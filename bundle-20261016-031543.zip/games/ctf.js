/* 깃발 뺏기 팀전 — realtime top-down capture-the-flag for 2–8 people (two teams; bots fill the empty spots).
   One person per phone (realtime): alone you play with/against AI; friends play through online / LAN rooms.
   Field split by a centre line. On your own half you are safe and can tag enemies by touching them; on the enemy half
   you can be tagged → you go to the enemy jail. A teammate who touches that jail frees everyone inside (they walk home
   protected). Grab the enemy flag from its stand and carry it back into your own half = 1 point.
   The world engine (movement, rules, AI) is pure and lives outside the view so node can run headless matches.
   The host (or the local phone) runs it; guests publish their stick + dash events and draw the host's snapshots
   (their own player is predicted locally). Round flow (score, clock, phases) travels in the small coarse state. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- world units: x across (−FW..FW), y down (−FH..FH). Team 0 (빨강) owns y > 0, team 1 (파랑) y < 0 ---------- */
  const FW = 11, FH = 18, PR = 0.55;
  const BY = 14.2, FZ = 2.6, FLAG_R = 1.0;           // flag stand y, guard zone (owner can't enter), pick-up distance
  const JX = 7.2, JY = 14.6, JR = 1.45, JZ = 2.4;    // jail position, fence radius, guard zone
  const VRUN = 6.0, ACC = 40, VDASH = 13, DASH_T = 0.2, DASH_CD = 2.4;
  const CARRY_K = 0.74, BOOT_K = 1.3, PAD_K = 1.55, BOOT_T = 6, SHIELD_T = 12, IMM_T = 1.0;
  const JAIL_MAX = 20, FW_MAX = 9, DROP_T = 10, ITEM_FIRST = 14, ITEM_GAP = 18;
  const OT_T = 60, COUNT_T = 2.6, FIRST_T = 6.2, END_T = 2.8, LAST_T = 0.8;
  const SUB = 1 / 60;
  const sgn = (t) => (t ? -1 : 1);
  const side = (y) => (y > 0 ? 0 : 1);                // whose half a point is in
  const BASE = [[0, BY], [0, -BY]];
  const JAIL = [[-JX, JY], [JX, -JY]];                // JAIL[t] lies in team t's half and holds the OTHER team

  /* ---------- maps (each obstacle list is mirrored through the centre so both teams get the same field) ----------
     W walls / A water (block movement) / B bushes (hide) / P speed pads / M moving carts [y, amp, period, phase, hw, hh]
     *c lists are already symmetric (not mirrored). it = item spots, ln = attack lanes (x). */
  const MAPS = [
    { id: 'park', nm: '잔디 공원', d: '덤불에 숨어서 몰래 다가가요', acc: ACC, spd: 1,
      W: [[-5, 5.5, 1.4, 0.5], [6.5, 8, 0.5, 1.4], [-8.5, 2.5, 0.7, 0.7], [3, 3, 0.6, 0.6]], Wc: [[0, 0, 0.8, 0.8]],
      B: [[6, 3.6, 1.5], [-8.6, 8, 1.6], [-2.4, 2.2, 1.1]], it: [[-6, 0], [6, 0]], ln: [-6.5, 0, 6.5] },
    { id: 'river', nm: '시냇물 다리', d: '물은 못 건너요 — 다리 3개로만!', acc: ACC, spd: 1,
      Ac: [[-9.9, 0, 1.1, 1.3], [-3.75, 0, 2.45, 1.3], [3.75, 0, 2.45, 1.3], [9.9, 0, 1.1, 1.3]],
      W: [[-4, 5, 0.8, 0.8], [5, 7, 0.7, 1.2]], B: [[-9, 4.2, 1.4], [3.4, 3.4, 1.3]],
      it: [[-7.5, 0], [0, 0], [7.5, 0]], ln: [-7.5, 0, 7.5] },
    { id: 'maze', nm: '미로 정원', d: '산울타리 미로 — 길을 잘 골라요', acc: ACC, spd: 1,
      W: [[-7, 4, 4, 0.35], [4.5, 4, 3.5, 0.35], [0, 7.6, 4.5, 0.35], [-4.6, 11.6, 0.35, 1.6], [4.6, 11.6, 0.35, 1.6], [8.4, 8.6, 0.35, 2]],
      Wc: [[0, 0, 2, 0.35]], B: [[9.3, 1.8, 1.2], [-2, 5.8, 1.1]], it: [[-6, 0], [6, 0]], ln: [-9.5, -1.5, 9.5] },
    { id: 'pads', nm: '질주 놀이터', d: '노란 발판을 밟으면 휙 빨라져요', acc: ACC, spd: 1,
      P: [[-9.4, 7, 0.9, 3.6], [9.4, 3, 0.9, 2.2], [4.2, 11.6, 1.2, 0.8]], Pc: [[0, 0, 1.6, 0.9]],
      W: [[-4, 6, 1, 1], [4.5, 7.5, 1.2, 0.5], [2, 3, 0.5, 1]], B: [[6.6, 11, 1.3]], it: [[-5.5, 0], [5.5, 0]], ln: [-8, 0, 8] },
    { id: 'mine', nm: '광산 수레길', d: '오가는 수레에 막히지 않게!', acc: ACC, spd: 1,
      M: [[4.8, 7.5, 5.5, 0, 1.3, 0.6], [11, 4.5, 4.2, 1.2, 1.1, 0.6], [1.8, 8.6, 7, 0.5, 1.3, 0.55]],
      W: [[-9.5, 7.8, 0.9, 0.9], [9, 7.5, 0.8, 0.8]], B: [[-9.4, 2.6, 1.2]], it: [[-5, 0], [5, 0]], ln: [-6, 0, 6] },
    { id: 'night', nm: '한밤 캠프', d: '깜깜해요 — 친구 근처만 보여요', acc: ACC, spd: 1, night: 1,
      W: [[-5, 6, 1.3, 1], [5.5, 4, 1, 1.3], [8.5, 9.6, 0.8, 0.8]],
      B: [[-8.5, 3, 1.5], [2.5, 7, 1.3], [-2, 2.8, 1.2], [6.8, 12.4, 1.2]], it: [[-6, 0], [6, 0], [0, 0]], ln: [-7, 0, 7] },
    { id: 'ice', nm: '얼음 호수', d: '쭉 미끄러져요, 얼음 구멍 조심', acc: 9, spd: 1.06,
      W: [[-6, 5, 1.6, 0.6], [6, 8.5, 0.6, 1.5]], A: [[3.5, 5, 1, 1], [-8.3, 10.5, 0.9, 0.9], [-1.8, 2.4, 0.7, 0.7]],
      B: [[8.6, 3, 1.3]], it: [[-6, 0], [6, 0]], ln: [-6, 0, 6] },
  ];
  /* geometry: absolute rects [x0,y0,x1,y1,kind(0 wall/1 water)], bushes, pads, carts, grid for the AI */
  const GX = 2 * FW, GY = 2 * FH;
  function geom(mk) {
    const m = MAPS[mk] || MAPS[0];
    if (m.G) return m.G;
    const R = [], B = [], P = [], M = [];
    const rect = (a, k, mir) => { const r = [a[0] - a[2], a[1] - a[3], a[0] + a[2], a[1] + a[3], k]; R.push(r); if (mir) R.push([-a[0] - a[2], -a[1] - a[3], -a[0] + a[2], -a[1] + a[3], k]); };
    (m.W || []).forEach((a) => rect(a, 0, 1)); (m.Wc || []).forEach((a) => rect(a, 0, 0));
    (m.A || []).forEach((a) => rect(a, 1, 1)); (m.Ac || []).forEach((a) => rect(a, 1, 0));
    (m.B || []).forEach((b) => { B.push([b[0], b[1], b[2]]); B.push([-b[0], -b[1], b[2]]); });
    const pad = (a, mir) => { P.push([a[0] - a[2], a[1] - a[3], a[0] + a[2], a[1] + a[3]]); if (mir) P.push([-a[0] - a[2], -a[1] - a[3], -a[0] + a[2], -a[1] + a[3]]); };
    (m.P || []).forEach((a) => pad(a, 1)); (m.Pc || []).forEach((a) => pad(a, 0));
    (m.M || []).forEach((a) => { M.push({ y: a[0], A: a[1], P: a[2], ph: a[3], hw: a[4], hh: a[5] }); M.push({ y: -a[0], A: a[1], P: a[2], ph: a[3] + Math.PI, hw: a[4], hh: a[5] }); });
    const walk = new Uint8Array(GX * GY), r0 = 0.45;
    for (let j = 0; j < GY; j++) for (let i = 0; i < GX; i++) {
      const cx = -FW + 0.5 + i, cy = -FH + 0.5 + j;
      let ok = 1;
      for (const r of R) { const qx = clamp(cx, r[0], r[2]), qy = clamp(cy, r[1], r[3]); if ((qx - cx) * (qx - cx) + (qy - cy) * (qy - cy) < r0 * r0) { ok = 0; break; } }
      walk[j * GX + i] = ok;
    }
    m.G = { R, B, P, M, walk, fc: new Map(), it: (m.it || [[0, 0]]).slice(), ln: (m.ln || [-6, 0, 6]).slice() };
    return m.G;
  }

  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  const NOIN = { ax: 0, ay: 0, ev: null, spd: 1 };

  /* ---------- AI navigation: distance fields on a 1-unit grid (Dial's algorithm, cached per map) ---------- */
  const cellOf = (x, y) => clamp(Math.floor(y + FH), 0, GY - 1) * GX + clamp(Math.floor(x + FW), 0, GX - 1);
  const NB = [[1, 0, 2], [-1, 0, 2], [0, 1, 2], [0, -1, 2], [1, 1, 3], [1, -1, 3], [-1, 1, 3], [-1, -1, 3]];
  function buildField(G, srcs) {
    const D = new Int16Array(GX * GY).fill(32767), bk = [];
    for (const c of srcs) { D[c] = 0; (bk[0] || (bk[0] = [])).push(c); }
    for (let d = 0; d < bk.length; d++) {
      const q = bk[d]; if (!q) continue;
      for (let k = 0; k < q.length; k++) {
        const c = q[k]; if (D[c] !== d) continue;
        const i = c % GX, j = (c - i) / GX;
        for (const n of NB) {
          const ni = i + n[0], nj = j + n[1];
          if (ni < 0 || nj < 0 || ni >= GX || nj >= GY) continue;
          const nc = nj * GX + ni;
          if (!G.walk[nc]) continue;
          if (n[0] && n[1] && (!G.walk[j * GX + ni] || !G.walk[nj * GX + i])) continue;
          const nd = d + n[2];
          if (nd < D[nc]) { D[nc] = nd; (bk[nd] || (bk[nd] = [])).push(nc); }
        }
      }
    }
    return D;
  }
  function fieldTo(G, x, y) {
    let c = cellOf(x, y);
    if (!G.walk[c]) {   // goal inside an obstacle: nearest walkable cell
      let best = c, bd = 1e9; const i0 = c % GX, j0 = (c - i0) / GX;
      for (let dj = -2; dj <= 2; dj++) for (let di = -2; di <= 2; di++) { const i = i0 + di, j = j0 + dj; if (i < 0 || j < 0 || i >= GX || j >= GY) continue; const cc = j * GX + i; if (G.walk[cc] && di * di + dj * dj < bd) { bd = di * di + dj * dj; best = cc; } }
      c = best;
    }
    const key = 'p' + c;
    let D = G.fc.get(key);
    if (!D) { D = buildField(G, [c]); if (G.fc.size > 80) G.fc.delete(G.fc.keys().next().value); G.fc.set(key, D); }
    return D;
  }
  function fieldHome(G, t) {
    const key = 'h' + t;
    let D = G.fc.get(key);
    if (!D) {
      const src = [];
      for (let j = 0; j < GY; j++) for (let i = 0; i < GX; i++) { const cy = -FH + 0.5 + j; if (G.walk[j * GX + i] && side(cy - 0.6 * sgn(t)) === t && Math.abs(cy) > 0.9) src.push(j * GX + i); }
      D = buildField(G, src); G.fc.set(key, D);
    }
    return D;
  }
  const FD = { x: 0, y: 0 };
  function flowDir(G, D, x, y) {
    const c = cellOf(x, y), i = c % GX, j = (c - i) / GX;
    let best = G.walk[c] ? D[c] : 32767, bi = -1, bj = -1;
    for (const n of NB) {
      const ni = i + n[0], nj = j + n[1];
      if (ni < 0 || nj < 0 || ni >= GX || nj >= GY) continue;
      const nc = nj * GX + ni;
      if (!G.walk[nc]) continue;
      if (n[0] && n[1] && (!G.walk[j * GX + ni] || !G.walk[nj * GX + i])) continue;
      if (D[nc] < best) { best = D[nc]; bi = ni; bj = nj; }
    }
    if (bi < 0) return null;
    const dx = -FW + 0.5 + bi - x, dy = -FH + 0.5 + bj - y, l = hyp(dx, dy) || 1;
    FD.x = dx / l; FD.y = dy / l; return FD;
  }
  function los(G, x0, y0, x1, y1) {
    const d = hyp(x1 - x0, y1 - y0), n = Math.ceil(d / 0.4);
    for (let k = 1; k < n; k++) { const f = k / n; if (!G.walk[cellOf(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f)]) return false; }
    return true;
  }

  /* ---------- world ---------- */
  function emit(W, hooks, code, a, b, c, d) {
    W.fxn++;
    W.fx.push([W.fxn, code, a, b, c, d]); if (W.fx.length > 12) W.fx.shift();
    if (hooks && hooks.fx) hooks.fx(code, a, b, c, d);
  }
  function mkPl(i, t, x, y) {
    return { i, t, x, y, vx: 0, vy: 0, a: t ? Math.PI / 2 : -Math.PI / 2, dash: 0, dx: 0, dy: 0, dcd: 0, jl: 0, jT: 0, fw: 0, fwT: 0, sh: 0, bo: 0, imm: 0, pd: 0, tp: 0 };
  }
  function spawnSpots(t, n) {
    const out = [];
    for (let k = 0; k < n; k++) out.push([sgn(t) * (-5 + 10 * (k + 0.5) / n), sgn(t) * 9.5]);
    return out;
  }
  function newWorld(st) {
    const mp = MAPS[st.mk] || MAPS[0], G = geom(st.mk);
    const W = { mp, G, mk: st.mk, pl: [], t: st.el || 0, rt: st.rt || 300, ot: (st.el || 0) >= (st.rt || 300) ? 1 : 0, sc: (st.sc || [0, 0]).slice(),
      fg: [mkFlag(0), mkFlag(1)], it: null, iT: ITEM_FIRST, res: null, endT: 0, fx: [], fxn: 0,
      tgs: Array(st.N).fill(0), rss: Array(st.N).fill(0), role: Array(st.N).fill(''), plan: [null, null], bot: Array(st.N).fill(1), mv: [] };
    for (let t = 0; t < 2; t++) {
      const mem = []; for (let i = 0; i < st.N; i++) if (st.tm[i] === t) mem.push(i);
      const sp = spawnSpots(t, mem.length);
      mem.forEach((i, k) => { W.pl[i] = mkPl(i, t, sp[k][0], sp[k][1]); });
    }
    for (let i = 0; i < st.N; i++) if (!W.pl[i]) W.pl[i] = mkPl(i, st.tm[i] | 0, 0, sgn(st.tm[i] | 0) * 9.5);
    moversAt(W);
    return W;
  }
  function mkFlag(t) { return { t, x: BASE[t][0], y: BASE[t][1], h: -1, at: 0, rT: 0 }; }
  function moversAt(W) {
    const M = W.G.M; W.mv.length = M.length;
    for (let k = 0; k < M.length; k++) { const m = M[k], x = m.A * Math.sin(6.2832 * W.t / m.P + m.ph); W.mv[k] = [x - m.hw, m.y - m.hh, x + m.hw, m.y + m.hh]; }
  }
  const carrying = (W, p) => (W.fg[0].h === p.i ? W.fg[0] : W.fg[1].h === p.i ? W.fg[1] : null);
  const free = (p) => !p.jl && !p.fw && p.tp <= 0;
  function inBush(G, x, y) { for (const b of G.B) if ((x - b[0]) * (x - b[0]) + (y - b[1]) * (y - b[1]) < b[2] * b[2]) return true; return false; }
  const NIGHT_V = 5.5, BUSH_V = 2.6, LANT_R = 2.8;
  function lanterns() { return [BASE[0], BASE[1], JAIL[0], JAIL[1]]; }
  /* can team `team` see player q right now? (bushes hide, night limits vision to near teammates + lanterns) */
  function visibleTo(W, team, q) {
    if (q.t === team || q.jl) return true;
    if (W.fg[team].h === q.i) return true;        // the flag glows
    const bush = inBush(W.G, q.x, q.y), night = !!W.mp.night;
    if (!bush && !night) return true;
    const R = bush ? BUSH_V : NIGHT_V;
    for (const p of W.pl) if (p.t === team && !p.jl && hyp(p.x - q.x, p.y - q.y) < R) return true;
    if (!bush && night) for (const l of lanterns()) if (hyp(l[0] - q.x, l[1] - q.y) < LANT_R) return true;
    return false;
  }

  /* ---------- movement & collisions ---------- */
  function pushRect(p, r) {
    const cx = clamp(p.x, r[0], r[2]), cy = clamp(p.y, r[1], r[3]);
    let dx = p.x - cx, dy = p.y - cy; const d2 = dx * dx + dy * dy;
    if (d2 >= PR * PR) return;
    if (d2 > 1e-9) {
      const d = Math.sqrt(d2); dx /= d; dy /= d;
      p.x += dx * (PR - d); p.y += dy * (PR - d);
      const vn = p.vx * dx + p.vy * dy; if (vn < 0) { p.vx -= vn * dx; p.vy -= vn * dy; }
    } else {        // centre inside: leave by the nearest edge
      const l = p.x - r[0], rr = r[2] - p.x, u = p.y - r[1], b = r[3] - p.y, m = Math.min(l, rr, u, b);
      if (m === l) { p.x = r[0] - PR; p.vx = Math.min(0, p.vx); } else if (m === rr) { p.x = r[2] + PR; p.vx = Math.max(0, p.vx); }
      else if (m === u) { p.y = r[1] - PR; p.vy = Math.min(0, p.vy); } else { p.y = r[3] + PR; p.vy = Math.max(0, p.vy); }
    }
  }
  function pushOutCircle(p, cx, cy, R) {
    let dx = p.x - cx, dy = p.y - cy; const d = hyp(dx, dy);
    if (d >= R) return;
    if (d < 1e-6) { dx = 0; dy = -sgn(p.t); } else { dx /= d; dy /= d; }
    p.x = cx + dx * R; p.y = cy + dy * R;
    const vn = p.vx * dx + p.vy * dy; if (vn < 0) { p.vx -= vn * dx; p.vy -= vn * dy; }
  }
  function collide(W, p) {
    const G = W.G;
    for (const r of G.R) pushRect(p, r);
    for (const r of W.mv) pushRect(p, r);
    // guard zones: you can't stand around your own flag stand or your own jail
    pushOutCircle(p, BASE[p.t][0], BASE[p.t][1], FZ);
    pushOutCircle(p, JAIL[p.t][0], JAIL[p.t][1], JZ);
    for (const r of G.R) pushRect(p, r);
    if (p.x < -FW + PR) { p.x = -FW + PR; p.vx = Math.max(0, p.vx); } else if (p.x > FW - PR) { p.x = FW - PR; p.vx = Math.min(0, p.vx); }
    if (p.y < -FH + PR) { p.y = -FH + PR; p.vy = Math.max(0, p.vy); } else if (p.y > FH - PR) { p.y = FH - PR; p.vy = Math.min(0, p.vy); }
  }
  function onPad(G, x, y) { for (const r of G.P) if (x > r[0] && x < r[2] && y > r[1] && y < r[3]) return true; return false; }
  function speedOf(W, p, I) {
    let v = VRUN * W.mp.spd * clamp(+I.spd || 1, 0.5, 1);
    if (carrying(W, p)) v *= CARRY_K;
    if (p.bo > 0) v *= BOOT_K;
    if (p.pd > 0) v *= PAD_K;
    if (p.fw) v *= 1.08;
    return v;
  }
  function movePlayer(W, p, I, h) {
    if (p.dcd > 0) p.dcd -= h; if (p.sh > 0) p.sh -= h; if (p.bo > 0) p.bo -= h; if (p.imm > 0) p.imm -= h; if (p.pd > 0) p.pd -= h; if (p.tp > 0) p.tp -= h;
    let mx = clamp(+I.ax || 0, -1, 1), my = clamp(+I.ay || 0, -1, 1); const m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
    if (p.jl) {     // inside the jail fence: shuffle around a little
      const J = JAIL[1 - p.t];
      p.vx = mx * 2; p.vy = my * 2; p.x += p.vx * h; p.y += p.vy * h;
      const dx = p.x - J[0], dy = p.y - J[1], d = hyp(dx, dy), R = JR - PR;
      if (d > R) { p.x = J[0] + dx / d * R; p.y = J[1] + dy / d * R; }
      p.jT += h;
      return;
    }
    if (p.fw) p.fwT += h;
    if (p.dash > 0) {
      p.dash -= h;
      p.vx = p.dx * VDASH; p.vy = p.dy * VDASH;
      if (p.dash <= 0) { const k = speedOf(W, p, I) / VDASH; p.vx *= Math.max(0.45, k); p.vy *= Math.max(0.45, k); }
    } else {
      const vm = p.tp > 0 ? 0 : speedOf(W, p, I), am = W.mp.acc * h * (p.pd > 0 ? 1.4 : 1);
      let ax = mx * vm - p.vx, ay = my * vm - p.vy; const al = hyp(ax, ay);
      if (al > am) { ax *= am / al; ay *= am / al; }
      p.vx += ax; p.vy += ay;
    }
    if (hyp(p.vx, p.vy) > 0.6) p.a = Math.atan2(p.vy, p.vx);
    p.x += p.vx * h; p.y += p.vy * h;
    collide(W, p);
    if (onPad(W.G, p.x, p.y)) p.pd = 0.6;
  }
  function doEvent(W, p, ev, hooks) {
    if (!Array.isArray(ev)) return;
    if (ev[0] === 'd' && p.dcd <= 0 && !p.jl && p.tp <= 0) {
      let dx = +ev[1] || 0, dy = +ev[2] || 0, l = hyp(dx, dy);
      if (l < 0.2) { dx = p.vx; dy = p.vy; l = hyp(dx, dy); if (l < 0.3) { dx = Math.cos(p.a); dy = Math.sin(p.a); l = 1; } }
      p.dx = dx / l; p.dy = dy / l; p.dash = DASH_T; p.dcd = carrying(W, p) ? DASH_CD * 1.25 : DASH_CD;
      emit(W, hooks, 8, r1(p.x), r1(p.y), p.i, 0);
    }
  }

  /* ---------- rules ---------- */
  function jailSlot(W, t, i) {    // t = prisoner team; spread prisoners inside the fence
    const J = JAIL[1 - t]; let k = 0, n = 0;
    for (const q of W.pl) if (q.t === t && q.jl) { if (q.i < i) k++; n++; }
    const a = k / Math.max(1, n + 1) * 6.283 + 0.6;
    return [J[0] + Math.cos(a) * 0.55, J[1] + Math.sin(a) * 0.55];
  }
  function dropFlag(W, F, x, y, hooks) {
    F.h = -1;
    if (hyp(x - BASE[F.t][0], y - BASE[F.t][1]) < FZ + 0.3) { F.x = BASE[F.t][0]; F.y = BASE[F.t][1]; F.at = 0; emit(W, hooks, 3, r1(F.x), r1(F.y), F.t, -1); return; }
    F.x = clamp(x, -FW + 0.6, FW - 0.6); F.y = clamp(y, -FH + 0.6, FH - 0.6); F.at = 1; F.rT = DROP_T;
    emit(W, hooks, 4, r1(F.x), r1(F.y), F.t, 0);
  }
  function tagPlayer(W, v, q, hooks) {   // q (on its own half) touched v (on q's half)
    if (v.imm > 0) return;
    if (v.sh > 0) {
      v.sh = 0; v.imm = IMM_T;
      let dx = v.x - q.x, dy = v.y - q.y; const d = hyp(dx, dy) || 1; dx /= d; dy /= d;
      v.vx = dx * 9; v.vy = dy * 9; q.vx = -dx * 5; q.vy = -dy * 5;
      emit(W, hooks, 1, r1(v.x), r1(v.y), v.i, q.i);
      return;
    }
    const F = carrying(W, v);
    if (F) dropFlag(W, F, v.x, v.y, hooks);
    emit(W, hooks, 0, r1(v.x), r1(v.y), v.i, q.i);
    v.jl = 1; v.jT = 0; v.dash = 0; v.vx = 0; v.vy = 0; v.sh = 0; v.bo = 0; v.pd = 0;
    const s = jailSlot(W, v.t, v.i); v.x = s[0]; v.y = s[1];
    W.tgs[q.i] = (W.tgs[q.i] | 0) + 1;
  }
  function release(W, p, hooks) { p.jl = 0; p.jT = 0; p.fw = 1; p.fwT = 0; p.tp = 0.25; p.imm = 0; }
  function stepWorld(W, h, inputs, hooks) {
    moversAt(W);
    for (const p of W.pl) {
      const I = inputs[p.i] || NOIN;
      if (I.ev) { doEvent(W, p, I.ev, hooks); I.ev = null; }
      movePlayer(W, p, I, h);
      if (p.fw && ((side(p.y) === p.t && Math.abs(p.y) > 0.8 && p.fwT > 0.3) || p.fwT > FW_MAX)) { p.fw = 0; p.fwT = 0; p.imm = 0.6; }
    }
    const pl = W.pl, TR = 2 * PR + 0.05;
    // tags + bodies
    for (let i = 0; i < pl.length; i++) for (let j = i + 1; j < pl.length; j++) {
      const a = pl[i], c = pl[j];
      if (!free(a) || !free(c)) continue;
      let dx = c.x - a.x, dy = c.y - a.y; const d2 = dx * dx + dy * dy;
      if (d2 >= TR * TR) continue;
      if (a.t !== c.t) {
        const sa = side(a.y), sc = side(c.y);
        if (sa === c.t && sc === c.t) { tagPlayer(W, a, c, hooks); continue; }
        if (sa === a.t && sc === a.t) { tagPlayer(W, c, a, hooks); continue; }
      }
      let d = Math.sqrt(d2); if (d < 1e-6) { dx = 0.01; dy = 0; d = 0.01; }
      if (d >= 2 * PR) continue;
      const nx = dx / d, ny = dy / d, o = (2 * PR - d) / 2;
      a.x -= nx * o; a.y -= ny * o; c.x += nx * o; c.y += ny * o;
      collide(W, a); collide(W, c);
    }
    // flags
    for (const F of W.fg) {
      if (F.h >= 0) {
        const p = pl[F.h];
        if (!p || p.jl) { F.h = -1; F.at = 1; F.rT = DROP_T; continue; }
        F.x = p.x; F.y = p.y;
        if (side(p.y) === p.t && Math.abs(p.y) > 0.05 && !W.res) {
          W.res = { w: p.t, why: 'cap', by: p.i };
          emit(W, hooks, 7, r1(p.x), r1(p.y), p.i, p.t);
        }
        continue;
      }
      for (const p of pl) {
        if (!free(p) || hyp(p.x - F.x, p.y - F.y) > FLAG_R + PR * 0.3) continue;
        if (p.t !== F.t) { if (!carrying(W, p)) { F.h = p.i; F.at = 1; emit(W, hooks, 2, r1(p.x), r1(p.y), p.i, F.t); break; } }
        else if (F.at) { F.x = BASE[F.t][0]; F.y = BASE[F.t][1]; F.at = 0; emit(W, hooks, 3, r1(F.x), r1(F.y), F.t, p.i); break; }
      }
      if (F.h < 0 && F.at) { F.rT -= h; if (F.rT <= 0) { F.x = BASE[F.t][0]; F.y = BASE[F.t][1]; F.at = 0; emit(W, hooks, 3, r1(F.x), r1(F.y), F.t, -1); } }
    }
    // jails: a free teammate touching the fence frees everybody inside; long stays end by themselves
    for (let t = 0; t < 2; t++) {
      const J = JAIL[1 - t];
      let n = 0; for (const p of pl) if (p.t === t && p.jl) n++;
      if (!n) continue;
      for (const p of pl) {
        if (p.t !== t || !free(p) || hyp(p.x - J[0], p.y - J[1]) > JR + PR) continue;
        for (const q of pl) if (q.t === t && q.jl) release(W, q, hooks);
        p.fw = 1; p.fwT = 0;
        const F = carrying(W, p); if (F) dropFlag(W, F, p.x, p.y, hooks);
        W.rss[p.i] = (W.rss[p.i] | 0) + 1;
        emit(W, hooks, 5, r1(J[0]), r1(J[1]), p.i, n);
        n = 0; break;
      }
      if (n) for (const q of pl) if (q.t === t && q.jl && q.jT >= JAIL_MAX) { release(W, q, hooks); emit(W, hooks, 6, r1(q.x), r1(q.y), q.i, 0); }
    }
    // item
    if (W.it) {
      for (const p of pl) {
        if (!free(p) || hyp(p.x - W.it.x, p.y - W.it.y) > PR + 0.55) continue;
        if (W.it.k) p.sh = SHIELD_T; else p.bo = BOOT_T;
        emit(W, hooks, 10, r1(W.it.x), r1(W.it.y), p.i, W.it.k);
        W.it = null; W.iT = ITEM_GAP; break;
      }
    }
  }
  function tickWorld(W, dt, inputs, hooks) {
    if (W.res) { W.endT += dt; return W.endT >= LAST_T ? W.res : null; }
    W.t += dt;
    if (!W.it) {
      W.iT -= dt;
      if (W.iT <= 0) {
        const sp = W.G.it[Math.floor(Math.random() * W.G.it.length)];
        W.it = { k: Math.random() < 0.5 ? 0 : 1, x: sp[0], y: sp[1] };
        emit(W, hooks, 9, sp[0], sp[1], W.it.k, 0);
      }
    }
    const n = Math.min(40, Math.max(1, Math.ceil(dt / SUB))), h = dt / n;
    for (let k = 0; k < n && !W.res; k++) { W.t += 0; stepWorld(W, h, inputs, hooks); }
    if (!W.res) {
      if (!W.ot && W.t >= W.rt) {
        if (W.sc[0] !== W.sc[1]) W.res = { w: -1, why: 'time', by: -1 };
        else { W.ot = 1; emit(W, hooks, 11, 0, 0, 0, 0); }
      } else if (W.ot && W.t >= W.rt + OT_T) W.res = { w: -1, why: 'time', by: -1 };
    }
    return null;
  }

  /* ---------- AI ---------- */
  const AI_DIFF = {
    1: { think: 0.5, spd: 0.84, av: 0.45, rav: 2.6, lead: 0, dash: 0.25, chase: 7, item: 3, err: 0.45, wait: 0, resD: 4, opp: 1.8 },
    2: { think: 0.28, spd: 0.93, av: 0.9, rav: 3.4, lead: 0.5, dash: 0.6, chase: 10, item: 6, err: 0.2, wait: 2.5, resD: 1.2, opp: 3 },
    3: { think: 0.2, spd: 0.96, av: 1.1, rav: 3.9, lead: 0.85, dash: 0.85, chase: 12, item: 9, err: 0.1, wait: 3.5, resD: 0, opp: 3.8 },
  };
  /* team plan: who defends / attacks / rescues; refreshed about every 0.6s */
  function teamPlan(W, t) {
    let P = W.plan[t];
    if (P && W.t - P.at < 0.6) return P;
    const s = sgn(t), mem = W.pl.filter((p) => p.t === t), T = mem.length;
    const bots = mem.filter((p) => W.bot[p.i] && !p.jl && !p.fw && W.fg[1 - t].h !== p.i);
    const nDef = Math.min(bots.length, T >= 4 ? 2 : 1);
    const prev = P ? P.def : [];
    const def = [];
    for (const i of prev) if (def.length < nDef && bots.some((b) => b.i === i)) def.push(i);
    const byBase = bots.filter((b) => !def.includes(b.i)).sort((a, b) => hyp(a.x - BASE[t][0], a.y - BASE[t][1]) - hyp(b.x - BASE[t][0], b.y - BASE[t][1]));
    for (const b of byBase) if (def.length < nDef) def.push(b.i);
    // only defenders if someone else attacks: a lone bot on a 2-person team with a human defends, else attacks
    const pris = mem.filter((p) => p.jl);
    let res = -1;
    if (pris.length) {
      const J = JAIL[1 - t];
      let cand = bots.filter((b) => !def.includes(b.i)); if (!cand.length) cand = bots;
      let bd = 1e9; for (const b of cand) { const d = hyp(b.x - J[0], b.y - J[1]); if (d < bd) { bd = d; res = b.i; } }
    }
    const intr = W.pl.filter((q) => q.t !== t && free(q) && side(q.y) === t && visibleTo(W, t, q));
    const eCar = W.fg[t].h >= 0 ? W.pl[W.fg[t].h] : null;
    // lanes for attackers: fewer visible enemies near the crossing = better
    const lanes = W.G.ln.map((x0) => {
      const x = x0 * s;
      let sc = 0; for (const q of W.pl) if (q.t !== t && free(q) && visibleTo(W, t, q) && side(q.y) !== t) sc += Math.max(0, 6 - hyp(q.x - x, q.y + s * 4));
      return { x, sc };
    }).sort((a, b) => a.sc - b.sc);
    let k = 0;
    for (const b of bots) {
      W.role[b.i] = b.i === res ? 'res' : def.includes(b.i) ? 'def' : 'att';
      if (W.role[b.i] === 'att') b._lane = lanes[k++ % lanes.length].x;
    }
    P = W.plan[t] = { at: W.t, def, res, intr, eCar, lanes, pris: pris.length, pT: P && P.pris ? P.pT + (W.t - P.at) : 0 };
    if (!pris.length) P.pT = 0;
    return P;
  }
  function nearestThreat(W, p) {    // enemies who could tag p (they stand on their own half)
    let best = null, bd = 1e9;
    for (const q of W.pl) {
      if (q.t === p.t || !free(q) || side(q.y) !== q.t || !visibleTo(W, p.t, q)) continue;
      const d = hyp(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; best = q; }
    }
    return best ? { q: best, d: bd } : null;
  }
  function decide(W, p, M, D, lv) {
    const t = p.t, s = sgn(t), G = W.G, P = teamPlan(W, t);
    const E = W.fg[1 - t], own = W.fg[t];
    M.avoid = 0; M.home = 0; M.chase = -1;
    const inOwn = side(p.y) === t;
    const set = (x, y) => { M.gx = x; M.gy = y; };
    if (E.h === p.i) { M.home = 1; M.avoid = 1; M.mode = 'carry'; return; }
    if (p.fw) { M.home = 1; M.mode = 'home'; return; }
    const role = W.role[p.i] || 'att';
    const chase = (q) => {
      const d = hyp(q.x - p.x, q.y - p.y), T = Math.min(0.8, d / 7) * D.lead;
      let gx = q.x + q.vx * T, gy = q.y + q.vy * T;
      if (gy * s < 0.4) gy = s * 0.4;
      set(gx, gy); M.chase = q.i; M.mode = 'chase';
    };
    // enemy runs off with our flag: defenders and close teammates go after the carrier
    const ec = P.eCar && free(P.eCar) && side(P.eCar.y) === t ? P.eCar : null;
    if (ec && visibleTo(W, t, ec)) {
      const d = hyp(ec.x - p.x, ec.y - p.y);
      if (role === 'def' || (inOwn && d < D.chase * (lv >= 3 ? 1 : 0.6))) { chase(ec); return; }
    }
    // a close intruder on our side: tag it
    if (inOwn) {
      let bq = null, bd = role === 'def' ? D.chase : D.opp;
      for (const q of P.intr) { if (!free(q) || side(q.y) !== t) continue; const d = hyp(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; bq = q; } }
      if (bq) { chase(bq); return; }
    }
    // item nearby (attackers/rescuers only grab it if it's on the way)
    if (W.it && role !== 'def') {
      const d = hyp(W.it.x - p.x, W.it.y - p.y);
      if (d < D.item && (side(W.it.y) === t || Math.abs(W.it.y) < 0.5)) { set(W.it.x, W.it.y); M.mode = 'item'; M.avoid = 1; return; }
    }
    if (role === 'res' && (P.pT >= D.resD || lv >= 2)) {
      const J = JAIL[1 - t]; set(J[0], J[1]); M.mode = 'res'; M.avoid = 1; return;
    }
    if (role === 'def') {
      const rank = P.def.indexOf(p.i);
      let enemyPris = 0; for (const q of W.pl) if (q.t !== t && q.jl) enemyPris++;
      let gx, gy;
      const guard = (cx, cy, R) => {
        let bq = null, bd = 1e9;
        for (const q of W.pl) { if (q.t === t || !free(q) || !visibleTo(W, t, q)) continue; const d = hyp(q.x - cx, q.y - cy); if (d < bd) { bd = d; bq = q; } }
        let dx = 0, dy = -s;
        if (bq) { dx = bq.x - cx; dy = bq.y - cy; const l = hyp(dx, dy) || 1; dx /= l; dy /= l; }
        else { const a = W.t * 0.6 + p.i; dx = Math.sin(a) * 0.7 * s; dy = -s; const l = hyp(dx, dy); dx /= l; dy /= l; }
        gx = cx + dx * R; gy = cy + dy * R;
      };
      if (rank <= 0) { if (own.at === 0) guard(BASE[t][0], BASE[t][1], FZ + 0.5); else { set(own.x, own.y); M.mode = 'ret'; return; } }
      else if (enemyPris) guard(JAIL[t][0], JAIL[t][1], JZ + 0.6);
      else {
        let bq = null, bd = 1e9; for (const q of W.pl) { if (q.t === t || !free(q) || !visibleTo(W, t, q)) continue; const d = Math.abs(q.y - s * 4); if (d < bd) { bd = d; bq = q; } }
        gx = clamp(bq ? bq.x : 0, -8, 8); gy = s * 5;
      }
      if (gy * s < 0.5) gy = s * 0.5;
      set(gx, gy); M.mode = 'guard'; return;
    }
    // attacker
    if (own.at && own.h < 0 && hyp(own.x - p.x, own.y - p.y) < 8) { set(own.x, own.y); M.mode = 'ret'; return; }
    if (E.h >= 0) {   // a teammate has the enemy flag: rescue or block chasers on our side of the line
      if (P.pris && W.role[p.i] !== 'def') { const J = JAIL[1 - t]; set(J[0], J[1]); M.mode = 'res'; M.avoid = 1; return; }
      const c = W.pl[E.h]; set(clamp(c.x, -8, 8), s * 1.5); M.mode = 'cover'; return;
    }
    const lane = p._lane != null ? p._lane : 0;
    if (inOwn && p.y * s > 0.2) {
      const stage = [lane, s * 1.6];
      const dS = hyp(p.x - stage[0], p.y - stage[1]);
      if (dS > 2.2 && !M.go) { set(stage[0], stage[1]); M.mode = 'stage'; M.wait = 0; return; }
      // at the line: wait for an opening (better bots), then go
      let danger = 0;
      for (const q of W.pl) { if (q.t === t || !free(q) || side(q.y) === t || !visibleTo(W, t, q)) continue; const d = hyp(q.x - p.x, q.y + s * 2.5 - p.y); if (d < 4.2) danger += 4.2 - d; }
      M.wait = (M.wait || 0) + D.think;
      if (danger > 1.2 && M.wait < D.wait && !M.go) {
        set(clamp(lane + (Math.sin(W.t * 1.3 + p.i) > 0 ? 3 : -3) * s, -FW + 1, FW - 1), s * 1.4); M.mode = 'feint'; return;
      }
      M.go = 1;
    }
    if (side(p.y) !== t) M.go = 0;
    set(E.x, E.y); M.mode = 'att'; M.avoid = 1;
  }
  function aiThink(W, p, M, lv, dt) {
    const D = AI_DIFF[lv] || AI_DIFF[2];
    const I = M.I || (M.I = { ax: 0, ay: 0, ev: null, spd: 1 });
    I.spd = D.spd;
    if (p.jl) { M.tt = 0; const a = W.t * 0.8 + p.i * 2; I.ax = Math.sin(a) * 0.4; I.ay = Math.cos(a * 1.3) * 0.4; return I; }
    M.tt = (M.tt || 0) - dt;
    if (M.tt <= 0 || M.gx == null) { M.tt = D.think * (0.8 + Math.random() * 0.4); decide(W, p, M, D, lv); M.ea = (Math.random() - 0.5) * 2 * D.err; }
    const G = W.G, s = sgn(p.t);
    let dx = 0, dy = 0;
    if (M.home) {
      const f = flowDir(G, fieldHome(G, p.t), p.x, p.y);
      if (f) { dx = f.x; dy = f.y; } else { dx = 0; dy = s; }
    } else {
      const gx = M.gx, gy = M.gy, d = hyp(gx - p.x, gy - p.y);
      if (d < 0.35 && M.mode !== 'chase') { dx = 0; dy = 0; }
      else if (d < 2.5 || los(G, p.x, p.y, gx, gy)) { dx = (gx - p.x) / (d || 1); dy = (gy - p.y) / (d || 1); if (M.mode !== 'chase' && d < 1.2) { dx *= d / 1.2; dy *= d / 1.2; } }
      else { const f = flowDir(G, fieldTo(G, gx, gy), p.x, p.y); if (f) { dx = f.x; dy = f.y; } else { dx = (gx - p.x) / d; dy = (gy - p.y) / d; } }
    }
    // dodge enemies who can tag me
    let th = null;
    if (M.avoid || side(p.y) !== p.t) {
      th = nearestThreat(W, p);
      let ax = 0, ay = 0;
      for (const q of W.pl) {
        if (q.t === p.t || !free(q) || side(q.y) !== q.t || !visibleTo(W, p.t, q)) continue;
        const ex = p.x - (q.x + q.vx * 0.2), ey = p.y - (q.y + q.vy * 0.2), d = hyp(ex, ey);
        if (d > D.rav || d < 1e-3) continue;
        const w = (D.rav - d) / D.rav; ax += ex / d * w; ay += ey / d * w;
      }
      if (ax || ay) {
        // don't let avoidance push straight backwards: keep some forward drive
        dx += ax * D.av * 1.6; dy += ay * D.av * 1.6;
        const l = hyp(dx, dy) || 1; dx /= l; dy /= l;
      }
    }
    if (M.ea && (dx || dy)) { const c = Math.cos(M.ea), sn = Math.sin(M.ea); const nx = dx * c - dy * sn, ny = dx * sn + dy * c; dx = nx; dy = ny; }
    // stuck → wiggle
    M.sT = (M.sT || 0) + dt;
    if (M.sT > 0.8) { const mv = hyp(p.x - (M.lx || 0), p.y - (M.ly || 0)); M.stuck = (dx || dy) && mv < 0.35 ? 0.5 : (M.stuck || 0); M.lx = p.x; M.ly = p.y; M.sT = 0; if (M.stuck) M.wa = (Math.random() - 0.5) * 3; }
    if (M.stuck > 0) { M.stuck -= dt; const c = Math.cos(M.wa), sn = Math.sin(M.wa); const nx = dx * c - dy * sn, ny = dx * sn + dy * c; dx = nx; dy = ny; }
    I.ax = dx; I.ay = dy;
    // dash
    if (p.dcd <= 0 && (dx || dy) && Math.random() < D.dash * dt * 6) {
      let want = false;
      if (th && th.d < 2.0 && side(p.y) !== p.t) want = true;
      if (M.mode === 'chase' && M.chase >= 0) { const q = W.pl[M.chase]; const d = hyp(q.x - p.x, q.y - p.y); if (d < 2.6 && d > 1.2) want = true; }
      if (M.mode === 'carry' && Math.abs(p.y) < 3) want = true;
      if (M.mode === 'att' && side(p.y) === p.t && Math.abs(p.y) < 1.5 && lv >= 2) want = true;
      if (want) I.ev = ['d', r2(dx), r2(dy)];
    }
    return I;
  }

  /* ---------- coarse state ---------- */
  function pickMap(mp, prev) {
    if (mp >= 0 && mp < MAPS.length) return mp;
    let k = Math.floor(Math.random() * MAPS.length);
    if (k === prev) k = (k + 1 + Math.floor(Math.random() * (MAPS.length - 1))) % MAPS.length;
    return k;
  }
  function init(players, opts) {
    const o = opts || {};
    const T = [2, 3, 4].includes(+o.ts) ? +o.ts : 4, N = 2 * T;
    const np = clamp(players.length | 0, 1, N);
    const tm = [], nm = [];
    for (let i = 0; i < np; i++) { tm.push(i % 2); nm.push(String((players[i] && players[i].name) || '').slice(0, 10)); }
    let bn = 0;
    for (let i = np; i < N; i++) {
      const a = tm.filter((t) => t === 0).length, b = tm.filter((t) => t === 1).length;
      tm.push(a <= b ? 0 : 1); nm.push('봇 ' + (++bn));
    }
    const mp = typeof +o.map === 'number' && +o.map >= -1 && +o.map < MAPS.length ? +o.map : -1;
    const need = [1, 3, 5].includes(+o.need) ? +o.need : 3;
    const rt = [180, 300, 480].includes(+o.time) ? +o.time : 300;
    return { rid: 1 + U.rand(99999), np, N, T, tm, nm, mp, mk: pickMap(mp, -1), need, rt,
      sc: [0, 0], ph: 'count', rd: 1, el: 0, rw: -1, by: -1, why: '', ca: Array(N).fill(0), tg: Array(N).fill(0), rs: Array(N).fill(0), res: null };
  }
  function seatsOfTeam(st, t) { const out = []; for (let i = 0; i < st.np; i++) if (st.tm[i] === t) out.push(i); return out; }
  function roundOver(st, res, el, tgs, rss) {
    const n = Object.assign({}, st, { sc: st.sc.slice(), ca: st.ca.slice(), tg: st.tg.slice(), rs: st.rs.slice(), ph: 'end', rw: res.w, by: res.by == null ? -1 : res.by, why: res.why || '', el: r1(Math.max(st.el, el)) });
    if ((res.w === 0 || res.w === 1) && res.why === 'cap') { n.sc[res.w]++; if (res.by >= 0 && res.by < n.ca.length) n.ca[res.by] = Math.min(99, n.ca[res.by] + 1); }
    if (Array.isArray(tgs)) tgs.forEach((v, i) => { if (i < n.tg.length) n.tg[i] = Math.min(999, (n.tg[i] | 0) + (v | 0)); });
    if (Array.isArray(rss)) rss.forEach((v, i) => { if (i < n.rs.length) n.rs[i] = Math.min(999, (n.rs[i] | 0) + (v | 0)); });
    return n;
  }
  function nextRound(st) {
    if (Math.max(st.sc[0], st.sc[1]) >= st.need || st.el >= st.rt || st.rd >= 60) {
      const w = st.sc[0] === st.sc[1] ? -1 : st.sc[0] > st.sc[1] ? 0 : 1;
      return Object.assign({}, st, { ph: 'done', res: [w] });
    }
    return Object.assign({}, st, { rd: st.rd + 1, ph: 'count', rw: -1, by: -1, why: '' });
  }
  const TEAM_NM = ['빨강 팀', '파랑 팀'];
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res)) return null;
    const w = st.res[0];
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번';
    const lines = [TEAM_NM[0] + ' ' + st.sc[0] + ' : ' + st.sc[1] + ' ' + TEAM_NM[1] + ' (' + st.T + ':' + st.T + ' · ' + MAPS[st.mk].nm + ')'];
    const scorers = st.nm.map((n, i) => ((st.ca[i] | 0) ? nm(i) + ((st.ca[i] | 0) > 1 ? ' ×' + st.ca[i] : '') : null)).filter(Boolean);
    if (scorers.length) lines.push('득점: ' + scorers.join(', '));
    const king = (arr, lab) => { let b = -1, v = 0; (arr || []).forEach((x, i) => { if ((x | 0) > v) { v = x | 0; b = i; } }); if (b >= 0) lines.push(lab + ': ' + nm(b) + ' (' + v + '번)'); };
    king(st.tg, '잡기 왕'); king(st.rs, '구출 왕');
    if (w !== 0 && w !== 1) return { winners: [], title: '무승부', text: lines.join('\n') };
    return { winners: seatsOfTeam(st, w), title: TEAM_NM[w] + ' 승리!', text: lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const TC = ['#ee6a55', '#4fa6e8'];
  const TCD = ['#a8392b', '#24609a'];
  const STICK_R = 46, TOPH = 50;
  const CSS = `
.cf-btn{position:absolute;border-radius:50%;border:2px solid rgba(242,233,216,.35);background:rgba(30,24,40,.82);color:#f2e9d8;
  font:800 17px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;
  touch-action:none;user-select:none;-webkit-user-select:none;z-index:3;padding:0;box-shadow:0 4px 12px rgba(0,0,0,.4);
  -webkit-tap-highlight-color:transparent;cursor:pointer;width:84px;height:84px;right:14px;bottom:18px}
.cf-btn small{font-size:10px;font-weight:600;opacity:.75;line-height:1}
.cf-btn.cd{opacity:.5}
.cf-btn.on{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}
.cf-btn.hot{border-color:#ffd27a;animation:cfp .6s ease-in-out infinite}
@keyframes cfp{50%{box-shadow:0 0 0 8px rgba(255,210,122,.45),0 4px 12px rgba(0,0,0,.4)}}
`;
  const THEME = {
    park: { out: '#1f3524', g0: '#4f8a3e', g1: '#4a8239', line: '#f4efe0', wall: '#8b6b4a', wallTop: '#a88560' },
    river: { out: '#1c3324', g0: '#5a8f42', g1: '#548a3d', line: '#f4efe0', wall: '#7c7f86', wallTop: '#9ea2aa' },
    maze: { out: '#1a2e1e', g0: '#6a9a4c', g1: '#639346', line: '#fbf6ea', wall: '#2f6131', wallTop: '#3f7d3f' },
    pads: { out: '#2b2236', g0: '#c79a62', g1: '#be915a', line: '#ffffff', wall: '#3f6fb0', wallTop: '#5a8ad0' },
    mine: { out: '#231b17', g0: '#8a6a4c', g1: '#826247', line: '#f6e7c8', wall: '#5b4a3e', wallTop: '#776251' },
    night: { out: '#0d1418', g0: '#355a3c', g1: '#315437', line: '#e8e2c8', wall: '#6e5a3e', wallTop: '#8c7450' },
    ice: { out: '#16202e', g0: '#d9e8f3', g1: '#d1e2ef', line: '#d2453c', wall: '#f5f9fc', wallTop: '#ffffff' },
  };

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (s) => api.players[s] || { name: '봇', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !st || s >= st.np || !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { if (!st || s >= st.np) return 2; const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    let st = null, key = null, W = null, phase = 'wait', cd = 0, endT = 0, lay = null, flip = false, shake = 0, tipT = 0, startT = 0;
    let bgCv = null, bgKey = '', mmCv = null, mmKey = '', nightCv = null;
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const ctrlOn = () => me() >= 0 && !auto();
    const myTeam = () => { const m = me(); return m >= 0 && st ? st.tm[m] : 0; };
    const curKey = () => (st ? st.rid + '.' + st.rd : null);
    const cam = { x: 0, y: 0, init: false };

    /* ----- round start ----- */
    let aiMem = [], vis = [], parts = [], rings = [], floats = [], conf = [];
    function startRound() {
      key = curKey();
      W = newWorld(st);
      aiMem = W.pl.map(() => ({}));
      vis = W.pl.map((p) => ({ x: p.x, y: p.y, a: p.a, bob: Math.random() * 6, hitT: 0, fly: 0 }));
      parts = []; rings = []; floats = []; snaps = []; lastFx = 0; lastQ = -1; for (const k in remIn) delete remIn[k];
      locIn.ev = null; netA.n = 0; banner = null; cam.init = false;
      phase = st.ph === 'play' ? 'play' : st.ph === 'count' ? 'count' : 'end';
      let seen = 0; try { seen = +localStorage.getItem('lounge.ctf.tips') || 0; } catch (e) {}
      const first = st.rd === 1 && ctrlOn() && seen < 3;
      if (first) try { localStorage.setItem('lounge.ctf.tips', String(seen + 1)); } catch (e) {}
      cd = first ? FIRST_T : COUNT_T; endT = END_T;
      tipT = first ? FIRST_T + 0.4 : 0;
      layout();
    }

    /* ----- layout: follow camera when I play, whole field when watching ----- */
    function layout() {
      if (!W) return;
      const w = cv.w, h = cv.h, visH = Math.max(160, h - TOPH);
      let s;
      if (ctrlOn()) s = clamp(Math.min(w / 16, visH / 24), 12, 30);
      else s = Math.max(4, Math.min((w - 8) / (2 * FW + 1.4), (visH - 8) / (2 * FH + 1.4)));
      lay = { s, visH, M: 1.2 };
      flip = myTeam() === 1;
      buildBg();
      showBtns();
    }
    cv.onresize = layout;
    const VX = (x) => (flip ? -x : x), VY = (y) => (flip ? -y : y);
    const SX = (x) => cv.w / 2 + (VX(x) - cam.x) * lay.s;
    const SY = (y) => TOPH + lay.visH / 2 + (VY(y) - cam.y) * lay.s;
    function camTarget() {
      const s = lay.s, hw = cv.w / 2 / s, hh = lay.visH / 2 / s, M = lay.M;
      let tx = 0, ty = 0;
      const m = me();
      if (ctrlOn() && m >= 0 && vis[m]) { tx = VX(vis[m].x); ty = VY(vis[m].y) - hh * 0.14; }
      tx = hw >= FW + M ? 0 : clamp(tx, -FW - M + hw, FW + M - hw);
      ty = hh >= FH + M ? 0 : clamp(ty, -FH - M + hh, FH + M - hh);
      return [tx, ty];
    }

    /* ----- static layer: field, halves, lines, walls, water, pads, stands (world space, unflipped) ----- */
    function buildBg() {
      if (!lay || !W) return;
      const dpr = Math.min(2, cv.dpr), k = st.mk + '|' + lay.s + '|' + dpr;
      if (k === bgKey && bgCv) return;
      bgKey = k;
      const s = lay.s, M = lay.M, ww = 2 * (FW + M), wh = 2 * (FH + M);
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(ww * s * dpr)); c.height = Math.max(1, Math.round(wh * s * dpr));
      const g = c.getContext('2d');
      g.setTransform(s * dpr, 0, 0, s * dpr, (FW + M) * s * dpr, (FH + M) * s * dpr);
      const id = W.mp.id, TH = THEME[id] || THEME.park, G = W.G;
      let seed = 7 + st.mk * 31; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      g.fillStyle = TH.out; g.fillRect(-FW - M, -FH - M, ww, wh);
      for (let i = 0; i < 140; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(0,0,0,.18)' : 'rgba(255,255,255,.05)'; g.beginPath(); g.arc(-FW - M + rnd() * ww, -FH - M + rnd() * wh, 0.1 + rnd() * 0.3, 0, 7); g.fill(); }
      // fence around
      g.fillStyle = id === 'ice' ? '#9fb6c9' : '#6b4a33'; rrc(g, -FW - 0.35, -FH - 0.35, 2 * FW + 0.7, 2 * FH + 0.7, 0.4); g.fill();
      // ground
      g.save(); g.beginPath(); g.rect(-FW, -FH, 2 * FW, 2 * FH); g.clip();
      for (let y = -FH, i = 0; y < FH; y += 1.5, i++) { g.fillStyle = i % 2 ? TH.g0 : TH.g1; g.fillRect(-FW, y, 2 * FW, 1.5); }
      for (let i = 0; i < 900; i++) {
        const x = -FW + rnd() * 2 * FW, y = -FH + rnd() * 2 * FH;
        if (id === 'ice') { g.fillStyle = rnd() < 0.5 ? 'rgba(120,160,200,.18)' : 'rgba(255,255,255,.8)'; g.fillRect(x, y, 0.08, 0.08); }
        else if (id === 'pads' || id === 'mine') { g.fillStyle = rnd() < 0.5 ? 'rgba(60,40,20,.18)' : 'rgba(255,240,210,.14)'; g.fillRect(x, y, 0.09, 0.09); }
        else { g.strokeStyle = rnd() < 0.5 ? 'rgba(20,50,20,.25)' : 'rgba(200,240,160,.18)'; g.lineWidth = 0.05; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (rnd() - 0.5) * 0.15, y - 0.22); g.stroke(); }
      }
      if (id === 'ice') { g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 0.05; for (let i = 0; i < 26; i++) { const x = -FW + rnd() * 2 * FW, y = -FH + rnd() * 2 * FH; g.beginPath(); g.moveTo(x, y); g.lineTo(x + 1.5 + rnd() * 2, y - 0.5 + rnd()); g.stroke(); } }
      // half tints
      for (let t = 0; t < 2; t++) { g.globalAlpha = 0.13; g.fillStyle = TC[t]; g.fillRect(-FW, t ? -FH : 0, 2 * FW, FH); g.globalAlpha = 1; }
      // carts' rails
      for (const m of G.M) { g.fillStyle = 'rgba(40,28,20,.55)'; g.fillRect(-m.A - m.hw - 0.3, m.y - m.hh - 0.1, 2 * (m.A + m.hw + 0.3), 2 * m.hh + 0.2); g.strokeStyle = '#b8a48a'; g.lineWidth = 0.1; g.beginPath(); g.moveTo(-m.A - m.hw - 0.3, m.y - m.hh * 0.6); g.lineTo(m.A + m.hw + 0.3, m.y - m.hh * 0.6); g.moveTo(-m.A - m.hw - 0.3, m.y + m.hh * 0.6); g.lineTo(m.A + m.hw + 0.3, m.y + m.hh * 0.6); g.stroke(); g.strokeStyle = 'rgba(90,60,40,.9)'; g.lineWidth = 0.18; for (let x = -m.A - m.hw; x <= m.A + m.hw; x += 0.8) { g.beginPath(); g.moveTo(x, m.y - m.hh); g.lineTo(x, m.y + m.hh); g.stroke(); } }
      // pads
      for (const r of G.P) {
        g.fillStyle = '#e3ae45'; rrc(g, r[0], r[1], r[2] - r[0], r[3] - r[1], 0.25); g.fill();
        g.strokeStyle = '#7a5410'; g.lineWidth = 0.1; g.stroke();
        g.fillStyle = 'rgba(122,84,16,.7)';
        const cx = (r[0] + r[2]) / 2, cy = (r[1] + r[3]) / 2, vert = r[3] - r[1] > r[2] - r[0];
        for (let k2 = -1; k2 <= 1; k2++) { g.beginPath(); if (vert) { const y = cy + k2 * 0.9; g.moveTo(cx - 0.45, y + 0.25); g.lineTo(cx, y - 0.25); g.lineTo(cx + 0.45, y + 0.25); } else { const x = cx + k2 * 0.9; g.moveTo(x - 0.25, cy - 0.45); g.lineTo(x + 0.25, cy); g.lineTo(x - 0.25, cy + 0.45); } g.lineWidth = 0.16; g.strokeStyle = 'rgba(122,84,16,.8)'; g.stroke(); }
      }
      // water
      for (const r of G.R) {
        if (r[4] !== 1) continue;
        const gr = g.createLinearGradient(r[0], r[1], r[0], r[3]);
        if (id === 'ice') { gr.addColorStop(0, '#2a5d86'); gr.addColorStop(1, '#173f62'); } else { gr.addColorStop(0, '#2f7fb0'); gr.addColorStop(1, '#1f5f8c'); }
        g.fillStyle = gr; rrc(g, r[0], r[1], r[2] - r[0], r[3] - r[1], id === 'ice' ? 0.6 : 0.15); g.fill();
        g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 0.06;
        for (let i = 0; i < 6; i++) { const x = r[0] + rnd() * (r[2] - r[0]), y = r[1] + rnd() * (r[3] - r[1]); g.beginPath(); g.moveTo(x - 0.4, y); g.quadraticCurveTo(x, y - 0.18, x + 0.4, y); g.stroke(); }
      }
      if (id === 'river') { g.fillStyle = '#8a6a45'; for (const x of [-7.5, 0, 7.5]) { const hw = x ? 1.3 : 1.2; g.fillRect(x - hw, -1.5, 2 * hw, 3); g.strokeStyle = 'rgba(60,40,20,.6)'; g.lineWidth = 0.06; for (let y = -1.4; y < 1.5; y += 0.4) { g.beginPath(); g.moveTo(x - hw, y); g.lineTo(x + hw, y); g.stroke(); } g.fillStyle = '#8a6a45'; } }
      // centre line
      g.strokeStyle = TH.line; g.lineWidth = 0.16; g.setLineDash([0.6, 0.35]); g.beginPath(); g.moveTo(-FW, 0); g.lineTo(FW, 0); g.stroke(); g.setLineDash([]);
      // stands & jails (guard zones)
      for (let t = 0; t < 2; t++) {
        const b = BASE[t], j = JAIL[t];
        g.fillStyle = hexA(TC[t], 0.16); g.beginPath(); g.arc(b[0], b[1], FZ, 0, 7); g.fill();
        g.strokeStyle = hexA(TC[t], 0.85); g.lineWidth = 0.1; g.setLineDash([0.4, 0.3]); g.beginPath(); g.arc(b[0], b[1], FZ, 0, 7); g.stroke();
        g.beginPath(); g.arc(j[0], j[1], JZ, 0, 7); g.stroke(); g.setLineDash([]);
        g.fillStyle = 'rgba(40,30,30,.55)'; g.beginPath(); g.arc(j[0], j[1], JR, 0, 7); g.fill();
        g.fillStyle = '#5a4636'; g.beginPath(); g.arc(b[0], b[1], 0.75, 0, 7); g.fill(); g.fillStyle = '#7a604a'; g.beginPath(); g.arc(b[0], b[1], 0.55, 0, 7); g.fill();
      }
      g.restore();
      // walls (raised blocks)
      for (const r of G.R) {
        if (r[4] !== 0) continue;
        g.fillStyle = 'rgba(0,0,0,.28)'; rrc(g, r[0] + 0.12, r[1] + 0.2, r[2] - r[0], r[3] - r[1], 0.2); g.fill();
        g.fillStyle = TH.wall; rrc(g, r[0], r[1], r[2] - r[0], r[3] - r[1], 0.2); g.fill();
        g.fillStyle = TH.wallTop; rrc(g, r[0] + 0.06, r[1] + 0.04, r[2] - r[0] - 0.12, (r[3] - r[1]) * 0.6, 0.16); g.fill();
        if (id === 'maze') { g.fillStyle = 'rgba(140,200,110,.35)'; for (let i = 0; i < (r[2] - r[0]) * (r[3] - r[1]) * 6; i++) { g.beginPath(); g.arc(r[0] + rnd() * (r[2] - r[0]), r[1] + rnd() * (r[3] - r[1]), 0.1, 0, 7); g.fill(); } }
      }
      bgCv = c; bgCv._dpr = dpr;
      buildMini();
    }
    function buildMini() {
      const mw = 50, mh = Math.round(mw * FH / FW), dpr = cv.dpr, k = st.mk + '|' + flip + '|' + dpr;
      if (k === mmKey && mmCv) return;
      mmKey = k;
      const c = document.createElement('canvas'); c.width = Math.round(mw * dpr); c.height = Math.round(mh * dpr);
      const g = c.getContext('2d'), sc = mw / (2 * FW);
      g.setTransform(sc * dpr, 0, 0, sc * dpr, mw / 2 * dpr, mh / 2 * dpr);
      if (flip) g.rotate(Math.PI);
      for (let t = 0; t < 2; t++) { g.fillStyle = shade(TC[t], -0.45); g.fillRect(-FW, t ? -FH : 0, 2 * FW, FH); }
      for (const r of W.G.R) { g.fillStyle = r[4] ? '#2f7fb0' : '#d8cbb0'; g.fillRect(r[0], r[1], r[2] - r[0], r[3] - r[1]); }
      for (const b of W.G.B) { g.fillStyle = 'rgba(40,110,50,.9)'; g.beginPath(); g.arc(b[0], b[1], b[2], 0, 7); g.fill(); }
      g.strokeStyle = '#f2e9d8'; g.lineWidth = 0.4; g.beginPath(); g.moveTo(-FW, 0); g.lineTo(FW, 0); g.stroke();
      for (let t = 0; t < 2; t++) { g.strokeStyle = TC[t]; g.lineWidth = 0.5; g.beginPath(); g.arc(JAIL[t][0], JAIL[t][1], JR, 0, 7); g.stroke(); }
      mmCv = c;
    }

    /* ----- input: floating stick + dash button; keys/pad via api.input ----- */
    const locIn = { ax: 0, ay: 0, ev: null, spd: 1 };
    let stick = null;
    const netA = { n: 0, e: null };
    function stickVec() {
      let sx = 0, sy = 0;
      if (stick) {
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy);
        if (d > 5) { const m = Math.min(1, d / STICK_R); sx = dx / d * m; sy = dy / d * m; }
      }
      if (api.input && !sx && !sy) {
        const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down');
        if (kx || ky) { const m = hyp(kx, ky); sx = m > 1 ? kx / m : kx; sy = m > 1 ? ky / m : ky; }
      }
      return { x: flip ? -sx : sx, y: flip ? -sy : sy };
    }
    function readMove() { const v = stickVec(); locIn.ax = v.x; locIn.ay = v.y; }
    function myP() { const m = me(); return W && m >= 0 ? W.pl[m] : null; }
    function dashDown() {
      const p = myP(); if (!p || phase !== 'play' || p.jl || p.dcd > 0) return false;
      const v = stickVec();
      const ev = ['d', r2(v.x), r2(v.y)];
      if (host()) locIn.ev = ev;
      else {
        netA.n = (netA.n + 1) % 1000; netA.e = ev; pubT = 0; inT = 0;
        let dx = v.x, dy = v.y, l = hyp(dx, dy); if (l < 0.2) { dx = Math.cos(p.a); dy = Math.sin(p.a); l = 1; }
        p.dash = DASH_T; p.dx = dx / l; p.dy = dy / l; p.dcd = DASH_CD;
      }
      api.buzz(12); sfx('whoosh', 80);
      return true;
    }
    function onDown(e) {
      if (!ctrlOn() || !lay) return;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      const pt = cv.local(e);
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      if (stick) return;
      stick = { id: e.pointerId, bx: pt.x, by: pt.y, x: pt.x, y: pt.y };
      tipT = Math.min(tipT, 0.6);
    }
    function onMove(e) {
      if (!stick || e.pointerId !== stick.id) return;
      const pt = cv.local(e); stick.x = pt.x; stick.y = pt.y;
      const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), mx = STICK_R * 1.25;
      if (d > mx) { stick.bx = stick.x - dx / d * mx; stick.by = stick.y - dy / d * mx; }
    }
    function onUp(e) { if (stick && e.pointerId === stick.id) stick = null; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    const dashLb = L.h('span', { text: '대시' }), dashSm = L.h('small', { text: '휙!' });
    const dashBtn = L.h('button', { class: 'cf-btn', type: 'button', 'aria-label': '대시' }, dashLb, dashSm);
    dashBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); dashBtn.classList.add('on'); dashDown(); setTimeout(() => dashBtn.classList.remove('on'), 140); });
    dashBtn.addEventListener('contextmenu', noCtx);
    root.appendChild(dashBtn);
    function showBtns() { dashBtn.style.display = ctrlOn() ? '' : 'none'; }
    let btnSig = '';
    function syncBtns() {
      const v = ctrlOn(); if ((dashBtn.style.display !== 'none') !== v) showBtns();
      const p = myP(); if (!p || !v) return;
      const cdS = p.dcd > 0 ? Math.ceil(p.dcd) : 0, th = phase === 'play' && !p.jl && side(p.y) !== p.t && dangerNear(p) < 2.2;
      const sig = [cdS, p.jl, phase, th].join('|');
      if (sig === btnSig) return;
      btnSig = sig;
      dashSm.textContent = p.jl ? '감옥' : cdS ? cdS + '초' : '휙!';
      dashBtn.classList.toggle('cd', !!(cdS || p.jl || phase !== 'play'));
      dashBtn.classList.toggle('hot', !!th && !cdS);
    }
    function dangerNear(p) { let bd = 99; for (const q of W.pl) { if (q.t === p.t || !free(q) || side(q.y) !== q.t || !visibleTo(W, p.t, q)) continue; bd = Math.min(bd, hyp(q.x - p.x, q.y - p.y)); } return bd; }
    const offIn = api.input ? api.input.on((type, id) => {
      if (!ctrlOn()) return;
      if (id === 'dash' && type === 'down') { dashBtn.classList.add('on'); dashDown(); setTimeout(() => dashBtn.classList.remove('on'), 140); }
    }) : null;
    const releaseAll = () => { stick = null; };
    window.addEventListener('blur', releaseAll);

    /* ----- effects ----- */
    let lastSfx = {};
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function puff(x, y, n, sp, col, life) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.283, v = sp * (0.3 + Math.random());
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, life: (life || 0.5) * (0.6 + Math.random() * 0.6), c: col || '#ffffff', r: 0.08 + Math.random() * 0.1 });
      }
      if (parts.length > 160) parts.splice(0, parts.length - 160);
    }
    function addFloat(x, y, txt, c) { floats.push({ x, y, t: 0, life: 1.2, txt, c }); if (floats.length > 10) floats.shift(); }
    function onFx(code, a, b, c, d) {
      const m = me(), mt = myTeam(), pl = W ? W.pl : [];
      const tOf = (i) => (pl[i] ? pl[i].t : 0);
      switch (code) {
        case 0: {   // tag
          sfx('hit', 40); setTimeout(() => sfx('thud', 0), 70);
          rings.push({ x: a, y: b, t: 0, life: 0.45, r0: 0.3, r1: 2.2, c: '#ffffff' });
          puff(a, b, 10, 4, '#fff3cf');
          addFloat(a, b, c === m ? '잡혔다! 감옥으로' : '잡았다!', c === m ? '#bfe3ff' : '#ffd27a');
          if (c === m) { api.buzz(90); shake = Math.max(shake, 0.8); } else if (d === m) { api.buzz(30); shake = Math.max(shake, 0.3); }
          if (vis[c]) { vis[c].hitT = 1; vis[c].fly = 1; }
          break;
        }
        case 1: sfx('pop', 40); rings.push({ x: a, y: b, t: 0, life: 0.5, r0: 0.5, r1: 2.4, c: '#7fe3ff' }); addFloat(a, b, '방패가 막았다!', '#7fe3ff'); if (c === m) api.buzz(40); break;
        case 2: sfx('chip', 40); rings.push({ x: a, y: b, t: 0, life: 0.6, r0: 0.4, r1: 2.6, c: TC[d] }); addFloat(a, b, c === m ? '깃발 획득! 우리 진영으로!' : tOf(c) === mt ? '깃발 뺏었다!' : '깃발 뺏겼다!', tOf(c) === mt ? '#ffd27a' : '#ee6a55'); if (c === m) api.buzz(40); else if (ctrlOn() && tOf(c) !== mt) api.buzz(20); break;
        case 3: sfx('pop', 60); if (d >= 0) addFloat(a, b, '깃발 되찾음', '#f2e9d8'); else addFloat(a, b, '깃발 제자리로', '#f2e9d8'); break;
        case 4: sfx('thud', 60); addFloat(a, b, '깃발 떨어짐', '#f2e9d8'); break;
        case 5: sfx('pop', 40); setTimeout(() => sfx('chip', 0), 90); rings.push({ x: a, y: b, t: 0, life: 0.7, r0: 0.6, r1: 3.2, c: '#7cdc8a' }); puff(a, b, 14, 4, '#c9ffd2'); addFloat(a, b, '구출! ' + d + '명', '#7cdc8a'); if (c === m) api.buzz(40); break;
        case 6: if (c === m) { addFloat(a, b, '시간이 지나 풀려났어요', '#7cdc8a'); sfx('pop', 60); } break;
        case 7: sfx('win', 200); rings.push({ x: a, y: b, t: 0, life: 0.9, r0: 0.5, r1: 4, c: TC[d] }); puff(a, b, 22, 6, '#ffd27a', 0.8); if (ctrlOn()) api.buzz(d === mt ? 60 : 30); break;
        case 8: puff(a, b, 6, 2.2, 'rgba(255,255,255,.7)', 0.35); if (c !== m) sfx('whoosh', 120); break;
        case 9: sfx('tick', 80); rings.push({ x: a, y: b, t: 0, life: 0.8, r0: 0.2, r1: 1.8, c: '#ffd27a' }); break;
        case 10: sfx('pop', 50); addFloat(a, b, d ? '방패!' : '번개 신발!', d ? '#7fe3ff' : '#ffd27a'); if (c === m) api.buzz(25); break;
        case 11: sfx('whoosh'); banner = { t: '연장전!', sub: '먼저 득점하는 팀이 이겨요', c: '#ee6a55', life: 2.4, max: 2.4 }; api.buzz(40); break;
      }
    }
    const hooks = { fx: onFx };
    let banner = null;

    /* ----- host flow ----- */
    const remIn = {};
    function inputsFor() {
      const out = [];
      for (let s = 0; s < W.pl.length; s++) {
        const ai = isAIseat(s); W.bot[s] = ai ? 1 : 0;
        if (ai) out[s] = aiThink(W, W.pl[s], aiMem[s], lvOf(s), curDt);
        else if (localHuman(s)) out[s] = locIn;
        else out[s] = remIn[s] || (remIn[s] = { ax: 0, ay: 0, ev: null, spd: 1, seen: -1 });
      }
      return out;
    }
    let curDt = 0;
    function hostFlow(dt) {
      if (!host() || !st || !W) return;
      if (st.ph === 'count' && phase === 'play') { api.setState(Object.assign({}, st, { ph: 'play' })); return; }
      if (st.ph === 'play' && phase === 'play' && W.res && W.endT >= LAST_T && !W.res.sent) { W.res.sent = 1; api.setState(roundOver(st, W.res, W.t, W.tgs, W.rss)); return; }
      if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextRound(st)); } }
    }

    /* ----- online ----- */
    let pubT = 0, hsQ = 0, inQ = 0, lastQ = -1, lastFx = 0, snaps = [], lastSig = '', inT = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.np) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remIn[s] || (remIn[s] = { ax: 0, ay: 0, ev: null, spd: 1, seen: -1 });
        R.ax = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0; R.ay = fin(+o.ay) ? clamp(+o.ay, -1, 1) : 0;
        const n = o.n | 0;
        if (R.seen >= 0 && n !== R.seen && Array.isArray(o.e) && o.e[0] === 'd') R.ev = o.e.slice(0, 3);
        R.seen = n;
      }
    }
    function encode() {
      const Pp = [];
      for (const p of W.pl) {
        const fl = (p.jl ? 1 : 0) | (p.fw ? 2 : 0) | (p.dash > 0 ? 4 : 0) | (p.sh > 0 ? 8 : 0) | (p.bo > 0 ? 16 : 0) | (p.dcd > 0 ? 32 : 0) | (p.imm > 0 ? 64 : 0) | (p.pd > 0 ? 128 : 0);
        Pp.push(r1(p.x), r1(p.y), r1(p.vx), r1(p.vy), fl, Math.floor(p.jT));
      }
      const F = []; for (const f of W.fg) F.push(r1(f.x), r1(f.y), f.h, f.at, Math.ceil(f.rT));
      return { k: key, q: hsQ, t: r2(W.t), ot: W.ot, P: Pp, F, I: W.it ? [W.it.k, W.it.x, W.it.y] : 0, fx: W.fx.slice(-10) };
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.P)) return;
      lastQ = hs.q;
      if (fin(hs.t)) W.t = hs.t;
      W.ot = hs.ot ? 1 : 0;
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; try { onFx(e[1], +e[2] || 0, +e[3] || 0, e[4] | 0, e[5] | 0); } catch (er) {} }
      const m = me();
      W.pl.forEach((p, i) => {
        const o = i * 6, A = hs.P;
        if (!fin(+A[o]) || !fin(+A[o + 1])) return;
        const fl = A[o + 4] | 0;
        const wasJ = p.jl; p.jl = fl & 1 ? 1 : 0; p.fw = fl & 2 ? 1 : 0;
        p.sh = fl & 8 ? 1 : 0; p.bo = fl & 16 ? 1 : 0; p.imm = fl & 64 ? 0.1 : 0; p.jT = A[o + 5] | 0;
        p.nx = +A[o]; p.ny = +A[o + 1]; p.nvx = +A[o + 2] || 0; p.nvy = +A[o + 3] || 0; p.nat = now;
        if (wasJ !== p.jl) { p.x = p.nx; p.y = p.ny; }
        if (i !== m || auto()) { p.dash = fl & 4 ? 0.05 : 0; p.pd = fl & 128 ? 0.1 : 0; }
        p.dcd = fl & 32 ? Math.max(p.dcd, 0.05) : 0;
      });
      if (Array.isArray(hs.F)) for (let t = 0; t < 2; t++) { const f = W.fg[t], o = t * 5; f.x = +hs.F[o] || 0; f.y = +hs.F[o + 1] || 0; f.h = hs.F[o + 2] | 0; f.at = hs.F[o + 3] | 0; f.rT = +hs.F[o + 4] || 0; }
      W.it = Array.isArray(hs.I) ? { k: hs.I[0] | 0, x: +hs.I[1] || 0, y: +hs.I[2] || 0 } : null;
      snaps.push({ at: now, P: hs.P }); if (snaps.length > 5) snaps.shift();
    }
    function guestStep(dt, rdt, now) {
      const m = auto() ? -1 : me();
      if (phase === 'play') W.t += dt;
      moversAt(W);
      const rt = now - 100;
      let A = null, Bs = snaps.length ? snaps[snaps.length - 1] : null, k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; Bs = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, Bs.at - A.at), 0, 1.3);
      W.pl.forEach((p, i) => {
        if (!Bs) return;
        const o = i * 6;
        if (i === m && phase === 'play' && !p.jl) {
          readMove();
          const n = Math.max(1, Math.ceil(dt / SUB)), h = dt / n;
          for (let j = 0; j < n; j++) movePlayer(W, p, locIn, h);
          if (fin(p.nx)) {
            const age = Math.min(0.15, (now - p.nat) / 1000);
            const tx = p.nx + p.nvx * age, ty = p.ny + p.nvy * age, d = hyp(tx - p.x, ty - p.y);
            if (d > 3) { p.x = tx; p.y = ty; } else { const kk = 1 - Math.exp(-rdt * 5); p.x += (tx - p.x) * kk; p.y += (ty - p.y) * kk; }
          }
          return;
        }
        const b = Bs.P, a = A ? A.P : null;
        const bx = +b[o], by = +b[o + 1];
        if (a && hyp(bx - a[o], by - a[o + 1]) < 4) { p.x = a[o] + (bx - a[o]) * k; p.y = a[o + 1] + (by - a[o + 1]) * k; }
        else { p.x = bx; p.y = by; }
        p.vx = p.nvx || 0; p.vy = p.nvy || 0;
        if (hyp(p.vx, p.vy) > 0.6) p.a = Math.atan2(p.vy, p.vx);
      });
      for (const f of W.fg) if (f.h >= 0 && W.pl[f.h]) { f.x = W.pl[f.h].x; f.y = W.pl[f.h].y; }
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(encode());
        } else {
          const m = me(); if (m < 0) return;
          readMove();
          const sig = [r2(locIn.ax), r2(locIn.ay), netA.n].join('|');
          if (sig === lastSig && inT > 0) return;
          if (pubT > 0 && sig !== lastSig && inT > 0.1) return;
          lastSig = sig; inT = 0.2; pubT = 1 / 30;
          inQ = (inQ + 1) % 100000;
          api.net.publish({ k: key, q: inQ, ax: r2(locIn.ax), ay: r2(locIn.ay), n: netA.n, e: netA.e });
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      if (curKey() !== key) startRound();
      if (!W) return;
      const dt = rdt * SPD();
      curDt = dt;
      if (phase === 'count') {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0 && b <= 3) sfx('tick', 40);
        if (cd <= 0 && (host() || st.ph === 'play')) { phase = 'play'; sfx('pop'); api.buzz(16); startT = 0.9; }
      }
      if (phase === 'play' && (st.ph === 'end' || st.ph === 'done')) phase = 'end';
      if (tipT > 0) tipT -= rdt;
      if (startT > 0) startT -= rdt;
      readMove();
      if (host()) {
        pollHost();
        if (phase === 'play' && (!W.res || W.endT < LAST_T)) tickWorld(W, Math.min(dt, 0.1), inputsFor(), hooks);
        else if (phase !== 'play') for (const q of W.pl) { q.vx *= 0.85; q.vy *= 0.85; }
        hostFlow(dt);
      } else {
        pollGuest(now);
        guestStep(Math.min(dt, 0.1), rdt, now);
        if (st.ph === 'end') phase = 'end';
      }
      W.pl.forEach((q, i) => {
        const v = vis[i]; if (!v) return;
        const d = hyp(q.x - v.x, q.y - v.y);
        if (d > 2.5 || v.fly) { const kk = Math.min(1, rdt * 6); v.x += (q.x - v.x) * kk; v.y += (q.y - v.y) * kk; v.fly = hyp(q.x - v.x, q.y - v.y) > 0.3 ? 1 : 0; }
        else { v.x = q.x; v.y = q.y; }
        let da = q.a - v.a; while (da > Math.PI) da -= 6.283; while (da < -Math.PI) da += 6.283; v.a += da * Math.min(1, rdt * 12);
        if (v.hitT > 0) v.hitT -= rdt * 1.4;
        if (q.dash > 0 && Math.random() < rdt * 30) puff(q.x, q.y, 1, 1.2, 'rgba(255,255,255,.7)', 0.3);
      });
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t += rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.vx *= 0.92; q.vy *= 0.92; if (q.t > q.life) parts.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t += rdt; if (rings[i].t > rings[i].life) rings.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t += rdt; if (floats[i].t > floats[i].life) floats.splice(i, 1); }
      for (let i = conf.length - 1; i >= 0; i--) { const c = conf[i]; c.t += rdt; c.x += c.vx * rdt; c.y += c.vy * rdt; c.vy += 420 * rdt; c.rot += c.vr * rdt; if (c.t > c.life) conf.splice(i, 1); }
      if (banner) { banner.life -= rdt; if (banner.life <= 0) banner = null; }
      shake = Math.max(0, shake - rdt * 2.6);
      publish(rdt);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, al, stroke) {
      ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle';
      if (stroke) { ctx.lineWidth = stroke; ctx.strokeStyle = 'rgba(16,12,22,.85)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y); }
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function drawFlagAt(x, y, t, u, now, onBack) {
      const wv = Math.sin(now / 160 + t) * 0.12;
      const px = x + (onBack ? -u * 0.35 : 0), py = y - (onBack ? u * 0.2 : 0), ph = u * (onBack ? 1.6 : 1.9);
      ctx.strokeStyle = '#d8cbb0'; ctx.lineWidth = Math.max(1.5, u * 0.09); ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px, py - ph); ctx.stroke();
      ctx.fillStyle = TC[t];
      ctx.beginPath(); ctx.moveTo(px, py - ph); ctx.quadraticCurveTo(px + u * 0.6, py - ph + u * (0.1 + wv), px + u * 1.15, py - ph + u * 0.35);
      ctx.quadraticCurveTo(px + u * 0.6, py - ph + u * (0.55 - wv), px, py - ph + u * 0.7); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = shade(TC[t], -0.4); ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#fff3cf'; ctx.beginPath(); ctx.arc(px + u * 0.42, py - ph + u * 0.35, u * 0.12, 0, 7); ctx.fill();
    }
    function drawPlayer(p, now, mt) {
      const s = lay.s, v = vis[p.i], x = SX(v.x), y = SY(v.y), u = s * PR * 1.9, col = TC[p.t], dk = TCD[p.t];
      const mine = p.i === me() && !auto();
      ctx.save();
      if (p.fw || v.fly) ctx.globalAlpha = 0.55;
      ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(x, y + u * 0.18, u * 0.55, u * 0.3, 0, 0, 7); ctx.fill();
      if (mine) { ctx.strokeStyle = side(p.y) !== p.t && !p.jl && !p.fw ? '#ff8a73' : '#e3ae45'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.ellipse(x, y + u * 0.18, u * 0.75, u * 0.4, 0, 0, 7); ctx.stroke(); }
      const F = carrying(W, p);
      if (F) {   // carrier glow
        const pr = 0.5 + 0.5 * Math.sin(now / 120);
        ctx.strokeStyle = hexA(TC[F.t], 0.6 + 0.4 * pr); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y - u * 0.25, u * (0.85 + pr * 0.15), 0, 7); ctx.stroke();
        drawFlagAt(x, y - u * 0.1, F.t, u * 0.85, now, true);
      }
      const fa = (flip ? v.a + Math.PI : v.a), fx = Math.cos(fa), fy = Math.sin(fa);
      const mv = hyp(p.vx, p.vy) > 0.8, step = mv ? Math.sin(now / 70 + v.bob) * u * 0.12 : 0;
      // feet
      ctx.fillStyle = '#2b2430';
      ctx.beginPath(); ctx.ellipse(x - u * 0.2 - fy * step, y + u * 0.05 + fx * step, u * 0.14, u * 0.11, 0, 0, 7); ctx.ellipse(x + u * 0.2 + fy * step, y + u * 0.05 - fx * step, u * 0.14, u * 0.11, 0, 0, 7); ctx.fill();
      // body
      const by = y - u * 0.32, bw = u * 0.42;
      const g = ctx.createRadialGradient(x - bw * 0.4, by - bw * 0.4, bw * 0.1, x, by, bw * 1.1);
      g.addColorStop(0, shade(col, 0.3)); g.addColorStop(1, shade(col, -0.25));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, by, bw, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(12,9,18,.5)'; ctx.lineWidth = 1; ctx.stroke();
      // head
      const hr = u * 0.3, hx = x + fx * u * 0.05, hy = by - u * 0.38;
      ctx.fillStyle = '#f1d3b3'; ctx.beginPath(); ctx.arc(hx, hy, hr, 0, 7); ctx.fill();
      ctx.fillStyle = dk; ctx.beginPath(); ctx.arc(hx, hy - hr * 0.12, hr * 1.04, Math.PI * 1.02, Math.PI * 1.98); ctx.closePath(); ctx.fill();
      if (fy > -0.5) { ctx.fillStyle = '#2a2230'; ctx.beginPath(); ctx.arc(hx + fx * hr * 0.4 - hr * 0.3, hy + hr * 0.12, Math.max(1, hr * 0.13), 0, 7); ctx.arc(hx + fx * hr * 0.4 + hr * 0.3, hy + hr * 0.12, Math.max(1, hr * 0.13), 0, 7); ctx.fill(); }
      if (p.bo > 0) { ctx.fillStyle = '#ffd27a'; for (let k = 0; k < 2; k++) { const a = now / 90 + k * 3; ctx.beginPath(); ctx.arc(x + Math.cos(a) * u * 0.5, y + Math.sin(a) * u * 0.2, 1.8, 0, 7); ctx.fill(); } }
      if (p.sh > 0) { ctx.strokeStyle = 'rgba(127,227,255,.85)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, by - u * 0.15, u * 0.78, 0, 7); ctx.stroke(); ctx.fillStyle = 'rgba(127,227,255,.14)'; ctx.fill(); }
      if (p.fw) { ctx.globalAlpha = 0.9; ctx.setLineDash([3, 3]); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, by - u * 0.1, u * 0.72, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
      if (v.hitT > 0) { ctx.globalAlpha = v.hitT * 0.6; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, by - u * 0.1, u * 0.7, 0, 7); ctx.fill(); }
      ctx.restore();
      const top = hy - hr - 6;
      if (mine) txt('나', x, top - 4, '#e3ae45', '800 ' + Math.max(11, Math.round(u * 0.55)) + 'px ' + FONT, 'center', 3);
      else if (p.i < st.np && !P(p.i).ai && api.online) txt(name(p.i).slice(0, 4), x, top - 3, '#f2e9d8', '700 10px ' + FONT, 'center', 3);
      if (p.jl && p.t === mt) txt(String(Math.max(1, JAIL_MAX - Math.floor(p.jT))), x + u * 0.6, top + 2, '#bfe3ff', '700 10px ' + MONO, 'center', 3);
    }
    function drawJail(t, now) {   // fence of team t's jail
      const j = JAIL[t], s = lay.s, x = SX(j[0]), y = SY(j[1]), R = JR * s;
      ctx.strokeStyle = shade(TC[t], -0.2); ctx.lineWidth = Math.max(2, s * 0.12);
      ctx.beginPath(); ctx.ellipse(x, y, R, R, 0, 0, 7); ctx.stroke();
      ctx.fillStyle = '#3a2e2a';
      for (let k = 0; k < 12; k++) { const a = k / 12 * 6.283; ctx.beginPath(); ctx.arc(x + Math.cos(a) * R, y + Math.sin(a) * R, Math.max(1.6, s * 0.11), 0, 7); ctx.fill(); }
      let n = 0; for (const q of W.pl) if (q.t !== t && q.jl) n++;
      if (n && ctrlOn() && myTeam() !== t) { const pr = 0.5 + 0.5 * Math.sin(now / 150); ctx.strokeStyle = 'rgba(124,220,138,' + (0.4 + pr * 0.5) + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, R + 4 + pr * 4, 0, 7); ctx.stroke(); }
      txt('감옥', x, y + R + 9, 'rgba(242,233,216,.75)', '700 10px ' + FONT, 'center', 3);
    }
    function drawItem(now) {
      const it = W.it; if (!it) return;
      const x = SX(it.x), y = SY(it.y) - Math.sin(now / 250) * 3, r = lay.s * 0.5;
      ctx.save();
      ctx.shadowColor = it.k ? '#7fe3ff' : '#ffd27a'; ctx.shadowBlur = 12;
      ctx.fillStyle = it.k ? '#2b6f8c' : '#8a5a10'; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      ctx.shadowBlur = 0; ctx.strokeStyle = '#fff3cf'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = it.k ? '#bff0ff' : '#ffd27a';
      if (it.k) { ctx.beginPath(); ctx.moveTo(x, y - r * 0.6); ctx.lineTo(x + r * 0.5, y - r * 0.35); ctx.lineTo(x + r * 0.4, y + r * 0.2); ctx.lineTo(x, y + r * 0.6); ctx.lineTo(x - r * 0.4, y + r * 0.2); ctx.lineTo(x - r * 0.5, y - r * 0.35); ctx.closePath(); ctx.fill(); }
      else { ctx.beginPath(); ctx.moveTo(x + r * 0.15, y - r * 0.65); ctx.lineTo(x - r * 0.35, y + r * 0.08); ctx.lineTo(x, y + r * 0.08); ctx.lineTo(x - r * 0.15, y + r * 0.65); ctx.lineTo(x + r * 0.35, y - r * 0.08); ctx.lineTo(x, y - r * 0.08); ctx.closePath(); ctx.fill(); }
      ctx.restore();
    }
    const dl = [];
    function drawWorld(now) {
      const s = lay.s, M = lay.M, mt = ctrlOn() ? myTeam() : -1;
      ctx.save(); ctx.translate(SX(0), SY(0)); if (flip) ctx.rotate(Math.PI);
      ctx.drawImage(bgCv, -(FW + M) * s, -(FH + M) * s, 2 * (FW + M) * s, 2 * (FH + M) * s);
      ctx.restore();
      // carts
      for (const r of W.mv) {
        const x0 = Math.min(SX(r[0]), SX(r[2])), y0 = Math.min(SY(r[1]), SY(r[3])), w = Math.abs(SX(r[2]) - SX(r[0])), h = Math.abs(SY(r[3]) - SY(r[1]));
        ctx.fillStyle = 'rgba(0,0,0,.3)'; rr(ctx, x0 + 2, y0 + 4, w, h, 4); ctx.fill();
        ctx.fillStyle = '#6d5745'; rr(ctx, x0, y0, w, h, 4); ctx.fill();
        ctx.fillStyle = '#8f7963'; rr(ctx, x0 + 3, y0 + 2, w - 6, h * 0.55, 3); ctx.fill();
        ctx.fillStyle = '#3d3b40'; ctx.beginPath(); ctx.arc(x0 + w * 0.3, y0 + h * 0.45, h * 0.22, 0, 7); ctx.arc(x0 + w * 0.6, y0 + h * 0.4, h * 0.2, 0, 7); ctx.fill();
      }
      for (const r of rings) {
        const k = r.t / r.life, rad = (r.r0 + (r.r1 - r.r0) * k) * s;
        ctx.beginPath(); ctx.ellipse(SX(r.x), SY(r.y), rad, rad * 0.7, 0, 0, 7);
        ctx.strokeStyle = hexA(r.c, 0.85 * (1 - k)); ctx.lineWidth = 2.5; ctx.stroke();
      }
      drawJail(0, now); drawJail(1, now);
      // flags on stands / dropped
      for (const F of W.fg) {
        if (F.h >= 0) continue;
        const x = SX(F.x), y = SY(F.y);
        if (F.at) { ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, s * 0.9, -Math.PI / 2, -Math.PI / 2 + 6.283 * clamp(F.rT / DROP_T, 0, 1)); ctx.stroke(); }
        drawFlagAt(x, y, F.t, s * 0.95, now, false);
      }
      drawItem(now);
      // danger rings under enemies that can tag me
      const mp = myP();
      const meOut = mp && !mp.jl && !mp.fw && side(mp.y) !== mp.t;
      const list = dl; list.length = 0;
      for (const p of W.pl) {
        if (mt >= 0 && !visibleTo(W, mt, p)) continue;
        list.push({ y: VY(vis[p.i].y), p });
      }
      list.sort((a, b) => a.y - b.y);
      for (const it of list) {
        const p = it.p;
        if (meOut && p.t !== mp.t && free(p) && side(p.y) === p.t && hyp(p.x - mp.x, p.y - mp.y) < 5) {
          ctx.strokeStyle = 'rgba(238,106,85,.85)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(SX(vis[p.i].x), SY(vis[p.i].y) + s * 0.18, s * 0.85, s * 0.45, 0, 0, 7); ctx.stroke();
        }
        drawPlayer(p, now, mt);
      }
      // bushes (canopy over players)
      const mine = mp ? inBush(W.G, mp.x, mp.y) : false;
      for (const b of W.G.B) {
        const x = SX(b[0]), y = SY(b[1]), r = b[2] * s;
        const inside = mp && hyp(mp.x - b[0], mp.y - b[1]) < b[2];
        ctx.globalAlpha = inside ? 0.45 : 0.95;
        ctx.fillStyle = W.mp.id === 'ice' ? '#e8f1f7' : '#2f6a33';
        ctx.beginPath(); for (let k = 0; k < 7; k++) { const a = k / 7 * 6.283; ctx.moveTo(x + Math.cos(a) * r * 0.55 + r * 0.42, y + Math.sin(a) * r * 0.55); ctx.arc(x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.55, r * 0.42, 0, 7); } ctx.fill();
        ctx.fillStyle = W.mp.id === 'ice' ? '#ffffff' : '#418a43'; ctx.beginPath(); ctx.arc(x - r * 0.15, y - r * 0.2, r * 0.5, 0, 7); ctx.fill();
        ctx.globalAlpha = 1;
      }
      if (mine && mp) txt('숨는 중', SX(mp.x), SY(mp.y) + s * 0.9, '#bff0c0', '700 10px ' + FONT, 'center', 3);
      for (const q of parts) { const k = q.t / q.life; ctx.globalAlpha = Math.max(0, 1 - k); ctx.fillStyle = q.c; ctx.beginPath(); ctx.arc(SX(q.x), SY(q.y), Math.max(1, q.r * s), 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
    }
    function drawNight() {
      if (!W.mp.night) return;
      const w = cv.w, h = cv.h, dpr = cv.dpr;
      if (!nightCv || nightCv.width !== Math.round(w * dpr) || nightCv.height !== Math.round(h * dpr)) { nightCv = document.createElement('canvas'); nightCv.width = Math.round(w * dpr); nightCv.height = Math.round(h * dpr); }
      const g = nightCv.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, w, h);
      g.fillStyle = 'rgba(4,6,18,.86)'; g.fillRect(0, 0, w, h);
      g.globalCompositeOperation = 'destination-out';
      const hole = (x, y, R) => { const gr = g.createRadialGradient(x, y, R * 0.35, x, y, R); gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, R, 0, 7); g.fill(); };
      const mt = ctrlOn() ? myTeam() : -1, s = lay.s;
      for (const p of W.pl) if ((mt < 0 || p.t === mt) && !p.jl) hole(SX(vis[p.i].x), SY(vis[p.i].y), NIGHT_V * s);
      for (const l of lanterns()) hole(SX(l[0]), SY(l[1]), LANT_R * s);
      for (const F of W.fg) if (F.h >= 0) hole(SX(F.x), SY(F.y), 1.6 * s);
      if (W.it) hole(SX(W.it.x), SY(W.it.y), 1.2 * s);
      g.globalCompositeOperation = 'source-over';
      ctx.drawImage(nightCv, 0, 0, w, h);
      // lanterns
      for (const l of lanterns()) { ctx.fillStyle = 'rgba(255,200,110,.9)'; ctx.beginPath(); ctx.arc(SX(l[0]) + s * 1.1, SY(l[1]) - s * 0.6, Math.max(2, s * 0.14), 0, 7); ctx.fill(); }
    }
    function drawStick() {
      if (!ctrlOn()) return;
      const bx = stick ? stick.bx : 70, by = stick ? stick.by : cv.h - 74;
      ctx.save();
      ctx.globalAlpha = stick ? 0.9 : 0.5;
      ctx.beginPath(); ctx.arc(bx, by, STICK_R, 0, 7); ctx.fillStyle = 'rgba(16,12,24,.45)'; ctx.fill();
      ctx.strokeStyle = 'rgba(242,233,216,.45)'; ctx.lineWidth = 2; ctx.stroke();
      let kx = bx, ky = by;
      if (stick) { const dx = stick.x - bx, dy = stick.y - by, d = hyp(dx, dy), m = Math.min(d, STICK_R); if (d > 0) { kx = bx + dx / d * m; ky = by + dy / d * m; } }
      ctx.beginPath(); ctx.arc(kx, ky, 22, 0, 7); ctx.fillStyle = stick ? '#e3ae45' : 'rgba(242,233,216,.6)'; ctx.fill();
      if (!stick) txt('이동', kx, ky + 0.5, '#2a1d05', '700 12px ' + FONT);
      ctx.restore();
    }
    function fmt(t) { t = Math.max(0, Math.ceil(t)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); }
    function drawMini() {
      if (!ctrlOn() || !mmCv) return;
      const mw = 50, mh = Math.round(mw * FH / FW), x0 = cv.w - mw - 8, y0 = TOPH + 6, sc = mw / (2 * FW), mt = myTeam();
      ctx.save(); ctx.globalAlpha = 0.9;
      rr(ctx, x0 - 3, y0 - 3, mw + 6, mh + 6, 6); ctx.fillStyle = 'rgba(16,12,22,.75)'; ctx.fill();
      ctx.drawImage(mmCv, x0, y0, mw, mh);
      const MX = (x) => x0 + mw / 2 + VX(x) * sc, MY = (y) => y0 + mh / 2 + VY(y) * sc;
      // camera box
      const hw = cv.w / 2 / lay.s, hh = lay.visH / 2 / lay.s;
      ctx.strokeStyle = 'rgba(242,233,216,.55)'; ctx.lineWidth = 1; ctx.strokeRect(x0 + mw / 2 + (cam.x - hw) * sc, y0 + mh / 2 + (cam.y - hh) * sc, 2 * hw * sc, 2 * hh * sc);
      for (const F of W.fg) { ctx.fillStyle = TC[F.t]; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; const x = MX(F.x), y = MY(F.y); ctx.beginPath(); ctx.moveTo(x, y - 5); ctx.lineTo(x + 5, y - 2.5); ctx.lineTo(x, y); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      for (const p of W.pl) {
        if (!visibleTo(W, mt, p)) continue;
        ctx.fillStyle = TC[p.t]; ctx.beginPath(); ctx.arc(MX(p.x), MY(p.y), p.i === me() ? 2.8 : 2, 0, 7); ctx.fill();
        if (p.i === me()) { ctx.strokeStyle = '#ffd27a'; ctx.lineWidth = 1.2; ctx.stroke(); }
      }
      ctx.restore();
    }
    function drawArrows(now) {
      if (!ctrlOn()) return;
      const mt = myTeam(), p = myP(); if (!p) return;
      const marks = [];
      const E = W.fg[1 - mt], O = W.fg[mt];
      if (E.h < 0) marks.push({ x: E.x, y: E.y, c: TC[1 - mt], t: '깃발' });
      if (E.h === p.i) marks.push({ x: p.x, y: mt === 0 ? 0.8 : -0.8, c: '#ffd27a', t: '우리 진영', home: 1 });
      if (O.h >= 0 || O.at) marks.push({ x: O.x, y: O.y, c: '#ee6a55', t: O.h >= 0 ? '뺏겼다!' : '되찾기' });
      let n = 0; for (const q of W.pl) if (q.t === mt && q.jl) n++;
      if (n && !p.jl) marks.push({ x: JAIL[1 - mt][0], y: JAIL[1 - mt][1], c: '#7cdc8a', t: '구출 ' + n });
      const m = 26, top = TOPH + 34, bot = cv.h - 150;
      for (const mk of marks) {
        let x = SX(mk.x), y = SY(mk.y);
        if (mk.home) { y = SY(mk.y); x = SX(p.x); }
        if (x > m && x < cv.w - m && y > top && y < bot) continue;
        const cx = cv.w / 2, cy = (top + bot) / 2, dx = x - cx, dy = y - cy;
        const kx = dx ? (dx > 0 ? (cv.w - m - cx) / dx : (m - cx) / dx) : 1e9, ky = dy ? (dy > 0 ? (bot - cy) / dy : (top - cy) / dy) : 1e9;
        const k = Math.min(kx, ky), ax = cx + dx * k, a = Math.atan2(dy, dx);
        let ay = cy + dy * k; if (ax > cv.w - 80 && ay < TOPH + 112) ay = TOPH + 112;
        ctx.save(); ctx.translate(ax, ay);
        ctx.fillStyle = 'rgba(16,12,22,.8)'; ctx.beginPath(); ctx.arc(0, 0, 15, 0, 7); ctx.fill();
        ctx.strokeStyle = mk.c; ctx.lineWidth = 2; ctx.stroke();
        ctx.rotate(a); ctx.fillStyle = mk.c; ctx.beginPath(); ctx.moveTo(13, 0); ctx.lineTo(4, -7); ctx.lineTo(4, 7); ctx.closePath(); ctx.fill();
        ctx.restore();
        const ly = ay > cy ? ay - 22 : ay + 23;
        txt(mk.t, clamp(ax, 34, cv.w - 34), ly, mk.c, '700 10px ' + FONT, 'center', 3);
      }
    }
    function drawHud(now) {
      const w = cv.w, mt = myTeam(), y0 = 5, ch = 36, cw = Math.min(140, (w - 12 - 78) / 2);
      const teamLab = (t) => (ctrlOn() ? (t === mt ? '우리 팀' : '상대 팀') : TEAM_NM[t]);
      for (let sd = 0; sd < 2; sd++) {
        const t = sd === 0 ? mt : 1 - mt, x = sd === 0 ? 6 : w - 6 - cw;
        ctx.save();
        rr(ctx, x, y0, cw, ch, 10); ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.fill();
        ctx.strokeStyle = TC[t]; ctx.lineWidth = 1.6; ctx.stroke();
        ctx.beginPath(); ctx.arc(x + 11, y0 + 11, 5, 0, 7); ctx.fillStyle = TC[t]; ctx.fill();
        txt(teamLab(t), x + 20, y0 + 11.5, '#f2e9d8', '700 11px ' + FONT, 'left');
        txt(String(st.sc[t]), x + cw - 8, y0 + 18, '#e3ae45', '800 22px ' + MONO, 'right');
        let flags = ''; for (let k = 0; k < st.need; k++) flags += k < st.sc[t] ? '■' : '□';
        if (st.need <= 5) txt(flags, x + 10, y0 + 27, hexA(TC[t], 0.95), '700 9px ' + FONT, 'left');
        let jn = 0; for (const q of W.pl) if (q.t === t && q.jl) jn++;
        if (jn) txt('감옥 ' + jn, x + cw - 34, y0 + 27, '#bfe3ff', '700 9px ' + FONT, 'right');
        ctx.restore();
      }
      const left = W.ot ? W.rt + OT_T - W.t : W.rt - W.t;
      const lab = (W.ot ? '연장 ' : '') + fmt(phase === 'count' && W.t === 0 ? W.rt : left);
      const tw = W.ot ? 76 : 62, tx = (w - tw) / 2, low = phase === 'play' && left < 15;
      rr(ctx, tx, y0 + 4, tw, 28, 14); ctx.fillStyle = W.ot ? '#ee6a55' : 'rgba(23,19,31,.88)'; ctx.fill();
      txt(lab, w / 2, y0 + 18.5, W.ot ? '#fff' : low && Math.floor(now / 300) % 2 ? '#ee6a55' : '#e3ae45', '700 13px ' + MONO);
      txt(MAPS[st.mk].nm + ' · 먼저 ' + st.need + '점', w / 2, y0 + ch + 7, 'rgba(242,233,216,.65)', '700 10px ' + FONT, 'center', 3);
    }
    function centerText(t1, sub, col, scale, cy) {
      ctx.save(); ctx.translate(cv.w / 2, cy); ctx.scale(scale, scale);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '44px ' + DISP; ctx.lineWidth = 7; ctx.strokeStyle = 'rgba(16,12,22,.85)'; ctx.lineJoin = 'round'; ctx.strokeText(t1, 0, 0);
      ctx.fillStyle = col; ctx.fillText(t1, 0, 0);
      if (sub) { ctx.font = '700 15px ' + FONT; ctx.lineWidth = 4.5; ctx.strokeText(sub, 0, 38); ctx.fillStyle = '#f2e9d8'; ctx.fillText(sub, 0, 38); }
      ctx.restore();
    }
    function drawBanners() {
      const cy = TOPH + (cv.h - TOPH) * 0.3, mt = myTeam();
      if (phase === 'count') {
        const n = Math.ceil(cd), mp = MAPS[st.mk];
        const sub = st.rd === 1 ? mp.nm + ' · ' + mp.d : '우리 ' + st.sc[mt] + ' : ' + st.sc[1 - mt] + ' 상대';
        if (n <= 3) centerText(String(n), tipT > 0 ? null : (ctrlOn() ? sub : mp.nm), '#f2e9d8', 1 + (cd % 1) * 0.3, cy);
        else centerText(mp.nm, mp.d, '#ffd27a', 0.8, cy);
      } else if (phase === 'play' && startT > 0) {
        ctx.save(); ctx.globalAlpha = Math.min(1, startT * 2); centerText('출발!', null, '#e3ae45', 1, cy); ctx.restore();
      } else if (phase === 'end' && (st.ph === 'end' || st.ph === 'done')) {
        const rw = st.rw, mine = ctrlOn() && rw === mt;
        if (st.ph === 'done') centerText('경기 끝!', null, '#e3ae45', 0.9, cy);
        else if (st.why === 'cap') centerText(ctrlOn() ? (mine ? '득점!' : '실점…') : TEAM_NM[rw] + ' 득점!', (st.by >= 0 ? name(st.by) + ' 깃발 꽂기 · ' : '') + st.sc[mt] + ' : ' + st.sc[1 - mt], TC[rw], 0.85, cy);
        else centerText('시간 끝!', null, '#f2e9d8', 0.85, cy);
      }
      if (banner && phase === 'play') { const k = 1 - banner.life / banner.max; ctx.save(); ctx.globalAlpha = Math.min(1, banner.life * 2); centerText(banner.t, banner.sub, banner.c, k < 0.15 ? 0.5 + k * 3 : 0.8, cy); ctx.restore(); }
      if (tipT > 0 && ctrlOn()) {
        const pc = !!window.LOUNGE_DESKTOP || (window.matchMedia && matchMedia('(pointer:fine)').matches);
        const lines = ['왼쪽 엄지: 끌어서 달리기 · 「대시」 휙!', '상대 진영(위쪽)의 깃발을 집어 우리 진영으로!', '우리 진영에서는 상대를 몸으로 터치 → 감옥', '상대 진영에서 잡히면 감옥 · 친구가 구해줘요'];
        if (pc) lines.push('PC: WASD·방향키 이동 · 스페이스 대시');
        ctx.save(); ctx.globalAlpha = Math.min(1, tipT * 2);
        ctx.font = '600 13px ' + FONT;
        let mw = 0; for (const l of lines) mw = Math.max(mw, ctx.measureText(l).width);
        const bw = Math.min(cv.w - 16, mw + 26), bh = lines.length * 21 + 14, bx = (cv.w - bw) / 2, by = Math.min(cv.h - 130 - bh, cy + 60);
        rr(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(20,16,30,.92)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.2; ctx.stroke();
        lines.forEach((l, k) => { ctx.font = '600 13px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = k === 0 ? '#ffd27a' : '#f2e9d8'; ctx.fillText(l, cv.w / 2, by + 17 + k * 21, bw - 12); });
        ctx.restore();
      }
      const p = myP();
      if (p && ctrlOn() && phase === 'play' && !(tipT > 0) && !banner) {
        let hTxt = '', col = '#f2e9d8';
        if (p.jl) { hTxt = '감옥! 친구가 울타리를 터치하면 풀려나요 (' + Math.max(1, JAIL_MAX - Math.floor(p.jT)) + '초)'; col = '#bfe3ff'; }
        else if (p.fw) { hTxt = '자유 귀환 중 — 우리 진영으로 돌아가요'; }
        else if (carrying(W, p)) { hTxt = '깃발 들었어요! 가운데 선을 넘어 우리 진영으로!'; col = '#ffd27a'; }
        else if (side(p.y) !== p.t) { hTxt = '상대 진영 — 터치당하면 감옥!'; col = '#ff9a85'; }
        if (hTxt) { ctx.save(); ctx.font = '700 12px ' + FONT; const tw = Math.min(cv.w - 20, ctx.measureText(hTxt).width + 20), hx = cv.w / 2, hy = cv.h - 124; rr(ctx, hx - tw / 2, hy - 11, tw, 22, 11); ctx.fillStyle = 'rgba(20,16,30,.86)'; ctx.fill(); ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = col; ctx.fillText(hTxt, hx, hy + 0.5, tw - 12); ctx.restore(); }
      }
    }
    function draw(now, rdt) {
      if (!lay || !W || !bgCv) return;
      const tg = camTarget();
      if (!cam.init) { cam.x = tg[0]; cam.y = tg[1]; cam.init = true; }
      else { const k = 1 - Math.exp(-rdt * 7); cam.x += (tg[0] - cam.x) * k; cam.y += (tg[1] - cam.y) * k; }
      cv.clear();
      ctx.fillStyle = (THEME[W.mp.id] || THEME.park).out; ctx.fillRect(0, 0, cv.w, cv.h);
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 7 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 7 : 0;
      ctx.save(); ctx.translate(sx, sy);
      drawWorld(now);
      drawNight();
      for (const f of floats) {
        const k = f.t / f.life, x = SX(f.x), y = SY(f.y) - lay.s * 1.4 - k * 22;
        ctx.save(); ctx.globalAlpha = Math.min(1, (1 - k) * 2.2);
        txt(f.txt, x, y, f.c, '800 14px ' + FONT, 'center', 3.5);
        ctx.restore();
      }
      ctx.restore();
      drawArrows(now);
      drawHud(now);
      drawMini();
      drawStick();
      drawBanners();
      for (const c of conf) { ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(c.rot); ctx.globalAlpha = Math.min(1, (c.life - c.t) * 2); ctx.fillStyle = c.c; ctx.fillRect(-4, -2.2, 8, 4.4); ctx.restore(); }
    }

    const stopLoop = U.loop((rdt, now) => {
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); syncBtns(); } catch (e) { console.error(e); }
      try { draw(now, rdt); } catch (e) { console.error(e); }
    });

    function celebrate(next) {
      const rw = next.rw, mt = myTeam();
      if ((rw === 0 || rw === 1) && next.why === 'cap') {
        const mine = ctrlOn() && rw === mt;
        api.sfx(!ctrlOn() || mine ? 'win' : 'lose');
        if (mine) api.buzz(50);
        for (let i = 0; i < 50; i++) conf.push({ x: cv.w * (0.2 + Math.random() * 0.6), y: TOPH + 60, vx: (Math.random() - 0.5) * 380, vy: -100 - Math.random() * 300, rot: Math.random() * 7, vr: (Math.random() - 0.5) * 14, c: [TC[rw], '#ffffff', '#e3ae45'][i % 3], t: 0, life: 1.4 + Math.random() * 0.8 });
      } else api.sfx('tick');
    }

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (curKey() !== key) { startRound(); return; }
        if (prev && prev.ph !== next.ph) {
          if (next.ph === 'play' && phase === 'count') { phase = 'play'; sfx('pop'); startT = 0.9; }
          if (next.ph === 'end') { phase = 'end'; endT = END_T; celebrate(next); }
        }
        if (W && next.ph === 'done') phase = 'end';
      },
      destroy() {
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        dashBtn.remove();
        styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, lay, flip, locIn, remIn, phase, cam }),
    };
  }

  /* ---------- small drawing helpers ---------- */
  function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function rrc(c, x, y, w, h, r) { rr(c, x, y, w, h, r); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(255,255,255,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'ctf', name: '깃발 뺏기 팀전', tag: '실시간 팀 술래잡기', cat: '스포츠',
    blurb: '상대 진영의 깃발을 가져와 우리 진영에 꽂으면 득점! 우리 진영에선 상대를 터치해 감옥에 보내고, 갇힌 친구는 구출해요. 최대 8명 팀전(빈자리는 봇).',
    tint: '#2a5a3a',
    icon: '<path d="M6 28h44" stroke="currentColor" stroke-width="2.5" stroke-dasharray="4 3"/><path d="M16 22V6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M16 6l14 4.5L16 15z" fill="currentColor"/><circle cx="38" cy="40" r="5" fill="currentColor"/><circle cx="24" cy="44" r="4" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M28 43l5-2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M40 10v12M44 10v12M48 10v12M38 10h12M38 22h12" stroke="currentColor" stroke-width="2"/>',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 8, hidden: false, realtime: true, aiDelay: 0,
    maxPlayersIf: (o) => 2 * ([2, 3, 4].includes(+(o && o.ts)) ? +o.ts : 4),
    options: [
      { id: 'ts', label: '팀 인원', choices: [{ v: 4, label: '4:4' }, { v: 3, label: '3:3' }, { v: 2, label: '2:2' }], def: 4 },
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.nm }))), def: -1 },
      { id: 'need', label: '목표 점수', choices: [{ v: 3, label: '3점' }, { v: 1, label: '1점' }, { v: 5, label: '5점' }], def: 3 },
      { id: 'time', label: '시간', choices: [{ v: 300, label: '5분' }, { v: 180, label: '3분' }, { v: 480, label: '8분' }], def: 300 },
    ],
    controls: [
      { id: 'up', label: '위로 달리기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 달리기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 달리기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 달리기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'dash', label: '대시(휙 달리기)', keys: ['Space', 'ShiftLeft', 'KeyJ'], pad: ['a', 'rt'] },
    ],
    quick: [
      '상대 진영의 깃발을 집어 가운데 선을 넘어 우리 진영으로 가져오면 1점! 먼저 3점(또는 5분 뒤 더 많은 팀)이 이겨요.',
      '우리 진영에서는 내가 술래: 들어온 상대를 몸으로 터치하면 감옥으로! 상대 진영에서는 내가 잡힐 수 있어요.',
      '감옥에 갇힌 친구는 우리 편이 감옥 울타리를 터치하면 모두 풀려나요. 「대시」로 휙 빠져나가요.',
    ],
    rules: [
      { h: '목표', p: [
        '두 팀이 가운데 선을 사이에 두고 하는 깃발 뺏기예요. 화면 아래가 우리 진영, 위가 상대 진영이에요.',
        '상대 진영 깊숙한 곳의 깃발을 몸으로 닿아 집은 뒤, 가운데 선을 넘어 우리 진영에 들어오면 깃발이 꽂히고 1점!',
        '먼저 3점을 낸 팀이 이겨요. 5분이 끝나면 점수가 많은 팀이 이기고, 같으면 1분 「연장전」(먼저 득점하면 승리, 그래도 같으면 무승부).',
      ] },
      { h: '잡기(태그)와 감옥', p: [
        '우리 진영 안에서는 내가 술래예요. 우리 진영에 들어온 상대에게 몸이 닿으면 자동으로 「잡았다!」 → 그 상대는 우리 감옥으로 가요.',
        '반대로 상대 진영에 들어가면 상대에게 닿는 순간 잡혀서 상대 감옥으로 가요. 상대가 가까이 오면 빨간 고리로 알려줘요.',
        '깃발을 든 채 잡히면 깃발은 그 자리에 떨어져요. 떨어진 깃발은 주인 팀이 닿으면 바로 제자리로, 10초가 지나도 제자리로 돌아가요.',
        '득점이 나면 모두 처음 자리로 돌아가고 감옥도 비워진 채 다시 시작해요.',
      ] },
      { h: '구출', p: [
        '감옥은 상대 진영 구석에 있어요(초록 고리가 반짝이면 우리 편이 갇혀 있다는 뜻).',
        '우리 편 누구든 감옥 울타리를 터치하면 갇힌 친구가 모두 풀려나요! 구한 사람과 풀려난 친구는 「자유 귀환」(반투명)으로 우리 진영까지 안전하게 돌아와요. 자유 귀환 중엔 잡지도 잡히지도 않고 깃발도 못 집어요.',
        '아무도 못 구해 주면 20초 뒤에 저절로 풀려나요.',
      ] },
      { h: '보호 구역 · 아이템', p: [
        '깃발 받침과 감옥 둘레의 점선 원에는 그 진영 팀이 들어갈 수 없어요(꽉 막고 지키기 금지). 그래서 깃발에 닿을 때까지는 안전하지만, 들고 나올 때가 진짜 승부!',
        '깃발을 들면 조금 느려지고 대시 쉬는 시간도 길어져요.',
        '가끔 가운데 선에 아이템이 나타나요: ⚡ 번개 신발(6초 동안 빨라짐), 🛡 방패(12초 동안 한 번 잡혀도 튕겨 냄).',
      ] },
      { h: '조작', p: [
        '화면 아무 곳이나 누르고 끌면 그 방향으로 달려요(누른 곳이 조이스틱 중심). 오른쪽 아래 「대시」는 휙 빠르게 튀어 나가요(2초쯤 쉬었다 다시).',
        '잡기는 버튼이 없어요: 우리 진영에서 상대에게 닿기만 하면 돼요.',
        '오른쪽 위 작은 지도에 전체 판이 보여요. 화면 밖의 깃발·감옥은 가장자리 화살표로 알려줘요.',
        'PC: WASD·방향키 이동, 스페이스·Shift·J 대시. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '맵 (기본은 무작위)', p: [
        '잔디 공원: 덤불에 들어가면 상대에게 안 보여요(아주 가까이 오면 보여요). 시냇물 다리: 물은 못 건너요, 다리 3개로만 넘어가요. 미로 정원: 산울타리 미로.',
        '질주 놀이터: 노란 발판을 밟으면 휙 빨라져요. 광산 수레길: 오가는 수레가 길을 막아요. 한밤 캠프: 깜깜해서 우리 편 근처와 등불 둘레만 보여요. 얼음 호수: 미끄럽고 얼음 구멍은 못 지나가요.',
      ] },
      { h: '예시', p: [
        '상대 수비가 깃발 앞을 지키고 있어요 → 가운데 선에서 왼쪽·오른쪽으로 흔들다가 수비가 다른 친구를 쫓아갈 때 「대시」로 들어가요.',
        '깃발을 집었어요! → 가장 가까운 선 쪽으로, 빨간 고리(잡을 수 있는 상대)를 피해 달리고 막히면 「대시」!',
        '친구 2명이 갇혔어요 → 감옥 쪽 화살표를 따라가 울타리에 닿기만 하면 둘 다 풀려나요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지는 AI예요. 친구와는 온라인·LAN 방에서 각자 폰으로(최대 8명). 사람은 1·3·5·7번 빨강 팀, 2·4·6·8번 파랑 팀이고 빈자리는 봇(보통)이 채워요.',
        'AI는 공격·수비·구출 역할을 나눠 움직여요. 난이도는 자리마다 쉬움·보통·어려움: 쉬움은 느리고 잘 안 피해요, 어려움은 빈틈을 기다렸다 들어오고 대시를 잘 써요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { init, newWorld, tickWorld, stepWorld, aiThink, roundOver, nextRound, result, MAPS, AI_DIFF, geom, visibleTo, side, BASE, JAIL, fieldTo, fieldHome, carrying },
  });
})();
