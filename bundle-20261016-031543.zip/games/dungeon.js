/* 미니 던전 탐험 — 칸 단위 턴제 로그라이크 퍼즐(1–4인).
   판마다 씨앗(seed)으로 5층 던전을 새로 만들어요(방 + 통로, 안개, 잠긴 문·열쇠, 함정과 단서, 상점, 5층 보스).
   한 걸음 = 한 턴: 내가 움직이면 그 층 몬스터가 움직여요(몬스터 머리 위 화살표 = 다음 행동). 전투는 주사위 없이 정해진 숫자.
   여럿이면 모두 같은 던전의 '자기 복사본'을 동시에 탐험(각자 속도로)하고, 다른 사람은 유령으로 보여요.
   상태: 공용 seed + 사람마다 압축 문자열(안개·가져간 것·몬스터). 생성은 seed로 결정적이라 게스트도 같은 판을 그려요. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= constants ======================= */
  const W = 17, H = 21, N = W * H, RV = 5, MAXF = 5, INV = 6, TORCH0 = 500, TORCH_ADD = 60;
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const B64I = {}; for (let i = 0; i < 64; i++) B64I[B64[i]] = i;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];
  const DIRN = ['위', '오른쪽', '아래', '왼쪽'];
  const cx = (c) => c % W, cy = (c) => (c / W) | 0;
  const man = (a, b) => Math.abs(cx(a) - cx(b)) + Math.abs(cy(a) - cy(b));
  const cheb = (a, b) => Math.max(Math.abs(cx(a) - cx(b)), Math.abs(cy(a) - cy(b)));
  const stepC = (c, d) => { const x = cx(c) + DX[d], y = cy(c) + DY[d]; return x < 0 || y < 0 || x >= W || y >= H ? -1 : y * W + x; };
  const dirTo = (a, b) => { const dx = cx(b) - cx(a), dy = cy(b) - cy(a); if (dx === 0 && dy < 0) return 0; if (dy === 0 && dx > 0) return 1; if (dx === 0 && dy > 0) return 2; if (dy === 0 && dx < 0) return 3; return -1; };

  function rng(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function hsh(a, b, c) { let h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul((c | 0) + 7, 2246822519)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return h >>> 0; }

  /* ---- bitsets as 6-bit strings ---- */
  const bsDec = (s, n) => { const a = new Uint8Array(Math.ceil(n / 6)); if (s) for (let i = 0; i < a.length && i < s.length; i++) a[i] = B64I[s[i]] || 0; return a; };
  const bsEnc = (a) => { let s = ''; for (let i = 0; i < a.length; i++) s += B64[a[i]]; return s; };
  const bget = (a, i) => (a[(i / 6) | 0] >> (i % 6)) & 1;
  const bset = (a, i) => { a[(i / 6) | 0] |= 1 << (i % 6); };

  /* ======================= data ======================= */
  /* monsters: b = behaviour. hp/at/df base; g = gold drop; f = floors [min,max]; w = spawn weight */
  const MT = [
    { n: '쥐', e: '🐀', hp: 2, at: 1, df: 0, g: 1, b: 'chase', f: [1, 3], w: 5, d: '보이면 쫓아와요. 약해요.' },
    { n: '박쥐', e: '🦇', hp: 2, at: 1, df: 0, g: 1, b: 'bat', f: [1, 4], w: 3, d: '한 턴에 2칸: 한 번은 아무 데로, 한 번은 나에게.' },
    { n: '슬라임', e: '🟢', hp: 5, at: 2, df: 0, g: 2, b: 'slow', f: [1, 3], w: 4, d: '느려요. 두 턴에 한 번만 움직여요.' },
    { n: '해골 병사', e: '💀', hp: 5, at: 2, df: 1, g: 3, b: 'chase', f: [2, 5], w: 4, d: '끈질기게 쫓아와요. 방어 1.' },
    { n: '거미', e: '🕷️', hp: 3, at: 2, df: 0, g: 2, b: 'ambush', f: [1, 4], w: 3, d: '2칸 안에 와야 깨요. 물리면 독.' },
    { n: '고블린 궁수', e: '👺', hp: 3, at: 2, df: 0, g: 3, b: 'archer', f: [2, 5], w: 3, d: '같은 줄(가로·세로) 5칸 안이면 화살(2)을 쏘고, 다음 턴은 장전해요. 붙으면 한 번 물러나요.' },
    { n: '돌 골렘', e: '🗿', hp: 10, at: 4, df: 2, g: 6, b: 'slow', f: [4, 5], w: 2, d: '아주 튼튼하고 세요. 대신 느려요.' },
    { n: '유령', e: '👻', hp: 3, at: 2, df: 0, g: 3, b: 'ghost', f: [3, 5], w: 3, d: '벽을 뚫고 와요. 느려요.' },
    { n: '미믹', e: '📦', hp: 6, at: 3, df: 0, g: 8, b: 'mimic', f: [2, 5], w: 0, d: '상자인 척해요. 가끔 덜컹거려요!' },
    { n: '돌진 멧돼지', e: '🐗', hp: 5, at: 2, df: 0, g: 3, b: 'charge', f: [2, 5], w: 3, d: '같은 줄이면 한 턴 노려보고 일직선으로 돌진(피해 2배). 옆으로 피하세요.' },
    { n: '폭탄 버섯', e: '🍄', hp: 3, at: 0, df: 0, g: 2, b: 'bloat', f: [1, 5], w: 2, d: '옆에 서면 부풀고, 다음 턴에 펑! 주변 1칸 피해 5.' },
    { n: '도둑 원숭이', e: '🐒', hp: 3, at: 0, df: 0, g: 0, b: 'thief', f: [2, 5], w: 2, d: '금화를 훔쳐 달아나요. 무거워서 두 턴에 한 번만 달려요. 잡으면 돌려받아요.' },
    { n: '동굴 마법사', e: '🧙', hp: 4, at: 1, df: 0, g: 5, b: 'caster', f: [3, 5], w: 2, d: '같은 줄 6칸 안이면 마법 화살(3), 다음 턴은 쉬어요. 붙으면 순간이동으로 도망.' },
    { n: '그림자 늑대', e: '🐺', hp: 4, at: 3, df: 0, g: 4, b: 'fast', f: [3, 5], w: 2, d: '빨라요. 한 턴에 2칸.' },
    { n: '수호 기사', e: '💂', hp: 7, at: 3, df: 1, g: 10, b: 'guard', f: [3, 5], w: 0, d: '자리를 지켜요. 바로 옆에 오면만 공격.' },
    { n: '독두꺼비', e: '🐸', hp: 4, at: 2, df: 0, g: 2, b: 'hop', f: [1, 4], w: 3, d: '두 턴에 한 번 2칸 폴짝. 물리면 독.' },
    { n: '잿빛 군주', e: '👹', hp: 22, at: 4, df: 1, g: 60, b: 'boss', f: [5, 5], w: 0, d: '5층 보스. 2번 움직인 뒤 한 턴 힘을 모아(빨간 칸) 주변을 내려쳐요(7). 반쯤 다치면 쥐를 불러요.' },
  ];
  const MI = {}; MT.forEach((m, i) => { MI[m.b === 'chase' && i === 0 ? 'rat' : m.b] = i; });
  const BOSS = 16, RAT = 0, MIMIC = 8, GUARD = 14;

  /* items. k: p potion · s scroll · x other consumable · w weapon · a armor · r ring ; c = colour for drawn bottles/scrolls */
  const IT = {
    a: { n: '빨간 물약', k: 'p', c: '#e0455a', pr: 15, d: '체력 8 회복' },
    b: { n: '큰 물약', k: 'p', c: '#ff7fb3', pr: 35, d: '체력을 가득 회복' },
    c: { n: '해독 물약', k: 'p', c: '#5cc46a', pr: 12, d: '독을 없애고 체력 3 회복' },
    d: { n: '힘 물약', k: 'p', c: '#f0a030', pr: 45, d: '공격력 영원히 +1' },
    e: { n: '돌 피부 물약', k: 'p', c: '#9aa4b0', pr: 45, d: '방어력 영원히 +1' },
    f: { n: '그림자 물약', k: 'p', c: '#6a5ac8', pr: 25, d: '10턴 동안 몬스터가 나를 못 봐요(가만히 있어요)' },
    g: { n: '폭탄', k: 'x', e: '💣', pr: 20, d: '내 주변 8칸 몬스터에게 피해 6 + 옆의 잠긴 문을 부숴요' },
    h: { n: '지도 두루마리', k: 's', c: '#3f8fd0', pr: 20, d: '이 층 지도를 모두 밝혀요(계단 위치도!)' },
    i: { n: '순간이동 두루마리', k: 's', c: '#b65ee0', pr: 15, d: '다른 방으로 순간이동' },
    j: { n: '불꽃 두루마리', k: 's', c: '#ee6a3a', pr: 30, d: '보이는 몬스터 모두에게 피해 4' },
    k: { n: '얼음 두루마리', k: 's', c: '#7fd6f0', pr: 25, d: '보이는 몬스터를 3턴 얼려요' },
    l: { n: '감지 두루마리', k: 's', c: '#e3c045', pr: 15, d: '이 층의 함정과 물건 위치가 모두 보여요' },
    n: { n: '빵', k: 'x', e: '🍞', pr: 6, d: '체력 4 회복' },
    A: { n: '단검', k: 'w', e: '🗡️', v: 1, pr: 25, d: '공격력 +1' },
    B: { n: '장검', k: 'w', e: '⚔️', v: 2, pr: 55, d: '공격력 +2' },
    C: { n: '전투 도끼', k: 'w', e: '🪓', v: 3, pr: 90, d: '공격력 +3' },
    D: { n: '가죽 갑옷', k: 'a', e: '🧥', v: 1, pr: 25, d: '방어력 +1' },
    E: { n: '사슬 갑옷', k: 'a', e: '🦺', v: 2, pr: 55, d: '방어력 +2' },
    F: { n: '판금 갑옷', k: 'a', e: '🛡️', v: 3, pr: 90, d: '방어력 +3' },
    G: { n: '체력 반지', k: 'r', e: '💍', pr: 40, d: '최대 체력 +6' },
    H: { n: '가시 반지', k: 'r', e: '🌵', pr: 35, d: '나를 때린 몬스터가 1 피해' },
    I: { n: '행운 부적', k: 'r', e: '🍀', pr: 40, d: '줍는 금화 1.5배' },
    J: { n: '탐지 반지', k: 'r', e: '👁️', pr: 30, d: '바로 옆(1칸) 함정이 저절로 보여요' },
  };
  const CONS = 'abcdefghijklgn';
  const CONS_W = { a: 6, b: 2, c: 3, d: 1, e: 1, f: 2, g: 3, h: 2, i: 2, j: 2, k: 2, l: 2, n: 4 };
  const GEAR_F = { 1: 'AD', 2: 'ADGHJ', 3: 'BEGIJ', 4: 'BECFH', 5: 'CFI' };
  const TRAPS = [
    { n: '가시 함정', d: '피해 4', clue: 0 },
    { n: '독침 함정', d: '독 4턴', clue: 0 },
    { n: '구덩이', d: '아래층으로 떨어져요(피해 3)', clue: 1 },
    { n: '순간이동 함정', d: '아무 데로 휙', clue: 2 },
    { n: '경보 함정', d: '층의 몬스터가 모두 깨요', clue: 2 },
  ];
  const CLUES = ['흩어진 뼈', '금 간 바닥', '빛나는 문양'];

  /* ======================= dungeon generation (deterministic from seed) ======================= */
  const GC = new Map();
  function gen(seed, f) {
    const key = seed + ':' + f;
    let G = GC.get(key);
    if (G) return G;
    for (let att = 0; !G && att < 40; att++) G = tryGen(seed, f, att);
    if (GC.size > 30) GC.clear();
    GC.set(key, G);
    return G;
  }
  function bfs(t, from, passable) {
    const d = new Int16Array(N).fill(-1), q = new Int16Array(N);
    let h = 0, e = 0; d[from] = 0; q[e++] = from;
    while (h < e) { const c = q[h++]; for (let k = 0; k < 4; k++) { const nb = stepC(c, k); if (nb >= 0 && d[nb] < 0 && passable(nb)) { d[nb] = d[c] + 1; q[e++] = nb; } } }
    return d;
  }
  function tryGen(seed, f, att) {
    const R = rng((seed ^ Math.imul(f + 1, 0x9E3779B1) ^ Math.imul(att + 3, 0x85EBCA77)) >>> 0);
    const ri = (n) => Math.floor(R() * n);
    const t = new Uint8Array(N);
    const rooms = [];
    const big = f === MAXF;
    for (let k = 0; k < 400 && rooms.length < 9; k++) {
      let w = 3 + ri(4), h = 3 + ri(4);
      if (big && rooms.length === 0) { w = 6; h = 6; }
      const x = 1 + ri(W - w - 1), y = 1 + ri(H - h - 1);
      if (rooms.some((r) => x <= r.x + r.w && r.x <= x + w && y <= r.y + r.h && r.y <= y + h)) continue;
      rooms.push({ x, y, w, h, cx: x + (w >> 1), cy: y + (h >> 1) });
    }
    if (rooms.length < 6) return null;
    const roomOf = new Int8Array(N).fill(-1);
    rooms.forEach((r, i) => { for (let yy = r.y; yy < r.y + r.h; yy++) for (let xx = r.x; xx < r.x + r.w; xx++) { t[yy * W + xx] = 1; roomOf[yy * W + xx] = i; } });
    const carve = (ax, ay, bx, by) => {
      const hf = R() < 0.5; let x = ax, y = ay;
      if (hf) { while (x !== bx) { x += Math.sign(bx - x); t[y * W + x] = 1; } while (y !== by) { y += Math.sign(by - y); t[y * W + x] = 1; } }
      else { while (y !== by) { y += Math.sign(by - y); t[y * W + x] = 1; } while (x !== bx) { x += Math.sign(bx - x); t[y * W + x] = 1; } }
    };
    for (let i = 1; i < rooms.length; i++) {
      let bj = 0, bd = 1e9;
      for (let j = 0; j < i; j++) { const d = Math.abs(rooms[i].cx - rooms[j].cx) + Math.abs(rooms[i].cy - rooms[j].cy); if (d < bd) { bd = d; bj = j; } }
      carve(rooms[i].cx, rooms[i].cy, rooms[bj].cx, rooms[bj].cy);
    }
    const extra = 1 + ri(2);
    for (let k = 0; k < extra; k++) { const a = ri(rooms.length), b = ri(rooms.length); if (a !== b) carve(rooms[a].cx, rooms[a].cy, rooms[b].cx, rooms[b].cy); }

    const sr = big ? 1 + ri(rooms.length - 1) : ri(rooms.length);
    const start = rooms[sr].cy * W + rooms[sr].cx;
    const d0 = bfs(t, start, (c) => t[c] === 1);
    // stairs room: farthest (5층은 큰 방 0번이 보스 방)
    let xr = -1, best = -1;
    rooms.forEach((r, i) => { if (i === sr) return; const d = d0[r.cy * W + r.cx]; if (d > best) { best = d; xr = i; } });
    if (big) xr = 0;
    if (xr < 0 || best < 8) return null;
    const openings = (r) => {
      const o = [];
      for (let xx = r.x; xx < r.x + r.w; xx++) { for (const yy of [r.y - 1, r.y + r.h]) if (yy >= 0 && yy < H && t[yy * W + xx]) o.push(yy * W + xx); }
      for (let yy = r.y; yy < r.y + r.h; yy++) { for (const xx of [r.x - 1, r.x + r.w]) if (xx >= 0 && xx < W && t[yy * W + xx]) o.push(yy * W + xx); }
      return o;
    };
    const doors = [];
    let vault = -1;
    if (f >= 2 && f < MAXF) { const o = openings(rooms[xr]); if (o.length === 1) { t[o[0]] = 2; doors.push(o[0]); } }
    {
      const cands = [];
      rooms.forEach((r, i) => { if (i !== sr && i !== xr && openings(r).length === 1) cands.push(i); });
      if (cands.length && (f === 1 || R() < 0.65)) { vault = cands[ri(cands.length)]; const o = openings(rooms[vault]); t[o[0]] = 2; doors.push(o[0]); }
    }
    let r0 = bfs(t, start, (c) => t[c] === 1);
    const stairs = big ? rooms[xr].cy * W + rooms[xr].cx + 1 : rooms[xr].cy * W + rooms[xr].cx;
    // shop on floors 2 and 4
    let shop = -1, keeper = -1;
    if (f === 2 || f === 4) {
      const cnt = (d) => { let k = 0; for (let i = 0; i < N; i++) if (d[i] >= 0) k++; return k; };
      const base = cnt(r0);
      const cands = [];
      rooms.forEach((r, i) => { if (i !== sr && i !== xr && i !== vault && r.w * r.h >= 9 && r0[r.cy * W + r.cx] >= 0) cands.push(i); });
      if (cands.length) {
        const si = cands[ri(cands.length)], r = rooms[si];
        const tries = [];
        for (let yy = r.y; yy < r.y + r.h; yy++) for (let xx = r.x; xx < r.x + r.w; xx++) tries.push(yy * W + xx);
        for (const c of tries) {
          t[c] = 3;
          const d = bfs(t, start, (q) => t[q] === 1);
          if (cnt(d) === base - 1) { shop = si; keeper = c; r0 = d; break; }
          t[c] = 1;
        }
      }
    }
    // free cells
    const used = new Uint8Array(N);
    used[start] = 1; used[stairs] = 1; if (keeper >= 0) used[keeper] = 1;
    doors.forEach((c) => (used[c] = 1));
    const pick = (ok) => {
      const list = [];
      for (let c = 0; c < N; c++) if (t[c] === 1 && !used[c] && ok(c)) list.push(c);
      if (!list.length) return -1;
      const c = list[ri(list.length)]; used[c] = 1; return c;
    };
    const inR0 = (c) => r0[c] >= 0;
    const notStart = (c) => roomOf[c] !== sr;
    const ents = [];
    const add = (k, p, v) => { if (p >= 0) ents.push({ k, p, v }); };
    const consPick = () => { let tot = 0; for (const k in CONS_W) tot += CONS_W[k]; let r = R() * tot; for (const k in CONS_W) { r -= CONS_W[k]; if (r < 0) return k; } return 'a'; };
    const gearPick = () => { const s = GEAR_F[f]; return s[ri(s.length)]; };
    doors.forEach((c) => add('D', c, 0));
    doors.forEach(() => add('K', pick((c) => inR0(c) && notStart(c) && r0[c] >= 4), 0));
    if (shop >= 0) {
      const pool = ['a', 'b', 'c', 'g', 'h', 'j', 'k', gearPick(), gearPick(), 'd', 'e'];
      const got = new Set();
      for (let k = 0; k < 3; k++) { let it = pool[ri(pool.length)]; for (let q = 0; q < 6 && got.has(it); q++) it = pool[ri(pool.length)]; got.add(it); add('S', pick((c) => roomOf[c] === shop), it); }
    }
    if (vault >= 0) {
      add('C', pick((c) => roomOf[c] === vault), R() < 0.5 ? gearPick() : '*');
      add('$', pick((c) => roomOf[c] === vault), 15 + f * 6 + ri(10));
      add('*', pick((c) => roomOf[c] === vault), 40);
    }
    const nCh = 1 + ri(2);
    for (let k = 0; k < nCh; k++) add('C', pick((c) => inR0(c) && notStart(c) && roomOf[c] >= 0), R() < 0.45 ? gearPick() : R() < 0.5 ? '*' : consPick());
    const nG = 4 + ri(3);
    for (let k = 0; k < nG; k++) add('$', pick((c) => inR0(c) || roomOf[c] === xr), 4 + f * 2 + ri(5 + f * 2));
    if (R() < 0.4) add('*', pick(inR0), 40);
    const nI = 2 + ri(2);
    for (let k = 0; k < nI; k++) add('I', pick(inR0), consPick());
    if (R() < 0.5) add('I', pick((c) => inR0(c) && notStart(c)), gearPick());
    if (f < MAXF) add('T', pick((c) => inR0(c) && notStart(c)), 0);
    const nT = 2 + f;
    const clues = new Int8Array(N).fill(-1);
    for (let k = 0; k < nT; k++) {
      const ty = ri(f === 1 ? 3 : 5);
      const p = pick((c) => inR0(c) && notStart(c) && (roomOf[c] < 0 || R() < 0.5) && d0[c] > 2);
      if (p < 0) continue;
      add('X', p, f === MAXF && ty === 2 ? 0 : ty);
      if (R() < 0.85) {
        const nb = [];
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const x = cx(p) + dx, y = cy(p) + dy; if ((dx || dy) && x >= 0 && y >= 0 && x < W && y < H) { const c = y * W + x; if (t[c] === 1 && !used[c] && clues[c] < 0) nb.push(c); } }
        if (nb.length) clues[nb[ri(nb.length)]] = TRAPS[ty].clue;
      }
    }
    { const c = pick((q) => inR0(q) && notStart(q)); if (c >= 0) { clues[c] = ri(3); used[c] = 0; } }
    // monsters
    const mons = [];
    const elig = MT.map((m, i) => (m.w && f >= m.f[0] && f <= m.f[1] ? i : -1)).filter((i) => i >= 0);
    const tot = elig.reduce((s, i) => s + MT[i].w, 0);
    const nM = 3 + f + ri(2);
    const scale = (f - 1) >> 1;
    for (let k = 0; k < nM; k++) {
      let r = R() * tot, ty = elig[0];
      for (const i of elig) { r -= MT[i].w; if (r < 0) { ty = i; break; } }
      const p = pick((c) => (inR0(c) || roomOf[c] === xr) && notStart(c) && d0[c] >= 6);
      if (p >= 0) mons.push([ty, p, MT[ty].hp + scale]);
    }
    if (f >= 2 && R() < 0.5) { const p = pick((c) => inR0(c) && notStart(c) && roomOf[c] >= 0); if (p >= 0) mons.push([MIMIC, p, MT[MIMIC].hp + scale]); }
    if (vault >= 0 && f >= 3) { const p = pick((c) => roomOf[c] === vault); if (p >= 0) mons.push([GUARD, p, MT[GUARD].hp]); }
    if (big) {
      const bp = rooms[xr].cy * W + rooms[xr].cx - 1;
      used[bp] = 1;
      mons.push([BOSS, bp, MT[BOSS].hp], [RAT, bp, 0], [RAT, bp, 0]);
    }
    // all keys reachable without doors, stairs reachable with doors opened
    const dAll = bfs(t, start, (c) => t[c] === 1 || t[c] === 2);
    if (dAll[stairs] < 0) return null;
    for (const e of ents) if (e.k === 'K' && r0[e.p] < 0) return null;
    if (doors.length > ents.filter((e) => e.k === 'K').length) return null;
    const entAt = new Int16Array(N).fill(-1);
    ents.forEach((e, i) => (entAt[e.p] = i));
    return { f, t, rooms, roomOf, start, stairs, ents, entAt, mons, clues, keeper, shop, sr, xr, vault };
  }

  /* ======================= monsters encoding ======================= */
  // 6 chars: type, pos hi, pos lo, hp, st, fl  (fl: 1 awake, 2..14 freeze<<1, 16 reserve, 32 summoned)
  function decMo(s) {
    const a = [];
    for (let i = 0; i + 5 < s.length; i += 6) a.push({ t: B64I[s[i]], p: B64I[s[i + 1]] * 64 + B64I[s[i + 2]], hp: B64I[s[i + 3]], st: B64I[s[i + 4]], fl: B64I[s[i + 5]] });
    return a;
  }
  function encMo(a) { let s = ''; for (const m of a) s += B64[m.t] + B64[(m.p >> 6) & 63] + B64[m.p & 63] + B64[Math.max(0, Math.min(63, m.hp))] + B64[m.st & 63] + B64[m.fl & 63]; return s; }
  function initMo(G) { return encMo(G.mons.map(([t, p, hp]) => ({ t, p, hp, st: 0, fl: t === BOSS ? 0 : hp === 0 ? 16 : t === GUARD ? 0 : 0 }))); }

  /* ======================= player context ======================= */
  function ctxOf(s, p) {
    const G = gen(s.sd, p.f);
    return { s, p, G, mo: decMo(p.mo), tk: bsDec(p.tk, G.ents.length), fog: bsDec(p.fog, N), ev: [] };
  }
  function save(c) { const p = c.p; p.mo = encMo(c.mo); p.tk = bsEnc(c.tk); p.fog = bsEnc(c.fog); }
  const doorOpen = (c, q) => { const i = c.G.entAt[q]; return i >= 0 && bget(c.tk, i) === 1; };
  const opaque = (c, q) => { const t = c.G.t[q]; return t === 0 || (t === 2 && !doorOpen(c, q)); };
  const walk = (c, q) => { const t = c.G.t[q]; return t === 1 || (t === 2 && doorOpen(c, q)); };
  function los(c, a, b) {
    let x0 = cx(a), y0 = cy(a); const x1 = cx(b), y1 = cy(b);
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    for (;;) {
      if (x0 === x1 && y0 === y1) return true;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
      if (x0 === x1 && y0 === y1) return true;
      if (opaque(c, y0 * W + x0)) return false;
    }
  }
  function visOf(c, pos) {
    const v = new Uint8Array(N), px = cx(pos), py = cy(pos);
    for (let dy = -RV; dy <= RV; dy++) for (let dx = -RV; dx <= RV; dx++) {
      if (dx * dx + dy * dy > RV * RV + 1) continue;
      const x = px + dx, y = py + dy;
      if (x < 0 || y < 0 || x >= W || y >= H) continue;
      const q = y * W + x;
      if (los(c, pos, q)) v[q] = 1;
    }
    return v;
  }
  function revealFog(c, v) { for (let q = 0; q < N; q++) if (v[q]) bset(c.fog, q); }
  const patk = (p) => p.a + (p.w ? IT[p.w].v : 0);
  const pdef = (p) => p.d + (p.ar ? IT[p.ar].v : 0);
  const monAt = (c, q) => { for (let i = 0; i < c.mo.length; i++) { const m = c.mo[i]; if (m.hp > 0 && m.p === q) return i; } return -1; };
  const mpass = (c, q) => walk(c, q) && q !== c.G.keeper;
  function score(p) { return p.g + (p.mx - 1) * 30 + (p.e === 3 ? 150 : 0); }

  /* ======================= monster AI (deterministic) ======================= */
  function lineDir(c, a, b, maxd) {
    const d = dirTo(a, b);
    if (d < 0 || man(a, b) > maxd) return -1;
    for (let q = stepC(a, d); q !== b; q = stepC(q, d)) { if (q < 0 || !mpass(c, q) || monAt(c, q) >= 0) return -1; }
    return d;
  }
  function chaseStep(c, i, from, dist, occ) {
    const cur = dist[from]; if (cur < 0) return -1;
    const rot = hsh(c.s.sd, c.p.t, i) & 3;
    for (let k = 0; k < 4; k++) { const d = (k + rot) & 3, nb = stepC(from, d); if (nb >= 0 && dist[nb] >= 0 && dist[nb] < cur && nb !== c.p.x && !occ(nb)) return nb; }
    return -1;
  }
  function fleeStep(c, i, from, dist, occ) {
    let best = -1, bd = dist[from];
    for (let d = 0; d < 4; d++) { const nb = stepC(from, d); if (nb >= 0 && dist[nb] > bd && nb !== c.p.x && !occ(nb) && mpass(c, nb)) { bd = dist[nb]; best = nb; } }
    return best;
  }
  /* what monster i will do on monster-phase T (player at c.p.x). Pure. */
  function intent(c, i, T, dist) {
    const m = c.mo[i], M = MT[m.t], P = c.p.x;
    if (m.hp <= 0) return { k: 'none' };
    const fz = (m.fl >> 1) & 7;
    if (fz) return { k: 'frozen' };
    if (!(m.fl & 1)) return { k: 'sleep' };
    if (M.b === 'charge' && m.st >= 1 && m.st <= 4) {
      const d = m.st - 1, path = []; let q = m.p, hit = false;
      for (let k = 0; k < 6; k++) { const nb = stepC(q, d); if (nb < 0) break; if (nb === P) { hit = true; break; } if (!mpass(c, nb) || monAt(c, nb) >= 0) break; path.push(nb); q = nb; }
      return { k: 'chg', d, path, hit };
    }
    if (M.b === 'charge' && m.st === 5) return { k: 'rest' };
    if (M.b === 'bloat') { if (m.st === 1) return { k: 'boom' }; return cheb(m.p, P) <= 1 ? { k: 'prime' } : { k: 'idle' }; }
    if (M.b === 'boss' && m.st === 3) return { k: 'slam' };
    if (c.p.sh > 0) return { k: 'lost' };
    const adj = man(m.p, P) === 1;
    const occ = (q) => monAt(c, q) >= 0;
    const slowOff = (M.b === 'slow' || M.b === 'ghost' || M.b === 'hop') && ((T + i) & 1) === 1;
    if (slowOff) return { k: 'rest' };
    switch (M.b) {
      case 'guard': return adj ? { k: 'atk' } : { k: 'idle' };
      case 'boss': {
        if (m.st === 2) return { k: 'wind' };
        if (adj) return { k: 'atk' };
        const nb = chaseStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb] } : { k: 'idle' };
      }
      case 'archer': {
        if (adj) { const nb = m.st === 2 ? -1 : fleeStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb], flee: 1 } : { k: 'atk' }; }
        if (m.st === 1) return { k: 'reload' };
        const d = lineDir(c, m.p, P, 5); if (d >= 0) return { k: 'shoot', d, dmg: 2 };
        const nb = chaseStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb] } : { k: 'idle' };
      }
      case 'caster': {
        if (adj) {
          let to = -1, bs = -1;
          for (let q = 0; q < N; q++) { if (dist[q] >= 4 && dist[q] <= 7 && mpass(c, q) && !occ(q)) { const sc = hsh(q, c.p.t, i) & 1023; if (sc > bs) { bs = sc; to = q; } } }
          return to >= 0 ? { k: 'blink', to } : { k: 'atk' };
        }
        if (m.st === 1) return { k: 'reload' };
        const d = lineDir(c, m.p, P, 6); if (d >= 0) return { k: 'shoot', d, dmg: 3 };
        const nb = chaseStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb] } : { k: 'idle' };
      }
      case 'charge': {
        if (adj) return { k: 'atk' };
        const d = lineDir(c, m.p, P, 6); if (d >= 0 && man(m.p, P) >= 2) return { k: 'aim', d };
        const nb = chaseStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb] } : { k: 'idle' };
      }
      case 'thief': {
        if (m.st > 0) { if ((T + i) & 1) return { k: 'rest' }; const nb = fleeStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb], flee: 1 } : { k: 'idle' }; }
        if (adj) return { k: 'steal' };
        const nb = chaseStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb] } : { k: 'idle' };
      }
      case 'ghost': {
        if (adj) return { k: 'atk' };
        let best = -1, bd = man(m.p, P);
        const rot = hsh(c.s.sd, T, i) & 3;
        for (let k = 0; k < 4; k++) { const nb = stepC(m.p, (k + rot) & 3); if (nb >= 0 && nb !== P && nb !== c.G.keeper && !occ(nb) && man(nb, P) < bd) { bd = man(nb, P); best = nb; } }
        return best >= 0 ? { k: 'mv', path: [best] } : { k: 'idle' };
      }
      case 'bat': case 'fast': case 'hop': {
        if (adj) return { k: 'atk' };
        const path = []; let q = m.p;
        const occ2 = (x) => occ(x) || path.includes(x);
        for (let s = 0; s < 2; s++) {
          let nb = -1;
          if (M.b === 'bat' && s === 0) {
            const d = hsh(c.s.sd, T, i * 7 + 1) & 3, r = stepC(q, d);
            if (r >= 0 && mpass(c, r) && r !== P && !occ2(r) && r !== m.p) nb = r;
          }
          if (nb < 0) { nb = chaseStep(c, i, q, dist, occ2); }
          if (nb < 0 || nb === m.p) break;
          path.push(nb); q = nb;
          if (man(q, P) === 1) break;
        }
        return path.length ? { k: 'mv', path } : { k: 'idle' };
      }
      default: {
        if (adj) return { k: 'atk' };
        const nb = chaseStep(c, i, m.p, dist, occ); return nb >= 0 ? { k: 'mv', path: [nb] } : { k: 'idle' };
      }
    }
  }
  function hurt(c, amt, src, ev) {
    const p = c.p; if (p.e) return;
    p.hp -= amt; c.ev.push(['d', src, amt]);
    if (p.hp <= 0) { p.hp = 0; die(c); }
  }
  function die(c) { const p = c.p; p.e = 1; p.g = Math.floor(p.g / 2); c.ev.push(['e', 1]); }
  function melee(c, m, mult) {
    const p = c.p, M = MT[m.t];
    hurt(c, Math.max(1, M.at * (mult || 1) - pdef(p)), m.p);
    if (M.b === 'ambush' || M.b === 'hop') { p.ps = Math.max(p.ps, M.b === 'ambush' ? 3 : 2); c.ev.push(['P']); }
    if (p.r === 'H') { m.hp -= 1; c.ev.push(['h', m.p, 1]); if (m.hp <= 0) killMon(c, m); }
  }
  function killMon(c, m) {
    const p = c.p, M = MT[m.t];
    m.hp = 0; p.kl++;
    let g = M.g + (M.b === 'thief' ? m.st : 0);
    if (g) { g = goldGain(p, g, M.b === 'thief' ? m.st : 0); p.g += g; }
    c.ev.push(['k', m.p, m.t, g]);
    if (m.t === BOSS) c.ev.push(['L']);
  }
  const goldGain = (p, g, raw) => (p.r === 'I' ? Math.floor((g - (raw || 0)) * 1.5) + (raw || 0) : g);
  function monPhase(c) {
    const p = c.p, T = p.t;
    const v = visOf(c, p.x);
    const dist = bfs(c.G.t, p.x, (q) => mpass(c, q));
    for (let i = 0; i < c.mo.length && !p.e; i++) {
      const m = c.mo[i]; if (m.hp <= 0) continue;
      const M = MT[m.t];
      const fz = (m.fl >> 1) & 7;
      if (fz) { m.fl = (m.fl & ~14) | ((fz - 1) << 1); continue; }
      if (!(m.fl & 1)) {
        if (M.b === 'mimic' || p.sh > 0) continue;
        const dd = man(m.p, p.x);
        const near = M.b === 'ambush' ? dd <= 2 : M.b === 'guard' ? dd <= 3 : (v[m.p] && dd <= RV);
        if (near) { m.fl |= 1; c.ev.push(['w', m.p]); }
        continue;
      }
      const it = intent(c, i, T, dist);
      switch (it.k) {
        case 'atk': melee(c, m); if (M.b === 'archer') m.st = 0; break;
        case 'steal': { const g = Math.min(p.g, 15); p.g -= g; m.st = Math.min(63, m.st + Math.max(1, g)); c.ev.push(['t', m.p, g]); break; }
        case 'mv': for (const q of it.path) m.p = q; if (M.b === 'archer') m.st = it.flee ? 2 : 0; break;
        case 'shoot': m.st = 1; c.ev.push(['S', m.p, p.x]); hurt(c, Math.max(1, it.dmg - pdef(p)), m.p); break;
        case 'reload': m.st = 0; break;
        case 'aim': m.st = it.d + 1; break;
        case 'chg': {
          for (const q of it.path) m.p = q;
          if (it.hit) melee(c, m, 2);
          m.st = 5; break;
        }
        case 'rest': if (M.b === 'charge') m.st = 0; break;
        case 'prime': m.st = 1; break;
        case 'boom': boom(c, m.p, 5, m); break;
        case 'blink': m.p = it.to; c.ev.push(['Q', it.to]); break;
        case 'wind': m.st = 3; break;
        case 'slam':
          m.st = 0; c.ev.push(['B', m.p]);
          if (cheb(m.p, p.x) <= 1) hurt(c, Math.max(1, 7 - pdef(p)), m.p);
          break;
        default: break;
      }
      if (M.b === 'boss' && (it.k === 'atk' || it.k === 'mv' || it.k === 'idle')) m.st = Math.min(2, m.st + 1);
    }
  }
  function boom(c, at, dmg, src) {
    const p = c.p;
    c.ev.push(['B', at]);
    if (src) src.hp = 0;
    for (const m of c.mo) if (m.hp > 0 && m !== src && cheb(m.p, at) <= 1) { m.hp -= dmg; c.ev.push(['h', m.p, dmg]); m.fl |= 1; if (m.hp <= 0) killMon(c, m); }
    if (src && cheb(p.x, at) <= 1) hurt(c, Math.max(1, dmg - pdef(p)), at);
  }

  /* ======================= state ======================= */
  function newSeed(opts) {
    if (opts && opts.dsd === 'day') { const d = new Date(); return (d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate()) * 7 + 13; }
    return 1 + Math.floor(Math.random() * 2e9);
  }
  function enterFloor(s, p, f) {
    p.f = f; p.mx = Math.max(p.mx, f);
    const G = gen(s.sd, f);
    p.x = G.start; p.mo = initMo(G); p.tk = bsEnc(new Uint8Array(Math.ceil(G.ents.length / 6))); p.fog = bsEnc(new Uint8Array(Math.ceil(N / 6)));
    p.ft = p.t; p.fe = p.tc;
    const c = ctxOf(s, p); revealFog(c, visOf(c, p.x)); save(c);
  }
  function init(players, opts) {
    const s = { sd: newSeed(opts), dy: opts && opts.dsd === 'day' ? 1 : 0, n: players.length, nm: players.map((q) => String(q.name || '').slice(0, 8)), ai: players.map((q) => (q.ai ? 1 : 0)), P: [] };
    for (let i = 0; i < players.length; i++) {
      const p = { f: 1, mx: 1, x: 0, hp: 24, mh: 24, a: 2, d: 0, w: '', ar: '', r: '', g: 0, t: 0, tc: TORCH0, inv: '', k: 0, ps: 0, sh: 0, kl: 0, e: 0, ls: '', sq: -9, ft: 0, fe: TORCH0, eid: 0, ev: [], mo: '', tk: '', fog: '' };
      s.P.push(p);
      enterFloor(s, p, 1);
    }
    return s;
  }
  function actor(s) { const a = []; s.P.forEach((p, i) => { if (!p.e) a.push(i); }); return a.length ? a : null; }

  function pickup(c, q) {
    const p = c.p, G = c.G, ei = G.entAt[q];
    if (ei < 0 || bget(c.tk, ei)) return;
    const e = G.ents[ei];
    if (e.k === '$') { const g = goldGain(p, e.v); p.g += g; bset(c.tk, ei); c.ev.push(['g', q, g]); }
    else if (e.k === '*') { const g = goldGain(p, e.v); p.g += g; bset(c.tk, ei); c.ev.push(['g', q, g, 1]); }
    else if (e.k === 'K') { p.k++; bset(c.tk, ei); c.ev.push(['K', q]); }
    else if (e.k === 'T') { p.tc += TORCH_ADD; bset(c.tk, ei); c.ev.push(['T', q]); }
    else if (e.k === 'I') { if (gainItem(c, e.v, q)) bset(c.tk, ei); }
    else if (e.k === 'X') { trap(c, ei, q); }
  }
  function gainItem(c, code, q) {
    const p = c.p, it = IT[code];
    if (it.k === 'w' || it.k === 'a') {
      const slot = it.k === 'w' ? 'w' : 'ar';
      const cur = p[slot] ? IT[p[slot]].v : 0;
      if (it.v > cur) { p[slot] = code; c.ev.push(['i', q, code, 1]); }
      else { p.g += 8; c.ev.push(['s', q, code]); }
      return true;
    }
    if (it.k === 'r' && !p.r) { equipRing(p, code); c.ev.push(['i', q, code, 1]); return true; }
    if (p.inv.length >= INV) { c.ev.push(['n', q, code]); return false; }
    p.inv += code; c.ev.push(['i', q, code]); return true;
  }
  function equipRing(p, code) {
    if (p.r === 'G') { p.mh -= 6; p.hp = Math.min(p.hp, p.mh); }
    p.r = code;
    if (code === 'G') { p.mh += 6; p.hp += 6; }
  }
  function trap(c, ei, q) {
    const p = c.p, ty = c.G.ents[ei].v;
    bset(c.tk, ei);
    c.ev.push(['X', q, ty]);
    if (ty === 0) hurt(c, 4, q);
    else if (ty === 1) { p.ps = Math.max(p.ps, 4); c.ev.push(['P']); }
    else if (ty === 2) { if (p.f < MAXF) { c.fall = 1; } else hurt(c, 3, q); }
    else if (ty === 3) teleport(c, 1);
    else if (ty === 4) { for (const m of c.mo) if (m.hp > 0 && m.t !== MIMIC && !(m.fl & 16)) m.fl |= 1; }
  }
  function teleport(c, salt) {
    const p = c.p, G = c.G;
    const opts = [];
    G.rooms.forEach((r, i) => { const q = r.cy * W + r.cx; if (i !== G.roomOf[p.x] && walk(c, q) && q !== G.keeper && monAt(c, q) < 0 && i !== G.vault) opts.push(q); });
    const reach = bfs(G.t, G.start, (q) => walk(c, q));
    const ok = opts.filter((q) => reach[q] >= 0);
    if (!ok.length) return;
    p.x = ok[hsh(c.s.sd, p.t, salt) % ok.length];
    c.ev.push(['Q', p.x, 1]);
  }
  function useItem(c, i) {
    const p = c.p, code = p.inv[i], it = IT[code];
    if (!it) throw new Error('no item');
    p.inv = p.inv.slice(0, i) + p.inv.slice(i + 1);
    c.ev.push(['u', p.x, code]);
    switch (code) {
      case 'a': p.hp = Math.min(p.mh, p.hp + 8); break;
      case 'b': p.hp = p.mh; break;
      case 'c': p.ps = 0; p.hp = Math.min(p.mh, p.hp + 3); break;
      case 'd': p.a++; break;
      case 'e': p.d++; break;
      case 'f': p.sh = 11; break;
      case 'n': p.hp = Math.min(p.mh, p.hp + 4); break;
      case 'g': {
        boom(c, p.x, 6, null);
        for (let d = 0; d < 4; d++) { const q = stepC(p.x, d); if (q >= 0 && c.G.t[q] === 2 && !doorOpen(c, q)) { bset(c.tk, c.G.entAt[q]); c.ev.push(['O', q]); } }
        break;
      }
      case 'h': for (let q = 0; q < N; q++) { const t = c.G.t[q]; if (t) bset(c.fog, q); else { for (let d = 0; d < 4; d++) { const nb = stepC(q, d); if (nb >= 0 && c.G.t[nb]) { bset(c.fog, q); break; } } } } break;
      case 'i': teleport(c, 2); break;
      case 'j': { const v = visOf(c, p.x); for (const m of c.mo) if (m.hp > 0 && v[m.p] && (m.fl & 1 || m.t !== MIMIC)) { m.hp -= 4; m.fl |= 1; c.ev.push(['h', m.p, 4]); if (m.hp <= 0) killMon(c, m); } break; }
      case 'k': { const v = visOf(c, p.x); for (const m of c.mo) if (m.hp > 0 && v[m.p]) { m.fl = (m.fl & ~14) | (3 << 1); c.ev.push(['h', m.p, 0]); } break; }
      case 'l': c.G.ents.forEach((e, ei) => { if (e.k === 'X') bset(c.tk, ei); if (!bget(c.tk, ei)) bset(c.fog, e.p); }); break;
      default: if (it.k === 'r') { const old = p.r; equipRing(p, code); if (old) p.inv = p.inv.slice(0, i) + old + p.inv.slice(i); } break;
    }
  }
  function search(c, r) {
    const p = c.p; let found = 0;
    c.G.ents.forEach((e, ei) => { if (e.k === 'X' && !bget(c.tk, ei) && cheb(e.p, p.x) <= r) { bset(c.tk, ei); found++; c.ev.push(['x', e.p]); } });
    return found;
  }
  function apply(s, seat, a) {
    const p = s.P[seat];
    if (!p || p.e || !a) throw new Error('not active');
    const c = ctxOf(s, p), G = c.G;
    p.ev = []; c.ev = p.ev;
    let moved = false, newFloor = 0;
    switch (a.t) {
      case 'm': {
        const d = a.d | 0; if (d < 0 || d > 3) throw new Error('dir');
        const q = stepC(p.x, d); if (q < 0) throw new Error('edge');
        const mi = monAt(c, q);
        if (mi >= 0) {
          const m = c.mo[mi], M = MT[m.t];
          if (m.t === MIMIC && !(m.fl & 1)) c.ev.push(['M', q]);
          m.fl |= 1;
          const dmg = Math.max(1, patk(p) - M.df);
          m.hp -= dmg; c.ev.push(['h', q, dmg]);
          if (m.hp <= 0) killMon(c, m);
          else if (M.b === 'boss' && !(m.fl & 32) && m.hp <= MT[BOSS].hp / 2) {
            m.fl |= 32; let k = 0;
            for (const r of c.mo) if (r.fl & 16 && r.hp === 0 && k < 2) {
              for (let dd = 0; dd < 4; dd++) { const nb = stepC(m.p, (dd + k * 2) & 3); if (nb >= 0 && mpass(c, nb) && nb !== p.x && monAt(c, nb) < 0) { r.p = nb; r.hp = MT[RAT].hp + 2; r.fl = 1; k++; break; } }
            }
            if (k) c.ev.push(['Y', m.p]);
          }
          break;
        }
        const t = G.t[q];
        if (t === 0 || t === 3) throw new Error('wall');
        if (t === 2 && !doorOpen(c, q)) {
          if (p.k <= 0) throw new Error('locked');
          p.k--; bset(c.tk, G.entAt[q]); c.ev.push(['O', q]);
          break;
        }
        const ei = G.entAt[q];
        if (ei >= 0 && G.ents[ei].k === 'C' && !bget(c.tk, ei)) {
          bset(c.tk, ei); const v = G.ents[ei].v;
          c.ev.push(['C', q]);
          if (v === '*') { const g = goldGain(p, 40); p.g += g; c.ev.push(['g', q, g, 1]); }
          else if (!gainItem(c, v, q)) { p.g += 10; c.ev.push(['g', q, 10]); }
          break;
        }
        p.x = q; moved = true;
        pickup(c, q);
        break;
      }
      case 'w': {
        const f = search(c, 2);
        const v = visOf(c, p.x);
        const threat = c.mo.some((m) => m.hp > 0 && (m.fl & 1) && v[m.p] && MT[m.t].b !== 'guard');
        if (!threat && p.hp < p.mh) { p.hp++; c.ev.push(['r']); }
        c.ev.push(['z', p.x, f]); p.sq = p.x;
        break;
      }
      case 'u': useItem(c, a.i | 0); break;
      case 'b': {
        const ei = G.entAt[p.x];
        if (ei < 0 || G.ents[ei].k !== 'S' || bget(c.tk, ei)) throw new Error('no shop');
        const code = G.ents[ei].v, pr = IT[code].pr;
        if (p.g < pr) throw new Error('gold');
        const isInv = !'wa'.includes(IT[code].k) && !(IT[code].k === 'r' && !p.r);
        if (isInv && p.inv.length >= INV) throw new Error('full');
        p.g -= pr; bset(c.tk, ei); gainItem(c, code, p.x); c.ev.push(['$', p.x, pr]);
        break;
      }
      case 'd': {
        if (p.x !== G.stairs) throw new Error('no stairs');
        if (p.f < MAXF) newFloor = p.f + 1;
        else {
          if (c.mo.some((m) => m.t === BOSS && m.hp > 0)) throw new Error('boss alive');
          p.e = 3; c.ev.push(['e', 3]);
        }
        break;
      }
      case 'q': p.e = 4; c.ev.push(['e', 4]); break;
      default: throw new Error('bad action');
    }
    p.ls = a.t;
    p.t++; p.tc--;
    if (!p.e && !newFloor && !c.fall) {
      if (p.r === 'J') search(c, 1);
      monPhase(c);
    }
    if (!p.e && p.ps > 0) { p.ps--; if (p.hp > 1) { p.hp--; c.ev.push(['d', -1, 1]); } }
    if (p.sh > 0) p.sh--;
    if (c.fall && !p.e) { hurt(c, 3, p.x); if (!p.e) newFloor = p.f + 1; c.ev.push(['F']); }
    if (!p.e) {
      if (newFloor) { save(c); enterFloor(s, p, newFloor); c.ev.push(['v', newFloor]); }
      else { revealFog(c, visOf(c, p.x)); save(c); }
    } else save(c);
    if (!p.e && p.tc <= 0) { p.e = 2; p.ev.push(['e', 2]); }
    if (p.ev.length > 10) p.ev.splice(0, p.ev.length - 10);
    p.eid++;
    void moved;
    return s;
  }

  function result(s) {
    if (s.P.some((p) => !p.e)) return null;
    const sc = s.P.map(score);
    const best = Math.max(...sc);
    const st = ['', '쓰러짐(금화 절반)', '횃불 꺼짐', '탈출 성공!', '중간에 나감'];
    const lines = s.P.map((p, i) => ((s.nm && s.nm[i]) || '#' + (i + 1)) + ' ' + sc[i] + '점 · ' + p.mx + '층 · 금화 ' + p.g + ' · ' + p.t + '턴 · ' + st[p.e]);
    if (s.n === 1) {
      const p = s.P[0], stars = starsOf(p);
      return { winners: stars ? [0] : [], title: (stars ? '★'.repeat(stars) + '☆'.repeat(3 - stars) : '☆☆☆') + ' 탐험 끝', text: lines[0].slice(lines[0].indexOf(' ') + 1) + '\n★ 3층 도착 · ★★ 보스 쓰러뜨리고 탈출 · ★★★ 탈출 + 금화 250 이상' + (s.dy ? '\n(오늘의 던전)' : '') };
    }
    // tie → fewer turns
    let win = [];
    s.P.forEach((p, i) => { if (sc[i] === best) win.push(i); });
    if (win.length > 1) { const mt = Math.min(...win.map((i) => s.P[i].t)); win = win.filter((i) => s.P[i].t === mt); }
    return { winners: win, text: lines.join('\n') };
  }
  function starsOf(p) { return p.e === 3 ? (p.g >= 250 ? 3 : 2) : p.mx >= 3 ? 1 : 0; }

  /* ======================= rival AI (uses only what that player can see) ======================= */
  function ai(s, seat, lv) {
    lv = lv || 2;
    const p = s.P[seat]; if (!p || p.e) return null;
    const c = ctxOf(s, p), G = c.G, P = p.x;
    const v = visOf(c, P);
    const known = (q) => bget(c.fog, q) === 1;
    const rnd = (k) => (hsh(s.sd + seat * 977, p.t, k) % 1000) / 1000;
    const mons = [];
    c.mo.forEach((m, i) => { if (m.hp > 0 && v[m.p] && !(m.t === MIMIC && !(m.fl & 1)) && !(m.fl & 16 && m.hp === 0)) mons.push(i); });
    const awake = mons.filter((i) => c.mo[i].fl & 1);
    const inv = p.inv;
    const has = (ch) => inv.indexOf(ch);
    const use = (ch) => ({ t: 'u', i: inv.indexOf(ch) });
    const hpR = p.hp / p.mh;
    const trapKnown = (q) => { const ei = G.entAt[q]; return ei >= 0 && G.ents[ei].k === 'X' && bget(c.tk, ei); };
    const dangerT = new Uint8Array(N);
    // tiles about to be hit
    const dist0 = bfs(G.t, P, (q) => mpass(c, q));
    if (lv >= 2) {
      c.mo.forEach((m, i) => {
        if (m.hp <= 0 || !(m.fl & 1)) return;
        const it = intent(c, i, p.t + 1, dist0);
        if (it.k === 'boom' || it.k === 'slam') for (let q = 0; q < N; q++) if (cheb(q, m.p) <= 1) dangerT[q] = 1;
        if (it.k === 'chg') { let q = m.p; for (let k = 0; k < 7; k++) { q = stepC(q, it.d); if (q < 0 || !mpass(c, q)) break; dangerT[q] = 1; } }
        if (MT[m.t].b === 'guard' && !(Math.ceil(m.hp / Math.max(1, patk(p) - MT[m.t].df)) * Math.max(1, MT[m.t].at - pdef(p)) < p.hp - 4)) for (let k = 0; k < 4; k++) { const q = stepC(m.p, k); if (q >= 0) dangerT[q] = 1; }
        if (lv >= 3 && it.k === 'prime') for (let q = 0; q < N; q++) if (cheb(q, m.p) <= 1) dangerT[q] = 1;
      });
    }
    // 1. healing
    const thr = lv === 1 ? 0.25 : lv === 2 ? 0.4 : 0.5;
    if (hpR <= thr) {
      for (const ch of lv >= 3 && p.mh - p.hp >= 12 ? 'ban' : 'anb') if (has(ch) >= 0 && (ch !== 'b' || hpR < 0.4 || lv < 3)) return use(ch);
      if (p.ps > 1 && has('c') >= 0) return use('c');
    }
    if (p.ps > 2 && has('c') >= 0 && lv >= 2) return use('c');
    // permanent buffs / rings
    if (lv >= 2 || rnd(1) < 0.3) {
      if (has('d') >= 0) return use('d');
      if (has('e') >= 0) return use('e');
      for (const r of 'GHIJ') if (has(r) >= 0 && (!p.r || (lv >= 3 && r === 'G' && p.r !== 'G'))) return use(r);
    }
    // 2. dodge danger
    if (dangerT[P] && lv >= 2) {
      let best = -1, bs = -1e9;
      for (let d = 0; d < 4; d++) { const q = stepC(P, d); if (q < 0 || !walk(c, q) || q === G.keeper || monAt(c, q) >= 0 || trapKnown(q)) continue; const sc = (dangerT[q] ? -100 : 0) + (lv >= 3 ? -awake.filter((i) => man(c.mo[i].p, q) === 1).length * 5 : 0); if (sc > bs) { bs = sc; best = d; } }
      if (best >= 0 && bs > -100) return { t: 'm', d: best };
    }
    // 3. fights
    const myD = (m) => Math.max(1, patk(p) - MT[m.t].df);
    const itD = (m) => { const M = MT[m.t]; if (M.b === 'thief' || M.b === 'bloat') return 0; let d = Math.max(1, M.at - pdef(p)); if (M.b === 'slow' || M.b === 'ghost' || M.b === 'hop') d /= 2; return d; };
    const adjM = awake.filter((i) => man(c.mo[i].p, P) === 1);
    if (lv >= 2 && awake.length >= 3 && has('j') >= 0) return use('j');
    if (lv >= 3 && awake.length >= 2 && adjM.length >= 2 && has('g') >= 0) return use('g');
    if (adjM.length) {
      adjM.sort((a, b) => c.mo[a].hp / myD(c.mo[a]) - c.mo[b].hp / myD(c.mo[b]));
      const m = c.mo[adjM[0]];
      const hits = Math.ceil(m.hp / myD(m));
      const take = adjM.reduce((sum, i) => sum + itD(c.mo[i]), 0) * (hits - 1);
      const ok = p.hp - take > (lv >= 3 ? 3 : 1);
      if (MT[m.t].b === 'bloat' && lv >= 2 && hits > 1) { /* step away instead */ }
      else if (ok || lv === 1) return { t: 'm', d: dirTo(P, m.p) };
      else {
        if (m.t === BOSS && lv >= 2 && has('k') >= 0) return use('k');
        if (has('g') >= 0 && m.hp <= 6) return use('g');
        if (has('j') >= 0 && m.hp <= 4) return use('j');
        if (has('f') >= 0) return use('f');
        if (has('i') >= 0 && lv >= 3) return use('i');
        if (m.t === BOSS && lv >= 3 && hpR < 0.25) return { t: 'q' };
        // flee
        let best = -1, bd = 0;
        for (let d = 0; d < 4; d++) { const q = stepC(P, d); if (q < 0 || !walk(c, q) || q === G.keeper || monAt(c, q) >= 0 || trapKnown(q)) continue; const sc = Math.min(...adjM.map((i) => man(c.mo[i].p, q))); if (sc > bd) { bd = sc; best = d; } }
        if (best >= 0 && (lv >= 2 ? rnd(2) < 0.7 : rnd(2) < 0.35)) return { t: 'm', d: best };
        return { t: 'm', d: dirTo(P, m.p) };
      }
    }
    // 4. stairs / shop
    const stairsKnown = known(G.stairs);
    const bossAlive = c.mo.some((m) => m.t === BOSS && m.hp > 0);
    const spent = p.t - p.ft, budget = Math.max(40, (p.fe - 25) / (MAXF - p.f + 1));
    const lowTorch = spent > budget * (lv === 1 ? 0.7 : lv === 2 ? 1.0 : 1.1);
    if (P === G.stairs) {
      if (p.f === MAXF) { if (!bossAlive) return { t: 'd' }; }
      else {
        const wantNow = lv === 1 ? rnd(3) < 0.6 || lowTorch : lowTorch;
        if (wantNow) return { t: 'd' };
      }
    }
    {
      const ei = G.entAt[P];
      if (ei >= 0 && G.ents[ei].k === 'S' && !bget(c.tk, ei) && lv >= 2) {
        const code = G.ents[ei].v, it = IT[code];
        const useful = (it.k === 'w' && (!p.w || IT[p.w].v < it.v)) || (it.k === 'a' && (!p.ar || IT[p.ar].v < it.v)) || (it.k === 'r' && !p.r) || ('abdeg'.includes(code) && inv.length < INV);
        if (useful && p.g >= it.pr + (lv >= 3 ? 0 : 10)) return { t: 'b' };
      }
    }
    // 5. search near clues
    if (lv >= 2 && p.ls !== 'w' && !awake.length && (p.sq < 0 || cheb(p.sq, P) > 1)) {
      let near = false;
      for (let q = 0; q < N && !near; q++) if (G.clues[q] >= 0 && cheb(q, P) <= 1) near = true;
      if (near && (lv >= 3 || rnd(4) < 0.5)) return { t: 'w' };
    }
    // rest when hurt and safe (lv2/3)
    if (lv >= 2 && !awake.length && hpR < 0.45 && p.tc > (MAXF - p.f + 1) * 40 + 30 && rnd(5) < 0.9) return { t: 'w' };
    // 6. navigation (first avoiding known traps, then allowing them)
    let bestQ = -1, par = null;
    for (let soft = 0; soft < 2 && bestQ < 0; soft++) {
      const avoid = (q) => (!soft && trapKnown(q)) || (lv >= 2 && dangerT[q]);
      const passK = (q) => known(q) && walk(c, q) && q !== G.keeper && !avoid(q) && !(monAt(c, q) >= 0);
      const d = new Int16Array(N).fill(-1), pr = new Int16Array(N).fill(-1), q2 = new Int16Array(N);
      let hh = 0, ee = 0; d[P] = 0; q2[ee++] = P;
      const tgt = [];
      const bumpOK = (q) => {
        if (!known(q)) return 0;
        const ei = G.entAt[q];
        if (ei >= 0 && G.ents[ei].k === 'C' && !bget(c.tk, ei)) return 20;
        if (G.t[q] === 2 && !doorOpen(c, q) && p.k > 0) return 30;
        const mi = monAt(c, q);
        if (mi >= 0) { const m = c.mo[mi]; if (m.t === MIMIC && !(m.fl & 1)) return 20; if (MT[m.t].b === 'thief' && m.st > 0) return 35; if (m.fl & 1 && lv >= 2 && Math.ceil(m.hp / myD(m)) * itD(m) < p.hp - 4) return 'archer caster'.includes(MT[m.t].b) ? (lv >= 3 ? 40 : 25) : 6; if (!(m.fl & 1) && lv >= 3 && m.t !== GUARD && Math.ceil(m.hp / myD(m)) <= 1) return 8; }
        return 0;
      };
      while (hh < ee) {
        const q = q2[hh++];
        for (let k = 0; k < 4; k++) {
          const nb = stepC(q, k); if (nb < 0 || d[nb] >= 0) continue;
          if (passK(nb)) { d[nb] = d[q] + 1; pr[nb] = q; q2[ee++] = nb; }
          else { const bv = bumpOK(nb); if (bv) { d[nb] = d[q] + 1; pr[nb] = q; tgt.push([nb, bv]); } }
        }
      }
      const val = (q) => {
        const ei = G.entAt[q];
        let vv = 0;
        if (ei >= 0 && !bget(c.tk, ei)) {
          const e = G.ents[ei];
          if (e.k === '$') vv = e.v; else if (e.k === '*') vv = 40; else if (e.k === 'K') vv = 30; else if (e.k === 'T') vv = 30;
          else if (e.k === 'I') vv = inv.length < INV || 'wa'.includes(IT[e.v].k) ? 16 : 0;
          else if (e.k === 'S' && lv >= 2) { const it = IT[e.v]; vv = p.g >= it.pr + 10 && ((it.k === 'w' && (!p.w || IT[p.w].v < it.v)) || (it.k === 'a' && (!p.ar || IT[p.ar].v < it.v)) || ('abg'.includes(e.v) && inv.length < INV)) ? 18 : 0; }
        }
        // frontier
        if (!vv) { for (let k = 0; k < 4; k++) { const nb = stepC(q, k); if (nb >= 0 && !known(nb)) { vv = 7; break; } } }
        return vv;
      };
      let wantStairs = stairsKnown && (lowTorch || (p.f === MAXF && !bossAlive));
      bestQ = -1; let bestS = -1e9;
      const consider = (q, vv) => {
        if (vv <= 0) return;
        const dd = d[q];
        let sc;
        if (lv === 3) sc = vv / (dd + 3) + rnd(q + 500) * 0.05;
        else if (lv === 2) sc = Math.min(vv, 20) / (dd + 2) + (vv >= 7 ? 0.2 : 0) - dd * 0.01 + rnd(q + 500) * 0.15;
        else sc = 1 / (dd + 1) + rnd(q) * 0.3;
        if (sc > bestS) { bestS = sc; bestQ = q; }
      };
      if (!wantStairs) {
        for (let q = 0; q < N; q++) if (d[q] > 0 && passK(q)) consider(q, val(q));
        for (const [q, bv] of tgt) consider(q, bv);
        if (bestQ < 0 && stairsKnown) wantStairs = true;
      }
      if (wantStairs) {
        if (P === G.stairs) { if (p.f < MAXF) return { t: 'd' }; }
        else if (d[G.stairs] > 0) bestQ = G.stairs;
        else if (p.f === MAXF && bossAlive) {
          // go hit the boss
          const bi = c.mo.findIndex((m) => m.t === BOSS && m.hp > 0);
          if (bi >= 0 && d[c.mo[bi].p] > 0) bestQ = c.mo[bi].p;
        }
        if (bestQ < 0) { for (const [q, bv] of tgt) consider(q, bv); for (let q = 0; q < N; q++) if (d[q] > 0 && passK(q)) consider(q, val(q)); }
      }
      if (bestQ < 0 && p.f === MAXF && bossAlive) {
        const bi = c.mo.findIndex((m) => m.t === BOSS && m.hp > 0);
        if (bi >= 0) { const bm = c.mo[bi]; if (known(bm.p)) { for (let k = 0; k < 4; k++) { const nb = stepC(bm.p, k); if (nb >= 0 && d[nb] > 0) { bestQ = nb; break; } } } }
      }
      par = pr;
    }
    if (bestQ < 0) {
      // stuck: locked door without key → bomb it; else wander/wait
      if (has('g') >= 0) for (let k = 0; k < 4; k++) { const q = stepC(P, k); if (q >= 0 && G.t[q] === 2 && !doorOpen(c, q)) return use('g'); }
      if (has('h') >= 0) return use('h');
      if (has('i') >= 0) return use('i');
      if (lv >= 2 && p.mx >= 2 && p.tc < 30) return { t: 'q' };
      const opts = [];
      for (let k = 0; k < 4; k++) { const q = stepC(P, k); if (q >= 0 && walk(c, q) && q !== G.keeper && monAt(c, q) < 0 && !trapKnown(q)) opts.push(k); }
      if (opts.length && rnd(6) < 0.6) return { t: 'm', d: opts[Math.floor(rnd(7) * opts.length)] };
      return { t: 'w' };
    }
    // lv1 noise
    if (lv === 1 && rnd(8) < 0.12) {
      const opts = [];
      for (let k = 0; k < 4; k++) { const q = stepC(P, k); if (q >= 0 && walk(c, q) && q !== G.keeper && monAt(c, q) < 0) opts.push(k); }
      if (opts.length) return { t: 'm', d: opts[Math.floor(rnd(9) * opts.length)] };
    }
    // use map scroll early on new floor
    if (has('h') >= 0 && lv >= 2 && p.t - p.ft < 3) return use('h');
    let q = bestQ;
    while (par[q] !== P && par[q] >= 0) q = par[q];
    if (par[q] < 0 && q !== bestQ) return { t: 'w' };
    const dd = dirTo(P, q);
    if (dd < 0) return { t: 'w' };
    return { t: 'm', d: dd };
  }
  function aiDelayFor(s, seat, lv) {
    const humanOn = s.P.some((p, i) => !p.e && !s.ai[i]);
    if (!humanOn) return 60;
    return 300 + (3 - (lv || 2)) * 60;
  }

  /* ======================= view ======================= */
  const CSS = `
.dg-top{flex-direction:column;align-items:stretch;gap:5px;padding:6px 8px;pointer-events:none}
.dg-stats{display:flex;align-items:center;gap:6px;padding:5px 8px;font-weight:700;font-size:13px;flex-wrap:nowrap;min-width:0}
.dg-hp{position:relative;flex:1 1 70px;min-width:56px;height:20px;border-radius:7px;background:#3a1e26;overflow:hidden;border:1px solid rgba(255,255,255,.12)}
.dg-hp>i{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(#f0687a,#c23a4e);transition:width .2s}
.dg-hp>b{position:relative;display:block;text-align:center;font:700 12px/20px var(--f-mono);color:#fff;text-shadow:0 1px 2px #000}
.dg-chip{display:inline-flex;align-items:center;gap:2px;font:700 12px var(--f-mono);white-space:nowrap;flex:none}
.dg-fl{font-family:var(--f-display);color:var(--brass);font-size:15px;flex:none;margin-right:2px}
.dg-rivals{display:flex;gap:5px;flex-wrap:wrap;justify-content:center}
.dg-rv{display:inline-flex;align-items:center;gap:4px;font:600 11px var(--f-body);background:rgba(23,19,31,.78);border:1px solid var(--line);border-radius:9px;padding:2px 7px;white-space:nowrap}
.dg-rv.me{border-color:var(--brass)}
.dg-msg{position:absolute;left:8px;right:8px;text-align:center;font-size:13px;font-weight:600;pointer-events:none;color:var(--ink);text-shadow:0 1px 3px #000,0 0 8px #000;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dg-bot{position:absolute;left:0;right:0;bottom:0;display:flex;justify-content:center;align-items:flex-end;gap:12px;padding:6px 8px 8px;background:linear-gradient(transparent,rgba(13,10,18,.92) 22%)}
.dg-left{display:flex;flex-direction:column;gap:5px}
.dg-inv{display:grid;grid-template-columns:repeat(3,46px);gap:4px}
.dg-slot{width:46px;height:46px;border-radius:10px;border:1px solid var(--line);background:#241d30;display:grid;place-items:center;padding:0;font-size:24px;cursor:pointer;touch-action:manipulation;color:var(--ink)}
.dg-slot svg{width:30px;height:30px}
.dg-slot.empty{opacity:.35;cursor:default}
.dg-slot.sel{border-color:var(--brass);box-shadow:0 0 0 2px var(--brass) inset}
.dg-act{display:grid;grid-template-columns:1fr 1fr;gap:4px;width:146px}
.dg-act .btn{min-height:46px;padding:0 4px;font-size:13px;border-radius:10px}
.dg-pad{display:grid;grid-template-columns:repeat(3,48px);grid-template-rows:repeat(3,48px);gap:3px}
.dg-pad .btn{min-height:48px;width:48px;padding:0;font-size:20px;border-radius:12px;background:#2c2340}
.dg-pad .btn.mid{font-size:12px;background:#3a2f22;color:var(--brass)}
.dg-card{position:absolute;left:10px;right:10px;padding:10px 12px;display:flex;flex-direction:column;gap:8px;z-index:6;font-size:14px;line-height:1.45;max-height:46%;overflow:auto}
.dg-card h4{margin:0;font-size:15px;display:flex;align-items:center;gap:6px}
.dg-card p{margin:0;white-space:pre-line;color:var(--ink)}
.dg-card .row{display:flex;gap:8px;justify-content:flex-end}
.dg-pass{position:absolute;inset:0;z-index:8;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:rgba(13,10,18,.96);text-align:center;padding:20px}
.dg-pass .big{font-family:var(--f-display);font-size:26px}
.dg-spec{display:flex;flex-direction:column;align-items:center;gap:6px;padding:4px 0;min-width:0;max-width:100%}
.dg-spec .muted{font-size:13px;text-align:center}
`;
  function potionSVG(c) { return '<svg viewBox="0 0 24 24"><rect x="9" y="1.5" width="6" height="4" rx="1" fill="#b58a5a"/><path d="M9.5 5.5h5v3.2l4.2 5.4a6.8 6.8 0 1 1-13.4 0l4.2-5.4z" fill="' + c + '" stroke="#1b1426" stroke-width="1"/><ellipse cx="9.5" cy="15" rx="1.6" ry="2.4" fill="rgba(255,255,255,.45)"/></svg>'; }
  function scrollSVG(c) { return '<svg viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="14" rx="2" fill="#efe0b8" stroke="#8a6a3a"/><path d="M7 9h9M7 12h7" stroke="#8a6a3a" stroke-width="1.3"/><circle cx="16.5" cy="15.5" r="3" fill="' + c + '" stroke="#1b1426" stroke-width=".8"/></svg>'; }
  function itemHTML(code) { const it = IT[code]; if (!it) return ''; if (it.k === 'p') return potionSVG(it.c); if (it.k === 's') return scrollSVG(it.c); return '<span>' + it.e + '</span>'; }

  function mount(root, api) {
    if (!document.getElementById('dg-style')) { const st = document.createElement('style'); st.id = 'dg-style'; st.textContent = CSS; document.head.appendChild(st); }
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, seat = 0, watch = -1, passSeat = -1, passFloor = 0, passAck = -1;
    let mapMode = false, card = null, walkPath = null, walkTimer = 0, pend = null;
    let anim = null, floats = [], flashes = [], shots = [], lastDraw = 0, dirty = true;
    const seenEid = {}, seenF = {}, seenE = {};
    let msgText = '', cache = { key: '', c: null, v: null, dist: null };
    const sp = () => (L.debug.speed || 1);

    /* ---- DOM ---- */
    const top = L.h('div', { class: 'hud top dg-top' });
    const stats = L.h('div', { class: 'panel dg-stats' });
    const rivals = L.h('div', { class: 'dg-rivals' });
    top.append(stats, rivals);
    const msg = L.h('div', { class: 'dg-msg' });
    const bot = L.h('div', { class: 'dg-bot' });
    const left = L.h('div', { class: 'dg-left' });
    const invEl = L.h('div', { class: 'dg-inv' });
    const slots = [];
    for (let i = 0; i < INV; i++) { const b = L.h('button', { class: 'dg-slot empty', 'aria-label': '가방 ' + (i + 1) }); b.addEventListener('click', () => onSlot(i)); slots.push(b); invEl.append(b); }
    const actRow = L.h('div', { class: 'dg-act' });
    const mapBtn = L.h('button', { class: 'btn', text: '🗺 지도' });
    const ctxBtn = L.h('button', { class: 'btn', text: '🏳 나가기' });
    actRow.append(mapBtn, ctxBtn);
    left.append(invEl, actRow);
    const pad = L.h('div', { class: 'dg-pad' });
    const padBtns = [];
    const cell = (txt, d, cls) => { const b = L.h('button', { class: 'btn' + (cls ? ' ' + cls : ''), text: txt, 'aria-label': d >= 0 ? DIRN[d] + '로' : '살피기' }); return b; };
    const blank = () => L.h('span');
    const bU = cell('▲', 0), bL = cell('◀', 3), bR = cell('▶', 1), bD = cell('▼', 2), bW = cell('살피기', -1, 'mid');
    pad.append(blank(), bU, blank(), bL, bW, bR, blank(), bD, blank());
    [[bU, 0], [bR, 1], [bD, 2], [bL, 3]].forEach(([b, d]) => { padBtns.push(b); holdRepeat(b, () => doMove(d)); });
    bW.addEventListener('click', () => { if (myTurnSeat() >= 0) { stopWalk(); send({ t: 'w' }); } });
    const spec = L.h('div', { class: 'dg-spec', hidden: true });
    bot.append(left, pad, spec);
    const cardEl = L.h('div', { class: 'panel dg-card', hidden: true });
    const passEl = L.h('div', { class: 'dg-pass', hidden: true });
    root.append(top, msg, bot, cardEl, passEl);
    mapBtn.addEventListener('click', () => { mapMode = !mapMode; mapBtn.textContent = mapMode ? '✕ 닫기' : '🗺 지도'; msg.style.visibility = mapMode ? 'hidden' : ''; closeCard(); dirty = true; api.sfx('click'); });
    ctxBtn.addEventListener('click', onCtx);

    function holdRepeat(b, fn) {
      let t1 = 0, t2 = 0;
      const stop = () => { clearTimeout(t1); clearInterval(t2); };
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); fn(); stop(); t1 = setTimeout(() => { t2 = setInterval(fn, 170); }, 380); });
      ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => b.addEventListener(ev, stop));
      b._stop = stop;
    }

    /* ---- seat selection (local humans, pass play, spectating) ---- */
    function localActive() { if (!st) return []; return api.mySeats().filter((i) => st.P[i] && !st.P[i].e); }
    function pickSeat() {
      const mine = localActive();
      if (mine.length === 1) { if (api.mySeats().length > 1 && passSeat >= 0 && passSeat !== mine[0]) { passSeat = mine[0]; passFloor = st.P[mine[0]].f; showPass(mine[0]); } passSeat = mine[0]; return mine[0]; }
      if (mine.length > 1) {
        if (!(mine.includes(passSeat) && st.P[passSeat].f === passFloor)) {
          const sorted = mine.slice().sort((a, b) => st.P[a].f - st.P[b].f || st.P[a].t - st.P[b].t || a - b);
          const nx = sorted[0], was = passSeat;
          passSeat = nx; passFloor = st.P[nx].f;
          if (nx !== was) showPass(nx);
        }
        return passSeat;
      }
      // nobody local active → spectate
      const alive = st.P.map((p, i) => (!p.e ? i : -1)).filter((i) => i >= 0);
      if (watch < 0 || watch >= st.n) { const m = api.mySeats(); watch = m.length ? m[0] : 0; }
      if (st.P[watch].e && alive.length && !api.mySeats().includes(watch)) watch = alive[0];
      return watch;
    }
    function showPass(i) {
      stopWalk();
      passAck = -1;
      passEl.innerHTML = '';
      passEl.append(L.h('span', { class: 'dot', style: { '--c': api.players[i].color, width: '18px', height: '18px' } }),
        L.h('div', { class: 'big', text: api.players[i].name }),
        L.h('div', { class: 'muted', text: '지하 ' + st.P[i].f + '층 탐험 차례예요. 폰을 넘겨 주세요.' }),
        L.h('button', { class: 'btn primary', text: '시작하기', onclick() { passAck = i; passEl.hidden = true; api.sfx('click'); render(); } }));
      passEl.hidden = false;
    }
    function myTurnSeat() { if (!st || !passEl.hidden) return -1; const mine = localActive(); return mine.includes(seat) ? seat : -1; }
    function send(a) { const s0 = myTurnSeat(); if (s0 < 0) return false; pend = { eid: st.P[s0].eid, at: performance.now() }; api.actAs(s0, a); return true; }

    /* ---- context helpers ---- */
    function ctxFor(sti, s0) {
      const key = s0 + ':' + sti.P[s0].eid + ':' + sti.P[s0].f + ':' + sti.P[s0].mo + ':' + sti.P[s0].tk + ':' + sti.P[s0].x;
      if (cache.key === key && cache.st === sti) return cache;
      const c = ctxOf(sti, sti.P[s0]);
      const v = visOf(c, sti.P[s0].x);
      const dist = bfs(c.G.t, sti.P[s0].x, (q) => mpass(c, q));
      cache = { key, st: sti, c, v, dist };
      return cache;
    }
    const known = (c, q) => bget(c.fog, q) === 1;

    /* ---- actions ---- */
    function doMove(d) {
      const s0 = myTurnSeat(); if (s0 < 0) return;
      stopWalk(); closeCard();
      if (mapMode) { mapMode = false; mapBtn.textContent = '🗺 지도'; msg.style.visibility = ''; }
      const { c } = ctxFor(st, s0), p = st.P[s0];
      const q = stepC(p.x, d);
      if (q < 0) { api.buzz(8); return; }
      if (monAt(c, q) < 0) {
        const t = c.G.t[q];
        if (t === 0 || t === 3) { api.buzz(8); if (t === 3) say('부엉이 상인이에요. 물건 위에 서서 「사기」를 눌러요.'); return; }
        if (t === 2 && !doorOpen(c, q) && p.k <= 0) { api.toast('잠긴 문 — 열쇠 🗝 가 필요해요'); api.buzz(20); return; }
      }
      if (pend && pend.eid === p.eid && performance.now() - pend.at < 450) return; // wait for the previous step to arrive
      send({ t: 'm', d });
    }
    function onSlot(i) {
      const s0 = seat; if (!st) return;
      const p = st.P[s0], code = p.inv[i];
      if (!code) return;
      api.sfx('click');
      const it = IT[code];
      const canUse = myTurnSeat() >= 0;
      openCard(itemHTML(code), it.n, it.d + (it.k === 'r' && p.r ? '\n(지금 낀 ' + IT[p.r].n + '와 바꿔 껴요)' : ''), canUse ? [['쓰기', () => { closeCard(); stopWalk(); send({ t: 'u', i }); }, true]] : [], i);
    }
    function onCtx() {
      const s0 = myTurnSeat(); if (s0 < 0) return;
      const { c } = ctxFor(st, s0), p = st.P[s0], G = c.G;
      api.sfx('click');
      const ei = G.entAt[p.x];
      if (p.x === G.stairs) {
        if (p.f < MAXF) { stopWalk(); send({ t: 'd' }); return; }
        if (c.mo.some((m) => m.t === BOSS && m.hp > 0)) { api.toast('잿빛 군주를 쓰러뜨려야 문이 열려요'); return; }
        send({ t: 'd' }); return;
      }
      if (ei >= 0 && G.ents[ei].k === 'S' && !bget(c.tk, ei)) {
        const code = G.ents[ei].v, it = IT[code];
        if (p.g < it.pr) { api.toast('금화가 모자라요 (' + it.pr + ' 필요)'); return; }
        const isInv = !'wa'.includes(it.k) && !(it.k === 'r' && !p.r);
        if (isInv && p.inv.length >= INV) { api.toast('가방이 가득 찼어요'); return; }
        send({ t: 'b' }); return;
      }
      openCard('<span>🏳</span>', '던전에서 나갈까요?', '지금 가진 금화 ' + p.g + '를 그대로 들고 나가요.\n(탈출 보너스 150점은 못 받아요. 다시 들어올 수 없어요)', [['나가기', () => { closeCard(); send({ t: 'q' }); }, false]]);
    }
    function stopWalk() { walkPath = null; clearTimeout(walkTimer); }
    function startWalk(target) {
      const s0 = myTurnSeat(); if (s0 < 0) return;
      const { c, v } = ctxFor(st, s0), p = st.P[s0];
      const trapKnown = (q) => { const ei = c.G.entAt[q]; return ei >= 0 && c.G.ents[ei].k === 'X' && bget(c.tk, ei) === 1; };
      const pass = (q) => known(c, q) && walk(c, q) && q !== c.G.keeper && !trapKnown(q) && !(monAt(c, q) >= 0 && v[q]);
      if (!pass(target) && target !== p.x) { // bump targets: walk next to them
        let best = -1, bd = 1e9; const d = bfs(c.G.t, p.x, pass);
        for (let k = 0; k < 4; k++) { const nb = stepC(target, k); if (nb >= 0 && d[nb] >= 0 && d[nb] < bd) { bd = d[nb]; best = nb; } }
        if (best < 0) { say('거기로 가는 길을 몰라요'); return; }
        target = best;
      }
      const d = bfs(c.G.t, target, pass);
      if (d[p.x] < 0) { say('거기로 가는 길을 몰라요'); return; }
      const path = []; let q = p.x;
      while (q !== target) { let nx = -1; for (let k = 0; k < 4; k++) { const nb = stepC(q, k); if (nb >= 0 && d[nb] === d[q] - 1) { nx = nb; break; } } if (nx < 0) break; path.push(nx); q = nx; }
      if (!path.length) return;
      walkPath = { seat: s0, path, awake: awakeCount(s0), hp: p.hp };
      walkStep();
    }
    function awakeCount(s0) { const { c, v } = ctxFor(st, s0); return c.mo.filter((m) => m.hp > 0 && v[m.p] && (m.fl & 1)).length; }
    function walkStep() {
      if (!walkPath || myTurnSeat() !== walkPath.seat) { stopWalk(); return; }
      const p = st.P[walkPath.seat];
      const nx = walkPath.path.shift();
      if (nx == null) { stopWalk(); return; }
      const d = dirTo(p.x, nx);
      if (d < 0) { stopWalk(); return; }
      if (!walkPath.path.length) walkPath.last = true;
      send({ t: 'm', d });
    }
    function continueWalk() {
      if (!walkPath) return;
      const p = st.P[walkPath.seat];
      if (!p || p.e || walkPath.last) { stopWalk(); return; }
      const bad = (p.ev || []).some((e) => 'dwXMtSBvQF'.includes(e[0]));
      const aw = awakeCount(walkPath.seat);
      if (bad || aw > walkPath.awake || p.hp < walkPath.hp) { stopWalk(); return; }
      walkPath.awake = aw; walkPath.hp = p.hp;
      clearTimeout(walkTimer);
      walkTimer = setTimeout(walkStep, 95 / sp());
    }

    /* ---- card (inspect / item) ---- */
    function openCard(iconHTML, title, text, buttons, sel) {
      cardEl.innerHTML = '';
      const h4 = L.h('h4'); const ic = L.h('span', { style: { display: 'inline-grid', width: '28px', height: '28px', placeItems: 'center', fontSize: '22px' } }); ic.innerHTML = iconHTML || ''; ic.querySelector('svg') && (ic.querySelector('svg').style.width = '26px');
      h4.append(ic, L.h('span', { text: title }));
      const row = L.h('div', { class: 'row' });
      (buttons || []).forEach(([t, fn, primary]) => row.append(L.h('button', { class: 'btn' + (primary ? ' primary' : ' danger'), text: t, onclick: fn })));
      row.append(L.h('button', { class: 'btn ghost', text: '닫기', onclick: closeCard }));
      cardEl.append(h4, L.h('p', { text }), row);
      cardEl.hidden = false;
      card = { sel };
      slots.forEach((b, i) => b.classList.toggle('sel', sel === i));
      placeCard();
    }
    function closeCard() { cardEl.hidden = true; card = null; slots.forEach((b) => b.classList.remove('sel')); }
    function placeCard() { cardEl.style.bottom = (bot.offsetHeight + 6) + 'px'; }

    function describe(q) {
      const s0 = seat, p = st.P[s0];
      const { c, v, dist } = ctxFor(st, s0), G = c.G;
      if (!known(c, q)) return ['<span>❔</span>', '아직 못 가 본 곳', '어둠 속이에요. 가까이 가면 보여요.'];
      const lines = [];
      let icon = '', title = '';
      const mi = monAt(c, q);
      if (mi >= 0 && v[q]) {
        const m = c.mo[mi], M = MT[m.t];
        if (m.t === MIMIC && !(m.fl & 1)) { icon = '<span>🧰</span>'; title = '상자'; lines.push('부딪히면 열려요. 안에 뭐가 있을까요?'); }
        else {
          icon = '<span>' + M.e + '</span>'; title = M.n;
          lines.push('체력 ' + m.hp + ' · 공격 ' + M.at + ' · 방어 ' + M.df, M.d);
          const it = intent(c, mi, p.t + 1, dist);
          const IN = { sleep: '자고 있어요 (가까이 가면 깨요)', frozen: '얼어 있어요', mv: '다음: 다가와요', atk: '다음: 나를 공격!', steal: '다음: 금화를 훔쳐요!', shoot: '다음: 쏴요! 줄에서 비키세요', aim: '노려보는 중 — 다음 턴 돌진!', chg: '돌진해요! 옆으로 피하세요', rest: '이번엔 쉬어요', reload: '장전 중', prime: '부풀어요 — 붙어 있으면 터져요', boom: '곧 터져요! 1칸 밖으로', blink: '도망쳐요(순간이동)', wind: '힘을 모아요', slam: '내려치기! 빨간 칸에서 나가요', idle: '가만히 있어요', lost: '나를 못 봐요(그림자)' };
          lines.push(IN[it.k] || '');
          if (m.t === BOSS) lines.push(m.fl & 32 ? '부하를 이미 불렀어요' : '체력이 반 아래면 쥐 2마리를 불러요');
          const myD = Math.max(1, patk(p) - M.df);
          lines.push('내 공격: 한 번에 ' + myD + ' → ' + Math.ceil(m.hp / myD) + '번이면 쓰러져요');
        }
      }
      const ei = G.entAt[q];
      if (!title && ei >= 0) {
        const e = G.ents[ei], tk = bget(c.tk, ei);
        if (e.k === 'D') { icon = '<span>🚪</span>'; title = tk ? '열린 문' : '잠긴 문'; lines.push(tk ? '지나갈 수 있어요.' : '열쇠 1개로 열려요(부딪히기). 폭탄으로도 부서져요.'); }
        else if (e.k === 'X' && tk) { icon = '<span>⚠️</span>'; title = TRAPS[e.v].n; lines.push('밟으면 ' + TRAPS[e.v].d + '. 피해서 가요.'); }
        else if (!tk && e.k === 'I') { icon = itemHTML(e.v); title = IT[e.v].n; lines.push(IT[e.v].d, '밟으면 주워요.'); }
        else if (!tk && e.k === 'S') { icon = itemHTML(e.v); title = IT[e.v].n + ' — ' + IT[e.v].pr + '금화'; lines.push(IT[e.v].d, '위에 서서 「사기」를 누르면 사요.'); }
        else if (!tk && e.k === 'C') { icon = '<span>🧰</span>'; title = '상자'; lines.push('부딪히면 열려요. 안에 뭐가 있을까요?'); }
        else if (!tk && e.k === '$') { icon = '<span>💰</span>'; title = '금화 ' + e.v; lines.push('밟으면 주워요.'); }
        else if (!tk && e.k === '*') { icon = '<span>💎</span>'; title = '보석'; lines.push('금화 40만큼의 값어치!'); }
        else if (!tk && e.k === 'K') { icon = '<span>🗝️</span>'; title = '열쇠'; lines.push('잠긴 문 하나를 열 수 있어요.'); }
        else if (!tk && e.k === 'T') { icon = '<span>🔥</span>'; title = '횃불'; lines.push('횃불(남은 턴) +' + TORCH_ADD); }
      }
      if (!title && q === G.stairs) { icon = '<span>' + (p.f < MAXF ? '🪜' : '🚪') + '</span>'; title = p.f < MAXF ? '아래층 계단' : '탈출 문'; lines.push(p.f < MAXF ? '위에 서서 「내려가기」. 다시 올라올 수는 없어요.' : '잿빛 군주를 쓰러뜨리면 열려요. 나가면 탈출 보너스 150점!'); }
      if (!title && q === G.keeper) { icon = '<span>🦉</span>'; title = '부엉이 상인'; lines.push('물건 위에 서서 「사기」를 눌러요.'); }
      if (!title && G.clues[q] >= 0) { icon = '<span>🦴</span>'; title = CLUES[G.clues[q]]; lines.push('근처에 함정이 숨어 있을 수 있어요.', '「살피기」를 하면 2칸 안 함정이 보여요.', ['뼈 → 가시·독침 함정', '금 간 바닥 → 구덩이', '빛나는 문양 → 순간이동·경보 함정'][G.clues[q]]); }
      if (!title && q === p.x) { icon = '<span>🙂</span>'; title = api.players[s0].name; lines.push('공격 ' + patk(p) + ' · 방어 ' + pdef(p) + (p.r ? ' · ' + IT[p.r].n : '') + (p.ps ? ' · 독 ' + p.ps : '') + (p.sh ? ' · 그림자 ' + p.sh : '')); }
      if (!title) { const t = G.t[q]; icon = t ? '<span>⬛</span>' : '<span>🧱</span>'; title = t ? '바닥' : '벽'; lines.push(t ? (v[q] ? '지금 보이는 곳' : '가 본 곳 (지금은 안 보여요)') : '지나갈 수 없어요.'); }
      return [icon, title, lines.filter(Boolean).join('\n')];
    }

    /* ---- input on canvas ---- */
    let pd = null;
    cv.cv.addEventListener('pointerdown', (e) => {
      const pt = cv.local(e);
      pd = { x: pt.x, y: pt.y, t: performance.now(), long: false, id: e.pointerId };
      clearTimeout(pd.timer);
      pd.timer = setTimeout(() => { if (!pd) return; pd.long = true; const q = screenToCell(pd.x, pd.y); if (q >= 0 && st) { const [ic, ti, tx] = describe(q); openCard(ic, ti, tx, []); api.buzz(10); } }, 430);
    });
    cv.cv.addEventListener('pointermove', (e) => { if (!pd) return; const pt = cv.local(e); if (Math.hypot(pt.x - pd.x, pt.y - pd.y) > 12) clearTimeout(pd.timer); });
    const endPd = (e, cancel) => {
      if (!pd) return; clearTimeout(pd.timer);
      const p0 = pd; pd = null;
      if (cancel || p0.long || !st) return;
      const pt = cv.local(e), dx = pt.x - p0.x, dy = pt.y - p0.y;
      if (Math.hypot(dx, dy) > 28 && !mapMode) { doMove(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0)); return; }
      const q = screenToCell(p0.x, p0.y);
      if (q < 0) return;
      if (!cardEl.hidden) closeCard();
      const s0 = myTurnSeat();
      if (mapMode) { if (s0 >= 0 && known(ctxFor(st, s0).c, q)) { mapMode = false; mapBtn.textContent = '🗺 지도'; msg.style.visibility = ''; startWalk(q); } dirty = true; return; }
      if (s0 < 0) { const [ic, ti, tx] = describe(q); openCard(ic, ti, tx, []); return; }
      const p = st.P[s0];
      if (q === p.x) { const [ic, ti, tx] = describe(q); openCard(ic, ti, tx, []); return; }
      const d = dirTo(p.x, q);
      if (d >= 0 && man(p.x, q) === 1) { doMove(d); return; }
      if (known(ctxFor(st, s0).c, q)) { stopWalk(); startWalk(q); }
      else { const [ic, ti, tx] = describe(q); openCard(ic, ti, tx, []); }
    };
    cv.cv.addEventListener('pointerup', (e) => endPd(e, false));
    cv.cv.addEventListener('pointercancel', (e) => endPd(e, true));
    cv.cv.addEventListener('contextmenu', (e) => e.preventDefault());

    /* ---- keyboard / gamepad ---- */
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (!passEl.hidden && (id === 'wait' || id === 'ctx')) { passEl.querySelector('.btn') && passEl.querySelector('.btn').click(); return; }
      if (id === 'up') doMove(0); else if (id === 'right') doMove(1); else if (id === 'down') doMove(2); else if (id === 'left') doMove(3);
      else if (id === 'wait') bW.click(); else if (id === 'ctx') onCtx(); else if (id === 'map') mapBtn.click();
      else if (/^i[1-6]$/.test(id)) { const i = +id[1] - 1; if (st && st.P[seat].inv[i] && myTurnSeat() >= 0) { stopWalk(); send({ t: 'u', i }); } }
    }) : null;

    /* ---- geometry ---- */
    let T = 40, area = { y0: 60, y1: 400 }, cam = { x: 0, y: 0 };
    function layout() {
      T = Math.max(40, Math.min(56, Math.floor(cv.w / 9)));
      const th = top.offsetHeight || 60, bh = bot.offsetHeight || 160;
      area = { y0: th + 2, y1: Math.max(th + 120, cv.h - bh - 22) };
      msg.style.bottom = (bh + 2) + 'px';
      placeCard();
      dirty = true;
    }
    cv.onresize = layout;
    function screenToCell(x, y) {
      if (mapMode) { const M = mapGeom(); const gx = Math.floor((x - M.x) / M.s), gy = Math.floor((y - M.y) / M.s); return gx >= 0 && gy >= 0 && gx < W && gy < H ? gy * W + gx : -1; }
      const gx = Math.floor((x + cam.x) / T), gy = Math.floor((y + cam.y) / T);
      return gx >= 0 && gy >= 0 && gx < W && gy < H ? gy * W + gx : -1;
    }
    function mapGeom() { const aw = cv.w - 16, ah = area.y1 - area.y0 - 8; const s = Math.max(6, Math.floor(Math.min(aw / W, ah / H))); return { s, x: Math.floor((cv.w - s * W) / 2), y: area.y0 + Math.floor((ah - s * H) / 2) + 4 }; }

    /* ---- events → floats / sfx / messages ---- */
    function say(t) { msgText = t; msg.textContent = t; }
    function addFloat(q, text, color, big) { floats.push({ x: cx(q) + 0.5, y: cy(q) + 0.2, text, color, t: 0, big }); dirty = true; }
    function handleEvents(p, s0, isView) {
      const nm = api.players[s0].name;
      const mine = api.canAct(s0);
      let line = '';
      for (const e of p.ev || []) {
        const k = e[0];
        if (!isView) continue;
        switch (k) {
          case 'h': if (e[2] > 0) { addFloat(e[1], '-' + e[2], '#ffe08a'); api.sfx('hit'); } else addFloat(e[1], '❄', '#9fe3ff'); break;
          case 'k': addFloat(e[1], e[3] ? '+' + e[3] : '처치', '#e3ae45', 1); line = MT[e[2]].n + ' 처치!' + (e[3] ? ' 금화 +' + e[3] : ''); api.sfx('pop'); break;
          case 'd': addFloat(p.x, '-' + e[2], '#ff6b6b', 1); if (mine) api.buzz(e[2] >= 4 ? 40 : 18); api.sfx('thud'); flashes.push({ t: 0, c: 'rgba(220,40,60,' }); if (e[1] === -1) line = '독 때문에 체력 -1'; break;
          case 'g': addFloat(e[1], '+' + e[2], '#ffd45a'); api.sfx('chip'); if (e[3]) line = '보석! 금화 +' + e[2]; break;
          case 'i': line = IT[e[2]].n + (e[3] ? ' 장착!' : ' 얻음'); api.sfx('pop'); break;
          case 's': line = IT[e[2]].n + ' — 더 좋은 걸 써서 금화 8로 바꿨어요'; break;
          case 'n': line = '가방이 가득 차서 ' + IT[e[2]].n + '을(를) 못 주웠어요'; break;
          case 'K': line = '열쇠를 주웠어요 🗝'; api.sfx('chip'); break;
          case 'T': line = '횃불 +' + TORCH_ADD + '턴 🔥'; api.sfx('pop'); break;
          case 'O': line = '문이 열렸어요'; api.sfx('click'); break;
          case 'C': api.sfx('pop'); break;
          case 'M': line = '미믹이다! 상자가 아니었어요'; addFloat(e[1], '!', '#ff6b6b', 1); api.sfx('hit'); break;
          case 'X': line = TRAPS[e[2]].n + '! ' + TRAPS[e[2]].d; addFloat(e[1], '⚠', '#ff9a4a', 1); api.sfx('thud'); break;
          case 'x': addFloat(e[1], '⚠', '#ffb04a'); break;
          case 'z': line = e[2] ? '살펴봤어요 — 함정 ' + e[2] + '개 발견!' : '살펴봤어요 — 2칸 안엔 함정이 없어요'; break;
          case 'r': addFloat(p.x, '+1', '#7ee08a'); break;
          case 'P': line = line || '독에 걸렸어요 (해독 물약!)'; break;
          case 'B': flashes.push({ t: 0, q: e[1], c: 'rgba(255,140,40,' }); api.sfx('thud'); break;
          case 'S': shots.push({ a: e[1], b: e[2], t: 0 }); api.sfx('whoosh'); break;
          case 'Q': addFloat(e[1], '✦', '#c9a0ff', 1); if (e[2]) line = '휙! 순간이동'; break;
          case 't': line = '도둑 원숭이가 금화 ' + e[2] + '을 훔쳤어요!'; addFloat(e[1], '-' + e[2] + '💰', '#ffd45a', 1); break;
          case 'w': addFloat(e[1], '!', '#ff8a5a'); break;
          case 'Y': line = '잿빛 군주가 쥐를 불렀어요!'; break;
          case 'L': line = '잿빛 군주를 쓰러뜨렸어요! 탈출 문이 열려요'; api.sfx('win'); break;
          case '$': line = '샀어요! 금화 -' + e[2]; api.sfx('chip'); break;
          case 'u': line = IT[e[2]].n + ' 사용'; api.sfx(IT[e[2]].k === 'p' ? 'pop' : 'whoosh'); if (e[2] === 'g') flashes.push({ t: 0, q: e[1], c: 'rgba(255,140,40,', big: 1 }); break;
          case 'F': line = '구덩이로 떨어졌어요! 아래층으로'; break;
          case 'v': line = '지하 ' + e[1] + '층에 내려왔어요'; api.sfx('whoosh'); if (e[1] === MAXF) line = '지하 5층 — 잿빛 군주가 기다려요!'; break;
          case 'e': line = ['', '쓰러졌어요… 금화 절반만 들고 나가요', '횃불이 꺼졌어요. 여기까지!', '탈출 성공! 🎉', '던전에서 나왔어요'][e[1]]; api.sfx(e[1] === 3 ? 'win' : e[1] === 1 ? 'lose' : 'click'); if (mine) api.toast(line); break;
          default: break;
        }
      }
      if (isView && line) say((mine ? '' : nm + ': ') + line);
    }

    /* ---- HUD ---- */
    function render() {
      if (!st) return;
      seat = pickSeat();
      const p = st.P[seat];
      const mineActive = myTurnSeat() >= 0;
      // stats
      stats.innerHTML = '';
      const hp = L.h('div', { class: 'dg-hp' }, L.h('i', { style: { width: Math.round(100 * p.hp / p.mh) + '%' } }), L.h('b', { text: '❤ ' + p.hp + '/' + p.mh + (p.ps ? ' ☠' + p.ps : '') }));
      stats.append(L.h('span', { class: 'dg-fl', text: 'B' + p.f }), hp,
        L.h('span', { class: 'dg-chip', text: '⚔' + patk(p) }), L.h('span', { class: 'dg-chip', text: '🛡' + pdef(p) }),
        L.h('span', { class: 'dg-chip', text: '🗝' + p.k }), L.h('span', { class: 'dg-chip', text: '💰' + p.g }),
        L.h('span', { class: 'dg-chip', style: { color: p.tc < 60 ? 'var(--coral)' : '' }, text: '🔥' + p.tc }));
      // rivals
      rivals.innerHTML = '';
      if (st.n > 1) {
        st.P.forEach((q, i) => {
          const tag = q.e === 3 ? '탈출' : q.e === 1 ? '쓰러짐' : q.e ? '끝' : 'B' + q.f;
          rivals.append(L.h('span', { class: 'dg-rv' + (i === seat ? ' me' : '') }, L.h('span', { class: 'dot', style: { '--c': api.players[i].color } }), api.players[i].name.slice(0, 5) + ' ' + tag + ' · ' + score(q)));
        });
      }
      // inventory
      for (let i = 0; i < INV; i++) {
        const code = p.inv[i];
        slots[i].innerHTML = code ? itemHTML(code) : '';
        slots[i].classList.toggle('empty', !code);
        slots[i].setAttribute('aria-label', code ? IT[code].n : '빈 칸');
      }
      // ctx button
      const { c } = ctxFor(st, seat);
      const ei = c.G.entAt[p.x];
      let ct = '🏳 나가기';
      if (p.x === c.G.stairs) ct = p.f < MAXF ? '⬇ 내려가기' : '🚪 탈출!';
      else if (ei >= 0 && c.G.ents[ei].k === 'S' && !bget(c.tk, ei)) ct = '사기 ' + IT[c.G.ents[ei].v].pr + '💰';
      ctxBtn.textContent = ct;
      ctxBtn.classList.toggle('primary', ct !== '🏳 나가기');
      // spectate / controls visibility
      const showCtl = mineActive || (localActive().length && !passEl.hidden);
      left.style.display = showCtl ? '' : 'none';
      pad.style.display = showCtl ? '' : 'none';
      spec.hidden = showCtl;
      if (!showCtl) {
        spec.innerHTML = '';
        const mySeats = api.mySeats();
        const meDone = mySeats.length && mySeats.every((i) => st.P[i].e);
        const txt = meDone ? mySeats.map((i) => api.players[i].name + ' 탐험 끝 · ' + score(st.P[i]) + '점').join(' / ') + (st.P.some((q) => !q.e) ? ' — 다른 사람을 기다려요' : '') : '관전 중: ' + api.players[seat].name;
        spec.append(L.h('div', { class: 'muted', text: txt }));
        const others = st.P.map((q, i) => i).filter((i) => i !== seat);
        if (others.length) spec.append(L.h('button', { class: 'btn', text: '👁 다른 사람 보기 ▸', onclick() { const order = st.P.map((q, i) => i); let k = order.indexOf(seat); for (let n = 0; n < st.n; n++) { k = (k + 1) % st.n; if (!st.P[k].e || n === st.n - 1) break; } watch = k; api.sfx('click'); render(); dirty = true; } }));
      }
      requestAnimationFrame(layout);
      dirty = true;
    }

    /* ---- drawing ---- */
    function rr(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h); }
    function emoji(ch, x, y, size, alpha) {
      ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.font = Math.round(size) + 'px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(ch, x, y + size * 0.05);
      ctx.globalAlpha = 1;
    }
    function drawItem(code, x, y, s) {
      const it = IT[code]; if (!it) return;
      if (it.k === 'p') {
        ctx.fillStyle = '#b58a5a'; ctx.fillRect(x - s * 0.1, y - s * 0.42, s * 0.2, s * 0.14);
        ctx.fillStyle = it.c; ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(x - s * 0.09, y - s * 0.28); ctx.lineTo(x + s * 0.09, y - s * 0.28); ctx.lineTo(x + s * 0.09, y - s * 0.12);
        ctx.arc(x, y + s * 0.12, s * 0.27, -Math.PI / 2 + 0.35, Math.PI * 1.5 - 0.35); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.beginPath(); ctx.ellipse(x - s * 0.1, y + s * 0.08, s * 0.05, s * 0.09, 0, 0, 7); ctx.fill();
      } else if (it.k === 's') {
        ctx.fillStyle = '#efe0b8'; ctx.strokeStyle = '#8a6a3a'; ctx.lineWidth = 1.2; rr(x - s * 0.34, y - s * 0.26, s * 0.68, s * 0.52, 3); ctx.fill(); ctx.stroke();
        ctx.strokeStyle = '#8a6a3a'; ctx.beginPath(); ctx.moveTo(x - s * 0.22, y - s * 0.1); ctx.lineTo(x + s * 0.16, y - s * 0.1); ctx.moveTo(x - s * 0.22, y + s * 0.02); ctx.lineTo(x + s * 0.06, y + s * 0.02); ctx.stroke();
        ctx.fillStyle = it.c; ctx.beginPath(); ctx.arc(x + s * 0.18, y + s * 0.12, s * 0.11, 0, 7); ctx.fill();
      } else emoji(it.e, x, y, s * 0.62);
    }
    function lerpPos(a, b, k) { return [cx(a) + (cx(b) - cx(a)) * k, cy(a) + (cy(b) - cy(a)) * k]; }

    function draw(now) {
      cv.clear();
      ctx.fillStyle = '#0c0910'; ctx.fillRect(0, 0, cv.w, cv.h);
      if (!st) return;
      const p = st.P[seat];
      const { c, v, dist } = ctxFor(st, seat), G = c.G;
      let ak = 1;
      if (anim) { ak = Math.min(1, (now - anim.t0) / (120 / sp())); if (ak >= 1) anim = null; }
      const ease = (k) => 1 - (1 - k) * (1 - k);
      const ppos = anim && anim.px != null ? lerpPos(anim.px, p.x, ease(ak)) : [cx(p.x), cy(p.x)];
      if (mapMode) { drawMap(c, v, p, now); drawFx(now, 0, 0, 1); return; }
      // camera
      const vw = cv.w, vh = area.y1 - area.y0;
      const tx = (ppos[0] + 0.5) * T - vw / 2, ty = (ppos[1] + 0.5) * T - vh / 2 - area.y0;
      const mw = W * T, mh = H * T;
      cam.x = mw <= vw ? (mw - vw) / 2 : U.clamp(tx, -T * 0.5, mw - vw + T * 0.5);
      cam.y = mh <= vh ? (mh - vh) / 2 - area.y0 : U.clamp(ty, -area.y0 - T * 0.5, mh - vh - area.y0 + T * 0.5);
      ctx.save(); ctx.translate(-Math.round(cam.x), -Math.round(cam.y));
      const x0 = Math.max(0, Math.floor(cam.x / T)), x1 = Math.min(W - 1, Math.floor((cam.x + vw) / T));
      const y0 = Math.max(0, Math.floor(cam.y / T)), y1 = Math.min(H - 1, Math.floor((cam.y + cv.h) / T));
      const tick = now / 1000;
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        const q = y * W + x;
        if (!known(c, q)) continue;
        const X = x * T, Y = y * T, t = G.t[q];
        if (t === 0) {
          const below = y + 1 < H ? G.t[q + W] : 0;
          if (below) { ctx.fillStyle = '#5d4838'; ctx.fillRect(X, Y, T, T); ctx.fillStyle = '#7b6049'; ctx.fillRect(X, Y, T, T * 0.28); ctx.strokeStyle = 'rgba(30,20,14,.55)'; ctx.lineWidth = 1; ctx.beginPath(); const off = (x & 1) * T * 0.5; ctx.moveTo(X, Y + T * 0.64); ctx.lineTo(X + T, Y + T * 0.64); ctx.moveTo(X + T * 0.5 - off + T * 0.25, Y + T * 0.28); ctx.lineTo(X + T * 0.5 - off + T * 0.25, Y + T * 0.64); ctx.moveTo(X + off + T * 0.25, Y + T * 0.64); ctx.lineTo(X + off + T * 0.25, Y + T); ctx.stroke(); }
          else { ctx.fillStyle = '#1e1725'; ctx.fillRect(X, Y, T, T); ctx.fillStyle = '#2a2131'; ctx.fillRect(X + 1, Y + 1, T - 2, T - 2); }
        } else {
          const hv = hsh(q, 3, 1) & 7;
          ctx.fillStyle = hv < 3 ? '#352c40' : hv < 6 ? '#31283b' : '#3a3044'; ctx.fillRect(X, Y, T, T);
          ctx.strokeStyle = 'rgba(0,0,0,.22)'; ctx.lineWidth = 1; ctx.strokeRect(X + 0.5, Y + 0.5, T - 1, T - 1);
          if (t === 2) {
            const open = doorOpen(c, q);
            if (!open) { ctx.fillStyle = '#8a5a2b'; rr(X + 3, Y + 2, T - 6, T - 4, 4); ctx.fill(); ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(X + T / 2, Y + 4); ctx.lineTo(X + T / 2, Y + T - 4); ctx.stroke(); ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(X + T / 2, Y + T / 2, T * 0.12, 0, 7); ctx.fill(); ctx.fillStyle = '#1b1426'; ctx.fillRect(X + T / 2 - 1.5, Y + T / 2 - 1, 3, T * 0.12); }
            else { ctx.fillStyle = '#6a4522'; ctx.fillRect(X + 2, Y + 2, 5, T - 4); }
          }
          if (q === G.stairs) {
            if (p.f < MAXF) { ctx.fillStyle = '#0d0a12'; rr(X + 4, Y + 4, T - 8, T - 8, 4); ctx.fill(); ctx.fillStyle = '#6f5a48'; for (let k = 0; k < 3; k++) ctx.fillRect(X + 7 + k * 3, Y + 8 + k * (T - 16) / 3, T - 14 - k * 6, 3); }
            else { const bossAlive = c.mo.some((m) => m.t === BOSS && m.hp > 0); const g = ctx.createRadialGradient(X + T / 2, Y + T / 2, 2, X + T / 2, Y + T / 2, T * 0.5); g.addColorStop(0, bossAlive ? '#5a2030' : '#fff3c4'); g.addColorStop(1, bossAlive ? 'rgba(90,30,40,0)' : 'rgba(227,174,69,0)'); ctx.fillStyle = g; ctx.fillRect(X, Y, T, T); emoji(bossAlive ? '🔒' : '🚪', X + T / 2, Y + T / 2, T * 0.55); }
          }
          const cl = G.clues[q];
          if (cl >= 0) {
            if (cl === 0) { ctx.strokeStyle = 'rgba(235,225,200,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(X + T * 0.25, Y + T * 0.65); ctx.lineTo(X + T * 0.6, Y + T * 0.45); ctx.moveTo(X + T * 0.45, Y + T * 0.3); ctx.lineTo(X + T * 0.7, Y + T * 0.75); ctx.stroke(); ctx.fillStyle = 'rgba(235,225,200,.7)'; ctx.beginPath(); ctx.arc(X + T * 0.3, Y + T * 0.32, T * 0.08, 0, 7); ctx.fill(); }
            else if (cl === 1) { ctx.strokeStyle = 'rgba(10,6,14,.85)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(X + T * 0.15, Y + T * 0.3); ctx.lineTo(X + T * 0.4, Y + T * 0.5); ctx.lineTo(X + T * 0.35, Y + T * 0.7); ctx.lineTo(X + T * 0.7, Y + T * 0.85); ctx.moveTo(X + T * 0.4, Y + T * 0.5); ctx.lineTo(X + T * 0.8, Y + T * 0.4); ctx.stroke(); }
            else { ctx.strokeStyle = 'rgba(160,140,255,' + (0.45 + 0.25 * Math.sin(tick * 2 + q)) + ')'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(X + T / 2, Y + T / 2, T * 0.28, 0, 7); ctx.moveTo(X + T / 2, Y + T * 0.22); ctx.lineTo(X + T * 0.74, Y + T * 0.64); ctx.lineTo(X + T * 0.26, Y + T * 0.64); ctx.closePath(); ctx.stroke(); }
          }
        }
        if (q === G.keeper) { ctx.fillStyle = '#6a4522'; rr(X + 2, Y + T * 0.55, T - 4, T * 0.4, 3); ctx.fill(); emoji('🦉', X + T / 2, Y + T * 0.42, T * 0.62); }
        const ei = G.entAt[q];
        if (ei >= 0) {
          const e = G.ents[ei], tk = bget(c.tk, ei);
          const XC = X + T / 2, YC = Y + T / 2;
          if (e.k === 'X' && tk) { ctx.fillStyle = ['#c9c2b0', '#6fd06a', '#120c16', '#b07cff', '#ff6a5a'][e.v]; if (e.v === 2) { ctx.beginPath(); ctx.ellipse(XC, YC, T * 0.36, T * 0.3, 0, 0, 7); ctx.fill(); ctx.strokeStyle = '#6a5040'; ctx.lineWidth = 2; ctx.stroke(); } else { for (let k = 0; k < 3; k++) { const bx = X + T * (0.22 + k * 0.28); ctx.beginPath(); ctx.moveTo(bx - T * 0.1, YC + T * 0.18); ctx.lineTo(bx, YC - T * 0.18); ctx.lineTo(bx + T * 0.1, YC + T * 0.18); ctx.fill(); } } }
          else if (!tk) {
            if (e.k === '$') { ctx.fillStyle = '#c98a1e'; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.ellipse(XC - T * 0.12 + k * T * 0.12, YC + T * 0.12 - (k & 1) * T * 0.08, T * 0.14, T * 0.08, 0, 0, 7); ctx.fill(); } ctx.fillStyle = '#ffd45a'; ctx.beginPath(); ctx.ellipse(XC, YC - T * 0.02, T * 0.14, T * 0.08, 0, 0, 7); ctx.fill(); }
            else if (e.k === '*') emoji('💎', XC, YC, T * 0.55);
            else if (e.k === 'K') emoji('🗝️', XC, YC, T * 0.6);
            else if (e.k === 'T') emoji('🔥', XC, YC, T * 0.58);
            else if (e.k === 'C') drawChest(XC, YC, 0);
            else if (e.k === 'I') drawItem(e.v, XC, YC, T);
            else if (e.k === 'S') { drawItem(e.v, XC, YC - T * 0.08, T * 0.9); ctx.fillStyle = 'rgba(13,10,18,.85)'; rr(X + T * 0.18, Y + T * 0.7, T * 0.64, T * 0.26, 4); ctx.fill(); ctx.fillStyle = p.g >= IT[e.v].pr ? '#ffd45a' : '#a89'; ctx.font = '700 ' + Math.round(T * 0.22) + 'px "IBM Plex Mono",monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(IT[e.v].pr, XC, Y + T * 0.84); }
          }
        }
        if (!v[q]) { ctx.fillStyle = 'rgba(8,5,12,.55)'; ctx.fillRect(X, Y, T, T); }
      }
      // ghosts of rivals on this floor
      st.P.forEach((q2, i) => {
        if (i === seat || q2.e || q2.f !== p.f) return;
        const X = cx(q2.x) * T + T / 2, Y = cy(q2.x) * T + T / 2;
        ctx.globalAlpha = 0.38; ctx.fillStyle = api.players[i].color; ctx.beginPath(); ctx.arc(X, Y, T * 0.3, 0, 7); ctx.fill();
        ctx.globalAlpha = 0.6; ctx.fillStyle = '#fff'; ctx.font = '700 ' + Math.round(T * 0.28) + 'px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; const nm = api.players[i].name; ctx.fillText(/\d$/.test(nm) ? nm.slice(-1) : nm.slice(0, 1), X, Y + 1);
        ctx.globalAlpha = 1;
      });
      // monsters
      const prevM = anim && anim.mons;
      c.mo.forEach((m, i) => {
        if (m.hp <= 0 || !v[m.p]) return;
        let pos = [cx(m.p), cy(m.p)];
        if (prevM && prevM[i] != null && prevM[i] !== m.p) pos = lerpPos(prevM[i], m.p, ease(ak));
        const X = pos[0] * T + T / 2, Y = pos[1] * T + T / 2, M = MT[m.t];
        if (m.t === MIMIC && !(m.fl & 1)) { drawChest(X, Y, Math.sin(tick * 9) * ((tick % 4) < 0.35 ? 1 : 0)); return; }
        ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(X, Y + T * 0.3, T * 0.3, T * 0.1, 0, 0, 7); ctx.fill();
        const size = m.t === BOSS ? T * 0.95 : T * 0.68;
        const bob = (m.fl & 1) ? Math.sin(tick * 5 + i) * 1.5 : 0;
        if (m.t === 2) { // slime: drawn blob
          const sq = 1 + Math.sin(tick * 4 + i) * 0.06;
          ctx.fillStyle = '#5fcf6a'; ctx.strokeStyle = '#1f6a2a'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(X - T * 0.32 * sq, Y + T * 0.24); ctx.quadraticCurveTo(X - T * 0.34, Y - T * 0.3 / sq, X, Y - T * 0.3 / sq); ctx.quadraticCurveTo(X + T * 0.34, Y - T * 0.3 / sq, X + T * 0.32 * sq, Y + T * 0.24); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.beginPath(); ctx.ellipse(X - T * 0.12, Y - T * 0.12, T * 0.05, T * 0.08, -0.4, 0, 7); ctx.fill();
          ctx.fillStyle = '#123a18'; ctx.beginPath(); ctx.arc(X - T * 0.07, Y + T * 0.02, T * 0.04, 0, 7); ctx.arc(X + T * 0.1, Y + T * 0.02, T * 0.04, 0, 7); ctx.fill();
        } else emoji(M.e, X, Y + bob, size, M.b === 'ghost' ? (G.t[m.p] ? 0.85 : 0.55) : 1);
        if ((m.fl >> 1) & 7) { ctx.fillStyle = 'rgba(140,210,255,.35)'; rr(X - T * 0.42, Y - T * 0.42, T * 0.84, T * 0.84, 6); ctx.fill(); }
        const mhp = m.t === BOSS ? MT[BOSS].hp : M.hp + ((p.f - 1) >> 1);
        if (m.hp < mhp || m.t === BOSS) { const bw = T * 0.7; ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(X - bw / 2, Y - T * 0.5, bw, 4); ctx.fillStyle = '#ee6a55'; ctx.fillRect(X - bw / 2, Y - T * 0.5, bw * Math.max(0, m.hp) / Math.max(m.hp, mhp), 4); }
      });
      // intents
      if (!anim) c.mo.forEach((m, i) => {
        if (m.hp <= 0 || !v[m.p] || (m.t === MIMIC && !(m.fl & 1))) return;
        const it = intent(c, i, p.t + 1, dist);
        drawIntent(m, it, p, tick);
      });
      // player
      {
        const X = ppos[0] * T + T / 2, Y = ppos[1] * T + T / 2;
        ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.beginPath(); ctx.ellipse(X, Y + T * 0.3, T * 0.3, T * 0.1, 0, 0, 7); ctx.fill();
        ctx.globalAlpha = p.sh > 0 ? 0.55 : 1;
        ctx.fillStyle = api.players[seat].color; ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(X, Y, T * 0.31, 0, 7); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#1b1426'; ctx.beginPath(); ctx.arc(X - T * 0.1, Y - T * 0.03, T * 0.045, 0, 7); ctx.arc(X + T * 0.1, Y - T * 0.03, T * 0.045, 0, 7); ctx.fill();
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.moveTo(X - T * 0.28, Y - T * 0.14); ctx.quadraticCurveTo(X, Y - T * 0.52, X + T * 0.28, Y - T * 0.14); ctx.closePath(); ctx.fill();
        ctx.globalAlpha = 1;
        if (p.ps) emoji('☠', X + T * 0.3, Y - T * 0.3, T * 0.3);
      }
      drawFx(now, 0, 0, T);
      ctx.restore();
      // torch vignette
      const X = (ppos[0] + 0.5) * T - cam.x, Y = (ppos[1] + 0.5) * T - cam.y;
      const g = ctx.createRadialGradient(X, Y, T * 2.5, X, Y, T * (RV + 1.5));
      g.addColorStop(0, 'rgba(12,9,16,0)'); g.addColorStop(1, 'rgba(12,9,16,.55)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, cv.w, cv.h);
      for (const f of flashes) if (f.q == null) { ctx.fillStyle = f.c + (0.3 * (1 - f.t)) + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
    }
    function drawChest(X, Y, wob) {
      ctx.save(); ctx.translate(X, Y); ctx.rotate(wob * 0.08);
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(-T * 0.32, T * 0.2, T * 0.64, T * 0.1);
      ctx.fillStyle = '#8a5a2b'; rr(-T * 0.32, -T * 0.18, T * 0.64, T * 0.42, 4); ctx.fill();
      ctx.fillStyle = '#a06a34'; rr(-T * 0.32, -T * 0.3, T * 0.64, T * 0.18, 5); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.fillRect(-T * 0.32, -T * 0.13, T * 0.64, T * 0.05); ctx.fillRect(-T * 0.05, -T * 0.13, T * 0.1, T * 0.16);
      ctx.restore();
    }
    function arrow(x0, y0, x1, y1, col, w) {
      const a = Math.atan2(y1 - y0, x1 - x0), L2 = T * 0.16;
      ctx.strokeStyle = col; ctx.lineWidth = w || 3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x1 + Math.cos(a) * L2 * 0.6, y1 + Math.sin(a) * L2 * 0.6); ctx.lineTo(x1 - Math.cos(a - 0.7) * L2, y1 - Math.sin(a - 0.7) * L2); ctx.lineTo(x1 - Math.cos(a + 0.7) * L2, y1 - Math.sin(a + 0.7) * L2); ctx.closePath(); ctx.fill();
    }
    function badge(X, Y, txt, bg, fg) {
      ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(X, Y, T * 0.15, 0, 7); ctx.fill();
      ctx.fillStyle = fg || '#1b1426'; ctx.font = '700 ' + Math.round(T * 0.2) + 'px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(txt, X, Y + 1);
    }
    function drawIntent(m, it, p, tick) {
      const X = cx(m.p) * T + T / 2, Y = cy(m.p) * T + T / 2;
      const BX = X + T * 0.33, BY = Y - T * 0.33;
      const pulse = 0.5 + 0.5 * Math.sin(tick * 6);
      const tile3 = (col) => { for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const x = cx(m.p) + dx, y = cy(m.p) + dy; if (x >= 0 && y >= 0 && x < W && y < H) { ctx.fillStyle = col; ctx.fillRect(x * T + 2, y * T + 2, T - 4, T - 4); } } };
      switch (it.k) {
        case 'sleep': badge(BX, BY, 'z', 'rgba(200,190,230,.85)'); break;
        case 'frozen': badge(BX, BY, '❄', '#bfe9ff'); break;
        case 'rest': case 'reload': badge(BX, BY, '…', 'rgba(170,160,190,.85)'); break;
        case 'lost': badge(BX, BY, '?', 'rgba(170,160,190,.85)'); break;
        case 'idle': break;
        case 'mv': {
          let a = m.p;
          for (const q of it.path) { arrow(cx(a) * T + T / 2, cy(a) * T + T / 2, cx(a) * T + T / 2 + (cx(q) - cx(a)) * T * 0.72, cy(a) * T + T / 2 + (cy(q) - cy(a)) * T * 0.72, it.flee ? 'rgba(160,220,255,.85)' : 'rgba(242,233,216,.75)', 2.5); a = q; }
          break;
        }
        case 'atk': case 'steal': {
          const PX = cx(p.x) * T + T / 2, PY = cy(p.x) * T + T / 2;
          arrow(X, Y, X + (PX - X) * 0.62, Y + (PY - Y) * 0.62, it.k === 'steal' ? '#ffd45a' : '#ff5a5a', 4);
          badge(BX, BY, it.k === 'steal' ? '$' : '!', it.k === 'steal' ? '#ffd45a' : '#ff5a5a', '#fff');
          break;
        }
        case 'shoot': {
          const PX = cx(p.x) * T + T / 2, PY = cy(p.x) * T + T / 2;
          ctx.setLineDash([5, 5]); ctx.strokeStyle = 'rgba(255,90,90,.85)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(X, Y); ctx.lineTo(PX, PY); ctx.stroke(); ctx.setLineDash([]);
          badge(BX, BY, '➶', '#ff5a5a', '#fff'); break;
        }
        case 'aim': case 'chg': {
          let q = m.p; ctx.fillStyle = 'rgba(255,80,60,' + (it.k === 'chg' ? 0.35 : 0.2 + 0.12 * pulse) + ')';
          for (let k = 0; k < 6; k++) { q = stepC(q, it.d); if (q < 0 || !walk(cache.c, q)) break; ctx.fillRect(cx(q) * T + 3, cy(q) * T + 3, T - 6, T - 6); if (q === p.x) break; }
          arrow(X, Y, X + DX[it.d] * T * 0.75, Y + DY[it.d] * T * 0.75, '#ff5a3a', 4);
          badge(BX, BY, '!!', '#ff5a3a', '#fff'); break;
        }
        case 'prime': badge(BX, BY, '!', '#ffb04a'); break;
        case 'boom': tile3('rgba(255,120,40,' + (0.25 + 0.2 * pulse) + ')'); badge(BX, BY, '💥', '#ffb04a'); break;
        case 'wind': badge(BX, BY, '⤒', '#ffd45a'); break;
        case 'slam': tile3('rgba(255,50,50,' + (0.25 + 0.2 * pulse) + ')'); badge(BX, BY, '!!', '#ff3a3a', '#fff'); break;
        case 'blink': badge(BX, BY, '✦', '#c9a0ff'); break;
        default: break;
      }
    }
    function drawFx(now, ox, oy, S) {
      const dt = Math.min(0.05, (now - (drawFx.last || now)) / 1000) * sp(); drawFx.last = now;
      for (const s2 of shots) { s2.t += dt * 4; const k = Math.min(1, s2.t); const ax = cx(s2.a) * S + S / 2, ay = cy(s2.a) * S + S / 2, bx = cx(s2.b) * S + S / 2, by = cy(s2.b) * S + S / 2; ctx.fillStyle = '#ffe08a'; ctx.beginPath(); ctx.arc(ax + (bx - ax) * k, ay + (by - ay) * k, Math.max(2, S * 0.08), 0, 7); ctx.fill(); }
      shots = shots.filter((s2) => s2.t < 1);
      for (const f of flashes) { f.t += dt * 2.5; if (f.q != null) { const r = S * (f.big ? 1.6 : 1.5) * (0.4 + f.t); ctx.fillStyle = f.c + (0.55 * (1 - f.t)) + ')'; ctx.beginPath(); ctx.arc(cx(f.q) * S + S / 2, cy(f.q) * S + S / 2, r, 0, 7); ctx.fill(); } }
      flashes = flashes.filter((f) => f.t < 1);
      for (const f of floats) {
        f.t += dt * 1.1;
        ctx.globalAlpha = Math.max(0, 1 - f.t);
        ctx.font = '800 ' + Math.round(Math.max(11, S * (f.big ? 0.42 : 0.34))) + 'px "IBM Plex Mono",monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.8)'; const X = f.x * S, Y = (f.y - f.t * 0.7) * S;
        ctx.strokeText(f.text, X, Y); ctx.fillStyle = f.color; ctx.fillText(f.text, X, Y);
        ctx.globalAlpha = 1;
      }
      floats = floats.filter((f) => f.t < 1);
    }
    function drawMap(c, v, p, now) {
      const M = mapGeom(), s = M.s, G = c.G;
      ctx.fillStyle = 'rgba(30,24,40,.9)'; rr(M.x - 6, M.y - 6, s * W + 12, s * H + 12, 10); ctx.fill();
      for (let q = 0; q < N; q++) {
        if (!known(c, q)) continue;
        const X = M.x + cx(q) * s, Y = M.y + cy(q) * s, t = G.t[q];
        ctx.fillStyle = t === 0 ? '#5d4838' : t === 2 ? (doorOpen(c, q) ? '#6a4522' : '#b07a3a') : v[q] ? '#4a3f58' : '#382f44';
        ctx.fillRect(X, Y, s - (t ? 0.5 : 0), s - (t ? 0.5 : 0));
        const ei = G.entAt[q];
        if (ei >= 0 && !bget(c.tk, ei)) { const k = G.ents[ei].k; const col = { $: '#ffd45a', '*': '#7fe0ff', K: '#ffe08a', T: '#ff9a4a', C: '#c98a45', I: '#e0a0ff', S: '#7ee08a' }[k]; if (col) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(X + s / 2, Y + s / 2, s * 0.28, 0, 7); ctx.fill(); } }
        if (ei >= 0 && G.ents[ei].k === 'X' && bget(c.tk, ei)) { ctx.fillStyle = '#ff6a5a'; ctx.fillRect(X + s * 0.3, Y + s * 0.3, s * 0.4, s * 0.4); }
        if (q === G.stairs) { ctx.fillStyle = '#e3ae45'; ctx.fillRect(X + 1, Y + 1, s - 2, s - 2); ctx.fillStyle = '#1b1426'; ctx.font = '700 ' + Math.round(s * 0.8) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(p.f < MAXF ? '▼' : '★', X + s / 2, Y + s / 2 + 1); }
      }
      c.mo.forEach((m) => { if (m.hp > 0 && v[m.p] && !(m.t === MIMIC && !(m.fl & 1))) { ctx.fillStyle = '#ff5a5a'; ctx.beginPath(); ctx.arc(M.x + cx(m.p) * s + s / 2, M.y + cy(m.p) * s + s / 2, s * 0.35, 0, 7); ctx.fill(); } });
      st.P.forEach((q2, i) => { if (q2.e || q2.f !== p.f) return; ctx.globalAlpha = i === seat ? 1 : 0.5; ctx.fillStyle = api.players[i].color; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(M.x + cx(q2.x) * s + s / 2, M.y + cy(q2.x) * s + s / 2, s * 0.45, 0, 7); ctx.fill(); if (i === seat) ctx.stroke(); ctx.globalAlpha = 1; });
      ctx.fillStyle = '#f2e9d8'; ctx.font = '600 12px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('지하 ' + p.f + '층 지도 · 가 본 곳을 누르면 거기까지 걸어가요', cv.w / 2, Math.max(area.y0, M.y - 4) - 14);
    }

    const stopLoop = U.loop((dt, now) => {
      if (!(dirty || anim || floats.length || flashes.length || shots.length || now - lastDraw > 120)) return;
      dirty = false; lastDraw = now;
      draw(now);
    });

    function update(next, prev) {
      st = next;
      const oldSeat = seat;
      seat = pickSeat();
      // rival notices (not the viewed seat)
      st.P.forEach((q, i) => {
        if (seenF[i] != null && q.f > seenF[i] && i !== seat) api.toast(api.players[i].name + ' 지하 ' + q.f + '층!');
        if (seenE[i] === 0 && q.e && i !== seat && !api.canAct(i)) api.toast(api.players[i].name + ' ' + ['', '쓰러짐', '횃불 꺼짐', '탈출 성공!', '나감'][q.e]);
        seenF[i] = q.f; seenE[i] = q.e;
      });
      const p = st.P[seat];
      if (seenEid[seat] !== p.eid) {
        const pp = prev && prev.P && prev.P[seat];
        const first = seenEid[seat] == null;
        seenEid[seat] = p.eid;
        if (!first && pp && oldSeat === seat) {
          const sameFloor = pp.f === p.f;
          if (sameFloor) {
            const pm = decMo(pp.mo);
            anim = { t0: performance.now(), px: pp.x !== p.x && man(pp.x, p.x) === 1 ? pp.x : null, mons: pm.map((m) => m.p) };
          } else anim = null;
          handleEvents(p, seat, true);
        }
      }
      if (pend && st.P[seat] && st.P[seat].eid !== pend.eid) pend = null;
      if (oldSeat !== seat) { stopWalk(); anim = null; closeCard(); }
      render();
      if (walkPath) continueWalk();
      dirty = true;
    }

    return {
      update,
      destroy() { stopLoop(); stopWalk(); if (offIn) offIn(); padBtns.forEach((b) => b._stop && b._stop()); cv.destroy(); top.remove(); msg.remove(); bot.remove(); cardEl.remove(); passEl.remove(); },
    };
  }

  /* ======================= 도감 (codex) — 몬스터·물건·함정 표에서 자동 생성 ======================= */
  const CX_BOTTLE = (c) => '<svg viewBox="0 0 32 32"><rect x="13" y="3" width="6" height="6" rx="1" fill="#c8a878"/><path d="M12 9h8v4l4 5v8a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3v-8l4-5z" fill="' + c + '" stroke="#fff" stroke-opacity=".5"/><circle cx="13" cy="20" r="2" fill="#fff" opacity=".5"/></svg>';
  const CX_SCROLL = (c) => '<svg viewBox="0 0 32 32"><rect x="7" y="7" width="18" height="18" rx="2" fill="#f2e6c8"/><rect x="5" y="5" width="22" height="4" rx="2" fill="' + c + '"/><rect x="5" y="23" width="22" height="4" rx="2" fill="' + c + '"/><path d="M11 13h10M11 17h8M11 21h6" stroke="#8a7650" stroke-width="1.5"/></svg>';
  const CX_KIND = { p: '물약', s: '두루마리', x: '소모품', w: '무기', a: '갑옷', r: '반지' };
  const CX_FL = (a, b) => a === b ? a + '층' : a + '~' + b + '층';
  const cxGearFl = (ch) => { const fl = []; for (let f = 1; f <= MAXF; f++) if (GEAR_F[f].indexOf(ch) >= 0) fl.push(f); return fl.length ? fl.join('·') + '층' : ''; };
  const CODEX = [
    { h: '몬스터', p: ['체력은 3~4층 +1, 5층 +2 (보스·수호 기사는 그대로). 피해 = 공격 − 상대 방어(최소 1).'],
      rows: MT.map((m, i) => ({ icon: m.e, name: m.n, tag: i === BOSS ? '5층 보스' : i === MIMIC ? '2층~ · 상자 흉내' : i === GUARD ? '3층~ · 보물방 지기' : CX_FL(m.f[0], m.f[1]),
        desc: '체력 ' + m.hp + ' · 공격 ' + m.at + ' · 방어 ' + m.df + ' · 금화 ' + m.g + ' · ' + m.d })) },
    { h: '물건', p: ['가방은 ' + INV + '칸. 무기·갑옷은 더 좋으면 바로 장착(아니면 금화 8), 반지는 하나만 껴요. 가격은 부엉이 상인 기준.'],
      rows: Object.keys(IT).map((ch) => { const it = IT[ch]; return { icon: it.e || (it.k === 'p' ? CX_BOTTLE(it.c) : CX_SCROLL(it.c)), name: it.n, tag: CX_KIND[it.k] + ' · 💰' + it.pr, desc: it.d + (cxGearFl(ch) ? ' · 나오는 층 ' + cxGearFl(ch) : '') }; }).concat([
        { icon: '🗝️', name: '열쇠', tag: '바닥', desc: '잠긴 문 🚪 1개를 열어요. 잠긴 문이 있는 층엔 그만큼 열쇠가 문 바깥에 꼭 있어요.' },
        { icon: '💰', name: '금화', tag: '바닥', desc: '한 무더기 4+층×2 ~ 8+층×4. 깊을수록 많아요.' },
        { icon: '💎', name: '보석', tag: '바닥·상자', desc: '금화 40.' },
        { icon: '🎁', name: '상자', tag: '바닥', desc: '부딪히면 열려요. 무기·갑옷·반지·보석·소모품. 덜컹거리면 미믹일 수도!' },
        { icon: '🔥', name: '횃불', tag: '바닥', desc: '남은 턴이 늘어나요(+' + TORCH_ADD + '). 처음 횃불은 ' + TORCH0 + '턴.' },
      ]) },
    { h: '함정과 단서', p: ['함정은 처음엔 안 보여요. 근처 단서를 보고 「살피기」(2칸 안 함정 발견)로 찾아요.', '단서가 없는 함정(15%), 함정이 없는 가짜 단서도 층마다 하나쯤 있어요.'],
      rows: TRAPS.map((t, i) => ({ icon: ['🗡️', '💉', '🕳️', '🌀', '🚨'][i], name: t.n, tag: '단서: ' + CLUES[t.clue], desc: t.d + (i >= 3 ? ' · 2층부터' : '') + (i === 2 ? ' · 5층엔 없어요' : '') }))
        .concat(CLUES.map((c, k) => ({ icon: ['🦴', '🧱', '✨'][k], name: c, tag: '단서', desc: '근처 함정: ' + TRAPS.filter((t) => t.clue === k).map((t) => t.n).join(' · ') }))) },
    { h: '층 구성', p: ['판마다 씨앗으로 새로 만들어요. 한 층은 방 6~9개 + 통로. 시작 방에서 가장 먼 방에 계단(🪜)이 있어요.'],
      rows: [1, 2, 3, 4, 5].map((f) => ({ icon: f === MAXF ? '👹' : '🪜', name: '지하 ' + f + '층', tag: f === 2 || f === 4 ? '🦉 상인' : f === MAXF ? '보스' : '',
        desc: [
          '몬스터 ' + (3 + f) + '~' + (4 + f) + '마리: ' + MT.filter((m) => m.w && f >= m.f[0] && f <= m.f[1]).map((m) => m.e).join(''),
          f >= 2 ? '미믹 50%' : '',
          '함정 ' + (2 + f) + '개' + (f === 1 ? '(가시·독침·구덩이만)' : ''),
          f === 1 ? '잠긴 보물방 1개' : '잠긴 보물방 65%' + (f >= 3 ? '(수호 기사가 지켜요)' : ''),
          f >= 2 && f < MAXF ? '계단 방이 잠겨 있을 수 있어요' : '',
          '장비: ' + GEAR_F[f].split('').map((c) => IT[c].e).join(''),
          f === MAXF ? '큰 방에 잿빛 군주 + 탈출 문' : '',
        ].filter(Boolean).join(' · ') })) },
  ];

  L.register({
    id: 'dungeon', name: '미니 던전 탐험', tag: '탐험 로그라이크', cat: '보드',
    icon: '<rect x="8" y="10" width="40" height="38" rx="4" fill="none" stroke="currentColor" stroke-width="3"/><path d="M8 24h14v10H8M48 30H34v18" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="20" r="4" fill="currentColor"/><path d="M38 40l4-6 4 6z" fill="currentColor"/><path d="M14 42h6v-3h4v-3h4" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="25" y="2" width="6" height="8" rx="2" fill="currentColor"/>',
    tint: '#3a2a52',
    blurb: '판마다 새로 생기는 5층 던전을 칸 단위로 탐험해요. 열쇠·함정·보물·몬스터를 지나 계단을 찾아 더 깊이! 여럿이면 같은 던전에서 누가 더 많이 가져오나 경쟁.',
    quick: [
      '판마다 새로 생기는 5층 던전에서 금화를 모으고, 5층 보스를 쓰러뜨리고 탈출해요.',
      '한 칸 움직이면 한 턴 — 그다음 몬스터가 움직여요. 몬스터 위 화살표가 다음 행동이에요.',
      '점수 = 금화 + 내려간 층 × 30 + 탈출 150. 쓰러지면 금화가 절반! (여럿이면 점수 1등 승리)',
    ],
    rules: [
      { h: '목표', p: ['던전은 지하 1층부터 5층까지 있어요. 판마다 지도가 새로 만들어져요.', '각 층의 계단(🪜)을 찾아 내려가요. 5층의 잿빛 군주를 쓰러뜨리고 탈출 문으로 나가면 탈출 성공!', '혼자 하면 별 3개 도전: ★ 3층 도착 · ★★ 탈출 · ★★★ 탈출 + 금화 250 이상.'] },
      { h: '차례(턴)에 할 일', p: ['한 번에 하나: 한 칸 움직이기 · 몬스터 때리기(몬스터 쪽으로 움직이면 공격) · 물건 쓰기 · 살피기.', '내가 하나 하면 그 층 몬스터가 한 번씩 움직여요. 서두를 필요 없어요. 천천히 생각하세요.', '횃불(🔥)이 남은 턴이에요. 한 턴마다 1씩 줄고, 0이 되면 탐험이 끝나요(금화는 그대로).'] },
      { h: '전투', p: ['주사위 없이 숫자대로! 피해 = 공격력 − 상대 방어력(최소 1).', '예시: 내 공격 3, 해골 병사(체력 5, 방어 1) → 한 번에 2 → 3번 때리면 쓰러져요.', '몬스터 머리 위 표시: 화살표 = 다가옴, 빨간 ! = 공격, 점선 = 쏨, 빨간 칸 = 곧 터지거나 내려침(피하세요!), z = 잠, … = 쉼.', '몬스터를 꾹 누르면 체력·특징·다음 행동과 "몇 번 때리면 쓰러지는지"가 나와요.'] },
      { h: '열쇠·문·상자', p: ['잠긴 문(🚪)은 열쇠 1개로 열려요. 열쇠는 그 층 어딘가(문 안쪽이 아닌 곳)에 꼭 있어요.', '계단이 잠긴 방에 있는 층도 있어요. 폭탄으로 문을 부술 수도 있어요.', '상자에 부딪히면 열려요. 그런데… 가끔 덜컹거리는 상자는 미믹(몬스터)일 수 있어요!'] },
      { h: '함정과 단서', p: ['함정은 처음엔 안 보여요. 대신 근처에 단서가 있어요.', '흩어진 뼈 → 가시·독침 함정 / 금 간 바닥 → 구덩이(아래층으로 떨어짐) / 빛나는 문양 → 순간이동·경보 함정.', '「살피기」(제자리 1턴)를 하면 2칸 안 함정이 보여요. 주변에 깨어 있는 몬스터가 없으면 체력도 1 회복해요.', '단서가 없는 함정, 함정이 없는 단서도 가끔 있어요.'] },
      { h: '물건', p: ['물약(병): 빨간(체력 8)·큰(가득)·해독·힘(공격 +1)·돌 피부(방어 +1)·그림자(몬스터가 못 봄).', '두루마리: 지도·순간이동·불꽃(보이는 몬스터 4 피해)·얼음(3턴 얼림)·감지(함정·물건 위치). 그 밖에 폭탄·빵.', '무기·갑옷은 더 좋으면 바로 장착, 아니면 금화 8로 바꿔요. 반지는 하나만 껴요.', '가방은 6칸. 칸을 누르면 설명과 「쓰기」가 나와요.', '2층·4층엔 부엉이 상인이 있어요. 물건 위에 서서 「사기」.'] },
      { h: '5층 보스', p: ['잿빛 군주는 두 번 움직인 뒤 한 턴 힘을 모으고(⤒), 다음 턴 주변 8칸을 내려쳐요(빨간 칸, 피해 7).', '빨간 칸이 보이면 한 칸 밖으로! 반쯤 다치면 쥐 2마리를 불러요.'] },
      { h: '여럿이서(경쟁)', p: ['모두 똑같은 던전을 각자 자기 복사본으로 동시에 탐험해요. 차례를 기다릴 필요 없이 각자 속도대로!', '다른 사람은 흐린 유령으로 보여요. 서로 방해하지 않아요.', '모두 끝나면 점수 1등이 이겨요(같으면 턴을 적게 쓴 사람). 쓰러지면 금화 절반, 「나가기」는 그대로 들고 나가요.', '한 폰으로 여럿이 하면 한 사람이 한 층씩 하고 폰을 넘겨요.'] },
      { h: '조작', p: ['옆 칸을 톡 → 한 칸 이동/공격. 화면을 밀어도(스와이프) 돼요. 오른쪽 아래 방향 버튼도 있어요(꾹 누르면 계속).', '가 본 먼 칸을 톡 → 거기까지 자동으로 걸어가요(몬스터가 보이거나 다치면 멈춤).', '아무 칸이나 꾹 → 무엇인지 설명. 「🗺 지도」로 층 전체를 보고 눌러서 이동.', 'PC: 방향키/WASD 이동, Space 살피기, E 내려가기·사기, M 지도, 1~6 물건 쓰기.', 'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
    ],
    tutorial: [
      { sel: 'canvas', text: '가운데 동그라미가 나예요. 판마다 새로 생기는 던전 지하 1층에서 출발해요. 밝은 곳만 보이고, 가 본 곳은 어둡게 기억돼요.' },
      { sel: '.dg-pad', text: '옆 칸을 톡 하거나, 밀거나, 이 방향 버튼으로 한 칸씩 움직여요. 몬스터 쪽으로 가면 공격! 내가 한 번 움직이면 몬스터도 한 번 움직여요.' },
      { sel: 'canvas', text: '몬스터 머리 위 표시가 다음 행동이에요: 화살표=다가옴, 빨간 !=공격, 빨간 칸=곧 터짐/내려침. 꾹 누르면 자세한 설명이 나와요.' },
      { sel: '.dg-stats', text: '체력 ❤, 공격 ⚔, 방어 🛡, 열쇠 🗝, 금화 💰, 횃불 🔥(남은 턴). 횃불이 꺼지기 전에 계단을 찾아 내려가요.' },
      { sel: '.dg-inv', text: '주운 물약·두루마리는 가방에. 칸을 누르면 설명과 「쓰기」가 나와요.' },
      { sel: '.dg-act', text: '뼈·금 간 바닥 같은 단서 근처에선 가운데 「살피기」로 함정을 찾아요. 계단 위에선 「내려가기」! 「지도」로 층 전체를 볼 수 있어요.' },
    ],
    controls: [
      { id: 'up', label: '위로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'wait', label: '살피기', keys: ['Space', 'Period'], pad: ['x'] },
      { id: 'ctx', label: '내려가기·사기', keys: ['KeyE'], pad: ['a'] },
      { id: 'map', label: '지도', keys: ['KeyM', 'Tab'], pad: ['y'] },
      { id: 'i1', label: '물건 1', keys: ['Digit1'], pad: [] }, { id: 'i2', label: '물건 2', keys: ['Digit2'], pad: [] }, { id: 'i3', label: '물건 3', keys: ['Digit3'], pad: [] },
      { id: 'i4', label: '물건 4', keys: ['Digit4'], pad: [] }, { id: 'i5', label: '물건 5', keys: ['Digit5'], pad: [] }, { id: 'i6', label: '물건 6', keys: ['Digit6'], pad: [] },
    ],
    options: [{ id: 'dsd', label: '던전', choices: [{ v: 'rand', label: '무작위' }, { v: 'day', label: '오늘의 던전' }], def: 'rand' }],
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, fixedOrder: true,
    codex: CODEX,
    init, actor, apply, result, ai, aiDelayFor, mount,
    _t: { gen, ctxOf, visOf, score, intent, MT, IT, decMo, N, W, H },
  });
})();
