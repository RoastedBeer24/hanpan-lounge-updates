/* 육각 다리 잇기 — 헥스(N×N 마름모 육각판), 바꾸기(파이) 규칙, 거리 평가 / MCTS+RAVE AI. */
(function () {
  const L = window.Lounge, U = L.util;
  const SQ3 = Math.sqrt(3);

  /* ---------- geometry ----------
     cell p = y*N + x. x: 왼쪽→오른쪽(2번 자리가 잇는 방향), y: 위→아래(1번 자리가 잇는 방향).
     neighbour directions in cyclic order: up, upper-right, lower-right, down, lower-left, upper-left */
  const DX = [0, 1, 1, 0, -1, -1], DY = [-1, -1, 0, 1, 1, 0];
  const GEO = {};
  function geo(N) {
    if (GEO[N]) return GEO[N];
    const NN = N * N, TOP = NN, BOT = NN + 1, LEFT = NN + 2, RIGHT = NN + 3;
    const CN = new Int16Array(NN * 6).fill(-1);   // cyclic neighbours incl. virtual edges (-1 = off-board corner)
    const C8 = new Int16Array(NN * 8);           // CN with the first two repeated (no modulo in hot loops)
    const NBF = new Int16Array(NN * 6).fill(-1);  // on-board neighbours only
    const NB = [];
    for (let p = 0; p < NN; p++) {
      const x = p % N, y = (p / N) | 0, list = [];
      for (let k = 0; k < 6; k++) {
        const xx = x + DX[k], yy = y + DY[k];
        let q;
        if (xx >= 0 && yy >= 0 && xx < N && yy < N) { q = yy * N + xx; list.push(q); NBF[p * 6 + k] = q; }
        else {
          const offX = xx < 0 || xx >= N, offY = yy < 0 || yy >= N;
          q = offX && offY ? -1 : offY ? (yy < 0 ? TOP : BOT) : (xx < 0 ? LEFT : RIGHT);
        }
        CN[p * 6 + k] = q;
      }
      for (let k = 0; k < 8; k++) C8[p * 8 + k] = CN[p * 6 + (k % 6)];
      NB.push(list);
    }
    return (GEO[N] = { N, NN, CN, C8, NB, NBF, TOP, BOT, LEFT, RIGHT });
  }
  const enc = (p, N) => String.fromCharCode(97 + (p % N)) + String.fromCharCode(97 + ((p / N) | 0));
  const decAt = (m, i, N) => (m.charCodeAt(i + 1) - 97) * N + (m.charCodeAt(i) - 97);
  const mirror = (p, N) => (p % N) * N + ((p / N) | 0);  // (x,y) → (y,x): 1번 방향 ↔ 2번 방향
  const ring = (p, N) => { const x = p % N, y = (p / N) | 0; return Math.min(x, y, N - 1 - x, N - 1 - y); };

  /* board: Int8Array(NN+4): 0 empty, 1 = seat 0 (위↔아래), 2 = seat 1 (왼↔오). The 4 virtual edge cells carry their owner. */
  function boardOf(m, N) {
    const g = geo(N), b = new Int8Array(g.NN + 4);
    b[g.TOP] = b[g.BOT] = 1; b[g.LEFT] = b[g.RIGHT] = 2;
    for (let i = 0; i < m.length; i += 2) {
      if (m[i] === 'z') { const p0 = decAt(m, 0, N); b[p0] = 0; b[mirror(p0, N)] = 2; }
      else b[decAt(m, i, N)] = ((i / 2) % 2) + 1;
    }
    return b;
  }
  /* cell of turn i (the swap turn → the mirrored first stone) */
  function cellOfTurn(m, i, N) { return m[2 * i] === 'z' ? mirror(decAt(m, 0, N), N) : decAt(m, 2 * i, N); }
  /* shortest chain of colour c that joins its two edges, or null */
  function winPath(b, N, c) {
    const g = geo(N), NN = g.NN, prev = new Int16Array(NN).fill(-2), q = [];
    for (let i = 0; i < N; i++) { const p = c === 1 ? i : i * N; if (b[p] === c) { prev[p] = -1; q.push(p); } }
    for (let h = 0; h < q.length; h++) {
      const p = q[h];
      if (c === 1 ? p >= NN - N : p % N === N - 1) { const path = []; for (let z = p; z >= 0; z = prev[z]) path.push(z); return path; }
      for (const n of g.NB[p]) if (b[n] === c && prev[n] === -2) { prev[n] = p; q.push(n); }
    }
    return null;
  }

  /* ---------- game ---------- */
  function init(players, opts) {
    const n = [7, 9, 11].includes(+(opts && opts.size)) ? +opts.size : 9;
    const sw = opts && (opts.swap === 0 || opts.swap === '0' || opts.swap === 'off') ? 0 : 1;
    const hum = players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0);
    const solo = hum.length === 1 && players.length === 2 && players.some((p) => p.ai) ? hum[0] : -1;
    return { n, sw, m: '', seq: 0, solo, uk: -1, st: null, ev: null };
  }
  const turns = (s) => s.m.length / 2;
  function actor(s) { return s.st ? null : turns(s) % 2; }
  function canSwap(s) { return !!s.sw && !s.st && turns(s) === 1; }
  function apply(s, seat, a) {
    if (s.st) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a) throw new Error('bad action');
    const n = turns(s), N = s.n;
    if (a.t === 'undo') {
      if (s.solo !== seat || n < 2 || s.uk === n) throw new Error('cannot undo');
      s.m = s.m.slice(0, -4);
      s.uk = n - 2; s.seq++;
      s.ev = { id: s.seq, k: 'u' };
      return s;
    }
    if (a.t === 'swap') {
      if (!canSwap(s) || seat !== 1) throw new Error('cannot swap');
      s.m += 'zz'; s.seq++;
      s.ev = { id: s.seq, k: 's' };
      return s;
    }
    if (a.t !== 'place') throw new Error('bad action');
    const p = a.p | 0;
    if (p < 0 || p >= N * N) throw new Error('off board');
    const b = boardOf(s.m, N);
    if (b[p]) throw new Error('occupied');
    b[p] = seat + 1;
    s.m += enc(p, N); s.seq++; s.ev = null;
    const path = winPath(b, N, seat + 1);
    if (path) s.st = { w: seat, p: path.map((q) => enc(q, N)).join('') };
    return s;
  }
  function result(s) {
    if (!s.st) return null;
    const stones = Math.ceil((turns(s) - s.st.w) / 2);
    return { winners: [s.st.w], text: (s.st.w === 0 ? '위·아래' : '왼쪽·오른쪽') + ' 변을 ' + stones + '번째 돌로 이었어요.' };
  }

  /* ---------- AI ---------- */
  const INF = 999;
  /* two-distance potential of colour c: min over empty cells of (dist to edge A + dist to edge B), where a cell's
     distance is 1 + the SECOND best neighbour (the opponent can always cut the best one). Own groups merge cells. */
  function pot2(b, g, c) {
    const NN = g.NN, CN = g.CN;
    const EA = c === 1 ? g.TOP : g.LEFT, EB = c === 1 ? g.BOT : g.RIGHT;
    const gid = new Int16Array(NN).fill(-1), mark = new Int32Array(NN);
    const gEmp = [], gA = [], gB = [];
    let stamp = 0;
    for (let p = 0; p < NN; p++) {
      if (b[p] !== c || gid[p] >= 0) continue;
      const id = gEmp.length, emp = [], stack = [p];
      let ea = false, eb = false;
      stamp++; gid[p] = id;
      while (stack.length) {
        const q = stack.pop();
        for (let k = 0; k < 6; k++) {
          const r = CN[q * 6 + k];
          if (r < 0) continue;
          if (r >= NN) { if (r === EA) ea = true; else if (r === EB) eb = true; continue; }
          if (b[r] === c) { if (gid[r] < 0) { gid[r] = id; stack.push(r); } }
          else if (b[r] === 0 && mark[r] !== stamp) { mark[r] = stamp; emp.push(r); }
        }
      }
      if (ea && eb) return { p: 0, k: 99 };
      gEmp.push(emp); gA.push(ea); gB.push(eb);
    }
    const nb = new Array(NN), fa = new Uint8Array(NN), fb = new Uint8Array(NN), empties = [];
    for (let p = 0; p < NN; p++) {
      if (b[p] !== 0) continue;
      empties.push(p);
      stamp++; mark[p] = stamp;
      const list = [], gs = [];
      for (let k = 0; k < 6; k++) {
        const r = CN[p * 6 + k];
        if (r < 0) continue;
        if (r >= NN) { if (r === EA) fa[p] = 1; else if (r === EB) fb[p] = 1; continue; }
        if (b[r] === 0) { if (mark[r] !== stamp) { mark[r] = stamp; list.push(r); } }
        else if (b[r] === c) {
          const id = gid[r];
          if (gs.indexOf(id) >= 0) continue;
          gs.push(id);
          if (gA[id]) fa[p] = 1;
          if (gB[id]) fb[p] = 1;
          for (const e of gEmp[id]) if (mark[e] !== stamp) { mark[e] = stamp; list.push(e); }
        }
      }
      nb[p] = list;
    }
    const dA = dist2(empties, nb, fa, NN), dB = dist2(empties, nb, fb, NN);
    let best = INF, cnt = 0;
    for (const p of empties) { const v = Math.min(INF, dA[p] + dB[p]); if (v < best) { best = v; cnt = 1; } else if (v === best) cnt++; }
    return { p: best, k: best >= INF ? 0 : cnt };
  }
  function dist2(empties, nb, f, NN) {
    const d = new Int16Array(NN).fill(INF);
    for (const p of empties) if (f[p]) d[p] = 1;
    for (let changed = true; changed;) {
      changed = false;
      for (const p of empties) {
        if (d[p] <= 1) continue;
        let m1 = INF, m2 = INF;
        for (const q of nb[p]) { const v = d[q]; if (v < m1) { m2 = m1; m1 = v; } else if (v < m2) m2 = v; }
        if (m2 < INF && m2 + 1 < d[p]) { d[p] = m2 + 1; changed = true; }
      }
    }
    return d;
  }
  /* plain shortest path: how many more stones colour c needs (own stones free, opponent blocks) — 0-1 BFS */
  function dist1(b, g, c) {
    const N = g.N, NN = g.NN, d = new Int16Array(NN).fill(INF), dq = new Int16Array(NN * 4);
    let h = NN * 2, t = NN * 2;
    for (let i = 0; i < N; i++) {
      const p = c === 1 ? i : i * N;
      if (b[p] === 3 - c) continue;
      const v = b[p] === c ? 0 : 1;
      if (v < d[p]) { d[p] = v; if (v === 0) dq[--h] = p; else dq[t++] = p; }
    }
    while (h < t) {
      const p = dq[h++];
      for (const q of g.NB[p]) {
        if (b[q] === 3 - c) continue;
        const v = d[p] + (b[q] === c ? 0 : 1);
        if (v < d[q]) { d[q] = v; if (b[q] === c) dq[--h] = q; else dq[t++] = q; }
      }
    }
    let best = INF;
    for (let i = 0; i < N; i++) { const p = c === 1 ? NN - N + i : i * N + N - 1; if (d[p] < best) best = d[p]; }
    return best;
  }
  /* the opponent just played L: if that cut into one of c's bridges (or edge templates), the other carrier cell */
  function bridgeReply(b, g, L, c) {
    const NN = g.NN, C8 = g.C8, base = L * 8;
    for (let k = 0; k < 6; k++) {
      const mid = C8[base + k + 1];
      if (mid < 0 || mid >= NN || b[mid]) continue;
      const a = C8[base + k], z = C8[base + k + 2];
      if (a >= 0 && z >= 0 && b[a] === c && b[z] === c) return mid;
    }
    return -1;
  }
  function emptiesOf(b, NN) { const e = []; for (let p = 0; p < NN; p++) if (!b[p]) e.push(p); return e; }
  function winningCells(b, g, c, emp) {
    const out = [];
    for (const p of emp) { b[p] = c; if (winPath(b, g.N, c)) out.push(p); b[p] = 0; }
    return out;
  }

  /* 쉬움: takes an obvious win most of the time, sometimes misses a block, plays a noisy shortest-path move */
  function easyMove(b, g, me, R) {
    const op = 3 - me, emp = emptiesOf(b, g.NN);
    const w = winningCells(b, g, me, emp);
    if (w.length && R() < 0.9) return w[0];
    const th = winningCells(b, g, op, emp);
    if (th.length && R() < 0.65) return th[(R() * th.length) | 0];
    if (R() < 0.15) {
      const near = emp.filter((p) => g.NB[p].some((q) => b[q]));
      const pool = near.length ? near : emp;
      return pool[(R() * pool.length) | 0];
    }
    let bp = emp[0], bv = -Infinity;
    for (const p of emp) {
      b[p] = me;
      const v = (Math.min(dist1(b, g, op), 30) - Math.min(dist1(b, g, me), 30)) * 10 + R() * 16;
      b[p] = 0;
      if (v > bv) { bv = v; bp = p; }
    }
    return bp;
  }
  /* 보통: one ply over every empty cell, scored by the two-distance potentials of both sides (+ mobility),
     answers bridge intrusions, always takes a win and blocks a one-move loss */
  function mediumMove(b, g, me, lastP, R) {
    const op = 3 - me, emp = emptiesOf(b, g.NN);
    const w = winningCells(b, g, me, emp);
    if (w.length) return w[0];
    const th = winningCells(b, g, op, emp);
    const cand = th.length ? th : emp;
    const br = lastP >= 0 ? bridgeReply(b, g, lastP, me) : -1;
    let bp = cand[0], bv = -Infinity;
    for (const p of cand) {
      b[p] = me;
      const a = pot2(b, g, me), o = pot2(b, g, op);
      b[p] = 0;
      let v = (Math.min(o.p, 60) - Math.min(a.p, 60)) * 100 + U.clamp(a.k - o.k, -40, 40);
      if (p === br) v += 70;
      v += R() * 30;
      if (v > bv) { bv = v; bp = p; }
    }
    return bp;
  }
  /* 어려움: Monte-Carlo tree search with RAVE (all-moves-as-first) — random fill-in playouts that save intruded
     bridges / edge templates. In Hex the filled board's winner is the game's winner, so playouts are exact. */
  const HC = { ms: 520, exp: 10, K: 700, C: 0.1 };
  function mcts(b0, g, me, lastP, ms) {
    const N = g.N, NN = g.NN, C8 = g.C8, NBF = g.NBF;
    const B = new Int8Array(NN + 4), emp = new Int16Array(NN), pos = new Int16Array(NN);
    const stack = new Int16Array(NN), seen = new Uint8Array(NN);
    let seed = ((Math.random() * 0x7fffffff) | 0) || 1234567;
    const rnd = () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; };
    function mk(board) {
      const mv = []; for (let p = 0; p < NN; p++) if (!board[p]) mv.push(p);
      const n = mv.length;
      return { mv: Int16Array.from(mv), n: new Float32Array(n), w: new Float32Array(n), an: new Float32Array(n), aw: new Float32Array(n), kid: new Array(n).fill(null), N: 0 };
    }
    function pick(nd) {
      const n = nd.n, w = nd.w, an = nd.an, aw = nd.aw, len = nd.mv.length, lnN = Math.log(nd.N + 1), K = HC.K, C = HC.C;
      let bi = 0, bv = -1;
      for (let i = 0; i < len; i++) {
        const ni = n[i], ai = an[i];
        const qa = ai > 0 ? aw[i] / ai : 0.5;
        let v;
        if (ni > 0) { const beta = Math.sqrt(K / (3 * ni + K)); v = beta * qa + (1 - beta) * (w[i] / ni); }
        else v = qa;
        v += C * Math.sqrt(lnN / (ni + 1)) + rnd() * 1e-6;
        if (v > bv) { bv = v; bi = i; }
      }
      return bi;
    }
    const root = mk(b0);
    if (!root.mv.length) return { p: -1, n: 0 };
    const pN = [], pI = new Int16Array(NN + 2), pP = new Int8Array(NN + 2);
    const t0 = Date.now();
    let it = 0;
    for (;;) {
      if ((it & 31) === 0 && it && Date.now() - t0 > ms) break;
      it++;
      B.set(b0);
      let node = root, pl = me, d = 0, last = lastP;
      for (;;) {
        const i = pick(node), mv = node.mv[i];
        B[mv] = pl; pN[d] = node; pI[d] = i; pP[d] = pl; d++; last = mv; pl = 3 - pl;
        let k = node.kid[i];
        if (!k) { if (node.n[i] >= HC.exp && node.mv.length > 1) k = node.kid[i] = mk(B); else break; }
        node = k;
        if (!node.mv.length) break;
      }
      // fill-in playout
      let ne = 0;
      for (let p = 0; p < NN; p++) if (!B[p]) { pos[p] = ne; emp[ne++] = p; }
      while (ne > 0) {
        let mv = -1;
        if (last >= 0) {
          const base = last * 8;
          for (let k = 0; k < 6; k++) {
            const mid = C8[base + k + 1];
            if (mid < 0 || mid >= NN || B[mid]) continue;
            const a = C8[base + k], z = C8[base + k + 2];
            if (a >= 0 && z >= 0 && B[a] === pl && B[z] === pl) { mv = mid; break; }
          }
        }
        if (mv < 0) mv = emp[(rnd() * ne) | 0];
        const ix = pos[mv], le = emp[--ne]; emp[ix] = le; pos[le] = ix;
        B[mv] = pl; last = mv; pl = 3 - pl;
      }
      // winner: does colour 1 join top and bottom?
      let sp = 0, win = 2;
      seen.fill(0);
      for (let x = 0; x < N; x++) if (B[x] === 1) { seen[x] = 1; stack[sp++] = x; }
      while (sp) {
        const q = stack[--sp];
        if (q >= NN - N) { win = 1; break; }
        for (let k = 0; k < 6; k++) { const r = NBF[q * 6 + k]; if (r >= 0 && !seen[r] && B[r] === 1) { seen[r] = 1; stack[sp++] = r; } }
      }
      for (let j = 0; j < d; j++) {
        const nd = pN[j], i = pI[j], p = pP[j], won = win === p ? 1 : 0;
        nd.N++; nd.n[i]++; nd.w[i] += won;
        const mv = nd.mv, an = nd.an, aw = nd.aw;
        for (let t = 0; t < mv.length; t++) if (B[mv[t]] === p) { an[t]++; aw[t] += won; }
      }
    }
    let bi = 0;
    for (let i = 1; i < root.mv.length; i++) if (root.n[i] > root.n[bi] || (root.n[i] === root.n[bi] && root.aw[i] / (root.an[i] || 1) > root.aw[bi] / (root.an[bi] || 1))) bi = i;
    return { p: root.mv[bi], n: it, q: root.n[bi] ? root.w[bi] / root.n[bi] : 0.5 };
  }
  function hardMove(b, g, me, lastP) {
    const op = 3 - me, emp = emptiesOf(b, g.NN);
    const w = winningCells(b, g, me, emp);
    if (w.length) return w[0];
    const th = winningCells(b, g, op, emp);
    if (th.length === 1) return th[0];
    return mcts(b, g, me, lastP, HC.ms).p;
  }
  /* first move. With the swap rule a modest edge cell (not worth stealing), otherwise the centre. */
  function opening(N, sw, lv, R) {
    const c = (N - 1) / 2;
    if (lv === 1) {
      const x = c + ((R() * 3) | 0) - 1, y = c + ((R() * 3) | 0) - 1;
      return y * N + x;
    }
    if (!sw) return c * N + c;
    const list = [];
    for (let p = 0; p < N * N; p++) {
      const x = p % N, y = (p / N) | 0;
      if (ring(p, N) !== 0) continue;
      if ((y === 0 || y === N - 1) && (x < 2 || x > N - 3)) continue;
      if ((x === 0 || x === N - 1) && (y < 2 || y > N - 3)) continue;
      list.push(p);
    }
    return list[(R() * list.length) | 0];
  }
  /* second player: take the first stone if it is anywhere but the outer ring */
  function wantSwap(s, lv, R) {
    const r = ring(decAt(s.m, 0, s.n), s.n);
    if (lv === 1) return r >= 2 && R() < 0.6;
    return r >= 1;
  }
  function lastCell(s) { const t = turns(s); return t ? cellOfTurn(s.m, t - 1, s.n) : -1; }
  function ai(s, seat, lv) {
    const R = Math.random, N = s.n, t = turns(s);
    if (t === 0) return { t: 'place', p: opening(N, s.sw, lv, R) };
    if (canSwap(s) && seat === 1 && wantSwap(s, lv, R)) return { t: 'swap' };
    const g = geo(N), b = boardOf(s.m, N), me = seat + 1, lp = lastCell(s);
    const p = lv === 1 ? easyMove(b, g, me, R) : lv === 3 ? hardMove(b, g, me, lp) : mediumMove(b, g, me, lp, R);
    return { t: 'place', p };
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 650 : lv === 3 ? 60 : 280; }

  /* ---------- view ---------- */
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace';
  function rgb(c) { const n = parseInt(String(c).replace('#', ''), 16) || 0; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function mixc(c, d, t, a) { const A = rgb(c), B = rgb(d); const m = (i) => Math.round(A[i] + (B[i] - A[i]) * t); return 'rgba(' + m(0) + ',' + m(1) + ',' + m(2) + ',' + (a == null ? 1 : a) + ')'; }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, N = 0, G = null, b = null, g = null;
    let ghost = -1, swapPrev = false, hover = -1, down = null, busy = false, stopLoop = null, safety = 0;
    let shownSeq = -1, waitSeq = -1, waitUntil = 0;
    let drop = null, swp = null, wa = null;
    let CX = null, CY = null, bgc = null, spr = [null, null], path = [];
    const col = (seat) => (api.players[seat] && api.players[seat].color) || (seat ? '#5bb3e6' : '#ee6a55');

    const BS = { minHeight: '44px', flex: '1 1 0', minWidth: 0, padding: '6px 4px', fontSize: '13px', whiteSpace: 'nowrap' };
    const hud = L.h('div', { class: 'hud bottom', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px' } });
    const undoBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '↶ 무르기', 'aria-label': '한 수 무르기', onclick: onUndo });
    const swapBtn = L.h('button', { class: 'btn sm hx-swap', style: BS, text: '⇄ 바꾸기', 'aria-label': '첫 돌 가져오기', onclick: onSwapBtn });
    const placeBtn = L.h('button', { class: 'btn primary hx-place', style: Object.assign({}, BS, { flex: '1.6 1 0', fontSize: '15px' }), text: '놓기', onclick: () => commit() });
    hud.append(undoBtn, swapBtn, placeBtn);
    const hint = L.h('div', { class: 'hx-hint', style: { position: 'absolute', left: '12px', right: '12px', bottom: '64px', textAlign: 'center', fontSize: '12.5px', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', pointerEvents: 'none' } });
    root.append(hud, hint);
    // invisible boxes over canvas areas, so the first-play tutorial can spotlight them
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
    const spBoard = spot('hx-board'), spP0 = spot('hx-p0'), spP1 = spot('hx-p1');
    const vis = (el, on) => { el.style.display = on ? '' : 'none'; };
    const setBusy = (v) => { if (busy !== v) { busy = v; api.setBusy(v); updateHud(); } };

    function myTurn() { const a = st && actor(st); return a != null && api.canAct(a); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }
    function canUndo() {
      if (!st || st.st || api.online || st.solo < 0 || !myTurn() || actor(st) !== st.solo || locked()) return false;
      const n = turns(st);
      return n >= 2 && st.uk !== n;
    }
    function onUndo() { if (!canUndo() || busy) return; ghost = -1; swapPrev = false; api.sfx('click'); api.buzz(15); send({ t: 'undo' }); }
    function swapMine() { return st && !st.st && myTurn() && canSwap(st) && actor(st) === 1; }
    function onSwapBtn() {
      if (!swapMine() || locked() || busy) return;
      swapPrev = !swapPrev; ghost = -1;
      api.sfx('click'); api.buzz(8);
      updateHud(); draw();
    }
    function commit() {
      if (!st || !myTurn() || locked() || busy) return;
      if (swapPrev) { if (!swapMine()) return; swapPrev = false; api.buzz(14); send({ t: 'swap' }); updateHud(); draw(); return; }
      if (ghost < 0) return;
      if (b[ghost]) { ghost = -1; draw(); return; }
      const p = ghost; ghost = -1;
      api.buzz(12);
      send({ t: 'place', p });
      updateHud(); draw();
    }

    /* ----- layout: the rhombus stands as a tall parallelogram (columns vertical) so it fits a phone ----- */
    function layout() {
      if (!st) return;
      N = st.n; g = geo(N);
      const W = cv.w, H = cv.h, hudH = 64, hintH = 22;
      const availW = W - 16, availH = H - hudH - hintH - 8;
      const cardH = 42;
      let D = null;
      for (let w = 60; w >= 12; w -= 0.5) {
        const R = w / SQ3, s = w * SQ3 / 2, bm = Math.max(7, w * 0.36);
        const bw = (N - 1) * s + 2 * R + 2 * bm, bh = 1.5 * (N - 1) * w + w + 2 * bm;
        const cardW = Math.min(176, Math.max(128, bw * 0.56));
        const room = Math.max(0, Math.floor((bw - cardW - bm - R) / s)) * (w / 2);
        const extra = Math.max(0, cardH + 6 - room);
        D = { w, R, s, bm, bw, bh, cardW, extra };
        if (bw <= availW && bh + 2 * extra <= availH) break;
      }
      const { w, R, s, bm, bw, bh, cardW, extra } = D;
      const left = Math.round((W - bw) / 2);
      const T = Math.round(Math.max(4, (availH - bh - 2 * extra) / 2) + extra);
      G = { w, R, s, bm, bw, bh, left, T, X0: left + bm + R, Y0: T + bm + w / 2, cardW, cardH, r: w * 0.4,
        c1: { x: left + bw - cardW, y: T - extra }, c0: { x: left, y: T + bh + extra - cardH } };
      CX = new Float32Array(g.NN); CY = new Float32Array(g.NN);
      for (let p = 0; p < g.NN; p++) { const x = p % N, y = (p / N) | 0; CX[p] = G.X0 + x * s; CY[p] = G.Y0 + y * w + x * w / 2; }
      hint.style.top = Math.round(G.c0.y + cardH + 4) + 'px';
      hint.style.bottom = '';
      place(spBoard, left, T, bw, bh);
      place(spP0, G.c0.x, G.c0.y, cardW, cardH); place(spP1, G.c1.x, G.c1.y, cardW, cardH);
      buildBg();
      spr = [makeStone(col(0), G.r), makeStone(col(1), G.r)];
    }
    function corner(p, k, f) { const a = (k * Math.PI) / 3, R = G.R * (f || 1); return [CX[p] + R * Math.cos(a), CY[p] + R * Math.sin(a)]; }
    function hexPath(x, p, f) { x.beginPath(); for (let k = 0; k < 6; k++) { const q = corner(p, k, f); k ? x.lineTo(q[0], q[1]) : x.moveTo(q[0], q[1]); } x.closePath(); }
    /* polyline of the outer hex edges that touch virtual edge id E, walking clockwise */
    function edgeLine(E) {
      const cells = [];
      if (E === g.TOP) for (let x = 0; x < N; x++) cells.push([x, [0, 1]]);
      else if (E === g.RIGHT) for (let y = 0; y < N; y++) cells.push([y * N + N - 1, [1, 2]]);
      else if (E === g.BOT) for (let x = N - 1; x >= 0; x--) cells.push([(N - 1) * N + x, [3, 4]]);
      else for (let y = N - 1; y >= 0; y--) cells.push([y * N, [4, 5]]);
      const segs = [];
      for (const [p, ks] of cells) for (const k of ks) {
        const q = g.CN[p * 6 + k];
        if (q === E) segs.push([corner(p, (k + 4) % 6), corner(p, (k + 5) % 6)]);
      }
      return segs;
    }
    function outline() {
      const pts = [];
      const add = (p, ks) => { for (const k of ks) { pts.push(corner(p, (k + 4) % 6)); pts.push(corner(p, (k + 5) % 6)); } };
      for (let x = 0; x < N; x++) add(x, [0, 1]);
      for (let y = 0; y < N; y++) add(y * N + N - 1, [1, 2]);
      for (let x = N - 1; x >= 0; x--) add((N - 1) * N + x, [3, 4]);
      for (let y = N - 1; y >= 0; y--) add(y * N, [4, 5]);
      return pts;
    }
    function buildBg() {
      const dpr = cv.dpr, pad = 14;
      const ox = G.left - pad, oy = G.T - pad, bwid = G.bw + pad * 2, bhei = G.bh + pad * 2 + 6;
      const c = document.createElement('canvas'); c.width = Math.ceil(bwid * dpr); c.height = Math.ceil(bhei * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr); x.translate(-ox, -oy);
      const ol = outline();
      const olPath = () => { x.beginPath(); ol.forEach((q, i) => (i ? x.lineTo(q[0], q[1]) : x.moveTo(q[0], q[1]))); x.closePath(); };
      // walnut frame (outline grown by bm)
      const wg = x.createLinearGradient(G.left, G.T, G.left + G.bw, G.T + G.bh);
      wg.addColorStop(0, '#8a5530'); wg.addColorStop(0.5, '#6e4024'); wg.addColorStop(1, '#53301a');
      x.lineJoin = 'round'; x.lineWidth = G.bm * 2; x.strokeStyle = wg; x.fillStyle = '#4a2a16';
      olPath(); x.stroke(); x.fill();
      // grain on the frame only
      x.save(); x.globalCompositeOperation = 'source-atop';
      let seed = 11; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      for (let i = 0; i < 70; i++) {
        const yy = G.T - G.bm + rnd() * (G.bh + G.bm * 2), amp = 2 + rnd() * 5, ph = rnd() * 6;
        x.strokeStyle = 'rgba(' + (rnd() < 0.5 ? '30,14,4' : '190,130,80') + ',' + (0.05 + rnd() * 0.08).toFixed(3) + ')';
        x.lineWidth = 0.6 + rnd() * 1.4;
        x.beginPath();
        for (let xx = G.left - 10; xx <= G.left + G.bw + 10; xx += 8) { const v = yy + Math.sin(xx / 34 + ph) * amp + (xx - G.left) * 0.18; xx > G.left - 10 ? x.lineTo(xx, v) : x.moveTo(xx, v); }
        x.stroke();
      }
      const sh = x.createLinearGradient(0, G.T, 0, G.T + G.bh);
      sh.addColorStop(0, 'rgba(255,220,170,.14)'); sh.addColorStop(1, 'rgba(0,0,0,.18)');
      x.fillStyle = sh; x.fillRect(G.left - 20, G.T - 20, G.bw + 40, G.bh + 40);
      x.restore();
      // drop shadow under everything
      x.save(); x.globalCompositeOperation = 'destination-over';
      x.shadowColor = 'rgba(0,0,0,.6)'; x.shadowBlur = 14; x.shadowOffsetY = 6;
      x.lineWidth = G.bm * 2; x.strokeStyle = '#000'; x.fillStyle = '#000'; olPath(); x.stroke(); x.fill();
      x.restore();
      // goal bands in the players' colours
      const band = (E, seat) => {
        const segs = edgeLine(E);
        x.lineCap = 'round'; x.lineJoin = 'round';
        x.lineWidth = G.bm * 1.25; x.strokeStyle = mixc(col(seat), '#000000', 0.12);
        x.beginPath(); segs.forEach(([a, z]) => { x.moveTo(a[0], a[1]); x.lineTo(z[0], z[1]); }); x.stroke();
        x.lineWidth = G.bm * 0.5; x.strokeStyle = mixc(col(seat), '#ffffff', 0.35, 0.55);
        x.beginPath(); segs.forEach(([a, z]) => { x.moveTo(a[0], a[1]); x.lineTo(z[0], z[1]); }); x.stroke();
      };
      band(g.TOP, 0); band(g.BOT, 0); band(g.LEFT, 1); band(g.RIGHT, 1);
      // cells
      for (let p = 0; p < g.NN; p++) {
        const px = p % N, py = (p / N) | 0;
        const cg = x.createLinearGradient(CX[p], CY[p] - G.w / 2, CX[p], CY[p] + G.w / 2);
        cg.addColorStop(0, '#f1ddb0'); cg.addColorStop(1, '#d6b179');
        hexPath(x, p, 0.93); x.fillStyle = cg; x.fill();
        const onY = py === 0 || py === N - 1, onX = px === 0 || px === N - 1;
        if (onY !== onX) { x.fillStyle = mixc(col(onY ? 0 : 1), '#ffffff', 0.15, 0.11); x.fill(); }
        x.strokeStyle = 'rgba(255,248,230,.55)'; x.lineWidth = 1;
        x.beginPath(); const a = corner(p, 3, 0.86), m = corner(p, 4, 0.86), z = corner(p, 5, 0.86); x.moveTo(a[0], a[1]); x.lineTo(m[0], m[1]); x.lineTo(z[0], z[1]); x.stroke();
        x.strokeStyle = 'rgba(110,70,30,.35)';
        x.beginPath(); const a2 = corner(p, 0, 0.86), m2 = corner(p, 1, 0.86), z2 = corner(p, 2, 0.86); x.moveTo(a2[0], a2[1]); x.lineTo(m2[0], m2[1]); x.lineTo(z2[0], z2[1]); x.stroke();
      }
      const ctr = ((N - 1) / 2) * N + (N - 1) / 2;
      x.fillStyle = 'rgba(90,55,20,.55)'; x.beginPath(); x.arc(CX[ctr], CY[ctr], Math.max(2, G.w * 0.07), 0, 7); x.fill();
      bgc = { c, ox, oy, w: bwid, h: bhei };
    }
    function makeStone(color, r) {
      const dpr = cv.dpr, pad = Math.ceil(r * 0.45) + 2, S = Math.ceil(r * 2 + pad * 2);
      const c = document.createElement('canvas'); c.width = Math.ceil(S * dpr); c.height = Math.ceil(S * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr);
      const cx = S / 2, cy = S / 2;
      x.fillStyle = 'rgba(30,12,0,.42)'; x.beginPath(); x.ellipse(cx + r * 0.1, cy + r * 0.22, r * 1.0, r * 0.95, 0, 0, 7); x.fill();
      const gr = x.createRadialGradient(cx - r * 0.35, cy - r * 0.4, r * 0.08, cx, cy, r);
      gr.addColorStop(0, mixc(color, '#ffffff', 0.55)); gr.addColorStop(0.45, mixc(color, '#000000', 0)); gr.addColorStop(1, mixc(color, '#000000', 0.45));
      x.fillStyle = gr; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.fill();
      x.strokeStyle = mixc(color, '#000000', 0.55, 0.5); x.lineWidth = 1; x.stroke();
      const hl = x.createRadialGradient(cx - r * 0.3, cy - r * 0.45, 0, cx - r * 0.3, cy - r * 0.45, r * 0.5);
      hl.addColorStop(0, 'rgba(255,255,255,.6)'); hl.addColorStop(1, 'rgba(255,255,255,0)');
      x.fillStyle = hl; x.beginPath(); x.ellipse(cx - r * 0.3, cy - r * 0.42, r * 0.45, r * 0.26, -0.4, 0, 7); x.fill();
      return { c, S };
    }
    function stoneAt(seat, x, y, alpha, scale) {
      const sp = spr[seat]; if (!sp) return;
      const S = sp.S * (scale || 1);
      if (alpha != null && alpha < 1) { ctx.save(); ctx.globalAlpha = Math.max(0, alpha); }
      ctx.drawImage(sp.c, x - S / 2, y - S / 2, S, S);
      if (alpha != null && alpha < 1) ctx.restore();
    }
    cv.onresize = () => { if (st) { layout(); draw(); } };
    function rr(x, a, bb, w, h, r) { x.beginPath(); if (x.roundRect) x.roundRect(a, bb, w, h, r); else x.rect(a, bb, w, h); }
    function hit(px, py) {
      if (!G) return -1;
      let best = -1, bd = Infinity;
      for (let p = 0; p < g.NN; p++) { const dx = px - CX[p], dy = py - CY[p], d = dx * dx + dy * dy; if (d < bd) { bd = d; best = p; } }
      return bd <= (G.w * 0.62) * (G.w * 0.62) ? best : -1;
    }

    function drawCard(seat, pos) {
      const p = api.players[seat] || { name: seat ? '2번' : '1번' };
      const x = pos.x, y = pos.y, w = G.cardW, h = G.cardH;
      const active = st && !st.st && actor(st) === seat, won = st && st.st && st.st.w === seat;
      rr(ctx, x, y, w, h, 12);
      ctx.fillStyle = active ? 'rgba(46,38,64,.96)' : 'rgba(34,28,46,.86)'; ctx.fill();
      ctx.lineWidth = active || won ? 1.6 : 1; ctx.strokeStyle = active || won ? '#e3ae45' : 'rgba(242,233,216,.14)'; ctx.stroke();
      const sp = spr[seat];
      if (sp) { const S = 26 / (G.r * 2) * sp.S; ctx.drawImage(sp.c, x + 22 - S / 2, y + h / 2 - S / 2, S, S); }
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.font = '700 13.5px ' + FONT; ctx.fillStyle = '#f2e9d8';
      const maxW = w - 48 - 8;
      let name = String(p.name || ''); if (ctx.measureText(name).width > maxW) { while (name.length > 1 && ctx.measureText(name + '…').width > maxW) name = name.slice(0, -1); name += '…'; }
      ctx.fillText(name, x + 42, y + 14);
      ctx.font = '600 11.5px ' + FONT; ctx.fillStyle = won ? '#e3ae45' : mixc(col(seat), '#ffffff', 0.25);
      ctx.fillText(won ? '★ 연결 완성!' : seat === 0 ? '↕ 위·아래 변 잇기' : '↔ 왼쪽·오른쪽 변 잇기', x + 42, y + 30);
    }

    function draw() {
      cv.clear();
      if (!G || !st) return;
      if (bgc) ctx.drawImage(bgc.c, bgc.ox, bgc.oy, bgc.w, bgc.h);
      drawCard(1, G.c1); drawCard(0, G.c0);
      const now = performance.now();
      const p0 = turns(st) ? decAt(st.m, 0, N) : -1;
      const swapped = turns(st) >= 2 && st.m[2] === 'z';
      // stones
      for (let p = 0; p < g.NN; p++) {
        const v = b[p]; if (!v) continue;
        if (swp && p === swp.to) continue;
        let sc = 1, al = 1;
        if (drop && drop.p === p) { const k = U.clamp((now - drop.t0) / drop.dur, 0, 1); sc = 1.25 - 0.25 * (1 - Math.pow(1 - k, 3)); al = 0.45 + 0.55 * k; }
        if (swapPrev && p === p0) al = 0.38;
        stoneAt(v - 1, CX[p], CY[p], al, sc);
      }
      if (swp) {
        const k = U.clamp((now - swp.t0) / swp.dur, 0, 1), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        const x = CX[swp.from] + (CX[swp.to] - CX[swp.from]) * e, y = CY[swp.from] + (CY[swp.to] - CY[swp.from]) * e, lift = Math.sin(k * Math.PI);
        stoneAt(0, x, y - lift * G.w * 0.3, 1 - e, 1 + lift * 0.18);
        stoneAt(1, x, y - lift * G.w * 0.3, e, 1 + lift * 0.18);
      }
      // last move marker
      const lp = lastCell(st);
      if (lp >= 0 && b[lp] && !(swp && lp === swp.to) && !(drop && drop.p === lp && now < drop.t0 + drop.dur)) {
        ctx.fillStyle = 'rgba(255,248,230,.95)'; ctx.strokeStyle = 'rgba(20,12,24,.55)'; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(CX[lp], CY[lp], Math.max(2.6, G.r * 0.24), 0, 7); ctx.fill(); ctx.stroke();
      }
      // winning chain
      if (st.st && path.length) {
        const k = wa ? U.clamp((now - wa.t0) / wa.dur, 0, 1) : 1;
        const n = Math.max(1, Math.ceil(k * path.length));
        ctx.save();
        ctx.shadowColor = 'rgba(255,214,120,.9)'; ctx.shadowBlur = 10;
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.4;
        for (let i = 0; i < n; i++) { hexPath(ctx, path[i], 0.9); ctx.stroke(); }
        ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(3, G.r * 0.32); ctx.strokeStyle = 'rgba(255,240,200,.92)';
        ctx.beginPath(); for (let i = 0; i < n; i++) i ? ctx.lineTo(CX[path[i]], CY[path[i]]) : ctx.moveTo(CX[path[i]], CY[path[i]]); ctx.stroke();
        ctx.restore();
      }
      // swap preview
      if (swapPrev && swapMine() && p0 >= 0) {
        const to = mirror(p0, N);
        ctx.save();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.setLineDash([6, 5]); ctx.lineCap = 'round';
        if (to !== p0) {
          const ax = CX[p0], ay = CY[p0], zx = CX[to], zy = CY[to], ang = Math.atan2(zy - ay, zx - ax), d = Math.hypot(zx - ax, zy - ay), cut = G.r * 1.15;
          const sx = ax + Math.cos(ang) * cut, sy = ay + Math.sin(ang) * cut, ex = zx - Math.cos(ang) * cut, ey = zy - Math.sin(ang) * cut;
          if (d > cut * 2.2) {
            ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke(); ctx.setLineDash([]);
            ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(ex - Math.cos(ang - 0.5) * 10, ey - Math.sin(ang - 0.5) * 10); ctx.moveTo(ex, ey); ctx.lineTo(ex - Math.cos(ang + 0.5) * 10, ey - Math.sin(ang + 0.5) * 10); ctx.stroke();
          }
        }
        ctx.restore();
        stoneAt(1, CX[to], CY[to], 0.8);
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; hexPath(ctx, to, 0.9); ctx.stroke();
      }
      // hover (mouse) and ghost
      const mine = myTurn() && !st.st;
      if (mine && hover >= 0 && hover !== ghost && !b[hover] && !swapPrev) { ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1.6; hexPath(ctx, hover, 0.86); ctx.stroke(); }
      if (mine && ghost >= 0 && !b[ghost]) {
        stoneAt(actor(st), CX[ghost], CY[ghost], 0.6);
        ctx.save(); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.2; ctx.setLineDash([5, 3]); hexPath(ctx, ghost, 0.95); ctx.stroke(); ctx.restore();
      }
    }

    function updateHud() {
      const mine = !!st && !st.st && myTurn();
      const sm = swapMine();
      if (!sm) swapPrev = false;
      vis(swapBtn, sm);
      swapBtn.textContent = swapPrev ? '✕ 취소' : '⇄ 바꾸기';
      swapBtn.setAttribute('aria-pressed', String(swapPrev));
      vis(placeBtn, mine);
      placeBtn.disabled = !mine || !!locked() || busy || (!swapPrev && ghost < 0);
      placeBtn.textContent = swapPrev ? '바꾸기 확정' : '놓기';
      vis(undoBtn, !!st && !st.st && !api.online && st.solo >= 0);
      undoBtn.disabled = !canUndo() || busy;
      let h = '';
      if (st && !st.st) {
        const a = actor(st), P = api.players[a] || {};
        if (mine) {
          if (swapPrev) h = '첫 돌을 내 돌로 가져와요 (대각선 반대 자리로)';
          else if (sm && ghost < 0) h = '「바꾸기」로 첫 돌을 가져오거나, 놓을 칸을 탭';
          else h = ghost < 0 ? (a === 0 ? '놓을 칸을 탭 · 위·아래 변을 이으세요' : '놓을 칸을 탭 · 왼쪽·오른쪽 변을 이으세요') : '같은 칸 한 번 더 탭 또는 「놓기」';
        } else h = (P.name || '') + (P.ai ? ' 생각 중…' : ' 차례');
      } else if (st && st.st) { const P = api.players[st.st.w] || {}; h = (P.name || '') + ' 승리 · 연결 완성!'; }
      hint.textContent = h;
    }

    function onDown(e) {
      if (!st || st.st || !myTurn() || locked() || !G) return;
      const q = cv.local(e), p = hit(q.x, q.y);
      down = { p, onGhost: p >= 0 && p === ghost, moved: false, id: e.pointerId };
      if (p >= 0 && !b[p] && p !== ghost) { ghost = p; swapPrev = false; api.sfx('tick'); api.buzz(6); updateHud(); draw(); }
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
    }
    function onMove(e) {
      if (!G || !st) return;
      const q = cv.local(e), p = hit(q.x, q.y);
      if (!down) {
        if (e.pointerType === 'mouse' && p !== hover) { hover = p; if (myTurn() && !st.st) draw(); }
        return;
      }
      if (e.pointerId !== down.id) return;
      if (p >= 0 && p !== ghost && !b[p]) { ghost = p; down.moved = true; api.sfx('tick'); updateHud(); draw(); }
    }
    function onUp(e) {
      if (!down || e.pointerId !== down.id) return;
      const d = down; down = null;
      const q = cv.local(e), p = hit(q.x, q.y);
      if (d.onGhost && !d.moved && p === ghost) commit();
    }
    function onCancel() { down = null; }
    function onLeave() { if (hover >= 0) { hover = -1; draw(); } }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.cv.addEventListener('pointerleave', onLeave);

    function animate() {
      setBusy(true);
      clearTimeout(safety);
      safety = setTimeout(() => { drop = swp = wa = null; if (stopLoop) { stopLoop(); stopLoop = null; } setBusy(false); draw(); }, 3000);
      if (stopLoop) return;
      stopLoop = U.loop(() => {
        const now = performance.now();
        if (drop && now >= drop.t0 + drop.dur) drop = null;
        if (swp && now >= swp.t0 + swp.dur) { swp = null; api.sfx('pop'); }
        if (wa && now >= wa.t0 + wa.dur) wa = null;
        draw();
        if (!drop && !swp && !wa) { if (stopLoop) { stopLoop(); stopLoop = null; } clearTimeout(safety); setBusy(false); }
      });
    }

    return {
      update(next, prev) {
        const fresh = prev && prev !== next && next.seq !== shownSeq;
        const resize = !st || st.n !== next.n;
        st = next;
        if (resize) layout();
        b = boardOf(st.m, N);
        path = st.st ? Array.from({ length: st.st.p.length / 2 }, (_, i) => decAt(st.st.p, i * 2, N)) : [];
        if (ghost >= 0 && (b[ghost] || st.st)) ghost = -1;
        if (!canSwap(st)) swapPrev = false;
        if (fresh) {
          const sp = L.debug.speed || 1, now = performance.now();
          if (next.ev && next.ev.id === next.seq && next.ev.k === 'u') { api.sfx('whoosh'); api.toast('한 수 물렀어요'); ghost = -1; drop = swp = wa = null; }
          else if (next.ev && next.ev.id === next.seq && next.ev.k === 's') {
            const p0 = decAt(next.m, 0, N);
            swp = { from: p0, to: mirror(p0, N), t0: now, dur: 560 / sp };
            api.sfx('whoosh'); api.buzz(18);
            api.toast((api.players[1] ? api.players[1].name : '2번') + ' 바꾸기! 첫 돌을 가져갔어요');
            animate();
          } else if (next.m.length > (prev.m || '').length) {
            const p = decAt(next.m, next.m.length - 2, N);
            drop = { p, t0: now, dur: 170 / sp };
            api.sfx('thud'); api.buzz(10);
            if (next.st) { wa = { t0: now, dur: drop.dur + 900 / sp }; api.toast((api.players[next.st.w] ? api.players[next.st.w].name : '') + ' 연결 완성!'); api.buzz(30); }
            animate();
          }
        }
        if (!prev) { ghost = -1; swapPrev = false; }
        shownSeq = next.seq;
        updateHud();
        draw();
      },
      destroy() {
        if (stopLoop) stopLoop();
        stopLoop = null;
        clearTimeout(safety);
        setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onCancel);
        cv.cv.removeEventListener('pointerleave', onLeave);
        cv.destroy(); hud.remove(); hint.remove();
      },
    };
  }

  L.register({
    id: 'hex', name: '육각 다리 잇기', tag: '연결 전략', cat: '보드',
    icon: '<path d="M14 9l6-3.5 6 3.5v7l-6 3.5-6-3.5z" fill="currentColor"/><path d="M26 16l6-3.5 6 3.5v7l-6 3.5-6-3.5z" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M26 30l6-3.5 6 3.5v7l-6 3.5-6-3.5z" fill="currentColor"/><path d="M14 37l6-3.5 6 3.5v7l-6 3.5-6-3.5z" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M38 37l6-3.5 6 3.5v7l-6 3.5-6-3.5z" fill="currentColor" opacity=".55"/><path d="M8 4v48M48 4v48" stroke="currentColor" stroke-width="3" stroke-linecap="round" opacity=".5"/>',
    tint: '#6a3a1e',
    blurb: '육각형 칸이 깔린 마름모 판에 번갈아 돌을 놓아, 내 색 테두리 두 변을 먼저 잇는 쪽이 이겨요. 비기는 일이 없어요.',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, hidden: false, aiDelay: 300,
    options: [
      { id: 'size', label: '판 크기', choices: [{ v: 7, label: '7×7' }, { v: 9, label: '9×9' }, { v: 11, label: '11×11' }], def: 9 },
      { id: 'swap', label: '바꾸기 규칙', choices: [{ v: 1, label: '켜기' }, { v: 0, label: '끄기' }], def: 1 },
    ],
    quick: [
      '내 색 테두리 두 변(먼저 두는 쪽은 위·아래, 나중 쪽은 왼쪽·오른쪽)을 내 돌로 먼저 이으면 이겨요.',
      '내 차례: 빈 육각 칸을 탭 → 한 번 더 탭(또는 「놓기」)해 돌 1개를 놓아요.',
      '바꾸기 규칙: 첫 돌이 놓이면 나중 쪽이 딱 한 번 그 돌을 자기 것으로 가져갈 수 있어요. 비기는 일은 없어요.',
    ],
    rules: [
      { h: '목표', p: [
        '육각형 칸이 마름모 모양으로 깔린 판이에요. 둘이 번갈아 빈 칸에 내 색 돌을 하나씩 놓아요.',
        '1번 자리(먼저 둠)는 위·아래 변을, 2번 자리는 왼쪽·오른쪽 변을 이으면 이겨요. 판 테두리 색과 이름표에 각자 이을 변이 적혀 있어요.',
        '돌은 맞닿은 옆 칸(6방향)끼리 이어져요. 길이 구불구불해도 괜찮아요.',
        '비기는 일은 없어요. 한쪽 길을 막으면 그게 곧 내 길이 되거든요. 판이 다 차기 전에 반드시 누군가 이어요.'] },
      { h: '차례에 할 일', p: [
        '빈 칸 하나에 돌 1개를 놓아요. 놓은 돌은 움직이거나 잡히지 않아요.',
        '(바꾸기 규칙이 켜져 있고 내가 2번 자리라면) 첫 차례에만 돌을 놓는 대신 「바꾸기」를 할 수 있어요.'] },
      { h: '특수 규칙: 바꾸기 (기본: 켜기)', p: [
        '먼저 두는 쪽이 꽤 유리해서 쓰는 공평 규칙이에요. 설정에서 끌 수 있어요.',
        '1번 자리가 첫 돌을 놓으면, 2번 자리는 딱 한 번 「바꾸기」로 그 돌을 자기 돌로 가져갈 수 있어요.',
        '가져간 돌은 2번 자리 방향에 맞게 대각선 반대 자리로 옮겨져요(위·아래용 자리가 왼쪽·오른쪽용 자리로).',
        '바꾸기를 하면 1번 자리가 다시 둬요. 바꾸지 않으면 그냥 2번 자리가 평소처럼 돌을 놓아요.',
        '그래서 1번 자리는 첫 돌을 너무 좋은 곳(가운데)에 두면 뺏겨요. 너무 좋지도 나쁘지도 않은 가장자리 쪽이 요령이에요.'] },
      { h: '승패', p: ['내 두 변이 내 돌로 이어지는 순간 승리! 이어진 길이 금색으로 빛나요.'] },
      { h: '조작', p: [
        '칸을 탭하면 반투명 돌이 보여요. 같은 칸을 한 번 더 탭하거나 「놓기」를 누르면 확정. 누른 채 끌면 미리보기가 따라와요.',
        '「⇄ 바꾸기」를 누르면 옮겨질 자리가 먼저 보이고, 「바꾸기 확정」을 눌러야 바뀌어요(「✕ 취소」로 그만두기).',
        '마지막 돌에는 하얀 점이 찍혀요.',
        '↶ 무르기: 이 폰에서 사람 1명 대 AI일 때만. 내 직전 수와 AI 응수를 함께 되돌려요(한 번에 한 수).'] },
      { h: '작전 팁', p: [
        '다리: 한 칸 건너 비스듬히 놓은 두 돌 사이에 빈 칸이 두 개 있으면, 상대가 하나를 막아도 남은 칸으로 이을 수 있어요. 막히면 바로 남은 칸에 두세요.',
        '테두리에서 두 번째 줄에 놓은 돌은 테두리와 이어진 것과 같아요(같은 다리 원리).',
        '가운데가 강한 자리예요. 상대 길을 막는 수가 곧 내 길이 되는 수를 찾아보세요.'] },
      { h: '예시', p: [
        '내가(1번) 첫 돌을 한가운데에 둠 → AI가 「바꾸기」로 가져감 → 그 돌은 AI 돌이 되고, 내가 다시 둬요. 가운데는 너무 좋아서 뺏긴 거예요.',
        '내 돌 A와 B가 한 칸 건너 비스듬히 있고 사이 빈 칸이 둘 → 상대가 한 칸을 막으면 나는 다른 칸에 둬서 이어요.'] },
      { h: 'AI', p: [
        '쉬움은 실수가 잦고, 보통은 양쪽이 이어지기까지 남은 거리를 비교해서 두고, 어려움은 수만 판을 미리 끝까지 둬 보고(몬테카를로 탐색) 골라요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
    ],
    tutorial: [
      { sel: '.hx-board', text: '육각 칸이 깔린 마름모 판이에요. 테두리 색이 각자 이을 변이에요. 빨강 변 2개, 파랑 변 2개!' },
      { sel: '.hx-p0', text: '먼저 두는 1번 자리는 위·아래 변을, 2번 자리는 왼쪽·오른쪽 변을 이어야 해요. 이름표에 내 색과 이을 방향이 적혀 있어요.' },
      { sel: '.hx-board', text: '빈 칸을 탭하면 반투명 돌이 보여요. 한 번 더 탭하거나 「놓기」로 확정! 돌은 맞닿은 옆 칸(6방향)끼리 이어져요. 구불구불해도 돼요.' },
      { sel: '.hx-board', text: '바꾸기 규칙: 첫 돌이 놓이면, 나중 두는 쪽이 딱 한 번 「⇄ 바꾸기」로 그 돌을 자기 것으로 가져갈 수 있어요(대각선 반대 자리로 옮겨져요).' },
      { sel: '.hx-board', text: '그래서 첫 돌을 한가운데처럼 너무 좋은 곳에 두면 뺏겨요! 가장자리 쪽 적당한 자리가 요령이에요. 내가 나중 쪽이면 좋은 첫 돌은 바꾸기로 가져오세요.' },
      { sel: '.hx-hint', text: '다리 요령: 한 칸 건너 비스듬히 두면 사이 빈 칸이 둘이라, 상대가 하나를 막아도 남은 칸으로 이어요. 이 안내 줄이 지금 할 일을 알려 줘요. 비기는 일은 없어요. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { geo, boardOf, winPath, pot2, dist1, mcts, HC, easyMove, mediumMove, hardMove, bridgeReply, mirror, enc, decAt, opening, wantSwap },
  });
})();
