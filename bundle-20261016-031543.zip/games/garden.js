/* 정원 가꾸기 — 타일 고르기·배치 퍼즐 (1–4인, 턴제, 한 폰 돌려하기 가능)
   내 차례: 시장의 「타일 + 동물」 짝 4개 중 하나를 골라 → 타일을 내 정원 빈 칸에 → 동물을 사는 곳(집) 칸에 놓기.
   정원이 다 차면 끝. 점수 = 동물(1 + 좋아하는 이웃) + 벤치(옆 동물) + 의뢰 카드 3장 + 계절 심사 + 남은 도토리. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ======================= 규칙 데이터 ======================= */
  const TK = 'rybptwk';                       // 타일: 빨간 꽃 r, 노란 꽃 y, 파란 꽃 b, 연못 p, 나무 t, 오솔길 w, 벤치 k
  const TNAME = { r: '빨간 꽃', y: '노란 꽃', b: '파란 꽃', p: '연못', t: '나무', w: '오솔길', k: '벤치' };
  const TJ = { r: '을', y: '을', b: '을', p: '을', t: '를', w: '을', k: '를' };
  const TW = { r: 14, y: 14, b: 14, p: 15, t: 16, w: 15, k: 12 };   // 뽑힐 비율(%)
  const CK = 'neshf';                         // 동물: 나비 n, 벌 e, 새 s, 고슴도치 h, 개구리 f
  const CNAME = { n: '나비', e: '벌', s: '새', h: '고슴도치', f: '개구리' };
  const JOSA = { n: '는', e: '은', s: '는', h: '는', f: '는' }, CJ = { n: '가', e: '이', s: '가', h: '가', f: '가' };
  const HOME = { n: 'ryb', e: 'ryb', s: 't', h: 'w', f: 'p' };
  const HOMENAME = { n: '꽃', e: '꽃', s: '나무', h: '오솔길', f: '연못' };
  const LIKENAME = { n: '다른 색 꽃', e: '같은 색 꽃', s: '나무', h: '나무·벤치', f: '연못' };
  const CBIT = { n: 1, e: 2, s: 4, h: 8, f: 16 };
  const isF = (c) => c === 'r' || c === 'y' || c === 'b';
  const FBIT = { r: 1, y: 2, b: 4 };
  function likes(cr, home, t) {
    switch (cr) {
      case 'n': return isF(t) && t !== home;
      case 'e': return t === home;
      case 's': return t === 't';
      case 'h': return t === 't' || t === 'k';
      case 'f': return t === 'p';
    }
    return false;
  }
  const SEASON = ['봄', '여름', '가을', '겨울'];
  const THEME = { F: '꽃', p: '연못', t: '나무', w: '오솔길', k: '벤치', A: '동물' };
  const SOLO_F = { F: 0.4, p: 0.2, t: 0.2, w: 0.2, k: 0.15, A: 0.45 };   // 혼자 할 때 계절 목표 = 놓은 칸 × 비율
  const STARS = { 4: [45, 55, 65], 5: [75, 90, 105] };                  // 혼자: 별 1·2·3개 점수

  /* 정원 이웃(상하좌우) */
  const NB = {};
  [4, 5].forEach((S) => {
    const out = [];
    for (let i = 0; i < S * S; i++) {
      const x = i % S, y = (i / S) | 0, l = [];
      if (y > 0) l.push(i - S); if (x < S - 1) l.push(i + 1); if (y < S - 1) l.push(i + S); if (x > 0) l.push(i - 1);
      out.push(l);
    }
    NB[S] = out;
  });

  /* 의뢰 카드: f(C) → [점수, 개수] */
  const CARDS = {
    cl: { nm: '같은 꽃 무리', d: '같은 색 꽃이 이어진 무리마다: 2칸이면 +2점, 3칸 이상이면 +5점', ex: '빨간 꽃 3칸이 붙어 있으면 +5, 노란 꽃 2칸 무리도 있으면 +2 더.', u: '무리', ic: ['r'],
      f(C) { let k = 0, p = 0; for (let q = 0; q < C.ng; q++) if (isF(C.gch[q]) && C.sz[q] >= 2) { k++; p += C.sz[q] >= 3 ? 5 : 2; } return [p, k]; } },
    rb: { nm: '세 빛깔 줄', d: '빨강·노랑·파랑 꽃이 모두 있는 가로줄·세로줄마다 +3점', ex: '맨 윗줄에 빨강·노랑·파랑 꽃이 하나씩 있으면 +3.', u: '줄', ic: ['b', null, 'rb'],
      f(C) {
        const S = C.S, g = C.g; let k = 0;
        for (let r = 0; r < S; r++) { let m = 0, n = 0; for (let c = 0; c < S; c++) { m |= FBIT[g[r * S + c]] || 0; n |= FBIT[g[c * S + r]] || 0; } if (m === 7) k++; if (n === 7) k++; }
        return [k * 3, k];
      } },
    fp: { nm: '개구리 연못', d: '연못이 2칸 이상 이어진 무리에 사는 개구리마다 +3점', ex: '연못 2칸이 붙어 있고 두 칸 모두 개구리 → +6.', u: '마리', ic: ['p', 'f'],
      f(C) { let k = 0; for (let i = 0; i < C.g.length; i++) if (C.an[i] === 'f' && C.sz[C.lab[i]] >= 2) k++; return [k * 3, k]; } },
    pb: { nm: '길가 벤치', d: '오솔길과 닿은 벤치마다 +2점, 그 벤치가 오솔길로 다른 벤치와 이어져 있으면 +2점 더', ex: '오솔길 2칸 양 끝에 벤치가 하나씩 → 벤치마다 2+2 = 모두 +8.', u: '개', ic: ['w', null, 'k'],
      f(C) {
        const cnt = C.tmp; for (let q = 0; q < C.ng; q++) cnt[q] = 0;
        const g = C.g, nb = C.nb;
        for (let i = 0; i < g.length; i++) if (g[i] === 'k') {
          let a = -1, b = -1, c = -1;
          for (const j of nb[i]) if (g[j] === 'w') { const q = C.lab[j]; if (q !== a && q !== b && q !== c) { cnt[q]++; if (a < 0) a = q; else if (b < 0) b = q; else c = q; } }
        }
        let p = 0, k = 0;
        for (let i = 0; i < g.length; i++) if (g[i] === 'k') {
          let on = false, linked = false;
          for (const j of nb[i]) if (g[j] === 'w') { on = true; if (cnt[C.lab[j]] >= 2) linked = true; }
          if (on) { k++; p += linked ? 4 : 2; }
        }
        return [p, k];
      } },
    b3: { nm: '꽃밭 나비', d: '나비 칸과 그 상하좌우에 빨강·노랑·파랑 꽃이 다 있으면 나비마다 +3점', ex: '노란 꽃 위 나비 옆에 빨간 꽃과 파란 꽃이 있으면 +3.', u: '마리', ic: ['y', 'n'],
      f(C) {
        const g = C.g, an = C.an; let k = 0;
        for (let i = 0; i < g.length; i++) if (an[i] === 'n') { let m = FBIT[g[i]] || 0; for (const j of C.nb[i]) m |= FBIT[g[j]] || 0; if (m === 7) k++; }
        return [k * 3, k];
      } },
    fo: { nm: '숲속 새', d: '나무가 3칸 이상 이어진 숲에 사는 새마다 +3점', ex: '나무 3그루가 붙은 숲에 새 2마리 → +6.', u: '마리', ic: ['t', 's'],
      f(C) { let k = 0; for (let i = 0; i < C.g.length; i++) if (C.an[i] === 's' && C.sz[C.lab[i]] >= 3) k++; return [k * 3, k]; } },
    co: { nm: '모서리 나무', d: '정원 네 모서리 칸의 나무 1그루마다 +3점', ex: '네 모서리 중 두 곳에 나무 → +6.', u: '그루', ic: ['t', null, 'corner'],
      f(C) { const S = C.S, g = C.g; let k = 0; for (const i of [0, S - 1, S * (S - 1), S * S - 1]) if (g[i] === 't') k++; return [k * 3, k]; } },
    zo: { nm: '동물 친구들', d: '동물이 3종류면 +3, 4종류 +6, 5종류 모두 +10점', ex: '나비·새·개구리·벌이 있으면 4종류 → +6.', u: '종류', ic: [null, 'e', 'zoo'],
      f(C) { const m = C.cm; let k = 0; for (let b = 1; b < 32; b <<= 1) if (m & b) k++; return [[0, 0, 0, 3, 6, 10][k], k]; } },
    lp: { nm: '긴 오솔길', d: '가장 긴 오솔길 무리가 3칸 이상이면 1칸마다 +3점', ex: '오솔길 4칸이 이어지면 +12. 2칸뿐이면 0점.', u: '칸', ic: ['w'],
      f(C) { let m = 0; for (let q = 0; q < C.ng; q++) if (C.gch[q] === 'w' && C.sz[q] > m) m = C.sz[q]; return [m >= 3 ? m * 3 : 0, m]; } },
    sh: { nm: '그늘 벤치', d: '나무와 닿은 벤치마다 +3점', ex: '벤치 바로 위에 나무가 있으면 그 벤치는 +3.', u: '개', ic: ['k', null, 't'],
      f(C) { const g = C.g; let k = 0; for (let i = 0; i < g.length; i++) if (g[i] === 'k' && C.nb[i].some((j) => g[j] === 't')) k++; return [k * 3, k]; } },
    sq: { nm: '꽃 네모', d: '꽃(색 상관없이) 4칸이 2×2 네모로 모인 곳마다 +3점 (겹쳐도 따로 셈)', ex: '꽃 2×3칸이면 네모가 2곳 → +6.', u: '곳', ic: ['r', null, 'sq'],
      f(C) { const S = C.S, g = C.g; let k = 0; for (let y = 0; y < S - 1; y++) for (let x = 0; x < S - 1; x++) { const i = y * S + x; if (isF(g[i]) && isF(g[i + 1]) && isF(g[i + S]) && isF(g[i + S + 1])) k++; } return [k * 3, k]; } },
    wf: { nm: '물가 꽃밭', d: '연못과 닿은 꽃 1칸마다 +1점', ex: '연못 하나를 꽃 3칸이 둘러싸면 +3.', u: '칸', ic: ['p', null, 'y'],
      f(C) { const g = C.g; let k = 0; for (let i = 0; i < g.length; i++) if (isF(g[i]) && C.nb[i].some((j) => g[j] === 'p')) k++; return [k, k]; } },
    mx: { nm: '알록달록 줄', d: '꽉 찬 가로줄·세로줄의 칸이 모두 다른 종류면 그 줄마다 +2점 (꽃은 색마다 다른 종류)', ex: '한 줄이 빨간 꽃·연못·나무·벤치면 +2.', u: '줄', ic: ['y', null, 'mix'],
      f(C) {
        const S = C.S, g = C.g; let k = 0;
        for (let r = 0; r < 2 * S; r++) {
          let seen = 0, ok = true;
          for (let c = 0; c < S && ok; c++) { const ch = r < S ? g[r * S + c] : g[c * S + (r - S)]; if (ch === '.') { ok = false; break; } const b = 1 << TK.indexOf(ch); if (seen & b) ok = false; seen |= b; }
          if (ok) k++;
        }
        return [k * 2, k];
      } },
    hh: { nm: '고슴도치 길', d: '고슴도치마다, 사는 오솔길 무리의 칸 수만큼 점수', ex: '오솔길 3칸 무리에 고슴도치 2마리 → 3+3 = +6.', u: '마리', ic: ['w', 'h'],
      f(C) { let p = 0, k = 0; for (let i = 0; i < C.g.length; i++) if (C.an[i] === 'h') { k++; p += C.sz[C.lab[i]]; } return [p, k]; } },
  };
  const CARD_IDS = Object.keys(CARDS);

  /* ======================= 점수 계산 ======================= */
  const C = { S: 4, g: null, an: null, nb: null, lab: new Int16Array(25), sz: new Int16Array(25), gch: new Array(25), gfl: new Int16Array(25), tmp: new Int16Array(25), ng: 0, cm: 0 };
  const STK = new Int16Array(25);
  /* g, an: 글자 배열(또는 문자열). 반환: {an: 동물, be: 벤치, cd:[[점수,개수]×3], tot} (계절·도토리 제외) */
  function scoreAll(g, an, S, cards, full) {
    const N = S * S, nb = NB[S], lab = C.lab, sz = C.sz, gch = C.gch, gfl = C.gfl;
    C.S = S; C.g = g; C.an = an; C.nb = nb;
    for (let i = 0; i < N; i++) lab[i] = -1;
    let ng = 0;
    for (let i = 0; i < N; i++) {
      const ch = g[i];
      if (ch === '.' || lab[i] >= 0) continue;
      let sp = 0, n = 0, fl = 0; STK[sp++] = i; lab[i] = ng;
      while (sp) { const k = STK[--sp]; n++; if (an[k] !== '.') fl |= CBIT[an[k]]; for (const j of nb[k]) if (lab[j] < 0 && g[j] === ch) { lab[j] = ng; STK[sp++] = j; } }
      sz[ng] = n; gch[ng] = ch; gfl[ng] = fl; ng++;
    }
    C.ng = ng;
    let ap = 0, be = 0, cm = 0;
    for (let i = 0; i < N; i++) {
      const c = an[i];
      if (c !== '.') { cm |= CBIT[c]; let p = 1; for (const j of nb[i]) if (likes(c, g[i], g[j])) p++; ap += p; }
      if (g[i] === 'k') for (const j of nb[i]) if (an[j] !== '.') be++;
    }
    C.cm = cm;
    let tot = ap + be;
    const cd = full ? [] : null;
    for (let k = 0; k < cards.length; k++) { const r = CARDS[cards[k]].f(C); tot += r[0]; if (full) cd.push(r); }
    return full ? { an: ap, be, cd, tot } : tot;
  }
  function countTheme(g, an, th) {
    let k = 0;
    for (let i = 0; i < g.length; i++) {
      if (th === 'A') { if (an[i] !== '.') k++; }
      else if (th === 'F') { if (isF(g[i])) k++; }
      else if (g[i] === th) k++;
    }
    return k;
  }
  function seasonEnds(R) { return [Math.floor(R / 4), Math.floor(R / 2), Math.floor(R * 3 / 4), R]; }
  function seasonOf(s) { const se = seasonEnds(s.R); for (let q = 0; q < 4; q++) if (s.rd < se[q]) return q; return 3; }
  function soloNeed(s, q) { return Math.ceil(seasonEnds(s.R)[q] * SOLO_F[s.se[q]]); }
  /* 계절 심사 보너스 (counts: 사람마다 개수) */
  function seasonBonus(n, counts, need) {
    if (n === 1) return [counts[0] >= need ? 3 : 0];
    const vals = Array.from(new Set(counts.filter((c) => c > 0))).sort((a, b) => b - a);
    return counts.map((c) => (c > 0 && c === vals[0] ? 3 : n >= 3 && c > 0 && c === vals[1] ? 1 : 0));
  }
  function totals(s) {
    return s.g.map((g, i) => {
      const r = scoreAll(g, s.a[i], s.S, s.cd, true);
      return { an: r.an, be: r.be, cd: r.cd, cards: r.cd.reduce((a, b) => a + b[0], 0), sb: s.sb[i], ac: s.ac[i], tot: r.tot + s.sb[i] + s.ac[i] };
    });
  }

  /* ======================= 게임 로직 ======================= */
  function pickW(w) { let t = 0; for (const k in w) t += w[k]; let r = Math.random() * t; for (const k in w) { r -= w[k]; if (r < 0) return k; } return Object.keys(w)[0]; }
  const newTile = () => pickW(TW);
  const newCr = () => CK[Math.floor(Math.random() * CK.length)];
  const newPair = () => newTile() + newCr();
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(1, Math.min(4, players.length));
    const S = String(opts.size) === '5' ? 5 : 4, N = S * S;
    const empty = '.'.repeat(N);
    const s = {
      v: 1, n, S, R: N, rd: 0, tn: 0,
      nm: players.slice(0, n).map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 12)),
      g: Array(n).fill(empty), a: Array(n).fill(empty),
      mk: [newPair(), newPair(), newPair(), newPair()],
      ac: Array(n).fill(2), sb: Array(n).fill(0),
      cd: shuffle(CARD_IDS.slice()).slice(0, 3),
      se: shuffle(Object.keys(THEME)).slice(0, 4).join(''),
      sh: [], seq: 0, last: null, done: 0, gid: Math.floor(Math.random() * 1e6),
    };
    return s;
  }
  function actor(s) { return s.done ? null : s.tn; }
  function homesFor(g, an, cr) { const out = []; for (let i = 0; i < g.length; i++) if (an[i] === '.' && HOME[cr].indexOf(g[i]) >= 0) out.push(i); return out; }

  function apply(s, seat, a) {
    if (s.done) throw new Error('game over');
    if (seat !== s.tn) throw new Error('not your turn');
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (a.t === 'acorn') {
      if (!(s.ac[seat] > 0)) throw new Error('no acorn');
      s.ac[seat]--;
      for (let i = 0; i < s.mk.length; i++) s.mk[i] = s.mk[i][0] + newCr();
      s.last = { id: ++s.seq, seat, k: 'ac' };
      return s;
    }
    if (a.t !== 'take') throw new Error('bad action');
    const i = a.i | 0, at = a.at | 0, ca = a.ca == null ? -1 : a.ca | 0;
    if (i < 0 || i >= s.mk.length || i !== a.i) throw new Error('bad slot');
    const N = s.S * s.S;
    const g = s.g[seat].split(''), an = s.a[seat].split('');
    if (at < 0 || at >= N || at !== a.at || g[at] !== '.') throw new Error('bad cell');
    const t = s.mk[i][0], cr = s.mk[i][1];
    const before = scoreAll(g, an, s.S, s.cd);
    g[at] = t;
    if (ca >= 0) {
      if (ca >= N || an[ca] !== '.' || HOME[cr].indexOf(g[ca]) < 0) throw new Error('bad home');
      an[ca] = cr;
    } else if (ca !== -1) throw new Error('bad home');
    const after = scoreAll(g, an, s.S, s.cd);
    s.g[seat] = g.join(''); s.a[seat] = an.join('');
    s.mk.splice(i, 1); s.mk.push(newPair());
    s.last = { id: ++s.seq, seat, k: 'tk', i, at, ca, t, c: cr, d: after - before };
    s.tn = (seat + 1) % s.n;
    if (s.tn === 0) {   // 한 바퀴 끝
      s.rd++;
      const se = seasonEnds(s.R), q = se.indexOf(s.rd);
      if (q >= 0) {
        const th = s.se[q];
        const counts = s.g.map((gg, k) => countTheme(gg, s.a[k], th));
        const bon = seasonBonus(s.n, counts, soloNeed(s, q));
        bon.forEach((b, k) => { s.sb[k] += b; });
        s.sh.push(bon);
        s.last.ss = q; s.last.sc = counts; s.last.sbn = bon;
      }
      if (s.rd >= s.R) s.done = 1;
    }
    return s;
  }

  function result(s) {
    if (!s || !s.done) return null;
    const T = totals(s);
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const brk = (t) => '동물·벤치 ' + (t.an + t.be) + ' · 의뢰 ' + t.cards + ' · 계절 ' + t.sb + (t.ac ? ' · 도토리 ' + t.ac : '');
    if (s.n === 1) {
      const t = T[0], need = STARS[s.S], st = need.filter((v) => t.tot >= v).length;
      return { winners: st > 0 ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요',
        text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + t.tot + '점\n' + brk(t) + '\n별 기준 ' + need.join(' / ') + '점' };
    }
    const order = T.map((t, i) => i).sort((a, b) => T[b].tot - T[a].tot || a - b);
    const top = T[order[0]].tot, winners = order.filter((i) => T[i].tot === top);
    const lines = order.map((i, k) => {
      const rank = T.filter((t) => t.tot > T[i].tot).length + 1;
      return rank + '위  ' + nm(i) + '  ' + T[i].tot + '점\n    ' + brk(T[i]);
    });
    void lines;
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: order.map((i) => (T.filter((t) => t.tot > T[i].tot).length + 1) + '위  ' + nm(i) + '  ' + T[i].tot + '점\n    ' + brk(T[i])).join('\n') };
  }

  /* ======================= AI ======================= */
  function seasonValue(s, seat, g, an) {   // 이번 계절 심사에서 얻을 보너스(지금 끝난다면)
    const q = seasonOf(s), th = s.se[q];
    const counts = s.g.map((gg, k) => (k === seat ? countTheme(g, an, th) : countTheme(gg, s.a[k], th)));
    return seasonBonus(s.n, counts, soloNeed(s, q))[s.n === 1 ? 0 : seat];
  }
  const CFG = { pw: 0.3, hw: 0.35, acorn: 1, top: 10, sw: 0.9, am: 1 };
  function potential(g, an, S, cards, base, left) {   // 앞으로의 가능성(빈 칸마다 가장 좋은 타일, 빈 집마다 가장 좋은 동물)
    let p = 0, e = 0, p2 = 0, homes = 0;
    for (let i = 0; i < g.length; i++) {
      if (g[i] === '.') {
        e++; let m = 0;
        for (let k = 0; k < 7; k++) { g[i] = TK[k]; const v = scoreAll(g, an, S, cards) - base; if (v > m) m = v; }
        g[i] = '.'; p += m;
      } else if (an[i] === '.' && g[i] !== 'k') {
        homes++; let m = 0;
        for (let c = 0; c < 5; c++) { const cr = CK[c]; if (HOME[cr].indexOf(g[i]) < 0) continue; an[i] = cr; const v = scoreAll(g, an, S, cards) - base; if (v > m) m = v; an[i] = '.'; }
        p2 += m;
      }
    }
    const fill = homes ? Math.min(1, left / homes) : 0;
    return p * CFG.pw + p2 * CFG.hw * fill;
  }
  function allMoves(s, seat) {
    const S = s.S, g = s.g[seat].split(''), an = s.a[seat].split(''), cards = s.cd;
    const base = scoreAll(g, an, S, cards);
    const sv0 = seasonValue(s, seat, g, an);
    const moves = [];
    for (let i = 0; i < s.mk.length; i++) {
      const t = s.mk[i][0], cr = s.mk[i][1];
      for (let e = 0; e < g.length; e++) {
        if (g[e] !== '.') continue;
        g[e] = t;
        moves.push({ i, at: e, ca: -1, v: scoreAll(g, an, S, cards) - base, sv: seasonValue(s, seat, g, an) - sv0 });
        for (let k = 0; k < g.length; k++) {
          if (an[k] !== '.' || HOME[cr].indexOf(g[k]) < 0) continue;
          an[k] = cr;
          moves.push({ i, at: e, ca: k, v: scoreAll(g, an, S, cards) - base, sv: seasonValue(s, seat, g, an) - sv0 });
          an[k] = '.';
        }
        g[e] = '.';
      }
    }
    return { moves, g, an, base };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const { moves, g, an } = allMoves(s, seat);
    const strip = (m) => ({ t: 'take', i: m.i, at: m.at, ca: m.ca });
    if (lv <= 1) {
      // 쉬움: 자주 아무거나, 아니면 큰 잡음이 섞인 욕심쟁이. 동물도 가끔 그냥 풀어 줌.
      if (Math.random() < 0.35) {
        const m = moves[Math.floor(Math.random() * moves.length)];
        return strip(m);
      }
      let best = null, bv = -1e9;
      for (const m of moves) { const v = m.v + Math.random() * 5 - (m.ca >= 0 && Math.random() < 0.15 ? 3 : 0); if (v > bv) { bv = v; best = m; } }
      return strip(best);
    }
    const q = seasonOf(s), se = seasonEnds(s.R), urgent = se[q] - s.rd <= 1 ? 1 : 0.55;
    if (lv === 2) {
      let best = null, bv = -1e9;
      for (const m of moves) { const v = m.v + m.sv * 0.5 * urgent + Math.random() * 0.8; if (v > bv) { bv = v; best = m; } }
      return strip(best);
    }
    // 어려움: 즉시 점수 + 계절 경쟁 + 앞으로의 가능성(의뢰 카드 진행도·빈 집) 내다보기, 필요하면 도토리 사용
    const left = s.R - s.rd - 1;
    for (const m of moves) m.q = m.v + m.sv * urgent * CFG.sw;
    moves.sort((a, b) => b.q - a.q);
    const top = moves.slice(0, CFG.top);
    let best = top[0], bv = -1e9;
    for (const m of top) {
      const t = s.mk[m.i][0], cr = s.mk[m.i][1];
      g[m.at] = t; if (m.ca >= 0) an[m.ca] = cr;
      const base = scoreAll(g, an, s.S, s.cd);
      const v = m.q + (left > 0 ? potential(g, an, s.S, s.cd, base, left) : 0) + Math.random() * 0.15;
      g[m.at] = '.'; if (m.ca >= 0) an[m.ca] = '.';
      if (v > bv) { bv = v; best = m; }
    }
    if (CFG.acorn && s.ac[seat] > 0 && s.rd >= 1) {   // 도토리: 동물을 새로 불렀을 때 기대 점수가 1점(도토리값)보다 확실히 나으면
      let ev = 0; const K = 4;
      for (let k = 0; k < K; k++) {
        const s2 = Object.assign({}, s, { mk: s.mk.map((p) => p[0] + newCr()) });
        let b = -1e9; for (const m of allMoves(s2, seat).moves) { const q2 = m.v + m.sv * urgent * CFG.sw; if (q2 > b) b = q2; }
        ev += b;
      }
      if (ev / K - 1 > moves[0].q + CFG.am) return { t: 'acorn' };
    }
    return strip(best);
  }
  function aiDelayFor(s, seat, lv) { return lv >= 3 ? 600 : lv <= 1 ? 950 : 750; }

  /* ======================= 그림 ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,monospace';
  const fr = (k) => { const x = Math.sin(k * 12.9898 + 4.1414) * 43758.5453; return x - Math.floor(x); };
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  const FCOL = { r: ['#e2513f', '#b8352a'], y: ['#f4c534', '#d09a1a'], b: ['#5b7fe6', '#3c5bc0'] };

  function grass(ctx, x, y, s, seed) {
    const gr = ctx.createLinearGradient(x, y, x + s * 0.3, y + s);
    gr.addColorStop(0, '#80bb62'); gr.addColorStop(1, '#5a9447');
    ctx.fillStyle = gr; rr(ctx, x, y, s, s, s * 0.12); ctx.fill();
    ctx.strokeStyle = 'rgba(32,74,26,.35)'; ctx.lineWidth = Math.max(1, s * 0.02); ctx.lineCap = 'round';
    ctx.beginPath();
    for (let k = 0; k < 6; k++) {
      const px = x + s * (0.1 + 0.8 * fr(seed * 7 + k * 3)), py = y + s * (0.15 + 0.8 * fr(seed * 5 + k * 11 + 1));
      ctx.moveTo(px, py); ctx.lineTo(px - s * 0.025, py - s * 0.06); ctx.moveTo(px, py); ctx.lineTo(px + s * 0.03, py - s * 0.055);
    }
    ctx.stroke();
  }
  function blossom(ctx, t, cx, cy, r) {
    const c = FCOL[t];
    if (t === 'r') {        // 둥근 꽃잎 5장
      ctx.fillStyle = c[0];
      for (let k = 0; k < 5; k++) { const a = k * Math.PI * 2 / 5 - Math.PI / 2; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * r * 0.55, cy + Math.sin(a) * r * 0.55, r * 0.5, 0, 7); ctx.fill(); }
      ctx.fillStyle = c[1]; ctx.beginPath(); ctx.arc(cx, cy, r * 0.32, 0, 7); ctx.fill();
      ctx.fillStyle = '#ffe08a'; ctx.beginPath(); ctx.arc(cx, cy, r * 0.17, 0, 7); ctx.fill();
    } else if (t === 'y') { // 뾰족 꽃잎 8장 + 갈색 가운데
      ctx.fillStyle = c[0];
      for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; ctx.beginPath(); ctx.ellipse(cx + Math.cos(a) * r * 0.58, cy + Math.sin(a) * r * 0.58, r * 0.42, r * 0.18, a, 0, 7); ctx.fill(); }
      ctx.fillStyle = '#7a4a1e'; ctx.beginPath(); ctx.arc(cx, cy, r * 0.36, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,220,140,.35)'; ctx.beginPath(); ctx.arc(cx - r * 0.1, cy - r * 0.1, r * 0.14, 0, 7); ctx.fill();
    } else {                // 십자 꽃잎 4장(초롱) + 흰 가운데
      ctx.fillStyle = c[0];
      for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + Math.PI / 4; ctx.beginPath(); ctx.ellipse(cx + Math.cos(a) * r * 0.48, cy + Math.sin(a) * r * 0.48, r * 0.5, r * 0.32, a, 0, 7); ctx.fill(); }
      ctx.fillStyle = c[1]; for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + Math.PI / 4; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * r * 0.62, cy + Math.sin(a) * r * 0.62, r * 0.12, 0, 7); ctx.fill(); }
      ctx.fillStyle = '#f6f2ff'; ctx.beginPath(); ctx.arc(cx, cy, r * 0.2, 0, 7); ctx.fill();
    }
  }
  const FPOS = [[0.27, 0.3], [0.7, 0.26], [0.5, 0.56], [0.24, 0.76], [0.76, 0.74]];
  /* 타일 하나 (mask: 같은 종류 이웃 위1 오른2 아래4 왼8) */
  function drawTile(ctx, t, x, y, s, mask, seed, ext) {
    ext = ext || 0;
    grass(ctx, x, y, s, seed);
    if (mask) {   // 이어진 이웃 쪽으로 풀밭을 칸 사이 틈까지 넓힘
      ctx.fillStyle = '#6aa553';
      if (mask & 1) ctx.fillRect(x + s * 0.2, y - ext - 1, s * 0.6, ext + s * 0.2);
      if (mask & 2) ctx.fillRect(x + s * 0.8, y + s * 0.2, ext + s * 0.2 + 1, s * 0.6);
      if (mask & 4) ctx.fillRect(x + s * 0.2, y + s * 0.8, s * 0.6, ext + s * 0.2 + 1);
      if (mask & 8) ctx.fillRect(x - ext - 1, y + s * 0.2, ext + s * 0.2, s * 0.6);
    }
    if (isF(t)) {
      ctx.fillStyle = 'rgba(40,80,30,.5)';
      for (let k = 0; k < 5; k++) { const p = FPOS[k]; ctx.beginPath(); ctx.ellipse(x + s * p[0] + s * 0.06, y + s * p[1] + s * 0.08, s * 0.07, s * 0.035, 0.6, 0, 7); ctx.fill(); }
      for (let k = 0; k < 5; k++) { const p = FPOS[k]; blossom(ctx, t, x + s * (p[0] + (fr(seed + k) - 0.5) * 0.06), y + s * (p[1] + (fr(seed * 3 + k) - 0.5) * 0.06), s * (0.11 + fr(seed + k * 9) * 0.025)); }
    } else if (t === 'p') {
      const m = s * 0.13, cx = x + s / 2, cy = y + s / 2, wd = s * 0.74;
      ctx.fillStyle = '#4a7a3a';
      rr(ctx, x + m - 2, y + m - 1, s - 2 * m + 4, s - 2 * m + 4, s * 0.3); ctx.fill();
      const water = ctx.createRadialGradient(cx - s * 0.1, cy - s * 0.12, s * 0.05, cx, cy, s * 0.5);
      water.addColorStop(0, '#8fd0ef'); water.addColorStop(1, '#3a84c0');
      ctx.fillStyle = water;
      rr(ctx, x + m, y + m, s - 2 * m, s - 2 * m, s * 0.28); ctx.fill();
      if (mask & 1) ctx.fillRect(cx - wd / 2, y - ext - 1, wd, s / 2 + ext + 1);
      if (mask & 2) ctx.fillRect(cx, cy - wd / 2, s / 2 + ext + 1, wd);
      if (mask & 4) ctx.fillRect(cx - wd / 2, cy, wd, s / 2 + ext + 1);
      if (mask & 8) ctx.fillRect(x - ext - 1, cy - wd / 2, s / 2 + ext + 1, wd);
      ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = Math.max(1, s * 0.025);
      ctx.beginPath(); ctx.ellipse(cx - s * 0.12, cy - s * 0.1, s * 0.12, s * 0.05, 0, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke();
      ctx.beginPath(); ctx.ellipse(cx + s * 0.12, cy + s * 0.12, s * 0.08, s * 0.03, 0, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke();
      if (fr(seed) > 0.35) { // 연잎
        const lx = x + s * (0.3 + fr(seed * 2) * 0.4), ly = y + s * (0.6 + fr(seed * 4) * 0.12);
        ctx.fillStyle = '#5aa64a'; ctx.beginPath(); ctx.moveTo(lx, ly); ctx.arc(lx, ly, s * 0.1, 0.4, Math.PI * 2 - 0.1); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#f5a9c6'; ctx.beginPath(); ctx.arc(lx - s * 0.02, ly - s * 0.02, s * 0.03, 0, 7); ctx.fill();
      }
    } else if (t === 't') {
      const cx = x + s / 2, cy = y + s * 0.46;
      ctx.fillStyle = 'rgba(20,50,15,.38)'; ctx.beginPath(); ctx.ellipse(cx + s * 0.05, y + s * 0.8, s * 0.3, s * 0.1, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#6b4426'; rr(ctx, cx - s * 0.05, cy + s * 0.1, s * 0.1, s * 0.3, s * 0.03); ctx.fill();
      ctx.fillStyle = '#2f6e33';
      [[0, -0.06, 0.25], [-0.17, 0.06, 0.18], [0.17, 0.06, 0.18], [0, 0.1, 0.2]].forEach((c) => { ctx.beginPath(); ctx.arc(cx + c[0] * s, cy + c[1] * s, c[2] * s, 0, 7); ctx.fill(); });
      ctx.fillStyle = '#4c9a45';
      [[-0.05, -0.12, 0.15], [-0.17, 0.01, 0.1], [0.12, -0.02, 0.11]].forEach((c) => { ctx.beginPath(); ctx.arc(cx + c[0] * s, cy + c[1] * s, c[2] * s, 0, 7); ctx.fill(); });
      ctx.fillStyle = 'rgba(190,240,150,.35)'; ctx.beginPath(); ctx.arc(cx - s * 0.09, cy - s * 0.17, s * 0.06, 0, 7); ctx.fill();
      if (fr(seed) > 0.5) { ctx.fillStyle = '#e2513f'; ctx.beginPath(); ctx.arc(cx + s * 0.1, cy + s * 0.04, s * 0.03, 0, 7); ctx.arc(cx - s * 0.12, cy + s * 0.1, s * 0.028, 0, 7); ctx.fill(); }
    } else if (t === 'w') {
      const cx = x + s / 2, cy = y + s / 2, wd = s * 0.44;
      const lone = !mask;
      if (lone) { mask = 10; ext = -s * 0.04; }   // 혼자 있는 길은 가로로 지나가는 길로(틈까지는 안 감)
      ctx.fillStyle = '#c9ad7a';
      ctx.beginPath(); ctx.arc(cx, cy, wd / 2 + s * 0.02, 0, 7); ctx.fill();
      if (mask & 1) ctx.fillRect(cx - wd / 2, y - ext - 1, wd, s / 2 + ext + 1);
      if (mask & 2) ctx.fillRect(cx, cy - wd / 2, s / 2 + ext + 1, wd);
      if (mask & 4) ctx.fillRect(cx - wd / 2, cy, wd, s / 2 + ext + 1);
      if (mask & 8) ctx.fillRect(x - ext - 1, cy - wd / 2, s / 2 + ext + 1, wd);
      ctx.fillStyle = '#e3cfa2';
      const st = [[0, 0]];
      if (mask & 1) st.push([0, -0.32]); if (mask & 2) st.push([0.32, 0]); if (mask & 4) st.push([0, 0.32]); if (mask & 8) st.push([-0.32, 0]);
      st.forEach((p, k) => { ctx.beginPath(); ctx.ellipse(cx + p[0] * s, cy + p[1] * s, s * 0.09, s * 0.065, fr(seed + k) * 2, 0, 7); ctx.fill(); });
      ctx.fillStyle = 'rgba(120,90,50,.35)';
      st.forEach((p, k) => { ctx.beginPath(); ctx.ellipse(cx + p[0] * s + 1, cy + p[1] * s + s * 0.05, s * 0.08, s * 0.02, 0, 0, Math.PI); ctx.fill(); });
    } else if (t === 'k') {
      const cx = x + s / 2, cy = y + s * 0.55;
      ctx.fillStyle = 'rgba(20,50,15,.35)'; ctx.beginPath(); ctx.ellipse(cx + s * 0.04, cy + s * 0.18, s * 0.36, s * 0.07, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#4a2f18';
      [-0.27, 0.23].forEach((dx) => { ctx.fillRect(cx + dx * s, cy, s * 0.05, s * 0.19); });
      ctx.fillStyle = '#9a5f33'; rr(ctx, cx - s * 0.34, cy - s * 0.27, s * 0.68, s * 0.08, s * 0.02); ctx.fill();
      rr(ctx, cx - s * 0.34, cy - s * 0.15, s * 0.68, s * 0.08, s * 0.02); ctx.fill();
      ctx.fillStyle = '#b97a45'; rr(ctx, cx - s * 0.38, cy - s * 0.02, s * 0.76, s * 0.1, s * 0.025); ctx.fill();
      ctx.fillStyle = 'rgba(255,230,190,.3)'; ctx.fillRect(cx - s * 0.36, cy - s * 0.01, s * 0.72, s * 0.02);
      ctx.fillStyle = '#4a2f18'; [-0.3, 0.26].forEach((dx) => { ctx.fillRect(cx + dx * s, cy - s * 0.3, s * 0.04, s * 0.3); });
    }
  }
  /* 동물: 상아색 원판 위에 그림 (cx, cy 중심, r = 원판 반지름) */
  function drawCreature(ctx, c, cx, cy, r, noDisc) {
    if (!noDisc) {
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.arc(cx + r * 0.08, cy + r * 0.14, r, 0, 7); ctx.fill();
      const gr = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r);
      gr.addColorStop(0, '#fffaf0'); gr.addColorStop(1, '#e8dcc0');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fill();
      ctx.strokeStyle = '#a07a45'; ctx.lineWidth = Math.max(1, r * 0.09); ctx.stroke();
    }
    const u = r * 0.82;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (c === 'n') {        // 나비
      ctx.fillStyle = '#9b59d0';
      [[-1, -1, 0.5, 0.38, -0.5], [1, -1, 0.5, 0.38, 0.5]].forEach((w) => { ctx.beginPath(); ctx.ellipse(cx + w[0] * u * 0.42, cy + w[1] * u * 0.25, u * w[2], u * w[3], w[4], 0, 7); ctx.fill(); });
      ctx.fillStyle = '#c084e8';
      [[-1, 1], [1, 1]].forEach((w) => { ctx.beginPath(); ctx.ellipse(cx + w[0] * u * 0.32, cy + u * 0.3, u * 0.3, u * 0.24, w[0] * 0.6, 0, 7); ctx.fill(); });
      ctx.fillStyle = '#f39a3c'; [-1, 1].forEach((d) => { ctx.beginPath(); ctx.arc(cx + d * u * 0.45, cy - u * 0.28, u * 0.13, 0, 7); ctx.fill(); });
      ctx.strokeStyle = '#2b1d33'; ctx.lineWidth = u * 0.16; ctx.beginPath(); ctx.moveTo(cx, cy - u * 0.45); ctx.lineTo(cx, cy + u * 0.5); ctx.stroke();
      ctx.lineWidth = u * 0.06; ctx.beginPath(); ctx.moveTo(cx, cy - u * 0.45); ctx.lineTo(cx - u * 0.22, cy - u * 0.75); ctx.moveTo(cx, cy - u * 0.45); ctx.lineTo(cx + u * 0.22, cy - u * 0.75); ctx.stroke();
    } else if (c === 'e') { // 벌
      ctx.fillStyle = 'rgba(220,240,255,.9)'; ctx.strokeStyle = 'rgba(80,110,140,.6)'; ctx.lineWidth = u * 0.05;
      [-1, 1].forEach((d) => { ctx.beginPath(); ctx.ellipse(cx + d * u * 0.22, cy - u * 0.42, u * 0.24, u * 0.34, d * 0.5, 0, 7); ctx.fill(); ctx.stroke(); });
      ctx.save(); ctx.beginPath(); ctx.ellipse(cx, cy + u * 0.08, u * 0.62, u * 0.42, 0, 0, 7); ctx.fillStyle = '#f2c230'; ctx.fill(); ctx.clip();
      ctx.fillStyle = '#2a1f14'; [-0.2, 0.18].forEach((dx) => ctx.fillRect(cx + dx * u - u * 0.09, cy - u * 0.5, u * 0.18, u * 1.2));
      ctx.restore();
      ctx.fillStyle = '#2a1f14'; ctx.beginPath(); ctx.arc(cx - u * 0.55, cy + u * 0.02, u * 0.22, 0, 7); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(cx - u * 0.6, cy - u * 0.03, u * 0.07, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.moveTo(cx + u * 0.6, cy + u * 0.05); ctx.lineTo(cx + u * 0.82, cy + u * 0.1); ctx.lineTo(cx + u * 0.6, cy + u * 0.18); ctx.fillStyle = '#2a1f14'; ctx.fill();
    } else if (c === 's') { // 새
      ctx.fillStyle = '#3c74b8'; ctx.beginPath(); ctx.moveTo(cx + u * 0.4, cy + u * 0.1); ctx.lineTo(cx + u * 0.85, cy - u * 0.15); ctx.lineTo(cx + u * 0.75, cy + u * 0.3); ctx.fill();
      ctx.fillStyle = '#5aa0d8'; ctx.beginPath(); ctx.arc(cx, cy + u * 0.05, u * 0.58, 0, 7); ctx.fill();
      ctx.fillStyle = '#f3e3c4'; ctx.beginPath(); ctx.ellipse(cx - u * 0.08, cy + u * 0.25, u * 0.36, u * 0.3, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#3c74b8'; ctx.beginPath(); ctx.ellipse(cx + u * 0.18, cy + u * 0.05, u * 0.3, u * 0.18, -0.4, 0, 7); ctx.fill();
      ctx.fillStyle = '#f39a3c'; ctx.beginPath(); ctx.moveTo(cx - u * 0.52, cy - u * 0.12); ctx.lineTo(cx - u * 0.85, cy - u * 0.02); ctx.lineTo(cx - u * 0.52, cy + u * 0.06); ctx.fill();
      ctx.fillStyle = '#1b1426'; ctx.beginPath(); ctx.arc(cx - u * 0.28, cy - u * 0.18, u * 0.08, 0, 7); ctx.fill();
    } else if (c === 'h') { // 고슴도치
      ctx.fillStyle = '#6b4a2c'; ctx.beginPath();
      const n = 9;
      for (let k = 0; k <= n; k++) {
        const a = Math.PI + (k / n) * Math.PI, rr2 = k % 2 ? u * 0.78 : u * 0.6;
        const px = cx + u * 0.12 + Math.cos(a) * rr2, py = cy + u * 0.3 + Math.sin(a) * rr2 * 0.95;
        if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#4a321d'; ctx.beginPath(); ctx.ellipse(cx + u * 0.15, cy + u * 0.05, u * 0.45, u * 0.32, 0, Math.PI, 0); ctx.fill();
      ctx.fillStyle = '#e8c79a'; ctx.beginPath(); ctx.moveTo(cx - u * 0.5, cy + u * 0.3); ctx.quadraticCurveTo(cx - u * 0.45, cy - u * 0.1, cx - u * 0.1, cy - u * 0.02); ctx.lineTo(cx - u * 0.1, cy + u * 0.34); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#1b1426'; ctx.beginPath(); ctx.arc(cx - u * 0.82, cy + u * 0.28, u * 0.08, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.moveTo(cx - u * 0.5, cy + u * 0.3); ctx.lineTo(cx - u * 0.82, cy + u * 0.3); ctx.lineTo(cx - u * 0.42, cy + u * 0.1); ctx.fill();
      ctx.beginPath(); ctx.arc(cx - u * 0.32, cy + u * 0.1, u * 0.06, 0, 7); ctx.fill();
      ctx.fillStyle = '#e8c79a'; ctx.beginPath(); ctx.arc(cx - u * 0.82, cy + u * 0.28, u * 0.04, 0, 7);
    } else if (c === 'f') { // 개구리
      ctx.fillStyle = '#3f8f3a'; [-1, 1].forEach((d) => { ctx.beginPath(); ctx.ellipse(cx + d * u * 0.5, cy + u * 0.45, u * 0.26, u * 0.14, d * 0.3, 0, 7); ctx.fill(); });
      ctx.fillStyle = '#5cb84a'; ctx.beginPath(); ctx.ellipse(cx, cy + u * 0.15, u * 0.62, u * 0.46, 0, 0, 7); ctx.fill();
      [-1, 1].forEach((d) => { ctx.beginPath(); ctx.arc(cx + d * u * 0.3, cy - u * 0.28, u * 0.22, 0, 7); ctx.fill(); });
      ctx.fillStyle = '#fff'; [-1, 1].forEach((d) => { ctx.beginPath(); ctx.arc(cx + d * u * 0.3, cy - u * 0.3, u * 0.14, 0, 7); ctx.fill(); });
      ctx.fillStyle = '#1b1426'; [-1, 1].forEach((d) => { ctx.beginPath(); ctx.arc(cx + d * u * 0.3, cy - u * 0.28, u * 0.07, 0, 7); ctx.fill(); });
      ctx.strokeStyle = '#2a5a24'; ctx.lineWidth = u * 0.07; ctx.beginPath(); ctx.arc(cx, cy + u * 0.05, u * 0.3, 0.3, Math.PI - 0.3); ctx.stroke();
      ctx.fillStyle = 'rgba(255,180,180,.6)'; [-1, 1].forEach((d) => { ctx.beginPath(); ctx.arc(cx + d * u * 0.42, cy + u * 0.12, u * 0.08, 0, 7); ctx.fill(); });
    }
  }
  function cardIcon(ctx, id, sz) {
    const ic = CARDS[id] ? CARDS[id].ic : ['r'];
    const s = sz * 0.78;
    if (ic[2] === 'zoo') {
      ['n', 'e', 's', 'f'].forEach((c, k) => drawCreature(ctx, c, sz * (0.27 + (k % 2) * 0.46), sz * (0.27 + (k >> 1) * 0.46), sz * 0.22));
      return;
    }
    if (ic[2] === 'rb') {
      ['r', 'y', 'b'].forEach((t, k) => blossom(ctx, t, sz * (0.2 + k * 0.3), sz * 0.5, sz * 0.15));
      return;
    }
    if (ic[2] === 'mix') {
      ['r', 'p', 't', 'k'].forEach((t, k) => drawTile(ctx, t, sz * (k % 2) * 0.5, sz * (k >> 1) * 0.5, sz * 0.48, 0, k + 1));
      return;
    }
    if (ic[2] === 'sq') { for (let k = 0; k < 4; k++) drawTile(ctx, 'ryby'[k], sz * (k % 2) * 0.5, sz * (k >> 1) * 0.5, sz * 0.49, 0, k + 3); return; }
    if (ic[2] === 'corner') {
      ctx.strokeStyle = '#7a5233'; ctx.lineWidth = sz * 0.07; rr(ctx, sz * 0.05, sz * 0.05, sz * 0.9, sz * 0.9, sz * 0.1); ctx.stroke();
      drawTile(ctx, 't', 0, 0, sz * 0.5, 0, 2); drawTile(ctx, 't', sz * 0.5, sz * 0.5, sz * 0.5, 0, 5);
      return;
    }
    if (ic[2]) { // 두 타일 나란히
      drawTile(ctx, ic[0], 0, sz * 0.12, sz * 0.52, ic[0] === ic[2] ? 2 : 0, 3);
      drawTile(ctx, ic[2], sz * 0.48, sz * 0.36, sz * 0.52, 0, 7);
      return;
    }
    if (ic[0]) drawTile(ctx, ic[0], (sz - s) / 2 - (ic[1] ? sz * 0.08 : 0), (sz - s) / 2 + (ic[1] ? sz * 0.08 : 0), s, 0, 4);
    if (ic[1]) drawCreature(ctx, ic[1], sz * 0.7, sz * 0.3, sz * 0.27);
  }

  /* ======================= 화면 ======================= */
  const CSS = `
.gd{position:absolute;inset:0;display:flex;flex-direction:column;gap:6px;padding:8px 10px 10px;box-sizing:border-box;background:radial-gradient(120% 70% at 50% 45%,#23301f 0%,#17131f 75%)}
.gd button{font:inherit;color:inherit}
.gd-pl{display:flex;gap:6px;flex:none}
.gd-chip{flex:1 1 0;min-width:0;min-height:44px;display:flex;align-items:center;gap:4px;padding:4px 7px 4px 8px;border-radius:12px;border:1px solid var(--line);border-left:5px solid var(--c);background:var(--surface);font-size:13px;font-weight:700;cursor:pointer;touch-action:manipulation}
.gd-chip .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1 1 auto;min-width:0;text-align:left}
.gd-chip .sc{font-family:var(--f-mono);font-size:15px;color:var(--brass)}
.gd-chip.view{border-color:var(--brass);background:var(--surface-2)}
.gd-chip.act{animation:gdp 1.3s ease-in-out infinite}
.gd-chip.flash{animation:gdf .9s ease-out}
@keyframes gdp{0%,100%{box-shadow:0 0 0 1px rgba(227,174,69,.25)}50%{box-shadow:0 0 0 3px rgba(227,174,69,.75)}}
@keyframes gdf{0%{background:#4c6b33}100%{background:var(--surface)}}
.gd-cards{display:flex;gap:6px;flex:none}
.gd-card{flex:1 1 0;min-width:0;min-height:54px;display:flex;flex-direction:column;justify-content:center;gap:2px;padding:4px 6px;border-radius:10px;border:1px solid #c9a96a;background:linear-gradient(#f5ecd8,#e4d4b0);color:#3a2a14 !important;cursor:pointer;text-align:left;touch-action:manipulation;box-shadow:0 2px 0 #9c7b45}
.gd-card.base{background:linear-gradient(#e6f0d6,#cfe0b4);border-color:#8fb26a;box-shadow:0 2px 0 #5f8240}
.gd-card .r1{display:flex;align-items:center;justify-content:space-between;gap:4px}
.gd-card canvas{width:24px;height:24px;flex:none}
.gd-card .p{font-family:var(--f-mono);font-weight:700;font-size:14px;color:#2f6b2a;white-space:nowrap}
.gd-card .t{font-size:11.5px;font-weight:700;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gd-season{flex:none;min-height:44px;display:flex;align-items:center;gap:8px;padding:4px 10px;border-radius:12px;border:1px solid var(--line);background:var(--surface);cursor:pointer;font-size:13px;font-weight:700;text-align:left;touch-action:manipulation}
.gd-season .sn{font-family:var(--f-display);font-weight:400;font-size:17px;color:var(--brass);flex:none}
.gd-season .tx{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gd-season .dots{display:flex;gap:4px;flex:none}
.gd-season .dots i{width:9px;height:9px;border-radius:50%;background:rgba(242,233,216,.18);display:block}
.gd-season .dots i.on{background:var(--brass)}
.gd-season .dots i.past{background:#7fae5a}
.gd-season .rd{font-family:var(--f-mono);font-size:12px;color:var(--muted);flex:none}
.gd-board{position:relative;flex:1 1 auto;min-height:120px}
.gd-back{position:absolute;left:4px;top:4px;z-index:2;min-height:44px !important}
.gd-hint{flex:none;font-size:13px;line-height:18px;min-height:18px;color:var(--muted);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gd-hint.me{color:var(--brass)}
.gd-mk{display:flex;gap:6px;flex:none}
.gd-pair{flex:1 1 0;min-width:0;height:66px;border-radius:12px;border:2px solid #5a4330;background:#3a2c22;padding:0;cursor:pointer;position:relative;touch-action:manipulation;transition:transform .12s}
.gd-pair canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
.gd-pair.sel{border-color:var(--brass);transform:translateY(-4px);box-shadow:0 6px 14px rgba(0,0,0,.4)}
.gd-pair.new{animation:gdin .55s ease-out}
.gd-pair[disabled]{cursor:default}
.gd-pair .bd{position:absolute;right:3px;top:3px;font:700 11px var(--f-mono);background:rgba(23,19,31,.85);color:var(--brass);border-radius:6px;padding:1px 4px;pointer-events:none}
@keyframes gdin{0%{transform:translateX(30px);opacity:0}100%{transform:none;opacity:1}}
.gd-act{display:flex;gap:6px;flex:none}
.gd-act .btn{min-height:44px;padding:8px 10px}
.gd-act .ac{flex:0 0 auto;min-width:64px}
.gd-act .un{flex:1 1 0}
.gd-act .ok{flex:1.5 1 0}
.gd-act .ok.soft{background:var(--surface-2);color:var(--ink);border-color:var(--brass)}
.gd-ov .sheet{gap:10px;touch-action:pan-y;overscroll-behavior:contain}
.gd-ov .row2 p{font-size:14px;line-height:1.4}
.gd-ov td.w{text-align:right;color:var(--brass);font-weight:700;font-size:12px}
.gd-ov h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:22px}
.gd-ov p{margin:0;line-height:1.5}
.gd-ov .row2{display:flex;align-items:center;gap:10px}
.gd-ov canvas{flex:none}
.gd-ov table{border-collapse:collapse;width:100%;font-size:13px}
.gd-ov td{padding:4px 2px;border-bottom:1px solid var(--line)}
.gd-ov td.n{font-family:var(--f-mono);text-align:right;color:var(--brass);font-weight:700}
@media (max-height:700px){.gd{gap:5px;padding:6px 8px 8px}.gd-card{min-height:50px}.gd-pair{height:60px}.gd-hint{font-size:12px}}
`;

  function mount(root, api) {
    const h = L.h;
    const styleEl = h('style', { text: CSS });
    const wrap = h('div', { class: 'gd' });
    const plRow = h('div', { class: 'gd-pl' });
    const cardRow = h('div', { class: 'gd-cards' });
    const seasonBtn = h('button', { class: 'gd-season', 'aria-label': '계절 심사 보기' });
    const board = h('div', { class: 'gd-board' });
    const hint = h('div', { class: 'gd-hint' });
    const mkRow = h('div', { class: 'gd-mk' });
    const actRow = h('div', { class: 'gd-act' });
    const acBtn = h('button', { class: 'btn ac', 'aria-label': '도토리로 시장 동물 새로 부르기' });
    const unBtn = h('button', { class: 'btn un', text: '되돌리기' });
    const okBtn = h('button', { class: 'btn primary ok', text: '확정' });
    actRow.append(acBtn, unBtn, okBtn);
    wrap.append(plRow, cardRow, seasonBtn, board, hint, mkRow, actRow);
    root.append(styleEl, wrap);
    const cv = U.canvas(board);
    const ctx = cv.ctx;
    const backBtn = h('button', { class: 'btn sm gd-back', text: '← 내 정원', hidden: true });
    board.append(backBtn);

    let st = null, gameKey = '', shownId = -1;
    let sel = { i: -1, at: -1, ca: -2 };   // ca: -2 아직 / -1 풀어 주기 / 칸
    let manual = null, pending = false, pendT = 0, acArm = 0, acT = 0;
    let geo = null, hover = -1;
    let anim = null, stopLoop = null, watchdog = 0, followSeat = 0;
    let scores = null;           // totals(st)
    let opts = null;             // 미리보기 계산 결과
    const pairEls = [], pairCv = [];
    let cardEls = [], cardKey = '';

    /* ---------- 상태 헬퍼 ---------- */
    const myTurn = () => { if (!st) return false; const a = actor(st); return a != null && api.canAct(a) && !pending; };
    function viewSeat() {
      if (!st) return 0;
      if (manual != null && manual < st.n) return manual;
      const a = actor(st), mine = api.mySeats();
      if (a != null && api.canAct(a)) return a;
      if (mine.length === 1) return mine[0];
      if (mine.length > 1) return followSeat;   // 한 폰 여럿: 마지막 사람 정원
      return followSeat;                        // 관전(전부 AI): 방금 둔 사람
    }
    function arrays(seat) { return { g: st.g[seat].split(''), an: st.a[seat].split('') }; }

    /* 미리보기: 고른 짝/칸에 따라 점수 계산 */
    function computeOpts() {
      opts = null;
      if (!st || sel.i < 0 || !myTurn()) return;
      const seat = actor(st), { g, an } = arrays(seat), pr = st.mk[sel.i];
      if (!pr) return;
      const t = pr[0], cr = pr[1], S = st.S;
      const base = scoreAll(g, an, S, st.cd, true);
      opts = { seat, t, cr, base, cell: {}, home: {}, homes: [] };
      if (sel.at < 0) {
        for (let e = 0; e < g.length; e++) {
          if (g[e] !== '.') continue;
          g[e] = t;
          let m = scoreAll(g, an, S, st.cd) - base.tot;
          for (let k = 0; k < g.length; k++) {
            if (an[k] !== '.' || HOME[cr].indexOf(g[k]) < 0) continue;
            an[k] = cr; const v = scoreAll(g, an, S, st.cd) - base.tot; an[k] = '.';
            if (v > m) m = v;
          }
          g[e] = '.';
          opts.cell[e] = m;
        }
      } else {
        g[sel.at] = t;
        opts.homes = homesFor(g, an, cr);
        opts.rel = scoreAll(g, an, S, st.cd) - base.tot;
        for (const k of opts.homes) { an[k] = cr; opts.home[k] = scoreAll(g, an, S, st.cd) - base.tot; an[k] = '.'; }
        const ca = sel.ca >= 0 ? sel.ca : -1;
        if (ca >= 0) an[ca] = cr;
        const r = scoreAll(g, an, S, st.cd, true);
        opts.after = r;
        opts.delta = r.tot - base.tot;
        opts.dAn = (r.an + r.be) - (base.an + base.be);
        opts.dCd = r.cd.reduce((a, b) => a + b[0], 0) - base.cd.reduce((a, b) => a + b[0], 0);
      }
    }

    /* ---------- 위: 사람 칩 ---------- */
    function renderChips() {
      if (!st) return;
      if (plRow.children.length !== st.n) {
        plRow.innerHTML = '';
        for (let i = 0; i < st.n; i++) {
          const b = h('button', { class: 'gd-chip', style: { '--c': api.players[i] ? api.players[i].color : '#888' }, onclick() { onChip(i); } },
            h('span', { class: 'nm' }), h('span', { class: 'sc' }));
          plRow.append(b);
        }
      }
      const a = actor(st), v = viewSeat();
      for (let i = 0; i < st.n; i++) {
        const b = plRow.children[i];
        const p = api.players[i];
        b.querySelector('.nm').textContent = (p ? p.name : st.nm[i]);
        b.querySelector('.sc').textContent = scores ? scores[i].tot : 0;
        b.classList.toggle('view', i === v && st.n > 1);
        b.classList.toggle('act', i === a);
        b.setAttribute('aria-label', (p ? p.name : '') + ' ' + (scores ? scores[i].tot : 0) + '점 · 정원 보기');
      }
    }
    function onChip(i) {
      api.sfx('click');
      const auto = (() => { const m = manual; manual = null; const r = viewSeat(); manual = m; return r; })();
      if (manual === i || i === auto) manual = null; else manual = i;
      if (manual != null && st.n > 1 && manual !== auto) api.toast((api.players[i] ? api.players[i].name : '') + '의 정원');
      renderAll();
    }

    /* ---------- 카드 줄 ---------- */
    function smallCanvas(w, hh) { const c = document.createElement('canvas'); const d = Math.min(2.5, window.devicePixelRatio || 1); c.width = Math.round(w * d); c.height = Math.round(hh * d); c.style.width = w + 'px'; c.style.height = hh + 'px'; const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); return { c, x }; }
    function buildCards() {
      const key = st.cd.join(',');
      if (key === cardKey) return;
      cardKey = key; cardRow.innerHTML = ''; cardEls = [];
      const base = h('button', { class: 'gd-card base', onclick: () => openBase() });
      const bc = smallCanvas(24, 24); drawCreature(bc.x, 'n', 12, 12, 11);
      base.append(h('div', { class: 'r1' }, bc.c, h('span', { class: 'p' })), h('div', { class: 't', text: '동물·벤치' }));
      cardRow.append(base); cardEls.push(base);
      st.cd.forEach((id, k) => {
        const b = h('button', { class: 'gd-card', onclick: () => openCard(k) });
        const c = smallCanvas(24, 24); cardIcon(c.x, id, 24);
        b.append(h('div', { class: 'r1' }, c.c, h('span', { class: 'p' })), h('div', { class: 't', text: CARDS[id].nm }));
        cardRow.append(b); cardEls.push(b);
      });
    }
    function renderCards() {
      if (!st) return;
      buildCards();
      const v = viewSeat(), sc = scores && scores[v];
      if (!sc) return;
      const delta = opts && opts.after && v === opts.seat ? opts.after : null;
      cardEls[0].querySelector('.p').textContent = (sc.an + sc.be) + (delta && delta.an + delta.be !== sc.an + sc.be ? '→' + (delta.an + delta.be) : '');
      cardEls[0].setAttribute('aria-label', '동물·벤치 점수 ' + (sc.an + sc.be) + '점, 자세히 보기');
      st.cd.forEach((id, k) => {
        const el = cardEls[k + 1], now = sc.cd[k][0], nx = delta ? delta.cd[k][0] : now;
        el.querySelector('.p').textContent = now + (nx !== now ? '→' + nx : '');
        el.setAttribute('aria-label', CARDS[id].nm + ' ' + now + '점, 자세히 보기');
      });
    }

    /* ---------- 계절 줄 ---------- */
    function renderSeason() {
      if (!st) return;
      const q = seasonOf(st), se = seasonEnds(st.R), th = st.se[q];
      const left = st.done ? 0 : se[q] - st.rd;
      seasonBtn.innerHTML = '';
      const v = viewSeat(), cnt = countTheme(st.g[v], st.a[v], th);
      const tx = st.done ? '심사 끝 · 계절 보너스 ' + st.sb[v] + '점' :
        st.n === 1 ? THEME[th] + ' ' + soloNeed(st, q) + '개↑ +3 · 지금 ' + cnt :
          THEME[th] + ' 1등 +3 · 지금 ' + cnt;
      const dots = h('span', { class: 'dots' });
      for (let k = 0; k < 4; k++) dots.append(h('i', { class: k < st.sh.length ? 'past' : k === q && !st.done ? 'on' : '' }));
      seasonBtn.append(h('span', { class: 'sn', text: st.done ? '끝' : SEASON[q] }), h('span', { class: 'tx', text: tx }),
        h('span', { class: 'rd', text: st.done ? '' : left === 1 ? '마지막 바퀴' : left + '바퀴 남음' }), dots);
    }

    /* ---------- 시장 ---------- */
    function buildMarket() {
      if (pairEls.length) return;
      for (let i = 0; i < 4; i++) {
        const b = h('button', { class: 'gd-pair', onclick() { onPair(i); } });
        const c = document.createElement('canvas'); b.append(c);
        const bd = h('span', { class: 'bd', hidden: true }); b.append(bd);
        mkRow.append(b); pairEls.push(b); pairCv.push(c);
      }
    }
    let mkDrawn = [];
    function drawPair(i) {
      const c = pairCv[i], b = pairEls[i], pr = st.mk[i] || '';
      const r = b.getBoundingClientRect(), d = Math.min(2.5, window.devicePixelRatio || 1);
      const w = Math.max(10, Math.round(r.width - 4)), hh = Math.max(10, Math.round(r.height - 4));
      const key = pr + w + 'x' + hh;
      if (mkDrawn[i] === key) return;
      mkDrawn[i] = key;
      c.width = Math.round(w * d); c.height = Math.round(hh * d);
      const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, w, hh);
      if (!pr) return;
      const s = Math.min(hh - 8, w * 0.68);
      drawTile(x, pr[0], 4, (hh - s) / 2, s, 0, i * 7 + pr.charCodeAt(0));
      const cr = Math.min(hh * 0.3, w * 0.22);
      drawCreature(x, pr[1], w - cr - 4, hh - cr - 4, cr);
    }
    function renderMarket() {
      if (!st) return;
      buildMarket();
      const mine = myTurn() && !anim;
      for (let i = 0; i < 4; i++) {
        drawPair(i);
        const b = pairEls[i], pr = st.mk[i];
        b.classList.toggle('sel', sel.i === i);
        b.disabled = !mine;
        b.setAttribute('aria-label', pr ? TNAME[pr[0]] + ' + ' + CNAME[pr[1]] : '');
        b.title = pr ? TNAME[pr[0]] + ' + ' + CNAME[pr[1]] + ' (' + CNAME[pr[1]] + JOSA[pr[1]] + ' ' + HOMENAME[pr[1]] + '에 살아요)' : '';
      }
    }
    function onPair(i) {
      if (!myTurn() || anim) return;
      api.sfx('card'); api.buzz(8);
      acArm = 0;
      if (sel.i === i) { sel = { i: -1, at: -1, ca: -2 }; }
      else {
        const keepAt = sel.at >= 0 && st.g[actor(st)][sel.at] === '.' ? sel.at : -1;
        sel = { i, at: keepAt, ca: -2 };
        if (keepAt >= 0) autoCreature();
      }
      manual = null;
      computeOpts(); renderAll();
    }
    function autoCreature() {   // 살 곳이 없으면 자동으로 풀어 주기
      computeOpts();
      if (opts && sel.at >= 0 && opts.homes.length === 0) sel.ca = -1;
    }

    /* ---------- 아래 버튼 ---------- */
    function renderAct() {
      if (!st) return;
      const mine = myTurn() && !anim;
      const a = actor(st);
      const seat = a != null && api.canAct(a) ? a : (api.mySeats()[0] != null ? api.mySeats()[0] : -1);
      const acN = seat >= 0 ? st.ac[seat] : 0;
      acBtn.textContent = acArm ? '한 번 더!' : '🌰 ' + acN;
      acBtn.disabled = !mine || acN <= 0;
      acBtn.classList.toggle('primary', !!acArm);
      unBtn.disabled = !mine || sel.i < 0;
      const ready = mine && sel.i >= 0 && sel.at >= 0;
      okBtn.disabled = !ready;
      okBtn.classList.toggle('soft', ready && sel.ca === -2);
      if (ready && opts) {
        okBtn.textContent = sel.ca === -2 ? '동물 없이 확정' : '확정 ' + (opts.delta >= 0 ? '+' : '') + opts.delta + '점';
      } else okBtn.textContent = '확정';
      const showAct = api.mySeats().length > 0;
      actRow.style.display = showAct ? '' : 'none';
    }
    acBtn.onclick = () => {
      if (!myTurn() || anim) return;
      if (!acArm) { acArm = 1; api.sfx('click'); clearTimeout(acT); acT = setTimeout(() => { acArm = 0; renderAct(); }, 2500); renderAct(); api.toast('도토리 1개(1점)로 시장의 동물 4마리를 새로 불러와요'); return; }
      acArm = 0; clearTimeout(acT);
      sel = { i: -1, at: -1, ca: -2 };
      send({ t: 'acorn' });
    };
    unBtn.onclick = () => {
      if (!myTurn() || anim) return;
      api.sfx('click');
      if (sel.ca !== -2 && opts && opts.homes && opts.homes.length) sel.ca = -2;
      else if (sel.at >= 0) { sel.at = -1; sel.ca = -2; }
      else sel = { i: -1, at: -1, ca: -2 };
      computeOpts(); renderAll();
    };
    okBtn.onclick = () => {
      if (!myTurn() || anim || sel.i < 0 || sel.at < 0) return;
      api.buzz(15); api.sfx('pop');
      send({ t: 'take', i: sel.i, at: sel.at, ca: sel.ca >= 0 ? sel.ca : -1 });
    };
    function send(a) {
      pending = true; clearTimeout(pendT);
      pendT = setTimeout(() => { pending = false; renderAll(); }, 4000);
      renderAll();
      api.act(a);
    }
    backBtn.onclick = () => { manual = null; api.sfx('click'); renderAll(); };

    /* ---------- 힌트 ---------- */
    function lastText(l) {
      if (!l) return '';
      const nm = api.players[l.seat] ? api.players[l.seat].name : st.nm[l.seat];
      if (l.k === 'ac') return nm + ': 🌰 도토리로 동물 새로 부름';
      return nm + ': ' + TNAME[l.t] + (l.ca >= 0 ? ' + ' + CNAME[l.c] : ' (' + CNAME[l.c] + ' 풀어 줌)') + ' → ' + (l.d >= 0 ? '+' : '') + l.d + '점';
    }
    function renderHint() {
      if (!st) return;
      let t = '', me = false;
      const a = actor(st);
      if (st.done) t = '정원이 다 찼어요! 점수를 세어 볼까요?';
      if (!st.done) {
        if (myTurn() && !anim) {
          me = true;
          const v = viewSeat();
          if (v !== a) t = '다른 정원을 보는 중 · 「← 내 정원」';
          else if (sel.i < 0) t = (st.n > 1 && api.mySeats().length > 1 ? api.players[a].name + ' 차례 · ' : '') + '시장에서 타일+동물 짝을 고르세요';
          else {
            const pr = st.mk[sel.i];
            if (sel.at < 0) t = TNAME[pr[0]] + TJ[pr[0]] + ' 놓을 빈 칸을 톡 (숫자 = 얻는 점수)';
            else if (sel.ca === -2) t = CNAME[pr[1]] + JOSA[pr[1]] + ' ' + HOMENAME[pr[1]] + '에 살아요 · 빛나는 칸을 톡';
            else if (sel.ca === -1) t = (opts && opts.homes.length ? CNAME[pr[1]] + ' 풀어 줌' : CNAME[pr[1]] + CJ[pr[1]] + ' 살 곳이 없어 풀어 줘요') + ' · 확정하세요';
            else if (opts) t = '확정하면 ' + (opts.delta >= 0 ? '+' : '') + opts.delta + '점 (동물·벤치 ' + (opts.dAn >= 0 ? '+' : '') + opts.dAn + ' · 의뢰 ' + (opts.dCd >= 0 ? '+' : '') + opts.dCd + ')';
          }
        } else if (pending) t = '보내는 중…';
        else {
          const nm = a != null && api.players[a] ? api.players[a].name : '';
          const lt = lastText(st.last);
          t = (lt ? lt + ' · ' : '') + (api.players[a] && api.players[a].ai ? nm + ' 생각 중…' : nm + ' 차례');
        }
      }
      hint.textContent = t;
      hint.classList.toggle('me', me);
    }

    /* ---------- 정원 그리기 ---------- */
    function layout() {
      if (!st) return;
      const S = st.S, W = cv.w, H = cv.h;
      const side = Math.max(60, Math.min(W - 4, H - 4));
      const fw = Math.max(7, side * 0.035);
      const cs = (side - 2 * fw) / S;
      geo = { x0: (W - side) / 2, y0: (H - side) / 2, side, fw, cs, ox: (W - side) / 2 + fw, oy: (H - side) / 2 + fw, S };
    }
    cv.onresize = () => { layout(); mkDrawn = []; draw(); renderMarket(); };
    function cellAt(p) {
      if (!geo) return -1;
      const x = Math.floor((p.x - geo.ox) / geo.cs), y = Math.floor((p.y - geo.oy) / geo.cs);
      if (x < 0 || y < 0 || x >= geo.S || y >= geo.S) return -1;
      return y * geo.S + x;
    }
    function maskOf(g, i, S) {
      const t = g[i]; if (t !== 'p' && t !== 'w') return 0;
      const x = i % S, y = (i / S) | 0; let m = 0;
      if (y > 0 && g[i - S] === t) m |= 1; if (x < S - 1 && g[i + 1] === t) m |= 2; if (y < S - 1 && g[i + S] === t) m |= 4; if (x > 0 && g[i - 1] === t) m |= 8;
      return m;
    }
    function badge(x, y, txt, strong) {
      ctx.font = '700 ' + Math.max(11, Math.round(geo.cs * 0.2)) + 'px ' + MONO;
      const w = ctx.measureText(txt).width + 10, hh = Math.max(16, geo.cs * 0.26);
      ctx.fillStyle = strong ? '#e3ae45' : 'rgba(23,19,31,.82)';
      rr(ctx, x - w / 2, y - hh / 2, w, hh, hh / 2); ctx.fill();
      ctx.fillStyle = strong ? '#2a1d05' : '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, x, y + 1);
    }
    function draw(now) {
      cv.clear();
      if (!st || !geo) return;
      const S = st.S, seat = viewSeat(), cs = geo.cs, pad = Math.max(1.5, cs * 0.035);
      const g = st.g[seat].split(''), an = st.a[seat].split('');
      const prevMode = opts && seat === opts.seat && sel.i >= 0 && myTurn();
      const pr = prevMode ? st.mk[sel.i] : null;
      if (prevMode && sel.at >= 0) { g[sel.at] = pr[0]; if (sel.ca >= 0) an[sel.ca] = pr[1]; }
      // 나무 틀(화단)
      const { x0, y0, side, fw } = geo;
      ctx.fillStyle = 'rgba(0,0,0,.4)'; rr(ctx, x0 + 3, y0 + 6, side, side, fw * 1.4); ctx.fill();
      const wood = ctx.createLinearGradient(x0, y0, x0, y0 + side);
      wood.addColorStop(0, '#a8774a'); wood.addColorStop(1, '#6e4a2b');
      ctx.fillStyle = wood; rr(ctx, x0, y0, side, side, fw * 1.4); ctx.fill();
      ctx.fillStyle = '#4a3020'; rr(ctx, geo.ox - 2, geo.oy - 2, cs * S + 4, cs * S + 4, fw * 0.6); ctx.fill();
      ctx.strokeStyle = 'rgba(255,220,170,.18)'; ctx.lineWidth = 1;
      for (let k = 1; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x0 + fw * 0.3, y0 + fw * k / 4); ctx.lineTo(x0 + side - fw * 0.3, y0 + fw * k / 4); ctx.stroke(); }
      const A = anim && anim.seat === seat ? anim : null;
      const at = A ? Math.min(1, (now - A.t0) / A.dur) : 1;
      for (let i = 0; i < S * S; i++) {
        const x = geo.ox + (i % S) * cs + pad, y = geo.oy + ((i / S) | 0) * cs + pad, s = cs - pad * 2;
        if (g[i] === '.') {
          ctx.fillStyle = '#5b3f2a'; rr(ctx, x, y, s, s, s * 0.12); ctx.fill();
          ctx.fillStyle = 'rgba(30,18,10,.35)';
          for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(x + s * (0.15 + 0.7 * fr(i * 13 + k)), y + s * (0.15 + 0.7 * fr(i * 7 + k * 5)), s * 0.03, 0, 7); ctx.fill(); }
          continue;
        }
        const isPrev = prevMode && i === sel.at;
        if (A && i === A.at && at < 1) {
          const e = Math.min(1, at / 0.55), sc = 1.35 - 0.35 * (1 - Math.pow(1 - e, 3));
          ctx.save(); ctx.globalAlpha = Math.min(1, e * 1.6);
          ctx.translate(x + s / 2, y + s / 2); ctx.scale(sc, sc); ctx.translate(-(x + s / 2), -(y + s / 2));
          drawTile(ctx, g[i], x, y, s, maskOf(g, i, S), i * 3 + 1, pad);
          ctx.restore();
        } else {
          if (isPrev) { ctx.save(); ctx.globalAlpha = 0.88; }
          drawTile(ctx, g[i], x, y, s, maskOf(g, i, S), i * 3 + 1, pad);
          if (isPrev) {
            ctx.restore();
            ctx.setLineDash([6, 4]); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; rr(ctx, x + 1.5, y + 1.5, s - 3, s - 3, s * 0.12); ctx.stroke(); ctx.setLineDash([]);
          }
        }
      }
      // 동물
      for (let i = 0; i < S * S; i++) {
        if (an[i] === '.') continue;
        const x = geo.ox + (i % S) * cs, y = geo.oy + ((i / S) | 0) * cs;
        let dy = 0, al = 1;
        if (A && i === A.ca && at < 1) { const e = U.clamp((at - 0.35) / 0.65, 0, 1); al = e > 0 ? 1 : 0; dy = -Math.sin(e * Math.PI) * cs * 0.25 - (1 - e) * cs * 0.1; }
        if (!al) continue;
        drawCreature(ctx, an[i], x + cs * 0.7, y + cs * 0.3 + dy, cs * 0.22);
        if (prevMode && i === sel.ca) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x + cs * 0.7, y + cs * 0.3, cs * 0.26, 0, 7); ctx.stroke(); }
      }
      // 미리보기 표시
      if (prevMode && opts) {
        if (sel.at < 0) {
          for (let i = 0; i < S * S; i++) {
            if (g[i] !== '.') continue;
            const x = geo.ox + (i % S) * cs, y = geo.oy + ((i / S) | 0) * cs;
            ctx.strokeStyle = i === hover ? '#e3ae45' : 'rgba(227,174,69,.5)'; ctx.lineWidth = i === hover ? 3 : 2;
            rr(ctx, x + pad + 3, y + pad + 3, cs - pad * 2 - 6, cs - pad * 2 - 6, cs * 0.1); ctx.stroke();
            if (opts.cell[i] != null) badge(x + cs / 2, y + cs / 2, '+' + opts.cell[i], false);
          }
        } else if (sel.ca === -2 || sel.ca >= 0) {
          for (const k of opts.homes) {
            if (k === sel.ca) continue;
            const x = geo.ox + (k % S) * cs, y = geo.oy + ((k / S) | 0) * cs;
            ctx.fillStyle = 'rgba(255,240,180,.22)'; rr(ctx, x + pad, y + pad, cs - pad * 2, cs - pad * 2, cs * 0.12); ctx.fill();
            ctx.strokeStyle = k === hover ? '#fff4c8' : '#e3ae45'; ctx.lineWidth = 2.5;
            rr(ctx, x + pad + 2, y + pad + 2, cs - pad * 2 - 4, cs - pad * 2 - 4, cs * 0.1); ctx.stroke();
            ctx.globalAlpha = 0.55; drawCreature(ctx, pr[1], x + cs * 0.7, y + cs * 0.3, cs * 0.2); ctx.globalAlpha = 1;
            badge(x + cs / 2, y + cs * 0.72, '+' + (opts.home[k] - (opts.rel || 0)), sel.ca === -2);
          }
        }
      }
      // 점수 떠오르기
      if (A && at < 1 && A.d != null) {
        const i = A.at, x = geo.ox + (i % S) * cs + cs / 2, y = geo.oy + ((i / S) | 0) * cs + cs * 0.3 - at * cs * 0.5;
        ctx.globalAlpha = Math.min(1, (1 - at) * 3);
        badge(x, y, (A.d >= 0 ? '+' : '') + A.d + '점', true);
        ctx.globalAlpha = 1;
      }
      // 다른 사람 정원 이름표
      if (st.n > 1) {
        const p = api.players[seat];
        ctx.font = '700 12px ' + FONT; ctx.textAlign = 'right'; ctx.textBaseline = 'top';
        const label = (p ? p.name : st.nm[seat]) + '의 정원';
        const w = ctx.measureText(label).width + 14;
        ctx.fillStyle = 'rgba(23,19,31,.78)'; rr(ctx, x0 + side - w - 2, Math.max(0, y0 - 1), w, 20, 8); ctx.fill();
        ctx.fillStyle = p ? p.color : '#f2e9d8'; ctx.fillText(label, x0 + side - 9, Math.max(0, y0 - 1) + 4);
      }
      backBtn.hidden = !(myTurn() && seat !== actor(st));
    }

    /* ---------- 정원 탭 ---------- */
    function onTap(ev) {
      if (!st || anim) return;
      const p = cv.local(ev), i = cellAt(p);
      if (i < 0) return;
      if (!myTurn()) return;
      const seat = actor(st);
      if (viewSeat() !== seat) return;
      if (sel.i < 0) { api.toast('먼저 아래 시장에서 짝을 고르세요'); api.buzz(20); return; }
      const g = st.g[seat];
      if (g[i] === '.' && i !== sel.at) {           // 타일 놓기(옮기기)
        sel.at = i; sel.ca = -2; api.sfx('tick'); api.buzz(8);
        autoCreature();
        if (sel.ca === -1) api.toast(CNAME[st.mk[sel.i][1]] + CJ[st.mk[sel.i][1]] + ' 살 곳이 없어요 — 풀어 줘요');
      } else if (sel.at >= 0 && opts && opts.homes.indexOf(i) >= 0) {   // 동물 놓기
        sel.ca = sel.ca === i ? -2 : i; api.sfx('pop'); api.buzz(8);
      } else if (sel.at >= 0 && i === sel.at) {
        // 놓은 타일을 다시 톡: 집이 아니면 무시
        api.buzz(15);
      } else { api.buzz(20); }
      computeOpts(); renderAll();
    }
    cv.cv.addEventListener('click', onTap);
    function onMove(ev) {
      if (!st || !myTurn() || sel.i < 0) { if (hover !== -1) { hover = -1; draw(performance.now()); } return; }
      const i = cellAt(cv.local(ev));
      if (i !== hover) { hover = i; draw(performance.now()); }
    }
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerleave', () => { if (hover !== -1) { hover = -1; draw(performance.now()); } });

    /* ---------- 팝업 ---------- */
    let ov = null;
    function closeOv() { if (ov) { ov.remove(); ov = null; } }
    function popup(title, body) {
      closeOv();
      const sheet = h('div', { class: 'sheet' },
        h('div', { class: 'row2', style: { justifyContent: 'space-between' } }, h('h3', { text: title }),
          h('button', { class: 'btn sm', text: '닫기', onclick: closeOv })), body);
      ov = h('div', { class: 'overlay gd-ov', onclick(e) { if (e.target === ov) closeOv(); } }, sheet);
      root.append(ov);
      api.sfx('click');
    }
    function openCard(k) {
      const id = st.cd[k], cd = CARDS[id];
      const ic = smallCanvas(56, 56); cardIcon(ic.x, id, 56);
      const tb = h('table');
      for (let i = 0; i < st.n; i++) {
        const r = scores[i].cd[k];
        tb.append(h('tr', null, h('td', null, h('span', { class: 'dot', style: { '--c': api.players[i] ? api.players[i].color : '#888', marginRight: '6px' } }), api.players[i] ? api.players[i].name : st.nm[i]),
          h('td', { style: { color: 'var(--muted)' }, text: r[1] + cd.u }), h('td', { class: 'n', text: r[0] + '점' })));
      }
      popup(cd.nm, h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } },
        h('div', { class: 'row2' }, ic.c, h('p', { style: { fontWeight: 700 }, text: cd.d })),
        h('p', { class: 'muted', text: '예시: ' + cd.ex }), tb));
    }
    function openBase() {
      const list = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
      CK.split('').forEach((c) => {
        const ic = smallCanvas(34, 34); drawCreature(ic.x, c, 17, 17, 15);
        list.append(h('div', { class: 'row2' }, ic.c, h('p', null, h('b', { text: CNAME[c] }), ' · 집 ' + HOMENAME[c] + ' · 좋아함 ' + LIKENAME[c])));
      });
      const bc = smallCanvas(34, 34); drawTile(bc.x, 'k', 0, 0, 34, 0, 1);
      list.append(h('div', { class: 'row2' }, bc.c, h('p', null, h('b', { text: '벤치' }), ' · 상하좌우에 사는 동물 1마리마다 +1점')));
      const tb = h('table');
      for (let i = 0; i < st.n; i++) {
        tb.append(h('tr', null, h('td', null, h('span', { class: 'dot', style: { '--c': api.players[i] ? api.players[i].color : '#888', marginRight: '6px' } }), api.players[i] ? api.players[i].name : st.nm[i]),
          h('td', { style: { color: 'var(--muted)' }, text: '동물 ' + scores[i].an + ' · 벤치 ' + scores[i].be }), h('td', { class: 'n', text: (scores[i].an + scores[i].be) + '점' })));
      }
      popup('동물·벤치 점수', h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } },
        h('p', { style: { fontWeight: 700 }, text: '동물 1마리 = 1점 + 상하좌우의 「좋아함」 칸 1개마다 +1점 (최대 5점)' }),
        list, h('p', { class: 'muted', text: '동물은 자기 집 칸에만, 한 칸에 1마리. 살 곳이 없으면 풀어 줘요(0점). 남은 도토리는 1개당 1점.' }), tb));
    }
    function openSeason() {
      const se = seasonEnds(st.R), q = seasonOf(st);
      const tb = h('table');
      for (let k = 0; k < 4; k++) {
        const th = st.se[k], bon = st.sh[k];
        const who = bon ? bon.map((b, i) => (b ? (api.players[i] ? api.players[i].name : st.nm[i]) + ' +' + b : '')).filter(Boolean).join(', ') || '없음' :
          (k === q && !st.done ? '진행 중' : '');
        tb.append(h('tr', null, h('td', { style: { fontWeight: 700, color: k === q && !st.done ? 'var(--brass)' : '' }, text: SEASON[k] }),
          h('td', { text: THEME[th] + (st.n === 1 ? ' ' + soloNeed(st, k) + '개↑' : ' 최다') }),
          h('td', { style: { color: 'var(--muted)' }, text: se[k] + '바퀴 끝' }), h('td', { class: 'w', text: who })));
      }
      const cur = st.se[q], cnts = h('table');
      if (!st.done) for (let i = 0; i < st.n; i++) cnts.append(h('tr', null, h('td', null, api.players[i] ? api.players[i].name : st.nm[i]), h('td', { class: 'n', text: THEME[cur] + ' ' + countTheme(st.g[i], st.a[i], cur) })));
      popup('계절 심사', h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } },
        h('p', { text: st.n === 1 ? '계절이 끝날 때 그 계절의 것이 목표 개수 이상이면 +3점.' :
          '계절이 끝날 때(표시된 바퀴가 끝나면) 그 계절의 것이 가장 많은 정원이 +3점' + (st.n >= 3 ? ', 두 번째로 많은 정원이 +1점' : '') + '. 같으면 모두 받아요.' }),
        h('p', { class: 'muted', text: '「동물」은 정원에 사는 동물 수, 「꽃」은 색 상관없이 꽃 칸 수예요.' }), tb,
        st.done ? null : h('p', { style: { fontWeight: 700 }, text: '지금 ' + SEASON[q] + ' 심사 현황' }), st.done ? null : cnts));
    }
    seasonBtn.onclick = openSeason;

    /* ---------- 애니메이션 ---------- */
    function startAnim(l) {
      const seat = viewSeat();
      if (l.seat !== seat) {   // 다른 정원: 칩 반짝
        const el = plRow.children[l.seat];
        if (el) { el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
        return;
      }
      anim = { seat: l.seat, at: l.at, ca: l.ca, d: l.d, t0: performance.now(), dur: 750 / L.debug.speed };
      api.setBusy(true);
      if (stopLoop) stopLoop();
      clearTimeout(watchdog);
      watchdog = setTimeout(endAnim, anim.dur + 1500);
      stopLoop = U.loop((dt, now) => { if (!anim) return; if (now - anim.t0 >= anim.dur) endAnim(); else draw(now); });
    }
    function endAnim() {
      if (stopLoop) { stopLoop(); stopLoop = null; }
      clearTimeout(watchdog);
      const was = !!anim; anim = null;
      draw(performance.now()); renderAll();
      if (was) api.setBusy(false);
    }

    function renderAll() {
      if (!st) return;
      renderChips(); renderCards(); renderSeason(); renderMarket(); renderAct(); renderHint();
      if (!anim) draw(performance.now());
    }

    return {
      update(next, prev) {
        const key = next.gid + ':' + next.S;
        const fresh = key !== gameKey;
        if (fresh) { gameKey = key; sel = { i: -1, at: -1, ca: -2 }; manual = null; shownId = -1; cardKey = ''; mkDrawn = []; plRow.innerHTML = ''; followSeat = 0; }
        const old = st;
        st = next;
        pending = false; clearTimeout(pendT);
        scores = totals(st);
        const l = st.last;
        const isNew = l && l.id !== shownId;
        if (isNew) {
          sel = { i: -1, at: -1, ca: -2 }; acArm = 0;
          if (l.k === 'tk') followSeat = l.seat;
        }
        // 차례가 나에게 오면 내 정원으로
        const a = actor(st);
        if (a != null && api.canAct(a) && (!old || actor(old) !== a)) manual = null;
        if (!geo || fresh) layout();
        computeOpts();
        if (isNew && prev && old && !fresh) {
          shownId = l.id;
          if (l.k === 'tk') {
            api.sfx(l.ca >= 0 ? 'pop' : 'card');
            // 시장: 새로 들어온 짝(맨 오른쪽) 반짝
            const b = pairEls[3]; if (b) { b.classList.remove('new'); void b.offsetWidth; b.classList.add('new'); }
            for (let k = l.i; k < 4; k++) mkDrawn[k] = null;
            if (l.ss != null) {
              const th = THEME[st.se[l.ss]], who = l.sbn.map((b, i) => (b ? (api.players[i] ? api.players[i].name : st.nm[i]) + ' +' + b : '')).filter(Boolean);
              api.toast(SEASON[l.ss] + ' 심사(' + th + ') · ' + (who.length ? who.join(', ') : '받은 사람 없음'));
              if (l.sbn.some((b, i) => b && api.canAct(i))) { api.sfx('win'); api.buzz(25); }
            }
            renderAll();
            startAnim(l);
          } else if (l.k === 'ac') {
            api.sfx('whoosh'); mkDrawn = [];
            pairEls.forEach((b) => { b.classList.remove('new'); void b.offsetWidth; b.classList.add('new'); });
            renderAll();
          }
        } else {
          if (l) shownId = l.id;
          if (anim && stopLoop) { /* 애니 중 재그리기 요청 */ }
          renderAll();
        }
      },
      destroy() {
        if (stopLoop) stopLoop();
        clearTimeout(watchdog); clearTimeout(pendT); clearTimeout(acT);
        if (anim) { anim = null; api.setBusy(false); }
        closeOv();
        cv.destroy(); wrap.remove(); styleEl.remove();
      },
    };
  }

  const DEF = {
    id: 'garden', name: '정원 가꾸기', tag: '타일 퍼즐', cat: '보드',
    blurb: '시장에서 타일+동물 짝을 골라 내 정원에 놓아요. 동물이 좋아하는 이웃을 만들고 의뢰 카드를 채워 가장 예쁜 정원을 만드세요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false,
    tint: '#2f5a2a',
    icon: '<rect x="6" y="6" width="44" height="44" rx="7" fill="none" stroke="currentColor" stroke-width="3"/><path d="M28 6V50M6 28H50" stroke="currentColor" stroke-width="2" opacity=".45"/><circle cx="13" cy="13" r="3.6" fill="currentColor"/><circle cx="21" cy="13" r="3.6" fill="currentColor"/><circle cx="13" cy="21" r="3.6" fill="currentColor"/><circle cx="21" cy="21" r="3.6" fill="currentColor"/><circle cx="17" cy="17" r="2.4" fill="currentColor" opacity=".5"/><circle cx="39" cy="39" r="8" fill="currentColor" opacity=".75"/><ellipse cx="39" cy="17" rx="8" ry="5.5" fill="currentColor" opacity=".45"/><path d="M11 41H24M11 37H24" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>',
    options: [
      { id: 'size', label: '정원 크기', def: '4', choices: [{ v: '4', label: '4×4 (16바퀴)' }, { v: '5', label: '5×5 (25바퀴)' }] },
    ],
    quick: [
      '내 정원(4×4)을 타일로 채우고 동물을 들여 점수를 가장 많이 모으면 이겨요.',
      '내 차례: 시장의 「타일 + 동물」 짝 하나 고르기 → 타일을 빈 칸에 → 동물을 사는 곳(집)에 → 확정.',
      '정원이 다 차면 끝. 동물·벤치 + 의뢰 카드 3장 + 계절 심사 + 남은 도토리를 더해요.',
    ],
    rules: [
      { h: '목표', p: ['모두 자기 정원(4×4, 옵션 5×5)을 가꿔요. 칸이 다 차면 게임 끝.', '점수가 가장 높은 사람이 이겨요. 같으면 함께 우승. 혼자 하면 점수로 별 1~3개!'] },
      { h: '차례에 할 일', p: [
        '① 아래 시장의 짝 4개(타일 1장 + 동물 1마리) 중 하나를 골라요.',
        '② 타일을 내 정원의 빈 칸 아무 데나 놓아요. 칸마다 그 자리에 놓으면 얻는 점수(+숫자)가 보여요.',
        '③ 동물은 자기 집 칸(빛나는 칸)에 놓아요. 방금 놓은 타일이 아니어도 돼요. 한 칸에 1마리만.',
        '   살 곳이 없거나 놓기 싫으면 풀어 줘요(0점). 「동물 없이 확정」을 누르면 돼요.',
        '④ 「확정」! 고른 짝은 빠지고 나머지는 왼쪽으로 밀려요. 오른쪽 끝에 새 짝이 들어와요.'] },
      { h: '타일', p: ['꽃(빨강·노랑·파랑 — 꽃 모양도 달라요), 연못, 나무, 오솔길, 벤치. 연못·오솔길은 붙이면 이어져 보여요.', '「무리」 = 상하좌우로 이어진 같은 타일(꽃은 같은 색끼리).'] },
      { h: '동물 (늘 점수)', p: [
        '동물 1마리 = 1점 + 상하좌우의 「좋아함」 칸 1개마다 +1점 (최대 5점).',
        '나비: 꽃에 살고, 자기와 다른 색 꽃을 좋아해요.',
        '벌: 꽃에 살고, 자기와 같은 색 꽃을 좋아해요.',
        '새: 나무에 살고, 나무를 좋아해요.',
        '고슴도치: 오솔길에 살고, 나무·벤치를 좋아해요.',
        '개구리: 연못에 살고, 연못을 좋아해요.',
        '벤치: 상하좌우에 사는 동물 1마리마다 +1점.'] },
      { h: '의뢰 카드 3장 (판마다 바뀜)', p: ['14가지 중 3장이 뽑혀요. 위쪽 카드에 지금 내 점수가 보이고, 짝을 놓아 보면 「4→8」처럼 바뀔 점수가 보여요.', '카드를 누르면 자세한 설명·예시와 모두의 점수가 나와요.'] },
      { h: '계절 심사', p: ['판은 봄·여름·가을·겨울로 나뉘어요(4×4는 4바퀴씩). 계절마다 심사할 것(꽃·연못·나무·오솔길·벤치·동물 중 하나)이 정해져 있어요.',
        '그 계절의 마지막 바퀴가 끝나면, 그것이 가장 많은 정원 +3점(3명 이상이면 두 번째 +1점). 같으면 모두 받아요.',
        '혼자 할 때는 목표 개수 이상이면 +3점.'] },
      { h: '시장 새로 고침 — 도토리', p: ['모두 도토리 2개로 시작해요. 내 차례에 🌰를 두 번 누르면 시장의 동물 4마리를 새로 불러와요(타일은 그대로).', '쓰지 않은 도토리는 끝날 때 1개당 1점이에요.'] },
      { h: '조작', p: ['짝 고르기 → 정원 칸 톡(타일) → 빛나는 칸 톡(동물) → 「확정」.', '「되돌리기」는 한 단계씩 취소해요. 타일을 다른 빈 칸에 톡하면 옮겨져요.', '위쪽 이름 칸을 누르면 그 사람 정원을 볼 수 있어요. 계절 줄을 누르면 심사 현황이 나와요.'] },
      { h: '예시', p: [
        '시장에서 「연못 + 개구리」를 골랐어요. 이미 연못 1칸이 있으니 바로 옆 빈 칸에 연못을 놓아요.',
        '개구리를 새 연못에 놓으면 1점 + 옆 연못 1칸 = 2점! 의뢰 「개구리 연못」이 있으면 연못 2칸 무리 + 개구리로 +4점 더.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.', '쉬움: 자주 대충 놓아요. 보통: 지금 가장 점수가 큰 곳에 놓아요. 어려움: 의뢰 카드 진행·빈 칸의 앞날·계절 경쟁까지 보고, 도토리도 써요.'] },
    ],
    tutorial: [
      { sel: '.gd-mk', text: '시장에는 「타일 + 동물」 짝이 4개 있어요. 내 차례엔 이 중 하나를 골라요. 고른 짝은 빠지고 오른쪽에 새 짝이 들어와요.' },
      { sel: '.gd-board', text: '이게 내 정원이에요. 짝을 고르면 빈 칸마다 「+점수」가 보여요. 원하는 빈 칸을 톡하면 타일이 놓여요(다른 칸을 톡하면 옮겨져요).' },
      { sel: '.gd-board', text: '그다음 동물을 빛나는 칸(동물의 집)에 톡! 나비·벌=꽃, 새=나무, 고슴도치=오솔길, 개구리=연못. 살 곳이 없으면 풀어 줘요.' },
      { sel: '.gd-cards', text: '맨 왼쪽은 늘 있는 동물·벤치 점수, 나머지 3장은 이번 판의 의뢰 카드예요. 숫자 = 지금 내 점수. 누르면 자세히 보여요.' },
      { sel: '.gd-season', text: '계절이 끝날 때마다 심사! 여기 적힌 것이 가장 많은 정원이 +3점을 받아요.' },
      { sel: '.gd-act', text: '「되돌리기」로 다시 고르고, 「확정」하면 끝. 🌰 도토리(2개)로 시장 동물을 새로 부를 수 있어요. 남은 도토리는 1점씩!' },
    ],
    aiDelay: 750,
    init, actor, apply, ai, aiDelayFor, result, mount,
  };
  DEF._t = { CFG, scoreAll, totals, CARDS, seasonEnds, countTheme, homesFor, allMoves };   // 테스트용
  L.register(DEF);
})();
