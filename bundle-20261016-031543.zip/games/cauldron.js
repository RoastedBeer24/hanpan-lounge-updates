/* 마녀 솥 재료 뽑기 — 동시 진행 욕심 게임 + 주머니 키우기 */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- 재료 ---------- */
  // 코드 한 글자 = 재료 1개. a/b/c 폭발 열매(1·2·3), x/y/z 솥 안에서 등딱지에 막힌 열매.
  const ING = {
    a: { n: '폭발 열매', e: '💥', v: 1, col: '#b8322a' },
    b: { n: '폭발 열매', e: '💥', v: 2, col: '#a3241f' },
    c: { n: '폭발 열매', e: '💥', v: 3, col: '#861816' },
    d: { n: '달빛 이끼', e: '🌿', p: 3, col: '#4f8a4b', t: '거품 1. 특별한 효과는 없어요.' },
    e: { n: '큰 이끼 덩이', e: '🥬', p: 7, col: '#2f7a3c', t: '한 번에 거품 3!' },
    f: { n: '얼음 수정', e: '❄️', p: 6, col: '#4c93c4', t: '거품 1, 압력 −1 (솥을 식혀요).' },
    g: { n: '쌍둥이 땅콩', e: '🥜', p: 4, col: '#b8843c', t: '거품 1. 솥에 땅콩이 이미 있으면 +2 더.' },
    h: { n: '메아리 조개', e: '🐚', p: 5, col: '#c9809a', t: '거품 1 + 바로 앞 재료가 낸 거품만큼 더.' },
    i: { n: '거북 등딱지', e: '🐢', p: 8, col: '#3f8f7a', t: '거품 1. 다음 폭발 열매 1개의 압력을 막아요.' },
    j: { n: '꼬리별 가루', e: '✨', p: 5, col: '#c9a43a', t: '거품 1. 주머니에서 열매 아닌 재료 1개를 바로 더 넣어요.' },
    k: { n: '부엉이 깃털', e: '🦉', p: 4, col: '#8a6a4a', t: '거품 1. 다음에 나올 재료 2개를 미리 보여 줘요.' },
    l: { n: '황금 꿀', e: '🍯', p: 5, col: '#d99a1e', t: '거품 1. 안 터지면 판 끝에 금화 +4.' },
    n: { n: '별사탕', e: '🍬', p: 8, col: '#c4569b', t: '거품 1. 안 터지면 판 끝에 ★ +1.' },
    o: { n: '용 비늘', e: '🐉', p: 8, col: '#3e9a5c', t: '거품 1. 이번 판 압력 한도 +1.' },
    p: { n: '번개 버섯', e: '🍄', p: 7, col: '#a94a3a', t: '거품 1 + 솥 속 폭발 열매 수만큼(최대 +4).' },
    q: { n: '마무리 꽃잎', e: '🌸', p: 4, col: '#d77fae', t: '거품 1. 멈출 때 맨 위에 있으면 거품 +5.' },
    r: { n: '바꿔치기 두꺼비', e: '🐸', p: 8, col: '#5d9a37', t: '거품 1. 솥 속 가장 큰 폭발 열매를 주머니로 돌려보내요(압력↓, 거품은 그대로).' },
    T: { n: '열매 솎아내기', e: '✂️', p: 6, col: '#6d5a7a', t: '주머니의 폭발 열매(1) 하나를 버려요.' },
    U: { n: '솥 뚜껑 강화', e: '🔩', p: 12, col: '#6f6f7f', t: '압력 한도가 영원히 +1 (최대 2번).' },
  };
  const SHOPK = 'efghijklnopqr';           // 장날마다 이 중 6가지가 나옴 (이끼 d·솎아내기·강화는 늘)
  const START = 'aaaaabbcdddef';            // 시작 주머니
  const LIM0 = 8, TR = 48, MAXBUY = 3, SAVE = 5, UPMAX = 2;
  const SHIELDED = { a: 'x', b: 'y', c: 'z' }, UNSH = { x: 'a', y: 'b', z: 'c' };
  const isFruit = (t) => t === 'a' || t === 'b' || t === 'c' || t === 'x' || t === 'y' || t === 'z';
  const fv = (t) => ({ a: 1, b: 2, c: 3, x: 1, y: 2, z: 3 })[t] || 0;
  const base = (t) => (UNSH[t] || t);
  const PT = (L) => Math.floor(L / 3);
  const CO = (L) => 2 + Math.floor(L / 2);
  const STARS = { 7: [42, 53, 62], 9: [55, 68, 80], 11: [68, 84, 98] };

  function lim(s, i) { return LIM0 + s.up[i] + s.xl[i]; }
  function remaining(s, i) {
    const cnt = {};
    for (const t of s.own[i]) cnt[t] = (cnt[t] || 0) + 1;
    for (const t of s.pot[i]) cnt[base(t)]--;
    for (const t of s.pk[i]) cnt[t]--;
    let r = '';
    for (const k in cnt) if (cnt[k] > 0) r += k.repeat(cnt[k]);
    return r;
  }
  function riskOf(s, i, ignorePeek) {
    if (s.st[i] !== 0 || s.sh[i] > 0) return 0;
    const room = lim(s, i) - s.pr[i];
    if (!ignorePeek && s.pk[i].length) { const t = s.pk[i][0]; return isFruit(t) && fv(t) > room ? 1 : 0; }
    let R = remaining(s, i); if (ignorePeek) R += s.pk[i];
    if (!R.length) return 0;
    let bad = 0;
    for (const t of R) if (isFruit(t) && fv(t) > room) bad++;
    return bad / R.length;
  }

  /* ---------- 초기화 ---------- */
  function init(players, opts) {
    const n = players.length, R = +((opts && opts.rounds) || 9);
    const s = {
      n, R, r: 0, k: 0, ph: 'b',
      nm: players.map((p, i) => String(p.name || (i + 1) + '번').slice(0, 8)),
      own: Array(n).fill(START), pot: Array(n).fill(''), pk: Array(n).fill(''),
      L: Array(n).fill(0), pr: Array(n).fill(0), sh: Array(n).fill(0), xl: Array(n).fill(0), eb: Array(n).fill(0),
      st: Array(n).fill(0), dc: Array(n).fill(null),
      sc: Array(n).fill(0), co: Array(n).fill(0), up: Array(n).fill(0),
      mk: '', bo: Array(n).fill(null), rs: null, last: { id: 0 }, sq: 0,
    };
    return s;
  }

  function actor(s) {
    if (s.ph === 'b') { const a = []; for (let i = 0; i < s.n; i++) if (s.st[i] === 0 && s.dc[i] == null) a.push(i); return a; }
    if (s.ph === 's') { const a = []; for (let i = 0; i < s.n; i++) if (s.bo[i] == null) a.push(i); return a; }
    return null;
  }

  /* 재료 1개를 솥에 넣기 (효과 포함). ev: [코드, 거품, 효과, 압력, 거품위치, 덤] */
  function place(s, i, t, ev, depth) {
    const L0 = lim(s, i);
    let g = 1, fx = 0, x = '';
    if (isFruit(t)) {
      const v = fv(t);
      g = v;
      if (s.sh[i] > 0) { s.sh[i]--; s.pot[i] += SHIELDED[t]; fx = 2; }
      else { s.pot[i] += t; s.pr[i] += v; if (s.pr[i] > L0) fx = 1; }
    } else {
      const before = s.pot[i];
      s.pot[i] += t;
      switch (t) {
        case 'e': g = 3; break;
        case 'f': s.pr[i] = Math.max(0, s.pr[i] - 1); fx = 3; break;
        case 'g': if (before.indexOf('g') >= 0) { g = 3; fx = 5; } break;
        case 'h': g = Math.min(7, 1 + s.eb[i]); fx = 5; break;
        case 'i': s.sh[i]++; fx = 6; break;
        case 'k': { let R = remaining(s, i); while (s.pk[i].length < 2 && R.length) { const j = Math.floor(Math.random() * R.length); s.pk[i] += R[j]; R = R.slice(0, j) + R.slice(j + 1); } fx = 7; break; }
        case 'o': s.xl[i]++; fx = 8; break;
        case 'p': { let c = 0; for (const u of before) if (isFruit(u)) c++; g = 1 + Math.min(4, c); fx = c ? 5 : 0; break; }
        case 'r': {
          let best = -1, bv = 0;
          for (let j = 0; j < s.pot[i].length; j++) { const u = s.pot[i][j]; if ('abc'.indexOf(u) >= 0 && fv(u) >= bv) { bv = fv(u); best = j; } }
          if (best >= 0) { x = s.pot[i][best]; s.pot[i] = s.pot[i].slice(0, best) + s.pot[i].slice(best + 1); s.pr[i] = Math.max(0, s.pr[i] - bv); fx = 4; }
          break;
        }
      }
    }
    s.eb[i] = g;
    s.L[i] = Math.min(TR, s.L[i] + g);
    ev.push(x ? [t, g, fx, s.pr[i], s.L[i], x] : [t, g, fx, s.pr[i], s.L[i]]);
    if (fx === 1) { s.st[i] = 2; return; }
    if (t === 'j' && depth < 6) {
      const R = remaining(s, i).split('').filter((u) => !isFruit(u));
      if (R.length) { ev[ev.length - 1][2] = 9; place(s, i, R[Math.floor(Math.random() * R.length)], ev, depth + 1); }
    }
  }
  function drawOne(s, i, ev) {
    let t;
    if (s.pk[i].length) { t = s.pk[i][0]; s.pk[i] = s.pk[i].slice(1); }
    else { const R = remaining(s, i); if (!R.length) return; t = R[Math.floor(Math.random() * R.length)]; }
    place(s, i, t, ev, 0);
  }
  function stopP(s, i, ev) {
    s.st[i] = 1;
    const P = s.pot[i];
    if (P.length && P[P.length - 1] === 'q') { s.L[i] = Math.min(TR, s.L[i] + 5); ev.push(['q', 5, 10, s.pr[i], s.L[i]]); }
  }
  const bagLeft = (s, i) => remaining(s, i).length + s.pk[i].length;

  function roundScore(s) {
    const rs = [];
    let best = -1;
    if (s.n > 1) for (let i = 0; i < s.n; i++) if (s.st[i] !== 2) best = Math.max(best, s.L[i]);
    for (let i = 0; i < s.n; i++) {
      const bust = s.st[i] === 2, Lv = s.L[i];
      let pt = PT(Lv), co = CO(Lv), hon = 0, can = 0, top = 0;
      if (bust) { pt = Math.floor(pt / 2); co = Math.floor(co / 2); }
      else {
        for (const t of s.pot[i]) { if (t === 'l') hon += 4; if (t === 'n') can++; }
        if (s.n > 1 && Lv === best && best > 0) top = 1;
      }
      pt += can + top; co += hon;
      s.sc[i] += pt; s.co[i] += co;
      rs.push([Lv, bust ? 1 : 0, pt, co, top, 0]);
    }
    const last = s.r >= s.R - 1;
    if (last) {
      for (let i = 0; i < s.n; i++) { const b = Math.floor(s.co[i] / 5); s.sc[i] += b; rs[i][5] = -b; }
    } else if (s.n > 1) {
      const lead = Math.max(...s.sc);
      for (let i = 0; i < s.n; i++) { const ch = Math.min(6, Math.floor((lead - s.sc[i]) / 4)); s.co[i] += ch; rs[i][5] = ch; }
    }
    s.rs = rs;
    return last;
  }

  function newMarket(s) {
    const k = SHOPK.split('');
    U.shuffle(k);
    s.mk = k.slice(0, 6).sort().join('');
  }
  function startRound(s) {
    for (let i = 0; i < s.n; i++) {
      s.pot[i] = ''; s.pk[i] = ''; s.L[i] = 0; s.pr[i] = 0; s.sh[i] = 0; s.xl[i] = 0; s.eb[i] = 0; s.st[i] = 0; s.dc[i] = null;
    }
    s.k = 0; s.ph = 'b';
  }

  function shopCost(code) { return ING[code].p; }
  function canBuy(s, i, list) {
    if (typeof list !== 'string' || list.length > MAXBUY) return false;
    let cost = 0;
    const seen = {};
    for (const c of list) {
      if (seen[c]) return false; seen[c] = 1;
      if (c === 'T') { if (s.own[i].indexOf('a') < 0) return false; }
      else if (c === 'U') { if (s.up[i] >= UPMAX) return false; }
      else if (c !== 'd' && s.mk.indexOf(c) < 0) return false;
      if (!ING[c]) return false;
      cost += shopCost(c);
    }
    return cost <= s.co[i];
  }

  function apply(s, seat, a) {
    if (!a) throw new Error('no action');
    if (s.ph === 'b') {
      if (s.st[seat] !== 0 || s.dc[seat] != null) throw new Error('not now');
      s.dc[seat] = a.d ? 1 : 0;
      if (actor(s).length) return s;
      // 모두 골랐다 → 한꺼번에 공개·진행
      const ev = Array.from({ length: s.n }, () => []);
      const dec = s.dc.slice();
      for (let i = 0; i < s.n; i++) {
        if (s.st[i] !== 0) continue;
        if (dec[i] === 1) drawOne(s, i, ev[i]);
        else stopP(s, i, ev[i]);
      }
      for (let i = 0; i < s.n; i++) if (s.st[i] === 0 && !bagLeft(s, i)) stopP(s, i, ev[i]);
      s.dc = Array(s.n).fill(null);
      s.k++;
      s.sq++;
      s.last = { id: s.sq, k: 's', ev, dc: dec };
      if (s.st.every((v) => v !== 0)) {
        const fin = roundScore(s);
        s.last.end = 1;
        if (fin) s.ph = 'x';
        else { s.ph = 's'; newMarket(s); s.bo = Array(s.n).fill(null); }
      }
      return s;
    }
    if (s.ph === 's') {
      if (s.bo[seat] != null) throw new Error('done');
      const list = String(a.b || '');
      if (!canBuy(s, seat, list)) throw new Error('bad buy');
      let cost = 0;
      for (const c of list) {
        cost += shopCost(c);
        if (c === 'T') { const j = s.own[seat].indexOf('a'); s.own[seat] = s.own[seat].slice(0, j) + s.own[seat].slice(j + 1); }
        else if (c === 'U') s.up[seat]++;
        else s.own[seat] = (s.own[seat] + c).split('').sort().join('');
      }
      s.co[seat] -= cost;
      s.bo[seat] = list;
      if (actor(s).length) return s;
      for (let i = 0; i < s.n; i++) s.co[i] = Math.min(SAVE, s.co[i]);
      s.sq++;
      s.last = { id: s.sq, k: 'b', bo: s.bo.slice() };
      s.r++;
      s.bo = Array(s.n).fill(null);
      startRound(s);
      return s;
    }
    throw new Error('game over');
  }

  function result(s) {
    if (s.ph !== 'x') return null;
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    if (s.n === 1) {
      const need = STARS[s.R] || STARS[9], st = need.filter((v) => s.sc[0] >= v).length;
      return { winners: st ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요', text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  마력 ★' + s.sc[0] + '\n별 기준 ' + need.join(' / ') };
    }
    const top = Math.max(...s.sc);
    let win = s.sc.map((v, i) => (v === top ? i : -1)).filter((i) => i >= 0);
    if (win.length > 1) { const bc = Math.max(...win.map((i) => s.own[i].length)); win = win.filter((i) => s.own[i].length === bc); }
    const order = s.sc.map((_, i) => i).sort((a, b) => s.sc[b] - s.sc[a] || a - b);
    return {
      winners: win, title: win.length > 1 ? '공동 우승' : nm(win[0]) + ' 우승!',
      text: order.map((i) => (s.sc.filter((v) => v > s.sc[i]).length + 1) + '위  ' + nm(i) + '  ★' + s.sc[i] + ' · 재료 ' + s.own[i].length + '개').join('\n'),
    };
  }

  /* ---------- AI ---------- */
  function hash(a, b, c) { let x = (a * 73856093) ^ (b * 19349663) ^ (c * 83492791); x = (x ^ (x >>> 13)) * 1274126177; return ((x ^ (x >>> 16)) >>> 0) / 4294967296; }
  function coinVal(s) { return s.r >= s.R - 1 ? 0.2 : s.r >= s.R - 2 ? 0.25 : 0.38; }
  function stopU(s, i) {
    let Lv = s.L[i];
    if (s.st[i] === 2) return Math.floor(PT(Lv) / 2) + Math.floor(CO(Lv) / 2) * coinVal(s);
    const P = s.pot[i];
    if (P.length && P[P.length - 1] === 'q') Lv = Math.min(TR, Lv + 5);
    let u = PT(Lv) + CO(Lv) * coinVal(s);
    for (const t of P) { if (t === 'l') u += 4 * coinVal(s); if (t === 'n') u += 1; }
    return u;
  }
  function wantDraw(s, i, lv) {
    if (!bagLeft(s, i)) return false;
    const P = s.pot[i], petal = P.length && P[P.length - 1] === 'q';
    if (lv === 1) {
      const r = riskOf(s, i, true);
      if (r === 0) return true;
      const thr = 0.28 + hash(s.r, i, 7) * 0.25;
      if (Math.random() < 0.07) return false;
      return r <= thr;
    }
    const r = riskOf(s, i);
    if (r === 0 && !petal) return true;
    if (lv === 2) {
      if (petal && r > 0.08) return false;
      let thr = 0.2;
      if (s.n > 1 && s.r >= s.R - 2 && Math.max(...s.sc) - s.sc[i] > 8) thr = 0.3;
      return r <= thr;
    }
    // lv3: 정확한 위험 % + 꽃잎·순위 계산
    if (petal) return r < 0.05;
    let thr = 0.28;
    if (s.n > 1) {
      const others = s.sc.filter((_, j) => j !== i), lead = Math.max(...others) - s.sc[i], left = s.R - s.r;
      if (left <= 2 && lead > 6) thr = 0.4;
      else if (left <= 2 && lead < -8) thr = 0.2;
      // 이미 멈춘 상대보다 거품이 조금 모자라면 「으뜸 솥」을 노려 한 번 더
      const best = Math.max(...s.L.filter((_, j) => j !== i && s.st[j] === 1).concat([-1]));
      if (best >= s.L[i] && best - s.L[i] <= 3 && s.st.every((v, j) => j === i || v !== 0)) thr += 0.12;
    }
    return r <= thr;
  }
  /* 장보기 */
  function itemVal(s, i, c, lv) {
    const left = s.R - 1 - s.r;            // 이 재료를 쓸 수 있는 남은 판 수
    const own = s.own[i];
    let fp = 0, prot = 0;
    for (const t of own) { fp += fv(t); if ('fior'.indexOf(t) >= 0) prot++; }
    const cnt = (t) => own.split(t).length - 1;
    const k = Math.max(0.3, Math.min(1.5, fp / Math.max(1, own.length) / 0.9)) * Math.pow(0.88, prot + s.up[i]);
    let v;   // 한 판에 버는 마력(대략)
    switch (c) {
      case 'd': v = 0.16; break;
      case 'e': v = 0.38; break;
      case 'f': v = 0.6 * k; break;
      case 'g': v = 0.28 + (cnt('g') ? 0.25 : 0); break;
      case 'h': v = 0.32; break;
      case 'i': v = 0.85 * k; break;
      case 'j': v = 0.26; break;
      case 'k': v = 0.18; break;
      case 'l': v = left > 1 ? 0.16 : 0.05; break;
      case 'n': v = 0.4; break;
      case 'o': v = 0.62 * k; break;
      case 'p': v = 0.38; break;
      case 'q': v = lv === 3 ? 0.15 : 0.08; break;
      case 'r': v = 0.45 * k; break;
      case 'T': { const na = cnt('a'); v = na >= 2 ? 0.6 * k : na === 1 ? 0.3 * k : 0; break; }
      case 'U': v = 0.5 * k; break;
      default: v = 0;
    }
    return v * left;
  }
  function shopPlan(s, i, lv) {
    const items = ['d', 'T', 'U'].concat(s.mk.split('')).filter((c) => canBuy(s, i, c));
    if (!items.length) return '';
    if (lv === 1) {
      const r = U.shuffle(items.slice());
      let out = '';
      for (const c of r) if (out.length < 2 && canBuy(s, i, out + c) && Math.random() < 0.7) out += c;
      return out;
    }
    if (lv === 2) {
      const sc = items.map((c) => [c, itemVal(s, i, c, 2) / shopCost(c) * (0.75 + Math.random() * 0.5)]).sort((a, b) => b[1] - a[1]);
      let out = '';
      for (const [c] of sc) if (out.length < MAXBUY && canBuy(s, i, out + c)) out += c;
      return out;
    }
    // lv3: 조합을 다 따져 보고, 좋은 후보 몇 개는 실제로 솥을 끓여 보며(모의 실험) 고름
    const left = s.R - 1 - s.r;
    const coinKeep = left > 1 ? 0.12 : 0.02;
    const vals = {}; for (const c of items) vals[c] = itemVal(s, i, c, 3);
    const N = items.length, cand = [];
    for (let a = -1; a < N; a++) for (let b = a; b < N; b++) for (let c = b; c < N; c++) {
      const set = [a, b, c].filter((x, k, arr) => x >= 0 && arr.indexOf(x) === k);
      const str = set.map((x) => items[x]).join('');
      if (cand.some((q) => q[0] === str) || !canBuy(s, i, str)) continue;
      let v = 0, cost = 0;
      for (const ch of str) { v += vals[ch]; cost += shopCost(ch); }
      cand.push([str, v + Math.min(SAVE, s.co[i] - cost) * coinKeep, cost]);
    }
    cand.sort((x, y) => y[1] - x[1]);
    const top = cand.slice(0, 6);
    if (top.length < 2 || left < 1) return top.length ? top[0][0] : '';
    let best = top[0][0], bv = -1e9;
    for (const [str, , cost] of top) {
      let own = s.own[i], up = s.up[i];
      for (const ch of str) {
        if (ch === 'T') { const j = own.indexOf('a'); own = own.slice(0, j) + own.slice(j + 1); }
        else if (ch === 'U') up++;
        else own += ch;
      }
      const v = rollAvg(s, own, up, 32) * left + Math.min(SAVE, s.co[i] - cost) * coinKeep;
      if (v > bv) { bv = v; best = str; }
    }
    return best;
  }
  /* 모의 실험: 이 주머니로 한 판 끓이면 평균 얼마나 버나 (같은 난수 줄을 써서 후보끼리 공정하게 비교) */
  function rollAvg(s0, own, up, K) {
    let tot = 0;
    const occ = {};
    const keyed = own.split('').map((t) => { occ[t] = (occ[t] || 0) + 1; return t + occ[t]; });
    for (let k = 0; k < K; k++) {
      const order = keyed.map((id) => [id[0], hash(k + 1, id.charCodeAt(0), +id.slice(1) * 31 + 7)]).sort((x, y) => x[1] - y[1]).map((x) => x[0]);
      const m = { n: 1, own: [own], up: [up], pot: [''], pk: [''], L: [0], pr: [0], sh: [0], xl: [0], eb: [0], st: [0], r: s0.r, R: s0.R };
      const take = (t) => { const j = order.indexOf(t); if (j >= 0) order.splice(j, 1); };
      let guard = 0;
      while (m.st[0] === 0 && guard++ < 60) {
        if (!bagLeft(m, 0)) break;
        const P = m.pot[0], petal = P.length && P[P.length - 1] === 'q';
        const r = riskOf(m, 0);
        if (r > 0.25 || (petal && r > 0.05)) break;
        let t;
        if (m.pk[0].length) { t = m.pk[0][0]; m.pk[0] = m.pk[0].slice(1); }
        else { t = order[0]; }
        take(t);
        const before = m.pot[0];
        place(m, 0, t, [], 0);
        // 꼬리별·부엉이가 가져간 재료도 순서에서 뺀다
        const extra = m.pot[0].slice(before.length + 1);
        for (const u of extra) take(base(u));
        for (const u of m.pk[0]) take(u);
      }
      tot += stopU(m, 0);
    }
    return tot / K;
  }

  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'b') {
      if (s.st[seat] !== 0 || s.dc[seat] != null) return null;
      return { d: wantDraw(s, seat, lv) ? 1 : 0 };
    }
    if (s.ph === 's') {
      if (s.bo[seat] != null) return null;
      return { b: shopPlan(s, seat, lv) };
    }
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'b') {
      if (s.st[seat] !== 0 || s.dc[seat] != null) return -1;
      const r = riskOf(s, seat);
      if (r === 0) return 260;
      return [0, 900, 700, 600][lv || 2];
    }
    if (s.ph === 's') return s.bo[seat] != null ? -1 : [0, 2400, 1900, 1600][lv || 2];
    return -1;
  }

  const CSS = `
.cd{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 70% at 50% 100%,#3a1f2e 0%,#1d1529 55%,#151020 100%);color:var(--ink);font-family:var(--f-body)}
.cd-strip{display:grid;gap:5px;padding:6px 8px 4px;flex:none}
.cd-pc{appearance:none;border:1px solid rgba(255,255,255,.1);background:rgba(46,38,64,.85);color:var(--ink);border-radius:11px;padding:4px 6px;min-height:50px;min-width:0;text-align:left;cursor:pointer;font:inherit;display:flex;flex-direction:column;gap:1px;position:relative;transition:border-color .2s,transform .15s}
.cd-pc.on{border-color:var(--brass);box-shadow:0 0 0 1px var(--brass) inset}
.cd-pc.boom{animation:cdBoom .5s}
@keyframes cdBoom{0%,100%{transform:none}25%{transform:translateX(-3px)}50%{transform:translateX(3px)}75%{transform:translateX(-2px)}}
.cd-pc .nm{display:flex;align-items:center;gap:4px;font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden}
.cd-pc .nm span:last-child{overflow:hidden;text-overflow:ellipsis}
.cd-pc .r2{font-family:var(--f-mono);font-size:11.5px;white-space:nowrap;overflow:hidden}
.cd-pc .r3{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:4px}
.cd-pc .mb{flex:none;width:24px;height:6px;border-radius:3px;background:rgba(255,255,255,.12);overflow:hidden}
.cd-pc .mb i{display:block;height:100%}
.cd-pc .ck{position:absolute;right:5px;top:3px;font-size:11px;color:var(--brass)}
.cd-main{position:relative;flex:1;min-height:0;display:flex;flex-direction:column}
.cd-cv{position:relative;flex:1;min-height:0}
.cd-meter{flex:none;padding:3px 10px 2px;display:flex;flex-direction:column;gap:3px}
.cd-mrow{display:flex;align-items:center;gap:6px;font-size:12px}
.cd-segs{flex:1;display:flex;gap:2px;height:12px}
.cd-segs i{flex:1;border-radius:3px;background:rgba(255,255,255,.1)}
.cd-risk{flex:none;font-family:var(--f-mono);font-weight:700;font-size:12px;padding:2px 7px;border-radius:999px;background:rgba(255,255,255,.08)}
.cd-hint{font-size:12.5px;line-height:1.3;min-height:17px;color:var(--ink)}
.cd-hint b{color:var(--brass)}
.cd-pot{flex:none;display:flex;align-items:center;gap:6px;padding:2px 8px}
.cd-chips{flex:1;min-width:0;display:flex;gap:3px;overflow-x:auto;scrollbar-width:none;height:30px;align-items:center}
.cd-chips::-webkit-scrollbar{display:none}
.cd-chip{flex:none;width:25px;height:25px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:13px;line-height:1;border:2px solid rgba(0,0,0,.35);box-shadow:inset 0 2px 0 rgba(255,255,255,.25);box-sizing:border-box}
.cd-chip.fr{color:#fff;font-family:var(--f-mono);font-weight:800;font-size:12px}
.cd-chip.sh{outline:2px solid #6fe0c2}
.cd-chip.lastc{box-shadow:0 0 0 2px var(--brass)}
.cd-emp{font-size:12px;color:var(--muted)}
.cd-bagb{min-width:58px;padding:6px 8px}
.cd-bar{flex:none;display:flex;gap:8px;padding:6px 10px 10px;align-items:stretch}
.cd-bar .btn{min-height:52px;font-size:16px}
.cd-bar .stop{flex:1}
.cd-bar .draw{flex:1.6;font-size:17px}
.cd-wait{flex:1;min-height:52px;display:flex;align-items:center;justify-content:center;font-size:13.5px;color:var(--muted);text-align:center}
.cd-shop{position:absolute;inset:0;background:#151020;overflow-y:auto;padding:8px 10px 0;display:none;flex-direction:column;gap:8px;z-index:3}
.cd-shop.show{display:flex}
.cd-sh-h{display:flex;align-items:center;justify-content:space-between;gap:8px}
.cd-sh-h h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:19px;color:var(--brass)}
.cd-coin{font-family:var(--f-mono);font-weight:700;font-size:15px;white-space:nowrap}
.cd-res{background:rgba(255,255,255,.05);border-radius:10px;padding:6px 8px;font-size:12px;display:flex;flex-direction:column;gap:3px}
.cd-res .rw{display:flex;align-items:center;gap:5px;white-space:nowrap}
.cd-res .rw .n{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;font-weight:700}
.cd-res .rw .v{font-family:var(--f-mono)}
.cd-res .tag{font-size:11px;padding:0 5px;border-radius:6px;background:rgba(255,255,255,.1)}
.cd-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.cd-it{appearance:none;font:inherit;color:var(--ink);text-align:left;border:1px solid rgba(255,255,255,.12);background:var(--surface-2);border-radius:11px;padding:6px 7px;min-height:64px;display:flex;flex-direction:column;gap:2px;cursor:pointer;position:relative;min-width:0}
.cd-it:disabled{opacity:.42;cursor:default}
.cd-it.sel{border-color:var(--brass);background:#4a3a2a;box-shadow:0 0 0 1px var(--brass) inset}
.cd-it .t1{display:flex;align-items:center;gap:5px;font-weight:700;font-size:12.5px;min-width:0}
.cd-it .t1 .nmx{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cd-it .pr{font-family:var(--f-mono);color:var(--brass);font-size:12.5px;flex:none}
.cd-it .ds{font-size:11px;line-height:1.25;color:var(--muted)}
.cd-it .chk{position:absolute;right:6px;bottom:4px;color:var(--brass);font-weight:800}
.cd-foot{position:sticky;bottom:0;display:flex;gap:8px;padding:8px 0 10px;background:linear-gradient(transparent,rgba(21,16,32,.97) 30%)}
.cd-foot .btn{min-height:50px}
.cd-foot .go{flex:1}
.cd-note{font-size:12px;color:var(--muted)}
.cd-sheet{position:absolute;inset:0;z-index:5;background:rgba(10,8,16,.6);display:flex;align-items:flex-end}
.cd-sheet .bx{width:100%;max-height:86%;overflow-y:auto;background:var(--surface);border-radius:16px 16px 0 0;padding:10px 12px 12px;box-sizing:border-box}
.cd-sheet h3{margin:0 0 6px;font-size:15px;display:flex;justify-content:space-between;align-items:center;gap:8px}
.cd-brow{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.cd-brow .tx{flex:1;min-width:0}
.cd-brow .tx b{font-size:13px}
.cd-brow .tx div{font-size:11.5px;color:var(--muted);line-height:1.25}
.cd-brow .ct{font-family:var(--f-mono);font-size:12px;text-align:right;flex:none;white-space:pre}
`;
  const EMO = '"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
  function chipEl(t, extra) {
    const b = base(t), I = ING[b];
    const fr = isFruit(t);
    return L.h('span', { class: 'cd-chip' + (fr ? ' fr' : '') + (t !== b ? ' sh' : '') + (extra ? ' ' + extra : ''), style: { background: I.col }, text: fr ? String(fv(t)) : I.e, title: I.n });
  }
  const FXT = { 2: '🐢 막았어요', 3: '❄ 압력 −1', 4: '🐸 열매 돌려보냄', 6: '🐢 보호', 7: '🦉 미리 보기', 8: '🐉 한도 +1', 9: '✨ 하나 더!', 10: '🌸 마무리 +5' };
  const mcol = (q) => (q < 0.5 ? '#4fd6a0' : q < 0.8 ? '#f2b84b' : '#ff6a4a');

  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'cd' });
    const strip = h('div', { class: 'cd-strip' });
    const main = h('div', { class: 'cd-main' });
    const cvw = h('div', { class: 'cd-cv' });
    const meter = h('div', { class: 'cd-meter' });
    const potRow = h('div', { class: 'cd-pot' });
    const bar = h('div', { class: 'cd-bar' });
    const shop = h('div', { class: 'cd-shop' });
    main.append(cvw, meter, potRow, bar, shop);
    wrap.append(strip, main);
    root.append(style, wrap);
    const cv = U.canvas(cvw), ctx = cv.ctx;

    let st = null, dead = false, busy = false, manual = -1, sheet = null, cart = { key: '', s: '' };
    let G = null;
    const sent = {}, timers = new Set();
    const disp = [], shownPot = [];         // 화면에 보이는 값 (재생 중엔 실제 상태보다 늦게 따라감)
    const flights = [], parts = [], floats = [];
    let shake = 0, bagShake = 0, autoKey = '', autoAt = 0, lastRound = -1, buyNote = null, buyNoteT = 0;
    const boomAt = [];
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms / sp()); timers.add(t); return t; };
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    const keyOf = (s, i) => (s.ph === 'b' ? 'b' + s.r + '.' + s.k : 's' + s.r) + ':' + i;
    function pending() {
      if (!st || busy) return [];
      const a = actor(st) || [];
      return a.filter((i) => api.canAct(i) && !sent[keyOf(st, i)]);
    }
    const ctlSeat = () => { const p = pending(); return p.length ? p[0] : -1; };
    const multi = () => api.mySeats().length >= 2;
    function viewSeat() {
      if (!st) return 0;
      if (manual >= 0 && manual < st.n) return manual;
      const c = ctlSeat();
      if (c >= 0) return c;
      const m = api.mySeats();
      return m.length ? m[0] : 0;
    }
    function send(seat, a) {
      if (!st) return;
      const k = keyOf(st, seat);
      sent[k] = 1;
      api.actAs(seat, a);
      later(() => { if (st && keyOf(st, seat) === k) { delete sent[k]; render(); } }, 3000);   // 혹시 거절되면 다시 누를 수 있게
      render();
    }

    /* ---------- 기하 ---------- */
    function layout() {
      const W = cv.w, H = cv.h;
      const Rout = Math.max(40, Math.min(W / 2 - 14, H / 2 - 6));
      const cx = W / 2, cy = H / 2 + 2;
      const r0 = Rout * 0.5, turns = 1.55, th0 = -Math.PI / 2 + 0.25;
      const tw = Math.max(8, Math.min(15, Rout * 0.085));
      const pt = (t) => { const a = th0 + t * turns * Math.PI * 2, r = r0 + (Rout - tw * 0.6 - r0) * t; return [cx + Math.cos(a) * r, cy + Math.sin(a) * r, a]; };
      const path = [];
      for (let j = 0; j <= 180; j++) path.push(pt(j / 180));
      const cells = [];
      for (let j = 0; j <= TR; j++) cells.push(pt(j / TR));
      G = { W, H, cx, cy, Rout, r0, tw, pt, path, cells, rc: r0 * 0.74, bx: 28, by: H - 28 };
    }
    cv.onresize = layout;
    layout();
    const potXY = () => [G.cx, G.cy - G.rc * 0.42];

    /* ---------- 그리기 ---------- */
    function liqCol(i) {
      if (!st) return '#4fd6a0';
      if (st.st[i] === 2 && !busy) return '#7a6f78';
      return mcol((disp[i] ? disp[i].pr : 0) / lim(st, i));
    }
    function drawTok(x, y, r, t, rot) {
      const b = base(t), I = ING[b];
      ctx.save(); ctx.translate(x, y); if (rot) ctx.rotate(rot);
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(1.5, 2.5, r, 0, 7); ctx.fill();
      ctx.fillStyle = I.col; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.22)'; ctx.beginPath(); ctx.arc(-r * 0.3, -r * 0.35, r * 0.4, 0, 7); ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (isFruit(t)) {
        ctx.fillStyle = '#fff'; ctx.font = '800 ' + Math.round(r * 1.1) + 'px "IBM Plex Mono",monospace'; ctx.fillText(String(fv(t)), 0, 1);
        ctx.fillStyle = '#ffd36b'; ctx.beginPath(); ctx.arc(r * 0.55, -r * 0.6, r * 0.22, 0, 7); ctx.fill();
        if (t !== b) { ctx.strokeStyle = '#6fe0c2'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(0, 0, r + 2, 0, 7); ctx.stroke(); }
      } else { ctx.font = Math.round(r * 1.15) + 'px ' + EMO; ctx.fillText(I.e, 0, 1); }
      ctx.restore();
    }
    function drawBag(now, V) {
      const { bx, by } = G;
      const sh = bagShake > now ? Math.sin(now / 25) * 3 : 0;
      ctx.save(); ctx.translate(bx + sh, by);
      ctx.fillStyle = '#7a5532'; ctx.beginPath();
      ctx.moveTo(-15, -6); ctx.quadraticCurveTo(-21, 16, 0, 18); ctx.quadraticCurveTo(21, 16, 15, -6); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#5c3e22'; ctx.beginPath(); ctx.ellipse(0, -8, 11, 5, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(-10, -4); ctx.quadraticCurveTo(0, 1, 10, -4); ctx.stroke();
      ctx.fillStyle = '#ffe39a'; ctx.font = '700 11px "IBM Plex Mono",monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(remaining(st, V).length + st.pk[V].length), 0, 8);
      ctx.restore();
      if (st.pk[V].length && st.ph === 'b' && !busy) {
        ctx.fillStyle = '#cfc2dd'; ctx.font = '700 10px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText('🦉 다음', bx + 22, by - 20);
        for (let j = 0; j < st.pk[V].length; j++) drawTok(bx + 32 + j * 23, by + 3, 10, st.pk[V][j]);
      }
    }
    function strokePath(path, f) {
      const n = Math.max(1, Math.round((path.length - 1) * f));
      ctx.beginPath(); ctx.moveTo(path[0][0], path[0][1]);
      for (let j = 1; j <= n; j++) ctx.lineTo(path[j][0], path[j][1]);
      ctx.stroke();
    }
    function drawScene(now) {
      if (!G || !st) return;
      cv.clear();
      const V = viewSeat(), d = disp[V] || { L: 0, pr: 0 };
      const { tw, path, cells } = G;
      const lc = liqCol(V);
      let sx = 0, sy = 0;
      if (shake > now) { const k = (shake - now) / 700; sx = Math.sin(now / 17) * 7 * k; sy = Math.cos(now / 23) * 5 * k; }
      else if (st.ph === 'b' && st.st[V] === 0 && !busy && riskOf(st, V) >= 0.3) sx = Math.sin(now / 40) * 1.2;
      ctx.save(); ctx.translate(sx, sy);
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = '#120d1a'; ctx.lineWidth = tw + 5; strokePath(path, 1);
      ctx.strokeStyle = '#2f2540'; ctx.lineWidth = tw; strokePath(path, 1);
      const f = Math.min(1, d.L / TR);
      if (f > 0) {
        ctx.globalAlpha = 0.28; ctx.strokeStyle = lc; ctx.lineWidth = tw + 7; strokePath(path, f);
        ctx.globalAlpha = 1; ctx.lineWidth = tw - 3; strokePath(path, f);
        ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 2; strokePath(path, f);
        ctx.fillStyle = 'rgba(255,255,255,.55)';
        const nb = Math.min(14, Math.ceil(f * 14));
        for (let j = 0; j < nb; j++) {
          const p = G.pt(((j / 14 + now / 9000) % 1) * f);
          ctx.beginPath(); ctx.arc(p[0] + Math.sin(now / 300 + j) * tw * 0.15, p[1], tw * 0.12 + (j % 3) * 0.8, 0, 7); ctx.fill();
        }
      }
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '700 ' + Math.max(9, Math.round(tw * 0.75)) + 'px "IBM Plex Mono",monospace';
      for (let j = 3; j <= TR; j += 3) {
        const c = cells[j], on = j <= d.L;
        ctx.fillStyle = on ? 'rgba(255,255,255,.85)' : 'rgba(255,255,255,.25)';
        ctx.beginPath(); ctx.arc(c[0], c[1], j % 6 ? 1.6 : 2.4, 0, 7); ctx.fill();
        if (j % 6 === 0) {
          const o = tw * 0.95 + 6;
          ctx.fillStyle = on ? '#ffe39a' : 'rgba(227,174,69,.55)';
          ctx.fillText('★' + PT(j), c[0] + Math.cos(c[2]) * o, c[1] + Math.sin(c[2]) * o);
        }
      }
      const m = G.pt(f);
      ctx.fillStyle = lc; ctx.beginPath(); ctx.arc(m[0], m[1], tw * 0.78, 0, 7); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.5; ctx.stroke();
      drawPot(now, V, lc);
      ctx.restore();
      drawBag(now, V);
      for (let j = flights.length - 1; j >= 0; j--) {
        const F = flights[j], k = (now - F.t0) / F.dur;
        if (k < 0) continue;
        if (k >= 1) { flights.splice(j, 1); if (F.done) F.done(); continue; }
        if (F.seat !== V) continue;
        const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        drawTok(F.x0 + (F.x1 - F.x0) * e, F.y0 + (F.y1 - F.y0) * e - Math.sin(Math.PI * e) * F.arc, 13 - 3 * (F.out ? 1 - k : k), F.t, e * 6);
      }
      for (let j = parts.length - 1; j >= 0; j--) {
        const P = parts[j]; P.life -= 1 / 60; if (P.life <= 0) { parts.splice(j, 1); continue; }
        P.x += P.vx; P.y += P.vy; P.vy += P.g;
        ctx.globalAlpha = Math.min(1, P.life * 2); ctx.fillStyle = P.c;
        ctx.beginPath(); ctx.arc(P.x, P.y, P.r, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let j = floats.length - 1; j >= 0; j--) {
        const T = floats[j], k = (now - T.t0) / (1100 / sp());
        if (k >= 1) { floats.splice(j, 1); continue; }
        if (k < 0 || T.seat !== V) continue;
        ctx.globalAlpha = 1 - k * k; ctx.fillStyle = T.c; ctx.font = '800 ' + T.sz + 'px "IBM Plex Sans KR",sans-serif';
        ctx.strokeStyle = 'rgba(0,0,0,.65)'; ctx.lineWidth = 3;
        ctx.strokeText(T.s, T.x, T.y - k * 34); ctx.fillText(T.s, T.x, T.y - k * 34);
      }
      ctx.globalAlpha = 1;
      ctx.textBaseline = 'top'; ctx.textAlign = 'left'; ctx.fillStyle = '#cfc2dd';
      ctx.font = '700 12px "IBM Plex Sans KR",sans-serif';
      ctx.fillText(Math.min(st.r + 1, st.R) + ' / ' + st.R + '판', 8, 6);
      if (st.n > 1) { ctx.fillStyle = col(V); ctx.fillText('● ' + nm(V).slice(0, 6) + '의 솥', 8, 22); }
      ctx.textAlign = 'right'; ctx.fillStyle = '#ffe39a';
      let pt = PT(d.L), co = CO(d.L);
      if (st.st[V] === 2 && !busy) { pt >>= 1; co >>= 1; }
      ctx.font = '700 12px "IBM Plex Mono",monospace';
      ctx.fillText('거품 ' + d.L, G.W - 8, 6);
      ctx.fillText('★' + pt + ' 💰' + co, G.W - 8, 22);
    }
    function drawPot(now, V, lc) {
      const { cx, cy, rc } = G;
      const burst = st.st[V] === 2 && !busy;
      for (let j = 0; j < 5; j++) {
        const x = cx + (j - 2) * rc * 0.28, fl = rc * (0.32 + 0.1 * Math.sin(now / 90 + j * 2));
        ctx.fillStyle = j % 2 ? 'rgba(255,170,60,.85)' : 'rgba(255,100,50,.8)';
        ctx.beginPath(); ctx.moveTo(x - rc * 0.12, cy + rc * 0.95); ctx.quadraticCurveTo(x, cy + rc * 0.95 - fl * 2, x + rc * 0.12, cy + rc * 0.95); ctx.fill();
      }
      const gr = ctx.createRadialGradient(cx - rc * 0.3, cy - rc * 0.1, rc * 0.1, cx, cy + rc * 0.1, rc * 1.05);
      gr.addColorStop(0, '#4b4258'); gr.addColorStop(1, '#14101b');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy + rc * 0.12, rc * 0.86, 0, 7); ctx.fill();
      const ry = cy - rc * 0.42;
      ctx.fillStyle = '#2b2435'; ctx.beginPath(); ctx.ellipse(cx, ry, rc * 0.82, rc * 0.24, 0, 0, 7); ctx.fill();
      ctx.fillStyle = burst ? '#3d363d' : lc; ctx.beginPath(); ctx.ellipse(cx, ry + 2, rc * 0.7, rc * 0.17, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#5a4f66'; ctx.lineWidth = 4; ctx.beginPath(); ctx.ellipse(cx, ry, rc * 0.82, rc * 0.24, 0, 0, 7); ctx.stroke();
      if (!burst) {
        ctx.fillStyle = 'rgba(255,255,255,.45)';
        for (let j = 0; j < 4; j++) {
          const ph = (now / 700 + j * 0.27) % 1;
          ctx.beginPath(); ctx.arc(cx + Math.sin(j * 2.3) * rc * 0.45, ry + 1 - ph * 3, 1.5 + ph * rc * 0.07, 0, 7); ctx.fill();
        }
        ctx.fillStyle = 'rgba(220,210,240,.10)';
        for (let j = 0; j < 3; j++) { const ph = (now / 1600 + j / 3) % 1; ctx.beginPath(); ctx.arc(cx + Math.sin(now / 900 + j) * 8, ry - 6 - ph * rc * 0.6, 5 + ph * 10, 0, 7); ctx.fill(); }
      } else {
        ctx.strokeStyle = '#0a070d'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(cx - rc * 0.2, cy - rc * 0.1); ctx.lineTo(cx - rc * 0.05, cy + rc * 0.2); ctx.lineTo(cx - rc * 0.22, cy + rc * 0.45); ctx.stroke();
        ctx.fillStyle = 'rgba(120,110,120,.25)';
        for (let j = 0; j < 3; j++) { const ph = (now / 1300 + j / 3) % 1; ctx.beginPath(); ctx.arc(cx + Math.sin(now / 700 + j) * 10, ry - ph * rc * 0.8, 6 + ph * 14, 0, 7); ctx.fill(); }
      }
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (burst) { ctx.fillStyle = '#ff8a5a'; ctx.font = '800 ' + Math.round(rc * 0.38) + 'px "IBM Plex Sans KR",sans-serif'; ctx.fillText('펑!', cx, cy + rc * 0.25); }
      else if (st.ph === 'b' && st.st[V] === 1 && !busy) { ctx.fillStyle = '#ffe39a'; ctx.font = '800 ' + Math.round(rc * 0.26) + 'px "IBM Plex Sans KR",sans-serif'; ctx.fillText('✋ 멈춤', cx, cy + rc * 0.25); }
      if (st.sh[V] > 0 && st.ph === 'b') { ctx.font = Math.round(rc * 0.3) + 'px ' + EMO; ctx.fillText('🐢' + (st.sh[V] > 1 ? '×' + st.sh[V] : ''), cx + rc * 0.62, cy + rc * 0.55); }
    }
    function splash(x, y, c, n) {
      for (let j = 0; j < n && parts.length < 140; j++) parts.push({ x, y, vx: (Math.random() - 0.5) * 4, vy: -1.5 - Math.random() * 3, g: 0.18, r: 1.5 + Math.random() * 2.5, c, life: 0.6 + Math.random() * 0.4 });
    }
    function boom(i) {
      const [px, py] = potXY(), now = performance.now();
      boomAt[i] = now;
      if (i === viewSeat()) {
        shake = now + 700;
        for (let j = 0; j < 40 && parts.length < 180; j++) { const a = Math.random() * 7, v = 2 + Math.random() * 5; parts.push({ x: px, y: py, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 2, g: 0.12, r: 2 + Math.random() * 4, c: j % 3 ? '#ff7a3a' : '#ffd36b', life: 0.7 + Math.random() * 0.5 }); }
        floats.push({ seat: i, s: '펑! 솥이 터졌어요', x: G.W / 2, y: py - 8, c: '#ff8a5a', sz: 17, t0: now });
        api.sfx('lose');
      }
      if (api.canAct(i)) api.buzz(120);
      const card = strip.children[i]; if (card) { card.classList.remove('boom'); void card.offsetWidth; card.classList.add('boom'); }
    }

    /* ---------- 사건 재생 ---------- */
    function playStep(s, prev) {
      const ev = s.last.ev, gap = 480, dur = 400;
      let longest = 0;
      const t0 = performance.now();
      for (let i = 0; i < s.n; i++) {
        const list = ev[i] || [];
        disp[i] = { L: prev.L[i], pr: prev.pr[i] };
        shownPot[i] = prev.pot[i];
        list.forEach((e, j) => {
          const at = j * gap;
          longest = Math.max(longest, at + dur + (e[5] ? dur : 0) + (e[2] === 1 ? 500 : 0));
          const land = () => {
            if (dead) return;
            disp[i].L = e[4]; disp[i].pr = e[3];
            if (e[2] !== 10) shownPot[i] += isFruit(e[0]) && e[2] === 2 ? ({ a: 'x', b: 'y', c: 'z' })[e[0]] : e[0];
            if (e[5]) { const k = shownPot[i].lastIndexOf(e[5]); if (k >= 0) shownPot[i] = shownPot[i].slice(0, k) + shownPot[i].slice(k + 1); }
            const [px, py] = potXY();
            if (i === viewSeat()) {
              const fr = isFruit(e[0]);
              splash(px, py, fr ? '#ff8a5a' : liqCol(i), 8);
              floats.push({ seat: i, s: '+' + e[1] + (fr && e[2] !== 2 ? '  압력+' + fv(e[0]) : ''), x: px, y: py - 18, c: fr ? '#ffb0a0' : '#c8ffe8', sz: 15, t0: performance.now() });
              if (FXT[e[2]]) floats.push({ seat: i, s: FXT[e[2]], x: px, y: py + 16, c: '#ffe39a', sz: 13, t0: performance.now() + 120 });
              api.sfx(fr ? 'thud' : 'pop');
            }
            if (e[2] === 1) boom(i);
            renderStrip(); if (i === viewSeat()) { renderMeter(); renderPot(); }
          };
          if (e[2] === 10) { later(land, at); return; }
          const [px, py] = potXY();
          later(() => { if (i === viewSeat()) { bagShake = performance.now() + 250; api.sfx('whoosh'); } }, at);
          flights.push({ seat: i, t: e[0], t0: t0 + at / sp(), dur: dur / sp(), x0: G.bx, y0: G.by - 8, x1: px, y1: py, arc: Math.min(G.H * 0.35, 90), done: land });
          if (e[5]) flights.push({ seat: i, t: e[5], out: 1, t0: t0 + (at + dur) / sp(), dur: dur / sp(), x0: px, y0: py, x1: G.bx, y1: G.by - 8, arc: 60 });
        });
      }
      if (longest > 0) { setBusy(true); later(() => { setBusy(false); snap(); render(); }, longest + 150); }
      else snap();
    }
    function snap() { if (!st) return; for (let i = 0; i < st.n; i++) { disp[i] = { L: st.L[i], pr: st.pr[i] }; shownPot[i] = st.pot[i]; } }

    /* ---------- DOM ---------- */
    const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
    function renderStrip() {
      if (!st) return;
      const V = viewSeat();
      strip.style.gridTemplateColumns = 'repeat(' + st.n + ',minmax(0,1fr))';
      while (strip.children.length > st.n) strip.lastChild.remove();
      for (let i = 0; i < st.n; i++) {
        let c = strip.children[i];
        if (!c) {
          c = h('button', { class: 'cd-pc', 'aria-label': nm(i) + '의 솥 보기', onclick: () => {
            const mine = (() => { const k = ctlSeat(); if (k >= 0) return k; const m = api.mySeats(); return m.length ? m[0] : 0; })();
            manual = i === mine ? -1 : i; api.sfx('click'); render();
          } });
          strip.append(c);
        }
        c.classList.toggle('on', i === V);
        const d = disp[i] || { L: st.L[i], pr: st.pr[i] };
        let r3 = '', ck = '';
        if (st.ph === 'b' || (busy && st.last && st.last.end)) {
          const q = d.pr / lim(st, i);
          if (st.st[i] === 2 && !busy) r3 = '💥 펑! 거품 ' + d.L;
          else if (st.st[i] === 1 && !busy) r3 = '✋ 멈춤 · 거품 ' + d.L;
          else r3 = '<span class="mb"><i style="width:' + Math.min(100, q * 100) + '%;background:' + mcol(q) + '"></i></span>거품 ' + d.L;
          if (st.ph === 'b' && st.st[i] === 0 && st.dc[i] != null) ck = '✓';
        } else if (st.ph === 's') r3 = st.bo[i] != null ? '✓ 장보기 끝' : '🛒 장보는 중';
        else r3 = '재료 ' + st.own[i].length + '개';
        if (buyNote && buyNote[i] != null && performance.now() < buyNoteT && st.ph === 'b' && st.k < 2) r3 = '🛒 ' + (buyNote[i] ? buyNote[i].split('').map((t) => ING[t].e).join('') : '안 삼');
        c.innerHTML = '<div class="nm"><span class="dot" style="--c:' + col(i) + '"></span><span>' + esc(nm(i)) + '</span></div>' +
          '<div class="r2">★' + st.sc[i] + ' 💰' + st.co[i] + (st.up[i] ? ' 🔩' + st.up[i] : '') + '</div><div class="r3">' + r3 + '</div>' + (ck ? '<span class="ck">' + ck + '</span>' : '');
      }
    }
    function autoOK(i) {
      if (!st || st.ph !== 'b' || st.st[i] !== 0 || busy) return false;
      const P = st.pot[i];
      return riskOf(st, i) === 0 && !(P.length && P[P.length - 1] === 'q') && bagLeft(st, i) > 0;
    }
    function renderMeter() {
      if (!st) return;
      const V = viewSeat(), d = disp[V] || { pr: 0 }, Lm = lim(st, V);
      meter.innerHTML = '';
      const segs = h('div', { class: 'cd-segs' });
      const mc = mcol(d.pr / Lm);
      for (let j = 0; j < Lm; j++) segs.append(h('i', { style: j < d.pr ? { background: mc } : {} }));
      let hint = '', rk = null;
      if (st.ph === 'b' || (busy && st.last && st.last.end)) {
        if (busy) hint = '재료를 넣는 중…';
        else if (st.st[V] === 2) hint = '💥 솥이 터졌어요! 이번 판 ★·💰는 절반만.';
        else if (st.st[V] === 1) hint = '✋ 멈췄어요. 다른 마녀를 기다려요.';
        else {
          const room = Lm - st.pr[V];
          rk = riskOf(st, V);
          if (st.pk[V].length) { const t = st.pk[V][0]; hint = '🦉 다음 재료는 <b>' + (isFruit(t) ? '폭발 열매 ' + fv(t) : ING[t].n) + '</b> — ' + (rk ? '넣으면 터져요!' : '안전해요.'); }
          else if (st.sh[V] > 0) hint = '🐢 등딱지가 다음 폭발 열매를 막아 줘요.';
          else if (room >= 3) hint = '폭발 열매가 나와도 안전해요.';
          else hint = '다음에 <b>폭발 열매 ' + (room + 1) + ' 이상</b>이면 터져요.';
          if (rk === 0 && autoOK(V) && api.canAct(V)) hint += ' 자동으로 넣어요.';
          else if (rk === 0 && st.pot[V].slice(-1) === 'q') hint += ' 🌸 지금 멈추면 +5!';
        }
      } else if (st.ph === 's') hint = '🛒 장보기 시간이에요.';
      else hint = '게임 끝!';
      const row = h('div', { class: 'cd-mrow' }, h('span', { text: '압력', style: { fontWeight: 700 } }), segs, h('span', { class: 'mono', text: d.pr + '/' + Lm }));
      if (rk != null) row.append(h('span', { class: 'cd-risk', style: { color: rk === 0 ? '#4fd6a0' : rk < 0.25 ? '#f2b84b' : '#ff6a4a' }, text: '위험 ' + Math.round(rk * 100) + '%' }));
      const hn = h('div', { class: 'cd-hint' }); hn.innerHTML = hint;
      meter.append(row, hn);
    }
    function renderPot() {
      if (!st) return;
      const V = viewSeat();
      potRow.innerHTML = '';
      const chips = h('div', { class: 'cd-chips' });
      const P = shownPot[V] != null ? shownPot[V] : st.pot[V];
      if (!P.length) chips.append(h('span', { class: 'cd-emp', text: st.ph === 'b' ? '솥이 비었어요 — 재료를 뽑아요' : '' }));
      for (let j = 0; j < P.length; j++) chips.append(chipEl(P[j], j === P.length - 1 ? 'lastc' : ''));
      potRow.append(chips, h('button', { class: 'btn sm cd-bagb', 'aria-label': '주머니 보기', onclick: () => openBag(V) }, '👜 ' + (remaining(st, V).length + st.pk[V].length)));
      requestAnimationFrame(() => { chips.scrollLeft = chips.scrollWidth; });
    }
    function renderBar() {
      bar.innerHTML = '';
      if (!st) return;
      bar.style.display = st.ph === 's' && !busy ? 'none' : 'flex';
      const c = ctlSeat(), V = viewSeat();
      if (st.ph === 'b' && c >= 0) {
        if (V !== c) { bar.append(h('button', { class: 'btn primary', style: { flex: 1 }, text: (multi() ? nm(c) + '의 ' : '내 ') + '솥으로 돌아가기', onclick: () => { manual = -1; render(); } })); return; }
        const who = multi() ? nm(c).slice(0, 5) + ' ' : '';
        const stopB = h('button', { class: 'btn stop cd-stop', onclick: () => { api.sfx('click'); send(c, { d: 0 }); } }, '✋ ' + who + '멈추기');
        const drawB = h('button', { class: 'btn primary draw cd-draw', onclick: () => { api.sfx('click'); bagShake = performance.now() + 300; send(c, { d: 1 }); } }, '👜 ' + who + '뽑기');
        if (autoOK(c)) { drawB.textContent = '안전해요 · 자동으로 뽑는 중'; drawB.disabled = true; stopB.disabled = true; }
        bar.append(stopB, drawB);
        return;
      }
      let t = '';
      if (st.ph === 'x') t = '게임이 끝났어요';
      else if (busy) t = '재료를 넣는 중…';
      else if (api.mySeats().length === 0) t = '구경 중 — 위 카드를 누르면 다른 솥을 봐요';
      else t = '다른 마녀가 고르는 중…';
      bar.append(h('div', { class: 'cd-wait cd-draw', text: t }));
    }
    function renderShop() {
      if (!st || st.ph !== 's' || busy) { shop.classList.remove('show'); return; }
      shop.classList.add('show');
      const c = ctlSeat();
      const key = 's' + st.r + ':' + c;
      if (cart.key !== key) cart = { key, s: '' };
      const sy = shop.scrollTop;
      shop.innerHTML = '';
      shop.append(h('div', { class: 'cd-sh-h' }, h('h3', { text: '🛒 재료 시장' }), h('span', { class: 'cd-note', text: (st.r + 1) + '판 끝 · 다음 ' + (st.r + 2) + '/' + st.R + '판' })));
      if (st.rs) {
        const box = h('div', { class: 'cd-res' });
        const ord = st.rs.map((_, i) => i).sort((a, b) => st.rs[b][2] - st.rs[a][2] || a - b);
        for (const i of ord) {
          const r = st.rs[i];
          const row = h('div', { class: 'rw' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { class: 'n', text: nm(i) }),
            h('span', { class: 'v', text: '거품' + r[0] }), h('span', { class: 'v', style: { color: '#ffe39a' }, text: '★+' + r[2] }), h('span', { class: 'v', text: '💰+' + r[3] }));
          if (r[1]) row.append(h('span', { class: 'tag', style: { color: '#ff8a5a' }, text: '💥절반' }));
          if (r[4]) row.append(h('span', { class: 'tag', text: '👑+1' }));
          if (r[5] > 0) row.append(h('span', { class: 'tag', text: '응원+' + r[5] }));
          box.append(row);
        }
        shop.append(box);
      }
      if (c < 0) {
        shop.append(h('div', { class: 'cd-note', text: '모두 장보는 중: ' + st.bo.map((b, i) => nm(i) + (b != null ? ' ✓' : ' …')).join(' · ') }));
        shop.scrollTop = sy;
        return;
      }
      let cost = 0; for (const t of cart.s) cost += ING[t].p;
      const money = st.co[c];
      shop.append(h('div', { class: 'cd-sh-h' },
        h('span', { style: { fontWeight: 700, fontSize: '14px' }, text: (multi() ? nm(c) + '의 장보기' : '내 장보기') + ' (3개까지)' }),
        h('span', { class: 'cd-coin', text: '💰 ' + (money - cost) + (cost ? ' 남음' : '') })));
      const grid = h('div', { class: 'cd-grid cd-market' });
      for (const t of ['d'].concat(st.mk.split(''), ['T', 'U'])) {
        const I = ING[t], sel = cart.s.indexOf(t) >= 0;
        const ok = sel || canBuy(st, c, cart.s + t);
        let ds = I.t;
        if (t === 'U') ds += ' 지금 ' + st.up[c] + '번.';
        if (t === 'T') ds += ' 남은 열매1: ' + (st.own[c].split('a').length - 1) + '개.';
        grid.append(h('button', { class: 'cd-it' + (sel ? ' sel' : ''), disabled: !ok, onclick: () => {
          cart.s = sel ? cart.s.replace(t, '') : cart.s + t; api.sfx(sel ? 'click' : 'chip'); renderShop();
        } }, h('div', { class: 't1' }, chipEl(t), h('span', { class: 'nmx', text: I.n }), h('span', { class: 'pr', text: '💰' + I.p })), h('div', { class: 'ds', text: ds }), sel ? h('span', { class: 'chk', text: '✓' }) : null));
      }
      shop.append(grid);
      shop.append(h('div', { class: 'cd-foot' },
        h('button', { class: 'btn', onclick: () => openBag(c), 'aria-label': '주머니 보기' }, '👜 주머니'),
        h('button', { class: 'btn primary go cd-done', onclick: () => { api.sfx('chip'); send(c, { b: cart.s }); } }, cart.s ? '다 샀어요 · ' + cart.s.length + '개' : '안 사고 넘어가기')));
      shop.append(h('div', { class: 'cd-note', style: { paddingBottom: '10px' }, text: '남은 금화는 ' + SAVE + '개까지 다음 판으로 저금돼요.' }));
      shop.scrollTop = sy;
    }
    function openBag(i) {
      closeBag();
      if (!st || i < 0) return;
      const own = st.own[i], rem = remaining(st, i) + st.pk[i];
      const cnt = {}, rc = {};
      for (const t of own) cnt[t] = (cnt[t] || 0) + 1;
      for (const t of rem) rc[t] = (rc[t] || 0) + 1;
      let fp = 0; for (const t of own) fp += fv(t);
      const bx = h('div', { class: 'bx' });
      bx.append(h('h3', {}, h('span', { text: '👜 ' + nm(i) + '의 주머니 · ' + own.length + '개' }), h('button', { class: 'btn sm', text: '닫기', onclick: closeBag })));
      bx.append(h('div', { class: 'cd-note', text: '폭발 열매 압력 합 ' + fp + ' · 압력 한도 ' + (LIM0 + st.up[i]) + ' (넘으면 펑!)' + (st.ph === 'b' ? ' · 「남은」은 이번 판 주머니에 남은 개수' : '') }));
      for (const t of Object.keys(cnt).sort()) {
        const I = ING[t];
        bx.append(h('div', { class: 'cd-brow' }, chipEl(t), h('div', { class: 'tx' }, h('b', { text: isFruit(t) ? I.n + ' ' + fv(t) : I.n }), h('div', { text: isFruit(t) ? '거품 ' + fv(t) + ', 압력 +' + fv(t) + '.' : I.t })),
          h('div', { class: 'ct', text: '가진 ' + cnt[t] + (st.ph === 'b' ? '\n남은 ' + (rc[t] || 0) : '') })));
      }
      sheet = h('div', { class: 'cd-sheet', onclick: (e) => { if (e.target === sheet) closeBag(); } }, bx);
      wrap.append(sheet);
    }
    function closeBag() { if (sheet) { sheet.remove(); sheet = null; } }
    function render() { renderStrip(); renderMeter(); renderPot(); renderBar(); renderShop(); }

    /* ---------- 업데이트 ---------- */
    function update(s, prev) {
      const first = !st;
      st = s;
      if (s.r !== lastRound) { if (lastRound >= 0) manual = -1; lastRound = s.r; }
      const pl = prev && prev.last ? prev.last.id : -1;
      if (first || !prev || !s.last || s.last.id === pl) {
        if (!busy) snap();
      } else if (s.last.k === 's' && s.last.id === pl + 1 && prev.r === s.r && prev.ph === 'b') {
        playStep(s, prev);
      } else {
        snap();
        if (s.last.k === 'b') { buyNote = s.last.bo; buyNoteT = performance.now() + 4000; later(renderStrip, 4100 * sp()); }
      }
      render();
    }

    /* ---------- 자동 뽑기 · 그리기 루프 ---------- */
    const stopLoop = U.loop((dt, now) => {
      drawScene(now);
      if (!st || busy || st.ph !== 'b') return;
      const c = ctlSeat();
      if (c < 0 || !autoOK(c) || document.querySelector('.tut-layer') || sheet) { autoKey = ''; return; }
      const k = keyOf(st, c);
      if (autoKey !== k) { autoKey = k; autoAt = now + 350 / sp(); return; }
      if (now >= autoAt) { autoKey = ''; bagShake = now + 300; send(c, { d: 1 }); }
    });

    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      const c = ctlSeat();
      if (id === 'bag') { if (sheet) closeBag(); else openBag(c >= 0 ? c : viewSeat()); return; }
      if (c < 0) return;
      if (st.ph === 'b' && viewSeat() === c && !autoOK(c)) { if (id === 'draw') send(c, { d: 1 }); else if (id === 'stop') send(c, { d: 0 }); }
      else if (st.ph === 's' && id === 'done') send(c, { b: cart.key === 's' + st.r + ':' + c ? cart.s : '' });
    }) : null;

    return {
      update,
      destroy() {
        dead = true; stopLoop(); timers.forEach(clearTimeout); timers.clear();
        if (offIn) offIn();
        if (busy) api.setBusy(false);
        cv.destroy(); wrap.remove(); style.remove();
      },
    };
  }

  /* ---------- 도감 (codex): generated from ING / START / SHOPK / constants above ---------- */
  function cdCodex() {
    const startN = (c) => START.split('').filter((x) => x === c).length;
    const fruitRows = 'abc'.split('').map((c) => ({ icon: '💥', name: ING[c].n + ' ' + ING[c].v, tag: '시작 주머니 ' + startN(c) + '개 · 살 수 없음',
      desc: '거품 ' + ING[c].v + ' · 압력 +' + ING[c].v + '. 압력이 한도(' + LIM0 + ')를 넘으면 솥이 펑!' }));
    const ingRows = Object.keys(ING).filter((c) => ING[c].p).map((c) => {
      const I = ING[c], n0 = startN(c);
      const where = c === 'd' || c === 'T' || c === 'U' ? '시장에 늘' : SHOPK.indexOf(c) >= 0 ? '시장에 가끔' : '';
      return { icon: I.e, name: I.n, tag: '💰' + I.p + (where ? ' · ' + where : '') + (n0 ? ' · 시작 주머니 ' + n0 + '개' : ''), desc: I.t + (c === 'U' ? ' 한도 ' + LIM0 + ' → 최대 ' + (LIM0 + UPMAX) + '.' : '') };
    });
    const track = [];
    for (let st = 0; st * 3 <= TR; st++) {
      const a = st * 3, b = Math.min(TR, a + 2);
      track.push({ icon: '★', name: '거품 ' + (a === b ? a : a + '~' + b), tag: '★' + st + ' · 💰' + (CO(a) === CO(b) ? CO(a) : CO(a) + '~' + CO(b)), desc: '터지면 ★' + Math.floor(st / 2) + ' · 💰' + (Math.floor(CO(a) / 2) === Math.floor(CO(b) / 2) ? Math.floor(CO(a) / 2) : Math.floor(CO(a) / 2) + '~' + Math.floor(CO(b) / 2)) + (b >= TR ? ' · 거품은 ' + TR + '까지' : '') });
    }
    return [
      { h: '재료', p: ['시작 주머니 ' + START.length + '개: ' + [...new Set(START)].map((c) => (ING[c].v ? '열매 ' + ING[c].v : ING[c].n) + '×' + startN(c)).join(' · ') + '.',
        '장날마다 「시장에 가끔」 재료 ' + SHOPK.length + '가지 중 6가지가 나와요. 한 번에 ' + MAXBUY + '개까지, 같은 것은 1개씩. 남은 금화는 ' + SAVE + '개까지 저금돼요.'], rows: fruitRows.concat(ingRows) },
      { h: '점수 길', p: ['판 끝에 거품 높이로 ★ = 거품÷3, 💰 = 2 + 거품÷2 (버림). 솥이 터지면 둘 다 절반(버림).', '👑 으뜸 솥: 안 터진 마녀 중 거품이 가장 높으면 ★ +1. 🍬 별사탕 ★ +1, 🍯 황금 꿀 💰 +4 (안 터졌을 때).'], rows: track },
      { h: '규칙 요약', p: [
        '모두 동시에 「뽑기」나 「멈추기」를 골라요. 뽑으면 주머니에서 재료 1개가 무작위로 솥에 들어가요.',
        '💥 폭발 열매가 올린 압력이 한도 ' + LIM0 + '를 넘으면 솥이 터져요(용 비늘·뚜껑 강화로 한도 ↑).',
        '응원금: ★ 1등보다 4점 뒤질 때마다 다음 장보기 💰 +1 (최대 +6).',
        '마지막 판이 끝나면 남은 금화 5개마다 ★ +1. ★가 같으면 재료가 많은 마녀가 이겨요.',
        '혼자 하기 별 기준: ' + Object.keys(STARS).map((r) => r + '판 ' + STARS[r].join('/')).join(' · ') + '.'] },
    ];
  }
  L.register({
    id: 'cauldron', name: '마녀 솥 재료 뽑기', tag: '욕심 재료 뽑기', cat: '보드',
    blurb: '주머니에서 재료를 하나씩 뽑아 솥에 넣어요. 폭발 열매가 너무 많으면 솥이 펑! 어디서 멈출지 고르고, 번 금화로 새 재료를 사 주머니를 키워요.',
    tint: '#3d2457',
    icon: '<path d="M10 24h36l-3 18a8 8 0 0 1-8 7H21a8 8 0 0 1-8-7z" fill="currentColor"/><rect x="7" y="20" width="42" height="6" rx="3" fill="currentColor"/><circle cx="20" cy="14" r="4" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="31" cy="9" r="3" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="38" cy="15" r="2.5" fill="currentColor"/><path d="M17 49l-3 5M39 49l3 5" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, fixedOrder: true, aiDelay: 700,
    options: [
      { id: 'rounds', label: '판 수', choices: [{ v: 7, label: '7판 (짧게)' }, { v: 9, label: '9판' }, { v: 11, label: '11판 (길게)' }], def: 9 },
    ],
    quick: [
      '모두 동시에 「뽑기」나 「멈추기」를 골라요. 뽑으면 주머니에서 재료 1개가 솥에 들어가 거품이 올라가요.',
      '폭발 열매의 압력이 한도(8)를 넘으면 솥이 펑! 그 판 ★와 금화가 절반이 돼요.',
      '판이 끝나면 번 금화로 새 재료를 사요. 9판 뒤 ★(마력)가 가장 많은 마녀가 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '마녀가 되어 솥에 재료를 넣고 물약을 끓여요. 거품이 높이 오를수록 ★(마력)와 💰(금화)를 많이 받아요.',
        '9판(옵션 7·11판)이 끝났을 때 ★가 가장 많으면 우승. 같으면 재료가 많은 마녀가 이겨요.',
        '혼자 하면 ★로 별 3개를 노려요 (9판 기준 55 / 68 / 80).'] },
      { h: '한 판의 흐름', p: [
        '모두 같은 재료 주머니(13개)로 시작해요. 판이 시작되면 솥은 비어 있어요.',
        '매번 모두가 몰래 「👜 뽑기」나 「✋ 멈추기」를 고르고, 다 고르면 한꺼번에 공개돼요.',
        '뽑으면 주머니에서 재료 1개가 무작위로 나와 솥에 들어가요. 재료의 거품만큼 나선 길을 따라 물약이 차올라요.',
        '멈추면 이번 판은 거기까지. 주머니가 비어도 저절로 멈춰요. 모두 멈추거나 터지면 판이 끝나요.',
        '위험이 0%일 때(열매가 나와도 안 터질 때)는 버튼을 누르지 않아도 자동으로 뽑아요.'] },
      { h: '폭발 열매와 압력', p: [
        '💥 폭발 열매(1·2·3)는 거품도 주지만 그 숫자만큼 압력을 올려요.',
        '압력이 한도 8을 넘으면 솥이 터져요! 그 판은 더 못 넣고, 받을 ★와 💰가 절반(버림)이 돼요.',
        '아래 막대에 「다음에 폭발 열매 2 이상이면 터져요 · 위험 25%」처럼 지금 뽑으면 터질 확률이 나와요.'] },
      { h: '점수', p: [
        '판이 끝나면 거품 높이로 ★ = 거품÷3(버림), 💰 = 2 + 거품÷2(버림)를 받아요. 나선 길의 ★ 숫자를 보면 쉬워요.',
        '👑 으뜸 솥: 안 터진 마녀 중 거품이 가장 높으면 ★ +1 (같으면 모두).',
        '응원금: ★ 1등보다 4점 뒤질 때마다 다음 장보기에서 💰 +1 (최대 +6). 뒤처져도 따라잡을 수 있어요.',
        '마지막 판이 끝나면 남은 금화 5개마다 ★ +1.'] },
      { h: '장보기 (판 사이)', p: [
        '시장에는 달빛 이끼, 솎아내기, 뚜껑 강화가 늘 있고, 특별 재료 13가지 중 6가지가 판마다 바뀌어 나와요.',
        '한 번에 3개까지, 같은 것은 1개씩 살 수 있어요. 산 재료는 주머니에 들어가 다음 판부터 나와요.',
        '남은 금화는 5개까지 다음 판으로 저금돼요.'] },
      { h: '재료 효과', p: [
        '🌿 달빛 이끼: 거품 1 · 🥬 큰 이끼 덩이: 거품 3',
        '❄️ 얼음 수정: 압력 −1 · 🐢 거북 등딱지: 다음 폭발 열매 1개의 압력을 막음(거품은 그대로)',
        '🐸 바꿔치기 두꺼비: 솥 속 가장 큰 폭발 열매를 주머니로 돌려보냄(압력↓) · 🐉 용 비늘: 이번 판 한도 +1',
        '🥜 쌍둥이 땅콩: 솥에 땅콩이 이미 있으면 +2 · 🐚 메아리 조개: 바로 앞 재료의 거품만큼 더',
        '🍄 번개 버섯: 솥 속 폭발 열매 수만큼 더(최대 +4) · ✨ 꼬리별 가루: 열매 아닌 재료 1개를 바로 더 넣음',
        '🦉 부엉이 깃털: 다음 재료 2개를 미리 보여 줌 · 🌸 마무리 꽃잎: 멈출 때 맨 위에 있으면 거품 +5',
        '🍯 황금 꿀: 안 터지면 금화 +4 · 🍬 별사탕: 안 터지면 ★ +1',
        '✂️ 열매 솎아내기: 폭발 열매(1) 1개를 버림 · 🔩 솥 뚜껑 강화: 한도 영원히 +1(2번까지)'] },
      { h: '예시', p: [
        '압력 7/8. 주머니에 12개가 남았고 그중 폭발 열매 3이 1개, 2가 2개예요.',
        '→ 2 이상이 나오면 터지니 위험 3/12 = 25%. 거품 18이면 지금 멈춰도 ★6 💰11!',
        '→ 한 번 더 뽑았더니 🐢 거북 등딱지! 다음 폭발 열매는 막아 주니 이번엔 위험 0%.'] },
      { h: '조작', p: [
        '「👜 뽑기」·「✋ 멈추기」 버튼. 위 카드를 누르면 다른 마녀의 솥을 볼 수 있어요. 「👜」 버튼은 주머니 속 재료 목록.',
        'PC: Space 뽑기, S 멈추기, B 주머니, Enter 장보기 끝.',
        '한 폰으로 여럿이 하면 이름이 적힌 버튼이 차례로 떠요. 주머니는 모두에게 공개라 가림막은 없어요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 어려움은 위험 %를 정확히 계산하고, 장보기 때 솥을 미리 끓여 보며 골라요.'] },
    ],
    tutorial: [
      { sel: '.cd-cv', text: '가운데가 내 솥이에요. 재료를 넣으면 거품만큼 물약이 나선 길을 따라 올라가요. 길의 ★ 숫자가 받을 마력이에요.' },
      { sel: '.cd-meter', text: '압력 막대예요. 💥 폭발 열매가 압력을 올리고, 한도를 넘으면 솥이 펑! 오른쪽 「위험 %」는 지금 뽑으면 터질 확률이에요.' },
      { sel: '.cd-bar', text: '「뽑기」로 재료를 하나 더 넣거나, 「멈추기」로 이번 판을 끝내요. 모두 동시에 골라요. 위험 0%일 땐 자동으로 뽑아요.' },
      { sel: '.cd-pot', text: '솥에 들어간 재료 목록이에요. 👜를 누르면 주머니에 남은 재료를 볼 수 있어요.' },
      { text: '판이 끝나면 번 금화로 시장에서 새 재료를 사 주머니를 키워요. 등딱지·얼음은 안전하게, 큰 이끼·버섯은 거품을 많이!' },
    ],
    controls: [
      { id: 'draw', label: '뽑기', keys: ['Space', 'KeyD'], pad: ['a'] },
      { id: 'stop', label: '멈추기', keys: ['KeyS'], pad: ['b'] },
      { id: 'bag', label: '주머니 보기', keys: ['KeyB'], pad: ['y'] },
      { id: 'done', label: '장보기 끝', keys: ['Enter'], pad: ['start'] },
    ],
    codex: cdCodex(),
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { ING, remaining, riskOf, place, PT, CO, STARS, shopPlan, wantDraw, canBuy, lim },
  });
})();
