/* 해적선 포격전 — 2–4인 턴제 포격전(옆에서 본 바다).
   내 차례: 배를 조금 움직이고(선택), 화면을 뒤로 끌었다 놓아 대포를 쏜다. 매 턴 바람이 바뀐다.
   결정적 고정 스텝 탄도: apply가 포탄을 끝까지 시뮬레이션해 피해를 정하고 last={id, px, al, hp0, sh}를 남긴다.
   뷰는 같은 Ball 시뮬로 그대로 재생한다(시뮬 안에서는 + − × ÷ √ 만 사용, Math.random 없음). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= rules & ballistics (pure, node-testable) ======================= */
  const W = 600;                       // sea width in units; sea level y = 0, up = negative y
  const GR = 300, DT = 1 / 100, VMAX = 440, WK = 5, MAXN = 1200;
  const MOVE = 45, RMAX = 15, HP0 = 150, EDGE = 40, GAP = 70, ISLPAD = 36;
  const AMIN = 3 * Math.PI / 180, AMAX = Math.PI - AMIN;
  const PIV = 14, PIVY = -21, BARREL = 14;  // cannon pivot (local, bow side) and muzzle length
  const SPREAD = 0.07;                 // 산탄: ±4°
  const WEP = [
    { nm: '일반탄', mx: 30, R: 48, sp: 1, wf: 1, r: 3.2 },
    { nm: '산탄', mx: 13, R: 30, sp: 1, wf: 1.15, r: 2.4 },
    { nm: '무거운 포탄', mx: 48, R: 62, sp: 0.88, wf: 0.45, r: 4.4 },
  ];
  const AMMO0 = [2, 1];
  const PVT = [0, 0.5, 1.2];          // 조준선: 끔 / 짧게 / 길게 (seconds of flight shown)                // 산탄, 무거운 포탄
  /* islands: [cx, half width, height, type 0 = green dome / 1 = rock spire]; layouts per player count: [ships, islands] */
  const MAPS = [
    { nm: '잔잔한 만', wm: 3, wave: 2,
      L: { 2: [[90, 510], [[300, 70, 95, 0]]],
        3: [[45, 300, 555], [[175, 45, 70, 0], [425, 45, 70, 0]]],
        4: [[45, 215, 385, 555], [[300, 44, 85, 0], [130, 14, 40, 1], [470, 14, 40, 1]]] } },
    { nm: '암초 해협', wm: 6, wave: 3,
      L: { 2: [[70, 530], [[200, 16, 110, 1], [300, 22, 60, 1], [400, 16, 120, 1]]],
        3: [[45, 300, 555], [[150, 18, 120, 1], [222, 12, 55, 1], [378, 12, 60, 1], [450, 18, 115, 1]]],
        4: [[45, 215, 385, 555], [[128, 16, 115, 1], [300, 20, 130, 1], [472, 16, 105, 1]]] } },
    { nm: '폭풍의 바다', wm: 11, wave: 5,
      L: { 2: [[80, 520], [[300, 75, 55, 0], [300, 10, 100, 1]]],
        3: [[45, 300, 555], [[172, 40, 60, 0], [428, 40, 60, 0]]],
        4: [[45, 215, 385, 555], [[130, 30, 55, 0], [300, 40, 70, 0], [470, 30, 55, 0]]] } },
    { nm: '노을 군도', wm: 7, wave: 2.5,
      L: { 2: [[60, 540], [[170, 40, 60, 0], [300, 45, 120, 0], [430, 40, 60, 0]]],
        3: [[45, 300, 555], [[160, 50, 100, 0], [440, 50, 100, 0]]],
        4: [[45, 215, 385, 555], [[128, 34, 105, 0], [300, 24, 60, 1], [472, 34, 105, 0]]] } },
  ];
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const islOf = (s) => MAPS[s.m].L[s.n][1];

  function landH(isl, x) {
    let h = 0;
    for (let i = 0; i < isl.length; i++) {
      const f = isl[i], u = (x - f[0]) / f[1];
      if (u <= -1 || u >= 1) continue;
      const q = u * u, v = f[3] ? f[2] * (1 - q * q) : f[2] * (1 - q);
      if (v > h) h = v;
    }
    return h;
  }
  /* one cannonball. res: 'w' water, 'l' land, 's' ship (hit = seat), 'o' gone */
  function Ball(isl, px, al, me, b, wa) {
    this.isl = isl; this.px = px; this.al = al; this.me = me;
    this.x = b[0]; this.y = b[1]; this.vx = b[2]; this.vy = b[3]; this.wa = wa;
    this.n = 0; this.done = false; this.res = ''; this.hit = -1; this.out = false;
  }
  Ball.prototype.step = function () {
    if (this.done) return;
    this.vx += this.wa * DT; this.vy += GR * DT;
    this.x += this.vx * DT; this.y += this.vy * DT; this.n++;
    const x = this.x, y = this.y;
    let inMe = false;
    for (let i = 0; i < this.px.length; i++) {
      if (!this.al[i]) continue;
      const dx = x - this.px[i], adx = dx < 0 ? -dx : dx;
      if (!((adx < 31 && y > -20 && y < 8) || (adx < 17 && y > -66 && y <= -20))) continue;
      if (i === this.me && !this.out) { inMe = true; continue; } // still leaving our own deck
      this.done = true; this.res = 's'; this.hit = i; return;
    }
    if (!inMe) this.out = true;
    const h = landH(this.isl, x);
    if (h > 0 && y > -h) { this.done = true; this.res = 'l'; return; }
    if (y >= 0) { this.y = 0; this.done = true; this.res = 'w'; return; }
    if (x < -160 || x > W + 160 || this.n > MAXN) { this.done = true; this.res = 'o'; }
  };
  function blast(w, x, y, hit, px, al) {
    const wp = WEP[w], out = [];
    for (let i = 0; i < px.length; i++) {
      if (!al[i]) { out.push(0); continue; }
      if (i === hit) { out.push(wp.mx); continue; }
      const dx = x - px[i], dy = y + 14, d = Math.sqrt(dx * dx + dy * dy);
      out.push(d < wp.R ? Math.round(wp.mx * (1 - d / wp.R)) : 0);
    }
    return out;
  }
  function makeShot(x, a, p, w, wd) {
    const wp = WEP[w], f = Math.cos(a) >= 0 ? 1 : -1, v = p * VMAX * wp.sp;
    const bx = x + f * PIV, by = PIVY;
    const angs = w === 1 ? [a - SPREAD, a, a + SPREAD] : [a];
    return { w, wa: r2(wd * WK * wp.wf), b: angs.map((q) => [r1(bx + Math.cos(q) * BARREL), r1(by - Math.sin(q) * BARREL), r1(Math.cos(q) * v), r1(-Math.sin(q) * v)]) };
  }
  function runShot(isl, px, al, me, shot) {
    const balls = [], dm = px.map(() => 0);
    for (const b of shot.b) {
      const s = new Ball(isl, px, al, me, b, shot.wa);
      while (!s.done) s.step();
      if (s.res !== 'o') { const d = blast(shot.w, s.x, s.y, s.hit, px, al); for (let i = 0; i < dm.length; i++) dm[i] += d[i]; }
      balls.push(s);
    }
    return { balls, dm };
  }
  function okX(s, seat, x, isl) {
    if (x < EDGE || x > W - EDGE) return false;
    for (const f of isl) if (Math.abs(x - f[0]) < f[1] + ISLPAD) return false;
    for (let i = 0; i < s.n; i++) if (i !== seat && s.hp[i] > 0 && Math.abs(x - s.x[i]) < GAP) return false;
    return true;
  }
  /* how far this ship may sail this turn (it cannot pass islands or other ships) */
  function moveRange(s, seat) {
    const isl = islOf(s), x0 = s.x[seat];
    let lo = x0, hi = x0;
    while (lo - 1 >= x0 - MOVE && okX(s, seat, lo - 1, isl)) lo -= 1;
    while (hi + 1 <= x0 + MOVE && okX(s, seat, hi + 1, isl)) hi += 1;
    return [lo, hi];
  }
  const randWind = (m) => { const wm = MAPS[m].wm; return Math.floor(Math.random() * (2 * wm + 1)) - wm; };

  /* ---------- state ---------- */
  function init(players, opts) {
    const n = U.clamp(players.length, 2, 4);
    const o = opts || {};
    let m = o.map != null && o.map !== 'r' ? +o.map : U.rand(MAPS.length);
    if (!(m >= 0 && m < MAPS.length)) m = 0;
    const pv = o.aim === 'off' ? 0 : o.aim === 'l' ? 2 : 1;
    const slots = U.shuffle(MAPS[m].L[n][0].slice());
    const x = slots.slice(0, n);
    return { n, m, nm: players.slice(0, n).map((p) => String(p.name || '').slice(0, 10)), hp: x.map(() => HP0), x,
      ag: x.map((v) => (v < W / 2 ? 45 : 135)), am: x.map(() => AMMO0.slice()), cur: 0, rd: 1, wd: randWind(m), seq: 0, ov: 0, wn: null, last: null, pv };
  }
  function actor(s) { return s.ov ? null : s.cur; }
  function apply(s, seat, a) {
    if (actor(s) !== seat) throw new Error('not your turn');
    if (!a || a.type !== 'fire') throw new Error('bad action');
    let ang = +a.a, p = +a.p;
    const w = a.w | 0;
    if (!isFinite(ang) || !isFinite(p)) throw new Error('bad shot');
    if (w < 0 || w > 2) throw new Error('bad weapon');
    if (w > 0 && !(s.am[seat][w - 1] > 0)) throw new Error('no ammo');
    const rg = moveRange(s, seat);
    let x1 = +a.x;
    if (!isFinite(x1)) x1 = s.x[seat];
    x1 = r1(clamp(x1, rg[0], rg[1]));
    ang = clamp(ang, AMIN, AMAX); p = clamp(p, 0.1, 1);
    const x0 = s.x[seat];
    s.x[seat] = x1;
    const px = s.x.slice(), al = s.hp.map((h) => (h > 0 ? 1 : 0)), hp0 = s.hp.slice();
    const shot = makeShot(x1, ang, p, w, s.wd);
    const r = runShot(islOf(s), px, al, seat, shot);
    for (let i = 0; i < s.n; i++) if (al[i]) s.hp[i] = Math.max(0, s.hp[i] - r.dm[i]);
    if (w) s.am[seat][w - 1]--;
    s.ag[seat] = Math.round(ang * 180 / Math.PI);
    s.seq++;
    s.last = { id: s.seq, s: seat, x0, x1, px, al, hp0, sh: shot, wd: s.wd };
    const alive = [];
    for (let i = 0; i < s.n; i++) if (s.hp[i] > 0) alive.push(i);
    if (alive.length <= 1) {
      s.ov = 1;
      s.wn = alive.length ? alive : al.map((v, i) => (v ? i : -1)).filter((i) => i >= 0); // everyone left sank together → shared
      return s;
    }
    let nx = seat;
    do nx = (nx + 1) % s.n; while (s.hp[nx] <= 0);
    if (nx <= seat) s.rd++;
    if (s.rd > RMAX) {
      s.rd = RMAX; s.ov = 2;
      const best = Math.max(...alive.map((i) => s.hp[i]));
      s.wn = alive.filter((i) => s.hp[i] === best);
      return s;
    }
    s.cur = nx; s.wd = randWind(s.m);
    return s;
  }
  function result(s) {
    if (!s.ov) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const ord = s.hp.map((_, i) => i).sort((a, b) => s.hp[b] - s.hp[a] || a - b);
    const lines = ord.map((i) => nm(i) + ' · ' + (s.hp[i] > 0 ? 'HP ' + s.hp[i] : '침몰'));
    const head = s.ov === 2 ? RMAX + '턴이 끝나 남은 HP로 정했어요' : s.wn.length > 1 ? '남은 배가 함께 가라앉았어요' : '마지막까지 떠 있는 배!';
    return { winners: s.wn.slice(), title: s.wn.length > 1 ? '공동 우승' : undefined, text: head + '\n' + lines.join('\n') };
  }

  /* ---------- AI ---------- */
  /* 쉬움: 한 배만 노리고 거친 탐색·큰 손떨림·이동 거의 안 함 / 보통 / 어려움: 이동까지 탐색, 약한 배 마무리, 손떨림 적음 */
  const ALV = {
    1: { na: 0.16, np: 0.17, da: 7, dp: 0.07, ref: 1, mv: 0, ms: 60, kill: 10, weak: 0, mar: 0 },
    2: { na: 0.1, np: 0.11, da: 5, dp: 0.05, ref: 4, mv: 1, ms: 120, kill: 20, weak: 0.3, mar: 5 },
    3: { na: 0.05, np: 0.055, da: 4, dp: 0.04, ref: 6, mv: 2, ms: 150, kill: 35, weak: 0.6, mar: 8 },
  };
  function aiScore(c, x1, a, p, w) {
    const s = c.s, px = s.x.slice(); px[c.seat] = x1;
    const r = runShot(c.isl, px, c.al, c.seat, makeShot(x1, a, p, w, s.wd));
    let v = 0, near = 400;
    for (let i = 0; i < s.n; i++) {
      if (!c.al[i]) continue;
      const d = r.dm[i];
      if (i === c.seat) { v -= d * 1.6; if (d >= s.hp[i]) v -= 120; continue; }
      const f = c.focus >= 0 && c.focus !== i ? 0.3 : 1;
      v += Math.min(d, s.hp[i]) * f * (1 + c.K.weak * (1 - s.hp[i] / HP0));
      if (d >= s.hp[i]) v += c.K.kill * f;
      if (f === 1) for (const b of r.balls) if (b.res !== 'o') { const e = Math.abs(b.x - px[i]); if (e < near) near = e; }
    }
    return v - near * 0.02;
  }
  function aiRobust(c, q) {
    const K = c.K;
    return (q.v * 2 + aiScore(c, q.x, q.a + K.na, q.p, q.w) + aiScore(c, q.x, q.a - K.na, q.p, q.w) +
      aiScore(c, q.x, q.a, clamp(q.p * (1 + K.np), 0.1, 1), q.w) + aiScore(c, q.x, q.a, clamp(q.p * (1 - K.np), 0.1, 1), q.w)) / 6;
  }
  function aiClimb(c, q, t0, lim) {
    let cur = q, sa = 0.02, sp = 0.012;
    for (let it = 0; it < 6 && Date.now() - t0 < lim; it++) {
      let imp = false;
      for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]) {
        const a = clamp(cur.a + d[0] * sa, AMIN, AMAX), p = clamp(cur.p + d[1] * sp, 0.1, 1);
        const v = aiScore(c, cur.x, a, p, cur.w);
        if (v > cur.v) { cur = { x: cur.x, a, p, w: cur.w, v }; imp = true; }
      }
      if (!imp) { sa /= 2; sp /= 2; }
    }
    return cur;
  }
  function ai(s, seat, lv) {
    const K = ALV[lv] || ALV[2], t0 = Date.now();
    const c = { s, seat, K, isl: islOf(s), al: s.hp.map((h) => (h > 0 ? 1 : 0)), focus: -1 };
    const en = []; for (let i = 0; i < s.n; i++) if (i !== seat && s.hp[i] > 0) en.push(i);
    if (lv === 1 && en.length) c.focus = en[U.rand(en.length)];
    const rg = moveRange(s, seat), x0 = s.x[seat];
    let poss = [x0];
    if (K.mv >= 1) poss.push(rg[0], rg[1]);
    if (K.mv >= 2) poss.push((rg[0] + x0) / 2, (rg[1] + x0) / 2);
    if (lv === 1 && Math.random() < 0.3) poss = [rg[0] + Math.random() * (rg[1] - rg[0])];
    poss = poss.map(r1).filter((x, i, arr) => arr.findIndex((y) => Math.abs(y - x) < 4) === i);
    const cand = [];
    outer: for (const x1 of poss) {
      for (let dg = 8; dg <= 172; dg += K.da) {
        const a = dg * Math.PI / 180;
        for (let p = 0.16; p <= 1.0001; p += K.dp) cand.push({ x: x1, a, p: Math.min(1, p), w: 0, v: aiScore(c, x1, a, Math.min(1, p), 0) });
        if (Date.now() - t0 > K.ms && cand.length > 200) break outer;
      }
    }
    cand.sort((A, B) => B.v - A.v);
    let best = null;
    const tops = [];
    for (const q of cand) { if (tops.length >= K.ref) break; if (!tops.some((t) => Math.abs(t.a - q.a) < 0.09 && Math.abs(t.p - q.p) < 0.08 && t.x === q.x)) tops.push(q); }
    for (const q of tops) {
      const r = lv === 1 ? q : aiClimb(c, q, t0, K.ms + 60);
      r.rv = lv === 1 ? r.v : aiRobust(c, r);
      if (!best || r.rv > best.rv) best = r;
    }
    if (!best) best = { x: x0, a: Math.PI / 4, p: 0.6, w: 0, v: 0, rv: 0 };
    // special shells
    const last = s.rd >= RMAX;
    for (const w of [2, 1]) {
      if (!(s.am[seat][w - 1] > 0)) continue;
      const p0 = w === 2 ? clamp(best.p / WEP[2].sp, 0.1, 1) : best.p;
      if (lv === 1) { if (Math.random() < 0.25) { best = { x: best.x, a: best.a, p: p0, w, v: 0, rv: 0 }; break; } continue; }
      if (Date.now() - t0 > K.ms + 110) break;
      let q = { x: best.x, a: best.a, p: p0, w, v: aiScore(c, best.x, best.a, p0, w) };
      q = aiClimb(c, q, t0, K.ms + 130);
      q.rv = aiRobust(c, q);
      if (q.rv > best.rv + (last ? 0 : K.mar) || (q.v > best.v && q.v >= 60)) best = q;
    }
    const g = () => (Math.random() + Math.random() + Math.random() - 1.5) * 1.15;
    const a = clamp(best.a + g() * K.na, AMIN, AMAX), p = clamp(best.p * (1 + g() * K.np), 0.1, 1);
    return { type: 'fire', x: best.x, a, p, w: best.w };
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 1200 : lv === 3 ? 800 : 950; }

  /* ======================= view ======================= */
  const LOOK = [
    { sky: [[0, '#4f9bd0'], [0.6, '#9fd0ea'], [1, '#e4f2ef']], sea: ['#2a8fb2', '#13597c', '#082640'], sun: [0.8, 0.2, '#fff4cf', 22], cloud: 'rgba(255,255,255,.88)', nc: 5,
      far: 'rgba(70,120,150,.45)', foam: 'rgba(255,255,255,.7)', grass: ['#6cc04f', '#2f7d3a'], sand: '#e2c27f', rock: ['#9aa0a8', '#535863'], sail: '#f1e6cc' },
    { sky: [[0, '#6f879c'], [0.65, '#aebdc9'], [1, '#d9e0e2']], sea: ['#3a8086', '#1b5157', '#0a272c'], sun: null, cloud: 'rgba(236,241,244,.82)', nc: 8,
      far: 'rgba(70,90,100,.45)', foam: 'rgba(235,245,245,.65)', grass: ['#5fa257', '#2c6236'], sand: '#cdb68a', rock: ['#8d939b', '#474c55'], sail: '#ece3cf' },
    { sky: [[0, '#151a27'], [0.55, '#2b3348'], [1, '#4b566e']], sea: ['#2a4a5d', '#142d3e', '#060f18'], sun: null, cloud: 'rgba(48,54,72,.92)', nc: 9,
      far: 'rgba(20,28,40,.6)', foam: 'rgba(210,225,235,.6)', grass: ['#4e7d48', '#24452a'], sand: '#a99573', rock: ['#6c727c', '#353a44'], sail: '#d9d2c2', rain: 1 },
    { sky: [[0, '#2a2150'], [0.45, '#7d4572'], [0.8, '#ee8549'], [1, '#ffd07a']], sea: ['#7b5884', '#3a2b55', '#14122a'], sun: [0.66, 0.96, '#ffe2a0', 40], cloud: 'rgba(255,180,150,.5)', nc: 4,
      far: 'rgba(70,40,80,.6)', foam: 'rgba(255,215,180,.6)', grass: ['#6f9a48', '#36552d'], sand: '#e0a86a', rock: ['#8e7a86', '#4a3b4c'], sail: '#f4dcc0' },
  ];
  const hash = (i, j) => { let h = Math.imul(i + 1, 0x9E3779B1) ^ Math.imul(j + 7, 0x85EBCA77); h ^= h >>> 15; h = Math.imul(h, 0x2C1B3C6D); h ^= h >>> 12; return (h >>> 0) / 4294967296; };

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let TOPH = 56, BOTH = 108, land = false;   // land: wide (landscape) layout — HUD on top, controls in the bottom corners
    let st = null, V = null, bgL = null, islL = null, layerKey = '';
    let anim = null, parts = [], shake = 0, flash = 0, flashT = 3, safeT = 0;
    let drag = null, mvx = 0, mvDir = 0, rng = [0, 0], selW = 0, turnKey = '', sentAt = 0, hpShow = null;
    let prevPts = [], lastAim = {}, frameOdd = false, lastMoveLbl = '';
    const top = L.h('div', { class: 'hud top', style: { gap: '5px', padding: '6px 8px', flexWrap: 'nowrap' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '8px 10px', flexDirection: 'column', alignItems: 'stretch', gap: '6px' } });
    root.append(top, bot);
    const col = (i) => (api.players[i] ? api.players[i].color : '#ccc');
    const pname = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const look = () => LOOK[st ? st.m : 0];

    /* ---- geometry & cached layers ---- */
    function layout() {
      const w = cv.w, h = cv.h, wasLand = land;
      land = w > h * 1.25;
      if (land) {
        // landscape: one slim HUD row + info pills on top, the sea fills the width, a strip of water at the bottom
        // holds the thumb controls (◀ ▶ at the left corner, shells at the right corner)
        TOPH = 40; BOTH = 0;
        const sy = Math.round(h - U.clamp(h * 0.22, 78, 110));
        const k = Math.min(w / (W + 40), Math.max(0.3, (sy - TOPH - 34) / 122));
        V = { k, ox: (w - W * k) / 2, sy, w, h };
      } else {
        TOPH = 56; BOTH = 108;
        const k = Math.min(w / (W + 40), Math.max(0.3, (h - TOPH - BOTH - 40) / 360));
        const depth = U.clamp(h * 0.2 - 20, 34, 170);
        V = { k, ox: (w - W * k) / 2, sy: Math.round(h - BOTH - depth), w, h };
      }
      layerKey = '';
      if (wasLand !== land) { topKey = ''; botKey = ''; if (st) { renderTop(); renderBot(); } }
    }
    const SX = (x) => V.ox + x * V.k, SY = (y) => V.sy + y * V.k;
    function mkLayer() {
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(V.w * cv.dpr)); c.height = Math.max(1, Math.round(V.h * cv.dpr));
      const g = c.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      return { c, g };
    }
    function buildLayers() {
      const key = [V.w, V.h, cv.dpr, st.m, st.n].join('|');
      if (key === layerKey) return;
      layerKey = key;
      const lk = look(), k = V.k;
      // sky + sea body
      bgL = mkLayer(); let g = bgL.g;
      const sg = g.createLinearGradient(0, 0, 0, V.sy);
      lk.sky.forEach((s) => sg.addColorStop(s[0], s[1]));
      g.fillStyle = sg; g.fillRect(0, 0, V.w, V.sy + 2);
      if (lk.sun) {
        const sx = V.w * lk.sun[0], sy = lk.sun[1] > 0.9 ? V.sy - 6 : TOPH + (V.sy - TOPH) * lk.sun[1], r = lk.sun[3] * Math.max(0.8, k * 1.4);
        const halo = g.createRadialGradient(sx, sy, r * 0.5, sx, sy, r * 4);
        halo.addColorStop(0, 'rgba(255,240,200,.55)'); halo.addColorStop(1, 'rgba(255,240,200,0)');
        g.fillStyle = halo; g.fillRect(sx - r * 4, sy - r * 4, r * 8, r * 8);
        g.fillStyle = lk.sun[2]; g.beginPath(); g.arc(sx, sy, r, 0, 7); g.fill();
      }
      if (st.m === 2) { // storm: faint moon behind clouds
        g.fillStyle = 'rgba(220,226,240,.25)'; g.beginPath(); g.arc(V.w * 0.22, TOPH + 70, 18, 0, 7); g.fill();
      }
      for (let i = 0; i < lk.nc; i++) {
        const cx = hash(i, st.m) * V.w, cy = TOPH + 40 + hash(i, 9) * Math.max(40, (V.sy - TOPH) * 0.45), s = (0.7 + hash(i, 3) * 0.8) * Math.max(0.8, k * 1.3);
        g.fillStyle = lk.cloud;
        g.beginPath();
        for (let j = 0; j < 5; j++) { const ox = (j - 2) * 14 * s, oy = -Math.abs(j - 2) * -3 * s - (j % 2) * 6 * s; g.moveTo(cx + ox + 13 * s, cy + oy); g.arc(cx + ox, cy + oy, (13 - Math.abs(j - 2) * 2) * s, 0, 7); }
        g.fill();
        g.fillStyle = 'rgba(0,0,0,.06)'; g.fillRect(cx - 32 * s, cy + 5 * s, 64 * s, 3 * s);
      }
      // far islands on the horizon
      g.fillStyle = lk.far;
      for (let i = 0; i < 3; i++) {
        const cx = (0.15 + i * 0.36 + hash(i, 4) * 0.1) * V.w, hw = (40 + hash(i, 5) * 50) * k, hh = (14 + hash(i, 6) * 18) * k;
        g.beginPath(); g.moveTo(cx - hw, V.sy + 1);
        g.quadraticCurveTo(cx - hw * 0.3, V.sy - hh * 1.2, cx, V.sy - hh); g.quadraticCurveTo(cx + hw * 0.4, V.sy - hh * 0.9, cx + hw, V.sy + 1); g.fill();
      }
      const wg = g.createLinearGradient(0, V.sy, 0, V.h);
      wg.addColorStop(0, lk.sea[0]); wg.addColorStop(0.35, lk.sea[1]); wg.addColorStop(1, lk.sea[2]);
      g.fillStyle = wg; g.fillRect(0, V.sy, V.w, V.h - V.sy);
      if (lk.sun && lk.sun[1] > 0.9) { // sunset glitter path
        g.fillStyle = 'rgba(255,214,150,.22)';
        for (let i = 0; i < 18; i++) { const y = V.sy + 6 + i * 5, ww = (30 - i) * 1.4 * (0.6 + hash(i, 2) * 0.8); g.fillRect(V.w * lk.sun[0] - ww / 2 + (hash(i, 8) - 0.5) * 20, y, ww, 2); }
      }
      // light rays under water
      g.fillStyle = 'rgba(255,255,255,.035)';
      for (let i = 0; i < 6; i++) { const x = hash(i, 11) * V.w; g.beginPath(); g.moveTo(x, V.sy); g.lineTo(x + 30, V.sy); g.lineTo(x - 30, V.h); g.lineTo(x - 70, V.h); g.fill(); }
      // islands
      islL = mkLayer(); g = islL.g;
      const isl = islOf(st);
      for (const f of isl) drawIsland(g, f, lk);
      for (const f of isl) if (!f[3] && f[2] >= 60) drawPalm(g, f, lk);
      if (st.m === 1) { // a small lighthouse on the tallest rock
        let t = isl[0]; for (const f of isl) if (f[2] > t[2]) t = f;
        drawLighthouse(g, t[0], -t[2]);
      }
    }
    function islPath(g, f) {
      g.beginPath(); g.moveTo(SX(f[0] - f[1]), SY(8));
      for (let x = -f[1]; x <= f[1] + 0.01; x += Math.max(1.5, f[1] / 24)) {
        const u = x / f[1], q = u * u, h = f[3] ? f[2] * (1 - q * q) : f[2] * (1 - q);
        g.lineTo(SX(f[0] + x), SY(-h));
      }
      g.lineTo(SX(f[0] + f[1]), SY(8)); g.closePath();
    }
    function drawIsland(g, f, lk) {
      const k = V.k;
      g.save();
      islPath(g, f);
      if (f[3]) {
        const rg = g.createLinearGradient(SX(f[0] - f[1]), 0, SX(f[0] + f[1]), 0);
        rg.addColorStop(0, lk.rock[0]); rg.addColorStop(1, lk.rock[1]);
        g.fillStyle = rg; g.fill();
        g.clip();
        g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 1.2;
        for (let i = 0; i < 6; i++) {
          const y = -f[2] * (0.12 + i * 0.14), x = f[0] + (hash(i, f[0]) - 0.5) * f[1] * 1.2, d = (hash(i, f[0] + 3) - 0.5) * 8;
          g.beginPath(); g.moveTo(SX(x), SY(y)); g.lineTo(SX(x + d), SY(y + 5)); g.lineTo(SX(x + d * 0.4), SY(y + 10)); g.stroke();
        }
        g.fillStyle = 'rgba(0,0,0,.14)'; g.fillRect(SX(f[0] + f[1] * 0.25), SY(-f[2] - 2), f[1] * 0.75 * k, (f[2] + 10) * k);
        g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(SX(f[0] - f[1]), SY(-f[2] - 2), f[1] * 0.45 * k, f[2] * k);
        g.fillStyle = 'rgba(30,60,40,.35)'; g.fillRect(SX(f[0] - f[1]), SY(-6), f[1] * 2 * k, 14 * k); // weed line
      } else {
        g.fillStyle = lk.sand; g.fill();
        g.clip();
        const gg = g.createLinearGradient(0, SY(-f[2]), 0, SY(-8));
        gg.addColorStop(0, lk.grass[0]); gg.addColorStop(1, lk.grass[1]);
        g.fillStyle = gg;
        g.beginPath(); g.moveTo(SX(f[0] - f[1] - 2), SY(-f[2] - 4)); g.lineTo(SX(f[0] + f[1] + 2), SY(-f[2] - 4));
        for (let x = f[1] + 2; x >= -f[1] - 2; x -= 5) g.lineTo(SX(f[0] + x), SY(-11 + 2.5 * Math.sin(x * 0.7)));
        g.closePath(); g.fill();
        // tufts
        g.fillStyle = 'rgba(255,255,255,.12)';
        for (let i = 0; i < 6; i++) { const x = f[0] + (hash(i, f[0] + 1) - 0.5) * f[1] * 1.2, h = landH([f], x); g.beginPath(); g.ellipse(SX(x), SY(-h * 0.7), 5 * k, 2.5 * k, 0, 0, 7); g.fill(); }
        g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(SX(f[0]), SY(-f[2] - 2), f[1] * k, (f[2] + 10) * k); // shade side
      }
      g.restore();
    }
    function drawPalm(g, f, lk) {
      const k = V.k;
      const xs = f[1] > 50 ? [f[0] - f[1] * 0.18, f[0] + f[1] * 0.12] : [f[0] - f[1] * 0.08];
      xs.forEach((x, j) => {
        const by = -landH([f], x) + 2, hgt = 30 + j * 6, lean = j ? 7 : -6;
        g.strokeStyle = '#7a5532'; g.lineWidth = 3 * k + 0.6; g.lineCap = 'round';
        g.beginPath(); g.moveTo(SX(x), SY(by)); g.quadraticCurveTo(SX(x + lean * 0.2), SY(by - hgt * 0.6), SX(x + lean), SY(by - hgt)); g.stroke();
        g.fillStyle = lk.grass[1];
        for (let i = 0; i < 6; i++) {
          const a = -Math.PI / 2 + (i - 2.5) * 0.55, lx = x + lean, ly = by - hgt;
          g.beginPath(); g.moveTo(SX(lx), SY(ly));
          g.quadraticCurveTo(SX(lx + Math.cos(a) * 12), SY(ly + Math.sin(a) * 12 - 6), SX(lx + Math.cos(a) * 18), SY(ly + Math.sin(a) * 10 + 6));
          g.quadraticCurveTo(SX(lx + Math.cos(a) * 10), SY(ly + Math.sin(a) * 6), SX(lx), SY(ly)); g.fill();
        }
        g.fillStyle = '#5a3a1e'; g.beginPath(); g.arc(SX(x + lean), SY(by - hgt + 2), 1.8 * k + 0.5, 0, 7); g.fill();
      });
    }
    function drawLighthouse(g, x, y) {
      const k = V.k;
      g.fillStyle = '#efe6d6'; g.beginPath(); g.moveTo(SX(x - 6), SY(y + 2)); g.lineTo(SX(x - 4), SY(y - 26)); g.lineTo(SX(x + 4), SY(y - 26)); g.lineTo(SX(x + 6), SY(y + 2)); g.fill();
      g.fillStyle = '#c4473b'; g.fillRect(SX(x - 5.2), SY(y - 9), 10.4 * k, 5 * k); g.fillRect(SX(x - 4.6), SY(y - 20), 9.2 * k, 5 * k);
      g.fillStyle = '#ffe28a'; g.fillRect(SX(x - 3.5), SY(y - 32), 7 * k, 6 * k);
      g.fillStyle = '#3a3a44'; g.beginPath(); g.moveTo(SX(x - 5), SY(y - 32)); g.lineTo(SX(x), SY(y - 37)); g.lineTo(SX(x + 5), SY(y - 32)); g.fill();
    }

    /* ---- sea & weather ---- */
    function waveAt(x, t, ph) {
      const amp = MAPS[st.m].wave * Math.max(0.7, V.k);
      return Math.sin(x * 0.045 + t * 1.6 + ph) * amp + Math.sin(x * 0.11 - t * 2.3 + ph * 2) * amp * 0.35;
    }
    function seaSurface(t, ph, fill, alpha, depth) {
      ctx.globalAlpha = alpha; ctx.fillStyle = fill;
      ctx.beginPath(); ctx.moveTo(0, V.sy + depth);
      for (let x = 0; x <= V.w + 8; x += 8) ctx.lineTo(x, V.sy + waveAt(x, t, ph));
      ctx.lineTo(V.w + 8, V.sy + depth); ctx.closePath(); ctx.fill();
      ctx.globalAlpha = 1;
    }
    function foamLine(t, ph, dy, alpha) {
      ctx.strokeStyle = look().foam; ctx.globalAlpha = alpha; ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let x = 0; x <= V.w + 8; x += 8) { const y = V.sy + dy + waveAt(x, t, ph) * 0.6; x ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
      ctx.stroke(); ctx.globalAlpha = 1;
    }
    function windStreaks(t) {
      const wd = st.wd; if (!wd) return;
      const sp = wd * 22 + Math.sign(wd) * 30, len = (10 + Math.abs(wd) * 3.2) * Math.max(0.8, V.k);
      ctx.strokeStyle = st.m === 2 ? 'rgba(200,210,230,.35)' : 'rgba(255,255,255,.5)'; ctx.lineWidth = 1.3; ctx.lineCap = 'round';
      ctx.beginPath();
      const span = V.w + 120;
      for (let i = 0; i < 12; i++) {
        let x = (hash(i, 21) * span + t * sp) % span; if (x < 0) x += span; x -= 60;
        const y = TOPH + 50 + hash(i, 22) * Math.max(30, V.sy - TOPH - 90);
        ctx.moveTo(x, y); ctx.lineTo(x - Math.sign(wd) * len, y + Math.sin(t * 3 + i) * 1.5);
      }
      ctx.stroke();
    }
    function rain(t) {
      ctx.strokeStyle = 'rgba(190,205,230,.32)'; ctx.lineWidth = 1;
      ctx.beginPath();
      const slant = st.wd * 1.2;
      for (let i = 0; i < 70; i++) {
        const x = ((hash(i, 31) * (V.w + 100) + t * slant * 25) % (V.w + 100) + V.w + 100) % (V.w + 100) - 50;
        const y = ((hash(i, 32) * V.h + t * 520) % V.h);
        ctx.moveTo(x, y); ctx.lineTo(x + slant, y + 12);
      }
      ctx.stroke();
    }

    /* ---- ships ---- */
    function drawShip(i, x, dy, face, angDeg, tilt, alpha, t) {
      const k = V.k, sx = SX(x), sy = V.sy + dy, c = col(i), lk = look();
      const ws = st.wd === 0 ? -1 : Math.sign(st.wd) * face; // wind side in ship-local x
      const bul = 1.5 + Math.abs(st.wd) * 0.35;
      ctx.save(); ctx.globalAlpha = alpha; ctx.translate(sx, sy); ctx.rotate(tilt);
      ctx.save(); ctx.scale(face * k, k);
      ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      // masts & rigging
      ctx.strokeStyle = '#4a2f18'; ctx.lineWidth = 2.6;
      ctx.beginPath(); ctx.moveTo(4, -19); ctx.lineTo(4, -76); ctx.moveTo(-18, -24); ctx.lineTo(-18, -58); ctx.moveTo(30, -22); ctx.lineTo(48, -31); ctx.stroke();
      ctx.strokeStyle = 'rgba(40,25,12,.55)'; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(4, -76); ctx.lineTo(-33, -24); ctx.moveTo(4, -76); ctx.lineTo(47, -30); ctx.moveTo(-18, -58); ctx.lineTo(-34, -25); ctx.stroke();
      ctx.strokeStyle = '#4a2f18'; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(-10, -68); ctx.lineTo(18, -68); ctx.moveTo(-12, -48); ctx.lineTo(20, -48); ctx.moveTo(-27, -52); ctx.lineTo(-9, -52); ctx.stroke();
      // sails (bulge with the wind)
      const sail = (x0, y0, x1, y1) => {
        const b = bul * ws;
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y0);
        ctx.quadraticCurveTo(x1 + b * 1.6, (y0 + y1) / 2, x1 + b * 0.4, y1);
        ctx.lineTo(x0 + b * 0.4, y1); ctx.quadraticCurveTo(x0 + b * 1.6, (y0 + y1) / 2, x0, y0); ctx.closePath();
      };
      ctx.fillStyle = lk.sail; ctx.strokeStyle = 'rgba(80,60,40,.45)'; ctx.lineWidth = 0.8;
      sail(-9, -67, 17, -50); ctx.fill(); ctx.stroke();
      sail(-11, -47, 19, -27); ctx.fill(); ctx.stroke();
      sail(-26, -51, -10, -33); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(0,0,0,.08)'; sail(4, -47, 19, -27); ctx.fill();
      // jib
      ctx.fillStyle = lk.sail; ctx.beginPath(); ctx.moveTo(46, -30); ctx.lineTo(7, -72); ctx.lineTo(26, -24); ctx.closePath(); ctx.fill(); ctx.stroke();
      // emblem on the main course: player colour band + ring
      ctx.fillStyle = c; ctx.fillRect(-11 + bul * ws * 0.3, -44, 30, 4);
      ctx.beginPath(); ctx.arc(4 + bul * ws * 0.8, -35, 5, 0, 7); ctx.fill();
      ctx.fillStyle = lk.sail; ctx.beginPath(); ctx.arc(4 + bul * ws * 0.8, -35, 2, 0, 7); ctx.fill();
      // pennant at the masthead, streaming downwind
      const fl = ws * 1, fw = Math.sin(t * 9 + i) * 1.6;
      ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(4, -76); ctx.quadraticCurveTo(4 + fl * 8, -77 + fw, 4 + fl * 16, -73 + fw * 0.5); ctx.lineTo(4, -70); ctx.closePath(); ctx.fill();
      // hull
      ctx.beginPath();
      ctx.moveTo(-34, -25); ctx.lineTo(-25, -25); ctx.lineTo(-23, -19); ctx.lineTo(24, -19);
      ctx.quadraticCurveTo(32, -20, 37, -25); ctx.lineTo(31, -6); ctx.quadraticCurveTo(25, 6, 10, 7);
      ctx.lineTo(-24, 7); ctx.quadraticCurveTo(-31, 5, -33, -4); ctx.closePath();
      const hg = ctx.createLinearGradient(0, -25, 0, 7); hg.addColorStop(0, '#9a6532'); hg.addColorStop(0.55, '#6a4020'); hg.addColorStop(1, '#3a210e');
      ctx.fillStyle = hg; ctx.fill();
      ctx.save(); ctx.clip();
      ctx.strokeStyle = 'rgba(30,16,6,.45)'; ctx.lineWidth = 0.7;
      ctx.beginPath(); for (const y of [-14, -2, 3]) { ctx.moveTo(-36, y); ctx.lineTo(38, y); } ctx.stroke();
      ctx.fillStyle = c; ctx.fillRect(-36, -11.5, 76, 4);
      ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.fillRect(-36, -11.5, 76, 1);
      ctx.fillStyle = '#1e120a'; for (const gx of [-15, -4, 7]) ctx.fillRect(gx, -6.5, 4.5, 3.5);
      ctx.restore();
      ctx.strokeStyle = '#d2a668'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-23, -19.5); ctx.lineTo(24, -19.5); ctx.moveTo(-34, -25.5); ctx.lineTo(-25, -25.5); ctx.stroke();
      ctx.fillStyle = '#ffd77a'; ctx.fillRect(-31, -23, 2.4, 2.4); ctx.fillRect(-27.5, -23, 2.4, 2.4);
      ctx.restore();
      // cannon (not mirrored: it points along the real aim)
      const a = angDeg * Math.PI / 180;
      ctx.save(); ctx.translate(face * PIV * k, PIVY * k);
      ctx.fillStyle = '#5a3418'; ctx.fillRect(-4 * k, -1 * k, 8 * k, 4 * k);
      ctx.rotate(-a);
      ctx.fillStyle = '#26262c'; ctx.fillRect(-3 * k, -2.6 * k, (BARREL + 2) * k, 5.2 * k);
      ctx.fillStyle = '#4a4a52'; ctx.fillRect(-3 * k, -2.6 * k, (BARREL + 2) * k, 1.4 * k);
      ctx.fillStyle = '#111'; ctx.fillRect((BARREL - 1) * k, -3.2 * k, 2.4 * k, 6.4 * k);
      ctx.restore();
      ctx.restore();
    }
    function drawWreck(i, x, t) {
      const k = V.k, b = Math.sin(t * 1.4 + i) * 1.5;
      ctx.fillStyle = '#5a3a1c';
      for (let j = 0; j < 3; j++) { ctx.save(); ctx.translate(SX(x + (j - 1) * 14), V.sy + b + j * 0.6); ctx.rotate(0.15 * (j - 1) + Math.sin(t + j) * 0.05); ctx.fillRect(-7 * k, -1.6 * k, 14 * k, 3.2 * k); ctx.restore(); }
      ctx.fillStyle = col(i); ctx.globalAlpha = 0.85;
      ctx.beginPath(); ctx.moveTo(SX(x + 4), V.sy - 2 + b); ctx.lineTo(SX(x + 13), V.sy - 6 + b); ctx.lineTo(SX(x + 6), V.sy + 1 + b); ctx.fill();
      ctx.globalAlpha = 1;
    }
    function shipLabel(i, x, y, hp, cur, t) {
      const k = V.k, sx = SX(x), sy = V.sy + (y - 88) * k;
      const w = 44;
      ctx.fillStyle = 'rgba(23,19,31,.72)'; rr(sx - w / 2 - 2, sy - 2, w + 4, 8, 4); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.15)'; ctx.fillRect(sx - w / 2, sy, w, 4);
      ctx.fillStyle = hp > HP0 / 2 ? '#5fd3a0' : hp > HP0 / 4 ? '#e3ae45' : '#ee6a55';
      ctx.fillRect(sx - w / 2, sy, w * Math.max(0, hp) / HP0, 4);
      if (cur) {
        const by = sy - 10 + Math.sin(t * 5) * 2.5;
        ctx.fillStyle = col(i); ctx.strokeStyle = 'rgba(23,19,31,.8)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(sx - 7, by - 8); ctx.lineTo(sx + 7, by - 8); ctx.lineTo(sx, by); ctx.closePath(); ctx.fill(); ctx.stroke();
      }
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }

    /* ---- particles ---- */
    function puff(x, y, n, kind, spd, life, size, c) {
      for (let j = 0; j < n && parts.length < 260; j++) {
        const a = Math.random() * Math.PI * 2, v = spd * (0.3 + Math.random() * 0.7);
        parts.push({ k: kind, x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - (kind === 'drop' || kind === 'wood' ? spd * 0.8 : 0), t: 0, life: life * (0.6 + Math.random() * 0.6), s: size * (0.6 + Math.random() * 0.8), c, r: Math.random() * 6 });
      }
    }
    function stepParts(dt) {
      for (let j = parts.length - 1; j >= 0; j--) {
        const p = parts[j];
        p.t += dt;
        if (p.t >= p.life) { parts.splice(j, 1); continue; }
        if (p.k === 'drop' || p.k === 'wood' || p.k === 'spark') { p.vy += 260 * dt; if (p.k === 'wood' && p.y > 0) { p.y = 0; p.vy = 0; p.vx *= 0.9; } }
        else if (p.k === 'smoke') { p.vx += st.wd * 2 * dt; p.vy -= 6 * dt; p.vx *= 0.985; p.vy *= 0.985; }
        else if (p.k === 'bub') { p.vy = -26; }
        else if (p.k === 'txt') { p.vy = -22; p.vx = 0; }
        p.x += p.vx * dt; p.y += p.vy * dt; p.r += dt * 6;
        if (p.k === 'drop' && p.y > 2) { parts.splice(j, 1); }
      }
    }
    function drawParts() {
      const k = V.k;
      for (const p of parts) {
        const f = p.t / p.life, x = SX(p.x), y = SY(p.y);
        if (p.k === 'smoke') { ctx.globalAlpha = 0.5 * (1 - f); ctx.fillStyle = p.c || '#d8d4cc'; ctx.beginPath(); ctx.arc(x, y, (p.s + f * p.s * 1.6) * k, 0, 7); ctx.fill(); }
        else if (p.k === 'fire') { ctx.globalAlpha = 1 - f; ctx.fillStyle = f < 0.3 ? '#fff1b0' : f < 0.6 ? '#ffb347' : '#e5552e'; ctx.beginPath(); ctx.arc(x, y, p.s * (1 - f * 0.5) * k, 0, 7); ctx.fill(); }
        else if (p.k === 'drop') { ctx.globalAlpha = 0.9 * (1 - f * 0.6); ctx.fillStyle = '#e8f6ff'; ctx.beginPath(); ctx.arc(x, y, p.s * k, 0, 7); ctx.fill(); }
        else if (p.k === 'spark') { ctx.globalAlpha = 1 - f; ctx.fillStyle = p.c || '#ffd27a'; ctx.fillRect(x - 1, y - 1, 2.2, 2.2); }
        else if (p.k === 'wood') { ctx.globalAlpha = 1 - f * f; ctx.fillStyle = p.c || '#7a4a24'; ctx.save(); ctx.translate(x, y); ctx.rotate(p.r); ctx.fillRect(-p.s * k, -1.2 * k, p.s * 2 * k, 2.4 * k); ctx.restore(); }
        else if (p.k === 'bub') { ctx.globalAlpha = 0.6 * (1 - f); ctx.strokeStyle = '#d8f1ff'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(x + Math.sin(p.t * 8 + p.s) * 2, y, p.s * k, 0, 7); ctx.stroke(); }
        else if (p.k === 'ring') { ctx.globalAlpha = 0.7 * (1 - f); ctx.strokeStyle = '#f2fbff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y, (6 + f * p.s) * k, (2 + f * p.s * 0.22) * k, 0, 0, 7); ctx.stroke(); }
        else if (p.k === 'txt') {
          ctx.globalAlpha = f < 0.75 ? 1 : (1 - f) * 4; ctx.font = '700 ' + Math.round(15 + p.s) + 'px "IBM Plex Mono", monospace';
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(p.c, x, y); ctx.fillStyle = p.s > 4 ? '#ffd27a' : '#f2e9d8'; ctx.fillText(p.c, x, y);
        }
      }
      ctx.globalAlpha = 1;
    }

    /* ---- HUD ---- */
    let topKey = '';
    function renderTop() {
      if (!st) return;
      const hp = hpShow || st.hp, cur = anim ? anim.l.s : st.ov ? -1 : st.cur;
      const key = hp.join(',') + '|' + cur + '|' + st.ov + '|' + land;
      if (key === topKey) return;
      topKey = key;
      top.innerHTML = '';
      top.style.padding = land ? '4px 8px' : '6px 8px';
      for (let i = 0; i < st.n; i++) {
        const p = api.players[i] || { name: '?', color: '#888' }, on = cur === i, dead = hp[i] <= 0;
        const bar = L.h('div', { style: { height: '5px', borderRadius: '3px', background: 'rgba(255,255,255,.12)', overflow: 'hidden' } },
          L.h('div', { style: { height: '100%', width: Math.max(0, hp[i]) / HP0 * 100 + '%', background: hp[i] > HP0 / 2 ? '#5fd3a0' : hp[i] > HP0 / 4 ? '#e3ae45' : '#ee6a55', transition: 'width .3s' } }));
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, maxWidth: land ? '220px' : '', padding: land ? '3px 8px' : '5px 7px', display: 'flex', flexDirection: 'column', gap: land ? '2px' : '3px',
          borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color : 'none', opacity: dead ? 0.45 : on || cur < 0 ? 1 : 0.78 } },
        L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden' } },
          L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }), L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', flex: '1 1 auto', minWidth: 0 }, text: p.name }),
          L.h('span', { class: 'mono', style: { fontSize: '11px', color: dead ? 'var(--coral)' : 'var(--ink)', flex: 'none' }, text: dead ? '침몰' : String(hp[i]) })),
        bar));
      }
    }
    let botKey = '';
    let moveLbl = null;
    function renderBot() {
      if (!st) { bot.innerHTML = ''; return; }
      const mine = canHuman();
      const a = anim ? anim.l.s : st.cur;
      const key = [mine, a, anim ? 'A' + anim.l.id : '', st.ov, selW, st.am[a] ? st.am[a].join(',') : '', st.seq, land].join('|');
      if (key === botKey) return;
      botKey = key;
      bot.innerHTML = ''; moveLbl = null; lastMoveLbl = '';
      Object.assign(bot.style, land
        ? { flexDirection: 'row', alignItems: 'flex-end', justifyContent: mine ? 'space-between' : 'center', padding: '0 8px 8px', gap: '8px' }
        : { flexDirection: 'column', alignItems: 'stretch', justifyContent: 'center', padding: '8px 10px', gap: '6px' });
      if (st.ov && !anim) return;
      if (!mine) {
        const am = st.am[a];
        const msg = anim ? pname(a) + ' · ' + WEP[anim.l.sh.w].nm + ' 발사!' : pname(a) + (api.players[a] && api.players[a].ai ? ' 조준 중…' : ' 차례');
        bot.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', fontWeight: 700, padding: '8px 12px', minHeight: '44px',
          minWidth: land ? '240px' : '', maxWidth: land ? '440px' : '', pointerEvents: land ? 'none' : '' } },
          L.h('span', { class: 'dot', style: { '--c': col(a), flex: 'none' } }),
          L.h('span', { style: { flex: '1 1 auto', minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: msg }),
          am ? L.h('span', { class: 'mono muted', style: { fontSize: '11px', flex: 'none' }, text: '산탄 ' + am[0] + ' · 무거운 ' + am[1] }) : null));
        return;
      }
      const am = st.am[a];
      moveLbl = L.h('span', { class: 'mono', style: { flex: 'none', fontSize: '11px', color: 'var(--brass)' } });
      if (land) {
        // landscape: ◀ ▶ under the left thumb, shells under the right thumb, a short hint in between (touches pass through it)
        bot.append(
          L.h('div', { 'data-tut': 'move', style: { display: 'flex', gap: '6px', flex: 'none' } }, mvBtn(-1, '◀', '왼쪽으로 이동', true), mvBtn(1, '▶', '오른쪽으로 이동', true)),
          L.h('div', { class: 'panel', style: { pointerEvents: 'none', flex: '0 1 auto', minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1px',
            padding: '4px 12px', fontSize: '12px', fontWeight: 600, marginBottom: '6px', overflow: 'hidden' } },
          L.h('span', { style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%' }, text: '아무 데나 뒤로 끌었다 놓으면 발사' }), moveLbl),
          L.h('div', { 'data-tut': 'ammo', style: { display: 'flex', gap: '5px', flex: 'none' } }, wBtn(0, '무제한', am, true), wBtn(1, '×' + am[0], am, true), wBtn(2, '×' + am[1], am, true)));
        updMoveLbl();
        return;
      }
      bot.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '6px', padding: '5px 10px', fontSize: '12px', fontWeight: 600 } },
        L.h('span', { style: { flex: '1 1 auto', minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: '◀ ▶ 꾹 눌러 이동 · 아무 데나 뒤로 끌었다 놓아 발사' }), moveLbl));
      bot.append(L.h('div', { style: { display: 'flex', gap: '5px', alignItems: 'stretch' } },
        L.h('div', { 'data-tut': 'move', style: { display: 'flex', gap: '5px', flex: 'none' } }, mvBtn(-1, '◀', '왼쪽으로 이동'), mvBtn(1, '▶', '오른쪽으로 이동')),
        L.h('div', { 'data-tut': 'ammo', style: { display: 'flex', gap: '5px', flex: '1 1 0', minWidth: 0 } }, wBtn(0, '무제한', am), wBtn(1, '×' + am[0], am), wBtn(2, '×' + am[1], am))));
      updMoveLbl();
    }
    function mvBtn(dir, txt, lbl, big) {
      const sz = big ? '56px' : '48px';
      const b = L.h('button', { class: 'btn', 'aria-label': lbl, style: { flex: 'none', width: sz, minHeight: sz, padding: '0', fontSize: big ? '20px' : '18px' }, text: txt });
      const stopMv = () => { if (mvDir === dir) mvDir = 0; };
      b.addEventListener('pointerdown', (e) => { if (!canHuman()) return; mvDir = dir; api.buzz(8); try { b.setPointerCapture(e.pointerId); } catch (er) {} });
      b.addEventListener('pointerup', stopMv); b.addEventListener('pointercancel', stopMv); b.addEventListener('lostpointercapture', stopMv);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
      return b;
    }
    function wBtn(w, sub, am, wide) {
      const dis = w > 0 && !(am[w - 1] > 0);
      return L.h('button', { class: 'btn sm' + (selW === w ? ' primary' : ''), disabled: dis ? true : null, 'aria-label': WEP[w].nm + ' 고르기',
        style: { flex: wide ? 'none' : '1 1 0', width: wide ? (w === 2 ? '80px' : '64px') : '', minWidth: 0, minHeight: wide ? '56px' : '48px', padding: '2px 4px', flexDirection: 'column', gap: '1px', lineHeight: 1.1 },
        onclick() { if (dis) return; selW = w; api.sfx('click'); api.buzz(8); renderBot(); } },
      L.h('span', { style: { fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap' }, text: wide && w === 2 ? '무거운탄' : WEP[w].nm }),
      L.h('span', { class: 'mono', style: { fontSize: '11px', opacity: 0.8 }, text: sub }));
    }
    function updMoveLbl() {
      if (!moveLbl || !st) return;
      const left = Math.max(0, Math.round(MOVE - Math.abs(mvx - st.x[st.cur])));
      const t = '이동 ' + left;
      if (t !== lastMoveLbl) { lastMoveLbl = t; moveLbl.textContent = t; }
    }

    /* ---- canvas overlays: wind, round, aim ---- */
    function pill(x, y, w, h) { ctx.fillStyle = 'rgba(23,19,31,.78)'; rr(x, y, w, h, h / 2); ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.35)'; ctx.lineWidth = 1; ctx.stroke(); }
    function drawInfo() {
      const y = TOPH + 6, wd = st.wd, aw = Math.abs(wd);
      // round
      pill(8, y, 66, 28);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
      ctx.font = '700 12px "IBM Plex Mono", monospace'; ctx.fillText(st.rd + '/' + RMAX + '턴', 41, y + 14.5);
      // wind
      const cx = V.w / 2, pw = 156;
      pill(cx - pw / 2, y, pw, 28);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.fillText('바람', cx - pw / 2 + 11, y + 15);
      const c = aw <= 3 ? '#5fd3a0' : aw <= 7 ? '#e3ae45' : '#ee6a55';
      const ax0 = cx - 30, ax1 = cx + 40, mid = (ax0 + ax1) / 2, len = (ax1 - ax0) / 2 * (aw / 12);
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(ax0, y + 14); ctx.lineTo(ax1, y + 14); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.fillRect(mid - 0.75, y + 8, 1.5, 12);
      if (wd) {
        const sg = Math.sign(wd), ex = mid + sg * len;
        ctx.strokeStyle = c; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(mid, y + 14); ctx.lineTo(ex, y + 14); ctx.stroke();
        ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(ex + sg * 7, y + 14); ctx.lineTo(ex - sg * 1, y + 7.5); ctx.lineTo(ex - sg * 1, y + 20.5); ctx.closePath(); ctx.fill();
      }
      ctx.fillStyle = c; ctx.font = '700 14px "IBM Plex Mono", monospace'; ctx.textAlign = 'right';
      ctx.fillText(String(aw), cx + pw / 2 - 10, y + 15);
      // map name
      const mn = MAPS[st.m].nm;
      ctx.font = '700 11px "IBM Plex Sans KR", sans-serif';
      const mw = Math.ceil(ctx.measureText(mn).width) + 18;
      if (cx + pw / 2 + 6 + mw < V.w - 6) { pill(V.w - 8 - mw, y, mw, 28); ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.fillText(mn, V.w - 8 - mw / 2, y + 15); }
    }
    const CANCEL = 24;
    /* distance from canvas point (x, y) along unit (ux, uy) to the edge of the phone screen — the finger may keep pulling
       over the HUD and the app header, but not past the glass */
    function screenRoom(x, y, ux, uy) {
      const r = cv.cv.getBoundingClientRect(), x0 = -r.left, y0 = -r.top, x1 = (window.innerWidth || cv.w) - r.left, y1 = (window.innerHeight || cv.h) - r.top;
      let t = 1e9;
      if (ux > 1e-6) t = Math.min(t, (x1 - x) / ux); else if (ux < -1e-6) t = Math.min(t, (x0 - x) / ux);
      if (uy > 1e-6) t = Math.min(t, (y1 - y) / uy); else if (uy < -1e-6) t = Math.min(t, (y0 - y) / uy);
      return Math.max(0, t);
    }
    /* full power needs ~0.3 × the short screen side of pull; when the glass edge comes sooner in the pull direction the scale
       shrinks so 100% is reached just before the edge, and holding the finger at the edge keeps pulling (edgePull) */
    function aimInfo() {
      if (!drag || !drag.vec) return null;
      const vx = drag.vec[0], vy = drag.vec[1], len = Math.hypot(vx, vy);
      if (len < CANCEL) return { cancel: true };
      let a = Math.atan2(vy, -vx); // fire opposite to the pull; screen y is down
      if (a < 0) a = a > -Math.PI / 2 ? AMIN : AMAX;
      a = clamp(a, AMIN, AMAX);
      let maxPx = clamp(Math.min(window.innerWidth || cv.w, window.innerHeight || cv.h) * 0.36, 120, 180);
      maxPx = clamp(screenRoom(drag.ox, drag.oy, vx / len, vy / len) - CANCEL, 56, maxPx);
      return { a, p: Math.round(clamp((len - CANCEL + 6) / maxPx, 0.1, 1) * 100) / 100 };
    }
    /* finger parked on the glass edge while pulling toward it → the pull keeps growing (the start point slides back
       along the same line, so the angle stays put) until 100% */
    function edgePull(dt) {
      if (!drag || !drag.started || drag.cx == null) return;
      const vx = drag.vec[0], vy = drag.vec[1], len = Math.hypot(vx, vy);
      if (len < CANCEL) return;
      const ux = vx / len, uy = vy / len, Wn = window.innerWidth || cv.w, Hn = window.innerHeight || cv.h, E = 18;
      const atEdge = (ux < -0.3 && drag.cx < E) || (ux > 0.3 && drag.cx > Wn - E) || (uy < -0.3 && drag.cy < E) || (uy > 0.3 && drag.cy > Hn - E);
      if (!atEdge) return;
      const info = aimInfo();
      if (!info || info.cancel || info.p >= 1) return;
      const d = 150 * dt;
      drag.ox -= ux * d; drag.oy -= uy * d; drag.vec = [vx + ux * d, vy + uy * d];
      aimFeedback();
    }
    function calcPreview(info) {
      prevPts.length = 0;
      if (!info || info.cancel) return;
      const s = st, px = s.x.slice(); px[s.cur] = mvx;
      const al = s.hp.map((h) => (h > 0 ? 1 : 0)), shot = makeShot(mvx, info.a, info.p, selW, s.wd), isl = islOf(s);
      for (const b of shot.b) {
        const sim = new Ball(isl, px, al, s.cur, b, shot.wa), pts = [];
        const steps = Math.round((PVT[st.pv == null ? 1 : st.pv] || 0) / DT);
        if (!steps) break;
        for (let n = 0; n < steps && !sim.done; n++) { sim.step(); if (n % 4 === 3) pts.push(sim.x, sim.y); }
        prevPts.push(pts);
      }
    }
    function drawAim(t) {
      const info = aimInfo();
      if (drag) {
        ctx.strokeStyle = info && info.cancel ? 'rgba(238,106,85,.9)' : 'rgba(255,255,255,.3)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.arc(drag.ox, drag.oy, CANCEL, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      if (!info) return;
      const bx = V.w / 2, by = TOPH + (land ? 62 : 56);
      if (info.cancel) {
        if (!drag.started) return;
        pill(bx - 70, by - 18, 140, 36); ctx.fillStyle = '#ee6a55'; ctx.font = '700 15px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('놓으면 취소', bx, by + 1);
        return;
      }
      // preview dots (only the first part of the flight)
      for (const pts of prevPts) {
        const n = pts.length / 2;
        for (let j = 0; j < n; j++) { ctx.globalAlpha = 0.95 - j / n * 0.7; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(SX(pts[j * 2]), SY(pts[j * 2 + 1]), 2.3 - j / n, 0, 7); ctx.fill(); }
      }
      ctx.globalAlpha = 1;
      // pull band on screen
      ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(drag.ox, drag.oy); ctx.lineTo(drag.ox + drag.vec[0], drag.oy + drag.vec[1]); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.beginPath(); ctx.arc(drag.ox + drag.vec[0], drag.oy + drag.vec[1], 5, 0, 7); ctx.fill();
      // readout
      const el = Math.round((info.a <= Math.PI / 2 ? info.a : Math.PI - info.a) * 180 / Math.PI), dir = Math.cos(info.a) >= 0 ? '▶' : '◀';
      const la = lastAim[st.cur];
      const h = la ? 52 : 38;
      pill(bx - 82, by - 19, 164, h);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 19px "IBM Plex Mono", monospace';
      ctx.fillText(dir + ' ' + el + '°  ' + Math.round(info.p * 100) + '%', bx, by);
      if (la) { ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.fillText('지난번 ' + la, bx, by + 21); }
      // power gauge ring at the ship
      const sx = SX(mvx), sy = SY(-40), r = 46 * V.k + 6;
      ctx.lineWidth = 5; ctx.lineCap = 'butt';
      ctx.strokeStyle = 'rgba(23,19,31,.55)'; ctx.beginPath(); ctx.arc(sx, sy, r, -Math.PI / 2, Math.PI * 1.5); ctx.stroke();
      ctx.strokeStyle = info.p < 0.5 ? '#5fd3a0' : info.p < 0.8 ? '#e3ae45' : '#ee6a55';
      ctx.beginPath(); ctx.arc(sx, sy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * info.p); ctx.stroke();
      void t;
    }

    /* ---- main draw ---- */
    function shipPose(i) {
      // returns {x, face, ang, alive, sink(0..1)}
      if (anim) {
        const l = anim.l;
        let x = l.px[i];
        let ang = i === l.s ? anim.ang : st.ag[i];
        if (i === l.s && anim.ph === 0) x = l.x0 + (l.x1 - l.x0) * Math.min(1, anim.t / Math.max(0.001, anim.mvDur));
        const sinking = anim.sink.includes(i);
        const alive = !!l.al[i];
        return { x, ang, alive, sink: sinking ? (anim.ph === 5 ? Math.min(1, anim.t / 1.8) : 0) : 0 };
      }
      let x = st.x[i], ang = st.ag[i];
      if (canHuman() && i === st.cur) { x = mvx; const info = aimInfo(); if (info && !info.cancel) ang = info.a * 180 / Math.PI; }
      return { x, ang, alive: st.hp[i] > 0, sink: 0 };
    }
    function draw(t) {
      if (!st || !V) return;
      buildLayers();
      cv.clear();
      ctx.save();
      if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 8, (Math.random() - 0.5) * shake * 6);
      ctx.drawImage(bgL.c, 0, 0, V.w, V.h);
      windStreaks(t);
      const lk = look();
      seaSurface(t, 0, lk.sea[0], 1, 16);
      foamLine(t, 1.3, 10, 0.25);
      ctx.drawImage(islL.c, 0, 0, V.w, V.h);
      // ships
      for (let i = 0; i < st.n; i++) {
        const P = shipPose(i);
        if (!P.alive) { drawWreck(i, P.x, t); continue; }
        const face = P.ang > 90 ? -1 : 1;
        const bob = waveAt(SX(P.x), t, 0) * 0.55, tilt = (waveAt(SX(P.x) + 12, t, 0) - waveAt(SX(P.x) - 12, t, 0)) * 0.02;
        if (P.sink > 0) {
          const s = P.sink;
          drawShip(i, P.x, bob + s * s * 70 * V.k, face, P.ang, tilt - face * s * 0.5, 1 - s * 0.6, t);
        } else drawShip(i, P.x, bob, face, P.ang, tilt, 1, t);
      }
      // front water over the hulls
      seaSurface(t, 2.1, lk.sea[0], 0.62, 16);
      foamLine(t, 2.1, 0, 0.55);
      // labels
      const hp = hpShow || st.hp;
      for (let i = 0; i < st.n; i++) {
        const P = shipPose(i);
        if (!P.alive || P.sink > 0) continue;
        const cur = !st.ov && (anim ? anim.l.s === i : st.cur === i);
        shipLabel(i, P.x, 0, hp[i], cur, t);
      }
      // balls
      if (anim && anim.ph === 3) {
        const w = anim.l.sh.w;
        for (let j = 0; j < anim.sims.length; j++) {
          const s = anim.sims[j], tr = anim.trails[j];
          for (let q = 0; q < tr.length; q += 2) { ctx.globalAlpha = 0.08 + (q / tr.length) * 0.35; ctx.fillStyle = '#e8e2d6'; ctx.beginPath(); ctx.arc(SX(tr[q]), SY(tr[q + 1]), (1.5 + q / tr.length * 2.5) * V.k, 0, 7); ctx.fill(); }
          ctx.globalAlpha = 1;
          if (s.done) continue;
          const x = SX(s.x), y = SY(s.y), r = Math.max(2.8, WEP[w].r * V.k);
          if (y < TOPH + 4) { // off the top: marker
            ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(x, TOPH + 4); ctx.lineTo(x - 6, TOPH + 14); ctx.lineTo(x + 6, TOPH + 14); ctx.closePath(); ctx.fill();
            continue;
          }
          ctx.fillStyle = '#18171c'; ctx.strokeStyle = 'rgba(255,240,210,.55)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.arc(x - r * 0.35, y - r * 0.35, r * 0.35, 0, 7); ctx.fill();
        }
      }
      drawParts();
      if (look().rain) rain(t);
      ctx.restore();
      if (flash > 0) { ctx.fillStyle = 'rgba(230,236,255,' + (flash * 0.35) + ')'; ctx.fillRect(0, 0, V.w, V.h); }
      drawInfo();
      if (canHuman()) drawAim(t);
    }

    /* ---- input ---- */
    function canHuman() { return !!st && !anim && !st.ov && api.canAct(st.cur) && !(sentAt && performance.now() - sentAt < 5000); }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (!canHuman() || drag) return;
      const p = cv.local(ev);
      drag = { id: ev.pointerId, ox: p.x, oy: p.y, vec: [0, 0], started: false, tick: -1, wasC: true, cx: ev.clientX, cy: ev.clientY };
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      api.buzz(8);
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const p = cv.local(ev);
      drag.vec = [p.x - drag.ox, p.y - drag.oy]; drag.cx = ev.clientX; drag.cy = ev.clientY;
      if (Math.hypot(drag.vec[0], drag.vec[1]) > CANCEL) drag.started = true;
      aimFeedback();
    });
    function aimFeedback() {
      const info = aimInfo();
      if (info) {
        if (!!info.cancel !== drag.wasC && drag.started) { drag.wasC = !!info.cancel; api.buzz(info.cancel ? 20 : 8); }
        const tk = info.cancel ? -1 : Math.floor(info.p * 10);
        if (tk !== drag.tick && tk >= 0) api.sfx('tick');
        drag.tick = tk;
      }
      calcPreview(info);
    }
    cv.cv.addEventListener('pointerup', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const info = aimInfo(), d0 = drag; drag = null; prevPts.length = 0;
      if (!canHuman() || !info) return;
      if (info.cancel) { if (d0.started) { api.sfx('click'); api.toast('취소'); } return; }
      mvDir = 0;
      api.buzz(18);
      if (!api.isHost) sentAt = performance.now();
      api.act({ type: 'fire', x: r1(mvx), a: info.a, p: info.p, w: selW });
    });
    cv.cv.addEventListener('pointercancel', (ev) => { if (drag && drag.id === ev.pointerId) { drag = null; prevPts.length = 0; } });

    /* ---- shot replay ---- */
    function startAnim(l) {
      if (anim) endAnim(true);
      const isl = islOf(st);
      const sims = l.sh.b.map((b) => new Ball(isl, l.px, l.al, l.s, b, l.sh.wa));
      const mid = l.sh.b[(l.sh.b.length - 1) >> 1];
      const toAng = Math.atan2(-mid[3], mid[2]) * 180 / Math.PI;
      const fromAng = anim && anim.l.s === l.s ? toAng : (prevAg[l.s] != null ? prevAg[l.s] : toAng);
      const mvDur = Math.min(0.8, Math.abs(l.x1 - l.x0) / 70);
      const sink = []; for (let i = 0; i < st.n; i++) if (l.al[i] && st.hp[i] <= 0) sink.push(i);
      anim = { l, ph: 0, t: 0, sims, trails: sims.map(() => []), acc: 0, mvDur, fromAng, toAng, ang: fromAng, sink, hits: [], dmg: l.hp0.map(() => 0) };
      hpShow = l.hp0.slice();
      api.setBusy(true);
      // rAF pauses in background tabs: make sure the replay (and busy) still finishes
      let n = 0; for (const b of l.sh.b) { const s = new Ball(isl, l.px, l.al, l.s, b, l.sh.wa); while (!s.done) s.step(); n = Math.max(n, s.n); }
      const dur = mvDur + 0.35 + n * DT / FLY + 0.6 + (sink.length ? 1.8 : 0);
      clearTimeout(safeT);
      const me = anim;
      safeT = setTimeout(() => { if (anim === me) endAnim(true); }, (dur / L.debug.speed) * 1000 + 3000);
      renderTop(); renderBot();
    }
    const FLY = 1.35; // replay speed of the flight
    function impact(s) {
      const l = anim.l;
      if (s.res === 'o') return;
      const d = blast(l.sh.w, s.x, s.y, s.hit, l.px, l.al);
      const big = l.sh.w === 2 ? 1.5 : l.sh.w === 1 ? 0.6 : 1;
      if (s.res === 'w') {
        puff(s.x, -2, Math.round(16 * big), 'drop', 120 * big, 0.9, 1.6, null);
        parts.push({ k: 'ring', x: s.x, y: 0, vx: 0, vy: 0, t: 0, life: 0.9, s: 30 * big, r: 0 });
        api.sfx('pop');
      } else if (s.res === 'l') {
        puff(s.x, s.y, Math.round(10 * big), 'fire', 50 * big, 0.45, 6 * big, null);
        puff(s.x, s.y, Math.round(8 * big), 'smoke', 25, 1.4, 6 * big, '#8d877c');
        puff(s.x, s.y, Math.round(8 * big), 'spark', 120 * big, 0.7, 1, '#c9a46a');
        api.sfx('thud');
      } else {
        puff(s.x, s.y, Math.round(14 * big), 'fire', 60 * big, 0.5, 7 * big, null);
        puff(s.x, s.y, Math.round(10 * big), 'smoke', 25, 1.6, 7 * big, '#6e6862');
        puff(s.x, s.y, Math.round(10 * big), 'wood', 130 * big, 1.6, 4, '#7a4a24');
        api.sfx('hit'); api.buzz(30);
      }
      shake = Math.max(shake, 0.5 * big);
      for (let i = 0; i < d.length; i++) {
        if (!d[i]) continue;
        anim.dmg[i] += d[i];
        hpShow[i] = Math.max(0, hpShow[i] - d[i]);
        parts.push({ k: 'txt', x: l.px[i] + (Math.random() - 0.5) * 10, y: -98, vx: 0, vy: -22, t: 0, life: 1.4, s: s.hit === i ? 6 : 0, c: '-' + d[i], r: 0 });
        if (s.hit !== i) puff(l.px[i], -12, 4, 'smoke', 14, 1, 4, '#8d877c');
      }
      if (s.res === 's') anim.hits.push(s.hit);
      renderTop();
    }
    function endAnim(force) {
      if (!anim) return;
      const a = anim;
      if (force) for (const s of a.sims) while (!s.done) { s.step(); if (s.done) impact(s); }
      anim = null; hpShow = null;
      clearTimeout(safeT);
      prevAg = st.ag.slice();
      // announce
      const l = a.l, nm = pname(l.s);
      if (a.sink.length) { api.toast(a.sink.map(pname).join(', ') + ' 침몰!'); api.sfx('lose'); api.buzz(40); }
      else if (a.hits.length) { const hit = a.hits.find((h) => h !== l.s); api.toast(hit != null ? '명중! ' + pname(hit) + ' -' + a.dmg[hit] : nm + ' · 내 배에 맞았어요'); }
      else if (a.dmg.every((v) => !v)) api.toast(nm + ' · 빗나감');
      const lv = l.sh.b[(l.sh.b.length - 1) >> 1], sp = Math.hypot(lv[2], lv[3]) / (VMAX * WEP[l.sh.w].sp);
      const ang = Math.atan2(-lv[3], lv[2]), el = Math.round((ang <= Math.PI / 2 ? ang : Math.PI - ang) * 180 / Math.PI);
      lastAim[l.s] = (Math.cos(ang) >= 0 ? '▶' : '◀') + ' ' + el + '° ' + Math.round(sp * 100) + '%';
      api.setBusy(false);
      newTurn(); renderTop(); renderBot();
    }
    let prevAg = [];
    function stepAnim(dt) {
      const a = anim;
      a.t += dt;
      if (a.ph === 0) {
        a.ang = a.fromAng + (a.toAng - a.fromAng) * Math.min(1, a.t / Math.max(0.3, a.mvDur));
        if (a.l.x1 !== a.l.x0 && Math.random() < 0.3) puff(a.l.x0 + (a.l.x1 - a.l.x0) * Math.min(1, a.t / Math.max(0.001, a.mvDur)) - Math.sign(a.l.x1 - a.l.x0) * 30, -1, 1, 'drop', 30, 0.5, 1.2, null);
        if (a.t >= Math.max(a.mvDur, 0.3)) { a.ph = 1; a.t = 0; }
      } else if (a.ph === 1) {
        a.ang = a.toAng;
        if (a.t >= 0.12) {
          a.ph = 3; a.t = 0;
          const f = Math.cos(a.toAng * Math.PI / 180) >= 0 ? 1 : -1, b = a.l.sh.b[(a.l.sh.b.length - 1) >> 1];
          puff(b[0], b[1], 7, 'fire', 40, 0.25, 4, null);
          puff(b[0], b[1], 8, 'smoke', 30, 1.3, 5, '#e4e0d8');
          for (let j = 0; j < 4; j++) parts.push({ k: 'smoke', x: b[0], y: b[1], vx: f * 40 * (j + 1) / 4 + (Math.random() - 0.5) * 10, vy: -8 * j, t: 0, life: 1.2, s: 5, c: '#ece8e0', r: 0 });
          api.sfx('thud'); api.sfx('whoosh'); api.buzz(20);
          shake = Math.max(shake, 0.25);
        }
      } else if (a.ph === 3) {
        a.acc += dt * FLY;
        let n = 0;
        while (a.acc >= DT && n < 3000) {
          a.acc -= DT; n++;
          let live = false;
          for (let j = 0; j < a.sims.length; j++) {
            const s = a.sims[j];
            if (s.done) continue;
            s.step();
            if (s.n % 3 === 0) { const tr = a.trails[j]; tr.push(s.x, s.y); if (tr.length > 40) tr.splice(0, 2); }
            if (s.done) impact(s); else live = true;
          }
          if (!live) { a.ph = 4; a.t = 0; break; }
        }
      } else if (a.ph === 4) {
        if (a.t >= 0.6) { if (a.sink.length) { a.ph = 5; a.t = 0; api.sfx('lose'); } else { endAnim(false); return; } }
      } else if (a.ph === 5) {
        if (Math.random() < 0.5) for (const i of a.sink) puff(a.l.px[i] + (Math.random() - 0.5) * 40, 6 + Math.random() * 20, 1, 'bub', 0, 1.2, 2.5, null);
        if (Math.random() < 0.15) for (const i of a.sink) puff(a.l.px[i], -20, 1, 'smoke', 12, 1.6, 6, '#5d5650');
        if (a.t >= 1.8) endAnim(false);
      }
    }
    function newTurn() {
      if (!st) return;
      const key = st.seq + ':' + st.cur + ':' + st.ov;
      if (key === turnKey) return;
      turnKey = key;
      mvx = st.x[st.cur]; mvDir = 0; rng = moveRange(st, st.cur);
      if (selW && !(st.am[st.cur][selW - 1] > 0)) selW = 0;
      if (!api.canAct(st.cur)) selW = 0;
      drag = null; prevPts.length = 0;
    }

    /* ---- loop ---- */
    cv.onresize = () => { layout(); };
    layout();
    const stop = U.loop((dt0, now) => {
      if (!st) return;
      const dt = dt0 * L.debug.speed, t = now / 1000;
      if (anim) stepAnim(dt);
      if (drag) edgePull(dt0);
      if (parts.length) stepParts(dt);
      if (shake > 0) shake = Math.max(0, shake - dt * 2.2);
      if (look().rain) { flashT -= dt; if (flashT <= 0) { flash = 1; flashT = 5 + Math.random() * 6; } }
      if (flash > 0) flash = Math.max(0, flash - dt * 2.5);
      if (mvDir && canHuman()) {
        const nx = clamp(mvx + mvDir * 60 * dt0, rng[0], rng[1]);
        if (nx !== mvx) { mvx = nx; if (Math.random() < 0.25) puff(mvx - mvDir * 32, -1, 1, 'drop', 25, 0.5, 1.2, null); if (drag) calcPreview(aimInfo()); }
        updMoveLbl();
      }
      // idle → 30 fps is plenty for the waves
      frameOdd = !frameOdd;
      if (!anim && !drag && !mvDir && !parts.length && frameOdd) return;
      draw(t);
    });

    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        if (!prevAg.length || !prev) prevAg = (prev || next).ag.slice();
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) startAnim(l);
        else if (!anim) { newTurn(); prevAg = next.ag.slice(); }
        renderTop(); renderBot();
      },
      destroy() { stop(); clearTimeout(safeT); cv.destroy(); top.remove(); bot.remove(); api.setBusy(false); },
    };
  }

  L.register({
    id: 'pirate', name: '해적선 포격전', tag: '바람 읽고 포격', cat: '아케이드',
    blurb: '해적선을 조금 움직이고, 화면을 뒤로 끌었다 놓아 대포를 쏴요. 매 턴 바뀌는 바람을 읽고 섬 너머로 맞히세요. 마지막까지 떠 있는 배가 이겨요.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 950,
    tint: '#1d4a6b',
    icon: '<path d="M7 36h42l-7 11H14z" fill="currentColor"/><path d="M27 8v28" stroke="currentColor" stroke-width="3"/><path d="M29 10c8 3 10 10 9 21H29z" fill="currentColor" opacity=".85"/><path d="M25 14c-6 3-8 9-7 17h7z" fill="currentColor" opacity=".6"/><circle cx="47" cy="12" r="4" fill="currentColor"/><path d="M38 24c2-6 4-9 7-10" stroke="currentColor" stroke-width="2" stroke-dasharray="2 3" fill="none"/><path d="M4 52c4-3 8-3 12 0s8 3 12 0 8-3 12 0 8 3 12 0" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    options: [
      { id: 'aim', label: '조준선', choices: [{ v: 'off', label: '끔' }, { v: 's', label: '짧게' }, { v: 'l', label: '길게' }], def: 's' },
      { id: 'map', label: '바다', choices: [{ v: 'r', label: '무작위' }, { v: '0', label: '잔잔한 만' }, { v: '1', label: '암초 해협' }, { v: '2', label: '폭풍의 바다' }, { v: '3', label: '노을 군도' }], def: 'r' },
    ],
    landscape: true,
    quick: [
      '목표: 대포로 다른 배를 맞혀 가라앉히고, 마지막까지 떠 있으면 승리',
      '내 차례: 배를 조금 옮기고(선택) → 화면을 뒤로 끌었다 놓아 한 방 쏘기',
      '이기는 법: 바람 화살표를 보고 세기·각도를 맞추기 (' + RMAX + '턴이 끝나면 HP 많은 배가 승리)',
    ],
    tutorial: [
      { text: '해적선 포격전이에요! 차례가 오면 대포를 한 번 쏴요. 다른 배를 모두 가라앉히면 이겨요.' },
      { text: '(선택) ◀ ▶ 버튼을 꾹 누르면 배가 조금 움직여요. 섬 뒤에 숨거나 쏘기 좋은 자리로 가요.', sel: '[data-tut="move"]' },
      { text: '쏘기: 화면 아무 데나 누르고, 쏘고 싶은 쪽의 반대로 끌었다 놓아요. 새총처럼요! 많이 끌수록 멀리 날아가요. 화면 끝에 손가락을 대고 있으면 계속 세져요.' },
      { text: '위쪽 가운데 바람 화살표를 꼭 보세요. 포탄이 그쪽으로 밀려요. 숫자가 클수록 많이 밀려요.' },
      { text: '특별한 포탄도 있어요. 산탄(3개로 퍼짐)과 무거운탄(큰 폭발)은 횟수가 정해져 있어요.', sel: '[data-tut="ammo"]' },
    ],
    rules: [
      { h: '목표', p: ['2–4명이 각자 해적선을 타고 차례대로 대포를 쏴요. 배마다 HP(체력) ' + HP0 + '으로 시작해요.', '포탄에 맞으면 HP가 줄고, 0이 되면 배가 가라앉아요. 마지막까지 떠 있는 배가 이겨요.'] },
      { h: '차례에 할 일', p: ['① (선택) ◀ ▶ 버튼을 꾹 눌러 배를 옮겨요. 한 턴에 최대 ' + MOVE + '칸. 섬·바위·다른 배는 지나갈 수 없어요.', '② 포탄 종류를 골라요(일반탄 / 산탄 / 무거운탄).', '③ 화면을 뒤로 끌었다 놓으면 발사! 쏘면 차례가 다음 사람에게 넘어가요.'] },
      { h: '점수·승리', p: ['다른 배가 모두 가라앉으면 남은 한 척이 이겨요. 남은 배들이 한 번에 같이 가라앉으면 공동 우승.', RMAX + '턴(모두 한 번씩 쏘면 1턴)이 끝나면 HP가 가장 많이 남은 배가 이겨요. 같으면 공동 우승.'] },
      { h: '조작 (쏘기)', p: ['화면 아무 데나 누른 채, 쏘고 싶은 쪽의 반대로 끌었다 놓아요. 새총과 같아요. 오른쪽 위로 쏘려면 왼쪽 아래로 끌어요.', '많이 끌수록 세게(멀리) 날아가요. 위에 각도와 세기(%)가 크게 나오고, 지난번에 쏜 값도 보여 줘요.', '화면 끝 때문에 더 못 끌 때는: 끝까지 끌면 100%가 되도록 눈금이 저절로 맞춰지고, 손가락을 화면 끝에 대고 있으면 세기가 계속 올라가요.', '흰 점선(조준선)은 포탄 길의 앞부분만 보여 줘요. 게임 설정의 ‘조준선’에서 끔 / 짧게(0.5초, 기본) / 길게(1.2초)를 고를 수 있어요. 나머지는 감으로!', '처음 누른 자리의 점선 원 안으로 돌아와 놓으면 취소돼요.', '가로 화면에서는 왼쪽 아래에 ◀ ▶, 오른쪽 아래에 포탄 버튼이 있어요. 세로로 해도 돼요.'] },
      { h: '바람', p: ['매 턴 바람이 바뀌어요. 위쪽 가운데 화살표 방향으로 포탄이 밀리고, 숫자(0–12)가 클수록 많이 밀려요.', '하늘의 바람 줄무늬와 돛대 깃발도 바람 방향을 보여 줘요.'] },
      { h: '포탄', p: ['일반탄: 무제한, 최대 피해 30.', '산탄: 한 판에 2번. 작은 포탄 3개가 부채꼴로 퍼져요(하나당 최대 13). 바람을 조금 더 타요.', '무거운 포탄: 한 판에 1번. 최대 피해 48에 폭발이 커요. 바람을 덜 타지만 조금 덜 날아가요.'] },
      { h: '피해', p: ['배(선체나 돛)에 바로 맞으면 최대 피해, 근처에 떨어지면 가까울수록 피해가 커요.', '내 배도 폭발에 다칠 수 있어요. 너무 가까이 쏘지 마세요.', '섬과 바위는 포탄을 막아 주는 엄폐물이에요(부서지지 않아요).'] },
      { h: '예시', p: ['바람이 → 6이고 적이 오른쪽에 있으면, 바람이 포탄을 밀어 주니 평소보다 조금 약하게 쏴요.', '적이 섬 뒤에 숨었으면 각도를 높여(60° 이상) 섬을 넘겨 떨어뜨려요.'] },
      { h: '바다', p: ['잔잔한 만: 바람이 약해요(최대 3).', '암초 해협: 높은 바위 기둥 사이로 쏴야 해요(바람 최대 6).', '폭풍의 바다: 비바람이 아주 세요(최대 11).', '노을 군도: 크고 작은 섬이 많아요(바람 최대 7).', '‘무작위’를 고르면 넷 중 하나가 나와요. 배 자리는 매 판 섞여요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 바람 계산이 정확하고, 배를 움직여 더 좋은 자리를 찾고, 약한 배를 먼저 노려요.'] },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _sim: { Ball, runShot, makeShot, blast, moveRange, landH, MAPS, WEP, DT, VMAX },
  });
})();
