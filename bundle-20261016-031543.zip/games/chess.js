/* 체스 — full-rules chess with an alpha-beta engine, vector pieces, tap/drag input. */
(function () {
  const L = window.Lounge, U = L.util;

  /* =====================================================================
   * Engine (0x88 board). Pieces: type 1..6 = P N B R Q K, +8 for black.
   * Squares: row 0 = rank 8 (FEN order), sq88 = row*16 + file.
   * Move int: from | to<<7 | promoType<<14 | flags<<17 (1 ep, 2 castle, 4 double push)
   * ===================================================================== */
  const CH = '.PNBRQK..pnbrqk';
  const VAL = [0, 100, 320, 330, 500, 900, 0];
  const N_D = [-33, -31, -18, -14, 14, 18, 31, 33], B_D = [-17, -15, 15, 17], R_D = [-16, -1, 1, 16];
  const K_D = [-17, -16, -15, -1, 1, 15, 16, 17];
  const MATE = 30000, INF = 32000, MAXPLY = 100;
  const to88 = (i) => ((i >> 3) << 4) | (i & 7);
  const to64 = (s) => ((s >> 4) << 3) | (s & 7);

  const bd = new Int8Array(128);
  let side = 0, castle = 0, ep = -1, hm = 0, hLo = 0, hHi = 0, gp = 0;
  const kSq = [0, 0];
  const HSIZE = 1400;
  const U_CAP = new Int8Array(HSIZE), U_CAS = new Int8Array(HSIZE), U_EP = new Int16Array(HSIZE), U_HM = new Int16Array(HSIZE);
  const U_HL = new Int32Array(HSIZE), U_HH = new Int32Array(HSIZE), HL = new Int32Array(HSIZE);
  const MV = new Int32Array(MAXPLY * 2 * 256), SC = new Int32Array(MAXPLY * 2 * 256);
  const CM = new Int8Array(128).fill(15);
  CM[116] = 12; CM[119] = 14; CM[112] = 13; CM[4] = 3; CM[7] = 11; CM[0] = 7;

  // zobrist (seeded so hashes are identical on every device)
  let seed = 0x9e3779b9;
  function rnd32() { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return (t ^ (t >>> 14)) | 0; }
  const zL = new Int32Array(16 * 128), zH = new Int32Array(16 * 128);
  for (let i = 0; i < zL.length; i++) { zL[i] = rnd32(); zH[i] = rnd32(); }
  const zCL = new Int32Array(16), zCH = new Int32Array(16), zEL = new Int32Array(128), zEH = new Int32Array(128);
  for (let i = 0; i < 16; i++) { zCL[i] = rnd32(); zCH[i] = rnd32(); }
  for (let i = 0; i < 128; i++) { zEL[i] = rnd32(); zEH[i] = rnd32(); }
  const zSL = rnd32(), zSH = rnd32();
  function zx(p, s) { hLo ^= zL[(p << 7) | s]; hHi ^= zH[(p << 7) | s]; }

  function computeHash() {
    hLo = 0; hHi = 0;
    for (let s = 0; s < 128; s++) { if (s & 0x88) { s += 7; continue; } if (bd[s]) zx(bd[s], s); }
    if (side) { hLo ^= zSL; hHi ^= zSH; }
    hLo ^= zCL[castle]; hHi ^= zCH[castle];
    if (ep >= 0) { hLo ^= zEL[ep]; hHi ^= zEH[ep]; }
  }

  function attacked(sq, by) {
    let a;
    if (by === 0) { a = sq + 15; if (!(a & 0x88) && bd[a] === 1) return true; a = sq + 17; if (!(a & 0x88) && bd[a] === 1) return true; }
    else { a = sq - 15; if (!(a & 0x88) && bd[a] === 9) return true; a = sq - 17; if (!(a & 0x88) && bd[a] === 9) return true; }
    const c = by << 3, kn = 2 | c, kg = 6 | c, bi = 3 | c, ro = 4 | c, qu = 5 | c;
    for (let i = 0; i < 8; i++) { a = sq + N_D[i]; if (!(a & 0x88) && bd[a] === kn) return true; }
    for (let i = 0; i < 8; i++) { a = sq + K_D[i]; if (!(a & 0x88) && bd[a] === kg) return true; }
    for (let i = 0; i < 4; i++) {
      const d = B_D[i]; a = sq + d;
      while (!(a & 0x88)) { const p = bd[a]; if (p) { if (p === bi || p === qu) return true; break; } a += d; }
    }
    for (let i = 0; i < 4; i++) {
      const d = R_D[i]; a = sq + d;
      while (!(a & 0x88)) { const p = bd[a]; if (p) { if (p === ro || p === qu) return true; break; } a += d; }
    }
    return false;
  }
  const inCheck = () => attacked(kSq[side], side ^ 1);

  function gen(start, capsOnly) {
    let n = start;
    const us = side, them = us ^ 1;
    const fwd = us ? 16 : -16, startRow = us ? 1 : 6, promoRow = us ? 7 : 0;
    for (let sq = 0; sq < 128; sq++) {
      if (sq & 0x88) { sq += 7; continue; }
      const p = bd[sq];
      if (!p || (p >> 3) !== us) continue;
      const t = p & 7;
      if (t === 1) {
        let to = sq + fwd;
        if (!(to & 0x88) && !bd[to]) {
          if ((to >> 4) === promoRow) {
            MV[n++] = sq | (to << 7) | (5 << 14);
            if (!capsOnly) { MV[n++] = sq | (to << 7) | (4 << 14); MV[n++] = sq | (to << 7) | (3 << 14); MV[n++] = sq | (to << 7) | (2 << 14); }
          } else if (!capsOnly) {
            MV[n++] = sq | (to << 7);
            if ((sq >> 4) === startRow && !bd[to + fwd]) MV[n++] = sq | ((to + fwd) << 7) | (4 << 17);
          }
        }
        for (let k = -1; k <= 1; k += 2) {
          to = sq + fwd + k;
          if (to & 0x88) continue;
          const q = bd[to];
          if (q && (q >> 3) === them) {
            if ((to >> 4) === promoRow) {
              MV[n++] = sq | (to << 7) | (5 << 14);
              if (!capsOnly) { MV[n++] = sq | (to << 7) | (4 << 14); MV[n++] = sq | (to << 7) | (3 << 14); MV[n++] = sq | (to << 7) | (2 << 14); }
            } else MV[n++] = sq | (to << 7);
          } else if (to === ep) MV[n++] = sq | (to << 7) | (1 << 17);
        }
      } else if (t === 2 || t === 6) {
        const D = t === 2 ? N_D : K_D;
        for (let i = 0; i < 8; i++) {
          const to = sq + D[i];
          if (to & 0x88) continue;
          const q = bd[to];
          if (!q) { if (!capsOnly) MV[n++] = sq | (to << 7); }
          else if ((q >> 3) === them) MV[n++] = sq | (to << 7);
        }
      } else {
        const D = t === 3 ? B_D : t === 4 ? R_D : K_D, nd = D.length;
        for (let i = 0; i < nd; i++) {
          const d = D[i];
          let to = sq + d;
          while (!(to & 0x88)) {
            const q = bd[to];
            if (!q) { if (!capsOnly) MV[n++] = sq | (to << 7); }
            else { if ((q >> 3) === them) MV[n++] = sq | (to << 7); break; }
            to += d;
          }
        }
      }
    }
    if (!capsOnly && castle) {
      if (us === 0 && bd[116] === 6) {
        if ((castle & 1) && bd[119] === 4 && !bd[117] && !bd[118] && !attacked(116, 1) && !attacked(117, 1) && !attacked(118, 1)) MV[n++] = 116 | (118 << 7) | (2 << 17);
        if ((castle & 2) && bd[112] === 4 && !bd[115] && !bd[114] && !bd[113] && !attacked(116, 1) && !attacked(115, 1) && !attacked(114, 1)) MV[n++] = 116 | (114 << 7) | (2 << 17);
      } else if (us === 1 && bd[4] === 14) {
        if ((castle & 4) && bd[7] === 12 && !bd[5] && !bd[6] && !attacked(4, 0) && !attacked(5, 0) && !attacked(6, 0)) MV[n++] = 4 | (6 << 7) | (2 << 17);
        if ((castle & 8) && bd[0] === 12 && !bd[3] && !bd[2] && !bd[1] && !attacked(4, 0) && !attacked(3, 0) && !attacked(2, 0)) MV[n++] = 4 | (2 << 7) | (2 << 17);
      }
    }
    return n;
  }

  function rookCastle(t) { return t === 118 ? [119, 117] : t === 114 ? [112, 115] : t === 6 ? [7, 5] : [0, 3]; }

  function make(m) {
    const f = m & 127, t = (m >> 7) & 127, pr = (m >> 14) & 7, fl = m >> 17;
    U_CAS[gp] = castle; U_EP[gp] = ep; U_HM[gp] = hm; U_HL[gp] = hLo; U_HH[gp] = hHi;
    const p = bd[f];
    let cap = bd[t];
    zx(p, f);
    if (cap) zx(cap, t);
    if (fl & 1) { const cs = t + (side ? -16 : 16); cap = bd[cs]; zx(cap, cs); bd[cs] = 0; }
    U_CAP[gp] = cap;
    const np = pr ? (pr | (side << 3)) : p;
    bd[t] = np; bd[f] = 0; zx(np, t);
    if (fl & 2) { const rc = rookCastle(t), r = bd[rc[0]]; bd[rc[1]] = r; bd[rc[0]] = 0; zx(r, rc[0]); zx(r, rc[1]); }
    if ((p & 7) === 6) kSq[side] = t;
    hLo ^= zCL[castle]; hHi ^= zCH[castle];
    castle &= CM[f] & CM[t];
    hLo ^= zCL[castle]; hHi ^= zCH[castle];
    if (ep >= 0) { hLo ^= zEL[ep]; hHi ^= zEH[ep]; }
    ep = -1;
    if (fl & 4) {
      const ex = side ? 1 : 9;
      if ((!((t - 1) & 0x88) && bd[t - 1] === ex) || (!((t + 1) & 0x88) && bd[t + 1] === ex)) { ep = (f + t) >> 1; hLo ^= zEL[ep]; hHi ^= zEH[ep]; }
    }
    hm = ((p & 7) === 1 || cap) ? 0 : hm + 1;
    side ^= 1; hLo ^= zSL; hHi ^= zSH;
    gp++; HL[gp] = hLo;
  }
  function unmake(m) {
    gp--; side ^= 1;
    const f = m & 127, t = (m >> 7) & 127, pr = (m >> 14) & 7, fl = m >> 17;
    const p = pr ? (1 | (side << 3)) : bd[t];
    bd[f] = p;
    if (fl & 1) { bd[t] = 0; bd[t + (side ? -16 : 16)] = U_CAP[gp]; } else bd[t] = U_CAP[gp];
    if (fl & 2) { const rc = rookCastle(t); bd[rc[0]] = bd[rc[1]]; bd[rc[1]] = 0; }
    if ((p & 7) === 6) kSq[side] = f;
    castle = U_CAS[gp]; ep = U_EP[gp]; hm = U_HM[gp]; hLo = U_HL[gp]; hHi = U_HH[gp];
  }

  /* --- loading / exporting --- */
  function setBoard(b64, stm, cas, ep64, half) {
    bd.fill(0);
    for (let i = 0; i < 64; i++) {
      const c = CH.indexOf(b64[i]);
      const s = to88(i);
      bd[s] = c > 0 ? c : 0;
      if (c === 6) kSq[0] = s; else if (c === 14) kSq[1] = s;
    }
    side = stm; hm = half | 0;
    castle = (cas.includes('K') ? 1 : 0) | (cas.includes('Q') ? 2 : 0) | (cas.includes('k') ? 4 : 0) | (cas.includes('q') ? 8 : 0);
    ep = ep64 >= 0 ? to88(ep64) : -1;
    computeHash();
    gp = 0; HL[0] = hLo;
  }
  function loadState(s) {
    setBoard(s.b, s.t, s.c, s.ep, s.hm);
    const rep = s.rep || [];
    // game history (for repetition detection during search)
    const n = Math.min(rep.length, 300);
    for (let i = 0; i < n - 1; i++) HL[i] = parseInt(rep[rep.length - n + i], 36) | 0;
    gp = Math.max(0, n - 1); HL[gp] = hLo;
  }
  function loadFEN(fen) {
    const [pl, stm, cas, eps, half] = fen.split(' ');
    let b = '';
    for (const ch of pl) { if (ch === '/') continue; if (/\d/.test(ch)) b += '.'.repeat(+ch); else b += ch; }
    let e = -1;
    if (eps && eps !== '-') e = (8 - +eps[1]) * 8 + (eps.charCodeAt(0) - 97);
    setBoard(b, stm === 'b' ? 1 : 0, cas || '-', e, half || 0);
  }
  function boardStr() { let s = ''; for (let i = 0; i < 64; i++) s += CH[bd[to88(i)]]; return s; }
  function castleStr() { return ((castle & 1 ? 'K' : '') + (castle & 2 ? 'Q' : '') + (castle & 4 ? 'k' : '') + (castle & 8 ? 'q' : '')) || '-'; }
  const PROMO_CH = ['', '', 'n', 'b', 'r', 'q'];

  function legalMoves() {
    const base = MAXPLY * 256;
    const n = gen(base, false), out = [];
    for (let i = base; i < n; i++) {
      const m = MV[i];
      make(m);
      if (!attacked(kSq[side ^ 1], side)) out.push(m);
      unmake(m);
    }
    return out;
  }
  function mInfo(m) { return { f: to64(m & 127), t: to64((m >> 7) & 127), p: PROMO_CH[(m >> 14) & 7], fl: m >> 17, m }; }

  function perft(d, ply) {
    ply = ply || 0;
    const base = ply * 256, n = gen(base, false);
    let c = 0;
    for (let i = base; i < n; i++) {
      const m = MV[i];
      make(m);
      if (!attacked(kSq[side ^ 1], side)) c += d === 1 ? 1 : perft(d - 1, ply + 1);
      unmake(m);
    }
    return c;
  }

  function insufficient() {
    let minors = [0, 0], bishopsColor = [[], []];
    for (let s = 0; s < 128; s++) {
      if (s & 0x88) { s += 7; continue; }
      const p = bd[s]; if (!p) continue;
      const t = p & 7, c = p >> 3;
      if (t === 1 || t === 4 || t === 5) return false;
      if (t === 2 || t === 3) { minors[c]++; if (t === 3) bishopsColor[c].push(((s >> 4) + (s & 7)) & 1); }
    }
    if (minors[0] + minors[1] <= 1) return true;
    // only bishops, all on the same square colour
    if (minors[0] === bishopsColor[0].length && minors[1] === bishopsColor[1].length) {
      const all = bishopsColor[0].concat(bishopsColor[1]);
      if (all.every((x) => x === all[0])) return true;
    }
    return false;
  }

  /* --- evaluation --- */
  const PST = [null,
    [0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10, 25, 25, 10, 5, 5, 0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0],
    [-50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30, -30, 5, 15, 20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 5, 5, 0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50],
    [-20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10, -10, 5, 5, 10, 10, 5, 5, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10, -10, 5, 0, 0, 0, 0, 5, -10, -20, -10, -10, -10, -10, -10, -10, -20],
    [0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0],
    [-20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5, 0, 5, 5, 5, 5, 0, -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20],
    [-30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20, -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20],
  ];
  const KEG = [-50, -40, -30, -20, -20, -30, -40, -50, -30, -20, -10, 0, 0, -10, -20, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -30, 0, 0, 0, 0, -30, -30, -50, -30, -30, -30, -30, -30, -30, -50];
  const PADV = [0, 0, 8, 16, 30, 50, 80, 0]; // endgame bonus by ranks advanced
  const PH = [0, 0, 1, 1, 2, 4, 0];
  const cmd = (s) => { const r = s >> 4, f = s & 7; return Math.max(3 - r, r - 4) + Math.max(3 - f, f - 4); };

  function evaluate() {
    let base = 0, kmg = 0, keg = 0, peg = 0, phase = 0;
    let wb = 0, bb = 0, wm = 0, bm = 0, wp = 0, bp = 0, heavy = 0;
    for (let s = 0; s < 128; s++) {
      if (s & 0x88) { s += 7; continue; }
      const p = bd[s]; if (!p) continue;
      const t = p & 7, black = p >> 3, i = ((s >> 4) << 3) | (s & 7), j = black ? i ^ 56 : i;
      phase += PH[t];
      if (t === 6) { const a = PST[6][j], e = KEG[j]; if (black) { kmg -= a; keg -= e; } else { kmg += a; keg += e; } continue; }
      const v = VAL[t] + PST[t][j];
      if (black) { base -= v; bm += VAL[t]; } else { base += v; wm += VAL[t]; }
      if (t === 1) { const adv = 7 - (j >> 3); if (black) { peg -= PADV[adv]; bp++; } else { peg += PADV[adv]; wp++; } }
      else if (t === 3) { if (black) bb++; else wb++; }
      if (t >= 4) heavy++;
    }
    if (!wp && !bp && !heavy && wm <= 330 && bm <= 330) return 0;
    if (wb >= 2) base += 30;
    if (bb >= 2) base -= 30;
    if (phase > 24) phase = 24;
    let sc = base + ((kmg * phase + (keg + peg) * (24 - phase)) / 24 | 0);
    // mop-up: drive a lone-ish king to the edge and bring ours closer
    const diff = wm - bm;
    if (phase <= 12 && Math.abs(diff) >= 300) {
      const wk = kSq[0], bk = kSq[1];
      const dist = Math.abs((wk >> 4) - (bk >> 4)) + Math.abs((wk & 7) - (bk & 7));
      const mop = (diff > 0 ? cmd(bk) : cmd(wk)) * 10 + (14 - dist) * 4;
      sc += diff > 0 ? mop : -mop;
      // without pawns a small edge rarely wins
      if (diff > 0 && !wp && wm - bm < 400) sc = sc / 4 | 0;
      if (diff < 0 && !bp && bm - wm < 400) sc = sc / 4 | 0;
    }
    return (side ? -sc : sc) + 10;
  }

  /* --- search --- */
  const TT_BITS = 18, TT_N = 1 << TT_BITS, TT_MASK = TT_N - 1;
  const ttKey = new Int32Array(TT_N), ttMove = new Int32Array(TT_N), ttScore = new Int16Array(TT_N), ttDepth = new Int8Array(TT_N), ttFlag = new Int8Array(TT_N);
  const killers = new Int32Array(MAXPLY * 2), hist = new Int32Array(16 * 128);
  let nodes = 0, deadline = 0, stop = false, canStop = false;
  const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

  function isRep() {
    const lim = Math.max(0, gp - hm);
    for (let i = gp - 2; i >= lim; i -= 2) if (HL[i] === hLo) return true;
    return false;
  }
  function scoreMoves(base, n, ply, ttm) {
    for (let i = base; i < n; i++) {
      const m = MV[i], f = m & 127, t = (m >> 7) & 127, pr = (m >> 14) & 7, fl = m >> 17;
      let s;
      if (m === ttm) s = 4000000;
      else if (bd[t] || (fl & 1)) s = 2000000 + ((bd[t] & 7) || 1) * 16 - (bd[f] & 7);
      else if (pr === 5) s = 1900000;
      else if (m === killers[ply * 2]) s = 1800000;
      else if (m === killers[ply * 2 + 1]) s = 1700000;
      else s = Math.min(1600000, hist[(bd[f] << 7) | t]) - (pr ? 1000 : 0);
      SC[i] = s;
    }
  }
  function pick(i, n) {
    let b = i, bs = SC[i];
    for (let j = i + 1; j < n; j++) if (SC[j] > bs) { bs = SC[j]; b = j; }
    if (b !== i) { const tm = MV[i]; MV[i] = MV[b]; MV[b] = tm; const ts = SC[i]; SC[i] = SC[b]; SC[b] = ts; }
    return MV[i];
  }
  function timeUp() { if ((++nodes & 1023) === 0 && canStop && now() > deadline) stop = true; return stop; }

  function qsearch(alpha, beta, ply) {
    if (timeUp()) return 0;
    const stand = evaluate();
    if (stand >= beta) return stand;
    if (stand > alpha) alpha = stand;
    if (ply >= MAXPLY * 2 - 2) return stand;
    const base = ply * 256, n = gen(base, true);
    scoreMoves(base, n, ply, 0);
    for (let i = base; i < n; i++) {
      const m = pick(i, n);
      // delta pruning: hopeless captures
      const t = (m >> 7) & 127;
      if (!((m >> 14) & 7) && stand + VAL[(bd[t] & 7) || 1] + 200 < alpha) continue;
      make(m);
      if (attacked(kSq[side ^ 1], side)) { unmake(m); continue; }
      const sc = -qsearch(-beta, -alpha, ply + 1);
      unmake(m);
      if (stop) return 0;
      if (sc > alpha) { alpha = sc; if (sc >= beta) return sc; }
    }
    return alpha;
  }

  /* 어려움 only: null-move pruning + late-move reductions (ADV) */
  let ADV = false;
  const NUL = new Int8Array(MAXPLY * 2 + 2);
  function hasPieces() {
    for (let s = 0; s < 128; s++) { if (s & 0x88) { s += 7; continue; } const p = bd[s]; if (p && (p >> 3) === side && (p & 7) > 1 && (p & 7) < 6) return true; }
    return false;
  }
  function makeNull() {
    U_EP[gp] = ep; U_HM[gp] = hm; U_HL[gp] = hLo; U_HH[gp] = hHi;
    if (ep >= 0) { hLo ^= zEL[ep]; hHi ^= zEH[ep]; }
    ep = -1; hm = 0;
    side ^= 1; hLo ^= zSL; hHi ^= zSH;
    gp++; HL[gp] = hLo;
  }
  function unmakeNull() { gp--; side ^= 1; ep = U_EP[gp]; hm = U_HM[gp]; hLo = U_HL[gp]; hHi = U_HH[gp]; }
  function search(depth, alpha, beta, ply) {
    if (timeUp()) return 0;
    if (ply > 0 && (hm >= 100 || isRep())) return 0;
    const chk = inCheck();
    if (chk && ply < MAXPLY) depth++;
    if (depth <= 0 || ply >= MAXPLY) return qsearch(alpha, beta, ply);
    NUL[ply + 1] = 0;
    if (ADV && !chk && ply > 0 && !NUL[ply] && depth >= 3 && beta < MATE - 500 && beta > -MATE + 500 && hasPieces() && evaluate() >= beta) {
      makeNull(); NUL[ply + 1] = 1;
      const ns = -search(depth - 3, -beta, -beta + 1, ply + 1);
      NUL[ply + 1] = 0; unmakeNull();
      if (stop) return 0;
      if (ns >= beta) return beta;
    }
    const ti = hLo & TT_MASK;
    let ttm = 0;
    if (ttKey[ti] === hHi) {
      ttm = ttMove[ti];
      if (ply > 0 && ttDepth[ti] >= depth) {
        let s = ttScore[ti];
        if (s > MATE - 500) s -= ply; else if (s < -MATE + 500) s += ply;
        const fl = ttFlag[ti];
        if (fl === 0 || (fl === 1 && s >= beta) || (fl === 2 && s <= alpha)) return s;
      }
    }
    const base = ply * 256, n = gen(base, false);
    scoreMoves(base, n, ply, ttm);
    let best = -INF, bestM = 0, legal = 0;
    const a0 = alpha;
    for (let i = base; i < n; i++) {
      const m = pick(i, n);
      make(m);
      if (attacked(kSq[side ^ 1], side)) { unmake(m); continue; }
      legal++;
      let sc;
      if (ADV && depth >= 3 && !chk && legal > 4 && !U_CAP[gp - 1] && !((m >> 14) & 7) && m !== killers[ply * 2] && m !== killers[ply * 2 + 1] && !inCheck()) {
        sc = -search(depth - 2, -alpha - 1, -alpha, ply + 1);
        if (sc > alpha && !stop) sc = -search(depth - 1, -beta, -alpha, ply + 1);
      } else sc = -search(depth - 1, -beta, -alpha, ply + 1);
      unmake(m);
      if (stop) return 0;
      if (sc > best) {
        best = sc; bestM = m;
        if (sc > alpha) {
          alpha = sc;
          if (sc >= beta) {
            const t = (m >> 7) & 127;
            if (!bd[t] && !((m >> 17) & 1) && !((m >> 14) & 7)) {
              if (killers[ply * 2] !== m) { killers[ply * 2 + 1] = killers[ply * 2]; killers[ply * 2] = m; }
              hist[(bd[m & 127] << 7) | t] += depth * depth;
            }
            break;
          }
        }
      }
    }
    if (!legal) return chk ? -MATE + ply : 0;
    let st = best;
    if (st > MATE - 500) st += ply; else if (st < -MATE + 500) st -= ply;
    ttKey[ti] = hHi; ttMove[ti] = bestM; ttScore[ti] = st; ttDepth[ti] = depth;
    ttFlag[ti] = best >= beta ? 1 : best <= a0 ? 2 : 0;
    return best;
  }

  const CFG = { budget: 250, noisePlies: 10, noise: 22 };
  function think(budget, noisy, maxDepth, adv) {
    ADV = !!adv;
    const t0 = now();
    deadline = t0 + budget; stop = false; nodes = 0; canStop = false;
    killers.fill(0);
    for (let i = 0; i < hist.length; i++) hist[i] >>= 2;
    const legal = legalMoves();
    if (legal.length === 0) return { m: 0 };
    if (legal.length === 1) return { m: legal[0], depth: 0, nodes: 0, ms: now() - t0 };
    // initial root ordering
    const base = 0;
    for (let i = 0; i < legal.length; i++) MV[base + i] = legal[i];
    const ti = hLo & TT_MASK;
    scoreMoves(base, legal.length, 0, ttKey[ti] === hHi ? ttMove[ti] : 0);
    let order = legal.map((m, i) => [m, SC[i]]).sort((a, b) => b[1] - a[1]).map((x) => x[0]);
    const noise = new Map(order.map((m) => [m, noisy ? Math.floor(Math.random() * CFG.noise) : 0]));
    let best = order[0], bestScore = 0, depthDone = 0;
    for (let depth = 1; depth <= (maxDepth || 60); depth++) {
      canStop = depth > 1;
      let alpha = -INF, iterBest = 0, iterScore = -INF;
      const scores = new Map();
      for (const m of order) {
        const nz = noise.get(m);
        make(m);
        const sc = -search(depth - 1, -INF, -(alpha - nz), 1) + nz;
        unmake(m);
        if (stop) break;
        scores.set(m, sc);
        if (sc > iterScore) { iterScore = sc; iterBest = m; }
        if (sc > alpha) alpha = sc;
      }
      if (stop) break;
      best = iterBest; bestScore = iterScore; depthDone = depth;
      order = order.slice().sort((a, b) => (b === best) - (a === best) || (scores.get(b) || -INF) - (scores.get(a) || -INF));
      if (Math.abs(bestScore) > MATE - 200) break;
      if (now() - t0 > budget * (adv ? 0.42 : 0.5)) break;
    }
    ADV = false;
    return { m: best, score: bestScore, depth: depthDone, nodes, ms: now() - t0 };
  }
  /* 쉬움: full-window shallow scores for every root move, then a human-like (often sloppy) pick */
  function rootScores(depth) {
    deadline = now() + 1e9; stop = false; canStop = false; ADV = false;
    const out = [];
    for (const m of legalMoves()) {
      make(m);
      const sc = depth <= 1 ? -qsearch(-INF, INF, 1) : -search(depth - 1, -INF, INF, 1);
      unmake(m);
      out.push([m, sc]);
    }
    return out.sort((a, b) => b[1] - a[1]);
  }
  function easyMove() {
    const r = rootScores(Math.random() < 0.55 ? 1 : 2);
    if (!r.length) return 0;
    const best = r[0][1];
    if (best > MATE - 200 && Math.random() < 0.7) return r[0][0]; // usually sees a mate in one
    const x = Math.random();
    if (x < 0.12) { // blunder: anything that is not suicidal-by-mate, often hangs a piece
      const pool = r.filter((e) => e[1] > -MATE + 200);
      return (pool.length ? pool : r)[(Math.random() * (pool.length || r.length)) | 0][0];
    }
    if (x < 0.45) { // among the top few, ignoring what they cost (up to ~a minor piece)
      const pool = r.filter((e) => e[1] >= best - 320).slice(0, 4);
      return pool[(Math.random() * pool.length) | 0][0];
    }
    let bm = r[0][0], bs = -INF;
    for (const [m, sc] of r) { const v = sc + Math.random() * 70; if (v > bs) { bs = v; bm = m; } }
    return bm;
  }

  /* =====================================================================
   * Game rules on the JSON state
   * ===================================================================== */
  const START = 'rnbqkbnrpppppppp' + '.'.repeat(32) + 'PPPPPPPPRNBQKBNR';
  function init() {
    setBoard(START, 0, 'KQkq', -1, 0);
    return { b: START, t: 0, c: 'KQkq', ep: -1, hm: 0, fm: 1, last: null, cap: '', st: null, ck: 0, seq: 0, rep: [(hLo >>> 0).toString(36)],
      ml: '', m0: 0, dr: null, nd: -1, u: [], ev: null };
  }
  /* while a draw offer is pending the opponent of the offerer must answer it */
  function actor(s) { return s.st ? null : s.dr ? 1 - s.dr.by : s.t; }

  /* SAN for move `mv` (mInfo) given the pre-move legal list; suffix added after the move */
  const FILES = 'abcdefgh';
  const sqName = (i) => FILES[i & 7] + (8 - (i >> 3));
  function sanOf(mv, moves, b) {
    if (mv.fl & 2) return (mv.t & 7) === 6 ? 'O-O' : 'O-O-O';
    const pc = b[mv.f].toUpperCase(), capture = b[mv.t] !== '.' || (mv.fl & 1);
    if (pc === 'P') return (capture ? FILES[mv.f & 7] + 'x' : '') + sqName(mv.t) + (mv.p ? '=' + mv.p.toUpperCase() : '');
    let dis = '';
    const others = moves.filter((m) => m.t === mv.t && m.f !== mv.f && b[m.f] === b[mv.f]);
    if (others.length) {
      if (!others.some((m) => (m.f & 7) === (mv.f & 7))) dis = FILES[mv.f & 7];
      else if (!others.some((m) => (m.f >> 3) === (mv.f >> 3))) dis = String(8 - (mv.f >> 3));
      else dis = sqName(mv.f);
    }
    return pc + dis + (capture ? 'x' : '') + sqName(mv.t);
  }
  /* undo support: snapshot of the position before a ply. `r` (the repetition list) is only kept when
     that ply reset it — otherwise it can be rebuilt by dropping the last key. */
  function snap(s) { return { b: s.b, t: s.t, c: s.c, ep: s.ep, hm: s.hm, fm: s.fm, cap: s.cap, ck: s.ck, last: s.last, nd: s.nd }; }
  const LIMIT = 2380;
  function fit(s) {
    const size = () => JSON.stringify(s).length;
    let n = size();
    if (n <= LIMIT) return;
    let toks = s.ml ? s.ml.split(' ') : [];
    while (n > LIMIT && toks.length > 24) { const k = Math.min(toks.length - 24, Math.ceil((n - LIMIT) / 4)); toks = toks.slice(k); s.m0 += k; s.ml = toks.join(' '); n = size(); }
    if (n > LIMIT && s.u.length) { s.u = []; n = size(); }
    while (n > LIMIT && toks.length) { toks = toks.slice(2); s.m0 += 2; s.ml = toks.join(' '); n = size(); }
  }

  function apply(s, seat, a) {
    if (s.st) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a) throw new Error('bad action');
    if (s.dr) { // only an answer to the pending offer is allowed
      if (a.type !== 'drawReply') throw new Error('answer the draw offer');
      s.seq++;
      const by = s.dr.by;
      s.dr = null;
      if (a.ok) s.st = { r: 'agree', w: -1 };
      else s.ev = { id: s.seq, k: 'n', by };
      return s;
    }
    if (a.type === 'resign') {
      s.seq++;
      s.st = { r: 'resign', w: 1 - seat };
      return s;
    }
    if (a.type === 'draw') {
      if (s.nd === seat) throw new Error('already offered');
      s.seq++;
      s.dr = { by: seat }; s.nd = seat;
      s.ev = { id: s.seq, k: 'o', by: seat };
      return s;
    }
    if (a.type === 'undo') {
      // revert this player's last move and the opponent's reply (two plies)
      if (!s.u || s.u.length !== 2 || s.u[0].t !== seat) throw new Error('nothing to undo');
      const [o, nw] = s.u;
      let r = nw.r || s.rep.slice(0, -1);
      r = o.r || r.slice(0, -1);
      if (!r.length) throw new Error('nothing to undo');
      Object.assign(s, { b: o.b, t: o.t, c: o.c, ep: o.ep, hm: o.hm, fm: o.fm, cap: o.cap, ck: o.ck, last: o.last, nd: o.nd, rep: r });
      const toks = s.ml ? s.ml.split(' ') : [];
      const drop = Math.min(2, toks.length);
      s.ml = toks.slice(0, toks.length - drop).join(' ');
      if (drop < 2) s.m0 = Math.max(0, s.m0 - (2 - drop));
      s.u = [];
      s.seq++;
      s.ev = { id: s.seq, k: 'u', by: seat };
      return s;
    }
    if (a.type !== 'move') throw new Error('bad action');
    loadState(s);
    const moves = legalMoves().map(mInfo);
    const mv = moves.find((m) => m.f === a.f && m.t === a.t && m.p === (a.p || ''));
    if (!mv) throw new Error('illegal move');
    const before = snap(s), repBefore = s.rep;
    let san = sanOf(mv, moves, s.b);
    const t88 = to88(mv.t);
    let capCh = bd[t88] ? CH[bd[t88]] : '';
    if (mv.fl & 1) capCh = side ? 'P' : 'p';
    const mover = CH[bd[to88(mv.f)]];
    make(mv.m);
    s.seq++;
    s.b = boardStr(); s.t = side; s.c = castleStr(); s.ep = ep >= 0 ? to64(ep) : -1; s.hm = hm;
    if (side === 0) s.fm++;
    s.cap += capCh;
    s.last = { f: mv.f, t: mv.t, id: s.seq, pc: mover };
    if (capCh) s.last.x = capCh;
    if (mv.p) s.last.p = mv.p;
    if (mv.fl & 2) s.last.k = 'c';
    if (mv.fl & 1) s.last.k = 'e';
    const key = (hLo >>> 0).toString(36);
    if (hm === 0) { s.rep = [key]; before.r = repBefore; } else s.rep.push(key);
    if (s.rep.length > 110) s.rep = s.rep.slice(-110);
    const chk = inCheck();
    s.ck = chk ? 1 : 0;
    const replies = legalMoves().length;
    san += chk ? (replies ? '+' : '#') : '';
    s.ml = s.ml ? s.ml + ' ' + san : san;
    if (s.nd !== seat) s.nd = -1; // the opponent moved: the other side may offer again
    s.u = (s.u || []).slice(-1).concat([before]);
    if (!replies) s.st = chk ? { r: 'mate', w: seat } : { r: 'stale', w: -1 };
    else if (hm >= 100) s.st = { r: '50', w: -1 };
    else if (insufficient()) s.st = { r: 'ins', w: -1 };
    else if (s.rep.filter((k) => k === key).length >= 3) s.st = { r: 'rep', w: -1 };
    fit(s);
    return s;
  }

  const SIDE = ['백', '흑'];
  function result(s) {
    if (!s.st) return null;
    const r = s.st.r, w = s.st.w, moves = (s.fm - (s.t === 0 ? 1 : 0)) + '수';
    if (r === 'mate') return { winners: [w], title: '체크메이트', text: SIDE[w] + ' 승리 · ' + moves };
    if (r === 'resign') return { winners: [w], title: SIDE[1 - w] + ' 기권', text: SIDE[w] + ' 승리 · ' + moves };
    if (r === 'stale') return { winners: [], title: '스테일메이트', text: '둘 수 있는 수가 없지만 체크가 아니라서 무승부예요.' };
    if (r === '50') return { winners: [], title: '무승부 (50수)', text: '50수 동안 폰 이동도, 잡은 기물도 없었어요.' };
    if (r === 'ins') return { winners: [], title: '무승부 (기물 부족)', text: '양쪽 모두 체크메이트할 기물이 남지 않았어요.' };
    if (r === 'rep') return { winners: [], title: '무승부 (3회 반복)', text: '같은 국면이 세 번 나왔어요.' };
    if (r === 'agree') return { winners: [], title: '무승부 (합의)', text: '무승부 제안을 받아들였어요 · ' + moves };
    return { winners: [], title: '무승부' };
  }

  const DRAW_OK = 30; // AI accepts a draw when its own search says it is at most +0.3 pawns (any move number, as in the official rules)
  /* per-seat level: 1 쉬움 · 2 보통 · 3 어려움 */
  const LVL = { 1: { draw: 0 }, 2: { budget: CFG.budget, draw: 160 }, 3: { budget: 600, draw: 400 } };
  function drawAnswer(s, seat, lv) {
    loadState(s); // side to move = the offerer
    ownTT(lv);
    let sc;
    if (lv === 1) { const r = rootScores(1); sc = r.length ? r[0][1] : evaluate(); }
    else { const r = think(LVL[lv].draw, false, 0, lv === 3); sc = typeof r.score === 'number' ? r.score : evaluate(); }
    const mine = seat === s.t ? sc : -sc;
    return mine <= DRAW_OK;
  }
  /* each level keeps its own search memory: a bot must not reuse the deeper results of another level (AI vs AI on one device) */
  let ttOwner = 0;
  function ownTT(lv) { if (ttOwner !== lv) { ttKey.fill(0); hist.fill(0); ttOwner = lv; } }
  function ai(s, seat, lv) {
    lv = lv === 1 || lv === 3 ? lv : 2;
    if (s.dr) return { type: 'drawReply', ok: drawAnswer(s, seat, lv) };
    loadState(s);
    ownTT(lv);
    let m;
    if (lv === 1) m = easyMove();
    else {
      const r = lv === 3 ? think(LVL[3].budget, s.fm <= 3, 0, CFG.adv !== false) : think(CFG.budget, s.fm <= CFG.noisePlies);
      m = r.m;
      if (CFG.log) CFG.log(r);
    }
    if (!m) { const l = legalMoves(); m = l[0]; }
    const i = mInfo(m);
    const a = { type: 'move', f: i.f, t: i.t };
    if (i.p) a.p = i.p;
    return a;
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 650 : lv === 3 ? 60 : 300; }

  function legalFromState(s) { loadState(s); return legalMoves().map(mInfo); }

  /* =====================================================================
   * View
   * ===================================================================== */
  const PV = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
  const isW = (c) => c >= 'A' && c <= 'Z';
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace';
  const COL = {
    light: '#ecdcbc', dark: '#a87650', rail0: '#5b3a25', rail1: '#3a2416', brass: '#e3ae45',
    wFill0: '#fbf4e4', wFill1: '#dccaa6', wLine: '#2b1d15', bFill0: '#3d3442', bFill1: '#1b161e', bLine: '#e8d9bb',
  };
  const PROMOS = [['q', '퀸'], ['r', '룩'], ['b', '비숍'], ['n', '나이트']];

  /* piece silhouettes in a unit box (0..1), drawn as fill + outline */
  function piecePaths(ctx, t) {
    const parts = [];
    const P = () => { const p = new Path2D(); parts.push(p); return p; };
    const base = (y, w) => { const p = P(); const x = 0.5 - w / 2; p.moveTo(x + 0.04, y); p.lineTo(x + w - 0.04, y); p.quadraticCurveTo(x + w, y, x + w, y + 0.04); p.lineTo(x + w, y + 0.07); p.lineTo(x, y + 0.07); p.lineTo(x, y + 0.04); p.quadraticCurveTo(x, y, x + 0.04, y); p.closePath(); };
    if (t === 'p') {
      let p = P(); p.moveTo(0.34, 0.8); p.quadraticCurveTo(0.36, 0.6, 0.44, 0.5); p.lineTo(0.56, 0.5); p.quadraticCurveTo(0.64, 0.6, 0.66, 0.8); p.closePath();
      p = P(); p.ellipse(0.5, 0.49, 0.13, 0.045, 0, 0, Math.PI * 2);
      p = P(); p.arc(0.5, 0.33, 0.12, 0, Math.PI * 2);
      base(0.78, 0.48);
    } else if (t === 'r') {
      let p = P();
      p.moveTo(0.27, 0.18); p.lineTo(0.37, 0.18); p.lineTo(0.37, 0.25); p.lineTo(0.45, 0.25); p.lineTo(0.45, 0.18); p.lineTo(0.55, 0.18);
      p.lineTo(0.55, 0.25); p.lineTo(0.63, 0.25); p.lineTo(0.63, 0.18); p.lineTo(0.73, 0.18); p.lineTo(0.73, 0.35); p.lineTo(0.66, 0.4);
      p.lineTo(0.68, 0.72); p.lineTo(0.32, 0.72); p.lineTo(0.34, 0.4); p.lineTo(0.27, 0.35); p.closePath();
      p = P(); p.moveTo(0.29, 0.71); p.lineTo(0.71, 0.71); p.lineTo(0.74, 0.79); p.lineTo(0.26, 0.79); p.closePath();
      base(0.78, 0.58);
    } else if (t === 'b') {
      let p = P(); p.moveTo(0.36, 0.78); p.quadraticCurveTo(0.4, 0.64, 0.44, 0.55); p.lineTo(0.56, 0.55); p.quadraticCurveTo(0.6, 0.64, 0.64, 0.78); p.closePath();
      p = P(); p.moveTo(0.5, 0.15); p.bezierCurveTo(0.68, 0.27, 0.69, 0.45, 0.6, 0.54); p.lineTo(0.4, 0.54); p.bezierCurveTo(0.31, 0.45, 0.32, 0.27, 0.5, 0.15); p.closePath();
      p = P(); p.ellipse(0.5, 0.555, 0.14, 0.04, 0, 0, Math.PI * 2);
      p = P(); p.arc(0.5, 0.12, 0.045, 0, Math.PI * 2);
      base(0.77, 0.5);
      parts.slit = true;
    } else if (t === 'n') {
      let p = P();
      p.moveTo(0.3, 0.79); p.lineTo(0.72, 0.79);
      p.bezierCurveTo(0.75, 0.6, 0.73, 0.38, 0.63, 0.26);
      p.bezierCurveTo(0.57, 0.19, 0.5, 0.16, 0.45, 0.16);
      p.lineTo(0.42, 0.08); p.lineTo(0.36, 0.18);
      p.bezierCurveTo(0.29, 0.23, 0.22, 0.33, 0.18, 0.44);
      p.lineTo(0.17, 0.5);
      p.bezierCurveTo(0.18, 0.56, 0.25, 0.58, 0.3, 0.54);
      p.bezierCurveTo(0.35, 0.51, 0.41, 0.5, 0.47, 0.47);
      p.bezierCurveTo(0.41, 0.57, 0.33, 0.66, 0.3, 0.79);
      p.closePath();
      base(0.77, 0.56);
      parts.eye = true;
    } else if (t === 'q') {
      let p = P();
      p.moveTo(0.3, 0.74); p.lineTo(0.18, 0.3); p.lineTo(0.34, 0.5); p.lineTo(0.35, 0.22); p.lineTo(0.45, 0.47); p.lineTo(0.5, 0.17);
      p.lineTo(0.55, 0.47); p.lineTo(0.65, 0.22); p.lineTo(0.66, 0.5); p.lineTo(0.82, 0.3); p.lineTo(0.7, 0.74); p.closePath();
      for (const [x, y] of [[0.18, 0.28], [0.35, 0.2], [0.5, 0.15], [0.65, 0.2], [0.82, 0.28]]) { p = P(); p.arc(x, y, 0.045, 0, Math.PI * 2); }
      p = P(); p.ellipse(0.5, 0.72, 0.21, 0.045, 0, 0, Math.PI * 2);
      base(0.78, 0.56);
    } else if (t === 'k') {
      let p = P(); p.moveTo(0.46, 0.06); p.lineTo(0.54, 0.06); p.lineTo(0.54, 0.12); p.lineTo(0.6, 0.12); p.lineTo(0.6, 0.19); p.lineTo(0.54, 0.19);
      p.lineTo(0.54, 0.27); p.lineTo(0.46, 0.27); p.lineTo(0.46, 0.19); p.lineTo(0.4, 0.19); p.lineTo(0.4, 0.12); p.lineTo(0.46, 0.12); p.closePath();
      p = P(); p.moveTo(0.31, 0.74); p.bezierCurveTo(0.14, 0.52, 0.27, 0.32, 0.43, 0.42); p.lineTo(0.5, 0.3); p.lineTo(0.57, 0.42);
      p.bezierCurveTo(0.73, 0.32, 0.86, 0.52, 0.69, 0.74); p.closePath();
      p = P(); p.ellipse(0.5, 0.72, 0.21, 0.045, 0, 0, Math.PI * 2);
      base(0.78, 0.56);
    }
    return parts;
  }
  const pathCache = {};
  function drawPiece(ctx, ch, cx, cy, size, alpha) {
    const t = ch.toLowerCase(), white = isW(ch);
    const parts = pathCache[t] || (pathCache[t] = piecePaths(ctx, t));
    ctx.save();
    if (alpha != null) ctx.globalAlpha = alpha;
    ctx.translate(cx - size / 2, cy - size / 2);
    ctx.scale(size, size);
    ctx.fillStyle = 'rgba(0,0,0,.22)';
    ctx.beginPath(); ctx.ellipse(0.5, 0.87, 0.3, 0.045, 0, 0, Math.PI * 2); ctx.fill();
    const g = ctx.createLinearGradient(0.2, 0.1, 0.8, 0.9);
    if (white) { g.addColorStop(0, COL.wFill0); g.addColorStop(1, COL.wFill1); }
    else { g.addColorStop(0, COL.bFill0); g.addColorStop(1, COL.bFill1); }
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.strokeStyle = white ? COL.wLine : COL.bLine;
    const lw = white ? 0.05 : 0.044;
    ctx.lineWidth = lw * 2;
    for (const p of parts) ctx.stroke(p);          // silhouette outline (outer half shows)
    ctx.fillStyle = g;
    for (const p of parts) ctx.fill(p);
    ctx.globalAlpha = (alpha == null ? 1 : alpha) * 0.55; // faint inner detail lines
    ctx.lineWidth = lw * 0.6;
    for (let i = 1; i < parts.length; i++) ctx.stroke(parts[i]);
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.lineWidth = lw;
    if (parts.slit) { ctx.beginPath(); ctx.moveTo(0.52, 0.3); ctx.lineTo(0.58, 0.4); ctx.stroke(); }
    if (parts.eye) { ctx.fillStyle = ctx.strokeStyle; ctx.beginPath(); ctx.arc(0.36, 0.28, 0.03, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.moveTo(0.6, 0.3); ctx.quadraticCurveTo(0.66, 0.45, 0.64, 0.62); ctx.stroke(); }
    if (!white) { // soft sheen on dark pieces
      ctx.globalAlpha = (alpha == null ? 1 : alpha) * 0.18;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.ellipse(0.42, 0.4, 0.05, 0.12, 0.3, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, G = null, sel = -1, targets = [], legal = [], anim = null, drag = null, promo = null;
    let stopLoop = null, shownSeq = -1, dropTo = -1, confirmTimer = 0, flip = false, busy = false, animTimer = 0;

    let showDots = U.store.get('chess.dots', true);
    const BS = { minHeight: '44px', flex: '1 1 0', minWidth: 0, padding: '6px 4px', fontSize: '13px', whiteSpace: 'nowrap' };
    const hud = L.h('div', { class: 'hud bottom', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px' } });
    const dotsBtn = L.h('button', { class: 'btn sm ghost ch-dots', style: BS, 'aria-pressed': String(showDots), onclick: toggleDots });
    const undoBtn = L.h('button', { class: 'btn sm ghost ch-undo', style: BS, text: '↶ 무르기', 'aria-label': '한 수 무르기', onclick: onUndo });
    const drawBtn = L.h('button', { class: 'btn sm ghost ch-draw', style: BS, text: '무승부 제안', onclick: onDraw });
    const resignBtn = L.h('button', { class: 'btn sm ghost ch-resign', style: BS, text: '기권', 'aria-label': '기권하기', onclick: onResign });
    hud.append(dotsBtn, undoBtn, drawBtn, resignBtn);
    root.append(hud);
    // move list (SAN), one compact horizontally scrolling row
    const mlist = L.h('div', { class: 'mono ch-moves', 'aria-label': '기보', style: { position: 'absolute', left: '0', right: '0', height: '30px', overflowX: 'auto', overflowY: 'hidden', whiteSpace: 'nowrap', fontSize: '12.5px', lineHeight: '30px', padding: '0 4px', scrollbarWidth: 'none', touchAction: 'pan-x', WebkitOverflowScrolling: 'touch' } });
    root.append(mlist);
    // draw-offer answer / waiting panel
    // (not class "overlay": core removes every .overlay on rematch)
    const offer = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'none', alignItems: 'flex-end', justifyContent: 'center', padding: '16px', background: 'rgba(15,10,22,.45)' } });
    const vis = (el, on) => { el.style.display = on ? '' : 'none'; };
    root.append(offer);
    // invisible boxes over canvas areas, so the first-play tutorial can spotlight them
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
    const spBoard = spot('ch-board'), spMe = spot('ch-me'), spOpp = spot('ch-opp');

    function dotsLabel() { dotsBtn.textContent = (showDots ? '● ' : '○ ') + '길 표시'; dotsBtn.setAttribute('aria-pressed', String(showDots)); dotsBtn.setAttribute('aria-label', '갈 수 있는 칸 표시 ' + (showDots ? '켜짐' : '꺼짐')); }
    dotsLabel();
    function toggleDots() { showDots = !showDots; U.store.set('chess.dots', showDots); dotsLabel(); api.sfx('click'); api.buzz(10); draw(); }

    const confirms = new Map(); // button -> {label, timer}
    function armed(btn, label, ask) {
      if (confirms.has(btn)) { disarm(btn); return true; }
      for (const b of [...confirms.keys()]) disarm(b);
      btn.classList.add('danger'); btn.classList.remove('ghost'); btn.textContent = ask;
      confirms.set(btn, { label, timer: setTimeout(() => disarm(btn), 3000) });
      api.sfx('click'); api.buzz(10);
      return false;
    }
    function disarm(btn) {
      const c = confirms.get(btn); if (!c) return;
      clearTimeout(c.timer); confirms.delete(btn);
      btn.classList.remove('danger'); btn.classList.add('ghost'); btn.textContent = c.label;
    }
    function disarmAll() { for (const b of [...confirms.keys()]) disarm(b); }
    function onResign() {
      if (!st || st.st || !myTurn() || locked()) return;
      if (!armed(resignBtn, '기권', '기권 확인')) return;
      sendAct({ type: 'resign' });
    }
    function onDraw() {
      if (!canOffer()) return;
      if (!armed(drawBtn, '무승부 제안', '제안 확인')) return;
      sendAct({ type: 'draw' });
    }
    function onUndo() {
      if (!canUndo()) return;
      sel = -1; targets = []; promo = null;
      api.sfx('click'); api.buzz(15);
      sendAct({ type: 'undo' });
    }
    function resetResign() { disarmAll(); }
    function soloVsAI() {
      if (api.online || !api.players[0] || !api.players[1]) return -1;
      const h = [0, 1].filter((i) => api.canAct(i)), a = [0, 1].filter((i) => api.players[i].ai);
      return h.length === 1 && a.length === 1 ? h[0] : -1;
    }
    function canOffer() { return !!st && !st.st && !st.dr && myTurn() && !locked() && st.nd !== st.t; }
    function canUndo() {
      const me = soloVsAI();
      return me >= 0 && !!st && !st.st && !st.dr && st.t === me && myTurn() && !locked() && !anim && st.u && st.u.length === 2 && st.u[0].t === me;
    }

    let waitSeq = -1, waitUntil = 0; // after sending a move, lock input until the next state (online round-trip)
    function myTurn() { const a = st && actor(st); return a != null && api.canAct(a); }
    function sendAct(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function computeFlip() {
      const mine = [0, 1].filter((i) => api.canAct(i));
      flip = mine.length === 1 && mine[0] === 1;
    }

    function layout() {
      const W = cv.w, H = cv.h;
      const stripH = 42, hudH = 60, gap = 8, listH = 30;
      let size = Math.min(W - 16, H - hudH - listH - stripH * 2 - gap * 2 - 8, 640);
      size = Math.max(180, size);
      const rail = Math.round(U.clamp(size * 0.035, 11, 18));
      const sq = Math.floor((size - rail * 2) / 8);
      size = sq * 8 + rail * 2;
      const x0 = Math.round((W - size) / 2);
      const block = stripH * 2 + gap * 2 + size + listH;
      const y0 = Math.round(Math.max(4, (H - hudH - block) / 2));
      G = { x0, y0, size, rail, sq, stripH, gap, bx: x0 + rail, by: y0 + stripH + gap + rail, topY: y0, botY: y0 + stripH + gap * 2 + size };
      place(spBoard, x0, y0 + stripH + gap, size, size);
      place(spMe, x0, G.botY, size, stripH); place(spOpp, x0, G.topY, size, stripH);
      mlist.style.top = (G.botY + stripH + 1) + 'px';
      mlist.style.left = x0 + 'px'; mlist.style.right = 'auto'; mlist.style.width = size + 'px';
    }
    cv.onresize = () => { layout(); draw(); };
    layout();

    function sqXY(i) {
      const r = i >> 3, f = i & 7;
      const c = flip ? 7 - f : f, rr = flip ? 7 - r : r;
      return { x: G.bx + c * G.sq, y: G.by + rr * G.sq };
    }
    function hit(x, y) {
      const c = Math.floor((x - G.bx) / G.sq), rr = Math.floor((y - G.by) / G.sq);
      if (c < 0 || c > 7 || rr < 0 || rr > 7) return -1;
      const f = flip ? 7 - c : c, r = flip ? 7 - rr : rr;
      return r * 8 + f;
    }

    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }

    function material(b) { let w = 0, k = 0; for (const c of b) { if (c === '.') continue; const v = PV[c.toLowerCase()]; if (isW(c)) w += v; else k += v; } return w - k; }

    function drawStrip(seat, y) {
      const p = api.players[seat] || { name: SIDE[seat], color: '#888' };
      const x = G.x0, w = G.size, hh = G.stripH;
      const active = st && !st.st && st.t === seat;
      rr(x, y, w, hh, 12);
      ctx.fillStyle = active ? 'rgba(46,38,64,.95)' : 'rgba(34,28,46,.75)'; ctx.fill();
      ctx.lineWidth = active ? 1.5 : 1;
      ctx.strokeStyle = active ? COL.brass : 'rgba(242,233,216,.13)'; ctx.stroke();
      const cy = y + hh / 2;
      // player colour dot
      ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(x + 15, cy, 5.5, 0, Math.PI * 2); ctx.fill();
      // side chip: tiny king silhouette in the side's colour
      drawPiece(ctx, seat === 0 ? 'K' : 'k', x + 35, cy - 1, 26);
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 14px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      let name = p.name;
      const maxNameW = w * 0.36;
      while (ctx.measureText(name).width > maxNameW && name.length > 1) name = name.slice(0, -1);
      if (name !== p.name) name += '…';
      ctx.fillText(name, x + 52, cy);
      let nx = x + 52 + ctx.measureText(name).width + 6;
      const checked = st && st.ck && st.t === seat && (!st.st || st.st.r === 'mate');
      ctx.fillStyle = checked ? '#ee6a55' : '#ab9fb8'; ctx.font = (checked ? '700' : '600') + ' 12px ' + FONT;
      const tag = checked ? (st.st ? '메이트' : '체크') : SIDE[seat];
      ctx.fillText(tag, nx, cy + 0.5);
      nx += ctx.measureText(tag).width + 8;
      // captured pieces (opponent colour) + material lead, right-aligned
      if (!st) return;
      const caps = st.cap.split('').filter((c) => (seat === 0 ? !isW(c) : isW(c)))
        .sort((a, b) => 'qrbnp'.indexOf(a.toLowerCase()) - 'qrbnp'.indexOf(b.toLowerCase()));
      const diff = material(st.b) * (seat === 0 ? 1 : -1);
      let rx = x + w - 10;
      ctx.textAlign = 'right';
      if (diff > 0) { ctx.fillStyle = COL.brass; ctx.font = '700 13px ' + MONO; ctx.fillText('+' + diff, rx, cy + 0.5); rx -= ctx.measureText('+' + diff).width + 5; }
      if (!caps.length) return;
      const ps = 22;
      const steps = caps.map((c, i) => (i === 0 ? 0 : caps[i - 1].toLowerCase() === c.toLowerCase() ? 7 : 12));
      let total = steps.reduce((a, b) => a + b, 0);
      const avail = Math.max(10, rx - ps / 2 - (nx + ps / 2 - 4));
      const k = total > avail ? avail / total : 1;
      let cx = rx - ps / 2 - total * k;
      for (let i = 0; i < caps.length; i++) { cx += steps[i] * k; drawPiece(ctx, caps[i], cx, cy, ps); }
    }

    function boardChars() {
      if (!anim) return st.b;
      return anim.base;
    }

    function draw() {
      cv.clear();
      if (!G || !st) return;
      const { x0, size, rail, sq, bx, by } = G;
      const y0 = G.y0 + G.stripH + G.gap;
      // strips
      drawStrip(flip ? 0 : 1, G.topY);
      drawStrip(flip ? 1 : 0, G.botY);
      // board shadow + rail
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(x0 + 3, y0 + 7, size, size, 10); ctx.fill();
      const wg = ctx.createLinearGradient(x0, y0, x0 + size, y0 + size);
      wg.addColorStop(0, COL.rail0); wg.addColorStop(1, COL.rail1);
      ctx.fillStyle = wg; rr(x0, y0, size, size, 10); ctx.fill();
      // rail grain
      ctx.save(); rr(x0, y0, size, size, 10); ctx.clip();
      ctx.strokeStyle = 'rgba(255,220,170,.05)'; ctx.lineWidth = 1;
      for (let i = 0; i < 14; i++) { const yy = y0 + (i + 0.5) * size / 14; ctx.beginPath(); ctx.moveTo(x0, yy); ctx.bezierCurveTo(x0 + size * 0.3, yy + 3, x0 + size * 0.7, yy - 3, x0 + size, yy + 1); ctx.stroke(); }
      ctx.restore();
      ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1;
      ctx.strokeRect(bx - 1.5, by - 1.5, sq * 8 + 3, sq * 8 + 3);
      // squares
      for (let i = 0; i < 64; i++) {
        const { x, y } = sqXY(i);
        const light = ((i >> 3) + (i & 7)) % 2 === 0;
        ctx.fillStyle = light ? COL.light : COL.dark;
        ctx.fillRect(x, y, sq, sq);
      }
      // subtle wood grain on the dark squares + overall sheen
      ctx.save(); ctx.beginPath(); ctx.rect(bx, by, sq * 8, sq * 8); ctx.clip();
      ctx.strokeStyle = 'rgba(70,40,20,.12)'; ctx.lineWidth = 1;
      for (let i = 0; i < 64; i++) {
        if (((i >> 3) + (i & 7)) % 2 === 0) continue;
        const { x, y } = sqXY(i);
        for (let k = 1; k < 4; k++) { const yy = y + k * sq / 4 + ((i * 7 + k * 3) % 5) - 2; ctx.beginPath(); ctx.moveTo(x, yy); ctx.quadraticCurveTo(x + sq / 2, yy + ((i + k) % 3) - 1, x + sq, yy); ctx.stroke(); }
      }
      const sh = ctx.createLinearGradient(bx, by, bx + sq * 8, by + sq * 8);
      sh.addColorStop(0, 'rgba(255,248,230,.10)'); sh.addColorStop(0.5, 'rgba(255,248,230,0)'); sh.addColorStop(1, 'rgba(30,15,5,.12)');
      ctx.fillStyle = sh; ctx.fillRect(bx, by, sq * 8, sq * 8);
      ctx.restore();
      // coordinates in the rail
      ctx.fillStyle = 'rgba(242,233,216,.62)';
      ctx.font = '600 ' + Math.max(9, Math.round(rail * 0.62)) + 'px ' + MONO;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let c = 0; c < 8; c++) {
        const f = flip ? 7 - c : c;
        ctx.fillText('abcdefgh'[f], bx + c * sq + sq / 2, by + sq * 8 + rail / 2 + 0.5);
        const r = flip ? c + 1 : 8 - c;
        ctx.fillText(String(r), x0 + rail / 2, by + c * sq + sq / 2 + 0.5);
      }
      // highlights
      const showLast = st.last && !anim ? st.last : anim ? anim.last : null;
      if (showLast) for (const i of [showLast.f, showLast.t]) { const { x, y } = sqXY(i); ctx.fillStyle = i === showLast.t ? 'rgba(227,174,69,.48)' : 'rgba(227,174,69,.28)'; ctx.fillRect(x, y, sq, sq); }
      if (sel >= 0) { const { x, y } = sqXY(sel); ctx.fillStyle = 'rgba(227,174,69,.7)'; ctx.fillRect(x, y, sq, sq); }
      const b = boardChars();
      if (st.ck && !anim) {
        const ki = st.b.indexOf(st.t === 0 ? 'K' : 'k');
        if (ki >= 0) {
          const { x, y } = sqXY(ki);
          const g = ctx.createRadialGradient(x + sq / 2, y + sq / 2, sq * 0.1, x + sq / 2, y + sq / 2, sq * 0.72);
          g.addColorStop(0, 'rgba(238,80,60,.95)'); g.addColorStop(0.55, 'rgba(238,80,60,.45)'); g.addColorStop(1, 'rgba(238,80,60,0)');
          ctx.fillStyle = g; ctx.fillRect(x, y, sq, sq);
        }
      }
      // drag hover
      if (drag && drag.moved && drag.hover >= 0 && targets.some((m) => m.t === drag.hover)) {
        const { x, y } = sqXY(drag.hover); ctx.strokeStyle = 'rgba(255,248,230,.85)'; ctx.lineWidth = 3; ctx.strokeRect(x + 1.5, y + 1.5, sq - 3, sq - 3);
      }
      // pieces
      const ps = sq * 0.94;
      for (let i = 0; i < 64; i++) {
        const c = b[i];
        if (c === '.') continue;
        const { x, y } = sqXY(i);
        const ghost = drag && drag.moved && drag.idx === i;
        drawPiece(ctx, c, x + sq / 2, y + sq / 2, ps, ghost ? 0.3 : null);
      }
      // last-move arrow (over the pieces, translucent)
      if (showLast && !anim && !drag) drawArrow(showLast.f, showLast.t);
      // legal targets
      if (sel >= 0 && !anim && showDots) {
        const seen = {};
        for (const m of targets) {
          if (seen[m.t]) continue; seen[m.t] = 1;
          const { x, y } = sqXY(m.t);
          const capture = st.b[m.t] !== '.' || (m.fl & 1);
          ctx.fillStyle = 'rgba(38,24,14,.34)'; ctx.strokeStyle = 'rgba(38,24,14,.38)';
          if (capture) { ctx.lineWidth = sq * 0.08; ctx.beginPath(); ctx.arc(x + sq / 2, y + sq / 2, sq * 0.44, 0, Math.PI * 2); ctx.stroke(); }
          else { ctx.beginPath(); ctx.arc(x + sq / 2, y + sq / 2, sq * 0.15, 0, Math.PI * 2); ctx.fill(); }
        }
      }
      // moving pieces
      if (anim) {
        const k = anim.k;
        for (const mv of anim.movers) {
          const a = sqXY(mv.f), z = sqXY(mv.t);
          const lift = Math.sin(k * Math.PI) * sq * 0.08;
          drawPiece(ctx, k >= 1 && mv.end ? mv.end : mv.ch, U.lerp(a.x, z.x, k) + sq / 2, U.lerp(a.y, z.y, k) + sq / 2 - lift, ps * (1 + 0.06 * Math.sin(k * Math.PI)));
        }
      }
      if (drag && drag.moved) drawPiece(ctx, st.b[drag.idx], drag.x, drag.y - sq * 0.25, ps * 1.18);
      if (promo) drawPromo();
    }

    function drawArrow(f, t) {
      const a = sqXY(f), z = sqXY(t), h = G.sq / 2;
      const x1 = a.x + h, y1 = a.y + h, x2 = z.x + h, y2 = z.y + h;
      const L2 = Math.hypot(x2 - x1, y2 - y1); if (L2 < 1) return;
      const ux = (x2 - x1) / L2, uy = (y2 - y1) / L2, nx = -uy, ny = ux;
      const w = Math.max(3, G.sq * 0.11), hl = G.sq * 0.34, hw = G.sq * 0.22;
      const sx = x1 + ux * G.sq * 0.22, sy = y1 + uy * G.sq * 0.22;
      const ex = x2 - ux * G.sq * 0.12, ey = y2 - uy * G.sq * 0.12;
      const bx2 = ex - ux * hl, by2 = ey - uy * hl;
      ctx.save();
      ctx.globalAlpha = 0.62;
      ctx.fillStyle = '#f0b43c';
      ctx.strokeStyle = 'rgba(40,22,8,.55)'; ctx.lineWidth = 1.2; ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(sx + nx * w / 2, sy + ny * w / 2);
      ctx.lineTo(bx2 + nx * w / 2, by2 + ny * w / 2);
      ctx.lineTo(bx2 + nx * hw, by2 + ny * hw);
      ctx.lineTo(ex, ey);
      ctx.lineTo(bx2 - nx * hw, by2 - ny * hw);
      ctx.lineTo(bx2 - nx * w / 2, by2 - ny * w / 2);
      ctx.lineTo(sx - nx * w / 2, sy - ny * w / 2);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
    }

    function drawPromo() {
      const { bx, by, sq } = G;
      ctx.fillStyle = 'rgba(15,10,22,.5)'; ctx.fillRect(bx, by, sq * 8, sq * 8);
      const white = st.t === 0;
      const tw = Math.min(sq * 1.7, (sq * 8 - 30) / 4), th = tw * 1.28, gap = 8;
      const total = tw * 4 + gap * 3;
      let x = bx + (sq * 8 - total) / 2;
      const y = by + sq * 4 - th / 2;
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 15px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText('승격할 기물을 고르세요', bx + sq * 4, y - 10);
      promo.rects = [];
      for (const [p, label] of PROMOS) {
        rr(x, y, tw, th, 12);
        ctx.fillStyle = white ? '#3a3050' : '#e9dcc0'; ctx.fill();
        ctx.strokeStyle = COL.brass; ctx.lineWidth = 1.5; ctx.stroke();
        drawPiece(ctx, white ? p.toUpperCase() : p, x + tw / 2, y + tw * 0.5, tw * 0.86);
        ctx.fillStyle = white ? '#f2e9d8' : '#2b1d15'; ctx.font = '700 13px ' + FONT; ctx.textBaseline = 'middle';
        ctx.fillText(label, x + tw / 2, y + th - 15);
        promo.rects.push({ p, x, y, w: tw, h: th });
        x += tw + gap;
      }
    }

    /* ---- input ---- */
    function refreshLegal() {
      legal = st && !st.st && !st.dr && myTurn() ? legalFromState(st) : [];
      if (sel >= 0) { targets = legal.filter((m) => m.f === sel); if (!targets.length) sel = -1; }
      else targets = [];
    }
    function onDown(e) {
      if (!st || !G || !e.isPrimary) return; // ignore extra fingers (multi-touch)
      const pt = cv.local(e);
      if (promo) {
        const r = (promo.rects || []).find((q) => pt.x >= q.x && pt.x <= q.x + q.w && pt.y >= q.y && pt.y <= q.y + q.h);
        const pm = promo; promo = null;
        if (r) { sel = -1; targets = []; dropTo = pm.dropped ? pm.t : -1; api.sfx('click'); sendAct({ type: 'move', f: pm.f, t: pm.t, p: r.p }); }
        draw();
        return;
      }
      if (anim || !myTurn() || locked() || st.dr) return;
      const i = hit(pt.x, pt.y);
      if (i < 0) { sel = -1; targets = []; draw(); return; }
      if (sel >= 0 && targets.some((m) => m.t === i)) { tryMove(sel, i, false); return; }
      const c = st.b[i];
      const own = c !== '.' && isW(c) === (st.t === 0);
      if (own) {
        const wasSel = sel === i;
        sel = i; targets = legal.filter((m) => m.f === i);
        drag = { idx: i, x: pt.x, y: pt.y, sx: pt.x, sy: pt.y, moved: false, wasSel, hover: i, id: e.pointerId };
        try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
        api.sfx('tick');
        if (!targets.length && !wasSel) { api.buzz(20); api.toast(st.ck ? '체크! 킹을 지키는 수만 둘 수 있어요' : '이 기물은 지금 움직일 수 없어요'); }
      } else { sel = -1; targets = []; }
      draw();
    }
    function onMove(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const pt = cv.local(e);
      drag.x = pt.x; drag.y = pt.y;
      if (!drag.moved && Math.hypot(pt.x - drag.sx, pt.y - drag.sy) > 7) drag.moved = true;
      drag.hover = hit(pt.x, pt.y - (e.pointerType === 'touch' ? G.sq * 0.25 : 0));
      if (drag.moved) draw();
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag; drag = null;
      if (d.moved) {
        const to = d.hover;
        if (to >= 0 && to !== d.idx && targets.some((m) => m.t === to)) { tryMove(d.idx, to, true); return; }
      } else if (d.wasSel) { sel = -1; targets = []; }
      draw();
    }
    function onCancel() { if (drag) { drag = null; draw(); } }
    function tryMove(f, t, dropped) {
      const ms = legal.filter((m) => m.f === f && m.t === t);
      if (!ms.length) return;
      if (ms.some((m) => m.p)) { promo = { f, t, dropped }; drag = null; draw(); return; }
      sel = -1; targets = []; dropTo = dropped ? t : -1;
      sendAct({ type: 'move', f, t });
      draw();
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);

    /* ---- animation ---- */
    function finishAnim() {
      clearTimeout(animTimer);
      if (stopLoop) { stopLoop(); stopLoop = null; }
      const had = !!anim;
      anim = null;
      if (busy) { busy = false; api.setBusy(false); }
      if (had && st) updateHud();
    }
    function startAnim(prev, next) {
      const l = next.last;
      const movers = [{ f: l.f, t: l.t, ch: prev.b[l.f], end: l.p ? (next.t === 1 ? l.p.toUpperCase() : l.p) : null }];
      const base = prev.b.split('');
      base[l.f] = '.';
      if (l.k === 'c') {
        const r = l.t > l.f ? [l.t + 1, l.t - 1] : [l.t - 2, l.t + 1];
        movers.push({ f: r[0], t: r[1], ch: prev.b[r[0]] });
        base[r[0]] = '.';
      }
      if (l.k === 'e') base[(l.f & 56) | (l.t & 7)] = '.';
      anim = { movers, base: base.join(''), last: l, k: 0, t0: performance.now(), dur: 180 / L.debug.speed };
      busy = true; api.setBusy(true);
      // rAF pauses in background tabs; make sure busy can't stick (AI/result would wait forever)
      animTimer = setTimeout(() => { if (anim) { finishAnim(); draw(); } }, anim.dur + 600);
      stopLoop = U.loop((dt, nowT) => {
        if (!anim) return;
        const k = Math.min(1, (nowT - anim.t0) / anim.dur);
        anim.k = k < 1 ? 1 - Math.pow(1 - k, 3) : 1;
        if (k >= 1) { finishAnim(); draw(); return; }
        draw();
      });
    }

    function updateHud() {
      const mine = !!st && !st.st && myTurn() && !st.dr;
      vis(resignBtn, mine); vis(drawBtn, mine);
      drawBtn.disabled = !canOffer();
      drawBtn.title = st && st.nd === st.t ? '상대가 한 수 둔 뒤에 다시 제안할 수 있어요' : '';
      const solo = soloVsAI() >= 0;
      vis(undoBtn, solo && !(st && st.st));
      undoBtn.disabled = !canUndo();
      vis(dotsBtn, !!st && !st.st && [0, 1].some((i) => api.canAct(i)));
      if (!mine) disarmAll();
      renderList();
      renderOffer();
    }
    let listSig = '';
    function renderList() {
      if (!st) return;
      const sig = st.m0 + '|' + st.ml + '|' + (myTurn() && !st.st ? 1 : 0);
      if (sig === listSig) return;
      listSig = sig;
      mlist.innerHTML = '';
      const toks = st.ml ? st.ml.split(' ') : [];
      if (!toks.length) {
        mlist.append(L.h('span', { style: { color: 'var(--muted)', fontFamily: 'var(--f-body)', fontWeight: 700, fontSize: '12px' }, text: myTurn() ? '기물을 탭하거나 끌어서 두세요' : '기보가 여기에 쌓여요' }));
        return;
      }
      let ply = st.m0;
      const frag = [];
      if (st.m0 > 0) frag.push(L.h('span', { style: { color: 'var(--muted)', marginRight: '6px' }, text: '…' }));
      toks.forEach((t, i) => {
        const n = (ply >> 1) + 1, white = (ply & 1) === 0;
        if (white || i === 0) frag.push(L.h('span', { style: { color: 'var(--muted)', marginLeft: i ? '8px' : '0', marginRight: '3px' }, text: n + (white ? '.' : '…') }));
        const last = i === toks.length - 1;
        frag.push(L.h('span', { style: { color: last ? 'var(--brass)' : 'var(--ink)', fontWeight: last ? 700 : 500, marginRight: '4px', padding: last ? '1px 4px' : '0', borderRadius: '5px', background: last ? 'rgba(227,174,69,.14)' : 'none' }, text: t }));
        ply++;
      });
      mlist.append(...frag);
      mlist.scrollLeft = mlist.scrollWidth;
    }
    let offerSig = '';
    function renderOffer() {
      const d = st && !st.st && st.dr;
      const responder = d ? 1 - d.by : -1;
      const answer = d && api.canAct(responder);
      const waiting = d && !answer && api.canAct(d.by);
      const sig = d ? (answer ? 'a' : waiting ? 'w' : 'x') + d.by + ':' + st.seq : '';
      if (sig === offerSig) return;
      offerSig = sig;
      offer.innerHTML = '';
      if (!answer && !waiting) { offer.style.display = 'none'; return; }
      offer.style.display = 'flex';
      const by = api.players[d.by] || { name: SIDE[d.by], color: '#888' };
      const sheet = L.h('div', { class: 'sheet', style: { width: '100%' } },
        L.h('span', { class: 'label', text: '무승부 제안' }),
        L.h('h2', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, L.h('span', { class: 'dot', style: { '--c': by.color } }), by.name + ' (' + SIDE[d.by] + ')'),
        L.h('p', { class: 'muted', style: { margin: 0 }, text: answer ? '무승부로 끝낼까요? 거절하면 게임이 이어져요.' : '상대의 답을 기다리는 중…' }));
      if (answer) {
        sheet.append(L.h('div', { class: 'row', style: { justifyContent: 'flex-end', flexWrap: 'nowrap' } },
          L.h('button', { class: 'btn', style: { flex: '1 1 0' }, text: '거절', onclick() { api.sfx('click'); sendAct({ type: 'drawReply', ok: false }); } }),
          L.h('button', { class: 'btn primary', style: { flex: '1 1 0' }, text: '수락 (무승부)', onclick() { api.sfx('click'); sendAct({ type: 'drawReply', ok: true }); } })));
      }
      offer.append(sheet);
    }

    return {
      update(next, prev) {
        const fresh = prev && prev !== next && next.seq !== shownSeq;
        st = next;
        computeFlip();
        if (fresh && next.last && next.last.id === next.seq) {
          finishAnim();
          const l = next.last;
          if (dropTo !== l.t && prev.seq === next.seq - 1) startAnim(prev, next);
          if (l.x) { api.sfx('hit'); api.buzz(15); } else if (l.k === 'c') api.sfx('whoosh'); else api.sfx('thud');
          if (next.ck && !next.st) { api.toast('체크!'); api.sfx('pop'); api.buzz(30); }
          else if (l.p && !next.st) api.toast('폰 승격!');
        } else if (fresh && next.st && (next.st.r === 'resign' || next.st.r === 'agree')) finishAnim();
        if (fresh && next.ev && next.ev.id === next.seq) {
          const e = next.ev, who = api.players[e.by] ? api.players[e.by].name : SIDE[e.by];
          if (e.k === 'o') { api.sfx('chip'); api.buzz(20); if (!api.canAct(1 - e.by) && !api.canAct(e.by)) api.toast(who + ' 무승부 제안'); }
          else if (e.k === 'n') { api.sfx('click'); api.toast(api.canAct(e.by) ? '상대가 무승부 제안을 거절했어요' : '무승부 제안 거절'); }
          else if (e.k === 'u') { finishAnim(); api.sfx('whoosh'); api.toast('한 수 물렀어요'); }
        }
        dropTo = -1;
        shownSeq = next.seq;
        if (prev && prev.seq !== next.seq) { sel = -1; promo = null; drag = null; disarmAll(); }
        if (!prev) { finishAnim(); sel = -1; promo = null; }
        refreshLegal();
        updateHud();
        draw();
      },
      destroy() {
        finishAnim();
        clearTimeout(confirmTimer); disarmAll();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onCancel);
        cv.destroy(); hud.remove(); mlist.remove(); offer.remove();
      },
    };
  }

  L.register({
    id: 'chess', name: '체스', tag: '전략',
    blurb: '백과 흑이 번갈아 두는 정통 체스. 상대 킹을 체크메이트하면 승리해요. 캐슬링·앙파상·승격, 50수·3회 반복 무승부와 무승부 제안까지 모두 적용됩니다.',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, hidden: false, aiDelay: 300,
    quick: [
      '상대 킹을 「체크메이트」(도망칠 곳 없이 잡히게 된 상태)로 만들면 이겨요. 백이 먼저 둬요.',
      '내 차례: 내 기물 하나를 탭 → 점으로 보이는 칸을 탭(또는 끌어다 놓기)해 한 수 둬요.',
      '내 킹이 공격받는 상태(체크)로 끝나는 수는 둘 수 없어요. 둘 수가 없는데 체크도 아니면 무승부예요.',
    ],
    rules: [
      { h: '목표', p: [
        '1번 자리가 백(흰 기물), 2번 자리가 흑이에요. 백이 먼저, 한 수씩 번갈아 둬요.',
        '상대 킹을 잡히기 직전으로 몰아(체크) 어디로도 피할 수 없게 하면 「체크메이트」 — 이겨요.',
        '킹은 실제로 잡히지 않아요. 체크메이트가 되는 순간 게임이 끝나요.'] },
      { h: '기물별 움직임', p: [
        '♙ 폰: 앞으로 1칸(처음엔 2칸까지). 잡을 땐 대각선 앞 1칸. 뒤로는 못 가요.',
        '♘ 나이트: L자(두 칸 + 옆 한 칸). 유일하게 다른 기물을 뛰어넘어요.',
        '♗ 비숍: 대각선으로 막히지 않는 만큼.',
        '♖ 룩: 가로·세로로 막히지 않는 만큼.',
        '♕ 퀸: 가로·세로·대각선 8방향으로 막히지 않는 만큼(가장 강해요).',
        '♔ 킹: 8방향으로 1칸. 상대가 공격하고 있는 칸으로는 못 가요.',
        '상대 기물이 있는 칸으로 가면 그 기물을 잡아요(판에서 빠져요). 내 기물은 못 잡아요.'] },
      { h: '차례에 할 일', p: [
        '기물 하나를 한 번 움직여요. 건너뛸 수는 없어요.',
        '체크(내 킹이 공격받는 중)면 반드시 풀어야 해요: 킹 피하기 · 공격하는 기물 잡기 · 사이 막기.',
        '내 킹이 공격받는 채로 남는 수는 둘 수 없어요(그런 기물은 골라도 「움직일 수 없음」이라고 알려 줘요).'] },
      { h: '특수 규칙', p: [
        '캐슬링: 킹과 룩이 둘 다 한 번도 안 움직였고 사이가 비었으면, 킹을 룩 쪽으로 2칸 옮겨요. 룩은 킹 너머로 자동으로 넘어와요. 체크 중이거나, 킹이 지나가는 칸·도착 칸이 공격받으면 안 돼요.',
        '앙파상: 상대 폰이 처음에 2칸 전진해 내 폰 바로 옆에 서면, 바로 다음 수에만 그 폰이 지나간 칸으로 대각선 이동하며 잡을 수 있어요.',
        '승격: 폰이 맨 끝 줄에 닿으면 퀸·룩·비숍·나이트 중 하나로 바뀌어요. 고르는 창이 떠요(보통 퀸).'] },
      { h: '승패 · 무승부', p: [
        '승리: 체크메이트, 또는 상대가 기권.',
        '스테일메이트: 내 차례인데 체크는 아닌데 둘 수 있는 수가 하나도 없으면 무승부.',
        '50수 규칙: 양쪽 합쳐 100번 동안 폰도 안 움직이고 잡기도 없으면 자동 무승부.',
        '3회 반복: 똑같은 국면(같은 차례·캐슬링·앙파상 가능 여부까지)이 세 번 나오면 자동 무승부.',
        '기물 부족: 킹만 남았거나, 킹 + 나이트/비숍 하나뿐이거나, 남은 비숍이 모두 같은 색 칸이면 무승부.',
        '합의: 무승부 제안을 상대가 수락하면 무승부.'] },
      { h: '무승부 제안', p: [
        '내 차례에 「무승부 제안」 → 3초 안에 「제안 확인」. 상대가 수락/거절할 때까지 아무도 못 둬요.',
        '거절당하면 내 차례로 돌아와요. 상대가 한 수 둘 때까지는 다시 제안할 수 없어요. 몇 수째든 제안할 수 있어요.',
        'AI는 자기 수읽기로 형세를 봐요: 비슷하거나(자기 쪽 +0.3폰 이하) 불리하면 수락, 유리하면 거절.'] },
      { h: '조작', p: [
        '내 기물을 탭 → 갈 수 있는 칸에 점(잡을 수 있는 칸은 원)이 떠요. 그 칸을 탭하거나 기물을 끌어다 놓으면 둬요.',
        '고른 기물을 다시 탭하면 선택이 풀려요. 「길 표시」로 점을 끄고 켤 수 있어요(기기에 기억).',
        '직전 수는 칸 강조와 화살표로 보여요. 보드 아래에 기보(SAN 표기: Nf3 = 나이트가 f3으로)가 쌓여요. 옆으로 밀어 볼 수 있어요.',
        '↶ 무르기: 이 폰에서 사람 1명 대 AI일 때만. 내 직전 수와 AI의 응수를 함께 되돌려요(한 번에 한 수).',
        '기권: 「기권」 → 3초 안에 「기권 확인」. 혼자 흑을 맡으면 보드가 뒤집혀 흑이 아래에 보여요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 얕게 읽고 가끔 기물을 놓치고, 어려움은 더 깊이(약 0.6초) 읽어요.'] },
      { h: '예시', p: [
        '첫 수로 e2의 폰을 탭 → e3·e4에 점이 떠요 → e4를 탭. 기보에 「1. e4」가 적혀요.',
        '내 퀸이 상대 킹을 공격하는데 킹이 피할 칸도, 막을 기물도, 퀸을 잡을 기물도 없다면 → 체크메이트로 승리!',
        '상대 킹은 체크가 아닌데 움직일 칸이 하나도 없고 다른 기물도 없다면 → 스테일메이트로 무승부(이기고 있어도!).'] },
    ],
    tutorial: [
      { sel: '.ch-board', text: '체스판이에요. 아래쪽이 내 기물이고 백이 먼저 둬요. 목표는 상대 킹을 도망칠 수 없게 몰아붙이는 「체크메이트」!' },
      { sel: '.ch-board', text: '내 기물을 탭하면 갈 수 있는 칸에 점이 떠요(잡을 수 있으면 원). 그 칸을 탭하거나 끌어다 놓으면 한 수 끝! 기물마다 움직임이 달라서, 점을 보면서 익히면 돼요.' },
      { sel: '.ch-board', text: '폰은 앞으로 1칸(처음엔 2칸), 잡을 땐 대각선. 나이트는 L자로 뛰어넘고, 비숍은 대각선, 룩은 가로·세로, 퀸은 8방향, 킹은 1칸씩이에요.' },
      { sel: '.ch-opp', text: '위 이름표가 상대, 아래가 나예요. 내 차례면 금색 테두리가 켜지고, 킹이 공격받으면 「체크」가 떠요. 체크면 반드시 풀어야 해요. 잡은 기물과 점수 차도 여기 보여요.' },
      { sel: '.ch-moves', text: '여기에 기보(지금까지 둔 수)가 쌓여요. 옆으로 밀어 볼 수 있어요.' },
      { sel: '.ch-undo', text: '실수했으면 「↶ 무르기」로 내 직전 수를 되돌려요(AI전에서만). 「길 표시」로 점을 끄고 켤 수 있어요.' },
      { sel: '.ch-draw', text: '비길 것 같으면 「무승부 제안」, 질 것 같으면 「기권」. 둘 다 한 번 더 눌러 확인해야 해요. 캐슬링·앙파상·승격 같은 특수 규칙은 「?」에 쉽게 적어 뒀어요. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _engine: { perft, loadFEN, think, CFG, legalFromState, evaluate, rootScores },
  });
})();
