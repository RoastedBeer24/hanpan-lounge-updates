/* 두더지 대 농부 — 비대칭 숨김 대결 (턴제).
   두더지 팀(1~3명, 두더지 3마리)은 땅속을 몰래 다니며 작물을 먹고, 농부는 망치·덫·허수아비로 밭을 지켜요.
   두더지 위치(mz)와 덫 위치(tz)는 상태에 가볍게 암호화되어 있고, 보는 쪽 화면(api.viewer())에서만 풀어서 그려요.
   공개 단서(흙더미·먹힌 자리·허수아비 숫자·망치 헛방)로 계산한 「두더지 있을 만한 곳」 분포(pd)는 apply가 매 차례 갱신하고,
   농부 AI도 이것만 써요(두더지 위치를 몰래 보지 않아요). */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------------- field ---------------- */
  const W = 7, H = 9, N = W * H, NM = 3;
  const xy = (t) => [t % W, Math.floor(t / W)];
  const NB = [];
  for (let t = 0; t < N; t++) {
    const [x, y] = xy(t), a = [];
    if (y > 0) a.push(t - W); if (x < W - 1) a.push(t + 1); if (y < H - 1) a.push(t + W); if (x > 0) a.push(t - 1);
    NB.push(a);
  }
  // 두더지가 숲에서 들어올 수 있는 칸: 아래 줄 + 아래쪽 양옆(위쪽은 농가 울타리)
  const ENTRY = [];
  for (let t = 0; t < N; t++) { const [x, y] = xy(t); if (y === H - 1 || ((x === 0 || x === W - 1) && y >= 6)) ENTRY.push(t); }
  const isEntry = (t) => ENTRY.includes(t);
  const area3 = (c) => { const [x, y] = xy(c), out = []; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < W && Y < H) out.push(Y * W + X); } return out; };
  const LENS = { short: [10, 5], normal: [12, 6], long: [14, 7] };
  const CROPS = 14;

  function genBoard() {
    for (let tries = 0; tries < 200; tries++) {
      const b = new Array(N).fill('.');
      // crops: interior rows 1–6, cols 1–5, in a few patches
      const pool = [];
      for (let y = 1; y <= 6; y++) for (let x = 1; x <= 5; x++) pool.push(y * W + x);
      const seeds = U.shuffle(pool.slice()).slice(0, 4);
      const crops = new Set();
      seeds.forEach((c) => crops.add(c));
      let guard = 0;
      while (crops.size < CROPS && guard++ < 500) {
        const arr = [...crops], c = arr[U.rand(arr.length)];
        const n = NB[c][U.rand(NB[c].length)];
        if (pool.includes(n) && Math.random() < 0.8) crops.add(n);
      }
      if (crops.size < CROPS) continue;
      crops.forEach((c) => (b[c] = 'c'));
      // rocks: 3, not on entry tiles, not on crops
      const free = [];
      for (let t = W; t < N - W; t++) if (b[t] === '.' && !isEntry(t)) free.push(t);
      U.shuffle(free).slice(0, 3).forEach((t) => (b[t] = 'r'));
      // connectivity check
      const seen = new Set([ENTRY[0]]), q = [ENTRY[0]];
      while (q.length) { const t = q.pop(); for (const n of NB[t]) if (b[n] !== 'r' && !seen.has(n)) { seen.add(n); q.push(n); } }
      if (seen.size !== b.filter((c) => c !== 'r').length) continue;
      return b.join('');
    }
    const b = new Array(N).fill('.');
    for (let i = 0; i < CROPS; i++) b[W + 1 + (i % 5) + Math.floor(i / 5) * W] = 'c';
    return b.join('');
  }

  /* ---------------- hidden encoding ---------------- */
  const CH = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_';
  const encOne = (k, salt, v) => CH[((v + 1) + (k * (salt * 7 + 3)) % 64 + 640) % 64];
  const decOne = (k, salt, ch) => { const i = CH.indexOf(ch); return ((i - (k * (salt * 7 + 3)) % 64 + 640) % 64) - 1; };
  const encArr = (k, base, a) => a.map((v, i) => encOne(k, base + i, v)).join('');
  const decArr = (k, base, str) => Array.from(str || '').map((ch, i) => decOne(k, base + i, ch));
  const molesOf = (s) => decArr(s.k, 0, s.mz);
  const setMoles = (s, a) => { s.mz = encArr(s.k, 0, a); };
  const trapsOf = (s) => decArr(s.k, 11, s.tz);
  const setTraps = (s, a) => { s.tz = encArr(s.k, 11, a); };

  /* ---------------- public belief (pd) ---------------- */
  const r2 = (v) => Math.round(v * 100) / 100;
  const sum = (a) => a.reduce((m, v) => m + v, 0);
  const onBoard = (s) => s.bw.reduce((m, v) => m + (v ? 0 : 1), 0);
  function scaleTo(D, target, mask) {
    for (let it = 0; it < 4; it++) {
      let tot = 0, freeTot = 0;
      for (let t = 0; t < N; t++) if (!mask || mask[t]) { tot += D[t]; if (D[t] < 1) freeTot += D[t]; }
      if (tot <= 1e-9) return false;
      const capped = tot - freeTot, k = freeTot > 1e-9 ? (target - capped) / freeTot : 0;
      for (let t = 0; t < N; t++) if ((!mask || mask[t]) && D[t] < 1) D[t] = Math.min(1, Math.max(0, D[t] * k));
      if (Math.abs(sum(mask ? D.filter((_, t) => mask[t]) : D) - target) < 0.01) break;
    }
    return true;
  }
  // public constraints: rocks, scarecrow counts, hammer misses this round; then normalise to the on-board count
  function constrain(s, D) {
    const n = onBoard(s);
    for (let t = 0; t < N; t++) if (s.b[t] === 'r') D[t] = 0;
    for (const [t, hit] of s.hm) if (!hit) D[t] = 0;
    const inSc = new Array(N).fill(0);
    for (const [c, cnt] of s.sc) {
      const A = area3(c).filter((t) => s.b[t] !== 'r');
      A.forEach((t) => (inSc[t] = 1));
      if (cnt === 0) A.forEach((t) => (D[t] = 0));
    }
    if (n <= 0) { for (let t = 0; t < N; t++) D[t] = 0; return D; }
    for (const [c, cnt] of s.sc) {
      if (cnt <= 0) continue;
      const A = area3(c).filter((t) => s.b[t] !== 'r'), mask = new Array(N).fill(0);
      A.forEach((t) => (mask[t] = 1));
      if (!scaleTo(D, Math.min(cnt, A.length), mask)) A.forEach((t) => (D[t] = cnt / A.length));
    }
    if (!scaleTo(D, n)) {
      const ok = []; for (let t = 0; t < N; t++) if (s.b[t] !== 'r' && !(s.hm.some((h) => h[0] === t && !h[1]))) ok.push(t);
      ok.forEach((t) => (D[t] = n / ok.length));
    }
    return D;
  }
  // propagate the belief through one mole phase using only what the farmer could see
  function phaseFilter(s, ob, nStart) {
    const b = s.b, D = s.pd.slice();
    const B = new Array(N).fill(0);
    for (const x of ob.e) D[x] = 0;
    const restN = Math.max(0, nStart - ob.e.length);
    if (restN > 0) scaleTo(D, restN);
    else for (let t = 0; t < N; t++) D[t] = 0;
    for (let t = 0; t < N; t++) B[t] = D[t];
    for (const x of ob.e) B[x] += 1;
    const ND = new Array(N).fill(0);
    // a mound marks where a mole STARTED a fast dig: it is now exactly two steps away from there
    for (const m of ob.d) {
      B[m] = Math.max(0, B[m] - 1);
      const w = new Array(N).fill(0);
      for (const n of NB[m]) if (b[n] !== 'r') for (const n2 of NB[n]) if (b[n2] !== 'r' && n2 !== m) w[n2] += 1;
      const tw = sum(w) || 1;
      for (let t = 0; t < N; t++) if (w[t]) ND[t] += w[t] / tw;
    }
    const rem = Math.max(0, nStart + ob.en - ob.d.length - ob.c);
    if (rem > 0) {
      const Q = new Array(N).fill(0);
      for (let t = 0; t < N; t++) {
        if (!B[t]) continue;
        const ns = NB[t].filter((n) => b[n] !== 'r');
        Q[t] += B[t] * STAY;
        ns.forEach((n) => (Q[n] += (B[t] * (1 - STAY)) / ns.length));
      }
      if (ob.en > 0) ENTRY.forEach((e) => (Q[e] += ob.en / ENTRY.length));
      if (sum(Q) > 1e-9) scaleTo(Q, rem);
      for (let t = 0; t < N; t++) ND[t] += Q[t];
    }
    for (let t = 0; t < N; t++) ND[t] = Math.min(1, ND[t]);
    return ND;
  }
  const STAY = 0.25;
  const storePd = (s, D) => { s.pd = D.map(r2); };

  /* ---------------- pure logic ---------------- */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    let fs = 0;
    if (opts.farmer === 'p2') fs = Math.min(1, n - 1);
    else if (opts.farmer === 'rand') fs = U.rand(n);
    const ms = []; for (let i = 0; i < n; i++) if (i !== fs) ms.push(i);
    const mo = ms.length === 1 ? [ms[0], ms[0], ms[0]] : ms.length === 2 ? [ms[0], ms[0], ms[1]] : [ms[0], ms[1], ms[2]];
    const [R, T] = LENS[opts.len] || LENS.normal;
    const s = {
      b: genBoard(), fs, ms, mo, R, T, rd: 1, ph: 'm', mt: 0,
      k: 1 + U.rand(900), mz: '', tz: '', bw: [1, 1, 1], rs: [0, 0, 0],
      tl: 3, sl: 2, sc: [], md: [], hm: [], ate: 0, cau: 0, fa: 2,
      pd: new Array(N).fill(0), ob: { e: [], d: [], en: 0, c: 0, n0: 0 }, seq: 0, last: null, win: null,
    };
    setMoles(s, [-1, -1, -1]); setTraps(s, []);
    s.ob.n0 = 0;
    skipIdle(s);
    return s;
  }
  // a mole seat with nothing to do (all its moles resting) is skipped automatically
  function seatHasWork(s, seat) { return s.mo.some((o, i) => o === seat && s.rs[i] === 0); }
  function skipIdle(s) {
    while (s.ph === 'm' && s.mt < s.ms.length && !seatHasWork(s, s.ms[s.mt])) { endSeatRest(s, s.ms[s.mt]); s.mt++; }
    if (s.ph === 'm' && s.mt >= s.ms.length) endMolePhase(s);
  }
  function endSeatRest(s, seat) { s.mo.forEach((o, i) => { if (o === seat && s.rs[i] > 0 && !(s.justC && s.justC.includes(i))) s.rs[i]--; }); }
  function endMolePhase(s) {
    const mol = molesOf(s);
    s.sc = s.sc.map(([c, _]) => [c, area3(c).filter((t) => mol.includes(t)).length]);
    s.hm = [];
    storePd(s, constrain(s, phaseFilter(s, s.ob, s.ob.n0)));
    s.ob = { e: [], d: [], en: 0, c: 0, n0: 0 };
    s.justC = null;
    s.ph = 'f'; s.fa = 2;
  }
  function startMolePhase(s) {
    s.rd++;
    if (s.rd > s.R) { s.ph = 'e'; s.win = 'f'; return; }
    s.md = s.md.map(([t, a]) => [t, a + 1]).filter(([, a]) => a <= 1);
    s.ph = 'm'; s.mt = 0; s.ob = { e: [], d: [], en: 0, c: 0, n0: onBoard(s) };
    skipIdle(s);
  }
  function actor(s) {
    if (s.ph === 'm') return s.ms[s.mt];
    if (s.ph === 'f') return s.fs;
    return null;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (s.ph === 'e') throw new Error('game over');
    if (actor(s) !== seat) throw new Error('not your turn');
    if (s.ph === 'm') return applyMoles(s, seat, a);
    return applyFarmer(s, a);
  }
  function applyMoles(s, seat, a) {
    if (a.t !== 'm' || !Array.isArray(a.mv)) throw new Error('bad mole action');
    const mol = molesOf(s), traps = trapsOf(s), mine = [];
    s.mo.forEach((o, i) => { if (o === seat) mine.push(i); });
    const plan = {};
    for (const m of a.mv) {
      if (!Array.isArray(m) || m.length < 2) throw new Error('bad move');
      const [i, e, ...path] = m;
      if (!mine.includes(i) || plan[i]) throw new Error('not your mole');
      if (s.rs[i] > 0) throw new Error('resting');
      if (path.length > 2 || path.some((t) => !Number.isInteger(t) || t < 0 || t >= N || s.b[t] === 'r')) throw new Error('bad path');
      let cur = mol[i];
      if (cur < 0) { if (e) throw new Error('cannot eat'); if (path.length !== 1 || !isEntry(path[0])) throw new Error('must enter one edge tile'); }
      else {
        if (e && s.b[cur] !== 'c') throw new Error('no crop');
        if (e && path.length > 1) throw new Error('full belly: one step only');
        if (path.length && !NB[cur].includes(path[0])) throw new Error('not adjacent');
      }
      if (path.length === 2 && (!NB[path[0]].includes(path[1]) || path[1] === cur)) throw new Error('bad step');
      plan[i] = { e: e ? 1 : 0, path };
    }
    // moles in the burrow that can act must enter: pick a free entry tile if the plan forgot them
    const used = new Set(mol.filter((t) => t >= 0));
    for (const i of mine) if (plan[i] && plan[i].path.length) used.add(plan[i].path[plan[i].path.length - 1]);
    for (const i of mine) {
      if (s.rs[i] > 0 || plan[i]) continue;
      if (mol[i] < 0) {
        const free = ENTRY.filter((t) => !used.has(t) && s.b[t] !== 'r');
        if (!free.length) throw new Error('no entry');
        plan[i] = { e: 0, path: [free[U.rand(free.length)]] }; used.add(plan[i].path[0]);
      } else plan[i] = { e: 0, path: [] };
    }
    // final tiles must not collide
    const fin = mol.slice();
    for (const i of mine) if (plan[i]) { const p = plan[i].path; fin[i] = p.length ? p[p.length - 1] : mol[i]; }
    for (let i = 0; i < NM; i++) for (let j = i + 1; j < NM; j++) if (fin[i] >= 0 && fin[i] === fin[j]) throw new Error('two moles on one tile');
    const ev = [];
    s.justC = s.justC || [];
    let tl = traps.slice();
    for (const i of mine) {
      const p = plan[i];
      if (!p) continue;
      const from = mol[i];
      if (from < 0) s.ob.en++;
      if (p.e) {
        s.b = s.b.slice(0, from) + 'x' + s.b.slice(from + 1);
        s.ate++; s.ob.e.push(from); ev.push(['e', from, i]);
      }
      if (p.path.length === 2) { s.md.push([from, 0]); s.ob.d.push(from); ev.push(['d', from, i]); }
      let at = from, caught = false;
      for (let k = 0; k < p.path.length; k++) {
        at = p.path[k];
        const ti = tl.indexOf(at);
        if (ti >= 0) { tl.splice(ti, 1); caught = true; ev.push(['c', at, i]); break; }
      }
      if (caught) { mol[i] = -1; s.bw[i] = 1; s.rs[i] = 1; s.cau++; s.ob.c++; s.justC.push(i); continue; }
      mol[i] = at; if (at >= 0) s.bw[i] = 0;
    }
    setMoles(s, mol); setTraps(s, tl);
    // keep one mound per tile (the newest)
    const seenM = new Set();
    s.md = s.md.reverse().filter(([t]) => (seenM.has(t) ? false : (seenM.add(t), true))).reverse();
    s.seq++; s.last = { id: s.seq, k: 'm', seat, ev };
    if (s.ate >= s.T) { s.ph = 'e'; s.win = 'm'; s.justC = null; return s; }
    endSeatRest(s, seat);
    s.mt++;
    skipIdle(s);
    return s;
  }
  function applyFarmer(s, a) {
    const c = a.c;
    if (a.t === 'x') { // 남은 행동 넘기기
      if (s.fa >= 2) throw new Error('use at least one action');
      s.seq++; s.last = { id: s.seq, k: 'x' };
      s.fa = 0; startMolePhase(s); return s;
    }
    if (!Number.isInteger(c) || c < 0 || c >= N || s.b[c] === 'r') throw new Error('bad tile');
    const mol = molesOf(s);
    let D = s.pd.slice();
    if (a.t === 'h') {
      const i = mol.indexOf(c);
      if (i >= 0) {
        mol[i] = -1; s.bw[i] = 1; s.rs[i] = 1; s.cau++;
        setMoles(s, mol);
      }
      s.hm.push([c, i >= 0 ? 1 : 0]);
      D[c] = 0;
      s.seq++; s.last = { id: s.seq, k: 'h', c, hit: i >= 0 ? 1 : 0, i };
    } else if (a.t === 't') {
      const tr = trapsOf(s);
      if (s.tl <= 0 || tr.includes(c)) throw new Error('no trap');
      tr.push(c); setTraps(s, tr); s.tl--;
      s.seq++; s.last = { id: s.seq, k: 't' };
    } else if (a.t === 's') {
      if (s.sl <= 0 || s.sc.some(([t]) => t === c)) throw new Error('no scarecrow');
      const n = area3(c).filter((t) => mol.includes(t)).length;
      s.sc.push([c, n]); s.sl--;
      s.seq++; s.last = { id: s.seq, k: 's', c, n };
    } else throw new Error('bad action');
    storePd(s, constrain(s, D));
    s.fa--;
    if (s.fa <= 0) startMolePhase(s);
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    if (s.win === 'm') return { winners: s.ms.slice(), title: '두더지 승리!', text: `${s.rd}라운드에 작물 ${s.ate}개를 먹었어요. (잡힌 횟수 ${s.cau}번)` };
    return { winners: [s.fs], title: '농부 승리!', text: `${s.R}라운드 동안 밭을 지켰어요. 먹힌 작물 ${s.ate}/${s.T} · 잡은 두더지 ${s.cau}번` };
  }

  /* ---------------- AI ---------------- */
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  function cropDist(b, skip) {
    const d = new Array(N).fill(99), q = [];
    for (let t = 0; t < N; t++) if (b[t] === 'c' && t !== skip) { d[t] = 0; q.push(t); }
    for (let h = 0; h < q.length; h++) { const t = q[h]; for (const n of NB[t]) if (b[n] !== 'r' && d[n] > d[t] + 1) { d[n] = d[t] + 1; q.push(n); } }
    return d;
  }
  // 두더지는 바로 옆 칸(상하좌우)에 묻힌 덫 냄새를 맡아요 — 팀 모두가 알아요
  function sensedTraps(s) {
    const mol = molesOf(s);
    return trapsOf(s).filter((t) => mol.some((m) => m >= 0 && (m === t || NB[m].includes(t))));
  }
  function inScare(s, t) { return s.sc.some(([c]) => area3(c).includes(t)); }
  function moleCands(s, i, from) {
    const out = [], b = s.b;
    if (from < 0) {
      for (const e of ENTRY) if (b[e] !== 'r') out.push({ e: 0, path: [e] });
      return out;
    }
    const eats = b[from] === 'c' ? [0, 1] : [0];
    for (const e of eats) {
      out.push({ e, path: [] });
      for (const n of NB[from]) {
        if (b[n] === 'r') continue;
        out.push({ e, path: [n] });
        if (!e) for (const n2 of NB[n]) if (b[n2] !== 'r' && n2 !== from) out.push({ e, path: [n, n2] });
      }
    }
    return out;
  }
  const MP = {
    2: { eat: 10, urg: 4, dist: 1.1, onCrop: 1.5, ent: 0.15, e1: 0.33, e2: 0.42, d2: 0.2, m0: 0.05, m1: 0.03, pdW: 0.25, sc: 0.25, risk: 9, spread: 0.5, noise: 2.4, swarm3: 1, swarm2: 1, near: 0 },
    3: { eat: 10, urg: 4, dist: 1.6, onCrop: 1.5, risk: 10, noise: 0.6 },
  };
  const FP = { 2: { bias0: 0, bias1: 0, top: 1, pow: 1, k: 6, trap: 0.3, trapP: 0.85, scare: 0.2, scareP: 0.6 }, 3: { bias0: 0, bias1: 0, top: 1, pow: 2, k: 6, trap: 0.3, trapP: 1, scare: 0.24, scareP: 1 } };
  const FL1 = { rnd: 0.12, trap: 0.32, scare: 0.1 };
  function aiMoles(s, seat, lv) {
    const mol = molesOf(s), mine = [];
    s.mo.forEach((o, i) => { if (o === seat && s.rs[i] === 0) mine.push(i); });
    const occ = new Set(mol.filter((t, i) => t >= 0 && !mine.includes(i)));
    const taken = new Set();
    const d0 = cropDist(s.b, -1);
    const pdN = s.pd;
    const smell = new Set(sensedTraps(s));
    // how many of my moles can eat right now (simultaneous eating overwhelms the farmer's two actions)
    const eaters = mine.filter((i) => mol[i] >= 0 && s.b[mol[i]] === 'c').length;
    const need = s.T - s.ate, roundsLeft = s.R - s.rd + 1;
    const urgency = U.clamp(need / Math.max(1, roundsLeft * 1.2), 0, 2);
    const mv = [];
    const order = mine.slice().sort((a, b) => (mol[a] < 0) - (mol[b] < 0));
    for (const i of order) {
      const from = mol[i];
      const cands = moleCands(s, i, from).filter((c) => {
        const dest = c.path.length ? c.path[c.path.length - 1] : from;
        if (lv >= 2 && c.path.some((t) => smell.has(t))) return false;
        if (lv <= 1 && c.path.some((t) => smell.has(t)) && Math.random() < 0.7) return false;
        return !occ.has(dest) && !taken.has(dest) && !mine.some((j) => j !== i && mol[j] === dest && !mv.some((m) => m[0] === j));
      });
      if (!cands.length) { mv.push([i, 0]); taken.add(from); continue; }
      let best = null, bs = -1e9;
      for (const c of cands) {
        const dest = c.path.length ? c.path[c.path.length - 1] : from;
        const dd = c.e ? cropDist(s.b, from)[dest] : d0[dest];
        let sc = 0;
        if (lv <= 1) {
          sc = (c.e ? 9 : 0) - dd * 1.2 + (c.path.length === 2 ? 0.6 : 0) + Math.random() * 7;
        } else {
          const P = MP[lv >= 3 ? 3 : 2];
          sc += c.e ? P.eat + urgency * P.urg : 0;
          sc -= dd * (P.dist + urgency * 0.4);
          if (s.b[dest] === 'c' && !(c.e && dest === from)) sc += P.onCrop;
          let exp;
          if (from < 0) exp = P.ent;
          else if (c.e) exp = c.path.length === 0 ? 0.95 : c.path.length === 1 ? P.e1 : P.e2;
          else if (c.path.length === 2) exp = P.d2;
          else exp = (c.path.length ? P.m1 : P.m0) + (pdN[dest] || 0) * P.pdW;
          if (inScare(s, dest)) exp += P.sc;
          if (lv >= 3) {
            if (c.e && eaters >= 3) exp *= P.swarm3; else if (c.e && eaters === 2) exp *= P.swarm2;
            const near = pdN[dest] + NB[dest].reduce((m, n) => m + (pdN[n] || 0), 0) * 0.3;
            exp += near * P.near;
          }
          sc -= exp * P.risk;
          if (taken.size) for (const t of taken) { const [x1, y1] = xy(t), [x2, y2] = xy(dest); if (Math.abs(x1 - x2) + Math.abs(y1 - y2) <= 1) sc -= P.spread; }
          sc += Math.random() * P.noise;
        }
        if (sc > bs) { bs = sc; best = c; }
      }
      const dest = best.path.length ? best.path[best.path.length - 1] : from;
      taken.add(dest);
      mv.push([i, best.e, ...best.path]);
    }
    return { t: 'm', mv };
  }
  // 어려움 두더지: 내 이동이 남길 단서로 농부의 추리 지도(pd)가 어떻게 바뀔지 직접 계산해 보고, 망치에 맞을 만한 칸을 피해요
  function aiMoles3(s, seat) {
    const P = MP[3];
    const mol = molesOf(s), mine = [];
    s.mo.forEach((o, i) => { if (o === seat && s.rs[i] === 0) mine.push(i); });
    const smell = new Set(sensedTraps(s));
    const need = s.T - s.ate, roundsLeft = s.R - s.rd + 1;
    const urgency = U.clamp(need / Math.max(1, roundsLeft * 1.2), 0, 2);
    const fin = mol.slice(), chosen = {};
    const ob0 = s.ob;
    let b = s.b;
    const obs = { e: ob0.e.slice(), d: ob0.d.slice(), en: ob0.en, c: ob0.c };
    const order = mine.slice().sort((a, c) => (mol[a] < 0) - (mol[c] < 0));
    for (const i of order) {
      const from = mol[i];
      const cands = moleCands({ b, sc: s.sc }, i, from).filter((c) => {
        if (c.path.some((t) => smell.has(t))) return false;
        const dest = c.path.length ? c.path[c.path.length - 1] : from;
        return !fin.some((t, j) => j !== i && t === dest);
      });
      if (!cands.length) { chosen[i] = { e: 0, path: [] }; continue; }
      let best = null, bs = -1e9;
      for (const c of cands) {
        const dest = c.path.length ? c.path[c.path.length - 1] : from;
        const b2 = c.e ? b.slice(0, from) + 'x' + b.slice(from + 1) : b;
        const ob = { e: c.e ? obs.e.concat([from]) : obs.e, d: c.path.length === 2 ? obs.d.concat([from]) : obs.d, en: obs.en + (from < 0 ? 1 : 0), c: obs.c };
        const pos = fin.slice(); pos[i] = dest;
        const bw = pos.map((t) => (t >= 0 ? 0 : 1));
        const s2 = { b: b2, pd: s.pd, hm: [], bw, sc: s.sc.map(([sc0]) => [sc0, area3(sc0).filter((t) => pos.includes(t)).length]) };
        const D = constrain(s2, phaseFilter(s2, ob, ob0.n0));
        const Hh = heat({ b: b2, pd: D }, 3);
        let risk = 0;
        if (Hh[dest] > 0.001) {
          const top = Hh.slice().sort((a, c) => c - a).slice(0, 6);
          const hd = Hh[dest], inTop = hd >= top[5] - 1e-9;
          const tot = sum(top.map((v) => v * v)) || 1;
          risk = inTop ? Math.min(0.95, (1.8 * hd * hd) / tot) : 0.03;
        }
        const dd = cropDist(b2, -1)[dest];
        let sc = (c.e ? P.eat + urgency * P.urg : 0) - risk * P.risk - dd * (P.dist + urgency * 0.4);
        if (b2[dest] === 'c') sc += P.onCrop;
        sc += Math.random() * P.noise;
        if (sc > bs) { bs = sc; best = c; }
      }
      chosen[i] = best;
      const dest = best.path.length ? best.path[best.path.length - 1] : from;
      if (best.e) { b = b.slice(0, from) + 'x' + b.slice(from + 1); obs.e.push(from); }
      if (best.path.length === 2) obs.d.push(from);
      if (from < 0) obs.en++;
      fin[i] = dest;
    }
    return { t: 'm', mv: order.map((i) => [i, chosen[i].e, ...chosen[i].path]) };
  }
  function heat(s, lv) {
    const Hh = s.pd.slice();
    const P = FP[lv >= 3 ? 3 : 2];
    if (lv >= 2 && (P.bias0 || P.bias1)) {
      const d = cropDist(s.b, -1);
      for (let t = 0; t < N; t++) if (Hh[t] > 0) Hh[t] *= 1 + (d[t] === 0 ? P.bias0 : d[t] === 1 ? P.bias1 : 0);
    }
    return Hh;
  }
  function aiFarmer(s, seat, lv) {
    const Hh = heat(s, lv), mx = Math.max(...Hh);
    const crops = []; for (let t = 0; t < N; t++) if (s.b[t] === 'c') crops.push(t);
    const traps = trapsOf(s);
    const hammerBest = () => {
      const ts = []; for (let t = 0; t < N; t++) if (s.b[t] !== 'r' && Hh[t] > 0) ts.push(t);
      if (!ts.length) return null;
      ts.sort((a, b) => Hh[b] - Hh[a]);
      if (lv >= 2) {
        const P = FP[lv >= 3 ? 3 : 2];
        if (P.pow) { // mixed strategy: smart moles dodge the single most obvious tile
          const top = ts.slice(0, P.k || 6), w = top.map((t) => Math.pow(Hh[t], P.pow));
          let r = Math.random() * sum(w);
          for (let j = 0; j < top.length; j++) { r -= w[j]; if (r <= 0) return { t: 'h', c: top[j] }; }
          return { t: 'h', c: top[0] };
        }
        return { t: 'h', c: Math.random() < P.top ? ts[0] : pick(ts.slice(0, 3)) };
      }
      // lv1: weighted random, sometimes a random guess
      if (Math.random() < FL1.rnd) return { t: 'h', c: pick(crops.length ? crops : ts) };
      let r = Math.random() * sum(ts.map((t) => Hh[t]));
      for (const t of ts) { r -= Hh[t]; if (r <= 0) return { t: 'h', c: t }; }
      return { t: 'h', c: ts[0] };
    };
    // where will moles arrive soon? crop tiles weighted by belief within two steps (+ a little for crops nearer the forest)
    const arrival = (t) => {
      let v = 0.05;
      for (let u = 0; u < N; u++) if (Hh[u] > 0) { const [x1, y1] = xy(t), [x2, y2] = xy(u), d = Math.abs(x1 - x2) + Math.abs(y1 - y2); if (d <= 3) v += Hh[u] / (1 + d); }
      const [x, y] = xy(t);
      v += (y / H) * 0.15 + (x === 1 || x === W - 2 ? 0.08 : 0);
      return v;
    };
    const freeCrops = crops.filter((t) => !traps.includes(t));
    const trapBest = () => {
      if (!freeCrops.length) return null;
      if (lv <= 1) return { t: 't', c: pick(freeCrops) };
      let best = freeCrops[0], bv = -1;
      for (const t of freeCrops) { const v = arrival(t) + Math.random() * (lv >= 3 ? 0.02 : 0.15); if (v > bv) { bv = v; best = t; } }
      return { t: 't', c: best };
    };
    const scareBest = () => {
      let best = -1, bv = -1;
      for (let c = 0; c < N; c++) {
        if (s.b[c] === 'r' || s.sc.some(([t]) => t === c)) continue;
        const A = area3(c);
        if (s.sc.some(([t]) => area3(t).filter((u) => A.includes(u)).length >= 3)) continue;
        let v = 0; for (const u of A) v += (s.b[u] === 'c' ? 0.35 : 0) + (lv >= 3 ? Hh[u] * (1 - Hh[u]) * 2 : Hh[u]);
        v += Math.random() * (lv >= 3 ? 0.05 : 0.6);
        if (v > bv) { bv = v; best = c; }
      }
      return best >= 0 ? { t: 's', c: best } : null;
    };
    const nOn = onBoard(s);
    let a = null;
    if (lv <= 1) {
      const r = Math.random();
      if (s.tl > 0 && r < FL1.trap) a = trapBest();
      else if (s.sl > 0 && r < FL1.trap + FL1.scare) a = scareBest();
    } else {
      const P = FP[lv >= 3 ? 3 : 2];
      if (s.tl > 0 && (nOn === 0 || mx < P.trap) && Math.random() < P.trapP) a = trapBest();
      else if (s.sl > 0 && s.rd >= 2 && mx < P.scare && Math.random() < P.scareP) a = scareBest();
    }
    if (!a && nOn > 0) a = hammerBest();
    if (!a && s.tl > 0) a = trapBest();
    if (!a && s.sl > 0) a = scareBest();
    if (!a) { if (s.fa < 2) a = { t: 'x' }; else a = { t: 'h', c: pick(crops.length ? crops : ENTRY) }; }
    return a;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'm') return lv >= 3 ? aiMoles3(s, seat) : aiMoles(s, seat, lv);
    if (s.ph === 'f') return aiFarmer(s, seat, lv);
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'e') return -1;
    const base = s.ph === 'm' ? 750 : 620;
    return lv <= 1 ? base + 250 : lv >= 3 ? base - 120 : base;
  }

  const T = { FL1, sensedTraps, MP, FP, W, H, N, NB, ENTRY, area3, molesOf, trapsOf, init, actor, apply, ai, result, onBoard, LENS };

  /* ---------------- view ---------------- */
  const MCOL = ['#ef7a5f', '#5bb8e0', '#e9c24f'];
  const MNAME = ['콩이', '두리', '보리'];
  const cropKind = (t) => (t * 5 + Math.floor(t / W) * 2) % 3; // 0 당근 · 1 배추 · 2 무
  const FONT = '"IBM Plex Sans KR", "Apple SD Gothic Neo", sans-serif';
  const MONO = '"IBM Plex Mono", monospace';
  const ease = (t) => 1 - Math.pow(1 - U.clamp(t, 0, 1), 3);

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, G = null, staticL = null, now = performance.now();
    let plan = {}, planKey = '', sel = -1, chosen = new Set();
    let tool = 'h', aim = -1, hover = -1, pending = false, pendSeq = -1;
    let heatOn = !!U.store.get('moles.heat', false);
    let anim = null, prevSt = null;
    const parts = [], pops = [];

    /* --- DOM --- */
    const sRound = L.h('span', { style: { fontWeight: 700, whiteSpace: 'nowrap' } });
    const sCrop = L.h('span', { style: { fontWeight: 700, whiteSpace: 'nowrap' } });
    const barIn = L.h('span', { style: { display: 'block', height: '100%', width: '0%', background: 'linear-gradient(90deg,#ef8a3c,#f2b24a)', borderRadius: '4px', transition: 'width .3s' } });
    const bar = L.h('span', { style: { display: 'inline-block', width: '64px', height: '8px', borderRadius: '4px', background: 'rgba(255,255,255,.12)', overflow: 'hidden', verticalAlign: 'middle' } }, barIn);
    const sCau = L.h('span', { class: 'muted', style: { fontSize: '12.5px', whiteSpace: 'nowrap' } });
    const heatBtn = L.h('button', { class: 'btn sm ml-heat', style: { minHeight: '44px', padding: '4px 10px', fontSize: '12.5px', whiteSpace: 'nowrap', flex: 'none' }, onclick() { heatOn = !heatOn; U.store.set('moles.heat', heatOn); api.sfx('click'); refresh(); } });
    const topPanel = L.h('div', { class: 'panel ml-top', style: { display: 'flex', alignItems: 'center', gap: '10px', padding: '4px 10px', minHeight: '44px', boxSizing: 'border-box', width: '100%', maxWidth: '440px', justifyContent: 'space-between', flexWrap: 'nowrap', fontSize: '13px' } },
      sRound, L.h('span', { style: { display: 'flex', alignItems: 'center', gap: '6px' } }, sCrop, bar), sCau, heatBtn);
    const topHud = L.h('div', { class: 'hud top', style: { padding: '3px 8px' } }, topPanel);
    const hint = L.h('div', { style: { fontSize: '12.5px', fontWeight: 700, lineHeight: 1.35, textAlign: 'center', minHeight: '17px' } });
    const row = L.h('div', { style: { display: 'flex', gap: '6px', justifyContent: 'center', flexWrap: 'nowrap', width: '100%' } });
    const botPanel = L.h('div', { class: 'panel ml-bot', style: { padding: '5px 8px', width: '100%', maxWidth: '440px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' } }, hint, row);
    const botHud = L.h('div', { class: 'hud bottom', style: { padding: '3px 8px 4px' } }, botPanel);
    const fieldMark = L.h('div', { class: 'ml-field', style: { position: 'absolute', pointerEvents: 'none' } });
    root.append(fieldMark, topHud, botHud);
    const mkBtn = (text, onclick, extra) => L.h('button', Object.assign({ class: 'btn sm', style: { minHeight: '44px', flex: '1 1 0', padding: '2px 4px', fontSize: '12.5px', whiteSpace: 'nowrap', minWidth: '0' }, text, onclick }, extra || {}));

    /* --- who sees what --- */
    const spectator = () => api.mySeats().length === 0;
    const ended = () => !!st && st.ph === 'e';
    const vw = () => api.viewer();
    const seeMoles = () => !!st && (spectator() || ended() || (vw() >= 0 && vw() !== st.fs));
    const seeTraps = () => !!st && (spectator() || ended() || vw() === st.fs);
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const myAct = () => { if (!st || ended() || anim || pending) return false; const a = actor(st); return a != null && api.canAct(a) && vw() === a; };
    const farmerTurn = () => myAct() && st.ph === 'f';
    const moleTurn = () => myAct() && st.ph === 'm';
    const curMoles = () => (st ? molesOf(st) : [-1, -1, -1]);
    const myMoles = () => { const a = actor(st); const out = []; st.mo.forEach((o, i) => { if (o === a && st.rs[i] === 0) out.push(i); }); return out; };

    /* --- layout --- */
    function layout() {
      const Wd = cv.w, Ht = cv.h;
      const tH = topHud.offsetHeight || 56, bH = botHud.offsetHeight || 110;
      const availH = Ht - tH - bH - 2;
      let c = Math.floor(Math.min((Wd - 24) / W, (availH - 2) / (H + 0.62)));
      c = Math.max(24, Math.min(c, 64));
      const barn = Math.round(c * 0.3), forest = Math.round(c * 0.32);
      const fw = c * W, fh = c * H;
      const ox = Math.round((Wd - fw) / 2);
      const total = barn + fh + forest;
      const oy = Math.round(tH + 1 + Math.max(0, (availH - total) / 2) + barn);
      G = { c, ox, oy, fw, fh, barn, forest, W: Wd, H: Ht };
      Object.assign(fieldMark.style, { left: (ox - 4) + 'px', top: (oy - 4) + 'px', width: (fw + 8) + 'px', height: (fh + 8) + 'px' });
    }
    cv.onresize = () => { layout(); };
    const tc = (t) => [G.ox + ((t % W) + 0.5) * G.c, G.oy + (Math.floor(t / W) + 0.5) * G.c];
    function tileAt(x, y) {
      const X = Math.floor((x - G.ox) / G.c), Y = Math.floor((y - G.oy) / G.c);
      if (X < 0 || Y < 0 || X >= W || Y >= H) return -1;
      return Y * W + X;
    }
    const inForest = (x, y) => y > G.oy + G.fh && y < G.oy + G.fh + G.forest + 14 && x > G.ox - 10 && x < G.ox + G.fw + 10;

    /* --- static layer: sky, barn, forest, soil --- */
    function buildStatic() {
      const oc = document.createElement('canvas');
      oc.width = Math.ceil(G.W * cv.dpr); oc.height = Math.ceil(G.H * cv.dpr);
      const g = oc.getContext('2d'); g.scale(cv.dpr, cv.dpr);
      const { c, ox, oy, fw, fh, barn, forest } = G;
      const bg = g.createLinearGradient(0, 0, 0, G.H); bg.addColorStop(0, '#1d1828'); bg.addColorStop(1, '#141a14');
      g.fillStyle = bg; g.fillRect(0, 0, G.W, G.H);
      // meadow behind the field
      const mx = ox - 12, my = oy - barn - 4, mw = fw + 24, mh = fh + barn + forest + 8;
      g.fillStyle = '#2d4a24'; rr(g, mx, my, mw, mh, 14); g.fill();
      let seed = 77;
      const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      g.fillStyle = 'rgba(160,220,120,.12)';
      for (let i = 0; i < 160; i++) { const x = mx + rnd() * mw, y = my + rnd() * mh; g.fillRect(x, y, 1.2, 3); }
      // barn + fence (top)
      const by = oy - barn;
      g.strokeStyle = '#c9a36b'; g.lineWidth = 2;
      g.beginPath(); g.moveTo(ox - 6, oy - 4); g.lineTo(ox + fw + 6, oy - 4); g.moveTo(ox - 6, oy - barn * 0.55); g.lineTo(ox + fw + 6, oy - barn * 0.55); g.stroke();
      for (let x = ox - 4; x <= ox + fw + 4; x += c / 2) { g.fillStyle = '#d8b57c'; g.fillRect(x - 1.5, oy - barn * 0.75, 3, barn * 0.75 - 2); }
      const bw = c * 1.6, bx = ox + fw / 2 - bw / 2, bh = barn * 1.15;
      g.fillStyle = '#9c3b2e'; g.fillRect(bx, by - bh * 0.25, bw, bh);
      g.fillStyle = '#6a2219'; g.beginPath(); g.moveTo(bx - 4, by - bh * 0.25); g.lineTo(bx + bw / 2, by - bh * 0.85); g.lineTo(bx + bw + 4, by - bh * 0.25); g.closePath(); g.fill();
      g.fillStyle = '#f2e6cf'; g.fillRect(bx + bw / 2 - bh * 0.22, by + bh * 0.2, bh * 0.44, bh * 0.55);
      g.strokeStyle = '#9c3b2e'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(bx + bw / 2 - bh * 0.22, by + bh * 0.2); g.lineTo(bx + bw / 2 + bh * 0.22, by + bh * 0.75); g.moveTo(bx + bw / 2 + bh * 0.22, by + bh * 0.2); g.lineTo(bx + bw / 2 - bh * 0.22, by + bh * 0.75); g.stroke();
      // forest (bottom): bushes
      const fy = oy + fh;
      for (let i = 0; i < 18; i++) {
        const x = ox - 8 + (i + 0.5) * ((fw + 16) / 18), r = forest * (0.42 + rnd() * 0.25);
        g.fillStyle = i % 2 ? '#1f3a1c' : '#25442080'; g.beginPath(); g.arc(x, fy + forest * 0.75, r, 0, 7); g.fill();
      }
      g.fillStyle = '#1b3318'; g.fillRect(ox - 8, fy + forest * 0.6, fw + 16, forest * 0.45);
      // side bushes next to side entries
      for (const side of [0, 1]) for (let y = 6; y < H; y++) {
        const x = side ? ox + fw + 6 : ox - 6, yy = oy + (y + 0.5) * c;
        g.fillStyle = '#21401d'; g.beginPath(); g.arc(x, yy, c * 0.22, 0, 7); g.fill();
      }
      // soil tiles
      for (let t = 0; t < N; t++) {
        const X = ox + (t % W) * c, Y = oy + Math.floor(t / W) * c;
        g.fillStyle = (t + Math.floor(t / W)) % 2 ? '#6e4627' : '#754c2b';
        g.fillRect(X, Y, c, c);
        g.strokeStyle = 'rgba(40,20,8,.35)'; g.lineWidth = 1;
        for (let k = 1; k <= 3; k++) { g.beginPath(); g.moveTo(X + 3, Y + (k * c) / 4); g.lineTo(X + c - 3, Y + (k * c) / 4); g.stroke(); }
        g.fillStyle = 'rgba(255,220,170,.05)'; g.fillRect(X, Y, c, 2);
      }
      // entry marks: tiny grass tufts along forest edges
      g.strokeStyle = 'rgba(150,210,110,.55)'; g.lineWidth = 1.5;
      for (const e of ENTRY) {
        const [x, y] = [ox + ((e % W) + 0.5) * c, oy + (Math.floor(e / W) + 0.5) * c];
        const dx = e % W === 0 ? -c / 2 : e % W === W - 1 ? c / 2 : 0, dy = Math.floor(e / W) === H - 1 ? c / 2 : 0;
        const ex = x + (dx ? dx : 0), ey = y + (dy ? dy : 0);
        for (let k = -1; k <= 1; k++) { g.beginPath(); g.moveTo(ex + k * 4 - (dx ? 0 : 0), ey); g.lineTo(ex + k * 5 + (dx < 0 ? -3 : dx > 0 ? 3 : 0), ey - (dy ? 5 : 0) + (dx ? -2 : 0)); g.stroke(); }
      }
      // rim
      g.strokeStyle = 'rgba(227,174,69,.45)'; g.lineWidth = 1.5; g.strokeRect(ox - 0.5, oy - 0.5, fw + 1, fh + 1);
      staticL = { cv: oc, key: skey() };
    }
    const skey = () => [G.c, G.W, G.H, G.ox, G.oy, cv.dpr].join(':');
    function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }

    /* --- sprites --- */
    function drawRock(x, y, c) {
      ctx.fillStyle = '#5d5866'; ctx.beginPath(); ctx.ellipse(x, y + c * 0.06, c * 0.38, c * 0.3, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#7d7889'; ctx.beginPath(); ctx.ellipse(x - c * 0.06, y - c * 0.02, c * 0.28, c * 0.2, -0.3, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.ellipse(x - c * 0.12, y - c * 0.1, c * 0.09, c * 0.05, -0.4, 0, 7); ctx.fill();
    }
    function drawHole(x, y, c) {
      ctx.fillStyle = '#4a2c16'; ctx.beginPath(); ctx.ellipse(x, y + c * 0.05, c * 0.3, c * 0.2, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#1c0f06'; ctx.beginPath(); ctx.ellipse(x, y + c * 0.07, c * 0.2, c * 0.12, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(120,180,80,.7)'; ctx.lineWidth = Math.max(1.5, c * 0.04);
      ctx.beginPath(); ctx.moveTo(x + c * 0.18, y - c * 0.08); ctx.lineTo(x + c * 0.3, y - c * 0.2); ctx.stroke();
    }
    function drawCrop(t, x, y, c, sc, wob) {
      const k = cropKind(t), sw = Math.sin(now / 700 + t) * 0.06 + wob;
      ctx.save(); ctx.translate(x, y + c * 0.12); ctx.scale(sc, sc);
      ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(0, c * 0.14, c * 0.3, c * 0.09, 0, 0, 7); ctx.fill();
      if (k === 0) { // 당근
        ctx.rotate(sw);
        ctx.strokeStyle = '#4fae46'; ctx.lineWidth = Math.max(2, c * 0.07); ctx.lineCap = 'round';
        for (const a of [-0.5, 0, 0.5]) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(a * c * 0.2, -c * 0.22, a * c * 0.42, -c * 0.4); ctx.stroke(); }
        ctx.fillStyle = '#f08a2c'; ctx.beginPath(); ctx.ellipse(0, c * 0.05, c * 0.16, c * 0.1, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(120,50,10,.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-c * 0.07, c * 0.05); ctx.lineTo(c * 0.03, c * 0.06); ctx.stroke();
      } else if (k === 1) { // 배추
        ctx.rotate(sw * 0.5);
        ctx.fillStyle = '#3f8f3a'; ctx.beginPath(); ctx.arc(0, -c * 0.04, c * 0.3, 0, 7); ctx.fill();
        ctx.fillStyle = '#6cc25a'; ctx.beginPath(); ctx.arc(0, -c * 0.06, c * 0.22, 0, 7); ctx.fill();
        ctx.fillStyle = '#b8e889'; ctx.beginPath(); ctx.arc(0, -c * 0.07, c * 0.12, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(30,80,30,.5)'; ctx.lineWidth = 1;
        for (const a of [0.6, 2.2, 3.8, 5.2]) { ctx.beginPath(); ctx.moveTo(0, -c * 0.06); ctx.lineTo(Math.cos(a) * c * 0.27, -c * 0.06 + Math.sin(a) * c * 0.27); ctx.stroke(); }
      } else { // 무
        ctx.rotate(sw);
        ctx.fillStyle = '#2f7d3a';
        for (const a of [-1, 1]) { ctx.beginPath(); ctx.ellipse(a * c * 0.13, -c * 0.2, c * 0.11, c * 0.23, a * 0.45, 0, 7); ctx.fill(); }
        ctx.fillStyle = '#4ea24c'; ctx.beginPath(); ctx.ellipse(0, -c * 0.26, c * 0.08, c * 0.2, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#efe9dc'; ctx.beginPath(); ctx.ellipse(0, c * 0.03, c * 0.15, c * 0.12, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#a6d17a'; ctx.beginPath(); ctx.ellipse(0, -c * 0.04, c * 0.13, c * 0.05, 0, 0, 7); ctx.fill();
      }
      ctx.restore();
    }
    function drawMound(x, y, c, fade) {
      ctx.save(); ctx.globalAlpha *= fade;
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(x, y + c * 0.18, c * 0.36, c * 0.1, 0, 0, 7); ctx.fill();
      const g = ctx.createRadialGradient(x - c * 0.08, y - c * 0.05, c * 0.03, x, y + c * 0.05, c * 0.38);
      g.addColorStop(0, '#b07a48'); g.addColorStop(1, '#5c3519');
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(x, y + c * 0.08, c * 0.34, c * 0.24, 0, Math.PI, 0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#8a5a30';
      for (const [dx, dy] of [[-0.36, 0.12], [0.33, 0.14], [0.2, 0.2], [-0.2, 0.19]]) { ctx.beginPath(); ctx.arc(x + dx * c, y + dy * c, c * 0.04, 0, 7); ctx.fill(); }
      ctx.restore();
    }
    function drawMole(x, y, r, col, o) {
      o = o || {};
      ctx.save(); ctx.translate(x, y);
      if (o.alpha != null) ctx.globalAlpha *= o.alpha;
      if (o.under) { // 땅속: 점선 고리
        ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(255,230,190,.65)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(0, 0, r * 1.25, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(0, r * 0.85, r * 0.9, r * 0.25, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#5f4f4b'; ctx.beginPath(); ctx.ellipse(0, 0, r, r * 0.95, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#d7b39a'; ctx.beginPath(); ctx.ellipse(0, r * 0.32, r * 0.55, r * 0.42, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#ffffff'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sx * r * 0.14, r * 0.62, r * 0.09, r * 0.12, 0, 0, 7); ctx.fill(); }
      ctx.fillStyle = '#ff8fa3'; ctx.beginPath(); ctx.ellipse(0, r * 0.18, r * 0.2, r * 0.14, 0, 0, 7); ctx.fill();
      if (o.dizzy) {
        ctx.strokeStyle = '#151015'; ctx.lineWidth = Math.max(1.2, r * 0.1);
        for (const sx of [-1, 1]) { const ex = sx * r * 0.36, ey = -r * 0.12, d = r * 0.11; ctx.beginPath(); ctx.moveTo(ex - d, ey - d); ctx.lineTo(ex + d, ey + d); ctx.moveTo(ex + d, ey - d); ctx.lineTo(ex - d, ey + d); ctx.stroke(); }
      } else {
        ctx.fillStyle = '#151015'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(sx * r * 0.36, -r * 0.12, r * 0.1, 0, 7); ctx.fill(); }
        ctx.fillStyle = '#fff'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(sx * r * 0.36 + r * 0.03, -r * 0.15, r * 0.035, 0, 7); ctx.fill(); }
      }
      // bandana
      ctx.strokeStyle = col; ctx.lineWidth = r * 0.26; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(0, r * 0.2, r * 0.9, Math.PI * 1.18, Math.PI * 1.82); ctx.stroke();
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(r * 0.72, -r * 0.5); ctx.lineTo(r * 1.08, -r * 0.72); ctx.lineTo(r * 1.0, -r * 0.36); ctx.closePath(); ctx.fill();
      // claws
      ctx.fillStyle = '#f6c3b7'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sx * r * 0.82, r * 0.55, r * 0.22, r * 0.14, sx * 0.5, 0, 7); ctx.fill(); }
      if (o.dizzy) {
        ctx.fillStyle = '#ffe27a';
        for (let k = 0; k < 3; k++) { const a = now / 180 + k * 2.1; star(Math.cos(a) * r * 0.9, -r * 1.15 + Math.sin(a) * r * 0.25, r * 0.2); }
      }
      if (o.zz) { ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.font = '700 ' + Math.round(r * 0.8) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.fillText('z', r * 0.9, -r * 0.9 + Math.sin(now / 300) * 2); }
      ctx.restore();
    }
    function star(x, y, r) {
      ctx.beginPath();
      for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + (k * Math.PI) / 5, rr2 = k % 2 ? r * 0.45 : r; ctx.lineTo(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
      ctx.closePath(); ctx.fill();
    }
    function drawScarecrow(x, y, c, cnt, rise) {
      const h = c * 0.9 * rise;
      ctx.save(); ctx.translate(x, y + c * 0.38);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(0, 0, c * 0.22, c * 0.07, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#8a6236'; ctx.lineWidth = Math.max(2, c * 0.07); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -h); ctx.moveTo(-c * 0.34, -h * 0.66); ctx.lineTo(c * 0.34, -h * 0.66); ctx.stroke();
      ctx.fillStyle = '#4b6fb0'; ctx.beginPath(); ctx.moveTo(-c * 0.22, -h * 0.72); ctx.lineTo(c * 0.22, -h * 0.72); ctx.lineTo(c * 0.16, -h * 0.36); ctx.lineTo(-c * 0.16, -h * 0.36); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#e8cc7a'; ctx.beginPath(); ctx.arc(0, -h * 0.86, c * 0.13, 0, 7); ctx.fill();
      ctx.fillStyle = '#7a4a22'; ctx.beginPath(); ctx.ellipse(0, -h * 0.95, c * 0.24, c * 0.06, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(0, -h * 1.0, c * 0.12, c * 0.09, 0, Math.PI, 0); ctx.fill();
      ctx.fillStyle = '#2a1a10'; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(sx * c * 0.05, -h * 0.86, c * 0.02, 0, 7); ctx.fill(); }
      ctx.restore();
      if (cnt != null && rise >= 1) {
        const bx = x + c * 0.3, by = y - c * 0.38, r = Math.max(9, c * 0.2);
        ctx.fillStyle = cnt > 0 ? '#ee6a55' : '#4f9e64'; ctx.beginPath(); ctx.arc(bx, by, r, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = '700 ' + Math.round(r * 1.2) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(String(cnt), bx, by + 1);
      }
    }
    function drawTrap(x, y, c, mode) {
      // mode: 'own' (농부 화면), 'smell' (두더지가 냄새 맡음), 'ghost' (놓기 미리보기)
      ctx.save(); ctx.translate(x, y + c * 0.05);
      if (mode === 'ghost') ctx.globalAlpha *= 0.6;
      if (mode === 'smell') {
        ctx.setLineDash([4, 3]); ctx.strokeStyle = '#ff6b5a'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, -c * 0.05, c * 0.36, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        ctx.globalAlpha *= 0.75;
      }
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(0, c * 0.1, c * 0.28, c * 0.08, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#c8ccd6'; ctx.lineWidth = Math.max(2, c * 0.06);
      ctx.beginPath(); ctx.arc(0, 0, c * 0.22, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, c * 0.22, Math.PI * 0.05, Math.PI * 0.95); ctx.stroke();
      ctx.fillStyle = '#e8ebf2';
      for (let k = -2; k <= 2; k++) { const xx = k * c * 0.08; ctx.beginPath(); ctx.moveTo(xx - c * 0.03, -c * 0.02); ctx.lineTo(xx, -c * 0.1); ctx.lineTo(xx + c * 0.03, -c * 0.02); ctx.fill(); ctx.beginPath(); ctx.moveTo(xx - c * 0.03, c * 0.02); ctx.lineTo(xx, c * 0.1); ctx.lineTo(xx + c * 0.03, c * 0.02); ctx.fill(); }
      ctx.fillStyle = '#8a8f9c'; ctx.beginPath(); ctx.arc(0, 0, c * 0.05, 0, 7); ctx.fill();
      ctx.restore();
      if (mode === 'smell') {
        ctx.fillStyle = '#ff6b5a'; ctx.font = '700 ' + Math.round(Math.max(10, c * 0.26)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('냄새!', x, y - c * 0.36);
      }
    }
    function drawHammer(x, y, c, ang) {
      ctx.save(); ctx.translate(x + c * 0.85, y + c * 0.15); ctx.rotate(ang);
      ctx.fillStyle = '#b5884f'; ctx.fillRect(-c * 0.85, -c * 0.05, c * 0.85, c * 0.1);
      ctx.fillStyle = '#7a5530'; rr(ctx, -c * 1.0, -c * 0.32, c * 0.3, c * 0.5, c * 0.06); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.22)'; ctx.fillRect(-c * 0.97, -c * 0.3, c * 0.07, c * 0.46);
      ctx.restore();
    }
    function drawText(t, x, y, size, color, weight) {
      ctx.font = (weight || 800) + ' ' + size + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(20,12,8,.8)'; ctx.strokeText(t, x, y);
      ctx.fillStyle = color; ctx.fillText(t, x, y);
    }
    function dust(x, y, n, col, sp) {
      for (let k = 0; k < n; k++) {
        const a = Math.random() * Math.PI * 2, v = (0.4 + Math.random()) * (sp || 60);
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, life: 0, max: 0.5 + Math.random() * 0.4, col: col || '#a87a4c', r: 1.5 + Math.random() * 2.5 });
      }
    }
    function popText(t, x, y, col) { pops.push({ t, x, y, col, life: 0, max: 1.1 }); }

    /* --- mole planning --- */
    function finalsExcept(i) {
      const mol = curMoles(), out = [];
      for (let j = 0; j < NM; j++) {
        if (j === i) continue;
        const p = plan[j];
        const f = p && p.path.length ? p.path[p.path.length - 1] : mol[j];
        if (f >= 0) out.push(f);
      }
      return out;
    }
    function reach(i) {
      const mol = curMoles(), from = mol[i], b = st.b, m = new Map();
      const blocked = new Set(finalsExcept(i));
      const smell = new Set(sensedTraps(st));
      const add = (d, path) => { if (blocked.has(d)) return; if (!m.has(d)) m.set(d, []); m.get(d).push(path); };
      if (from < 0) { for (const e of ENTRY) if (b[e] !== 'r') add(e, [e]); }
      else {
        const eat = plan[i] && plan[i].e;
        add(from, []);
        for (const n of NB[from]) {
          if (b[n] === 'r') continue;
          add(n, [n]);
          if (!eat) for (const n2 of NB[n]) if (b[n2] !== 'r' && n2 !== from) add(n2, [n, n2]);
        }
      }
      // prefer routes that avoid a smelled trap
      for (const [d, ps] of m) ps.sort((a, c) => a.filter((t) => smell.has(t)).length - c.filter((t) => smell.has(t)).length);
      return m;
    }
    function resetPlan() {
      plan = {}; chosen = new Set(); sel = -1;
      if (!st || st.ph !== 'm') return;
      const mol = curMoles(), a = actor(st);
      st.mo.forEach((o, i) => { if (o === a && st.rs[i] === 0 && mol[i] >= 0) plan[i] = { e: st.b[mol[i]] === 'c' ? 1 : 0, path: [] }; });
      const mine = myMoles();
      sel = mine.length ? mine[0] : -1;
    }
    function nextUnchosen() {
      const mine = myMoles();
      const k = mine.indexOf(sel);
      for (let d = 1; d <= mine.length; d++) { const j = mine[(k + d) % mine.length]; if (!chosen.has(j)) return j; }
      return sel;
    }
    function moleTap(t) {
      const mol = curMoles(), mine = myMoles();
      const other = mine.find((j) => j !== sel && (mol[j] === t || (plan[j] && plan[j].path.length && plan[j].path[plan[j].path.length - 1] === t)));
      const R = sel >= 0 ? reach(sel) : null;
      if (other != null && !(R && R.has(t) && mol[other] !== t)) { sel = other; api.sfx('click'); refresh(); return; }
      if (!R || !R.has(t)) {
        if (sel >= 0 && mol[sel] >= 0 && plan[sel] && plan[sel].e && Math.abs((t % W) - (mol[sel] % W)) + Math.abs(Math.floor(t / W) - Math.floor(mol[sel] / W)) === 2) api.toast('배불러서 1칸만 움직일 수 있어요');
        else if (sel >= 0 && mol[sel] < 0) api.toast('숲에서 들어올 때는 초록 가장자리 칸을 골라요');
        else api.toast('표시된 칸으로만 갈 수 있어요');
        api.buzz(10); return;
      }
      const paths = R.get(t), cur = plan[sel] || { e: 0, path: [] };
      const curDest = cur.path.length ? cur.path[cur.path.length - 1] : mol[sel];
      let path = paths[0];
      if (curDest === t && paths.length > 1 && chosen.has(sel)) {
        const k = paths.findIndex((p) => p.join() === cur.path.join());
        path = paths[(k + 1) % paths.length];
        api.toast('다른 길로 바꿨어요');
      }
      const smell = sensedTraps(st);
      if (path.some((x) => smell.includes(x))) { api.toast('그 길엔 덫 냄새가 나요! 다른 칸을 골라요'); api.buzz(20); return; }
      plan[sel] = { e: cur.e, path: path.slice() };
      chosen.add(sel);
      api.sfx(path.length === 2 ? 'roll' : 'tick'); api.buzz(8);
      const wasSel = sel;
      sel = nextUnchosen();
      if (sel === wasSel && myMoles().every((j) => chosen.has(j))) sel = wasSel;
      refresh();
    }
    function toggleEat() {
      const mol = curMoles();
      if (sel < 0 || mol[sel] < 0 || st.b[mol[sel]] !== 'c') return;
      const p = plan[sel] || { e: 0, path: [] };
      p.e = p.e ? 0 : 1;
      if (p.e && p.path.length > 1) { p.path = []; chosen.delete(sel); api.toast('먹으면 1칸만 움직여요 — 다시 골라 주세요'); }
      plan[sel] = p; api.sfx('click'); refresh();
    }
    function submitMoles() {
      const mv = [];
      for (const i of myMoles()) { const p = plan[i]; if (p) mv.push([i, p.e ? 1 : 0, ...p.path]); }
      send({ t: 'm', mv });
    }
    function send(a) { pending = true; pendSeq = st.seq; aim = -1; api.act(a); setTimeout(() => { if (pending && st && st.seq === pendSeq) { pending = false; refresh(); } }, 4000); refresh(); }

    /* --- farmer --- */
    const TOOLN = { h: '망치', t: '덫', s: '허수아비' };
    function farmerTap(t) {
      if (st.b[t] === 'r') { api.toast('바위에는 쓸 수 없어요'); api.buzz(10); return; }
      if (tool === 't' && (st.tl <= 0 || trapsOf(st).includes(t))) { api.toast(st.tl <= 0 ? '덫을 다 썼어요' : '이미 덫이 있어요'); return; }
      if (tool === 's' && (st.sl <= 0 || st.sc.some(([c]) => c === t))) { api.toast(st.sl <= 0 ? '허수아비를 다 썼어요' : '이미 허수아비가 있어요'); return; }
      if (aim === t) { commitFarmer(); return; }
      aim = t; api.sfx('tick'); refresh();
    }
    function commitFarmer() { if (aim < 0) return; send({ t: tool, c: aim }); }

    /* --- HUD --- */
    function refresh() {
      if (!st) return;
      const mT = myAct();
      sRound.textContent = '라운드 ' + Math.min(st.rd, st.R) + '/' + st.R;
      sCrop.textContent = '먹힌 작물 ' + st.ate + '/' + st.T;
      barIn.style.width = Math.round((st.ate / st.T) * 100) + '%';
      sCau.textContent = '잡힘 ' + st.cau;
      const farmerView = vw() === st.fs && !spectator();
      heatBtn.style.display = (!(farmerView || spectator()) || ended()) ? 'none' : '';
      heatBtn.textContent = heatOn ? '추리 ✓' : '추리';
      heatBtn.classList.toggle('primary', heatOn);
      row.innerHTML = '';
      if (farmerTurn()) {
        for (const k of ['h', 't', 's']) {
          const left = k === 't' ? st.tl : k === 's' ? st.sl : null;
          const b = mkBtn(TOOLN[k] + (left != null ? ' ' + left : ''), () => { if (left === 0) { api.toast(TOOLN[k] + '를 다 썼어요'); return; } tool = k; aim = -1; api.sfx('click'); refresh(); });
          if (tool === k) b.classList.add('primary');
          if (left === 0) { b.disabled = true; b.style.opacity = '.45'; }
          row.append(b);
        }
        const verb = tool === 'h' ? '쾅!' : tool === 't' ? '묻기' : '세우기';
        const go = mkBtn(aim >= 0 ? verb : st.fa < 2 ? '넘기기' : verb, () => { if (aim >= 0) commitFarmer(); else if (st.fa < 2) send({ t: 'x' }); else api.toast('먼저 칸을 톡 하세요'); }, { class: 'btn sm ml-go' });
        go.style.flex = '1.2 1 0';
        if (aim >= 0) go.classList.add('primary'); else if (st.fa >= 2) go.style.opacity = '.55';
        row.append(go);
      } else if (moleTurn()) {
        const mol = curMoles();
        for (const i of myMoles()) {
          const p = plan[i], inB = mol[i] < 0;
          const st2 = inB ? (chosen.has(i) ? '입장' : '숲') : p && p.e ? '냠냠' : p && p.path.length === 2 ? '굴' : p && p.path.length === 1 ? '살금' : '그대로';
          const b = mkBtn('', () => { sel = i; api.sfx('click'); refresh(); });
          b.append(L.h('span', { style: { width: '10px', height: '10px', borderRadius: '50%', background: MCOL[i], flex: 'none' } }), L.h('span', { text: MNAME[i].slice(0, 1) + '·' + st2 }));
          b.style.padding = '2px 3px';
          if (sel === i) b.classList.add('primary');
          row.append(b);
        }
        const onCrop = sel >= 0 && mol[sel] >= 0 && st.b[mol[sel]] === 'c';
        if (onCrop) {
          const e = plan[sel] && plan[sel].e;
          const b = mkBtn(e ? '냠냠 ✓' : '냠냠', toggleEat, { class: 'btn sm ml-eat' });
          if (e) b.style.background = '#4f9e64';
          row.append(b);
        }
        const done = mkBtn('완료', submitMoles, { class: 'btn sm primary ml-go' });
        done.style.flex = '1.2 1 0';
        row.append(done);
      } else {
        const t = ended() ? '' : null;
        if (t == null) row.append(L.h('div', { class: 'muted', style: { fontSize: '12.5px', minHeight: '44px', display: 'flex', alignItems: 'center' }, text: waitText() }));
      }
      hint.textContent = hintText();
      hint.style.color = mT ? 'var(--brass)' : 'var(--ink)';
    }
    function waitText() {
      if (!st) return '';
      const a = actor(st);
      if (a == null) return '';
      if (st.ph === 'f') return api.players[a] && api.players[a].ai ? '농부가 밭을 살피는 중…' : nm(a) + '(농부) 차례';
      return api.players[a] && api.players[a].ai ? '두더지들이 땅속에서 꼼지락…' : nm(a) + '(두더지) 차례';
    }
    function hintText() {
      if (!st) return '';
      if (ended()) {
        const v = vw(), mw = st.win === 'm';
        if (spectator() || v < 0) return mw ? '두더지 팀 승리! 작물 ' + st.ate + '개 꿀꺽' : '농부 승리! 밭을 지켰어요';
        const meMole = v !== st.fs;
        return (mw === meMole) ? '승리! 🎉' : (meMole ? '농부가 밭을 지켰어요' : '두더지들이 작물을 다 먹었어요');
      }
      if (pending || anim) return waitText() || '…';
      if (farmerTurn()) {
        const left = '(남은 행동 ' + st.fa + ')';
        if (aim >= 0) return (tool === 'h' ? '한 번 더 톡 하거나 「쾅!」' : tool === 't' ? '「묻기」를 누르면 몰래 덫을 묻어요' : '「세우기」: 둘레 9칸 두더지 수를 알려 줘요') + ' ' + left;
        return (tool === 'h' ? '두더지가 있을 것 같은 칸을 톡' : tool === 't' ? '덫을 묻을 칸을 톡(두더지는 옆 칸에서 냄새를 맡아요)' : '허수아비를 세울 칸을 톡') + ' ' + left;
      }
      if (moleTurn()) {
        const mol = curMoles();
        if (sel < 0) return '「완료」를 누르세요';
        const nmS = MNAME[sel];
        if (mol[sel] < 0) return nmS + ': 숲에서 들어올 초록 가장자리 칸을 톡';
        const p = plan[sel];
        if (p && p.e) return nmS + ': 냠냠! 먹고 나서 1칸까지 움직일 수 있어요';
        return nmS + ': 초록 = 살금 1칸 · 주황 = 빠른 굴 2칸(흙더미)';
      }
      const v = vw();
      if (!spectator() && v >= 0) return v === st.fs ? '당신은 농부예요 — 단서를 보고 두더지를 찾아요' : '당신은 두더지 팀이에요 — 몰래 작물을 먹어요';
      return waitText();
    }

    /* --- animations from state.last --- */
    function startAnim(s, prev) {
      const l = s.last;
      if (!l) return;
      const sp = L.debug.speed || 1;
      if (l.k === 'm') {
        const visible = seeMoles();
        anim = { k: 'm', t0: now, dur: (visible ? 950 : 750) / sp, l, prevB: prev.b, prevMol: molesOf(prev), done: {} };
        const myMoleView = !spectator() && vw() >= 0 && vw() !== s.fs;
        const eats = l.ev.filter((e) => e[0] === 'e').length, cs = l.ev.filter((e) => e[0] === 'c').length;
        if (eats) api.toast(myMoleView ? '냠냠! 작물 ' + eats + '개 꿀꺽' : '앗! 작물 ' + eats + '개를 먹혔어요');
        if (cs) setTimeout(() => api.toast('철컥! 두더지가 덫에 걸렸어요'), 450 / sp);
      } else if (l.k === 'h') {
        anim = { k: 'h', t0: now, dur: (l.hit ? 1100 : 750) / sp, l, done: {} };
      } else if (l.k === 's') {
        anim = { k: 's', t0: now, dur: 650 / sp, l, done: {} };
        api.sfx('whoosh');
      } else if (l.k === 't') {
        if (seeTraps()) { const tr = trapsOf(s); anim = { k: 't', t0: now, dur: 450 / sp, l, c: tr[tr.length - 1], done: {} }; api.sfx('chip'); }
        else api.toast('농부가 어딘가에 몰래 덫을 묻었어요');
      }
      if (anim) api.setBusy(true);
    }
    function stepAnim() {
      if (!anim) return;
      const t = (now - anim.t0) / anim.dur, l = anim.l, c = G.c;
      if (anim.k === 'm') {
        for (const e of l.ev) {
          const key = e.join(':');
          const at = e[0] === 'e' ? 0.25 : e[0] === 'd' ? 0.15 : 0.6;
          if (t >= at && !anim.done[key]) {
            anim.done[key] = 1;
            const [x, y] = tc(e[1]);
            if (e[0] === 'e') { api.sfx('pop'); dust(x, y, 10, '#6cc25a', 70); popText('냠!', x, y - c * 0.4, '#ffe27a'); }
            if (e[0] === 'd') { api.sfx('roll'); dust(x, y + c * 0.1, 7, '#9a6a3c', 45); }
            if (e[0] === 'c') { api.sfx('hit'); api.buzz(30); dust(x, y, 12, '#d6dbe6', 90); popText('철컥!', x, y - c * 0.45, '#ff8a7a'); }
          }
        }
      } else if (anim.k === 'h' && t >= 0.32 && !anim.done.hit) {
        anim.done.hit = 1;
        const [x, y] = tc(l.c);
        api.sfx('thud'); api.buzz(l.hit ? 40 : 15); dust(x, y + c * 0.1, l.hit ? 16 : 10, '#a87a4c', 80);
        if (l.hit) { api.sfx('hit'); popText('잡았다!', x, y - c * 0.55, '#ffe27a'); api.toast('잡았다! ' + MNAME[l.i] + '(이)가 숲으로 쫓겨나 한 차례 쉬어요'); }
        else popText('헛방', x, y - c * 0.5, '#e8ddd0');
      } else if (anim.k === 's' && t >= 0.55 && !anim.done.b) {
        anim.done.b = 1;
        const [x, y] = tc(l.c);
        popText(l.n > 0 ? '근처에 ' + l.n + '마리!' : '근처엔 없어요', x, y - G.c * 0.8, l.n > 0 ? '#ff8a7a' : '#a5e3a0');
        api.sfx(l.n > 0 ? 'chip' : 'click');
      }
      if (t >= 1) { anim = null; prevSt = null; api.setBusy(false); refresh(); }
    }

    /* --- frame --- */
    function draw() {
      if (!st || !G) return;
      if (!staticL || staticL.key !== skey()) buildStatic();
      ctx.drawImage(staticL.cv, 0, 0, G.W, G.H);
      const c = G.c, s = st, a = anim;
      const t = a ? (now - a.t0) / a.dur : 1;
      // board (crops shown from before the eat until it happens)
      const b = a && a.k === 'm' && a.prevB ? Array.from(s.b).map((ch, i) => (ch === 'x' && a.prevB[i] === 'c' && !a.done['e:' + i + ':' + (a.l.ev.find((e) => e[0] === 'e' && e[1] === i) || [])[2]] ? 'c' : ch)) : s.b;
      // heat overlay (farmer's 추리)
      if (heatOn && (vw() === s.fs || spectator()) && !ended()) {
        for (let k = 0; k < N; k++) {
          const v = s.pd[k]; if (v < 0.02) continue;
          ctx.fillStyle = 'rgba(255,80,60,' + Math.min(0.55, 0.1 + v * 0.6).toFixed(2) + ')';
          ctx.fillRect(G.ox + (k % W) * c + 1, G.oy + Math.floor(k / W) * c + 1, c - 2, c - 2);
          if (v >= 0.1) { ctx.fillStyle = 'rgba(255,240,220,.85)'; ctx.font = '600 ' + Math.round(c * 0.22) + 'px ' + MONO; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic'; ctx.fillText(Math.round(v * 100) + '', G.ox + ((k % W) + 1) * c - 3, G.oy + (Math.floor(k / W) + 1) * c - 3); }
        }
      }
      // scarecrow areas
      for (const [sc0] of s.sc) {
        const [x, y] = [G.ox + ((sc0 % W) - 1) * c, G.oy + (Math.floor(sc0 / W) - 1) * c];
        ctx.save(); ctx.beginPath(); ctx.rect(G.ox, G.oy, G.fw, G.fh); ctx.clip();
        ctx.fillStyle = 'rgba(232,204,122,.07)'; ctx.fillRect(x, y, c * 3, c * 3);
        ctx.setLineDash([5, 4]); ctx.strokeStyle = 'rgba(232,204,122,.45)'; ctx.lineWidth = 1.5; ctx.strokeRect(x + 1, y + 1, c * 3 - 2, c * 3 - 2); ctx.setLineDash([]);
        ctx.restore();
      }
      // tiles
      for (let k = 0; k < N; k++) {
        const [x, y] = tc(k);
        if (b[k] === 'r') drawRock(x, y, c);
        else if (b[k] === 'x') drawHole(x, y, c);
      }
      // mounds
      for (const [m, age] of s.md) {
        let f = age ? 0.5 : 1;
        if (a && a.k === 'm' && age === 0 && a.l.ev.some((e) => e[0] === 'd' && e[1] === m)) f = t < 0.15 ? 0 : Math.min(1, (t - 0.15) / 0.25);
        if (f > 0) { const [x, y] = tc(m); drawMound(x, y + c * 0.12, c * (0.6 + 0.4 * f), f); }
      }
      // hammer marks this round
      for (const [m, hit] of s.hm) {
        if (a && a.k === 'h' && a.l.c === m && t < 0.32) continue;
        const [x, y] = tc(m);
        ctx.strokeStyle = hit ? 'rgba(255,226,122,.8)' : 'rgba(240,230,215,.55)'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        for (let k = 0; k < 6; k++) { const an = k * 1.05 + 0.3; ctx.moveTo(x + Math.cos(an) * c * 0.1, y + Math.sin(an) * c * 0.1); ctx.lineTo(x + Math.cos(an) * c * 0.3, y + Math.sin(an) * c * 0.3); }
        ctx.stroke();
      }
      // crops
      for (let k = 0; k < N; k++) if (b[k] === 'c') { const [x, y] = tc(k); drawCrop(k, x, y, c, 1, 0); }
      // traps
      if (seeTraps()) for (const tr of trapsOf(s)) { const [x, y] = tc(tr); if (a && a.k === 't' && a.c === tr) { const f = ease(t); ctx.save(); ctx.globalAlpha = f; drawTrap(x, y - (1 - f) * c * 0.6, c, 'own'); ctx.restore(); } else drawTrap(x, y, c, 'own'); }
      else if (seeMoles()) for (const tr of sensedTraps(s)) { const [x, y] = tc(tr); drawTrap(x, y, c, 'smell'); }
      // moles on the field
      const mol = curMoles();
      const showM = seeMoles();
      const R = c * 0.3;
      if (showM) {
        for (let i = 0; i < NM; i++) {
          let p = mol[i];
          let pre = a && a.k === 'm' ? a.prevMol[i] : p;
          if (a && a.k === 'h' && a.l.hit && a.l.i === i) continue;
          if (a && a.k === 'm') {
            const caught = a.l.ev.find((e) => e[0] === 'c' && e[2] === i);
            if (caught) { if (t < 0.6) p = caught[1]; else continue; }
          }
          if (p < 0 && pre < 0) continue;
          let x, y;
          if (pre >= 0 && p >= 0 && pre !== p) { const [x1, y1] = tc(pre), [x2, y2] = tc(p), f = ease(Math.min(1, t / 0.75)); x = U.lerp(x1, x2, f); y = U.lerp(y1, y2, f); }
          else if (p >= 0) [x, y] = tc(p);
          else continue;
          if (pre < 0 && p >= 0 && a && a.k === 'm' && t < 0.4) continue;
          const mine = !spectator() && vw() >= 0 && st.mo[i] === vw();
          drawMole(x, y, R, MCOL[i], { under: true, alpha: mine || spectator() || ended() ? 0.95 : 0.8 });
          if (moleTurn() && sel === i) { ctx.strokeStyle = '#ffe27a'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, R * 1.45 + Math.sin(now / 200) * 1.5, 0, 7); ctx.stroke(); }
        }
      }
      // popped (caught) moles — everybody sees these
      if (a && a.k === 'h' && a.l.hit && t >= 0.32) {
        const [x, y] = tc(a.l.c), f = (t - 0.32) / 0.68;
        const fly = Math.max(0, (f - 0.55) / 0.45);
        drawMole(x + fly * c * 0.5, y - c * 0.25 - Math.sin(Math.min(1, f * 2) * Math.PI / 2) * c * 0.2 + fly * fly * c * 4, R * 1.1, MCOL[a.l.i], { dizzy: true, alpha: 1 - fly * 0.6 });
      }
      if (a && a.k === 'm') for (const e of a.l.ev) if (e[0] === 'c' && t >= 0.6) {
        const [x, y] = tc(e[1]), f = (t - 0.6) / 0.4;
        drawMole(x, y - c * 0.25 + f * f * c * 3, R * 1.1, MCOL[e[2]], { dizzy: true, alpha: 1 - f * 0.7 });
      }
      // scarecrows
      for (const [sc0, cnt] of s.sc) {
        const [x, y] = tc(sc0);
        const rising = a && a.k === 's' && a.l.c === sc0;
        drawScarecrow(x, y, c, rising && t < 0.55 ? null : cnt, rising ? ease(t / 0.5) : 1);
      }
      // forest: burrow moles (public)
      drawBurrow();
      // planning overlays
      if (moleTurn()) drawMolePlan();
      if (farmerTurn()) drawFarmerAim();
      // hammer swing
      if (a && a.k === 'h') {
        const [x, y] = tc(a.l.c);
        const ang = t < 0.32 ? 1.1 * (1 - ease(t / 0.32)) : t < 0.6 ? 0 : ((t - 0.6) / 0.4) * 0.8;
        ctx.save(); ctx.globalAlpha = t > 0.85 ? Math.max(0, (1 - t) / 0.15) : 1; drawHammer(x, y, c, ang); ctx.restore();
      }
      // particles + pop texts
      for (let k = parts.length - 1; k >= 0; k--) {
        const p = parts[k];
        ctx.globalAlpha = Math.max(0, 1 - p.life / p.max); ctx.fillStyle = p.col;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
      for (const p of pops) { const f = p.life / p.max; ctx.globalAlpha = f > 0.7 ? (1 - f) / 0.3 : 1; drawText(p.t, p.x, p.y - f * c * 0.5, Math.round(Math.max(13, c * 0.36)), p.col); }
      ctx.globalAlpha = 1;
      // hover (PC)
      if (hover >= 0 && myAct() && !a) { const x = G.ox + (hover % W) * c, y = G.oy + Math.floor(hover / W) * c; ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1.5; ctx.strokeRect(x + 1.5, y + 1.5, c - 3, c - 3); }
    }
    function drawBurrow() {
      const c = G.c, y = G.oy + G.fh + G.forest * 0.55, inB = [];
      for (let i = 0; i < NM; i++) {
        let inside = st.bw[i] === 1;
        if (anim && anim.k === 'm' && anim.prevMol[i] < 0 && molesOf(st)[i] >= 0 && (now - anim.t0) / anim.dur < 0.4) inside = true;
        if (anim && anim.k === 'h' && anim.l.hit && anim.l.i === i && (now - anim.t0) / anim.dur < 0.9) inside = false;
        if (anim && anim.k === 'm' && anim.l.ev.some((e) => e[0] === 'c' && e[2] === i) && (now - anim.t0) / anim.dur < 0.95) inside = false;
        if (inside) inB.push(i);
      }
      if (!inB.length) return;
      const r = Math.max(9, c * 0.24);
      const x0 = G.ox + G.fw / 2 - ((inB.length - 1) * r * 3) / 2;
      inB.forEach((i, k) => {
        const x = x0 + k * r * 3;
        ctx.fillStyle = '#120a05'; ctx.beginPath(); ctx.ellipse(x, y + r * 0.6, r * 1.2, r * 0.45, 0, 0, 7); ctx.fill();
        drawMole(x, y, r, MCOL[i], { zz: st.rs[i] > 0 });
        if (moleTurn() && sel === i) { ctx.strokeStyle = '#ffe27a'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, r * 1.5, 0, 7); ctx.stroke(); }
      });
    }
    function drawMolePlan() {
      const c = G.c, mol = curMoles();
      // planned routes
      for (const i of myMoles()) {
        const p = plan[i];
        if (!p || !p.path.length) continue;
        const pts = (mol[i] >= 0 ? [mol[i]] : []).concat(p.path).map(tc);
        if (mol[i] < 0) { const [ex, ey] = pts[0]; pts.unshift([ex, G.oy + G.fh + G.forest * 0.4]); }
        ctx.strokeStyle = MCOL[i]; ctx.lineWidth = 3; ctx.setLineDash([6, 4]); ctx.lineCap = 'round';
        ctx.beginPath(); pts.forEach(([x, y], k) => (k ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke(); ctx.setLineDash([]);
        const [dx, dy] = pts[pts.length - 1];
        ctx.fillStyle = MCOL[i]; ctx.globalAlpha = 0.85; ctx.beginPath(); ctx.arc(dx, dy, c * 0.14, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
        if (p.path.length === 2 && mol[i] >= 0) { const [mx, my] = tc(mol[i]); ctx.globalAlpha = 0.45; drawMound(mx, my + c * 0.12, c * 0.8, 1); ctx.globalAlpha = 1; }
      }
      if (sel < 0) return;
      const R = reach(sel), from = mol[sel], smell = sensedTraps(st);
      for (const [d, ps] of R) {
        if (d === from) continue;
        const [x, y] = tc(d);
        const len = ps[0].length, bad = ps.every((p) => p.some((q) => smell.includes(q)));
        const col = bad ? 'rgba(255,90,70,.55)' : (from < 0 || len === 1) ? 'rgba(110,220,120,.9)' : 'rgba(255,170,70,.9)';
        ctx.fillStyle = col.replace(/[\d.]+\)$/, '0.18)'); ctx.fillRect(G.ox + (d % W) * c + 2, G.oy + Math.floor(d / W) * c + 2, c - 4, c - 4);
        ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, c * 0.12, 0, 7); ctx.stroke();
      }
    }
    function drawFarmerAim() {
      const c = G.c;
      if (aim < 0) return;
      const [x, y] = tc(aim);
      if (tool === 's') {
        const X = G.ox + ((aim % W) - 1) * c, Y = G.oy + (Math.floor(aim / W) - 1) * c;
        ctx.save(); ctx.beginPath(); ctx.rect(G.ox, G.oy, G.fw, G.fh); ctx.clip();
        ctx.fillStyle = 'rgba(255,226,122,.14)'; ctx.fillRect(X, Y, c * 3, c * 3);
        ctx.strokeStyle = '#ffe27a'; ctx.lineWidth = 2; ctx.strokeRect(X + 1, Y + 1, c * 3 - 2, c * 3 - 2); ctx.restore();
        ctx.globalAlpha = 0.6; drawScarecrow(x, y, c, null, 1); ctx.globalAlpha = 1;
      } else if (tool === 't') drawTrap(x, y, c, 'ghost');
      ctx.strokeStyle = '#ffe27a'; ctx.lineWidth = 2.5;
      const r = c * 0.42 + Math.sin(now / 160) * 1.5;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x - r - 5, y); ctx.lineTo(x - r + 5, y); ctx.moveTo(x + r - 5, y); ctx.lineTo(x + r + 5, y); ctx.moveTo(x, y - r - 5); ctx.lineTo(x, y - r + 5); ctx.moveTo(x, y + r - 5); ctx.lineTo(x, y + r + 5); ctx.stroke();
    }

    const stopLoop = U.loop((dt) => {
      now = performance.now();
      const sp = L.debug.speed || 1;
      for (let k = parts.length - 1; k >= 0; k--) { const p = parts[k]; p.life += dt * sp; p.x += p.vx * dt * sp; p.y += p.vy * dt * sp; p.vy += 160 * dt * sp; if (p.life > p.max) parts.splice(k, 1); }
      for (let k = pops.length - 1; k >= 0; k--) { pops[k].life += dt * sp; if (pops[k].life > pops[k].max) pops.splice(k, 1); }
      stepAnim();
      cv.clear();
      draw();
    });

    /* --- input --- */
    let down = null;
    function onDown(ev) { const p = cv.local(ev); down = { x: p.x, y: p.y }; }
    function onUp(ev) {
      if (!down || !st || !G) return;
      const p = cv.local(ev);
      const moved = Math.hypot(p.x - down.x, p.y - down.y) > 14;
      down = null;
      if (moved || !myAct()) return;
      if (moleTurn() && inForest(p.x, p.y)) {
        const inB = myMoles().filter((i) => curMoles()[i] < 0);
        if (inB.length) { sel = inB[(inB.indexOf(sel) + 1) % inB.length]; api.sfx('click'); refresh(); }
        return;
      }
      const t = tileAt(p.x, p.y);
      if (t < 0) return;
      if (farmerTurn()) farmerTap(t); else if (moleTurn()) moleTap(t);
    }
    function onMove(ev) { if (!G) return; const p = cv.local(ev); const t = tileAt(p.x, p.y); if (t !== hover) hover = t; }
    function onLeave() { hover = -1; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerleave', onLeave);

    return {
      update(s, prev) {
        const fresh = !st || !prev || prev === s || (prev && prev.k !== s.k);
        st = s;
        if (pending && s.seq !== pendSeq) pending = false;
        if (!G) layout();
        const key = s.rd + ':' + s.mt + ':' + s.ph + ':' + s.seq;
        if (key !== planKey) {
          planKey = key; resetPlan();
          if (s.ph !== 'f') aim = -1;
          if (s.ph === 'f' && tool === 't' && s.tl <= 0) tool = 'h';
          if (s.ph === 'f' && tool === 's' && s.sl <= 0) tool = 'h';
        }
        if (!fresh && prev && s.last && (!prev.last || prev.last.id !== s.last.id)) {
          if (anim) { anim = null; api.setBusy(false); }
          startAnim(s, prev);
        }
        refresh();
        requestAnimationFrame(() => { if (st) { const g0 = G && G.c; layout(); if (G.c !== g0) refresh(); } });
      },
      destroy() {
        stopLoop();
        api.setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerleave', onLeave);
        cv.destroy(); topHud.remove(); botHud.remove(); fieldMark.remove();
      },
    };
  }

  L.register({
    id: 'moles', name: '두더지 대 농부', tag: '숨바꼭질 대결', cat: '보드',
    blurb: '땅속 두더지 팀은 몰래 굴을 파 작물을 훔쳐 먹고, 농부는 흙더미 같은 단서를 보고 망치·덫·허수아비로 밭을 지켜요.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: true, aiDelay: 650,
    tint: '#3f5a1f',
    icon: '<path d="M6 46c4-10 12-14 22-14s18 4 22 14z" fill="currentColor" opacity=".55"/><circle cx="28" cy="30" r="11" fill="currentColor"/><circle cx="24" cy="28" r="1.8" fill="#3f5a1f"/><circle cx="32" cy="28" r="1.8" fill="#3f5a1f"/><ellipse cx="28" cy="33" rx="3" ry="2.2" fill="#3f5a1f"/><path d="M44 8l-4 16" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M40 4l10 4-3 6-10-4z" fill="currentColor"/><path d="M10 14l3 10M13 12l1 12M16 13l-2 11" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".7"/>',
    options: [
      { id: 'farmer', label: '농부 역할', choices: [{ v: 'p1', label: '1번 자리' }, { v: 'p2', label: '2번 자리' }, { v: 'rand', label: '무작위' }], def: 'p1' },
      { id: 'len', label: '판 길이', choices: [{ v: 'short', label: '짧게 (10라운드·5개)' }, { v: 'normal', label: '보통 (12라운드·6개)' }, { v: 'long', label: '길게 (14라운드·7개)' }], def: 'normal' },
    ],
    quick: [
      '두더지 팀(3마리)은 땅속에 숨어 작물을 먹고, 농부는 밭을 지켜요. 농부에게 두더지는 안 보여요!',
      '두더지 차례: 한 마리씩 1칸(살금) 또는 2칸(빠른 굴, 흙더미가 남음) 움직이고, 작물 위면 냠냠. 농부 차례: 망치·덫·허수아비 중 2번.',
      '정해진 라운드 안에 작물을 목표만큼(보통 6개) 먹으면 두더지 승, 끝까지 지키면 농부 승!',
    ],
    rules: [
      { h: '목표', p: [
        '한 명은 농부, 나머지는 두더지 팀이에요(2명이면 한 사람이 두더지 3마리를 모두, 3명이면 2마리+1마리, 4명이면 1마리씩).',
        '두더지 승리: 작물을 목표 수만큼 먹으면 바로 승리(보통 12라운드·6개, 짧게 10·5개, 길게 14·7개).',
        '농부 승리: 마지막 라운드가 끝날 때까지 목표만큼 먹히지 않으면 승리.',
        '누가 농부를 할지는 설정 「농부 역할」에서 골라요.'] },
      { h: '한 라운드', p: [
        '① 두더지 차례(두더지 팀 모두) → ② 농부 차례. 이것을 정해진 라운드만큼 반복해요.',
        '두더지는 모두 밭 아래 숲 굴에서 시작해요. 첫 차례에 아래쪽·양옆 아래 가장자리(풀 표시) 칸으로 1칸 들어와요.'] },
      { h: '두더지 차례', p: [
        '두더지마다 하나씩 정해요: 그대로 · 살금 1칸(흔적 없음) · 빠른 굴 2칸(상하좌우로 두 번).',
        '빠른 굴을 파면 출발한 칸에 흙더미가 솟아요. 흙더미는 다음 라운드까지 농부에게 보여요.',
        '작물 칸 위에 있으면 「냠냠」으로 먹을 수 있어요. 먹힌 자리는 구멍이 되어 모두에게 보여요. 배가 불러서 먹은 차례엔 1칸까지만 움직여요.',
        '바위는 지나갈 수 없고, 두더지끼리 같은 칸에 멈출 수 없어요.',
        '두더지는 바로 옆 칸(상하좌우)에 묻힌 덫의 냄새를 맡아요. 냄새 나는 칸은 빨간 점선으로 보여요.'] },
      { h: '농부 차례 (행동 2번)', p: [
        '망치: 칸 하나를 쾅! 그 칸에 두더지가 있으면 잡아요. 몇 번이든 쓸 수 있어요.',
        '덫(한 판 3개): 칸에 몰래 묻어요. 두더지가 그 칸에 들어오면(지나가도) 철컥! 덫은 사라져요.',
        '허수아비(한 판 2개): 세운 칸 둘레 9칸(3×3)에 두더지가 몇 마리 있는지 숫자로 알려 줘요. 숫자는 두더지 차례가 끝날 때마다 새로 바뀌어요.',
        '첫 행동 뒤에는 「넘기기」로 남은 행동을 건너뛸 수 있어요.'] },
      { h: '잡히면', p: [
        '잡힌 두더지는 숲 굴로 쫓겨나 다음 두더지 차례 한 번을 쉬고(zZ), 그다음 차례에 다시 가장자리로 들어와요.',
        '먹은 작물은 그대로 셈해요.'] },
      { h: '단서 읽기 (농부)', p: [
        '흙더미: 두더지가 그 칸에서 빠른 굴을 시작했어요 → 지금은 그 칸에서 정확히 2칸 떨어진 곳에 있어요.',
        '먹힌 구멍: 방금 거기 있던 두더지는 그 칸이나 바로 옆 칸에 있어요(배불러서 1칸만 움직여요).',
        '「추리」 버튼을 켜면 지금까지 보인 단서로 계산한 「두더지가 있을 만한 곳」이 붉게 보여요(숫자 = 가능성 %).'] },
      { h: '예시', p: [
        '3라운드: 배추 칸이 사라지고 구멍이 생겼어요. → 농부는 그 칸과 상하좌우 칸 중 두 곳을 망치로 쳐요.',
        '같은 라운드에 아래쪽에 흙더미가 하나 생겼다면, 다른 두더지가 거기서 2칸 떨어진 곳으로 빠르게 움직인 거예요.',
        '두더지는 3마리가 한꺼번에 먹으면 농부가 다 쫓아가지 못해요. 대신 덫 냄새를 조심!'] },
      { h: '조작', p: [
        '두더지: 아래 버튼(또는 판)에서 두더지를 고르고 갈 칸을 톡 → 다른 두더지도 정한 뒤 「완료」. 초록 = 1칸, 주황 = 2칸(흙더미). 2칸 칸을 한 번 더 톡하면 다른 길로 바뀌어요.',
        '농부: 아래에서 도구를 고르고 칸을 톡 → 한 번 더 톡하거나 「쾅!/묻기/세우기」를 눌러요.',
        '한 폰으로 둘이 하면 차례마다 가림막이 나와요. 농부 화면엔 두더지가, 두더지 화면엔 덫이 안 보여요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(어려운 농부는 단서로 추리하고, 어려운 두더지는 농부가 어디를 의심할지 계산해요).'] },
    ],
    tutorial: [
      { text: '두더지 대 농부! 한쪽은 땅속 두더지 팀(3마리), 다른 쪽은 농부예요. 두더지는 작물을 먹고, 농부는 밭을 지켜요.' },
      { sel: '.ml-field', text: '두더지는 땅속에 있어 농부 화면에는 안 보여요. 대신 흙더미(빠른 굴을 시작한 자리)와 먹힌 구멍 같은 단서가 남아요.' },
      { sel: '.ml-bot', text: '농부 차례엔 행동 2번: 망치(칸을 톡 → 한 번 더 톡 = 쾅!) · 덫 3개(몰래 묻기) · 허수아비 2개(둘레 9칸의 두더지 수).' },
      { sel: '.ml-bot', text: '두더지 차례엔 두더지를 고르고 갈 칸을 톡. 초록 = 살금 1칸(흔적 없음), 주황 = 빠른 굴 2칸(지금 자리에 흙더미). 작물 위에서는 「냠냠」!' },
      { sel: '.ml-top', text: '위에서 라운드와 먹힌 작물 수를 봐요. 목표만큼 먹으면 두더지 승, 끝까지 지키면 농부 승!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: T,
  });
})();
