/* 늑대와 양 — 비대칭 사냥 판 놀이. 8×8 체크무늬 들판(늑대 1 : 양 4) / 십자 들판(늑대 1 : 양 13, 뛰어넘어 잡기).
   AI: 체크무늬는 끝까지 읽는 완전 해석(어려움), 십자 들판은 알파베타 탐색. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- geometry ----------
     'c' 체크무늬 8×8: 어두운 칸 32개만 씀. 칸 i = r*4 + k, 열 c = 2k + (r 짝수 ? 1 : 0). 대각선 4방향.
     'x' 십자 들판: 7×7에서 네 귀퉁이 2×2를 뺀 33점. 가로·세로 선만. */
  const GEO = {};
  function geo(v) {
    if (GEO[v]) return GEO[v];
    const R = [], C = [], at = {};
    if (v === 'c') {
      for (let i = 0; i < 32; i++) { const r = i >> 2, c = 2 * (i & 3) + (r % 2 === 0 ? 1 : 0); R.push(r); C.push(c); at[r * 8 + c] = i; }
    } else {
      for (let r = 0; r < 7; r++) for (let c = 0; c < 7; c++) if ((r >= 2 && r <= 4) || (c >= 2 && c <= 4)) { at[r * 8 + c] = R.length; R.push(r); C.push(c); }
    }
    const n = R.length, D = v === 'c' ? [[-1, -1], [-1, 1], [1, -1], [1, 1]] : [[-1, 0], [0, -1], [0, 1], [1, 0]];
    const cell = (r, c) => (r >= 0 && c >= 0 && r < 8 && c < 8 && at[r * 8 + c] != null ? at[r * 8 + c] : -1);
    // step[p*4+d], jump[p*4+d] (landing point, only for 'x'); sheep directions: 'c' up-left/up-right, 'x' up/left/right
    const step = new Int8Array(n * 4).fill(-1), jump = new Int8Array(n * 4).fill(-1);
    for (let p = 0; p < n; p++) for (let d = 0; d < 4; d++) {
      step[p * 4 + d] = cell(R[p] + D[d][0], C[p] + D[d][1]);
      if (v === 'x') jump[p * 4 + d] = cell(R[p] + 2 * D[d][0], C[p] + 2 * D[d][1]);
    }
    const sheepDirs = v === 'c' ? [0, 1] : [0, 1, 2];
    return (GEO[v] = { v, n, R, C, at, step, jump, sheepDirs, cell, rows: v === 'c' ? 8 : 7, cols: v === 'c' ? 8 : 7 });
  }
  function startBoard(v) {
    const g = geo(v), b = Array(g.n).fill('.');
    if (v === 'c') { for (let i = 28; i < 32; i++) b[i] = 's'; b[g.cell(0, 3)] = 'w'; }
    else { for (let p = 0; p < g.n; p++) if (g.R[p] >= 4) b[p] = 's'; b[g.cell(3, 3)] = 'w'; }
    return b.join('');
  }

  /* ---------- rules ---------- */
  const CAP_GOAL = 5;     // 십자 들판: 늑대가 양 5마리를 잡으면 승리
  const MOVE_CAP = 60;    // 십자 들판: 양이 60번 움직이는 동안 못 가두면 늑대 승리(해 질 녘)
  /* legal moves of the side to move: [from, to, captured(-1)] */
  function movesOf(g, b, sd, cj, wp) {
    const out = [];
    if (sd === 'w') {
      if (wp < 0) return out;
      for (let d = 0; d < 4; d++) {
        const q = g.step[wp * 4 + d];
        if (q < 0) continue;
        if (!cj && b[q] === '.') out.push([wp, q, -1]);
        else if (g.v === 'x' && b[q] === 's') { const t = g.jump[wp * 4 + d]; if (t >= 0 && b[t] === '.') out.push([wp, t, q]); }
      }
    } else {
      for (let p = 0; p < g.n; p++) if (b[p] === 's') for (const d of g.sheepDirs) { const q = g.step[p * 4 + d]; if (q >= 0 && b[q] === '.') out.push([p, q, -1]); }
    }
    return out;
  }
  const wolfAt = (b) => b.indexOf('w');

  function init(players, opts) {
    const v = opts && opts.board === 'x' ? 'x' : 'c';
    const side = opts && (opts.side === 's' || opts.side === 'r') ? opts.side : 'w';
    const W = side === 'w' ? 0 : side === 's' ? 1 : (Math.random() < 0.5 ? 0 : 1);
    const hum = players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0);
    const solo = hum.length === 1 && players.length === 2 && players.some((p) => p.ai) ? hum[0] : -1;
    return { v, b: startBoard(v), sd: 'w', W, cj: 0, n: 0, k: 0, seq: 0, last: null, st: null, u: [], solo, ev: null };
  }
  const seatOf = (s, sd) => (sd === 'w' ? s.W : 1 - s.W);
  function actor(s) { return s.st ? null : seatOf(s, s.sd); }

  /* after the side `sd` moved: switch turn and detect the end */
  function settle(s, g) {
    const b = s.b, wp = wolfAt(b);
    if (g.v === 'c' && g.R[wp] === 7) { s.st = { w: 'w', r: 'goal' }; return; }
    if (g.v === 'x' && s.k >= CAP_GOAL) { s.st = { w: 'w', r: 'eat' }; return; }
    if (s.sd === 'w' && s.cj) return;
    const nx = s.sd === 'w' ? 's' : 'w';
    s.sd = nx;
    if (!movesOf(g, b, nx, 0, wp).length) { s.st = nx === 'w' ? { w: 's', r: 'trap' } : { w: 'w', r: 'stuck' }; return; }
    if (g.v === 'x' && nx === 's' && s.n >= MOVE_CAP) s.st = { w: 'w', r: 'time' };
  }
  function snap(s) { return { b: s.b, sd: s.sd, n: s.n, k: s.k, last: s.last }; }

  function apply(s, seat, a) {
    if (s.st) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a) throw new Error('bad action');
    const g = geo(s.v);
    if (a.t === 'undo') {
      if (s.solo !== seat || !s.u.length || s.cj) throw new Error('cannot undo');
      const o = s.u.pop();
      Object.assign(s, { b: o.b, sd: o.sd, n: o.n, k: o.k, last: o.last, cj: 0 });
      s.seq++; s.ev = { id: s.seq, k: 'u' };
      return s;
    }
    if (a.t === 'stop') {
      if (!s.cj || s.sd !== 'w') throw new Error('nothing to stop');
      s.cj = 0; s.seq++; s.ev = { id: s.seq, k: 'stop' };
      settle(s, g);
      return s;
    }
    if (a.t !== 'm') throw new Error('bad action');
    const wp = wolfAt(s.b);
    const mv = movesOf(g, s.b, s.sd, s.cj, wp).find((m) => m[0] === a.f && m[1] === a.to);
    if (!mv) throw new Error('illegal move');
    if (seat === s.solo && !s.cj) { s.u.push(snap(s)); if (s.u.length > 6) s.u.shift(); }
    const b = s.b.split('');
    b[mv[1]] = b[mv[0]]; b[mv[0]] = '.';
    if (mv[2] >= 0) { b[mv[2]] = '.'; s.k++; }
    s.b = b.join('');
    s.seq++;
    s.last = { id: s.seq, sd: s.sd, f: mv[0], to: mv[1], x: mv[2] };
    s.ev = null;
    if (s.sd === 's') s.n++;
    s.cj = 0;
    if (mv[2] >= 0 && movesOf(g, s.b, 'w', 1, mv[1]).length) s.cj = 1;
    settle(s, g);
    if (s.st) s.cj = 0;
    return s;
  }
  function result(s) {
    if (!s.st) return null;
    const w = seatOf(s, s.st.w);
    const T = {
      goal: '늑대가 양 떼를 지나 맨 끝 줄에 닿았어요!',
      trap: '양들이 늑대를 꼼짝 못 하게 가뒀어요!',
      stuck: '양이 더 움직일 곳이 없어서 늑대가 이겼어요.',
      eat: '늑대가 양을 ' + CAP_GOAL + '마리 잡았어요!',
      time: '해가 질 때까지 양들이 늑대를 못 가뒀어요.',
    };
    return { winners: [w], title: s.st.w === 'w' ? '늑대 승리!' : '양 떼 승리!', text: T[s.st.r] || '' };
  }

  /* ---------- AI ---------- */
  /* --- 체크무늬: exact solve. key = sheepMask*64 + wolf*2 + side(0 wolf, 1 sheep). value: true = side to move wins --- */
  /* transposition table (open addressing on typed arrays; cleared when it gets too full) */
  const HB = 19, HS = 1 << HB, HM = HS - 1;
  let HK = null, HA = null, HV = null, hCount = 0;
  function hInit() { HK = new Uint32Array(HS); HA = new Uint8Array(HS); HV = new Uint8Array(HS); hCount = 0; }
  function hGet(mask, aux) {
    let i = (Math.imul(mask ^ (aux * 0x9e3779b1), 0x85ebca6b) >>> (32 - HB)) & HM;
    while (HA[i]) { if (HA[i] === aux && HK[i] === mask) return HV[i]; i = (i + 1) & HM; }
    return 255;
  }
  function hSet(mask, aux, v) {
    if (hCount > HS * 0.7) hInit();
    let i = (Math.imul(mask ^ (aux * 0x9e3779b1), 0x85ebca6b) >>> (32 - HB)) & HM;
    while (HA[i]) { if (HA[i] === aux && HK[i] === mask) { HV[i] = v; return; } i = (i + 1) & HM; }
    HA[i] = aux; HK[i] = mask; HV[i] = v; hCount++;
  }
  function cMoves(mask, w, side, g) {
    const out = [];
    if (side === 0) {
      for (let d = 0; d < 4; d++) { const q = g.step[w * 4 + d]; if (q >= 0 && !((mask >>> q) & 1)) out.push(q); }
    } else {
      for (let p = 0; p < 32; p++) if ((mask >>> p) & 1) for (let d = 0; d < 2; d++) {
        const q = g.step[p * 4 + d];
        if (q >= 0 && q !== w && !((mask >>> q) & 1)) out.push(p * 32 + q);
      }
    }
    return out;
  }
  /* exact: does the side to move win? (side 0 = wolf, 1 = sheep). The sheep only move forward, so it always ends. */
  const SOL = { nodes: 0 };
  function cSolve(mask, w, side) {
    if (!HK) hInit();
    const aux = w * 2 + side + 1, hit = hGet(mask, aux);
    if (hit !== 255) return hit === 1;
    SOL.nodes++;
    const g = geo('c'), st = g.step;
    let win = false;
    if (side === 0) {
      let a0 = -1, a1 = -1, a2 = -1, a3 = -1, n = 0;
      // try forward (towards row 7) first
      for (let d = 3; d >= 0; d--) {
        const q = st[w * 4 + d];
        if (q < 0 || ((mask >>> q) & 1)) continue;
        if (g.R[q] === 7) { hSet(mask, aux, 1); return true; }
        if (n === 0) a0 = q; else if (n === 1) a1 = q; else if (n === 2) a2 = q; else a3 = q;
        n++;
      }
      win = (n > 0 && !cSolve(mask, a0, 1)) || (n > 1 && !cSolve(mask, a1, 1)) || (n > 2 && !cSolve(mask, a2, 1)) || (n > 3 && !cSolve(mask, a3, 1));
    } else {
      const kids = [], keys = [];
      for (let p = 0; p < 32; p++) if ((mask >>> p) & 1) for (let d = 0; d < 2; d++) {
        const q = st[p * 4 + d];
        if (q < 0 || q === w || ((mask >>> q) & 1)) continue;
        const nm = ((mask & ~(1 << p)) | (1 << q)) >>> 0, k = cEval(nm, w, g);
        let i = kids.length; kids.push(nm); keys.push(k);
        while (i > 0 && keys[i - 1] > k) { kids[i] = kids[i - 1]; keys[i] = keys[i - 1]; i--; }
        kids[i] = nm; keys[i] = k;
      }
      for (let i = 0; i < kids.length; i++) if (!cSolve(kids[i], w, 0)) { win = true; break; }
    }
    hSet(mask, aux, win ? 1 : 0);
    return win;
  }
  function maskOf(b) { let m = 0; for (let p = 0; p < 32; p++) if (b[p] === 's') m |= 1 << p; return m >>> 0; }
  /* heuristic for 체크무늬, from the wolf's view (bigger = better for wolf) */
  const DQ = new Int8Array(32), QQ = new Int8Array(32);
  function cEval(mask, w, g) {
    if (g.R[w] === 7) return 5000;
    // BFS wolf → row 7 through empty squares
    const dist = DQ, R = g.R, st = g.step; dist.fill(-1); dist[w] = 0; QQ[0] = w;
    let qn = 1, best = -1, area = 0;
    for (let h = 0; h < qn; h++) {
      const p = QQ[h]; area++;
      if (R[p] === 7 && best < 0) best = dist[p];
      for (let d = 0; d < 4; d++) { const t = st[p * 4 + d]; if (t >= 0 && dist[t] < 0 && !((mask >>> t) & 1)) { dist[t] = dist[p] + 1; QQ[qn++] = t; } }
    }
    let sheepRow = 0, minR = 9, maxR = -1;
    for (let p = 0; p < 32; p++) if ((mask >>> p) & 1) { const r = R[p]; sheepRow += r; if (r < minR) minR = r; if (r > maxR) maxR = r; }
    let mob = 0; for (let d = 0; d < 4; d++) { const t = st[w * 4 + d]; if (t >= 0 && !((mask >>> t) & 1)) mob++; }
    if (best < 0) return -400 + area * 6 + mob * 4 - (28 - sheepRow);
    return 300 - best * 25 + mob * 6 + (maxR - minR) * 12 + R[w] * 4;
  }
  function cSearch(mask, w, side, depth, alpha, beta, g) {
    if (g.R[w] === 7) return 5000 + depth;
    const ms = cMoves(mask, w, side, g);
    if (!ms.length) return side === 0 ? -5000 - depth : 5000 + depth;
    if (depth <= 0) return cEval(mask, w, g);
    if (side === 0) {
      let v = -1e9;
      for (const q of ms) { v = Math.max(v, cSearch(mask, q, 1, depth - 1, alpha, beta, g)); alpha = Math.max(alpha, v); if (alpha >= beta) break; }
      return v;
    }
    let v = 1e9;
    for (const m of ms) {
      const nm = ((mask & ~(1 << ((m / 32) | 0))) | (1 << (m % 32))) >>> 0;
      v = Math.min(v, cSearch(nm, w, 0, depth - 1, alpha, beta, g)); beta = Math.min(beta, v); if (alpha >= beta) break;
    }
    return v;
  }
  function cAI(s, lv) {
    const g = geo('c'), mask = maskOf(s.b), w = wolfAt(s.b), side = s.sd === 'w' ? 0 : 1;
    const ms = cMoves(mask, w, side, g);
    const toAct = (m) => (side === 0 ? { t: 'm', f: w, to: m } : { t: 'm', f: (m / 32) | 0, to: m % 32 });
    const after = (m) => (side === 0 ? [mask, m] : [((mask & ~(1 << ((m / 32) | 0))) | (1 << (m % 32))) >>> 0, w]);
    const sign = side === 0 ? 1 : -1;
    const depth = lv === 1 ? 1 : lv === 2 ? 4 : side === 0 ? 6 : 4;
    const scored = ms.map((m) => {
      const [nm, nw] = after(m);
      let v = sign * cSearch(nm, nw, 1 - side, depth - 1, -1e9, 1e9, g);
      if (lv === 3) {
        // exact: a winning move beats everything. When lost anyway, set traps: prefer moves where few replies refute us.
        const wins = side === 0 ? (g.R[nw] === 7 || !cSolve(nm, nw, 1)) : !cSolve(nm, nw, 0);
        if (wins) v += 100000;
        else {
          const rs = cMoves(nm, nw, 1 - side, g);
          let good = 0;
          for (const r of rs) {
            const oppWins = side === 0 ? !cSolve(((nm & ~(1 << ((r / 32) | 0))) | (1 << (r % 32))) >>> 0, nw, 0) : (g.R[r] === 7 || !cSolve(nm, r, 1));
            if (oppWins) good++;
          }
          v += rs.length ? (1 - good / rs.length) * 400 : 0;
        }
      }
      return { m, v: v + (lv === 1 ? Math.random() * 160 : lv === 2 ? Math.random() * 30 : Math.random() * 2) };
    });
    scored.sort((a, b) => b.v - a.v);
    let pick = scored[0];
    if (lv === 1 && scored.length > 1 && Math.random() < 0.3) pick = scored[U.rand(scored.length)];
    return toAct(pick.m);
  }

  /* --- 십자 들판: alpha-beta + transposition table (values from the wolf's view: bigger = better for the wolf) --- */
  const XW = { w: [120, 9, 14, 70, 18, 2, 1.5], s: [120, 9, 14, 70, 18, 2, 1.5], cur: null, bud: 0 };
  const XSEEN = new Uint8Array(40), XQ = new Int8Array(40);
  function xEval(b, wp, k, n, g) {
    const st = g.step, J = g.jump, seen = XSEEN;
    seen.fill(0); seen[wp] = 1; XQ[0] = wp;
    let qn = 1, area = 0;
    for (let h = 0; h < qn; h++) { const p = XQ[h]; area++; for (let d = 0; d < 4; d++) { const t = st[p * 4 + d]; if (t >= 0 && !seen[t] && b[t] === 0) { seen[t] = 1; XQ[qn++] = t; } } }
    let jumps = 0, mob = 0, hang = 0, adv = 0;
    for (let d = 0; d < 4; d++) {
      const t = st[wp * 4 + d];
      if (t < 0) continue;
      if (b[t] === 0) mob++;
      else if (b[t] === 1) { const j = J[wp * 4 + d]; if (j >= 0 && b[j] === 0) jumps++; }
    }
    // loose sheep: an empty point behind it and the wolf can reach the point in front
    for (let p = 0; p < g.n; p++) if (b[p] === 1) {
      adv += 6 - g.R[p];
      for (let d = 0; d < 4; d++) { const a1 = st[p * 4 + d], a2 = st[p * 4 + (3 - d)]; if (a1 >= 0 && a2 >= 0 && b[a2] === 0 && seen[a1]) { hang++; break; } }
    }
    const w = XW.cur;
    return k * w[0] + area * w[1] + mob * w[2] + jumps * w[3] + hang * w[4] - adv * w[5] + n * w[6];
  }
  // Zobrist keys (fixed seed → same on every device)
  const ZS = new Int32Array(40), ZW = new Int32Array(40), ZN = new Int32Array(80);
  let ZSIDE = 0, ZCJ = 0;
  (function () {
    let x = 0x2545f491;
    const r = () => { x ^= x << 13; x ^= x >>> 17; x ^= x << 5; return x | 0; };
    for (let i = 0; i < 40; i++) { ZS[i] = r(); ZW[i] = r(); }
    for (let i = 0; i < 80; i++) ZN[i] = r();
    ZSIDE = r(); ZCJ = r();
  })();
  const TB = 17, TS = 1 << TB, TM = TS - 1;
  let TK = null, TD = null, TF = null, TV = null, TBM = null;
  function tInit() { TK = new Int32Array(TS); TD = new Int8Array(TS).fill(-1); TF = new Uint8Array(TS); TV = new Float32Array(TS); TBM = new Int16Array(TS).fill(-1); }
  const HIST = new Int32Array(40 * 40);
  const MB = new Int8Array(128 * 80);   // move buffers per ply
  const MSC = new Int32Array(128 * 40); // move scores per ply
  let xNodes = 0, xDeadline = 0, xAbort = false;
  const XS = { d: 0 };
  /* fills MB at ply: pairs (to, captured) for the wolf (captures first), (from, to) for the sheep. returns pair count */
  function xGen(b, wp, sd, cj, g, ply) {
    const st = g.step, o = ply * 80;
    let c = 0;
    if (sd === 0) {
      for (let d = 0; d < 4; d++) {
        const t = st[wp * 4 + d]; if (t < 0) continue;
        if (b[t] === 1) { const j = g.jump[wp * 4 + d]; if (j >= 0 && b[j] === 0) { MB[o + 2 * c] = j; MB[o + 2 * c + 1] = t; c++; } }
      }
      if (!cj) for (let d = 0; d < 4; d++) { const t = st[wp * 4 + d]; if (t >= 0 && b[t] === 0) { MB[o + 2 * c] = t; MB[o + 2 * c + 1] = -1; c++; } }
    } else {
      for (let p = 0; p < g.n; p++) if (b[p] === 1) for (let i = 0; i < 3; i++) { const t = st[p * 4 + i]; if (t >= 0 && b[t] === 0) { MB[o + 2 * c] = p; MB[o + 2 * c + 1] = t; c++; } }
    }
    return c;
  }
  /* sd: 0 wolf, 1 sheep. cj: wolf is mid-chain (may only jump again or stop). */
  function xSearch(b, h, wp, sd, cj, k, n, depth, alpha, beta, g, ply) {
    if (k >= CAP_GOAL) return 20000 + depth;
    if (sd === 1 && n >= MOVE_CAP) return 15000;
    if ((++xNodes & 1023) === 0 && performance.now() > xDeadline) xAbort = true;
    if (xAbort || ply >= 120) return 0;
    const cnt = xGen(b, wp, sd, cj, g, ply);
    if (sd === 0 && !cnt && !cj) return -20000 - depth;
    if (sd === 1 && !cnt) return 18000; // sheep stuck → wolf wins
    if (depth <= 0) return xEval(b, wp, k, n, g);
    const key = h ^ ZN[n] ^ (sd ? ZSIDE : 0) ^ (cj ? ZCJ : 0);
    const ti = (key ^ (key >>> TB)) & TM;
    let ttMove = -1;
    if (TK[ti] === key && TD[ti] >= 0) {
      ttMove = TBM[ti];
      if (TD[ti] >= depth) {
        const v = TV[ti], f = TF[ti];
        if (f === 0) return v;
        if (f === 1 && v > alpha) alpha = v;
        else if (f === 2 && v < beta) beta = v;
        if (alpha >= beta) return v;
      }
    }
    const a0 = alpha, b0 = beta, o = ply * 80, so = ply * 40;
    let bestM = -1, v;
    if (sd === 0) {
      v = -1e9;
      if (cj) { v = xSearch(b, h, wp, 1, 0, k, n, depth - 1, alpha, beta, g, ply + 1); bestM = 999; if (v > alpha) alpha = v; }
      for (let i = 0; i < cnt && alpha < beta; i++) {
        const t = MB[o + 2 * i], x = MB[o + 2 * i + 1];
        b[wp] = 0; b[t] = 2; let h2 = h ^ ZW[wp] ^ ZW[t];
        if (x >= 0) { b[x] = 0; h2 ^= ZS[x]; }
        const r = x >= 0 ? xSearch(b, h2, t, 0, 1, k + 1, n, depth, alpha, beta, g, ply + 1) : xSearch(b, h2, t, 1, 0, k, n, depth - 1, alpha, beta, g, ply + 1);
        b[t] = 0; b[wp] = 2; if (x >= 0) b[x] = 1;
        if (r > v) { v = r; bestM = t * 64 + (x + 1); }
        if (v > alpha) alpha = v;
      }
    } else {
      // order: tt move, then history
      for (let i = 0; i < cnt; i++) { const f = MB[o + 2 * i], t = MB[o + 2 * i + 1]; MSC[so + i] = (f * 64 + t === ttMove ? 1e9 : 0) + HIST[f * 40 + t]; }
      v = 1e9;
      for (let i = 0; i < cnt && alpha < beta; i++) {
        let bi = i; for (let j = i + 1; j < cnt; j++) if (MSC[so + j] > MSC[so + bi]) bi = j;
        if (bi !== i) {
          const s0 = MSC[so + i]; MSC[so + i] = MSC[so + bi]; MSC[so + bi] = s0;
          const f0 = MB[o + 2 * i], t0 = MB[o + 2 * i + 1]; MB[o + 2 * i] = MB[o + 2 * bi]; MB[o + 2 * i + 1] = MB[o + 2 * bi + 1]; MB[o + 2 * bi] = f0; MB[o + 2 * bi + 1] = t0;
        }
        const f = MB[o + 2 * i], t = MB[o + 2 * i + 1];
        b[f] = 0; b[t] = 1;
        const r = xSearch(b, h ^ ZS[f] ^ ZS[t], wp, 0, 0, k, n + 1, depth - 1, alpha, beta, g, ply + 1);
        b[t] = 0; b[f] = 1;
        if (r < v) { v = r; bestM = f * 64 + t; }
        if (v < beta) beta = v;
        if (alpha >= beta) HIST[f * 40 + t] += depth * depth;
      }
    }
    if (!xAbort) {
      TK[ti] = key; TD[ti] = depth; TV[ti] = v; TBM[ti] = bestM;
      TF[ti] = sd === 0 ? (v >= b0 ? 1 : v <= a0 ? 2 : 0) : (v <= a0 ? 2 : v >= b0 ? 1 : 0);
    }
    return v;
  }
  function xAI(s, lv) {
    const g = geo('x');
    if (!TK) tInit();
    const b = new Int8Array(g.n);
    let h = 0;
    for (let p = 0; p < g.n; p++) { b[p] = s.b[p] === 's' ? 1 : s.b[p] === 'w' ? 2 : 0; if (b[p] === 1) h ^= ZS[p]; else if (b[p] === 2) h ^= ZW[p]; }
    const wp = wolfAt(s.b), sd = s.sd === 'w' ? 0 : 1, cj = s.cj;
    const cnt = xGen(b, wp, sd, cj, g, 0);
    let cand = [];
    if (sd === 0 && cj) cand.push({ stop: 1 });
    for (let i = 0; i < cnt; i++) { const p = MB[2 * i], q = MB[2 * i + 1]; cand.push(sd === 0 ? { f: wp, to: p, x: q } : { f: p, to: q, x: -1 }); }
    const sign = sd === 0 ? 1 : -1;
    const maxD = lv === 1 ? 1 : lv === 2 ? 3 : 40;
    const budget = lv === 3 ? (XW.bud || 260) : 120;
    XW.cur = sd === 0 ? XW.w : XW.s;
    if (XW.prev !== XW.cur) { tInit(); XW.prev = XW.cur; }
    HIST.fill(0);
    const t0 = performance.now();
    xDeadline = t0 + budget; xAbort = false;
    let best = null;
    for (let D = 1; D <= maxD; D++) {
      const sc = [];
      let alpha = -1e9, beta = 1e9;
      for (const c of cand) {
        let r;
        if (c.stop) r = xSearch(b, h, wp, 1, 0, s.k, s.n, D - 1, alpha, beta, g, 1);
        else if (sd === 0) {
          b[wp] = 0; b[c.to] = 2; let h2 = h ^ ZW[wp] ^ ZW[c.to]; if (c.x >= 0) { b[c.x] = 0; h2 ^= ZS[c.x]; }
          r = c.x >= 0 ? xSearch(b, h2, c.to, 0, 1, s.k + 1, s.n, D - 1, alpha, beta, g, 1) : xSearch(b, h2, c.to, 1, 0, s.k, s.n, D - 1, alpha, beta, g, 1);
          b[c.to] = 0; b[wp] = 2; if (c.x >= 0) b[c.x] = 1;
        } else {
          b[c.f] = 0; b[c.to] = 1;
          r = xSearch(b, h ^ ZS[c.f] ^ ZS[c.to], wp, 0, 0, s.k, s.n + 1, D - 1, alpha, beta, g, 1);
          b[c.to] = 0; b[c.f] = 1;
        }
        if (xAbort) break;
        sc.push({ c, v: sign * r });
        // lv3 needs only the best move: narrow the window (lv1/2 keep exact scores for their noisy choice)
        if (lv === 3) { if (sd === 0) alpha = Math.max(alpha, r - 1); else beta = Math.min(beta, r + 1); }
      }
      if (xAbort && best) break;
      if (sc.length) {
        best = sc;
        cand = sc.slice().sort((a, b2) => b2.v - a.v).map((o) => o.c).concat(cand.filter((c) => !sc.some((o) => o.c === c)));
      }
      XS.d = D;
      if (xAbort || performance.now() - t0 > budget * 0.45) break;
      if (sc.every((o) => Math.abs(o.v) >= 14000)) break;
    }
    const noise = lv === 1 ? 90 : lv === 2 ? 14 : 0.5;
    const sc = best.map((o) => ({ c: o.c, v: o.v + Math.random() * noise }));
    sc.sort((a, b2) => b2.v - a.v);
    let pick = sc[0].c;
    if (lv === 1 && sc.length > 1 && Math.random() < 0.25) pick = sc[U.rand(sc.length)].c;
    return pick.stop ? { t: 'stop' } : { t: 'm', f: pick.f, to: pick.to };
  }

  function ai(s, seat, lv) {
    lv = lv || 2;
    return s.v === 'c' ? cAI(s, lv) : xAI(s, lv);
  }
  function aiDelayFor(s, seat, lv) { if (s.cj) return 380; return lv === 1 ? 750 : lv === 3 ? 320 : 500; }

  /* ---------- view ---------- */
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace';
  const DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';

  /* hint helpers (pure) */
  // 체크무늬: shortest path of the wolf to row 7 through empty squares (cells after the wolf), or null when shut in
  function wolfPath(b, g) {
    const w = wolfAt(b), prev = new Int8Array(32).fill(-2), q = [w];
    prev[w] = -1;
    for (let h = 0; h < q.length; h++) {
      const p = q[h];
      if (g.R[p] === 7) { const out = []; for (let z = p; z !== w; z = prev[z]) out.unshift(z); return out; }
      for (let d = 3; d >= 0; d--) { const t = g.step[p * 4 + d]; if (t >= 0 && prev[t] === -2 && b[t] === '.') { prev[t] = p; q.push(t); } }
    }
    return null;
  }
  // 십자 들판: sheep the wolf could jump right now
  function loose(b, g) {
    const w = wolfAt(b), out = [];
    for (const m of movesOf(g, b, 'w', 1, w)) out.push(m[2]);
    return out;
  }
  // is moving a sheep f→t risky? ('c': opens the wolf's way out, 'x': lets the wolf jump someone)
  function risky(b, g, f, t) {
    const a = b.split(''); a[t] = 's'; a[f] = '.'; const nb = a.join('');
    if (g.v === 'c') return !wolfPath(b, g) && !!wolfPath(nb, g);
    return loose(nb, g).length > 0;
  }

  /* sprites */
  function mkCanvas(w, h, dpr) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * dpr)); c.height = Math.max(1, Math.round(h * dpr)); const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); return [c, x]; }
  function sheepSprite(S, color, dpr) {
    const [c, x] = mkCanvas(S, S, dpr), u = S / 2;
    x.translate(u, u);
    x.fillStyle = 'rgba(20,30,10,.28)'; x.beginPath(); x.ellipse(0, u * 0.7, u * 0.66, u * 0.2, 0, 0, 7); x.fill();
    // wool
    const puff = (px, py, r) => { x.beginPath(); x.arc(px, py, r, 0, 7); x.fill(); };
    x.fillStyle = '#d8cfbf';
    for (let i = 0; i < 9; i++) { const a = (i / 9) * Math.PI * 2; puff(Math.cos(a) * u * 0.5, Math.sin(a) * u * 0.46 + u * 0.04, u * 0.3); }
    x.fillStyle = '#fbf7ee';
    for (let i = 0; i < 9; i++) { const a = (i / 9) * Math.PI * 2 + 0.1; puff(Math.cos(a) * u * 0.46 - u * 0.03, Math.sin(a) * u * 0.42, u * 0.27); }
    puff(0, 0, u * 0.5);
    x.fillStyle = 'rgba(255,255,255,.9)'; puff(-u * 0.22, -u * 0.26, u * 0.14); puff(u * 0.08, -u * 0.34, u * 0.1);
    // collar in the player's colour + bell
    x.strokeStyle = color; x.lineWidth = u * 0.12; x.lineCap = 'round';
    x.beginPath(); x.arc(0, u * 0.08, u * 0.3, 0.35 * Math.PI, 0.65 * Math.PI); x.stroke();
    x.fillStyle = '#e3ae45'; puff(0, u * 0.42, u * 0.09);
    // ears
    x.fillStyle = '#3d3238';
    x.save(); x.translate(-u * 0.33, -u * 0.02); x.rotate(-0.35); x.beginPath(); x.ellipse(0, 0, u * 0.17, u * 0.08, 0, 0, 7); x.fill(); x.restore();
    x.save(); x.translate(u * 0.33, -u * 0.02); x.rotate(0.35); x.beginPath(); x.ellipse(0, 0, u * 0.17, u * 0.08, 0, 0, 7); x.fill(); x.restore();
    // face
    x.fillStyle = '#3d3238'; x.beginPath(); x.ellipse(0, u * 0.06, u * 0.24, u * 0.29, 0, 0, 7); x.fill();
    x.fillStyle = '#fbf7ee'; puff(-u * 0.08, -u * 0.22, u * 0.1); puff(u * 0.08, -u * 0.22, u * 0.1); puff(0, -u * 0.28, u * 0.1);
    x.fillStyle = '#fff'; puff(-u * 0.1, u * 0.02, u * 0.07); puff(u * 0.1, u * 0.02, u * 0.07);
    x.fillStyle = '#1a1418'; puff(-u * 0.09, u * 0.04, u * 0.038); puff(u * 0.11, u * 0.04, u * 0.038);
    x.fillStyle = '#e99aa5'; x.beginPath(); x.ellipse(0, u * 0.2, u * 0.06, u * 0.035, 0, 0, 7); x.fill();
    return c;
  }
  function wolfSprite(S, color, dpr) {
    const [c, x] = mkCanvas(S, S, dpr), u = S / 2;
    x.translate(u, u * 1.04);
    x.fillStyle = 'rgba(20,30,10,.2)'; x.beginPath(); x.ellipse(0, u * 0.62, u * 0.6, u * 0.16, 0, 0, 7); x.fill();
    // ears
    const ear = (sx) => {
      x.fillStyle = '#5d616e'; x.beginPath(); x.moveTo(sx * u * 0.14, -u * 0.36); x.lineTo(sx * u * 0.5, -u * 0.86); x.lineTo(sx * u * 0.62, -u * 0.22); x.closePath(); x.fill();
      x.fillStyle = '#d7a49b'; x.beginPath(); x.moveTo(sx * u * 0.25, -u * 0.36); x.lineTo(sx * u * 0.48, -u * 0.7); x.lineTo(sx * u * 0.54, -u * 0.3); x.closePath(); x.fill();
    };
    ear(-1); ear(1);
    // head with cheek fluff
    const gr = x.createLinearGradient(0, -u * 0.6, 0, u * 0.6); gr.addColorStop(0, '#8d929f'); gr.addColorStop(1, '#646875');
    x.fillStyle = gr;
    x.beginPath();
    x.moveTo(0, -u * 0.52);
    x.bezierCurveTo(u * 0.5, -u * 0.52, u * 0.66, -u * 0.2, u * 0.7, u * 0.12);
    x.lineTo(u * 0.5, u * 0.16); x.lineTo(u * 0.6, u * 0.34); x.lineTo(u * 0.36, u * 0.36);
    x.bezierCurveTo(u * 0.26, u * 0.56, -u * 0.26, u * 0.56, -u * 0.36, u * 0.36);
    x.lineTo(-u * 0.6, u * 0.34); x.lineTo(-u * 0.5, u * 0.16); x.lineTo(-u * 0.7, u * 0.12);
    x.bezierCurveTo(-u * 0.66, -u * 0.2, -u * 0.5, -u * 0.52, 0, -u * 0.52);
    x.closePath(); x.fill();
    // light muzzle + forehead stripe
    x.fillStyle = '#ece6da';
    x.beginPath(); x.ellipse(0, u * 0.22, u * 0.3, u * 0.24, 0, 0, 7); x.fill();
    x.beginPath(); x.moveTo(-u * 0.07, -u * 0.5); x.lineTo(u * 0.07, -u * 0.5); x.lineTo(u * 0.12, u * 0.02); x.lineTo(-u * 0.12, u * 0.02); x.closePath(); x.fill();
    // sly eyes
    const eye = (sx) => {
      x.save(); x.translate(sx * u * 0.25, -u * 0.1); x.rotate(sx * 0.32);
      x.fillStyle = '#f5c542'; x.beginPath(); x.ellipse(0, 0, u * 0.13, u * 0.075, 0, 0, 7); x.fill();
      x.fillStyle = '#1b1416'; x.beginPath(); x.ellipse(sx * -u * 0.02, 0, u * 0.025, u * 0.065, 0, 0, 7); x.fill();
      x.restore();
      x.strokeStyle = '#33353d'; x.lineWidth = u * 0.06; x.lineCap = 'round';
      x.beginPath(); x.moveTo(sx * u * 0.1, -u * 0.17); x.lineTo(sx * u * 0.38, -u * 0.25); x.stroke();
    };
    eye(-1); eye(1);
    // nose + smirk
    x.fillStyle = '#1f1a1d'; x.beginPath(); x.ellipse(0, u * 0.1, u * 0.1, u * 0.07, 0, 0, 7); x.fill();
    x.strokeStyle = '#3a2f33'; x.lineWidth = u * 0.045;
    x.beginPath(); x.moveTo(-u * 0.12, u * 0.3); x.quadraticCurveTo(u * 0.04, u * 0.38, u * 0.16, u * 0.26); x.stroke();
    // scarf in the player's colour
    x.fillStyle = color;
    x.beginPath(); x.moveTo(-u * 0.38, u * 0.4); x.quadraticCurveTo(0, u * 0.62, u * 0.38, u * 0.4); x.lineTo(u * 0.34, u * 0.54); x.quadraticCurveTo(0, u * 0.74, -u * 0.34, u * 0.54); x.closePath(); x.fill();
    x.beginPath(); x.moveTo(u * 0.18, u * 0.56); x.lineTo(u * 0.34, u * 0.8); x.lineTo(u * 0.06, u * 0.66); x.closePath(); x.fill();
    return c;
  }
  function rng(seed) { let a = seed | 0; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(x, X, Y, W, H, R) { x.beginPath(); x.moveTo(X + R, Y); x.arcTo(X + W, Y, X + W, Y + H, R); x.arcTo(X + W, Y + H, X, Y + H, R); x.arcTo(X, Y + H, X, Y, R); x.arcTo(X, Y, X + W, Y, R); x.closePath(); }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, g = null, G = null, bg = null, spr = null, flip = false;
    let sel = -1, drag = null, hover = -1, anim = null, busy = false, stopLoop = null, safety = 0, shownSeq = -1;
    let waitSeq = -1, waitUntil = 0;
    let hints = U.store.get('wolfsheep.hints', true);
    const col = (seat) => (api.players[seat] && api.players[seat].color) || (seat ? '#5bb3e6' : '#ee6a55');
    const localSeats = () => [0, 1].filter((i) => api.canAct(i));
    const anyLocal = localSeats().length > 0;

    const BS = { minHeight: '44px', flex: '1 1 0', minWidth: 0, padding: '6px 4px', fontSize: '13px', whiteSpace: 'nowrap' };
    const hud = L.h('div', { class: 'hud bottom', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px' } });
    const hintBtn = L.h('button', { class: 'btn sm ghost ws-tip', style: BS, onclick: toggleHints });
    const undoBtn = L.h('button', { class: 'btn sm ghost ws-undo', style: BS, text: '↶ 무르기', 'aria-label': '한 수 무르기', onclick: onUndo });
    const stopBtn = L.h('button', { class: 'btn primary ws-stop', style: Object.assign({}, BS, { flex: '1.5 1 0', fontSize: '14px' }), text: '여기서 멈추기', onclick: onStop });
    hud.append(hintBtn, undoBtn, stopBtn);
    const hint = L.h('div', { class: 'ws-hint', style: { position: 'absolute', left: '10px', right: '10px', textAlign: 'center', fontSize: '12.5px', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', pointerEvents: 'none' } });
    if (anyLocal) root.append(hud);
    root.append(hint);
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
    const spBoard = spot('ws-board'), spMe = spot('ws-me'), spOpp = spot('ws-opp');
    const vis = (el, on) => { el.style.display = on ? '' : 'none'; };
    const setBusy = (v) => { if (busy !== v) { busy = v; api.setBusy(v); updateHud(); } };

    function tipLabel() { hintBtn.textContent = (hints ? '💡 힌트 켬' : '💡 힌트 끔'); hintBtn.setAttribute('aria-pressed', String(hints)); }
    tipLabel();
    function toggleHints() { hints = !hints; U.store.set('wolfsheep.hints', hints); tipLabel(); api.sfx('click'); api.buzz(8); updateHud(); draw(); }
    function myTurn() { const a = st && actor(st); return a != null && api.canAct(a); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }
    function canUndo() { return !!st && !st.st && !api.online && st.solo >= 0 && myTurn() && actor(st) === st.solo && !st.cj && st.u.length > 0 && !locked(); }
    function onUndo() { if (!canUndo() || busy) return; sel = -1; drag = null; api.sfx('click'); api.buzz(15); send({ t: 'undo' }); }
    function onStop() { if (!st || !st.cj || !myTurn() || locked() || busy) return; api.sfx('click'); api.buzz(10); send({ t: 'stop' }); }
    const mySide = () => (st && myTurn() ? st.sd : null);

    /* ----- layout ----- */
    function layout() {
      if (!st) return;
      g = geo(st.v);
      const mine = localSeats();
      flip = mine.length === 1 && mine[0] === st.W;
      const W = cv.w, H = cv.h, n = g.rows;
      const hudH = anyLocal ? 62 : 0, cardH = 44, hintH = 20, gap = 6;
      // board side = n*cs + 2*frame; the cross meadow's fence needs a frame that grows with the cell size
      const fk = g.v === 'c' ? 0 : 0.16, f0 = g.v === 'c' ? 10 : 10;
      const availW = W - 16 - 2 * f0, availH = H - hudH - 2 * cardH - hintH - 3 * gap - 12 - 2 * f0;
      const cs = Math.max(20, Math.floor(Math.min(availW / (n + 2 * fk), availH / (n + 2 * fk), 62)));
      const frame = Math.ceil(f0 + fk * cs);
      const bw = cs * n + 2 * frame;
      const bx = Math.round((W - bw) / 2);
      const total = cardH * 2 + gap * 2 + bw + 4 + hintH;
      const top = Math.max(4, Math.round((H - hudH - total) / 2));
      const by = top + cardH + gap;
      G = { cs, bw, bx, by, frame, ox: bx + frame, oy: by + frame, cardH, cardW: bw,
        cTop: { x: bx, y: top }, cBot: { x: bx, y: by + bw + gap }, piece: Math.round(cs * (g.v === 'c' ? 0.9 : 0.86)) };
      hint.style.top = Math.round(G.cBot.y + cardH + 4) + 'px';
      place(spBoard, bx, by, bw, bw);
      const meTop = false;
      place(meTop ? spOpp : spMe, G.cBot.x, G.cBot.y, bw, cardH);
      place(meTop ? spMe : spOpp, G.cTop.x, G.cTop.y, bw, cardH);
      buildBg();
      const dpr = cv.dpr;
      spr = { s: sheepSprite(G.piece, col(1 - st.W), dpr), w: wolfSprite(G.piece, col(st.W), dpr),
        sMini: sheepSprite(30, col(1 - st.W), dpr), wMini: wolfSprite(30, col(st.W), dpr) };
    }
    function pos(p) {
      let r = g.R[p], c = g.C[p];
      if (flip) { r = g.rows - 1 - r; c = g.cols - 1 - c; }
      return { x: G.ox + (c + 0.5) * G.cs, y: G.oy + (r + 0.5) * G.cs };
    }
    function hit(x, y) {
      let c = Math.floor((x - G.ox) / G.cs), r = Math.floor((y - G.oy) / G.cs);
      if (r < 0 || c < 0 || r >= g.rows || c >= g.cols) return -1;
      if (flip) { r = g.rows - 1 - r; c = g.cols - 1 - c; }
      return g.cell(r, c);
    }

    function buildBg() {
      const W = cv.w, H = cv.h, dpr = cv.dpr;
      const [c, x] = mkCanvas(W, H, dpr);
      const { cs, bw, bx, by, frame, ox, oy } = G, n = g.rows, R = rng(7 + n);
      if (g.v === 'c') {
        // wooden fence frame
        x.fillStyle = 'rgba(0,0,0,.35)'; rr(x, bx + 2, by + 4, bw, bw, 12); x.fill();
        const wg = x.createLinearGradient(bx, by, bx + bw, by + bw); wg.addColorStop(0, '#8a5a33'); wg.addColorStop(1, '#5c3a20');
        x.fillStyle = wg; rr(x, bx, by, bw, bw, 12); x.fill();
        x.strokeStyle = 'rgba(255,220,170,.18)'; x.lineWidth = 1;
        for (let i = 0; i < 6; i++) { const yy = by + 2 + R() * (bw - 4); x.beginPath(); x.moveTo(bx + 3, yy); x.lineTo(bx + frame - 2, yy + 1); x.moveTo(bx + bw - frame + 2, yy); x.lineTo(bx + bw - 3, yy - 1); x.stroke(); }
        for (let r = 0; r < 8; r++) for (let cc = 0; cc < 8; cc++) {
          const dark = (r + cc) % 2 === 1, X = ox + cc * cs, Y = oy + r * cs;
          x.fillStyle = dark ? ((r + cc) % 4 === 1 ? '#5c9a45' : '#57943f') : '#b8d88a';
          x.fillRect(X, Y, cs, cs);
          // grass blades
          x.strokeStyle = dark ? 'rgba(30,70,20,.35)' : 'rgba(110,150,60,.45)'; x.lineWidth = 1;
          for (let k = 0; k < 5; k++) { const gx = X + 3 + R() * (cs - 6), gy = Y + 4 + R() * (cs - 6); x.beginPath(); x.moveTo(gx, gy); x.lineTo(gx + (R() - 0.5) * 3, gy - 3 - R() * 3); x.stroke(); }
          if (!dark && R() < 0.5) { // little flowers on the pale squares
            const fx = X + 5 + R() * (cs - 10), fy = Y + 5 + R() * (cs - 10), fc = ['#fff6e0', '#f7d35a', '#f0a7c0'][(R() * 3) | 0];
            x.fillStyle = fc; for (let k = 0; k < 5; k++) { const a = k * 1.256; x.beginPath(); x.arc(fx + Math.cos(a) * 2.2, fy + Math.sin(a) * 2.2, 1.6, 0, 7); x.fill(); }
            x.fillStyle = '#e8a23a'; x.beginPath(); x.arc(fx, fy, 1.3, 0, 7); x.fill();
          }
        }
        x.strokeStyle = 'rgba(0,0,0,.25)'; x.lineWidth = 1; x.strokeRect(ox + 0.5, oy + 0.5, cs * 8 - 1, cs * 8 - 1);
        // the wolf's goal row (row 7): warm tint + little flags
        for (let p = 28; p < 32; p++) {
          const q = pos(p), X = q.x - cs / 2, Y = q.y - cs / 2;
          x.fillStyle = 'rgba(240,190,80,.28)'; x.fillRect(X, Y, cs, cs);
          const fx = X + cs * 0.12, fy = Y + cs * 0.1;
          x.strokeStyle = '#4a3020'; x.lineWidth = 1.4; x.beginPath(); x.moveTo(fx, fy); x.lineTo(fx, fy + cs * 0.3); x.stroke();
          x.fillStyle = '#e3ae45'; x.beginPath(); x.moveTo(fx, fy); x.lineTo(fx + cs * 0.17, fy + cs * 0.07); x.lineTo(fx, fy + cs * 0.14); x.closePath(); x.fill();
        }
      } else {
        // cross-shaped meadow with dirt paths
        const m = cs * 0.16, a0 = 2 * cs, a1 = 5 * cs;
        const crossPath = (pad) => {
          x.beginPath();
          const L0 = ox - pad, T0 = oy - pad, R0 = ox + 7 * cs + pad, B0 = oy + 7 * cs + pad;
          const p1 = ox + a0 - pad, p2 = ox + a1 + pad, q1 = oy + a0 - pad, q2 = oy + a1 + pad;
          x.moveTo(p1, T0); x.lineTo(p2, T0); x.lineTo(p2, q1); x.lineTo(R0, q1); x.lineTo(R0, q2); x.lineTo(p2, q2);
          x.lineTo(p2, B0); x.lineTo(p1, B0); x.lineTo(p1, q2); x.lineTo(L0, q2); x.lineTo(L0, q1); x.lineTo(p1, q1); x.closePath();
        };
        x.save(); x.lineJoin = 'round';
        x.fillStyle = 'rgba(0,0,0,.35)'; x.translate(2, 4); crossPath(m + 4); x.fill(); x.translate(-2, -4);
        x.fillStyle = '#6b4426'; crossPath(m + 4); x.fill();
        x.strokeStyle = '#6b4426'; x.lineWidth = 10; crossPath(m + 4); x.stroke();
        const gg = x.createRadialGradient(ox + 3.5 * cs, oy + 3.5 * cs, cs, ox + 3.5 * cs, oy + 3.5 * cs, 5 * cs);
        gg.addColorStop(0, '#7fb85a'); gg.addColorStop(1, '#5a9440');
        x.fillStyle = gg; crossPath(m); x.fill();
        x.strokeStyle = '#7fb85a'; x.lineWidth = 8; crossPath(m); x.stroke();
        x.restore();
        x.save(); crossPath(m + 3); x.clip();
        x.strokeStyle = 'rgba(30,70,20,.35)'; x.lineWidth = 1;
        for (let k = 0; k < 260; k++) { const gx = ox + R() * 7 * cs, gy = oy + R() * 7 * cs; x.beginPath(); x.moveTo(gx, gy); x.lineTo(gx + (R() - 0.5) * 3, gy - 3 - R() * 3); x.stroke(); }
        for (let k = 0; k < 26; k++) {
          const fx = ox + R() * 7 * cs, fy = oy + R() * 7 * cs, fc = ['#fff6e0', '#f7d35a', '#f0a7c0'][(R() * 3) | 0];
          x.fillStyle = fc; for (let j = 0; j < 5; j++) { const a = j * 1.256; x.beginPath(); x.arc(fx + Math.cos(a) * 2.2, fy + Math.sin(a) * 2.2, 1.6, 0, 7); x.fill(); }
        }
        x.restore();
        // paths
        x.lineCap = 'round';
        for (const [lw, cc] of [[cs * 0.2, 'rgba(70,45,20,.35)'], [cs * 0.15, '#cfa86c']]) {
          x.strokeStyle = cc; x.lineWidth = lw;
          for (let p = 0; p < g.n; p++) for (const d of [2, 3]) { const q = g.step[p * 4 + d]; if (q < 0) continue; const A = pos(p), B = pos(q); x.beginPath(); x.moveTo(A.x, A.y); x.lineTo(B.x, B.y); x.stroke(); }
        }
        for (let p = 0; p < g.n; p++) {
          const A = pos(p);
          x.fillStyle = 'rgba(70,45,20,.4)'; x.beginPath(); x.arc(A.x, A.y + 1, cs * 0.2, 0, 7); x.fill();
          x.fillStyle = '#dcb97e'; x.beginPath(); x.arc(A.x, A.y, cs * 0.18, 0, 7); x.fill();
          x.fillStyle = 'rgba(255,255,255,.18)'; x.beginPath(); x.arc(A.x - cs * 0.04, A.y - cs * 0.05, cs * 0.08, 0, 7); x.fill();
        }
      }
      bg = c;
    }

    /* ----- cards ----- */
    function cardInfo(side) {
      const seat = seatOf(st, side), P = api.players[seat] || {}, b = st.b;
      let status = '';
      if (side === 'w') {
        if (g.v === 'c') { const p = wolfPath(b, g); status = p ? '깃발까지 ' + p.length + '칸' : '길이 막혔어요'; }
        else status = '잡은 양 ' + st.k + '/' + CAP_GOAL;
      } else {
        if (g.v === 'c') status = wolfPath(b, g) ? '늑대 길 열림!' : '늑대 길 막음';
        else status = '해 지기까지 ' + Math.max(0, MOVE_CAP - st.n);
      }
      return { seat, name: P.name || (seat + 1) + '번', role: side === 'w' ? '늑대' : '양 ' + (b.split('s').length - 1) + '마리', status, warn: g.v === 'c' && side === 's' && !!wolfPath(b, g) };
    }
    function drawCard(at, side) {
      const I = cardInfo(side), X = at.x, Y = at.y, W = G.cardW, H = G.cardH;
      const active = !st.st && st.sd === side;
      ctx.fillStyle = active ? '#2e2640' : '#221c2e';
      rr(ctx, X, Y, W, H, 12); ctx.fill();
      ctx.lineWidth = active ? 2 : 1; ctx.strokeStyle = active ? '#e3ae45' : 'rgba(255,255,255,.08)';
      rr(ctx, X + 0.5, Y + 0.5, W - 1, H - 1, 12); ctx.stroke();
      ctx.drawImage(side === 'w' ? spr.wMini : spr.sMini, X + 8, Y + 7, 30, 30);
      ctx.fillStyle = col(I.seat); ctx.beginPath(); ctx.arc(X + 44, Y + 15, 4, 0, 7); ctx.fill();
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      ctx.fillStyle = '#f2e9d8'; ctx.font = '600 13.5px ' + FONT;
      const nameW = W - 52 - 112;
      let nm = I.name; while (nm.length > 1 && ctx.measureText(nm).width > nameW) nm = nm.slice(0, -1);
      if (nm !== I.name) nm += '…';
      ctx.fillText(nm, X + 52, Y + 15);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '12px ' + FONT; ctx.fillText(I.role, X + 40, Y + 32);
      ctx.textAlign = 'right'; ctx.font = '600 12.5px ' + FONT;
      ctx.fillStyle = I.warn ? '#ee6a55' : (side === 'w' && g.v === 'x' && st.k > 0) ? '#ee9a55' : '#e3ae45';
      ctx.fillText(I.status, X + W - 10, Y + H / 2);
      if (active) { ctx.fillStyle = '#e3ae45'; ctx.font = '11px ' + FONT; }
    }

    /* ----- drawing ----- */
    function targetsOf(from) {
      if (!st || from < 0) return [];
      return movesOf(g, st.b, st.sd, st.cj, wolfAt(st.b)).filter((m) => m[0] === from);
    }
    function movable() {
      const s = new Set();
      for (const m of movesOf(g, st.b, st.sd, st.cj, wolfAt(st.b))) s.add(m[0]);
      return s;
    }
    function drawPiece(kind, x, y, scale, alpha) {
      const S = G.piece * (scale || 1), im = kind === 'w' ? spr.w : spr.s;
      if (alpha != null) ctx.globalAlpha = alpha;
      ctx.drawImage(im, x - S / 2, y - S / 2, S, S);
      ctx.globalAlpha = 1;
    }
    function paw(x, y, s, a) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.fillStyle = 'rgba(60,40,30,.42)';
      ctx.beginPath(); ctx.ellipse(0, s * 0.25, s * 0.32, s * 0.27, 0, 0, 7); ctx.fill();
      for (const [dx, dy] of [[-0.34, -0.18], [-0.12, -0.38], [0.12, -0.38], [0.34, -0.18]]) { ctx.beginPath(); ctx.arc(dx * s, dy * s, s * 0.12, 0, 7); ctx.fill(); }
      ctx.restore();
    }
    function draw() {
      if (!st || !G) return;
      cv.clear();
      ctx.drawImage(bg, 0, 0, cv.w, cv.h);
      const cs = G.cs, now = performance.now();
      // cards: the wolf's card sits on the wolf's home side
      const wolfTop = !flip;
      drawCard(wolfTop ? G.cTop : G.cBot, 'w');
      drawCard(wolfTop ? G.cBot : G.cTop, 's');
      const mine = !st.st && myTurn() && !locked() && !busy;
      // last move marker
      const lm = st.last;
      if (lm && !anim) {
        const A = pos(lm.f), B = pos(lm.to);
        ctx.strokeStyle = 'rgba(255,240,200,.55)'; ctx.lineWidth = 2; ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.arc(A.x, A.y, cs * 0.3, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(255,236,170,.22)'; ctx.beginPath(); ctx.arc(B.x, B.y, cs * 0.46, 0, 7); ctx.fill();
        if (lm.x >= 0) { const X = pos(lm.x); ctx.strokeStyle = 'rgba(238,106,85,.7)'; ctx.lineWidth = 2.5; const r = cs * 0.14; ctx.beginPath(); ctx.moveTo(X.x - r, X.y - r); ctx.lineTo(X.x + r, X.y + r); ctx.moveTo(X.x + r, X.y - r); ctx.lineTo(X.x - r, X.y + r); ctx.stroke(); }
      }
      // hints: the wolf's way out (체크무늬) or loose sheep (십자 들판)
      const tipOn = hints && !st.st && anyLocal && !anim && localSeats().includes(actor(st));
      if (tipOn && g.v === 'c') {
        const path = wolfPath(st.b, g);
        if (path) {
          let prv = pos(wolfAt(st.b));
          for (const p of path) { const q = pos(p); paw(q.x, q.y, cs * 0.34, Math.atan2(q.y - prv.y, q.x - prv.x) + Math.PI / 2); prv = q; }
        }
      }
      const looseSet = tipOn && g.v === 'x' ? new Set(loose(st.b, g)) : null;
      // pieces
      const b = st.b;
      const dragFrom = drag && drag.moved ? drag.p : -1;
      for (let p = 0; p < g.n; p++) {
        const k = b[p];
        if (k === '.') continue;
        if (anim && p === anim.to) continue;
        if (p === dragFrom) continue;
        const q = pos(p);
        if (looseSet && looseSet.has(p)) { ctx.fillStyle = 'rgba(238,106,85,.35)'; ctx.beginPath(); ctx.arc(q.x, q.y, cs * 0.46, 0, 7); ctx.fill(); }
        drawPiece(k, q.x, q.y);
      }
      // movable glow + selection
      if (mine) {
        if (sel < 0 && st.sd === 's') {
          ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 2;
          for (const p of movable()) { const q = pos(p); ctx.beginPath(); ctx.arc(q.x, q.y, cs * 0.44, 0, 7); ctx.stroke(); }
        }
        if (sel >= 0) {
          const q = pos(sel);
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(q.x, q.y, cs * 0.46, 0, 7); ctx.stroke();
          for (const m of targetsOf(sel)) {
            const t = pos(m[1]), cap = m[2] >= 0;
            const bad = hints && st.sd === 's' && risky(st.b, g, m[0], m[1]);
            const hov = hover === m[1] || (drag && drag.over === m[1]);
            ctx.fillStyle = cap ? 'rgba(238,106,85,.85)' : bad ? 'rgba(238,106,85,.75)' : 'rgba(255,250,235,.85)';
            ctx.beginPath(); ctx.arc(t.x, t.y, cs * (hov ? 0.22 : 0.16), 0, 7); ctx.fill();
            ctx.strokeStyle = 'rgba(40,30,20,.45)'; ctx.lineWidth = 1.5; ctx.stroke();
            if (bad || cap) {
              ctx.fillStyle = '#fff'; ctx.font = '700 ' + Math.round(cs * 0.24) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
              ctx.fillText(cap ? '✕' : '!', t.x, t.y + 1);
            }
            if (cap) { const X = pos(m[2]); ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2.5; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.arc(X.x, X.y, cs * 0.45, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
          }
        }
      }
      // end markers
      if (st.st) {
        const q = pos(wolfAt(st.b));
        ctx.lineWidth = 3;
        ctx.strokeStyle = st.st.w === 'w' ? '#e3ae45' : '#ee6a55';
        ctx.beginPath(); ctx.arc(q.x, q.y, cs * 0.5, 0, 7); ctx.stroke();
      }
      // animation
      if (anim) {
        const t = Math.min(1, (now - anim.t0) / anim.dur), e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
        const A = pos(anim.f), B = pos(anim.to);
        if (anim.x >= 0) {
          const X = pos(anim.x), k = Math.min(1, Math.max(0, (t - 0.45) / 0.55));
          if (k < 1) drawPiece('s', X.x, X.y, 1 - 0.6 * k, 1 - k);
          if (k > 0) { ctx.fillStyle = 'rgba(255,255,255,' + (0.8 * (1 - k)) + ')'; for (let i = 0; i < 6; i++) { const a = i * 1.047 + 0.3; ctx.beginPath(); ctx.arc(X.x + Math.cos(a) * cs * 0.5 * k, X.y + Math.sin(a) * cs * 0.5 * k, cs * 0.1, 0, 7); ctx.fill(); } }
        }
        const hop = Math.sin(Math.PI * t) * cs * (anim.x >= 0 ? 0.55 : 0.2);
        drawPiece(anim.sd, A.x + (B.x - A.x) * e, A.y + (B.y - A.y) * e - hop, 1 + 0.08 * Math.sin(Math.PI * t));
      }
      // drag ghost
      if (drag && drag.moved) drawPiece(b[drag.p], drag.x, drag.y - cs * 0.15, 1.12, 0.92);
    }

    /* ----- HUD / hint line ----- */
    function updateHud() {
      if (!st) return;
      const my = myTurn() && !st.st;
      vis(hintBtn, anyLocal && !st.st);
      vis(undoBtn, !st.st && !api.online && st.solo >= 0);
      undoBtn.disabled = !canUndo() || busy;
      vis(stopBtn, my && !!st.cj);
      stopBtn.disabled = locked() || busy;
      let h = '';
      if (!st.st) {
        const a = actor(st), P = api.players[a] || {};
        if (my) {
          if (st.cj) h = '한 번 더 뛰어넘어 잡을 수 있어요 · 아니면 「여기서 멈추기」';
          else if (st.sd === 'w') h = g.v === 'c' ? '늑대를 대각선 한 칸 · 깃발 줄에 닿으면 승리' : '늑대를 한 칸 · 양을 뛰어넘으면 잡아요';
          else if (sel < 0) h = g.v === 'c' ? '움직일 양을 탭 · 앞쪽 대각선으로 한 칸' : '움직일 양을 탭 · 앞이나 옆으로 한 칸';
          else h = hints ? '점을 탭해 이동 · 빨간 !는 위험한 칸' : '점을 탭해 이동 · 다른 양을 탭하면 바꿔요';
        } else h = (P.name || '') + (P.ai ? ' 생각 중…' : ' 차례');
      } else { const r = result(st); h = r.title + ' ' + r.text; }
      hint.textContent = h;
    }

    /* ----- input ----- */
    function trySelect(p) {
      if (p < 0 || !st) return false;
      if (!targetsOf(p).length) return false;
      if (sel !== p) { sel = p; api.sfx('tick'); api.buzz(6); }
      return true;
    }
    function tryMove(to) {
      const m = targetsOf(sel).find((mm) => mm[1] === to);
      if (!m) return false;
      api.buzz(12);
      send({ t: 'm', f: m[0], to: m[1] });
      sel = st.sd === 'w' ? sel : -1;
      return true;
    }
    function onDown(e) {
      if (!st || !G || st.st || !myTurn() || locked() || busy) return;
      const q = cv.local(e), p = hit(q.x, q.y);
      if (p < 0) { if (st.sd === 's') { sel = -1; updateHud(); draw(); } return; }
      if (sel >= 0 && targetsOf(sel).some((m) => m[1] === p)) { tryMove(p); updateHud(); draw(); return; }
      if (trySelect(p)) { drag = { p, id: e.pointerId, x: q.x, y: q.y, sx: q.x, sy: q.y, moved: false, over: -1 }; try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {} }
      else if (st.b[p] === (st.sd === 'w' ? 'w' : 's')) {
        api.toast(st.cj ? '이어서 잡을 양이 있는 쪽으로만 뛸 수 있어요' : '이 말은 지금 갈 곳이 없어요'); api.buzz(20);
      } else if (st.sd === 's') sel = -1;
      updateHud(); draw();
    }
    function onMove(e) {
      if (!G || !st) return;
      const q = cv.local(e);
      if (!drag) {
        if (e.pointerType === 'mouse') { const p = hit(q.x, q.y); if (p !== hover) { hover = p; if (sel >= 0) draw(); } }
        return;
      }
      if (e.pointerId !== drag.id) return;
      drag.x = q.x; drag.y = q.y;
      if (!drag.moved && Math.hypot(q.x - drag.sx, q.y - drag.sy) > 8) drag.moved = true;
      if (drag.moved) { const p = hit(q.x, q.y); drag.over = targetsOf(drag.p).some((m) => m[1] === p) ? p : -1; draw(); }
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag; drag = null;
      if (d.moved) {
        const q = cv.local(e), p = hit(q.x, q.y);
        if (p >= 0 && p !== d.p && myTurn() && !locked() && targetsOf(d.p).some((m) => m[1] === p)) { sel = d.p; tryMove(p); }
      }
      updateHud(); draw();
    }
    function onCancel() { drag = null; draw(); }
    function onLeave() { if (hover >= 0) { hover = -1; draw(); } }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.cv.addEventListener('pointerleave', onLeave);
    cv.onresize = () => { if (st) { layout(); draw(); } };

    function animate() {
      setBusy(true);
      clearTimeout(safety);
      safety = setTimeout(() => { anim = null; if (stopLoop) { stopLoop(); stopLoop = null; } setBusy(false); autoSel(); draw(); }, 3000);
      if (stopLoop) return;
      stopLoop = U.loop(() => {
        if (anim && performance.now() >= anim.t0 + anim.dur) {
          if (anim.x >= 0) { api.sfx('hit'); api.buzz(22); }
          anim = null;
        }
        draw();
        if (!anim) { if (stopLoop) { stopLoop(); stopLoop = null; } clearTimeout(safety); setBusy(false); autoSel(); draw(); }
      });
    }
    function autoSel() {
      if (!st || st.st || !myTurn()) { sel = -1; return; }
      if (st.sd === 'w') sel = wolfAt(st.b);
      else if (sel >= 0 && !targetsOf(sel).length) sel = -1;
      updateHud();
    }

    return {
      update(next, prev) {
        const fresh = prev && prev !== next && next.seq !== shownSeq;
        const relayout = !st || st.v !== next.v || st.W !== next.W;
        st = next;
        if (relayout) layout();
        if (fresh) {
          const sp = L.debug.speed || 1;
          if (next.ev && next.ev.id === next.seq && next.ev.k === 'u') { api.sfx('whoosh'); api.toast('한 수 물렀어요'); anim = null; sel = -1; }
          else if (next.last && next.last.id === next.seq) {
            const lm = next.last;
            anim = { sd: lm.sd, f: lm.f, to: lm.to, x: lm.x, t0: performance.now(), dur: (lm.x >= 0 ? 420 : 260) / sp };
            api.sfx(lm.x >= 0 ? 'whoosh' : lm.sd === 'w' ? 'thud' : 'pop'); api.buzz(8);
            if (lm.x >= 0) api.toast(next.st ? '양을 ' + CAP_GOAL + '마리 잡았어요!' : '늑대가 양을 잡았어요! (' + next.k + '/' + CAP_GOAL + ')');
            else if (next.st && next.st.r === 'trap') api.toast('늑대가 갇혔어요!');
            else if (next.st && next.st.r === 'goal') api.toast('늑대가 빠져나갔어요!');
            else if (g.v === 'c' && lm.sd === 's' && prev && prev.b && !wolfPath(prev.b, g) && wolfPath(next.b, g) && !next.st) api.toast('늑대 길이 열렸어요!');
            animate();
          }
        }
        if (!prev) sel = -1;
        if (!anim) autoSel();
        else if (sel >= 0 && (st.st || !myTurn())) sel = -1;
        shownSeq = next.seq;
        updateHud();
        draw();
      },
      destroy() {
        if (stopLoop) stopLoop();
        stopLoop = null;
        clearTimeout(safety);
        setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onCancel);
        cv.cv.removeEventListener('pointerleave', onLeave);
        cv.destroy(); hud.remove(); hint.remove(); spBoard.remove(); spMe.remove(); spOpp.remove();
      },
    };
  }

  L.register({
    id: 'wolfsheep', name: '늑대와 양', tag: '비대칭 사냥', cat: '보드',
    icon: '<path d="M7 27l3-21 10 10h12l10-10 3 21-5 9-12 11-12-11z" fill="currentColor"/><path d="M19 27l6 2-6 1z M37 27l-6 2 6 1z" fill="#000" opacity=".55"/><path d="M24 38h8l-4 4z" fill="#000" opacity=".6"/><circle cx="45" cy="47" r="5" fill="currentColor" opacity=".7"/><circle cx="51" cy="43" r="4.5" fill="currentColor" opacity=".7"/><circle cx="50" cy="50" r="4" fill="currentColor" opacity=".7"/>',
    tint: '#3f5a2a',
    blurb: '늑대 1마리 대 양 떼! 늑대는 양 떼를 뚫고 빠져나가거나 양을 잡고, 양들은 힘을 모아 늑대를 꼼짝 못 하게 가둬요.',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, hidden: false, aiDelay: 500,
    options: [
      { id: 'board', label: '판', choices: [{ v: 'c', label: '체크무늬 (양 4)' }, { v: 'x', label: '십자 들판 (양 13)' }], def: 'c' },
      { id: 'side', label: '1번 자리 역할', choices: [{ v: 'w', label: '늑대' }, { v: 's', label: '양' }, { v: 'r', label: '무작위' }], def: 'w' },
    ],
    quick: [
      '한 사람은 늑대 1마리, 다른 사람은 양 떼를 맡아요. 늑대가 먼저, 번갈아 말 하나를 한 칸씩 움직여요.',
      '늑대는 어느 쪽으로나 갈 수 있지만, 양은 앞(과 옆)으로만 가고 뒤로는 못 가요.',
      '늑대가 꼼짝 못 하게 갇히면 양 승! 늑대가 빠져나가면(체크무늬) 또는 양을 5마리 잡으면(십자 들판) 늑대 승!',
    ],
    rules: [
      { h: '목표', p: [
        '늑대 1마리와 양 떼의 쫓고 쫓기는 판 놀이예요. 두 사람의 역할이 서로 달라요.',
        '늑대: 양 떼를 뚫고 빠져나가거나(체크무늬), 양을 잡아먹어요(십자 들판).',
        '양: 서로 붙어 벽을 만들어 늑대가 한 칸도 못 움직이게 가두면 이겨요.'] },
      { h: '판 ① 체크무늬 (기본, 양 4마리)', p: [
        '8×8 체크무늬 들판의 진한 칸만 써요. 양 4마리는 아래 끝 줄, 늑대는 위 끝 줄에서 시작해요.',
        '늑대: 대각선 4방향 어디로든 한 칸. 양: 앞쪽 대각선 2방향으로만 한 칸(뒤로 못 가요).',
        '아무도 잡지 않아요. 이미 말이 있는 칸으로는 못 가요.',
        '늑대가 양들이 출발한 끝 줄(깃발 칸)에 닿으면 늑대 승리.',
        '늑대가 움직일 칸이 하나도 없으면 양 승리. (양이 하나도 못 움직이게 되면 늑대 승리)',
        '정석대로 두면 양이 이기는 판이에요. 그만큼 양은 틈을 보이면 안 되고, 늑대는 틈을 노려야 해요.'] },
      { h: '판 ② 십자 들판 (양 13마리)', p: [
        '십자 모양 길에 점 33개가 있어요. 선을 따라 가로·세로로만 움직여요(대각선 없음).',
        '양 13마리는 아래쪽, 늑대는 한가운데에서 시작해요.',
        '양: 앞이나 옆으로 한 칸(뒤로는 못 가요). 늑대: 어느 쪽이든 한 칸.',
        '늑대는 바로 옆 양을 뛰어넘어 바로 뒤 빈 점에 내려앉으면 그 양을 잡아요. 잡은 뒤 또 뛰어넘을 수 있으면 이어서 잡아도 되고, 「여기서 멈추기」로 멈춰도 돼요. 잡기는 의무가 아니에요.',
        '늑대가 양을 5마리 잡으면 늑대 승리. 양이 60번 움직일 때까지(해 질 녘) 늑대를 못 가둬도 늑대 승리.',
        '늑대가 한 칸도 못 움직이고 뛰어넘을 양도 없으면 양 승리.'] },
      { h: '차례에 할 일', p: [
        '늑대가 먼저 움직여요. 그다음 양 쪽이 양 한 마리를 한 칸 움직이고, 번갈아 계속해요.',
        '차례를 건너뛸 수는 없어요.'] },
      { h: '조작', p: [
        '내 말을 탭하면 갈 수 있는 곳에 점이 떠요. 점을 탭하면 이동! 말을 끌어다 놓아도 돼요.',
        '늑대 차례에는 늑대가 저절로 골라져요. 양은 움직일 수 있는 양에 금색 테두리가 보여요.',
        '빨간 ✕ 점: 양을 뛰어넘어 잡는 자리. 빨간 ! 점: 위험한 수(늑대 길이 열리거나, 늑대에게 잡힐 수 있는 수).',
        '💡 힌트(켬): 체크무늬에서는 늑대가 빠져나갈 수 있는 길을 발자국으로, 십자 들판에서는 지금 잡힐 수 있는 양을 빨갛게 보여 줘요. 버튼으로 끄고 켤 수 있어요.',
        '마지막으로 움직인 말은 출발 칸에 점선 고리, 도착 칸에 밝은 빛이 남아요.',
        '↶ 무르기: 이 폰에서 사람 1명 대 AI일 때만. 내 직전 수와 AI 응수를 함께 되돌려요(여러 번 가능).'] },
      { h: '작전 팁', p: [
        '양(체크무늬): 네 마리가 옆으로 나란히 줄을 맞춰 한 줄씩 올라가세요. 줄 사이에 구멍이 생기면 늑대가 그 틈으로 빠져나가요.',
        '늑대(체크무늬): 양 떼 가운데쯤에 바짝 붙어 양이 줄을 흐트러뜨리게 만드세요.',
        '양(십자 들판): 서로 등을 대고 붙어 있으면 늑대가 못 뛰어넘어요. 뒤에 빈 점이 있는 양이 위험해요.',
        '늑대(십자 들판): 양 바로 뒤에 빈 점이 생기는 순간을 노리세요. 한 번에 두세 마리를 연달아 잡을 수도 있어요.'] },
      { h: '예시', p: [
        '체크무늬: 양 4마리가 나란히 서 있으면 늑대는 그 줄을 못 넘어요. 그런데 양 한 마리만 혼자 앞으로 나가면 그 자리에 틈이 생겨 늑대가 대각선으로 빠져나가요. 그러면 「늑대 길 열림!」 표시가 떠요.',
        '십자 들판: 늑대 ● 바로 위에 양 ○, 그 위가 빈 점이면 늑대가 ○를 뛰어넘어 잡아요. 내려앉은 곳에서 또 양 뒤가 비어 있으면 한 번 더 잡을 수 있어요.'] },
      { h: 'AI', p: [
        '쉬움은 실수가 잦아 이기기 쉽고, 보통은 몇 수 앞을 보고, 어려움은 체크무늬에서 끝까지 다 읽어 실수가 없어요(어려움 양은 거의 못 이겨요!).',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
    ],
    tutorial: [
      { sel: '.ws-board', text: '늑대 1마리와 양 떼의 쫓고 쫓기는 들판이에요. 늑대는 빠져나가려 하고, 양들은 늑대를 가두려 해요.' },
      { sel: '.ws-me', text: '이름표에 역할과 지금 상황이 보여요(늑대 길이 막혔는지, 잡은 양 수, 해 지기까지 남은 수). 금색 테두리가 지금 차례예요.' },
      { sel: '.ws-board', text: '내 말을 탭하면 갈 수 있는 곳에 점이 떠요. 점을 탭하면 이동! 끌어다 놓아도 돼요. 양은 뒤로 못 가니 신중하게!' },
      { sel: '.ws-board', text: '체크무늬: 늑대가 깃발 줄에 닿으면 늑대 승, 늑대가 꼼짝 못 하면 양 승. 십자 들판: 늑대는 양을 뛰어넘어 잡아요. 5마리 잡거나 해 질 때까지 버티면 늑대 승!' },
      { sel: '.ws-hint', text: '이 줄이 지금 할 일을 알려 줘요. 빨간 ! 점은 위험한 수, 발자국은 늑대가 빠져나갈 길이에요. 💡힌트로 끄고 켜고, AI전에선 ↶ 무르기도 돼요. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { geo, movesOf, startBoard, cSolve, SOL, hInit, XS, XW, maskOf, wolfPath, loose, risky, CAP_GOAL, MOVE_CAP },
  });
})();
