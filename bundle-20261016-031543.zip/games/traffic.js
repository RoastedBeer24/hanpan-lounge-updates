/* 신호등 지휘관 — realtime traffic-light control (1–4) + solo stage mode with stars.
   A toy town with 1–4 signalled crossings. Tap a crossing to flip its green between ↕ and ↔ (yellow → all-red → green).
   Cars, buses, trucks and ambulances arrive on a fixed seeded schedule (the same for every player), queue with an IDM
   car-following model and stop at red. Waiting drivers get impatient: a full gauge = the driver runs the red (−10), and
   if cross traffic is moving that can be a crash (♥ −1). Pedestrians cross with the parallel green. Later stages add
   right/left turns (↰ = protected left arrow for the green axis), rain (longer braking), roadwork (slow zone), rush hour.
   Network (pipes.js / cooking.js pattern): every device simulates its own town (host also the AI towns); guests publish
   [score, hearts, passed, crashes, f]; the host relays all rows + the clock and ends the match with setState. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;

  /* ======================= world & rules data ======================= */
  const W = 6, H = 9;                       // world size in road units (a road is 1 wide, one lane each way)
  const Q = 0.25, HW = 0.5, CW = 0.26, SLD = HW + CW + 0.04, EXT = 1.3;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];          // headings: 0 north, 1 east, 2 south, 3 west
  const RX = (d) => -DY[d], RY = (d) => DX[d];          // right-hand side of heading d (we drive on the right)
  const DT = 1 / 20, YEL = 1.6, ALLR = 0.8, S0 = 0.1, THW = 0.45, LOOK = 2.3, CRASH_T = 3.2;
  const PED_V = 0.5, PED_PAT = 16, HEARTS = 3;
  const PTS_RUN = 10, PTS_CRASH = 30, PTS_AMB_LATE = 40, PTS_AMB_OK = 20, PTS_PED = 5, PTS_PEDQ = 10, PTS_LOST = 5;
  // vehicle types: car, bus, truck, ambulance (len/wid in road units, v0 u/s, a u/s², pat = seconds to full impatience)
  const VT = [
    { k: 'car', nm: '승용차', len: 0.42, wid: 0.25, v0: 1.5, a: 1.7, pts: 10, pat: 11 },
    { k: 'bus', nm: '버스', len: 0.86, wid: 0.28, v0: 1.15, a: 0.85, pts: 30, pat: 13 },
    { k: 'trk', nm: '트럭', len: 0.66, wid: 0.28, v0: 1.2, a: 0.95, pts: 15, pat: 12 },
    { k: 'amb', nm: '구급차', len: 0.5, wid: 0.27, v0: 1.9, a: 2.2, pts: 30, pat: 3.2 },
  ];
  VT.forEach((t) => { const r = t.wid / 2, n = Math.max(2, Math.ceil(t.len / t.wid)), span = t.len / 2 - r; t.r = r; t.off = []; for (let i = 0; i < n; i++) t.off.push(-span + 2 * span * i / (n - 1)); });
  const PALETTE = ['#e8574a', '#f2b134', '#4a90d9', '#5fbf6a', '#a9b6c4', '#9b6bd3', '#ef8a3c', '#38b5ae', '#d65d8f', '#59616e'];
  const LAYS = [
    { vx: [3], hy: [4.5], nm: '네거리 1곳' },
    { vx: [1.6, 4.4], hy: [4.5], nm: '가로 두 곳' },
    { vx: [3], hy: [2.7, 6.3], nm: '세로 두 곳' },
    { vx: [3], hy: [1.9, 4.5, 7.1], nm: '세로 세 곳' },
    { vx: [1.6, 4.4], hy: [2.6, 6.4], nm: '바둑판 네 곳' },
  ];

  function mkRng(seed) {
    let a = (seed >>> 0) || 0x9e3779b9;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function hrand(seed, i) {   // random access: i-th number of a seed (spawn schedules are the same on every board)
    let t = (Math.imul((seed >>> 0) ^ 0x5bd1e995, 0x27d4eb2d) + Math.imul(i + 1, 0x9E3779B1)) >>> 0;
    t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); t = (t ^ (t >>> 14)) >>> 0;
    t = Math.imul(t ^ (t >>> 13), 0x85ebca6b) >>> 0; return ((t ^ (t >>> 16)) >>> 0) / 4294967296;
  }

  /* solo stages (fixed seed → same arrivals every time). rate = cars/s per road entry, bias = [↕, ↔] multipliers,
     pr/pl = right/left turn share, amb = ambulances, ped = pedestrians/s per crossing, work = [road, index, from, to] */
  const STAGES = [
    { n: '첫 신호등', lay: 0, dur: 50, rate: 0.15, bias: [1.2, 0.9], sd: 1101,
      tip: '교차로를 톡 누르면 초록불이 ↕ ↔ 로 바뀌어요. 빨간불 앞에 차가 쌓이면 바꿔 줘요!' },
    { n: '기다림 게이지', lay: 0, dur: 60, rate: 0.21, bias: [1.35, 0.8], sd: 2207,
      tip: '오래 기다린 차 위에 게이지가 차요. 빨개지면 화가 나서 빨간불에 달려요!' },
    { n: '버스와 트럭', lay: 0, dur: 60, rate: 0.2, bias: [1, 1.1], bus: 0.18, trk: 0.12, sd: 3313,
      tip: '버스는 30점! 길고 느려서 빨리 지나가게 해 주면 좋아요.' },
    { n: '건널목', lay: 0, dur: 60, rate: 0.19, bias: [1.1, 1], ped: 0.22, sd: 4409,
      tip: '사람은 나란한 찻길이 초록불일 때 건너요(+5). 너무 오래 기다리면 돌아가요(−10).' },
    { n: '구급차 출동', lay: 0, dur: 70, rate: 0.2, bias: [1, 1.05], bus: 0.08, amb: 3, sd: 5501,
      tip: '사이렌이 울리면 구급차 쪽을 초록불로! 세워 두면 −40, 한 번도 안 서면 +20.' },
    { n: '나란히 두 곳', lay: 1, dur: 70, rate: 0.17, bias: [0.9, 1.25], ped: 0.08, sd: 6607,
      tip: '가로 길 차는 두 교차로를 연달아 지나요. 초록불을 이어 주면 술술!' },
    { n: '우회전 차', lay: 2, dur: 70, rate: 0.18, bias: [1.2, 1], pr: 0.25, bus: 0.08, sd: 7703,
      tip: '오른쪽 깜빡이 차는 초록불에 오른쪽으로 돌아 나가요. 건너는 사람이 있으면 기다려요.' },
    { n: '좌회전 신호', lay: 0, dur: 70, rate: 0.18, bias: [1.1, 1], pl: 0.2, pr: 0.08, sd: 8807,
      tip: '왼쪽 깜빡이 차는 맞은편 차가 끊겨야 돌아요. 맨 앞에서 막히면 ↰ 버튼으로 좌회전 신호!' },
    { n: '비 오는 날', lay: 1, dur: 75, rate: 0.17, bias: [1, 1.15], ped: 0.1, bus: 0.1, rain: 1, sd: 9901,
      tip: '비가 오면 잘 못 멈춰요. 노란불에도 지나가는 차가 많아요. 사고 조심!' },
    { n: '도로 공사', lay: 2, dur: 75, rate: 0.19, bias: [1.15, 0.95], bus: 0.08, pr: 0.12, work: [['v', 0, 7.2, 8.6], ['h', 0, 4.1, 5.7]], sd: 11003,
      tip: '공사 구간은 아주 천천히 지나가요. 그쪽 줄이 금방 길어져요.' },
    { n: '출근길 러시아워', lay: 3, dur: 90, rate: 0.12, bias: [1.4, 0.75], amb: 2, rush: 1.5, sd: 12107,
      tip: '중간쯤 차가 확 몰려요! 큰길(↕) 초록불을 길게, 옆길은 짧게.' },
    { n: '바둑판 마을', lay: 4, dur: 90, rate: 0.13, bias: [1, 1], ped: 0.07, bus: 0.1, pr: 0.12, sd: 13201,
      tip: '교차로가 4곳! 게이지가 빨간 곳부터 급한 순서대로.' },
    { n: '비 오는 퇴근길', lay: 4, dur: 90, rate: 0.12, bias: [1.1, 1], bus: 0.1, pr: 0.1, amb: 2, rain: 1, rush: 1.5, sd: 14303,
      tip: '비 + 러시아워 + 구급차. 천천히, 하지만 꾸준히!' },
    { n: '최종: 도시 지휘관', lay: 2, dur: 100, rate: 0.135, bias: [1.15, 1], bus: 0.1, trk: 0.06, pr: 0.1, pl: 0.1, amb: 3, ped: 0.07, rush: 1.35, work: [['h', 1, 0.2, 1.8]], sd: 15401,
      tip: '좌회전·구급차·사람·러시아워 총출동. 배운 걸 다 써 봐요!' },
  ];
  // ★★ ≈ 82 % and ★★★ ≈ 95 % of the hard AI's median score on that stage
  const STAR_PAR = [[230, 270], [360, 420], [490, 570], [430, 490], [720, 840], [600, 690], [680, 780], [260, 300], [790, 920], [720, 840], [700, 810], [920, 1060], [950, 1100], [910, 1060]];

  function randParams(sd, cty) {
    const r = mkRng((sd ^ 0x2545F491) >>> 0), pick = (a) => a[Math.floor(r() * a.length)];
    const lay = cty === 0 ? pick([0, 0, 1, 2]) : cty === 1 ? pick([3, 4, 4]) : pick([0, 1, 2, 3, 4]);
    const P = { lay, sd, rate: [0.19, 0.16, 0.17, 0.14, 0.12][lay], bias: [1 + r() * 0.35, 0.8 + r() * 0.3] };
    if (r() < 0.5) P.bias.reverse();
    P.bus = r() < 0.7 ? 0.1 : 0; P.trk = r() < 0.5 ? 0.07 : 0;
    P.ped = r() < 0.55 ? 0.08 + r() * 0.06 : 0;
    P.pr = r() < 0.55 ? 0.1 : 0;
    P.pl = (lay === 0 || lay === 2) && r() < 0.35 ? 0.14 : 0;
    P.amb = Math.floor(r() * 3);
    P.rain = r() < 0.3 ? 1 : 0;
    P.rush = r() < 0.45 ? 1.4 + r() * 0.3 : 0;
    P.rate *= (P.pl ? 0.8 : 1) * (P.rush ? 0.88 : 1) * (P.rain ? 0.92 : 1) * (P.ped ? 0.95 : 1) * (P.amb > 1 ? 0.95 : 1);   // busier mixes get fewer cars
    if (r() < 0.3) { const LY = LAYS[lay]; if (r() < 0.5) { const y0 = r() < 0.5 ? 0.15 : H - 1.55; P.work = [['v', Math.floor(r() * LY.vx.length), y0, y0 + 1.4]]; } else { const x0 = r() < 0.5 ? 0.15 : W - 1.15; P.work = [['h', Math.floor(r() * LY.hy.length), x0, x0 + 1.0]]; } }
    return P;
  }

  /* ======================= town definition (roads, routes, schedule) ======================= */
  const ctr = (D, ix) => [D.vx[ix % D.nV], D.hy[(ix / D.nV) | 0]];
  const postPos = (c, d) => [c[0] - DX[d] * (SLD + 0.22) + RX(d) * (HW + 0.22), c[1] - DY[d] * (SLD + 0.22) + RY(d) * (HW + 0.22)];
  const leftBtnPos = (c) => [c[0] + 1.72, c[1] - 1.32];
  function genDef(P, dur) {
    const LY = LAYS[P.lay] || LAYS[0], nV = LY.vx.length, nH = LY.hy.length;
    const D = { P, dur, vx: LY.vx, hy: LY.hy, nV, nH, nI: nV * nH, ents: [], rc: {}, work: [], ambs: [], rain: !!P.rain, lt: !!P.pl, sd: P.sd >>> 0 };
    for (let i = 0; i < nV; i++) { D.ents.push({ d: 2, c: LY.vx[i], ax: 0 }); D.ents.push({ d: 0, c: LY.vx[i], ax: 0 }); }
    for (let j = 0; j < nH; j++) { D.ents.push({ d: 1, c: LY.hy[j], ax: 1 }); D.ents.push({ d: 3, c: LY.hy[j], ax: 1 }); }
    (P.work || []).forEach(([o, i, a, b]) => {
      if (o === 'v' && i < nV) D.work.push({ x0: LY.vx[i] - HW, x1: LY.vx[i] + HW, y0: a, y1: b, v: 1 });
      else if (o === 'h' && i < nH) D.work.push({ x0: a, x1: b, y0: LY.hy[i] - HW, y1: LY.hy[i] + HW, v: 0 });
    });
    const na = P.amb | 0;
    for (let k = 0; k < na; k++) D.ambs.push({ t: dur * (0.1 + 0.78 * (k + 0.2 + hrand(D.sd, 9000 + k) * 0.6) / na), e: Math.floor(hrand(D.sd, 9100 + k) * D.ents.length) });
    D.deco = genDeco(D);
    return D;
  }
  function genDeco(D) {
    const xs = [0], ys = [0];
    D.vx.forEach((x) => xs.push(x - HW, x + HW)); xs.push(W);
    D.hy.forEach((y) => ys.push(y - HW, y + HW)); ys.push(H);
    const r = mkRng((D.sd ^ 0x7f4a7c15) >>> 0), out = [], avoid = [];
    for (let ix = 0; ix < D.nI; ix++) { const c = ctr(D, ix); for (let d = 0; d < 4; d++) avoid.push(postPos(c, d)); if (D.lt) avoid.push(leftBtnPos(c)); }
    for (let a = 0; a < xs.length; a += 2) for (let b = 0; b < ys.length; b += 2) {
      const x0 = xs[a] + 0.17, x1 = xs[a + 1] - 0.17, y0 = ys[b] + 0.17, y1 = ys[b + 1] - 0.17;
      if (x1 - x0 < 0.3 || y1 - y0 < 0.3) continue;
      const nx = Math.max(1, Math.round((x1 - x0) / 0.8)), ny = Math.max(1, Math.round((y1 - y0) / 0.8));
      const cw = (x1 - x0) / nx, ch = (y1 - y0) / ny;
      for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) {
        const x = x0 + (i + 0.5) * cw, y = y0 + (j + 0.5) * ch;
        if (avoid.some((p) => Math.abs(p[0] - x) < (D.lt ? 0.55 : 0.4) && Math.abs(p[1] - y) < (D.lt ? 0.55 : 0.4))) { if (r() < 0.5) out.push({ k: 2, x: x + (r() - 0.5) * 0.2, y: y + (r() - 0.5) * 0.2, r: 0.08 + r() * 0.04 }); continue; }
        const u = r();
        if (u < 0.55) out.push({ k: 0, x, y, w: cw * (0.6 + r() * 0.2), h: ch * (0.6 + r() * 0.2), c: Math.floor(r() * 6), rf: r() < 0.5 ? 0 : 1 });
        else if (u < 0.9) out.push({ k: 1, x: x + (r() - 0.5) * cw * 0.3, y: y + (r() - 0.5) * ch * 0.3, r: Math.min(cw, ch) * (0.26 + r() * 0.1) });
      }
    }
    return out;
  }
  /* route = polyline from an entry (off-map) to an exit (off-map); stops = one per crossing on the way:
     {s: stop line, ix, ax (0 ↕ / 1 ↔ approach), t (0 straight, 1 right, 2 left), bo: box exit, sc: corner, se: left entry} */
  function buildRoute(D, e, tk, tt) {
    const E = D.ents[e]; let d = E.d, px, py;
    if (d === 2) { px = E.c - Q; py = -EXT; } else if (d === 0) { px = E.c + Q; py = H + EXT; }
    else if (d === 1) { px = -EXT; py = E.c + Q; } else { px = W + EXT; py = E.c - Q; }
    const pts = [px, py], st = []; let len = 0, k = 0, turned = false;
    let ref = d === 0 || d === 2 ? py : px;
    const add = (x, y) => { len += Math.hypot(x - px, y - py); pts.push(x, y); px = x; py = y; };
    const at = (x, y) => len + Math.hypot(x - px, y - py);
    for (let g = 0; g < 8; g++) {
      const vert = d === 0 || d === 2, sgn = d === 1 || d === 2 ? 1 : -1, arr = vert ? D.hy : D.vx;
      let best = -1, bc = 0;
      for (let m = 0; m < arr.length; m++) { const c = arr[m]; if ((c - ref) * sgn > 1e-6 && (best < 0 || (c - ref) * sgn < (bc - ref) * sgn)) { best = m; bc = c; } }
      if (best < 0) break;
      const rc = vert ? px - Q * RX(d) : py - Q * RY(d), others = vert ? D.vx : D.hy;
      let ri = 0; for (let m = 0; m < others.length; m++) if (Math.abs(others[m] - rc) < 0.01) ri = m;
      const i = vert ? ri : best, j = vert ? best : ri, ix = j * D.nV + i, cx0 = D.vx[i], cy0 = D.hy[j];
      const t = !turned && k === tk ? tt : 0;
      const S = { s: at(cx0 - DX[d] * SLD + Q * RX(d), cy0 - DY[d] * SLD + Q * RY(d)), ix, ax: vert ? 0 : 1, t, bo: 0, sc: 0, se: 0, d };
      if (t === 0) { S.bo = at(cx0 + DX[d] * HW + Q * RX(d), cy0 + DY[d] * HW + Q * RY(d)); ref = vert ? cy0 : cx0; }
      else if (t === 1) {
        const d2 = (d + 1) & 3;
        add(cx0 + Q * (RX(d) + RX(d2)), cy0 + Q * (RY(d) + RY(d2))); S.sc = len; S.bo = len + HW - Q;
        d = d2; ref = d === 0 || d === 2 ? py : px; turned = true;
      } else {
        const d2 = (d + 3) & 3;
        add(cx0 - DX[d] * HW + Q * RX(d), cy0 - DY[d] * HW + Q * RY(d)); S.se = len;
        add(cx0 + DX[d2] * HW + Q * RX(d2), cy0 + DY[d2] * HW + Q * RY(d2)); S.sc = len; S.bo = len;
        d = d2; ref = d === 0 || d === 2 ? py : px; turned = true;
      }
      st.push(S); k++;
    }
    if (d === 0) add(px, -EXT); else if (d === 2) add(px, H + EXT); else if (d === 1) add(W + EXT, py); else add(-EXT, py);
    const n = pts.length / 2, cum = new Float64Array(n);
    for (let m = 1; m < n; m++) cum[m] = cum[m - 1] + Math.hypot(pts[2 * m] - pts[2 * m - 2], pts[2 * m + 1] - pts[2 * m - 1]);
    return { e, pts, cum, len: cum[n - 1], st, tt: turned ? tt : 0 };
  }
  function routeOf(D, e, tk, tt) { const key = e + '.' + tk + '.' + tt; return D.rc[key] || (D.rc[key] = buildRoute(D, e, tk, tt)); }
  function rpos(ro, s, o) {
    const c = ro.cum, p = ro.pts, n = c.length;
    let k = 0; while (k < n - 2 && s > c[k + 1]) k++;
    const L0 = c[k + 1] - c[k] || 1, t = (s - c[k]) / L0, dx = p[2 * k + 2] - p[2 * k], dy = p[2 * k + 3] - p[2 * k + 1];
    o.x = p[2 * k] + dx * t; o.y = p[2 * k + 1] + dy * t; o.ux = dx / L0; o.uy = dy / L0;
    return o;
  }
  /* nearest point (by route distance) of route ro within [s0, s1] whose corridor touches an obstacle at (qx,qy)
     with heading (hx,hy) and half length / width hl, hw. Returns s or −1; out.lon = obstacle half-extent along the route */
  function projAhead(ro, s0, s1, qx, qy, hx, hy, hl, hw, myHW, out) {
    const c = ro.cum, p = ro.pts, n = c.length; let best = -1;
    for (let k = 0; k < n - 1; k++) {
      if (c[k + 1] < s0 || c[k] > s1) continue;
      const L0 = c[k + 1] - c[k]; if (L0 < 1e-6) continue;
      const ux = (p[2 * k + 2] - p[2 * k]) / L0, uy = (p[2 * k + 3] - p[2 * k + 1]) / L0;
      let t = (qx - p[2 * k]) * ux + (qy - p[2 * k + 1]) * uy;
      const a = Math.max(0, s0 - c[k]), b = Math.min(L0, s1 - c[k]);
      if (t < a) { if (c[k] <= s0 && t < a - 0.02) continue; t = a; }   // beside / behind me: not in my way
      else if (t > b) t = b;
      const ex = p[2 * k] + ux * t - qx, ey = p[2 * k + 1] + uy * t - qy, dd = Math.sqrt(ex * ex + ey * ey);
      const cs = hx * ux + hy * uy, ac = Math.abs(cs), sn = Math.sqrt(Math.max(0, 1 - ac * ac));
      if (dd > myHW + hl * sn + hw * ac + 0.02) continue;
      const s = c[k] + t;
      if (best < 0 || s < best) { best = s; out.lon = hl * ac + hw * sn; out.cs = cs; }
    }
    return best;
  }
  function rushK(D, t) {
    const k = D.P.rush; if (!k) return 1;
    const f = t / D.dur, b = f < 0.3 ? 0 : f < 0.45 ? (f - 0.3) / 0.15 : f < 0.7 ? 1 : f < 0.85 ? 1 - (f - 0.7) / 0.15 : 0;
    return 1 + (k - 1) * b;
  }
  function rateAt(D, e, t) { const P = D.P; return P.rate * (P.bias ? P.bias[D.ents[e].ax] : 1) * rushK(D, t); }
  function specOf(D, e, k) {
    const P = D.P, h = (m) => hrand(D.sd, ((e * 4096 + k) * 8 + m) >>> 0);
    const u = h(0), ty = u < (P.bus || 0) ? 1 : u < (P.bus || 0) + (P.trk || 0) ? 2 : 0;
    const v = h(1), nc = D.ents[e].ax === 0 ? D.nH : D.nV;
    let tt = 0; if (v < (P.pr || 0)) tt = 1; else if (v < (P.pr || 0) + (P.pl || 0)) tt = 2;
    return [ty, tt ? Math.floor(h(2) * nc) : -1, tt, Math.floor(h(3) * PALETTE.length)];
  }
  function gapOf(D, e, k, t) { const u = hrand(D.sd, ((e * 4096 + k) * 8 + 5) >>> 0); return Math.max(0.8, -Math.log(1 - u * 0.995) / Math.max(0.01, rateAt(D, e, t))); }
  function potential(D) {   // points if every scheduled vehicle/pedestrian got through (used for the random-town star targets)
    let p = 0; const P = D.P;
    for (let e = 0; e < D.ents.length; e++) { let t = 0.3 + hrand(D.sd, 70000 + e) * 2.2, k = 0; while (t < D.dur - 3) { p += VT[specOf(D, e, k)[0]].pts; t += gapOf(D, e, k, t); k++; } }
    p += D.ambs.filter((a) => a.t < D.dur - 3).length * (VT[3].pts + PTS_AMB_OK);
    if (P.ped) p += P.ped * D.dur * D.nI * PTS_PED * 0.85;
    return p;
  }

  /* ======================= board simulation (one per player) ======================= */
  function newBoard(D) {
    const B = { D, t: 0, ph: 1, sc: 0, hp: D.P.hp || HEARTS, ps: 0, cr: 0, rn: 0, pp: 0, lc: -9, V: [], P: [], L: [], nx: [], kk: [], bl: [], le: [],
      pn: [], pk: [], ai: 0, vid: 1, pid: 1, ev: [], lost: 0 };
    const ax0 = D.P.bias && D.P.bias[1] > D.P.bias[0] ? 1 : 0;
    for (let ix = 0; ix < D.nI; ix++) B.L.push({ ph: ax0, st: 0, t: 0, nx: 0, g: 0 });
    for (let e = 0; e < D.ents.length; e++) { B.nx.push(0.3 + hrand(D.sd, 70000 + e) * 2.2); B.kk.push(0); B.bl.push([]); B.le.push(null); }
    for (let ix = 0; ix < D.nI; ix++) { B.pn.push(D.P.ped ? 1 + hrand(D.sd, 80000 + ix) * 3 : 1e9); B.pk.push(0); }
    return B;
  }
  const addSc = (B, n) => { B.sc = Math.max(0, B.sc + n); };
  function lightOK(B, S) { const g = B.L[S.ix]; if (g.st !== 0) return false; return S.t === 2 ? g.ph === S.ax + 2 : g.ph === S.ax; }
  function toggleB(B, ix) {   // straight green flips ↕ ↔ (from a left arrow: straight for the same axis)
    if (B.ph !== 1) return 'over';
    const g = B.L[ix]; if (!g) return 'out';
    if (g.st !== 0) return 'busy';
    g.st = 1; g.t = YEL; g.nx = g.ph >= 2 ? g.ph - 2 : 1 - g.ph; B.ev.push({ k: 'light', ix });
    return 'ok';
  }
  function frontLeft(B, ix) {   // axis (0/1) whose front car is a left-turner waiting at the line (−1 = none)
    let best = -1, bw = -1;
    for (const a of B.V) {
      if (a.cr > 0 || a.si >= a.ro.st.length) continue;
      const S = a.ro.st[a.si];
      if (S.ix !== ix || S.t !== 2 || a.v > 0.3 || S.s - (a.s + VT[a.ty].len / 2) > 0.5) continue;
      if (a.w > bw) { bw = a.w; best = S.ax; }
    }
    return best;
  }
  function leftB(B, ix) {   // ↰: protected left arrow for the axis whose front car wants to turn left
    if (B.ph !== 1) return 'over';
    const g = B.L[ix]; if (!g) return 'out';
    if (!B.D.lt) return 'nolt';
    if (g.st !== 0) return 'busy';
    const ax = frontLeft(B, ix);
    if (ax < 0) return 'none';
    if (g.ph === ax + 2) return 'already';
    g.st = 1; g.t = YEL; g.nx = ax + 2; B.ev.push({ k: 'light', ix, l: 1 });
    return 'ok';
  }
  const TP = { x: 0, y: 0, ux: 0, uy: 0 }, TMPO = { lon: 0, cs: 0 }, PP = { x: 0, y: 0, hx: 0, hy: 0 };
  function setPos(a) {
    rpos(a.ro, a.s, TP); a.x = TP.x; a.y = TP.y; a.hx = TP.ux; a.hy = TP.uy;
    const T = VT[a.ty]; for (let k = 0; k < T.off.length; k++) { rpos(a.ro, a.s + T.off[k], TP); a.cc[2 * k] = TP.x; a.cc[2 * k + 1] = TP.y; }   // body circles follow the path (bent at corners)
  }
  function inWork(D, x, y) { for (const z of D.work) if (x > z.x0 && x < z.x1 && y > z.y0 && y < z.y1) return true; return false; }
  function pedPos(D, p, o) {
    const c = ctr(D, p.a >> 2), arm = p.a & 3, mx = c[0] + DX[arm] * (HW + CW / 2), my = c[1] + DY[arm] * (HW + CW / 2);
    const ux = RX(arm), uy = RY(arm), e = HW + 0.14, t = p.p < 0 ? 0 : p.p, f = p.sd * e * (1 - 2 * t);
    o.x = mx + ux * f; o.y = my + uy * f; o.hx = -ux * p.sd; o.hy = -uy * p.sd; return o;
  }
  function spawnTick(B) {
    const D = B.D;
    for (let e = 0; e < D.ents.length; e++) {
      let guard = 0;
      while (B.t >= B.nx[e] && guard++ < 4) { const k = B.kk[e]++; B.bl[e].push(specOf(D, e, k)); B.nx[e] += gapOf(D, e, k, B.nx[e]); }
      while (B.bl[e].length > 6) { B.bl[e].pop(); addSc(B, -PTS_LOST); B.lost++; B.ev.push({ k: 'lost', e }); }
    }
    while (B.ai < D.ambs.length && B.t >= D.ambs[B.ai].t) { const A = D.ambs[B.ai++]; B.bl[A.e].unshift([3, -1, 0, 0]); }
    for (let e = 0; e < D.ents.length; e++) {
      if (!B.bl[e].length) continue;
      const sp = B.bl[e][0], T = VT[sp[0]], last = B.le[e];
      if (last && !last.gone && last.s - VT[last.ty].len / 2 - T.len / 2 < 0.3) continue;
      B.bl[e].shift();
      const v0 = T.v0 * (D.rain ? 0.85 : 1);
      const a = { id: B.vid++, ty: sp[0], ro: routeOf(D, e, sp[1], sp[2]), s: 0, v: last && !last.gone ? Math.min(v0 * 0.9, last.v + 0.2) : v0 * 0.9, w: 0, an: 0, sr: 0, si: 0, dc: 0, cr: 0, stp: 0,
        col: sp[3], x: 0, y: 0, hx: 0, hy: 0, lg: 99, lj: -1, lv: 0, ls: 0, cc: new Float32Array(8), gone: false, e, cap: 1e9, gh: 0, ght: 0 };
      setPos(a); B.V.push(a); B.le[e] = a;
      if (a.ty === 3) B.ev.push({ k: 'amb', e });
    }
  }
  function pri(a) {
    let p = a.v > 0.3 ? 1 : 0;
    if (a.dc === 1) p += 2;
    else if (a.si > 0) { const S = a.ro.st[a.si - 1]; if (a.s - VT[a.ty].len / 2 < S.bo) p += 2; }
    return p;
  }
  const TQ = { x: 0, y: 0, ux: 0, uy: 0 };
  function seen(a, g, j, lv, ls) {   // keep the nearest and the second-nearest obstacle (from a different car)
    if (g < a.lg) {
      if (a.lj !== j) { a.lg2 = a.lg; a.lj2 = a.lj; a.lv2 = a.lv; a.ls2 = a.ls; }
      a.lg = g; a.lj = j; a.lv = lv; a.ls = ls;
    } else if (j !== a.lj && g < a.lg2) { a.lg2 = g; a.lj2 = j; a.lv2 = lv; a.ls2 = ls; }
  }
  function leaders(B) {
    const V = B.V, n = V.length, D = B.D;
    for (let i = 0; i < n; i++) {   // how far may each car get in the next second? (it stops at its own red line)
      const b = V[i]; b.cap = 1e9;
      if (b.cr > 0 || b.si >= b.ro.st.length) continue;
      const S = b.ro.st[b.si];
      if (!(lightOK(B, S) || b.an || b.sr || b.dc === 1)) b.cap = S.s - VT[b.ty].len / 2 - 0.02;
    }
    for (let i = 0; i < n; i++) {
      const a = V[i]; a.lg = 99; a.lj = -1; a.lv = 0; a.ls = 0; a.lg2 = 99; a.lj2 = -1; a.lv2 = 0; a.ls2 = 0;
      if (a.cr > 0) continue;
      const Ta = VT[a.ty], hw = Ta.wid / 2, front = a.s + Ta.len / 2;
      for (let j = 0; j < n; j++) {
        if (j === i) continue;
        const b = V[j];
        if (Math.abs(b.x - a.x) > LOOK + 0.6 || Math.abs(b.y - a.y) > LOOK + 0.6) continue;
        if (a.an && !(b.cr > 0) && Math.abs(a.hx * b.hx + a.hy * b.hy) < 0.7) continue;   // an angry driver doesn't look sideways
        const late = b.an && !a.an && Math.abs(a.hx * b.hx + a.hy * b.hy) < 0.7;   // a red-light runner is seen only at the last moment
        const Tb = VT[b.ty];
        let bs = 1e9, bcs = 1;
        for (let k = 0; k < Tb.off.length; k++) {   // nearest of the obstacle's body circles along my path
          const s = projAhead(a.ro, a.s, a.s + LOOK, b.cc[2 * k], b.cc[2 * k + 1], b.hx, b.hy, Tb.r, Tb.r * 0.75, hw, TMPO);
          if (s >= 0 && s - TMPO.lon < bs) { bs = s - TMPO.lon; bcs = TMPO.cs; }
        }
        if (bs > 1e8 || (late && bs - front > 0.3)) continue;
        seen(a, bs - front, j, b.cr > 0 ? 0 : b.v * bcs, bs);
      }
      if (!a.an) for (let j = 0; j < n; j++) {   // look out for cars about to cross my path (not just those already on it)
        const b = V[j];
        if (j === i || b.cr > 0 || b.v < 0.25 || b.an || Math.abs(a.hx * b.hx + a.hy * b.hy) > 0.7) continue;   // nobody expects a red-light runner
        if (Math.abs(b.x - a.x) > LOOK + 1.6 || Math.abs(b.y - a.y) > LOOK + 1.6) continue;
        const Tb = VT[b.ty];
        for (let k = 1; k <= 2; k++) {
          const sp = Math.min(b.s + b.v * 0.5 * k, b.cap);
          if (sp < b.s + 0.05) break;
          rpos(b.ro, sp, TQ);
          const s = projAhead(a.ro, a.s, a.s + LOOK, TQ.x, TQ.y, TQ.ux, TQ.uy, Tb.len / 2, Tb.wid / 2, hw, TMPO);
          if (s < 0) continue;
          const g = s - TMPO.lon - front;
          seen(a, g, j, 0, s - TMPO.lon);
          break;
        }
      }
      for (let j = 0; j < B.P.length; j++) {
        const p = B.P[j]; if (p.p < 0) continue;
        pedPos(D, p, PP);
        if (Math.abs(PP.x - a.x) > LOOK + 0.4 || Math.abs(PP.y - a.y) > LOOK + 0.4) continue;
        const s = projAhead(a.ro, a.s, a.s + LOOK, PP.x, PP.y, PP.hx, PP.hy, 0.1, 0.1, hw, TMPO);
        if (s < 0) continue;
        const g = s - TMPO.lon - front;
        seen(a, g, -2 - j, 0, s - TMPO.lon);
      }
    }
    for (let i = 0; i < n; i++) {   // two drivers waiting for each other: the one already in the crossing goes first
      const a = V[i]; if (a.lj < 0) continue;
      const b = V[a.lj]; if (b.lj !== i) continue;
      const pa = pri(a), pb = pri(b);
      if (pa > pb || (pa === pb && a.id < b.id)) {
        if (a.lg < 0.08 && b.lg < 0.08) { a.gh = b.id; b.gh = a.id; a.ght = b.ght = 1.5; }   // truly tangled: squeeze past each other
        a.lg = a.lg2; a.lj = a.lj2; a.lv = a.lv2; a.ls = a.ls2;   // the winner still watches everything else
      }
    }
  }
  /* 비보호 좌회전: on a straight green a left-turner may go when no oncoming car is close (oncoming left-turners don't count) */
  function gapOK(B, me, S) {
    const od = (S.d + 2) & 3;
    for (const b of B.V) {
      if (b === me || b.cr > 0) continue;
      const sts = b.ro.st;
      if (b.si < sts.length) {
        const S2 = sts[b.si];
        if (S2.ix === S.ix && S2.d === od && S2.t !== 2) { const d2 = S2.s - (b.s + VT[b.ty].len / 2); if (d2 < 2.4 && (b.v > 0.2 || d2 < 0.6)) return false; }
      }
      if (b.si > 0) { const P = sts[b.si - 1]; if (P.ix === S.ix && P.d === od && P.t !== 2 && b.s - VT[b.ty].len / 2 < P.bo) return false; }
    }
    return true;
  }
  function idm(v, v0, a, b, g, dv) {
    const ss = S0 + Math.max(0, v * THW + v * dv / (2 * Math.sqrt(a * b)));
    const gg = Math.max(0.001, g);
    return a * (1 - Math.pow(v / v0, 4) - (ss / gg) * (ss / gg));
  }
  function stepV(B, dt) {
    const D = B.D, rain = D.rain, bc = rain ? 1.3 : 2.2, bmax = rain ? 2.6 : 4.8, V = B.V;
    for (let i = 0; i < V.length; i++) {
      const a = V[i];
      if (a.ght > 0) a.ght -= dt;
      if (a.cr > 0) continue;
      const T = VT[a.ty], hl = T.len / 2, sts = a.ro.st;
      let v0 = T.v0 * (rain ? 0.85 : 1) * (a.an ? 1.2 : 1);
      if (D.work.length && inWork(D, a.x, a.y)) v0 *= 0.42;
      const st = a.si < sts.length ? sts[a.si] : null, ps = a.si > 0 ? sts[a.si - 1] : null;
      for (const S of [st, ps]) if (S && S.t) { const from = (S.t === 1 ? S.sc : S.se) - 0.85, to = S.sc + 0.25; if (a.s > from && a.s < to) v0 = Math.min(v0, 0.8); }
      const A0 = a.an ? T.a * 1.6 : T.a;
      let acc = Math.max(-bc, A0 * (1 - Math.pow(a.v / v0, 4)));
      if (a.lg < 90) acc = Math.min(acc, idm(a.v, v0, A0, bc, a.lg, a.v - a.lv));
      if (st) {
        const dist = st.s - (a.s + hl);
        let lok = lightOK(B, st);
        if (!lok && st.t === 2 && dist < 1.2 && B.L[st.ix].st === 0 && B.L[st.ix].ph === st.ax && gapOK(B, a, st)) lok = true;   // permissive left
        if (lok && a.dc === -1) a.dc = 0;
        let go = lok || a.an || a.sr || a.dc === 1;
        if (!go && a.dc === 0 && dist < LOOK + 1) {
          const need = a.v * a.v / (2 * bc);
          if (a.v > 0.3 && dist < need * 0.9) { a.dc = 1; go = true; } else a.dc = -1;
        }
        if (go && lok && a.dc !== 1 && !a.an && !a.sr && dist > 0.02 && a.lg < 90 && a.ls >= st.bo - 0.05 && a.lv < 0.35 && a.ls - st.bo < T.len + 0.12) go = false;   // don't block the box
        if (!go && dist < LOOK + 1) acc = Math.min(acc, idm(a.v, v0, T.a, bc, dist, a.v));
        // impatience
        if (a.v < 0.25 && dist < 4.5 && a.dc !== 1) {
          a.w += dt / T.pat;
          if (a.ty === 3) a.stp = 1;
          if (a.w >= 1) {
            a.w = 1;
            if (a.ty === 3) { if (!a.sr) { a.sr = 1; addSc(B, -PTS_AMB_LATE); B.ev.push({ k: 'ambLate', x: a.x, y: a.y }); } }
            else if (!a.an) { a.an = 1; B.ev.push({ k: 'angry', x: a.x, y: a.y, id: a.id }); }
          }
        } else if (a.v > 0.4) a.w = Math.max(0, a.w - dt * 0.08);
      }
      acc = Math.max(-bmax, Math.min(A0, acc));
      a.v = Math.max(0, a.v + acc * dt);
      a.s += a.v * dt;
      setPos(a);
      if (st && a.s + hl >= st.s) {   // front crossed the stop line
        if (a.an && !a.sr && a.dc !== 1 && !lightOK(B, st)) { addSc(B, -PTS_RUN); B.rn++; B.ev.push({ k: 'run', x: a.x, y: a.y }); }
        a.si++; a.dc = 0; a.w = 0;
      }
      if (a.an && a.si > 0 && a.s - hl > sts[a.si - 1].bo) { a.an = 0; a.w = 0; }   // the red-light runner calms down once through the crossing
      if (a.s >= a.ro.len - 0.05) {
        a.gone = true;
        let p = T.pts; if (a.ty === 3 && !a.stp) p += PTS_AMB_OK;
        addSc(B, p); B.ps++;
        B.ev.push({ k: 'pass', x: U.clamp(a.x, 0.15, W - 0.15), y: U.clamp(a.y, 0.15, H - 0.15), p, ty: a.ty, ok: a.ty === 3 && !a.stp });
      }
    }
  }
  function crashes(B) {
    const V = B.V, n = V.length;
    for (let i = 0; i < n; i++) {
      const a = V[i]; if (a.gone) continue;
      for (let j = i + 1; j < n; j++) {
        const b = V[j]; if (b.gone || (a.cr > 0 && b.cr > 0) || (a.ght > 0 && a.gh === b.id) || (b.ght > 0 && b.gh === a.id)) continue;
        if (Math.abs(a.x - b.x) > 1.1 || Math.abs(a.y - b.y) > 1.1) continue;
        const Ta = VT[a.ty], Tb = VT[b.ty], lim = Ta.r + Tb.r - 0.035, l2 = lim * lim;
        let hit = false;
        for (let k = 0; k < Ta.off.length && !hit; k++) for (let m = 0; m < Tb.off.length; m++) {
          const dx = a.cc[2 * k] - b.cc[2 * m], dy = a.cc[2 * k + 1] - b.cc[2 * m + 1];
          if (dx * dx + dy * dy < l2) { hit = true; break; }
        }
        if (hit) crash(B, a, b);
      }
    }
  }
  function crash(B, a, b) {
    const fresh = !(a.cr > 0) || !(b.cr > 0);
    if (!(a.cr > 0)) { a.cr = CRASH_T; a.v = 0; a.an = 0; }
    if (!(b.cr > 0)) { b.cr = CRASH_T; b.v = 0; b.an = 0; }
    if (!fresh) return;
    const x = (a.x + b.x) / 2, y = (a.y + b.y) / 2;
    if (B.t - B.lc > 1.0) {
      B.lc = B.t; B.hp--; B.cr++; addSc(B, -PTS_CRASH);
      B.ev.push({ k: 'crash', x, y, hp: B.hp });
      if (B.hp <= 0) { B.hp = 0; B.ph = 2; B.ev.push({ k: 'fail' }); }
    } else B.ev.push({ k: 'bump', x, y });
  }
  function pedsTick(B, dt) {
    const D = B.D;
    if (D.P.ped) for (let ix = 0; ix < D.nI; ix++) {
      while (B.t >= B.pn[ix]) {
        const k = B.pk[ix]++, h = (m) => hrand(D.sd, ((ix * 4096 + k) * 8 + m + 300000) >>> 0);
        const arm = Math.floor(h(0) * 4), sd = h(1) < 0.5 ? -1 : 1, a = ix * 4 + arm;
        let same = 0; for (const p of B.P) if (p.a === a && p.sd === sd && p.p < 0) same++;
        if (same < 3) B.P.push({ id: B.pid++, a, sd, p: -1, w: 0, c: Math.floor(h(2) * PALETTE.length), q: same });
        B.pn[ix] += Math.max(1.2, -Math.log(1 - h(3) * 0.995) / D.P.ped);
      }
    }
    for (let i = B.P.length - 1; i >= 0; i--) {
      const p = B.P[i], g = B.L[p.a >> 2], arm = p.a & 3, wax = arm & 1 ? 0 : 1;
      if (p.p < 0) {
        if (g.st === 0 && g.ph === wax && !carOnCw(B, p)) { p.p = 0; B.ev.push({ k: 'walk', a: p.a }); }
        else {
          p.w += dt / PED_PAT;
          if (p.w >= 1) { pedPos(D, p, PP); B.P.splice(i, 1); addSc(B, -PTS_PEDQ); B.ev.push({ k: 'pedq', x: PP.x, y: PP.y }); continue; }
        }
      } else {
        p.p += dt * PED_V / (2 * (HW + 0.14));
        if (p.p >= 1) { pedPos(D, p, PP); B.P.splice(i, 1); addSc(B, PTS_PED); B.pp++; B.ev.push({ k: 'ped', x: PP.x, y: PP.y }); }
      }
    }
    // keep each corner's waiting line packed (q = place in the line, for drawing)
    const cnt = {};
    for (const p of B.P) if (p.p < 0) { const k = p.a * 2 + (p.sd > 0 ? 1 : 0); p.q = cnt[k] || 0; cnt[k] = p.q + 1; }
  }
  function carOnCw(B, p) {
    const c = ctr(B.D, p.a >> 2), arm = p.a & 3, mx = c[0] + DX[arm] * (HW + CW / 2), my = c[1] + DY[arm] * (HW + CW / 2);
    for (const a of B.V) {
      const dx = a.x - mx, dy = a.y - my, along = dx * DX[arm] + dy * DY[arm], across = dx * RX(arm) + dy * RY(arm);
      if (Math.abs(along) < CW / 2 + VT[a.ty].len / 2 && Math.abs(across) < HW + 0.05) return true;
    }
    return false;
  }
  function stepB(B, dt) {
    if (B.ph !== 1) return;
    B.t += dt;
    for (const g of B.L) {
      if (g.st === 0) g.g += dt;
      else { g.t -= dt; if (g.t <= 0) { if (g.st === 1) { g.st = 2; g.t = ALLR; } else { g.st = 0; g.ph = g.nx; g.g = 0; } } }
    }
    spawnTick(B);
    leaders(B);
    stepV(B, dt);
    crashes(B);
    for (const a of B.V) if (a.cr > 0 && !a.gone) { a.cr -= dt; if (a.cr <= 0) { a.gone = true; B.ev.push({ k: 'tow', x: a.x, y: a.y }); } }
    if (B.V.some((a) => a.gone)) B.V = B.V.filter((a) => !a.gone);
    pedsTick(B, dt);
    if (B.ph === 1 && B.t >= B.D.dur - 1e-6) { B.ph = 3; B.ev.push({ k: 'end' }); }
  }
  // per crossing & axis: queue, weighted waiting, worst gauge, moving arrivals, ambulance, left-turner at the front
  function analyze(B) {
    const D = B.D, n = D.nI * 2;
    const A = { q: new Float32Array(n), ws: new Float32Array(n), wm: new Float32Array(n), mv: new Float32Array(n), ab: new Uint8Array(n), fl: new Float32Array(n), lq: new Float32Array(n), pw: new Float32Array(n), an: new Uint8Array(n), fb: new Uint8Array(n), lm: new Uint8Array(n) };
    for (const a of B.V) {
      if (a.cr > 0 || a.si >= a.ro.st.length) continue;
      const S = a.ro.st[a.si], k = S.ix * 2 + S.ax, dist = S.s - (a.s + VT[a.ty].len / 2);
      if (dist > 4.2) continue;
      if (a.ty === 3) A.ab[k] = 1;
      if (a.an) A.an[k] = 1;
      if (a.v < 0.3) {
        A.q[k]++; A.ws[k] += (1 + 4 * a.w * a.w) * (a.ty === 1 ? 2 : 1); A.wm[k] = Math.max(A.wm[k], a.w);
        if (S.t === 2) { A.lq[k]++; if (dist < 0.45) A.fl[k] = Math.max(A.fl[k], 0.01 + a.w); }
        if (dist < 0.45 && lightOK(B, S)) A.fb[k] = 1;   // green but the front car can't go (box blocked / left-turner / people)
      } else if (dist < 2.6) { A.mv[k] += a.ty === 1 ? 2 : 1; if (S.t === 2) { A.lq[k]++; A.lm[k] = 1; } }
    }
    for (const p of B.P) if (p.p < 0) { const arm = p.a & 3; A.pw[(p.a >> 2) * 2 + (arm & 1 ? 0 : 1)] += 1 + p.w; }
    return A;
  }

  /* ======================= AI (per level) ======================= */
  const AIP = [null,
    { dt: 2.1, k: 1.7, h: 3.5, urg: 0.93, minG: 4.5, slip: 0.35, oops: 0.05, amb: 0, idle: 3, stuck: 0 },
    { dt: 1.35, k: 1.15, h: 1.5, urg: 0.8, minG: 2.6, slip: 0.15, oops: 0, amb: 1, idle: 1.2, stuck: 4.5 },
    { dt: 0.4, k: 1.05, h: 1.4, urg: 0.8, minG: 2.4, slip: 0, oops: 0, amb: 1, idle: 0.7, stuck: 1.6 },
  ];
  function aiInit(lv, seed) { return { lv: U.clamp(lv | 0, 1, 3), r: mkRng(seed), t: 0.6 }; }
  function aiThink(B, A, dt) {
    if (B.ph !== 1) return;
    A.t -= dt; if (A.t > 0) return;
    const P = AIP[A.lv];
    A.t = P.dt * (0.8 + A.r() * 0.45);
    const D = B.D, S = analyze(B);
    if (P.oops && A.r() < P.oops) { toggleB(B, Math.floor(A.r() * D.nI)); return; }
    for (let ix = 0; ix < D.nI; ix++) {
      if (P.slip && A.r() < P.slip) continue;
      const g = B.L[ix]; if (g.st !== 0) continue;
      if (g.ph >= 2) {   // left arrow on: straight again once the left-turners are gone
        const a = g.ph - 2;
        const k = ix * 2 + a;
        if ((!S.fl[k] && !S.lm[k] && g.g > 0.7) || g.g > 5) toggleB(B, ix);
        continue;
      }
      const G = g.ph, R = 1 - G, kg = ix * 2 + G, kr = ix * 2 + R;
      // lv3 / lv2: a crowded green that cannot move (box blocked downstream) is worth nothing
      const stuck = P.stuck && g.g > P.stuck && S.q[kg] > 0 && S.mv[kg] === 0 && (A.lv < 3 || S.fb[kg]);
      const urgent = S.wm[kr] > P.urg || (A.lv >= 2 && S.an[kr]) || (A.lv === 3 && S.wm[kr] > 0.62 && S.mv[kg] === 0);
      if (D.lt && S.fl[kg] > (A.lv === 1 ? 0.5 : A.lv === 2 ? 0.32 : 0.22) && !urgent) { leftB(B, ix); continue; }
      if (P.amb && S.ab[kg] && S.wm[kr] < 0.9) continue;   // let the ambulance through first
      const pR = S.ws[kr] + 0.5 * S.pw[kr] + (P.amb && S.ab[kr] ? 25 : 0);
      const pG = stuck ? 0 : S.mv[kg] * 1.3 + S.ws[kg] * 0.5 + 0.3 * S.pw[kg] + (P.amb && S.ab[kg] ? 25 : 0);
      let go = false;
      if (urgent && g.g >= 1) go = true;
      else if (P.amb && S.ab[kr] && !S.ab[kg] && g.g >= 0.8) go = true;
      else if (g.g >= P.minG && pR > pG * P.k + P.h) go = true;
      else if (S.mv[kg] === 0 && (S.q[kg] === 0 || stuck) && pR > 0 && g.g >= P.idle) go = true;
      if (go) {
        if (D.lt && A.lv >= 2 && S.fl[kr] > 0.3 && !S.ab[kr]) leftB(B, ix);   // the red side is blocked by a left-turner: give the arrow first
        else toggleB(B, ix);
      }
    }
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    return {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      cty: [0, 1].includes(o.city) ? o.city : -1, dur: [60, 90, 120].includes(o.time) ? o.time : 90,
      ph: n === 1 ? 'pick' : 'play', sd: 1 + U.rand(2147483646), stg: -1, res: null,
    };
  }
  function startStage(s, id, rnd) {
    const r = rnd || Math.random;
    if (id >= 0 && id < STAGES.length) return Object.assign({}, s, { ph: 'play', stg: id, sd: STAGES[id].sd });
    return Object.assign({}, s, { ph: 'play', stg: 1000, sd: 1 + Math.floor(r() * 2147483646) });
  }
  function paramsOf(st) { return st.stg >= 0 && st.stg < STAGES.length ? STAGES[st.stg] : randParams(st.sd, st.cty); }
  const durOf = (st) => (st.stg >= 0 && st.stg < STAGES.length ? STAGES[st.stg].dur : st.dur || 90);
  const DEFS = {};
  function defOf(st) { const k = st.sd + '.' + st.stg + '.' + st.cty + '.' + durOf(st); return DEFS[k] || (DEFS[k] = genDef(paramsOf(st), durOf(st))); }
  function finish(s, rows) {   // rows: [seat, score, hearts, passed, crashes, f (0 playing, 1 traffic jam/out of hearts, 2 made it to the end)]
    const res = rows.slice().sort((a, b) => b[1] - a[1] || b[2] - a[2] || b[3] - a[3] || a[0] - b[0]);
    return Object.assign({}, s, { ph: 'done', res });
  }
  const randPar = (D) => { const p = potential(D); return [Math.round(p * 0.62 / 10) * 10, Math.round(p * 0.8 / 10) * 10]; };
  function parOf(s) { if (s.stg >= 0 && s.stg < STAGES.length) return STAR_PAR[s.stg]; return randPar(defOf(s)); }
  function starsOf(s, sc, f) { if (f !== 2) return 0; const p = parOf(s); return 1 + (sc >= p[0] ? 1 : 0) + (sc >= p[1] ? 1 : 0); }
  const boardName = (s) => (s.stg >= 0 && s.stg < STAGES.length ? (s.stg + 1) + '. ' + STAGES[s.stg].n : (s.n === 1 ? '무작위 마을 · ' : '') + (LAYS[defOf(s).P.lay] || LAYS[0]).nm);
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    if (s.n === 1) {
      const r = s.res[0], n = starsOf(s, r[1], r[5]), p = parOf(s);
      return { winners: n > 0 ? [r[0]] : [], title: n ? '별 ' + n + '개!' : '교통 마비…',
        text: boardName(s) + '\n' + '★'.repeat(n) + '☆'.repeat(3 - n) + '  ' + r[1] + '점\n통과 ' + r[3] + '대 · 사고 ' + r[4] + '번 · 남은 ♥ ' + r[2] +
          '\n별 기준: ★ 끝까지 버티기 · ★★ ' + p[0] + '점 · ★★★ ' + p[1] + '점' };
    }
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = s.res.map((r) => (1 + s.res.filter((q) => q[1] > r[1]).length) + '위  ' + nm(r[0]) + '  ' + r[1] + '점 · 통과 ' + r[3] + '대' + (r[4] ? ' · 사고 ' + r[4] : '') + (r[5] === 1 ? ' · 마비' : ''));
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: boardName(s) + '\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const C_GREEN = '#4fe08a', C_YEL = '#ffc93a', C_RED = '#ff4d3d';
  const HOUSE = [['#d9725a', '#b65440'], ['#5b8fd1', '#416fae'], ['#e3b04b', '#c08f2c'], ['#8f6fc4', '#6f50a3'], ['#4fae8f', '#358b6f'], ['#d07aa0', '#ad5a80']];
  const SKIN = ['#f1c9a5', '#e0ac7e', '#c68b5e', '#f5d6b8'];
  function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
  function circ(g, x, y, r) { g.beginPath(); g.arc(x, y, Math.max(0.01, r), 0, TAU); }
  function shade(hex, k) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, gg = (n >> 8) & 255, b = n & 255;
    if (k < 0) { r *= 1 + k; gg *= 1 + k; b *= 1 + k; } else { r += (255 - r) * k; gg += (255 - gg) * k; b += (255 - b) * k; }
    return 'rgb(' + (r | 0) + ',' + (gg | 0) + ',' + (b | 0) + ')';
  }
  const SHADE = {};
  const shadeC = (hex, k) => SHADE[hex + k] || (SHADE[hex + k] = shade(hex, k));
  /* the town's static picture: grass, blocks, houses, roads, markings, crosswalks, roadwork */
  function paintTown(g, D, x0, y0, s) {
    const X = (x) => x0 + x * s, Y = (y) => y0 + y * s;
    const r = mkRng((D.sd ^ 0x1234567) >>> 0);
    g.fillStyle = '#5c9a53'; g.fillRect(X(0), Y(0), W * s, H * s);
    for (let i = 0; i < W * 2; i++) for (let j = 0; j < H * 2; j++) if ((i + j) & 1) { g.fillStyle = 'rgba(255,255,255,.035)'; g.fillRect(X(i / 2), Y(j / 2), s / 2, s / 2); }
    for (let i = 0; i < 70; i++) { g.fillStyle = r() < 0.5 ? 'rgba(30,70,30,.18)' : 'rgba(170,220,120,.16)'; circ(g, X(r() * W), Y(r() * H), s * (0.02 + r() * 0.03)); g.fill(); }
    // sidewalks
    g.fillStyle = '#cdc2aa';
    D.vx.forEach((x) => g.fillRect(X(x - HW - 0.12), Y(0), s * (1 + 0.24), H * s));
    D.hy.forEach((y) => g.fillRect(X(0), Y(y - HW - 0.12), W * s, s * (1 + 0.24)));
    g.strokeStyle = 'rgba(0,0,0,.12)'; g.lineWidth = 1;
    D.vx.forEach((x) => { for (let y = 0; y < H; y += 0.33) { g.beginPath(); g.moveTo(X(x - HW - 0.12), Y(y)); g.lineTo(X(x - HW), Y(y)); g.moveTo(X(x + HW), Y(y)); g.lineTo(X(x + HW + 0.12), Y(y)); g.stroke(); } });
    D.hy.forEach((y) => { for (let x = 0; x < W; x += 0.33) { g.beginPath(); g.moveTo(X(x), Y(y - HW - 0.12)); g.lineTo(X(x), Y(y - HW)); g.moveTo(X(x), Y(y + HW)); g.lineTo(X(x), Y(y + HW + 0.12)); g.stroke(); } });
    // asphalt
    g.fillStyle = D.rain ? '#373a43' : '#42454e';
    D.vx.forEach((x) => g.fillRect(X(x - HW), Y(0), s, H * s));
    D.hy.forEach((y) => g.fillRect(X(0), Y(y - HW), W * s, s));
    for (let i = 0; i < 220; i++) { g.fillStyle = r() < 0.5 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.08)'; const vert = r() < 0.5; if (vert && D.vx.length) { const x = D.vx[Math.floor(r() * D.vx.length)]; g.fillRect(X(x - HW + r()), Y(r() * H), 1.5, 1.5); } else { const y = D.hy[Math.floor(r() * D.hy.length)]; g.fillRect(X(r() * W), Y(y - HW + r()), 1.5, 1.5); } }
    if (D.rain) for (let i = 0; i < 14; i++) { const vert = r() < 0.5; let cx, cy; if (vert) { cx = D.vx[Math.floor(r() * D.vx.length)] + (r() - 0.5) * 0.7; cy = r() * H; } else { cx = r() * W; cy = D.hy[Math.floor(r() * D.hy.length)] + (r() - 0.5) * 0.7; } g.fillStyle = 'rgba(140,170,210,.16)'; g.beginPath(); g.ellipse(X(cx), Y(cy), s * (0.12 + r() * 0.12), s * (0.06 + r() * 0.05), r() * 3, 0, TAU); g.fill(); }
    // centre lines (double yellow) between crossings
    const zone = SLD + 0.02;
    g.strokeStyle = '#e8b92f'; g.lineWidth = Math.max(1, s * 0.022);
    const segs = (cs, lo, hi) => { const a = [lo]; cs.forEach((c) => { a.push(c - zone, c + zone); }); a.push(hi); const o = []; for (let i = 0; i < a.length; i += 2) if (a[i + 1] > a[i]) o.push([a[i], a[i + 1]]); return o; };
    D.vx.forEach((x) => segs(D.hy, 0, H).forEach(([a, b]) => { for (const o of [-0.03, 0.03]) { g.beginPath(); g.moveTo(X(x + o), Y(a)); g.lineTo(X(x + o), Y(b)); g.stroke(); } }));
    D.hy.forEach((y) => segs(D.vx, 0, W).forEach(([a, b]) => { for (const o of [-0.03, 0.03]) { g.beginPath(); g.moveTo(X(a), Y(y + o)); g.lineTo(X(b), Y(y + o)); g.stroke(); } }));
    // crosswalks + stop lines
    for (let ix = 0; ix < D.nI; ix++) {
      const c = ctr(D, ix);
      g.fillStyle = 'rgba(240,236,224,.88)';
      for (let arm = 0; arm < 4; arm++) {
        const mx = c[0] + DX[arm] * (HW + CW / 2), my = c[1] + DY[arm] * (HW + CW / 2), ux = RX(arm), uy = RY(arm);
        for (let k = -3; k <= 3; k++) {
          const px = mx + ux * k * 0.135, py = my + uy * k * 0.135;
          const hw = Math.abs(ux) > 0.5 ? 0.04 : CW * 0.42, hh = Math.abs(ux) > 0.5 ? CW * 0.42 : 0.04;
          g.fillRect(X(px - hw), Y(py - hh), hw * 2 * s, hh * 2 * s);
        }
      }
      g.fillStyle = 'rgba(245,242,232,.95)';
      for (let d = 0; d < 4; d++) {
        const bx = c[0] - DX[d] * SLD, by = c[1] - DY[d] * SLD;
        const ax0 = bx, ay0 = by, ax1 = bx + RX(d) * HW, ay1 = by + RY(d) * HW;
        const t = 0.035;
        g.fillRect(X(Math.min(ax0, ax1) - (DX[d] ? t : 0)), Y(Math.min(ay0, ay1) - (DY[d] ? t : 0)), Math.max(Math.abs(ax1 - ax0), DX[d] ? t * 2 : 0) * s, Math.max(Math.abs(ay1 - ay0), DY[d] ? t * 2 : 0) * s);
        if (D.lt) { // painted straight/left arrows on the approach lane
          const px = c[0] - DX[d] * (SLD + 0.38) + RX(d) * Q, py = c[1] - DY[d] * (SLD + 0.38) + RY(d) * Q;
          g.save(); g.translate(X(px), Y(py)); g.rotate(Math.atan2(DY[d], DX[d])); g.strokeStyle = 'rgba(240,236,224,.55)'; g.lineWidth = Math.max(1, s * 0.035); g.lineCap = 'round';
          g.beginPath(); g.moveTo(-s * 0.14, 0); g.lineTo(s * 0.12, 0); g.moveTo(s * 0.05, -s * 0.06); g.lineTo(s * 0.12, 0); g.lineTo(s * 0.05, s * 0.06);
          g.moveTo(-s * 0.02, 0); g.quadraticCurveTo(s * 0.04, 0, s * 0.04, -s * 0.1); g.stroke(); g.restore();
        }
      }
    }
    // houses, trees
    for (const o of D.deco) {
      if (o.k === 0) {
        const c = HOUSE[o.c], w = o.w * s, h = o.h * s, x = X(o.x) - w / 2, y = Y(o.y) - h / 2;
        g.fillStyle = 'rgba(0,0,0,.25)'; rr(g, x + s * 0.05, y + s * 0.07, w, h, 3); g.fill();
        g.fillStyle = c[1]; rr(g, x, y, w, h, 3); g.fill();
        g.fillStyle = c[0];
        if (o.rf) { rr(g, x, y, w, h / 2, 3); g.fill(); } else { rr(g, x, y, w / 2, h, 3); g.fill(); }
        g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 1;
        g.beginPath(); if (o.rf) { g.moveTo(x + 2, y + h / 2); g.lineTo(x + w - 2, y + h / 2); } else { g.moveTo(x + w / 2, y + 2); g.lineTo(x + w / 2, y + h - 2); } g.stroke();
        g.fillStyle = '#6b5a52'; g.fillRect(x + w * 0.7, y + h * 0.15, Math.max(2, s * 0.08), Math.max(2, s * 0.08));
      } else if (o.k === 1) {
        const R = o.r * s;
        g.fillStyle = 'rgba(0,0,0,.25)'; circ(g, X(o.x) + s * 0.05, Y(o.y) + s * 0.07, R); g.fill();
        g.fillStyle = '#2f6e3a'; circ(g, X(o.x), Y(o.y), R); g.fill();
        g.fillStyle = '#3f8a46'; circ(g, X(o.x) - R * 0.2, Y(o.y) - R * 0.2, R * 0.72); g.fill();
        g.fillStyle = 'rgba(180,230,140,.35)'; circ(g, X(o.x) - R * 0.35, Y(o.y) - R * 0.35, R * 0.3); g.fill();
      } else {
        g.fillStyle = '#3c7f43'; circ(g, X(o.x), Y(o.y), o.r * s); g.fill();
        g.fillStyle = '#ff9ac0'; circ(g, X(o.x) + o.r * s * 0.3, Y(o.y) - o.r * s * 0.2, Math.max(1, o.r * s * 0.25)); g.fill();
      }
    }
    // roadwork: hatched slow zone + cones
    for (const z of D.work) {
      g.save(); g.beginPath(); g.rect(X(z.x0), Y(z.y0), (z.x1 - z.x0) * s, (z.y1 - z.y0) * s); g.clip();
      g.strokeStyle = 'rgba(255,150,40,.22)'; g.lineWidth = s * 0.1;
      for (let k = -20; k < 40; k++) { g.beginPath(); g.moveTo(X(z.x0) + k * s * 0.3, Y(z.y0)); g.lineTo(X(z.x0) + k * s * 0.3 - (z.y1 - z.y0) * s, Y(z.y1)); g.stroke(); }
      g.restore();
      const cone = (x, y) => { g.fillStyle = 'rgba(0,0,0,.3)'; circ(g, X(x) + 1.5, Y(y) + 2, s * 0.07); g.fill(); g.fillStyle = '#ff7a1a'; circ(g, X(x), Y(y), s * 0.07); g.fill(); g.fillStyle = '#fff'; circ(g, X(x), Y(y), s * 0.035); g.fill(); g.fillStyle = '#ff7a1a'; circ(g, X(x), Y(y), s * 0.018); g.fill(); };
      if (z.v) { for (let y = z.y0 + 0.1; y < z.y1; y += 0.3) { cone(z.x0 + 0.06, y); cone(z.x1 - 0.06, y); } }
      else { for (let x = z.x0 + 0.1; x < z.x1; x += 0.3) { cone(x, z.y0 + 0.06); cone(x, z.y1 - 0.06); } }
      const sx = z.v ? z.x1 + 0.22 : (z.x0 + z.x1) / 2, sy = z.v ? (z.y0 + z.y1) / 2 : z.y0 - 0.24;
      g.fillStyle = '#ffb21a'; g.save(); g.translate(X(sx), Y(sy)); g.rotate(Math.PI / 4); g.fillRect(-s * 0.12, -s * 0.12, s * 0.24, s * 0.24); g.restore();
      g.fillStyle = '#2a1c10'; g.font = '800 ' + Math.max(8, Math.round(s * 0.16)) + 'px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('공사', X(sx), Y(sy) + 0.5);
    }
  }
  function drawMini(g, D, x, y, w, h) {   // picker thumbnails
    const s = Math.min(w / W, h / H);
    g.save(); g.beginPath(); g.rect(x, y, W * s, H * s); g.clip();
    g.fillStyle = '#5c9a53'; g.fillRect(x, y, W * s, H * s);
    g.fillStyle = '#42454e';
    D.vx.forEach((vx) => g.fillRect(x + (vx - HW) * s, y, s, H * s));
    D.hy.forEach((hy) => g.fillRect(x, y + (hy - HW) * s, W * s, s));
    for (const z of D.work) { g.fillStyle = 'rgba(255,140,30,.8)'; g.fillRect(x + z.x0 * s, y + z.y0 * s, (z.x1 - z.x0) * s, (z.y1 - z.y0) * s); }
    for (let ix = 0; ix < D.nI; ix++) { const c = ctr(D, ix); g.fillStyle = '#4fe08a'; circ(g, x + c[0] * s, y + c[1] * s, Math.max(1.5, s * 0.22)); g.fill(); }
    if (D.rain) { g.fillStyle = 'rgba(60,90,150,.35)'; g.fillRect(x, y, W * s, H * s); }
    g.restore();
  }
  const CSS = `
.tf-pick{position:absolute;inset:0;z-index:4;overflow-y:auto;background:rgba(18,14,24,.96);padding:12px 12px 24px;-webkit-overflow-scrolling:touch;touch-action:pan-y}
.tf-pick h3{margin:2px 0 2px;font:400 20px var(--f-display,sans-serif);color:var(--ink,#f2e9d8)}
.tf-pick .sub{color:var(--muted,#ab9fb8);font:500 12px var(--f-body,sans-serif);margin:0 0 10px;line-height:1.4}
.tf-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.tf-st{position:relative;display:flex;flex-direction:column;align-items:center;gap:2px;padding:7px 3px 6px;border-radius:12px;background:#2e2640;
  border:1.5px solid rgba(255,255,255,.06);color:var(--ink,#f2e9d8);font:600 11px var(--f-body,sans-serif);cursor:pointer;min-height:44px}
.tf-st:active{transform:translateY(1px)}
.tf-st.next{border-color:#e3ae45;box-shadow:0 0 0 2px rgba(227,174,69,.25)}
.tf-st canvas{border-radius:4px;display:block}
.tf-st .nm{line-height:1.15;text-align:center;word-break:keep-all;min-height:2.3em;display:flex;align-items:center}
.tf-st .stars{color:#ffd24a;letter-spacing:1px;font-size:11px;line-height:1}
.tf-st .stars i{color:rgba(242,233,216,.22);font-style:normal}
.tf-st .bt{font:500 10px var(--f-mono,monospace);color:var(--muted,#ab9fb8)}
.tf-st .no{position:absolute;left:5px;top:3px;font:700 11px var(--f-mono,monospace);color:#e3ae45;text-shadow:0 1px 2px #000}
.tf-rand{display:block;width:100%;margin-top:12px}
`;
  const KEYN = { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Space: '스페이스', Enter: 'Enter' };

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const DPR = () => Math.min(2.5, cv.dpr || 1);
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    let st = null;
    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    const isBot = (s) => { const p = api.players[s]; return !!p && (!!p.ai || (auto() && isMine(s))); };

    let key = null, D = null, KS = [], AIs = [], view = 0, lay = null, tl = -3.5;
    let parts = [], floats = [], ripples = [], shake = 0, endWait = 0, endSeen = false, hostT = 0, pickRid = -1, pick = null;
    let statC = null, statK = '', sel = 0, kbUsed = false, hover = -1, bestNew = false, saved = false, pubT = 0, lastSig = '', heartT = 0, busyT = 0;
    let QA = null, honkT = 0;
    const remote = {}, lastSc = {}, P1 = { x: 0, y: 0, ux: 0, uy: 0 }, P2 = { x: 0, y: 0, ux: 0, uy: 0 }, PQ = { x: 0, y: 0, hx: 0, hy: 0 };
    const READY = 3.5;
    const FINE = !!(window.matchMedia && window.matchMedia('(pointer:fine)').matches);
    const rain = [];
    for (let i = 0; i < 70; i++) rain.push([Math.random(), Math.random(), 0.6 + Math.random() * 0.6]);

    const curKey = () => (st && st.ph !== 'pick' ? st.rid + '.' + st.sd + '.' + st.stg + '.' + st.cty + '.' + st.dur : null);
    function ensureMatch() {
      if (!st || st.ph === 'pick') return;
      const k = curKey();
      if (k === key) return;
      key = k; D = defOf(st); KS = []; AIs = [];
      for (let s = 0; s < st.n; s++) makeBoard(s);
      const m = mine(), fst = KS.findIndex(Boolean);
      view = m.length ? m[0] : (fst >= 0 ? fst : 0);
      parts = []; floats = []; ripples = []; shake = 0; endWait = 0; endSeen = false; bestNew = false; saved = false;
      for (const x in remote) delete remote[x];
      for (const x in lastSc) delete lastSc[x];
      tl = st.ph === 'done' ? 9999 : -READY;
      sel = 0; kbUsed = false; statC = null; layout();
    }
    function makeBoard(s) {
      if (!simHere(s)) { KS[s] = null; AIs[s] = null; return; }
      KS[s] = newBoard(D);
      const p = api.players[s];
      AIs[s] = isBot(s) ? aiInit(p && p.ai ? (p.lv || 2) : 2, ((st.sd ^ Math.imul(s + 1, 0x9E3779B1)) >>> 0) + st.rid) : null;
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h, n = st ? st.n : 1;
      const hudH = 40, stripH = n > 1 ? 44 : 24, hintH = 24;
      const top = hudH + stripH + 4, bottom = h - hintH - 6;
      const sc = Math.max(16, Math.min((w - 14) / W, (bottom - top) / H));
      const bw = sc * W, bh = sc * H;
      const ox = Math.round((w - bw) / 2), oy = Math.round(top + Math.max(0, (bottom - top - bh) * 0.3));
      lay = { w, h, hudH, stripH, hintH, sc, bw, bh, ox, oy, hintY: Math.min(h - hintH / 2 - 2, oy + bh + 4 + hintH / 2) };
      statC = null;
    }
    cv.onresize = layout;
    const X = (x) => lay.ox + x * lay.sc, Y = (y) => lay.oy + y * lay.sc;

    function staticLayer() {
      const sk = key + '|' + lay.sc + '|' + DPR();
      if (statC && statK === sk) return statC;
      const m = 8, d = DPR();
      const c = document.createElement('canvas'); c.width = Math.ceil((lay.bw + m * 2) * d); c.height = Math.ceil((lay.bh + m * 2) * d);
      const g = c.getContext('2d'); g.scale(d, d);
      g.fillStyle = '#5a3d24'; rr(g, 0, 0, lay.bw + m * 2, lay.bh + m * 2, 12); g.fill();
      g.strokeStyle = '#8a6238'; g.lineWidth = 2; rr(g, 1, 1, lay.bw + m * 2 - 2, lay.bh + m * 2 - 2, 11); g.stroke();
      g.fillStyle = '#2e1f12'; g.fillRect(m - 2, m - 2, lay.bw + 4, lay.bh + 4);
      g.save(); g.beginPath(); g.rect(m, m, lay.bw, lay.bh); g.clip();
      paintTown(g, D, m, m, lay.sc);
      g.restore();
      statC = c; statK = sk;
      return c;
    }

    /* ----- solo stage picker ----- */
    function bests() { try { return JSON.parse(localStorage.getItem('lounge.traffic.best') || '{}') || {}; } catch (e) { return {}; } }
    function saveBest(id, sc, stars) {
      if (!(id >= 0 && id < STAGES.length)) return false;
      const b = bests(), o = Array.isArray(b[id]) ? b[id] : [0, 0]; if (o[0] >= sc && o[1] >= stars) return false;
      b[id] = [Math.max(o[0], sc), Math.max(o[1], stars)];
      try { localStorage.setItem('lounge.traffic.best', JSON.stringify(b)); } catch (e) {}
      return sc > o[0];
    }
    function thumb(Dd, wpx) {
      const hpx = Math.round(wpx * H / W), c = L.h('canvas'), d = Math.min(2, window.devicePixelRatio || 1);
      c.width = Math.round(wpx * d); c.height = Math.round(hpx * d); c.style.width = wpx + 'px'; c.style.height = hpx + 'px';
      const g = c.getContext('2d'); g.scale(d, d);
      drawMini(g, Dd, 0, 0, wpx, hpx);
      return c;
    }
    function buildPicker() {
      if (pick) return;
      const canPick = host() && mine().length > 0 && !auto();
      const Bs = bests(), bs = (i) => (Array.isArray(Bs[i]) ? Bs[i] : [0, 0]);
      let next = STAGES.findIndex((_, i) => !(bs(i)[1] > 0));
      if (next < 0) next = STAGES.findIndex((_, i) => bs(i)[1] < 3);
      const grid = L.h('div', { class: 'tf-grid' }), wpx = Math.max(30, Math.min(46, Math.floor(((lay ? lay.w : 360) - 48) / 4) - 28));
      const go = (id) => { if (!canPick || !st || st.ph !== 'pick') return; api.sfx('click'); api.buzz(15); api.setState(startStage(st, id)); };
      let nextEl = null;
      STAGES.forEach((S, i) => {
        const b0 = bs(i), n = U.clamp(b0[1] | 0, 0, 3);
        const stars = L.h('div', { class: 'stars' }); stars.innerHTML = '★'.repeat(n) + '<i>' + '★'.repeat(3 - n) + '</i>';
        const b = L.h('button', { class: 'tf-st' + (i === next ? ' next' : ''), type: 'button', 'aria-label': (i + 1) + '번 ' + S.n, disabled: !canPick },
          L.h('span', { class: 'no', text: String(i + 1) }), thumb(genDef(S, S.dur), wpx), L.h('span', { class: 'nm', text: S.n }), stars,
          L.h('span', { class: 'bt', text: b0[0] > 0 ? b0[0] + '점' : '기록 없음' }));
        b.onclick = () => go(i);
        if (i === next) nextEl = b;
        grid.append(b);
      });
      const rnd = L.h('button', { class: 'btn tf-rand', type: 'button', text: '무작위 마을 · 매번 새로 만들어요', disabled: !canPick });
      rnd.onclick = () => go(1000);
      const el = L.h('div', { class: 'tf-pick' }, L.h('h3', { text: '스테이지 고르기' }),
        L.h('p', { class: 'sub', text: canPick ? '끝까지 버티면 ★, 점수가 높으면 ★★·★★★. 금테 칸이 다음 도전이에요.' : '고르는 중…' }), grid, rnd);
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el };
      if (nextEl) setTimeout(() => { try { nextEl.scrollIntoView({ block: 'nearest' }); } catch (e) {} }, 30);
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } }
    function hostPickFlow(rdt) {
      if (!host() || !st || st.ph !== 'pick') return;
      if (pickRid !== st.rid) { pickRid = st.rid; hostT = 0; }
      if (!mine().length || auto()) { hostT += rdt * SPD(); if (hostT > 1.2) { hostT = -1e9; api.setState(startStage(st, auto() ? 0 : U.rand(STAGES.length))); } }
    }

    /* ----- input ----- */
    const myB = () => { const m = mine()[0]; return m != null ? KS[m] : null; };
    const canCtl = () => !!st && st.ph === 'play' && isMine(view) && !auto() && !!KS[view] && tl >= 0 && KS[view].ph === 1;
    function fl(x, y, text, col, big, life) { floats.push({ x, y, text, col: col || '#fff3c0', t: life || 1.2, T: life || 1.2, big: !!big }); if (floats.length > 14) floats.shift(); }
    function busyMsg(ix) { if (busyT > 0) return; busyT = 0.6; const c = ctr(D, ix); fl(c[0], c[1] - 0.6, '신호 바뀌는 중…', '#ffe08a', false, 0.8); sfxG('tick', 80); }
    function doToggle(ix) {
      if (!canCtl()) return;
      const r = toggleB(KS[view], ix);
      if (r === 'ok') { api.sfx('click'); api.buzz(12); ripples.push({ ix, t: 0.35, T: 0.35, col: '#ffe08a' }); }
      else if (r === 'busy') busyMsg(ix);
    }
    function doLeft(ix) {
      if (!canCtl()) return;
      const r = leftB(KS[view], ix), c = ctr(D, ix);
      if (r === 'ok') { api.sfx('pop'); api.buzz(12); ripples.push({ ix, t: 0.35, T: 0.35, col: C_GREEN }); }
      else if (r === 'busy') busyMsg(ix);
      else if (r === 'none') { fl(c[0], c[1] - 0.6, '맨 앞에 좌회전 차가 없어요', '#ffc0b0', false, 1.1); sfxG('tick', 80); }
      else if (r === 'already') { fl(c[0], c[1] - 0.6, '이미 좌회전 신호예요', '#ffe08a', false, 0.9); }
    }
    function toWorld(p) { return { x: (p.x - lay.ox) / lay.sc, y: (p.y - lay.oy) / lay.sc }; }
    function crossAt(p) {
      const w = toWorld(p); let best = -1, bd = 1e9;
      for (let ix = 0; ix < D.nI; ix++) { const c = ctr(D, ix), dx = Math.abs(w.x - c[0]), dy = Math.abs(w.y - c[1]); if (dx < 1.15 && dy < 1.15 && dx + dy < bd) { bd = dx + dy; best = ix; } }
      return best;
    }
    const lbR = () => Math.max(20, lay.sc * 0.36);
    function leftAt(p) {
      if (!D || !D.lt) return -1;
      const hr = Math.max(26, lay.sc * 0.5);
      for (let ix = 0; ix < D.nI; ix++) { const q = leftBtnPos(ctr(D, ix)); if (Math.hypot(p.x - X(q[0]), p.y - Y(q[1])) < hr) return ix; }
      return -1;
    }
    function chipAt(p) {
      if (!st || st.n < 2 || p.y < lay.hudH || p.y > lay.hudH + lay.stripH) return -1;
      const cw = (lay.w - 12) / st.n, i = Math.floor((p.x - 6) / cw);
      return i >= 0 && i < st.n ? i : -1;
    }
    const canWatch = () => { const M = myB(); return !M || M.ph !== 1 || auto(); };
    function setView(s) {
      if (s === view) return;
      if (!KS[s]) { api.toast('그 판은 그 사람 폰에서만 보여요'); return; }
      view = s; api.sfx('click');
    }
    function onDown(e) {
      if (!st || !lay) return;
      const p = cv.local(e);
      e.preventDefault();
      if (st.ph === 'play' && tl < -0.2 && st.n === 1 && !api.online) { tl = -0.01; return; }   // solo: tap skips the tip
      const ch = chipAt(p);
      if (ch >= 0) {
        if (canWatch() || ch === mine()[0]) setView(ch);
        else api.toast('내 판이 끝나면 다른 판을 볼 수 있어요');
        return;
      }
      if (!D || !canCtl()) return;
      const lb = leftAt(p);
      if (lb >= 0) { doLeft(lb); return; }
      const ix = crossAt(p);
      if (ix >= 0) { if (e.pointerType === 'mouse') kbUsed = false; sel = ix; doToggle(ix); }
    }
    function onMove(e) { if (!lay || !D || e.pointerType !== 'mouse') return; const p = cv.local(e); hover = leftAt(p) >= 0 ? -1 : crossAt(p); }
    function onLeave() { hover = -1; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerleave', onLeave);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);

    /* keyboard / gamepad: arrows pick a crossing, 바꾸기 flips it, 1–4 flip a crossing directly, 좌회전 = ↰ */
    function moveSel(dx, dy) {
      if (!D) return;
      const c0 = ctr(D, sel); let best = -1, bd = 1e9;
      for (let ix = 0; ix < D.nI; ix++) {
        if (ix === sel) continue;
        const c = ctr(D, ix), vx = c[0] - c0[0], vy = c[1] - c0[1], along = vx * dx + vy * dy;
        if (along <= 0.01) continue;
        const d = along + 2 * Math.abs(vx * dy - vy * dx);
        if (d < bd) { bd = d; best = ix; }
      }
      if (best >= 0) { sel = best; api.sfx('tick'); }
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !st || !D) return;
      if (id === 'view') {
        if (!canWatch()) { api.toast('내 판이 끝나면 다른 판을 볼 수 있어요'); return; }
        const idx = []; for (let s = 0; s < st.n; s++) if (KS[s]) idx.push(s);
        if (idx.length > 1) setView(idx[(idx.indexOf(view) + 1) % idx.length]);
        return;
      }
      if (st.ph === 'play' && tl < -0.2 && st.n === 1 && !api.online && (id === 'toggle' || id === 'arrow')) { tl = -0.01; return; }
      kbUsed = true; hover = -1;
      if (id === 'up') moveSel(0, -1); else if (id === 'down') moveSel(0, 1); else if (id === 'left') moveSel(-1, 0); else if (id === 'right') moveSel(1, 0);
      else if (id === 'toggle') doToggle(Math.min(sel, D.nI - 1));
      else if (id === 'arrow') { if (D.lt) doLeft(Math.min(sel, D.nI - 1)); else api.toast('이 판에는 좌회전 신호가 없어요'); }
      else if (/^i[1-4]$/.test(id)) { const ix = +id[1] - 1; if (ix < D.nI) { sel = ix; doToggle(ix); } }
    }) : () => {};

    /* ----- effects ----- */
    const lastSfx = {};
    function sfxG(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 50)) return; lastSfx[n] = t; api.sfx(n); }
    function burst(x, y, cols, n, sp, life, kind) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: life, T: life, c: cols[i % cols.length], k: kind || 'dot', r: 0.03 + Math.random() * 0.04 }); }
      if (parts.length > 240) parts.splice(0, parts.length - 240);
    }
    function onEvents(B) {
      const me = isMine(view);
      for (const e of B.ev) {
        switch (e.k) {
          case 'light': sfxG('tick', 40); break;
          case 'pass':
            if (e.ty === 1 || e.ty === 3) { sfxG('chip', 90); fl(e.x, e.y, '+' + e.p, e.ok ? '#9dffb0' : '#ffe08a', e.ok, e.ok ? 1.5 : 1.1); if (e.ok) fl(e.x, e.y + 0.35, '길 터 주기 성공!', '#9dffb0', false, 1.5); }
            else fl(e.x, e.y, '+' + e.p, 'rgba(255,240,190,.85)', false, 0.8);
            break;
          case 'ped': sfxG('tick', 120); fl(e.x, e.y, '+5', '#bfe8ff', false, 0.8); break;
          case 'pedq': sfxG('thud', 120); fl(e.x, e.y, '돌아가요 −10', '#ffb0a0', false, 1.2); break;
          case 'angry': if (honkT <= 0) { honkT = 0.5; sfxG('tick', 60); } fl(e.x, e.y - 0.3, '빵빵!', '#ff9a7a', false, 0.9); if (me) api.buzz(10); break;
          case 'run': sfxG('whoosh', 120); if (me) api.buzz(25); fl(e.x, e.y, '신호 위반 −10', '#ff8a7a', true, 1.3); break;
          case 'crash': sfxG('thud', 80); sfxG('hit', 80); if (me) api.buzz([40, 40, 90]); shake = 0.8; burst(e.x, e.y, ['#ffd24a', '#ff8a3a', '#fff'], 18, 2.6, 0.6); burst(e.x, e.y, ['rgba(80,80,90,.7)', 'rgba(140,140,150,.6)'], 10, 0.6, 1.4, 'smoke'); fl(e.x, e.y - 0.25, '쾅! ♥ −1', '#ff6a5a', true, 1.6); break;
          case 'bump': sfxG('hit', 80); burst(e.x, e.y, ['#ffd24a', '#fff'], 8, 2, 0.4); break;
          case 'tow': burst(e.x, e.y, ['rgba(200,200,210,.6)'], 6, 0.5, 0.6, 'smoke'); break;
          case 'amb': sfxG('whoosh', 200); { const E = D.ents[e.e]; const p = entryPt(E); fl(p[0], p[1], '구급차 출동!', '#ff8a8a', true, 1.6); } if (me) api.buzz([15, 40, 15]); break;
          case 'ambLate': sfxG('lose', 200); if (me) api.buzz(40); fl(e.x, e.y - 0.3, '구급차 지연 −40', '#ff7a6a', true, 1.6); break;
          case 'lost': { const p = entryPt(D.ents[e.e]); fl(p[0], p[1], '돌아갔어요 −5', '#ffb0a0', false, 1.1); } break;
          case 'fail': sfxG('lose', 200); break;
          case 'end': if (me) { sfxG('win', 200); api.buzz([20, 30, 50]); } break;
        }
      }
      B.ev.length = 0;
    }
    function entryPt(E) { const m = 0.3; return E.d === 2 ? [E.c - Q, m] : E.d === 0 ? [E.c + Q, H - m] : E.d === 1 ? [m, E.c + Q] : [W - m, E.c - Q]; }

    /* ----- online: rows = [score, hearts, passed, crashes, f] ----- */
    const fOfB = (B) => (B.ph === 2 ? 1 : B.ph === 3 ? 2 : 0);
    function rowOfB(B) { return [B.sc, B.hp, B.ps, B.cr, fOfB(B)]; }
    function rowOf(s) {
      if (st && st.ph === 'done' && Array.isArray(st.res)) { const r = st.res.find((x) => x[0] === s); if (r) return [r[1], r[2], r[3], r[4], r[5]]; }
      const B = KS[s]; if (B) return rowOfB(B);
      const o = remote[s]; return o ? [o.sc, o.hp, o.ps, o.cr, o.f] : [0, HEARTS, 0, 0, 0];
    }
    function takeRow(s, a) {
      if (!Array.isArray(a)) return;
      const o = remote[s] || (remote[s] = { at: tl });
      const f = a[4] | 0;
      if (o.sc !== (a[0] | 0) || o.f !== f) o.at = tl;
      Object.assign(o, { sc: a[0] | 0, hp: U.clamp(a[1] | 0, 0, 9), ps: a[2] | 0, cr: a[3] | 0, f });
    }
    function pollNet() {
      if (!api.online || !key) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) { const s = +k, o = rem[k]; if (!(s >= 0 && s < st.n) || KS[s] || !o || o.k !== key) continue; takeRow(s, o.r); }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== key) return;
        if (typeof hs.t === 'number' && isFinite(hs.t) && st.ph === 'play') { const d = hs.t - tl; if (Math.abs(d) > 0.6) tl = hs.t; else tl += d * 0.05; }
        if (Array.isArray(hs.r)) hs.r.forEach((a, s) => { if (!KS[s]) takeRow(s, a); });
      }
    }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 0.3;
          const r = []; for (let i = 0; i < st.n; i++) r.push(rowOf(i));
          api.net.hostSend({ k: key, t: Math.round(tl * 100) / 100, r });
        } else {
          const B = myB(); if (!B) return;
          heartT -= rdt;
          if (pubT > 0) return;
          const row = rowOfB(B), sig = row.join('|');
          if (sig === lastSig && heartT > 0) return;
          lastSig = sig; pubT = 0.3; heartT = 1.5;
          api.net.publish({ k: key, r: row });
        }
      } catch (e) {}
    }
    const fOf = (s) => { const B = KS[s]; if (B) return fOfB(B); const o = remote[s]; return o ? o.f : 0; };
    function hostEnd(rdt) {
      if (!host() || !st || st.ph !== 'play' || !D || tl < 0) return;
      let ready = true, stale = true;
      for (let s = 0; s < st.n; s++) if (!fOf(s)) { ready = false; if (KS[s] || !remote[s] || tl - remote[s].at < 20) stale = false; }
      if (!ready && !stale && tl < D.dur + 10) { endWait = 0; return; }
      endWait += rdt;
      if (endWait > (st.n === 1 ? 1.2 : 1.6)) {
        const rows = []; for (let s = 0; s < st.n; s++) { const r = rowOf(s); rows.push([s, r[0], r[1], r[2], r[3], fOf(s) || 2]); }
        endWait = -1e9;
        api.setState(finish(st, rows));
      }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) { draw(now); return; }
      const dt = rdt * SPD();
      if (st.ph === 'pick') { if (!pick) buildPicker(); hostPickFlow(rdt); draw(now); return; }
      if (pick) dropPicker();
      ensureMatch();
      if (key && D) {
        const was = tl;
        if (st.ph === 'play') tl += dt;
        pollNet();
        if (was < 0 && tl < 0 && Math.ceil(-was) !== Math.ceil(-tl)) api.sfx('tick');
        if (was < 0 && tl >= 0 && mine().length) { api.sfx('pop'); api.buzz(20); }
        const target = Math.max(0, Math.min(tl, D.dur + 0.01));
        for (let s = 0; s < st.n; s++) {
          if (!KS[s] && simHere(s) && st.ph === 'play') makeBoard(s);   // a seat taken over by the host's AI starts here
          const B = KS[s]; if (!B) continue;
          const A = AIs[s];
          let n = 0;
          while (B.ph === 1 && B.t + DT <= target + 1e-9 && n < 300) { if (A) aiThink(B, A, DT); stepB(B, DT); n++; }
          if (B.ph !== 1 && B.t < target) B.t = target;
          if (s !== view) B.ev.length = 0;
        }
        for (let s = 0; s < st.n; s++) { const sc = rowOf(s)[0]; if (lastSc[s] != null && sc - lastSc[s] >= 30 && s !== view) floats.push({ hud: s, text: '+' + (sc - lastSc[s]), col: '#ffe08a', t: 1.1, T: 1.1 }); lastSc[s] = sc; }
        const B = KS[view];
        if (B) { onEvents(B); QA = queues(B); } else QA = null;
        const M = myB();
        if (M && M.ph !== 1 && !endSeen && !auto()) {
          endSeen = true;
          if (st.n === 1 && !saved && st.stg >= 0 && st.stg < STAGES.length) { saved = true; bestNew = saveBest(st.stg, M.sc, starsOf(st, M.sc, fOfB(M))); }
        }
        hostEnd(rdt);
      }
      busyT -= rdt; honkT -= rdt;
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; if (q.k === 'smoke') { q.vy -= 0.3 * rdt; q.r += rdt * 0.08; } q.vx *= 0.95; q.vy *= 0.95; if (q.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = ripples.length - 1; i >= 0; i--) { ripples[i].t -= rdt; if (ripples[i].t <= 0) ripples.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 2.2);
      publish(rdt);
      draw(now);
    }
    // per approach (crossing × heading): waiting count, worst gauge, a left-turner waiting at the front
    function queues(B) {
      const n = D.nI * 4, o = QA && QA.q.length === n ? QA : { q: new Uint8Array(n), w: new Float32Array(n), lf: new Uint8Array(n), amb: new Uint8Array(n), any: 0, ang: 0, ambR: 0, lfG: 0 };
      o.q.fill(0); o.w.fill(0); o.lf.fill(0); o.amb.fill(0); o.ang = 0; o.ambR = 0; o.lfG = 0;
      for (const a of B.V) {
        if (a.cr > 0 || a.si >= a.ro.st.length) continue;
        const S = a.ro.st[a.si], k = S.ix * 4 + S.d, dist = S.s - (a.s + VT[a.ty].len / 2);
        if (dist > 4.5) continue;
        const ok = lightOK(B, S);
        if (a.ty === 3 && !ok && dist < 3) { o.amb[k] = 1; o.ambR = 1; }
        if (a.v < 0.3) { o.q[k]++; if (a.w > o.w[k]) o.w[k] = a.w; if (a.an) o.ang = 1; if (S.t === 2 && dist < 0.5) { o.lf[k] = 1; const g = B.L[S.ix]; if (g.st === 0 && g.ph === S.ax) o.lfG = 1; } }
      }
      return o;
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align, base) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    function wrap(t, maxW, font) {
      ctx.font = font; const out = []; let line = '';
      for (const wd of t.split(' ')) { const tryL = line ? line + ' ' + wd : wd; if (ctx.measureText(tryL).width > maxW && line) { out.push(line); line = wd; } else line = tryL; }
      if (line) out.push(line); return out;
    }
    function panel(x, y, w, h) { ctx.fillStyle = 'rgba(18,12,24,.93)'; rr(ctx, x, y, w, h, 14); ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.stroke(); }
    function heart(x, y, r, on) {
      ctx.beginPath(); ctx.moveTo(x, y + r * 0.9);
      ctx.bezierCurveTo(x - r * 1.5, y - r * 0.1, x - r * 0.75, y - r * 1.25, x, y - r * 0.45);
      ctx.bezierCurveTo(x + r * 0.75, y - r * 1.25, x + r * 1.5, y - r * 0.1, x, y + r * 0.9);
      ctx.fillStyle = on ? '#ff5a6e' : 'rgba(242,233,216,.16)'; ctx.fill();
      if (on) { ctx.fillStyle = 'rgba(255,255,255,.35)'; circ(ctx, x - r * 0.45, y - r * 0.45, r * 0.22); ctx.fill(); }
    }
    function sigState(B, ix, ax) {   // 0 red, 1 yellow, 2 green straight, 3 green left arrow
      const g = B.L[ix];
      if (g.st === 0) return g.ph === ax ? 2 : g.ph === ax + 2 ? 3 : 0;
      if (g.st === 1 && (g.ph & 1) === ax) return 1;
      return 0;
    }
    const SCOL = [C_RED, C_YEL, C_GREEN, C_GREEN];
    function drawLights(B, now) {
      const s = lay.sc;
      for (let ix = 0; ix < D.nI; ix++) {
        const c = ctr(D, ix), g = B.L[ix];
        // centre mark: which way the green goes
        const cx0 = X(c[0]), cy0 = Y(c[1]);
        ctx.save(); ctx.translate(cx0, cy0); ctx.globalAlpha = 0.5;
        const col = g.st === 0 ? C_GREEN : g.st === 1 ? C_YEL : C_RED;
        ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = Math.max(2, s * 0.06); ctx.lineCap = 'round';
        if (g.st === 2) { circ(ctx, 0, 0, s * 0.08); ctx.fill(); }
        else if (g.ph >= 2) {
          ctx.rotate((g.ph & 1) ? Math.PI / 2 : 0);
          ctx.beginPath(); ctx.moveTo(s * 0.06, s * 0.28); ctx.lineTo(s * 0.06, -s * 0.02); ctx.quadraticCurveTo(s * 0.06, -s * 0.12, -s * 0.06, -s * 0.12); ctx.lineTo(-s * 0.18, -s * 0.12); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(-s * 0.26, -s * 0.12); ctx.lineTo(-s * 0.15, -s * 0.2); ctx.lineTo(-s * 0.15, -s * 0.04); ctx.closePath(); ctx.fill();
        } else {
          if (g.ph === 1) ctx.rotate(Math.PI / 2);
          ctx.beginPath(); ctx.moveTo(0, -s * 0.24); ctx.lineTo(0, s * 0.24); ctx.stroke();
          for (const k of [-1, 1]) { ctx.beginPath(); ctx.moveTo(0, k * s * 0.33); ctx.lineTo(-s * 0.09, k * s * 0.2); ctx.lineTo(s * 0.09, k * s * 0.2); ctx.closePath(); ctx.fill(); }
        }
        ctx.restore();
        // stop-line glow per approach
        for (let d = 0; d < 4; d++) {
          const ax = d === 0 || d === 2 ? 0 : 1, ss = sigState(B, ix, ax), cl = SCOL[ss];
          const bx = c[0] - DX[d] * (SLD + 0.02), by = c[1] - DY[d] * (SLD + 0.02);
          const ex = bx + RX(d) * HW, ey = by + RY(d) * HW;
          ctx.strokeStyle = cl; ctx.globalAlpha = ss === 3 ? 0.55 : 0.85; ctx.lineWidth = Math.max(2.5, s * 0.07); ctx.lineCap = 'butt';
          ctx.beginPath(); ctx.moveTo(X(bx + RX(d) * 0.04), Y(by + RY(d) * 0.04)); ctx.lineTo(X(ex - RX(d) * 0.04), Y(ey - RY(d) * 0.04)); ctx.stroke();
          ctx.globalAlpha = 1;
        }
      }
      for (const q of ripples) {
        const f = 1 - q.t / q.T, c = ctr(D, q.ix);
        ctx.strokeStyle = q.col; ctx.globalAlpha = 1 - f; ctx.lineWidth = 3; circ(ctx, X(c[0]), Y(c[1]), lay.sc * (0.45 + f * 0.6)); ctx.stroke(); ctx.globalAlpha = 1;
      }
    }
    function drawPosts(B, now) {
      const s = lay.sc, r = Math.max(9, s * 0.19), pulse = 0.5 + 0.5 * Math.sin(now / 140);
      for (let ix = 0; ix < D.nI; ix++) {
        const c = ctr(D, ix);
        for (let d = 0; d < 4; d++) {
          const ax = d === 0 || d === 2 ? 0 : 1, ss = sigState(B, ix, ax), k = ix * 4 + d;
          const p = postPos(c, d), x = X(p[0]), y = Y(p[1]);
          const q = QA ? QA.q[k] : 0, w = QA ? QA.w[k] : 0, amb = QA && QA.amb[k];
          ctx.fillStyle = 'rgba(0,0,0,.35)'; circ(ctx, x + 1.5, y + 2, r); ctx.fill();
          const hot = q && w > 0.75;
          ctx.fillStyle = hot ? 'rgba(' + (120 + 80 * pulse | 0) + ',20,24,.95)' : q && w > 0.45 ? '#5a3a14' : '#1d1826'; circ(ctx, x, y, r); ctx.fill();
          ctx.strokeStyle = SCOL[ss]; ctx.lineWidth = Math.max(2.5, r * 0.28); circ(ctx, x, y, r - ctx.lineWidth / 2); ctx.stroke();
          if (q && w > 0.02) {   // impatience arc around the post
            ctx.strokeStyle = w > 0.75 ? '#ff5a4a' : w > 0.45 ? '#ffb43a' : '#e8e0a0'; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.arc(x, y, r + 3, -Math.PI / 2, -Math.PI / 2 + TAU * Math.min(1, w)); ctx.stroke();
          }
          if (q) txt(String(q), x, y + 0.5, '#fff', '800 ' + Math.round(r * 1.05) + 'px ' + MONO);
          else { ctx.fillStyle = SCOL[ss]; circ(ctx, x, y, r * 0.28); ctx.fill(); }
          if (ss === 3) { ctx.fillStyle = '#123a22'; circ(ctx, x + r * 0.95, y - r * 0.95, r * 0.55); ctx.fill(); txt('↰', x + r * 0.95, y - r * 0.92, C_GREEN, '800 ' + Math.round(r * 0.9) + 'px ' + FONT); }
          if (amb) { ctx.strokeStyle = 'rgba(255,80,80,' + (0.4 + 0.6 * pulse) + ')'; ctx.lineWidth = 2; circ(ctx, x, y, r + 7); ctx.stroke(); }
        }
        if (D.lt) {   // ↰ button
          const p = leftBtnPos(c), x = X(p[0]), y = Y(p[1]), R = lbR();
          let want = false; if (QA) for (let d = 0; d < 4; d++) if (QA.lf[ix * 4 + d]) want = true;
          const g = B.L[ix], on = g.st === 0 && g.ph >= 2;
          ctx.fillStyle = 'rgba(0,0,0,.4)'; circ(ctx, x + 2, y + 3, R); ctx.fill();
          ctx.fillStyle = on ? '#1f6b3e' : want ? 'rgba(' + (90 + 60 * pulse | 0) + ',60,20,1)' : '#2e2640'; circ(ctx, x, y, R); ctx.fill();
          ctx.strokeStyle = want ? '#ffb43a' : on ? C_GREEN : '#e3ae45'; ctx.lineWidth = 2; circ(ctx, x, y, R - 1); ctx.stroke();
          txt('↰', x, y - R * 0.12, on ? C_GREEN : '#f2e9d8', '800 ' + Math.round(R * 0.95) + 'px ' + FONT);
          txt('좌회전', x, y + R * 0.52, '#d8cce4', '700 ' + Math.max(9, Math.round(R * 0.36)) + 'px ' + FONT);
        }
        if ((kbUsed && sel === ix && canCtl()) || hover === ix) {
          ctx.strokeStyle = kbUsed ? '#ffe08a' : 'rgba(255,224,138,.6)'; ctx.lineWidth = 2.5; ctx.setLineDash([6, 4]);
          rr(ctx, X(c[0] - 0.62), Y(c[1] - 0.62), s * 1.24, s * 1.24, 10); ctx.stroke(); ctx.setLineDash([]);
        }
        if (D.nI > 1 && (kbUsed || FINE)) {
          const nx = X(c[0] - 0.36), ny = Y(c[1] - 0.36);
          ctx.fillStyle = 'rgba(20,14,28,.7)'; circ(ctx, nx, ny, 7); ctx.fill(); txt(String(ix + 1), nx, ny + 0.5, '#e3ae45', '800 10px ' + MONO);
        }
      }
      // backlog badges at the town's edge
      for (let e = 0; e < D.ents.length; e++) {
        const n = B.bl[e].length; if (!n) continue;
        const p = entryPt(D.ents[e]), x = X(p[0]), y = Y(p[1]), amb = B.bl[e].some((sp) => sp[0] === 3);
        const t = '+' + n; ctx.font = '800 11px ' + MONO; const tw = ctx.measureText(t).width + 10;
        ctx.fillStyle = amb ? 'rgba(200,30,40,.95)' : n >= 4 ? 'rgba(190,80,20,.95)' : 'rgba(40,30,50,.9)'; rr(ctx, x - tw / 2, y - 8, tw, 16, 8); ctx.fill();
        txt(t, x, y + 0.5, '#fff', '800 11px ' + MONO);
      }
    }
    function drawVehicle(a, now) {
      const T = VT[a.ty], s = lay.sc, Lp = T.len * s, Wp = T.wid * s;
      rpos(a.ro, a.s - 0.12, P1); rpos(a.ro, a.s + 0.12, P2);
      let ang = Math.atan2(P2.y - P1.y, P2.x - P1.x);
      if (a.cr > 0) ang += (((a.id * 7) % 5) - 2) * 0.16;
      const x = X(a.x), y = Y(a.y);
      ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
      ctx.fillStyle = 'rgba(0,0,0,.3)'; rr(ctx, -Lp / 2 + 1.5, -Wp / 2 + 2, Lp, Wp, Wp * 0.3); ctx.fill();
      let body = PALETTE[a.col] || '#e8574a';
      if (a.ty === 1) body = a.col & 1 ? '#2f9e6b' : '#3a7bd5';
      if (a.ty === 3) body = '#f4f2ea';
      if (a.ty === 2) {   // truck: cargo box + cab
        ctx.fillStyle = '#d9cba8'; rr(ctx, -Lp / 2, -Wp / 2, Lp * 0.68, Wp, 2); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.15)'; ctx.lineWidth = 1;
        for (let i = 1; i < 4; i++) { const xx = -Lp / 2 + Lp * 0.68 * i / 4; ctx.beginPath(); ctx.moveTo(xx, -Wp / 2 + 1); ctx.lineTo(xx, Wp / 2 - 1); ctx.stroke(); }
        ctx.fillStyle = body; rr(ctx, Lp * 0.2, -Wp / 2, Lp * 0.3, Wp, Wp * 0.25); ctx.fill();
        ctx.fillStyle = 'rgba(170,215,240,.9)'; ctx.fillRect(Lp * 0.38, -Wp * 0.36, Lp * 0.07, Wp * 0.72);
      } else {
        ctx.fillStyle = body; rr(ctx, -Lp / 2, -Wp / 2, Lp, Wp, a.ty === 1 ? 3 : Wp * 0.32); ctx.fill();
        if (a.ty === 1) {   // bus: window strips + roof hatches
          ctx.fillStyle = 'rgba(25,40,60,.7)'; ctx.fillRect(-Lp / 2 + 3, -Wp / 2 + 1, Lp - 7, Wp * 0.18); ctx.fillRect(-Lp / 2 + 3, Wp / 2 - 1 - Wp * 0.18, Lp - 7, Wp * 0.18);
          ctx.fillStyle = 'rgba(255,255,255,.75)'; ctx.fillRect(-Lp * 0.25, -Wp * 0.16, Lp * 0.14, Wp * 0.32); ctx.fillRect(Lp * 0.08, -Wp * 0.16, Lp * 0.14, Wp * 0.32);
          ctx.fillStyle = 'rgba(170,215,240,.9)'; ctx.fillRect(Lp / 2 - 3, -Wp * 0.4, 2, Wp * 0.8);
        } else {
          ctx.fillStyle = a.ty === 3 ? '#e6e3da' : shadeC(body, -0.25); rr(ctx, -Lp * 0.2, -Wp * 0.36, Lp * 0.42, Wp * 0.72, Wp * 0.22); ctx.fill();
          ctx.fillStyle = 'rgba(170,215,240,.9)'; rr(ctx, Lp * 0.16, -Wp * 0.33, Lp * 0.11, Wp * 0.66, 2); ctx.fill();
          ctx.fillStyle = 'rgba(120,160,190,.8)'; rr(ctx, -Lp * 0.3, -Wp * 0.3, Lp * 0.08, Wp * 0.6, 2); ctx.fill();
          if (a.ty === 3) {   // ambulance: red stripe, cross, light bar
            ctx.fillStyle = '#e03a3a'; ctx.fillRect(-Lp / 2 + 1, -Wp / 2, Lp - 2, Wp * 0.13); ctx.fillRect(-Lp / 2 + 1, Wp / 2 - Wp * 0.13, Lp - 2, Wp * 0.13);
            ctx.fillRect(-Lp * 0.06, -Wp * 0.22, Lp * 0.12, Wp * 0.44); ctx.fillRect(-Lp * 0.15, -Wp * 0.06, Lp * 0.3, Wp * 0.12);
            const fl1 = Math.floor(now / 160) % 2;
            ctx.fillStyle = fl1 ? '#ff3030' : '#3a7bff'; ctx.fillRect(Lp * 0.05, -Wp * 0.42, Lp * 0.08, Wp * 0.36);
            ctx.fillStyle = fl1 ? '#3a7bff' : '#ff3030'; ctx.fillRect(Lp * 0.05, Wp * 0.06, Lp * 0.08, Wp * 0.36);
          }
        }
      }
      // lights: brake lights when stopped, blinkers before / during a turn
      if (a.v < 0.3 && a.cr <= 0) { ctx.fillStyle = '#ff3a3a'; ctx.fillRect(-Lp / 2, -Wp * 0.42, 1.8, Wp * 0.2); ctx.fillRect(-Lp / 2, Wp * 0.22, 1.8, Wp * 0.2); }
      const sts = a.ro.st;
      let turn = 0;
      if (a.si < sts.length && sts[a.si].t && sts[a.si].s - a.s < 2.2) turn = sts[a.si].t;
      else if (a.si > 0 && sts[a.si - 1].t && a.s < sts[a.si - 1].bo + 0.1) turn = sts[a.si - 1].t;
      if (turn && Math.floor(now / 260) % 2) { const sy = turn === 1 ? 1 : -1; ctx.fillStyle = '#ffb02e'; circ(ctx, Lp / 2 - 1.5, sy * (Wp / 2 - 1), Math.max(1.6, s * 0.035)); ctx.fill(); circ(ctx, -Lp / 2 + 1.5, sy * (Wp / 2 - 1), Math.max(1.6, s * 0.035)); ctx.fill(); }
      ctx.restore();
      if (a.ty === 3 && (a.sr || a.v > 0.3) && a.cr <= 0) { const k = 0.5 + 0.5 * Math.sin(now / 90); ctx.fillStyle = 'rgba(255,60,60,' + (0.12 + 0.12 * k) + ')'; circ(ctx, x, y, s * 0.5); ctx.fill(); }
    }
    function drawBubbles(B, now) {   // impatience bubbles over waiting drivers
      const s = lay.sc, r = Math.max(5, s * 0.1);
      for (const a of B.V) {
        if (a.cr > 0) { const k = now / 200 + a.id; for (let i = 0; i < 3; i++) { const an = k + i * TAU / 3; ctx.fillStyle = '#ffe08a'; circ(ctx, X(a.x) + Math.cos(an) * s * 0.22, Y(a.y) - s * 0.08 + Math.sin(an) * s * 0.1, Math.max(1.5, s * 0.04)); ctx.fill(); } continue; }
        if (!(a.an || (a.w > 0.4 && a.v < 0.3))) continue;
        const sh = a.an ? Math.sin(now / 30 + a.id) * 1.2 : 0, x = X(a.x) + sh, y = Y(a.y);   // on the roof
        const col = a.an || a.w > 0.85 ? '#ff4a3a' : a.w > 0.65 ? '#ff9a3a' : '#ffd24a';
        ctx.fillStyle = 'rgba(15,10,20,.8)'; circ(ctx, x, y, r + 1.5); ctx.fill();
        if (a.an) { ctx.fillStyle = '#ff4a3a'; circ(ctx, x, y, r); ctx.fill(); txt('!', x, y + 0.5, '#fff', '900 ' + Math.round(r * 1.5) + 'px ' + FONT); }
        else { ctx.strokeStyle = col; ctx.lineWidth = Math.max(2, r * 0.5); ctx.beginPath(); ctx.arc(x, y, r * 0.65, -Math.PI / 2, -Math.PI / 2 + TAU * a.w); ctx.stroke(); }
      }
    }
    function drawPeds(B, now) {
      const s = lay.sc;
      for (const p of B.P) {
        pedPos(D, p, PQ);
        let x = PQ.x, y = PQ.y;
        if (p.p < 0) {   // waiting on the corner: stand back from the kerb, in a little line
          const arm = p.a & 3; x += DX[arm] * (0.06 + p.q * 0.12) + RX(arm) * p.sd * 0.05; y += DY[arm] * (0.06 + p.q * 0.12) + RY(arm) * p.sd * 0.05;
        }
        const X0 = X(x), Y0 = Y(y), bob = p.p >= 0 ? Math.sin(now / 90 + p.id) * 0.8 : 0, rr0 = Math.max(3, s * 0.066);
        ctx.fillStyle = 'rgba(0,0,0,.28)'; circ(ctx, X0 + 1, Y0 + 1.5, rr0 * 1.25); ctx.fill();
        ctx.fillStyle = PALETTE[p.c]; ctx.beginPath(); ctx.ellipse(X0, Y0 + bob * 0.3, rr0 * 1.35, rr0 * 0.95, Math.atan2(PQ.hy, PQ.hx) + Math.PI / 2, 0, TAU); ctx.fill();
        ctx.fillStyle = SKIN[p.id % 4]; circ(ctx, X0, Y0 - rr0 * 0.15 + bob * 0.3, rr0 * 0.72); ctx.fill();
        ctx.fillStyle = '#3a2a22'; circ(ctx, X0, Y0 - rr0 * 0.35 + bob * 0.3, rr0 * 0.5); ctx.fill();
        if (p.p < 0 && p.w > 0.55) { ctx.fillStyle = p.w > 0.8 ? '#ff4a3a' : '#ffb43a'; circ(ctx, X0, Y0 - rr0 * 2, Math.max(2, rr0 * 0.55)); ctx.fill(); }
      }
    }
    function drawRain(now) {
      ctx.save(); ctx.beginPath(); ctx.rect(lay.ox, lay.oy, lay.bw, lay.bh); ctx.clip();
      ctx.fillStyle = 'rgba(30,45,80,.16)'; ctx.fillRect(lay.ox, lay.oy, lay.bw, lay.bh);
      ctx.strokeStyle = 'rgba(190,215,255,.35)'; ctx.lineWidth = 1;
      const t = now / 1000; ctx.beginPath();
      for (const r of rain) {
        const x = lay.ox + ((r[0] + t * 0.08 * r[2]) % 1) * lay.bw, y = lay.oy + ((r[1] + t * 0.9 * r[2]) % 1) * lay.bh;
        ctx.moveTo(x, y); ctx.lineTo(x - 3, y + 9);
      }
      ctx.stroke(); ctx.restore();
    }
    function drawBoard(now) {
      const B = KS[view];
      const sh = shake > 0 ? (Math.random() - 0.5) * shake * 6 : 0;
      ctx.save(); ctx.translate(sh, 0);
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, lay.ox - 6, lay.oy - 3, lay.bw + 12, lay.bh + 12, 12); ctx.fill();
      ctx.drawImage(staticLayer(), lay.ox - 8, lay.oy - 8, lay.bw + 16, lay.bh + 16);
      if (B) {
        ctx.save(); ctx.beginPath(); ctx.rect(lay.ox, lay.oy, lay.bw, lay.bh); ctx.clip();
        drawLights(B, now);
        for (const a of B.V) drawVehicle(a, now);
        drawPeds(B, now);
        drawBubbles(B, now);
        ctx.restore();
        if (D.rain) drawRain(now);
        drawPosts(B, now);
      }
      ctx.restore();
      const s = lay.sc;
      for (const q of parts) {
        const f = q.t / q.T, x = X(q.x), y = Y(q.y);
        ctx.globalAlpha = Math.min(1, f * 1.6); ctx.fillStyle = q.c; circ(ctx, x, y, q.r * s * (q.k === 'smoke' ? 2.2 : 1)); ctx.fill();
      }
      ctx.globalAlpha = 1;
      for (const q of floats) {
        if (q.hud != null) continue;
        const f = q.t / q.T, x = X(q.x), y = Math.max(lay.oy + 8, Y(q.y) - (1 - f) * s * 0.6);
        ctx.globalAlpha = Math.min(1, f * 2.2);
        const font = (q.big ? '800 14px ' : '700 11px ') + FONT;
        ctx.font = font; const tw = ctx.measureText(q.text).width;
        const xx = U.clamp(x, tw / 2 + 8, lay.w - tw / 2 - 8);
        ctx.fillStyle = 'rgba(15,10,20,.75)'; rr(ctx, xx - tw / 2 - 5, y - 10, tw + 10, 20, 8); ctx.fill();
        txt(q.text, xx, y + 0.5, q.col, font);
      }
      ctx.globalAlpha = 1;
      // conditions (rain / rush hour / roadwork) in the board's top-left corner
      let px = lay.ox + 6;
      const pill = (t, col, bg) => { ctx.font = '700 10px ' + FONT; const w = ctx.measureText(t).width + 12; ctx.fillStyle = bg; rr(ctx, px, lay.oy + 6, w, 18, 9); ctx.fill(); txt(t, px + w / 2, lay.oy + 15.5, col, '700 10px ' + FONT); px += w + 4; };
      if (D.rain) pill('비 · 잘 안 멈춰요', '#cfe2ff', 'rgba(30,50,90,.85)');
      const rk = B ? rushK(D, B.t) : 1;
      if (rk > 1.15) pill('러시아워 ×' + rk.toFixed(1), '#ffe08a', 'rgba(110,60,10,.88)');
    }
    function drawHud() {
      const w = lay.w, Hh = lay.hudH, B = KS[view], r = rowOf(view);
      ctx.fillStyle = 'rgba(14,10,20,.6)'; ctx.fillRect(0, 0, w, Hh);
      txt(isMine(view) ? '내 점수' : fitText(name(view), 70, '700 10px ' + FONT), 10, 10, '#ab9fb8', '700 10px ' + FONT, 'left');
      txt(String(r[0]), 10, 27, '#ffe08a', '800 19px ' + MONO, 'left');
      ctx.font = '800 19px ' + MONO; const sw = ctx.measureText(String(r[0])).width;
      const hp = r[1], hx = Math.max(24 + sw, w * 0.36);
      for (let i = 0; i < HEARTS; i++) heart(hx + i * 19, 21, 7, i < hp);
      txt('통과 ' + r[2], hx + HEARTS * 19 + 4, 21, '#d8cce4', '700 11px ' + FONT, 'left');
      let s, col = '#bfe8ff';
      if (tl < 0 && st.ph === 'play') { s = '준비'; col = '#e3ae45'; }
      else if (B && B.ph === 2) { s = '교통 마비'; col = '#ff9a7a'; }
      else { const left = Math.max(0, Math.ceil(D.dur - (B ? B.t : Math.max(0, tl)))); s = Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0'); col = left <= 10 ? '#ff9a7a' : '#bfe8ff'; }
      ctx.font = '800 14px ' + MONO; const pw = Math.max(54, ctx.measureText(s).width + 20);
      ctx.fillStyle = 'rgba(46,38,64,.95)'; rr(ctx, w - pw - 8, 8, pw, 24, 12); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1.2; ctx.stroke();
      txt(s, w - 8 - pw / 2, 20.5, col, '800 14px ' + (s.indexOf(':') > 0 ? MONO : FONT));
    }
    function drawStrip() {
      const y0 = lay.hudH, Hs = lay.stripH, w = lay.w;
      if (st.n === 1) {
        const p = parOf(st), B = KS[view], sc = B ? B.sc : 0, done = !!B && B.ph === 3;
        const items = [['★', '끝까지 버티기', done], ['★★', p[0] + '점', sc >= p[0] && (!B || B.ph !== 2)], ['★★★', p[1] + '점', sc >= p[1] && (!B || B.ph !== 2)]];
        const cw = (w - 20) / 3;
        items.forEach(([s2, t2, on], i) => txt(fitText(s2 + ' ' + t2, cw - 4, '700 11px ' + FONT), 10 + cw * i + cw / 2, y0 + Hs / 2, on ? '#ffd24a' : '#8a7f98', '700 11px ' + FONT));
        return;
      }
      const cw = (w - 12) / st.n, rows = [];
      for (let s = 0; s < st.n; s++) rows.push(rowOf(s));
      const rank = rows.map((r, s) => s).sort((a, b) => rows[b][0] - rows[a][0] || a - b);
      for (let s = 0; s < st.n; s++) {
        const r = rows[s], x = 6 + cw * s, selv = s === view, P = Pl(s);
        ctx.fillStyle = selv ? 'rgba(227,174,69,.2)' : 'rgba(46,38,64,.85)'; rr(ctx, x + 2, y0 + 3, cw - 4, Hs - 6, 9); ctx.fill();
        if (selv) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.stroke(); }
        ctx.fillStyle = P.color || '#888'; rr(ctx, x + 2, y0 + 3, 4, Hs - 6, 2); ctx.fill();
        txt(fitText((rank.indexOf(s) + 1) + '. ' + name(s), cw - 18, '700 10px ' + FONT), x + 10, y0 + 14, '#f2e9d8', '700 10px ' + FONT, 'left');
        txt(String(r[0]), x + 10, y0 + 30, '#ffe08a', '800 13px ' + MONO, 'left');
        ctx.font = '800 13px ' + MONO; const nw = ctx.measureText(String(r[0])).width;
        const hearts = '♥'.repeat(Math.max(0, r[1]));
        if (r[4] === 1) txt('마비', x + 14 + nw, y0 + 30, '#ff9a7a', '700 10px ' + FONT, 'left');
        else txt(hearts, x + 14 + nw, y0 + 30, '#ff5a6e', '700 10px ' + FONT, 'left');
      }
      for (const q of floats) {
        if (q.hud == null) continue;
        const f = q.t / q.T, x = 6 + cw * q.hud + cw - 8, y = y0 + 30 - (1 - f) * 8;
        ctx.globalAlpha = Math.min(1, f * 2); ctx.font = '800 11px ' + MONO; const tw = ctx.measureText(q.text).width;
        ctx.fillStyle = 'rgba(20,14,24,.9)'; rr(ctx, x - tw - 8, y - 9, tw + 8, 18, 9); ctx.fill();
        txt(q.text, x - 4, y + 0.5, q.col, '800 11px ' + MONO, 'right'); ctx.globalAlpha = 1;
      }
    }
    function drawHint(now) {
      const B = KS[view];
      let s = '', col = '#d8cce4';
      if (!isMine(view) && mine().length && st.ph === 'play') s = name(view) + '의 마을을 보는 중 · 위 칸을 눌러 바꿔요';
      else if (B && isMine(view) && !auto() && tl >= 0 && B.ph === 1 && QA) {
        if (QA.ambR) { s = '구급차가 빨간불에 걸렸어요! 그쪽을 초록불로'; col = '#ffb0a0'; }
        else if (QA.ang) { s = '화난 차가 빨간불에 달려요! 사고 조심'; col = '#ffb0a0'; }
        else if (D.lt && QA.lfG) { s = '좌회전 차가 앞을 막고 있어요 → ↰ 좌회전'; col = '#ffd08a'; }
        else { let hot = false; for (let k = 0; k < QA.q.length; k++) if (QA.q[k] && QA.w[k] > 0.6) hot = true; s = hot ? '게이지가 찬 쪽 신호를 바꿔 줘요' : D.nI > 1 ? '교차로를 톡 = 그 교차로 초록불 ↕↔' : '교차로를 톡 = 초록불 ↕↔ 바꾸기'; if (hot) col = '#ffd08a'; }
      }
      if (!s) return;
      txt(fitText(s, lay.w - 20, '600 12px ' + FONT), lay.w / 2, lay.hintY, col, '600 12px ' + FONT);
    }
    function controlTip() {
      if (kbUsed || FINE) {
        const b = (api.input && api.input.bindings) ? api.input.bindings() : [];
        const kn = (id) => { const x = b.find((o) => o.id === id); return x && x.keys[0] ? (KEYN[x.keys[0]] || x.keys[0].replace(/^Key/, '').replace(/^Digit/, '')) : '?'; };
        return '교차로를 클릭하거나, 방향키로 고르고 ' + kn('toggle') + '로 바꿔요. 숫자 1~' + D.nI + ' = 그 교차로 바로 바꾸기' + (D.lt ? ', ' + kn('arrow') + ' = 좌회전 신호' : '') + '.';
      }
      return '교차로를 톡 누르면 초록불이 ↕ ↔ 로 바뀌어요(노란불 → 빨간불 → 초록불).' + (D.lt ? ' ↰ 버튼 = 좌회전 신호.' : '');
    }
    function drawReady() {
      const w = Math.min(lay.w - 28, 340), x = (lay.w - w) / 2;
      const S = st.stg >= 0 && st.stg < STAGES.length ? STAGES[st.stg] : null;
      const tip = S ? S.tip : (st.n > 1 ? '모두 같은 마을, 같은 차들! 사고 없이 더 많이 통과시키면 승리.' : '처음 보는 마을! 줄이 긴 쪽, 게이지가 찬 쪽부터.');
      const tipFont = '600 13px ' + FONT, ctlFont = '500 12px ' + FONT;
      const tipL = wrap(tip, w - 32, tipFont), ctlL = wrap(controlTip(), w - 32, ctlFont);
      const goalL = wrap('차 10 · 트럭 15 · 버스 30 · 구급차 30 · 건넌 사람 5 · 신호 위반 −10 · 사고 ♥ −1', w - 32, ctlFont);
      const h = 76 + tipL.length * 18 + 8 + ctlL.length * 16 + 6 + goalL.length * 16;
      const y = lay.oy + Math.max(10, (lay.bh - h) * 0.35);
      panel(x, y, w, h);
      txt(S ? '스테이지 ' + (st.stg + 1) : (st.n > 1 ? '신호등 대결' : '무작위 마을'), lay.w / 2, y + 18, '#e3ae45', '700 12px ' + FONT);
      txt(fitText(S ? S.n : (LAYS[D.P.lay] || LAYS[0]).nm, w - 80, '400 22px ' + DISP), lay.w / 2, y + 42, '#f2e9d8', '400 22px ' + DISP);
      let yy = y + 66;
      tipL.forEach((l) => { txt(l, lay.w / 2, yy, '#f2e9d8', tipFont); yy += 18; });
      yy += 8; ctlL.forEach((l) => { txt(l, lay.w / 2, yy, '#c9bcd6', ctlFont); yy += 16; });
      yy += 6; goalL.forEach((l) => { txt(l, lay.w / 2, yy, '#bfe8ff', ctlFont); yy += 16; });
      txt(String(Math.max(1, Math.ceil(-tl))), x + w - 22, y + 20, '#ffd24a', '800 22px ' + MONO);
      if (st.n === 1 && !api.online) { ctx.fillStyle = 'rgba(18,12,24,.85)'; rr(ctx, lay.w / 2 - 62, y + h + 6, 124, 22, 11); ctx.fill(); txt('톡 눌러 바로 시작', lay.w / 2, y + h + 17, '#d8cce4', '600 11px ' + FONT); }
    }
    function drawDone() {
      const B = KS[view];
      if (!B || B.ph === 1 || !isMine(view) || auto()) return;
      const multi = st.n > 1 && st.ph === 'play';
      const w = Math.min(lay.w - 36, 310), hh = multi ? 92 : 74, x = (lay.w - w) / 2, y = lay.oy + lay.bh * 0.3;
      panel(x, y, w, hh);
      const ok = B.ph === 3;
      txt(ok ? '시간 끝! 수고했어요' : '교통 마비!', lay.w / 2, y + 24, ok ? '#9dffb0' : '#ffb0a0', '400 21px ' + DISP);
      txt(B.sc + '점 · 통과 ' + B.ps + '대 · 사고 ' + B.cr + (bestNew ? ' · 최고 기록!' : ''), lay.w / 2, y + 51, '#f2e9d8', '700 13px ' + FONT);
      if (multi) txt(fitText('다른 사람을 기다리는 중…', w - 16, '600 11px ' + FONT), lay.w / 2, y + 74, '#c9bcd6', '600 11px ' + FONT);
    }
    function draw(now) {
      const w = cv.w, h = cv.h;
      if (!lay || lay.w !== w || lay.h !== h) layout();
      cv.clear();
      if (!lay.bg) { lay.bg = ctx.createRadialGradient(w / 2, h * 0.45, 20, w / 2, h * 0.45, Math.max(w, h) * 0.75); lay.bg.addColorStop(0, '#231d33'); lay.bg.addColorStop(1, '#120e18'); }
      ctx.fillStyle = lay.bg; ctx.fillRect(0, 0, w, h);
      if (!st || st.ph === 'pick') return;
      if (!key || !D) { txt('준비 중…', w / 2, h / 2, '#ab9fb8', '600 14px ' + FONT); return; }
      drawBoard(now);
      drawHud();
      drawStrip();
      drawHint(now);
      if (tl < 0 && st.ph === 'play') drawReady();
      else drawDone();
    }

    const stop = U.loop(frame);
    root._tf = { lay: () => lay, B: () => KS[view], KS: () => KS, tl: () => tl, view: () => view, D: () => D, sel: () => sel, cross: (ix) => { const c = ctr(D, ix); return { x: X(c[0]), y: Y(c[1]) }; }, leftBtn: (ix) => { const c = leftBtnPos(ctr(D, ix)); return { x: X(c[0]), y: Y(c[1]) }; } }; // test hook
    return {
      update(state) {
        st = state;
        if (!st) return;
        if (st.ph === 'pick') { key = null; KS = []; D = null; }
        else if (pick) dropPicker();
        if (st.ph === 'done' && key === curKey()) tl = Math.max(tl, 0);
        if (lay && lay.stripH !== (st.n > 1 ? 44 : 24)) layout();
      },
      destroy() {
        stop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerleave', onLeave);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        dropPicker();
        cv.destroy(); styleEl.remove();
      },
    };
  }

  L.register({
    id: 'traffic', name: '신호등 지휘관', tag: '실시간 교통 관제', cat: '아케이드',
    blurb: '교차로를 톡톡 눌러 신호를 바꿔, 사고 없이 차를 많이 통과시켜요! 오래 기다린 차는 화가 나서 빨간불에 달려요. 모두 같은 마을로 겨루고, 혼자 하면 스테이지 14개.',
    tint: '#2f5a3a',
    icon: '<rect x="20" y="4" width="16" height="40" rx="6" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="28" cy="14" r="4.5" fill="currentColor"/><circle cx="28" cy="24" r="4.5" fill="currentColor" opacity=".55"/><circle cx="28" cy="34" r="4.5" fill="currentColor" opacity=".3"/><rect x="25" y="44" width="6" height="9" fill="currentColor"/><path d="M6 50h14M36 50h14" stroke="currentColor" stroke-width="4" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'up', label: '위쪽 교차로 고르기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래쪽 교차로 고르기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽 교차로 고르기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽 교차로 고르기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'toggle', label: '고른 교차로 신호 바꾸기', keys: ['Space', 'KeyJ', 'Enter'], pad: ['a'] },
      { id: 'arrow', label: '고른 교차로 좌회전 신호(↰)', keys: ['KeyF', 'KeyK'], pad: ['x'] },
      { id: 'i1', label: '1번 교차로 바로 바꾸기', keys: ['Digit1', 'Numpad1'], pad: [] },
      { id: 'i2', label: '2번 교차로 바로 바꾸기', keys: ['Digit2', 'Numpad2'], pad: [] },
      { id: 'i3', label: '3번 교차로 바로 바꾸기', keys: ['Digit3', 'Numpad3'], pad: [] },
      { id: 'i4', label: '4번 교차로 바로 바꾸기', keys: ['Digit4', 'Numpad4'], pad: [] },
      { id: 'view', label: '다른 사람 판 보기 (내 판이 끝난 뒤)', keys: ['KeyV'], pad: ['lb'] },
    ],
    options: [
      { id: 'city', label: '마을', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '작은 마을' }, { v: 1, label: '큰 도시' }], def: -1 },
      { id: 'time', label: '시간', choices: [{ v: 60, label: '1분' }, { v: 90, label: '1분 30초' }, { v: 120, label: '2분' }], def: 90 },
    ],
    quick: [
      '교차로를 톡 누르면 초록불 방향이 바뀌어요(↕ ↔). 차들은 빨간불에 서서 기다려요.',
      '오래 기다린 차는 게이지가 차서 화가 나면 빨간불에 달려요(−10). 옆 차와 부딪히면 사고(♥ −1)!',
      '빠져나간 차·건넌 사람만큼 점수! 시간이 끝났을 때 점수가 가장 높으면 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '모두 똑같은 장난감 마을에서, 똑같은 순서로 들어오는 차들을 각자 신호등으로 지휘해요.',
        '시간이 끝났을 때 점수가 가장 높은 사람이 승리! 하트(♥ 3개)를 다 잃으면 내 마을은 교통 마비로 끝나요(점수는 그대로).',
        '혼자 하면 스테이지 14개(+무작위 마을)에서 별을 모아요.',
      ] },
      { h: '하는 법', p: [
        '교차로(네거리)를 톡 누르면 초록불이 세로(↕) ↔ 가로(↔)로 바뀌어요. 바로 바뀌지 않고 노란불 1.6초 → 모두 빨간불 0.8초 → 초록불 순서예요.',
        '바뀌는 중에는 다시 눌러도 안 돼요. 그래서 너무 자주 바꾸면 차가 못 지나가요.',
        '교차로 네 귀퉁이의 동그란 신호등에 그 방향 신호 색과 기다리는 차 수가 보여요. 바깥 고리는 맨 앞 차들의 기다림 게이지예요.',
        '판 가장자리의 「+3」은 줄이 길어서 아직 마을에 못 들어온 차예요. 6대가 넘게 밀리면 돌아가 버려요(−5).',
      ] },
      { h: '기다림 · 사고', p: [
        '빨간불에 서 있는 차는 기다림 게이지가 차요(승용차 약 11초, 버스 13초). 노랑 → 주황 → 빨강.',
        '게이지가 다 차면 "빵빵!" 화가 나서 빨간불에 그냥 달려요: 신호 위반 −10.',
        '그때 옆 방향 차가 달리고 있으면 쾅! 사고: ♥ −1, −30점. 부서진 차는 3초 동안 길을 막아요.',
        '노란불에 이미 가까이 온 차는 못 멈추고 지나가요(벌점 없음). 비가 오면 브레이크가 덜 들어서 이런 차가 많아져요.',
      ] },
      { h: '점수', p: [
        '마을을 빠져나간 승용차 10, 트럭 15, 버스 30, 구급차 30점. 구급차가 한 번도 안 서고 지나가면 +20 더!',
        '횡단보도를 건넌 사람 +5. 사람은 나란한 찻길이 초록불일 때 건너요. 16초 넘게 기다리면 돌아가요(−10).',
        '구급차를 빨간불에 3초 넘게 세워 두면 −40(사이렌을 켜고 조심조심 지나가요).',
        '점수는 0점 아래로 내려가지 않아요.',
      ] },
      { h: '여러 가지 마을', p: [
        '깜빡이: 오른쪽 깜빡이 차는 초록불에 오른쪽으로 돌아요(사람이 건너면 기다려요).',
        '좌회전(↰): 왼쪽 깜빡이 차는 초록불이고 맞은편에서 오는 차가 없을 때만 돌아요(비보호 좌회전). 맞은편 차가 계속 오면 맨 앞에서 기다리며 뒤 차까지 막아요.',
        '↰ 버튼 = 맨 앞에서 기다리는 좌회전 차 쪽에 좌회전 신호(그쪽 직진은 멈춰요). 그다음 교차로를 누르면 같은 쪽 직진 신호로 돌아가요.',
        '비: 브레이크가 덜 들어요. 공사: 주황 구간은 아주 천천히 지나가요. 러시아워: 중간쯤 차가 확 몰려요.',
        '차는 교차로 건너편이 꽉 막혔으면 초록불이어도 들어가지 않아요(꼬리 물기 금지).',
      ] },
      { h: '혼자 하기 (스테이지)', p: [
        '스테이지 14개는 차가 들어오는 순서가 늘 같아요. 해 볼수록 잘하게 돼요.',
        '끝까지 버티면(♥ 남기고 시간 끝) ★, 기준 점수를 넘기면 ★★·★★★(위쪽에 기준 점수가 보여요). 교통 마비면 별이 없어요.',
        '「무작위 마을」은 매번 새 마을이에요. 옵션 「마을」·「시간」은 대결과 무작위 마을에 써요.',
      ] },
      { h: '함께 하기', p: [
        '실시간 게임이라 한 폰에서는 한 명만 해요. 혼자 하면 나머지 자리는 AI예요(각자 자기 마을).',
        '친구와는 온라인·LAN 방으로: 각자 폰에서 자기 마을을 지휘하고, 위쪽 칸에서 서로의 점수와 하트가 보여요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 늦게 보고 가끔 엉뚱하게 바꿔요. 어려움은 빠르고 게이지·구급차·좌회전을 잘 챙겨요.',
      ] },
      { h: 'PC 조작', p: [
        '마우스로 교차로를 클릭하면 바뀌어요. 교차로마다 작은 번호가 보여요.',
        '키보드·게임패드: 방향키·WASD·왼스틱 = 교차로 고르기, 스페이스·J·Enter·Ⓐ = 고른 교차로 바꾸기, 숫자 1~4 = 그 번호 교차로 바로 바꾸기, F·K·Ⓧ = 좌회전 신호, V·LB = 다른 판 보기. 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '예시', p: [
        '세로(↕) 초록불이에요. 가로 쪽 신호등에 「4」와 주황 고리가 보여요 → 가로 차 4대가 꽤 기다렸어요.',
        '세로 쪽에 다가오는 차가 끊긴 순간 교차로를 톡! 노란불·빨간불 뒤 가로(↔)가 초록불이 되고 4대가 차례로 빠져나가요(+40).',
        '그동안 세로 쪽에 또 줄이 생기면 게이지가 빨개지기 전에 다시 톡!',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { STAGES, STAR_PAR, LAYS, VT, AIP, DT, genDef, randParams, newBoard, stepB, toggleB, leftB, frontLeft, aiInit, aiThink, analyze, potential, defOf, init, startStage, finish, result, starsOf, parOf, routeOf, rpos, lightOK },
  });
})();
