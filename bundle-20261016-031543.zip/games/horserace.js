/* 경마 응원전 — realtime cheering horse race (2–6). Everyone picks a horse and cheers by tapping their own zone:
   taps in the green tempo band push the horse best, frantic mashing drains its stamina. Hurdles need one timed tap,
   rain makes the track heavy, the last stretch is a "스퍼트!" window. Host-authoritative fixed-step race (1/60 s);
   guests publish cumulative tap-quality counters + jump judgements and receive ~16 Hz snapshots.
   One person per phone (the rest of a local game are AI); friends play via online / LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const H = 1 / 60;
  const VB = 19;                 // base gallop speed (m/s)
  const TIRED = 2.2, JW = 0.75, JP0 = 0.08, JP1 = 0.38; // tired time, jump window (s to the hurdle), perfect band
  const AFTER = 12, COUNT = 3, END_T = 4.6;
  const HORSES = [
    { n: '번개', c: '#9a5f2c', m: '#2a1a12' }, { n: '흑진주', c: '#2c2427', m: '#0d0a0b' },
    { n: '백설', c: '#ece6da', m: '#c9c0b2' }, { n: '황금빛', c: '#d1a254', m: '#f3e2b8' },
    { n: '얼룩이', c: '#e2dacb', m: '#3a302a', sp: 1 }, { n: '적토', c: '#a9452a', m: '#5c1e10' },
    { n: '잿빛', c: '#8f8c92', m: '#3d3a40' }, { n: '초코', c: '#5e3c24', m: '#24150c' },
  ];
  const TRACKS = [
    { id: 'turf', name: '푸른 잔디', sub: '기본 잔디 주로 · 허들 2개', spd: 1, cost: 1, obs: 2, rain: 0.35, g1: '#2f6d36', g2: '#377c3d' },
    { id: 'steeple', name: '장애물 코스', sub: '허들 4개와 물웅덩이 1개', spd: 1, cost: 1, obs: 5, rain: 0.3, water: 1, g1: '#2d6634', g2: '#34743a' },
    { id: 'dirt', name: '진흙 모래길', sub: '무거운 모래 · 체력이 더 닳고 비가 자주 와요', spd: 0.94, cost: 1.15, obs: 3, rain: 0.6, g1: '#8a6541', g2: '#7f5c3a' },
  ];
  const LENS = [500, 800, 1200];
  /* tap effects: [cheer gain, stamina cost] by quality — g green tempo, f a bit fast, m frantic mash, s slow, o first/after a pause */
  const TAP_N = { g: [0.15, 0.55], f: [0.08, 1.5], m: [0.035, 3.0], s: [0.12, 0.35], o: [0.06, 0.3] };
  const TAP_S = { g: [0.16, 1.0], f: [0.12, 1.7], m: [0.06, 2.6], s: [0.11, 0.6], o: [0.06, 0.4] };
  const r1 = (v) => Math.round(v * 10) / 10;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const fin = (v) => typeof v === 'number' && isFinite(v);
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); }

  /* green tempo band (seconds between taps) */
  function band(sprint, rain) {
    let lo = 0.22, hi = 0.36;
    if (sprint) { lo = 0.12; hi = 0.24; }
    if (rain) { lo += 0.03; hi += 0.04; }
    return [lo, hi];
  }
  function tapCat(iv, sprint, rain) {
    if (!(iv < 0.9)) return 'o';
    const [lo, hi] = band(sprint, rain);
    if (iv < lo * 0.6) return 'm';
    if (iv < lo) return 'f';
    if (iv <= hi) return 'g';
    return 's';
  }
  function newRace(tr, ln, sd, n) {
    const T = TRACKS[clamp(tr | 0, 0, TRACKS.length - 1)], rnd = prng(sd);
    const obs = [], k = T.obs, span = 0.62;
    for (let i = 0; i < k; i++) {
      const f = 0.14 + span * (i + 0.5) / k + (rnd() - 0.5) * 0.45 * span / k;
      obs.push({ x: Math.round(ln * f), w: T.water && i === Math.floor(k / 2) ? 1 : 0 });
    }
    const rainAt = rnd() < T.rain ? Math.round(ln * (0.18 + rnd() * 0.37)) : -1;
    const spr = Math.round(ln - Math.max(120, ln * 0.16));
    const hs = [];
    for (let i = 0; i < n; i++) hs.push({ p: 0, v: 0, ch: 0.3, en: 100, td: 0, st: 0, sm: 1, bt: 0, ob: 0, jr: '', jx: -99, lt: -9, ft: -1, sp: 0, tc: 0, last: '' });
    return { T, tr: tr | 0, ln, sd, n, t: 0, obs, rainAt, rain: 0, spr, hs, ev: [], evId: 0, lead: -1, leadT: 0, firstFt: -1, sprAnn: 0 };
  }
  function pushEv(R, type, seat, hooks) {
    R.evId = (R.evId + 1) % 100000;
    R.ev.push([R.evId, type, seat]);
    if (R.ev.length > 4) R.ev.shift();
    if (hooks && hooks.ev) hooks.ev(type, seat);
  }
  const inSprint = (R, h) => h.p >= R.spr;
  /* time (s) until horse i reaches its next unresolved hurdle, or −1 */
  function hurdleTT(R, i) {
    const h = R.hs[i], o = R.obs[h.ob];
    if (!o || h.jr || h.ft >= 0) return -1;
    const d = o.x - h.p;
    if (d < -1) return -1;
    return Math.max(0, d) / Math.max(h.v, 4);
  }
  function judge(tt) { return tt > JP1 ? 'E' : tt >= JP0 ? 'P' : 'L'; }
  /* resolve the current hurdle with q: P perfect, L late, E early, C crash (no jump) */
  function resolveJump(R, i, q, hooks) {
    const h = R.hs[i], o = R.obs[h.ob];
    if (!o || h.jr) return false;
    h.jr = q; h.jx = o.x;
    if (q === 'P') { h.bt = 0.9; h.ch = Math.min(1, h.ch + 0.2); }
    else if (q === 'L') { h.st = 0.35; h.sm = 0.8; }
    else if (q === 'E') { h.st = 0.9; h.sm = 0.5; h.v *= 0.7; }
    else { h.st = 1.3; h.sm = 0.35; h.v *= 0.45; h.en = Math.max(0, h.en - 8); }
    if (q === 'P' || q === 'C' || q === 'E') pushEv(R, q === 'P' ? 'jump' : q === 'C' ? 'crash' : 'early', i, hooks);
    else if (hooks && hooks.ev) hooks.ev('late', i);
    return true;
  }
  /* one cheer tap of quality cat */
  function applyTap(R, i, cat, hooks) {
    const h = R.hs[i];
    if (!h || h.ft >= 0 || h.td > 0) return false;
    const e = (inSprint(R, h) ? TAP_S : TAP_N)[cat] || TAP_N.o;
    h.ch = Math.min(inSprint(R, h) ? 1.35 : 1, h.ch + e[0]);
    h.en -= e[1] * (R.rain ? 1.35 : 1) * R.T.cost;
    h.lt = R.t; h.last = cat; h.tc++;
    if (h.en <= 0) { h.en = 0; h.td = TIRED; pushEv(R, 'tired', i, hooks); }
    return true;
  }
  /* a tap from a local person or an AI: a jump when a hurdle is close, otherwise a cheer (iv = seconds since the last tap) */
  function tapAt(R, i, iv, hooks) {
    const tt = hurdleTT(R, i);
    if (tt >= 0 && tt <= JW && R.hs[i].td <= 0) { const q = judge(tt); resolveJump(R, i, q, hooks); return 'j' + q; }
    const h = R.hs[i];
    const cat = tapCat(iv, inSprint(R, h), R.rain);
    return applyTap(R, i, cat, hooks) ? cat : '';
  }
  function targetSpeed(R, h) {
    const sp = inSprint(R, h);
    let v = VB * R.T.spd * (R.rain ? 0.9 : 1) * (0.55 + 0.5 * Math.min(h.ch, sp ? 1.3 : 1));
    if (h.td > 0) v *= 0.6; else if (h.en < 20) v *= 0.85 + 0.15 * h.en / 20;
    if (sp) v *= 1 + 0.18 * h.en / 100;
    if (h.st > 0) v *= h.sm;
    if (h.bt > 0) v *= 1.12;
    return v;
  }
  /* rem[i] = true when seat i is controlled from another phone (its jump judgement arrives late) */
  function stepRace(R, dt, hooks, rem) {
    R.t += dt;
    let lp = -1, leader = -1;
    for (let i = 0; i < R.n; i++) { const h = R.hs[i]; if (h.ft < 0 && h.p > lp) { lp = h.p; leader = i; } }
    if (!R.rain && R.rainAt >= 0 && lp >= R.rainAt) { R.rain = 1; pushEv(R, 'rain', -1, hooks); }
    for (let i = 0; i < R.n; i++) {
      const h = R.hs[i];
      if (h.ft >= 0) { h.v += (7 - h.v) * Math.min(1, 1.5 * dt); h.p += h.v * dt; continue; }
      if (h.td > 0) h.td -= dt;
      if (h.st > 0) h.st -= dt;
      if (h.bt > 0) h.bt -= dt;
      const sp = inSprint(R, h);
      if (sp && !h.sp) { h.sp = 1; if (!R.sprAnn) { R.sprAnn = 1; pushEv(R, 'sprint', i, hooks); } }
      h.ch = Math.max(0, h.ch - h.ch * (h.td > 0 ? 1.2 : sp ? 0.8 : 0.5) * dt);
      const reg = h.td > 0 ? 14 : sp ? 0 : R.t - h.lt > 0.6 ? 7 : 2.5;
      h.en = Math.min(100, h.en + reg * dt);
      const tv = targetSpeed(R, h);
      h.v += (tv - h.v) * Math.min(1, (tv > h.v ? 2.2 : 3) * dt);
      const p0 = h.p;
      h.p += h.v * dt;
      // hurdles
      const o = R.obs[h.ob];
      if (o) {
        if (h.jr) { if (h.p > o.x + 4) { h.ob++; h.jr = ''; } }
        else if (h.p >= o.x + (rem && rem[i] ? Math.max(3, h.v * 0.35) : 0)) resolveJump(R, i, 'C', hooks);
      }
      if (h.p >= R.ln) {
        h.ft = R.t - (h.p - R.ln) / Math.max(1, h.p - p0) * dt;
        if (R.firstFt < 0) { R.firstFt = h.ft; pushEv(R, 'fin', i, hooks); }
        else if (h.ft - R.firstFt < 0.08 && R.hs.filter((q) => q.ft >= 0).length === 2) pushEv(R, 'photo', i, hooks);
        if (hooks && hooks.fin) hooks.fin(i);
      }
    }
    if (leader >= 0 && leader !== R.lead) {
      if (R.lead >= 0 && R.t > 2.5 && R.t - R.leadT > 2) pushEv(R, 'lead', leader, hooks);
      R.lead = leader; R.leadT = R.t;
    }
  }
  function raceOver(R) {
    if (R.hs.every((h) => h.ft >= 0)) return true;
    if (R.firstFt >= 0 && R.t > R.firstFt + AFTER) return true;
    return R.t > R.ln / 7 + 40;
  }
  /* finishing order [[seat, centiseconds or −1], …] */
  function order(R) {
    return R.hs.map((h, i) => [i, h.ft, h.p]).sort((a, b) => {
      if (a[1] >= 0 && b[1] >= 0) return a[1] - b[1] || a[0] - b[0];
      if (a[1] >= 0) return -1; if (b[1] >= 0) return 1;
      return b[2] - a[2] || a[0] - b[0];
    }).map((x) => [x[0], x[1] >= 0 ? Math.round(x[1] * 100) : -1]);
  }

  /* ----- AI: rhythm accuracy and hurdle timing by level ----- */
  const AIC = {
    1: { iv: 0.31, sd: 0.07, mash: 0.1, jsd: 0.17, miss: 0.1, careless: 0.35, rest: 0, spr: 0.15, sprAt: 0.6 },
    2: { iv: 0.29, sd: 0.035, mash: 0.03, jsd: 0.08, miss: 0.02, careless: 0.08, rest: 15, spr: 0.19, sprAt: 0.92 },
    3: { iv: 0.29, sd: 0.031, mash: 0.012, jsd: 0.068, miss: 0.01, careless: 0.045, rest: 20, spr: 0.187, sprAt: 0.95 }, // beats 보통 in ~3/4 of races
  };
  function aiStep(R, i, mem, lv, hooks) {
    const C = AIC[lv] || AIC[2], h = R.hs[i];
    if (h.ft >= 0) return;
    if (mem.nt == null) mem.nt = R.t + 0.15 + Math.random() * 0.25 * (4 - (lv || 2));
    if (h.td > 0) { mem.nt = R.t + 0.25; return; }
    const tt = hurdleTT(R, i);
    if (tt >= 0 && tt <= 1.2) {
      if (mem.jo !== h.ob) { mem.jo = h.ob; mem.jt = clamp(0.23 + gauss() * C.jsd, 0.01, 0.9); mem.miss = Math.random() < C.miss; mem.cl = Math.random() < C.careless; }
      if (tt <= mem.jt && !mem.miss && !mem.cl) { tapAt(R, i, R.t - h.lt, hooks); mem.nt = R.t + 0.2; return; }
      if (tt <= JW && !mem.cl) return; // hold the cheering until the jump
    }
    if (R.t < mem.nt) return;
    if (mem.bu > 0) mem.bu -= R.t - (mem.bt0 || R.t);
    mem.bt0 = R.t;
    const sp = inSprint(R, h);
    let iv;
    if (sp) {
      const sprinting = (R.ln - h.p) < (R.ln - R.spr) * C.sprAt || lv <= 1;
      iv = sprinting && h.en > (lv >= 3 ? 6 : 0) ? C.spr + gauss() * C.sd : 0.3 + gauss() * C.sd;
    } else {
      if (!(mem.bu > 0) && Math.random() < C.mash * 0.35) mem.bu = 0.4 + Math.random() * 0.5;
      iv = mem.bu > 0 ? 0.09 + Math.random() * 0.03 : C.iv + (R.rain ? 0.035 : 0) + gauss() * C.sd;
      if (C.rest && h.en < C.rest) iv = 0.42 + gauss() * C.sd;
    }
    mem.nt = R.t + clamp(iv, 0.06, 0.8);
    tapAt(R, i, R.t - h.lt, hooks);
  }

  /* ======================= state (coarse, via api.setState / actions) ======================= */
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    const tp = [0, 1, 2].includes(o.track) ? o.track : -1;
    const hs = Array(n).fill(-1);
    const free = U.shuffle([0, 1, 2, 3, 4, 5, 6, 7]);
    players.forEach((p, i) => { if (p && p.ai) hs[i] = free.pop(); });
    const s = {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      hs, tp, tr: tp >= 0 ? tp : U.rand(TRACKS.length), ln: LENS.includes(o.len) ? o.len : 800, bo: o.match === 3 ? 3 : 1,
      rd: 1, sd: 1 + U.rand(2147483646), ph: 'pick', wins: Array(n).fill(0), pts: Array(n).fill(0), fin: [], res: null,
    };
    if (hs.every((x) => x >= 0)) s.ph = 'count';
    return s;
  }
  function actor(s) {
    if (!s || s.ph !== 'pick') return null;
    const a = []; s.hs.forEach((x, i) => { if (x < 0) a.push(i); });
    return a.length ? a : null;
  }
  function apply(s, seat, a) {
    if (!a || a.type !== 'pick' || s.ph !== 'pick') throw new Error('bad action');
    const k = a.h | 0;
    if (!(k >= 0 && k < HORSES.length) || s.hs[seat] >= 0 || s.hs.includes(k)) throw new Error('horse taken');
    s.hs[seat] = k;
    if (s.hs.every((x) => x >= 0)) s.ph = 'count';
    return s;
  }
  function autoPick(s) { // host: give the remaining seats a free horse and start
    const n = Object.assign({}, s, { hs: s.hs.slice() });
    const free = U.shuffle([0, 1, 2, 3, 4, 5, 6, 7].filter((k) => !n.hs.includes(k)));
    n.hs = n.hs.map((x) => (x >= 0 ? x : free.pop()));
    n.ph = 'count';
    return n;
  }
  function endRace(s, ord) {
    const n = Object.assign({}, s, { ph: 'end', fin: ord, wins: s.wins.slice(), pts: s.pts.slice() });
    if (ord.length) n.wins[ord[0][0]]++;
    ord.forEach((o, k) => { n.pts[o[0]] += s.n - k; });
    return n;
  }
  function nextRace(s) {
    const done = s.bo === 1 || s.wins.some((w) => w >= 2) || s.rd >= 3;
    if (done) {
      const res = s.bo === 1 ? s.fin.map((f) => [f[0], f[1]])
        : s.wins.map((w, i) => [i, w, s.pts[i]]).sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[0] - b[0]);
      return Object.assign({}, s, { ph: 'done', res });
    }
    return Object.assign({}, s, { ph: 'count', rd: s.rd + 1, sd: 1 + U.rand(2147483646), tr: s.tp >= 0 ? s.tp : U.rand(TRACKS.length), fin: [] });
  }
  const fmtT = (cs) => (cs < 0 ? '완주 못 함' : (cs / 100).toFixed(2) + '초');
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const hn = (i) => (HORSES[s.hs[i]] || { n: '?' }).n;
    if (s.bo === 1) {
      const w = s.res[0][0];
      return { winners: [w], title: nm(w) + ' 우승!', text: TRACKS[s.tr].name + ' · ' + s.ln + 'm\n' + s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + ' (' + hn(r[0]) + ')  ' + fmtT(r[1])).join('\n') };
    }
    const top = s.res[0], winners = s.res.filter((r) => r[1] === top[1] && r[2] === top[2]).map((r) => r[0]);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승',
      text: '3판 2선승 · ' + s.ln + 'm\n' + s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + ' (' + hn(r[0]) + ')  ' + r[1] + '승 · ' + r[2] + '점').join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const LINES = {
    start: ['출발했습니다! 일제히 뛰쳐나가요!', '게이트 열렸습니다! 힘차게 출발!', '출발! 응원 소리가 경기장을 울려요!'],
    lead: ['{h}, 선두로 치고 나갑니다!', '{h}가 앞으로! 순위가 바뀌어요!', '역전! {h}가 머리를 내밀어요!'],
    jump: ['{h}, 깔끔하게 넘었어요!', '{h} 훌쩍 날아올랐습니다!', '{h}, 교과서 같은 점프!'],
    crash: ['{h}, 장애물에 걸렸어요!', '아이고, {h} 휘청!', '{h}, 허들을 들이받았어요!'],
    early: ['{h}, 너무 일찍 뛰었어요!', '{h} 성급했어요! 허들 위에 착지!'],
    tired: ['{h}, 숨이 차요! 헉헉!', '{h} 체력 바닥! 잠깐 숨 고르기', '{h}, 너무 몰아붙였어요!'],
    rain: ['비가 쏟아집니다! 주로가 무거워져요', '소나기! 발굽이 푹푹 빠져요', '빗방울이 굵어집니다! 템포를 늦춰요'],
    sprint: ['마지막 직선! 스퍼트!', '결승선이 보입니다! 스퍼트!', '이제 남은 힘을 다 쏟아요! 스퍼트!'],
    fin: ['{h} 1착으로 골인!', '{h}, 1등으로 결승선 통과!'],
    photo: ['간발의 차! 사진 판정!', '코끝 차이! 사진 판정입니다!'],
  };
  const CSS = `
.hr-pick{position:absolute;left:0;right:0;bottom:0;z-index:8;padding:12px 12px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.96) 12%);display:flex;flex-direction:column;gap:8px;user-select:none;-webkit-user-select:none}
.hr-pick h3{margin:0;font-family:var(--f-display,"Black Han Sans"),sans-serif;font-weight:400;font-size:22px;color:var(--ink,#f2e9d8);display:flex;align-items:center;gap:8px}
.hr-pick .sub{font-size:12.5px;color:var(--muted,#ab9fb8);line-height:1.35}
.hr-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.hr-hc{appearance:none;position:relative;border:1.5px solid rgba(242,233,216,.14);background:rgba(46,38,64,.92);color:var(--ink,#f2e9d8);border-radius:12px;padding:4px 2px 6px;display:flex;flex-direction:column;align-items:center;gap:1px;font-weight:700;font-size:12px;min-height:72px;cursor:pointer;touch-action:manipulation}
.hr-hc:active{transform:scale(.96)}
.hr-hc canvas{width:58px;height:44px;display:block}
.hr-hc:disabled{opacity:.42;cursor:default}
.hr-hc .own{position:absolute;top:4px;right:5px;width:10px;height:10px;border-radius:50%;border:1.5px solid #f2e9d8}
.hr-pick .row2{display:flex;gap:8px}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1); // one person per phone
    const isMine = (s) => mine().includes(s);
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const nameOf = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const horseOf = (s) => HORSES[st && st.hs ? st.hs[s] : 0] || HORSES[0];
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; return !!p.ai || !!p.local; };
    let st = null, key = null, R = null, phase = 'wait', cd = 0, endT = 0, acc = 0, hostT = 0, pick = null, lastPickSig = '';
    let zones = [], tv = { x: 0, y: 0, w: 1, h: 1 }, spec = null;
    let aiMem = [], fb = {}, banner = null, shownEv = -1, lastEv = 0, camC = 0, camR = 80, lastSfx = 0, hintT = 0, flash = 0;
    // network
    let pubT = 0, hsQ = 0, inQ = 0, lastSig = '', snaps = [], lastQ = -1;
    const rc = {}, remJ = {};
    const fbOf = (s) => fb[s] || (fb[s] = { txt: '', col: '#f2e9d8', t: 0, pulse: 0, lastMs: -1e9, ivE: 1, c: { g: 0, f: 0, m: 0, s: 0, o: 0 }, j: [-1, '', 0] });

    function curKey() { return st ? st.rid + '.' + st.rd : null; }
    function startRace() {
      R = newRace(st.tr, st.ln, st.sd, st.n);
      aiMem = R.hs.map(() => ({}));
      snaps = []; lastQ = -1; banner = null; shownEv = -1; lastEv = 0; acc = 0; flash = 0;
      camC = 20; camR = 70;
      for (const s of mine()) { const f = fbOf(s); f.txt = ''; f.t = 0; f.lastMs = -1e9; f.ivE = 1; }
      phase = st.ph === 'run' ? 'run' : 'count'; cd = COUNT; endT = END_T;
      if (st.rd === 1) hintT = 6;
      layout();
    }

    /* ----- layout: race view + one tap zone per person on this phone ----- */
    function layout() {
      const W = cv.w, Hh = cv.h, m = mine();
      zones = []; spec = null;
      if (!m.length) { // all AI: race view + a stamina board
        const th = Math.min(Hh * 0.62, 112 + (st ? st.n : 4) * 58);
        tv = { x: 0, y: 0, w: W, h: th };
        spec = { x: 0, y: th, w: W, h: Hh - th };
      } else { // race view on top, my tap zone below
        const th = Math.round(Hh * 0.5);
        tv = { x: 0, y: 0, w: W, h: th };
        zones.push({ seat: m[0], x: 3, y: th + 3, w: W - 6, h: Hh - th - 6 });
      }
    }
    cv.onresize = layout;
    const zdims = (z) => ({ w: z.w, h: z.h });

    /* ----- input ----- */
    function myView(s) { // the horse as this phone sees it (guests: extrapolated from the latest snapshot)
      return R ? R.hs[s] : null;
    }
    function tapSeat(seat, tms) {
      if (!st || !R || !isMine(seat)) return;
      const f = fbOf(seat);
      f.pulse = 1;
      if (st.ph !== 'run' || phase !== 'run') { if (st.ph === 'count') { f.txt = '아직이에요!'; f.col = '#ab9fb8'; f.t = 0.7; } return; }
      const h = myView(seat);
      if (!h || h.ft >= 0) return;
      const ivr = (tms - f.lastMs) / 1000;
      f.lastMs = tms;
      if (ivr < 0.9) f.ivE = f.ivE * 0.55 + ivr * 0.45; else f.ivE = 1;
      hintT = Math.min(hintT, 1.2);
      let r;
      if (host()) r = tapAt(R, seat, ivr, hooks);
      else { // guest: judge locally, send counters / the jump
        const tt = hurdleTT(R, seat);
        if (h.td > 0) r = '';
        else if (tt >= 0 && tt <= JW) { const q = judge(tt); f.j = [h.ob, q, (f.j[2] + 1) % 1000]; h.jr = q; h.jx = R.obs[h.ob].x; r = 'j' + q; hooks.ev(q === 'P' ? 'jump' : q === 'E' ? 'early' : 'late', seat, true); }
        else { r = tapCat(ivr, inSprint(R, h), R.rain); f.c[r]++; }
        pubT = 0;
      }
      feedback(seat, r);
    }
    function feedback(seat, r) {
      const f = fbOf(seat), h = R && R.hs[seat];
      const T = {
        g: ['좋아요!', '#5fd38a'], f: ['조금 빨라요', '#e3ae45'], m: ['너무 빨라요!', '#ee6a55'], s: ['더 빠르게', '#9fc6ff'], o: ['다그닥!', '#f2e9d8'],
        jP: ['완벽한 점프!', '#5fd38a'], jL: ['아슬아슬!', '#e3ae45'], jE: ['너무 일러요!', '#ee6a55'],
      };
      if (!r) { if (h && h.td > 0) { f.txt = '헉헉… 숨 고르는 중'; f.col = '#ee6a55'; f.t = 0.6; } return; }
      const e = T[r]; if (!e) return;
      if (r[0] === 'j' || r !== f.lastR || f.t < 0.3) { f.txt = e[0]; f.col = e[1]; f.t = r[0] === 'j' ? 1.2 : 0.7; }
      f.lastR = r;
      if (r === 'g') { sfx('tick', 45); api.buzz(6); } else if (r === 'm') { sfx('click', 60); api.buzz(14); } else if (r[0] === 'j') { api.sfx(r === 'jP' ? 'whoosh' : 'thud'); api.buzz(r === 'jP' ? 20 : 50); } else sfx('click', 50);
    }
    function onDown(e) {
      e.preventDefault();
      const r = cv.cv.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
      const z = zones.find((q) => px >= q.x && px <= q.x + q.w && py >= q.y && py <= q.y + q.h);
      if (!z) return;
      tapSeat(z.seat, e.timeStamp || performance.now());
    }
    // keyboard / gamepad (api.input, rebindable in 「⌨ 조작 설정」): one tap per press, holding does not repeat
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || id !== 'tap') return;
      const m = mine(); if (!m.length || pick) return;
      tapSeat(m[0], performance.now());
    }) : () => {};
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- horse picker ----- */
    function horseThumb(k) {
      const c = L.h('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
      c.width = 58 * dpr; c.height = 44 * dpr;
      const g = c.getContext('2d'); g.scale(dpr, dpr);
      g.translate(31, 41); g.scale(0.92, 0.92);
      drawHorse(g, HORSES[k], '#f2e9d8', '', 1.1, { jump: 0, noJockey: true });
      return c;
    }
    function pickerSeat() { // the person on this phone who still has to pick
      if (!st) return -1;
      const m = mine().filter((s) => st.hs[s] < 0);
      return m.length ? m[0] : -1;
    }
    function buildPicker() {
      dropPicker();
      const seat = pickerSeat();
      const T = TRACKS[st.tr];
      const info = (st.tp < 0 ? '무작위 트랙' : T.name) + ' · ' + st.ln + 'm · ' + (st.bo === 3 ? '3판 2선승' : '한 판 승부');
      const waiting = st.hs.map((x, i) => (x < 0 ? i : -1)).filter((i) => i >= 0 && !isMine(i));
      const grid = L.h('div', { class: 'hr-grid' });
      HORSES.forEach((Ho, k) => {
        const own = st.hs.indexOf(k);
        const b = L.h('button', { class: 'hr-hc', 'aria-label': Ho.n + (own >= 0 ? ' (선택됨)' : ''), disabled: seat < 0 || own >= 0 },
          horseThumb(k), L.h('span', { text: Ho.n }), own >= 0 ? L.h('span', { class: 'own', style: { background: P(own).color } }) : null);
        b.onclick = () => { if (seat < 0) return; api.sfx('click'); api.buzz(12); api.actAs(seat, { type: 'pick', h: k }); };
        grid.append(b);
      });
      const title = seat >= 0
        ? L.h('h3', null, L.h('span', { class: 'dot', style: { '--c': P(seat).color, width: '14px', height: '14px' } }), nameOf(seat) + ' · 말 고르기')
        : L.h('h3', { text: '말 고르기' });
      const sub = L.h('div', { class: 'sub', text: seat >= 0 ? info + ' — 응원할 말을 골라요. 능력치는 모두 같아요.' : '다른 사람이 고르는 중… (' + waiting.map(nameOf).join(', ') + ')' });
      const kids = [title, sub, grid];
      if (api.online && api.isHost && waiting.length) {
        kids.push(L.h('button', { class: 'btn block', text: '기다리지 않고 시작 (남은 말 자동 배정)', onclick() { if (st && st.ph === 'pick') { api.sfx('click'); api.setState(autoPick(st)); } } }));
      }
      const el = L.h('div', { class: 'hr-pick' }, kids);
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el };
    }
    function syncPicker() {
      if (!st || st.ph !== 'pick') { dropPicker(); return; }
      const sig = st.hs.join(',') + '|' + pickerSeat();
      if (pick && sig === lastPickSig) return;
      lastPickSig = sig; buildPicker();
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } lastPickSig = ''; }

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 50)) return; lastSfx = t; api.sfx(n); }
    const hooks = {
      ev(type, seat, localOnly) {
        if (seat >= 0 && isMine(seat)) {
          const f = fbOf(seat);
          if (type === 'tired') { f.txt = '헉헉! 지쳤어요'; f.col = '#ee6a55'; f.t = 1.6; api.buzz(80); api.sfx('lose'); }
          if (type === 'crash') { f.txt = '걸렸어요!'; f.col = '#ee6a55'; f.t = 1.3; api.buzz(90); api.sfx('thud'); }
          if (type === 'early' && !localOnly && host()) { /* feedback() already said it */ }
        }
        if (type === 'rain') { sfx('whoosh', 30); }
        if (type === 'sprint') { api.sfx('chip'); flash = 1; for (const s of mine()) api.buzz(30); }
        if (type === 'fin') sfx('win', 30);
        void localOnly;
      },
      fin(i) { if (isMine(i)) { api.buzz(60); const f = fbOf(i); f.txt = '골인!'; f.col = '#e3ae45'; f.t = 2; } },
    };

    /* ----- host flow ----- */
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'count' && phase === 'run') { api.setState(Object.assign({}, st, { ph: 'run' })); return; }
      if (st.ph === 'run' && R && raceOver(R)) { api.setState(endRace(st, order(R))); return; }
      if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextRace(st)); } }
      if (st.ph === 'pick' && api.online && !mine().length) { hostT += dt; if (hostT > 2) { hostT = -1e9; api.setState(autoPick(st)); } }
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !R) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < R.n) || simHere(s) || !o || o.k !== key) continue;
        if (Array.isArray(o.c) && o.c.length === 5) {
          const prev = rc[s] || [0, 0, 0, 0, 0];
          'gfmso'.split('').forEach((cat, j) => {
            const nv = o.c[j] | 0; let d = nv - (prev[j] | 0);
            if (d < 0 || d > 40) d = 0;
            for (let q = 0; q < Math.min(d, 8); q++) applyTap(R, s, cat, hooks);
          });
          rc[s] = o.c.map((v) => v | 0);
        }
        if (Array.isArray(o.j) && o.j[2] !== remJ[s]) {
          remJ[s] = o.j[2];
          const h = R.hs[s];
          if ((o.j[0] | 0) === h.ob && !h.jr && 'PLE'.includes(o.j[1])) resolveJump(R, s, o.j[1], hooks);
        }
      }
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !R) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.h)) return;
      lastQ = hs.q;
      snaps.push({ at: now, t: +hs.t || 0, h: hs.h }); if (snaps.length > 5) snaps.shift();
      R.t = +hs.t || R.t; R.rain = hs.rn ? 1 : 0;
      hs.h.forEach((a, i) => {
        const h = R.hs[i]; if (!h || !Array.isArray(a)) return;
        const wasFt = h.ft;
        h.v = (a[1] | 0) / 10; h.en = a[2] | 0; h.ch = (a[3] | 0) / 100;
        const fl = a[4] | 0;
        h.td = fl & 1 ? 1 : 0; h.st = fl & 2 ? 0.5 : 0; h.bt = fl & 4 ? 0.5 : 0; h.sp = fl & 8 ? 1 : 0;
        const ob = a[5] | 0, jr = ['', 'P', 'L', 'E', 'C'][(fl >> 4) & 7] || '';
        if (!isMine(i) || ob !== h.ob || jr) { h.ob = ob; if (jr || !isMine(i)) { h.jr = jr; if (jr && R.obs[ob]) h.jx = R.obs[ob].x; } }
        h.ft = (a[6] | 0) >= 0 ? (a[6] | 0) / 100 : -1;
        if (wasFt < 0 && h.ft >= 0) hooks.fin(i);
        if (isMine(i)) { h.np = (a[0] | 0) / 10; h.nat = now; }
      });
      if (Array.isArray(hs.ev)) for (const e of hs.ev) if (Array.isArray(e) && e[0] > lastEv) { lastEv = e[0]; R.ev.push(e); if (R.ev.length > 4) R.ev.shift(); if (e[1] !== 'jump' || !isMine(e[2])) hooks.ev(e[1], e[2]); }
    }
    function interp(now) {
      if (host() || !R || !snaps.length) return;
      const rt = now - 110;
      let A = null, B = snaps[snaps.length - 1], k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.4);
      R.hs.forEach((h, i) => {
        if (isMine(i) && h.nat) { // light prediction for my own horse: extrapolate the newest value
          const p = h.np + h.v * Math.min(0.35, (now - h.nat) / 1000 * SPD());
          h.p = Math.abs(p - h.p) > 6 ? p : h.p + (p - h.p) * 0.4;
          return;
        }
        const b = B.h[i], a = A ? A.h[i] : null;
        if (!Array.isArray(b)) return;
        h.p = a ? ((a[0] | 0) + ((b[0] | 0) - (a[0] | 0)) * k) / 10 : (b[0] | 0) / 10;
      });
    }
    function publish(rdt, now) {
      if (!api.online || !R) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 16;
          hsQ = (hsQ + 1) % 100000;
          const h = R.hs.map((q) => [Math.round(q.p * 10), Math.round(q.v * 10), Math.round(q.en), Math.round(q.ch * 100),
            (q.td > 0 ? 1 : 0) | (q.st > 0 ? 2 : 0) | (q.bt > 0 ? 4 : 0) | (q.sp ? 8 : 0) | ((['', 'P', 'L', 'E', 'C'].indexOf(q.jr) & 7) << 4), q.ob, q.ft >= 0 ? Math.round(q.ft * 100) : -1]);
          api.net.hostSend({ k: key, q: hsQ, t: Math.round(R.t * 100) / 100, rn: R.rain, h, ev: R.ev.slice(-3) });
        } else {
          const s = mine()[0]; if (s == null) return;
          const f = fbOf(s);
          const c = [f.c.g, f.c.f, f.c.m, f.c.s, f.c.o];
          const sig = c.join(',') + '|' + f.j.join(',');
          if (sig === lastSig && pubT > -0.5) return;
          lastSig = sig; pubT = 0;
          inQ = (inQ + 1) % 100000;
          api.net.publish({ k: key, q: inQ, c, j: f.j });
        }
      } catch (e) {}
      void now;
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      const dt = rdt * SPD();
      if (st.ph === 'pick') syncPicker(); else if (pick) dropPicker();
      if (R && phase === 'count' && (st.ph === 'count' || st.ph === 'run')) {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0) api.sfx('tick');
        if (cd <= 0 && (host() || st.ph === 'run')) { phase = 'run'; api.sfx('pop'); api.buzz(25); if (host()) pushEv(R, 'start', -1, hooks); }
      }
      if (hintT > 0 && phase === 'run') hintT -= rdt;
      if (host()) {
        pollHost();
        if (R && phase === 'run' && (st.ph === 'run' || st.ph === 'count' || st.ph === 'end')) {
          acc += Math.min(dt, 0.5);
          const rem = R.hs.map((_, i) => !simHere(i));
          let n = 0;
          while (acc >= H && n < 240) {
            if (st.ph !== 'end') R.hs.forEach((h, i) => { const p = api.players[i]; if (p && simHere(i) && (p.ai || (L.debug && L.debug.autoplay))) aiStep(R, i, aiMem[i], p.ai ? (p.lv || 2) : 2, hooks); });
            stepRace(R, H, hooks, rem); acc -= H; n++;
          }
        }
        hostFlow(dt);
      } else if (R) {
        pollGuest(now);
        if (phase === 'run' && st.ph === 'run') R.t += dt;
        if (st.ph === 'end') R.hs.forEach((h) => { h.p += Math.max(h.v, 6) * dt; });
        interp(now);
      }
      for (const k in fb) { const f = fb[k]; if (f.t > 0) f.t -= rdt; if (f.pulse > 0) f.pulse = Math.max(0, f.pulse - rdt * 5); }
      if (flash > 0) flash = Math.max(0, flash - rdt * 1.5);
      // commentary
      if (R && R.ev.length) { const e = R.ev[R.ev.length - 1]; if (e[0] !== shownEv && (!banner || banner.age > 0.9 || e[1] === 'fin' || e[1] === 'photo')) { shownEv = e[0]; banner = { id: e[0], type: e[1], seat: e[2], age: 0 }; } }
      if (banner) { banner.age += rdt; if (banner.age > 2.6) banner = null; }
      publish(rdt, now);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align) {
      ctx.font = font; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,8,16,.85)'; ctx.strokeText(t, x, y); ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function fitText(t, maxW) { // trim with an ellipsis to the current font
      if (ctx.measureText(t).width <= maxW) return t;
      let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1);
      return s + '…';
    }
    function draw(now) {
      cv.clear();
      const w = cv.w, h = cv.h;
      ctx.fillStyle = '#120e19'; ctx.fillRect(0, 0, w, h);
      if (!st) return;
      if (!R) return;
      drawTrack(now);
      if (st.ph !== 'pick') for (const z of zones) drawZone(z, now);
      if (spec) drawSpec(now);
    }
    function lineFor(b) {
      const L2 = LINES[b.type]; if (!L2) return null;
      return L2[b.id % L2.length];
    }
    function drawTrack(now) {
      const r = tv, n = R.n, T = R.T;
      ctx.save(); ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
      const mmH = 26, skyH = Math.max(22, Math.min(54, r.h * 0.14));
      const y0 = r.y + mmH + skyH, laneArea = r.h - mmH - skyH - 12;
      const laneH = Math.min(64, laneArea / n), yTop = y0 + (laneArea - laneH * n) / 2 + 4;
      // camera
      let lo = 1e9, hi = -1e9;
      for (const q of R.hs) { if (q.ft >= 0 && st.ph === 'run') continue; lo = Math.min(lo, q.p); hi = Math.max(hi, q.p); }
      if (lo > hi) { lo = R.ln - 10; hi = R.ln + 10; }
      const want = clamp(hi - lo + 34, 46, 150), wantC = (hi + lo) / 2 + 5;
      camR += (want - camR) * 0.08; camC += (wantC - camC) * 0.15;
      if (Math.abs(wantC - camC) > 80) camC = wantC;
      const pxm = r.w / camR;
      const X = (p) => r.x + r.w / 2 + (p - camC) * pxm;
      const left = camC - camR / 2 - 6, right = camC + camR / 2 + 6;
      // night sky + stands
      const sg = ctx.createLinearGradient(0, r.y + mmH, 0, y0);
      sg.addColorStop(0, '#191330'); sg.addColorStop(1, '#2a2040');
      ctx.fillStyle = sg; ctx.fillRect(r.x, r.y, r.w, y0 - r.y);
      const par = 0.35; // stands scroll slower (parallax)
      ctx.fillStyle = '#0f0b17';
      const pl = camC * par - camR / 2, pr = camC * par + camR / 2;
      for (let i = Math.floor(pl / 14) - 1; i < pr / 14 + 1; i++) {
        const sx = r.x + r.w / 2 + (i * 14 - camC * par) * pxm, hh = skyH * (0.45 + ((i * 2654435761) >>> 0) % 7 / 30);
        ctx.fillRect(sx, y0 - hh, 14 * pxm * 0.98, hh);
        // crowd specks
        for (let j = 0; j < 3; j++) { const k = ((i * 7 + j) * 2246822519) >>> 0; ctx.fillStyle = L.COLORS[k % 6]; ctx.globalAlpha = 0.55; ctx.fillRect(sx + (k % 11) / 11 * 14 * pxm, y0 - hh + 3 + (k % 5), 2, 2); ctx.fillStyle = '#0f0b17'; ctx.globalAlpha = 1; }
      }
      for (let i = Math.floor(pl / 60) - 1; i < pr / 60 + 1; i++) { // floodlights
        const lx = r.x + r.w / 2 + (i * 60 + 30 - camC * par) * pxm;
        ctx.fillStyle = '#3a3150'; ctx.fillRect(lx - 1, y0 - skyH + 2, 2, skyH - 2);
        const lg = ctx.createRadialGradient(lx, y0 - skyH + 4, 0, lx, y0 - skyH + 4, 26); lg.addColorStop(0, 'rgba(255,240,200,.75)'); lg.addColorStop(1, 'rgba(255,240,200,0)');
        ctx.fillStyle = lg; ctx.fillRect(lx - 26, y0 - skyH - 22, 52, 52);
      }
      // turf (mowed stripes every 10 m)
      const rain = R.rain;
      for (let m = Math.floor(left / 10) * 10; m < right; m += 10) {
        ctx.fillStyle = (m / 10) % 2 ? T.g1 : T.g2;
        ctx.fillRect(X(m), y0, 10 * pxm + 1, r.y + r.h - y0);
      }
      if (rain) { ctx.fillStyle = 'rgba(20,30,60,.28)'; ctx.fillRect(r.x, y0, r.w, r.h); }
      // sprint stretch tint
      if (right > R.spr) { const sx = Math.max(r.x, X(R.spr)); ctx.fillStyle = 'rgba(227,174,69,.12)'; ctx.fillRect(sx, y0, r.x + r.w - sx, r.h); if (X(R.spr) > r.x) { ctx.fillStyle = 'rgba(227,174,69,.7)'; ctx.fillRect(X(R.spr) - 1, y0, 2, laneH * n + 8); } }
      // lane lines
      ctx.strokeStyle = 'rgba(255,255,255,.12)'; ctx.lineWidth = 1;
      for (let i = 1; i < n; i++) { const y = yTop + laneH * i; ctx.beginPath(); ctx.moveTo(r.x, y); ctx.lineTo(r.x + r.w, y); ctx.stroke(); }
      // rails with posts
      const rail = (y) => {
        ctx.fillStyle = '#f2e9d8'; ctx.fillRect(r.x, y - 1.5, r.w, 3);
        for (let m = Math.floor(left / 5) * 5; m < right; m += 5) ctx.fillRect(X(m) - 1, y, 2, 6);
      };
      // distance markers
      for (let m = Math.ceil(left / 100) * 100; m < right; m += 100) {
        if (m <= 0 || m >= R.ln) continue;
        const x = X(m);
        ctx.fillStyle = '#d33'; ctx.fillRect(x - 1.5, y0 - 16, 3, 16);
        ctx.font = '700 10px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(String(R.ln - m), x, y0 - 16);
      }
      // hurdles
      for (let k = 0; k < R.obs.length; k++) {
        const o = R.obs[k], x = X(o.x);
        if (x < r.x - 40 || x > r.x + r.w + 40) continue;
        for (let i = 0; i < n; i++) drawHurdle(x, yTop + laneH * (i + 1) - laneH * 0.18, laneH, o.w, pxm);
      }
      // start & finish
      if (X(0) > r.x - 10) { ctx.fillStyle = 'rgba(255,255,255,.8)'; ctx.fillRect(X(0) - 1, yTop, 2, laneH * n); }
      const fx = X(R.ln);
      if (fx < r.x + r.w + 20) {
        const cs = Math.max(4, laneH / 6);
        for (let yy = 0, i = 0; yy < laneH * n; yy += cs, i++) for (let c = 0; c < 2; c++) { ctx.fillStyle = (i + c) % 2 ? '#111' : '#f5f0e6'; ctx.fillRect(fx + c * cs - cs, yTop + yy, cs, Math.min(cs, laneH * n - yy)); }
        ctx.fillStyle = '#e3ae45'; ctx.fillRect(fx - 2, y0 - skyH * 0.9, 4, skyH * 0.9);
        ctx.font = '12px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillStyle = '#e3ae45'; ctx.fillText('결승', fx, y0 - skyH * 0.9 - 1);
      }
      rail(yTop - 3); rail(yTop + laneH * n + 3);
      // horses (top lane first so lower lanes overlap)
      const sc = clamp(laneH / 30, 0.62, 1.55);
      for (let i = 0; i < n; i++) {
        const q = R.hs[i], x = X(q.p), y = yTop + laneH * (i + 1) - laneH * 0.14;
        if (x < r.x - 60) { // behind the camera: arrow with the gap
          txt('◀ ' + Math.round(camC - camR / 2 - q.p) + 'm', r.x + 22, y - laneH * 0.4, P(i).color, '700 11px ' + MONO);
          continue;
        }
        let jump = 0, tilt = 0;
        if (q.jr && q.jr !== 'C') {
          const c0 = q.jr === 'E' ? q.jx - 6 : q.jx, u = (q.p - (c0 - 3.6)) / 7.2;
          if (u > 0 && u < 1) jump = Math.sin(Math.PI * u) * 12;
        }
        if (q.st > 0) tilt = Math.sin(now / 60) * 0.12 + 0.15;
        ctx.save(); ctx.translate(x, y); ctx.scale(sc, sc);
        ctx.beginPath(); ctx.ellipse(0, 1, 15, 2.6, 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fill();
        if (isMine(i) && mine().length === 1) { ctx.beginPath(); ctx.ellipse(0, 1, 20, 4, 0, 0, 7); ctx.strokeStyle = 'rgba(242,233,216,.85)'; ctx.lineWidth = 1.6; ctx.setLineDash([4, 3]); ctx.stroke(); ctx.setLineDash([]); }
        drawHorse(ctx, horseOf(i), P(i).color, String(i + 1), q.p * 1.25, { jump, tilt, tired: q.td > 0 });
        if (q.td > 0) { ctx.font = '700 9px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.globalAlpha = 0.6 + 0.4 * Math.sin(now / 120); ctx.fillText('헉헉', 22, -36); ctx.globalAlpha = 1; }
        if (q.bt > 0) { ctx.strokeStyle = 'rgba(255,243,207,.7)'; ctx.lineWidth = 1.4; for (const o of [-24, -18, -12]) { ctx.beginPath(); ctx.moveTo(-20, o); ctx.lineTo(-32 - Math.random() * 6, o); ctx.stroke(); } }
        ctx.restore();
        // name label behind the horse
        if (laneH >= 24) {
          ctx.font = '700 ' + (laneH >= 40 ? 11 : 9.5) + 'px ' + FONT;
          const label = fitText(nameOf(i), 70);
          const lx = x - 26 * sc - 4;
          if (lx > r.x + 20) { ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,8,16,.75)'; ctx.strokeText(label, lx, y - 8 * sc); ctx.fillStyle = P(i).color; ctx.fillText(label, lx, y - 8 * sc); }
        }
      }
      // rain streaks
      if (rain) {
        ctx.strokeStyle = 'rgba(180,200,255,.35)'; ctx.lineWidth = 1;
        for (let i = 0; i < 60; i++) { const k = (i * 2654435761) >>> 0, x = r.x + ((k % 1000) / 1000 * r.w + now / 4 * 0.6) % r.w, y = r.y + (((k >> 10) % 1000) / 1000 * r.h + now / 2.2) % r.h; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 4, y + 11); ctx.stroke(); }
      }
      if (flash > 0) { ctx.fillStyle = 'rgba(227,174,69,' + flash * 0.25 + ')'; ctx.fillRect(r.x, r.y, r.w, r.h); }
      // minimap
      drawMinimap(r, mmH);
      // countdown / commentary / results
      const midY = yTop + laneH * n / 2;
      if (phase === 'count' && (st.ph === 'count' || st.ph === 'run')) {
        const bw2 = Math.min(r.w - 40, 260); // scrim so the countdown reads clearly over the horses
        rrect(ctx, r.x + (r.w - bw2) / 2, midY - 66, bw2, 104, 16); ctx.fillStyle = 'rgba(18,14,25,.62)'; ctx.fill();
        txt(String(Math.max(1, Math.ceil(cd))), r.x + r.w / 2, midY, '#f2e9d8', '56px ' + DISP);
        txt(T.name + ' · ' + R.ln + 'm' + (st.bo === 3 ? ' · ' + st.rd + '경주' : ''), r.x + r.w / 2, midY - 44, '#e3ae45', '18px ' + DISP);
      }
      if (banner && st.ph !== 'end') drawBanner(r, mmH + 4, now);
      if (st.ph === 'end') drawResults(r);
      ctx.restore();
    }
    function drawHurdle(x, y, laneH, water, pxm) {
      const s = clamp(laneH / 26, 0.7, 1.9);
      if (water) { ctx.fillStyle = 'rgba(80,150,220,.8)'; ctx.beginPath(); ctx.ellipse(x - 6 * s, y - 1, Math.max(10 * s, 4 * pxm), 3.2 * s, 0, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(200,230,255,.6)'; ctx.lineWidth = 1; ctx.stroke(); }
      ctx.fillStyle = '#24411a'; ctx.beginPath(); ctx.ellipse(x, y - 5 * s, 4.5 * s, 7 * s, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#3d6b2a'; ctx.beginPath(); ctx.ellipse(x - 1 * s, y - 7 * s, 3 * s, 4.5 * s, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.fillRect(x - 3.5 * s, y - 15 * s, 1.6 * s, 15 * s); ctx.fillRect(x + 2 * s, y - 15 * s, 1.6 * s, 15 * s);
      ctx.fillStyle = '#f2e9d8'; ctx.fillRect(x - 4 * s, y - 14.5 * s, 8 * s, 2.4 * s);
      ctx.fillStyle = '#ee6a55'; ctx.fillRect(x - 4 * s, y - 14.5 * s, 2.7 * s, 2.4 * s); ctx.fillRect(x + 1.4 * s, y - 14.5 * s, 2.7 * s, 2.4 * s);
    }
    function drawMinimap(r, mmH) {
      const x0 = r.x + 14, x1 = r.x + r.w - 30, y = r.y + mmH / 2 + 1;
      ctx.fillStyle = 'rgba(23,19,31,.85)'; ctx.fillRect(r.x, r.y, r.w, mmH);
      ctx.fillStyle = 'rgba(242,233,216,.18)'; rrect(ctx, x0, y - 3, x1 - x0, 6, 3); ctx.fill();
      const M = (p) => x0 + (x1 - x0) * clamp(p / R.ln, 0, 1);
      ctx.fillStyle = 'rgba(227,174,69,.55)'; ctx.fillRect(M(R.spr), y - 3, x1 - M(R.spr), 6);
      if (R.rainAt >= 0 && R.rain) { ctx.fillStyle = 'rgba(120,170,255,.5)'; ctx.fillRect(M(R.rainAt), y - 3, x1 - M(R.rainAt), 6); }
      ctx.fillStyle = '#f2e9d8'; for (const o of R.obs) ctx.fillRect(M(o.x) - 1, y - 6, 2, 12);
      // flag
      ctx.fillStyle = '#e3ae45'; ctx.fillRect(x1 + 4, y - 8, 2, 16); ctx.beginPath(); ctx.moveTo(x1 + 6, y - 8); ctx.lineTo(x1 + 16, y - 5); ctx.lineTo(x1 + 6, y - 2); ctx.fill();
      const idx = R.hs.map((_, i) => i).sort((a, b) => R.hs[a].p - R.hs[b].p);
      for (const i of idx) { ctx.beginPath(); ctx.arc(M(R.hs[i].p), y, isMine(i) ? 5.5 : 4.5, 0, 7); ctx.fillStyle = P(i).color; ctx.fill(); ctx.lineWidth = isMine(i) ? 2 : 1; ctx.strokeStyle = isMine(i) ? '#f2e9d8' : 'rgba(0,0,0,.6)'; ctx.stroke(); }
    }
    function drawBanner(r, top, now) {
      const t = lineFor(banner); if (!t) return;
      const hn = banner.seat >= 0 ? horseOf(banner.seat).n : '';
      const text = t.replace('{h}', hn);
      const life = 2.6;
      const a = Math.max(0, Math.min(1, banner.age * 6, (life - banner.age) * 3));
      if (a <= 0) return;
      {
        ctx.save(); ctx.globalAlpha = a;
        ctx.font = '700 13.5px ' + FONT;
        const tw = Math.min(r.w - 24, ctx.measureText(text).width + 46), bx = r.x + (r.w - tw) / 2, by = r.y + top + 2 + (1 - a) * -6;
        rrect(ctx, bx, by, tw, 28, 14); ctx.fillStyle = 'rgba(23,19,31,.9)'; ctx.fill();
        ctx.lineWidth = 1.5; ctx.strokeStyle = banner.seat >= 0 ? P(banner.seat).color : '#e3ae45'; ctx.stroke();
        // mic glyph
        ctx.fillStyle = '#e3ae45'; rrect(ctx, bx + 11, by + 7, 7, 11, 3.5); ctx.fill(); ctx.fillRect(bx + 14, by + 18, 1.4, 4);
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(fitText(text, tw - 34), bx + 25, by + 14.5);
        ctx.restore();
      }
      void now;
    }
    function drawResults(r) {
      const fins = st.fin || [];
      const rows = fins.length, rh = Math.min(26, (r.h - 70) / Math.max(1, rows));
      const bw = Math.min(r.w - 24, 320), bh = rows * rh + 44, bx = r.x + (r.w - bw) / 2, by = r.y + (r.h - bh) / 2 + 8;
      rrect(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(23,19,31,.92)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.font = '17px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#e3ae45';
      ctx.fillText(st.bo === 3 ? st.rd + '경주 결과' : '경주 결과', bx + bw / 2, by + 20);
      fins.forEach((f, k) => {
        const y = by + 40 + rh * k + rh / 2, s = f[0];
        ctx.font = '700 13px ' + MONO; ctx.textAlign = 'left'; ctx.fillStyle = k === 0 ? '#e3ae45' : '#f2e9d8'; ctx.fillText((k + 1) + '위', bx + 12, y);
        ctx.beginPath(); ctx.arc(bx + 50, y, 5, 0, 7); ctx.fillStyle = P(s).color; ctx.fill();
        ctx.font = '700 13px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText(fitText(nameOf(s) + ' · ' + horseOf(s).n, bw - (st.bo === 3 ? 150 : 130)), bx + 60, y);
        ctx.font = '600 12px ' + MONO; ctx.textAlign = 'right'; ctx.fillStyle = '#ab9fb8';
        ctx.fillText(st.bo === 3 ? fmtT(f[1]).replace('초', 's') + '  ' + st.wins[s] + '승' : fmtT(f[1]), bx + bw - 12, y);
      });
    }
    function drawSpec(now) { // all-AI: a small board with each horse's stamina and cheer
      const r = spec;
      if (r.h < 40) return;
      const n = R.n, rh = Math.min(44, (r.h - 20) / n);
      for (let i = 0; i < n; i++) {
        const q = R.hs[i], y = r.y + 12 + rh * i;
        rrect(ctx, 10, y, r.w - 20, rh - 6, 10); ctx.fillStyle = 'rgba(46,38,64,.7)'; ctx.fill();
        ctx.beginPath(); ctx.arc(26, y + (rh - 6) / 2, 6, 0, 7); ctx.fillStyle = P(i).color; ctx.fill();
        ctx.font = '700 12.5px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
        ctx.fillText(fitText(nameOf(i) + ' · ' + horseOf(i).n, r.w * 0.42), 38, y + (rh - 6) / 2);
        const bx = r.w * 0.5, bw = r.w * 0.5 - 24;
        energyBar(bx, y + (rh - 6) / 2 - 5, bw, 10, q, now);
      }
    }
    function energyBar(x, y, w, h, q, now) {
      rrect(ctx, x, y, w, h, h / 2); ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fill();
      const e = clamp(q.en / 100, 0, 1);
      const col = q.td > 0 ? (Math.sin(now / 90) > 0 ? '#ee6a55' : '#7a2d3a') : e > 0.5 ? '#5fd38a' : e > 0.22 ? '#e3ae45' : '#ee6a55';
      if (e > 0.01) { rrect(ctx, x, y, Math.max(h, w * e), h, h / 2); ctx.fillStyle = col; ctx.fill(); }
    }
    function drawZone(z, now) {
      const d = zdims(z), w = d.w, h = d.h, s = z.seat, q = R.hs[s], f = fbOf(s), col = P(s).color;
      ctx.save();
      ctx.translate(z.x, z.y);
      // pad
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, hexA(col, 0.2 + f.pulse * 0.25)); g.addColorStop(1, 'rgba(34,28,46,.95)');
      rrect(ctx, 0, 0, w, h, 16); ctx.fillStyle = g; ctx.fill();
      ctx.lineWidth = 2; ctx.strokeStyle = hexA(col, 0.75); ctx.stroke();
      ctx.clip();
      const narrow = w < 150;
      // header: name + rank
      const ord = rankOf(s);
      ctx.font = '700 ' + (narrow ? 12 : 14) + 'px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.beginPath(); ctx.arc(14, 16, 5, 0, 7); ctx.fillStyle = col; ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.fillText(fitText(nameOf(s) + (narrow ? '' : ' · ' + horseOf(s).n), w - (narrow ? 56 : 70)), 24, 16.5);
      ctx.font = (narrow ? 17 : 20) + 'px ' + DISP; ctx.textAlign = 'right'; ctx.fillStyle = ord === 1 ? '#e3ae45' : '#f2e9d8';
      ctx.fillText(ord + '위', w - 10, 17);
      // stamina bar
      const bx = 10, bw = w - 20;
      ctx.font = '600 10px ' + FONT; ctx.textAlign = 'left'; ctx.fillStyle = '#ab9fb8'; ctx.fillText('체력', bx, 35);
      energyBar(bx + 26, 30, bw - 26, 10, q, now);
      // tempo gauge
      const sp = inSprint(R, q), [lo, hi] = band(sp, R.rain);
      const ty = 50, tx = bx + 26, tw = bw - 26, RMIN = 1.2, RMAX = 10;
      const RX = (rate) => tx + tw * clamp((rate - RMIN) / (RMAX - RMIN), 0, 1);
      ctx.fillStyle = '#ab9fb8'; ctx.fillText('템포', bx, ty + 5);
      rrect(ctx, tx, ty, tw, 10, 5); ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fill();
      ctx.fillStyle = 'rgba(238,106,85,.35)'; ctx.fillRect(RX(1 / (lo * 0.6)), ty + 1, tx + tw - RX(1 / (lo * 0.6)) - 3, 8);
      ctx.fillStyle = sp ? '#e3ae45' : '#5fd38a'; ctx.fillRect(RX(1 / hi), ty, RX(1 / lo) - RX(1 / hi), 10);
      const since = (performance.now() - f.lastMs) / 1000;
      const rate = 1 / Math.max(f.ivE, since > f.ivE ? Math.min(2, since) : 0.01);
      const nx = RX(rate);
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(nx, ty + 12); ctx.lineTo(nx - 5, ty + 19); ctx.lineTo(nx + 5, ty + 19); ctx.fill(); ctx.fillRect(nx - 1, ty - 2, 2, 14);
      // big tap target
      const top = 74, avail = h - top - (h > 210 ? 22 : 8);
      const cx = w / 2, cy = top + avail / 2, Rr = Math.max(18, Math.min(w * 0.36, avail * 0.46));
      const beat = q.ft < 0 && phase === 'run' ? Math.max(0, Math.cos(now / 1000 * Math.PI * 2 / ((lo + hi) / 2))) : 0;
      ctx.beginPath(); ctx.arc(cx, cy, Rr * (1 - f.pulse * 0.06), 0, 7);
      const bg = ctx.createRadialGradient(cx - Rr * 0.3, cy - Rr * 0.3, 2, cx, cy, Rr);
      bg.addColorStop(0, shade(col, 0.25)); bg.addColorStop(1, shade(col, -0.35));
      ctx.fillStyle = bg; ctx.fill();
      ctx.lineWidth = 3; ctx.strokeStyle = hexA('#f2e9d8', 0.25 + beat * 0.2); ctx.stroke();
      // horseshoe glyph
      ctx.save(); ctx.translate(cx, cy - Rr * 0.08); const k = Rr / 44;
      ctx.scale(k, k);
      ctx.beginPath(); ctx.arc(0, 0, 16, Math.PI * 0.85, Math.PI * 2.15); ctx.lineWidth = 8; ctx.strokeStyle = 'rgba(23,19,31,.55)'; ctx.lineCap = 'round'; ctx.stroke();
      ctx.fillStyle = 'rgba(242,233,216,.85)'; for (const a of [1.05, 1.35, 1.65, 1.95]) { ctx.beginPath(); ctx.arc(Math.cos(a * Math.PI) * 16, Math.sin(a * Math.PI) * 16, 1.6, 0, 7); ctx.fill(); }
      ctx.restore();
      ctx.font = Math.round(Math.max(14, Rr * 0.36)) + 'px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
      const label = st.ph === 'pick' || phase === 'count' ? '' : q.ft >= 0 ? '골인!' : q.td > 0 ? '헉헉' : sp ? '스퍼트!' : '응원!';
      ctx.fillText(label, cx, cy + Rr * 0.42);
      // hurdle cue: a ring that closes onto the target ring at the perfect moment
      const tt = hurdleTT(R, s);
      if (tt >= 0 && tt <= 1.5 && phase === 'run' && q.ft < 0) {
        const Rt = Rr + 8, Rc = Rt + (tt - 0.23) * Rr * 1.6;
        ctx.lineWidth = 4; ctx.strokeStyle = tt <= JW ? '#5fd38a' : 'rgba(242,233,216,.5)';
        ctx.beginPath(); ctx.arc(cx, cy, Rt, 0, 7); ctx.stroke();
        if (Rc > 4) { ctx.lineWidth = 3; ctx.strokeStyle = tt <= JW ? '#e3ae45' : 'rgba(227,174,69,.5)'; ctx.beginPath(); ctx.arc(cx, cy, Rc, 0, 7); ctx.stroke(); }
        txt(tt <= JW ? '점프! 링이 겹칠 때 탭' : '곧 허들!', cx, Math.max(top - 2, cy - Rr - 16), tt <= JW ? '#e3ae45' : '#f2e9d8', '700 ' + (narrow ? 12 : 14) + 'px ' + FONT);
      }
      // sprint glow
      if (sp && q.ft < 0) { ctx.save(); ctx.globalAlpha = 0.4 + 0.3 * Math.sin(now / 110); ctx.lineWidth = 4; ctx.strokeStyle = '#e3ae45'; rrect(ctx, 2, 2, w - 4, h - 4, 15); ctx.stroke(); ctx.restore(); }
      // feedback text
      if (f.t > 0 && f.txt) { ctx.globalAlpha = Math.min(1, f.t * 3); txt(f.txt, cx, cy - Rr * 0.5 - (narrow ? 2 : 6), f.col, '700 ' + (narrow ? 13 : 16) + 'px ' + FONT); ctx.globalAlpha = 1; }
      // countdown / result
      if (phase === 'count' && st.ph !== 'pick') txt(String(Math.max(1, Math.ceil(cd))), cx, cy, '#f2e9d8', Math.round(Rr * 0.9) + 'px ' + DISP);
      if (st.ph === 'end') { ctx.fillStyle = 'rgba(23,19,31,.6)'; rrect(ctx, 0, 0, w, h, 16); ctx.fill(); const k2 = (st.fin || []).findIndex((x) => x[0] === s); txt((k2 + 1) + '위', cx, cy, k2 === 0 ? '#e3ae45' : '#f2e9d8', Math.round(Math.min(48, Rr)) + 'px ' + DISP); if (st.bo === 3) txt(st.wins[s] + '승', cx, cy + Rr * 0.7, '#ab9fb8', '700 13px ' + FONT); }
      // hint
      if (hintT > 0 && phase === 'run' && h > 210 && !narrow) { ctx.globalAlpha = Math.min(1, hintT); ctx.font = '600 12px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = '#ab9fb8'; ctx.fillText(sp ? '스퍼트 구간: 빠르게 연타! 남은 체력만큼 빨라요' : '초록 칸 템포로 리듬 있게 · 마구 연타는 지쳐요', cx, h - 12); ctx.globalAlpha = 1; }
      else if (h > 210 && !narrow && phase === 'run' && st.ph === 'run') { ctx.font = '600 11px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(171,159,184,.7)'; ctx.fillText('남은 ' + Math.max(0, Math.round(R.ln - q.p)) + 'm', cx, h - 12); }
      ctx.restore();
    }
    function rankOf(s) {
      if (st && st.ph === 'end') { const k = (st.fin || []).findIndex((x) => x[0] === s); if (k >= 0) return k + 1; }
      const o = order(R); return o.findIndex((x) => x[0] === s) + 1;
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        const k = curKey();
        if (st.ph === 'pick') { R = R && key === k ? R : null; syncPicker(); if (!R) { key = k; R = newRace(st.tr, st.ln, st.sd, st.n); phase = 'wait'; layout(); } return; }
        dropPicker();
        if (k !== key || phase === 'wait') { key = k; startRace(); }
        if (st.ph === 'run' && phase === 'count' && !host()) { phase = 'run'; cd = 0; }
        if (st.ph === 'end' && (!prev || prev.ph !== 'end')) {
          endT = END_T;
          const w = st.fin && st.fin[0] ? st.fin[0][0] : -1;
          if (w >= 0 && isMine(w)) { api.sfx('win'); api.buzz(60); } else api.sfx('chip');
        }
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        dropPicker(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ R, st, phase, zones, tv, tapSeat, fb }),
    };
  }

  /* ----- horse art: side view facing right, feet at y = 0 ----- */
  function drawHorse(g, Ho, silk, num, ph, o) {
    const coat = Ho.c, mane = Ho.m, dark = shade(coat, -0.3);
    const jump = o.jump || 0, tuck = jump > 3;
    const bob = tuck ? 0 : Math.sin(ph * 2) * 0.9;
    g.save(); g.translate(0, -jump + bob * 0.5);
    if (o.tilt) g.rotate(o.tilt);
    const leg = (hx, hy, a1, a2, col) => {
      const kx = hx + Math.sin(a1) * 8, ky = hy + Math.cos(a1) * 8, fx = kx + Math.sin(a1 + a2) * 8, fy = ky + Math.cos(a1 + a2) * 8;
      g.strokeStyle = col; g.lineWidth = 2.6; g.lineCap = 'round'; g.lineJoin = 'round';
      g.beginPath(); g.moveTo(hx, hy); g.lineTo(kx, ky); g.lineTo(fx, fy); g.stroke();
      g.fillStyle = '#1a1414'; g.beginPath(); g.arc(fx, fy, 1.5, 0, 7); g.fill();
    };
    const legs = (far) => {
      const col = far ? dark : coat, o1 = far ? 0 : 0.45, o2 = far ? 1.4 : 1.85;
      if (tuck) { leg(-11, -16, -0.9, 1.3, col); leg(10, -15, 1.0, -1.7, col); return; }
      leg(-11, -16, 0.55 * Math.sin(ph + o1), 0.8 * Math.max(0, Math.sin(ph + o1 - 1)), col);
      leg(10, -15, 0.6 * Math.sin(ph + o2), -0.9 * Math.max(0, Math.sin(ph + o2 + 1.2)), col);
    };
    legs(true);
    // tail
    g.strokeStyle = mane; g.lineWidth = 3.2; g.lineCap = 'round';
    g.beginPath(); g.moveTo(-15, -21); g.quadraticCurveTo(-22, -22, -25, -15 + Math.sin(ph * 2) * 2); g.stroke();
    // body
    g.fillStyle = coat;
    g.beginPath(); g.ellipse(0, -18.5, 15, 7.5, 0, 0, 7); g.fill();
    g.beginPath(); g.arc(-10, -18.5, 7.2, 0, 7); g.fill();
    g.beginPath(); g.arc(9, -17.5, 6.8, 0, 7); g.fill();
    if (Ho.sp) { g.fillStyle = mane; g.globalAlpha = 0.75; for (const [x, y, r] of [[-8, -21, 3], [2, -16, 2.4], [-2, -22, 1.6], [7, -20, 2]]) { g.beginPath(); g.ellipse(x, y, r, r * 0.8, 0, 0, 7); g.fill(); } g.globalAlpha = 1; }
    // neck + head
    g.fillStyle = coat;
    g.beginPath(); g.moveTo(7, -23); g.lineTo(13, -33); g.lineTo(19, -31); g.lineTo(15, -16); g.closePath(); g.fill();
    g.save(); g.translate(18, -31); g.rotate(0.55);
    g.beginPath(); g.ellipse(4, 0, 7, 3.4, 0, 0, 7); g.fill();
    g.fillStyle = '#120e10'; g.beginPath(); g.arc(1.5, -1.2, 0.9, 0, 7); g.fill();
    g.restore();
    g.fillStyle = coat; g.beginPath(); g.moveTo(15, -34); g.lineTo(17, -38.5); g.lineTo(18.5, -33.5); g.fill();
    g.strokeStyle = mane; g.lineWidth = 2.6; g.beginPath(); g.moveTo(7.5, -25); g.lineTo(14, -34.5); g.stroke();
    legs(false);
    if (!o.noJockey) {
      // saddle cloth with the lane number
      g.fillStyle = silk; g.fillRect(-7, -23, 10, 7.5);
      g.fillStyle = '#fff'; g.font = '700 6px ' + MONO; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(num, -2, -19);
      // jockey (crouched)
      g.save(); g.translate(1, -28); g.rotate(-0.35);
      g.fillStyle = silk; g.beginPath(); g.ellipse(0, 0, 5.5, 3.2, 0, 0, 7); g.fill();
      g.restore();
      g.strokeStyle = shade(silk, -0.35); g.lineWidth = 2.2; g.beginPath(); g.moveTo(-1, -26); g.lineTo(2, -21.5); g.stroke();
      g.strokeStyle = silk; g.lineWidth = 1.8; g.beginPath(); g.moveTo(3, -28); g.lineTo(11, -27); g.stroke();
      g.fillStyle = shade(silk, -0.2); g.beginPath(); g.arc(5.6, -32.4, 2.9, 0, 7); g.fill();
      g.fillStyle = '#f2e9d8'; g.fillRect(4.5, -35.3, 1.4, 3);
      if (o.tired) { g.fillStyle = 'rgba(255,255,255,.75)'; g.beginPath(); g.arc(27, -30, 1.6, 0, 7); g.arc(30, -33, 1.1, 0, 7); g.fill(); }
    }
    g.restore();
  }

  /* ---------- helpers ---------- */
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'horserace', name: '경마 응원전', tag: '연타 응원 경주', cat: '파티',
    blurb: '내 말을 골라 화면을 톡톡 두드려 응원! 초록 템포로 리듬 있게 치면 빨라지고, 마구 연타하면 지쳐요. 허들 점프와 마지막 스퍼트까지. 혼자면 AI와, 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#6b2f52',
    icon: '<path d="M14 48V30a14 14 0 0128 0v18" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round"/><g fill="#6b2f52"><circle cx="14" cy="36" r="1.8"/><circle cx="15.5" cy="26" r="1.8"/><circle cx="42" cy="36" r="1.8"/><circle cx="40.5" cy="26" r="1.8"/></g><path d="M8 10l5 6M28 6v8M48 10l-5 6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'tap', label: '응원 탭 (허들 점프도)', keys: ['Space', 'Enter'], pad: ['a', 'rb'] },
    ],
    options: [
      { id: 'len', label: '거리', choices: [{ v: 500, label: '단거리 500m' }, { v: 800, label: '중거리 800m' }, { v: 1200, label: '장거리 1200m' }], def: 800 },
      { id: 'track', label: '트랙', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '푸른 잔디' }, { v: 1, label: '장애물 코스' }, { v: 2, label: '진흙 모래길' }], def: -1 },
      { id: 'match', label: '경기', choices: [{ v: 1, label: '한 판 승부' }, { v: 3, label: '3판 2선승' }], def: 1 },
    ],
    quick: [
      '응원할 말을 고르고, 내 구역을 톡톡 두드려 응원해요. 먼저 결승선을 통과한 말이 이겨요.',
      '초록 칸 템포(1초에 3~4번)로 리듬 있게! 마구 연타하면 지쳐서 느려져요.',
      '허들은 링이 겹칠 때 한 번 톡 = 점프. 마지막 금색 구간에선 빠르게 연타 스퍼트!',
    ],
    rules: [
      { h: '목표', p: [
        '각자 말을 한 마리씩 골라 응원해요. 먼저 결승선을 통과한 말이 이겨요.',
        '말의 능력치는 모두 같아요 — 응원 실력 승부!',
        '한 판 승부 또는 3판 2선승(먼저 2번 1등).',
      ] },
      { h: '조작 (터치)', p: [
        '화면 아래 내 응원 구역 아무 데나 톡톡 두드리면 말이 힘을 내요. 응원이 끊기면 점점 느려져요.',
        '템포 막대의 초록 칸 속도(1초에 3~4번쯤)로 리듬 있게 치면 가장 효율이 좋아요.',
        '허들 앞에서는 같은 구역을 한 번 톡 하면 점프예요(아래 「허들」).',
        'PC 키보드·게임패드: 스페이스·Enter·Ⓐ·RB로 탭(누를 때마다 한 번, 허들 점프도 같은 키). 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '체력', p: [
        '초록 칸보다 빠르게 치면 체력이 빨리 닳아요. 빨간 칸(마구 연타)은 힘은 적게 나고 체력만 크게 깎여요.',
        '체력이 0이 되면 약 2초 동안 헉헉대며 느려지고 탭이 먹히지 않아요.',
        '천천히 치거나 잠깐 쉬면 체력이 회복돼요.',
      ] },
      { h: '허들 · 비 · 스퍼트', p: [
        '허들: 「곧 허들!」 표시 뒤 노란 링이 줄어들어요. 링이 초록 링에 겹칠 때 한 번 탭하면 완벽한 점프(잠깐 가속). 너무 이르면 허들 위에 걸쳐 느려지고, 안 뛰면 걸려 크게 느려져요. 점프 구간에서의 탭은 응원이 아니라 점프로 쳐요.',
        '비: 트랙에 따라 경주 중 비가 올 수 있어요. 주로가 무거워 조금 느려지고 체력이 더 닳아요. 초록 칸도 조금 느린 쪽으로 옮겨가요.',
        '스퍼트!: 마지막 직선(금색 구간)에서는 빠르게 연타할수록 좋아요(초록 칸이 빨라져요). 체력은 더 이상 회복되지 않고, 남은 체력이 많을수록 더 빨라요.',
        '트랙: 푸른 잔디(허들 2), 장애물 코스(허들 4 + 물웅덩이), 진흙 모래길(조금 느리고 체력이 더 닳고 비가 자주 와요). 거리는 500 / 800 / 1200m.',
      ] },
      { h: '순위 · 승리', p: [
        '첫 말이 골인하고 12초 안에 못 들어온 말은 그 자리 순서대로 순위가 매겨져요.',
        '3판 2선승에서 3경주까지 2승이 없으면 승수, 그다음 순위 점수(1등 = 인원수 점, 꼴등 = 1점)의 합이 높은 사람이 우승해요.',
      ] },
      { h: '팁', p: [
        '처음부터 세게 치지 말고 초록 칸에 맞춰 체력을 아껴 두세요. 스퍼트에서 남은 체력만큼 빨라져요.',
        '허들 링은 서두르지 마세요. 초록 링에 겹칠 때 딱 한 번!',
        '템포 막대가 빨간 칸으로 가면 손을 조금 늦춰요. 헉헉대는 2초가 가장 큰 손해예요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지 말은 AI가 응원해요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로 해요.',
        '온라인·LAN: 각자 폰으로 경주 화면과 내 응원 구역이 보여요. 경주는 호스트 폰이 계산해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 박자가 들쭉날쭉하고 자주 연타·점프 실수를 하고, 어려움은 정확한 템포로 체력을 아끼다 스퍼트에서 쏟아부어요.',
      ] },
    ],
    init, actor, apply,
    ai: () => null,
    result, mount,
    _t: { HORSES, TRACKS, LENS, H, JW, JP0, JP1, TIRED, band, tapCat, newRace, applyTap, tapAt, hurdleTT, judge, resolveJump, stepRace, raceOver, order, aiStep, targetSpeed, init, actor, apply, autoPick, endRace, nextRace, result },
  });
})();
