/* 뱀 사다리 — reference implementation of the Lounge game interface. */
(function () {
  const L = window.Lounge, U = L.util;
  const LADDERS = { 1: 38, 4: 14, 9: 31, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 80: 100 };
  const SNAKES = { 16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 78 };

  function init(players) {
    return { n: players.length, names: players.map((p) => p.name), pos: players.map(() => 0), turn: 0, last: null, seq: 0, winner: null, g: Math.floor(Math.random() * 1e6) };
  }
  function actor(s) { return s.winner == null ? s.turn : null; }
  function apply(s, seat, a) {
    if (!a || a.type !== 'roll') throw new Error('bad action');
    const roll = 1 + Math.floor(Math.random() * 6);
    const from = s.pos[seat];
    const land = Math.min(100, from + roll); // reaching or passing 100 wins
    let to = land, via = null;
    if (LADDERS[land]) { to = LADDERS[land]; via = 'ladder'; }
    else if (SNAKES[land]) { to = SNAKES[land]; via = 'snake'; }
    s.pos[seat] = to;
    s.seq++;
    s.last = { seat, from, roll, land, to, via, id: s.seq };
    if (to === 100) { s.winner = seat; return s; }
    s.turn = (s.turn + 1) % s.n;
    return s;
  }
  function result(s) {
    if (s.winner == null) return null;
    return { winners: [s.winner], text: '100번 칸에 먼저 도착했어요.' };
  }

  /* board geometry: cell k (1..100) → column/row (row 0 at bottom) */
  function cellXY(k, B) {
    if (k <= 0) return { x: B.x + B.c * 0.5, y: B.y + B.size + B.c * 0.55 };
    const r = Math.floor((k - 1) / 10), c0 = (k - 1) % 10;
    const c = r % 2 === 0 ? c0 : 9 - c0;
    return { x: B.x + c * B.c + B.c / 2, y: B.y + B.size - (r + 1) * B.c + B.c / 2 };
  }

  function mount(root, api) {
    const cv = U.canvas(root);
    const ctx = cv.ctx;
    let st = null, B = null;
    const disp = []; // displayed positions per seat (cell number, float path handled by anims)
    let anim = null; // {seat, path:[{x,y}], t, speed}
    let die = { v: 1, rolling: 0 };
    let shownSeq = 0;

    const hud = L.h('div', { class: 'hud bottom sn-hud' });
    const info = L.h('div', { class: 'panel sn-info', style: { display: 'flex', alignItems: 'center', gap: '10px', fontWeight: 700, minWidth: 0, maxWidth: '100%', boxSizing: 'border-box' } });
    const rollBtn = L.h('button', { class: 'btn primary sn-roll', text: '주사위 굴리기', onclick() { api.sfx('roll'); api.act({ type: 'roll' }); } });
    hud.append(info, rollBtn);
    const top = L.h('div', { class: 'hud top sn-top', style: { gap: '6px' } });
    root.append(hud, top);
    function renderTop() {
      top.innerHTML = '';
      if (!st) return;
      const cur = actor(st);
      for (let i = 0; i < st.n; i++) {
        const p = api.players[i];
        top.append(L.h('span', { class: 'turn', style: { opacity: cur === i || cur == null ? 1 : 0.6, borderColor: cur === i ? p.color : '' } },
          L.h('span', { class: 'dot', style: { '--c': p.color } }), p.name + ' ', L.h('b', { class: 'mono', text: String(disp[i] != null ? disp[i] : st.pos[i]) })));
      }
    }

    function layout() {
      const pad = 16, bottom = 76, topH = 56;
      const size = Math.min(cv.w - pad * 2 - 14, cv.h - bottom - topH - pad);
      const c = size / 10;
      B = { x: (cv.w - size) / 2 + 7, y: topH + Math.max(0, (cv.h - bottom - topH - pad - size) / 2), size, c };
    }
    cv.onresize = () => { layout(); draw(); };
    layout();

    function tokenXY(seat, cellOrXY) {
      const p = typeof cellOrXY === 'number' ? cellXY(cellOrXY, B) : cellOrXY;
      const n = st ? st.n : 1;
      const ang = (seat / n) * Math.PI * 2 - Math.PI / 2;
      const off = n > 1 ? B.c * 0.2 : 0;
      return { x: p.x + Math.cos(ang) * off, y: p.y + Math.sin(ang) * off };
    }

    function drawLadder(a, b) {
      const A = cellXY(a, B), Bp = cellXY(b, B);
      const dx = Bp.x - A.x, dy = Bp.y - A.y, len = Math.hypot(dx, dy);
      const nx = -dy / len, ny = dx / len, w = B.c * 0.18;
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = B.c * 0.13;
      for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(A.x + nx * w * s + 2, A.y + ny * w * s + 3); ctx.lineTo(Bp.x + nx * w * s + 2, Bp.y + ny * w * s + 3); ctx.stroke(); }
      ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = B.c * 0.09;
      const rungs = Math.max(2, Math.round(len / (B.c * 0.42)));
      for (let i = 1; i < rungs; i++) {
        const t = i / rungs, x = A.x + dx * t, y = A.y + dy * t;
        ctx.beginPath(); ctx.moveTo(x + nx * w, y + ny * w); ctx.lineTo(x - nx * w, y - ny * w); ctx.stroke();
      }
      ctx.strokeStyle = '#c98a45'; ctx.lineWidth = B.c * 0.1;
      for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(A.x + nx * w * s, A.y + ny * w * s); ctx.lineTo(Bp.x + nx * w * s, Bp.y + ny * w * s); ctx.stroke(); }
    }
    function drawSnake(head, tail, idx) {
      const H = cellXY(head, B), T = cellXY(tail, B);
      const dx = T.x - H.x, dy = T.y - H.y, len = Math.hypot(dx, dy);
      const nx = -dy / len, ny = dx / len;
      const waves = Math.max(1.5, len / (B.c * 1.6));
      const amp = B.c * 0.32;
      const pts = [];
      const N = 40;
      for (let i = 0; i <= N; i++) {
        const t = i / N;
        const s = Math.sin(t * Math.PI * waves) * amp * (0.4 + 0.6 * Math.sin(t * Math.PI));
        pts.push({ x: H.x + dx * t + nx * s, y: H.y + dy * t + ny * s, t });
      }
      const hues = ['#5fb35a', '#d4593f', '#7a6bd0', '#d29a2c', '#3c9fa6'];
      const col = hues[idx % hues.length];
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (let i = 0; i < N; i++) {
        const a = pts[i], b = pts[i + 1];
        const w = B.c * (0.26 - 0.18 * a.t);
        ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = w + 3;
        ctx.beginPath(); ctx.moveTo(a.x + 1.5, a.y + 2.5); ctx.lineTo(b.x + 1.5, b.y + 2.5); ctx.stroke();
      }
      for (let i = 0; i < N; i++) {
        const a = pts[i], b = pts[i + 1];
        ctx.strokeStyle = i % 4 < 2 ? col : shade(col, -25); ctx.lineWidth = B.c * (0.26 - 0.18 * a.t);
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      }
      // head
      ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(H.x, H.y, B.c * 0.22, B.c * 0.18, Math.atan2(dy, dx), 0, 7); ctx.fill();
      ctx.fillStyle = '#fff';
      const ex = Math.cos(Math.atan2(dy, dx) + Math.PI / 2) * B.c * 0.08, ey = Math.sin(Math.atan2(dy, dx) + Math.PI / 2) * B.c * 0.08;
      for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(H.x + ex * s, H.y + ey * s, B.c * 0.05, 0, 7); ctx.fill(); }
      ctx.fillStyle = '#111';
      for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(H.x + ex * s, H.y + ey * s, B.c * 0.025, 0, 7); ctx.fill(); }
    }
    function shade(hex, amt) {
      const n = parseInt(hex.slice(1), 16);
      const r = U.clamp((n >> 16) + amt, 0, 255), g = U.clamp(((n >> 8) & 255) + amt, 0, 255), b = U.clamp((n & 255) + amt, 0, 255);
      return 'rgb(' + r + ',' + g + ',' + b + ')';
    }

    function draw() {
      cv.clear();
      if (!B) return;
      // board
      ctx.fillStyle = 'rgba(0,0,0,.35)'; roundRect(B.x + 4, B.y + 6, B.size, B.size, 10); ctx.fill();
      ctx.save(); roundRect(B.x, B.y, B.size, B.size, 10); ctx.clip();
      for (let k = 1; k <= 100; k++) {
        const p = cellXY(k, B);
        const r = Math.floor((k - 1) / 10);
        ctx.fillStyle = (k + r) % 2 ? '#f1e2bd' : '#e7cf96';
        if (k === 100) ctx.fillStyle = '#e3ae45';
        ctx.fillRect(p.x - B.c / 2, p.y - B.c / 2, B.c + 0.5, B.c + 0.5);
        ctx.fillStyle = 'rgba(60,40,10,.55)';
        ctx.font = '600 ' + Math.max(8, B.c * 0.22) + 'px "IBM Plex Mono", monospace';
        ctx.textAlign = 'left'; ctx.textBaseline = 'top';
        ctx.fillText(k, p.x - B.c / 2 + 3, p.y - B.c / 2 + 2);
      }
      ctx.restore();
      Object.keys(LADDERS).forEach((a) => drawLadder(+a, LADDERS[a]));
      Object.keys(SNAKES).forEach((hd, i) => drawSnake(+hd, SNAKES[hd], i));
      // tokens
      if (st) {
        const cur = !anim && die.rolling <= 0 ? actor(st) : null;
        const order = [];
        for (let i = 0; i < st.n; i++) if (i !== cur && !(anim && anim.seat === i)) order.push(i);
        if (anim) order.push(anim.seat); else if (cur != null) order.push(cur); // the moving / next token on top
        for (const i of order) {
          let p;
          if (anim && anim.seat === i) p = tokenXY(i, animPoint());
          else p = tokenXY(i, disp[i] != null ? disp[i] : st.pos[i]);
          const r = B.c * 0.2;
          const lift = anim && anim.seat === i ? Math.abs(Math.sin(anim.t * Math.PI)) * B.c * 0.15 : 0;
          ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(p.x + 1, p.y + r * 0.7, r, r * 0.45, 0, 0, 7); ctx.fill();
          ctx.fillStyle = api.players[i].color; ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.arc(p.x, p.y - lift, r, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.beginPath(); ctx.arc(p.x - r * 0.3, p.y - lift - r * 0.3, r * 0.32, 0, 7); ctx.fill();
          if (i === cur) { // whose turn: a ring around that token so it is easy to find
            ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(p.x, p.y, r + 4.5, 0, 7); ctx.stroke();
            ctx.strokeStyle = api.canAct(i) ? '#e3ae45' : '#f2e9d8'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(p.x, p.y, r + 4.5, 0, 7); ctx.stroke();
          }
        }
      }
    }
    function roundRect(x, y, w, hh, r) { ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, hh, r) : ctx.rect(x, y, w, hh); }

    /* animation: token hops cell by cell, then slides on ladder/snake */
    function animPoint() {
      const segs = anim.path.length - 1;
      const f = Math.min(anim.pos, segs - 1e-6);
      const i = Math.floor(f);
      anim.t = f - i;
      const a = anim.path[i], b = anim.path[i + 1];
      return { x: U.lerp(a.x, b.x, anim.t), y: U.lerp(a.y, b.y, anim.t) };
    }
    let stopLoop = null;
    function runAnim(last) {
      const cells = [];
      for (let k = last.from + 1; k <= last.land; k++) cells.push(k);
      const path = [cellXY(last.from, B), ...cells.map((c) => cellXY(c, B))];
      const hopCount = path.length - 1;
      if (last.via) path.push(cellXY(last.to, B));
      anim = { seat: last.seat, path, pos: 0, t: 0, hops: hopCount };
      die.rolling = 0.5;
      api.setBusy(true);
      let lastHop = 0, slideSfx = false;
      if (stopLoop) stopLoop();
      clearTimeout(watchdog);
      // background tabs pause rAF; finish the move anyway so the game never stalls
      watchdog = setTimeout(() => { if (anim) { anim.pos = anim.path.length; die.rolling = 0; tickAnim(0); } }, (1200 + path.length * 400) / L.debug.speed + 1500);
      function tickAnim(dt) {
        if (die.rolling > 0) { die.rolling -= dt; die.v = 1 + Math.floor(Math.random() * 6); if (die.rolling <= 0) { die.v = last.roll; } renderInfo(); draw(); return; }
        const speed = (anim.pos < anim.hops ? 6.5 : 1.6) * L.debug.speed;
        anim.pos += dt * speed;
        if (Math.floor(anim.pos) > lastHop && anim.pos <= anim.hops) { lastHop = Math.floor(anim.pos); api.sfx('tick'); }
        if (anim.pos > anim.hops && last.via && !slideSfx) { slideSfx = true; api.sfx(last.via === 'ladder' ? 'win' : 'lose'); if (api.canAct(last.seat)) api.buzz(last.via === 'ladder' ? 15 : 35); }
        if (anim.pos >= anim.path.length - 1) {
          disp[last.seat] = last.to; anim = null; if (stopLoop) stopLoop(); stopLoop = null; clearTimeout(watchdog);
          draw(); renderInfo(); renderTop(); refreshButton(); api.setBusy(false);
          return;
        }
        draw();
      }
      stopLoop = U.loop(tickAnim);
    }
    let watchdog = 0, pending = false;

    function renderInfo() {
      if (!st) return;
      info.innerHTML = '';
      const dieEl = L.h('span', { class: 'mono', style: { display: 'inline-grid', placeItems: 'center', width: '34px', height: '34px', flex: 'none', borderRadius: '8px', background: 'var(--ink)', color: 'var(--bg)', fontSize: '20px' }, text: die.v });
      const l = st.last, moving = !!(anim || die.rolling > 0);
      const line = (seat, text, style) => L.h('div', { style: Object.assign({ display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden' }, style || {}) },
        seat != null ? L.h('span', { class: 'dot', style: { '--c': api.players[seat].color, flex: 'none' } }) : null,
        L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0 }, text }));
      // line 1: what just happened (the dot is the colour of the player it is about)
      let top = null;
      if (l && moving) top = line(l.seat, api.players[l.seat].name + (die.rolling > 0 ? ' 굴리는 중…' : ' ' + l.roll + '칸 이동'));
      else if (l) top = line(l.seat, api.players[l.seat].name + ' ' + l.roll + (l.to === 100 ? ' · 골인!' : l.via === 'ladder' ? ' · 사다리 ↑' + l.to : l.via === 'snake' ? ' · 뱀 ↓' + l.to : ' → ' + l.to));
      else top = line(null, '100번 칸에 먼저 닿으면 승리');
      // line 2: whose turn now, with a hint for the human on this phone
      let bottom = null;
      const cur = actor(st);
      if (!moving && cur != null) {
        const me = api.canAct(cur);
        let mine = 0; for (let i = 0; i < st.n; i++) if (api.canAct(i)) mine++;
        bottom = line(cur, me ? (mine > 1 ? api.players[cur].name + ' 차례 · ' : '내 차례 · ') + '굴리기 또는 판을 톡' : api.players[cur].name + ' 차례',
          { fontSize: '13px', color: me ? 'var(--brass)' : 'var(--muted)' });
      }
      const col = L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px', minWidth: 0, flex: '1 1 auto', fontSize: bottom ? '13px' : '15px' } }, top, bottom);
      if (bottom && top) { top.style.color = 'var(--ink)'; top.style.opacity = '0.85'; }
      info.append(dieEl, col);
    }

    function refreshButton() {
      const a = st && actor(st);
      rollBtn.hidden = !(a != null && api.canAct(a));
      rollBtn.disabled = !!anim || die.rolling > 0 || pending;
    }
    cv.cv.addEventListener('click', () => { if (!rollBtn.hidden && !rollBtn.disabled) rollBtn.click(); });
    rollBtn.addEventListener('click', () => { pending = true; api.buzz(12); refreshButton(); setTimeout(() => { pending = false; refreshButton(); }, 3000); }, true);

    return {
      update(next, prev) {
        st = next;
        pending = false;
        const key = next.last ? next.g + ':' + next.last.id : '';
        if (next.last && key !== shownSeq && prev && B) {
          shownSeq = key;
          if (anim && stopLoop) { stopLoop(); stopLoop = null; anim = null; }
          for (let i = 0; i < next.n; i++) disp[i] = next.pos[i];
          disp[next.last.seat] = next.last.from;
          runAnim(next.last);
        } else {
          shownSeq = key;
          if (!anim) for (let i = 0; i < next.n; i++) disp[i] = next.pos[i];
        }
        renderInfo(); renderTop(); refreshButton(); draw();
      },
      destroy() { if (stopLoop) stopLoop(); clearTimeout(watchdog); if (anim) api.setBusy(false); cv.destroy(); hud.remove(); top.remove(); },
    };
  }

  L.register({
    id: 'snakes', name: '뱀 사다리', tag: '주사위', blurb: '주사위를 굴려 100번 칸에 먼저 닿으면 승리. 사다리는 올라가고 뱀은 미끄러져요.',
    quick: [
      '말을 100번 칸에 가장 먼저 닿게 하면 이겨요.',
      '내 차례: 주사위를 한 번 굴려 나온 수만큼 앞으로 가요.',
      '사다리 아래에 멈추면 위로 쑥! 뱀 머리에 멈추면 꼬리로 주르륵.',
    ],
    rules: [
      { h: '목표', p: ['주사위를 굴려 말을 움직여요.', '100번 칸(금색)에 가장 먼저 닿는 사람이 이겨요.'] },
      { h: '준비', p: ['모든 말은 판 밖(1번 칸 아래)에서 출발해요.', '칸 번호는 1번(왼쪽 아래)부터 지그재그로 올라가 100번(왼쪽 위)까지 있어요.'] },
      { h: '차례에 할 일', p: ['주사위를 한 번 굴려요.', '나온 수만큼 칸 번호가 커지는 쪽으로 가요.', '6이 나와도 한 번 더 굴리지 않아요. 바로 다음 사람 차례예요.', '같은 칸에 여러 말이 있어도 괜찮아요. 서로 잡지 않아요.'] },
      { h: '사다리와 뱀', p: ['사다리 아래 칸에 멈추면 → 사다리 꼭대기로 올라가요. (예: 28 → 84, 80 → 100)', '뱀 머리 칸에 멈추면 → 꼬리 칸으로 내려가요. (예: 98 → 78, 87 → 24)', '지나가기만 하면 아무 일도 없어요. 멈춘 칸만 따져요.'] },
      { h: '점수·승리', p: ['100번 칸에 닿으면 바로 이겨요.', '정확히 100을 맞출 필요가 없어요. 97에서 5가 나와도 100에 닿아 승리!'] },
      { h: '조작', p: ['내 차례에 아래 「주사위 굴리기」를 누르거나 판을 톡 치세요.', '위쪽에 사람마다 지금 칸 번호가 보여요. 지금 차례인 말에는 동그란 테두리가 있어요.', '아래 칸에 방금 나온 수와 결과, 다음 차례가 보여요.'] },
      { h: '예시', p: ['내 말이 24번 칸에 있어요. 주사위 4 → 28번 칸 → 사다리라서 84번으로 쑥!', '84번에서 3 → 87번 칸 → 뱀 머리라서 24번으로 주르륵…', '운이 전부인 게임이에요. 마음 편히 즐기세요!'] },
    ],
    tutorial: [
      { sel: 'canvas', text: '1번(왼쪽 아래)부터 100번(왼쪽 위)까지 지그재그로 올라가는 판이에요. 100번에 먼저 닿으면 이겨요!' },
      { sel: '.sn-top', text: '위쪽에 사람마다 지금 몇 번 칸에 있는지 보여요. 모두 0(판 밖)에서 시작해요.' },
      { sel: '.sn-hud', text: '내 차례엔 「주사위 굴리기」를 누르거나 판을 톡 치세요. 나온 수만큼 말이 앞으로 가요.' },
      { sel: 'canvas', text: '사다리 아래 칸에 멈추면 꼭대기로 올라가고, 뱀 머리 칸에 멈추면 꼬리로 미끄러져요. 지나가기만 하면 괜찮아요.' },
      { sel: '.sn-info', text: '여기에 방금 나온 수와 결과(사다리 ↑, 뱀 ↓), 다음 차례가 나와요. 그럼 굴려 볼까요?' },
    ],
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, aiDelay: 550,
    init, actor, apply, result, ai: () => ({ type: 'roll' }), mount,
  });
})();
