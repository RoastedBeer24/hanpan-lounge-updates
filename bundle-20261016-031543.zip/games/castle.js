/* 성벽 타일 잇기 — 타일을 한 장씩 뽑아 가장자리(성·길·들판)가 맞게 이어 놓고, 깃발을 꽂아 성·길·탑을 완성해 점수를 모으는 게임.
   타일 그림·구성(30종 72장)·이름·깃발 모양은 모두 이 게임만의 디자인이에요.
   상태(작게): n 인원, b 판(타일마다 4글자: x, y, 종류, 방향 0~3), d 남은 더미(종류 글자), c 지금 놓을 타일(종류 글자, 없으면 ''),
   t 차례, sc 점수, fl 꽂힌 깃발(3글자씩: 타일 번호, 조각 번호, 자리), bd 자리별 점수 내역 [성, 길, 탑, 끝 계산],
   N 처음 더미 장수, ov 끝(1), id 일련번호, last 최근 일 {id, s 자리, k 타일 번호, f 깃발 조각, ev [[자리, 점수, 타일, 조각, 분류]], ds 버린 장수, fin 끝 계산}. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- 기본 값 ---------- */
  const AL = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+,-./:;<=>?@[]^_{|}~';
  const AX = {}; for (let i = 0; i < AL.length; i++) AX[AL[i]] = i;
  const O = 45, LIM = 40;          // 좌표 글자 원점, 판 크기 한계(±40칸)
  const FLAGS = 7;                 // 사람마다 깃발 수
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];   // 위 · 오른쪽 · 아래 · 왼쪽
  const SHORT = 40;                // 「짧게」 더미 장수
  const START = 18;                // 시작 타일 종류(성 끝과 곧은 길)
  // 혼자 하기 별 기준 (보통 71장 / 짧게 40장)
  const STARS = { m: [140, 190, 230], s: [80, 110, 130] };

  /* ---------- 타일 (우리만의 30종) ----------
     [이름, 가장자리(위·오른쪽·아래·왼쪽: c 성 / r 길 / f 들판), 조각들, 장수, 꾸밈]
     조각: 종류(C 성 · R 길 · T 탑) + 이어진 가장자리 번호 + (* 보물, m 시장) + @깃발 자리 [+ #보물 자리]
     꾸밈: B 휜 길, G 성문, V 마을 갈림길, W 우물 네거리, M 시장 광장, S/s 시장 노점(길 위/아래) */
  const TDEF = [
    ['탑', 'ffff', 'T@.5,.5', 4, ''],
    ['탑과 길', 'ffrf', 'T@.5,.42 R2@.5,.82', 2, ''],
    ['탑과 휜 길', 'frfr', 'T@.5,.3 R13@.25,.65', 2, 'B'],
    ['성 아래 탑', 'cfff', 'C0@.5,.13 T@.5,.63', 2, ''],
    ['큰 성', 'cccc', 'C0123*@.5,.5#.5,.24', 1, ''],
    ['세 면 성', 'cccf', 'C012@.6,.5', 3, ''],
    ['세 면 성 (보물)', 'cccf', 'C012*@.6,.5#.76,.5', 1, ''],
    ['성문 길', 'cccr', 'C012@.62,.42 R3@.1,.5', 1, 'G'],
    ['성문 길 (보물)', 'cccr', 'C012*@.62,.42#.72,.7 R3@.1,.5', 2, 'G'],
    ['모퉁이 성', 'ccff', 'C01@.68,.32', 3, ''],
    ['모퉁이 성 (보물)', 'ccff', 'C01*@.66,.34#.84,.17', 2, ''],
    ['모퉁이 성과 길', 'ccrr', 'C01@.72,.28 R23@.37,.63', 3, ''],
    ['모퉁이 성과 길 (보물)', 'ccrr', 'C01*@.72,.28#.86,.14 R23@.37,.63', 1, ''],
    ['성 띠', 'cfcf', 'C02@.5,.5', 1, ''],
    ['성 띠 (보물)', 'cfcf', 'C02*@.5,.55#.5,.2', 2, ''],
    ['마주 본 성', 'cfcf', 'C0@.5,.13 C2@.5,.87', 2, ''],
    ['이웃한 성', 'ccff', 'C0@.45,.13 C1@.87,.55', 2, ''],
    ['성 끝', 'cfff', 'C0@.5,.14', 5, ''],
    ['성 끝과 곧은 길', 'crfr', 'C0@.5,.13 R13@.28,.5', 3, ''],
    ['성 끝과 굽은 길', 'cfrr', 'C0@.5,.13 R23@.37,.63', 2, ''],
    ['성 끝과 굽은 길 2', 'crrf', 'C0@.5,.13 R12@.63,.63', 2, ''],
    ['성 끝과 갈림길', 'crrr', 'C0@.5,.13 R1@.84,.52 R2@.5,.85 R3@.16,.52', 2, 'V'],
    ['곧은 길', 'frfr', 'R13@.3,.5', 6, ''],
    ['굽은 길', 'ffrr', 'R23@.37,.63', 7, ''],
    ['세 갈래 길', 'frrr', 'R1@.84,.5 R2@.5,.84 R3@.16,.5', 4, 'V'],
    ['네 갈래 길', 'rrrr', 'R0@.5,.16 R1@.84,.5 R2@.5,.84 R3@.16,.5', 1, 'W'],
    ['시장 길', 'frfr', 'R13m@.3,.5', 2, 'S'],
    ['시장 굽은 길', 'ffrr', 'R23m@.37,.63', 1, 'S'],
    ['시장 갈림길', 'frrr', 'R1m@.84,.5 R2m@.5,.84 R3m@.16,.5', 1, 'M'],
    ['성 끝과 시장 길', 'crfr', 'C0@.5,.13 R13m@.28,.5', 1, 's'],
  ];
  const TY = TDEF.map(([nm, e, fs, n, d]) => ({
    nm, e, n, d,
    F: fs.split(' ').map((s) => {
      const [a, pos] = s.split('@'); const [p, tp] = pos.split('#');
      const f = { t: a[0], e: [], tr: 0, mk: 0, p: p.split(',').map(Number), tp: tp ? tp.split(',').map(Number) : null };
      for (const ch of a.slice(1)) { if (ch === '*') f.tr = 1; else if (ch === 'm') f.mk = 1; else f.e.push(+ch); }
      return f;
    }),
  }));
  const NT = TY.length;
  const rotP = (p, r) => { let x = p[0], y = p[1]; for (let i = 0; i < r; i++) { const nx = 1 - y; y = x; x = nx; } return [x, y]; };
  // ROT[종류][방향] = { e: 가장자리 4글자, fe: 조각마다 돌린 가장자리, side: 가장자리 → 조각 번호(-1 들판), fp: 돌린 깃발 자리 }
  const ROT = TY.map((T) => [0, 1, 2, 3].map((r) => {
    const e = [0, 1, 2, 3].map((d) => T.e[(d - r + 4) & 3]);
    const fe = T.F.map((f) => f.e.map((x) => (x + r) & 3));
    const side = [-1, -1, -1, -1];
    fe.forEach((es, j) => es.forEach((d) => { side[d] = j; }));
    const sig = e.join('') + '|' + T.F.map((f, j) => f.t + fe[j].slice().sort().join('') + (f.tr ? '*' : '') + (f.mk ? 'm' : '')).sort().join(',');
    return { e, fe, side, fp: T.F.map((f) => rotP(f.p, r)), sig };
  }));
  const UR = ROT.map((rs) => { const seen = new Set(), out = []; rs.forEach((R, r) => { if (!seen.has(R.sig)) { seen.add(R.sig); out.push(r); } }); return out; });
  const DECK_ALL = (() => { let s = ''; TY.forEach((T, i) => { s += AL[i].repeat(T.n); }); return s; })();

  /* ---------- 판 ---------- */
  const key = (x, y) => (x + 128) * 256 + (y + 128);
  function board(bs) {
    const n = bs.length >> 2;
    const B = { n, x: [], y: [], t: [], r: [], at: new Map() };
    for (let i = 0; i < n; i++) {
      const x = AX[bs[i * 4]] - O, y = AX[bs[i * 4 + 1]] - O;
      B.x.push(x); B.y.push(y); B.t.push(AX[bs[i * 4 + 2]]); B.r.push(+bs[i * 4 + 3]);
      B.at.set(key(x, y), i);
    }
    return B;
  }
  function bAdd(B, x, y, t, r) { B.x.push(x); B.y.push(y); B.t.push(t); B.r.push(r); B.at.set(key(x, y), B.n); B.n++; }
  function bPop(B) { B.n--; B.at.delete(key(B.x[B.n], B.y[B.n])); B.x.pop(); B.y.pop(); B.t.pop(); B.r.pop(); }
  const encT = (x, y, t, r) => AL[x + O] + AL[y + O] + AL[t] + r;
  const tileAt = (B, x, y) => { const k = B.at.get(key(x, y)); return k === undefined ? -1 : k; };
  function fits(B, ty, r, x, y) {
    const E = ROT[ty][r].e;
    for (let d = 0; d < 4; d++) {
      const k = B.at.get(key(x + DX[d], y + DY[d]));
      if (k !== undefined && E[d] !== ROT[B.t[k]][B.r[k]].e[(d + 2) & 3]) return false;
    }
    return true;
  }
  function frontier(B) {
    const out = [], seen = new Set();
    for (let i = 0; i < B.n; i++) for (let d = 0; d < 4; d++) {
      const x = B.x[i] + DX[d], y = B.y[i] + DY[d], kk = key(x, y);
      if (seen.has(kk) || B.at.has(kk)) continue;
      seen.add(kk);
      if (Math.abs(x) > LIM || Math.abs(y) > LIM) continue;
      out.push([x, y]);
    }
    return out;
  }
  function movesFor(B, ty, fr) {
    const out = [];
    for (const [x, y] of fr || frontier(B)) for (const r of UR[ty]) if (fits(B, ty, r, x, y)) out.push({ x, y, r });
    return out;
  }
  function hasMove(B, ty, fr) {
    for (const [x, y] of fr || frontier(B)) for (const r of UR[ty]) if (fits(B, ty, r, x, y)) return true;
    return false;
  }

  /* ---------- 깃발 ---------- */
  function flagList(fl) { const out = []; for (let i = 0; i + 2 < fl.length; i += 3) out.push([AX[fl[i]], +fl[i + 1], +fl[i + 2]]); return out; }
  const flagsUsed = (fl, seat) => { let c = 0; for (let i = 2; i < fl.length; i += 3) if (+fl[i] === seat) c++; return c; };

  /* ---------- 조각 묶기: 이어진 성·길을 한 덩어리로 ----------
     돌려주는 것: base(타일 → 첫 조각 번호), find(조각 → 덩어리 대표), G(대표 → 덩어리 {t, open, tiles, tr, mk, fl[자리], nf, sp}) */
  function analyze(B, flags, ns, wantSp) {
    const n = B.n, base = new Int32Array(n + 1);
    let N = 0;
    for (let i = 0; i < n; i++) { base[i] = N; N += TY[B.t[i]].F.length; }
    base[n] = N;
    const par = new Int32Array(N), opn = new Int32Array(N), ntile = new Int32Array(N);
    for (let i = 0; i < N; i++) par[i] = i;
    const find = (a) => { while (par[a] !== a) { par[a] = par[par[a]]; a = par[a]; } return a; };
    const sp = wantSp ? new Array(N) : null;
    for (let i = 0; i < n; i++) {
      const T = TY[B.t[i]], R = ROT[B.t[i]][B.r[i]], x = B.x[i], y = B.y[i];
      for (let j = 0; j < T.F.length; j++) {
        const nd = base[i] + j; ntile[nd] = i;
        if (T.F[j].t === 'T') {
          for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
            if ((dx || dy) && !B.at.has(key(x + dx, y + dy))) { opn[nd]++; if (sp) (sp[nd] || (sp[nd] = [])).push([x + dx, y + dy]); }
          }
          continue;
        }
        for (const e of R.fe[j]) {
          const k = B.at.get(key(x + DX[e], y + DY[e]));
          if (k === undefined) { opn[nd]++; if (sp) (sp[nd] || (sp[nd] = [])).push([x + DX[e], y + DY[e]]); }
          else {
            const jj = ROT[B.t[k]][B.r[k]].side[(e + 2) & 3];
            const a = find(nd), b = find(base[k] + jj);
            if (a !== b) par[a] = b;
          }
        }
      }
    }
    const G = new Map();
    for (let nd = 0; nd < N; nd++) {
      const rt = find(nd), i = ntile[nd], f = TY[B.t[i]].F[nd - base[i]];
      let g = G.get(rt);
      if (!g) { g = { t: f.t, open: 0, tiles: 0, tr: 0, mk: 0, fl: new Array(ns).fill(0), nf: 0, lt: -1, sp: null, n0: nd }; G.set(rt, g); }
      g.open += opn[nd];
      if (g.lt !== i) { g.tiles++; g.lt = i; }
      g.tr += f.tr; if (f.mk) g.mk = 1;
      if (sp && sp[nd]) {
        if (!g.sp) g.sp = [];
        for (const q of sp[nd]) if (!g.sp.some((o) => o[0] === q[0] && o[1] === q[1])) g.sp.push(q);
      }
    }
    for (const g of G.values()) if (g.t === 'T') g.tiles = 9 - g.open;
    for (const [k, j, s] of flags) { if (k >= n) continue; const g = G.get(find(base[k] + j)); if (g) { g.fl[s]++; g.nf++; } }
    return { base, find, G, N, ntile };
  }
  const fullPts = (g) => (g.t === 'C' ? 2 * g.tiles + 2 * g.tr : g.t === 'R' ? g.tiles * (g.mk ? 2 : 1) : 9);
  const endPts = (g) => (g.t === 'C' ? g.tiles + g.tr : g.tiles);
  const CAT = { C: 0, R: 1, T: 2 };
  function owners(g) { let m = 0; g.fl.forEach((c) => { if (c > m) m = c; }); const o = []; if (m > 0) g.fl.forEach((c, s) => { if (c === m) o.push(s); }); return o; }
  // 새 타일 k 와 닿은 덩어리 대표들(새 타일의 조각 + 둘레 9칸의 탑)
  function touchedRoots(A, B, k) {
    const out = [];
    const add = (rt) => { if (!out.includes(rt)) out.push(rt); };
    for (let j = 0; j < TY[B.t[k]].F.length; j++) add(A.find(A.base[k] + j));
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const i = tileAt(B, B.x[k] + dx, B.y[k] + dy);
      if (i < 0 || i === k) continue;
      TY[B.t[i]].F.forEach((f, j) => { if (f.t === 'T') add(A.find(A.base[i] + j)); });
    }
    return out;
  }

  /* ---------- 규칙 ---------- */
  function drawNext(s, B) {
    let ds = 0;
    const fr = frontier(B);
    while (s.d.length) {
      const c = s.d[0]; s.d = s.d.slice(1);
      if (hasMove(B, AX[c], fr)) { s.c = c; return ds; }
      ds++;
    }
    s.c = '';
    return ds;
  }
  function init(players, opts) {
    const n = players.length;
    let deck = U.shuffle(DECK_ALL.split(''));
    if (opts && opts.len === 's') deck = deck.slice(0, SHORT);
    const s = {
      n, nm: players.map((p) => String(p.name || '').slice(0, 12)), b: encT(0, 0, START, 0), d: deck.join(''), c: '', t: 0, sc: new Array(n).fill(0), fl: '',
      bd: Array.from({ length: n }, () => [0, 0, 0, 0]), N: deck.length, ov: 0, id: 0, last: null,
    };
    drawNext(s, board(s.b));
    return s;
  }
  const actor = (s) => (s.ov ? null : s.t);
  function finalScore(s, B, ev) {
    const A = analyze(B, flagList(s.fl), s.n, false);
    for (const [rt, g] of A.G) {
      if (!g.nf || g.open === 0) continue;
      const pts = endPts(g);
      const nd = g.n0, k = A.ntile[nd];
      // 깃발이 꽂힌 조각을 표시 위치로
      let ak = k, aj = nd - A.base[k];
      for (const [fk, fj] of flagList(s.fl)) if (A.find(A.base[fk] + fj) === rt) { ak = fk; aj = fj; break; }
      for (const w of owners(g)) { s.sc[w] += pts; s.bd[w][3] += pts; if (pts) ev.push([w, pts, ak, aj, CAT[g.t]]); }
    }
    s.ov = 1;
  }
  function apply(s, seat, a) {
    if (s.ov || seat !== s.t || !s.c) throw new Error('not your turn');
    if (!a || a.k !== 'p') throw new Error('bad action');
    const x = a.x | 0, y = a.y | 0, r = a.r | 0, f = a.f == null ? -1 : a.f | 0, ty = AX[s.c];
    if (r < 0 || r > 3 || Math.abs(x) > LIM || Math.abs(y) > LIM) throw new Error('bad place');
    const B = board(s.b);
    if (B.at.has(key(x, y))) throw new Error('occupied');
    let adj = false;
    for (let d = 0; d < 4; d++) if (B.at.has(key(x + DX[d], y + DY[d]))) adj = true;
    if (!adj || !fits(B, ty, r, x, y)) throw new Error('does not fit');
    bAdd(B, x, y, ty, r);
    const k = B.n - 1;
    s.b += encT(x, y, ty, r);
    if (f >= 0) {
      if (f >= TY[ty].F.length) throw new Error('bad feature');
      if (flagsUsed(s.fl, seat) >= FLAGS) throw new Error('no flags');
      const A0 = analyze(B, flagList(s.fl), s.n, false);
      if (A0.G.get(A0.find(A0.base[k] + f)).nf) throw new Error('taken');
      s.fl += AL[k] + f + seat;
    }
    // 완성된 성·길·탑 점수 → 깃발 돌려받기
    const A = analyze(B, flagList(s.fl), s.n, false);
    const ev = [], doneR = [];
    for (const rt of touchedRoots(A, B, k)) {
      const g = A.G.get(rt);
      if (g.open !== 0 || !g.nf) continue;
      const pts = fullPts(g);
      let ak = k, aj = -1;
      for (let j = 0; j < TY[ty].F.length; j++) if (A.find(A.base[k] + j) === rt) { aj = j; break; }
      if (aj < 0) { ak = A.ntile[rt]; aj = rt - A.base[ak]; }
      for (const w of owners(g)) { s.sc[w] += pts; s.bd[w][CAT[g.t]] += pts; ev.push([w, pts, ak, aj, CAT[g.t]]); }
      doneR.push(rt);
    }
    if (doneR.length) {
      const keep = flagList(s.fl).filter(([fk, fj]) => !doneR.includes(A.find(A.base[fk] + fj)));
      s.fl = keep.map(([fk, fj, fs]) => AL[fk] + fj + fs).join('');
    }
    s.id++;
    s.last = { id: s.id, s: seat, k, f, ev, ds: 0, fin: 0 };
    s.t = (seat + 1) % s.n;
    s.last.ds = drawNext(s, B);
    if (!s.c) { s.last.fin = 1; finalScore(s, B, s.last.ev); }
    return s;
  }
  function stars(s) { const T = STARS[s.N <= SHORT ? 's' : 'm']; return T.filter((v) => s.sc[0] >= v).length; }
  function result(s) {
    if (!s.ov) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const bdTxt = (i) => '성 ' + s.bd[i][0] + ' · 길 ' + s.bd[i][1] + ' · 탑 ' + s.bd[i][2] + ' · 끝 계산 ' + s.bd[i][3];
    if (s.n === 1) {
      const st = stars(s), T = STARS[s.N <= SHORT ? 's' : 'm'];
      const next = st < 3 ? '\n다음 별까지 ' + (T[st] - s.sc[0]) + '점' : '';
      return { winners: st > 0 ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요',
        text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + s.sc[0] + '점\n' + bdTxt(0) + next + '\n(별 기준 ' + T.join(' / ') + '점)' };
    }
    const max = Math.max(...s.sc);
    const winners = s.sc.map((v, i) => (v === max ? i : -1)).filter((i) => i >= 0);
    const order = s.sc.map((v, i) => i).sort((a, b) => s.sc[b] - s.sc[a]);
    return { winners, text: order.map((i, r) => (r + 1) + '위 ' + nm(i) + ' ' + s.sc[i] + '점 (' + bdTxt(i) + ')').join('\n') };
  }

  /* ---------- AI ---------- */
  const AP = { q: 0.62, tf: 2.2, qT: 0.7, tfT: 1.6, fw: 0.22, m1: 1.7, m2: 1.0, m3: 0.6, k: 8, ns: 8, gap: 10, e1: 6, e2: 0.15, e3: 0.35 };   // 어려움 AI 조절값
  function fitCount(B, x, y, cnt) {
    let m = 0;
    for (let t = 0; t < NT; t++) {
      if (!cnt[t]) continue;
      for (const r of UR[t]) if (fits(B, t, r, x, y)) { m += cnt[t]; break; }
    }
    return m;
  }
  function flagWorth(c, R, n, lv) {
    if (lv < 3) return c * U.clamp((R / Math.max(1, n)) * 0.22, 0.2, 3);
    const base = U.clamp((R / Math.max(1, n)) * AP.fw, 0.2, 3);
    let v = 0;
    for (let i = 0; i < c; i++) v += base * (i < 2 ? AP.m1 : i < 4 ? AP.m2 : AP.m3);
    return v;
  }
  // 덩어리 하나의 기대 점수(주인 한 사람 기준)
  function groupVal(g, B, lv, R, cnt, cache, cx, cy) {
    if (lv < 3) {
      const o = g.open;
      if (g.t === 'T') return g.tiles + o * 0.7 * U.clamp(R / (o * 2.5 + 1), 0, 1);
      const pc = U.clamp((g.t === 'C' ? 0.95 - 0.16 * (o - 1) : 0.97 - 0.12 * (o - 1)), 0.08, 0.95) * U.clamp(R / (o * 3), 0, 1);
      return endPts(g) + pc * (fullPts(g) - endPts(g));
    }
    const spots = g.sp || [];
    const mOf = (q) => {
      const near = Math.abs(q[0] - cx) + Math.abs(q[1] - cy) === 1;
      const kk = key(q[0], q[1]);
      if (!near && cache.has(kk)) return cache.get(kk);
      const m = fitCount(B, q[0], q[1], cnt);
      if (!near) cache.set(kk, m);
      return m;
    };
    if (g.t === 'T') {
      const tf = U.clamp((R + 1) / (spots.length * AP.tfT + 1), 0, 1);
      let v = g.tiles;
      for (const q of spots) { const m = mOf(q); if (m) v += (1 - Math.pow(AP.qT, m)) * tf; }
      return v;
    }
    let pc = 1;
    for (const q of spots) { const m = mOf(q); if (!m) { pc = 0; break; } pc *= 1 - Math.pow(AP.q, m); }
    pc *= U.clamp((R + 1) / (spots.length * AP.tf + 1), 0, 1);
    return endPts(g) + pc * (fullPts(g) - endPts(g));
  }
  function evalMove(s, B, flags, seat, lv, cnt, R, cache) {
    const k = B.n - 1, n = s.n;
    const A = analyze(B, flags, n, lv >= 3);
    const sc = s.sc.slice(), hand = [];
    for (let i = 0; i < n; i++) hand.push(FLAGS - flags.filter((q) => q[2] === i).length);
    const done = new Set(), hand0 = hand[seat];
    for (const rt of touchedRoots(A, B, k)) {
      const g = A.G.get(rt);
      if (g.open || !g.nf) continue;
      const pts = fullPts(g);
      owners(g).forEach((w) => { sc[w] += pts; });
      g.fl.forEach((c, i) => { hand[i] += c; });
      done.add(rt);
    }
    const pot = new Array(n).fill(0);
    const gv = new Map();
    for (const [rt, g] of A.G) {
      if (!g.nf || done.has(rt)) continue;
      const v = groupVal(g, B, lv, R, cnt, cache, B.x[k], B.y[k]);
      gv.set(rt, v);
      for (const w of owners(g)) pot[w] += v;
    }
    const E = (i, dh) => sc[i] + pot[i] + flagWorth(hand[i] + (dh || 0), R, n, lv);
    const rel = (mine) => { if (n === 1) return mine; let o = 0; for (let i = 0; i < n; i++) if (i !== seat) o += E(i); return mine - o / (n - 1); };
    const e0 = E(seat);
    let best = { v: rel(e0), f: -1 };
    if (hand0 > 0) {
      const F = TY[B.t[k]].F;
      for (let j = 0; j < F.length; j++) {
        const rt = A.find(A.base[k] + j), g = A.G.get(rt);
        if (g.nf) continue;
        let mine;
        if (!g.open) mine = e0 + fullPts(g);               // 바로 완성 → 깃발은 곧바로 돌아옴
        else mine = sc[seat] + pot[seat] + groupVal(g, B, lv, R, cnt, cache, B.x[k], B.y[k]) + flagWorth(hand[seat] - 1, R, n, lv);
        const v = rel(mine);
        if (v > best.v + 0.01) best = { v, f: j };
      }
    }
    return best;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const B = board(s.b), ty = AX[s.c], flags = flagList(s.fl);
    const moves = movesFor(B, ty);
    if (!moves.length) throw new Error('no move');   // drawNext 가 막아 줘서 안 생김
    const left = FLAGS - flags.filter((q) => q[2] === seat).length;
    const cnt = new Array(NT).fill(0);
    for (const ch of s.d) cnt[AX[ch]]++;
    const R = s.d.length, cache = new Map();
    if (lv <= 1) {
      // 쉬움: 보통처럼 따지긴 하지만 판단이 많이 흔들리고, 가끔 아무 데나 놓고, 깃발을 기분 따라 꽂아요.
      let best = null, bv = -1e9;
      for (const m of moves) {
        bAdd(B, m.x, m.y, ty, m.r);
        const e = evalMove(s, B, flags, seat, 2, cnt, R, cache);
        bPop(B);
        const v = e.v + Math.random() * AP.e1;
        if (v > bv) { bv = v; best = { k: 'p', x: m.x, y: m.y, r: m.r, f: e.f }; }
      }
      if (Math.random() < AP.e2) { const m = moves[U.rand(moves.length)]; best = { k: 'p', x: m.x, y: m.y, r: m.r, f: -1 }; }
      if (left > 0 && Math.random() < AP.e3) {
        bAdd(B, best.x, best.y, ty, best.r);
        const A = analyze(B, flags, s.n, false);
        const free = TY[ty].F.map((_, j) => j).filter((j) => !A.G.get(A.find(A.base[B.n - 1] + j)).nf);
        best.f = free.length && Math.random() < 0.7 ? free[U.rand(free.length)] : -1;
        bPop(B);
      }
      return best;
    }
    const scored = [];
    for (const m of moves) {
      bAdd(B, m.x, m.y, ty, m.r);
      const e = evalMove(s, B, flags, seat, lv, cnt, R, cache);
      bPop(B);
      scored.push({ a: { k: 'p', x: m.x, y: m.y, r: m.r, f: e.f }, v: e.v + (lv === 2 ? Math.random() * 0.8 : Math.random() * 0.05) });
    }
    scored.sort((p, q) => q.v - p.v);
    if (lv < 3 || s.n < 2 || !s.d.length) return scored[0].a;
    // 어려움: 좋은 수 몇 개만 골라, 다음 사람이 뽑을 만한 타일로 가장 좋은 응수를 해 본 뒤 다시 따져요(남은 타일 수만 씀, 더미 순서는 안 봐요).
    const types = [];
    for (let t = 0; t < NT; t++) if (cnt[t]) types.push(t);
    types.sort((p, q) => cnt[q] - cnt[p]);
    const samp = types.slice(0, AP.ns);
    const K = Math.min(AP.k, scored.length);
    let best = scored[0].a, bv = -1e9;
    const t0 = Date.now();
    for (let i = 0; i < K; i++) {
      const c = scored[i];
      if (scored[0].v - c.v > AP.gap || (i >= 2 && Date.now() - t0 > 70)) break;   // 느린 폰에서도 300ms 안쪽
      let s1;
      try { s1 = apply(JSON.parse(JSON.stringify(s)), seat, c.a); } catch (e) { continue; }
      let v;
      if (s1.ov) v = posEval(s1, seat, cnt, 0);
      else {
        const opp = s1.t, B1 = board(s1.b), fr1 = frontier(B1);
        let tot = 0, ws = 0;
        for (const t of samp) {
          if (!hasMove(B1, t, fr1)) continue;
          const s1b = JSON.parse(JSON.stringify(s1)); s1b.c = AL[t];
          const cnt2 = cnt.slice(); cnt2[t]--;
          const rep = replyFor(s1b, opp, cnt2, R - 1);
          const s2 = apply(s1b, opp, rep);
          tot += cnt[t] * posEval(s2, seat, cnt2, R - 1); ws += cnt[t];
        }
        v = ws ? tot / ws : c.v;
      }
      if (v > bv) { bv = v; best = c.a; }
    }
    return best;
  }
  // 상대의 가장 좋은 응수(보통 수준 판단, 흔들림 없음)
  function replyFor(s, seat, cnt, R) {
    const B = board(s.b), ty = AX[s.c], flags = flagList(s.fl), cache = new Map();
    let best = null, bv = -1e9;
    for (const m of movesFor(B, ty)) {
      bAdd(B, m.x, m.y, ty, m.r);
      const e = evalMove(s, B, flags, seat, 2, cnt, R, cache);
      bPop(B);
      if (e.v > bv) { bv = e.v; best = { k: 'p', x: m.x, y: m.y, r: m.r, f: e.f }; }
    }
    return best;
  }
  // 놓인 판 그대로의 형세 (seat 기준)
  function posEval(s, seat, cnt, R) {
    const n = s.n;
    const rel = (E) => { if (n === 1) return E[seat]; let o = 0; for (let i = 0; i < n; i++) if (i !== seat) o += E[i]; return E[seat] - o / (n - 1); };
    if (s.ov) return rel(s.sc);
    const B = board(s.b), flags = flagList(s.fl);
    const A = analyze(B, flags, n, true), cache = new Map();
    const E = s.sc.slice();
    for (const g of A.G.values()) {
      if (!g.nf) continue;
      const v = groupVal(g, B, 3, R, cnt, cache, 1e6, 1e6);
      for (const w of owners(g)) E[w] += v;
    }
    for (let i = 0; i < n; i++) E[i] += flagWorth(FLAGS - flags.filter((q) => q[2] === i).length, R, n, 3);
    return rel(E);
  }
  const aiDelayFor = (s, seat, lv) => (lv === 1 ? 950 : lv === 3 ? 650 : 800);

  /* =====================================================================
     화면
     ===================================================================== */
  const CSS = `
.cs-wrap{position:absolute;inset:0;display:flex;flex-direction:column;background:#17131f;-webkit-user-select:none;user-select:none}
.cs-pl{display:flex;gap:4px;padding:6px 8px 4px;flex:none}
.cs-p{flex:1 1 0;min-width:0;height:46px;border-radius:10px;background:#221c2e;border:1px solid var(--line);padding:2px 6px;display:flex;flex-direction:column;justify-content:center;gap:1px;overflow:hidden;transition:border-color .2s,box-shadow .2s}
.cs-p .nm{font-size:12px;font-weight:700;display:flex;align-items:center;gap:4px;white-space:nowrap;min-width:0;line-height:1.25}
.cs-p .nm .t{overflow:hidden;text-overflow:ellipsis;min-width:0}
.cs-p .nm .dot{flex:none;width:9px;height:9px}
.cs-p .l{display:flex;align-items:center;gap:5px;font:700 11px var(--f-mono),monospace;color:var(--muted);white-space:nowrap;line-height:1.2}
.cs-p .l b{color:var(--ink);font-size:14px}
.cs-p .l .fg{display:inline-flex;align-items:center;gap:2px}
.cs-p .l svg{width:9px;height:12px;flex:none}
.cs-p.cur{border-color:var(--c);box-shadow:inset 0 0 0 1px var(--c),0 0 12px -4px var(--c)}
.cs-pl.tight .cs-p{padding:2px 4px}.cs-pl.tight .cs-p .l{gap:3px}
.cs-board{position:relative;flex:1 1 auto;min-height:120px;overflow:hidden;touch-action:none;cursor:grab}
.cs-board.hov{cursor:pointer}
.cs-zoom{position:absolute;right:6px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:6px;z-index:2}
.cs-zoom button{appearance:none;width:44px;height:44px;border-radius:12px;border:1px solid var(--line);background:rgba(23,19,31,.82);color:var(--ink);font:700 20px var(--f-mono),monospace;display:grid;place-items:center;padding:0;cursor:pointer;touch-action:manipulation}
.cs-zoom button:active{transform:scale(.94)}
.cs-bar{flex:none;background:#221c2e;border-top:1px solid var(--line);padding:7px 10px 9px;display:flex;flex-direction:column;gap:7px;box-shadow:0 -8px 20px rgba(0,0,0,.3)}
.cs-hint{font-size:13px;line-height:1.35;min-height:35px;display:flex;align-items:center;justify-content:center;text-align:center;color:var(--muted)}
.cs-hint b{color:var(--brass)}
.cs-hint .ok{color:#8fe0a4;font-weight:700}
.cs-row{display:flex;align-items:center;gap:8px;min-height:64px}
.cs-cur{width:64px;height:64px;flex:none;border-radius:8px;position:relative;cursor:pointer;box-shadow:0 3px 8px rgba(0,0,0,.45),0 0 0 2px rgba(227,174,69,.55);transition:transform .15s}
.cs-cur:active{transform:scale(.95)}
.cs-cur canvas{width:64px;height:64px;display:block;border-radius:6px}
.cs-cur .dk{position:absolute;left:50%;bottom:-7px;transform:translateX(-50%);font:700 10px var(--f-mono),monospace;background:#17131f;color:var(--brass);border:1px solid var(--line);border-radius:999px;padding:0 5px;white-space:nowrap;line-height:15px}
.cs-cur.empty{box-shadow:none;border:1.5px dashed var(--line)}
.cs-btns{flex:1 1 auto;display:flex;gap:6px;min-width:0}
.cs-btns .btn{flex:1 1 0;min-width:0;min-height:52px;padding:4px 6px;font-size:14px;white-space:nowrap}
.cs-btns .btn .k{font-size:17px;line-height:1}
.cs-opts{display:flex;flex-wrap:wrap;gap:6px}
.cs-opts:empty{display:none}
.cs-opt{appearance:none;flex:1 1 30%;min-width:92px;min-height:48px;border-radius:11px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-weight:700;font-size:13px;display:flex;align-items:center;gap:7px;padding:3px 8px;cursor:pointer;text-align:left;line-height:1.15;touch-action:manipulation}
.cs-opt .tx{display:flex;flex-direction:column;min-width:0}
.cs-opt small{font-size:11px;font-weight:600;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cs-opt small b{color:#8fe0a4}
.cs-opt.on{border-color:var(--c);box-shadow:inset 0 0 0 2px var(--c);background:#3a2f22}
.cs-opt:disabled{opacity:.42;cursor:default}
.cs-opt svg{width:20px;height:20px;flex:none}
.cs-tip{font-size:11.5px;color:var(--muted);text-align:center;margin-top:-3px}
`;
  const FLAG_SVG = (c) => '<svg viewBox="0 0 9 12"><path d="M1.5 0.5v11" stroke="#d9cbb0" stroke-width="1.3"/><path d="M2 1h6l-2 2 2 2H2z" fill="' + c + '" stroke="rgba(0,0,0,.4)" stroke-width=".5"/></svg>';
  const OPT_SVG = {
    C: '<svg viewBox="0 0 20 20"><path d="M2 18V7h3v3h3V7h4v3h3V7h3v11z" fill="#d6bf92" stroke="#5d5040" stroke-width="1.2"/><rect x="8" y="12" width="4" height="6" fill="#4a3a2a"/></svg>',
    R: '<svg viewBox="0 0 20 20"><path d="M3 18C6 12 14 9 17 2" stroke="#5b4a33" stroke-width="6" fill="none"/><path d="M3 18C6 12 14 9 17 2" stroke="#e0c995" stroke-width="4" fill="none"/></svg>',
    T: '<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8" fill="#8f8371" stroke="#4d4538" stroke-width="1.2"/><circle cx="10" cy="10" r="5" fill="#a8424d"/></svg>',
    N: '<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="7.5" fill="none" stroke="#ab9fb8" stroke-width="1.6"/><path d="M5 15L15 5" stroke="#ab9fb8" stroke-width="1.6"/></svg>',
  };
  const FNAME = { C: '성', R: '길', T: '탑' };
  const ARROW = ['↑', '→', '↓', '←'];

  // 작은 결정적 난수 (그림용)
  function prng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const MID = [[0.5, 0], [1, 0.5], [0.5, 1], [0, 0.5]];
  // 성 모양: 기본형(위쪽 가장자리 기준) + 몇 번 돌렸는지
  function canonC(es) {
    for (let k = 0; k < 4; k++) {
      const key2 = es.map((e) => (e - k + 4) & 3).sort().join('');
      if (key2 === '0' || key2 === '01' || key2 === '02' || key2 === '012' || key2 === '0123') return [k, key2];
    }
    return [0, '0'];
  }
  const CSH = {
    '0': { path(g) { g.moveTo(0, 0); g.lineTo(1, 0); g.quadraticCurveTo(0.5, 0.56, 0, 0); }, walls: [[1, 0, 0.5, 0.56, 0, 0]], houses: [[0.32, 0.09, 0.2], [0.62, 0.1, -0.15]] },
    '01': { path(g) { g.moveTo(0, 0); g.lineTo(1, 0); g.lineTo(1, 1); g.quadraticCurveTo(0.42, 0.58, 0, 0); }, walls: [[1, 1, 0.42, 0.58, 0, 0]], houses: [[0.45, 0.12, 0.1], [0.86, 0.5, -0.2], [0.78, 0.2, 0.4], [0.62, 0.4, -0.5]] },
    '02': { path(g) { g.moveTo(0, 0); g.lineTo(1, 0); g.quadraticCurveTo(0.64, 0.5, 1, 1); g.lineTo(0, 1); g.quadraticCurveTo(0.36, 0.5, 0, 0); }, walls: [[1, 0, 0.64, 0.5, 1, 1], [0, 1, 0.36, 0.5, 0, 0]], houses: [[0.3, 0.12, 0.2], [0.68, 0.86, -0.1], [0.38, 0.78, 0.5], [0.66, 0.2, -0.4]] },
    '012': { path(g) { g.moveTo(0, 0); g.lineTo(1, 0); g.lineTo(1, 1); g.lineTo(0, 1); g.quadraticCurveTo(0.44, 0.5, 0, 0); }, walls: [[0, 1, 0.44, 0.5, 0, 0]], houses: [[0.38, 0.15, 0.2], [0.82, 0.2, -0.3], [0.86, 0.78, 0.15], [0.4, 0.86, -0.2], [0.8, 0.5, 0.6]] },
    '0123': { path(g) { g.rect(0, 0, 1, 1); }, walls: [], houses: [[0.2, 0.2, 0.2], [0.8, 0.22, -0.3], [0.22, 0.8, -0.1], [0.78, 0.8, 0.35], [0.24, 0.5, 0.5], [0.76, 0.52, -0.5]] },
  };
  function roadPath(g, T, f) {
    g.beginPath();
    if (f.e.length === 2) {
      const [a, b] = f.e, A = MID[a], Bp = MID[b];
      g.moveTo(A[0], A[1]);
      if (((a + 2) & 3) === b) { if (T.d === 'B') g.quadraticCurveTo(0.5, 0.9, Bp[0], Bp[1]); else g.lineTo(Bp[0], Bp[1]); }
      else g.quadraticCurveTo(0.5, 0.5, Bp[0], Bp[1]);
    } else {
      const A = MID[f.e[0]];
      g.moveTo(A[0], A[1]);
      if (T.d === 'G') g.lineTo(0.3, 0.5); else g.lineTo(0.5, T.d === 'V' && T.F[0].t === 'C' ? 0.53 : 0.5);
    }
  }
  function house(g, x, y, a, sz, rnd) {
    g.save(); g.translate(x, y); g.rotate(a);
    const w = sz * (0.9 + rnd() * 0.3), hh = sz * 0.68;
    g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(-w / 2 + 0.012, -hh / 2 + 0.016, w, hh);
    const roof = ['#a4492f', '#8d3d2a', '#b0593a', '#7c4a35'][Math.floor(rnd() * 4)];
    g.fillStyle = roof; g.fillRect(-w / 2, -hh / 2, w, hh / 2);
    g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(-w / 2, 0, w, hh / 2);
    g.fillStyle = roof; g.globalAlpha = 0.75; g.fillRect(-w / 2, 0, w, hh / 2); g.globalAlpha = 1;
    g.strokeStyle = 'rgba(40,15,8,.7)'; g.lineWidth = 0.008; g.strokeRect(-w / 2, -hh / 2, w, hh);
    g.beginPath(); g.moveTo(-w / 2, 0); g.lineTo(w / 2, 0); g.stroke();
    g.restore();
  }
  function wall(g, w) {
    const [x0, y0, cx, cy, x1, y1] = w;
    const path = () => { g.beginPath(); g.moveTo(x0, y0); g.quadraticCurveTo(cx, cy, x1, y1); };
    g.lineCap = 'butt';
    g.save(); g.translate(0.012, 0.02); path(); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 0.09; g.stroke(); g.restore();
    path(); g.strokeStyle = '#4f4537'; g.lineWidth = 0.085; g.stroke();
    path(); g.strokeStyle = '#b4a384'; g.lineWidth = 0.05; g.stroke();
    path(); g.strokeStyle = '#e6d9bb'; g.lineWidth = 0.03; g.setLineDash([0.03, 0.03]); g.stroke(); g.setLineDash([]);
  }
  function treasure(g, x, y) {
    g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.arc(x + 0.01, y + 0.015, 0.07, 0, 7); g.fill();
    const gr = g.createRadialGradient(x - 0.02, y - 0.02, 0.005, x, y, 0.07);
    gr.addColorStop(0, '#fff0b8'); gr.addColorStop(0.55, '#e2ad3e'); gr.addColorStop(1, '#9c6a17');
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, 0.065, 0, 7); g.fill();
    g.strokeStyle = '#6a470d'; g.lineWidth = 0.01; g.stroke();
    g.fillStyle = '#c8384a'; g.beginPath(); g.moveTo(x, y - 0.035); g.lineTo(x + 0.028, y); g.lineTo(x, y + 0.035); g.lineTo(x - 0.028, y); g.closePath(); g.fill();
    g.fillStyle = 'rgba(255,255,255,.6)'; g.beginPath(); g.moveTo(x, y - 0.035); g.lineTo(x + 0.012, y - 0.01); g.lineTo(x - 0.008, y - 0.01); g.closePath(); g.fill();
  }
  function tower(g, x, y) {
    g.fillStyle = 'rgba(0,0,0,.38)'; g.beginPath(); g.arc(x + 0.025, y + 0.035, 0.175, 0, 7); g.fill();
    g.fillStyle = '#8f8371'; g.beginPath(); g.arc(x, y, 0.17, 0, 7); g.fill();
    g.strokeStyle = '#4d4538'; g.lineWidth = 0.014; g.stroke();
    g.strokeStyle = '#cfc3aa'; g.lineWidth = 0.032; g.setLineDash([0.034, 0.028]); g.beginPath(); g.arc(x, y, 0.15, 0, 7); g.stroke(); g.setLineDash([]);
    const gr = g.createRadialGradient(x - 0.04, y - 0.04, 0.01, x, y, 0.125);
    gr.addColorStop(0, '#e07a7c'); gr.addColorStop(0.6, '#a8424d'); gr.addColorStop(1, '#5e1d31');
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, 0.122, 0, 7); g.fill();
    g.strokeStyle = 'rgba(40,8,18,.55)'; g.lineWidth = 0.008;
    for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * 0.122, y + Math.sin(a) * 0.122); g.stroke(); }
    g.fillStyle = '#f0c35a'; g.beginPath(); g.arc(x, y, 0.022, 0, 7); g.fill();
  }
  function awning(g, x, y, w, hh) {
    g.fillStyle = 'rgba(0,0,0,.32)'; g.fillRect(x - w / 2 + 0.012, y - hh / 2 + 0.018, w, hh);
    const n = 5;
    for (let i = 0; i < n; i++) { g.fillStyle = i % 2 ? '#f2e9d8' : '#d9533f'; g.fillRect(x - w / 2 + (w / n) * i, y - hh / 2, w / n + 0.001, hh); }
    g.strokeStyle = 'rgba(60,20,10,.6)'; g.lineWidth = 0.008; g.strokeRect(x - w / 2, y - hh / 2, w, hh);
    g.fillStyle = '#c89a4a'; g.beginPath(); g.arc(x + w / 2 + 0.035, y + hh / 2 - 0.01, 0.022, 0, 7); g.fill();
    g.fillStyle = '#6d8f3a'; g.beginPath(); g.arc(x + w / 2 + 0.03, y - hh / 2 + 0.02, 0.018, 0, 7); g.fill();
  }
  function paintTile(g, ty) {
    const T = TY[ty], rnd = prng(ty * 977 + 13);
    // 들판
    const gr = g.createLinearGradient(0, 0, 1, 1);
    gr.addColorStop(0, '#80ad4f'); gr.addColorStop(1, '#5f8c3a');
    g.fillStyle = gr; g.fillRect(0, 0, 1, 1);
    for (let i = 0; i < 80; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(38,70,20,.2)' : 'rgba(210,235,130,.16)'; const s = 0.01 + rnd() * 0.02; g.fillRect(rnd(), rnd(), s, s); }
    g.strokeStyle = 'rgba(40,72,22,.55)'; g.lineWidth = 0.012; g.lineCap = 'round';
    for (let i = 0; i < 7; i++) { const x = 0.08 + rnd() * 0.84, y = 0.08 + rnd() * 0.84; g.beginPath(); g.moveTo(x - 0.02, y - 0.03); g.lineTo(x, y); g.lineTo(x + 0.02, y - 0.035); g.stroke(); }
    // 꽃 몇 송이
    for (let i = 0; i < 4; i++) { g.fillStyle = rnd() < 0.5 ? '#f2e3a0' : '#e8a0b0'; g.beginPath(); g.arc(0.06 + rnd() * 0.88, 0.06 + rnd() * 0.88, 0.011, 0, 7); g.fill(); }
    // 길
    g.lineCap = 'butt'; g.lineJoin = 'round';
    for (const f of T.F) if (f.t === 'R') {
      roadPath(g, T, f); g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 0.22; g.stroke();
      roadPath(g, T, f); g.strokeStyle = '#6b5638'; g.lineWidth = 0.19; g.stroke();
      roadPath(g, T, f); g.strokeStyle = '#dcc493'; g.lineWidth = 0.15; g.stroke();
      roadPath(g, T, f); g.strokeStyle = 'rgba(140,105,60,.5)'; g.lineWidth = 0.014; g.setLineDash([0.035, 0.045]); g.stroke(); g.setLineDash([]);
    }
    // 성
    for (const f of T.F) if (f.t === 'C') {
      const [k, ck] = canonC(f.e), S = CSH[ck];
      g.save(); g.translate(0.5, 0.5); g.rotate(k * Math.PI / 2); g.translate(-0.5, -0.5);
      g.save(); g.beginPath(); S.path(g); g.closePath(); g.clip();
      const cg = g.createLinearGradient(0, 0, 1, 1); cg.addColorStop(0, '#d3cab4'); cg.addColorStop(1, '#a89c82');
      g.fillStyle = cg; g.fillRect(0, 0, 1, 1);
      for (let i = 0; i < 60; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(110,85,50,.16)' : 'rgba(255,248,225,.2)'; g.fillRect(rnd(), rnd(), 0.03 + rnd() * 0.03, 0.018); }
      for (const [hx, hy, ha] of S.houses) house(g, hx, hy, ha, ck === '0' ? 0.12 : 0.14, rnd);
      g.restore();
      for (const w of S.walls) wall(g, w);
      g.restore();
      if (f.tr && f.tp) treasure(g, f.tp[0], f.tp[1]);
    }
    // 성문
    if (T.d === 'G') {
      g.fillStyle = '#3a2d20'; g.beginPath(); g.moveTo(0.18, 0.44); g.lineTo(0.27, 0.44); g.lineTo(0.27, 0.56); g.lineTo(0.18, 0.56); g.closePath(); g.fill();
      g.fillStyle = '#7a5a33'; g.fillRect(0.2, 0.46, 0.05, 0.08);
    }
    // 탑
    for (const f of T.F) if (f.t === 'T') tower(g, f.p[0], f.p[1]);
    // 마을 · 우물 · 시장
    if (T.d === 'V') {
      const cy = T.F[0].t === 'C' ? 0.55 : 0.5;
      g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.arc(0.5 + 0.01, cy + 0.015, 0.12, 0, 7); g.fill();
      g.fillStyle = '#c9ad7c'; g.beginPath(); g.arc(0.5, cy, 0.115, 0, 7); g.fill();
      house(g, 0.5, cy, 0.05, 0.17, rnd);
    } else if (T.d === 'W') {
      g.fillStyle = '#c9ad7c'; g.beginPath(); g.arc(0.5, 0.5, 0.13, 0, 7); g.fill();
      g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.arc(0.51, 0.515, 0.085, 0, 7); g.fill();
      g.fillStyle = '#8d877c'; g.beginPath(); g.arc(0.5, 0.5, 0.08, 0, 7); g.fill();
      g.strokeStyle = '#4d4538'; g.lineWidth = 0.01; g.stroke();
      g.fillStyle = '#3f7fa8'; g.beginPath(); g.arc(0.5, 0.5, 0.05, 0, 7); g.fill();
      g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.arc(0.485, 0.485, 0.015, 0, 7); g.fill();
    } else if (T.d === 'M') {
      g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.arc(0.51, 0.515, 0.16, 0, 7); g.fill();
      g.fillStyle = '#d6bf92'; g.beginPath(); g.arc(0.5, 0.5, 0.155, 0, 7); g.fill();
      g.strokeStyle = '#8a7350'; g.lineWidth = 0.01; g.stroke();
      awning(g, 0.47, 0.47, 0.17, 0.11);
    } else if (T.d === 'S') {
      if (T.F[0].e.length === 2 && ((T.F[0].e[0] + 2) & 3) === T.F[0].e[1]) awning(g, 0.6, 0.24, 0.2, 0.11);
      else awning(g, 0.7, 0.28, 0.2, 0.11);
    } else if (T.d === 's') awning(g, 0.6, 0.77, 0.2, 0.11);
    // 시장 표시: 길 위 작은 동전
    // 테두리 (빛·그림자)
    g.lineWidth = 0.02; g.lineCap = 'butt';
    g.strokeStyle = 'rgba(255,250,225,.22)'; g.beginPath(); g.moveTo(0.01, 0.99); g.lineTo(0.01, 0.01); g.lineTo(0.99, 0.01); g.stroke();
    g.strokeStyle = 'rgba(0,0,0,.32)'; g.beginPath(); g.moveTo(0.99, 0.01); g.lineTo(0.99, 0.99); g.lineTo(0.01, 0.99); g.stroke();
  }
  // 조각 모양 (기본 방향, 0..1 좌표) — 강조 표시용
  function featShape(g, T, f, lw) {
    if (f.t === 'C') {
      const [k, ck] = canonC(f.e);
      g.save(); g.translate(0.5, 0.5); g.rotate(k * Math.PI / 2); g.translate(-0.5, -0.5);
      g.beginPath(); CSH[ck].path(g); g.closePath(); g.fill();
      g.restore();
    } else if (f.t === 'R') {
      roadPath(g, T, f); g.lineWidth = lw || 0.2; g.lineCap = 'round'; g.stroke();
    } else { g.beginPath(); g.arc(f.p[0], f.p[1], 0.2, 0, 7); g.fill(); }
  }

  const TP = 224;
  const artCache = [];
  function tileArt(ty) {
    if (!artCache[ty]) {
      const c = document.createElement('canvas'); c.width = c.height = TP;
      const g = c.getContext('2d'); g.scale(TP, TP); paintTile(g, ty);
      artCache[ty] = c;
    }
    return artCache[ty];
  }

  function mount(root, api) {
    const h = L.h;
    const spd = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'cs-wrap' });
    const plEl = h('div', { class: 'cs-pl' });
    const bdEl = h('div', { class: 'cs-board' });
    const barEl = h('div', { class: 'cs-bar' });
    wrap.append(plEl, bdEl, barEl);
    root.append(style, wrap);
    const cv = U.canvas(bdEl), ctx = cv.ctx;
    const zoomEl = h('div', { class: 'cs-zoom' },
      h('button', { text: '+', 'aria-label': '확대', onclick() { zoomBy(1.3); } }),
      h('button', { text: '−', 'aria-label': '축소', onclick() { zoomBy(1 / 1.3); } }),
      h('button', { text: '⤢', 'aria-label': '판 전체 보기', onclick() { auto = true; fitCam(true); } }));
    bdEl.append(zoomEl);
    const hintEl = h('div', { class: 'cs-hint' });
    const optsEl = h('div', { class: 'cs-opts' });
    const curCv = h('canvas', { width: 128, height: 128 });
    const dkEl = h('span', { class: 'dk' });
    const curEl = h('div', { class: 'cs-cur', role: 'button', 'aria-label': '이번 타일 (누르면 돌리기)', onclick() { rotate(); } }, curCv, dkEl);
    const btnsEl = h('div', { class: 'cs-btns' });
    const rowEl = h('div', { class: 'cs-row' }, curEl, btnsEl);
    barEl.append(hintEl, optsEl, rowEl);

    let st = null, B = null, flags = [], lastId = -1;
    let ui = { step: 'pick', x: 0, y: 0, r: 0, f: -1 };
    let legal = new Map();       // 칸 → 맞는 방향들
    let ghostA = null, opts = [];
    let pending = false, pendT = 0, busy = false, busyT = 0;
    let anim = null, pops = [], gone = [];
    let dirty = true, hoverK = -1;
    const cam = { x: 0.5, y: 0.5, s: 64 };
    let auto = true, tw = null;
    const SMIN = 22, SMAX = 150;
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    function busyFor(ms) { clearTimeout(busyT); setBusy(true); busyT = setTimeout(() => setBusy(false), ms); }

    const P = () => api.players;
    const nm = (i) => (P()[i] ? P()[i].name : (i + 1) + '번');
    const col = (i) => (P()[i] ? P()[i].color : '#e3ae45');
    const who = (i) => (api.canAct(i) && api.mySeats().length === 1 ? '나' : nm(i));
    const myTurn = () => !!st && !st.ov && !!st.c && api.canAct(st.t) && !pending;
    const flagsLeft = (seat) => FLAGS - flags.filter((q) => q[2] === seat).length;

    /* ---------- 카메라 ---------- */
    const toS = (wx, wy) => [(wx - cam.x) * cam.s + cv.w / 2, (wy - cam.y) * cam.s + cv.h / 2];
    const toW = (sx, sy) => [(sx - cv.w / 2) / cam.s + cam.x, (sy - cv.h / 2) / cam.s + cam.y];
    function bbox() {
      let x0 = 0, x1 = 0, y0 = 0, y1 = 0;
      if (B) for (let i = 0; i < B.n; i++) { x0 = Math.min(x0, B.x[i]); x1 = Math.max(x1, B.x[i]); y0 = Math.min(y0, B.y[i]); y1 = Math.max(y1, B.y[i]); }
      return { x0: x0 - 1, x1: x1 + 2, y0: y0 - 1, y1: y1 + 2 };   // 둘레 한 칸 여유 (놓을 자리)
    }
    function fitTarget() {
      const bb = bbox(), padR = 54, pad = 8;
      const s = U.clamp(Math.min((cv.w - pad - padR) / (bb.x1 - bb.x0), (cv.h - pad * 2) / (bb.y1 - bb.y0)), SMIN, 78);
      const cx = (bb.x0 + bb.x1) / 2 + (padR - pad) / 2 / s;
      return { x: cx, y: (bb.y0 + bb.y1) / 2, s };
    }
    function camTo(t, ms) {
      const d = (ms == null ? 360 : ms) / spd();
      if (d < 20) { cam.x = t.x; cam.y = t.y; cam.s = t.s; tw = null; dirty = true; return; }
      tw = { x0: cam.x, y0: cam.y, s0: cam.s, x1: t.x, y1: t.y, s1: t.s, t0: performance.now(), d };
      dirty = true;
    }
    function fitCam(anim2) { camTo(fitTarget(), anim2 ? 360 : 0); }
    function clampCam() {
      const bb = bbox();
      cam.s = U.clamp(cam.s, SMIN, SMAX);
      cam.x = U.clamp(cam.x, bb.x0, bb.x1); cam.y = U.clamp(cam.y, bb.y0, bb.y1);
    }
    function zoomBy(f, sx, sy) {
      if (sx == null) { sx = cv.w / 2; sy = cv.h / 2; }
      const [wx, wy] = toW(sx, sy);
      tw = null; auto = false;
      cam.s = U.clamp(cam.s * f, SMIN, SMAX);
      cam.x = wx - (sx - cv.w / 2) / cam.s; cam.y = wy - (sy - cv.h / 2) / cam.s;
      clampCam(); dirty = true;
    }
    function ensureVisible(x, y, minS) {
      const [sx, sy] = toS(x + 0.5, y + 0.5);
      const m = cam.s * 0.7;
      const ts = Math.max(cam.s, minS || 0);
      if (ts !== cam.s || sx < m || sx > cv.w - 54 - m || sy < m || sy > cv.h - m) {
        camTo({ x: ts !== cam.s ? x + 0.5 : cam.x + (sx < m || sx > cv.w - 54 - m ? (x + 0.5 - cam.x) : 0), y: ts !== cam.s ? y + 0.5 : cam.y + (sy < m || sy > cv.h - m ? (y + 0.5 - cam.y) : 0), s: ts }, 320);
      }
    }
    cv.onresize = () => { if (auto) fitCam(false); else clampCam(); dirty = true; };

    /* ---------- 상태 → 화면 ---------- */
    function computeLegal() {
      legal = new Map();
      if (!st || !st.c || !B) return;
      const ty = AX[st.c];
      for (const [x, y] of frontier(B)) {
        const rs = [];
        for (const r of UR[ty]) if (fits(B, ty, r, x, y)) rs.push(r);
        if (rs.length) legal.set(key(x, y), { x, y, rs });
      }
    }
    // 유령 타일을 올려 둔 판으로 다시 계산 (미리 보기 · 깃발 고르기)
    function ghostCalc() {
      ghostA = null; opts = [];
      if (ui.step === 'pick' || !st || !st.c) return;
      const ty = AX[st.c];
      bAdd(B, ui.x, ui.y, ty, ui.r);
      const A = analyze(B, flags, st.n, false), k = B.n - 1;
      const comp = [];
      for (const rt of touchedRoots(A, B, k)) {
        const g = A.G.get(rt);
        if (g.open === 0) comp.push({ g, rt, own: owners(g) });
      }
      opts = TY[ty].F.map((f, j) => {
        const rt = A.find(A.base[k] + j), g = A.G.get(rt);
        return { j, t: f.t, rt, g, taken: g.nf > 0, done: g.open === 0, edge: ROT[ty][ui.r].fe[j] };
      });
      ghostA = { A, k, comp, nodes: null };
      bPop(B);
    }
    function previewText() {
      if (!ghostA) return '';
      const parts = [];
      for (const c of ghostA.comp) {
        const nmF = FNAME[c.g.t];
        if (c.own.length) parts.push(nmF + ' 완성! ' + c.own.map(who).join('·') + ' <span class="ok">+' + fullPts(c.g) + '</span>');
        else parts.push(nmF + ' 완성 (깃발 꽂으면 <span class="ok">+' + fullPts(c.g) + '</span>)');
      }
      return parts.join(' · ');
    }

    function renderPlayers() {
      plEl.innerHTML = '';
      if (!st) return;
      plEl.classList.toggle('tight', st.n >= 4);
      for (let i = 0; i < st.n; i++) {
        const p = h('div', { class: 'cs-p' + (!st.ov && st.t === i ? ' cur' : ''), style: { '--c': col(i) } },
          h('div', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { class: 't', text: nm(i) })),
          h('div', { class: 'l' }, h('b', { text: String(st.sc[i]) }), h('span', { class: 'fg', html: FLAG_SVG(col(i)) + '<span>' + flagsLeft(i) + '</span>' })));
        plEl.append(p);
      }
    }
    function mkBtn(label, cls, fn, aria) { return h('button', { class: 'btn ' + (cls || ''), html: label, 'aria-label': aria || label.replace(/<[^>]+>/g, ''), onclick: fn }); }
    function renderBar() {
      btnsEl.innerHTML = ''; optsEl.innerHTML = '';
      if (!st) return;
      const cnt = st.d.length;
      dkEl.textContent = '남은 ' + cnt;
      curEl.style.display = '';
      if (st.ov) {
        curEl.classList.add('empty'); drawCur(-1, 0);
        hintEl.innerHTML = '게임 끝! 못 끝낸 성·길·탑도 점수에 더했어요.';
        btnsEl.append(mkBtn('⤢ 판 전체 보기', '', () => { auto = true; fitCam(true); }));
        return;
      }
      curEl.classList.remove('empty');
      const ty = st.c ? AX[st.c] : -1;
      if (!myTurn()) {
        drawCur(ty, 0);
        const cs = st.t;
        hintEl.innerHTML = pending ? '보내는 중…' : api.canAct(cs) ? '잠깐만요…' : '<span>' + esc(nm(cs)) + ' 차례 · ' + (P()[cs] && P()[cs].ai ? '어디에 놓을지 생각 중…' : '타일을 놓는 중…') + '</span>';
        btnsEl.append(h('div', { class: 'cs-tip', style: { flex: '1', alignSelf: 'center', textAlign: 'left', margin: 0 }, text: TY[ty] ? '이번 타일: ' + TY[ty].nm : '' }));
        return;
      }
      if (ui.step === 'pick') {
        drawCur(ty, ui.r);
        const nOk = [...legal.values()].filter((v) => v.rs.includes(ui.r)).length;
        hintEl.innerHTML = '<span><b>금색 칸</b>을 눌러 타일을 놓으세요 · 놓을 곳 ' + legal.size + '곳' + (nOk < legal.size ? ' (지금 방향 ' + nOk + '곳)' : '') + '</span>';
        btnsEl.append(mkBtn('<span class="k">⟳</span> 돌리기', 'cs-rot', rotate));
      } else if (ui.step === 'rot') {
        drawCur(ty, ui.r);
        const pv = previewText();
        const L0 = legal.get(key(ui.x, ui.y));
        hintEl.innerHTML = '<span>' + (pv || (L0 && L0.rs.length > 1 ? '⟳로 방향을 고르고 <b>「놓기」</b>' : UR[ty].length === 1 ? '돌려도 모양이 같아요 · <b>「놓기」</b>' : '이 자리는 이 방향만 맞아요 · <b>「놓기」</b>')) + '</span>';
        btnsEl.append(mkBtn('✕ 취소', '', back), mkBtn('<span class="k">⟳</span> 돌리기', 'cs-rot', rotate), mkBtn('✓ 놓기', 'primary cs-ok', confirmTile));
      } else {
        curEl.style.display = 'none';
        const left = flagsLeft(st.t);
        hintEl.innerHTML = '<span>깃발을 꽂을 곳을 고르세요 · 남은 깃발 <b>' + left + '</b>' + (ghostA && ghostA.comp.length ? '<br>' + previewText() : '') + '</span>';
        const c = col(st.t);
        const none = h('button', { class: 'cs-opt' + (ui.f < 0 ? ' on' : ''), style: { '--c': c }, onclick() { selectOpt(-1); } },
          h('span', { html: OPT_SVG.N }), h('span', { class: 'tx' }, h('span', { text: '깃발 없이' }), h('small', { text: '아껴 두기' })));
        optsEl.append(none);
        for (const o of opts) {
          const sameDir = opts.filter((q) => q.t === o.t).length > 1;
          const label = FNAME[o.t] + (sameDir && o.edge.length === 1 ? ' ' + ARROW[o.edge[0]] : '');
          let sub;
          if (o.taken) sub = '주인 있음';
          else if (o.done) sub = '바로 <b>+' + fullPts(o.g) + '</b>';
          else sub = '완성하면 +' + fullPts(o.g);
          const b = h('button', { class: 'cs-opt' + (ui.f === o.j ? ' on' : ''), style: { '--c': c }, onclick() { selectOpt(o.j); } },
            h('span', { html: OPT_SVG[o.t] }), h('span', { class: 'tx' }, h('span', { text: label }), h('small', { html: sub })));
          if (o.taken || left <= 0) b.disabled = true;
          optsEl.append(b);
        }
        btnsEl.append(mkBtn('← 뒤로', '', back), mkBtn(ui.f >= 0 ? '✓ 깃발 꽂고 끝' : '✓ 확정', 'primary cs-ok', submit));
      }
    }
    const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    function drawCur(ty, r) {
      const g = curCv.getContext('2d');
      g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, 128, 128);
      if (ty < 0) return;
      g.translate(64, 64); g.rotate(r * Math.PI / 2); g.drawImage(tileArt(ty), -64, -64, 128, 128);
    }
    function renderAll() { renderPlayers(); renderBar(); dirty = true; }

    /* ---------- 조작 ---------- */
    function rotate() {
      if (!myTurn()) return;
      if (ui.step === 'pick') { ui.r = (ui.r + 1) & 3; api.sfx('tick'); renderBar(); dirty = true; return; }
      if (ui.step !== 'rot') return;
      const L0 = legal.get(key(ui.x, ui.y)); if (!L0) return;
      if (L0.rs.length < 2) { api.toast(UR[AX[st.c]].length === 1 ? '돌려도 모양이 같아요' : '이 자리는 이 방향만 맞아요'); api.buzz(8); return; }
      const i = L0.rs.indexOf(ui.r);
      ui.r = L0.rs[(i + 1) % L0.rs.length];
      api.sfx('tick'); api.buzz(6);
      ghostCalc(); renderBar(); dirty = true;
    }
    function placeAt(x, y) {
      const L0 = legal.get(key(x, y)); if (!L0) return false;
      let r = ui.r;
      if (!L0.rs.includes(r)) { r = L0.rs[0]; for (let d = 1; d < 4; d++) if (L0.rs.includes((ui.r + d) & 3)) { r = (ui.r + d) & 3; break; } }
      // 같은 모양의 다른 방향(예: 곧은 길 0/2)은 UR 기준으로 맞춤
      ui = { step: 'rot', x, y, r, f: -1 };
      api.sfx('click'); api.buzz(10);
      ghostCalc(); renderBar();
      ensureVisible(x, y, cam.s < 50 ? 56 : 0);
      dirty = true;
      return true;
    }
    function back() {
      if (!myTurn()) return;
      if (ui.step === 'flag') { ui.step = 'rot'; ui.f = -1; }
      else if (ui.step === 'rot') ui = { step: 'pick', x: 0, y: 0, r: ui.r, f: -1 };
      api.sfx('click'); ghostCalc(); renderBar(); dirty = true;
    }
    function confirmTile() {
      if (!myTurn() || ui.step !== 'rot') return;
      const can = flagsLeft(st.t) > 0 && opts.some((o) => !o.taken);
      if (!can) { submit(); return; }
      ui.step = 'flag'; ui.f = -1;
      api.sfx('click'); renderBar(); dirty = true;
    }
    function selectOpt(j) {
      if (!myTurn() || ui.step !== 'flag') return;
      if (j >= 0) { const o = opts.find((q) => q.j === j); if (!o || o.taken || flagsLeft(st.t) <= 0) return; }
      ui.f = j; api.sfx('tick'); api.buzz(8); renderBar(); dirty = true;
    }
    function submit() {
      if (!myTurn() || ui.step === 'pick') return;
      pending = true; clearTimeout(pendT);
      pendT = setTimeout(() => { pending = false; renderAll(); }, 2500);
      api.act({ k: 'p', x: ui.x, y: ui.y, r: ui.r, f: ui.step === 'flag' ? ui.f : -1 });
      renderBar();
    }
    function tap(sx, sy) {
      if (!st) return;
      if (!myTurn()) return;
      const [wx, wy] = toW(sx, sy);
      const cx = Math.floor(wx), cy = Math.floor(wy);
      if (ui.step === 'flag') {
        if (cx !== ui.x || cy !== ui.y) return;
        // 고를 수 있는 조각 중 누른 곳에서 가장 가까운 것
        const ty = AX[st.c], R = ROT[ty][ui.r];
        let bj = -2, bd = 1e9;
        for (const o of opts) { if (o.taken) continue; const p = R.fp[o.j]; const d = Math.hypot(wx - (cx + p[0]), wy - (cy + p[1])); if (d < bd) { bd = d; bj = o.j; } }
        if (bj >= -1 && flagsLeft(st.t) > 0) selectOpt(bd < 0.45 ? bj : bj);
        return;
      }
      if (ui.step === 'rot' && cx === ui.x && cy === ui.y) { rotate(); return; }
      if (placeAt(cx, cy)) return;
      // 가까운 금색 칸으로 (작게 보일 때 손가락 오차)
      let best = null, bd = 1e9;
      for (const v of legal.values()) { const d = Math.hypot(wx - (v.x + 0.5), wy - (v.y + 0.5)); if (d < bd) { bd = d; best = v; } }
      if (best && bd * cam.s < Math.max(30, cam.s * 0.8)) { placeAt(best.x, best.y); return; }
      if (ui.step === 'pick') { api.toast('금색 테두리 칸에만 놓을 수 있어요'); api.buzz(8); }
    }

    /* ---------- 포인터: 끌어서 이동 · 두 손가락/휠 확대 · 톡 ---------- */
    const ptrs = new Map();
    let drag = null, pinch = null;
    function onDown(e) {
      if (e.target !== cv.cv) return;
      try { cv.cv.setPointerCapture(e.pointerId); } catch (x) {}
      const p = cv.local(e); ptrs.set(e.pointerId, p);
      if (ptrs.size === 1) drag = { id: e.pointerId, x0: p.x, y0: p.y, cx: cam.x, cy: cam.y, moved: false };
      else if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, s: cam.s, w: toW((a.x + b.x) / 2, (a.y + b.y) / 2) };
        if (drag) drag.moved = true;
      }
    }
    function onMove(e) {
      const p = cv.local(e);
      if (!ptrs.has(e.pointerId)) {   // 마우스 올려 보기
        if (e.pointerType === 'mouse' && myTurn() && ui.step !== 'flag') {
          const [wx, wy] = toW(p.x, p.y); const kk = key(Math.floor(wx), Math.floor(wy));
          const hk = legal.has(kk) ? kk : -1;
          if (hk !== hoverK) { hoverK = hk; bdEl.classList.toggle('hov', hk >= 0); dirty = true; }
        }
        return;
      }
      ptrs.set(e.pointerId, p);
      if (pinch && ptrs.size >= 2) {
        const [a, b] = [...ptrs.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y) || 1;
        cam.s = U.clamp(pinch.s * d / pinch.d, SMIN, SMAX);
        const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        cam.x = pinch.w[0] - (mx - cv.w / 2) / cam.s; cam.y = pinch.w[1] - (my - cv.h / 2) / cam.s;
        auto = false; tw = null; clampCam(); dirty = true;
        return;
      }
      if (drag && e.pointerId === drag.id) {
        const dx = p.x - drag.x0, dy = p.y - drag.y0;
        if (!drag.moved && Math.hypot(dx, dy) > 9) drag.moved = true;
        if (drag.moved) { cam.x = drag.cx - dx / cam.s; cam.y = drag.cy - dy / cam.s; auto = false; tw = null; clampCam(); dirty = true; }
      }
    }
    function onUp(e, cancel) {
      const p = ptrs.get(e.pointerId);
      if (!p) return;
      ptrs.delete(e.pointerId);
      if (ptrs.size < 2) pinch = null;
      if (drag && e.pointerId === drag.id) {
        const d = drag; drag = null;
        if (!cancel && !d.moved && ptrs.size === 0) tap(p.x, p.y);
      }
      if (ptrs.size === 1 && !drag) { const [id, q] = [...ptrs.entries()][0]; drag = { id, x0: q.x, y0: q.y, cx: cam.x, cy: cam.y, moved: true }; }
    }
    const onUpE = (e) => onUp(e, false), onCancel = (e) => onUp(e, true);
    function onWheel(e) { e.preventDefault(); const p = cv.local(e); zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15, p.x, p.y); }
    function onLeave() { if (hoverK >= 0) { hoverK = -1; bdEl.classList.remove('hov'); dirty = true; } }
    bdEl.addEventListener('pointerdown', onDown);
    bdEl.addEventListener('pointermove', onMove);
    bdEl.addEventListener('pointerup', onUpE);
    bdEl.addEventListener('pointercancel', onCancel);
    bdEl.addEventListener('pointerleave', onLeave);
    bdEl.addEventListener('wheel', onWheel, { passive: false });
    bdEl._cs = { tapCell(x, y) { const [sx, sy] = toS(x + 0.5, y + 0.5); tap(sx, sy); }, legal: () => [...legal.values()], confirm: () => confirmTile(), opt: (j) => selectOpt(j), opts: () => opts.map((o) => ({ j: o.j, t: o.t, taken: o.taken })), submit: () => submit(), ui: () => ui }; // 시험용
    // PC 키보드·게임패드 (조작 설정에서 바꿀 수 있어요)
    const offInput = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'rot') rotate();
      else if (id === 'ok') { if (ui.step === 'rot') confirmTile(); else if (ui.step === 'flag') submit(); }
      else if (id === 'back') back();
      else if (id === 'zin') zoomBy(1.25);
      else if (id === 'zout') zoomBy(1 / 1.25);
    }) : null;

    /* ---------- 그리기 ---------- */
    function featWorld(k, j, bb) {   // 타일 k 의 조각 j 깃발 자리 (판 좌표)
      const b = bb || B;
      const p = ROT[b.t[k]][b.r[k]].fp[j];
      return [b.x[k] + p[0], b.y[k] + p[1]];
    }
    function drawTileAt(ty, r, x, y, sc2, alpha) {
      const [sx, sy] = toS(x + 0.5, y + 0.5), S = cam.s * (sc2 || 1);
      ctx.save(); ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.translate(sx, sy); ctx.rotate(r * Math.PI / 2);
      ctx.drawImage(tileArt(ty), -S / 2, -S / 2, S, S);
      ctx.restore();
    }
    function drawFlag(wx, wy, c, alpha, lift) {
      const [sx0, sy0] = toS(wx, wy);
      const sz = Math.max(13, cam.s * 0.34);
      const x = sx0 - sz * 0.12, y = sy0 + sz * 0.42 - (lift || 0);
      ctx.save(); ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(x + 1.5, y + 1, sz * 0.24, sz * 0.09, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#3a2a1a'; ctx.beginPath(); ctx.ellipse(x, y, sz * 0.16, sz * 0.07, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#2a1d10'; ctx.lineWidth = Math.max(1.6, sz * 0.08); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - sz); ctx.stroke();
      const t = y - sz;
      ctx.beginPath(); ctx.moveTo(x, t); ctx.lineTo(x + sz * 0.78, t + sz * 0.1); ctx.lineTo(x + sz * 0.52, t + sz * 0.24); ctx.lineTo(x + sz * 0.78, t + sz * 0.38); ctx.lineTo(x, t + sz * 0.46); ctx.closePath();
      ctx.fillStyle = c; ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.55)'; ctx.lineWidth = Math.max(1, sz * 0.04); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.28)'; ctx.beginPath(); ctx.moveTo(x, t); ctx.lineTo(x + sz * 0.78, t + sz * 0.1); ctx.lineTo(x + sz * 0.4, t + sz * 0.13); ctx.lineTo(x, t + sz * 0.12); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#f0c35a'; ctx.beginPath(); ctx.arc(x, t, Math.max(1.6, sz * 0.07), 0, 7); ctx.fill();
      ctx.restore();
    }
    // 덩어리(rt)에 속한 모든 조각을 칠하기
    function highlightGroup(A, bb, rt, c, alpha) {
      for (let i = 0; i < bb.n; i++) {
        const T = TY[bb.t[i]];
        for (let j = 0; j < T.F.length; j++) {
          if (A.find(A.base[i] + j) !== rt) continue;
          const [sx, sy] = toS(bb.x[i] + 0.5, bb.y[i] + 0.5);
          ctx.save(); ctx.translate(sx, sy); ctx.rotate(bb.r[i] * Math.PI / 2); ctx.scale(cam.s, cam.s); ctx.translate(-0.5, -0.5);
          ctx.globalAlpha = alpha; ctx.fillStyle = c; ctx.strokeStyle = c;
          featShape(ctx, T, T.F[j], 0.22);
          ctx.restore();
        }
      }
    }
    function roundRect(x, y, w, hh, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + hh, r); ctx.arcTo(x + w, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    let bgGrad = null, bgKey = '';
    function draw(now) {
      cv.clear();
      const W0 = cv.w, H0 = cv.h;
      if (bgKey !== W0 + 'x' + H0) {
        bgKey = W0 + 'x' + H0;
        bgGrad = ctx.createRadialGradient(W0 / 2, H0 / 2, 10, W0 / 2, H0 / 2, Math.max(W0, H0) * 0.75);
        bgGrad.addColorStop(0, '#2a3a2c'); bgGrad.addColorStop(1, '#141a17');
      }
      ctx.fillStyle = bgGrad; ctx.fillRect(0, 0, W0, H0);
      // 탁자 무늬 (아주 옅은 칸)
      const S = cam.s;
      if (S >= 30) {
        ctx.strokeStyle = 'rgba(255,255,255,.035)'; ctx.lineWidth = 1;
        const [wx0, wy0] = toW(0, 0), [wx1, wy1] = toW(W0, H0);
        ctx.beginPath();
        for (let x = Math.floor(wx0); x <= wx1; x++) { const sx = toS(x, 0)[0]; ctx.moveTo(sx, 0); ctx.lineTo(sx, H0); }
        for (let y = Math.floor(wy0); y <= wy1; y++) { const sy = toS(0, y)[1]; ctx.moveTo(0, sy); ctx.lineTo(W0, sy); }
        ctx.stroke();
      }
      if (!st || !B) return;
      const t = now || performance.now();
      const vis = (x, y) => { const [sx, sy] = toS(x + 0.5, y + 0.5); return sx > -S && sx < W0 + S && sy > -S && sy < H0 + S; };
      // 그림자
      ctx.fillStyle = 'rgba(0,0,0,.42)';
      for (let i = 0; i < B.n; i++) {
        if (anim && i === anim.k) continue;
        if (!vis(B.x[i], B.y[i])) continue;
        const [sx, sy] = toS(B.x[i], B.y[i]);
        ctx.fillRect(sx + S * 0.05, sy + S * 0.07, S, S);
      }
      // 타일
      for (let i = 0; i < B.n; i++) {
        if (anim && i === anim.k) continue;
        if (!vis(B.x[i], B.y[i])) continue;
        drawTileAt(B.t[i], B.r[i], B.x[i], B.y[i]);
      }
      // 이음새 (얇은 선)
      if (S >= 28) {
        ctx.strokeStyle = 'rgba(20,30,15,.35)'; ctx.lineWidth = 1;
        for (let i = 0; i < B.n; i++) { if (anim && i === anim.k) continue; const [sx, sy] = toS(B.x[i], B.y[i]); ctx.strokeRect(sx + 0.5, sy + 0.5, S - 1, S - 1); }
      }
      // 방금 놓인 타일 (떨어지는 움직임)
      if (anim) {
        const p = U.clamp((t - anim.t0) / anim.d, 0, 1), e = 1 - Math.pow(1 - p, 3);
        const i = anim.k;
        const [sx, sy] = toS(B.x[i], B.y[i]);
        ctx.fillStyle = 'rgba(0,0,0,' + (0.42 * e) + ')';
        ctx.fillRect(sx + S * (0.05 + 0.2 * (1 - e)), sy + S * (0.07 + 0.25 * (1 - e)), S, S);
        drawTileAt(B.t[i], B.r[i], B.x[i], B.y[i], 1 + 0.35 * (1 - e), 0.3 + 0.7 * e);
      }
      // 마지막에 놓인 타일 테두리
      if (st.last && st.last.k < B.n && !st.ov) {
        const i = st.last.k, [sx, sy] = toS(B.x[i], B.y[i]);
        ctx.strokeStyle = col(st.last.s); ctx.lineWidth = Math.max(2, S * 0.045); ctx.globalAlpha = 0.9;
        roundRect(sx + 1, sy + 1, S - 2, S - 2, Math.min(6, S * 0.08)); ctx.stroke(); ctx.globalAlpha = 1;
      }
      const mine = myTurn();
      // 놓을 수 있는 자리
      if (mine && st.c) {
        const pulse = 0.55 + 0.45 * Math.sin(t / 260);
        for (const v of legal.values()) {
          if (ui.step !== 'pick' && v.x === ui.x && v.y === ui.y) continue;
          const [sx, sy] = toS(v.x, v.y);
          const ok = v.rs.includes(ui.r);
          const hv = key(v.x, v.y) === hoverK;
          ctx.fillStyle = hv ? 'rgba(227,174,69,.32)' : ok ? 'rgba(227,174,69,' + (0.1 + 0.1 * pulse) + ')' : 'rgba(227,174,69,.06)';
          roundRect(sx + 3, sy + 3, S - 6, S - 6, Math.min(8, S * 0.12)); ctx.fill();
          ctx.strokeStyle = ok ? 'rgba(240,195,90,' + (0.55 + 0.4 * pulse) + ')' : 'rgba(240,195,90,.45)';
          ctx.lineWidth = Math.max(1.5, S * (ok ? 0.04 : 0.025));
          ctx.setLineDash(ok ? [] : [S * 0.12, S * 0.08]); ctx.stroke(); ctx.setLineDash([]);
        }
      }
      // 꽂힌 깃발
      for (const [k, j, s2] of flags) if (k < B.n && !(anim && k === anim.k && t - anim.t0 < anim.d)) { const [wx, wy] = featWorld(k, j); drawFlag(wx, wy, col(s2)); }
      // 돌아가는 깃발 (완성되어 회수)
      gone = gone.filter((g) => t - g.t0 < g.d);
      for (const g of gone) { const p = U.clamp((t - g.t0) / g.d, 0, 1); if (p <= 0) continue; drawFlag(g.x, g.y, g.c, 1 - p, p * S * 0.6); }
      // 유령 타일 (내가 고르는 중)
      if (mine && ui.step !== 'pick' && st.c) {
        const ty = AX[st.c];
        const [sx, sy] = toS(ui.x, ui.y);
        ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fillRect(sx + S * 0.08, sy + S * 0.11, S, S);
        drawTileAt(ty, ui.r, ui.x, ui.y, 1, 1);
        const pulse = 0.5 + 0.5 * Math.sin(t / 220);
        ctx.strokeStyle = 'rgba(240,195,90,' + (0.7 + 0.3 * pulse) + ')'; ctx.lineWidth = Math.max(2.5, S * 0.06);
        roundRect(sx - 1, sy - 1, S + 2, S + 2, Math.min(6, S * 0.08)); ctx.stroke();
        if (ghostA) {
          bAdd(B, ui.x, ui.y, ty, ui.r);
          // 완성되는 덩어리는 초록으로 살짝
          for (const c of ghostA.comp) highlightGroup(ghostA.A, B, c.rt, '#7fe09a', 0.22 + 0.12 * pulse);
          if (ui.step === 'flag') {
            const c = col(st.t);
            for (const o of opts) {
              if (o.taken) continue;
              const sel = ui.f === o.j;
              highlightGroup(ghostA.A, B, o.rt, c, sel ? 0.42 + 0.15 * pulse : 0.16);
            }
            const R = ROT[ty][ui.r];
            for (const o of opts) {
              if (o.taken) continue;
              const p = R.fp[o.j], [px, py] = toS(ui.x + p[0], ui.y + p[1]);
              if (ui.f === o.j) drawFlag(ui.x + p[0], ui.y + p[1], c, 0.95);
              else { ctx.fillStyle = 'rgba(23,19,31,.7)'; ctx.beginPath(); ctx.arc(px, py, Math.max(7, S * 0.09), 0, 7); ctx.fill(); ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.stroke(); }
            }
          }
          bPop(B);
        }
      }
      // 점수 튀어 오르기
      pops = pops.filter((q) => t - q.t0 < q.d);
      for (const q of pops) {
        const p = (t - q.t0) / q.d; if (p < 0) continue;
        const [sx, sy] = toS(q.x, q.y);
        const y = sy - S * 0.2 - p * 34;
        ctx.globalAlpha = p < 0.8 ? 1 : (1 - p) / 0.2;
        ctx.font = '700 ' + Math.round(U.clamp(S * 0.3, 14, 22)) + 'px "IBM Plex Mono", monospace';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const w = ctx.measureText(q.txt).width + 12, hh = U.clamp(S * 0.3, 14, 22) + 8;
        ctx.fillStyle = q.c; roundRect(sx - w / 2, y - hh / 2, w, hh, hh / 2); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 3; ctx.strokeText(q.txt, sx, y + 1); ctx.fillText(q.txt, sx, y + 1);
        ctx.globalAlpha = 1;
      }
    }
    const stopLoop = U.loop((dt, now) => {
      if (tw) {
        const p = U.clamp((now - tw.t0) / tw.d, 0, 1), e = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
        cam.x = U.lerp(tw.x0, tw.x1, e); cam.y = U.lerp(tw.y0, tw.y1, e); cam.s = U.lerp(tw.s0, tw.s1, e);
        if (p >= 1) tw = null;
        dirty = true;
      }
      if (anim && now - anim.t0 > anim.d + 50) anim = null;
      const live = anim || pops.length || gone.length || (myTurn() && st && st.c);
      if (dirty || live) { dirty = false; draw(now); }
    });

    /* ---------- 상태 받기 ---------- */
    function update(state, prev) {
      const prevB = B, prevFlags = flags;
      st = state; B = board(st.b); flags = flagList(st.fl);
      const L1 = st.last;
      const isNew = L1 && L1.id !== lastId;
      if (isNew || prev == null || prev === state) {
        if (isNew || prev == null) { pending = false; clearTimeout(pendT); ui = { step: 'pick', x: 0, y: 0, r: 0, f: -1 }; }
      }
      computeLegal();
      ghostCalc();
      if (isNew && prev && lastId >= 0) {
        const now = performance.now(), sp = spd();
        anim = { k: L1.k, t0: now, d: 300 / sp };
        api.sfx('thud'); if (api.canAct(L1.s)) api.buzz(12);
        // 회수된 깃발
        if (prevB) {
          const still = new Set(flags.map((q) => q.join(',')));
          for (const q of prevFlags) if (!still.has(q.join(',')) && q[0] < prevB.n) { const [x, y] = featWorld(q[0], q[1], prevB); gone.push({ x, y, c: col(q[2]), t0: now + 260 / sp, d: 700 / sp }); }
        }
        let delay = 300 / sp, best = null;
        for (const [w, pts, k, j] of L1.ev || []) {
          const [x, y] = featWorld(k, j);
          pops.push({ x, y, txt: '+' + pts, c: col(w), t0: now + delay, d: 1100 / sp });
          if (!L1.fin) delay += 120 / sp;
          if (!best || pts > best[1]) best = [w, pts];
        }
        if (L1.ev && L1.ev.length) {
          setTimeout(() => api.sfx(L1.fin ? 'win' : 'chip'), 280 / sp);
          if (!L1.fin && best) {
            const g = L1.ev.find((q) => q[0] === best[0] && q[1] === best[1]);
            api.toast(['성', '길', '탑'][g[4]] + ' 완성! ' + who(best[0]) + ' +' + best[1]);
          }
        }
        if (L1.fin) setTimeout(() => api.toast('타일 끝! 못 끝낸 것도 칸마다 점수를 더해요'), 200 / sp);
        if (L1.ds) setTimeout(() => api.toast('맞는 자리가 없는 타일 ' + L1.ds + '장을 버리고 새로 뽑았어요'), 500 / sp);
        busyFor((L1.fin ? 1700 : (L1.ev && L1.ev.length ? 800 : 380)) / sp);
        if (auto) fitCam(true); else ensureVisible(B.x[L1.k], B.y[L1.k]);
      } else if (prev == null || lastId < 0) {
        if (auto) fitCam(false);
      }
      if (L1) lastId = L1.id; else if (prev == null) lastId = 0;
      renderAll();
    }

    return {
      update,
      destroy() {
        stopLoop(); clearTimeout(busyT); clearTimeout(pendT);
        if (busy) api.setBusy(false);
        if (offInput) offInput();
        bdEl.removeEventListener('pointerdown', onDown); bdEl.removeEventListener('pointermove', onMove);
        bdEl.removeEventListener('pointerup', onUpE); bdEl.removeEventListener('pointercancel', onCancel);
        bdEl.removeEventListener('pointerleave', onLeave); bdEl.removeEventListener('wheel', onWheel);
        cv.destroy(); wrap.remove(); style.remove();
      },
    };
  }

  const ICON = '<path d="M6 50V22h7v6h6v-6h7v6h6v-6h7v6h6v-6h5v28z" fill="currentColor" opacity=".9"/>' +
    '<rect x="24" y="36" width="10" height="14" rx="5" fill="currentColor" opacity=".35"/>' +
    '<path d="M29 22V4" stroke="currentColor" stroke-width="2.5"/><path d="M30 5h14l-5 4 5 4H30z" fill="currentColor"/>';

  L.register({
    id: 'castle', name: '성벽 타일 잇기', tag: '타일 놓기 · 땅 만들기', cat: '보드', hidden: false,
    icon: ICON, tint: '#5a3a24',
    blurb: '타일을 한 장씩 이어 붙여 성·길·탑을 만들고, 깃발을 꽂아 완성하면 점수를 받아요.',
    minPlayers: 1, maxPlayers: 5, defaultPlayers: 2, aiDelay: 800, aiDelayFor,
    options: [{ id: 'len', label: '타일 수', choices: [{ v: 'm', label: '보통 71장' }, { v: 's', label: '짧게 40장' }], def: 'm' }],
    controls: [
      { id: 'rot', label: '타일 돌리기', keys: ['KeyR', 'Space'], pad: ['x'] },
      { id: 'ok', label: '놓기 · 확정', keys: ['Enter'], pad: ['a'] },
      { id: 'back', label: '뒤로 · 취소', keys: ['Backspace'], pad: ['b'] },
      { id: 'zin', label: '확대', keys: ['Equal', 'NumpadAdd'], pad: ['rb'] },
      { id: 'zout', label: '축소', keys: ['Minus', 'NumpadSubtract'], pad: ['lb'] },
    ],
    quick: [
      '타일을 한 장씩 이어 붙여 성·길·탑을 만들어요. 맞닿는 변은 그림이 같아야 해요.',
      '내 차례: 타일 놓기 → (원하면) 방금 놓은 타일의 성·길·탑에 깃발 꽂기.',
      '깃발 꽂은 것이 완성되면 바로 점수! 타일이 다 떨어지면 점수가 가장 높은 사람이 이겨요.',
    ],
    rules: [
      { h: '목표', p: [
        '가운데 시작 타일부터 타일을 이어 붙여 성·길·탑을 만들어요.',
        '내 깃발을 꽂아 둔 성·길·탑이 완성되면 점수를 받아요. 타일이 다 떨어졌을 때 점수가 가장 높은 사람이 이겨요.'] },
      { h: '차례에 할 일', p: [
        '① 이번 타일(아래 그림)을 판의 금색 칸 중 한 곳에 놓아요. 돌려서 방향을 고를 수 있어요.',
        '맞닿는 변은 그림이 같아야 해요: 성은 성끼리, 길은 길끼리, 들판은 들판끼리.',
        '② 원하면 방금 놓은 타일의 성·길·탑 중 하나에 깃발을 꽂아요. 단, 이미 이어진 곳에 누구 깃발이 있으면 못 꽂아요.',
        '③ 완성된 것이 있으면 바로 점수를 계산하고, 거기 꽂힌 깃발은 주인에게 돌아가요.',
        '깃발은 한 사람에 ' + FLAGS + '개. 아껴 쓰세요! 어디에도 맞지 않는 타일이 나오면 버리고 새로 뽑아요.'] },
      { h: '완성이란?', p: [
        '성: 성벽으로 빙 둘러싸여 열린 곳이 없을 때.',
        '길: 양쪽 끝이 모두 막혔을 때(마을·우물·시장 광장·성문·탑에서 끝나거나, 길이 동그랗게 이어졌을 때).',
        '탑: 탑 타일 둘레 8칸(가로·세로·대각선)이 모두 채워졌을 때.'] },
      { h: '점수', p: [
        '완성된 성: 타일 1장마다 2점 + 보물(금화) 하나마다 2점.',
        '완성된 길: 타일 1장마다 1점. 시장(줄무늬 천막)이 있는 길은 2배!',
        '완성된 탑: 9점.',
        '게임 끝: 못 끝낸 성은 타일마다 1점(+보물 1점), 못 끝낸 길은 타일마다 1점, 못 끝낸 탑은 채워진 칸(탑 포함)마다 1점.',
        '들판은 점수가 없어요.'] },
      { h: '깃발 다툼', p: [
        '따로 깃발이 꽂힌 두 성(또는 길)이 나중에 이어지면 하나가 돼요.',
        '그러면 깃발이 더 많은 사람이 점수를 받아요. 깃발 수가 같으면 모두 똑같이 다 받아요.'] },
      { h: '예시', p: [
        '내가 성 끝 타일을 놓고 성에 깃발을 꽂았어요(성 1칸).',
        '다음 차례에 반대쪽에 성 끝 타일을 붙여 성을 닫으면 → 성 2칸 완성 = 4점! 깃발은 바로 돌아와요.',
        '보물이 있는 성이었다면 +2점 더. 시장이 있는 4칸짜리 길을 완성하면 8점.'] },
      { h: '혼자 하기', p: [
        '혼자 하면 타일을 다 쓸 때까지 점수를 모아 별을 받아요.',
        '별 기준 — 보통 71장: ' + STARS.m.join(' / ') + '점, 짧게 40장: ' + STARS.s.join(' / ') + '점.'] },
      { h: '조작', p: [
        '금색 칸을 누르면 타일이 올라가요. ⟳ 돌리기(또는 타일을 한 번 더 톡)로 방향을 바꾸고 「놓기」.',
        '그다음 깃발을 꽂을 곳(성·길·탑)을 고르고 「확정」. 확정 전엔 「뒤로」 「취소」로 되돌릴 수 있어요.',
        '판은 끌어서 옮기고, 두 손가락 · 마우스 휠 · ＋/− 버튼으로 확대해요. ⤢는 판 전체 보기.',
        '놓으면 완성되는 곳은 초록으로 빛나고, 받을 점수가 아래에 미리 나와요.'] },
      { h: 'AI 난이도', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움은 당장 점수만 보고 깃발을 아무 데나 꽂아요. 보통은 완성할 수 있을지 따져요. 어려움은 남은 타일로 끝낼 수 있는지 세어 보고, 깃발을 아껴 쓰며, 남의 성을 막기도 해요.'] },
    ],
    tutorial: [
      { sel: '.cs-board', text: '가운데 시작 타일에서 출발해요. 타일을 한 장씩 이어 붙여 성·길·탑을 만들어요. 판은 끌어서 옮기고, 두 손가락이나 ＋/−로 확대해요.' },
      { sel: '.cs-cur', text: '이번에 놓을 타일이에요. 누르면 돌아가요. 아래 숫자는 남은 타일 수예요.' },
      { sel: '.cs-board', text: '금색 칸이 놓을 수 있는 자리예요. 맞닿는 변은 그림이 같아야 해요: 성은 성끼리, 길은 길끼리, 들판은 들판끼리.' },
      { sel: '.cs-bar', text: '자리를 누르면 타일이 올라가요. ⟳로 방향을 고르고 「놓기」 → 깃발 꽂을 곳(성·길·탑)을 고르고 「확정」. 확정 전엔 언제든 되돌릴 수 있어요.' },
      { sel: '.cs-pl', text: '깃발은 ' + FLAGS + '개(위쪽 숫자). 깃발 꽂은 성·길·탑이 완성되면 바로 점수를 받고 깃발이 돌아와요. 성은 칸마다 2점, 길은 1점, 탑은 둘레 8칸이 다 차면 9점!' },
      { text: '타일이 다 떨어지면 끝! 못 끝낸 것도 칸마다 1점씩 받아요. 점수가 가장 높은 사람이 이겨요.' },
    ],
    init, actor, apply, ai, result, mount,
    _t: { AP, TY, ROT, UR, board, analyze, frontier, movesFor, fits, flagList, fullPts, endPts, owners, DECK_ALL, STARS, AL, AX, key },
  });
})();
