/* 몬스터 키우기 대회 — 알에서 깬 아기 몬스터를 정해진 날 수 동안 먹이·훈련·휴식·탐험으로 키워요.
   먹이(불·물·풀·번개)가 첫 진화의 갈래를, 능력치가 다음 진화의 모습(튼튼형·날쌘형·멋쟁이형)을 정해요.
   중간 대회 2번(능력 하나 겨루기)과 마지막 결승(모두와 자동 대결 + 묘기 심사)에서 점수를 모아요.
   모든 몬스터 이름·모습·규칙은 이 게임 자체 디자인이에요.
   상태: n 사람 수, E 출전 수(혼자면 도전자 3 추가), D 날 수, d 지난 날, ph 'c'고르기/'x'끝, nm 이름, st 능력[힘,속도,지능,체력,매력],
   af 갈래 점수, en 기력, mo 기분, e 갈래(-1 아기), v 모습(-1), g 단계, lf 어제 먹이, ch 오늘 고른 카드, pt 점수(출전마다),
   rv 도전자 [갈래, 모습, 등급], mt 중간 대회 종목 2개, hot 오늘 UP 카드, sd 씨앗, fb 결승 대결 승자, fj 묘기 점수, last 최근 일. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- 내용 ---------- */
  const SN = ['힘', '속도', '지능', '체력', '매력'];
  const SC = ['#ff7a59', '#5ec8ff', '#b48cff', '#6fdc8c', '#ff8fc8'];
  const EL = [
    { n: '불', i: '🔥', c: '#ff6b3d' },
    { n: '물', i: '💧', c: '#4aa8ff' },
    { n: '풀', i: '🌿', c: '#5cc25a' },
    { n: '번개', i: '⚡', c: '#f5c933' },
  ];
  const BEAT = [2, 0, 3, 1];                 // 불>풀, 물>불, 풀>번개, 번개>물
  const LOSE = [1, 3, 0, 2];
  const VN = ['튼튼형', '날쌘형', '멋쟁이형'];
  const BABY = '동글 아기 몬스터';
  const FORMS = [
    ['불꼬리 도마뱀', ['용암등 도마뱀', '불씨날개 도마뱀', '불꽃갈기 도마뱀'], ['화산뿔 용', '불새날개 용', '태양왕관 용']],
    ['물방울 물범', ['빙산엄니 물범', '물살지느러미 물범', '진주목걸이 물범'], ['해일엄니 바다사자', '물보라날개 물범', '달빛진주 물범']],
    ['이끼 거북', ['바위이끼 거북', '잎사귀발 거북', '꽃등 거북'], ['고목숲 거북', '나뭇잎날개 거북', '꽃동산 거북']],
    ['찌릿귀 여우', ['천둥발톱 여우', '번개꼬리 여우', '별빛털 여우'], ['먹구름갈기 여우', '번개날개 여우', '은하꼬리 여우']],
  ];
  const MOVE = ['불꽃 박치기', '물대포', '덩굴 채찍', '찌릿 번개'];
  const TRICK = [['불 고리 뛰어넘기', '불씨 공중제비', '불꽃 춤'], ['물기둥 물구나무', '물보라 회오리', '진주 저글링'], ['통나무 들기', '나뭇잎 활공', '꽃잎 뿌리기'], ['번개 공 튀기기', '번쩍 순간이동', '별빛 반짝 쇼']];
  const CARDS = [
    { k: 'f', e: 0, s: 0, n: '불꽃 고추', i: '🌶️' },
    { k: 'f', e: 1, s: 3, n: '시원 조개', i: '🐚' },
    { k: 'f', e: 2, s: 4, n: '이슬 잎', i: '🍃' },
    { k: 'f', e: 3, s: 1, n: '찌릿 사탕', i: '🍬' },
    { k: 't', s: 0, b: 3, n: '바위 밀기', i: '💪' },
    { k: 't', s: 1, b: 3, n: '달리기', i: '👟' },
    { k: 't', s: 2, b: 4, n: '수수께끼', i: '🧩' },
    { k: 't', s: 3, b: 0, n: '폭포 맞기', i: '🌊' },
    { k: 't', s: 4, b: 1, n: '춤 연습', i: '🎶' },
    { k: 'r', n: '휴식', i: '😴' },
    { k: 'x', n: '탐험', i: '🧭' },
  ];
  const TR_EN = 3, EX_EN = 2;
  /* 탐험 사건: 0~3 = 갈래 열매(갈래 +3, 기력 +1), 4~ 아래 */
  const EX = [
    { t: '들판을 신나게 뛰었어요', w: 3, d: [0, 3, 0, 0, 0], m: 1 },
    { t: '오래된 그림책을 찾았어요', w: 3, d: [0, 0, 4, 0, 0] },
    { t: '꽃밭에서 뒹굴었어요', w: 3, d: [0, 0, 0, 0, 3], m: 1 },
    { t: '큰 돌을 굴리며 놀았어요', w: 3, d: [3, 0, 0, 0, 0] },
    { t: '친구 몬스터와 놀았어요', w: 2, d: [0, 0, 0, 2, 0], m: 2 },
    { t: '진화의 돌을 찾았어요!', w: 1, d: [2, 2, 2, 2, 2] },
    { t: '소나기를 쫄딱 맞았어요', w: 2, m: -2 },
    { t: '길을 잃고 헤맸어요', w: 2, en: -2 },
  ];
  const exText = (c) => (c < 4 ? '반짝이는 ' + EL[c].n + ' 열매를 주웠어요' : EX[c - 4].t);
  /* 혼자 할 때 도전자 */
  const RVN = ['들판 도전자', '호숫가 도전자', '산꼭대기 도전자'];
  const RVC = ['#b39c7a', '#7fb0c8', '#d08455'];
  const RRATE = [4.3, 5.3, 6.3];
  const RW = [[0.3, 0.15, 0.08, 0.3, 0.17], [0.16, 0.3, 0.26, 0.14, 0.14], [0.15, 0.13, 0.17, 0.17, 0.38]];

  const evoDays = (D) => [Math.round(D * 0.2), Math.round(D * 0.47), Math.round(D * 0.73)];
  const conDays = (D) => [Math.round(D * 0.4), Math.round(D * 0.7)];
  const stageAt = (D, d) => evoDays(D).filter((x) => x <= d).length;
  const clampI = (x, a, b) => (x < a ? a : x > b ? b : x);
  const rnd = (n) => Math.floor(Math.random() * n);

  function formName(e, v, g) {
    if (g <= 0 || e < 0) return BABY;
    if (g === 1) return FORMS[e][0];
    return FORMS[e][g - 1][v < 0 ? 0 : v];
  }
  function styleOf(st) {
    const a = st[0] + st[3], b = st[1] + st[2], c = st[4] * 2;
    return a >= b && a >= c ? 0 : b >= c ? 1 : 2;
  }
  function rivalStats(r, d) {
    const w = RW[r[1]], rate = RRATE[r[2]];
    return w.map((x) => 8 + Math.round(rate * d * x));
  }
  /* 출전 몬스터 k의 모습·능력 (사람 자리 또는 도전자) */
  function mon(s, k) {
    if (k < s.n) return { st: s.st[k], e: s.e[k], v: s.v[k], g: s.g[k], mo: s.mo[k], en: s.en[k] };
    const r = s.rv[k - s.n], g = stageAt(s.D, s.d);
    return { st: rivalStats(r, s.d), e: g >= 1 ? r[0] : -1, v: g >= 2 ? r[1] : -1, g, mo: 6, en: 6, rv: r };
  }
  const nameOf = (s, k) => (k < s.n ? s.nm[k] : RVN[s.rv[k - s.n][2]]);
  const sum = (a) => a.reduce((x, y) => x + y, 0);

  /* ---------- 대결 시뮬 (결정적: apply와 화면이 같이 씀) ---------- */
  function rng(seed) {
    let a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function tmul(a, b) { if (a < 0 || b < 0) return 1; if (BEAT[a] === b) return 1.4; if (BEAT[b] === a) return 0.75; return 1; }
  function bst(m) {
    const P = m.st[0], S = m.st[1], I = m.st[2], H = m.st[3];
    const mm = m.mo >= 7 ? 1.1 : m.mo <= 2 ? 0.9 : 1;
    return { hp: Math.round(30 + H * 1.5), atk: (5 + P * 0.4) * mm, rate: 10 + S * 0.3, dg: Math.min(0.3, 0.02 + (S + I) * 0.0025), cr: Math.min(0.3, 0.04 + I * 0.005), e: m.e };
  }
  function battle(A, B, seed) {
    const r = rng(seed), X = [bst(A), bst(B)], hp = [X[0].hp, X[1].hp], gz = [r() * 60, r() * 60], ev = [];
    let w = -1;
    for (let t = 0; t < 600 && w < 0 && ev.length < 30; t++) {
      gz[0] += X[0].rate; gz[1] += X[1].rate;
      while (w < 0 && ev.length < 30) {
        let k = -1;
        if (gz[0] >= 100 && gz[0] >= gz[1]) k = 0; else if (gz[1] >= 100) k = 1; else if (gz[0] >= 100) k = 0;
        if (k < 0) break;
        gz[k] -= 100;
        const o = 1 - k;
        if (r() < X[o].dg) { ev.push([k, 0, 0, 1]); continue; }
        const cr = r() < X[k].cr, m = tmul(X[k].e, X[o].e);
        const dmg = Math.max(1, Math.round(X[k].atk * m * (0.85 + r() * 0.3) * (cr ? 1.5 : 1)));
        hp[o] -= dmg; ev.push([k, dmg, cr ? 1 : 0, 0]);
        if (hp[o] <= 0) w = k;
      }
    }
    if (w < 0) w = hp[0] / X[0].hp >= hp[1] / X[1].hp ? 0 : 1;
    return { ev, w, hp: [X[0].hp, X[1].hp] };
  }
  const bSeed = (s, a, b) => (s.sd * 7 + a * 101 + b * 7919) >>> 0;
  const judgeBase = (m) => m.st[4] + m.st[2] * 0.4 + m.st[1] * 0.2 + m.mo * 2 + m.g * 3;
  function pairs(E) { const p = []; for (let a = 0; a < E; a++) for (let b = a + 1; b < E; b++) p.push([a, b]); return p; }

  /* ---------- 초기화 ---------- */
  function init(players, opts) {
    const n = players.length, D = +((opts && opts.days) || 15);
    const E = n === 1 ? 4 : n;
    const s = {
      n, E, D, d: 0, ph: 'c',
      nm: players.map((p, i) => String(p.name || (i + 1) + '번').slice(0, 8)),
      st: [], af: [], en: [], mo: [], e: [], v: [], g: [], lf: [], ch: [],
      pt: Array(E).fill(0), rv: [], mt: [], hot: rnd(9), sd: 1 + rnd(1e6), fb: null, fj: null, last: { id: 0 }, sq: 0,
    };
    for (let i = 0; i < n; i++) {
      const st = [8, 8, 8, 8, 8]; st[rnd(5)] += 4;
      s.st.push(st); s.af.push([0, 0, 0, 0]); s.en.push(8); s.mo.push(6);
      s.e.push(-1); s.v.push(-1); s.g.push(0); s.lf.push(-1); s.ch.push(null);
    }
    if (n === 1) {
      const els = U.shuffle([0, 1, 2, 3]);
      for (let t = 0; t < 3; t++) s.rv.push([els[t], rnd(3), t]);
    }
    const a = rnd(5); let b = rnd(4); if (b >= a) b++;
    s.mt = [a, b];
    return s;
  }

  function actor(s) {
    if (s.ph !== 'c') return null;
    const a = [];
    for (let i = 0; i < s.n; i++) if (s.ch[i] == null) a.push(i);
    return a;
  }
  function legal(s, i, c) {
    if (!(c >= 0 && c <= 10)) return false;
    const C = CARDS[c];
    if (C.k === 't') return s.en[i] >= TR_EN;
    if (C.k === 'x') return s.en[i] >= EX_EN;
    return true;
  }
  const moodBonus = (mo) => (mo >= 7 ? 2 : mo <= 2 ? -2 : 0);

  function doCard(s, i, c) {
    const C = CARDS[c], st = s.st[i], b0 = st.slice(), en0 = s.en[i], mo0 = s.mo[i], hot = s.hot === c;
    let ev = -1;
    if (C.k === 'f') {
      st[C.s] += 2 + (hot ? 2 : 0); s.af[i][C.e] += 3 + (hot ? 1 : 0);
      s.en[i] += 2; s.mo[i] += s.lf[i] === C.e ? -1 : 1; s.lf[i] = C.e;
    } else {
      s.lf[i] = -1;
      if (C.k === 't') { st[C.s] += 5 + moodBonus(s.mo[i]) + (hot ? 3 : 0); st[C.b] += 1; s.en[i] -= TR_EN; s.mo[i] -= 1; }
      else if (C.k === 'r') { s.en[i] += 5; s.mo[i] += 2; }
      else {
        s.en[i] -= EX_EN; s.mo[i] += 1;
        let tot = 3; for (const x of EX) tot += x.w;
        let r = Math.random() * tot;
        if (r < 3) { ev = rnd(4); s.af[i][ev] += 3; s.en[i] += 1; }
        else {
          r -= 3; let j = 0; while (j < EX.length - 1 && r >= EX[j].w) { r -= EX[j].w; j++; }
          const x = EX[j]; ev = 4 + j;
          if (x.d) for (let q = 0; q < 5; q++) st[q] += x.d[q];
          if (x.m) s.mo[i] += x.m;
          if (x.en) s.en[i] += x.en;
        }
      }
    }
    for (let q = 0; q < 5; q++) st[q] = clampI(st[q], 0, 99);
    s.en[i] = clampI(s.en[i], 0, 10); s.mo[i] = clampI(s.mo[i], 0, 10);
    return [c, ev, hot ? 1 : 0].concat(st.map((x, j) => x - b0[j]), [s.en[i] - en0, s.mo[i] - mo0]);
  }
  function evolve(s, i) {
    if (s.g[i] >= 3) return;
    if (s.g[i] === 0) {
      const af = s.af[i], mx = Math.max(...af), c = [0, 1, 2, 3].filter((j) => af[j] === mx);
      s.e[i] = c[rnd(c.length)];
    } else s.v[i] = styleOf(s.st[i]);
    s.g[i]++;
  }
  function contest(s, t) {
    const sc = [];
    for (let k = 0; k < s.E; k++) { const m = mon(s, k); sc.push(Math.round((m.st[t] + m.mo + Math.random() * 6) * 10) / 10); }
    const gain = sc.map((x) => sc.filter((y) => y < x).length);
    gain.forEach((x, k) => (s.pt[k] += x));
    return { t, sc, gn: gain };
  }
  function finale(s) {
    const fb = [];
    for (const [a, b] of pairs(s.E)) {
      const r = battle(mon(s, a), mon(s, b), bSeed(s, a, b));
      const w = r.w ? b : a; fb.push(w); s.pt[w] += 3;
    }
    const fj = [];
    for (let k = 0; k < s.E; k++) fj.push(Math.round((judgeBase(mon(s, k)) + Math.random() * 8) * 10) / 10);
    fj.forEach((x, k) => (s.pt[k] += 2 * fj.filter((y) => y < x).length));
    s.fb = fb; s.fj = fj;
  }

  function apply(s, seat, a) {
    if (s.ph !== 'c') throw new Error('대회가 끝났어요');
    if (!(seat >= 0 && seat < s.n) || s.ch[seat] != null) throw new Error('오늘은 이미 골랐어요');
    const c = a && typeof a.c === 'number' ? a.c : -1;
    if (!legal(s, seat, c)) throw new Error(CARDS[c] ? '기력이 모자라요' : '알 수 없는 카드예요');
    s.ch[seat] = c;
    if (s.ch.some((x) => x == null)) return s;
    const R = [];
    for (let i = 0; i < s.n; i++) R.push(doCard(s, i, s.ch[i]));
    s.d++;
    let ev = 0, mc = null, fin = 0;
    if (evoDays(s.D).indexOf(s.d) >= 0) { ev = 1; for (let i = 0; i < s.n; i++) evolve(s, i); }
    const ci = conDays(s.D).indexOf(s.d);
    if (ci >= 0) mc = contest(s, s.mt[ci]);
    if (s.d >= s.D) { finale(s); s.ph = 'x'; fin = 1; }
    else { let h = rnd(9); if (h === s.hot) h = rnd(9); s.hot = h; }
    s.ch = Array(s.n).fill(null);
    s.last = { id: ++s.sq, d: s.d, r: R, ev, mc, fin };
    return s;
  }

  function ranking(s) {
    const tot = (k) => sum(mon(s, k).st);
    return Array.from({ length: s.E }, (_, k) => k).sort((a, b) => s.pt[b] - s.pt[a] || tot(b) - tot(a) || a - b);
  }
  function result(s) {
    if (s.ph !== 'x') return null;
    const ord = ranking(s), tot = (k) => sum(mon(s, k).st);
    const line = (k, r) => r + '위  ' + nameOf(s, k) + ' · ' + formName(mon(s, k).e, mon(s, k).v, mon(s, k).g) + '  ' + s.pt[k] + '점';
    let rk = 0;
    const lines = ord.map((k, j) => { if (j === 0 || s.pt[k] !== s.pt[ord[j - 1]] || tot(k) !== tot(ord[j - 1])) rk = j + 1; return line(k, rk); });
    if (s.n === 1) {
      const p = ord.indexOf(0), stars = Math.max(0, 3 - p);
      return { winners: stars ? [0] : [], title: stars ? '별 ' + stars + '개!' : '아쉬워요', text: '★'.repeat(stars) + '☆'.repeat(3 - stars) + '\n' + lines.join('\n') };
    }
    const top = ord[0];
    const win = ord.filter((k) => s.pt[k] === s.pt[top] && tot(k) === tot(top));
    return { winners: win, title: win.length > 1 ? '공동 우승' : s.nm[win[0]] + ' 우승!', text: lines.join('\n') };
  }

  /* ---------- AI ---------- */
  function hash(a, b) { let x = (a * 73856093) ^ (b * 19349663); x = (x ^ (x >>> 13)) * 1274126177; return ((x ^ (x >>> 16)) >>> 0) / 4294967296; }
  function targetEl(s, i, lv) {
    if (lv >= 3) {
      const cnt = [0, 0, 0, 0];
      for (let k = 0; k < s.E; k++) {
        if (k === i) continue;
        const m = mon(s, k);
        let e = m.e;
        if (e < 0 && k < s.n) { const af = s.af[k], mx = Math.max(...af); if (mx > 0) e = af.indexOf(mx); }
        if (e < 0 && m.rv) e = m.rv[0];
        if (e >= 0) cnt[e]++;
      }
      let best = -1, bv = -1e9;
      for (let e = 0; e < 4; e++) {
        let v = 0; for (let o = 0; o < 4; o++) v += cnt[o] * (BEAT[e] === o ? 1 : BEAT[o] === e ? -1 : 0);
        v += hash(s.sd, i * 4 + e) * 0.5 + s.af[i][e] * 0.2;
        if (v > bv) { bv = v; best = e; }
      }
      return best;
    }
    const af = s.af[i], mx = Math.max(...af);
    return mx > 0 ? af.indexOf(mx) : Math.floor(hash(s.sd, i + 7) * 4);
  }
  function aiPick(s, i, lv) {
    const leg = []; for (let c = 0; c < 11; c++) if (legal(s, i, c)) leg.push(c);
    const en = s.en[i], mo = s.mo[i], st = s.st[i], left = s.D - s.d;
    if (lv <= 1) {
      if (Math.random() < 0.5) return leg[rnd(leg.length)];
      if (en < TR_EN) return Math.random() < 0.6 ? 9 : rnd(4);
      return Math.random() < 0.7 ? 4 + rnd(5) : rnd(4);
    }
    const noise = lv === 2 ? 0.35 : 0;
    // 첫 진화 전: 원하는 갈래 먹이
    if (s.g[i] === 0) {
      const T = targetEl(s, i, lv), af = s.af[i];
      const lead = af[T] - Math.max(...af.filter((_, j) => j !== T));
      if (lead < (lv >= 3 ? 3 : 2) && (lv >= 3 || Math.random() < 0.8)) return T;
    }
    const W0 = [1.0, 0.95, 0.7, 1.0, 1.1], W = lv >= 3 ? W0 : W0.map((x, j) => x - 0.15 + hash(s.sd, i * 5 + j) * 0.3);
    const cds = conDays(s.D);
    function statVal(j) {
      let v = W[j] / (1 + st[j] / 30) + noise * (Math.random() - 0.5);
      if (lv >= 3) { for (let q = 0; q < 2; q++) { const dd = cds[q] - s.d; if (dd >= 1 && dd <= 3) { if (s.mt[q] === j) v += 0.6; } } }
      return v;
    }
    function bestFood() {
      let b = 0, bv = -1e9;
      for (let c = 0; c < 4; c++) { const v = statVal(CARDS[c].s) + (s.hot === c ? 0.8 : 0) - (s.lf[i] === c ? 0.6 : 0); if (v > bv) { bv = v; b = c; } }
      return b;
    }
    function bestTrain() {
      let b = 4, bv = -1e9;
      for (let c = 4; c <= 8; c++) { const v = statVal(CARDS[c].s) + (s.hot === c ? (lv >= 3 ? 0.9 : 0.4) : 0); if (v > bv) { bv = v; b = c; } }
      return b;
    }
    if (left === 1) return en >= TR_EN ? bestTrain() : bestFood();
    if (mo <= 2) return en >= 8 && lv >= 3 ? 10 : 9;
    if (en < TR_EN) return lv >= 3 && mo >= 7 && en === 2 ? bestFood() : 9;
    if (lv >= 3) {
      if (mo <= 5 && en <= 6) return 9;
      if (mo === 6 && en <= 5) return bestFood();
      if (s.hot < 4 && en <= 7 && mo <= 7) return bestFood();
    } else { if (mo <= 5 && en <= 5) return 9; if (mo <= 6 && en <= 4) return bestFood(); }
    return bestTrain();
  }
  function ai(s, seat, lv) {
    if (s.ph !== 'c' || s.ch[seat] != null) return null;
    return { c: aiPick(s, seat, lv || 2) };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph !== 'c' || s.ch[seat] != null) return -1;
    return [0, 1300, 1000, 800][lv || 2] + seat * 120;
  }

  /* ---------- 몬스터 그리기 (100단위 좌표, 바닥 y=0, 오른쪽을 봄) ---------- */
  const PAL = [
    { b: ['#e2552f', '#b8402a', '#ff7140', '#ef4f6e'], y: '#ffc977', a: '#ffd23f', d: '#7a2412' },
    { b: ['#3f8fdc', '#3270b8', '#2fb3d9', '#7a8ff0'], y: '#d6efff', a: '#9ee6ff', d: '#1d3f6e' },
    { b: ['#7cb35a', '#6c8f4a', '#8fd06a', '#a8cf6a'], y: '#e9f3c8', a: '#ff8fb8', d: '#2f4a22', sh: '#7a5a35' },
    { b: ['#f4c534', '#e0a628', '#ffd84d', '#f7d77a'], y: '#fff3c4', a: '#7b6cff', d: '#5a4a20' },
  ];
  function drawMon(ctx, m, S, t, opt) {
    opt = opt || {};
    const e = m.e, g = e < 0 ? 0 : m.g, v = g >= 2 ? m.v : -1, mo = m.mo == null ? 6 : m.mo;
    const k = [0.55, 0.7, 0.85, 1][g], u = (S * k) / 100;
    ctx.save();
    ctx.scale(u * (opt.flip ? -1 : 1), u);
    if (opt.rot) ctx.rotate(opt.rot);
    ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(0, 0, 44, 7, 0, 0, 7); ctx.fill();
    const bob = opt.still ? 0 : Math.sin(t * 0.004 + (opt.ph || 0)) * 1.6;
    ctx.translate(0, bob);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    const D = { ctx, t, g, v, mo, opt };
    if (e < 0) drawBaby(D, opt.hint);
    else [drawLizard, drawSeal, drawTurtle, drawFox][e](D, PAL[e], PAL[e].b[v + 1]);
    ctx.restore();
  }
  const OUT = 'rgba(30,14,28,.55)';
  function ell(c, x, y, rx, ry, col, rot, stroke) {
    c.fillStyle = col; c.beginPath(); c.ellipse(x, y, rx, ry, rot || 0, 0, 7); c.fill();
    if (stroke !== false) { c.strokeStyle = OUT; c.lineWidth = 2.2; c.stroke(); }
  }
  function poly(c, pts, col, stroke) {
    c.fillStyle = col; c.beginPath(); c.moveTo(pts[0], pts[1]);
    for (let j = 2; j < pts.length; j += 2) c.lineTo(pts[j], pts[j + 1]);
    c.closePath(); c.fill();
    if (stroke !== false) { c.strokeStyle = OUT; c.lineWidth = 2; c.stroke(); }
  }
  function face(D, x, y, r) {
    const c = D.ctx, mo = D.mo, blink = (D.t % 3600) < 120;
    const ex = [x + r * 0.42, x - r * 0.08], ey = y - r * 0.12, er = r * 0.24;
    for (let j = 0; j < 2; j++) {
      const rr = er * (j ? 0.9 : 1);
      if (blink) { c.strokeStyle = '#2a1626'; c.lineWidth = 2; c.beginPath(); c.moveTo(ex[j] - rr, ey); c.lineTo(ex[j] + rr, ey); c.stroke(); continue; }
      c.fillStyle = '#fff'; c.beginPath(); c.ellipse(ex[j], ey, rr, rr * 1.15, 0, 0, 7); c.fill();
      c.fillStyle = '#2a1626'; c.beginPath(); c.arc(ex[j] + rr * 0.25, ey + rr * 0.1, rr * 0.62, 0, 7); c.fill();
      c.fillStyle = '#fff'; c.beginPath(); c.arc(ex[j] + rr * 0.42, ey - rr * 0.22, rr * 0.22, 0, 7); c.fill();
      if (mo <= 2) { c.strokeStyle = '#2a1626'; c.lineWidth = 1.8; c.beginPath(); c.moveTo(ex[j] - rr, ey - rr * 1.6); c.lineTo(ex[j] + rr, ey - rr * 1.2); c.stroke(); }
    }
    c.strokeStyle = '#2a1626'; c.lineWidth = 2;
    const mx = x + r * 0.2, my = y + r * 0.42;
    c.beginPath();
    if (mo >= 7) { c.arc(mx, my - 2, r * 0.2, 0.15 * Math.PI, 0.85 * Math.PI); }
    else if (mo <= 2) { c.arc(mx, my + 4, r * 0.18, 1.15 * Math.PI, 1.85 * Math.PI); }
    else { c.moveTo(mx - r * 0.13, my); c.lineTo(mx + r * 0.13, my); }
    c.stroke();
    if (mo >= 7) { c.fillStyle = 'rgba(255,120,150,.55)'; c.beginPath(); c.ellipse(x + r * 0.62, y + r * 0.3, r * 0.15, r * 0.09, 0, 0, 7); c.fill(); }
  }
  function flame(c, x, y, s, t, ph) {
    const f = 1 + Math.sin(t * 0.018 + (ph || 0)) * 0.12;
    c.save(); c.translate(x, y); c.scale(s, s * f);
    c.fillStyle = '#ff7b2e'; c.beginPath(); c.moveTo(0, -18); c.quadraticCurveTo(10, -4, 6, 4); c.quadraticCurveTo(0, 10, -6, 4); c.quadraticCurveTo(-10, -4, 0, -18); c.fill();
    c.fillStyle = '#ffd23f'; c.beginPath(); c.moveTo(0, -9); c.quadraticCurveTo(5, -1, 3, 4); c.quadraticCurveTo(0, 7, -3, 4); c.quadraticCurveTo(-5, -1, 0, -9); c.fill();
    c.restore();
  }
  function star(c, x, y, r, col) {
    c.fillStyle = col; c.beginPath();
    for (let j = 0; j < 10; j++) { const a = -Math.PI / 2 + (j * Math.PI) / 5, rr = j & 1 ? r * 0.45 : r; c.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); }
    c.closePath(); c.fill();
  }
  function leaf(c, x, y, len, ang, col) {
    c.save(); c.translate(x, y); c.rotate(ang);
    c.fillStyle = col; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(len * 0.5, -len * 0.35, len, 0); c.quadraticCurveTo(len * 0.5, len * 0.35, 0, 0); c.fill();
    c.strokeStyle = 'rgba(20,50,20,.55)'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(0, 0); c.lineTo(len * 0.9, 0); c.stroke();
    c.restore();
  }
  function crown(c, x, y, w) {
    poly(c, [x - w, y, x - w, y - w * 0.9, x - w * 0.5, y - w * 0.4, x, y - w * 1.2, x + w * 0.5, y - w * 0.4, x + w, y - w * 0.9, x + w, y], '#ffd34d');
    c.fillStyle = '#ff5d7a'; c.beginPath(); c.arc(x, y - w * 0.35, w * 0.18, 0, 7); c.fill();
  }
  function sparkles(D, cx, cy, R, n, col) {
    const c = D.ctx;
    for (let j = 0; j < n; j++) {
      const a = D.t * 0.0012 + (j * Math.PI * 2) / n, tw = 0.6 + 0.4 * Math.sin(D.t * 0.006 + j * 2);
      star(c, cx + Math.cos(a) * R, cy + Math.sin(a) * R * 0.6, 4 * tw + 1, col);
    }
  }
  function wing(D, x, y, size, col, kind) {
    const c = D.ctx, fl = Math.sin(D.t * 0.008) * 0.25;
    c.save(); c.translate(x, y); c.rotate(-0.5 + fl);
    if (kind === 'bat') poly(c, [0, 0, -size * 0.3, -size, -size * 0.55, -size * 0.55, -size * 0.85, -size * 0.75, -size, -size * 0.2, -size * 0.6, -size * 0.1], col);
    else if (kind === 'fin') { c.globalAlpha = 0.85; poly(c, [0, 0, -size * 0.4, -size, -size, -size * 0.6, -size * 0.6, -size * 0.1], col); c.globalAlpha = 1; }
    else if (kind === 'leaf') { leaf(c, 0, 0, size, -Math.PI * 0.75, col); leaf(c, 0, 0, size * 0.75, -Math.PI * 0.62, col); }
    else poly(c, [0, 0, -size * 0.35, -size * 0.55, -size * 0.2, -size * 0.6, -size * 0.7, -size, -size * 0.55, -size * 0.45, -size * 0.75, -size * 0.4, -size * 0.6, -size * 0.05], col);
    c.restore();
  }
  function drawBaby(D, hint) {
    const c = D.ctx, hc = hint >= 0 ? EL[hint].c : '#ff9db5';
    ell(c, -12, -3, 9, 5, '#d9bf96'); ell(c, 12, -3, 9, 5, '#d9bf96');
    ell(c, 0, -34, 33, 32, '#f3dcb6');
    ell(c, 3, -24, 21, 17, '#fff4de', 0, false);
    c.strokeStyle = '#3d7a3a'; c.lineWidth = 3; c.beginPath(); c.moveTo(0, -65); c.quadraticCurveTo(-2, -74, 2, -78); c.stroke();
    leaf(c, 2, -76, 12, -0.5, hint >= 0 ? hc : '#7fcf6a'); leaf(c, 0, -74, 10, -2.6, '#7fcf6a');
    // 알껍질
    poly(c, [-34, -18, -26, -26, -18, -16, -10, -26, -2, -16, 6, -26, 14, -16, 22, -26, 30, -16, 35, -20, 32, -2, 18, 2, -18, 2, -32, -2], '#fffaf0');
    face(D, 2, -44, 20);
    c.fillStyle = hc; c.globalAlpha = 0.5; c.beginPath(); c.ellipse(16, -36, 4, 2.5, 0, 0, 7); c.fill(); c.globalAlpha = 1;
  }
  function drawLizard(D, P, body) {
    const c = D.ctx, g = D.g, v = D.v, t = D.t;
    c.translate(10, 0);
    const bw = v === 0 ? 40 : v === 1 ? 31 : 35, bh = v === 0 ? 22 : v === 1 ? 15 : 18, legL = v === 1 ? 17 : 10;
    const by = -(legL + bh * 0.7);
    // 꼬리
    const tl = 26 + g * 6, tx = -bw - tl * 0.55, ty = by - 10 - g * 4;
    c.strokeStyle = OUT; c.lineWidth = 15; c.beginPath(); c.moveTo(-bw * 0.6, by + 2); c.quadraticCurveTo(-bw - tl * 0.4, by + 10, tx, ty); c.stroke();
    c.strokeStyle = body; c.lineWidth = 11; c.stroke();
    flame(c, tx, ty - 4, 0.9 + g * 0.25, t);
    if (v === 1) wing(D, -4, by - bh * 0.6, g === 3 ? 52 : 32, '#ffb05a', 'bat');
    // 다리
    const lw = v === 0 ? 11 : v === 1 ? 7 : 9;
    for (const lx of [-bw * 0.55, -bw * 0.22, bw * 0.22, bw * 0.55]) { ell(c, lx, by + bh * 0.4 + legL * 0.5, lw * 0.6, legL * 0.65 + 3, P.b[0]); }
    ell(c, 0, by, bw, bh, body);
    ell(c, 4, by + bh * 0.38, bw * 0.72, bh * 0.45, P.y, 0, false);
    if (v === 0) { c.strokeStyle = '#ffb340'; c.lineWidth = 2; c.beginPath(); c.moveTo(-bw * 0.5, by - 4); c.lineTo(-bw * 0.3, by + 2); c.lineTo(-bw * 0.1, by - 6); c.moveTo(bw * 0.1, by - 2); c.lineTo(bw * 0.3, by + 4); c.stroke(); }
    if (g >= 2) {
      const n = 5, col = v === 0 ? P.d : v === 2 ? '#ffd23f' : '#ff9a52';
      for (let j = 0; j < n; j++) {
        const x = -bw * 0.6 + (j * bw * 1.2) / (n - 1), yy = by - bh * Math.sqrt(Math.max(0, 1 - (x / bw) ** 2)) + 2, h = (v === 0 ? 11 : 7) + (g === 3 ? 4 : 0);
        if (v === 2) flame(c, x, yy, 0.5, t, j); else poly(c, [x - 6, yy, x, yy - h, x + 6, yy], col);
      }
    }
    // 머리
    const hr = 15 + g, hx = bw * 0.82, hy = by - bh * 0.75 - 4;
    if (v === 2) for (let j = 0; j < 8; j++) { const a = Math.PI * 0.5 + (j * Math.PI * 1.4) / 7; flame(c, hx - 2 + Math.cos(a) * hr * 1.05, hy + Math.sin(a) * hr * 0.95, 0.55 + (g - 2) * 0.2, t, j); }
    ell(c, hx + hr * 0.75, hy + hr * 0.25, hr * 0.75, hr * 0.55, body);
    ell(c, hx, hy, hr * 1.1, hr, body);
    if (v === 0) {
      const H = g === 3 ? 22 : 13;
      poly(c, [hx - hr * 0.5, hy - hr * 0.6, hx - hr * 0.9 - H * 0.6, hy - hr - H, hx - hr * 0.05, hy - hr * 0.85], '#f2e6c8');
      poly(c, [hx + hr * 0.1, hy - hr * 0.8, hx - hr * 0.1 - H * 0.3, hy - hr - H * 1.1, hx + hr * 0.5, hy - hr * 0.75], '#f2e6c8');
    }
    face(D, hx + 2, hy, hr);
    c.fillStyle = P.d; c.beginPath(); c.arc(hx + hr * 1.35, hy + hr * 0.12, 1.6, 0, 7); c.fill();
    if (v === 2 && g === 3) crown(c, hx, hy - hr * 0.9, 9);
    if (g === 3 && v === 1) sparkles(D, -10, by - 30, 50, 4, '#ffb05a');
  }
  function drawSeal(D, P, body) {
    const c = D.ctx, g = D.g, v = D.v, t = D.t;
    const bw = v === 0 ? 42 : 37, bh = v === 0 ? 26 : 23, by = -bh - 2;
    // 꼬리 지느러미
    ell(c, -bw - 4, by + 14, 12, 6, P.b[0], -0.5); ell(c, -bw - 2, by + 22, 12, 6, P.b[0], 0.5);
    if (v === 1) { wing(D, -6, by - bh * 0.5, g === 3 ? 50 : 32, '#9ee6ff', 'fin'); poly(c, [-14, by - bh + 3, -6, by - bh - 12 - g * 3, 6, by - bh + 4], P.b[2]); }
    ell(c, -4, by, bw, bh, body);
    ell(c, 2, by + bh * 0.35, bw * 0.75, bh * 0.5, P.y, 0, false);
    if (v === 0) {
      const ice = g === 3 ? 1.3 : 1;
      poly(c, [-bw * 0.7, by - bh * 0.4, -bw * 0.45, by - bh - 8 * ice, -bw * 0.2, by - bh * 0.75, 0, by - bh - 12 * ice, bw * 0.2, by - bh * 0.85], '#d6f3ff');
    }
    ell(c, bw * 0.25, by + bh * 0.75, 12, 6, P.b[0], 0.5);
    const hr = 18 + g, hx = bw * 0.62, hy = by - bh * 0.85;
    ell(c, hx, hy, hr, hr * 0.95, body);
    ell(c, hx + hr * 0.6, hy + hr * 0.35, hr * 0.5, hr * 0.35, P.y);
    if (v === 0) {
      const T = g === 3 ? 18 : 11;
      poly(c, [hx + hr * 0.45, hy + hr * 0.55, hx + hr * 0.55, hy + hr * 0.55 + T, hx + hr * 0.7, hy + hr * 0.55], '#ffffff');
      poly(c, [hx + hr * 0.8, hy + hr * 0.5, hx + hr * 0.9, hy + hr * 0.5 + T * 0.9, hx + hr * 1.02, hy + hr * 0.45], '#ffffff');
    }
    c.strokeStyle = 'rgba(30,30,60,.6)'; c.lineWidth = 1.2;
    for (let j = -1; j <= 1; j++) { c.beginPath(); c.moveTo(hx + hr * 0.8, hy + hr * 0.35); c.lineTo(hx + hr * 1.4, hy + hr * 0.3 + j * 4); c.stroke(); }
    face(D, hx - 2, hy - 2, hr * 0.95);
    if (g <= 1 || v === 1) { c.fillStyle = P.a; c.beginPath(); c.moveTo(hx, hy - hr - 14); c.quadraticCurveTo(hx + 7, hy - hr - 2, hx, hy - hr + 1); c.quadraticCurveTo(hx - 7, hy - hr - 2, hx, hy - hr - 14); c.fill(); c.strokeStyle = OUT; c.lineWidth = 1.5; c.stroke(); }
    if (v === 2) {
      for (let j = 0; j < 5 + g; j++) { const a = Math.PI * 0.15 + (j * Math.PI * 0.7) / (4 + g); ell(c, hx - 4 + Math.cos(a) * hr * 0.95, hy + 6 + Math.sin(a) * hr * 0.9, 3.4, 3.4, '#fffdf2'); }
      c.fillStyle = 'rgba(200,240,255,.7)';
      for (let j = 0; j < 3; j++) { const yy = -((t * 0.03 + j * 30) % 90); c.beginPath(); c.arc(-20 + j * 14, by + yy, 3 + j, 0, 7); c.fill(); }
      if (g === 3) { crown(c, hx - 2, hy - hr * 0.85, 9); }
    }
  }
  function drawTurtle(D, P, body) {
    const c = D.ctx, g = D.g, v = D.v;
    const legL = v === 1 ? 16 : 8, lw = v === 0 ? 12 : 9, sw = v === 0 ? 44 : 39, shh = v === 0 ? 34 : 29;
    const base = -legL - 6;
    for (const lx of [-sw * 0.6, -sw * 0.25, sw * 0.25, sw * 0.6]) ell(c, lx, base + legL * 0.5 + 3, lw * 0.6, legL * 0.6 + 3, body);
    ell(c, -sw - 2, base, 8, 4, body, 0.3);
    // 목·머리
    const hr = 13 + g, hx = sw + 6, hy = base - 12;
    c.strokeStyle = OUT; c.lineWidth = 15; c.beginPath(); c.moveTo(sw * 0.6, base - 4); c.lineTo(hx - 4, hy + 4); c.stroke();
    c.strokeStyle = body; c.lineWidth = 11; c.stroke();
    ell(c, hx, hy, hr * 1.1, hr, body);
    face(D, hx + 1, hy, hr);
    if (v === 1) { wing(D, -sw * 0.2, base - shh * 0.7, g === 3 ? 46 : 30, '#8fd06a', 'leaf'); }
    // 등껍질
    c.fillStyle = v === 0 ? '#8a8172' : P.sh; c.beginPath(); c.ellipse(0, base, sw, shh, 0, Math.PI, Math.PI * 2); c.closePath(); c.fill();
    c.strokeStyle = OUT; c.lineWidth = 2.2; c.stroke();
    ell(c, 0, base, sw + 2, 5, '#5a4128');
    c.strokeStyle = 'rgba(40,25,10,.5)'; c.lineWidth = 1.6;
    c.beginPath(); c.moveTo(-sw * 0.45, base); c.lineTo(-sw * 0.3, base - shh * 0.6); c.lineTo(sw * 0.3, base - shh * 0.6); c.lineTo(sw * 0.45, base); c.moveTo(0, base - shh * 0.6); c.lineTo(0, base - shh); c.stroke();
    // 이끼
    c.fillStyle = '#5ea84a';
    for (let j = 0; j < 5; j++) { c.beginPath(); c.arc(-sw * 0.5 + j * sw * 0.25, base - shh * (0.78 + 0.12 * Math.sin(j * 2.1)), 7 + (j % 2) * 2, 0, 7); c.fill(); }
    if (v === 0) {
      c.fillStyle = '#a69d8c';
      for (let j = 0; j < 3; j++) poly(c, [-sw * 0.5 + j * sw * 0.45, base - shh * 0.3, -sw * 0.4 + j * sw * 0.45, base - shh * 0.55, -sw * 0.25 + j * sw * 0.45, base - shh * 0.35], '#b3aa98');
      if (g === 3) {
        c.fillStyle = '#6b4a2a'; c.fillRect(-5, base - shh - 22, 10, 24); c.strokeStyle = OUT; c.strokeRect(-5, base - shh - 22, 10, 24);
        ell(c, 0, base - shh - 34, 22, 15, '#3f8f3a'); ell(c, -14, base - shh - 26, 12, 9, '#4aa142'); ell(c, 14, base - shh - 27, 12, 9, '#4aa142');
      } else { ell(c, -10, base - shh - 3, 9, 7, '#4aa142'); ell(c, 8, base - shh - 4, 10, 8, '#3f8f3a'); }
    }
    if (g <= 1) { leaf(c, 0, base - shh - 2, 13, -1.9, '#7fcf6a'); leaf(c, 0, base - shh - 2, 11, -1.1, '#9fe07a'); }
    if (v === 2) {
      const fl = g === 3 ? [[-26, -0.7], [-10, -0.98], [8, -0.98], [24, -0.72], [-16, -0.45], [16, -0.45]] : [[-18, -0.85], [2, -1], [20, -0.8]];
      for (const [fx, fy] of fl) {
        const x = fx, y = base + shh * fy;
        c.fillStyle = '#ff8fb8';
        for (let p = 0; p < 5; p++) { const a = (p * Math.PI * 2) / 5 + D.t * 0.0005; c.beginPath(); c.arc(x + Math.cos(a) * 4.5, y + Math.sin(a) * 4.5, 3.6, 0, 7); c.fill(); }
        c.fillStyle = '#ffe066'; c.beginPath(); c.arc(x, y, 2.8, 0, 7); c.fill();
      }
      if (g === 3) { const bx = 30 + Math.sin(D.t * 0.002) * 12, byy = base - shh - 20 + Math.cos(D.t * 0.003) * 6, fw = Math.abs(Math.sin(D.t * 0.02)); ell(c, bx - 4, byy, 5 * fw + 1, 4, '#c58bff', 0, false); ell(c, bx + 4, byy, 5 * fw + 1, 4, '#c58bff', 0, false); }
    }
  }
  function drawFox(D, P, body) {
    const c = D.ctx, g = D.g, v = D.v, t = D.t;
    const legL = v === 1 ? 22 : 17, lw = v === 0 ? 10 : 7, bw = v === 0 ? 33 : 29, bh = v === 0 ? 19 : 16;
    const by = -(legL + bh * 0.55);
    // 번개 꼬리
    const ts = 1 + g * 0.18 + (v === 2 ? 0.2 : 0);
    const tail = (ang, sc, col) => { c.save(); c.translate(-bw * 0.8, by - 2); c.rotate(ang); c.scale(ts * sc, ts * sc); poly(c, [0, 0, -14, -10, -8, -14, -26, -26, -16, -28, -34, -46, -12, -30, -18, -27, -4, -12], col); c.restore(); };
    if (v === 2) { tail(-0.5, 0.85, '#fff3a0'); tail(0.35, 0.85, '#fff3a0'); }
    tail(0, 1, P.a);
    if (v === 1) wing(D, -2, by - bh * 0.6, g === 3 ? 50 : 32, '#fff07a', 'bolt');
    for (const lx of [-bw * 0.6, -bw * 0.3, bw * 0.3, bw * 0.6]) { ell(c, lx, by + bh * 0.4 + legL * 0.45, lw * 0.55, legL * 0.62 + 2, P.b[0]); if (v === 0) { c.fillStyle = '#f5f0e0'; for (let q = -1; q <= 1; q++) { c.beginPath(); c.arc(lx + 3 + q * 3, -2, 1.8, 0, 7); c.fill(); } } }
    ell(c, 0, by, bw, bh, body);
    ell(c, 4, by + bh * 0.4, bw * 0.7, bh * 0.42, P.y, 0, false);
    c.strokeStyle = P.d; c.lineWidth = 2.4;
    for (let j = 0; j < 2 + (g >= 2 ? 1 : 0); j++) { const x = -bw * 0.4 + j * 12; c.beginPath(); c.moveTo(x, by - bh * 0.85); c.lineTo(x + 4, by - bh * 0.4); c.lineTo(x - 1, by - bh * 0.25); c.lineTo(x + 3, by + 2); c.stroke(); }
    const hr = 15 + g, hx = bw * 0.85, hy = by - bh * 0.95 - 4;
    if (v === 0) for (let j = 0; j < 7; j++) { const a = Math.PI * 0.4 + (j * Math.PI * 1.2) / 6; ell(c, hx - 4 + Math.cos(a) * hr * 1.0, hy + 5 + Math.sin(a) * hr * 0.9, 7 + g, 6 + g, '#9aa3b8'); }
    // 귀
    const ear = (x, s) => { poly(c, [x - 6 * s, hy - hr * 0.6, x - 2 * s, hy - hr - 16 - g * 2, x + 7 * s, hy - hr * 0.7], body); c.strokeStyle = P.a; c.lineWidth = 2; c.beginPath(); c.moveTo(x - 1, hy - hr * 0.75); c.lineTo(x + 2, hy - hr - 4); c.lineTo(x - 1, hy - hr - 8); c.stroke(); };
    ear(hx - hr * 0.45, 1); ear(hx + hr * 0.35, 1);
    ell(c, hx, hy, hr * 1.05, hr * 0.95, body);
    poly(c, [hx + hr * 0.6, hy - hr * 0.1, hx + hr * 1.55, hy + hr * 0.25, hx + hr * 0.6, hy + hr * 0.6], body);
    c.fillStyle = '#2a1626'; c.beginPath(); c.arc(hx + hr * 1.5, hy + hr * 0.25, 2.2, 0, 7); c.fill();
    face(D, hx - 1, hy, hr);
    if (v === 0 && g === 3) {
      const cx = hx - 10, cy = hy - hr - 30;
      ell(c, cx - 10, cy, 12, 9, '#7d849a'); ell(c, cx + 6, cy - 3, 14, 11, '#8a92a8'); ell(c, cx + 18, cy + 1, 10, 8, '#7d849a');
      if ((t % 1400) < 500) poly(c, [cx + 2, cy + 8, cx - 4, cy + 18, cx + 2, cy + 18, cx - 3, cy + 28, cx + 8, cy + 14, cx + 3, cy + 14, cx + 6, cy + 8], '#fff07a', false);
    }
    if (v === 2) { sparkles(D, -6, by - 20, 46 + g * 4, 3 + g, '#fff6a8'); if (g === 3) { c.strokeStyle = 'rgba(255,240,160,.85)'; c.lineWidth = 2.5; c.beginPath(); c.ellipse(hx, hy - hr - 8, 13, 4, 0, 0, 7); c.stroke(); } }
  }

  /* ---------- 화면 ---------- */
  const CSS = `
.mo{position:absolute;inset:0;display:flex;flex-direction:column;background:#17131f;color:var(--ink);font-family:var(--f-body)}
.mo-strip{display:grid;gap:4px;padding:5px 6px 3px;flex:none}
.mo-pc{appearance:none;font:inherit;color:var(--ink);text-align:left;border:1px solid rgba(255,255,255,.1);background:rgba(46,38,64,.85);border-radius:10px;padding:3px 6px;min-height:44px;min-width:0;cursor:pointer;display:flex;flex-direction:column;justify-content:center;gap:1px;position:relative}
.mo-pc.on{border-color:var(--brass);box-shadow:0 0 0 1px var(--brass) inset}
.mo-pc .a{display:flex;align-items:center;gap:4px;font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;min-width:0}
.mo-pc .a .nmx{overflow:hidden;text-overflow:ellipsis;min-width:0}
.mo-pc .a .p{margin-left:auto;font-family:var(--f-mono);color:var(--brass);flex:none}
.mo-pc .b{font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mo-pc .ck{position:absolute;right:4px;bottom:2px;font-size:10px;color:#7fe0a0;font-weight:800}
.mo-cvw{position:relative;flex:1;min-height:150px}
.mo-skip{position:absolute;right:8px;bottom:8px;z-index:2;min-height:44px;min-width:44px;display:none}
.mo-stats{flex:none;display:grid;grid-template-columns:repeat(5,1fr);gap:4px;padding:4px 8px 0}
.mo-sb{background:rgba(255,255,255,.05);border-radius:8px;padding:2px 5px 4px;min-width:0}
.mo-sb .l{font-size:11px;color:var(--muted);display:flex;justify-content:space-between;align-items:baseline;gap:2px;white-space:nowrap}
.mo-sb .l b{font-family:var(--f-mono);color:var(--ink);font-size:13px}
.mo-sb .bar{height:4px;border-radius:2px;background:rgba(255,255,255,.1);overflow:hidden;margin-top:2px}
.mo-sb .bar i{display:block;height:100%;transition:width .4s}
.mo-em{flex:none;display:flex;gap:10px;padding:5px 8px 0}
.mo-gg{flex:1;display:flex;align-items:center;gap:5px;font-size:11.5px;min-width:0;white-space:nowrap}
.mo-gg .seg{flex:1;display:flex;gap:2px;height:9px;min-width:0}
.mo-gg .seg i{flex:1;border-radius:2px;background:rgba(255,255,255,.1)}
.mo-gg b{font-family:var(--f-mono);font-size:12px}
.mo-hint{flex:none;font-size:12.5px;line-height:1.3;padding:4px 10px 2px;height:38px;box-sizing:border-box;overflow:hidden;color:var(--ink)}
.mo-hint b{color:var(--brass)}
.mo-cards{flex:none;display:flex;flex-direction:column;gap:5px;padding:2px 6px 8px}
.mo-row{display:grid;gap:4px}
.mo-cd{appearance:none;font:inherit;color:var(--ink);border:1px solid rgba(255,255,255,.12);background:var(--surface-2);border-radius:10px;min-height:46px;padding:3px 2px;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;position:relative;min-width:0;transition:transform .1s}
.mo-cd:active{transform:scale(.96)}
.mo-cd .n{font-size:11.5px;font-weight:700;white-space:nowrap;letter-spacing:-.4px}
.mo-cd .x{font-size:10.5px;color:var(--muted);white-space:nowrap;letter-spacing:-.3px}
.mo-cd.sel{border-color:var(--brass);background:#4a3a2a;box-shadow:0 0 0 1px var(--brass) inset}
.mo-cd:disabled{opacity:.38;cursor:default}
.mo-cd .up{position:absolute;top:-5px;right:-2px;background:var(--coral);color:#fff;font-size:9.5px;font-weight:800;border-radius:6px;padding:0 4px;line-height:15px}
.mo-cd.food{border-bottom:3px solid var(--ec)}
.mo-go{min-height:46px;font-size:15px;padding:0 6px}
`;

  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'mo' });
    const strip = h('div', { class: 'mo-strip' });
    const cvw = h('div', { class: 'mo-cvw' });
    const skipB = h('button', { class: 'btn sm mo-skip', text: '건너뛰기 ⏭' });
    const stats = h('div', { class: 'mo-stats' });
    const emRow = h('div', { class: 'mo-em' });
    const hint = h('div', { class: 'mo-hint' });
    const cards = h('div', { class: 'mo-cards' });
    cvw.append(skipB);
    wrap.append(strip, cvw, stats, emRow, hint, cards);
    root.append(style, wrap);
    const cv = U.canvas(cvw), ctx = cv.ctx;
    cv.cv.style.position = 'absolute'; cv.cv.style.left = '0'; cv.cv.style.top = '0';

    let st = null, fS = null, dead = false, busy = false, manual = -1, sel = -1, selKey = '';
    const sent = {}, timers = new Set(), floats = [];
    let Q = [], sc = null, msg = '';
    const pcol = (k) => (st && k >= st.n ? RVC[st.rv[k - st.n][2]] : api.players[k] ? api.players[k].color : '#e3ae45');
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms / sp()); timers.add(t); return t; };
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    const keyOf = (s, i) => s.d + ':' + i;
    function pending() {
      if (!st || st.ph !== 'c' || sc) return [];
      return (actor(st) || []).filter((i) => api.canAct(i) && !sent[keyOf(st, i)]);
    }
    const ctlSeat = () => { const p = pending(); return p.length ? p[0] : -1; };
    function viewSeat() {
      if (!st) return 0;
      if (manual >= 0 && manual < st.E) return manual;
      const c = ctlSeat(); if (c >= 0) return c;
      const m = api.mySeats(); return m.length ? m[0] : 0;
    }
    function send(seat, c) {
      if (!st || !legal(st, seat, c)) return;
      const k = keyOf(st, seat);
      sent[k] = 1; sel = -1; manual = -1;
      api.sfx('pop'); api.actAs(seat, { c });
      later(() => { if (st && keyOf(st, seat) === k && st.ch[seat] == null) { delete sent[k]; render(); } }, 3000);
      render();
    }

    /* ---------- 배경 (캐시) ---------- */
    let bg = null;
    function buildBg() {
      const W = cv.w, H = cv.h, dpr = cv.dpr || 1;
      bg = document.createElement('canvas'); bg.width = Math.max(1, W * dpr); bg.height = Math.max(1, H * dpr);
      const b = bg.getContext('2d'); b.scale(dpr, dpr);
      const gr = b.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#231a36'); gr.addColorStop(0.6, '#3a2a4a'); gr.addColorStop(1, '#2b2238');
      b.fillStyle = gr; b.fillRect(0, 0, W, H);
      let x = 12345; const r = () => ((x = (x * 16807) % 2147483647) / 2147483647);
      for (let j = 0; j < 40; j++) { b.fillStyle = 'rgba(255,240,210,' + (0.2 + r() * 0.5) + ')'; b.beginPath(); b.arc(r() * W, r() * H * 0.55, r() * 1.3 + 0.3, 0, 7); b.fill(); }
            b.fillStyle = '#2c4a3a'; b.beginPath(); b.moveTo(0, H * 0.7); b.quadraticCurveTo(W * 0.3, H * 0.58, W * 0.6, H * 0.68); b.quadraticCurveTo(W * 0.85, H * 0.74, W, H * 0.64); b.lineTo(W, H); b.lineTo(0, H); b.fill();
      const g2 = b.createLinearGradient(0, H * 0.74, 0, H); g2.addColorStop(0, '#2f6a45'); g2.addColorStop(1, '#1d4a32');
      b.fillStyle = g2; b.beginPath(); b.moveTo(0, H * 0.8); b.quadraticCurveTo(W * 0.5, H * 0.72, W, H * 0.8); b.lineTo(W, H); b.lineTo(0, H); b.fill();
      b.strokeStyle = '#7a5532'; b.lineWidth = 3;
      for (let j = 0; j < 6; j++) { const fx = 10 + j * 22; b.beginPath(); b.moveTo(fx, H * 0.8 - 22); b.lineTo(fx, H * 0.8 + 6); b.stroke(); }
      b.beginPath(); b.moveTo(4, H * 0.8 - 16); b.lineTo(124, H * 0.8 - 16); b.moveTo(4, H * 0.8 - 6); b.lineTo(124, H * 0.8 - 6); b.stroke();
      b.fillStyle = 'rgba(160,220,140,.25)';
      for (let j = 0; j < 30; j++) { const gx = r() * W, gy = H * 0.82 + r() * H * 0.16; b.fillRect(gx, gy, 1.5, 4); }
    }
    cv.onresize = () => { buildBg(); };
    buildBg();

    /* ---------- 글자 도우미 ---------- */
    const FD = '"Black Han Sans","IBM Plex Sans KR",sans-serif', FB = '"IBM Plex Sans KR",sans-serif', FM = '"IBM Plex Mono",monospace';
    function text(s, x, y, size, col, align, font, wt) {
      ctx.font = (wt || '700') + ' ' + size + 'px ' + (font || FB); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y);
    }
    function fitText(s, x, y, size, col, maxW, align, font) {
      ctx.font = '700 ' + size + 'px ' + (font || FB);
      let sz = size; while (sz > 8 && ctx.measureText(s).width > maxW) { sz -= 1; ctx.font = '700 ' + sz + 'px ' + (font || FB); }
      ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y);
    }
    function pill(x, y, w, hh, col) { ctx.fillStyle = col; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, hh, hh / 2); else ctx.rect(x, y, w, hh); ctx.fill(); }
    const hintEl = (s, k) => { if (k >= s.n) return -1; const af = s.af[k], mx = Math.max(...af); return mx > 0 ? af.indexOf(mx) : -1; };

    /* ---------- 장면 ---------- */
    function drawMain(now) {
      const W = cv.w, H = cv.h, s = fS || st;
      if (!s) return;
      if (s.ph === 'x' && !sc) { drawStand(now, 1); return; }
      const V = Math.min(viewSeat(), s.E - 1), m = mon(s, V);
      // 위 정보
      text((Math.min(s.d + 1, s.D)) + '일째', 12, 18, 20, '#f2e9d8', 'left', FD, '400');
      ctx.font = '400 20px ' + FD; const dw = ctx.measureText((Math.min(s.d + 1, s.D)) + '일째').width;
      text('/ ' + s.D + '일', 18 + dw, 19, 12, '#ab9fb8', 'left', FM);
      const ev = evoDays(s.D), cd = conDays(s.D), lines = [];
      const ne = ev.find((x) => x > s.d), ci = cd.findIndex((x) => x > s.d);
      const when = (x) => (x - s.d === 1 ? '오늘 밤' : (x - s.d - 1) + '일 뒤');
      if (ci >= 0) lines.push(['🏅 ' + SN[s.mt[ci]] + ' 대회 · ' + when(cd[ci]), SC[s.mt[ci]]]);
      if (ne) lines.push(['✨ 진화 · ' + when(ne), '#ffe39a']);
      lines.push(['🏆 결승 · ' + when(s.D), '#e3ae45']);
      lines.slice(0, 3).forEach((l, j) => fitText(l[0], 12, 40 + j * 16, 11.5, l[1], W * 0.55, 'left'));
      // 갈래 정보 (오른쪽 위)
      const rx = W - 10;
      if (m.e < 0) {
        if (V < s.n) {
          text('먹이 갈래', rx, 16, 11, '#ab9fb8', 'right');
          const af = s.af[V];
          for (let j = 0; j < 4; j++) { const yy = 32 + j * 15; text(EL[j].i + ' ' + af[j], rx, yy, 11.5, af[j] === Math.max(...af) && af[j] > 0 ? EL[j].c : '#cfc2dd', 'right', FM); }
        } else text('갈래 비밀', rx, 16, 11, '#ab9fb8', 'right');
      } else {
        text(EL[m.e].i + ' ' + EL[m.e].n + ' 갈래', rx, 16, 12, EL[m.e].c, 'right');
        text('강함 ▶ ' + EL[BEAT[m.e]].i + EL[BEAT[m.e]].n, rx, 33, 11, '#9fe6a0', 'right');
        text('약함 ◀ ' + EL[LOSE[m.e]].i + EL[LOSE[m.e]].n, rx, 48, 11, '#ff9a8a', 'right');
      }
      // 몬스터
      const gy = H * 0.8 + 6, S = Math.min(W * 0.6, (H - 70) * 0.78);
      if (m.e >= 0) { const gl = ctx.createRadialGradient(W / 2, gy, 4, W / 2, gy, S * 0.7); gl.addColorStop(0, EL[m.e].c + '55'); gl.addColorStop(1, EL[m.e].c + '00'); ctx.fillStyle = gl; ctx.fillRect(W / 2 - S, gy - S * 0.7, S * 2, S * 1.4); }
      ctx.save(); ctx.translate(W / 2, gy); drawMon(ctx, m, S, now, { hint: hintEl(s, V) }); ctx.restore();
      // 이름표
      const nm = formName(m.e, m.v, m.g), sub = nameOf(s, V) + ' · ' + (m.g ? m.g + '단계' : '아기') + (m.v >= 0 ? ' · ' + VN[m.v] : '');
      ctx.font = '700 13px ' + FB; const tw = Math.min(W - 20, Math.max(ctx.measureText(nm).width, 90) + 24);
      pill(W / 2 - tw / 2, H - 34, tw, 30, 'rgba(23,19,31,.78)');
      fitText(nm, W / 2, H - 25, 13, '#f2e9d8', tw - 14);
      fitText(sub, W / 2, H - 12, 10.5, pcol(V), tw - 14);
      // 떠오르는 글자
      for (let j = floats.length - 1; j >= 0; j--) {
        const f = floats[j], a = (now - f.t0) * sp() / 1500;
        if (a >= 1) { floats.splice(j, 1); continue; }
        if (a < 0) continue;
        ctx.globalAlpha = 1 - a * a;
        text(f.s, W / 2 + f.dx, gy - S * 0.55 - a * 40 + f.dy, 14, f.c, 'center', FB, '800');
        ctx.globalAlpha = 1;
      }
      if (msg && sc && sc.k === 'day') { ctx.font = '700 12px ' + FB; const mw = Math.min(W - 16, ctx.measureText(msg).width + 20); pill(W / 2 - mw / 2, gy - S * 0.92 - 40, mw, 24, 'rgba(23,19,31,.85)'); fitText(msg, W / 2, gy - S * 0.92 - 28, 12, '#ffe39a', mw - 10); }
    }
    function lineup(s, now, opt) {
      const W = cv.w, H = cv.h, E = s.E, cw = W / E;
      const S = Math.min(cw * 0.62, H * 0.38);
      const gy = opt.gy || H * 0.62;
      for (let k = 0; k < E; k++) {
        const m = opt.mon ? opt.mon(k) : mon(s, k), x = cw * (k + 0.5);
        let yo = 0, rot = 0;
        if (opt.jump && opt.jump(k)) { const p = opt.jump(k); yo = -Math.sin(p * Math.PI) * 30; rot = p * Math.PI * 2 * (opt.spin ? 1 : 0); }
        ctx.save(); ctx.translate(x, gy + yo); if (rot) { ctx.translate(0, -S * 0.3); ctx.rotate(rot); ctx.translate(0, S * 0.3); }
        drawMon(ctx, m, S, now, { ph: k * 1.7, hint: hintEl(s, k) }); ctx.restore();
        fitText(nameOf(s, k), x, gy + 14, 11.5, pcol(k), cw - 6);
        if (opt.sub) fitText(opt.sub(k), x, gy + 29, 10.5, '#cfc2dd', cw - 6);
        if (opt.extra) opt.extra(k, x, gy, cw, S);
      }
    }
    function banner(t1, t2, y) {
      const W = cv.w;
      pill(W / 2 - Math.min(W - 20, 260) / 2, y - 18, Math.min(W - 20, 260), t2 ? 46 : 34, 'rgba(23,19,31,.82)');
      fitText(t1, W / 2, y - 2, 18, '#e3ae45', W - 40, 'center', FD);
      if (t2) fitText(t2, W / 2, y + 17, 11.5, '#cfc2dd', W - 40);
    }
    function drawEvo(now, p) {
      const s = st, pre = sc.pre;
      const flash = p > 0.42 && p < 0.58 ? 1 - Math.abs(p - 0.5) / 0.08 : 0;
      lineup(s, now, {
        mon: (k) => (p < 0.5 ? mon(pre, k) : mon(s, k)),
        sub: (k) => (p < 0.5 ? '' : (() => { const m = mon(s, k); return formName(m.e, m.v, m.g); })()),
        extra: (k, x, gy, cw, S) => { if (p < 0.5) { ctx.globalAlpha = p * 1.6; ctx.fillStyle = '#fff6c0'; ctx.beginPath(); ctx.ellipse(x, gy - S * 0.35, S * 0.4 * p * 2, S * 0.45 * p * 2, 0, 0, 7); ctx.fill(); ctx.globalAlpha = 1; } },
      });
      if (flash) { ctx.fillStyle = 'rgba(255,250,220,' + flash + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
      banner('✨ 진화!', p < 0.5 ? '몬스터들이 빛나기 시작해요…' : '모습이 바뀌었어요', 30);
    }
    function drawContest(now, p) {
      const s = st, mc = sc.mc, W = cv.w, H = cv.h, mx = Math.max(...mc.sc, 1);
      banner('🏅 중간 대회 · ' + SN[mc.t] + ' 겨루기', SN[mc.t] + ' + 기분 + 운 · 이긴 상대마다 1점', 30);
      const fill = Math.min(1, p / 0.6);
      lineup(s, now, {
        gy: H * 0.66,
        jump: (k) => (p > 0.62 && mc.gn[k] === Math.max(...mc.gn) ? Math.min(1, (p - 0.62) / 0.2) : 0),
        sub: (k) => (p > 0.62 ? '+' + mc.gn[k] + '점' : ''),
        extra: (k, x, gy, cw, S) => {
          const by = gy - S * 0.95 - 8, bh = Math.max(20, by - 84), bw = Math.min(26, cw * 0.3);
          ctx.fillStyle = 'rgba(255,255,255,.08)'; ctx.fillRect(x - bw / 2, by - bh, bw, bh);
          const f = (mc.sc[k] / mx) * fill; ctx.fillStyle = SC[mc.t]; ctx.fillRect(x - bw / 2, by - bh * f, bw, bh * f);
          text(fill >= 1 ? mc.sc[k].toFixed(1) : (mc.sc[k] * fill).toFixed(1), x, by - bh - 9, 11, '#f2e9d8', 'center', FM);
          if (p > 0.62) { const r = mc.sc.filter((y) => y > mc.sc[k]).length; text(['🥇', '🥈', '🥉', ''][r] || '', x + bw / 2 + 10, by - 8, 16, '#fff'); }
        },
      });
    }
    function bTime(b) { return (b.ev.length * 470 + 1700) * (b.fast ? 0.55 : 1); }
    function drawBattle(now, tt) {
      const s = st, b = sc.b, W = cv.w, H = cv.h, A = b.a, B = b.bb, step = 470 * (b.fast ? 0.55 : 1), intro = 800 * (b.fast ? 0.55 : 1);
      const MA = mon(s, A), MB = mon(s, B);
      const tau = tt - intro, i = Math.floor(tau / step), f = tau >= 0 ? (tau % step) / step : 0;
      const hp = b.r.hp.slice(); let last = null;
      for (let j = 0; j < b.r.ev.length && j <= i; j++) { const e = b.r.ev[j]; if (j < i || f > 0.4) hp[1 - e[0]] -= e[1]; if (j === i) last = e; }
      const gy = H * 0.8, S = Math.min(W * 0.4, H * 0.5), xs = [W * 0.27, W * 0.73];
      const done = i >= b.r.ev.length;
      for (let k = 0; k < 2; k++) {
        const m = k ? MB : MA;
        let dx = 0, sh = 0, rot = 0;
        if (last && !done) { if (last[0] === k) dx = (f < 0.4 ? f / 0.4 : Math.max(0, 1 - (f - 0.4) / 0.4)) * W * 0.12; else if (f > 0.4 && f < 0.7 && !last[3]) sh = Math.sin(f * 80) * 4; else if (last[3] && f > 0.3 && f < 0.7) dx = -14; }
        if (done && b.r.w !== k) rot = 0;
        ctx.save(); ctx.translate(xs[k] + (k ? -dx : dx) + sh, gy);
        if (done && b.r.w !== k) ctx.globalAlpha = 0.55;
        drawMon(ctx, m, S, now, { flip: k === 1, ph: k * 2, rot });
        ctx.restore(); ctx.globalAlpha = 1;
        // HP 막대
        const bw = W * 0.4, bx = k ? W - 10 - bw : 10, by = 34;
        fitText(nameOf(s, k ? B : A), k ? W - 10 : 10, 14, 12, pcol(k ? B : A), bw, k ? 'right' : 'left');
        ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(bx, by, bw, 9);
        const fr = Math.max(0, hp[k]) / b.r.hp[k]; ctx.fillStyle = fr > 0.5 ? '#6fdc8c' : fr > 0.25 ? '#f2b84b' : '#ff6a4a';
        ctx.fillRect(k ? bx + bw * (1 - fr) : bx, by, bw * fr, 9);
        text((m.e >= 0 ? EL[m.e].i + ' ' : '') + Math.max(0, Math.round(hp[k])) + '/' + b.r.hp[k], k ? W - 10 : 10, by + 20, 11, '#cfc2dd', k ? 'right' : 'left', FM);
      }
      text('VS', W / 2, 40, 18, '#e3ae45', 'center', FD, '400');
      text('결승 대결 ' + (sc.bi + 1) + '/' + sc.bn, W / 2, 62, 10.5, '#ab9fb8');
      if (last && !done) {
        const k = last[0], o = 1 - k, mk = k ? MB : MA, mo2 = o ? MB : MA;
        const mv = mk.e >= 0 ? MOVE[mk.e] : '몸통 박치기';
        let t2 = '';
        if (last[3]) t2 = '휙! 피했어요';
        else { const tm = tmul(mk.e, mo2.e); t2 = (last[2] ? '급소! ' : '') + (tm > 1 ? '잘 통해요!' : tm < 1 ? '잘 안 통해요…' : ''); }
        fitText(mv + '!', W / 2, H * 0.3, 15, '#f2e9d8', W - 20);
        if (t2) fitText(t2, W / 2, H * 0.3 + 19, 12, last[3] ? '#9fd8ff' : '#ffe39a', W - 20);
        if (!last[3] && f > 0.4) { const a = (f - 0.4) / 0.6; ctx.globalAlpha = 1 - a; text('-' + last[1], xs[o], gy - S * 0.75 - a * 24, 18, last[2] ? '#ff5d5d' : '#fff', 'center', FD, '400'); ctx.globalAlpha = 1; }
      }
      if (done) { const wx = xs[b.r.w]; text('🏆 승리!', wx, gy - S * 0.95, 18, '#e3ae45', 'center', FD, '400'); fitText('+3점', wx, gy - S * 0.95 + 20, 12, '#ffe39a', W * 0.4); }
      if (i < 0) banner(nameOf(s, A) + ' vs ' + nameOf(s, B), (MA.e >= 0 ? EL[MA.e].i : '') + ' 대 ' + (MB.e >= 0 ? EL[MB.e].i : ''), H * 0.42);
    }
    function drawJudge(now, tt) {
      const s = st, E = s.E, step = 900, intro = 800, i = Math.floor((tt - intro) / step), f = ((tt - intro) % step) / step;
      banner('🎪 묘기 심사', '매력·지능·기분 · 앞선 상대마다 2점', 30);
      lineup(s, now, {
        gy: cv.h * 0.7, spin: true,
        jump: (k) => (k === i ? f : 0),
        sub: (k) => (k < i || (k === i && f > 0.5) ? '✨ ' + s.fj[k].toFixed(1) : ''),
        extra: (k, x, gy, cw, S) => {
          if (k === i) { const m = mon(s, k), tr = m.e >= 0 ? TRICK[m.e][Math.max(0, m.v)] : '데굴데굴 구르기'; fitText(tr, x, gy - S * 0.95 - 30, 11.5, '#ffe39a', cw - 4); }
          if (i >= E) { const r = s.fj.filter((y) => y > s.fj[k]).length; text(['🥇', '🥈', '🥉', ''][r] || '', x, gy - S * 0.95 - 20, 18, '#fff'); }
        },
      });
    }
    function drawStand(now, fin) {
      const s = st, W = cv.w, H = cv.h, ord = ranking(s);
      banner(fin ? '🏆 최종 순위' : '순위', s.n === 1 ? '도전자 3마리와 겨뤘어요' : '중간 대회 + 결승 대결 + 묘기 심사', 30);
      const top = 64, rh = Math.min(64, (H - top - 8) / s.E);
      ord.forEach((k, j) => {
        const y = top + j * rh, m = mon(s, k);
        pill(10, y + 2, W - 20, rh - 6, j === 0 ? 'rgba(227,174,69,.22)' : 'rgba(255,255,255,.06)');
        text(['🥇', '🥈', '🥉', '4'][j], 28, y + rh / 2, 16, '#fff');
        ctx.save(); ctx.translate(70, y + rh - 8); drawMon(ctx, m, rh * 0.95, now, { ph: k, still: true }); ctx.restore();
        fitText(nameOf(s, k), 110, y + rh / 2 - 8, 13, pcol(k), W - 190, 'left');
        fitText(formName(m.e, m.v, m.g), 110, y + rh / 2 + 9, 10.5, '#cfc2dd', W - 190, 'left');
        text(s.pt[k] + '점', W - 20, y + rh / 2, 16, '#e3ae45', 'right', FM, '800');
      });
    }
    function drawScene(now) {
      ctx.clearRect(0, 0, cv.w, cv.h);
      if (bg) ctx.drawImage(bg, 0, 0, cv.w, cv.h);
      if (!st) return;
      if (sc) {
        const tt = (now - sc.t0) * sp(), p = Math.min(1, tt / sc.dur);
        if (sc.k === 'day') drawMain(now);
        else { ctx.fillStyle = 'rgba(15,10,22,.45)'; ctx.fillRect(0, 0, cv.w, cv.h); }
        if (sc.k === 'evo') drawEvo(now, p);
        else if (sc.k === 'con') drawContest(now, p);
        else if (sc.k === 'intro') { lineup(st, now, { gy: cv.h * 0.72, sub: (k) => { const m = mon(st, k); return formName(m.e, m.v, m.g); } }); banner('🏆 결승 대회!', '모두와 한 번씩 자동 대결 → 묘기 심사', 30); }
        else if (sc.k === 'bat') drawBattle(now, tt);
        else if (sc.k === 'judge') drawJudge(now, tt);
        else if (sc.k === 'stand') drawStand(now, 1);
        return;
      }
      drawMain(now);
    }
    function startNext(now) {
      sc = Q.shift() || null;
      if (sc) {
        sc.t0 = now;
        if (sc.on) sc.on();
        skipB.style.display = sc.k === 'day' || sc.k === '_' ? 'none' : 'block';
        setBusy(true);
      } else { skipB.style.display = 'none'; fS = null; msg = ''; setBusy(false); render(); }
    }
    skipB.onclick = () => { api.sfx('click'); const rest = Q.filter((x) => x.k === 'stand'); Q = rest; startNext(performance.now()); };

    const stop = U.loop((dt, now) => {
      if (dead) return;
      if (sc && (now - sc.t0) * sp() >= sc.dur) startNext(now);
      drawScene(now);
    });

    /* ---------- 상태가 바뀌면 장면 만들기 ---------- */
    function queueFor(s, prev) {
      const Lt = s.last, now = performance.now();
      Q = [];
      const V = Math.min(viewSeat(), s.n - 1);
      fS = prev;
      Q.push({
        k: 'day', dur: 1500, on: () => {
          floats.length = 0;
          const r = Lt.r[V];
          if (r) {
            const parts = [];
            for (let q = 0; q < 5; q++) if (r[3 + q]) parts.push([(r[3 + q] > 0 ? '+' : '') + r[3 + q] + ' ' + SN[q], SC[q]]);
            if (r[8]) parts.push([(r[8] > 0 ? '+' : '') + r[8] + ' 기력', '#ffe39a']);
            if (r[9]) parts.push([(r[9] > 0 ? '+' : '') + r[9] + ' 기분', '#ff9db5']);
            parts.forEach((p, j) => floats.push({ s: p[0], c: p[1], t0: now, dx: (j % 2 ? 1 : -1) * 44, dy: -Math.floor(j / 2) * 22 }));
            msg = r[1] >= 0 ? '🧭 ' + exText(r[1]) : r[2] ? '⬆ 오늘의 UP 효과!' : '';
            if (r[1] >= 0 && api.canAct(V)) api.toast(exText(r[1]));
          }
          api.sfx(Lt.r.some((x) => x[0] >= 4 && x[0] <= 8) ? 'thud' : 'pop');
        },
      });
      if (Lt.ev) Q.push({ k: 'evo', dur: 2800, pre: prev, on: () => { fS = null; api.sfx('whoosh'); later(() => api.sfx('win'), 1300); api.buzz(60); } });
      else Q.push({ k: '_', dur: 0, on: () => { fS = null; } });
      if (Lt.mc) Q.push({ k: 'con', dur: 3600, mc: Lt.mc, on: () => { api.sfx('roll'); later(() => api.sfx('chip'), 2200); } });
      if (Lt.fin) {
        Q.push({ k: 'intro', dur: 1800, on: () => api.sfx('whoosh') });
        const P = pairs(s.E);
        P.forEach(([a, b], j) => {
          const fast = !(a < s.n && !api.players[a].ai) && !(b < s.n && !api.players[b].ai);
          const r = battle(mon(s, a), mon(s, b), bSeed(s, a, b));
          const bb = { a, bb: b, r, fast, ev: r.ev };
          Q.push({ k: 'bat', dur: bTime(bb), b: bb, bi: j, bn: P.length, on: () => api.sfx('whoosh') });
        });
        Q.push({ k: 'judge', dur: 800 + s.E * 900 + 1000, on: () => api.sfx('pop') });
        Q.push({ k: 'stand', dur: 2600, on: () => api.sfx('win') });
      }
      Q = Q.filter((x) => x.dur > 0 || x.k === '_');
      startNext(now);
    }

    /* ---------- DOM ---------- */
    function renderStrip() {
      const s = st;
      strip.style.gridTemplateColumns = 'repeat(' + s.E + ',1fr)';
      while (strip.children.length > s.E) strip.lastChild.remove();
      while (strip.children.length < s.E) {
        const k = strip.children.length;
        strip.append(h('button', { class: 'mo-pc', onclick: () => { manual = manual === k ? -1 : k; api.sfx('click'); render(); } }));
      }
      const V = viewSeat();
      for (let k = 0; k < s.E; k++) {
        const b = strip.children[k], m = mon(fS || s, k);
        b.className = 'mo-pc' + (k === V ? ' on' : '');
        b.innerHTML = '';
        b.append(
          h('div', { class: 'a' }, h('span', { class: 'dot', style: { '--c': pcol(k) } }), h('span', { class: 'nmx', text: nameOf(s, k) }), h('span', { class: 'p', text: s.pt[k] + '점' })),
          h('div', { class: 'b', text: (m.e >= 0 ? EL[m.e].i : '🥚') + ' ' + formName(m.e, m.v, m.g) }),
        );
        if (s.ph === 'c' && k < s.n && s.ch[k] != null) b.append(h('span', { class: 'ck', text: '✓' }));
      }
    }
    function renderStats() {
      const s = st, V = Math.min(viewSeat(), s.E - 1), m = mon(s, V);
      if (!stats.children.length) for (let q = 0; q < 5; q++) stats.append(h('div', { class: 'mo-sb' }, h('div', { class: 'l' }, h('span', { text: SN[q] }), h('b', { text: '0' })), h('div', { class: 'bar' }, h('i', { style: { background: SC[q] } }))));
      for (let q = 0; q < 5; q++) {
        const el = stats.children[q];
        el.querySelector('b').textContent = m.st[q];
        el.querySelector('i').style.width = Math.min(100, (m.st[q] / 70) * 100) + '%';
      }
      emRow.innerHTML = '';
      const gg = (lab, val, col, ic) => {
        const seg = h('div', { class: 'seg' });
        for (let j = 0; j < 10; j++) seg.append(h('i', { style: j < val ? { background: col } : {} }));
        return h('div', { class: 'mo-gg' }, h('span', { text: lab }), seg, h('b', { text: ic + val }));
      };
      const moIc = m.mo >= 7 ? '😊' : m.mo <= 2 ? '😢' : '🙂';
      emRow.append(gg('기력', m.en, '#ffd25a', ''), gg('기분', m.mo, '#ff8fc8', moIc));
    }
    function preview(s, i, c) {
      const C = CARDS[c], hot = s.hot === c, up = hot ? ' <b>UP!</b>' : '';
      if (C.k === 'f') return C.i + ' <b>' + C.n + '</b>: ' + SN[C.s] + ' +' + (2 + (hot ? 2 : 0)) + ' · ' + EL[C.e].i + EL[C.e].n + ' 갈래 +' + (3 + (hot ? 1 : 0)) + ' · 기력 +2 · 기분 ' + (s.lf[i] === C.e ? '−1 (연달아 질려요)' : '+1') + up;
      if (C.k === 't') { const mb = moodBonus(s.mo[i]); return C.i + ' <b>' + C.n + '</b>: ' + SN[C.s] + ' +' + (5 + mb + (hot ? 3 : 0)) + (mb > 0 ? ' (기분 좋아서 +2)' : mb < 0 ? ' (기분이 나빠 −2)' : '') + ' · ' + SN[C.b] + ' +1 · 기력 −3 · 기분 −1' + up; }
      if (C.k === 'r') return '😴 <b>휴식</b>: 기력 +5 · 기분 +2';
      return '🧭 <b>탐험</b>: 기력 −2 · 기분 +1 · 무작위 사건(열매·능력 UP·가끔 소나기)';
    }
    let cardEls = null, goB = null;
    function buildCards() {
      cards.innerHTML = '';
      const r1 = h('div', { class: 'mo-row', style: { gridTemplateColumns: 'repeat(4,1fr)' } });
      const r2 = h('div', { class: 'mo-row', style: { gridTemplateColumns: 'repeat(5,1fr)' } });
      const r3 = h('div', { class: 'mo-row', style: { gridTemplateColumns: '1fr 1fr 1.5fr' } });
      cardEls = CARDS.map((C, c) => {
        const sub = C.k === 'f' ? EL[C.e].i + ' ' + SN[C.s] + '+2' : C.k === 't' ? SN[C.s] + '+5' : C.k === 'r' ? '기력+5' : '무작위';
        const b = h('button', { class: 'mo-cd' + (C.k === 'f' ? ' food' : ''), style: C.k === 'f' ? { '--ec': EL[C.e].c } : {}, onclick: () => pick(c) },
          h('span', { class: 'n', text: (C.k === 't' ? '' : C.i + ' ') + C.n }), h('span', { class: 'x', text: (C.k === 't' ? C.i + ' ' : '') + sub }));
        (C.k === 'f' ? r1 : C.k === 't' ? r2 : r3).append(b);
        return b;
      });
      goB = h('button', { class: 'btn primary mo-go', text: '결정', onclick: () => { const c = ctlSeat(); if (c >= 0 && sel >= 0) send(c, sel); } });
      r3.append(goB);
      cards.append(r1, r2, r3);
    }
    function pick(c) {
      const seat = ctlSeat();
      if (seat < 0) return;
      if (!legal(st, seat, c)) { api.toast('기력이 모자라요 (훈련 3 · 탐험 2)'); api.buzz(30); return; }
      if (sel === c) { send(seat, c); return; }       // 같은 카드 두 번 = 결정
      sel = c; selKey = keyOf(st, seat); manual = -1; api.sfx('tick'); render();
    }
    function renderCards() {
      const s = st, seat = ctlSeat();
      if (seat < 0 || selKey !== keyOf(s, seat)) sel = -1;
      CARDS.forEach((C, c) => {
        const b = cardEls[c];
        b.disabled = seat < 0 || !legal(s, seat, c);
        b.classList.toggle('sel', sel === c);
        let up = b.querySelector('.up');
        if (s.hot === c && s.ph === 'c') { if (!up) b.append(h('span', { class: 'up', text: 'UP' })); } else if (up) up.remove();
      });
      const multi = api.mySeats().length >= 2;
      goB.disabled = seat < 0 || sel < 0;
      goB.textContent = seat < 0 ? (s.ph === 'x' ? '대회 끝' : '기다려요') : multi ? '결정 · ' + (api.players[seat] ? api.players[seat].name : '') : '결정 ✓';
    }
    function renderHint() {
      const s = st, seat = ctlSeat();
      if (s.ph === 'x') { hint.innerHTML = '🏆 결승 대회가 끝났어요!'; return; }
      if (sc && sc.k !== 'day') { hint.innerHTML = '대회 진행 중… 「건너뛰기」로 바로 결과를 볼 수 있어요.'; return; }
      if (seat >= 0) {
        if (sel >= 0) { hint.innerHTML = preview(s, seat, sel); return; }
        const who = api.mySeats().length >= 2 ? '<b>' + (api.players[seat] ? api.players[seat].name : '') + '</b> ' : '';
        hint.innerHTML = who + '오늘 할 일을 골라요. ' + (s.en[seat] < TR_EN ? '기력이 모자라면 <b>휴식</b>이나 <b>먹이</b>!' : '<b>UP</b> 카드는 오늘 효과가 더 커요.');
        return;
      }
      const done = s.ch.filter((x) => x != null).length;
      if (sc && sc.k === 'day' && s.last && s.last.r) {
        const V = Math.min(viewSeat(), s.n - 1), r = s.last.r[V];
        if (r) { hint.innerHTML = nameOf(s, V) + '의 어제: ' + CARDS[r[0]].i + ' ' + CARDS[r[0]].n + (r[1] >= 0 ? ' — ' + exText(r[1]) : ''); return; }
      }
      hint.innerHTML = api.mySeats().length ? '다른 주인들이 고르는 중… (' + done + '/' + s.n + ')' : '몬스터 주인들이 고르는 중… (' + done + '/' + s.n + ')';
    }
    function render() {
      if (!st || dead) return;
      renderStrip(); renderStats(); renderCards(); renderHint();
    }
    buildCards();

    return {
      update(state, prev) {
        st = state;
        if (prev && prev !== state && state.last && prev.last && state.last.id !== prev.last.id) { manual = -1; sel = -1; queueFor(state, prev); }
        else if (prev && prev !== state && state.ch && prev.ch) {
          for (let i = 0; i < state.n; i++) if (state.ch[i] != null && prev.ch[i] == null && !api.canAct(i)) api.sfx('tick');
        }
        render();
      },
      destroy() {
        dead = true; stop();
        for (const t of timers) clearTimeout(t);
        if (busy) api.setBusy(false);
        cv.destroy(); wrap.remove(); style.remove();
      },
    };
  }

  /* ---------- 도감 (codex): FORMS·CARDS·EX·BEAT 등 데이터 표에서 자동으로 만들어요 ---------- */
  const CX_CSS = `
.mo-cx-g{margin:6px 0 0;font-size:16px;font-weight:700;display:flex;align-items:center;gap:6px}
.mo-cx-st{font-size:12px;color:var(--muted);margin:2px 0 -2px}
.mo-cx-3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}
.mo-cx-c{display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 4px;border-radius:12px;background:var(--surface);text-align:center;min-width:0}
.mo-cx-c b{font-size:12.5px;line-height:1.3;word-break:keep-all}
.mo-cx-c canvas,.mo-cx-r canvas{flex:none;border-radius:10px;background:var(--surface-2)}
`;
  function monCanvas(m, px) {
    const cv = document.createElement('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(px * dpr); cv.height = Math.round(px * dpr);
    cv.style.width = px + 'px'; cv.style.height = px + 'px';
    const c = cv.getContext('2d');
    c.scale(dpr, dpr); c.translate(px * 0.46, px * 0.93);
    const g = m.e < 0 ? 0 : m.g, k = [0.55, 0.7, 0.85, 1][g];
    try { drawMon(c, m, (px * 0.72) / k, 1000, { still: true }); } catch (e) { /* 그림 실패해도 도감은 열려요 */ }
    return cv;
  }
  function codex(el) {
    const h = L.h, ED = [10, 15, 20].map((D) => D + '일: ' + evoDays(D).join('·') + '일째 밤').join(' / ');
    const CD = [10, 15, 20].map((D) => D + '일: ' + conDays(D).join('·') + '일째').join(' / ');
    const sign = (x) => (x > 0 ? '+' + x : '−' + -x);
    const VC = ['힘+체력이 가장 높으면 (속도+지능, 매력×2보다)', '속도+지능이 가장 높으면', '매력×2가 가장 높으면'];
    const row = (ic, name, tag, desc) => h('div', { class: 'cx-row mo-cx-r' },
      typeof ic === 'string' ? h('span', { class: 'cx-ic', text: ic }) : ic,
      h('div', { class: 'cx-tx' }, h('div', { class: 'cx-nm' }, h('b', { text: name }), tag ? h('span', { class: 'cx-tag', text: tag }) : null),
        ...[].concat(desc || []).map((t) => h('div', { class: 'cx-d', text: t }))));
    const note = (t) => h('p', { class: 'note', style: { margin: 0 }, text: t });
    const card = (m, name, tag) => h('div', { class: 'mo-cx-c' }, monCanvas(m, 58), h('b', { text: name }), h('span', { class: 'cx-tag', text: tag }));
    const tot = 3 + EX.reduce((a, x) => a + x.w, 0), pc = (w) => (Math.round((w / tot) * 1000) / 10) + '%';
    const foodOf = (e) => CARDS.find((C) => C.k === 'f' && C.e === e);
    const secs = [
      { h: '진화 모습', n: 1 + FORMS.length * 7, f(p) {
        p.append(note('진화는 3번, 정해진 날 밤에 일어나요(' + ED + '). 갈래는 1번째 진화 때 정해지고 바뀌지 않아요.'),
          note('2·3번째 진화의 모습은 그날 밤 능력치로 정해져요. 튼튼형: ' + VC[0] + ' · 날쌘형: ' + VC[1] + ' · 멋쟁이형: ' + VC[2] + '.'));
        p.append(row(monCanvas({ e: -1, g: 0, v: -1, mo: 7 }, 58), BABY, '아기', '알에서 막 깬 모습. 1번째 진화 전까지 상성이 없어요.'));
        FORMS.forEach((F, e) => {
          const fd = foodOf(e);
          p.append(h('div', { class: 'mo-cx-g', style: { color: EL[e].c } }, h('span', { text: EL[e].i + ' ' + EL[e].n + ' 갈래' })));
          p.append(row(monCanvas({ e, g: 1, v: -1, mo: 7 }, 58), F[0], '1단계',
            '1번째 진화 때 ' + EL[e].n + ' 갈래 점수가 가장 높으면(같으면 무작위). ' + fd.i + ' ' + fd.n + ' 먹이·' + EL[e].n + ' 열매로 쌓여요.'));
          for (let g = 2; g <= 3; g++) {
            p.append(h('div', { class: 'mo-cx-st', text: g + '단계 — ' + g + '번째 진화 때 능력치로' }));
            p.append(h('div', { class: 'mo-cx-3' }, ...F[g - 1].map((nm, v) => card({ e, g, v, mo: 7 }, nm, VN[v]))));
          }
        });
      } },
      { h: '하루 카드', n: CARDS.length, f(p) {
        p.append(note('매일 1장. 「UP」 카드는 그날 효과가 더 커요. 기력·기분은 0~10. 기분 7 이상이면 훈련 +2, 2 이하면 −2.'));
        CARDS.forEach((C) => {
          let tag = '', d = '';
          if (C.k === 'f') { tag = '먹이 · ' + EL[C.e].i + EL[C.e].n; d = SN[C.s] + ' +2 · ' + EL[C.e].n + ' 갈래 +3 · 기력 +2 · 기분 +1 (같은 먹이 연달아 −1). UP: ' + SN[C.s] + ' +4, 갈래 +4.'; }
          else if (C.k === 't') { tag = '훈련 · 기력 ' + TR_EN; d = SN[C.s] + ' +5 · ' + SN[C.b] + ' +1 · 기력 −' + TR_EN + ' · 기분 −1. UP: ' + SN[C.s] + ' +8. 기력 ' + TR_EN + ' 이상일 때만.'; }
          else if (C.k === 'r') { tag = '쉬기'; d = '기력 +5 · 기분 +2.'; }
          else { tag = '기력 ' + EX_EN; d = '기력 −' + EX_EN + ' · 기분 +1, 그리고 탐험 사건 하나(「탐험 사건」 탭). 기력 ' + EX_EN + ' 이상일 때만.'; }
          p.append(row(C.i, C.n, tag, d));
        });
      } },
      { h: '탐험 사건', n: 4 + EX.length, f(p) {
        p.append(note('🧭 탐험을 고르면 아래 중 하나가 무작위로 일어나요(확률은 한 번 탐험 기준).'));
        EL.forEach((E, e) => p.append(row(E.i, exText(e), pc(0.75), E.n + ' 갈래 +3 · 기력 +1')));
        EX.forEach((x) => {
          const a = [];
          if (x.d) { if (x.d.every((v) => v === x.d[0])) a.push('모든 능력 ' + sign(x.d[0])); else x.d.forEach((v, q) => { if (v) a.push(SN[q] + ' ' + sign(v)); }); }
          if (x.m) a.push('기분 ' + sign(x.m));
          if (x.en) a.push('기력 ' + sign(x.en));
          const ic = x.en ? '🌀' : x.m < 0 ? '🌧️' : x.d && x.d.every((v) => v) ? '💎' : '✨';
          p.append(row(ic, x.t, pc(x.w), a.join(' · ')));
        });
      } },
      { h: '대회·상성', n: 0, f(p) {
        p.append(note('상성: 💧물 → 🔥불 → 🌿풀 → ⚡번개 → 💧물 (앞이 뒤를 이겨요). 아기는 상성이 없어요.'));
        EL.forEach((E, e) => p.append(row(E.i, E.n + ' 갈래', '기술 「' + MOVE[e] + '」',
          [EL[BEAT[e]].i + EL[BEAT[e]].n + '에게 공격 ×' + tmul(e, BEAT[e]) + ' · ' + EL[LOSE[e]].i + EL[LOSE[e]].n + '에게 ×' + tmul(e, LOSE[e]), '묘기: ' + TRICK[e].map((t, v) => VN[v] + ' ' + t).join(' · ')])));
        p.append(row('🏅', '중간 대회 (2번)', '이긴 상대마다 1점', [CD + '.', '종목(능력 하나)은 처음부터 공개. 점수 = 그 능력 + 기분 + 운(0~6).']));
        p.append(row('🏆', '결승 대결', '이길 때마다 3점', ['모든 상대와 한 번씩 자동 대결.',
          '체력 = 30 + 체력×1.5 · 공격 = 5 + 힘×0.4 (기분 7↑ ×1.1, 2↓ ×0.9)',
          '공격 빈도 = 10 + 속도×0.3 · 피하기 = 2% + (속도+지능)×0.25% (최대 30%)',
          '급소 = 4% + 지능×0.5% (최대 30%, 피해 ×1.5) · 상성 ×1.4 / ×0.75']));
        p.append(row('🎪', '묘기 심사', '앞선 상대마다 2점', ['매력 + 지능×0.4 + 속도×0.2 + 기분×2 + 진화 단계×3 + 운(0~8).']));
        p.append(row('⚖️', '동점', '', '점수가 같으면 능력치 합이 높은 쪽이 앞서요.'));
        RVN.forEach((nm, t) => p.append(row(['🌾', '🏞️', '⛰️'][t], nm, '혼자 할 때 도전자',
          '하루에 능력치 합이 약 ' + RRATE[t] + '씩 자라요. 많이 키우는 능력: ' + RW[t].map((w, q) => [w, q]).sort((a, b) => b[0] - a[0]).slice(0, 2).map(([, q]) => SN[q]).join('·') + '. 갈래는 판마다 무작위.')));
      } },
    ];
    const tabs = h('div', { class: 'chips' }), pane = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    const show = (k) => {
      pane.innerHTML = '';
      [...tabs.children].forEach((b, i) => b.classList.toggle('on', i === k));
      secs[k].f(pane);
    };
    secs.forEach((sec, k) => tabs.append(h('button', { class: 'btn sm', text: sec.h + (sec.n ? ' ' + sec.n : ''), onclick: () => show(k) })));
    el.append(h('style', { text: CX_CSS }), tabs, pane);
    show(0);
  }

  L.register({
    id: 'monster', name: '몬스터 키우기 대회', tag: '육성 대회', cat: '파티',
    blurb: '알에서 깬 몬스터를 정해진 날 수 동안 먹이·훈련·휴식·탐험으로 키워요. 먹이와 훈련에 따라 불·물·풀·번개 갈래로 진화하고, 대회 날 자동 대결과 묘기 심사로 우승을 가려요.',
    tint: '#2f5a2a',
    icon: '<path d="M12 48c0-20 7-34 16-34s16 14 16 34z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linejoin="round"/><path d="M19 19l-6-9 11 5zM37 19l6-9-11 5z" fill="currentColor"/><circle cx="23" cy="31" r="3.5" fill="currentColor"/><circle cx="33" cy="31" r="3.5" fill="currentColor"/><path d="M23 39q5 4 10 0" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><path d="M6 50h44" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M47 10l2 4 4 1-4 2-2 4-2-4-4-1 4-2z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, fixedOrder: true, aiDelay: 900,
    options: [
      { id: 'days', label: '키우는 날', choices: [{ v: 10, label: '10일 (짧게)' }, { v: 15, label: '15일' }, { v: 20, label: '20일 (길게)' }], def: 15 },
    ],
    quick: [
      '알에서 깬 몬스터를 정해진 날(15일) 동안 키워요. 매일 모두 동시에 카드 1장을 골라요.',
      '먹이는 갈래(🔥불·💧물·🌿풀·⚡번개)를 정하고, 훈련은 능력치를 올려요. 기력이 떨어지면 쉬어요.',
      '중간 대회 2번과 마지막 결승(자동 대결 + 묘기 심사)에서 점수를 가장 많이 모으면 우승!',
    ],
    rules: [
      { h: '목표', p: [
        '아기 몬스터를 키워 대회에서 점수를 가장 많이 모으면 우승이에요.',
        '혼자 하면 도전자 몬스터 3마리(들판·호숫가·산꼭대기)와 겨뤄요. 최종 1등이면 별 3개, 2등 2개, 3등 1개.'] },
      { h: '하루에 할 일', p: [
        '매일 모두가 동시에 카드 1장을 골라요. 카드를 누르면 무엇이 오르는지 아래에 미리 나오고, 「결정」(또는 같은 카드 한 번 더)으로 정해요.',
        '🍽 먹이(윗줄): 능력 +2, 그 먹이의 갈래 +3, 기력 +2, 기분 +1. 같은 먹이를 이틀 연달아 먹으면 질려서 기분 −1.',
        '💪 훈련(가운뎃줄): 능력 +5(옆 능력 +1), 기력 −3, 기분 −1. 기분이 7 이상이면 +2 더, 2 이하면 −2.',
        '😴 휴식: 기력 +5, 기분 +2.  🧭 탐험: 기력 −2, 기분 +1, 그리고 무작위 사건(열매·능력 UP·진화의 돌, 가끔 소나기나 길 잃기).',
        '「UP」 표시 카드는 그날 효과가 더 커요(훈련 +3, 먹이 +2). 기력은 0~10, 기분은 0~10이에요.'] },
      { h: '진화', p: [
        '진화는 정해진 날 밤에 3번 일어나요(15일이면 3·7·11일째 밤). 위쪽에 「✨ 진화 · 1일 뒤」처럼 나와요.',
        '1번째 진화: 먹이로 쌓은 갈래 점수가 가장 높은 갈래가 돼요. 🔥불꼬리 도마뱀 · 💧물방울 물범 · 🌿이끼 거북 · ⚡찌릿귀 여우.',
        '2·3번째 진화: 그때 능력치로 모습이 정해져요. 힘+체력이 높으면 튼튼형(뿔·엄니·바위), 속도+지능이면 날쌘형(날개), 매력이 높으면 멋쟁이형(왕관·꽃·별빛).',
        '아기까지 모두 29가지 모습(갈래 4 × 1단계 1 + 2·3단계 각 3)이 있어요. 갈래는 한 번 정해지면 바뀌지 않아요.'] },
      { h: '갈래 상성', p: [
        '💧물 → 🔥불 → 🌿풀 → ⚡번개 → 💧물 (화살표 앞이 뒤를 이겨요).',
        '강한 상대에게는 공격이 1.4배, 약한 상대에게는 0.75배예요. 아기 몬스터는 상성이 없어요.'] },
      { h: '점수', p: [
        '🏅 중간 대회(2번, 종목은 처음부터 공개): 그 능력 + 기분 + 약간의 운. 이긴 상대마다 1점.',
        '🏆 결승 대결: 모든 상대와 한 번씩 자동 대결해요. 힘=공격, 체력=체력, 속도=자주 공격·피하기, 지능=급소·피하기. 이길 때마다 3점.',
        '🎪 묘기 심사: 매력이 가장 중요하고, 지능·속도·기분·진화 단계도 조금씩. 앞선 상대마다 2점.',
        '점수가 같으면 능력치 합이 높은 쪽이 앞서요.'] },
      { h: '예시', p: [
        '기력 4, 기분 7인 날 「달리기」(UP)를 고르면 → 속도 +5 +2(기분) +3(UP) = +10, 체력 +1, 기력 1, 기분 6.',
        '다음 날은 기력이 1이라 훈련을 못 해요 → 「휴식」으로 기력 6, 기분 8. 그다음 훈련은 다시 +2 보너스!'] },
      { h: '조작', p: [
        '카드를 눌러 고르고 「결정」. 위의 이름 칸을 누르면 다른 몬스터를 구경할 수 있어요(한 번 더 누르면 돌아와요).',
        '대회 장면은 「건너뛰기」로 바로 결과를 볼 수 있어요. 숨긴 정보가 없어 한 폰으로 돌려 해도 돼요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 어려움은 기분·기력을 잘 챙기고 중간 대회 종목과 상성까지 노려요.'] },
    ],
    tutorial: [
      { sel: '.mo-cvw', text: '가운데가 내 몬스터예요. 왼쪽 위에 오늘 날짜와 다음 진화·중간 대회·결승 날이 나와요.' },
      { sel: '.mo-stats', text: '능력치 5가지예요. 힘·체력·속도·지능은 결승 대결에, 매력은 묘기 심사에 좋아요.' },
      { sel: '.mo-em', text: '기력과 기분이에요. 훈련은 기력 3이 들고, 기분이 7 이상이면 훈련 효과가 +2!' },
      { sel: '.mo-cards', text: '매일 카드 1장을 골라요. 윗줄 먹이는 갈래(불·물·풀·번개)를, 가운뎃줄 훈련은 능력치를 키워요. UP 카드는 오늘 효과가 더 커요.' },
      { sel: '.mo-go', text: '카드를 누르면 무엇이 오르는지 위에 미리 보여요. 「결정」을 누르면 오늘 할 일이 정해져요.' },
      { sel: '.mo-strip', text: '위 칸을 누르면 다른 몬스터를 구경할 수 있어요. 점수는 중간 대회와 결승에서 모아요.' },
    ],
    codex,
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { battle, mon, legal, evoDays, conDays, ranking, formName, CARDS },
  });
})();
