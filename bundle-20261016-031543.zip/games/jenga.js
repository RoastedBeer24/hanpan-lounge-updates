/* 블록 탑 빼기 — 18층×3개 나무 블록 탑에서 하나씩 빼서 맨 위에 올리는 파티 게임.
   결정적 물리 모델(+ − × ÷ √ 만 사용, 고정 스텝 1/240 s):
   · 하중 분배: 층마다 위쪽 탑을 강체 판으로 보고, 블록마다 다른 두께(시드)를 탄성 받침으로 풀어 블록별 하중 f를 구한다
     → 하중을 거의 안 받는 블록은 헐겁고, 많이 받는 블록은 빡빡하다.
   · 빼기: 손가락 목표 위치(기록된 프로필)와 블록을 스프링으로 잇고, 아래·위 접촉면의 쿨롱 마찰(정지/운동)을
     투영 가우스-자이델로 푼다. 위층 덩어리는 나머지 블록들과 탄성 전단+미끄럼으로 이어져 있어, 하중 큰 블록을
     세게 당기면 위층이 같이 끌려간다.
   · 흔들림/붕괴: 모든 층 경계면의 지지 사각형과 그 위 무게중심으로 축별 임계각 α를 구하고, 가장 약한 경계면을
     경첩으로 하는 하우스너 록킹(θ'' = −p²(α−|θ|)) + 탄성 떨림으로 기울기를 적분한다. |θ|가 α를 넘으면 붕괴.
   apply는 끝까지(정지 또는 붕괴) 시뮬레이션하고 last={id,k,pre,a}를 남기며, 뷰는 같은 Sim으로 재생한다.
   붕괴 후 블록이 흩어지는 장면은 뷰 전용 강체 시뮬레이션. 단위: cm·s, 질량은 블록 1개 ≈ 1. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- constants ---------- */
  const H = 1.5, BL = 7.5, BW = 2.5, HL = 3.75, HW = 1.25, NL0 = 18, NB = 54;
  const G = 981, DT = 1 / 240, SPS = 12;              // physics step; profile sample = 12 steps = 0.05 s
  const KF = 16000, CF = 2 * Math.sqrt(KF), FMAX = 26000; // finger ↔ block spring (per cm of lead), damping, strongest push
  const KS = 6000, MUR = 0.65;                        // upper part shear stiffness, friction against the other blocks
  const TV = 40;                                      // thickness spread, in "block weights" of compression
  const VSN = 14;                                      // cm/s: sliding speed where friction snag becomes strong
  const TE = 0.003, DAMP = 0.9, REST = 0.8;           // elastic tremble range (rad), damping, rocking impact loss
  const QSTEP = 0.25, QMAX = 51, PMAX = 600;          // profile: 0.25 cm steps, max 12.75 cm, ≤ 30 s
  const COMMIT = 1.0;                                 // pulled further than this → you must finish that block
  const TMAX = 80;                                    // safety cap of turns on one tower (practically unreachable)
  const ALPH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  const IDC = ALPH + '0123456789';
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* ---------- seeded block properties ---------- */
  function hash(a, b) {
    let h = Math.imul((a | 0) ^ 0x9e3779b9, 0x85ebca6b) ^ Math.imul((b | 0) + 0x632be5ab, 0xc2b2ae35);
    h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d); h ^= h >>> 12; h = Math.imul(h, 0x297a2d39); h ^= h >>> 15;
    return (h >>> 0) / 4294967296;
  }
  const propCache = {};
  function props(seed) {
    if (propCache[seed]) return propCache[seed];
    const P = [];
    for (let id = 0; id < NB; id++) {
      const r = (k) => hash(seed, id * 8 + k);
      P.push({ t: (r(0) - 0.5) * 2 * TV, mu: 0.3 + 0.18 * r(1), m: 0.97 + 0.06 * r(2), tone: r(3), dl: (r(4) - 0.5) * 0.12, dw: r(5) });
    }
    const keys = Object.keys(propCache); if (keys.length > 6) delete propCache[keys[0]];
    return (propCache[seed] = P);
  }

  /* ---------- tower encoding: L = 3 chars per level (block id or '.'), S = level shifts ×100 ---------- */
  function decode(pre) {
    const n = pre.L.length / 3, lv = [];
    for (let i = 0; i < n; i++) {
      const b = [];
      for (let k = 0; k < 3; k++) { const ch = pre.L[i * 3 + k]; b.push(ch === '.' ? -1 : IDC.indexOf(ch)); }
      lv.push({ sx: (pre.S[2 * i] || 0) / 100, sy: (pre.S[2 * i + 1] || 0) / 100, b });
    }
    return lv;
  }
  function encode(lv) {
    let n = lv.length; while (n && lv[n - 1].b.every((x) => x < 0)) n--;
    let s = ''; const S = [];
    for (let i = 0; i < n; i++) { for (const id of lv[i].b) s += id < 0 ? '.' : IDC[id]; S.push(Math.round(lv[i].sx * 100), Math.round(lv[i].sy * 100)); }
    return { L: s, S };
  }
  function initialTower(seed) {
    const lv = [];
    for (let i = 0; i < NL0; i++) lv.push({ sx: Math.round((hash(seed, 900 + i) - 0.5) * 8) / 100, sy: Math.round((hash(seed, 950 + i) - 0.5) * 8) / 100, b: [i * 3, i * 3 + 1, i * 3 + 2] });
    return encode(lv);
  }
  const cloneLv = (lv) => lv.map((v) => ({ sx: v.sx, sy: v.sy, b: v.b.slice() }));
  function topInfo(lv) {
    let top = lv.length - 1; while (top >= 0 && lv[top].b.every((x) => x < 0)) top--;
    const full = top >= 0 && lv[top].b.every((x) => x >= 0);
    return { top, full, T: full ? top : top - 1 };   // blocks may be pulled from levels < T
  }
  function findBlock(lv, id) {
    for (let i = 0; i < lv.length; i++) { const k = lv[i].b.indexOf(id); if (k >= 0) return [i, k]; }
    return null;
  }
  function legalBlocks(lv) {
    const T = topInfo(lv).T, out = [];
    for (let i = 0; i < T; i++) for (const id of lv[i].b) if (id >= 0) out.push(id);
    return out;
  }
  function legalSlots(lv) {
    const ti = topInfo(lv);
    if (ti.full || ti.top < 0) return [0, 1, 2];
    return [0, 1, 2].filter((k) => lv[ti.top].b[k] < 0);
  }
  function placeLevel(lv) { const ti = topInfo(lv); return ti.full ? ti.top + 1 : ti.top; }
  function placeBlock(lv, id, slot, seed) {
    const ti = topInfo(lv);
    lv.length = ti.top + 1;
    if (ti.full) {
      const v = lv[ti.top];
      lv.push({ sx: v.sx + (hash(seed, 3000 + ti.top) - 0.5) * 0.12, sy: v.sy + (hash(seed, 3100 + ti.top) - 0.5) * 0.12, b: [-1, -1, -1] });
    }
    lv[lv.length - 1].b[slot] = id;
  }
  function centerXY(lv, i, k) {
    const v = lv[i], off = (k - 1) * BW;
    return i % 2 === 0 ? [v.sx, v.sy + off] : [v.sx + off, v.sy];
  }

  /* ---------- statics: support rectangles, centre of mass, critical tilt per direction ---------- */
  // mv (optional): the block being pulled {l,k,ds,du,ax,out}: ds = its displacement, du = the upper part's displacement (along ax)
  function analyze(lv, P, mv) {
    const n = lv.length, R = [];
    let top = -1;
    for (let i = 0; i < n; i++) {
      const rs = [];
      for (let k = 0; k < 3; k++) {
        const id = lv[i].b[k]; if (id < 0) continue;
        let o = 0;
        if (mv) { if (i === mv.l && k === mv.k) { if (mv.out) continue; o = mv.ds; } else if (i > mv.l) o = mv.du; }
        const c = centerXY(lv, i, k);
        if (mv && mv.ax === 0) c[0] += o; else if (mv) c[1] += o;
        const r = i % 2 === 0 ? [c[0] - HL, c[0] + HL, c[1] - HW, c[1] + HW] : [c[0] - HW, c[0] + HW, c[1] - HL, c[1] + HL];
        r.push(P[id].m, c[0], c[1]); rs.push(r);
      }
      R.push(rs); if (rs.length) top = i;
    }
    const crit = [0, 1, 2, 3].map(() => ({ a: 9, i: 0, h: 1, M: 1, R: 4, e: 0 }));
    let M = 0, Sx = 0, Sy = 0, Sz = 0, bad = -1;
    for (let i = top; i >= 0; i--) {
      const rs = R[i];
      for (const r of rs) { const m = r[4]; M += m; Sx += m * r[5]; Sy += m * r[6]; Sz += m * (i * H + H / 2); }
      if (!rs.length) { bad = i; break; }
      let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
      if (i === 0) for (const a of rs) { if (a[0] < x0) x0 = a[0]; if (a[1] > x1) x1 = a[1]; if (a[2] < y0) y0 = a[2]; if (a[3] > y1) y1 = a[3]; }
      else for (const a of rs) for (const b of R[i - 1]) {
        const ax0 = a[0] > b[0] ? a[0] : b[0], ax1 = a[1] < b[1] ? a[1] : b[1], ay0 = a[2] > b[2] ? a[2] : b[2], ay1 = a[3] < b[3] ? a[3] : b[3];
        if (ax1 - ax0 > 0.05 && ay1 - ay0 > 0.05) { if (ax0 < x0) x0 = ax0; if (ax1 > x1) x1 = ax1; if (ay0 < y0) y0 = ay0; if (ay1 > y1) y1 = ay1; }
      }
      if (x1 < x0) { bad = i; break; }
      const cx = Sx / M, cy = Sy / M, h = Sz / M - i * H, Rr = Math.sqrt(h * h + 14.06);
      const cand = [(x1 - cx) / h, (cx - x0) / h, (y1 - cy) / h, (cy - y0) / h], edge = [x1, x0, y1, y0];
      for (let q = 0; q < 4; q++) if (cand[q] < crit[q].a) { const c = crit[q]; c.a = cand[q]; c.i = i; c.h = h; c.M = M; c.R = Rr; c.e = edge[q]; }
    }
    return { crit, bad, top };
  }
  function minAlpha(g) { return g.bad >= 0 ? -1 : Math.min(g.crit[0].a, g.crit[1].a, g.crit[2].a, g.crit[3].a); }

  /* load carried by each block of level l: the part above is a rigid plank on three elastic supports of different thickness */
  function loads(lv, P, l) {
    const ax = l % 2;
    let W = 0, Sc = 0, Sz = 0;
    for (let i = l + 1; i < lv.length; i++) for (let k = 0; k < 3; k++) {
      const id = lv[i].b[k]; if (id < 0) continue;
      const m = P[id].m, c = centerXY(lv, i, k);
      W += m; Sc += m * (ax === 0 ? c[1] : c[0]); Sz += m * (i * H + H / 2);
    }
    const f = [0, 0, 0];
    if (W <= 0) return { f, W: 0, zc: 0 };
    const c = Sc / W - (ax === 0 ? lv[l].sy : lv[l].sx);
    const sup = []; for (let k = 0; k < 3; k++) if (lv[l].b[k] >= 0) sup.push(k);
    const t = (k) => P[lv[l].b[k]].t, x = (k) => (k - 1) * BW;
    const sets = [];
    if (sup.length === 3) sets.push(sup);
    for (let a = 0; a < sup.length; a++) for (let b = a + 1; b < sup.length; b++) sets.push([sup[a], sup[b]]);
    for (const A of sets) {
      let n = 0, X1 = 0, X2 = 0, T0 = 0, T1 = 0;
      for (const k of A) { n++; X1 += x(k); X2 += x(k) * x(k); T0 += t(k); T1 += t(k) * x(k); }
      const det = n * X2 - X1 * X1; if (det < 1e-9) continue;
      const r0 = T0 - W, r1 = T1 - W * c;
      const z = (r0 * X2 - X1 * r1) / det, ph = (n * r1 - X1 * r0) / det;
      let ok = true;
      for (const k of sup) { const d = t(k) - z - ph * x(k); if (A.includes(k) ? d < -1e-7 : d > 1e-7) { ok = false; break; } }
      if (!ok) continue;
      for (const k of A) f[k] = Math.max(0, t(k) - z - ph * x(k));
      return { f, W, zc: Sz / W };
    }
    // centre of mass beyond the supports (the tower is tipping anyway): the nearest support takes it all
    let best = sup[0]; for (const k of sup) if (Math.abs(x(k) - c) < Math.abs(x(best) - c)) best = k;
    if (best != null) f[best] = W;
    return { f, W, zc: Sz / W };
  }
  function blockInfo(lv, P, id) {
    const pos = findBlock(lv, id); if (!pos) return null;
    const ld = loads(lv, P, pos[0]), f = ld.f[pos[1]], pb = P[id];
    const Fs = pb.mu * (f + pb.m) * G + Math.min(pb.mu * f * G, MUR * Math.max(0, ld.W - f) * G);
    return { l: pos[0], k: pos[1], f, W: ld.W, Fs, drag: pb.mu * f > MUR * (ld.W - f) };
  }
  function looseLabel(bi) {
    if (bi.drag) return { t: '꽉 낌 · 위층이 같이 밀려요', n: 0, c: '#ee6a55' };
    if (bi.Fs < 1500) return { t: '헐거움', n: 5, c: '#5fd3a0' };
    if (bi.Fs < 4000) return { t: '조금 헐거움', n: 4, c: '#9fd36a' };
    if (bi.Fs < 8000) return { t: '보통', n: 3, c: '#e3ae45' };
    if (bi.Fs < 14000) return { t: '빡빡함', n: 2, c: '#ee9a55' };
    return { t: '꽉 낌', n: 1, c: '#ee6a55' };
  }

  /* ---------- profile: target finger position per 0.05 s, run-length coded ---------- */
  function encProf(arr) {
    let s = '';
    for (let i = 0; i < arr.length;) { let j = i; while (j < arr.length && arr[j] === arr[i]) j++; s += ALPH[arr[i]] + (j - i > 1 ? j - i : ''); i = j; }
    return s;
  }
  function decProf(s) {
    const out = [], re = /([A-Za-z])(\d*)/g; let m;
    while ((m = re.exec(s))) { const v = ALPH.indexOf(m[1]), n = m[2] ? +m[2] : 1; for (let k = 0; k < n && out.length < 2400; k++) out.push(v); }
    return out;
  }

  /* ---------- deterministic simulation ---------- */
  function Sim(seed, pre, a, live) {
    this.P = props(seed); this.seed = seed; this.lv = decode(pre); this.k = a.k;
    this.th = [0, 0]; this.om = [0, 0]; this.n = 0; this.done = false; this.col = null; this.calm = 0;
    this.peak = 0; this.dang = 0; this.Fp = 0; this.dvu = 0; this.tOut = 0;
    if (a.k === 'p') {
      const pos = findBlock(this.lv, a.b);
      this.id = a.b; this.l = pos[0]; this.ks = pos[1]; this.ax = this.l % 2; this.d = a.d < 0 ? -1 : 1;
      this.prof = typeof a.p === 'string' ? decProf(a.p) : a.p; this.open = !!live;
      this.s = 0; this.vb = 0; this.u = 0; this.vu = 0; this.ua = 0; this.out = 0; this.tOut = 0; this.ab = -1; this.te = 0;
      const ld = loads(this.lv, this.P, this.l);
      this.W = ld.W; this.f0 = ld.f[this.ks]; this.zUp = ld.zc;
      this.mb = this.P[a.b].m; this.mu = this.P[a.b].mu;
    } else {
      this.id = a.b; this.slot = a.slot;
      placeBlock(this.lv, a.b, a.slot, seed);
      this.pl = this.lv.length - 1;
      this.om[0] = (hash(seed, 5000 + pre.L.length * 3 + a.slot) - 0.5) * 0.16;
      this.om[1] = (hash(seed, 7000 + pre.L.length * 3 + a.slot) - 0.5) * 0.16;
    }
    this.geo = analyze(this.lv, this.P, this.mv());
  }
  Sim.prototype.mv = function () {
    return this.k === 'p' ? { l: this.l, k: this.ks, ds: this.d * this.s, du: this.d * this.u, ax: this.ax, out: this.out } : null;
  };
  Sim.prototype.time = function () { return this.n * DT; };
  // live recording: the view must append a profile sample before stepping when this is true
  Sim.prototype.need = function () { return this.k === 'p' && this.open && !this.out && Math.floor(this.n / SPS) >= this.prof.length; };
  Sim.prototype.collapse = function (j, sg, c, th, om) {
    this.col = { j, sg, i: c.i, a: c.a, R: c.R, e: c.e, th, om };
    this.done = true;
  };
  Sim.prototype.step = function () {
    if (this.done) return;
    const t = this.n * DT;
    let moved = false;
    this.Fp = 0; this.dvu = 0;
    if (this.k === 'p') {
      const W = this.W, vu0 = this.vu, vr0 = Math.abs(this.vb - this.vu);
      let f = 0;
      if (!this.out) {
        const si = Math.floor(this.n / SPS);
        let tg;
        if (si < this.prof.length) tg = this.prof[si] * QSTEP;
        else { // profile over but block still in: a steady, firm push finishes the job
          if (this.ab < 0) { this.ab = this.s + 0.3; this.te = t; }
          tg = Math.min(QMAX * QSTEP, this.ab + 3 * (t - this.te));
        }
        const ov = BL - Math.abs(this.s - this.u);
        f = this.f0 * clamp(ov / 5, 0, 1);
        let Fp = tg > this.s ? Math.min(FMAX, KF * (tg - this.s)) - CF * this.vb : 0;
        if (Fp < 0) Fp = 0;
        this.Fp = Fp;
        this.vb += Fp / this.mb * DT;
      }
      // the part above: elastic shear against the rest of the level, slipping when the friction cap is exceeded
      if (W > 0) {
        const ks = KS * W; let Fr = -ks * (this.u - this.ua) - 1.2 * Math.sqrt(ks * W) * this.vu;
        const cap = MUR * Math.max(0, W - f) * G;
        if (Fr > cap) { Fr = cap; this.ua = this.u + cap / ks; } else if (Fr < -cap) { Fr = -cap; this.ua = this.u - cap / ks; }
        this.vu += Fr / W * DT;
      }
      if (!this.out) {
        const m = this.mb, kin = Math.abs(this.vb) > 0.05 || Math.abs(this.vb - this.vu) > 0.05;
        // wood on wood: kinetic friction a bit below static, but rising again with sliding speed (fibres snag) —
        // so a fast yank of a loaded block grabs the part above much harder than a slow, steady push
        const vr = vr0, kv = kin ? 0.85 + 0.55 * clamp((vr - 6) / VSN, 0, 1) : 1;
        const mu = this.mu, cB = mu * (kin ? 0.88 : 1) * (f + m) * G * DT, cT = mu * kv * f * G * DT;
        const meff = W > 0 ? 1 / (1 / m + 1 / W) : m;
        let lb = 0, lt = 0;
        for (let it = 0; it < 8; it++) {
          let nl = clamp(lb - this.vb * m, -cB, cB); this.vb += (nl - lb) / m; lb = nl;
          if (W > 0 && cT > 0) { nl = clamp(lt - (this.vb - this.vu) * meff, -cT, cT); const dl = nl - lt; this.vb += dl / m; this.vu -= dl / W; lt = nl; }
        }
        this.s += this.vb * DT;
        if (this.s < 0) { this.s = 0; if (this.vb < 0) this.vb = 0; }
        if (this.s >= BL || t > this.prof.length * SPS * DT + 25) {
          this.out = 1; this.tOut = t; this.lv[this.l].b[this.ks] = -1; this.vb = 0;
        }
        moved = true;
      }
      this.u += this.vu * DT;
      this.dvu = this.vu - vu0;
      if (this.vu !== 0 || this.dvu !== 0) moved = true;
    }
    if (moved || !this.n) this.geo = analyze(this.lv, this.P, this.mv());
    const geo = this.geo;
    if (geo.bad >= 0) {
      const j = this.k === 'p' ? this.ax : 0;
      this.collapse(j, this.k === 'p' ? this.d : 1, { i: geo.bad, a: -0.05, R: 10, e: 0 }, 0, 0);
      this.n++; return;
    }
    let dang = 0;
    for (let j = 0; j < 2; j++) {
      const th = this.th[j]; let om = this.om[j];
      const sg = th > 0 || (th === 0 && om >= 0) ? 1 : -1;
      const c = geo.crit[j * 2 + (sg > 0 ? 0 : 1)];
      const al = c.a, p2 = 0.75 * G / c.R;
      if (this.k === 'p' && j === this.ax) {
        const I = c.M * 1.333 * c.R * c.R;
        if (this.dvu) {
          // the dragged upper part accelerates: the body above the hinge lags behind (or is shoved) → tilt
          const Mm = c.i > this.l ? c.M : this.W, hm = c.i > this.l ? c.h : this.zUp - c.i * H;
          om += -this.dvu * this.d * Mm * hm / I;
        }
        if (this.Fp && c.i < this.l) om += this.d * this.Fp * (this.l * H + H / 2 - c.i * H) / I * DT;
      }
      const acc = Math.abs(th) < TE && al > TE ? -p2 * al * th / TE : -sg * p2 * (al - Math.abs(th));
      om += acc * DT; om *= 1 - DAMP * DT;
      const nth = th + om * DT;
      if (nth * th < 0) om *= REST;
      this.th[j] = nth; this.om[j] = om;
      const r = Math.abs(nth) / Math.max(0.004, al); if (r > dang) dang = r;
      if (Math.abs(nth) > al + 0.02) { this.collapse(j, nth > 0 ? 1 : -1, c, nth, om); this.n++; return; }
    }
    this.dang = dang; if (dang > this.peak) this.peak = dang;
    if (this.k === 'q' || this.out) {
      const quiet = Math.abs(this.th[0]) < 4e-4 && Math.abs(this.th[1]) < 4e-4 && Math.abs(this.om[0]) < 0.01 && Math.abs(this.om[1]) < 0.01 &&
        (this.k === 'q' || (Math.abs(this.vu) < 0.01 && Math.abs(this.u - this.ua) < 0.003));
      this.calm = quiet ? this.calm + 1 : 0;
      if (this.calm > 24 && t - this.tOut > 0.25) this.done = true;
      if (t - this.tOut > 15) this.done = true;
    }
    this.n++;
  };
  Sim.prototype.run = function () { let g = 0; while (!this.done && g++ < 200000) { if (this.need()) this.open = false; this.step(); } return this; };
  Sim.prototype.post = function () {
    const lv = cloneLv(this.lv);
    if (this.k === 'p') for (let i = this.l + 1; i < lv.length; i++) { if (this.ax === 0) lv[i].sx += this.d * this.u; else lv[i].sy += this.d * this.u; }
    return encode(lv);
  };

  /* ---------- state ---------- */
  function newSeed() { return 1 + Math.floor(Math.random() * 2147483000); }
  function init(players, opts) {
    const n = players.length, sd = newSeed(), tw = initialTower(sd);
    return {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), md: opts && opts.rule === 'elim' ? 'elim' : 'one',
      sd, L: tw.L, S: tw.S, c: 0, ph: 'pull', h: -1, al: players.map((_, i) => i), ko: [], pc: players.map(() => 0),
      np: 0, tc: 0, rd: 1, lost: -1, seq: 0, last: null,
    };
  }
  function actor(s) { return s.ph === 'end' ? null : s.c; }
  function nextAlive(s, seat) { for (let k = 1; k <= s.n; k++) { const q = (seat + k) % s.n; if (s.al.includes(q)) return q; } return seat; }
  function fell(s, seat) {
    s.ko.push(seat); s.lost = seat;
    if (s.md === 'elim' && s.al.length > 2) {
      const nx = nextAlive(s, seat);
      s.al = s.al.filter((q) => q !== seat);
      s.sd = newSeed(); const tw = initialTower(s.sd); s.L = tw.L; s.S = tw.S;
      s.c = nx; s.ph = 'pull'; s.h = -1; s.np = 0; s.tc = 0; s.rd++;
    } else {
      if (s.md === 'elim') s.al = s.al.filter((q) => q !== seat);
      s.ph = 'end';
    }
    return s;
  }
  function apply(s, seat, a) {
    if (actor(s) !== seat) throw new Error('not your turn');
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const lv = decode(s);
    if (s.ph === 'pull') {
      if (a.k !== 'p') throw new Error('expected a pull');
      const b = a.b | 0, d = a.d < 0 ? -1 : 1, p = String(a.p || '');
      if (!legalBlocks(lv).includes(b)) throw new Error('illegal block');
      if (p.length > 1200 || !/^([A-Za-z]\d{0,4})*$/.test(p)) throw new Error('bad profile');
      const pk = Array.isArray(a.pk) ? a.pk.map((x) => x | 0).filter((x) => x >= 0 && x < NB).slice(0, 3) : [];
      const pre = { L: s.L, S: s.S };
      const sim = new Sim(s.sd, pre, { k: 'p', b, d, p }).run();
      s.seq++;
      s.last = { id: s.seq, k: 'p', s: seat, sd: s.sd, pre, a: { b, d, p, pk } };
      s.pc[seat]++; s.np++;
      if (sim.col) { s.last.col = 1; return fell(s, seat); }
      const post = sim.post(); s.L = post.L; s.S = post.S;
      s.ph = 'place'; s.h = b;
      return s;
    }
    if (s.ph === 'place') {
      if (a.k !== 'q') throw new Error('expected a placement');
      const slot = a.slot | 0;
      if (!legalSlots(lv).includes(slot)) throw new Error('slot taken');
      const pre = { L: s.L, S: s.S };
      const sim = new Sim(s.sd, pre, { k: 'q', b: s.h, slot }).run();
      s.seq++;
      s.last = { id: s.seq, k: 'q', s: seat, sd: s.sd, pre, a: { b: s.h, slot } };
      if (sim.col) { s.last.col = 1; s.h = -1; return fell(s, seat); }
      const post = sim.post(); s.L = post.L; s.S = post.S;
      s.h = -1; s.ph = 'pull'; s.tc++;
      if (s.tc >= TMAX) { s.ph = 'end'; s.lost = -1; return s; }
      s.c = nextAlive(s, seat);
      return s;
    }
    throw new Error('game over');
  }
  function result(s) {
    if (s.ph !== 'end') return null;
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const lv = decode(s), lvls = topInfo(lv).top + 1;
    if (s.lost < 0) return { winners: s.al.slice(), title: '탑이 버텼어요!', text: '블록을 ' + s.np + '개나 뺐는데도 끝까지 서 있었어요.' };
    if (s.md === 'elim' && s.n > 1) {
      const order = s.al.concat(s.ko.slice().reverse());
      return { winners: s.al.slice(), text: order.map((q, r) => (r + 1) + '위 ' + nm(q)).join('\n') };
    }
    if (s.n === 1) return { winners: [], title: '탑이 무너졌어요', text: '블록 ' + s.np + '개를 빼서 올렸어요 · ' + lvls + '층까지 쌓았어요.' };
    const w = []; for (let i = 0; i < s.n; i++) if (i !== s.lost) w.push(i);
    return { winners: w, title: nm(s.lost) + ' 님이 무너뜨렸어요', text: '이번 판에 뺀 블록 ' + s.np + '개 · 탑 높이 ' + lvls + '층' };
  }

  /* ---------- AI ---------- */
  function runPolicy(seed, pre, id, d, pol) {
    const prof = [], sim = new Sim(seed, pre, { k: 'p', b: id, d, p: prof }, true);
    let g = 0;
    while (!sim.done && g++ < 60000) {
      if (sim.need()) { if (prof.length >= PMAX) sim.open = false; else prof.push(clamp(Math.round(pol(sim) / QSTEP), 0, QMAX)); }
      sim.step();
      if (sim.out) sim.open = false;
    }
    return { prof, sim };
  }
  function aiScore(bi, sa) { return -bi.Fs / 4000 + Math.min(sa, 0.25) * 8 - (bi.drag ? 6 : 0) - (sa < 0.04 ? 12 : 0); }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const tw = decode(s), P = props(s.sd), pre = { L: s.L, S: s.S };
    if (s.ph === 'place') {
      const slots = legalSlots(tw);
      if (lv === 1 && Math.random() < 0.6) return { k: 'q', slot: slots[Math.floor(Math.random() * slots.length)] };
      let best = slots[0], bv = -9;
      for (const k of slots) { const t2 = cloneLv(tw); placeBlock(t2, s.h, k, s.sd); const v = minAlpha(analyze(t2, P, null)) + (k === 1 ? 0.002 : 0); if (v > bv) { bv = v; best = k; } }
      return { k: 'q', slot: best };
    }
    const legal = legalBlocks(tw);
    const evalB = (id) => {
      const bi = blockInfo(tw, P, id), t2 = cloneLv(tw), pos = findBlock(t2, id); t2[pos[0]].b[pos[1]] = -1;
      const sa = minAlpha(analyze(t2, P, null));
      return { id, bi, sa, sc: aiScore(bi, sa) };
    };
    const dir = () => (Math.random() < 0.5 ? 1 : -1);
    if (lv === 1) {
      let c;
      if (Math.random() < 0.35) c = evalB(legal[Math.floor(Math.random() * legal.length)]);
      else { const cs = U.shuffle(legal.slice()).slice(0, 3).map(evalB); cs.sort((a, b) => a.bi.Fs - b.bi.Fs); c = cs[0]; }
      const v = 3 + Math.random() * 5, j = Math.random() - 0.5;
      const r = runPolicy(s.sd, pre, c.id, dir(), (sim) => Math.min(12.5, v * sim.time() + j));
      return { k: 'p', b: c.id, d: r.sim.d, p: encProf(r.prof), pk: [] };
    }
    if (lv === 2) {
      const cs = U.shuffle(legal.slice()).slice(0, 5).map(evalB);
      cs.sort((a, b) => b.sc - a.sc);
      const c = cs[0], d = dir();
      const v = 4.5 + Math.random() * 2.5, r = runPolicy(s.sd, pre, c.id, d, (sim) => Math.min(v * sim.time(), sim.s + c.bi.Fs / KF + 0.9));
      return { k: 'p', b: c.id, d, p: encProf(r.prof), pk: cs.slice(0, 2).map((x) => x.id).filter((x) => x !== c.id).concat([c.id]).slice(-2) };
    }
    // 어려움: rank every legal block, then try the best few for real with a careful, wobble-aware push
    const cs = legal.map(evalB).sort((a, b) => b.sc - a.sc);
    const t0 = Date.now(); let best = null;
    for (const c of cs.slice(0, 5)) {
      for (const d of [1, -1]) {
        const pol = (sim) => (sim.dang > 0.3 || Math.abs(sim.vu) > 0.4 ? sim.s : Math.min(4 * sim.time(), sim.s + 0.85 * c.bi.Fs / KF + 0.3));
        const r = runPolicy(s.sd, pre, c.id, d, pol);
        const v = (r.sim.col ? 100 : r.sim.peak) - c.sc * 0.02;
        if (!best || v < best.v) best = { v, c, d, r };
        if (!r.sim.col && r.sim.peak < 0.15) break;
      }
      if (best && best.v < 0.1) break;
      if (Date.now() - t0 > 220) break;
    }
    const pk = cs.slice(0, 3).map((x) => x.id).filter((x) => x !== best.c.id).slice(0, 2).concat([best.c.id]);
    return { k: 'p', b: best.c.id, d: best.d, p: encProf(best.r.prof), pk };
  }
  function aiDelayFor(s, seat, lv) { return s.ph === 'place' ? 450 : [1300, 900, 650][clamp((lv || 2) - 1, 0, 2)]; }

  /* ---------- view ---------- */
  const YAW90 = [0, -1, 0, 1, 0, 0, 0, 0, 1], ID3 = [1, 0, 0, 0, 1, 0, 0, 0, 1];
  const mmul = (A, B) => { const C = new Array(9); for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) C[r * 3 + c] = A[r * 3] * B[c] + A[r * 3 + 1] * B[3 + c] + A[r * 3 + 2] * B[6 + c]; return C; };
  const mv3 = (R, x, y, z) => [R[0] * x + R[1] * y + R[2] * z, R[3] * x + R[4] * y + R[5] * z, R[6] * x + R[7] * y + R[8] * z];
  const mtv3 = (R, x, y, z) => [R[0] * x + R[3] * y + R[6] * z, R[1] * x + R[4] * y + R[7] * z, R[2] * x + R[5] * y + R[8] * z];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const FACES = [[0, 2, 6, 4, 0], [1, 5, 7, 3, 0], [0, 4, 5, 1, 1], [2, 3, 7, 6, 1], [0, 1, 3, 2, 2], [4, 6, 7, 5, 2]]; // last: 0 end grain, 1 long side, 2 broad face
  const FN = [[-1, 0, 0], [1, 0, 0], [0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1]];
  const LIGHT = (() => { const v = [-0.35, -0.55, 0.76], l = Math.hypot(...v); return v.map((x) => x / l); })();
  const II = [1 / 0.708, 1 / 4.875, 1 / 5.208]; // inverse principal inertia of a block (unit mass)

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const topEl = L.h('div', { class: 'hud top', style: { padding: '6px 8px 0', justifyContent: 'space-between', flexWrap: 'nowrap' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px', flexDirection: 'column', alignItems: 'stretch', gap: '6px' } });
    root.append(topEl, bot);
    const color = (i) => (api.players[i] ? api.players[i].color : '#fff');
    const nameOf = (i) => (api.players[i] ? api.players[i].name : '');
    let st = null, P = null, lvS = null, dirty = true, alive = true;
    let anim = null;       // {sim, kind:'live'|'replay', ...}
    let fall = null;       // collapse animation
    let rubble = null;     // blocks lying around after a collapse (kept for the end screen)
    let sel = null;        // {id, t0, dist, d, bi}
    let ptr = null, sentAt = 0, simAcc = 0, flash = null, slotSel = -1, lastCreak = 0;
    const cam = { yaw: 0.72, tyaw: 0.72, pitch: 0.4, D: 90, F: 600, tz: 13, ttz: 13, zoom: 1, tzoom: 1, sc: 12, cx: 0, cy: 0 };
    let B = null; // camera basis
    let polys = []; // hit list for this frame: {id, pts[], kind}

    /* ---- camera ---- */
    function areaRect() {
      const tb = topEl.getBoundingClientRect(), bb = bot.getBoundingClientRect(), rr = cv.cv.getBoundingClientRect();
      const top = Math.max(0, (tb.bottom || 0) - rr.top) + 34, b = Math.min(cv.h, (bb.top || cv.h) - rr.top) - 6;
      return { top, bot: Math.max(top + 120, b) };
    }
    function setCam() {
      const ar = areaRect(), areaH = ar.bot - ar.top;
      const top = lvS ? Math.max(8, topInfo(lvS).top + 1) : NL0;
      const Z = top * H + 4;
      cam.ttz = sel && !fall ? cam.ttz : Z * 0.46;
      const base = Math.min(areaH * 0.86 / (Z * Math.cos(cam.pitch) + 12 * Math.sin(cam.pitch)), cv.w * 0.74 / 19);
      cam.sc = base * cam.zoom;
      cam.F = cam.sc * cam.D;
      cam.cx = cv.w / 2; cam.cy = ar.top + areaH * 0.5;
      const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw), cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
      const pos = [cp * cy * cam.D, cp * sy * cam.D, cam.tz + sp * cam.D], fw = [-cp * cy, -cp * sy, -sp], rt = [-sy, cy, 0];
      B = { pos, fw, rt, up: cross(rt, fw) };
    }
    function proj(p) {
      const dx = p[0] - B.pos[0], dy = p[1] - B.pos[1], dz = p[2] - B.pos[2];
      const z = dx * B.fw[0] + dy * B.fw[1] + dz * B.fw[2];
      const x = dx * B.rt[0] + dy * B.rt[1], y = dx * B.up[0] + dy * B.up[1] + dz * B.up[2];
      return [cam.cx + cam.F * x / z, cam.cy - cam.F * y / z, z];
    }

    /* ---- block poses ---- */
    function dimsOf(id) { const p = P ? P[id] : null; return p ? [HL + p.dl * 0.5, 1.205 + 0.03 * p.dw, 0.735] : [HL, 1.22, 0.735]; }
    // tilt transforms from a sim (or nothing): rotate everything above the hinge interface about its edge
    function tiltsOf(sim, extra) {
      const out = [];
      if (!sim || !sim.geo || sim.geo.bad >= 0) return out;
      for (let j = 0; j < 2; j++) {
        let th = sim.th[j]; if (!th) continue;
        th = th * (1 + 1.5 * Math.max(0, 1 - Math.abs(th) / 0.03)); // make tiny tremble readable
        const c = sim.geo.crit[j * 2 + (sim.th[j] > 0 ? 0 : 1)];
        out.push({ j, i: c.i, e: c.e, zi: c.i * H, cs: Math.cos(th), sn: Math.sin(th) });
      }
      if (extra) out.push(extra);
      return out;
    }
    function tiltPt(p, tl) {
      if (tl.j === 0) { const x = p[0] - tl.e, z = p[2] - tl.zi; return [tl.e + x * tl.cs + z * tl.sn, p[1], tl.zi + z * tl.cs - x * tl.sn]; }
      const y = p[1] - tl.e, z = p[2] - tl.zi; return [p[0], tl.e + y * tl.cs + z * tl.sn, tl.zi + z * tl.cs - y * tl.sn];
    }
    function tiltMat(tl) { return tl.j === 0 ? [tl.cs, 0, tl.sn, 0, 1, 0, -tl.sn, 0, tl.cs] : [1, 0, 0, 0, tl.cs, tl.sn, 0, -tl.sn, tl.cs]; }
    // list of {id, lvl, c:[x,y,z], R} for the tower (from a sim if animating, else from the state)
    function towerPoses(lv, sim) {
      const out = [];
      for (let i = 0; i < lv.length; i++) for (let k = 0; k < 3; k++) {
        const id = lv[i].b[k]; if (id < 0) continue;
        const c = centerXY(lv, i, k); let z = i * H + H / 2;
        if (sim && sim.k === 'p') {
          const o = i === sim.l && k === sim.ks ? sim.d * sim.s : i > sim.l ? sim.d * sim.u : 0;
          if (sim.ax === 0) c[0] += o; else c[1] += o;
        }
        if (sel && !sim && id === sel.id) {
          const tt = (performance.now() - sel.t0) / 1000 * L.debug.speed, b = tt < 0.42 ? Math.sin(Math.PI * tt / 0.42) : 0;
          const o = sel.d * sel.dist * b; if (i % 2 === 0) c[0] += o; else c[1] += o;
        }
        out.push({ id, lvl: i, k, c: [c[0], c[1], z], R: i % 2 ? YAW90 : ID3 });
      }
      return out;
    }
    function blockCorners(b, tilts) {
      const d = dimsOf(b.id), pts = [];
      for (let q = 0; q < 8; q++) {
        const l = mv3(b.R, q & 1 ? d[0] : -d[0], q & 2 ? d[1] : -d[1], q & 4 ? d[2] : -d[2]);
        let p = [b.c[0] + l[0], b.c[1] + l[1], b.c[2] + l[2]];
        if (tilts) for (const tl of tilts) if (b.lvl == null || b.lvl >= tl.i) p = tiltPt(p, tl);
        pts.push(p);
      }
      return pts;
    }
    function blockR(b, tilts) {
      let R = b.R;
      if (tilts) for (const tl of tilts) if (b.lvl == null || b.lvl >= tl.i) R = mmul(tiltMat(tl), R);
      return R;
    }

    /* ---- drawing ---- */
    function woodRGB(id) {
      const t = P ? P[id].tone : 0.5;
      return [214 + 22 * t - 10 * (t > 0.85 ? 1 : 0), 168 + 26 * t, 108 + 30 * t];
    }
    function drawBlock(b, tilts, o) {
      const pts = blockCorners(b, tilts), R = blockR(b, tilts), pj = pts.map(proj);
      if (pj.some((q) => q[2] < 1)) return null;
      const rgb = woodRGB(b.id), faces = [];
      const cx = (pts[0][0] + pts[7][0]) / 2, cy = (pts[0][1] + pts[7][1]) / 2, cz = (pts[0][2] + pts[7][2]) / 2;
      for (let f = 0; f < 6; f++) {
        const F = FACES[f], n = mv3(R, FN[f][0], FN[f][1], FN[f][2]);
        const fc = [0, 1, 2].map((a) => (pts[F[0]][a] + pts[F[2]][a]) / 2);
        const vis = n[0] * (B.pos[0] - fc[0]) + n[1] * (B.pos[1] - fc[1]) + n[2] * (B.pos[2] - fc[2]);
        if (vis <= 0) continue;
        const li = 0.58 + 0.42 * Math.max(0, n[0] * LIGHT[0] + n[1] * LIGHT[1] + n[2] * LIGHT[2]);
        let k = li * (F[4] === 0 ? 0.8 : 1);
        const r = Math.round(rgb[0] * k * (F[4] === 0 ? 1.02 : 1)), g = Math.round(rgb[1] * k * (F[4] === 0 ? 0.92 : 1)), bb = Math.round(rgb[2] * k * (F[4] === 0 ? 0.85 : 1));
        const q = [pj[F[0]], pj[F[1]], pj[F[2]], pj[F[3]]];
        ctx.globalAlpha = o && o.alpha != null ? o.alpha : 1;
        ctx.fillStyle = 'rgb(' + r + ',' + g + ',' + bb + ')';
        ctx.beginPath(); ctx.moveTo(q[0][0], q[0][1]); for (let i = 1; i < 4; i++) ctx.lineTo(q[i][0], q[i][1]); ctx.closePath(); ctx.fill();
        // grain: lines along the long axis on the side/broad faces, rings on the end grain
        const area = Math.abs((q[2][0] - q[0][0]) * (q[3][1] - q[1][1]) - (q[3][0] - q[1][0]) * (q[2][1] - q[0][1])) / 2;
        if (area > 40) {
          ctx.strokeStyle = 'rgba(110,62,24,.2)'; ctx.lineWidth = 0.8; ctx.beginPath();
          if (F[4] !== 0) {
            // edges along local x are q0→? : find which pair of edges is longer in 3D (the long axis)
            const e01 = Math.hypot(pts[F[1]][0] - pts[F[0]][0], pts[F[1]][1] - pts[F[0]][1], pts[F[1]][2] - pts[F[0]][2]);
            const e12 = Math.hypot(pts[F[2]][0] - pts[F[1]][0], pts[F[2]][1] - pts[F[1]][1], pts[F[2]][2] - pts[F[1]][2]);
            const A = e01 > e12 ? [q[0], q[1], q[3], q[2]] : [q[1], q[2], q[0], q[3]];
            const t0 = P ? P[b.id].tone : 0.5;
            for (const v of [0.28 + 0.1 * t0, 0.62 - 0.08 * t0]) {
              const a = [A[0][0] + (A[2][0] - A[0][0]) * v, A[0][1] + (A[2][1] - A[0][1]) * v], e = [A[1][0] + (A[3][0] - A[1][0]) * v, A[1][1] + (A[3][1] - A[1][1]) * v];
              ctx.moveTo(a[0], a[1]); ctx.quadraticCurveTo((a[0] + e[0]) / 2 + (v - 0.45) * 3, (a[1] + e[1]) / 2 + (v - 0.45) * 3, e[0], e[1]);
            }
          } else {
            const mx = (q[0][0] + q[2][0]) / 2, my = (q[0][1] + q[2][1]) / 2;
            ctx.moveTo(mx + (q[1][0] - mx) * 0.5, my + (q[1][1] - my) * 0.5); ctx.lineTo(mx + (q[3][0] - mx) * 0.5, my + (q[3][1] - my) * 0.5);
          }
          ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(70,38,14,.45)'; ctx.lineWidth = 0.7;
        ctx.beginPath(); ctx.moveTo(q[0][0], q[0][1]); for (let i = 1; i < 4; i++) ctx.lineTo(q[i][0], q[i][1]); ctx.closePath(); ctx.stroke();
        faces.push(q);
      }
      ctx.globalAlpha = 1;
      if (o && o.hl) {
        ctx.strokeStyle = o.hl; ctx.lineWidth = 2.4; ctx.lineJoin = 'round';
        for (const q of faces) { ctx.beginPath(); ctx.moveTo(q[0][0], q[0][1]); for (let i = 1; i < 4; i++) ctx.lineTo(q[i][0], q[i][1]); ctx.closePath(); ctx.stroke(); }
      }
      return { faces, c: proj([cx, cy, cz]) };
    }
    function drawGhost(c, R, on) {
      const d = [HL, 1.2, 0.72], pts = [];
      for (let q = 0; q < 8; q++) { const l = mv3(R, q & 1 ? d[0] : -d[0], q & 2 ? d[1] : -d[1], q & 4 ? d[2] : -d[2]); pts.push(proj([c[0] + l[0], c[1] + l[1], c[2] + l[2]])); }
      const faces = [];
      for (let f = 0; f < 6; f++) {
        const F = FACES[f], n = mv3(R, FN[f][0], FN[f][1], FN[f][2]);
        const vis = n[0] * (B.pos[0] - c[0]) + n[1] * (B.pos[1] - c[1]) + n[2] * (B.pos[2] - c[2]);
        if (vis <= 0) continue;
        faces.push([pts[F[0]], pts[F[1]], pts[F[2]], pts[F[3]]]);
      }
      const t = performance.now() / 1000;
      for (const q of faces) {
        ctx.fillStyle = on ? 'rgba(227,174,69,' + (0.32 + 0.12 * Math.sin(t * 5)) + ')' : 'rgba(242,233,216,.13)';
        ctx.beginPath(); ctx.moveTo(q[0][0], q[0][1]); for (let i = 1; i < 4; i++) ctx.lineTo(q[i][0], q[i][1]); ctx.closePath(); ctx.fill();
        ctx.setLineDash(on ? [] : [3, 3]); ctx.strokeStyle = on ? '#e3ae45' : 'rgba(242,233,216,.6)'; ctx.lineWidth = on ? 2 : 1.2; ctx.stroke(); ctx.setLineDash([]);
      }
      return faces;
    }
    function drawTable() {
      const g = ctx.createLinearGradient(0, 0, 0, cv.h);
      g.addColorStop(0, '#1c1526'); g.addColorStop(1, '#100c16');
      ctx.fillStyle = g; ctx.fillRect(0, 0, cv.w, cv.h);
      const ring = (r, z) => { const pts = []; for (let a = 0; a < 48; a++) { const t = a / 48 * Math.PI * 2; pts.push(proj([Math.cos(t) * r, Math.sin(t) * r, z])); } return pts; };
      const poly = (pts) => { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); };
      const c0 = proj([0, 0, 0]);
      const spot = ctx.createRadialGradient(c0[0], c0[1] - cv.h * 0.2, 10, c0[0], c0[1] - cv.h * 0.1, cv.h * 0.75);
      spot.addColorStop(0, 'rgba(227,174,69,.10)'); spot.addColorStop(1, 'rgba(227,174,69,0)');
      ctx.fillStyle = spot; ctx.fillRect(0, 0, cv.w, cv.h);
      poly(ring(30, -2.4)); ctx.fillStyle = '#2a170c'; ctx.fill();
      const top = ring(30, 0); poly(top);
      const tg = ctx.createRadialGradient(c0[0], c0[1], 4, c0[0], c0[1], cam.sc * 34);
      tg.addColorStop(0, '#6e4122'); tg.addColorStop(0.7, '#4c2a14'); tg.addColorStop(1, '#3a1f0e');
      ctx.fillStyle = tg; ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.35)'; ctx.lineWidth = 1.2; ctx.stroke();
      // a few concentric grain arcs
      ctx.strokeStyle = 'rgba(30,14,4,.25)'; ctx.lineWidth = 1;
      for (const r of [9, 15, 22]) { poly(ring(r, 0)); ctx.stroke(); }
    }
    function drawShadow(lv) {
      if (!lv || !lv.length) return;
      const v = lv[0], pts = [[-5, -5], [5, -5], [5, 5], [-5, 5]].map((q) => proj([v.sx + q[0], v.sy + q[1], 0]));
      ctx.fillStyle = 'rgba(0,0,0,.28)';
      for (const s of [1, 0.8]) {
        const cx = (pts[0][0] + pts[2][0]) / 2, cy = (pts[0][1] + pts[2][1]) / 2;
        ctx.beginPath(); pts.forEach((p, i) => { const x = cx + (p[0] - cx) * s, y = cy + (p[1] - cy) * s; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.closePath(); ctx.fill();
      }
    }

    function handPos() {
      const ti = lvS ? topInfo(lvS) : { top: NL0 - 1 };
      const z = (ti.top + 1) * H + 3.2 + Math.sin(performance.now() / 500) * 0.25;
      return [B.rt[0] * 8.5, B.rt[1] * 8.5, z];
    }
    function drawScene(now) {
      setCam();
      cv.clear();
      polys = [];
      if (!st) return;
      drawTable();
      let lv = lvS, sim = null, tilts = null;
      if (anim) { sim = anim.sim; lv = sim.lv; tilts = tiltsOf(sim); }
      const items = [];
      if (fall) {
        for (const b of fall.stand) items.push({ b, tilts: null });
        if (fall.phase === 'tip') for (const b of fall.body) items.push({ b, tilts: [fall.tl] });
        else for (const d of fall.deb) items.push({ b: d, tilts: null });
      } else if (rubble && st.ph === 'end') {
        for (const b of rubble) items.push({ b, tilts: null });
      } else {
        drawShadow(lv);
        for (const b of towerPoses(lv, sim)) items.push({ b, tilts });
      }
      if (fall || rubble) drawShadow(fall ? null : null);
      // the pulled block after it leaves the tower (replays)
      let free = null;
      if (anim && sim.k === 'p' && sim.out && !fall) {
        const c = centerXY(sim.lv, sim.l, sim.ks), ex = BL + 1.2, z = sim.l * H + H / 2;
        const k = clamp((sim.time() - sim.tOut) / 0.45, 0, 1), e = k * k * (3 - 2 * k);
        const a = [c[0] + (sim.ax === 0 ? sim.d * ex : 0), c[1] + (sim.ax === 1 ? sim.d * ex : 0), z], hp = handPos();
        free = { id: sim.id, c: [a[0] + (hp[0] - a[0]) * e, a[1] + (hp[1] - a[1]) * e, a[2] + (hp[2] - a[2]) * e], R: sim.ax ? YAW90 : ID3 };
      }
      // placement: block flying from the hand to its slot
      if (anim && sim.k === 'q' && anim.tw < 1) {
        const tl = sim.pl, c = centerXY(sim.lv, tl, sim.slot), hp = handPos(), e = anim.tw * anim.tw * (3 - 2 * anim.tw);
        const to = [c[0], c[1], tl * H + H / 2];
        free = { id: sim.id, c: [hp[0] + (to[0] - hp[0]) * e, hp[1] + (to[1] - hp[1]) * e, hp[2] + (to[2] - hp[2]) * e + Math.sin(e * Math.PI) * 2.5], R: tl % 2 ? YAW90 : ID3 };
        const ix = items.findIndex((it) => it.b.id === sim.id); if (ix >= 0) items.splice(ix, 1);
      }
      // sort far → near
      const depth = (it) => { const c = it.b.c; return (c[0] - B.pos[0]) * B.fw[0] + (c[1] - B.pos[1]) * B.fw[1] + (c[2] - B.pos[2]) * B.fw[2]; };
      // stacked boxes: levels vertically farthest from the eye first, then far → near inside a level (debris: by depth)
      for (const it of items) { it.dp = depth(it); it.lk = it.b.lvl != null ? -Math.round(Math.abs(it.b.lvl * H + H / 2 - B.pos[2]) / H * 2) : null; }
      items.sort((a, b) => (a.lk != null && b.lk != null && a.lk !== b.lk ? a.lk - b.lk : b.dp - a.dp));
      const mine = st && actor(st) != null && api.canAct(actor(st)) && !waitingNet();
      const pickable = mine && st.ph === 'pull' && !anim && !fall;
      const legalSet = pickable ? new Set(legalBlocks(lvS)) : null;
      for (const it of items) {
        let hl = null;
        if (sel && it.b.id === sel.id && !fall) hl = '#e3ae45';
        if (anim && anim.kind === 'live' && it.b.id === anim.id) hl = '#e3ae45';
        if (anim && anim.poke != null && it.b.id === anim.poke) hl = '#e3ae45';
        const r = drawBlock(it.b, it.tilts, { hl });
        if (r && (legalSet ? legalSet.has(it.b.id) : true) && !fall) polys.push({ id: it.b.id, faces: r.faces, c: r.c, legal: legalSet ? true : false });
        else if (r && pickable) polys.push({ id: it.b.id, faces: r.faces, c: r.c, legal: false });
      }
      // ghosts for the placement
      if (mine && st.ph === 'place' && !anim && !fall) {
        const tl = placeLevel(lvS), slots = legalSlots(lvS);
        const base = lvS[tl] || lvS[tl - 1] || { sx: 0, sy: 0 };
        if (slotSel < 0 || !slots.includes(slotSel)) slotSel = slots[0];
        for (const k of slots) {
          const off = (k - 1) * BW, c = tl % 2 === 0 ? [base.sx, base.sy + off, tl * H + H / 2] : [base.sx + off, base.sy, tl * H + H / 2];
          const f = drawGhost(c, tl % 2 ? YAW90 : ID3, k === slotSel);
          polys.push({ slot: k, faces: f, c: proj(c) });
        }
      }
      if (free) drawBlock(free, null, { hl: '#e3ae45' });
      else if (st.ph === 'place' && st.h >= 0 && !anim && !fall) drawBlock({ id: st.h, c: handPos(), R: placeLevel(lvS) % 2 ? YAW90 : ID3 }, null, { hl: 'rgba(227,174,69,.7)' });
      drawMeters(sim);
      drawBubble();
      if (flash) {
        const k = clamp((now - flash.t0) / 1300, 0, 1);
        if (k >= 1) flash = null; else {
          ctx.globalAlpha = k < 0.12 ? k / 0.12 : 1 - Math.max(0, (k - 0.6) / 0.4);
          const y = areaRect().top + 40, s = 1 + (1 - k) * 0.12;
          ctx.font = '400 ' + Math.round(34 * s) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, cv.w / 2, y);
          ctx.fillStyle = flash.c; ctx.fillText(flash.text, cv.w / 2, y);
          ctx.globalAlpha = 1;
        }
      }
    }
    function bar(x, y, w, label, v, col, mark) {
      ctx.fillStyle = 'rgba(23,19,31,.72)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, 22, 8) : ctx.rect(x, y, w, 22); ctx.fill();
      ctx.font = '700 10.5px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ab9fb8';
      ctx.fillText(label, x + 7, y + 11);
      const bx = x + 46, bw = w - 54;
      ctx.fillStyle = 'rgba(255,255,255,.1)'; ctx.fillRect(bx, y + 8, bw, 6);
      ctx.fillStyle = col; ctx.fillRect(bx, y + 8, bw * clamp(v, 0, 1), 6);
      if (mark != null) { ctx.fillStyle = '#f2e9d8'; ctx.fillRect(bx + bw * clamp(mark, 0, 1) - 1, y + 5, 2, 12); }
    }
    function drawMeters(sim) {
      if (!sim) return;
      const y = areaRect().top - 28, w = Math.min(170, cv.w * 0.44);
      const d = clamp(fall ? 1 : sim.dang, 0, 1);
      bar(8, y, w, '흔들림', d, d < 0.35 ? '#5fd3a0' : d < 0.7 ? '#e3ae45' : '#ee6a55');
      if (sim.k === 'p' && !sim.out) {
        const v = sim.Fp / 26000, need = anim && anim.need ? anim.need / 26000 : null;
        bar(cv.w - w - 8, y, w, '미는 힘', v, sim.vb > 0.05 ? '#5fd3a0' : '#e3ae45', need);
      }
    }
    /* drag guide on my selected block: the two ways it can slide out */
    function drawPullGuide(pg) {
      if (!myTurn() || st.ph !== 'pull') return;
      const a = axisScreen(sel.id, 1);
      let ux = a.ux, uy = a.uy;
      if (!(a.len >= 5)) { ux = 0; uy = 1; } // block points at the camera: drag up / down
      const t = performance.now() / 1000, Lg = 30 + 4 * Math.sin(t * 4), cx = pg.c[0], cy = pg.c[1];
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (const sg of [1, -1]) {
        const x0 = cx + ux * sg * 14, y0 = cy + uy * sg * 14, x1 = cx + ux * sg * (14 + Lg), y1 = cy + uy * sg * (14 + Lg);
        const hx = -uy, hy = ux, ax = x1 - ux * sg * 8, ay = y1 - uy * sg * 8;
        for (const [col, lw] of [['rgba(23,19,31,.75)', 6], ['#e3ae45', 2.6]]) {
          ctx.strokeStyle = col; ctx.lineWidth = lw;
          ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1);
          ctx.moveTo(ax + hx * 6, ay + hy * 6); ctx.lineTo(x1, y1); ctx.lineTo(ax - hx * 6, ay - hy * 6); ctx.stroke();
        }
      }
    }
    function drawBubble() {
      if (!sel || anim || fall) return;
      const pg = polys.find((p) => p.id === sel.id); if (!pg) return;
      drawPullGuide(pg);
      const lab = looseLabel(sel.bi), x = clamp(pg.c[0], 70, cv.w - 70), y = Math.max(areaRect().top + 4, pg.c[1] - 46);
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const tw = Math.max(92, ctx.measureText(lab.t).width + 20);
      ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x - tw / 2, y - 16, tw, 34, 9) : ctx.rect(x - tw / 2, y - 16, tw, 34); ctx.fill();
      ctx.strokeStyle = lab.c; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = lab.c; ctx.fillText(lab.t, x, y - 5);
      for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(x - 20 + i * 10, y + 9, 3, 0, 7); ctx.fillStyle = i < lab.n ? lab.c : 'rgba(255,255,255,.18)'; ctx.fill(); }
    }

    /* ---- input ---- */
    function waitingNet() { return sentAt && performance.now() - sentAt < 6000; }
    function myTurn() { return st && st.ph !== 'end' && actor(st) != null && api.canAct(actor(st)) && !waitingNet(); }
    function inPoly(p, q) { let c = false; for (let i = 0, j = q.length - 1; i < q.length; j = i++) { if ((q[i][1] > p.y) !== (q[j][1] > p.y) && p.x < (q[j][0] - q[i][0]) * (p.y - q[i][1]) / (q[j][1] - q[i][1]) + q[i][0]) c = !c; } return c; }
    function pick(p, filt) {
      for (let i = polys.length - 1; i >= 0; i--) { const g = polys[i]; if (filt && !filt(g)) continue; for (const f of g.faces) if (inPoly(p, f)) return g; }
      let best = null, bd = 22 * 22;
      for (const g of polys) { if (filt && !filt(g)) continue; const d = (g.c[0] - p.x) ** 2 + (g.c[1] - p.y) ** 2; if (d < bd) { bd = d; best = g; } }
      return best;
    }
    function axisScreen(id, d) {
      const pos = findBlock(lvS, id); if (!pos) return { ux: 1, uy: 0, ppc: 12 };
      const c = centerXY(lvS, pos[0], pos[1]), z = pos[0] * H + H / 2, ax = pos[0] % 2;
      const p0 = proj([c[0], c[1], z]), p1 = proj([c[0] + (ax === 0 ? d : 0), c[1] + (ax === 1 ? d : 0), z]);
      const vx = p1[0] - p0[0], vy = p1[1] - p0[1], len = Math.hypot(vx, vy);
      if (len >= 5) return { ux: vx / len, uy: vy / len, ppc: Math.max(len, 10), len };
      const away = (ax === 0 ? d * B.fw[0] : d * B.fw[1]) > 0;
      return { ux: 0, uy: away ? -1 : 1, ppc: 12, len };
    }
    function select(id) {
      const bi = blockInfo(lvS, P, id), pos = findBlock(lvS, id), c = centerXY(lvS, pos[0], pos[1]);
      const ax = pos[0] % 2, toCam = ax === 0 ? B.pos[0] - c[0] : B.pos[1] - c[1];
      const FP = 2600, dist = bi.Fs < FP ? Math.min(0.9, (FP - bi.Fs) / FP * 1.1) : 0.04;
      sel = { id, t0: performance.now(), dist, d: toCam >= 0 ? 1 : -1, bi };
      cam.ttz = pos[0] * H + H / 2; cam.tzoom = 1.3;
      api.sfx(bi.Fs < 4000 ? 'tick' : 'click'); api.buzz(bi.Fs < 4000 ? 8 : 18);
      renderHud();
    }
    function deselect() { sel = null; cam.tzoom = 1; renderHud(); }
    function startLive(id, d) {
      const prof = [];
      anim = { kind: 'live', id, d, prof, sim: new Sim(st.sd, { L: st.L, S: st.S }, { k: 'p', b: id, d, p: prof }, true), committed: false, sent: false, grab: null, tg: 0, need: sel ? sel.bi.Fs : null };
      simAcc = 0;
    }
    function startGrab(p) {
      const a = axisScreen(anim.id, anim.d);
      anim.grab = { x0: p.x, y0: p.y, s0: anim.sim.s, ux: a.ux, uy: a.uy, ppc: a.ppc };
      anim.tg = anim.sim.s;
    }
    function moveGrab(p) {
      const g = anim.grab; if (!g) return;
      const along = ((p.x - g.x0) * g.ux + (p.y - g.y0) * g.uy) / g.ppc;
      anim.tg = clamp(g.s0 + along, 0, QMAX * QSTEP);
    }
    function submitLive() {
      if (!anim || anim.kind !== 'live' || anim.sent) return;
      anim.sent = true; anim.sim.open = false; anim.grab = null; anim.pstr = encProf(anim.prof);
      ptr = null;
      if (!api.isHost) sentAt = performance.now();
      const a = { k: 'p', b: anim.id, d: anim.d, p: anim.pstr };
      api.setBusy(true);
      api.act(a);
      renderHud();
    }
    function cancelLive() { anim = null; api.sfx('click'); api.toast('살짝 건드리기만 했어요 — 다른 블록도 골라 보세요'); renderHud(); }
    function place(slot) {
      if (!myTurn() || st.ph !== 'place' || anim) return;
      api.sfx('whoosh'); api.buzz(12);
      if (!api.isHost) sentAt = performance.now();
      api.act({ k: 'q', slot });
    }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (ptr || !st) return;
      const p = cv.local(ev);
      ptr = { id: ev.pointerId, x0: p.x, y0: p.y, mode: 'pending', hit: null, yaw0: cam.tyaw, pitch0: cam.pitch };
      if (myTurn() && !fall) {
        if (st.ph === 'pull') {
          if (anim && anim.kind === 'live' && !anim.sent) {
            const g = pick(p, (q) => q.id === anim.id);
            if (g && Math.hypot(g.c[0] - p.x, g.c[1] - p.y) < 90) { ptr.mode = 'grab'; startGrab(p); api.buzz(8); }
          } else if (!anim) {
            // forgiving: once a block is selected, a touch on or near it grabs that block (not a neighbour)
            const sg = sel ? polys.find((q) => q.id === sel.id) : null;
            if (sg && (sg.faces.some((f) => inPoly(p, f)) || Math.hypot(sg.c[0] - p.x, sg.c[1] - p.y) < 34)) ptr.hit = sg;
            else ptr.hit = pick(p, (q) => q.id != null);
          }
        } else if (st.ph === 'place' && !anim) ptr.hit = pick(p, (q) => q.slot != null);
      }
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!ptr || ptr.id !== ev.pointerId) return;
      const p = cv.local(ev), dx = p.x - ptr.x0, dy = p.y - ptr.y0;
      if (ptr.mode === 'pending' && Math.hypot(dx, dy) > 9) {
        if (ptr.hit && sel && ptr.hit.id === sel.id && st.ph === 'pull' && !anim && myTurn()) {
          const a = axisScreen(sel.id, 1);
          const d = a.len >= 5 ? (dx * a.ux + dy * a.uy >= 0 ? 1 : -1) : ((dy < 0) === (a.uy < 0) ? 1 : -1);
          startLive(sel.id, d); ptr.mode = 'grab'; startGrab({ x: ptr.x0, y: ptr.y0 });
          api.buzz(10);
        } else ptr.mode = 'rot';
      }
      if (ptr.mode === 'rot') {
        cam.tyaw = ptr.yaw0 - dx * 0.011; cam.yaw = cam.tyaw;
        cam.pitch = clamp(ptr.pitch0 + dy * 0.004, 0.12, 0.95);
      } else if (ptr.mode === 'grab' && anim && anim.kind === 'live') moveGrab(p);
      dirty = true;
    });
    function endPtr(ev) {
      if (!ptr || ptr.id !== ev.pointerId) return;
      const pt = ptr; ptr = null;
      if (pt.mode === 'pending' && anim && anim.kind === 'replay' && !anim.ff && !api.canAct(anim.last.s)) { anim.ff = true; api.sfx('tick'); }
      if (pt.mode === 'pending' && myTurn() && !fall) {
        if (st.ph === 'pull' && !anim) {
          if (pt.hit && pt.hit.id != null) {
            if (!pt.hit.legal) { api.sfx('click'); api.toast('맨 위 완성된 층과 그 위에서는 뺄 수 없어요'); }
            else select(pt.hit.id);
          } else if (sel) deselect();
        } else if (st.ph === 'place' && !anim) {
          if (pt.hit && pt.hit.slot != null) { if (pt.hit.slot === slotSel) place(slotSel); else { slotSel = pt.hit.slot; api.sfx('tick'); renderHud(); } }
        }
      }
      if (pt.mode === 'grab' && anim && anim.kind === 'live' && !anim.sent) {
        anim.grab = null;
        if (!anim.committed && !anim.sim.col) cancelLive();
      }
      dirty = true;
    }
    cv.cv.addEventListener('pointerup', endPtr);
    cv.cv.addEventListener('pointercancel', endPtr);

    /* ---- HUD ---- */
    let hudKey = '';
    function renderHud(force) {
      if (!st) return;
      const a = anim && anim.kind === 'replay' ? anim.last.s : actor(st);
      const mine = a != null && api.canAct(a) && !anim && !fall && st.ph !== 'end';
      const lvls = lvS ? topInfo(lvS).top + 1 : 0;
      const key = [a, mine, st.ph, lvls, st.np, sel ? sel.id : -1, anim ? anim.kind + (anim.committed ? 1 : 0) + (anim.sent ? 1 : 0) : '', fall ? 1 : 0, slotSel, waitingNet() ? 1 : 0, st.al.length].join('|');
      if (key === hudKey && !force) return;
      hudKey = key;
      topEl.innerHTML = '';
      topEl.append(L.h('div', { class: 'panel mono jg-stats', style: { padding: '5px 10px', fontSize: '12px', display: 'flex', gap: '10px' } },
        L.h('span', null, L.h('b', { style: { color: 'var(--brass)' }, text: String(lvls) }), '층'),
        L.h('span', null, '뺀 블록 ', L.h('b', { style: { color: 'var(--brass)' }, text: String(st.np) }))));
      if (st.md === 'elim' && st.n > 2) topEl.append(L.h('div', { class: 'panel', style: { padding: '5px 10px', fontSize: '12px', fontWeight: 700 } }, '탈락전 ' + st.rd + '라운드 · ' + st.al.length + '명'));
      bot.innerHTML = '';
      if (st.ph === 'end' || a == null) return;
      let hint;
      if (fall) hint = '와르르!';
      else if (anim && anim.kind === 'replay') hint = (anim.last.k === 'p' ? (anim.poke != null ? '블록을 톡톡 건드려 보는 중…' : '블록을 빼는 중…') : '맨 위에 올리는 중…') + (api.canAct(anim.last.s) ? '' : ' · 탭하면 빨리 보기');
      else if (anim && anim.kind === 'live') hint = anim.sent ? '탑이 멈추길 기다리는 중…' : anim.committed ? '이 블록을 끝까지 빼야 해요 · 블록을 다시 끌어요' : '끌어서 빼기 · 1cm 전에 손을 떼면 취소';
      else if (mine && st.ph === 'pull') hint = sel ? '고른 블록을 끌어서 빼요 · 톡 누르면 다시 건드려 보기' : '블록을 톡 눌러 느슨한지 보세요 · 빈 곳을 끌면 회전';
      else if (mine && st.ph === 'place') hint = '맨 위 빈자리를 눌러 골라요';
      else if (waitingNet()) hint = '보내는 중…';
      else hint = api.players[a] && api.players[a].ai ? '생각 중…' : '차례를 기다리는 중';
      if (mine && st.ph === 'place') {
        bot.append(L.h('div', { style: { display: 'flex', gap: '8px' } },
          L.h('button', { class: 'btn primary jg-place', style: { flex: '1 1 auto', minHeight: '48px' }, text: '맨 위에 올리기', onclick: () => place(slotSel < 0 ? legalSlots(lvS)[0] : slotSel) })));
      }
      const rotBtn = (dir, t) => L.h('button', { class: 'btn jg-rot' + (dir < 0 ? ' l' : ' r'), 'aria-label': dir < 0 ? '왼쪽으로 돌리기' : '오른쪽으로 돌리기', style: { flex: 'none', width: '48px', padding: 0, fontSize: '20px' }, text: t,
        onclick: () => { cam.tyaw += dir * Math.PI / 4; api.sfx('tick'); dirty = true; } });
      bot.append(L.h('div', { style: { display: 'flex', gap: '8px', alignItems: 'stretch' } },
        rotBtn(-1, '⟲'),
        L.h('div', { class: 'panel jg-turn', style: { flex: '1 1 auto', minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '5px 10px', gap: '1px' } },
          L.h('div', { style: { fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } },
            L.h('span', { class: 'dot', style: { '--c': color(a), display: 'inline-block', marginRight: '6px' } }), nameOf(a)),
          L.h('div', { class: 'muted', style: { fontSize: '11.5px', lineHeight: 1.3 }, text: hint })),
        rotBtn(1, '⟳')));
    }

    /* ---- collapse animation (view only) ---- */
    function startFall(sim) {
      const lv = sim.lv, c = sim.col, poses = towerPoses(lv, sim);
      if (sim.k === 'p' && !sim.out) { /* still in the tower: part of poses */ }
      const tl0 = tiltsOf(sim).filter((t) => t.j !== c.j);
      const body = [], stand = [];
      for (const b of poses) {
        const bb = { id: b.id, lvl: b.lvl, c: b.c, R: blockR(b, tl0) };
        const pts = blockCorners(b, tl0); bb.c = [(pts[0][0] + pts[7][0]) / 2, (pts[0][1] + pts[7][1]) / 2, (pts[0][2] + pts[7][2]) / 2];
        bb.lvl = b.lvl;
        (b.lvl >= c.i ? body : stand).push(bb);
      }
      if (sim.k === 'p' && sim.out) {
        const cc = centerXY(lv, sim.l, sim.ks);
        body.push({ id: sim.id, lvl: 999, c: [cc[0] + (sim.ax === 0 ? sim.d * (BL + 1.2) : 0), cc[1] + (sim.ax === 1 ? sim.d * (BL + 1.2) : 0), sim.l * H + H / 2], R: sim.ax ? YAW90 : ID3 });
      }
      const sg = c.sg, al = c.a < 0 ? c.a : Math.min(c.a, 0.05);
      fall = { phase: 'tip', body, stand, j: c.j, sg, th: Math.abs(c.th) || 0.001, om: Math.abs(c.om) + 0.05, al, p2: 0.75 * G / Math.max(4, c.R), i: c.i, e: c.e, t: 0, deb: null, hitT: 0 };
      fall.tl = mkTilt();
      api.sfx('whoosh'); api.buzz(60);
      flash = { text: '와르르!', c: '#ee6a55', t0: performance.now() };
      renderHud();
    }
    function mkTilt() {
      const th = fall.sg * fall.th;
      let e = fall.e;
      if (!isFinite(e) || fall.al < -0.04) e = fall.j === 0 ? fall.sg * 2 : fall.sg * 2;
      return { j: fall.j, i: fall.i, e, zi: fall.i * H, cs: Math.cos(th), sn: Math.sin(th) };
    }
    function releaseDebris() {
      const tl = fall.tl, w = fall.sg * fall.om, wv = fall.j === 0 ? [0, w, 0] : [-w, 0, 0];
      const hinge = fall.j === 0 ? [tl.e, 0, tl.zi] : [0, tl.e, tl.zi];
      fall.deb = fall.body.map((b, n) => {
        const R = mmul(tiltMat(tl), b.R), c = tiltPt(b.c, tl);
        const r = [c[0] - hinge[0], c[1] - hinge[1], c[2] - hinge[2]], v = cross(wv, r);
        const h1 = hash(b.id, 11 + n) - 0.5, h2 = hash(b.id, 23 + n) - 0.5, h3 = hash(b.id, 37) - 0.5;
        if (fall.j === 0) wv[1] === wv[1];
        return { id: b.id, lvl: null, c, R, v: [v[0] + h1 * 14, v[1] + h2 * 14, v[2] + h3 * 6], w: [wv[0] + h2 * 3, wv[1] + h1 * 3, h3 * 4], sl: 0 };
      });
      // the standing part becomes static colliders
      fall.statics = fall.stand.map((b) => ({ c: b.c, R: b.R }));
      fall.phase = 'deb'; fall.t = 0;
    }
    function spheres(b) { const out = []; for (const x of [-2.5, 0, 2.5]) { const l = mv3(b.R, x, 0, 0); out.push([b.c[0] + l[0], b.c[1] + l[1], b.c[2] + l[2]]); } return out; }
    function applyImp(b, r, J) {
      b.v[0] += J[0]; b.v[1] += J[1]; b.v[2] += J[2];
      const tq = cross(r, J), lt = mtv3(b.R, tq[0], tq[1], tq[2]);
      const dw = mv3(b.R, lt[0] * II[0], lt[1] * II[1], lt[2] * II[2]);
      b.w[0] += dw[0]; b.w[1] += dw[1]; b.w[2] += dw[2];
    }
    function kEff(b, r, n) {
      const rn = cross(r, n), lt = mtv3(b.R, rn[0], rn[1], rn[2]), iw = mv3(b.R, lt[0] * II[0], lt[1] * II[1], lt[2] * II[2]), q = cross(iw, r);
      return 1 + q[0] * n[0] + q[1] * n[1] + q[2] * n[2];
    }
    function velAt(b, r) { const wr = cross(b.w, r); return [b.v[0] + wr[0], b.v[1] + wr[1], b.v[2] + wr[2]]; }
    function debStep(dt) {
      const D = fall.deb; let hits = 0;
      for (const b of D) {
        if (b.sl > 0.35) continue;
        b.v[2] -= G * dt;
        b.c[0] += b.v[0] * dt; b.c[1] += b.v[1] * dt; b.c[2] += b.v[2] * dt;
        const wl = Math.hypot(b.w[0], b.w[1], b.w[2]);
        if (wl > 1e-6) {
          const a = wl * dt, k = [b.w[0] / wl, b.w[1] / wl, b.w[2] / wl], s = Math.sin(a), c = 1 - Math.cos(a);
          const K = [0, -k[2], k[1], k[2], 0, -k[0], -k[1], k[0], 0], K2 = mmul(K, K);
          const Q = ID3.map((v, i) => v + s * K[i] + c * K2[i]);
          b.R = mmul(Q, b.R);
        }
        // ground contact at the corners
        const d = dimsOf(b.id);
        for (let q = 0; q < 8; q++) {
          const l = mv3(b.R, q & 1 ? d[0] : -d[0], q & 2 ? d[1] : -d[1], q & 4 ? d[2] : -d[2]);
          const pz = b.c[2] + l[2];
          if (pz >= 0) continue;
          const r = l, vel = velAt(b, r);
          if (vel[2] < 0) {
            const n = [0, 0, 1], jn = -(1 + 0.25) * vel[2] / kEff(b, r, n);
            applyImp(b, r, [0, 0, jn]);
            if (jn > 25) hits++;
            const v2 = velAt(b, r), vt = Math.hypot(v2[0], v2[1]);
            if (vt > 1e-4) { const t = [-v2[0] / vt, -v2[1] / vt, 0], jt = Math.min(0.5 * jn, vt / kEff(b, r, t)); applyImp(b, r, [t[0] * jt, t[1] * jt, 0]); }
          }
          b.c[2] -= pz * 0.6;
        }
        b.v[0] *= 0.999; b.v[1] *= 0.999; b.w[0] *= 0.995; b.w[1] *= 0.995; b.w[2] *= 0.995;
      }
      // block ↔ block (three spheres per block)
      const all = D.concat(fall.statics.map((s) => ({ c: s.c, R: s.R, st: 1 })));
      for (const b of all) b._s = spheres(b);
      for (let i = 0; i < D.length; i++) {
        const A = D[i];
        for (let j = i + 1; j < all.length; j++) {
          const Bb = all[j];
          if (A.sl > 0.35 && (Bb.st || Bb.sl > 0.35)) continue;
          const dx = Bb.c[0] - A.c[0], dy = Bb.c[1] - A.c[1], dz = Bb.c[2] - A.c[2];
          if (dx * dx + dy * dy + dz * dz > 72) continue;
          for (const pa of A._s) for (const pb of Bb._s) {
            let nx = pb[0] - pa[0], ny = pb[1] - pa[1], nz = pb[2] - pa[2]; const d2 = nx * nx + ny * ny + nz * nz;
            if (d2 >= 1.44 * 1.0 || d2 < 1e-8) continue;
            const dd = Math.sqrt(d2); nx /= dd; ny /= dd; nz /= dd;
            const pen = 1.2 - dd, cp = [(pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, (pa[2] + pb[2]) / 2];
            const ra = [cp[0] - A.c[0], cp[1] - A.c[1], cp[2] - A.c[2]], rb = [cp[0] - Bb.c[0], cp[1] - Bb.c[1], cp[2] - Bb.c[2]];
            const va = velAt(A, ra), vb = Bb.st ? [0, 0, 0] : velAt(Bb, rb);
            const vn = (vb[0] - va[0]) * nx + (vb[1] - va[1]) * ny + (vb[2] - va[2]) * nz;
            const n = [nx, ny, nz];
            if (vn < 0) {
              const k = kEff(A, ra, n) + (Bb.st ? 0 : kEff(Bb, rb, n)), jn = -(1.2) * vn / k;
              applyImp(A, ra, [-nx * jn, -ny * jn, -nz * jn]); if (!Bb.st) applyImp(Bb, rb, [nx * jn, ny * jn, nz * jn]);
              if (jn > 40) hits++;
              A.sl = 0; if (!Bb.st) Bb.sl = 0;
            }
            const cw = Bb.st ? pen * 0.5 : pen * 0.25;
            A.c[0] -= nx * cw; A.c[1] -= ny * cw; A.c[2] -= nz * cw;
            if (!Bb.st) { Bb.c[0] += nx * cw; Bb.c[1] += ny * cw; Bb.c[2] += nz * cw; }
          }
        }
      }
      for (const b of D) {
        const sp = Math.hypot(b.v[0], b.v[1], b.v[2]), ws = Math.hypot(b.w[0], b.w[1], b.w[2]);
        if (sp < 2.5 && ws < 1.2 && b.c[2] < 3) { b.sl += dt; if (b.sl > 0.35) { b.v = [0, 0, 0]; b.w = [0, 0, 0]; } } else b.sl = 0;
      }
      return hits;
    }
    function fallTick(dt) {
      fall.t += dt;
      if (fall.phase === 'tip') {
        const acc = fall.p2 * (fall.th - fall.al) + 2;
        fall.om += acc * dt; fall.th += fall.om * dt;
        fall.tl = mkTilt();
        if (fall.th > 0.5 || fall.t > 2.2) releaseDebris();
        return;
      }
      let h = 0; const n = Math.max(1, Math.ceil(dt / (1 / 200)));
      for (let i = 0; i < n; i++) h += debStep(dt / n);
      if (h && fall.t - fall.hitT > 0.06) { fall.hitT = fall.t; api.sfx(h > 3 ? 'thud' : 'chip'); if (h > 4) api.buzz(15); }
      const still = fall.deb.every((b) => b.sl > 0.35);
      if (still || fall.t > 4.5) endFall();
    }
    function endFall() {
      if (!fall) return;
      rubble = fall.stand.map((b) => ({ id: b.id, c: b.c, R: b.R })).concat((fall.deb || []).map((b) => ({ id: b.id, c: b.c, R: b.R })));
      fall = null; anim = null; sel = null; cam.tzoom = 1;
      lvS = st ? decode(st) : lvS;
      if (st && st.ph !== 'end') {
        rubble = null;
        const l = st.last, who = l ? nameOf(l.s) : '';
        api.toast(who + ' 탈락! 새 탑을 쌓고 계속해요', 2400);
      }
      api.setBusy(false);
      renderHud(true); dirty = true;
    }

    /* ---- replays ---- */
    function startReplay(last) {
      const sim = new Sim(last.sd, last.pre, last.k === 'p' ? { k: 'p', b: last.a.b, d: last.a.d, p: last.a.p } : { k: 'q', b: last.a.b, slot: last.a.slot });
      anim = { kind: 'replay', sim, last, tw: last.k === 'q' ? 0 : 1, pokes: last.k === 'p' && last.a.pk ? last.a.pk.slice() : [], poke: null, pt: 0 };
      lvS = decode(last.pre); P = props(last.sd);
      sel = null; cam.tzoom = 1;
      if (last.k === 'p') {
        // turn the camera so the pulled block is in view
        const pos = findBlock(lvS, last.a.b);
        if (pos) {
          const ax = pos[0] % 2, side = pos[1] - 1 || 0.6, ex = last.a.d;
          const vx = ax === 0 ? ex * 0.8 : side, vy = ax === 0 ? side : ex * 0.8;
          let ty = Math.atan2(vy, vx); while (ty - cam.tyaw > Math.PI) ty -= 2 * Math.PI; while (ty - cam.tyaw < -Math.PI) ty += 2 * Math.PI;
          if (!api.canAct(last.s)) cam.tyaw = ty;
          cam.ttz = pos[0] * H + H / 2; cam.tzoom = 1.25;
        }
      }
      simAcc = 0;
      api.setBusy(true);
      renderHud();
    }
    function finishAnim() {
      const a = anim; if (!a) return;
      const sim = a.sim;
      if (sim.col) { startFall(sim); return; }
      if (a.kind === 'replay' || a.sent) {
        if (sim.peak > 0.72) { flash = { text: '아슬아슬!', c: '#e3ae45', t0: performance.now() }; api.sfx('pop'); api.buzz(25); }
        else if (sim.k === 'q') { api.sfx('thud'); }
      }
      anim = null; cam.tzoom = 1;
      lvS = decode(st); P = props(st.sd);
      api.setBusy(false);
      renderHud(true); dirty = true;
    }

    /* ---- main loop ---- */
    const stop = U.loop((dt, now) => {
      if (!alive) return;
      // camera easing
      let dy = cam.tyaw - cam.yaw; cam.yaw += dy * Math.min(1, dt * 7);
      cam.tz += (cam.ttz - cam.tz) * Math.min(1, dt * 5); cam.zoom += (cam.tzoom - cam.zoom) * Math.min(1, dt * 5);
      if (Math.abs(dy) > 1e-4 || Math.abs(cam.ttz - cam.tz) > 1e-3 || Math.abs(cam.tzoom - cam.zoom) > 1e-3) dirty = true;
      if (fall) { fallTick(dt * L.debug.speed); dirty = true; }
      else if (anim) {
        const sim = anim.sim, sp = L.debug.speed * (anim.ff ? 3 : 1); // a tap fast-forwards someone else's turn
        if (anim.kind === 'replay' && anim.pokes.length || anim.poke != null) {
          // AI pokes a couple of blocks first
          anim.pt += dt * sp;
          if (anim.poke == null) { anim.poke = anim.pokes.shift(); anim.pt = 0; const pos = findBlock(lvS, anim.poke); if (pos) { sel = { id: anim.poke, t0: now, dist: 0.5, d: 1, bi: blockInfo(lvS, P, anim.poke) }; const bi = sel.bi; sel.dist = bi.Fs < 2600 ? Math.min(0.9, (2600 - bi.Fs) / 2600 * 1.1) : 0.04; api.sfx('tick'); } renderHud(); }
          else if (anim.pt > 0.5) { anim.poke = null; sel = null; if (!anim.pokes.length) renderHud(); }
          dirty = true;
        } else if (anim.tw < 1) { anim.tw = Math.min(1, anim.tw + dt * sp / 0.38); dirty = true; if (anim.tw >= 1) { api.sfx('thud'); api.buzz(12); } }
        else {
          simAcc += dt * sp;
          let n = 0; const s0 = sim.k === 'p' ? sim.s : 0;
          while (simAcc >= DT && !sim.done && n < 2000) {
            if (anim.kind === 'live' && !anim.sent && sim.need()) {
              if (anim.prof.length >= PMAX) { submitLive(); continue; }
              anim.prof.push(anim.grab ? clamp(Math.round(anim.tg / QSTEP), 0, QMAX) : 0);
            }
            sim.step(); simAcc -= DT; n++;
            if (anim.kind === 'live' && !anim.sent) {
              if (!anim.committed && sim.s >= COMMIT) { anim.committed = true; api.buzz(10); renderHud(); }
              if (sim.out || sim.col) { if (sim.out) { api.sfx('pop'); api.buzz(14); } submitLive(); }
            }
          }
          if (sim.k === 'p' && !sim.out) {
            const ds = sim.s - s0;
            if (ds > 0.02 && now - lastCreak > 70 / Math.max(1, sp)) { lastCreak = now; api.sfx('tick'); }
          }
          if (anim.kind === 'replay' && sim.k === 'p' && sim.out && !anim.popped) { anim.popped = 1; api.sfx('pop'); }
          if (sim.done && !(anim.kind === 'live' && !anim.sent)) finishAnim();
          dirty = true;
        }
        if (anim && anim.kind === 'live' && !anim.sent) renderHud();
      }
      if (sel || (st && st.ph === 'place') || flash || ptr) dirty = true;
      if (dirty) { dirty = false; drawScene(now); }
    });
    cv.onresize = () => { dirty = true; };
    // test hook (headless runner): screen positions of pickable blocks/slots and the selected block's pull axis
    cv.cv._dbg = () => ({ polys: polys.map((g) => ({ id: g.id, slot: g.slot, x: g.c[0], y: g.c[1], legal: g.legal })), sel: sel ? sel.id : null, axis: sel ? axisScreen(sel.id, 1) : null, anim: anim ? anim.kind : null, ph: st && st.ph });

    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        const l = next.last;
        if (!prev) {
          lvS = decode(next); P = props(next.sd);
          if (next.ph === 'end' && l && l.col) {
            const sm = new Sim(l.sd, l.pre, l.k === 'p' ? { k: 'p', b: l.a.b, d: l.a.d, p: l.a.p } : { k: 'q', b: l.a.b, slot: l.a.slot }).run();
            P = props(l.sd);
            if (sm.col) rubble = towerPoses(sm.lv, sm).filter((b) => b.lvl < sm.col.i).map((b) => ({ id: b.id, c: b.c, R: b.R }));
          }
        } else if (prev !== next && l && (!prev.last || prev.last.id !== l.id)) {
          if (fall) endFall();
          if (l.k === 'p' && anim && anim.kind === 'live' && anim.sent && anim.id === l.a.b && anim.pstr === l.a.p) {
            anim.kind = 'replay'; anim.last = l; anim.pokes = []; anim.poke = null; anim.tw = 1;
            if (anim.sim.done) finishAnim();
          } else {
            if (anim && anim.kind === 'live') anim = null;
            rubble = null;
            startReplay(l);
          }
        } else if (!anim && !fall) { lvS = decode(next); P = props(next.sd); }
        if (next.ph !== 'end' && !anim && !fall) rubble = null;
        if (next.ph === 'place') { const sl = legalSlots(decode(next)); if (!sl.includes(slotSel)) slotSel = sl[0]; } else slotSel = -1;
        if (sel && (next.ph !== 'pull' || !legalBlocks(decode(next)).includes(sel.id))) sel = null;
        renderHud(true); dirty = true;
      },
      destroy() { alive = false; stop(); cv.destroy(); topEl.remove(); bot.remove(); api.setBusy(false); },
    };
  }

  L.register({
    id: 'jenga', name: '블록 탑 빼기', tag: '나무 블록 탑', cat: '파티',
    blurb: '나무 블록 탑에서 하나를 살살 빼서 맨 위에 올려요. 헐거운 블록을 찾아 조심히 빼고, 탑을 무너뜨린 사람이 집니다.',
    minPlayers: 1, maxPlayers: 6, defaultPlayers: 3, hidden: false, aiDelay: 900,
    tint: '#5c3a1a',
    icon: '<rect x="12" y="41" width="32" height="7" rx="1.5" fill="currentColor"/><rect x="12" y="32" width="9.5" height="7" rx="1.5" fill="currentColor"/><rect x="34.5" y="32" width="9.5" height="7" rx="1.5" fill="currentColor"/><rect x="12" y="23" width="32" height="7" rx="1.5" fill="currentColor"/><rect x="12" y="14" width="9.5" height="7" rx="1.5" fill="currentColor"/><rect x="23.25" y="14" width="9.5" height="7" rx="1.5" fill="currentColor"/><rect x="34.5" y="14" width="9.5" height="7" rx="1.5" fill="currentColor"/><rect x="31" y="32" width="14" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="2" stroke-dasharray="3 2" transform="translate(-8 0)"/><path d="M46 35.5h7M50 32.5l3 3-3 3" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
    options: [{ id: 'rule', label: '승부 방식', choices: [{ v: 'one', label: '무너뜨린 사람 패배' }, { v: 'elim', label: '탈락전(순위)' }], def: 'one' }],
    quick: [
      '탑에서 블록 1개를 빼서 맨 위에 올려요. 탑을 무너뜨린 사람이 져요.',
      '내 차례: 블록을 톡 눌러 헐거운지 보고 → 노란 화살표 쪽으로 끌어 빼고 → 맨 위 빈자리에 올려요.',
      '초록 「헐거움」 블록을 고르고, 위쪽 「흔들림」 막대가 빨개지기 전에 살살 빼세요.',
    ],
    rules: [
      { h: '목표', p: [
        '나무 블록 54개로 쌓은 18층 탑이에요. 한 층에 3개씩, 층마다 방향이 엇갈려 있어요.',
        '돌아가며 블록을 1개씩 빼서 맨 위에 올려요.',
        '탑을 무너뜨린 사람이 지고, 나머지는 모두 이겨요.'] },
      { h: '준비', p: [
        '탑은 자동으로 쌓여요. 첫 번째 사람부터 시작해요.',
        '혼자 하면(1명) 몇 개까지 빼는지 도전하는 연습 모드예요.'] },
      { h: '차례에 할 일', p: [
        '① 블록 고르기: 블록을 톡 누르면 살짝 밀어 봐요. 블록 위에 「헐거움 ~ 꽉 낌」 표시와 점 5개가 떠요. 초록이고 점이 많을수록 쉽게 빠져요.',
        '마음에 안 들면 다른 블록을 또 톡 눌러 봐도 돼요. 몇 번이든 괜찮아요.',
        '② 빼기: 고른 블록을 노란 화살표 쪽으로 끌어요. 손가락을 멀리·빨리 끌수록 세게 밀어요(오른쪽 위 「미는 힘」 막대).',
        '③ 올리기: 다 빠지면 맨 위 빈자리를 눌러 고르고, 한 번 더 누르거나 「맨 위에 올리기」를 눌러요.',
        '④ 올린 블록이 자리를 잡고 탑이 멈추면 다음 사람 차례예요.'] },
      { h: '뺄 수 있는 블록', p: [
        '맨 위의 완성된 층(3개가 다 찬 층)에서는 뺄 수 없어요.',
        '맨 위 층이 덜 찼으면, 그 층과 바로 아래 층에서도 뺄 수 없어요.',
        '맨 위 층이 3개로 차면, 다음 블록은 방향을 바꿔 새 층을 시작해요.'] },
      { h: '점수·승리', p: [
        '빼는 중이든 올리는 중이든 탑이 쓰러지면 그 차례 사람이 져요. 나머지는 모두 승리!',
        '「탈락전」 옵션: 무너뜨린 사람만 탈락하고, 새 탑으로 계속해요. 마지막까지 남은 사람이 1위예요.',
        '아주 오래(80번) 버티면 탑이 버틴 것으로 모두 승리해요.'] },
      { h: '특수 규칙', p: [
        '1cm 넘게 뺀 블록은 끝까지 빼야 해요. 1cm 전에 손을 떼면 취소돼서 다른 블록을 골라도 돼요.',
        '톡 건드려 보기는 마음대로 해도 돼요(벌칙 없음).',
        '블록마다 두께와 마찰이 조금씩 달라요. 위층 무게를 거의 안 받는 블록은 헐겁고, 무게를 많이 받는 블록은 빡빡해요.',
        '「꽉 낌 · 위층이 같이 밀려요」 블록을 세게 밀면 위층이 같이 끌려가고 탑이 흔들려요.',
        '왼쪽 위 「흔들림」 막대가 노랑 → 빨강이 되면 위험해요. 블록을 뺄수록 받침이 좁아져서 잘 쓰러져요.'] },
      { h: '조작', p: [
        '빈 곳을 좌우로 끌거나 ⟲ ⟳ 버튼 → 탑 돌리기. 위아래로 끌면 내려다보는 각도가 바뀌어요.',
        '블록 톡 → 건드려 보기 · 고르기. 고른 블록을 끌기 → 빼기. 손을 떼면 멈춰요.',
        '맨 위 빈자리 톡 → 올릴 자리 고르기, 한 번 더 톡(또는 「맨 위에 올리기」) → 올리기.',
        '다른 사람 차례에는 화면을 톡 누르면 빨리 볼 수 있어요.',
        '맨 아래 안내 줄이 지금 할 일을 알려 줘요.'] },
      { h: '예시', p: [
        '가운데 블록을 톡 → 「헐거움 ●●●●●」(초록). 좋아요!',
        '화살표 쪽으로 천천히 끌기 → 흔들림 막대는 초록 그대로, 블록이 쏙 빠져요.',
        '맨 위 빈자리를 톡, 한 번 더 톡 → 올라가요. 탑이 멈추면 다음 사람 차례.',
        '반대로 「꽉 낌」 블록을 세게 끌면 위층이 같이 밀려 와르르! → 내가 진 거예요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 블록을 여러 개 건드려 보고 헐겁고 안전한 블록을 골라 조심스럽게 빼요.'] },
    ],
    tutorial: [
      { text: '나무 블록 탑에서 블록을 하나씩 빼서 맨 위에 올려요. 탑을 무너뜨린 사람이 져요!' },
      { sel: '.jg-stats', text: '여기에 지금 탑 높이(층)와 지금까지 뺀 블록 수가 보여요.' },
      { text: '내 차례엔 먼저 블록을 톡 눌러 보세요. 살짝 밀어 보고 「헐거움 ~ 꽉 낌」 표시가 떠요. 초록이고 점이 많을수록 쉽게 빠져요. 맨 위 층(과 덜 찬 맨 위 층 바로 아래)은 못 빼요.' },
      { text: '고른 블록을 노란 화살표 쪽으로 끌어서 빼요. 멀리·빨리 끌수록 세게 밀어요. 1cm 전에 손을 떼면 취소, 1cm 넘게 빼면 끝까지 빼야 해요.' },
      { text: '빼는 동안 왼쪽 위 「흔들림」 막대를 보세요. 빨개지면 탑이 무너지기 직전이에요!' },
      { sel: '.jg-rot.r', text: '⟲ ⟳ 버튼(또는 빈 곳 끌기)으로 탑을 돌려 다른 면의 블록도 볼 수 있어요.' },
      { sel: '.jg-turn', text: '다 빼면 맨 위 빈자리를 눌러 고르고, 한 번 더 누르거나 「맨 위에 올리기」를 눌러요. 막히면 이 안내 줄을 보세요. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _sim: { Sim, analyze, loads, blockInfo, legalBlocks, legalSlots, topInfo, decode, encode, initialTower, props, encProf, decProf, runPolicy, minAlpha, placeBlock, findBlock, cloneLv },
  });
})();
