/* 개미 군단 영토전 — realtime ant-colony territory war (2–4).
   Your nests grow ants by themselves. Drag from your nests (swipe across several to gather them) to any nest: a column
   of ants marches there and either reinforces your nest or fights the defenders one for one; at 0 defenders the nest is
   yours. Win by wiping out the other colonies, or hold the most nests (then ants) when the timer ends.
   Host-authoritative: the host / local phone runs the colony sim in fixed 50 ms steps; guests send queued, acked
   "send" commands and receive ~10 Hz snapshots of nests and columns, advancing the columns locally in between.
   One person per phone: locally you command seat 0 against AI colonies; friends play through online / LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const STEP = 0.05, V = 30, COUNT = 3, HOME0 = 15, MAX_G = 16;
  const SZ_R = [0, 10, 13, 16], SZ_CAP = [0, 25, 45, 70], SZ_RATE = [0, 0.7, 1.0, 1.4];
  const FARM_K = 2, QUEEN_K = 1.3, FORT_K = 1.5, QUEEN_CAP = 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const fin = (v) => typeof v === 'number' && isFinite(v);

  /* maps: per-player wedge template in polar form [r, φ (fraction of the wedge, −.5….5), size 1–3, kind, defenders].
     Kinds: n 둥지, f 진딧물 농장 (2× growth), q 여왕방 (owner's nests all grow 1.3×, holds 100), t 돌 요새 (1.5× defence).
     φ = .5 sits on the border between two players and is placed once per player. c = centre nests [size, kind, def].
     Every player gets the exact same wedge, rotated (2p/3p) and then stretched to portrait (2p/4p keep mirror symmetry). */
  const MAPS = [
    { id: 'yard', name: '앞마당 흙밭', sub: '기본 맵. 가운데 큰 둥지가 승부처예요', hr: 118,
      t: [[80, -0.22, 1, 'n', 8], [80, 0.22, 1, 'n', 8], [50, 0, 2, 'n', 14], [110, 0.5, 2, 'n', 16]], c: [[3, 'n', 30]] },
    { id: 'farm', name: '진딧물 농장', sub: '초록 잎 농장은 개미가 두 배로 빨리 늘어요', hr: 118,
      t: [[78, -0.25, 1, 'f', 12], [78, 0.25, 1, 'f', 12], [45, 0, 1, 'n', 6], [115, 0.5, 2, 'f', 20]], c: [[2, 'f', 25]] },
    { id: 'queen', name: '여왕의 방', sub: '가운데 여왕방을 가지면 내 둥지가 모두 빨리 자라요', hr: 120,
      t: [[85, -0.2, 1, 'n', 6], [85, 0.2, 1, 'n', 6], [62, 0.5, 2, 't', 18]], c: [[3, 'q', 45]] },
    { id: 'fort', name: '돌 요새', sub: '돌 요새는 지키는 개미가 1.5배로 버텨요', hr: 118,
      t: [[70, 0, 2, 't', 12], [100, -0.3, 1, 'n', 7], [100, 0.3, 1, 'n', 7], [120, 0.5, 2, 'n', 16]], c: [[2, 't', 24]] },
    { id: 'field', name: '넓은 들판', sub: '작은 둥지가 많고 길이 멀어요', hr: 126,
      t: [[95, -0.3, 1, 'n', 5], [95, 0.3, 1, 'n', 5], [65, -0.15, 1, 'n', 7], [65, 0.15, 1, 'n', 7], [40, 0.5, 1, 'n', 9], [126, 0.5, 1, 'n', 9]], c: [[2, 'n', 18]] },
    { id: 'pond', name: '연못 정원', sub: '가운데 연못을 빙 돌아서 가야 해요', hr: 122, pond: 32,
      t: [[88, -0.25, 1, 'n', 7], [88, 0.25, 1, 'n', 7], [60, 0, 2, 'f', 16], [70, 0.5, 2, 'n', 14], [125, 0.5, 1, 'n', 8]], c: [] },
  ];
  const STRETCH = { 2: 1.45, 3: 1, 4: 1.3 };
  function buildNests(mp, n) {
    const M = MAPS[mp], wedge = Math.PI * 2 / n, base = n === 4 ? Math.PI * 0.75 : Math.PI / 2, ys = STRETCH[n] || 1;
    const N = [];
    const add = (r, ang, sz, k, c, o) => N.push({ x: r1(r * Math.cos(ang)), y: r1(r * Math.sin(ang) * ys), sz, k, c, o, o0: o });
    for (const e of M.c) add(0, 0, e[0], e[1], e[2], -1);
    for (let i = 0; i < n; i++) add(M.hr, base + i * wedge, 3, 'h', HOME0, i);
    for (const e of M.t) for (let i = 0; i < n; i++) add(e[0], base + i * wedge + e[1] * wedge, e[2], e[3], e[4], -1);
    return N;
  }
  function newWorld(mp, n) {
    mp = clamp(mp | 0, 0, MAPS.length - 1);
    const M = MAPS[mp];
    return { mp, M, n, t: 0, N: buildNests(mp, n), G: [], gid: 0, out: [], rt: {}, pond: M.pond || 0, qm: 0 };
  }
  const capOf = (N) => (N.k === 'q' ? QUEEN_CAP : SZ_CAP[N.sz]);
  const defK = (N) => (N.k === 't' ? FORT_K : 1);
  const rateOf = (W, N) => SZ_RATE[N.sz] * (N.k === 'f' ? FARM_K : 1) * (N.o >= 0 && (W.qm & (1 << N.o)) ? QUEEN_K : 1);
  const colLen = (n) => clamp(n * 1.5, 6, 48);
  const homeOf = (W, s) => W.N.findIndex((q) => q.k === 'h' && q.o0 === s);

  /* path between two nests: straight, or a curve around the pond. Cached; identical on every device. */
  function route(W, a, b) {
    const key = a * 64 + b;
    let R = W.rt[key];
    if (R) return R;
    const A = W.N[a], B = W.N[b];
    let pts = [A.x, A.y, B.x, B.y];
    if (W.pond) {
      const dx = B.x - A.x, dy = B.y - A.y, l2 = dx * dx + dy * dy || 1;
      const u = clamp(-(A.x * dx + A.y * dy) / l2, 0, 1), px = A.x + dx * u, py = A.y + dy * u, d = Math.hypot(px, py);
      if (d < W.pond + 9) {
        const ll = Math.sqrt(l2);
        let nx, ny;
        if (d > 1) { nx = px / d; ny = py / d; } else { nx = -dy / ll; ny = dx / ll; }
        let k = W.pond + 13;
        for (let it = 0; it < 10; it++) {
          const cx = 2 * nx * k - (A.x + B.x) / 2, cy = 2 * ny * k - (A.y + B.y) / 2;
          pts = [];
          let mind = 1e9;
          for (let i = 0; i <= 16; i++) {
            const t = i / 16, a0 = (1 - t) * (1 - t), a1 = 2 * (1 - t) * t, a2 = t * t;
            const x = a0 * A.x + a1 * cx + a2 * B.x, y = a0 * A.y + a1 * cy + a2 * B.y;
            pts.push(x, y);
            if (i > 0 && i < 16) mind = Math.min(mind, Math.hypot(x, y));
          }
          if (mind >= W.pond + 7) break;
          k *= 1.12;
        }
      }
    }
    const cum = [0];
    for (let i = 2; i < pts.length; i += 2) cum.push(cum[cum.length - 1] + Math.hypot(pts[i] - pts[i - 2], pts[i + 1] - pts[i - 1]));
    R = { p: pts, c: cum, L: cum[cum.length - 1] || 1 };
    W.rt[key] = R;
    return R;
  }
  /* point at distance d along a route → o.x, o.y and unit direction o.ux, o.uy */
  function posAt(R, d, o) {
    const p = R.p, c = R.c;
    d = clamp(d, 0, R.L);
    let i = 1;
    while (i < c.length - 1 && c[i] < d) i++;
    const seg = c[i] - c[i - 1] || 1, u = (d - c[i - 1]) / seg;
    const x0 = p[2 * i - 2], y0 = p[2 * i - 1], x1 = p[2 * i], y1 = p[2 * i + 1];
    o.x = x0 + (x1 - x0) * u; o.y = y0 + (y1 - y0) * u;
    const l = Math.hypot(x1 - x0, y1 - y0) || 1;
    o.ux = (x1 - x0) / l; o.uy = (y1 - y0) / l;
    return o;
  }

  /* send: from each source the seat owns, floor(count × pct%) ants leave as one column. Returns the ants sent. */
  function send(W, seat, srcs, dst, pct) {
    if (!(dst >= 0 && dst < W.N.length) || !Array.isArray(srcs)) return 0;
    if (W.out.includes(seat)) return 0;
    pct = clamp(Math.round(+pct || 50), 1, 100);
    let made = 0, cnt = 0;
    for (const g of W.G) if (g.o === seat) cnt++;
    const done = [];
    for (const s0 of srcs) {
      const s = s0 | 0;
      if (s === dst || done.includes(s) || !(s >= 0 && s < W.N.length)) continue;
      done.push(s);
      const S = W.N[s];
      if (S.o !== seat) continue;
      const k = Math.floor(S.c * pct / 100 + 1e-9);
      if (k < 1) continue;
      // a column on the same road that has only just left takes the newcomers along
      let g = null;
      for (const q of W.G) if (q.o === seat && q.a === s && q.b === dst && q.m === q.n && q.h < 6) { g = q; break; }
      if (g) { g.n += k; g.m += k; }
      else {
        if (cnt >= MAX_G) continue;
        W.gid = (W.gid + 1) % 100000;
        W.G.push({ id: W.gid, o: seat, a: s, b: dst, n: k, m: k, h: 0 });
        cnt++;
      }
      S.c -= k; made += k;
    }
    return made;
  }
  /* k ants of seat o reach nest i */
  function land(W, i, o, k, hooks) {
    const N = W.N[i];
    if (N.o === o) { N.c += k; return; }
    const need = N.c * defK(N);
    if (k >= need - 1e-9) {
      const from = N.o;
      N.o = o; N.c = Math.max(0, k - need);
      if (hooks && hooks.cap) hooks.cap(i, from, o);
    } else N.c = Math.max(0, N.c - k / defK(N));
    if (hooks && hooks.hit) hooks.hit(i, o, k);
  }
  function stepWorld(W, dt, hooks) {
    W.t += dt;
    let qm = 0;
    for (const N of W.N) if (N.k === 'q' && N.o >= 0) qm |= 1 << N.o;
    W.qm = qm;
    for (const N of W.N) {
      if (N.o < 0) continue;
      const cap = capOf(N);
      if (N.c < cap) N.c = Math.min(cap, N.c + rateOf(W, N) * dt);
    }
    for (let i = W.G.length - 1; i >= 0; i--) {
      const g = W.G[i];
      g.h += V * dt;
      const R = route(W, g.a, g.b);
      if (g.h >= R.L) {
        const gap = colLen(g.n) / g.n;
        const arrived = Math.min(g.n, Math.floor((g.h - R.L) / gap + 1e-9) + 1);
        const k = arrived - (g.n - g.m);
        if (k > 0) { g.m -= k; land(W, g.b, g.o, k, hooks); }
      }
      if (g.m <= 0) W.G.splice(i, 1);
    }
    for (let s = 0; s < W.n; s++) {
      if (W.out.includes(s)) continue;
      let any = false;
      for (const N of W.N) if (N.o === s) { any = true; break; }
      if (!any) for (const g of W.G) if (g.o === s) { any = true; break; }
      if (!any) { W.out.push(s); if (hooks && hooks.out) hooks.out(s); }
    }
  }
  function scores(W) {
    const nests = new Array(W.n).fill(0), ants = new Array(W.n).fill(0);
    for (const N of W.N) if (N.o >= 0) { nests[N.o]++; ants[N.o] += N.c; }
    for (const g of W.G) ants[g.o] += g.m;
    return { nests, ants };
  }
  /* final order: survivors by nests then ants, then the fallen (last to fall first). rows [seat, nests, ants, alive] */
  function ranking(W) {
    const sc = scores(W), rows = [];
    for (let s = 0; s < W.n; s++) if (!W.out.includes(s)) rows.push([s, sc.nests[s], Math.floor(sc.ants[s]), 1]);
    rows.sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[0] - b[0]);
    for (let k = W.out.length - 1; k >= 0; k--) rows.push([W.out[k], 0, 0, 0]);
    return rows;
  }
  const aliveN = (W) => W.n - W.out.length;

  /* ----- AI ----- */
  const AIC = {
    1: { ev: [3.2, 4.8], first: 2.6, src: 1, mg: 4, mgK: 0.1, noise: 0.45, growth: 0, defend: 0, cons: 0.3, top: 4, gamble: 0.35, res: 0, dk: 0.2 },
    2: { ev: [1.8, 2.7], first: 1.6, src: 2, mg: 3, mgK: 0.2, noise: 0, growth: 1, defend: 0.55, cons: 0.6, top: 2, gamble: 0, res: 0.1, dk: 0.16 },
    3: { ev: [0.9, 1.35], first: 0.9, src: 4, mg: 2, mgK: 0.1, noise: 0, growth: 1, defend: 1, cons: 1, top: 1, gamble: 0, res: 0.12, dk: 0.1, guard: 0.4, focus: 1.25, far: 1 },
  };
  /* returns a list of {s:[src], d, p} commands or null */
  function aiThink(W, seat, mem, lv, dt, rnd) {
    const R = rnd || Math.random;
    const C = AIC[lv] || AIC[2];
    if (mem.t == null) mem.t = C.first * (0.7 + R() * 0.6);
    mem.t -= dt;
    if (mem.t > 0 || W.out.includes(seat)) return null;
    mem.t = C.ev[0] + R() * (C.ev[1] - C.ev[0]);
    const N = W.N, nn = N.length, mine = [];
    for (let i = 0; i < nn; i++) if (N[i].o === seat) mine.push(i);
    if (!mine.length) return null;
    const rl = (a, b) => route(W, a, b).L;
    const own = new Array(nn).fill(0), foe = new Array(nn).fill(0), same = new Array(nn).fill(0), foeEta = new Array(nn).fill(1e9);
    for (const g of W.G) {
      const eta = Math.max(0, rl(g.a, g.b) - g.h) / V;
      if (g.o === seat) own[g.b] += g.m;
      else if (g.o === N[g.b].o) same[g.b] += g.m;
      else { foe[g.b] += g.m; foeEta[g.b] = Math.min(foeEta[g.b], eta); }
    }
    const mk = (j, t, k) => ({ s: [j], d: t, p: clamp(Math.ceil(k * 100 / Math.max(1, N[j].c)), 1, 100) });
    // 어려움: keep a guard against enemy nests close enough to strike back
    const guard = new Array(nn).fill(0);
    if (C.guard) for (const j of mine) { let th = 0; for (let e = 0; e < nn; e++) if (N[e].o >= 0 && N[e].o !== seat && rl(e, j) < 120) th += N[e].c; guard[j] = th * C.guard / defK(N[j]); }
    const spare = (j) => N[j].c - (C.defend ? Math.max(0, foe[j] / defK(N[j]) - own[j]) : 0) - Math.max(C.res * N[j].c, guard[j]);
    // 1) defend a nest that is about to fall
    if (C.defend && R() < C.defend) {
      for (const i of mine) {
        if (!foe[i]) continue;
        const eta = foeEta[i], k = defK(N[i]);
        const have = (N[i].c + Math.min(Math.max(0, capOf(N[i]) - N[i].c), rateOf(W, N[i]) * eta) + own[i]) * k;
        let lack = (foe[i] - have) / k + 2;
        if (lack <= 2) continue;
        const helpers = mine.filter((j) => j !== i && rl(j, i) / V < eta + (lv >= 3 ? 0.4 : 2)).sort((a, b) => rl(a, i) - rl(b, i));
        const cmds = [];
        for (const j of helpers) {
          const sp = N[j].c - foe[j] - 1;
          if (sp < 2) continue;
          const kk = Math.min(sp, lack);
          cmds.push(mk(j, i, kk)); lack -= kk;
          if (lack <= 0 || cmds.length >= C.src) break;
        }
        if (cmds.length) return cmds;
      }
    }
    // 2) attack / expand: best value for the ants it costs
    let weak = -1;
    if (C.focus) { const sc = scores(W); let bw = 1e9; for (let o = 0; o < W.n; o++) if (o !== seat && !W.out.includes(o) && sc.ants[o] + sc.nests[o] * 10 < bw) { bw = sc.ants[o] + sc.nests[o] * 10; weak = o; } }
    const cands = [];
    for (let t = 0; t < nn; t++) {
      const T = N[t];
      if (T.o === seat) continue;
      let dmin = 1e9;
      for (const j of mine) dmin = Math.min(dmin, rl(j, t));
      const eta = dmin / V;
      let def = T.c;
      if (C.noise) def *= 1 + (R() - 0.5) * 2 * C.noise;
      if (C.growth && T.o >= 0) def = Math.min(Math.max(capOf(T), def), def + rateOf(W, T) * eta);
      if (lv >= 2) def += same[t];
      const need = def * defK(T) - own[t] + C.mg + def * C.mgK;
      if (need <= 0) continue;
      let val = (T.sz === 3 ? 2.3 : T.sz === 2 ? 1.6 : 1) * (T.k === 'f' ? 1.6 : T.k === 'q' ? 2.2 : T.k === 't' ? 1.1 : 1);
      if (T.o >= 0 && lv >= 2) val *= 1.3;
      if (C.focus && T.o >= 0 && T.o === weak) val *= C.focus;
      const sc = val * 100 / (need + dmin * C.dk + 6) * (lv === 1 ? 0.6 + R() * 0.8 : 1);
      cands.push([sc, t, need]);
    }
    cands.sort((a, b) => b[0] - a[0]);
    const tries = Math.min(cands.length, 4);
    for (let ci = 0; ci < tries; ci++) {
      const idx = ci === 0 && C.top > 1 ? Math.floor(R() * Math.min(C.top, cands.length)) : ci;
      const t = cands[idx][1], need = cands[idx][2];
      const srcs = mine.slice().sort((a, b) => rl(a, t) - rl(b, t));
      let got = 0;
      const use = [];
      for (const j of srcs) {
        if (use.length >= C.src) break;
        const sp = spare(j);
        if (sp < 2) continue;
        use.push([j, sp]); got += sp;
        if (got >= need) break;
      }
      if (!use.length) continue;
      if (got >= need && C.far && N[t].o >= 0 && use.length > 1) { // growth while the farthest helpers walk
        const extra = rateOf(W, N[t]) * (rl(use[use.length - 1][0], t) - rl(use[0][0], t)) / V * defK(N[t]);
        if (got < need + extra) continue;
      }
      if (got >= need) {
        let left = need;
        const cmds = [];
        for (const u of use) { const k = Math.min(u[1], left); cmds.push(mk(u[0], t, k)); left -= k; if (left <= 0) break; }
        return cmds;
      }
      if (C.gamble && R() < C.gamble) return [mk(use[0][0], t, N[use[0][0]].c * 0.5)];
    }
    // 3) a nest near its cap pushes ants toward the front line
    if (C.cons && R() < C.cons) {
      for (const j of mine) {
        if (N[j].c < capOf(N[j]) * 0.85) continue;
        if (lv === 1) { const t = Math.floor(R() * nn); if (t !== j) return [{ s: [j], d: t, p: 50 }]; continue; }
        let best = -1, bd = 1e9;
        for (const i of mine) {
          if (i === j || N[i].c > capOf(N[i]) * 0.8) continue;
          let df = 1e9;
          for (let t = 0; t < nn; t++) if (N[t].o !== seat) df = Math.min(df, rl(i, t));
          const myF = (() => { let x = 1e9; for (let t = 0; t < nn; t++) if (N[t].o !== seat) x = Math.min(x, rl(j, t)); return x; })();
          if (df >= myF) continue; // only move forward
          if (df < bd) { bd = df; best = i; }
        }
        if (best >= 0) return [{ s: [j], d: best, p: 50 }];
      }
    }
    return null;
  }

  /* ======================= pure game interface ======================= */
  const TIMES = [180, 240, 360];
  function init(players, opts) {
    const o = opts || {};
    let mp = o.map == null ? -1 : +o.map;
    const rnd = !(mp >= 0 && mp < MAPS.length);
    if (rnd) mp = Math.floor(Math.random() * MAPS.length);
    const T = TIMES.includes(+o.time) ? +o.time : 240;
    return {
      rid: 1 + U.rand(99999), n: clamp(players.length, 2, 4), nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      mp, rnd: rnd ? 1 : 0, T, ph: 'count', res: null, why: '',
    };
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const top = s.res[0];
    const winners = top[3] ? s.res.filter((r) => r[3] && r[1] === top[1] && r[2] === top[2]).map((r) => r[0]) : [];
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + (r[3] ? '둥지 ' + r[1] + ' · 개미 ' + r[2] : '탈락'));
    const why = s.why === 'ko' ? '다른 군단을 모두 물리쳤어요' : '시간 끝 — 둥지 수(같으면 개미 수)로 순위';
    return {
      winners,
      title: winners.length === 1 ? nm(winners[0]) + ' 군단 승리!' : winners.length ? '공동 승리' : '무승부',
      text: (MAPS[s.mp] ? MAPS[s.mp].name : '') + ' · ' + why + '\n' + lines.join('\n'),
    };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const PCTS = [[25, '25%'], [50, '절반'], [75, '75%'], [100, '전부']];
  const CSS = `
.an-bar{position:absolute;left:0;right:0;bottom:0;z-index:6;display:flex;align-items:center;gap:8px;padding:8px 10px calc(8px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.94) 32%);user-select:none;-webkit-user-select:none}
.an-bar .lb{font:700 12px/1.15 "IBM Plex Sans KR",system-ui,sans-serif;color:var(--muted,#ab9fb8);white-space:nowrap;text-align:center}
.an-seg{display:flex;flex:1;gap:6px;min-width:0}
.an-seg button{flex:1;min-width:0;min-height:46px;appearance:none;border:1.5px solid rgba(242,233,216,.16);background:rgba(46,38,64,.94);color:var(--ink,#f2e9d8);border-radius:12px;font:700 14px/1 "IBM Plex Sans KR",system-ui,sans-serif;cursor:pointer;touch-action:manipulation;padding:0 2px}
.an-seg button:active{transform:scale(.96)}
.an-seg button.on{border-color:var(--brass,#e3ae45);background:rgba(227,174,69,.24);color:#ffe3a6}
.an-ff{position:absolute;right:10px;bottom:calc(12px + env(safe-area-inset-bottom));z-index:7;appearance:none;border:1.5px solid rgba(242,233,216,.2);background:rgba(23,19,31,.86);color:var(--ink,#f2e9d8);border-radius:12px;min-height:44px;padding:0 14px;font:700 13px/1 "IBM Plex Sans KR",system-ui,sans-serif;cursor:pointer;touch-action:manipulation}
.an-ff.on{border-color:var(--brass,#e3ae45);color:#ffe3a6}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const seatMe = () => { const m = mine(); return m.length ? m[0] : -1; };
    const isMine = (s) => s >= 0 && s === seatMe();
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return false; };
    let st = null, key = null, W = null, cd = 0, acc = 0, ended = false, sentPlay = false, ff = false;
    let pct = 50;
    try { const v = +localStorage.getItem('lounge.ants.pct'); if (PCTS.some((q) => q[0] === v)) pct = v; } catch (e) {}
    let aiMem = [], parts = [], floats = [], rings = [], lastSfx = 0, hintT = 0, sentOnce = false, prevO = [], knownOut = [], lastTick = -1;
    let lay = null, NS = [], bg = null, bgKey = '', sprites = [];
    // network
    let pubT = 0, hsQ = 0, lastQ = -1, cmdI = 0, cmdQ = [], inT = 0, lastSig = '';
    const lastCmd = {};

    function curKey() { return st ? st.rid + '.' + st.mp + '.' + st.n : null; }
    function startGame() {
      W = newWorld(st.mp, st.n);
      aiMem = [];
      for (let i = 0; i < W.n; i++) aiMem.push({});
      parts = []; floats = []; rings = []; prevO = W.N.map((q) => q.o); knownOut = [];
      cd = COUNT; acc = 0; ended = false; sentPlay = st.ph !== 'count'; ff = false;
      cmdQ = []; lastQ = -1; drag = null; sel = []; kc = -1;
      for (const k in lastCmd) delete lastCmd[k];
      hintT = mine().length ? 14 : 0; sentOnce = false; lastTick = -1;
      makeSprites();
      layout();
      syncBar();
    }

    /* ----- layout: whole map on screen between the HUD and the send bar; my home at the bottom ----- */
    const HUD_H = 50;
    function viewMat(n, s) {
      if (s < 0) s = 0;
      if (n === 4) return [[1, 0, 0, 1], [1, 0, 0, -1], [-1, 0, 0, -1], [-1, 0, 0, 1]][s] || [1, 0, 0, 1];
      const a = -s * Math.PI * 2 / n, c = Math.cos(a), si = Math.sin(a);
      return [c, -si, si, c];
    }
    function layout() {
      if (!W) return;
      const w = cv.w, h = cv.h, m = viewMat(W.n, seatMe());
      const top = HUD_H + 6, bot = mine().length ? 76 : 14;
      let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
      for (const q of W.N) {
        const x = m[0] * q.x + m[1] * q.y, y = m[2] * q.x + m[3] * q.y, r = SZ_R[q.sz] + 12;
        x0 = Math.min(x0, x - r); x1 = Math.max(x1, x + r); y0 = Math.min(y0, y - r - (q.k === 'q' ? 8 : 0)); y1 = Math.max(y1, y + r);
      }
      const s = clamp(Math.min((w - 16) / (x1 - x0), (h - top - bot) / (y1 - y0)), 0.45, 3);
      lay = { s, m, cx: w / 2 - s * (x0 + x1) / 2, cy: top + (h - top - bot) / 2 - s * (y0 + y1) / 2, w, h, top, bot };
      lay.key = [w, h, W.mp, W.n, seatMe(), cv.dpr].join('|');
      NS = W.N.map((q) => ({ x: SX(q.x, q.y), y: SY(q.x, q.y), r: SZ_R[q.sz] * s }));
    }
    cv.onresize = () => { layout(); };
    const SX = (x, y) => lay.cx + lay.s * (lay.m[0] * x + lay.m[1] * y);
    const SY = (x, y) => lay.cy + lay.s * (lay.m[2] * x + lay.m[3] * y);

    /* ----- ant sprites (one per colony colour, two leg frames) ----- */
    function makeSprites() {
      sprites = [];
      const d = Math.min(3, Math.max(2, Math.ceil((cv.dpr || 1) * 1.5)));
      for (let s = 0; s < (W ? W.n : 4); s++) {
        const col = P(s).color, fr = [];
        for (let f = 0; f < 2; f++) {
          const c = document.createElement('canvas');
          c.width = c.height = 24 * d;
          const g = c.getContext('2d');
          g.scale(d, d); g.translate(12, 12);
          const body = shade(col, -0.35), dark = shade(col, -0.7), hi = shade(col, 0.35);
          g.strokeStyle = dark; g.lineWidth = 1.1; g.lineCap = 'round';
          for (const sd of [-1, 1]) for (let k = 0; k < 3; k++) {
            const sw = (f ? 1 : -1) * (k === 1 ? -1 : 1) * 0.35;
            const a = sd * (Math.PI / 2 + (k - 1) * 0.75 + sw);
            g.beginPath(); g.moveTo(0.5 + (k - 1) * 1.1, 0);
            g.lineTo(0.5 + (k - 1) * 1.1 + Math.cos(a) * 3.2, Math.sin(a) * 3.2);
            g.lineTo(0.5 + (k - 1) * 2.2 + Math.cos(a) * 3.6 + (k - 1) * 1.6, Math.sin(a) * 5.6);
            g.stroke();
          }
          g.lineWidth = 0.8;
          g.beginPath(); g.moveTo(5.4, -1); g.quadraticCurveTo(7.5, -3.6, 9.4, -3.4); g.stroke();
          g.beginPath(); g.moveTo(5.4, 1); g.quadraticCurveTo(7.5, 3.6, 9.4, 3.4); g.stroke();
          const ell = (x, y, rx, ry, fill) => { g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, 7); g.fillStyle = fill; g.fill(); };
          ell(-4.6, 0, 4.3, 3.2, dark); ell(-4.6, 0, 3.7, 2.7, body); ell(-5.4, -1, 1.6, 0.9, hi);
          ell(0.6, 0, 2.5, 1.6, dark); ell(0.6, 0, 2, 1.2, body);
          ell(4.4, 0, 2.3, 2.1, dark); ell(4.4, 0, 1.8, 1.6, body); ell(4.1, -0.6, 0.7, 0.5, hi);
          fr.push(c);
        }
        sprites.push(fr);
      }
    }
    let antPx = 1;
    function antAt(seat, X, Y, ux, uy, f, k) {
      const spr = sprites[seat];
      if (!spr) return;
      const dpr = cv.dpr || 1, kk = k * dpr;
      ctx.setTransform(ux * kk, uy * kk, -uy * kk, ux * kk, X * dpr, Y * dpr);
      ctx.drawImage(spr[f & 1], -12, -12, 24, 24);
    }

    /* ----- static layer: soil, tunnels, pond, pebbles, leaves, nest mounds ----- */
    function mul32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
    function roads() { // each nest to its two nearest neighbours (by road length)
      const out = [], seen = {};
      for (let i = 0; i < W.N.length; i++) {
        const ds = [];
        for (let j = 0; j < W.N.length; j++) if (j !== i) ds.push([route(W, i, j).L, j]);
        ds.sort((a, b) => a[0] - b[0]);
        for (let k = 0; k < Math.min(2, ds.length); k++) {
          const j = ds[k][1], a = Math.min(i, j), b = Math.max(i, j);
          if (!seen[a * 64 + b]) { seen[a * 64 + b] = 1; out.push([a, b]); }
        }
      }
      return out;
    }
    function paintBG() {
      bgKey = lay.key;
      const dpr = cv.dpr || 1, w = cv.w, h = cv.h;
      if (!bg) bg = document.createElement('canvas');
      bg.width = Math.max(1, Math.round(w * dpr)); bg.height = Math.max(1, Math.round(h * dpr));
      const g = bg.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const rnd = mul32(9137 + W.mp * 131 + W.n * 17);
      const s = lay.s;
      // soil
      const gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#3e2b1d'); gr.addColorStop(0.5, '#36251a'); gr.addColorStop(1, '#2a1c13');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 26; i++) {
        const x = rnd() * w, y = rnd() * h, r = 30 + rnd() * 70;
        const rg = g.createRadialGradient(x, y, 0, x, y, r);
        rg.addColorStop(0, i % 2 ? 'rgba(98,68,42,.22)' : 'rgba(16,9,5,.22)'); rg.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2);
      }
      const SPK = ['rgba(150,112,76,.32)', 'rgba(22,13,7,.42)', 'rgba(190,160,120,.22)', 'rgba(110,80,52,.4)'];
      const nsp = Math.round(w * h / 80);
      for (let i = 0; i < nsp; i++) { g.fillStyle = SPK[i & 3]; const z = rnd() < 0.85 ? 1 : 2; g.fillRect(rnd() * w, rnd() * h, z, z); }
      g.strokeStyle = 'rgba(16,9,5,.45)'; g.lineWidth = 1;
      for (let i = 0; i < 9; i++) { // cracks
        let x = rnd() * w, y = rnd() * h, a = rnd() * 7;
        g.beginPath(); g.moveTo(x, y);
        for (let k = 0; k < 6; k++) { a += (rnd() - 0.5) * 1.4; x += Math.cos(a) * 9; y += Math.sin(a) * 9; g.lineTo(x, y); }
        g.stroke();
      }
      const nearNest = (x, y, pad) => NS.some((p) => Math.hypot(p.x - x, p.y - y) < p.r + pad);
      // pond
      if (W.pond) {
        const px = SX(0, 0), py = SY(0, 0), pr = W.pond * s;
        g.beginPath(); g.arc(px, py, pr + 6, 0, 7); g.fillStyle = 'rgba(30,20,12,.7)'; g.fill();
        const wg = g.createRadialGradient(px - pr * 0.3, py - pr * 0.3, pr * 0.1, px, py, pr);
        wg.addColorStop(0, '#3f7f86'); wg.addColorStop(0.7, '#245560'); wg.addColorStop(1, '#173a44');
        g.beginPath(); g.arc(px, py, pr, 0, 7); g.fillStyle = wg; g.fill();
        g.strokeStyle = 'rgba(200,240,240,.25)'; g.lineWidth = 1.2;
        for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(px - pr * 0.2 + k * 6, py - pr * 0.1 + k * 5, pr * (0.3 + k * 0.15), 3.6, 4.6); g.stroke(); }
        for (let k = 0; k < 4; k++) { // lily pads
          const a = k * 1.7 + 0.4, d = pr * (0.45 + 0.3 * (k % 2)), x = px + Math.cos(a) * d, y = py + Math.sin(a) * d, r = 5 + (k % 2) * 2;
          g.beginPath(); g.moveTo(x, y); g.arc(x, y, r, a + 0.3, a + Math.PI * 2 - 0.2); g.closePath(); g.fillStyle = '#4f8a3a'; g.fill();
          g.strokeStyle = 'rgba(20,50,20,.6)'; g.lineWidth = 0.8; g.stroke();
          if (k === 1) { g.beginPath(); g.arc(x + 1, y - 1, 2.2, 0, 7); g.fillStyle = '#f0b7d0'; g.fill(); }
        }
        g.strokeStyle = '#6f8a3a'; g.lineWidth = 1.4; g.lineCap = 'round';
        for (let k = 0; k < 9; k++) { const a = k * 0.7 + 2.2, x = px + Math.cos(a) * (pr + 4), y = py + Math.sin(a) * (pr + 4); g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * 3 + (k % 3 - 1) * 2, y - 9 - (k % 2) * 4); g.stroke(); }
      }
      // tunnels: dark carved channels with a pale rim
      const rd = roads(), tmp = { x: 0, y: 0, ux: 0, uy: 0 };
      const pathOf = (a, b) => { const R = route(W, a, b); g.beginPath(); for (let i = 0; i < R.p.length; i += 2) { const x = SX(R.p[i], R.p[i + 1]), y = SY(R.p[i], R.p[i + 1]); i ? g.lineTo(x, y) : g.moveTo(x, y); } };
      g.lineCap = 'round'; g.lineJoin = 'round';
      for (const [a, b] of rd) { pathOf(a, b); g.strokeStyle = 'rgba(160,122,82,.16)'; g.lineWidth = Math.max(8, 9 * s); g.stroke(); }
      for (const [a, b] of rd) { pathOf(a, b); g.strokeStyle = 'rgba(14,8,4,.55)'; g.lineWidth = Math.max(5, 5.5 * s); g.stroke(); }
      for (const [a, b] of rd) { // little crumbs along the tunnels
        const R = route(W, a, b);
        for (let d = 8; d < R.L - 8; d += 7) {
          posAt(R, d, tmp);
          const sd = rnd() < 0.5 ? -1 : 1, off = 3.6 + rnd() * 1.5, wx = tmp.x - tmp.uy * off * sd, wy = tmp.y + tmp.ux * off * sd;
          g.fillStyle = 'rgba(150,112,76,.35)'; g.fillRect(SX(wx, wy), SY(wx, wy), 1.4, 1.4);
        }
      }
      // pebbles
      for (let i = 0; i < 38; i++) {
        const x = rnd() * w, y = HUD_H * 0.5 + rnd() * (h - HUD_H * 0.5), rx = 2 + rnd() * 4.5, ry = rx * (0.6 + rnd() * 0.3), a = rnd() * 3;
        if (nearNest(x, y, 12)) continue;
        g.beginPath(); g.ellipse(x + 1, y + 1.5, rx, ry, a, 0, 7); g.fillStyle = 'rgba(10,6,3,.45)'; g.fill();
        g.beginPath(); g.ellipse(x, y, rx, ry, a, 0, 7); g.fillStyle = ['#6e6258', '#7d6a55', '#5d544c', '#8a7a68'][i & 3]; g.fill();
        g.beginPath(); g.ellipse(x - rx * 0.3, y - ry * 0.35, rx * 0.4, ry * 0.3, a, 0, 7); g.fillStyle = 'rgba(255,240,220,.22)'; g.fill();
      }
      // fallen leaves and twigs
      for (let i = 0; i < 6; i++) {
        const x = (i % 2 ? w - 18 - rnd() * w * 0.22 : 18 + rnd() * w * 0.22), y = HUD_H + 20 + rnd() * (h - HUD_H - 60), a = rnd() * 7, L0 = 14 + rnd() * 10;
        if (nearNest(x, y, 18)) continue;
        g.save(); g.translate(x, y); g.rotate(a);
        g.beginPath(); g.moveTo(-L0, 0); g.quadraticCurveTo(0, -L0 * 0.45, L0, 0); g.quadraticCurveTo(0, L0 * 0.45, -L0, 0);
        g.fillStyle = ['rgba(150,120,40,.55)', 'rgba(110,130,50,.5)', 'rgba(160,90,40,.5)'][i % 3]; g.fill();
        g.strokeStyle = 'rgba(40,25,10,.5)'; g.lineWidth = 0.8; g.beginPath(); g.moveTo(-L0 - 3, 0); g.lineTo(L0, 0); g.stroke();
        for (let k = -2; k <= 2; k++) { g.beginPath(); g.moveTo(k * L0 * 0.3, 0); g.lineTo(k * L0 * 0.3 + L0 * 0.18, -L0 * 0.2); g.moveTo(k * L0 * 0.3, 0); g.lineTo(k * L0 * 0.3 + L0 * 0.18, L0 * 0.2); g.stroke(); }
        g.restore();
      }
      // grass tufts on the side edges
      g.lineCap = 'round';
      for (let i = 0; i < 14; i++) {
        const left = i % 2 === 0, x = left ? rnd() * 8 : w - rnd() * 8, y = HUD_H + rnd() * (h - HUD_H);
        for (let k = 0; k < 5; k++) {
          const lx = x + (k - 2) * 2, a = (left ? 0.5 : -0.5) + (k - 2) * 0.22;
          g.beginPath(); g.moveTo(lx, y); g.quadraticCurveTo(lx + Math.sin(a) * 6, y - 8, lx + Math.sin(a) * 12, y - 14 - (k % 2) * 4);
          g.strokeStyle = ['#5f7a2e', '#4d6626', '#73903a'][k % 3]; g.lineWidth = 1.6; g.stroke();
        }
      }
      // nest mounds
      W.N.forEach((q, i) => {
        const p = NS[i], R = p.r;
        g.beginPath(); g.ellipse(p.x + 2, p.y + 4, R * 1.3, R * 1.1, 0, 0, 7); g.fillStyle = 'rgba(8,4,2,.45)'; g.fill();
        for (let k = 0; k < 16; k++) { const a = rnd() * 7, d = R * (1.15 + rnd() * 0.4); g.beginPath(); g.arc(p.x + Math.cos(a) * d, p.y + Math.sin(a) * d, 0.8 + rnd() * 1.3, 0, 7); g.fillStyle = rnd() < 0.5 ? '#7a5a3a' : '#5a3f28'; g.fill(); }
        const mg = g.createRadialGradient(p.x - R * 0.35, p.y - R * 0.4, R * 0.1, p.x, p.y, R * 1.22);
        mg.addColorStop(0, '#9a7450'); mg.addColorStop(0.55, '#6c4c31'); mg.addColorStop(1, '#3f2a1a');
        g.beginPath(); g.arc(p.x, p.y, R * 1.2, 0, 7); g.fillStyle = mg; g.fill();
        g.strokeStyle = 'rgba(30,18,10,.5)'; g.lineWidth = 0.8;
        for (let k = 0; k < 4; k++) { const a = k * 1.6 + rnd(); g.beginPath(); g.arc(p.x, p.y, R * (0.8 + k * 0.08), a, a + 0.9); g.stroke(); }
        const hg = g.createRadialGradient(p.x, p.y + 1, 0, p.x, p.y + 1, R * 0.62);
        hg.addColorStop(0, '#050201'); hg.addColorStop(0.75, '#1b0f07'); hg.addColorStop(1, 'rgba(40,24,12,.9)');
        g.beginPath(); g.ellipse(p.x, p.y + 1, R * 0.66, R * 0.52, 0, 0, 7); g.fillStyle = hg; g.fill();
        if (q.k === 't') { // stone ring
          for (let k = 0; k < 11; k++) {
            const a = k / 11 * Math.PI * 2, x = p.x + Math.cos(a) * R * 1.32, y = p.y + Math.sin(a) * R * 1.32, rr = Math.max(2.4, R * 0.24);
            g.beginPath(); g.ellipse(x + 0.8, y + 1.2, rr, rr * 0.8, a, 0, 7); g.fillStyle = 'rgba(10,6,3,.5)'; g.fill();
            g.beginPath(); g.ellipse(x, y, rr, rr * 0.8, a, 0, 7); g.fillStyle = k % 2 ? '#8d8478' : '#a39a8c'; g.fill();
            g.beginPath(); g.ellipse(x - rr * 0.3, y - rr * 0.3, rr * 0.4, rr * 0.3, a, 0, 7); g.fillStyle = 'rgba(255,255,255,.25)'; g.fill();
          }
        }
        if (q.k === 'f') { // leaf with aphids
          for (const sd of [-1, 1]) {
            g.save(); g.translate(p.x + sd * R * 0.95, p.y - R * 0.95); g.rotate(sd * 0.7);
            const l = Math.max(7, R * 0.75);
            g.beginPath(); g.moveTo(0, l * 0.5); g.quadraticCurveTo(-l * 0.6, -l * 0.1, 0, -l * 0.8); g.quadraticCurveTo(l * 0.6, -l * 0.1, 0, l * 0.5);
            g.fillStyle = '#5fae3e'; g.fill(); g.strokeStyle = '#2f6a22'; g.lineWidth = 0.8; g.stroke();
            g.beginPath(); g.moveTo(0, l * 0.5); g.lineTo(0, -l * 0.7); g.stroke();
            for (let k = 0; k < 3; k++) { g.beginPath(); g.arc((k - 1) * l * 0.18, -l * 0.15 + k * l * 0.12, Math.max(1.1, l * 0.09), 0, 7); g.fillStyle = '#c8f070'; g.fill(); }
            g.restore();
          }
        }
        if (q.k === 'q') { // crown
          const cw = Math.max(10, R * 0.9), cy = p.y - R * 1.25 - cw * 0.3;
          g.beginPath(); g.moveTo(p.x - cw, cy + cw * 0.5); g.lineTo(p.x - cw, cy - cw * 0.2); g.lineTo(p.x - cw * 0.5, cy + cw * 0.15); g.lineTo(p.x, cy - cw * 0.45);
          g.lineTo(p.x + cw * 0.5, cy + cw * 0.15); g.lineTo(p.x + cw, cy - cw * 0.2); g.lineTo(p.x + cw, cy + cw * 0.5); g.closePath();
          g.fillStyle = '#e3ae45'; g.fill(); g.strokeStyle = '#7a5410'; g.lineWidth = 1.2; g.stroke();
          g.beginPath(); g.arc(p.x, cy + cw * 0.15, cw * 0.14, 0, 7); g.fillStyle = '#ee6a55'; g.fill();
        }
      });
      // vignette
      const vg = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.75);
      vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(8,4,2,.55)');
      g.fillStyle = vg; g.fillRect(0, 0, w, h);
    }

    /* ----- input: drag from my nests (swipe over more of mine to gather them), or tap-select then tap a target ----- */
    let drag = null, sel = [];
    function canPlay() { const me = seatMe(); return me >= 0 && W && st && st.ph === 'play' && !ended && !W.out.includes(me); }
    function nestAt(x, y) {
      let best = -1, bd = 1e9;
      for (let i = 0; i < NS.length; i++) {
        const p = NS[i], d = Math.hypot(x - p.x, y - p.y);
        if (d < Math.max(26, p.r + 16) && d < bd) { bd = d; best = i; }
      }
      return best;
    }
    function preview(srcs, pc) { let k = 0; for (const s of srcs) { const q = W.N[s]; if (q && q.o === seatMe()) k += Math.floor(q.c * pc / 100 + 1e-9); } return k; }
    function doSend(srcs, dst) {
      const me = seatMe();
      srcs = srcs.filter((s) => s !== dst && W.N[s] && W.N[s].o === me);
      if (!srcs.length) return;
      const k = preview(srcs, pct);
      if (k < 1) { api.toast('보낼 개미가 없어요'); api.buzz(8); return; }
      if (host()) {
        const made = send(W, me, srcs, dst, pct);
        if (!made) { api.toast('행렬이 너무 많아요. 잠깐 기다려요'); return; }
      } else {
        cmdI++;
        cmdQ.push([cmdI, dst, pct].concat(srcs.slice(0, 30)));
        if (cmdQ.length > 12) cmdQ.shift();
        inT = 0;
      }
      sentOnce = true; hintT = Math.min(hintT, 0.6);
      sfx('whoosh', 40); api.buzz(14);
      const p = NS[dst];
      floats.push({ x: p.x, y: p.y - p.r - 16, text: '+' + k + '마리 출발', col: P(me).color, t: 1.1, T: 1.1 });
    }
    function onDown(e) {
      if (!canPlay() || drag) return;
      const p = cv.local(e), i = nestAt(p.x, p.y), me = seatMe();
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      if (i >= 0 && W.N[i].o === me) {
        const srcs = sel.slice();
        if (!srcs.includes(i)) srcs.push(i);
        drag = { id: e.pointerId, start: i, srcs, x: p.x, y: p.y, x0: p.x, y0: p.y, over: i, moved: false };
        api.buzz(8);
      } else if (i >= 0 && sel.length) { doSend(sel, i); sel = []; }
      else if (i < 0) sel = [];
    }
    function onMove(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const p = cv.local(e);
      drag.x = p.x; drag.y = p.y;
      if (Math.hypot(p.x - drag.x0, p.y - drag.y0) > 10) drag.moved = true;
      const j = nestAt(p.x, p.y);
      if (j >= 0 && j !== drag.over && W.N[j].o === seatMe() && !drag.srcs.includes(j)) { drag.srcs.push(j); api.buzz(6); sfx('tick', 40); }
      if (j !== drag.over && j >= 0 && W.N[j].o !== seatMe()) api.buzz(4);
      drag.over = j;
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag;
      drag = null;
      if (e.type === 'pointercancel' || !W || !canPlay()) return;
      const j = nestAt(d.x, d.y);
      if (!d.moved && j === d.start) { // a tap: toggle selection
        const k = sel.indexOf(j);
        if (k >= 0) sel.splice(k, 1); else sel.push(j);
        sfx('click', 30);
        return;
      }
      if (j >= 0) { doSend(d.srcs.filter((s) => s !== j), j); sel = []; }
      else sel = [];
    }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- keyboard / gamepad (api.input, rebindable in 「⌨ 조작 설정」). The mouse stays the main way to play.
       1–4 = 보낼 양, 바꾸기 = cycle it; a cursor (white ring) moves to the nearest nest in the pressed direction,
       다음 = jump through my nests; 고르기 = toggle my nest / attack an enemy nest with the chosen ones;
       보내기 = send the chosen nests to the cursor (also to my own nest = reinforce); 취소 = clear the choice. */
    const KMOVE = { cl: [-1, 0], cr: [1, 0], cu: [0, -1], cd: [0, 1] };
    let kc = -1, kbOn = false;
    const kl = (id) => { // first bound key of an action, for the hint line
      const b = api.input && api.input.bindings().find((x) => x.id === id), c = b && b.keys[0];
      return !c ? '' : c === 'Space' ? '스페이스' : c === 'Escape' ? 'Esc' : c.replace(/^Key|^Digit|^Numpad/, '');
    };
    function kcFix() { // keep the cursor on a valid nest; start on my home (or any nest of mine)
      if (kc >= 0 && NS[kc]) return true;
      const me = seatMe(); kc = -1;
      for (let i = 0; i < W.N.length; i++) if (W.N[i].o === me && (kc < 0 || W.N[i].k === 'h')) kc = i;
      if (kc < 0 && NS.length) kc = 0;
      return false;
    }
    function kcMove(dx, dy) {
      if (!kcFix()) return;
      const p = NS[kc];
      let best = -1, bs = 1e9;
      for (let i = 0; i < NS.length; i++) {
        if (i === kc) continue;
        const q = NS[i], vx = q.x - p.x, vy = q.y - p.y, d = Math.hypot(vx, vy);
        if (d < 1) continue;
        const c = (vx * dx + vy * dy) / d;
        if (c < 0.35) continue;
        const sc = d * (1 + 2.2 * (1 - c));
        if (sc < bs) { bs = sc; best = i; }
      }
      if (best >= 0) { kc = best; sfx('tick', 30); api.buzz(4); }
    }
    function kcNext() {
      kcFix();
      const me = seatMe(), n = W.N.length;
      for (let k = 1; k <= n; k++) { const i = (kc + k) % n; if (W.N[i].o === me) { kc = i; sfx('tick', 30); api.buzz(4); return; } }
    }
    function kbPick() {
      if (!kcFix()) return;
      const me = seatMe();
      if (W.N[kc].o === me) { const k = sel.indexOf(kc); if (k >= 0) sel.splice(k, 1); else sel.push(kc); sfx('click', 30); api.buzz(6); }
      else if (sel.length) { doSend(sel, kc); sel = []; }
      else { api.toast('먼저 내 둥지를 골라요'); api.buzz(8); }
    }
    function kbSend() {
      if (!kcFix()) return;
      if (!sel.length) { api.toast('먼저 보낼 내 둥지를 골라요'); api.buzz(8); return; }
      if (!sel.some((s) => s !== kc)) { api.toast('다른 둥지로 커서를 옮겨요'); api.buzz(8); return; }
      doSend(sel, kc); sel = [];
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !mine().length) return;
      const pi = ['p25', 'p50', 'p75', 'p100'].indexOf(id);
      if (pi >= 0) { setPct(PCTS[pi][0]); return; }
      if (id === 'pct') { const k = PCTS.findIndex((q) => q[0] === pct); setPct(PCTS[(k + 1) % PCTS.length][0]); return; }
      if (!canPlay() || drag || !NS.length) return;
      kbOn = true; hintT = Math.min(hintT, 1);
      if (KMOVE[id]) kcMove(KMOVE[id][0], KMOVE[id][1]);
      else if (id === 'next') kcNext();
      else if (id === 'pick') kbPick();
      else if (id === 'send') kbSend();
      else if (id === 'clear') { kcFix(); if (sel.length) { sel = []; sfx('click', 30); } }
    }) : () => {};

    /* ----- bottom bar: how many to send ----- */
    const segBtns = [];
    const seg = L.h('div', { class: 'an-seg', role: 'group', 'aria-label': '보낼 양' });
    for (const [v, t] of PCTS) {
      const b = L.h('button', { type: 'button', text: t, 'aria-label': '보낼 양 ' + t, onclick() { setPct(v); } });
      segBtns.push([v, b]); seg.append(b);
    }
    const bar = L.h('div', { class: 'an-bar' }, L.h('div', { class: 'lb', html: '보낼<br>양' }), seg);
    bar.addEventListener('pointerdown', (e) => e.stopPropagation());
    root.appendChild(bar);
    const ffBtn = L.h('button', { class: 'an-ff', type: 'button', text: '빨리 보기 ▶▶', onclick() { ff = !ff; api.sfx('click'); syncBar(); } });
    ffBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
    root.appendChild(ffBtn);
    function setPct(v) {
      pct = v; api.sfx('click'); api.buzz(8);
      try { localStorage.setItem('lounge.ants.pct', String(v)); } catch (e) {}
      syncBar();
    }
    function syncBar() {
      for (const [v, b] of segBtns) b.classList.toggle('on', v === pct);
      const me = seatMe(), out = me >= 0 && W && W.out.includes(me);
      bar.hidden = me < 0 || !st || st.ph === 'done' || out;
      ffBtn.hidden = api.online || !st || st.ph !== 'play' || ended || (me >= 0 && !out);
      ffBtn.classList.toggle('on', ff);
      ffBtn.textContent = ff ? '빨리 보는 중 ×4' : '빨리 보기 ▶▶';
    }

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 50)) return; lastSfx = t; api.sfx(n); }
    function puff(x, y, col, n, sp) {
      for (let i = 0; i < n; i++) { const a = Math.random() * 7, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 8, t: 0.4 + Math.random() * 0.3, T: 0.7, c: col, r: 1 + Math.random() * 1.6 }); }
      if (parts.length > 260) parts.splice(0, parts.length - 260);
    }
    function onCapture(i, from, to) {
      const p = NS[i];
      if (!p) return;
      rings.push({ x: p.x, y: p.y, r0: p.r, r1: p.r + 26, t: 0.55, T: 0.55, col: to >= 0 ? P(to).color : '#d8ccb6' });
      puff(p.x, p.y, to >= 0 ? P(to).color : '#d8ccb6', 12, 60);
      const me = seatMe();
      if (isMine(to)) { floats.push({ x: p.x, y: p.y - p.r - 14, text: '점령!', col: P(to).color, t: 1.3, T: 1.3 }); sfx('pop', 40); api.buzz(18); }
      else if (from >= 0 && from === me) { floats.push({ x: p.x, y: p.y - p.r - 14, text: '빼앗김!', col: '#ee6a55', t: 1.4, T: 1.4 }); sfx('thud', 40); api.buzz(50); }
      else sfx('tick', 90);
      const k = sel.indexOf(i); if (k >= 0 && to !== me) sel.splice(k, 1);
    }
    function onOut(s) {
      if (isMine(s)) { api.sfx('lose'); api.buzz([40, 60, 40]); api.toast('내 개미 군단이 무너졌어요 · 관전 중'); }
      else { api.toast(name(s) + ' 군단 탈락!'); sfx('thud', 30); }
      syncBar();
    }
    function watch() { // effects derived from state changes (same on host and guests)
      if (!W) return;
      for (let i = 0; i < W.N.length; i++) { const o = W.N[i].o; if (prevO[i] !== o) { if (prevO[i] !== undefined) onCapture(i, prevO[i], o); prevO[i] = o; } }
      for (const s of W.out) if (!knownOut.includes(s)) { knownOut.push(s); onOut(s); }
    }

    /* ----- host: game flow ----- */
    function finish(why) {
      if (ended) return;
      ended = true;
      api.setState(Object.assign({}, st, { ph: 'done', res: ranking(W), why }));
    }
    function hostTick(dt) {
      if (st.ph === 'count') {
        if (cd <= 0 && !sentPlay) { sentPlay = true; api.setState(Object.assign({}, st, { ph: 'play' })); }
        return;
      }
      if (st.ph !== 'play' || ended) return;
      pollHost();
      acc += Math.min(dt, 1);
      let k = 0;
      while (acc >= STEP && k < 60) {
        for (let s = 0; s < W.n; s++) {
          const p = api.players[s];
          if (!p || !simHere(s)) continue;
          if (p.ai || (L.debug && L.debug.autoplay)) {
            const cmds = aiThink(W, s, aiMem[s] || (aiMem[s] = {}), p.ai ? (p.lv || 2) : 2, STEP);
            if (cmds) for (const c of cmds) send(W, s, c.s, c.d, c.p);
          }
        }
        stepWorld(W, STEP, null);
        acc -= STEP; k++;
        if (aliveN(W) <= 1) { finish('ko'); break; }
        if (W.t >= st.T) { finish('time'); break; }
      }
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.n) || simHere(s) || !o || o.k !== key || !Array.isArray(o.c)) continue;
        const list = o.c.filter((c) => Array.isArray(c) && fin(c[0])).sort((a, b) => a[0] - b[0]);
        for (const c of list) {
          if (c[0] <= (lastCmd[s] | 0)) continue;
          lastCmd[s] = c[0];
          send(W, s, c.slice(3).map((v) => v | 0), c[1] | 0, c[2]);
        }
      }
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.N)) return;
      lastQ = hs.q;
      if (fin(hs.t)) W.t = hs.t;
      for (let i = 0; i < W.N.length; i++) { const o = hs.N[i * 2], c = hs.N[i * 2 + 1]; if (fin(o)) W.N[i].o = o; if (fin(c)) W.N[i].c = c; }
      if (Array.isArray(hs.G)) {
        const old = {};
        for (const g of W.G) old[g.id] = g;
        const G = [];
        for (let i = 0; i + 6 < hs.G.length; i += 7) {
          const id = hs.G[i], o = hs.G[i + 1], a = hs.G[i + 2], b = hs.G[i + 3], n = hs.G[i + 4], m = hs.G[i + 5], hh = hs.G[i + 6];
          if (!(a >= 0 && a < W.N.length && b >= 0 && b < W.N.length && n > 0)) continue;
          let g = old[id];
          const tgt = hh + V * 0.05;
          if (!g || g.o !== o || g.a !== a || g.b !== b) g = { id, o, a, b, n, m, h: tgt };
          else { g.n = n; g.m = m; if (Math.abs(g.h - tgt) > 8) g.h = tgt; else g.h += (tgt - g.h) * 0.35; }
          G.push(g);
        }
        W.G = G;
      }
      if (Array.isArray(hs.o)) for (const s of hs.o) if (fin(s) && !W.out.includes(s)) W.out.push(s);
      const me = seatMe();
      if (hs.A && fin(hs.A[me])) { const ack = hs.A[me]; cmdQ = cmdQ.filter((c) => c[0] > ack); }
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 0.1;
          hsQ = (hsQ + 1) % 100000;
          const N = [], G = [];
          for (const q of W.N) N.push(q.o, Math.max(0, Math.ceil(q.c - 1e-6)));
          for (const g of W.G) G.push(g.id, g.o, g.a, g.b, g.n, g.m, r1(g.h));
          api.net.hostSend({ k: key, q: hsQ, t: r1(W.t), N, G, A: Object.assign({}, lastCmd), o: W.out.slice() });
        } else {
          const me = seatMe();
          if (me < 0) return;
          const sig = cmdQ.length ? cmdQ[cmdQ.length - 1][0] + ':' + cmdQ.length : '0';
          if (sig === lastSig && inT > 0) return;
          lastSig = sig; inT = cmdQ.length ? 0.4 : 2;
          api.net.publish({ k: key, c: cmdQ.slice(-8) });
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    function frame(rdt) {
      if (!st || !W) return;
      const dt = rdt * SPD() * (ff ? 4 : 1);
      if (st.ph === 'count') {
        const pn = Math.ceil(cd); cd -= dt; const nn = Math.ceil(cd);
        if (nn !== pn && nn > 0) api.sfx('tick');
        if (cd <= 0 && pn > 0) { api.sfx('pop'); api.buzz(20); }
      }
      if (hintT > 0 && st.ph === 'play') hintT -= rdt;
      if (host()) hostTick(dt);
      else {
        pollGuest();
        if (st.ph === 'play') {
          W.t += dt;
          for (const g of W.G) { const R = route(W, g.a, g.b); g.h = Math.min(g.h + V * dt, R.L + colLen(g.n) + 1); }
        }
      }
      watch();
      // last 10 seconds: tick
      if (st.ph === 'play' && !ended) { const left = Math.ceil(st.T - W.t); if (left <= 10 && left > 0 && left !== lastTick) { lastTick = left; api.sfx('tick'); } }
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.92; p.vy *= 0.92; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t -= rdt; if (rings[i].t <= 0) rings.splice(i, 1); }
      publish(rdt);
    }

    /* ----- drawing ----- */
    const tmp = { x: 0, y: 0, ux: 1, uy: 0 };
    function rrect(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function draw(now) {
      cv.clear();
      const w = cv.w, h = cv.h;
      if (!W || !st) { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h); return; }
      if (!lay || lay.w !== w || lay.h !== h) layout();
      if (bgKey !== lay.key || !bg) paintBG();
      ctx.drawImage(bg, 0, 0, w, h);
      const t = now / 1000, s = lay.s, me = seatMe(), dpr = cv.dpr || 1;
      antPx = clamp(s * 0.6, 0.55, 1);
      // active roads glow faintly in the marching colour
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (const g of W.G) {
        const R = route(W, g.a, g.b);
        ctx.beginPath();
        for (let i = 0; i < R.p.length; i += 2) { const x = SX(R.p[i], R.p[i + 1]), y = SY(R.p[i], R.p[i + 1]); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
        ctx.strokeStyle = hexA(P(g.o).color, 0.13); ctx.lineWidth = Math.max(4, 5 * s); ctx.stroke();
      }
      // nests: owner tint, rim, fill arc, number
      for (let i = 0; i < W.N.length; i++) {
        const q = W.N[i], p = NS[i], R = p.r, col = q.o >= 0 ? P(q.o).color : null;
        if (col) {
          ctx.beginPath(); ctx.arc(p.x, p.y, R * 1.2, 0, 7); ctx.fillStyle = hexA(col, 0.15); ctx.fill();
          const f = Math.min(1, q.c / capOf(q));
          ctx.beginPath(); ctx.arc(p.x, p.y, R * 1.2 + 5, -Math.PI / 2, -Math.PI / 2 + f * Math.PI * 2);
          ctx.strokeStyle = hexA(col, f >= 1 ? 0.9 : 0.55); ctx.lineWidth = 2.2; ctx.stroke();
        }
        ctx.beginPath(); ctx.arc(p.x, p.y, R * 1.2 + 1.5, 0, 7);
        ctx.lineWidth = q.sz >= 3 ? 3.4 : 2.8;
        if (col) ctx.strokeStyle = col; else { ctx.strokeStyle = 'rgba(222,208,184,.5)'; ctx.setLineDash([3, 3]); }
        ctx.stroke(); ctx.setLineDash([]);
        if (q.o === me && me >= 0 && q.o0 === me && q.k === 'h' && W.t < 6 && st.ph === 'play') {
          ctx.beginPath(); ctx.arc(p.x, p.y, R * 1.2 + 9 + Math.sin(t * 6) * 2, 0, 7); ctx.strokeStyle = 'rgba(255,227,166,.6)'; ctx.lineWidth = 2; ctx.stroke();
        }
      }
      // selection rings
      const selList = drag ? drag.srcs : sel;
      for (const i of selList) {
        const p = NS[i]; if (!p) continue;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 1.2 + 8, 0, 7);
        ctx.setLineDash([5, 4]); ctx.lineDashOffset = -t * 20;
        ctx.strokeStyle = '#ffe3a6'; ctx.lineWidth = 2.5; ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
      }
      // keyboard cursor
      if (kbOn && !drag && kc >= 0 && NS[kc] && canPlay()) {
        const p = NS[kc], rr = p.r * 1.2 + 12 + Math.sin(t * 5) * 1.5;
        ctx.beginPath(); ctx.arc(p.x, p.y, rr, 0, 7); ctx.strokeStyle = 'rgba(12,6,3,.6)'; ctx.lineWidth = 5; ctx.stroke();
        ctx.strokeStyle = '#fff6e6'; ctx.lineWidth = 2.5; ctx.stroke();
      }
      // idle ants pottering around owned nests
      for (let i = 0; i < W.N.length; i++) {
        const q = W.N[i];
        if (q.o < 0 || !sprites[q.o]) continue;
        const p = NS[i], k = Math.min(4, Math.ceil(q.c / 12));
        for (let j = 0; j < k; j++) {
          const dir = (i + j) % 2 ? 1 : -1, a = t * 0.55 * dir + j * 2.4 + i * 1.3, rr = p.r * (1.3 + 0.18 * Math.sin(t * 1.7 + j * 2 + i));
          const x = p.x + Math.cos(a) * rr, y = p.y + Math.sin(a) * rr;
          antAt(q.o, x, y, -Math.sin(a) * dir, Math.cos(a) * dir, ((t * 9 + j) | 0), antPx * 0.9);
        }
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      // marching columns
      const maxS = W.G.length > 30 ? 7 : W.G.length > 16 ? 10 : 14;
      for (const g of W.G) {
        const R = route(W, g.a, g.b), gap = colLen(g.n) / g.n;
        const jMin = Math.max(0, Math.ceil((g.h - R.L) / gap - 1e-9)), jMax = Math.min(g.n - 1, Math.floor(g.h / gap));
        const cnt = jMax - jMin + 1;
        if (cnt <= 0) continue;
        const dHead = g.h - jMin * gap, vis = (jMax - jMin) * gap;
        const nS = Math.max(1, Math.min(cnt, maxS, Math.floor(vis / 3) + 1)), step = nS > 1 ? vis / (nS - 1) : 0;
        for (let k = 0; k < nS; k++) {
          const d = dHead - k * step;
          posAt(R, d, tmp);
          const wob = (k % 2 ? 2.6 : -2.6) + Math.sin(g.id * 1.7 + k * 2.3 + t * 3) * 0.8;
          const wx = tmp.x - tmp.uy * wob, wy = tmp.y + tmp.ux * wob;
          const ux = lay.m[0] * tmp.ux + lay.m[1] * tmp.uy, uy = lay.m[2] * tmp.ux + lay.m[3] * tmp.uy;
          antAt(g.o, SX(wx, wy), SY(wx, wy), ux, uy, ((t * 12 + k) | 0), antPx);
        }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const left = g.n - jMin;
        if (left >= 2 && dHead < R.L - NS[g.b].r / s * 1.3 && dHead > NS[g.a].r / s * 1.3) {
          posAt(R, dHead, tmp);
          const X = SX(tmp.x, tmp.y), Y = SY(tmp.x, tmp.y), txt = String(left);
          ctx.font = '700 10.5px ' + MONO;
          const tw = ctx.measureText(txt).width + 8;
          rrect(X - tw / 2, Y - 19, tw, 13, 6.5); ctx.fillStyle = 'rgba(20,12,8,.78)'; ctx.fill();
          ctx.strokeStyle = P(g.o).color; ctx.lineWidth = 1; ctx.stroke();
          ctx.fillStyle = '#fff6e6'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(txt, X, Y - 12.4);
        }
        // fight at the gate
        if (g.h >= R.L && W.N[g.b].o !== g.o && Math.random() < 0.5) {
          const p = NS[g.b];
          posAt(R, Math.max(0, R.L - p.r / s * 1.1), tmp);
          puff(SX(tmp.x, tmp.y), SY(tmp.x, tmp.y), Math.random() < 0.5 ? P(g.o).color : '#c8a878', 1, 40);
          if (isMine(g.o) || isMine(W.N[g.b].o)) sfx('tick', 160);
        }
      }
      // nest numbers on top of everything on the ground
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let i = 0; i < W.N.length; i++) {
        const q = W.N[i], p = NS[i], v = Math.max(0, Math.ceil(q.c - 1e-6));
        ctx.font = '700 ' + (q.sz >= 3 ? 14 : 12.5) + 'px ' + MONO;
        ctx.lineWidth = 3.2; ctx.strokeStyle = 'rgba(12,6,3,.92)'; ctx.strokeText(String(v), p.x, p.y + 1.5);
        ctx.fillStyle = q.o >= 0 ? '#fff6e6' : '#d8ccb6'; ctx.fillText(String(v), p.x, p.y + 1.5);
      }
      // particles, rings, floats
      for (const pr of parts) { ctx.globalAlpha = clamp(pr.t / 0.4, 0, 1) * 0.85; ctx.beginPath(); ctx.arc(pr.x, pr.y, pr.r, 0, 7); ctx.fillStyle = pr.c; ctx.fill(); }
      ctx.globalAlpha = 1;
      for (const r of rings) { const k = 1 - r.t / r.T; ctx.globalAlpha = 1 - k; ctx.beginPath(); ctx.arc(r.x, r.y, r.r0 + (r.r1 - r.r0) * k, 0, 7); ctx.strokeStyle = r.col; ctx.lineWidth = 3; ctx.stroke(); }
      ctx.globalAlpha = 1;
      for (const f of floats) {
        const k = 1 - f.t / f.T;
        ctx.globalAlpha = clamp(f.t / 0.35, 0, 1);
        ctx.font = '15px ' + DISP; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(12,6,3,.9)';
        const y = f.y - k * 16, x = clamp(f.x, 50, w - 50);
        ctx.strokeText(f.text, x, y); ctx.fillStyle = f.col; ctx.fillText(f.text, x, y);
      }
      ctx.globalAlpha = 1;
      if (drag && drag.moved) drawDrag(t, drag);
      else if (kbOn && kc >= 0 && NS[kc] && canPlay() && sel.some((x) => x !== kc)) drawDrag(t, { srcs: sel, x: NS[kc].x, y: NS[kc].y, kb: 1 });
      drawHUD(t);
      // hints
      if (st.ph === 'play' && me >= 0 && !W.out.includes(me) && !drag) {
        let msg = '';
        if (sel.length && kbOn) msg = '둥지 ' + sel.length + '곳 고름 · 커서를 목표로 옮겨 ' + kl('send') + ' (' + kl('clear') + ' = 취소)';
        else if (sel.length) msg = '둥지 ' + sel.length + '곳 고름 · 보낼 둥지를 톡 (빈 땅 톡 = 취소)';
        else if (kbOn && !sentOnce) msg = '흰 테두리 커서로 내 둥지에서 ' + kl('pick') + ' → 목표에서 ' + kl('send');
        else if (hintT > 0) msg = sentOnce ? '' : '내 둥지를 꾹 눌러 끌고 → 다른 둥지 위에서 떼요';
        if (msg) pill(msg, w / 2, h - lay.bot - 16, hintT > 0 && hintT < 1 && !sel.length ? hintT : 1);
      }
      if (st.ph === 'play' && me >= 0 && W.out.includes(me)) pill('탈락 · 관전 중', w / 2, h - 80, 1, '#ee6a55');
      if (st.ph === 'count') drawCount(t);
    }
    function pill(text, x, y, a, col) {
      ctx.save(); ctx.globalAlpha = a;
      ctx.font = '700 12.5px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const tw = Math.min(cv.w - 20, ctx.measureText(text).width + 22);
      rrect(x - tw / 2, y - 14, tw, 28, 14); ctx.fillStyle = 'rgba(23,19,31,.86)'; ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.45)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = col || '#f2e9d8'; ctx.fillText(text, x, y + 0.5, cv.w - 30);
      ctx.restore();
    }
    function drawDrag(t, drag) {
      const me = seatMe(), col = P(me).color, j = nestAt(drag.x, drag.y);
      const srcs = drag.srcs.filter((s) => s !== j);
      const tx = j >= 0 ? NS[j].x : drag.x, ty = j >= 0 ? NS[j].y : drag.y;
      ctx.lineCap = 'round';
      for (const s of srcs) {
        const p = NS[s], dx = tx - p.x, dy = ty - p.y, d = Math.hypot(dx, dy);
        if (d < 4) continue;
        const ux = dx / d, uy = dy / d, sx = p.x + ux * p.r, sy = p.y + uy * p.r, ex = tx - ux * (j >= 0 ? NS[j].r * 1.2 + 6 : 0), ey = ty - uy * (j >= 0 ? NS[j].r * 1.2 + 6 : 0);
        ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey);
        ctx.strokeStyle = 'rgba(12,6,3,.6)'; ctx.lineWidth = 6; ctx.stroke();
        ctx.setLineDash([2, 6]); ctx.lineDashOffset = -t * 30; ctx.strokeStyle = col; ctx.lineWidth = 4; ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
        ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(ex - ux * 10 - uy * 6, ey - uy * 10 + ux * 6); ctx.lineTo(ex - ux * 10 + uy * 6, ey - uy * 10 - ux * 6); ctx.closePath();
        ctx.fillStyle = col; ctx.fill();
      }
      if (j >= 0) { ctx.beginPath(); ctx.arc(NS[j].x, NS[j].y, NS[j].r * 1.2 + 7, 0, 7); ctx.strokeStyle = '#fff6e6'; ctx.lineWidth = 2.5; ctx.stroke(); }
      // what will happen
      const k = preview(srcs, pct);
      let l1 = srcs.length ? k + '마리 보내기' : '놓을 둥지 위로 끌어요', l2 = '', c2 = '#f2e9d8';
      if (j < 0) l2 = srcs.length ? '빈 땅에서 떼면 취소' : '';
      else if (!srcs.length) { l1 = '여기서 떼면 취소'; }
      else if (W.N[j].o === me) { l2 = drag.kb ? kl('send') + ' = 내 둥지 지원' : '내 둥지 지원'; c2 = '#9fe0b0'; }
      else {
        const q = W.N[j], need = q.c * defK(q), dv = Math.ceil(q.c - 1e-6);
        if (k >= need - 1e-9) { l2 = '지킴 ' + dv + (q.k === 't' ? '×1.5' : '') + ' → 점령 가능'; c2 = '#9fe0b0'; }
        else { l2 = '지킴 ' + dv + (q.k === 't' ? '×1.5' : '') + ' → 모자라요'; c2 = '#ff9a8a'; }
      }
      const bx = clamp(drag.x, 80, cv.w - 80), by = clamp(drag.y - 62, lay.top + 22, cv.h - 40);
      ctx.font = '700 13px ' + FONT;
      const tw = Math.max(ctx.measureText(l1).width, l2 ? ctx.measureText(l2).width : 0) + 24, th = l2 ? 44 : 28;
      rrect(bx - tw / 2, by - th / 2, tw, th, 12); ctx.fillStyle = 'rgba(23,19,31,.92)'; ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fff6e6'; ctx.fillText(l1, bx, by - (l2 ? 8 : 0));
      if (l2) { ctx.font = '700 12px ' + FONT; ctx.fillStyle = c2; ctx.fillText(l2, bx, by + 10); }
    }
    function drawHUD(t) {
      const w = cv.w, me = seatMe();
      const hg = ctx.createLinearGradient(0, 0, 0, HUD_H + 8);
      hg.addColorStop(0, 'rgba(23,19,31,.94)'); hg.addColorStop(0.8, 'rgba(23,19,31,.78)'); hg.addColorStop(1, 'rgba(23,19,31,0)');
      ctx.fillStyle = hg; ctx.fillRect(0, 0, w, HUD_H + 8);
      // timer
      const left = Math.max(0, Math.ceil(st.T - (st.ph === 'play' || st.ph === 'done' ? W.t : 0)));
      const txt = Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
      rrect(8, 6, 56, 28, 9); ctx.fillStyle = left <= 30 && st.ph === 'play' ? 'rgba(238,106,85,.25)' : 'rgba(46,38,64,.92)'; ctx.fill();
      ctx.strokeStyle = left <= 30 && st.ph === 'play' ? '#ee6a55' : 'rgba(242,233,216,.18)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.font = '700 15px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = left <= 30 && st.ph === 'play' ? (Math.sin(t * 8) > 0 || left > 10 ? '#ffb3a6' : '#ee6a55') : '#f2e9d8';
      ctx.fillText(txt, 36, 20.5);
      // colony chips
      const sc = scores(W), n = W.n, x0 = 70, cw = (w - x0 - 8) / n;
      for (let s = 0; s < n; s++) {
        const x = x0 + s * cw, out = W.out.includes(s), col = P(s).color;
        rrect(x + 2, 6, cw - 4, 28, 9); ctx.fillStyle = out ? 'rgba(46,38,64,.5)' : 'rgba(46,38,64,.92)'; ctx.fill();
        ctx.strokeStyle = s === me ? '#e3ae45' : 'rgba(242,233,216,.14)'; ctx.lineWidth = s === me ? 1.6 : 1; ctx.stroke();
        // mini mound in the colony colour = nests, mini ant = ants
        ctx.beginPath(); ctx.arc(x + 12, 24, 6.5, Math.PI, 0); ctx.closePath();
        if (out) { ctx.strokeStyle = col; ctx.lineWidth = 1.4; ctx.stroke(); } else { ctx.fillStyle = col; ctx.fill(); ctx.beginPath(); ctx.ellipse(x + 12, 22.5, 2.2, 1.6, 0, 0, 7); ctx.fillStyle = 'rgba(20,10,5,.85)'; ctx.fill(); }
        ctx.textAlign = 'left';
        if (out) { ctx.font = '700 11.5px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('탈락', x + 22, 20.5, cw - 26); continue; }
        ctx.font = '700 13px ' + MONO; ctx.fillStyle = '#f2e9d8';
        const a = String(sc.nests[s]);
        ctx.fillText(a, x + 21, 20.5);
        const aw = ctx.measureText(a).width, ax = x + 21 + aw + 11;
        const nA = String(Math.floor(sc.ants[s]));
        ctx.font = '600 10.5px ' + MONO; ctx.fillStyle = '#c9bdd6';
        if (x + cw - (x + 21 + aw) >= 20 + ctx.measureText(nA).width) {
          antAt(s, ax, 20.5, 1, 0, 0, 0.6);
          ctx.setTransform(cv.dpr || 1, 0, 0, cv.dpr || 1, 0, 0);
          ctx.fillText(nA, ax + 8, 21);
        } else ctx.fillText('·' + nA, x + 22 + aw, 21, Math.max(8, cw - 28 - aw));
      }
      // strength bar
      let tot = 0;
      for (let s = 0; s < n; s++) tot += sc.ants[s];
      let bx = 8;
      const bw = w - 16;
      rrect(8, 39, bw, 5, 2.5); ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fill();
      if (tot > 0) for (let s = 0; s < n; s++) { const ww = bw * sc.ants[s] / tot; if (ww <= 0) continue; ctx.fillStyle = P(s).color; ctx.fillRect(bx, 39, ww, 5); bx += ww; }
    }
    function drawCount(t) {
      const w = cv.w, h = cv.h, me = seatMe();
      ctx.fillStyle = 'rgba(10,6,4,.5)'; ctx.fillRect(0, HUD_H, w, h - HUD_H);
      const M = MAPS[st.mp];
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const cy = lay.top + (h - lay.top - lay.bot) * 0.42;
      ctx.font = '22px ' + DISP; ctx.fillStyle = '#e3ae45'; ctx.fillText((st.rnd ? '무작위 · ' : '') + M.name, w / 2, cy - 54);
      ctx.font = '600 12.5px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText(M.sub, w / 2, cy - 30, w - 24);
      const n = Math.max(1, Math.ceil(cd));
      ctx.font = '72px ' + DISP; ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(12,6,3,.85)'; ctx.strokeText(String(n), w / 2, cy + 22);
      ctx.fillStyle = '#fff6e6'; ctx.fillText(String(n), w / 2, cy + 22);
      if (me >= 0) {
        const hi = homeOf(W, me), p = hi >= 0 ? NS[hi] : null;
        if (p) {
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 1.2 + 10 + Math.sin(t * 7) * 3, 0, 7); ctx.strokeStyle = '#ffe3a6'; ctx.lineWidth = 3; ctx.stroke();
          const ly = p.y - p.r * 1.2 - 30;
          pill('내 둥지', p.x, ly, 1, P(me).color);
        }
      }
    }

    cv.cv._dbg = () => ({ NS, W, sel, pct, kc }); // test hook (headless screenshots)
    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; startGame(); }
        if (st.ph === 'play' && cd > 0 && !host()) cd = 0;
        if (st.ph === 'done') { ended = true; drag = null; sel = []; }
        syncBar();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        bar.remove(); ffBtn.remove(); styleEl.remove();
        cv.destroy();
      },
    };
  }

  /* ---------- helpers ---------- */
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'ants', name: '개미 군단 영토전', tag: '실시간 땅따먹기', cat: '아케이드',
    blurb: '내 둥지에서 끌어 개미 행렬을 보내 다른 둥지를 빼앗아요. 둥지에선 개미가 저절로 늘어요. 다 물리치거나 시간 끝에 둥지가 가장 많으면 승리!',
    tint: '#4a4212',
    icon: '<path d="M5 50 Q28 22 51 50 Z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><ellipse cx="28" cy="44" rx="5.5" ry="3.5" fill="currentColor"/><ellipse cx="14" cy="15" rx="5.5" ry="4" fill="currentColor"/><ellipse cx="22" cy="14" rx="3" ry="2.2" fill="currentColor"/><circle cx="28" cy="13" r="3.2" fill="currentColor"/><path d="M19 11l-3-6M23 11l2-6M19 17l-3 6M23 17l2 6M30 10q3-5 7-5M31 13q5-1 8 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="42" cy="28" r="2.2" fill="currentColor"/><circle cx="37" cy="31" r="1.6" fill="currentColor"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'p25', label: '보낼 양 25%', keys: ['Digit1', 'Numpad1'], pad: [] },
      { id: 'p50', label: '보낼 양 절반', keys: ['Digit2', 'Numpad2'], pad: [] },
      { id: 'p75', label: '보낼 양 75%', keys: ['Digit3', 'Numpad3'], pad: [] },
      { id: 'p100', label: '보낼 양 전부', keys: ['Digit4', 'Numpad4'], pad: [] },
      { id: 'pct', label: '보낼 양 바꾸기 (차례로)', keys: ['KeyR'], pad: ['y'] },
      { id: 'cu', label: '커서 ↑', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'cd', label: '커서 ↓', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'cl', label: '커서 ←', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'cr', label: '커서 →', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'next', label: '다음 내 둥지로', keys: ['Tab', 'KeyQ'], pad: ['rb'] },
      { id: 'pick', label: '고르기 (적 둥지면 공격)', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'send', label: '커서 둥지로 보내기', keys: ['Enter', 'KeyK'], pad: ['x'] },
      { id: 'clear', label: '고른 것 취소', keys: ['Escape', 'KeyX'], pad: ['b'] },
    ],
    options: [
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.name }))), def: -1 },
      { id: 'time', label: '시간', choices: [{ v: 180, label: '3분' }, { v: 240, label: '4분' }, { v: 360, label: '6분' }], def: 240 },
    ],
    quick: [
      '개미를 보내 다른 둥지를 빼앗는 땅따먹기예요. 내 둥지에선 개미가 저절로 늘어요.',
      '내 둥지를 꾹 눌러 끌고 → 보낼 둥지 위에서 손을 떼면 개미 행렬이 출발해요.',
      '다른 군단을 모두 없애거나, 시간이 끝났을 때 둥지가 가장 많으면 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '개미를 보내 둥지를 빼앗는 땅따먹기예요. 내 둥지는 언제나 화면 아래쪽에서 시작해요.',
        '다른 군단을 모두 없애면(둥지도, 걷고 있는 개미도 0) 바로 승리.',
        '시간(기본 4분)이 끝나면 둥지를 가장 많이 가진 군단이 이겨요. 둥지 수가 같으면 개미 수(둥지 + 걷는 중)가 많은 쪽이 이겨요.',
      ] },
      { h: '조작 (터치)', p: [
        '끌어서 보내기: 내 둥지(내 색 테두리)를 누른 채 끌어서, 보낼 둥지 위에서 손을 떼요. 개미 행렬이 출발해요.',
        '쓸어 담기: 끄는 동안 지나간 다른 내 둥지도 함께 보내요.',
        '끄는 동안 몇 마리가 가는지, 지금 기준으로 「점령 가능 / 모자라요」가 보여요. 빈 땅에서 떼거나, 둥지 하나만 끌다가 그 둥지로 돌아와 떼면 취소.',
        '톡 방식: 내 둥지를 톡톡 눌러 여러 개 고른 뒤 보낼 둥지를 톡. 빈 땅을 톡 하면 고르기 취소.',
        '보낼 양: 아래 버튼 25% · 절반 · 75% · 전부(기본 절반). 고른 둥지마다 그만큼이 떠나요. 이 폰에 기억돼요.',
        '내 둥지로 보내면 지원(합쳐져요), 남의 둥지로 보내면 공격이에요.',
        'PC: 마우스로 끌기가 기본이에요. 키보드 1~4(패드 Ⓨ = 바꾸기)로 보낼 양. 방향키·WASD·왼스틱으로 흰 커서를 옮기고 Tab(RB)은 다음 내 둥지, 스페이스(Ⓐ) = 내 둥지 고르기 / 적 둥지면 바로 공격, Enter(Ⓧ) = 커서 둥지로 보내기, Esc·X(Ⓑ) = 취소. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '둥지', p: [
        '내 둥지에서는 개미가 저절로 늘어요. 큰 둥지일수록 빨리 늘고 많이 담아요(작은 25 · 중간 45 · 큰 70마리에서 멈춰요). 둥지 둘레의 얇은 선이 얼마나 찼는지 보여 줘요.',
        '회색 점선 둥지는 주인이 없어요. 지키는 개미만 있고 늘지 않아요.',
        '맨 위 칸: 남은 시간, 군단마다 둥지 모양 옆에 둥지 수, 개미 모양 옆에 개미 수. 그 아래 막대는 전체 개미 중 각 군단의 몫이에요.',
      ] },
      { h: '싸움', p: [
        '도착한 개미는 내 둥지면 합쳐지고, 남의 둥지면 지키는 개미와 한 마리씩 맞바꿔 싸워요.',
        '지키는 개미가 0이 되면 그 둥지는 내 것이 되고 남은 개미가 들어가요.',
        '행렬은 한 줄로 걸어가서 차례로 도착해요. 서로 다른 군단 행렬이 길에서 마주쳐도 싸우지 않고 지나가요.',
      ] },
      { h: '특별한 둥지', p: [
        '진딧물 농장(초록 잎): 개미가 2배로 빨리 늘어요.',
        '여왕방(왕관): 가지고 있으면 내 모든 둥지가 1.3배 빨리 늘어요. 100마리까지 담아요.',
        '돌 요새(돌 테두리): 지키는 개미 1마리가 공격 개미 1.5마리를 막아요.',
      ] },
      { h: '맵', p: [
        '설정의 「맵」에서 골라요(기본 무작위). 모든 군단이 똑같은 모양으로 놓여서 공평해요. 내 둥지는 언제나 화면 아래쪽이에요.',
        '앞마당 흙밭: 기본. 진딧물 농장: 농장이 많아요. 여왕의 방: 가운데 여왕방이 승부처. 돌 요새: 요새가 길목을 막아요. 넓은 들판: 작은 둥지가 많고 길이 멀어요. 연못 정원: 가운데 연못을 빙 돌아가요.',
      ] },
      { h: '팁', p: [
        '처음엔 가까운 회색(주인 없는) 둥지부터! 늘지 않으니 빨리 먹을수록 이득이에요.',
        '남의 둥지는 개미가 가는 동안에도 늘어요. 「점령 가능」이 간신히 뜨면 조금 더 모아서 보내요.',
        '둥지를 다 비우면 공격받기 쉬워요. 「절반」으로 보내 지킬 개미를 남겨 두세요.',
        '여러 둥지를 쓸어 담아 한꺼번에 보내면 큰 둥지도 한 번에 빼앗을 수 있어요.',
      ] },
      { h: '예시', p: [
        '내 둥지에 30마리, 적 둥지에 지키는 개미 12마리.',
        '→ 「절반」으로 보내면 15마리가 출발 → 12마리와 맞바꾸고 3마리가 남아 점령! 내 둥지에는 15마리가 남아 지켜요.',
        '(돌 요새라면 지키는 개미 1마리가 공격 개미 1.5마리를 막아요. 12마리를 이기려면 18마리 넘게 보내야 해요.)',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 해요. 혼자 하면 나머지 군단은 AI예요. 친구와는 온라인·LAN 방으로 각자 폰에서.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 골라요. 쉬움은 느리고 셈을 자주 틀리고, 어려움은 빨리 판단하고 여러 둥지를 모아 딱 필요한 만큼 보내며 공격받는 둥지를 지켜요.',
        '혼자 하다 탈락하면 「빨리 보기」로 결과까지 빠르게 볼 수 있어요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { AIC, MAPS, STRETCH, buildNests, newWorld, route, posAt, send, land, stepWorld, scores, ranking, aiThink, aliveN, capOf, defK, rateOf, colLen, homeOf, SZ_R, STEP, V },
  });
})();
