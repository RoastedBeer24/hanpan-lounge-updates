/* 레이저 거울 미로 — 거울을 놓거나 돌려 내 레이저로 보석을 모으는 판 게임(1–4명). 1명이면 단계별 퍼즐. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------------- tiles ----------------
     '.' 빈 칸   '#' 벽(빛이 멈춤)   '1' '2' '3' 보석(점수)   'T' 과녁 수정(퍼즐)   'X' 금지 수정(퍼즐, 비추면 안 됨)
     'F' 거울 /   'B' 거울 \  (대전: 누구나 돌릴 수 있음 / 퍼즐: 내가 놓은 거울)
     'f' 'b' 고정 거울 / \ (퍼즐, 못 바꿈)   'k' 'l' 반투명 거울 / \ (빛이 지나가면서 반사도 됨)
     'P' 꺾기 돌(빛이 오른쪽으로 90° 꺾임)   'O' 순간이동 문(짝 문으로 나와 같은 방향으로 계속) */
  const DX = [1, 0, -1, 0], DY = [0, 1, 0, -1]; // 0 right 1 down 2 left 3 up
  const REF_F = [3, 2, 1, 0], REF_B = [1, 0, 3, 2];
  const GEMV = { 1: 1, 2: 2, 3: 3 };
  const isMirror = (ch) => ch === 'F' || ch === 'B';

  /* emitter: [side, idx]; side 0 left (fires right), 1 top (down), 2 right (left), 3 bottom (up) */
  function entry(R, C, e) {
    const s = e[0], k = e[1];
    if (s === 0) return { r: k, c: 0, d: 0 };
    if (s === 1) return { r: 0, c: k, d: 1 };
    if (s === 2) return { r: k, c: C - 1, d: 2 };
    return { r: R - 1, c: k, d: 3 };
  }
  function portalPartner(b, R, C, i) {
    const j = R * C - 1 - i; // point-symmetric partner if it is a portal
    if (j !== i && b[j] === 'O') return j;
    for (let q = 0; q < b.length; q++) if (q !== i && b[q] === 'O') return q;
    return -1;
  }

  /* trace a laser. Returns {segs:[x0,y0,x1,y1,t0, ...] (grid units, cell centre = c+.5), hits:{cell:time}, len}.
     Pure + deterministic; used by apply, AI, preview and animation. */
  const SEEN = new Uint8Array(4 * 100);
  function trace(b, R, C, e, wantSegs) {
    const segs = wantSegs ? [] : null, hits = {};
    SEEN.fill(0, 0, R * C * 4);
    const st = entry(R, C, e);
    const ex = st.c + 0.5 - DX[st.d] * 0.9, ey = st.r + 0.5 - DY[st.d] * 0.9;
    const Q = [[st.r, st.c, st.d, ex, ey, 0]];
    let maxT = 0, guard = 0;
    while (Q.length) {
      let [r, c, d, px, py, t] = Q.pop();
      for (;;) {
        if (++guard > 3000) break;
        if (r < 0 || c < 0 || r >= R || c >= C) {
          const qx = c + 0.5 - DX[d] * 0.5 + DX[d] * 0.25, qy = r + 0.5 - DY[d] * 0.5 + DY[d] * 0.25;
          const l = Math.abs(qx - px) + Math.abs(qy - py);
          if (segs) segs.push(px, py, qx, qy, t);
          t += l; break;
        }
        const i = r * C + c, ch = b[i], cx = c + 0.5, cy = r + 0.5;
        if (ch === '#') {
          const qx = cx - DX[d] * 0.5, qy = cy - DY[d] * 0.5;
          const l = Math.abs(qx - px) + Math.abs(qy - py);
          if (segs) segs.push(px, py, qx, qy, t);
          t += l; break;
        }
        const l = Math.abs(cx - px) + Math.abs(cy - py);
        if (segs) segs.push(px, py, cx, cy, t);
        t += l; px = cx; py = cy;
        const key = i * 4 + d;
        if (SEEN[key]) break;
        SEEN[key] = 1;
        if (ch !== '.' && hits[i] == null && (GEMV[ch] || ch === 'T' || ch === 'X')) hits[i] = t;
        if (ch === 'F' || ch === 'f') d = REF_F[d];
        else if (ch === 'B' || ch === 'b') d = REF_B[d];
        else if (ch === 'k' || ch === 'l') {
          const d2 = ch === 'k' ? REF_F[d] : REF_B[d];
          Q.push([r + DY[d2], c + DX[d2], d2, cx, cy, t]);
        } else if (ch === 'P') d = (d + 1) & 3;
        else if (ch === 'O') {
          const j = portalPartner(b, R, C, i);
          if (j >= 0) { r = (j / C) | 0; c = j % C; px = c + 0.5; py = r + 0.5; if (segs) segs.push(-1, -1, -1, -1, t); }
        }
        r += DY[d]; c += DX[d];
      }
      if (t > maxT) maxT = t;
    }
    return { segs, hits, len: maxT };
  }
  function gainOf(b, hits) { let g = 0; for (const k in hits) g += GEMV[b[k]] || 0; return g; }

  /* ---------------- versus maps (8×8, built from one 4×4 quarter turned 4 times → fair for every seat) ---------------- */
  const N8 = 8;
  const ROT = { F: 'B', B: 'F', k: 'l', l: 'k', f: 'b', b: 'f' };
  function expand(q) {
    const a = Array(64).fill('.');
    for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) {
      let ch = q[r][c], rr = r, cc = c;
      for (let k = 0; k < 4; k++) {
        a[rr * 8 + cc] = ch;
        const nr = cc, nc = 7 - rr; rr = nr; cc = nc; ch = ROT[ch] || ch;
      }
    }
    return a.join('');
  }
  // emitter rows on the left side; the quarter turns give top col 7-a, right row 7-a, bottom col a.
  const MAPS = [
    { n: '수정 정원', q: ['1.12', '....', '2.3#', '#...'], a: 1 },
    { n: '거울 회랑', q: ['2.3#', '....', 'F.2#', '..11'], a: 1 },
    { n: '빛 나누기', q: ['2.#3', '....', '1.2#', 'k.1.'], a: 1 },
    { n: '꺾기 돌 탑', q: ['12.2', 'P1.#', '....', '.3.#'], a: 2 },
    { n: '순간이동 신전', q: ['..#3', '....', '2.21', 'O.#1'], a: 1 },
  ];
  function seatEmitters(n, a) {
    const all = [[0, a], [1, 7 - a], [2, 7 - a], [3, a]];
    if (n === 2) return [all[0], all[2]];
    if (n === 3) return [all[0], all[1], all[2]];
    return all.slice(0, n);
  }

  /* ---------------- puzzle stages (1 player) ---------------- */
  const STAGES = [
    { n: '첫 반사', g: ['#...#', '..T..', '.....', '.....', '#...#'], e: [0, 3], m: 1 },
    { n: '벽 돌아가기', g: ['T....', '.....', '#....', '.....', '.....'], e: [0, 4], m: 2 },
    { n: '수정 두 개', g: ['......', '.T....', '......', '....T.', '..#...', '......'], e: [0, 5], m: 2 },
    { n: '건드리면 안 돼', g: ['......', '.T..X.', '......', '......', '.X....', '......'], e: [3, 4], m: 2 },
    { n: '반투명 거울', g: ['......', '.T...T', '...k..', '......', '..X...', '......'], e: [0, 2], m: 2 },
    { n: '꺾기 돌', g: ['......', '....T.', '.P....', '......', 'T...P.', '......'], e: [3, 1], m: 3 },
    { n: '순간이동 문', g: ['......', '.O..#.', '......', '.T....', '....O.', '......'], e: [0, 1], m: 2 },
    { n: '고정 거울', g: ['.......', '.f...T.', '.......', '...#...', '.......', '.T...b.', '.......'], e: [0, 3], m: 3 },
    { n: '섞어 쓰기', g: ['.......', '.T..#..', '...k...', '.......', '.P...X.', '...T...', '.......'], e: [3, 5], m: 3 },
    { n: '수정 미궁', g: ['........', '.T....#.', '...X....', '.#..k..T', '....O...', '.P......', '...O..X.', 'T.......'], e: [0, 4], m: 4 },
    { n: '두 갈래 길', g: ['....O..', '...T...', '..#..l.', 'T......', '.k..X..', '......T', '..O....'], e: [1, 1], m: 3 },
    { n: '빛의 미궁', g: ['T...#...', '...P....', '.O....X.', '.....T..', '#.k.....', '......O.', '........', '..X.T...'], e: [2, 6], m: 5 },
  ];
  /* ---------------- rules engine ---------------- */
  function init(players, opts) {
    const n = players.length;
    if (n === 1) return puzzleState(0, 0, 0);
    let mp = opts && opts.map != null ? opts.map : -1;
    if (!(mp >= 0 && mp < MAPS.length)) mp = Math.floor(Math.random() * MAPS.length);
    const M = MAPS[mp];
    const rounds = (opts && +opts.rounds) || 8;
    return { md: 'v', R: 8, C: 8, mp, b: expand(M.q), e: seatEmitters(n, M.a), n, nm: players.map((p, i) => String(p.name || '플레이어 ' + (i + 1)).slice(0, 10)), sc: Array(n).fill(0), turn: 0, tn: 0, mx: rounds, last: null, seq: 0, g: Math.floor(Math.random() * 1e6) };
  }
  function puzzleState(k, clr, seq) {
    const S = STAGES[k];
    return { md: 'p', k, R: S.g.length, C: S.g[0].length, b: S.g.join(''), e: [S.e], n: 1, m: S.m, clr, ok: 0, last: null, seq, g: Math.floor(Math.random() * 1e6) };
  }
  function protectedCells(s) { return s.e.map((e) => { const p = entry(s.R, s.C, e); return p.r * s.C + p.c; }); }
  function gemsLeft(s) { let g = 0; for (const ch of s.b) if (GEMV[ch]) g++; return g; }
  function actor(s) {
    if (s.md === 'p') return s.ok && s.k === STAGES.length - 1 ? null : 0;
    return s.over ? null : s.turn;
  }
  function puzzleSolved(s) {
    const h = trace(s.b, s.R, s.C, s.e[0], false).hits;
    for (let i = 0; i < s.b.length; i++) {
      if (s.b[i] === 'T' && h[i] == null) return false;
      if (s.b[i] === 'X' && h[i] != null) return false;
    }
    return true;
  }
  function setCh(b, i, ch) { return b.slice(0, i) + ch + b.slice(i + 1); }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (s.md === 'p') return applyPuzzle(s, a);
    if (s.over || seat !== s.turn) throw new Error('not your turn');
    let kind, c = -1;
    if (a.t === 'shoot') kind = 's'; // 그냥 쏘기: change nothing, just fire
    else {
      c = a.c | 0;
      if (!(c >= 0 && c < s.b.length)) throw new Error('bad cell');
    }
    const ch = c >= 0 ? s.b[c] : '';
    if (kind === 's') { /* nothing to change */ } else if (a.t === 'put') {
      if (ch !== '.' || (a.o !== 'F' && a.o !== 'B')) throw new Error('cannot place');
      if (protectedCells(s).includes(c)) throw new Error('protected');
      s.b = setCh(s.b, c, a.o); kind = 'p';
    } else if (a.t === 'turn') {
      if (!isMirror(ch)) throw new Error('not a mirror');
      s.b = setCh(s.b, c, ch === 'F' ? 'B' : 'F'); kind = 't';
    } else throw new Error('bad action');
    const tr = trace(s.b, s.R, s.C, s.e[seat], false);
    const got = []; let pts = 0;
    for (const k in tr.hits) { const v = GEMV[s.b[k]]; if (v) { got.push(+k, v); pts += v; } }
    for (let q = 0; q < got.length; q += 2) s.b = setCh(s.b, got[q], '.');
    s.sc[seat] += pts;
    s.seq++;
    s.last = { id: s.seq, s: seat, c, k: kind, got, pts };
    s.tn++;
    if (s.tn >= s.mx * s.n || gemsLeft(s) === 0) s.over = 1;
    else s.turn = (s.turn + 1) % s.n;
    return s;
  }
  function applyPuzzle(s, a) {
    const t = a.t;
    if (t === 'go' || t === 'next') {
      const k = t === 'next' ? s.k + 1 : a.k | 0;
      if (!(k >= 0 && k < STAGES.length)) throw new Error('bad stage');
      if (t === 'next' && !s.ok) throw new Error('not solved');
      const ns = puzzleState(k, s.clr, s.seq + 1);
      ns.g = s.g; ns.last = { id: ns.seq, k: 'go' };
      return ns;
    }
    if (s.ok) throw new Error('solved');
    const S = STAGES[s.k];
    if (t === 'reset') {
      s.b = S.g.join(''); s.m = S.m;
    } else {
      const c = a.c | 0;
      if (!(c >= 0 && c < s.b.length)) throw new Error('bad cell');
      const ch = s.b[c];
      if (t === 'put') {
        if (ch !== '.' || s.m <= 0 || (a.o !== 'F' && a.o !== 'B')) throw new Error('cannot place');
        if (protectedCells(s).includes(c)) throw new Error('protected');
        s.b = setCh(s.b, c, a.o); s.m--;
      } else if (t === 'flip') {
        if (!isMirror(ch)) throw new Error('not yours');
        s.b = setCh(s.b, c, ch === 'F' ? 'B' : 'F');
      } else if (t === 'del') {
        if (!isMirror(ch)) throw new Error('not yours');
        s.b = setCh(s.b, c, '.'); s.m++;
      } else throw new Error('bad action');
    }
    s.seq++;
    s.ok = puzzleSolved(s) ? 1 : 0;
    if (s.ok) s.clr |= 1 << s.k;
    s.last = { id: s.seq, k: t, c: a.c != null ? a.c | 0 : -1, ok: s.ok };
    return s;
  }
  function result(s) {
    if (s.md === 'p') {
      if (!(s.ok && s.k === STAGES.length - 1)) return null;
      let n = 0; for (let k = 0; k < STAGES.length; k++) if (s.clr & (1 << k)) n++;
      return { winners: [0], title: '마지막 단계 성공!', text: '이번에 깬 단계 ' + n + ' / ' + STAGES.length };
    }
    if (!s.over) return null;
    const best = Math.max(...s.sc);
    const winners = s.sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    return { winners, text: s.sc.map((v, i) => (s.nm ? s.nm[i] : '#' + (i + 1)) + ' ' + v + '점').join(' · ') };
  }

  /* ---------------- AI ---------------- */
  function movesOf(s) {
    const out = [{ t: 'shoot' }], prot = protectedCells(s);
    for (let i = 0; i < s.b.length; i++) {
      const ch = s.b[i];
      if (ch === '.' && !prot.includes(i)) { out.push({ t: 'put', c: i, o: 'F' }, { t: 'put', c: i, o: 'B' }); }
      else if (isMirror(ch)) out.push({ t: 'turn', c: i });
    }
    return out;
  }
  function boardAfter(b, m) { return m.t === 'shoot' ? b : setCh(b, m.c, m.t === 'put' ? m.o : b[m.c] === 'F' ? 'B' : 'F'); }
  function stripHits(b, hits) { for (const k in hits) if (GEMV[b[k]]) b = setCh(b, +k, '.'); return b; }
  function bestMove(s, b, seat) {
    let best = { g: 0, b3: b };
    const prot = protectedCells(s), arr = b.split(''), e = s.e[seat];
    { const h = trace(arr, s.R, s.C, e, false).hits, g = gainOf(arr, h); if (g > 0) best = { g, b3: stripHits(b, h) }; } // 그냥 쏘기
    for (let i = 0; i < arr.length; i++) {
      const ch = arr[i];
      if (ch === '.' ? prot.includes(i) : !isMirror(ch)) continue;
      const opts = ch === '.' ? 'FB' : ch === 'F' ? 'B' : 'F';
      for (let q = 0; q < opts.length; q++) {
        arr[i] = opts[q];
        const h = trace(arr, s.R, s.C, e, false).hits;
        let g = 0; for (const k in h) g += GEMV[arr[k]] || 0;
        if (g > best.g) best = { g, b3: stripHits(arr.join(''), h) };
      }
      arr[i] = ch;
    }
    return best;
  }
  const bestGain = (s, b, seat) => bestMove(s, b, seat).g;
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.md === 'p') return aiPuzzle(s, lv);
    const ms = movesOf(s);
    const ev = ms.map((m) => {
      const b2 = boardAfter(s.b, m);
      const h = trace(b2, s.R, s.C, s.e[seat], false).hits;
      return { m, g: gainOf(b2, h), b3: stripHits(b2, h) };
    });
    if (lv === 1) {
      if (Math.random() < 0.3) return ms[Math.floor(Math.random() * ms.length)];
      ev.forEach((x) => { x.v = x.g + Math.random() * 2.5; });
    } else {
      ev.forEach((x) => { x.v = x.g + Math.random() * 0.4; });
      if (lv === 3) {
        ev.sort((p, q) => q.v - p.v);
        const turnsLeft = s.mx * s.n - s.tn - 1;
        const K = Math.min(ev.length, s.n === 2 ? 12 : s.n === 3 ? 8 : 6);
        for (let q = 0; q < K; q++) {
          const x = ev[q];
          let pen = 0, nb = x.b3;
          for (let o = 1; o < s.n && o <= turnsLeft; o++) {
            const opp = (seat + o) % s.n;
            const w = o === 1 ? 0.75 : 0.3;
            const r = bestMove(s, x.b3, opp);
            pen += w * r.g;
            if (o === 1) nb = r.b3;
          }
          // what will be left for me after the next player's best reply
          if (turnsLeft >= s.n) pen -= 0.35 * bestMove(s, nb, seat).g;
          x.v -= pen;
        }
        for (let q = K; q < ev.length; q++) ev[q].v -= 99;
      }
    }
    let best = ev[0];
    for (const x of ev) if (x.v > best.v) best = x;
    return best.m;
  }

  /* puzzle solver: DFS placing mirrors only on cells the beam currently crosses (complete, see notes in tests) */
  function solve(b, R, C, e, m, limit) {
    let nodes = 0;
    const ok = (bb) => {
      const h = trace(bb, R, C, e, false).hits;
      for (let i = 0; i < bb.length; i++) {
        if (bb[i] === 'T' && h[i] == null) return false;
        if (bb[i] === 'X' && h[i] != null) return false;
      }
      return true;
    };
    const prot = (() => { const p = entry(R, C, e); return p.r * C + p.c; })();
    function rec(bb, left, out) {
      if (++nodes > (limit || 400000)) return null;
      if (ok(bb)) return out;
      if (!left) return null;
      const segs = trace(bb, R, C, e, true).segs;
      const cells = new Set();
      for (let q = 0; q < segs.length; q += 5) {
        const x = segs[q + 2], y = segs[q + 3];
        if (x < 0) continue;
        if (x % 1 !== 0.5 || y % 1 !== 0.5) continue;
        const i = Math.floor(y) * C + Math.floor(x);
        if (bb[i] === '.' && i !== prot) cells.add(i);
      }
      for (const i of cells) for (const o of 'FB') {
        const r = rec(setCh(bb, i, o), left - 1, out.concat([[i, o]]));
        if (r) return r;
      }
      return null;
    }
    const r = rec(b, m, []);
    return { sol: r, nodes };
  }
  function aiPuzzle(s, lv) {
    if (s.ok) return { t: 'next' };
    const S = STAGES[s.k];
    const base = S.g.join('');
    const placed = [];
    for (let i = 0; i < s.b.length; i++) if (isMirror(s.b[i]) && base[i] === '.') placed.push(i);
    if (lv === 1 && placed.length === 0 && s.m > 1 && Math.random() < 0.5) { // 쉬움: 엉뚱한 데 먼저 놓아 보기
      const free = []; for (let i = 0; i < s.b.length; i++) if (s.b[i] === '.' && !protectedCells(s).includes(i)) free.push(i);
      if (free.length) return { t: 'put', c: free[Math.floor(Math.random() * free.length)], o: Math.random() < 0.5 ? 'F' : 'B' };
    }
    const sol = solve(base, s.R, s.C, s.e[0], S.m).sol || [];
    const want = {}; sol.forEach(([i, o]) => { want[i] = o; });
    for (const i of placed) {
      if (want[i] == null) return { t: 'del', c: i };
      if (s.b[i] !== want[i]) return { t: 'flip', c: i };
    }
    for (const [i, o] of sol) if (s.b[i] !== o) return { t: 'put', c: i, o };
    return { t: 'reset' };
  }
  function aiDelayFor(s, seat, lv) { return s.md === 'p' ? (lv === 1 ? 1100 : lv === 3 ? 500 : 750) : (lv === 1 ? 950 : lv === 3 ? 600 : 750); }

  /* ================= view ================= */
  const hexRgb = (hex) => { const n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const rgba = (hex, a) => { const c = hexRgb(hex); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; };
  function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
  const PORTAL_COL = ['#b98cff', '#49d6c4'];

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, lay = null, bgCv = null, bgKey = '', spr = null;
    let sel = null, preview = null, ghost = null;
    let anim = null, pz = null, pending = false, pendT = 0, shown = '', time = 0, idleAcc = 0, dirty = true;
    let hint = null, watchdog = 0, autoJumped = false;
    const fx = [];
    const disp = [];
    const sp = () => L.debug.speed || 1;

    /* ---------- DOM ---------- */
    const top = L.h('div', { class: 'hud top lz-top', style: { gap: '5px', flexWrap: 'nowrap' } });
    const hud = L.h('div', { class: 'hud bottom' });
    const panel = L.h('div', { class: 'panel lz-panel', style: { display: 'flex', flexDirection: 'column', gap: '8px', width: '100%', maxWidth: '440px', boxSizing: 'border-box' } });
    const infoTxt = L.h('span', { style: { flex: '1', minWidth: '0', overflow: 'hidden', lineHeight: '1.3', maxHeight: '2.6em', wordBreak: 'keep-all' } });
    const infoSub = L.h('span', { class: 'mono muted', style: { fontSize: '12px', whiteSpace: 'pre', textAlign: 'right', lineHeight: '1.3' } });
    const info = L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', minHeight: '22px', fontSize: '14px', fontWeight: 700 } }, infoTxt, infoSub);
    const row = L.h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } });
    const mk = (cls, text, fn, style) => L.h('button', { class: 'btn ' + cls, text, onclick: fn, style: Object.assign({ minHeight: '44px' }, style || {}) });
    const bF = mk('', '／', () => setOri('F'), { width: '48px', padding: '0', fontSize: '20px' });
    const bB = mk('', '＼', () => setOri('B'), { width: '48px', padding: '0', fontSize: '20px' });
    const bCancel = mk('ghost', '취소', () => { sel = null; preview = null; api.sfx('click'); refresh(); });
    const bFire = mk('primary', '쏘기', fire, { flex: '1', whiteSpace: 'nowrap', padding: '10px 8px' });
    const bShoot = mk('', '그냥 쏘기', () => { if (!canPlay() || anim || sel || st.md !== 'v') return; api.buzz(15); act({ t: 'shoot' }); }, { flex: '1', whiteSpace: 'nowrap' });
    const bReset = mk('', '처음부터', () => { if (canPlay()) { api.sfx('click'); act({ t: 'reset' }); } });
    const bHint = mk('', '힌트', showHint);
    const bNext = mk('primary', '다음 단계 ▶', () => { if (canPlay()) { api.sfx('click'); act({ t: 'next' }); } }, { flex: '1' });
    const inv = L.h('span', { class: 'mono', style: { flex: '1', fontSize: '14px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden' } });
    panel.append(info, row);
    hud.append(panel);
    // tutorial spotlight targets (invisible): the board and my own laser
    const boardMark = L.h('div', { class: 'lz-board', style: { position: 'absolute', pointerEvents: 'none' } });
    const meMark = L.h('div', { class: 'lz-me', style: { position: 'absolute', pointerEvents: 'none' } });
    root.append(boardMark, meMark, top, hud);

    function canPlay() {
      if (!st) return false;
      const a = actor(st);
      return a != null && api.canAct(a) && !pending;
    }
    function act(a) { pending = true; clearTimeout(pendT); pendT = setTimeout(() => { pending = false; refresh(); }, 4000); api.act(a); }

    /* ---------- layout + static layer ---------- */
    function layout() {
      if (!st) return;
      const R = st.R, C = st.C, TOP = st.md === 'p' ? 66 : 54, BOT = 126;
      const availW = cv.w - 10, availH = Math.max(80, cv.h - TOP - BOT - 6);
      const cell = Math.max(14, Math.floor(Math.min(availW / (C + 1.3), availH / (R + 1.3), 66)));
      const W = C * cell, H = R * cell;
      lay = { R, C, cell, fr: Math.round(cell * 0.62), W, H, ox: Math.round((cv.w - W) / 2), oy: Math.round(TOP + (availH - H) / 2 + 3) };
      cv.cv._lay = lay; // read by headless UI tests
      Object.assign(boardMark.style, { left: (lay.ox - lay.fr) + 'px', top: (lay.oy - lay.fr) + 'px', width: (W + 2 * lay.fr) + 'px', height: (H + 2 * lay.fr) + 'px' });
      const mine = api.mySeats ? api.mySeats() : [], ep = emitterPose(st.e[mine.length && st.e[mine[0]] ? mine[0] : 0]);
      Object.assign(meMark.style, { left: (ep.x - cell * 0.8) + 'px', top: (ep.y - cell * 0.8) + 'px', width: (cell * 1.6) + 'px', height: (cell * 1.6) + 'px' });
      const statics = st.b.replace(/[FB123TX]/g, '.');
      const key = [cv.w, cv.h, cv.dpr, R, C, statics, JSON.stringify(st.e), st.md].join('|');
      if (key !== bgKey) { bgKey = key; buildSprites(); buildStatic(); }
      dirty = true;
    }
    function offscreen() {
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(cv.w * cv.dpr)); c.height = Math.max(1, Math.round(cv.h * cv.dpr));
      const g = c.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      return { c, g };
    }
    const seatColor = (i) => (api.players[i] && api.players[i].color) || '#ee6a55';
    function emitterPose(e) {
      const { ox, oy, cell, fr, W, H } = lay, s = e[0], k = e[1];
      if (s === 0) return { x: ox - fr * 0.5, y: oy + (k + 0.5) * cell, a: 0 };
      if (s === 1) return { x: ox + (k + 0.5) * cell, y: oy - fr * 0.5, a: Math.PI / 2 };
      if (s === 2) return { x: ox + W + fr * 0.5, y: oy + (k + 0.5) * cell, a: Math.PI };
      return { x: ox + (k + 0.5) * cell, y: oy + H + fr * 0.5, a: -Math.PI / 2 };
    }
    function pairIdx(i, j) {
      const a = Math.min(i, j < 0 ? i : j);
      let n = 0; for (let q = 0; q < a; q++) if (st.b[q] === 'O' && portalPartner(st.b, st.R, st.C, q) > q) n++;
      return n % 2;
    }
    function buildStatic() {
      const { c, g } = offscreen();
      const { ox, oy, cell, fr, W, H, R, C } = lay;
      const w = cv.w, h = cv.h;
      const bgG = g.createRadialGradient(w / 2, oy + H / 2, 20, w / 2, oy + H / 2, Math.max(w, h) * 0.75);
      bgG.addColorStop(0, '#2b2142'); bgG.addColorStop(1, '#110d18');
      g.fillStyle = bgG; g.fillRect(0, 0, w, h);
      // frame
      g.save(); g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = 18; g.shadowOffsetY = 8;
      rr(g, ox - fr, oy - fr, W + 2 * fr, H + 2 * fr, fr * 0.7);
      const fG = g.createLinearGradient(0, oy - fr, 0, oy + H + fr); fG.addColorStop(0, '#3d3150'); fG.addColorStop(1, '#1d1727');
      g.fillStyle = fG; g.fill(); g.restore();
      rr(g, ox - fr + 1.5, oy - fr + 1.5, W + 2 * fr - 3, H + 2 * fr - 3, fr * 0.65);
      g.strokeStyle = 'rgba(227,174,69,.55)'; g.lineWidth = 1.5; g.stroke();
      g.fillStyle = 'rgba(227,174,69,.45)';
      for (const [x, y] of [[ox - fr * 0.5, oy - fr * 0.5], [ox + W + fr * 0.5, oy - fr * 0.5], [ox - fr * 0.5, oy + H + fr * 0.5], [ox + W + fr * 0.5, oy + H + fr * 0.5]]) { g.beginPath(); g.arc(x, y, Math.max(2, cell * 0.06), 0, 7); g.fill(); }
      // bed + tiles
      rr(g, ox - 3, oy - 3, W + 6, H + 6, 6); g.fillStyle = '#0c0a12'; g.fill();
      for (let r = 0; r < R; r++) for (let cc = 0; cc < C; cc++) {
        const x = ox + cc * cell, y = oy + r * cell;
        const tG = g.createLinearGradient(x, y, x + cell, y + cell);
        tG.addColorStop(0, (r + cc) % 2 ? '#2b2339' : '#282034'); tG.addColorStop(1, (r + cc) % 2 ? '#1f1929' : '#1c1725');
        rr(g, x + 1.5, y + 1.5, cell - 3, cell - 3, cell * 0.14); g.fillStyle = tG; g.fill();
        g.strokeStyle = 'rgba(255,255,255,.05)'; g.lineWidth = 1; g.stroke();
      }
      g.fillStyle = '#09070d';
      for (let r = 1; r < R; r++) for (let cc = 1; cc < C; cc++) { g.beginPath(); g.arc(ox + cc * cell, oy + r * cell, Math.max(1.2, cell * 0.04), 0, 7); g.fill(); }
      // protected entry cells (chevrons in the owner's colour)
      st.e.forEach((e, i) => {
        const p = entry(R, C, e), x = ox + p.c * cell, y = oy + p.r * cell, col = seatColor(i);
        rr(g, x + 3, y + 3, cell - 6, cell - 6, cell * 0.12); g.fillStyle = rgba(col, 0.1); g.fill();
        g.save(); g.translate(x + cell / 2, y + cell / 2); g.rotate([0, Math.PI / 2, Math.PI, -Math.PI / 2][p.d]);
        g.strokeStyle = rgba(col, 0.35); g.lineWidth = Math.max(1.5, cell * 0.05); g.lineCap = 'round'; g.lineJoin = 'round';
        for (const dx of [-0.12, 0.08]) { g.beginPath(); g.moveTo((dx - 0.08) * cell, -0.12 * cell); g.lineTo(dx * cell + 0.04 * cell, 0); g.lineTo((dx - 0.08) * cell, 0.12 * cell); g.stroke(); }
        g.restore();
      });
      for (let i = 0; i < st.b.length; i++) {
        const ch = st.b[i], r = (i / C) | 0, cc = i % C, x = ox + cc * cell, y = oy + r * cell;
        if (ch === '#') drawWall(g, x, y, cell);
        else if (ch === 'k' || ch === 'l') drawSplitter(g, x + cell / 2, y + cell / 2, cell, ch === 'k' ? -Math.PI / 4 : Math.PI / 4);
        else if (ch === 'P') drawPrism(g, x + cell / 2, y + cell / 2, cell);
        else if (ch === 'O') {
          const pc = PORTAL_COL[pairIdx(i, portalPartner(st.b, R, C, i))];
          g.fillStyle = '#07060b'; g.beginPath(); g.arc(x + cell / 2, y + cell / 2, cell * 0.36, 0, 7); g.fill();
          g.strokeStyle = rgba(pc, 0.8); g.lineWidth = Math.max(2, cell * 0.06); g.beginPath(); g.arc(x + cell / 2, y + cell / 2, cell * 0.38, 0, 7); g.stroke();
        }
      }
      st.e.forEach((e, i) => drawEmitter(g, emitterPose(e), seatColor(i), cell, fr));
      drawLegend(g);
      bgCv = c;
    }
    function drawLegend(g) { // small key under the board when there is room
      const { oy, H, fr } = lay, y0 = oy + H + fr + 8, room = cv.h - 126 - y0;
      if (room < 30) return;
      const ic = Math.min(30, room - 4), y = y0 + Math.min(room, 44) / 2;
      const items = st.md === 'p' ? [['T0', '비추기'], ['X0', '피하기']] : [['g1', '1점'], ['g2', '2점'], ['g3', '3점']];
      if (st.md === 'p' && st.b.indexOf('X') < 0) items.pop();
      g.font = '700 13px "IBM Plex Sans KR", sans-serif'; g.textBaseline = 'middle'; g.textAlign = 'left';
      const ws = items.map(([, t]) => ic + 2 + g.measureText(t).width);
      const gap = 18, tot = ws.reduce((x, w) => x + w, 0) + gap * (items.length - 1);
      let x = (cv.w - tot) / 2;
      items.forEach(([k, t], i) => {
        g.drawImage(spr[k], x, y - ic / 2 - 2, ic, ic);
        g.fillStyle = '#ab9fb8'; g.fillText(t, x + ic + 2, y);
        x += ws[i] + gap;
      });
    }
    function drawWall(g, x, y, cell) {
      const p = cell * 0.08;
      g.fillStyle = 'rgba(0,0,0,.45)'; rr(g, x + p + 1, y + p + 3, cell - 2 * p, cell - 2 * p, cell * 0.12); g.fill();
      const wG = g.createLinearGradient(x, y, x, y + cell); wG.addColorStop(0, '#6a5c7a'); wG.addColorStop(1, '#3a3048');
      rr(g, x + p, y + p, cell - 2 * p, cell - 2 * p, cell * 0.12); g.fillStyle = wG; g.fill();
      g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1; g.stroke();
      g.strokeStyle = 'rgba(20,14,28,.55)'; g.lineWidth = Math.max(1, cell * 0.03);
      g.beginPath(); g.moveTo(x + p, y + cell / 2); g.lineTo(x + cell - p, y + cell / 2);
      g.moveTo(x + cell / 2, y + p); g.lineTo(x + cell / 2, y + cell / 2);
      g.moveTo(x + cell * 0.3, y + cell / 2); g.lineTo(x + cell * 0.3, y + cell - p);
      g.moveTo(x + cell * 0.72, y + cell / 2); g.lineTo(x + cell * 0.72, y + cell - p); g.stroke();
    }
    function drawSplitter(g, cx, cy, cell, ang) { // glass beam-splitter cube with a half-silvered diagonal
      const h2 = cell * 0.34;
      g.save(); g.translate(cx, cy);
      g.fillStyle = 'rgba(0,0,0,.35)'; rr(g, -h2 + 2, -h2 + 3, 2 * h2, 2 * h2, cell * 0.08); g.fill();
      const cG = g.createLinearGradient(-h2, -h2, h2, h2); cG.addColorStop(0, 'rgba(170,240,255,.42)'); cG.addColorStop(1, 'rgba(60,150,200,.22)');
      rr(g, -h2, -h2, 2 * h2, 2 * h2, cell * 0.08); g.fillStyle = cG; g.fill();
      g.strokeStyle = 'rgba(200,250,255,.85)'; g.lineWidth = 1.2; g.stroke();
      g.rotate(ang);
      const d = h2 * 1.38;
      g.strokeStyle = 'rgba(235,255,255,.95)'; g.lineWidth = Math.max(1.6, cell * 0.05);
      g.beginPath(); g.moveTo(-d, 0); g.lineTo(d, 0); g.stroke();
      g.strokeStyle = 'rgba(120,220,255,.6)'; g.lineWidth = Math.max(1, cell * 0.025);
      g.beginPath(); g.moveTo(-d, cell * 0.04); g.lineTo(d, cell * 0.04); g.stroke();
      g.restore();
      g.fillStyle = 'rgba(255,255,255,.55)'; g.beginPath(); g.ellipse(cx - h2 * 0.55, cy - h2 * 0.62, h2 * 0.28, h2 * 0.1, -0.5, 0, 7); g.fill();
    }
    function drawPrism(g, cx, cy, cell) {
      const r = cell * 0.38;
      const tri = (dx, dy) => { g.beginPath(); for (let k = 0; k < 3; k++) { const a = -Math.PI / 2 + k * 2 * Math.PI / 3; g.lineTo(dx + Math.cos(a) * r, dy + Math.sin(a) * r * 1.05 + r * 0.12); } g.closePath(); };
      g.save(); g.translate(cx, cy);
      g.fillStyle = 'rgba(0,0,0,.35)'; tri(2, 3); g.fill();
      const pG = g.createLinearGradient(-r, -r, r, r);
      pG.addColorStop(0, 'rgba(255,120,140,.6)'); pG.addColorStop(0.35, 'rgba(255,230,120,.5)'); pG.addColorStop(0.65, 'rgba(120,240,170,.5)'); pG.addColorStop(1, 'rgba(120,160,255,.65)');
      tri(0, 0); g.fillStyle = pG; g.fill(); g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 1.2; g.stroke();
      // turn-right arrow
      g.strokeStyle = 'rgba(255,255,255,.95)'; g.lineWidth = Math.max(1.4, cell * 0.045); g.lineCap = 'round'; g.lineJoin = 'round';
      const a0 = -Math.PI * 0.95, a1 = Math.PI * 0.1, rad = r * 0.36, cy0 = r * 0.2;
      g.beginPath(); g.arc(0, cy0, rad, a0, a1); g.stroke();
      const ex = Math.cos(a1) * rad, ey = cy0 + Math.sin(a1) * rad;
      g.beginPath(); g.moveTo(ex - rad * 0.5, ey - rad * 0.1); g.lineTo(ex, ey); g.lineTo(ex + rad * 0.15, ey - rad * 0.55); g.stroke();
      g.restore();
    }
    function drawEmitter(g, P, col, cell, fr) {
      g.save(); g.translate(P.x, P.y); g.rotate(P.a);
      const len = fr * 0.95, wd = cell * 0.62;
      g.fillStyle = 'rgba(0,0,0,.4)'; rr(g, -len / 2 + 1, -wd / 2 + 3, len, wd, wd * 0.25); g.fill();
      const hG = g.createLinearGradient(0, -wd / 2, 0, wd / 2); hG.addColorStop(0, '#d9b25a'); hG.addColorStop(0.5, '#8a6424'); hG.addColorStop(1, '#5a3f14');
      rr(g, -len / 2, -wd / 2, len, wd, wd * 0.25); g.fillStyle = hG; g.fill();
      g.strokeStyle = 'rgba(255,240,200,.35)'; g.lineWidth = 1; g.stroke();
      g.fillStyle = col; rr(g, -len / 2 + len * 0.14, -wd / 2, len * 0.24, wd, 2); g.fill();
      g.fillStyle = '#1a1420'; g.beginPath(); g.arc(len / 2 - 1, 0, wd * 0.27, 0, 7); g.fill();
      const lG = g.createRadialGradient(len / 2 - 1, 0, 0, len / 2 - 1, 0, wd * 0.22); lG.addColorStop(0, '#fff'); lG.addColorStop(0.45, col); lG.addColorStop(1, rgba(col, 0.25));
      g.fillStyle = lG; g.beginPath(); g.arc(len / 2 - 1, 0, wd * 0.21, 0, 7); g.fill();
      g.restore();
    }

    /* ---------- sprites ---------- */
    function sprite(sz, fn) {
      const c = document.createElement('canvas'); const px = Math.max(2, Math.ceil(sz * cv.dpr));
      c.width = px; c.height = px; const g = c.getContext('2d'); g.scale(px / sz, px / sz); fn(g, sz); return c;
    }
    function buildSprites() {
      const cell = lay.cell, S2 = cell * 1.2;
      spr = { size: S2 };
      spr.mirror = sprite(S2, (g, s) => mirrorBar(g, s, false));
      spr.bolted = sprite(S2, (g, s) => mirrorBar(g, s, true));
      for (const v of [1, 2, 3]) spr['g' + v] = sprite(cell, (g, s) => gem(g, s, v));
      spr.T0 = sprite(cell, (g, s) => crystal(g, s, false, false));
      spr.T1 = sprite(cell, (g, s) => crystal(g, s, true, false));
      spr.X0 = sprite(cell, (g, s) => crystal(g, s, false, true));
      spr.X1 = sprite(cell, (g, s) => crystal(g, s, true, true));
      spr.flare = sprite(cell, (g, s) => { const r = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2); r.addColorStop(0, 'rgba(255,255,255,.95)'); r.addColorStop(0.25, 'rgba(255,255,255,.35)'); r.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = r; g.fillRect(0, 0, s, s); });
    }
    function mirrorBar(g, s, bolted) { // horizontal bar centred in the sprite; rotated −45° when drawn = '/'
      const c = s / 2, L2 = lay.cell * 0.52, t = lay.cell * 0.14;
      g.translate(c, c);
      g.fillStyle = 'rgba(0,0,0,.42)'; rr(g, -L2 + 1, -t / 2 + lay.cell * 0.05, 2 * L2, t, t / 2); g.fill();
      const mG = g.createLinearGradient(0, -t / 2, 0, t / 2);
      if (bolted) { mG.addColorStop(0, '#80868f'); mG.addColorStop(0.45, '#d6dbe2'); mG.addColorStop(1, '#565b64'); }
      else { mG.addColorStop(0, '#9fb0c4'); mG.addColorStop(0.4, '#ffffff'); mG.addColorStop(0.6, '#cfe0f2'); mG.addColorStop(1, '#6d7c90'); }
      rr(g, -L2, -t / 2, 2 * L2, t, t / 2); g.fillStyle = mG; g.fill();
      g.strokeStyle = bolted ? '#30343b' : '#2b3442'; g.lineWidth = 1; g.stroke();
      if (bolted) {
        g.fillStyle = '#2a2d33'; for (const sx of [-1, 1]) { g.beginPath(); g.arc(sx * (L2 - t * 0.6), 0, t * 0.28, 0, 7); g.fill(); }
      } else {
        g.fillStyle = '#e3ae45'; g.beginPath(); g.arc(0, 0, t * 0.46, 0, 7); g.fill();
        g.strokeStyle = '#6a4a14'; g.lineWidth = 1; g.stroke();
      }
    }
    function gem(g, s, v) {
      const c = s / 2, cy = s * 0.44;
      const col = v === 1 ? ['#a6ffd0', '#2fbf74', '#0f6a3c'] : v === 2 ? ['#b4d2ff', '#3b7cf0', '#183f96'] : ['#ffffff', '#d6f3ff', '#86b9da'];
      const r = s * (v === 1 ? 0.2 : v === 2 ? 0.23 : 0.27);
      g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(c, cy + r * 1.1, r * 0.95, r * 0.28, 0, 0, 7); g.fill();
      let pts;
      if (v === 1) pts = [[-0.6, -1], [0.6, -1], [1, -0.55], [1, 0.55], [0.6, 1], [-0.6, 1], [-1, 0.55], [-1, -0.55]];
      else if (v === 2) pts = [[0, -1.1], [1, 0], [0, 1.1], [-1, 0]];
      else pts = [[-0.62, -0.75], [0.62, -0.75], [1.1, -0.2], [0, 1.05], [-1.1, -0.2]];
      const gG = g.createLinearGradient(c - r, cy - r, c + r, cy + r);
      gG.addColorStop(0, col[0]); gG.addColorStop(0.5, col[1]); gG.addColorStop(1, col[2]);
      g.beginPath(); pts.forEach(([x, y]) => g.lineTo(c + x * r, cy + y * r)); g.closePath(); g.fillStyle = gG; g.fill();
      g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 1; g.stroke();
      g.strokeStyle = v === 3 ? 'rgba(80,130,170,.55)' : 'rgba(255,255,255,.4)'; g.lineWidth = 0.8; g.beginPath();
      if (v === 1) g.rect(c - r * 0.45, cy - r * 0.55, r * 0.9, r * 1.1);
      else if (v === 2) { g.moveTo(c - r * 0.5, cy); g.lineTo(c, cy - r * 0.55); g.lineTo(c + r * 0.5, cy); g.lineTo(c, cy + r * 0.55); g.closePath(); }
      else { g.moveTo(c - r * 1.1, cy - r * 0.2); g.lineTo(c + r * 1.1, cy - r * 0.2); g.moveTo(c - r * 0.3, cy - r * 0.75); g.lineTo(c - r * 0.5, cy - r * 0.2); g.lineTo(c, cy + r * 1.05); g.lineTo(c + r * 0.5, cy - r * 0.2); g.lineTo(c + r * 0.3, cy - r * 0.75); }
      g.stroke();
      g.fillStyle = 'rgba(255,255,255,.8)'; g.beginPath(); g.ellipse(c - r * 0.35, cy - r * 0.45, r * 0.22, r * 0.11, -0.6, 0, 7); g.fill();
      g.fillStyle = '#e3ae45'; // value pips
      for (let k = 0; k < v; k++) { g.beginPath(); g.arc(c + (k - (v - 1) / 2) * s * 0.12, s * 0.86, s * 0.045, 0, 7); g.fill(); }
    }
    function crystal(g, s, lit, bad) {
      const c = s / 2;
      const base = bad ? (lit ? ['#ffd0d0', '#ff4b4b', '#7a0d16'] : ['#d06a7a', '#8a2436', '#3a0a14']) : (lit ? ['#ffffff', '#8ff3ff', '#2aa6c8'] : ['#9ab8c4', '#4f6f7e', '#26353f']);
      g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(c, s * 0.8, s * 0.26, s * 0.07, 0, 0, 7); g.fill();
      g.fillStyle = bad ? '#3b2028' : '#3a3346'; g.beginPath(); g.ellipse(c, s * 0.77, s * 0.24, s * 0.08, 0, 0, 7); g.fill();
      [[0, 0.6, 0.11], [-0.16, 0.4, 0.08], [0.16, 0.45, 0.085]].forEach(([dx, hh, ww]) => {
        const x = c + dx * s, y0 = s * 0.76, y1 = y0 - hh * s;
        const cG = g.createLinearGradient(x - ww * s, 0, x + ww * s, 0); cG.addColorStop(0, base[2]); cG.addColorStop(0.45, base[0]); cG.addColorStop(1, base[1]);
        g.beginPath(); g.moveTo(x - ww * s, y0); g.lineTo(x - ww * s, y1 + ww * s); g.lineTo(x, y1); g.lineTo(x + ww * s, y1 + ww * s); g.lineTo(x + ww * s, y0); g.closePath();
        g.fillStyle = cG; g.fill(); g.strokeStyle = lit ? 'rgba(255,255,255,.85)' : 'rgba(255,255,255,.28)'; g.lineWidth = 0.8; g.stroke();
      });
      if (bad) {
        g.strokeStyle = lit ? '#ff6060' : 'rgba(255,90,90,.6)'; g.lineWidth = Math.max(1.5, s * 0.045);
        g.beginPath(); g.arc(c, s * 0.5, s * 0.41, 0, 7); g.stroke();
        g.beginPath(); g.moveTo(c - s * 0.29, s * 0.21); g.lineTo(c + s * 0.29, s * 0.79); g.stroke();
      }
    }

    /* ---------- drawing ---------- */
    const cellXY = (i) => ({ x: lay.ox + (i % lay.C + 0.5) * lay.cell, y: lay.oy + (((i / lay.C) | 0) + 0.5) * lay.cell });
    function drawMirrorAt(i, ch, ang, scale) {
      const p = cellXY(i), sz = spr.size;
      ctx.save(); ctx.translate(p.x, p.y);
      ctx.rotate(ang != null ? ang : (ch === 'F' || ch === 'f') ? -Math.PI / 4 : Math.PI / 4);
      if (scale != null && scale !== 1) ctx.scale(scale, scale);
      ctx.drawImage(ch === 'f' || ch === 'b' ? spr.bolted : spr.mirror, -sz / 2, -sz / 2, sz, sz);
      ctx.restore();
    }
    function drawPieces(b, opt) {
      const cell = lay.cell;
      for (let i = 0; i < b.length; i++) {
        const ch = b[i];
        if (ch === '.' || ch === '#' || ch === 'k' || ch === 'l' || ch === 'P') continue;
        if (opt && opt.skip && opt.skip(i)) continue;
        const p = cellXY(i);
        if (ch === 'F' || ch === 'B' || ch === 'f' || ch === 'b') drawMirrorAt(i, ch);
        else if (ch === '1' || ch === '2' || ch === '3') {
          const bob = Math.sin(time * 2 + i) * cell * 0.025;
          ctx.drawImage(spr['g' + ch], p.x - cell / 2, p.y - cell / 2 + bob, cell, cell);
          const tw = (time * 0.7 + i * 0.37) % 3;
          if (tw < 0.35) sparkle(p.x - cell * 0.1 + (i % 3) * cell * 0.08, p.y - cell * 0.16 + bob, cell * 0.16 * Math.sin(tw / 0.35 * Math.PI));
        } else if (ch === 'T' || ch === 'X') {
          const lit = opt && opt.lit && opt.lit[i];
          if (lit) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.55 + 0.25 * Math.sin(time * 6); ctx.drawImage(spr.flare, p.x - cell * 0.75, p.y - cell * 0.8, cell * 1.5, cell * 1.5); ctx.restore(); }
          ctx.drawImage(spr[ch + (lit ? 1 : 0)], p.x - cell / 2, p.y - cell / 2, cell, cell);
        } else if (ch === 'O') {
          const j = portalPartner(b, lay.R, lay.C, i), pc = PORTAL_COL[pairIdx(i, j)];
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(time * 2.2 * (i < j ? 1 : -1));
          ctx.strokeStyle = pc; ctx.lineCap = 'round';
          for (let k = 0; k < 3; k++) {
            ctx.globalAlpha = 0.9 - k * 0.25; ctx.lineWidth = Math.max(1.5, cell * (0.06 - k * 0.012));
            ctx.beginPath(); ctx.arc(0, 0, cell * (0.28 - k * 0.08), k * 2.1, k * 2.1 + 3.6); ctx.stroke();
          }
          ctx.restore();
        }
      }
    }
    function sparkle(x, y, r) {
      if (r <= 0.5) return;
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,255,255,.9)';
      ctx.beginPath(); ctx.moveTo(x, y - r); ctx.lineTo(x + r * 0.18, y - r * 0.18); ctx.lineTo(x + r, y); ctx.lineTo(x + r * 0.18, y + r * 0.18);
      ctx.lineTo(x, y + r); ctx.lineTo(x - r * 0.18, y + r * 0.18); ctx.lineTo(x - r, y); ctx.lineTo(x - r * 0.18, y - r * 0.18); ctx.closePath(); ctx.fill(); ctx.restore();
    }
    function beamPath(segs, T) {
      const { ox, oy, cell } = lay;
      ctx.beginPath();
      for (let q = 0; q < segs.length; q += 5) {
        const x0 = segs[q]; if (x0 < 0) continue;
        const t0 = segs[q + 4]; if (t0 >= T) continue;
        const y0 = segs[q + 1], x1 = segs[q + 2], y1 = segs[q + 3];
        const l = Math.abs(x1 - x0) + Math.abs(y1 - y0), f = l > 0 ? Math.min(1, (T - t0) / l) : 1;
        ctx.moveTo(ox + x0 * cell, oy + y0 * cell); ctx.lineTo(ox + (x0 + (x1 - x0) * f) * cell, oy + (y0 + (y1 - y0) * f) * cell);
      }
    }
    function drawBeam(segs, T, col, alpha, dashed) {
      const cell = lay.cell;
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      beamPath(segs, T);
      if (!dashed) {
        ctx.strokeStyle = rgba(col, 0.16 * alpha); ctx.lineWidth = cell * 0.44; ctx.stroke();
        ctx.strokeStyle = rgba(col, 0.55 * alpha); ctx.lineWidth = cell * 0.17; ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.85 * alpha).toFixed(3) + ')'; ctx.lineWidth = Math.max(1.5, cell * 0.05); ctx.stroke();
      } else {
        ctx.strokeStyle = rgba(col, 0.2 * alpha); ctx.lineWidth = cell * 0.2; ctx.stroke();
        ctx.setLineDash([cell * 0.16, cell * 0.2]); ctx.lineDashOffset = -time * cell * 1.6;
        ctx.strokeStyle = rgba(col, 0.9 * alpha); ctx.lineWidth = Math.max(1.5, cell * 0.06); ctx.stroke();
      }
      ctx.restore();
    }
    function drawHeads(segs, T, len) {
      if (T >= len) return;
      const { ox, oy, cell } = lay;
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      for (let q = 0; q < segs.length; q += 5) {
        const x0 = segs[q]; if (x0 < 0) continue;
        const t0 = segs[q + 4], x1 = segs[q + 2], y1 = segs[q + 3], y0 = segs[q + 1];
        const l = Math.abs(x1 - x0) + Math.abs(y1 - y0);
        if (T <= t0 || T >= t0 + l) continue;
        const f = (T - t0) / l, x = ox + (x0 + (x1 - x0) * f) * cell, y = oy + (y0 + (y1 - y0) * f) * cell;
        ctx.drawImage(spr.flare, x - cell * 0.5, y - cell * 0.5, cell, cell);
      }
      ctx.restore();
    }
    function ring(i, col, a, rad) {
      const p = cellXY(i);
      ctx.save(); ctx.strokeStyle = col; ctx.globalAlpha = U.clamp(a, 0, 1); ctx.lineWidth = Math.max(2, lay.cell * 0.06);
      ctx.beginPath(); ctx.arc(p.x, p.y, lay.cell * (rad || 0.42), 0, 7); ctx.stroke(); ctx.restore();
    }
    function draw() {
      if (!st || !lay || !bgCv) return;
      ctx.drawImage(bgCv, 0, 0, cv.w, cv.h);
      const cell = lay.cell;
      if (st.md === 'p') drawPuzzle(); else drawVersus();
      ctx.save();
      for (const f of fx) {
        const a = Math.max(0, 1 - f.t / f.life);
        if (f.txt) {
          ctx.globalAlpha = a; ctx.fillStyle = f.col; ctx.strokeStyle = 'rgba(10,6,16,.85)'; ctx.lineWidth = 3;
          ctx.font = '800 ' + Math.round(cell * 0.42) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.strokeText(f.txt, f.x, f.y); ctx.fillText(f.txt, f.x, f.y);
        } else {
          ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = a; ctx.fillStyle = f.col;
          ctx.fillRect(f.x - f.s / 2, f.y - f.s / 2, f.s, f.s);
        }
      }
      ctx.restore();
    }
    function drawVersus() {
      const cell = lay.cell;
      let b = st.b, skip = null;
      if (anim) { b = anim.preB; skip = (i) => anim.popped[i] || i === anim.c; }
      else if (sel) skip = (i) => i === sel.c;
      const turn = anim ? anim.seat : actor(st);
      if (turn != null) {
        const P = emitterPose(st.e[turn]);
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.45 + 0.3 * Math.sin(time * 4);
        ctx.drawImage(spr.flare, P.x - cell * 0.6, P.y - cell * 0.6, cell * 1.2, cell * 1.2); ctx.restore();
      }
      if (ghost && !anim && !sel) {
        drawBeam(ghost.segs, 1e9, seatColor(actor(st)), 0.4, true);
        ctx.save(); ctx.font = '800 ' + Math.round(cell * 0.28) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 3;
        for (const k in ghost.hits) { // what 「그냥 쏘기」 would collect right now
          const v = GEMV[st.b[k]]; if (!v) continue;
          const p = cellXY(+k);
          ring(+k, seatColor(actor(st)), 0.5, 0.44);
          ctx.strokeStyle = 'rgba(10,6,16,.9)'; ctx.fillStyle = 'rgba(255,255,255,.85)';
          ctx.strokeText('+' + v, p.x + cell * 0.3, p.y - cell * 0.3); ctx.fillText('+' + v, p.x + cell * 0.3, p.y - cell * 0.3);
        }
        ctx.restore();
      }
      drawPieces(b, { skip });
      if (anim) {
        const ph = U.clamp(anim.t / 0.25, 0, 1), e = 1 - Math.pow(1 - ph, 3);
        const toCh = anim.preB[anim.c];
        if (anim.k === 's') { /* 그냥 쏘기: no mirror change */ }
        else if (anim.k === 'p') drawMirrorAt(anim.c, toCh, null, 0.4 + 0.6 * e + Math.sin(ph * Math.PI) * 0.15);
        else { const a1 = toCh === 'F' ? -Math.PI / 4 : Math.PI / 4; drawMirrorAt(anim.c, toCh, -a1 + 2 * a1 * e); }
        if (anim.t < 0.6 && anim.c >= 0) ring(anim.c, seatColor(anim.seat), 1 - anim.t / 0.6, 0.38 + anim.t * 0.3);
        if (anim.T > 0) {
          const al = anim.fade != null ? Math.max(0, 1 - anim.fade / 0.45) : 1;
          drawBeam(anim.segs, anim.T, anim.col, al, false);
          drawHeads(anim.segs, anim.T, anim.len);
        }
      } else if (sel) {
        const ch = sel.t === 'put' ? sel.o : (st.b[sel.c] === 'F' ? 'B' : 'F');
        ctx.save(); ctx.globalAlpha = 0.8 + 0.2 * Math.sin(time * 5); drawMirrorAt(sel.c, ch); ctx.restore();
        ring(sel.c, '#e3ae45', 0.9, 0.48);
        if (preview) {
          const col = seatColor(actor(st));
          drawBeam(preview.segs, 1e9, col, 0.8, true);
          ctx.save(); ctx.font = '800 ' + Math.round(cell * 0.32) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 3;
          for (const k in preview.hits) {
            const v = GEMV[st.b[k]]; if (!v) continue;
            const p = cellXY(+k);
            ring(+k, col, 0.75 + 0.25 * Math.sin(time * 6), 0.44);
            ctx.strokeStyle = 'rgba(10,6,16,.9)'; ctx.fillStyle = '#fff';
            ctx.strokeText('+' + v, p.x + cell * 0.3, p.y - cell * 0.3); ctx.fillText('+' + v, p.x + cell * 0.3, p.y - cell * 0.3);
          }
          ctx.restore();
        }
      }
    }
    function drawPuzzle() {
      if (!pz) return;
      const lit = {};
      for (const k in pz.hits) if (pz.hits[k] <= pz.T) lit[k] = 1;
      drawBeam(pz.segs, pz.T, seatColor(0), 1, false);
      drawHeads(pz.segs, pz.T, pz.len);
      drawPieces(st.b, { lit });
      const base = STAGES[st.k].g.join('');
      ctx.fillStyle = 'rgba(227,174,69,.95)';
      for (let i = 0; i < st.b.length; i++) if (isMirror(st.b[i]) && base[i] === '.') { const p = cellXY(i); ctx.beginPath(); ctx.arc(p.x + lay.cell * 0.36, p.y - lay.cell * 0.36, Math.max(2, lay.cell * 0.05), 0, 7); ctx.fill(); }
      if (hint && hint.until > time) {
        const a = 0.45 + 0.35 * Math.sin(time * 7);
        if (hint.o) { ctx.save(); ctx.globalAlpha = a; drawMirrorAt(hint.c, hint.o); ctx.restore(); }
        ring(hint.c, hint.bad ? '#ff6a5a' : '#8ff3ff', 0.9, 0.47);
      }
    }

    /* ---------- loop ---------- */
    const stopLoop = U.loop((dt) => {
      time += dt;
      let moving = false;
      if (anim) { stepAnim(dt * sp()); moving = true; }
      if (pz && pz.T < pz.len) { pz.T += dt * 34 * sp(); if (pz.T >= pz.len) { pz.T = pz.len + 0.01; pzDone(); } moving = true; }
      for (let q = fx.length - 1; q >= 0; q--) { const f = fx[q]; f.t += dt; f.x += f.vx * dt; f.y += f.vy * dt; f.vy += (f.g || 0) * dt; if (f.t >= f.life) fx.splice(q, 1); }
      if (moving || fx.length || sel || dirty || (hint && hint.until > time)) { dirty = false; draw(); return; }
      idleAcc += dt;
      if (idleAcc > 0.06) { idleAcc = 0; draw(); }
    });

    function burst(i, col, n, txt) {
      const p = cellXY(i), cell = lay.cell;
      for (let k = 0; k < n; k++) { const a = Math.random() * 6.283, v = cell * (1.5 + Math.random() * 3); fx.push({ x: p.x, y: p.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: cell * 4, t: 0, life: 0.45 + Math.random() * 0.3, col, s: Math.max(2, cell * 0.07) }); }
      if (txt) fx.push({ x: p.x, y: p.y - cell * 0.2, vx: 0, vy: -cell * 1.4, t: 0, life: 0.9, col, txt });
    }

    /* versus: replay the shot stored in state.last */
    function startShot(last) {
      finishShot(true);
      const preArr = st.b.split('');
      for (let q = 0; q < last.got.length; q += 2) preArr[last.got[q]] = String(last.got[q + 1]);
      const preB = preArr.join('');
      const tr = trace(preB, st.R, st.C, st.e[last.s], true);
      anim = { seat: last.s, c: last.c, k: last.k, preB, segs: tr.segs, hits: tr.hits, len: tr.len, T: 0, t: 0, popped: {}, col: seatColor(last.s), fade: null, pts: last.pts, hold: 0 };
      for (let i = 0; i < st.n; i++) disp[i] = st.sc[i] - (i === last.s ? last.pts : 0);
      api.setBusy(true);
      api.sfx(last.k === 'p' ? 'pop' : last.k === 't' ? 'click' : 'tick');
      clearTimeout(watchdog);
      watchdog = setTimeout(() => finishShot(false), (2600 + tr.len * 60) / sp() + 1500);
    }
    function stepAnim(dt) {
      const a = anim;
      a.t += dt;
      if (a.t < 0.25) return;
      if (a.T === 0) api.sfx('whoosh');
      if (a.T < a.len) {
        a.T = Math.min(a.len, a.T + dt * 24);
        for (const k in a.hits) {
          if (a.popped[k] || a.hits[k] > a.T) continue;
          const v = GEMV[a.preB[k]];
          if (!v) continue;
          a.popped[k] = 1; disp[a.seat] += v; renderTop();
          burst(+k, a.col, 14, '+' + v); api.sfx('chip'); api.buzz(8);
        }
        return;
      }
      a.hold += dt;
      if (a.hold < 0.3) return;
      a.fade = (a.fade || 0) + dt;
      if (a.fade >= 0.45) finishShot(false);
    }
    function finishShot(silent) {
      if (!anim) return;
      clearTimeout(watchdog);
      const a = anim; anim = null;
      for (let i = 0; i < st.n; i++) disp[i] = st.sc[i];
      if (!silent && a.pts >= 5) api.toast(api.players[a.seat].name + ' +' + a.pts + '점!');
      computeGhost(); refresh(); dirty = true;
      api.setBusy(false);
    }

    /* puzzle: live beam, regrown from where the path changed */
    function setPuzzleBeam(fromScratch) {
      const tr = trace(st.b, st.R, st.C, st.e[0], true);
      let T0 = 0;
      if (pz && !fromScratch) {
        const a = pz.segs, b = tr.segs; let q = 0;
        while (q < a.length && q < b.length && a[q] === b[q] && a[q + 1] === b[q + 1] && a[q + 2] === b[q + 2] && a[q + 3] === b[q + 3]) q += 5;
        T0 = q < b.length ? b[q + 4] : tr.len + 0.01;
        T0 = Math.min(T0, pz.T);
      }
      const celebrated = !!(pz && pz.ok && pz.k === st.k && !fromScratch);
      pz = { segs: tr.segs, hits: tr.hits, len: tr.len, T: T0, ok: st.ok, k: st.k, celebrated };
      if (pz.T < pz.len) {
        api.setBusy(true);
        clearTimeout(watchdog);
        watchdog = setTimeout(() => { if (pz && pz.T < pz.len) { pz.T = pz.len + 0.01; pzDone(); } }, 1200 / sp() + 1500);
      } else pzDone();
    }
    function pzDone() {
      clearTimeout(watchdog);
      if (st && st.md === 'p' && pz) {
        if (st.ok && !pz.celebrated) {
          pz.celebrated = true;
          for (let i = 0; i < st.b.length; i++) if (st.b[i] === 'T') burst(i, '#8ff3ff', 16);
          api.sfx('win'); api.buzz(25);
          if (st.k < STAGES.length - 1) api.toast('성공! 수정이 모두 빛나요');
          saveProgress();
        } else if (!st.ok && st.last && /^(put|flip|del)$/.test(st.last.k) && Object.keys(pz.hits).some((k) => st.b[k] === 'X')) api.sfx('lose');
      }
      refresh();
      api.setBusy(false);
    }
    function saveProgress() {
      if (api.online || !api.canAct(0) || !U.store) return;
      U.store.set('laser.clr', (U.store.get('laser.clr', 0) | 0) | (1 << st.k));
    }

    /* ---------- versus helpers ---------- */
    function computeGhost() {
      ghost = null;
      if (!st || st.md !== 'v' || st.over) return;
      const a = actor(st);
      if (a != null && api.canAct(a)) { ghost = trace(st.b, st.R, st.C, st.e[a], true); ghost.gain = gainOf(st.b, ghost.hits); }
    }
    function computePreview() {
      preview = null;
      if (!sel) return;
      const ch = sel.t === 'put' ? sel.o : (st.b[sel.c] === 'F' ? 'B' : 'F');
      const b2 = setCh(st.b, sel.c, ch);
      const tr = trace(b2, st.R, st.C, st.e[actor(st)], true);
      preview = { segs: tr.segs, hits: tr.hits, gain: gainOf(b2, tr.hits) };
    }
    function setOri(o) {
      if (!sel || sel.t !== 'put') return;
      sel.o = o; api.sfx('click'); api.buzz(8); computePreview(); refresh();
    }
    function fire() {
      if (!sel || !canPlay() || anim) return;
      const a = sel.t === 'put' ? { t: 'put', c: sel.c, o: sel.o } : { t: 'turn', c: sel.c };
      sel = null; preview = null; api.buzz(15);
      act(a);
    }
    function tapCell(i) {
      if (st.md === 'p') return tapPuzzle(i);
      if (!canPlay() || anim || st.over) return;
      if (i < 0) { if (sel) { sel = null; preview = null; refresh(); } return; }
      const ch = st.b[i];
      if (ch === '.') {
        if (protectedCells(st).includes(i)) { api.toast('레이저 바로 앞 칸은 비워 둬요'); return; }
        if (sel && sel.c === i && sel.t === 'put') { setOri(sel.o === 'F' ? 'B' : 'F'); return; }
        const a = actor(st);
        const gF = gainOf(st.b, trace(setCh(st.b, i, 'F'), st.R, st.C, st.e[a], false).hits);
        const gB = gainOf(st.b, trace(setCh(st.b, i, 'B'), st.R, st.C, st.e[a], false).hits);
        sel = { t: 'put', c: i, o: gB > gF ? 'B' : 'F' };
      } else if (isMirror(ch)) {
        if (sel && sel.c === i) return;
        sel = { t: 'turn', c: i };
      } else {
        api.toast(GEMV[ch] ? '보석 칸에는 못 놓아요' : ch === '#' ? '벽이에요' : '빈 칸이나 거울을 눌러요');
        return;
      }
      api.sfx('tick'); api.buzz(8);
      computePreview(); refresh();
    }
    function tapPuzzle(i) {
      if (!canPlay() || i < 0 || st.ok) return;
      const ch = st.b[i], base = STAGES[st.k].g.join('');
      if (ch === '.') {
        if (protectedCells(st).includes(i)) { api.toast('레이저 바로 앞 칸은 비워 둬요'); return; }
        if (st.m <= 0) { api.toast('거울을 다 썼어요 — 놓은 거울을 눌러 빼요'); return; }
        api.sfx('pop'); api.buzz(8); hint = null; act({ t: 'put', c: i, o: 'F' });
      } else if (isMirror(ch) && base[i] === '.') {
        api.sfx('click'); api.buzz(8); hint = null;
        act(ch === 'F' ? { t: 'flip', c: i } : { t: 'del', c: i });
      } else if (ch === 'f' || ch === 'b') api.toast('고정된 거울이에요');
      else api.toast('빈 칸을 눌러 거울을 놓아요');
    }
    function showHint() {
      if (!canPlay() || st.ok) return;
      const S = STAGES[st.k], base = S.g.join('');
      let r = solve(st.b, st.R, st.C, st.e[0], st.m, 60000).sol;
      if (r && r.length) { hint = { c: r[0][0], o: r[0][1], until: time + 2.6 }; api.toast('반짝이는 자리에 거울을 놓아 보세요'); }
      else {
        r = solve(base, st.R, st.C, st.e[0], S.m).sol || [];
        const want = {}; r.forEach(([i, o]) => { want[i] = o; });
        let bad = -1;
        for (let i = 0; i < st.b.length; i++) if (isMirror(st.b[i]) && base[i] === '.' && want[i] !== st.b[i]) { bad = i; break; }
        if (bad >= 0) { hint = { c: bad, bad: true, until: time + 2.6 }; api.toast('빨간 동그라미 거울을 돌리거나 빼 보세요'); }
        else if (r.length) { hint = { c: r[0][0], o: r[0][1], until: time + 2.6 }; api.toast('반짝이는 자리에 거울을 놓아 보세요'); }
      }
      api.sfx('tick'); dirty = true;
    }

    /* ---------- input ---------- */
    let down = null;
    function onDown(e) { down = { x: e.clientX, y: e.clientY }; }
    function onUp(e) {
      if (!down || !st || !lay) return;
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y); down = null;
      if (moved > 14) return;
      const p = cv.local(e), { ox, oy, cell, R, C } = lay;
      const cx = Math.floor((p.x - ox) / cell), cy = Math.floor((p.y - oy) / cell);
      tapCell(cx >= 0 && cy >= 0 && cx < C && cy < R ? cy * C + cx : -1);
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointerup', onUp);
    cv.onresize = () => { layout(); renderTop(); };

    /* ---------- HUD ---------- */
    function renderTop() {
      top.innerHTML = '';
      if (!st) return;
      if (st.md === 'p') {
        const S = STAGES[st.k], done = st.clr & (1 << st.k);
        const nav = (d) => L.h('button', { class: 'btn sm', text: d < 0 ? '◀' : '▶', 'aria-label': d < 0 ? '이전 단계' : '다음 단계', style: { minWidth: '44px', minHeight: '44px', padding: '0' },
          disabled: !canPlay() || st.k + d < 0 || st.k + d >= STAGES.length ? true : null,
          onclick() { if (canPlay()) { api.sfx('click'); act({ t: 'go', k: st.k + d }); } } });
        top.append(nav(-1), L.h('span', { class: 'turn', style: { maxWidth: (cv.w - 150) + 'px', fontSize: '14px', minHeight: '32px' } },
          L.h('b', { class: 'mono', text: (st.k + 1) + '/' + STAGES.length }), ' ' + S.n + (done ? ' ✓' : '')), nav(1));
        return;
      }
      const cur = anim ? anim.seat : actor(st);
      const nameW = Math.max(26, Math.floor((cv.w - 24 - st.n * 46 - (st.n - 1) * 5) / st.n));
      for (let i = 0; i < st.n; i++) {
        const p = api.players[i];
        top.append(L.h('span', { class: 'turn', style: { opacity: cur === i || cur == null ? 1 : 0.6, borderColor: cur === i ? p.color : '', padding: '4px 7px 4px 6px', gap: '5px', fontSize: '12px', flex: 'none' } },
          L.h('span', { class: 'dot', style: { '--c': p.color } }),
          L.h('span', { text: p.name, style: { maxWidth: nameW + 'px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }),
          L.h('b', { class: 'mono', style: { fontSize: '14px' }, text: String(disp[i] != null ? disp[i] : st.sc[i]) })));
      }
    }
    function refresh() {
      if (!st) return;
      row.innerHTML = '';
      if (st.md === 'p') {
        const S = STAGES[st.k];
        let lit = 0, tot = 0, bad = false;
        const h2 = pz ? pz.hits : {};
        for (let i = 0; i < st.b.length; i++) { if (st.b[i] === 'T') { tot++; if (h2[i] != null) lit++; } if (st.b[i] === 'X' && h2[i] != null) bad = true; }
        const mine = canPlay() || (actor(st) != null && api.canAct(actor(st)));
        infoTxt.textContent = st.ok ? (st.k === STAGES.length - 1 ? '마지막 단계까지 성공!' : '성공! 수정이 모두 빛나요') : bad ? '빨간 수정에 빛이 닿았어요!' : !mine ? 'AI가 푸는 중' : '수정을 모두 비추세요';
        infoTxt.style.color = st.ok ? 'var(--brass)' : bad ? 'var(--coral)' : '';
        infoSub.textContent = '수정 ' + lit + '/' + tot;
        inv.textContent = '거울 ' + st.m + '/' + S.m;
        if (st.ok) { if (st.k < STAGES.length - 1) row.append(inv, bNext); else row.append(inv); }
        else row.append(inv, bReset, bHint);
        bReset.disabled = !mine; bHint.disabled = !mine; bNext.disabled = !mine;
        renderTop();
        return;
      }
      const a = actor(st), mine = a != null && api.canAct(a) && !anim;
      infoTxt.style.color = '';
      infoSub.textContent = st.over ? '' : '라운드 ' + Math.min(st.mx, Math.floor(st.tn / st.n) + 1) + '/' + st.mx + '\n보석 ' + gemsLeft(st) + '개';
      if (anim) infoTxt.textContent = api.players[anim.seat].name + ' 발사!';
      else if (st.over) infoTxt.textContent = '게임 끝';
      else if (mine && sel) {
        const g = preview ? preview.gain : 0;
        infoTxt.textContent = g > 0 ? '+' + g + '점 예상 — 쏠까요?' : '이 수로는 보석이 없어요';
        infoTxt.style.color = g > 0 ? 'var(--brass)' : 'var(--muted)';
        if (sel.t === 'put') { bF.classList.toggle('primary', sel.o === 'F'); bB.classList.toggle('primary', sel.o === 'B'); row.append(bF, bB); }
        bFire.textContent = (sel.t === 'put' ? '놓고 쏘기' : '돌리고 쏘기') + (g > 0 ? ' +' + g : '');
        bFire.disabled = pending;
        row.append(bCancel, bFire);
      } else if (mine) {
        infoTxt.textContent = '빈 칸에 거울 놓기 · 거울 눌러 돌리기';
        const g = ghost && ghost.gain ? ghost.gain : 0;
        bShoot.textContent = '그냥 쏘기 ' + (g > 0 ? '+' + g : '(보석 없음)');
        bShoot.classList.toggle('primary', g > 0);
        bShoot.disabled = pending;
        row.append(bShoot);
      }
      else {
        const l = st.last;
        infoTxt.textContent = l ? api.players[l.s].name + (l.k === 's' ? ' 그냥 쏘기' : '') + (l.pts ? ' +' + l.pts + '점 (보석 ' + l.got.length / 2 + '개)' : ' — 보석 없음') : api.players[a].name + ' 차례';
      }
      renderTop();
    }

    return {
      update(next, prev) {
        const prevSt = st;
        st = next;
        pending = false; clearTimeout(pendT);
        const stageChanged = !prevSt || prevSt.md !== next.md || prevSt.k !== next.k || prevSt.g !== next.g || prevSt.R !== next.R;
        layout();
        const key = next.g + ':' + (next.last ? next.last.id : 0);
        if (next.md === 'p') {
          sel = null; preview = null; anim = null;
          if (stageChanged) hint = null;
          if (key !== shown || !pz) { shown = key; setPuzzleBeam(stageChanged); }
          if (!autoJumped) {
            autoJumped = true;
            if (!api.online && next.seq === 0 && next.k === 0 && api.canAct(0) && U.store) {
              const clr = U.store.get('laser.clr', 0) | 0;
              let k = 0; while (k < STAGES.length - 1 && (clr & (1 << k))) k++;
              if (k > 0) setTimeout(() => { if (st && st.md === 'p' && st.seq === 0 && canPlay()) { act({ t: 'go', k }); api.toast((k + 1) + '단계부터 이어서 해요'); } }, 60);
            }
          }
          refresh();
          return;
        }
        pz = null;
        if (stageChanged) { finishShot(true); for (let i = 0; i < next.n; i++) disp[i] = next.sc[i]; }
        if (next.last && key !== shown && prev && prevSt && !stageChanged) {
          shown = key; sel = null; preview = null; ghost = null;
          startShot(next.last);
        } else {
          shown = key;
          if (!anim) { for (let i = 0; i < next.n; i++) disp[i] = next.sc[i]; computeGhost(); }
          if (sel) {
            const ch = next.b[sel.c], a = actor(next);
            if (a == null || !api.canAct(a) || (sel.t === 'put' ? ch !== '.' : !isMirror(ch))) { sel = null; preview = null; } else computePreview();
          }
        }
        refresh();
      },
      destroy() {
        stopLoop(); clearTimeout(watchdog); clearTimeout(pendT);
        if (anim || (pz && pz.T < pz.len)) api.setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointerup', onUp);
        cv.destroy(); top.remove(); hud.remove(); boardMark.remove(); meMark.remove();
      },
    };
  }

  L.register({
    id: 'laser', name: '레이저 거울 미로', tag: '빛 반사', cat: '보드',
    blurb: '차례마다 거울 하나를 놓거나 돌린 뒤(그냥 쏴도 돼요) 내 레이저를 쏴요. 빛이 지나간 보석은 모두 내 것! 혼자면 12단계 거울 퍼즐이에요.',
    tint: '#3d1a6b',
    icon: '<rect x="5" y="5" width="46" height="46" rx="7" fill="none" stroke="currentColor" stroke-width="2.5" opacity=".45"/><path d="M3 40H31V15" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M25 46L37 34" stroke="currentColor" stroke-width="5.5" stroke-linecap="round"/><path d="M31 5l7 7-7 8-7-8z" fill="currentColor"/><circle cx="44" cy="44" r="3" fill="currentColor" opacity=".6"/><path d="M44 22v6M41 25h6" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".7"/>',
    quick: [
      '거울로 내 레이저 빛을 꺾어 보석을 모아요. 점수가 가장 많으면 이겨요.',
      '내 차례: 빈 칸에 거울 놓기 · 거울 하나 돌리기 · 그냥 쏘기 중 하나 → 내 레이저가 자동 발사!',
      '빛이 지나간 보석은 모두 내 것(초록 1 · 파랑 2 · 다이아 3점). 혼자 하면 12단계 퍼즐이에요.',
    ],
    rules: [
      { h: '목표', p: [
        '판 가장자리에 사람마다 자기 색 레이저가 하나씩 있어요.',
        '거울로 내 레이저 빛을 꺾어 보석을 지나가게 하면, 그 보석은 내 점수가 돼요.',
        '게임이 끝났을 때 점수가 가장 높은 사람이 이겨요. 같으면 함께 이겨요.'] },
      { h: '준비', p: [
        '맵(설정, 기본 무작위)과 라운드 수(6 · 8 · 10, 기본 8)를 골라요.',
        '맵은 같은 모양을 네 번 돌려 붙인 모양이라 어느 자리든 공평해요.'] },
      { h: '차례에 할 일', p: [
        '셋 중 하나만 해요.',
        '① 빈 칸에 거울(／ 또는 ＼) 하나 놓기.',
        '② 판 위의 거울 하나 돌리기(／ ↔ ＼). 누가 놓은 거울이든 돌릴 수 있어요.',
        '③ 아무것도 바꾸지 않고 「그냥 쏘기」.',
        '그다음 내 레이저가 자동으로 발사돼요. 빛이 지나간 보석은 모두 내 것이 되고 판에서 사라져요.'] },
      { h: '빛의 길', p: [
        '빛은 레이저 화살표 방향으로 곧게 나가요.',
        '거울을 만나면 90° 꺾여요. 거울은 양면이라 어느 쪽에서 와도 꺾여요.',
        '빛은 보석을 지나 계속 나아가요. 한 번에 여러 개를 가져갈 수도 있어요.',
        '판 밖으로 나가거나 벽에 닿으면 빛이 끝나요.'] },
      { h: '점수·승리', p: [
        '초록 보석 1점 · 파랑 보석 2점 · 다이아 3점. 보석 아래 금색 점 개수가 점수예요.',
        '보석이 모두 없어지거나, 정한 라운드(모두 한 번씩 = 1라운드)가 끝나면 게임 끝.'] },
      { h: '특수 규칙', p: [
        '레이저 바로 앞 칸(화살표 칸)에는 거울을 놓을 수 없어요.',
        '벽(돌 블록): 빛이 멈춰요.',
        '반투명 거울(하늘색 유리): 빛이 그대로 지나가면서 동시에 꺾여, 두 갈래가 돼요.',
        '꺾기 돌(무지개 세모): 빛이 언제나 오른쪽으로 90° 꺾여요.',
        '순간이동 문(소용돌이): 짝 문으로 나와서 같은 방향으로 계속 가요.'] },
      { h: '혼자 하기 (퍼즐)', p: [
        '1명이면 12단계 퍼즐이에요. 정해진 개수의 거울로 하늘색 수정을 모두 동시에 비추면 성공!',
        '빨간 금지 수정에는 빛이 닿으면 안 돼요. 볼트 박힌 회색 거울은 고정이라 못 바꿔요.',
        '빈 칸을 누르면 ／, 한 번 더 누르면 ＼, 또 누르면 빠져요. 빛길이 바로바로 보여요.',
        '막히면 「힌트」, 다시 하려면 「처음부터」. 위 ◀ ▶로 다른 단계를 고를 수 있고, 깬 단계는 기억해 둬요.'] },
      { h: '조작', p: [
        '빈 칸을 누르면 거울이 놓일 모습과 빛길, 얻을 점수(+N)가 미리 보여요. 아직 쏜 게 아니에요.',
        '같은 칸을 한 번 더 누르거나 ／ ＼ 버튼으로 방향을 바꾸고, 「놓고 쏘기」로 확정해요. 「취소」로 물러요.',
        '거울을 누르면 돌렸을 때 모습이 보이고, 「돌리고 쏘기」로 확정해요.',
        '내 차례에는 지금 내 빛길이 점선으로 보여요. 「그냥 쏘기 +N」을 누르면 판을 바꾸지 않고 바로 쏴요.'] },
      { h: '예시', p: [
        '내 레이저가 오른쪽으로 쏘는데, 빛길 위쪽 두 칸에 파랑 보석(2점)이 있어요.',
        '빛길 위 빈 칸에 거울 ／를 놓으면 빛이 위로 꺾여 파랑 보석을 지나가요 → +2점!',
        '그 거울은 판에 남아요. 다음 사람이 그 거울을 ＼로 돌려 자기 빛길로 쓸 수도 있으니 조심!'] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움: 가끔 엉뚱한 곳에 거울을 놓아요. 보통: 지금 가장 많이 얻는 수를 골라요. 어려움: 다음 사람이 얻을 점수까지 계산해서 길을 열어 주지 않아요.'] },
    ],
    tutorial: [
      { sel: '.lz-board', text: '거울 미로 판이에요. 내 레이저 빛이 지나간 보석은 내 점수가 돼요(초록 1 · 파랑 2 · 다이아 3점). 혼자 하면 하늘색 수정을 모두 비추는 퍼즐이에요.' },
      { sel: '.lz-me', text: '이게 내 레이저예요(내 색). 빛은 화살표 방향으로 곧게 나가다가 거울을 만나면 90° 꺾여요. 바로 앞 칸에는 거울을 못 놓아요.' },
      { sel: '.lz-board', text: '내 차례엔 하나만: 빈 칸에 거울 놓기 · 판의 거울 하나 돌리기(누구 거울이든) · 그냥 쏘기. 그다음 레이저가 자동으로 나가요. (퍼즐은 정해진 거울 수 안에서 마음껏 놓고 빼요.)' },
      { sel: '.lz-board', text: '빈 칸을 톡 하면 거울이 놓일 모습과 빛길, 얻을 점수(+N)가 미리 보여요. 한 번 더 톡 하면 방향(／ ＼)이 바뀌어요. 아직 쏜 건 아니에요!' },
      { sel: '.lz-panel', text: '여기서 「놓고 쏘기」로 확정하거나 「취소」해요. 판을 안 바꾸고 「그냥 쏘기 +N」도 돼요. (혼자 할 땐 「힌트」 「처음부터」가 있어요.)' },
      { sel: '.lz-board', text: '특별한 칸: 벽은 빛을 막고, 반투명 거울은 빛을 두 갈래로, 꺾기 돌은 오른쪽으로 꺾고, 순간이동 문은 짝 문으로 보내요.' },
      { sel: '.lz-top', text: '위쪽에 점수가 보여요(퍼즐은 단계 고르기). 정한 라운드가 끝나거나 보석이 다 없어지면 끝, 점수가 가장 높으면 승리! 그럼 시작해요.' },
    ],
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 750,
    options: [
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.n }))), def: -1 },
      { id: 'rounds', label: '라운드', choices: [{ v: 6, label: '6' }, { v: 8, label: '8' }, { v: 10, label: '10' }], def: 8 },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { trace, solve, MAPS, STAGES, expand, seatEmitters, entry, movesOf, gainOf, bestGain, puzzleSolved, puzzleState },
  });
})();
