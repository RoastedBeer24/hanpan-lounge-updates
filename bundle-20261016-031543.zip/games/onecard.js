/* 원카드 — 52장 + 조커 2장. 같은 무늬/숫자 내기, 공격 카드 누적·방어, J 점프·Q 방향·K 한 번 더·7 무늬 바꾸기,
   원카드 선언(모두 누를 수 있는 배열 actor), 파산. 패는 vwr()만 앞면. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- cards: one char each ---------- */
  const ALPH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01';
  const BJ = 52, CJ = 53; // 흑백 조커, 컬러 조커
  const SUITS = ['♠', '◆', '♥', '♣'], SUIT_NAME = ['스페이드', '다이아', '하트', '클로버'];
  const RK = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const ci = (ch) => ALPH.indexOf(ch);
  const cc = (i) => ALPH[i];
  const suitOf = (i) => (i >= 52 ? -1 : (i / 13) | 0);
  const rankOf = (i) => (i >= 52 ? 0 : (i % 13) + 1);
  const isJoker = (i) => i >= 52;
  function power(i) { // attack strength (0 = not an attack card)
    if (i === CJ) return 7;
    if (i === BJ) return 5;
    const r = rankOf(i);
    if (r === 1) return suitOf(i) === 0 ? 5 : 3;
    if (r === 2) return 2;
    return 0;
  }
  function cardName(i) { return i === BJ ? '흑백 조커' : i === CJ ? '컬러 조커' : SUITS[suitOf(i)] + RK[rankOf(i)]; }

  /* ---------- state ----------
     h: hands (strings), dk: draw pile, dp: discard (last = top), su: suit to follow (−1 = anything, after a joker),
     t: turn, dir: ±1, atk: pending attack total (0 = none), pd: drawn card that may be played (option),
     oc: {s: seat with one card, d: 0} — open one-card window, ac: 1 if this seat acts again (K), out: 0 active / 1 finished / 2 bankrupt,
     rk: finish order, bk: bankrupt order, o: options {hs, lim, mode, dp}, ai: AI flags, last: latest event, seq */
  function shuffleStr(s) { return U.shuffle(s.split('')).join(''); }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const o = { hs: opts.hand === 5 ? 5 : 7, lim: opts.bust === 15 ? 15 : opts.bust === 0 ? 0 : 20, mode: opts.mode === 'rank' ? 1 : 0, dp: opts.drawPlay === 'on' ? 1 : 0 };
    let deck = shuffleStr(ALPH);
    const h = [];
    for (let i = 0; i < n; i++) h.push('');
    for (let k = 0; k < o.hs; k++) for (let i = 0; i < n; i++) { h[i] += deck[0]; deck = deck.slice(1); }
    // starting card: jokers go back into the pile; the first card's effect is not applied
    let top = deck[0]; deck = deck.slice(1);
    while (isJoker(ci(top))) { const at = 1 + U.rand(deck.length - 1); deck = deck.slice(0, at) + top + deck.slice(at); top = deck[0]; deck = deck.slice(1); }
    const t = U.rand(n);
    return {
      n, nm: players.map((p) => p.name), ai: players.map((p) => (p.ai ? 1 : 0)), o,
      h, dk: deck, dp: top, su: suitOf(ci(top)), t, dir: 1, atk: 0, pd: '', oc: null, ac: 0,
      out: players.map(() => 0), rk: [], bk: [], idle: 0, end: 0, seq: 0, last: { id: 0, k: 's', s: t },
    };
  }
  const alive = (s) => { const a = []; for (let i = 0; i < s.n; i++) if (!s.out[i]) a.push(i); return a; };
  function nextSeat(s, from, dir) {
    for (let k = 1; k <= s.n; k++) { const i = (((from + (dir || s.dir) * k) % s.n) + s.n) % s.n; if (!s.out[i]) return i; }
    return from;
  }
  function actor(s) {
    if (s.end) return null;
    if (s.oc) return alive(s);
    return s.t;
  }
  function topCard(s) { return ci(s.dp[s.dp.length - 1]); }
  /* can card i be played now by the turn player? */
  function canPlay(s, i) {
    const top = topCard(s);
    if (s.atk > 0) {
      const p = power(i);
      if (!p || p < power(top)) return false;
      if (isJoker(i)) return true;
      if (isJoker(top)) return false; // a joker attack can only be answered by a (stronger or equal) joker
      return suitOf(i) === s.su || rankOf(i) === rankOf(top);
    }
    if (isJoker(i) || s.su < 0) return true;
    return suitOf(i) === s.su || (!isJoker(top) && rankOf(i) === rankOf(top));
  }
  function playable(s, seat) {
    if (s.pd) return [ci(s.pd)].filter((i) => canPlay(s, i));
    return s.h[seat].split('').map(ci).filter((i) => canPlay(s, i));
  }
  /* draw up to k cards for seat (reshuffling the discard pile under the top card when needed) */
  function drawN(s, seat, k) {
    let got = '', rs = 0;
    for (let j = 0; j < k; j++) {
      if (!s.dk.length && s.dp.length > 1) { s.dk = shuffleStr(s.dp.slice(0, -1)); s.dp = s.dp.slice(-1); rs = 1; }
      if (!s.dk.length) break;
      got += s.dk[0]; s.dk = s.dk.slice(1);
    }
    s.h[seat] += got;
    return { got, rs };
  }
  function checkBust(s, seat) {
    if (!s.o.lim || s.out[seat] || s.h[seat].length < s.o.lim) return false;
    s.out[seat] = 2; s.bk.push(seat);
    s.dk = shuffleStr(s.dk + s.h[seat]); s.h[seat] = '';
    if (s.oc && s.oc.s === seat) s.oc = null;
    return true;
  }
  function checkEnd(s) {
    const a = alive(s);
    if (s.o.mode === 0 && s.rk.length) { s.end = 1; return true; }
    if (a.length <= 1) { if (a.length === 1 && s.o.mode === 1) { s.rk.push(a[0]); s.out[a[0]] = 1; } else if (a.length === 1) s.rk.push(a[0]); s.end = 1; return true; }
    return false;
  }

  function apply(s, seat, a) {
    if (s.end) throw new Error('game over');
    if (!a || typeof a.t !== 'string') throw new Error('bad action');
    const acts = actor(s), list = Array.isArray(acts) ? acts : [acts];
    if (!list.includes(seat)) throw new Error('not your turn');
    if (a.t === 'one') {
      if (!s.oc) throw new Error('no window');
      const own = s.oc.s;
      s.oc = null; s.seq++;
      if (seat === own) s.last = { id: s.seq, k: 'o', s: own };
      else {
        const d = drawN(s, own, 1);
        s.last = { id: s.seq, k: 'c', s: own, by: seat, n: d.got.length, rs: d.rs };
        if (checkBust(s, own)) { s.last.bust = 1; if (s.t === own) s.t = nextSeat(s, own); checkEnd(s); }
      }
      return s;
    }
    if (seat !== s.t) throw new Error('not your turn');
    if (a.t === 'go') { if (!s.oc) throw new Error('no window'); s.oc = null; s.seq++; s.last = { id: s.seq, k: 'g', s: seat }; return s; }
    const wasOc = s.oc;
    if (a.t === 'draw') {
      if (s.pd) throw new Error('decide on the drawn card');
      s.oc = null; s.ac = 0; s.seq++;
      const atk = s.atk;
      const d = drawN(s, seat, atk > 0 ? atk : 1);
      s.last = { id: s.seq, k: 'd', s: seat, n: d.got.length, atk, rs: d.rs };
      if (atk > 0) { s.atk = 0; if (isJoker(topCard(s))) s.su = -1; }
      s.idle = d.got.length ? 0 : s.idle + 1;
      if (checkBust(s, seat)) { s.last.bust = 1; s.t = nextSeat(s, seat); checkEnd(s); return s; }
      if (!atk && s.o.dp && d.got.length && canPlay(s, ci(d.got))) { s.pd = d.got; return s; }
      s.t = nextSeat(s, seat);
      if (s.idle >= alive(s).length * 2) stallEnd(s, 1); // nobody can play and nothing is left to draw
      else if (s.seq >= LIMIT) stallEnd(s, 2);
      return s;
    }
    if (a.t === 'pass') {
      if (!s.pd) throw new Error('nothing to pass');
      s.pd = ''; s.seq++; s.last = { id: s.seq, k: 'k', s: seat };
      s.t = nextSeat(s, seat);
      return s;
    }
    if (a.t !== 'play') throw new Error('bad action');
    const ch = String(a.c || '');
    const i = ci(ch);
    if (i < 0 || ch.length !== 1 || s.h[seat].indexOf(ch) < 0) throw new Error('no such card');
    if (s.pd && ch !== s.pd) throw new Error('only the drawn card');
    if (!canPlay(s, i)) throw new Error('cannot play');
    if (rankOf(i) === 7 && !(a.su >= 0 && a.su <= 3)) throw new Error('choose a suit');
    s.oc = null; s.pd = ''; s.ac = 0; s.idle = 0; s.seq++;
    s.h[seat] = s.h[seat].replace(ch, '');
    s.dp += ch;
    const r = rankOf(i), pw = power(i);
    s.su = isJoker(i) ? -1 : r === 7 ? a.su : suitOf(i);
    if (pw) s.atk += pw;
    s.last = { id: s.seq, k: 'p', s: seat, c: ch, su: r === 7 ? a.su : undefined, atk: s.atk };
    if (wasOc && wasOc.s !== seat) s.last.esc = wasOc.s; // the one-card player got away
    const left = s.h[seat].length;
    if (left === 0) {
      s.out[seat] = 1; s.rk.push(seat); s.last.fin = s.rk.length;
      if (checkEnd(s)) return s;
    }
    let nt;
    if (r === 11) { nt = nextSeat(s, nextSeat(s, seat)); s.last.fx = 'j'; }
    else if (r === 12) { s.dir = -s.dir; nt = nextSeat(s, seat); s.last.fx = 'q'; }
    else if (r === 13 && !s.out[seat]) { nt = seat; s.ac = 1; s.last.fx = 'k'; }
    else nt = nextSeat(s, seat);
    if (r === 11 && nt === seat && s.out[seat]) nt = nextSeat(s, seat);
    s.t = nt;
    if (left === 1) s.oc = { s: seat };
    if (s.seq >= LIMIT) stallEnd(s, 2);
    return s;
  }
  const LIMIT = 900; // actions; only reachable in very long games (e.g. 파산 없음): fewest cards wins
  function stallEnd(s, why) {
    const order = alive(s).sort((x, y) => s.h[x].length - s.h[y].length);
    order.forEach((x) => { s.rk.push(x); s.out[x] = 1; });
    s.end = 1; s.last.stall = why; s.oc = null;
  }
  function result(s) {
    if (!s.end) return null;
    const lines = [];
    s.rk.forEach((x, k) => lines.push((k + 1) + '위 ' + s.nm[x]));
    s.bk.slice().reverse().forEach((x) => lines.push('파산 ' + s.nm[x]));
    if (s.o.mode === 0 && s.rk.length) {
      const w = s.rk[0];
      const rest = alive(s).filter((x) => x !== w).sort((x, y) => s.h[x].length - s.h[y].length).map((x) => s.nm[x] + ' ' + s.h[x].length + '장');
      return { winners: [w], text: (s.last && s.last.stall ? (s.last.stall === 1 ? '더 낼 카드도 뽑을 카드도 없어' : '판이 너무 길어져서(' + LIMIT + '수)') + ' 손패가 가장 적은 사람이 이겼어요.\n' : '가장 먼저 패를 다 털었어요.\n') + (rest.length ? '남은 패: ' + rest.join(', ') : '') + (s.bk.length ? '\n파산: ' + s.bk.map((x) => s.nm[x]).join(', ') : '') };
    }
    return { winners: s.rk.length ? [s.rk[0]] : [], text: lines.join('\n') };
  }

  /* ---------- AI ---------- */
  function suitCounts(hand, skip) {
    const c = [0, 0, 0, 0];
    for (const ch of hand) { if (ch === skip) continue; const su = suitOf(ci(ch)); if (su >= 0) c[su]++; }
    return c;
  }
  function bestSuit(hand, skip) {
    const c = suitCounts(hand, skip);
    let b = 0; for (let k = 1; k < 4; k++) if (c[k] > c[b] || (c[k] === c[b] && Math.random() < 0.5)) b = k;
    return b;
  }
  /* cards not yet seen by seat: not in its hand and not on the discard pile (the draw pile and other hands) */
  function unseenSuits(s, seat) {
    const seen = new Set((s.h[seat] + s.dp).split(''));
    const u = [0, 0, 0, 0];
    for (let i = 0; i < 52; i++) if (!seen.has(cc(i))) u[suitOf(i)]++;
    return u;
  }
  /* 어려움: determinized rollouts — deal the unseen cards to the others at random, play every candidate out a few
     dozen moves with the 보통 policy and keep the card that wins most often (heuristic score as tie-break) */
  function rollout(s0, seat, first, depth) {
    const s = { n: s0.n, nm: s0.nm, ai: s0.ai, o: s0.o, h: s0.h.slice(), dk: s0.dk, dp: s0.dp, su: s0.su, t: s0.t, dir: s0.dir, atk: s0.atk,
      pd: s0.pd, oc: null, ac: s0.ac, out: s0.out.slice(), rk: s0.rk.slice(), bk: s0.bk.slice(), idle: s0.idle, end: 0, seq: 0, last: {} };
    apply(s, seat, first);
    for (let d = 0; d < depth && !s.end; d++) {
      s.oc = null;
      const t = s.t;
      apply(s, t, pick(s, t, 2));
    }
    if (s.end) return s.rk[0] === seat ? 1 : s.out[seat] === 2 ? -0.3 : s.rk.indexOf(seat) >= 0 ? 0.4 : 0;
    // unfinished: compare hand sizes
    let mn = 99; for (let k = 0; k < s.n; k++) if (k !== seat && !s.out[k]) mn = Math.min(mn, s.h[k].length);
    if (s.out[seat]) return s.out[seat] === 1 ? 1 : -0.3;
    return 0.5 + 0.08 * (mn - s.h[seat].length);
  }
  function determinize(s, seat) {
    const mine = new Set((s.h[seat] + s.dp).split(''));
    let pool = ''; for (const ch of ALPH) if (!mine.has(ch)) pool += ch;
    pool = shuffleStr(pool);
    const d = Object.assign({}, s, { h: s.h.slice() });
    for (let k = 0; k < s.n; k++) if (k !== seat) { const m = s.h[k].length; d.h[k] = pool.slice(0, m); pool = pool.slice(m); }
    d.dk = pool;
    return d;
  }
  const AIH = { ms: 220, it: 500 };
  function ai(s, seat, lv) {
    lv = lv || 2;
    // a forgetful 쉬움 owner who is also the turn player (after K, or J with two players) simply goes on playing
    if (s.oc && s.oc.s === seat && seat === s.t && lv === 1 && forgets(s, seat)) { s.oc = null; return pick(s, seat, lv); }
    if (lv !== 3 || s.oc || seat !== s.t) return pick(s, seat, lv);
    const base = pick(s, seat, 3);
    const opts = playable(s, seat);
    const cands = opts.map((i) => playAct(s, seat, i, 3));
    if (!s.atk && !s.pd) cands.push({ t: 'draw' });
    if (s.pd) cands.push({ t: 'pass' });
    if (cands.length <= 1) return base;
    if (cands.some((a) => a.t === 'play' && s.h[seat].length === 1)) return base; // last card: just play it
    const key = (a) => a.t + (a.c || '') + (a.su != null ? a.su : '');
    const sc = cands.map(() => 0), bk = key(base);
    const t0 = Date.now();
    let it = 0;
    while (Date.now() - t0 < AIH.ms && it < AIH.it) {
      const d = determinize(s, seat);
      for (let j = 0; j < cands.length; j++) sc[j] += rollout(d, seat, cands[j], 40);
      it++;
    }
    let bj = -1, bv = -1e9;
    for (let j = 0; j < cands.length; j++) { const v = sc[j] / it + (key(cands[j]) === bk ? 0.02 : 0); if (v > bv) { bv = v; bj = j; } }
    return cands[bj];
  }
  function pick(s, seat, lv) {
    if (s.oc) return { t: 'one' }; // own declaration, or catching someone (the timing lives in aiDelayFor)
    if (seat !== s.t) return null;
    const hand = s.h[seat];
    const opts = playable(s, seat);
    if (s.pd) return opts.length ? playAct(s, seat, opts[0], lv) : { t: 'pass' };
    if (!opts.length) return { t: 'draw' };
    if (lv === 1) { // beginner: the first card in hand that fits
      return playAct(s, seat, opts[0], lv);
    }
    const nx = nextSeat(s, seat), nxc = s.h[nx].length;
    let minOpp = 99; for (let k = 0; k < s.n; k++) if (k !== seat && !s.out[k]) minOpp = Math.min(minOpp, s.h[k].length);
    if (s.atk > 0) {
      // defend with the weakest card that works; jokers last
      opts.sort((x, y) => (isJoker(x) - isJoker(y)) || power(x) - power(y));
      return playAct(s, seat, opts[0], lv);
    }
    const uns = lv === 3 ? unseenSuits(s, seat) : null;
    let best = null, bv = -1e9;
    for (const i of opts) {
      const r = rankOf(i), ch = cc(i), rest = hand.replace(ch, '');
      let v = 10 + Math.random() * (lv === 3 ? 0.5 : 2);
      const sc = suitCounts(rest);
      if (lv === 3) {
        // 어려움: hoard attack/defence cards and jokers until they matter, lead suits the others are short of, plan the finish
        const danger = nxc <= 2 || minOpp <= 1;
        if (isJoker(i)) v += rest.length <= 1 || danger ? 22 : -55;
        else {
          const su = suitOf(i);
          v += 2.5 * sc[su] - 0.35 * uns[su];
          const pw = power(i);
          if (pw) v += danger ? 22 : nxc <= 3 ? 8 : rest.length <= 2 ? 6 : -9 - pw;
          if (r === 7) {
            const cur = s.su >= 0 ? sc[s.su] : 0, mx = Math.max(...sc);
            const nonSeven = opts.filter((x) => rankOf(x) !== 7 && !power(x) && !isJoker(x)).length;
            v += nonSeven ? -22 + 5 * (mx - cur) : -4 + 3 * (mx - cur); // a 7 is a lifeline: use it when stuck
          }
          if (r === 13) {
            const s2 = Object.assign({}, s, { h: s.h.slice(), su: su, dp: s.dp + ch }); s2.h[seat] = rest;
            const nxt = rest.length ? playable(s2, seat) : [];
            v += nxt.length ? (rest.length === 1 ? 600 : 10) : -8; // K + last card = finish this turn
          }
          if (r === 11) v += danger ? 16 : nxc <= 3 ? 9 : 2;
          if (r === 12) v += danger ? 9 : 1;
          if (rest.length === 1) { const last = ci(rest); if (isJoker(last)) v += 12; else if (suitOf(last) === su || rankOf(last) === r) v += 10; }
        }
      } else if (isJoker(i)) v += hand.length <= 2 || nxc <= 2 ? 18 : -45;
      else {
        v += 2 * sc[suitOf(i)];
        const pw = power(i);
        if (pw) v += (nxc <= 3 ? 16 : 5) - (pw === 5 ? 8 : 0);
        if (r === 7) {
          const cur = s.su >= 0 ? sc[s.su] : 0, mx = Math.max(...sc);
          v += -14 + 5 * (mx - cur);
        }
        if (r === 13) { const s2 = Object.assign({}, s, { h: s.h.slice(), su: suitOf(i), dp: s.dp + ch }); s2.h[seat] = rest; v += rest.length && playable(s2, seat).length ? 9 : -6; }
        if (r === 11) v += nxc <= 3 ? 12 : 3;
        if (r === 12) v += nxc <= 3 ? 7 : 1;
      }
      if (rest.length === 0) v += 1000;
      if (v > bv) { bv = v; best = i; }
    }
    return playAct(s, seat, best, lv);
  }
  function playAct(s, seat, i, lv) {
    const a = { t: 'play', c: cc(i) };
    if (rankOf(i) === 7) {
      if (lv === 1) a.su = Math.random() < 0.5 ? U.rand(4) : bestSuit(s.h[seat], cc(i));
      else if (lv === 3) { // most cards in hand; tie → the suit the others hold least of
        const c = suitCounts(s.h[seat], cc(i)), u = unseenSuits(s, seat);
        let b = 0; for (let k = 1; k < 4; k++) if (c[k] * 10 - u[k] > c[b] * 10 - u[b]) b = k;
        a.su = b;
      } else a.su = bestSuit(s.h[seat], cc(i));
    }
    return a;
  }
  // hash so one window gets one decision (the core may re-ask after unrelated re-renders)
  const forgets = (s, seat) => ((s.seq * 7919 + seat * 104729) % 100) < 35;
  function aiDelayFor(s, seat, lv) {
    lv = lv || 2;
    const r = Math.random();
    if (s.oc) {
      const own = s.oc.s, ownAI = !!s.ai[own];
      if (seat === own) { // say "원카드!"
        if (lv === 1) return forgets(s, seat) ? (seat === s.t ? 2600 + r * 800 : -1) : 900 + r * 900;
        return lv === 3 ? 300 + r * 250 : 380 + r * 420;
      }
      // catching: people always get a fair chance; AIs that remember are never sniped except by a sharp 어려움
      if (lv === 1) return 2300 + r * 1500;
      if (lv === 3) return ownAI ? 1000 + r * 400 : 800 + r * 500;
      if (!ownAI) return 1100 + r * 1200;
      return 1700 + r * 600;
    }
    if (seat !== s.t) return -1;
    const k = lv === 1 ? 1.3 : lv === 3 ? 0.85 : 1;
    if (s.pd) return 450 * k;
    return (s.ac ? 520 : 760) * k;
  }

  /* ---------- drawing ---------- */
  const RED = '#b8322a', INK = '#1d1a22';
  const SU_CH = ['S', 'D', 'H', 'C'];
  function suitPath(ctx, su, x, y, sz) {
    const k = sz / 2;
    ctx.beginPath();
    if (su === 'H') {
      ctx.moveTo(x, y + k * 0.92);
      ctx.bezierCurveTo(x - k * 1.15, y + k * 0.05, x - k * 0.95, y - k * 1.0, x, y - k * 0.42);
      ctx.bezierCurveTo(x + k * 0.95, y - k * 1.0, x + k * 1.15, y + k * 0.05, x, y + k * 0.92);
    } else if (su === 'D') {
      ctx.moveTo(x, y - k); ctx.lineTo(x + k * 0.74, y); ctx.lineTo(x, y + k); ctx.lineTo(x - k * 0.74, y); ctx.closePath();
    } else if (su === 'S') {
      ctx.moveTo(x, y - k * 0.98);
      ctx.bezierCurveTo(x + k * 1.2, y - k * 0.05, x + k * 0.95, y + k * 0.82, x + k * 0.05, y + k * 0.36);
      ctx.lineTo(x + k * 0.32, y + k); ctx.lineTo(x - k * 0.32, y + k); ctx.lineTo(x - k * 0.05, y + k * 0.36);
      ctx.bezierCurveTo(x - k * 0.95, y + k * 0.82, x - k * 1.2, y - k * 0.05, x, y - k * 0.98);
    } else {
      const r = k * 0.4;
      for (const [cx, cy] of [[x, y - k * 0.48], [x - k * 0.48, y + k * 0.12], [x + k * 0.48, y + k * 0.12]]) { ctx.moveTo(cx + r, cy); ctx.arc(cx, cy, r, 0, Math.PI * 2); }
      ctx.moveTo(x - k * 0.1, y); ctx.lineTo(x + k * 0.1, y); ctx.lineTo(x + k * 0.3, y + k); ctx.lineTo(x - k * 0.3, y + k); ctx.closePath();
    }
    ctx.fill();
  }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace', DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  function drawJoker(ctx, x, y, w, color) {
    const h = w * 1.4;
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, '#fffaf0'); g.addColorStop(1, '#efe5cf');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, w * 0.1); ctx.fill();
    ctx.strokeStyle = 'rgba(80,60,30,.35)'; ctx.lineWidth = 1; ctx.stroke();
    const cx = x + w / 2, cy = y + h * 0.5;
    // jester hat: three bells
    const cols = color ? ['#c0392b', '#2f6fb5', '#d9a21b'] : ['#1d1a22', '#6b6670', '#1d1a22'];
    ctx.save();
    for (let k = -1; k <= 1; k++) {
      ctx.fillStyle = cols[k + 1];
      ctx.beginPath(); ctx.moveTo(cx - w * 0.22, cy + h * 0.08); ctx.quadraticCurveTo(cx + k * w * 0.18, cy - h * 0.06, cx + k * w * 0.32, cy - h * 0.2 + Math.abs(k) * h * 0.04);
      ctx.quadraticCurveTo(cx + k * w * 0.06, cy - h * 0.02, cx + w * 0.22, cy + h * 0.08); ctx.closePath(); ctx.fill();
      ctx.fillStyle = color ? '#e3ae45' : '#9a9aa0';
      ctx.beginPath(); ctx.arc(cx + k * w * 0.32, cy - h * 0.2 + Math.abs(k) * h * 0.04, w * 0.05, 0, 7); ctx.fill();
    }
    ctx.fillStyle = color ? '#2b8a5a' : '#3a3540'; rr(ctx, cx - w * 0.24, cy + h * 0.06, w * 0.48, h * 0.06, 2); ctx.fill();
    ctx.fillStyle = color ? '#f0d9b5' : '#d8d2c4'; ctx.beginPath(); ctx.arc(cx, cy + h * 0.19, w * 0.14, 0, 7); ctx.fill();
    ctx.restore();
    ctx.fillStyle = color ? RED : INK;
    ctx.font = '700 ' + Math.round(w * 0.16) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    const word = 'JOKER';
    for (let k = 0; k < 5; k++) { ctx.fillText(word[k], x + w * 0.13, y + w * 0.2 + k * w * 0.16); }
    ctx.save(); ctx.translate(x + w, y + h); ctx.rotate(Math.PI);
    for (let k = 0; k < 5; k++) { ctx.fillText(word[k], w * 0.13, w * 0.2 + k * w * 0.16); }
    ctx.restore();
  }
  function drawCardFace(ctx, x, y, w, i) {
    if (isJoker(i)) return drawJoker(ctx, x, y, w, i === CJ);
    const h = w * 1.4, su = SU_CH[suitOf(i)], rk = RK[rankOf(i)];
    const col = su === 'H' || su === 'D' ? RED : INK;
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, '#fffaf0'); g.addColorStop(1, '#efe5cf');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, w * 0.1); ctx.fill();
    ctx.strokeStyle = 'rgba(80,60,30,.35)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = col; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    const fs = Math.round(w * 0.3);
    ctx.font = '700 ' + fs + 'px ' + FONT;
    const corner = (cx, cy) => {
      if (rk === '10') { ctx.save(); ctx.translate(cx, cy); ctx.scale(0.74, 1); ctx.fillText(rk, 0, 0); ctx.restore(); } else ctx.fillText(rk, cx, cy);
    };
    corner(x + w * 0.17, y + fs * 0.98);
    suitPath(ctx, su, x + w * 0.17, y + fs * 1.42, w * 0.18);
    ctx.save(); ctx.translate(x + w, y + h); ctx.rotate(Math.PI);
    corner(w * 0.17, fs * 0.98); suitPath(ctx, su, w * 0.17, fs * 1.42, w * 0.18);
    ctx.restore();
    const mx = x + w * 0.58, my = y + h * 0.55;
    if ('JQK'.indexOf(rk) >= 0) {
      const fw = w * 0.5, fh = h * 0.56;
      ctx.fillStyle = col === RED ? 'rgba(184,50,42,.1)' : 'rgba(40,30,60,.1)';
      rr(ctx, mx - fw / 2, my - fh / 2, fw, fh, 3); ctx.fill();
      ctx.strokeStyle = '#c99a3a'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = col; ctx.font = Math.round(w * 0.36) + 'px ' + DISP; ctx.textBaseline = 'middle';
      ctx.fillText(rk, mx, my - fh * 0.12);
      suitPath(ctx, su, mx, my + fh * 0.27, w * 0.16);
    } else suitPath(ctx, su, mx, my, w * (rk === 'A' ? (su === 'S' ? 0.66 : 0.56) : 0.46));
    // corner tag for special cards
    const pw = power(i), tag = pw ? '+' + pw : rk === 'J' ? '점프' : rk === 'Q' ? '역방향' : rk === 'K' ? '한번더' : rk === '7' ? '무늬' : '';
    if (tag) {
      ctx.font = '700 ' + Math.max(8, Math.round(w * 0.15)) + 'px ' + FONT;
      const tw = ctx.measureText(tag).width + 6;
      ctx.fillStyle = pw ? 'rgba(184,50,42,.92)' : 'rgba(58,46,80,.88)';
      rr(ctx, x + w - tw - 3, y + 3, tw, w * 0.2, w * 0.1); ctx.fill();
      ctx.fillStyle = '#fff6e6'; ctx.textBaseline = 'middle'; ctx.fillText(tag, x + w - tw / 2 - 3, y + 3 + w * 0.1 + 0.5);
    }
  }
  function drawCardBack(ctx, x, y, w) {
    const h = w * 1.4;
    const g = ctx.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, '#5a2d5f'); g.addColorStop(1, '#3a1b40');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, w * 0.1); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1; ctx.stroke();
    const ins = w * 0.09;
    ctx.save();
    rr(ctx, x + ins, y + ins, w - ins * 2, h - ins * 2, w * 0.05); ctx.clip();
    ctx.strokeStyle = 'rgba(227,174,69,.5)'; ctx.lineWidth = 1;
    const step = Math.max(4, w * 0.16);
    ctx.beginPath();
    for (let d = -h; d < w + h; d += step) { ctx.moveTo(x + d, y); ctx.lineTo(x + d + h, y + h); ctx.moveTo(x + d, y + h); ctx.lineTo(x + d + h, y); }
    ctx.stroke();
    ctx.fillStyle = '#e3ae45';
    ctx.beginPath(); const cx = x + w / 2, cy = y + h / 2, k = w * 0.16;
    ctx.moveTo(cx, cy - k); ctx.lineTo(cx + k * 0.7, cy); ctx.lineTo(cx, cy + k); ctx.lineTo(cx - k * 0.7, cy); ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.2;
    rr(ctx, x + ins, y + ins, w - ins * 2, h - ins * 2, w * 0.05); ctx.stroke();
  }
  function drawCard(ctx, x, y, w, i, up, rot, sx) {
    const h = w * 1.4;
    ctx.save();
    ctx.translate(x + w / 2, y + h / 2);
    if (rot) ctx.rotate(rot);
    if (sx != null) ctx.scale(Math.max(0.02, sx), 1);
    ctx.translate(-w / 2, -h / 2);
    ctx.shadowColor = 'rgba(0,0,0,.38)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 2;
    ctx.fillStyle = '#000'; rr(ctx, 0.5, 0.5, w - 1, h - 1, w * 0.1); ctx.fill();
    ctx.shadowColor = 'transparent';
    if (up && i >= 0) drawCardFace(ctx, 0, 0, w, i); else drawCardBack(ctx, 0, 0, w);
    ctx.restore();
  }
  function noiseTile() {
    const c = document.createElement('canvas'); c.width = c.height = 96;
    const x = c.getContext('2d'), d = x.createImageData(96, 96);
    for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 14; }
    x.putImageData(d, 0, 0); return c;
  }
  const ease = (t) => 1 - Math.pow(1 - t, 3);
  const sortKey = (i) => (isJoker(i) ? 100 + i : suitOf(i) * 16 + (rankOf(i) === 1 ? 14 : rankOf(i)));

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const noise = noiseTile();
    let st = null, G = null, bg = null, dirty = true, busy = false, holdUntil = 0;
    let flies = [], sel = -1, hits = [], lastId = -1, waitSeq = -1, waitUntil = 0, pick7 = false;
    const spd = () => L.debug.speed || 1;
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    const hud = L.h('div', { class: 'hud bottom', style: { padding: '8px 10px 10px', gap: '6px', flexWrap: 'nowrap' } });
    const oneBtn = L.h('button', { class: 'btn danger', style: { position: 'absolute', left: '50%', transform: 'translateX(-50%)', minHeight: '52px', minWidth: '168px', fontFamily: 'var(--f-display)', fontSize: '20px', fontWeight: 400, zIndex: 6, boxShadow: '0 0 0 3px rgba(238,106,85,.35), 0 6px 18px rgba(0,0,0,.45)', display: 'none' }, text: '원카드!', onclick: onOne });
    /* quick help: a compact cheat sheet of the special cards over the table */
    let helpEl = null;
    const helpBtn = L.h('button', { class: 'btn sm', style: { position: 'absolute', left: '12px', top: '12px', zIndex: 5, minHeight: '36px', padding: '4px 10px', fontSize: '12px', fontWeight: 700, background: 'rgba(23,19,31,.82)' }, 'aria-label': '카드 효과 보기', text: '카드 효과', onclick: toggleHelp });
    function toggleHelp() {
      api.sfx('click');
      if (helpEl) { helpEl.remove(); helpEl = null; return; }
      const row = (card, eff, block, red) => L.h('tr', null,
        L.h('td', { style: { width: '84px', fontWeight: 700, whiteSpace: 'nowrap', color: red ? '#ff8a76' : 'var(--ink)', padding: '4px 6px 4px 0' }, text: card }),
        L.h('td', { style: { width: '70px', padding: '4px 6px', color: 'var(--brass)', fontWeight: 700, whiteSpace: 'nowrap' }, text: eff }),
        L.h('td', { style: { padding: '4px 0', color: 'var(--muted)' }, text: block }));
      const tbl = (title, rows) => [L.h('div', { class: 'label', style: { marginTop: '6px' }, text: title }),
        L.h('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: '13px', lineHeight: 1.3 } }, L.h('tbody', null, rows))];
      helpEl = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '12px', background: 'rgba(10,8,15,.55)' }, onclick: toggleHelp },
        L.h('div', { class: 'panel', style: { width: '100%', maxWidth: '380px', maxHeight: '100%', overflowY: 'auto', padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: '2px' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center' } }, L.h('b', { style: { fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '18px' }, text: '카드 효과' }),
            L.h('span', { class: 'muted', style: { marginLeft: 'auto', fontSize: '11px' }, text: '아무 데나 누르면 닫혀요' })),
          tbl('공격 · 막는 카드', [
            row('2', '+2장', '같은 무늬 A · 다른 2 · 조커'),
            row('A', '+3장', '다른 A(♠A 포함) · 조커'),
            row('♠A', '+5장', '조커만'),
            row('흑백 조커', '+5장', '컬러 조커만'),
            row('컬러 조커', '+7장', '못 막아요', true)]),
          L.h('div', { class: 'muted', style: { fontSize: '12px' }, text: '막으면 공격이 쌓여 다음 사람에게 (예: 2+A = +5장). 못 막으면 모두 뽑아요.' }),
          tbl('특수 카드', [
            row('J', '점프', '다음 사람 건너뛰기'),
            row('Q', '방향', '도는 방향 반대로'),
            row('K', '한 번 더', '1장 더 내기'),
            row('7', '무늬', '원하는 무늬로 바꾸기'),
            row('조커', '아무 때나', '다음 사람은 아무 카드나')]),
          L.h('div', { class: 'muted', style: { fontSize: '12px', marginTop: '6px' }, text: '1장 남으면 「원카드!」 · 남이 먼저 누르면 1장 벌칙 · ' + (st && st.o.lim ? st.o.lim + '장이 되면 파산' : '파산 없음') })));
      root.append(helpEl);
    }
    helpBtn.classList.add('oc-help');
    root.append(hud, oneBtn, helpBtn);
    /* invisible boxes over canvas regions — spotlight targets for the first-play tutorial */
    const anc = {};
    function anchor(cls, x, y, w, h) {
      let el = anc[cls];
      if (!el) { el = anc[cls] = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', visibility: 'hidden' } }); root.append(el); }
      Object.assign(el.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' });
    }
    let pulse = 0;

    /* whose hand may be face-up. While a one-card window is open on a shared phone, only the player who just
       played (still holding the phone) may look — never the next player before the curtain. */
    function vwr() {
      const v = api.viewer();
      if (st && st.oc && api.mySeats().length > 1 && v !== st.oc.s) return -1;
      return v;
    }
    function bottomSeat() {
      const v = vwr();
      if (v >= 0) return v;
      const mine = api.mySeats();
      return mine.length ? mine[0] : 0;
    }
    function myTurnSeat() { return st && !st.end && api.canAct(st.t) ? st.t : -1; }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function send(a, seat) {
      if (locked()) return;
      waitSeq = st.seq; waitUntil = performance.now() + (api.online ? 3000 : 400);
      api.actAs(seat != null ? seat : st.t, a); // explicit seat: during a one-card window every seat is an actor
      sel = -1; pick7 = false;
    }
    /* who presses the one-card button on this device */
    function oneSeat() {
      if (!st || !st.oc || st.end) return -1;
      const own = st.oc.s;
      if (api.canAct(own)) return own;
      const mine = api.mySeats().filter((x) => !st.out[x] && x !== own);
      if (!mine.length) return -1;
      return mine.includes(st.t) ? st.t : mine[0];
    }
    function onOne() {
      const seat = oneSeat();
      if (seat < 0 || locked()) return;
      api.buzz(25); api.sfx('pop');
      waitSeq = st.seq; waitUntil = performance.now() + 3000;
      api.actAs(seat, { t: 'one' });
    }

    function geometry() {
      const W = cv.w, H = cv.h;
      const tight = H < 660;
      const hudH = tight ? 62 : 70;
      const cw = Math.round(U.clamp(W * (tight ? 0.135 : 0.15), 46, 66));
      const n = st ? st.h[bottomSeat()].length : 7;
      const rows = handRows(n, W, cw);
      const handH = cw * 1.4 + (rows - 1) * cw * 0.62 + 16;
      const handY = H - hudH - handH;
      const plateY = handY - 26;
      const top = 6;
      const pw = Math.round(U.clamp(W * 0.17, 60, 76));
      const cy = Math.round(top + 74 + (plateY - 28 - top - 74) * 0.55);
      G = { W, H, tight, hudH, cw, rows, handH, handY, plateY, top, pw, cx: W / 2, cy, oppW: Math.min(84, (W - 16) / 5 - 4) };
      oneBtn.style.top = Math.max(8, plateY - 28 - 32 - 6) + 'px';
      const ph = pw * 1.4, px0 = W / 2 - pw * 0.62 - pw / 2;
      anchor('oc-piles', px0 - 8, cy - pw * 0.7 - 8, pw * 1.24 + pw + 16, ph + 16);
      anchor('oc-hand', 6, plateY - 16, W - 12, H - hudH - plateY + 14);
      anchor('oc-opp', 6, top + 2, W - 12, Math.max(40, cy - pw * 0.7 - 12 - top));
      anchor('oc-bar', 4, H - hudH + 2, W - 8, hudH - 4);
    }
    function buildBg() {
      const W = cv.w, H = cv.h, dpr = cv.dpr;
      const c = document.createElement('canvas'); c.width = Math.ceil(W * dpr); c.height = Math.ceil(H * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr);
      // wood rail + deep felt table
      const pad = 6;
      const wg = x.createLinearGradient(0, 0, W, H); wg.addColorStop(0, '#5a3720'); wg.addColorStop(1, '#3b2213');
      x.fillStyle = wg; rr(x, pad, pad, W - pad * 2, H - pad * 2 - G.hudH + 4, 26); x.fill();
      const fg = x.createRadialGradient(W / 2, G.cy, 20, W / 2, G.cy, Math.max(W, H) * 0.7);
      fg.addColorStop(0, '#22604f'); fg.addColorStop(0.6, '#174a3d'); fg.addColorStop(1, '#0f3328');
      x.fillStyle = fg; rr(x, pad + 9, pad + 9, W - pad * 2 - 18, H - pad * 2 - G.hudH - 14, 18); x.fill();
      x.save(); rr(x, pad + 9, pad + 9, W - pad * 2 - 18, H - pad * 2 - G.hudH - 14, 18); x.clip();
      x.fillStyle = x.createPattern(noise, 'repeat'); x.fillRect(0, 0, W, H);
      x.restore();
      x.strokeStyle = 'rgba(227,174,69,.45)'; x.lineWidth = 1.2; rr(x, pad + 9, pad + 9, W - pad * 2 - 18, H - pad * 2 - G.hudH - 14, 18); x.stroke();
      // center ring
      x.strokeStyle = 'rgba(242,233,216,.08)'; x.lineWidth = 2;
      x.beginPath(); x.ellipse(W / 2, G.cy, G.pw * 1.75, G.pw * 1.25, 0, 0, 7); x.stroke();
      bg = c;
    }
    cv.onresize = () => { geometry(); buildBg(); dirty = true; };

    /* seat placement: bottom seat at the bottom, the others clockwise along the upper arc */
    function seatPos(seat) {
      const b = bottomSeat();
      if (seat === b) return { x: G.cx, y: G.plateY, me: true };
      const k = st.n - 1, idx = ((seat - b + st.n) % st.n) - 1; // 0 = next clockwise (left)
      const th = Math.PI + Math.PI * (idx + 1) / (k + 1);
      const rx = G.W / 2 - G.oppW / 2 - 10, ry = G.cy - G.top - 40;
      return { x: G.cx + Math.cos(th) * rx, y: G.cy + Math.sin(th) * ry + (k >= 4 ? 18 : 10) };
    }
    const deckPos = () => ({ x: G.cx - G.pw * 0.62 - G.pw / 2, y: G.cy - G.pw * 0.7 });
    const pilePos = () => ({ x: G.cx + G.pw * 0.62 - G.pw / 2, y: G.cy - G.pw * 0.7 });

    // more rows when a single row would make each card's tappable strip narrower than ~36px
    function handRows(n, W, cw) {
      let rows = 1;
      while (rows < 3 && Math.ceil(n / rows) > 1 && (W - 24 - cw) / (Math.ceil(n / rows) - 1) < 36) rows++;
      return rows;
    }
    function handLayout(seat) {
      const cards = st.h[seat].split('').map(ci).sort((a, b) => sortKey(a) - sortKey(b));
      const n = cards.length, cw = G.cw, out = [];
      if (!n) return out;
      const rows = handRows(n, G.W, cw), per = Math.ceil(n / rows);
      for (let r = 0; r < rows; r++) {
        const row = cards.slice(r * per, (r + 1) * per), m = row.length;
        const avail = G.W - 24 - cw;
        const step = m > 1 ? Math.min(cw * 0.78, avail / (m - 1)) : 0;
        const tot = step * (m - 1) + cw;
        const x0 = (G.W - tot) / 2;
        const y = G.handY + 10 + r * cw * 0.62;
        row.forEach((i, k) => {
          const mid = (m - 1) / 2, off = (k - mid) / Math.max(1, m);
          out.push({ i, x: x0 + k * step, y: y + Math.abs(off) * 10, rot: off * 0.18, w: cw, step, last: k === m - 1, row: r });
        });
      }
      return out;
    }

    function draw(now) {
      cv.clear();
      if (!G) return;
      if (bg) ctx.drawImage(bg, 0, 0, G.W, G.H);
      if (!st) return;
      hits = [];
      const flying = new Set(flies.filter((f) => now < f.t0 + f.dur).map((f) => f.key));
      // direction arrows around the center
      drawDirection(now);
      // draw pile
      const dpk = deckPos();
      const dn = st.dk.length;
      for (let k = Math.min(4, Math.ceil(dn / 8)) - 1; k >= 0; k--) drawCard(ctx, dpk.x - k * 1.2, dpk.y - k * 1.5, G.pw, -1, false);
      if (!dn) { ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.setLineDash([4, 4]); rr(ctx, dpk.x, dpk.y, G.pw, G.pw * 1.4, G.pw * 0.1); ctx.stroke(); ctx.setLineDash([]); }
      tag(dpk.x + G.pw / 2, dpk.y + G.pw * 1.4 + 12, String(dn) + '장', 'rgba(15,12,20,.78)', '#f2e9d8', MONO);
      // discard pile: top three
      const pp = pilePos();
      const dp = st.dp;
      const hideTop = flying.has('play' + st.last.id);
      for (let k = Math.min(3, dp.length); k >= 1; k--) {
        if (k === 1 && hideTop) continue;
        const i = ci(dp[dp.length - k]);
        const jit = ((dp.length - k) * 37 % 11 - 5) * 0.03;
        drawCard(ctx, pp.x + (k - 1) * 2, pp.y + (k - 1) * 1, G.pw, i, true, k === 1 ? jit * 0.6 : jit);
      }
      // current suit / attack badges
      const top = topCard(st);
      if (st.atk > 0) {
        const pul = 1 + Math.sin(now / 160) * 0.05;
        ctx.save(); ctx.translate(pp.x + G.pw / 2, pp.y - 16); ctx.scale(pul, pul);
        tag(0, 0, '공격 +' + st.atk, '#ee6a55', '#2b0c06', '700 14px ' + FONT);
        ctx.restore();
      }
      const suitTxt = st.su < 0 ? '아무 카드' : (isJoker(top) || st.su !== suitOf(top)) ? SUITS[st.su] + ' ' + SUIT_NAME[st.su] : '';
      if (suitTxt) {
        const red = st.su === 1 || st.su === 2;
        tag(pp.x + G.pw / 2, pp.y + G.pw * 1.4 + 12, (st.su < 0 ? '' : '무늬 ') + suitTxt, '#e3ae45', red ? '#7a1a12' : '#2a1d05', '700 12px ' + FONT);
      }
      // seats
      for (let s = 0; s < st.n; s++) drawSeat(s, now, flying);
      // my hand
      drawHand(now, flying);
      // flying cards on top
      for (const f of flies) {
        let p = (now - f.t0) / f.dur;
        if (p < 0 || p > 1) continue;
        const e = ease(p);
        const x = U.lerp(f.x0, f.x1, e), y = U.lerp(f.y0, f.y1, e) - Math.sin(p * Math.PI) * 18, w = U.lerp(f.w0, f.w1, e);
        drawCard(ctx, x, y, w, f.i, f.up, (1 - e) * (f.rot || 0));
      }
      // hint
      const hn = hintText();
      if (hn) {
        ctx.font = '600 12.5px ' + FONT;
        const t = clip(hn, G.W - 40);
        const y = G.plateY - 28;
        tag(G.cx, y, t, 'rgba(16,12,22,.72)', '#d9cfe4', '600 12.5px ' + FONT);
      }
    }
    function clip(t, w) {
      if (ctx.measureText(t).width <= w) return t;
      while (t.length > 1 && ctx.measureText(t + '…').width > w) t = t.slice(0, -1);
      return t + '…';
    }
    function tag(x, y, text, bgc, fg, font) {
      ctx.font = font || '600 12px ' + FONT;
      const tw = ctx.measureText(text).width + 14, h = 20;
      ctx.fillStyle = bgc; rr(ctx, x - tw / 2, y - h / 2, tw, h, h / 2); ctx.fill();
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, x, y + 1);
      return tw;
    }
    function drawDirection(now) {
      const rx = G.pw * 1.75, ry = G.pw * 1.25, cx = G.cx, cy = G.cy;
      ctx.save();
      ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.fillStyle = 'rgba(227,174,69,.75)'; ctx.lineWidth = 2;
      const dir = st.dir; // +1 = clockwise on screen
      const spin = (now / 4000) * dir;
      for (let k = 0; k < 4; k++) {
        const a0 = spin + k * Math.PI / 2 + 0.25, a1 = a0 + 0.75;
        ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, a0, a1); ctx.stroke();
        const ae = dir > 0 ? a1 : a0;
        const px = cx + Math.cos(ae) * rx, py = cy + Math.sin(ae) * ry;
        const tx = -Math.sin(ae) * rx * dir, ty = Math.cos(ae) * ry * dir, tl = Math.hypot(tx, ty);
        const ux = tx / tl, uy = ty / tl;
        ctx.beginPath(); ctx.moveTo(px + ux * 7, py + uy * 7); ctx.lineTo(px - uy * 5, py + ux * 5); ctx.lineTo(px + uy * 5, py - ux * 5); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }
    function drawSeat(s, now, flying) {
      const p = seatPos(s), pl = api.players[s] || { name: st.nm[s], color: '#888' };
      const turn = !st.end && st.t === s;
      const cnt = st.h[s].length;
      const badge = st.out[s] === 2 ? ['파산', '#ee6a55', '#2b0c06'] : st.out[s] === 1 ? [(st.rk.indexOf(s) + 1) + '위', '#e3ae45', '#2a1d05'] : st.oc && st.oc.s === s ? ['원카드?', '#ee6a55', '#2b0c06'] : cnt === 1 ? ['원카드', '#e3ae45', '#2a1d05'] : null;
      if (p.me) {
        // compact plate above my hand
        ctx.font = '700 13px ' + FONT;
        const name = clip(pl.name, 120), nw = ctx.measureText(name).width;
        ctx.font = '600 13px ' + MONO;
        const cnt2 = cnt + '장', cw2 = ctx.measureText(cnt2).width;
        const bw2 = badge ? (ctx.font = '700 11px ' + FONT, ctx.measureText(badge[0]).width + 14 + 6) : 0;
        const tw = 25 + nw + 8 + cw2 + 12 + bw2;
        const x = p.x - tw / 2, y = p.y - 13;
        ctx.fillStyle = turn ? 'rgba(46,38,64,.95)' : 'rgba(22,17,30,.8)'; rr(ctx, x, y, tw, 26, 13); ctx.fill();
        ctx.lineWidth = turn ? 1.6 : 1; ctx.strokeStyle = turn ? '#e3ae45' : 'rgba(242,233,216,.15)'; ctx.stroke();
        ctx.fillStyle = pl.color; ctx.beginPath(); ctx.arc(x + 14, p.y, 5, 0, 7); ctx.fill();
        ctx.font = '700 13px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(name, x + 25, p.y + 0.5);
        ctx.font = '600 13px ' + MONO; ctx.fillStyle = '#e3ae45'; ctx.fillText(cnt2, x + 25 + nw + 8, p.y + 0.5);
        if (badge) tag(x + tw - 6 - (bw2 - 6) / 2, p.y, badge[0], badge[1], badge[2], '700 11px ' + FONT);
        return;
      }
      const w = G.oppW, h = 64, x = p.x - w / 2, y = p.y - h / 2;
      ctx.save();
      if (turn) { ctx.shadowColor = 'rgba(227,174,69,.6)'; ctx.shadowBlur = 14; }
      ctx.fillStyle = turn ? 'rgba(46,38,64,.96)' : 'rgba(22,17,30,.84)'; rr(ctx, x, y, w, h, 12); ctx.fill();
      ctx.restore();
      ctx.lineWidth = turn ? 1.8 : 1; ctx.strokeStyle = turn ? '#e3ae45' : 'rgba(242,233,216,.14)'; rr(ctx, x, y, w, h, 12); ctx.stroke();
      if (st.out[s]) ctx.globalAlpha = 0.55;
      ctx.fillStyle = pl.color; ctx.beginPath(); ctx.arc(x + 10, y + 12, 4, 0, 7); ctx.fill();
      ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(clip(pl.name, w - 22), x + 18, y + 12.5);
      // mini fan of backs
      const show = Math.min(cnt, 6), bw = w < 76 ? 13 : 17, fanW = w - 14 - 26;
      const stp = show > 1 ? U.clamp((fanW - bw) / (show - 1), 2, 5) : 0;
      for (let k = 0; k < show; k++) drawCard(ctx, x + 8 + k * stp, y + 24, bw, -1, false, (k - show / 2) * 0.06);
      ctx.font = '700 18px ' + MONO; ctx.fillStyle = cnt === 1 ? '#ee6a55' : '#f2e9d8'; ctx.textAlign = 'right';
      ctx.fillText(String(cnt), x + w - 7, y + 40);
      ctx.globalAlpha = 1;
      if (badge) tag(p.x, y + h + 2, badge[0], badge[1], badge[2], '700 11px ' + FONT);
      if (turn && st.atk > 0) tag(p.x, y - 4, '+' + st.atk, '#ee6a55', '#2b0c06', '700 11px ' + FONT);
    }
    function drawHand(now, flying) {
      const b = bottomSeat();
      const up = b === vwr();
      const lay = handLayout(b);
      const ts = myTurnSeat();
      const active = up && ts === b && !locked() && !busy && !(st.oc && st.oc.s !== b && vwr() !== st.t);
      const pl = active ? new Set(playable(st, b)) : null;
      const pdI = st.pd ? ci(st.pd) : -1;
      lay.forEach((c, k) => {
        if (flying.has('h' + c.i)) return;
        let lift = 0, dim = false;
        if (pl) { if (pl.has(c.i) && (pdI < 0 || pdI === c.i)) lift = 10; else dim = true; }
        if (sel === c.i && lift) lift = 24;
        const y = c.y - lift;
        if (sel === c.i && lift) {
          ctx.save(); ctx.translate(c.x + c.w / 2, y + c.w * 0.7); ctx.rotate(c.rot); ctx.shadowColor = 'rgba(227,174,69,.95)'; ctx.shadowBlur = 16; ctx.fillStyle = '#e3ae45'; rr(ctx, -c.w / 2 - 2, -c.w * 0.7 - 2, c.w + 4, c.w * 1.4 + 4, c.w * 0.12); ctx.fill(); ctx.restore();
        }
        drawCard(ctx, c.x, y, c.w, c.i, up, c.rot);
        if (dim) { ctx.save(); ctx.translate(c.x + c.w / 2, y + c.w * 0.7); ctx.rotate(c.rot); ctx.fillStyle = 'rgba(12,8,18,.5)'; rr(ctx, -c.w / 2, -c.w * 0.7, c.w, c.w * 1.4, c.w * 0.1); ctx.fill(); ctx.restore(); }
        else if (lift && !st.atk && pl) { /* playable cue */ }
        if (pl && pl.has(c.i)) hits.push({ i: c.i, x: c.x, y: y, w: c.last ? c.w : Math.max(c.step, 10), h: c.w * 1.4, full: c.w });
      });
    }
    function hintText() {
      if (!st || st.end) return '';
      const ts = myTurnSeat();
      if (st.oc && oneSeat() >= 0) return ''; // the big button takes this spot
      if (ts < 0) return '';
      if (vwr() !== ts) return '';
      if (st.pd) return '뽑은 ' + cardName(ci(st.pd)) + '를 낼 수 있어요';
      const pl = playable(st, ts);
      if (st.atk > 0) {
        const top = topCard(st);
        return pl.length ? '공격 +' + st.atk + ' · ' + (power(top) >= 5 ? '조커' : '같은 무늬·숫자의 센 공격 카드') + '로 막거나 받기' : '막을 카드가 없어요 · ' + st.atk + '장 받기';
      }
      if (st.ac) return 'K · 한 장 더 내세요';
      if (!pl.length) return '낼 카드가 없어요 · 1장 뽑기';
      if (sel >= 0) return rankOf(sel) === 7 ? '바꿀 무늬를 고르세요' : '한 번 더 탭하거나 「내기」';
      const top = topCard(st);
      return st.su < 0 ? '아무 카드나 낼 수 있어요' : SUITS[st.su] + (isJoker(top) || st.su !== suitOf(top) ? '' : ' 또는 ' + RK[rankOf(top)]) + ' 카드를 내세요';
    }

    /* ---------- input ---------- */
    function onDown(e) {
      if (!st || !G) return;
      const q = cv.local(e);
      for (let k = hits.length - 1; k >= 0; k--) {
        const h = hits[k];
        if (q.x >= h.x && q.x <= h.x + h.w && q.y >= h.y - 4 && q.y <= h.y + h.h) { tapCard(h.i); return; }
      }
      // tap on the draw pile = draw
      const d = deckPos();
      if (q.x >= d.x - 6 && q.x <= d.x + G.pw + 6 && q.y >= d.y - 6 && q.y <= d.y + G.pw * 1.4 + 6 && myTurnSeat() >= 0 && vwr() === st.t && !st.pd) { doDraw(); return; }
      if (sel >= 0) { sel = -1; pick7 = false; renderHud(); dirty = true; }
    }
    function tapCard(i) {
      if (busy || locked()) return;
      if (sel === i) { playSel(); return; }
      sel = i; pick7 = rankOf(i) === 7;
      api.sfx('tick'); api.buzz(6);
      renderHud(); dirty = true;
    }
    function playSel(su) {
      if (sel < 0 || myTurnSeat() < 0) return;
      if (rankOf(sel) === 7 && su == null) { pick7 = true; renderHud(); dirty = true; return; }
      const a = { t: 'play', c: cc(sel) };
      if (rankOf(sel) === 7) a.su = su;
      api.sfx('card'); api.buzz(12);
      send(a);
      renderHud(); dirty = true;
    }
    function doDraw() {
      if (busy || locked() || myTurnSeat() < 0) return;
      api.sfx('card'); api.buzz(10);
      send({ t: 'draw' });
      renderHud(); dirty = true;
    }
    cv.cv.addEventListener('pointerdown', onDown);

    /* ---------- HUD ---------- */
    const B = (txt, cls, fn, extra) => L.h('button', { class: 'btn ' + (cls || ''), style: Object.assign({ flex: '1 1 0', minWidth: 0, minHeight: '48px', padding: '6px 6px', whiteSpace: 'nowrap', fontSize: '15px' }, extra || {}), onclick: fn }, txt);
    function renderHud() {
      hud.innerHTML = '';
      const os = oneSeat();
      oneBtn.style.display = os >= 0 ? '' : 'none';
      if (os >= 0) { oneBtn.textContent = '원카드!'; oneBtn.setAttribute('aria-label', os === st.oc.s ? '원카드 외치기' : st.nm[st.oc.s] + '에게 원카드 외치기 (1장 벌칙)'); }
      if (!st || st.end) return;
      const ts = myTurnSeat();
      if (ts < 0) return;
      if (vwr() !== ts) {
        // several people share this phone and the call window is still open: the next player confirms to see their hand
        if (st.oc) {
          if (st.oc.s !== ts) hud.append(B('원카드! 잡기', 'danger', () => { api.buzz(25); api.sfx('pop'); send({ t: 'one' }, ts); }, { flex: '0 1 132px' }));
          hud.append(B(st.nm[ts] + ' 차례 · 계속', 'primary', () => { api.sfx('click'); send({ t: 'go' }, ts); }));
        }
        return;
      }
      const off = busy || locked();
      if (sel >= 0 && pick7) {
        const hand = st.h[ts], cnts = suitCounts(hand, cc(sel));
        [0, 1, 2, 3].forEach((su) => {
          const b = B(L.h('span', { style: { display: 'flex', flexDirection: 'column', lineHeight: '1.05', alignItems: 'center' } }, L.h('span', { style: { fontSize: '22px', color: su === 1 || su === 2 ? '#ff8a76' : 'var(--ink)' }, text: SUITS[su] }), L.h('span', { class: 'mono', style: { fontSize: '11px', opacity: 0.75 }, text: cnts[su] + '장' })), '', () => playSel(su));
          b.setAttribute('aria-label', SUIT_NAME[su] + '로 바꾸기'); b.disabled = off;
          hud.append(b);
        });
        hud.append(B('취소', 'ghost', () => { sel = -1; pick7 = false; api.sfx('click'); renderHud(); dirty = true; }, { flex: '0 0 64px' }));
        return;
      }
      if (st.pd) {
        hud.append(B('넘기기', '', () => { api.sfx('click'); send({ t: 'pass' }); }));
        const b = B('내기 · ' + cardName(ci(st.pd)), 'primary', () => { sel = ci(st.pd); playSel(); });
        b.disabled = off; hud.append(b);
        return;
      }
      const pl = playable(st, ts);
      const drawB = B(st.atk > 0 ? '공격 +' + st.atk + ' 받기' : '1장 뽑기', st.atk > 0 ? 'danger' : pl.length ? 'ghost' : 'primary', doDraw);
      drawB.disabled = off;
      hud.append(drawB);
      if (sel >= 0) {
        const b = B('내기 · ' + cardName(sel), 'primary', () => playSel());
        b.disabled = off; hud.append(b);
      }
    }

    /* ---------- update / animation ---------- */
    function frame() {
      const now = performance.now();
      flies = flies.filter((f) => now < f.t0 + f.dur);
      const anim = flies.length > 0 || (st && st.atk > 0);
      if (busy && !flies.length && now >= holdUntil) { setBusy(false); renderHud(); dirty = true; }
      if (anim || dirty || busy) { draw(now); dirty = false; }
    }
    function seatCardPos(s, cardI) {
      const p = seatPos(s);
      if (p.me) {
        const lay = handLayout(s), c = cardI != null ? lay.find((x) => x.i === cardI) : null;
        if (c) return { x: c.x, y: c.y, w: c.w };
        return { x: G.cx - G.cw / 2, y: G.handY + 10, w: G.cw };
      }
      return { x: p.x - 10, y: p.y - 8, w: 20 };
    }
    function animate(prev, next) {
      const l = next.last, now = performance.now(), sp = spd();
      if (!l || l.id === lastId) return;
      let t = now;
      const b = bottomSeat();
      if (l.k === 'p') {
        const ch = l.c, i = ci(ch);
        // origin from the PREVIOUS hand layout (card still there)
        let o;
        if (seatPos(l.s).me) { const saved = st; st = prev; o = seatCardPos(l.s, i); st = saved; } else o = seatCardPos(l.s);
        const pp = pilePos();
        flies.push({ key: 'play' + l.id, i, up: true, x0: o.x, y0: o.y, w0: o.w, x1: pp.x, y1: pp.y, w1: G.pw, t0: t, dur: 300 / sp, rot: 0.4 });
        t += 300 / sp;
      } else if ((l.k === 'd' || l.k === 'c') && l.n) {
        const s = l.k === 'd' ? l.s : l.s;
        const added = next.h[s].slice(-l.n).split('');
        const d = deckPos();
        const up = s === b && b === vwr();
        added.forEach((ch, k) => {
          const i = ci(ch);
          const dest = seatCardPos(s, up ? i : null);
          flies.push({ key: 'h' + (up ? i : 'x' + k), i, up, x0: d.x, y0: d.y, w0: G.pw, x1: dest.x, y1: dest.y, w1: dest.w, t0: t + k * 90 / sp, dur: 260 / sp });
        });
        t += (added.length * 90 + 260) / sp;
      }
      if (t > now) { holdUntil = Math.max(holdUntil, t); setBusy(true); }
    }
    function feedback(prev, next) {
      const l = next.last;
      if (!l || l.id === lastId) return;
      const nm = (x) => next.nm[x];
      const mine = (x) => api.canAct(x);
      if (l.k === 'p') {
        const i = ci(l.c), r = rankOf(i);
        if (power(i)) { api.toast((prev.atk > 0 ? '방어! ' : '공격! ') + '+' + l.atk); api.sfx('hit'); api.buzz(20); }
        else if (l.fx === 'j') { api.toast('점프! ' + nm(nextSeat(prev, l.s, next.dir)) + ' 건너뜀'); api.sfx('whoosh'); }
        else if (l.fx === 'q') { api.toast('방향 전환'); api.sfx('whoosh'); }
        else if (l.fx === 'k') { api.toast(nm(l.s) + ' 한 번 더!'); api.sfx('pop'); }
        else if (r === 7) { api.toast(SUITS[l.su] + ' ' + SUIT_NAME[l.su] + '로 변경'); api.sfx('chip'); }
        else api.sfx('card');
        if (l.fin) { api.toast(nm(l.s) + (next.o.mode ? ' ' + l.fin + '위!' : ' 패를 다 털었어요!')); api.sfx('win'); }
      } else if (l.k === 'd') {
        api.sfx('card');
        if (l.atk) { api.toast(nm(l.s) + ' ' + l.n + '장 받음'); api.buzz(mine(l.s) ? 30 : 0); }
        if (l.rs) setTimeout(() => api.toast('버린 카드를 섞어 다시 쌓았어요'), 600 / spd());
      } else if (l.k === 'o') { api.toast(nm(l.s) + ': 원카드!'); api.sfx('pop'); api.buzz(15); }
      else if (l.k === 'c') { api.toast(nm(l.by) + ' 원카드! ' + nm(l.s) + ' 1장 벌칙'); api.sfx('lose'); api.buzz(30); }
      if (l.bust) { setTimeout(() => api.toast(nm(l.s) + ' 파산!'), 400 / spd()); api.sfx('thud'); }
      if (l.esc != null) { /* nobody called in time */ }
    }

    const stopLoop = U.loop(frame);
    const wd = setInterval(() => { if (busy && performance.now() > holdUntil + 600 / spd()) { flies = []; setBusy(false); renderHud(); dirty = true; } }, 300);
    return {
      update(next, prev) {
        const isNew = prev && prev !== next;
        st = next;
        geometry();
        if (!bg || !prev) buildBg();
        if (isNew) { animate(prev, next); feedback(prev, next); }
        lastId = next.last ? next.last.id : -1;
        if (isNew && prev.seq !== next.seq) { sel = -1; pick7 = false; waitSeq = -1; }
        if (sel >= 0 && (myTurnSeat() < 0 || next.h[next.t].indexOf(cc(sel)) < 0)) { sel = -1; pick7 = false; }
        renderHud();
        dirty = true;
      },
      destroy() { stopLoop(); clearInterval(wd); setBusy(false); cv.cv.removeEventListener('pointerdown', onDown); cv.destroy(); hud.remove(); oneBtn.remove(); helpBtn.remove(); Object.values(anc).forEach((el) => el.remove()); if (helpEl) helpEl.remove(); },
    };
  }

  L.register({
    id: 'onecard', name: '원카드', tag: '카드', cat: '카드', hidden: true,
    blurb: '같은 무늬나 같은 숫자를 내며 손패를 먼저 털면 이겨요. 공격 카드는 쌓이고, 한 장 남으면 「원카드!」를 외쳐야 해요.',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, aiDelay: 760,
    options: [
      { id: 'hand', label: '처음 패', choices: [{ v: 7, label: '7장' }, { v: 5, label: '5장' }], def: 7 },
      { id: 'drawPlay', label: '뽑은 카드 바로 내기', choices: [{ v: 'off', label: '안 됨' }, { v: 'on', label: '가능' }], def: 'off' },
      { id: 'bust', label: '파산', choices: [{ v: 20, label: '20장' }, { v: 15, label: '15장' }, { v: 0, label: '없음' }], def: 20 },
      { id: 'mode', label: '끝내기', choices: [{ v: 'first', label: '1등 나오면 끝' }, { v: 'rank', label: '끝까지 순위' }], def: 'first' },
    ],
    quick: [
      '손에 든 카드를 가장 먼저 다 내면 이겨요.',
      '내 차례: 바닥 맨 위 카드와 무늬(♠◆♥♣)나 숫자가 같은 카드 1장 내기. 낼 게 없으면 1장 뽑기.',
      '공격 카드(2 · A · 조커)를 맞으면 막거나 뽑아요. 1장 남으면 「원카드!」를 꼭 누르세요.',
    ],
    rules: [
      { h: '목표', p: [
        '손에 든 카드를 가장 먼저 다 내면 이겨요.',
        '카드는 트럼프 52장 + 조커 2장(흑백 조커 · 컬러 조커)이에요.',
        '게임 중 왼쪽 위 「카드 효과」 버튼을 누르면 특수 카드 표를 바로 볼 수 있어요.'] },
      { h: '준비', p: [
        '한 사람에게 7장씩(설정: 5장) 나눠요.',
        '가운데 왼쪽은 뽑을 더미(뒷면), 오른쪽은 바닥(앞면)이에요. 더미에서 1장을 펼쳐 시작 카드로 써요.',
        '시작 카드는 효과가 없어요(조커면 다시 펼쳐요).',
        '첫 사람은 무작위. 처음엔 시계 방향으로 돌아가요.'] },
      { h: '차례에 할 일', p: [
        '① 바닥 맨 위 카드와 무늬나 숫자가 같은 카드 1장을 내요. 조커는 언제든 낼 수 있어요.',
        '② 낼 카드가 없으면(또는 내기 싫으면) 더미에서 1장 뽑고 차례가 끝나요.',
        '③ 카드를 내서 1장이 남으면 바로 「원카드!」를 눌러요.',
        '④ 마지막 카드까지 내면 승리! 마지막 1장을 특수·공격 카드로 내도 돼요.'] },
      { h: '특수 카드', p: [
        'J 점프 → 다음 사람을 건너뛰어요. (둘이서 하면 다시 내 차례)',
        'Q 방향 바꾸기 → 도는 방향이 반대로. (둘이서 하면 그냥 상대 차례)',
        'K 한 번 더 → 바로 1장 더 내요. 낼 게 없으면 1장 뽑아요.',
        '7 무늬 바꾸기 → 원하는 무늬를 골라요. 다음 사람은 그 무늬나 숫자 7을 내요.',
        '조커 → 아무 때나 낼 수 있는 공격 카드. 조커 다음 사람은(공격을 막거나 받은 뒤) 아무 카드나 낼 수 있어요.'] },
      { h: '공격 카드 (뽑기 공격)', p: [
        '공격 카드를 내면 다음 사람이 그 장수만큼 뽑아야 해요.',
        '2 → +2장 · A → +3장 · ♠A → +5장 · 흑백 조커 → +5장 · 컬러 조커 → +7장',
        '공격받은 사람은 막을 카드를 내면 공격이 쌓여서 다음 사람에게 넘어가요.',
        '막지 못하면(또는 안 막으면) 쌓인 장수를 모두 뽑고 차례가 끝나요.'] },
      { h: '무엇으로 막나요?', p: [
        '규칙은 하나: 같은 세기 이상의 공격 카드이면서, 무늬나 숫자가 맞아야 해요(조커는 무늬 상관없음).',
        '2 (+2) ← 같은 무늬 A, 다른 2, 조커로 막기',
        'A (+3) ← 다른 A(♠A 포함), 조커로 막기',
        '♠A (+5) ← 조커로만 막기',
        '흑백 조커 (+5) ← 컬러 조커로만 막기',
        '컬러 조커 (+7) ← 못 막아요'] },
      { h: '원카드!', p: [
        '카드를 내서 1장이 남으면 바로 화면의 「원카드!」를 눌러요.',
        '내가 누르기 전에 다른 사람이 먼저 누르면 → 나는 벌칙으로 1장 뽑아요.',
        '남이 1장 남았는데 깜빡하면, 내가 먼저 「원카드!」를 눌러 잡을 수 있어요.',
        '아무도 안 누르고 다음 사람이 카드를 내거나 뽑으면 → 그냥 넘어가요.',
        'AI는 자기 원카드를 바로 외치고, 사람이 깜빡하면 1초쯤 뒤에 잡아내요(쉬움 AI는 가끔 깜빡하고 잡는 것도 느려요).',
        '한 폰을 돌려 쓸 때는 다음 사람이 「계속」을 누르면 원카드 기회가 끝나요.'] },
      { h: '점수·승리', p: [
        '기본(「1등 나오면 끝」): 누군가 카드를 다 내면 그 사람이 1등, 판이 끝나요.',
        '「끝까지 순위」: 다 낸 순서대로 1위, 2위… 한 명이 남을 때까지 계속해요. 파산한 사람은 꼴찌 쪽이에요.',
        '파산: 손패가 20장(설정: 15장)이 되면 그 판에서 빠져요. 그 사람 카드는 뽑을 더미에 섞여요. 「파산 없음」도 고를 수 있어요.',
        '한 명 빼고 모두 파산하면 남은 사람이 이겨요.',
        '뽑을 카드도 낼 카드도 없어 모두 넘기기만 하거나, 판이 900수를 넘기면 손패가 가장 적은 사람이 이겨요.'] },
      { h: '그 밖의 규칙', p: [
        '뽑을 더미가 떨어지면 바닥 맨 위 카드만 남기고 나머지를 섞어 새 더미로 써요.',
        '「뽑은 카드 바로 내기」를 켜면, 방금 뽑은 카드가 낼 수 있는 카드일 때 바로 내거나 넘길 수 있어요(기본은 꺼짐).'] },
      { h: '조작', p: [
        '낼 수 있는 카드는 살짝 떠오르고, 못 내는 카드는 어둡게 보여요.',
        '카드를 탭하면 고르고, 한 번 더 탭하거나 「내기」를 누르면 내요. 7을 내면 무늬 고르기 버튼이 떠요.',
        '가운데 더미를 탭하거나 「1장 뽑기」/「공격 +N 받기」로 뽑아요.',
        '다른 사람 패는 뒷면과 장수만 보여요. 한 폰으로 여럿이 하면 차례마다 가림막이 떠요.'] },
      { h: '예시 ① 기본', p: [
        '바닥이 ♥5면 → ♥ 아무 카드나, 숫자 5(♠5 · ◆5 · ♣5)를 낼 수 있어요.',
        '바닥이 ♣9인데 ♣도 9도 없으면 → 1장 뽑기.',
        '바닥이 ◆3일 때 ◆7을 내고 「♥」를 고르면 → 다음 사람은 ♥나 7을 내야 해요.'] },
      { h: '예시 ② 공격 쌓기', p: [
        'A가 ♥2를 냄(+2) → B가 ♥A로 막음(+3, 쌓여서 +5) → C는 A나 조커가 없어요.',
        '→ C가 「공격 +5 받기」로 5장을 뽑고 차례가 끝나요.',
        '♠2 공격이라면: ♠A · ◆2 · 조커로 막을 수 있지만, ◆A로는 못 막아요(무늬도 숫자도 달라요).'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움(보이는 카드부터 냄)·보통·어려움(나온 카드를 기억하고 공격·조커·7을 아껴 씀)으로 고를 수 있어요.'] },
    ],
    tutorial: [
      { sel: '.oc-hand', text: '아래가 내 손패예요. 이 카드를 가장 먼저 다 내면 이겨요!' },
      { sel: '.oc-piles', text: '가운데 왼쪽은 뽑을 더미, 오른쪽은 바닥이에요. 바닥 맨 위 카드와 무늬(♠◆♥♣)나 숫자가 같은 카드를 1장씩 내요.' },
      { sel: '.oc-hand', text: '낼 수 있는 카드는 살짝 떠오르고, 못 내는 카드는 어두워요. 카드를 탭하고 한 번 더 탭(또는 「내기」)하면 내요.' },
      { sel: '.oc-bar', text: '낼 게 없으면 아래 「1장 뽑기」(또는 더미 탭). 공격을 받았는데 못 막으면 「공격 +N 받기」로 쌓인 만큼 뽑아요.' },
      { sel: '.oc-help', text: '공격 카드: 2(+2장) · A(+3장, ♠A는 +5장) · 조커(+5 · +7장). 그 밖에 J 건너뛰기 · Q 방향 바꾸기 · K 한 번 더 · 7 무늬 바꾸기. 헷갈리면 「카드 효과」를 누르세요.' },
      { sel: '.oc-opp', text: '다른 사람은 카드 장수만 보여요. 누가 1장 남으면 「원카드!」 버튼이 떠요 — 내 거면 바로 누르고, 남의 거면 먼저 눌러 잡으세요(1장 벌칙)!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { AIH, ALPH, ci, cc, power, canPlay, playable, suitOf, rankOf, nextSeat, BJ, CJ },
  });
})();
