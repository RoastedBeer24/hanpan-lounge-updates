/* 화산섬 탈출 — 턴제 탈출 보드게임(1–4인). 9×11 육각 격자 위의 섬(모양 8종, 판마다 시드로 생성).
   차례마다 탐험가 한 명이 걸음 수(기본 4, 오르막 2걸음, 무거우면 줄어듦) 안에서 한 칸을 골라 이동하고, 도착 칸의 보물을 줍는다.
   모두 한 번씩 움직이면 화산 차례: 금 간 해안이 가라앉고, 용암이 비탈을 따라 흐르고(결정적 — 다음 분화는 미리 빛으로 보임),
   화산탄이 떨어진다. 구조선(3척, 각 2자리)은 정해진 라운드에 떠난다. 배에 오른 사람의 보물만 점수.
   지형(높이·분화 방향)은 (모양, 시드)에서 결정적으로 만들어져 게스트도 같은 섬을 그린다. 상태에는 칸 상태·보물 문자열만. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= grid (odd-r offset, pointy-top) ======================= */
  const GW = 9, GH = 11, N = GW * GH, SQ3 = Math.sqrt(3);
  const CXs = new Float32Array(N), CYs = new Float32Array(N);   // centres in hex-radius units
  const NB = [];
  for (let i = 0; i < N; i++) {
    const c = i % GW, r = (i / GW) | 0;
    CXs[i] = (c + 0.5 * (r & 1)) * SQ3 + SQ3 / 2; CYs[i] = r * 1.5 + 1;
    const D = r & 1 ? [[0, -1], [1, -1], [-1, 0], [1, 0], [0, 1], [1, 1]] : [[-1, -1], [0, -1], [-1, 0], [1, 0], [-1, 1], [0, 1]];
    const o = [];
    for (const [dc, dr] of D) { const cc = c + dc, rr = r + dr; if (cc >= 0 && rr >= 0 && cc < GW && rr < GH) o.push(rr * GW + cc); }
    NB.push(o);
  }
  const GRID_W = 9.5 * SQ3, GRID_H = 17, CX0 = GRID_W / 2, CY0 = GRID_H / 2;
  const isBorder = (i) => { const c = i % GW, r = (i / GW) | 0; return c === 0 || r === 0 || r === GH - 1 || c === GW - 1; };
  function hexDist(a, b) {
    const ca = a % GW, ra = (a / GW) | 0, cb = b % GW, rb = (b / GW) | 0;
    const qa = ca - ((ra - (ra & 1)) >> 1), qb = cb - ((rb - (rb & 1)) >> 1);
    const dq = qa - qb, dr = ra - rb;
    return Math.max(Math.abs(dq), Math.abs(dr), Math.abs(dq + dr));
  }

  /* ======================= deterministic noise ======================= */
  function hsh(a, b, c) {
    let x = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul(c | 0, 0x27d4eb2d)) | 0;
    x = Math.imul(x ^ (x >>> 13), 1274126177); x ^= x >>> 16;
    return (x >>> 0) / 4294967296;
  }
  function vnoise(x, y, sd) {
    const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
    const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    const v = (a, b) => hsh(a, b, sd) * 2 - 1;
    const a0 = v(ix, iy) + (v(ix + 1, iy) - v(ix, iy)) * sx, a1 = v(ix, iy + 1) + (v(ix + 1, iy + 1) - v(ix, iy + 1)) * sx;
    return a0 + (a1 - a0) * sy;
  }
  function capsule(X, Y, ax, ay, bx, by, r) {
    const dx = bx - ax, dy = by - ay, t = Math.max(0, Math.min(1, ((X - ax) * dx + (Y - ay) * dy) / (dx * dx + dy * dy)));
    return r - Math.hypot(X - ax - dx * t, Y - ay - dy * t);
  }

  /* ======================= island shapes ======================= */
  const SHAPES = [
    { n: '둥근 섬', f: (X, Y) => 0.8 - Math.hypot(X, Y) },
    { n: '초승달 섬', f: (X, Y) => Math.min(0.9 - Math.hypot(X, Y), Math.hypot(X - 0.55, Y + 0.05) - 0.48) },
    { n: '쌍둥이 섬', f: (X, Y) => Math.max(0.46 - Math.hypot(X + 0.18, Y + 0.5), 0.44 - Math.hypot(X - 0.2, Y - 0.52), capsule(X, Y, -0.18, -0.5, 0.2, 0.52, 0.1)) },
    { n: '긴 섬', f: (X, Y) => { const u = X * 0.78 + Y * 0.62, v = -X * 0.62 + Y * 0.78; return 0.9 * (1 - Math.hypot(u / 1.0, v / 0.5)); } },
    { n: '세 갈래 섬', f: (X, Y) => { let m = 0.36 - Math.hypot(X, Y); for (let k = 0; k < 3; k++) { const a = -Math.PI / 2 + k * 2 * Math.PI / 3; m = Math.max(m, capsule(X, Y, 0, 0, Math.cos(a) * 0.84, Math.sin(a) * 0.84, 0.25)); } return m; } },
    { n: '말굽 섬', f: (X, Y) => { const d = Math.hypot(X, Y); let m = Math.min(0.9 - d, d - 0.3); if (Y > 0.05) m = Math.min(m, Math.abs(X) - 0.24); return m; } },
    { n: '나비 섬', f: (X, Y) => { const wing = (sx) => Math.max(0.36 - Math.hypot(X - sx * 0.5, Y + 0.42), 0.32 - Math.hypot(X - sx * 0.48, Y - 0.45)); return Math.max(wing(1), wing(-1), capsule(X, Y, 0, -0.55, 0, 0.55, 0.13)); } },
    { n: '별 섬', f: (X, Y) => { const a = Math.atan2(Y, X), d = Math.hypot(X, Y); return 0.6 + 0.3 * Math.cos(5 * a + Math.PI / 2) - d; } },
  ];

  function largest(f, th) {
    const seen = new Uint8Array(N); let best = [];
    for (let i = 0; i < N; i++) {
      if (seen[i] || !(f[i] > th)) continue;
      const comp = [i]; seen[i] = 1;
      for (let k = 0; k < comp.length; k++) for (const j of NB[comp[k]]) if (!seen[j] && f[j] > th) { seen[j] = 1; comp.push(j); }
      if (comp.length > best.length) best = comp;
    }
    return best.sort((a, b) => a - b);
  }

  /* island terrain from (shape, seed): H[i] = −1 sea, 0–4 land height, 5 crater. Pure + cached. */
  const GEN = {};
  function gen(v, sd) {
    const key = v + ':' + sd;
    if (GEN[key]) return GEN[key];
    const sh = SHAPES[v].f, f = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      const X = (CXs[i] - CX0) / 7, Y = (CYs[i] - CY0) / 7.5;
      f[i] = isBorder(i) ? -9 : sh(X, Y) + 0.15 * vnoise(X * 2.6 + 9, Y * 2.6 + 9, sd);
    }
    let th = 0, land = largest(f, th);
    for (let it = 0; it < 80 && (land.length < 37 || land.length > 58); it++) { th += land.length < 37 ? -0.015 : 0.015; land = largest(f, th); }
    const isL = new Uint8Array(N); for (const i of land) isL[i] = 1;
    // distance to the sea
    const ds = new Int8Array(N).fill(-1), q = [];
    for (let i = 0; i < N; i++) if (!isL[i]) { ds[i] = 0; q.push(i); }
    for (let k = 0; k < q.length; k++) for (const j of NB[q[k]]) if (ds[j] < 0) { ds[j] = ds[q[k]] + 1; q.push(j); }
    let mx = 0, my = 0; for (const i of land) { mx += CXs[i]; my += CYs[i]; } mx /= land.length; my /= land.length;
    let cr = land[0];
    for (const i of land) { if (ds[i] > ds[cr] || (ds[i] === ds[cr] && Math.hypot(CXs[i] - mx, CYs[i] - my) < Math.hypot(CXs[cr] - mx, CYs[cr] - my))) cr = i; }
    const dc = new Int8Array(N).fill(99), q2 = [cr]; dc[cr] = 0;
    for (let k = 0; k < q2.length; k++) for (const j of NB[q2[k]]) if (isL[j] && dc[j] === 99) { dc[j] = dc[q2[k]] + 1; q2.push(j); }
    const H = new Int8Array(N).fill(-1);
    for (const i of land) {
      if (i === cr) { H[i] = 5; continue; }
      const X = (CXs[i] - CX0) / 7, Y = (CYs[i] - CY0) / 7.5;
      const base = 4.3 * ds[i] / (ds[i] + dc[i]);
      let h = Math.round(base + 0.95 * vnoise(X * 3.3 + 31, Y * 3.3 + 17, sd ^ 0x5bd1) - 0.15);
      h = Math.max(0, Math.min(4, h));
      if (ds[i] === 1) h = Math.min(h, 1);
      if (dc[i] === 1) h = Math.max(3, Math.min(4, h));
      H[i] = h;
    }
    return (GEN[key] = { H, land, cr, dc, ds });
  }

  /* ======================= rules data ======================= */
  const VAL = [0, 1, 3, 6], WT = [0, 0, 1, 2];
  const TNAME = ['', '금화', '보석', '황금 우상'];
  const CAP = 2;                                  // seats per rescue boat
  const LENS = { s: [5, 7, 9], m: [6, 9, 12], l: [8, 11, 14] };
  const pval = (p) => p[1] * VAL[1] + p[2] * VAL[2] + p[3] * VAL[3];
  const pwt = (p) => p[2] * WT[2] + p[3] * WT[3];
  const apFor = (w, stun) => Math.max(1, 4 - Math.floor(w / 2) - (stun ? 2 : 0));
  const apOf = (p) => apFor(pwt(p), p[5]);
  const setc = (str, i, ch) => str.slice(0, i) + ch + str.slice(i + 1);
  const walk = (ch) => ch === '.' || ch === 'R';

  function crackCount(r, Lr) { const f = r / Lr; return f < 0.25 ? 1 : f < 0.7 ? 2 : 3; }
  function rockCount(r, Lr) { const f = r / Lr; return r <= 1 ? 0 : f < 0.4 ? 1 : f < 0.75 ? 2 : 3; }
  function eruptCount(ph, Lr) { const f = ph / Lr; return ph === 1 ? 1 : f < 0.34 ? ph % 2 : f < 0.67 ? 1 : 2; }

  /* lava cells created at phase `ph`: every fresh lava cell (A) flows to its lowest downhill neighbour(s) (at most 2;
     level ground only onto untouched land), and the crater spills into its neighbours. Deterministic. */
  function lavaStep(b, H, cr, ph, sd, excl, Lr) {
    const out = [];
    const ok = (j) => walk(b[j]) && excl.indexOf(j) < 0;
    for (let i = 0; i < N; i++) {
      if (b[i] !== 'A') continue;
      let best = 99, cand = [];
      for (const j of NB[i]) {
        if (!ok(j)) continue;
        if (H[j] < H[i] || (H[j] === H[i] && b[j] === '.')) { if (H[j] < best) { best = H[j]; cand = [j]; } else if (H[j] === best) cand.push(j); }
      }
      if (cand.length > 2) { cand.sort((a, c) => hsh(a, ph, sd) - hsh(c, ph, sd)); cand.length = 2; }
      for (const j of cand) if (out.indexOf(j) < 0) out.push(j);
    }
    const e = eruptCount(ph, Lr);
    if (e > 0) {
      const cs = NB[cr].filter(ok).sort((a, c) => hsh(a, ph * 7 + 3, sd) - hsh(c, ph * 7 + 3, sd));
      for (let k = 0; k < e && k < cs.length; k++) if (out.indexOf(cs[k]) < 0) out.push(cs[k]);
    }
    return out.sort((a, c) => a - c);
  }

  /* choose the next volcano phase: cracks (random), rocks (random, often near explorers), lava (deterministic) */
  function plan(s) {
    const G = gen(s.v, s.sd), H = G.H, b = s.b;
    const coast = [];
    for (let i = 0; i < N; i++) if (walk(b[i]) && NB[i].some((j) => b[j] === '~')) coast.push([i, H[i] + Math.random() * 1.8]);
    coast.sort((a, c) => a[1] - c[1]);
    s.nk = coast.slice(0, crackCount(s.r, s.Lr)).map((o) => o[0]).sort((a, c) => a - c);
    const kr = rockCount(s.r, s.Lr), act = s.p.filter((p) => p[4] === 0).map((p) => p[0]);
    const cand = [];
    for (let i = 0; i < N; i++) if (walk(b[i]) && s.nk.indexOf(i) < 0) cand.push([i, act.some((x) => hexDist(x, i) <= 2) ? 4 : 1]);
    s.nr = [];
    for (let k = 0; k < kr && cand.length; k++) {
      let tot = 0; for (const o of cand) tot += o[1];
      let r = Math.random() * tot, j = 0;
      while (j < cand.length - 1 && r >= cand[j][1]) { r -= cand[j][1]; j++; }
      s.nr.push(cand[j][0]); cand.splice(j, 1);
    }
    s.nr.sort((a, c) => a - c);
    s.nl = lavaStep(b, H, G.cr, s.r, s.sd, s.nk, s.Lr);
  }

  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const v = opts.shape != null && opts.shape !== 'r' && SHAPES[+opts.shape] ? +opts.shape : U.rand(SHAPES.length);
    const ln = LENS[opts.len] ? opts.len : 'm';
    const sd = 1 + U.rand(1e9);
    const G = gen(v, sd), H = G.H;
    const b = [];
    for (let i = 0; i < N; i++) b.push(H[i] < 0 ? '~' : i === G.cr ? 'X' : '.');
    const angC = (i) => Math.atan2(CYs[i] - CYs[G.cr], CXs[i] - CXs[G.cr]);
    const adiff = (a, c) => { let d = a - c; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return Math.abs(d); };
    const base = Math.random() * Math.PI * 2;
    // explorers start on the middle slopes, spread around the volcano
    const starts = [];
    for (let k = 0; k < n; k++) {
      const ta = base + k * 2 * Math.PI / n;
      let best = -1, bv = 1e9;
      for (const i of G.land) {
        if (i === G.cr || starts.indexOf(i) >= 0 || starts.some((j) => NB[j].indexOf(i) >= 0)) continue;
        const pen = (H[i] === 1 || H[i] === 2 ? 0 : 1.2) + (G.dc[i] < 2 ? 3 : 0) + Math.abs(G.dc[i] - 2.5) * 0.35 + (G.ds[i] <= 1 ? 1 : 0);
        const val = adiff(angC(i), ta) + pen + Math.random() * 0.2;
        if (val < bv) { bv = val; best = i; }
      }
      if (best < 0) best = G.land.find((i) => i !== G.cr && starts.indexOf(i) < 0);
      starts.push(best);
    }
    // rescue boats: sea cells next to the shore, spread around (between the explorers)
    const seaAdj = [];
    for (let i = 0; i < N; i++) if (H[i] < 0 && NB[i].some((j) => H[j] >= 0)) seaAdj.push(i);
    const boats = [];
    for (let k = 0; k < 3; k++) {
      const ta = base + Math.PI / Math.max(2, n) + k * 2 * Math.PI / 3;
      let best = -1, bv = 1e9;
      for (const i of seaAdj) {
        if (boats.indexOf(i) >= 0 || boats.some((j) => hexDist(i, j) <= 2)) continue;
        const val = adiff(angC(i), ta) + (isBorder(i) ? 0.25 : 0) + Math.random() * 0.15;
        if (val < bv) { bv = val; best = i; }
      }
      if (best < 0) best = seaAdj.find((i) => boats.indexOf(i) < 0);
      boats.push(best);
    }
    const deps = U.shuffle(LENS[ln].slice());
    // treasure: richer near the volcano
    const t = Array(N).fill('0');
    let tv = 0;
    for (const i of G.land) {
      if (i === G.cr || starts.indexOf(i) >= 0) continue;
      const hv = H[i];
      if (Math.random() > (hv >= 3 ? 0.62 : hv === 2 ? 0.5 : 0.36)) continue;
      const q = Math.random();
      const ty = hv >= 3 ? (q < 0.42 ? 3 : q < 0.85 ? 2 : 1) : hv === 2 ? (q < 0.1 ? 3 : q < 0.52 ? 2 : 1) : (q < 0.18 ? 2 : 1);
      t[i] = String(ty); tv += VAL[ty];
    }
    const s = {
      v, sd, n, ln, Lr: Math.max(...deps), nm: players.map((q, k) => String((q && q.name) || k + 1 + '번').slice(0, 8)),
      b: b.join(''), t: t.join(''),
      p: starts.map((x) => [x, 0, 0, 0, 0, 0, 0]),   // [cell, 금화, 보석, 우상, 상태(0 섬·1 탈출·2 용암·3 남겨짐), 기절, 탈출 순서]
      bt: boats.map((x, k) => [x, deps[k], 0]),      // [cell(−1 떠남), 출발 라운드, 탄 사람]
      r: 1, cur: 0, es: 0, tv, nl: [], nk: [], nr: [], seq: 0, last: null, end: 0,
    };
    plan(s);
    return s;
  }

  function actor(s) { return s.end ? null : s.cur; }
  const occupied = (s, i, seat) => s.p.some((p, k) => k !== seat && p[4] === 0 && p[0] === i);
  const boatAt = (s, i) => s.bt.findIndex((o) => o[0] === i);

  /* Dijkstra (≤ 99 cells). Costs: land 1 (+1 uphill), sea 2 (only with empty hands), boarding 1. Lava/crater blocked.
     block: optional Uint8Array of extra blocked cells (AI planning). Boats are end points only. */
  const DQ = new Float64Array(N), DONE = new Uint8Array(N);
  function reach(s, from, ap, carrying, block) {
    const G = gen(s.v, s.sd), H = G.H, b = s.b;
    const d = new Float64Array(N).fill(Infinity), pv = new Int16Array(N).fill(-1);
    DONE.fill(0); d[from] = 0;
    const bAt = new Int8Array(N).fill(-1);
    s.bt.forEach((o, k) => { if (o[0] >= 0) bAt[o[0]] = k; });
    for (;;) {
      let u = -1, best = Infinity;
      for (let i = 0; i < N; i++) if (!DONE[i] && d[i] < best) { best = d[i]; u = i; }
      if (u < 0) break;
      DONE[u] = 1;
      if (bAt[u] >= 0 && u !== from) continue;
      const hu = b[u] === '~' ? 0 : H[u];
      for (const v of NB[u]) {
        if (DONE[v]) continue;
        let c;
        if (bAt[v] >= 0) { if (s.bt[bAt[v]][2] >= CAP) continue; c = 1; }
        else if (b[v] === '~') { if (carrying) continue; c = 2; }
        else if (walk(b[v])) c = H[v] > hu ? 2 : 1;
        else continue;
        if (block && block[v] && bAt[v] < 0) continue;
        const nd = d[u] + c;
        if (nd <= ap && nd < d[v]) { d[v] = nd; pv[v] = u; }
      }
    }
    return { d, pv };
  }
  function pathTo(pv, from, to) { const out = [to]; let x = to; while (x !== from && pv[x] >= 0 && out.length < 40) { x = pv[x]; out.unshift(x); } return out; }
  function legalTargets(s, seat) {
    const p = s.p[seat], ap = apOf(p), R = reach(s, p[0], ap, pval(p) > 0 || pwt(p) > 0, null), out = [];
    for (let i = 0; i < N; i++) if (i !== p[0] && R.d[i] <= ap && !occupied(s, i, seat)) out.push(i);
    return { list: out, R, ap };
  }

  function moversLeft(s) {   // explorers still to move this round after the current one
    const n = s.n, st0 = (s.r - 1) % n, k = (s.cur - st0 + n) % n;
    let c = 0; for (let k2 = k + 1; k2 < n; k2++) if (s.p[(st0 + k2) % n][4] === 0) c++;
    return c;
  }
  /* volcano phase at the end of a round */
  function phase(s) {
    const G = gen(s.v, s.sd);
    const pre = { pb: s.b, pt: s.t, pbt: s.bt.map((o) => o[0]) };
    const b = s.b.split(''), t = s.t.split('');
    const info = { nl: s.nl.slice(), sk: [], rk: s.nr.slice(), ob: [], hit: [], out: [], fell: [], gone: [] };
    for (const i of s.nk) if (walk(b[i])) { b[i] = '~'; t[i] = '0'; info.sk.push(i); }
    for (let i = 0; i < N; i++) { if (b[i] === 'B') b[i] = 'R'; else if (b[i] === 'A') b[i] = 'B'; }
    for (const i of s.nl) if (walk(b[i])) { b[i] = 'A'; t[i] = '0'; }
    s.p.forEach((p, k) => {
      if (p[4] !== 0) return;
      const x = p[0];
      if (b[x] === 'A') { p[4] = 2; info.out.push(k); return; }
      if (info.sk.indexOf(x) >= 0) { p[1] = p[2] = p[3] = 0; info.fell.push(k); }
      if (s.nr.indexOf(x) >= 0 && b[x] !== '~') { p[5] = 1; info.hit.push(k); }
    });
    for (const i of s.nr) if (walk(b[i]) && t[i] === '0' && !s.p.some((p) => p[4] === 0 && p[0] === i)) { t[i] = '2'; info.ob.push(i); }
    s.b = b.join(''); s.t = t.join('');
    s.bt.forEach((o, k) => {
      if (o[0] < 0) return;
      if (o[1] <= s.r) { o[0] = -1; info.gone.push(k); return; }
      if (!NB[o[0]].some((j) => s.b[j] !== '~')) {   // shore sank: drift to the nearest sea cell next to land
        const seen = new Uint8Array(N), q = [o[0]]; seen[o[0]] = 1;
        let to = -1;
        for (let h = 0; h < q.length && to < 0; h++) for (const j of NB[q[h]]) {
          if (seen[j] || s.b[j] !== '~') continue; seen[j] = 1;
          if (s.bt.some((z) => z[0] === j) || s.p.some((p) => p[4] === 0 && p[0] === j)) { q.push(j); continue; }
          if (NB[j].some((z) => s.b[z] !== '~')) { to = j; break; }
          q.push(j);
        }
        if (to >= 0) o[0] = to;
      }
    });
    if (!s.p.some((p) => p[4] === 0)) s.end = 1;
    else if (s.r >= s.Lr || !s.bt.some((o) => o[0] >= 0) || s.r >= 40) { s.p.forEach((p) => { if (p[4] === 0) p[4] = 3; }); s.end = 1; }
    else { s.r++; plan(s); }
    return { pre, info };
  }

  function advance(s) {
    if (!s.p.some((p) => p[4] === 0)) { s.end = 1; return null; }
    const n = s.n, st0 = (s.r - 1) % n, k = (s.cur - st0 + n) % n;
    for (let k2 = k + 1; k2 < n; k2++) { const q = (st0 + k2) % n; if (s.p[q][4] === 0) { s.cur = q; return null; } }
    const ph = phase(s);
    if (!s.end) {
      const st1 = (s.r - 1) % n;
      for (let k2 = 0; k2 < n; k2++) { const q = (st1 + k2) % n; if (s.p[q][4] === 0) { s.cur = q; break; } }
    }
    return ph;
  }

  function apply(s, seat, a) {
    if (s.end) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const p = s.p[seat];
    if (a.t === 'drop') {
      const ty = a.k | 0;
      if (ty < 1 || ty > 3 || p[ty] <= 0) throw new Error('nothing to drop');
      p[ty]--;
      const placed = s.t[p[0]] === '0' && walk(s.b[p[0]]);
      if (placed) s.t = setc(s.t, p[0], String(ty));
      s.seq++; s.last = { id: s.seq, k: 'd', s: seat, ty, x: p[0], pl: placed ? 1 : 0 };
      return s;
    }
    let path = [p[0]], pk = 0, bo = -1;
    if (a.t === 'mv') {
      const to = a.to | 0, L2 = legalTargets(s, seat);
      if (L2.list.indexOf(to) < 0) throw new Error('illegal move');
      path = pathTo(L2.R.pv, p[0], to);
      const bi = boatAt(s, to);
      if (bi >= 0) { bo = bi; s.bt[bi][2]++; p[0] = to; p[4] = 1; p[6] = ++s.es; }
      else {
        p[0] = to;
        const ty = +s.t[to];
        if (ty) { pk = ty; p[ty]++; s.t = setc(s.t, to, '0'); }
      }
    } else if (a.t !== 'stay') throw new Error('bad action');
    p[5] = 0;
    s.seq++;
    const last = { id: s.seq, k: 'm', s: seat, pa: path, pk, bo };
    const ph = advance(s);
    if (ph) { last.ph = ph.info; last.pre = ph.pre; }
    s.last = last;
    return s;
  }

  function stars(s, p) {
    if (p[4] !== 1) return 0;
    const v = pval(p), tv = Math.max(20, s.tv);
    return v >= tv * 0.45 ? 3 : v >= tv * 0.25 ? 2 : 1;
  }
  function result(s) {
    if (!s.end) return null;
    const rows = s.p.map((p, k) => ({ k, p, v: pval(p) }));
    const esc = rows.filter((o) => o.p[4] === 1);
    const stTxt = (p) => (p[4] === 1 ? pval(p) + '점' : p[4] === 2 ? '용암에 갇힘' : '섬에 남겨짐');
    if (s.n === 1) {
      const p = s.p[0], st = stars(s, p);
      if (!st) return { winners: [], title: '탈출 실패…', text: (p[4] === 2 ? '용암에 갇혔어요.' : '마지막 배가 떠나 버렸어요.') + ' 다음엔 조금 일찍 배로!' };
      return { winners: [0], title: '★★★'.slice(0, st) + '☆☆☆'.slice(0, 3 - st) + ' 탈출 성공!', text: '보물 ' + pval(p) + '점을 들고 탈출! (★★ ' + Math.ceil(Math.max(20, s.tv) * 0.25) + '점 · ★★★ ' + Math.ceil(Math.max(20, s.tv) * 0.45) + '점)' };
    }
    if (!esc.length) return { winners: [], title: '아무도 탈출하지 못했어요', text: '화산섬이 모두를 삼켰어요. 다음엔 욕심을 조금 덜!' };
    const best = Math.max(...esc.map((o) => o.v));
    const winners = esc.filter((o) => o.v === best).map((o) => o.k);
    const order = rows.slice().sort((a, c) => (c.p[4] === 1) - (a.p[4] === 1) || c.v - a.v);
    return { winners, title: winners.length > 1 ? '공동 1등!' : '탈출 성공 · ' + best + '점', text: order.map((o) => ((s.nm && s.nm[o.k]) || o.k + 1 + '번') + ' ' + stTxt(o.p)).join(' · ') };
  }

  /* ======================= AI ======================= */
  function project(s, k) {      // cells hot (lava) during the next k phases, assuming the shown cracks (pure, deterministic)
    const G = gen(s.v, s.sd), b = s.b.split(''), hot = new Uint8Array(N);
    for (const i of s.nk) if (walk(b[i])) b[i] = '~';
    let nxt = s.nl.slice();
    for (let ph = 0; ph < k; ph++) {
      for (let i = 0; i < N; i++) { if (b[i] === 'B') b[i] = 'R'; else if (b[i] === 'A') b[i] = 'B'; }
      for (const i of nxt) if (walk(b[i])) b[i] = 'A';
      for (let i = 0; i < N; i++) if (b[i] === 'A' || (ph === 0 && b[i] === 'B')) hot[i] = 1;
      nxt = lavaStep(b.join(''), G.H, G.cr, s.r + 1 + ph, s.sd, [], s.Lr);
    }
    return hot;
  }
  /* best escape slack from cell (turns to spare before some boat leaves) + the distance map (for treasure pull) */
  function escSlack(s, cell, carrying, ap, block, afterThis) {
    const R = reach(s, cell, Infinity, carrying, block);
    let best = -99, cost = 99;
    s.bt.forEach((o) => {
      if (o[0] < 0 || o[2] >= CAP) return;
      const c = R.d[o[0]];
      if (!isFinite(c)) return;
      const turns = Math.ceil(c / ap), left = o[1] - s.r + (afterThis ? 0 : 1);
      best = Math.max(best, left - turns); cost = Math.min(cost, c);
    });
    return { slack: best, cost, d: R.d };
  }

  function ai(s, seat, lv) {
    lv = lv || 2;
    const p = s.p[seat], carry = pval(p), w = pwt(p);
    const T = legalTargets(s, seat), R = T.R;
    const deadly = new Uint8Array(N), crack = new Uint8Array(N), rock = new Uint8Array(N);
    for (const i of s.nl) deadly[i] = 1;
    for (const i of s.nk) crack[i] = 1;
    for (const i of s.nr) rock[i] = 1;
    const careless = lv === 1 && Math.random() < 0.02;
    let block = null;
    if (lv >= 2) { block = lv === 3 ? project(s, 2) : new Uint8Array(N); for (const i of s.nl) block[i] = 1; }
    const margin = lv === 1 ? (Math.random() < 0.06 ? -1 : 0) : lv === 2 ? 1 : 0;
    const decay = lv === 1 ? 0.5 : lv === 2 ? 0.62 : 0.7, potW = lv === 1 ? 0.5 : lv === 2 ? 0.75 : 0.85;
    const boatsNow = T.list.filter((i) => boatAt(s, i) >= 0);
    const others = s.p.filter((q, k) => k !== seat && q[4] === 0).map((q) => q[0]);
    const opts = [];
    for (const i of T.list.concat([p[0]])) {
      if (boatAt(s, i) >= 0) continue;
      if (deadly[i] && !careless) continue;
      const ty = i === p[0] ? 0 : +s.t[i];
      const gain = VAL[ty];
      let c2 = carry + gain, w2 = w + WT[ty];
      let pen = 0;
      const falls = crack[i] && (lv > 1 || Math.random() < 0.7);
      if (falls) { pen += c2 + 1.5; c2 = 0; w2 = 0; }
      if (rock[i] && lv > 1) pen += 2.5;
      const ap2 = apFor(w2, rock[i] ? 1 : 0);
      const E = escSlack(s, i, c2 > 0, ap2, block, true);
      // pull towards treasure further away (discounted by the turns needed); rivals standing closer make it less sure
      let pot = 0, pot2 = 0;
      for (let j = 0; j < N; j++) {
        if (j === i || s.t[j] === '0' || deadly[j] || !isFinite(E.d[j])) continue;
        const turns = Math.max(1, Math.ceil(E.d[j] / ap2));
        let v = VAL[+s.t[j]] * Math.pow(decay, turns - 1);
        if (lv === 3 && others.some((o) => hexDist(o, j) < hexDist(i, j))) v *= 0.6;
        if (v > pot) { pot2 = pot; pot = v; } else if (v > pot2) pot2 = v;
      }
      if (lv === 3) pot += 0.35 * pot2;
      let val = gain + potW * pot - pen - (lv === 3 ? 0.1 : 0.05) * Math.min(E.cost, 30);
      const raw = val;
      if (lv === 1) val += Math.random() * 3;
      else if (lv === 2) val += Math.random() * 0.6;
      if (lv === 3 && block[i]) val -= 0.8;
      opts.push({ i, val, raw, slack: E.slack, feas: E.slack >= margin });
    }
    const feas = opts.filter((o) => o.feas).sort((a, b2) => b2.val - a.val);
    if (boatsNow.length) {
      let thr = lv === 1 ? 1.2 : lv === 2 ? 1.5 : 0.9 + carry * 0.03;
      if (lv === 3 && s.n > 1) {   // score-aware: once nobody else is still on the island, bank a winning haul at once
        const rivals = s.p.filter((q, k) => k !== seat && q[4] === 0).length;
        const top = Math.max(0, ...s.p.filter((q, k) => k !== seat && q[4] === 1).map(pval));
        if (!rivals) thr = carry > top ? 1e9 : carry + 6 <= top ? 0.4 : thr;
        else if (carry > top + 8) thr += 0.6;
      }
      const bestV = feas.length ? Math.max(...feas.map((o) => o.raw)) : -99;
      if (!feas.length || bestV < thr) {
        boatsNow.sort((a, c) => R.d[a] - R.d[c]);
        return { t: 'mv', to: boatsNow[0] };
      }
    }
    if (feas.length) {
      let pick = feas[0];
      if (lv === 1 && feas.length > 1 && Math.random() < 0.2) pick = feas[U.rand(Math.min(4, feas.length))];
      return pick.i === p[0] ? { t: 'stay' } : { t: 'mv', to: pick.i };
    }
    // nothing safe in time: drop the heaviest thing if that buys steps, else head for the boats
    if (lv >= 2 && w >= 2) {
      const wDrop = p[3] > 0 ? w - 2 : w - 1;
      if (apFor(wDrop, 0) > apFor(w, 0)) return { t: 'drop', k: p[3] > 0 ? 3 : 2 };
    }
    let best = null;
    for (const o of opts) if (!best || o.slack > best.slack || (o.slack === best.slack && o.val > best.val)) best = o;
    if (!best) {   // every reachable cell is deadly: pick any
      const any = T.list.filter((i) => boatAt(s, i) < 0);
      if (!any.length) return { t: 'stay' };
      return { t: 'mv', to: any[U.rand(any.length)] };
    }
    return best.i === p[0] ? { t: 'stay' } : { t: 'mv', to: best.i };
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 900 : lv === 3 ? 520 : 700; }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace';
  const DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const TOPC = ['#e6cf94', '#86b85a', '#5f9442', '#8e8068', '#6b5d55', '#4a3a34'];   // top colours by height
  const SIDEC = ['#b39457', '#5d7d3a', '#44682f', '#5f5444', '#463c36', '#2f2522'];
  function mkCanvas(w, h, dpr) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * dpr)); c.height = Math.max(1, Math.round(h * dpr)); const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); return [c, x]; }
  function rr(x, X, Y, W, H, R) { x.beginPath(); x.moveTo(X + R, Y); x.arcTo(X + W, Y, X + W, Y + H, R); x.arcTo(X + W, Y + H, X, Y + H, R); x.arcTo(X, Y + H, X, Y, R); x.arcTo(X, Y, X + W, Y, R); x.closePath(); }
  function hexPath(x, cx, cy, r) { x.beginPath(); for (let k = 0; k < 6; k++) { const a = (k * 60 - 90) * Math.PI / 180; const px = cx + r * Math.cos(a), py = cy + r * Math.sin(a); if (k) x.lineTo(px, py); else x.moveTo(px, py); } x.closePath(); }
  function rng(seed) { let a = seed | 0; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  function drawTreasure(x, ty, cx, cy, s, glow) {
    x.save(); x.translate(cx, cy);
    if (glow) { x.fillStyle = 'rgba(255,220,120,' + (0.18 + 0.12 * glow) + ')'; x.beginPath(); x.arc(0, 0, s * 0.95, 0, 7); x.fill(); }
    x.fillStyle = 'rgba(0,0,0,.28)'; x.beginPath(); x.ellipse(0, s * 0.42, s * 0.55, s * 0.16, 0, 0, 7); x.fill();
    if (ty === 1) {
      for (let k = 0; k < 3; k++) {
        const yy = s * 0.3 - k * s * 0.17;
        x.fillStyle = '#a8761c'; x.beginPath(); x.ellipse(0, yy + s * 0.06, s * 0.42, s * 0.16, 0, 0, 7); x.fill();
        x.fillStyle = '#f2c94c'; x.beginPath(); x.ellipse(0, yy, s * 0.42, s * 0.16, 0, 0, 7); x.fill();
      }
      x.strokeStyle = '#a8761c'; x.lineWidth = 1; x.beginPath(); x.ellipse(0, s * -0.04, s * 0.24, s * 0.08, 0, 0, 7); x.stroke();
    } else if (ty === 2) {
      x.fillStyle = '#7a3fd0'; x.beginPath(); x.moveTo(0, s * 0.42); x.lineTo(s * 0.44, -s * 0.06); x.lineTo(s * 0.26, -s * 0.3); x.lineTo(-s * 0.26, -s * 0.3); x.lineTo(-s * 0.44, -s * 0.06); x.closePath(); x.fill();
      x.fillStyle = '#b58cff'; x.beginPath(); x.moveTo(0, s * 0.42); x.lineTo(-s * 0.44, -s * 0.06); x.lineTo(-s * 0.12, -s * 0.06); x.closePath(); x.fill();
      x.fillStyle = '#d9c4ff'; x.beginPath(); x.moveTo(-s * 0.26, -s * 0.3); x.lineTo(s * 0.26, -s * 0.3); x.lineTo(s * 0.12, -s * 0.06); x.lineTo(-s * 0.12, -s * 0.06); x.closePath(); x.fill();
      x.fillStyle = '#fff'; x.beginPath(); x.arc(-s * 0.1, -s * 0.18, s * 0.05, 0, 7); x.fill();
    } else if (ty === 3) {
      const g = x.createLinearGradient(-s * 0.3, -s * 0.5, s * 0.3, s * 0.4); g.addColorStop(0, '#fff0a8'); g.addColorStop(0.5, '#e8b030'); g.addColorStop(1, '#9a6512');
      x.fillStyle = '#6a4a1a'; x.fillRect(-s * 0.34, s * 0.24, s * 0.68, s * 0.16);
      x.fillStyle = g;
      x.beginPath(); x.moveTo(-s * 0.26, s * 0.26); x.lineTo(-s * 0.18, -s * 0.12); x.lineTo(s * 0.18, -s * 0.12); x.lineTo(s * 0.26, s * 0.26); x.closePath(); x.fill();
      x.beginPath(); x.arc(0, -s * 0.28, s * 0.2, 0, 7); x.fill();
      x.fillStyle = '#7a4f0e'; x.fillRect(-s * 0.1, -s * 0.31, s * 0.06, s * 0.05); x.fillRect(s * 0.04, -s * 0.31, s * 0.06, s * 0.05);
      x.fillStyle = '#e04848'; x.beginPath(); x.arc(0, -s * 0.48, s * 0.06, 0, 7); x.fill();
    }
    x.restore();
  }
  function drawExplorer(x, cx, cy, s, color, o) {
    o = o || {};
    x.save(); x.translate(cx, cy);
    if (o.alpha != null) x.globalAlpha = o.alpha;
    if (!o.swim) { x.fillStyle = 'rgba(0,0,0,.32)'; x.beginPath(); x.ellipse(0, s * 0.42, s * 0.42, s * 0.14, 0, 0, 7); x.fill(); }
    if (o.ring) { x.strokeStyle = o.ring; x.lineWidth = 2.5; x.beginPath(); x.ellipse(0, s * 0.4, s * 0.58, s * 0.2, 0, 0, 7); x.stroke(); }
    if (o.swim) { x.beginPath(); x.rect(-s, -s * 1.2, s * 2, s * 1.32); x.clip(); }
    // body
    x.fillStyle = color; x.strokeStyle = 'rgba(20,10,10,.6)'; x.lineWidth = 1.4;
    x.beginPath(); x.moveTo(-s * 0.32, s * 0.4); x.quadraticCurveTo(-s * 0.36, -s * 0.08, 0, -s * 0.1); x.quadraticCurveTo(s * 0.36, -s * 0.08, s * 0.32, s * 0.4); x.closePath(); x.fill(); x.stroke();
    // backpack loot
    if (o.loot) { x.fillStyle = '#7a4a22'; x.beginPath(); rr(x, s * 0.18, -s * 0.02, s * 0.26, s * 0.32, 4); x.fill(); x.fillStyle = '#f2c94c'; x.beginPath(); x.arc(s * 0.31, -s * 0.04, s * 0.08 + Math.min(3, o.loot) * s * 0.02, 0, 7); x.fill(); }
    // head
    x.fillStyle = '#f1cfa6'; x.beginPath(); x.arc(0, -s * 0.24, s * 0.18, 0, 7); x.fill(); x.stroke();
    // pith helmet
    x.fillStyle = '#d9c08a'; x.beginPath(); x.ellipse(0, -s * 0.31, s * 0.3, s * 0.08, 0, 0, 7); x.fill();
    x.beginPath(); x.ellipse(0, -s * 0.36, s * 0.18, s * 0.15, 0, Math.PI, 0); x.fill();
    x.fillStyle = color; x.fillRect(-s * 0.18, -s * 0.36, s * 0.36, s * 0.05);
    x.restore();
    if (o.swim) {
      x.strokeStyle = 'rgba(220,245,255,.85)'; x.lineWidth = 1.6;
      const ph = o.t || 0;
      x.beginPath(); x.ellipse(cx, cy + s * 0.12, s * (0.42 + 0.05 * Math.sin(ph)), s * 0.12, 0, 0, 7); x.stroke();
    }
    if (o.stun) {
      x.fillStyle = '#ffe27a';
      for (let k = 0; k < 3; k++) { const a = (o.t || 0) * 2 + k * 2.09; star(x, cx + Math.cos(a) * s * 0.36, cy - s * 0.62 + Math.sin(a) * s * 0.1, s * 0.09); }
    }
  }
  function star(x, cx, cy, r) { x.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr2 = k & 1 ? r * 0.45 : r; x.lineTo(cx + Math.cos(a) * rr2, cy + Math.sin(a) * rr2); } x.closePath(); x.fill(); }
  function flame(x, cx, cy, s) {
    x.beginPath(); x.moveTo(cx, cy - s); x.bezierCurveTo(cx + s * 0.7, cy - s * 0.2, cx + s * 0.55, cy + s * 0.5, cx, cy + s * 0.5);
    x.bezierCurveTo(cx - s * 0.55, cy + s * 0.5, cx - s * 0.7, cy - s * 0.2, cx, cy - s); x.fill();
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, Gm = null, LY = null, statics = {}, lavaSpr = null;
    let sel = -1, hover = -1, tg = null, anim = null, busy = false, stopLoop = null, safety = 0, shownSeq = -1, waitSeq = -1, waitUntil = 0, frame = 0;
    const smoke = [];
    const anyLocal = api.players.some((p, i) => api.canAct(i));
    const col = (k) => (api.players[k] && api.players[k].color) || L.COLORS[k % L.COLORS.length];
    const pname = (k) => (api.players[k] && api.players[k].name) || (k + 1) + '번';

    /* --- DOM: bottom bar, hint, drop chooser, spotlight anchors --- */
    const BS = { minHeight: '46px', flex: '1 1 0', minWidth: 0, padding: '6px 4px', fontSize: '14px', whiteSpace: 'nowrap' };
    const hud = L.h('div', { class: 'hud bottom vo-hud', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px' } });
    const dropBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '🎒 버리기', onclick: toggleDrop });
    const stayBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '⏸ 제자리', onclick: onStay });
    const goBtn = L.h('button', { class: 'btn primary', style: Object.assign({}, BS, { flex: '1.5 1 0', fontSize: '15px' }), text: '칸을 고르세요', onclick: onGo });
    hud.append(dropBtn, stayBtn, goBtn);
    const hint = L.h('div', { class: 'vo-hint', style: { position: 'absolute', left: '8px', right: '8px', textAlign: 'center', fontSize: '12.5px', lineHeight: '18px', color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', pointerEvents: 'none' } });
    const dropBox = L.h('div', { class: 'panel', style: { position: 'absolute', left: '10px', right: '10px', display: 'none', gap: '6px', padding: '8px', zIndex: 5, flexDirection: 'column', background: 'var(--surface)', border: '1px solid rgba(227,174,69,.4)', borderRadius: '14px' } });
    if (anyLocal) root.append(hud, dropBox);
    root.append(hint);
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
    const spBoard = spot('vo-board'), spChips = spot('vo-chips'), spMe = spot('vo-me'), spBoat = spot('vo-boat');
    const setBusy = (v) => { if (busy !== v) { busy = v; api.setBusy(v); updateHud(); } };

    function myTurn() { const a = st && actor(st); return a != null && api.canAct(a); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; sel = -1; closeDrop(); api.act(a); updateHud(); }
    function canInput() { return st && !st.end && myTurn() && !locked() && !busy; }

    /* --- layout --- */
    function layout() {
      if (!st) return;
      Gm = gen(st.v, st.sd);
      const W = cv.w, H = cv.h;
      const hudH = anyLocal ? 64 : 0, chipH = 42, infoH = 18, hintH = 20;
      const top = 4 + chipH + 4 + infoH + 2;
      const availW = W - 10, availH = H - top - hintH - hudH - 8;
      // frame: the island plus one ring of sea (boats only ever sit next to the shore)
      let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
      for (let i = 0; i < N; i++) {
        if (!(Gm.H[i] >= 0 || NB[i].some((j) => Gm.H[j] >= 0))) continue;
        x0 = Math.min(x0, CXs[i] - SQ3 / 2); x1 = Math.max(x1, CXs[i] + SQ3 / 2); y0 = Math.min(y0, CYs[i] - 1); y1 = Math.max(y1, CYs[i] + 1);
      }
      y0 -= 0.55; x0 -= 0.1; x1 += 0.1; y1 += 0.15;
      const bwU = x1 - x0, bhU = y1 - y0;
      const R = Math.max(10, Math.min(availW / bwU, availH / bhU, 40));
      const pw = bwU * R, ph = bhU * R;
      const fcH = availH - ph > 110 ? 62 : 0;      // tall screens: forecast card under the hint line
      const px = Math.round((W - pw) / 2), py = Math.round(top + Math.max(0, (availH - ph - (fcH ? fcH + 8 : 0)) / 2));
      const ox = px - x0 * R, oy = py - y0 * R;
      const hintY = Math.round(Math.min(H - hudH - hintH - 2, py + ph + 3));
      LY = { R, ox, oy, bw: pw, bh: ph, chipH, top, hudH, panel: { x: px, y: py, w: pw, h: ph }, hintY, fc: fcH ? { x: px, y: hintY + hintH + 6, w: pw, h: fcH } : null };
      hint.style.top = LY.hintY + 'px';
      dropBox.style.bottom = (hudH + 4) + 'px';
      place(spBoard, px, py, pw, ph);
      place(spChips, 4, 4, W - 8, chipH);
      statics = {};
      buildSprites();
      placeSpots();
    }
    function placeSpots() {
      if (!LY || !st) return;
      const R = LY.R;
      const me = st.p.findIndex((p, k) => api.canAct(k));
      const mi = me >= 0 ? st.p[me][0] : st.p[0][0];
      const c = cpos(mi, st.b);
      place(spMe, c.x - R, c.y - R * 1.2, R * 2, R * 2);
      const bo = st.bt.find((o) => o[0] >= 0);
      if (bo) { const q = cpos(bo[0], st.b); place(spBoat, q.x - R * 1.1, q.y - R * 1.3, R * 2.2, R * 2.3); }
    }
    const liftOf = (ch, h) => (ch === '~' || h < 0 ? 0 : (h + 1) * 0.14);
    function cpos(i, b) {   // top-face centre of cell i on board string b
      const R = LY.R, h = Gm.H[i], ch = b[i];
      return { x: LY.ox + CXs[i] * R, y: LY.oy + CYs[i] * R - liftOf(ch, h) * R };
    }

    function buildSprites() {
      const R = LY.R, dpr = cv.dpr, S = Math.ceil(R * 2.2);
      const mk = (hot) => {
        const [c, x] = mkCanvas(S, S, dpr), m = S / 2, rnd = rng(hot ? 11 : 29);
        hexPath(x, m, m, R * 0.98); x.save(); x.clip();
        const g = x.createRadialGradient(m, m, R * 0.1, m, m, R);
        if (hot) { g.addColorStop(0, '#fff3a0'); g.addColorStop(0.35, '#ffb02e'); g.addColorStop(0.8, '#e2461b'); g.addColorStop(1, '#8a1f0e'); }
        else { g.addColorStop(0, '#ff8a2a'); g.addColorStop(0.5, '#b8361a'); g.addColorStop(1, '#4a140c'); }
        x.fillStyle = g; x.fillRect(0, 0, S, S);
        x.fillStyle = hot ? 'rgba(60,20,10,.55)' : 'rgba(30,12,10,.78)';
        for (let k = 0; k < (hot ? 6 : 10); k++) {
          const px = m + (rnd() - 0.5) * R * 1.5, py = m + (rnd() - 0.5) * R * 1.5, rs = R * (0.12 + rnd() * 0.18);
          x.beginPath(); for (let j = 0; j < 6; j++) { const a = j * 1.05 + rnd() * 0.5, q = rs * (0.6 + rnd() * 0.5); x.lineTo(px + Math.cos(a) * q, py + Math.sin(a) * q); } x.closePath(); x.fill();
        }
        x.restore();
        return c;
      };
      const [gl, gx] = mkCanvas(S * 1.6, S * 1.6, dpr), gm = S * 0.8;
      const gg = gx.createRadialGradient(gm, gm, 0, gm, gm, gm); gg.addColorStop(0, 'rgba(255,140,40,.55)'); gg.addColorStop(1, 'rgba(255,80,20,0)');
      gx.fillStyle = gg; gx.fillRect(0, 0, S * 1.6, S * 1.6);
      lavaSpr = { A: mk(true), B: mk(false), glow: gl, S, GS: S * 1.6 };
    }

    /* static terrain layer for a board string (cached) */
    function staticFor(b) {
      if (statics[b]) return statics[b];
      const keys = Object.keys(statics); if (keys.length > 3) delete statics[keys[0]];
      const W = cv.w, H = cv.h, dpr = cv.dpr, R = LY.R, Hh = Gm.H;
      const [c, x] = mkCanvas(W, H, dpr);
      const bx = LY.panel.x, by = LY.panel.y, bw = LY.panel.w, bh = LY.panel.h;
      x.fillStyle = 'rgba(0,0,0,.4)'; rr(x, bx + 2, by + 4, bw, bh, 16); x.fill();
      const sg = x.createLinearGradient(0, by, 0, by + bh); sg.addColorStop(0, '#14506e'); sg.addColorStop(1, '#0c3550');
      x.fillStyle = sg; rr(x, bx, by, bw, bh, 16); x.fill();
      x.save(); rr(x, bx, by, bw, bh, 16); x.clip();
      const rnd = rng(st.sd & 0xffff);
      x.strokeStyle = 'rgba(160,220,240,.12)'; x.lineWidth = 1.2;
      for (let k = 0; k < 26; k++) { const wx = bx + rnd() * bw, wy = by + rnd() * bh, wl = R * (0.6 + rnd()); x.beginPath(); x.moveTo(wx, wy); x.quadraticCurveTo(wx + wl / 2, wy - 3, wx + wl, wy); x.stroke(); }
      // shallows around the island
      for (let i = 0; i < N; i++) {
        if (b[i] !== '~') continue;
        const near = NB[i].some((j) => b[j] !== '~'), sunk = Hh[i] >= 0;
        if (!near && !sunk) continue;
        const px = LY.ox + CXs[i] * R, py = LY.oy + CYs[i] * R;
        x.fillStyle = sunk ? 'rgba(90,200,200,.28)' : 'rgba(110,210,215,.16)'; hexPath(x, px, py, R * 1.02); x.fill();
        if (sunk) { x.fillStyle = 'rgba(40,60,60,.35)'; const r2 = rng(i * 7 + 1); for (let k = 0; k < 3; k++) { x.beginPath(); x.arc(px + (r2() - 0.5) * R, py + (r2() - 0.5) * R * 0.8, R * 0.1, 0, 7); x.fill(); } }
      }
      // land prisms, back to front
      for (let i = 0; i < N; i++) {
        const ch = b[i];
        if (ch === '~') continue;
        drawPrism(x, i, ch, LY.ox + CXs[i] * R, LY.oy + CYs[i] * R, 1);
      }
      x.restore();
      statics[b] = c;
      return c;
    }
    function drawPrism(x, i, ch, px, py, sc) {
      const R = LY.R * sc, h = Gm.H[i], lift = liftOf(ch, h) * LY.R, ty = py - lift, rh = R * 0.97;
      const v = (k, yy) => { const a = (k * 60 - 90) * Math.PI / 180; return [px + rh * Math.cos(a), yy + rh * Math.sin(a)]; };
      const lava = ch === 'A' || ch === 'B', rock = ch === 'R';
      const side = lava ? '#2c1b17' : rock ? '#2a2526' : SIDEC[Math.min(5, h)];
      // sides: right-down and left-down faces
      const [x1, y1] = v(1, ty), [x2, y2] = v(2, ty), [x3, y3] = v(3, ty), [x4, y4] = v(4, ty);
      x.fillStyle = side;
      x.beginPath(); x.moveTo(x1, y1); x.lineTo(x2, y2); x.lineTo(x2, y2 + lift + R * 0.12); x.lineTo(x1, y1 + lift + R * 0.12); x.closePath(); x.fill();
      x.fillStyle = 'rgba(0,0,0,.22)'; x.fill();
      x.fillStyle = side;
      x.beginPath(); x.moveTo(x2, y2); x.lineTo(x3, y3); x.lineTo(x3, y3 + lift + R * 0.12); x.lineTo(x2, y2 + lift + R * 0.12); x.closePath(); x.fill();
      x.beginPath(); x.moveTo(x3, y3); x.lineTo(x4, y4); x.lineTo(x4, y4 + lift + R * 0.12); x.lineTo(x3, y3 + lift + R * 0.12); x.closePath(); x.fill();
      x.fillStyle = 'rgba(0,0,0,.12)'; x.fill();
      // top face
      const top = lava ? '#3a1d16' : rock ? '#3a3436' : ch === 'X' ? '#4a3a34' : TOPC[Math.min(5, h)];
      hexPath(x, px, ty, rh); x.fillStyle = top; x.fill();
      x.strokeStyle = 'rgba(0,0,0,.25)'; x.lineWidth = 1; x.stroke();
      const r2 = rng(i * 131 + 7);
      if (ch === '.') {
        if (h === 0) { x.fillStyle = 'rgba(150,120,70,.45)'; for (let k = 0; k < 7; k++) { x.beginPath(); x.arc(px + (r2() - 0.5) * R, ty + (r2() - 0.5) * R * 0.9, 0.9, 0, 7); x.fill(); } }
        else if (h === 1) { x.strokeStyle = 'rgba(40,80,20,.55)'; x.lineWidth = 1.1; for (let k = 0; k < 6; k++) { const gx = px + (r2() - 0.5) * R * 1.1, gy = ty + (r2() - 0.5) * R * 0.9; x.beginPath(); x.moveTo(gx, gy); x.lineTo(gx - 1, gy - 3); x.moveTo(gx, gy); x.lineTo(gx + 1.5, gy - 3); x.stroke(); } }
        else if (h === 2) { for (let k = 0; k < 2; k++) { const gx = px + (r2() - 0.5) * R * 0.9, gy = ty + (r2() - 0.4) * R * 0.7, s2 = R * (0.22 + r2() * 0.08); x.fillStyle = '#3a6a28'; x.beginPath(); x.moveTo(gx, gy - s2 * 1.4); x.lineTo(gx + s2, gy + s2 * 0.4); x.lineTo(gx - s2, gy + s2 * 0.4); x.closePath(); x.fill(); x.fillStyle = '#2b5420'; x.beginPath(); x.moveTo(gx, gy - s2 * 1.4); x.lineTo(gx + s2, gy + s2 * 0.4); x.lineTo(gx, gy + s2 * 0.4); x.closePath(); x.fill(); } }
        else if (h === 3) { for (let k = 0; k < 3; k++) { const gx = px + (r2() - 0.5) * R * 1.0, gy = ty + (r2() - 0.5) * R * 0.8; x.fillStyle = '#6e6252'; x.beginPath(); x.ellipse(gx, gy, R * 0.16, R * 0.1, 0, 0, 7); x.fill(); x.fillStyle = '#a69882'; x.beginPath(); x.ellipse(gx - 1, gy - 1.5, R * 0.1, R * 0.05, 0, 0, 7); x.fill(); } }
        else { x.strokeStyle = 'rgba(40,30,30,.45)'; x.lineWidth = 1; for (let k = 0; k < 4; k++) { const gx = px + (r2() - 0.5) * R, gy = ty + (r2() - 0.5) * R * 0.8; x.beginPath(); x.moveTo(gx, gy); x.lineTo(gx + R * 0.25, gy + R * 0.12); x.stroke(); } }
        // highlight on the upper edges
        const [a0, b0] = v(5, ty), [a1, b1] = v(0, ty), [a2, b2] = v(1, ty);
        x.strokeStyle = 'rgba(255,255,230,.22)'; x.lineWidth = 1.2; x.beginPath(); x.moveTo(a0, b0); x.lineTo(a1, b1); x.lineTo(a2, b2); x.stroke();
      } else if (rock) {
        x.strokeStyle = 'rgba(180,60,30,.35)'; x.lineWidth = 1;
        for (let k = 0; k < 3; k++) { let gx = px + (r2() - 0.5) * R, gy = ty + (r2() - 0.5) * R * 0.8; x.beginPath(); x.moveTo(gx, gy); for (let j = 0; j < 3; j++) { gx += (r2() - 0.5) * R * 0.4; gy += (r2() - 0.5) * R * 0.4; x.lineTo(gx, gy); } x.stroke(); }
      } else if (ch === 'X') {
        x.fillStyle = '#2a1a16'; x.beginPath(); x.ellipse(px, ty, rh * 0.72, rh * 0.55, 0, 0, 7); x.fill();
        x.strokeStyle = '#6b5148'; x.lineWidth = 2; x.stroke();
      }
    }

    /* --- drawing --- */
    function draw(now) {
      if (!st || !LY) return;
      now = now || performance.now();
      const W = cv.w, H = cv.h, R = LY.R, sp = L.debug.speed || 1;
      cv.clear();
      // phase animation bookkeeping
      let A = anim, mt = 1, pt = -1;
      if (A) { const e = (now - A.t0) * sp; mt = A.mv ? Math.min(1, e / A.mvDur) : 1; if (A.ph && e > A.mvDur) pt = Math.min(1, (e - A.mvDur) / A.phDur); }
      const phPend = A && A.ph && pt < 0;      // the move is still playing, the phase has not started
      const usePre = A && A.ph && pt < 0.3;
      const b = usePre ? A.pre.pb : st.b;
      const tstr = A && A.ph && pt < 0.45 ? A.pre.pt : st.t;
      ctx.drawImage(staticFor(b), 0, 0, W, H);
      const tsec = now / 1000;
      // sinking cells during the phase
      if (A && A.ph && pt >= 0.3) {
        const k = Math.min(1, (pt - 0.3) / 0.4);
        for (const i of A.ph.sk) {
          if (k < 1) {
            const px = LY.ox + CXs[i] * R, py = LY.oy + CYs[i] * R + k * R * 0.5;
            ctx.save(); ctx.globalAlpha = 1 - k; drawPrism(ctx, i, A.pre.pb[i] === '~' ? '.' : A.pre.pb[i], px, py, 1 - 0.3 * k); ctx.restore();
          }
          const q = cpos(i, '~'.repeat(N));
          ctx.strokeStyle = 'rgba(220,250,255,' + (0.8 * (1 - k)) + ')'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.ellipse(q.x, q.y, R * (0.4 + k * 0.7), R * (0.18 + k * 0.3), 0, 0, 7); ctx.stroke();
        }
      }
      // lava (animated)
      const newLava = A && A.ph && pt >= 0 ? A.ph.nl : null;
      for (let i = 0; i < N; i++) {
        const ch = b[i];
        if (ch !== 'A' && ch !== 'B' && ch !== 'X') continue;
        let al = 1;
        if (newLava && !usePre && newLava.indexOf(i) >= 0) {
          al = Math.max(0, Math.min(1, (pt - 0.38) / 0.45));
          if (al < 1) { const pc = A.pre.pb[i]; ctx.save(); ctx.globalAlpha = 1 - al; drawPrism(ctx, i, pc === '~' ? '.' : pc, LY.ox + CXs[i] * R, LY.oy + CYs[i] * R, 1); ctx.restore(); }
        }
        const q = cpos(i, b), pul = 0.5 + 0.5 * Math.sin(tsec * 2.2 + i * 1.7);
        if (ch === 'X') {
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = 0.6 + 0.4 * pul; ctx.drawImage(lavaSpr.glow, q.x - lavaSpr.GS / 2, q.y - lavaSpr.GS / 2, lavaSpr.GS, lavaSpr.GS);
          ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
          const g = ctx.createRadialGradient(q.x, q.y, 1, q.x, q.y, R * 0.5);
          g.addColorStop(0, '#fff2a0'); g.addColorStop(0.5, '#ff9a2a'); g.addColorStop(1, 'rgba(200,50,20,.2)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(q.x, q.y, R * 0.5, R * 0.36, 0, 0, 7); ctx.fill();
          continue;
        }
        ctx.globalAlpha = al * (ch === 'A' ? 0.85 + 0.15 * pul : 0.8 + 0.2 * pul);
        ctx.drawImage(ch === 'A' ? lavaSpr.A : lavaSpr.B, q.x - lavaSpr.S / 2, q.y - lavaSpr.S / 2, lavaSpr.S, lavaSpr.S);
        if (ch === 'A') { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = al * (0.25 + 0.3 * pul); ctx.drawImage(lavaSpr.glow, q.x - lavaSpr.GS / 2, q.y - lavaSpr.GS / 2, lavaSpr.GS, lavaSpr.GS); ctx.globalCompositeOperation = 'source-over'; }
        ctx.globalAlpha = 1;
      }
      // previews of the coming volcano phase
      const pv = phPend ? { nl: A.ph.nl, nk: A.ph.sk, nr: A.ph.rk } : (A && A.ph && pt < 1 ? null : { nl: st.nl, nk: st.nk, nr: st.nr });
      if (pv && !st.end) {
        const pul = 0.5 + 0.5 * Math.sin(tsec * 4);
        for (const i of pv.nl) {
          const q = cpos(i, b);
          hexPath(ctx, q.x, q.y, R * 0.9); ctx.fillStyle = 'rgba(255,110,30,' + (0.22 + 0.22 * pul) + ')'; ctx.fill();
          ctx.setLineDash([4, 3]); ctx.strokeStyle = 'rgba(255,170,60,.95)'; ctx.lineWidth = 2; ctx.stroke(); ctx.setLineDash([]);
          ctx.fillStyle = 'rgba(255,200,80,.95)'; flame(ctx, q.x + R * 0.42, q.y - R * 0.3, R * 0.2);
        }
        for (const i of pv.nk) {
          const q = cpos(i, b), r2 = rng(i * 17 + 3);
          hexPath(ctx, q.x, q.y, R * 0.9); ctx.fillStyle = 'rgba(10,40,70,' + (0.25 + 0.15 * pul) + ')'; ctx.fill();
          ctx.strokeStyle = 'rgba(255,225,140,' + (0.65 + 0.3 * pul) + ')'; ctx.lineWidth = 1.8;
          for (let k = 0; k < 2; k++) { let gx = q.x + (r2() - 0.5) * R * 0.8, gy = q.y - R * 0.5; ctx.beginPath(); ctx.moveTo(gx, gy); for (let j = 0; j < 4; j++) { gx += (r2() - 0.5) * R * 0.5; gy += R * 0.25; ctx.lineTo(gx, gy); } ctx.stroke(); }
        }
        for (const i of pv.nr) {
          const q = cpos(i, b), rot = tsec * 1.5;
          ctx.strokeStyle = 'rgba(255,70,60,' + (0.65 + 0.35 * pul) + ')'; ctx.lineWidth = 2;
          ctx.setLineDash([5, 4]); ctx.lineDashOffset = -rot * 10; ctx.beginPath(); ctx.arc(q.x, q.y, R * 0.6, 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
          ctx.beginPath(); ctx.moveTo(q.x - R * 0.3, q.y); ctx.lineTo(q.x + R * 0.3, q.y); ctx.moveTo(q.x, q.y - R * 0.3); ctx.lineTo(q.x, q.y + R * 0.3); ctx.stroke();
        }
      }
      // reachable cells + selection path (my turn)
      const showReach = tg && !A && canInput();
      if (showReach) {
        for (const i of tg.list) {
          const q = cpos(i, b), isBoat = boatAt(st, i) >= 0;
          if (isBoat) { ctx.strokeStyle = 'rgba(255,230,140,' + (0.6 + 0.4 * Math.sin(tsec * 5)) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(q.x, q.y + R * 0.15, R * 0.85, R * 0.42, 0, 0, 7); ctx.stroke(); continue; }
          const sea = b[i] === '~';
          if (sea) ctx.setLineDash([3, 4]);
          hexPath(ctx, q.x, q.y, R * 0.86); ctx.strokeStyle = i === hover ? 'rgba(255,240,200,.95)' : sea ? 'rgba(170,225,255,.45)' : 'rgba(255,250,235,.55)'; ctx.lineWidth = i === hover ? 2.4 : 1.4; ctx.stroke();
          ctx.setLineDash([]);
          if (!sea) { ctx.fillStyle = 'rgba(255,250,235,.75)'; ctx.beginPath(); ctx.arc(q.x, q.y + R * 0.35, R * 0.07, 0, 7); ctx.fill(); }
        }
        if (sel >= 0) {
          const path = pathTo(tg.R.pv, st.p[st.cur][0], sel);
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.setLineDash([6, 5]); ctx.lineDashOffset = -tsec * 20;
          ctx.beginPath(); path.forEach((c, k) => { const q = cpos(c, b); if (k) ctx.lineTo(q.x, q.y + R * 0.2); else ctx.moveTo(q.x, q.y + R * 0.2); }); ctx.stroke();
          ctx.setLineDash([]); ctx.lineDashOffset = 0;
          const q = cpos(sel, b);
          hexPath(ctx, q.x, q.y, R * 0.9); ctx.strokeStyle = '#ffd36a'; ctx.lineWidth = 3.2; ctx.stroke();
        }
      }
      // treasures
      for (let i = 0; i < N; i++) {
        let ty = +tstr[i];
        if (A && A.mv && mt < 1 && i === A.mv.to && A.mv.pk) ty = A.mv.pk;
        if (A && A.drop && i === A.drop.x && (now - A.t0) * sp < 300) ty = 0;
        if (!ty || b[i] === '~') continue;
        const q = cpos(i, b);
        drawTreasure(ctx, ty, q.x, q.y - R * 0.05, R * 0.62, ty === 3 ? 0.5 + 0.5 * Math.sin(tsec * 3 + i) : 0);
      }
      // boats
      const btx = A && A.ph && pt < 0.6 ? A.pre.pbt : st.bt.map((o) => o[0]);
      st.bt.forEach((o, k) => {
        let x0 = btx[k];
        if (x0 < 0) return;
        let gone = 0;
        if (A && A.ph && A.ph.gone.indexOf(k) >= 0) { if (pt < 0.5) gone = 0; else gone = (pt - 0.5) / 0.5; if (pt >= 1) return; }
        const q = cpos(x0, '~'.repeat(N));
        const dx = (CXs[x0] - CX0), dy = (CYs[x0] - CY0), dl = Math.hypot(dx, dy) || 1;
        const bx = q.x + dx / dl * gone * R * 3, by = q.y + dy / dl * gone * R * 3 + Math.sin(tsec * 2 + k) * 1.5;
        drawBoat(bx, by, k, o, 1 - gone);
      });
      // explorers
      const swimOf = (i) => b[i] === '~';
      st.p.forEach((p, k) => {
        let x = p[0], status = p[4];
        if (status === 1) return;   // drawn on their boat
        if (status === 2) { if (!(A && A.ph && A.ph.out.indexOf(k) >= 0 && pt < 0.55)) return; }
        let q;
        if (A && A.mv && A.mv.s === k && mt < 1) {
          const path = A.mv.pa, f = mt * (path.length - 1), j = Math.min(path.length - 2, Math.floor(f)), u = f - j;
          const a0 = cpos(path[j], b), a1 = cpos(path[j + 1], b);
          q = { x: a0.x + (a1.x - a0.x) * u, y: a0.y + (a1.y - a0.y) * u - Math.sin(u * Math.PI) * R * 0.35 };
        } else q = cpos(x, b);
        const mine = st.cur === k && !st.end && !A;
        const stun = p[5] && !(A && A.ph && pt < 0.3);
        drawExplorer(ctx, q.x, q.y - R * 0.12, R * 0.95, col(k), { swim: swimOf(x) && !(A && A.mv && A.mv.s === k && mt < 1), loot: pval(p) > 0 ? Math.min(3, Math.ceil(pval(p) / 5)) : 0, ring: mine ? '#ffd36a' : null, stun, t: tsec * 3 });
      });
      // phase effects: rocks, lost explorers
      if (A && A.ph && pt >= 0 && pt < 1) {
        const cq = cpos(Gm.cr, b);
        for (const i of A.ph.rk) {
          const q = cpos(i, st.b), u = Math.min(1, pt / 0.3);
          if (u < 1) {
            const xx = cq.x + (q.x - cq.x) * u, yy = cq.y + (q.y - cq.y) * u - Math.sin(u * Math.PI) * R * 3;
            ctx.fillStyle = '#3a2a26'; ctx.beginPath(); ctx.arc(xx, yy, R * 0.22, 0, 7); ctx.fill();
            ctx.fillStyle = 'rgba(255,140,40,.7)'; ctx.beginPath(); ctx.arc(xx, yy, R * 0.12, 0, 7); ctx.fill();
          } else if (pt < 0.55) {
            const k2 = (pt - 0.3) / 0.25;
            ctx.strokeStyle = 'rgba(255,190,90,' + (1 - k2) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(q.x, q.y, R * (0.3 + k2 * 0.6), 0, 7); ctx.stroke();
          }
        }
        for (const k of A.ph.out) {
          if (pt < 0.4) continue;
          const q = cpos(st.p[k][0], st.b), k2 = Math.min(1, (pt - 0.4) / 0.4);
          ctx.fillStyle = 'rgba(255,' + Math.round(200 - 120 * k2) + ',40,' + (1 - k2) + ')';
          for (let j = 0; j < 5; j++) flame(ctx, q.x + (j - 2) * R * 0.18, q.y - R * 0.3 - k2 * R * 0.6 - (j % 2) * R * 0.2, R * 0.22);
        }
      }
      // smoke from the crater
      drawSmoke(now, b);
      drawChips();
      drawInfo();
      if (LY.fc) drawForecast();
    }
    function drawForecast() {
      const F = LY.fc, x0 = F.x, y0 = F.y;
      ctx.fillStyle = 'rgba(255,255,255,.05)'; rr(ctx, x0, y0, F.w, F.h, 12); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.25)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      ctx.fillStyle = '#e3ae45'; ctx.font = '700 13px ' + FONT;
      if (st.end) { ctx.fillText('🌋 화산섬이 바다에 잠겨 가요…', x0 + 12, y0 + F.h / 2); return; }
      ctx.fillText('🌋 다음 화산 차례', x0 + 12, y0 + 18);
      const more = moversLeft(st);
      ctx.textAlign = 'right'; ctx.fillStyle = '#ab9fb8'; ctx.font = '600 12px ' + FONT;
      ctx.fillText(more ? more + 1 + '명 더 움직인 뒤' : '이번 차례가 끝나면', x0 + F.w - 12, y0 + 18);
      ctx.textAlign = 'left'; ctx.font = '600 12.5px ' + FONT;
      let x = x0 + 12; const y = y0 + 44;
      const item = (icon, txt, c) => { ctx.fillStyle = c; ctx.fillText(icon, x, y); x += ctx.measureText(icon).width + 3; ctx.fillStyle = '#f2e9d8'; ctx.fillText(txt, x, y); x += ctx.measureText(txt).width + 12; };
      item('용암', ' ' + st.nl.length + '칸', '#ff9a40');
      item('붕괴', ' ' + st.nk.length + '칸', '#ffe18c');
      item('화산탄', ' ' + st.nr.length + '개', '#ff6a5a');
      const bs = st.bt.filter((o) => o[0] >= 0).map((o) => o[1] - st.r + 1).sort((a, c) => a - c);
      ctx.textAlign = 'right'; ctx.fillStyle = '#9fd9e8';
      ctx.fillText('⛵ ' + (bs.length ? bs.join(' · ') : '없음'), x0 + F.w - 12, y);
    }
    function drawBoat(x, y, k, o, alpha) {
      const R = LY.R;
      ctx.save(); ctx.globalAlpha = Math.max(0, alpha);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(x, y + R * 0.32, R * 0.7, R * 0.16, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#7a4a26'; ctx.beginPath(); ctx.moveTo(x - R * 0.72, y + R * 0.02); ctx.lineTo(x + R * 0.72, y + R * 0.02); ctx.lineTo(x + R * 0.48, y + R * 0.32); ctx.lineTo(x - R * 0.48, y + R * 0.32); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#a06a3a'; ctx.fillRect(x - R * 0.72, y - R * 0.02, R * 1.44, R * 0.07);
      ctx.strokeStyle = '#4a2c16'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - R * 0.95); ctx.stroke();
      ctx.fillStyle = '#f4ecd8'; ctx.beginPath(); ctx.moveTo(x + 1.5, y - R * 0.92); ctx.lineTo(x + R * 0.55, y - R * 0.12); ctx.lineTo(x + 1.5, y - R * 0.12); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#e04848'; ctx.beginPath(); ctx.moveTo(x, y - R * 0.95); ctx.lineTo(x - R * 0.28, y - R * 0.86); ctx.lineTo(x, y - R * 0.78); ctx.closePath(); ctx.fill();
      // passengers
      let n = 0;
      st.p.forEach((p, kk) => { if (p[4] === 1 && p[0] === (o[0] >= 0 ? o[0] : -9)) { ctx.fillStyle = col(kk); ctx.beginPath(); ctx.arc(x - R * 0.42 + n * R * 0.24, y - R * 0.08, R * 0.13, 0, 7); ctx.fill(); ctx.fillStyle = '#d9c08a'; ctx.beginPath(); ctx.arc(x - R * 0.42 + n * R * 0.24, y - R * 0.17, R * 0.09, Math.PI, 0); ctx.fill(); n++; } });
      // departure badge: turns left
      const left = o[1] - st.r + 1;
      if (o[0] >= 0 && !st.end) {
        const bx = x - R * 0.55, by = y - R * 0.7, last = left <= 1;
        ctx.fillStyle = last ? '#ee6a55' : '#f4ecd8'; ctx.beginPath(); ctx.arc(bx, by, R * 0.32, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.fillStyle = last ? '#fff' : '#3a2a1a'; ctx.font = '700 ' + Math.round(R * 0.4) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(String(Math.max(0, left)), bx, by + 1);
        // seats
        for (let s2 = 0; s2 < CAP; s2++) { ctx.fillStyle = s2 < o[2] ? '#ee6a55' : 'rgba(255,255,255,.85)'; ctx.beginPath(); ctx.arc(x + R * 0.18 + s2 * R * 0.2, y + R * 0.17, R * 0.06, 0, 7); ctx.fill(); }
      }
      ctx.restore();
    }
    function drawSmoke(now, b) {
      const R = LY.R, q = cpos(Gm.cr, b), sp = L.debug.speed || 1;
      const dt = Math.min(0.05, (now - (drawSmoke.t || now)) / 1000) * Math.min(sp, 3); drawSmoke.t = now;
      if (smoke.length < 16 && Math.random() < 0.25) smoke.push({ x: q.x + (Math.random() - 0.5) * R * 0.4, y: q.y - R * 0.2, r: R * 0.18, a: 0.5, vx: (Math.random() - 0.3) * R * 0.25, vy: -R * (0.7 + Math.random() * 0.4) });
      for (let k = smoke.length - 1; k >= 0; k--) {
        const s2 = smoke[k]; s2.x += s2.vx * dt; s2.y += s2.vy * dt; s2.r += R * 0.35 * dt; s2.a -= 0.16 * dt;
        if (s2.a <= 0 || s2.y < LY.panel.y - R * 0.6) { smoke.splice(k, 1); continue; }
        ctx.fillStyle = 'rgba(70,62,66,' + s2.a.toFixed(3) + ')'; ctx.beginPath(); ctx.arc(s2.x, s2.y, s2.r, 0, 7); ctx.fill();
      }
    }
    function drawChips() {
      const W = cv.w, n = st.n, gap = 5, cw = (W - 8 - gap * (n - 1)) / n, ch = LY.chipH;
      for (let k = 0; k < n; k++) {
        const p = st.p[k], x0 = 4 + k * (cw + gap), y0 = 4, on = st.cur === k && !st.end;
        ctx.fillStyle = on ? 'rgba(227,174,69,.2)' : 'rgba(255,255,255,.06)'; rr(ctx, x0, y0, cw, ch, 10); ctx.fill();
        ctx.strokeStyle = on ? '#e3ae45' : 'rgba(255,255,255,.12)'; ctx.lineWidth = on ? 2 : 1; ctx.stroke();
        ctx.fillStyle = col(k); ctx.beginPath(); ctx.arc(x0 + 11, y0 + 13, 5, 0, 7); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.font = '600 12px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        let nm = pname(k); const maxw = cw - 24;
        while (nm.length > 1 && ctx.measureText(nm).width > maxw) nm = nm.slice(0, -1);
        ctx.fillText(nm, x0 + 20, y0 + 13);
        let line;
        if (p[4] === 1) line = '⛵ 탈출 ' + pval(p) + '점';
        else if (p[4] === 2) line = '🔥 탈락';
        else if (p[4] === 3) line = '🏝 남겨짐';
        else line = '💰' + pval(p) + ' 👣' + apOf(p) + (p[5] ? ' 💫' : '') + (st.b[p[0]] === '~' ? ' 🌊' : '');
        ctx.fillStyle = p[4] === 1 ? '#9fe3b8' : p[4] >= 2 ? '#f0a090' : '#e3ae45'; ctx.font = '600 11.5px ' + FONT;
        let ln = line; while (ln.length > 2 && ctx.measureText(ln).width > cw - 12) ln = ln.slice(0, -1);
        ctx.fillText(ln, x0 + 7, y0 + 30);
      }
    }
    function drawInfo() {
      const W = cv.w, y = 4 + LY.chipH + 4 + 9;
      ctx.font = '600 11.5px ' + FONT; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      ctx.fillStyle = '#ab9fb8';
      const shape = SHAPES[st.v].n;
      ctx.fillText(shape + ' · 라운드 ' + Math.min(st.r, st.Lr) + '/' + st.Lr, 8, y);
      // legend (right)
      ctx.textAlign = 'right';
      let x = W - 8;
      const item = (label, fn) => { ctx.fillStyle = '#ab9fb8'; ctx.fillText(label, x, y); x -= ctx.measureText(label).width + 4; fn(x - 5); x -= 16; };
      item('화산탄', (cx) => { ctx.strokeStyle = '#ff5a4a'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(cx, y, 5, 0, 7); ctx.stroke(); });
      item('붕괴', (cx) => { ctx.strokeStyle = '#ffe18c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(cx - 2, y - 6); ctx.lineTo(cx + 2, y - 2); ctx.lineTo(cx - 1, y + 2); ctx.lineTo(cx + 2, y + 6); ctx.stroke(); });
      item('용암', (cx) => { ctx.fillStyle = '#ff8a2a'; flame(ctx, cx, y + 1, 6); });
      ctx.fillStyle = '#ab9fb8'; ctx.fillText('다음:', x, y);
    }

    /* --- hud --- */
    function updateHud() {
      if (!st) return;
      const my = canInput();
      tg = my ? legalTargets(st, st.cur) : null;
      if (sel >= 0 && (!tg || tg.list.indexOf(sel) < 0)) sel = -1;
      const p = st.p[st.cur];
      hud.style.display = anyLocal && !st.end && myTurn() ? '' : 'none';
      dropBtn.disabled = !my || pval(p) === 0;
      stayBtn.disabled = !my;
      goBtn.disabled = !my || sel < 0;
      goBtn.textContent = sel >= 0 ? (boatAt(st, sel) >= 0 ? '⛵ 배에 타기!' : '▶ 여기로 이동') : '칸을 고르세요';
      if (!my) closeDrop();
      let h = '';
      if (st.end) { const r = result(st); h = r.title; }
      else if (myTurn()) {
        if (sel >= 0) {
          const bi = boatAt(st, sel);
          if (bi >= 0) h = '⛵ 탈출! 지금 가진 ' + pval(p) + '점을 지켜요 (탭 한 번 더 = 확정)';
          else {
            const ty = +st.t[sel], parts = [];
            if (ty) parts.push(TNAME[ty] + ' +' + VAL[ty] + '점' + (WT[ty] ? ' (무거움)' : ''));
            else parts.push('보물 없음');
            const w2 = pwt(p) + WT[ty]; parts.push('다음 걸음 ' + apFor(w2, st.nr.indexOf(sel) >= 0));
            if (st.nl.indexOf(sel) >= 0) parts.push('⚠ 용암이 덮쳐요!');
            else if (st.nk.indexOf(sel) >= 0) parts.push('⚠ 무너져요(보물 잃음)');
            else if (st.nr.indexOf(sel) >= 0) parts.push('⚠ 화산탄(기절)');
            h = parts.join(' · ');
          }
        } else if (st.b[p[0]] === '~') h = '🌊 헤엄치는 중 · 걸음 ' + apOf(p) + ' (바다 1칸 = 2걸음)';
        else h = '걸음 ' + apOf(p) + (p[5] ? ' (기절 −2)' : '') + ' · 밝은 테두리 칸을 탭' + (moversLeft(st) ? ' · 오르막은 2걸음' : ' · 내 차례 뒤 화산!');
      } else {
        const P = api.players[st.cur] || {};
        h = pname(st.cur) + (P.ai ? ' 생각 중…' : ' 차례');
        const more = moversLeft(st);
        h += more ? ' · 화산까지 ' + (more + 1) + '명' : ' · 이 차례 뒤 화산이 깨어나요';
      }
      hint.textContent = h;
    }
    function toggleDrop() {
      if (!canInput()) return;
      if (dropBox.style.display !== 'none') { closeDrop(); return; }
      const p = st.p[st.cur];
      dropBox.innerHTML = '';
      dropBox.append(L.h('div', { class: 'muted', style: { fontSize: '12.5px', textAlign: 'center' }, text: '무엇을 버릴까요? 버리면 걸음이 늘 수 있어요' }));
      const row = L.h('div', { style: { display: 'flex', gap: '6px' } });
      for (let ty = 3; ty >= 1; ty--) {
        if (!p[ty]) continue;
        const ap2 = apFor(pwt(p) - WT[ty], p[5]);
        row.append(L.h('button', { class: 'btn sm', style: { flex: '1 1 0', minHeight: '46px', fontSize: '13px', padding: '4px' },
          text: TNAME[ty] + ' ×' + p[ty] + (ap2 > apOf(p) ? ' (걸음 ' + ap2 + ')' : ''), onclick: () => { api.sfx('click'); api.buzz(10); send({ t: 'drop', k: ty }); } }));
      }
      row.append(L.h('button', { class: 'btn sm ghost', style: { flex: '0 0 auto', minHeight: '46px', minWidth: '56px' }, text: '닫기', onclick: closeDrop }));
      dropBox.append(row);
      dropBox.style.display = 'flex';
      api.sfx('tick');
    }
    function closeDrop() { dropBox.style.display = 'none'; }
    function onStay() { if (!canInput()) return; api.sfx('click'); api.buzz(10); send({ t: 'stay' }); }
    function onGo() { if (!canInput() || sel < 0) return; api.buzz(14); send({ t: 'mv', to: sel }); }

    /* --- input --- */
    function hitCell(x, y) {
      if (!LY) return -1;
      let best = -1, bd = LY.R * 0.95;
      for (let i = 0; i < N; i++) { const q = cpos(i, st.b), d = Math.hypot(q.x - x, q.y - y); if (d < bd) { bd = d; best = i; } }
      return best;
    }
    function nearestTarget(x, y) {   // forgiving tap: snap to the closest reachable cell within ~1.1 R
      if (!tg) return -1;
      let best = -1, bd = LY.R * 1.15;
      for (const i of tg.list) { const q = cpos(i, st.b), d = Math.hypot(q.x - x, q.y - y); if (d < bd) { bd = d; best = i; } }
      return best;
    }
    function onDown(e) {
      if (!st || !LY) return;
      const q = cv.local(e);
      if (!canInput() || anim) { return; }
      closeDrop();
      const i = nearestTarget(q.x, q.y);
      if (i < 0) {
        const c = hitCell(q.x, q.y);
        if (c >= 0 && c !== st.p[st.cur][0] && tg) { api.toast(occupied(st, c, st.cur) ? '다른 탐험가가 있는 칸이에요' : '이번 차례엔 거기까지 못 가요'); api.buzz(20); }
        sel = -1; updateHud(); return;
      }
      if (i === sel) { onGo(); return; }
      sel = i; api.sfx('tick'); api.buzz(6);
      if (st.nl.indexOf(i) >= 0) api.buzz(30);
      updateHud();
    }
    function onMove(e) {
      if (!st || !LY || e.pointerType !== 'mouse') return;
      const q = cv.local(e), i = canInput() ? nearestTarget(q.x, q.y) : -1;
      hover = i;
    }
    function onLeave() { hover = -1; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerleave', onLeave);
    cv.onresize = () => { if (st) { layout(); updateHud(); } };

    /* --- animation --- */
    function startAnim(next) {
      const sp = L.debug.speed || 1, lm = next.last;
      const A = { t0: performance.now(), mv: null, mvDur: 0, ph: null, phDur: 0, drop: null };
      if (lm.k === 'd') { A.drop = lm; A.mvDur = 300; api.sfx(lm.pl ? 'thud' : 'whoosh'); api.toast(TNAME[lm.ty] + (lm.pl ? '을(를) 내려놨어요' : '을(를) 버렸어요')); }
      if (lm.k === 'm' && lm.pa && lm.pa.length > 1) { A.mv = { s: lm.s, pa: lm.pa, to: lm.pa[lm.pa.length - 1], pk: lm.pk }; A.mvDur = 150 * (lm.pa.length - 1) + 80; }
      if (lm.ph) { A.ph = lm.ph; A.pre = lm.pre; A.phDur = 1500; }
      if (!A.mvDur && !A.phDur) return;
      A.end = (A.mvDur + A.phDur) / sp;
      A.fx = { arrive: false, rocks: false, lava: false };
      anim = A;
      setBusy(true);
      clearTimeout(safety);
      safety = setTimeout(finishAnim, A.end + 1500);
    }
    function finishAnim() { anim = null; clearTimeout(safety); setBusy(false); placeSpots(); updateHud(); }
    function animEvents(now) {
      const A = anim; if (!A) return;
      const sp = L.debug.speed || 1, e = (now - A.t0) * sp;
      if (A.mv && !A.fx.arrive && e >= A.mvDur) {
        A.fx.arrive = true;
        const lm = st.last;
        if (lm && lm.bo >= 0) { api.sfx('win'); api.buzz(30); api.toast(pname(lm.s) + ' 탈출 성공! ⛵ ' + pval(st.p[lm.s]) + '점'); }
        else if (A.mv.pk) { api.sfx('chip'); api.buzz(12); if (A.mv.pk === 3) api.toast(pname(A.mv.s) + ': 황금 우상! +6'); }
        else api.sfx('tick');
      }
      if (A.ph) {
        const pt = (e - A.mvDur) / A.phDur;
        if (pt >= 0 && !A.fx.start) { A.fx.start = true; if (A.ph.rk.length) api.sfx('whoosh'); }
        if (pt >= 0.3 && !A.fx.rocks) {
          A.fx.rocks = true;
          if (A.ph.rk.length) { api.sfx('hit'); api.buzz(20); }
          if (A.ph.sk.length) api.sfx('bounce');
          for (const k of A.ph.hit) api.toast(pname(k) + ' 화산탄에 맞아 기절! 💫');
          for (const k of A.ph.fell) api.toast(pname(k) + ' 땅이 무너져 바다로! 🌊');
        }
        if (pt >= 0.45 && !A.fx.lava) {
          A.fx.lava = true;
          if (A.ph.nl.length) api.sfx('thud');
          for (const k of A.ph.out) { api.toast(pname(k) + ' 용암에 갇혔어요! 🔥'); api.sfx('lose'); api.buzz(60); }
          for (const k of A.ph.gone) api.toast((k + 1) + '번 배가 떠났어요 ⛵');
        }
      }
      if (e >= A.mvDur + A.phDur) finishAnim();
    }
    stopLoop = U.loop((dt, now) => {
      frame++;
      if (anim) animEvents(now);
      if (!anim && (frame & 1)) return;   // idle: ~30 fps is plenty for smoke and glow
      draw(now);
    });

    return {
      update(next, prev) {
        const relayout = !st || st.v !== next.v || st.sd !== next.sd;
        const fresh = prev && prev !== next && next.seq !== shownSeq && next.last && next.last.id === next.seq;
        st = next;
        if (relayout) layout();
        if (fresh) { sel = -1; startAnim(next); }
        if (!prev) sel = -1;
        shownSeq = next.seq;
        if (!anim) placeSpots();
        updateHud();
        draw();
      },
      destroy() {
        if (stopLoop) stopLoop(); stopLoop = null;
        clearTimeout(safety); setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerleave', onLeave);
        cv.destroy(); hud.remove(); hint.remove(); dropBox.remove(); spBoard.remove(); spChips.remove(); spMe.remove(); spBoat.remove();
      },
    };
  }

  L.register({
    id: 'volcano', name: '화산섬 탈출', tag: '보물 챙겨 탈출', cat: '보드',
    icon: '<path d="M6 46l14-24h4l4-6 4 6h4l14 24z" fill="currentColor"/><path d="M24 22l4-6 4 6-2 6-2-3-2 3z" fill="#000" opacity=".45"/><circle cx="24" cy="10" r="3.5" fill="currentColor" opacity=".7"/><circle cx="31" cy="7" r="4.5" fill="currentColor" opacity=".55"/><path d="M4 50c4-3 8 3 12 0s8 3 12 0 8 3 12 0 8 3 12 0" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    tint: '#7a2a18',
    blurb: '화산이 터지기 시작한 섬! 육각 섬을 돌아다니며 보물을 챙기고, 용암과 무너지는 땅을 피해 떠나기 전의 구조선에 올라타요. 탈출한 사람의 보물만 점수!',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 700,
    options: [
      { id: 'shape', label: '섬 모양', choices: [{ v: 'r', label: '무작위' }].concat(SHAPES.map((o, k) => ({ v: String(k), label: o.n }))), def: 'r' },
      { id: 'len', label: '배 출발', choices: [{ v: 's', label: '빨리 (5·7·9)' }, { v: 'm', label: '보통 (6·9·12)' }, { v: 'l', label: '늦게 (8·11·14)' }], def: 'm' },
    ],
    quick: [
      '화산섬에서 보물을 줍고, 배가 떠나기 전에 배 칸으로 들어가 탈출해요.',
      '내 차례: 걸음 수(기본 4) 안에서 칸 하나를 골라 이동 → 그 칸의 보물을 저절로 주워요. 모두 움직이면 화산이 깨어나요.',
      '탈출한 사람 중 보물 점수가 가장 높은 사람이 승리! 용암에 갇히거나 배를 놓치면 0점.',
    ],
    rules: [
      { h: '목표', p: [
        '화산이 터지기 시작한 섬이에요. 탐험가가 되어 보물을 챙기고 구조선을 타고 탈출해요.',
        '점수는 배에 탄 사람이 들고 있던 보물만 쳐요. 욕심을 부리면 점수가 커지지만, 너무 늦으면 섬에 갇혀요!'] },
      { h: '차례에 할 일', p: [
        '걸음 수 안에서 갈 수 있는 칸이 밝은 테두리로 보여요. 칸을 탭하면 길이 보이고, 한 번 더 탭(또는 「여기로 이동」)하면 이동해요.',
        '걸음: 기본 4. 오르막 칸은 2걸음. 바다 칸은 헤엄 2걸음(보물을 든 채로는 바다에 못 들어가요).',
        '도착한 칸에 보물이 있으면 저절로 주워요. 지나가기만 한 칸의 보물은 안 주워요.',
        '「⏸ 제자리」로 움직이지 않을 수도 있고, 「🎒 버리기」로 무거운 보물을 내려놓을 수 있어요(버려도 차례는 계속돼요).',
        '다른 탐험가가 있는 칸은 지나갈 수는 있지만 멈출 수는 없어요.'] },
      { h: '보물과 무게', p: [
        '🪙 금화 1점(무게 없음) · 💎 보석 3점(무게 1) · 🗿 황금 우상 6점(무게 2). 좋은 보물은 화산 가까운 높은 곳에 많아요.',
        '무게 2마다 걸음이 1 줄어요(최소 1). 예) 우상 1개 = 걸음 3, 우상 2개 = 걸음 2.'] },
      { h: '화산 차례 (모두 한 번씩 움직인 뒤)', p: [
        '① 금 간 칸(노란 금)이 바다로 무너져요. 그 칸에 있던 사람은 바다에 빠져 들고 있던 보물을 모두 잃어요(헤엄쳐서 다시 올라올 수 있어요).',
        '② 용암이 비탈을 따라 한 칸씩 흘러 내려가고, 분화구에서 새 용암이 넘쳐요. 주황 빛 칸이 다음에 용암이 될 칸이에요. 그 칸에 있으면 탈락!',
        '③ 빨간 과녁에 화산탄이 떨어져요. 맞으면 기절해서 다음 차례 걸음 −2. 빈 땅에 떨어진 화산탄은 보석(흑요석)이 돼요.',
        '용암은 두 번의 화산 차례 동안 뜨겁고(못 지나감), 그 뒤 검은 바위로 식어 다시 걸을 수 있어요.',
        '다음 화산 차례에 일어날 일은 모두 섬 위에 미리 표시돼요. 표시를 잘 보고 피하세요!'] },
      { h: '구조선', p: [
        '배는 3척, 배마다 2명까지 탈 수 있어요. 배 옆 칸에서 1걸음으로 배 칸에 들어가면 바로 탈출!',
        '배 위 동그라미 숫자는 남은 차례 수예요. 1(빨강)이면 이번 라운드가 마지막 기회예요. 배는 보통 6·9·12라운드가 끝날 때 떠나요(옵션).',
        '해안이 무너져 배 옆에 땅이 없어지면, 배가 가까운 다른 해안으로 옮겨 가요.'] },
      { h: '점수·승리', p: [
        '마지막 배가 떠나면 게임 끝. 탈출한 사람 중 보물 점수가 가장 높은 사람이 이겨요(같으면 공동 1등).',
        '혼자 하기: 탈출하면 ★, 섬 보물 점수의 1/4 이상이면 ★★, 45% 이상이면 ★★★ (결과 화면에 기준 점수가 나와요).'] },
      { h: '예시', p: [
        '걸음 4인 내가 바로 옆 오르막(2걸음)의 보석 칸으로 가면 보석 +3점. 무게 1이라 걸음은 아직 4예요.',
        '배 숫자가 2인데 배까지 걸음 6이 필요하면, 이번 차례와 다음 차례 두 번에 가야 해요. 여기서 우상을 더 주우면 걸음이 3으로 줄어 위험할 수 있어요!'] },
      { h: '조작', p: [
        '칸 탭 = 고르기(길·보물·위험 안내가 아래 줄에 떠요), 같은 칸 다시 탭 = 이동. 칸 근처를 대충 눌러도 가장 가까운 갈 수 있는 칸이 골라져요.',
        '위쪽 이름표: 💰 들고 있는 보물 점수 · 👣 다음 걸음 · 💫 기절 · 🌊 헤엄 중.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움 AI는 용암 흐름을 몇 차례 앞까지 읽고 탈출 때를 계산해요.'] },
    ],
    tutorial: [
      { sel: '.vo-board', text: '화산이 깨어난 섬이에요! 보물을 챙겨서 배가 떠나기 전에 배에 타면 탈출. 탈출한 사람의 보물만 점수예요.' },
      { sel: '.vo-me', text: '내 탐험가예요. 내 차례엔 갈 수 있는 칸이 밝은 테두리로 보여요. 칸을 탭하면 길이 보이고, 한 번 더 탭하면 이동! 도착 칸의 보물은 저절로 주워요.' },
      { sel: '.vo-board', text: '걸음은 4. 오르막은 2걸음이고, 보석·우상은 무거워서 많이 들면 걸음이 줄어요.' },
      { sel: '.vo-board', text: '모두 한 번씩 움직이면 화산 차례! 주황 빛 = 다음에 용암이 덮칠 칸(있으면 탈락), 노란 금 = 바다로 무너질 칸(보물 잃음), 빨간 과녁 = 화산탄(기절).' },
      { sel: '.vo-boat', text: '구조선의 숫자는 남은 차례예요. 숫자가 다 지나기 전에 배 칸으로 들어가면 탈출! 배마다 2명까지 타요.' },
      { sel: '.vo-chips', text: '이름표에서 들고 있는 보물 점수(💰)와 다음 걸음(👣)을 봐요. 욕심과 탈출 사이의 줄타기, 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { gen, SHAPES, lavaStep, reach, legalTargets, pval, pwt, apOf, project, N, NB, stars },
  });
})();
