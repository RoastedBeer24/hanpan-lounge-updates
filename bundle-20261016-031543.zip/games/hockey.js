/* 아이스하키 4:4 — realtime top-down ice hockey for up to 8 people (2–4 skaters a side + an automatic goalie).
   One person per phone: each human skates one player; empty skater spots are bots. Friends play via online / LAN.
   Unlike 미니 풋살: skating momentum on ice (glide, hockey-stop braking), the nets stand INSIDE the rink so play goes
   on behind them, a stick-handled puck that glides and bounces off the boards, body checks, goal creases, three periods,
   golden-goal overtime and an instant replay after every goal.
   The match engine (world, physics, AI, faceoffs, clock) is pure and lives outside the view so node can run headless AI
   matches. The host (or the local phone) runs it; guests publish their stick/button and draw the host's snapshots
   (their own skater is predicted locally). Score / period / end travel in the small coarse state. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- arenas (units ≈ half a metre; x across −HW…HW, y along −HL…HL) ---------- */
  const ARENAS = {
    rink: { name: '실내 링크', HW: 15, HL: 34, CR: 7, GO: 6, eb: 0.72, es: 0.3, fr: 1 },
    lake: { name: '호수 빙판', HW: 16, HL: 35, CR: 10, GO: 6, eb: 0.42, es: 0.12, fr: 1.12, wind: 1 },
    storm: { name: '눈보라', HW: 15, HL: 34, CR: 7, GO: 6, eb: 0.6, es: 0.25, fr: 1.05, snow: 1 },
    small: { name: '작은 링크', HW: 11.5, HL: 26, CR: 5.5, GO: 4.6, eb: 0.76, es: 0.3, fr: 1 },
    pillar: { name: '기둥 링크', HW: 15, HL: 34, CR: 7, GO: 6, eb: 0.72, es: 0.3, fr: 1, pil: 1 },
    neon: { name: '네온 탄력 링크', HW: 15, HL: 34, CR: 7, GO: 6, eb: 0.95, es: 0.65, fr: 0.78 },
  };
  const AR_IDS = Object.keys(ARENAS);
  const GW = 2.1, GD = 1.9, NT = 0.12, PO = 0.2, CRE = 3.3;            // net half-width, depth, frame, post, crease radius
  const PR = 0.95, GKR = 1.15, PK = 0.38, SREACH = PR + 0.85;          // skater, goalie, puck radius, stick reach
  const VMAX = 12.5, VCAR = 11.2, ACC = 19, BRK = 36, GLIDE = 0.7, VDASH = 19, VG = 9.5, ACC_G = 46;
  const PKK = 0.16, PKC = 0.85;                                        // puck drag dv/dt = −(PKK·v + PKC)·fr
  const WIND_P = 2.6, WIND_S = 0.9;
  const SUB = 1 / 150, NP = 26, PDT = 0.1;
  const GOAL_T = 4.4, CNT_T = 1.5, FIRST_T = 3.6, BRK_T = 2.8, OT_MAX = 120, CAP_T = 900;
  const REC_HZ = 30, RP_LEN = 2.0, RP_POST = 0.35, RP_SLOW = 0.75, GOAL_BAN = 1.1, TAP_T = 0.2;
  const TEAM = ['빨강', '파랑'], TCOL = ['#d8463a', '#2f7fd6'], TDARK = ['#7a1f1a', '#173f73'];
  const NUMS = [9, 17, 4, 22], GNUM = [1, 31];
  /* AI levels (per seat: 1 쉬움 / 2 보통 / 3 어려움). Bots without a seat and the goalie use the team level. */
  const DIFF = {
    1: { react: 0.38, spd: 0.82, shootR: 15, shootP: 0.42, aimErr: 0.15, pw0: 0.4, pw1: 0.75, passErr: 0.17, passIQ: 0.25,
      chkR: 3.4, chkP: 0.3, dribIQ: 0, posIQ: 0.3, stealP: 0.75, kReact: 0.32, kErr: 1.7, kSpd: 0.75, catchV: 19, kHold: 1.3 },
    2: { react: 0.2, spd: 0.92, shootR: 18, shootP: 0.65, aimErr: 0.075, pw0: 0.6, pw1: 0.92, passErr: 0.08, passIQ: 0.65,
      chkR: 3.1, chkP: 0.48, dribIQ: 0.6, posIQ: 0.7, stealP: 1.1, kReact: 0.24, kErr: 1.25, kSpd: 0.86, catchV: 23, kHold: 0.95 },
    3: { react: 0.1, spd: 1.0, shootR: 20, shootP: 0.8, aimErr: 0.035, pw0: 0.78, pw1: 1.0, passErr: 0.03, passIQ: 1,
      chkR: 2.9, chkP: 0.62, dribIQ: 1, posIQ: 1, stealP: 1.45, kReact: 0.17, kErr: 0.85, kSpd: 0.95, catchV: 27, kHold: 0.65 },
  };
  const NOH = {};

  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * Math.random()); }
  function mulberry(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const sgOf = (t) => (t === 0 ? 1 : -1);      // y side of team t's own goal (team 0 defends +y)
  const fwOf = (t) => (t === 0 ? -1 : 1);      // y direction team t attacks
  const shotSpeed = (pw) => 24 + 30 * clamp(pw, 0, 1);
  function wrapA(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  function turn(p, to, mx) { const d = wrapA(to - p.a); p.a = wrapA(p.a + clamp(d, -mx, mx)); }
  function seatsOfTeam(st, t) { const r = []; for (let s = t; s < st.np; s += 2) r.push(s); return r; }
  function bodySeat(st, i) { const ts = st.ts; if (i >= 2 * ts) return -1; const t = Math.floor(i / ts), j = i % ts, s = t + 2 * j; return s < st.np ? s : -1; }
  function seatBody(st, s) { return (s % 2) * st.ts + Math.floor(s / 2); }
  function bodyName(st, i) {
    const ts = st.ts;
    if (i < 0) return '';
    if (i >= 2 * ts) return '골리';
    const s = bodySeat(st, i);
    return s >= 0 ? String((st.n && st.n[s]) || (s + 1) + '번') : '#' + NUMS[i % ts];
  }

  /* ---------- arena layout (deterministic from the state seed so guests build the same rink) ---------- */
  function arenaLayout(st) {
    const A = ARENAS[st.ar] || ARENAS.rink, R = mulberry((st.sd | 0) || 7), GL = A.HL - A.GO, pil = [], pat = [];
    if (A.pil) {
      const k = Math.floor(R() * 3);
      if (k === 0) pil.push([-6, -11, 1.1], [6, -11, 1.1], [-6, 11, 1.1], [6, 11, 1.1]);
      else if (k === 1) pil.push([0, -9.5, 1.3], [0, 9.5, 1.3], [-8.6, 0, 1], [8.6, 0, 1]);
      else pil.push([-5.5, -15, 1], [5.5, 15, 1], [5, -5.5, 1.2], [-5, 5.5, 1.2]);
    }
    if (A.snow) {
      for (let n = 0; n < 3; n++) {
        const r = 2.2 + R() * 1.6, x = (R() * 2 - 1) * (A.HW - 3 - r * 0.5), y = 5 + r * 0.6 + R() * (GL - 11 - r);
        pat.push([r1(x), r1(y), r1(r)], [r1(-x), r1(-y), r1(r)]);       // point-symmetric: fair for both teams
      }
    }
    return { pil, pat };
  }

  /* ---------- world ---------- */
  function mkP(i, t, k, seat, j) {
    return { i, t, k, seat, j, x: 0, y: 0, vx: 0, vy: 0, a: t === 0 ? -Math.PI / 2 : Math.PI / 2, mx: 0, my: 0, brk: 0, spd: 1,
      cool: 0, tk: 0, tc: 0, dx: 0, dy: -1, got: 0, stun: 0, rec: 0, kt: 0, bf: 0, run: 0, hum: 0 };
  }
  function newWorld(st) {
    const A = ARENAS[st.ar] || ARENAS.rink, ts = st.ts, pl = [], tf = [[], []];
    for (let t = 0; t < 2; t++) for (let j = 0; j < ts; j++) { tf[t].push(pl.length); pl.push(mkP(pl.length, t, false, bodySeat(st, pl.length), j)); }
    const gk = [pl.length, pl.length + 1];
    for (let t = 0; t < 2; t++) pl.push(mkP(pl.length, t, true, -1, -1));
    const lay = arenaLayout(st);
    return { A, HW: A.HW, HL: A.HL, CR: A.CR, GL: A.HL - A.GO, ts, pl, tf, gk, pil: lay.pil, pat: lay.pat,
      b: { x: 0, y: 0, vx: 0, vy: 0, rot: 0, w: 0, inn: 0 }, own: -1, lt: -1, ast: -1, call: [null, null], wx: 0, wy: 0,
      path: new Float64Array(NP * 2), evn: 0, evl: [0, 0, 0, 0, -1], catchV: [23, 23] };
  }
  function setWind(W, st) {
    if (W.A.wind && fin(st.wd) && st.wd >= 0) { const a = st.wd * Math.PI / 180; W.wx = Math.cos(a); W.wy = Math.sin(a); } else { W.wx = 0; W.wy = 0; }
  }
  const FO = { 2: [[0, 1.7], [0, 10]], 3: [[0, 1.7], [-6, 5], [4, 11]], 4: [[0, 1.7], [-6, 5], [6, 5], [0, 11]] };
  function faceoff(W) {
    const b = W.b;
    b.x = 0; b.y = 0; b.vx = 0; b.vy = 0; b.w = 0; b.inn = 0; b.py = 0;
    W.call = [null, null]; W.own = -1; W.lt = -1; W.ast = -1;
    const kx = W.HW / 15, ky = W.HL / 34;
    for (const p of W.pl) { p.vx = 0; p.vy = 0; p.cool = 0; p.tk = 0; p.tc = 0; p.stun = 0; p.rec = 0; p.kt = 0; p.bf = 0; p.mx = 0; p.my = 0; p.brk = 0; }
    for (let t = 0; t < 2; t++) {
      const sg = sgOf(t), fw = fwOf(t), k = W.pl[W.gk[t]], spots = FO[W.ts] || FO[4];
      k.x = 0; k.y = sg * (W.GL - 1.5); k.a = Math.atan2(fw, 0);
      W.tf[t].forEach((i, j) => {
        const p = W.pl[i], s = spots[j % spots.length];
        p.x = s[0] * kx * sg; p.y = (j === 0 ? s[1] : s[1] * ky) * sg; p.a = Math.atan2(fw, 0);
        pillarPush(W, p, PR, 0);
      });
    }
  }

  /* keep a circle inside the rounded rink; returns the normal speed it hit with */
  function rrPush(W, o, r, e) {
    const ix = W.HW - W.CR, iy = W.HL - W.CR;
    const qx = clamp(o.x, -ix, ix), qy = clamp(o.y, -iy, iy);
    const dx = o.x - qx, dy = o.y - qy, d = hyp(dx, dy), lim = W.CR - r;
    if (d <= lim || d < 1e-9) return 0;
    const nx = dx / d, ny = dy / d;
    o.x = qx + nx * lim; o.y = qy + ny * lim;
    const vn = o.vx * nx + o.vy * ny;
    if (vn > 0) { o.vx -= (1 + e) * vn * nx; o.vy -= (1 + e) * vn * ny; return vn; }
    return 0;
  }
  function pillarPush(W, o, r, e) {
    let hit = 0;
    for (const c of W.pil) {
      const dx = o.x - c[0], dy = o.y - c[1], d = hyp(dx, dy), R = c[2] + r;
      if (d >= R || d < 1e-9) continue;
      const nx = dx / d, ny = dy / d; o.x = c[0] + nx * R; o.y = c[1] + ny * R;
      const vn = o.vx * nx + o.vy * ny;
      if (vn < 0) { o.vx -= (1 + e) * vn * nx; o.vy -= (1 + e) * vn * ny; hit = Math.max(hit, -vn); }
    }
    return hit;
  }
  function inPatch(W, x, y) { for (const c of W.pat) { const dx = x - c[0], dy = y - c[1]; if (dx * dx + dy * dy < c[2] * c[2]) return true; } return false; }
  /* thin net wall (segment) vs circle: push to the circle's side, bounce */
  function segHit(o, r, ax, ay, bx, by, e) {
    const dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy;
    let u = ((o.x - ax) * dx + (o.y - ay) * dy) / L2; u = u < 0 ? 0 : u > 1 ? 1 : u;
    const px = ax + dx * u, py = ay + dy * u; let nx = o.x - px, ny = o.y - py; const d = hyp(nx, ny);
    if (d >= r || d < 1e-9) return -1;
    nx /= d; ny /= d; o.x = px + nx * r; o.y = py + ny * r;
    const vn = o.vx * nx + o.vy * ny;
    if (vn < 0) { o.vx -= (1 + e) * vn * nx; o.vy -= (1 + e) * vn * ny; return -vn; }
    return 0;
  }
  /* the net as a solid box (skaters, goalies, a puck carried from behind) */
  function netSolid(W, o, r) {
    for (const sg of [-1, 1]) {
      const ya = sg * W.GL, yb = sg * (W.GL + GD), x0 = -GW - NT - r, x1 = GW + NT + r, y0 = Math.min(ya, yb) - r, y1 = Math.max(ya, yb) + r;
      if (o.x <= x0 || o.x >= x1 || o.y <= y0 || o.y >= y1) continue;
      const pl = o.x - x0, pr = x1 - o.x, pt = o.y - y0, pb = y1 - o.y, m = Math.min(pl, pr, pt, pb);
      if (m === pl) { o.x = x0; if (o.vx > 0) o.vx *= -0.2; }
      else if (m === pr) { o.x = x1; if (o.vx < 0) o.vx *= -0.2; }
      else if (m === pt) { o.y = y0; if (o.vy > 0) o.vy *= -0.2; }
      else { o.y = y1; if (o.vy < 0) o.vy *= -0.2; }
    }
  }
  function emit(W, kind, i, v, x, y, hooks) {
    W.evn = (W.evn + 1) % 1000;
    W.evl = [kind, r1(x), r1(y), Math.round(v), i];
    if (hooks.fx) hooks.fx(kind, x, y, v, i);
  }
  /* puck vs boards, pillars, nets; detects a goal (puck fully over the line after entering through the mouth) */
  function puckBounds(W, hooks, live, py, carried) {
    const b = W.b, A = W.A;
    const v = rrPush(W, b, PK, carried ? 0 : A.eb);
    if (v > 7 && !carried) emit(W, 8, W.lt, v, b.x, b.y, hooks);
    if (W.pil.length) { const pv = pillarPush(W, b, PK, carried ? 0 : 0.85); if (pv > 6) emit(W, 9, W.lt, pv, b.x, b.y, hooks); }
    for (const sg of [-1, 1]) {
      const y0 = sg * W.GL, y1 = sg * (W.GL + GD);
      for (const sx of [-1, 1]) {
        const dx = b.x - sx * GW, dy = b.y - y0, d = hyp(dx, dy), R = PK + PO;
        if (d < R && d > 1e-6) {
          const nx = dx / d, ny = dy / d; b.x = sx * GW + nx * R; b.y = y0 + ny * R;
          const vn = b.vx * nx + b.vy * ny;
          if (vn < 0) { b.vx -= 1.75 * vn * nx; b.vy -= 1.75 * vn * ny; if (-vn > 5 && !carried) emit(W, 6, W.lt, -vn, b.x, b.y, hooks); }
        }
      }
      const R = PK + NT;
      segHit(b, R, -GW, y0, -GW, y1, 0.25); segHit(b, R, GW, y0, GW, y1, 0.25);
      const bv = segHit(b, R, -GW, y1, GW, y1, 0.12);
      if (bv > 3 && hooks.net) hooks.net(sg, b.x, bv);
      // the mouth: remember a puck that crossed the goal line between the posts
      const ax = Math.abs(b.x) < GW;
      if (ax && sg * py < W.GL && sg * b.y >= W.GL) b.inn = sg;
      if (b.inn === sg && sg * b.y < W.GL - 0.6) b.inn = 0;
      if (ax && sg * b.y > W.GL && sg * b.y < W.GL + GD && b.inn !== sg) {   // got inside some other way: put it behind the net
        b.y = sg * (W.GL + GD + NT + PK + 0.03); if (b.vy * sg < 0) b.vy = -b.vy * 0.3;
      }
      if (live && b.inn === sg && sg * b.y > W.GL + PK && ax) return sg > 0 ? 1 : 0;
    }
    return -1;
  }
  function take(W, i, hooks) {
    const p = W.pl[i], pr = W.lt >= 0 ? W.pl[W.lt] : null;
    W.ast = pr && pr.i !== i && pr.t === p.t && !pr.k ? pr.i : -1;
    W.own = i; W.lt = i;
    if (W.call[p.t] && W.call[p.t].i === i) W.call[p.t] = null;
    if (p.k) emit(W, 4, i, hyp(W.b.vx - p.vx, W.b.vy - p.vy), W.b.x, W.b.y, hooks);
  }
  function kick(W, i, dx, dy, spd, kind, hooks) {
    const p = W.pl[i], b = W.b, l = hyp(dx, dy) || 1;
    dx /= l; dy /= l;
    W.own = -1; W.lt = i; p.cool = 0.25; p.kt = 0.28;
    b.vx = dx * spd + p.vx * 0.25; b.vy = dy * spd + p.vy * 0.25;
    b.w = (Math.random() < 0.5 ? -1 : 1) * (6 + spd * 0.35);
    if (!p.k) p.a = Math.atan2(dy, dx);
    emit(W, kind, i, spd, b.x, b.y, hooks);
  }
  function dash(W, i, dx, dy, hooks) {
    const p = W.pl[i];
    if (p.k || p.tc > 0 || p.tk > 0 || p.stun > 0 || W.own === i) return false;
    const l = hyp(dx, dy); if (l < 1e-6) { dx = Math.cos(p.a); dy = Math.sin(p.a); } else { dx /= l; dy /= l; }
    p.tk = 0.22; p.tc = 1.0; p.dx = dx; p.dy = dy; p.got = 0; p.a = Math.atan2(dy, dx);
    emit(W, 7, i, 0, p.x, p.y, hooks);
    return true;
  }
  /* a check that lands: the victim is knocked over, a carried puck pops loose */
  function bodyCheck(W, q, c, hooks) {
    const b = W.b;
    c.stun = 0.75; c.tk = 0; c.vx = q.dx * 11 + c.vx * 0.3; c.vy = q.dy * 11 + c.vy * 0.3;
    q.got = 1; q.tk = Math.min(q.tk, 0.04); q.vx *= 0.45; q.vy *= 0.45; q.cool = 0.1;
    if (W.own === c.i) {
      W.own = -1; W.lt = q.i; c.cool = 0.6;
      const s = Math.random() < 0.5 ? -1 : 1;
      b.vx = q.dx * 7 - q.dy * s * 3 + c.vx * 0.3; b.vy = q.dy * 7 + q.dx * s * 3 + c.vy * 0.3; b.w = s * 9;
    }
    const nearB = Math.abs(c.x) > W.HW - 2.6 || Math.abs(c.y) > W.HL - 2.6;
    emit(W, 3, q.i, nearB ? 16 : 11, (q.x + c.x) / 2, (q.y + c.y) / 2, hooks);
  }
  /* pass speed so the puck arrives at distance d with about `va` units/s left */
  function passSpeed(W, d, va) {
    const k = PKK * W.A.fr, c = PKC * W.A.fr, ck = c / k;
    let lo = va, hi = 48;
    for (let n = 0; n < 22; n++) {
      const v = (lo + hi) / 2, t = Math.log((v + ck) / (va + ck)) / k, s = (v - va) / k - ck * t;
      if (s < d) lo = v; else hi = v;
    }
    return clamp(hi, 10, 40);
  }

  function movePlayers(W, h, hooks) {
    const pl = W.pl, b = W.b, A = W.A;
    for (const p of pl) {
      if (p.cool > 0) p.cool -= h; if (p.tc > 0) p.tc -= h; if (p.stun > 0) p.stun -= h; if (p.rec > 0) p.rec -= h; if (p.kt > 0) p.kt -= h; if (p.bf > 0) p.bf -= h; if (p.lk > 0) { p.lk -= h; if (p.lk <= 0) p.lk = 0; }
      if (p.k) {
        const vm = VG * p.spd * (p.bf > 0 ? 0.75 : 1);
        let mx = p.mx, my = p.my; const m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
        let ax = mx * vm - p.vx, ay = my * vm - p.vy; const al = hyp(ax, ay), am = ACC_G * h;
        if (al > am) { ax *= am / al; ay *= am / al; }
        p.vx += ax; p.vy += ay;
        turn(p, Math.atan2(b.y - p.y, b.x - p.x), 9 * h);
      } else if (p.tk > 0) {
        p.tk -= h; p.vx = p.dx * VDASH; p.vy = p.dy * VDASH;
        if (p.tk <= 0) { p.tk = 0; if (!p.got) p.rec = 0.35; p.vx *= 0.55; p.vy *= 0.55; }
      } else {
        let vm = (W.own === p.i ? VCAR : VMAX) * p.spd;
        if (W.pat.length && inPatch(W, p.x, p.y)) vm *= 0.72;
        if (p.rec > 0) vm *= 0.55;
        let mx = p.mx, my = p.my; const m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
        if (p.stun > 0) { const f = Math.exp(-2.2 * h); p.vx *= f; p.vy *= f; }
        else if (m > 0.08 || p.brk) {
          const tx = m > 0.08 ? mx * vm : 0, ty = m > 0.08 ? my * vm : 0, sp = hyp(p.vx, p.vy);
          let ax = tx - p.vx, ay = ty - p.vy; const al = hyp(ax, ay);
          const dot = sp > 0.5 ? (p.vx * ax + p.vy * ay) / (sp * (al || 1)) : 1;   // pushing against my motion = braking
          const am = (dot < -0.35 ? BRK : ACC) * h;
          if (al > am) { ax *= am / al; ay *= am / al; }
          p.vx += ax; p.vy += ay;
        } else { const f = Math.exp(-GLIDE * h); p.vx *= f; p.vy *= f; }
        if (m > 0.12 && p.stun <= 0) turn(p, Math.atan2(my, mx), (W.own === p.i ? 8 : 12) * h);
        if (W.wx || W.wy) { p.vx += W.wx * WIND_S * h; p.vy += W.wy * WIND_S * h; }
      }
      p.x += p.vx * h; p.y += p.vy * h;
      p.run += hyp(p.vx, p.vy) * h;
      const r = p.k ? GKR : PR;
      rrPush(W, p, r, A.es);
      if (W.pil.length) pillarPush(W, p, r, 0.3);
      netSolid(W, p, r);
      if (p.k) {
        const sg = sgOf(p.t);
        p.x = clamp(p.x, -GW - 1.7, GW + 1.7);
        if (p.y * sg > W.GL - 1.35) { p.y = sg * (W.GL - 1.35); if (p.vy * sg > 0) p.vy = 0; }
        if (p.y * sg < W.GL - 4.4) { p.y = sg * (W.GL - 4.4); if (p.vy * sg < 0) p.vy = 0; }
      } else {
        // the other team's crease is off-limits for attackers
        const t2 = 1 - p.t, sg = sgOf(t2), cy = sg * W.GL, dx = p.x, dy = p.y - cy, d = hyp(dx, dy), R = CRE + PR * 0.25;
        if (d < R && sg * p.y < W.GL && d > 1e-6) { p.x = dx / d * R; p.y = cy + dy / d * R; const vn = (p.vx * dx + p.vy * dy) / d; if (vn < 0) { p.vx -= vn * dx / d; p.vy -= vn * dy / d; } }
      }
    }
    for (let i = 0; i < pl.length; i++) for (let j = i + 1; j < pl.length; j++) {
      const a = pl[i], c = pl[j], R = (a.k ? GKR : PR) + (c.k ? GKR : PR);
      let dx = c.x - a.x, dy = c.y - a.y; const d2 = dx * dx + dy * dy;
      if (d2 >= R * R) continue;
      let d = Math.sqrt(d2); if (d < 1e-6) { dx = 0.01; dy = 0; d = 0.01; }
      const nx = dx / d, ny = dy / d, o = (R - d) / 2;
      const wa = a.k ? 0.2 : 1, wc = c.k ? 0.2 : 1, ws = wa + wc;      // goalies are planted
      a.x -= nx * o * 2 * wa / ws; a.y -= ny * o * 2 * wa / ws; c.x += nx * o * 2 * wc / ws; c.y += ny * o * 2 * wc / ws;
      const vn = (c.vx - a.vx) * nx + (c.vy - a.vy) * ny;
      if (vn < 0) {
        const k = vn * 0.85;
        a.vx += k * nx * wa / ws * 2; a.vy += k * ny * wa / ws * 2; c.vx -= k * nx * wc / ws * 2; c.vy -= k * ny * wc / ws * 2;
        if (a.t !== c.t && !a.k && !c.k) {
          if (a.tk > 0 && c.stun <= 0) { bodyCheck(W, a, c, hooks); continue; }
          if (c.tk > 0 && a.stun <= 0) { bodyCheck(W, c, a, hooks); continue; }
        }
        if (-vn > 9) emit(W, 10, a.i, -vn, (a.x + c.x) / 2, (a.y + c.y) / 2, hooks);
      }
    }
  }
  function dribble(W, h, hooks, live) {
    const p = W.pl[W.own], b = W.b, py = b.y;
    const wob = p.k ? 0 : Math.sin(p.run * 0.9 + p.i) * 0.32, ca = Math.cos(p.a), sa = Math.sin(p.a);
    const reach = p.k ? GKR + 0.25 : SREACH;
    const tx = p.x + ca * reach - sa * wob, ty = p.y + sa * reach + ca * wob, k = Math.min(1, h * 30);
    b.x += (tx - b.x) * k; b.y += (ty - b.y) * k; b.vx = p.vx; b.vy = p.vy;
    b.rot += (hyp(p.vx, p.vy) * 0.6 + 4) * h; b.w *= Math.exp(-3 * h);
    const sg = b.y > 0 ? 1 : -1, front = sg * p.y < W.GL - 0.2 && Math.abs(p.x) < GW + 1.2;
    let g = -1;
    if (front || p.k) g = puckBounds(W, NOH, live && !p.k, py, true);
    else { rrPush(W, b, PK, 0); netSolid(W, b, PK); if (W.pil.length) pillarPush(W, b, PK, 0); }
    if (g >= 0) { W.own = -1; return g; }
    if (hyp(b.x - tx, b.y - ty) > 1.4) { W.own = -1; p.cool = 0.3; }   // pinned away from the stick: lost it
    return -1;
  }
  /* the puck on someone's stick can be taken: a check that reaches it wins it, a stick next to it pokes it away now and then */
  function steals(W, h, hooks) {
    const c = W.pl[W.own], b = W.b;
    if (c.k) return;
    for (const q of W.pl) {
      if (q.t === c.t || q.stun > 0 || q.cool > 0) continue;
      const sx = q.x + Math.cos(q.a) * SREACH, sy = q.y + Math.sin(q.a) * SREACH;
      const ds = hyp(b.x - sx, b.y - sy), db = hyp(b.x - q.x, b.y - q.y);
      const r = q.k ? GKR + PK + 0.2 : PR + PK + 0.1;
      if (ds >= 0.95 && db >= r) continue;
      let win = false;
      if (q.tk > 0) { win = true; c.stun = Math.max(c.stun, 0.3); q.got = 1; q.tk = Math.min(q.tk, 0.05); }
      else if (q.k) win = Math.random() < h * 4;
      else win = Math.random() < h * (q.sp || 1.1);
      if (win) { take(W, q.i, hooks); if (!q.k) emit(W, 2, q.i, 0, b.x, b.y, hooks); return; }
    }
  }
  function puckStep(W, h, hooks, live) {
    const b = W.b, sp = hyp(b.vx, b.vy), py = b.y;
    let fr = W.A.fr;
    if (W.pat.length && inPatch(W, b.x, b.y)) fr *= 4.5;
    if (sp > 0) { let ns = sp - (PKK * sp + PKC) * fr * h; if (ns < 0) ns = 0; b.vx *= ns / sp; b.vy *= ns / sp; }
    if (W.wx || W.wy) { b.vx += W.wx * WIND_P * h; b.vy += W.wy * WIND_P * h; }
    b.x += b.vx * h; b.y += b.vy * h;
    b.rot += b.w * h; b.w *= Math.exp(-0.8 * h);
    return puckBounds(W, hooks, live, py, false);
  }
  function puckPlayers(W, h, hooks) {
    const b = W.b;
    for (const p of W.pl) {
      if (p.cool > 0) continue;
      const rvx = b.vx - p.vx, rvy = b.vy - p.vy, rs = hyp(rvx, rvy);
      const sg = sgOf(p.t), zone = sg * b.y > W.GL - 6;
      const trap = p.stun > 0 ? 0 : p.k ? (zone ? W.catchV[p.t] : 0) : 17;
      if (!p.k && p.stun <= 0) {     // receiving on the stick blade
        const sx = p.x + Math.cos(p.a) * SREACH, sy = p.y + Math.sin(p.a) * SREACH;
        if (hyp(b.x - sx, b.y - sy) < 0.8 && rs < trap) { take(W, p.i, hooks); return; }
      }
      const r = (p.k ? 0.82 + (p.bf > 0 ? 0.42 : 0) : PR) + PK;   // a goalie's blocking shape is narrower than his body
      let dx = b.x - p.x, dy = b.y - p.y, d = hyp(dx, dy);
      if (d >= r) continue;
      if (d < 1e-6) { dx = Math.cos(p.a); dy = Math.sin(p.a); d = 1; }
      const nx = dx / d, ny = dy / d;
      if (rs < trap) { take(W, p.i, hooks); return; }
      if (p.k && rs > 30 && !p.lk && Math.random() < (rs - 30) / 55 * (p.bf > 0 ? 0.45 : 1)) { p.lk = 0.25; continue; }   // a hard shot squeezes through
      if (p.k && p.lk > 0) continue;
      b.x = p.x + nx * r; b.y = p.y + ny * r;
      const vn = rvx * nx + rvy * ny;
      if (vn < 0) {
        const e = p.k ? 0.32 : 0.3;
        b.vx -= (1 + e) * vn * nx; b.vy -= (1 + e) * vn * ny;
        if (p.k) { const a = (Math.random() - 0.5) * 1.1, c = Math.cos(a), s = Math.sin(a), vx = b.vx; b.vx = vx * c - b.vy * s; b.vy = vx * s + b.vy * c; b.w = (Math.random() - 0.5) * 30; }
        if (p.k && -vn > 10) emit(W, 4, p.i, -vn, b.x, b.y, hooks);
        else if (-vn > 7) emit(W, 5, p.i, -vn, b.x, b.y, hooks);
      }
      const pr = W.lt >= 0 ? W.pl[W.lt] : null;
      if (pr && pr.i !== p.i) W.ast = pr.t === p.t && !pr.k ? pr.i : -1;
      W.lt = p.i;
    }
  }
  function stepWorld(W, h, hooks, live) {
    movePlayers(W, h, hooks);
    if (W.own >= 0) {
      const g = dribble(W, h, hooks, live);
      if (g >= 0) return g;
      if (W.own >= 0) steals(W, h, hooks);
      return -1;
    }
    const g = puckStep(W, h, hooks, live);
    if (g < 0) puckPlayers(W, h, hooks);
    return g;
  }

  /* ---------- puck prediction + intercepts (AI) ---------- */
  function puckPath(W) {
    const P = W.path, b = W.b, own = W.own >= 0, fr = W.A.fr;
    let x = b.x, y = b.y, vx = b.vx, vy = b.vy;
    for (let k = 0; k < NP; k++) {
      P[k * 2] = x; P[k * 2 + 1] = y;
      if (own) { if (k < 5) { x += vx * PDT; y += vy * PDT; } }
      else {
        for (let s = 0; s < 2; s++) {
          const h = PDT / 2, sp = hyp(vx, vy);
          if (sp > 0) { let ns = sp - (PKK * sp + PKC) * fr * h; if (ns < 0) ns = 0; vx *= ns / sp; vy *= ns / sp; }
          vx += W.wx * WIND_P * h; vy += W.wy * WIND_P * h;
          x += vx * h; y += vy * h;
          if (Math.abs(x) > W.HW - PK) { x = Math.sign(x) * (W.HW - PK); vx = -vx * W.A.eb; }
          if (Math.abs(y) > W.HL - PK) { y = Math.sign(y) * (W.HL - PK); vy = -vy * W.A.eb; }
        }
      }
      x = clamp(x, -W.HW, W.HW); y = clamp(y, -W.HL, W.HL);
    }
  }
  function intercept(W, p, vm, react, out) {
    const P = W.path;
    let d = 0;
    for (let k = 0; k < NP; k++) {
      const t = k * PDT;
      d = hyp(P[k * 2] - p.x, P[k * 2 + 1] - p.y) - SREACH * 0.8;
      if (d <= vm * Math.max(0, t - react) * 0.85) { out.t = t; out.x = P[k * 2]; out.y = P[k * 2 + 1]; return out; }
    }
    out.t = NP * PDT + d / vm; out.x = P[(NP - 1) * 2]; out.y = P[(NP - 1) * 2 + 1];
    return out;
  }
  function laneClear(W, x0, y0, x1, y1, t, skipK) {
    const dx = x1 - x0, dy = y1 - y0, L2 = dx * dx + dy * dy || 1, Ln = Math.sqrt(L2);
    let m = 99;
    for (const q of W.pl) {
      if (q.t !== t || (skipK && q.k) || q.stun > 0) continue;
      const u = ((q.x - x0) * dx + (q.y - y0) * dy) / L2;
      if (u < 0.02 || u > 1.08) continue;
      const uu = Math.min(u, 1), px = x0 + dx * uu - q.x, py = y0 + dy * uu - q.y;
      m = Math.min(m, hyp(px, py) - (q.k ? GKR : PR) * 0.5 - uu * Ln * 0.05);
    }
    for (const c of W.pil) {
      const u = clamp(((c[0] - x0) * dx + (c[1] - y0) * dy) / L2, 0, 1);
      m = Math.min(m, hyp(x0 + dx * u - c[0], y0 + dy * u - c[1]) - c[2]);
    }
    // the nets block straight lines too
    for (const sg of [-1, 1]) {
      const cy = sg * (W.GL + GD / 2), u = clamp(((0 - x0) * dx + (cy - y0) * dy) / L2, 0, 1);
      m = Math.min(m, hyp(x0 + dx * u, y0 + dy * u - cy) - GW);
    }
    return m;
  }
  function openness(W, x, y, t) { let m = 99; for (const q of W.pl) if (q.t !== t && !q.k) m = Math.min(m, hyp(q.x - x, q.y - y)); return m; }
  function assignRoles(E) {
    const W = E.W, own = W.own >= 0 ? W.pl[W.own] : null;
    for (let t = 0; t < 2; t++) {
      const F = W.tf[t];
      if (own && own.t === t) { for (const j of F) E.role[j] = j === W.own ? 'car' : own.k ? 'out' : 'sup'; E.chase[t] = -1; continue; }
      let best = -1, bt = 1e9;
      for (const j of F) {
        const p = W.pl[j];
        if (p.stun > 0) { E.icp[j].t = 9; continue; }
        const it = intercept(W, p, VMAX * (p.spd || 1), 0.05, E.icp[j]);
        if (it.t < bt) { bt = it.t; best = j; }
      }
      const prev = E.chase[t];
      if (prev >= 0 && prev !== best && F.includes(prev) && W.pl[prev].stun <= 0 && E.icp[prev].t < bt + 0.35) best = prev;
      E.chase[t] = best;
      for (const j of F) E.role[j] = j === best ? 'chase' : 'def';
    }
  }

  /* ---------- AI ---------- */
  function steerTo(p, tx, ty, run) {
    const dx = tx - p.x, dy = ty - p.y, d = hyp(dx, dy);
    if (d < 0.45) { p.mx = 0; p.my = 0; p.brk = 1; return; }
    const k = Math.min(1, d / 3.2) * (run || 1);
    p.mx = dx / d * k; p.my = dy / d * k; p.brk = 0;
  }
  function aiField(E, i, D, dt, hooks) {
    const W = E.W, p = W.pl[i], m = E.mem[i], role = E.role[i];
    m.th -= dt;
    if (role !== m.role) { m.role = role; m.th = role === 'car' ? D.react * 0.6 : Math.min(m.th, D.react * 0.4); if (role === 'car') m.dir = null; }
    if (m.th <= 0) {
      m.th = D.react * (0.7 + Math.random() * 0.6);
      if (role === 'car') aiCarrier(E, i, D, hooks);
      else if (role === 'sup' || role === 'out') aiSupport(E, i, D);
      else if (role === 'chase') aiChase(E, i, D, hooks);
      else aiDefend(E, i, D);
    }
    if (role === 'car') { const d = m.dir || [0, fwOf(p.t)]; p.mx = d[0]; p.my = d[1]; p.brk = 0; return; }
    if (!fin(m.tx)) { m.tx = p.x; m.ty = p.y; }
    if (role === 'chase' && W.own < 0 && D.posIQ >= 0.7) { const it = E.icp[i]; m.tx = it.x; m.ty = it.y; }
    steerTo(p, m.tx, m.ty, m.run || 1);
  }
  function aiCarrier(E, i, D, hooks) {
    const W = E.W, p = W.pl[i], b = W.b, t = p.t, fw = fwOf(t), gy = fw * W.GL, m = E.mem[i];
    if (W.own !== i) return;
    let press = 99, front = null, fd = 99;
    const ahead = W.GL - fw * b.y;                  // distance in front of the goal line I attack (<0 = behind the net)
    const slotY = fw * (W.GL - 7.5);
    const gdx = (ahead > 2 ? 0 : (b.x >= 0 ? 1 : -1) * (GW + 3.5)) - b.x, gdy = (ahead > 2 ? slotY : fw * (W.GL - 3)) - b.y;
    const gl = hyp(gdx, gdy) || 1;
    for (const j of W.tf[1 - t]) {
      const q = W.pl[j], d = hyp(q.x - p.x, q.y - p.y);
      if (q.stun > 0) continue;
      if (d < press) press = d;
      if (((q.x - p.x) * gdx + (q.y - p.y) * gdy) / gl > 0 && d < 6 && d < fd) { fd = d; front = q; }
    }
    const dG = hyp(b.x, gy - b.y);
    /* shoot */
    if (dG < D.shootR && ahead > 1.2 && Math.abs(b.x) < ahead * 2.4 + GW) {
      const kp = W.pl[W.gk[1 - t]];
      let best = null;
      for (const cx of [-(GW - 0.6), GW - 0.6, -(GW * 0.55), GW * 0.55]) {
        const lane = Math.min(laneClear(W, b.x, b.y, cx, gy, 1 - t, true), laneClear(W, b.x, b.y, cx, gy, t, true) + 0.4);
        const sc = Math.min(lane, 2.5) + Math.abs(cx - kp.x) * 0.7 * D.posIQ + Math.random() * (1.4 - D.posIQ);
        if (!best || sc > best.sc) best = { cx, sc, lane };
      }
      const close = dG < D.shootR * 0.55;
      const pr = D.shootP * (best.lane > 0.9 ? 1 : 0.3) * (close ? 1.6 : dG > D.shootR * 0.8 ? 0.45 : 1) * (press < 2.5 ? 1.3 : 1);
      if (Math.random() < pr) {
        const a = Math.atan2(gy - b.y, best.cx - b.x) + gauss() * D.aimErr;
        kick(W, i, Math.cos(a), Math.sin(a), shotSpeed(D.pw0 + Math.random() * (D.pw1 - D.pw0)), 1, hooks);
        return;
      }
    }
    /* pass */
    let bp = null;
    for (const j of W.tf[t]) {
      if (j === i) continue;
      const q = W.pl[j];
      if (q.stun > 0) continue;
      const ld = 0.45 * D.passIQ;
      const lx = clamp(q.x + q.vx * ld, -W.HW + 2, W.HW - 2), ly = clamp(q.y + q.vy * ld, -W.HL + 2, W.HL - 2);
      const lane = laneClear(W, b.x, b.y, lx, ly, 1 - t, false), open = openness(W, lx, ly, t), prog = (ly - b.y) * fw;
      const qAhead = W.GL - fw * ly, slot = qAhead > 2 && qAhead < 11 && Math.abs(lx) < 6;
      const called = !!(W.call[t] && W.call[t].i === j);
      const sc = prog * 0.1 + Math.min(open, 7) * 0.35 + (lane > 1.5 ? 0.8 : lane > 0.9 ? -0.5 : -3) + (called ? 2.5 : 0) + (q.hum ? 0.6 : 0) + (slot ? 1.6 * D.passIQ : 0);
      if (!bp || sc > bp.sc) bp = { j, lx, ly, sc, lane, called };
    }
    if (bp) {
      let go = false;
      if (bp.called && bp.lane > 0.8) go = true;
      else if (press < 3 && bp.sc > 0.6 && Math.random() < 0.4 + 0.5 * D.passIQ) go = true;
      else if (bp.sc > 3.4 && Math.random() < 0.2 * (0.5 + D.passIQ)) go = true;
      else if (D.passIQ < 0.5 && press < 3.4 && Math.random() < 0.25) go = true;   // beginners panic-pass
      if (go) {
        const d = hyp(bp.lx - b.x, bp.ly - b.y), a = Math.atan2(bp.ly - b.y, bp.lx - b.x) + gauss() * D.passErr;
        kick(W, i, Math.cos(a), Math.sin(a), passSpeed(W, d, 8), 0, hooks);
        W.call[t] = null;
        return;
      }
    }
    /* clear it up the boards when trapped near my own net */
    const own = -gy;
    if (hyp(b.x, own - b.y) < 12 && press < 2.4 && Math.random() < 0.45 + 0.4 * D.posIQ) {
      const sx = b.x >= 0 ? 1 : -1, a = Math.atan2(fw * 20, sx * 8) + gauss() * 0.15;
      kick(W, i, Math.cos(a), Math.sin(a), shotSpeed(0.55), 1, hooks);
      return;
    }
    /* skate toward the slot, around whoever is in front */
    let dx = gdx / gl, dy = gdy / gl;
    if (front && D.dribIQ > 0) {
      let side = Math.sign(p.x - front.x) || (Math.random() < 0.5 ? -1 : 1);
      if (Math.abs(p.x) > W.HW - 5) side = -Math.sign(p.x);
      const w = D.dribIQ * 1.6 * (6 - fd) / 6;
      dx += side * w; const l = hyp(dx, dy) || 1; dx /= l; dy /= l;
    }
    if (Math.abs(b.x) > W.HW - 2.8) { dx -= Math.sign(b.x) * 0.6; const l = hyp(dx, dy) || 1; dx /= l; dy /= l; }
    if (D.dribIQ === 0) { const a = Math.atan2(dy, dx) + gauss() * 0.3; dx = Math.cos(a); dy = Math.sin(a); }
    m.dir = [dx, dy];
  }
  function aiSupport(E, i, D) {
    const W = E.W, p = W.pl[i], t = p.t, fw = fwOf(t), m = E.mem[i], F = W.tf[t];
    const car = W.own >= 0 ? W.pl[W.own] : null;
    if (car && car.k) {   // my goalie has it: spread out to take the outlet pass
      const side = (F.indexOf(i) % 2) ? 1 : -1;
      m.tx = side * (W.HW - 4); m.ty = sgOf(t) * W.GL * 0.45; m.run = 0.9; return;
    }
    const cx = car ? car.x : W.b.x, cy = car ? car.y : W.b.y;
    // with 3+ skaters the last one (a defenceman) stays back behind the puck
    if (F.length >= 3 && F[F.length - 1] === i && D.posIQ >= 0.5) {
      m.tx = clamp(cx * 0.35, -W.HW + 3, W.HW - 3); m.ty = clamp(cy - fw * 10, -W.GL + 3, W.GL - 3); m.run = 0.8; return;
    }
    const side = cx > 1 ? -1 : cx < -1 ? 1 : (p.x >= 0 ? 1 : -1);
    const slotY = fw * (W.GL - 6.5);
    const cand = [[side * 6.5, cy + fw * 8], [side * 3.5, slotY], [side * (W.HW - 3.5), cy + fw * 3], [-side * 3, cy + fw * 11]];
    let best = null;
    const nC = D.posIQ < 0.5 ? 2 : cand.length;
    for (let k = 0; k < nC; k++) {
      const x = clamp(cand[k][0], -W.HW + 2.5, W.HW - 2.5), y = clamp(cand[k][1], -W.GL + 3.5, W.GL - 3.5);
      const sc = Math.min(openness(W, x, y, t), 7) + (laneClear(W, cx, cy, x, y, 1 - t, false) > 1.5 ? 2 : 0) - hyp(x - p.x, y - p.y) * 0.05 + Math.random() * (1 - D.posIQ) * 3;
      if (!best || sc > best.sc) best = { x, y, sc };
    }
    m.tx = best.x; m.ty = best.y; m.run = 0.75 + 0.25 * D.posIQ;
  }
  function aiChase(E, i, D, hooks) {
    const W = E.W, p = W.pl[i], b = W.b, t = p.t, m = E.mem[i], Oy = sgOf(t) * W.GL;
    if (W.own >= 0 && W.pl[W.own].t !== t) {
      const c = W.pl[W.own];
      if (c.k) { m.tx = clamp(b.x, -8, 8); m.ty = sgOf(c.t) * (W.GL - 9); m.run = 0.7; return; }
      const gx = -b.x, gy = Oy - b.y, gl = hyp(gx, gy) || 1;
      const goalSide = ((p.x - b.x) * gx + (p.y - b.y) * gy) / gl > 0.3;
      const lead = 0.12 + 0.18 * D.posIQ, bx = b.x + c.vx * lead, by = b.y + c.vy * lead;
      if (goalSide || D.posIQ < 0.5) { m.tx = bx; m.ty = by; } else { m.tx = bx + gx / gl * 1.8; m.ty = by + gy / gl * 1.8; }
      m.run = 1;
      const dc = hyp(c.x - p.x, c.y - p.y);
      if (dc < D.chkR && p.tc <= 0 && p.tk <= 0 && Math.random() < D.chkP) dash(W, i, c.x + c.vx * 0.1 - p.x, c.y + c.vy * 0.1 - p.y, hooks);
      return;
    }
    const it = E.icp[i], n = (1 - D.posIQ) * 1.4;
    if (D.posIQ < 0.5) { m.tx = b.x + gauss() * n; m.ty = b.y + gauss() * n; }
    else { m.tx = it.x; m.ty = it.y; }
    m.run = 1;
  }
  function aiDefend(E, i, D) {
    const W = E.W, p = W.pl[i], b = W.b, t = p.t, m = E.mem[i], Oy = sgOf(t) * (W.GL - 1);
    // mark the opponent closest to my net that no teammate covers yet (cheap: by order of my team list)
    const F = W.tf[t], k = F.indexOf(i);
    const opp = W.tf[1 - t].filter((j) => j !== W.own).map((j) => W.pl[j]).sort((a, c) => hyp(a.x, Oy - a.y) - hyp(c.x, Oy - c.y));
    const tg = opp.length ? opp[Math.min(opp.length - 1, Math.max(0, k - (E.chase[t] >= 0 && F.indexOf(E.chase[t]) < k ? 1 : 0)))] : null;
    let x, y;
    const lx = b.x * 0.45, ly = b.y + (Oy - b.y) * (0.45 + 0.1 * D.posIQ);
    if (tg && W.own >= 0) {
      const gx = -tg.x, gy = Oy - tg.y, gl = hyp(gx, gy) || 1;
      x = tg.x + gx / gl * 2.4; y = tg.y + gy / gl * 2.4;
      x = x * 0.7 + lx * 0.3; y = y * 0.7 + ly * 0.3;
    } else { x = lx; y = ly; }
    if (D.posIQ < 0.5) { x += gauss() * 2.5; y += gauss() * 2.5; }
    m.tx = clamp(x, -W.HW + 2, W.HW - 2); m.ty = clamp(y, -W.GL + 2, W.GL - 2);
    m.run = 0.75 + 0.25 * D.posIQ;
  }
  function aiGoalie(E, i, D, dt, hooks) {
    const W = E.W, p = W.pl[i], b = W.b, t = p.t, sg = sgOf(t), m = E.mem[i];
    const lineY = sg * (W.GL - 1.4);
    if (W.own === i) {
      m.hold = (m.hold || 0) + dt;
      p.mx = clamp(-p.x * 0.3, -0.5, 0.5); p.my = clamp((lineY - p.y) * 0.3, -0.5, 0.5);
      if (m.hold > D.kHold + (m.hj || 0)) { m.hold = 0; goalieOutlet(E, i, D, hooks); }
      return;
    }
    m.hold = 0; m.hj = Math.random() * 0.4;
    let tx = null, ty = null;
    const loose = W.own < 0;
    if (loose && b.vy * sg > 7) {
      if (!m.seen) m.kerr = gauss() * D.kErr;
      m.seen = (m.seen || 0) + dt;
      const tt = (lineY - b.y) / b.vy;
      if (tt > 0 && tt < 1.4 && m.seen >= D.kReact) {
        const xc = b.x + b.vx * tt + (m.kerr || 0) * Math.min(1, tt * 2.5);
        if (Math.abs(xc) < GW + 1.4) {
          tx = clamp(xc, -GW, GW); ty = lineY;
          if (Math.abs(xc - p.x) > 0.9 && tt < 0.45 && p.bf <= 0 && !m.dove) { p.bf = 0.55; m.dove = 1; }
        }
      }
    } else { m.seen = 0; m.dove = 0; }
    if (tx == null) {
      // stand on the line from the puck to the middle of the net, a bit out (cuts the angle)
      const gy = sg * W.GL, dx = b.x, dy = b.y - gy, d = hyp(dx, dy) || 1;
      const behind = sg * b.y > W.GL;
      if (behind) { tx = clamp(b.x, -GW + 0.6, GW - 0.6); ty = lineY; }
      else {
        const dep = 0.9 + (d > 20 ? 0.9 : d > 10 ? 0.45 : 0.1) * D.posIQ;
        tx = dx / d * dep; ty = gy + dy / d * dep;
      }
      // a loose slow puck in my crease: smother it
      const cr = hyp(b.x, b.y - gy) < CRE + 0.8 && !behind;
      if (cr && ((loose && hyp(b.vx, b.vy) < 9) || (!loose && W.pl[W.own].t !== t))) { tx = b.x; ty = b.y; }
    }
    const dx = tx - p.x, dy = ty - p.y, d = hyp(dx, dy), k = d < 0.15 ? 0 : Math.min(1, d / 1.0);
    p.mx = d > 1e-6 ? dx / d * k : 0; p.my = d > 1e-6 ? dy / d * k : 0;
  }
  function goalieOutlet(E, i, D, hooks) {
    const W = E.W, p = W.pl[i], b = W.b, t = p.t, fw = fwOf(t);
    let best = null;
    for (const j of W.tf[t]) {
      const q = W.pl[j]; if (q.stun > 0) continue;
      const open = openness(W, q.x, q.y, t), lane = laneClear(W, b.x, b.y, q.x, q.y, 1 - t, false);
      const sc = Math.min(open, 7) + (lane > 1.4 ? 2 : -3) + (q.hum ? 1.5 : 0) + (q.y - b.y) * fw * 0.04;
      if (!best || sc > best.sc) best = { q, sc, lane };
    }
    if (best && best.lane > 1.0) {
      const q = best.q, lx = q.x + q.vx * 0.3, ly = q.y + q.vy * 0.3, d = hyp(lx - b.x, ly - b.y);
      const a = Math.atan2(ly - b.y, lx - b.x) + gauss() * D.passErr * 0.6;
      kick(W, i, Math.cos(a), Math.sin(a), passSpeed(W, d, 8), 0, hooks);
    } else {
      const sx = Math.random() < 0.5 ? -1 : 1, a = Math.atan2(fw * 30, sx * 13) + gauss() * 0.12;
      kick(W, i, Math.cos(a), Math.sin(a), passSpeed(W, 26, 7), 0, hooks);
    }
  }
  function celebrate(E, p) {
    if (E.ph !== 'goal' || E.scT < 0 || p.k) return;
    if (p.t === E.scT) {
      const sc = E.st.gs >= 0 && E.st.gs < E.W.pl.length ? E.W.pl[E.st.gs] : null;
      const tx = sc && sc.t === p.t && sc.i !== p.i ? sc.x : (p.x >= 0 ? 1 : -1) * (E.W.HW - 4), ty = sc && sc.t === p.t && sc.i !== p.i ? sc.y : 0;
      const dx = tx - p.x, dy = ty - p.y, d = hyp(dx, dy);
      if (d > 2.4) { p.mx = dx / d * 0.7; p.my = dy / d * 0.7; } else p.brk = 1;
    }
  }

  /* ---------- human actions ---------- */
  function aimAssist(W, p, dx, dy, hasDir) {
    const b = W.b, fw = fwOf(p.t), gy = fw * W.GL, ahead = W.GL - fw * b.y;
    if (ahead < 0.8) return [dx, dy];
    if (!hasDir && hyp(b.x, gy - b.y) < 24) {   // no stick near the net: aim for the side away from the goalie
      const k = W.pl[W.gk[1 - p.t]], cx = (k.x > b.x * 0.25 ? -1 : 1) * (GW - 0.55), ex = cx - b.x, ey = gy - b.y, l = hyp(ex, ey) || 1;
      return [ex / l, ey / l];
    }
    if (dy * fw > 0.3) {
      const t = (gy - b.y) / dy, hx = b.x + dx * t;
      if (Math.abs(hx) < GW + 5) {
        const ax = clamp(hx, -(GW - 0.55), GW - 0.55), ex = ax - b.x, ey = gy - b.y, l = hyp(ex, ey) || 1;
        return [ex / l, ey / l];
      }
    }
    return [dx, dy];
  }
  function humanPass(E, i, dx, dy, hasDir, hooks) {
    const W = E.W, p = W.pl[i], b = W.b;
    let best = null;
    for (const j of W.tf[p.t]) {
      if (j === i) continue;
      const q = W.pl[j], ex = q.x - b.x, ey = q.y - b.y, d = hyp(ex, ey) || 1, dot = (ex * dx + ey * dy) / d;
      if (hasDir && dot < 0.3) continue;
      const sc = (hasDir ? dot * 2.2 : 0) - d * 0.03 - (q.stun > 0 ? 2 : 0);
      if (!best || sc > best.sc) best = { q, sc };
    }
    if (!best) { kick(W, i, dx, dy, 18, 0, hooks); return; }
    const q = best.q, lx = clamp(q.x + q.vx * 0.4, -W.HW + 1.5, W.HW - 1.5), ly = clamp(q.y + q.vy * 0.4, -W.HL + 1.5, W.HL - 1.5);
    kick(W, i, lx - b.x, ly - b.y, passSpeed(W, hyp(lx - b.x, ly - b.y), 8.5), 0, hooks);
  }
  function humanAct(E, seat, a, hooks) {
    const W = E.W, i = seatBody(E.st, seat), p = W.pl[i], b = W.b;
    if (!p || p.stun > 0) return;
    let dx = +a.dx || 0, dy = +a.dy || 0; const dl = hyp(dx, dy), hasDir = dl > 0.25;
    if (hasDir) { dx /= dl; dy /= dl; } else { dx = Math.cos(p.a); dy = Math.sin(p.a); }
    const sx = p.x + Math.cos(p.a) * SREACH, sy = p.y + Math.sin(p.a) * SREACH;
    if (a.k === 'pass') {
      if (W.own === i) humanPass(E, i, dx, dy, hasDir, hooks);
      else if (W.own >= 0 && W.pl[W.own].t === p.t) { W.call[p.t] = { i, t: 1.8 }; if (hooks.call) hooks.call(i); }
      return;
    }
    if (a.k === 'call') { if (W.own !== i) { W.call[p.t] = { i, t: 1.8 }; if (hooks.call) hooks.call(i); } return; }
    if (a.k === 'shoot') {
      const pw = clamp(+a.pw || 0.3, 0.2, 1);
      const near = W.own < 0 && p.cool <= 0 && Math.min(hyp(b.x - sx, b.y - sy), hyp(b.x - p.x, b.y - p.y) - PR) < 1.5;
      if (W.own === i || near) {
        if (near) { W.lt = i; W.own = i; }        // one-timer straight off the pass
        const d = aimAssist(W, p, dx, dy, hasDir), err = 0.01 + Math.max(0, pw - 0.85) * 0.3 + (near ? 0.03 : 0);
        const an = Math.atan2(d[1], d[0]) + gauss() * err;
        kick(W, i, Math.cos(an), Math.sin(an), shotSpeed(pw) * (near ? 1.06 : 1), 1, hooks);
      }
      return;
    }
    if (a.k === 'check') {
      if (W.own === i) return;
      let tx = dx, ty = dy, bd = 99;
      // aim at the nearest opponent puck carrier / skater close by
      for (const q of W.pl) {
        if (q.t === p.t || q.k || q.stun > 0) continue;
        const ex = q.x + q.vx * 0.1 - p.x, ey = q.y + q.vy * 0.1 - p.y, d = hyp(ex, ey);
        const lim = W.own === q.i ? 6 : 4;
        if (d < lim && (d - (W.own === q.i ? 2 : 0)) < bd && (!hasDir || (ex * dx + ey * dy) / (d || 1) > -0.2)) { bd = d - (W.own === q.i ? 2 : 0); tx = ex; ty = ey; }
      }
      dash(W, i, tx, ty, hooks);
    }
  }

  /* ---------- engine (shared by the view and the headless tests) ---------- */
  function teamLv(st, isAI, lvOf, t) {
    let mx = 0;
    for (const s of seatsOfTeam(st, t)) if (isAI(s)) mx = Math.max(mx, lvOf(s) | 0);
    if (!mx) for (let s = 0; s < st.np; s++) if (isAI(s)) mx = Math.max(mx, lvOf(s) | 0);
    return DIFF[mx] ? mx : 2;
  }
  function newEngine(st) {
    const W = newWorld(st);
    const E = { W, st, rid: st.rid, ph: 'count', cd: FIRST_T, clk: +st.el || 0, mem: W.pl.map(() => ({ th: 0 })),
      role: W.pl.map(() => ''), icp: W.pl.map(() => ({ t: 9, x: 0, y: 0 })), chase: [-1, -1], slow: 0, scT: -1, first: true, perB: 0 };
    setWind(W, st);
    faceoff(W);
    if (st.ph === 'done') E.ph = 'done';
    else if (st.seq > 1) { E.cd = CNT_T; E.first = false; }
    return E;
  }
  function engineSet(E, st) {
    const prev = E.st; E.st = st;
    if (st.seq === prev.seq) { if (st.ph === 'done' && E.ph !== 'goal') E.ph = 'done'; return; }
    if (fin(st.el) && st.el > E.clk) E.clk = st.el;
    setWind(E.W, st);
    if (st.lg >= 0) { if (E.ph !== 'goal') { E.ph = 'goal'; E.cd = GOAL_T; E.W.own = -1; } E.scT = st.lg; }
    else if (st.ph === 'done') E.ph = 'done';
    else { faceoff(E.W); E.ph = 'count'; E.cd = BRK_T; E.first = false; E.perB = 1; }
  }
  function phaseStep(E, dt) {
    if (E.ph === 'goal' || E.ph === 'count') E.cd -= dt;
    if (E.ph === 'goal' && E.cd <= 0) {
      if (E.st.ph === 'done') { E.ph = 'done'; return 'over'; }
      faceoff(E.W); E.ph = 'count'; E.cd = CNT_T; E.perB = 0; return 'ko';
    }
    if (E.ph === 'count' && E.cd <= 0) {
      E.ph = 'play'; E.first = false; E.perB = 0;
      return 'start';
    }
    return null;
  }
  function perLen(st) { return st.len / 3; }
  /* ctl: { isAI(seat), lv(seat), inp(seat) -> {ax, ay, acts:[]} | null, hooks } */
  function tick(E, dt, ctl) {
    const W = E.W, st = E.st, np = st.np, ev = [], hooks = ctl.hooks || NOH;
    const pe = phaseStep(E, dt);
    if (pe) {
      ev.push({ type: pe });
      if (pe === 'start') {   // the referee drops the puck: it skitters a little
        const a = Math.random() * 6.283, v = 1.5 + Math.random() * 2; W.b.vx = Math.cos(a) * v; W.b.vy = Math.sin(a) * v; W.b.w = 6;
        emit(W, 11, -1, 0, 0, 0, hooks);
      }
    }
    const live = E.ph === 'play';
    const tl = [teamLv(st, ctl.isAI, ctl.lv, 0), teamLv(st, ctl.isAI, ctl.lv, 1)];
    W.catchV[0] = DIFF[tl[0]].catchV; W.catchV[1] = DIFF[tl[1]].catchV;
    if (live) { puckPath(W); assignRoles(E); }
    for (const p of W.pl) {
      p.mx = 0; p.my = 0; p.hum = 0; p.brk = 0;
      if (E.ph === 'count') { p.brk = 1; continue; }
      if (!live) { p.brk = 1; celebrate(E, p); continue; }
      if (p.k) { const D = DIFF[tl[p.t]]; p.spd = D.kSpd; aiGoalie(E, p.i, D, dt, hooks); continue; }
      const s = p.seat, human = s >= 0 && !ctl.isAI(s), inp = human ? ctl.inp(s) : null;
      if (inp) { p.hum = 1; p.spd = 1; p.sp = 1.15; p.mx = clamp(+inp.ax || 0, -1, 1); p.my = clamp(+inp.ay || 0, -1, 1); continue; }
      const lv = s >= 0 && !human ? (ctl.lv(s) | 0) : tl[p.t], D = DIFF[lv] || DIFF[2];
      p.spd = D.spd; p.sp = D.stealP;
      aiField(E, p.i, D, dt, hooks);
    }
    for (let s = 0; s < np; s++) {
      if (ctl.isAI(s)) continue;
      const inp = ctl.inp(s);
      if (inp && inp.acts && inp.acts.length) { if (live) for (const a of inp.acts) humanAct(E, s, a, hooks); inp.acts.length = 0; }
    }
    if (E.ph !== 'count') {
      const n = Math.min(80, Math.max(1, Math.ceil(dt / SUB))), h = dt / n;
      for (let k = 0; k < n; k++) {
        const g = stepWorld(W, h, hooks, E.ph === 'play');
        if (g >= 0 && E.ph === 'play') {
          const lt = W.lt >= 0 ? W.pl[W.lt] : null;
          const og = lt && lt.t !== g ? 1 : 0;
          ev.push({ type: 'goal', team: g, gs: lt && !og ? lt.i : -1, ga: !og && W.ast >= 0 && W.ast !== W.lt ? W.ast : -1, og });
          E.ph = 'goal'; E.cd = GOAL_T; E.scT = g;
          break;
        }
      }
    }
    if (E.ph === 'play') {
      E.clk += dt;
      if (st.ph === 'ot') { if (E.clk >= st.len + OT_MAX) { E.ph = 'hold'; ev.push({ type: 'time' }); } }
      else if (st.len > 0) {
        const pend = Math.min(st.len, perLen(st) * (st.per | 0 || 1));
        if (E.clk >= pend) { E.ph = 'hold'; ev.push({ type: (st.per | 0) < 3 ? 'period' : 'time' }); }
      } else if (E.clk >= CAP_T) { E.ph = 'hold'; ev.push({ type: 'time' }); }
      for (let t = 0; t < 2; t++) if (W.call[t]) { W.call[t].t -= dt; if (W.call[t].t <= 0) W.call[t] = null; }
      // a dead puck nobody goes for gets a nudge toward the middle
      const b = W.b;
      if (W.own < 0 && hyp(b.vx, b.vy) < 0.6) {
        E.slow += dt;
        let near = 99; for (const p of W.pl) if (!p.k) near = Math.min(near, hyp(p.x - b.x, p.y - b.y));
        if (E.slow > 3 && near > 3) { const tx = clamp(-b.x, -6, 6), ty = -b.y * 0.6, l = hyp(tx - b.x, ty - b.y) || 1; b.vx = (tx - b.x) / l * 9; b.vy = (ty - b.y) / l * 9; E.slow = 0; emit(W, 12, -1, 9, b.x, b.y, hooks); }
      } else E.slow = 0;
    }
    return ev;
  }

  /* ---------- coarse state ---------- */
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 2, 8);
    const ar = AR_IDS.includes(o.ar) ? o.ar : AR_IDS[U.rand(AR_IDS.length)];
    const tsO = [2, 3, 4].includes(+o.ts) ? +o.ts : 4;
    return {
      rid: 1 + U.rand(99999), n: players.map((p) => String((p && p.name) || '').slice(0, 10)), np,
      ts: Math.max(tsO, Math.ceil(np / 2)), len: [180, 300].includes(+o.len) ? +o.len : 180, ar, sd: 1 + U.rand(99999),
      wd: ARENAS[ar].wind ? windDir() : -1,
      sc: [0, 0], seq: 1, lg: -1, gs: -1, ga: -1, og: 0, el: 0, per: 1, ph: 'play', w: -1, gb: [],
    };
  }
  function windDir() { const c = [90, 270, 60, 120, 240, 300, 0, 180]; return c[U.rand(c.length)]; }
  function scoreGoal(st, team, gs, ga, og, el) {
    const n = Object.assign({}, st, { sc: [st.sc[0] | 0, st.sc[1] | 0] });
    n.sc[team]++; n.seq = (st.seq | 0) + 1; n.lg = team; n.og = og ? 1 : 0; n.el = r1(el || 0);
    const nb = 2 * st.ts + 2;
    n.gs = gs >= 0 && gs < nb ? gs | 0 : -1; n.ga = ga >= 0 && ga < nb ? ga | 0 : -1;
    n.gb = (st.gb || []).concat([n.og ? -1 : n.gs]).slice(-40);
    if (st.ph === 'ot') { n.ph = 'done'; n.w = team; }
    return n;
  }
  function nextPeriod(st, el) {
    const n = Object.assign({}, st, { seq: (st.seq | 0) + 1, lg: -1, gs: -1, ga: -1, og: 0, el: r1(el || 0), per: (st.per | 0) + 1 });
    if (ARENAS[st.ar] && ARENAS[st.ar].wind) n.wd = windDir();
    return n;
  }
  function timeUp(st, el) {
    const n = Object.assign({}, st, { seq: (st.seq | 0) + 1, lg: -1, gs: -1, ga: -1, og: 0, el: r1(el || 0) });
    const a = st.sc[0] | 0, b = st.sc[1] | 0;
    if (a !== b) { n.ph = 'done'; n.w = a > b ? 0 : 1; return n; }
    if (st.ph !== 'ot') { n.ph = 'ot'; n.per = 4; if (ARENAS[st.ar] && ARENAS[st.ar].wind) n.wd = windDir(); return n; }
    n.ph = 'done'; n.w = -1; return n;
  }
  /* host: apply an engine event to the coarse state (null = nothing to send) */
  function coarseNext(st, e, clk) {
    if (!st || st.ph === 'done') return null;
    if (e.type === 'goal') return scoreGoal(st, e.team, e.gs, e.ga, e.og, clk);
    if (e.type === 'period') return nextPeriod(st, clk);
    if (e.type === 'time') return timeUp(st, clk);
    return null;
  }
  function scorers(st) {
    const c = {};
    for (const i of st.gb || []) if (i >= 0) c[i] = (c[i] || 0) + 1;
    return Object.keys(c).map((k) => [+k, c[k]]).sort((a, b) => b[1] - a[1]);
  }
  function result(st) {
    if (!st || st.ph !== 'done') return null;
    const sc = st.sc || [0, 0];
    const top = scorers(st).slice(0, 4).map(([i, n]) => bodyName(st, i) + (n > 1 ? ' ' + n : '')).join(', ');
    const text = TEAM[0] + ' ' + sc[0] + ' : ' + sc[1] + ' ' + TEAM[1] + (st.per >= 4 ? ' (연장)' : '') + (top ? '\n득점: ' + top : '');
    if (st.w === 0 || st.w === 1) return { winners: seatsOfTeam(st, st.w), title: TEAM[st.w] + ' 팀 승리!', text };
    return { winners: [], title: '무승부', text };
  }

  /* ---------- view ---------- */
  const TV = {
    rink: { out: '#15121d', stand: '#241d30', crowd: ['#5a4a6a', '#7a5a4a', '#3a4a6a', '#8a7a5a'], board: '#f1ede4', kick: '#e3ae45', ice: ['#e9f1f6', '#dbe7ef'], red: '#cf3b33', blue: '#2f62b8', crease: 'rgba(80,150,230,.35)', glass: 'rgba(200,230,255,.18)' },
    lake: { out: '#16242c', stand: '#1d3238', trees: 1, board: '#eef4f7', kick: '#cfdde6', ice: ['#b9d3e3', '#9fc0d6'], red: 'rgba(210,90,60,.75)', blue: 'rgba(40,90,160,.7)', crease: 'rgba(60,120,200,.25)', glass: 'rgba(255,255,255,0)', bank: 1 },
    storm: { out: '#1b2128', stand: '#262d36', crowd: ['#4a5260', '#5a6270', '#3a4250'], board: '#e6e9ee', kick: '#8a9aaa', ice: ['#dfe8ee', '#ccd9e2'], red: '#c0443a', blue: '#3a62a8', crease: 'rgba(80,150,230,.3)', glass: 'rgba(200,230,255,.12)' },
    small: { out: '#1c1712', stand: '#2b2218', wood: 1, board: '#b9875a', kick: '#7a5332', ice: ['#edf3f6', '#dde8ee'], red: '#cf3b33', blue: '#2f62b8', crease: 'rgba(80,150,230,.33)', glass: 'rgba(255,255,255,0)' },
    pillar: { out: '#16131c', stand: '#221c2c', crowd: ['#5a4a6a', '#6a5a4a', '#3a4a6a'], board: '#ece6da', kick: '#b07a3a', ice: ['#e6eef4', '#d6e3ec'], red: '#cf3b33', blue: '#2f62b8', crease: 'rgba(80,150,230,.35)', glass: 'rgba(200,230,255,.16)' },
    neon: { out: '#07060d', stand: '#0e0b18', crowd: ['#3a2a5a', '#2a3a5a', '#5a2a4a'], board: '#1b1730', kick: '#ff5fbf', ice: ['#151a2c', '#10152a'], red: '#ff4f8a', blue: '#3fe0ff', crease: 'rgba(63,224,255,.18)', glass: 'rgba(63,224,255,.08)', neon: 1 },
  };
  const MX = 3.4, MY = 3.4, STICK_R = 46;
  const CSS = `
.hk-act{position:absolute;right:16px;bottom:24px;width:88px;height:88px;border-radius:50%;border:2px solid rgba(242,233,216,.35);
  background:rgba(34,28,46,.8);color:#f2e9d8;font:800 17px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:2px;touch-action:none;user-select:none;-webkit-user-select:none;z-index:3;padding:0;
  box-shadow:0 4px 14px rgba(0,0,0,.45);-webkit-tap-highlight-color:transparent}
.hk-act .in{position:absolute;inset:6px;border-radius:50%;background:rgba(30,25,42,.94);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;pointer-events:none}
.hk-act small{font-size:10px;font-weight:600;opacity:.75;line-height:1}
.hk-act.own .in{background:rgba(60,40,10,.94);color:#fff3cf}
.hk-act.chk .in{background:rgba(70,22,22,.94)}
.hk-act.cd{opacity:.55}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    let st = null, E = null, lay = null, bg = null, bgKey = '', flip = false, camY = 0, shake = 0, busyHeld = false, tipT = 0, startT = 0;
    const name = (s) => (st && st.n && st.n[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const myTeam = () => { const m = me(); return m < 0 ? -1 : m % 2; };
    const myBody = () => { const m = me(); return m < 0 || !st ? -1 : seatBody(st, m); };
    const ctrlOn = () => me() >= 0 && !auto();
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    const isHumBody = (p) => p.seat >= 0 && !isAIseat(p.seat);

    /* ----- layout + camera ----- */
    function layout() {
      const w = cv.w, h = cv.h, top = 56, bot = ctrlOn() ? 150 : 12;
      const W = E ? E.W : { HW: 15, HL: 34 };
      const visH = Math.max(160, h - top - bot);
      const s = Math.max(3, Math.min(w / (2 * W.HW + 2 * MX), visH / (0.6 * (2 * W.HL + 2 * MY))));
      const cy0 = top + visH / 2, ext = W.HL + MY;
      let minC = -ext + (cy0 - top) / s, maxC = ext - (h - bot - cy0) / s;
      const scroll = minC < maxC;
      if (!scroll) { minC = maxC = 0; }
      lay = { s, top, bot, cy0, minC, maxC, scroll, cx: w / 2 };
      flip = myTeam() === 1;
      bgKey = ''; buildBg();
      showBtns();
    }
    cv.onresize = layout;
    const VX = (x) => (flip ? -x : x), VY = (y) => (flip ? -y : y);
    const SX = (x) => lay.cx + VX(x) * lay.s;
    const SY = (y) => lay.cy0 + (VY(y) - camY) * lay.s;
    function camStep(rdt, bx, by, bvy) {
      if (!lay) return;
      let tgt = VY(by) + VY(bvy) * 0.15;
      tgt = clamp(tgt, lay.minC, lay.maxC);
      camY += (tgt - camY) * Math.min(1, rdt * 4.2);
      camY = clamp(camY, lay.minC, lay.maxC);
    }

    /* ----- static rink layer (world space, unflipped) ----- */
    function buildBg() {
      if (!lay || !E) return;
      const W = E.W, ar = st.ar, k = ar + '|' + st.sd + '|' + lay.s + '|' + cv.dpr;
      if (k === bgKey && bg) return;
      bgKey = k;
      const T = TV[ar] || TV.rink, s = lay.s, dpr = cv.dpr, HW = W.HW, HL = W.HL, GL = W.GL, Wd = 2 * HW + 2 * MX, Hd = 2 * HL + 2 * MY;
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(Wd * s * dpr)); c.height = Math.max(1, Math.round(Hd * s * dpr));
      const g = c.getContext('2d');
      g.setTransform(s * dpr, 0, 0, s * dpr, (HW + MX) * s * dpr, (HL + MY) * s * dpr);
      g.fillStyle = T.out; g.fillRect(-HW - MX, -HL - MY, Wd, Hd);
      let seed = 17; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      // surroundings: stands with a crowd, snowy lake shore with trees, or a wooden backyard
      if (T.trees) {
        g.fillStyle = '#e9f0f2'; g.fillRect(-HW - MX, -HL - MY, Wd, Hd);
        for (let i = 0; i < 70; i++) { const x = -HW - MX + rnd() * Wd, y = -HL - MY + rnd() * Hd; if (Math.abs(x) < HW + 0.5 && Math.abs(y) < HL + 0.5) continue; g.fillStyle = rnd() < 0.5 ? '#2f5a46' : '#244a3a'; g.beginPath(); g.arc(x, y, 0.7 + rnd() * 1.1, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.55)'; g.beginPath(); g.arc(x - 0.2, y - 0.2, 0.35, 0, 7); g.fill(); }
      } else if (T.wood) {
        for (let y = -HL - MY, i = 0; y < HL + MY; y += 1.2, i++) { g.fillStyle = i % 2 ? '#3a2b1c' : '#33261a'; g.fillRect(-HW - MX, y, Wd, 1.2); }
      } else {
        g.fillStyle = T.stand; g.fillRect(-HW - MX, -HL - MY, Wd, Hd);
        for (let i = 0; i < 520; i++) { const x = -HW - MX + rnd() * Wd, y = -HL - MY + rnd() * Hd; if (Math.abs(x) < HW + 1.1 && Math.abs(y) < HL + 1.1) continue; g.fillStyle = T.crowd[i % T.crowd.length]; g.beginPath(); g.arc(x, y, 0.32, 0, 7); g.fill(); }
      }
      // boards (or a snow bank)
      rrPath(g, -HW - 0.8, -HL - 0.8, 2 * HW + 1.6, 2 * HL + 1.6, W.CR + 0.8);
      g.fillStyle = T.board; g.fill();
      if (T.bank) { g.fillStyle = 'rgba(255,255,255,.8)'; for (let i = 0; i < 120; i++) { const a = rnd() * 6.283; const x = Math.cos(a) * (HW + 0.4), y = Math.sin(a) * (HL + 0.4); g.beginPath(); g.arc(clamp(x * 1.2, -HW - 0.6, HW + 0.6), clamp(y * 1.2, -HL - 0.6, HL + 0.6), 0.5 + rnd() * 0.5, 0, 7); g.fill(); } }
      g.lineWidth = 0.3; g.strokeStyle = T.kick;
      rrPath(g, -HW - 0.2, -HL - 0.2, 2 * HW + 0.4, 2 * HL + 0.4, W.CR + 0.2); g.stroke();
      // ice
      g.save(); rrPath(g, -HW, -HL, 2 * HW, 2 * HL, W.CR); g.clip();
      const ig = g.createLinearGradient(-HW, -HL, HW, HL); ig.addColorStop(0, T.ice[0]); ig.addColorStop(0.5, T.ice[1]); ig.addColorStop(1, T.ice[0]);
      g.fillStyle = ig; g.fillRect(-HW, -HL, 2 * HW, 2 * HL);
      if (ar === 'lake') {   // natural ice: dark patches + cracks
        for (let i = 0; i < 26; i++) { g.fillStyle = 'rgba(30,70,110,' + (0.05 + rnd() * 0.08) + ')'; g.beginPath(); g.ellipse(-HW + rnd() * 2 * HW, -HL + rnd() * 2 * HL, 1.5 + rnd() * 4, 1 + rnd() * 2.5, rnd() * 3, 0, 7); g.fill(); }
        g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 0.07;
        for (let i = 0; i < 16; i++) { let x = -HW + rnd() * 2 * HW, y = -HL + rnd() * 2 * HL; g.beginPath(); g.moveTo(x, y); for (let k2 = 0; k2 < 5; k2++) { x += (rnd() - 0.5) * 4; y += (rnd() - 0.5) * 4; g.lineTo(x, y); } g.stroke(); }
      }
      g.strokeStyle = T.neon ? 'rgba(63,224,255,.06)' : 'rgba(120,150,170,.18)'; g.lineWidth = 0.05;
      for (let i = 0; i < 140; i++) { const x = -HW + rnd() * 2 * HW, y = -HL + rnd() * 2 * HL, a = rnd() * 3.14, l = 1 + rnd() * 3; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); }
      // markings
      const BL = HL * 0.27, FX = HW * 0.47, FY = GL - 6.2 * HL / 34, glow = (col) => { if (T.neon) { g.shadowColor = col; g.shadowBlur = 8 * dpr; } };
      g.save();
      glow(T.red); g.fillStyle = T.red; g.fillRect(-HW, -0.22, 2 * HW, 0.44);
      g.fillStyle = 'rgba(255,255,255,.55)'; for (let x = -HW + 0.6; x < HW; x += 1.6) g.fillRect(x, -0.06, 0.7, 0.12);
      glow(T.blue); g.fillStyle = T.blue; for (const sy of [-1, 1]) g.fillRect(-HW, sy * BL - 0.22, 2 * HW, 0.44);
      g.strokeStyle = T.blue; g.lineWidth = 0.15; g.beginPath(); g.arc(0, 0, 4.2, 0, 7); g.stroke();
      g.fillStyle = T.blue; g.beginPath(); g.arc(0, 0, 0.35, 0, 7); g.fill();
      glow(T.red); g.strokeStyle = T.red; g.fillStyle = T.red;
      for (const sy of [-1, 1]) {
        g.lineWidth = 0.12; g.beginPath(); g.moveTo(-HW, sy * GL); g.lineTo(HW, sy * GL); g.stroke();
        for (const sx of [-1, 1]) {
          g.lineWidth = 0.13; g.beginPath(); g.arc(sx * FX, sy * FY, 3.4, 0, 7); g.stroke();
          g.beginPath(); g.arc(sx * FX, sy * FY, 0.4, 0, 7); g.fill();
          g.beginPath(); g.arc(sx * FX, sy * (BL - 1.6), 0.32, 0, 7); g.fill();
        }
      }
      g.restore();
      // creases
      for (const sy of [-1, 1]) {
        g.beginPath(); g.moveTo(-CRE, sy * GL); g.arc(0, sy * GL, CRE, sy > 0 ? Math.PI : 0, sy > 0 ? 2 * Math.PI : Math.PI, false); g.closePath();
        g.fillStyle = T.crease; g.fill(); g.strokeStyle = T.red; g.lineWidth = 0.1; g.stroke();
      }
      // snow patches
      for (const p of W.pat) {
        const rg = g.createRadialGradient(p[0], p[1], 0.2, p[0], p[1], p[2]);
        rg.addColorStop(0, 'rgba(255,255,255,.95)'); rg.addColorStop(0.7, 'rgba(250,252,255,.8)'); rg.addColorStop(1, 'rgba(250,252,255,0)');
        g.fillStyle = rg; g.beginPath(); g.arc(p[0], p[1], p[2], 0, 7); g.fill();
        g.fillStyle = 'rgba(170,190,205,.35)'; for (let i = 0; i < 8; i++) { g.beginPath(); g.arc(p[0] + (rnd() - 0.5) * p[2], p[1] + (rnd() - 0.5) * p[2], 0.12, 0, 7); g.fill(); }
      }
      g.restore();
      // glass reflection along the boards
      if (T.glass !== 'rgba(255,255,255,0)') { g.strokeStyle = T.glass; g.lineWidth = 0.5; rrPath(g, -HW - 1.1, -HL - 1.1, 2 * HW + 2.2, 2 * HL + 2.2, W.CR + 1.1); g.stroke(); }
      if (T.neon) { g.save(); g.shadowColor = T.kick; g.shadowBlur = 10 * dpr; g.strokeStyle = T.kick; g.lineWidth = 0.18; rrPath(g, -HW - 0.1, -HL - 0.1, 2 * HW + 0.2, 2 * HL + 0.2, W.CR + 0.1); g.stroke(); g.restore(); }
      // pillars
      for (const p of W.pil) {
        g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.arc(p[0] + 0.3, p[1] + 0.4, p[2], 0, 7); g.fill();
        const pg = g.createRadialGradient(p[0] - p[2] * 0.4, p[1] - p[2] * 0.4, 0.1, p[0], p[1], p[2]);
        pg.addColorStop(0, '#d9dde4'); pg.addColorStop(1, '#5a6070');
        g.fillStyle = pg; g.beginPath(); g.arc(p[0], p[1], p[2], 0, 7); g.fill();
        g.strokeStyle = '#e3ae45'; g.lineWidth = 0.22; g.beginPath(); g.arc(p[0], p[1], p[2] - 0.15, 0, 7); g.stroke();
      }
      bg = c;
    }

    /* ----- input: floating stick (left part) + one context button; keyboard / pad via api.input ----- */
    const locIn = { ax: 0, ay: 0, acts: [] };
    let stick = null, hold = null;
    const netA = { n: [0, 0, 0, 0], pa: [0, 0], sa: [0.5, 0, 0], ca: [0, 0] };
    function readInput() {
      let sx = 0, sy = 0;
      if (stick) {
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy);
        if (d > 5) { const m = Math.min(1, d / STICK_R); sx = dx / d * m; sy = dy / d * m; }
      }
      if (api.input && !sx && !sy) {
        const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down');
        if (kx || ky) { const m = hyp(kx, ky); sx = m > 1 ? kx / m : kx; sy = m > 1 ? ky / m : ky; }
      }
      locIn.ax = flip ? -sx : sx; locIn.ay = flip ? -sy : sy;
    }
    function doAct(k, extra) {
      if (!ctrlOn() || !E) return;
      readInput();
      const a = Object.assign({ k, dx: r2(locIn.ax), dy: r2(locIn.ay) }, extra || {});
      if (host()) { if (E.ph === 'play') locIn.acts.push(a); }
      else {
        const n = netA.n;
        if (k === 'pass') { n[0] = (n[0] + 1) % 1000; netA.pa = [a.dx, a.dy]; }
        else if (k === 'shoot') { n[1] = (n[1] + 1) % 1000; netA.sa = [r2(a.pw), a.dx, a.dy]; }
        else if (k === 'check') { n[2] = (n[2] + 1) % 1000; netA.ca = [a.dx, a.dy]; }
        else if (k === 'call') n[3] = (n[3] + 1) % 1000;
        pubT = 0;
      }
      api.buzz(k === 'shoot' ? 16 : k === 'check' ? 12 : 8);
      tipT = Math.min(tipT, 0.4);
    }
    const holdEl = () => (hold ? (performance.now() - hold.t0) / 1000 : 0);
    const chargePw = () => clamp(0.25 + (holdEl() - TAP_T * 0.6) / 0.72 * 0.75, 0.25, 1);
    function mode() {   // what the button does right now
      if (!E) return 'chk';
      const W = E.W, i = myBody();
      if (i < 0) return 'chk';
      if (W.own === i) return 'own';
      if (W.own >= 0 && W.pl[W.own].t === W.pl[i].t) return 'call';
      return 'chk';
    }
    function actDown(src) {
      if (!ctrlOn() || !E || hold) return;
      const md = src === 'shoot' ? 'own' : mode();
      if (md === 'own') hold = { t0: performance.now(), m: 'own' };
      else if (md === 'call') { doAct('call'); hold = { t0: performance.now(), m: 'call' }; }
      else doAct('check');
    }
    function actUp(src) {
      if (!hold) return;
      const h = hold, el = holdEl(); hold = null;
      if (h.m === 'own' && el < TAP_T && src !== 'shoot') doAct('pass');
      else if (h.m === 'own' || el >= TAP_T) doAct('shoot', { pw: clamp(0.25 + (el - TAP_T * 0.6) / 0.72 * 0.75, 0.25, 1) });
    }
    function onDown(e) {
      if (!ctrlOn() || !lay) return;
      const p = cv.local(e);
      e.preventDefault();
      if (p.x > cv.w * 0.62 && p.y > cv.h - lay.bot - 40) return;
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      stick = { id: e.pointerId, bx: p.x, by: p.y, x: p.x, y: p.y };
      tipT = Math.min(tipT, 0.6);
    }
    function onMove(e) {
      if (!stick || e.pointerId !== stick.id) return;
      const p = cv.local(e); stick.x = p.x; stick.y = p.y;
      const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), mx = STICK_R * 1.25;
      if (d > mx) { stick.bx = stick.x - dx / d * mx; stick.by = stick.y - dy / d * mx; }
    }
    function onUp(e) { if (stick && e.pointerId === stick.id) stick = null; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    const btnLb = L.h('span', { text: '체크' }), btnSub = L.h('small', { text: '몸싸움' });
    const btn = L.h('button', { class: 'hk-act chk', type: 'button', 'aria-label': '행동 버튼' }, L.h('span', { class: 'in' }, btnLb, btnSub));
    btn.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); try { btn.setPointerCapture(e.pointerId); } catch (er) {} actDown('btn'); });
    const bUp = () => actUp('btn');
    btn.addEventListener('pointerup', bUp); btn.addEventListener('pointercancel', bUp); btn.addEventListener('lostpointercapture', bUp);
    btn.addEventListener('contextmenu', noCtx);
    root.appendChild(btn);
    function setRing(f) {
      const c = f >= 0.98 ? '#ee6a55' : '#e3ae45';
      btn.style.background = f > 0 ? 'conic-gradient(' + c + ' ' + Math.round(f * 360) + 'deg, rgba(34,28,46,.8) 0)' : '';
    }
    function showBtns() { btn.style.display = ctrlOn() ? '' : 'none'; }
    let lastMd = '', btnVis = null;
    function syncBtns() {
      if (btnVis !== ctrlOn()) { btnVis = ctrlOn(); showBtns(); if (lay && (lay.bot > 20) !== btnVis) layout(); }
      if (!E || !ctrlOn()) return;
      const md = hold ? (hold.m === 'own' ? 'own' : 'call') : mode();
      if (md !== lastMd) {
        lastMd = md;
        btnLb.textContent = md === 'own' ? '패스·슛' : md === 'call' ? '패스 줘' : '체크';
        btnSub.textContent = md === 'own' ? '톡=패스 꾹=슛' : md === 'call' ? '꾹=원타이머' : '몸싸움';
        btn.classList.toggle('own', md === 'own'); btn.classList.toggle('chk', md === 'chk');
      }
      const p = E.W.pl[myBody()];
      btn.classList.toggle('cd', !!p && md === 'chk' && (p.tc > 0.05 || p.stun > 0));
      const el = holdEl();
      setRing(hold && el > TAP_T * 0.6 ? (chargePw() - 0.25) / 0.75 : 0);
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (!ctrlOn()) return;
      if (id === 'act' || id === 'shoot') { if (type === 'down') actDown(id); else actUp(id); return; }
      if (type !== 'down') return;
      if (id === 'pass') { const md = mode(); if (md === 'own') doAct('pass'); else if (md === 'call') doAct('call'); }
      else if (id === 'check') { if (mode() !== 'own') doAct('check'); }
    }) : null;
    const releaseAll = () => { stick = null; if (hold) { hold = null; setRing(0); } };
    window.addEventListener('blur', releaseAll);

    /* ----- effects ----- */
    const parts = [], rings = [], floats = [], conf = [], trail = [], snow = [];
    const scr = [];   // skate scratch trails per body: flat [x, y, age, ...]
    const nets = [{ a: 0, x: 0 }, { a: 0, x: 0 }];   // 0 = top goal (y −GL), 1 = bottom goal (y +GL)
    let lastSfx = {}, popT = [0, 0], banner = null, lamp = [0, 0], boardFl = null;
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function spray(x, y, n, sp, dirx, diry) {
      for (let i = 0; i < n; i++) { const a = Math.atan2(diry || 0, dirx || 0) + (Math.random() - 0.5) * 1.6, v = (sp || 4) * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, life: 0.35 + Math.random() * 0.35, c: '#ffffff', r: 0.18 + Math.random() * 0.22 }); }
      if (parts.length > 260) parts.splice(0, parts.length - 260);
    }
    const mineB = (i) => ctrlOn() && i >= 0 && i === myBody();
    const TCc = (t) => TCOL[t] || '#888';
    function fx(kind, x, y, v, i) {
      const pl = E && i >= 0 ? E.W.pl[i] : null, col = pl ? TCc(pl.t) : '#f2e9d8';
      switch (kind) {
        case 0: sfx('pop'); rings.push({ x, y, t: 0, life: 0.3, r0: 0.4, r1: 1.8, c: col }); break;
        case 1:
          sfx(v > 44 ? 'thud' : 'hit', 40); rings.push({ x, y, t: 0, life: 0.4, r0: 0.5, r1: v > 44 ? 3.6 : 2.4, c: col });
          spray(x, y, v > 44 ? 9 : 5, 6); if (v > 47) shake = Math.max(shake, 0.35);
          if (mineB(i)) api.buzz(v > 44 ? 24 : 14);
          if (v > 47) floats.push({ x, y, t: 0, life: 0.9, txt: '슬랩샷!', c: '#e3ae45' });
          break;
        case 2: sfx('chip'); spray(x, y, 6, 4); if (pl) floats.push({ x: pl.x, y: pl.y, t: 0, life: 0.9, txt: '뺏었다!', c: col }); if (mineB(i)) api.buzz(18); break;
        case 3:
          sfx('thud'); setTimeout(() => sfx('hit', 30), 40); spray(x, y, 12, 7); shake = Math.max(shake, v > 13 ? 0.6 : 0.35);
          rings.push({ x, y, t: 0, life: 0.35, r0: 0.6, r1: 3.2, c: '#fff3cf' });
          if (pl) floats.push({ x, y, t: 0, life: 1, txt: v > 13 ? '보드 체크!' : '쾅!', c: col });
          if (v > 13) boardFl = { x, y, t: 0 };
          if (mineB(i)) api.buzz(30);
          break;
        case 4: sfx('click'); if (v > 16) floats.push({ x, y, t: 0, life: 1, txt: '선방!', c: '#f2e9d8' }); rings.push({ x, y, t: 0, life: 0.3, r0: 0.5, r1: 2.4, c: '#f2e9d8' }); break;
        case 5: sfx('bounce', 70); spray(x, y, 4, 4); break;
        case 6: sfx('chip', 80); spray(x, y, 8, 6); floats.push({ x, y, t: 0, life: 0.9, txt: '골대!', c: '#e3ae45' }); shake = Math.max(shake, 0.3); break;
        case 7: sfx('whoosh', 120); if (pl) spray(pl.x, pl.y, 4, 3); break;
        case 8: sfx('bounce', 90); boardFl = { x, y, t: 0 }; if (v > 22) shake = Math.max(shake, 0.18); break;
        case 9: sfx('pop', 80); rings.push({ x, y, t: 0, life: 0.3, r0: 0.6, r1: 2.2, c: '#e3ae45' }); break;
        case 10: sfx('hit', 160); spray(x, y, 4, 3); break;
        case 11: sfx('tick'); rings.push({ x: 0, y: 0, t: 0, life: 0.45, r0: 0.3, r1: 3, c: '#f2e9d8' }); break;
        case 12: sfx('whoosh', 200); break;
      }
    }
    const hooks = {
      fx,
      net(sg, x, v) { const n = nets[sg < 0 ? 0 : 1]; n.a = Math.min(1.6, 0.5 + v / 22); n.x = x; },
      call(i) { if (mineB(i)) floats.push({ x: E.W.pl[i].x, y: E.W.pl[i].y, t: 0, life: 0.9, txt: '패스 줘!', c: '#f2e9d8' }); },
    };
    /* WebAudio goal horn + crowd (follows the app's sound switch) */
    const Snd = {
      ac: null, nb: null,
      on() { try { return !!(U.store ? U.store.get('sound', true) : true); } catch (e) { return true; } },
      ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
      horn() {
        const ac = this.ctx(); if (!ac) return;
        try {
          const t = ac.currentTime, dur = 1.6 / Math.max(1, Math.min(4, SPD())), g = ac.createGain(), f = ac.createBiquadFilter();
          f.type = 'lowpass'; f.frequency.value = 900; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.12, t + 0.06); g.gain.setValueAtTime(0.12, t + dur - 0.2); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
          f.connect(g).connect(ac.destination);
          for (const fr of [155, 196, 233]) { const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(fr, t); o.connect(f); o.start(t); o.stop(t + dur + 0.05); }
          if (!this.nb) { const n = ac.sampleRate * 1.2, b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this.nb = b; }
          const src = ac.createBufferSource(), bf = ac.createBiquadFilter(), g2 = ac.createGain();
          src.buffer = this.nb; src.loop = true; bf.type = 'bandpass'; bf.frequency.value = 900; bf.Q.value = 0.6;
          g2.gain.setValueAtTime(0.0001, t); g2.gain.exponentialRampToValueAtTime(0.1, t + 0.25); g2.gain.exponentialRampToValueAtTime(0.0001, t + dur * 1.6);
          src.connect(bf).connect(g2).connect(ac.destination); src.start(t); src.stop(t + dur * 1.6 + 0.05);
        } catch (e) {}
      },
      close() { try { if (this.ac) this.ac.close(); } catch (e) {} this.ac = null; },
    };
    function goalFx(n) {
      const t = n.lg, mt = myTeam();
      shake = 1; popT[t] = 1; lamp[t === 0 ? 0 : 1] = GOAL_T;
      Snd.horn(); setTimeout(() => api.sfx(mt < 0 || mt === t ? 'win' : 'lose'), 200);
      if (mt === t) api.buzz(40); else if (mt >= 0) api.buzz(80);
      const col = TCc(t);
      for (let i = 0; i < 70; i++) conf.push({ x: cv.w * (0.2 + Math.random() * 0.6), y: lay ? lay.cy0 - 30 : 200, vx: (Math.random() - 0.5) * 420, vy: -120 - Math.random() * 360, rot: Math.random() * 7, vr: (Math.random() - 0.5) * 14, c: [col, '#e3ae45', '#f2e9d8'][i % 3], t: 0, life: 1.6 + Math.random() * 0.8 });
      let sub = '';
      if (n.og) sub = '자책골';
      else if (n.gs >= 0) sub = bodyName(n, n.gs) + ' 득점' + (n.ga >= 0 ? ' · 도움 ' + bodyName(n, n.ga) : '');
      banner = { t: '골!', sub, c: col, life: GOAL_BAN + 0.2, max: GOAL_BAN + 0.2 };
      startReplay();
    }

    /* ----- instant replay: every device records what it draws, then plays the last 2 s back in slow motion ----- */
    let REC = null, recN = 0, recHead = 0, recT = 0, rp = null, FS = 0;
    const RN = Math.ceil((RP_LEN + RP_POST + 0.6) * REC_HZ);
    function recInit() { const nb = E.W.pl.length; FS = nb * 4 + 3; REC = new Float32Array(RN * FS); recN = 0; recHead = 0; recT = 0; rp = null; }
    function recFrame() {
      const W = E.W, o = recHead * FS;
      for (let i = 0; i < W.pl.length; i++) { const p = W.pl[i], k = o + i * 4; REC[k] = p.x; REC[k + 1] = p.y; REC[k + 2] = p.a; REC[k + 3] = (p.stun > 0 ? 1 : 0) | (p.tk > 0 ? 2 : 0) | (p.bf > 0 ? 4 : 0) | (p.kt > 0 ? 8 : 0); }
      const k = o + W.pl.length * 4; REC[k] = W.b.x; REC[k + 1] = W.b.y; REC[k + 2] = W.b.rot;
      recHead = (recHead + 1) % RN; recN = Math.min(RN, recN + 1);
    }
    function startReplay() { if (REC) rp = { wait: RP_POST, t: -GOAL_BAN + RP_POST, fr: null, n: 0 }; }
    function replayGrab() {
      const n = Math.min(recN, Math.round((RP_LEN + RP_POST) * REC_HZ));
      if (n < 8) { rp = null; return; }
      const fr = new Float32Array(n * FS);
      for (let k = 0; k < n; k++) { const src = ((recHead - n + k) % RN + RN) % RN; fr.set(REC.subarray(src * FS, src * FS + FS), k * FS); }
      rp.fr = fr; rp.n = n;
    }
    const RB = { b: { x: 0, y: 0, rot: 0, vx: 0, vy: 0 }, pl: [] };
    function replayBodies() {   // interpolated frame → scratch bodies for drawing
      const W = E.W, f = clamp(rp.t * REC_HZ, 0, rp.n - 1.001), k0 = Math.floor(f), u = f - k0, a = k0 * FS, c = (k0 + 1) * FS, fr = rp.fr;
      if (RB.pl.length !== W.pl.length) RB.pl = W.pl.map((p) => ({ i: p.i, t: p.t, k: p.k, seat: p.seat, j: p.j, x: 0, y: 0, a: 0, vx: 0, vy: 0, stun: 0, tk: 0, bf: 0, kt: 0, run: 0 }));
      for (let i = 0; i < W.pl.length; i++) {
        const q = RB.pl[i], o = i * 4, nx = fr[a + o] + (fr[c + o] - fr[a + o]) * u, ny = fr[a + o + 1] + (fr[c + o + 1] - fr[a + o + 1]) * u;
        q.vx = (fr[c + o] - fr[a + o]) * REC_HZ; q.vy = (fr[c + o + 1] - fr[a + o + 1]) * REC_HZ;
        q.run += hyp(nx - q.x, ny - q.y); q.x = nx; q.y = ny;
        q.a = fr[a + o + 2] + wrapA(fr[c + o + 2] - fr[a + o + 2]) * u;
        const fl = fr[a + o + 3] | 0; q.stun = fl & 1 ? 0.1 : 0; q.tk = fl & 2 ? 0.1 : 0; q.bf = fl & 4 ? 0.1 : 0; q.kt = fl & 8 ? 0.1 : 0;
      }
      const o = W.pl.length * 4;
      RB.b.x = fr[a + o] + (fr[c + o] - fr[a + o]) * u; RB.b.y = fr[a + o + 1] + (fr[c + o + 1] - fr[a + o + 1]) * u; RB.b.rot = fr[a + o + 2];
      RB.b.vx = (fr[c + o] - fr[a + o]) * REC_HZ; RB.b.vy = (fr[c + o + 1] - fr[a + o + 1]) * REC_HZ;
      return RB;
    }

    /* ----- engine control (host / local) ----- */
    const remIn = {};
    const ctl = {
      isAI: isAIseat, lv: lvOf, hooks,
      inp(s) {
        if (isAIseat(s)) return null;
        if (localHuman(s)) return locIn;
        return remIn[s] || (remIn[s] = { ax: 0, ay: 0, acts: [], seen: null });
      },
    };
    function onEvents(ev) {
      for (const e of ev) {
        if (e.type === 'start') { startT = 0.8; api.buzz(12); }
        else if (e.type === 'over') releaseBusy();
        else if (e.type === 'goal' || e.type === 'period' || e.type === 'time') {
          const n = coarseNext(st, e, E.clk);
          if (!n) continue;
          if (n.ph === 'done') holdBusy();
          api.setState(n);
        }
      }
    }
    function holdBusy() { if (!busyHeld) { busyHeld = true; api.setBusy(true); } }
    function releaseBusy() { if (busyHeld) { busyHeld = false; api.setBusy(false); } }

    /* ----- online ----- */
    const curKey = () => (st ? st.rid + '.' + st.seq : null);
    let pubT = 0, q = 0, lastQ = -1, snapB = null, snapC = null, lastEvn = -1;
    function pollNet(now) {
      if (!api.online || !E) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) {
          const s = +k, o = rem[k];
          if (!(s >= 0 && s < st.np) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object') continue;
          const R = ctl.inp(s);
          R.ax = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0; R.ay = fin(+o.ay) ? clamp(+o.ay, -1, 1) : 0;
          const n = Array.isArray(o.n) && o.n.length >= 4 ? o.n.map((v) => v | 0) : null;
          if (!n) continue;
          if (R.seen) {
            const pa = Array.isArray(o.pa) ? o.pa : [0, 0], sa = Array.isArray(o.sa) ? o.sa : [0.5, 0, 0], ca = Array.isArray(o.ca) ? o.ca : [0, 0];
            if (n[0] !== R.seen[0]) R.acts.push({ k: 'pass', dx: +pa[0] || 0, dy: +pa[1] || 0 });
            if (n[1] !== R.seen[1]) R.acts.push({ k: 'shoot', pw: clamp(+sa[0] || 0.5, 0.2, 1), dx: +sa[1] || 0, dy: +sa[2] || 0 });
            if (n[2] !== R.seen[2]) R.acts.push({ k: 'check', dx: +ca[0] || 0, dy: +ca[1] || 0 });
            if (n[3] !== R.seen[3]) R.acts.push({ k: 'call' });
            if (R.acts.length > 6) R.acts.splice(0, R.acts.length - 6);
          }
          R.seen = n;
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== curKey() || hs.q === lastQ) return;
        lastQ = hs.q;
        const W = E.W;
        if (Array.isArray(hs.p)) W.pl.forEach((p, i) => {
          const x = +hs.p[i * 3], y = +hs.p[i * 3 + 1], a = +hs.p[i * 3 + 2];
          if (!fin(x) || !fin(y)) return;
          if (fin(p.nx) && p.nat) { const dt = (now - p.nat) / 1000; if (dt > 0.01 && dt < 0.5) { p.nvx = (x - p.nx) / dt; p.nvy = (y - p.ny) / dt; } }
          p.nx = x; p.ny = y; p.nat = now; if (fin(a)) p.na = a;
          const f = Array.isArray(hs.f) ? hs.f[i] | 0 : 0;
          p.tk = f & 1 ? 0.1 : 0; p.stun = f & 2 ? 0.1 : 0; p.bf = f & 4 ? 0.1 : 0; if (f & 8) p.kt = Math.max(p.kt, 0.15);
        });
        if (Array.isArray(hs.b) && hs.b.length >= 4 && hs.b.every(fin)) snapB = { x: hs.b[0], y: hs.b[1], vx: hs.b[2], vy: hs.b[3], at: now };
        W.own = (hs.o | 0) >= 0 && (hs.o | 0) < W.pl.length ? hs.o | 0 : -1;
        if (fin(hs.c)) snapC = { c: hs.c, at: now };
        if (Array.isArray(hs.e) && hs.e.length >= 5) {
          if (lastEvn >= 0 && hs.e[0] !== lastEvn) fx(hs.e[1] | 0, +hs.e[2] || 0, +hs.e[3] || 0, +hs.e[4] || 0, hs.e[5] == null ? -1 : hs.e[5] | 0);
          lastEvn = hs.e[0];
        }
      }
    }
    function publish(rdt) {
      if (!api.online || !E) return;
      pubT -= rdt; if (pubT > 0) return; pubT = 1 / 30;
      try {
        q = (q + 1) % 1000;
        const k = curKey(), W = E.W;
        if (api.isHost) {
          const p = [], f = [];
          for (const pl of W.pl) { p.push(r1(pl.x), r1(pl.y), r1(pl.a)); f.push((pl.tk > 0 ? 1 : 0) | (pl.stun > 0 ? 2 : 0) | (pl.bf > 0 ? 4 : 0) | (pl.kt > 0 ? 8 : 0)); }
          const b = W.b;
          api.net.hostSend({ k, q, b: [r1(b.x), r1(b.y), r1(b.vx), r1(b.vy)], o: W.own, p, f, c: r1(E.clk), e: [W.evn].concat(W.evl) });
        } else {
          if (me() < 0) return;
          readInput();
          api.net.publish({ k, q, ax: r2(locIn.ax), ay: r2(locIn.ay), n: netA.n.slice(), pa: netA.pa, sa: netA.sa, ca: netA.ca });
        }
      } catch (e) {}
    }
    /* guest: everyone moves to the host's snapshot; my own skater is predicted from my stick */
    function guestStep(dt, rdt, now) {
      const W = E.W, pe = phaseStep(E, dt);
      if (pe === 'start') { startT = 0.8; }
      if (pe === 'over') releaseBusy();
      if (E.ph === 'play') E.clk += dt;
      if (snapC) { const c = snapC.c + (E.ph === 'play' ? Math.min(0.3, (now - snapC.at) / 1000) * SPD() : 0); if (Math.abs(c - E.clk) > 0.3) E.clk = c; }
      const mi = ctrlOn() ? myBody() : -1, k = 1 - Math.exp(-rdt * 12);
      for (const p of W.pl) {
        if (!fin(p.nx)) continue;
        const age = Math.min(0.12, (now - p.nat) / 1000);
        const tx = p.nx + (p.nvx || 0) * age, ty = p.ny + (p.nvy || 0) * age;
        const ox = p.x, oy = p.y;
        if (p.i === mi && E.ph === 'play') {
          readInput(); p.mx = locIn.ax; p.my = locIn.ay;
          const n = Math.max(1, Math.ceil(dt / SUB)), h = dt / n;
          for (let j = 0; j < n; j++) predictMove(W, p, h);
          const d = hyp(tx - p.x, ty - p.y);
          if (d > 4.5) { p.x = tx; p.y = ty; } else { const kk = 1 - Math.exp(-rdt * 4); p.x += (tx - p.x) * kk; p.y += (ty - p.y) * kk; }
        } else {
          if (hyp(tx - p.x, ty - p.y) > 6) { p.x = tx; p.y = ty; } else { p.x += (tx - p.x) * k; p.y += (ty - p.y) * k; }
          if (fin(p.na)) p.a = wrapA(p.a + wrapA(p.na - p.a) * k);
          p.vx = p.nvx || 0; p.vy = p.nvy || 0;
        }
        p.run += hyp(p.x - ox, p.y - oy);
        if (p.kt > 0) p.kt -= dt;
      }
      const b = W.b;
      if (W.own >= 0) {
        const p = W.pl[W.own], reach = p.k ? GKR + 0.25 : SREACH, tx = p.x + Math.cos(p.a) * reach, ty = p.y + Math.sin(p.a) * reach, kk = Math.min(1, dt * 25);
        b.x += (tx - b.x) * kk; b.y += (ty - b.y) * kk; b.vx = p.vx; b.vy = p.vy; b.rot += (hyp(p.vx, p.vy) * 0.6 + 4) * dt;
      } else {
        const n = Math.min(40, Math.max(1, Math.ceil(dt / SUB))), h = dt / n;
        for (let j = 0; j < n; j++) puckStep(W, h, NOH, false);
        if (snapB) {
          const age = Math.min(0.15, (now - snapB.at) / 1000) * SPD();
          const tx = snapB.x + snapB.vx * age, ty = snapB.y + snapB.vy * age, d = hyp(tx - b.x, ty - b.y);
          if (d > 3.5) { b.x = tx; b.y = ty; b.vx = snapB.vx; b.vy = snapB.vy; }
          else { const kk = 1 - Math.exp(-rdt * 10); b.x += (tx - b.x) * kk; b.y += (ty - b.y) * kk; b.vx += (snapB.vx - b.vx) * kk; b.vy += (snapB.vy - b.vy) * kk; }
          if (Math.abs(b.w) < 2 && hyp(b.vx, b.vy) > 10) b.w = 10;
        }
      }
    }
    function predictMove(W, p, h) {
      let vm = (W.own === p.i ? VCAR : VMAX);
      if (W.pat.length && inPatch(W, p.x, p.y)) vm *= 0.72;
      let mx = p.mx, my = p.my; const m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
      if (p.tk > 0 || p.stun > 0) { p.vx = p.nvx || 0; p.vy = p.nvy || 0; }   // dashing / knocked over: follow the host
      else if (m > 0.08) {
        const sp = hyp(p.vx, p.vy); let ax = mx * vm - p.vx, ay = my * vm - p.vy; const al = hyp(ax, ay);
        const dot = sp > 0.5 ? (p.vx * ax + p.vy * ay) / (sp * (al || 1)) : 1, am = (dot < -0.35 ? BRK : ACC) * h;
        if (al > am) { ax *= am / al; ay *= am / al; }
        p.vx += ax; p.vy += ay;
        if (m > 0.12) turn(p, Math.atan2(my, mx), (W.own === p.i ? 8 : 12) * h);
      } else { const f = Math.exp(-GLIDE * h); p.vx *= f; p.vy *= f; }
      if (W.wx || W.wy) { p.vx += W.wx * WIND_S * h; p.vy += W.wy * WIND_S * h; }
      p.x += p.vx * h; p.y += p.vy * h;
      rrPush(W, p, PR, W.A.es); netSolid(W, p, PR); if (W.pil.length) pillarPush(W, p, PR, 0.3);
    }

    /* ----- main loop ----- */
    const lastSp = [];
    function frame(rdt, now) {
      if (!st || !E) return;
      const dt = rdt * SPD();
      pollNet(now);
      readInput();
      if (host()) onEvents(tick(E, Math.min(dt, 0.1), ctl));
      else guestStep(Math.min(dt, 0.1), rdt, now);
      if (E.ph === 'done' && busyHeld && !rp && !(banner && banner.life > 0)) releaseBusy();
      const W = E.W;
      // replay recording / playback
      if (REC) {
        if (!rp || !rp.fr) { recT += dt; while (recT >= 1 / REC_HZ) { recT -= 1 / REC_HZ; recFrame(); } }
        if (rp) {
          if (!rp.fr) { rp.wait -= dt; if (rp.wait <= 0) replayGrab(); }
          if (rp && rp.fr) { rp.t += dt * RP_SLOW; if (rp.t >= rp.n / REC_HZ) rp = null; }
          if (rp && E.ph !== 'goal' && E.ph !== 'done') rp = null;
        }
      }
      // ice effects from motion: skate scratches + spray on hard stops
      for (const p of W.pl) {
        const sp = hyp(p.vx, p.vy), ls = lastSp[p.i] || 0;
        if (dt > 0 && ls - sp > 28 * dt && ls > 6 && Math.random() < 0.6) spray(p.x, p.y, 2, 4, p.vx, p.vy);
        lastSp[p.i] = sp;
        if (sp > 4) { const a = scr[p.i] || (scr[p.i] = []); a.push(p.x, p.y, 0); if (a.length > 66) a.splice(0, 3); }
      }
      for (const a of scr) if (a) { for (let k = 2; k < a.length; k += 3) a[k] += rdt; while (a.length && a[2] > 1.4) a.splice(0, 3); }
      const b = W.b, sp = hyp(b.vx, b.vy);
      if (W.own < 0 && sp > 15) { trail.push(b.x, b.y); if (trail.length > 18) trail.splice(0, 2); } else if (trail.length) trail.splice(0, 2);
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t += rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.9; p.vy *= 0.9; if (p.t > p.life) parts.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t += rdt; if (rings[i].t > rings[i].life) rings.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t += rdt; if (floats[i].t > floats[i].life) floats.splice(i, 1); }
      for (let i = conf.length - 1; i >= 0; i--) { const c = conf[i]; c.t += rdt; c.x += c.vx * rdt; c.y += c.vy * rdt; c.vy += 520 * rdt; c.vx *= 0.985; c.rot += c.vr * rdt; if (c.t > c.life) conf.splice(i, 1); }
      for (const n of nets) n.a = Math.max(0, n.a - rdt * 2.2);
      lamp[0] = Math.max(0, lamp[0] - dt); lamp[1] = Math.max(0, lamp[1] - dt);
      if (boardFl) { boardFl.t += rdt; if (boardFl.t > 0.35) boardFl = null; }
      popT[0] = Math.max(0, popT[0] - rdt * 1.5); popT[1] = Math.max(0, popT[1] - rdt * 1.5);
      if (banner) { banner.life -= dt; if (banner.life <= 0) banner = null; }
      if (tipT > 0) tipT -= rdt;
      if (startT > 0) startT -= rdt;
      shake = Math.max(0, shake - rdt * 2.6);
      if (W.A.snow || W.A.wind) stepSnow(rdt);
      const vb = rp && rp.fr ? replayBodies().b : b;
      camStep(rdt, vb.x, vb.y, vb.vy || 0);
      publish(rdt);
    }
    function stepSnow(rdt) {
      const W = E.W, heavy = !!W.A.snow, n = heavy ? 90 : 34;
      while (snow.length < n) snow.push({ x: Math.random(), y: Math.random(), z: 0.4 + Math.random() * 0.6, ph: Math.random() * 6 });
      const wx = VX(W.wx || 0.3), wy = VY(W.wy || 0.6);
      for (const f of snow) {
        f.x += (wx * (heavy ? 0.16 : 0.22) + Math.sin(f.ph) * 0.02) * f.z * rdt; f.y += (wy * 0.12 + 0.05) * f.z * rdt; f.ph += rdt * 2;
        if (f.x < -0.05) f.x += 1.1; if (f.x > 1.05) f.x -= 1.1; if (f.y > 1.05) f.y -= 1.1; if (f.y < -0.05) f.y += 1.1;
      }
    }

    /* ----- drawing ----- */
    function draw(now) {
      if (!lay || !E) return;
      cv.clear();
      const W = E.W, s = lay.s, T = TV[st.ar] || TV.rink;
      const R = rp && rp.fr ? replayBodies() : null, pl = R ? R.pl : W.pl, pk = R ? R.b : W.b;
      ctx.fillStyle = T.out; ctx.fillRect(0, 0, cv.w, cv.h);
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 7 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 7 : 0;
      ctx.save(); ctx.translate(sx, sy);
      ctx.save(); ctx.translate(SX(0), SY(0)); if (flip) ctx.rotate(Math.PI);
      ctx.drawImage(bg, -(W.HW + MX) * s, -(W.HL + MY) * s, (2 * W.HW + 2 * MX) * s, (2 * W.HL + 2 * MY) * s);
      ctx.restore();
      if (boardFl) { const k = boardFl.t / 0.35; ctx.beginPath(); ctx.arc(SX(boardFl.x), SY(boardFl.y), (1.2 + k * 2.5) * s, 0, 7); ctx.strokeStyle = 'rgba(255,243,207,' + (0.6 * (1 - k)) + ')'; ctx.lineWidth = 3; ctx.stroke(); }
      // skate scratches
      if (!R) {
        ctx.lineCap = 'round';
        for (const a of scr) {
          if (!a || a.length < 6) continue;
          for (let k = 3; k < a.length; k += 3) {
            const al = Math.max(0, 1 - a[k + 2] / 1.4) * 0.3;
            if (hyp(a[k] - a[k - 3], a[k + 1] - a[k - 2]) > 3) continue;
            ctx.beginPath(); ctx.moveTo(SX(a[k - 3]), SY(a[k - 2])); ctx.lineTo(SX(a[k]), SY(a[k + 1]));
            ctx.strokeStyle = T.neon ? 'rgba(63,224,255,' + al + ')' : 'rgba(255,255,255,' + (al * 2) + ')'; ctx.lineWidth = 1.2; ctx.stroke();
          }
        }
      }
      drawNets(W);
      // puck trail
      if (!R) for (let i = 0; i + 1 < trail.length; i += 2) {
        const a = (i / 2 + 1) / (trail.length / 2);
        ctx.beginPath(); ctx.arc(SX(trail[i]), SY(trail[i + 1]), Math.max(2, PK * s * 1.1) * (0.4 + 0.6 * a), 0, 7);
        ctx.fillStyle = T.neon ? 'rgba(255,95,191,' + (0.3 * a) + ')' : 'rgba(40,50,70,' + (0.22 * a) + ')'; ctx.fill();
      }
      for (const r of rings) {
        const k = r.t / r.life;
        ctx.beginPath(); ctx.arc(SX(r.x), SY(r.y), (r.r0 + (r.r1 - r.r0) * k) * s, 0, 7);
        ctx.strokeStyle = hexA(r.c, 0.75 * (1 - k)); ctx.lineWidth = 2; ctx.stroke();
      }
      for (const p of parts) { const k = p.t / p.life; ctx.beginPath(); ctx.arc(SX(p.x), SY(p.y), Math.max(1, p.r * s * (1 - k * 0.5)), 0, 7); ctx.fillStyle = 'rgba(255,255,255,' + (0.85 * (1 - k)) + ')'; ctx.fill(); }
      // bodies (+ puck) sorted top → bottom of the screen
      const order = pl.map((p) => p.i).sort((a, c) => VY(pl[a].y) - VY(pl[c].y));
      if (!R) for (const i of order) drawMarker(pl[i]);
      const by = VY(pk.y); let pDone = false;
      for (const i of order) {
        const p = pl[i];
        if (!pDone && VY(p.y) > by) { drawPuck(pk); pDone = true; }
        drawPlayer(p, now, !!R);
      }
      if (!pDone) drawPuck(pk);
      drawFrames(W, now);
      if (!R) for (const f of floats) {
        const k = f.t / f.life, x = SX(f.x), y = SY(f.y) - 24 - k * 22;
        ctx.save(); ctx.globalAlpha = Math.min(1, (1 - k) * 2);
        ctx.font = '800 14px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(12,9,18,.85)'; ctx.strokeText(f.txt, x, y); ctx.fillStyle = f.c; ctx.fillText(f.txt, x, y);
        ctx.restore();
      }
      ctx.restore();
      if (snow.length) drawSnow();
      if (R) drawReplayFrame(now);
      else { drawOffscreen(); drawStick(); }
      drawHud(now);
      drawBanners(now);
      for (const c of conf) {
        ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(c.rot); ctx.globalAlpha = Math.min(1, (c.life - c.t) * 2);
        ctx.fillStyle = c.c; ctx.fillRect(-4, -2.2, 8, 4.4); ctx.restore();
      }
    }
    function drawSnow() {
      const heavy = !!E.W.A.snow, wx = VX(E.W.wx || 0.3), wy = VY(E.W.wy || 0.6);
      ctx.save();
      for (const f of snow) {
        const x = f.x * cv.w, y = f.y * cv.h;
        if (heavy) { ctx.fillStyle = 'rgba(255,255,255,' + (0.35 + f.z * 0.4) + ')'; ctx.beginPath(); ctx.arc(x, y, 1 + f.z * 1.8, 0, 7); ctx.fill(); }
        else { ctx.strokeStyle = 'rgba(255,255,255,' + (0.18 + f.z * 0.2) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - wx * 18 * f.z, y - wy * 18 * f.z); ctx.stroke(); }
      }
      ctx.restore();
    }
    function goalPts(sy) {
      const W = E.W, y0 = sy * W.GL, y1 = sy * (W.GL + GD);
      return { a: [SX(-GW), SY(y0)], b: [SX(GW), SY(y0)], c: [SX(GW), SY(y1)], d: [SX(-GW), SY(y1)] };
    }
    function drawNets(W) {
      for (const sy of [-1, 1]) {
        const n = nets[sy < 0 ? 0 : 1], g = goalPts(sy), bul = n.a * GD * 0.35 * lay.s;
        const dir = Math.sign(g.d[1] - g.a[1]) || 1;
        ctx.save();
        ctx.beginPath(); ctx.moveTo(g.a[0], g.a[1]); ctx.lineTo(g.b[0], g.b[1]); ctx.lineTo(g.c[0], g.c[1]); ctx.lineTo(g.d[0], g.d[1]); ctx.closePath();
        ctx.fillStyle = 'rgba(20,24,34,.22)'; ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 1;
        const N = 7;
        for (let k = 1; k < N; k++) {
          const u = k / N, x0 = g.a[0] + (g.b[0] - g.a[0]) * u, y0 = g.a[1], x1 = g.d[0] + (g.c[0] - g.d[0]) * u;
          const wx = n.a > 0 ? Math.exp(-Math.pow((u - 0.5 - (flip ? -1 : 1) * n.x / (2 * GW)) * 4, 2)) : 0;
          ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, g.d[1] + dir * bul * wx); ctx.stroke();
        }
        for (let k = 1; k < 3; k++) { const u = k / 3, y = g.a[1] + (g.d[1] - g.a[1]) * u; ctx.beginPath(); ctx.moveTo(g.a[0], y); ctx.lineTo(g.b[0], y); ctx.stroke(); }
        ctx.restore();
      }
    }
    function drawFrames(W, now) {
      for (const sy of [-1, 1]) {
        const g = goalPts(sy), li = lamp[sy < 0 ? 0 : 1];   // top net (y<0) is team 1's own net → team 0 scores there
        ctx.save();
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = 5;
        ctx.beginPath(); ctx.moveTo(g.a[0] + 2, g.a[1] + 3); ctx.lineTo(g.d[0] + 2, g.d[1] + 3); ctx.lineTo(g.c[0] + 2, g.c[1] + 3); ctx.lineTo(g.b[0] + 2, g.b[1] + 3); ctx.stroke();
        ctx.strokeStyle = '#d8322a'; ctx.lineWidth = 3.5;
        ctx.beginPath(); ctx.moveTo(g.a[0], g.a[1]); ctx.lineTo(g.d[0], g.d[1]); ctx.lineTo(g.c[0], g.c[1]); ctx.lineTo(g.b[0], g.b[1]); ctx.stroke();
        // goal lamp behind the net
        const lx = (g.c[0] + g.d[0]) / 2, ly = g.d[1] + Math.sign(g.d[1] - g.a[1]) * 9;
        const on = li > 0 && Math.floor(now / 160) % 2 === 0;
        ctx.beginPath(); ctx.arc(lx, ly, 4.5, 0, 7); ctx.fillStyle = on ? '#ff4433' : '#5a2a2a'; ctx.fill();
        if (on) { ctx.beginPath(); ctx.arc(lx, ly, 18, 0, 7); ctx.fillStyle = 'rgba(255,60,40,.25)'; ctx.fill(); }
        ctx.restore();
      }
    }
    function drawMarker(p) {
      if (p.k || !isHumBody(p)) return;
      const x = SX(p.x), y = SY(p.y), s = lay.s, R = PR * s;
      const mine = mineB(p.i);
      ctx.save();
      ctx.beginPath(); ctx.ellipse(x, y, R * 1.6, R * 1.6, 0, 0, 7);
      ctx.strokeStyle = mine ? '#e3ae45' : P(p.seat).color; ctx.lineWidth = mine ? 2.6 : 2; ctx.globalAlpha = 0.95; ctx.stroke();
      if (mine && hold && holdEl() > TAP_T * 0.6) {
        const f = (chargePw() - 0.25) / 0.75;
        ctx.beginPath(); ctx.arc(x, y, R * 2, -Math.PI / 2, -Math.PI / 2 + f * Math.PI * 2);
        ctx.strokeStyle = f >= 0.98 ? '#ee6a55' : '#fff3cf'; ctx.lineWidth = 3.5; ctx.stroke();
      }
      ctx.restore();
    }
        function drawPlayer(p, now, rep) {
      const x = SX(p.x), y = SY(p.y), s = lay.s, R = (p.k ? GKR : PR) * s * 1.08;
      const a = p.a + (flip ? Math.PI : 0), ca = Math.cos(a), sa = Math.sin(a);
      const kit = TCc(p.t), dark = TDARK[p.t] || '#333';
      const sp = hyp(p.vx, p.vy), stride = Math.min(1, sp / 7) * Math.sin(p.run * 1.25);
      const down = p.stun > 0;
      ctx.save();
      ctx.beginPath(); ctx.ellipse(x + R * 0.25, y + R * 0.35, R * (down ? 1.5 : 1.15), R * 0.9, 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fill();
      ctx.translate(x, y); ctx.rotate(a);
      if (down) ctx.rotate(Math.sin(now / 90) * 0.15 + 0.6);
      const st2 = p.tk > 0 ? 1.22 : 1;
      ctx.scale(st2, 1);
      // skates (blades along facing)
      if (!down) {
        ctx.fillStyle = '#20202a'; ctx.strokeStyle = '#cfd6de'; ctx.lineWidth = Math.max(1, R * 0.08);
        for (const side of [-1, 1]) {
          const f = side * stride, bx2 = R * (f * 0.5), by2 = side * R * 0.42;
          ctx.beginPath(); ctx.ellipse(bx2, by2, R * 0.42, R * 0.15, side * 0.25 * Math.min(1, sp / 6), 0, 7); ctx.fill(); ctx.stroke();
        }
      }
      if (p.k) {
        // goalie: wide pads (spread in the butterfly), blocker + glove, caged mask
        const bfw = p.bf > 0 ? 1.45 : 1;
        ctx.fillStyle = '#f2efe6'; ctx.strokeStyle = dark; ctx.lineWidth = Math.max(1, R * 0.08);
        for (const side of [-1, 1]) { rrPath(ctx, R * 0.15, side * R * 0.42 * bfw - R * 0.24, R * 0.75, R * 0.48, R * 0.15); ctx.fill(); ctx.stroke(); }
        ctx.fillStyle = dark; rrPath(ctx, R * 0.25, -R * 1.15, R * 0.55, R * 0.4, R * 0.1); ctx.fill();
        ctx.beginPath(); ctx.arc(R * 0.5, R * 1.0, R * 0.32, 0, 7); ctx.fillStyle = '#e3ae45'; ctx.fill();
      }
      // body / jersey across the shoulders
      ctx.beginPath(); ctx.ellipse(-R * 0.05, 0, R * 0.6, R * 0.98, 0, 0, 7); ctx.fillStyle = kit; ctx.fill();
      ctx.lineWidth = Math.max(1, R * 0.11); ctx.strokeStyle = dark; ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.fillRect(-R * 0.42, -R * 0.9, R * 0.14, R * 1.8);
      // stick: from the right glove forward to the blade at the stick point (wound back while charging)
      if (!p.k && !down) {
        let wind = 0;
        if (mineB(p.i) && !rep && hold && holdEl() > TAP_T * 0.6) wind = (chargePw() - 0.25) / 0.75;
        const sa2 = p.kt > 0 ? -0.35 : wind * 1.9;
        const hx = R * 0.25, hy = R * 0.62, rl = SREACH / PR * R / 1.08, bxp = Math.cos(sa2) * rl, byp = Math.sin(sa2) * rl * 0.9 + R * 0.15;
        ctx.strokeStyle = '#2a2018'; ctx.lineWidth = Math.max(1.6, R * 0.17); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(bxp, byp); ctx.stroke();
        ctx.strokeStyle = '#f2efe6'; ctx.lineWidth = Math.max(1.4, R * 0.15);
        ctx.beginPath(); ctx.moveTo(bxp, byp); ctx.lineTo(bxp + Math.cos(sa2 - 1.4) * R * 0.45, byp + Math.sin(sa2 - 1.4) * R * 0.45); ctx.stroke();
        ctx.fillStyle = dark; ctx.beginPath(); ctx.arc(hx, hy, R * 0.2, 0, 7); ctx.fill();
      }
      // helmet (team dark) + visor toward the front
      ctx.beginPath(); ctx.arc(R * 0.08, 0, R * 0.44, 0, 7); ctx.fillStyle = p.k ? '#f2efe6' : dark; ctx.fill();
      ctx.beginPath(); ctx.arc(R * 0.08, 0, R * 0.44, -0.9, 0.9); ctx.strokeStyle = p.k ? '#3a3a44' : 'rgba(200,230,255,.85)'; ctx.lineWidth = Math.max(1, R * 0.12); ctx.stroke();
      if (p.k) { ctx.strokeStyle = 'rgba(40,40,50,.8)'; ctx.lineWidth = 0.8; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(R * 0.3, k * R * 0.18); ctx.lineTo(R * 0.52, k * R * 0.18); ctx.stroke(); } }
      ctx.restore();
      if (down) {
        ctx.save(); ctx.fillStyle = '#e3ae45';
        for (let k = 0; k < 3; k++) { const an = now / 160 + k * 2.1; ctx.beginPath(); ctx.arc(x + Math.cos(an) * R * 0.9, y - R * 0.3 + Math.sin(an) * R * 0.45, 1.8, 0, 7); ctx.fill(); }
        ctx.restore();
      }
      // label over people: "나" for me, names for other people (online)
      if (!p.k && isHumBody(p)) {
        const mine = mineB(p.i), txt = mine ? '나' : name(p.seat).slice(0, 6);
        ctx.save(); ctx.font = '700 11px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const tw = ctx.measureText(txt).width + 10, ty = y - R * 2 - 7;
        rrPath(ctx, x - tw / 2, ty - 8, tw, 16, 8); ctx.fillStyle = mine ? '#e3ae45' : 'rgba(23,19,31,.82)'; ctx.fill();
        ctx.fillStyle = mine ? '#2a1d05' : P(p.seat).color; ctx.fillText(txt, x, ty + 0.5);
        ctx.beginPath(); ctx.moveTo(x - 4, ty + 8); ctx.lineTo(x + 4, ty + 8); ctx.lineTo(x, ty + 12); ctx.closePath(); ctx.fillStyle = mine ? '#e3ae45' : 'rgba(23,19,31,.82)'; ctx.fill();
        ctx.restore();
      }
    }
    function drawPuck(b) {
      const x = SX(b.x), y = SY(b.y), r = Math.max(3.4, PK * lay.s * 1.25);
      const neon = !!(TV[st.ar] || {}).neon;
      ctx.save();
      ctx.beginPath(); ctx.ellipse(x + r * 0.3, y + r * 0.45, r * 1.05, r * 0.8, 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fill();
      if (neon) { ctx.shadowColor = '#ff5fbf'; ctx.shadowBlur = 10; }
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fillStyle = '#121218'; ctx.fill();
      ctx.shadowBlur = 0;
      ctx.lineWidth = Math.max(1, r * 0.22); ctx.strokeStyle = neon ? '#ff8fd0' : '#3a3a48'; ctx.stroke();
      const ro = (b.rot || 0) + (flip ? Math.PI : 0);
      ctx.strokeStyle = 'rgba(230,230,240,.75)'; ctx.lineWidth = Math.max(1, r * 0.2);
      ctx.beginPath(); ctx.arc(x, y, r * 0.5, ro, ro + 1.8); ctx.stroke();
      ctx.restore();
    }
    function drawOffscreen() {
      if (!ctrlOn()) return;
      const i = myBody(); if (!(i >= 0)) return;
      const p = E.W.pl[i], x = SX(p.x), y = SY(p.y), top = lay.top - 6, bot = cv.h - lay.bot + 10;
      if (y >= top && y <= bot) return;
      const up = y < top, ay = up ? top + 8 : bot - 8, ax = clamp(x, 20, cv.w - 20);
      ctx.save(); ctx.translate(ax, ay);
      ctx.beginPath(); ctx.moveTo(0, up ? -9 : 9); ctx.lineTo(-9, up ? 4 : -4); ctx.lineTo(9, up ? 4 : -4); ctx.closePath();
      ctx.fillStyle = '#e3ae45'; ctx.fill();
      ctx.restore();
    }
    function drawStick() {
      if (!ctrlOn()) return;
      const bx = stick ? stick.bx : 74, by = stick ? stick.by : cv.h - 80;
      ctx.save();
      ctx.globalAlpha = stick ? 0.9 : 0.45;
      ctx.beginPath(); ctx.arc(bx, by, STICK_R, 0, 7); ctx.fillStyle = 'rgba(23,19,31,.45)'; ctx.fill();
      ctx.strokeStyle = 'rgba(242,233,216,.4)'; ctx.lineWidth = 2; ctx.stroke();
      let kx = bx, ky = by;
      if (stick) { const dx = stick.x - bx, dy = stick.y - by, d = hyp(dx, dy), m = Math.min(d, STICK_R); if (d > 0) { kx = bx + dx / d * m; ky = by + dy / d * m; } }
      ctx.beginPath(); ctx.arc(kx, ky, 22, 0, 7); ctx.fillStyle = stick ? '#e3ae45' : 'rgba(242,233,216,.55)'; ctx.fill();
      if (!stick) { ctx.font = '700 12px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#2a1d05'; ctx.fillText('이동', kx, ky + 0.5); }
      ctx.restore();
    }
    function drawReplayFrame(now) {
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(0, lay.top - 2, cv.w, 10); ctx.fillRect(0, cv.h - 22, cv.w, 22);
      const x = 14, y = lay.top + 22;
      rrPath(ctx, x, y - 13, 96, 26, 13); ctx.fillStyle = 'rgba(23,19,31,.85)'; ctx.fill();
      ctx.beginPath(); ctx.arc(x + 15, y, 5, 0, 7); ctx.fillStyle = Math.floor(now / 400) % 2 ? '#ee6a55' : '#7a2a22'; ctx.fill();
      ctx.font = '800 13px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
      ctx.fillText('다시 보기', x + 26, y + 0.5);
      ctx.restore();
    }
    function fmt(t) { t = Math.max(0, Math.ceil(t)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); }
    function drawHud(now) {
      const w = cv.w, mt = myTeam() >= 0 ? myTeam() : 0, ot = 1 - mt, sc = st.sc || [0, 0];
      const pw = 200, ph = 40, x0 = (w - pw) / 2, y0 = 7;
      ctx.save();
      rrPath(ctx, x0, y0, pw, ph, 20); ctx.fillStyle = 'rgba(23,19,31,.86)'; ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.45)'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.textBaseline = 'middle';
      const side = (t, cx, chipX) => {
        ctx.beginPath(); ctx.arc(chipX, y0 + ph / 2, 7, 0, 7); ctx.fillStyle = TCc(t); ctx.fill();
        ctx.strokeStyle = 'rgba(242,233,216,.6)'; ctx.lineWidth = 1.2; ctx.stroke();
        const k = 1 + popT[t] * 0.6;
        ctx.save(); ctx.translate(cx, y0 + ph / 2 + 1); ctx.scale(k, k);
        ctx.font = '700 22px "IBM Plex Mono", ui-monospace, monospace'; ctx.textAlign = 'center';
        ctx.fillStyle = popT[t] > 0 ? TCc(t) : '#f2e9d8'; ctx.fillText(String(sc[t] | 0), 0, 0);
        ctx.restore();
      };
      side(mt, x0 + 46, x0 + 18); side(ot, x0 + pw - 46, x0 + pw - 18);
      let clock, sub;
      if (st.ph === 'ot') { clock = fmt(st.len + OT_MAX - E.clk); sub = '연장 · 골든골'; }
      else { const pl2 = perLen(st), per = clamp(st.per | 0, 1, 3); clock = fmt(pl2 * per - E.clk); sub = per + '피리어드'; }
      const low = st.ph !== 'ot' && (st.per | 0) >= 3 && st.len - E.clk < 15 && E.ph === 'play';
      ctx.font = '600 15px "IBM Plex Mono", ui-monospace, monospace'; ctx.textAlign = 'center';
      ctx.fillStyle = low ? (Math.floor(now / 300) % 2 ? '#ee6a55' : '#f2e9d8') : '#e3ae45';
      ctx.fillText(clock, w / 2, y0 + ph / 2 + 1);
      ctx.font = '700 10px "IBM Plex Sans KR", system-ui, sans-serif';
      let txt = sub;
      if (E.W.wx || E.W.wy) { const ang = Math.atan2(VY(E.W.wy), VX(E.W.wx)), ar = ['→', '↘', '↓', '↙', '←', '↖', '↑', '↗'][((Math.round(ang / (Math.PI / 4)) % 8) + 8) % 8]; txt += ' · 바람 ' + ar; }
      const tw = ctx.measureText(txt).width + 14;
      rrPath(ctx, w / 2 - tw / 2, y0 + ph + 3, tw, 16, 8); ctx.fillStyle = st.ph === 'ot' ? '#e3ae45' : 'rgba(23,19,31,.82)'; ctx.fill();
      ctx.fillStyle = st.ph === 'ot' ? '#2a1d05' : '#ab9fb8'; ctx.fillText(txt, w / 2, y0 + ph + 11.5);
      ctx.restore();
      if (lay.scroll) drawMini();
    }
    function drawMini() {
      const W = E.W, mh = 62, mw = Math.round(mh * W.HW / W.HL), x0 = cv.w - mw - 10, y0 = 9, k = mw / (2 * W.HW), ky = mh / (2 * W.HL);
      ctx.save();
      rrPath(ctx, x0 - 3, y0 - 3, mw + 6, mh + 6, 6); ctx.fillStyle = 'rgba(23,19,31,.7)'; ctx.fill();
      rrPath(ctx, x0, y0, mw, mh, 4); ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x0, y0 + mh / 2); ctx.lineTo(x0 + mw, y0 + mh / 2); ctx.strokeStyle = 'rgba(207,59,51,.6)'; ctx.stroke();
      const mp = (x, y) => [x0 + mw / 2 + VX(x) * k, y0 + mh / 2 + VY(y) * ky];
      const v0 = clamp((camY - (lay.cy0 - lay.top) / lay.s), -W.HL, W.HL), v1 = clamp((camY + (cv.h - lay.bot - lay.cy0) / lay.s), -W.HL, W.HL);
      ctx.fillStyle = 'rgba(242,233,216,.1)'; ctx.fillRect(x0, y0 + mh / 2 + v0 * ky, mw, (v1 - v0) * ky);
      for (const p of W.pl) { const [x, y] = mp(p.x, p.y); ctx.beginPath(); ctx.arc(x, y, mineB(p.i) ? 2.8 : 2, 0, 7); ctx.fillStyle = mineB(p.i) ? '#e3ae45' : TCc(p.t); ctx.fill(); }
      const [bx, by] = mp(W.b.x, W.b.y); ctx.beginPath(); ctx.arc(bx, by, 1.6, 0, 7); ctx.fillStyle = '#fff'; ctx.fill();
      ctx.restore();
    }
    function centerText(txt, sub, col, scale, cy) {
      ctx.save(); ctx.translate(cv.w / 2, cy); ctx.scale(scale, scale);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '52px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
      ctx.lineWidth = 7; ctx.strokeStyle = 'rgba(12,9,18,.8)'; ctx.strokeText(txt, 0, 0);
      ctx.fillStyle = col; ctx.fillText(txt, 0, 0);
      if (sub) { ctx.font = '700 16px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.lineWidth = 4.5; ctx.strokeText(sub, 0, 40, cv.w / scale - 30); ctx.fillStyle = '#f2e9d8'; ctx.fillText(sub, 0, 40, cv.w / scale - 30); }
      ctx.restore();
    }
    function drawBanners(now) {
      const cy = lay.top + (cv.h - lay.top - lay.bot) * 0.3;
      if (banner && banner.life > 0) {
        const k = 1 - banner.life / banner.max, sc = k < 0.15 ? 0.6 + k / 0.15 * 0.6 : 1.2 - Math.min(0.2, (k - 0.15) * 0.6);
        ctx.save(); ctx.globalAlpha = Math.min(1, banner.life * 3); centerText(banner.t, banner.sub, banner.c, sc, cy); ctx.restore();
      } else if (E.ph === 'count') {
        if (E.perB && E.cd > 1) {
          if (st.ph === 'ot') centerText('연장전!', '먼저 넣는 팀이 이겨요', '#e3ae45', 0.9, cy);
          else centerText((st.per | 0) + '피리어드', '가운데에서 페이스오프', '#f2e9d8', 0.85, cy);
        } else if (E.first && E.cd <= 3) { const n = Math.ceil(E.cd); centerText(String(n), null, '#f2e9d8', 1 + (E.cd % 1) * 0.3, cy); }
        else if (!E.first) centerText('페이스오프', null, '#f2e9d8', 0.75, cy);
        else centerText('준비', null, '#f2e9d8', 0.9, cy);
      } else if (E.ph === 'play' && startT > 0) {
        ctx.save(); ctx.globalAlpha = Math.min(1, startT * 2); centerText('드롭!', null, '#e3ae45', 0.9, cy); ctx.restore();
      } else if ((E.ph === 'done' || E.ph === 'hold') && !(rp && rp.fr)) {
        const w = st.w;
        if (st.ph === 'done') centerText('경기 종료', w >= 0 ? TEAM[w] + ' 팀 승리' : '무승부', '#e3ae45', 0.85, cy);
      }
      if (tipT > 0 && ctrlOn()) {
        const pc = !!window.LOUNGE_DESKTOP || matchMedia('(pointer:fine)').matches;
        const lines = ['왼쪽 엄지: 끌어서 스케이트 (미끄러져요!)', '퍽 있을 때 버튼: 톡 = 패스, 꾹 = 슛', '퍽 없을 때 버튼: 체크(몸싸움)로 뺏기', '내 팀은 ' + TEAM[myTeam()] + ' · 위쪽 골에 넣어요'];
        if (pc) lines.push('PC: 방향키·WASD, 스페이스 = 버튼');
        ctx.save(); ctx.globalAlpha = Math.min(1, tipT * 2);
        ctx.font = '600 13px "IBM Plex Sans KR", system-ui, sans-serif';
        let mw = 0; for (const l of lines) mw = Math.max(mw, ctx.measureText(l).width);
        const bw = Math.min(cv.w - 20, mw + 28), bh = lines.length * 21 + 18, bx = (cv.w - bw) / 2, by = Math.min(cv.h - lay.bot - bh - 8, cy + 56);
        rrPath(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(23,19,31,.9)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        lines.forEach((l, k) => { ctx.fillStyle = k === 0 ? '#e3ae45' : '#f2e9d8'; ctx.fillText(l, cv.w / 2, by + 19 + k * 21, bw - 14); });
        ctx.restore();
      }
    }

    const stopLoop = U.loop((rdt, now) => {
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); syncBtns(); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (!E || E.rid !== next.rid) {
          E = newEngine(next); camY = 0; releaseBusy(); banner = null; conf.length = 0; snow.length = 0; scr.length = 0;
          recInit();
          tipT = me() >= 0 && !auto() && next.seq === 1 ? FIRST_T / SPD() + 1.4 : 0;
          layout();
          return;
        }
        const goal = prev && next.seq !== prev.seq && next.lg >= 0;
        engineSet(E, next);
        if (goal) { goalFx(next); if (next.ph === 'done') holdBusy(); }
        else if (prev && next.ph === 'ot' && prev.ph !== 'ot') { sfx('whoosh'); api.toast('동점! 연장전 — 골든골'); }
        else if (prev && next.per !== prev.per && next.ph !== 'done') { sfx('tick'); if (next.wd !== prev.wd && next.wd >= 0) api.toast('바람 방향이 바뀌었어요'); }
        if (next.ph === 'done' && !goal && prev && prev.ph !== 'done') { api.sfx('tick'); Snd.horn(); }
        if ((myTeam() === 1) !== flip) layout(); else buildBg();
      },
      destroy() {
        stopLoop();
        releaseBusy();
        if (offIn) offIn();
        Snd.close();
        window.removeEventListener('blur', releaseAll);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        btn.remove();
        styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ E, st, lay, flip, camY, locIn, remIn, rp }),
    };
  }

  /* ---------- small drawing helpers ---------- */
  function rrPath(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  L.register({
    id: 'hockey', name: '아이스하키 4:4', tag: '실시간 팀 하키', cat: '스포츠',
    blurb: '미끄러지는 얼음 위에서 퍽을 몰고, 패스하고, 슛! 몸싸움으로 뺏기도 해요. 최대 8명 팀전, 빈자리와 골리는 AI. 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#1d4a6e',
    icon: '<rect x="6" y="6" width="44" height="44" rx="14" fill="none" stroke="currentColor" stroke-width="3"/><path d="M6 28h44" stroke="currentColor" stroke-width="2" opacity=".5"/><path d="M15 12l14 26h7" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M41 12l-10 22" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" opacity=".7"/><ellipse cx="22" cy="42" rx="5" ry="2.6" fill="currentColor"/>',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 8, hidden: false, realtime: true, aiDelay: 0,
    maxPlayersIf: (o) => 2 * ([2, 3, 4].includes(+(o && o.ts)) ? +o.ts : 4),
    options: [
      { id: 'ts', label: '팀 인원', choices: [{ v: 4, label: '4:4' }, { v: 3, label: '3:3' }, { v: 2, label: '2:2' }], def: 4 },
      { id: 'len', label: '경기 시간', choices: [{ v: 180, label: '3분' }, { v: 300, label: '5분' }], def: 180 },
      { id: 'ar', label: '링크', choices: [{ v: 'rand', label: '무작위' }, { v: 'rink', label: '실내 링크' }, { v: 'lake', label: '호수 빙판(바람)' }, { v: 'storm', label: '눈보라' }, { v: 'small', label: '작은 링크' }, { v: 'pillar', label: '기둥 링크' }, { v: 'neon', label: '네온 탄력 링크' }], def: 'rand' },
    ],
    controls: [
      { id: 'up', label: '위로 스케이트', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 스케이트', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 스케이트', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 스케이트', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'act', label: '행동 (톡 = 패스 · 꾹 = 슛 / 퍽 없으면 체크)', keys: ['Space', 'KeyJ'], pad: ['a', 'rt'] },
      { id: 'pass', label: '패스 (퍽 없으면 패스 달라고 하기)', keys: ['KeyK', 'KeyZ'], pad: ['x'] },
      { id: 'shoot', label: '슛 (길게 누를수록 세게)', keys: ['KeyL', 'KeyX'], pad: ['b'] },
      { id: 'check', label: '체크 (몸싸움)', keys: ['KeyU', 'ShiftLeft'], pad: ['y', 'lt'] },
    ],
    quick: [
      '퍽을 상대 골(화면 위쪽)에 넣으면 1골! 내 골은 항상 아래쪽이에요.',
      '왼쪽 엄지로 스케이트, 오른쪽 버튼 하나로: 퍽 있으면 톡 = 패스 · 꾹 = 슛, 없으면 체크(몸싸움).',
      '3피리어드가 끝났을 때 골이 많은 팀 승리(동점이면 골든골 연장).',
    ],
    rules: [
      { h: '목표', p: [
        '얼음 위에서 하는 팀 경기예요. 검은 원반(퍽)을 상대 골망에 넣으면 1골.',
        '내 팀 골은 화면에서 항상 아래쪽, 공격 방향은 위쪽이에요. 팀은 빨강·파랑 두 팀.',
        '한 팀은 스케이터 4명(옵션: 3명·2명) + 골리(골키퍼) 1명. 골리는 자동으로 움직여요.',
      ] },
      { h: '조작 (터치)', p: [
        '화면 왼쪽 아래에 엄지를 대고 끌면 그 방향으로 스케이트를 타요(손을 댄 곳이 조이스틱 중심).',
        '얼음이라 손을 떼도 쭉 미끄러져요. 빨리 서려면 반대쪽으로 당기세요(얼음 가루가 튀며 멈춰요).',
        '퍽에 스틱이 닿으면 자동으로 스틱에 붙어요(퍽 몰기). 퍽을 가진 동안은 조금 느려요.',
        '오른쪽 버튼 하나로 다 해요 — 퍽이 있을 때: 톡 누르면 「패스」(스틱 방향의 동료에게), 꾹 누르고 있으면 버튼 둘레가 차오르며 힘이 모이고 떼는 순간 「슛」.',
        '퍽이 없을 때: 「체크」 — 짧게 돌진해서 상대와 부딪히면 상대가 넘어지고 퍽이 튀어나와요. 빗나가면 잠깐 휘청이고, 1초 뒤에 다시 쓸 수 있어요.',
        '우리 팀 동료가 퍽을 가졌을 때는 버튼이 「패스 줘」로 바뀌어요. 누르고 있다가 퍽이 오는 순간 떼면 원타이머 슛!',
        '슛은 조이스틱 방향으로 나가는데, 골 쪽을 향하면 골망 안쪽으로 살짝 맞춰 줘요. 조이스틱을 놓고 쏘면 골리 반대쪽 구석을 노려요.',
        '내 선수는 금색 동그라미와 「나」 표시. 화면 밖에 있으면 가장자리에 금색 화살표가 떠요.',
        'PC: 방향키·WASD(왼스틱) 이동, 스페이스·J = 버튼(톡/꾹), K 패스, L 슛, U·Shift 체크. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '경기 규칙', p: [
        '링크는 벽(보드)으로 둘러싸여 퍽이 밖으로 나가지 않고 튕겨요. 골대는 링크 안쪽에 있어서 골대 뒤로도 돌아갈 수 있어요(골은 앞쪽으로만 들어가요).',
        '골대 앞 파란 반원은 골리 구역(크리스) — 상대 선수는 들어갈 수 없어요.',
        '각 피리어드 시작과 골이 난 뒤에는 가운데에서 페이스오프: 심판이 퍽을 떨어뜨리면 먼저 차지하는 쪽이 공격해요.',
        '골리는 느린 퍽은 잡아서 동료에게 넘기고, 빠른 슛은 몸으로 막아 튕겨내요.',
        '오프사이드·아이싱·반칙은 없어요. 체크로 넘어진 선수는 잠깐 못 움직여요.',
        '퍽이 아무도 없는 곳에 오래 멈춰 있으면 가운데 쪽으로 살짝 밀어 줘요.',
        '골이 나면 골 장면을 느리게 다시 보여 줘요(다시 보기).',
      ] },
      { h: '점수 · 승리', p: [
        '경기 시간(3분·5분)을 피리어드 3개로 나눠요(3분이면 1분씩). 시계는 경기가 멈춘 동안(골, 페이스오프) 멈춰요.',
        '3피리어드가 끝났을 때 골이 많은 팀이 이겨요.',
        '동점이면 연장전(골든골): 먼저 넣는 팀이 바로 승리. 2분 안에 아무도 못 넣으면 무승부예요.',
      ] },
      { h: '링크', p: [
        '실내 링크: 기본 링크. 작은 링크: 좁아서 정신없이 빨라요.',
        '호수 빙판: 바람이 퍽(조금은 선수도)을 밀어요. 바람 방향은 피리어드마다 바뀌고 위 점수판에 화살표로 보여요. 눈 둑이라 퍽이 덜 튀어요.',
        '눈보라: 하얀 눈 더미 위에서는 퍽이 금방 서고 선수도 느려져요.',
        '기둥 링크: 링크 안 쇠기둥에 퍽이 탱 하고 튕겨요(배치는 3가지 중 하나).',
        '네온 탄력 링크: 보드가 아주 잘 튕기고 퍽이 더 잘 미끄러져요.',
        '「무작위」(기본)는 매 경기 링크를 골라요.',
      ] },
      { h: '예시', p: [
        '내가 퍽을 몰고 가다 상대가 막아서면 → 조이스틱을 빈 동료 쪽으로 기울이고 버튼 톡 → 패스! → 동료가 골 앞으로 다시 주면 버튼을 꾹 눌렀다 떼서 슛!',
        '상대가 퍽을 몰고 오면 → 그쪽으로 스케이트를 타며 버튼 → 「쾅!」 체크 성공, 튀어나온 퍽을 주워요.',
        '3분이 끝났는데 2:2 동점이면 → 「연장전!」 → 먼저 한 골 넣는 팀 승리.',
      ] },
      { h: '팁', p: [
        '골리 정면보다 골대 양쪽 구석! 골리가 한쪽으로 움직였을 때 반대쪽으로 패스하면 거의 빈 골대예요.',
        '골대 뒤로 돌아가 상대를 따돌린 뒤 앞으로 나오며 쏘는 것도 좋아요.',
        '체크는 상대가 퍽을 가졌을 때 가까이서. 멀리서 쓰면 빗나가고 휘청여요.',
        '얼음이라 미리미리 방향을 바꾸세요. 급할 땐 반대로 당겨 멈추기!',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지는 AI예요. 친구와는 온라인·LAN 방에서 각자 폰으로(2~8명).',
        '사람은 자리 순서대로 빨강·파랑 팀에 번갈아 들어가고, 각자 스케이터 한 명을 조종해요. 남는 스케이터 자리는 봇이 채워요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(자리 잡기, 패스·슛 정확도, 몸싸움, 속도가 달라요). 자리 없는 봇과 골리는 그 팀 AI 중 가장 높은 난이도를 따라요(그 팀에 AI 자리가 없으면 상대 AI 기준).',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { init, newEngine, engineSet, tick, scoreGoal, nextPeriod, timeUp, coarseNext, result, newWorld, faceoff, passSpeed, DIFF, ARENAS, AR_IDS, GW, PK, seatBody, bodySeat, bodyName, arenaLayout },
  });
})();
