/* 요트 경주 — 바람 방향을 보고 뱃머리 방향과 돛을 정해, 부표를 번호 순서대로(화살표 방향) 돌고 결승선을 먼저 지나는 경주.
   모두 동시에 계획(방향·돛)하고, 다 정하면 5초 동안 함께 움직인다. 움직임은 apply에서 고정 스텝으로 끝까지 계산하고
   (last = 움직이기 전 배·바람·돌풍·계획), 뷰가 같은 시뮬로 다시 그린다. 시뮬 안에서는 + − × ÷ √ 와 직접 만든 다항식 sin만 쓴다.
   돛 각도는 바람에 맞춰 자동(그림으로 보임). 돛은 「활짝」/「반만」 — 센 바람(돌풍)에서 활짝 펴면 배가 기울어 느려진다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const D2R = Math.PI / 180, TAU = 6.283185307179586;
  const CW = 100, CH = 130;          // 코스 크기(단위 m 쯤)
  const DT = 0.05, LEG = 5, NST = 100; // 한 차례 = 5초, 0.05초 스텝
  const RATE = 70;                    // 방향 바꾸는 빠르기(°/초)
  const BR = 1.4;                     // 배 반지름(부딪힘)
  const GSPD = 3;                     // 돌풍이 바람 따라 흐르는 속도
  const RMAX = 28;                    // 부표에서 이 거리 안에서 돌아야 인정
  const ISH = 4, BSH = 16;            // 섬 바람 그늘 길이(반지름 배수), 배 바람 그늘 길이
  const MAXT = 40, AFTER = 5;         // 최대 차례, 첫 완주 뒤 남은 차례
  const KN = 1.34, WKN = 12;           // 화면 표시용 노트 환산
  const NOGO = 36;                    // 이보다 바람 쪽이면 못 감(표시용)
  const r1 = (v) => Math.round(v * 10) / 10, r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  function wrap(a) { a = a % 360; if (a > 180) a -= 360; else if (a <= -180) a += 360; return a; }
  const norm = (a) => ((a % 360) + 360) % 360;
  function sn(x) { // sin(x), 다항식 (기기마다 같은 결과)
    let u = x / TAU; u -= Math.floor(u + 0.5);
    if (u > 0.25) u = 0.5 - u; else if (u < -0.25) u = -0.5 - u;
    const y = u * TAU, y2 = y * y;
    return y * (1 - y2 / 6 * (1 - y2 / 20 * (1 - y2 / 42 * (1 - y2 / 72))));
  }
  const sinD = (d) => sn(d * D2R), cosD = (d) => sn((d + 90) * D2R);
  const brg = (dx, dy) => norm(Math.atan2(dx, -dy) / D2R); // 나침반 방위(0 = 위, 시계 방향)

  /* ---------- 배의 속도 곡선(폴라) — 바람 1.0(12노트)일 때, 바람과 뱃머리 사이 각도(°) → 속도 ---------- */
  const PA = [0, 30, 38, 45, 52, 60, 75, 90, 110, 135, 150, 165, 180];
  const PS = [0, 0, 2.4, 3.9, 4.5, 4.9, 5.4, 5.7, 5.9, 5.5, 5.0, 4.6, 4.4].map((v) => v * 1.12);
  function polar(th) {
    for (let i = 1; i < PA.length; i++) if (th <= PA[i]) return PS[i - 1] + (PS[i] - PS[i - 1]) * (th - PA[i - 1]) / (PA[i] - PA[i - 1]);
    return PS[PS.length - 1];
  }
  /* 돛의 힘: 활짝(0)은 바람 1.15 넘으면 기울어 손해, 반만(1)은 78% 힘이지만 1.7까지 버팀. 뒷바람일수록 덜 기욺 */
  const heelF = (th) => (th <= 110 ? 1 : th >= 170 ? 0.25 : 1 - 0.75 * (th - 110) / 60);
  function power(W, rf, th) {
    if (!rf) return W > 1.15 ? W - (W - 1.15) * 1.9 * heelF(th) : W;
    const w = 0.78 * W; return W > 1.7 ? w - (W - 1.7) * 1.5 * heelF(th) : w;
  }
  const over = (W, rf) => (rf ? W - 1.7 : W - 1.15);
  const bestPow = (W) => Math.max(power(W, 0, 90), power(W, 1, 90));
  /* 목표 방위로 가장 빨리 다가가는 속도(VMG) 표 — AI용 */
  const VMG = [];
  for (let b = 0; b <= 180; b++) { let m = 0.3; for (let o = -180; o <= 180; o += 2) { const v = polar(Math.abs(o)) * Math.cos((o - b) * D2R); if (v > m) m = v; } VMG.push(m); }

  /* ---------- 코스 ----------
     st: 출발·결승선 두 끝, mk: 부표(순서대로), isl: 섬 [x,y,r], g: 돌풍 [개수, 세기min, max, 반지름min, max], lu: 약풍 [개수, 세기, 반지름min, max],
     cur: 물살 [y0, y1, vx, vy], wf: 기본 바람 방향(불어오는 쪽), W: 기본 세기, sh: 차례마다 바뀌는 정도(°), rng: 최대 변화(°), wv: 세기 변화 */
  const CS = [
    { id: 'bay', name: '만 경기', sub: '잔잔한 만 · 처음 하기 좋아요', wf: 0, W: 1.0, sh: 8, rng: 20, wv: 0.08,
      st: [[30, 116], [70, 116]], mk: [[50, 16], [18, 64]], isl: [], g: [2, 1.3, 1.38, 9, 12], lu: [1, 0.62, 9, 11], cur: null,
      pal: ['#123e57', '#1b6580', '#2a86a0'], land: ['#d9c38f', '#5f9a52', '#3f7440'], par: 62 },
    { id: 'isl', name: '섬 사이', sub: '섬 뒤는 바람 그늘 · 좁은 물길', wf: 40, W: 1.0, sh: 10, rng: 24, wv: 0.08,
      st: [[24, 116], [62, 116]], mk: [[84, 18], [18, 74]], isl: [[50, 56, 10], [61, 65, 7.5], [25, 33, 6], [80, 96, 5]],
      g: [2, 1.3, 1.38, 9, 12], lu: [1, 0.62, 8, 10], cur: null,
      pal: ['#0f4a52', '#177276', '#25958f'], land: ['#e2cf98', '#4f9a55', '#2f6c3c'], par: 68 },
    { id: 'storm', name: '폭풍 전야', sub: '센 바람·돌풍 · 돛을 반만!', wf: 340, W: 1.35, sh: 13, rng: 28, wv: 0.12,
      st: [[12, 116], [50, 116]], mk: [[78, 72], [58, 14]], isl: [[30, 58, 6]], g: [3, 1.3, 1.42, 10, 14], lu: [0], cur: null,
      pal: ['#141f2a', '#22384a', '#31505f'], land: ['#a39a83', '#4d6650', '#34473a'], par: 53 },
    { id: 'strait', name: '물살 해협', sub: '가운데 물살이 서쪽으로 흘러요', wf: 270, W: 1.05, sh: 8, rng: 18, wv: 0.08,
      st: [[32, 116], [70, 116]], mk: [[16, 22], [86, 24]], isl: [[-5, 64, 15], [105, 66, 14]], g: [2, 1.3, 1.36, 9, 12], lu: [1, 0.62, 9, 11], cur: [48, 82, -1.5, 0],
      pal: ['#0f3558', '#18537c', '#246c98'], land: ['#c9b48a', '#6a8a55', '#4a6640'], par: 52, wp: 'bl' },
  ];
  CS.forEach((C) => {
    const S0 = C.st[0], S1 = C.st[1], fx = S1[0] - S0[0], fy = S1[1] - S0[1], fl = Math.sqrt(fx * fx + fy * fy);
    let nx = -fy / fl, ny = fx / fl, cx = 0, cy = 0;
    C.mk.forEach((m) => { cx += m[0]; cy += m[1]; });
    cx /= C.mk.length; cy /= C.mk.length;
    if (nx * (cx - S0[0]) + ny * (cy - S0[1]) > 0) { nx = -nx; ny = -ny; }
    C.no = [nx, ny]; C.fv = [fx, fy, fl * fl];
    const mid = [(S0[0] + S1[0]) / 2, (S0[1] + S1[1]) / 2];
    C.M = C.mk.map((m, k) => {
      const pv = k ? C.mk[k - 1] : mid, nx2 = k < C.mk.length - 1 ? C.mk[k + 1] : mid;
      let ax = m[0] - pv[0], ay = m[1] - pv[1]; const al = Math.sqrt(ax * ax + ay * ay); ax /= al; ay /= al;
      let bx = nx2[0] - m[0], by = nx2[1] - m[1]; const bl = Math.sqrt(bx * bx + by * by); bx /= bl; by /= bl;
      let ux = ax - bx, uy = ay - by; const ul = Math.sqrt(ux * ux + uy * uy) || 1; ux /= ul; uy /= ul;
      const port = wrap(brg(bx, by) - brg(ax, ay)) < 0; // 왼쪽으로 꺾음 → 부표를 왼쪽에 두고 돈다
      const pax = port ? -uy : uy, pay = port ? ux : -ux; // 다가가는 쪽
      return { x: m[0], y: m[1], ux, uy, port, sg: port ? 1 : -1, pax, pay,
        A: [m[0] + ux * 3 + pax * 7, m[1] + uy * 3 + pay * 7], E: [m[0] + ux * 3 - pax * 7, m[1] + uy * 3 - pay * 7] };
    });
  });

  function curAt(C, x, y) {
    const c = C.cur; if (!c || y <= c[0] || y >= c[1]) return null;
    const k = Math.min(1, (y - c[0]) / 6, (c[1] - y) / 6);
    return [c[2] * k, c[3] * k];
  }

  /* ---------- 한 차례(5초) 시뮬레이션 ----------
     B0: [[x, y, 방향, 속도, 다음부표, 완주시각, 돛]...], plans: [[방향, 돛] | null], only: 이 자리만 움직임(AI·미리보기), shadows: 다른 배 바람 그늘,
     ghost: only일 때 다른 배를 지금 방향·속도로 곧게 움직여 부딪힘 예상(AI) */
  function Leg(C, B0, wd, gs, T0, plans, only, shadows, ghost) {
    this.C = C; this.wf = wd[0]; this.W = wd[1]; this.tx = -sinD(wd[0]); this.ty = cosD(wd[0]);
    this.gs = gs; this.T0 = T0; this.k = 0; this.ev = []; this.cd = {}; this.sh = shadows !== false;
    this.B = B0.map((q, i) => {
      const pl = plans && plans[i];
      return { x: q[0], y: q[1], h: q[2], v: q[3], mk: q[4], ft: q[5], rf: pl ? pl[1] : q[6], th: pl ? pl[0] : q[2],
        on: !q[5] && (only == null || only < 0 || only === i), fin: !!q[5], hl: 0, ov: 0, px: q[0], py: q[1], wl: 1,
        gh: !!ghost && !q[5] && only != null && only >= 0 && only !== i };
    });
  }
  Leg.prototype.wAt = function (x, y, t, self) {
    const tx = this.tx, ty = this.ty, gs = this.gs, ds = GSPD * t;
    let f = 1;
    for (let i = 0; i < gs.length; i++) {
      const g = gs[i], dx = x - (g[0] + tx * ds), dy = y - (g[1] + ty * ds), r = g[2], d2 = dx * dx + dy * dy;
      if (d2 < r * r) { const q = 1 - Math.sqrt(d2) / r, k = q > 0.4 ? 1 : q / 0.4; f *= 1 + (g[3] - 1) * k; }
    }
    const isl = this.C.isl;
    for (let i = 0; i < isl.length; i++) {
      const o = isl[i], dx = x - o[0], dy = y - o[1], a = dx * tx + dy * ty, len = o[2] * ISH;
      if (a <= 0 || a >= len) continue;
      const lat = Math.abs(dx * ty - dy * tx), w = o[2] * (1 + 0.6 * a / len);
      if (lat >= w) continue;
      f *= 1 - 0.5 * (1 - a / len) * (lat < w * 0.6 ? 1 : (w - lat) / (w * 0.4));
    }
    if (this.sh) {
      const B = this.B;
      for (let j = 0; j < B.length; j++) {
        if (j === self) continue;
        const o = B[j]; if (o.fin) continue;
        const dx = x - o.x, dy = y - o.y, a = dx * tx + dy * ty;
        if (a <= 0.5 || a >= BSH) continue;
        const lat = Math.abs(dx * ty - dy * tx), w = 2.4 + a * 0.14;
        if (lat >= w) continue;
        f *= 1 - 0.32 * (1 - a / BSH) * (lat < w * 0.6 ? 1 : (w - lat) / (w * 0.4));
      }
    }
    return f;
  };
  Leg.prototype.cool = function (key, n) { if (this.cd[key] != null && this.k - this.cd[key] < n) return false; this.cd[key] = this.k; return true; };
  Leg.prototype.step = function () {
    const B = this.B, C = this.C, t = this.k * DT, wf = this.wf, tx = this.tx, ty = this.ty, mx = RATE * DT;
    for (let i = 0; i < B.length; i++) {
      const b = B[i]; if (!b.on) continue;
      const dh = wrap(b.th - b.h), tn = dh > mx ? mx : dh < -mx ? -mx : dh;
      const ra = wrap(b.h - wf);
      if (tn) b.h = norm(b.h + tn);
      const rb = wrap(b.h - wf);
      if (tn && (ra >= 0) !== (rb >= 0)) {
        if (Math.abs(ra) < 90) { b.v *= 0.9; this.ev.push(['tk', i, this.k]); }
        else { b.v *= 0.82; this.ev.push(['gy', i, this.k]); }
      }
      const th = rb < 0 ? -rb : rb, wl = this.W * this.wAt(b.x, b.y, t, i);
      b.wl = wl;
      const vt = polar(th) * power(wl, b.rf, th), ov = over(wl, b.rf);
      b.ov = ov > 0.03 && th < 150 ? ov : 0;
      if (!b.hl && ov > 0.12 && th < 140) { b.hl = 1; this.ev.push(['hl', i, this.k]); }
      b.v += (vt - b.v) * (vt > b.v ? DT / 1.1 : DT / 1.8);
    }
    const isl = C.isl;
    for (let i = 0; i < B.length; i++) {
      const b = B[i];
      if (b.gh) { b.x += sinD(b.h) * b.v * DT; b.y -= cosD(b.h) * b.v * DT; continue; }
      if (!b.on) continue;
      b.px = b.x; b.py = b.y;
      let vx = sinD(b.h) * b.v, vy = -cosD(b.h) * b.v;
      const c = C.cur ? curAt(C, b.x, b.y) : null;
      if (c) { vx += c[0]; vy += c[1]; }
      b.x += vx * DT; b.y += vy * DT;
      for (let j = 0; j < isl.length; j++) {
        const o = isl[j], dx = b.x - o[0], dy = b.y - o[1], rr = o[2] + BR, d2 = dx * dx + dy * dy;
        if (d2 >= rr * rr) continue;
        const d = Math.sqrt(d2) || 0.01;
        b.x = o[0] + dx / d * rr; b.y = o[1] + dy / d * rr; b.v *= 0.88;
        if (this.cool('g' + i, 20)) { b.v *= 0.5; this.ev.push(['gr', i, this.k]); }
      }
      let hit = false;
      if (b.x < BR) { b.x = BR; hit = true; } else if (b.x > CW - BR) { b.x = CW - BR; hit = true; }
      if (b.y < BR) { b.y = BR; hit = true; } else if (b.y > CH - BR) { b.y = CH - BR; hit = true; }
      if (hit) { b.v *= 0.88; if (this.cool('e' + i, 20)) { b.v *= 0.6; this.ev.push(['ed', i, this.k]); } }
    }
    // 부딪힘: 길을 비켜야 하는 배가 밀려나고 느려진다
    for (let i = 0; i < B.length; i++) {
      const a = B[i]; if (!a.on && !a.gh) continue;
      for (let j = i + 1; j < B.length; j++) {
        const b = B[j]; if ((!b.on && !b.gh) || (!a.on && !b.on)) continue;
        const dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy, m = BR * 2;
        if (d2 >= m * m) continue;
        const d = Math.sqrt(d2) || 0.01, nx = d2 ? dx / d : 1, ny = d2 ? dy / d : 0, ov = m - d;
        const g = rowGive(a, b, wf, tx, ty) ? i : j, gb = B[g], ob = g === i ? b : a, sgn = g === i ? -1 : 1;
        gb.x += nx * (ov + 0.5) * sgn; gb.y += ny * (ov + 0.5) * sgn;
        if (this.cool('c' + i + '_' + j, 30)) { gb.v *= 0.4; ob.v *= 0.92; this.ev.push(['hit', g, this.k, g === i ? j : i]); }
      }
    }
    // 부표 돌기 · 결승
    const M = C.M, S0 = C.st[0], no = C.no, fv = C.fv;
    for (let i = 0; i < B.length; i++) {
      const b = B[i]; if (!b.on) continue;
      if (b.mk < M.length) {
        const m = M[b.mk], ax = b.px - m.x, ay = b.py - m.y, bx = b.x - m.x, by = b.y - m.y;
        const c0 = (m.ux * ay - m.uy * ax) * m.sg, c1 = (m.ux * by - m.uy * bx) * m.sg;
        if (c0 > 0 && c1 <= 0 && m.ux * bx + m.uy * by > 0 && bx * bx + by * by < RMAX * RMAX) { b.mk++; this.ev.push(['rd', i, this.k, b.mk - 1]); }
      } else {
        const s0 = no[0] * (b.px - S0[0]) + no[1] * (b.py - S0[1]), s1 = no[0] * (b.x - S0[0]) + no[1] * (b.y - S0[1]);
        if (s0 < 0 && s1 >= 0) {
          const fr = s0 / (s0 - s1), ix = b.px + (b.x - b.px) * fr, iy = b.py + (b.y - b.py) * fr;
          const al = ((ix - S0[0]) * fv[0] + (iy - S0[1]) * fv[1]) / fv[2];
          if (al >= 0 && al <= 1) {
            b.x = ix; b.y = iy; b.on = false; b.fin = true;
            b.ft = Math.max(0.01, r2(this.T0 * LEG + (this.k + fr) * DT)); b.fa = al;
            this.ev.push(['fn', i, this.k]);
          }
        }
      }
    }
    this.k++;
  };
  /* 길 비키기(간단): 방향을 바꾸는 중(바람 정면)인 배 → 왼쪽에서 바람 받는 배(포트) → 같은 쪽이면 바람 위쪽 배가 비킨다 */
  function rowGive(a, b, wf, tx, ty) { // true면 a가 비킨다
    const ra = wrap(a.h - wf), rb = wrap(b.h - wf), ia = Math.abs(ra) < 32, ib = Math.abs(rb) < 32;
    if (ia !== ib) return ia;
    const sa = ra < 0, sb = rb < 0; // 오른쪽(스타보드)에서 바람
    if (sa !== sb) return !sa;
    return a.x * tx + a.y * ty <= b.x * tx + b.y * ty; // 더 바람 위쪽(windward)이 비킨다
  }
  Leg.prototype.run = function () { while (this.k < NST) this.step(); return this; };
  Leg.prototype.out = function () { return this.B.map((b) => [r1(b.x), r1(b.y), r1(b.h), r2(b.v), b.mk, b.ft, b.rf]); };

  /* ---------- 상태 ---------- */
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) * 1.414;
  function gustAt(C, kind, x, y) {
    if (kind === 'g') return [r1(x), r1(y), r1(C.g[3] + Math.random() * (C.g[4] - C.g[3])), r2(C.g[1] + Math.random() * (C.g[2] - C.g[1]))];
    return [r1(x), r1(y), r1(C.lu[2] + Math.random() * (C.lu[3] - C.lu[2])), C.lu[1]];
  }
  function spawnUpwind(C, g, tx, ty) {
    let x = 8 + Math.random() * (CW - 16), y = 8 + Math.random() * (CH - 16), n = 0;
    const r = g[2];
    while (n++ < 80 && x > -r && x < CW + r && y > -r && y < CH + r) { x -= tx * 4; y -= ty * 4; }
    g[0] = r1(x + tx * 2); g[1] = r1(y + ty * 2);
  }
  function startBoats(C, n) {
    const S0 = C.st[0], S1 = C.st[1], no = C.no, m = C.M[0], out = [], slot = U.shuffle(Array.from({ length: n }, (_, i) => i));
    const mx = (S0[0] + S1[0]) / 2 + no[0] * 5, my = (S0[1] + S1[1]) / 2 + no[1] * 5;
    const b = brg(m.A[0] - mx, m.A[1] - my), be = wrap(b - C.wf);
    const h = Math.abs(be) < 47 ? norm(C.wf + (be < 0 ? -47 : 47)) : b; // 모두 같은 방향으로 출발
    for (let i = 0; i < n; i++) {
      const f = (slot[i] + 0.5) / n, x = S0[0] + (S1[0] - S0[0]) * (0.08 + 0.84 * f) + no[0] * 5, y = S0[1] + (S1[1] - S0[1]) * (0.08 + 0.84 * f) + no[1] * 5;
      out.push([r1(x), r1(y), r1(h), 2, 0, 0, 0]);
    }
    return out;
  }
  function courseOf(opt) {
    if (opt === 'rnd' || opt == null || opt === '' || !CS[+opt]) return opt === 'rnd' || opt == null || opt === '' ? Math.floor(Math.random() * CS.length) : 0;
    return +opt;
  }
  function init(players, opts) {
    opts = opts || {};
    const c = courseOf(opts.course != null ? opts.course : 'rnd'), C = CS[c], n = players.length;
    const gs = [];
    for (let i = 0; i < C.g[0]; i++) gs.push(gustAt(C, 'g', 10 + Math.random() * 80, 8 + Math.random() * 100));
    for (let i = 0; i < (C.lu[0] || 0); i++) gs.push(gustAt(C, 'l', 10 + Math.random() * 80, 8 + Math.random() * 100));
    const b = startBoats(C, n);
    return { n, nm: players.map((p) => String(p.name || '').slice(0, 10)), c, T: 0, wd: [C.wf, C.W], ws: 0, gs, b,
      p: players.map(() => null), tr: b.map((q) => [Math.round(q[0]), Math.round(q[1])]), fz: -1, end: 0, rk: null, seq: 0, last: null };
  }
  function actor(s) {
    if (s.end) return null;
    const out = [];
    for (let i = 0; i < s.n; i++) if (!s.b[i][5] && !s.p[i]) out.push(i);
    return out.length ? out : null;
  }
  function apply(s, seat, a) {
    const list = actor(s);
    if (!list || list.indexOf(seat) < 0) throw new Error('not your turn');
    if (!a || a.type !== 'plan') throw new Error('bad action');
    const h = +a.h;
    if (!isFinite(h)) throw new Error('bad heading');
    s.p[seat] = [norm(Math.round(h)), a.r ? 1 : 0];
    if (list.length === 1) runLeg(s);
    return s;
  }
  function runLeg(s) {
    const C = CS[s.c];
    const pre = { b: s.b.map((q) => q.slice()), wd: s.wd.slice(), gs: s.gs.map((g) => g.slice()) };
    const lg = new Leg(C, pre.b, pre.wd, pre.gs, s.T, s.p, -1, true).run();
    s.b = lg.out();
    s.seq++;
    s.last = { id: s.seq, T: s.T, b: pre.b, wd: pre.wd, gs: pre.gs, p: s.p.slice() };
    for (let i = 0; i < s.n; i++) {
      if (pre.b[i][5]) continue;
      const tr = s.tr[i]; tr.push(Math.round(s.b[i][0]), Math.round(s.b[i][1]));
      while (tr.length > 14) tr.splice(0, 2);
    }
    s.T++;
    s.p = s.p.map(() => null);
    // 돌풍은 바람 따라 흘러가고, 코스를 벗어나면 바람 위쪽에서 새로
    const tx = lg.tx, ty = lg.ty;
    for (const g of s.gs) {
      g[0] = r1(g[0] + tx * GSPD * LEG); g[1] = r1(g[1] + ty * GSPD * LEG);
      if (g[0] < -g[2] || g[0] > CW + g[2] || g[1] < -g[2] || g[1] > CH + g[2]) {
        const ng = gustAt(C, g[3] >= 1 ? 'g' : 'l', 0, 0);
        g[2] = ng[2]; g[3] = ng[3];
        spawnUpwind(C, g, tx, ty);
      }
    }
    // 바람이 조금씩 돈다(기본 방향 근처로 돌아오려는 경향)
    const off = wrap(s.wd[0] - C.wf), nOff = clamp(off * 0.7 + gauss() * C.sh, -C.rng, C.rng);
    const nw = norm(Math.round(C.wf + nOff));
    s.ws = Math.round(wrap(nw - s.wd[0]));
    s.wd = [nw, r2(C.W * (1 + clamp(gauss() * C.wv, -2 * C.wv, 2 * C.wv)))];
    let fin = 0;
    for (let i = 0; i < s.n; i++) if (s.b[i][5]) fin++;
    if (fin && s.fz < 0) s.fz = s.T;
    if (fin === s.n || s.T >= MAXT || (s.fz >= 0 && s.T >= s.fz + AFTER)) { s.end = 1; s.rk = ranking(s); }
  }
  function ranking(s) {
    const C = CS[s.c], wi = windOf(s.wd), cost = s.b.map((b) => progCost(C, wi, b, s.T * LEG));
    return s.b.map((_, i) => i).sort((a, b) => {
      const A = s.b[a], B = s.b[b];
      if (A[5] && B[5]) return A[5] - B[5] || a - b;
      if (A[5] || B[5]) return A[5] ? -1 : 1;
      return B[4] - A[4] || cost[a] - cost[b] || a - b;
    });
  }
  function fmtT(t) { const m = Math.floor(t / 60), sx = t - m * 60; return m + ':' + (sx < 10 ? '0' : '') + sx.toFixed(1); }
  function result(s) {
    if (!s.end) return null;
    const C = CS[s.c], rk = s.rk || ranking(s), nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const lines = rk.map((i, k) => {
      const b = s.b[i];
      return b[5] ? (k + 1) + '등 ' + nm(i) + ' · ' + fmtT(b[5]) : '— ' + nm(i) + ' · 완주 못함 (부표 ' + b[4] + '/' + C.mk.length + ')';
    });
    if (s.n === 1) {
      const t = s.b[0][5];
      let star = '';
      if (t) star = '\n' + (t <= C.par ? '★★★ 바다의 달인!' : t <= C.par * 1.15 ? '★★☆ 아주 잘했어요' : t <= C.par * 1.4 ? '★☆☆ 완주!' : '☆☆☆ 다음엔 더 빨리!') + ' (기준 ' + fmtT(C.par) + ')';
      return { winners: t ? [0] : [], title: t ? '완주 ' + fmtT(t) : '시간 초과', text: C.name + '\n' + lines.join('\n') + star };
    }
    return { winners: [rk[0]], text: C.name + '\n' + lines.join('\n') };
  }

  /* ---------- AI: 같은 시뮬로 방향·돛 후보를 시험하고, 남은 거리를 "바람을 고려한 시간"으로 잰다 ---------- */
  function windOf(wd) { return { wf: wd[0], W: wd[1], pw: bestPow(wd[1]) }; }
  function tt(C, wi, x0, y0, x1, y1, dep) {
    const dx = x1 - x0, dy = y1 - y0, d2 = dx * dx + dy * dy;
    if (d2 < 1e-4) return 0;
    if (!dep) {
      for (const o of C.isl) {
        const t = clamp(((o[0] - x0) * dx + (o[1] - y0) * dy) / d2, 0, 1), cx = x0 + dx * t, cy = y0 + dy * t;
        let nx = cx - o[0], ny = cy - o[1]; const nl = Math.sqrt(nx * nx + ny * ny);
        if (nl >= o[2] + 3.5) continue;
        if (nl < 0.01) { nx = -dy; ny = dx; } else { nx /= nl; ny /= nl; }
        const ql = Math.sqrt(nx * nx + ny * ny); nx /= ql; ny /= ql;
        const wx = clamp(o[0] + nx * (o[2] + 6), 3, CW - 3), wy = clamp(o[1] + ny * (o[2] + 6), 3, CH - 3);
        return tt(C, wi, x0, y0, wx, wy, 1) + tt(C, wi, wx, wy, x1, y1, 1);
      }
    }
    const be = Math.round(Math.abs(wrap(brg(dx, dy) - wi.wf)));
    return Math.sqrt(d2) / (VMG[be] * wi.pw);
  }
  function markCost(C, wi, m, x, y) {
    const rx = x - m.x, ry = y - m.y, cs = (m.ux * ry - m.uy * rx) * m.sg;
    if (cs > 0) {
      const ex = m.E[0] - m.x, ey = m.E[1] - m.y, ce = (m.ux * ey - m.uy * ex) * m.sg, f = cs / (cs - ce);
      const px = rx + (ex - rx) * f, py = ry + (ey - ry) * f;
      if (m.ux * px + m.uy * py > 1) return tt(C, wi, x, y, m.E[0], m.E[1]);
    }
    return tt(C, wi, x, y, m.A[0], m.A[1]) + tt(C, wi, m.A[0], m.A[1], m.E[0], m.E[1]);
  }
  function finCost(C, wi, x, y) {
    const S0 = C.st[0], fv = C.fv, no = C.no;
    const al = clamp(((x - S0[0]) * fv[0] + (y - S0[1]) * fv[1]) / fv[2], 0.2, 0.8);
    const qx = S0[0] + fv[0] * al, qy = S0[1] + fv[1] * al, ex = qx + no[0] * 3, ey = qy + no[1] * 3;
    const sd = no[0] * (x - S0[0]) + no[1] * (y - S0[1]);
    if (sd < 0) return tt(C, wi, x, y, ex, ey);
    const ix = qx - no[0] * 6, iy = qy - no[1] * 6;
    return tt(C, wi, x, y, ix, iy) + tt(C, wi, ix, iy, ex, ey);
  }
  function progCost(C, wi, b, endT) {
    if (b[5]) return b[5] - endT;
    const x = b[0], y = b[1], k = b[4], M = C.M;
    if (k >= M.length) return finCost(C, wi, x, y);
    let c = markCost(C, wi, M[k], x, y), px = M[k].E[0], py = M[k].E[1];
    for (let j = k + 1; j < M.length; j++) { const q = M[j]; c += tt(C, wi, px, py, q.A[0], q.A[1]) + tt(C, wi, q.A[0], q.A[1], q.E[0], q.E[1]); px = q.E[0]; py = q.E[1]; }
    return c + finCost(C, wi, px, py);
  }
  const ALV = {
    1: { st: 15, nz: 9, reef: 0, sh: 0, two: 0, slop: 0.25 },
    2: { st: 5, nz: 3, reef: 1, sh: 0, gh: 1, two: 0, slop: 0 },
    3: { st: 4, nz: 0, reef: 1, sh: 1, gh: 1, two: 1, pred: 1, slop: 0 },
  };
  /* 다른 배가 이번에 할 법한 방향(어려움 AI의 예상용, 간단한 욕심쟁이 계획) */
  function guessPlan(s, j) {
    const C = CS[s.c], wi = windOf(s.wd), b = s.b[j];
    let best = null;
    for (let h = 0; h < 360; h += 10) {
      const pl = []; pl[j] = [h, b[6]];
      const lg = new Leg(C, s.b, s.wd, s.gs, s.T, pl, j, false).run(), q = lg.B[j];
      const c = progCost(C, wi, lg.out()[j], (s.T + 1) * LEG) - (q.ft ? 0 : q.v * 0.45);
      if (!best || c < best.c) best = { c, h };
    }
    return [best.h, b[6]];
  }
  function ai(s, seat, lv) {
    const K = ALV[lv] || ALV[2], C = CS[s.c], b0 = s.b[seat], wi = windOf(s.wd);
    let others = null;
    if (K.pred) { others = []; for (let j = 0; j < s.n; j++) if (j !== seat && !s.b[j][5]) others[j] = guessPlan(s, j); }
    const evalOne = (B, gs, T0, h, rf, full) => {
      let pl = [];
      if (full && others) pl = others.slice();
      pl[seat] = [h, rf];
      const lg = new Leg(C, B, s.wd, gs, T0, pl, full && others ? -1 : seat, !!K.sh, !!K.gh).run(), q = lg.B[seat];
      const o = lg.out();
      return { c: progCost(C, wi, o[seat], (T0 + 1) * LEG) - (q.ft ? (q.fa > 0.12 && q.fa < 0.88 ? 0 : -1.5) : q.v * 0.45), B: o };
    };
    const hs = [], off = K.st > 5 ? Math.random() * K.st : 0;
    for (let h = off; h < 360; h += K.st) hs.push(Math.round(h));
    hs.push(Math.round(b0[2]));
    const rfs = K.reef ? [0, 1] : [0];
    const C1 = [];
    for (const h of hs) for (const rf of rfs) { const e = evalOne(s.b, s.gs, s.T, h, rf, true); C1.push({ h, rf, c: e.c, B: e.B }); }
    C1.sort((a, b) => a.c - b.c);
    let best = C1[0];
    if (K.two) {
      const gs2 = s.gs.map((g) => [g[0] - sinD(s.wd[0]) * GSPD * LEG, g[1] + cosD(s.wd[0]) * GSPD * LEG, g[2], g[3]]);
      let bc = Infinity;
      for (const c of C1.slice(0, 6)) {
        let m2 = c.c;
        if (!c.B[seat][5]) for (let h2 = 0; h2 < 360; h2 += 15) for (const rf2 of rfs) { const e = evalOne(c.B, gs2, s.T + 1, h2, rf2); if (e.c < m2) m2 = e.c; }
        if (m2 < bc) { bc = m2; best = c; }
      }
    }
    if (K.slop && Math.random() < K.slop) best = C1[Math.min(C1.length - 1, 1 + Math.floor(Math.random() * 4))];
    return { type: 'plan', h: norm(Math.round(best.h + gauss() * K.nz)), r: best.rf };
  }

  /* ---------- 뷰 ---------- */
  function sailName(th) { return th < NOGO ? '바람 정면' : th < 58 ? '맞바람 비스듬히' : th < 80 ? '앞옆바람' : th < 115 ? '옆바람' : th < 155 ? '뒤옆바람' : '뒷바람'; }
  function rgb(c) { const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim()); const n = m ? parseInt(m[1], 16) : 0xcccccc; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgba(c, a) { const q = rgb(c); return 'rgba(' + q[0] + ',' + q[1] + ',' + q[2] + ',' + a + ')'; }
  const RSPD = 3; // 다시보기 빠르기(5초 → 1.7초)

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, M = null, tNow = 0, clock = 0;
    let anim = null, shownId = -1, safeT = 0, lastPaths = null;
    let plan = null, pv = null, drag = null, lastTickDeg = null;
    const sent = {}, floats = [], streaks = [];
    let bg = null, bgKey = '', topKey = '', botKey = '', windKey = '';
    let heelTip = false;
    let rfPref = 0;
    try { rfPref = U.store.get('sailing.rf', 0) ? 1 : 0; } catch (e) {}

    const top = L.h('div', { class: 'hud top', style: { gap: '5px', padding: '6px 8px', flexWrap: 'nowrap' } });
    const windEl = L.h('div', { class: 'panel', 'data-tut': 'wind', style: { position: 'absolute', display: 'flex', alignItems: 'center', gap: '6px', padding: '4px 9px 4px 5px', pointerEvents: 'none', zIndex: 2, borderRadius: '12px' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px', flexDirection: 'column', alignItems: 'stretch', gap: '6px', flexWrap: 'nowrap' } });
    root.append(top, windEl, bot);

    const Cn = () => CS[st ? st.c : 0];
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const pname = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const SX = (x) => M.x + x * M.k, SY = (y) => M.y + y * M.k;

    function layout() {
      const w = cv.w, h = cv.h, topH = 54, botH = 124;
      const aw = w - 12, ah = h - topH - botH - 6;
      const k = Math.max(1, Math.min(aw / CW, ah / CH));
      M = { k, x: (w - CW * k) / 2, y: topH + Math.max(0, (ah - CH * k) / 2), w, h, topH, botH };
      bgKey = ''; topKey = ''; botKey = ''; windKey = '';
      const wp = st ? CS[st.c].wp : '';
      windEl.style.left = Math.round(M.x + 6) + 'px'; windEl.style.right = '';
      if (wp === 'bl') { windEl.style.top = ''; windEl.style.bottom = Math.round(h - (M.y + CH * k) + 6) + 'px'; }
      else { windEl.style.bottom = ''; windEl.style.top = Math.round(M.y + 6) + 'px'; }
      if (st) { renderTop(); renderBot(); renderWind(); }
    }
    cv.onresize = layout;

    /* ---- 지금 보여 줄 배·바람 ---- */
    function boatsNow() {
      if (anim) return anim.lg.B.map((b) => ({ x: b.x, y: b.y, h: b.h, v: b.v, mk: b.mk, ft: b.ft, rf: b.rf, ov: b.ov, fin: b.fin }));
      return st.b.map((q) => ({ x: q[0], y: q[1], h: q[2], v: q[3], mk: q[4], ft: q[5], rf: q[6], ov: 0, fin: !!q[5] }));
    }
    const windNow = () => (anim ? anim.L.wd : st.wd);
    const gustsNow = () => (anim ? anim.L.gs : st.gs);
    const gustT = () => (anim ? anim.lg.k * DT : 0);

    /* ---- 계획(사람) ---- */
    function planSeat() {
      if (!st || st.end || anim) return -1;
      const list = actor(st) || [];
      for (const s of list) {
        if (!api.canAct(s)) continue;
        const q = sent[s];
        if (q && q.T === st.T && performance.now() - q.at < 6000) continue;
        return s;
      }
      return -1;
    }
    function syncPlan() {
      const seat = planSeat();
      if (seat < 0) { if (plan) { plan = null; pv = null; } return; }
      if (!plan || plan.seat !== seat || plan.T !== st.T) {
        const b = st.b[seat];
        plan = { seat, T: st.T, h: norm(Math.round(b[2])), rf: st.T === 0 ? rfPref : b[6] };
        pv = null;
      }
    }
    function preview() {
      if (!plan) return null;
      const key = plan.seat + '|' + plan.T + '|' + plan.h + '|' + plan.rf + '|' + st.seq;
      if (pv && pv.key === key) return pv;
      const pl = []; pl[plan.seat] = [plan.h, plan.rf];
      const lg = new Leg(Cn(), st.b, st.wd, st.gs, st.T, pl, plan.seat, true);
      const b = lg.B[plan.seat], wl = lg.W * lg.wAt(b.x, b.y, 0, plan.seat);
      const pts = [[b.x, b.y]];
      while (lg.k < NST) { lg.step(); if (lg.k % 2 === 0 || lg.k === NST) pts.push([b.x, b.y]); }
      const ev = lg.ev.filter((e) => e[1] === plan.seat);
      pv = { key, pts, end: b, wl, ev, rd: ev.find((e) => e[0] === 'rd'), fn: ev.find((e) => e[0] === 'fn'), hl: ev.some((e) => e[0] === 'hl'), tk: ev.some((e) => e[0] === 'tk'), gy: ev.some((e) => e[0] === 'gy'), gr: ev.some((e) => e[0] === 'gr' || e[0] === 'ed') };
      return pv;
    }
    function setHeading(h, quiet) {
      if (!plan) return;
      h = norm(Math.round(h));
      if (h === plan.h) return;
      plan.h = h;
      const tk = Math.round(h / 5);
      if (!quiet && tk !== lastTickDeg) { api.sfx('tick'); lastTickDeg = tk; }
      botKey = ''; renderBot();
    }
    function commit() {
      if (!plan || planSeat() !== plan.seat) return;
      const seat = plan.seat;
      sent[seat] = { T: st.T, at: performance.now() };
      rfPref = plan.rf; try { U.store.set('sailing.rf', plan.rf); } catch (e) {}
      api.sfx('click'); api.buzz(14);
      const a = { type: 'plan', h: plan.h, r: plan.rf };
      plan = null; pv = null;
      api.actAs(seat, a);
      botKey = ''; renderBot(); renderTop();
    }

    /* ---- HUD ---- */
    function rankNow() {
      const C = Cn(), wi = windOf(st.wd);
      const cost = st.b.map((b) => progCost(C, wi, b, st.T * LEG));
      return st.b.map((_, i) => i).sort((a, b) => {
        const A = st.b[a], B = st.b[b];
        if (A[5] && B[5]) return A[5] - B[5];
        if (A[5] || B[5]) return A[5] ? -1 : 1;
        return B[4] - A[4] || cost[a] - cost[b] || a - b;
      });
    }
    function renderTop() {
      if (!st) { top.innerHTML = ''; return; }
      const key = [st.seq, st.p.map((p) => (p ? 1 : 0)).join(''), !!anim, st.end, M.w].join('|');
      if (key === topKey) return;
      topKey = key;
      top.innerHTML = '';
      const C = Cn(), rk = rankNow(), pos = []; rk.forEach((i, k) => { pos[i] = k + 1; });
      for (let i = 0; i < st.n; i++) {
        const b = st.b[i], p = api.players[i] || { name: '?', color: '#888' };
        const done = !!b[5], ready = !!st.p[i];
        const waiting = !st.end && !anim && !done && !ready;
        const mine = api.canAct(i);
        const prog = done ? fmtT(b[5]) : (b[4] >= C.mk.length ? '결승으로' : '부표 ' + (b[4] + 1));
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, maxWidth: '200px', padding: '4px 7px', display: 'flex', flexDirection: 'column', gap: '1px',
          borderColor: mine && waiting ? p.color : '', opacity: done && !st.end ? 0.85 : 1 } },
        L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden' } },
          L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
          L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0, flex: '1 1 auto' }, text: p.name }),
          L.h('span', { style: { flex: 'none', fontSize: '11px', color: ready || done ? '#5fd3a0' : 'var(--muted)' }, text: done ? '⚑' : ready ? '✓' : waiting ? '…' : '' })),
        L.h('div', { style: { fontSize: '11px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: 'var(--muted)', fontWeight: 600 } },
          L.h('b', { style: { color: pos[i] === 1 ? 'var(--brass)' : 'var(--ink)' }, text: st.n > 1 ? pos[i] + '위 ' : '' }), prog)));
      }
    }
    function renderWind() {
      if (!st || !M) return;
      const wd = windNow(), left = st.fz >= 0 && !st.end ? Math.max(0, st.fz + AFTER - st.T) : -1;
      const key = [wd[0], wd[1], st.ws, st.T, left, !!anim].join('|');
      if (key === windKey) return;
      windKey = key;
      windEl.innerHTML = '';
      const ar = L.h('span', { style: { width: '30px', height: '30px', flex: 'none', display: 'grid', placeItems: 'center', borderRadius: '50%', background: 'rgba(242,233,216,.1)' } });
      ar.innerHTML = '<svg viewBox="-12 -12 24 24" width="26" height="26" aria-hidden="true"><g transform="rotate(' + (wd[0] + 180) + ')"><path d="M0 -10L5.5 -1.5H1.8V10H-1.8V-1.5H-5.5Z" fill="#9fe0ff"/></g></svg>';
      const sh = !anim && st.T > 0 && Math.abs(st.ws) >= 3 ? (st.ws > 0 ? ' ↻' : ' ↺') + Math.abs(st.ws) + '°' : '';
      windEl.append(ar, L.h('div', { style: { display: 'flex', flexDirection: 'column', lineHeight: 1.15 } },
        L.h('span', { style: { fontSize: '12px', fontWeight: 800, whiteSpace: 'nowrap' } }, '바람 ', L.h('span', { class: 'mono', text: String(Math.round(wd[1] * WKN)) }), '노트'),
        L.h('span', { style: { fontSize: '10.5px', fontWeight: 600, color: left >= 0 ? '#ee6a55' : 'var(--muted)', whiteSpace: 'nowrap' }, text: left >= 0 ? '남은 ' + left + '차례' : (st.T + 1) + '번째 차례' + sh })));
    }
    function btn(label, onclick, extra) {
      return L.h('button', Object.assign({ class: 'btn', onclick(ev) { ev.stopPropagation(); onclick(); } }, extra || {}), label);
    }
    function renderBot() {
      if (!st) { bot.innerHTML = ''; return; }
      syncPlan();
      const P = plan ? preview() : null;
      let msg = '';
      if (anim) msg = '모두 함께 5초 동안 움직여요 · 탭하면 빨리';
      else if (st.end) msg = '경주 끝!';
      else if (!plan) {
        const list = actor(st) || [], nn = st.b.filter((b) => !b[5]).length;
        const mineWait = st.b.some((b, i) => api.canAct(i) && !b[5]);
        msg = (mineWait ? '다른 배를 기다려요' : (list.length === 1 ? pname(list[0]) + ' 생각 중…' : '배들이 방향을 정하는 중…')) + ' · ✓ ' + (nn - list.length) + '/' + nn;
      }
      const key = plan ? ['P', plan.seat, plan.h, plan.rf, P && P.key, M.w].join('|') : ['M', msg, M.w].join('|');
      if (key === botKey) return;
      botKey = key;
      bot.innerHTML = '';
      if (!plan) {
        bot.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', fontSize: '13px', fontWeight: 700, minHeight: '44px', padding: '6px 12px', pointerEvents: 'none', textAlign: 'center', width: '100%', maxWidth: '560px', alignSelf: 'center', boxSizing: 'border-box' } },
          L.h('span', { style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: msg })));
        return;
      }
      const C = Cn(), b = st.b[plan.seat], wd = st.wd, th = Math.abs(wrap(plan.h - wd[0]));
      const spd = P ? P.end.v : 0, nogo = th < NOGO;
      let hint = sailName(th);
      let hcol = 'var(--muted)';
      if (nogo) { hint = '바람 정면 — 못 가요! 비스듬히'; hcol = '#ee6a55'; }
      else if (P && P.fn) { hint = '결승선 통과! ⚑'; hcol = '#5fd3a0'; }
      else if (P && P.rd) { hint = (P.rd[3] + 1) + '번 부표 돌기 ✓'; hcol = '#5fd3a0'; }
      else if (P && P.gr) { hint = '부딪혀요! 방향을 바꿔요'; hcol = '#ee6a55'; }
      else if (P && P.hl && !plan.rf) { hint = '기우뚱! 돛을 반만 펴면 빨라요'; hcol = '#e3ae45'; }
      else if (P && P.tk) hint = sailName(th) + ' · 방향 전환(택)';
      else if (P && P.gy) hint = sailName(th) + ' · 돛 넘기기(자이브)';
      const multi = st.b.filter((q, i) => api.canAct(i)).length > 1;
      const row1 = L.h('div', { 'data-tut': 'aim', style: { display: 'flex', gap: '6px', alignItems: 'stretch' } },
        btn('↺', () => { setHeading(plan.h - 5); api.buzz(6); }, { 'aria-label': '왼쪽으로 5도', style: { minWidth: '52px', minHeight: '50px', fontSize: '20px', padding: '0 6px', flex: 'none' } }),
        L.h('div', { class: 'panel', style: { flex: '1 1 auto', minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: '3px 8px', gap: '1px', borderColor: col(plan.seat) } },
          L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '8px', whiteSpace: 'nowrap' } },
            multi ? L.h('span', { class: 'dot', style: { '--c': col(plan.seat), alignSelf: 'center' } }) : null,
            L.h('span', { class: 'mono', style: { fontSize: '17px', fontWeight: 700 }, text: String(plan.h).padStart(3, '0') + '°' }),
            L.h('span', { class: 'mono', style: { fontSize: '17px', fontWeight: 700, color: nogo ? '#ee6a55' : '#9fe0ff' }, text: (spd * KN).toFixed(1) }),
            L.h('span', { style: { fontSize: '11px', color: 'var(--muted)' }, text: '노트' })),
          L.h('div', { style: { fontSize: '11.5px', fontWeight: 700, color: hcol, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%' }, text: (multi ? pname(plan.seat) + ' · ' : '') + hint })),
        btn('↻', () => { setHeading(plan.h + 5); api.buzz(6); }, { 'aria-label': '오른쪽으로 5도', style: { minWidth: '52px', minHeight: '50px', fontSize: '20px', padding: '0 6px', flex: 'none' } }));
      const seg = L.h('div', { 'data-tut': 'sail', style: { display: 'flex', gap: '4px', flex: '0 0 auto' } },
        [['돛 활짝', 0], ['돛 반만', 1]].map(([t, v]) => L.h('button', { class: 'btn' + (plan.rf === v ? ' primary' : ''), 'aria-pressed': plan.rf === v ? 'true' : 'false',
          style: { minHeight: '48px', padding: '0 10px', fontSize: '13.5px', minWidth: '74px' },
          onclick(ev) { ev.stopPropagation(); if (plan.rf !== v) { plan.rf = v; api.sfx('click'); api.buzz(8); botKey = ''; renderBot(); } } }, t)));
      const go = L.h('button', { class: 'btn primary', 'data-tut': 'go', style: { flex: '1 1 auto', minHeight: '48px', fontSize: '16px', fontWeight: 800, minWidth: 0 },
        onclick(ev) { ev.stopPropagation(); commit(); } }, '출발 ▶');
      row1.style.width = '100%'; row1.style.maxWidth = '560px'; row1.style.alignSelf = 'center';
      bot.append(row1, L.h('div', { style: { display: 'flex', gap: '6px', alignItems: 'stretch', width: '100%', maxWidth: '560px', alignSelf: 'center' } }, seg, go));
      void b; void C;
    }

    /* ---- 배경(물·섬) 캐시 ---- */
    function prng(seed) { let x = seed >>> 0 || 1; return () => { x ^= x << 13; x >>>= 0; x ^= x >> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; }; }
    function buildBg() {
      const C = Cn(), key = [st.c, M.w, M.h, cv.dpr].join('|');
      if (key === bgKey && bg) return;
      bgKey = key;
      bg = document.createElement('canvas');
      bg.width = Math.round(M.w * cv.dpr); bg.height = Math.round(M.h * cv.dpr);
      const g = bg.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const P = C.pal;
      // 바깥 바다
      g.fillStyle = P[0]; g.fillRect(0, 0, M.w, M.h);
      // 코스 물
      const x0 = SX(0), y0 = SY(0), ww = CW * M.k, hh = CH * M.k;
      const gr = g.createLinearGradient(0, y0, 0, y0 + hh);
      gr.addColorStop(0, P[1]); gr.addColorStop(0.55, P[2]); gr.addColorStop(1, P[1]);
      g.fillStyle = gr; g.fillRect(x0, y0, ww, hh);
      const rad = g.createRadialGradient(x0 + ww * 0.5, y0 + hh * 0.45, 10, x0 + ww * 0.5, y0 + hh * 0.5, Math.max(ww, hh) * 0.75);
      rad.addColorStop(0, 'rgba(255,255,255,.06)'); rad.addColorStop(1, 'rgba(0,0,0,.18)');
      g.fillStyle = rad; g.fillRect(x0, y0, ww, hh);
      // 잔물결
      const rnd = prng(1234 + st.c * 77);
      g.lineCap = 'round';
      for (let i = 0; i < 520; i++) {
        const x = rnd() * M.w, y = rnd() * M.h, l = 3 + rnd() * 7;
        g.strokeStyle = 'rgba(255,255,255,' + (0.025 + rnd() * 0.05).toFixed(3) + ')'; g.lineWidth = 1;
        g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + l / 2, y - 1.6, x + l, y); g.stroke();
      }
      if (C.id === 'storm') for (let i = 0; i < 60; i++) { // 흰 파도
        const x = x0 + rnd() * ww, y = y0 + rnd() * hh;
        g.fillStyle = 'rgba(235,245,250,' + (0.12 + rnd() * 0.15).toFixed(2) + ')';
        g.beginPath(); g.ellipse(x, y, 2 + rnd() * 3, 0.8, -0.3, 0, 7); g.fill();
      }
      // 코스 경계(부표 줄)
      g.strokeStyle = 'rgba(242,233,216,.22)'; g.lineWidth = 1.2; g.setLineDash([2, 6]);
      g.strokeRect(x0 + 0.5, y0 + 0.5, ww - 1, hh - 1); g.setLineDash([]);
      // 물살 띠
      if (C.cur) {
        const cy0 = SY(C.cur[0]), cy1 = SY(C.cur[1]);
        const cg = g.createLinearGradient(0, cy0, 0, cy1);
        cg.addColorStop(0, 'rgba(120,200,255,0)'); cg.addColorStop(0.2, 'rgba(120,200,255,.10)'); cg.addColorStop(0.8, 'rgba(120,200,255,.10)'); cg.addColorStop(1, 'rgba(120,200,255,0)');
        g.fillStyle = cg; g.fillRect(x0, cy0, ww, cy1 - cy0);
      }
      // 섬
      g.save(); g.beginPath(); g.rect(x0, y0, ww, hh); g.clip();
      for (const o of C.isl) {
        const cx = SX(o[0]), cy = SY(o[1]), r = o[2] * M.k;
        g.fillStyle = 'rgba(255,255,255,.12)'; g.beginPath(); g.arc(cx, cy, r + 4, 0, 7); g.fill();
        g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.arc(cx + 2, cy + 3, r, 0, 7); g.fill();
        g.fillStyle = C.land[0]; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fill();
        const ig = g.createRadialGradient(cx - r * 0.2, cy - r * 0.25, 1, cx, cy, r * 0.85);
        ig.addColorStop(0, C.land[1]); ig.addColorStop(1, C.land[2]);
        g.fillStyle = ig; g.beginPath(); g.arc(cx, cy, r * 0.78, 0, 7); g.fill();
        const rr = prng(o[0] * 31 + o[1] * 7);
        for (let j = 0; j < Math.max(3, Math.round(o[2] / 2)); j++) { // 나무
          const a = rr() * 6.28, d = rr() * r * 0.5, tx = cx + Math.cos(a) * d, ty = cy + Math.sin(a) * d, tr = Math.max(2.5, r * (0.12 + rr() * 0.08));
          g.fillStyle = 'rgba(0,0,0,.22)'; g.beginPath(); g.arc(tx + 1, ty + 1.5, tr, 0, 7); g.fill();
          g.fillStyle = C.land[2]; g.beginPath(); g.arc(tx, ty, tr, 0, 7); g.fill();
          g.fillStyle = 'rgba(255,255,255,.12)'; g.beginPath(); g.arc(tx - tr * 0.3, ty - tr * 0.3, tr * 0.45, 0, 7); g.fill();
        }
      }
      g.restore();
    }

    /* ---- 그리기 ---- */
    function drawGusts(C) {
      const gs = gustsNow(), wd = windNow(), tx = -sinD(wd[0]), ty = cosD(wd[0]), ds = GSPD * gustT();
      for (const q of gs) {
        const x = SX(q[0] + tx * ds), y = SY(q[1] + ty * ds), r = q[2] * M.k, gust = q[3] >= 1;
        const gg = ctx.createRadialGradient(x, y, 0, x, y, r);
        if (gust) { gg.addColorStop(0, 'rgba(6,18,40,.34)'); gg.addColorStop(0.6, 'rgba(6,18,40,.24)'); gg.addColorStop(1, 'rgba(6,18,40,0)'); }
        else { gg.addColorStop(0, 'rgba(200,235,240,.16)'); gg.addColorStop(0.65, 'rgba(200,235,240,.1)'); gg.addColorStop(1, 'rgba(200,235,240,0)'); }
        ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
        if (gust) { // 잔물결 무늬
          ctx.strokeStyle = 'rgba(190,225,255,.22)'; ctx.lineWidth = 1;
          for (let j = 0; j < 7; j++) {
            const a = j * 2.4 + q[0], d = r * (0.15 + ((j * 0.37) % 0.6)), px = x + Math.cos(a) * d, py = y + Math.sin(a) * d, l = 4 + (j % 3) * 2;
            const wob = Math.sin(tNow / 300 + j) * 1.2;
            ctx.beginPath(); ctx.moveTo(px - ty * l * 0.5, py + tx * l * 0.5 + wob); ctx.lineTo(px + ty * l * 0.5, py - tx * l * 0.5 + wob); ctx.stroke();
          }
        }
        ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = gust ? 'rgba(200,230,255,.7)' : 'rgba(230,250,255,.6)';
        ctx.fillText(gust ? '돌풍' : '약풍', x, y);
      }
      void C;
    }
    function drawShadows(C, boats) {
      const wd = windNow(), tx = -sinD(wd[0]), ty = cosD(wd[0]), px = -ty, py = tx;
      ctx.save(); ctx.beginPath(); ctx.rect(SX(0), SY(0), CW * M.k, CH * M.k); ctx.clip();
      const wedge = (x, y, w0, w1, len, c0) => {
        const g = ctx.createLinearGradient(SX(x), SY(y), SX(x + tx * len), SY(y + ty * len));
        g.addColorStop(0, c0); g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g; ctx.beginPath();
        ctx.moveTo(SX(x + px * w0), SY(y + py * w0)); ctx.lineTo(SX(x + tx * len + px * w1), SY(y + ty * len + py * w1));
        ctx.lineTo(SX(x + tx * len - px * w1), SY(y + ty * len - py * w1)); ctx.lineTo(SX(x - px * w0), SY(y - py * w0)); ctx.closePath(); ctx.fill();
      };
      for (const o of C.isl) wedge(o[0], o[1], o[2], o[2] * 1.6, o[2] * ISH, 'rgba(0,10,25,.2)');
      boats.forEach((b) => { if (!b.fin) wedge(b.x, b.y, 2.4, 2.4 + BSH * 0.14, BSH, 'rgba(0,10,25,.16)'); });
      ctx.restore();
    }
    function drawStreaks(dt, C) {
      const wd = windNow(), tx = -sinD(wd[0]), ty = cosD(wd[0]);
      while (streaks.length < 32) streaks.push({ x: Math.random() * CW, y: Math.random() * CH, l: Math.random(), s: 0.7 + Math.random() * 0.6 });
      const spd = 9 * wd[1] * (anim ? RSPD * L.debug.speed : 1);
      ctx.lineCap = 'round';
      for (const p of streaks) {
        p.x += tx * spd * p.s * dt; p.y += ty * spd * p.s * dt; p.l += dt * 0.5;
        if (p.l > 1 || p.x < -4 || p.x > CW + 4 || p.y < -4 || p.y > CH + 4) {
          p.l = 0; p.x = Math.random() * CW; p.y = Math.random() * CH;
        }
        const a = Math.sin(p.l * Math.PI) * 0.24, len = 2.4 * p.s, X = SX(p.x), Y = SY(p.y), X2 = SX(p.x + tx * len), Y2 = SY(p.y + ty * len);
        ctx.strokeStyle = 'rgba(225,245,255,' + a.toFixed(3) + ')'; ctx.lineWidth = 1.3;
        ctx.beginPath(); ctx.moveTo(X, Y); ctx.lineTo(X2, Y2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(X2 - tx * 3 - ty * 2.6, Y2 - ty * 3 + tx * 2.6); ctx.lineTo(X2, Y2); ctx.lineTo(X2 - tx * 3 + ty * 2.6, Y2 - ty * 3 - tx * 2.6); ctx.stroke();
      }
      if (C.cur) { // 물살 화살표
        const cy0 = C.cur[0], cy1 = C.cur[1], dir = C.cur[2] < 0 ? -1 : 1;
        ctx.strokeStyle = 'rgba(150,240,230,.45)'; ctx.lineWidth = 2;
        const ph = ((clock * 1.5) % 14) * dir;
        for (let row = 0; row < 3; row++) {
          const y = cy0 + (cy1 - cy0) * (0.22 + row * 0.28);
          for (let x = -14 + ((ph + row * 5) % 14 + 14) % 14; x < CW + 4; x += 14) {
            const X = SX(x), Y = SY(y), s = 4;
            ctx.beginPath(); ctx.moveTo(X - dir * s * 0.6, Y - s); ctx.lineTo(X + dir * s * 0.4, Y); ctx.lineTo(X - dir * s * 0.6, Y + s); ctx.stroke();
          }
        }
        ctx.fillStyle = 'rgba(200,235,255,.65)'; ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'bottom';
        ctx.fillText('물살 ' + (dir < 0 ? '←' : '→'), SX(CW) - 4, SY(cy0) + 12);
      }
    }
    function arrowHead(x, y, dx, dy, s) {
      const nx = -dy, ny = dx;
      ctx.beginPath(); ctx.moveTo(x + dx * s, y + dy * s); ctx.lineTo(x - dx * s * 0.6 + nx * s * 0.75, y - dy * s * 0.6 + ny * s * 0.75); ctx.lineTo(x - dx * s * 0.6 - nx * s * 0.75, y - dy * s * 0.6 - ny * s * 0.75); ctx.closePath(); ctx.fill();
    }
    function drawCourse(C, boats, focus) {
      // 출발·결승선
      const S0 = C.st[0], S1 = C.st[1];
      const ax = SX(S0[0]), ay = SY(S0[1]), bx = SX(S1[0]), by = SY(S1[1]);
      const finalFor = focus >= 0 && boats[focus] && boats[focus].mk >= C.M.length && !boats[focus].fin;
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(ax, ay + 1); ctx.lineTo(bx, by + 1); ctx.stroke();
      ctx.lineWidth = 2.5; ctx.setLineDash([6, 5]); ctx.strokeStyle = finalFor ? '#f4c64e' : 'rgba(242,233,216,.85)';
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke(); ctx.setLineDash([]);
      for (const [x, y] of [[ax, ay], [bx, by]]) {
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(x + 1, y + 2, 4.5, 0, 7); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(x, y, 4, 0, 7); ctx.fill();
        ctx.strokeStyle = '#2a2233'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - 13); ctx.stroke();
        for (let r = 0; r < 2; r++) for (let c = 0; c < 3; c++) { ctx.fillStyle = (r + c) % 2 ? '#1b1426' : '#f2e9d8'; ctx.fillRect(x + c * 3, y - 13 + r * 3, 3, 3); }
      }
      ctx.fillStyle = 'rgba(242,233,216,.8)'; ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      const nx = C.no[0], ny = C.no[1];
      ctx.fillText('출발 · 결승', (ax + bx) / 2 - nx * 10, (ay + by) / 2 - ny * 10 - 5);
      if (finalFor) { // 결승 방향 화살표
        ctx.fillStyle = '#f4c64e'; arrowHead((ax + bx) / 2 + nx * 2, (ay + by) / 2 + ny * 2, nx, ny, 6);
      }
      // 부표
      const R = Math.max(5.5, M.k * 1.6);
      C.M.forEach((m, k) => {
        const x = SX(m.x), y = SY(m.y);
        const nextFor = focus >= 0 && boats[focus] && boats[focus].mk === k && !boats[focus].fin;
        const passed = focus >= 0 && boats[focus] && boats[focus].mk > k;
        // 도는 방향 화살표(바깥쪽 호)
        const au = Math.atan2(m.uy, m.ux), ra = Math.max(15, M.k * 5.2), sp = 72 * D2R;
        const a0 = m.port ? au + sp : au - sp, a1 = m.port ? au - sp : au + sp;
        ctx.strokeStyle = nextFor ? '#f4c64e' : passed ? 'rgba(242,233,216,.18)' : 'rgba(242,233,216,.5)'; ctx.lineWidth = nextFor ? 2.6 : 1.8;
        ctx.setLineDash(nextFor ? [] : [4, 4]);
        ctx.beginPath(); ctx.arc(x, y, ra, a0, a1, m.port); ctx.stroke(); ctx.setLineDash([]);
        const ex = x + Math.cos(a1) * ra, ey = y + Math.sin(a1) * ra, dx = m.port ? Math.sin(a1) : -Math.sin(a1), dy = m.port ? -Math.cos(a1) : Math.cos(a1);
        ctx.fillStyle = ctx.strokeStyle; arrowHead(ex, ey, dx, dy, nextFor ? 6 : 5);
        if (nextFor) {
          const pulse = 0.5 + 0.5 * Math.sin(tNow / 260);
          ctx.strokeStyle = 'rgba(244,198,78,' + (0.35 + pulse * 0.4).toFixed(2) + ')'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(x, y, R + 4 + pulse * 3, 0, 7); ctx.stroke();
        }
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(x + 1.5, y + 2.5, R, 0, 7); ctx.fill();
        ctx.fillStyle = passed ? '#7d6e5e' : '#f08a3c'; ctx.beginPath(); ctx.arc(x, y, R, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.arc(x - R * 0.3, y - R * 0.35, R * 0.4, 0, 7); ctx.fill();
        ctx.fillStyle = '#1b1426'; ctx.font = '800 ' + Math.round(R * 1.25) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(passed ? '✓' : String(k + 1), x, y + 0.5);
      });
    }
    function drawTrails(boats) {
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (let i = 0; i < st.n; i++) {
        const tr = st.tr[i]; if (!tr || tr.length < 2) continue;
        ctx.strokeStyle = rgba(col(i), 0.32); ctx.lineWidth = 1.6; ctx.setLineDash([2, 4]);
        ctx.beginPath();
        const lim = anim ? tr.length : tr.length - 2;
        for (let j = 0; j < lim; j += 2) { const x = SX(tr[j]), y = SY(tr[j + 1]); if (j) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
        if (!anim && lastPaths && lastPaths[i] && lastPaths[i].length > 1) {
          for (const p of lastPaths[i]) ctx.lineTo(SX(p[0]), SY(p[1]));
        } else if (!anim && tr.length >= 2) ctx.lineTo(SX(tr[tr.length - 2]), SY(tr[tr.length - 1]));
        ctx.stroke(); ctx.setLineDash([]);
        if (anim && anim.paths[i] && anim.paths[i].length > 1) { // 이번 차례 물자국
          const P = anim.paths[i];
          ctx.strokeStyle = 'rgba(240,250,255,.45)'; ctx.lineWidth = 2.2;
          ctx.beginPath(); ctx.moveTo(SX(P[0][0]), SY(P[0][1])); for (const p of P) ctx.lineTo(SX(p[0]), SY(p[1])); ctx.lineTo(SX(boats[i].x), SY(boats[i].y)); ctx.stroke();
        }
      }
    }
    function drawBoat(b, i, wf, alpha, ring) {
      const x = SX(b.x), y = SY(b.y), Lb = Math.max(20, M.k * 5.6), bw = Lb * 0.38;
      ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y);
      if (ring) {
        const pulse = 0.5 + 0.5 * Math.sin(tNow / 240);
        ctx.strokeStyle = rgba(col(i), 0.5 + pulse * 0.4); ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(0, 0, Lb * 0.75 + pulse * 2, 0, 7); ctx.stroke();
      }
      ctx.rotate(b.h * D2R);
      const rel = wrap(b.h - wf), th = Math.abs(rel), heel = b.ov > 0 ? Math.min(1, b.ov * 2.5) : 0;
      // 물보라
      if (b.v > 3.6 && !b.fin) {
        ctx.fillStyle = 'rgba(240,250,255,.5)';
        ctx.beginPath(); ctx.moveTo(0, -Lb * 0.55); ctx.lineTo(bw * 0.8, -Lb * 0.2); ctx.lineTo(bw * 0.55, -Lb * 0.22); ctx.lineTo(0, -Lb * 0.45); ctx.lineTo(-bw * 0.55, -Lb * 0.22); ctx.lineTo(-bw * 0.8, -Lb * 0.2); ctx.closePath(); ctx.fill();
      }
      // 그림자
      ctx.fillStyle = 'rgba(0,0,0,.3)';
      hull(1.5 + heel * 2, 2.5, Lb, bw); ctx.fill();
      const sq = 1 - heel * 0.25; // 기울면 좁아 보임
      ctx.save(); ctx.scale(sq, 1);
      ctx.fillStyle = col(i); hull(0, 0, Lb, bw); ctx.fill();
      ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 1.6; ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.75)'; hull(0, Lb * 0.06, Lb * 0.66, bw * 0.48); ctx.fill();
      ctx.restore();
      // 돛: 바람 반대쪽으로, 바람 각도의 절반쯤 열림(자동)
      const mxy = -Lb * 0.12, bl = Lb * 0.56;
      let da;
      if (th < NOGO - 4 || b.fin) da = Math.sin(tNow / 70 + i) * 7 * D2R; // 펄럭펄럭
      else da = clamp(th * 0.5, 8, 85) * D2R * (rel < 0 ? 1 : -1);
      const ex = -Math.sin(da) * bl, ey = mxy + Math.cos(da) * bl;
      const sx = -(ey - mxy) / bl, sy = ex / bl, bul = (rel < 0 ? 1 : -1) * Lb * 0.13 * (th < NOGO - 4 ? 0.2 : 1);
      const cx = (ex) / 2 + sx * -bul, cy = (mxy + ey) / 2 + sy * -bul;
      ctx.fillStyle = heel > 0.3 ? '#ffe2c8' : '#fbf6ea'; ctx.strokeStyle = 'rgba(27,20,38,.8)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(0, mxy); ctx.quadraticCurveTo(cx, cy, ex, ey); ctx.lineTo(0, mxy); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = '#3a2c22'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, mxy); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.fillStyle = '#1b1426'; ctx.beginPath(); ctx.arc(0, mxy, 1.8, 0, 7); ctx.fill();
      if (b.rf) { ctx.strokeStyle = 'rgba(27,20,38,.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(ex * 0.35, mxy + (ey - mxy) * 0.35 - 2); ctx.lineTo(ex * 0.35 + sx * 3, mxy + (ey - mxy) * 0.35 + sy * 3); ctx.stroke(); }
      ctx.restore();
      if (heel > 0.15 && !b.fin) { // 기우뚱 표시
        ctx.fillStyle = 'rgba(238,106,85,.9)'; ctx.font = '800 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        ctx.fillText('!', x + Lb * 0.55, y - Lb * 0.45);
      }
    }
    function hull(ox, oy, Lb, bw) {
      ctx.beginPath();
      ctx.moveTo(ox, oy - Lb / 2);
      ctx.quadraticCurveTo(ox + bw * 0.62, oy - Lb * 0.2, ox + bw / 2, oy + Lb * 0.42);
      ctx.lineTo(ox - bw / 2, oy + Lb * 0.42);
      ctx.quadraticCurveTo(ox - bw * 0.62, oy - Lb * 0.2, ox, oy - Lb / 2);
      ctx.closePath();
    }
    function drawPlan(boats) {
      const P = preview(); if (!P || !plan) return;
      const b = boats[plan.seat], x = SX(b.x), y = SY(b.y), wd = st.wd, wf = wd[0];
      const R = clamp(M.k * 15, 46, 64), R0 = R * 0.28, vref = 6.6 * 1.3;
      // 바람 정면(못 가는 쪽) 부채꼴
      ctx.fillStyle = 'rgba(238,106,85,.4)'; ctx.strokeStyle = 'rgba(238,106,85,.85)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.arc(x, y, R, (wf - NOGO - 90) * D2R, (wf + NOGO - 90) * D2R); ctx.closePath(); ctx.fill(); ctx.stroke();
      // 속도 고리(폴라)
      ctx.beginPath();
      for (let o = 0; o <= 360; o += 5) {
        const th = Math.abs(wrap(o - wf)), v = polar(th) * power(P.wl, plan.rf, th), r = R0 + (R - R0) * clamp(v / vref, 0, 1);
        const px = x + sinD(o) * r, py = y - cosD(o) * r;
        if (o) ctx.lineTo(px, py); else ctx.moveTo(px, py);
      }
      ctx.closePath();
      ctx.fillStyle = 'rgba(159,224,255,.16)'; ctx.fill();
      ctx.strokeStyle = 'rgba(159,224,255,.85)'; ctx.lineWidth = 1.6; ctx.stroke();
      ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1; ctx.setLineDash([2, 4]);
      ctx.beginPath(); ctx.arc(x, y, R, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      // 바람 오는 쪽 표시
      ctx.fillStyle = '#ee6a55'; ctx.font = '800 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('바람', x + sinD(wf) * (R + 9), y - cosD(wf) * (R + 9));
      // 예상 경로
      ctx.strokeStyle = rgba(col(plan.seat), 0.95); ctx.lineWidth = 2.4; ctx.setLineDash([5, 4]); ctx.lineCap = 'round';
      ctx.beginPath(); P.pts.forEach((p, j) => { const X = SX(p[0]), Y = SY(p[1]); if (j) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); }); ctx.stroke(); ctx.setLineDash([]);
      drawBoat({ x: P.end.x, y: P.end.y, h: P.end.h, v: 0, rf: plan.rf, ov: 0, fin: false }, plan.seat, wf, 0.45, false);
      // 고른 방향 화살표
      const th = Math.abs(wrap(plan.h - wf)), v = polar(th) * power(P.wl, plan.rf, th), rr = R0 + (R - R0) * clamp(v / vref, 0, 1);
      const dx = sinD(plan.h), dy = -cosD(plan.h);
      ctx.strokeStyle = 'rgba(27,20,38,.6)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x + dx * 10, y + dy * 10); ctx.lineTo(x + dx * (R + 6), y + dy * (R + 6)); ctx.stroke();
      ctx.strokeStyle = th < NOGO ? '#ee6a55' : '#f4c64e'; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.moveTo(x + dx * 10, y + dy * 10); ctx.lineTo(x + dx * (R + 6), y + dy * (R + 6)); ctx.stroke();
      ctx.fillStyle = ctx.strokeStyle; arrowHead(x + dx * (R + 8), y + dy * (R + 8), dx, dy, 6);
      ctx.fillStyle = '#f4c64e'; ctx.beginPath(); ctx.arc(x + dx * rr, y + dy * rr, 3.2, 0, 7); ctx.fill();
      if (P.rd) { const p = P.pts[Math.min(P.pts.length - 1, Math.round(P.rd[2] / 2))]; floatLabel(SX(p[0]), SY(p[1]) - 12, '✓', '#5fd3a0'); }
    }
    function floatLabel(x, y, t, c, big) {
      ctx.font = (big ? '800 15px' : '800 12px') + ' "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const X = clamp(x, 50, M.w - 50);
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(23,19,31,.8)'; ctx.strokeText(t, X, y);
      ctx.fillStyle = c; ctx.fillText(t, X, y);
    }
    function draw(dt) {
      cv.clear();
      if (!st || !M) return;
      const C = Cn();
      buildBg();
      ctx.drawImage(bg, 0, 0, M.w, M.h);
      const boats = boatsNow(), wf = windNow()[0];
      const focus = plan ? plan.seat : (() => { const m = api.mySeats ? api.mySeats() : []; return m.length === 1 ? m[0] : -1; })();
      drawShadows(C, boats);
      drawGusts(C);
      drawStreaks(dt, C);
      drawCourse(C, boats, focus);
      drawTrails(boats);
      const order = boats.map((_, i) => i).filter((i) => i !== focus).concat(focus >= 0 ? [focus] : []);
      for (const i of order) drawBoat(boats[i], i, wf, boats[i].fin && !anim ? 0.75 : 1, !!plan && i === plan.seat);
      if (plan && !anim) drawPlan(boats);
      for (const f of floats) {
        if (f.t < 0) continue;
        ctx.globalAlpha = clamp(1.6 - f.t * 1.6, 0, 1);
        floatLabel(SX(f.x), SY(f.y) - 14 - f.t * 18, f.text, f.c, f.big);
      }
      ctx.globalAlpha = 1;
    }

    /* ---- 다시보기 ---- */
    function startReplay(L0) {
      if (anim) finishReplay(true);
      const C = Cn();
      const lg = new Leg(C, L0.b, L0.wd, L0.gs, L0.T, L0.p, -1, true);
      anim = { L: L0, lg, acc: 0, ev: 0, hold: 0, done: false, ff: 1, paths: L0.b.map((q) => [[q[0], q[1]]]) };
      plan = null; pv = null; drag = null;
      api.setBusy(true); api.sfx('whoosh');
      clearTimeout(safeT);
      const me = anim;
      safeT = setTimeout(() => { if (anim === me) { while (me.lg.k < NST) stepAnim(me); finishReplay(); } }, (NST * DT / RSPD / L.debug.speed) * 1000 + 3500);
      topKey = ''; botKey = ''; renderTop(); renderBot(); renderWind();
    }
    function stepAnim(A) {
      A.lg.step();
      if (A.lg.k % 2 === 0) A.lg.B.forEach((b, i) => { const P = A.paths[i], l = P[P.length - 1]; if (!A.L.b[i][5] && (l[0] !== b.x || l[1] !== b.y)) P.push([b.x, b.y]); });
      while (A.ev < A.lg.ev.length) onEvent(A.lg.ev[A.ev++], A);
    }
    function onEvent(e, A) {
      const tp = e[0], i = e[1], b = A.lg.B[i], mine = api.canAct(i), C = Cn();
      const fl = (text, c, big) => floats.push({ x: b.x, y: b.y, text, c, t: 0, big });
      if (tp === 'rd') {
        fl((e[3] + 1) + '번 부표 ✓', '#f4c64e'); api.sfx('chip');
        if (mine) { api.buzz(15); api.toast((st.n > 1 && api.mySeats().length > 1 ? pname(i) + ' · ' : '') + (e[3] + 1) + '번 부표를 돌았어요!' + (e[3] + 1 === C.mk.length ? ' 이제 결승선으로!' : '')); }
      } else if (tp === 'fn') {
        let k = 1; for (let j = 0; j < A.lg.B.length; j++) { const q = A.lg.B[j]; if (j !== i && q.ft && q.ft < b.ft) k++; }
        fl('결승! ' + k + '등', '#5fd3a0', 1); api.sfx(k === 1 ? 'win' : 'pop');
        if (mine) api.buzz(40);
        api.toast(pname(i) + ' 결승! ' + (st.n > 1 ? k + '등 · ' : '') + fmtT(b.ft));
      } else if (tp === 'hit') {
        fl('쿵!', '#ee6a55'); api.sfx('hit');
        if (mine) { api.buzz(30); api.toast('부딪혔어요 — 내가 길을 비켜야 했어요'); }
        else if (api.canAct(e[3])) { api.buzz(15); api.toast(pname(i) + '이(가) 비켜야 했어요'); }
      } else if (tp === 'gr') { fl('섬에 쿵!', '#ee6a55'); api.sfx('thud'); if (mine) { api.buzz(25); api.toast('섬에 걸려 느려졌어요'); } }
      else if (tp === 'ed') { fl('가장자리!', '#ee6a55'); if (mine) api.buzz(15); }
      else if (tp === 'tk') { fl('택', '#cfe9ff'); api.sfx('whoosh'); }
      else if (tp === 'gy') { fl('자이브', '#cfe9ff'); api.sfx('whoosh'); }
      else if (tp === 'hl') { fl('기우뚱!', '#e3ae45'); if (mine && !heelTip) { heelTip = true; api.toast('센 바람에 배가 기울어 느려졌어요 — 「돛 반만」을 써 보세요'); } }
    }
    function finishReplay(skipBusy) {
      clearTimeout(safeT);
      const A = anim; if (!A) return;
      anim = null;
      lastPaths = A.paths.map((p, i) => (A.L.b[i][5] ? null : p));
      if (st && Math.abs(st.ws) >= 6 && !st.end) { api.toast('바람이 ' + (st.ws > 0 ? '오른쪽(시계 방향)' : '왼쪽(반시계 방향)') + '으로 ' + Math.abs(st.ws) + '° 돌았어요'); }
      if (!skipBusy) api.setBusy(false);
      topKey = ''; botKey = ''; windKey = '';
      renderTop(); renderBot(); renderWind();
    }

    /* ---- 입력 ---- */
    function headingFromPointer(p) {
      if (!plan) return;
      const q = st.b[plan.seat], bx = SX(q[0]), by = SY(q[1]), dx = p.x - bx, dy = p.y - by;
      if (dx * dx + dy * dy < 100) return;
      setHeading(Math.atan2(dx, -dy) / D2R);
    }
    function onDown(ev) {
      if (anim) { anim.ff = 5; return; }
      syncPlan();
      if (!plan) return;
      const p = cv.local(ev);
      drag = { id: ev.pointerId };
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      headingFromPointer(p); api.buzz(6);
    }
    function onMove(ev) { if (!drag || drag.id !== ev.pointerId) return; headingFromPointer(cv.local(ev)); }
    function onUp(ev) { if (drag && drag.id === ev.pointerId) drag = null; }
    const el = cv.cv;
    el.addEventListener('pointerdown', onDown); el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp); el.addEventListener('pointercancel', onUp);
    const offKey = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (anim) { if (id === 'go') anim.ff = 5; return; }
      syncPlan();
      if (!plan) return;
      if (id === 'left') setHeading(plan.h - 5);
      else if (id === 'right') setHeading(plan.h + 5);
      else if (id === 'sail') { plan.rf = plan.rf ? 0 : 1; api.sfx('click'); botKey = ''; renderBot(); }
      else if (id === 'go') commit();
    }) : null;

    /* ---- 루프 ---- */
    let botTick = 0;
    const stop = U.loop((dt, now) => {
      tNow = now; clock += dt;
      if (!st || !M) return;
      const spd = L.debug.speed;
      if (anim) {
        const A = anim;
        if (!A.done) {
          A.acc += dt * spd * RSPD * A.ff;
          let n = 0;
          while (A.acc >= DT && A.lg.k < NST && n < 400) { stepAnim(A); A.acc -= DT; n++; }
          if (A.lg.k >= NST) A.done = true;
        } else {
          A.hold += dt * spd;
          if (A.hold > 0.25) finishReplay();
        }
      }
      for (const f of floats) f.t += dt * spd * 0.8;
      for (let i = floats.length - 1; i >= 0; i--) if (floats[i].t > 1.2) floats.splice(i, 1);
      if ((botTick += dt) > 0.5) { botTick = 0; if (!anim) { const before = plan && plan.seat; syncPlan(); if ((plan && plan.seat) !== before) { botKey = ''; renderBot(); } } }
      draw(dt);
    });

    layout();
    return {
      update(next, prev) {
        const cc = st ? st.c : -1;
        st = next;
        if (cc !== next.c) layout();
        for (const k in sent) if (next.T !== sent[k].T || next.p[k] || next.b[k][5]) delete sent[k];
        const L0 = next.last;
        if (L0 && L0.id !== shownId && prev && prev !== next && (!prev.last || prev.last.id !== L0.id)) {
          shownId = L0.id;
          startReplay(L0);
        } else if (L0) shownId = L0.id;
        if (!anim) syncPlan();
        topKey = ''; botKey = '';
        renderTop(); renderBot(); renderWind();
      },
      destroy() {
        stop(); clearTimeout(safeT);
        el.removeEventListener('pointerdown', onDown); el.removeEventListener('pointermove', onMove);
        el.removeEventListener('pointerup', onUp); el.removeEventListener('pointercancel', onUp);
        if (offKey) try { offKey(); } catch (e) {}
        cv.destroy(); top.remove(); bot.remove(); windEl.remove();
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'sailing', name: '요트 경주', tag: '바람 읽기 경주', cat: '스포츠',
    blurb: '바람 방향을 보고 뱃머리 방향과 돛을 정해요. 모두 정하면 5초씩 함께 움직여요. 부표를 순서대로 돌고 결승선을 먼저 지나면 승리!',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 3, hidden: false, aiDelay: 700,
    options: [
      { id: 'course', label: '코스', choices: [{ v: 0, label: '만 경기' }, { v: 1, label: '섬 사이' }, { v: 2, label: '폭풍 전야' }, { v: 3, label: '물살 해협' }, { v: 'rnd', label: '무작위' }], def: 'rnd' },
    ],
    tint: '#1b5b78',
    icon: '<path d="M9 38H47L41 46H15Z" fill="currentColor"/><path d="M28 7V37" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M30.5 9C38 15 42 24 43 34H30.5Z" fill="currentColor" opacity=".9"/><path d="M25.5 14L15 34H25.5Z" fill="currentColor" opacity=".55"/><path d="M5 51C10 48 14 48 19 51S28 54 33 51S43 48 51 51" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="48" cy="13" r="3.2" fill="none" stroke="currentColor" stroke-width="2"/>',
    controls: [
      { id: 'left', label: '왼쪽으로 5°', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lb'] },
      { id: 'right', label: '오른쪽으로 5°', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'rb'] },
      { id: 'sail', label: '돛 활짝/반만', keys: ['KeyS', 'ArrowDown'], pad: ['y'] },
      { id: 'go', label: '출발 / 빨리 보기', keys: ['Enter', 'Space'], pad: ['a'] },
    ],
    quick: [
      '목표: 부표를 번호 순서대로(화살표 방향) 돌고, 출발선으로 돌아와 결승선을 가장 먼저 지나기',
      '내 차례: 화면을 끌어 갈 방향 정하기 → 돛(활짝/반만) → 「출발」. 모두 정하면 5초 동안 함께 움직여요',
      '바람이 오는 쪽(빨간 부채꼴)으로는 못 가요. 거슬러 갈 땐 지그재그! 옆바람·뒤옆바람이 가장 빨라요',
    ],
    tutorial: [
      { sel: 'canvas', text: '요트 경주예요! 주황 부표를 1번, 2번 순서대로 화살표 방향으로 돌고, 출발선(체크 깃발)을 다시 지나면 결승이에요.' },
      { sel: '[data-tut="wind"]', text: '바람 화살표예요. 바람이 오는 쪽으로는 배가 못 가요. 바람은 차례마다 조금씩 돌아요.' },
      { sel: '[data-tut="aim"]', text: '내 배 둘레의 파란 고리가 속도 미리보기예요. 크게 부푼 쪽일수록 빨라요. 빨간 부채꼴은 바람 정면이라 못 가요. 화면을 끌거나 ↺ ↻(5°씩)로 방향을 정해요. 점선은 5초 동안 갈 길, 여기 숫자는 5초 뒤 속도예요.' },
      { sel: '[data-tut="sail"]', text: '돛 각도는 배가 알아서 맞춰요. 대신 돛을 「활짝」 펼지 「반만」 펼지 골라요. 센 바람·돌풍에서 활짝 펴면 배가 기울어 느려져요!' },
      { sel: '[data-tut="go"]', text: '「출발」을 누르면 끝! 모두 정하면 다 같이 5초 동안 움직여요. 다른 배 바로 뒤(바람 그늘)는 바람이 약하니 피하세요.' },
    ],
    rules: [
      { h: '목표', p: ['1–4척이 함께 달려요. 주황 부표를 번호 순서대로, 부표 옆 화살표 방향으로 돌아요.', '부표를 다 돌면 출발선(체크 깃발 사이 점선)을 다시 지나요. 이게 결승선이에요.', '가장 먼저 결승선을 지난 배가 이겨요. 혼자 하면 기록에 따라 별을 받아요.'] },
      { h: '차례에 할 일', p: ['모두 동시에 정해요: ① 갈 방향 ② 돛(활짝/반만) ③ 「출발」.', '모두 정하면 배들이 5초 동안 함께 움직여요. 그다음 또 정해요.', '한 폰에서 여럿이 하면 이름이 나온 사람 차례에 폰을 넘겨 주세요.'] },
      { h: '바람과 속도', p: ['바람이 오는 쪽(빨간 부채꼴, 바람 정면에서 양옆 36°쯤)으로는 못 가요. 그쪽으로 향하면 배가 멈춰요.', '바람 오는 쪽으로 가려면 45~50° 비스듬히 지그재그로 가요.', '옆바람(바람이 옆에서)·뒤옆바람이 가장 빠르고, 바로 뒷바람은 조금 느려요.', '배 둘레의 고리가 방향마다 속도예요. 크게 부푼 쪽이 빨라요.'] },
      { h: '방향 바꾸기', p: ['택: 뱃머리가 바람 정면을 지나 반대쪽으로 넘어가는 것. 넘어가는 동안 속도가 많이 줄어요.', '자이브: 뒷바람에서 꼬리가 바람을 지나 넘어가는 것. 돛이 휙 넘어가며 조금 느려져요.', '그래서 지그재그는 너무 자주 하지 말고, 길게 몇 번만!'] },
      { h: '돛', p: ['돛 각도는 바람에 맞춰 자동으로 맞춰져요(그림에서 돛이 움직이는 걸 볼 수 있어요).', '돛 활짝: 보통 바람에서 가장 빨라요. 하지만 바람이 아주 세면(돌풍 속, 폭풍 전야) 배가 기울어(빨간 !) 오히려 느려져요.', '돛 반만: 힘은 조금 약하지만 센 바람에서도 기울지 않아요. 미리보기 속도를 비교해 고르세요.'] },
      { h: '돌풍·약풍·바람 그늘', p: ['짙은 얼룩 「돌풍」: 바람이 30~40% 세요. 바람 따라 흘러가요.', '밝은 얼룩 「약풍」: 바람이 약해요.', '배와 섬 뒤(바람이 불어 가는 쪽)는 바람 그늘이라 바람이 약해요. 앞 배 바로 뒤를 따라가면 손해!', '바람 방향은 차례마다 조금씩 바뀌어요. 바뀐 방향을 보고 지그재그 방향을 골라요.'] },
      { h: '부딪힘', p: ['배끼리 부딪히면 길을 비켜야 했던 배가 밀려나고 많이 느려져요.', '누가 비키나: 방향을 바꾸는 중(바람 정면)인 배 → 왼쪽에서 바람을 받는 배 → 둘 다 같은 쪽이면 바람 위쪽에 있는 배.', '섬이나 코스 가장자리에 닿아도 느려져요.'] },
      { h: '코스', p: ['만 경기: 잔잔한 기본 코스. 위로 거슬러 올라가 1번, 왼쪽 2번, 출발선으로.', '섬 사이: 섬들 사이로 지나가요. 섬 뒤는 바람 그늘이에요.', '폭풍 전야: 센 바람과 큰 돌풍. 「돛 반만」을 잘 써야 해요. 바람도 많이 돌아요.', '물살 해협: 가운데 띠에서 물살이 서쪽(←)으로 배를 밀어요. 부표를 오른쪽에 두고 돌아요.', '무작위: 넷 중 하나.'] },
      { h: '끝·순위', p: ['결승한 순서대로 순위가 정해져요(5초 사이의 정확한 시각까지 따져요).', '처음 한 척이 결승하면 나머지는 5차례 안에 들어와야 해요. 못 들어오면 부표를 많이 돈 순, 결승에 가까운 순이에요.', '경주는 최대 40차례예요.'] },
      { h: '조작', p: ['화면 아무 데나 누르고 끌면 내 배에서 손가락 쪽으로 방향이 정해져요. ↺ ↻ 버튼은 5°씩.', '점선은 5초 동안 갈 길, 흐린 배는 5초 뒤 자리예요. 부표를 돌게 되면 ✓가 보여요.', '움직이는 동안 화면을 탭하면 빨리 보기.', 'PC: ←/→ 방향, S 돛, 엔터 출발.'] },
      { h: '예시', p: ['바람이 위(북쪽)에서 불고 1번 부표가 바로 위에 있어요. 위로 곧장은 못 가니 오른쪽 위(45°)로 가다가, 부표가 왼쪽 뒤로 보이면 왼쪽 위(315°)로 택!', '부표를 돈 뒤 왼쪽 아래 2번으로는 뒤옆바람이라 쌩쌩. 돌풍이 지나가면 활짝/반만 속도를 비교해 봐요.', '앞 배 바로 뒤에 붙으면 바람 그늘이라 느려져요 → 살짝 옆으로 비켜 가요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(쉬움은 방향이 서툴고 돛을 늘 활짝, 어려움은 두 차례 앞까지 보고 바람 그늘도 피해요).'] },
    ],
    init, actor, apply, ai, result, mount,
    aiDelayFor(s, seat, lv) { return lv === 1 ? 900 : lv === 3 ? 550 : 700; },
    _sim: { CS, Leg, polar, power, progCost, windOf, ranking, fmtT, VMG, sinD, cosD, wrap, brg },
  });
})();
