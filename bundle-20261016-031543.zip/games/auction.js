/* 소리 없는 경매 — 3~6인 비공개 동시 입찰 경매. 매 라운드 경매품이 공개되면 모두 동시에 몰래 입찰(배열 actor)하고,
   가장 많이 쓴 사람이 낙찰. 특수 경매: 2개 묶음 · 경매사 수수료 · 2등 가격 · 위작(가장 적게 쓴 사람이 떠안음).
   점수 = 물건 점수 + 세트 보너스(같은 색 3점 이상이면 그 색 ×2, 네 색 모두 +5, 태엽새 마릿수²) + 특수 물건 + 남은 금화 10당 1점.
   물건 141종: 색 물건 60(색마다 점수별 3종) · 걸작 8 · 태엽새 16 · 위작 12 + 특수 물건 45(짝 · 전집 · 보물상자/열쇠 · 금화 물건 ·
   저주/부적 · 전시 소품 · 신비한 물건). 판마다 색 20점 + 태엽새 5 + 걸작 1~2 + 특수 테마 1~3개(라운드 수에 따라)가 섞여요.
   이벤트 카드(옵션): 3라운드가 끝날 때마다 모두 한 장씩 받고, 입찰 전에 라운드당 한 장씩 써요(쓰면 모두에게 공개).
   카드 87종 · 7분류(정보/입찰/돈/물품/방해/점수/규칙) · 희귀도(흔함 2장·드묾 1장·전설은 12종 중 4종만) → 판마다 더미가 달라요. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- catalogue ---------- */
  const COL = [
    { n: '회화', c: '#d9584a' }, { n: '도자기', c: '#4f8fdc' }, { n: '보석', c: '#36b37e' }, { n: '조각', c: '#d6a23c' },
  ];
  const BIRD_C = '#a77de0', FAKE_C = '#8d8496';
  /* NAMES[colour][tier][variant] — tier t is worth 2+t points; each game uses one variant per tier */
  const NAMES = [
    [['항구의 새벽', '빨래 널린 골목', '연필 스케치'], ['붉은 정원', '해바라기 정물', '비 오는 창가'], ['고양이 초상', '사과 세 알', '등대의 밤'],
      ['안개 낀 들판', '눈 덮인 산', '도시의 불빛'], ['달빛 호수', '별이 쏟아지는 밤', '황금 폭포']],
    [['쪽빛 찻잔', '이 빠진 사발', '작은 연적'], ['물결무늬 주전자', '꽃무늬 접시', '표주박 병'], ['푸른 꽃병', '뚜껑 항아리', '학 무늬 매병'],
      ['청자 물병', '용 무늬 단지', '세발 향로'], ['백자 달항아리', '금 이음 그릇', '쌍둥이 꽃병']],
    [['초록 반지', '진주 비녀', '구슬 팔찌'], ['물방울 귀걸이', '은 머리빗', '클로버 펜던트'], ['숲빛 브로치', '보석 회중시계', '나비 핀'],
      ['비취 팔찌', '진주 목걸이', '보석 열쇠'], ['이끼 왕관', '보석 알', '별 티아라']],
    [['청동 사자', '나무 곰', '돌 거북'], ['대리석 두상', '청동 종', '돌 손'], ['금빛 물고기', '흑단 코끼리', '청동 가면'],
      ['춤추는 소녀상', '말 탄 기사', '석탑 모형'], ['태양 원반', '황금 고양이상', '인어 분수상']],
  ];
  const BIRDS = ['태엽 참새', '태엽 부엉이', '태엽 공작', '태엽 까치', '태엽 두루미', '태엽 앵무새', '태엽 오리', '태엽 수탉', '태엽 백조', '태엽 벌새',
    '태엽 홍학', '태엽 펭귄', '태엽 독수리', '태엽 비둘기', '태엽 까마귀', '태엽 꾀꼬리'];
  const FAKES = [['수상한 걸작', -3], ['어설픈 청자', -3], ['가짜 명화', -4], ['유리 보석', -4], ['복제 조각상', -5], ['짝퉁 태엽새', -5],
    ['플라스틱 진주', -3], ['짝퉁 고서', -3], ['가짜 금괴', -4], ['모조 부적', -4], ['녹슨 왕관', -5], ['위조 보물 지도', -5]];
  const FAKE_GROUPS = [[0, 1, 6, 7], [2, 3, 8, 9], [4, 5, 10, 11]]; // by value −3 / −4 / −5
  const MASTER = [['왕궁 연회도', '천 년의 정원'], ['용왕의 항아리', '구름학 대병'], ['바다별 목걸이', '일곱 빛 왕관'], ['거인의 두상', '날개 달린 여신상']];
  const PAIRS = [['왼쪽 장갑', '오른쪽 장갑'], ['해 촛대', '달 촛대'], ['원앙 수컷', '원앙 암컷'], ['왼쪽 해치상', '오른쪽 해치상'], ['청실 노리개', '홍실 노리개']];
  const BOOKS = ['별자리 도감', '요리 비법서', '마법 주문서'];
  const CHESTS = [['나무 보물상자', 2], ['은 보물상자', 3], ['황금 보물상자', 4]];
  const KEYS = ['녹슨 열쇠', '은 열쇠', '황금 열쇠'];
  const MONEY = [['은화 주머니', 15], ['금화 자루', 18], ['보물 항아리', 22], ['해적 금고', 25], ['왕실 금괴', 30]];
  const CURSES = [['저주받은 가면', 6], ['우는 인형', 5], ['검은 거울', 7], ['뱀 반지', 5]];
  const CHARMS = ['붉은 부적', '행운 방울'];
  const PROPS = ['황금 액자', '도자기 받침대', '유리 진열장', '대리석 좌대'];
  const MYST = [['요술 램프', 1], ['행운 고양이', 2], ['황금 거위', 2], ['모래시계', 2], ['망원경', 1]];
  const Z_LAMP = 0, Z_CAT = 1, Z_GOOSE = 2, Z_HOUR = 3, Z_SCOPE = 4;
  const MYST_D = ['낙찰하면 이벤트 카드 2장', '낙찰하면 이벤트 카드 1장', '3라운드마다 금화 +5', '동점이면 내가 이겨요', '다음 경매품을 미리 봐요'];

  /* item ids: 0..59 colour items (colour c = id/15, tier t, variant k), 60..69 clockwork birds, 70..75 forgeries (kept from the
     first edition), then 6 more birds, 6 more forgeries, masterpieces and the special themes */
  const ITEMS = [];
  for (let c = 0; c < 4; c++) for (let t = 0; t < 5; t++) for (let k = 0; k < 3; k++) ITEMS.push({ k: 'c', c, t, x: k, v: 2 + t, n: NAMES[c][t][k] });
  const BIRD_IDS = [], FAKE_IDS = [];
  for (let i = 0; i < 10; i++) BIRD_IDS.push(ITEMS.push({ k: 'b', x: i, n: BIRDS[i] }) - 1);
  for (let i = 0; i < 6; i++) FAKE_IDS.push(ITEMS.push({ k: 'f', x: i, v: FAKES[i][1], n: FAKES[i][0] }) - 1);
  const add = (o) => ITEMS.push(o) - 1;
  for (let i = 10; i < 16; i++) BIRD_IDS.push(add({ k: 'b', x: i, n: BIRDS[i] }));
  for (let i = 6; i < 12; i++) FAKE_IDS.push(add({ k: 'f', x: i, v: FAKES[i][1], n: FAKES[i][0] }));
  const MASTER_IDS = [];
  for (let c = 0; c < 4; c++) for (let x = 0; x < 2; x++) MASTER_IDS.push(add({ k: 'c', c, t: 5, x, v: 8, n: MASTER[c][x], mp: 1 }));
  const PAIR_IDS = PAIRS.map((p, g) => [0, 1].map((sd) => add({ k: 'p', g, s: sd, n: p[sd] })));
  const BOOK_IDS = BOOKS.map((b, g) => [0, 1, 2].map((vol) => add({ k: 'k', g, s: vol, n: b + ' ' + (vol + 1) + '권' })));
  const CHEST_IDS = CHESTS.map((c, i) => add({ k: 'h', x: i, v: c[1], n: c[0] }));
  const KEY_IDS = KEYS.map((n, i) => add({ k: 'y', x: i, v: 1, n }));
  const MONEY_IDS = MONEY.map((m, i) => add({ k: 'm', x: i, v: 0, m: m[1], n: m[0] }));
  const CURSE_IDS = CURSES.map((c, i) => add({ k: 'x', x: i, v: c[1], n: c[0] }));
  const CHARM_IDS = CHARMS.map((n, i) => add({ k: 'a', x: i, v: 1, n }));
  const PROP_IDS = PROPS.map((n, c) => add({ k: 'c', c, t: -1, x: 0, v: 1, n, pr: 1 }));
  const MYST_IDS = MYST.map((m, i) => add({ k: 'z', x: i, v: m[1], n: m[0] }));
  const item = (i) => ITEMS[i];
  const NORMAL = 25, START = 100, FEE = 10, RAINBOW = 5;
  const PAIR_BONUS = 4, BOOK2 = 3, BOOK3 = 8, CHEST_X = 3, GOOSE_AMT = 5, CARD_COINS = 5;
  /* one JSON-safe character per id (141 items, 87 event cards); ids ≥ 93 use Latin-1 letters (2 bytes in UTF-8) */
  const ALPHA = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&()*+,-.:;=?@' + "'/<>[]^_`{|}~" +
    Array.from({ length: 64 }, (_, i) => String.fromCharCode(0xc0 + i)).join('');
  const idOf = (ch) => ALPHA.indexOf(ch);
  const chOf = (i) => ALPHA[i];
  const kindOf = (id) => { const it = item(id); return it.k === 'c' ? String(it.c) : it.k === 'b' ? '4' : ''; };
  const KIND_N = ['회화', '도자기', '보석', '조각', '태엽새'];
  /* special themes: short rule text shown on the card, in the catalogue and in the rules */
  const SPEC = {
    p: { n: '짝 물건', c: '#e07a9a', d: '한 짝 2점 · 짝을 맞추면 8점' },
    k: { n: '전집', c: '#3fb0a6', d: '권마다 2점 · 같은 책 2권 +3 · 3권 모두 +8' },
    h: { n: '보물상자', c: '#c98a3a', d: '상자 점수 · 열쇠가 있으면 3배' },
    y: { n: '열쇠', c: '#c9b26b', d: '1점 · 열쇠 하나로 상자 하나를 열어요' },
    m: { n: '금화 물건', c: '#e3ae45', d: '점수 없음 · 낙찰하면 바로 금화를 받아요' },
    x: { n: '저주', c: '#9a6ae0', d: '점수가 높지만, 저주: 남은 금화가 점수가 안 돼요' },
    a: { n: '부적', c: '#e05a4a', d: '1점 · 가지고 있으면 내 저주가 모두 풀려요' },
    z: { n: '신비', c: '#4fb3d9', d: '' },
  };
  const THEMES = [
    { n: '짝 물건', k: 'p', pick: () => U.shuffle(PAIR_IDS.slice()).slice(0, 2).reduce((a, p) => a.concat(p), []) },
    { n: '전집', k: 'k', pick: () => BOOK_IDS[U.rand(BOOK_IDS.length)].slice() },
    { n: '보물상자와 열쇠', k: 'h', pick: () => U.shuffle(CHEST_IDS.slice()).slice(0, 2).concat(KEY_IDS[U.rand(KEY_IDS.length)]) },
    { n: '금화 물건', k: 'm', pick: () => U.shuffle(MONEY_IDS.slice()).slice(0, 2) },
    { n: '저주와 부적', k: 'x', pick: () => U.shuffle(CURSE_IDS.slice()).slice(0, 2).concat(CHARM_IDS[U.rand(CHARM_IDS.length)]) },
    { n: '전시 소품', k: 'c', pick: () => U.shuffle(PROP_IDS.slice()).slice(0, 2) },
    { n: '신비한 물건', k: 'z', pick: () => U.shuffle(MYST_IDS.slice()).slice(0, 2) },
  ];
  /* one-line effect of an item (special ones only) */
  function itemHint(id) {
    const it = item(id);
    if (it.k === 'c') return it.pr ? '1점 · ' + COL[it.c].n + ' 1개로 쳐요 (세트·네 색)' : it.mp ? COL[it.c].n + ' 걸작 · 8점' : '';
    if (it.k === 'z') return MYST_D[it.x];
    if (it.k === 'm') return '점수 없음 · 낙찰하면 바로 금화 +' + it.m;
    if (it.k === 'x') return it.v + '점 · 저주: 남은 금화가 점수가 안 돼요';
    return SPEC[it.k] ? SPEC[it.k].d : '';
  }
  const MODE = {
    n: { n: '일반 경매', d: '가장 많이 쓴 사람이 낙찰받고 그 금액을 내요' },
    b: { n: '2개 묶음', d: '낙찰자가 두 점을 모두 가져가요' },
    q: { n: '경매사 수수료', d: '낙찰자는 입찰액에 수수료 ' + FEE + '금화를 더 내요' },
    v: { n: '2등 가격', d: '낙찰자는 두 번째로 높은 입찰액만 내요' },
    f: { n: '위작 주의', d: '가장 적게 쓴 사람이 떠안고, 다른 사람들이 쓴 돈을 위로금으로 받아요' },
  };
  const SPECIALS = { 8: { f: 1, b: 1, q: 1, v: 1 }, 12: { f: 2, b: 1, q: 1, v: 1 }, 16: { f: 3, b: 2, q: 1, v: 1 } };

  /* ---------- event cards ---------- */
  const E = {
    PEEK: 0, PRIO: 1, SPON: 2, COUP: 3, INS: 4, BONUS: 5, CERT: 6, TREND: 7, BLOCK: 8, STEAL: 9, COLL: 10, SWAP: 11, APPR: 12, LOAN: 13, CANCEL: 14,
    SNOOP: 15, RUMOR: 16, PREV: 17, MEGA: 18, CAP: 19, FLOOR: 20, HAGG: 21, REV: 22, LOTTO: 23, ROBIN: 24, DIV: 25, SAVE: 26, BUNDLE: 27, SWITCH: 28,
    SELL: 29, DUMP: 30, THIEF: 31, GUARD: 32, LOCK: 33, TARIFF: 34, CSTEAL: 35, BADGE: 36, RESTORE: 37, WIND: 38, EXTEND: 39, SHORTEN: 40, RIG: 41,
    AMNESTY: 42, INFL: 43, PAIR: 44,
    DUTCH: 45, TWICE: 46, ALLPAY: 47, AVG: 48, OPEN: 49, BLIND: 50, ALLY: 51, COLLR: 52, MINBID: 53, SABO: 54, CBLOCK: 55, ROTATE: 56, ACCUSE: 57,
    TAX: 58, INVEST: 59, OWNER: 60, RAFFLE: 61, RUSH: 62, INSTAL: 63, LEND: 64, BUYOUT: 65, RETURN: 66, REPLICA: 67, APPRAISE: 68, BET: 69,
    MISSION: 70, CURATOR: 71, FAME: 72, FOCUS: 73, BOOM: 74, SLUMP: 75, CRASH: 76, TRIPLE: 77, BIRDYR: 78, NOFAKE: 79, FIXED: 80, FAKEGIFT: 81,
    HEIR: 82, FIRST: 83, BUYNOW: 84, DUEL: 85, SUMPEEK: 86,
  };
  const SPON_ADD = 10, INS_AMT = 10, STEAL_AMT = 10, COLL_AMT = 3, APPR_AMT = 10, LOAN_AMT = 20, LOAN_PEN = 3, EV_EVERY = 3;
  const CAP_AMT = 25, FLOOR_AMT = 15, LOCK_AMT = 20, TARIFF_AMT = 10, ROBIN_AMT = 10, DIV_AMT = 3, DIV_MAX = 15, SAVE_AMT = 15, SAVE_PTS = 3,
    SELL_X = 5, BADGE_PTS = 5, THIEF_PAY = 10, R_MAX = 20, DECK_N = 36, LEGENDS = 4;
  const SABO_AMT = 10, MIN_AMT = 10, ALLY_PTS = 4, INV_IN = 20, INV_OUT = 30, INV_WAIT = 3, RAFFLE_AMT = 5, RUSH_ALL = 10, RUSH_ME = 15,
    LEND_OUT = 15, LEND_BACK = 25, BUY_X = 8, FIX_X = 4, NOW_X = 6, COLL_X = 5, BET_WIN = 12, BET_LOSE = 5, MIS_N = 3, MIS_WIN = 6, MIS_LOSE = 2,
    FAME_PTS = 2, BOOM_AMT = 5, BOOM_N = 3, SLUMP_AMT = 20, SLUMP_N = 3, HEIR_AMT = 30, ACC_PTS = 2, APPR_N = 3, FIX_MIN = 10, CUR_MAX = 5;
  /* round flags (s.rf) and lasting rule changes (s.gf) */
  const RF_CAP = 1, RF_FLOOR = 2, RF_REV = 4, RF_DUTCH = 8, RF_TWICE = 16, RF_ALLPAY = 32, RF_AVG = 64, RF_OPEN = 128, RF_BLIND = 256, RF_FIRST = 512;
  const GF_AMN = 1, GF_INFL = 2, GF_PAIR = 4, GF_CRASH = 8, GF_TRIPLE = 16, GF_BIRD = 32;
  /* categories (colour + name). rarity r: 0 흔함 (2 copies in the pool), 1 드묾 (1 copy), 2 전설 (only 4 of them per game, 1 copy) */
  const CATS = [
    { n: '정보', c: '#6fa8ec' }, { n: '입찰', c: '#5fd3a0' }, { n: '돈', c: '#e3ae45' }, { n: '물품', c: '#b994ec' },
    { n: '방해', c: '#ee6a55' }, { n: '점수', c: '#f08fc0' }, { n: '규칙', c: '#ff9a4d' },
  ];
  const RARE = [{ n: '흔함', c: '#b9b0c8' }, { n: '드묾', c: '#7fc4ff' }, { n: '전설', c: '#ffcf5a' }];
  /* tg: 1 = another player, 2 = one of my items, 3 = an item kind, 4 = next round's auction type, 5 = 이상/미만, 6 = someone else's item.
     nf: not in a forgery round */
  const CARDS = [
    { n: '엿보기', d: '먼저 낸 입찰 중 1등 금액을 몰래 봐요 (위작 경매면 꼴찌 금액)', g: 0, r: 0 },
    { n: '우선권', d: '이번 경매에서 동점이 나면 나에게 유리하게 정해요', g: 1, r: 0 },
    { n: '후원자', d: '이번 내 입찰(1 이상)을 비교할 때 +10으로 쳐요. 내는 돈은 그대로', g: 1, r: 0 },
    { n: '반값 쿠폰', d: '이번 라운드에 내가 내는 돈이 반값(내림)이 돼요', g: 1, r: 0 },
    { n: '위로 보험', d: '이번 경매품을 내가 못 가져가면 은행에서 10금화를 받아요', g: 2, r: 0 },
    { n: '덤 상자', d: '이번에 내가 낙찰되면 물건 더미에서 한 점을 더 받아요', g: 3, r: 1, nf: 1 },
    { n: '명품 인증서', d: '이번에 내가 낙찰받은 물건은 점수 2배 (태엽새는 2마리로 쳐요)', g: 5, r: 1, nf: 1 },
    { n: '유행 바람', d: '이번 경매품 종류는 끝날 때 한 점당 +1점이에요 (모두에게)', g: 5, r: 1, nf: 1 },
    { n: '출입 금지', d: '고른 한 사람은 이번 경매에서 빠져요 (내지도 받지도 않아요)', g: 4, r: 1, tg: 1 },
    { n: '소매치기', d: '고른 사람의 금화 10개를 가져와요', g: 4, r: 0, tg: 1 },
    { n: '모금함', d: '다른 사람 모두에게서 금화 3개씩 받아요', g: 2, r: 0 },
    { n: '맞교환', d: '고른 사람과 가장 최근에 얻은 물건을 서로 바꿔요', g: 3, r: 1, tg: 1 },
    { n: '위작 감별', d: '내 위작 하나를 없애요. 위작이 없으면 금화 10개를 받아요', g: 3, r: 0 },
    { n: '은행 대출', d: '지금 금화 20개를 받고, 끝날 때 3점을 잃어요', g: 2, r: 0 },
    { n: '경매 취소', d: '이번 경매를 바로 끝내요. 물건은 사라지고 아무도 돈을 안 내요', g: 4, r: 1 },
    { n: '쪽지 훔쳐보기', d: '이미 입찰한 사람 한 명을 골라 그 금액을 몰래 봐요', g: 0, r: 0, tg: 1 },
    { n: '소문 듣기', d: '고른 사람이 가진 이벤트 카드를 몰래 다 봐요', g: 0, r: 0, tg: 1 },
    { n: '예고장', d: '다음 라운드 경매품과 경매 방식을 몰래 미리 봐요', g: 0, r: 1 },
    { n: '확성기', d: '지금까지 낸 입찰 금액을 모두에게 공개해요', g: 0, r: 1 },
    { n: '가격 상한', d: '이번 경매는 모든 입찰을 최대 25금화로 쳐요 (넘게 써도 25)', g: 1, r: 0 },
    { n: '최저가 선언', d: '이번 경매는 15금화 이하 입찰이 모두 무효(0)예요', g: 1, r: 0, nf: 1 },
    { n: '흥정', d: '이번 경매를 2등 가격 경매로 바꿔요 (수수료도 없어져요)', g: 1, r: 1 },
    { n: '거꾸로 경매', d: '이번엔 1 이상 쓴 사람 중 가장 적게 쓴 사람이 낙찰돼요', g: 1, r: 2, nf: 1 },
    { n: '복권', d: '금화 0·5·10·15·20·25개 중 하나를 무작위로 받아요', g: 2, r: 0 },
    { n: '로빈 후드', d: '나 말고 가장 부자에게서 금화 10개를 뺏어 가장 가난한 사람에게 줘요', g: 2, r: 1 },
    { n: '배당금', d: '내 물건(위작 빼고) 한 점당 금화 3개를 받아요 (최대 15)', g: 2, r: 0 },
    { n: '적금 통장', d: '지금 금화 15개를 내고, 끝날 때 3점을 받아요', g: 2, r: 0 },
    { n: '보따리 추가', d: '이번 경매품에 더미의 물건 한 점을 얹어 2개 묶음으로 만들어요', g: 3, r: 0, nf: 1 },
    { n: '바꿔치기', d: '이번 경매품을 버리고 더미의 새 물건으로 바꿔요 (낸 입찰은 그대로)', g: 3, r: 1, nf: 1 },
    { n: '벼룩시장', d: '내 물건 하나를 골라 은행에 팔아요 (점수×5금화, 태엽새 15)', g: 3, r: 1, tg: 2 },
    { n: '위작 떠넘기기', d: '내 위작 하나를 고른 사람에게 넘겨요', g: 3, r: 1, tg: 1 },
    { n: '밤도둑', d: '고른 사람의 물건 하나를 무작위로 훔치고 금화 10개를 줘요 (위작일 수도!)', g: 3, r: 2, tg: 1 },
    { n: '경비원', d: '다음에 나를 고르는 카드 한 장을 막아요 (막을 때까지 남아요)', g: 4, r: 0 },
    { n: '지갑 잠금', d: '고른 사람의 이번 입찰은 최대 20금화로만 쳐요', g: 4, r: 0, tg: 1 },
    { n: '추가 관세', d: '고른 사람이 이번에 낙찰되면 금화 10개를 더 내요', g: 4, r: 0, tg: 1, nf: 1 },
    { n: '카드 빼앗기', d: '고른 사람의 이벤트 카드 한 장을 무작위로 가져와요', g: 4, r: 1, tg: 1 },
    { n: '전문가 배지', d: '종류 하나를 골라요. 끝날 때 그 종류를 가장 많이(2점 이상) 가지면 +5점', g: 5, r: 1, tg: 3 },
    { n: '복원 공방', d: '내 색 물건 중 가장 점수 낮은 것을 점수 2배로 만들어요', g: 5, r: 1 },
    { n: '태엽 감기', d: '내 태엽새 한 마리를 2마리로 쳐요', g: 5, r: 1 },
    { n: '경매 연장', d: '맨 끝에 일반 경매 한 라운드를 더해요', g: 6, r: 2 },
    { n: '조기 마감', d: '맨 마지막 라운드를 없애요 (2라운드 넘게 남았을 때)', g: 6, r: 2 },
    { n: '경매사 매수', d: '다음 라운드 경매 방식을 내가 골라요 (위작 경매는 못 바꿔요)', g: 6, r: 1, tg: 4 },
    { n: '위작 사면', d: '이번 판은 끝날 때 위작이 모두 0점이에요', g: 6, r: 2 },
    { n: '물가 상승', d: '이번 판은 끝날 때 남은 금화 5개당 1점이에요 (원래 10개)', g: 6, r: 2 },
    { n: '세트 완화', d: '이번 판은 같은 색 2점만 모아도 그 색 점수가 2배예요', g: 6, r: 2 },
    // ---- 45..86 (라운드 12) ----
    { n: '내림 경매', d: '이번 입찰은 5 단위로 내려서 비교하고, 그 값을 내요', g: 1, r: 0, nf: 1 },
    { n: '봉투 두 번', d: '모두 낸 뒤 1·2등 두 사람만 서로 금액을 보고 한 번 더 입찰해요', g: 1, r: 2, nf: 1 },
    { n: '모두 내기', d: '이번엔 진 사람도 자기 입찰의 절반을 은행에 내요', g: 1, r: 1, nf: 1 },
    { n: '평균가', d: '낙찰자는 1 이상 쓴 입찰들의 평균(올림)만 내요', g: 1, r: 0, nf: 1 },
    { n: '공개 입찰', d: '이제부터 이번 경매 입찰은 내는 즉시 모두에게 보여요', g: 1, r: 0 },
    { n: '깜깜이', d: '이번 경매품을 더미의 새 물건으로 바꿔 덮어요. 모른 채 입찰!', g: 1, r: 1, nf: 1 },
    { n: '동맹 입찰', d: '고른 사람과 입찰을 합쳐요. 이기면 물건은 나, 그 사람은 +4점', g: 1, r: 1, tg: 1, nf: 1 },
    { n: '수집가 등장', d: '수집가가 (점수×5)금화로 입찰해요. 수집가가 이기면 물건이 사라져요', g: 4, r: 0, nf: 1 },
    { n: '공개 경고', d: '고른 사람은 이번에 최소 10금화를 걸어야 해요', g: 4, r: 0, tg: 1 },
    { n: '훼방꾼', d: '고른 사람의 이번 입찰을 10 낮게 쳐요 (내는 돈은 그대로)', g: 4, r: 0, tg: 1 },
    { n: '카드 봉쇄', d: '고른 사람은 이번과 다음 라운드에 카드를 못 써요', g: 4, r: 1, tg: 1 },
    { n: '카드 돌리기', d: '모두 가진 카드를 다음 사람에게 통째로 넘겨요', g: 4, r: 1 },
    { n: '위작 판정', d: '고른 사람은 지금 가진 위작 하나당 끝날 때 −2점 더', g: 4, r: 0, tg: 1 },
    { n: '재산세', d: '나 말고 모두 남은 금화의 10%(내림)를 은행에 내요', g: 2, r: 0 },
    { n: '투자', d: '금화 20개를 맡기면 3라운드 뒤에 30개로 돌려받아요', g: 2, r: 0 },
    { n: '경매장 주인', d: '이번 낙찰자가 내는 돈의 절반을 은행 대신 내가 받아요', g: 2, r: 1, nf: 1 },
    { n: '경품 추첨', d: '모두 금화 5개씩 내고, 무작위 한 명이 다 가져가요', g: 2, r: 0 },
    { n: '골드 러시', d: '모두 금화 +10, 나는 +15', g: 2, r: 0 },
    { n: '할부 구매', d: '이번에 낙찰되면 절반만 지금 내고, 나머지는 끝날 때 내요', g: 2, r: 1, nf: 1 },
    { n: '돈놀이', d: '고른 사람에게 금화 15개를 빌려줘요. 끝날 때 25개를 돌려받아요', g: 2, r: 1, tg: 1 },
    { n: '강제 매입', d: '다른 사람 물건 하나를 (점수×8)금화를 주고 사 와요', g: 3, r: 1, tg: 6 },
    { n: '반품', d: '가장 최근 낙찰받은 물건을 돌려주고 낸 돈의 절반을 받아요', g: 3, r: 0 },
    { n: '전시 소품', d: '고른 색의 전시 소품(1점, 그 색 1개로 쳐요)을 받아요', g: 3, r: 1, tg: 3 },
    { n: '감정서', d: '다음 경매품 3개를 모두에게 공개해요', g: 0, r: 0 },
    { n: '예언 내기', d: '이번 낙찰가가 기준 이상일지 걸어요. 맞히면 +12, 틀리면 −5금화', g: 0, r: 1, tg: 5, nf: 1 },
    { n: '비밀 임무', d: '고른 종류를 끝날 때 3점 이상 가지면 +6점, 못 하면 −2점', g: 5, r: 1, tg: 3 },
    { n: '큐레이터', d: '끝날 때 내가 가진 물건 종류 하나당 +1점 (최대 5점)', g: 5, r: 1 },
    { n: '명성', d: '이번에 내가 낙찰되면 +2점', g: 5, r: 0, nf: 1 },
    { n: '한 우물', d: '끝날 때 가장 많이 모은 색의 물건 한 점당 +1점', g: 5, r: 1 },
    { n: '호황', d: '앞으로 3라운드 동안 라운드마다 모두 금화 +5', g: 6, r: 1 },
    { n: '불황', d: '이번 포함 3라운드 동안 모든 입찰을 최대 20으로 쳐요', g: 6, r: 1 },
    { n: '시장 붕괴', d: '이번 판은 끝날 때 남은 금화 20개당 1점이에요', g: 6, r: 2 },
    { n: '대전시회', d: '이번 판은 같은 색 4점 이상이면 그 색 점수가 3배예요', g: 6, r: 2 },
    { n: '새의 해', d: '이번 판은 태엽새 한 마리당 +2점 더', g: 6, r: 2 },
    { n: '진품 보증', d: '남은 위작 경매 하나를 일반 경매로 바꿔요', g: 6, r: 1 },
    { n: '정가 구매', d: '더미에서 물건 하나를 뽑아 바로 사요 (점수×4금화)', g: 3, r: 1 },
    { n: '위작 선물', d: '아무도 안 쓰는 위작 하나를 고른 사람에게 보내요', g: 4, r: 1, tg: 1 },
    { n: '유산 상속', d: '금화 30개를 받아요. 대신 내 남은 금화는 점수가 안 돼요', g: 2, r: 2 },
    { n: '선착순', d: '이번 경매는 동점이면 먼저 입찰한 사람이 이겨요', g: 1, r: 0, nf: 1 },
    { n: '즉시 구매', d: '경매 없이 이번 물건을 (점수×6)금화에 바로 사요', g: 3, r: 1, nf: 1 },
    { n: '일대일', d: '이번 경매는 나와 고른 사람만 입찰해요', g: 4, r: 1, tg: 1, nf: 1 },
    { n: '회계 장부', d: '지금까지 낸 입찰의 합계와 개수를 몰래 봐요', g: 0, r: 0 },
  ];
  CARDS.forEach((c) => { c.c = CATS[c.g].c; });
  const TARGET = {};
  CARDS.forEach((c, k) => { if (c.tg) TARGET[k] = c.tg; });
  const NEXT_MODES = 'nbqv';
  /* cards that would reveal or change a covered lot, and cards that make no sense in a second envelope */
  const NO_BLIND = [E.TREND, E.BUNDLE, E.SWITCH, E.COLLR, E.BET, E.BUYNOW, E.BLIND];
  const NO_T2 = [E.BUNDLE, E.SWITCH, E.BUYNOW, E.BLIND];

  /* hidden bids travel lightly scrambled (the view never shows them before the reveal) */
  const scr = (t) => { let r = ''; for (let i = 0; i < t.length; i++) r += String.fromCharCode(t.charCodeAt(i) ^ 21); return r.split('').reverse().join(''); };
  const unscr = (t) => { const x = t.split('').reverse().join(''); let r = ''; for (let i = 0; i < x.length; i++) r += String.fromCharCode(x.charCodeAt(i) ^ 21); return r; };
  const enc = (v) => scr(String(v * 7 + 3));
  const dec = (s) => (parseInt(unscr(s), 10) - 3) / 7;
  const bit = (m, i) => ((m || 0) >> i) & 1;

  /* ---------- scoring ---------- */
  /* cf: certified item chars (count double), tr: trend kinds (+1 per item of that kind), ep: card points (loan, savings, …),
     gf: lasting rule changes, bp: 전문가 배지 points, ex: {nc: 유산 상속, cu: 큐레이터, fo: 한 우물, ms: 비밀 임무 points} */
  function score(co, coins, cf, tr, ep, gf, bp, ex) {
    gf = gf || 0; ex = ex || {};
    const cnt = [0, 0, 0, 0], sum = [0, 0, 0, 0], phys = [0, 0, 0, 0, 0];
    let birds = 0, fake0 = 0, sp = 0, curse = 0, charm = 0, keys = 0;
    const pr = {}, bk = {}, ch = [], kinds = {};
    for (const c of co || '') {
      const it = item(idOf(c)), x = cf && cf.indexOf(c) >= 0 ? 2 : 1;
      if (it.k !== 'f') kinds[it.k === 'c' ? 'c' + it.c : it.k] = 1;
      switch (it.k) {
        case 'c': cnt[it.c]++; sum[it.c] += it.v * x; phys[it.c]++; break;
        case 'b': birds += x; phys[4]++; break;
        case 'f': fake0 += it.v; break;
        case 'p': pr[it.g] = (pr[it.g] || 0) | (1 << it.s); sp += 2 * x; break;
        case 'k': bk[it.g] = (bk[it.g] || 0) + 1; sp += 2 * x; break;
        case 'h': ch.push(it.v * x); break;
        case 'y': keys++; sp += x; break;
        case 'x': curse++; sp += it.v * x; break;
        case 'a': charm++; sp += x; break;
        case 'z': sp += it.v * x; break;
      }
    }
    for (const g in pr) if (pr[g] === 3) sp += PAIR_BONUS;
    for (const g in bk) sp += bk[g] >= 3 ? BOOK3 : bk[g] === 2 ? BOOK2 : 0;
    ch.sort((a, b) => b - a).forEach((v, i) => { sp += v * (i < keys ? CHEST_X : 1); });
    const fake = gf & GF_AMN ? 0 : fake0;
    const need = gf & GF_PAIR ? 2 : 3;
    let base = 0, bonus = 0;
    for (let k = 0; k < 4; k++) {
      base += sum[k];
      if ((gf & GF_TRIPLE) && cnt[k] >= 4) bonus += 2 * sum[k];
      else if (cnt[k] >= need) bonus += sum[k];
    }
    let trend = 0;
    for (const t of tr || '') trend += phys[+t];
    const bird = birds * birds + (gf & GF_BIRD ? 2 * birds : 0), rb = cnt.every((x) => x > 0) ? RAINBOW : 0;
    const cursed = curse > 0 && !charm;
    let cp = Math.floor((coins || 0) / coinRate(gf));
    if (cp > 0 && (cursed || ex.nc)) cp = 0;
    const cu = ex.cu ? Math.min(CUR_MAX, Object.keys(kinds).length) : 0, fo = ex.fo ? Math.max(...cnt) : 0, ms = ex.ms || 0;
    const ev = ep || 0, bd = bp || 0;
    const items = base + bonus + bird + rb + fake + trend + ev + bd + sp + cu + fo + ms;
    return { cnt, sum, birds, base, bonus, bird, rb, fake, fake0, trend, ev, bd, sp, cu, fo, ms, cursed, curse, cp, items, total: items + cp };
  }
  const coinRate = (gf) => (gf & GF_INFL ? 5 : gf & GF_CRASH ? 20 : 10);
  const countKind = (co, d) => { let k = 0; for (const ch of co || '') if (kindOf(idOf(ch)) === d) k++; return k; };
  /* 전문가 배지: +5 for each badge kind where I hold the most (ties count) and at least 2 */
  function badgePts(s, i) {
    if (!s.gl) return 0;
    let p = 0;
    for (let j = 0; j + 1 < s.gl.length; j += 2) {
      if (+s.gl[j] !== i) continue;
      const d = s.gl[j + 1], me = countKind(s.co[i], d);
      let mx = 0;
      for (let o = 0; o < s.n; o++) if (o !== i) mx = Math.max(mx, countKind(s.co[o], d));
      if (me >= 2 && me >= mx) p += BADGE_PTS;
    }
    return p;
  }
  /* 비밀 임무: +6 if I hold 3+ of the kind, otherwise −2 */
  function missionPts(s, i) {
    if (!s.ms) return 0;
    let p = 0;
    for (let j = 0; j + 1 < s.ms.length; j += 2) if (+s.ms[j] === i) p += countKind(s.co[i], s.ms[j + 1]) >= MIS_N ? MIS_WIN : -MIS_LOSE;
    return p;
  }
  const coinsAt = (s, i) => s.c[i] + (s.dc ? s.dc[i] : 0);
  const scoreOf = (s, i) => score(s.co[i], coinsAt(s, i), s.cf, s.tr, s.ep ? s.ep[i] : 0, s.gf, badgePts(s, i),
    { nc: bit(s.nc, i), cu: bit(s.cu, i), fo: bit(s.fo, i), ms: missionPts(s, i) });

  /* ---------- rules ---------- */
  /* this game's event deck: commons ×2, rares ×1 and 4 random legends, shuffled → the first 36 are dealt in order */
  function buildDeck() {
    const pool = [], leg = [];
    CARDS.forEach((c, k) => { if (c.r === 0) pool.push(k, k); else if (c.r === 1) pool.push(k); else leg.push(k); });
    U.shuffle(leg).slice(0, LEGENDS).forEach((k) => pool.push(k));
    return U.shuffle(pool).slice(0, DECK_N).map(chOf).join('');
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const R = [8, 12, 16].includes(opts.rounds) ? opts.rounds : 12;
    const sp = SPECIALS[R];
    const q = [];
    for (const k in sp) for (let i = 0; i < sp[k]; i++) q.push(k);
    while (q.length < R - 1) q.push('n');
    U.shuffle(q); q.unshift('n'); // the first lot is always a plain one
    // this game's lots: one random variant of every colour × value (2..6), 5 of the 16 clockwork birds, 1–2 masterpieces
    // and 1–3 special themes (more rounds → more themes)
    const pool = [];
    for (let c = 0; c < 4; c++) for (let t = 0; t < 5; t++) pool.push(c * 15 + t * 3 + U.rand(3));
    U.shuffle(BIRD_IDS.slice()).slice(0, 5).forEach((x) => pool.push(x));
    U.shuffle(MASTER_IDS.slice()).slice(0, R >= 16 ? 2 : 1).forEach((x) => pool.push(x));
    const th = U.shuffle(THEMES.map((_, i) => i)).slice(0, R <= 8 ? 1 : R >= 16 ? 3 : 2).sort((a, b) => a - b);
    th.forEach((t) => THEMES[t].pick().forEach((x) => pool.push(x)));
    const dk = U.shuffle(pool).map(chOf).join('');
    const fk = U.shuffle([0, 1, 2].map((g) => FAKE_IDS[FAKE_GROUPS[g][U.rand(4)]])).map(chOf).join('');
    const s = {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), c: Array(n).fill(START), co: Array(n).fill(''),
      R, r: 0, q: q.join(''), dk, di: 0, fk, fi: 0, th: th.join(''), lot: '', md: 'n', b: Array(n).fill(null), h: [], sa: opts.all === 1 ? 1 : 0,
      last: null, seq: 0, ph: 'b', eo: opts.ev === 0 ? 0 : 1,
    };
    if (s.eo) Object.assign(s, { ek: buildDeck(), ei: 0, ev: Array(n).fill(''), cf: '', tr: '', ep: Array(n).fill(0), lc: null, dr: -1, sh: 0, gf: 0, gl: '' });
    startRound(s);
    return s;
  }
  /* per-round card state (deleted when a new round starts): 2nd envelope, ally, collector, warnings, saboteurs, owner, fame, instalment,
     bets, bid order */
  const ROUND_KEYS = ['t2', 'al', 'cv', 'mb', 'sb', 'ow', 'fm', 'it', 'bt', 'bo'];
  function startRound(s) {
    s.md = s.q[s.r];
    if (s.md === 'f') s.lot = s.fk[s.fi++];
    else if (s.md === 'b') { s.lot = s.dk.substr(s.di, 2); s.di += 2; }
    else s.lot = s.dk[s.di++];
    s.b = Array(s.n).fill(null);
    s.u = Array(s.n).fill(-1); // event card used this round by each seat
    s.x = 0; // bitmask: seats shut out of this lot (출입 금지)
    s.pk = Array(s.n).fill(null); // private card info (엿보기 · 쪽지 · 소문 · 예고장 · 회계 장부), scrambled like bids
    ROUND_KEYS.forEach((k) => { delete s[k]; });
    if (s.eo) {
      s.rf = 0; s.lk = 0; s.tf = 0; s.op = null; // round flags · 지갑 잠금 · 추가 관세 · public bids
      if (s.bm > 0) { for (let i = 0; i < s.n; i++) s.c[i] += BOOM_AMT; if (!--s.bm) delete s.bm; } // 호황
      if (s.dp > 0 && !--s.dp) delete s.dp; // 불황 runs out
      payInvest(s, false);
    }
  }
  function payInvest(s, all) {
    if (!s.iv) return;
    s.iv = s.iv.filter(([i, r, a]) => { if (all || r <= s.r) { s.c[i] += a; return false; } return true; });
    if (!s.iv.length) delete s.iv;
  }
  const prio = (s) => s.r % s.n; // tie priority rotates every round
  const order = (s) => Array.from({ length: s.n }, (_, k) => (prio(s) + k) % s.n);
  const maxBid = (s, seat) => (s.md === 'q' ? Math.max(0, s.c[seat] - FEE) : s.c[seat]);
  /* the least a seat may bid: 봉투 두 번 (not below the first envelope) and 공개 경고 */
  function minBid(s, seat) {
    let m = 0;
    if (s.t2) { if (seat === s.t2[0]) m = s.t2[2]; else if (seat === s.t2[1]) m = s.t2[3]; }
    if (bit(s.mb, seat)) m = Math.max(m, MIN_AMT);
    return Math.min(m, maxBid(s, seat));
  }
  const isOut = (s, i) => ((s.x || 0) >> i) & 1;
  /* coins a seat has already promised with a hidden bid this round (cards can never take those) */
  function reserve(s, i) {
    if (s.b[i] == null || isOut(s, i)) return 0;
    const v = dec(s.b[i]);
    return v + (s.md === 'q' && v > 0 ? FEE : 0);
  }
  const free = (s, i) => Math.max(0, s.c[i] - reserve(s, i));
  /* rounds still to come after this one need these lots; anything beyond is spare for cards (drawn from the back) */
  const spare = (s) => s.dk.length - s.di - slotsAfter(s);
  function drawBack(s) { const ch = s.dk[s.dk.length - 1]; s.dk = s.dk.slice(0, -1); return ch; }
  /* every seat is listed while bidding so the core never puts up its single-seat curtain; seats that already bid are rejected */
  function actor(s) { return s.ph === 'b' ? Array.from({ length: s.n }, (_, i) => i) : null; }
  const addDc = (s, i, v) => { if (!s.dc) s.dc = Array(s.n).fill(0); s.dc[i] += v; };
  const ownerOf = (s, id) => { const ch = chOf(id); for (let i = 0; i < s.n; i++) if ((s.co[i] || '').indexOf(ch) >= 0) return i; return -1; };
  /* what an item is "worth" at face value (points; money items count coins/5) */
  function faceOf(id) {
    const it = item(id);
    switch (it.k) {
      case 'b': return 3;
      case 'p': case 'k': return 2;
      case 'm': return it.m / 5;
      default: return it.v;
    }
  }
  function faceValue(lot) { let v = 0; for (const ch of lot) v += faceOf(idOf(ch)); return v; }
  const collVal = (s) => Math.max(5, Math.round(faceValue(s.lot) * COLL_X));
  const nowPrice = (s) => Math.max(5, Math.round(faceValue(s.lot) * NOW_X));
  const betLine = (s) => Math.max(5, Math.round(faceValue(s.lot) * 4 / 5) * 5);
  const buyPrice = (id) => Math.max(5, Math.round(faceOf(id) * BUY_X));

  /* bids as they count: 지갑 잠금 / 가격 상한 / 불황 cap them, 최저가 선언 voids the small ones, 내림 경매 rounds them down to 5s */
  function countBids(s, raw) {
    const rf = s.rf || 0, b = raw.slice(), slump = (s.dp || 0) > 0;
    let adj = 0;
    for (let i = 0; i < s.n; i++) {
      let v = b[i];
      if (bit(s.lk, i)) v = Math.min(v, LOCK_AMT);
      if (rf & RF_CAP) v = Math.min(v, CAP_AMT);
      if (slump) v = Math.min(v, SLUMP_AMT);
      if ((rf & RF_FLOOR) && v <= FLOOR_AMT) v = 0;
      if (rf & RF_DUTCH) v = Math.floor(v / 5) * 5;
      if (v !== b[i]) { adj |= 1 << i; b[i] = v; }
    }
    return { b, adj };
  }
  /* on-win effects of special items: money pays out, the lamp and the cat bring event cards (coins when cards are off / gone) */
  function gain(s, w, chars) {
    let c = 0, k = 0, got = 0;
    for (const ch of chars) {
      const it = item(idOf(ch));
      if (it.k === 'm') c += it.m;
      else if (it.k === 'z' && it.x === Z_LAMP) k += 2;
      else if (it.k === 'z' && it.x === Z_CAT) k += 1;
    }
    for (let j = 0; j < k; j++) { if (s.eo && s.ei < s.ek.length) { s.ev[w] += s.ek[s.ei++]; got++; } else c += CARD_COINS; }
    s.c[w] += c;
    return c || got ? { c, k: got } : null;
  }
  function resolve(s, raw) {
    const u = s.u || [], f = s.md === 'f', rf = s.rf || 0, al = s.al || null;
    const { b: bids, adj } = countBids(s, raw);
    const partner = al && !isOut(s, al[1]) ? al[1] : -1;
    const inn = (i) => !isOut(s, i) && !(al && i === al[1]);
    const own = (i) => bids[i] + (u[i] === E.SPON && bids[i] > 0 ? SPON_ADD : 0) - (bit(s.sb, i) && bids[i] > 0 ? SABO_AMT : 0);
    const team = (i) => (al && i === al[0] && partner >= 0 ? bids[partner] : 0);
    const eff = (i) => own(i) + team(i);
    const pos = (i) => bids[i] + team(i) > 0;
    const half = (i, v) => (u[i] === E.COUP ? Math.floor(v / 2) : v);
    // tie order: 우선권 cards first, then the 모래시계 owner, then (선착순) bid order or the rotating priority
    let base = order(s);
    if ((rf & RF_FIRST) && s.bo) { const bo = s.bo.split('').map(Number); base = bo.concat(base.filter((i) => bo.indexOf(i) < 0)); }
    const hg = ownerOf(s, MYST_IDS[Z_HOUR]);
    const pr = base.filter((i) => u[i] === E.PRIO), hl = hg >= 0 && u[hg] !== E.PRIO ? [hg] : [], np = base.filter((i) => u[i] !== E.PRIO && i !== hg);
    const ord = f ? np.concat(hl, pr) : pr.concat(hl, np); // forgery: the lucky ones go last
    let w = -1, pay = 0, tie = 0, ex = '', tx = 0, p2 = 0, ap = 0, gn = null, cw = 0;
    if (f) {
      let mn = Infinity;
      for (const i of ord) if (!isOut(s, i) && eff(i) < mn) { mn = eff(i); w = i; }
      if (w >= 0) {
        tie = ord.filter((i) => !isOut(s, i) && eff(i) === mn).length > 1 ? 1 : 0;
        for (let i = 0; i < s.n; i++) if (i !== w && !isOut(s, i)) { const p = half(i, bids[i]); s.c[i] -= p; pay += p; }
        s.c[w] += pay;
        s.co[w] += s.lot;
      }
    } else {
      const rev = rf & RF_REV;
      let best = rev ? Infinity : 0;
      for (const i of ord) {
        if (!inn(i) || !pos(i)) continue;
        if (rev ? eff(i) < best : eff(i) > best) { best = eff(i); w = i; }
      }
      if (s.cv > 0 && (w < 0 || s.cv >= best)) { cw = 1; w = -1; } // 수집가 wins (players must beat it)
      if (w >= 0) {
        tie = ord.filter((i) => inn(i) && pos(i) && eff(i) === best).length > 1 ? 1 : 0;
        const fee = s.md === 'q' ? FEE : 0;
        if (al && w === al[0]) pay = bids[w] + Math.min(fee, s.c[w] - bids[w]); // the team may win on the partner's money alone
        else if (s.md === 'v' && !rev) {
          pay = s.cv || 0;
          bids.forEach((x, i) => { if (i !== w && inn(i)) pay = Math.max(pay, x); });
          if (rf & RF_FLOOR) pay = Math.max(pay, FLOOR_AMT + 1);
          pay = Math.min(pay, bids[w]);
        } else if (rf & RF_AVG) {
          let sm = 0, k = 0;
          for (let i = 0; i < s.n; i++) if (inn(i) && bids[i] > 0) { sm += bids[i]; k++; }
          pay = Math.min(bids[w], Math.ceil(sm / Math.max(1, k))) + fee;
        } else pay = bids[w] + fee;
        pay = half(w, pay);
        if (bit(s.it, w)) { const later = Math.floor(pay / 2); s.c[w] -= pay - later; addDc(s, w, -later); } // 할부 구매
        else s.c[w] -= pay;
        if (bit(s.tf, w)) { tx = Math.min(TARIFF_AMT, s.c[w]); s.c[w] -= tx; } // 추가 관세
        if (al && w === al[0] && partner >= 0) { p2 = half(partner, bids[partner]); s.c[partner] -= p2; s.ep[partner] += ALLY_PTS; } // 동맹
        if (s.ow != null && s.ow !== w) s.c[s.ow] += Math.floor((pay + p2) / 2); // 경매장 주인
        s.co[w] += s.lot;
        if (u[w] === E.BONUS && spare(s) > 0) { ex = drawBack(s); s.co[w] += ex; }
        if (u[w] === E.CERT) s.cf += s.lot;
        if (bit(s.fm, w)) s.ep[w] += FAME_PTS;
        gn = gain(s, w, s.lot + ex);
      }
      if (rf & RF_ALLPAY) { // 모두 내기: every loser pays half of what they wrote
        for (let i = 0; i < s.n; i++) {
          if (isOut(s, i) || i === w || (w >= 0 && i === partner && w === al[0]) || bids[i] <= 0) continue;
          const a = Math.min(Math.floor(half(i, bids[i]) / 2), s.c[i]);
          s.c[i] -= a; ap += a;
        }
      }
    }
    let bets = null;
    if (s.bt) { // 예언 내기
      const price = w >= 0 ? pay : 0;
      bets = s.bt.map(([i, d, N]) => {
        const hit = d === 0 ? price >= N : price < N, amt = hit ? BET_WIN : -Math.min(BET_LOSE, s.c[i]);
        s.c[i] += amt;
        return [i, amt];
      });
    }
    const ins = [];
    for (let i = 0; i < s.n; i++) if (u[i] === E.INS && i !== w) { s.c[i] += INS_AMT; ins.push(i); }
    return { w: cw ? -3 : w, pay, tie, ex, ins, b: bids, adj, tx, p2, ap, gn, bets };
  }
  const usesStr = (u) => (u || []).map((k, i) => (k >= 0 ? String(i) + chOf(k) : '')).join('');

  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (s.ph !== 'b') throw new Error('not bidding');
    if (!Number.isInteger(seat) || seat < 0 || seat >= s.n) throw new Error('bad seat');
    if (s.b[seat] != null) throw new Error('already bid');
    if (a.t === 'card') return playCard(s, seat, a);
    if (a.t !== 'bid') throw new Error('bad action');
    const v = a.v;
    if (!Number.isInteger(v) || v < minBid(s, seat) || v > maxBid(s, seat)) throw new Error('bad bid');
    s.b[seat] = enc(v);
    if (s.eo) {
      s.bo = (s.bo || '') + seat;
      if (s.rf & RF_OPEN) { if (!s.op) s.op = Array(s.n).fill(-1); s.op[seat] = v; } // 공개 입찰
    }
    maybeResolve(s);
    return s;
  }
  function maybeResolve(s) {
    if (s.b.some((x) => x == null)) return;
    const raw = s.b.map(dec);
    // 봉투 두 번: the first envelope only picks the two who bid again
    if (((s.rf || 0) & RF_TWICE) && !s.t2) {
      const { b } = countBids(s, raw);
      const cand = order(s).filter((i) => !isOut(s, i) && b[i] > 0).sort((p, q2) => b[q2] - b[p]);
      if (cand.length >= 2) {
        const [a1, a2] = cand;
        s.t2 = [a1, a2, raw[a1], raw[a2]];
        s.last = { id: ++s.seq, r: s.r, lot: s.lot, md: s.md, b, w: -1, pay: 0, tie: 0, st: prio(s), tw: [a1, a2] };
        if (s.u.some((k) => k >= 0)) s.last.u = s.u.slice();
        if (s.x) s.last.x = s.x;
        for (let i = 0; i < s.n; i++) if (i !== a1 && i !== a2) s.x |= 1 << i;
        s.b[a1] = null; s.b[a2] = null; s.bo = ''; s.op = null;
        return;
      }
    }
    const lot = s.lot, md = s.md, r = s.r, st = prio(s), u = (s.u || []).slice(), x = s.x || 0, rf = s.rf || 0, lk = s.lk || 0, tf = s.tf || 0;
    const res = resolve(s, raw);
    const us = usesStr(u);
    const e = [lot, md, res.w, res.pay];
    if (s.sa || us) e.push(s.sa ? res.b : 0);
    if (us) e.push(us);
    s.h.push(e);
    const l = s.last = { id: ++s.seq, r, lot, md, b: res.b, w: res.w, pay: res.pay, tie: res.tie, st };
    if (us) l.u = u;
    if (x) l.x = x;
    if (res.ex) l.ex = res.ex;
    if (res.ins.length) l.ins = res.ins;
    if (res.adj) { l.ad = res.adj; l.rb = raw; }
    if (rf) l.rf = rf;
    if (lk) l.lk = lk;
    if (tf) l.tf = tf;
    if (res.tx) l.tx = res.tx;
    if (s.t2) l.t2 = s.t2.slice(0, 2);
    if (s.al) { l.al = s.al; if (res.p2) l.p2 = res.p2; }
    if (s.cv) l.cv = s.cv;
    if (s.ow != null) l.ow = s.ow;
    if (s.sb) l.sb = s.sb;
    if (res.ap) l.ap = res.ap;
    if (res.gn) l.gn = res.gn;
    if (res.bets) l.bt = res.bets;
    if (s.dp > 0) l.dp = 1;
    advance(s);
  }
  function advance(s) {
    s.r++;
    if (s.r >= s.R) {
      payInvest(s, true);
      s.ph = 'e'; s.lot = ''; s.b = []; s.u = []; s.pk = []; s.x = 0;
      ROUND_KEYS.forEach((k) => { delete s[k]; });
      if (s.eo) { s.rf = 0; s.lk = 0; s.tf = 0; s.op = null; }
      return;
    }
    if (s.r % EV_EVERY === 0) {
      const g = ownerOf(s, MYST_IDS[Z_GOOSE]); // 황금 거위 lays a golden egg
      if (g >= 0) { s.c[g] += GOOSE_AMT; s.gz = s.r; }
      if (s.eo) deal(s);
    }
    startRound(s);
  }
  function deal(s) {
    let any = 0;
    for (let i = 0; i < s.n; i++) if (s.ei < s.ek.length) { s.ev[i] += s.ek[s.ei++]; any = 1; }
    if (any) s.dr = s.r;
  }

  /* --- event cards: what's legal --- */
  const hasFake = (co) => { for (const ch of co || '') if (item(idOf(ch)).k === 'f') return true; return false; };
  const fakeCount = (co) => { let k = 0; for (const ch of co || '') if (item(idOf(ch)).k === 'f') k++; return k; };
  const sellPrice = (id) => { const it = item(id); return it.k === 'f' || it.k === 'm' ? 0 : Math.round(faceOf(id) * SELL_X); };
  const sellable = (co) => { for (const ch of co || '') if (sellPrice(idOf(ch)) > 0) return true; return false; };
  const hasMoney = (lot) => { for (const ch of lot) if (item(idOf(ch)).k === 'm') return true; return false; };
  /* cheapest colour item that isn't certified yet (복원 공방) / first plain bird (태엽 감기) */
  function restoreIdx(s, seat) {
    const co = s.co[seat] || '';
    let bi = -1, bv = 99;
    for (let j = 0; j < co.length; j++) { const it = item(idOf(co[j])); if (it.k === 'c' && !it.pr && s.cf.indexOf(co[j]) < 0 && it.v < bv) { bv = it.v; bi = j; } }
    return bi;
  }
  function windIdx(s, seat) {
    const co = s.co[seat] || '';
    for (let j = 0; j < co.length; j++) if (item(idOf(co[j])).k === 'b' && s.cf.indexOf(co[j]) < 0) return j;
    return -1;
  }
  /* 로빈 후드: [richest other (who pays), poorest (who gets)] — or null */
  function robinPair(s, seat) {
    let rich = -1;
    for (const i of order(s)) if (i !== seat && free(s, i) > 0 && (rich < 0 || s.c[i] > s.c[rich])) rich = i;
    if (rich < 0) return null;
    let poor = seat;
    for (const i of order(s)) if (i !== rich && s.c[i] < s.c[poor]) poor = i;
    return [rich, poor];
  }
  /* lots of the coming rounds, in order (예고장 · 감정서 · 망원경) */
  function upcoming(s, k) {
    const out = [];
    let di = s.di, fi = s.fi;
    for (let r = s.r + 1; r < s.R && out.length < k; r++) {
      const m = s.q[r];
      if (m === 'f') out.push({ md: m, lot: s.fk[fi++] });
      else if (m === 'b') { out.push({ md: m, lot: s.dk.substr(di, 2) }); di += 2; } else out.push({ md: m, lot: s.dk[di++] });
    }
    return out;
  }
  const nextLot = (s) => upcoming(s, 1)[0] || null;
  /* 반품: my latest won lot that I still hold (part of it, for a bundle) */
  function returnable(s, seat) {
    const co = s.co[seat] || '';
    for (let j = s.h.length - 1; j >= 0; j--) {
      const e = s.h[j];
      if (e[2] !== seat || e[1] === 'f') continue;
      const chars = e[0].split('').filter((ch) => co.indexOf(ch) >= 0).join('');
      if (chars) return { chars, pay: e[3] };
    }
    return null;
  }
  /* forgeries this game never uses (위작 선물) */
  function unusedFakes(s) {
    return FAKE_IDS.filter((id) => { const ch = chOf(id); return s.fk.indexOf(ch) < 0 && !s.co.some((co) => co.indexOf(ch) >= 0); });
  }
  /* 전시 소품 of colour c is free to hand out if it isn't in this game at all */
  function propFree(s, c) {
    const ch = chOf(PROP_IDS[c]);
    return s.dk.indexOf(ch) < 0 && !s.co.some((co) => co.indexOf(ch) >= 0) && !s.h.some((e) => e[0].indexOf(ch) >= 0);
  }
  function nextFake(s) { for (let r = s.r + 1; r < s.R; r++) if (s.q[r] === 'f') return r; return -1; }
  /* legal target values of each kind (1 seat · 2 my item · 3 kind · 4 next mode · 5 이상/미만 · 6 seat×64 + item) */
  function tgList(s, seat, k) {
    const ty = TARGET[k], r = [];
    if (ty === 1) for (let t = 0; t < s.n; t++) r.push(t);
    else if (ty === 2) for (let t = 0; t < (s.co[seat] || '').length; t++) r.push(t);
    else if (ty === 3) for (let t = 0; t < 5; t++) r.push(t);
    else if (ty === 4) for (let t = 0; t < NEXT_MODES.length; t++) r.push(t);
    else if (ty === 5) r.push(0, 1);
    else if (ty === 6) for (let o = 0; o < s.n; o++) if (o !== seat) for (let j = 0; j < Math.min(64, (s.co[o] || '').length); j++) r.push(o * 64 + j);
    return r;
  }
  /* why a target can't be chosen ('' = OK) */
  function targetWhy(s, seat, k, t) {
    const ty = TARGET[k];
    if (ty === 2) { // one of my items
      const co = s.co[seat] || '';
      if (!Number.isInteger(t) || t < 0 || t >= co.length) return '고를 수 없어요';
      const it = item(idOf(co[t]));
      return it.k === 'f' ? '위작은 못 팔아요' : sellPrice(idOf(co[t])) <= 0 ? '팔 수 없는 물건이에요' : '';
    }
    if (ty === 3) { // an item kind
      if (!Number.isInteger(t) || t < 0 || t > 4) return '고를 수 없어요';
      if (k === E.REPLICA) { if (t > 3) return '색만 고를 수 있어요'; return propFree(s, t) ? '' : '이미 나온 소품이에요'; }
      const lst = k === E.MISSION ? s.ms || '' : s.gl || '';
      for (let j = 0; j + 1 < lst.length; j += 2) if (+lst[j] === seat && +lst[j + 1] === t) return '이미 고른 종류예요';
      return '';
    }
    if (ty === 4) { // next round's type
      if (!Number.isInteger(t) || t < 0 || t >= NEXT_MODES.length) return '고를 수 없어요';
      const cur = s.q[s.r + 1], m = NEXT_MODES[t];
      if (m === cur) return '이미 그 방식이에요';
      if (m === 'b' && spare(s) < 1) return '남은 물건이 모자라요';
      return '';
    }
    if (ty === 5) return t === 0 || t === 1 ? '' : '고를 수 없어요';
    if (ty === 6) { // someone else's item
      if (!Number.isInteger(t) || t < 0) return '고를 수 없어요';
      const o = t >> 6, j = t & 63;
      if (o >= s.n || o === seat || j >= (s.co[o] || '').length) return '고를 수 없어요';
      const id = idOf(s.co[o][j]), it = item(id);
      if (it.k === 'f' || it.k === 'm') return '살 수 없는 물건이에요';
      if (buyPrice(id) > free(s, seat)) return '금화가 모자라요';
      return '';
    }
    if (!Number.isInteger(t) || t < 0 || t >= s.n || t === seat) return '고를 수 없어요';
    if ((k === E.BLOCK || k === E.LOCK || k === E.TARIFF || k === E.ALLY || k === E.MINBID || k === E.SABO || k === E.DUEL) && isOut(s, t)) return '이미 빠졌어요';
    if (k === E.STEAL && s.c[t] <= 0) return '금화가 없어요';
    if (k === E.SWAP) { if (!s.co[seat]) return '내 물건이 없어요'; if (!s.co[t]) return '물건이 없어요'; }
    if (k === E.SNOOP && (s.b[t] == null || isOut(s, t))) return '아직 입찰 안 했어요';
    if ((k === E.RUMOR || k === E.CSTEAL || k === E.CBLOCK) && !(s.ev[t] || '').length) return '카드가 없어요';
    if (k === E.CBLOCK && s.cbu && s.cbu[t] > s.r) return '이미 봉쇄됐어요';
    if (k === E.THIEF && !s.co[t]) return '물건이 없어요';
    if (k === E.LOCK && bit(s.lk, t)) return '이미 잠겼어요';
    if (k === E.TARIFF && bit(s.tf, t)) return '이미 관세가 붙었어요';
    if (k === E.MINBID) { if (s.b[t] != null) return '이미 입찰했어요'; if (bit(s.mb, t)) return '이미 경고받았어요'; }
    if (k === E.SABO && bit(s.sb, t)) return '이미 훼방 중이에요';
    if (k === E.ACCUSE && !hasFake(s.co[t])) return '위작이 없어요';
    return '';
  }
  function cantUse(s, seat, k, tg) {
    if (!s.eo || s.ph !== 'b') return '지금은 못 써요';
    if (s.b[seat] != null) return '입찰한 뒤에는 못 써요';
    if (s.u[seat] >= 0) return '한 라운드에 한 장만 써요';
    if (s.cbu && s.cbu[seat] >= s.r) return '카드 봉쇄 중이에요';
    const C = CARDS[k], f = s.md === 'f', rf = s.rf || 0, gf = s.gf || 0;
    if (C.nf && f) return '위작 경매엔 못 써요';
    if ((rf & RF_BLIND) && NO_BLIND.indexOf(k) >= 0) return '덮인 경매엔 못 써요';
    if (s.t2 && (C.g === 1 || C.g === 4 || NO_T2.indexOf(k) >= 0)) return '두 번째 입찰 중엔 못 써요';
    const single = s.lot.length === 1 && 'nqv'.indexOf(s.md) >= 0;
    switch (k) {
      case E.PEEK: case E.MEGA: case E.SUMPEEK: if (peekVal(s, seat) < 0) return '아직 아무도 입찰하지 않았어요'; break;
      case E.BONUS: if (spare(s) < 1) return '남은 물건이 없어요'; break;
      case E.PREV: if (s.r >= s.R - 1) return '마지막 경매예요'; break;
      case E.CAP: if (rf & RF_CAP) return '이미 상한이 있어요'; break;
      case E.FLOOR: if (rf & RF_FLOOR) return '이미 선언됐어요'; break;
      case E.HAGG: if (s.md !== 'n' && s.md !== 'q') return '일반·수수료 경매에서만 써요'; break;
      case E.REV: if (rf & RF_REV) return '이미 거꾸로예요'; if (s.cv) return '수집가가 있어요'; if (s.al) return '동맹이 있어요'; break;
      case E.ROBIN: if (!robinPair(s, seat)) return '뺏을 금화가 없어요'; break;
      case E.DIV: if (!sellable(s.co[seat])) return '내 물건이 없어요'; break;
      case E.SAVE: if (free(s, seat) < SAVE_AMT) return '금화가 모자라요'; break;
      case E.BUNDLE: case E.SWITCH: case E.BLIND:
        if (!single) return '물건 한 점짜리 경매에서만 써요';
        if (spare(s) < 1) return '남은 물건이 없어요';
        break;
      case E.TREND: if (!s.lot.split('').some((ch) => kindOf(idOf(ch)))) return '유행할 종류가 없어요'; break;
      case E.SELL: if (!sellable(s.co[seat])) return '팔 물건이 없어요'; break;
      case E.DUMP: if (!hasFake(s.co[seat])) return '내 위작이 없어요'; break;
      case E.GUARD: if (bit(s.sh, seat)) return '이미 경비원이 있어요'; break;
      case E.RESTORE: if (restoreIdx(s, seat) < 0) return '2배로 만들 물건이 없어요'; break;
      case E.WIND: if (windIdx(s, seat) < 0) return '태엽새가 없어요'; break;
      case E.EXTEND: if (s.R >= R_MAX) return '더 늘릴 수 없어요'; if (spare(s) < 1) return '남은 물건이 없어요'; break;
      case E.SHORTEN: if (s.R - s.r < 3) return '2라운드 넘게 남았을 때만 써요'; break;
      case E.RIG: if (s.r >= s.R - 1) return '마지막 경매예요'; if (s.q[s.r + 1] === 'f') return '다음은 위작 경매예요'; break;
      case E.AMNESTY: if (gf & GF_AMN) return '이미 사면됐어요'; break;
      case E.INFL: if (gf & GF_INFL) return '이미 올랐어요'; break;
      case E.PAIR: if (gf & GF_PAIR) return '이미 완화됐어요'; break;
      case E.DUTCH: if (rf & RF_DUTCH) return '이미 내림 경매예요'; if (rf & RF_REV) return '거꾸로 경매엔 못 써요'; break;
      case E.TWICE: if (rf & RF_TWICE) return '이미 봉투 두 번이에요'; if (rf & RF_REV) return '거꾸로 경매엔 못 써요'; break;
      case E.ALLPAY: if (rf & RF_ALLPAY) return '이미 모두 내기예요'; break;
      case E.AVG: if (rf & RF_AVG) return '이미 평균가예요'; if (s.md === 'v') return '이미 2등 가격 경매예요'; break;
      case E.OPEN: if (rf & RF_OPEN) return '이미 공개 입찰이에요'; break;
      case E.ALLY: if (s.al) return '이미 동맹이 있어요'; if (rf & RF_REV) return '거꾸로 경매엔 못 써요'; break;
      case E.COLLR: if (s.cv) return '이미 수집가가 있어요'; if (rf & RF_REV) return '거꾸로 경매엔 못 써요'; break;
      case E.ROTATE: if (!s.ev.some((h2, i) => (i === seat ? h2.length > 1 : h2.length > 0))) return '넘길 카드가 없어요'; break;
      case E.TAX: if (!s.c.some((c, i) => i !== seat && free(s, i) >= 10)) return '낼 금화가 있는 사람이 없어요'; break;
      case E.INVEST: if (free(s, seat) < INV_IN) return '금화가 모자라요'; if (s.r + INV_WAIT >= s.R) return '남은 라운드가 모자라요'; break;
      case E.OWNER: if (s.ow != null) return '이미 주인이 있어요'; break;
      case E.LEND: if (free(s, seat) < LEND_OUT) return '금화가 모자라요'; break;
      case E.RETURN: if (!returnable(s, seat)) return '반품할 물건이 없어요'; break;
      case E.APPRAISE: if (s.r >= s.R - 1) return '마지막 경매예요'; if ((s.pv || 0) >= Math.min(s.R - 1, s.r + APPR_N)) return '이미 공개됐어요'; break;
      case E.CURATOR: if (bit(s.cu, seat)) return '이미 썼어요'; break;
      case E.FOCUS: if (bit(s.fo, seat)) return '이미 썼어요'; break;
      case E.BOOM: if (s.bm) return '이미 호황이에요'; break;
      case E.SLUMP: if (s.dp) return '이미 불황이에요'; break;
      case E.CRASH: if (gf & GF_CRASH) return '이미 붕괴했어요'; break;
      case E.TRIPLE: if (gf & GF_TRIPLE) return '이미 열렸어요'; break;
      case E.BIRDYR: if (gf & GF_BIRD) return '이미 새의 해예요'; break;
      case E.NOFAKE: if (nextFake(s) < 0) return '남은 위작 경매가 없어요'; if (spare(s) < 1) return '남은 물건이 모자라요'; break;
      case E.FIXED: if (spare(s) < 1) return '남은 물건이 없어요'; if (free(s, seat) < FIX_MIN) return '금화가 모자라요'; break;
      case E.FAKEGIFT: if (!unusedFakes(s).length) return '남은 위작이 없어요'; break;
      case E.HEIR: if (bit(s.nc, seat)) return '이미 받았어요'; break;
      case E.FIRST: if (rf & RF_FIRST) return '이미 선착순이에요'; break;
      case E.BUYNOW: if (hasMoney(s.lot)) return '금화 물건은 못 사요'; if (nowPrice(s) > free(s, seat)) return '금화가 모자라요 (' + nowPrice(s) + ')'; break;
    }
    if (TARGET[k]) {
      if (tg === undefined) {
        for (const t of tgList(s, seat, k)) if (!targetWhy(s, seat, k, t)) return '';
        return k === E.SWAP && !s.co[seat] ? '내 물건이 없어요' : '고를 대상이 없어요';
      }
      return targetWhy(s, seat, k, tg);
    }
    return '';
  }
  /* best bid already placed by someone else (lowest in a forgery round); −1 if nobody has bid */
  function peekVal(s, seat) {
    let r = -1;
    for (let i = 0; i < s.n; i++) {
      if (i === seat || s.b[i] == null || isOut(s, i)) continue;
      const v = dec(s.b[i]);
      if (r < 0 || (s.md === 'f' ? v < r : v > r)) r = v;
    }
    return r;
  }
  function playCard(s, seat, a) {
    if (!s.eo) throw new Error('event cards are off');
    const k = a.k;
    if (!Number.isInteger(k) || !CARDS[k]) throw new Error('bad card');
    const hand = s.ev[seat], at = hand.indexOf(chOf(k));
    if (at < 0) throw new Error('no such card');
    const ty = TARGET[k] || 0;
    const tg = ty ? (Number.isInteger(a.tg) ? a.tg : -2) : -1;
    const why = cantUse(s, seat, k, ty ? tg : undefined);
    if (why) throw new Error(why);
    s.ev[seat] = hand.slice(0, at) + hand.slice(at + 1);
    s.u[seat] = k;
    const lc = { id: ++s.seq, s: seat, k, r: s.r };
    const victim = ty === 1 ? tg : ty === 6 ? tg >> 6 : -1;
    if (tg >= 0) lc.t = ty === 6 ? victim : tg;
    s.lc = lc;
    if (victim >= 0 && bit(s.sh, victim)) { // 경비원 stops it
      s.sh &= ~(1 << victim); lc.blk = 1;
      return s;
    }
    switch (k) {
      case E.PEEK: s.pk[seat] = enc(peekVal(s, seat)); break;
      case E.SNOOP: s.pk[seat] = enc(dec(s.b[tg]) + 1000 * (tg + 1)); break; // who + how much
      case E.RUMOR: s.pk[seat] = scr('R' + s.ev[tg]); break;
      case E.PREV: { const nx = nextLot(s); s.pk[seat] = scr('N' + nx.md + nx.lot); break; }
      case E.MEGA: s.op = s.b.map((b, i) => (b != null && !isOut(s, i) && i !== seat ? dec(b) : s.op && s.op[i] >= 0 ? s.op[i] : -1)); break;
      case E.TREND: {
        let add2 = '';
        for (const ch of s.lot) { const d = kindOf(idOf(ch)); if (d && add2.indexOf(d) < 0) add2 += d; }
        s.tr += add2; lc.v = add2; break;
      }
      case E.BLOCK: s.x |= 1 << tg; if (s.b[tg] == null) s.b[tg] = enc(0); break;
      case E.STEAL: { const amt = Math.min(STEAL_AMT, free(s, tg)); s.c[tg] -= amt; s.c[seat] += amt; lc.v = amt; break; }
      case E.COLL: {
        let tot = 0;
        for (let i = 0; i < s.n; i++) if (i !== seat) { const amt = Math.min(COLL_AMT, free(s, i)); s.c[i] -= amt; tot += amt; }
        s.c[seat] += tot; lc.v = tot; break;
      }
      case E.SWAP: {
        const A = s.co[seat], B = s.co[tg], a1 = A[A.length - 1], b1 = B[B.length - 1];
        s.co[seat] = A.slice(0, -1) + b1; s.co[tg] = B.slice(0, -1) + a1;
        lc.a = a1; lc.b = b1; break;
      }
      case E.APPR: {
        const co = s.co[seat];
        let wi = -1, wv = 0;
        for (let j = 0; j < co.length; j++) { const it = item(idOf(co[j])); if (it.k === 'f' && it.v < wv) { wv = it.v; wi = j; } }
        if (wi >= 0) { lc.a = co[wi]; s.co[seat] = co.slice(0, wi) + co.slice(wi + 1); } else { s.c[seat] += APPR_AMT; lc.v = APPR_AMT; }
        break;
      }
      case E.LOAN: s.c[seat] += LOAN_AMT; s.ep[seat] -= LOAN_PEN; break;
      case E.CAP: s.rf |= RF_CAP; break;
      case E.FLOOR: s.rf |= RF_FLOOR; break;
      case E.REV: s.rf |= RF_REV; break;
      case E.HAGG: lc.v = s.md; s.md = 'v'; break;
      case E.LOTTO: { const amt = 5 * U.rand(6); s.c[seat] += amt; lc.v = amt; break; }
      case E.ROBIN: {
        const [rich, poor] = robinPair(s, seat), amt = Math.min(ROBIN_AMT, free(s, rich));
        s.c[rich] -= amt; s.c[poor] += amt; lc.t = rich; lc.p = poor; lc.v = amt; break;
      }
      case E.DIV: {
        let k2 = 0; for (const ch of s.co[seat]) if (item(idOf(ch)).k !== 'f') k2++;
        const amt = Math.min(DIV_MAX, k2 * DIV_AMT); s.c[seat] += amt; lc.v = amt; break;
      }
      case E.SAVE: s.c[seat] -= SAVE_AMT; s.ep[seat] += SAVE_PTS; break;
      case E.BUNDLE: { const ch = drawBack(s); s.lot += ch; lc.a = ch; break; }
      case E.SWITCH: { const ch = drawBack(s); lc.a = s.lot; lc.b = ch; s.lot = ch; break; }
      case E.SELL: {
        const co = s.co[seat], ch = co[tg], amt = sellPrice(idOf(ch));
        s.co[seat] = co.slice(0, tg) + co.slice(tg + 1); s.cf = s.cf.split(ch).join('');
        s.c[seat] += amt; lc.a = ch; lc.v = amt; break;
      }
      case E.DUMP: {
        const co = s.co[seat];
        let wi = -1, wv = 0;
        for (let j = 0; j < co.length; j++) { const it = item(idOf(co[j])); if (it.k === 'f' && it.v < wv) { wv = it.v; wi = j; } }
        lc.a = co[wi]; s.co[seat] = co.slice(0, wi) + co.slice(wi + 1); s.co[tg] += lc.a; break;
      }
      case E.THIEF: {
        const co = s.co[tg], j = U.rand(co.length), ch = co[j];
        s.co[tg] = co.slice(0, j) + co.slice(j + 1); s.co[seat] += ch; lc.a = ch;
        const pay = Math.min(THIEF_PAY, free(s, seat)); s.c[seat] -= pay; s.c[tg] += pay; lc.v = pay; break;
      }
      case E.GUARD: s.sh |= 1 << seat; break;
      case E.LOCK: s.lk |= 1 << tg; break;
      case E.TARIFF: s.tf |= 1 << tg; break;
      case E.CSTEAL: {
        const h2 = s.ev[tg], j = U.rand(h2.length);
        s.ev[seat] += h2[j]; s.ev[tg] = h2.slice(0, j) + h2.slice(j + 1); break;
      }
      case E.BADGE: s.gl += String(seat) + tg; break;
      case E.RESTORE: { const ch = s.co[seat][restoreIdx(s, seat)]; s.cf += ch; lc.a = ch; break; }
      case E.WIND: { const ch = s.co[seat][windIdx(s, seat)]; s.cf += ch; lc.a = ch; break; }
      case E.EXTEND: s.R++; s.q += 'n'; lc.v = s.R; break;
      case E.SHORTEN: s.R--; s.q = s.q.slice(0, -1); lc.v = s.R; break;
      case E.RIG: { const m = NEXT_MODES[tg]; lc.v = s.q[s.r + 1]; s.q = s.q.slice(0, s.r + 1) + m + s.q.slice(s.r + 2); lc.m = m; break; }
      case E.AMNESTY: s.gf |= GF_AMN; break;
      case E.INFL: s.gf = (s.gf | GF_INFL) & ~GF_CRASH; break;
      case E.PAIR: s.gf |= GF_PAIR; break;
      // ---- round 12 ----
      case E.DUTCH: s.rf |= RF_DUTCH; break;
      case E.TWICE: s.rf |= RF_TWICE; break;
      case E.ALLPAY: s.rf |= RF_ALLPAY; break;
      case E.AVG: s.rf |= RF_AVG; break;
      case E.OPEN: s.rf |= RF_OPEN; break;
      case E.BLIND: { const ch = drawBack(s); lc.a = s.lot; s.lot = ch; s.rf |= RF_BLIND; break; }
      case E.ALLY: s.al = [seat, tg]; break;
      case E.COLLR: s.cv = collVal(s); lc.v = s.cv; break;
      case E.MINBID: s.mb = (s.mb || 0) | (1 << tg); break;
      case E.SABO: s.sb = (s.sb || 0) | (1 << tg); break;
      case E.CBLOCK: if (!s.cbu) s.cbu = Array(s.n).fill(-1); s.cbu[tg] = s.r + 1; break;
      case E.ROTATE: { const hs = s.ev.slice(); for (let i = 0; i < s.n; i++) s.ev[(i + 1) % s.n] = hs[i]; break; }
      case E.ACCUSE: { const k2 = fakeCount(s.co[tg]); s.ep[tg] -= ACC_PTS * k2; lc.v = k2; break; }
      case E.TAX: {
        let tot = 0;
        for (let i = 0; i < s.n; i++) if (i !== seat) { const amt = Math.floor(free(s, i) / 10); s.c[i] -= amt; tot += amt; }
        lc.v = tot; break;
      }
      case E.INVEST: s.c[seat] -= INV_IN; (s.iv = s.iv || []).push([seat, s.r + INV_WAIT, INV_OUT]); lc.v = s.r + INV_WAIT; break;
      case E.OWNER: s.ow = seat; break;
      case E.RAFFLE: {
        let pot = 0;
        for (let i = 0; i < s.n; i++) { const amt = Math.min(RAFFLE_AMT, free(s, i)); s.c[i] -= amt; pot += amt; }
        const wn = U.rand(s.n); s.c[wn] += pot; lc.t = wn; lc.v = pot; break;
      }
      case E.RUSH: for (let i = 0; i < s.n; i++) s.c[i] += i === seat ? RUSH_ME : RUSH_ALL; break;
      case E.INSTAL: s.it = (s.it || 0) | (1 << seat); break;
      case E.LEND: s.c[seat] -= LEND_OUT; s.c[tg] += LEND_OUT; addDc(s, tg, -LEND_BACK); addDc(s, seat, LEND_BACK); break;
      case E.BUYOUT: {
        const o = victim, j = tg & 63, ch = s.co[o][j], p = buyPrice(idOf(ch));
        s.co[o] = s.co[o].slice(0, j) + s.co[o].slice(j + 1); s.co[seat] += ch;
        s.c[seat] -= p; s.c[o] += p; lc.a = ch; lc.v = p; break;
      }
      case E.RETURN: {
        const rt = returnable(s, seat), back = Math.floor(rt.pay / 2);
        for (const ch of rt.chars) { const co = s.co[seat], j = co.indexOf(ch); s.co[seat] = co.slice(0, j) + co.slice(j + 1); s.cf = s.cf.split(ch).join(''); }
        s.c[seat] += back; lc.a = rt.chars; lc.v = back; break;
      }
      case E.REPLICA: { const ch = chOf(PROP_IDS[tg]); s.co[seat] += ch; lc.a = ch; break; }
      case E.APPRAISE: s.pv = Math.min(s.R - 1, s.r + APPR_N); break;
      case E.BET: { const N = betLine(s); (s.bt = s.bt || []).push([seat, tg, N]); lc.v = N; break; }
      case E.MISSION: s.ms = (s.ms || '') + seat + tg; break;
      case E.CURATOR: s.cu = (s.cu || 0) | (1 << seat); break;
      case E.FAME: s.fm = (s.fm || 0) | (1 << seat); break;
      case E.FOCUS: s.fo = (s.fo || 0) | (1 << seat); break;
      case E.BOOM: s.bm = BOOM_N; break;
      case E.SLUMP: s.dp = SLUMP_N; break;
      case E.CRASH: s.gf = (s.gf | GF_CRASH) & ~GF_INFL; break;
      case E.TRIPLE: s.gf |= GF_TRIPLE; break;
      case E.BIRDYR: s.gf |= GF_BIRD; break;
      case E.NOFAKE: { const r2 = nextFake(s); s.q = s.q.slice(0, r2) + 'n' + s.q.slice(r2 + 1); lc.v = r2; break; }
      case E.FIXED: {
        const ch = drawBack(s), p = Math.min(free(s, seat), Math.round(faceOf(idOf(ch)) * FIX_X));
        s.c[seat] -= p; s.co[seat] += ch; lc.a = ch; lc.v = p;
        const g = gain(s, seat, ch); if (g) lc.g = g;
        break;
      }
      case E.FAKEGIFT: { const pool = unusedFakes(s), ch = chOf(pool[U.rand(pool.length)]); s.co[tg] += ch; lc.a = ch; break; }
      case E.HEIR: s.c[seat] += HEIR_AMT; s.nc = (s.nc || 0) | (1 << seat); break;
      case E.FIRST: s.rf |= RF_FIRST; break;
      case E.DUEL:
        for (let i = 0; i < s.n; i++) if (i !== seat && i !== tg && !isOut(s, i)) { s.x |= 1 << i; if (s.b[i] == null) s.b[i] = enc(0); }
        break;
      case E.SUMPEEK: {
        let sm = 0, k2 = 0;
        for (let i = 0; i < s.n; i++) if (i !== seat && s.b[i] != null && !isOut(s, i)) { sm += dec(s.b[i]); k2++; }
        s.pk[seat] = enc(sm + 1000 * k2); break;
      }
    }
    if (k === E.CANCEL) cancelRound(s, seat);
    else if (k === E.BUYNOW) buyNow(s, seat);
    else maybeResolve(s); // 출입 금지 / 일대일 may have filled the last missing bid
    return s;
  }
  function cancelRound(s, seat) {
    const ins = [];
    for (let i = 0; i < s.n; i++) if (s.u[i] === E.INS) { s.c[i] += INS_AMT; ins.push(i); }
    s.h.push([s.lot, s.md, -2, 0, 0, usesStr(s.u)]); // w = −2: cancelled
    s.last = { id: ++s.seq, r: s.r, lot: s.lot, md: s.md, b: null, w: -1, pay: 0, cx: seat, u: s.u.slice(), st: prio(s) };
    if (ins.length) s.last.ins = ins;
    advance(s);
  }
  /* 즉시 구매: the lot is mine at a fixed price, nobody else pays */
  function buyNow(s, seat) {
    const p = nowPrice(s), lot = s.lot;
    s.c[seat] -= p; s.co[seat] += lot;
    const gn = gain(s, seat, lot), ins = [];
    for (let i = 0; i < s.n; i++) if (s.u[i] === E.INS && i !== seat) { s.c[i] += INS_AMT; ins.push(i); }
    s.h.push([lot, s.md, seat, p, 0, usesStr(s.u)]);
    s.last = { id: ++s.seq, r: s.r, lot, md: s.md, b: null, w: seat, pay: p, bn: 1, u: s.u.slice(), st: prio(s) };
    if (gn) s.last.gn = gn;
    if (ins.length) s.last.ins = ins;
    advance(s);
  }

  function standings(s) {
    return Array.from({ length: s.n }, (_, i) => Object.assign({ i }, scoreOf(s, i), { coins: s.c[i] }));
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const st = standings(s);
    const best = Math.max(...st.map((x) => x.total));
    let top = st.filter((x) => x.total === best);
    const bc = Math.max(...top.map((x) => x.coins));
    top = top.filter((x) => x.coins === bc);
    const lines = st.slice().sort((a, b) => b.total - a.total || b.coins - a.coins)
      .map((x) => (s.nm[x.i] || (x.i + 1) + '번') + ' · ' + x.total + '점 (물건 ' + (x.base + x.fake) + ' · 세트·새 ' + (x.bonus + x.bird + x.rb) +
        (x.sp ? ' · 특수 ' + x.sp : '') + (s.eo ? ' · 카드 ' + (x.trend + x.ev + x.bd + x.cu + x.fo + x.ms) : '') + ' · 금화 ' + x.cp + ')');
    return { winners: top.map((x) => x.i), title: top.length === 1 ? (s.nm[top[0].i] || '') + ' 승리 · ' + best + '점' : '공동 승리 · ' + best + '점', text: lines.join('\n') };
  }

  /* ---------- AI ---------- */
  const scWith = (s, i, add, cert) => score((s.co[i] || '') + (add || ''), 0, cert ? (s.cf || '') + add : s.cf, s.tr, 0, s.gf);
  const isCursed = (co) => { let c = 0, a = 0; for (const ch of co || '') { const k = item(idOf(ch)).k; if (k === 'x') c++; else if (k === 'a') a++; } return c > 0 && !a; };
  /* points that a curse (or a charm lifting it) would cost / save on leftover coins — a rough guess of the end-game purse */
  function curseAdj(s, seat, lot) {
    if (bit(s.nc, seat)) return 0;
    const a = isCursed(s.co[seat]), b = isCursed((s.co[seat] || '') + lot);
    if (a === b) return 0;
    const est = s.c[seat] * 0.45 / coinRate(s.gf);
    return b ? -est : est;
  }
  const lotItems = (s, seat, lot, cert) => scWith(s, seat, lot, cert).items - scWith(s, seat).items;
  const lotPts = (s, seat, lot, cert) => lotItems(s, seat, lot, cert) + curseAdj(s, seat, lot);
  function slotsAfter(s) { let k = 0; for (let r = s.r + 1; r < s.R; r++) k += s.q[r] === 'b' ? 2 : s.q[r] === 'f' ? 0 : 1; return k; }
  /* expected number of future appearances for each colour (0..3) and birds (4) — only kinds, never the hidden order */
  function futureOdds(s) {
    const un = [0, 0, 0, 0, 0];
    let tot = 0;
    for (const ch of s.dk.slice(s.di)) { const it = item(idOf(ch)); if (it.k === 'c') un[it.c]++; else if (it.k === 'b') un[4]++; tot++; }
    const sl = slotsAfter(s);
    return un.map((x) => (tot ? x * sl / tot : 0));
  }
  function potential(s, seat, lot, odds) {
    const a = scWith(s, seat), b = scWith(s, seat, lot), need = (s.gf || 0) & GF_PAIR ? 2 : 3;
    let p = 0;
    for (let k = 0; k < 4; k++) {
      if (b.cnt[k] <= a.cnt[k] || a.cnt[k] >= need) continue;
      if (b.cnt[k] === need - 1) p += b.sum[k] * 0.5 * Math.min(1, odds[k]);
      else if (b.cnt[k] === need - 2) p += b.sum[k] * 0.18 * Math.min(1, odds[k] / 2);
    }
    if (b.birds > a.birds) p += (2 * b.birds + 1) * 0.4 * Math.min(1, odds[4]);
    // special sets: the missing piece may still come up
    const rest = s.dk.slice(s.di), co = (s.co[seat] || '') + lot;
    const pr = Math.min(1, slotsAfter(s) / Math.max(1, rest.length));
    const inRest = (id) => rest.indexOf(chOf(id)) >= 0, mine = (id) => co.indexOf(chOf(id)) >= 0;
    for (const ch of lot) {
      const it = item(idOf(ch));
      if (it.k === 'p') { const mate = PAIR_IDS[it.g][1 - it.s]; if (!mine(mate) && inRest(mate)) p += PAIR_BONUS * 0.45 * pr; }
      else if (it.k === 'k') { const have = BOOK_IDS[it.g].filter(mine).length, left = BOOK_IDS[it.g].filter(inRest).length; if (have < 3 && left) p += (have === 1 ? BOOK2 : BOOK3 - BOOK2) * 0.4 * pr * Math.min(1, left); }
      else if (it.k === 'h' && KEY_IDS.some(inRest)) p += it.v * 2 * 0.35 * pr;
      else if (it.k === 'y' && CHEST_IDS.some(inRest)) p += 4 * 0.35 * pr;
    }
    return p;
  }
  function rateOf(s, seat) {
    // what leftover coins are worth at the end (nothing at all under a curse or after 유산 상속: spend them)
    const top = isCursed(s.co[seat]) || bit(s.nc, seat) ? 30 : coinRate(s.gf);
    if (s.r >= s.R - 1) return top;
    let tot = 0; for (const x of s.c) tot += x;
    let pts = 0; for (let r = s.r; r < s.R; r++) pts += s.q[r] === 'b' ? 10 : s.q[r] === 'f' ? 0 : 5.5;
    let rate = tot / Math.max(5, pts) * 0.9;
    rate *= Math.sqrt(Math.max(0.3, s.c[seat] / Math.max(1, tot / s.n)));
    return U.clamp(rate, 1.5, top);
  }
  /* coins an item pays out besides points: money, cards from the lamp/cat, golden eggs, tie-breaks, a peek ahead */
  function extraC(s, lot) {
    let c = 0;
    const deals = Math.max(0, Math.floor((s.R - 1) / EV_EVERY) - Math.floor(s.r / EV_EVERY)), left = s.R - s.r;
    for (const ch of lot) {
      const it = item(idOf(ch));
      if (it.k === 'm') c += it.m;
      else if (it.k === 'z') c += [8, 4, GOOSE_AMT * deals, 2 + left * 0.3, 1 + left * 0.3][it.x];
    }
    return c;
  }
  const blind = (s) => ((s.rf || 0) & RF_BLIND) !== 0;
  /* what the current lot is worth to me in coins (a covered lot: the average over everything it could be) */
  function lotWorth(s, seat, odds, rate, cert) {
    const one = (lot) => (lotPts(s, seat, lot, cert) + potential(s, seat, lot, odds)) * rate + extraC(s, lot);
    if (!blind(s)) return one(s.lot);
    const pool = (s.dk.slice(s.di) + s.lot).split('');
    let t = 0; for (const ch of pool) t += one(ch);
    return t / pool.length;
  }
  function faceNow(s) {
    if (!blind(s)) return faceValue(s.lot);
    const pool = (s.dk.slice(s.di) + s.lot).split('');
    return faceValue(pool.join('')) / pool.length;
  }
  const usedBy = (s, i) => (s.u && s.u[i] != null ? s.u[i] : -1);
  /* the most a bid of mine can count for this round (가격 상한 / 지갑 잠금 / 불황) */
  function capFor(s, seat) {
    let m = Infinity;
    if ((s.rf || 0) & RF_CAP) m = CAP_AMT;
    if (bit(s.lk, seat)) m = Math.min(m, LOCK_AMT);
    if ((s.dp || 0) > 0) m = Math.min(m, SLUMP_AMT);
    return m;
  }
  /* rival bids I know for sure: my 엿보기 / 쪽지 and anything shown by 확성기 / 공개 입찰 → best of them (−1: nothing known) */
  function knownTop(s, seat) {
    let r = -1;
    const my = usedBy(s, seat);
    if ((my === E.PEEK || my === E.SNOOP) && s.pk && s.pk[seat] != null) r = dec(s.pk[seat]) % 1000;
    if (s.op) s.op.forEach((v, i) => { if (i !== seat && v > r && !isOut(s, i)) r = v; });
    return r;
  }
  function aiBid(s, seat, lv) {
    const max = maxBid(s, seat), mn = minBid(s, seat), c = s.c[seat], rate = rateOf(s, seat);
    const odds = futureOdds(s), my = usedBy(s, seat), rf = s.rf || 0, cap = capFor(s, seat);
    const others = [];
    for (let i = 0; i < s.n; i++) if (i !== seat && !isOut(s, i) && !(s.al && s.al[1] === i)) others.push(i);
    const spon = my === E.SPON ? SPON_ADD : 0, sabo = bit(s.sb, seat) ? SABO_AMT : 0;
    const oSpon = (o) => (usedBy(s, o) === E.SPON ? SPON_ADD : 0);
    const jit = () => Math.random() * 2 - 1;
    const fin = (b, val) => {
      let v = Math.round(Math.min(b, lv >= 2 ? cap : Infinity));
      if (lv >= 2 && (rf & RF_DUTCH) && v > 0) { const up = Math.ceil(v / 5) * 5; v = up <= (val || 0) ? up : Math.floor(v / 5) * 5; } // 내림 경매
      return U.clamp(v, mn, max);
    };
    if (s.md === 'f') {
      const pk = lv >= 2 && my === E.PEEK && s.pk && s.pk[seat] != null ? dec(s.pk[seat]) : -1; // the lowest bid so far
      if (lv === 1) return fin(U.rand(Math.min(c, 14) + 1));
      const avoid = -lotPts(s, seat, s.lot) * rate * (my === E.COUP ? 1.6 : 1);
      if (avoid <= 0.5) return fin(0); // 위작 사면: nothing to fear
      let b = avoid * 0.3 * (1 + 0.35 * jit());
      if (lv === 3) {
        const pred = others.map((o) => U.clamp(-lotPts(s, o, s.lot) * rateOf(s, o) * 0.3, 0, Math.min(maxBid(s, o), capFor(s, o))) + oSpon(o) - (bit(s.sb, o) ? SABO_AMT : 0));
        const comp = pred.reduce((a, x) => a + x, 0);
        if (!pred.length || comp >= avoid * 0.9) b = 0; // being paid to take it is a good deal
        else b = Math.min(avoid * 0.75, Math.min(...pred) + 1 + U.rand(3));
      }
      if (spon && b > 0) b = Math.max(1, b - spon * 0.7);
      if (sabo && b > 0) b = Math.min(avoid * 0.9, b + sabo);
      if (pk >= 0) { // step just over the lowest bid if that's worth it
        const need = Math.max(1, pk + 1 - spon + sabo);
        if (need <= avoid * 0.9) b = Math.max(b, need + (lv === 3 ? 0 : U.rand(3)));
      }
      return fin(b);
    }
    // 봉투 두 번: the second envelope — I know the rival's first bid
    if (s.t2 && (seat === s.t2[0] || seat === s.t2[1])) {
      const me1 = seat === s.t2[0] ? s.t2[2] : s.t2[3], op1 = seat === s.t2[0] ? s.t2[3] : s.t2[2];
      const val = lotWorth(s, seat, odds, rate, my === E.CERT) - (s.md === 'q' ? FEE : 0);
      if (lv === 1) return fin(me1 + U.rand(8));
      if (val <= me1 + 1) return fin(me1);
      if (lv === 3) return fin(Math.min(val * 0.95, Math.max(me1, op1 + 2 + U.rand(4) + (op1 >= me1 ? (val - op1) * 0.25 : 0))), val);
      return fin(me1 + (val - me1) * (0.25 + 0.45 * Math.random()), val);
    }
    // 동맹: as the partner, my bid only helps the team (and earns +4 if it wins)
    if (s.al && s.al[1] === seat) {
      if (lv === 1) return fin(U.rand(10));
      return fin(ALLY_PTS * rate * (lv === 3 ? 0.8 : 0.6) * (0.7 + 0.3 * Math.random()));
    }
    let val;
    if (lv === 1) val = faceNow(s) * rate * (0.6 + Math.random() * 0.9) + (blind(s) ? 0 : extraC(s, s.lot) * 0.6);
    else {
      val = lotWorth(s, seat, odds, rate, my === E.CERT);
      if (my === E.BONUS) val += 3.5 * rate;
      // opponents' needs: deny a set completion or a big bird flock
      if (!blind(s)) {
        let deny = 0;
        for (const o of others) deny = Math.max(deny, lotPts(s, o, s.lot) - faceValue(s.lot));
        val += Math.max(0, deny) * (lv === 3 ? 0.5 : 0.25) * rate;
      }
      if (bit(s.tf, seat)) val -= TARIFF_AMT; // 추가 관세 on me
      if (bit(s.fm, seat)) val += FAME_PTS * rate; // 명성
      if (bit(s.it, seat)) val *= 1.1; // 할부: half of it later
    }
    if (my === E.COUP) val *= 1.7; // paying half
    if (s.md === 'q') val -= FEE * (my === E.COUP ? 0.5 : 1);
    if (val <= 0.5) return fin(0);
    if (rf & RF_REV) { // 거꾸로 경매: the smallest bid (1 or more) wins
      if (lv === 1) return fin(1 + U.rand(8));
      return fin(1 + U.rand(lv === 3 ? 2 : 4));
    }
    let b;
    const pk = lv >= 2 ? knownTop(s, seat) : -1;
    if (s.md === 'v') b = lv === 3 ? val : val * (0.8 + 0.15 * Math.random());
    else if (lv === 3) {
      // track every rival's remaining coins: nobody can pay more than they hold
      let pred = 0;
      for (const o of others) {
        const ov = (lotWorth(s, o, odds, rateOf(s, o)) - (s.md === 'q' ? FEE : 0)) * 0.78;
        pred = Math.max(pred, U.clamp(ov, 0, Math.min(maxBid(s, o), capFor(s, o))) + oSpon(o) - (bit(s.sb, o) ? SABO_AMT : 0));
      }
      if (val > pred + 1) b = Math.min(val * 0.95, pred + 1 + U.rand(3));
      else b = val * (Math.random() < 0.15 ? 0.85 : 0.5); // a small bluff now and then
    } else if (lv === 2) {
      b = val * (0.62 + 0.2 * Math.random());
      if (Math.random() < 0.1) b *= 0.5 + Math.random(); // bluff a little
    } else b = val * (0.5 + 0.6 * Math.random());
    if (pk >= 0) {
      const need = Math.max(1, pk + 1 - spon + sabo);
      if (need <= val) b = Math.max(b, need + (lv === 3 ? U.rand(2) : U.rand(4)));
      else b = Math.min(b, val * 0.6);
    } else if (spon && b > 0 && lv >= 2) b = Math.max(1, b - 7);
    if (lv >= 2) {
      if (s.al && s.al[0] === seat) b *= 0.8; // my partner adds to my bid
      if (rf & RF_AVG) b = Math.min(val * 1.25, b * 1.3); // I only pay the average
      if (rf & RF_ALLPAY) b = lv === 3 && b < val * 0.45 ? 0 : b * 0.85; // losing costs half
      if (sabo && b > 0) b = Math.min(val, b + sabo);
      if (s.cv) b = val > s.cv + 1 ? Math.max(b, s.cv + 1 + (lv === 3 ? 0 : U.rand(3))) : 0; // beat the collector or stay out
      if (cap < Infinity && val >= cap) b = cap; // everyone is capped: go to the cap and hope for the tie
      if ((rf & RF_FLOOR) && b > 0) b = val > FLOOR_AMT + 1 ? Math.max(b, FLOOR_AMT + 1) : 0;
    }
    return fin(b, val);
  }

  /* --- event-card AI --- */
  function aiCtx(s, seat) {
    const f = s.md === 'f', odds = futureOdds(s), rate = rateOf(s, seat);
    const val = f ? 0 : Math.max(0, lotWorth(s, seat, odds, rate) - (s.md === 'q' ? FEE : 0));
    const avoid = f ? Math.max(0, -lotPts(s, seat, s.lot) * rate) : 0;
    const ov = [];
    let mo = 0, mi = -1, poorer = 0;
    for (let o = 0; o < s.n; o++) {
      if (o === seat || isOut(s, o)) { ov.push(0); continue; }
      const v = f ? 0 : U.clamp(lotWorth(s, o, odds, rateOf(s, o)), 0, maxBid(s, o));
      ov.push(v);
      if (v > mo) { mo = v; mi = o; }
      if (s.c[o] < s.c[seat]) poorer++;
    }
    const pw = f || val <= 0 ? 0 : U.clamp(val / (val + mo + 0.01), 0.05, 0.9);
    const pTake = f ? (poorer === 0 ? 0.55 : 0.4 / (poorer + 1)) : 0; // the poorest usually ends up with the forgery
    const tot = Array.from({ length: s.n }, (_, i) => scoreOf(s, i).total);
    let lead = -1; tot.forEach((t, i) => { if (lead < 0 || t > tot[lead]) lead = i; });
    return { f, rate, val, avoid, ov, mo, mi, pw, pTake, left: s.R - s.r, tot, lead };
  }
  /* may an AI of this level aim at t? (smart ones don't waste a card on a 경비원) */
  const aimOK = (s, seat, k, t, lv) => !targetWhy(s, seat, k, t) && (lv < 2 || !bit(s.sh, t));
  function bestTarget(s, seat, k, lv, fn) {
    let t = -1, bv = -Infinity;
    for (let o = 0; o < s.n; o++) {
      if (!aimOK(s, seat, k, o, lv)) continue;
      const v = lv === 2 ? fn(o) * (0.7 + 0.6 * Math.random()) : fn(o);
      if (v > bv) { bv = v; t = o; }
    }
    return t;
  }
  const avgOthers = (s, seat) => { let a = 0; for (let o = 0; o < s.n; o++) if (o !== seat) a += s.c[o] / (s.n - 1); return a; };
  function cardGain(s, seat, k, lv, x) {
    const n = s.n, f = x.f, hard = lv === 3, sc0 = () => scWith(s, seat).items;
    switch (k) {
      case E.PEEK: return { g: f ? x.avoid * 0.5 : x.val * (hard ? 0.5 : 0.4) };
      case E.PRIO: return { g: f ? x.avoid * x.pTake * 0.4 : x.val * 0.15 };
      case E.SPON: return { g: f ? Math.min(SPON_ADD, x.avoid) * (0.3 + x.pTake) : Math.min(SPON_ADD, x.val) * (0.3 + x.pw) };
      case E.COUP: return { g: f ? x.avoid * 0.15 : x.val * 0.6 * x.pw };
      case E.INS: return { g: INS_AMT * (f ? 1 - x.pTake : 1 - x.pw) * 0.8 };
      case E.BONUS: return { g: x.pw * 4.5 * x.rate };
      case E.CERT: return { g: blind(s) ? x.pw * 2 * x.rate : x.pw * Math.max(0, lotPts(s, seat, s.lot, 1) - lotPts(s, seat, s.lot)) * x.rate };
      case E.TREND: {
        let g = 0;
        const ds = new Set(s.lot.split('').map((ch) => kindOf(idOf(ch))).filter(Boolean));
        for (const d of ds) {
          let oth = 0;
          for (let o = 0; o < n; o++) if (o !== seat) oth += countKind(s.co[o], d);
          g += countKind(s.co[seat], d) + x.pw * countKind(s.lot, d) - oth / (n - 1);
        }
        return { g: g * x.rate };
      }
      case E.BLOCK: {
        if (f || x.mi < 0) return null;
        const t = hard ? bestTarget(s, seat, k, lv, (o) => x.ov[o] + (blind(s) ? 0 : Math.max(0, lotPts(s, o, s.lot) - faceValue(s.lot)) * rateOf(s, o) * 0.5))
          : aimOK(s, seat, k, x.mi, lv) ? x.mi : -1;
        if (t < 0) return null;
        return { g: (x.val > 0 ? Math.min(x.val + 2, x.ov[t]) * 0.6 : 0) + (blind(s) ? 0 : Math.max(0, lotPts(s, t, s.lot) - faceValue(s.lot)) * x.rate * 0.3), tg: t };
      }
      case E.STEAL: {
        const t = bestTarget(s, seat, k, lv, (o) => (hard ? scWith(s, o).items + s.c[o] / 10 : s.c[o]));
        return t < 0 ? null : { g: Math.min(STEAL_AMT, free(s, t)) * 0.75, tg: t };
      }
      case E.COLL: return { g: COLL_AMT * (n - 1) * 0.6 };
      case E.SWAP: {
        const A = s.co[seat], a1 = A[A.length - 1];
        const gain2 = (o) => {
          const B = s.co[o], b1 = B[B.length - 1];
          const mine = score(A.slice(0, -1) + b1, 0, s.cf, s.tr, 0, s.gf).items - score(A, 0, s.cf, s.tr, 0, s.gf).items;
          const theirs = score(B.slice(0, -1) + a1, 0, s.cf, s.tr, 0, s.gf).items - score(B, 0, s.cf, s.tr, 0, s.gf).items;
          return (mine - theirs * (hard ? 0.5 : 0.3)) * x.rate;
        };
        const t = bestTarget(s, seat, k, lv, gain2);
        return t < 0 ? null : { g: gain2(t), tg: t };
      }
      case E.APPR: {
        let wv = 0;
        for (const ch of s.co[seat]) { const it = item(idOf(ch)); if (it.k === 'f') wv = Math.min(wv, it.v); }
        if ((s.gf || 0) & GF_AMN) wv = 0;
        return { g: wv < 0 ? -wv * x.rate * 1.2 : APPR_AMT * 0.6 };
      }
      case E.LOAN: return { g: x.left < 2 ? -1 : LOAN_AMT - LOAN_PEN * x.rate - (s.c[seat] > 60 ? 6 : 0) };
      case E.CANCEL: {
        if (f) return { g: x.avoid * x.pTake * 0.9 };
        if (blind(s)) return { g: 0 };
        let deny = 0;
        for (let o = 0; o < n; o++) if (o !== seat) deny = Math.max(deny, lotPts(s, o, s.lot) - faceValue(s.lot));
        return { g: x.pw < 0.25 ? Math.max(0, deny) * x.rate * 0.4 : 0 };
      }
      case E.SNOOP: {
        const t = bestTarget(s, seat, k, lv, (o) => x.ov[o] + Math.random());
        return t < 0 ? null : { g: f ? x.avoid * 0.3 : x.val * 0.35, tg: t };
      }
      case E.RUMOR: { const t = bestTarget(s, seat, k, lv, (o) => s.ev[o].length); return t < 0 ? null : { g: 0.5, tg: t }; }
      case E.PREV: return { g: hard ? 2 : 1 };
      case E.MEGA: return { g: f ? x.avoid * 0.25 : x.val * 0.25 };
      case E.CAP:
        if (f || x.val < CAP_AMT * 0.9 || x.mo <= CAP_AMT) return { g: 0 };
        return { g: (Math.min(x.val, x.mo) - CAP_AMT) * 0.5 + (prio(s) === seat ? 4 : 0) };
      case E.FLOOR: return { g: x.val < FLOOR_AMT && x.mo > 0 && x.mo < FLOOR_AMT ? x.mo * 0.4 : 0 };
      case E.HAGG: return { g: x.pw * x.val * 0.3 };
      case E.REV: return { g: x.val > 3 ? x.val * 0.45 : 0 };
      case E.LOTTO: return { g: 6 };
      case E.ROBIN: {
        const pr = robinPair(s, seat);
        if (!pr) return null;
        return { g: pr[1] === seat ? Math.min(ROBIN_AMT, free(s, pr[0])) * 0.8 + (pr[0] === x.lead ? 2 : 0) : 1 };
      }
      case E.DIV: {
        let k2 = 0; for (const ch of s.co[seat]) if (item(idOf(ch)).k !== 'f') k2++;
        return { g: Math.min(DIV_MAX, k2 * DIV_AMT) * 0.75 };
      }
      case E.SAVE: return { g: SAVE_PTS * x.rate - SAVE_AMT };
      case E.BUNDLE: return { g: (x.pw * 3.5 - 0.8) * x.rate * 0.6 };
      case E.SWITCH: return { g: Math.max(0, x.mo - x.val) * 0.35 };
      case E.SELL: {
        const co = s.co[seat], base = sc0();
        let bj = -1, bg = -Infinity;
        for (let j = 0; j < co.length; j++) {
          if (sellPrice(idOf(co[j])) <= 0) continue;
          const loss = base - score(co.slice(0, j) + co.slice(j + 1), 0, s.cf, s.tr, 0, s.gf).items;
          const lift = isCursed(co) && !isCursed(co.slice(0, j) + co.slice(j + 1)) ? s.c[seat] * 0.45 / coinRate(s.gf) : 0;
          const g = sellPrice(idOf(co[j])) - (loss - lift) * x.rate * 1.1;
          if (g > bg) { bg = g; bj = j; }
        }
        return bj < 0 ? null : { g: bg, tg: bj };
      }
      case E.DUMP: {
        let wv = 0;
        for (const ch of s.co[seat]) { const it = item(idOf(ch)); if (it.k === 'f') wv = Math.min(wv, it.v); }
        if ((s.gf || 0) & GF_AMN) wv = 0;
        const t = hard ? bestTarget(s, seat, k, lv, (o) => x.tot[o]) : bestTarget(s, seat, k, lv, () => Math.random());
        return t < 0 ? null : { g: -wv * x.rate * 1.1, tg: t };
      }
      case E.THIEF: {
        const base = sc0();
        const gain2 = (o) => {
          const B = s.co[o], bb = scWith(s, o).items;
          let tot = 0;
          for (let j = 0; j < B.length; j++) {
            const mine = scWith(s, seat, B[j]).items - base;
            const theirs = bb - score(B.slice(0, j) + B.slice(j + 1), 0, s.cf, s.tr, 0, s.gf).items;
            tot += mine + theirs * (hard ? 0.5 : 0.3);
          }
          return B.length ? tot / B.length * x.rate - THIEF_PAY : -1;
        };
        const t = bestTarget(s, seat, k, lv, gain2);
        return t < 0 ? null : { g: gain2(t), tg: t };
      }
      case E.GUARD: return { g: 3 + (x.lead === seat ? 3 : 0) };
      case E.LOCK: {
        if (f) return { g: 0 };
        const t = bestTarget(s, seat, k, lv, (o) => x.ov[o]);
        if (t < 0) return null;
        return { g: Math.max(0, Math.min(x.ov[t], x.val + 5) - LOCK_AMT) * (x.val > 0 ? 0.6 : 0.2), tg: t };
      }
      case E.TARIFF: {
        const t = aimOK(s, seat, k, x.mi, lv) ? x.mi : bestTarget(s, seat, k, lv, (o) => x.ov[o]);
        return t < 0 ? null : { g: x.ov[t] > 0 ? TARIFF_AMT * 0.5 * (1 - x.pw) : 0, tg: t };
      }
      case E.CSTEAL: {
        const t = bestTarget(s, seat, k, lv, (o) => s.ev[o].length);
        return t < 0 ? null : { g: 4 + s.ev[t].length * 0.5, tg: t };
      }
      case E.BADGE: {
        let bd = -1, bp = -1;
        for (let d = 0; d < 5; d++) {
          if (targetWhy(s, seat, k, d)) continue;
          const me = countKind(s.co[seat], String(d));
          let mx = 0;
          for (let o = 0; o < n; o++) if (o !== seat) mx = Math.max(mx, countKind(s.co[o], String(d)));
          const p = me >= 2 && me > mx ? 0.8 : me >= 2 && me === mx ? 0.55 : me === 1 && mx <= 1 ? 0.3 : 0.08;
          if (p > bp) { bp = p; bd = d; }
        }
        return bd < 0 ? null : { g: BADGE_PTS * x.rate * bp * (0.6 + 0.4 * s.r / s.R) - 2, tg: bd };
      }
      case E.RESTORE: case E.WIND: {
        const j = k === E.RESTORE ? restoreIdx(s, seat) : windIdx(s, seat);
        if (j < 0) return null;
        const ch = s.co[seat][j];
        return { g: (score(s.co[seat], 0, s.cf + ch, s.tr, 0, s.gf).items - sc0()) * x.rate };
      }
      case E.EXTEND: {
        let avg = 0; for (const c of s.c) avg += c / n;
        return { g: Math.max(0, (s.c[seat] - avg) * 0.3) + 1 };
      }
      case E.SHORTEN: {
        if (x.lead !== seat) return { g: 0 };
        let second = -Infinity; x.tot.forEach((t, i) => { if (i !== seat) second = Math.max(second, t); });
        return { g: 3 + (x.tot[seat] - second) };
      }
      case E.RIG: {
        let avg = 0; for (const c of s.c) avg += c / n;
        const want = s.c[seat] >= avg ? 1 : 3; // rich: a 2-item bundle; poor: second price
        const t = !targetWhy(s, seat, k, want) ? want : [0, 1, 2, 3].find((m) => !targetWhy(s, seat, k, m));
        return t == null ? null : { g: 2, tg: t };
      }
      case E.AMNESTY: case E.PAIR: case E.TRIPLE: case E.BIRDYR: {
        const flag = k === E.AMNESTY ? GF_AMN : k === E.PAIR ? GF_PAIR : k === E.TRIPLE ? GF_TRIPLE : GF_BIRD;
        const delta = (o) => score(s.co[o], 0, s.cf, s.tr, 0, (s.gf || 0) | flag).items - scWith(s, o).items;
        let oth = 0; for (let o = 0; o < n; o++) if (o !== seat) oth = Math.max(oth, delta(o));
        return { g: (delta(seat) - oth * 0.7) * x.rate + (k === E.BIRDYR || k === E.TRIPLE ? 0.5 : 0) };
      }
      case E.INFL: return { g: (s.c[seat] - avgOthers(s, seat)) / 10 * x.rate * (0.3 + 0.7 * s.r / s.R) };
      // ---- round 12 ----
      case E.DUTCH: return { g: x.pw * 2.5 };
      case E.TWICE: return { g: x.val > 8 ? (hard ? 3 : 2) : 0 };
      case E.ALLPAY: return { g: x.pw < 0.3 ? Math.min(x.mo, 40) * 0.2 : 0 };
      case E.AVG: return { g: x.pw * x.val * 0.25 };
      case E.OPEN: return { g: hard ? 2 : 1.5 };
      case E.BLIND: return { g: x.mo - x.val > 6 ? (x.mo - x.val) * 0.3 : 0 };
      case E.ALLY: {
        if (x.val < 5 || x.mi < 0) return null;
        const t = aimOK(s, seat, k, x.mi, lv) ? x.mi : bestTarget(s, seat, k, lv, (o) => x.ov[o]);
        return t < 0 ? null : { g: Math.min(x.ov[t], x.val) * 0.5, tg: t };
      }
      case E.COLLR: return { g: (1 - x.pw) * Math.min(x.mo, collVal(s)) * 0.25 };
      case E.MINBID: {
        const t = bestTarget(s, seat, k, lv, (o) => -x.ov[o] + (f ? 0 : -s.c[o] / 50));
        return t < 0 ? null : { g: f ? MIN_AMT * x.pTake : 2.5, tg: t };
      }
      case E.SABO: {
        const t = f ? bestTarget(s, seat, k, lv, (o) => s.c[o]) : aimOK(s, seat, k, x.mi, lv) ? x.mi : -1;
        if (t < 0) return null;
        return { g: f ? x.avoid * x.pTake * 0.5 : x.val > 0 ? Math.min(SABO_AMT, x.ov[t]) * 0.5 * (0.3 + x.pw) : 0, tg: t };
      }
      case E.CBLOCK: {
        const t = bestTarget(s, seat, k, lv, (o) => s.ev[o].length + (o === x.lead ? 2 : 0));
        return t < 0 ? null : { g: 1.5 + s.ev[t].length * 0.6 + (t === x.lead ? 2 : 0), tg: t };
      }
      case E.ROTATE: { const prev = (seat + n - 1) % n; return { g: (s.ev[prev].length - (s.ev[seat].length - 1)) * 1.5 }; }
      case E.ACCUSE: {
        const t = bestTarget(s, seat, k, lv, (o) => fakeCount(s.co[o]) + (o === x.lead ? 1 : 0));
        return t < 0 ? null : { g: ACC_PTS * fakeCount(s.co[t]) * x.rate * 0.6, tg: t };
      }
      case E.TAX: { let t = 0; for (let o = 0; o < n; o++) if (o !== seat) t += Math.floor(free(s, o) / 10); return { g: t * 0.4 }; }
      case E.INVEST: return { g: (INV_OUT - INV_IN) * 0.7 - (x.val > s.c[seat] - INV_IN ? 4 : 0) };
      case E.OWNER: return { g: (1 - x.pw) * x.mo * 0.25 };
      case E.RAFFLE: return { g: 1 };
      case E.RUSH: return { g: 6 };
      case E.INSTAL: return { g: x.pw * Math.min(x.val, 30) * 0.15 };
      case E.LEND: {
        const t = bestTarget(s, seat, k, lv, (o) => -x.tot[o]);
        return t < 0 ? null : { g: (LEND_BACK - LEND_OUT) * 0.6 - 2, tg: t };
      }
      case E.BUYOUT: {
        const base = sc0();
        let bt = -1, bg = -Infinity;
        for (const t of tgList(s, seat, k)) {
          if (targetWhy(s, seat, k, t)) continue;
          const o = t >> 6, j = t & 63, B = s.co[o], ch = B[j];
          if (lv >= 2 && bit(s.sh, o)) continue;
          const mine = scWith(s, seat, ch).items - base;
          const theirs = scWith(s, o).items - score(B.slice(0, j) + B.slice(j + 1), 0, s.cf, s.tr, 0, s.gf).items;
          const g = (mine + theirs * (hard ? 0.5 : 0.3)) * x.rate - buyPrice(idOf(ch));
          if (g > bg) { bg = g; bt = t; }
        }
        return bt < 0 ? null : { g: bg, tg: bt };
      }
      case E.RETURN: {
        const rt = returnable(s, seat);
        if (!rt) return null;
        let co = s.co[seat];
        for (const ch of rt.chars) co = co.replace(ch, '');
        const loss = sc0() - score(co, 0, s.cf, s.tr, 0, s.gf).items;
        return { g: Math.floor(rt.pay / 2) - loss * x.rate * 1.1 };
      }
      case E.REPLICA: {
        let bt = -1, bg = -Infinity;
        for (let t = 0; t < 4; t++) {
          if (targetWhy(s, seat, k, t)) continue;
          const g = (scWith(s, seat, chOf(PROP_IDS[t])).items - sc0() + potential(s, seat, chOf(PROP_IDS[t]), futureOdds(s)) * 0.5) * x.rate;
          if (g > bg) { bg = g; bt = t; }
        }
        return bt < 0 ? null : { g: bg, tg: bt };
      }
      case E.APPRAISE: return { g: hard ? 2 : 1.5 };
      case E.BET: {
        const N = betLine(s), P = Math.max(x.val, x.mo) * (hard ? 0.75 : 0.7);
        const p = U.clamp(0.5 + Math.abs(P - N) / 30, 0.5, hard ? 0.85 : 0.75);
        return { g: BET_WIN * p - BET_LOSE * (1 - p), tg: P >= N ? 0 : 1 };
      }
      case E.MISSION: {
        let bd = -1, bp = -Infinity;
        const odds = futureOdds(s);
        for (let d = 0; d < 5; d++) {
          if (targetWhy(s, seat, k, d)) continue;
          const me = countKind(s.co[seat], String(d)), need = MIS_N - me;
          const p = need <= 0 ? 0.97 : U.clamp((odds[d] * 0.45 - need + 1) * (need === 1 ? 0.6 : 0.3), 0, 0.85);
          const g = MIS_WIN * p - MIS_LOSE * (1 - p);
          if (g > bp) { bp = g; bd = d; }
        }
        return bd < 0 ? null : { g: bp * x.rate, tg: bd };
      }
      case E.CURATOR: {
        const kinds = new Set(s.co[seat].split('').map((ch) => { const it = item(idOf(ch)); return it.k === 'f' ? '' : it.k === 'c' ? 'c' + it.c : it.k; }).filter(Boolean));
        return { g: (Math.min(CUR_MAX, kinds.size + x.left * 0.15)) * x.rate - 2 };
      }
      case E.FAME: return { g: x.pw * FAME_PTS * x.rate };
      case E.FOCUS: { const sc = scWith(s, seat); return { g: (Math.max(...sc.cnt) + x.left * 0.08) * x.rate - 2 }; }
      case E.BOOM: return { g: s.c[seat] < avgOthers(s, seat) ? 2 : 0.5 };
      case E.SLUMP: return { g: (avgOthers(s, seat) - s.c[seat]) * 0.12 };
      case E.CRASH: return { g: (avgOthers(s, seat) - s.c[seat]) / 20 * x.rate * (0.3 + 0.7 * s.r / s.R) + 0.5 };
      case E.NOFAKE: return { g: x.tot[seat] <= Math.min(...x.tot) + 2 ? 4 : 1 };
      case E.FIXED: return { g: hard ? 2.5 : 2 };
      case E.FAKEGIFT: {
        const t = hard ? bestTarget(s, seat, k, lv, (o) => x.tot[o]) : bestTarget(s, seat, k, lv, () => Math.random());
        return t < 0 ? null : { g: 4 * x.rate * 0.6, tg: t };
      }
      case E.HEIR: return { g: x.left >= 3 ? HEIR_AMT - (s.c[seat] + HEIR_AMT) * 0.4 / 10 * x.rate - 4 : -1 };
      case E.FIRST: return { g: x.pw * 2 };
      case E.BUYNOW: return { g: x.val - nowPrice(s) };
      case E.DUEL: {
        if (x.val < 5) return null;
        const t = bestTarget(s, seat, k, lv, (o) => -x.ov[o]);
        return t < 0 ? null : { g: (x.mo - x.ov[t]) * 0.5, tg: t };
      }
      case E.SUMPEEK: return { g: f ? x.avoid * 0.3 : x.val * 0.25 };
    }
    return null;
  }
  /* every legal way to play card k (with each legal target) */
  function cardOpts(s, seat, k) {
    if (!TARGET[k]) return cantUse(s, seat, k) ? [] : [{ k }];
    const r = [];
    for (const t of tgList(s, seat, k)) if (!cantUse(s, seat, k, t)) r.push({ k, tg: t });
    return r;
  }
  function aiCard(s, seat, lv) {
    if (!s.eo || usedBy(s, seat) >= 0) return null;
    const hand = s.ev[seat];
    if (!hand) return null;
    const left = s.R - s.r, kinds = [...new Set(hand.split('').map(idOf))];
    if (lv === 1) { // beginner: plays a random card now and then
      if (Math.random() > 0.3 && hand.length < left) return null;
      const opts = [];
      for (const k of kinds) opts.push(...cardOpts(s, seat, k));
      return opts.length ? Object.assign({ t: 'card' }, opts[U.rand(opts.length)]) : null;
    }
    const x = aiCtx(s, seat);
    let best = null;
    for (const k of kinds) {
      if (cantUse(s, seat, k)) continue;
      const r = cardGain(s, seat, k, lv, x);
      if (!r || !(r.g > 0)) continue;
      if (TARGET[k] && cantUse(s, seat, k, r.tg)) continue;
      if (lv === 2) r.g *= 0.6 + 0.8 * Math.random();
      if (!best || r.g > best.g) best = Object.assign({ k }, r);
    }
    if (!best) return null;
    const thr = hand.length >= left ? 0.01 : (lv === 3 ? 7 : 6) * (hand.length >= 3 ? 0.75 : 1);
    if (best.g < thr) return null;
    const a = { t: 'card', k: best.k };
    if (TARGET[best.k]) a.tg = best.tg;
    return a;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph !== 'b' || s.b[seat] != null) return null;
    const c = aiCard(s, seat, lv);
    if (c) return c;
    return { t: 'bid', v: aiBid(s, seat, lv) };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph !== 'b' || s.b[seat] != null) return -1;
    let d = (lv === 1 ? 1300 : lv === 3 ? 650 : 950) + U.rand(900);
    // holding a card that reads other bids: let others commit first
    if (lv >= 2 && s.eo && usedBy(s, seat) < 0 && peekVal(s, seat) < 0 && [E.PEEK, E.SNOOP, E.MEGA, E.SUMPEEK].some((k) => s.ev[seat].indexOf(chOf(k)) >= 0)) d += 1400;
    return d;
  }

  /* ---------- art (original SVG, 100×80) ---------- */
  let uid = 0;
  const sky = (u, a, b) => '<defs><linearGradient id="' + u + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + a + '"/><stop offset="1" stop-color="' + b + '"/></linearGradient></defs><rect width="100" height="80" fill="url(#' + u + ')"/>';
  function star(cx, cy, r) {
    let d = '';
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, q = i % 2 ? r * 0.45 : r; d += (i ? 'L' : 'M') + (cx + q * Math.cos(a)).toFixed(1) + ' ' + (cy + q * Math.sin(a)).toFixed(1); }
    return d + 'z';
  }
  function city() {
    const bl = [[4, 14, 40], [20, 12, 52], [34, 16, 34], [52, 12, 58], [66, 14, 44], [82, 14, 30]];
    let o = '';
    for (const [x, w, hh] of bl) {
      o += '<rect x="' + x + '" y="' + (80 - hh) + '" width="' + w + '" height="' + hh + '" fill="#1e1830"/>';
      for (let y = 80 - hh + 5; y < 76; y += 7) for (const wx of [x + 3, x + w - 6]) if ((wx + y) % 3) o += '<rect x="' + wx + '" y="' + y + '" width="3" height="3" fill="#ffd36b"/>';
    }
    return o;
  }
  /* paintings: tier×3 + variant. variant 0 keeps the classic landscape set */
  function paintOld(v, u) {
    const sk = [['#f6c27a', '#e8735b'], ['#9fd0e8', '#f2e2b8'], ['#e9b3a8', '#7e5a8c'], ['#cfd9c4', '#8fa7a0'], ['#1f2a55', '#4a4f8c']][v];
    const hill = ['#3f6b55', '#a2473f', '#6b4a3a', '#7b8b5a', '#2d3b4f'][v];
    return sky(u, sk[0], sk[1]) +
      '<circle cx="' + (30 + v * 10) + '" cy="' + (22 + (v % 2) * 6) + '" r="' + (v === 4 ? 7 : 9) + '" fill="' + (v === 4 ? '#f4ecd0' : '#fff3c4') + '" opacity=".9"/>' +
      (v === 2 ? '<ellipse cx="50" cy="56" rx="16" ry="14" fill="#3b2d33"/><circle cx="50" cy="38" r="11" fill="#3b2d33"/><path d="M41 31l2-9 5 7M59 31l-2-9-5 7" fill="#3b2d33"/><circle cx="46" cy="37" r="1.6" fill="#f6d36b"/><circle cx="54" cy="37" r="1.6" fill="#f6d36b"/>' :
        '<path d="M0 58 Q25 ' + (38 + v * 3) + ' 50 55 T100 50 V80 H0z" fill="' + hill + '"/><path d="M0 68 Q30 58 60 66 T100 64 V80 H0z" fill="' + hill + '" opacity=".7" style="filter:brightness(.7)"/>') +
      (v === 0 ? '<path d="M64 60h18l-3 5H67z" fill="#2c1f1a"/><path d="M72 60V46l7 10z" fill="#f2e9d8"/>' : '') +
      (v === 1 ? '<g fill="#d9584a"><circle cx="20" cy="66" r="3"/><circle cx="30" cy="70" r="3"/><circle cx="78" cy="68" r="3"/></g>' : '') +
      (v === 4 ? '<path d="M0 64h100v16H0z" fill="#2a3566"/><path d="M38 66h24M30 70h40M42 74h16" stroke="#f4ecd0" stroke-width="1.2" opacity=".6"/>' : '');
  }
  const PAINT = [ // [sky top, sky bottom, scene] for variants 1 and 2 of each tier
    ['#bfe0ee', '#f3ead2', '<rect y="22" width="30" height="58" fill="#c98f6a"/><rect x="70" y="16" width="30" height="64" fill="#b77a5a"/><rect x="8" y="34" width="8" height="10" fill="#3b2d33" opacity=".5"/><rect x="80" y="30" width="8" height="10" fill="#3b2d33" opacity=".5"/><path d="M30 30Q50 40 70 26" stroke="#3b2d33" fill="none"/><rect x="36" y="32" width="8" height="10" fill="#d9584a"/><rect x="48" y="34" width="7" height="12" fill="#4f8fdc"/><rect x="58" y="31" width="8" height="9" fill="#f6d36b"/><rect y="70" width="100" height="10" fill="#8a7b6a"/>'],
    ['#f3eee2', '#ebe3d0', '<g stroke="#55505a" stroke-width="1.4" fill="none" stroke-linecap="round"><path d="M22 60V38l16-12 16 12v22z"/><path d="M33 60V48h10v12"/><path d="M8 62h84"/><circle cx="72" cy="38" r="12"/><path d="M72 50v12M62 34l6 4M78 32l-4 6"/></g><path d="M10 70l20-2M40 71l30-1" stroke="#55505a" stroke-width=".8" opacity=".5"/>'],
    ['#e9c48a', '#b9763e', '<path d="M44 54L38 36M50 54l2-26M56 54l8-14" stroke="#3f6b35" stroke-width="2"/><path d="M40 76l-4-22h28l-4 22z" fill="#4f6fa8"/><g fill="#f2c230"><circle cx="38" cy="34" r="8"/><circle cx="52" cy="26" r="8"/><circle cx="64" cy="38" r="8"/></g><g fill="#6b3d1a"><circle cx="38" cy="34" r="3.5"/><circle cx="52" cy="26" r="3.5"/><circle cx="64" cy="38" r="3.5"/></g>'],
    ['#2d3b55', '#4e6a8a', '<g stroke="#bcd3ea" stroke-width="1.2" opacity=".7"><path d="M26 16l-3 8M38 22l-3 8M60 16l-3 8M72 24l-3 8M30 44l-3 8M44 48l-3 8M64 44l-3 8M74 52l-3 8"/></g><rect x="18" y="10" width="64" height="56" fill="none" stroke="#6b4a24" stroke-width="5"/><path d="M50 10v56M18 38h64" stroke="#6b4a24" stroke-width="3"/><rect x="12" y="66" width="76" height="6" fill="#8a5a2b"/><path d="M24 66h10l-2-8h-6z" fill="#c26a3a"/><circle cx="29" cy="54" r="5" fill="#3f8b5a"/>'],
    ['#e7d8bf', '#c7b08a', '<rect y="56" width="100" height="24" fill="#8a5a3a"/><ellipse cx="50" cy="60" rx="38" ry="6" fill="#efe6d2"/><g fill="#d23a2e"><circle cx="36" cy="52" r="8"/><circle cx="52" cy="50" r="8"/><circle cx="66" cy="54" r="7"/></g><path d="M36 44v-4M52 42v-4M66 47v-4" stroke="#5a3d10" stroke-width="1.5"/><path d="M52 40c3-4 7-4 8-2-3 2-5 2-8 2z" fill="#3f8b35"/><circle cx="33" cy="49" r="2" fill="#fff" opacity=".5"/>'],
    ['#141c3a', '#2c3a6a', '<g fill="#fff3c4"><circle cx="14" cy="12" r="1"/><circle cx="30" cy="22" r="1"/><circle cx="84" cy="44" r="1"/><circle cx="20" cy="40" r="1"/></g><path d="M58 22L100 8v28z" fill="#fff3c4" opacity=".35"/><rect y="58" width="100" height="22" fill="#1d2f5a"/><path d="M38 64l8-8h22l8 8z" fill="#2b2530"/><path d="M50 58l3-34h6l3 34z" fill="#efe6d2"/><path d="M51.4 46h9.2l.6 6H50.8zM52.4 34h7.2l.5 5h-8.2z" fill="#d9584a"/><rect x="52" y="18" width="8" height="6" fill="#ffe08a"/><path d="M51 18l5-5 5 5z" fill="#d9584a"/>'],
    ['#9fd0e8', '#e6f1f6', '<path d="M0 66L34 22l20 24 14-14 32 34V80H0z" fill="#6c7a8c"/><path d="M34 22l-9 12 5 3 4-5 4 5 5-4zM68 32l-6 6 4 2 3-3 4 3z" fill="#fff"/><rect y="66" width="100" height="14" fill="#f2f6f8"/><path d="M14 66l5-12 5 12zM80 68l5-12 5 12z" fill="#2d5a45"/>'],
    ['#3a2550', '#d9705a', null], // city lights (drawn by city())
    ['#13235a', '#2a4a8c', '<g fill="none" stroke="#9fc4ff" stroke-width="2" opacity=".7" stroke-linecap="round"><path d="M10 30c10-10 24-10 30 0s20 10 30 0 20-8 26 0"/><path d="M20 44c8-6 18-6 24 0s16 6 24 0"/></g><circle cx="80" cy="16" r="7" fill="#ffe08a"/><g fill="#fff3a8"><circle cx="20" cy="14" r="2.4"/><circle cx="44" cy="18" r="2"/><circle cx="60" cy="10" r="2.6"/><circle cx="34" cy="8" r="1.6"/></g><path d="M0 66q30-12 60-2t40-4V80H0z" fill="#16203a"/><path d="M18 80c-6-16-4-34 4-50 6 16 6 34 2 50z" fill="#10261f"/>'],
    ['#bfe3d4', '#6fae8f', '<path d="M0 10h36v70H0zM64 10h36v70H64z" fill="#4a5a3a"/><path d="M36 12h28v58H36z" fill="#f4e3a0"/><path d="M42 14v54M50 14v54M58 14v54" stroke="#e3ae45" stroke-width="2" opacity=".8"/><ellipse cx="50" cy="72" rx="30" ry="7" fill="#fff6d8" opacity=".8"/><circle cx="12" cy="12" r="10" fill="#3f6b35"/><circle cx="88" cy="14" r="10" fill="#3f6b35"/>'],
  ];
  const ST = ' stroke="#2b3d5c" stroke-width="1.5"';
  const VASE = 'M44 12h12l-2 10c12 8 14 24 8 40l-4 10H42l-4-10c-6-16-4-32 8-40z';
  const CERA = [ // per tier: [classic, variant 1, variant 2]
    ['<path d="M28 40h44l-4 22c-2 6-8 8-18 8s-16-2-18-8zM70 46c8 0 8 10 0 10" fill="#2f5fa8"' + ST + '/>', // 쪽빛 찻잔
      '<path d="M22 44h56c-2 14-12 24-28 24S24 58 22 44z" fill="#d8c7a0"' + ST + '/><path d="M60 44l4 5 4-5" fill="#efe6d2" stroke="#2b3d5c" stroke-width="1.2"/><path d="M40 68h20v3H40z" fill="#b9a57d"/>',
      '<path d="M50 30c14 0 20 12 20 22s-8 16-20 16-20-6-20-16 6-22 20-22z" fill="#e9b3a8"' + ST + '/><path d="M50 30c-2-6 2-10 6-12" stroke="#5a7a3a" stroke-width="2" fill="none"/><path d="M56 22c6-4 12-2 12 2-4 2-8 2-12-2z" fill="#6fae5a"/><path d="M50 34v32" stroke="#2b3d5c" opacity=".35"/>'],
    ['<path d="M30 34c0-10 10-14 22-14s20 4 20 14v18c0 12-10 18-22 18s-20-6-20-18zM72 38c10 0 12 12 2 16M30 40l-12-8" fill="#c9d8e6"' + ST + '/><path d="M34 46c6 4 26 4 32 0M36 54c6 3 22 3 28 0" stroke="#2b3d5c" stroke-width="1.2" fill="none" opacity=".55"/>',
      '<ellipse cx="50" cy="48" rx="34" ry="18" fill="#f6f2e8"' + ST + '/><ellipse cx="50" cy="48" rx="24" ry="12" fill="none" stroke="#4f8fdc" stroke-width="1.2"/><g fill="#4f8fdc"><circle cx="50" cy="43" r="3"/><circle cx="44" cy="48" r="3"/><circle cx="56" cy="48" r="3"/><circle cx="50" cy="53" r="3"/></g><circle cx="50" cy="48" r="2" fill="#e3ae45"/>',
      '<path d="M50 14c6 0 8 6 6 12 6 4 6 10 2 14 12 6 14 18 8 26-4 6-28 6-32 0-6-8-4-20 8-26-4-4-4-10 2-14-2-6 0-12 6-12z" fill="#b8c98a"' + ST + '/><path d="M47 10h6v5h-6z" fill="#8a5a2b"/>'],
    ['<path d="' + VASE + '" fill="#4f8fdc"' + ST + '/><path d="M40 40c6 4 14 4 20 0M40 52c6 3 14 3 20 0" stroke="#f6f2e8" stroke-width="1.4" fill="none" opacity=".8"/>',
      '<path d="M34 36h32c6 6 8 14 6 22-2 8-10 12-22 12s-20-4-22-12c-2-8 0-16 6-22z" fill="#a8c5b5"' + ST + '/><path d="M32 30h36v6H32z" fill="#7fa595"' + ST + '/><circle cx="50" cy="26" r="4" fill="#7fa595"' + ST + '/><path d="M36 50h28" stroke="#2b3d5c" opacity=".4"/>',
      '<path d="M44 12h12v6c14 6 18 20 12 36l-6 16H38l-6-16c-6-16-2-30 12-36z" fill="#7fb3a3"' + ST + '/><g fill="none" stroke="#f6f2e8" stroke-width="1.6"><circle cx="42" cy="38" r="6"/><circle cx="58" cy="52" r="6"/><path d="M39 38l3-2 3 2M55 52l3-2 3 2"/></g>'],
    ['<path d="M42 14h16v8c10 6 14 16 14 28 0 14-10 22-22 22S28 64 28 50c0-12 4-22 14-28z" fill="#7fb3a3"' + ST + '/><path d="M34 46c6 4 26 4 32 0" stroke="#2b3d5c" stroke-width="1.2" fill="none" opacity=".55"/><circle cx="50" cy="40" r="5" fill="none" stroke="#2b3d5c" stroke-width="1.2" opacity=".6"/>',
      '<path d="M38 18h24v6c10 4 14 14 14 24 0 14-10 22-26 22S24 62 24 48c0-10 4-20 14-24z" fill="#f1ece0"' + ST + '/><path d="M28 46c6-8 12 4 18-4s12 4 18-4 10 2 10 2" stroke="#2f5fa8" stroke-width="2.4" fill="none" stroke-linecap="round"/><circle cx="71" cy="40" r="2" fill="#2f5fa8"/>',
      '<path d="M46 28c-4-6 6-8 2-14M54 28c-4-6 6-8 2-14" stroke="#9a92a8" stroke-width="1.6" fill="none" opacity=".8"/><path d="M28 34h44c0 14-8 22-22 22S28 48 28 34z" fill="#8a9a7a"' + ST + '/><path d="M34 54l-4 10M50 56v10M66 54l4 10" stroke="#2b3d5c" stroke-width="3" stroke-linecap="round"/><path d="M26 32h48" stroke="#2b3d5c" stroke-width="3"/>'],
    ['<path d="M50 12c18 0 26 14 26 30S66 72 50 72 24 58 24 42s8-30 26-30z" fill="#f1ece0"' + ST + '/><path d="M36 54c6 3 22 3 28 0" stroke="#2b3d5c" stroke-width="1.2" fill="none" opacity=".4"/>',
      '<path d="M20 38h60c-2 18-14 30-30 30S22 56 20 38z" fill="#3a3f4a"' + ST + '/><ellipse cx="50" cy="38" rx="30" ry="4" fill="#545a66" stroke="#2b3d5c"/><path d="M34 41l6 8-4 8 6 8M62 41l-4 10 6 6" stroke="#e3ae45" stroke-width="2" fill="none" stroke-linejoin="round"/>',
      '<g transform="translate(-17 6) scale(.85)"><path d="' + VASE + '" transform="translate(9 0)" fill="#e9b3a8"' + ST + '/></g><g transform="translate(23 6) scale(.85)"><path d="' + VASE + '" transform="translate(9 0)" fill="#9fc4e8"' + ST + '/></g>'],
  ];
  const GEMC = ['#3fcf8e', '#7fe3c0', '#2e9e6a', '#9be7a6', '#1f7a55'];
  function beads(cx, cy, rx, ry, a0, a1, k, r, ca, cb) {
    let o = '';
    for (let i = 0; i < k; i++) { const a = a0 + (a1 - a0) * i / (k - 1 || 1); o += '<circle cx="' + (cx + rx * Math.cos(a)).toFixed(1) + '" cy="' + (cy + ry * Math.sin(a)).toFixed(1) + '" r="' + r + '" fill="' + (i % 2 ? cb : ca) + '"/>'; }
    return o;
  }
  const GEMS = [ // per tier: [classic, v1, v2]; GEM is replaced with the gem colour
    ['<circle cx="50" cy="52" r="16" fill="none" stroke="#e3ae45" stroke-width="4"/><path d="M42 30l8-10 8 10-8 10z" fill="GEM" stroke="#0b3a26"/>',
      '<path d="M18 62L76 22" stroke="#e3ae45" stroke-width="3.5" stroke-linecap="round"/><circle cx="78" cy="20" r="6" fill="#f4efe4"/><circle cx="70" cy="27" r="4" fill="GEM"/><circle cx="85" cy="28" r="3" fill="#f4efe4"/>',
      () => beads(50, 42, 18, 18, 0, Math.PI * 2 * 11 / 12, 12, 4.4, 'GEM', '#e3ae45')],
    ['<path d="M38 18v14M62 18v14" stroke="#e3ae45" stroke-width="2"/><path d="M38 32c-8 10-8 22 0 26 8-4 8-16 0-26zM62 32c-8 10-8 22 0 26 8-4 8-16 0-26z" fill="GEM" stroke="#0b3a26"/>',
      '<path d="M26 30h48v10H26z" fill="#cfd3da" stroke="#6a6f7a"/><path d="M30 40v20M35 40v20M40 40v20M45 40v20M50 40v20M55 40v20M60 40v20M65 40v20M70 40v20" stroke="#cfd3da" stroke-width="2.4"/><circle cx="40" cy="35" r="2.6" fill="GEM"/><circle cx="50" cy="35" r="3" fill="GEM"/><circle cx="60" cy="35" r="2.6" fill="GEM"/>',
      '<path d="M30 10l20 26 20-26" stroke="#e3ae45" stroke-width="1.6" fill="none"/><g fill="GEM" stroke="#0b3a26"><circle cx="50" cy="38" r="7"/><circle cx="43" cy="46" r="7"/><circle cx="57" cy="46" r="7"/><circle cx="50" cy="53" r="7"/></g><circle cx="50" cy="46" r="2.5" fill="#e3ae45"/>'],
    ['<path d="M50 18l20 14-8 28H38l-8-28z" fill="GEM" stroke="#0b3a26" stroke-width="1.5"/><path d="M30 32h40M50 18l-6 14 6 28 6-28z" stroke="#0b3a26" fill="none" opacity=".5"/>',
      '<circle cx="50" cy="12" r="3" fill="none" stroke="#e3ae45" stroke-width="2"/><path d="M50 15v8" stroke="#e3ae45" stroke-width="3"/><circle cx="50" cy="44" r="20" fill="#e3ae45" stroke="#7a5418" stroke-width="2"/><circle cx="50" cy="44" r="15" fill="#f6f0dc"/><path d="M50 44V34M50 44l7 4" stroke="#2a1d05" stroke-width="2" stroke-linecap="round"/><circle cx="50" cy="25" r="3" fill="GEM"/>',
      '<path d="M50 30v30" stroke="#e3ae45" stroke-width="3"/><path d="M50 40c-6-14-22-16-24-6-1 8 10 12 24 6zM50 40c6-14 22-16 24-6 1 8-10 12-24 6zM50 44c-8 2-18 8-14 14 4 4 12 0 14-14zM50 44c8 2 18 8 14 14-4 4-12 0-14-14z" fill="GEM" stroke="#0b3a26"/>'],
    ['<ellipse cx="50" cy="44" rx="26" ry="20" fill="none" stroke="GEM" stroke-width="8"/><ellipse cx="50" cy="44" rx="26" ry="20" fill="none" stroke="#0b3a26" stroke-width="1" opacity=".5"/>',
      () => beads(50, 22, 28, 30, Math.PI * 0.1, Math.PI * 0.9, 13, 3.6, '#f4efe4', '#e8e0cf') + '<path d="M50 56l6 8-6 9-6-9z" fill="GEM" stroke="#0b3a26"/>',
      '<circle cx="34" cy="40" r="12" fill="none" stroke="#e3ae45" stroke-width="5"/><circle cx="34" cy="40" r="5" fill="GEM"/><path d="M46 40h34M70 40v10M78 40v8" stroke="#e3ae45" stroke-width="5"/>'],
    ['<path d="M24 56l6-26 12 14 8-20 8 20 12-14 6 26z" fill="#e3ae45" stroke="#7a5418" stroke-width="1.5"/><circle cx="50" cy="44" r="5" fill="GEM"/><circle cx="34" cy="48" r="3.5" fill="GEM"/><circle cx="66" cy="48" r="3.5" fill="GEM"/>',
      '<path d="M44 66h12l3 6H41z" fill="#e3ae45"/><ellipse cx="50" cy="42" rx="18" ry="24" fill="GEM" stroke="#0b3a26" stroke-width="1.5"/><path d="M33 36c10 4 24 4 34 0M33 50c10 4 24 4 34 0" stroke="#e3ae45" stroke-width="3" fill="none"/><g fill="#f4efe4"><circle cx="42" cy="43" r="2"/><circle cx="50" cy="44" r="2"/><circle cx="58" cy="43" r="2"/></g>',
      () => '<path d="M18 62c10-16 54-16 64 0" stroke="#d8dbe2" stroke-width="5" fill="none"/><path d="' + star(50, 34, 12) + '" fill="GEM" stroke="#0b3a26"/><path d="' + star(32, 46, 7) + star(68, 46, 7) + '" fill="#d8dbe2"/>'],
  ];
  const SCUL = [ // per tier: [metal, figure] ×3; M is replaced with the metal colour
    [['#b07a3a', '<path d="M28 58c0-10 6-16 16-16h14c8 0 12 4 14 10l4 6zM60 42c0-8 6-14 12-12 4 2 4 8 0 12" fill="M"/><circle cx="70" cy="36" r="8" fill="M"/><path d="M64 30c4-6 12-6 14 0" stroke="#7a4e1e" stroke-width="2" fill="none"/>'],
      ['#8a5a35', '<ellipse cx="50" cy="48" rx="14" ry="12" fill="M"/><circle cx="50" cy="30" r="9" fill="M"/><circle cx="43" cy="22" r="3.5" fill="M"/><circle cx="57" cy="22" r="3.5" fill="M"/><ellipse cx="50" cy="33" rx="4" ry="3" fill="#c79a6a"/><circle cx="50" cy="31.5" r="1.4" fill="#2a1d05"/><path d="M38 56h8v4h-8zM54 56h8v4h-8z" fill="M"/>'],
      ['#8f9a8a', '<ellipse cx="48" cy="50" rx="20" ry="11" fill="M"/><path d="M36 48l6-6h12l6 6-6 6H42z" fill="none" stroke="#5f6a5a" stroke-width="1.5"/><circle cx="72" cy="50" r="6" fill="M"/><path d="M34 58l-4 2M60 58l4 2" stroke="M" stroke-width="5" stroke-linecap="round"/>']],
    [['#e9e4da', '<path d="M36 58c0-8 6-12 14-12s14 4 14 12z" fill="M"/><ellipse cx="50" cy="34" rx="10" ry="12" fill="M"/><path d="M42 30c4-4 12-4 16 0" stroke="#a8a091" stroke-width="1.5" fill="none"/>'],
      ['#b07a3a', '<path d="M46 24v-6h8v6" stroke="M" stroke-width="3" fill="none"/><path d="M36 56c0-6 2-8 2-18 0-8 6-14 12-14s12 6 12 14c0 10 2 12 2 18z" fill="M"/><path d="M34 56h32" stroke="#7a4e1e" stroke-width="3"/><circle cx="50" cy="58" r="3" fill="#7a4e1e"/>'],
      ['#d8d0c2', '<path d="M40 60V36c0-3 4-3 4 0v-8c0-3 4-3 4 0v-2c0-3 4-3 4 0v4c0-3 4-3 4 0v14l4-6c2-2 5 0 4 2l-6 12c-2 4-4 6-6 6z" fill="M" stroke="#a8a091"/>']],
    [['#e3ae45', '<path d="M26 40c10-12 30-12 40 0-10 12-30 12-40 0zM66 40l12-10v20z" fill="M"/><circle cx="34" cy="38" r="2" fill="#5a3d10"/>'],
      ['#6e5a68', '<ellipse cx="46" cy="44" rx="18" ry="12" fill="M" stroke="#c9b8c4" stroke-width="1"/><circle cx="64" cy="38" r="9" fill="M"/><path d="M70 42c4 6 4 12 0 16" stroke="M" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M34 52v8M42 52v8M52 52v8M58 52v8" stroke="M" stroke-width="6"/><path d="M60 34c-6 2-6 10 0 10" fill="#6a5a62"/><circle cx="66" cy="36" r="1.5" fill="#e3ae45"/>'],
      ['#b07a3a', '<path d="M32 26l-6-4M68 26l6-4" stroke="M" stroke-width="3"/><path d="M32 22c0-6 36-6 36 0v18c0 14-8 22-18 22S32 54 32 40z" fill="M"/><path d="M38 34h9M53 34h9" stroke="#2a1d05" stroke-width="3.5" stroke-linecap="round"/><path d="M50 36v10M44 52c4 3 8 3 12 0" stroke="#7a4e1e" stroke-width="2" fill="none"/>']],
    [['#c98f52', '<circle cx="50" cy="24" r="6" fill="M"/><path d="M50 30v16l-8 12M50 46l8 12M50 34l-12-6M50 34l12 4 6-8" stroke="M" stroke-width="5" stroke-linecap="round" fill="none"/>'],
      ['#c98f52', '<ellipse cx="46" cy="46" rx="16" ry="7" fill="M"/><path d="M60 44l8-12 6 2-4 8z" fill="M"/><path d="M34 50l-2 10M40 50l2 10M52 50l-2 10M58 50l2 10M30 44l-6 6" stroke="M" stroke-width="3"/><path d="M44 40V28" stroke="M" stroke-width="6" stroke-linecap="round"/><circle cx="44" cy="22" r="5" fill="M"/><path d="M48 30l12-12" stroke="#7a4e1e" stroke-width="2"/>'],
      ['#bdb3a3', '<path d="M50 19v-8" stroke="#8a8070" stroke-width="2"/><path d="M34 60h32v-8H34zM37 52h26V42H37zM32 42h36v-3H32zM39 39h22v-8H39zM35 31h30v-3H35zM42 28h16v-6H42zM38 22h24v-3H38z" fill="M" stroke="#8a8070" stroke-width=".8"/>']],
    [['#f0c35a', '<circle cx="50" cy="38" r="18" fill="M"/><circle cx="50" cy="38" r="11" fill="none" stroke="#9a6a14" stroke-width="2"/><path d="M50 14v6M50 56v6M26 38h6M68 38h6M33 21l4 4M63 51l4 4M33 55l4-4M63 25l4-4" stroke="#9a6a14" stroke-width="2"/>'],
      ['#f0c35a', '<path d="M60 58c8 0 10-8 6-12" stroke="M" stroke-width="3" fill="none"/><path d="M38 60c-2-10 0-20 6-24l-2-14 6 8h4l6-8-2 14c6 4 8 14 6 24z" fill="M"/><circle cx="46" cy="32" r="1.6" fill="#5a3d10"/><circle cx="54" cy="32" r="1.6" fill="#5a3d10"/>'],
      ['#9fc4c0', '<path d="M30 32c-6 6-6 16-2 24M70 32c6 6 6 16 2 24" stroke="#7fc4ff" stroke-width="2" fill="none" opacity=".8"/><circle cx="46" cy="22" r="6" fill="M"/><path d="M42 28c-2 8 0 16 6 22 4 4 2 8-4 10l14-2c-2-4-6-6-6-10 0-6 4-14 0-20z" fill="M"/><path d="M58 50l8-4-2 8z" fill="M"/>']],
  ];
  const BIRDC = ['#c7a26b', '#9c7a52', '#4fa3a0', '#38383f', '#e9e4da', '#3fbf6a', '#e3c34a', '#d9584a', '#f4f1ea', '#3aa6c9', '#f08fb0', '#2a2a33', '#7a5230', '#9aa3ad', '#26262e', '#f2c230'];
  function birdArt(v) {
    const b = BIRDC[v], swan = v === 8;
    const head = swan ? '<path d="M62 40c8-6 2-14 6-22" stroke="' + b + '" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="70" cy="18" r="6" fill="' + b + '" stroke="#e3ae45" stroke-width="1.2"/><circle cx="72" cy="16" r="1.6" fill="#111"/><path d="M75 18l7 2-7 2z" fill="#e8823a"/>'
      : '<circle cx="66" cy="34" r="9" fill="' + b + '" stroke="#e3ae45" stroke-width="1.5"/><circle cx="68" cy="32" r="2" fill="#111"/>';
    const beak = v === 5 ? '<path d="M74 32c6 0 7 6 2 8l-2-3z" fill="#d9584a"/>' : v === 6 ? '<path d="M73 33h10c1 3-2 4-10 3z" fill="#e8823a"/>' : v === 9 ? '<path d="M74 34l18 1-18 2z" fill="#38383f"/>' : v === 10 ? '<path d="M74 33c6 0 8 3 6 7-2-2-4-3-6-3z" fill="#f4efe4"/><path d="M78 37c2 0 2 3 0 3z" fill="#111"/>' : v === 11 ? '<path d="M74 34l8 2-8 3z" fill="#f08a2a"/>' : v === 12 ? '<path d="M74 31c7 0 9 4 7 8l-3-2-4 1z" fill="#f2c230"/>' : v === 14 ? '<path d="M74 33l11 2-11 4z" fill="#6a6a72"/>' : swan ? '' : '<path d="M74 34l9 2-9 3z" fill="#e3ae45"/>';
    const extra = [
      '', '<path d="M59 28l1-9 5 5zM68 25l5-6v9z" fill="' + b + '"/><circle cx="68" cy="32" r="3.5" fill="#f6d36b"/><circle cx="68" cy="32" r="1.6" fill="#111"/>',
      '<path d="M28 44l-14-14M28 46l-16-6M28 48l-14 4" stroke="#4fa3a0" stroke-width="3" stroke-linecap="round"/><g fill="#e3ae45"><circle cx="14" cy="30" r="2.5"/><circle cx="12" cy="40" r="2.5"/><circle cx="14" cy="52" r="2.5"/></g>',
      '<ellipse cx="50" cy="50" rx="10" ry="6" fill="#f2f2f2"/><path d="M30 44L8 40" stroke="#38383f" stroke-width="5" stroke-linecap="round"/>',
      '<circle cx="64" cy="26" r="3" fill="#d9584a"/><path d="M28 44c-6 0-10 4-12 8" stroke="#38383f" stroke-width="4" fill="none" stroke-linecap="round"/>',
      '<path d="M40 44c4 8 14 8 18 2z" fill="#f2c230"/>', '<path d="M28 42c-6-2-10 0-12 4" stroke="#3f6b35" stroke-width="3" fill="none"/>',
      '<path d="M60 27l2-6 3 4 3-5 2 5 3-2-1 5z" fill="#d23a2e"/><circle cx="74" cy="40" r="2.4" fill="#d23a2e"/><path d="M30 40c-10-10-18-8-20 0M30 44c-12-4-18 2-16 8" stroke="#3a2f45" stroke-width="3" fill="none"/>',
      '', '<path d="M44 34c-4-10 4-16 10-12z" fill="#7fe3c0" opacity=".7"/>',
      '<path d="M42 60v14M54 60v14" stroke="#d96b8f" stroke-width="2.4"/><path d="M38 74h8M50 74h8" stroke="#d96b8f" stroke-width="2"/><path d="M40 42c6 6 14 6 18 0" stroke="#fff" stroke-width="1.5" fill="none" opacity=".6"/>',
      '<ellipse cx="52" cy="50" rx="11" ry="9" fill="#f4f1ea"/><circle cx="63" cy="38" r="3" fill="#f4f1ea"/><path d="M40 60h6M52 60h6" stroke="#f08a2a" stroke-width="3"/>',
      '<circle cx="66" cy="34" r="8" fill="#f4f1ea"/><circle cx="68" cy="32" r="2" fill="#111"/><path d="M28 40l-14-6M28 44H12M28 48l-14 6" stroke="#5a3a20" stroke-width="4" stroke-linecap="round"/>',
      '<path d="M58 40c4 4 10 4 12 0" stroke="#5fb39a" stroke-width="3" fill="none"/><path d="M38 44c6 4 12 4 16 0" stroke="#6a737d" stroke-width="2" fill="none"/>',
      '<path d="M28 42l-16-4M28 46l-16 4" stroke="#1a1a20" stroke-width="4" stroke-linecap="round"/><circle cx="68" cy="32" r="2.6" fill="#d8dbe2"/><circle cx="68" cy="32" r="1.3" fill="#111"/>',
      '<path d="M60 31h14" stroke="#111" stroke-width="3" stroke-linecap="round"/><path d="M30 44l-14 2" stroke="#111" stroke-width="4" stroke-linecap="round"/><path d="M38 42c6 6 14 6 18 0" stroke="#111" stroke-width="2" fill="none"/>',
    ][v];
    return '<rect width="100" height="80" fill="#2e2440"/><path d="M0 66h100v14H0z" fill="#1f1830"/>' +
      '<ellipse cx="48" cy="46" rx="20" ry="14" fill="' + b + '" stroke="#e3ae45" stroke-width="1.5"/>' + head + beak +
      '<path d="M30 42c-10-2-16 2-20 8 8 0 14-2 20-4z" fill="' + b + '" stroke="#e3ae45" stroke-width="1.2"/>' +
      '<path d="M40 40c6 8 16 8 20 2" stroke="#e3ae45" stroke-width="1.5" fill="none"/><path d="M42 60v6M54 60v6" stroke="#e3ae45" stroke-width="2"/>' +
      '<path d="M48 32v-8" stroke="#bfc3cc" stroke-width="2"/><path d="M40 20c0-5 16-5 16 0s-16 5-16 0z" fill="none" stroke="#bfc3cc" stroke-width="2.5"/>' + extra;
  }
  function fakeArt(v) {
    const obj = [
      '<g transform="rotate(-5 50 40)"><rect x="18" y="12" width="64" height="52" fill="#b9b0a0" stroke="#7a6a50" stroke-width="5"/><path d="M22 50 Q40 30 56 46 T80 40 V60 H22z" fill="#8a8f7a"/><circle cx="38" cy="28" r="6" fill="#d8cfa0"/></g>',
      '<path d="M42 14h16v8c10 6 14 16 14 28 0 14-10 22-22 22S28 64 28 50c0-12 4-22 14-28z" fill="#9aa88a" stroke="#4a4550" stroke-width="1.5"/><path d="M36 44c4 6 8 2 10 10" stroke="#c9b897" stroke-width="3" fill="none"/>',
      '<g transform="rotate(4 50 40)"><rect x="16" y="12" width="68" height="52" fill="#d9b0a0" stroke="#8a6a3a" stroke-width="5"/><circle cx="50" cy="34" r="10" fill="#a2473f"/><path d="M30 60c4-14 36-14 40 0" fill="#6b4a3a"/><path d="M24 20l12 8M70 50l8 6" stroke="#fff" stroke-width="2" opacity=".4"/></g>',
      '<path d="M50 16l22 16-9 30H37l-9-30z" fill="#a8d8c8" opacity=".75" stroke="#6a6f7a" stroke-width="1.5"/><path d="M28 32h44" stroke="#6a6f7a" opacity=".6"/>',
      '<path d="M36 64c0-8 6-12 14-12s14 4 14 12z" fill="#cfc7b8"/><ellipse cx="50" cy="36" rx="11" ry="14" fill="#cfc7b8"/><path d="M44 34h4M52 34h4" stroke="#6a6f7a" stroke-width="2"/><path d="M58 30l-4 2" stroke="#4a4550" stroke-width="1.5"/>',
      '<ellipse cx="48" cy="46" rx="20" ry="14" fill="#8a7a6a"/><circle cx="66" cy="34" r="9" fill="#8a7a6a"/><circle cx="68" cy="32" r="2" fill="#111"/><path d="M74 34l9 2-9 3z" fill="#b9a57d"/><path d="M40 60v6M54 60v6" stroke="#6a6f7a" stroke-width="2"/>',
      beads(50, 26, 24, 26, Math.PI * 0.15, Math.PI * 0.85, 11, 4.2, '#e8e4dc', '#cfcac0') + '<circle cx="37" cy="44" r="4.2" fill="#8d8496"/><path d="M46 54l4 6 4-6" fill="#cfcac0"/>',
      '<rect x="28" y="12" width="44" height="54" rx="2" fill="#7a6a8a" stroke="#4a4550" stroke-width="2"/><rect x="34" y="20" width="32" height="8" fill="#b9a57d" opacity=".6"/><path d="M36 40h28M36 46h20" stroke="#c9b897" stroke-width="2" opacity=".5"/><circle cx="50" cy="57" r="5" fill="#9a8a6a"/>',
      '<path d="M22 58l8-20h40l8 20z" fill="#c9a24a" stroke="#6a5a2a" stroke-width="1.5"/><path d="M44 42h14l-3 12H42z" fill="#9a9aa0"/><path d="M30 44h8" stroke="#fff3c4" stroke-width="1.5" opacity=".6"/>',
      '<rect x="36" y="10" width="28" height="56" fill="#d8cf8a" stroke="#8a7a3a"/><path d="M42 20c8 4 8 10 0 14s8 10 16 4M44 50h12" stroke="#3a3aa0" stroke-width="2.2" fill="none"/>',
      '<path d="M24 56l6-26 12 14 8-20 8 20 12-14 6 26z" fill="#9a6a3a" stroke="#5a3a1a" stroke-width="1.5"/><g fill="#6a8a5a" opacity=".8"><circle cx="36" cy="50" r="4"/><circle cx="60" cy="46" r="3"/><circle cx="50" cy="40" r="2.5"/></g>',
      '<path d="M18 16h56l8 6v42H26l-8-6z" fill="#d8c79a" stroke="#8a7a50" stroke-width="1.5"/><path d="M30 30c10 4 14-6 24 0s8 14 16 10" stroke="#8a5a3a" stroke-width="1.6" stroke-dasharray="3 2" fill="none"/><path d="M64 36l6 6M70 36l-6 6" stroke="#c0392b" stroke-width="2.4"/>',
    ][v];
    return '<rect width="100" height="80" fill="#5a5560"/>' + obj +
      '<path d="M58 10l-6 16 8 8-10 14 6 12" stroke="#2a2430" stroke-width="2" fill="none"/>' +
      '<g transform="rotate(12 70 56)"><rect x="54" y="44" width="34" height="22" rx="3" fill="none" stroke="#e0443a" stroke-width="3"/><text x="71" y="61" text-anchor="middle" font-size="16" font-weight="900" fill="#e0443a" font-family="sans-serif">?!</text></g>';
  }
  /* ---- round 12: masterpieces and special themes ---- */
  const gemBg = (u) => '<defs><radialGradient id="' + u + '"><stop offset="0" stop-color="#2d4a3e"/><stop offset="1" stop-color="#0f1d18"/></radialGradient></defs><rect width="100" height="80" fill="url(#' + u + ')"/>';
  const GOLDF = () => '<rect x="2" y="2" width="96" height="76" fill="none" stroke="#f0c35a" stroke-width="3"/><rect x="6.5" y="6.5" width="87" height="67" fill="none" stroke="#f0c35a" stroke-width="1" opacity=".8"/>' +
    '<path d="' + star(13, 14, 8) + '" fill="#ffd36b" stroke="#7a5418" stroke-width=".8"/>';
  function masterArt(c, x, u) {
    let o;
    if (c === 0 && x === 0) {
      o = sky(u, '#1d1640', '#5a2f5a') + '<g fill="#fff3c4"><circle cx="24" cy="14" r="1.2"/><circle cx="62" cy="10" r="1.4"/><circle cx="88" cy="28" r="1"/></g><circle cx="78" cy="18" r="6" fill="#fff3c4"/>' +
        '<path d="M16 50h68v24H16z" fill="#8a2a2a"/><path d="M8 52q42-14 84 0l-4-8q-38-10-76 0z" fill="#2a2030"/><path d="M28 36h44v8H28z" fill="#8a2a2a"/><path d="M20 38q30-12 60 0l-4-7q-26-8-52 0z" fill="#2a2030"/>' +
        '<g fill="#ffd36b"><rect x="24" y="58" width="6" height="8"/><rect x="38" y="58" width="6" height="8"/><rect x="56" y="58" width="6" height="8"/><rect x="70" y="58" width="6" height="8"/><rect x="44" y="38" width="12" height="5"/></g>' +
        '<g fill="#e0443a"><ellipse cx="13" cy="60" rx="3" ry="4"/><ellipse cx="87" cy="60" rx="3" ry="4"/></g>';
    } else if (c === 0) {
      o = sky(u, '#cfe6d4', '#f3e9d2') + '<ellipse cx="50" cy="70" rx="36" ry="6" fill="#7fb3c9"/><path d="M48 70c-2-14 0-28-6-40M50 46c8-6 14-10 20-10M46 40c-8-4-14-4-20 0" stroke="#5a3d2a" stroke-width="4" fill="none" stroke-linecap="round"/>' +
        '<g fill="#f2a6be"><circle cx="40" cy="26" r="10"/><circle cx="56" cy="22" r="11"/><circle cx="70" cy="32" r="9"/><circle cx="28" cy="36" r="8"/><circle cx="48" cy="34" r="8"/></g><g fill="#fff" opacity=".7"><circle cx="38" cy="22" r="2"/><circle cx="58" cy="18" r="2"/><circle cx="70" cy="30" r="1.6"/></g>';
    } else if (c === 1 && x === 0) {
      o = '<rect width="100" height="80" fill="#efe6d2"/><rect y="64" width="100" height="16" fill="#c9b897"/><path d="M36 12h28v6c14 6 20 18 20 30 0 16-14 24-34 24S16 64 16 48c0-12 6-24 20-30z" fill="#2f5fa8" stroke="#1a2f55" stroke-width="1.5"/>' +
        '<path d="M22 54c6-6 10 2 16-4s10 2 16-4 10 2 16-4 8 2 8 2" stroke="#f6f2e8" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M28 36c8-6 16 2 22-2s10-6 18 0" stroke="#e3ae45" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="69" cy="35" r="2.4" fill="#e3ae45"/>';
    } else if (c === 1) {
      o = '<rect width="100" height="80" fill="#efe6d2"/><rect y="66" width="100" height="14" fill="#c9b897"/><path d="M44 8h12v8c12 8 16 22 12 38l-5 14H37l-5-14c-4-16 0-30 12-38z" fill="#8fb8a6" stroke="#3a5a4a" stroke-width="1.5"/>' +
        '<g fill="#f6f2e8" opacity=".9"><ellipse cx="42" cy="30" rx="6" ry="3"/><ellipse cx="58" cy="54" rx="7" ry="3"/></g><path d="M40 46l10-6 9 2-6 2 4 6-8-2z" fill="#f6f2e8" stroke="#2b3d5c" stroke-width=".8"/><circle cx="50" cy="40" r="1.6" fill="#d23a2e"/>';
    } else if (c === 2 && x === 0) {
      o = gemBg(u) + '<path d="M14 14q36 40 72 0" stroke="#e3ae45" stroke-width="2.5" fill="none"/><path d="' + star(50, 46, 20) + '" fill="#3fb3c9" stroke="#0b3a46" stroke-width="1.5"/><path d="' + star(50, 46, 9) + '" fill="#bff0f6"/>';
    } else if (c === 2) {
      o = gemBg(u) + '<path d="M18 62l6-34 13 16 13-24 13 24 13-16 6 34z" fill="#f0c35a" stroke="#7a5418" stroke-width="1.5"/>' +
        ['#e0443a', '#ff9a4d', '#ffd36b', '#3fcf8e', '#4f8fdc', '#7a5ad0', '#f08fc0'].map((cl, i) => '<circle cx="' + (24 + i * 8.7).toFixed(1) + '" cy="54" r="3.4" fill="' + cl + '"/>').join('');
    } else if (c === 3 && x === 0) {
      o = '<rect width="100" height="80" fill="#3a2f45"/><path d="M30 62c-6-10-8-24-2-36 6-12 20-18 32-14 12 4 16 16 14 28-2 8-6 12-6 22z" fill="#cfc7b8"/>' +
        '<path d="M44 34c4-3 10-3 14 0M48 44c2 2 6 2 8 0M42 52c6 3 14 3 18 0" stroke="#8a8070" stroke-width="2" fill="none"/><circle cx="46" cy="38" r="2" fill="#6a6050"/><circle cx="58" cy="38" r="2" fill="#6a6050"/><path d="M28 30c4-12 18-18 30-14" stroke="#a8a091" stroke-width="4" fill="none"/>';
    } else {
      o = '<rect width="100" height="80" fill="#3a2f45"/><ellipse cx="50" cy="20" rx="40" ry="26" fill="#fff" opacity=".07"/>' +
        '<path d="M44 30c-14-12-30-10-36-2 10 0 20 4 26 12zM56 30c14-12 30-10 36-2-10 0-20 4-26 12z" fill="#e9e4da" stroke="#a8a091"/><circle cx="50" cy="18" r="6" fill="#e9e4da"/><path d="M44 26h12l4 34H40z" fill="#e9e4da"/><path d="M46 34l-2 24M54 34l2 24" stroke="#a8a091" stroke-width="1.2"/>';
    }
    if (c === 3) o += '<rect x="30" y="60" width="40" height="8" rx="1" fill="#d8d0c2"/><rect x="34" y="68" width="32" height="12" fill="#bdb3a3"/>';
    return o + GOLDF();
  }
  /* pairs: the half I hold, and a faint ghost of its missing partner on the other side */
  const PAIRC = [['#c96a8a', '#e9a6be'], ['#e3ae45', '#bcc6d6'], ['#d9704a', '#9c7a52'], ['#b9b0a0', '#b9b0a0'], ['#3f6fd0', '#d9443a']];
  const PSTK = ' stroke="#2a1d10" stroke-width="1.2"';
  function pairShape(g, sd) { // drawn on the left half (x ≈ 14..54)
    const c = PAIRC[g][sd];
    switch (g) {
      case 0: return '<path d="M20 66V40c0-3 4-3 4 0V26c0-3 5-3 5 0v-4c0-3 5-3 5 0v4c0-3 5-3 5 0v20l4-6c2-3 6-1 5 2l-7 14v10z" fill="' + c + '"' + PSTK + '/><path d="M20 60h22" stroke="#fff" stroke-width="2" opacity=".5"/>';
      case 1: return '<path d="M20 70h26l-4-6H24z" fill="' + c + '"' + PSTK + '/><path d="M33 64V40" stroke="' + c + '" stroke-width="4"/><path d="M24 40h18l-2 4H26z" fill="' + c + '"' + PSTK + '/><rect x="30" y="22" width="6" height="18" fill="#f4efe4"' + PSTK + '/><path d="M33 11c4 4 3 8 0 9-3-1-4-5 0-9z" fill="#ffb347"/>' +
        (sd ? '<path d="M37 55a5 5 0 1 1-5-5 3.8 3.8 0 0 0 5 5z" fill="#f4efe4"/>' : '<circle cx="33" cy="54" r="4" fill="#ffd36b" stroke="#8a5a14"/>');
      case 2: return '<rect x="14" y="62" width="34" height="4" rx="2" fill="#6b4a24"/><ellipse cx="30" cy="52" rx="16" ry="10" fill="' + c + '"' + PSTK + '/><circle cx="41" cy="38" r="7" fill="' + c + '"' + PSTK + '/><path d="M47 37l7 2-7 2z" fill="#e3ae45"/><circle cx="42" cy="37" r="1.4" fill="#111"/><path d="M15 50l-5-4v8z" fill="' + c + '"/>' +
        (sd ? '' : '<path d="M35 33c4-6 10-4 12 0" stroke="#3fb3c9" stroke-width="3" fill="none"/><path d="M22 48c4-4 10-4 12 2" stroke="#f4efe4" stroke-width="2" fill="none"/>');
      case 3: return '<rect x="12" y="64" width="38" height="7" fill="#8a8070"/><path d="M16 64V46c0-10 8-16 16-16s12 6 12 14v20z" fill="' + c + '"' + PSTK + '/><circle cx="38" cy="30" r="10" fill="' + c + '"' + PSTK + '/><path d="M36 21l3-9 4 8" fill="' + c + '"' + PSTK + '/>' +
        '<path d="M29 26c-4 0-6 6-2 8M43 34h6" stroke="#6a6050" stroke-width="2" fill="none"/><circle cx="41" cy="28" r="1.6" fill="#3a2f2a"/><path d="M22 52c4 2 8 2 12 0" stroke="#6a6050" stroke-width="1.5" fill="none"/>';
      default: return '<circle cx="32" cy="14" r="3" fill="none" stroke="' + c + '" stroke-width="2"/><path d="M32 17v6" stroke="' + c + '" stroke-width="2"/><path d="M26 28l6 6 6-6-6-6z" fill="' + c + '"' + PSTK + '/><circle cx="32" cy="42" r="5" fill="#e3ae45"' + PSTK + '/><path d="M32 47v4" stroke="' + c + '" stroke-width="2"/>' +
        '<path d="M26 51h12l3 21H23z" fill="' + c + '"/><path d="M28 53v17M32 53v19M36 53v17" stroke="#fff" stroke-width=".8" opacity=".5"/>';
    }
  }
  function pairArt(it) {
    const mir = (x) => '<g transform="translate(100 0) scale(-1 1)">' + x + '</g>';
    const me = pairShape(it.g, it.s), mate = pairShape(it.g, 1 - it.s);
    return '<rect width="100" height="80" fill="#2b3a40"/><ellipse cx="50" cy="74" rx="44" ry="5" fill="#1d282c"/><ellipse cx="50" cy="30" rx="40" ry="24" fill="#fff" opacity=".05"/>' +
      '<g opacity=".2">' + (it.s ? mate : mir(mate)) + '</g>' + (it.s ? mir(me) : me);
  }
  const BOOKC = ['#2f4f8f', '#b8572e', '#5a2f7a'];
  const BOOKE = [
    () => '<path d="' + star(50, 34, 9) + '" fill="#ffd36b"/><g fill="#ffd36b"><circle cx="39" cy="22" r="1.4"/><circle cx="61" cy="24" r="1.4"/><circle cx="60" cy="45" r="1.2"/></g>',
    () => '<path d="M38 32h24c0 8-5 12-12 12s-12-4-12-12z" fill="#f4efe4"/><path d="M36 32h28" stroke="#f4efe4" stroke-width="2"/><path d="M46 26c-2-3 2-4 0-7M54 26c-2-3 2-4 0-7" stroke="#f4efe4" stroke-width="1.4" fill="none"/>',
    () => '<circle cx="50" cy="34" r="11" fill="none" stroke="#c9b2f0" stroke-width="1.6"/><path d="M50 23l9.5 16.5h-19z" fill="none" stroke="#c9b2f0" stroke-width="1.6"/><circle cx="50" cy="34" r="2" fill="#ffd36b"/>',
  ];
  function bookArt(it) {
    const c = BOOKC[it.g];
    return '<rect width="100" height="80" fill="#2d2438"/><rect y="70" width="100" height="10" fill="#5a3d2a"/>' +
      '<rect x="12" y="20" width="14" height="50" rx="1" fill="' + c + '" opacity=".35"/><rect x="74" y="20" width="14" height="50" rx="1" fill="' + c + '" opacity=".35"/>' +
      '<rect x="30" y="10" width="40" height="60" rx="2" fill="' + c + '" stroke="#1a1424" stroke-width="1.5"/><rect x="30" y="10" width="5" height="60" fill="#000" opacity=".25"/><rect x="35" y="14" width="31" height="52" fill="none" stroke="#e3ae45" stroke-width="1" opacity=".8"/>' +
      BOOKE[it.g]() + '<circle cx="50" cy="57" r="7.5" fill="#e3ae45"/><text x="50" y="61.5" text-anchor="middle" font-size="12.5" font-weight="900" fill="#2a1d05" font-family="sans-serif">' + (it.s + 1) + '</text>';
  }
  const CHESTM = [['#8a5a35', '#4a3020'], ['#c3cad4', '#6a7380'], ['#e3ae45', '#8a5a14']];
  function chestArt(it) {
    const [b, d] = CHESTM[it.x];
    return '<rect width="100" height="80" fill="#2a2230"/><ellipse cx="50" cy="70" rx="36" ry="5" fill="#1a141e"/>' +
      '<path d="M20 40h60v28H20z" fill="' + b + '" stroke="' + d + '" stroke-width="2"/><path d="M20 40c0-14 12-20 30-20s30 6 30 20z" fill="' + b + '" stroke="' + d + '" stroke-width="2"/>' +
      '<path d="M32 22v46M68 22v46M20 46h60" stroke="' + d + '" stroke-width="3.5"/><rect x="44" y="40" width="12" height="13" rx="2" fill="#f0c35a" stroke="' + d + '" stroke-width="1.5"/><path d="M50 45v4" stroke="#2a1d05" stroke-width="2"/>' +
      (it.x === 2 ? '<path d="M80 12l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#fff" opacity=".9"/>' : '');
  }
  const KEYM = ['#b06a3a', '#c3cad4', '#f0c35a'];
  function keyArt(it) {
    const c = KEYM[it.x];
    const bow = [
      '<circle cx="30" cy="30" r="12" fill="none" stroke="' + c + '" stroke-width="6"/>',
      '<g fill="' + c + '"><circle cx="30" cy="20" r="7"/><circle cx="20" cy="30" r="7"/><circle cx="40" cy="30" r="7"/><circle cx="30" cy="38" r="5"/></g><circle cx="30" cy="29" r="3" fill="#2a2230"/>',
      '<path d="M18 40l2-20 6 8 4-11 4 11 6-8 2 20z" fill="' + c + '"/><circle cx="30" cy="32" r="3" fill="#e0443a"/>',
    ][it.x];
    return '<rect width="100" height="80" fill="#2a2230"/><ellipse cx="50" cy="40" rx="40" ry="26" fill="#fff" opacity=".04"/>' + bow +
      '<path d="M38 38l40 26" stroke="' + c + '" stroke-width="6" stroke-linecap="round"/><path d="M66 56l-5 8M74 61l-5 8" stroke="' + c + '" stroke-width="5"/>' +
      (it.x === 0 ? '<g fill="#7a3a1a" opacity=".7"><circle cx="52" cy="47" r="2.5"/><circle cx="62" cy="54" r="2"/><circle cx="24" cy="26" r="2"/></g>' : '');
  }
  const coin = (x, y, r, c) => '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + (c || '#f0c35a') + '" stroke="#8a5a14" stroke-width="1"/>';
  function moneyArt(it) {
    const bg = '<rect width="100" height="80" fill="#22301f"/><ellipse cx="50" cy="72" rx="38" ry="5" fill="#16200f"/>';
    switch (it.x) {
      case 0: return bg + '<path d="M34 34c-8 8-12 20-6 30 4 6 40 6 44 0 6-10 2-22-6-30z" fill="#8a7a6a" stroke="#4a3a2a" stroke-width="1.5"/><path d="M36 34h28l-4-6H40z" fill="#6a5a4a"/><path d="M36 31c4 2 24 2 28 0" stroke="#d9584a" stroke-width="2.5" fill="none"/>' +
        coin(76, 66, 5, '#d8dbe2') + coin(24, 68, 4, '#d8dbe2') + coin(50, 52, 6, '#d8dbe2');
      case 1: return bg + '<path d="M28 30c-6 10-8 24-2 34 4 6 44 6 48 0 6-10 4-24-2-34z" fill="#c9a87a" stroke="#6a5030" stroke-width="1.5"/><path d="M34 30l6-10h20l6 10z" fill="#b8956a"/><path d="M36 26h28" stroke="#6a5030" stroke-width="3"/>' +
        coin(50, 50, 9) + '<path d="M50 45v10M47 47h6M47 53h6" stroke="#8a5a14" stroke-width="1.5"/>' + coin(78, 66, 5) + coin(20, 66, 5);
      case 2: return bg + '<path d="M30 40c-4 8-4 18 2 26h36c6-8 6-18 2-26z" fill="#a0603a" stroke="#5a3010" stroke-width="1.5"/><path d="M34 40h32v-6H34z" fill="#8a4a2a"/>' +
        coin(40, 32, 6) + coin(52, 28, 7) + coin(62, 33, 6) + coin(46, 23, 5) + coin(58, 21, 5) + '<path d="M38 52c6 4 18 4 24 0" stroke="#e3ae45" stroke-width="2" fill="none"/>';
      case 3: return bg + '<rect x="24" y="18" width="52" height="48" rx="4" fill="#4a5560" stroke="#22282e" stroke-width="2"/><rect x="30" y="24" width="40" height="36" rx="3" fill="#5f6b78"/><circle cx="50" cy="42" r="10" fill="#c3cad4" stroke="#22282e" stroke-width="2"/>' +
        '<path d="M50 34v4M50 46v4M42 42h4M54 42h4" stroke="#22282e" stroke-width="2"/><path d="M62 30l6-2M62 54l6 2" stroke="#e3ae45" stroke-width="2.5"/><path d="M14 30c4-2 8 0 10 2" stroke="#e8e4dc" stroke-width="2" fill="none"/><circle cx="14" cy="28" r="3" fill="#e8e4dc"/>';
      default: return bg + [[28, 54], [52, 54], [40, 40], [64, 40]].map(([x, y]) => '<path d="M' + (x - 10) + ' ' + (y + 12) + 'l4-12h20l4 12z" fill="#f0c35a" stroke="#8a5a14" stroke-width="1.5"/><path d="M' + (x - 4) + ' ' + (y + 4) + 'h12" stroke="#fff3c4" stroke-width="1.5" opacity=".7"/>').join('') +
        '<path d="M82 16l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#fff"/>';
    }
  }
  function curseArt(it) {
    const bg = '<rect width="100" height="80" fill="#1e1428"/><g fill="none" stroke="#9a6ae0" stroke-width="2" opacity=".5" stroke-linecap="round"><path d="M12 70c6-10-4-16 4-26"/><path d="M88 66c-6-10 4-16-4-26"/></g>';
    switch (it.x) {
      case 0: return bg + '<path d="M28 18c14-8 30-8 44 0 2 22-6 40-22 46-16-6-24-24-22-46z" fill="#e9e4da" stroke="#5a3a7a" stroke-width="2"/><path d="M35 30l11 4-11 4zM65 30l-11 4 11 4z" fill="#1e1428"/><path d="M42 52c4-3 12-3 16 0" stroke="#5a3a7a" stroke-width="2.5" fill="none"/><path d="M30 22l-6-9M70 22l6-9" stroke="#9a6ae0" stroke-width="2"/>';
      case 1: return bg + '<path d="M38 46h24l6 22H32z" fill="#c96a8a" stroke="#5a3a7a" stroke-width="1.5"/><circle cx="50" cy="32" r="14" fill="#f2d2c0" stroke="#5a3a7a" stroke-width="1.5"/><path d="M36 30c0-14 28-14 28 0-4-6-24-6-28 0z" fill="#6a3a2a"/>' +
        '<circle cx="44" cy="32" r="2" fill="#1e1428"/><circle cx="56" cy="32" r="2" fill="#1e1428"/><path d="M44 35c-1 4 1 8-1 10" stroke="#7fc4ff" stroke-width="2" fill="none"/><path d="M46 41c2-1 6-1 8 0" stroke="#5a3a7a" stroke-width="1.5" fill="none"/>';
      case 2: return bg + '<ellipse cx="50" cy="40" rx="20" ry="27" fill="#8a6a3a" stroke="#4a3010" stroke-width="2"/><ellipse cx="50" cy="40" rx="15" ry="22" fill="#0a0810"/><path d="M42 26l6 10-4 6 8 8" stroke="#9a6ae0" stroke-width="1.5" fill="none"/><ellipse cx="45" cy="32" rx="3" ry="6" fill="#fff" opacity=".12"/>';
      default: return bg + '<circle cx="50" cy="46" r="16" fill="none" stroke="#c9b26b" stroke-width="5"/><path d="M38 36c-6-8 2-14 8-10 6 4 2 10 10 8" stroke="#3fae6a" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="57" cy="33" r="4" fill="#3fae6a"/><circle cx="58" cy="32" r="1" fill="#e0443a"/>';
    }
  }
  function charmArt(it) {
    const bg = '<rect width="100" height="80" fill="#3a1f1f"/><circle cx="50" cy="40" r="30" fill="#ffcf5a" opacity=".08"/>';
    if (it.x === 0) return bg + '<rect x="36" y="8" width="28" height="62" fill="#f2d66a" stroke="#8a6a1a" stroke-width="1.5"/><path d="M42 18c8 4 8 10 0 14s8 10 16 4M44 46h12M50 46v16M44 54l6 4 6-4" stroke="#c0392b" stroke-width="2.4" fill="none" stroke-linecap="round"/>';
    return bg + '<path d="M50 14v6" stroke="#c0392b" stroke-width="3"/><path d="M40 12c4 6 16 6 20 0" stroke="#c0392b" stroke-width="3" fill="none"/><path d="M34 54c0-20 6-32 16-32s16 12 16 32z" fill="#f0c35a" stroke="#8a5a14" stroke-width="2"/>' +
      '<path d="M30 54h40v5H30z" fill="#e3ae45" stroke="#8a5a14" stroke-width="1.5"/><circle cx="50" cy="63" r="4" fill="#8a5a14"/><path d="M40 36c2-6 6-8 8-8" stroke="#fff3c4" stroke-width="2" fill="none"/><path d="M50 64l-6 10M50 64l6 10" stroke="#c0392b" stroke-width="2.5"/>';
  }
  function propArt(it) {
    const c = COL[it.c].c, bg = '<rect width="100" height="80" fill="#2a2333"/><rect width="100" height="80" fill="' + c + '" opacity=".14"/>';
    switch (it.c) {
      case 0: return bg + '<rect x="18" y="12" width="64" height="52" fill="none" stroke="#e3ae45" stroke-width="8"/><rect x="13" y="7" width="74" height="62" fill="none" stroke="#9a6a14" stroke-width="1.5"/><g fill="#f0c35a"><circle cx="18" cy="12" r="4"/><circle cx="82" cy="12" r="4"/><circle cx="18" cy="64" r="4"/><circle cx="82" cy="64" r="4"/></g><rect x="24" y="18" width="52" height="40" fill="' + c + '" opacity=".25"/>';
      case 1: return bg + '<ellipse cx="50" cy="34" rx="26" ry="6" fill="#6b4a24"/><path d="M28 36c0 10 4 18 8 26M72 36c0 10-4 18-8 26M50 40v24" stroke="#6b4a24" stroke-width="4" fill="none" stroke-linecap="round"/><ellipse cx="50" cy="66" rx="18" ry="4" fill="#4a3018"/><ellipse cx="50" cy="31" rx="18" ry="3" fill="' + c + '" opacity=".6"/>';
      case 2: return bg + '<rect x="24" y="12" width="52" height="46" fill="#bfe7f0" opacity=".25" stroke="#d8f2f8" stroke-width="2"/><path d="M30 18l10 30M44 16l6 18" stroke="#fff" stroke-width="2" opacity=".5"/><rect x="18" y="58" width="64" height="12" fill="#6b4a24"/><rect x="18" y="58" width="64" height="3" fill="#e3ae45"/><path d="M42 50l8-10 8 10z" fill="' + c + '" opacity=".7"/>';
      default: return bg + '<rect x="30" y="16" width="40" height="8" fill="#e9e4da"/><rect x="34" y="24" width="32" height="38" fill="#d8d0c2"/><path d="M40 24v38M50 24v38M60 24v38" stroke="#b9b0a0" stroke-width="2"/><rect x="26" y="62" width="48" height="8" fill="#e9e4da"/><path d="M36 30l6 10-3 8" stroke="#a8a091" stroke-width="1" fill="none"/>';
    }
  }
  function mystArt(it) {
    const bg = '<rect width="100" height="80" fill="#13283a"/><g fill="#bfe7ff"><circle cx="12" cy="12" r="1"/><circle cx="86" cy="16" r="1.2"/><circle cx="78" cy="62" r="1"/><circle cx="18" cy="58" r="1"/></g>';
    switch (it.x) {
      case 0: return bg + '<path d="M22 52c4-10 20-10 30-8l18-10c4-2 8 2 4 6L60 52c-4 8-34 10-38 0z" fill="#f0c35a" stroke="#8a5a14" stroke-width="1.5"/><path d="M30 44c0-6 14-8 18-2" fill="#e3ae45" stroke="#8a5a14" stroke-width="1.2"/><path d="M24 50c-6 0-8-6-4-8" stroke="#8a5a14" stroke-width="2.5" fill="none"/>' +
        '<path d="M74 32c6-8 0-14 6-20s-2-10 4-12" stroke="#bfe7ff" stroke-width="2" fill="none" opacity=".6"/><rect x="30" y="58" width="24" height="5" rx="2" fill="#8a5a14"/>';
      case 1: return bg + '<rect x="30" y="34" width="40" height="34" rx="12" fill="#f4f1ea" stroke="#6a6050" stroke-width="1.5"/><path d="M68 42c6-6 8-14 6-22" stroke="#f4f1ea" stroke-width="7" stroke-linecap="round"/><circle cx="50" cy="30" r="16" fill="#f4f1ea" stroke="#6a6050" stroke-width="1.5"/><path d="M36 20l2-10 8 8M64 20l-2-10-8 8" fill="#f4f1ea" stroke="#6a6050" stroke-width="1.5"/>' +
        '<path d="M42 30c2-2 4-2 6 0M52 30c2-2 4-2 6 0" stroke="#2a1d05" stroke-width="1.6" fill="none"/><path d="M36 44h28" stroke="#d9443a" stroke-width="4"/><circle cx="50" cy="48" r="3.5" fill="#f0c35a"/><ellipse cx="50" cy="60" rx="8" ry="5" fill="#f0c35a" stroke="#8a5a14"/>';
      case 2: return bg + '<ellipse cx="46" cy="52" rx="22" ry="13" fill="#f0c35a" stroke="#8a5a14" stroke-width="1.5"/><path d="M62 46c6-6 4-16 10-20" stroke="#f0c35a" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="72" cy="24" r="6" fill="#f0c35a" stroke="#8a5a14" stroke-width="1.2"/><path d="M77 24l7 2-7 3z" fill="#e8823a"/><circle cx="73" cy="22" r="1.4" fill="#2a1d05"/>' +
        '<path d="M30 48c6 6 18 6 24 0" stroke="#8a5a14" stroke-width="1.5" fill="none"/><ellipse cx="22" cy="66" rx="6" ry="7.5" fill="#fff3c4" stroke="#e3ae45" stroke-width="1.5"/>';
      case 3: return bg + '<rect x="30" y="10" width="40" height="5" rx="2" fill="#8a5a2b"/><rect x="30" y="65" width="40" height="5" rx="2" fill="#8a5a2b"/><path d="M34 15h32c0 14-12 18-12 25s12 11 12 25H34c0-14 12-18 12-25S34 29 34 15z" fill="#bfe7ff" fill-opacity=".3" stroke="#d8f2f8" stroke-width="1.5"/>' +
        '<path d="M40 22h20c-2 6-8 9-10 13-2-4-8-7-10-13zM38 64c2-8 10-10 12-18 2 8 10 10 12 18z" fill="#f2d66a"/><path d="M50 36v10" stroke="#f2d66a" stroke-width="1.5" stroke-dasharray="1.5 2"/>';
      default: return bg + '<path d="M22 42l50-22 6 12-50 22z" fill="#8a5a2b" stroke="#4a3018" stroke-width="1.5"/><path d="M68 18l10 18" stroke="#e3ae45" stroke-width="5"/><ellipse cx="25" cy="48" rx="3" ry="6" fill="#bfe7ff" transform="rotate(-24 25 48)"/>' +
        '<path d="M48 42l-10 30M48 42l2 30M48 42l14 28" stroke="#6b4a24" stroke-width="3" stroke-linecap="round"/><circle cx="86" cy="14" r="4" fill="#fff3c4"/>';
    }
  }
  function art(id) {
    const it = item(id), u = 'au' + (++uid);
    if (it.k === 'b') return birdArt(it.x);
    if (it.k === 'f') return fakeArt(it.x);
    const sp = { p: pairArt, k: bookArt, h: chestArt, y: keyArt, m: moneyArt, x: curseArt, a: charmArt, z: mystArt }[it.k];
    if (sp) return sp(it);
    if (it.pr) return propArt(it);
    if (it.mp) return masterArt(it.c, it.x, u);
    const t = it.t, k = it.x;
    if (it.c === 0) {
      if (k === 0) return paintOld(t, u);
      const p = PAINT[t * 2 + k - 1];
      return sky(u, p[0], p[1]) + (p[2] || city());
    }
    if (it.c === 1) return '<rect width="100" height="80" fill="#efe6d2"/><rect y="62" width="100" height="18" fill="#c9b897"/>' + CERA[t][k];
    if (it.c === 2) {
      let g = GEMS[t][k];
      if (typeof g === 'function') g = g();
      return '<defs><radialGradient id="' + u + '"><stop offset="0" stop-color="#2d4a3e"/><stop offset="1" stop-color="#0f1d18"/></radialGradient></defs>' +
        '<rect width="100" height="80" fill="url(#' + u + ')"/>' + g.replace(/GEM/g, GEMC[(t + k * 2) % 5]) +
        '<path d="M74 18l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#fff" opacity=".85"/><path d="M24 22l1 3 3 1-3 1-1 3-1-3-3-1 3-1z" fill="#fff" opacity=".6"/>';
    }
    const [m, fig] = SCUL[t][k];
    return '<rect width="100" height="80" fill="#3a2f45"/><ellipse cx="50" cy="20" rx="40" ry="26" fill="#fff" opacity=".07"/>' + fig.replace(/="M"/g, '="' + m + '"') +
      '<rect x="30" y="60" width="40" height="8" rx="1" fill="#d8d0c2"/><rect x="34" y="68" width="32" height="12" fill="#bdb3a3"/>';
  }
  /* event card icons (40×40, currentColor) */
  const CICON = [
    '<path d="M4 20c5-8 11-12 16-12s11 4 16 12c-5 8-11 12-16 12S9 28 4 20z" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="20" cy="20" r="5" fill="currentColor"/>',
    '<path d="M10 36V5M10 6h20l-5 7 5 7H10" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>',
    '<circle cx="16" cy="23" r="10" fill="none" stroke="currentColor" stroke-width="3"/><path d="M16 18v10M30 4v12M24 10h12" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    '<path d="M4 10h32v7a3 3 0 000 6v7H4v-7a3 3 0 000-6z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M14 26l12-12" stroke="currentColor" stroke-width="3"/><circle cx="15" cy="15" r="2.5" fill="currentColor"/><circle cx="25" cy="25" r="2.5" fill="currentColor"/>',
    '<path d="M20 4l13 5v10c0 9-6 15-13 18C13 34 7 28 7 19V9z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M14 20l4 4 8-8" fill="none" stroke="currentColor" stroke-width="3"/>',
    '<rect x="6" y="17" width="28" height="18" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M4 11h32v6H4zM20 11v24" fill="none" stroke="currentColor" stroke-width="3"/><path d="M20 11c-4-8-12-4-8 0M20 11c4-8 12-4 8 0" fill="none" stroke="currentColor" stroke-width="2.5"/>',
    '<circle cx="20" cy="15" r="10" fill="none" stroke="currentColor" stroke-width="3"/><path d="M13 23l-3 14 10-5 10 5-3-14" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M16 15l3 3 5-6" fill="none" stroke="currentColor" stroke-width="2.5"/>',
    '<path d="M4 14h20c6 0 6-8 0-8M4 22h26c6 0 6 8 0 8M4 30h12" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    '<circle cx="20" cy="20" r="15" fill="none" stroke="currentColor" stroke-width="3.5"/><path d="M9 20h22" stroke="currentColor" stroke-width="5"/>',
    '<path d="M12 15h16l4 20H8z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M15 15c0-6 10-6 10 0" fill="none" stroke="currentColor" stroke-width="3"/><path d="M34 3l-7 7M34 3h-6M34 3v6" stroke="currentColor" stroke-width="2.5" fill="none"/>',
    '<rect x="6" y="17" width="28" height="18" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M14 23h12" stroke="currentColor" stroke-width="3"/><circle cx="20" cy="9" r="5" fill="currentColor"/>',
    '<path d="M6 13h26l-6-6M34 27H8l6 6" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<circle cx="17" cy="17" r="10" fill="none" stroke="currentColor" stroke-width="3.5"/><path d="M25 25l10 10" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>',
    '<path d="M4 14L20 5l16 9zM6 34h28M9 17v13M16 17v13M24 17v13M31 17v13" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>',
    '<path d="M6 24l10-10 6 6-10 10z" fill="currentColor"/><path d="M19 17l12 12" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M4 36h16" stroke="currentColor" stroke-width="3"/><path d="M27 4l8 8M35 4l-8 8" stroke="currentColor" stroke-width="3"/>',
    // ---- 15..44 ----
    '<path d="M8 5h17l7 7v23H8z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M13 12h8M13 17h13" stroke="currentColor" stroke-width="2.5"/><path d="M12 27c3-4 5-5 8-5s5 1 8 5c-3 4-5 5-8 5s-5-1-8-5z" fill="currentColor"/>',
    '<path d="M12 17a9 9 0 0118 0c0 6-6 8-6 13a5 5 0 01-9 2" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M17 17a4 4 0 018 0c0 2-2 3-3 4" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><path d="M5 12c-2 4-2 8 0 12M35 9c2 3 2 6 1 9" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    '<circle cx="20" cy="17" r="12" fill="none" stroke="currentColor" stroke-width="3"/><path d="M9 37h22l-3-7H12z" fill="currentColor"/><path d="M13 14a8 8 0 016-6" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M23 16l1.5 3 3 1.5-3 1.5-1.5 3-1.5-3-3-1.5 3-1.5z" fill="currentColor"/>',
    '<path d="M5 15h7l15-9v27l-15-9H5z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M10 24l3 10h5l-2-9" fill="currentColor"/><path d="M32 13c2.5 3 2.5 9 0 12M35 9c4 5 4 15 0 20" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    '<path d="M4 6h32" stroke="currentColor" stroke-width="4.5" stroke-linecap="round"/><path d="M20 35V13M12 21l8-8 8 8" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M4 25h32" stroke="currentColor" stroke-width="3" stroke-dasharray="4 3"/><circle cx="11" cy="32" r="3.5" fill="currentColor" opacity=".55"/><circle cx="29" cy="32" r="3.5" fill="currentColor" opacity=".55"/><path d="M20 21V4M13 11l7-7 7 7" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M12 3l5 9M28 3l-5 9" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="20" cy="24" r="12" fill="none" stroke="currentColor" stroke-width="3"/><path d="M15.5 21a4.5 4.5 0 019 0c0 3.5-9 6-9 9.5h9" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M8 20a12 12 0 0120-9M32 20a12 12 0 01-20 9" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M29 4v8h-8M11 36v-8h8" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<rect x="6" y="6" width="28" height="28" rx="6" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="13.5" cy="13.5" r="2.8" fill="currentColor"/><circle cx="20" cy="20" r="2.8" fill="currentColor"/><circle cx="26.5" cy="26.5" r="2.8" fill="currentColor"/><circle cx="26.5" cy="13.5" r="2.8" fill="currentColor"/><circle cx="13.5" cy="26.5" r="2.8" fill="currentColor"/>',
    '<path d="M11 4c13 6 13 26 0 32" fill="none" stroke="currentColor" stroke-width="3"/><path d="M11 4v32" stroke="currentColor" stroke-width="1.5"/><path d="M4 20h30M29 15l6 5-6 5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 20l-1-4M4 20l-1 4" stroke="currentColor" stroke-width="2"/>',
    '<path d="M8 34V25M16 34V19M24 34V13M32 34V7" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><path d="M5 37h30" stroke="currentColor" stroke-width="2"/>',
    '<ellipse cx="19" cy="22" rx="13" ry="10" fill="none" stroke="currentColor" stroke-width="3"/><path d="M31 18l5-2v8l-4 1" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round"/><path d="M12 31v5M25 31v5" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M15 9h8" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="26" cy="19" r="1.8" fill="currentColor"/>',
    '<path d="M14 12c-9 6-11 23 6 23s15-17 6-23z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M14 12l-3-6h18l-3 6z" fill="currentColor"/><path d="M20 19v11M14.5 24.5h11" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    '<rect x="4" y="11" width="14" height="20" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><rect x="22" y="11" width="14" height="20" rx="2" fill="currentColor" opacity=".4" stroke="currentColor" stroke-width="3"/><path d="M9 7c3-4 18-4 21 0M31 35c-3 4-18 4-21 0" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><path d="M27 4l3 3-4 2M13 38l-3-3 4-2" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    '<path d="M4 21L19 6h14v14L18 35z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="27" cy="13" r="3" fill="currentColor"/><path d="M14 22l6 6M17 19l6 6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>',
    '<rect x="3" y="12" width="17" height="17" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M9 18c0-3.5 5.5-3.5 5.5 0 0 2-2.7 2.2-2.7 4.4M11.8 25.5v.5" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M23 20h13M30 13l7 7-7 7" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M3 14c6-4 28-4 34 0-1 8-6 11-11 9-3-1-4-4-6-4s-3 3-6 4c-5 2-10-1-11-9z" fill="currentColor"/><circle cx="12" cy="15.5" r="2.8" fill="#1d1628"/><circle cx="28" cy="15.5" r="2.8" fill="#1d1628"/><path d="M27 27a6 6 0 1 0 8 8a5 5 0 0 1-8-8z" fill="currentColor"/>',
    '<path d="' + star(20, 21, 17) + '" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="20" cy="22" r="4.5" fill="currentColor"/>',
    '<rect x="8" y="18" width="24" height="18" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M13 18v-5a7 7 0 0114 0v5" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="20" cy="26" r="3" fill="currentColor"/><path d="M20 28v4" stroke="currentColor" stroke-width="2.5"/>',
    '<path d="M15 4h10v9l7 5v6H8v-6l7-5z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M5 29h30v6H5z" fill="currentColor"/><path d="M20 15v6M17 18h6" stroke="currentColor" stroke-width="2.4"/>',
    '<rect x="5" y="9" width="17" height="24" rx="3" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(-10 13 21)"/><path d="M13 17l1.5 3 3 .5-2.2 2 .5 3-2.8-1.4-2.8 1.4.5-3-2.2-2 3-.5z" fill="currentColor"/><path d="M36 9c-6 0-9 4-9 9v6M23 20l4 5 4-5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M11 5h18v9a9 9 0 01-18 0z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M11 8H5c0 6 3 8 6 8M29 8h6c0 6-3 8-6 8" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M20 23v6" stroke="currentColor" stroke-width="3"/><path d="M12 36h16l-2-6H14z" fill="currentColor"/>',
    '<path d="M29 3l8 8-15 15-8-8z" fill="currentColor"/><path d="M14 19c-7 0-10 4-10 9 0 3-1 5-2 7 8 1 16-1 17-9" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>',
    '<circle cx="11" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="11" cy="28" r="7" fill="none" stroke="currentColor" stroke-width="3"/><path d="M17 20h18M30 15v10" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>',
    '<rect x="5" y="8" width="30" height="27" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M5 15h30M12 4v7M28 4v7" stroke="currentColor" stroke-width="3"/><path d="M20 19v12M14 25h12" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>',
    '<rect x="5" y="8" width="30" height="27" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M5 15h30M12 4v7M28 4v7" stroke="currentColor" stroke-width="3"/><path d="M14 25h12" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>',
    '<rect x="3" y="10" width="25" height="18" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M3 12l12.5 9L28 12" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="30" cy="28" r="8" fill="currentColor"/><path d="M30 24v8" stroke="#1d1628" stroke-width="2.4"/>',
    '<rect x="5" y="5" width="30" height="24" rx="1" fill="none" stroke="currentColor" stroke-width="3"/><path d="M12 17l6 6 10-11" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M11 35h18" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    '<circle cx="15" cy="25" r="11" fill="none" stroke="currentColor" stroke-width="3"/><path d="M15 19v12M11.5 22h6M11.5 28h6" stroke="currentColor" stroke-width="2.4"/><path d="M32 34V5M26 11l6-6 6 6" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<rect x="4" y="12" width="14" height="22" rx="2" fill="currentColor" opacity=".4" stroke="currentColor" stroke-width="3"/><rect x="22" y="12" width="14" height="22" rx="2" fill="currentColor" opacity=".4" stroke="currentColor" stroke-width="3"/><path d="M20 2l1.6 3.4L25 7l-3.4 1.6L20 12l-1.6-3.4L15 7l3.4-1.6z" fill="currentColor"/>',
    // ---- 45..86 ----
    '<path d="M5 7h10v8h8v8h8" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linejoin="round"/><path d="M26 29l5 7 5-7z" fill="currentColor"/><path d="M31 23v7" stroke="currentColor" stroke-width="3"/><circle cx="11" cy="30" r="6" fill="none" stroke="currentColor" stroke-width="3"/>',
    '<rect x="3" y="7" width="22" height="15" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M3 8l11 8 11-8" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="15" y="19" width="22" height="15" rx="2" fill="currentColor" fill-opacity=".35" stroke="currentColor" stroke-width="3"/><path d="M15 20l11 8 11-8" fill="none" stroke="currentColor" stroke-width="2.5"/>',
    '<circle cx="10" cy="9" r="4.5" fill="currentColor"/><circle cx="20" cy="6" r="4.5" fill="currentColor"/><circle cx="30" cy="9" r="4.5" fill="currentColor"/><path d="M5 19h30l-4 17H9z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M14 26h12" stroke="currentColor" stroke-width="3"/>',
    '<path d="M9 34V18M20 34V8M31 34V24" stroke="currentColor" stroke-width="6" stroke-linecap="round"/><path d="M3 21h34" stroke="currentColor" stroke-width="2.5" stroke-dasharray="4 3"/>',
    '<path d="M5 17L20 6l15 11v18H5z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M5 17l15 10 15-10" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="20" cy="13" r="2.6" fill="currentColor"/>',
    '<rect x="8" y="5" width="24" height="31" rx="4" fill="currentColor" fill-opacity=".3" stroke="currentColor" stroke-width="3"/><path d="M15 15a5 5 0 0110 0c0 4-5 4-5 8M20 28v1" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/>',
    '<circle cx="14" cy="20" r="10" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="26" cy="20" r="10" fill="currentColor" fill-opacity=".35" stroke="currentColor" stroke-width="3"/><path d="M20 15v10M15 20h10" stroke="currentColor" stroke-width="2.6"/>',
    '<path d="M11 14h18v-9H11zM6 14h28" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="20" cy="25" r="8" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="23" cy="24" r="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M26 27l3 9" stroke="currentColor" stroke-width="2"/>',
    '<path d="M20 4l17 31H3z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M20 14v10" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><circle cx="20" cy="29.5" r="2.2" fill="currentColor"/>',
    '<circle cx="16" cy="17" r="11" fill="none" stroke="currentColor" stroke-width="3"/><path d="M11 17h10" stroke="currentColor" stroke-width="3.5"/><path d="M31 21v15M26 31l5 5 5-5" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>',
    '<rect x="5" y="4" width="18" height="26" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><rect x="20" y="22" width="16" height="13" rx="2" fill="currentColor"/><path d="M23.5 22v-4a4.5 4.5 0 019 0v4" fill="none" stroke="currentColor" stroke-width="2.6"/>',
    '<path d="M31 9a14 14 0 1 0 4 11" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/><path d="M36 3v8h-8" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/><rect x="14" y="13" width="12" height="15" rx="2" fill="currentColor" fill-opacity=".45" stroke="currentColor" stroke-width="2.2"/>',
    '<rect x="13" y="4" width="18" height="10" rx="2" fill="currentColor" transform="rotate(-35 22 9)"/><path d="M17 15L6 31" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M18 36h18" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>',
    '<path d="M8 33L32 7" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><circle cx="11" cy="11" r="5" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="29" cy="29" r="5" fill="none" stroke="currentColor" stroke-width="3"/>',
    '<circle cx="20" cy="30" r="7" fill="none" stroke="currentColor" stroke-width="3"/><path d="M20 23V13" stroke="currentColor" stroke-width="3"/><path d="M20 16c-7 0-10-4-10-9 7 0 10 4 10 9zM20 13c6 0 9-3 9-8-6 0-9 3-9 8z" fill="currentColor"/>',
    '<path d="M4 18L20 5l16 13" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M8 16v19h24V16" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="20" cy="25" r="5.5" fill="currentColor"/>',
    '<circle cx="18" cy="20" r="13" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="14" cy="16" r="3" fill="currentColor"/><circle cx="22" cy="24" r="3" fill="currentColor"/><circle cx="12" cy="25" r="2.4" fill="currentColor"/><path d="M31 16h6v10" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    '<path d="M6 34l12-18 4 4 6-14" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="31" cy="30" r="6" fill="currentColor"/><path d="M24 6h8v8" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    '<circle cx="20" cy="20" r="15" fill="none" stroke="currentColor" stroke-width="3"/><path d="M20 5a15 15 0 0 1 0 30z" fill="currentColor" fill-opacity=".45"/><path d="M20 5v30" stroke="currentColor" stroke-width="2.5"/>',
    '<circle cx="11" cy="20" r="7" fill="currentColor"/><path d="M20 13h14M29 8l5 5-5 5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M36 27H22M27 22l-5 5 5 5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M3 7h6l4 19h18l4-13H11" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="15" cy="33" r="3" fill="currentColor"/><circle cx="29" cy="33" r="3" fill="currentColor"/>',
    '<rect x="17" y="18" width="18" height="17" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M17 24h18" stroke="currentColor" stroke-width="2.5"/><path d="M12 30H8a5 5 0 01-5-5V12a5 5 0 015-5h12M15 3l5 4-5 4" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
    '<rect x="5" y="5" width="30" height="30" rx="2" fill="none" stroke="currentColor" stroke-width="4"/><rect x="12" y="12" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-dasharray="3 2"/><path d="M20 16v8M16 20h8" stroke="currentColor" stroke-width="2.5"/>',
    '<path d="M7 4h18l7 7v25H7z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M12 13h10M12 19h14M12 25h8" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><circle cx="29" cy="31" r="3.5" fill="currentColor"/>',
    '<path d="M11 35V7M5 13l6-6 6 6" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M29 5v28M23 27l6 6 6-6" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>',
    '<circle cx="20" cy="20" r="15" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="20" cy="20" r="8.5" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="20" cy="20" r="3" fill="currentColor"/>',
    '<rect x="4" y="4" width="14" height="14" rx="2" fill="currentColor"/><rect x="22" y="4" width="14" height="14" rx="7" fill="none" stroke="currentColor" stroke-width="3"/><path d="M11 22l7 13H4z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M29 22l7 7-7 7-7-7z" fill="currentColor" fill-opacity=".45" stroke="currentColor" stroke-width="2.5"/>',
    '<path d="M12 34C4 28 3 16 9 7M28 34c8-6 9-18 3-27" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><g fill="currentColor"><ellipse cx="6" cy="22" rx="2.4" ry="4"/><ellipse cx="34" cy="22" rx="2.4" ry="4"/><ellipse cx="8" cy="13" rx="2.2" ry="3.6"/><ellipse cx="32" cy="13" rx="2.2" ry="3.6"/></g><path d="' + star(20, 21, 7) + '" fill="currentColor"/>',
    '<path d="M6 10h28M12 10V4h16v6" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M9 15h22l-2 21H11z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M20 4v18" stroke="currentColor" stroke-width="2"/><path d="M15 24h10v6H15z" fill="currentColor"/>',
    '<path d="M4 33l10-10 7 6 14-17" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M26 12h9v9" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M4 9l10 10 7-6 14 17" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M26 30h9v-9" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
    '<circle cx="20" cy="20" r="15" fill="none" stroke="currentColor" stroke-width="3"/><path d="M22 4l-5 9 6 5-6 6 4 11" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>',
    '<rect x="3" y="11" width="10" height="18" rx="1" fill="none" stroke="currentColor" stroke-width="2.6"/><rect x="15" y="7" width="10" height="26" rx="1" fill="currentColor" fill-opacity=".4" stroke="currentColor" stroke-width="2.6"/><rect x="27" y="11" width="10" height="18" rx="1" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M8 36h24" stroke="currentColor" stroke-width="2.5"/>',
    '<path d="M3 23c7-1 11-8 18-9 6-1 11 3 14 7-4 0-7 2-9 6-7 7-17 6-23-4z" fill="currentColor"/><circle cx="29" cy="18" r="1.6" fill="#1d1628"/><circle cx="31" cy="7" r="4" fill="none" stroke="currentColor" stroke-width="2.4"/>',
    '<circle cx="20" cy="20" r="15" fill="none" stroke="currentColor" stroke-width="3" stroke-dasharray="5 3"/><path d="M12 20l6 6 10-12" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>',
    '<path d="M8 14h24l-2 22H10z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M14 18v-6a6 6 0 0112 0v6" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="20" cy="26" r="3.5" fill="currentColor"/>',
    '<rect x="6" y="15" width="28" height="20" fill="none" stroke="currentColor" stroke-width="3"/><path d="M6 21h28M20 15v20" stroke="currentColor" stroke-width="2.6"/><path d="M13 6l7 9 7-9" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M28 24l-4 4 4 4" fill="none" stroke="currentColor" stroke-width="2.4"/>',
    '<path d="M10 5h22v26a5 5 0 01-5 5H8a5 5 0 005-5V9a4 4 0 00-4-4z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M17 13h10M17 19h10M17 25h6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
    '<circle cx="20" cy="23" r="13" fill="none" stroke="currentColor" stroke-width="3"/><path d="M20 23v-8M20 23l5 4" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M15 4h10M20 4v6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    '<path d="M23 3L8 22h11l-4 15 17-21H21z" fill="currentColor"/>',
    '<path d="M7 7l24 24M33 7L9 31" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M4 28l8 8M28 36l8-8" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>',
    '<rect x="7" y="4" width="26" height="32" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M15 11h11l-7 9 7 9H15" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>',
  ];
  /* ---------- view ---------- */
  const CSS = `
.au{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(ellipse at 50% 38%,#43213a 0%,#24172c 55%,#140f1a 100%);overflow:hidden}
.au-top{display:grid;gap:5px;padding:6px 8px 0;flex:none}
.au-p{appearance:none;font:inherit;color:var(--ink);text-align:left;border:1px solid var(--line);background:rgba(34,28,46,.88);border-radius:12px;padding:5px 7px;min-height:48px;display:flex;flex-direction:column;gap:2px;min-width:0;cursor:pointer;transition:border-color .2s,box-shadow .2s}
.au-p .r1{display:flex;align-items:center;gap:4px;font-size:11.5px;font-weight:700;min-width:0}
.au-p .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1 1 auto;min-width:0}
.au-p .r2{display:flex;align-items:center;justify-content:space-between;gap:4px}
.au-p .co{font-family:var(--f-mono);font-weight:600;font-size:13px;color:var(--brass);display:flex;align-items:center;gap:3px}
.au-p .pt{font-family:var(--f-mono);font-size:11px;color:var(--muted)}
.au-p .pips{display:flex;gap:2px;flex-wrap:wrap;min-height:6px}
.au-p .pips i{width:7px;height:7px;border-radius:2px;display:block}
.au-p .st{font-size:12px;font-weight:800;flex:none;width:12px;text-align:center}
.au-coin{width:10px;height:10px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#ffe7a3,#e3ae45 55%,#9a6a14);display:inline-block;flex:none;box-shadow:0 0 0 1px rgba(0,0,0,.25)}
.au-mid{flex:1 1 auto;min-height:0;position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;padding:4px 10px}
.au-head{display:flex;align-items:center;gap:6px;width:100%;justify-content:space-between;font-size:12px;color:var(--muted);font-weight:700}
.au-head .rd{font-family:var(--f-mono);color:var(--ink)}
.au-head .btn{min-height:34px;padding:4px 10px;font-size:12px}
.au-table{position:relative;flex:1 1 auto;min-height:0;width:100%;display:flex;align-items:center;justify-content:center}
.au-table:before{content:"";position:absolute;left:6%;right:6%;bottom:2%;height:30%;border-radius:50%;background:radial-gradient(ellipse at 50% 40%,#7a2b3a 0%,#4a1c2a 60%,transparent 72%);opacity:.85}
.au-spot{position:absolute;left:50%;top:-30%;width:120%;height:140%;transform:translateX(-50%);background:radial-gradient(ellipse at 50% 30%,rgba(255,236,190,.16),rgba(255,236,190,0) 60%);pointer-events:none}
.au-lot{position:relative;display:flex;gap:8px;align-items:flex-end;justify-content:center;max-height:100%}
.au-card{position:relative;background:linear-gradient(#f6eedc,#e9dcc0);color:#2a1d05;border-radius:12px;padding:6px 6px 7px;box-shadow:0 12px 28px rgba(0,0,0,.5),0 0 0 1px rgba(0,0,0,.2);display:flex;flex-direction:column;gap:4px;animation:auIn .45s cubic-bezier(.2,.9,.3,1.2)}
.au-card .fr{border-radius:6px;border:5px solid #6b4a24;box-shadow:inset 0 0 0 2px #e3ae45;overflow:hidden;line-height:0;background:#000}
.au-card svg{display:block;width:100%;height:auto}
.au-card .nm{font-family:var(--f-display);font-size:16px;line-height:1.1;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.au-card .meta{display:flex;justify-content:space-between;align-items:center;gap:4px;font-size:11px;font-weight:700}
.au-card .tagc{color:#fff;border-radius:999px;padding:1px 7px;font-size:10.5px}
.au-card .val{font-family:var(--f-mono);font-size:15px;font-weight:700}
.au-badge{position:absolute;top:-10px;left:50%;transform:translateX(-50%);white-space:nowrap;background:var(--coral);color:#2b0c06;font-weight:800;font-size:11.5px;border-radius:999px;padding:3px 10px;box-shadow:0 4px 10px rgba(0,0,0,.4)}
.au-mode{font-size:12px;color:var(--ink);text-align:center;background:rgba(18,14,24,.7);border:1px solid var(--line);border-radius:999px;padding:4px 12px;max-width:100%}
.au-mode b{color:var(--brass)}
.au-bot{flex:none;padding:8px 10px 10px;background:linear-gradient(rgba(23,19,31,0),rgba(23,19,31,.92) 18%);display:flex;flex-direction:column;gap:7px}
.au-info{display:flex;justify-content:space-between;align-items:baseline;gap:8px;font-size:12px;color:var(--muted);font-weight:700}
.au-info b{font-family:var(--f-mono);color:var(--ink);font-size:13px}
.au-amt{display:flex;align-items:center;gap:8px}
.au-amt .btn{width:56px;min-height:52px;font-size:24px;padding:0;flex:none}
.au-amt .v{flex:1;text-align:center;font-family:var(--f-mono);font-size:38px;font-weight:600;line-height:1;color:var(--brass);display:flex;align-items:baseline;justify-content:center;gap:6px}
.au-amt .v small{font-family:var(--f-body);font-size:13px;color:var(--muted);font-weight:700}
.au-range{width:100%;accent-color:var(--brass);height:28px;margin:0}
.au-chips{display:grid;grid-template-columns:repeat(5,1fr);gap:6px}
.au-chips .btn{min-height:40px;padding:4px 0;font-size:13px}
.au-go{min-height:52px;font-size:16px;width:100%}
.au-wait{display:flex;flex-direction:column;gap:6px;align-items:stretch}
.au-wait .ln{display:flex;align-items:center;justify-content:center;gap:8px;font-size:13px;font-weight:700;color:var(--ink);min-height:24px}
.au-wait .mine{font-family:var(--f-mono);color:var(--brass)}
.au-sts{display:flex;gap:6px;justify-content:center;flex-wrap:wrap}
.au-sts>span{display:inline-flex;align-items:center;gap:4px;font-size:11.5px;font-weight:700;border:1px solid var(--line);border-radius:999px;padding:3px 8px;background:rgba(34,28,46,.8)}
.au-dots:after{content:"…";animation:auDots 1.2s infinite}
.au-rev{position:absolute;inset:0;z-index:12;background:rgba(10,8,15,.8);backdrop-filter:blur(2px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:12px;animation:fade .2s}
.au-rev h3{font-family:var(--f-display);font-weight:400;font-size:22px;margin:0;text-align:center;color:var(--ink)}
.au-rev .sub{font-size:12px;color:var(--muted);font-weight:700;text-align:center}
.au-grid{display:grid;gap:8px;justify-content:center}
.au-flip{perspective:700px;width:92px;height:104px}
.au-fi{position:relative;width:100%;height:100%;transform-style:preserve-3d;transition-property:transform;transition-timing-function:cubic-bezier(.3,1.3,.5,1)}
.au-flip.on .au-fi{transform:rotateY(180deg)}
.au-face{position:absolute;inset:0;backface-visibility:hidden;-webkit-backface-visibility:hidden;border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;box-shadow:0 6px 16px rgba(0,0,0,.45)}
.au-back{border:3px solid rgba(255,255,255,.75);font-family:var(--f-display);font-size:30px;color:rgba(255,255,255,.85)}
.au-front{transform:rotateY(180deg);background:linear-gradient(#f6eedc,#e6d6b6);color:#2a1d05;border:3px solid var(--c)}
.au-front .who{font-size:11.5px;font-weight:800;max-width:84px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.au-front .amt{font-family:var(--f-mono);font-size:28px;font-weight:700;line-height:1}
.au-front .amt small{font-size:11px}
.au-flip.win .au-front{box-shadow:0 0 0 3px var(--brass),0 0 26px rgba(227,174,69,.75);animation:auPop .5s}
.au-flip.lose{opacity:.5;transition:opacity .3s}
.au-stamp{position:absolute;right:-8px;top:-10px;background:var(--brass);color:var(--brass-ink);font-weight:900;font-size:11px;padding:3px 7px;border-radius:7px;transform:rotate(10deg);box-shadow:0 3px 8px rgba(0,0,0,.4)}
.au-stamp.bad{background:var(--coral);color:#2b0c06}
.au-res{font-size:15px;font-weight:800;text-align:center;min-height:22px;color:var(--ink)}
.au-res .mono{color:var(--brass)}
.au-skip{font-size:11px;color:var(--muted)}
.au-hand{position:absolute;inset:0;z-index:14;background:rgba(10,8,15,.97);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:20px}
.au-hand .big{font-family:var(--f-display);font-size:34px}
.au-ov{position:absolute;inset:0;z-index:16;display:flex;align-items:flex-end;justify-content:center;padding:10px;background:rgba(10,8,15,.6);animation:fade .15s}
.au-ov .sheet{gap:10px;max-height:86%;padding:16px}
.au-hl{display:flex;flex-direction:column;gap:5px;font-size:12.5px}
.au-hl .row{display:flex;align-items:center;gap:7px;padding:5px 7px;border-radius:9px;background:var(--bg);flex-wrap:nowrap}
.au-hl .sw{width:8px;height:22px;border-radius:2px;flex:none}
.au-hl .t{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.au-hl .m{font-family:var(--f-mono);flex:none}
.au-hl .all{font-family:var(--f-mono);font-size:10.5px;color:var(--muted);flex:none}
.au-col{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:6px}
.au-mini{background:#efe5cf;color:#2a1d05;border-radius:8px;padding:3px;display:flex;flex-direction:column;gap:2px;font-size:10px;font-weight:700;border-top:4px solid var(--c)}
.au-mini svg{width:100%;height:auto;display:block;border-radius:4px}
.au-mini .nmm{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.au-bd{display:grid;grid-template-columns:1fr auto;gap:3px 10px;font-size:12.5px}
.au-bd span:nth-child(2n){font-family:var(--f-mono);text-align:right}
@keyframes auIn{from{transform:translateY(-30px) scale(.85);opacity:0}to{transform:none;opacity:1}}
@keyframes auPop{0%{transform:rotateY(180deg) scale(1)}40%{transform:rotateY(180deg) scale(1.12)}100%{transform:rotateY(180deg) scale(1)}}
@keyframes auDots{0%{opacity:.2}50%{opacity:1}100%{opacity:.2}}
.au-p .cd{display:inline-flex;align-items:center;gap:2px;font-family:var(--f-mono);font-size:10.5px;font-weight:700;color:#e6d6ff;background:rgba(167,125,224,.28);border-radius:5px;padding:0 4px;line-height:15px;flex:none}
.au-p .cd i{width:6px;height:9px;border-radius:1.5px;background:#b994ec;display:block}
.au-p.out{opacity:.55}
.au-p .pips i.cf{box-shadow:0 0 0 1.5px #ffe7a3}
.au-fx{display:flex;flex-wrap:wrap;gap:4px;justify-content:center;max-width:100%;max-height:46px;overflow:hidden}
.au-fx>span{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:700;border-radius:999px;padding:2px 8px 2px 4px;background:rgba(18,14,24,.78);border:1px solid var(--c);color:var(--ink);white-space:nowrap}
.au-fx svg{width:14px;height:14px;color:var(--c);flex:none}
.au-gorow{display:flex;gap:8px;align-items:stretch}
.au-gorow .au-go{flex:1 1 auto;width:auto;min-width:0}
.au-cbtn{flex:none;min-height:52px;padding:4px 10px;font-size:13px;flex-direction:column;gap:1px;line-height:1.1;border-color:rgba(185,148,236,.6);background:linear-gradient(#3a2a52,#2b2040)}
.au-cbtn svg{width:20px;height:20px;color:#d7c2ff}
.au-cbtn.used{opacity:.75}
.au-card.cpt{padding:4px 4px 5px;gap:3px;border-radius:10px}
.au-card.cpt .fr{border-width:3px}
.au-card.cpt .val{font-family:var(--f-mono);font-weight:700;font-size:12px}
.au-cbtn .n{font-family:var(--f-body);font-weight:700;font-size:11px;color:#e6d6ff}
.au-peek{justify-content:center;gap:6px;color:#9fc8ff}
.au-peek svg{width:16px;height:16px;color:inherit}
.au-ci{width:44px;height:44px;border-radius:11px;flex:none;display:grid;place-items:center;color:var(--c);background:linear-gradient(160deg,color-mix(in srgb,var(--c) 30%,#2b2040),#1d1628);border:1.5px solid var(--c)}
.au-ci svg{width:28px;height:28px}
.au-cl{display:flex;flex-direction:column;gap:7px}
.au-crow{display:flex;gap:10px;align-items:center;padding:8px;border-radius:12px;background:var(--bg)}
.au-crow .tx{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:2px}
.au-crow .tx b{font-size:14.5px}
.au-crow .tx span{font-size:12px;color:var(--muted);line-height:1.35}
.au-crow .tx .why{color:var(--coral);font-weight:700;font-size:11.5px}
.au-crow .btn{min-height:44px;min-width:60px;flex:none}
.au-tg{display:flex;flex-wrap:wrap;gap:6px;padding:0 0 4px 0}
.au-tg .btn{min-height:44px;padding:4px 10px;font-size:13px;flex:1 1 calc(50% - 6px);justify-content:flex-start;min-width:0}
.au-tg .btn span.t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.au-evt{position:absolute;left:50%;z-index:15;transform:translateX(-50%);width:min(340px,calc(100% - 24px));display:flex;gap:10px;align-items:center;background:rgba(23,19,31,.96);border:2px solid var(--c);border-radius:14px;padding:9px 11px;box-shadow:0 10px 26px rgba(0,0,0,.55),0 0 18px color-mix(in srgb,var(--c) 35%,transparent);pointer-events:none;animation:auEvt .4s cubic-bezier(.2,.9,.3,1.25)}
.au-evt.bye{opacity:0;transform:translateX(-50%) translateY(-10px);transition:opacity .3s,transform .3s}
.au-evt .tx{display:flex;flex-direction:column;gap:2px;min-width:0}
.au-evt .who{font-size:12.5px;font-weight:700;color:var(--muted);display:flex;align-items:center;gap:5px;white-space:nowrap;overflow:hidden}
.au-evt .who b{color:var(--c);font-size:15px}
.au-evt .det{font-size:13px;font-weight:700;color:var(--ink);line-height:1.3}
.au-deal{position:absolute;inset:0;z-index:17;display:flex;align-items:center;justify-content:center;padding:14px;background:rgba(10,8,15,.72);animation:fade .2s}
.au-deal .sheet{align-items:center;text-align:center;gap:10px;width:min(340px,100%)}
.au-deal .sheet h2{font-size:24px}
.au-ecard{width:150px;min-height:184px;border-radius:14px;padding:12px 10px;display:flex;flex-direction:column;align-items:center;gap:8px;background:linear-gradient(165deg,#3d2c58,#1f1730);border:3px solid var(--c);box-shadow:0 12px 26px rgba(0,0,0,.5),inset 0 0 0 3px rgba(255,255,255,.06);animation:auDeal .6s cubic-bezier(.2,.9,.3,1.2)}
.au-ecard svg{width:56px;height:56px;color:var(--c)}
.au-ecard b{font-family:var(--f-display);font-weight:400;font-size:21px;color:var(--ink)}
.au-ecard span{font-size:12px;color:var(--muted);line-height:1.35}
.au-ecards{display:flex;gap:6px;justify-content:center;flex-wrap:wrap}
.au-flip .au-tagx{position:absolute;left:-6px;top:-8px;background:#5fd3a0;color:#08261a;font-weight:900;font-size:10.5px;padding:2px 6px;border-radius:7px;z-index:2}
.au-flip.out .au-front .amt{font-size:16px;color:var(--coral)}
.au-xl{display:flex;flex-direction:column;gap:3px;align-items:center;font-size:12px;font-weight:700;color:var(--muted);text-align:center}
.au-cxbig{width:84px;height:84px;color:var(--coral);animation:auPop2 .5s}
@keyframes auEvt{from{opacity:0;transform:translateX(-50%) translateY(-16px) scale(.9)}to{opacity:1;transform:translateX(-50%)}}
@keyframes auDeal{0%{transform:rotateY(90deg) scale(.7);opacity:0}100%{transform:none;opacity:1}}
@keyframes auPop2{0%{transform:scale(.4) rotate(-20deg);opacity:0}60%{transform:scale(1.15)}100%{transform:none;opacity:1}}
.au-p .r2{min-width:0;overflow:hidden}
@media (max-width:430px){.au-top.tight{gap:4px}.au-top.tight .au-p{padding:5px 5px}.au-top.tight .au-p .co .au-coin{display:none}.au-top.tight .au-p .r2{gap:2px}.au-top.tight .au-p .co{font-size:12px}.au-top.tight .au-p .cd{padding:0 3px;gap:1px}.au-top.tight .au-p .pt{font-size:10.5px}}
.au-p .sh{width:11px;height:11px;color:#ffcf5a;flex:none;display:inline-grid;margin:-2px 1px 0 0}
.au-p .sh svg{width:11px;height:11px}
.au-tags{display:flex;gap:4px;flex-wrap:wrap;align-items:center}
.au-tags i{font-style:normal;font-size:10.5px;font-weight:800;border-radius:6px;padding:1px 6px;line-height:16px;background:color-mix(in srgb,var(--c) 22%,transparent);color:var(--c);border:1px solid color-mix(in srgb,var(--c) 55%,transparent)}
.au-filt{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px;flex:none}
.au-filt .btn{min-height:44px;padding:4px 2px;font-size:12.5px;min-width:0}
.au-filt .btn.on{background:var(--c,var(--brass));color:#1b1424;border-color:transparent}
.au-cat{display:flex;flex-direction:column;gap:6px;overflow:auto;min-height:0}
.au-cat .au-crow{padding:7px 8px}
.au-cat .au-ci{width:40px;height:40px}
.au-cat .au-ci svg{width:25px;height:25px}
.au-picks{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:6px;padding-bottom:4px}
.au-picks .btn{min-height:44px;padding:4px 6px;font-size:12px;flex-direction:column;gap:2px;line-height:1.15;min-width:0}
.au-picks .btn .t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
.au-picks .btn small{font-size:10.5px;color:var(--muted);font-weight:700}
.au-picks .btn svg{width:100%;height:auto;max-height:40px;border-radius:4px;display:block}
.au-note{font-size:12px;font-weight:700;text-align:center;color:var(--c,var(--ink));line-height:1.3}
.au-ecard .rar{font-size:11px;font-weight:900;letter-spacing:.04em;color:var(--rc)}
.au-ecard.leg{box-shadow:0 12px 26px rgba(0,0,0,.5),0 0 0 2px #ffcf5a,0 0 26px rgba(255,207,90,.45)}
.au-evt .blk{color:#ffcf5a}
.au-flip .au-tagx.cap{background:#e3ae45;color:#2a1d05}
.au-flip .au-tagx.bad{background:var(--coral);color:#2b0c06}
.au-hint{flex:none;max-width:100%;font-size:11.5px;font-weight:700;line-height:1.3;color:#cfe3ff;text-align:center;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
`;

  function itemColor(id) { const it = item(id); return it.k === 'c' ? COL[it.c].c : it.k === 'b' ? BIRD_C : it.k === 'f' ? FAKE_C : SPEC[it.k].c; }
  function itemTag(id) {
    const it = item(id);
    if (it.k === 'c') return COL[it.c].n + (it.mp ? ' 걸작' : it.pr ? ' 소품' : '');
    return it.k === 'b' ? '태엽새' : it.k === 'f' ? '위작' : SPEC[it.k].n;
  }
  /* short value label: points, n² for birds, coins for money items, "2+" for set pieces */
  function itemVal(id) {
    const it = item(id);
    if (it.k === 'b') return 'n²';
    if (it.k === 'm') return '+' + it.m + '금';
    if (it.k === 'p' || it.k === 'k') return '2+';
    if (it.k === 'h') return it.v + '+';
    return (it.v > 0 ? '+' : '') + it.v;
  }
  const valLong = (id) => { const it = item(id); return it.k === 'b' ? '마릿수²' : it.k === 'm' ? '금화 +' + it.m : itemVal(id) + '점'; };
  /* the lot as everyone sees it: covered (깜깜이) until the reveal */
  const COVER = '<rect width="100" height="80" fill="#3a2a52"/><path d="M0 0l100 80M100 0L0 80" stroke="#4a3a66" stroke-width="10"/><circle cx="50" cy="40" r="20" fill="#2b2040" stroke="#b994ec" stroke-width="2"/>' +
    '<text x="50" y="49" text-anchor="middle" font-size="26" font-weight="900" fill="#d7c2ff" font-family="sans-serif">?</text>';
  const cicon = (k) => '<svg viewBox="0 0 40 40" aria-hidden="true">' + CICON[k] + '</svg>';
  const DECK = '<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="13" y="5" width="19" height="27" rx="3" transform="rotate(12 22 18)" fill="none" stroke="currentColor" stroke-width="2.5" opacity=".6"/><rect x="8" y="8" width="19" height="27" rx="3" fill="currentColor" opacity=".25" stroke="currentColor" stroke-width="2.5"/><path d="M17.5 15l3 5-3 5-3-5z" fill="currentColor"/></svg>';

  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'au' });
    const top = h('div', { class: 'au-top' });
    const mid = h('div', { class: 'au-mid' });
    const bot = h('div', { class: 'au-bot' });
    wrap.append(top, mid, bot);
    root.append(style, wrap);
    let st = null, anim = null, revealed = -1, ovEl = null, handEl = null, handKey = '', midKey = '', botKey = '';
    let evtEl = null, evtT = 0, dealEl = null, dealT = 0, pendingDeal = false, sheetSeat = -1, sheetOpen = -1, cardSent = '';
    const sent = {}, bidV = {}, timers = [];
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#999');
    const later = (fn, ms) => { const t = setTimeout(fn, ms / sp()); timers.push(t); return t; };
    const multi = () => !api.online && api.mySeats().length >= 2;
    const view = () => (anim ? anim.prev : st);
    const rk = (s) => s.r + (s.t2 ? 0.5 : 0); // a second envelope is a new bid in the same round
    const josa = (w, a, b) => { const c = w.charCodeAt(w.length - 1); return w + (c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b); };

    /* who on this device still has to bid */
    function pendingLocal() {
      if (!st || st.ph !== 'b' || anim) return [];
      const r = [];
      for (let i = 0; i < st.n; i++) if (api.canAct(i) && st.b[i] == null && sent[i] !== rk(st)) r.push(i);
      return r;
    }
    function activeBidder() {
      const p = pendingLocal();
      if (!p.length) return -1;
      if (multi()) return p.includes(revealed) ? revealed : -1;
      return p[0];
    }

    /* ---- top: players ---- */
    function renderTop() {
      const s = view(); if (!s) return;
      top.innerHTML = '';
      top.style.gridTemplateColumns = 'repeat(' + (s.n <= 4 ? s.n : 3) + ',minmax(0,1fr))';
      top.classList.toggle('tight', s.n === 4);
      for (let i = 0; i < s.n; i++) {
        const sc = scoreOf(s, i);
        const bidding = s.ph === 'b' && !anim;
        const out = bidding && isOut(s, i);
        const done = bidding && s.b[i] != null && !out;
        const shield = s.eo && bit(s.sh, i) ? h('span', { class: 'sh', html: cicon(E.GUARD), title: '경비원', 'aria-label': '경비원이 지켜요' }) : null;
        const pips = h('div', { class: 'pips' });
        if (shield) pips.append(shield);
        for (const ch of s.co[i]) pips.append(h('i', { class: s.cf && s.cf.indexOf(ch) >= 0 ? 'cf' : '', style: { background: itemColor(idOf(ch)) } }));
        const nc = s.eo && s.ev ? s.ev[i].length : 0;
        top.append(h('button', { class: 'au-p' + (out ? ' out' : ''), 'aria-label': nm(i) + ' 수집품 보기', onclick: () => colSheet(i),
          style: { borderColor: done ? 'rgba(95,211,160,.6)' : out ? 'rgba(238,106,85,.7)' : '' } },
        h('div', { class: 'r1' }, h('span', { class: 'dot', style: { '--c': col(i), flex: 'none' } }), h('span', { class: 'nm', text: nm(i) }),
          bidding ? h('span', { class: 'st', style: { color: out ? 'var(--coral)' : done ? '#5fd3a0' : 'var(--muted)' }, text: out ? '✕' : done ? '✓' : '…', 'aria-label': out ? '출입 금지' : done ? '입찰함' : '고민 중' }) : null),
        h('div', { class: 'r2' }, h('span', { class: 'co' }, h('span', { class: 'au-coin' }), String(s.c[i])),
          s.eo ? h('span', { class: 'cd', 'aria-label': '이벤트 카드 ' + nc + '장' }, h('i'), String(nc)) : null,
          h('span', { class: 'pt', text: '★' + sc.items })),
        pips));
      }
    }

    /* ---- middle: the lot on the table ---- */
    function cardEl(id, w, compact, cover) {
      const it = item(id), c = cover ? '#7a5ab0' : itemColor(id);
      const svg = '<svg viewBox="0 0 100 80" aria-hidden="true">' + (cover ? COVER : art(id)) + '</svg>';
      const name = cover ? '덮인 경매품' : it.n, bad = !cover && it.k === 'f';
      if (compact) { // short screens: name + value on one line under the picture
        return h('div', { class: 'au-card cpt', style: { width: w + 'px', borderTop: '4px solid ' + c } },
          h('div', { class: 'fr', html: svg }),
          h('div', { class: 'nm', style: { fontSize: '12.5px' } }, name, h('span', { class: 'val', style: { color: bad ? '#c0392b' : c, marginLeft: '4px' }, text: cover ? '?' : itemVal(id) })));
      }
      return h('div', { class: 'au-card', style: { width: w + 'px' } },
        h('div', { class: 'fr', html: svg }),
        h('div', { class: 'nm', style: { fontSize: w < 120 ? '13.5px' : '16px' }, text: name }),
        h('div', { class: 'meta' }, h('span', { class: 'tagc', style: { background: c }, text: cover ? '깜깜이' : itemTag(id) }),
          h('span', { class: 'val', style: { color: bad ? '#c0392b' : '#2a1d05' }, text: cover ? '?' : valLong(id) })));
    }
    /* this round's card effects + lasting trends, as chips everyone can see.
       o: the round's card state (s itself, or the reveal's `last`): al · mb · sb · cv · ow · bt · t2 */
    const chipOf = (k, text) => h('span', { style: { '--c': CARDS[k].c } }, h('span', { html: cicon(k), style: { display: 'contents' } }), text);
    const SHOWN_APART = [E.BLOCK, E.LOCK, E.TARIFF, E.ALLY, E.MINBID, E.SABO, E.COLLR, E.BET, E.DUEL, E.OWNER];
    function fxChips(s, u, x, lk, tf, o) {
      const chips = [];
      o = o || {};
      if (o.cv) chips.push(chipOf(E.COLLR, '수집가 ' + o.cv + '금화'));
      if (o.al) chips.push(chipOf(E.ALLY, '동맹 ' + nm(o.al[0]) + '+' + nm(o.al[1])));
      if (o.t2) chips.push(chipOf(E.TWICE, '2차: ' + nm(o.t2[0]) + ' · ' + nm(o.t2[1])));
      (u || []).forEach((k, i) => {
        if (k < 0 || SHOWN_APART.indexOf(k) >= 0) return;
        chips.push(chipOf(k, CARDS[k].n + ' · ' + nm(i)));
      });
      if (o.ow != null) chips.push(chipOf(E.OWNER, '주인 ' + nm(o.ow)));
      const duel = (u || []).indexOf(E.DUEL);
      for (let i = 0; i < s.n; i++) {
        if (bit(x, i) && !o.t2) chips.push(chipOf(duel >= 0 ? E.DUEL : E.BLOCK, (duel >= 0 ? '빠짐 → ' : '출입 금지 → ') + nm(i)));
        if (bit(lk, i)) chips.push(chipOf(E.LOCK, '지갑 잠금 → ' + nm(i)));
        if (bit(tf, i)) chips.push(chipOf(E.TARIFF, '관세 → ' + nm(i)));
        if (bit(o.mb, i)) chips.push(chipOf(E.MINBID, '최소 ' + MIN_AMT + ' → ' + nm(i)));
        if (bit(o.sb, i)) chips.push(chipOf(E.SABO, '−' + SABO_AMT + ' → ' + nm(i)));
      }
      (o.bt || []).forEach((b) => { if (b.length === 3) chips.push(chipOf(E.BET, nm(b[0]) + ': ' + b[2] + (b[1] ? ' 미만' : ' 이상'))); });
      return chips;
    }
    /* effects that last: trends, rule changes, public bids */
    function trendChips(s) {
      const out = [];
      if (s.op) {
        const t = s.op.map((v, i) => (v >= 0 ? nm(i) + ' ' + v : '')).filter(Boolean).join(' · ');
        if (t) out.push(chipOf((s.rf || 0) & RF_OPEN ? E.OPEN : E.MEGA, '공개: ' + t));
      }
      const gf = s.gf || 0;
      if (s.bm) out.push(chipOf(E.BOOM, '호황 ' + s.bm + '번 더'));
      if (s.dp) out.push(chipOf(E.SLUMP, '불황 ' + s.dp + '라운드'));
      if (gf & GF_AMN) out.push(chipOf(E.AMNESTY, '위작 0점'));
      if (gf & GF_INFL) out.push(chipOf(E.INFL, '금화 5당 1점'));
      if (gf & GF_CRASH) out.push(chipOf(E.CRASH, '금화 20당 1점'));
      if (gf & GF_PAIR) out.push(chipOf(E.PAIR, '세트 2점부터'));
      if (gf & GF_TRIPLE) out.push(chipOf(E.TRIPLE, '같은 색 4점 ×3'));
      if (gf & GF_BIRD) out.push(chipOf(E.BIRDYR, '태엽새 +2'));
      if (!s.tr) return out;
      const cnt = {};
      for (const t of s.tr) cnt[t] = (cnt[t] || 0) + 1;
      return out.concat(Object.keys(cnt).map((t) => chipOf(E.TREND, '유행 ' + KIND_N[+t] + ' +' + cnt[t])));
    }
    /* how this round's bids are counted right now (shown under the lot) */
    function roundNote(s) {
      const rf = s.rf || 0, r = [];
      if (s.t2) r.push('2차 입찰: ' + nm(s.t2[0]) + ' ' + s.t2[2] + ' · ' + nm(s.t2[1]) + ' ' + s.t2[3] + ' → 그 이상으로 다시');
      else if (rf & RF_TWICE) r.push('봉투 두 번: 1·2등은 한 번 더 입찰');
      if (rf & RF_REV) r.push('거꾸로: 가장 적게(1 이상) 쓴 사람이 낙찰');
      if (rf & RF_BLIND) r.push('덮인 경매품 — 공개 때 알 수 있어요');
      if (rf & RF_DUTCH) r.push('입찰을 5 단위로 내려서 비교');
      if (rf & RF_ALLPAY) r.push('진 사람도 입찰의 절반을 내요');
      if (rf & RF_AVG) r.push('낙찰자는 평균가만 내요');
      if (rf & RF_OPEN) r.push('입찰하면 바로 공개돼요');
      if (rf & RF_FIRST) r.push('동점이면 먼저 낸 사람');
      if (s.cv) r.push('수집가 ' + s.cv + '보다 많이 써야 해요');
      if (rf & RF_CAP) r.push('입찰은 최대 ' + CAP_AMT + '까지만 쳐요');
      if ((s.dp || 0) > 0) r.push('불황: 입찰은 최대 ' + SLUMP_AMT);
      if (rf & RF_FLOOR) r.push(FLOOR_AMT + ' 이하 입찰은 무효');
      return r.join(' · ');
    }
    /* one short line under the lot: what a special item does, or the lots shown by 감정서 */
    function hintLine(s) {
      const parts = [];
      if ((s.pv || 0) > s.r) {
        const up = upcoming(s, s.pv - s.r);
        if (up.length) parts.push('감정서 공개 · 다음: ' + up.map((x) => (x.md === 'f' ? '위작 경매 ' : '') + x.lot.split('').map((ch) => item(idOf(ch)).n).join('+')).join(' → '));
      }
      if (!blind(s)) {
        const seen = {};
        for (const ch of s.lot) { const t = itemHint(idOf(ch)); if (t && !seen[t]) { seen[t] = 1; parts.push(item(idOf(ch)).n + ': ' + t); } }
      }
      return parts.join(' · ');
    }
    function renderMid() {
      const s = view(); if (!s) return;
      const key = [s.r, s.R, s.lot, s.md, s.ph, anim ? 1 : 0, mid.clientHeight > 0 ? Math.round(mid.clientHeight / 20) : 0, s.n, (s.u || []).join(','), s.x, s.tr,
        s.rf, s.lk, s.tf, s.gf, s.op ? s.op.join(',') : '', s.t2 ? s.t2.join(',') : '', s.al, s.cv, s.mb, s.sb, s.ow, s.bt ? s.bt.join(';') : '', s.bm, s.dp, s.pv,
        mid.clientWidth > 0 ? Math.round(mid.clientWidth / 20) : 0].join('|');
      if (key === midKey) return;
      midKey = key;
      mid.innerHTML = '';
      if (s.ph === 'e') {
        mid.append(h('div', { class: 'au-mode', html: '<b>경매 끝</b> · 결과를 집계했어요' }));
        mid.append(h('button', { class: 'btn sm', text: '경매 기록', onclick: histSheet }));
        return;
      }
      mid.append(h('div', { class: 'au-head' },
        h('span', null, h('span', { class: 'rd', text: '라운드 ' + (s.r + 1) + '/' + s.R }), ' · 동점 우선 ', h('span', { class: 'dot', style: { '--c': col(prio(s)), display: 'inline-block', verticalAlign: 'middle' } }), ' ' + nm(prio(s))),
        h('button', { class: 'btn sm', text: '기록', 'aria-label': '경매 기록 보기', onclick: histSheet })));
      const fx = fxChips(s, s.u, s.x, s.lk, s.tf, s).concat(trendChips(s));
      const table = h('div', { class: 'au-table' }, h('div', { class: 'au-spot' }));
      mid.append(table);
      if (fx.length) mid.append(h('div', { class: 'au-fx' }, ...fx));
      const rn = roundNote(s);
      const md = s.md === 'n' && s.lot.length > 1 ? { n: '보따리 경매', d: '낙찰자가 두 점을 모두 가져가요' } : MODE[s.md];
      mid.append(h('div', { class: 'au-mode', style: rn ? { borderColor: CATS[1].c } : null }, h('b', { text: md.n }), ' · ' + (rn || md.d)));
      const hl = hintLine(s);
      if (hl) mid.append(h('div', { class: 'au-hint', text: hl }));
      // size the lot to the space the table really got (badge needs ~12px above the card)
      const th = table.clientHeight - 12, two = s.lot.length > 1;
      const maxW = two ? Math.min(130, (mid.clientWidth - 40) / 2) : Math.min(190, mid.clientWidth * 0.5);
      let w = Math.min(maxW, Math.floor((th - 70) / 0.8)); // card height ≈ 0.8w + 70
      let compact = false;
      if (w < (two ? 84 : 96)) { compact = true; w = U.clamp(Math.floor((th - 34) / 0.8), 56, maxW); } // compact ≈ 0.8w + 34
      const lot = h('div', { class: 'au-lot' });
      for (const ch of s.lot) lot.append(cardEl(idOf(ch), Math.round(w), compact, blind(s)));
      if (s.md !== 'n' || two) lot.append(h('div', { class: 'au-badge', style: { background: s.md === 'f' ? 'var(--coral)' : 'var(--brass)', color: s.md === 'f' ? '#2b0c06' : 'var(--brass-ink)' }, text: md.n }));
      table.append(lot);
    }

    /* ---- bottom: bidding controls or waiting status ---- */
    function holdRepeat(btn, fn) {
      let t1 = 0, t2 = 0;
      const stop = () => { clearTimeout(t1); clearInterval(t2); };
      btn.addEventListener('pointerdown', (e) => { e.preventDefault(); fn(); api.buzz(8); t1 = setTimeout(() => { t2 = setInterval(fn, 70); }, 380); });
      ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => btn.addEventListener(ev, stop));
    }
    function renderBot(force) {
      const s = st; if (!s) return;
      const seat = activeBidder();
      const key = [s.r, s.ph, seat, anim ? 1 : 0, s.b ? s.b.map((x) => (x == null ? 0 : 1)).join('') : '', pendingLocal().join(','),
        (s.u || []).join(','), s.x, s.eo ? s.ev.join('/') : '', (s.pk || []).map((x) => (x == null ? 0 : 1)).join(''), s.c.join(','), cardSent,
        s.md, s.lot, s.rf, s.lk, s.tf, s.sh, s.co.join('/'), s.op ? s.op.join(',') : '', s.t2 ? s.t2.join(',') : '', s.mb, s.sb, s.al, s.cv, s.dp, s.cbu ? s.cbu.join(',') : ''].join('|');
      if (key === botKey && !force) return;
      botKey = key;
      bot.innerHTML = '';
      if (s.ph === 'e') { bot.append(h('div', { class: 'au-wait' }, h('div', { class: 'ln', text: '모든 경매가 끝났어요' }))); return; }
      if (seat >= 0) return bot.append(bidPanel(seat));
      const sts = h('div', { class: 'au-sts' });
      for (let i = 0; i < s.n; i++) {
        const out = isOut(s, i), d = s.b[i] != null;
        sts.append(h('span', { style: { opacity: d ? 1 : 0.7 } }, h('span', { class: 'dot', style: { '--c': col(i) } }), nm(i),
          h('span', { style: { color: out ? 'var(--coral)' : d ? '#5fd3a0' : 'var(--muted)' }, text: out ? '✕' : d ? '✓' : '…' })));
      }
      const mine = api.mySeats();
      const mineDone = mine.filter((i) => s.b[i] != null || sent[i] === rk(s));
      let line;
      if (anim) line = h('div', { class: 'ln', text: '입찰 공개!' });
      else if (pendingLocal().length && multi()) line = h('div', { class: 'ln', text: '폰을 다음 사람에게 넘겨주세요' });
      else if (mine.length === 1 && isOut(s, mine[0])) line = s.t2 ? h('div', { class: 'ln' }, '봉투 두 번 — ' + nm(s.t2[0]) + ' · ' + nm(s.t2[1]) + ' 다시 입찰 중', h('span', { class: 'au-dots' }))
        : h('div', { class: 'ln', style: { color: 'var(--coral)' } }, '이번 경매에서 빠졌어요', h('span', { class: 'au-dots' }));
      else if (mineDone.length === 1 && !multi() && bidV['sent' + mineDone[0]] != null && bidV['sentR' + mineDone[0]] === rk(s))
        line = h('div', { class: 'ln' }, '내 입찰 ', h('span', { class: 'mine', text: bidV['sent' + mineDone[0]] + '금화' }), ' · 다른 사람 기다리는 중', h('span', { class: 'au-dots' }));
      else line = h('div', { class: 'ln' }, '모두 몰래 입찰하는 중', h('span', { class: 'au-dots' }));
      bot.append(h('div', { class: 'au-wait' }, line, sts));
    }
    function bidPanel(seat) {
      const s = st, max = maxBid(s, seat), mn = minBid(s, seat), f = s.md === 'f', rf = s.rf || 0, cover = blind(s);
      let v = U.clamp(bidV[seat + ':' + rk(s)] != null ? bidV[seat + ':' + rk(s)] : mn, mn, max);
      const my = s.u ? s.u[seat] : -1;
      const pts = lotItems(s, seat, s.lot, my === E.CERT);
      const vEl = h('span', { text: String(v) });
      const goT = h('span');
      const left = h('b');
      const range = h('input', { class: 'au-range', type: 'range', min: mn, max, step: 1, value: v, 'aria-label': '입찰 금액' });
      const cut = (x) => (my === E.COUP ? Math.floor(x / 2) : x);
      function set(nv, quiet) {
        nv = U.clamp(Math.round(nv), mn, max);
        if (nv !== v && !quiet) api.sfx('tick');
        v = nv; bidV[seat + ':' + rk(s)] = v;
        vEl.textContent = String(v); range.value = v;
        let cv = Math.min(v, capFor(s, seat));
        if ((rf & RF_FLOOR) && cv <= FLOOR_AMT) cv = 0;
        if (rf & RF_DUTCH) cv = Math.floor(cv / 5) * 5;
        let pay = cut(cv + (s.md === 'q' && cv > 0 ? FEE : 0));
        if (bit(s.it, seat)) pay -= Math.floor(pay / 2);
        pay += bit(s.tf, seat) && cv > 0 ? TARIFF_AMT : 0;
        left.textContent = String(Math.max(0, s.c[seat] - (f ? cut(cv) : pay)));
        goT.textContent = f ? (v ? v + '금화 내고 피하기' : '0금화 · 떠안을 각오') : v ? v + '금화 입찰' : '포기 (0금화)';
      }
      range.addEventListener('input', () => set(+range.value));
      const minus = h('button', { class: 'btn', 'aria-label': '1 줄이기', text: '−' });
      const plus = h('button', { class: 'btn', 'aria-label': '1 늘리기', text: '+' });
      holdRepeat(minus, () => set(v - 1));
      holdRepeat(plus, () => set(v + 1));
      const chip = (t, fn, aria) => h('button', { class: 'btn sm', text: t, 'aria-label': aria || t, onclick: () => { set(fn()); api.buzz(8); } });
      const go = h('button', { class: 'btn primary au-go', onclick: () => {
        if (st.b[seat] != null || sent[seat] === rk(st)) return;
        sent[seat] = rk(st); bidV['sent' + seat] = v; bidV['sentR' + seat] = rk(st);
        api.buzz(20); api.sfx('chip');
        if (multi()) revealed = -1;
        closeOv();
        api.actAs(seat, { t: 'bid', v });
        later(() => { if (st && st.ph === 'b' && st.b[seat] == null && sent[seat] === rk(st)) { delete sent[seat]; renderAll(); } }, 3000 * sp());
        renderAll();
      } }, goT);
      const sc = scoreOf(s, seat).items;
      const info = h('div', { class: 'au-info' },
        h('span', null, nm(seat) + ' · 금화 ', h('b', { text: String(s.c[seat]) }), ' → 남는 돈 ', left),
        h('span', { style: { color: f ? 'var(--coral)' : '#5fd3a0' }, text: (f ? '떠안으면 ' : '낙찰되면 ') + (cover ? '?점 (덮여 있어요)' : (pts >= 0 ? '+' : '') + pts + '점 (' + sc + '→' + (sc + pts) + ')') }));
      const gorow = h('div', { class: 'au-gorow' });
      if (s.eo) gorow.append(cardButton(seat));
      gorow.append(go);
      const box = h('div', { class: 'au-wait', style: { gap: '7px' } }, info,
        h('div', { class: 'au-amt' }, minus, h('div', { class: 'v' }, vEl, h('small', { text: '금화' })), plus),
        range,
        h('div', { class: 'au-chips' }, chip(mn ? '최소' : '0', () => mn, mn ? '최소 금액으로' : '0으로'), chip('−5', () => v - 5), chip('+5', () => v + 5), chip('+10', () => v + 10), chip('최대', () => max, '가진 돈 전부')),
        gorow);
      if (s.md === 'q') box.insertBefore(h('div', { class: 'au-info', style: { justifyContent: 'center', color: 'var(--brass)' }, text: '낙찰되면 수수료 ' + FEE + '금화가 더 붙어요 · 최대 입찰 ' + max }), box.children[1]);
      const note = myCardNote(s, seat);
      if (note) box.insertBefore(note, box.children[1]);
      const warn = [];
      if (bit(s.lk, seat)) warn.push('지갑 잠금: 내 입찰은 최대 ' + LOCK_AMT + '까지만 쳐요');
      if (bit(s.tf, seat)) warn.push('추가 관세: 낙찰되면 ' + TARIFF_AMT + '금화 더 내요');
      if (bit(s.mb, seat)) warn.push('공개 경고: 최소 ' + MIN_AMT + '금화를 걸어야 해요');
      if (bit(s.sb, seat)) warn.push('훼방꾼: 내 입찰은 ' + SABO_AMT + ' 낮게 쳐요');
      if (s.t2 && (seat === s.t2[0] || seat === s.t2[1])) { const o = seat === s.t2[0] ? 1 : 0; warn.push('2차 입찰: ' + nm(s.t2[o]) + '의 1차는 ' + s.t2[o + 2] + ' · 내 1차 ' + mn + ' 이상'); }
      if (s.al && s.al[1] === seat) warn.push(nm(s.al[0]) + '의 동맹: 내 입찰이 더해져요 (이기면 +' + ALLY_PTS + '점, 내 금액은 내요)');
      if (s.al && s.al[0] === seat) warn.push(nm(s.al[1]) + '의 입찰이 내 입찰에 더해져요');
      if (s.cv) warn.push('수집가 ' + s.cv + '금화보다 많이 써야 이겨요');
      if (!f && isCursed((s.co[seat] || '') + (cover ? '' : s.lot)) && !isCursed(s.co[seat]) && !bit(s.nc, seat)) warn.push('저주! 가지면 남은 금화가 점수가 안 돼요');
      const sc2 = ownerOf(s, MYST_IDS[Z_SCOPE]);
      if (sc2 === seat) { const nx = nextLot(s); if (nx) warn.push('망원경: 다음은 ' + (nx.md === 'f' ? '위작 경매 ' : '') + nx.lot.split('').map((ch) => item(idOf(ch)).n).join(' + ')); }
      if (warn.length) box.insertBefore(h('div', { class: 'au-note', style: { '--c': '#ffb38a' }, text: warn.join(' · ') }), box.children[1]);
      set(v, true);
      return box;
    }
    /* what my card this round told me (private) or that it's in play */
    function myCardNote(s, seat) {
      const my = s.u ? s.u[seat] : -1;
      if (my < 0) return null;
      const C = CARDS[my], f = s.md === 'f', pk = s.pk && s.pk[seat];
      const row = (...kids) => h('div', { class: 'au-info au-peek', style: { color: C.c } }, h('span', { html: cicon(my), style: { display: 'contents' } }), ...kids);
      if (pk != null && my === E.PEEK) return row('엿보기: 먼저 낸 입찰 중 ' + (f ? '꼴찌 ' : '1등 '), h('b', { text: dec(pk) + '금화' }));
      if (pk != null && my === E.SNOOP) { const d = dec(pk); return row('쪽지: ' + nm(Math.floor(d / 1000) - 1) + '의 입찰 ', h('b', { text: (d % 1000) + '금화' })); }
      if (pk != null && my === E.RUMOR) {
        const t = unscr(pk).slice(1);
        return row('소문: ' + (t ? t.split('').map((ch) => CARDS[idOf(ch)].n).join(', ') : '카드 없음'));
      }
      if (pk != null && my === E.PREV) {
        const t = unscr(pk), m = t[1], lot = t.slice(2);
        return row('예고: 다음은 ' + MODE[m].n + ' · ' + lot.split('').map((ch) => item(idOf(ch)).n).join(' + '));
      }
      if (pk != null && my === E.SUMPEEK) { const d = dec(pk); return row('회계 장부: ' + Math.floor(d / 1000) + '명 합계 ', h('b', { text: (d % 1000) + '금화' })); }
      if (my === E.BET && s.bt) { const b = s.bt.find((x) => x[0] === seat); if (b) return row('예언 내기: 낙찰가 ' + b[2] + (b[1] ? ' 미만' : ' 이상') + '에 걸었어요'); }
      return row(C.n + ' 사용 중');
    }
    function cardButton(seat) {
      const s = st, hand = s.ev[seat] || '', used = s.u[seat];
      if (used >= 0) return h('button', { class: 'btn au-cbtn used', disabled: true, 'aria-label': '이번 라운드 카드 사용함' }, h('span', { html: cicon(used), style: { display: 'contents' } }), h('span', { class: 'n', text: '사용함' }));
      return h('button', { class: 'btn au-cbtn', 'aria-label': '이벤트 카드 ' + hand.length + '장', disabled: cardSent === seat + ':' + rk(s),
        onclick: () => cardSheet(seat) }, h('span', { html: DECK, style: { display: 'contents' } }), h('span', { class: 'n', text: '카드 ' + hand.length }));
    }
    const tagsOf = (k) => h('span', { class: 'au-tags' }, h('i', { style: { '--c': CARDS[k].c }, text: CATS[CARDS[k].g].n }), h('i', { style: { '--c': RARE[CARDS[k].r].c }, text: RARE[CARDS[k].r].n }));
    /* the picker for a card that needs a choice */
    function pickerFor(s, seat, k, use) {
      const ty = TARGET[k], box = h('div', { class: 'au-picks' });
      const btn = (t, label, sub, extra) => box.append(h('button', { class: 'btn', onclick: () => use(k, t) }, extra || null, h('span', { class: 't', text: label }), sub ? h('small', { text: sub }) : null));
      if (ty === 1) {
        for (let t = 0; t < s.n; t++) {
          if (targetWhy(s, seat, k, t)) continue;
          let sub = '';
          if (k === E.STEAL) sub = s.c[t] + '금화';
          else if (k === E.SWAP) sub = item(idOf(s.co[t][s.co[t].length - 1])).n;
          else if (k === E.BLOCK) sub = s.b[t] != null ? '입찰함' : '';
          else if (k === E.RUMOR || k === E.CSTEAL) sub = '카드 ' + s.ev[t].length + '장';
          else if (k === E.THIEF) sub = '물건 ' + s.co[t].length + '점';
          else if (k === E.DUMP || k === E.LOCK || k === E.TARIFF || k === E.FAKEGIFT || k === E.CBLOCK || k === E.LEND) sub = '★' + scoreOf(s, t).items + ' · ' + s.c[t] + '금화';
          else if (k === E.ACCUSE) sub = '위작 ' + fakeCount(s.co[t]) + '점';
          else if (k === E.MINBID || k === E.SABO || k === E.ALLY || k === E.DUEL) sub = s.b[t] != null ? '입찰함' : s.c[t] + '금화';
          if (bit(s.sh, t)) sub = '경비원이 막아요';
          btn(t, nm(t), sub, h('span', { class: 'dot', style: { '--c': col(t), flex: 'none' } }));
        }
      } else if (ty === 2) {
        const co = s.co[seat];
        for (let j = 0; j < co.length; j++) {
          if (targetWhy(s, seat, k, j)) continue;
          const id = idOf(co[j]);
          btn(j, item(id).n, '+' + sellPrice(id) + '금화', h('span', { html: '<svg viewBox="0 0 100 80" aria-hidden="true">' + art(id) + '</svg>', style: { display: 'contents' } }));
        }
      } else if (ty === 3) {
        for (let d = 0; d < 5; d++) {
          if (targetWhy(s, seat, k, d)) continue;
          let mx = 0;
          for (let o = 0; o < s.n; o++) if (o !== seat) mx = Math.max(mx, countKind(s.co[o], String(d)));
          btn(d, k === E.REPLICA ? PROPS[d] : KIND_N[d], '나 ' + countKind(s.co[seat], String(d)) + (k === E.MISSION ? ' · 3점이면 성공' : ' · 최다 ' + mx), h('span', { class: 'dot', style: { '--c': d < 4 ? COL[d].c : BIRD_C, flex: 'none' } }));
        }
      } else if (ty === 4) {
        for (let m = 0; m < NEXT_MODES.length; m++) {
          if (targetWhy(s, seat, k, m)) continue;
          btn(m, MODE[NEXT_MODES[m]].n, { n: '보통 경매', b: '두 점을 함께', q: '낙찰자 +' + FEE + '금화', v: '2등 금액만 내요' }[NEXT_MODES[m]]);
        }
      } else if (ty === 5) {
        const N = betLine(s);
        btn(0, N + '금화 이상', '비싸게 팔릴 거야'); btn(1, N + '금화 미만', '싸게 팔리거나 유찰');
      } else if (ty === 6) {
        for (const t of tgList(s, seat, k)) {
          if (targetWhy(s, seat, k, t)) continue;
          const o = t >> 6, id = idOf(s.co[o][t & 63]);
          btn(t, item(id).n, nm(o) + ' · ' + buyPrice(id) + '금화' + (bit(s.sh, o) ? ' · 경비원' : ''), h('span', { html: '<svg viewBox="0 0 100 80" aria-hidden="true">' + art(id) + '</svg>', style: { display: 'contents' } }));
        }
      }
      return box;
    }
    function cardSheet(seat, openK) {
      const s = st; if (!s || s.ph !== 'b') return;
      const hand = s.ev[seat] || '';
      const old = ovEl && ovEl.dataset.cards ? ovEl.querySelector('.sheet') : null, keep = old ? old.scrollTop : 0, was = sheetOpen;
      sheetOpen = openK == null ? -1 : openK;
      const list = h('div', { class: 'au-cl' });
      const cnt = {};
      for (const ch of hand) cnt[idOf(ch)] = (cnt[idOf(ch)] || 0) + 1;
      const kinds = Object.keys(cnt).map(Number).sort((a, b) => CARDS[a].g - CARDS[b].g || a - b);
      if (!kinds.length) list.append(h('p', { class: 'muted', style: { margin: 0 }, text: s.r < EV_EVERY ? '3라운드가 끝나면 첫 카드를 받아요.' : '가진 카드가 없어요. 3라운드마다 한 장씩 받아요.' }));
      const use = (k, tg) => {
        if (!st || st.ph !== 'b' || cantUse(st, seat, k, TARGET[k] ? tg : undefined)) return;
        cardSent = seat + ':' + rk(st);
        closeOv();
        api.buzz(18); api.sfx('card');
        const a = { t: 'card', k };
        if (TARGET[k]) a.tg = tg;
        api.actAs(seat, a);
        renderBot(true);
      };
      for (const k of kinds) {
        const why = cantUse(s, seat, k);
        const row = h('div', { class: 'au-crow' }, h('span', { class: 'au-ci', style: { '--c': CARDS[k].c }, html: cicon(k) }),
          h('div', { class: 'tx' }, h('b', { text: CARDS[k].n + (cnt[k] > 1 ? ' ×' + cnt[k] : '') }), tagsOf(k), h('span', { text: CARDS[k].d }), why ? h('span', { class: 'why', text: why }) : null),
          h('button', { class: 'btn primary', disabled: !!why, text: TARGET[k] ? (sheetOpen === k ? '닫기' : '고르기') : '쓰기',
            onclick: () => { if (TARGET[k]) cardSheet(seat, sheetOpen === k ? -1 : k); else use(k); } }));
        list.append(row);
        if (TARGET[k] && sheetOpen === k && !why) {
          const q = ['', '누구에게 쓸까요?', '어떤 물건을 팔까요?', k === E.REPLICA ? '어떤 색 소품을 받을까요?' : '어떤 종류로 할까요?', '다음 라운드를 어떤 경매로? (지금: ' + (MODE[s.q[s.r + 1]] || MODE.n).n + ')', '낙찰가가 어떻게 될까요? (유찰이면 0)', '누구의 어떤 물건을 살까요?'][TARGET[k]];
          list.append(h('div', { class: 'muted', style: { fontSize: '12px', fontWeight: 700 }, text: q + (k === E.SWAP ? ' (내가 줄 물건: ' + item(idOf(s.co[seat][s.co[seat].length - 1])).n + ')' : '') }));
          list.append(pickerFor(s, seat, k, use));
        }
      }
      modal(h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' } }, h('h2', { text: '이벤트 카드' }),
        h('button', { class: 'btn sm', text: '카드 도감', onclick: () => catalog(0, () => cardSheet(seat, sheetOpen)) })),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '12.5px' }, text: '입찰하기 전에 라운드마다 한 장 쓸 수 있어요. 쓰면 모두에게 알려져요.' }), list);
      ovEl.dataset.cards = '1'; sheetSeat = seat;
      const sh = ovEl.querySelector('.sheet'), pk = ovEl.querySelector('.au-picks');
      if (old) sh.scrollTop = keep; // a state update re-draws the sheet: stay where the player was
      if (pk && sheetOpen !== was && pk.scrollIntoView) pk.scrollIntoView({ block: 'nearest' });
    }
    /* every card in the game, filterable by category */
    function catalog(filter, back) {
      const s = view();
      const inDeck = {};
      if (s && s.ek) for (const ch of s.ek) inDeck[idOf(ch)] = 1;
      const filt = h('div', { class: 'au-filt' });
      const tabs = [{ n: '전체', c: 'var(--brass)' }].concat(CATS);
      tabs.forEach((c, i) => filt.append(h('button', { class: 'btn' + (filter === i ? ' on' : ''), style: { '--c': c.c }, text: c.n, onclick: () => catalog(i, back) })));
      const list = h('div', { class: 'au-cat' });
      CARDS.forEach((C, k) => {
        if (filter && C.g !== filter - 1) return;
        const leg = C.r === 2 && s && s.ek && !inDeck[k];
        list.append(h('div', { class: 'au-crow', style: { opacity: leg ? 0.5 : 1 } }, h('span', { class: 'au-ci', style: { '--c': C.c }, html: cicon(k) }),
          h('div', { class: 'tx' }, h('b', { text: C.n }), tagsOf(k), h('span', { text: C.d + (leg ? ' (이번 판엔 없어요)' : '') }))));
      });
      modal(h('h2', { text: '카드 도감 · ' + CARDS.length + '종' }),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '12px' }, text: '흔함은 자주, 드묾은 가끔 나와요. 전설은 ' + CARDS.filter((c) => c.r === 2).length + '종 중 ' + LEGENDS + '종만 판마다 무작위로 들어가요.' }),
        filt, list);
      if (back) { const b = ovEl.querySelector('.sheet > .btn.block'); if (b) { b.textContent = '돌아가기'; b.onclick = () => back(); } }
    }

    /* ---- pass-the-phone screen (several people on one phone) ---- */
    function syncHand() {
      let want = -1;
      if (st && multi() && st.ph === 'b' && !anim) {
        const p = pendingLocal();
        if (p.length && !p.includes(revealed)) want = p[0];
      }
      const key = want + ':' + (st ? rk(st) : 0);
      if (key === handKey) return;
      handKey = key;
      if (handEl) { handEl.remove(); handEl = null; }
      if (want < 0) return;
      handEl = h('div', { class: 'au-hand' },
        h('span', { class: 'dot', style: { '--c': col(want), width: '18px', height: '18px' } }),
        h('div', { class: 'big', text: nm(want) }),
        h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: '라운드 ' + (st.r + 1) + ' · 몰래 입찰' }),
        h('div', { class: 'muted', text: '다른 사람은 보지 마세요' }),
        h('button', { class: 'btn primary', text: '입찰하기', onclick: () => { revealed = want; api.sfx('click'); syncHand(); renderBot(true); } }));
      wrap.append(handEl);
    }

    /* ---- event card played: a banner everyone sees ---- */
    function showCardEvt(lc) {
      if (evtEl) evtEl.remove();
      clearTimeout(evtT);
      const k = lc.k, C = CARDS[k], who = nm(lc.s);
      const iname = (ch) => (ch ? item(idOf(ch)).n : '');
      const T = lc.t != null && lc.t >= 0 && lc.t < (st ? st.n : 9) ? nm(lc.t) : '';
      let det = C.d;
      switch (k) {
        case E.PEEK: det = '먼저 낸 입찰을 몰래 엿봤어요'; break;
        case E.BLOCK: det = T + ' 이번 경매 출입 금지!'; break;
        case E.STEAL: det = T + '에게서 금화 ' + lc.v + '개를 가져갔어요'; break;
        case E.COLL: det = '모두에게서 금화 ' + lc.v + '개를 모았어요'; break;
        case E.SWAP: det = josa(T, '과', '와') + ' 맞교환: ' + iname(lc.a) + ' ↔ ' + iname(lc.b); break;
        case E.APPR: det = lc.a ? '위작 「' + iname(lc.a) + '」을(를) 없앴어요' : '위작이 없어서 금화 +' + lc.v; break;
        case E.LOAN: det = '금화 +' + LOAN_AMT + ' · 끝날 때 −' + LOAN_PEN + '점'; break;
        case E.TREND: det = (lc.v || '').split('').map((t) => KIND_N[+t]).join('·') + ' 유행! 끝날 때 한 점당 +1점'; break;
        case E.CANCEL: det = '이번 경매가 취소됐어요!'; break;
        case E.SNOOP: det = T + '의 입찰 쪽지를 몰래 봤어요'; break;
        case E.RUMOR: det = T + '의 카드를 몰래 봤어요'; break;
        case E.PREV: det = '다음 경매품을 몰래 미리 봤어요'; break;
        case E.MEGA: det = '지금까지 낸 입찰이 모두 공개됐어요!'; break;
        case E.CAP: det = '이번 입찰은 최대 ' + CAP_AMT + '금화까지만 쳐요'; break;
        case E.FLOOR: det = '이번 경매는 ' + FLOOR_AMT + '금화 이하 입찰이 무효!'; break;
        case E.HAGG: det = '이번 경매가 2등 가격 경매로 바뀌었어요'; break;
        case E.REV: det = '거꾸로! 가장 적게(1 이상) 쓴 사람이 낙찰돼요'; break;
        case E.LOTTO: det = lc.v ? '복권 당첨! 금화 +' + lc.v : '꽝! 아무것도 못 받았어요'; break;
        case E.ROBIN: det = nm(lc.t) + ' → ' + nm(lc.p) + ' 금화 ' + lc.v + '개'; break;
        case E.DIV: det = '배당금 금화 +' + lc.v; break;
        case E.SAVE: det = '금화 ' + SAVE_AMT + '개 저금 · 끝날 때 +' + SAVE_PTS + '점'; break;
        case E.BUNDLE: det = '「' + iname(lc.a) + '」 추가! 2개 묶음이 됐어요'; break;
        case E.SWITCH: det = iname(lc.a) + ' → ' + iname(lc.b) + ' 교체!'; break;
        case E.SELL: det = '「' + iname(lc.a) + '」 판매 · 금화 +' + lc.v; break;
        case E.DUMP: det = T + '에게 위작 「' + iname(lc.a) + '」 떠넘기기!'; break;
        case E.THIEF: det = T + '에게서 「' + iname(lc.a) + '」 훔침! (금화 ' + lc.v + '개 줌)'; break;
        case E.GUARD: det = '경비원이 다음 공격 한 번을 막아줘요'; break;
        case E.LOCK: det = T + '의 이번 입찰은 최대 ' + LOCK_AMT + '까지만!'; break;
        case E.TARIFF: det = josa(T, '이', '가') + ' 낙찰되면 금화 ' + TARIFF_AMT + '개 더!'; break;
        case E.CSTEAL: det = T + '의 카드 한 장을 가져갔어요'; break;
        case E.BADGE: det = KIND_N[lc.t] + ' 전문가! 끝날 때 가장 많으면 +' + BADGE_PTS + '점'; break;
        case E.RESTORE: det = '「' + iname(lc.a) + '」 점수가 2배가 됐어요'; break;
        case E.WIND: det = '「' + iname(lc.a) + '」 = 2마리!'; break;
        case E.EXTEND: det = '경매가 ' + lc.v + '라운드로 늘었어요'; break;
        case E.SHORTEN: det = '경매가 ' + lc.v + '라운드로 줄었어요'; break;
        case E.RIG: det = '다음 라운드는 ' + MODE[lc.m].n + '!'; break;
        case E.AMNESTY: det = '이번 판은 위작이 모두 0점!'; break;
        case E.INFL: det = '끝날 때 금화 5개당 1점으로 올랐어요'; break;
        case E.PAIR: det = '같은 색 2점만 모아도 2배!'; break;
        case E.DUTCH: det = '내림 경매! 입찰을 5 단위로 내려서 쳐요'; break;
        case E.TWICE: det = '모두 낸 뒤 1·2등만 한 번 더 입찰해요'; break;
        case E.ALLPAY: det = '모두 내기! 진 사람도 입찰의 절반을 내요'; break;
        case E.AVG: det = '낙찰자는 평균가만 내요'; break;
        case E.OPEN: det = '이제 입찰하면 금액이 바로 공개돼요'; break;
        case E.BLIND: det = '「' + iname(lc.a) + '」 대신 덮인 물건이 나왔어요!'; break;
        case E.ALLY: det = josa(T, '과', '와') + ' 동맹! 입찰을 합쳐요'; break;
        case E.COLLR: det = '수집가가 ' + lc.v + '금화로 입찰해요'; break;
        case E.MINBID: det = josa(T, '은', '는') + ' 최소 ' + MIN_AMT + '금화를 걸어야 해요'; break;
        case E.SABO: det = T + '의 입찰을 ' + SABO_AMT + ' 낮게 쳐요'; break;
        case E.CBLOCK: det = T + '은(는) 다음 라운드까지 카드 금지!'; break;
        case E.ROTATE: det = '모두의 카드가 다음 사람에게 넘어갔어요'; break;
        case E.ACCUSE: det = T + '의 위작 ' + lc.v + '점 판정! 끝날 때 −' + ACC_PTS * lc.v + '점'; break;
        case E.TAX: det = '재산세로 금화 ' + lc.v + '개가 은행으로'; break;
        case E.INVEST: det = '금화 ' + INV_IN + '개 투자 → ' + (lc.v + 1) + '라운드에 ' + INV_OUT + '개'; break;
        case E.OWNER: det = '이번 낙찰금의 절반은 ' + who + '에게 가요'; break;
        case E.RAFFLE: det = '추첨 결과: ' + nm(lc.t) + ' 금화 +' + lc.v + '!'; break;
        case E.RUSH: det = '모두 금화 +' + RUSH_ALL + ' (' + who + ' +' + RUSH_ME + ')'; break;
        case E.INSTAL: det = '낙찰되면 절반은 끝날 때 내요'; break;
        case E.LEND: det = T + '에게 금화 ' + LEND_OUT + '개를 빌려줬어요 (끝날 때 ' + LEND_BACK + ')'; break;
        case E.BUYOUT: det = T + '의 「' + iname(lc.a) + '」을(를) ' + lc.v + '금화에 샀어요'; break;
        case E.RETURN: det = '「' + lc.a.split('').map(iname).join('+') + '」 반품 · 금화 +' + lc.v; break;
        case E.REPLICA: det = '「' + iname(lc.a) + '」을(를) 받았어요'; break;
        case E.APPRAISE: det = '다음 경매품들이 모두에게 공개됐어요'; break;
        case E.BET: det = '낙찰가 ' + lc.v + (lc.t ? ' 미만' : ' 이상') + '에 걸었어요'; break;
        case E.MISSION: det = '비밀 임무를 받았어요 (' + KIND_N[lc.t] + ' 3점)'; break;
        case E.CURATOR: det = '끝날 때 물건 종류 하나당 +1점 (최대 ' + CUR_MAX + ')'; break;
        case E.FAME: det = '이번에 낙찰되면 +' + FAME_PTS + '점'; break;
        case E.FOCUS: det = '끝날 때 가장 많은 색 한 점당 +1점'; break;
        case E.BOOM: det = '호황! ' + BOOM_N + '라운드 동안 라운드마다 모두 +' + BOOM_AMT; break;
        case E.SLUMP: det = '불황! ' + SLUMP_N + '라운드 동안 입찰은 최대 ' + SLUMP_AMT; break;
        case E.CRASH: det = '시장 붕괴! 남은 금화 20개당 1점'; break;
        case E.TRIPLE: det = '대전시회! 같은 색 4점 이상이면 3배'; break;
        case E.BIRDYR: det = '새의 해! 태엽새 한 마리당 +2점'; break;
        case E.NOFAKE: det = (lc.v + 1) + '라운드 위작 경매가 일반 경매로!'; break;
        case E.FIXED: det = '「' + iname(lc.a) + '」을(를) ' + lc.v + '금화에 샀어요'; break;
        case E.FAKEGIFT: det = T + '에게 위작 「' + iname(lc.a) + '」 선물!'; break;
        case E.HEIR: det = '금화 +' + HEIR_AMT + ' · 대신 남은 금화는 점수 없음'; break;
        case E.FIRST: det = '동점이면 먼저 입찰한 사람이 이겨요'; break;
        case E.DUEL: det = josa(T, '과', '와') + ' 일대일! 나머지는 빠져요'; break;
        case E.SUMPEEK: det = '낸 입찰들의 합계를 몰래 봤어요'; break;
      }
      if (lc.blk) det = T + '의 경비원이 막았어요!';
      evtEl = h('div', { class: 'au-evt', style: { '--c': C.c, top: '6px' } },
        h('span', { class: 'au-ci', style: { '--c': C.c }, html: cicon(k) }),
        h('div', { class: 'tx' }, h('div', { class: 'who' }, h('span', { class: 'dot', style: { '--c': col(lc.s), flex: 'none' } }), who + ' · ', h('b', { text: C.n })), h('div', { class: 'det' + (lc.blk ? ' blk' : ''), text: det })));
      wrap.append(evtEl);
      api.sfx(lc.blk ? 'thud' : CARDS[k].g === 4 || k === E.THIEF || k === E.DUMP ? 'hit' : 'pop'); api.buzz(14);
      const el = evtEl;
      evtT = setTimeout(() => { el.classList.add('bye'); setTimeout(() => el.remove(), 320); if (evtEl === el) evtEl = null; }, 2600 / sp());
    }

    /* ---- new event cards: everyone gets one ---- */
    function showDeal() {
      pendingDeal = false;
      if (dealEl) dealEl.remove();
      clearTimeout(dealT);
      const s = st; if (!s || !s.eo || s.ph !== 'b') return;
      const v = api.viewer();
      const solo = v >= 0 && !multi();
      const close = () => { clearTimeout(dealT); if (dealEl) { dealEl.remove(); dealEl = null; } };
      let body;
      if (solo && s.ev[v]) {
        const k = idOf(s.ev[v][s.ev[v].length - 1]);
        const C = CARDS[k];
        body = h('div', { class: 'au-ecard' + (C.r === 2 ? ' leg' : ''), style: { '--c': C.c, '--rc': RARE[C.r].c } }, h('span', { class: 'rar', text: CATS[C.g].n + ' · ' + RARE[C.r].n }),
          h('span', { html: cicon(k), style: { display: 'contents' } }), h('b', { text: C.n }), h('span', { text: C.d }));
      } else {
        body = h('div', { class: 'au-ecards' }, ...Array.from({ length: s.n }, (_, i) => h('span', { class: 'au-ci', style: { '--c': col(i) }, html: DECK })));
      }
      dealEl = h('div', { class: 'au-deal', onclick: close },
        h('div', { class: 'sheet' },
          h('span', { class: 'label', text: s.r + '라운드 끝' }),
          h('h2', { text: '이벤트 카드 도착!' }), body,
          h('p', { class: 'muted', style: { margin: 0, fontSize: '12.5px' }, text: solo ? '입찰 화면의 [카드] 버튼으로 써요. 입찰 전에 라운드마다 한 장!' : '모두 한 장씩 받았어요. 입찰할 때 [카드] 버튼에서 확인해요.' }),
          s.gz === s.r && ownerOf(s, MYST_IDS[Z_GOOSE]) >= 0 ? h('p', { class: 'au-note', style: { margin: 0, '--c': 'var(--brass)' }, text: '황금 거위: ' + nm(ownerOf(s, MYST_IDS[Z_GOOSE])) + ' 금화 +' + GOOSE_AMT }) : null,
          h('button', { class: 'btn primary block', text: '좋아요' })));
      wrap.append(dealEl);
      api.sfx('card'); api.buzz(15);
      dealT = setTimeout(close, 4500 / sp());
    }

    /* ---- the reveal: every bid flips at once ---- */
    function startReveal(l, prev) {
      endReveal(true);
      anim = { l, prev };
      api.setBusy(true);
      closeOv();
      const it0 = l.lot.split('').map((ch) => item(idOf(ch)).n).join(' + ');
      const ov = h('div', { class: 'au-rev' });
      ov.append(h('div', { class: 'sub', text: '라운드 ' + (l.r + 1) + ' · ' + MODE[l.md].n }), h('h3', { text: it0 }));
      const fx = fxChips(prev || st, l.u, l.x, l.lk, l.tf, l);
      if (l.bn) { // 즉시 구매: nothing to flip either
        ov.append(h('div', { class: 'au-cxbig', style: { color: CARDS[E.BUYNOW].c }, html: cicon(E.BUYNOW) }));
        ov.append(h('div', { class: 'au-res' }, h('span', { style: { color: col(l.w) }, text: nm(l.w) }), ' 즉시 구매 · ', h('span', { class: 'mono', text: l.pay + '금화' })));
        const ex2 = [];
        if (l.gn) ex2.push(gainText(l));
        if (l.ins) ex2.push('위로 보험 +' + INS_AMT + ': ' + l.ins.map(nm).join(', '));
        ex2.forEach((t) => ov.append(h('div', { class: 'au-xl', text: t })));
        ov.append(h('div', { class: 'au-skip', text: '눌러서 넘기기' }));
        wrap.append(ov);
        anim.ov = ov; anim.done = true;
        api.sfx('win'); api.buzz(25);
        later(() => endReveal(), 2400);
        ov.addEventListener('click', () => { if (anim && anim.done) endReveal(); });
        return;
      }
      if (l.cx != null) { // 경매 취소: nothing to flip
        ov.append(h('div', { class: 'au-cxbig', html: cicon(E.CANCEL) }));
        ov.append(h('div', { class: 'au-res' }, h('span', { style: { color: col(l.cx) }, text: nm(l.cx) }), '의 경매 취소! 아무도 돈을 내지 않아요'));
        if (l.ins) ov.append(h('div', { class: 'au-xl', text: '위로 보험 +' + INS_AMT + ': ' + l.ins.map(nm).join(', ') }));
        ov.append(h('div', { class: 'au-skip', text: '눌러서 넘기기' }));
        wrap.append(ov);
        anim.ov = ov; anim.done = true;
        api.sfx('thud'); api.buzz(25);
        later(() => endReveal(), 2400);
        ov.addEventListener('click', () => { if (anim && anim.done) endReveal(); });
        return;
      }
      if (fx.length) ov.append(h('div', { class: 'au-fx' }, ...fx));
      const nc = l.b.length <= 3 ? l.b.length : l.b.length === 4 ? 2 : 3;
      const grid = h('div', { class: 'au-grid', style: { gridTemplateColumns: 'repeat(' + nc + ',92px)' } });
      const cards = l.b.map((v, i) => {
        const c = col(i), out = ((l.x || 0) >> i) & 1;
        const fi = h('div', { class: 'au-fi', style: { transitionDuration: (0.55 / sp()) + 's' } },
          h('div', { class: 'au-face au-back', style: { background: 'repeating-linear-gradient(45deg,' + c + ' 0 7px,color-mix(in srgb,' + c + ' 70%,#000) 7px 14px)' }, text: '?' }),
          h('div', { class: 'au-face au-front', style: { '--c': c } }, h('span', { class: 'who', text: nm(i) }),
            out ? h('span', { class: 'amt', text: l.t2 ? '1차 탈락' : l.u && l.u.indexOf(E.DUEL) >= 0 ? '빠짐' : '출입 금지' }) : h('span', { class: 'amt' }, String(v), h('small', { text: '금화' }))));
        const el = h('div', { class: 'au-flip' + (out ? ' out' : '') }, fi);
        if (l.u && l.u[i] === E.SPON && v > 0 && !out) el.append(h('span', { class: 'au-tagx', text: '+' + SPON_ADD }));
        if (bit(l.sb, i) && v > 0 && !out) el.append(h('span', { class: 'au-tagx bad', text: '−' + SABO_AMT }));
        if (l.al && l.al[1] === i && !out) el.append(h('span', { class: 'au-tagx', text: '동맹' }));
        if (bit(l.ad, i) && !out) el.append(h('span', { class: 'au-tagx ' + (v === 0 ? 'bad' : 'cap'), text: (bit(l.lk, i) && v > 0 ? '잠금 ' : v === 0 ? '무효 ' : '상한 ') + (l.rb ? l.rb[i] + '→' + v : '') }));
        grid.append(el);
        return el;
      });
      ov.append(grid);
      const res = h('div', { class: 'au-res', text: ' ' });
      const xl = h('div', { class: 'au-xl' });
      ov.append(res, xl, h('div', { class: 'au-skip', text: '눌러서 넘기기' }));
      wrap.append(ov);
      anim.ov = ov;
      api.sfx('whoosh');
      later(() => { cards.forEach((c, i) => setTimeout(() => c.classList.add('on'), i * 25)); api.sfx('card'); api.buzz(15); anim && (anim.flipped = true); }, 650);
      later(() => {
        if (!anim) return;
        const names = l.lot.split('').map((ch) => item(idOf(ch)).n).join(' + ');
        const wu = l.u && l.w >= 0 ? l.u[l.w] : -1;
        if (l.tw) { // 봉투 두 번: the first envelope
          cards.forEach((c, i) => { if (l.tw.indexOf(i) >= 0) { c.classList.add('win'); c.append(h('span', { class: 'au-stamp', text: '2차로' })); } else c.classList.add('lose'); });
          res.innerHTML = '';
          res.append('봉투 두 번! ', h('span', { style: { color: col(l.tw[0]) }, text: nm(l.tw[0]) }), ' · ', h('span', { style: { color: col(l.tw[1]) }, text: nm(l.tw[1]) }), '만 한 번 더 입찰해요');
          api.sfx('pop'); api.buzz(20);
        } else if (l.w === -3) { res.textContent = '수집가가 ' + l.cv + '금화로 가져갔어요!'; cards.forEach((c) => c.classList.add('lose')); api.sfx('thud'); }
        else if (l.w < 0) { res.textContent = l.md === 'f' ? '모두 빠져서 위작이 버려졌어요' : l.ad ? '유찰 — 쳐주는 입찰이 없어요' : '유찰 — 아무도 입찰하지 않았어요'; cards.forEach((c) => c.classList.add('lose')); api.sfx('thud'); }
        else {
          cards.forEach((c, i) => { if (i === l.w) { c.classList.add('win'); c.append(h('span', { class: 'au-stamp' + (l.md === 'f' ? ' bad' : ''), text: l.md === 'f' ? '떠안음' : '낙찰' })); } else c.classList.add('lose'); });
          res.innerHTML = '';
          if (l.md === 'f') {
            res.append(h('span', { style: { color: col(l.w) }, text: nm(l.w) }), '이(가) 위작을 떠안아요 · 위로금 ', h('span', { class: 'mono', text: '+' + l.pay }));
            api.sfx('lose'); api.buzz(25);
            api.toast(nm(l.w) + ': ' + names + ' 떠안음');
          } else {
            res.append(h('span', { style: { color: col(l.w) }, text: nm(l.w) }), ' 낙찰 · ', h('span', { class: 'mono', text: l.pay + '금화' }),
              (l.rf || 0) & RF_REV ? ' (거꾸로 경매)' : wu === E.COUP ? ' (반값)' : l.al && l.al[0] === l.w ? ' (동맹)' : l.md === 'v' ? ' (2등 가격)' : (l.rf || 0) & RF_AVG ? ' (평균가)' : l.md === 'q' ? ' (수수료 포함)' : (l.rf || 0) & RF_DUTCH ? ' (내림)' : '');
            api.sfx('win'); api.buzz(25);
          }
          if (l.tie) res.append(h('div', { class: 'sub', style: { marginTop: '4px' }, text: '동점 → ' + (l.u && l.u.some((k) => k === E.PRIO) ? '우선권 카드 · ' : '') + ((l.rf || 0) & RF_FIRST ? '먼저 낸 사람' : '모래시계 · 우선권이 가까운 쪽으로') }));
        }
        const extra = [];
        if (l.ex) extra.push('덤 상자: ' + item(idOf(l.ex)).n + ' 추가!');
        if (wu === E.CERT && l.md !== 'f') extra.push('명품 인증서: 이 물건 점수 2배');
        if (l.ins) extra.push('위로 보험 +' + INS_AMT + ': ' + l.ins.map(nm).join(', '));
        if (l.tx) extra.push('추가 관세: ' + nm(l.w) + ' 금화 ' + l.tx + '개 더 냄');
        if (l.p2) extra.push('동맹: ' + nm(l.al[1]) + ' ' + l.p2 + '금화 내고 +' + ALLY_PTS + '점');
        else if (l.al && l.al[0] === l.w) extra.push('동맹: ' + nm(l.al[1]) + ' +' + ALLY_PTS + '점');
        if (l.gn) extra.push(gainText(l));
        if (l.ow != null && l.w >= 0 && l.ow !== l.w) extra.push('경매장 주인: ' + nm(l.ow) + ' 금화 +' + Math.floor((l.pay + (l.p2 || 0)) / 2));
        if (l.ap) extra.push('모두 내기: 진 사람들이 금화 ' + l.ap + '개를 냈어요');
        if (wu === E.FAME) extra.push('명성 +' + FAME_PTS + '점');
        if (wu === E.INSTAL) extra.push('할부: ' + Math.floor(l.pay / 2) + '금화는 끝날 때 내요');
        if (l.bt) l.bt.forEach(([i, a]) => extra.push('예언 내기: ' + nm(i) + (a > 0 ? ' 적중! +' + a : ' 빗나감 ' + a)));
        if (l.cv && l.w !== -3 && l.w >= 0) extra.push('수집가 ' + l.cv + '금화를 넘었어요');
        if (l.md === 'f' && l.u && l.u.some((k, i) => k === E.COUP && i !== l.w)) extra.push('반값 쿠폰: ' + l.u.map((k, i) => (k === E.COUP && i !== l.w ? nm(i) : '')).filter(Boolean).join(', ') + ' 반만 냄');
        extra.forEach((t) => xl.append(h('span', { text: t })));
        anim && (anim.done = true);
      }, 1350);
      later(() => endReveal(), 3300 + (l.u ? 500 : 0) + (l.tw ? 300 : 0));
      ov.addEventListener('click', () => { if (anim && anim.done) endReveal(); });
    }
    function gainText(l) {
      const g = l.gn, t = [];
      if (g.c) t.push('금화 +' + g.c);
      if (g.k) t.push('이벤트 카드 ' + g.k + '장');
      return nm(l.w) + ': ' + t.join(' · ') + ' (특수 물건)';
    }
    function endReveal(silent) {
      if (!anim) return;
      timers.splice(0).forEach(clearTimeout);
      if (anim.ov) anim.ov.remove();
      anim = null;
      api.setBusy(false);
      if (!silent) { midKey = ''; renderAll(); if (pendingDeal) showDeal(); }
    }

    /* ---- sheets ---- */
    function closeOv() { if (ovEl) { ovEl.remove(); ovEl = null; } sheetSeat = -1; }
    function modal(...kids) {
      closeOv();
      const box = h('div', { class: 'sheet' }, ...kids, h('button', { class: 'btn block', text: '닫기', onclick: closeOv }));
      ovEl = h('div', { class: 'au-ov' }, box);
      ovEl.addEventListener('click', (e) => { if (e.target === ovEl) closeOv(); });
      wrap.append(ovEl);
      api.sfx('click');
    }
    function usesText(us) {
      const r = [];
      for (let j = 0; j + 1 < (us || '').length; j += 2) r.push(nm(+us[j]) + ' ' + CARDS[idOf(us[j + 1])].n);
      return r.join(' · ');
    }
    function histSheet() {
      const s = view(); if (!s) return;
      const list = h('div', { class: 'au-hl' });
      if (!s.h.length) list.append(h('p', { class: 'muted', style: { margin: 0 }, text: '아직 끝난 경매가 없어요.' }));
      s.h.slice().reverse().forEach((e, k) => {
        const rno = s.h.length - k;
        const [lot, md, w, pay, all, us] = e;
        const names = lot.split('').map((ch) => item(idOf(ch)).n).join('+');
        const c = itemColor(idOf(lot[0]));
        const who = w === -3 ? '수집가' : w < 0 ? '유찰' : nm(w);
        list.append(h('div', { class: 'row' },
          h('span', { class: 'sw', style: { background: c } }),
          h('span', { class: 'mono muted', style: { flex: 'none', fontSize: '11px' }, text: 'R' + rno }),
          h('span', { class: 't' }, names, md !== 'n' ? h('span', { class: 'muted', text: ' · ' + MODE[md].n }) : null),
          w >= 0 ? h('span', { class: 'dot', style: { '--c': col(w), flex: 'none' } }) : null,
          h('span', { class: 'm', text: w === -2 ? '취소' : w < 0 ? who : md === 'f' ? who + ' +' + pay : who + ' ' + pay })));
        if (all) list.append(h('div', { class: 'all', style: { paddingLeft: '22px', marginTop: '-3px' }, text: '입찰: ' + all.map((x, i) => nm(i) + ' ' + x).join(' · ') }));
        if (us) list.append(h('div', { class: 'all', style: { paddingLeft: '22px', marginTop: '-3px', color: '#c9b2f0' }, text: '카드: ' + usesText(us) }));
      });
      modal(h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' } }, h('h2', { text: '경매 기록' }),
        h('button', { class: 'btn sm', text: '물건 도감', onclick: () => itemCatalog(0, histSheet) })),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '12px' }, text: s.sa ? '모든 입찰액을 기록해요(설정).' : '낙찰가만 남아요. 진 입찰액은 공개 순간에만 볼 수 있어요.' }), list);
    }
    /* every item in the game, by group, with what the special ones do */
    const ICAT = [
      { n: '특수', f: (it) => 'pkhymxaz'.indexOf(it.k) >= 0 || it.pr },
      { n: '색 물건', f: (it) => it.k === 'c' && !it.pr },
      { n: '태엽새', f: (it) => it.k === 'b' },
      { n: '위작', f: (it) => it.k === 'f' },
    ];
    function itemCatalog(tab, back) {
      const s = view();
      const filt = h('div', { class: 'au-filt' });
      ICAT.forEach((c, i) => filt.append(h('button', { class: 'btn' + (tab === i ? ' on' : ''), text: c.n, onclick: () => itemCatalog(i, back) })));
      const grid = h('div', { class: 'au-col' });
      ITEMS.forEach((it, id) => {
        if (!ICAT[tab].f(it)) return;
        grid.append(h('div', { class: 'au-mini', style: { '--c': itemColor(id) }, title: itemHint(id) },
          h('div', { html: '<svg viewBox="0 0 100 80" aria-hidden="true">' + art(id) + '</svg>' }),
          h('span', { class: 'nmm', text: it.n }),
          h('span', { class: 'mono', text: itemTag(id) + ' ' + itemVal(id) })));
      });
      const th = s && s.th != null ? s.th.split('').map((t) => THEMES[+t].n).join(' · ') : '';
      const rules = tab === 0 ? h('div', { class: 'au-bd', style: { gridTemplateColumns: '1fr' } },
        ...['p', 'k', 'h', 'y', 'm', 'x', 'a'].map((k) => h('span', { style: { textAlign: 'left', fontFamily: 'var(--f-body)' } }, h('b', { style: { color: SPEC[k].c }, text: SPEC[k].n + ' ' }), SPEC[k].d)),
        h('span', { style: { textAlign: 'left', fontFamily: 'var(--f-body)' } }, h('b', { style: { color: COL[2].c }, text: '전시 소품 ' }), '1점 · 그 색 물건 1개로 쳐요 (같은 색 세트 · 네 색)'),
        ...MYST.map((m, i) => h('span', { style: { textAlign: 'left', fontFamily: 'var(--f-body)' } }, h('b', { style: { color: SPEC.z.c }, text: m[0] + ' ' }), m[1] + '점 · ' + MYST_D[i]))) : null;
      modal(h('h2', { text: '물건 도감 · ' + ITEMS.length + '종' }),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '12px' }, text: '판마다 색 물건 20점 · 태엽새 5마리 · 걸작 1~2점 · 특수 테마 1~3가지가 섞여 나와요.' + (th ? ' 이번 판 특수: ' + th + '.' : '') }),
        filt, rules, grid);
      if (back) { const b = ovEl.querySelector('.sheet > .btn.block'); if (b) { b.textContent = '돌아가기'; b.onclick = () => back(); } }
    }
    function badgeText(s, i) {
      const r = [];
      for (let j = 0; j + 1 < (s.gl || '').length; j += 2) if (+s.gl[j] === i) r.push(KIND_N[+s.gl[j + 1]]);
      return r.length ? ' (' + r.join('·') + ')' : '';
    }
    function colSheet(i) {
      const s = view(); if (!s) return;
      const sc = scoreOf(s, i);
      const grid = h('div', { class: 'au-col' });
      const ids = s.co[i].split('').map(idOf).sort((a, b) => a - b);
      ids.forEach((id) => {
        const cf = s.cf && s.cf.indexOf(chOf(id)) >= 0;
        grid.append(h('div', { class: 'au-mini', style: { '--c': itemColor(id) } },
          h('div', { html: '<svg viewBox="0 0 100 80" aria-hidden="true">' + art(id) + '</svg>' }),
          h('span', { class: 'nmm', text: item(id).n }),
          h('span', { class: 'mono', text: itemTag(id) + ' ' + (item(id).k === 'b' ? '' : itemVal(id)) + (cf ? ' ×2' : '') })));
      });
      const need = s.gf & GF_PAIR ? 2 : 3;
      const sets = COL.map((c, k) => sc.cnt[k] ? c.n + ' ' + sc.cnt[k] + ((s.gf & GF_TRIPLE) && sc.cnt[k] >= 4 ? '(×3)' : sc.cnt[k] >= need ? '(×2)' : '') : null).filter(Boolean).join(' · ');
      const bd = [
        h('span', { text: '물건 점수' }), h('span', { text: String(sc.base) }),
        h('span', { text: '같은 색 ' + (s.gf & GF_PAIR ? 2 : 3) + '점 이상 ×2' }), h('span', { text: '+' + sc.bonus }),
        h('span', { text: '태엽새 ' + sc.birds + '마리 (마릿수²)' }), h('span', { text: '+' + sc.bird }),
        h('span', { text: '네 색 모두' }), h('span', { text: '+' + sc.rb }),
        h('span', { text: s.gf & GF_AMN && sc.fake0 ? '위작 (사면: ' + sc.fake0 + ' → 0)' : '위작' }), h('span', { text: String(sc.fake) }),
        h('span', { text: '특수 물건 (짝·전집·상자·저주 …)' }), h('span', { text: (sc.sp >= 0 ? '+' : '') + sc.sp }),
      ];
      if (s.eo) bd.push(h('span', { text: '유행 바람' }), h('span', { text: '+' + sc.trend }), h('span', { text: '카드 점수 (대출·적금·명성·동맹 …)' }), h('span', { text: (sc.ev > 0 ? '+' : '') + sc.ev }),
        h('span', { text: '전문가 배지' + badgeText(s, i) }), h('span', { text: '+' + sc.bd }));
      if (sc.cu || sc.fo || sc.ms) bd.push(h('span', { text: '큐레이터 · 한 우물 · 비밀 임무' }), h('span', { text: (sc.cu + sc.fo + sc.ms >= 0 ? '+' : '') + (sc.cu + sc.fo + sc.ms) }));
      const dc = s.dc ? s.dc[i] : 0, why0 = bit(s.nc, i) ? ' · 유산 상속: 0점' : sc.cursed ? ' · 저주: 0점' : '';
      bd.push(h('span', { text: '금화 ' + s.c[i] + (dc ? (dc > 0 ? ' +' : ' ') + dc + '(빚·빌려준 돈)' : '') + ' (' + coinRate(s.gf) + '당 1점)' + why0 }), h('span', { text: (sc.cp >= 0 ? '+' : '') + sc.cp }),
        h('b', { text: '합계' }), h('b', { class: 'mono', style: { textAlign: 'right' }, text: sc.total + '점' }));
      modal(h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, h('span', { class: 'dot', style: { '--c': col(i), width: '16px', height: '16px' } }), h('h2', { text: nm(i) })),
        ids.length ? grid : h('p', { class: 'muted', style: { margin: 0 }, text: '아직 모은 물건이 없어요.' }),
        h('div', { class: 'au-bd' }, ...bd),
        sets ? h('div', { class: 'muted', style: { fontSize: '12px' }, text: sets }) : null,
        s.eo ? h('div', { class: 'muted', style: { fontSize: '12px' }, text: '이벤트 카드 ' + (s.ev[i] || '').length + '장 (내용은 비밀)' }) : null);
    }

    function renderAll() { renderTop(); renderMid(); renderBot(); syncHand(); }
    const ro = new ResizeObserver(() => { midKey = ''; renderMid(); });
    ro.observe(mid);

    return {
      update(next, prev) {
        st = next;
        cardSent = '';
        if (!prev) { revealed = -1; endReveal(true); pendingDeal = false; }
        const l = next.last;
        if (prev && prev !== next && next.lc && (!prev.lc || prev.lc.id !== next.lc.id)) showCardEvt(next.lc);
        if (prev && prev !== next && next.eo && next.dr >= 0 && next.dr !== prev.dr) pendingDeal = true;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          revealed = -1;
          startReveal(l, prev);
        } else if (prev && prev !== next && next.seq < prev.seq) { endReveal(true); pendingDeal = false; }
        if (next.ph === 'b') for (const k in sent) if (sent[k] !== rk(next)) delete sent[k];
        // keep an open card sheet in sync (e.g. 엿보기 becomes usable once someone bids)
        if (ovEl && ovEl.dataset.cards && sheetSeat >= 0 && !anim) {
          if (next.ph === 'b' && next.b[sheetSeat] == null && next.u[sheetSeat] < 0) cardSheet(sheetSeat, sheetOpen); else closeOv();
        }
        renderAll();
        if (pendingDeal && !anim) showDeal();
      },
      destroy() {
        timers.splice(0).forEach(clearTimeout);
        clearTimeout(evtT); clearTimeout(dealT);
        ro.disconnect();
        closeOv(); if (handEl) handEl.remove();
        wrap.remove(); style.remove();
        api.setBusy(false);
      },
    };
  }

  /* ---------- 도감 (게임 밖에서도 열리는 전체 목록 — 데이터 표에서 만들어요) ---------- */
  const cxSvg = (id) => '<svg viewBox="0 0 100 80" aria-hidden="true" style="width:100%;height:100%;display:block">' + art(id) + '</svg>';
  function codex(el) {
    const h = L.h;
    const sub = (t, c) => h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', margin: '8px 0 0', fontWeight: 800, fontSize: '14px', color: c || 'var(--brass)' } },
      h('i', { style: { width: '10px', height: '10px', borderRadius: '3px', background: c || 'var(--brass)', flex: 'none' } }), t);
    const note = (t) => h('p', { class: 'note', style: { margin: 0, fontSize: '12.5px', color: 'var(--muted)', lineHeight: 1.5 }, text: t });
    const row = (ic, name, tag, desc, wide) => h('div', { class: 'cx-row' },
      h('span', { class: 'cx-ic', style: wide ? { width: '56px', height: '45px', padding: 0, overflow: 'hidden', background: 'none' } : {}, html: ic }),
      h('div', { class: 'cx-tx' }, h('div', { class: 'cx-nm' }, h('b', { text: name }), tag ? h('span', { class: 'cx-tag', text: tag }) : null), desc ? h('div', { class: 'cx-d', text: desc }) : null));
    const grid = (ids, label) => h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: '6px' } },
      ...ids.map((id) => h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px', padding: '4px', borderRadius: '10px', background: 'var(--surface-2)', borderBottom: '3px solid ' + itemColor(id), minWidth: 0 } },
        h('div', { style: { aspectRatio: '5/4', borderRadius: '6px', overflow: 'hidden' }, html: cxSvg(id) }),
        h('b', { style: { fontSize: '11.5px', lineHeight: 1.2, wordBreak: 'keep-all' }, text: item(id).n }),
        h('span', { style: { fontSize: '11px', color: 'var(--muted)', fontFamily: 'var(--f-mono)' }, text: label(id) }))));
    const range = (f) => ITEMS.map((_, i) => i).filter((i) => f(item(i)));
    const ptsOf = (id) => { const v = item(id).v; return (v > 0 ? '+' : '') + v + '점'; };

    const tabs = [
      { h: '물건', n: ITEMS.length, build(p) {
        p.append(note('판마다 색 물건 20점 · 걸작 1~2점 · 태엽새 5마리 · 위작 3점 · 특수 테마 1~3가지가 섞여 나와요. 모든 물건이 다 나오지는 않아요.'));
        p.append(sub('점수 규칙'));
        p.append(h('div', { class: 'cx-row', style: { flexDirection: 'column', gap: '3px', fontSize: '12.5px', lineHeight: 1.5 } },
          ...['색 물건: 적힌 점수(2~6점). 걸작은 8점이고 그 색으로 쳐요.',
            '같은 색을 3점 이상 모으면 그 색 물건 점수가 2배!',
            '네 색(회화·도자기·보석·조각)을 모두 한 점 이상 가지면 +' + RAINBOW + '점.',
            '태엽새: 마릿수의 제곱 (1마리 1 · 2마리 4 · 3마리 9 · 4마리 16점 …).',
            '위작: −3~−5점.',
            '특수 물건: 아래 설명대로 (짝 맞추기 +' + PAIR_BONUS + ', 전집 2권 +' + BOOK2 + ' · 3권 +' + BOOK3 + ', 열쇠로 연 상자 ×' + CHEST_X + ').',
            '남은 금화 10개당 1점 (저주가 있으면 0점).',
            '최종 점수 = 물건 + 세트 보너스 + 태엽새 + 특수 + 카드 점수 + 남은 금화 점수.'].map((t) => h('div', { text: '• ' + t }))));
        COL.forEach((c, ci) => {
          const ids = range((it) => it.k === 'c' && !it.pr && it.c === ci).sort((a, b) => item(a).t - item(b).t || item(a).x - item(b).x);
          p.append(sub(c.n + ' · ' + ids.length + '점', c.c));
          p.append(grid(ids, (id) => (item(id).mp ? '걸작 ' : '') + ptsOf(id)));
        });
        p.append(sub('태엽새 · ' + BIRD_IDS.length + '종', BIRD_C), note('한 마리는 점수가 없고, 모은 마릿수의 제곱이 점수예요. 판마다 5마리가 나와요.'));
        p.append(grid(BIRD_IDS, () => '마릿수²'));
        p.append(sub('위작 · ' + FAKE_IDS.length + '종', FAKE_C), note('「위작 주의」 경매에서 가장 적게 건 사람이 떠안아요. 판마다 3점.'));
        p.append(grid(FAKE_IDS, ptsOf));
        const SPG = [['p', '짝 물건'], ['k', '전집'], ['h', '보물상자'], ['y', '열쇠'], ['m', '금화 물건'], ['x', '저주'], ['a', '부적'], ['c', '전시 소품'], ['z', '신비한 물건']];
        SPG.forEach(([k, nm]) => {
          const ids = k === 'c' ? PROP_IDS.slice() : range((it) => it.k === k);
          p.append(sub(nm + ' · ' + ids.length + '종', k === 'c' ? COL[2].c : SPEC[k].c));
          ids.forEach((id) => p.append(row(cxSvg(id), item(id).n, itemTag(id) + ' ' + valLong(id), itemHint(id), 1)));
        });
      } },
      { h: '특수 테마', n: THEMES.length, build(p) {
        p.append(note('특수 테마는 8라운드면 1가지, 12라운드면 2가지, 16라운드면 3가지가 무작위로 섞여요. 테마마다 아래 물건 중 몇 점이 나와요.'));
        const KS = { p: ['p'], k: ['k'], h: ['h', 'y'], m: ['m'], x: ['x', 'a'], c: [], z: ['z'] };
        const WHAT = { p: '짝 2쌍(4점)', k: '같은 책 1~3권 한 질', h: '보물상자 2개 + 열쇠 1개', m: '금화 물건 2점', x: '저주 물건 2점 + 부적 1점', c: '전시 소품 2점', z: '신비한 물건 2점' };
        THEMES.forEach((T) => {
          const ids = T.k === 'c' ? PROP_IDS.slice() : range((it) => KS[T.k].indexOf(it.k) >= 0);
          const rule = T.k === 'c' ? '1점 · 그 색 물건 1개로 쳐요 (같은 색 세트 · 네 색 채우기)' : T.k === 'z' ? MYST.map((m, i) => m[0] + ': ' + MYST_D[i]).join(' / ')
            : KS[T.k].map((k) => SPEC[k].n + ': ' + SPEC[k].d).join(' / ');
          p.append(row(cxSvg(ids[0]), T.n, WHAT[T.k], rule + '. 후보: ' + ids.map((id) => item(id).n).join(' · '), 1));
        });
        p.append(sub('경매 방식'));
        p.append(note('라운드 수에 따라 특수 경매가 섞여요: 8라운드 위작 1 · 묶음 1 · 수수료 1 · 2등 가격 1 / 12라운드 위작 2 / 16라운드 위작 3 · 묶음 2.'));
        Object.keys(MODE).forEach((k) => p.append(row(k === 'f' ? '🎭' : k === 'b' ? '📦' : k === 'q' ? '🔨' : k === 'v' ? '🥈' : '💰', MODE[k].n, '', MODE[k].d)));
      } },
      { h: '이벤트 카드', n: CARDS.length, build(p) {
        p.append(note('3라운드마다 모두 한 장씩 받아요(옵션으로 끌 수 있어요). 입찰 전에 라운드마다 한 장 쓸 수 있고, 남긴 카드는 점수가 없어요.'));
        p.append(note('흔함은 자주, 드묾은 가끔 나와요. 전설 ' + CARDS.filter((c) => c.r === 2).length + '종 중 ' + LEGENDS + '종만 판마다 무작위로 들어가요.'));
        CATS.forEach((cat, g) => {
          const ks = CARDS.map((_, k) => k).filter((k) => CARDS[k].g === g);
          p.append(sub(cat.n + ' · ' + ks.length + '장', cat.c));
          ks.forEach((k) => {
            const C = CARDS[k], r = row(cicon(k), C.n, RARE[C.r].n + (C.tg ? ' · 대상 고르기' : ''), C.d + (C.nf ? ' (위작 경매엔 못 써요)' : ''));
            r.firstChild.style.color = C.c;
            p.append(r);
          });
        });
      } },
    ];
    const bar = h('div', { class: 'chips' }), pane = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
    const show = (k) => {
      pane.textContent = '';
      [...bar.children].forEach((b, i) => b.classList.toggle('on', i === k));
      tabs[k].build(pane);
      const sh = el.closest && el.closest('.sheet'); if (sh) sh.scrollTop = 0;
    };
    tabs.forEach((t, k) => bar.append(h('button', { class: 'btn sm', text: t.h + ' ' + t.n, onclick: () => show(k) })));
    el.append(bar, pane);
    show(0);
  }

  const ICON = '<path d="M10 22l14-14 8 8-14 14z" fill="currentColor"/><path d="M26 22l16 16" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><rect x="8" y="44" width="26" height="6" rx="2" fill="currentColor"/><rect x="34" y="8" width="16" height="20" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M38 18l3 3 5-6" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/><circle cx="44" cy="44" r="6" fill="none" stroke="currentColor" stroke-width="3"/>';

  L.register({
    id: 'auction', name: '소리 없는 경매', tag: '비밀 입찰', cat: '파티', icon: ICON, tint: '#5a2440',
    blurb: '경매품이 나오면 모두 동시에 몰래 금화를 걸어요. 가장 많이 건 사람이 낙찰! 물건 141종 · 짝 맞추기 · 전집 · 보물상자 같은 특수 물건을 모으고 위작은 피해요. 3라운드마다 이벤트 카드(87종)도 받아요.',
    minPlayers: 3, maxPlayers: 6, defaultPlayers: 4, hidden: true, aiDelay: 900, aiDelayFor,
    options: [
      { id: 'rounds', label: '라운드', choices: [{ v: 8, label: '8' }, { v: 12, label: '12' }, { v: 16, label: '16' }], def: 12 },
      { id: 'ev', label: '이벤트 카드', choices: [{ v: 1, label: '켜기' }, { v: 0, label: '끄기' }], def: 1 },
      { id: 'all', label: '기록에 진 입찰도', choices: [{ v: 0, label: '숨기기' }, { v: 1, label: '모두 보기' }], def: 0 },
    ],
    quick: [
      '금화 100개로 경매품을 사 모아, 끝났을 때 점수가 가장 높으면 이겨요.',
      '매 라운드: 물건 하나가 나오면 모두 동시에 몰래 금화를 걸고 「입찰」. 가장 많이 건 사람이 그 돈을 내고 가져가요.',
      '점수: 물건 점수 + 같은 색 3점 이상이면 그 색 2배 + 태엽새는 마릿수² + 특수 물건 + 남은 금화 10개당 1점. 위작(−점)은 피하세요!',
      '특수 물건은 경매품 아래 한 줄 설명을 보세요 (짝을 맞추면 8점, 열쇠로 상자를 열면 3배 …).',
    ],
    rules: [
      { h: '목표', p: [
        '모두 금화 100개로 시작해요. 경매에 나온 물건을 사 모아요.',
        '끝났을 때 점수가 가장 높은 사람이 이겨요. 점수가 같으면 금화가 많은 사람이 이겨요.'] },
      { h: '준비 (자동)', p: [
        '라운드 수는 기본 12(설정에서 8 · 12 · 16)예요. 라운드마다 물건이 하나씩 나와요.',
        '물건은 ' + ITEMS.length + '가지 중에서 판마다 섞여 나와요: 색 물건(회화 · 도자기 · 보석 · 조각) 색마다 2~6점짜리 한 점씩, 걸작(8점) 1~2점, 태엽새 16종 중 5마리, 위작 12종 중 3점.',
        '여기에 특수 테마가 8라운드면 1가지, 12라운드면 2가지, 16라운드면 3가지 섞여요 (아래 「특수 물건」).',
        '판에 나오는 물건이 라운드 수보다 많아서, 모든 물건이 다 나오지는 않아요.',
        '몇몇 라운드는 특수 경매예요(아래 「특수 경매」).'] },
      { h: '차례에 할 일 (모두 동시에)', p: [
        '① 가운데에 나온 물건과 경매 방식(가운데 알약 모양 안내)을 봐요. 「낙찰되면 +○점」에 내가 얻을 점수가 미리 보여요.',
        '② −/+ 버튼, 슬라이더, 0 · −5 · +5 · +10 · 최대 버튼으로 걸 금액을 맞춰요. 0은 포기예요.',
        '③ (이벤트 카드가 있으면) 입찰하기 전에 「카드」로 한 장 쓸 수 있어요.',
        '④ 「○금화 입찰」을 눌러요. 다른 사람은 내 금액을 몰라요.',
        '⑤ 모두 입찰하면 입찰 카드가 한꺼번에 뒤집혀요. 가장 많이 건 사람이 그 금액을 내고 물건을 가져가요. 모두 0이면 유찰(물건은 사라져요).'] },
      { h: '동점일 때', p: [
        '위쪽 「동점 우선」에 표시된 사람부터 시계 방향으로 가장 가까운 사람이 이겨요.',
        '우선권은 라운드마다 한 칸씩 돌아가요.',
        '우선권 카드를 쓴 사람, 그다음 모래시계를 가진 사람이 먼저 이겨요.'] },
      { h: '점수·승리', p: [
        '색 물건: 적힌 점수(2~6점). 걸작은 8점이고 그 색 물건으로 쳐요.',
        '같은 색을 3점 이상 모으면 그 색 물건 점수가 2배!',
        '네 색을 모두 한 점 이상 가지면 +' + RAINBOW + '점.',
        '태엽새: 마릿수의 제곱(1마리 1점, 2마리 4점, 3마리 9점, 4마리 16점 …). 많이 모을수록 커요.',
        '위작: −3~−5점.',
        '남은 금화 10개당 1점(나머지는 버림). 돈을 아끼는 것도 점수예요.',
        '특수 물건: 아래 「특수 물건」을 보세요.',
        '최종 점수 = 물건 점수 + 세트 보너스 + 태엽새 + 특수 물건 + (카드 점수) + 남은 금화 점수.'] },
      { h: '특수 물건', p: [
        '짝 물건(장갑 · 촛대 · 원앙 · 해치상 · 노리개): 한 짝은 2점, 두 짝을 다 모으면 8점.',
        '전집(별자리 도감 · 요리 비법서 · 마법 주문서 1~3권): 권마다 2점, 같은 책 2권이면 +3, 3권 모두면 +8.',
        '보물상자(나무 2 · 은 3 · 황금 4점)와 열쇠(1점): 열쇠 하나가 상자 하나를 열어 그 상자 점수가 3배! (비싼 상자부터 열려요)',
        '금화 물건(은화 주머니 · 금화 자루 · 보물 항아리 · 해적 금고 · 왕실 금괴): 점수는 없지만 낙찰하면 바로 15~30금화를 받아요.',
        '저주 물건(5~7점): 점수가 높지만 하나라도 있으면 끝날 때 남은 금화가 점수가 안 돼요. 부적(1점)이 있으면 저주가 모두 풀려요.',
        '전시 소품(1점): 그 색 물건 1개로 쳐요 → 같은 색 3점 · 네 색 모두를 채우기 쉬워요.',
        '신비한 물건: 요술 램프(낙찰하면 카드 2장) · 행운 고양이(카드 1장) · 황금 거위(3라운드마다 금화 +5) · 모래시계(동점이면 내가 이겨요) · 망원경(다음 경매품을 미리 봐요).',
        '「기록」 → 「물건 도감」에서 모든 물건 그림과 설명을 볼 수 있어요.'] },
      { h: '특수 경매', p: [
        '2개 묶음: 물건 두 점이 함께 나와 낙찰자가 둘 다 가져가요.',
        '경매사 수수료: 낙찰자는 입찰액에 수수료 ' + FEE + '금화를 더 내요(그래서 가진 돈 −' + FEE + '까지만 걸 수 있어요).',
        '2등 가격: 가장 많이 건 사람이 낙찰받지만, 두 번째로 높은 입찰액만 내요.',
        '위작 주의: 위작은 가장 적게 건 사람이 떠안아요(동점이면 우선권 규칙). 나머지는 자기가 건 돈을 내고, 그 돈은 모두 위작을 떠안은 사람이 위로금으로 받아요.',
        '→ 위작 경매에서는 「안 떠안으려고」 돈을 거는 거예요. 버튼에 「○금화 내고 피하기」라고 나와요.'] },
      { h: '이벤트 카드 (옵션, 기본 켬)', p: [
        '3라운드가 끝날 때마다 모두 카드를 한 장씩 받아요. 내 카드는 나만 봐요(장수는 공개).',
        '입찰하기 전에 「카드」 버튼으로 라운드마다 한 장 쓸 수 있어요. 쓰는 순간 누가 무슨 카드를 썼는지 모두에게 알림이 떠요.',
        '쓰지 않은 카드는 끝날 때 점수가 없어요. 아끼지 말고 써요.',
        '카드는 ' + CARDS.length + '종, 7가지 분류(정보 · 입찰 · 돈 · 물품 · 방해 · 점수 · 규칙)예요. 흔함은 자주, 드묾은 가끔 나와요. 전설 ' + CARDS.filter((c) => c.r === 2).length + '종 중 ' + LEGENDS + '종만 판마다 무작위로 섞여요.',
        '사람을 고르는 카드는 「고르기」를 누르고 대상을 눌러요. 상대가 경비원을 두었으면 카드가 막히고 경비원도 사라져요.',
        '위작 경매에선 못 쓰는 카드: ' + CARDS.filter((c) => c.nf).map((c) => c.n).join(' · ') + '.',
        '경매 방식을 바꾸는 카드: 내림 경매(5 단위로 내려서 비교) · 봉투 두 번(1·2등만 서로 금액을 보고 다시 입찰, 처음보다 낮게는 못 써요) · 모두 내기 · 평균가 · 공개 입찰 · 깜깜이(덮인 물건) · 선착순 · 동맹 입찰(두 사람 입찰을 합쳐요) · 일대일.',
        '끝날 때 갚는 카드(할부 구매 · 돈놀이)는 남은 금화에서 빼고 더해서 점수를 계산해요. 모자라면 점수가 깎여요.',
        '「카드」 → 「카드 도감」에서 모든 카드를 분류별로 볼 수 있어요. 아래 「카드 · ○○」 항목에도 전부 적혀 있어요.'] },
      { h: '조작', p: [
        '−/+ (꾹 누르면 빠르게) · 슬라이더 · 0/−5/+5/+10/최대 → 금액 맞추기. 아래 큰 버튼 → 입찰.',
        '위쪽 사람 칸을 누르면 그 사람의 수집품과 점수 계산을 볼 수 있어요. 금화와 모은 물건은 모두 공개예요.',
        '「기록」에는 낙찰가와 쓴 카드가 남아요. 진 입찰액은 뒤집히는 순간에만 보여요(설정 「기록에 진 입찰도: 모두 보기」로 남길 수 있어요).',
        '한 폰에서 여럿이 할 때는 「다른 사람은 보지 마세요」 화면이 나오면 폰을 넘기고 「입찰하기」를 눌러요.'] },
      { h: '예시', p: [
        '보석 4점짜리 물건이 나왔어요. 나는 보석이 이미 2점 있어요 → 3점째면 보석이 모두 2배!',
        '그래서 30금화를 걸었어요. 뒤집어 보니 민지 22 · 준호 30 · 나 30.',
        '나와 준호가 동점 → 「동점 우선」이 나라서 내가 낙찰, 30금화를 내요.',
        '나중에 「은 보물상자」(3점)를 사고, 열쇠도 얻었어요 → 상자가 열려 3×3 = 9점 + 열쇠 1점!',
        '위작 주의 라운드에선 반대로: 나 5 · 민지 0 · 준호 8 → 민지가 위작을 떠안고, 나와 준호가 낸 13금화를 위로금으로 받아요.'] },
      ...CATS.map((c, g) => ({ h: '카드 · ' + c.n, p: CARDS.filter((x) => x.g === g).map((x) => x.n + (x.r ? ' (' + RARE[x.r].n + ')' : '') + ': ' + x.d + '.') })),
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 적힌 점수만 보고 들쭉날쭉 걸고 카드도 아무 때나 아무에게나 써요. 보통은 세트 가능성과 남의 필요를 따져 조금씩 블러핑하고, 카드는 쓸 만할 때 써요. 어려움은 다른 사람의 남은 금화와 필요를 계산해 이길 만큼만 걸고, 카드도 가장 이득인 때와 상대(1등, 경비원 없는 사람)를 골라 써요.'] },
    ],
    tutorial: [
      { sel: '.au-table', text: '이번 경매품이에요. 모두 동시에 몰래 금화를 걸고, 가장 많이 건 사람이 그 돈을 내고 가져가요!' },
      { sel: '.au-top', text: '모두의 금화 · 이벤트 카드 장수 · 물건 점수(★)예요. 금화와 수집품은 모두 공개! 칸을 누르면 그 사람의 수집품을 볼 수 있어요.' },
      { sel: '.au-head', text: '지금 라운드와 「동점 우선」이에요. 금액이 같으면 이 사람(부터 시계 방향으로 가까운 사람)이 이겨요. 「기록」엔 지난 낙찰가가 있어요.' },
      { sel: '.au-mode', text: '이번 경매 방식이에요. 일반 · 2개 묶음 · 경매사 수수료 · 2등 가격 · 위작 주의(가장 적게 건 사람이 떠안음)가 있어요. 특수 물건이면 아래에 한 줄 설명이 나와요.' },
      { sel: '.au-amt', text: '−/+ · 슬라이더 · 아래 버튼으로 걸 금액을 맞춰요(0은 포기). 바로 위에 남는 돈과 낙찰되면 얻는 점수가 보여요. 남은 금화도 10개당 1점!' },
      { sel: '.au-cbtn', text: '「카드」: 3라운드마다 받는 이벤트 카드를 입찰 전에 한 장 쓸 수 있어요. 남긴 카드는 점수가 없어요.' },
      { sel: '.au-go', text: '금액을 정했으면 이 버튼으로 입찰! 모두 입찰하면 한꺼번에 뒤집혀요. 시작!' },
    ],
    codex,
    init, actor, apply, ai, result, mount,
    _t: { ITEMS, MYST_IDS, PROP_IDS, PAIR_IDS, BOOK_IDS, CHEST_IDS, KEY_IDS, MONEY_IDS, CURSE_IDS, CHARM_IDS, MASTER_IDS, BIRD_IDS, FAKE_IDS, THEMES, itemHint, upcoming, minBid, returnable, tgList, gain, countBids, lotWorth, item, score, scoreOf, resolve, maxBid, enc, dec, scr, unscr, prio, order, startRound, lotPts, aiBid, aiCard, cardGain, aiCtx, rateOf, futureOdds, cantUse, targetWhy, peekVal, free, spare, badgePts, buildDeck, SPECIALS, FEE, E, CARDS, CATS, RARE, CICON, TARGET, ALPHA, idOf, chOf, art },
  });
})();
