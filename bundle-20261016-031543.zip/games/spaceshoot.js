/* 우주선 슈팅 대전 (spaceshoot) — realtime top-down arena shooter (2–4). Inertia ships (thrust + rotation, with a
   "grip" assist that bleeds off sideways drift while thrusting), assisted aim for people, destructible asteroids,
   8 arenas larger than the screen (following camera + minimap + off-screen arrows): asteroid field, nebula fog with
   radar pings, black hole, space station walls, wormholes, binary stars, meteor shower, maze base.
   Power-ups (spread, laser, shield, homing missiles, mines), 3 lives, last ship standing wins the round; best of 3 / 5.
   Host-authoritative fixed-step sim (1/120 s) with swept bullet collisions; guests publish stick/fire input + a
   special counter, receive ~20 Hz compact snapshots, interpolate everything else and predict their own ship.
   One person per phone: locally you fly seat 0 against AI ships; friends play together through online/LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const H = 1 / 120;
  const SR = 9, THR = 265, VMAX = 215, DRAG = 0.42, GRIP = 2.6, TURN = 6.6, TURN_P = 15, GTURN = 14;
  const BS = 340, BLIFE = 1.05, BR = 2.5, CD_FIRE = 0.2, CD_AUTO = 0.3, BMAX = 9;
  const LIVES = 3, INV = 1.6, COUNT = 3, END_T = 2.6, CAP_T = 150;
  const MS = 190, MTURN = 3.2, MLIFE = 3.5, MINE_ARM = 0.8, MINE_TRIG = 18, MINE_BLAST = 36, MINE_LIFE = 25;
  const LASER_LEN = 520, HOLE_R = 15, WELL_R = 13, STAR_R = 20, STAR_D = 200, STAR_W = 0.21, PR = 19, VIS = 115;
  const AA_B = 0.2, AA_T = 0.1, AA_RANGE = 320, PING = 4.5, PING_ON = 1.2;
  const PU_KINDS = ['S', 'L', 'D', 'M', 'N'];
  const PU_NAME = { S: '확산탄', L: '레이저', D: '방패', M: '유도 미사일', N: '기뢰' };
  const PU_CH = { S: '확', L: '레', D: '방', M: '유', N: '기' };
  const PU_COL = { S: '#e8c04e', L: '#ff5d8f', D: '#7fe3ff', M: '#ff9a4d', N: '#b48cf0' };
  const PORTAL_COL = ['#5ee0d0', '#ff8ad8'];
  /* walls are [cx, cy, half-w, half-h]; every map is point-symmetric so no spawn is favoured */
  const sym = (list) => { const o = []; for (const w of list) { o.push(w); o.push([-w[0], -w[1], w[2], w[3]]); } return o; };
  const ARENAS = [
    { id: 'rocks', name: '소행성 지대', sub: '소행성 뒤에 숨어요. 쏘면 부서져요', w: 760, h: 1080, rocks: 22,
      bg: '#0b0d24', grid: 'rgba(120,140,220,.07)', edge: '120,180,255' },
    { id: 'nebula', name: '성운', sub: '안개 속에선 가까운 적만 보여요', w: 800, h: 1120, rocks: 10, fog: 1,
      bg: '#160a28', grid: 'rgba(200,120,230,.06)', edge: '200,130,255' },
    { id: 'hole', name: '블랙홀', sub: '가운데로 끌려가요. 빠지면 목숨 하나!', w: 840, h: 1160, rocks: 9, hole: 1,
      bg: '#0a0716', grid: 'rgba(170,140,240,.06)', edge: '180,140,240' },
    { id: 'station', name: '우주 정거장', sub: '벽 뒤에 숨어서 쏘세요', w: 800, h: 1120, rocks: 4,
      bg: '#0c1122', grid: 'rgba(140,160,210,.08)', edge: '227,174,69',
      walls: sym([[0, -100, 64, 7], [-180, -200, 56, 7], [200, -210, 7, 52], [-90, -350, 7, 42], [240, -370, 64, 7], [-290, -110, 7, 40]]) },
    { id: 'worm', name: '웜홀', sub: '같은 색 구멍끼리 이어져 있어요', w: 860, h: 1180, rocks: 8,
      bg: '#061619', grid: 'rgba(90,220,200,.07)', edge: '94,224,208',
      portals: [[-300, -330, 300, 330], [300, -330, -300, 330]] },
    { id: 'binary', name: '쌍둥이 별', sub: '빙글빙글 도는 두 별이 끌어당겨요', w: 900, h: 1200, rocks: 7, stars: 1,
      bg: '#170d0c', grid: 'rgba(255,170,110,.06)', edge: '255,180,110' },
    { id: 'meteor', name: '유성우', sub: '쏟아지는 운석에 맞으면 목숨 하나!', w: 780, h: 1100, rocks: 3, meteor: 10,
      bg: '#170b0a', grid: 'rgba(255,140,90,.06)', edge: '255,140,90' },
    { id: 'maze', name: '미로 기지', sub: '좁은 통로에서 숨바꼭질', w: 840, h: 1200, rocks: 2,
      bg: '#04130f', grid: 'rgba(80,240,170,.07)', edge: '80,240,170',
      walls: sym([[-250, -320, 110, 7], [190, -320, 70, 7], [0, -170, 130, 7], [-250, -60, 7, 100], [-130, 0, 7, 70], [320, -190, 7, 70], [70, -460, 7, 60], [-170, -470, 60, 7], [60, -245, 7, 40]]) },
  ];
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const r2 = (v) => Math.round(v * 100) / 100;
  const wrapA = (a) => { a = (a + Math.PI) % (Math.PI * 2); if (a < 0) a += Math.PI * 2; return a - Math.PI; };
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); }

  /* segment p0→p1 vs circle (c, r): first entry t in [0,1], 0 if starting inside, −1 if none */
  function segCircle(x0, y0, x1, y1, cx, cy, r) {
    const dx = x1 - x0, dy = y1 - y0, fx = x0 - cx, fy = y0 - cy;
    const c = fx * fx + fy * fy - r * r;
    if (c <= 0) return 0;
    const a = dx * dx + dy * dy;
    if (a < 1e-9) return -1;
    const b = 2 * (fx * dx + fy * dy);
    if (b >= 0) return -1;
    const disc = b * b - 4 * a * c;
    if (disc < 0) return -1;
    const t = (-b - Math.sqrt(disc)) / (2 * a);
    return t >= 0 && t <= 1 ? t : -1;
  }
  /* segment vs axis-aligned box (cx, cy, hw, hh) grown by pad: entry t, 0 if inside, −1 if none (no allocations) */
  function segBox(x0, y0, x1, y1, w, pad) {
    const minX = w[0] - w[2] - pad, maxX = w[0] + w[2] + pad, minY = w[1] - w[3] - pad, maxY = w[1] + w[3] + pad;
    if (x0 >= minX && x0 <= maxX && y0 >= minY && y0 <= maxY) return 0;
    let t0 = 0, t1 = 1;
    const dx = x1 - x0, dy = y1 - y0;
    if (Math.abs(dx) < 1e-12) { if (x0 < minX || x0 > maxX) return -1; }
    else { let ta = (minX - x0) / dx, tb = (maxX - x0) / dx; if (ta > tb) { const q = ta; ta = tb; tb = q; } if (ta > t0) t0 = ta; if (tb < t1) t1 = tb; if (t0 > t1) return -1; }
    if (Math.abs(dy) < 1e-12) { if (y0 < minY || y0 > maxY) return -1; }
    else { let ta = (minY - y0) / dy, tb = (maxY - y0) / dy; if (ta > tb) { const q = ta; ta = tb; tb = q; } if (ta > t0) t0 = ta; if (tb < t1) t1 = tb; if (t0 > t1) return -1; }
    return t0;
  }
  const inBox = (x, y, w, pad) => Math.abs(x - w[0]) <= w[2] + pad && Math.abs(y - w[1]) <= w[3] + pad;
  function slots(W) {
    const n = W.n, a = W.hw, b = W.hh;
    if (n <= 2) return [[0, b - 110], [0, -(b - 110)]];
    if (n === 3) return [[0, b - 110], [0, -(b - 110)], [-(a - 110), 0]];
    return [[-(a - 120), b - 120], [a - 120, -(b - 120)], [a - 120, b - 120], [-(a - 120), -(b - 120)]];
  }
  function spawnAt(W, slot) {
    const p = slots(W)[slot] || [0, 0];
    return { x: p[0], y: p[1], a: Math.atan2(-p[1], -p[0] * 0.3) };
  }
  /* gravity bodies: black hole (swallows), gravity well and binary stars (solid, bounce) */
  function makeBodies(W) {
    const A = W.A, B = [];
    if (A.hole) B.push({ k: 'hole', x: 0, y: 0, r: HOLE_R, G: 650000, cap: 380 });
    else if (A.stars) { B.push({ k: 'star', x: 0, y: 0, r: STAR_R, G: 300000, cap: 260 }); B.push({ k: 'star', x: 0, y: 0, r: STAR_R, G: 300000, cap: 260 }); }
    else if (W.grav) B.push({ k: 'well', x: 0, y: 0, r: WELL_R, G: 380000, cap: 300 });
    W.bodies = B;
    updateBodies(W);
  }
  function updateBodies(W) {
    if (!W.A.stars) return;
    const an = W.sph + W.t * STAR_W, c = Math.cos(an) * STAR_D, s = Math.sin(an) * STAR_D;
    W.bodies[0].x = c; W.bodies[0].y = s; W.bodies[1].x = -c; W.bodies[1].y = -s;
  }
  function freeSpot(W, x, y, r) {
    if (Math.abs(x) > W.hw - r || Math.abs(y) > W.hh - r) return false;
    for (const b of W.bodies) if (Math.hypot(x - b.x, y - b.y) < (b.k === 'hole' ? 120 : b.k === 'star' ? 60 : 70) + r) return false;
    if (W.A.stars && Math.abs(Math.hypot(x, y) - STAR_D) < STAR_R + r + 30) return false;
    for (const w of W.walls) if (inBox(x, y, w, r + 4)) return false;
    for (const p of W.portals) for (let e = 0; e < 2; e++) if (Math.hypot(x - p[e * 2], y - p[e * 2 + 1]) < PR + r + 10) return false;
    return true;
  }
  function newMeteor(W, anywhere) {
    const rnd = W.rnd, sp = 85 + rnd() * 60, an = W.md + (rnd() - 0.5) * 0.24, r = rnd() < 0.5 ? 8 : 11;
    let x, y;
    if (anywhere) { x = (rnd() * 2 - 1) * W.hw; y = (rnd() * 2 - 1) * W.hh; }
    else { x = (rnd() * 2 - 1) * W.hw; y = Math.sin(W.md) > 0 ? -W.hh - r - 14 : W.hh + r + 14; }
    return { id: W.nid++, x, y, vx: Math.cos(an) * sp, vy: Math.sin(an) * sp, r, hp: r >= 10 ? 2 : 1, m: 1 };
  }
  function newWorld(ar, sd, n, sp, grav) {
    const A = ARENAS[clamp(ar | 0, 0, ARENAS.length - 1)], rnd = prng(sd);
    const W = { A, ar: ar | 0, n, hw: A.w / 2, hh: A.h / 2, walls: A.walls || [], portals: A.portals || [], t: 0,
      grav: A.hole || A.stars ? 0 : grav ? 1 : 0, bodies: [], sph: rnd() * Math.PI * 2, md: Math.PI / 2, rnd,
      ships: [], bul: [], rocks: [], mis: [], mines: [], pu: [], fx: [], fxId: 0, puT: 4, nid: 1, sp: sp || [] };
    if (A.meteor) W.md = (rnd() < 0.5 ? 1 : -1) * Math.PI / 2 + (rnd() - 0.5) * 0.7;
    makeBodies(W);
    for (let s = 0; s < n; s++) {
      const p = spawnAt(W, sp && sp[s] != null ? sp[s] : s);
      W.ships.push({ seat: s, x: p.x, y: p.y, px: p.x, py: p.y, vx: 0, vy: 0, a: p.a, g: p.a, lives: LIVES, alive: true, inv: 0.6, sh: 0, spr: 0, sk: '', sn: 0, cd: 0.4, scd: 0, sc: null, th: 0, by: -1, fl: 0, wc: 0 });
    }
    for (let k = 0, tries = 0; k < A.rocks && tries < 900; tries++) {
      const r = rnd() < 0.65 ? 16 : 10, x = (rnd() * 2 - 1) * (W.hw - 26), y = (rnd() * 2 - 1) * (W.hh - 40);
      if (!freeSpot(W, x, y, r + 6)) continue;
      if (W.ships.some((c) => Math.hypot(c.x - x, c.y - y) < 80)) continue;
      if (W.rocks.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + r + 16)) continue;
      const an = rnd() * 6.283, sp2 = 6 + rnd() * 14;
      W.rocks.push({ id: W.nid++, x, y, vx: Math.cos(an) * sp2, vy: Math.sin(an) * sp2, r, hp: r >= 16 ? 4 : 2 });
      k++;
    }
    for (let k = 0, tries = 0; k < (A.meteor || 0) && tries < 200; tries++) {
      const m = newMeteor(W, true);
      if (W.ships.some((c) => Math.hypot(c.x - m.x, c.y - m.y) < 110)) continue;
      W.rocks.push(m); k++;
    }
    return W;
  }
  function emit(W, hooks, code, x, y, a, b, c, d) {
    W.fxId = (W.fxId + 1) % 100000;
    W.fx.push([W.fxId, code, Math.round(x), Math.round(y), a == null ? 0 : a, b == null ? 0 : b, c == null ? 0 : c, d == null ? 0 : d]);
    if (W.fx.length > 8) W.fx.shift();
    if (hooks && hooks.fx) hooks.fx(code, x, y, a, b, c, d);
  }
  /* damage one ship (shield first, then a life). Returns true when something happened */
  function damage(W, s, by, hooks) {
    if (!s.alive || s.inv > 0) return false;
    if (s.sh > 0) { s.sh = 0; s.inv = 0.5; emit(W, hooks, 's', s.x, s.y, s.seat); return true; }
    s.lives--; s.inv = INV; s.by = by;
    if (s.lives <= 0) { s.alive = false; s.lives = 0; emit(W, hooks, 'o', s.x, s.y, s.seat, by); }
    else emit(W, hooks, 'h', s.x, s.y, s.seat, by);
    return true;
  }
  const GA = [0, 0];
  function gravAcc(W, x, y, k) {
    GA[0] = 0; GA[1] = 0;
    for (const b of W.bodies) {
      const dx = b.x - x, dy = b.y - y, d2 = dx * dx + dy * dy, d = Math.sqrt(d2) || 1;
      const a = Math.min(b.cap, b.G / (d2 + 900)) * (k == null ? 1 : k);
      GA[0] += dx / d * a; GA[1] += dy / d * a;
    }
    return GA;
  }
  /* bounce a circle (x, y, r) with velocity off walls, edges and solid bodies */
  function solidBounce(W, o, r, rest) {
    const hw = W.hw, hh = W.hh;
    if (o.x < -hw + r) { o.x = -hw + r; if (o.vx < 0) o.vx = -o.vx * rest; }
    if (o.x > hw - r) { o.x = hw - r; if (o.vx > 0) o.vx = -o.vx * rest; }
    if (o.y < -hh + r) { o.y = -hh + r; if (o.vy < 0) o.vy = -o.vy * rest; }
    if (o.y > hh - r) { o.y = hh - r; if (o.vy > 0) o.vy = -o.vy * rest; }
    for (const w of W.walls) {
      if (!inBox(o.x, o.y, w, r)) continue;
      const qx = clamp(o.x, w[0] - w[2], w[0] + w[2]), qy = clamp(o.y, w[1] - w[3], w[1] + w[3]);
      let dx = o.x - qx, dy = o.y - qy, d = Math.hypot(dx, dy);
      if (d >= r) continue;
      if (d < 1e-6) { // centre inside the box: push out along the shallow axis
        const ox = w[2] - Math.abs(o.x - w[0]), oy = w[3] - Math.abs(o.y - w[1]);
        if (ox < oy) { dx = Math.sign(o.x - w[0]) || 1; dy = 0; o.x = w[0] + dx * (w[2] + r); }
        else { dy = Math.sign(o.y - w[1]) || 1; dx = 0; o.y = w[1] + dy * (w[3] + r); }
      } else { dx /= d; dy /= d; o.x = qx + dx * r; o.y = qy + dy * r; }
      const vn = o.vx * dx + o.vy * dy;
      if (vn < 0) { o.vx -= (1 + rest) * vn * dx; o.vy -= (1 + rest) * vn * dy; }
    }
    for (const b of W.bodies) {
      if (b.k === 'hole') continue;
      const ex = o.x - b.x, ey = o.y - b.y, d = Math.hypot(ex, ey), R = b.r + r;
      if (d < R && d > 1e-6) { const nx = ex / d, ny = ey / d; o.x = b.x + nx * R; o.y = b.y + ny * R; const vn = o.vx * nx + o.vy * ny; if (vn < 0) { o.vx -= (1 + rest) * vn * nx; o.vy -= (1 + rest) * vn * ny; } if (b.k === 'star') { o.vx += nx * 40; o.vy += ny * 40; } }
    }
  }
  /* input: {x, y: move stick (|v| ≤ 1); ax, ay: aim stick (twin); f: fire held; s: special counter; m: 'b' | 't'; aa: aim assist} */
  function stickDrive(s, i, h) {
    const x = clamp(+i.x || 0, -1, 1), y = clamp(+i.y || 0, -1, 1), m = Math.min(1, Math.hypot(x, y));
    let thr = 0;
    if (m > 0.15) {
      const d = wrapA(Math.atan2(y, x) - s.a);
      const rate = clamp(d * TURN_P, -TURN, TURN); // proportional: fast swing, no jitter at the end
      s.a = wrapA(s.a + clamp(rate * h, -Math.abs(d), Math.abs(d)));
      const c = Math.cos(d);
      thr = clamp((m - 0.32) / 0.48, 0, 1) * (c > 0 ? c * c : 0);
    }
    if (i.m === 't') {
      const ax = +i.ax || 0, ay = +i.ay || 0;
      if (Math.hypot(ax, ay) > 0.3) { const d = wrapA(Math.atan2(ay, ax) - s.g); s.g = wrapA(s.g + clamp(d, -GTURN * h, GTURN * h)); }
      else s.g = s.a;
    } else s.g = s.a;
    return thr;
  }
  function portalHop(W, s, hooks) {
    for (const p of W.portals) for (let e = 0; e < 2; e++) {
      const cx = p[e * 2], cy = p[e * 2 + 1];
      if (Math.hypot(s.x - cx, s.y - cy) >= PR) continue;
      const qx = p[2 - e * 2], qy = p[3 - e * 2], sp = Math.hypot(s.vx, s.vy);
      const ux = sp > 20 ? s.vx / sp : Math.cos(s.a), uy = sp > 20 ? s.vy / sp : Math.sin(s.a);
      s.x = s.px = qx + ux * (PR + SR + 3); s.y = s.py = qy + uy * (PR + SR + 3);
      s.wc = 0.6;
      if (hooks) emit(W, hooks, 'w', cx, cy, qx, qy, s.seat, W.portals.indexOf(p));
      return true;
    }
    return false;
  }
  function moveShip(W, s, inp, h, hooks) {
    const i = inp || {};
    const thr = stickDrive(s, i, h);
    s.th = thr;
    const ca = Math.cos(s.a), sa = Math.sin(s.a);
    s.vx += ca * THR * thr * h; s.vy += sa * THR * thr * h;
    if (thr > 0.05) { // grip assist: while thrusting, sideways drift fades so the ship goes where it points
      const lat = -s.vx * sa + s.vy * ca, k = lat * (1 - Math.exp(-GRIP * thr * h));
      s.vx += sa * k; s.vy -= ca * k;
    }
    if (W.bodies.length) { const g = gravAcc(W, s.x, s.y); s.vx += g[0] * h; s.vy += g[1] * h; }
    const k = Math.exp(-DRAG * h); s.vx *= k; s.vy *= k;
    const sp = Math.hypot(s.vx, s.vy), cap = VMAX * (W.A.hole ? 1.5 : 1);
    if (sp > cap) { s.vx *= cap / sp; s.vy *= cap / sp; }
    s.px = s.x; s.py = s.y;
    s.x += s.vx * h; s.y += s.vy * h;
    if (W.portals.length) { if (s.wc > 0) s.wc -= h; else portalHop(W, s, hooks); }
    solidBounce(W, s, SR, 0.55);
  }
  function wantsFire(i, af) { return af || (i && (i.m === 't' ? Math.hypot(+i.ax || 0, +i.ay || 0) > 0.55 || !!i.f : !!i.f)); }
  /* walls and bodies only (rocks can be shot through) */
  function wallsClear(W, x0, y0, x1, y1) {
    for (const w of W.walls) if (segBox(x0, y0, x1, y1, w, 1) >= 0) return false;
    for (const b of W.bodies) if (segCircle(x0, y0, x1, y1, b.x, b.y, b.r) >= 0) return false;
    return true;
  }
  /* aim assist: the nearest-in-angle enemy inside the cone (lead included). Returns angle or null; AST.o = target */
  const AST = { o: null };
  function assistAim(W, s, base, cone, range) {
    let best = null, bd = cone; AST.o = null;
    for (const o of W.ships) {
      if (!o.alive || o.seat === s.seat) continue;
      const d = Math.hypot(o.x - s.x, o.y - s.y);
      if (d > range || (W.A.fog && d > VIS + 25)) continue;
      let tt = d / BS, tx = o.x + o.vx * tt, ty = o.y + o.vy * tt;
      tt = Math.hypot(tx - s.x, ty - s.y) / BS; tx = o.x + o.vx * tt; ty = o.y + o.vy * tt;
      const an = Math.atan2(ty - s.y, tx - s.x), df = Math.abs(wrapA(an - base));
      if (df < bd && wallsClear(W, s.x, s.y, o.x, o.y)) { bd = df; best = an; AST.o = o; }
    }
    return best;
  }
  function fire(W, s, af, hooks, i) {
    let mine = 0; for (const b of W.bul) if (b.o === s.seat) mine++;
    if (mine >= BMAX) return false;
    let a0 = s.g;
    if (i && i.aa) { const q = assistAim(W, s, s.g, i.m === 't' ? AA_T : AA_B, AA_RANGE); if (q != null) a0 = q; }
    const n = s.spr > 0 ? 3 : 1;
    for (let k = 0; k < n; k++) {
      const a = a0 + (n === 3 ? (k - 1) * 0.2 : 0);
      const x = s.x + Math.cos(a) * (SR + 2), y = s.y + Math.sin(a) * (SR + 2);
      W.bul.push({ x, y, px: s.x, py: s.y, vx: Math.cos(a) * BS, vy: Math.sin(a) * BS, o: s.seat, t: BLIFE });
    }
    s.cd = af ? CD_AUTO : CD_FIRE; s.fl = 0.06;
    if (hooks && hooks.fire) hooks.fire(s);
    return true;
  }
  /* first thing a ray from (x0,y0) toward angle a hits: {t (distance), kind, ref} */
  function rayCast(W, x0, y0, a, len, skipSeat) {
    const x1 = x0 + Math.cos(a) * len, y1 = y0 + Math.sin(a) * len, dx = x1 - x0, dy = y1 - y0;
    let bt = 1, kind = 'edge', ref = null;
    const take = (t, k, r) => { if (t >= 0 && t < bt) { bt = t; kind = k; ref = r; } };
    if (dx > 1e-9) take((W.hw - x0) / dx, 'edge', null); else if (dx < -1e-9) take((-W.hw - x0) / dx, 'edge', null);
    if (dy > 1e-9) take((W.hh - y0) / dy, 'edge', null); else if (dy < -1e-9) take((-W.hh - y0) / dy, 'edge', null);
    for (const w of W.walls) take(segBox(x0, y0, x1, y1, w, 0), 'wall', w);
    for (const r of W.rocks) take(segCircle(x0, y0, x1, y1, r.x, r.y, r.r), 'rock', r);
    for (const b of W.bodies) take(segCircle(x0, y0, x1, y1, b.x, b.y, b.r), 'body', b);
    for (const s of W.ships) if (s.alive && s.seat !== skipSeat) take(segCircle(x0, y0, x1, y1, s.x, s.y, SR + 3), 'ship', s);
    return { t: bt * len, kind, ref, x: x0 + dx * bt, y: y0 + dy * bt };
  }
  function hitRock(W, r, dmg, hooks, host) {
    r.hp -= dmg;
    if (r.hp > 0) { emit(W, hooks, 'c', r.x, r.y, r.r); return; }
    const ix = W.rocks.indexOf(r); if (ix < 0) return;
    W.rocks.splice(ix, 1);
    emit(W, hooks, 'r', r.x, r.y, r.r, r.m ? 1 : 0);
    if (r.m) { // meteors don't split; another one comes in from the edge
      if (host) { W.rocks.push(newMeteor(W, false)); if (Math.random() < 0.07 && W.pu.length < 3) W.pu.push({ x: Math.round(clamp(r.x, -W.hw + 20, W.hw - 20)), y: Math.round(clamp(r.y, -W.hh + 20, W.hh - 20)), k: PU_KINDS[Math.floor(Math.random() * PU_KINDS.length)], t: 12 }); }
      return;
    }
    if (r.r > 7) {
      const nr = r.r >= 16 ? 10 : 6;
      for (const sg of [-1, 1]) {
        const an = Math.atan2(r.vy, r.vx) + sg * 1.2 + (host ? (Math.random() - 0.5) * 0.6 : 0);
        W.rocks.push({ id: W.nid++, x: r.x + Math.cos(an) * nr * 0.6, y: r.y + Math.sin(an) * nr * 0.6, vx: r.vx * 0.6 + Math.cos(an) * 26, vy: r.vy * 0.6 + Math.sin(an) * 26, r: nr, hp: nr >= 10 ? 2 : 1 });
      }
    }
    if (host && Math.random() < 0.14 && W.pu.length < 3) W.pu.push({ x: Math.round(r.x), y: Math.round(r.y), k: PU_KINDS[Math.floor(Math.random() * PU_KINDS.length)], t: 12 });
  }
  function special(W, s, hooks, host, i) {
    if (!s.sk || s.sn <= 0 || s.scd > 0) return false;
    const k = s.sk;
    if (k === 'L') {
      let a = s.g;
      if (i && i.aa) { const q = assistAim(W, s, s.g, 0.08, LASER_LEN); if (q != null) a = q; }
      const x0 = s.x + Math.cos(a) * (SR + 1), y0 = s.y + Math.sin(a) * (SR + 1);
      const hit = rayCast(W, x0, y0, a, LASER_LEN, s.seat);
      emit(W, hooks, 'l', x0, y0, Math.round(hit.x), Math.round(hit.y), s.seat);
      if (hit.kind === 'ship') damage(W, hit.ref, s.seat, hooks);
      else if (hit.kind === 'rock') hitRock(W, hit.ref, 3, hooks, host);
      s.scd = 0.6;
    } else if (k === 'M') {
      W.mis.push({ x: s.x + Math.cos(s.g) * (SR + 3), y: s.y + Math.sin(s.g) * (SR + 3), px: s.x, py: s.y, a: s.g, o: s.seat, t: MLIFE });
      s.scd = 0.45;
      if (hooks && hooks.launch) hooks.launch(s);
    } else if (k === 'N') {
      if (W.mines.filter((m) => m.o === s.seat).length >= 4) return false;
      W.mines.push({ x: Math.round(s.x - Math.cos(s.a) * (SR + 6)), y: Math.round(s.y - Math.sin(s.a) * (SR + 6)), o: s.seat, t: 0 });
      s.scd = 0.35;
      if (hooks && hooks.mine) hooks.mine(s);
    }
    s.sn--; if (s.sn <= 0) { s.sk = ''; s.sn = 0; }
    return true;
  }
  function explode(W, x, y, R, owner, hooks, host) {
    emit(W, hooks, 'b', x, y, R);
    for (const s of W.ships) if (s.alive && s.seat !== owner && Math.hypot(s.x - x, s.y - y) < R + SR) damage(W, s, owner, hooks);
    for (const r of W.rocks.slice()) if (Math.hypot(r.x - x, r.y - y) < R + r.r) hitRock(W, r, 2, hooks, host && !!r.m);
  }
  /* move bullets with swept collision against everything (no tunnelling at any step size) */
  function stepBullets(W, h, hooks, host) {
    const hw = W.hw, hh = W.hh;
    for (let i = W.bul.length - 1; i >= 0; i--) {
      const b = W.bul[i];
      b.t -= h;
      const x0 = b.x, y0 = b.y, x1 = x0 + b.vx * h, y1 = y0 + b.vy * h, dx = x1 - x0, dy = y1 - y0;
      let bt = 2, kind = null, ref = null, pe = 0;
      if (x1 > hw && dx > 1e-9) { const t = Math.max(0, (hw - x0) / dx); if (t < bt) { bt = t; kind = 'edge'; } }
      if (x1 < -hw && dx < -1e-9) { const t = Math.max(0, (-hw - x0) / dx); if (t < bt) { bt = t; kind = 'edge'; } }
      if (y1 > hh && dy > 1e-9) { const t = Math.max(0, (hh - y0) / dy); if (t < bt) { bt = t; kind = 'edge'; } }
      if (y1 < -hh && dy < -1e-9) { const t = Math.max(0, (-hh - y0) / dy); if (t < bt) { bt = t; kind = 'edge'; } }
      for (const w of W.walls) { const t = segBox(x0, y0, x1, y1, w, BR * 0.5); if (t >= 0 && t < bt) { bt = t; kind = 'wall'; ref = w; } }
      for (const r of W.rocks) { const t = segCircle(x0, y0, x1, y1, r.x, r.y, r.r + BR * 0.5); if (t >= 0 && t < bt) { bt = t; kind = 'rock'; ref = r; } }
      for (const q of W.bodies) { const t = segCircle(x0, y0, x1, y1, q.x, q.y, q.r); if (t >= 0 && t < bt) { bt = t; kind = 'body'; ref = q; } }
      for (const p of W.portals) for (let e = 0; e < 2; e++) { const t = segCircle(x0, y0, x1, y1, p[e * 2], p[e * 2 + 1], PR * 0.8); if (t >= 0 && t < bt) { bt = t; kind = 'portal'; ref = p; pe = e; } }
      for (const s of W.ships) { // relative motion: the ship moved from (px,py) to (x,y) this step
        if (!s.alive || s.seat === b.o) continue;
        const t = segCircle(x0 - s.px, y0 - s.py, x1 - s.x, y1 - s.y, 0, 0, SR + BR); if (t >= 0 && t < bt) { bt = t; kind = 'ship'; ref = s; }
      }
      for (const m of W.mis) if (m.o !== b.o) { const t = segCircle(x0, y0, x1, y1, m.x, m.y, 5); if (t >= 0 && t < bt) { bt = t; kind = 'mis'; ref = m; } }
      for (const m of W.mines) if (m.o !== b.o) { const t = segCircle(x0, y0, x1, y1, m.x, m.y, 6); if (t >= 0 && t < bt) { bt = t; kind = 'mine'; ref = m; } }
      if (kind === 'portal') { // come out of the twin hole, same heading
        const qx = ref[2 - pe * 2], qy = ref[3 - pe * 2], sp = Math.hypot(b.vx, b.vy) || 1;
        b.x = b.px = qx + b.vx / sp * (PR + 2); b.y = b.py = qy + b.vy / sp * (PR + 2);
        if (b.t <= 0) W.bul.splice(i, 1);
        continue;
      }
      if (kind) {
        const hx = x0 + dx * bt, hy = y0 + dy * bt;
        W.bul.splice(i, 1);
        if (kind === 'ship') damage(W, ref, b.o, hooks);
        else if (kind === 'rock') hitRock(W, ref, 1, hooks, host);
        else if (kind === 'mis') { W.mis.splice(W.mis.indexOf(ref), 1); emit(W, hooks, 'b', ref.x, ref.y, 14); }
        else if (kind === 'mine') { W.mines.splice(W.mines.indexOf(ref), 1); explode(W, ref.x, ref.y, MINE_BLAST, ref.o, hooks, host); }
        else if (hooks && hooks.spark) hooks.spark(hx, hy);
        continue;
      }
      b.px = x0; b.py = y0; b.x = x1; b.y = y1;
      if (b.t <= 0) W.bul.splice(i, 1);
    }
  }
  function nearestEnemy(W, x, y, seat, maxD) {
    let best = null, bd = maxD || 1e9;
    for (const s of W.ships) { if (!s.alive || s.seat === seat) continue; const d = Math.hypot(s.x - x, s.y - y); if (d < bd) { bd = d; best = s; } }
    return best;
  }
  function stepMissiles(W, h, hooks, host) {
    for (let i = W.mis.length - 1; i >= 0; i--) {
      const m = W.mis[i];
      m.t -= h;
      const tg = nearestEnemy(W, m.x, m.y, m.o, W.A.fog ? 160 : 1e9);
      if (tg) { const d = wrapA(Math.atan2(tg.y - m.y, tg.x - m.x) - m.a); m.a = wrapA(m.a + clamp(d, -MTURN * h, MTURN * h)); }
      m.px = m.x; m.py = m.y;
      m.x += Math.cos(m.a) * MS * h; m.y += Math.sin(m.a) * MS * h;
      let boom = m.t <= 0 || Math.abs(m.x) > W.hw || Math.abs(m.y) > W.hh;
      for (const w of W.walls) if (segBox(m.px, m.py, m.x, m.y, w, 2) >= 0) boom = true;
      for (const b of W.bodies) if (Math.hypot(m.x - b.x, m.y - b.y) < b.r) boom = true;
      for (const r of W.rocks) if (segCircle(m.px, m.py, m.x, m.y, r.x, r.y, r.r + 3) >= 0) boom = true;
      for (const s of W.ships) if (s.alive && s.seat !== m.o && segCircle(m.px - s.px, m.py - s.py, m.x - s.x, m.y - s.y, 0, 0, SR + 4) >= 0) boom = true;
      if (boom) { W.mis.splice(i, 1); explode(W, m.x, m.y, 20, m.o, hooks, host); }
    }
  }
  function stepMines(W, h, hooks, host) {
    for (let i = W.mines.length - 1; i >= 0; i--) {
      const m = W.mines[i];
      m.t += h;
      if (m.t > MINE_LIFE) { W.mines.splice(i, 1); continue; }
      if (m.t < MINE_ARM) continue;
      if (W.ships.some((s) => s.alive && s.seat !== m.o && Math.hypot(s.x - m.x, s.y - m.y) < MINE_TRIG + SR)) { W.mines.splice(i, 1); explode(W, m.x, m.y, MINE_BLAST, m.o, hooks, host); }
    }
  }
  function stepRocks(W, h, hooks) {
    const hole = W.A.hole ? W.bodies[0] : null;
    for (let i = W.rocks.length - 1; i >= 0; i--) {
      const r = W.rocks[i];
      if (r.m) { // meteor: straight line, wraps around the field, burns up in a star/well
        r.x += r.vx * h; r.y += r.vy * h;
        const ox = W.hw + r.r + 16, oy = W.hh + r.r + 16;
        if (r.y > oy || r.y < -oy) { r.y = r.y > 0 ? -oy + 2 : oy - 2; r.x = (W.rnd() * 2 - 1) * W.hw; }
        if (r.x > ox) r.x = -ox + 2; else if (r.x < -ox) r.x = ox - 2;
        for (const b of W.bodies) if (Math.hypot(r.x - b.x, r.y - b.y) < b.r + r.r) { W.rocks.splice(i, 1); emit(W, hooks, 'r', r.x, r.y, r.r, 1); W.rocks.push(newMeteor(W, false)); break; }
        continue;
      }
      if (W.bodies.length) { const g = gravAcc(W, r.x, r.y, 0.25); r.vx += g[0] * h; r.vy += g[1] * h; }
      r.x += r.vx * h; r.y += r.vy * h;
      if (hole && Math.hypot(r.x, r.y) < HOLE_R + r.r * 0.3) { W.rocks.splice(i, 1); emit(W, hooks, 'k', r.x, r.y, -1); continue; }
      solidBounce(W, r, r.r, 1);
      const sp = Math.hypot(r.vx, r.vy); if (sp > 60) { r.vx *= 60 / sp; r.vy *= 60 / sp; }
    }
  }
  function collideShips(W, hooks, host) {
    const S = W.ships;
    for (const s of S) {
      if (!s.alive) continue;
      for (let ri = W.rocks.length - 1; ri >= 0; ri--) {
        const r = W.rocks[ri];
        let dx = s.x - r.x, dy = s.y - r.y, d = Math.hypot(dx, dy);
        const R = SR + r.r;
        if (d >= R) continue;
        if (r.m && s.inv <= 0) { // meteor strike
          W.rocks.splice(ri, 1);
          emit(W, hooks, 'r', r.x, r.y, r.r, 1);
          if (host) W.rocks.push(newMeteor(W, false));
          s.vx += r.vx * 0.5; s.vy += r.vy * 0.5;
          damage(W, s, -1, hooks);
          if (!s.alive) break;
          continue;
        }
        if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
        const nx = dx / d, ny = dy / d, mr = (r.r * r.r) / 81, ms = 1;
        const ov = R - d; s.x += nx * ov * mr / (mr + ms); s.y += ny * ov * mr / (mr + ms);
        if (!r.m) { r.x -= nx * ov * ms / (mr + ms); r.y -= ny * ov * ms / (mr + ms); }
        const vn = (s.vx - r.vx) * nx + (s.vy - r.vy) * ny;
        if (vn < 0) { const j = -(1.6) * vn / (1 / ms + 1 / mr); s.vx += j / ms * nx; s.vy += j / ms * ny; if (!r.m) { r.vx -= j / mr * nx; r.vy -= j / mr * ny; } if (hooks && hooks.bonk && -vn > 40) hooks.bonk(s, -vn); }
      }
      if (!s.alive) continue;
      if (W.A.hole && Math.hypot(s.x, s.y) < HOLE_R) { // swallowed: lose a life, respawn at the farthest slot
        s.inv = 0; s.sh = 0;
        damage(W, s, -1, hooks);
        emit(W, hooks, 'k', s.x, s.y, s.seat);
        if (s.alive) {
          const sl = slots(W); let bi = 0, bd = -1;
          sl.forEach((p, k) => { let d = 999; for (const o of S) if (o !== s && o.alive) d = Math.min(d, Math.hypot(o.x - p[0], o.y - p[1])); if (d > bd) { bd = d; bi = k; } });
          const p = spawnAt(W, bi); s.x = s.px = p.x; s.y = s.py = p.y; s.vx = 0; s.vy = 0; s.a = s.g = p.a; s.inv = 2;
        }
      }
    }
    for (let i = 0; i < S.length; i++) for (let j = i + 1; j < S.length; j++) {
      const a = S[i], b = S[j];
      if (!a.alive || !b.alive) continue;
      let dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
      if (d >= SR * 2) continue;
      if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
      const nx = dx / d, ny = dy / d, ov = SR * 2 - d;
      a.x -= nx * ov / 2; a.y -= ny * ov / 2; b.x += nx * ov / 2; b.y += ny * ov / 2;
      const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
      if (vn < 0) { const jm = -0.9 * vn; a.vx -= jm * nx; a.vy -= jm * ny; b.vx += jm * nx; b.vy += jm * ny; if (hooks && hooks.bonk && -vn > 40) hooks.bonk(a, -vn); }
    }
  }
  function pickups(W, hooks) {
    for (let i = W.pu.length - 1; i >= 0; i--) {
      const p = W.pu[i];
      const s = W.ships.find((q) => q.alive && Math.hypot(q.x - p.x, q.y - p.y) < SR + 11);
      if (!s) continue;
      W.pu.splice(i, 1);
      if (p.k === 'S') s.spr = 9;
      else if (p.k === 'D') s.sh = 15;
      else { s.sk = p.k; s.sn = p.k === 'L' ? 2 : 3; }
      emit(W, hooks, 'p', p.x, p.y, s.seat, PU_KINDS.indexOf(p.k));
    }
  }
  /* host only (uses Math.random): power-ups now and then, up to 3 on the field */
  function maybePowerup(W, dt) {
    for (let i = W.pu.length - 1; i >= 0; i--) { W.pu[i].t -= dt; if (W.pu[i].t <= 0) W.pu.splice(i, 1); }
    W.puT -= dt;
    if (W.puT > 0) return;
    W.puT = 6.5;
    if (W.pu.length >= 3) return;
    for (let k = 0; k < 40; k++) {
      const x = (Math.random() * 2 - 1) * (W.hw - 40) * 0.8, y = (Math.random() * 2 - 1) * (W.hh - 40) * 0.8;
      if (!freeSpot(W, x, y, 14)) continue;
      if (W.rocks.some((r) => Math.hypot(r.x - x, r.y - y) < r.r + 16)) continue;
      if (W.ships.some((s) => s.alive && Math.hypot(s.x - x, s.y - y) < 60)) continue;
      W.pu.push({ x: Math.round(x), y: Math.round(y), k: PU_KINDS[Math.floor(Math.random() * PU_KINDS.length)], t: 16 });
      return;
    }
  }
  /* one fixed step of the arena (host). inputs[seat]; af = auto-fire option */
  function stepWorld(W, inputs, hooks, af, host) {
    const h = H;
    W.t += h;
    updateBodies(W);
    for (const s of W.ships) {
      if (!s.alive) continue;
      const i = (inputs && inputs[s.seat]) || {};
      moveShip(W, s, i, h, hooks);
      if (s.cd > 0) s.cd -= h;
      if (s.scd > 0) s.scd -= h;
      if (s.inv > 0) s.inv -= h;
      if (s.sh > 0) { s.sh -= h; if (s.sh <= 0) s.sh = 0; }
      if (s.spr > 0) s.spr -= h;
      if (s.fl > 0) s.fl -= h;
      if (s.cd <= 0 && wantsFire(i, af)) fire(W, s, af, hooks, i);
      const sc = i.s | 0;
      if (s.sc == null) s.sc = sc;
      if (sc !== s.sc) { s.sc = sc; special(W, s, hooks, host, i); }
    }
    collideShips(W, hooks, host);
    stepBullets(W, h, hooks, host);
    stepMissiles(W, h, hooks, host);
    stepMines(W, h, hooks, host);
    stepRocks(W, h, hooks);
    pickups(W, hooks);
  }

  /* ----- AI ----- */
  const AIC = {
    1: { rate: 0.24, noise: 0.28, lead: 0.25, tol: 0.32, dodge: 0.08, pu: 0.25, fireP: 0.55, see: 120, met: 0.2, sight: 190, hear: 210, flee: 4 },
    2: { rate: 0.11, noise: 0.12, lead: 0.8, tol: 0.17, dodge: 0.45, pu: 0.6, fireP: 0.9, see: 150, met: 0.6, sight: 215, hear: 240, flee: 6 },
    3: { rate: 0.05, noise: 0.075, lead: 1, tol: 0.1, dodge: 0.85, pu: 0.9, fireP: 0.88, see: 170, met: 0.95, kite: 1, sight: 240, hear: 280, flee: 5.5 },
  };
  function losClear(W, x0, y0, x1, y1, pad) {
    for (const w of W.walls) if (segBox(x0, y0, x1, y1, w, pad) >= 0) return false;
    for (const r of W.rocks) if (!r.m && segCircle(x0, y0, x1, y1, r.x, r.y, r.r + pad) >= 0) return false;
    for (const b of W.bodies) if (segCircle(x0, y0, x1, y1, b.x, b.y, b.r) >= 0) return false;
    return true;
  }
  function blockerRock(W, x0, y0, x1, y1) {
    let best = null, bt = 2;
    for (const r of W.rocks) { if (r.m) continue; const t = segCircle(x0, y0, x1, y1, r.x, r.y, r.r); if (t >= 0 && t < bt) { bt = t; best = r; } }
    return best;
  }
  function hazard(W, x, y) { // penalty for standing at (x, y)
    let p = 0;
    const m = 24;
    if (Math.abs(x) > W.hw - m) p += (Math.abs(x) - (W.hw - m)) * 8;
    if (Math.abs(y) > W.hh - m) p += (Math.abs(y) - (W.hh - m)) * 8;
    for (const b of W.bodies) {
      const d = Math.hypot(x - b.x, y - b.y);
      if (b.k === 'hole') { if (d < 120) p += (120 - d) * 9; }
      else if (d < b.r + 38) p += (b.r + 38 - d) * 8;
    }
    for (const w of W.walls) if (inBox(x, y, w, SR + 6)) p += 300;
    for (const r of W.rocks) {
      if (r.m) { for (let k = 0; k < 3; k++) { const tx = r.x + r.vx * k * 0.2, ty = r.y + r.vy * k * 0.2; if (Math.hypot(x - tx, y - ty) < r.r + SR + 18) { p += 220; break; } } continue; }
      const d = Math.hypot(x - r.x, y - r.y); if (d < r.r + SR + 8) p += 120;
    }
    for (const mn of W.mines) if (Math.hypot(x - mn.x, y - mn.y) < MINE_BLAST + 8) p += 200;
    return p;
  }
  /* coarse navigation grid + BFS distance field so bots find their way around walls on big maps */
  const NC = 40;
  function buildNav(W) {
    const cols = Math.ceil(W.hw * 2 / NC), rows = Math.ceil(W.hh * 2 / NC), bl = new Uint8Array(cols * rows);
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
      const x = -W.hw + (i + 0.5) * NC, y = -W.hh + (j + 0.5) * NC;
      let b = 0;
      for (const w of W.walls) if (inBox(x, y, w, SR + 6)) { b = 1; break; }
      if (!b) for (const q of W.bodies) if (q.k !== 'star' && Math.hypot(x - q.x, y - q.y) < (q.k === 'hole' ? 60 : q.r + 14)) b = 1;
      bl[j * cols + i] = b;
    }
    W.nav = { cols, rows, bl, q: new Int32Array(cols * rows) };
    return W.nav;
  }
  function cellOf(N, W, x, y) { const i = clamp(Math.floor((x + W.hw) / NC), 0, N.cols - 1), j = clamp(Math.floor((y + W.hh) / NC), 0, N.rows - 1); return j * N.cols + i; }
  function navField(W, mem, gx, gy) {
    const N = W.nav || buildNav(W), gc = cellOf(N, W, gx, gy);
    if (mem.ff && mem.ffc === gc && mem.ffw === W) return mem.ff;
    const n = N.cols * N.rows;
    if (!mem.ff || mem.ff.length !== n) mem.ff = new Float32Array(n);
    const D = mem.ff, Q = N.q; D.fill(1e6);
    let h = 0, t = 0;
    if (!N.bl[gc]) { D[gc] = 0; Q[t++] = gc; }
    else { // goal sits in a blocked cell (hugging a wall): start from the free cells it can actually see
      const gi = gc % N.cols, gj = (gc - gi) / N.cols;
      for (let r = 1; r <= 2 && !t; r++) for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
        const i = gi + di, j = gj + dj; if (i < 0 || j < 0 || i >= N.cols || j >= N.rows) continue;
        const c = j * N.cols + i; if (N.bl[c] || D[c] < 1e6) continue;
        if (!wallsClear(W, gx, gy, -W.hw + (i + 0.5) * NC, -W.hh + (j + 0.5) * NC)) continue;
        D[c] = r; Q[t++] = c;
      }
      if (!t) { D[gc] = 0; Q[t++] = gc; }
    }
    while (h < t) {
      const c = Q[h++], i = c % N.cols, j = (c - i) / N.cols, nd = D[c] + 1;
      if (i > 0 && !N.bl[c - 1] && D[c - 1] > nd) { D[c - 1] = nd; Q[t++] = c - 1; }
      if (i < N.cols - 1 && !N.bl[c + 1] && D[c + 1] > nd) { D[c + 1] = nd; Q[t++] = c + 1; }
      if (j > 0 && !N.bl[c - N.cols] && D[c - N.cols] > nd) { D[c - N.cols] = nd; Q[t++] = c - N.cols; }
      if (j < N.rows - 1 && !N.bl[c + N.cols] && D[c + N.cols] > nd) { D[c + N.cols] = nd; Q[t++] = c + N.cols; }
    }
    mem.ffc = gc; mem.ffw = W;
    return D;
  }
  /* what this bot can notice: ships in sight (walls block), ships that fire nearby, whoever just hit it, radar pings */
  function aiSpot(W, s, C, mem) {
    const sight = W.A.fog ? C.see : C.sight;
    let best = null, bd = 1e9;
    for (const o of W.ships) {
      if (!o.alive || o.seat === s.seat) continue;
      const d = Math.hypot(o.x - s.x, o.y - s.y);
      if (d < sight && (d < 120 || wallsClear(W, s.x, s.y, o.x, o.y))) { if (d < bd) { bd = d; best = o; } }
      else if (o.fl > 0 && d < C.hear) mem.last = { x: o.x + (Math.random() - 0.5) * 60, y: o.y + (Math.random() - 0.5) * 60, t: W.t };
    }
    if (mem.lv0 !== s.lives) { // got hit: look where it came from
      if (mem.lv0 != null && s.by >= 0 && W.ships[s.by] && W.ships[s.by].alive) {
        const o = W.ships[s.by]; mem.last = { x: o.x, y: o.y, t: W.t };
        if (C.flee) { // break contact for a while, then come back hunting
          const dx = s.x - o.x, dy = s.y - o.y, dd = Math.hypot(dx, dy) || 1;
          mem.fl = [clamp(s.x + dx / dd * 420, -W.hw + 70, W.hw - 70), clamp(s.y + dy / dd * 420, -W.hh + 70, W.hh - 70)]; mem.flT = W.t + C.flee * (0.8 + Math.random() * 0.4);
        }
      }
      mem.lv0 = s.lives;
    }
    if (W.A.fog && W.t > 1 && W.t % PING < 0.25 && (mem.pg == null || W.t - mem.pg > 1)) { mem.pg = W.t; const o = nearestEnemy(W, s.x, s.y, s.seat, 1e9); if (o && Math.random() < 0.35 + C.met * 0.4) mem.last = { x: o.x, y: o.y, t: W.t }; }
    return best;
  }
  function aiThink(W, s, mem, lv, dt, af) {
    const C = AIC[lv] || AIC[2];
    const inp = mem.inp || (mem.inp = { x: 0, y: 0, ax: 0, ay: 0, f: 0, s: 0, m: 'b' });
    if (!s.alive) { inp.x = inp.y = 0; inp.f = 0; return inp; }
    mem.t = (mem.t || 0) - dt;
    if (mem.t > 0) return inp;
    mem.t = C.rate * (0.7 + Math.random() * 0.6);
    const steer = (ang, thrust) => { const m = thrust > 0 ? 0.32 + 0.48 * clamp(thrust, 0, 1) : 0.22; inp.x = r2(Math.cos(ang) * m); inp.y = r2(Math.sin(ang) * m); };
    inp.f = 0; inp.m = 'b'; inp.ax = 0; inp.ay = 0;
    // 1. dodge incoming bullets / missiles (and meteors)
    if (Math.random() < C.dodge) {
      const threats = [];
      for (const b of W.bul) if (b.o !== s.seat) threats.push([b.x, b.y, b.vx, b.vy, SR + 9]);
      for (const m of W.mis) if (m.o !== s.seat) threats.push([m.x, m.y, Math.cos(m.a) * MS, Math.sin(m.a) * MS, SR + 9]);
      if (Math.random() < C.met) for (const r of W.rocks) if (r.m) threats.push([r.x, r.y, r.vx, r.vy, SR + r.r + 10]);
      for (const b of threats) {
        const rx = s.x - b[0], ry = s.y - b[1], rvx = s.vx - b[2], rvy = s.vy - b[3];
        const vv = rvx * rvx + rvy * rvy; if (vv < 1) continue;
        const tc = -(rx * rvx + ry * rvy) / vv;
        if (tc < 0 || tc > 0.6) continue;
        const cx = rx + rvx * tc, cy = ry + rvy * tc;
        if (Math.hypot(cx, cy) > b[4]) continue;
        const bl = Math.hypot(b[2], b[3]) || 1;
        let px = -b[3] / bl, py = b[2] / bl;
        if (px * rx + py * ry < 0) { px = -px; py = -py; }
        if (hazard(W, s.x + px * 40, s.y + py * 40) > hazard(W, s.x - px * 40, s.y - py * 40) + 50) { px = -px; py = -py; }
        steer(Math.atan2(py, px), 1); mem.t = 0.18;
        return inp;
      }
    }
    // 2. keep away from the black hole / the stars
    for (const b of W.bodies) {
      const d = Math.hypot(s.x - b.x, s.y - b.y);
      if (b.k === 'hole' && d < 90) { steer(Math.atan2(s.y - b.y, s.x - b.x) + 0.6, 1); return inp; }
      if (b.k === 'star' && d < b.r + 34) { steer(Math.atan2(s.y - b.y, s.x - b.x) + 0.4, 1); return inp; }
    }
    // 3. target
    const tgt = aiSpot(W, s, C, mem);
    if (tgt) mem.last = { x: tgt.x, y: tgt.y, t: W.t };
    const d = tgt ? Math.hypot(tgt.x - s.x, tgt.y - s.y) : 1e9;
    // power-up?
    let pu = null;
    if (W.pu.length && Math.random() < C.pu) { let bd = 1e9; for (const p of W.pu) { const q = Math.hypot(p.x - s.x, p.y - s.y); if (q < bd && q < C.sight + 80) { bd = q; pu = p; } } if (pu && tgt && bd > d * 1.2 && d < 150) pu = null; }
    // special weapons
    if (s.sk && tgt && s.scd <= 0) {
      const aimA = Math.atan2(tgt.y - s.y, tgt.x - s.x), off = Math.abs(wrapA(aimA - s.g));
      let use = false;
      if (s.sk === 'L') use = off < (lv >= 3 ? 0.05 : C.tol * 0.6) && d < LASER_LEN && losClear(W, s.x, s.y, tgt.x, tgt.y, 1) || (lv === 1 && Math.random() < 0.06);
      else if (s.sk === 'M') use = d < 320 && (lv > 1 || Math.random() < 0.3);
      else if (s.sk === 'N') use = lv >= 3 ? d < 110 && Math.abs(wrapA(aimA - s.a)) > 1.6 : Math.random() < (lv === 1 ? 0.08 : 0.15) && d < 160;
      if (use) inp.s = ((inp.s | 0) + 1) % 1000;
    }
    const fleeing = mem.flT > W.t && mem.fl && Math.hypot(mem.fl[0] - s.x, mem.fl[1] - s.y) > 40;
    if (mem.fl && !fleeing) { mem.fl = null; if (!tgt) mem.last = null; } // got away: start searching again
    if (tgt && !pu && !fleeing && d < 260 && losClear(W, s.x, s.y, tgt.x, tgt.y, 2)) {
      // attack: lead the target
      let tx = tgt.x, ty = tgt.y, tt = d / BS;
      for (let k = 0; k < 2; k++) { tx = tgt.x + tgt.vx * tt * C.lead; ty = tgt.y + tgt.vy * tt * C.lead; tt = Math.hypot(tx - s.x, ty - s.y) / BS; }
      const aim = Math.atan2(ty - s.y, tx - s.x) + gauss() * C.noise;
      if (C.kite) { // 어려움: aim with a separate gun (twin-stick style) while circling the target
        inp.m = 't'; inp.ax = r2(Math.cos(aim) * 0.5); inp.ay = r2(Math.sin(aim) * 0.5);
        const toT = Math.atan2(tgt.y - s.y, tgt.x - s.x);
        if (!mem.side || Math.random() < 0.015) mem.side = Math.random() < 0.5 ? -1 : 1;
        const off = d > 230 ? 0.7 : d < 120 ? 2.3 : 1.57;
        let mv = toT + mem.side * off;
        if (hazard(W, s.x + Math.cos(mv) * 60, s.y + Math.sin(mv) * 60) > 80) { mem.side = -mem.side; mv = toT + mem.side * off; }
        steer(mv, hazard(W, s.x + Math.cos(mv) * 60, s.y + Math.sin(mv) * 60) > 80 ? 0 : 0.5);
        if (Math.abs(wrapA(aim - s.g)) < C.tol && Math.random() < C.fireP) inp.f = 1;
        return inp;
      }
      let thrust = d > 220 ? 0.6 : d < 95 ? 0 : 0.15;
      if (hazard(W, s.x + Math.cos(aim) * 50, s.y + Math.sin(aim) * 50) > 100) thrust = 0;
      steer(aim, thrust);
      if (Math.abs(wrapA(aim - s.a)) < C.tol && Math.random() < C.fireP) inp.f = 1;
      return inp;
    }
    // 4. travel toward a goal (power-up, the target, its last known spot, else wander)
    let gx = 0, gy = 0;
    if (fleeing) { gx = mem.fl[0]; gy = mem.fl[1]; }
    else if (pu) { gx = pu.x; gy = pu.y; }
    else if (tgt) { gx = tgt.x; gy = tgt.y; }
    else if (mem.last && W.t - mem.last.t < 8 && Math.hypot(mem.last.x - s.x, mem.last.y - s.y) > 40) { gx = mem.last.x; gy = mem.last.y; }
    else { // patrol: the middle, a random spot, or around the last place someone was seen
      if (!mem.wp || Math.hypot(mem.wp[0] - s.x, mem.wp[1] - s.y) < 50 || W.t - (mem.wpT || 0) > 10) {
        const q = Math.random(), sc = q < 0.15 ? 0.4 : 1, cx = q > 0.8 && mem.last ? mem.last.x : 0, cy = q > 0.8 && mem.last ? mem.last.y : 0;
        for (let k = 0; k < 20; k++) { const x = clamp(cx + (Math.random() * 2 - 1) * (W.hw - 70) * sc, -W.hw + 60, W.hw - 60), y = clamp(cy + (Math.random() * 2 - 1) * (W.hh - 70) * sc, -W.hh + 60, W.hh - 60); mem.wp = [x, y]; if (freeSpot(W, x, y, 20)) break; }
        mem.wpT = W.t;
      }
      gx = mem.wp[0]; gy = mem.wp[1]; mem.pat = 1;
    }
    // a rock in the way of the target: shoot it (보통 이상)
    if (tgt && lv >= 2 && d < 320 && !fleeing) {
      const r = blockerRock(W, s.x, s.y, tgt.x, tgt.y);
      if (r && Math.hypot(r.x - s.x, r.y - s.y) < 200 && wallsClear(W, s.x, s.y, r.x, r.y)) {
        const aim = Math.atan2(r.y - s.y, r.x - s.x);
        steer(aim, 0);
        if (Math.abs(wrapA(aim - s.a)) < 0.2) inp.f = 1;
        return inp;
      }
    }
    const N = W.walls.length || W.bodies.length ? navField(W, mem, gx, gy) : null;
    let best = -1e9, ba = s.a;
    for (let k = 0; k < 12; k++) {
      const an = k * Math.PI / 6, px = s.x + s.vx * 0.3 + Math.cos(an) * 55, py = s.y + s.vy * 0.3 + Math.sin(an) * 55;
      const eu = Math.hypot(px - gx, py - gy);
      let sc = (N ? -Math.min(N[cellOf(W.nav, W, px, py)] * NC, 1e5) - eu * 0.3 : -eu) - hazard(W, px, py);
      if (!wallsClear(W, s.x, s.y, px, py)) sc -= 3000; else if (!losClear(W, s.x, s.y, px, py, SR)) sc -= 160;
      if (sc > best) { best = sc; ba = an; }
    }
    steer(ba + gauss() * C.noise * 0.5, mem.pat ? 0.3 : 0.75); mem.pat = 0;
    if (af === 0 && tgt && Math.abs(wrapA(Math.atan2(tgt.y - s.y, tgt.x - s.x) - s.a)) < C.tol && d < 360 && wallsClear(W, s.x, s.y, tgt.x, tgt.y)) inp.f = 1;
    return inp;
  }

  /* ======================= state ======================= */
  const NAR = ARENAS.length;
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    // spawn slots: people first (online, each person's own ship starts at a short edge)
    const order = players.map((p, i) => [i, p && p.ai ? 1 : 0]).sort((a, b) => a[1] - b[1] || a[0] - b[0]).map((x) => x[0]);
    const sp = Array(n).fill(0); order.forEach((seat, k) => { sp[seat] = k; });
    const pk = Number.isInteger(o.arena) && o.arena >= 0 && o.arena < NAR ? o.arena : -1;
    return {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), sp,
      b: o.rounds === 5 ? 5 : 3, pk, af: o.fire === 1 ? 1 : 0, gv: o.grav === 1 ? 1 : 0,
      ph: 'count', ar: pk >= 0 ? pk : U.rand(NAR), rd: 1, sd: 1 + U.rand(2147483646), wins: Array(n).fill(0), rw: -1, res: null,
    };
  }
  function roundOver(s, winner) {
    const n = Object.assign({}, s, { wins: s.wins.slice(), ph: 'end', rw: winner });
    if (winner >= 0) n.wins[winner]++;
    return n;
  }
  function nextRound(s) {
    const need = Math.floor(s.b / 2) + 1, mx = Math.max(...s.wins);
    if (mx >= need || s.rd >= s.b * 2 + 1) {
      const order = s.wins.map((v, i) => [i, v]).sort((a, b) => b[1] - a[1] || a[0] - b[0]);
      return Object.assign({}, s, { ph: 'done', res: order });
    }
    let ar = s.ar;
    if (s.pk < 0) { ar = U.rand(NAR - 1); if (ar >= s.ar) ar++; }
    return Object.assign({}, s, { rd: s.rd + 1, sd: 1 + U.rand(2147483646), ph: 'count', ar, rw: -1 });
  }
  /* who won this round right now? −2 = still going, −1 = draw, else seat */
  function roundWinner(W) {
    const alive = W.ships.filter((s) => s.alive);
    if (alive.length === 1) return alive[0].seat;
    if (alive.length === 0) return -1;
    if (W.t > CAP_T) {
      const mx = Math.max(...alive.map((s) => s.lives)), top = alive.filter((s) => s.lives === mx);
      return top.length === 1 ? top[0].seat : -1;
    }
    return -2;
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승',
      text: (s.pk >= 0 && ARENAS[s.pk] ? ARENAS[s.pk].name : '무작위 전장') + ' · ' + (s.b === 5 ? '5판 3선승' : '3판 2선승') + '\n' + s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '승').join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `.ss-chip{position:absolute;left:8px;top:60px;z-index:6;appearance:none;border:1px solid rgba(242,233,216,.2);background:rgba(10,12,28,.8);color:var(--ink,#f2e9d8);border-radius:12px;min-height:44px;padding:4px 12px;font:700 12px/1.2 "IBM Plex Sans KR",system-ui,sans-serif;cursor:pointer;touch-action:manipulation;user-select:none;-webkit-user-select:none}
.ss-chip b{color:var(--brass,#e3ae45)}`;
  const STICK_R = 48, TOP = 56;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let st = null, key = null, W = null, phase = 'wait', cd = 0, endT = 0, acc = 0, lay = null, hintT = 0, shake = 0, lastSfx = 0;
    let cfg = { ctl: 'b' };
    try { const c = JSON.parse(localStorage.getItem('lounge.spaceshoot.cfg') || 'null'); if (c && (c.ctl === 'b' || c.ctl === 't')) cfg.ctl = c.ctl; } catch (e) {}
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const host = () => !api.online || api.isHost;
    const pilots = () => api.mySeats().slice(0, 1);        // the one person steering on this phone
    const isMine = (s) => pilots().includes(s);
    const myShip = () => { const m = pilots(); return m.length && W ? W.ships[m[0]] : null; };
    const autoSeat = (s) => { const p = api.players[s]; if (!p) return false; if (p.ai) return true; return !api.online && p.local && !isMine(s); };
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    let aiMem = [], inputs = {}, parts = [], floats = [], beams = [];
    const locIn = {};
    let pubT = 0, hsQ = 0, inQ = 0, lastSig = '', inT = 0, snaps = [], lastQ = -1, lastFx = 0, rtt = 0.15;
    const sendT = {}, iqOf = {}, remIn = {};
    const cam = { x: 0, y: 0, z: 1 };

    function curKey() { return st ? st.rid + '.' + st.rd + '.' + st.ar : null; }
    function startRound() {
      W = newWorld(st.ar, st.sd, st.n, st.sp, st.gv);
      aiMem = W.ships.map(() => ({}));
      inputs = {}; parts = []; floats = []; beams = []; snaps = []; lastQ = -1; lastFx = 0; acc = 0;
      for (const s of pilots()) locIn[s] = { x: 0, y: 0, ax: 0, ay: 0, f: 0, s: (locIn[s] && locIn[s].s) || 0, m: cfg.ctl, aa: 1 };
      phase = st.ph === 'play' ? 'play' : 'count';
      cd = COUNT; endT = END_T;
      if (st.rd === 1 && pilots().length) hintT = 6;
      mmCv = null;
      layout();
      camUpdate(0, true);
    }

    /* ----- layout & camera ----- */
    function layout() {
      const w = cv.w, h = cv.h;
      const bot = pilots().length ? 120 : 10;
      const z0 = clamp(Math.min(w / 340, (h - TOP - bot) / 500), 0.85, 1.6);
      // one pilot whose ship starts at the top edge (online): turn the whole view so it starts at the bottom
      const m = pilots(), wf = m.length === 1 && W && W.ships[m[0]] && slots(W)[(st.sp || [])[m[0]] || 0][1] < 0;
      lay = { z0, ax: w / 2, ay: TOP + (h - TOP - bot) / 2, f: wf ? -1 : 1, bot };
      if (W) { // minimap box (top-right)
        const mw = Math.round(Math.min(78, 96 * W.hw / W.hh)), s = mw / (W.hw * 2), mh = Math.round(W.hh * 2 * s);
        lay.mm = { x: w - mw - 8, y: 6, w: mw, h: mh, s };
      }
      starPat = null;
      syncChip();
    }
    cv.onresize = layout;
    const X = (x) => lay.ax + (x - cam.x) * cam.z * lay.f, Y = (y) => lay.ay + (y - cam.y) * cam.z * lay.f;
    function camUpdate(rdt, snap) {
      if (!W || !lay) return;
      const w = cv.w, h = cv.h, me = myShip();
      let tx = 0, ty = 0, tz = lay.z0;
      const availH = h - TOP - lay.bot;
      const zFit = Math.min(w / (W.hw * 2 + 40), availH / (W.hh * 2 + 40));
      if (me && me.alive) { tx = me.x + me.vx * 0.3 + Math.cos(me.g) * 26; ty = me.y + me.vy * 0.3 + Math.sin(me.g) * 26; }
      else {
        const al = W.ships.filter((c) => c.alive);
        if (al.length) {
          let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
          for (const c of al) { x0 = Math.min(x0, c.x); x1 = Math.max(x1, c.x); y0 = Math.min(y0, c.y); y1 = Math.max(y1, c.y); }
          tx = (x0 + x1) / 2; ty = (y0 + y1) / 2;
          tz = clamp(Math.min(w / (x1 - x0 + 220), availH / (y1 - y0 + 260)), Math.min(zFit, lay.z0), lay.z0);
        }
      }
      // keep the view inside the field (a little border is fine)
      const hx = (w / 2) / tz, pad = 30;
      tx = W.hw * 2 + pad * 2 <= hx * 2 ? 0 : clamp(tx, -W.hw - pad + hx, W.hw + pad - hx);
      const up = (lay.ay - TOP) / tz, dn = (h - lay.bot - 6 - lay.ay) / tz;
      const lo = lay.f > 0 ? up : dn, hi = lay.f > 0 ? dn : up;
      ty = W.hh * 2 + pad * 2 <= lo + hi ? (lo - hi) / 2 : clamp(ty, -W.hh - pad + lo, W.hh + pad - hi);
      if (snap || Math.hypot(tx - cam.x, ty - cam.y) > 300) { cam.x = tx; cam.y = ty; cam.z = tz; return; }
      const k = 1 - Math.exp(-6 * rdt), kz = 1 - Math.exp(-2.5 * rdt);
      cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k; cam.z += (tz - cam.z) * kz;
    }
    const onScreen = (x, y, r) => { const sx = X(x), sy = Y(y), rr = (r || 0) * cam.z + 30; return sx > -rr && sx < cv.w + rr && sy > -rr && sy < cv.h + rr; };

    /* ----- input ----- */
    const ptrs = new Map();
    const seatAt = () => { const m = pilots(); return m.length ? m[0] : -1; };
    const SPLIT = 0.55;
    function fireBtn() { const r = 40; return { x: cv.w - r - 18, y: cv.h - r - 24, r }; }
    function specBtn() { const r = 30; return st && st.af ? { x: cv.w - 40 - 18, y: cv.h - 40 - 24, r: 36 } : { x: cv.w - 40 * 2 - 18 - r - 12, y: cv.h - r - 30, r }; }
    function refresh() {
      for (const s of pilots()) {
        const I = locIn[s] || (locIn[s] = { x: 0, y: 0, ax: 0, ay: 0, f: 0, s: 0, m: cfg.ctl, aa: 1 });
        I.m = cfg.ctl; I.aa = 1; I.x = 0; I.y = 0; I.ax = 0; I.ay = 0; I.f = 0;
        for (const p of ptrs.values()) {
          if (p.seat !== s) continue;
          if (p.kind === 'stick' || p.kind === 'aim') {
            let dx = p.x - p.ax, dy = p.y - p.ay;
            if (lay && lay.f < 0) { dx = -dx; dy = -dy; }
            const d = Math.hypot(dx, dy);
            if (d > 6) { const m = Math.min(1, d / STICK_R); if (p.kind === 'stick') { I.x = r2(dx / d * m); I.y = r2(dy / d * m); } else { I.ax = r2(dx / d * m); I.ay = r2(dy / d * m); } }
          } else if (p.kind === 'fire') I.f = 1;
        }
        // keyboard / gamepad (api.input, rebindable): keys = full push (turn + thrust), a stick is analog like the touch stick
        const inp = api.input;
        if (inp) {
          const fl = lay && lay.f < 0 ? -1 : 1;
          const unit = (x, y) => { const m = Math.hypot(x, y), k = m > 1 ? 1 / m : 1; return [r2(x * k * fl), r2(y * k * fl)]; };
          const kx = inp.axis('left', 'right'), ky = inp.axis('up', 'down');
          if (kx || ky) [I.x, I.y] = unit(kx, ky);
          if (cfg.ctl === 't') { const ax = inp.axis('aimL', 'aimR'), ay = inp.axis('aimU', 'aimD'); if (ax || ay) [I.ax, I.ay] = unit(ax, ay); }
          if (inp.held('fire')) I.f = 1;
        }
      }
    }
    function pressSpecial(s) {
      const I = locIn[s]; if (!I) return;
      const c = W && W.ships[s];
      if (!c || !c.sk || !c.alive) { api.buzz(4); return; } // nothing to use: don't waste the press
      I.s = ((I.s | 0) + 1) % 1000;
      api.buzz(18);
      pubT = 0; inT = 0;
    }
    function onDown(e) {
      const p = cv.local(e), seat = seatAt();
      if (seat < 0 || !W) return;
      e.preventDefault();
      if (p.y < TOP - 4 && p.x > cv.w * 0.25) return; // score panel / minimap: no input
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      hintT = Math.min(hintT, 1);
      const sb = specBtn();
      if (Math.hypot(p.x - sb.x, p.y - sb.y) < sb.r + 8) { pressSpecial(seat); ptrs.set(e.pointerId, { seat, kind: 'spec', x: p.x, y: p.y }); refresh(); return; }
      if (p.x < cv.w * SPLIT) {
        for (const [id, q] of ptrs) if (q.seat === seat && q.kind === 'stick') ptrs.delete(id);
        ptrs.set(e.pointerId, { seat, kind: 'stick', ax: p.x, ay: p.y, x: p.x, y: p.y, hot: false });
      } else if (cfg.ctl === 't') {
        for (const [id, q] of ptrs) if (q.seat === seat && q.kind === 'aim') ptrs.delete(id);
        ptrs.set(e.pointerId, { seat, kind: 'aim', ax: p.x, ay: p.y, x: p.x, y: p.y });
      } else if (!st.af) {
        ptrs.set(e.pointerId, { seat, kind: 'fire', x: p.x, y: p.y });
        api.buzz(8);
      }
      refresh();
    }
    function onMove(e) {
      const q = ptrs.get(e.pointerId);
      if (!q) return;
      const p = cv.local(e);
      q.x = p.x; q.y = p.y;
      if (q.kind === 'stick' || q.kind === 'aim') {
        const d = Math.hypot(q.x - q.ax, q.y - q.ay);
        if (d > STICK_R * 1.25) { const k = STICK_R * 1.25 / d; q.ax = q.x - (q.x - q.ax) * k; q.ay = q.y - (q.y - q.ay) * k; }
        if (q.kind === 'stick') { // a light tick when the stick crosses into "thrust"
          const hot = Math.min(d, STICK_R) / STICK_R > 0.4;
          if (hot && !q.hot) api.buzz(5);
          q.hot = hot;
        }
      }
      refresh();
    }
    function onUp(e) { if (ptrs.delete(e.pointerId)) refresh(); }
    // keyboard / gamepad (declared in `controls`): movement / aim / fire are read in refresh() (also every frame, for sticks)
    const offIn = api.input ? api.input.on((type, id) => {
      if (id === 'special') { if (type === 'down' && W && pilots().length) { hintT = Math.min(hintT, 1); pressSpecial(pilots()[0]); } }
      else refresh();
    }) : null;
    const releaseAll = () => { ptrs.clear(); refresh(); };
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    window.addEventListener('blur', releaseAll);

    function setCfg(v) { cfg.ctl = v; try { localStorage.setItem('lounge.spaceshoot.cfg', JSON.stringify(cfg)); } catch (e) {} releaseAll(); syncChip(); }
    const chip = L.h('button', { class: 'ss-chip', type: 'button', 'aria-label': '조작 방식 바꾸기', onclick() { api.sfx('click'); setCfg(cfg.ctl === 'b' ? 't' : 'b'); hintT = 3; } });
    chip.addEventListener('pointerdown', (e) => e.stopPropagation());
    root.appendChild(chip);
    function syncChip() {
      chip.innerHTML = '';
      chip.append('조작 ', L.h('b', { text: cfg.ctl === 'b' ? '기본' : '트윈 스틱' }), ' ⇄');
      chip.hidden = !pilots().length || !st || st.ph === 'done';
    }

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 50)) return; lastSfx = t; api.sfx(n); }
    function burst(x, y, col, n, sp, life) { for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: (life || 0.5) * (0.6 + Math.random() * 0.6), c: col }); } if (parts.length > 400) parts.splice(0, parts.length - 400); }
    function onFx(code, x, y, a, b, c, d) {
      if (code === 'h') { burst(x, y, P(a).color, 14, 90); burst(x, y, '#fff3cf', 6, 60); if (isMine(a)) { api.buzz(60); sfx('thud', 30); shake = Math.min(1, shake + 0.6); } else sfx('hit', 40); if (b >= 0 && isMine(b)) { api.buzz(20); floats.push({ x, y, text: '명중!', col: '#fff3cf', t: 0.8 }); } }
      else if (code === 'o') { burst(x, y, P(a).color, 40, 140, 0.9); burst(x, y, '#ffcf6b', 24, 110, 0.7); shake = Math.min(1, shake + (isMine(a) ? 1 : 0.4)); if (isMine(a)) { api.sfx('lose'); api.buzz(120); } else if (b >= 0 && isMine(b)) { api.sfx('win'); api.buzz(40); } else sfx('thud', 30); floats.push({ x, y, text: name(a) + ' 격추!', col: P(a).color, t: 1.6 }); }
      else if (code === 's') { burst(x, y, '#7fe3ff', 16, 80); sfx('bounce', 40); floats.push({ x, y, text: '방패!', col: '#7fe3ff', t: 1 }); }
      else if (code === 'r') { burst(x, y, b ? '#ff9a5a' : '#a89b8c', Math.round(a) + 2, 70, 0.6); sfx('pop', 40); }
      else if (code === 'c') { burst(x, y, '#cbbfb0', 4, 50, 0.3); }
      else if (code === 'b') { burst(x, y, '#ffb35c', 22, a * 4, 0.5); burst(x, y, '#fff3cf', 8, a * 3, 0.3); sfx('thud', 40); shake = Math.min(1, shake + 0.25); }
      else if (code === 'p') { const k = PU_KINDS[b] || 'S'; floats.push({ x, y, text: PU_NAME[k] + '!', col: PU_COL[k], t: 1.3 }); sfx('chip', 40); if (isMine(a)) api.buzz(25); }
      else if (code === 'l') { beams.push({ x0: x, y0: y, x1: a, y1: b, c: P(c).color, t: 0.3 }); sfx('whoosh', 30); if (isMine(c)) api.buzz(15); }
      else if (code === 'k') { burst(x, y, '#b48cf0', 18, 60, 0.7); if (a >= 0) { floats.push({ x, y, text: name(a) + ' 블랙홀에 빠짐!', col: P(a).color, t: 1.6 }); if (isMine(a)) api.buzz(90); } }
      else if (code === 'w') { const col = PORTAL_COL[d] || '#5ee0d0'; burst(x, y, col, 12, 60, 0.5); burst(a, b, col, 16, 80, 0.6); if (isMine(c)) { api.buzz(15); sfx('whoosh', 30); } }
    }
    const hooks = {
      fx: onFx,
      fire(s) { if (isMine(s.seat)) sfx('tick', 70); },
      launch(s) { if (isMine(s.seat)) sfx('whoosh', 40); },
      mine(s) { if (isMine(s.seat)) sfx('click', 40); },
      spark(x, y) { burst(x, y, '#cfe8ff', 3, 40, 0.25); },
      bonk(s, v) { if (isMine(s.seat)) api.buzz(v > 120 ? 25 : 10); sfx('bounce', 80); },
    };

    /* ----- host flow ----- */
    function hostFlow(dt) {
      if (!host() || !st || !W) return;
      if (st.ph === 'count' && phase === 'play') { api.setState(Object.assign({}, st, { ph: 'play' })); return; }
      if (st.ph === 'play') { const w = roundWinner(W); if (w > -2) api.setState(roundOver(st, w)); }
      else if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextRound(st)); } }
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.ships.length) || simHere(s) || !o || o.k !== key) continue;
        remIn[s] = { x: clamp(+o.x || 0, -1, 1), y: clamp(+o.y || 0, -1, 1), ax: clamp(+o.ax || 0, -1, 1), ay: clamp(+o.ay || 0, -1, 1), f: o.f ? 1 : 0, s: o.s | 0, m: o.m === 't' ? 't' : 'b', aa: 1 };
        if (fin(o.q)) iqOf[s] = o.q;
      }
    }
    function encode() {
      const s = W.ships.map((q) => [Math.round(q.x), Math.round(q.y), Math.round(q.vx), Math.round(q.vy), Math.round(q.a * 100), Math.round(q.g * 100), q.lives,
        (q.alive ? 1 : 0) | (q.inv > 0 ? 2 : 0) | (q.sh > 0 ? 4 : 0) | (q.th > 0.05 ? 8 : 0) | (q.spr > 0 ? 16 : 0) | (q.fl > 0 ? 32 : 0), q.sk ? q.sk + q.sn : '']);
      const b = []; for (const q of W.bul.slice(-40)) b.push(Math.round(q.x), Math.round(q.y), Math.round(Math.atan2(q.vy, q.vx) * 100), q.o);
      const r = []; for (const q of W.rocks) r.push(q.id, Math.round(q.x), Math.round(q.y), q.m ? -q.r : q.r, q.hp);
      const m = []; for (const q of W.mis) m.push(Math.round(q.x), Math.round(q.y), Math.round(q.a * 100), q.o);
      const n = []; for (const q of W.mines) n.push(q.x, q.y, q.o, q.t >= MINE_ARM ? 1 : 0);
      const p = []; for (const q of W.pu) p.push(q.x, q.y, PU_KINDS.indexOf(q.k));
      return { k: key, q: hsQ, t: r2(W.t), s, b, r, m, n, p, fx: W.fx.slice(-6), iq: Object.assign({}, iqOf) };
    }
    function decodeRocks(rr) {
      const rk = [];
      for (let i = 0; i + 4 < rr.length; i += 5) { const r = rr[i + 3]; rk.push({ id: rr[i], x: rr[i + 1], y: rr[i + 2], vx: 0, vy: 0, r: Math.abs(r), hp: rr[i + 4], m: r < 0 ? 1 : 0 }); }
      return rk;
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.s)) return;
      lastQ = hs.q;
      hs.rk = decodeRocks(hs.r || []);
      snaps.push({ at: now, h: hs }); if (snaps.length > 4) snaps.shift();
      if (fin(hs.t)) W.t = hs.t;
      // events
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; onFx(e[1], e[2], e[3], e[4], e[5], e[6], e[7]); }
      // world objects (latest)
      W.mines = []; const nn = hs.n || []; for (let i = 0; i + 3 < nn.length; i += 4) W.mines.push({ x: nn[i], y: nn[i + 1], o: nn[i + 2], t: nn[i + 3] ? MINE_ARM + 1 : 0 });
      W.pu = []; const pp = hs.p || []; for (let i = 0; i + 2 < pp.length; i += 3) W.pu.push({ x: pp[i], y: pp[i + 1], k: PU_KINDS[pp[i + 2]] || 'S', t: 5 });
      hs.s.forEach((a, i) => {
        const c = W.ships[i];
        if (!c || !Array.isArray(a)) return;
        const fl = a[7] | 0;
        c.alive = !!(fl & 1); c.inv = fl & 2 ? 0.3 : 0; c.sh = fl & 4 ? 1 : 0; c.th = fl & 8 ? 1 : c.th; c.spr = fl & 16 ? 1 : 0; c.fl = fl & 32 ? 0.05 : 0;
        c.lives = a[6] | 0;
        const sk = String(a[8] || ''); c.sk = sk ? sk[0] : ''; c.sn = sk ? +sk.slice(1) || 0 : 0;
        if (!isMine(i)) { c.th = fl & 8 ? 1 : 0; return; }
        if (hs.iq && fin(hs.iq[i]) && sendT[hs.iq[i]]) { const sm = (now - sendT[hs.iq[i]]) / 1000; if (sm > 0 && sm < 2) rtt = rtt * 0.85 + sm * 0.15; }
        const lag = Math.min(0.25, rtt / 2);
        const tx = a[0] + a[2] * lag, ty = a[1] + a[3] * lag;
        if (!c.alive || Math.hypot(tx - c.x, ty - c.y) > 45) { c.x = c.px = tx; c.y = c.py = ty; c.vx = a[2]; c.vy = a[3]; c.a = a[4] / 100; }
        else { c.x += (tx - c.x) * 0.3; c.y += (ty - c.y) * 0.3; c.vx += (a[2] - c.vx) * 0.4; c.vy += (a[3] - c.vy) * 0.4; }
      });
    }
    function interpGuest(now) {
      if (host() || !snaps.length || !W) return;
      const rt = now - 100;
      let A = null, B = snaps[snaps.length - 1], k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.3);
      W.ships.forEach((c, s) => {
        if (isMine(s)) return;
        const b = B.h.s[s], a = A ? A.h.s[s] : null;
        if (!Array.isArray(b)) return;
        if (a && Math.hypot(b[0] - a[0], b[1] - a[1]) < 120) { c.x = a[0] + (b[0] - a[0]) * k; c.y = a[1] + (b[1] - a[1]) * k; c.a = a[4] / 100 + wrapA(b[4] / 100 - a[4] / 100) * k; c.g = a[5] / 100 + wrapA(b[5] / 100 - a[5] / 100) * k; }
        else { c.x = b[0]; c.y = b[1]; c.a = b[4] / 100; c.g = b[5] / 100; }
        c.vx = b[2]; c.vy = b[3];
      });
      // rocks / meteors: interpolate by id
      if (A) {
        const old = new Map(); for (const r of A.h.rk) old.set(r.id, r);
        W.rocks = B.h.rk.map((r) => { const o = old.get(r.id); if (!o || Math.hypot(r.x - o.x, r.y - o.y) > 80) return r; return { id: r.id, x: o.x + (r.x - o.x) * k, y: o.y + (r.y - o.y) * k, vx: (r.x - o.x) * 20, vy: (r.y - o.y) * 20, r: r.r, hp: r.hp, m: r.m }; });
      } else W.rocks = B.h.rk;
      // bullets & missiles: extrapolate from the newest snapshot at or before the render time
      const S0 = A || B, el = Math.max(0, (rt - S0.at) / 1000) * SPD();
      W.bul = []; const bb = S0.h.b || [];
      for (let i = 0; i + 3 < bb.length; i += 4) { const an = bb[i + 2] / 100; W.bul.push({ x: bb[i] + Math.cos(an) * BS * el, y: bb[i + 1] + Math.sin(an) * BS * el, vx: Math.cos(an) * BS, vy: Math.sin(an) * BS, o: bb[i + 3] }); }
      W.bul = W.bul.filter((q) => Math.abs(q.x) < W.hw && Math.abs(q.y) < W.hh);
      W.mis = []; const mm = S0.h.m || [];
      for (let i = 0; i + 3 < mm.length; i += 4) { const an = mm[i + 2] / 100; W.mis.push({ x: mm[i] + Math.cos(an) * MS * el, y: mm[i + 1] + Math.sin(an) * MS * el, a: an, o: mm[i + 3] }); }
    }
    function publish(rdt, now) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          let o = encode();
          if (JSON.stringify(o).length > 2300) { o.b = o.b.slice(-80); o.fx = o.fx.slice(-3); }
          api.net.hostSend(o);
        } else {
          const s = pilots()[0];
          if (s == null) return;
          const I = locIn[s]; if (!I) return;
          const sig = [I.x, I.y, I.ax, I.ay, I.f, I.s, I.m].join('|');
          if (sig === lastSig && inT > 0) return;
          lastSig = sig; inT = 0.15;
          inQ = (inQ + 1) % 100000; sendT[inQ] = now; delete sendT[(inQ + 99900) % 100000];
          api.net.publish({ k: key, q: inQ, x: I.x, y: I.y, ax: I.ax, ay: I.ay, f: I.f, s: I.s, m: I.m });
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      const dt = rdt * SPD();
      if (pilots().length) refresh(); // picks up gamepad stick changes every frame
      if (W && phase === 'count') {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0) api.sfx('tick');
        if (cd <= 0 && (host() || st.ph === 'play')) { phase = 'play'; api.sfx('pop'); api.buzz(20); syncChip(); }
      }
      if (hintT > 0 && phase === 'play') hintT -= rdt;
      if (host()) {
        pollHost();
        if (W && phase === 'play' && (st.ph === 'play' || st.ph === 'count' || st.ph === 'end')) {
          W.ships.forEach((c, i) => {
            const p = api.players[i]; if (!p) return;
            if (st.ph === 'end') { inputs[i] = {}; return; }
            if (simHere(i)) {
              if (autoSeat(i) || (L.debug && L.debug.autoplay)) inputs[i] = aiThink(W, c, aiMem[i], p.ai ? (p.lv || 2) : 2, dt, st.af);
              else inputs[i] = locIn[i];
            } else inputs[i] = remIn[i];
          });
          acc += Math.min(dt, 0.25);
          let n = 0;
          while (acc >= H && n < 120) { stepWorld(W, inputs, hooks, st.af, true); acc -= H; n++; }
          if (st.ph === 'play') maybePowerup(W, dt);
        }
        hostFlow(dt);
      } else if (W) {
        pollGuest(now);
        if (phase === 'play' && st.ph === 'play') {
          W.t += dt;
          updateBodies(W);
          for (const s of pilots()) { const c = W.ships[s]; if (c && c.alive) { let k = Math.min(dt, 0.1); while (k > 1e-6) { const hh = Math.min(H * 2, k); moveShip(W, c, locIn[s], hh, null); k -= hh; } } }
        } else updateBodies(W);
        interpGuest(now);
      }
      camUpdate(rdt, false);
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.94; p.vy *= 0.94; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = beams.length - 1; i >= 0; i--) { beams[i].t -= rdt; if (beams[i].t <= 0) beams.splice(i, 1); }
      // engine exhaust particles (only near the camera)
      if (W) for (const c of W.ships) if (c.alive && c.th > 0.05 && Math.random() < 0.7 && onScreen(c.x, c.y, 20)) parts.push({ x: c.x - Math.cos(c.a) * SR, y: c.y - Math.sin(c.a) * SR, vx: -Math.cos(c.a) * 60 + (Math.random() - 0.5) * 20, vy: -Math.sin(c.a) * 60 + (Math.random() - 0.5) * 20, t: 0.25, c: Math.random() < 0.5 ? '#ffcf6b' : '#ff7a3d' });
      if (W) for (const m of W.mis) if (Math.random() < 0.8 && onScreen(m.x, m.y, 10)) parts.push({ x: m.x - Math.cos(m.a) * 4, y: m.y - Math.sin(m.a) * 4, vx: (Math.random() - 0.5) * 10, vy: (Math.random() - 0.5) * 10, t: 0.4, c: 'rgba(200,200,210,.7)' });
      shake = Math.max(0, shake - rdt * 3);
      publish(rdt, now);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, rot) {
      ctx.save(); ctx.translate(x, y); if (rot) ctx.rotate(rot);
      ctx.font = font; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(5,6,16,.85)'; ctx.strokeText(t, 0, 0); ctx.fillStyle = col; ctx.fillText(t, 0, 0);
      ctx.restore();
    }
    let fogCv = null, starPat = null, mmCv = null, wallPat = null;
    function visibleTo(x, y, extra) {
      if (!W || !W.A.fog) return true;
      const me = pilots().map((s) => W.ships[s]).filter((c) => c && c.alive);
      if (!me.length) return true;
      return me.some((c) => Math.hypot(c.x - x, c.y - y) < VIS + (extra || 0));
    }
    const pingA = () => { if (!W || !W.A.fog || !pilots().length) return 0; const t = W.t % PING; return t < PING_ON ? 1 - t / PING_ON : 0; };
    /* parallax starfield: two repeating tiles drawn as patterns (2 fills per frame) */
    function makeStars() {
      const dpr = cv.dpr, T = 360, mk = (n, sd, big) => {
        const c = document.createElement('canvas'); c.width = c.height = Math.round(T * dpr);
        const g = c.getContext('2d'); g.scale(dpr, dpr);
        for (let i = 0; i < n; i++) { const a = hash(i, sd), b = hash(i, sd + 1), q = hash(i, sd + 2); g.globalAlpha = 0.25 + (q % 60) / 100; g.fillStyle = q % 7 === 0 ? '#ffd9a8' : q % 5 === 0 ? '#a8c8ff' : '#e8ecff'; const r = big ? 0.9 + (q % 10) / 8 : 0.5 + (q % 10) / 14; g.fillRect(a % T, b % T, r, r); }
        return ctx.createPattern(c, 'repeat');
      };
      starPat = { T, far: mk(70, 11, false), near: mk(26, 29, true) };
    }
    function drawStars() {
      if (!starPat) makeStars();
      const dpr = cv.dpr, Tp = starPat.T * dpr;
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
      for (const [pat, par] of [[starPat.far, 0.15], [starPat.near, 0.35]]) {
        let ox = (cam.x * par * cam.z * lay.f * dpr) % Tp, oy = (cam.y * par * cam.z * lay.f * dpr) % Tp;
        if (ox < 0) ox += Tp; if (oy < 0) oy += Tp;
        ctx.translate(-ox, -oy); ctx.fillStyle = pat; ctx.fillRect(ox, oy, cv.cv.width, cv.cv.height); ctx.translate(ox, oy);
      }
      ctx.restore();
    }
    function draw(now) {
      cv.clear();
      const w = cv.w, h = cv.h;
      if (!lay) layout();
      const bg = ctx.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, '#060818'); bg.addColorStop(1, '#100820');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
      if (!W || !st) return;
      drawStars();
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 8 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 8 : 0;
      ctx.save(); ctx.translate(lay.ax + sx, lay.ay + sy); ctx.scale(cam.z, cam.z); if (lay.f < 0) ctx.rotate(Math.PI); ctx.translate(-cam.x, -cam.y);
      drawArena(now);
      // power-ups
      for (const p of W.pu) {
        if (!onScreen(p.x, p.y, 12)) continue;
        const bob = Math.sin(now / 220 + p.x) * 1.5, col = PU_COL[p.k];
        ctx.save(); ctx.translate(p.x, p.y + bob); ctx.rotate(now / 900);
        ctx.beginPath(); ctx.arc(0, 0, 15, 0, 7); ctx.fillStyle = hexA(col, 0.12 + 0.06 * Math.sin(now / 200)); ctx.fill();
        ctx.beginPath(); for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; ctx.lineTo(Math.cos(a) * 10, Math.sin(a) * 10); } ctx.closePath();
        ctx.fillStyle = 'rgba(10,12,28,.88)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = col; ctx.stroke();
        ctx.rotate(-now / 900); if (lay.f < 0) ctx.rotate(Math.PI);
        ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = col; ctx.fillText(PU_CH[p.k], 0, 0.5);
        ctx.restore();
      }
      // mines
      for (const m of W.mines) {
        if (!onScreen(m.x, m.y, 10) || (!visibleTo(m.x, m.y, 20) && !isMine(m.o))) continue;
        const armed = m.t >= MINE_ARM, blink = armed && Math.sin(now / 120) > 0;
        ctx.save(); ctx.translate(m.x, m.y);
        ctx.strokeStyle = P(m.o).color; ctx.lineWidth = 1.5;
        ctx.beginPath(); for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; ctx.moveTo(Math.cos(a) * 4, Math.sin(a) * 4); ctx.lineTo(Math.cos(a) * 7.5, Math.sin(a) * 7.5); } ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 0, 4.5, 0, 7); ctx.fillStyle = '#2a2235'; ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 0, 1.8, 0, 7); ctx.fillStyle = blink ? '#ff4d4d' : armed ? '#7a2020' : '#555'; ctx.fill();
        if (armed && isMine(m.o)) { ctx.beginPath(); ctx.arc(0, 0, MINE_TRIG + SR, 0, 7); ctx.strokeStyle = hexA(P(m.o).color, 0.15); ctx.setLineDash([2, 3]); ctx.stroke(); ctx.setLineDash([]); }
        ctx.restore();
      }
      // rocks & meteors
      for (const r of W.rocks) if (onScreen(r.x, r.y, r.r * 4)) { if (r.m) drawMeteor(r); else drawRock(r); }
      // bullets
      ctx.lineCap = 'round';
      for (const b of W.bul) {
        if (!onScreen(b.x, b.y, 10) || !visibleTo(b.x, b.y, 40)) continue;
        const col = P(b.o).color, sp = Math.hypot(b.vx, b.vy) || 1, ux = b.vx / sp, uy = b.vy / sp;
        ctx.strokeStyle = hexA(col, 0.5); ctx.lineWidth = 2.4;
        ctx.beginPath(); ctx.moveTo(b.x - ux * 10, b.y - uy * 10); ctx.lineTo(b.x, b.y); ctx.stroke();
        ctx.beginPath(); ctx.arc(b.x, b.y, BR, 0, 7); ctx.fillStyle = '#fffbe8'; ctx.fill();
        ctx.beginPath(); ctx.arc(b.x, b.y, BR + 1.2, 0, 7); ctx.strokeStyle = col; ctx.lineWidth = 1.2; ctx.stroke();
      }
      // missiles
      for (const m of W.mis) {
        if (!onScreen(m.x, m.y, 10) || !visibleTo(m.x, m.y, 40)) continue;
        ctx.save(); ctx.translate(m.x, m.y); ctx.rotate(m.a);
        ctx.fillStyle = '#e8e2d6'; ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -2.4); ctx.lineTo(-4, 2.4); ctx.closePath(); ctx.fill();
        ctx.fillStyle = P(m.o).color; ctx.fillRect(-5, -3, 2.5, 6);
        ctx.restore();
      }
      // particles
      for (const p of parts) { ctx.globalAlpha = Math.min(1, p.t * 3); ctx.fillStyle = p.c; ctx.fillRect(p.x - 1, p.y - 1, 2, 2); }
      ctx.globalAlpha = 1;
      // aim-assist lock (mine)
      const me = myShip();
      if (me && me.alive && st.ph === 'play' && phase === 'play') {
        const q = assistAim(W, me, me.g, cfg.ctl === 't' ? AA_T : AA_B, AA_RANGE), o = q != null ? AST.o : null;
        if (o) drawLock(o, now, P(me.seat).color);
      }
      // ships
      for (const c of W.ships) if (c.alive && onScreen(c.x, c.y, 20) && (isMine(c.seat) || visibleTo(c.x, c.y, 0))) drawShip(c, now);
      // laser beams
      for (const b of beams) {
        ctx.globalAlpha = Math.min(1, b.t * 5);
        ctx.strokeStyle = b.c; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(b.x0, b.y0); ctx.lineTo(b.x1, b.y1); ctx.stroke();
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.8; ctx.stroke();
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      if (W.A.fog) drawFog(now);
      // floating texts
      for (const f of floats) {
        if (!onScreen(f.x, f.y, 0)) continue;
        ctx.globalAlpha = Math.min(1, f.t * 2);
        txt(f.text, clamp(X(f.x), 80, w - 80), clamp(Y(f.y) - 22 - (1.6 - f.t) * 16, 110, h - 60), f.col, '700 13px ' + FONT, 0);
      }
      ctx.globalAlpha = 1;
      drawHud(now);
    }
    function drawLock(o, now, col) {
      const r = SR + 8 + Math.sin(now / 120) * 1.2;
      ctx.save(); ctx.translate(o.x, o.y); ctx.rotate(now / 600);
      ctx.strokeStyle = hexA(col, 0.9); ctx.lineWidth = 1.6;
      for (let k = 0; k < 4; k++) { ctx.rotate(Math.PI / 2); ctx.beginPath(); ctx.arc(0, 0, r, -0.32, 0.32); ctx.stroke(); ctx.beginPath(); ctx.moveTo(r + 3, 0); ctx.lineTo(r - 3, 0); ctx.stroke(); }
      ctx.restore();
    }
    function drawFog(now) {
      const w = cv.w, h = cv.h, dpr = cv.dpr;
      if (!fogCv) fogCv = document.createElement('canvas');
      if (fogCv.width !== cv.cv.width || fogCv.height !== cv.cv.height) { fogCv.width = cv.cv.width; fogCv.height = cv.cv.height; }
      const g = fogCv.getContext('2d');
      g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, fogCv.width, fogCv.height); g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const me = pilots().map((s) => W.ships[s]).filter((c) => c && c.alive);
      g.globalCompositeOperation = 'source-over';
      g.fillStyle = me.length ? 'rgba(46,22,70,.93)' : 'rgba(46,22,70,.35)';
      g.fillRect(0, 0, w, h);
      // drifting nebula wisps (world-anchored)
      for (let i = 0; i < 6; i++) { const x = X(Math.sin(now / 5000 + i * 1.7) * W.hw * 0.7), y = Y(Math.cos(now / 6000 + i * 2.3) * W.hh * 0.7), r = (90 + i * 12) * cam.z; if (x < -r || x > w + r || y < -r || y > h + r) continue; const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(180,80,200,.18)'); gr.addColorStop(1, 'rgba(180,80,200,0)'); g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); }
      g.globalCompositeOperation = 'destination-out';
      for (const c of me) {
        const x = X(c.x), y = Y(c.y), r = VIS * cam.z;
        const gr = g.createRadialGradient(x, y, r * 0.55, x, y, r); gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
      }
      g.globalCompositeOperation = 'source-over';
      ctx.drawImage(fogCv, 0, 0, w, h);
      // radar ping ring around me
      const pa = pingA();
      if (pa > 0 && me.length) {
        const c = me[0], t = 1 - pa;
        ctx.beginPath(); ctx.arc(X(c.x), Y(c.y), (30 + t * 260) * cam.z, 0, 7); ctx.strokeStyle = 'rgba(160,230,255,' + (0.5 * pa) + ')'; ctx.lineWidth = 2; ctx.stroke();
      }
    }
    function getWallPat(kind) {
      if (wallPat && wallPat.k === kind) return wallPat.p;
      const c = document.createElement('canvas'); c.width = c.height = 32;
      const g = c.getContext('2d');
      if (kind === 'maze') {
        g.fillStyle = '#0d2a22'; g.fillRect(0, 0, 32, 32); g.strokeStyle = 'rgba(80,240,170,.18)'; g.lineWidth = 2; g.strokeRect(1, 1, 30, 30);
        g.fillStyle = 'rgba(80,240,170,.35)'; g.fillRect(14, 14, 4, 4);
      } else {
        g.fillStyle = '#3a4258'; g.fillRect(0, 0, 32, 32); g.strokeStyle = 'rgba(227,174,69,.6)'; g.lineWidth = 5;
        for (let k = -32; k < 64; k += 16) { g.beginPath(); g.moveTo(k, 0); g.lineTo(k - 32, 32); g.stroke(); }
      }
      wallPat = { k: kind, p: ctx.createPattern(c, 'repeat') };
      return wallPat.p;
    }
    function drawArena(now) {
      const A = W.A, hw = W.hw, hh = W.hh;
      ctx.fillStyle = A.bg; ctx.globalAlpha = 0.72; ctx.fillRect(-hw, -hh, hw * 2, hh * 2); ctx.globalAlpha = 1;
      // grid (only the visible part)
      const vx = (cv.w * 0.75) / cam.z, vy = (cv.h * 0.75) / cam.z;
      const gx0 = Math.max(-hw, cam.x - vx), gx1 = Math.min(hw, cam.x + vx), gy0 = Math.max(-hh, cam.y - vy), gy1 = Math.min(hh, cam.y + vy);
      ctx.strokeStyle = A.grid; ctx.lineWidth = 1; ctx.beginPath();
      for (let x = Math.ceil(gx0 / 60) * 60; x <= gx1; x += 60) { ctx.moveTo(x, gy0); ctx.lineTo(x, gy1); }
      for (let y = Math.ceil(gy0 / 60) * 60; y <= gy1; y += 60) { ctx.moveTo(gx0, y); ctx.lineTo(gx1, y); }
      ctx.stroke();
      // force-field border
      ctx.strokeStyle = 'rgba(' + A.edge + ',' + (0.45 + 0.2 * Math.sin(now / 400)) + ')'; ctx.lineWidth = 2.5; ctx.strokeRect(-hw, -hh, hw * 2, hh * 2);
      ctx.strokeStyle = 'rgba(' + A.edge + ',.12)'; ctx.lineWidth = 10; ctx.strokeRect(-hw - 5, -hh - 5, hw * 2 + 10, hh * 2 + 10);
      if (A.fog) { // purple nebula clouds under the fog
        for (let i = 0; i < 7; i++) { const x = Math.sin(i * 2.1) * hw * 0.7, y = Math.cos(i * 1.3) * hh * 0.7, r = 120; if (!onScreen(x, y, r)) continue; const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(200,90,220,.16)'); g.addColorStop(1, 'rgba(200,90,220,0)'); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); }
      }
      if (A.meteor) { // faint streaks showing which way the shower falls
        ctx.strokeStyle = 'rgba(255,150,100,.05)'; ctx.lineWidth = 2; const ux = Math.cos(W.md), uy = Math.sin(W.md);
        ctx.beginPath(); for (let i = -6; i <= 6; i++) { const x = i * 70 - ux * 600, y = -uy * 600; ctx.moveTo(x, y); ctx.lineTo(x + ux * 1300, y + uy * 1300); } ctx.stroke();
      }
      if (A.stars) { ctx.beginPath(); ctx.arc(0, 0, STAR_D, 0, 7); ctx.setLineDash([4, 10]); ctx.strokeStyle = 'rgba(255,190,120,.16)'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]); }
      for (const b of W.bodies) {
        if (!onScreen(b.x, b.y, 120)) continue;
        if (b.k === 'hole') {
          const pul = 1 + 0.04 * Math.sin(now / 300);
          for (let k = 5; k >= 1; k--) { ctx.beginPath(); ctx.arc(0, 0, (HOLE_R + k * 22) * pul, 0, 7); ctx.strokeStyle = 'rgba(180,140,240,' + (0.05 + (5 - k) * 0.03) + ')'; ctx.lineWidth = 2; ctx.stroke(); }
          ctx.save(); ctx.rotate(now / 700);
          ctx.beginPath(); ctx.ellipse(0, 0, HOLE_R * 2.3, HOLE_R * 0.9, 0, 0, 7); ctx.strokeStyle = 'rgba(255,170,90,.75)'; ctx.lineWidth = 3; ctx.stroke();
          ctx.beginPath(); ctx.ellipse(0, 0, HOLE_R * 1.8, HOLE_R * 0.6, 0.4, 0, 7); ctx.strokeStyle = 'rgba(255,220,160,.45)'; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.restore();
          const g = ctx.createRadialGradient(0, 0, 0, 0, 0, HOLE_R + 6); g.addColorStop(0, '#000'); g.addColorStop(0.75, '#000'); g.addColorStop(1, 'rgba(120,80,200,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, HOLE_R + 6, 0, 7); ctx.fill();
        } else {
          const star = b.k === 'star', R = b.r, hot = star && W.bodies.indexOf(b) === 1;
          for (let k = 3; k >= 1; k--) { const ph = ((now / 1400 + k / 3) % 1); ctx.beginPath(); ctx.arc(b.x, b.y, R + ph * (star ? 70 : 60), 0, 7); ctx.strokeStyle = 'rgba(255,190,110,' + (0.25 * (1 - ph)) + ')'; ctx.lineWidth = 1.5; ctx.stroke(); }
          const halo = ctx.createRadialGradient(b.x, b.y, R * 0.6, b.x, b.y, R * 2.4); halo.addColorStop(0, hot ? 'rgba(255,110,70,.45)' : 'rgba(255,200,110,.45)'); halo.addColorStop(1, 'rgba(255,160,90,0)');
          ctx.fillStyle = halo; ctx.fillRect(b.x - R * 2.4, b.y - R * 2.4, R * 4.8, R * 4.8);
          const g = ctx.createRadialGradient(b.x - 3, b.y - 3, 1, b.x, b.y, R);
          g.addColorStop(0, '#fff2c8'); g.addColorStop(0.5, hot ? '#ff8a4a' : '#ffb24a'); g.addColorStop(1, hot ? '#b2301c' : '#c2541c');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(b.x, b.y, R, 0, 7); ctx.fill();
        }
      }
      W.portals.forEach((p, pi) => {
        const col = PORTAL_COL[pi % 2];
        for (let e = 0; e < 2; e++) {
          const x = p[e * 2], y = p[e * 2 + 1];
          if (!onScreen(x, y, PR * 2)) continue;
          const g = ctx.createRadialGradient(x, y, 2, x, y, PR + 8); g.addColorStop(0, '#02060a'); g.addColorStop(0.6, hexA(col, 0.35)); g.addColorStop(1, hexA(col, 0));
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, PR + 8, 0, 7); ctx.fill();
          ctx.save(); ctx.translate(x, y); ctx.rotate((e ? -1 : 1) * now / 500);
          ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.setLineDash([9, 6]); ctx.beginPath(); ctx.arc(0, 0, PR, 0, 7); ctx.stroke();
          ctx.rotate((e ? 1 : -1) * now / 260); ctx.lineWidth = 1.5; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.arc(0, 0, PR * 0.6, 0, 7); ctx.stroke(); ctx.setLineDash([]);
          ctx.restore();
        }
      });
      if (W.walls.length) {
        const maze = A.id === 'maze', pat = getWallPat(maze ? 'maze' : 'st');
        for (const w of W.walls) {
          if (!onScreen(w[0], w[1], Math.max(w[2], w[3]) + 10)) continue;
          const x = w[0] - w[2], y = w[1] - w[3], ww = w[2] * 2, hh2 = w[3] * 2;
          ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(x + 3, y + 4, ww, hh2);
          ctx.fillStyle = pat; ctx.fillRect(x, y, ww, hh2);
          if (maze) { ctx.strokeStyle = 'rgba(80,240,170,' + (0.55 + 0.25 * Math.sin(now / 500 + w[0] * 0.01)) + ')'; ctx.lineWidth = 1.6; ctx.strokeRect(x, y, ww, hh2); }
          else { ctx.strokeStyle = '#8b96b4'; ctx.lineWidth = 1.2; ctx.strokeRect(x, y, ww, hh2); ctx.fillStyle = 'rgba(120,200,255,' + (0.5 + 0.5 * Math.sin(now / 300 + w[0])) + ')'; ctx.fillRect(w[0] - 1.5, w[1] - 1.5, 3, 3); }
        }
      }
    }
    function drawRock(r) {
      ctx.save(); ctx.translate(r.x, r.y);
      const n = 9, seed = r.id * 7919;
      ctx.beginPath();
      for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2, rr = r.r * (0.82 + (hash(seed, k) % 100) / 500); ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
      ctx.closePath();
      ctx.fillStyle = '#6a5e53'; ctx.fill(); ctx.strokeStyle = 'rgba(20,16,14,.75)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.beginPath(); ctx.arc(-r.r * 0.22, -r.r * 0.25, r.r * 0.55, 0, 7); ctx.fillStyle = 'rgba(255,236,210,.12)'; ctx.fill();
      ctx.fillStyle = 'rgba(40,32,28,.45)';
      for (let k = 0; k < 3; k++) { const a = (hash(seed, k + 20) % 628) / 100, d = r.r * 0.45; ctx.beginPath(); ctx.arc(Math.cos(a) * d, Math.sin(a) * d, r.r * 0.16, 0, 7); ctx.fill(); }
      const maxHp = r.r >= 16 ? 4 : r.r >= 10 ? 2 : 1;
      if (r.hp < maxHp) { ctx.strokeStyle = 'rgba(255,220,180,.55)'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(-r.r * 0.5, -r.r * 0.2); ctx.lineTo(0, 0); ctx.lineTo(r.r * 0.3, r.r * 0.5); if (r.hp < maxHp - 1) { ctx.moveTo(0, 0); ctx.lineTo(r.r * 0.5, -r.r * 0.4); } ctx.stroke(); }
      ctx.restore();
    }
    function drawMeteor(r) {
      const ux = Math.cos(W.md), uy = Math.sin(W.md), L2 = r.r * 4.5;
      const g = ctx.createLinearGradient(r.x, r.y, r.x - ux * L2, r.y - uy * L2);
      g.addColorStop(0, 'rgba(255,190,110,.75)'); g.addColorStop(1, 'rgba(255,90,40,0)');
      ctx.strokeStyle = g; ctx.lineWidth = r.r * 1.3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(r.x, r.y); ctx.lineTo(r.x - ux * L2, r.y - uy * L2); ctx.stroke();
      ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, 7); ctx.fillStyle = '#5a3a2c'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#ff9a4d'; ctx.stroke();
      ctx.beginPath(); ctx.arc(r.x + ux * r.r * 0.3, r.y + uy * r.r * 0.3, r.r * 0.45, 0, 7); ctx.fillStyle = 'rgba(255,220,150,.55)'; ctx.fill();
    }
    function drawShip(c, now) {
      const col = P(c.seat).color;
      if (c.inv > 0 && Math.sin(now / 50) > 0.2 && c.inv < INV) ctx.globalAlpha = 0.45;
      ctx.save(); ctx.translate(c.x, c.y);
      // aim line (mine): where the gun points
      if (isMine(c.seat)) { ctx.save(); ctx.rotate(c.g); ctx.setLineDash([3, 6]); ctx.strokeStyle = hexA(c.sk === 'L' ? PU_COL.L : col, c.sk === 'L' || cfg.ctl === 't' ? 0.55 : 0.3); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(SR + 5, 0); ctx.lineTo(SR + (c.sk === 'L' ? 120 : 64), 0); ctx.stroke(); ctx.setLineDash([]); ctx.restore(); }
      ctx.rotate(c.a);
      if (c.th > 0.05) { const fl = 6 + Math.random() * 5 * c.th; ctx.beginPath(); ctx.moveTo(-SR * 0.7, -3); ctx.lineTo(-SR * 0.7 - fl, 0); ctx.lineTo(-SR * 0.7, 3); ctx.fillStyle = '#ffcf6b'; ctx.fill(); }
      // hull
      ctx.beginPath(); ctx.moveTo(SR * 1.25, 0); ctx.lineTo(-SR * 0.8, -SR * 0.9); ctx.lineTo(-SR * 0.45, 0); ctx.lineTo(-SR * 0.8, SR * 0.9); ctx.closePath();
      const g = ctx.createLinearGradient(-SR, -SR, SR, SR); g.addColorStop(0, shade(col, 0.35)); g.addColorStop(1, shade(col, -0.3));
      ctx.fillStyle = g; ctx.fill(); ctx.lineWidth = 1.1; ctx.strokeStyle = 'rgba(255,255,255,.65)'; ctx.stroke();
      ctx.beginPath(); ctx.ellipse(SR * 0.25, 0, SR * 0.38, SR * 0.24, 0, 0, 7); ctx.fillStyle = '#cfe8ff'; ctx.fill();
      if (c.spr > 0) { ctx.fillStyle = PU_COL.S; ctx.fillRect(-SR * 0.3, -SR * 0.95, 4, 2); ctx.fillRect(-SR * 0.3, SR * 0.95 - 2, 4, 2); }
      ctx.rotate(c.g - c.a);
      if (c.fl > 0) { ctx.beginPath(); ctx.arc(SR * 1.35, 0, 3, 0, 7); ctx.fillStyle = '#fffbe8'; ctx.fill(); }
      ctx.restore();
      ctx.globalAlpha = 1;
      if (c.sh > 0) { ctx.beginPath(); ctx.arc(c.x, c.y, SR + 5, 0, 7); ctx.strokeStyle = 'rgba(127,227,255,' + (0.55 + 0.3 * Math.sin(now / 90)) + ')'; ctx.lineWidth = 1.6; ctx.stroke(); ctx.fillStyle = 'rgba(127,227,255,.1)'; ctx.fill(); }
      // lives pips under the ship (screen-down even when the view is turned)
      const pd = (SR + 6) * lay.f;
      for (let k = 0; k < LIVES; k++) { ctx.beginPath(); ctx.arc(c.x + (-6 + k * 6) * lay.f, c.y + pd, 1.8, 0, 7); ctx.fillStyle = k < c.lives ? col : 'rgba(255,255,255,.15)'; ctx.fill(); }
      if (isMine(c.seat)) { ctx.beginPath(); ctx.arc(c.x, c.y, SR + 9, 0, 7); ctx.strokeStyle = 'rgba(242,233,216,.4)'; ctx.setLineDash([2, 4]); ctx.lineWidth = 0.9; ctx.stroke(); ctx.setLineDash([]); }
    }
    function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
    function scoreRow(x, y, size) { // dots + wins + lives for every player, left to right
      ctx.font = '700 ' + size + 'px ' + MONO; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      for (let s = 0; s < st.n; s++) {
        const c = W && W.ships[s], alive = !c || c.alive;
        ctx.globalAlpha = alive ? 1 : 0.35;
        ctx.beginPath(); ctx.arc(x + 5, y, 5, 0, 7); ctx.fillStyle = P(s).color; ctx.fill();
        if (isMine(s)) { ctx.lineWidth = 2; ctx.strokeStyle = '#f2e9d8'; ctx.stroke(); }
        ctx.fillStyle = '#f2e9d8'; ctx.fillText(String(st.wins[s] | 0) + '승', x + 13, y + 0.5);
        for (let k = 0; k < LIVES; k++) { ctx.beginPath(); ctx.arc(x + 38 + k * 6, y, 2.2, 0, 7); ctx.fillStyle = c && k < c.lives ? P(s).color : 'rgba(255,255,255,.18)'; ctx.fill(); }
        x += 58;
      }
      ctx.globalAlpha = 1;
    }
    /* minimap: static layer cached, ships/items on top */
    function drawMinimap() {
      const mm = lay.mm; if (!mm) return;
      const MX = (x) => mm.x + mm.w / 2 + x * mm.s * lay.f, MY = (y) => mm.y + mm.h / 2 + y * mm.s * lay.f;
      if (!mmCv || mmCv.key !== mm.w + 'x' + mm.h + lay.f + cv.dpr) {
        const dpr = cv.dpr, c = document.createElement('canvas'); c.width = Math.round((mm.w + 4) * dpr); c.height = Math.round((mm.h + 4) * dpr);
        const g = c.getContext('2d'); g.scale(dpr, dpr); g.translate(2 - mm.x, 2 - mm.y);
        rrect(g, mm.x, mm.y, mm.w, mm.h, 6); g.fillStyle = 'rgba(6,8,20,.82)'; g.fill(); g.strokeStyle = 'rgba(' + W.A.edge + ',.55)'; g.lineWidth = 1.2; g.stroke();
        g.fillStyle = W.A.id === 'maze' ? 'rgba(80,240,170,.7)' : 'rgba(170,180,210,.7)';
        for (const w of W.walls) g.fillRect(MX(w[0]) - w[2] * mm.s, MY(w[1]) - w[3] * mm.s, Math.max(1.2, w[2] * 2 * mm.s), Math.max(1.2, w[3] * 2 * mm.s));
        W.portals.forEach((p, pi) => { g.strokeStyle = PORTAL_COL[pi % 2]; g.lineWidth = 1.3; for (let e = 0; e < 2; e++) { g.beginPath(); g.arc(MX(p[e * 2]), MY(p[e * 2 + 1]), 2.6, 0, 7); g.stroke(); } });
        if (W.A.stars) { g.beginPath(); g.arc(MX(0), MY(0), STAR_D * mm.s, 0, 7); g.strokeStyle = 'rgba(255,190,120,.25)'; g.lineWidth = 1; g.stroke(); }
        mmCv = c; mmCv.key = mm.w + 'x' + mm.h + lay.f + cv.dpr;
      }
      ctx.drawImage(mmCv, mm.x - 2, mm.y - 2, mm.w + 4, mm.h + 4);
      for (const b of W.bodies) { ctx.beginPath(); ctx.arc(MX(b.x), MY(b.y), b.k === 'hole' ? 3 : 2.4, 0, 7); ctx.fillStyle = b.k === 'hole' ? '#b48cf0' : '#ffb24a'; ctx.fill(); }
      for (const p of W.pu) { ctx.fillStyle = PU_COL[p.k]; ctx.fillRect(MX(p.x) - 1.5, MY(p.y) - 1.5, 3, 3); }
      // camera view box
      const w = cv.w, h = cv.h, wx = (sx) => cam.x + (sx - lay.ax) / (cam.z * lay.f), wy = (sy) => cam.y + (sy - lay.ay) / (cam.z * lay.f);
      const ax0 = MX(wx(0)), ax1 = MX(wx(w)), ay0 = MY(wy(TOP)), ay1 = MY(wy(h - lay.bot * 0.5));
      ctx.save(); ctx.beginPath(); ctx.rect(mm.x, mm.y, mm.w, mm.h); ctx.clip();
      ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1; ctx.strokeRect(Math.min(ax0, ax1), Math.min(ay0, ay1), Math.abs(ax1 - ax0), Math.abs(ay1 - ay0));
      ctx.restore();
      const pa = pingA();
      for (const c of W.ships) {
        if (!c.alive) continue;
        const mine = isMine(c.seat);
        let al = 1;
        if (!mine && W.A.fog && pilots().length && !visibleTo(c.x, c.y, 0)) { al = pa; if (al <= 0) continue; }
        ctx.globalAlpha = al;
        ctx.beginPath(); ctx.arc(MX(c.x), MY(c.y), mine ? 3.4 : 2.8, 0, 7); ctx.fillStyle = P(c.seat).color; ctx.fill();
        if (mine) { ctx.lineWidth = 1.4; ctx.strokeStyle = '#fff3cf'; ctx.stroke(); }
      }
      ctx.globalAlpha = 1;
    }
    /* arrows at the screen edge pointing at enemies you can't see on screen */
    function drawArrows() {
      const me = myShip(); if (!me || !me.alive) return;
      const w = cv.w, h = cv.h, L0 = 12, R0 = w - 12, T0 = (lay.mm ? lay.mm.y + lay.mm.h : TOP) + 14, B0 = h - lay.bot - 6, pa = pingA(), placed = [];
      for (const c of W.ships) {
        if (!c.alive || c.seat === me.seat) continue;
        let al = 1;
        if (W.A.fog && !visibleTo(c.x, c.y, 0)) { al = pa; if (al <= 0) continue; }
        const sx = X(c.x), sy = Y(c.y);
        if (sx > L0 && sx < R0 && sy > T0 && sy < B0) continue;
        const dx = sx - lay.ax, dy = sy - lay.ay;
        let k = 1e9;
        if (dx > 0) k = Math.min(k, (R0 - lay.ax) / dx); if (dx < 0) k = Math.min(k, (L0 - lay.ax) / dx);
        if (dy > 0) k = Math.min(k, (B0 - lay.ay) / dy); if (dy < 0) k = Math.min(k, (T0 - lay.ay) / dy);
        let px = lay.ax + dx * k, py = lay.ay + dy * k;
        const an = Math.atan2(dy, dx), dist = Math.hypot(c.x - me.x, c.y - me.y), horiz = Math.abs(py - T0) < 1 || Math.abs(py - B0) < 1;
        for (let t = 0; t < 4 && placed.some((q) => Math.abs(q[0] - px) < 44 && Math.abs(q[1] - py) < 30); t++) { if (horiz) px = clamp(px + (px > w / 2 ? -46 : 46), L0, R0); else py = clamp(py + (py > h / 2 ? -32 : 32), T0, B0); }
        placed.push([px, py]);
        ctx.globalAlpha = al * clamp(1.2 - dist / 1400, 0.55, 1);
        ctx.save(); ctx.translate(px, py); ctx.rotate(an);
        ctx.beginPath(); ctx.moveTo(2, 0); ctx.lineTo(-12, -8); ctx.lineTo(-8, 0); ctx.lineTo(-12, 8); ctx.closePath();
        ctx.fillStyle = P(c.seat).color; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(5,6,16,.85)'; ctx.stroke();
        ctx.restore();
        txt(Math.round(dist / 10) + 'm', px - Math.cos(an) * 24, py - Math.sin(an) * 18, P(c.seat).color, '700 10px ' + MONO, 0);
      }
      ctx.globalAlpha = 1;
    }
    function drawHud(now) {
      const w = cv.w, h = cv.h, m = pilots();
      // name tags
      for (const c of W.ships) {
        if (!c.alive || !onScreen(c.x, c.y, 10) || !(isMine(c.seat) || visibleTo(c.x, c.y, 0))) continue;
        txt(name(c.seat), X(c.x), Y(c.y) - (SR * cam.z + 12), P(c.seat).color, '700 10.5px ' + FONT, 0);
      }
      drawArrows();
      // score panel (top-left) + minimap (top-right)
      const mmw = lay.mm ? lay.mm.w + 16 : 0;
      const title = '라운드 ' + st.rd + ' · ' + ARENAS[st.ar].name;
      ctx.font = '700 12.5px ' + FONT;
      const bw = Math.min(w - 16 - mmw, Math.max(st.n * 58 + 18, ctx.measureText(title).width + 22));
      rrect(ctx, 8, 6, bw, 46, 12); ctx.fillStyle = 'rgba(8,10,24,.8)'; ctx.fill();
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(title, 18, 19);
      scoreRow(18, 38, 11);
      drawMinimap();
      if (st.ph !== 'done') for (const s of m) drawControls(s, now);
      const bigs = (t, col, size, yk) => txt(t, w / 2, h * yk, col, size + 'px ' + DISP, 0);
      if (phase === 'count' && st.ph === 'count') {
        bigs(String(Math.max(1, Math.ceil(cd))), '#f2e9d8', 60, 0.44);
        bigs(ARENAS[st.ar].name, '#7fc8ff', 22, 0.3);
        txt(ARENAS[st.ar].sub + (W.grav ? ' · 중력 우물' : ''), w / 2, h * 0.3 + 26, '#cfc3dc', '600 12px ' + FONT, 0);
      }
      if (st.ph === 'end') bigs(st.rw >= 0 ? name(st.rw) + ' 라운드 승리!' : '무승부 라운드', st.rw >= 0 ? P(st.rw).color : '#f2e9d8', 24, 0.42);
      if (W && st.ph === 'play' && W.t > CAP_T - 10 && W.t < CAP_T) bigs('시간 종료 ' + Math.ceil(CAP_T - W.t) + '초 전', '#ee6a55', 18, 0.3);
      if (hintT > 0 && m.length) {
        ctx.globalAlpha = Math.min(1, hintT);
        const t1 = '왼쪽: 미는 쪽으로 돌고, 끝까지 밀면 전진';
        const t2 = cfg.ctl === 't' ? '오른쪽 스틱: 조준하며 연사' : st.af ? '자동 연사 · 동그란 버튼: 특수무기' : '오른쪽 아무 데나 누르면 발사 (조준 보정)';
        ctx.save();
        ctx.font = '600 12.5px ' + FONT;
        const bw2 = Math.min(w - 16, Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width) + 24), y0 = Math.round(h * 0.52);
        rrect(ctx, (w - bw2) / 2, y0, bw2, 46, 13); ctx.fillStyle = 'rgba(8,10,24,.86)'; ctx.fill();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t1, w / 2, y0 + 14); ctx.fillStyle = '#7fc8ff'; ctx.fillText(t2, w / 2, y0 + 32);
        ctx.restore();
        ctx.globalAlpha = 1;
      }
    }
    function drawControls(s, now) {
      const w = cv.w, h = cv.h, c = W.ships[s], col = P(s).color;
      ctx.save();
      const dead = !c || !c.alive;
      ctx.globalAlpha = dead ? 0.3 : 1;
      // special button
      const sb = specBtn(), has = c && c.sk && c.sn > 0;
      let sPress = false, fPress = false; for (const p of ptrs.values()) if (p.seat === s) { if (p.kind === 'spec') sPress = true; if (p.kind === 'fire') fPress = true; }
      ctx.beginPath(); ctx.arc(sb.x, sb.y, sb.r * (sPress ? 0.92 : 1), 0, 7); ctx.fillStyle = has ? hexA(PU_COL[c.sk], 0.85) : 'rgba(30,32,54,.8)'; ctx.fill();
      ctx.lineWidth = 2.5; ctx.strokeStyle = has ? '#fff3cf' : 'rgba(242,233,216,.25)'; ctx.stroke();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (has) { ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#10121e'; ctx.fillText(PU_NAME[c.sk].replace('유도 ', ''), sb.x, sb.y - 6); ctx.font = '700 12px ' + MONO; ctx.fillText('×' + c.sn, sb.x, sb.y + 9); }
      else { ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('특수', sb.x, sb.y - 6); ctx.fillText('없음', sb.x, sb.y + 8); }
      if (c && c.scd > 0 && has) { ctx.beginPath(); ctx.arc(sb.x, sb.y, sb.r - 2, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - clamp(c.scd / 0.6, 0, 1))); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.stroke(); }
      // fire button or aim stick
      if (cfg.ctl === 't') {
        let q = null; for (const p of ptrs.values()) if (p.seat === s && p.kind === 'aim') q = p;
        const ax = q ? q.ax : w - 24 - STICK_R - 4, ay = q ? q.ay : h - STICK_R - 110;
        stickArt(ax, ay, q, col, dead, '조준', true);
      } else if (!st.af) {
        const b = fireBtn();
        if (fPress) { ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 7, 0, 7); ctx.strokeStyle = hexA(col, 0.5); ctx.lineWidth = 3; ctx.stroke(); }
        ctx.beginPath(); ctx.arc(b.x, b.y, b.r * (fPress ? 0.93 : 1), 0, 7); ctx.fillStyle = fPress ? hexA(col, 0.95) : hexA(col, 0.72); ctx.fill();
        ctx.lineWidth = 3; ctx.strokeStyle = '#fff3cf'; ctx.stroke();
        ctx.font = '19px ' + DISP; ctx.fillStyle = '#10121e'; ctx.fillText('발사', b.x, b.y + 1);
      }
      // move stick
      let q = null; for (const p of ptrs.values()) if (p.seat === s && p.kind === 'stick') q = p;
      stickArt(q ? q.ax : 22 + STICK_R + 6, q ? q.ay : h - STICK_R - 30, q, col, dead, '이동', false);
      ctx.globalAlpha = 1;
      if (dead && st.ph === 'play') { ctx.font = '18px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ee6a55'; ctx.fillText('격추 · 관전 중', w / 2, h - 150); }
      ctx.restore();
      void now;
    }
    function stickArt(ax, ay, q, col, dead, label, aim) {
      ctx.globalAlpha = (dead ? 0.3 : 1) * (q ? 0.95 : 0.5);
      ctx.beginPath(); ctx.arc(ax, ay, STICK_R, 0, 7); ctx.fillStyle = 'rgba(8,10,24,.55)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.stroke();
      // inner ring: inside = turn only (or aim only), outside = thrust (or fire)
      ctx.beginPath(); ctx.arc(ax, ay, STICK_R * (aim ? 0.55 : 0.4), 0, 7); ctx.strokeStyle = 'rgba(242,233,216,.16)'; ctx.lineWidth = 1; ctx.stroke();
      let kx = ax, ky = ay, m = 0;
      if (q) { const dx = q.x - q.ax, dy = q.y - q.ay, d = Math.hypot(dx, dy), mm = Math.min(d, STICK_R); m = mm / STICK_R; if (d > 0) { kx = ax + dx / d * mm; ky = ay + dy / d * mm; } }
      if (q && m > (aim ? 0.55 : 0.4)) { ctx.beginPath(); ctx.arc(ax, ay, STICK_R, 0, 7); ctx.strokeStyle = hexA(col, 0.7); ctx.lineWidth = 3; ctx.stroke(); }
      ctx.beginPath(); ctx.arc(kx, ky, 20, 0, 7); ctx.fillStyle = hexA(col, 0.9); ctx.fill(); ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.stroke();
      if (!q) { ctx.font = '600 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.fillText(label, ax, ay - STICK_R - 10); }
      ctx.globalAlpha = dead ? 0.3 : 1;
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; startRound(); }
        if (st.ph === 'play' && phase === 'count' && !host()) { phase = 'play'; cd = 0; }
        if (st.ph === 'end' && (!prev || prev.ph !== 'end')) {
          endT = END_T;
          if (st.rw >= 0 && isMine(st.rw)) { api.sfx('win'); api.buzz(60); } else api.sfx('chip');
        }
        syncChip();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        chip.remove(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ W, st, phase, locIn, cfg, lay, cam, ptrs, X, Y, pressSpecial }),
    };
  }

  /* ---------- helpers ---------- */
  function hash(a, b) {
    let h = (Math.imul(a | 0, 0x9E3779B1) ^ Math.imul((b | 0) + 0x632BE5AB, 0x85EBCA77)) >>> 0;
    h ^= h >>> 16; h = Math.imul(h, 0x7feb352d) >>> 0; h ^= h >>> 15; return h >>> 0;
  }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'spaceshoot', name: '우주선 슈팅 대전', tag: '실시간 우주 대결', cat: '아케이드',
    blurb: '관성으로 미끄러지는 우주선으로 서로 쏘아 맞혀요! 목숨 3개, 마지막까지 남으면 라운드 승리. 화면보다 넓은 전장 8곳(웜홀·쌍둥이 별·유성우·미로 기지 등), 아이템 5종. 친구와는 온라인·LAN 방으로.',
    tint: '#1f2f6b',
    icon: '<path d="M14 40L30 10l6 14-8 4z" fill="currentColor"/><path d="M14 40l14-12 8-4-2 10z" fill="currentColor" opacity=".6"/><circle cx="40" cy="14" r="2.5" fill="currentColor"/><circle cx="46" cy="8" r="2" fill="currentColor"/><circle cx="42" cy="40" r="9" fill="none" stroke="currentColor" stroke-width="3"/><path d="M38 38l3 2M44 43l2-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'rounds', label: '라운드', choices: [{ v: 3, label: '3판 2선승' }, { v: 5, label: '5판 3선승' }], def: 3 },
      { id: 'arena', label: '전장', choices: [{ v: -1, label: '무작위' }].concat(ARENAS.map((a, i) => ({ v: i, label: a.name }))), def: -1 },
      { id: 'fire', label: '발사', choices: [{ v: 0, label: '버튼 발사' }, { v: 1, label: '자동 연사' }], def: 0 },
      { id: 'grav', label: '중력 우물', choices: [{ v: 0, label: '끄기' }, { v: 1, label: '켜기' }], def: 0 },
    ],
    controls: [
      { id: 'up', label: '위', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'fire', label: '발사', keys: ['Space', 'KeyF'], pad: ['a', 'rt'] },
      { id: 'special', label: '특수무기', keys: ['ShiftLeft', 'KeyE'], pad: ['x', 'rb'] },
      { id: 'aimU', label: '조준 위 (트윈 스틱)', keys: ['KeyI'], pad: ['ry-'] },
      { id: 'aimD', label: '조준 아래 (트윈 스틱)', keys: ['KeyK'], pad: ['ry+'] },
      { id: 'aimL', label: '조준 왼쪽 (트윈 스틱)', keys: ['KeyJ'], pad: ['rx-'] },
      { id: 'aimR', label: '조준 오른쪽 (트윈 스틱)', keys: ['KeyL'], pad: ['rx+'] },
    ],
    quick: [
      '우주선마다 목숨 3개. 상대를 쏘아 맞혀 목숨을 모두 없애요.',
      '화면 왼쪽에 엄지를 대고 밀면 그쪽으로 돌고, 끝까지 밀면 전진. 오른쪽을 누르고 있으면 연사.',
      '마지막까지 남으면 라운드 승리. 3판 2선승(또는 5판 3선승).',
    ],
    rules: [
      { h: '목표', p: [
        '우주선마다 목숨 3개. 총알·레이저·미사일·기뢰(유성우에서는 운석도)에 맞으면 하나씩 잃고 잠깐(약 1.6초) 무적이 돼요.',
        '목숨을 다 잃으면 격추. 마지막까지 남은 우주선이 라운드 승리예요.',
      ] },
      { h: '조작 (터치)', p: [
        '이동: 화면 왼쪽 아무 데나 엄지를 대면 조이스틱이 생겨요. 미는 방향으로 우주선이 돌고, 안쪽 원 밖까지 밀면 그 방향으로 전진(살짝 진동).',
        '우주선은 관성으로 미끄러져요. 놓으면 계속 미끄러지고, 전진하는 동안에는 옆으로 미끄러짐이 줄어 원하는 쪽으로 잘 가요.',
        '발사: 화면 오른쪽 아무 데나 누르고 있으면 연사(설정이 「자동 연사」면 저절로 쏴요).',
        '특수무기: 오른쪽 아래 동그란 「특수」 버튼. 주운 무기가 없으면(「특수 없음」) 눌러도 아무 일 없어요.',
        '조준 보정: 앞쪽 가까이(약 11도 안)에 있는 상대를 향해 총알이 살짝 휘어 나가요. 보정되는 상대에는 조준 표시가 떠요.',
        '트윈 스틱: 왼쪽은 이동, 오른쪽 스틱은 이동과 따로 조준하며 연사(보정은 더 약하게). 왼쪽 위 「조작」 칩으로 바꿔요(이 폰에 기억돼요).',
        'PC 키보드·게임패드: 방향키·WASD·왼스틱 이동, 스페이스·F·Ⓐ·RT 발사, Shift·E·Ⓧ·RB 특수무기. 트윈 스틱이면 IJKL·오른스틱으로 조준하며 연사. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '승리 · 라운드', p: [
        '3판 2선승 또는 5판 3선승이에요.',
        '동시에 모두 격추되면 무승부 라운드(최대 판 수를 넘으면 승수가 많은 사람이 우승, 같으면 공동 우승).',
        '라운드가 150초를 넘으면 목숨이 가장 많이 남은 우주선이 이겨요(같으면 무승부 라운드).',
      ] },
      { h: '넓은 전장', p: [
        '전장은 화면보다 넓어요. 화면이 내 우주선을 따라가요. 오른쪽 위 작은 지도에 모두의 위치와 아이템이 보이고, 화면 밖 상대는 가장자리 화살표(거리 표시)로 알려줘요.',
        '혼자 관전할 때(격추됐을 때 등)는 남은 우주선이 모두 보이게 화면이 맞춰져요.',
      ] },
      { h: '아이템 (가끔 나타나요, 소행성을 부숴도 가끔 나와요)', p: [
        '확산탄: 9초 동안 세 갈래로 쏴요. 방패: 한 번 막아 줘요(15초).',
        '레이저(2발): 조준선 방향으로 즉시 꿰뚫는 빔. 유도 미사일(3발): 가장 가까운 상대를 쫓아가요. 총알로 맞혀 떨어뜨릴 수 있어요.',
        '기뢰(3개): 뒤에 떨어뜨려요. 잠시 뒤 켜지고 상대가 다가오면 터져요. 내 기뢰에는 내가 다치지 않아요. 총알로 쏘면 그 자리에서 터져요.',
        '특수무기는 하나만 들 수 있어요. 새로 주우면 바뀌어요. 아이템은 전장에 최대 3개까지 떠 있어요.',
      ] },
      { h: '전장 8곳 (무작위면 라운드마다 바뀌어요)', p: [
        '소행성 지대: 떠다니는 소행성이 총알을 막아요. 쏘면 쪼개지다 부서져요.',
        '성운: 안개 때문에 내 주변만 보여요. 4.5초마다 레이더가 퍼지며 잠깐 상대 위치를 작은 지도와 화살표로 알려줘요.',
        '블랙홀: 가운데로 끌려가요. 중심에 빠지면 목숨 하나를 잃고 먼 곳에서 다시 나와요.',
        '우주 정거장: 부서지지 않는 벽 뒤에 숨어서 싸워요.',
        '웜홀: 같은 색 구멍 두 개가 이어져 있어요. 우주선과 총알이 들어가면 짝 구멍으로 나와요(미사일·소행성은 그냥 지나가요).',
        '쌍둥이 별: 가운데를 빙글빙글 도는 두 별이 끌어당겨요. 별에 닿으면 튕겨 나가고 총알은 막혀요.',
        '유성우: 한쪽에서 운석이 계속 쏟아져요. 부딪히면 목숨 하나(방패가 먼저 막아요). 총알로 부술 수 있어요.',
        '미로 기지: 벽이 많은 좁은 통로에서 숨바꼭질하며 싸워요.',
        '중력 우물(설정): 블랙홀·쌍둥이 별이 아닌 전장 가운데에 작은 별이 생겨 우주선을 끌어당겨요. 별에 닿으면 튕겨 나가고 총알은 막혀요.',
      ] },
      { h: '팁', p: [
        '멈추고 싶으면 가던 반대쪽으로 밀어 잠깐 전진하세요. 그대로 두면 계속 미끄러져요.',
        '조준 표시가 뜬 상대는 총알이 알아서 살짝 따라가요. 그때 쏘세요.',
        '오른쪽 위 작은 지도와 가장자리 화살표로 화면 밖 상대를 찾아요.',
        '맞은 직후 무적 시간(약 1.6초)에 자리를 옮겨 다시 노려요.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 조종해요. 혼자 하면 나머지 자리는 AI 우주선이에요.',
        '친구와는 온라인·LAN 방으로: 각자 폰으로 한 대씩. 전투는 호스트 폰이 계산해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 조준이 엉성하고 잘 안 피하며, 어려움은 움직임을 예측해 쏘고 총알·운석을 피하고 아이템을 잘 챙겨요. AI는 조준 보정을 받지 않아요.',
        'AI는 상대 위치를 처음부터 알지 못해요. 눈에 보이거나(벽 뒤는 안 보여요) 가까이서 총을 쏘거나 자기를 맞혔을 때만 쫓아오고, 그 밖에는 전장을 돌아다니며 찾아요. 맞으면 잠깐 물러났다가 다시 찾아와요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { AIC, ARENAS, H, SR, BS, BR, LIVES, INV, CAP_T, PR, segCircle, segBox, slots, freeSpot, newWorld, stepWorld, stepBullets, moveShip, damage, fire, special, rayCast, assistAim, aiThink, maybePowerup, roundOver, nextRound, roundWinner, init, buildNav, navField, hazard },
  });
})();
