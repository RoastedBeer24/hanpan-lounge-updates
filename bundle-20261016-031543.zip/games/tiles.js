/* 숫자 타일 — 1–13 숫자 타일 4색 ×2 + 조커 2 (106개). 같은 숫자 다른 색 묶음(그룹)과 같은 색 연속 숫자(런)로
   손패를 모두 내려놓으면 승리. 첫 등록 30점, 이후 판 위 타일 자유 재배치, 조커 회수.
   타일 = 한 글자(ALPH, 같은 종류 2장은 같은 글자), 판 = 세트 문자열 배열. 온라인: 차례인 사람은 판을 로컬에서
   고치다가 {type:'play', table, used}로 새 판 전체를 보내고, 호스트가 검증한다. 편집 중인 판은 api.net.publish로 미리보기. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- tiles ---------- */
  const ALPH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz*';
  const JK = 52;
  const ki = (ch) => ALPH.indexOf(ch);
  const kc = (k) => ALPH[k];
  const isJ = (k) => k === JK;
  const colOf = (k) => (k / 13) | 0;
  const numOf = (k) => (k % 13) + 1;
  const kindOf = (c, n) => c * 13 + n - 1;
  const tileVal = (k) => (isJ(k) ? 30 : numOf(k));
  const COL_NAME = ['빨강', '파랑', '노랑', '검정'];
  const NEED = 30;
  const tName = (k) => (isJ(k) ? '조커' : COL_NAME[colOf(k)] + ' ' + numOf(k));
  const strK = (s) => s.split('').map(ki);
  const kStr = (a) => a.map(kc).join('');
  function cntOf(str) { const c = new Array(53).fill(0); for (const ch of str) { const k = ki(ch); if (k >= 0) c[k]++; } return c; }
  const sortStr = (s) => s.split('').sort((a, b) => ki(a) - ki(b)).join('');

  /* ---------- sets ---------- */
  /* analyze(kinds in table order) -> {ok, run:{c,b}|null, grp:{n,m}|null, pts, why} */
  function analyze(a) {
    const n = a.length;
    const r = { ok: false, run: null, grp: null, pts: 0, why: '' };
    let nj = 0;
    for (const k of a) if (isJ(k)) nj++;
    const nn = n - nj;
    if (n < 3) { r.why = '3장 이상이어야 해요'; return r; }
    if (nn === 0) { r.why = '숫자 타일이 있어야 해요'; return r; }
    let col = -1, base = 0, runOk = n <= 13;
    for (let i = 0; i < n && runOk; i++) {
      const k = a[i]; if (isJ(k)) continue;
      const c = colOf(k), b = numOf(k) - i;
      if (col < 0) { col = c; base = b; } else if (c !== col || b !== base) runOk = false;
    }
    if (runOk && base >= 1 && base + n - 1 <= 13) r.run = { c: col, b: base };
    let num = -1, mask = 0, g = n <= 4, sameNum = true, sameCol = true, c0 = -1, dupCol = false;
    for (const k of a) {
      if (isJ(k)) continue;
      const nk = numOf(k), ck = colOf(k);
      if (num < 0) num = nk; else if (nk !== num) { sameNum = false; g = false; }
      if (c0 < 0) c0 = ck; else if (ck !== c0) sameCol = false;
      if (mask & (1 << ck)) { dupCol = true; g = false; }
      mask |= 1 << ck;
    }
    if (g) r.grp = { n: num, m: mask };
    if (r.run || r.grp) {
      r.ok = true;
      const pr = r.run ? n * r.run.b + (n * (n - 1)) / 2 : 0;
      const pg = r.grp ? r.grp.n * n : 0;
      r.pts = Math.max(pr, pg);
      return r;
    }
    if (sameNum && sameCol && nn > 1) r.why = '같은 타일이 겹쳐요';
    else if (sameNum) r.why = n > 4 ? '같은 숫자는 4장까지예요' : dupCol ? '같은 숫자는 색이 모두 달라야 해요' : '같은 숫자는 색이 달라야 해요';
    else if (sameCol) r.why = n > 13 ? '13장을 넘을 수 없어요' : (runOk ? '1부터 13 사이여야 해요' : '숫자가 차례로 이어져야 해요');
    else r.why = '같은 숫자 묶음도, 같은 색 연속도 아니에요';
    return r;
  }
  /* for each joker in the set (in order): the tile kinds it may stand for */
  function jokerReps(a, r) {
    r = r || analyze(a);
    const out = [];
    if (!r.ok) return out;
    a.forEach((k, i) => {
      if (!isJ(k)) return;
      const s = [];
      if (r.run) s.push(kindOf(r.run.c, r.run.b + i));
      if (r.grp) for (let c = 0; c < 4; c++) if (!(r.grp.m & (1 << c))) s.push(kindOf(c, r.grp.n));
      out.push(s);
    });
    return out;
  }
  /* a valid ordering of the multiset a (runs ascending, jokers filling gaps), or null. pref: kinds jokers should keep */
  function arrange(a, pref) {
    if (analyze(a).ok) return a.slice();
    const n = a.length;
    const real = a.filter((k) => !isJ(k));
    if (n < 3 || !real.length) return null;
    const c = colOf(real[0]);
    if (n <= 13 && real.every((k) => colOf(k) === c)) {
      const nums = real.map(numOf).sort((x, y) => x - y);
      if (nums.every((v, i) => i === 0 || v !== nums[i - 1])) {
        const lo = nums[0], hi = nums[nums.length - 1];
        let best = null, bs = -1e9;
        for (let s = Math.max(1, hi - n + 1); s <= Math.min(lo, 14 - n); s++) {
          const arr = []; let sc = -Math.abs(s - lo) * 0.01;
          for (let v = s; v < s + n; v++) {
            if (nums.includes(v)) arr.push(kindOf(c, v));
            else { arr.push(JK); if (pref && pref.includes(kindOf(c, v))) sc += 10; }
          }
          if (sc > bs) { bs = sc; best = arr; }
        }
        if (best) return best;
      }
    }
    const nm = numOf(real[0]);
    if (n <= 4 && real.every((k) => numOf(k) === nm)) {
      const cs = real.map(colOf);
      if (new Set(cs).size === cs.length) return real.slice().sort((x, y) => x - y).concat(new Array(n - real.length).fill(JK));
    }
    return null;
  }

  /* joker rule: every joker that was on the table either still stands for (one of) the same tile(s), or that tile
     was put down from the rack this turn (one replacement tile per retrieved joker). */
  function jokerRule(startTb, endTb, used) {
    const S = [], E = [];
    for (const s of startTb) if (s.indexOf('*') >= 0) jokerReps(strK(s)).forEach((x) => S.push(x));
    if (!S.length) return true;
    for (const s of endTb) if (s.indexOf('*') >= 0) jokerReps(strK(s)).forEach((x) => E.push(x));
    const A = cntOf(used), takenE = E.map(() => false);
    function rec(i) {
      if (i >= S.length) return true;
      const reps = S[i];
      for (let j = 0; j < E.length; j++) {
        if (takenE[j] || !E[j].some((k) => reps.includes(k))) continue;
        takenE[j] = true; if (rec(i + 1)) return true; takenE[j] = false;
      }
      for (const k of reps) if (A[k] > 0) { A[k]--; if (rec(i + 1)) return true; A[k]++; }
      return false;
    }
    return rec(0);
  }

  /* full check of a submitted table. -> {ok, msg, pts (new-set points before the first meld), bad:[set idx]} */
  function checkPlay(s, seat, table, used) {
    const res = { ok: false, msg: '', pts: 0, bad: [] };
    if (!Array.isArray(table) || typeof used !== 'string' || table.length > 60) { res.msg = '잘못된 판이에요'; return res; }
    const cnt = new Array(53).fill(0);
    for (const t of table) {
      if (typeof t !== 'string' || !t.length || t.length > 20) { res.msg = '잘못된 판이에요'; return res; }
      for (const ch of t) { const k = ki(ch); if (k < 0) { res.msg = '잘못된 타일이에요'; return res; } cnt[k]++; }
    }
    const rk = cntOf(s.r[seat]), uc = cntOf(used);
    for (let k = 0; k < 53; k++) if (uc[k] > rk[k]) { res.msg = '내 패에 없는 타일이에요'; return res; }
    if (used.length !== [...used].filter((ch) => ki(ch) >= 0).length) { res.msg = '잘못된 타일이에요'; return res; }
    const want = cntOf(s.tb.join('') + used);
    for (let k = 0; k < 53; k++) if (want[k] !== cnt[k]) { res.msg = '판의 타일은 내 패로 가져올 수 없어요'; return res; }
    const an = table.map((t) => analyze(strK(t)));
    an.forEach((a, i) => { if (!a.ok) res.bad.push(i); });
    // before the first meld: old sets untouched, new sets only from the rack
    const opened = !!s.op[seat];
    let intact = true;
    if (!opened) {
      const pool = table.slice(), isNew = table.map(() => true);
      for (const o of s.tb) {
        const i = pool.findIndex((t, j) => t === o && isNew[j]);
        if (i < 0) { intact = false; break; }
        isNew[i] = false;
      }
      table.forEach((t, i) => { if (isNew[i] && an[i].ok) res.pts += an[i].pts; });
    }
    if (res.bad.length) { res.msg = an[res.bad[0]].why; return res; }
    if (!opened && !intact) { res.msg = '처음 등록 전에는 판의 타일을 옮길 수 없어요'; return res; }
    if (!used.length) { res.msg = '내 타일을 1장 이상 놓아야 해요'; return res; }
    if (!opened && res.pts < NEED) { res.msg = '처음 등록은 ' + NEED + '점 이상이어야 해요 (지금 ' + res.pts + '점)'; return res; }
    if (opened && !jokerRule(s.tb, table, used)) { res.msg = '조커를 빼려면 그 자리 타일을 내 패에서 놓아야 해요'; return res; }
    res.ok = true;
    return res;
  }

  /* ---------- state ----------
     n, nm, ai, o:{tm (turn seconds, 0 = off), rd (rounds)}, p: pool, r: racks (sorted strings), tb: table sets,
     op: opened (first meld done), t: turn, st0: round's first seat, ps: passes in a row with an empty pool,
     tc: turns this round, end: 0 playing / 1 round over / 2 match over, rn: rounds finished, sc: running scores,
     rr: last round {w, pen, d, why}, last: latest event, seq */
  function deal(s) {
    const pool = [];
    for (let k = 0; k < 52; k++) pool.push(k, k);
    pool.push(JK, JK);
    U.shuffle(pool);
    s.r = [];
    for (let i = 0; i < s.n; i++) s.r.push(sortStr(kStr(pool.splice(0, 14))));
    s.p = kStr(pool);
    s.tb = []; s.op = new Array(s.n).fill(0); s.ps = 0; s.tc = 0; s.end = 0;
    s.t = s.st0;
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const s = {
      n, nm: players.map((p) => p.name), ai: players.map((p) => (p.ai ? 1 : 0)),
      o: { tm: [60, 120].includes(opts.timer) ? opts.timer : 0, rd: [3, 5].includes(opts.rounds) ? opts.rounds : 1 },
      st0: U.rand(n), rn: 0, sc: new Array(n).fill(0), rr: null, seq: 0,
    };
    deal(s);
    s.last = { id: 0, k: 's', s: s.t };
    return s;
  }
  function actor(s) {
    if (s.end === 2) return null;
    if (s.end === 1) return Array.from({ length: s.n }, (_, i) => i);
    return s.t;
  }
  const LIMIT = 1200;
  function endRound(s, why, w) {
    const pen = s.r.map((r) => [...r].reduce((a, ch) => a + tileVal(ki(ch)), 0));
    let win;
    if (why === 'out') win = [w];
    else { const m = Math.min(...pen); win = pen.map((p, i) => (p === m ? i : -1)).filter((i) => i >= 0); }
    const base = pen[win[0]];
    const d = pen.map((p, i) => (win.includes(i) ? 0 : -(p - base)));
    const pot = -d.reduce((a, b) => a + b, 0);
    win.forEach((i, k) => { d[i] = Math.floor(pot / win.length) + (k < pot % win.length ? 1 : 0); });
    d.forEach((x, i) => { s.sc[i] += x; });
    s.rn++;
    s.rr = { w: win, pen, d, why };
    s.end = s.rn >= s.o.rd ? 2 : 1;
  }
  function nextTurn(s) {
    s.t = (s.t + 1) % s.n;
    s.tc++;
    if (s.tc >= LIMIT) endRound(s, 'lim');
  }
  function apply(s, seat, a) {
    if (!a || typeof a.type !== 'string') throw new Error('bad action');
    if (s.end === 2) throw new Error('game over');
    if (s.end === 1) {
      if (a.type !== 'next') throw new Error('round over');
      s.st0 = (s.st0 + 1) % s.n;
      deal(s);
      s.seq++; s.last = { id: s.seq, k: 'r', s: s.t };
      return s;
    }
    if (seat !== s.t) throw new Error('not your turn');
    if (a.type === 'draw') {
      s.seq++;
      if (s.p.length) {
        const ch = s.p[0];
        s.p = s.p.slice(1);
        s.r[seat] = sortStr(s.r[seat] + ch);
        s.ps = 0;
        s.last = { id: s.seq, k: 'd', s: seat, to: a.to ? 1 : 0 };
      } else {
        s.ps++;
        s.last = { id: s.seq, k: 'x', s: seat, to: a.to ? 1 : 0 };
        if (s.ps >= s.n) { endRound(s, 'pool'); return s; }
      }
      nextTurn(s);
      return s;
    }
    if (a.type !== 'play') throw new Error('bad action');
    const table = Array.isArray(a.table) ? a.table.map(String) : null;
    const used = String(a.used || '');
    const chk = checkPlay(s, seat, table, used);
    if (!chk.ok) throw new Error('illegal play: ' + chk.msg);
    const wasOpen = s.op[seat];
    s.tb = table;
    const rc = cntOf(s.r[seat]);
    for (const ch of used) rc[ki(ch)]--;
    let rs = ''; rc.forEach((c, k) => { for (let i = 0; i < c; i++) rs += kc(k); });
    s.r[seat] = rs;
    s.op[seat] = 1;
    s.ps = 0;
    s.seq++;
    s.last = { id: s.seq, k: 'p', s: seat, n: used.length, op: wasOpen ? 0 : 1 };
    if (!rs.length) { endRound(s, 'out', seat); return s; }
    nextTurn(s);
    return s;
  }
  function result(s) {
    if (s.end !== 2) return null;
    const rr = s.rr, nm = s.nm;
    const sg = (x) => (x > 0 ? '+' + x : x < 0 ? '−' + -x : '0');
    let head = rr.why === 'out' ? nm[rr.w[0]] + '이(가) 타일을 모두 내려놓았어요.' : rr.why === 'pool' ? '더미가 떨어지고 더 낼 사람이 없어, 남은 타일 합이 가장 적은 쪽이 이겼어요.' : '판이 너무 길어져서 남은 타일 합이 가장 적은 쪽이 이겼어요.';
    const lines = ['벌점 (남은 타일 합, 조커 30)'];
    for (let i = 0; i < s.n; i++) lines.push(nm[i] + ' · ' + rr.pen[i] + '점 → ' + sg(rr.d[i]));
    let winners = rr.w.slice();
    if (s.o.rd > 1) {
      const best = Math.max(...s.sc);
      winners = s.sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
      const order = s.sc.map((v, i) => i).sort((x, y) => s.sc[y] - s.sc[x]);
      lines.push('', s.o.rd + '판 누적');
      order.forEach((i, k) => lines.push((k + 1) + '위 ' + nm[i] + ' · ' + sg(s.sc[i])));
      head = '마지막 판: ' + head;
    }
    return { winners, text: head + '\n\n' + lines.join('\n') };
  }

  /* ---------- AI ---------- */
  const AI = { budget: 260, hard: 280, easyPeek: 0.2 };
  const nowMs = () => Date.now();
  function genCands(cnt) {
    const J = Math.min(2, cnt[JK]), out = [];
    for (let n = 1; n <= 13; n++) {
      const av = [];
      for (let c = 0; c < 4; c++) if (cnt[kindOf(c, n)] > 0) av.push(c);
      for (let m = 1; m < (1 << av.length); m++) {
        const cs = av.filter((_, i) => m & (1 << i));
        for (let size = Math.max(3, cs.length); size <= 4; size++) {
          const j = size - cs.length;
          if (j > J || (j && size === 4 && cs.length < 2)) continue;
          out.push(cs.map((c) => kindOf(c, n)).concat(new Array(j).fill(JK)));
        }
      }
    }
    for (let c = 0; c < 4; c++) for (let a = 1; a <= 11; a++) {
      let j = 0, real = 0;
      const arr = [];
      for (let b = a; b <= 13; b++) {
        const k = kindOf(c, b);
        if (cnt[k] > 0) { arr.push(k); real++; } else { j++; if (j > J) break; arr.push(JK); }
        if (arr.length >= 3 && real >= 1 && !isJ(arr[0])) out.push(arr.slice());
        else if (arr.length === 3 && isJ(arr[0]) && real >= 2) out.push(arr.slice()); // J x y (joker below)
      }
    }
    return out;
  }
  /* best combination of sets from the rack alone: most tiles, then most points; requires pts >= need */
  function bestMelds(cnt0, need, deadline) {
    const cnt = cnt0.slice();
    const cands = genCands(cnt);
    if (!cands.length) return null;
    const pts = cands.map((c) => analyze(c).pts);
    const by = Array.from({ length: 53 }, () => []);
    cands.forEach((c, i) => { const seen = new Set(); for (const k of c) if (!isJ(k) && !seen.has(k)) { seen.add(k); by[k].push(i); } });
    let best = null, bT = 0, bP = 0, nodes = 0, stop = false;
    const cur = [];
    function take(c) { let ok = true; for (const k of c) if (--cnt[k] < 0) ok = false; if (!ok) for (const k of c) cnt[k]++; return ok; }
    function give(c) { for (const k of c) cnt[k]++; }
    function rec(tiles, p) {
      if ((++nodes & 127) === 0 && nowMs() > deadline) { stop = true; return; }
      if (p >= need && tiles > 0 && (tiles > bT || (tiles === bT && p > bP))) { bT = tiles; bP = p; best = cur.slice(); }
      let rem = 0, k = -1;
      for (let i = 0; i < 53; i++) if (cnt[i] > 0 && (i === JK || by[i].length)) { rem += cnt[i]; if (k < 0 && i !== JK) k = i; }
      if (k < 0 || (best && tiles + rem <= bT && p >= need)) return;
      for (const ci of by[k]) {
        const c = cands[ci];
        if (!take(c)) continue;
        cur.push(c); rec(tiles + c.length, p + pts[ci]); cur.pop(); give(c);
        if (stop) return;
      }
      cnt[k]--; rec(tiles, p); cnt[k]++;
    }
    rec(0, 0);
    return best ? { sets: best.map((c) => c.slice()), tiles: bT, pts: bP } : null;
  }
  function usedOf(rack0, cnt) { let u = ''; for (let k = 0; k < 53; k++) for (let i = cnt[k]; i < rack0[k]; i++) u += kc(k); return u; }
  const cloneTb = (t) => t.map((a) => a.slice());

  function planOpened(s, seat, deadline, noJ) {
    const rack0 = cntOf(s.r[seat]);
    if (noJ) rack0[JK] = 0; // keep the rack's jokers out of this plan
    const W = { tb: s.tb.map(strK), cnt: rack0.slice() };
    const legal = (tb, cnt) => tb.every((a) => analyze(a).ok) && jokerRule(s.tb, tb.map(kStr), usedOf(rack0, cnt));
    const rackN = () => W.cnt.reduce((a, b) => a + b, 0);
    function addMelds(dl) {
      const m = bestMelds(W.cnt, 0, Math.min(deadline, dl));
      if (!m) return false;
      for (const st of m.sets) { W.tb.push(st); for (const k of st) W.cnt[k]--; }
      return true;
    }
    function attach(tb, k, skip) { // put tile k onto some set; returns new tb or null (no legality of jokers checked here)
      for (let i = 0; i < tb.length; i++) {
        if (i === skip) continue;
        const pref = jokerReps(tb[i]).flat();
        for (const cand of [tb[i].concat([k]), [k].concat(tb[i])]) {
          const arr = arrange(cand, pref);
          if (arr) { const t2 = cloneTb(tb); t2[i] = arr; return t2; }
        }
      }
      return null;
    }
    function extend(allowJ) {
      for (let k = 0; k < 53; k++) {
        if (!W.cnt[k] || (isJ(k) && !allowJ)) continue;
        for (let i = 0; i < W.tb.length; i++) {
          const pref = jokerReps(W.tb[i]).flat();
          for (const cand of [W.tb[i].concat([k]), [k].concat(W.tb[i])]) {
            const arr = arrange(cand, pref);
            if (!arr) continue;
            const t2 = cloneTb(W.tb); t2[i] = arr;
            const c2 = W.cnt.slice(); c2[k]--;
            if (legal(t2, c2)) { W.tb = t2; W.cnt = c2; return true; }
          }
        }
      }
      return false;
    }
    function splitIns() {
      for (let k = 0; k < 52; k++) {
        if (!W.cnt[k]) continue;
        for (let i = 0; i < W.tb.length; i++) {
          const a = W.tb[i], r = analyze(a);
          if (!r.run || r.run.c !== colOf(k)) continue;
          const p = numOf(k) - r.run.b;
          if (p < 2 || a.length - p < 3) continue;
          const left = a.slice(0, p).concat([k]), right = a.slice(p);
          if (!analyze(left).ok || !analyze(right).ok) continue;
          const t2 = cloneTb(W.tb); t2.splice(i, 1, left, right);
          const c2 = W.cnt.slice(); c2[k]--;
          if (legal(t2, c2)) { W.tb = t2; W.cnt = c2; return true; }
        }
      }
      return false;
    }
    function fixFragments(tb) { // pieces shorter than 3 get attached tile by tile to other sets (merging runs)
      let t = tb;
      for (let guard = 0; guard < 4; guard++) {
        const i = t.findIndex((a) => !analyze(a).ok);
        if (i < 0) return t;
        if (t[i].length > 2) return null;
        const frag = t[i];
        let t2 = t.slice(0, i).concat(t.slice(i + 1));
        for (const k of frag) { t2 = attach(t2, k, -1); if (!t2) return null; }
        t = t2;
      }
      return t.every((a) => analyze(a).ok) ? t : null;
    }
    function takeFromTable(tb, kind) {
      for (let i = 0; i < tb.length; i++) {
        const a = tb[i];
        for (let j = 0; j < a.length; j++) {
          if (a[j] !== kind) continue;
          const r = analyze(a);
          const opts = [[a.slice(0, j).concat(a.slice(j + 1))]];
          if (r.run && j > 0 && j < a.length - 1) opts.unshift([a.slice(0, j), a.slice(j + 1)]);
          for (const pieces of opts) {
            const nt = tb.slice(0, i).concat(pieces.filter((p) => p.length), tb.slice(i + 1));
            const f = fixFragments(nt);
            if (f) return f;
          }
        }
      }
      return null;
    }
    function targets(k) {
      const n = numOf(k), c = colOf(k), out = [];
      const others = [0, 1, 2, 3].filter((x) => x !== c);
      for (let x = 0; x < 3; x++) for (let y = x + 1; y < 3; y++) out.push([k, kindOf(others[x], n), kindOf(others[y], n)].sort((p, q) => p - q));
      for (let d = -2; d <= 0; d++) { const st = n + d; if (st >= 1 && st + 2 <= 13) out.push([kindOf(c, st), kindOf(c, st + 1), kindOf(c, st + 2)]); }
      return out;
    }
    function borrow() {
      for (let k = 0; k < 52; k++) {
        if (!W.cnt[k]) continue;
        for (const T of targets(k)) {
          if (nowMs() > deadline) return false;
          const c2 = W.cnt.slice(), miss = [];
          for (const x of T) { if (c2[x] > 0) c2[x]--; else miss.push(x); }
          if (!miss.length || miss.length > 2) continue;
          let t2 = W.tb;
          for (const m of miss) { t2 = takeFromTable(t2, m); if (!t2) break; }
          if (!t2) continue;
          t2 = cloneTb(t2); t2.push(T.slice());
          if (legal(t2, c2)) { W.tb = t2; W.cnt = c2; return true; }
        }
      }
      return false;
    }
    function retrieve() {
      for (let i = 0; i < W.tb.length; i++) {
        const a = W.tb[i];
        if (!a.includes(JK)) continue;
        const reps = jokerReps(a);
        let jn = 0;
        for (let p = 0; p < a.length; p++) {
          if (!isJ(a[p])) continue;
          for (const k of reps[jn] || []) {
            if (!W.cnt[k]) continue;
            const ns = a.slice(); ns[p] = k;
            if (!analyze(ns).ok) continue;
            const t2 = cloneTb(W.tb); t2[i] = ns;
            const c2 = W.cnt.slice(); c2[k]--; c2[JK]++;
            // use the joker in new sets from the rack, else on any set
            const m = bestMelds(c2, 0, Math.min(deadline, nowMs() + 25));
            if (m) {
              const t3 = cloneTb(t2), c3 = c2.slice();
              m.sets.forEach((st) => { t3.push(st); st.forEach((x) => c3[x]--); });
              if (c3[JK] <= rack0[JK] && legal(t3, c3)) { W.tb = t3; W.cnt = c3; return true; }
            }
            for (let q = 0; q < t2.length; q++) {
              for (const cand of [t2[q].concat([JK]), [JK].concat(t2[q])]) {
                if (!analyze(cand).ok) continue;
                const t3 = cloneTb(t2); t3[q] = cand;
                const c3 = c2.slice(); c3[JK]--;
                if (c3[JK] <= rack0[JK] && legal(t3, c3)) { W.tb = t3; W.cnt = c3; return true; }
              }
            }
          }
          jn++;
        }
      }
      return false;
    }
    addMelds(nowMs() + AI.budget * 0.35);
    let guard = 0;
    while (nowMs() < deadline && guard++ < 60) {
      if (retrieve() || extend(false) || splitIns() || borrow()) continue;
      break;
    }
    if (rackN() <= 3 || !s.p.length) { let g2 = 0; while (g2++ < 4 && nowMs() < deadline + 40 && extend(true)); }
    if (W.cnt[JK] > rack0[JK]) return null;
    return { table: W.tb.map(kStr), used: usedOf(rack0, W.cnt) };
  }
  /* 어려움: rebuild the whole table from table tiles + rack. Every table tile must be used; maximise rack tiles placed.
     Candidate sets come from the combined counts; branch on the lowest remaining kind (cover it with a set or leave a
     rack copy of it behind). Leaves are checked with the joker rule. */
  function rebuild(s, seat, deadline, noJ) {
    const rack0 = cntOf(s.r[seat]);
    if (noJ) rack0[JK] = 0;
    const tabC = cntOf(s.tb.join(''));
    const cnt = tabC.map((c, k) => c + rack0[k]);
    const cands = genCands(cnt);
    const by = Array.from({ length: 53 }, () => []);
    cands.forEach((c, i) => { const seen = new Set(); for (const k of c) if (!isJ(k) && !seen.has(k)) { seen.add(k); by[k].push(i); } });
    by.forEach((l) => l.sort((x, y) => cands[y].length - cands[x].length));
    const left = new Array(53).fill(0); // rack copies left behind
    const rackN = rack0.reduce((a, b) => a + b, 0);
    let best = null, bU = 0, bJ = 0, nodes = 0, stop = false;
    const cur = [], memo = new Map();
    function rec(leftN) {
      if ((++nodes & 63) === 0 && nowMs() > deadline) { stop = true; return; }
      const key = cnt.join(',');
      const seen = memo.get(key);
      if (seen != null && seen <= leftN) return; // reached the same remainder before with no more tiles left behind
      memo.set(key, leftN);
      let k = -1, kb = 1e9;
      for (let i = 0; i < 52; i++) if (cnt[i] > 0) { // most constrained kind first
        let o = 0; for (const ci of by[i]) { const c = cands[ci]; let ok = true; for (const x of c) if (cnt[x] <= 0) { ok = false; break; } if (ok) o++; }
        if (left[i] < rack0[i]) o++;
        if (o < kb) { kb = o; k = i; if (o <= 1) break; }
      }
      if (k < 0) { // only jokers may remain
        const lj = cnt[JK];
        if (lj > rack0[JK]) return;
        const used = rackN - leftN - lj;
        // prefer more rack tiles; on a tie keep more jokers in hand
        if (used > bU || (used === bU && used > 0 && lj > bJ)) {
          const tb = cur.map((c) => kStr(c)), u = usedStr(lj);
          if (jokerRule(s.tb, tb, u)) { best = tb; bU = used; bJ = lj; }
        }
        return;
      }
      if (best && rackN - leftN <= bU) return; // cannot beat the best any more
      for (const ci of by[k]) {
        const c = cands[ci];
        let ok = true;
        for (const x of c) if (--cnt[x] < 0) ok = false;
        if (ok) { cur.push(c); rec(leftN); cur.pop(); }
        for (const x of c) cnt[x]++;
        if (stop) return;
      }
      if (left[k] < rack0[k]) { left[k]++; cnt[k]--; rec(leftN + 1); cnt[k]++; left[k]--; }
    }
    function usedStr(lj) { let u = ''; for (let k = 0; k < 53; k++) { const n = k === JK ? rack0[JK] - lj : rack0[k] - left[k]; for (let i = 0; i < n; i++) u += kc(k); } return u; }
    rec(0);
    if (!best || !bU) return null;
    // keep untouched sets where they were, new ones after them
    const pool = best.slice(), out = [];
    for (const o of s.tb) { const i = pool.indexOf(o); if (i >= 0) { out.push(o); pool.splice(i, 1); } }
    const table = out.concat(pool);
    const tc = cntOf(table.join('')); let used = '';
    for (let k = 0; k < 53; k++) for (let i = tabC[k]; i < tc[k]; i++) used += kc(k);
    return { table, used };
  }
  const jUsed = (p) => (p ? [...p.used].filter((ch) => ch === '*').length : 0);
  function planHard(s, seat, deadline) {
    const rack = s.r[seat], hasJ = rack.indexOf('*') >= 0, start = nowMs(), span = deadline - start;
    const plans = [];
    const tryBoth = (noJ, frac) => {
      const dl = start + span * frac;
      const p1 = planOpened(s, seat, Math.min(dl, nowMs() + span * 0.3), noJ);
      if (p1 && p1.used.length) plans.push(p1);
      const p2 = rebuild(s, seat, dl, noJ);
      if (p2 && p2.used.length) plans.push(p2);
    };
    if (hasJ) tryBoth(true, 0.45);
    tryBoth(false, 1);
    const ok = plans.filter((p) => checkPlay(s, seat, p.table, p.used).ok);
    if (!ok.length) return null;
    // score: tiles (and their points) leaving the rack; jokers are worth holding until they finish the game
    let minOpp = 99; for (let i = 0; i < s.n; i++) if (i !== seat) minOpp = Math.min(minOpp, s.r[i].length);
    const urgent = minOpp <= 4 || s.p.length < 8;
    const score = (p) => {
      const out = p.used.length === rack.length;
      if (out) return 1e6;
      const left = rack.length - p.used.length;
      let v = p.used.length * 10 + [...p.used].reduce((a, ch) => a + tileVal(ki(ch)) * 0.1, 0);
      if (!urgent && left > 3) v -= jUsed(p) * 38; // a joker on the table only pays if it moves a lot of tiles
      return v;
    };
    ok.sort((a, b) => score(b) - score(a));
    const top = ok[0];
    if (score(top) <= 0) return null;
    return top;
  }
  function ai(s, seat, lv) {
    if (s.end === 2) return null;
    if (s.end === 1) return { type: 'next' };
    if (seat !== s.t) return null;
    lv = lv || 2;
    const t0 = nowMs();
    let plan = null;
    try {
      if (!s.op[seat]) {
        const rk = cntOf(s.r[seat]);
        if (lv === 3) { // first meld without jokers when that is enough
          const nj = rk.slice(); nj[JK] = 0;
          let m = bestMelds(nj, NEED, t0 + 120);
          if (!m) m = bestMelds(rk, NEED, t0 + 260);
          if (m) plan = { table: s.tb.concat(m.sets.map(kStr)), used: m.sets.map(kStr).join('') };
        } else {
          const m = bestMelds(rk, NEED, t0 + (lv === 1 ? 60 : AI.budget));
          if (m) plan = { table: s.tb.concat(m.sets.map(kStr)), used: m.sets.map(kStr).join('') };
        }
      } else if (lv === 1 && Math.random() < AI.easyPeek) plan = planOpened(s, seat, t0 + 120); // a lucky spot now and then
      else if (lv === 1) { // beginner: new sets from the rack and tiles tacked onto the ends of sets — no rearranging
        const rk = cntOf(s.r[seat]);
        const m = bestMelds(rk, 0, t0 + 60);
        const tb = s.tb.slice();
        let used = '';
        if (m) for (const st of m.sets) { tb.push(kStr(st)); used += kStr(st); for (const k of st) rk[k]--; }
        {
          for (let k = 0; k < 52; k++) {
            if (!rk[k]) continue;
            for (let i = 0; i < tb.length; i++) {
              const a = strK(tb[i]);
              if (a.includes(JK)) continue;
              const cand = [a.concat([k]), [k].concat(a)].find((c) => analyze(c).ok);
              if (cand) { tb[i] = kStr(cand); used += kc(k); rk[k]--; break; }
            }
          }
        }
        if (used) plan = { table: tb, used };
      } else if (lv === 3) plan = planHard(s, seat, t0 + AI.hard);
      else plan = planOpened(s, seat, t0 + AI.budget);
    } catch (e) { plan = null; }
    if (plan && plan.used.length && checkPlay(s, seat, plan.table, plan.used).ok) return { type: 'play', table: plan.table, used: plan.used };
    return { type: 'draw' };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.end === 1) {
      if (!s.ai.every((x) => x) || seat !== 0) return -1; // people press 「다음 판」 themselves
      return 1600;
    }
    if (seat !== s.t) return -1;
    return lv === 1 ? 1000 : lv === 3 ? 600 : 700;
  }

  /* ---------- drawing helpers ---------- */
  const TC = ['#c63a2c', '#2563b6', '#cf8a0e', '#25212b'];
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace';
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  function glyph(ctx, c, x, y, s) {
    ctx.beginPath();
    if (c === 0) ctx.arc(x, y, s * 0.55, 0, 7);
    else if (c === 1) ctx.rect(x - s * 0.5, y - s * 0.5, s, s);
    else if (c === 2) { ctx.moveTo(x, y - s * 0.62); ctx.lineTo(x + s * 0.62, y + s * 0.48); ctx.lineTo(x - s * 0.62, y + s * 0.48); ctx.closePath(); }
    else { ctx.moveTo(x, y - s * 0.66); ctx.lineTo(x + s * 0.55, y); ctx.lineTo(x, y + s * 0.66); ctx.lineTo(x - s * 0.55, y); ctx.closePath(); }
    ctx.fill();
  }
  /* o: {back, sel, m (placed this turn), dim, lift, fresh} */
  function drawTile(ctx, x, y, w, h, k, o) {
    o = o || {};
    const r = Math.max(3, w * 0.14);
    ctx.save();
    if (o.lift) { ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 8; }
    else { ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = 3; ctx.shadowOffsetY = 1.5; }
    ctx.fillStyle = o.back ? '#1c1426' : '#bfae8a';
    rr(ctx, x, y, w, h, r); ctx.fill();
    ctx.shadowColor = 'transparent';
    const fh = h - Math.max(2, h * 0.07);
    if (o.back) {
      const g = ctx.createLinearGradient(x, y, x + w, y + fh);
      g.addColorStop(0, '#4d2c5a'); g.addColorStop(1, '#33203f');
      ctx.fillStyle = g; rr(ctx, x, y, w, fh, r); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1;
      rr(ctx, x + w * 0.16, y + fh * 0.14, w * 0.68, fh * 0.72, r * 0.6); ctx.stroke();
      ctx.fillStyle = 'rgba(227,174,69,.75)'; glyph(ctx, 3, x + w / 2, y + fh / 2, w * 0.24);
    } else {
      const g = ctx.createLinearGradient(0, y, 0, y + fh);
      g.addColorStop(0, '#fffbf2'); g.addColorStop(1, '#eee1c4');
      ctx.fillStyle = g; rr(ctx, x, y, w, fh, r); ctx.fill();
      if (isJ(k)) {
        const cx = x + w / 2, cy = y + fh * 0.44, R = w * 0.2;
        for (let c = 0; c < 4; c++) { const a = c * Math.PI / 2 - Math.PI / 4; ctx.fillStyle = TC[c]; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * R, cy + Math.sin(a) * R, w * 0.13, 0, 7); ctx.fill(); }
        ctx.fillStyle = '#e3ae45'; ctx.beginPath();
        for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4 - Math.PI / 2, rad = i % 2 ? w * 0.07 : w * 0.17; ctx.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad); }
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#5a3d10'; ctx.font = '700 ' + Math.max(7, Math.round(w * 0.22)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('조커', cx, y + fh * 0.84);
      } else {
        const c = colOf(k), n = numOf(k);
        ctx.fillStyle = TC[c];
        ctx.font = '700 ' + Math.round(w * (n >= 10 ? 0.5 : 0.58)) + 'px ' + FONT;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        if (n >= 10) { ctx.save(); ctx.translate(x + w / 2, y + fh * 0.43); ctx.scale(0.86, 1); ctx.fillText(String(n), 0, 0); ctx.restore(); }
        else ctx.fillText(String(n), x + w / 2, y + fh * 0.43);
        if (n === 6 || n === 9) { ctx.fillRect(x + w * 0.36, y + fh * 0.66, w * 0.28, Math.max(1, w * 0.04)); }
        glyph(ctx, c, x + w / 2, y + fh * 0.8, w * 0.15);
      }
      if (o.m) { ctx.strokeStyle = 'rgba(227,174,69,.95)'; ctx.lineWidth = 1.6; rr(ctx, x + 1, y + 1, w - 2, fh - 2, r); ctx.stroke(); }
    }
    if (o.sel) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.6; rr(ctx, x - 1.5, y - 1.5, w + 3, h + 3, r + 1); ctx.stroke(); }
    if (o.dim) { ctx.fillStyle = 'rgba(14,10,20,.45)'; rr(ctx, x, y, w, h, r); ctx.fill(); }
    ctx.restore();
  }
  function noiseTile() {
    const c = document.createElement('canvas'); c.width = c.height = 96;
    const x = c.getContext('2d'), d = x.createImageData(96, 96);
    for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 14; }
    x.putImageData(d, 0, 0); return c;
  }

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const noise = noiseTile();
    let st = null, G = null, bg = null, bgKey = '', dirty = true, uid = 0;
    let zoom = U.clamp(+U.store.get('tiles.zoom', 1) || 1, 0.6, 1.8), scrollY = 0;
    const slots = {}; // seat -> array of chars|null (rack arrangement, this device only)
    let glowAt = {}; // slot index -> time of arrival (viewer seat)
    let E = null; // edit in progress: {seq, seat, tb:[{id,t:[{c,m}]}], slots0, chk, strs, used, changed, deadline}
    let drag = null, sel = null, pan = null, pinch = null;
    const ptrs = new Map();
    let fresh = { t: 0, idx: new Set() };
    let waitSeq = -1, waitUntil = 0, turnSeen = 0, lastMsg = '';
    let preview = null, previewSig = '', pollAt = 0, pubTimer = 0, lastPubSig = '';
    let TL = null, TLsets = null; // table layout + displayed sets
    let timeoutFired = -1;

    /* DOM: bottom buttons, zoom buttons, round sheet */
    const hud = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px', gap: '6px', flexWrap: 'nowrap' } });
    const B = (txt, cls, fn, extra) => L.h('button', { class: 'btn ' + (cls || ''), style: Object.assign({ flex: '1 1 0', minWidth: 0, minHeight: '46px', padding: '4px 6px', whiteSpace: 'nowrap', fontSize: '14px' }, extra || {}), onclick: fn }, txt);
    const zoomBox = L.h('div', { style: { position: 'absolute', right: '10px', display: 'flex', gap: '6px', zIndex: 3 } });
    const zb = (t, d, lab) => L.h('button', { class: 'btn sm', 'aria-label': lab, style: { width: '40px', minHeight: '40px', padding: 0, fontSize: '18px', background: 'rgba(23,19,31,.72)' }, onclick() { setZoom(zoom + d); api.sfx('click'); } }, t);
    zoomBox.append(zb('−', -0.15, '타일 작게'), zb('+', 0.15, '타일 크게'));
    zoomBox.classList.add('tl-zoom');
    root.append(hud, zoomBox);
    let roundEl = null;
    /* invisible boxes over canvas regions — spotlight targets for the first-play tutorial */
    const anc = {};
    function anchor(cls, x, y, w, h) {
      let el = anc[cls];
      if (!el) { el = anc[cls] = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', visibility: 'hidden' } }); root.append(el); }
      Object.assign(el.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' });
    }

    const vwr = () => api.viewer();
    function bottomSeat() {
      const v = vwr();
      if (v >= 0) return v;
      if (st && api.canAct(st.t)) return st.t;
      const m = api.mySeats();
      return m.length ? m[0] : -1;
    }
    const faceUp = () => { const b = bottomSeat(); return b >= 0 && b === vwr(); };
    const locked = () => st && st.seq === waitSeq && performance.now() < waitUntil;
    function setZoom(z) {
      const old = zoom;
      zoom = U.clamp(Math.round(z * 100) / 100, 0.6, 1.8);
      if (old !== zoom) { scrollY *= zoom / old; U.store.set('tiles.zoom', zoom); dirty = true; }
    }

    /* ----- rack slots ----- */
    function capFor(seat) { return G ? G.rows * G.cols : 24; }
    function fitSlots(seat) {
      const sl = slots[seat]; if (!sl) return;
      const cap = capFor(seat);
      while (sl.length < cap) sl.push(null);
      while (sl.length > cap && sl[sl.length - 1] == null) sl.pop();
      for (let i = sl.length - 1; sl.length > cap && i >= 0; i--) if (sl[i] == null) sl.splice(i, 1);
    }
    function sortRack(seat, mode, quiet) {
      const sl = slots[seat]; if (!sl) return;
      const tiles = sl.filter((x) => x != null).map(ki);
      if (mode === 'num') tiles.sort((a, b) => (isJ(a) - isJ(b)) || numOf(a) - numOf(b) || colOf(a) - colOf(b));
      else tiles.sort((a, b) => (isJ(a) - isJ(b)) || colOf(a) - colOf(b) || numOf(a) - numOf(b));
      const cap = capFor(seat), out = [];
      const groups = mode === 'col' ? new Set(tiles.map((k) => (isJ(k) ? 9 : colOf(k)))).size : 1;
      const gaps = mode === 'col' && tiles.length + groups - 1 <= cap;
      tiles.forEach((k, i) => {
        if (gaps && i > 0 && (isJ(k) ? 9 : colOf(k)) !== (isJ(tiles[i - 1]) ? 9 : colOf(tiles[i - 1]))) out.push(null);
        out.push(kc(k));
      });
      slots[seat] = out; fitSlots(seat);
      if (!quiet) { U.store.set('tiles.sort', mode); api.sfx('chip'); api.buzz(8); }
      glowAt = {};
      dirty = true;
    }
    function reconcile(seat) {
      const rack = st.r[seat];
      if (!slots[seat]) { slots[seat] = rack.split(''); fitSlots(seat); sortRack(seat, U.store.get('tiles.sort', 'col') === 'num' ? 'num' : 'col', true); return; }
      const sl = slots[seat], need = cntOf(rack);
      for (let i = 0; i < sl.length; i++) if (sl[i] != null) { const k = ki(sl[i]); if (need[k] > 0) need[k]--; else sl[i] = null; }
      const now = performance.now();
      for (let k = 0; k < 53; k++) while (need[k]-- > 0) {
        let i = sl.indexOf(null);
        if (i < 0) { sl.push(null); i = sl.length - 1; }
        sl[i] = kc(k);
        if (seat === vwr()) glowAt[i] = now;
      }
      fitSlots(seat);
    }
    function rackInsert(sl, j, ch) {
      while (sl.length <= j) sl.push(null);
      if (sl[j] == null) { sl[j] = ch; return; }
      let e = j; while (e < sl.length && sl[e] != null) e++;
      if (e < sl.length) { for (let x = e; x > j; x--) sl[x] = sl[x - 1]; sl[j] = ch; return; }
      e = j; while (e >= 0 && sl[e] != null) e--;
      if (e >= 0) { for (let x = e; x < j; x++) sl[x] = sl[x + 1]; sl[j] = ch; return; }
      sl.splice(j, 0, ch);
    }

    /* ----- edit model ----- */
    const kinds = (t) => t.map((x) => ki(x.c));
    function newEdit(seat) {
      E = { seq: st.seq, seat, tb: st.tb.map((s) => ({ id: ++uid, t: s.split('').map((c) => ({ c, m: 0 })) })), slots0: (slots[seat] || []).slice(), deadline: st.o.tm ? performance.now() + st.o.tm * 1000 : 0 };
      recheck(true);
    }
    function resetEdit() {
      if (!E) return;
      slots[E.seat] = E.slots0.slice(); fitSlots(E.seat);
      E.tb = st.tb.map((s) => ({ id: ++uid, t: s.split('').map((c) => ({ c, m: 0 })) }));
      sel = null;
      recheck();
    }
    function recheck(quiet) {
      if (!E) return;
      E.strs = E.tb.map((s) => s.t.map((x) => x.c).join(''));
      let used = '';
      E.tb.forEach((s) => s.t.forEach((x) => { if (x.m) used += x.c; }));
      E.used = used;
      E.chk = checkPlay(st, E.seat, E.strs, used);
      E.changed = used.length > 0 || E.strs.join('|') !== st.tb.join('|');
      E.an = E.tb.map((s) => analyze(kinds(s.t)));
      if (!quiet) publishPreview();
      renderHud(); dirty = true;
    }
    function publishPreview() {
      if (!api.online || !E) return;
      if (pubTimer) return;
      pubTimer = setTimeout(() => {
        pubTimer = 0;
        if (!E || !st) return;
        const sig = E.strs.join('|');
        if (sig === lastPubSig) return;
        lastPubSig = sig;
        try { api.net.publish({ k: st.seq, s: E.seat, tb: E.strs }); } catch (e) {}
      }, 220);
    }
    function removeAt(tb, set, idx, split) {
      const an = analyze(kinds(set.t));
      set.t.splice(idx, 1);
      if (split && an.ok && an.run && idx > 0 && idx < set.t.length) {
        const right = set.t.splice(idx);
        tb.splice(tb.indexOf(set) + 1, 0, { id: ++uid, t: right });
      }
      if (!set.t.length) tb.splice(tb.indexOf(set), 1);
    }
    function orderLike(tiles, arr) {
      const pool = tiles.slice();
      return arr.map((k) => { const i = pool.findIndex((t) => ki(t.c) === k); return pool.splice(i, 1)[0]; });
    }
    function place(tb, ref, tile, gap, pref) {
      const before = kinds(ref.t), an0 = analyze(before);
      pref = pref || jokerReps(before, an0).flat();
      gap = U.clamp(gap, 0, ref.t.length);
      const ins = ref.t.slice(); ins.splice(gap, 0, tile);
      const ka = kinds(ins);
      if (analyze(ka).ok) { ref.t = ins; return 'ok'; }
      const arr = arrange(ka, pref);
      if (arr) { ref.t = orderLike(ins, arr); return 'ok'; }
      if (an0.run && gap > 0 && gap < ref.t.length) {
        const opts = [[ref.t.slice(0, gap).concat([tile]), ref.t.slice(gap)], [ref.t.slice(0, gap), [tile].concat(ref.t.slice(gap))]];
        for (const [a, b] of opts) {
          if (analyze(kinds(a)).ok && analyze(kinds(b)).ok) { ref.t = a; tb.splice(tb.indexOf(ref) + 1, 0, { id: ++uid, t: b }); return 'split'; }
        }
      }
      ref.t = ins;
      return 'bad';
    }
    /* src: {from:'rack', slot} | {from:'tb', si, idx}; tgt: {kind:'rack', slot} | {kind:'set', si, gap, swapJ} | {kind:'new'} */
    function doMove(ed, sl, src, tgt, opened) {
      const tb = ed ? ed.tb : null;
      if (tgt.kind === 'rack') {
        if (src.from === 'rack') { if (src.slot !== tgt.slot) { const ch = sl[src.slot]; sl[src.slot] = null; rackInsert(sl, tgt.slot, ch); } return { res: 'rack' }; }
        const set = tb[src.si], tile = set.t[src.idx];
        if (!tile.m) return { res: 'deny', msg: '판에 있던 타일은 내 패로 가져올 수 없어요' };
        removeAt(tb, set, src.idx, true);
        rackInsert(sl, tgt.slot, tile.c);
        return { res: 'rack' };
      }
      if (!tb) return { res: 'deny', msg: '' };
      const tref = tgt.kind === 'set' ? tb[tgt.si] : null;
      if (tref && !opened && tref.t.some((x) => !x.m)) return { res: 'deny', msg: '처음 등록 전에는 내 타일로 새 세트만 만들 수 있어요' };
      let tile;
      if (src.from === 'rack') { tile = { c: sl[src.slot], m: 1 }; sl[src.slot] = null; }
      else {
        const sset = tb[src.si];
        tile = sset.t[src.idx];
        if (!tile.m && !opened) return { res: 'deny', msg: '처음 등록 전에는 판의 타일을 옮길 수 없어요' };
        if (tref === sset) {
          const pref = jokerReps(kinds(sset.t)).flat();
          sset.t.splice(src.idx, 1);
          let g = tgt.gap; if (src.idx < g) g--;
          if (!sset.t.length) { sset.t = [tile]; return { res: 'ok' }; }
          return { res: place(tb, sset, tile, g, pref) };
        }
        removeAt(tb, sset, src.idx, true);
      }
      if (!tref) { tb.push({ id: ++uid, t: [tile] }); return { res: 'new' }; }
      if (tgt.swapJ != null && tref.t[tgt.swapJ] && ki(tref.t[tgt.swapJ].c) === JK) {
        const jt = tref.t[tgt.swapJ];
        tref.t[tgt.swapJ] = tile;
        tb.push({ id: ++uid, t: [jt] });
        return { res: 'swap' };
      }
      return { res: place(tb, tref, tile, tgt.gap) };
    }
    function simulate(src, tgt) {
      const ed = { tb: E.tb.map((s) => ({ id: s.id, t: s.t.map((x) => ({ c: x.c, m: x.m })) })) };
      const sl = slots[E.seat].slice();
      const r = doMove(ed, sl, src, tgt, !!st.op[E.seat]);
      return { r, ed };
    }
    function srcTile(src) {
      if (src.from === 'rack') { const sl = slots[bottomSeat()]; return sl ? { c: sl[src.slot], m: 1 } : null; }
      if (!E) return null;
      const s = E.tb[src.si]; return s ? s.t[src.idx] : null;
    }
    function commitMove(src, tgt) {
      if (tgt.kind !== 'rack' && !E) return;
      const seat = bottomSeat();
      const r = doMove(E, slots[seat], src, tgt, !!(st && st.op[seat]));
      if (r.res === 'deny') { if (r.msg) api.toast(r.msg); api.sfx('thud'); api.buzz(20); return; }
      if (r.res === 'swap') { api.toast('조커를 가져왔어요 · 이번 차례에 판에 써야 해요'); api.sfx('pop'); }
      else if (r.res === 'split') { api.sfx('whoosh'); }
      else if (r.res === 'bad') api.sfx('thud');
      else api.sfx(r.res === 'rack' ? 'tick' : 'card');
      api.buzz(10);
      if (tgt.kind === 'new') ensureVisibleLast();
      sel = null;
      if (E) recheck(); else { renderHud(); dirty = true; }
    }
    function ensureVisibleLast() { setTimeout(() => { if (!TL || !E) return; const s = TL.sets[TL.sets.length - 1]; if (!s) return; const vh = G.tY1 - G.tY0; if (s.y + s.h + 24 > scrollY + vh) { scrollY = Math.min(TL.maxScroll + 200, s.y + s.h + 24 - vh); clampScroll(); dirty = true; } }, 0); }

    /* ----- geometry ----- */
    function geometry() {
      const W = cv.w, H = cv.h;
      const b = bottomSeat();
      const n = st && b >= 0 ? st.r[b].length : 14;
      const topH = 46, hudH = 60, stH = 28;
      let rows = 2, cols = Math.max(10, Math.ceil((n + 3) / 2));
      let tw = Math.min(36, (W - 20 - (cols - 1) * 2) / cols);
      if (tw < 24) { rows = 3; cols = Math.max(12, Math.ceil((n + 3) / 3)); tw = Math.min(36, (W - 20 - (cols - 1) * 2) / cols); }
      tw = Math.floor(tw);
      const th = Math.round(tw * 1.32);
      const rackH = rows * th + (rows - 1) * 4 + 16;
      const rackY = H - hudH - rackH;
      const statusY = rackY - stH;
      G = { W, H, topH, hudH, stH, rows, cols, tw, th, rackH, rackY, statusY, tY0: topH, tY1: statusY, rx0: Math.round((W - cols * tw - (cols - 1) * 2) / 2), base: U.clamp(W / 400, 0.85, 1.25) };
      zoomBox.style.top = (G.tY1 - 48) + 'px';
      anchor('tl-top', 4, 3, W - 8, topH - 6);
      anchor('tl-table', 2, G.tY0 + 2, W - 4, G.tY1 - G.tY0 - 4);
      anchor('tl-status', 2, statusY, W - 4, stH);
      anchor('tl-rack', 2, rackY + 2, W - 4, rackH - 4);
      anchor('tl-bar', 4, H - hudH + 2, W - 8, hudH - 4);
      if (b >= 0 && slots[b]) fitSlots(b);
      const key = [W, H, rows, cols, tw].join(',');
      if (key !== bgKey) { bgKey = key; buildBg(); }
    }
    function slotPos(i) { const c = i % G.cols, r = (i / G.cols) | 0; return { x: G.rx0 + c * (G.tw + 2), y: G.rackY + 8 + r * (G.th + 4) }; }
    function buildBg() {
      const W = G.W, H = G.H, dpr = cv.dpr;
      const c = document.createElement('canvas'); c.width = Math.ceil(W * dpr); c.height = Math.ceil(H * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr);
      x.fillStyle = '#17131f'; x.fillRect(0, 0, W, H);
      // felt table
      const fg = x.createRadialGradient(W / 2, (G.tY0 + G.tY1) / 2, 20, W / 2, (G.tY0 + G.tY1) / 2, Math.max(W, H) * 0.7);
      fg.addColorStop(0, '#22604f'); fg.addColorStop(0.6, '#174a3d'); fg.addColorStop(1, '#0f3328');
      x.fillStyle = fg; x.fillRect(0, G.tY0, W, G.tY1 - G.tY0);
      x.fillStyle = x.createPattern(noise, 'repeat'); x.fillRect(0, G.tY0, W, G.tY1 - G.tY0);
      x.fillStyle = 'rgba(227,174,69,.35)'; x.fillRect(0, G.tY0, W, 1); x.fillRect(0, G.tY1 - 1, W, 1);
      // status strip
      x.fillStyle = '#1d1828'; x.fillRect(0, G.statusY, W, G.stH);
      // wooden rack
      const wg = x.createLinearGradient(0, G.rackY, 0, G.rackY + G.rackH);
      wg.addColorStop(0, '#6a4426'); wg.addColorStop(1, '#3f2614');
      x.fillStyle = wg; x.fillRect(0, G.rackY, W, G.rackH);
      x.fillStyle = 'rgba(0,0,0,.25)';
      for (let r = 0; r < G.rows; r++) { const y = G.rackY + 8 + r * (G.th + 4) + G.th; x.fillRect(4, y - 1, W - 8, 3); }
      x.strokeStyle = 'rgba(255,220,170,.06)'; x.lineWidth = 1;
      for (let i = 0; i < 14; i++) { x.beginPath(); const yy = G.rackY + 3 + i * (G.rackH / 14); x.moveTo(0, yy); x.bezierCurveTo(W * 0.3, yy + 3, W * 0.6, yy - 3, W, yy + 1); x.stroke(); }
      x.fillStyle = '#17131f'; x.fillRect(0, G.rackY + G.rackH, W, H - G.rackY - G.rackH);
      bg = c;
    }
    cv.onresize = () => { if (st) { geometry(); renderHud(); } dirty = true; };

    /* ----- table layout ----- */
    function displaySets() {
      if (E) return E.tb.map((s) => s.t);
      const src = preview || st.tb;
      return src.map((s) => s.split('').map((c) => ({ c, m: 0 })));
    }
    function layoutTable(sets) {
      const tw = Math.round(30 * zoom * G.base), th = Math.round(tw * 1.32);
      const pad = 10, gapX = 8, capH = 15, rowGap = 6, W = G.W;
      const avail = W - pad * 2;
      const perLine = Math.max(3, Math.floor((avail - 8 + 1) / (tw + 1)));
      let x = pad, y = pad + 2, lineH = 0;
      const out = [];
      sets.forEach((set, i) => {
        const n = set.length, per = Math.min(n, perLine), lines = Math.max(1, Math.ceil(n / perLine));
        const w = per * (tw + 1) - 1 + 8, h = lines * (th + 2) - 2 + 8;
        if (x > pad && x + w > W - pad) { x = pad; y += lineH + capH + rowGap; lineH = 0; }
        const tiles = [];
        for (let j = 0; j < n; j++) tiles.push({ x: x + 4 + (j % perLine) * (tw + 1), y: y + 4 + ((j / perLine) | 0) * (th + 2) });
        out.push({ i, x, y, w, h, tiles, per: perLine, lines });
        x += w + gapX; lineH = Math.max(lineH, h);
      });
      const nw = 3 * (tw + 1) + 7;
      if (x > pad && x + nw > W - pad) { x = pad; y += lineH + capH + rowGap; lineH = 0; }
      const newSlot = { x, y, w: nw, h: th + 8 };
      const contentH = y + Math.max(lineH, th + 8) + capH + pad + 50;
      return { sets: out, newSlot, tw, th, contentH, maxScroll: Math.max(0, contentH - (G.tY1 - G.tY0)) };
    }
    function clampScroll() { if (TL) scrollY = U.clamp(scrollY, 0, TL.maxScroll); }

    /* ----- drawing ----- */
    function tagPill(x, y, text, bgc, fg, font, align) {
      ctx.font = font || '600 11px ' + FONT;
      const tw = ctx.measureText(text).width + 12, h = 18;
      const x0 = U.clamp(align === 'left' ? x : align === 'right' ? x - tw : x - tw / 2, 4, G.W - tw - 4);
      ctx.fillStyle = bgc; rr(ctx, x0, y - h / 2, tw, h, h / 2); ctx.fill();
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, x0 + tw / 2, y + 0.5);
      return tw;
    }
    function clip(t, w) {
      if (ctx.measureText(t).width <= w) return t;
      while (t.length > 1 && ctx.measureText(t + '…').width > w) t = t.slice(0, -1);
      return t + '…';
    }
    function timeLeft() {
      if (!st || !st.o.tm || st.end) return -1;
      if (E && E.deadline) return Math.max(0, (E.deadline - performance.now()) / 1000);
      return Math.max(0, st.o.tm - (performance.now() - turnSeen) / 1000);
    }
    function drawTop(now) {
      const W = G.W, n = st.n;
      const poolW = 52, gap = 5, x0 = 8;
      const cw = (W - 16 - poolW - gap * n) / n;
      for (let i = 0; i < n; i++) {
        const x = x0 + i * (cw + gap), y = 6, h = 34;
        const pl = api.players[i] || { name: st.nm[i], color: '#888' };
        const turn = st.end === 0 && st.t === i;
        ctx.fillStyle = turn ? 'rgba(46,38,64,.98)' : 'rgba(34,28,46,.9)'; rr(ctx, x, y, cw, h, 9); ctx.fill();
        ctx.lineWidth = turn ? 1.6 : 1; ctx.strokeStyle = turn ? '#e3ae45' : 'rgba(242,233,216,.12)'; rr(ctx, x, y, cw, h, 9); ctx.stroke();
        ctx.fillStyle = pl.color; ctx.beginPath(); ctx.arc(x + 9, y + 11, 3.8, 0, 7); ctx.fill();
        ctx.font = '700 11.5px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(clip(pl.name, cw - 20), x + 16, y + 11.5);
        ctx.font = '600 12px ' + MONO; ctx.fillStyle = st.r[i].length <= 2 ? '#ee6a55' : '#e3ae45';
        ctx.fillText(String(st.r[i].length), x + 8, y + 25);
        const cntW = ctx.measureText(String(st.r[i].length)).width;
        ctx.font = '600 10px ' + FONT; ctx.fillStyle = st.op[i] ? '#5fd3a0' : '#ab9fb8';
        ctx.fillText(clip(st.op[i] ? '등록' : '등록 전', cw - cntW - 18), x + 12 + cntW, y + 25.5);
        if (turn && st.o.tm) {
          const left = timeLeft(), f = U.clamp(left / st.o.tm, 0, 1);
          ctx.fillStyle = left < 10 ? '#ee6a55' : '#e3ae45';
          ctx.fillRect(x + 6, y + h - 3, (cw - 12) * f, 2);
        }
      }
      const px = W - 8 - poolW, py = 6;
      ctx.fillStyle = 'rgba(34,28,46,.9)'; rr(ctx, px, py, poolW, 34, 9); ctx.fill();
      ctx.strokeStyle = 'rgba(242,233,216,.12)'; ctx.lineWidth = 1; rr(ctx, px, py, poolW, 34, 9); ctx.stroke();
      ctx.font = '600 10px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'center'; ctx.fillText('더미', px + poolW / 2, py + 11);
      ctx.font = '600 13px ' + MONO; ctx.fillStyle = st.p.length ? '#f2e9d8' : '#ee6a55'; ctx.fillText(String(st.p.length), px + poolW / 2, py + 25);
    }
    function drawTable(now) {
      const sets = displaySets();
      TLsets = sets;
      TL = layoutTable(sets);
      clampScroll();
      const oy = G.tY0 - scrollY;
      ctx.save();
      ctx.beginPath(); ctx.rect(0, G.tY0, G.W, G.tY1 - G.tY0); ctx.clip();
      if (!sets.length && !E) {
        ctx.font = '600 13px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.4)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('아직 판에 놓인 세트가 없어요', G.W / 2, (G.tY0 + G.tY1) / 2 - 10);
      }
      const ft = (now - fresh.t) / 2600, fa = ft < 1 ? 1 - ft : 0;
      const dragTgt = drag && drag.started ? drag.tgt : null;
      const fitSet = drag && drag.started ? drag.fits : null;
      dropMark = null;
      TL.sets.forEach((s, si) => {
        const y = s.y + oy;
        if (y > G.tY1 + 4 || y + s.h < G.tY0 - 20) return;
        const set = sets[si];
        const an = E ? E.an[si] : null;
        const bad = an && !an.ok;
        const touched = E && (set.some((x) => x.m) || !st.tb.includes(E.strs[si]));
        ctx.fillStyle = bad ? 'rgba(238,106,85,.2)' : touched ? 'rgba(227,174,69,.13)' : 'rgba(8,30,24,.35)';
        rr(ctx, s.x, y, s.w, s.h, 7); ctx.fill();
        if (bad) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 1.6; rr(ctx, s.x, y, s.w, s.h, 7); ctx.stroke(); }
        if (fitSet && fitSet.has(si)) { ctx.strokeStyle = 'rgba(95,211,160,.85)'; ctx.lineWidth = 1.8; ctx.setLineDash([5, 3]); rr(ctx, s.x - 2, y - 2, s.w + 4, s.h + 4, 8); ctx.stroke(); ctx.setLineDash([]); }
        if (!E && fa > 0 && fresh.idx.has(si)) { ctx.save(); ctx.globalAlpha = fa; ctx.shadowColor = '#e3ae45'; ctx.shadowBlur = 14; ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; rr(ctx, s.x - 1, y - 1, s.w + 2, s.h + 2, 8); ctx.stroke(); ctx.restore(); }
        set.forEach((t, j) => {
          const p = s.tiles[j];
          const isDragSrc = drag && drag.started && drag.src.from === 'tb' && drag.src.si === si && drag.src.idx === j;
          const isSel = sel && sel.from === 'tb' && sel.si === si && sel.idx === j;
          if (isDragSrc) { ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.setLineDash([3, 3]); rr(ctx, p.x, p.y + oy, TL.tw, TL.th, 4); ctx.stroke(); ctx.setLineDash([]); return; }
          drawTile(ctx, p.x, p.y + oy - (isSel ? 5 : 0), TL.tw, TL.th, ki(t.c), { m: E && t.m, sel: isSel, dim: E && !st.op[E.seat] && !t.m });
        });
        // caption: reason / set kind & points
        let cap = '', capC = '#ab9fb8';
        if (bad) { cap = an.why; capC = '#ff8f7d'; }
        else if (touched && an) { cap = (an.run ? '연속' : '같은 수') + ' · ' + an.pts + '점'; capC = '#e3c27a'; }
        if (cap) {
          ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = capC; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
          ctx.fillText(clip(cap, Math.max(s.w + 30, 150)), s.x + 2, y + s.h + 2);
        }
        if (dragTgt && dragTgt.kind === 'set' && dragTgt.si === si) dropMark = { s, set, oy };
      });
      // new-set slot
      if (E) {
        const ns = TL.newSlot, y = ns.y + oy;
        const hot = dragTgt && dragTgt.kind === 'new';
        ctx.strokeStyle = hot ? '#e3ae45' : 'rgba(242,233,216,.28)'; ctx.lineWidth = hot ? 2 : 1.2; ctx.setLineDash([5, 4]);
        rr(ctx, ns.x, y, ns.w, ns.h, 7); ctx.stroke(); ctx.setLineDash([]);
        if (hot) { ctx.fillStyle = 'rgba(227,174,69,.12)'; rr(ctx, ns.x, y, ns.w, ns.h, 7); ctx.fill(); }
        ctx.font = '600 11px ' + FONT; ctx.fillStyle = hot ? '#e3ae45' : 'rgba(242,233,216,.5)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('＋ 새 세트', ns.x + ns.w / 2, y + ns.h / 2);
      }
      ctx.restore();
      // scroll hint
      if (TL.maxScroll > 4) {
        const vh = G.tY1 - G.tY0, f = vh / (TL.contentH), ty = G.tY0 + (scrollY / TL.contentH) * vh;
        ctx.fillStyle = 'rgba(242,233,216,.25)'; rr(ctx, G.W - 4, ty + 2, 2.5, Math.max(20, f * vh) - 4, 1.5); ctx.fill();
      }
      if (preview && !E) tagPill(10, G.tY0 + 12, (st.nm[st.t] || '') + ' 정리 중 · 미리보기', 'rgba(16,12,22,.8)', '#e3ae45', '600 11px ' + FONT, 'left');
    }
    let dropMark = null;
    function drawDropMark() {
      const dt = drag && drag.started ? drag.tgt : null;
      if (!dropMark || !dt || dt.kind !== 'set') return;
      const { s, set, oy } = dropMark, y = s.y + oy;
      ctx.save();
      ctx.beginPath(); ctx.rect(0, G.tY0, G.W, G.tY1 - G.tY0); ctx.clip();
      const col = dt.swapJ != null || dt.ok ? '#5fd3a0' : '#ee6a55';
      ctx.strokeStyle = col; ctx.lineWidth = 2; rr(ctx, s.x - 2, y - 2, s.w + 4, s.h + 4, 8); ctx.stroke();
      if (dt.swapJ != null) {
        const p = s.tiles[dt.swapJ];
        ctx.lineWidth = 3; rr(ctx, p.x - 2, p.y + oy - 2, TL.tw + 4, TL.th + 4, 6); ctx.stroke();
        tagPill(p.x + TL.tw / 2, y - 10, '조커 바꾸기', col, '#0c2a1e', '700 11px ' + FONT);
      } else {
        const n = set.length, g = U.clamp(dt.gap, 0, n);
        let gx, gy;
        if (g < n) { const p = s.tiles[g]; gx = p.x - 1; gy = p.y; if (g > 0 && s.tiles[g - 1].y !== p.y) { const q = s.tiles[g - 1]; gx = q.x + TL.tw + 1; gy = q.y; } }
        else { const q = s.tiles[n - 1]; gx = q.x + TL.tw + 1; gy = q.y; }
        ctx.fillStyle = col; ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 4;
        rr(ctx, gx - 2.5, gy + oy - 6, 5, TL.th + 12, 2.5); ctx.fill();
        ctx.beginPath(); ctx.moveTo(gx - 6, gy + oy - 10); ctx.lineTo(gx + 6, gy + oy - 10); ctx.lineTo(gx, gy + oy - 3); ctx.closePath(); ctx.fill();
        ctx.shadowColor = 'transparent';
        if (!dt.ok) tagPill(s.x + s.w / 2, y + s.h + 9, '여기는 맞지 않아요', col, '#2b0c06', '700 11px ' + FONT);
      }
      ctx.restore();
    }
    function drawRack(now) {
      const b = bottomSeat();
      if (b < 0) {
        ctx.font = '600 12px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.55)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('관전 중 · 모두 AI', G.W / 2, G.rackY + G.rackH / 2);
        return;
      }
      const up = faceUp();
      const sl = slots[b];
      if (!up || !sl) {
        const n = st.r[b].length;
        for (let i = 0; i < n; i++) { const p = slotPos(i); drawTile(ctx, p.x, p.y, G.tw, G.th, 0, { back: true }); }
        return;
      }
      const active = !!E && !locked();
      sl.forEach((ch, i) => {
        if (ch == null) return;
        if (drag && drag.started && drag.src.from === 'rack' && drag.src.slot === i) return;
        const p = slotPos(i);
        const isSel = sel && sel.from === 'rack' && sel.slot === i;
        const g = glowAt[i] && now - glowAt[i] < 4000 ? 1 - (now - glowAt[i]) / 4000 : 0;
        if (g > 0) { ctx.save(); ctx.globalAlpha = g; ctx.shadowColor = '#e3ae45'; ctx.shadowBlur = 12; ctx.fillStyle = '#e3ae45'; rr(ctx, p.x - 1.5, p.y - 1.5, G.tw + 3, G.th + 3, 5); ctx.fill(); ctx.restore(); }
        drawTile(ctx, p.x, p.y - (isSel ? 7 : 0), G.tw, G.th, ki(ch), { sel: isSel });
      });
      if (drag && drag.started && drag.tgt && drag.tgt.kind === 'rack') {
        const p = slotPos(drag.tgt.slot);
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]); rr(ctx, p.x - 1, p.y - 1, G.tw + 2, G.th + 2, 5); ctx.stroke(); ctx.setLineDash([]);
      }
      if (!active && E && locked()) { ctx.fillStyle = 'rgba(14,10,20,.3)'; ctx.fillRect(0, G.rackY, G.W, G.rackH); }
    }
    function statusInfo() {
      if (!st) return { t: '' };
      if (st.end) return { t: '판이 끝났어요' };
      if (E) {
        if (locked()) return { t: '보내는 중…' };
        const opened = !!st.op[E.seat];
        if (!E.used.length && !E.changed) return { t: opened ? '타일을 판으로 끌어 놓거나, 낼 게 없으면 「' + (st.p.length ? '뽑기' : '넘기기') + '」' : '처음엔 내 타일만으로 30점 이상 새 세트를 만들어요', c: '#d9cfe4' };
        if (!E.chk.ok) return { t: E.chk.msg, c: '#ff8f7d' };
        return { t: st.r[E.seat].length === E.used.length ? '마지막 타일! 「완료」로 승리' : '좋아요 · 「완료」를 누르세요 (' + E.used.length + '장)', c: '#5fd3a0' };
      }
      if (sel) return { t: '옮길 곳을 탭하세요', c: '#e3ae45' };
      const v = vwr();
      if (api.canAct(st.t) && v !== st.t) return { t: '' };
      if (preview) return { t: st.nm[st.t] + '이(가) 판을 정리하고 있어요', c: '#d9cfe4' };
      return { t: lastMsg || (st.nm[st.t] + ' 차례'), c: '#d9cfe4' };
    }
    function drawStatus(now) {
      const y = G.statusY + G.stH / 2;
      const si = statusInfo();
      let right = 0;
      if (E && !st.op[E.seat]) {
        const p = E.chk.pts, ok = p >= NEED;
        right = tagPill(G.W - 8, y, '등록 ' + p + ' / ' + NEED, ok ? '#5fd3a0' : 'rgba(238,106,85,.85)', ok ? '#0c2a1e' : '#2b0c06', '700 11.5px ' + MONO, 'right') + 6;
      }
      const tl = timeLeft();
      if (tl >= 0 && st.end === 0) {
        const txt = Math.ceil(tl) + '초';
        right += tagPill(G.W - 8 - right, y, txt, tl < 10 ? '#ee6a55' : 'rgba(46,38,64,.95)', tl < 10 ? '#2b0c06' : '#e3ae45', '700 11.5px ' + MONO, 'right') + 6;
      }
      ctx.font = '600 12px ' + FONT; ctx.fillStyle = si.c || '#d9cfe4'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(clip(si.t, G.W - 20 - right), 10, y + 0.5);
    }
    function draw(now) {
      cv.clear();
      if (!G || !st) return;
      if (bg) ctx.drawImage(bg, 0, 0, G.W, G.H);
      drawTop(now);
      drawTable(now);
      drawStatus(now);
      drawRack(now);
      if (drag && drag.started) {
        const t = srcTile(drag.src);
        if (t) {
          const w = Math.round(Math.max(G.tw, TL ? TL.tw : G.tw) * 1.12), h = Math.round(w * 1.32);
          ctx.save(); ctx.globalAlpha = drag.tgt && drag.tgt.kind === 'set' ? 0.72 : 1;
          drawTile(ctx, drag.x - w / 2, drag.y - h / 2, w, h, ki(t.c), { lift: true, m: t.m });
          ctx.restore();
        }
        drawDropMark();
      }
    }

    /* ----- hit testing ----- */
    function rackSlotAt(x, y, nearest) {
      let best = -1, bd = 1e9;
      const cap = G.rows * G.cols;
      for (let i = 0; i < cap; i++) {
        const p = slotPos(i), cx = p.x + G.tw / 2, cy = p.y + G.th / 2;
        if (!nearest && (x < p.x - 1 || x > p.x + G.tw + 1 || y < p.y - 4 || y > p.y + G.th + 3)) continue;
        const d = (x - cx) ** 2 + (y - cy) ** 2 * 1.4;
        if (d < bd) { bd = d; best = i; }
      }
      return best;
    }
    function tableTileAt(x, y) {
      if (!TL || y < G.tY0 || y >= G.tY1) return null;
      const cy = y - G.tY0 + scrollY;
      for (let si = 0; si < TL.sets.length; si++) {
        const s = TL.sets[si];
        if (x < s.x || x > s.x + s.w || cy < s.y || cy > s.y + s.h) continue;
        for (let j = 0; j < s.tiles.length; j++) {
          const p = s.tiles[j];
          if (x >= p.x - 0.5 && x <= p.x + TL.tw + 0.5 && cy >= p.y - 3 && cy <= p.y + TL.th + 3) return { si, idx: j };
        }
        return { si, idx: -1 };
      }
      return null;
    }
    function targetAt(x, y, src) {
      if (y >= G.rackY - 8) {
        if (!faceUp()) return null;
        const slot = rackSlotAt(x, Math.max(y, G.rackY + 8), true);
        return slot >= 0 ? { kind: 'rack', slot } : null;
      }
      if (!E || locked() || y < G.tY0 || y >= G.tY1) return null;
      const cy = y - G.tY0 + scrollY;
      for (let si = 0; si < TL.sets.length; si++) {
        const s = TL.sets[si];
        if (x < s.x - 8 || x > s.x + s.w + 8 || cy < s.y - 10 || cy > s.y + s.h + 10) continue;
        const n = s.tiles.length;
        const line = U.clamp(Math.floor((cy - s.y - 4) / (TL.th + 2)), 0, s.lines - 1);
        const a = line * s.per, b = Math.min(n, a + s.per);
        let gap = b;
        for (let j = a; j < b; j++) if (x < s.tiles[j].x + TL.tw / 2) { gap = j; break; }
        let swapJ = null;
        const t = srcTile(src);
        if (t && ki(t.c) !== JK && st.op[E.seat]) {
          for (let j = a; j < b; j++) {
            const p = s.tiles[j];
            if (x > p.x + TL.tw * 0.18 && x < p.x + TL.tw * 0.82 && ki(TLsets[si][j].c) === JK) {
              const reps = jokerReps(kinds(TLsets[si]));
              let jn = 0; for (let q = 0; q < j; q++) if (ki(TLsets[si][q].c) === JK) jn++;
              if ((reps[jn] || []).includes(ki(t.c))) swapJ = j;
            }
          }
        }
        return { kind: 'set', si, gap, swapJ };
      }
      return { kind: 'new' };
    }
    function tgtKey(t) { return t ? [t.kind, t.si, t.gap, t.swapJ, t.slot].join(':') : ''; }
    function evalTarget(src, tgt) {
      if (!tgt || tgt.kind !== 'set' || !E) return tgt;
      const sim = simulate(src, tgt);
      if (sim.r.res === 'deny') tgt.ok = false;
      else tgt.ok = sim.r.res !== 'bad';
      return tgt;
    }
    function fitsFor(src) {
      const out = new Set();
      if (!E) return out;
      const t = srcTile(src); if (!t) return out;
      E.tb.forEach((s, si) => {
        if (src.from === 'tb' && src.si === si) return;
        if (!st.op[E.seat] && s.t.some((x) => !x.m)) return;
        const sim = simulate(src, { kind: 'set', si, gap: s.t.length });
        if (sim.r.res === 'ok' || sim.r.res === 'split') out.add(si);
        else { const sim2 = simulate(src, { kind: 'set', si, gap: 0 }); if (sim2.r.res === 'ok') out.add(si); }
      });
      return out;
    }

    /* ----- input ----- */
    function pickAt(q) {
      // rack tile?
      const b = bottomSeat();
      if (q.y >= G.rackY && faceUp() && slots[b]) {
        const i = rackSlotAt(q.x, q.y, false);
        if (i >= 0 && slots[b][i] != null) return { from: 'rack', slot: i };
        return null;
      }
      if (E && !locked()) {
        const h = tableTileAt(q.x, q.y);
        if (h && h.idx >= 0) {
          const t = E.tb[h.si].t[h.idx];
          if (t.m || st.op[E.seat]) return { from: 'tb', si: h.si, idx: h.idx };
          return { from: 'tb', si: h.si, idx: h.idx, lockedTile: true };
        }
      }
      return null;
    }
    function onDown(e) {
      if (!st || !G || st.end) return;
      const q = cv.local(e);
      ptrs.set(e.pointerId, q);
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
      if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        if (a.y < G.tY1 && b.y < G.tY1) {
          if (drag) drag = null;
          pan = null;
          pinch = { d0: Math.hypot(a.x - b.x, a.y - b.y) || 1, z0: zoom, my: (a.y + b.y) / 2, s0: scrollY };
          dirty = true;
        }
        return;
      }
      if (ptrs.size > 2) return;
      const pk = pickAt(q);
      if (pk && !pk.lockedTile) {
        drag = { pid: e.pointerId, src: pk, x0: q.x, y0: q.y, x: q.x, y: q.y, started: false, touch: e.pointerType !== 'mouse', tgt: null, fits: null };
        return;
      }
      if (pk && pk.lockedTile) { api.toast('처음 등록(30점) 전에는 판의 타일을 옮길 수 없어요'); api.sfx('thud'); }
      if (q.y >= G.tY0 && q.y < G.tY1) pan = { pid: e.pointerId, y0: q.y, s0: scrollY, moved: false, q };
      else if (q.y >= G.rackY && sel) { // tap on an empty rack slot with something selected
        const i = rackSlotAt(q.x, q.y, true);
        if (i >= 0) { const s2 = sel; sel = null; commitMove(s2, { kind: 'rack', slot: i }); }
      }
    }
    function onMove(e) {
      if (!ptrs.has(e.pointerId)) return;
      const q = cv.local(e);
      ptrs.set(e.pointerId, q);
      if (pinch && ptrs.size >= 2) {
        const [a, b] = [...ptrs.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y) || 1;
        const z = U.clamp(pinch.z0 * d / pinch.d0, 0.6, 1.8);
        const cy = pinch.my - G.tY0 + pinch.s0, my = (a.y + b.y) / 2;
        zoom = Math.round(z * 100) / 100;
        scrollY = cy * (zoom / pinch.z0) - (my - G.tY0);
        dirty = true;
        return;
      }
      if (drag && drag.pid === e.pointerId) {
        drag.x = q.x; drag.y = q.y - (drag.touch ? 26 : 0);
        if (!drag.started && Math.hypot(q.x - drag.x0, q.y - drag.y0) > 7) {
          drag.started = true; sel = null;
          drag.fits = fitsFor(drag.src);
          api.sfx('tick'); api.buzz(8);
        }
        if (drag.started) updateDragTarget();
        dirty = true;
        return;
      }
      if (pan && pan.pid === e.pointerId) {
        const dy = q.y - pan.y0;
        if (Math.abs(dy) > 6) pan.moved = true;
        if (pan.moved) { scrollY = pan.s0 - dy; clampScroll(); dirty = true; }
      }
    }
    function updateDragTarget() {
      const t = targetAt(drag.x, drag.y, drag.src);
      if (tgtKey(t) !== tgtKey(drag.tgt)) { drag.tgt = evalTarget(drag.src, t); if (t && t.kind === 'set') api.buzz(4); }
    }
    function onUp(e) {
      const q = ptrs.get(e.pointerId) || cv.local(e);
      ptrs.delete(e.pointerId);
      if (pinch) { if (ptrs.size < 2) { pinch = null; U.store.set('tiles.zoom', zoom); } return; }
      if (drag && drag.pid === e.pointerId) {
        const d = drag; drag = null;
        if (d.started) {
          if (d.tgt && e.type !== 'pointercancel') commitMove(d.src, d.tgt);
          else { api.sfx('click'); }
          dirty = true; return;
        }
        tapPick(d.src, q);
        dirty = true; return;
      }
      if (pan && pan.pid === e.pointerId) {
        const p = pan; pan = null;
        if (!p.moved && e.type !== 'pointercancel') tapTable(q);
      }
    }
    function tapPick(src, q) {
      if (sel) {
        const same = sel.from === src.from && sel.slot === src.slot && sel.si === src.si && sel.idx === src.idx;
        if (same) { sel = null; api.sfx('click'); return; }
        if (src.from === 'rack' && sel.from === 'rack') { sel = src; api.sfx('tick'); api.buzz(6); return; }
        if (src.from === 'rack' && sel.from === 'tb') { const s2 = sel; sel = null; commitMove(s2, { kind: 'rack', slot: src.slot }); return; }
        if (src.from === 'tb' && E) { const s2 = sel; sel = null; const t = targetAt(q.x, q.y, s2); if (t) commitMove(s2, t); return; }
      }
      if (src.from === 'tb' || E || src.from === 'rack') { sel = src; api.sfx('tick'); api.buzz(6); renderHud(); }
    }
    function tapTable(q) {
      if (!sel || !E) { if (sel) { sel = null; dirty = true; } return; }
      const s2 = sel; sel = null;
      const t = targetAt(q.x, q.y, s2);
      if (t) commitMove(s2, t);
    }
    function onWheel(e) {
      if (!G) return;
      e.preventDefault();
      if (e.ctrlKey) setZoom(zoom * (e.deltaY < 0 ? 1.08 : 0.92));
      else { scrollY += e.deltaY; clampScroll(); dirty = true; }
    }
    const cvEl = cv.cv;
    cvEl.addEventListener('pointerdown', onDown);
    cvEl.addEventListener('pointermove', onMove);
    cvEl.addEventListener('pointerup', onUp);
    cvEl.addEventListener('pointercancel', onUp);
    cvEl.addEventListener('wheel', onWheel, { passive: false });

    /* ----- actions ----- */
    function send(a) {
      if (!st || locked()) return;
      waitSeq = st.seq; waitUntil = performance.now() + (api.online ? 3500 : 500);
      api.act(a);
    }
    function doDraw(timeout) {
      if (!E || locked()) return;
      const seat = E.seat;
      if (E.changed) { slots[seat] = E.slots0.slice(); fitSlots(seat); }
      E.tb = st.tb.map((s) => ({ id: ++uid, t: s.split('').map((c) => ({ c, m: 0 })) }));
      recheck(true);
      api.sfx('card'); api.buzz(10);
      send(timeout ? { type: 'draw', to: 1 } : { type: 'draw' });
      renderHud(); dirty = true;
    }
    function doDone() {
      if (!E || locked() || !E.chk.ok) return;
      api.sfx('pop'); api.buzz(18);
      send({ type: 'play', table: E.strs.slice(), used: E.used });
      renderHud(); dirty = true;
    }
    function renderHud() {
      hud.innerHTML = '';
      if (!st || st.end) { zoomBox.style.display = st && st.end ? 'none' : ''; return; }
      zoomBox.style.display = '';
      const up = faceUp();
      const off = locked();
      if (E) {
        const rb = B('↺ 되돌리기', 'ghost', () => { resetEdit(); api.sfx('whoosh'); api.buzz(10); }, { flex: '0 1 96px' });
        rb.disabled = !E.changed || off;
        hud.append(rb);
      }
      if (up) {
        hud.append(B('숫자순', '', () => sortRack(bottomSeat(), 'num'), { flex: '0 1 72px' }), B('색깔순', '', () => sortRack(bottomSeat(), 'col'), { flex: '0 1 72px' }));
      }
      if (E) {
        let main;
        if (!E.used.length) main = B(st.p.length ? '뽑기 · 1장' : '넘기기', 'primary', () => doDraw());
        else { main = B('완료', 'primary', doDone); main.disabled = !E.chk.ok || off; }
        if (off) main.disabled = true;
        hud.append(main);
      }
    }
    function renderRound() {
      if (!st || st.end !== 1) { if (roundEl) { roundEl.remove(); roundEl = null; } return; }
      if (roundEl && roundEl._rn === st.rn) return;
      if (roundEl) roundEl.remove();
      const rr2 = st.rr, sg = (x) => (x > 0 ? '+' + x : x < 0 ? '−' + -x : '0');
      const why = rr2.why === 'out' ? st.nm[rr2.w[0]] + '이(가) 타일을 모두 내려놓았어요' : '더 낼 사람이 없어 남은 합이 가장 적은 쪽이 이겼어요';
      const rows = [];
      for (let i = 0; i < st.n; i++) {
        const pl = api.players[i] || { name: st.nm[i], color: '#888' };
        const rackRow = L.h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '2px', marginTop: '4px' } },
          st.r[i].split('').map((ch) => { const k = ki(ch); return L.h('span', { class: 'mono', style: { fontSize: '11px', fontWeight: 700, padding: '1px 4px', borderRadius: '4px', background: '#f3e8d0', color: isJ(k) ? '#8a5a10' : TC[colOf(k)] }, text: isJ(k) ? '★' : String(numOf(k)) }); }));
        rows.push(L.h('div', { style: { padding: '8px 10px', border: '1px solid var(--line)', borderRadius: '12px', background: 'var(--bg)' } },
          L.h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap', gap: '8px' } },
            L.h('span', { class: 'row', style: { gap: '6px', flexWrap: 'nowrap', minWidth: 0 } }, L.h('span', { class: 'dot', style: { '--c': pl.color } }), L.h('b', { text: pl.name, style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }), rr2.w.includes(i) ? L.h('span', { class: 'tag me', text: '승' }) : null),
            L.h('span', { class: 'mono', style: { whiteSpace: 'nowrap', fontSize: '13px' } }, '벌점 ' + rr2.pen[i] + ' · ', L.h('b', { style: { color: rr2.d[i] >= 0 ? 'var(--ok)' : 'var(--bad)' }, text: sg(rr2.d[i]) }), ' · 누적 ' + sg(st.sc[i]))),
          st.r[i].length ? rackRow : null));
      }
      const canNext = api.mySeats().length > 0;
      const btn = canNext ? L.h('button', { class: 'btn primary block', text: '다음 판 (' + (st.rn + 1) + ' / ' + st.o.rd + ')', onclick() { api.sfx('click'); api.act({ type: 'next' }); } }) : L.h('p', { class: 'muted', style: { margin: 0 }, text: '곧 다음 판이 시작돼요' });
      roundEl = L.h('div', { class: 'overlay tl-round' }, L.h('div', { class: 'sheet' },
        L.h('span', { class: 'label', text: st.rn + '판 결과 · 벌점은 남은 타일 합(조커 30)' }),
        L.h('h2', { text: rr2.w.map((i) => st.nm[i]).join(', ') + ' 승리' }),
        L.h('p', { class: 'muted', style: { margin: 0 }, text: why }),
        rows, btn));
      roundEl._rn = st.rn;
      root.append(roundEl);
    }

    /* ----- update / loop ----- */
    function describe(prev, next) {
      const l = next.last; if (!l) return '';
      const nm = next.nm[l.s];
      if (l.k === 'p') return nm + ' · ' + l.n + '장 냄' + (l.op ? ' (첫 등록!)' : '') + (next.r[l.s].length ? ' · 남은 ' + next.r[l.s].length + '장' : '');
      if (l.k === 'd') return nm + (l.to ? ' · 시간 초과로 1장 뽑음' : ' · 1장 뽑음');
      if (l.k === 'x') return nm + ' · 넘김 (더미 없음)';
      if (l.k === 'r') return '새 판 시작 · ' + nm + ' 먼저';
      return '';
    }
    function frame() {
      const now = performance.now();
      let anim = false;
      if (drag && drag.started && E) {
        const vh0 = G.tY0 + 34, vh1 = G.tY1 - 30;
        if (drag.y < vh0 && drag.y > G.tY0 - 40) { scrollY -= 7; clampScroll(); updateDragTarget(); anim = true; }
        else if (drag.y > vh1 && drag.y < G.rackY - 10) { scrollY += 7; clampScroll(); updateDragTarget(); anim = true; }
      }
      if (st && !st.end && st.o.tm) {
        anim = true;
        if (E && E.deadline && now > E.deadline && timeoutFired !== st.seq && !locked()) {
          timeoutFired = st.seq; drag = null; sel = null;
          api.toast('시간 초과 · 낸 타일을 되돌리고 1장 뽑아요');
          doDraw(true);
        }
      }
      if (now - fresh.t < 2700) anim = true;
      if (Object.keys(glowAt).some((k) => now - glowAt[k] < 4100)) anim = true;
      if (waitSeq >= 0 && st && st.seq === waitSeq && now >= waitUntil) { waitSeq = -1; renderHud(); dirty = true; }
      if (api.online && st && !st.end && !E && now > pollAt) {
        pollAt = now + 300;
        let r = null; try { r = (api.net.remote() || {})[st.t]; } catch (e) { r = null; }
        let pv = null;
        if (r && r.k === st.seq && Array.isArray(r.tb) && r.tb.length <= 60 && r.tb.every((x) => typeof x === 'string' && x.length <= 20 && [...x].every((ch) => ki(ch) >= 0))) pv = r.tb;
        const sig = pv ? pv.join('|') : '';
        if (sig !== previewSig) { previewSig = sig; preview = pv; dirty = true; }
      }
      if (anim || dirty || pinch || drag) { draw(now); dirty = false; }
    }
    const stopLoop = U.loop(frame);

    return {
      update(next, prev) {
        const isNew = !!prev && prev !== next;
        const old = st;
        st = next;
        const newTurn = !old || !prev || prev.seq !== next.seq || prev.end !== next.end || prev.rn !== next.rn;
        if (newTurn) {
          if (prev && prev.rn !== next.rn && next.end === 0) { Object.keys(slots).forEach((k) => delete slots[k]); glowAt = {}; }
          if (E) { E = null; }
          if (api.online && old && old.seq !== next.seq) { try { api.net.publish(null); } catch (e) {} lastPubSig = ''; }
          sel = null; drag = null; waitSeq = -1; preview = null; previewSig = '';
          turnSeen = performance.now();
          if (isNew && prev.seq !== next.seq) {
            lastMsg = describe(prev, next);
            const l = next.last;
            if (l && l.k === 'p' && prev.rn === next.rn) {
              const pool = prev.tb.slice(), idx = new Set();
              next.tb.forEach((t, i) => { const j = pool.indexOf(t); if (j >= 0) pool.splice(j, 1); else idx.add(i); });
              fresh = { t: performance.now(), idx };
              api.sfx('card');
              if (l.op) api.toast(next.nm[l.s] + ' 첫 등록!');
              if (next.r[l.s].length === 1 && !next.end) api.toast(next.nm[l.s] + ' · 1장 남음!');
              setTimeout(() => { if (!TL || E) return; const first = [...idx][0]; const s = TL.sets[first]; if (s) { const vh = G.tY1 - G.tY0; if (s.y < scrollY || s.y + s.h > scrollY + vh) { scrollY = s.y - 12; clampScroll(); dirty = true; } } }, 30);
            } else if (l && (l.k === 'd' || l.k === 'x')) api.sfx(l.k === 'd' ? 'tick' : 'click');
            if (next.end === 1 && prev.end === 0) api.sfx(next.rr.w.some((i) => api.canAct(i)) ? 'win' : 'thud');
          } else if (!prev) lastMsg = describe(null, next);
        }
        geometry();
        const v = vwr();
        if (!E && v >= 0 && !next.end) reconcile(v);
        else if (v >= 0 && next.end) reconcile(v);
        // start editing when it's this viewer's own turn
        if (!E && !next.end && v >= 0 && v === next.t && api.canAct(v)) { newEdit(v); turnSeen = performance.now(); }
        if (E && (E.seat !== v || E.seq !== next.seq)) E = null;
        geometry();
        renderHud(); renderRound();
        dirty = true;
      },
      destroy() {
        stopLoop(); clearTimeout(pubTimer);
        cvEl.removeEventListener('pointerdown', onDown); cvEl.removeEventListener('pointermove', onMove);
        cvEl.removeEventListener('pointerup', onUp); cvEl.removeEventListener('pointercancel', onUp); cvEl.removeEventListener('wheel', onWheel);
        cv.destroy(); hud.remove(); zoomBox.remove(); Object.values(anc).forEach((el) => el.remove()); if (roundEl) roundEl.remove();
        api.setBusy(false);
      },
      _dbg: () => ({ E, G, TL, slots, scrollY, zoom }),
    };
  }

  L.register({
    id: 'tiles', name: '숫자 타일', tag: '타일 맞추기', cat: '보드', hidden: true,
    tint: '#2b3f73',
    icon: '<rect x="5" y="12" width="14" height="20" rx="3" fill="currentColor"/><rect x="21" y="12" width="14" height="20" rx="3" fill="currentColor"/><rect x="37" y="12" width="14" height="20" rx="3" fill="currentColor"/>' +
      '<text x="12" y="27" font-size="12" font-weight="700" text-anchor="middle" fill="#2b3f73" font-family="sans-serif">4</text><text x="28" y="27" font-size="12" font-weight="700" text-anchor="middle" fill="#2b3f73" font-family="sans-serif">5</text><text x="44" y="27" font-size="12" font-weight="700" text-anchor="middle" fill="#2b3f73" font-family="sans-serif">6</text>' +
      '<rect x="4" y="38" width="48" height="7" rx="2" fill="currentColor" opacity=".55"/>',
    blurb: '같은 숫자 다른 색, 또는 같은 색 연속 숫자로 세트를 만들어 내 타일을 모두 내려놓으면 이겨요. 판 위의 세트는 자유롭게 다시 짤 수 있어요.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, aiDelay: 700,
    options: [
      { id: 'rounds', label: '판 수', choices: [{ v: 1, label: '한 판' }, { v: 3, label: '3판 누적' }, { v: 5, label: '5판 누적' }], def: 1 },
      { id: 'timer', label: '제한 시간', choices: [{ v: 0, label: '없음' }, { v: 60, label: '60초' }, { v: 120, label: '120초' }], def: 0 },
    ],
    quick: [
      '내 타일 14개를 「세트」로 만들어 판에 다 내려놓는 사람이 이겨요.',
      '내 차례: 타일을 끌어 판에 세트를 놓고 「완료」, 낼 게 없으면 「뽑기」로 1장 가져와요.',
      '처음 내려놓을 때만 내 타일로 만든 세트 합이 30점 이상이어야 해요. 그 뒤엔 판 위 세트를 자유롭게 다시 짜도 돼요.',
    ],
    rules: [
      { h: '목표', p: [
        '내 받침대의 타일을 모두 판에 내려놓으면 그 판을 이겨요.',
        '타일은 「세트」로만 내려놓을 수 있어요.',
        '「3판·5판 누적」을 고르면 점수를 더해 마지막에 가장 높은 사람이 이겨요.'] },
      { h: '타일', p: [
        '숫자 1~13이 빨강 · 파랑 · 노랑 · 검정 4색으로 2벌씩, 그리고 조커 2개 → 모두 106개예요.',
        '색마다 아래쪽에 작은 표시가 있어요: 빨강 ● · 파랑 ■ · 노랑 ▲ · 검정 ◆. 색을 구별하기 어려워도 알아볼 수 있어요.',
        '6과 9는 밑줄로 구별해요. 조커는 「조커」라고 적힌 별 타일이에요.'] },
      { h: '세트 (2가지)', p: [
        '같은 수: 같은 숫자, 서로 다른 색 3~4개. 예: 빨강7 · 파랑7 · 검정7.',
        '연속: 같은 색, 이어지는 숫자 3개 이상. 예: 파랑 3 · 4 · 5 · 6. 13 다음에 1로 이어지지 않아요.',
        '조커는 어떤 타일이든 대신할 수 있어요. 예: 노랑 8 · 조커 · 노랑 10 → 조커가 노랑 9.',
        '같은 색 같은 숫자 두 개는 「같은 수」 세트에 같이 못 들어가요.'] },
      { h: '준비', p: [
        '모두 14개씩 받고, 남은 타일은 뒷면으로 「더미」가 돼요(위 오른쪽에 남은 수).',
        '먼저 할 사람은 무작위, 그다음 차례대로 돌아가요.'] },
      { h: '첫 등록 (30점)', p: [
        '처음 내려놓을 때는 내 타일만으로 만든 새 세트들의 숫자 합이 30점 이상이어야 해요. 여러 세트를 합쳐도 돼요.',
        '조커는 대신하는 숫자로 세요.',
        '첫 등록 차례에는 판에 있던 세트를 건드리거나 거기에 붙일 수 없어요.',
        '첫 등록 전에는 아래 줄에 「등록 N / 30」으로 지금 점수가 보여요.'] },
      { h: '차례에 할 일', p: [
        '둘 중 하나: ① 내 타일을 1개 이상 판에 놓고 「완료」 ② 낼 수 없으면(또는 내기 싫으면) 「뽑기」로 더미에서 1장.',
        '첫 등록 뒤에는 판 위 타일을 마음대로 다시 짤 수 있어요: 세트에 붙이기, 나누기, 합치기, 다른 세트로 옮기기.',
        '단, 차례가 끝날 때 판의 모든 세트가 올발라야 해요. 판에 있던 타일을 내 받침대로 가져올 수는 없어요.',
        '「↺ 되돌리기」를 누르면 판과 내 타일이 차례 시작 때로 돌아가요.',
        '제한 시간(60초·120초)을 켰다면, 시간이 다 되면 놓은 타일을 되돌리고 1장 뽑아요.'] },
      { h: '특수 규칙: 조커 가져오기', p: [
        '첫 등록을 한 사람은 판의 조커를 가져와 다시 쓸 수 있어요. 방법: 그 조커가 대신하는 타일을 내 받침대에서 놓아 바꾸기.',
        '같은 수 3개짜리 세트의 조커라면, 빠진 색 중 아무거나 놓으면 돼요.',
        '가져온 조커는 받침대로 가져갈 수 없고, 같은 차례에 판의 다른 세트에 다시 놓아야 해요.'] },
      { h: '점수·승리', p: [
        '누가 타일을 모두 내려놓으면 그 판이 끝나요.',
        '더미가 떨어지면 뽑는 대신 넘기고, 모두가 한 바퀴 내리 넘기면 판이 끝나요. 이때는 남은 타일 합이 가장 적은 사람이 이겨요.',
        '벌점 = 남은 타일 숫자의 합(조커는 30점).',
        '진 사람은 (내 벌점 − 이긴 사람 벌점)만큼 잃고, 이긴 사람은 그만큼을 모두 받아요.'] },
      { h: '조작', p: [
        '받침대 타일을 끌어 판의 세트에 놓거나, 빈 곳(＋ 새 세트)에 놓아 새 세트를 시작해요.',
        '끄는 동안 맞는 세트는 초록 점선, 놓일 자리는 막대로 보여요.',
        '끌기가 어려우면 타일을 탭해서 고른 뒤 놓을 곳을 탭해도 돼요.',
        '연속 세트 가운데에 놓으면 끼어들거나, 맞으면 두 세트로 나뉘어요. 가운데 타일을 빼면 세트가 둘로 나뉘어요.',
        '조커 위에 그 조커가 대신하는 타일을 놓으면 조커를 가져와요.',
        '틀린 세트는 빨갛게 표시되고 이유가 아래 줄에 나와요. 「완료」는 판이 올바를 때만 눌려요.',
        '판은 위아래로 밀어 움직이고, 두 손가락이나 −/+ 버튼으로 크기를 바꿔요. 받침대 타일은 끌어서 정리하거나 「숫자순」「색깔순」으로 정렬해요.'] },
      { h: '예시 ① 첫 등록', p: [
        '빨강 10 · 11 · 12 → 33점. 30점 이상이라 통과!',
        '검정5 · 파랑5 · 노랑5(15점) + 빨강 3 · 4 · 5(12점) = 27점 → 3점 모자라요. 세트를 하나 더 만들거나, 기다렸다가 다음 차례에.',
        '파랑 9 · 조커 · 파랑 11 → 조커가 10이라 9 + 10 + 11 = 30점 → 통과!'] },
      { h: '예시 ② 판 다시 짜기 (첫 등록 뒤)', p: [
        '판에 「파랑 4 · 5 · 6 · 7」이 있고, 내 손에는 빨강7 · 노랑7과 파랑 8이 있어요.',
        '→ 판의 파랑 7을 끝에서 떼어 와요. 남은 「파랑 4 · 5 · 6」도 3개라 올발라요.',
        '→ 떼어 온 파랑7 + 내 빨강7 · 노랑7 = 새 「같은 수」 세트!',
        '→ 파랑 8은 못 붙여요(7이 빠져서 이어지지 않아요). 이번 차례엔 2개를 내려놓았어요.',
        '주의: 가운데 타일을 빼서 2개짜리 세트가 남으면 틀린 판이라 「완료」가 안 눌려요.'] },
      { h: '예시 ③ 점수', p: [
        '내가 타일을 다 내렸어요. A는 남은 합 12점, B는 조커 + 5 = 35점.',
        '→ A −12, B −35, 나 +47.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움(내 패로 새 세트만 냄)·보통·어려움(판 전체를 다시 짜 보고 조커를 아껴 둠)으로 고를 수 있어요.'] },
    ],
    tutorial: [
      { sel: '.tl-rack', text: '아래 나무 받침대가 내 타일 14개예요. 숫자 1~13, 4색(빨강 ● · 파랑 ■ · 노랑 ▲ · 검정 ◆), 그리고 조커. 이걸 모두 판에 내려놓으면 이겨요!' },
      { sel: '.tl-table', text: '가운데 초록 판에 세트를 놓아요. 세트는 두 가지: 같은 숫자 · 다른 색 3~4개(빨강7 파랑7 검정7), 또는 같은 색 연속 숫자 3개 이상(파랑 3·4·5).' },
      { sel: '.tl-status', text: '첫 등록: 처음엔 내 타일로 만든 세트 합이 30점 이상이어야 해요. 놓는 동안 이 줄에 「등록 N / 30」이 보여요. 예: 빨강 10·11·12 = 33점 → 통과!' },
      { sel: '.tl-rack', text: '타일을 끌어서 판에 놓아요(빈 곳 = 새 세트). 끌기가 어려우면 타일을 탭하고, 놓을 곳을 탭해도 돼요.' },
      { sel: '.tl-bar', text: '다 놓았으면 「완료」, 낼 게 없으면 「뽑기 · 1장」. 실수했으면 「↺ 되돌리기」. 「숫자순」「색깔순」으로 받침대를 정리하면 세트가 잘 보여요.' },
      { sel: '.tl-table', text: '첫 등록 뒤에는 판 위 세트를 마음대로 다시 짤 수 있어요(붙이기 · 나누기 · 옮기기). 차례가 끝날 때 모든 세트가 올바르기만 하면 돼요. 틀리면 빨갛게 보여요.' },
      { sel: '.tl-top', text: '위에는 사람마다 남은 타일 수와 첫 등록 여부, 오른쪽엔 더미 수가 보여요. 가장 먼저 다 내려놓으세요!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { ALPH, ki, kc, analyze, arrange, jokerReps, jokerRule, checkPlay, bestMelds, planOpened, rebuild, cntOf, strK, kStr, AI, JK, kindOf },
  });
})();
