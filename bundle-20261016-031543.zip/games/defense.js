/* 성 지키기 협동 — cooperative realtime tower defense (1–4).
   Monsters walk the road toward the castle in waves; everyone builds, upgrades and sells towers on the stone pads with
   their own gold (every kill pays all players the same share). Survive every wave to win; the castle falling loses.
   Host-authoritative: the host / local phone runs the world in fixed 50 ms steps (enemies, towers, shots, AI helpers);
   guests send queued, acked commands (build / upgrade / sell / next wave / speed) and receive ~10 Hz snapshots of
   towers and enemies, moving the enemies along the road locally in between. One person per phone: locally you play
   seat 0 with AI helpers in the other seats; friends play through online / LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const WAVE_GOLD = 15;
  const GW = 9, GH = 13, STEP = 0.05, MAXS = 15, PREP = 30, GAP = 20, HP0 = 20, AI_WAIT = 5;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const fin = (v) => typeof v === 'number' && isFinite(v);

  /* maps: routes as waypoints in grid cells (col,row); the first point sits just outside the board, the last one is the
     castle. Several routes = enemies take them in turn. Build pads are generated from the road (same on every device). */
  const MAPS = [
    { id: 'forest', name: '숲속 굽이길', sub: '한 줄로 굽이굽이 — 처음 하기 좋아요',
      R: [[[1, -1], [1, 2], [7, 2], [7, 6], [1, 6], [1, 10], [4, 10], [4, 12]]] },
    { id: 'twin', name: '두 갈래 길', sub: '양쪽 동굴에서 번갈아 나와 가운데서 만나요',
      R: [[[1, -1], [1, 4], [4, 4], [4, 7], [7, 7], [7, 10], [4, 10], [4, 12]], [[7, -1], [7, 4], [4, 4], [4, 7], [7, 7], [7, 10], [4, 10], [4, 12]]] },
    { id: 'snail', name: '달팽이 성', sub: '성이 한가운데! 길이 성을 빙 감아 돌아요',
      R: [[[-1, 1], [7, 1], [7, 11], [1, 11], [1, 4], [4, 4], [4, 7]]] },
    { id: 'fork', name: '갈림길 숲', sub: '길이 둘로 갈렸다 다시 만나요. 가운데 자리가 명당',
      R: [[[4, -1], [4, 1], [2, 1], [2, 6], [4, 6], [4, 8], [1, 8], [1, 11], [4, 11], [4, 12]], [[4, -1], [4, 1], [6, 1], [6, 6], [4, 6], [4, 8], [1, 8], [1, 11], [4, 11], [4, 12]]] },
    { id: 'zig', name: '지그재그 협곡', sub: '길이 길어요. 길 사이 자리는 두 줄을 함께 쏴요',
      R: [[[-1, 1], [7, 1], [7, 4], [1, 4], [1, 7], [7, 7], [7, 10], [4, 10], [4, 12]]] },
    { id: 'pass', name: '좁은 산길', sub: '길이 짧고 자리가 적어요 — 어려운 맵',
      R: [[[4, -1], [4, 3], [2, 3], [2, 6], [6, 6], [6, 9], [4, 9], [4, 12]]], maxs: 10 },
  ];
  function buildMap(M) {
    if (M.routes) return M;
    M.routes = M.R.map((wp) => {
      const p = [];
      for (const [c, r] of wp) p.push(c + 0.5, r + 0.5);
      const cum = [0];
      for (let i = 2; i < p.length; i += 2) cum.push(cum[cum.length - 1] + Math.hypot(p[i] - p[i - 2], p[i + 1] - p[i - 1]));
      return { p, c: cum, L: cum[cum.length - 1] };
    });
    const last = M.R[0][M.R[0].length - 1];
    M.castle = { c: last[0], r: last[1], x: last[0] + 0.5, y: last[1] + 0.5 };
    // road cells
    const road = new Uint8Array(GW * GH);
    for (const wp of M.R) for (let i = 1; i < wp.length; i++) {
      const [c0, r0] = wp[i - 1], [c1, r1] = wp[i], n = Math.max(Math.abs(c1 - c0), Math.abs(r1 - r0));
      for (let k = 0; k <= n; k++) {
        const c = Math.round(c0 + (c1 - c0) * k / n), r = Math.round(r0 + (r1 - r0) * k / n);
        if (c >= 0 && c < GW && r >= 0 && r < GH) road[r * GW + c] = 1;
      }
    }
    M.road = road;
    // samples along the road for coverage (weight = share of enemies passing × length)
    const smp = [];
    for (const R of M.routes) for (let d = 0.125; d < R.L; d += 0.25) {
      const o = posAt(R, d, {});
      if (o.y < 0 || o.x < 0 || o.x > GW || o.y > GH) continue;
      smp.push(o.x, o.y, 0.25 / M.routes.length, d / R.L);
    }
    M.smp = smp;
    M.cc = {};
    // build pads: cells near the road (≤ 2 cells), best coverage first, never touching each other
    const cand = [];
    for (let r = 0; r < GH; r++) for (let c = 0; c < GW; c++) {
      if (road[r * GW + c]) continue;
      if (Math.max(Math.abs(c - M.castle.c), Math.abs(r - M.castle.r)) <= 1) continue;
      if (M.R.some((wp) => Math.max(Math.abs(c - clamp(wp[0][0], 0, GW - 1)), Math.abs(r - clamp(wp[0][1], 0, GH - 1))) <= 1)) continue; // cave mouth
      let adj = false;
      for (let dr = -2; dr <= 2 && !adj; dr++) for (let dc = -2; dc <= 2; dc++) {
        const cc = c + dc, rr = r + dr;
        if (cc >= 0 && cc < GW && rr >= 0 && rr < GH && road[rr * GW + cc]) { adj = true; break; }
      }
      if (!adj) continue;
      cand.push({ c, r, x: c + 0.5, y: r + 0.5, sc: covRaw(M, c + 0.5, r + 0.5, 2.6) });
    }
    cand.sort((a, b) => b.sc - a.sc || (a.r * GW + a.c) - (b.r * GW + b.c));
    const S = [];
    for (const q of cand) {
      if (S.length >= (M.maxs || MAXS)) break;
      if (S.some((s) => Math.max(Math.abs(s.c - q.c), Math.abs(s.r - q.r)) < 2)) continue;
      S.push({ c: q.c, r: q.r, x: q.x, y: q.y });
    }
    S.sort((a, b) => a.r - b.r || a.c - b.c);
    M.S = S;
    return M;
  }
  function covRaw(M, x, y, rg) {
    let s = 0;
    const p = M.smp, r2 = rg * rg;
    for (let i = 0; i < p.length; i += 4) { const dx = p[i] - x, dy = p[i + 1] - y; if (dx * dx + dy * dy <= r2) s += p[i + 2]; }
    return s;
  }
  function cov(M, si, rg) {
    const k = si * 100 + Math.round(rg * 10);
    if (M.cc[k] == null) M.cc[k] = covRaw(M, M.S[si].x, M.S[si].y, rg);
    return M.cc[k];
  }
  function posAt(R, d, o) {
    const p = R.p, c = R.c;
    d = clamp(d, 0, R.L);
    let i = 1;
    while (i < c.length - 1 && c[i] < d) i++;
    const seg = c[i] - c[i - 1] || 1, u = (d - c[i - 1]) / seg;
    const x0 = p[2 * i - 2], y0 = p[2 * i - 1], x1 = p[2 * i], y1 = p[2 * i + 1];
    const l = Math.hypot(x1 - x0, y1 - y0) || 1;
    o.ux = (x1 - x0) / l; o.uy = (y1 - y0) / l;
    o.x = x0 + (x1 - x0) * u; o.y = y0 + (y1 - y0) * u;
    return o;
  }
  const laneOff = (id) => (((id * 37) % 11) - 5) / 5 * 0.17;

  /* towers: per level cost (build, then upgrades), damage, shots/s, range (cells). mag = magic (ignores armour),
     air = can hit flyers, spl = splash radius, fl = flight time, slow/sd = slow factor & seconds, pd/pt = poison dps & seconds,
     ch = chain jumps. */
  const TT = [
    { id: 'arch', nm: '궁수 탑', sn: '궁수', cost: [60, 70, 110], dmg: [9, 16, 26], rate: [1.6, 1.9, 2.3], rg: [2.6, 2.9, 3.2], air: 1, fl: 0.2,
      d: '빠른 화살. 하늘의 박쥐·용도 쏴요', tip: '싸고 빨라요 · 공중 ○' },
    { id: 'cann', nm: '대포', sn: '대포', cost: [100, 110, 160], dmg: [28, 50, 85], rate: [0.6, 0.62, 0.66], rg: [2.4, 2.6, 2.8], spl: [0.9, 1.0, 1.15], fl: 0.45,
      d: '터지는 포탄. 몰려 있는 적에게 강해요. 하늘은 못 쏴요', tip: '범위 공격 · 공중 ✕' },
    { id: 'ice', nm: '얼음 마법탑', sn: '얼음', cost: [80, 90, 130], dmg: [5, 9, 14], rate: [1.0, 1.1, 1.2], rg: [2.4, 2.6, 2.8], mag: 1, air: 1, fl: 0.25,
      slow: [0.62, 0.52, 0.42], sd: [1.6, 2.0, 2.4], spl: [0, 0.6, 0.8], d: '맞은 적이 느려져요. 다른 탑과 함께 쓰면 좋아요', tip: '느리게 · 공중 ○' },
    { id: 'pois', nm: '독 탑', sn: '독', cost: [80, 90, 130], dmg: [0, 0, 0], rate: [0.9, 1.0, 1.1], rg: [2.5, 2.7, 2.9], mag: 1, air: 1, fl: 0.3,
      pd: [11, 19, 30], pt: [3, 3.5, 4], d: '독이 몇 초 동안 계속 깎아요. 갑옷을 무시해요. 트롤은 독에 걸리면 회복 못 해요', tip: '지속 피해 · 갑옷 무시' },
    { id: 'cata', nm: '투석기', sn: '투석기', cost: [120, 130, 180], dmg: [55, 95, 150], rate: [0.32, 0.34, 0.36], rg: [3.8, 4.1, 4.4], spl: [1.25, 1.35, 1.5], fl: 0.9, mn: 1,
      d: '아주 멀리 큰 돌을 던져요. 느리지만 넓게 쾅! 바로 옆과 하늘은 못 맞혀요', tip: '먼 거리 · 넓은 범위' },
    { id: 'bolt', nm: '번개탑', sn: '번개', cost: [110, 120, 170], dmg: [17, 29, 46], rate: [0.75, 0.8, 0.9], rg: [2.5, 2.7, 2.9], mag: 1, air: 1, fl: 0, ch: [2, 3, 4],
      d: '번개가 근처 적에게 튀어요(점점 약해짐). 갑옷을 무시해요', tip: '연쇄 · 갑옷 무시 · 공중 ○' },
  ];
  const spentOf = (ty, lv) => { let s = 0; for (let i = 0; i < lv; i++) s += TT[ty].cost[i]; return s; };
  const refundOf = (ty, lv) => Math.floor(spentOf(ty, lv) * 0.7);

  /* enemies: hp, speed (cells/s), ar = armour (cuts arrows/cannon/stones), mr = magic resist, dmg = castle damage,
     gold = bounty for the whole team, rs = draw radius (cells) */
  const ET = [
    { id: 'gob', nm: '고블린', hp: 38, sp: 1.0, dmg: 1, gold: 6, rs: 0.22 },
    { id: 'wolf', nm: '늑대', hp: 28, sp: 1.75, dmg: 1, gold: 6, rs: 0.24 },
    { id: 'orc', nm: '방패 오크', hp: 95, sp: 0.8, ar: 0.5, dmg: 2, gold: 12, rs: 0.28 },
    { id: 'bat', nm: '박쥐', hp: 32, sp: 1.35, air: 1, dmg: 1, gold: 7, rs: 0.22 },
    { id: 'troll', nm: '트롤', hp: 320, sp: 0.6, ar: 0.2, dmg: 3, gold: 26, rs: 0.36, regen: 0.015 },
    { id: 'sham', nm: '주술사', hp: 60, sp: 0.9, mr: 0.3, dmg: 1, gold: 12, rs: 0.24, heal: 1 },
    { id: 'ogre', nm: '오우거 왕', hp: 1000, sp: 0.5, ar: 0.4, dmg: 8, gold: 120, rs: 0.46, boss: 1 },
    { id: 'drag', nm: '붉은 용', hp: 1300, sp: 0.62, air: 1, mr: 0.2, dmg: 8, gold: 150, rs: 0.5, boss: 1 },
    { id: 'maou', nm: '어둠의 마왕', hp: 1800, sp: 0.42, ar: 0.3, mr: 0.3, dmg: 20, gold: 0, rs: 0.5, boss: 1, summon: 1 },
  ];
  /* waves: groups [enemy type, count, gap seconds]; 'B' = this wave's boss */
  const WAVES = [
    [[0, 8, 1.1]],
    [[0, 8, 1.0], [1, 5, 0.8]],
    [[0, 8, 0.9], [2, 4, 1.6], [1, 5, 0.7]],
    [[3, 6, 0.9], [0, 10, 0.8]],
    [[0, 10, 0.8], [2, 4, 1.4], ['B']],
    [[1, 12, 0.6], [2, 5, 1.3], [5, 2, 2]],
    [[4, 2, 3], [0, 12, 0.7], [3, 6, 0.8]],
    [[2, 10, 1.1], [5, 3, 1.5], [1, 10, 0.55]],
    [[3, 12, 0.6], [4, 3, 2.5], [0, 12, 0.6]],
    [[0, 12, 0.6], [3, 8, 0.7], ['B']],
    [[1, 20, 0.45], [4, 3, 2.2], [5, 3, 1.5]],
    [[2, 14, 0.9], [3, 10, 0.6], [5, 4, 1.3]],
    [[4, 6, 1.8], [1, 16, 0.45], [3, 8, 0.6]],
    [[2, 16, 0.8], [4, 5, 1.8], [3, 14, 0.5], [5, 4, 1.2]],
    [[4, 4, 2], [2, 10, 0.8], [3, 10, 0.6], ['B']],
  ];
  const DIFF = { 1: { hp: 0.7, sp: 0.95, g0: 300 }, 2: { hp: 1, sp: 1, g0: 260 }, 3: { hp: 1.22, sp: 1.05, g0: 240 } };
  const hpK = (w) => 1 + 0.11 * (w - 1) + 0.0075 * (w - 1) * (w - 1);
  const bossOf = (w, nw) => (w === nw ? 8 : w === 10 ? 7 : 6);
  function waveGroups(w, nw) {
    const src = w === nw && nw === 10 ? [[4, 2, 2.5], [2, 6, 1], [3, 6, 0.7], ['B']] : WAVES[w - 1] || WAVES[WAVES.length - 1];
    return src.map((g) => (g[0] === 'B' ? [bossOf(w, nw), 1, 0, 1] : g));
  }
  /* what the next wave holds: [[type, count], ...] (merged), for the info line */
  function waveInfo(w, nw) {
    const out = [];
    for (const g of waveGroups(w, nw)) { const f = out.find((x) => x[0] === g[0]); if (f) f[1] += g[1]; else out.push([g[0], g[1]]); }
    return out;
  }

  function rng(W) { W.sd = (Math.imul(W.sd, 1664525) + 1013904223) >>> 0; return W.sd / 4294967296; }
  function newWorld(mp, n, df, nw, seed) {
    mp = clamp(mp | 0, 0, MAPS.length - 1);
    const M = buildMap(MAPS[mp]);
    df = DIFF[df] ? df : 2;
    nw = nw === 15 ? 15 : 10;
    n = clamp(n | 0, 1, 4);
    return {
      mp, M, n, df, nw, t: 0, w: 0, cd: PREP, q: [], qt: 0, E: [], H: [], T: new Array(M.S.length).fill(null),
      g: new Array(n).fill(DIFF[df].g0 * TEAM[n] / n), hp: HP0, eid: 0, sp: 1, end: 0, k: new Array(n).fill(0), bt: new Array(n).fill(0),
      sd: (seed >>> 0) || 1, spn: 0, lk: 0, tmp: {},
    };
  }
  function startWave(W) {
    W.w++;
    addGold(W, WAVE_GOLD + 5 * W.w);
    W.qt = 0; W.cd = -1;
    const q = [];
    let t = 0;
    for (const g of waveGroups(W.w, W.nw)) {
      if (g[3]) { t += 2; q.push([t, g[0]]); t += 2; continue; }
      for (let i = 0; i < g[1]; i++) { q.push([t, g[0]]); t += g[2]; }
      t += 1.5;
    }
    W.q = q;
  }
  const TEAM = [1, 1, 1.06, 1.1, 1.14]; // more players → a little more gold in total (split gold is harder to pool)
  function addGold(W, total) { for (let s = 0; s < W.n; s++) W.g[s] += total * TEAM[W.n] / W.n; }
  function spawn(W, ty, r, d) {
    const T = ET[ty], D = DIFF[W.df];
    const hp = Math.round(T.hp * hpK(W.w) * D.hp);
    W.eid = (W.eid % 9999) + 1;
    const e = { id: W.eid, t: ty, r: r == null ? W.spn++ % W.M.routes.length : r, d: d || 0, hp, mh: hp, sl: 1, slT: 0, ps: 0, psT: 0, po: -1, pi: -1, lh: -1, x: 0, y: 0, sm: 4, ht: 0 };
    place(W, e);
    W.E.push(e);
    return e;
  }
  function place(W, e) {
    const R = W.M.routes[e.r], o = posAt(R, e.d, W.tmp), off = laneOff(e.id);
    e.x = o.x - o.uy * off; e.y = o.y + o.ux * off;
  }
  const speedOf = (W, e) => ET[e.t].sp * DIFF[W.df].sp * (e.slT > 0 ? e.sl : 1);
  const remOf = (W, e) => W.M.routes[e.r].L - e.d;
  function hurt(W, e, amt, mag, seat, ti) {
    const T = ET[e.t];
    const k = 1 - ((mag ? T.mr : T.ar) || 0), v = Math.min(Math.max(0, e.hp), amt * k);
    e.hp -= amt * k;
    if (seat >= 0) e.lh = seat;
    if (W.dd && ti >= 0 && W.T[ti]) W.dd[W.T[ti].ty] += v;
  }
  /* commands: 1 build(spot, type) · 2 upgrade(spot) · 3 sell(spot) · 4 call the next wave now · 5 speed(1|2) */
  function canDo(W, seat, op, s, a) {
    if (W.end || !(seat >= 0 && seat < W.n)) return '';
    if (op === 4) return W.cd > 0 && W.w < W.nw ? 'ok' : '';
    if (op === 5) return 'ok';
    if (!(s >= 0 && s < W.T.length)) return '';
    const T = W.T[s];
    if (op === 1) {
      if (T || !(a >= 0 && a < TT.length)) return '';
      return W.g[seat] + 1e-6 >= TT[a].cost[0] ? 'ok' : 'gold';
    }
    if (!T) return '';
    if (op === 2) { if (T.lv >= 3) return 'max'; return W.g[seat] + 1e-6 >= TT[T.ty].cost[T.lv] ? 'ok' : 'gold'; }
    if (op === 3) return T.o === seat ? 'ok' : 'owner';
    return '';
  }
  function cmd(W, seat, op, s, a) {
    if (canDo(W, seat, op, s, a) !== 'ok') return false;
    if (op === 1) { W.g[seat] -= TT[a].cost[0]; W.T[s] = { ty: a, lv: 1, o: seat, cd: 0.3, fc: 0, tg: 0, k: 0 }; W.bt[seat]++; return true; }
    const T = W.T[s];
    if (op === 2) { W.g[seat] -= TT[T.ty].cost[T.lv]; T.lv++; return true; }
    if (op === 3) { W.g[seat] += refundOf(T.ty, T.lv); W.T[s] = null; return true; }
    if (op === 4) { addGold(W, earlyBonus(W)); startWave(W); return true; }
    if (op === 5) { W.sp = a === 2 ? 2 : 1; return true; }
    return false;
  }
  const earlyBonus = (W) => (W.cd > 0 ? Math.round(W.cd * (1 + 0.1 * W.w)) : 0);

  function target(W, ti) {
    const S = W.M.S[ti], T = W.T[ti], D = TT[T.ty], rg = D.rg[T.lv - 1], r2 = rg * rg, mn = (D.mn || 0) * (D.mn || 0);
    let best = null, br = 1e9;
    for (const e of W.E) {
      if (e.hp <= 0 || e.d < 0.3) continue;
      if (ET[e.t].air && !D.air) continue;
      const dx = e.x - S.x, dy = e.y - S.y, d2 = dx * dx + dy * dy;
      if (d2 > r2 || d2 < mn) continue;
      const rem = remOf(W, e);
      if (rem < br) { br = rem; best = e; }
    }
    return best;
  }
  function stepWorld(W, dt, hooks) {
    if (W.end) return;
    W.t += dt;
    // waves
    if (W.cd > 0) { W.cd -= dt; if (W.cd <= 0) startWave(W); }
    else if (W.q.length) {
      W.qt += dt;
      while (W.q.length && W.q[0][0] <= W.qt) { const q = W.q.shift(); spawn(W, q[1]); }
      if (!W.q.length && W.w < W.nw) W.cd = GAP;
    }
    // enemies
    for (let i = W.E.length - 1; i >= 0; i--) {
      const e = W.E[i], T = ET[e.t];
      if (e.psT > 0) { if (W.dd && W.T[e.pi]) W.dd[3] += Math.min(Math.max(0, e.hp), e.ps * dt); e.hp -= e.ps * dt; e.psT -= dt; if (e.po >= 0) e.lh = e.po; }
      else if (T.regen && e.hp < e.mh) e.hp = Math.min(e.mh, e.hp + e.mh * T.regen * dt);
      if (e.slT > 0) e.slT -= dt;
      if (T.heal) {
        e.ht += dt;
        if (e.ht >= 2) {
          e.ht = 0;
          for (const o of W.E) if (o !== e && o.hp > 0 && !ET[o.t].boss && Math.abs(o.x - e.x) < 1.6 && Math.abs(o.y - e.y) < 1.6) o.hp = Math.min(o.mh, o.hp + o.mh * 0.1);
          if (hooks && hooks.heal) hooks.heal(e);
        }
      }
      if (T.summon) {
        e.sm -= dt;
        if (e.sm <= 0) { e.sm = 6; for (let k = 0; k < 2; k++) spawn(W, 0, e.r, Math.max(0, e.d - 0.4 - k * 0.4)); }
      }
      if (e.hp <= 0) continue;
      e.d += speedOf(W, e) * dt;
      if (e.d >= W.M.routes[e.r].L) {
        W.hp = Math.max(0, W.hp - T.dmg); W.lk++;
        W.E.splice(i, 1);
        if (hooks && hooks.leak) hooks.leak(e);
        continue;
      }
      place(W, e);
    }
    // towers
    for (let ti = 0; ti < W.T.length; ti++) {
      const T = W.T[ti];
      if (!T) continue;
      T.cd -= dt;
      if (T.cd > 0) continue;
      const e = target(W, ti);
      if (!e) { T.cd = 0; continue; }
      const D = TT[T.ty], lv = T.lv - 1;
      T.cd += 1 / D.rate[lv];
      if (T.cd < 0) T.cd = 0;
      T.fc = (T.fc + 1) % 1000; T.tg = e.id;
      if (D.ch) { // lightning: instant chain
        const hit = [e];
        let cur = e, dmg = D.dmg[lv];
        hurt(W, e, dmg, 1, T.o, ti);
        for (let j = 0; j < D.ch[lv]; j++) {
          let nx = null, nd = 1.7 * 1.7;
          for (const o of W.E) {
            if (o.hp <= 0 || hit.includes(o)) continue;
            const dx = o.x - cur.x, dy = o.y - cur.y, d2 = dx * dx + dy * dy;
            if (d2 < nd) { nd = d2; nx = o; }
          }
          if (!nx) break;
          dmg *= 0.75; hurt(W, nx, dmg, 1, T.o, ti); hit.push(nx); cur = nx;
        }
        if (hooks && hooks.chain) hooks.chain(ti, hit);
        continue;
      }
      let lx = e.x, ly = e.y;
      if (D.spl) { // aim where the enemy will be when the shot lands
        const R = W.M.routes[e.r], o = posAt(R, e.d + speedOf(W, e) * D.fl, W.tmp), off = laneOff(e.id);
        lx = o.x - o.uy * off; ly = o.y + o.ux * off;
      }
      W.H.push({ t: D.fl, ty: T.ty, lv, o: T.o, tg: e.id, x: lx, y: ly, ti });
    }
    // shots landing
    for (let i = W.H.length - 1; i >= 0; i--) {
      const h = W.H[i];
      h.t -= dt;
      if (h.t > 0) continue;
      W.H.splice(i, 1);
      const D = TT[h.ty], lv = h.lv;
      const tg = W.E.find((e) => e.id === h.tg && e.hp > 0);
      if (h.ty === 1 || h.ty === 4) { // splash (ground only)
        const r2 = D.spl[lv] * D.spl[lv];
        for (const e of W.E) {
          if (e.hp <= 0 || ET[e.t].air) continue;
          const dx = e.x - h.x, dy = e.y - h.y;
          if (dx * dx + dy * dy <= r2) hurt(W, e, D.dmg[lv], 0, h.o, h.ti);
        }
        if (hooks && hooks.boom) hooks.boom(h);
        continue;
      }
      if (h.ty === 2) {
        const list = [];
        if (D.spl[lv] && tg) { const r2 = D.spl[lv] * D.spl[lv]; for (const e of W.E) if (e.hp > 0 && (e.x - tg.x) ** 2 + (e.y - tg.y) ** 2 <= r2) list.push(e); }
        else if (tg) list.push(tg);
        for (const e of list) {
          hurt(W, e, D.dmg[lv], 1, h.o, h.ti);
          const f = ET[e.t].boss ? (1 + D.slow[lv]) / 2 : D.slow[lv];
          if (e.slT <= 0 || f <= e.sl) e.sl = f;
          e.slT = Math.max(e.slT, D.sd[lv]);
        }
        continue;
      }
      if (!tg) continue;
      if (h.ty === 3) { if (D.pd[lv] >= tg.ps || tg.psT <= 0) { tg.ps = D.pd[lv]; tg.po = h.o; tg.pi = h.ti; } tg.psT = Math.max(tg.psT, D.pt[lv]); tg.lh = h.o; continue; }
      hurt(W, tg, D.dmg[lv], 0, h.o, h.ti);
    }
    // deaths
    for (let i = W.E.length - 1; i >= 0; i--) {
      const e = W.E[i];
      if (e.hp > 0) continue;
      W.E.splice(i, 1);
      addGold(W, ET[e.t].gold);
      if (e.lh >= 0 && e.lh < W.n) W.k[e.lh]++;
      if (hooks && hooks.kill) hooks.kill(e);
    }
    if (W.hp <= 0) W.end = -1;
    else if (W.w >= W.nw && !W.q.length && !W.E.length) W.end = 1;
  }
  const starsOf = (hp) => (hp >= 18 ? 3 : hp >= 10 ? 2 : hp > 0 ? 1 : 0);

  /* ----- AI helpers: pick the best tower / upgrade per gold for the coming waves ----- */
  const AIC = {
    1: { think: [5, 8], noise: 0.9, look: 0, keep: 0, alt: 0, upg: 0.6, spot: 1 },
    2: { think: [2, 3], noise: 0.25, look: 1, keep: 0.4, alt: 0.6, upg: 1, spot: 0 },
    3: { think: [0.8, 1.3], noise: 0.04, look: 2, keep: 1, alt: 0.8, upg: 1, spot: 0 },
  };
  const VK = [2.7, 2.3, 1.6, 1.8, 1.35, 2.6]; // measured damage per gold per covered road (all-tower average)
  function threat(W, look) { // share of hp that flies / wears armour in the next waves
    let air = 0, arm = 0, tot = 0;
    for (let w = W.w + (W.cd > 0 ? 1 : 0); w <= Math.min(W.nw, W.w + 1 + look); w++) {
      for (const g of waveGroups(w, W.nw)) {
        const T = ET[g[0]], h = T.hp * g[1] * hpK(w);
        tot += h; if (T.air) air += h; if (T.ar) arm += h * T.ar;
      }
    }
    return tot ? { air: air / tot, arm: arm / tot } : { air: 0, arm: 0 };
  }
  /* rough worth of a tower: measured efficiency × gold in it × road it covers, tuned for what is coming */
  function towerVal(M, s, ty, lv, th, look, cnt) {
    const D = TT[ty];
    let k = VK[ty];
    if (ty === 2 && cnt[2] < 2) k = 2.5;
    if (look) k *= Math.pow(0.86, Math.max(0, cnt[ty] - 1)); // a mix of towers beats one kind
    if (look) {
      if (!D.air) k *= (1 - th.air) / 0.85;
      if (!D.mag) k *= (1 - 0.8 * th.arm) / 0.88;
    }
    return k * spentOf(ty, lv) * cov(M, s, D.rg[lv - 1]);
  }
  function aiThink(W, seat, mem, lv) {
    const C = AIC[lv] || AIC[2];
    if (mem.t == null) mem.t = AI_WAIT + rng(W) * 2;
    mem.t -= STEP;
    if (mem.t > 0 || W.end) return null;
    mem.t = C.think[0] + rng(W) * (C.think[1] - C.think[0]);
    const g = W.g[seat], M = W.M, th = threat(W, C.look);
    const opts = [];
    const cnt = [0, 0, 0, 0, 0, 0];
    for (const t of W.T) if (t) cnt[t.ty]++;
    const nz = () => 1 + C.noise * (rng(W) - 0.5) * 2;
    for (let s = 0; s < W.T.length; s++) {
      const T = W.T[s];
      if (!T) {
        for (let ty = 0; ty < TT.length; ty++) opts.push({ op: 1, s, a: ty, c: TT[ty].cost[0], v: towerVal(M, s, ty, 1, th, C.look, cnt) * nz() });
      } else if (T.lv < 3) { // upgrades (own towers first; helpers sometimes upgrade a friend's)
        const dv = towerVal(M, s, T.ty, T.lv + 1, th, C.look, cnt) - towerVal(M, s, T.ty, T.lv, th, C.look, cnt);
        opts.push({ op: 2, s, a: 0, c: TT[T.ty].cost[T.lv], v: dv * C.upg * (T.o === seat ? 1 : 0.85) * nz() });
      }
    }
    if (!opts.length) return null;
    for (const o of opts) o.e = o.v / o.c;
    opts.sort((a, b) => b.e - a.e);
    if (C.spot) { // 쉬움: grabs whatever it can pay for, a bit at random
      const ok = opts.filter((o) => o.c <= g + 1e-6);
      if (!ok.length) return null;
      const o = ok[Math.floor(rng(W) * Math.min(ok.length, 8))];
      return [o.op, o.s, o.a];
    }
    const best = opts[0];
    if (best.c <= g + 1e-6) return [best.op, best.s, best.a];
    // the best is too dear: save up only when it is close and something nearly as good isn't affordable now
    const alt = opts.find((o) => o.c <= g + 1e-6 && o.e >= best.e * C.alt);
    if (alt) return [alt.op, alt.s, alt.a];
    if (best.c - g <= 45 && rng(W) < C.keep) return null;
    const any = opts.find((o) => o.c <= g + 1e-6 && o.e >= best.e * 0.45);
    return any ? [any.op, any.s, any.a] : null;
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    let mp = o.map == null ? -1 : +o.map;
    const rnd = !(mp >= 0 && mp < MAPS.length);
    if (rnd) mp = Math.floor(Math.random() * MAPS.length);
    const df = [1, 2, 3].includes(+o.diff) ? +o.diff : 2;
    const nw = +o.waves === 15 ? 15 : 10;
    return {
      rid: 1 + U.rand(99999), n: clamp(players.length, 1, 4), nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      mp, rnd: rnd ? 1 : 0, df, nw, ph: 'play', res: null,
    };
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !s.res) return null;
    const r = s.res, nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const all = Array.from({ length: s.n }, (_, i) => i);
    const head = (MAPS[s.mp] ? MAPS[s.mp].name : '') + ' · ' + ['', '쉬움', '보통', '어려움'][s.df] + ' · ' + s.nw + '웨이브';
    const lines = all.map((i) => nm(i) + '  탑 ' + (r.b[i] | 0) + '개 · 처치 ' + (r.k[i] | 0));
    if (r.win) {
      const st = starsOf(r.hp);
      return { winners: all, title: '성을 지켰어요! ' + '★'.repeat(st) + '☆'.repeat(3 - st),
        text: head + '\n성 체력 ' + r.hp + '/' + HP0 + ' · 별 ' + st + '개 (★★★ 18 이상 · ★★ 10 이상)\n' + (s.n > 1 ? lines.join('\n') : lines[0].replace(/^.*?  /, '')) };
    }
    return { winners: [], title: '성이 무너졌어요…', text: head + '\n웨이브 ' + r.w + '/' + s.nw + '에서 무너졌어요\n' + (s.n > 1 ? lines.join('\n') : lines[0].replace(/^.*?  /, '')) };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const TAU = Math.PI * 2;
  const ICON = [
    '<path d="M4 20L17 7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M19 5l-6 1.2 4.8 4.8z" fill="currentColor"/><path d="M4 20l1-4M4 20l4-1M6.5 17.5l1-4M6.5 17.5l4-1" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    '<rect x="9" y="5" width="12" height="6.5" rx="2.5" transform="rotate(-28 15 8)" fill="currentColor"/><circle cx="8.5" cy="15.5" r="5.5" fill="currentColor"/><circle cx="8.5" cy="15.5" r="2" fill="#000" opacity=".35"/>',
    '<path d="M12 2.5v19M3.8 7.2l16.4 9.6M3.8 16.8l16.4-9.6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M9.5 3.5L12 6l2.5-2.5M9.5 20.5L12 18l2.5 2.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    '<path d="M9 3h6M10 3v5.5L5.2 17.3A2.6 2.6 0 0 0 7.5 21h9a2.6 2.6 0 0 0 2.3-3.7L14 8.5V3" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M7.2 15h9.6l1.6 3.2a1.4 1.4 0 0 1-1.3 1.8H7a1.4 1.4 0 0 1-1.3-1.8z" fill="currentColor"/>',
    '<path d="M3 21h18M6.5 21l4.5-8 4.5 8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M11 13l6-7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="18" cy="5" r="3.4" fill="currentColor"/>',
    '<path d="M13.5 2L5 13.5h6L9.5 22 19 9.5h-6.2z" fill="currentColor"/>',
  ];
  const ICON_UP = '<path d="M12 4l7 8h-4.5v8h-5v-8H5z" fill="currentColor"/>';
  const ICON_SELL = '<circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M12 6.5v11M15 9.2c-.6-1-1.7-1.5-3-1.5-1.8 0-3 .9-3 2.2 0 3.2 6.2 1.6 6.2 4.6 0 1.4-1.3 2.3-3.2 2.3-1.4 0-2.6-.6-3.2-1.6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>';
  const ETIP = ['평범한 졸개', '아주 빨라요', '방패: 화살·대포·돌 피해 절반', '하늘을 날아요: 대포·투석기로는 못 맞혀요', '튼튼하고 조금씩 회복해요(독에 걸리면 회복 못 해요)',
    '근처 적을 치료해요 — 먼저 잡아요', '보스! 갑옷이 두꺼워요', '보스! 하늘을 날아요', '마지막 보스! 성에 닿으면 끝나요 · 고블린을 불러내요'];
  const CSS = `
.df-bar{position:absolute;left:0;right:0;bottom:0;z-index:6;display:flex;align-items:stretch;gap:6px;padding:8px 8px calc(8px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.95) 30%);user-select:none;-webkit-user-select:none}
.df-bar button{appearance:none;border:1.5px solid rgba(242,233,216,.16);background:rgba(46,38,64,.94);color:var(--ink,#f2e9d8);border-radius:12px;min-height:48px;cursor:pointer;touch-action:manipulation;font:700 14px/1.1 ${FONT};padding:0 8px}
.df-bar button:active{transform:scale(.96)}
.df-bar .df-info{flex:1;min-width:0;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;text-align:left;gap:3px;padding:0 10px;background:rgba(23,19,31,.82)}
.df-info b{display:block;max-width:100%;font:700 12.5px/1.15 ${FONT};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#ffe3a6}
.df-info span{display:block;max-width:100%;font:500 11px/1.15 ${FONT};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--muted,#ab9fb8)}
.df-bar .df-next{min-width:88px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;border-color:var(--brass,#e3ae45);background:rgba(227,174,69,.2);color:#ffe3a6}
.df-next small{font:600 10.5px/1 ${MONO};color:#f2e9d8;opacity:.85}
.df-bar .df-next[disabled]{opacity:.45;border-color:rgba(242,233,216,.16);background:rgba(46,38,64,.9);color:var(--muted,#ab9fb8)}
.df-bar .df-sq{width:48px;padding:0;font:700 15px/1 ${MONO}}
.df-bar .df-sq.on{border-color:var(--brass,#e3ae45);color:#ffe3a6;background:rgba(227,174,69,.22)}
.df-rad{position:absolute;inset:0;z-index:7;pointer-events:none}
.df-rb{position:absolute;width:54px;height:54px;margin:-27px 0 0 -27px;border-radius:50%;appearance:none;border:2px solid rgba(242,233,216,.35);background:radial-gradient(circle at 35% 30%,#4a3d63,#2a2139 70%);color:#f2e9d8;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;pointer-events:auto;cursor:pointer;touch-action:manipulation;box-shadow:0 4px 10px rgba(0,0,0,.45);padding:0;transition:transform .08s}
.df-rb svg{width:24px;height:24px;display:block}
.df-rb b{font:700 11px/1 ${MONO};color:#ffe3a6}
.df-rb.on{border-color:#ffe3a6;background:radial-gradient(circle at 35% 30%,#7a5c22,#3e2d10 75%);transform:scale(1.1)}
.df-rb.no{opacity:.55}
.df-rb.no b{color:#ee6a55}
.df-rb.arm{border-color:#ee6a55;background:radial-gradient(circle at 35% 30%,#7a2e26,#3a1410 75%)}
.df-rb:active{transform:scale(.94)}
.df-card{position:absolute;left:8px;right:8px;max-width:520px;margin:0 auto;z-index:7;background:rgba(23,19,31,.94);border:1.5px solid rgba(227,174,69,.45);border-radius:12px;padding:8px 11px;color:var(--ink,#f2e9d8);font:500 12px/1.4 ${FONT};pointer-events:none;box-shadow:0 6px 16px rgba(0,0,0,.4)}
.df-card h4{margin:0 0 2px;font:700 13.5px/1.25 ${FONT};color:#ffe3a6;display:flex;align-items:center;gap:6px}
.df-card h4 .dot{width:10px;height:10px;border-radius:50%;display:inline-block}
.df-card p{margin:0;color:#d9cfe3}
.df-card .st{font:600 11.5px/1.4 ${MONO};color:#f2e9d8}
.df-card .warn{color:#ee6a55;font-weight:700}
.df-tips{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:8;width:min(320px,calc(100% - 32px));background:rgba(23,19,31,.96);border:1.5px solid var(--brass,#e3ae45);border-radius:16px;padding:14px 16px;color:var(--ink,#f2e9d8);box-shadow:0 10px 30px rgba(0,0,0,.55)}
.df-tips h3{margin:0 0 8px;font:22px/1.1 ${DISP};color:#ffe3a6}
.df-tips ol{margin:0 0 12px;padding-left:20px;font:500 13px/1.5 ${FONT}}
.df-tips li{margin:0 0 4px}
.df-tips button{width:100%;min-height:46px;border-radius:12px;border:0;background:var(--brass,#e3ae45);color:#1c1408;font:700 15px/1 ${FONT};cursor:pointer}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const host = () => !api.online || api.isHost;
    const seatMe = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return false; };
    const auto = () => !!(L.debug && L.debug.autoplay);
    let st = null, key = null, W = null, ended = false, acc = 0, paused = false, aiMem = [];
    // network
    let pubT = 0, hsQ = 0, lastQ = -1, cmdI = 0, cmdQ = [], inT = 0, lastSig = '';
    const lastCmd = {};
    // effects
    let shots = [], fx = [], floats = [], parts = [], banner = null, shake = 0, flash = 0, lastSfx = {};
    const seen = new Map(), prevFc = [], aim = [], pend = [];
    let prevW = 0, prevHp = HP0, tipsShown = false, now0 = 0;
    // layout
    let lay = null, bg = null, bgKey = '';

    function curKey() { return st ? st.rid + '.' + st.mp + '.' + st.n : null; }
    function startGame() {
      W = newWorld(st.mp, st.n, st.df, st.nw, st.rid);
      aiMem = []; for (let i = 0; i < W.n; i++) aiMem.push({});
      shots = []; fx = []; floats = []; parts = []; banner = null; shake = 0; flash = 0;
      seen.clear(); prevFc.length = 0; aim.length = 0; pend.length = 0;
      prevW = 0; prevHp = HP0; ended = st.ph === 'done'; acc = 0; paused = false;
      cmdQ = []; lastQ = -1; for (const k in lastCmd) delete lastCmd[k];
      closeMenu(); kc = -1;
      layout();
      if (!tipsShown && seatMe() >= 0 && !auto()) { tipsShown = true; showTips(); }
      syncBar(true);
    }

    /* ----- layout: the whole board between the HUD and the bottom bar ----- */
    function layout() {
      const w = cv.w, h = cv.h, n = st ? st.n : 1;
      const hudH = n > 1 ? 62 : 44, barH = Math.max(60, bar.offsetHeight || 64);
      const availH = h - hudH - barH - 20, availW = w - 16;
      const cs = Math.max(8, Math.min(availW / GW, availH / GH));
      const mw = cs * GW, mh = cs * GH;
      lay = { w, h, cs, hudH, barH, mw, mh, ox: Math.round((w - mw) / 2), oy: Math.round(hudH + 10 + Math.max(0, (availH - mh) / 2)) };
      lay.key = [w, h, cs, st ? st.mp : -1, cv.dpr].join('|');
      if (menu) placeMenu();
    }
    cv.onresize = () => { layout(); };
    const X = (x) => lay.ox + x * lay.cs;
    const Y = (y) => lay.oy + y * lay.cs;

    /* ----- static board (cached) ----- */
    function prng(seed) { let s = seed >>> 0 || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
    function paintBG() {
      const w = lay.w, h = lay.h, dpr = cv.dpr || 1, cs = lay.cs, M = W.M;
      if (!bg) bg = document.createElement('canvas');
      bg.width = Math.round(w * dpr); bg.height = Math.round(h * dpr);
      const g = bg.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const rnd = prng(97 + W.mp * 131);
      g.fillStyle = '#17131f'; g.fillRect(0, 0, w, h);
      const { ox, oy, mw, mh } = lay;
      // wooden frame with brass lip
      rr(g, ox - 7, oy - 7, mw + 14, mh + 14, 12);
      const wg = g.createLinearGradient(0, oy - 7, 0, oy + mh + 7); wg.addColorStop(0, '#6b4526'); wg.addColorStop(1, '#3d2614');
      g.fillStyle = wg; g.fill();
      g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1; g.stroke();
      rr(g, ox - 2.5, oy - 2.5, mw + 5, mh + 5, 7); g.strokeStyle = '#e3ae45'; g.lineWidth = 1.4; g.stroke();
      g.save();
      rr(g, ox, oy, mw, mh, 5); g.clip();
      // felt-like meadow
      const fg = g.createRadialGradient(ox + mw * 0.45, oy + mh * 0.4, cs, ox + mw / 2, oy + mh / 2, Math.max(mw, mh) * 0.75);
      fg.addColorStop(0, '#3d7a3c'); fg.addColorStop(1, '#22502b');
      g.fillStyle = fg; g.fillRect(ox, oy, mw, mh);
      for (let i = 0; i < mw * mh / 30; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(255,255,220,.035)' : 'rgba(0,20,0,.06)'; g.fillRect(ox + rnd() * mw, oy + rnd() * mh, 1.2, 1.2); }
      // road
      g.lineCap = 'round'; g.lineJoin = 'round';
      const road = (wd, col) => { for (const R of M.routes) { g.beginPath(); for (let i = 0; i < R.p.length; i += 2) { const x = X(R.p[i]), y = Y(R.p[i + 1]); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.strokeStyle = col; g.lineWidth = wd; g.stroke(); } };
      road(cs * 0.98, 'rgba(10,20,6,.35)');
      road(cs * 0.86, '#4e3825');
      road(cs * 0.74, '#8b6a45');
      road(cs * 0.34, 'rgba(176,142,98,.45)');
      for (const R of M.routes) for (let d = 0.3; d < R.L; d += 0.45) { // pebbles
        const o = posAt(R, d, {}), a = rnd() * TAU, k = (rnd() - 0.5) * 0.6;
        g.beginPath(); g.ellipse(X(o.x - o.uy * k), Y(o.y + o.ux * k), cs * 0.05, cs * 0.035, a, 0, TAU); g.fillStyle = rnd() < 0.5 ? '#6d5236' : '#a88a62'; g.fill();
      }
      // scenery on free cells
      const padAt = new Set(M.S.map((s) => s.r * GW + s.c));
      for (let r = 0; r < GH; r++) for (let c = 0; c < GW; c++) {
        const k = r * GW + c;
        if (M.road[k] || padAt.has(k)) { rnd(); rnd(); continue; }
        if (Math.max(Math.abs(c - M.castle.c), Math.abs(r - M.castle.r)) <= 1) { rnd(); rnd(); continue; }
        const v = rnd(), u = rnd();
        const cx = X(c + 0.3 + u * 0.4), cy = Y(r + 0.3 + v * 0.4);
        if (v < 0.42) tree(g, cx, cy, cs * (0.26 + u * 0.12), rnd);
        else if (v < 0.52) rock(g, cx, cy, cs * 0.16);
        else tuft(g, cx, cy, cs, rnd);
      }
      // cave mouths where the road comes in
      const done = new Set();
      for (const wp of M.R) {
        const k = wp[0][0] + ',' + wp[0][1];
        if (done.has(k)) continue;
        done.add(k);
        const [c, r] = wp[0], [c1, r1] = wp[1];
        const ex = X(clamp(c + 0.5, 0, GW)), ey = Y(clamp(r + 0.5, 0, GH));
        const ang = Math.atan2(r1 - r, c1 - c);
        g.save(); g.translate(ex, ey); g.rotate(ang - Math.PI / 2);
        g.beginPath(); g.ellipse(0, 0, cs * 0.8, cs * 0.62, 0, 0, Math.PI); g.fillStyle = '#4a413b'; g.fill();
        g.beginPath(); g.ellipse(0, 0, cs * 0.5, cs * 0.4, 0, 0, Math.PI); g.fillStyle = '#0d0a0a'; g.fill();
        for (let i = 0; i < 6; i++) { const a = (i + 0.5) / 6 * Math.PI; g.beginPath(); g.arc(Math.cos(a) * cs * 0.68, Math.sin(a) * cs * 0.52, cs * 0.1, 0, TAU); g.fillStyle = i % 2 ? '#5c524b' : '#7d7066'; g.fill(); }
        g.restore();
      }
      g.restore();
      // pads
      for (const s of M.S) pad(g, X(s.x), Y(s.y), cs);
      castle(g, X(M.castle.x), Y(M.castle.y), cs);
      bgKey = lay.key;
    }
    function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
    function tree(g, x, y, r, rnd) {
      g.beginPath(); g.ellipse(x + r * 0.25, y + r * 0.45, r * 1.05, r * 0.6, 0, 0, TAU); g.fillStyle = 'rgba(5,20,5,.35)'; g.fill();
      const cols = ['#1e4a24', '#2b6230', '#3c7a3a'];
      for (let i = 0; i < 3; i++) { g.beginPath(); g.arc(x + (rnd() - 0.5) * r * 0.5, y - i * r * 0.18 + (rnd() - 0.5) * r * 0.3, r * (1 - i * 0.22), 0, TAU); g.fillStyle = cols[i]; g.fill(); }
      g.beginPath(); g.arc(x - r * 0.25, y - r * 0.45, r * 0.22, 0, TAU); g.fillStyle = 'rgba(200,240,150,.14)'; g.fill();
    }
    function rock(g, x, y, r) {
      g.beginPath(); g.ellipse(x + r * 0.2, y + r * 0.35, r * 1.2, r * 0.6, 0, 0, TAU); g.fillStyle = 'rgba(0,0,0,.3)'; g.fill();
      g.beginPath(); g.ellipse(x, y, r * 1.1, r * 0.8, 0.3, 0, TAU); g.fillStyle = '#8a8378'; g.fill();
      g.beginPath(); g.ellipse(x - r * 0.3, y - r * 0.25, r * 0.45, r * 0.3, 0.3, 0, TAU); g.fillStyle = 'rgba(255,255,255,.22)'; g.fill();
    }
    function tuft(g, x, y, cs, rnd) {
      g.strokeStyle = rnd() < 0.5 ? '#4f8a3e' : '#2f6a2c'; g.lineWidth = 1.2; g.lineCap = 'round';
      for (let k = 0; k < 4; k++) { const a = (k - 1.5) * 0.35; g.beginPath(); g.moveTo(x + k * 1.6, y); g.lineTo(x + k * 1.6 + Math.sin(a) * cs * 0.12, y - cs * 0.14); g.stroke(); }
      if (rnd() < 0.25) { g.beginPath(); g.arc(x + 3, y - cs * 0.15, cs * 0.04, 0, TAU); g.fillStyle = rnd() < 0.5 ? '#f2e9d8' : '#f0c75a'; g.fill(); }
    }
    function pad(g, x, y, cs) {
      const r = cs * 0.42;
      g.beginPath(); g.ellipse(x + 1, y + r * 0.25, r * 1.05, r * 0.85, 0, 0, TAU); g.fillStyle = 'rgba(0,0,0,.35)'; g.fill();
      for (let i = 0; i < 9; i++) {
        const a = i / 9 * TAU, sx = x + Math.cos(a) * r * 0.78, sy = y + Math.sin(a) * r * 0.7;
        g.beginPath(); g.ellipse(sx, sy, r * 0.3, r * 0.24, a, 0, TAU); g.fillStyle = i % 2 ? '#9a9184' : '#827a6e'; g.fill();
      }
      g.beginPath(); g.ellipse(x, y, r * 0.62, r * 0.52, 0, 0, TAU); g.fillStyle = '#5e574d'; g.fill();
      g.beginPath(); g.ellipse(x - r * 0.15, y - r * 0.12, r * 0.3, r * 0.2, 0, 0, TAU); g.fillStyle = 'rgba(255,255,255,.08)'; g.fill();
    }
    function castle(g, x, y, cs) {
      const s = cs;
      g.beginPath(); g.ellipse(x + s * 0.1, y + s * 0.62, s * 1.35, s * 0.42, 0, 0, TAU); g.fillStyle = 'rgba(0,0,0,.4)'; g.fill();
      const stone = (sx, sy, sw, sh, c) => { g.fillStyle = c; g.fillRect(sx, sy, sw, sh); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 1; g.strokeRect(sx + 0.5, sy + 0.5, sw - 1, sh - 1); };
      // wall
      stone(x - s * 1.1, y - s * 0.25, s * 2.2, s * 0.8, '#a39a8c');
      for (let i = 0; i < 6; i++) stone(x - s * 1.1 + i * s * 0.4, y - s * 0.42, s * 0.24, s * 0.2, '#b3aa9c');
      // side towers
      for (const sd of [-1, 1]) {
        const tx = x + sd * s * 0.95;
        stone(tx - s * 0.3, y - s * 0.75, s * 0.6, s * 1.3, '#968d80');
        for (let i = 0; i < 3; i++) stone(tx - s * 0.3 + i * s * 0.22, y - s * 0.92, s * 0.16, s * 0.2, '#a89f92');
        g.fillStyle = '#2a2018'; g.fillRect(tx - s * 0.05, y - s * 0.45, s * 0.1, s * 0.22);
      }
      // keep + roof
      stone(x - s * 0.42, y - s * 1.05, s * 0.84, s * 1.0, '#b8afa0');
      g.beginPath(); g.moveTo(x - s * 0.52, y - s * 1.02); g.lineTo(x, y - s * 1.62); g.lineTo(x + s * 0.52, y - s * 1.02); g.closePath();
      g.fillStyle = '#7a2e26'; g.fill(); g.strokeStyle = '#3d140f'; g.lineWidth = 1; g.stroke();
      // flag
      g.strokeStyle = '#3d2614'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x, y - s * 1.6); g.lineTo(x, y - s * 2.0); g.stroke();
      g.beginPath(); g.moveTo(x, y - s * 2.0); g.lineTo(x + s * 0.38, y - s * 1.9); g.lineTo(x, y - s * 1.8); g.closePath(); g.fillStyle = '#e3ae45'; g.fill();
      // gate
      g.beginPath(); g.moveTo(x - s * 0.24, y + s * 0.55); g.lineTo(x - s * 0.24, y + s * 0.1); g.arc(x, y + s * 0.1, s * 0.24, Math.PI, TAU); g.lineTo(x + s * 0.24, y + s * 0.55); g.closePath();
      g.fillStyle = '#2a1a10'; g.fill(); g.strokeStyle = '#e3ae45'; g.lineWidth = 1.2; g.stroke();
      g.fillStyle = '#e8c86a'; g.fillRect(x - s * 0.08, y - s * 0.75, s * 0.16, s * 0.2);
    }

    /* ----- dynamic drawing ----- */
    function hpFrac(e) { return e.mh ? clamp(e.hp / e.mh, 0, 1) : 1; }
    function drawTower(T, s, t) {
      const S = W.M.S[s], x = X(S.x), y = Y(S.y), cs = lay.cs, r = cs * 0.4, col = P(T.o).color, D = TT[T.ty];
      ctx.save();
      // owner ring + base
      ctx.beginPath(); ctx.ellipse(x, y + r * 0.1, r * 0.98, r * 0.8, 0, 0, TAU); ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fill();
      ctx.lineWidth = Math.max(2, cs * 0.07); ctx.strokeStyle = col; ctx.stroke();
      const a = aim[s] != null ? aim[s] : -Math.PI / 2, fire = T.fl || 0;
      if (T.ty === 0) { // archer tower
        const bw = r * 1.05, bh = r * 1.2, by = y - r * 0.15;
        ctx.fillStyle = '#7b5a3a'; ctx.fillRect(x - bw / 2, by - bh / 2, bw, bh);
        ctx.strokeStyle = '#3d2614'; ctx.lineWidth = 1; ctx.strokeRect(x - bw / 2 + 0.5, by - bh / 2 + 0.5, bw - 1, bh - 1);
        ctx.fillStyle = '#5e4128'; for (let i = 0; i < 3; i++) ctx.fillRect(x - bw / 2, by - bh / 2 + bh * (0.3 + i * 0.25), bw, 1.2);
        ctx.beginPath(); ctx.moveTo(x - bw * 0.68, by - bh / 2); ctx.lineTo(x, by - bh / 2 - r * 0.75); ctx.lineTo(x + bw * 0.68, by - bh / 2); ctx.closePath();
        ctx.fillStyle = T.lv >= 3 ? '#c2902e' : T.lv === 2 ? '#3f6aa0' : '#8e3b2c'; ctx.fill(); ctx.strokeStyle = '#2a160c'; ctx.stroke();
        ctx.beginPath(); ctx.arc(x + Math.cos(a) * r * 0.22, by - bh * 0.1 + Math.sin(a) * r * 0.1, r * 0.17, 0, TAU); ctx.fillStyle = col; ctx.fill();
      } else if (T.ty === 1) { // cannon
        rr(ctx, x - r * 0.72, y - r * 0.45, r * 1.44, r * 0.8, r * 0.18); ctx.fillStyle = '#7b5a3a'; ctx.fill(); ctx.strokeStyle = '#3d2614'; ctx.lineWidth = 1; ctx.stroke();
        for (const sd of [-1, 1]) { ctx.beginPath(); ctx.arc(x + sd * r * 0.5, y + r * 0.3, r * 0.24, 0, TAU); ctx.fillStyle = '#4a311c'; ctx.fill(); ctx.strokeStyle = '#2a1a0e'; ctx.stroke(); }
        ctx.save(); ctx.translate(x, y - r * 0.15); ctx.rotate(a);
        const kick = fire * r * 0.25, bl = r * (0.95 + T.lv * 0.12);
        const bgr = ctx.createLinearGradient(0, -r * 0.26, 0, r * 0.26); bgr.addColorStop(0, '#77737e'); bgr.addColorStop(0.5, '#3a3840'); bgr.addColorStop(1, '#1e1d22');
        rr(ctx, -r * 0.35 - kick, -r * 0.26, bl + r * 0.35, r * 0.52, r * 0.2); ctx.fillStyle = bgr; ctx.fill(); ctx.strokeStyle = '#111'; ctx.stroke();
        ctx.fillStyle = T.lv >= 3 ? '#e3ae45' : T.lv === 2 ? '#b8b2a6' : '#55525a'; ctx.fillRect(bl - r * 0.18 - kick, -r * 0.3, r * 0.16, r * 0.6);
        ctx.beginPath(); ctx.arc(bl - kick, 0, r * 0.15, 0, TAU); ctx.fillStyle = '#0b0a0c'; ctx.fill();
        ctx.restore();
      } else if (T.ty === 2) { // frost spire
        const bob = Math.sin(t * 2.4 + s) * r * 0.08;
        ctx.beginPath(); ctx.arc(x, y, r * 0.62, 0, TAU); ctx.fillStyle = '#5e6d80'; ctx.fill();
        const gl = ctx.createRadialGradient(x, y - r * 0.5 + bob, 1, x, y - r * 0.5 + bob, r * (1 + fire));
        gl.addColorStop(0, 'rgba(170,230,255,.55)'); gl.addColorStop(1, 'rgba(170,230,255,0)');
        ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y - r * 0.5 + bob, r * (1 + fire), 0, TAU); ctx.fill();
        const hh = r * (1.05 + T.lv * 0.12);
        ctx.beginPath(); ctx.moveTo(x, y - hh - r * 0.3 + bob); ctx.lineTo(x + r * 0.34, y - r * 0.35 + bob); ctx.lineTo(x, y + r * 0.05 + bob); ctx.lineTo(x - r * 0.34, y - r * 0.35 + bob); ctx.closePath();
        ctx.fillStyle = '#bfefff'; ctx.fill(); ctx.strokeStyle = '#4aa6d8'; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x, y - hh - r * 0.3 + bob); ctx.lineTo(x, y + r * 0.05 + bob); ctx.strokeStyle = 'rgba(74,166,216,.6)'; ctx.stroke();
      } else if (T.ty === 3) { // poison cauldron
        ctx.beginPath(); ctx.ellipse(x, y - r * 0.05, r * 0.72, r * 0.62, 0, 0, TAU); ctx.fillStyle = '#2a2a2e'; ctx.fill(); ctx.strokeStyle = '#111'; ctx.lineWidth = 1; ctx.stroke();
        ctx.beginPath(); ctx.ellipse(x, y - r * 0.38, r * 0.62, r * 0.24, 0, 0, TAU); ctx.fillStyle = T.lv >= 3 ? '#9cff6a' : '#6fd34a'; ctx.fill();
        for (let i = 0; i < 2 + T.lv; i++) {
          const ph = (t * 0.9 + i * 0.37 + s * 0.13) % 1, bx = x + Math.sin(i * 2.3 + s) * r * 0.35, by = y - r * 0.4 - ph * r * 0.9;
          ctx.beginPath(); ctx.arc(bx, by, r * (0.08 + 0.06 * (1 - ph)), 0, TAU); ctx.fillStyle = 'rgba(140,240,90,' + (0.8 * (1 - ph)).toFixed(2) + ')'; ctx.fill();
        }
      } else if (T.ty === 4) { // catapult
        ctx.fillStyle = '#6b4a2c'; ctx.fillRect(x - r * 0.75, y - r * 0.1, r * 1.5, r * 0.3);
        ctx.fillStyle = '#4a311c'; ctx.fillRect(x - r * 0.12, y - r * 0.55, r * 0.24, r * 0.5);
        const arm = -2.1 + fire * 1.6;
        ctx.save(); ctx.translate(x, y - r * 0.45); ctx.rotate(arm + (a > -Math.PI / 2 && a < Math.PI / 2 ? 0 : 0));
        ctx.fillStyle = '#8a6440'; ctx.fillRect(0, -r * 0.08, r * 1.1, r * 0.16);
        ctx.beginPath(); ctx.arc(r * 1.1, 0, r * 0.2, 0, TAU); ctx.fillStyle = fire > 0.5 ? '#4a311c' : '#8a8378'; ctx.fill();
        ctx.restore();
        for (let i = 0; i < T.lv; i++) { ctx.beginPath(); ctx.arc(x - r * 0.55 + i * r * 0.28, y + r * 0.3, r * 0.1, 0, TAU); ctx.fillStyle = '#3a2a18'; ctx.fill(); }
      } else { // lightning coil
        ctx.fillStyle = '#4b4558'; ctx.fillRect(x - r * 0.42, y - r * 0.25, r * 0.84, r * 0.5);
        const hh = r * (1.0 + T.lv * 0.12);
        for (let i = 0; i < 4; i++) { ctx.fillStyle = i % 2 ? '#b98a2c' : '#e3ae45'; ctx.fillRect(x - r * 0.18, y - r * 0.25 - (i + 1) * hh * 0.22, r * 0.36, hh * 0.2); }
        const oy = y - r * 0.35 - hh;
        const gl = ctx.createRadialGradient(x, oy, 1, x, oy, r * (0.7 + fire * 0.8));
        gl.addColorStop(0, 'rgba(255,250,200,.95)'); gl.addColorStop(0.4, 'rgba(160,190,255,.6)'); gl.addColorStop(1, 'rgba(160,190,255,0)');
        ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, oy, r * (0.7 + fire * 0.8), 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(x, oy, r * 0.22, 0, TAU); ctx.fillStyle = '#fff6d0'; ctx.fill();
      }
      ctx.restore();
      // level pips
      for (let i = 0; i < T.lv; i++) {
        const px = x - (T.lv - 1) * r * 0.22 + i * r * 0.44, py = y + r * 0.78;
        ctx.beginPath(); ctx.arc(px, py, Math.max(2, r * 0.13), 0, TAU); ctx.fillStyle = '#e3ae45'; ctx.fill(); ctx.strokeStyle = '#3d2614'; ctx.lineWidth = 1; ctx.stroke();
      }
      void D;
    }
    function drawEnemy(e, t) {
      const T = ET[e.t], cs = lay.cs, r = T.rs * cs, air = T.air, x = X(e.x), y0 = Y(e.y), hov = air ? cs * 0.32 + Math.sin(t * 5 + e.id) * cs * 0.04 : 0, y = y0 - hov;
      const R = W.M.routes[e.r] || W.M.routes[0];
      const o = posAt(R, e.d, tmpO), fx = o.ux < -0.2 ? -1 : 1;
      // shadow
      ctx.beginPath(); ctx.ellipse(x, y0 + r * 0.55, r * (air ? 0.8 : 1), r * (air ? 0.3 : 0.4), 0, 0, TAU); ctx.fillStyle = 'rgba(0,0,0,' + (air ? 0.22 : 0.35) + ')'; ctx.fill();
      const walk = Math.sin(t * 10 + e.id) * r * 0.08;
      ctx.save(); ctx.translate(x, y + (air ? 0 : walk * 0.4)); ctx.scale(fx, 1);
      switch (e.t) {
        case 0: // goblin
          body(r, '#6fae3c', '#3d6a1f');
          ear(-1, r, '#6fae3c'); ear(1, r, '#6fae3c');
          eyes(r, '#ffe36a');
          ctx.strokeStyle = '#6b4a2c'; ctx.lineWidth = Math.max(1, r * 0.14); ctx.beginPath(); ctx.moveTo(r * 0.6, r * 0.5); ctx.lineTo(r * 1.0, -r * 0.7); ctx.stroke();
          break;
        case 1: // wolf
          ctx.beginPath(); ctx.ellipse(-r * 0.15, 0, r * 1.05, r * 0.62, 0, 0, TAU); ctx.fillStyle = '#8d8a92'; ctx.fill(); ctx.strokeStyle = '#4b4850'; ctx.lineWidth = 1; ctx.stroke();
          ctx.beginPath(); ctx.arc(r * 0.75, -r * 0.25, r * 0.5, 0, TAU); ctx.fillStyle = '#a19ea6'; ctx.fill(); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(r * 0.55, -r * 0.65); ctx.lineTo(r * 0.7, -r * 1.05); ctx.lineTo(r * 0.92, -r * 0.62); ctx.fillStyle = '#6d6a72'; ctx.fill();
          ctx.beginPath(); ctx.moveTo(-r * 1.1, -r * 0.1); ctx.quadraticCurveTo(-r * 1.6, -r * 0.6 + walk, -r * 1.5, -r * 0.9); ctx.strokeStyle = '#8d8a92'; ctx.lineWidth = r * 0.25; ctx.lineCap = 'round'; ctx.stroke();
          ctx.beginPath(); ctx.arc(r * 0.95, -r * 0.32, r * 0.09, 0, TAU); ctx.fillStyle = '#ffdf6a'; ctx.fill();
          break;
        case 2: // shield orc
          body(r, '#4f6b3a', '#2a3d1c');
          eyes(r, '#ff7a5a');
          rr(ctx, r * 0.35, -r * 0.75, r * 0.6, r * 1.45, r * 0.2); ctx.fillStyle = '#8a5a30'; ctx.fill(); ctx.strokeStyle = '#3d2614'; ctx.lineWidth = 1; ctx.stroke();
          ctx.beginPath(); ctx.arc(r * 0.65, 0, r * 0.15, 0, TAU); ctx.fillStyle = '#c9c0b0'; ctx.fill();
          break;
        case 3: case 7: { // bat / dragon
          const big = e.t === 7, fl = Math.sin(t * (big ? 6 : 16) + e.id) * 0.6, wc = big ? '#a8322a' : '#5a3f78';
          for (const sd of [-1, 1]) {
            ctx.beginPath(); ctx.moveTo(0, -r * 0.1);
            ctx.quadraticCurveTo(r * 0.6 * sd * (big ? 0.6 : 1), -r * (1.3 + fl), r * 1.7 * sd * (big ? 0.6 : 1), -r * (0.3 + fl * 0.8));
            ctx.quadraticCurveTo(r * 1.0 * sd * (big ? 0.6 : 1), r * 0.1, 0, r * 0.25);
            ctx.fillStyle = wc; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1; ctx.stroke();
          }
          if (big) {
            ctx.beginPath(); ctx.moveTo(-r * 0.7, r * 0.1); ctx.quadraticCurveTo(-r * 1.4, r * 0.5, -r * 1.6, r * 0.1); ctx.strokeStyle = '#c0453a'; ctx.lineWidth = r * 0.18; ctx.lineCap = 'round'; ctx.stroke();
            ctx.beginPath(); ctx.ellipse(0, 0, r * 0.8, r * 0.45, 0, 0, TAU); ctx.fillStyle = '#d0473a'; ctx.fill();
            ctx.beginPath(); ctx.arc(r * 0.75, -r * 0.2, r * 0.32, 0, TAU); ctx.fill();
            ctx.beginPath(); ctx.arc(r * 0.88, -r * 0.28, r * 0.07, 0, TAU); ctx.fillStyle = '#ffe36a'; ctx.fill();
          } else {
            ctx.beginPath(); ctx.arc(0, 0, r * 0.5, 0, TAU); ctx.fillStyle = '#3f2c55'; ctx.fill();
            ctx.beginPath(); ctx.arc(r * 0.18, -r * 0.1, r * 0.1, 0, TAU); ctx.fillStyle = '#ff6a5a'; ctx.fill();
          }
          break;
        }
        case 4: // troll
          body(r, '#7c8a96', '#4a5560');
          eyes(r * 0.9, '#ffd36a');
          ctx.strokeStyle = '#5e4128'; ctx.lineWidth = r * 0.28; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(r * 0.5, r * 0.3); ctx.lineTo(r * 1.15, -r * 0.55 + walk); ctx.stroke();
          ctx.beginPath(); ctx.arc(r * 1.18, -r * 0.6 + walk, r * 0.24, 0, TAU); ctx.fillStyle = '#4a311c'; ctx.fill();
          break;
        case 5: { // shaman
          ctx.beginPath(); ctx.moveTo(0, -r * 1.0); ctx.lineTo(r * 0.8, r * 0.7); ctx.lineTo(-r * 0.8, r * 0.7); ctx.closePath(); ctx.fillStyle = '#7b4fa8'; ctx.fill(); ctx.strokeStyle = '#3e2457'; ctx.lineWidth = 1; ctx.stroke();
          ctx.beginPath(); ctx.arc(0, -r * 0.45, r * 0.32, 0, TAU); ctx.fillStyle = '#9c7a5a'; ctx.fill();
          ctx.strokeStyle = '#6b4a2c'; ctx.lineWidth = r * 0.12; ctx.beginPath(); ctx.moveTo(r * 0.75, r * 0.7); ctx.lineTo(r * 0.75, -r * 1.0); ctx.stroke();
          const gp = 0.5 + 0.5 * Math.sin(t * 4 + e.id);
          ctx.beginPath(); ctx.arc(r * 0.75, -r * 1.05, r * (0.2 + gp * 0.1), 0, TAU); ctx.fillStyle = 'rgba(120,255,170,' + (0.6 + gp * 0.4).toFixed(2) + ')'; ctx.fill();
          break;
        }
        case 6: // ogre king
          body(r, '#c79a6a', '#7a5a3a');
          ctx.fillStyle = '#5e4128'; ctx.fillRect(-r * 0.9, r * 0.2, r * 1.8, r * 0.18);
          eyes(r, '#ff6a4a');
          crown(r, '#e3ae45');
          break;
        case 8: { // dark lord
          const gp = 0.5 + 0.5 * Math.sin(t * 3);
          ctx.beginPath(); ctx.arc(0, 0, r * (1.35 + gp * 0.15), 0, TAU); ctx.fillStyle = 'rgba(150,60,200,' + (0.18 + gp * 0.1).toFixed(2) + ')'; ctx.fill();
          ctx.beginPath(); ctx.moveTo(0, -r * 1.1); ctx.lineTo(r * 0.95, r * 0.85); ctx.lineTo(-r * 0.95, r * 0.85); ctx.closePath(); ctx.fillStyle = '#2b1838'; ctx.fill(); ctx.strokeStyle = '#7b4fa8'; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.beginPath(); ctx.arc(0, -r * 0.45, r * 0.42, 0, TAU); ctx.fillStyle = '#1a0f22'; ctx.fill();
          for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * r * 0.3, -r * 0.75); ctx.quadraticCurveTo(sd * r * 0.7, -r * 1.1, sd * r * 0.55, -r * 1.45); ctx.strokeStyle = '#d8ccb6'; ctx.lineWidth = r * 0.12; ctx.stroke(); }
          ctx.fillStyle = '#ff3b3b'; ctx.fillRect(-r * 0.2, -r * 0.52, r * 0.13, r * 0.08); ctx.fillRect(r * 0.08, -r * 0.52, r * 0.13, r * 0.08);
          break;
        }
      }
      ctx.restore();
      // status
      if (e.slT > 0) { ctx.beginPath(); ctx.ellipse(x, y0 + r * 0.45, r * 1.15, r * 0.45, 0, 0, TAU); ctx.strokeStyle = 'rgba(150,220,255,.85)'; ctx.lineWidth = 1.6; ctx.stroke(); }
      if (e.psT > 0) { const ph = (t * 1.5 + e.id * 0.3) % 1; ctx.beginPath(); ctx.arc(x + r * 0.4, y - r * (0.6 + ph), r * 0.16 * (1 - ph * 0.5), 0, TAU); ctx.fillStyle = 'rgba(130,240,80,' + (0.9 - ph * 0.8).toFixed(2) + ')'; ctx.fill(); }
      const f = hpFrac(e);
      if (f < 0.999 || T.boss) {
        const bw = Math.max(16, r * 2.1), bh = T.boss ? 5 : 3.5, bx = x - bw / 2, by = y - r * (T.boss ? 1.75 : 1.35) - bh;
        ctx.fillStyle = 'rgba(0,0,0,.65)'; ctx.fillRect(bx - 1, by - 1, bw + 2, bh + 2);
        ctx.fillStyle = f > 0.5 ? '#7fd36a' : f > 0.25 ? '#e8c04e' : '#ee6a55'; ctx.fillRect(bx, by, bw * f, bh);
      }
    }
    const tmpO = {};
    function body(r, c1, c2) {
      const g = ctx.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.1, 0, 0, r);
      g.addColorStop(0, c1); g.addColorStop(1, c2);
      ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = 1; ctx.stroke();
    }
    function ear(sd, r, c) { ctx.beginPath(); ctx.moveTo(sd * r * 0.55, -r * 0.55); ctx.lineTo(sd * r * 1.2, -r * 0.95); ctx.lineTo(sd * r * 0.85, -r * 0.25); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); }
    function eyes(r, c) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(r * 0.2, -r * 0.2, Math.max(1, r * 0.14), 0, TAU); ctx.arc(r * 0.55, -r * 0.2, Math.max(1, r * 0.14), 0, TAU); ctx.fill(); }
    function crown(r, c) {
      ctx.beginPath(); ctx.moveTo(-r * 0.55, -r * 0.8); ctx.lineTo(-r * 0.55, -r * 1.25); ctx.lineTo(-r * 0.27, -r * 1.0); ctx.lineTo(0, -r * 1.35); ctx.lineTo(r * 0.27, -r * 1.0); ctx.lineTo(r * 0.55, -r * 1.25); ctx.lineTo(r * 0.55, -r * 0.8); ctx.closePath();
      ctx.fillStyle = c; ctx.fill(); ctx.strokeStyle = '#7a5410'; ctx.lineWidth = 1; ctx.stroke();
    }

    /* ----- watch the world (same on host and guests): shots, deaths, leaks, waves ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function puff(x, y, col, n, sp, life) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - sp * 0.3, t: (life || 0.5) * (0.6 + Math.random() * 0.6), c: col, r: 1 + Math.random() * 2 }); }
      if (parts.length > 300) parts.splice(0, parts.length - 300);
    }
    function findE(id) { for (const e of W.E) if (e.id === id) return e; return null; }
    function watch() {
      const cs = lay.cs, me = seatMe();
      // shots
      for (let s = 0; s < W.T.length; s++) {
        const T = W.T[s];
        if (!T) { prevFc[s] = -1; aim[s] = null; continue; }
        if (T.fl) T.fl = Math.max(0, T.fl - 0.06);
        if (prevFc[s] == null || prevFc[s] < 0) { prevFc[s] = T.fc; continue; }
        if (T.fc === prevFc[s]) continue;
        prevFc[s] = T.fc;
        const e = findE(T.tg), S = W.M.S[s], D = TT[T.ty];
        if (!e) continue;
        aim[s] = Math.atan2(e.y - S.y, e.x - S.x);
        T.fl = 1;
        if (T.ty === 5) {
          const pts = [[S.x, S.y - 0.75], [e.x, e.y]];
          let cur = e; const hit = [e];
          for (let j = 0; j < D.ch[T.lv - 1]; j++) {
            let nx = null, nd = 1.7 * 1.7;
            for (const o of W.E) { if (hit.includes(o)) continue; const d2 = (o.x - cur.x) ** 2 + (o.y - cur.y) ** 2; if (d2 < nd) { nd = d2; nx = o; } }
            if (!nx) break;
            pts.push([nx.x, nx.y]); hit.push(nx); cur = nx;
          }
          fx.push({ k: 'bolt', pts, t: 0.2, T: 0.2 });
          sfx('hit', 140);
          continue;
        }
        let lx = e.x, ly = e.y;
        if (D.spl && (T.ty === 1 || T.ty === 4)) { const R = W.M.routes[e.r], o = posAt(R, e.d + speedOf(W, e) * D.fl, tmpO), off = laneOff(e.id); lx = o.x - o.uy * off; ly = o.y + o.ux * off; }
        const sy = T.ty === 4 ? S.y - 0.5 : S.y - 0.35;
        shots.push({ ty: T.ty, lv: T.lv, sx: S.x, sy, tid: e.id, tx: lx, tyy: ly, t: 0, T: Math.max(0.12, D.fl), air: !!ET[e.t].air });
        if (T.ty === 1 || T.ty === 4) sfx('thud', 160);
      }
      // deaths / leaks
      const live = new Set();
      for (const e of W.E) {
        live.add(e.id);
        let q = seen.get(e.id);
        if (!q) { q = { t: e.t, x: 0, y: 0, rem: 0 }; seen.set(e.id, q); if (ET[e.t].boss) { sfx('bounce', 300); api.buzz(30); } }
        q.x = e.x; q.y = e.y; q.rem = remOf(W, e);
      }
      for (const [id, q] of seen) {
        if (live.has(id)) continue;
        seen.delete(id);
        const T = ET[q.t];
        if (q.rem < 0.6) {
          flash = 1; shake = Math.min(1, shake + 0.35 + T.dmg * 0.05);
          floats.push({ x: W.M.castle.x, y: W.M.castle.y - 1.2, text: '−' + T.dmg, col: '#ee6a55', t: 1.1, T: 1.1, big: 1 });
          sfx('lose', 250); api.buzz(T.dmg >= 5 ? [60, 40, 60] : 35);
        } else {
          puff(X(q.x), Y(q.y) - (T.air ? cs * 0.32 : 0), T.boss ? '#e3ae45' : '#d8ccb6', T.boss ? 30 : 9, cs * (T.boss ? 3 : 1.6), T.boss ? 0.9 : 0.45);
          const share = Math.round(T.gold * TEAM[W.n] / W.n);
          if (share >= 1 && me >= 0) floats.push({ x: q.x, y: q.y - 0.4, text: '+' + share, col: '#ffd76a', t: 0.8, T: 0.8 });
          sfx('pop', 80);
          if (T.boss) { api.buzz([30, 30, 60]); banner = { a: T.nm + ' 쓰러뜨림!', b: '', t: 1.8, T: 1.8 }; }
        }
      }
      // waves
      if (W.w !== prevW) {
        if (W.w > prevW && W.w > 0) {
          const gs = waveGroups(W.w, W.nw), bossW = gs.some((g) => ET[g[0]].boss);
          const newT = gs.map((g) => g[0]).filter((ty, i, a) => a.indexOf(ty) === i && !seenType(ty, W.w));
          banner = { a: (W.w === W.nw ? '마지막 웨이브!' : '웨이브 ' + W.w + ' / ' + W.nw), b: newT.length ? '새 적 · ' + ET[newT[0]].nm + ': ' + ETIP[newT[0]] : bossW ? '보스가 와요!' : '', t: 2.4, T: 2.4, boss: bossW };
          sfx('whoosh', 200); api.buzz(bossW ? [40, 50, 40] : 15);
        }
        prevW = W.w;
        if (W.w >= 1) hideTips();
        syncBar(true);
      }
      if (W.hp < prevHp) prevHp = W.hp;
    }
    function seenType(ty, w) { for (let i = 1; i < w; i++) if (waveGroups(i, W.nw).some((g) => g[0] === ty)) return true; return false; }

    /* ----- host: run the world ----- */
    function finish() {
      if (ended) return;
      ended = true;
      closeMenu();
      api.setState(Object.assign({}, st, { ph: 'done', res: { win: W.end > 0 ? 1 : 0, hp: W.hp, w: W.w, k: W.k.slice(), b: W.bt.slice() } }));
    }
    function hostTick(dt) {
      if (st.ph !== 'play' || ended) return;
      pollHost();
      if (paused) return;
      acc += Math.min(dt * W.sp, 2);
      let k = 0;
      while (acc >= STEP && k < 80) {
        for (let s = 0; s < W.n; s++) {
          const p = api.players[s];
          if (!p || !simHere(s)) continue;
          if (p.ai || auto()) {
            const c = aiThink(W, s, aiMem[s] || (aiMem[s] = {}), p.ai ? (p.lv || 2) : 2);
            if (c) cmd(W, s, c[0], c[1], c[2]);
          }
        }
        stepWorld(W, STEP, null);
        acc -= STEP; k++;
        if (W.end) { finish(); break; }
      }
    }

    /* ----- online ----- */
    function packHS() {
      const T = [], E = [];
      for (let s = 0; s < W.T.length; s++) { const t = W.T[s]; if (t) T.push(s, t.ty, t.lv, t.o, t.fc, t.tg); }
      const list = W.E.slice().sort((a, b) => remOf(W, a) - remOf(W, b));
      for (let i = 0; i < list.length && i < 64; i++) {
        const e = list[i];
        E.push(e.id, e.t, e.r, Math.round(e.d * 10), Math.max(1, Math.round(hpFrac(e) * 100)), (e.slT > 0 ? 1 : 0) | (e.psT > 0 ? 2 : 0));
      }
      return { k: key, q: hsQ, t: Math.round(W.t * 10) / 10, w: W.w, c: W.cd > 0 ? Math.ceil(W.cd * 10) : -1, qn: W.q.length, sp: W.sp, hp: W.hp, g: W.g.map((v) => Math.floor(v + 1e-6)), T, E, A: Object.assign({}, lastCmd) };
    }
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.n) || simHere(s) || !o || o.k !== key || !Array.isArray(o.c)) continue;
        const list = o.c.filter((c) => Array.isArray(c) && fin(c[0])).sort((a, b) => a[0] - b[0]);
        for (const c of list) {
          if (c[0] <= (lastCmd[s] | 0)) continue;
          lastCmd[s] = c[0];
          cmd(W, s, c[1] | 0, c[2] | 0, c[3] | 0);
        }
      }
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.E)) return;
      lastQ = hs.q;
      if (fin(hs.t)) W.t = hs.t;
      if (fin(hs.w)) W.w = hs.w;
      if (fin(hs.c)) W.cd = hs.c >= 0 ? hs.c / 10 : -1;
      W.qn = fin(hs.qn) ? hs.qn : 0;
      if (hs.sp === 1 || hs.sp === 2) W.sp = hs.sp;
      if (fin(hs.hp)) W.hp = hs.hp;
      if (Array.isArray(hs.g)) for (let i = 0; i < W.n; i++) if (fin(hs.g[i])) W.g[i] = hs.g[i];
      if (Array.isArray(hs.T)) {
        const had = W.T.slice();
        W.T.fill(null);
        for (let i = 0; i + 5 < hs.T.length; i += 6) {
          const s = hs.T[i];
          if (!(s >= 0 && s < W.T.length) || !TT[hs.T[i + 1]]) continue;
          const o = had[s] && had[s].ty === hs.T[i + 1] ? had[s] : { fl: 0 };
          o.ty = hs.T[i + 1]; o.lv = clamp(hs.T[i + 2], 1, 3); o.o = hs.T[i + 3]; o.fc = hs.T[i + 4]; o.tg = hs.T[i + 5];
          W.T[s] = o;
          pend[s] = 0;
        }
      }
      const old = new Map();
      for (const e of W.E) old.set(e.id, e);
      const E = [];
      for (let i = 0; i + 5 < hs.E.length; i += 6) {
        const id = hs.E[i], ty = hs.E[i + 1], r = hs.E[i + 2], d = hs.E[i + 3] / 10, hp = hs.E[i + 4], fl = hs.E[i + 5];
        if (!ET[ty] || !W.M.routes[r]) continue;
        let e = old.get(id);
        if (!e || e.t !== ty) e = { id, t: ty, r, d, hp, mh: 100, sl: 0.55, slT: 0, psT: 0, x: 0, y: 0 };
        const tgt = d + speedOf(W, e) * W.sp * 0.05;
        if (Math.abs(e.d - tgt) > 0.7) e.d = tgt; else e.d += (tgt - e.d) * 0.4;
        e.hp = hp; e.slT = fl & 1 ? 1 : 0; e.psT = fl & 2 ? 1 : 0;
        place(W, e);
        E.push(e);
      }
      W.E = E;
      const me = seatMe();
      if (hs.A && fin(hs.A[me])) { const ack = hs.A[me]; cmdQ = cmdQ.filter((c) => c[0] > ack); }
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0 || ended) return;
          pubT = 0.1;
          hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(packHS());
        } else {
          const me = seatMe();
          if (me < 0) return;
          const sig = cmdQ.length ? cmdQ[cmdQ.length - 1][0] + ':' + cmdQ.length : '0';
          if (sig === lastSig && inT > 0) return;
          lastSig = sig; inT = cmdQ.length ? 0.4 : 2;
          api.net.publish({ k: key, c: cmdQ.slice(-8) });
        }
      } catch (e) {}
    }
    const qLeft = () => (W.qn != null ? W.qn : W.q.length);

    /* ----- my commands ----- */
    function canPlay() { return seatMe() >= 0 && W && st && st.ph === 'play' && !ended; }
    function doCmd(op, s, a) {
      const me = seatMe();
      if (!canPlay()) return false;
      const why = canDo(W, me, op, s, a);
      if (why !== 'ok') {
        if (why === 'gold') { api.toast('골드가 모자라요'); api.buzz(20); sfx('tick', 50); }
        else if (why === 'owner') api.toast('내 탑만 팔 수 있어요');
        return false;
      }
      if (op === 1 || op === 2) {
        const c = op === 1 ? TT[a].cost[0] : TT[W.T[s].ty].cost[W.T[s].lv];
        const S = W.M.S[s];
        floats.push({ x: S.x, y: S.y - 0.6, text: '−' + c, col: '#ffd76a', t: 0.9, T: 0.9 });
        puff(X(S.x), Y(S.y), '#d8ccb6', 10, lay.cs * 1.4, 0.45);
        sfx(op === 1 ? 'chip' : 'pop', 40); api.buzz(op === 1 ? 14 : 20);
      } else if (op === 3) {
        const T = W.T[s], S = W.M.S[s];
        floats.push({ x: S.x, y: S.y - 0.6, text: '+' + refundOf(T.ty, T.lv), col: '#ffd76a', t: 0.9, T: 0.9 });
        puff(X(S.x), Y(S.y), '#a39a8c', 12, lay.cs * 1.6, 0.5);
        sfx('chip', 40); api.buzz(14);
      } else if (op === 4) { const b = earlyBonus(W); if (b > 0) floats.push({ x: GW / 2, y: 1.2, text: '빨리 부르기 +' + Math.round(b * TEAM[W.n] / W.n), col: '#ffd76a', t: 1.4, T: 1.4, big: 1 }); api.buzz(15); }
      if (host()) { cmd(W, me, op, s, a); if (op === 1) prevFc[s] = -1; }
      else {
        cmdI++; cmdQ.push([cmdI, op, s, a | 0]); if (cmdQ.length > 12) cmdQ.shift(); inT = 0;
        if (op === 1) { pend[s] = 1.2; W.g[me] -= TT[a].cost[0]; }
        if (op === 2) W.g[me] -= TT[W.T[s].ty].cost[W.T[s].lv];
        if (op === 5) W.sp = a === 2 ? 2 : 1;
      }
      syncBar(true);
      return true;
    }

    /* ----- radial menu on a pad / tower ----- */
    const rad = L.h('div', { class: 'df-rad' });
    const card = L.h('div', { class: 'df-card', hidden: true });
    root.appendChild(rad); root.appendChild(card);
    let menu = null; // { s, kind: 'build'|'tower', pick, hov, arm, btns: [] }
    let lastPT = 'touch';
    function svgI(inner) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + inner + '</svg>'; }
    function openMenu(s) {
      if (!canPlay()) return;
      closeMenu(true);
      hideTips();
      const T = W.T[s];
      menu = { s, kind: T ? 'tower' : 'build', pick: -1, hov: -1, arm: 0, btns: [] };
      if (!T) {
        for (let ty = 0; ty < TT.length; ty++) {
          const b = L.h('button', { class: 'df-rb', type: 'button', 'aria-label': TT[ty].nm + ' ' + TT[ty].cost[0] + '골드', html: svgI(ICON[ty]) + '<b>' + TT[ty].cost[0] + '</b>' });
          b.addEventListener('pointerdown', (e) => { e.stopPropagation(); lastPT = e.pointerType || 'touch'; });
          b.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse' && menu) { menu.hov = ty; syncMenu(); } });
          b.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse' && menu && menu.hov === ty) { menu.hov = -1; syncMenu(); } });
          b.addEventListener('click', () => pickType(ty, lastPT === 'mouse'));
          menu.btns.push(b); rad.appendChild(b);
        }
      } else {
        const up = L.h('button', { class: 'df-rb', type: 'button', 'aria-label': '업그레이드' });
        up.addEventListener('pointerdown', (e) => { e.stopPropagation(); lastPT = e.pointerType || 'touch'; });
        up.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse' && menu) { menu.hov = 0; syncMenu(); } });
        up.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse' && menu) { menu.hov = -1; syncMenu(); } });
        up.addEventListener('click', () => pickUp(lastPT === 'mouse'));
        menu.btns.push(up); rad.appendChild(up);
        if (T.o === seatMe()) {
          const sell = L.h('button', { class: 'df-rb', type: 'button', 'aria-label': '팔기' });
          sell.addEventListener('pointerdown', (e) => { e.stopPropagation(); lastPT = e.pointerType || 'touch'; });
          sell.addEventListener('click', () => pickSell());
          menu.btns.push(sell); rad.appendChild(sell);
        }
      }
      placeMenu(); syncMenu();
      sfx('click', 30); api.buzz(8);
    }
    function closeMenu(quiet) {
      if (!menu) return;
      for (const b of menu.btns) b.remove();
      menu = null; card.hidden = true;
      if (!quiet) syncBar();
    }
    function placeMenu() {
      if (!menu || !lay) return;
      const S = W.M.S[menu.s], n = menu.btns.length, cs = lay.cs;
      const R = n > 2 ? Math.max(62, cs * 1.45) : Math.max(52, cs * 1.25);
      let cx = X(S.x), cy = Y(S.y);
      const m = R + 30;
      cx = clamp(cx, m, lay.w - m);
      cy = clamp(cy, lay.hudH + m - 6, lay.h - lay.barH - m);
      menu.cx = cx; menu.cy = cy; menu.R = R;
      menu.btns.forEach((b, i) => {
        const a = n > 2 ? -Math.PI / 2 + i * TAU / n : (i === 0 ? -Math.PI / 2 : Math.PI / 2);
        b.style.left = (cx + Math.cos(a) * R) + 'px'; b.style.top = (cy + Math.sin(a) * R) + 'px';
      });
      // the info card goes on the side away from the menu
      const below = cy < (lay.hudH + lay.h - lay.barH) / 2;
      card.style.top = below ? '' : (lay.hudH + 6) + 'px';
      card.style.bottom = below ? (lay.barH + 6) + 'px' : '';
    }
    function pickType(ty, direct) {
      if (!menu || menu.kind !== 'build') return;
      if (menu.pick === ty || direct) {
        if (doCmd(1, menu.s, ty)) closeMenu();
        return;
      }
      menu.pick = ty; sfx('tick', 30); api.buzz(6);
      syncMenu();
    }
    function pickUp(direct) {
      if (!menu || menu.kind !== 'tower') return;
      const T = W.T[menu.s];
      if (!T) { closeMenu(); return; }
      if (T.lv >= 3) { api.toast('가장 높은 단계예요'); return; }
      if (menu.pick === 0 || direct) { if (doCmd(2, menu.s, 0)) closeMenu(); return; }
      menu.pick = 0; menu.arm = 0; sfx('tick', 30); api.buzz(6); syncMenu();
    }
    function pickSell() {
      if (!menu || menu.kind !== 'tower') return;
      if (menu.arm) { if (doCmd(3, menu.s, 0)) closeMenu(); return; }
      menu.arm = 1; menu.pick = -1; sfx('tick', 30); api.buzz(10); syncMenu();
    }
    function stat(ty, lv) {
      const D = TT[ty], i = lv - 1, a = [];
      if (D.pd) a.push('독 ' + D.pd[i] + '/초 × ' + D.pt[i] + '초');
      else a.push('공격 ' + D.dmg[i] + (D.ch ? ' (+' + D.ch[i] + '번 튐)' : ''));
      a.push('초당 ' + D.rate[i] + '발');
      a.push('사거리 ' + D.rg[i]);
      if (D.slow) a.push('느리게 ' + Math.round((1 - D.slow[i]) * 100) + '%');
      if (D.spl && D.spl[i]) a.push('범위 ' + D.spl[i]);
      return a.join(' · ');
    }
    function syncMenu() {
      if (!menu) return;
      const me = seatMe(), g = W.g[me] || 0, T = W.T[menu.s];
      if (menu.kind === 'build') {
        if (T) { closeMenu(); return; }
        menu.btns.forEach((b, ty) => { b.classList.toggle('on', menu.pick === ty); b.classList.toggle('no', g + 1e-6 < TT[ty].cost[0]); });
        const ty = menu.hov >= 0 ? menu.hov : menu.pick;
        card.innerHTML = '';
        if (ty < 0) {
          card.append(L.h('h4', { text: '탑 고르기' }), L.h('p', { text: lastPT === 'mouse' ? '탑에 마우스를 올리면 사거리가 보이고, 누르면 지어요.' : '한 번 누르면 사거리가 보여요. 한 번 더 누르면 지어요.' }),
            L.h('p', { class: 'st', text: '내 골드 ' + Math.floor(g) }));
        } else {
          const D = TT[ty], short = g + 1e-6 < D.cost[0];
          card.append(L.h('h4', { text: D.nm + ' · ' + D.cost[0] + '골드' }), L.h('p', { text: D.d }), L.h('p', { class: 'st', text: stat(ty, 1) }),
            L.h('p', { class: short ? 'warn' : '', text: short ? '골드가 ' + Math.ceil(D.cost[0] - g) + ' 모자라요' : (lastPT === 'mouse' || menu.hov >= 0 ? '누르면 지어요' : '한 번 더 누르면 지어요') }));
        }
      } else {
        if (!T) { closeMenu(); return; }
        const D = TT[T.ty], up = menu.btns[0], sell = menu.btns[1];
        const upc = T.lv < 3 ? D.cost[T.lv] : 0;
        up.innerHTML = svgI(ICON_UP) + '<b>' + (T.lv < 3 ? upc : 'MAX') + '</b>';
        up.classList.toggle('no', T.lv >= 3 || g + 1e-6 < upc);
        up.classList.toggle('on', menu.pick === 0);
        up.setAttribute('aria-label', T.lv < 3 ? '업그레이드 ' + upc + '골드' : '최고 단계');
        if (sell) { sell.innerHTML = svgI(ICON_SELL) + '<b>' + (menu.arm ? '팔기?' : '+' + refundOf(T.ty, T.lv)) + '</b>'; sell.classList.toggle('arm', !!menu.arm); }
        card.innerHTML = '';
        const head = L.h('h4', null, L.h('span', { class: 'dot', style: { background: P(T.o).color } }), D.nm + ' ' + T.lv + '단계' + (T.o === me ? '' : ' · ' + name(T.o)));
        card.append(head);
        if (menu.arm) card.append(L.h('p', { class: 'warn', text: '한 번 더 누르면 팔아요 (+' + refundOf(T.ty, T.lv) + '골드, 쓴 골드의 70%)' }));
        else if (T.lv < 3) {
          card.append(L.h('p', { class: 'st', text: '지금 ' + stat(T.ty, T.lv) }), L.h('p', { class: 'st', text: '다음 ' + stat(T.ty, T.lv + 1) }));
          const short = g + 1e-6 < upc;
          card.append(L.h('p', { class: short ? 'warn' : '', text: short ? '업그레이드 ' + upc + '골드 · ' + Math.ceil(upc - g) + ' 모자라요' : (menu.pick === 0 ? '한 번 더 누르면 ' + upc + '골드로 업그레이드' : (T.o === me ? '' : '친구 탑도 내 골드로 키울 수 있어요')) }));
        } else card.append(L.h('p', { class: 'st', text: stat(T.ty, T.lv) }), L.h('p', { text: '가장 높은 단계예요' }));
      }
      card.hidden = false;
    }

    /* ----- tips before the first wave (realtime: no tutorial) ----- */
    let tips = null;
    function showTips() {
      hideTips();
      const items = [
        '돌 자리를 누르면 탑 메뉴가 떠요. 한 번 눌러 사거리를 보고, 한 번 더 누르면 지어요.',
        '지은 탑을 누르면 업그레이드·팔기. ' + (st.n > 1 ? '친구 탑도 내 골드로 키울 수 있어요.' : '박쥐·용은 하늘을 날아서 대포·투석기로는 못 맞혀요.'),
        '「지금!」으로 다음 웨이브를 일찍 부르면 보너스 골드를 받아요.',
      ];
      tips = L.h('div', { class: 'df-tips' }, L.h('h3', { text: '성을 지켜요!' }), L.h('ol', null, items.map((t) => L.h('li', { text: t }))),
        L.h('button', { type: 'button', text: '알겠어요', onclick() { hideTips(); api.sfx('click'); } }));
      tips.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(tips);
    }
    function hideTips() { if (tips) { tips.remove(); tips = null; } }

    /* ----- input on the board ----- */
    function padAt(px, py) {
      if (!W || !lay) return -1;
      let best = -1, bd = Math.max(26, lay.cs * 0.95);
      W.M.S.forEach((S, i) => { const d = Math.hypot(px - X(S.x), py - Y(S.y)); if (d < bd) { bd = d; best = i; } });
      return best;
    }
    function onDown(e) {
      if (tips) { hideTips(); e.preventDefault(); return; }
      if (!canPlay()) return;
      const p = cv.local(e), s = padAt(p.x, p.y);
      lastPT = e.pointerType || 'touch';
      e.preventDefault();
      if (s >= 0 && (!menu || menu.s !== s)) { kc = s; openMenu(s); return; }
      if (menu) closeMenu();
    }
    let hovPad = -1;
    function onMove(e) { if (e.pointerType !== 'mouse' || !W || !lay) return; const p = cv.local(e); hovPad = padAt(p.x, p.y); cv.cv.style.cursor = hovPad >= 0 ? 'pointer' : ''; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- keyboard / gamepad (rebindable in 「⌨ 조작 설정」) ----- */
    let kc = -1;
    const KMOVE = { cl: [-1, 0], cr: [1, 0], cu: [0, -1], cd: [0, 1] };
    function kcMove(dx, dy) {
      const M = W.M;
      if (kc < 0 || !M.S[kc]) { kc = 0; for (let i = 0; i < M.S.length; i++) if (M.S[i].r > M.S[kc].r) kc = i; return; }
      const p = M.S[kc];
      let best = -1, bs = 1e9;
      M.S.forEach((q, i) => {
        if (i === kc) return;
        const vx = q.x - p.x, vy = q.y - p.y, d = Math.hypot(vx, vy), c = (vx * dx + vy * dy) / d;
        if (c < 0.35) return;
        const sc = d * (1 + 2.2 * (1 - c));
        if (sc < bs) { bs = sc; best = i; }
      });
      if (best >= 0) { kc = best; sfx('tick', 30); }
    }
    function menuStep(dir) {
      if (!menu) return;
      if (menu.kind === 'build') { menu.pick = ((menu.pick < 0 ? (dir > 0 ? -1 : 0) : menu.pick) + dir + TT.length) % TT.length; }
      else { menu.pick = 0; menu.arm = 0; }
      lastPT = 'key'; sfx('tick', 30); syncMenu();
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || seatMe() < 0) return;
      if (tips) { hideTips(); if (id === 'ok' || id === 'back') return; }
      if (id === 'pause') { togglePause(); return; }
      if (id === 'speed') { toggleSpeed(); return; }
      if (id === 'next') { callNext(); return; }
      if (!canPlay()) return;
      if (menu) {
        if (id === 'back') { closeMenu(); sfx('click', 30); return; }
        if (id === 'cl' || id === 'cu') { menuStep(-1); return; }
        if (id === 'cr' || id === 'cd') { menuStep(1); return; }
        const ti = ['t1', 't2', 't3', 't4', 't5', 't6'].indexOf(id);
        if (ti >= 0 && menu.kind === 'build') { if (menu.pick === ti) pickType(ti, true); else { menu.pick = ti; lastPT = 'key'; syncMenu(); } return; }
        if (id === 'ok') { if (menu.kind === 'build') { if (menu.pick >= 0) pickType(menu.pick, true); else menuStep(1); } else if (menu.arm) pickSell(); else pickUp(true); return; }
        if (id === 'up' && menu.kind === 'tower') { pickUp(true); return; }
        if (id === 'sell' && menu.kind === 'tower') { pickSell(); return; }
        return;
      }
      if (KMOVE[id]) { kcMove(KMOVE[id][0], KMOVE[id][1]); return; }
      if (kc < 0) kcMove(0, 0);
      const ti = ['t1', 't2', 't3', 't4', 't5', 't6'].indexOf(id);
      if (id === 'ok') { openMenu(kc); lastPT = 'key'; return; }
      if (ti >= 0 && !W.T[kc]) { openMenu(kc); if (menu) { menu.pick = ti; lastPT = 'key'; syncMenu(); } return; }
      if ((id === 'up' || id === 'sell') && W.T[kc]) { openMenu(kc); if (id === 'up') pickUp(false); else pickSell(); }
    }) : () => {};

    /* ----- bottom bar ----- */
    const infoB = L.h('b'), infoS = L.h('span');
    const infoBtn = L.h('button', { class: 'df-info', type: 'button', 'aria-label': '웨이브 정보' }, infoB, infoS);
    const nextLbl = L.h('span', { text: '지금!' }), nextSub = L.h('small');
    const nextBtn = L.h('button', { class: 'df-next', type: 'button', 'aria-label': '다음 웨이브 지금 부르기' }, nextLbl, nextSub);
    const spdBtn = L.h('button', { class: 'df-sq', type: 'button', 'aria-label': '빠르기', text: '×1' });
    const pauBtn = L.h('button', { class: 'df-sq', type: 'button', 'aria-label': '잠깐 멈춤', text: 'Ⅱ' });
    const bar = L.h('div', { class: 'df-bar' }, infoBtn, nextBtn, spdBtn, pauBtn);
    bar.addEventListener('pointerdown', (e) => { e.stopPropagation(); hideTips(); });
    root.appendChild(bar);
    infoBtn.onclick = () => showWaveCard();
    nextBtn.onclick = () => callNext();
    spdBtn.onclick = () => toggleSpeed();
    pauBtn.onclick = () => togglePause();
    function callNext() {
      if (!canPlay()) return;
      if (!(W.cd > 0 && W.w < W.nw)) { api.toast(W.w >= W.nw ? '마지막 웨이브예요' : '지금 웨이브가 다 나온 뒤에 부를 수 있어요'); return; }
      closeMenu(true);
      doCmd(4, 0, 0);
    }
    function toggleSpeed() { if (!canPlay()) return; doCmd(5, 0, W.sp === 2 ? 1 : 2); sfx('click', 30); }
    function togglePause() { if (api.online || !canPlay()) return; paused = !paused; api.sfx('click'); api.buzz(8); syncBar(true); }
    let waveCardT = 0;
    function showWaveCard() {
      if (!W) return;
      closeMenu(true);
      const w = W.cd > 0 || W.w === 0 ? Math.min(W.nw, W.w + 1) : W.w;
      card.innerHTML = '';
      card.append(L.h('h4', { text: (w === W.w ? '지금 웨이브 ' : '다음 웨이브 ') + w + ' / ' + W.nw }));
      for (const [ty, n] of waveInfo(w, W.nw)) card.append(L.h('p', null, L.h('b', { text: ET[ty].nm + ' ×' + n }), ' — ' + ETIP[ty]));
      card.style.top = ''; card.style.bottom = (lay.barH + 6) + 'px';
      card.hidden = false; waveCardT = 4;
      sfx('click', 30);
    }
    let barSig = '';
    function waveText(w) {
      return waveInfo(w, W.nw).map(([ty, n]) => (ET[ty].boss ? '⚠' + ET[ty].nm : ET[ty].nm + ' ' + n)).join(' · ');
    }
    function syncBar(force) {
      if (!W || !st) return;
      const me = seatMe(), done = st.ph === 'done' || ended;
      let a, b;
      if (W.w === 0) { a = '첫 웨이브까지 ' + Math.ceil(Math.max(0, W.cd)) + '초'; b = waveText(1); }
      else if (qLeft() > 0) { a = '웨이브 ' + W.w + ' / ' + W.nw + ' 오는 중'; b = waveText(W.w); }
      else if (W.cd > 0) { a = '다음 웨이브 ' + (W.w + 1) + ' · ' + Math.ceil(W.cd) + '초'; b = waveText(W.w + 1); }
      else { a = '마지막 웨이브! 남은 적 ' + W.E.length; b = '모두 막으면 승리'; }
      if (paused) a = '잠깐 멈춤 · ' + a;
      const can = !done && W.cd > 0 && W.w < W.nw, bonus = can ? Math.round(earlyBonus(W) * TEAM[W.n] / W.n) : 0;
      const sig = [a, b, can, bonus, W.sp, paused, me, done].join('|');
      if (!force && sig === barSig) return;
      barSig = sig;
      infoB.textContent = a; infoS.textContent = b;
      nextBtn.disabled = !can || me < 0;
      nextLbl.textContent = W.w === 0 ? '바로 시작' : '지금!';
      nextSub.textContent = can ? '+' + bonus + '골드' : qLeft() > 0 ? '오는 중' : '—';
      spdBtn.textContent = '×' + W.sp; spdBtn.classList.toggle('on', W.sp === 2);
      spdBtn.disabled = me < 0 || done;
      pauBtn.hidden = api.online || me < 0; pauBtn.textContent = paused ? '▶' : 'Ⅱ'; pauBtn.classList.toggle('on', paused);
      pauBtn.setAttribute('aria-label', paused ? '계속하기' : '잠깐 멈춤');
      nextBtn.hidden = me < 0; spdBtn.hidden = me < 0;
      bar.hidden = done;
    }

    /* ----- main loop ----- */
    function frame(rdt) {
      if (!st || !W) return;
      const dt = rdt * SPD();
      // pause while the rules sheet is open or the app is hidden (local only)
      if (!api.online && !ended) { const auto2 = document.hidden || !!document.querySelector('.overlay.rules-ov'); if (auto2 !== !!frame.ap) { frame.ap = auto2; if (auto2 && !paused) { paused = true; frame.byAuto = 1; syncBar(true); } else if (!auto2 && frame.byAuto) { paused = false; frame.byAuto = 0; syncBar(true); } } }
      if (host()) hostTick(dt);
      else {
        pollGuest();
        if (st.ph === 'play') {
          const gdt = dt * W.sp;
          if (auto() && seatMe() >= 0 && !ended) { // test autopilot for a guest seat: think on the mirror, send commands
            acc += gdt;
            while (acc >= STEP) { acc -= STEP; const c = aiThink(W, seatMe(), aiMem[seatMe()] || (aiMem[seatMe()] = {}), 2); if (c) doCmd(c[0], c[1], c[2]); }
          }
          if (W.cd > 0) W.cd = Math.max(0.01, W.cd - gdt);
          for (const e of W.E) { e.d = Math.min(e.d + speedOf(W, e) * gdt, W.M.routes[e.r].L); place(W, e); }
        }
      }
      watch();
      for (let i = shots.length - 1; i >= 0; i--) {
        const q = shots[i];
        q.t += (paused ? 0 : rdt) * SPD() * W.sp;
        if (q.ty !== 1 && q.ty !== 4) { const e = findE(q.tid); if (e) { q.tx = e.x; q.tyy = e.y; } }
        if (q.t >= q.T) {
          shots.splice(i, 1);
          const x = X(q.tx), y = Y(q.tyy) - (q.air ? lay.cs * 0.32 : 0);
          if (q.ty === 1 || q.ty === 4) { const R = TT[q.ty].spl[q.lv - 1] * lay.cs; fx.push({ k: 'boom', x, y, r: R, t: 0.4, T: 0.4 }); puff(x, y, '#ffb347', q.ty === 4 ? 14 : 9, lay.cs * 2, 0.4); }
          else if (q.ty === 2) fx.push({ k: 'ice', x, y, r: lay.cs * Math.max(0.4, TT[2].spl[q.lv - 1]), t: 0.35, T: 0.35 });
          else if (q.ty === 3) fx.push({ k: 'pois', x, y, r: lay.cs * 0.35, t: 0.35, T: 0.35 });
        }
      }
      for (let i = fx.length - 1; i >= 0; i--) { fx[i].t -= rdt; if (fx[i].t <= 0) fx.splice(i, 1); }
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.9; p.vy = p.vy * 0.9 + 40 * rdt; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let s = 0; s < pend.length; s++) if (pend[s] > 0) pend[s] -= rdt;
      if (banner) { banner.t -= rdt; if (banner.t <= 0) banner = null; }
      shake = Math.max(0, shake - rdt * 2.5); flash = Math.max(0, flash - rdt * 2.2);
      if (waveCardT > 0) { waveCardT -= rdt; if (waveCardT <= 0 && !menu) card.hidden = true; }
      if (menu) syncMenuLite();
      syncBar(false);
      publish(rdt);
    }
    let menuSig = '';
    function syncMenuLite() { // gold or tower changed under an open menu
      const me = seatMe(), T = W.T[menu.s];
      const sig = Math.floor(W.g[me] || 0) + ':' + (T ? T.ty + '.' + T.lv : '-');
      if (sig !== menuSig) { menuSig = sig; if ((menu.kind === 'build') !== !T) closeMenu(); else syncMenu(); }
    }

    function drawRange(s, rg, dashed, col) {
      const S = W.M.S[s], x = X(S.x), y = Y(S.y), r = rg * lay.cs;
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU);
      ctx.fillStyle = col ? hexA(col, 0.1) : 'rgba(227,174,69,.1)'; ctx.fill();
      ctx.setLineDash(dashed ? [6, 5] : []); ctx.lineWidth = 2; ctx.strokeStyle = col || 'rgba(255,227,166,.85)'; ctx.stroke(); ctx.setLineDash([]);
    }
    function draw(nowMs) {
      cv.clear();
      const w = cv.w, h = cv.h, t = nowMs / 1000;
      if (!W || !st) { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h); return; }
      if (!lay || lay.w !== w || lay.h !== h) layout();
      if (bgKey !== lay.key || !bg) paintBG();
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 6 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 6 : 0;
      ctx.save(); ctx.translate(sx, sy);
      ctx.drawImage(bg, 0, 0, w, h);
      const cs = lay.cs, me = seatMe(), g = W.g[me] || 0;
      // pads: free ones glow when I can build
      const canB = canPlay() && g + 1e-6 >= TT[0].cost[0];
      for (let s = 0; s < W.M.S.length; s++) {
        if (W.T[s]) continue;
        const S = W.M.S[s], x = X(S.x), y = Y(S.y);
        if (pend[s] > 0) { ctx.beginPath(); ctx.arc(x, y, cs * 0.3, 0, TAU); ctx.strokeStyle = 'rgba(255,227,166,.8)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 2; ctx.stroke(); ctx.setLineDash([]); continue; }
        if (canB) { const a = 0.25 + 0.2 * Math.sin(t * 3 + s * 0.7); ctx.beginPath(); ctx.arc(x, y, cs * 0.44, 0, TAU); ctx.strokeStyle = 'rgba(255,227,166,' + a.toFixed(2) + ')'; ctx.lineWidth = 2; ctx.stroke(); }
        ctx.fillStyle = 'rgba(255,227,166,' + (canB ? 0.75 : 0.35) + ')'; ctx.font = '700 ' + Math.round(cs * 0.36) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('+', x, y + 0.5);
      }
      // range previews
      if (menu) {
        const T = W.T[menu.s];
        if (menu.kind === 'build') { const ty = menu.hov >= 0 ? menu.hov : menu.pick; if (ty >= 0) { drawRange(menu.s, TT[ty].rg[0], false); if (TT[ty].mn) drawRange(menu.s, TT[ty].mn, true, 'rgba(238,106,85,.7)'); } }
        else if (T) { drawRange(menu.s, TT[T.ty].rg[T.lv - 1], false, P(T.o).color); if (T.lv < 3 && (menu.pick === 0 || menu.hov === 0)) drawRange(menu.s, TT[T.ty].rg[T.lv], true); }
        const S = W.M.S[menu.s];
        ctx.beginPath(); ctx.arc(X(S.x), Y(S.y), cs * 0.5, 0, TAU); ctx.strokeStyle = '#ffe3a6'; ctx.lineWidth = 2.5; ctx.stroke();
      } else if (hovPad >= 0 && W.T[hovPad]) { const T = W.T[hovPad]; drawRange(hovPad, TT[T.ty].rg[T.lv - 1], true, P(T.o).color); }
      // towers, ground enemies, flyers (monsters come out of the cave: clip them to the board)
      for (let s = 0; s < W.T.length; s++) if (W.T[s]) drawTower(W.T[s], s, t);
      const order = W.E.slice().sort((a, b) => a.y - b.y);
      ctx.save(); ctx.beginPath(); ctx.rect(lay.ox, lay.oy, lay.mw, lay.mh); ctx.clip();
      for (const e of order) if (!ET[e.t].air) drawEnemy(e, t);
      ctx.restore();
      for (const q of shots) drawShot(q);
      ctx.save(); ctx.beginPath(); ctx.rect(lay.ox, lay.oy - lay.cs, lay.mw, lay.mh + lay.cs); ctx.clip();
      for (const e of order) if (ET[e.t].air) drawEnemy(e, t);
      ctx.restore();
      for (const f of fx) drawFx(f);
      for (const p of parts) { ctx.globalAlpha = clamp(p.t * 2, 0, 1); ctx.fillStyle = p.c; ctx.fillRect(p.x - p.r / 2, p.y - p.r / 2, p.r, p.r); }
      ctx.globalAlpha = 1;
      // castle hit flash
      if (flash > 0) {
        const c = W.M.castle, x = X(c.x), y = Y(c.y) - cs * 0.4;
        const gl = ctx.createRadialGradient(x, y, 2, x, y, cs * 1.8);
        gl.addColorStop(0, 'rgba(238,80,60,' + (0.6 * flash).toFixed(2) + ')'); gl.addColorStop(1, 'rgba(238,80,60,0)');
        ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, cs * 1.8, 0, TAU); ctx.fill();
      }
      // keyboard cursor
      if (kc >= 0 && W.M.S[kc] && !menu && kbUsed()) {
        const S = W.M.S[kc];
        ctx.beginPath(); ctx.arc(X(S.x), Y(S.y), cs * 0.55 + Math.sin(t * 6) * 2, 0, TAU); ctx.strokeStyle = '#fff6e6'; ctx.lineWidth = 2.5; ctx.setLineDash([5, 4]); ctx.stroke(); ctx.setLineDash([]);
      }
      // floats
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (const f of floats) {
        const k = f.t / f.T, y = Y(f.y) - (1 - k) * cs * 0.8;
        ctx.globalAlpha = clamp(k * 1.6, 0, 1);
        ctx.font = '700 ' + (f.big ? 15 : 12) + 'px ' + MONO; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(12,8,4,.8)'; ctx.strokeText(f.text, X(f.x), y);
        ctx.fillStyle = f.col; ctx.fillText(f.text, X(f.x), y);
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      drawHUD(t);
      if (banner) drawBanner();
      if (paused && !ended) {
        ctx.fillStyle = 'rgba(12,8,16,.45)'; ctx.fillRect(0, lay.hudH, w, h - lay.hudH - lay.barH);
        ctx.font = '28px ' + DISP; ctx.fillStyle = '#ffe3a6'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('잠깐 멈춤', w / 2, lay.oy + lay.mh / 2);
      }
    }
    let kbT = 0;
    const kbUsed = () => performance.now() - kbT < 15000;
    function drawShot(q) {
      const k = clamp(q.t / q.T, 0, 1), cs = lay.cs;
      const x0 = X(q.sx), y0 = Y(q.sy), x1 = X(q.tx), y1 = Y(q.tyy) - (q.air ? cs * 0.32 : 0);
      const x = x0 + (x1 - x0) * k;
      const arc = q.ty === 4 ? cs * 2.2 : q.ty === 1 ? cs * 0.8 : q.ty === 3 ? cs * 0.5 : 0;
      const y = y0 + (y1 - y0) * k - Math.sin(k * Math.PI) * arc;
      if (q.ty === 0) {
        const a = Math.atan2(y1 - y0, x1 - x0);
        ctx.strokeStyle = '#efe2c4'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x - Math.cos(a) * cs * 0.22, y - Math.sin(a) * cs * 0.22); ctx.lineTo(x, y); ctx.stroke();
      } else if (q.ty === 1) {
        ctx.beginPath(); ctx.arc(x, y, Math.max(2.5, cs * 0.1), 0, TAU); ctx.fillStyle = '#1b1a1e'; ctx.fill();
      } else if (q.ty === 2) {
        ctx.beginPath(); ctx.arc(x, y, Math.max(2.5, cs * 0.09), 0, TAU); ctx.fillStyle = '#bfefff'; ctx.fill(); ctx.strokeStyle = 'rgba(74,166,216,.8)'; ctx.lineWidth = 1; ctx.stroke();
      } else if (q.ty === 3) {
        ctx.beginPath(); ctx.arc(x, y, Math.max(2.5, cs * 0.09), 0, TAU); ctx.fillStyle = '#8cf05a'; ctx.fill();
      } else if (q.ty === 4) {
        const sx = x0 + (x1 - x0) * k, sy = y0 + (y1 - y0) * k;
        ctx.beginPath(); ctx.ellipse(sx, sy + cs * 0.2, cs * 0.14, cs * 0.06, 0, 0, TAU); ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fill();
        ctx.beginPath(); ctx.arc(x, y, Math.max(3.5, cs * 0.16), 0, TAU); ctx.fillStyle = '#8a8378'; ctx.fill(); ctx.strokeStyle = '#4a443c'; ctx.lineWidth = 1; ctx.stroke();
      }
    }
    function drawFx(f) {
      const k = f.t / f.T;
      if (f.k === 'boom') {
        ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (1 - k * 0.6), 0, TAU); ctx.fillStyle = 'rgba(255,170,70,' + (0.35 * k).toFixed(2) + ')'; ctx.fill();
        ctx.strokeStyle = 'rgba(255,220,150,' + (0.8 * k).toFixed(2) + ')'; ctx.lineWidth = 2; ctx.stroke();
      } else if (f.k === 'ice') {
        ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (1.2 - k * 0.6), 0, TAU); ctx.strokeStyle = 'rgba(170,230,255,' + (0.9 * k).toFixed(2) + ')'; ctx.lineWidth = 2; ctx.stroke();
      } else if (f.k === 'pois') {
        ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (1.3 - k * 0.6), 0, TAU); ctx.fillStyle = 'rgba(120,230,70,' + (0.3 * k).toFixed(2) + ')'; ctx.fill();
      } else if (f.k === 'bolt') {
        ctx.strokeStyle = 'rgba(200,220,255,' + k.toFixed(2) + ')'; ctx.lineWidth = 2.2; ctx.lineJoin = 'round';
        ctx.beginPath();
        for (let i = 0; i < f.pts.length - 1; i++) {
          const ax = X(f.pts[i][0]), ay = Y(f.pts[i][1]), bx = X(f.pts[i + 1][0]), by = Y(f.pts[i + 1][1]);
          ctx.moveTo(ax, ay);
          for (let j = 1; j <= 4; j++) { const u = j / 5; ctx.lineTo(ax + (bx - ax) * u + (Math.random() - 0.5) * lay.cs * 0.3, ay + (by - ay) * u + (Math.random() - 0.5) * lay.cs * 0.3); }
          ctx.lineTo(bx, by);
        }
        ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.8 * k).toFixed(2) + ')'; ctx.lineWidth = 1; ctx.stroke();
      }
    }
    function drawHUD(t) {
      const w = lay.w, me = seatMe(), n = W.n;
      const g0 = ctx.createLinearGradient(0, 0, 0, lay.hudH);
      g0.addColorStop(0, 'rgba(23,19,31,.98)'); g0.addColorStop(1, 'rgba(23,19,31,.88)');
      ctx.fillStyle = g0; ctx.fillRect(0, 0, w, lay.hudH);
      ctx.fillStyle = 'rgba(227,174,69,.35)'; ctx.fillRect(0, lay.hudH - 1, w, 1);
      ctx.textBaseline = 'middle';
      // castle hp
      const low = W.hp <= 6;
      heart(16, 22, 8.5, low && Math.sin(t * 8) > 0 ? '#ff8a7a' : '#ee6a55');
      ctx.font = '700 17px ' + MONO; ctx.textAlign = 'left'; ctx.fillStyle = low ? '#ff9a8a' : '#f2e9d8';
      ctx.fillText(String(W.hp), 30, 23);
      const hw = ctx.measureText(String(W.hp)).width;
      ctx.font = '600 11px ' + MONO; ctx.fillStyle = '#ab9fb8'; ctx.fillText('/' + HP0, 32 + hw, 25);
      // wave
      ctx.textAlign = 'center';
      ctx.font = '17px ' + DISP; ctx.fillStyle = '#ffe3a6';
      ctx.fillText(W.w === 0 ? '준비 시간' : '웨이브 ' + W.w + ' / ' + W.nw, w / 2, 16);
      ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#ab9fb8';
      ctx.fillText(MAPS[W.mp].name + ' · ' + ['', '쉬움', '보통', '어려움'][W.df] + (W.sp === 2 ? ' · ×2' : ''), w / 2, 33, w - 190);
      // my gold (or team gold when watching)
      const gv = me >= 0 ? Math.floor(W.g[me] + 1e-6) : Math.floor(W.g.reduce((a, b) => a + b, 0));
      ctx.textAlign = 'right'; ctx.font = '700 17px ' + MONO; ctx.fillStyle = '#ffd76a';
      ctx.fillText(String(gv), w - 12, 23);
      coin(w - 22 - ctx.measureText(String(gv)).width, 22, 7.5);
      // teammates
      if (n > 1) {
        const cw = (w - 16) / n;
        for (let s = 0; s < n; s++) {
          const x = 8 + s * cw, y = 50;
          rr(ctx, x + 2, y - 8, cw - 4, 16, 8); ctx.fillStyle = s === me ? 'rgba(227,174,69,.18)' : 'rgba(46,38,64,.8)'; ctx.fill();
          ctx.beginPath(); ctx.arc(x + 11, y, 4.5, 0, TAU); ctx.fillStyle = P(s).color; ctx.fill();
          ctx.textAlign = 'left'; ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#f2e9d8';
          const gs = String(Math.floor(W.g[s] + 1e-6));
          ctx.font = '700 10.5px ' + MONO; const gw = ctx.measureText(gs).width;
          ctx.fillStyle = '#ffd76a'; ctx.textAlign = 'right'; ctx.fillText(gs, x + cw - 9, y + 0.5);
          ctx.textAlign = 'left'; ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#f2e9d8';
          ctx.fillText(s === me ? '나' : name(s), x + 19, y + 0.5, Math.max(10, cw - 34 - gw));
        }
      }
    }
    function heart(x, y, r, c) {
      ctx.beginPath(); ctx.moveTo(x, y + r * 0.9);
      ctx.bezierCurveTo(x - r * 1.4, y - r * 0.1, x - r * 0.7, y - r * 1.2, x, y - r * 0.45);
      ctx.bezierCurveTo(x + r * 0.7, y - r * 1.2, x + r * 1.4, y - r * 0.1, x, y + r * 0.9);
      ctx.fillStyle = c; ctx.fill();
    }
    function coin(x, y, r) {
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fillStyle = '#e3ae45'; ctx.fill(); ctx.strokeStyle = '#7a5410'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y, r * 0.55, 0, TAU); ctx.strokeStyle = 'rgba(122,84,16,.7)'; ctx.lineWidth = 1; ctx.stroke();
    }
    function drawBanner() {
      const k = banner.t / banner.T, w = lay.w, y = lay.oy + lay.mh * 0.36;
      const a = Math.min(1, k * 3, (1 - k) * 8 + 0.2);
      ctx.globalAlpha = clamp(a, 0, 1);
      const bh = banner.b ? 66 : 46;
      ctx.fillStyle = banner.boss ? 'rgba(80,16,12,.82)' : 'rgba(23,19,31,.82)'; ctx.fillRect(0, y - bh / 2, w, bh);
      ctx.fillStyle = banner.boss ? '#ee6a55' : '#e3ae45'; ctx.fillRect(0, y - bh / 2, w, 2); ctx.fillRect(0, y + bh / 2 - 2, w, 2);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '26px ' + DISP; ctx.fillStyle = '#fff1d0'; ctx.fillText(banner.a, w / 2, y - (banner.b ? 11 : 0), w - 20);
      if (banner.b) { ctx.font = '600 12.5px ' + FONT; ctx.fillStyle = '#ffd9a0'; ctx.fillText(banner.b, w / 2, y + 17, w - 20); }
      ctx.globalAlpha = 1;
    }

    cv.cv._dbg = () => ({ W, lay, menu, packHS, st, open: (s) => openMenu(s), pick: pickType, up: pickUp, sell: pickSell, next: callNext, speed: toggleSpeed, pause: togglePause });
    const stopLoop = U.loop((rdt, nowMs) => {
      try { frame(rdt); } catch (e) { console.error(e); }
      try { draw(nowMs); } catch (e) { console.error(e); }
    });
    const offKb = api.input ? api.input.on(() => { kbT = performance.now(); }) : () => {};

    return {
      update(next) {
        if (!next) return;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; startGame(); }
        if (st.ph === 'done') { ended = true; closeMenu(true); hideTips(); }
        syncBar(true);
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn(); offKb();
        hideTips();
        bar.remove(); rad.remove(); card.remove(); styleEl.remove();
        cv.destroy();
      },
    };
  }

  /* ---------- helpers ---------- */
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  L.register({
    id: 'defense', name: '성 지키기 협동', tag: '협동 타워 디펜스', cat: '아케이드',
    blurb: '몬스터가 길을 따라 성으로 몰려와요. 다 같이 돌 자리에 탑을 짓고 키워서 마지막 웨이브까지 성을 지키면 승리!',
    tint: '#2f4a1c',
    icon: '<rect x="7" y="31" width="42" height="19" rx="2" fill="currentColor"/><path d="M7 32v-7h6v7zM18 32v-7h6v7zM32 32v-7h6v7zM43 32v-7h6v7z" fill="currentColor"/><rect x="21" y="15" width="14" height="18" fill="currentColor"/><path d="M19 16l9-10 9 10z" fill="currentColor"/><path d="M24 50v-7a4 4 0 0 1 8 0v7z" fill="#000" opacity=".4"/><path d="M28 6V1l6 2.5-6 2.5" fill="currentColor"/><path d="M3 9l12 6" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><path d="M16 15.6l-5.4.2 2.8-4.8z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'cu', label: '커서 ↑ / 메뉴 앞으로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'cd', label: '커서 ↓ / 메뉴 뒤로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'cl', label: '커서 ← / 메뉴 앞으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'cr', label: '커서 → / 메뉴 뒤로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'ok', label: '고르기 · 짓기', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'back', label: '메뉴 닫기', keys: ['Escape', 'Backspace'], pad: ['b'] },
      { id: 't1', label: '궁수 탑', keys: ['Digit1', 'Numpad1'], pad: [] },
      { id: 't2', label: '대포', keys: ['Digit2', 'Numpad2'], pad: [] },
      { id: 't3', label: '얼음 마법탑', keys: ['Digit3', 'Numpad3'], pad: [] },
      { id: 't4', label: '독 탑', keys: ['Digit4', 'Numpad4'], pad: [] },
      { id: 't5', label: '투석기', keys: ['Digit5', 'Numpad5'], pad: [] },
      { id: 't6', label: '번개탑', keys: ['Digit6', 'Numpad6'], pad: [] },
      { id: 'up', label: '업그레이드', keys: ['KeyU'], pad: ['rb'] },
      { id: 'sell', label: '팔기 (두 번)', keys: ['KeyX'], pad: ['lb'] },
      { id: 'next', label: '다음 웨이브 지금 부르기', keys: ['KeyN'], pad: ['y'] },
      { id: 'speed', label: '빠르기 ×1 / ×2', keys: ['KeyF'], pad: ['x'] },
      { id: 'pause', label: '잠깐 멈춤 (혼자 할 때)', keys: ['KeyP'], pad: ['start'] },
    ],
    options: [
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.name }))), def: -1 },
      { id: 'diff', label: '웨이브 난이도', choices: [{ v: 1, label: '쉬움' }, { v: 2, label: '보통' }, { v: 3, label: '어려움' }], def: 2 },
      { id: 'waves', label: '길이', choices: [{ v: 10, label: '10웨이브' }, { v: 15, label: '15웨이브' }], def: 10 },
    ],
    quick: [
      '몬스터가 길을 따라 성으로 와요. 다 함께 탑을 지어 막는 협동 게임이에요.',
      '돌 자리(+)를 눌러 탑을 짓고, 지은 탑을 눌러 업그레이드·팔기. 적을 잡으면 모두 골드를 받아요.',
      '마지막 웨이브까지 성 체력이 남아 있으면 승리! 체력이 많이 남을수록 별이 많아요.',
    ],
    rules: [
      { h: '목표', p: [
        '몬스터 무리(웨이브)가 동굴에서 나와 길을 따라 성으로 걸어와요. 성에 닿으면 성 체력이 깎여요(보통 1, 큰 적일수록 더 많이).',
        '모든 웨이브(10 또는 15)를 막아 내면 모두 함께 승리, 성 체력(20)이 0이 되면 모두 함께 패배예요.',
        '별: 이겼을 때 성 체력 18 이상 ★★★ · 10 이상 ★★ · 그 밖 ★.',
      ] },
      { h: '할 일', p: [
        '길 옆 돌 자리(+ 표시)를 누르면 탑 6종 메뉴가 둥글게 떠요. 탑을 한 번 누르면 사거리(동그라미)와 설명이 보이고, 한 번 더 누르면 지어요.',
        '지은 탑을 누르면 위쪽 화살표 = 업그레이드(3단계까지), 동전 = 팔기. 팔기는 두 번 눌러야 하고, 쓴 골드의 70%를 돌려받아요.',
        '빈 곳을 누르면 메뉴가 닫혀요. 탑은 다가오는 적 중 성에 가장 가까운 적부터 쏴요.',
      ] },
      { h: '골드', p: [
        '골드는 사람마다 따로예요. 적을 잡으면 누가 잡든 모두 똑같이 나눠 받아요. 웨이브가 시작될 때도 조금 받아요.',
        '함께 하면 골드를 나눠 받는 대신 전체 골드가 조금 더 많아요(2명 +6% · 3명 +10% · 4명 +14%).',
        '친구 탑도 내 골드로 업그레이드할 수 있어요(팔기는 지은 사람만).',
      ] },
      { h: '웨이브', p: [
        '첫 웨이브 전에 30초 준비 시간이 있어요. 한 웨이브가 다 나오면 다음 웨이브까지 20초.',
        '「지금!」 버튼으로 다음 웨이브를 일찍 부르면 남은 시간만큼 보너스 골드를 받아요(뒤 웨이브일수록 더 많이).',
        '아래 왼쪽 칸에 다음 웨이브에 나올 적이 보여요. 누르면 적마다 특징을 알려 줘요. 새 적이 처음 나올 땐 화면에 설명이 떠요.',
        '보스: 5번째 웨이브 오우거 왕, (15웨이브일 때) 10번째 붉은 용, 마지막 웨이브 어둠의 마왕. 마왕이 성에 닿으면 바로 끝나요!',
      ] },
      { h: '탑 6종 (짓는 값)', p: [
        '궁수 탑(60): 빠른 화살. 싸고 하늘도 쏴요. 방패 적에겐 약해요.',
        '대포(100): 터지는 포탄으로 몰린 적을 한꺼번에. 하늘은 못 쏴요.',
        '얼음 마법탑(80): 맞은 적이 느려져요(2단계부터 주변까지). 보스는 덜 느려져요.',
        '독 탑(80): 몇 초 동안 계속 깎는 독. 갑옷을 무시하고, 독에 걸린 트롤은 회복을 못 해요.',
        '투석기(120): 아주 멀리 큰 돌을 던져 넓게 쾅. 느리고, 바로 옆과 하늘은 못 맞혀요. 빠른 적은 피하기도 해요.',
        '번개탑(110): 번개가 근처 적에게 2~4번 튀어요(튈 때마다 약해짐). 갑옷을 무시해요.',
      ] },
      { h: '적', p: [
        '고블린: 평범. 늑대: 아주 빨라요. 방패 오크: 화살·대포·돌 피해를 반만 받아요. 박쥐: 하늘을 날아요.',
        '트롤: 튼튼하고 조금씩 회복. 주술사: 근처 적을 치료해요(먼저 잡으세요). 마왕은 고블린을 불러내요.',
        '웨이브가 지날수록 적이 더 튼튼해져요.',
      ] },
      { h: '조작', p: [
        '아래 버튼: 「지금!」 다음 웨이브 부르기 · 「×1/×2」 빠르기(함께 할 땐 모두에게 적용) · 「Ⅱ」 잠깐 멈춤(혼자 할 때만, 규칙 화면을 열어도 멈춰요).',
        'PC: 마우스를 탑 버튼에 올리면 사거리가 보이고 누르면 바로 지어요. 키보드는 방향키(WASD)로 흰 커서를 돌 자리로 옮기고 Enter·스페이스 = 메뉴/짓기, 1~6 = 탑 고르기, U = 업그레이드, X = 팔기(두 번), Esc = 닫기, N = 다음 웨이브, F = 빠르기, P = 멈춤. 패드: Ⓐ 고르기 · Ⓑ 닫기 · RB 업그레이드 · LB 팔기 · Ⓨ 다음 웨이브 · Ⓧ 빠르기. 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '예시', p: [
        '준비 시간에 골드 260 → 길이 꺾이는 곳 옆 자리에 궁수 탑(60)과 대포(100)를 지어요. 남은 100으로 얼음 마법탑(80)을 대포 옆에 지으면 느려진 적이 포탄에 잘 맞아요.',
        '다음 웨이브에 「박쥐」가 보이면 → 대포·투석기는 못 쏘니 궁수·얼음·독·번개탑을 준비해요.',
        '할 일이 없을 때 「지금!」(+골드)을 누르면 보너스로 탑을 더 빨리 키울 수 있어요.',
      ] },
      { h: '맵과 난이도', p: [
        '맵 6곳(+무작위): 숲속 굽이길(처음 하기 좋아요) · 두 갈래 길 · 달팽이 성(성이 가운데) · 갈림길 숲 · 지그재그 협곡 · 좁은 산길(어려움).',
        '웨이브 난이도(쉬움·보통·어려움)는 적의 체력·빠르기와 시작 골드를 바꿔요. 길이는 10웨이브(약 8분) 또는 15웨이브(약 13분).',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 해요. 혼자 하면 나머지 자리는 AI 도우미예요. 친구와는 온라인·LAN 방으로 각자 폰에서.',
        'AI 도우미 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 아무 탑이나 짓고, 보통은 다가올 적에 맞춰 짓고, 어려움은 길을 넓게 덮는 자리와 탑 조합을 잘 골라요. AI는 처음 5초 동안 기다려서 내가 먼저 자리를 고를 수 있어요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { MAPS, TT, ET, WAVES, DIFF, AIC, TEAM, buildMap, posAt, newWorld, startWave, stepWorld, cmd, canDo, aiThink, waveGroups, waveInfo, starsOf, refundOf, spentOf, cov, earlyBonus, speedOf, remOf, laneOff, STEP, GW, GH, HP0, PREP, GAP },
  });
})();
