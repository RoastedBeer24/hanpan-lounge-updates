/* 장기 — 9×10 판, 궁성 대각선 규칙, 포 넘기, 장군/멍군, 빅장, 한수쉼, 점수 판정, 알파-베타 AI. */
(function () {
  const L = window.Lounge, U = L.util;

  /* =====================================================================
   * Engine. Board index sq = row*9 + col, row 0 = top (한's back rank).
   * Piece code = type | side<<3 ; types 1 궁 2 사 3 차 4 포 5 마 6 상 7 졸/병 ; side 0 초, 1 한.
   * Move int: from | to<<7.
   * ===================================================================== */
  const CH = '.KARCNBP.karcnbp';
  const VAL = [0, 0, 300, 1300, 700, 500, 300, 200];
  const PTS = [0, 0, 3, 13, 7, 5, 3, 2]; // 점수 판정
  const MATE = 30000, INF = 32000, WINJ = 20000, MAXPLY = 64;
  const RW = (i) => (i / 9) | 0, CL = (i) => i % 9;
  const ix = (r, c) => r * 9 + c;
  const onb = (r, c) => r >= 0 && r < 10 && c >= 0 && c < 9;

  /* ---- static tables ---- */
  const PAL = new Int8Array(90); // 1 = top palace (한), 2 = bottom palace (초)
  for (let r = 0; r < 10; r++) for (let c = 3; c <= 5; c++) { if (r <= 2) PAL[ix(r, c)] = 1; if (r >= 7) PAL[ix(r, c)] = 2; }
  const DADJ = [], DRAY = [], KM = [], MA = [], SA = [], MAR = [], SAR = [], PW = [[], []], PWR = [[], []];
  for (let i = 0; i < 90; i++) { DADJ.push([]); DRAY.push([]); KM.push([]); MA.push([]); SA.push([]); MAR.push([]); SAR.push([]); PW[0].push([]); PW[1].push([]); PWR[0].push([]); PWR[1].push([]); }
  for (const [a, m, b] of [[3, 13, 23], [5, 13, 21], [66, 76, 86], [68, 76, 84]]) {
    DADJ[a].push(m); DADJ[m].push(a); DADJ[b].push(m); DADJ[m].push(b);
    DRAY[a].push([m, b]); DRAY[b].push([m, a]); DRAY[m].push([a]); DRAY[m].push([b]);
  }
  const OD = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  for (let s = 0; s < 90; s++) {
    const r = RW(s), c = CL(s);
    if (PAL[s]) {
      for (const [dr, dc] of OD) { const rr = r + dr, cc = c + dc; if (onb(rr, cc) && PAL[ix(rr, cc)] === PAL[s]) KM[s].push(ix(rr, cc)); }
      for (const d of DADJ[s]) KM[s].push(d);
    }
    for (const [dr, dc] of OD) {
      const lr = r + dr, lc = c + dc;
      if (!onb(lr, lc)) continue;
      const diags = dr ? [[dr, -1], [dr, 1]] : [[-1, dc], [1, dc]];
      for (const [er, ec] of diags) {
        const tr = lr + er, tc = lc + ec;
        if (onb(tr, tc)) MA[s].push([ix(tr, tc), ix(lr, lc)]);
        const ur = tr + er, uc = tc + ec;
        if (onb(tr, tc) && onb(ur, uc)) SA[s].push([ix(ur, uc), ix(lr, lc), ix(tr, tc)]);
      }
    }
    for (let side = 0; side < 2; side++) {
      const f = side ? 1 : -1, enemy = side ? 2 : 1;
      if (onb(r + f, c)) PW[side][s].push(ix(r + f, c));
      if (c > 0) PW[side][s].push(s - 1);
      if (c < 8) PW[side][s].push(s + 1);
      if (PAL[s] === enemy) for (const d of DADJ[s]) if (RW(d) === r + f) PW[side][s].push(d);
    }
  }
  for (let s = 0; s < 90; s++) {
    for (const [t, l] of MA[s]) MAR[t].push([s, l]);
    for (const [t, l1, l2] of SA[s]) SAR[t].push([s, l1, l2]);
    for (let side = 0; side < 2; side++) for (const t of PW[side][s]) PWR[side][t].push(s);
  }
  function nx(s, d) { // d: 0 up 1 down 2 left 3 right
    if (d === 0) return s >= 9 ? s - 9 : -1;
    if (d === 1) return s < 81 ? s + 9 : -1;
    if (d === 2) return s % 9 ? s - 1 : -1;
    return s % 9 !== 8 ? s + 1 : -1;
  }

  /* ---- mutable engine position ---- */
  const bd = new Int8Array(90);
  let side = 0, hm = 0, hLo = 0, hHi = 0, gp = 0, mcBase = 0;
  const kSq = [76, 13];
  const HSIZE = 1200;
  const U_CAP = new Int8Array(HSIZE), U_HM = new Int16Array(HSIZE), U_HL = new Int32Array(HSIZE), U_HH = new Int32Array(HSIZE), HL = new Int32Array(HSIZE);
  const MV = new Int32Array((MAXPLY * 2 + 2) * 160), SC = new Int32Array((MAXPLY * 2 + 2) * 160);
  let OPT = { bk: 'd', ml: 200 };

  let seed = 0x2545f491;
  function rnd32() { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return (t ^ (t >>> 14)) | 0; }
  const zL = new Int32Array(16 * 90), zH = new Int32Array(16 * 90);
  for (let i = 0; i < zL.length; i++) { zL[i] = rnd32(); zH[i] = rnd32(); }
  const zSL = rnd32(), zSH = rnd32();
  function zx(p, s) { hLo ^= zL[p * 90 + s]; hHi ^= zH[p * 90 + s]; }
  function computeHash() { hLo = 0; hHi = 0; for (let s = 0; s < 90; s++) if (bd[s]) zx(bd[s], s); if (side) { hLo ^= zSL; hHi ^= zSH; } }

  function attacked(sq, by) {
    const c = by << 3, R = 3 | c, C = 4 | c;
    for (let d = 0; d < 4; d++) {
      let to = nx(sq, d), screen = false;
      while (to >= 0) {
        const q = bd[to];
        if (q) {
          if (!screen) { if (q === R) return true; if ((q & 7) === 4) break; screen = true; }
          else { if (q === C) return true; break; }
        }
        to = nx(to, d);
      }
    }
    const rays = DRAY[sq];
    for (let i = 0; i < rays.length; i++) {
      const ray = rays[i]; let screen = false;
      for (let j = 0; j < ray.length; j++) {
        const q = bd[ray[j]];
        if (!q) continue;
        if (!screen) { if (q === R) return true; if ((q & 7) === 4) break; screen = true; }
        else { if (q === C) return true; break; }
      }
    }
    const mr = MAR[sq];
    for (let i = 0; i < mr.length; i++) if (bd[mr[i][0]] === (5 | c) && !bd[mr[i][1]]) return true;
    const sr = SAR[sq];
    for (let i = 0; i < sr.length; i++) if (bd[sr[i][0]] === (6 | c) && !bd[sr[i][1]] && !bd[sr[i][2]]) return true;
    const pr = PWR[by][sq];
    for (let i = 0; i < pr.length; i++) if (bd[pr[i]] === (7 | c)) return true;
    const km = KM[sq];
    for (let i = 0; i < km.length; i++) { const q = bd[km[i]]; if (q === (1 | c) || q === (2 | c)) return true; }
    return false;
  }
  const inCheck = () => attacked(kSq[side], side ^ 1);
  function facing() {
    const a = kSq[0], b = kSq[1];
    if (a % 9 !== b % 9 || bd[a] !== 1 || bd[b] !== 9) return false;
    for (let s = Math.min(a, b) + 9; s < Math.max(a, b); s += 9) if (bd[s]) return false;
    return true;
  }

  function gen(start, capsOnly) {
    let n = start;
    const us = side, them = us ^ 1;
    const add = (f, to) => { const q = bd[to]; if (!q) { if (!capsOnly) MV[n++] = f | (to << 7); } else if ((q >> 3) === them) MV[n++] = f | (to << 7); };
    for (let sq = 0; sq < 90; sq++) {
      const p = bd[sq];
      if (!p || (p >> 3) !== us) continue;
      const t = p & 7;
      if (t === 1 || t === 2) { const km = KM[sq]; for (let i = 0; i < km.length; i++) add(sq, km[i]); }
      else if (t === 3) {
        for (let d = 0; d < 4; d++) {
          let to = nx(sq, d);
          while (to >= 0) { const q = bd[to]; if (!q) { if (!capsOnly) MV[n++] = sq | (to << 7); } else { if ((q >> 3) === them) MV[n++] = sq | (to << 7); break; } to = nx(to, d); }
        }
        const rays = DRAY[sq];
        for (let i = 0; i < rays.length; i++) for (const to of rays[i]) { const q = bd[to]; if (!q) { if (!capsOnly) MV[n++] = sq | (to << 7); } else { if ((q >> 3) === them) MV[n++] = sq | (to << 7); break; } }
      } else if (t === 4) {
        for (let d = 0; d < 4; d++) {
          let to = nx(sq, d);
          while (to >= 0 && !bd[to]) to = nx(to, d);
          if (to < 0 || (bd[to] & 7) === 4) continue;
          to = nx(to, d);
          while (to >= 0) {
            const q = bd[to];
            if (!q) { if (!capsOnly) MV[n++] = sq | (to << 7); }
            else { if ((q >> 3) === them && (q & 7) !== 4) MV[n++] = sq | (to << 7); break; }
            to = nx(to, d);
          }
        }
        const rays = DRAY[sq];
        for (let i = 0; i < rays.length; i++) {
          const ray = rays[i]; if (ray.length !== 2) continue;
          const s1 = bd[ray[0]]; if (!s1 || (s1 & 7) === 4) continue;
          const to = ray[1], q = bd[to];
          if (!q) { if (!capsOnly) MV[n++] = sq | (to << 7); } else if ((q >> 3) === them && (q & 7) !== 4) MV[n++] = sq | (to << 7);
        }
      } else if (t === 5) {
        const ma = MA[sq];
        for (let i = 0; i < ma.length; i++) if (!bd[ma[i][1]]) add(sq, ma[i][0]);
      } else if (t === 6) {
        const sa = SA[sq];
        for (let i = 0; i < sa.length; i++) if (!bd[sa[i][1]] && !bd[sa[i][2]]) add(sq, sa[i][0]);
      } else {
        const pw = PW[us][sq];
        for (let i = 0; i < pw.length; i++) add(sq, pw[i]);
      }
    }
    return n;
  }

  function make(m) {
    const f = m & 127, t = (m >> 7) & 127;
    U_HM[gp] = hm; U_HL[gp] = hLo; U_HH[gp] = hHi;
    const p = bd[f], cap = bd[t];
    U_CAP[gp] = cap;
    zx(p, f); if (cap) zx(cap, t); zx(p, t);
    bd[t] = p; bd[f] = 0;
    if ((p & 7) === 1) kSq[p >> 3] = t;
    hm = cap ? 0 : hm + 1;
    side ^= 1; hLo ^= zSL; hHi ^= zSH;
    gp++; HL[gp] = hLo;
  }
  function unmake(m) {
    gp--; side ^= 1;
    const f = m & 127, t = (m >> 7) & 127;
    const p = bd[t];
    bd[f] = p; bd[t] = U_CAP[gp];
    if ((p & 7) === 1) kSq[p >> 3] = f;
    hm = U_HM[gp]; hLo = U_HL[gp]; hHi = U_HH[gp];
  }

  function setBoard(b, stm) {
    for (let i = 0; i < 90; i++) {
      const c = CH.indexOf(b[i]);
      bd[i] = c > 0 ? c : 0;
      if (c === 1) kSq[0] = i; else if (c === 9) kSq[1] = i;
    }
    side = stm; hm = 0; computeHash(); gp = 0; HL[0] = hLo;
  }
  function loadState(s) {
    setBoard(s.b, s.t);
    OPT = { bk: s.o.bk, ml: s.o.ml };
    mcBase = s.mc;
    const rep = s.rep || [];
    const n = Math.min(rep.length, 200);
    for (let i = 0; i < n - 1; i++) HL[i] = parseInt(rep[rep.length - n + i], 36) | 0;
    gp = Math.max(0, n - 1); HL[gp] = hLo; hm = gp;
  }
  function boardStr() { let s = ''; for (let i = 0; i < 90; i++) s += CH[bd[i]]; return s; }
  function legalMoves() {
    const base = (MAXPLY * 2) * 160;
    const n = gen(base, false), out = [];
    for (let i = base; i < n; i++) {
      const m = MV[i];
      make(m);
      if (!attacked(kSq[side ^ 1], side)) out.push(m);
      unmake(m);
    }
    return out;
  }
  /* material score (점수 판정): 한 gets 1.5 덤 */
  function pointsOf(b) {
    const p = [0, 1.5];
    for (let i = 0; i < 90; i++) { const c = CH.indexOf(b[i]); if (c > 0) p[c >> 3] += PTS[c & 7]; }
    return p;
  }
  function judge() { // from side-to-move's perspective, game-deciding
    let d = 0;
    for (let i = 0; i < 90; i++) { const p = bd[i]; if (p) d += (p >> 3) ? -PTS[p & 7] * 10 : PTS[p & 7] * 10; }
    d -= 15;
    if (side) d = -d;
    return d > 0 ? WINJ + d : -WINJ + d;
  }

  /* ---- evaluation ---- */
  const PST = [];
  for (let p = 0; p < 16; p++) PST.push(new Int16Array(90));
  for (let sd = 0; sd < 2; sd++) for (let s = 0; s < 90; s++) {
    const r = RW(s), c = CL(s), adv = sd ? r : 9 - r, cd = Math.abs(c - 4);
    const set = (t, v) => { PST[t | (sd << 3)][s] = Math.round(v); };
    const prog = adv - 3;
    set(7, prog < 0 ? 0 : [0, 12, 30, 42, 46, 40, 22][prog] + (cd <= 1 && prog >= 2 ? 8 : 0) - (c === 0 || c === 8 ? 4 : 0));
    set(5, 22 - 4 * cd - 3 * Math.abs(adv - 4.5) - (adv === 0 ? 8 : 0));
    set(6, 10 - 2 * cd - 2 * Math.abs(adv - 3));
    set(3, 6 - cd + (adv >= 7 && cd <= 1 ? 16 : 0) + (adv >= 5 ? 6 : 0));
    set(4, 6 - cd + (adv <= 2 && cd === 0 ? 10 : 0));
    set(1, PAL[s] && cd === 0 && (r === 1 || r === 8) ? 12 : 0);
    set(2, PAL[s] ? 4 : 0);
  }
  function evaluate() {
    let sc = 0;
    for (let s = 0; s < 90; s++) {
      const p = bd[s]; if (!p) continue;
      const v = VAL[p & 7] + PST[p][s];
      if (p >> 3) sc -= v; else sc += v;
    }
    return (side ? -sc : sc) + 10;
  }

  /* ---- search ---- */
  const TT_N = 1 << 18, TT_MASK = TT_N - 1;
  const ttKey = new Int32Array(TT_N), ttMove = new Int32Array(TT_N), ttScore = new Int16Array(TT_N), ttDepth = new Int8Array(TT_N), ttFlag = new Int8Array(TT_N);
  const killers = new Int32Array(MAXPLY * 4), hist = new Int32Array(16 * 128);
  let nodes = 0, deadline = 0, stop = false, canStop = false;
  const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
  function timeUp() { if ((++nodes & 1023) === 0 && canStop && now() > deadline) stop = true; return stop; }
  function isRep() { const lim = Math.max(0, gp - hm); for (let i = gp - 2; i >= lim; i -= 2) if (HL[i] === hLo) return true; return false; }
  function scoreMoves(base, n, ply, ttm) {
    for (let i = base; i < n; i++) {
      const m = MV[i], f = m & 127, t = (m >> 7) & 127;
      let s;
      if (m === ttm) s = 4000000;
      else if (bd[t]) s = 2000000 + VAL[bd[t] & 7] * 4 - VAL[bd[f] & 7] / 10;
      else if (m === killers[ply * 2]) s = 1800000;
      else if (m === killers[ply * 2 + 1]) s = 1700000;
      else s = Math.min(1600000, hist[(bd[f] << 7) | t]);
      SC[i] = s;
    }
  }
  function pick(i, n) {
    let b = i, bs = SC[i];
    for (let j = i + 1; j < n; j++) if (SC[j] > bs) { bs = SC[j]; b = j; }
    if (b !== i) { const tm = MV[i]; MV[i] = MV[b]; MV[b] = tm; const ts = SC[i]; SC[i] = SC[b]; SC[b] = ts; }
    return MV[i];
  }
  function qsearch(alpha, beta, ply) {
    if (timeUp()) return 0;
    const stand = evaluate();
    if (stand >= beta) return stand;
    if (stand > alpha) alpha = stand;
    if (ply >= MAXPLY * 2 - 1) return stand;
    const base = ply * 160, n = gen(base, true);
    scoreMoves(base, n, ply, 0);
    for (let i = base; i < n; i++) {
      const m = pick(i, n);
      const t = (m >> 7) & 127;
      if (stand + VAL[bd[t] & 7] + 200 < alpha) continue;
      make(m);
      if (attacked(kSq[side ^ 1], side)) { unmake(m); continue; }
      const sc = -qsearch(-beta, -alpha, ply + 1);
      unmake(m);
      if (stop) return 0;
      if (sc > alpha) { alpha = sc; if (sc >= beta) return sc; }
    }
    return alpha;
  }
  /* 어려움 only: null-move pruning + late-move reductions (ADV) */
  let ADV = false;
  const NUL = new Int8Array(MAXPLY * 2 + 4);
  function makeNull() { U_HM[gp] = hm; U_HL[gp] = hLo; U_HH[gp] = hHi; hm = 0; side ^= 1; hLo ^= zSL; hHi ^= zSH; gp++; HL[gp] = hLo; }
  function unmakeNull() { gp--; side ^= 1; hm = U_HM[gp]; hLo = U_HL[gp]; hHi = U_HH[gp]; }
  function search(depth, alpha, beta, ply) {
    if (timeUp()) return 0;
    if (ply > 0 && isRep()) return judge();
    if (mcBase + ply >= OPT.ml) return judge();
    const chk = inCheck();
    if (chk && ply < MAXPLY) depth++;
    if (depth <= 0 || ply >= MAXPLY) return qsearch(alpha, beta, ply);
    NUL[ply + 1] = 0;
    if (ADV && !chk && ply > 0 && !NUL[ply] && depth >= 3 && beta < WINJ - 2000 && beta > -WINJ + 2000 && !facing() && evaluate() >= beta) {
      makeNull(); NUL[ply + 1] = 1;
      const ns = -search(depth - 3, -beta, -beta + 1, ply + 1);
      NUL[ply + 1] = 0; unmakeNull();
      if (stop) return 0;
      if (ns >= beta) return beta;
    }
    const ti = hLo & TT_MASK;
    let ttm = 0;
    if (ttKey[ti] === hHi) {
      ttm = ttMove[ti];
      if (ply > 0 && ttDepth[ti] >= depth) {
        let s = ttScore[ti];
        if (s > MATE - 500) s -= ply; else if (s < -MATE + 500) s += ply;
        const fl = ttFlag[ti];
        if (fl === 0 || (fl === 1 && s >= beta) || (fl === 2 && s <= alpha)) return s;
      }
    }
    const fb = OPT.bk !== 'n' && facing();
    const base = ply * 160, n = gen(base, false);
    scoreMoves(base, n, ply, ttm);
    let best = -INF, bestM = 0, legal = 0;
    const a0 = alpha;
    for (let i = base; i < n; i++) {
      const m = pick(i, n);
      make(m);
      if (attacked(kSq[side ^ 1], side)) { unmake(m); continue; }
      legal++;
      let sc;
      if (fb && facing()) sc = OPT.bk === 'd' ? 0 : -judge();
      else if (ADV && depth >= 3 && !chk && legal > 4 && !U_CAP[gp - 1] && m !== killers[ply * 2] && m !== killers[ply * 2 + 1] && !inCheck()) {
        sc = -search(depth - 2, -alpha - 1, -alpha, ply + 1);
        if (sc > alpha && !stop) sc = -search(depth - 1, -beta, -alpha, ply + 1);
      } else sc = -search(depth - 1, -beta, -alpha, ply + 1);
      unmake(m);
      if (stop) return 0;
      if (sc > best) {
        best = sc; bestM = m;
        if (sc > alpha) {
          alpha = sc;
          if (sc >= beta) {
            const t = (m >> 7) & 127;
            if (!bd[t]) {
              if (killers[ply * 2] !== m) { killers[ply * 2 + 1] = killers[ply * 2]; killers[ply * 2] = m; }
              hist[(bd[m & 127] << 7) | t] += depth * depth;
            }
            break;
          }
        }
      }
    }
    if (!legal) return chk ? -MATE + ply : (fb ? (OPT.bk === 'd' ? 0 : judge()) : evaluate());
    let stt = best;
    if (stt > MATE - 500) stt += ply; else if (stt < -MATE + 500) stt -= ply;
    ttKey[ti] = hHi; ttMove[ti] = bestM; ttScore[ti] = Math.max(-32000, Math.min(32000, stt)); ttDepth[ti] = depth;
    ttFlag[ti] = best >= beta ? 1 : best <= a0 ? 2 : 0;
    return best;
  }
  const CFG = { budget: 300, noisePlies: 8, noise: 24 };
  function think(budget, noisy, adv) {
    ADV = !!adv;
    const t0 = now();
    deadline = t0 + budget; stop = false; nodes = 0; canStop = false;
    killers.fill(0);
    for (let i = 0; i < hist.length; i++) hist[i] >>= 2;
    const legal = legalMoves();
    if (!legal.length) return { m: 0 };
    if (legal.length === 1) return { m: legal[0], score: evaluate(), depth: 0 };
    const fb = OPT.bk !== 'n' && facing();
    for (let i = 0; i < legal.length; i++) MV[i] = legal[i];
    const ti = hLo & TT_MASK;
    scoreMoves(0, legal.length, 0, ttKey[ti] === hHi ? ttMove[ti] : 0);
    let order = legal.map((m, i) => [m, SC[i]]).sort((a, b) => b[1] - a[1]).map((x) => x[0]);
    const noise = new Map(order.map((m) => [m, noisy ? Math.floor(Math.random() * CFG.noise) : 0]));
    let best = order[0], bestScore = 0, depthDone = 0;
    for (let depth = 1; depth <= 40; depth++) {
      canStop = depth > 1;
      let alpha = -INF, iterBest = 0, iterScore = -INF;
      const scores = new Map();
      for (const m of order) {
        const nz = noise.get(m);
        make(m);
        let sc;
        if (fb && facing()) sc = (OPT.bk === 'd' ? 0 : -judge()) + nz;
        else sc = -search(depth - 1, -INF, -(alpha - nz), 1) + nz;
        unmake(m);
        if (stop) break;
        scores.set(m, sc);
        if (sc > iterScore) { iterScore = sc; iterBest = m; }
        if (sc > alpha) alpha = sc;
      }
      if (stop) break;
      best = iterBest; bestScore = iterScore; depthDone = depth;
      order = order.slice().sort((a, b) => (b === best) - (a === best) || (scores.get(b) || -INF) - (scores.get(a) || -INF));
      if (Math.abs(bestScore) > MATE - 200) break;
      if (now() - t0 > budget * (adv ? 0.45 : 0.55)) break;
    }
    ADV = false;
    return { m: best, score: bestScore, depth: depthDone, nodes, ms: now() - t0 };
  }
  /* 쉬움: shallow full-window scores for every root move, then a sloppy pick */
  function rootScores(depth) {
    deadline = now() + 1e9; stop = false; canStop = false; ADV = false;
    const fb = OPT.bk !== 'n' && facing();
    const out = [];
    for (const m of legalMoves()) {
      make(m);
      let sc;
      if (fb && facing()) sc = OPT.bk === 'd' ? 0 : -judge();
      else sc = depth <= 1 ? -qsearch(-INF, INF, 1) : -search(depth - 1, -INF, INF, 1);
      unmake(m);
      out.push([m, sc]);
    }
    return out.sort((a, b) => b[1] - a[1]);
  }
  function easyMove() {
    const r = rootScores(Math.random() < 0.55 ? 1 : 2);
    if (!r.length) return 0;
    const best = r[0][1];
    if (best > MATE - 200 && Math.random() < 0.7) return r[0][0];
    const x = Math.random();
    if (x < 0.12) {
      const pool = r.filter((e) => e[1] > -MATE + 200);
      return (pool.length ? pool : r)[(Math.random() * (pool.length || r.length)) | 0][0];
    }
    if (x < 0.45) {
      const pool = r.filter((e) => e[1] >= best - 320).slice(0, 4);
      return pool[(Math.random() * pool.length) | 0][0];
    }
    let bm = r[0][0], bs = -INF;
    for (const [m, sc] of r) { const v = sc + Math.random() * 70; if (v > bs) { bs = v; bm = m; } }
    return bm;
  }

  /* =====================================================================
   * Game rules on the JSON state
   * ===================================================================== */
  const ARR = ['마상마상', '상마상마', '마상상마', '상마마상']; // own left → right
  const SIDE = ['초', '한'];
  function emptySetup() {
    const b = Array(90).fill('.');
    b[ix(0, 0)] = b[ix(0, 8)] = 'r'; b[ix(0, 3)] = b[ix(0, 5)] = 'a'; b[ix(1, 4)] = 'k'; b[ix(2, 1)] = b[ix(2, 7)] = 'c';
    for (const c of [0, 2, 4, 6, 8]) { b[ix(3, c)] = 'p'; b[ix(6, c)] = 'P'; }
    b[ix(9, 0)] = b[ix(9, 8)] = 'R'; b[ix(9, 3)] = b[ix(9, 5)] = 'A'; b[ix(8, 4)] = 'K'; b[ix(7, 1)] = b[ix(7, 7)] = 'C';
    return b.join('');
  }
  /* columns of a side's 마/상 slots in its own left-to-right order */
  const SLOTS = [[1, 2, 6, 7], [7, 6, 2, 1]];
  function placeArr(b, sd, k) {
    const a = b.split(''), row = sd ? 0 : 9;
    for (let i = 0; i < 4; i++) { const ch = ARR[k][i] === '마' ? 'n' : 'b'; a[ix(row, SLOTS[sd][i])] = sd ? ch : ch.toUpperCase(); }
    return a.join('');
  }
  function init(players, opts) {
    const o = { bk: opts && (opts.bk === 's' || opts.bk === 'n') ? opts.bk : 'd', ml: opts && [100, 150, 200].includes(+opts.ml) ? +opts.ml : 200 };
    const hum = players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0);
    const solo = hum.length === 1 && players.length === 2 && players.some((p) => p.ai) ? hum[0] : -1;
    return { o, ph: 's', sc: [-1, -1], b: emptySetup(), t: 0, mc: 0, cap: '', ck: 0, seq: 0, rep: [], last: null, st: null, dr: null, nd: -1, u: [], ev: null, solo };
  }
  function actor(s) {
    if (s.st) return null;
    if (s.ph === 's') return s.sc[1] < 0 ? 1 : 0;
    return s.dr ? 1 - s.dr.by : s.t;
  }
  function snap(s) { return { b: s.b, t: s.t, mc: s.mc, cap: s.cap, ck: s.ck, last: s.last, nd: s.nd }; }
  const LIMIT = 2380;
  function fit(s) {
    let n = JSON.stringify(s).length;
    if (n > LIMIT && s.u.length) { s.u = []; n = JSON.stringify(s).length; }
    while (n > LIMIT && s.rep.length > 4) { s.rep = s.rep.slice(8); n = JSON.stringify(s).length; }
  }
  function endChecks(s, seat, fb) {
    const key = (hLo >>> 0).toString(36);
    const chk = inCheck();
    s.ck = chk ? 1 : 0;
    const replies = legalMoves().length;
    if (chk && !replies) { s.st = { r: 'mate', w: seat }; return; }
    if (s.o.bk !== 'n' && fb && facing()) { s.st = s.o.bk === 'd' ? { r: 'bik', w: -1 } : { r: 'bikS', w: scoreWinner(s.b) }; return; }
    if (s.rep.filter((k) => k === key).length >= 3) { s.st = { r: 'rep', w: scoreWinner(s.b) }; return; }
    if (s.mc >= s.o.ml) { s.st = { r: 'limit', w: scoreWinner(s.b) }; return; }
    if (s.o.bk !== 'n' && !fb && facing()) s.ev = { id: s.seq, k: 'bj', by: seat };
  }
  function scoreWinner(b) { const p = pointsOf(b); return p[0] > p[1] ? 0 : 1; }

  function apply(s, seat, a) {
    if (s.st) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a) throw new Error('bad action');
    if (s.ph === 's') {
      if (a.type !== 'setup') throw new Error('choose setup');
      const k = a.k | 0;
      if (k < 0 || k > 3) throw new Error('bad setup');
      s.sc[seat] = k;
      s.b = placeArr(s.b, seat, k);
      s.seq++;
      s.ev = { id: s.seq, k: 'set', by: seat, a: k };
      if (s.sc[0] >= 0 && s.sc[1] >= 0) {
        s.ph = 'p'; s.t = 0;
        setBoard(s.b, 0);
        s.rep = [(hLo >>> 0).toString(36)];
      }
      return s;
    }
    if (s.dr) {
      if (a.type !== 'drawReply') throw new Error('answer the draw offer');
      s.seq++;
      const by = s.dr.by;
      s.dr = null;
      if (a.ok) s.st = { r: 'agree', w: -1 };
      else s.ev = { id: s.seq, k: 'n', by };
      return s;
    }
    if (a.type === 'resign') { s.seq++; s.st = { r: 'resign', w: 1 - seat }; return s; }
    if (a.type === 'draw') {
      if (s.nd === seat) throw new Error('already offered');
      s.seq++; s.dr = { by: seat }; s.nd = seat; s.ev = { id: s.seq, k: 'o', by: seat };
      return s;
    }
    if (a.type === 'undo') {
      if (s.solo !== seat || !s.u || s.u.length !== 2 || s.u[0].t !== seat) throw new Error('nothing to undo');
      const [o, nw] = s.u;
      let r = nw.r || s.rep.slice(0, -1);
      r = o.r || r.slice(0, -1);
      if (!r.length) throw new Error('nothing to undo');
      Object.assign(s, { b: o.b, t: o.t, mc: o.mc, cap: o.cap, ck: o.ck, last: o.last, nd: o.nd, rep: r });
      s.u = []; s.seq++; s.ev = { id: s.seq, k: 'u', by: seat };
      return s;
    }
    loadState(s);
    const fb = facing();
    const before = snap(s), repBefore = s.rep;
    if (a.type === 'pass') {
      if (inCheck()) throw new Error('cannot pass in check');
      side ^= 1; hLo ^= zSL; hHi ^= zSH;
      s.seq++; s.mc++; s.t = side;
      s.last = { id: s.seq, ps: 1, by: seat };
      s.ev = null;
      s.rep.push((hLo >>> 0).toString(36));
      if (s.rep.length > 60) s.rep = s.rep.slice(-60);
      if (s.nd !== seat) s.nd = -1;
      s.u = (s.u || []).slice(-1).concat([before]);
      endChecks(s, seat, fb);
      fit(s);
      return s;
    }
    if (a.type !== 'move') throw new Error('bad action');
    const f = a.f | 0, t = a.t | 0;
    const m = legalMoves().find((x) => (x & 127) === f && ((x >> 7) & 127) === t);
    if (m == null) throw new Error('illegal move');
    const pc = s.b[f], capCh = s.b[t] !== '.' ? s.b[t] : '';
    make(m);
    s.seq++; s.mc++;
    s.b = boardStr(); s.t = side;
    s.cap += capCh;
    s.last = { f, t, id: s.seq, pc, by: seat };
    if (capCh) s.last.x = capCh;
    s.ev = null;
    const key = (hLo >>> 0).toString(36);
    if (capCh) { s.rep = [key]; before.r = repBefore; } else s.rep.push(key);
    if (s.rep.length > 60) s.rep = s.rep.slice(-60);
    if (s.nd !== seat) s.nd = -1;
    s.u = (s.u || []).slice(-1).concat([before]);
    endChecks(s, seat, fb);
    fit(s);
    return s;
  }

  function scoreText(b) { const p = pointsOf(b); return '초 ' + p[0] + '점 · 한 ' + p[1] + '점(덤 1.5 포함)'; }
  function result(s) {
    if (!s.st) return null;
    const r = s.st.r, w = s.st.w, mv = s.mc + '수';
    if (r === 'mate') return { winners: [w], title: '외통 (' + SIDE[w] + ' 승)', text: SIDE[1 - w] + ' 궁이 피할 곳이 없어요 · ' + mv };
    if (r === 'resign') return { winners: [w], title: SIDE[1 - w] + ' 기권', text: SIDE[w] + ' 승리 · ' + mv };
    if (r === 'bik') return { winners: [], title: '빅장 (무승부)', text: '대궁을 피하지 않아 비겼어요 · ' + mv };
    if (r === 'bikS') return { winners: [w], title: '빅장 · 점수 판정', text: SIDE[w] + ' 승리\n' + scoreText(s.b) };
    if (r === 'rep') return { winners: [w], title: '반복수 · 점수 판정', text: '같은 국면이 세 번 나왔어요. ' + SIDE[w] + ' 승리\n' + scoreText(s.b) };
    if (r === 'limit') return { winners: [w], title: s.o.ml + '수 · 점수 판정', text: SIDE[w] + ' 승리\n' + scoreText(s.b) };
    if (r === 'agree') return { winners: [], title: '무승부 (합의)', text: '무승부 제안을 받아들였어요 · ' + mv };
    return { winners: [], title: '무승부' };
  }

  const DRAW_OK = 30;
  /* each level keeps its own search memory: a bot must not reuse the deeper results of another level (AI vs AI on one device) */
  let ttOwner = 0;
  function ownTT(lv) { if (ttOwner !== lv) { ttKey.fill(0); hist.fill(0); ttOwner = lv; } }
  function ai(s, seat, lv) {
    lv = lv === 1 || lv === 3 ? lv : 2;
    if (s.ph === 's') return { type: 'setup', k: U.rand(4) };
    if (s.dr) {
      loadState(s); ownTT(lv);
      let sc;
      if (lv === 1) { const r = rootScores(1); sc = r.length ? r[0][1] : evaluate(); }
      else { const r = think(lv === 3 ? 400 : 160, false, lv === 3); sc = typeof r.score === 'number' ? r.score : evaluate(); }
      const mine = seat === s.t ? sc : -sc;
      return { type: 'drawReply', ok: mine <= DRAW_OK };
    }
    loadState(s);
    ownTT(lv);
    let m;
    if (lv === 1) m = easyMove();
    else m = (lv === 3 ? think(600, s.mc < 3, CFG.adv !== false) : think(CFG.budget, s.mc < CFG.noisePlies)).m;
    if (!m) return { type: 'pass' };
    return { type: 'move', f: m & 127, t: (m >> 7) & 127 };
  }
  function aiDelayFor(s, seat, lv) { return s.ph === 's' ? 300 : lv === 1 ? 650 : lv === 3 ? 60 : 300; }
  function legalFromState(s) { loadState(s); return legalMoves().map((m) => ({ f: m & 127, t: (m >> 7) & 127 })); }

  /* =====================================================================
   * View
   * ===================================================================== */
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace';
  const SERIF = '"Noto Serif CJK KR","Noto Serif KR","Nanum Myeongjo","AppleMyungjo","Batang","Songti SC",serif';
  const HANJA = [['', '楚', '士', '車', '包', '馬', '象', '卒'], ['', '漢', '士', '車', '包', '馬', '象', '兵']];
  const HANGUL = [['', '초', '사', '차', '포', '마', '상', '졸'], ['', '한', '사', '차', '포', '마', '상', '병']];
  const NAME = ['', '궁', '사', '차', '포', '마', '상', '졸'];
  const INK = ['#16744a', '#c3281f'];
  const RAD = [0, 0.47, 0.33, 0.41, 0.41, 0.41, 0.41, 0.33];
  const codeOf = (ch) => CH.indexOf(ch);
  const pName = (ch) => { const c = codeOf(ch); return (c & 7) === 7 ? ((c >> 3) ? '병' : '졸') : NAME[c & 7]; };

  function octa(ctx, x, y, r) {
    ctx.beginPath();
    for (let k = 0; k < 8; k++) { const a = Math.PI / 8 + k * Math.PI / 4; const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
    ctx.closePath();
  }
  function drawPiece(ctx, ch, x, y, cell, opt) {
    const c = codeOf(ch); if (c <= 0) return;
    const t = c & 7, sd = c >> 3;
    const r = cell * RAD[t] * ((opt && opt.scale) || 1);
    ctx.save();
    if (opt && opt.alpha != null) ctx.globalAlpha = opt.alpha;
    ctx.fillStyle = 'rgba(30,14,0,.42)'; octa(ctx, x + r * 0.08, y + r * 0.16, r); ctx.fill();
    const g = ctx.createLinearGradient(x - r, y - r, x + r, y + r);
    g.addColorStop(0, '#f8e6bf'); g.addColorStop(0.55, '#e7c88f'); g.addColorStop(1, '#c99d5d');
    ctx.fillStyle = g; octa(ctx, x, y, r); ctx.fill();
    ctx.strokeStyle = 'rgba(80,46,12,.75)'; ctx.lineWidth = Math.max(1, r * 0.07); ctx.stroke();
    ctx.strokeStyle = sd ? 'rgba(195,40,31,.55)' : 'rgba(22,116,74,.55)'; ctx.lineWidth = Math.max(0.8, r * 0.05);
    octa(ctx, x, y, r * 0.8); ctx.stroke();
    const hj = !opt || opt.hanja !== false;
    const glyph = (hj ? HANJA : HANGUL)[sd][t];
    ctx.fillStyle = INK[sd];
    const fs = r * (t === 1 ? 1.05 : 1.12) * (hj ? 1 : 0.92);
    ctx.font = (hj ? '900 ' : '700 ') + fs.toFixed(1) + 'px ' + (hj ? SERIF : FONT);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(glyph, x, y + r * 0.05);
    ctx.restore();
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, G = null, sel = -1, targets = [], legal = [], anim = null, busy = false, stopLoop = null, animTimer = 0;
    let shownSeq = -1, flip = false, preview = -1, waitSeq = -1, waitUntil = 0;
    let hanja = U.store.get('janggi.hanja', true);
    const BS = { minHeight: '44px', flex: '1 1 0', minWidth: 0, padding: '6px 4px', fontSize: '13px', whiteSpace: 'nowrap' };
    const hud = L.h('div', { class: 'hud bottom jg-hud', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px' } });
    const glyphBtn = L.h('button', { class: 'btn sm ghost jg-glyph', style: BS, onclick: toggleGlyph });
    const undoBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '↶ 무르기', 'aria-label': '한 수 무르기', onclick: onUndo });
    const passBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '한수쉼', 'aria-label': '한 수 쉬기', onclick: onPass });
    const drawBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '무승부', 'aria-label': '무승부 제안', onclick: onDraw });
    const resignBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '기권', 'aria-label': '기권하기', onclick: onResign });
    const setupBtns = ARR.map((name, k) => L.h('button', { class: 'btn sm', style: Object.assign({}, BS, { flexDirection: 'column', gap: '0', lineHeight: '1.15', minHeight: '50px' }), onclick: () => onSetup(k) }));
    hud.append(glyphBtn, undoBtn, passBtn, drawBtn, resignBtn, ...setupBtns);
    const hint = L.h('div', { class: 'jg-hint', style: { position: 'absolute', left: '12px', right: '12px', textAlign: 'center', fontSize: '12.5px', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', pointerEvents: 'none' } });
    const offer = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'none', alignItems: 'flex-end', justifyContent: 'center', padding: '16px', background: 'rgba(15,10,22,.45)' } });
    root.append(hud, hint, offer);
    // invisible boxes over canvas areas, so the first-play tutorial can spotlight them
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
    const spBoard = spot('jg-board'), spPal = spot('jg-palace'), spMe = spot('jg-me'), spOpp = spot('jg-opp');
    const vis = (el, on) => { el.style.display = on ? '' : 'none'; };
    function glyphLabel() { glyphBtn.textContent = hanja ? '글자 漢' : '글자 한'; glyphBtn.setAttribute('aria-label', hanja ? '기물 글자: 한자 (누르면 한글)' : '기물 글자: 한글 (누르면 한자)'); }
    glyphLabel();
    function toggleGlyph() { hanja = !hanja; U.store.set('janggi.hanja', hanja); glyphLabel(); api.sfx('click'); api.buzz(8); draw(); }

    const confirms = new Map();
    function armed(btn, label, ask) {
      if (confirms.has(btn)) { disarm(btn); return true; }
      for (const b of [...confirms.keys()]) disarm(b);
      btn.classList.add('danger'); btn.classList.remove('ghost'); btn.textContent = ask;
      confirms.set(btn, { label, timer: setTimeout(() => disarm(btn), 3000) });
      api.sfx('click'); api.buzz(10);
      return false;
    }
    function disarm(btn) { const c = confirms.get(btn); if (!c) return; clearTimeout(c.timer); confirms.delete(btn); btn.classList.remove('danger'); btn.classList.add('ghost'); btn.textContent = c.label; }
    function disarmAll() { for (const b of [...confirms.keys()]) disarm(b); }

    function myTurn() { const a = st && actor(st); return a != null && api.canAct(a); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function sendAct(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }
    function playing() { return !!st && !st.st && st.ph === 'p'; }
    function canOffer() { return playing() && !st.dr && myTurn() && !locked() && st.nd !== st.t; }
    function canUndo() { return playing() && !api.online && st.solo >= 0 && !st.dr && st.t === st.solo && myTurn() && !locked() && !anim && st.u && st.u.length === 2 && st.u[0].t === st.solo; }
    function onResign() { if (!playing() || !myTurn() || locked() || st.dr) return; if (!armed(resignBtn, '기권', '기권 확인')) return; sendAct({ type: 'resign' }); }
    function onDraw() { if (!canOffer()) return; if (!armed(drawBtn, '무승부', '제안 확인')) return; sendAct({ type: 'draw' }); }
    function onPass() {
      if (!playing() || !myTurn() || locked() || st.dr || anim) return;
      if (st.ck) { api.toast('장군 중에는 쉴 수 없어요'); api.buzz(25); return; }
      if (!armed(passBtn, '한수쉼', '쉼 확인')) return;
      sel = -1; targets = [];
      sendAct({ type: 'pass' });
    }
    function onUndo() { if (!canUndo()) return; sel = -1; targets = []; api.sfx('click'); api.buzz(15); sendAct({ type: 'undo' }); }
    function onSetup(k) {
      if (!st || st.ph !== 's' || !myTurn() || locked()) return;
      if (preview === k) { api.sfx('click'); api.buzz(15); preview = -1; sendAct({ type: 'setup', k }); updateHud(); draw(); return; }
      preview = k; api.sfx('tick'); api.buzz(8); updateHud(); draw();
    }

    function computeFlip() { const mine = [0, 1].filter((i) => api.canAct(i)); flip = mine.length === 1 && mine[0] === 1; }
    function layout() {
      const W = cv.w, H = cv.h;
      const stripH = 40, hudH = 66, hintH = 22, gap = 6;
      const avail = H - hudH - hintH - stripH * 2 - gap * 3 - 6;
      let cell = Math.min((W - 10) / 9.3, avail / 10.62, 64);
      cell = Math.max(22, Math.floor(cell));
      const m = cell * 0.65;
      const bw = Math.round(cell * 8 + m * 2), bh = Math.round(cell * 9 + m * 2 + cell * 0.32);
      const sw = Math.min(W - 12, Math.max(bw, 300));
      const block = stripH * 2 + gap * 2 + bh;
      const y0 = Math.round(Math.max(4, (H - hudH - hintH - block) / 2));
      const x0 = Math.round((W - bw) / 2), sx = Math.round((W - sw) / 2);
      G = { cell, m, bw, bh, x0, sx, sw, stripH, topY: y0, boardY: y0 + stripH + gap, botY: y0 + stripH + gap * 2 + bh };
      G.bx = x0 + m; G.by = G.boardY + m;
      hint.style.top = (G.botY + stripH + 3) + 'px';
      place(spBoard, x0, G.boardY, bw, bh);
      place(spPal, Math.round(G.bx + 2.45 * cell), Math.round(G.by - 0.55 * cell), Math.round(3.1 * cell), Math.round(3.1 * cell));
      place(spMe, sx, G.botY, sw, stripH); place(spOpp, sx, y0, sw, stripH);
      buildBg();
    }
    let bgc = null;
    function buildBg() {
      const dpr = cv.dpr, w = G.bw, h = G.bh, cell = G.cell, m = G.m;
      const c = document.createElement('canvas'); c.width = Math.ceil(w * dpr); c.height = Math.ceil(h * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr);
      const g = x.createLinearGradient(0, 0, w, h);
      g.addColorStop(0, '#e6bd73'); g.addColorStop(0.5, '#dcae63'); g.addColorStop(1, '#c69650');
      x.fillStyle = g; rr(x, 0, 0, w, h, 8); x.fill();
      x.save(); rr(x, 0, 0, w, h, 8); x.clip();
      let sd = 11; const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
      for (let i = 0; i < 50; i++) {
        const yy = rnd() * h, amp = 2 + rnd() * 6, ph = rnd() * 6;
        x.strokeStyle = 'rgba(120,70,20,' + (0.04 + rnd() * 0.07).toFixed(3) + ')'; x.lineWidth = 0.6 + rnd() * 1.6;
        x.beginPath();
        for (let xx = 0; xx <= w; xx += 6) { const v = yy + Math.sin(xx / (40 + amp * 8) + ph) * amp; xx ? x.lineTo(xx, v) : x.moveTo(xx, v); }
        x.stroke();
      }
      const sh = x.createRadialGradient(w * 0.3, h * 0.25, 10, w * 0.5, h * 0.5, Math.max(w, h) * 0.8);
      sh.addColorStop(0, 'rgba(255,240,200,.2)'); sh.addColorStop(1, 'rgba(60,30,0,.12)');
      x.fillStyle = sh; x.fillRect(0, 0, w, h);
      x.restore();
      x.strokeStyle = 'rgba(45,24,6,.85)'; x.lineWidth = 1;
      x.beginPath();
      for (let r = 0; r < 10; r++) { const y = Math.round(m + r * cell) + 0.5; x.moveTo(m, y); x.lineTo(m + 8 * cell, y); }
      for (let col = 0; col < 9; col++) { const xx = Math.round(m + col * cell) + 0.5; x.moveTo(xx, m); x.lineTo(xx, m + 9 * cell); }
      // palace diagonals
      for (const r0 of [0, 7]) {
        x.moveTo(m + 3 * cell, m + r0 * cell); x.lineTo(m + 5 * cell, m + (r0 + 2) * cell);
        x.moveTo(m + 5 * cell, m + r0 * cell); x.lineTo(m + 3 * cell, m + (r0 + 2) * cell);
      }
      x.stroke();
      x.lineWidth = 2; x.strokeRect(m, m, 8 * cell, 9 * cell);
      // starting-point marks (졸·포 자리)
      x.strokeStyle = 'rgba(45,24,6,.55)'; x.lineWidth = 1;
      const tick = cell * 0.12, off = cell * 0.08;
      const marks = [[2, 1], [2, 7], [7, 1], [7, 7], [3, 0], [3, 2], [3, 4], [3, 6], [3, 8], [6, 0], [6, 2], [6, 4], [6, 6], [6, 8]];
      for (const [r, col] of marks) {
        const px = m + col * cell, py = m + r * cell;
        for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
          if ((col === 0 && sx < 0) || (col === 8 && sx > 0)) continue;
          x.beginPath(); x.moveTo(px + sx * off, py + sy * (off + tick)); x.lineTo(px + sx * off, py + sy * off); x.lineTo(px + sx * (off + tick), py + sy * off); x.stroke();
        }
      }
      bgc = c;
    }
    cv.onresize = () => { layout(); draw(); };
    layout();
    function rr(x, a, b, w, h, r) { x.beginPath(); if (x.roundRect) x.roundRect(a, b, w, h, r); else x.rect(a, b, w, h); }
    function P(i) { const r = RW(i), c = CL(i); const vr = flip ? 9 - r : r, vc = flip ? 8 - c : c; return { x: G.bx + vc * G.cell, y: G.by + vr * G.cell }; }
    function hit(px, py) {
      const vc = Math.round((px - G.bx) / G.cell), vr = Math.round((py - G.by) / G.cell);
      if (vc < 0 || vc > 8 || vr < 0 || vr > 9) return -1;
      if (Math.hypot(px - (G.bx + vc * G.cell), py - (G.by + vr * G.cell)) > G.cell * 0.62) return -1;
      const r = flip ? 9 - vr : vr, c = flip ? 8 - vc : vc;
      return ix(r, c);
    }

    function drawStrip(seat, y) {
      const p = api.players[seat] || { name: SIDE[seat], color: '#888' };
      const x = G.sx, w = G.sw, hh = G.stripH;
      const active = st && !st.st && actor(st) === seat;
      const won = st && st.st && st.st.w === seat;
      rr(ctx, x, y, w, hh, 12);
      ctx.fillStyle = active ? 'rgba(46,38,64,.95)' : 'rgba(34,28,46,.75)'; ctx.fill();
      ctx.lineWidth = active || won ? 1.5 : 1; ctx.strokeStyle = active || won ? '#e3ae45' : 'rgba(242,233,216,.13)'; ctx.stroke();
      const cy = y + hh / 2;
      ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(x + 14, cy, 5, 0, 7); ctx.fill();
      drawPiece(ctx, seat ? 'k' : 'K', x + 35, cy, 30, { hanja });
      ctx.font = '700 14px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      let name = p.name; const maxW = w * 0.3;
      while (ctx.measureText(name).width > maxW && name.length > 1) name = name.slice(0, -1);
      if (name !== p.name) name += '…';
      ctx.fillText(name, x + 54, cy);
      let nx2 = x + 54 + ctx.measureText(name).width + 6;
      const checked = st && st.ph === 'p' && st.ck && st.t === seat && (!st.st || st.st.r === 'mate');
      ctx.font = (checked ? '700' : '600') + ' 12px ' + FONT; ctx.fillStyle = checked ? '#ee6a55' : won ? '#e3ae45' : '#ab9fb8';
      const tag = checked ? (st.st ? '외통' : '장군') : won ? '승리' : seat ? '한' : '초 · 선';
      ctx.fillText(tag, nx2, cy + 0.5);
      nx2 += ctx.measureText(tag).width + 8;
      if (!st) return;
      const pts = pointsOf(st.ph === 's' ? [0, 1].reduce((b, sd) => (st.sc[sd] < 0 ? placeArr(b, sd, 0) : b), st.b) : st.b)[seat];
      let rx = x + w - 10;
      ctx.textAlign = 'right'; ctx.font = '700 13px ' + MONO; ctx.fillStyle = '#e3ae45';
      const ptxt = String(pts);
      ctx.fillText(ptxt, rx, cy + 0.5);
      rx -= ctx.measureText(ptxt).width + 8;
      const caps = st.cap.split('').filter((c) => (seat === 0 ? c >= 'a' : c < 'a' && c !== '.'))
        .sort((a, b) => PTS[codeOf(b) & 7] - PTS[codeOf(a) & 7]);
      if (!caps.length) return;
      const ps = 20, step0 = 13;
      const total = (caps.length - 1) * step0;
      const avail = Math.max(10, rx - ps / 2 - (nx2 + ps / 2));
      const k = total > avail ? avail / total : 1;
      let cx = rx - ps / 2 - total * k;
      for (const c of caps) { drawPiece(ctx, c, cx, cy, ps * 1.25, { hanja }); cx += step0 * k; }
    }

    function boardChars() { if (anim) return anim.base; if (st.ph === 's' && preview >= 0 && myTurn()) return placeArr(st.b, actor(st), preview); return st.b; }

    function draw() {
      cv.clear();
      if (!G || !st) return;
      const cell = G.cell;
      drawStrip(flip ? 0 : 1, G.topY);
      drawStrip(flip ? 1 : 0, G.botY);
      ctx.fillStyle = 'rgba(0,0,0,.5)'; rr(ctx, G.x0 + 3, G.boardY + 8, G.bw, G.bh, 10); ctx.fill();
      if (bgc) ctx.drawImage(bgc, G.x0, G.boardY, G.bw, G.bh);
      // coordinates (1–9 files, 1–10 ranks from 초's side)
      const fs = Math.max(8, Math.min(11, G.m * 0.42));
      ctx.font = '600 ' + fs + 'px ' + MONO; ctx.fillStyle = 'rgba(60,34,10,.62)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let c = 0; c < 9; c++) { const q = P(ix(flip ? 0 : 9, c)); ctx.fillText(String(c + 1), q.x, G.boardY + G.bh - cell * 0.2); }
      const b = boardChars();
      const last = anim ? anim.last : st.last;
      if (last && !last.ps && st.ph === 'p') {
        const a = P(last.f), z = P(last.t);
        ctx.strokeStyle = 'rgba(227,174,69,.75)'; ctx.lineWidth = 2; ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.arc(a.x, a.y, cell * 0.3, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        if (!anim) { ctx.fillStyle = 'rgba(227,174,69,.35)'; ctx.beginPath(); ctx.arc(z.x, z.y, cell * 0.5, 0, 7); ctx.fill(); }
      }
      // empty setup slots
      if (st.ph === 's') {
        for (let sd = 0; sd < 2; sd++) {
          if (st.sc[sd] >= 0 || (preview >= 0 && myTurn() && actor(st) === sd)) continue;
          for (const col of SLOTS[sd]) {
            const q = P(ix(sd ? 0 : 9, col));
            ctx.save(); ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(70,40,10,.6)'; ctx.lineWidth = 1.4; octa(ctx, q.x, q.y, cell * 0.38); ctx.stroke();
            ctx.fillStyle = 'rgba(70,40,10,.55)'; ctx.font = '700 ' + Math.round(cell * 0.32) + 'px ' + FONT; ctx.fillText('?', q.x, q.y + 1); ctx.restore();
          }
        }
      }
      // check glow
      if (st.ph === 'p' && st.ck && !anim) {
        const q = P(st.b.indexOf(st.t ? 'k' : 'K'));
        const g = ctx.createRadialGradient(q.x, q.y, cell * 0.1, q.x, q.y, cell * 0.75);
        g.addColorStop(0, 'rgba(238,80,60,.95)'); g.addColorStop(0.55, 'rgba(238,80,60,.45)'); g.addColorStop(1, 'rgba(238,80,60,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q.x, q.y, cell * 0.75, 0, 7); ctx.fill();
      }
      // facing kings line (대궁)
      if (st.ph === 'p' && st.o.bk !== 'n' && !anim && !st.st) {
        const a = st.b.indexOf('K'), z = st.b.indexOf('k');
        if (a >= 0 && z >= 0 && a % 9 === z % 9) {
          let clear = true; for (let s2 = z + 9; s2 < a; s2 += 9) if (st.b[s2] !== '.') clear = false;
          if (clear) { const p1 = P(a), p2 = P(z); ctx.save(); ctx.strokeStyle = 'rgba(238,106,85,.75)'; ctx.lineWidth = 3; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke(); ctx.restore(); }
        }
      }
      if (sel >= 0) { const q = P(sel); ctx.fillStyle = 'rgba(227,174,69,.6)'; ctx.beginPath(); ctx.arc(q.x, q.y, cell * 0.55, 0, 7); ctx.fill(); }
      for (let i = 0; i < 90; i++) {
        const ch = b[i]; if (ch === '.') continue;
        const q = P(i);
        const pv = st.ph === 's' && preview >= 0 && myTurn() && st.b[i] === '.';
        drawPiece(ctx, ch, q.x, q.y, cell, { hanja, alpha: pv ? 0.75 : null, scale: i === sel ? 1.08 : 1 });
      }
      // legal targets
      if (sel >= 0 && !anim) {
        for (const m of targets) {
          const q = P(m.t);
          if (st.b[m.t] !== '.') { ctx.strokeStyle = 'rgba(200,40,30,.85)'; ctx.lineWidth = Math.max(2.5, cell * 0.08); ctx.beginPath(); ctx.arc(q.x, q.y, cell * 0.48, 0, 7); ctx.stroke(); }
          else { ctx.fillStyle = 'rgba(30,60,40,.55)'; ctx.beginPath(); ctx.arc(q.x, q.y, cell * 0.15, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(255,248,230,.6)'; ctx.lineWidth = 1; ctx.stroke(); }
        }
      }
      if (anim) {
        const k = anim.k, a = P(anim.last.f), z = P(anim.last.t);
        const lift = Math.sin(k * Math.PI) * cell * 0.12;
        drawPiece(ctx, anim.last.pc, U.lerp(a.x, z.x, k), U.lerp(a.y, z.y, k) - lift, cell, { hanja, scale: 1 + 0.08 * Math.sin(k * Math.PI) });
      }
    }

    /* ---- input ---- */
    function refreshLegal() {
      legal = playing() && !st.dr && myTurn() ? legalFromState(st) : [];
      if (sel >= 0) { targets = legal.filter((m) => m.f === sel); if (!targets.length) sel = -1; } else targets = [];
    }
    function onDown(e) {
      if (!st || !G || !e.isPrimary) return;
      if (anim || !playing() || !myTurn() || locked() || st.dr) return;
      const q = cv.local(e), i = hit(q.x, q.y);
      if (i < 0) { if (sel >= 0) { sel = -1; targets = []; updateHud(); draw(); } return; }
      if (sel >= 0 && targets.some((m) => m.t === i)) {
        const f = sel; sel = -1; targets = [];
        api.buzz(10); sendAct({ type: 'move', f, t: i }); updateHud(); draw(); return;
      }
      const ch = st.b[i], own = ch !== '.' && (codeOf(ch) >> 3) === st.t;
      if (own && i !== sel) {
        sel = i; targets = legal.filter((m) => m.f === i);
        api.sfx('tick'); api.buzz(6);
        if (!targets.length) api.toast(st.ck ? '장군을 막지 못하는 기물이에요' : '움직일 수 있는 곳이 없어요');
      } else { sel = -1; targets = []; }
      updateHud(); draw();
    }
    cv.cv.addEventListener('pointerdown', onDown);

    /* ---- animation ---- */
    function setBusy(v) { if (busy !== v) { busy = v; api.setBusy(v); } }
    function finishAnim() { clearTimeout(animTimer); if (stopLoop) { stopLoop(); stopLoop = null; } anim = null; setBusy(false); }
    function startAnim(prev, next) {
      const l = next.last;
      const base = prev.b.split(''); base[l.f] = '.';
      anim = { base: base.join(''), last: l, k: 0, t0: performance.now(), dur: 220 / (L.debug.speed || 1) };
      setBusy(true);
      animTimer = setTimeout(() => { if (anim) { finishAnim(); updateHud(); draw(); } }, anim.dur + 600);
      stopLoop = U.loop((dt, t) => {
        if (!anim) return;
        const k = Math.min(1, (t - anim.t0) / anim.dur);
        anim.k = 1 - Math.pow(1 - k, 3);
        if (k >= 1) { finishAnim(); updateHud(); draw(); return; }
        draw();
      });
    }

    function lastText() {
      const l = st.last; if (!l) return '';
      const who = SIDE[l.by];
      if (l.ps) return who + ' 한수쉼';
      return who + ' ' + pName(l.pc) + (l.x ? '→' + pName(l.x) + ' 잡음' : ' 이동');
    }
    function updateHud() {
      const setup = !!st && st.ph === 's' && !st.st;
      const mine = playing() && myTurn() && !st.dr;
      setupBtns.forEach((b, k) => {
        vis(b, setup && myTurn());
        const sd = st ? actor(st) : 0;
        const on = preview === k;
        b.className = 'btn sm' + (on ? ' primary' : '');
        b.innerHTML = '';
        b.append(L.h('span', { style: { fontSize: '13px', fontWeight: 700 }, text: on ? '확정' : ARR[k] }),
          L.h('span', { style: { fontSize: '10.5px', opacity: 0.75, fontWeight: 500 }, text: on ? ARR[k] : ARR[k].split('').map((c) => (hanja ? (c === '마' ? '馬' : '象') : c)).join('') }));
        b.setAttribute('aria-label', ARR[k] + (on ? ' 확정' : ' 미리보기') + (sd ? ' (한)' : ' (초)'));
      });
      vis(glyphBtn, !!st && !(setup && myTurn()));
      vis(passBtn, mine); vis(drawBtn, mine); vis(resignBtn, mine);
      drawBtn.disabled = !canOffer();
      passBtn.disabled = !!(st && st.ck);
      vis(undoBtn, !!st && !st.st && st.ph === 'p' && !api.online && st.solo >= 0);
      undoBtn.disabled = !canUndo();
      if (!mine) disarmAll();
      let h = '';
      if (st && setup) {
        const a = actor(st), p = api.players[a];
        if (myTurn()) h = SIDE[a] + ' 상차림(내 기준 왼쪽→오른쪽) · ' + (preview < 0 ? '배치를 고르세요' : '한 번 더 누르면 확정');
        else h = (p ? p.name : SIDE[a]) + (p && p.ai ? ' 상차림 고르는 중…' : ' 상차림 차례');
      } else if (st && !st.st) {
        const a = actor(st), p = api.players[a];
        const lt = lastText();
        let tail;
        if (mine) {
          let fc = false;
          if (st.o.bk !== 'n') { const ka = st.b.indexOf('K'), kz = st.b.indexOf('k'); if (ka % 9 === kz % 9) { fc = true; for (let s2 = kz + 9; s2 < ka; s2 += 9) if (st.b[s2] !== '.') fc = false; } }
          tail = fc ? '대궁! 피하지 않으면 ' + (st.o.bk === 'd' ? '빅장 무승부' : '빅장 점수 판정') : st.ck ? '장군! 궁을 지키세요' : sel < 0 ? '움직일 기물을 탭하세요' : '갈 곳을 탭하세요';
        } else tail = (p ? p.name : SIDE[a]) + (p && p.ai ? ' 생각 중…' : ' 차례');
        h = (lt ? lt + ' · ' : '') + tail;
        h = st.mc + '/' + st.o.ml + '수 · ' + h;
      } else if (st && st.st) { const r = result(st); h = r ? r.title : ''; }
      hint.textContent = h;
      renderOffer();
    }
    let offerSig = '';
    function renderOffer() {
      const d = st && !st.st && st.dr;
      const responder = d ? 1 - d.by : -1;
      const answer = d && api.canAct(responder);
      const waiting = d && !answer && api.canAct(d.by);
      const sig = d ? (answer ? 'a' : waiting ? 'w' : 'x') + d.by + ':' + st.seq : '';
      if (sig === offerSig) return;
      offerSig = sig;
      offer.innerHTML = '';
      if (!answer && !waiting) { offer.style.display = 'none'; return; }
      offer.style.display = 'flex';
      const by = api.players[d.by] || { name: SIDE[d.by], color: '#888' };
      const sheet = L.h('div', { class: 'sheet', style: { width: '100%' } },
        L.h('span', { class: 'label', text: '무승부 제안' }),
        L.h('h2', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, L.h('span', { class: 'dot', style: { '--c': by.color } }), by.name + ' (' + SIDE[d.by] + ')'),
        L.h('p', { class: 'muted', style: { margin: 0 }, text: answer ? '무승부로 끝낼까요? 거절하면 게임이 이어져요.' : '상대의 답을 기다리는 중…' }));
      if (answer) sheet.append(L.h('div', { class: 'row', style: { justifyContent: 'flex-end', flexWrap: 'nowrap' } },
        L.h('button', { class: 'btn', style: { flex: '1 1 0' }, text: '거절', onclick() { api.sfx('click'); sendAct({ type: 'drawReply', ok: false }); } }),
        L.h('button', { class: 'btn primary', style: { flex: '1 1 0' }, text: '수락 (무승부)', onclick() { api.sfx('click'); sendAct({ type: 'drawReply', ok: true }); } })));
      offer.append(sheet);
    }

    return {
      update(next, prev) {
        const fresh = prev && prev !== next && next.seq !== shownSeq;
        st = next;
        computeFlip();
        if (st.ph !== 's' || !myTurn()) preview = -1;
        if (fresh) {
          const l = next.last;
          if (l && l.id === next.seq) {
            finishAnim();
            if (!l.ps && prev.seq === next.seq - 1 && prev.b[l.f] === l.pc) startAnim(prev, next);
            if (l.ps) { api.sfx('click'); api.toast(SIDE[l.by] + ' 한수쉼'); }
            else if (l.x) { api.sfx('hit'); api.buzz(15); } else api.sfx('thud');
            if (next.ck && !next.st) { api.toast('장군!'); api.sfx('pop'); api.buzz(30); }
            else if (prev.ck && prev.ph === 'p' && !next.st && !l.ps) api.toast('멍군!');
          }
          const e = next.ev;
          if (e && e.id === next.seq) {
            const who = api.players[e.by] ? api.players[e.by].name : SIDE[e.by];
            if (e.k === 'o') { api.sfx('chip'); api.buzz(20); if (!api.canAct(1 - e.by) && !api.canAct(e.by)) api.toast(who + ' 무승부 제안'); }
            else if (e.k === 'n') { api.sfx('click'); api.toast(api.canAct(e.by) ? '상대가 무승부 제안을 거절했어요' : '무승부 제안 거절'); }
            else if (e.k === 'u') { finishAnim(); api.sfx('whoosh'); api.toast('한 수 물렀어요'); }
            else if (e.k === 'set') { api.sfx('card'); api.toast(SIDE[e.by] + ' 상차림 · ' + ARR[e.a]); }
            else if (e.k === 'bj' && !(next.ck)) { api.sfx('pop'); api.buzz(20); api.toast('대궁! ' + SIDE[e.by] + '이 빅장을 불렀어요'); }
          }
        }
        shownSeq = next.seq;
        if (prev && prev.seq !== next.seq) { sel = -1; disarmAll(); }
        if (!prev) { finishAnim(); sel = -1; preview = -1; }
        refreshLegal();
        updateHud();
        draw();
      },
      destroy() {
        finishAnim(); disarmAll();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.destroy(); hud.remove(); hint.remove(); offer.remove();
      },
    };
  }

  L.register({
    id: 'janggi', name: '장기', tag: '전략', cat: '보드',
    tint: '#5c2a24',
    icon: '<path d="M8 6h40v44H8z" fill="none" stroke="currentColor" stroke-width="2.2" opacity=".55"/><path d="M20 6l16 13M36 6L20 19M20 50l16-13M36 50L20 37" stroke="currentColor" stroke-width="1.6" opacity=".55"/><polygon points="22,20 34,20 42,28 42,38 34,46 22,46 14,38 14,28" fill="currentColor"/><text x="28" y="39" font-size="17" font-weight="900" text-anchor="middle" fill="#5c2a24" font-family="serif">車</text>',
    blurb: '9×10 판에서 초(선)와 한이 번갈아 두는 한국 장기. 상차림을 고른 뒤, 상대 궁을 외통으로 몰면 이겨요. 빅장·한수쉼·점수 판정까지 적용돼요.',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, hidden: false, aiDelay: 300,
    options: [
      { id: 'bk', label: '빅장', choices: [{ v: 'd', label: '무승부' }, { v: 's', label: '점수 판정' }, { v: 'n', label: '없음' }], def: 's' },
      { id: 'ml', label: '수 제한', choices: [{ v: 100, label: '100수' }, { v: 150, label: '150수' }, { v: 200, label: '200수' }], def: 200 },
    ],
    quick: [
      '상대 궁(왕)을 「장군」으로 몰아 피할 수 없게(외통) 만들면 이겨요. 초(초록)가 먼저 둬요.',
      '내 차례: 내 기물을 탭 → 점으로 보이는 자리를 탭해 한 수 둬요. 둘 게 마땅치 않으면 「한수쉼」도 돼요.',
      '외통이 안 나고 수 제한(기본 200수)에 닿으면, 남은 기물 점수가 높은 쪽이 이겨요.',
    ],
    rules: [
      { h: '목표', p: [
        '1번 자리가 초(楚, 초록), 2번 자리가 한(漢, 빨강)이에요. 초가 먼저, 한 수씩 번갈아 둬요.',
        '「장군」 = 다음 수에 상대 궁을 잡을 수 있는 상태. 장군을 피할 방법이 하나도 없으면 「외통」 — 이겨요.',
        '내 궁이 장군받는 채로 남는 수는 둘 수 없어요.'] },
      { h: '판 읽는 법', p: [
        '기물은 칸 안이 아니라 선이 만나는 점 위에 놓여요(9줄 × 10줄).',
        '궁성: 양쪽 끝 가운데의 X자 대각선이 그려진 3×3 구역. 궁과 사는 궁성 밖으로 못 나가요.',
        '궁성 안에서는 X자 대각선 선을 따라서도 움직일 수 있어요(궁·사·차·포·졸).'] },
      { h: '기물별 움직임', p: [
        '궁(楚/漢): 궁성 안에서 선을 따라 1칸.',
        '사(士): 궁과 똑같이 궁성 안에서 1칸.',
        '차(車): 가로·세로로 막히지 않는 만큼(가장 강해요). 궁성 안에선 대각선 선으로도.',
        '포(包): 기물 하나를 꼭 뛰어넘어서 가로·세로로. 포는 포를 넘을 수도, 잡을 수도 없어요.',
        '마(馬): 한 칸 곧장 + 한 칸 대각선(날 일(日)자). 곧장 가는 첫 칸이 막히면 못 가요.',
        '상(象): 한 칸 곧장 + 두 칸 대각선(쓸 용(用)자). 지나가는 칸이 하나라도 막히면 못 가요.',
        '졸(卒)·병(兵): 앞이나 옆으로 1칸. 뒤로는 못 가요. 상대 궁성 안에선 대각선 앞으로도.',
        '상대 기물이 있는 자리로 가면 그 기물을 잡아요. 궁도 장군이 풀리지 않으면 잡힐 위기예요.'] },
      { h: '시작 전: 상차림', p: [
        '마(馬)·상(象) 네 개의 자리를 골라요: 마상마상 · 상마상마 · 마상상마 · 상마마상(내 쪽에서 본 왼쪽→오른쪽).',
        '전통대로 한이 먼저 차리고, 초가 그걸 보고 차려요.',
        '아래 버튼을 한 번 누르면 판에 미리 보이고, 한 번 더 누르면 확정돼요. AI는 무작위로 골라요.'] },
      { h: '차례에 할 일', p: [
        '기물 하나를 한 번 움직여요.',
        '또는 「한수쉼」: 차례를 그냥 넘겨요. 장군받는 중에는 못 쉬어요. 누른 뒤 3초 안에 「쉼 확인」.',
        '장군을 받으면 반드시 풀어야 해요: 궁 피하기 · 공격하는 기물 잡기 · 사이 막기. 장군을 막아내는 걸 「멍군」이라고 불러요.'] },
      { h: '승패', p: [
        '외통: 장군을 피할 수 없으면 짐.',
        '기권: 「기권」 → 3초 안에 「기권 확인」.',
        '점수 판정: 정한 수(100/150/200수, 양쪽 수를 모두 셈)에 닿거나, 같은 국면이 세 번 나오면 남은 기물 점수가 높은 쪽이 이겨요.',
        '기물 점수: 차 13 · 포 7 · 마 5 · 상 3 · 사 3 · 졸/병 2. 한은 나중에 두니까 덤 1.5점(시작: 초 72 · 한 73.5). 그래서 점수로는 비기지 않아요.',
        '이름표 오른쪽 금색 숫자가 지금 점수예요.',
        '무승부 제안: 「무승부」 → 3초 안에 「제안 확인」. 상대가 수락하면 비겨요. 거절당하면 상대가 한 수 둔 뒤에 다시 제안할 수 있어요. AI는 비슷하거나 불리하면 수락해요.'] },
      { h: '특수 규칙: 빅장 (옵션)', p: [
        '「대궁」: 두 궁이 같은 세로줄에서 사이에 아무 기물 없이 마주 보는 것. 대궁을 만든 쪽이 「빅장」을 부른 거예요.',
        '상대는 바로 다음 수에 대궁을 풀어야 해요(사이에 기물 넣기·궁 옮기기). 한수쉼으로는 못 풀어요.',
        '풀지 않으면 → 점수 판정(기본, 대회 방식): 그 자리에서 기물 점수로 승부. / 무승부 옵션: 빅장으로 비겨요. / 없음 옵션: 대궁을 따지지 않아요.',
        '대궁이면 두 궁 사이에 빨간 점선이 보여요.'] },
      { h: '조작', p: [
        '내 기물을 탭 → 갈 수 있는 자리에 점(잡을 수 있으면 빨간 원)이 떠요. 그 자리를 탭하면 움직여요. 다른 곳을 탭하면 선택이 풀려요.',
        '직전 수는 금색, 장군받은 궁은 빨갛게 빛나요. 판 아래 안내 줄이 지금 할 일을 알려 줘요.',
        '↶ 무르기: 이 폰에서 사람 1명 대 AI일 때만. 내 직전 수와 AI 응수를 함께 되돌려요(한 번에 한 수).',
        '「글자」 버튼으로 한자/한글 기물을 바꿔요(기기에 기억). 혼자 한을 맡으면 판이 뒤집혀 한이 아래에 와요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 얕게 읽고 가끔 기물을 흘리고, 어려움은 약 0.6초 동안 더 깊이 읽어요.'] },
      { h: '예시', p: [
        '내 차(車)가 상대 궁과 같은 세로줄에 있고 사이가 비었다 → 「장군!」 상대는 궁을 옮기거나, 사이를 막거나, 내 차를 잡아야 해요.',
        '포(包)로 장군: 내 포와 상대 궁 사이에 기물이 딱 하나 있으면 장군이에요. 그 사이 기물을 치우거나 하나 더 넣으면 풀려요.',
        '200수까지 외통이 없고 초 58점 · 한 55.5점이면 → 초 승리(점수 판정).'] },
    ],
    tutorial: [
      { sel: '.jg-board', text: '장기판이에요. 기물은 칸 안이 아니라 선이 만나는 점 위에 놓여요. 아래쪽이 내 편(초, 초록)이고, 목표는 상대 궁을 외통으로 모는 거예요.' },
      { sel: '.jg-palace', text: 'X자가 그려진 이 3×3 구역이 「궁성」이에요(내 쪽 아래에도 있어요). 궁과 사는 궁성 밖으로 못 나가요. 궁성 안에서는 X자 선을 따라 대각선으로도 움직여요.' },
      { sel: '.jg-hud', text: '시작 전에 「상차림」으로 마·상 자리를 골라요. 한이 먼저 고르고, 내 차례가 되면 여기 버튼 4개가 떠요. 한 번 누르면 미리 보기, 한 번 더 누르면 확정!' },
      { sel: '.jg-board', text: '내 기물을 탭하면 갈 수 있는 자리에 점이 떠요(잡을 수 있으면 빨간 원). 그 자리를 탭하면 한 수 끝! 차는 직선 끝까지, 포는 하나를 넘어서, 마는 日자, 상은 用자로 움직여요.' },
      { sel: '.jg-me', text: '아래 이름표가 나, 위가 상대예요. 오른쪽 금색 숫자가 남은 기물 점수예요. 수 제한까지 외통이 안 나면 이 점수가 높은 쪽이 이겨요.' },
      { sel: '.jg-hint', text: '장군을 받으면 궁이 빨갛게 빛나고 이 안내 줄에 알려 줘요. 장군은 반드시 풀어야 해요(피하기 · 잡기 · 막기 = 멍군!).' },
      { sel: '.jg-hud', text: '게임 중엔 여기에 「한수쉼」(차례 넘기기) · 「무승부」 · 「기권」 · 「↶ 무르기」가 생겨요. 위험한 버튼은 한 번 더 눌러 확인해요. 빅장 같은 특수 규칙은 「?」에 쉽게 적어 뒀어요. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _engine: { loadState, legalMoves, legalFromState, think, CFG, facing, inCheck, setBoard, pointsOf, placeArr, emptySetup, ix },
  });
})();
