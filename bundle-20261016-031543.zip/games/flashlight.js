/* 어둠 속 손전등 숨바꼭질 — 8인 고정(봇이 빈자리를 채움), 살인마 1 vs 생존자 7의 비대칭 실시간 게임 (한 폰에 한 명).
   생존자들은 불 꺼진 맵 곳곳의 등불 7개 중 5개를 고쳐 켜고(고치는 중 「딱 맞춰 누르기」), 대문을 열고 탈출해요.
   살인마는 손전등 빛(1.1초)이나 「덥석」으로 생존자를 놀라게 하고, 두 번째에 붙잡아 새장에 가둬요. 새장은 친구가 구출할 수 있고,
   두 번 갇히거나 시간이 다 되면 탈락(유령 구경). 숨을 곳, 소리 물결, 넘을 수 있는 창문, 쓰러뜨리는 책장, 마지막 한 명의 비밀 통로.
   캐릭터: 생존자 8명·살인마 3명(각자 다른 능력). 맵 5곳(각자 기믹).
   Network (snowball.js pattern): the host (or the local phone) runs the pure world engine incl. AI; guests send their
   stick/buttons and draw the host's snapshots (own body predicted locally). Round flow travels in the small coarse
   state via api.setState. The snapshot carries every position, but each view only draws what its player can see. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;
  const hyp = Math.hypot;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const wrapA = (a) => { a = (a + Math.PI) % TAU; if (a < 0) a += TAU; return a - Math.PI; };
  const mmss = (t) => { t = Math.max(0, Math.ceil(t)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  const NP = 8;

  /* ---------- tuning (units = tiles, seconds) ---------- */
  const PR = 0.3;                                         // body radius
  const V_WALK = 2.6, V_RUN = 3.9, V_SNEAK = 1.35, V_SEEK = 4.15, V_BOOST = 5.3, ACC = 30;
  const BOOST_T = 2.2, IMM_T = 1.7;                       // after a scare: speed burst · can't be scared again
  const RANGE = 5.6, HALF = 0.4, BEAM_T = 1.1;            // flashlight: length, half angle, seconds in the beam to scare
  const NV_KID = 2.5, NV_SEEK = 2.0;                      // night-vision radius
  const REACH = 1.6;
  const LAN_T = 37, GATE_T = 12, HEAL_T = 10, RESCUE_T = 1.2, OPEN_T = 0.7, BREAK_T = 1.8, KICK_T = 1.4, CLOSE_T = 1.2;
  const CAGE_T = 45, COLLAPSE_T = 90, DAWN_COL = 60, CAP_T = 270, START_T = 5;
  const VAULT_K = 0.55, VAULT_S = 1.25, STUN_T = 2.2, TRAP_T = 2.5, BLIND_T = 2;
  const LUNGE_T = 0.36, V_LUNGE = 7.4, LUNGE_REC = 1.1, HIT_REC = 1.7;
  const CHK_WARN = 0.5, CHK_DUR = 1.2, CHK_W = 0.17, CHK_G = 0.05;   // skill check: warning, needle sweep, zone sizes (fraction)
  const NEED = 5, HEAR_S = 14, TR = 10, LAMP_R = 2.6, GLOW_R = 1.8;
  const PICK_T = 15, END_T = 7, HEDGE_WARN = 3;
  const SUB = 1 / 60;

  /* ---------- characters ---------- */
  const KIDS = [
    { nm: '질주꾼', tag: '순간 질주', act: '질주', cd: 40, d: '「질주」 2.5초 동안 아주 빨리 달려요 (40초마다)' },
    { nm: '그림자발', tag: '조용한 발걸음', d: '달려도, 삐걱 마루·경보 바닥을 밟아도 소리가 안 나고 눈밭에 발자국도 안 남아요' },
    { nm: '수리공', tag: '정비 기술', d: '등불을 30% 빨리 고치고, 실수해도 덜 망가져요' },
    { nm: '응급대원', tag: '응급 처치', d: '친구 치료·새장 구출이 두 배 빨라요' },
    { nm: '숨바람', tag: '숨기 달인', d: '숨은 곳이 덜컹대지 않고, 들켜도 한 번은 쏙 빠져나가요' },
    { nm: '밝은눈', tag: '밤눈', d: '밤눈이 넓고, 12칸 안의 살인마가 벽 너머로도 보여요' },
    { nm: '섬광', tag: '손거울', act: '반짝', cd: 35, d: '「반짝」 4칸 안의 살인마 눈을 2초 부시게 해요 (35초마다)' },
    { nm: '소음꾼', tag: '자명종', act: '던지기', cd: 25, d: '「던지기」 앞쪽에 자명종을 던져 소리로 살인마를 속여요 (25초마다)' },
    { nm: '연막꾼', tag: '연기 구름', act: '연막', cd: 32, d: '「연막」 발밑에 연기를 피워요. 6초 동안 연기 속은 손전등 빛도 눈길도 막혀요 (32초마다)' },
    { nm: '날쌘손', tag: '재빠른 손', d: '창문을 두 배 빨리 넘고, 대문도 두 배 빨리 열어요' },
    { nm: '버팀이', tag: '강한 담력', d: '손전등 빛을 두 배 오래 버티고(2.2초), 깜짝 놀라면 더 오래 빨라져요' },
    { nm: '방울꾼', tag: '딸랑 덫', act: '방울', cd: 20, d: '「방울」 발밑에 방울 줄을 걸어요(2개까지). 살인마가 밟으면 딸랑! 잠깐 비틀대고 모두에게 3초 보여요 (20초마다)' },
  ];
  const SEEKERS = [
    { nm: '덫사냥꾼', tag: '끈끈이', act: '덫', cd: 8, d: '「덫」 발밑에 끈끈이 덫을 놓아요(3개까지). 밟은 생존자는 잠깐 못 움직이고 위치가 보여요' },
    { nm: '거울유령', tag: '순간 이동', act: '거울', cd: 18, d: '「거울」 거울을 세워 두고, 멀리서 다시 누르면 그 거울로 순간 이동해요' },
    { nm: '박쥐백작', tag: '박쥐 귀', act: '초음파', cd: 24, d: '「초음파」 16칸 안에서 움직이는 생존자가 3초 보여요 · 소리를 맵 끝까지 들어요' },
    { nm: '그림자귀신', tag: '그림자 몸', act: '숨죽이기', cd: 24, d: '「숨죽이기」 7초 동안 손전등을 끄고 그림자가 돼요. 빨라지고, 두근두근도 없고, 2칸 안에서만 보여요. 그림자일 때 「덥석」은 더 멀리 뛰어요 (24초마다)' },
    { nm: '돌진뿔', tag: '황소 뿔', act: '돌진', cd: 20, d: '「돌진」 1.3초 동안 앞으로 무섭게 달려요. 부딪히면 「덥석」과 같고, 서 있는 책장은 부숴요. 벽에 박으면 어질어질 (20초마다)' },
    { nm: '냄새사냥꾼', tag: '냄새 추적', act: '킁킁', cd: 28, d: '뛰는 생존자의 발자국이 5초 동안 보여요. 「킁킁」 20칸 안의 가장 가까운 생존자 2명이 3초 보여요 (28초마다)' },
  ];
  const K_DARAM = 0, K_SOMI = 1, K_TTUK = 2, K_HAE = 3, K_MONG = 4, K_BYUL = 5, K_BAN = 6, K_KONG = 7, K_SMOKE = 8, K_QUICK = 9, K_TOUGH = 10, K_BELL = 11;
  const S_TRAP = 0, S_MIRROR = 1, S_BAT = 2, S_SHADE = 3, S_HORN = 4, S_NOSE = 5;
  const CLOAK_T = 7, CHG_T = 1.3, V_CHG = 7.2, SMOKE_T = 6, SMOKE_R = 2.1, BELL_STUN = 0.9;
  const beamT = (q) => (q.c === K_TOUGH ? BEAM_T * 2 : BEAM_T);

  /* ---------- maps (28×30).
     # wall · w window in an outer wall (look only) · L light switch (school) · . floor · : creaky floor · _ carpet/soft (quiet)
     d doorway · p pallet doorway (a shelf that can be knocked over) · v low window (climb over) · D locked door (needs a key)
     G lantern · E exit gate · K cage · W wardrobe/locker (hide) · X box/bush (hide) · T table · H shelf · S bench · P plant/tree
     R statue/rock/ride · B bed · ~ water · @ seeker start · h secret-passage spot · k key spot · z alarm floor · c crows
     1 2 3 travel pads (pairs). Tall things (# w L E D W H P R) block light.
     new maps: , snow (footprints) · = ice (slippery) · m glowing mushrooms (light) · o / O moving hedges (o shut first, O shut second) ---------- */
  const MAPS = [
    { nm: '달빛 저택', th: 0, gm: { flick: 1, chime: 50 }, g: [
      '######E#####w######w########',
      '#W..:..B#H.......H#B..:...W#',
      '#......B#..T...T..#B.......#',
      '#..G....d..........d...G...#',
      '#..:....#..T...T..#....:...#',
      '#X.....W#H...__..H#W......X#',
      '#......K#....__...#K.......#',
      '###p#####v###dd#v#######p###',
      '#..:.....:..........:......#',
      'w..H..:.....:..@.....:.H...w',
      '#..H....P...____...P...H...#',
      '#.....:.....____.....:.....#',
      '#.:...h.......:........h..:#',
      '#W...:.....G........:....X.#',
      '####d#######p##v#####d######',
      '#...:..X#H.:....H#W...:...W#',
      '#.T..T..#H..__..H#.........#',
      '#.T..T..v...__G..d..B......#',
      '#..:....#H......H#..B...G.:#',
      '#K.....W#...:..K.#X.......X#',
      '#..:....#........#....:....#',
      '###p########d##v####v###p###',
      '#..........:.......:.......#',
      'w.G..H....T..T....H....X...w',
      '#....H..:.........:..H.....#',
      '#K..:....__.h..__....:...KW#',
      '#X.......__....__.......G..#',
      '#...:..W.....:.....P..:..X.#',
      '#.....:.........K......:...#',
      '#####################E######',
    ] },
    { nm: '숲속 캠프', th: 1, gm: { fog: 1, crows: 1 }, g: [
      '#########E##################',
      '#P.....c..._...P.....X..P..#',
      '#..G.......__.....P......W.#',
      '#.P....R...__......:..G....#',
      '#....:...........P.........#',
      '###v####p##.....##p###v#####',
      '#X....:......T.......:...X.#',
      '#..W.....TT.....TT....K....#',
      '#.....G.............c......#',
      'w..P.....__________....P...w',
      '#K....:..__________..:.....#',
      '#..R.....____@_____....G...#',
      '#..X..:..__________..:...X.#',
      '#.....h..............h.....#',
      '#..TT......P....P......TT..#',
      '#W....c....:.......:...K..W#',
      '#......:......G........:...#',
      '####p####v####..####v###p###',
      '#....:......P.......:....X.#',
      '#.X....R........R......P...#',
      '#...G.....~~~~~~~.....c....#',
      '#......:..~~~~~~~~~.......K#',
      '#K..P.....~~~~~~~~~..:.....#',
      '#....X:....~~~~~~~...G...W.#',
      '#..:.......h.......:.......#',
      '#.P....TT.....P......TT..P.#',
      '#...W....:....c.......:...X#',
      '#X......P.........P......W.#',
      '#...:.....K.....:..........#',
      '##################E#########',
    ] },
    { nm: '별빛 박물관', th: 2, gm: { keys: 1, alarm: 1 }, g: [
      '#####E##########w###########',
      '#H..R...H#H......H#H..:..TH#',
      '#........#..T..T..#........#',
      '#..T..k..D...G....#.R....R.#',
      '#R.......#..T..T..#...:....#',
      '#..X...W.#........#X....G.W#',
      '#K...:...#H......H#.K.:....#',
      '####d##v#####D#####v##p#####',
      '#........z.........z.......#',
      'w..H...R...:.@......R...H..w',
      '#..H..G.....TTTT.......H...#',
      '#..z.....:..TTTT..:....z...#',
      '#X.....h...........h.....K.#',
      '#W..R....:....z....:...R..W#',
      '###p####d####D#####v#d######',
      '#..:..X..#H......H#....:..X#',
      '#.T..T...#...G....D.R....R.#',
      '#.T..T..K#..T..T..#........#',
      '#....:...#........#W..:....#',
      '#W..G....#H......H#...k..K.#',
      '#..:...X.#........#........#',
      '##d#####v##########p####d###',
      '#......:........:..........#',
      'w..R..z....TT..TT....z..R..w',
      '#K....H..:..........H....X.#',
      '#....GH.......k......H..G..#',
      '#X..:.....h..........:...W.#',
      '#..R....:....K.......R.....#',
      '#.W...........:.........X..#',
      '#################E##########',
    ] },
    { nm: '달님 놀이공원', th: 3, gm: { flick: 1, pads: '미끄럼 터널', padT: 0.9 }, g: [
      '##E#######w##########w######',
      '#..:....H..1...H....:..X..W#',
      '#G.....HH......HH.......G..#',
      '#..X..:.........:....S.....#',
      '#......#v####p#####v##.....#',
      '#W...:.#..RRR...RRR..#..K..#',
      '#..:...v..RRR...RRR..#...X.#',
      '#..G...#...RRR.@.RRR.p.....#',
      '#......#..RRR.K.RRR..#.....#',
      '#.X..:.#..RRR.h.RRR..#..W..#',
      '#......##d#####v###p##.....#',
      '#K.....:.......:......:...G#',
      '#...S..TT..2...X...TT..S...#',
      '#.P....TT..........TT....P.#',
      'w....:.......h......:...X..w',
      '#..W...H.H.....3.H.H....K..#',
      '#......H.H.....:.H.H.......#',
      '#..:...H.H..G....H.H...:...#',
      '#X.....HXH.......HWH......X#',
      '#....:.......:......:......#',
      '#####p####v###..###v####p###',
      '#..1...:....P....P.....X...#',
      '#.G..X.....__..__.....2....#',
      '#....:.....__..__......:...#',
      '#..S...R........R...S....K.#',
      '#W....:.....3...........G..#',
      '#...P....:......:....P....W#',
      '#.K...X.........h......X...#',
      '#....:.........:.......:...#',
      '####################E#######',
    ] },
    { nm: '한밤 학교', th: 4, gm: { chime: 55, sw: 1, pads: '엘리베이터', padT: 1.5 }, g: [
      '#######w####E#####w#########',
      '#H.....WH#H......H#H..:...H#',
      '#.TT.TT..#........#..TT.TT.#',
      '#.TT.TT.:#.:..G...#..TT.TT.#',
      '#........L........#:.......#',
      '#.TT.TT..#X......X#..TT.TT.#',
      '#G......K#..1.....#K.....GW#',
      '##d###p###v###d#####p#d#####',
      '#W.W.W.:...........:.W.W.W.#',
      'L......:.....:..@....:.....L',
      '#......h.....SS.......h....#',
      '#....:.......SS.....:......#',
      '#.W.W.W.:.......:...W.W.W..#',
      '#p#####d###v###d#####d###p##',
      '#...:....#.:......#........#',
      '#.TT.TT..#H..G...H#.TT.TT..#',
      '#.TT.TT.X#........L.TT.TT..#',
      '#........#S..2..S.#....:..K#',
      '#K.TT.TT.#........#.TT.TT.G#',
      '#G.TT.TT.#.WX..X.W#.TT.TT..#',
      '##d#####v#p#####d#####v###d#',
      '#.:.........:.....:........#',
      'w..W..P.....G.....P....X...w',
      '#....:....HHHHHH......:....#',
      '#X..1.....H....H.....h.....#',
      '#...:.....H.K..H......:..K.#',
      '#.S.......HHH.HH.....S...W.#',
      '#....2.:.........:....X....#',
      '#W.......:..............:..#',
      '##########E#################',
    ] },
    { nm: '눈 덮인 산장', th: 5, gm: { snow: 1, ice: 1 }, g: [
      '#############E##############',
      '#,,,,,,,,,,,,,,,,,,,,,,,,,,#',
      '#,##w######,,X,,,######w##,#',
      '#,#W....G.#,P,,,,#.G....W#,#',
      '#,#.......#,,,,K,#.......#,#',
      '#,#..TT...v,,,,,,p...TT:.#,#',
      '#,#:____:.#,H,,H,#..___..#,#',
      '#,#.____.X#,,,:,,#X.___.B#,#',
      '#,####d####,,,,,,####d####,#',
      '#,,,,,,,,,,P,,@,,,,,,,,,,,,#',
      '#,P,,,,,:,,,,,,,,P,,,,,,,P,#',
      '#,,,,,,K,,========,,K,,,,,,#',
      '#,,:,,X,,==========,,,,,X,,#',
      '#,,,,,,,,==========:,,h,,,,#',
      '#,,,G,,,,====RP====,,,,,,,P#',
      '#,X,,,,P,====RR====,X,,G,,,#',
      '#,,,,,,,,==========,,,,,,,,#',
      '#,K,,h,,,==========,P,,,,,,#',
      '#P,,H,:,,,========,,,:,H,K,#',
      '#,,,,,,,,X,,,,,,,,,,,,,,,,,#',
      '#,####d####,,,,,,####v####,#',
      '#,#X.....H#PH,,P,#....:.B#,#',
      '#,#.TT.:..#,,,,,,#.G.....#,#',
      '#,#.......p,,G,,,d....TT.X,#',
      '#,#..__.G.#,,,,,,#..__...#,#',
      '#,#W.__...#,X,,,h#X.__..W#,#',
      '#,##w######,,,:,,######w##,#',
      '#,,,,X,,,,,,K,,,X,,,,,,,,,,#',
      '#,P,,,,,P,,,,,,,,,,P,,,,,P,#',
      '##############E#############',
    ] },
    { nm: '반딧불 동굴', th: 6, gm: { glow: 1, echo: 1 }, g: [
      '#####E######################',
      '#####.######################',
      '####.....##########.....####',
      '###....h.X#######.X.....G.##',
      '##.G........p..##...h:....##',
      '##...:......#:.............#',
      '##W...m....##.............W#',
      '###.....K.###..##..K..m...##',
      '####.....####p#####......###',
      '####..#######.m#########p###',
      '####v########...#######..###',
      '####...####.......####...###',
      '###....W##.R.@...R.##.....##',
      '##.X..........:......K...X.#',
      '##........m............:...#',
      '##G..........~~~...m.......#',
      '##..:....#.R.~~~.R.#.....G.#',
      '##....K..##.......##.W.....#',
      '###.....####X...G####.....##',
      '####.m.#######v#######...###',
      '####...######h..######m.####',
      '####.......###..##.......###',
      '###.......X.##..#.K.......##',
      '###W....m...##:##.......h.##',
      '##....................:....#',
      '###.G.:.................G.##',
      '###......K..#####W..m....X##',
      '####.......#######.......###',
      '######################.#####',
      '######################E#####',
    ] },
    { nm: '달빛 미로 정원', th: 7, gm: { hedge: 40 }, g: [
      '###E########################',
      '#.......X....K.....X.......#',
      '#.........h........W.......#',
      '#..##d#oo####..####OO####..#',
      '#..#..#..####..####..p.G#..#',
      '#..#G.v..####..####..#..#..#',
      '#..####..####..####..#d##..#',
      '#.:..........:...........:.#',
      '#X.....K............K.....X#',
      '#..####..####d##v##..####..#',
      '#..####..#..S....X#..####..#',
      '#oo####..#........#..####OO#',
      '#..####..#...@....#..####..#',
      '#.......:#..____..#........#',
      '#G..W..h.#.._R__..p........#',
      '#........p..__R_..#.h..W..G#',
      '#........#..____..#:.......#',
      '#..####..#........#..####..#',
      '#OO####..#.X......#..####oo#',
      '#..####..#.....S..#..####..#',
      '#..####..##v##d####..####..#',
      '#X.....K............K.....X#',
      '#.:...........:.G........:.#',
      '#..#p##OO####..####..####..#',
      '#..#..#..####..####..v..#..#',
      '#..#.Gd..####..####oo#G.#..#',
      '#..####..####..####..##d#..#',
      '#.......W..................#',
      '#.......X.....K....X.......#',
      '########################E###',
    ] },
  ];
  const THEMES = [
    { f: [92, 62, 44], f2: [128, 92, 62], wl: '#2c2142', wd: '#1d1529', wt: '#433059', tr: 'rgba(227,174,69,.6)', cp: '#5a1d3a', cp2: '#74284c', bg: '#0b0814', plank: 1 },
    { f: [46, 74, 44], f2: [70, 96, 54], wl: '#2b3a22', wd: '#1a2614', wt: '#4c5f33', tr: 'rgba(170,140,80,.55)', cp: '#5b4a2e', cp2: '#6e5a38', bg: '#07100a', grass: 1 },
    { f: [96, 90, 104], f2: [124, 116, 132], wl: '#2a2a3c', wd: '#1a1a28', wt: '#44445c', tr: 'rgba(200,190,240,.5)', cp: '#3a2a5a', cp2: '#4a3a70', bg: '#08080f', tile: 1 },
    { f: [70, 48, 88], f2: [96, 66, 110], wl: '#3a2040', wd: '#24122a', wt: '#5a3060', tr: 'rgba(255,150,210,.6)', cp: '#2a4a6a', cp2: '#3a6088', bg: '#0c0612', tile: 1 },
    { f: [88, 74, 58], f2: [112, 96, 74], wl: '#2a3240', wd: '#1a2029', wt: '#3e4a5e', tr: 'rgba(160,200,230,.5)', cp: '#2e4a3a', cp2: '#3a5c48', bg: '#080a0f', plank: 1 },
    { f: [104, 76, 52], f2: [128, 96, 66], wl: '#3b2a24', wd: '#251a16', wt: '#5e463a', tr: 'rgba(230,245,255,.7)', cp: '#6a2a2a', cp2: '#8a3a3a', bg: '#0a0e16', plank: 1, snow: 1 },
    { f: [64, 58, 70], f2: [84, 76, 90], wl: '#2a2334', wd: '#17121f', wt: '#3f3550', tr: 'rgba(120,230,200,.45)', cp: '#3a3048', cp2: '#4a3e5c', bg: '#05040a', cave: 1 },
    { f: [46, 78, 46], f2: [120, 108, 90], wl: '#1f3a1f', wd: '#122412', wt: '#2f5a2c', tr: 'rgba(200,230,170,.5)', cp: '#6a6a72', cp2: '#82828c', bg: '#060c07', grass: 1, garden: 1 },
  ];
  const WALLS = '#wLE', SOLID = '#wLEDvGKWXTHSPRB~o', OPAQ = '#wLEDWHPRo', BOUND = '#wLEDvpd', HIDES = 'WX', FLOORS = '.:_,=m';
  const SPOT_NM = [['옷장', '상자 속'], ['텐트', '덤불 속'], ['진열장', '상자 속'], ['매표소', '인형 수레'], ['사물함', '상자 속'], ['장작 창고', '눈더미'], ['바위틈', '버섯 덤불'], ['정자', '덤불 속']];
  const D4 = [[0, 1], [0, -1], [1, 0], [-1, 0]];
  const D8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

  function parseMap(m, k) {
    const g = m.g, H = g.length, Wd = g[0].length, N = Wd * H;
    const c = new Array(N);
    for (let y = 0; y < H; y++) for (let x = 0; x < Wd; x++) c[y * Wd + x] = g[y][x] || '#';
    const M = { k, nm: m.nm, th: m.th, gm: m.gm || {}, W: Wd, H, N, c, sol: new Uint8Array(N), opq: new Uint8Array(N), room: new Int16Array(N).fill(-1),
      sx: Wd / 2, sy: H / 2, rooms: 0, roomT: [], walk: [], lans: [], gates: [], cages: [], spots: [], vaults: [], pals: [], doors: [], keys: [],
      crows: [], hatches: [], pads: [], sw: [], glow: [], hedge: [], alarm: new Uint8Array(N), palAt: new Int16Array(N).fill(-1), vAt: new Int16Array(N).fill(-1),
      doorAt: new Int16Array(N).fill(-1), gateAt: new Int16Array(N).fill(-1), spotAt: new Int16Array(N).fill(-1) };
    for (let i = 0; i < N; i++) { M.sol[i] = SOLID.indexOf(c[i]) >= 0 ? 1 : 0; M.opq[i] = OPAQ.indexOf(c[i]) >= 0 ? 1 : 0; }
    const inb = (x, y) => x >= 0 && y >= 0 && x < Wd && y < H;
    const solid = (x, y) => !inb(x, y) || M.sol[y * Wd + x] === 1;
    let rid = 0;
    for (let i = 0; i < N; i++) {
      if (M.room[i] >= 0 || BOUND.indexOf(c[i]) >= 0) continue;
      const q = [i]; M.room[i] = rid;
      while (q.length) {
        const j = q.pop(), x = j % Wd, y = (j / Wd) | 0;
        for (const [dx, dy] of D4) {
          const nx = x + dx, ny = y + dy; if (!inb(nx, ny)) continue;
          const n = ny * Wd + nx;
          if (M.room[n] >= 0 || BOUND.indexOf(c[n]) >= 0) continue;
          M.room[n] = rid; q.push(n);
        }
      }
      rid++;
    }
    M.rooms = rid;
    for (let r = 0; r < rid; r++) M.roomT.push([]);
    const adjOf = (x, y) => { const a = []; for (const [dx, dy] of D4) { const nx = x + dx, ny = y + dy; if (!solid(nx, ny)) a.push(ny * Wd + nx); } return a; };
    const pairs = {};
    for (let i = 0; i < N; i++) {
      const x = i % Wd, y = (i / Wd) | 0, ch = c[i], cx = x + 0.5, cy = y + 0.5;
      if (M.room[i] >= 0) M.roomT[M.room[i]].push(i);
      if (!M.sol[i]) M.walk.push(i);
      if (ch === '@') { M.sx = cx; M.sy = cy; }
      else if (ch === 'G') M.lans.push({ i, x: cx, y: cy, adj: adjOf(x, y) });
      else if (ch === 'K') M.cages.push({ i, x: cx, y: cy, adj: adjOf(x, y) });
      else if (HIDES.indexOf(ch) >= 0) { M.spotAt[i] = M.spots.length; M.spots.push({ i, x: cx, y: cy, k: ch, adj: adjOf(x, y) }); }
      else if (ch === 'v' || ch === 'p') {
        const ax = !solid(x - 1, y) && !solid(x + 1, y) ? 0 : 1;   // 0: cross left↔right · 1: cross up↔down
        const o = { i, x: cx, y: cy, ax };
        if (ch === 'v') { M.vAt[i] = M.vaults.length; M.vaults.push(o); } else { M.palAt[i] = M.pals.length; M.pals.push(o); }
      } else if (ch === 'D') { M.doorAt[i] = M.doors.length; M.doors.push({ i, x: cx, y: cy }); }
      else if (ch === 'E') {
        let ix = cx, iy = cy, dx = 0, dy = 0;
        for (const [ddx, ddy] of D4) if (inb(x + ddx, y + ddy) && !solid(x + ddx, y + ddy)) { ix = cx + ddx; iy = cy + ddy; dx = -ddx; dy = -ddy; }
        M.gateAt[i] = M.gates.length; M.gates.push({ i, x: cx, y: cy, ix, iy, dx, dy });
      } else if (ch === 'k') M.keys.push({ i, x: cx, y: cy });
      else if (ch === 'z') M.alarm[i] = 1;
      else if (ch === 'c') M.crows.push({ i, x: cx, y: cy });
      else if (ch === 'h') M.hatches.push({ i, x: cx, y: cy });
      else if (ch === 'm') M.glow.push({ i, x: cx, y: cy });
      else if (ch === 'o' || ch === 'O') M.hedge.push({ i, x: cx, y: cy, ph: ch === 'o' ? 0 : 1 });
      else if (ch >= '1' && ch <= '3') { const o = { i, x: cx, y: cy, to: -1 }; const j = M.pads.length; M.pads.push(o); if (pairs[ch] != null) { o.to = pairs[ch]; M.pads[pairs[ch]].to = j; } else pairs[ch] = j; }
      else if (ch === 'L') {
        for (const [dx, dy] of D4) {
          const nx = x + dx, ny = y + dy; if (!inb(nx, ny)) continue;
          const n = ny * Wd + nx; if (M.room[n] < 0 || solid(nx, ny)) continue;
          M.sw.push({ i, x: cx, y: cy, room: M.room[n], dx, dy }); break;
        }
      }
    }
    // walls that touch a room are lit with it (looks nicer)
    M.roomLit = M.roomT.map((ts) => {
      const set = new Set(ts);
      for (const i of ts) { const x = i % Wd, y = (i / Wd) | 0; for (const [dx, dy] of D8) { const nx = x + dx, ny = y + dy; if (inb(nx, ny)) { const n = ny * Wd + nx; if (M.room[n] < 0) set.add(n); } } }
      return Array.from(set);
    });
    // static distance from the seeker start (for spawning kids far away)
    const f = new Int16Array(N).fill(-1), q = [((M.sy | 0) * Wd + (M.sx | 0))];
    f[q[0]] = 0;
    for (let h = 0; h < q.length; h++) { const j = q[h], x = j % Wd, y = (j / Wd) | 0; for (const [dx, dy] of D4) { const nx = x + dx, ny = y + dy; if (!inb(nx, ny)) continue; const n = ny * Wd + nx; if (f[n] >= 0 || (M.sol[n] && c[n] !== 'v')) continue; f[n] = f[j] + 1; q.push(n); } }
    M.dS = f;
    return M;
  }
  const PM = MAPS.map(parseMap);
  /* ---------- small helpers ---------- */
  function mulberry(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function hash3(a, b, c) { let h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul(c | 0, 2246822519)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }

  /* ---------- geometry (doors, shelves and gates change, so solids live in the world) ---------- */
  const solidT = (W, x, y) => x < 0 || y < 0 || x >= W.M.W || y >= W.M.H || W.sol[y * W.M.W + x] === 1;
  const opaqT = (W, x, y) => x < 0 || y < 0 || x >= W.M.W || y >= W.M.H || W.opq[y * W.M.W + x] === 1;
  const tileAt = (M, x, y) => clamp(Math.floor(y), 0, M.H - 1) * M.W + clamp(Math.floor(x), 0, M.W - 1);
  function castRay(W, x, y, dx, dy, maxD, solidToo) {
    let tx = Math.floor(x), ty = Math.floor(y);
    const sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1;
    const tdx = dx !== 0 ? Math.abs(1 / dx) : 1e9, tdy = dy !== 0 ? Math.abs(1 / dy) : 1e9;
    let tmx = dx > 0 ? (tx + 1 - x) * tdx : dx < 0 ? (x - tx) * tdx : 1e9;
    let tmy = dy > 0 ? (ty + 1 - y) * tdy : dy < 0 ? (y - ty) * tdy : 1e9;
    for (let k = 0; k < 90; k++) {
      let d;
      if (tmx < tmy) { d = tmx; tmx += tdx; tx += sx; } else { d = tmy; tmy += tdy; ty += sy; }
      if (d >= maxD) return maxD;
      if (solidToo ? solidT(W, tx, ty) : opaqT(W, tx, ty)) return d;
    }
    return maxD;
  }
  function los(W, x0, y0, x1, y1) {
    const dx = x1 - x0, dy = y1 - y0, d = hyp(dx, dy);
    if (d < 1e-4) return true;
    return castRay(W, x0, y0, dx / d, dy / d, d) >= d - 0.02;
  }
  function resolve(W, p) {
    const x0 = Math.floor(p.x - PR), x1 = Math.floor(p.x + PR), y0 = Math.floor(p.y - PR), y1 = Math.floor(p.y + PR);
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
      if (!solidT(W, tx, ty)) continue;
      const cx = clamp(p.x, tx, tx + 1), cy = clamp(p.y, ty, ty + 1);
      const dx = p.x - cx, dy = p.y - cy, d = hyp(dx, dy);
      if (d >= PR) continue;
      if (d > 1e-6) { const k = (PR - d) / d; p.x += dx * k; p.y += dy * k; }
      else {
        const l = p.x - tx, r = tx + 1 - p.x, u = p.y - ty, b = ty + 1 - p.y, m = Math.min(l, r, u, b);
        if (m === l) p.x = tx - PR; else if (m === r) p.x = tx + 1 + PR; else if (m === u) p.y = ty - PR; else p.y = ty + 1 + PR;
      }
    }
  }
  function moveBody(W, p, dx, dy) { p.x += dx; resolve(W, p); p.y += dy; resolve(W, p); }
  // corner help: walking into a wall right next to an opening slides you into the opening (no snagging on door frames)
  function cornerSlide(W, p, ax, ay, step) {
    const hor = Math.abs(ax) >= Math.abs(ay), s = hor ? Math.sign(ax) : Math.sign(ay);
    if (!s || Math.abs(hor ? ax : ay) < 0.55 * Math.max(Math.abs(ax), Math.abs(ay))) return;
    const tx = Math.floor(p.x), ty = Math.floor(p.y);
    if (hor) {
      const fx0 = Math.floor(p.x + s * (PR + 0.08));
      if (fx0 === tx) return;
      if (!solidT(W, fx0, ty)) { const c = ty + 0.5, d = c - p.y; if (Math.abs(d) > 0.02) moveBody(W, p, 0, clamp(d, -step, step)); return; }
      for (const o of [-1, 1]) { const ny = ty + o; if (!solidT(W, fx0, ny) && !solidT(W, tx, ny) && Math.abs(ny + 0.5 - p.y) < 0.95) { moveBody(W, p, 0, clamp(ny + 0.5 - p.y, -step, step)); return; } }
    } else {
      const fy0 = Math.floor(p.y + s * (PR + 0.08));
      if (fy0 === ty) return;
      if (!solidT(W, tx, fy0)) { const c = tx + 0.5, d = c - p.x; if (Math.abs(d) > 0.02) moveBody(W, p, clamp(d, -step, step), 0); return; }
      for (const o of [-1, 1]) { const nx = tx + o; if (!solidT(W, nx, fy0) && !solidT(W, nx, ty) && Math.abs(nx + 0.5 - p.x) < 0.95) { moveBody(W, p, clamp(nx + 0.5 - p.x, -step, step), 0); return; } }
    }
  }

  /* ---------- world ---------- */
  function spawnKids(M, n, rng) {
    const cand = M.walk.filter((i) => M.dS[i] >= 11 && '.:_,='.indexOf(M.c[i]) >= 0);
    for (let i = cand.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); const t = cand[i]; cand[i] = cand[j]; cand[j] = t; }
    const out = [];
    for (const t of cand) { const x = (t % M.W) + 0.5, y = ((t / M.W) | 0) + 0.5; if (out.every((o) => hyp(o[0] - x, o[1] - y) >= 4)) out.push([x, y]); if (out.length >= n) break; }
    for (let k = 0; out.length < n; k++) { const t = cand[k % cand.length]; out.push([(t % M.W) + 0.5, ((t / M.W) | 0) + 0.5]); }
    return out;
  }
  function newWorld(st) {
    const M = PM[st.mk] || PM[0], np = st.np, rng = mulberry(((st.rid | 0) * 7919 + (st.rd | 0) * 104729) | 0);
    const W = { M, seed: st.rid | 0, t: 0, go: 0, sk: st.sk, np,
      sol: Uint8Array.from(M.sol), opq: Uint8Array.from(M.opq), dv: 1, pv: 0, pass: null, fc: new Map(),
      pl: [], lan: M.lans.map(() => ({ p: 0, lit: 0, kick: 0, hum: 2 + rng() * 3, n: 0 })),
      gate: M.gates.map(() => ({ p: 0, open: 0 })), pw: 0, col: -1,
      pal: M.pals.map(() => 0), door: M.doors.map(() => 1), keys: [], hatch: -1, hop: 0,
      spots: M.spots.map(() => ({ occ: -1, since: 0, camp: 0 })), cage: M.cages.map(() => -1),
      traps: [], mir: null, toys: [], smk: [], bel: [], skRv: 0, hph: 0, hwk: 0, crow: M.crows.map(() => 0), lit: new Array(M.rooms).fill(0),
      rvA: 0, chimeT: M.gm.chime || 1e9, fog: [], noise: [], fx: [], fxN: 0, ckN: 0, res: null, claim: { res: {}, heal: {}, key: -1 }, hk: null };
    if (M.keys.length) { const ks = M.keys.map((_, j) => j); for (let i = ks.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); const t = ks[i]; ks[i] = ks[j]; ks[j] = t; } W.keys = ks.slice(0, Math.min(3, ks.length)).sort((a, b) => a - b); }
    if (M.hatches.length) W.hatch = Math.floor(rng() * M.hatches.length);
    if (M.gm.fog) for (let k = 0; k < 4; k++) W.fog.push({ a: rng() * TAU, b: rng() * TAU, s: 0.7 + rng() * 0.6, r: 3 + rng() * 0.9 });
    const sp = spawnKids(M, np - 1, rng);
    let k = 0;
    for (let i = 0; i < np; i++) {
      const sk = i === st.sk;
      let x = M.sx, y = M.sy;
      if (!sk) { x = sp[k][0]; y = sp[k][1]; k++; }
      const cc = st.ch && st.ch[i] >= 0 ? st.ch[i] : 0, c = clamp(cc | 0, 0, sk ? SEEKERS.length - 1 : KIDS.length - 1);
      const a = sk ? Math.PI / 2 : rng() * TAU - Math.PI;
      W.pl.push({ i, sk: sk ? 1 : 0, c, x, y, vx: 0, vy: 0, a, ma: a, st: 0, hp: 2, hl: 0, hid: -1, ent: null, cg: -1, ct: 0, hk: 0,
        ex: 0, imm: 0, bst: 0, stun: 0, blind: 0, ln: 0, lr: 0, lhit: 0, cd: 0, cl: 0, chg: 0, job: null, vt: null, ride: null, chk: null, nc: 0, key: 0,
        rn: 0, sn: 0, lt: -1, nT: 0.3, rv: 0, used: 0, alT: -9, wh: 3, sLan: M.lans.map(() => 0), nRes: 0, nHeal: 0, nHit: 0, nStun: 0, esc: 0, out: 0 });
    }
    return W;
  }
  function fx(W, code, x, y, a, b) {
    W.fxN++;
    const e = [W.fxN, code, Math.round(x * 10), Math.round(y * 10), a | 0, b | 0];
    W.fx.push(e); if (W.fx.length > 14) W.fx.shift();
    if (W.hk && W.hk.fx) { try { W.hk.fx(code, x, y, a | 0, b | 0); } catch (er) { /* view hook */ } }
  }
  // noise kinds: 0 creak · 1 running · 2 hiding spot creak · 3 failed skill check · 4 crows · 5 alarm floor · 6 lantern hum
  // 7 rattle toy · 8 fast vault · 9 shelf falls · 10 trap · 11 sniffle (scared kid) · 12 cage opened · 13 bell line · 14 charge crash
  const LOUD = [0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1];
  function makeNoise(W, x, y, kind, src) { W.noise.push({ x, y, k: kind, src, t: W.t }); fx(W, 0, x, y, kind, src); }
  function setPal(W, j, s) { W.pal[j] = s; W.sol[W.M.pals[j].i] = s === 1 ? 1 : 0; W.dv++; }
  function setDoor(W, j, l) { const i = W.M.doors[j].i; W.door[j] = l; W.sol[i] = l ? 1 : 0; W.opq[i] = l ? 1 : 0; W.dv++; }
  function setGate(W, j, open) { const i = W.M.gates[j].i; W.gate[j].open = open; W.sol[i] = open ? 0 : 1; W.opq[i] = open ? 0 : 1; W.dv++; }
  const seekerOf = (W) => W.pl[W.sk];
  const hiddenFrom = (q) => q.st !== 0 || q.hid >= 0 || !!q.ride;
  const beamOn = (S) => S.st === 0 && !(S.stun > 0) && !(S.blind > 0) && !S.ride && !(S.cl > 0);
  const nvOf = (p) => (p.sk ? NV_SEEK : p.c === K_BYUL ? NV_KID * 1.6 : NV_KID);

  /* ---------- light & sight ---------- */
  function fogPos(W, k) { const f = W.fog[k], M = W.M, t = W.t * 0.03 * f.s; return [M.W * (0.5 + 0.4 * Math.sin(t + f.a)), M.H * (0.5 + 0.4 * Math.sin(t * 0.77 + f.b))]; }
  function inFog(W, x, y) { for (let k = 0; k < W.fog.length; k++) { const q = fogPos(W, k); if (hyp(q[0] - x, q[1] - y) < W.fog[k].r) return true; } return false; }
  function flickOn(W, r) { const T = W.t + r * 3.3, k = Math.floor(T / 8); return T - k * 8 < 1.8 && hash3(W.seed, r, k) < 0.3; }
  function roomLit(W, r) { return r >= 0 && (W.lit[r] > 0 || (!!W.M.gm.flick && W.go && flickOn(W, r))); }
  function lampLit(W, x, y) {
    for (let j = 0; j < W.lan.length; j++) { if (!W.lan[j].lit) continue; const o = W.M.lans[j]; if (hyp(o.x - x, o.y - y) < LAMP_R && los(W, o.x, o.y, x, y)) return true; }
    const gl = W.M.glow;
    for (let j = 0; j < gl.length; j++) { const o = gl[j]; if (hyp(o.x - x, o.y - y) < GLOW_R && los(W, o.x, o.y, x, y)) return true; }
    return false;
  }
  // smoke clouds block light and eyes along a line (segment passes close to a cloud's centre)
  function smokeLine(W, x0, y0, x1, y1) {
    for (const o of W.smk) {
      const dx = x1 - x0, dy = y1 - y0, L2 = dx * dx + dy * dy;
      const k = L2 > 1e-6 ? clamp(((o.x - x0) * dx + (o.y - y0) * dy) / L2, 0, 1) : 0;
      if (hyp(x0 + dx * k - o.x, y0 + dy * k - o.y) < SMOKE_R * 0.9) return true;
    }
    return false;
  }
  function hedgePh(W) { const T = W.M.gm.hedge; return !T || W.t < START_T ? 0 : Math.floor((W.t - START_T) / T) % 2; }
  function syncHedge(W) { // moving hedges: 'o' shut in phase 0, 'O' shut in phase 1 (time based, so guests follow W.t)
    const M = W.M; if (!M.hedge.length) return;
    const ph = hedgePh(W); if (ph === W.hph) return;
    W.hph = ph;
    for (const o of M.hedge) { const shut = o.ph === ph ? 1 : 0; W.sol[o.i] = shut; W.opq[o.i] = shut; }
    W.dv++;
    for (const p of W.pl) {
      if (p.st !== 0 || p.hid >= 0 || p.ride) continue;
      const t = tileAt(M, p.x, p.y);
      if (W.sol[t]) { const b = walkTile(W, p.x, p.y); p.x = (b % M.W) + 0.5; p.y = ((b / M.W) | 0) + 0.5; p.vt = null; }
      resolve(W, p);
    }
  }
  const litAt = (W, x, y) => roomLit(W, W.M.room[tileAt(W.M, x, y)]) || lampLit(W, x, y);
  function inBeam(W, S, q) {
    if (!beamOn(S) || !W.go) return false;
    const dx = q.x - S.x, dy = q.y - S.y, d = hyp(dx, dy);
    if (d > RANGE) return false;
    if (Math.abs(wrapA(Math.atan2(dy, dx) - S.a)) > HALF + Math.atan2(PR * 0.8, Math.max(d, 0.3))) return false;
    if (d > 2.2 && W.fog.length && inFog(W, q.x, q.y)) return false;
    if (d > 1.2 && W.smk.length && smokeLine(W, S.x, S.y, q.x, q.y)) return false;
    return los(W, S.x, S.y, q.x, q.y);
  }
  // seen through walls (outline only)
  function aura(W, v, q) {
    if (q === v || hiddenFrom(q)) return false;
    if (W.rvA > 0) return true;
    if (v.sk && q.rv > 0) return true;
    if (!v.sk && q.sk && W.skRv > 0) return true;
    if (!v.sk && q.sk && v.c === K_BYUL && !(q.cl > 0) && hyp(q.x - v.x, q.y - v.y) < 12) return true;
    return false;
  }
  // really seen (lit and in line of sight)
  function seeFull(W, v, q) {
    if (q === v) return true;
    if (hiddenFrom(q)) return false;
    const d = hyp(q.x - v.x, q.y - v.y);
    if (q.sk && q.cl > 0) return d < 2 && los(W, v.x, v.y, q.x, q.y);   // a shadow: only seen up close
    if (d > 1.2 && W.smk.length && smokeLine(W, v.x, v.y, q.x, q.y)) return false;
    let lit = d <= nvOf(v);
    if (!lit && q.sk && beamOn(q) && W.go) lit = d < 14;          // the flashlight gives the seeker away
    if (!lit && !q.sk && inBeam(W, seekerOf(W), q)) lit = true;
    if (!lit && litAt(W, q.x, q.y)) lit = true;
    if (lit && d > 1.8 && W.fog.length && inFog(W, q.x, q.y)) lit = false;
    return lit && los(W, v.x, v.y, q.x, q.y);
  }
  const canSee = (W, v, q) => seeFull(W, v, q) || aura(W, v, q);

  /* ---------- interactions ---------- */
  function nearSpot(W, p, free) {
    let best = -1, bd = REACH;
    const sp = W.M.spots;
    for (let j = 0; j < sp.length; j++) {
      if (free && W.spots[j].occ >= 0) continue;
      const d = hyp(sp[j].x - p.x, sp[j].y - p.y);
      if (d < bd) { bd = d; best = j; }
    }
    return best;
  }
  function palNear(W, p) {
    let best = -1, bd = 1.45;
    for (let j = 0; j < W.M.pals.length; j++) { if (W.pal[j] !== 0) continue; const o = W.M.pals[j], d = hyp(o.x - p.x, o.y - p.y); if (d < bd) { bd = d; best = j; } }
    return best;
  }
  function vaultAt(W, p) {
    const M = W.M; let best = null, bd = 1.1;
    const test = (o, kind, j) => {
      const dx = p.x - o.x, dy = p.y - o.y, along = o.ax === 0 ? dx : dy, lat = o.ax === 0 ? dy : dx, d = Math.abs(along);
      if (Math.abs(lat) > 0.55 || d > bd || d < 0.3) return;
      const s = along >= 0 ? 1 : -1, lx = o.ax === 0 ? o.x - s : o.x, ly = o.ax === 0 ? o.y : o.y - s;
      if (solidT(W, Math.floor(lx), Math.floor(ly))) return;
      bd = d; best = { kind, j, x1: lx, y1: ly };
    };
    for (let j = 0; j < M.vaults.length; j++) test(M.vaults[j], 'v', j);
    if (!p.sk) for (let j = 0; j < M.pals.length; j++) if (W.pal[j] === 1) test(M.pals[j], 'p', j);
    return best;
  }
  function nearIdx(list, p, r, ok) { let best = -1, bd = r; for (let j = 0; j < list.length; j++) { if (ok && !ok(j)) continue; const d = hyp(list[j].x - p.x, list[j].y - p.y); if (d < bd) { bd = d; best = j; } } return best; }
  // what the big button does right now (the view shows the same label). want = the AI asks for one kind only
  function kidCtx(W, p, want) {
    if (p.sk || p.st !== 0 || p.vt || p.ride || p.stun > 0) return null;
    if (p.hid >= 0) return want && want !== 'out' ? null : { k: 'out' };
    if (p.job) return want && want !== 'stop' ? null : { k: 'stop' };
    const M = W.M, ok = (k) => !want || want === k;
    if (ok('rescue')) for (const q of W.pl) if (q.st === 2 && q.cg >= 0) { const c = M.cages[q.cg]; if (hyp(c.x - p.x, c.y - p.y) < 1.75) return { k: 'rescue', j: q.i }; }
    if (ok('drop')) { const j = palNear(W, p); if (j >= 0) return { k: 'drop', j }; }
    if (ok('vault')) { const v = vaultAt(W, p); if (v) return { k: 'vault', v }; }
    if (ok('gate') && W.pw) { const j = nearIdx(M.gates.map((g) => ({ x: g.ix, y: g.iy })), p, 1.5, (j) => !W.gate[j].open); if (j >= 0) return { k: 'gate', j }; }
    if (ok('lan')) { const j = nearIdx(M.lans, p, 1.75, (j) => !W.lan[j].lit); if (j >= 0) return { k: 'lan', j }; }
    if (ok('heal')) for (const q of W.pl) if (q !== p && !q.sk && q.st === 0 && q.hid < 0 && q.hp === 1 && !q.vt && !q.ride && hyp(q.x - p.x, q.y - p.y) < 1.6) return { k: 'heal', j: q.i };
    if (ok('hide')) { const j = nearSpot(W, p, true); if (j >= 0) return { k: 'hide', j }; }
    if (ok('pad')) { const j = nearIdx(M.pads, p, 0.9); if (j >= 0) return { k: 'pad', j }; }
    if (ok('sw')) { const j = nearIdx(M.sw, p, 1.5); if (j >= 0) return { k: 'sw', j }; }
    return null;
  }
  function seekCtx(W, p, want) {
    if (!p.sk || p.st !== 0 || p.vt || p.ride || p.stun > 0 || p.job || !W.go || p.lr > 0 || p.ln > 0 || p.chg > 0) return null;
    const M = W.M, ok = (k) => !want || want === k;
    if (ok('break')) { const j = nearIdx(M.pals, p, 1.5, (j) => W.pal[j] === 1); if (j >= 0) return { k: 'break', j }; }
    if (!want) for (const q of W.pl) { // someone right in front: grab first
      if (q.sk || hiddenFrom(q)) continue;
      const d = hyp(q.x - p.x, q.y - p.y);
      if (d < 2.6 && Math.abs(wrapA(Math.atan2(q.y - p.y, q.x - p.x) - p.a)) < 0.7 && seeFull(W, p, q)) return { k: 'lunge' };
    }
    if (ok('vault')) { const v = vaultAt(W, p); if (v) return { k: 'vault', v }; }
    if (ok('hatch') && W.hop === 1 && W.hatch >= 0) { const h = M.hatches[W.hatch]; if (hyp(h.x - p.x, h.y - p.y) < 1.25) return { k: 'hatch' }; }
    if (ok('open')) { const j = nearSpot(W, p, false); if (j >= 0) return { k: 'open', j }; }
    if (ok('kick')) { const j = nearIdx(M.lans, p, 1.75, (j) => !W.lan[j].lit && W.lan[j].p > 0.03 && !W.lan[j].kick); if (j >= 0) return { k: 'kick', j }; }
    if (ok('pad')) { const j = nearIdx(M.pads, p, 0.9); if (j >= 0) return { k: 'pad', j }; }
    if (ok('sw')) { const j = nearIdx(M.sw, p, 1.5); if (j >= 0) return { k: 'sw', j }; }
    if (ok('lunge')) return { k: 'lunge' };
    return null;
  }
  const ctxOf = (W, p, want) => (p.sk ? seekCtx(W, p, want) : kidCtx(W, p, want));
  function hideIn(W, p, j) {
    const o = W.spots[j], s = W.M.spots[j];
    o.occ = p.i; o.since = W.t; o.camp = 0;
    p.hid = j; p.ent = [p.x, p.y]; p.x = s.x; p.y = s.y; p.vx = 0; p.vy = 0; p.ex = 0; p.job = null; p.chk = null;
    fx(W, 1, s.x, s.y, p.i, j);
  }
  function unhide(W, p, tx, ty, far) {
    const j = p.hid; if (j < 0) return;
    const M = W.M, s = M.spots[j];
    let bx = s.x, by = s.y + 1;
    if (tx == null && p.ent) { bx = p.ent[0]; by = p.ent[1]; }
    else {
      const ref = tx != null ? [tx, ty] : [s.x, s.y + 1];
      let bd = far ? -1 : 1e9;
      for (const n of s.adj) { const x = (n % M.W) + 0.5, y = ((n / M.W) | 0) + 0.5, d = hyp(x - ref[0], y - ref[1]); if (far ? d > bd : d < bd) { bd = d; bx = x; by = y; } }
    }
    W.spots[j].occ = -1; p.hid = -1; p.x = bx; p.y = by; p.ent = null; p.vx = 0; p.vy = 0;
    resolve(W, p);
    fx(W, 2, bx, by, p.i, j);
  }
  function dropPal(W, p, j) {
    const o = W.M.pals[j];
    setPal(W, j, 1);
    let stunned = 0;
    for (const q of W.pl) {
      if (q.st !== 0 || q.hid >= 0 || q.ride || q.vt) continue;
      const dx = q.x - o.x, dy = q.y - o.y, along = o.ax === 0 ? dx : dy, lat = o.ax === 0 ? dy : dx;
      if (q.sk && hyp(dx, dy) < 1.35) { q.stun = Math.max(q.stun, STUN_T); q.ln = 0; q.job = null; stunned = 1; }
      if (Math.abs(lat) < 0.8 && Math.abs(along) < 0.5 + PR) {
        const s = along >= 0 ? 1 : -1;
        if (o.ax === 0) q.x = o.x + s * (0.5 + PR + 0.02); else q.y = o.y + s * (0.5 + PR + 0.02);
        q.vx = 0; q.vy = 0; resolve(W, q);
      }
    }
    if (stunned) p.nStun++;
    makeNoise(W, o.x, o.y, 9, p.i);
    fx(W, 13, o.x, o.y, j, stunned);
  }
  function startVault(W, p, v) {
    p.vt = { x0: p.x, y0: p.y, x1: v.x1, y1: v.y1, t: 0, T: p.sk ? VAULT_S : p.c === K_QUICK ? VAULT_K * 0.55 : VAULT_K };
    p.job = null; p.chk = null; p.vx = 0; p.vy = 0;
    if (!p.sk && p.rn && p.c !== K_SOMI) makeNoise(W, p.x, p.y, 8, p.i);
    fx(W, 34, p.x, p.y, p.i, p.sk);
  }
  function lightLan(W, j) {
    const o = W.lan[j]; o.lit = 1; o.p = 1; o.kick = 0;
    let n = 0; for (const q of W.lan) if (q.lit) n++;
    for (const q of W.pl) if (q.job && q.job.k === 1 && q.job.j === j) { q.job = null; q.chk = null; }
    fx(W, 8, W.M.lans[j].x, W.M.lans[j].y, j, n);
    if (n >= NEED && !W.pw) powerGates(W, COLLAPSE_T, 9);
  }
  function powerGates(W, col, code) { W.pw = 1; W.col = col; fx(W, code, W.M.W / 2, W.M.H / 2, 0, 0); }
  function outKid(W, q, how) {
    if (q.cg >= 0) { W.cage[q.cg] = -1; q.cg = -1; }
    if (q.hid >= 0) { W.spots[q.hid].occ = -1; q.hid = -1; }
    q.st = 3; q.out = how || 1; q.job = null; q.chk = null; q.vx = 0; q.vy = 0; q.ride = null; q.vt = null;
    for (const k in W.claim.res) if (+k === q.i || W.claim.res[k] === q.i) delete W.claim.res[k];
    fx(W, 5, q.x, q.y, q.i, how || 1);
  }
  function catchKid(W, q, how) {
    const S = seekerOf(W);
    q.job = null; q.chk = null; q.ex = 0; q.vt = null;
    if (q.hid >= 0) unhide(W, q, S.x, S.y);
    if (q.key) { q.key = 0; const k = nearIdx(W.M.keys, q, 99, (j) => W.keys.indexOf(j) < 0); if (k >= 0) { W.keys.push(k); W.keys.sort((a, b) => a - b); } }
    if (q.hk >= 1) { outKid(W, q, 1); return; }
    let best = -1, bd = 1e9;
    for (let j = 0; j < W.M.cages.length; j++) { if (W.cage[j] >= 0) continue; const c = W.M.cages[j], d = hyp(c.x - q.x, c.y - q.y); if (d < bd) { bd = d; best = j; } }
    if (best < 0) { outKid(W, q, 1); return; }
    const c = W.M.cages[best], x0 = q.x, y0 = q.y;
    W.cage[best] = q.i; q.cg = best; q.st = 2; q.ct = CAGE_T; q.hk++; q.hp = 1; q.hl = 0; q.x = c.x; q.y = c.y; q.vx = 0; q.vy = 0; q.bst = 0; q.imm = 0;
    fx(W, 4, x0, y0, q.i, best);
  }
  function hitKid(W, q, how) {
    if (q.imm > 0 || q.st !== 0 || q.hid >= 0) return false;
    const S = seekerOf(W);
    S.nHit++;
    if (q.hp === 2) { q.hp = 1; q.hl = 0; q.bst = q.c === K_TOUGH ? BOOST_T * 1.5 : BOOST_T; q.imm = IMM_T; q.ex = 0; q.job = null; q.chk = null; fx(W, 3, q.x, q.y, q.i, how); }
    else catchKid(W, q, how);
    return true;
  }
  function freeKid(W, q, r) {
    const M = W.M, c = M.cages[q.cg];
    W.cage[q.cg] = -1; q.cg = -1; q.st = 0; q.hp = 1; q.imm = 1.5; q.ex = 0;
    let bx = c.x, by = c.y + 1, bd = 1e9;
    for (const n of c.adj) { const x = (n % M.W) + 0.5, y = ((n / M.W) | 0) + 0.5, d = hyp(x - r.x, y - r.y); if (d < bd) { bd = d; bx = x; by = y; } }
    q.x = bx; q.y = by; resolve(W, q);
    r.nRes++;
    delete W.claim.res[q.i];
    makeNoise(W, c.x, c.y, 12, r.i);
    fx(W, 7, c.x, c.y, q.i, r.i);
  }
  function openSpot(W, S, j) {
    const o = W.spots[j], s = W.M.spots[j];
    if (o.occ >= 0) {
      const q = W.pl[o.occ];
      if (q.c === K_MONG && !q.used) { q.used = 1; unhide(W, q, S.x, S.y, true); q.bst = BOOST_T; q.imm = 1.2; fx(W, 32, q.x, q.y, q.i, 0); return; }
      catchKid(W, q, 2);
    } else fx(W, 15, s.x, s.y, j, 0);
  }
  function escape(W, p, via) {
    if (p.hid >= 0) { W.spots[p.hid].occ = -1; p.hid = -1; }
    p.st = 4; p.esc = via; p.job = null; p.chk = null; p.vx = 0; p.vy = 0;
    fx(W, 6, p.x, p.y, p.i, via);
  }
  function doAct(W, p, inp) {
    const c = ctxOf(W, p, inp.wk || null);
    if (!c) return;
    const M = W.M;
    switch (c.k) {
      case 'out': unhide(W, p); break;
      case 'stop': p.job = null; p.chk = null; break;
      case 'rescue': p.job = { k: 4, j: c.j, p: 0 }; break;
      case 'drop': dropPal(W, p, c.j); break;
      case 'vault': startVault(W, p, c.v); break;
      case 'gate': p.job = { k: 2, j: c.j }; break;
      case 'lan': p.job = { k: 1, j: c.j }; p.nc = W.t + 1.5 + Math.random() * 3; break;
      case 'heal': p.job = { k: 3, j: c.j }; p.nc = W.t + 1.5 + Math.random() * 3; break;
      case 'hide': hideIn(W, p, c.j); break;
      case 'pad': p.ride = { j: c.j, t: 0, T: M.gm.padT || 1 }; p.job = null; p.vx = 0; p.vy = 0; fx(W, 35, p.x, p.y, p.i, 0); break;
      case 'sw': { const s = M.sw[c.j]; W.lit[s.room] = W.lit[s.room] > 0 ? 0 : 12; fx(W, 36, s.x, s.y, s.room, W.lit[s.room] > 0 ? 1 : 0); break; }
      case 'break': p.job = { k: 6, j: c.j, p: 0 }; break;
      case 'hatch': p.job = { k: 9, p: 0 }; break;
      case 'open': p.job = { k: 5, j: c.j, p: 0 }; p.a = Math.atan2(M.spots[c.j].y - p.y, M.spots[c.j].x - p.x); break;
      case 'kick': p.job = { k: 7, j: c.j, p: 0 }; break;
      case 'lunge': p.ln = p.cl > 0 ? 0.52 : LUNGE_T; p.lhit = 0; p.cl = 0; fx(W, 33, p.x, p.y, p.i, 0); break;
    }
  }
  function doSkill(W, p) {
    if (p.st !== 0 || p.cd > 0 || p.vt || p.ride || p.stun > 0 || p.hid >= 0) return;
    if (p.sk) {
      if (!W.go || p.job || p.ln > 0) return;
      if (p.c === S_TRAP) { W.traps.push({ x: r1(p.x), y: r1(p.y) }); if (W.traps.length > 3) W.traps.shift(); p.cd = SEEKERS[S_TRAP].cd; fx(W, 18, p.x, p.y, p.i, 0); }
      else if (p.c === S_MIRROR) {
        if (!W.mir || hyp(W.mir.x - p.x, W.mir.y - p.y) < 4) { W.mir = { x: r1(p.x), y: r1(p.y) }; p.cd = 2; fx(W, 20, p.x, p.y, p.i, 0); }
        else p.job = { k: 10, p: 0 };
      } else if (p.c === S_BAT) {
        let n = 0;
        for (const q of W.pl) { if (q.sk || hiddenFrom(q)) continue; if (hyp(q.x - p.x, q.y - p.y) < 16 && (hyp(q.vx, q.vy) > 1.5 || q.job)) { q.rv = 3; n++; } }
        p.cd = SEEKERS[S_BAT].cd; fx(W, 22, p.x, p.y, p.i, n);
      } else if (p.c === S_SHADE) { p.cl = CLOAK_T; p.cd = SEEKERS[S_SHADE].cd; fx(W, 45, p.x, p.y, p.i, 0); }
      else if (p.c === S_HORN) { p.chg = CHG_T; p.cl = 0; p.cd = SEEKERS[S_HORN].cd; p.vx = Math.cos(p.a) * V_CHG; p.vy = Math.sin(p.a) * V_CHG; fx(W, 46, p.x, p.y, p.i, 0); }
      else if (p.c === S_NOSE) {
        const near = [];
        for (const q of W.pl) { if (q.sk || hiddenFrom(q)) continue; const d = hyp(q.x - p.x, q.y - p.y); if (d < 20) near.push([d, q]); }
        near.sort((a, b) => a[0] - b[0]);
        for (const e of near.slice(0, 2)) e[1].rv = 3;
        p.cd = SEEKERS[S_NOSE].cd; fx(W, 47, p.x, p.y, p.i, Math.min(2, near.length));
      }
      return;
    }
    const K = KIDS[p.c]; if (!K || !K.act) return;
    if (p.c === K_DARAM) { p.bst = 2.5; p.cd = K.cd; fx(W, 28, p.x, p.y, p.i, 0); }
    else if (p.c === K_BAN) {
      const S = seekerOf(W), d = hyp(S.x - p.x, S.y - p.y);
      if (S.st === 0 && W.go && d < 4.2 && los(W, p.x, p.y, S.x, S.y)) { S.blind = BLIND_T; S.ln = 0; p.cd = K.cd; fx(W, 23, S.x, S.y, p.i, 1); }
      else { p.cd = 4; fx(W, 23, p.x, p.y, p.i, 0); }
    } else if (p.c === K_KONG) {
      const dx = Math.cos(p.ma), dy = Math.sin(p.ma), d = Math.max(0.6, castRay(W, p.x, p.y, dx, dy, 4.8, true) - 0.45);
      const x = p.x + dx * d, y = p.y + dy * d;
      W.toys.push({ x: r1(x), y: r1(y), n: 3, t: 0.5 }); if (W.toys.length > 3) W.toys.shift();
      p.cd = K.cd; fx(W, 38, x, y, p.i, 0);
    } else if (p.c === K_SMOKE) {
      W.smk.push({ x: r1(p.x), y: r1(p.y), t: SMOKE_T }); if (W.smk.length > 3) W.smk.shift();
      p.cd = K.cd; fx(W, 48, p.x, p.y, p.i, 0);
    } else if (p.c === K_BELL) {
      const mine = W.bel.filter((b) => b.o === p.i);
      if (mine.length >= 2) W.bel.splice(W.bel.indexOf(mine[0]), 1);
      W.bel.push({ x: r1(p.x), y: r1(p.y), o: p.i }); if (W.bel.length > 8) W.bel.shift();
      p.cd = K.cd; fx(W, 49, p.x, p.y, p.i, 0);
    }
  }
  function resolveChk(W, p, r) {
    const j = p.job; p.chk = null; p.nc = W.t + 3.5 + Math.random() * 4;
    if (!j || (j.k !== 1 && j.k !== 3)) return;
    fx(W, 17, p.x, p.y, p.i, r);
    if (r === 2) { if (j.k === 1) W.lan[j.j].p = Math.min(0.999, W.lan[j.j].p + 0.025); else { const q = W.pl[j.j]; q.hl = Math.min(0.999, q.hl + 0.03); } }
    else if (r === 0) {
      if (j.k === 1) { const o = W.lan[j.j], L0 = W.M.lans[j.j]; o.p = Math.max(0, o.p - (p.c === K_TTUK ? 0.03 : 0.07)); makeNoise(W, L0.x, L0.y, 3, p.i); }
      else { const q = W.pl[j.j]; q.hl = Math.max(0, q.hl - 0.1); makeNoise(W, p.x, p.y, 3, p.i); }
    }
  }
  // kid jobs need the stick to stay still; seeker jobs are short locked channels
  function stepJob(W, p, inp, h) {
    const j = p.job;
    if (!p.sk) {
      if (hyp(+inp.ax || 0, +inp.ay || 0) > 0.5) { p.job = null; p.chk = null; return false; }
      if (j.k === 1) {
        const o = W.lan[j.j];
        if (o.lit) { p.job = null; p.chk = null; return false; }
        const n = o.n || 1, r = (p.c === K_TTUK ? 1.3 : 1) * (n === 1 ? 1 : n === 2 ? 0.85 : 0.75) / LAN_T * h;
        o.p = Math.min(1, o.p + r); p.sLan[j.j] += r; o.kick = 0;
        if (o.p >= 1) lightLan(W, j.j);
      } else if (j.k === 2) {
        const g = W.gate[j.j];
        if (g.open || !W.pw) { p.job = null; return false; }
        g.p = Math.min(1, g.p + h / GATE_T * (p.c === K_QUICK ? 2 : 1));
        if (g.p >= 1) { setGate(W, j.j, 1); fx(W, 10, W.M.gates[j.j].x, W.M.gates[j.j].y, j.j, 0); for (const q of W.pl) if (q.job && q.job.k === 2 && q.job.j === j.j) q.job = null; }
      } else if (j.k === 3) {
        const q = W.pl[j.j];
        if (q.st !== 0 || q.hp !== 1 || q.hid >= 0 || hyp(q.x - p.x, q.y - p.y) > 1.6) { p.job = null; p.chk = null; return false; }
        q.hl += h / HEAL_T * (p.c === K_HAE ? 2 : 1);
        if (q.hl >= 1) { q.hp = 2; q.hl = 0; p.nHeal++; fx(W, 29, q.x, q.y, q.i, p.i); p.job = null; p.chk = null; }
      } else if (j.k === 4) {
        const q = W.pl[j.j];
        if (q.st !== 2) { p.job = null; return false; }
        j.p += h / RESCUE_T * (p.c === K_HAE ? 2 : 1);
        if (j.p >= 1) { freeKid(W, q, p); p.job = null; }
      }
      return true;
    }
    j.p += h;
    const T = j.k === 5 ? OPEN_T : j.k === 6 ? BREAK_T : j.k === 7 ? KICK_T : j.k === 9 ? CLOSE_T : 0.9;
    if (j.p < T) return true;
    p.job = null;
    const M = W.M;
    if (j.k === 5) openSpot(W, p, j.j);
    else if (j.k === 6) { if (W.pal[j.j] === 1) { setPal(W, j.j, 2); fx(W, 14, M.pals[j.j].x, M.pals[j.j].y, j.j, 0); } }
    else if (j.k === 7) { const o = W.lan[j.j]; if (!o.lit) { o.kick = 1; o.p = Math.max(0, o.p - 0.06); fx(W, 16, M.lans[j.j].x, M.lans[j.j].y, j.j, 0); } }
    else if (j.k === 9) { if (W.hop === 1) { W.hop = 2; fx(W, 12, M.hatches[W.hatch].x, M.hatches[W.hatch].y, 0, 0); if (!W.pw) powerGates(W, DAWN_COL, 30); } }
    else if (j.k === 10) { if (W.mir) { const x0 = p.x, y0 = p.y; p.x = W.mir.x; p.y = W.mir.y; W.mir = null; resolve(W, p); p.cd = SEEKERS[S_MIRROR].cd; fx(W, 21, x0, y0, p.i, 0); } }
    return true;
  }
  // movement for one body (shared by the host engine and the guest's own prediction)
  function movePl(W, p, inp, h) {
    const frozen = p.st !== 0 || p.hid >= 0 || p.ride || p.vt || p.stun > 0 || (p.sk && (!W.go || p.job));
    let ax = frozen ? 0 : +inp.ax || 0, ay = frozen ? 0 : +inp.ay || 0;
    if (!fin(ax)) ax = 0;
    if (!fin(ay)) ay = 0;
    let m = hyp(ax, ay); if (m > 1) { ax /= m; ay /= m; m = 1; }
    const sneak = !p.sk && (!!inp.sn || (m > 0.1 && m < 0.42));
    const run = !p.sk && !sneak && !!inp.rn;
    const M = W.M, ice = M.c[tileAt(M, p.x, p.y)] === '=';
    let vm;
    if (p.sk) vm = p.lr > 0 ? 1.4 : V_SEEK * (p.blind > 0 ? 0.55 : 1) * (p.cl > 0 ? 1.18 : 1);
    else vm = p.bst > 0 ? V_BOOST : run ? V_RUN : sneak ? V_SNEAK : V_WALK;
    if (ice) vm *= 1.08;
    let tvx = 0, tvy = 0;
    if (m > 0.1) { tvx = ax / m * vm; tvy = ay / m * vm; }
    if (p.sk && p.chg > 0 && !frozen) { // charge: runs straight ahead, steers only a little
      if (m > 0.3) { const want = Math.atan2(ay, ax); p.a = wrapA(p.a + clamp(wrapA(want - p.a), -2.2 * h, 2.2 * h)); }
      tvx = Math.cos(p.a) * V_CHG; tvy = Math.sin(p.a) * V_CHG; p.vx = tvx; p.vy = tvy;
      for (let j = 0; j < M.pals.length; j++) { // smash a standing shelf in the way
        if (W.pal[j] !== 1) continue; const o = M.pals[j];
        if (hyp(o.x - (p.x + Math.cos(p.a) * 0.45), o.y - (p.y + Math.sin(p.a) * 0.45)) < 0.62) { setPal(W, j, 2); fx(W, 14, o.x, o.y, j, 1); }
      }
    }
    if (p.sk && p.ln > 0 && !frozen) { tvx = Math.cos(p.a) * V_LUNGE; tvy = Math.sin(p.a) * V_LUNGE; p.vx = tvx; p.vy = tvy; }
    const dv = (ice ? ACC * 0.13 : ACC) * h;
    p.vx += clamp(tvx - p.vx, -dv, dv); p.vy += clamp(tvy - p.vy, -dv, dv);
    if (frozen) { p.vx = 0; p.vy = 0; }
    else {
      const x0 = p.x, y0 = p.y, want = hyp(p.vx, p.vy) * h;
      moveBody(W, p, p.vx * h, p.vy * h);
      const got = hyp(p.x - x0, p.y - y0);
      if (want > 1e-4 && got < want * 0.6) {
        if (p.sk && p.chg > 0 && got < want * 0.3) { // crashed into a wall
          p.chg = 0; p.stun = Math.max(p.stun, 1.1); p.vx = 0; p.vy = 0;
          makeNoise(W, p.x, p.y, 14, p.i); fx(W, 44, p.x, p.y, p.i, 0);
        } else if (m > 0.1 && !p.ln && !p.chg) {
          cornerSlide(W, p, tvx, tvy, Math.max(0.02, vm * h * 0.8));
          if (got < want * 0.2) { p.vx *= 0.5; p.vy *= 0.5; }   // pressing into a wall: no stored speed
        }
      }
    }
    const sp = hyp(p.vx, p.vy);
    p.rn = run && sp > 2.2 ? 1 : 0; p.sn = sneak && sp > 0.3 ? 1 : 0;
    if (sp > 0.35) p.ma = Math.atan2(p.vy, p.vx);
    if (!frozen) {
      let want = p.sk && fin(inp.aa) ? inp.aa : (sp > 0.35 ? p.ma : p.a);
      if (p.ln > 0 || p.chg > 0) want = p.a;
      const tr = inp.tr > 0 ? inp.tr : p.sk ? 7 : 14;
      p.a = wrapA(p.a + clamp(wrapA(want - p.a), -tr * h, tr * h));
    }
    return sp;
  }
  function afterMove(W, p, sp, h) {
    const M = W.M, ti = tileAt(M, p.x, p.y), ch = M.c[ti];
    if (ti !== p.lt) {
      if (W.go && p.lt >= 0 && ch === ':' && !p.sn && sp > 1 && p.c !== K_SOMI) makeNoise(W, p.x, p.y, 0, p.i);
      if (W.go && M.alarm[ti] && sp > 1.6 && !p.sn && p.c !== K_SOMI && W.t - p.alT > 3) { p.alT = W.t; p.rv = Math.max(p.rv, 1.3); makeNoise(W, p.x, p.y, 5, p.i); }
      p.lt = ti;
    }
    if (p.rn && W.go) { p.nT -= h; if (p.nT <= 0) { p.nT = 0.55; if (ch !== '_' && p.c !== K_SOMI) makeNoise(W, p.x, p.y, 1, p.i); } }
    else p.nT = Math.min(p.nT, 0.2);
    if (p.hp === 1 && sp > 0.5 && W.go) { p.wh -= h; if (p.wh <= 0) { p.wh = 6; makeNoise(W, p.x, p.y, 11, p.i); } }
    if (W.go && sp > 1.8 && !p.sn) for (let j = 0; j < M.crows.length; j++) {
      if (W.crow[j] > 0) continue;
      const c = M.crows[j]; if (hyp(c.x - p.x, c.y - p.y) < 1.8) { W.crow[j] = 30; makeNoise(W, c.x, c.y, 4, p.i); }
    }
    for (let k = 0; k < W.traps.length; k++) {
      const t = W.traps[k]; if (hyp(t.x - p.x, t.y - p.y) > 0.5) continue;
      W.traps.splice(k, 1); p.stun = TRAP_T; p.rv = 3.5; p.job = null; p.vx = 0; p.vy = 0;
      makeNoise(W, p.x, p.y, 10, p.i); fx(W, 19, p.x, p.y, p.i, 0); break;
    }
    if (!p.key) for (let k = 0; k < W.keys.length; k++) { const o = M.keys[W.keys[k]]; if (hyp(o.x - p.x, o.y - p.y) < 0.65) { p.key = 1; W.keys.splice(k, 1); if (W.claim.key === p.i) W.claim.key = -1; fx(W, 24, o.x, o.y, p.i, 0); break; } }
    if (p.key) for (let j = 0; j < M.doors.length; j++) {
      if (!W.door[j]) continue; const o = M.doors[j];
      if (hyp(o.x - p.x, o.y - p.y) < 1.08) {
        setDoor(W, j, 0); p.key = 0; fx(W, 25, o.x, o.y, p.i, j);
        // the room's other locked door opens too (a key room never has only one way out)
        const rs = new Set(), mine = M.room[ti]; for (const [dx, dy] of D4) { const r = M.room[tileAt(M, o.x + dx, o.y + dy)]; if (r >= 0 && r !== mine) rs.add(r); }
        for (let k = 0; k < M.doors.length; k++) { if (!W.door[k]) continue; const b = M.doors[k]; for (const [dx, dy] of D4) if (rs.has(M.room[tileAt(M, b.x + dx, b.y + dy)])) { setDoor(W, k, 0); fx(W, 25, b.x, b.y, p.i, k); break; } }
        break;
      }
    }
    const g = M.gateAt[ti];
    if (g >= 0 && W.gate[g].open) { escape(W, p, 1); return; }
    if (W.hop === 1 && W.hatch >= 0) { const o = M.hatches[W.hatch]; if (hyp(o.x - p.x, o.y - p.y) < 0.6) escape(W, p, 2); }
  }
  const NOIN = { ax: 0, ay: 0, rn: 0, sn: 0, aa: null, act: 0, sk: 0, tr: 0, ck: null, wk: null, ai: 0 };
  const CHKAI = [[0.65, 0.1], [0.82, 0.25], [0.95, 0.5]];
  function stepWorld(W, h, I, first) {
    const M = W.M, S = seekerOf(W);
    W.t += h;
    if (!W.go && W.t >= START_T) { W.go = 1; fx(W, 27, S.x, S.y, S.i, 0); }
    if (W.t >= W.chimeT) { W.chimeT += M.gm.chime; W.rvA = 2; fx(W, 26, M.W / 2, M.H / 2, 0, 0); }
    if (W.rvA > 0) W.rvA -= h;
    if (W.skRv > 0) W.skRv -= h;
    if (M.hedge.length) {
      syncHedge(W);
      const k = Math.floor((W.t - START_T + HEDGE_WARN) / M.gm.hedge);
      if (W.go && k > W.hwk) { W.hwk = k; fx(W, 42, M.W / 2, M.H / 2, 0, 0); }
    }
    for (let k = W.smk.length - 1; k >= 0; k--) { W.smk[k].t -= h; if (W.smk[k].t <= 0) W.smk.splice(k, 1); }
    for (const o of W.lan) o.n = 0;
    for (const p of W.pl) if (p.job && p.job.k === 1 && p.st === 0) W.lan[p.job.j].n++;
    for (const p of W.pl) {
      if (p.st === 3 || p.st === 4) continue;
      if (p.st === 2) {
        if (!W.go) continue;
        p.ct -= h * (hyp(S.x - p.x, S.y - p.y) < 4 ? 0.5 : 1);
        if (p.ct <= 0) outKid(W, p, 2);
        continue;
      }
      if (p.cd > 0) p.cd -= h;
      if (p.imm > 0) p.imm -= h;
      if (p.bst > 0) p.bst -= h;
      if (p.stun > 0) p.stun -= h;
      if (p.blind > 0) p.blind -= h;
      if (p.rv > 0) p.rv -= h;
      if (p.lr > 0) p.lr -= h;
      if (p.cl > 0) p.cl -= h;
      if (p.chg > 0) { p.chg -= h; if (p.chg <= 0) { p.chg = 0; p.lr = Math.max(p.lr, 0.5); } }
      if (p.ln > 0) { p.ln -= h; if (p.ln <= 0) { p.ln = 0; if (!p.lhit) p.lr = LUNGE_REC; } }
      const inp = I[p.i] || NOIN;
      if (first && Array.isArray(inp.ck) && p.chk && (inp.ck[0] | 0) === p.chk.id) resolveChk(W, p, clamp(inp.ck[1] | 0, 0, 2));
      if (first && inp.act) doAct(W, p, inp);
      if (first && inp.sk) doSkill(W, p);
      if (p.st !== 0) continue;
      if (p.vt) {
        const v = p.vt; v.t += h; const k = Math.min(1, v.t / v.T);
        p.x = v.x0 + (v.x1 - v.x0) * k; p.y = v.y0 + (v.y1 - v.y0) * k; p.vx = 0; p.vy = 0;
        if (k >= 1) { p.vt = null; resolve(W, p); }
        continue;
      }
      if (p.ride) {
        const r = p.ride; r.t += h;
        if (r.t >= r.T) { const o = M.pads[M.pads[r.j].to] || M.pads[r.j]; p.x = o.x; p.y = o.y; p.ride = null; resolve(W, p); fx(W, 35, o.x, o.y, p.i, 1); }
        continue;
      }
      if (p.job && stepJob(W, p, inp, h)) { p.vx = 0; p.vy = 0; p.rn = 0; p.sn = 0; continue; }
      const sp = movePl(W, p, inp, h);
      if (!p.sk && p.st === 0) afterMove(W, p, sp, h);
    }
    if (!W.go) return;
    // the seeker's beam and grab
    if (S.st === 0 && beamOn(S)) {
      for (const q of W.pl) {
        if (q.sk) continue;
        if (q.st !== 0 || q.hid >= 0 || q.ride || q.imm > 0) { q.ex = 0; continue; }
        if (inBeam(W, S, q)) q.ex += h; else q.ex = Math.max(0, q.ex - h * 0.7);
        if (q.ex >= beamT(q)) { q.ex = 0; hitKid(W, q, 0); }
      }
      if (S.ln > 0 && !S.lhit) for (const q of W.pl) {
        if (q.sk || q.st !== 0 || q.hid >= 0 || q.ride || q.imm > 0) continue;
        if (hyp(q.x - S.x, q.y - S.y) < 0.82) { hitKid(W, q, 1); S.lhit = 1; S.ln = 0; S.lr = HIT_REC; break; }
      }
    } else for (const q of W.pl) if (!q.sk) q.ex = Math.max(0, q.ex - h * 0.7);
    if (S.st === 0 && S.chg > 0) for (const q of W.pl) { // the charge hits like a lunge
      if (q.sk || q.st !== 0 || q.hid >= 0 || q.ride || q.imm > 0) continue;
      if (hyp(q.x - S.x, q.y - S.y) < 0.85) { hitKid(W, q, 1); S.chg = 0; S.lr = HIT_REC; S.vx = 0; S.vy = 0; break; }
    }
    if (S.st === 0 && W.bel.length && !S.ride && !S.vt) for (let k = 0; k < W.bel.length; k++) { // bell lines
      const b = W.bel[k]; if (hyp(b.x - S.x, b.y - S.y) > 0.62) continue;
      W.bel.splice(k, 1); S.stun = Math.max(S.stun, BELL_STUN); S.ln = 0; S.chg = 0; S.job = null; S.vx = 0; S.vy = 0; W.skRv = 3;
      makeNoise(W, b.x, b.y, 13, -3); fx(W, 43, b.x, b.y, b.o, 0);
      const o = W.pl[b.o]; if (o && !o.sk) o.nStun++;
      break;
    }
    // skill checks
    for (const p of W.pl) {
      if (p.sk || p.st !== 0) continue;
      if (!(p.job && (p.job.k === 1 || p.job.k === 3))) { p.chk = null; continue; }
      const inp = I[p.i] || NOIN;
      if (!p.chk) {
        if (W.t >= p.nc) {
          const z = 0.38 + Math.random() * 0.45;
          W.ckN = (W.ckN % 999) + 1;
          p.chk = { id: W.ckN, t0: W.t, z };
          if (inp.ai) {
            const D = CHKAI[clamp(inp.ai | 0, 1, 3) - 1], r = Math.random() < D[0] ? (Math.random() < D[1] ? 2 : 1) : 0;
            p.chk.ar = r; p.chk.at = W.t + CHK_WARN + CHK_DUR * (r ? z + CHK_W * 0.4 : Math.random() * 0.9);
          }
        }
      } else if (p.chk.ar != null) { if (W.t >= p.chk.at) resolveChk(W, p, p.chk.ar); }
      else if (W.t > p.chk.t0 + CHK_WARN + CHK_DUR + 0.75) resolveChk(W, p, 0);
    }
    // lanterns
    for (let j = 0; j < W.lan.length; j++) {
      const o = W.lan[j]; if (o.lit) continue;
      if (o.n > 0) { o.hum -= h; if (o.hum <= 0) { o.hum = 5; makeNoise(W, M.lans[j].x, M.lans[j].y, 6, -1); } }
      else if (o.kick) { o.p = Math.max(0, o.p - h * 0.004); if (o.p <= 0) o.kick = 0; }
    }
    // hiding too long creaks
    for (let j = 0; j < W.spots.length; j++) {
      const o = W.spots[j]; if (o.occ < 0) continue;
      if (W.pl[o.occ].c === K_MONG) continue;
      if (W.t - Math.max(o.since, START_T) >= 25) { o.camp -= h; if (o.camp <= 0) { o.camp = 6; makeNoise(W, M.spots[j].x, M.spots[j].y, 2, o.occ); } }
    }
    for (let k = W.toys.length - 1; k >= 0; k--) { const o = W.toys[k]; o.t -= h; if (o.t <= 0) { o.t = 1; o.n--; makeNoise(W, o.x, o.y, 7, -2); if (o.n <= 0) W.toys.splice(k, 1); } }
    for (let j = 0; j < W.crow.length; j++) if (W.crow[j] > 0) W.crow[j] = Math.max(0, W.crow[j] - h);
    for (let r = 0; r < W.lit.length; r++) if (W.lit[r] > 0) W.lit[r] = Math.max(0, W.lit[r] - h);
    while (W.noise.length && W.noise[0].t < W.t - 3) W.noise.shift();
    // round flow
    if (!W.pw && W.t >= CAP_T) powerGates(W, DAWN_COL, 30);
    if (W.pw && W.col > 0) { W.col -= h; if (W.col <= 0) { W.col = 0; for (const q of W.pl) if (!q.sk && (q.st === 0 || q.st === 2)) outKid(W, q, 3); } }
    // nobody free any more → the round ends now; survivors left in cages count as caught
    let free = 0, caged = 0;
    for (const q of W.pl) if (!q.sk) { if (q.st === 0) free++; else if (q.st === 2) caged++; }
    if (free === 0 && caged > 0) { for (const q of W.pl) if (!q.sk && q.st === 2) outKid(W, q, 1); fx(W, 40, M.W / 2, M.H / 2, caged, 0); }
    const alive = free + (free ? caged : 0);
    if (alive === 1 && W.hop === 0 && W.hatch >= 0) { W.hop = 1; const o = M.hatches[W.hatch]; fx(W, 11, o.x, o.y, 0, 0); }
    if (free === 0) W.res = { t: W.t };
  }
  function tickWorld(W, dt, inputs, hooks) {
    if (W.res) return;
    W.hk = hooks || null;
    const n = Math.max(1, Math.ceil(dt / SUB - 1e-6)), h = dt / n;
    for (let k = 0; k < n && !W.res; k++) stepWorld(W, h, inputs, k === 0);
    W.hk = null;
  }
  // [seat, points, outcome, a, b] — outcome: 0 escaped by the gate · 1 by the secret passage · 2 caught · 3 still inside at dawn · 9 seeker
  function roundRows(W) {
    let outs = 0; for (const q of W.pl) if (!q.sk && q.st === 3) outs++;
    const all = outs === W.pl.length - 1;
    return W.pl.map((p) => {
      if (p.sk) return [p.i, outs + (all ? 2 : 0), 9, outs, p.nHit];
      let lans = 0; for (const v of p.sLan) if (v >= 0.25) lans++;
      return [p.i, (p.st === 4 ? 3 : 0) + lans + p.nRes, p.st === 4 ? (p.esc === 2 ? 1 : 0) : p.out === 3 ? 3 : 2, lans, p.nRes];
    });
  }
  /* ---------- AI: path fields (BFS over tiles; windows and fallen shelves count as passable) ---------- */
  function passOf(W) {
    if (W.pv === W.dv && W.pass) return W.pass;
    const M = W.M, a = W.pass || new Uint8Array(M.N);
    for (let i = 0; i < M.N; i++) a[i] = !W.sol[i] || M.vAt[i] >= 0 || (M.palAt[i] >= 0 && W.pal[M.palAt[i]] === 1) ? 1 : 0;
    W.pass = a; W.pv = W.dv; W.fc.clear();
    return a;
  }
  function field(W, goal) {
    const pass = passOf(W), M = W.M;
    let f = W.fc.get(goal);
    if (f) return f;
    if (W.fc.size > 300) W.fc.clear();
    f = new Int16Array(M.N).fill(-1);
    W.fc.set(goal, f);
    if (!(goal >= 0 && goal < M.N)) return f;
    const q = new Int32Array(M.N); let qh = 0, qt = 0;
    f[goal] = 0; q[qt++] = goal;
    while (qh < qt) {
      const j = q[qh++], x = j % M.W, y = (j / M.W) | 0;
      for (let k = 0; k < 8; k++) {
        const dx = D8[k][0], dy = D8[k][1], nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= M.W || ny >= M.H) continue;
        const n = ny * M.W + nx;
        if (!pass[n] || f[n] >= 0) continue;
        if (dx && dy && (W.sol[n] || W.sol[j] || W.sol[y * M.W + nx] || W.sol[ny * M.W + x])) continue;
        f[n] = f[j] + (W.sol[n] ? 3 : 1); q[qt++] = n;
      }
    }
    return f;
  }
  function walkTile(W, x, y) {
    const M = W.M, t = tileAt(M, x, y);
    if (!W.sol[t]) return t;
    const tx = t % M.W, ty = (t / M.W) | 0;
    let best = -1, bd = 1e9;
    for (let r = 1; r <= 2 && best < 0; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (solidT(W, tx + dx, ty + dy)) continue;
      const d = hyp(tx + dx + 0.5 - x, ty + dy + 0.5 - y); if (d < bd) { bd = d; best = (ty + dy) * M.W + tx + dx; }
    }
    return best >= 0 ? best : M.walk[0];
  }
  function steer(W, p, goal) {
    const M = W.M, f = field(W, goal), cur = tileAt(M, p.x, p.y);
    const gx = (goal % M.W) + 0.5, gy = ((goal / M.W) | 0) + 0.5;
    if (f[cur] < 0) return { dx: gx - p.x, dy: gy - p.y, d: 99, nt: -1 };
    if (f[cur] <= 1 && !W.sol[goal]) return { dx: gx - p.x, dy: gy - p.y, d: hyp(gx - p.x, gy - p.y), nt: goal };
    const x = cur % M.W, y = (cur / M.W) | 0, pass = passOf(W);
    let bn = -1, bv = f[cur];
    for (let k = 0; k < 8; k++) {
      const dx = D8[k][0], dy = D8[k][1], nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= M.W || ny >= M.H) continue;
      const n = ny * M.W + nx;
      if (!pass[n] || f[n] < 0) continue;
      if (dx && dy && (W.sol[n] || W.sol[y * M.W + nx] || W.sol[ny * M.W + x])) continue;
      if (f[n] < bv) { bv = f[n]; bn = n; }
    }
    if (bn < 0) return { dx: gx - p.x, dy: gy - p.y, d: 99, nt: -1 };
    return { dx: (bn % M.W) + 0.5 - p.x, dy: ((bn / M.W) | 0) + 0.5 - p.y, d: f[cur], nt: bn };
  }
  function unstick(m, p, I, dt, t) {
    if (m.uT > 0) { m.uT -= dt; I.ax = m.ux; I.ay = m.uy; I.act = 0; return; }
    if (hyp(I.ax, I.ay) < 0.3) { m.sk0 = null; return; }
    if (!m.sk0 || t - m.sk0.t > 1.2) {
      if (m.sk0 && hyp(p.x - m.sk0.x, p.y - m.sk0.y) < 0.3) { const a = Math.random() * TAU; m.ux = Math.cos(a); m.uy = Math.sin(a); m.uT = 0.45; m.og = -1; m.fg = -1; m.pg = -1; }
      m.sk0 = { x: p.x, y: p.y, t };
    }
  }
  function standOf(W, fMe, adj) {
    let best = -1, bd = 1e9;
    for (const n of adj) { if (W.sol[n] || fMe[n] < 0) continue; if (fMe[n] < bd) { bd = fMe[n]; best = n; } }
    return best;
  }
  function loopTiles(W) { // tiles near a window or a standing shelf (good places to be chased)
    const M = W.M;
    if (M.loop) return M.loop;
    M.loop = new Uint8Array(M.N);
    const src = M.vaults.concat(M.pals);
    for (const i of M.walk) { const x = (i % M.W) + 0.5, y = ((i / M.W) | 0) + 0.5; for (const o of src) if (hyp(o.x - x, o.y - y) < 2.6) { M.loop[i] = 1; break; } }
    return M.loop;
  }
  const newI = (lv, tr) => ({ ax: 0, ay: 0, rn: 0, sn: 0, aa: null, act: 0, sk: 0, tr: tr || 0, ck: null, wk: null, ai: lv });

  /* ---------- AI: kids ---------- */
  const KD = [
    { react: 0.8, mem: 2, flee: 6, pal: 0.25, hide: 0.1, res: 0.4, heal: 0.2, aware: 0, noise: 7, runIdle: 0.55 },
    { react: 0.35, mem: 3, flee: 7.5, pal: 0.65, hide: 0.3, res: 0.85, heal: 0.6, aware: 3, noise: 3, runIdle: 0.1 },
    { react: 0.15, mem: 4, flee: 8.5, pal: 0.9, hide: 0.45, res: 1, heal: 0.9, aware: 5, noise: 1.5, runIdle: 0 },
  ];
  function fleeGoal(W, p, m, lv) {
    const M = W.M, D = KD[lv - 1], loop = loopTiles(W);
    const fS = field(W, walkTile(W, m.sx, m.sy)), me = walkTile(W, p.x, p.y), fMe = field(W, me);
    const hereS = fS[me] < 0 ? 25 : fS[me];
    let best = -1, bs = -1e9;
    for (let k = 0; k < 60; k++) {
      const t = M.walk[Math.floor(Math.random() * M.walk.length)];
      const dm = fMe[t]; if (dm < 3 || dm > 14) continue;
      const ds = fS[t] < 0 ? 25 : fS[t];
      let sc = ds - dm * 0.45 + Math.random() * D.noise;
      if (ds < dm || ds <= hereS) sc -= 8;                   // don't run toward the seeker
      if (lv >= 2 && loop[t]) sc += lv === 3 ? 4 : 2.5;
      if (lv === 3 && los(W, m.sx, m.sy, (t % M.W) + 0.5, ((t / M.W) | 0) + 0.5)) sc -= 4;
      if (sc > bs) { bs = sc; best = t; }
    }
    return best >= 0 ? best : me;
  }
  function dropClaims(W, p) {
    for (const k in W.claim.res) if (W.claim.res[k] === p.i) delete W.claim.res[k];
    for (const k in W.claim.heal) if (W.claim.heal[k] === p.i) delete W.claim.heal[k];
  }
  function pickObj(W, p, m, lv) {
    const M = W.M, D = KD[lv - 1], t = W.t;
    m.ok = null; m.oj = -1; m.og = -1;
    m.runI = Math.random() < D.runIdle ? 1 : 0;
    dropClaims(W, p);
    const me = walkTile(W, p.x, p.y), fMe = field(W, me);
    const known = m.st != null && t - m.st < D.mem + 3;
    // a caged friend
    let rq = null;
    for (const q of W.pl) {
      if (q.st !== 2 || q.cg < 0) continue;
      const c = M.cages[q.cg], cl = W.claim.res[q.i];
      if (cl != null && cl !== p.i && W.pl[cl] && W.pl[cl].st === 0) continue;
      if (lv >= 2 && known && hyp(m.sx - c.x, m.sy - c.y) < (lv === 3 ? 5 : 3)) continue;
      const s = standOf(W, fMe, c.adj); if (s < 0) continue;
      if (!rq || fMe[s] < rq.d) rq = { q, s, d: fMe[s] };
    }
    if (rq && Math.random() < D.res && (!W.pw || rq.d < 14)) { W.claim.res[rq.q.i] = p.i; m.ok = 'rescue'; m.og = rq.s; m.oj = rq.q.i; return; }
    // secret passage
    if (W.hop === 1 && W.hatch >= 0) { m.ok = 'hatch'; m.og = M.hatches[W.hatch].i; return; }
    // gates
    if (W.pw) {
      let best = -1, bd = 1e9;
      for (let j = 0; j < M.gates.length; j++) {
        const g = M.gates[j], tg = W.gate[j].open ? g.i : tileAt(M, g.ix, g.iy), f = field(W, tg)[me];
        if (f < 0) continue;
        const d = f - (W.gate[j].open ? 8 : W.gate[j].p * 10);
        if (d < bd) { bd = d; best = j; }
      }
      if (best >= 0) { const g = M.gates[best]; if (W.gate[best].open) { m.ok = 'exit'; m.og = g.i; } else { m.ok = 'gate'; m.og = tileAt(M, g.ix, g.iy); m.oj = best; } return; }
    }
    // keys and locked rooms
    if (W.door.some((l) => l)) {
      if (p.key) {
        let best = -1, bd = 1e9;
        for (let j = 0; j < M.doors.length; j++) { if (!W.door[j]) continue; const f = field(W, M.doors[j].i)[me]; if (f >= 0 && f < bd) { bd = f; best = j; } }
        if (best >= 0) { m.ok = 'door'; m.og = M.doors[best].i; return; }
      } else if (W.keys.length && lv >= 2) {
        const cl = W.claim.key, free = cl < 0 || cl === p.i || !W.pl[cl] || W.pl[cl].st !== 0 || W.pl[cl].key;
        if (free && (cl === p.i || Math.random() < 0.35)) {
          let best = -1, bd = 1e9;
          for (const k of W.keys) { const i = M.keys[k].i; if (fMe[i] >= 0 && fMe[i] < bd) { bd = fMe[i]; best = i; } }
          if (best >= 0) { W.claim.key = p.i; m.ok = 'key'; m.og = best; return; }
        }
      }
    }
    if (W.claim.key === p.i && !m.ok) W.claim.key = -1;
    // heal a scared friend
    if (p.hp === 2 && Math.random() < D.heal) {
      let best = null, bd = 9;
      for (const q of W.pl) {
        if (q === p || q.sk || q.st !== 0 || q.hp !== 1 || q.hid >= 0) continue;
        const cl = W.claim.heal[q.i]; if (cl != null && cl !== p.i && W.pl[cl].st === 0) continue;
        const d = fMe[walkTile(W, q.x, q.y)]; if (d >= 0 && d < bd) { bd = d; best = q; }
      }
      if (best) { W.claim.heal[best.i] = p.i; m.ok = 'heal'; m.og = walkTile(W, best.x, best.y); m.oj = best.i; return; }
    }
    // a lantern
    let best = -1, bs = -1e9, bt = -1;
    for (let j = 0; j < M.lans.length; j++) {
      const o = W.lan[j]; if (o.lit) continue;
      const s = standOf(W, fMe, M.lans[j].adj); if (s < 0) continue;
      const mine = p.job && p.job.k === 1 && p.job.j === j;
      let sc = -fMe[s] + Math.random() * D.noise + (mine ? 6 : 0);
      if (lv >= 2) { sc += o.p * 10; if (o.n - (mine ? 1 : 0) >= 2) sc -= 15; }
      if (lv === 3 && known) sc -= Math.max(0, 9 - hyp(m.sx - M.lans[j].x, m.sy - M.lans[j].y)) * 2;
      if (sc > bs) { bs = sc; best = j; bt = s; }
    }
    if (best >= 0) { m.ok = 'lan'; m.og = bt; m.oj = best; return; }
    m.og = M.walk[Math.floor(Math.random() * M.walk.length)];
  }
  function aiKid(W, p, m, lv, dt) {
    const I = newI(lv);
    if (p.st !== 0 || p.vt || p.ride || p.stun > 0) return I;
    const M = W.M, D = KD[lv - 1], S = seekerOf(W), t = W.t;
    const dS = hyp(S.x - p.x, S.y - p.y);
    if (W.go && S.st === 0) {
      const see = p.ex > 0.05 || dS < (S.cl > 0 ? 1.5 : D.aware) || canSee(W, p, S);
      if (see) { if (m.st == null || t - m.st > D.mem) m.rt = t + D.react; m.sx = S.x; m.sy = S.y; m.st = t; }
    }
    const known = m.st != null && t - m.st < D.mem;
    const near = known ? hyp(m.sx - p.x, m.sy - p.y) : 99;
    const threat = known && t >= (m.rt || 0) && near < D.flee;
    if (p.hid >= 0) {
      const stay = t - W.spots[p.hid].since;
      if (!m.hw) m.hw = t + 2 + Math.random() * 5;
      const calm = !threat && (lv === 1 || dS > 6);
      if ((calm && t > m.hw) || (stay > 23 && p.c !== K_MONG && dS > 3.5) || W.pw && dS > 5) { I.act = 1; I.wk = 'out'; m.hw = 0; m.og = -1; }
      return I;
    }
    m.hw = 0;
    let goal = -1, want = null;
    if (threat) {
      if (m.mode !== 'flee' || t > (m.fT || 0) || m.fg < 0) { m.mode = 'flee'; m.fT = t + 0.9; m.fg = fleeGoal(W, p, m, lv); }
      goal = m.fg; I.rn = 1;
      if (p.cd <= 0) {
        if (p.c === K_DARAM && near < 4) I.sk = 1;
        else if (p.c === K_BAN && dS < 4 && lv >= 2) I.sk = 1;
        else if (p.c === K_SMOKE && dS < 5.5 && (lv >= 2 || Math.random() < 0.3)) I.sk = 1;
        else if (p.c === K_BELL && near < 6 && (lv >= 2 || Math.random() < dt)) I.sk = 1;
      }
      if (lv >= 2 && dS > 3.5 && !seeFull(W, S, p) && Math.random() < D.hide * dt * 2 && nearSpot(W, p, true) >= 0) { I.act = 1; I.wk = 'hide'; return I; }
      const pj = palNear(W, p);
      if (pj >= 0 && dS < 3.3 && m.pd !== pj) {
        const o = M.pals[pj], between = (S.x - o.x) * (p.x - o.x) + (S.y - o.y) * (p.y - o.y) < 0;
        if (between) { m.pd = pj; if (Math.random() < D.pal) { I.act = 1; I.wk = 'drop'; return I; } }
      }
      if (pj < 0) m.pd = -1;
    } else {
      if (m.mode !== 'obj') { m.mode = 'obj'; m.oT = 0; }
      if (t >= (m.oT || 0) || m.og == null || m.og < 0) { pickObj(W, p, m, lv); m.oT = t + 1 + Math.random() * 0.8; }
      goal = m.og; want = m.ok;
      if (p.c === K_KONG && p.cd <= 0 && lv >= 2 && known && near < 10 && near > 4) I.sk = 1;
      if (p.c === K_BELL && p.cd <= 0 && lv >= 2 && M.c[tileAt(M, p.x, p.y)] === 'd' && Math.random() < 0.5) I.sk = 1;
      if (p.job) {
        const k = p.job.k;
        if ((k === 1 && want === 'lan') || (k === 3 && want === 'heal') || (k === 2 && want === 'gate') || (k === 4 && want === 'rescue')) return I;
      }
      if (p.hp === 1 && lv >= 2 && W.claim.heal[p.i] != null && want !== 'exit' && want !== 'hatch' && want !== 'gate') {
        const hq = W.pl[W.claim.heal[p.i]];
        if (hq && hq.st === 0 && hyp(hq.x - p.x, hq.y - p.y) < 2.4 && !p.job) return I;
      }
      const urgent = want === 'exit' || want === 'hatch' || want === 'rescue' || want === 'gate';
      if (lv >= 2 && known && near < 9) I.sn = 1;
      else I.rn = m.runI || (urgent && lv >= 2) ? 1 : 0;
    }
    if (goal >= 0) {
      const s = steer(W, p, goal), d = hyp(s.dx, s.dy);
      if (want && want !== 'exit' && want !== 'hatch' && want !== 'key' && want !== 'door' && s.d <= 2) {
        const c = kidCtx(W, p, want);
        if (c) { I.act = 1; I.wk = want; I.ax = 0; I.ay = 0; return I; }
      }
      if (s.nt >= 0 && W.sol[s.nt] && kidCtx(W, p, 'vault')) { I.act = 1; I.wk = 'vault'; return I; }
      if (!(s.d < 1 && d < 0.15) && d > 1e-3) { I.ax = s.dx / d; I.ay = s.dy / d; }
      if (I.sn) { I.ax *= 0.45; I.ay *= 0.45; }
    }
    unstick(m, p, I, dt, t);
    return I;
  }

  /* ---------- AI: the seeker ---------- */
  const SD = [
    { tr: 3.2, err: 0.3, hear: 0.45, react: 0.7, chase: 1.5, lunge: 0.35, lock: 0.3, kick: 0.25, abil: 0.3, camp: 0.5, sweep: 0 },
    { tr: 5.5, err: 0.12, hear: 0.85, react: 0.28, chase: 2.8, lunge: 0.75, lock: 0.65, kick: 0.65, abil: 0.75, camp: 0.12, sweep: 0.45 },
    { tr: 8, err: 0.04, hear: 1, react: 0.12, chase: 3, lunge: 0.95, lock: 0.75, kick: 0.95, abil: 1, camp: 0, sweep: 0.5 },
  ];
  function queueSpots(W, m, x, y, r, prob) {
    const M = W.M, near = [];
    for (let j = 0; j < M.spots.length; j++) { const d = hyp(M.spots[j].x - x, M.spots[j].y - y); if (d < r) near.push([d, j]); }
    near.sort((a, b) => a[0] - b[0]);
    for (const e of near) if (m.q.length < 3 && Math.random() < prob && m.q.indexOf(e[1]) < 0 && !(W.t - (m.vis['s' + e[1]] || -99) < 6)) m.q.push(e[1]);
    if (m.q.length) m.qT = W.t;
  }
  function aiSeeker(W, p, m, lv, dt) {
    const D = SD[lv - 1], M = W.M, t = W.t, I = newI(lv, D.tr);
    if (!W.go || p.st !== 0 || p.vt || p.ride || p.job || p.stun > 0) return I;
    if (!m.q) { m.q = []; m.vis = {}; m.err = 0; m.cg = 0; m.pg = -1; m.pj = -1; }
    m.err = clamp(m.err + (Math.random() - 0.5) * dt * 3, -D.err, D.err);
    let tg = null, td = 1e9;
    for (const q of W.pl) {
      if (q.sk || hiddenFrom(q) || !canSee(W, p, q)) continue;
      let d = hyp(q.x - p.x, q.y - p.y);
      if (lv === 3 && q.hp === 1) d -= 2;
      if (q.imm > 0) d += 3;
      if (d < td) { td = d; tg = q; }
    }
    if (tg) { if (m.tid !== tg.i || t - (m.tt || -9) > 1.5) m.rt = t + D.react; m.tid = tg.i; m.tx = tg.x; m.ty = tg.y; m.tt = t; m.tvx = tg.vx; m.tvy = tg.vy; m.lost = 0; }
    if (M.gm.snow || p.c === S_NOSE) for (const q of W.pl) { // footprints in the snow · the smell of running feet
      if (q.sk || q.st !== 0 || hiddenFrom(q) || hyp(q.vx, q.vy) < 0.8) continue;
      const d = hyp(q.x - p.x, q.y - p.y);
      const snow = M.gm.snow && q.c !== K_SOMI && M.c[tileAt(M, q.x, q.y)] === ',' && d < 8, nose = p.c === S_NOSE && q.rn && d < 13;
      if ((snow || nose) && Math.random() < D.hear * dt * 2) { m.nx = q.x; m.ny = q.y; m.nt = t; m.nk = 1; m.nd = 0; }
    }
    const hearR = p.c === S_BAT ? 99 : HEAR_S * (M.gm.echo ? 1.15 : 1);
    for (const nz of W.noise) {
      if (nz.t <= (m.hn || 0)) continue;
      m.hn = nz.t;
      if (nz.src === p.i) continue;
      const far = hyp(nz.x - p.x, nz.y - p.y);
      if (!LOUD[nz.k] && far > hearR) continue;
      if (Math.random() > D.hear) continue;
      if (m.nt != null && t - m.nt < 1.5 && !m.nd && hyp(m.nx - p.x, m.ny - p.y) < far && !LOUD[nz.k]) continue;
      m.nx = nz.x; m.ny = nz.y; m.nt = t; m.nk = nz.k; m.nd = 0;
    }
    let caged = 0; for (const q of W.pl) if (q.st === 2) caged++;
    if (caged > m.cg && Math.random() < D.camp) { m.camp = t + 10; m.cx = p.x; m.cy = p.y; m.cgG = -1; }
    m.cg = caged;
    let goal = -1, look = null, direct = null;
    const chasing = m.tt != null && t - m.tt < D.chase && t >= (m.rt || 0);
    m.md = chasing ? 'c' : m.q.length ? 'q' : m.nt != null && !m.nd && t - m.nt < 9 ? 'n' : m.lookT > t ? 'l' : m.camp > t ? 'k' : 'p';
    if (chasing) {
      const seeNow = t - m.tt < 0.05, lead = lv === 3 ? 0.35 : lv === 2 ? 0.15 : 0;
      const ex = m.tx + (m.tvx || 0) * lead, ey = m.ty + (m.tvy || 0) * lead;
      look = Math.atan2(ey - p.y, ex - p.x) + m.err;
      goal = walkTile(W, ex, ey);
      const d = hyp(m.tx - p.x, m.ty - p.y);
      if (seeNow && d < 4 && los(W, p.x, p.y, m.tx, m.ty) && castRay(W, p.x, p.y, (m.tx - p.x) / d, (m.ty - p.y) / d, d, true) >= d - 0.3) direct = [m.tx - p.x, m.ty - p.y];
      if (seeNow && d < (p.cl > 0 ? 3.3 : 2.3) && Math.abs(wrapA(look - p.a)) < 0.3 && p.lr <= 0 && t > (m.lgT || 0)) { m.lgT = t + 0.45; if (Math.random() < D.lunge) { I.act = 1; I.wk = 'lunge'; } }
      else if (p.c === S_HORN && p.cd <= 0 && seeNow && d > 2.4 && d < 7 && Math.abs(wrapA(look - p.a)) < 0.2 && t > (m.cgT || 0)) {
        m.cgT = t + 0.6;
        if (castRay(W, p.x, p.y, (m.tx - p.x) / d, (m.ty - p.y) / d, d, true) >= d - 0.3 && Math.random() < D.abil) I.sk = 1;
      }
      if (!seeNow && t - m.tt > 0.6 && !m.lost) { m.lost = 1; queueSpots(W, m, m.tx, m.ty, 2.6, D.lock); }
    } else if (m.q.length) {
      const j = m.q[0], s = M.spots[j];
      if (t - (m.qT || t) > 8 || W.t - (m.vis['s' + j] || -99) < 3) { m.q.shift(); m.qT = t; }
      else if (hyp(s.x - p.x, s.y - p.y) < REACH - 0.1) { look = Math.atan2(s.y - p.y, s.x - p.x); I.act = 1; I.wk = 'open'; m.q.shift(); m.qT = t; m.vis['s' + j] = t; }
      else { const st = standOf(W, field(W, walkTile(W, p.x, p.y)), s.adj); if (st < 0) m.q.shift(); else goal = st; }
    } else if (m.nt != null && !m.nd && t - m.nt < 9) {
      goal = walkTile(W, m.nx, m.ny);
      if (hyp(m.nx - p.x, m.ny - p.y) < 1.6) { m.nd = 1; m.lookT = t + 1.2; queueSpots(W, m, m.nx, m.ny, m.nk === 2 ? 1.2 : 2.6, m.nk === 2 ? 1 : D.lock * 0.7); }
    } else if (m.lookT > t) {
      look = p.a + 2.6 * dt * (m.ld || 1); if (Math.random() < dt) m.ld = -(m.ld || 1);
    } else if (m.camp > t) {
      if (m.cgG == null || m.cgG < 0 || hyp((m.cgG % M.W) + 0.5 - p.x, ((m.cgG / M.W) | 0) + 0.5 - p.y) < 0.8) {
        let k = 0, g = -1; do { g = M.walk[Math.floor(Math.random() * M.walk.length)]; k++; } while (k < 30 && hyp((g % M.W) + 0.5 - m.cx, ((g / M.W) | 0) + 0.5 - m.cy) > 4);
        m.cgG = g;
      }
      goal = m.cgG;
    } else {
      const reached = m.pg >= 0 && hyp((m.pg % M.W) + 0.5 - p.x, ((m.pg / M.W) | 0) + 0.5 - p.y) < 0.9;
      if (reached) {
        if (m.pj >= 0) {
          m.vis[m.pj] = t; m.atLan = t; m.lookT = t + 0.9;
          if (Math.random() < D.kick && seekCtx(W, p, 'kick')) { I.act = 1; I.wk = 'kick'; }
        }
        m.pj = -1; m.pg = -1;
      }
      if (m.pg == null || m.pg < 0 || t > (m.pT || 0)) {
        m.pT = t + 14;
        const fMe = field(W, walkTile(W, p.x, p.y));
        let best = -1, bs = -1e9, bt = -1;
        if (lv > 1 || Math.random() < 0.4) for (let j = 0; j < M.lans.length; j++) {
          const o = W.lan[j]; if (o.lit) continue;
          const s = standOf(W, fMe, M.lans[j].adj); if (s < 0) continue;
          if (t - (m.vis[j] || -99) < 25 || fMe[s] < 2) continue;
          const sc = o.p * (lv === 3 ? 14 : 8) - fMe[s] * 0.12 + Math.random() * (lv === 3 ? 2 : 6);
          if (sc > bs) { bs = sc; best = j; bt = s; }
        }
        if (best >= 0) { m.pj = best; m.pg = bt; }
        else { m.pj = -1; let g = M.walk[0]; for (let k = 0; k < 8; k++) { g = M.walk[Math.floor(Math.random() * M.walk.length)]; if (fMe[g] > 5) break; } m.pg = g; }
      }
      goal = m.pg;
    }
    if (direct) { const d = hyp(direct[0], direct[1]); if (d > 1e-3) { I.ax = direct[0] / d; I.ay = direct[1] / d; } }
    else if (goal >= 0) {
      const s = steer(W, p, goal), d = hyp(s.dx, s.dy);
      if (s.nt >= 0 && W.sol[s.nt] && !I.act) {
        const pj = M.palAt[s.nt];
        if (pj >= 0 && W.pal[pj] === 1) { if (seekCtx(W, p, 'break')) { I.act = 1; I.wk = 'break'; } }
        else if (M.vAt[s.nt] >= 0 && seekCtx(W, p, 'vault')) { I.act = 1; I.wk = 'vault'; }
      }
      if (!(s.d < 1 && d < 0.2) && d > 1e-3) { I.ax = s.dx / d; I.ay = s.dy / d; }
    }
    if (look != null) I.aa = look;
    else if (D.sweep && hyp(I.ax, I.ay) > 0.5) I.aa = Math.atan2(I.ay, I.ax) + Math.sin(t * 2.4) * D.sweep;
    if (p.cd <= 0 && !I.act && Math.random() < D.abil * dt * 2) {
      const fresh = m.atLan != null && t - m.atLan < 1.5;
      if (p.c === S_TRAP) { if (fresh || (lv === 1 && Math.random() < 0.05)) I.sk = 1; }
      else if (p.c === S_MIRROR) {
        if (!W.mir) { if (fresh) I.sk = 1; }
        else if (m.nt != null && t - m.nt < 2 && !chasing && hyp(m.nx - W.mir.x, m.ny - W.mir.y) < 8 && hyp(m.nx - p.x, m.ny - p.y) > 13) I.sk = 1;
      } else if (p.c === S_BAT) { if (!chasing && t - (m.tt || -99) > (lv === 3 ? 5 : 9)) I.sk = 1; }
      else if (p.c === S_SHADE) { if (!chasing && ((m.md === 'n' && hyp(m.nx - p.x, m.ny - p.y) < 12) || (m.md === 'p' && m.pj >= 0 && W.lan[m.pj].p > 0.05 && hyp(M.lans[m.pj].x - p.x, M.lans[m.pj].y - p.y) < 11) || (lv === 1 && Math.random() < 0.05))) I.sk = 1; }
      else if (p.c === S_NOSE) { if (!chasing && t - (m.tt || -99) > (lv === 3 ? 4 : 8)) I.sk = 1; }
    }
    unstick(m, p, I, dt, t);
    return I;
  }
  function aiThink(W, p, m, lv, dt) { return p.sk ? aiSeeker(W, p, m, lv, dt) : aiKid(W, p, m, lv, dt); }

  /* ---------- coarse state (travels with api.setState) ---------- */
  function pickMap(mp, prev) {
    if (mp >= 0 && mp < MAPS.length) return mp;
    let k = Math.floor(Math.random() * MAPS.length);
    if (k === prev && MAPS.length > 1) k = (k + 1 + Math.floor(Math.random() * (MAPS.length - 1))) % MAPS.length;
    return k;
  }
  function botPicks(st) {
    const ch = st.ch.slice(), used = {};
    ch.forEach((c, i) => { if (c >= 0 && i !== st.sk) used[c] = 1; });
    for (let i = 0; i < st.np; i++) {
      if (!((st.ai >> i) & 1) || ch[i] >= 0) continue;
      if (i === st.sk) { ch[i] = U.rand(SEEKERS.length); continue; }
      const free = []; for (let c = 0; c < KIDS.length; c++) if (!used[c]) free.push(c);
      const c = free.length ? free[U.rand(free.length)] : U.rand(KIDS.length);
      ch[i] = c; used[c] = 1;
    }
    return ch;
  }
  function fillPicks(st) { // whoever has not picked when the time is up gets a random one
    const ch = st.ch.slice(), used = {};
    ch.forEach((c, i) => { if (c >= 0 && i !== st.sk) used[c] = 1; });
    for (let i = 0; i < st.np; i++) {
      if (ch[i] >= 0) continue;
      if (i === st.sk) { ch[i] = U.rand(SEEKERS.length); continue; }
      const free = []; for (let c = 0; c < KIDS.length; c++) if (!used[c]) free.push(c);
      ch[i] = free.length ? free[U.rand(free.length)] : U.rand(KIDS.length); used[ch[i]] = 1;
    }
    return ch;
  }
  function pickSeeker(st) {
    const n = st.np, cand = [], kidOnly = st.who === 'kid';
    if (st.who === 'p1' && st.rd === 1) return 0;
    for (let i = 0; i < n; i++) if (!((st.sd >> i) & 1) && !(kidOnly && i === 0)) cand.push(i);
    if (!cand.length) for (let i = 0; i < n; i++) if (!(kidOnly && i === 0) && i !== st.sk) cand.push(i);
    return cand.length ? cand[U.rand(cand.length)] : 0;
  }
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 2, NP);
    const mp = typeof o.map === 'number' && o.map >= -1 && o.map < MAPS.length ? o.map : -1;
    const rounds = [1, 2, 3].includes(+o.rounds) ? +o.rounds : 2;
    const who = ['rand', 'p1', 'kid'].includes(o.who) ? o.who : 'rand';
    let ai = 0; players.slice(0, np).forEach((p, i) => { if (p && p.ai) ai |= 1 << i; });
    const st = {
      rid: 1 + U.rand(99999), nm: players.slice(0, np).map((p) => String((p && p.name) || '').slice(0, 8)), np, rounds, mp, who, ai,
      rd: 1, sd: 0, sk: 0, mk: pickMap(mp, -1), ph: 'pick', ch: Array(np).fill(-1), sc: Array(np).fill(0), es: Array(np).fill(0), ou: Array(np).fill(0), rs: null, res: null,
    };
    st.sk = pickSeeker(st); st.sd = 1 << st.sk; st.ch = botPicks(st);
    return st;
  }
  function startPlay(st) { return Object.assign({}, st, { ph: 'play', ch: fillPicks(st) }); }
  function roundOver(st, rows) {
    const n = Object.assign({}, st, { sc: st.sc.slice(), es: st.es.slice(), ou: st.ou.slice(), ph: 'end' });
    const rs = [];
    if (Array.isArray(rows)) for (const r of rows) {
      if (!Array.isArray(r)) continue;
      const s = r[0] | 0; if (s < 0 || s >= st.np) continue;
      const pts = clamp(r[1] | 0, 0, 30), oc = r[2] | 0;
      n.sc[s] += pts;
      if (oc === 0 || oc === 1) n.es[s]++;
      if (oc === 9) n.ou[s] += r[3] | 0;
      rs.push([s, pts, oc, r[3] | 0, r[4] | 0]);
    }
    n.rs = rs;
    return n;
  }
  function nextRound(st) {
    if (st.rd >= st.rounds) {
      const order = st.sc.map((v, i) => [i, v, st.es[i], st.ou[i]]).sort((a, b) => b[1] - a[1] || (b[2] + b[3]) - (a[2] + a[3]) || a[0] - b[0]);
      return Object.assign({}, st, { ph: 'done', res: order });
    }
    const n = Object.assign({}, st, { rd: st.rd + 1, mk: pickMap(st.mp, st.mk), ph: 'pick', ch: Array(st.np).fill(-1), rs: null });
    n.sk = pickSeeker(n); n.sd = st.sd | (1 << n.sk); n.ch = botPicks(n);
    return n;
  }
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res) || !st.res.length) return null;
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번';
    const top = st.res[0][1], winners = st.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = st.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '점 · 탈출 ' + r[2] + ' · 살인마로 잡음 ' + r[3]);
    const head = (st.mp >= 0 ? MAPS[st.mp].nm : '맵 무작위') + ' · ' + st.rounds + '판';
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: head + '\n' + lines.join('\n') };
  }

  /* ---------- host snapshot (positions + world objects) ---------- */
  const jobT = (k) => (k === 5 ? OPEN_T : k === 6 ? BREAK_T : k === 7 ? KICK_T : k === 9 ? CLOSE_T : k === 10 ? 0.9 : k === 4 ? RESCUE_T : 1);
  const PF = 12; // numbers per player
  function snapshot(W, key, q) {
    const P = [];
    for (const p of W.pl) {
      const fl = (p.rn ? 1 : 0) | (p.sn ? 2 : 0) | (p.hp === 1 ? 4 : 0) | (p.bst > 0 ? 8 : 0) | (p.key ? 16 : 0) | (p.stun > 0 ? 32 : 0) | (p.blind > 0 ? 64 : 0) |
        (p.rv > 0 ? 128 : 0) | (p.ln > 0 ? 256 : 0) | (p.imm > 0 ? 512 : 0) | (p.vt ? 1024 : 0) | (p.ride ? 2048 : 0) | (p.used ? 4096 : 0) | (p.lr > 0 ? 8192 : 0) | (p.cl > 0 ? 16384 : 0) | (p.chg > 0 ? 32768 : 0);
      let jb = 0, jj = -1;
      if (p.job) {
        const j = p.job, k = j.k;
        const pr = k === 1 ? W.lan[j.j].p : k === 2 ? W.gate[j.j].p : k === 3 ? W.pl[j.j].hl : clamp(j.p / jobT(k), 0, 1);
        jb = k * 100 + Math.round(clamp(pr, 0, 1) * 99); jj = j.j != null ? j.j : -1;
      }
      P.push(Math.round(p.x * 10), Math.round(p.y * 10), Math.round(wrapA(p.a) * 10), p.st, fl, p.hid, Math.round(p.ex * 10), jb, jj,
        Math.ceil(Math.max(0, p.cd)), p.chk ? p.chk.id * 100 + Math.round(p.chk.z * 99) : 0, p.st === 2 ? Math.ceil(p.ct) : p.hk);
    }
    const G = W.lan.map((o) => (o.lit ? -1 : Math.floor(o.p * 98) + (o.kick ? 1000 : 0) + (o.n > 0 ? 2000 : 0)));
    const E = [W.pw, Math.ceil(Math.max(0, W.col)), W.hop, W.hatch].concat(W.gate.map((g) => Math.round(g.p * 99) + (g.open ? 100 : 0)));
    const o = { k: key, q, t: Math.round(W.t * 10) / 10, P, G, E, pa: W.pal.join(''), fx: W.fx.slice(-12) };
    if (W.door.length) { o.dr = W.door.join(''); o.ky = W.keys.slice(); }
    if (W.traps.length) o.tr = W.traps.flatMap((t) => [Math.round(t.x * 10), Math.round(t.y * 10)]);
    if (W.mir) o.mr = [Math.round(W.mir.x * 10), Math.round(W.mir.y * 10)];
    if (W.toys.length) o.ty = W.toys.flatMap((t) => [Math.round(t.x * 10), Math.round(t.y * 10)]);
    if (W.crow.length) o.cw = W.crow.map((c) => (c > 0 ? 1 : 0)).join('');
    const lt = []; for (let r = 0; r < W.lit.length; r++) if (W.lit[r] > 0) lt.push(r, Math.ceil(W.lit[r]));
    if (lt.length) o.lt = lt;
    if (W.rvA > 0) o.rv = Math.ceil(W.rvA * 10);
    if (W.skRv > 0) o.sr = Math.ceil(W.skRv * 10);
    if (W.smk.length) o.sm = W.smk.flatMap((t) => [Math.round(t.x * 10), Math.round(t.y * 10), Math.ceil(t.t * 10)]);
    if (W.bel.length) o.bl = W.bel.flatMap((t) => [Math.round(t.x * 10), Math.round(t.y * 10), t.o]);
    return o;
  }
  // guest: copy the host's snapshot into the local world (own body is predicted; others glide to nx/ny)
  function applySnap(W, hs, me) {
    const M = W.M, A = hs.P;
    if (fin(hs.t)) { W.t = hs.t; if (W.t >= START_T) W.go = 1; syncHedge(W); }
    for (const o of W.spots) o.occ = -1;
    W.pl.forEach((p, i) => {
      const o = i * PF;
      if (!fin(+A[o]) || !fin(+A[o + 1])) return;
      const fl = A[o + 4] | 0, wasHid = p.hid, wasSt = p.st;
      p.st = clamp(A[o + 3] | 0, 0, 4);
      p.rn = fl & 1 ? 1 : 0; p.sn = fl & 2 ? 1 : 0; p.hp = fl & 4 ? 1 : 2; p.bst = fl & 8 ? 1 : 0; p.key = fl & 16 ? 1 : 0;
      p.stun = fl & 32 ? 1 : 0; p.blind = fl & 64 ? 1 : 0; p.rv = fl & 128 ? 1 : 0; p.ln = fl & 256 ? 1 : 0; p.imm = fl & 512 ? 1 : 0;
      p.vt = fl & 1024 ? (p.vt || { g: 1 }) : null; p.ride = fl & 2048 ? (p.ride || { g: 1 }) : null; p.used = fl & 4096 ? 1 : 0; p.lr = fl & 8192 ? 1 : 0; p.cl = fl & 16384 ? 1 : 0; p.chg = fl & 32768 ? 1 : 0;
      p.hid = clamp(A[o + 5] | 0, -1, M.spots.length - 1);
      if (p.hid >= 0) W.spots[p.hid].occ = i;
      p.ex = (A[o + 6] | 0) / 10;
      const jb = A[o + 7] | 0;
      p.job = jb > 0 ? { k: Math.floor(jb / 100), j: A[o + 8] | 0, pp: (jb % 100) / 99, p: 0 } : null;
      p.cd = A[o + 9] | 0;
      const ck = A[o + 10] | 0;
      if (ck > 0) { const id = Math.floor(ck / 100); if (!p.chk || p.chk.id !== id) p.chk = { id, z: (ck % 100) / 99, seen: 0 }; } else p.chk = null;
      if (p.st === 2) { p.ct = A[o + 11] | 0; p.cg = W.cage.indexOf(i); } else p.hk = A[o + 11] | 0;
      p.nx = (A[o] | 0) / 10; p.ny = (A[o + 1] | 0) / 10;
      if (i !== me) p.na = (A[o + 2] | 0) / 10;
      if (hyp(p.nx - p.x, p.ny - p.y) > 2.5 || p.hid >= 0 || wasHid !== p.hid || wasSt !== p.st || p.vt || p.ride) { p.x = p.nx; p.y = p.ny; }
    });
    const G = Array.isArray(hs.G) ? hs.G : [];
    W.lan.forEach((o, j) => { const v = G[j] | 0; if (G[j] === -1 || v < 0) { o.lit = 1; o.p = 1; o.kick = 0; o.n = 0; } else { o.lit = 0; o.n = v >= 2000 ? 1 : 0; const r = v % 2000; o.kick = r >= 1000 ? 1 : 0; o.p = (r % 1000) / 98; } });
    const E = Array.isArray(hs.E) ? hs.E : [];
    W.pw = E[0] ? 1 : 0; W.col = E[1] | 0; W.hop = E[2] | 0; if (E[3] != null) W.hatch = E[3] | 0;
    W.gate.forEach((g, j) => { const v = E[4 + j] | 0; g.p = (v % 100) / 99; const op = v >= 100 ? 1 : 0; if (op !== g.open) setGate(W, j, op); });
    if (typeof hs.pa === 'string') for (let j = 0; j < W.pal.length; j++) { const s = +hs.pa[j] || 0; if (s !== W.pal[j]) setPal(W, j, s); }
    if (typeof hs.dr === 'string') for (let j = 0; j < W.door.length; j++) { const l = +hs.dr[j] || 0; if (l !== W.door[j]) setDoor(W, j, l); }
    if (Array.isArray(hs.ky)) W.keys = hs.ky.map((v) => v | 0).filter((v) => v >= 0 && v < M.keys.length);
    const pts = (a) => { const out = []; if (Array.isArray(a)) for (let k = 0; k + 1 < a.length; k += 2) out.push({ x: (a[k] | 0) / 10, y: (a[k + 1] | 0) / 10 }); return out; };
    W.traps = pts(hs.tr); W.toys = pts(hs.ty);
    W.mir = Array.isArray(hs.mr) ? { x: (hs.mr[0] | 0) / 10, y: (hs.mr[1] | 0) / 10 } : null;
    if (typeof hs.cw === 'string') for (let j = 0; j < W.crow.length; j++) W.crow[j] = hs.cw[j] === '1' ? 1 : 0;
    W.lit.fill(0);
    if (Array.isArray(hs.lt)) for (let k = 0; k + 1 < hs.lt.length; k += 2) { const r = hs.lt[k] | 0; if (r >= 0 && r < W.lit.length) W.lit[r] = +hs.lt[k + 1] || 0.1; }
    W.rvA = (hs.rv | 0) / 10; W.skRv = (hs.sr | 0) / 10;
    W.smk = []; if (Array.isArray(hs.sm)) for (let k = 0; k + 2 < hs.sm.length; k += 3) W.smk.push({ x: (hs.sm[k] | 0) / 10, y: (hs.sm[k + 1] | 0) / 10, t: (hs.sm[k + 2] | 0) / 10 });
    W.bel = []; if (Array.isArray(hs.bl)) for (let k = 0; k + 2 < hs.bl.length; k += 3) W.bel.push({ x: (hs.bl[k] | 0) / 10, y: (hs.bl[k + 1] | 0) / 10, o: hs.bl[k + 2] | 0 });
    W.cage.fill(-1); W.pl.forEach((p, i) => { if (p.st === 2) { const j = nearIdx(M.cages, p, 0.6); if (j >= 0) { W.cage[j] = i; p.cg = j; } } });
  }
  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const STICK_R = 46, TOPH = 70;
  const NOISE_NM = ['삐걱', '타닥', '덜컹', '펑!', '까악!', '삐요삐요', '딸깍', '따르릉', '탁', '쿵!', '찰칵', '훌쩍', '철컥', '딸랑!', '쾅!'];
  const CTX_NM = { out: '나오기', stop: '멈추기', rescue: '구출', drop: '넘어뜨리기', vault: '넘기', gate: '대문 열기', lan: '고치기', heal: '치료',
    hide: '숨기', pad: '타기', sw: '불', break: '치우기', hatch: '닫기', open: '열어 보기', kick: '망가뜨리기', lunge: '덥석' };
  const SK_COL = ['#3f6b4a', '#7a4a9a', '#8a2a3a', '#2a2440', '#8a4a22', '#6a5a32'];
  const CSS = `
.fl-btn{position:absolute;border-radius:50%;border:2px solid rgba(242,233,216,.35);background:rgba(34,24,54,.86);color:#f2e9d8;
  font:700 15px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;
  touch-action:none;user-select:none;-webkit-user-select:none;z-index:3;padding:0;box-shadow:0 4px 14px rgba(0,0,0,.5);
  -webkit-tap-highlight-color:transparent;cursor:pointer;line-height:1.1}
.fl-btn small{font-size:10px;font-weight:600;opacity:.85;line-height:1;max-width:78px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fl-btn.on{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}
.fl-btn.dim{opacity:.45}
.fl-btn.lit{background:#f2d27a;color:#2a1d05;border-color:#fff3cf}
.fl-btn.hot{background:#ee6a55;color:#fff;border-color:#ffd9d2}
.fl-btn.pulse{animation:flp 1s ease-in-out infinite}
@keyframes flp{50%{box-shadow:0 0 0 7px rgba(227,174,69,.45),0 4px 14px rgba(0,0,0,.5)}}
.fl-act{width:92px;height:92px;right:10px;bottom:14px;font-size:17px;--p:0}
.fl-act::before{content:'';position:absolute;inset:-7px;border-radius:50%;pointer-events:none;
  background:conic-gradient(#ffe28a calc(var(--p) * 1turn),rgba(255,255,255,.08) 0);
  -webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 6px),#000 calc(100% - 5px));mask:radial-gradient(farthest-side,transparent calc(100% - 6px),#000 calc(100% - 5px))}
.fl-act small{font-size:11px;max-width:84px}
.fl-run{width:64px;height:64px;right:112px;bottom:10px}
.fl-sn{width:54px;height:54px;right:117px;bottom:90px;font-size:13px}
.fl-sk{width:62px;height:62px;right:25px;bottom:118px;font-size:14px}
.fl-btn .cd{position:absolute;inset:0;border-radius:50%;pointer-events:none;background:conic-gradient(rgba(12,8,22,.55) calc(var(--c,0) * 1turn),transparent 0)}
.fl-pick{position:absolute;inset:0;z-index:5;overflow:auto;background:#120d1c;display:flex;flex-direction:column;align-items:center;
  padding:10px 12px 16px;box-sizing:border-box;color:#f2e9d8;font-family:var(--f-body,system-ui)}
.fl-pick .in{width:100%;max-width:420px;display:flex;flex-direction:column;gap:8px}
.fl-pk-head{display:flex;justify-content:space-between;align-items:center;gap:8px}
.fl-pk-head b{font:20px var(--f-display,sans-serif);color:#e3ae45;letter-spacing:.5px}
.fl-pk-head span{font:700 15px var(--f-mono,monospace);color:#bfe3ff;min-width:44px;text-align:right}
.fl-pk-role{font-size:14px;line-height:1.35;background:rgba(255,255,255,.06);border-radius:12px;padding:8px 10px}
.fl-pk-role b{color:#ffe9a8}
.fl-pk-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.fl-card{display:flex;align-items:center;gap:8px;min-height:56px;padding:6px 8px;border-radius:12px;border:2px solid rgba(242,233,216,.18);
  background:rgba(46,38,64,.92);color:#f2e9d8;text-align:left;font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent}
.fl-card canvas{width:40px;height:40px;flex:none}
.fl-card .t{display:flex;flex-direction:column;gap:1px;min-width:0}
.fl-card .t b{font-size:15px}
.fl-card .t small{font-size:11px;color:#c9bfd8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fl-card.sel{border-color:#e3ae45;background:rgba(227,174,69,.2)}
.fl-card.taken{opacity:.78}
.fl-pk-desc{font-size:13px;line-height:1.45;min-height:38px;color:#f2e9d8;background:rgba(255,255,255,.05);border-radius:10px;padding:8px 10px}
.fl-pk-team{display:flex;flex-wrap:wrap;gap:4px 10px;font-size:12px;color:#c9bfd8}
.fl-pk-team i{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:4px;vertical-align:-1px}
.fl-pk-go{min-height:48px;border-radius:14px;border:0;background:#e3ae45;color:#2a1d05;font:700 16px var(--f-body,system-ui);cursor:pointer}
.fl-pk-go:disabled{opacity:.5}
`;
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(255,255,255,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  // a character portrait / body (top-down, cartoony). sk: seeker, c: character, col: seat colour, r: radius in px
  function drawChar(ctx, x, y, r, sk, c, col, a, opt) {
    const o = opt || {};
    ctx.save();
    if (o.alpha != null) ctx.globalAlpha *= o.alpha;
    const fx = Math.cos(a), fy = Math.sin(a), nx = -fy, ny = fx;
    if (!o.noShadow) { ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + r * 0.15, y + r * 0.35, r * 0.95, r * 0.6, 0, 0, TAU); ctx.fill(); }
    if (sk) {
      if (c === S_BAT) { // wings
        ctx.fillStyle = '#3a1420';
        for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(x + nx * r * 0.5 * s, y + ny * r * 0.5 * s); ctx.lineTo(x + nx * r * 1.6 * s - fx * r * 0.3, y + ny * r * 1.6 * s - fy * r * 0.3); ctx.lineTo(x + nx * r * 1.1 * s - fx * r * 0.9, y + ny * r * 1.1 * s - fy * r * 0.9); ctx.lineTo(x + nx * r * 0.9 * s - fx * r * 0.5, y + ny * r * 0.9 * s - fy * r * 0.5); ctx.closePath(); ctx.fill(); }
      }
      // flashlight in hand
      const hx = x + fx * r * 0.95, hy = y + fy * r * 0.95;
      ctx.save(); ctx.translate(hx, hy); ctx.rotate(a);
      ctx.fillStyle = '#3a3a46'; ctx.fillRect(-r * 0.25, -r * 0.16, r * 0.55, r * 0.32);
      ctx.fillStyle = o.beam ? '#fff3b0' : '#777'; ctx.fillRect(r * 0.28, -r * 0.2, r * 0.12, r * 0.4);
      ctx.restore();
      ctx.fillStyle = SK_COL[c] || '#555'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      ctx.lineWidth = Math.max(1.5, r * 0.1); ctx.strokeStyle = col; ctx.stroke();
      if (c === S_TRAP) { // wide hat
        ctx.fillStyle = '#1e2a20'; ctx.beginPath(); ctx.ellipse(x - fx * r * 0.2, y - fy * r * 0.2, r * 0.95, r * 0.8, a, 0, TAU); ctx.fill();
        ctx.fillStyle = '#2f4433'; ctx.beginPath(); ctx.arc(x - fx * r * 0.25, y - fy * r * 0.25, r * 0.5, 0, TAU); ctx.fill();
      } else if (c === S_MIRROR) { // veil
        ctx.fillStyle = 'rgba(220,190,255,.45)'; ctx.beginPath(); ctx.arc(x - fx * r * 0.25, y - fy * r * 0.25, r * 0.85, a + 0.9, a - 0.9 + TAU); ctx.fill();
        ctx.fillStyle = '#d9e6ff'; ctx.beginPath(); ctx.arc(x + nx * r * 0.9, y + ny * r * 0.9, r * 0.28, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.8)'; ctx.beginPath(); ctx.arc(x + nx * r * 0.85, y + ny * r * 0.85, r * 0.1, 0, TAU); ctx.fill();
      } else if (c === S_BAT) { // high collar
        ctx.fillStyle = '#1a0a10'; ctx.beginPath(); ctx.moveTo(x - fx * r * 0.2 + nx * r * 0.85, y - fy * r * 0.2 + ny * r * 0.85); ctx.lineTo(x - fx * r * 0.95, y - fy * r * 0.95); ctx.lineTo(x - fx * r * 0.2 - nx * r * 0.85, y - fy * r * 0.2 - ny * r * 0.85); ctx.closePath(); ctx.fill();
      } else if (c === S_SHADE) { // tattered hood with wisps
        ctx.fillStyle = 'rgba(10,8,20,.85)'; ctx.beginPath(); ctx.arc(x - fx * r * 0.15, y - fy * r * 0.15, r * 0.9, a + 1.0, a - 1.0 + TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(150,130,220,.5)'; ctx.lineWidth = Math.max(1, r * 0.1);
        for (const s of [-1, 0, 1]) { ctx.beginPath(); ctx.moveTo(x - fx * r * 0.8 + nx * r * 0.4 * s, y - fy * r * 0.8 + ny * r * 0.4 * s); ctx.quadraticCurveTo(x - fx * r * 1.3 + nx * r * 0.7 * s, y - fy * r * 1.3 + ny * r * 0.7 * s, x - fx * r * 1.6 + nx * r * 0.3 * s, y - fy * r * 1.6 + ny * r * 0.3 * s); ctx.stroke(); }
      } else if (c === S_HORN) { // two big horns
        ctx.fillStyle = '#e8d6b0';
        for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(x + nx * r * 0.45 * s + fx * r * 0.1, y + ny * r * 0.45 * s + fy * r * 0.1); ctx.quadraticCurveTo(x + nx * r * 1.25 * s, y + ny * r * 1.25 * s, x + nx * r * 1.05 * s + fx * r * 0.85, y + ny * r * 1.05 * s + fy * r * 0.85); ctx.lineTo(x + nx * r * 0.75 * s - fx * r * 0.1, y + ny * r * 0.75 * s - fy * r * 0.1); ctx.closePath(); ctx.fill(); }
      } else if (c === S_NOSE) { // floppy ears and a big nose
        ctx.fillStyle = '#3a2a16';
        for (const s of [-1, 1]) { ctx.beginPath(); ctx.ellipse(x + nx * r * 0.85 * s - fx * r * 0.2, y + ny * r * 0.85 * s - fy * r * 0.2, r * 0.42, r * 0.22, a, 0, TAU); ctx.fill(); }
        ctx.fillStyle = '#1a1010'; ctx.beginPath(); ctx.arc(x + fx * r * 0.88, y + fy * r * 0.88, r * 0.2, 0, TAU); ctx.fill();
      }
      const ex = x + fx * r * 0.45, ey = y + fy * r * 0.45;
      ctx.fillStyle = '#ffe36a'; ctx.beginPath(); ctx.arc(ex + nx * r * 0.28, ey + ny * r * 0.28, r * 0.17, 0, TAU); ctx.arc(ex - nx * r * 0.28, ey - ny * r * 0.28, r * 0.17, 0, TAU); ctx.fill();
      ctx.fillStyle = '#1b1226'; ctx.beginPath(); ctx.arc(ex + nx * r * 0.28 + fx * r * 0.06, ey + ny * r * 0.28 + fy * r * 0.06, r * 0.07, 0, TAU); ctx.arc(ex - nx * r * 0.28 + fx * r * 0.06, ey - ny * r * 0.28 + fy * r * 0.06, r * 0.07, 0, TAU); ctx.fill();
      ctx.restore();
      return;
    }
    // kid
    ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.lineWidth = Math.max(1.5, r * 0.12); ctx.strokeStyle = 'rgba(20,10,30,.8)'; ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.beginPath(); ctx.arc(x - r * 0.3, y - r * 0.35, r * 0.3, 0, TAU); ctx.fill();
    const bx = x - fx * r * 0.45, by = y - fy * r * 0.45;
    switch (c) {
      case K_DARAM: // squirrel ears + tail
        ctx.fillStyle = '#a5622e';
        ctx.beginPath(); ctx.ellipse(x - fx * r * 1.15, y - fy * r * 1.15, r * 0.55, r * 0.32, a, 0, TAU); ctx.fill();
        for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(bx + nx * r * 0.55 * s, by + ny * r * 0.55 * s); ctx.lineTo(bx + nx * r * 0.8 * s - fx * r * 0.35, by + ny * r * 0.8 * s - fy * r * 0.35); ctx.lineTo(bx + nx * r * 0.25 * s - fx * r * 0.2, by + ny * r * 0.25 * s - fy * r * 0.2); ctx.closePath(); ctx.fill(); }
        break;
      case K_SOMI: // fluffy cotton hat
        ctx.fillStyle = '#f6f2ff';
        for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.arc(bx + nx * r * (k - 1.5) * 0.3, by + ny * r * (k - 1.5) * 0.3, r * 0.3, 0, TAU); ctx.fill(); }
        break;
      case K_TTUK: // hard hat
        ctx.fillStyle = '#f2c230'; ctx.beginPath(); ctx.arc(bx, by, r * 0.62, a + Math.PI / 2, a - Math.PI / 2 + TAU); ctx.fill();
        ctx.fillStyle = '#c99a12'; ctx.fillRect(bx - r * 0.08, by - r * 0.08, r * 0.16, r * 0.16);
        break;
      case K_HAE: // sun crown
        ctx.strokeStyle = '#ffd54a'; ctx.lineWidth = Math.max(1.2, r * 0.13);
        for (let k = 0; k < 7; k++) { const t = a + Math.PI * (0.55 + k * 0.15); ctx.beginPath(); ctx.moveTo(x + Math.cos(t) * r * 0.75, y + Math.sin(t) * r * 0.75); ctx.lineTo(x + Math.cos(t) * r * 1.15, y + Math.sin(t) * r * 1.15); ctx.stroke(); }
        break;
      case K_MONG: // hood
        ctx.strokeStyle = '#5a4a7a'; ctx.lineWidth = r * 0.34; ctx.beginPath(); ctx.arc(x, y, r * 0.86, a + 1.1, a - 1.1 + TAU); ctx.stroke();
        break;
      case K_BYUL: { // star clip
        ctx.fillStyle = '#ffe36a'; ctx.beginPath();
        for (let k = 0; k < 10; k++) { const t = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? r * 0.17 : r * 0.38; ctx.lineTo(bx + nx * r * 0.3 + Math.cos(t) * rr, by + ny * r * 0.3 + Math.sin(t) * rr); }
        ctx.closePath(); ctx.fill();
        break;
      }
      case K_BAN: // hand mirror
        ctx.fillStyle = '#7a6040'; ctx.fillRect(x + nx * r * 0.95 - r * 0.06, y + ny * r * 0.95 - r * 0.06, r * 0.12, r * 0.12);
        ctx.fillStyle = '#dff2ff'; ctx.beginPath(); ctx.arc(x + nx * r * 1.1 + fx * r * 0.2, y + ny * r * 1.1 + fy * r * 0.2, r * 0.3, 0, TAU); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x + nx * r * 1.02 + fx * r * 0.12, y + ny * r * 1.02 + fy * r * 0.12, r * 0.09, 0, TAU); ctx.fill();
        break;
      case K_SMOKE: // smoke puffs on the head
        ctx.fillStyle = 'rgba(200,200,215,.9)';
        for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(bx + nx * r * (k - 1) * 0.35 - fx * r * 0.1 * (k % 2), by + ny * r * (k - 1) * 0.35 - fy * r * 0.1 * (k % 2), r * 0.28, 0, TAU); ctx.fill(); }
        break;
      case K_QUICK: // gloves
        ctx.fillStyle = '#ffffff';
        for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(x + nx * r * 0.95 * s + fx * r * 0.35, y + ny * r * 0.95 * s + fy * r * 0.35, r * 0.26, 0, TAU); ctx.fill(); }
        ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = Math.max(1, r * 0.08);
        for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(x + nx * r * 0.95 * s + fx * r * 0.35, y + ny * r * 0.95 * s + fy * r * 0.35, r * 0.26, 0, TAU); ctx.stroke(); }
        break;
      case K_TOUGH: // a sturdy helmet with a stripe
        ctx.fillStyle = '#7d8a96'; ctx.beginPath(); ctx.arc(bx, by, r * 0.66, a + Math.PI / 2, a - Math.PI / 2 + TAU); ctx.fill();
        ctx.strokeStyle = '#ffd54a'; ctx.lineWidth = Math.max(1.2, r * 0.14); ctx.beginPath(); ctx.moveTo(bx + nx * r * 0.62, by + ny * r * 0.62); ctx.lineTo(bx - nx * r * 0.62, by - ny * r * 0.62); ctx.stroke();
        break;
      case K_BELL: // a little bell on a ribbon
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(bx, by, r * 0.3, 0, TAU); ctx.fill();
        ctx.fillStyle = '#7a4a10'; ctx.beginPath(); ctx.arc(bx - fx * r * 0.12, by - fy * r * 0.12, r * 0.08, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#c94f6a'; ctx.lineWidth = Math.max(1, r * 0.1); ctx.beginPath(); ctx.moveTo(bx + nx * r * 0.45, by + ny * r * 0.45); ctx.lineTo(bx - nx * r * 0.45, by - ny * r * 0.45); ctx.stroke();
        break;
      case K_KONG: // propeller cap
        ctx.fillStyle = '#5bb3e6'; ctx.beginPath(); ctx.arc(bx, by, r * 0.45, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = Math.max(1.5, r * 0.14); const pa = (o.t || 0) * 12;
        ctx.beginPath(); ctx.moveTo(bx + Math.cos(pa) * r * 0.6, by + Math.sin(pa) * r * 0.6); ctx.lineTo(bx - Math.cos(pa) * r * 0.6, by - Math.sin(pa) * r * 0.6); ctx.stroke();
        break;
    }
    const ex = x + fx * r * 0.42, ey = y + fy * r * 0.42;
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ex + nx * r * 0.3, ey + ny * r * 0.3, r * 0.2, 0, TAU); ctx.arc(ex - nx * r * 0.3, ey - ny * r * 0.3, r * 0.2, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1b1226'; ctx.beginPath(); ctx.arc(ex + nx * r * 0.3 + fx * r * 0.07, ey + ny * r * 0.3 + fy * r * 0.07, r * 0.1, 0, TAU); ctx.arc(ex - nx * r * 0.3 + fx * r * 0.07, ey - ny * r * 0.3 + fy * r * 0.07, r * 0.1, 0, TAU); ctx.fill();
    if (o.scared) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = Math.max(1, r * 0.08); ctx.beginPath(); ctx.moveTo(x + r * 0.7, y - r * 1.25); ctx.lineTo(x + r * 0.95, y - r * 0.8); ctx.moveTo(x + r * 1.0, y - r * 1.35); ctx.lineTo(x + r * 1.15, y - r * 0.95); ctx.stroke(); }
    ctx.restore();
  }

  /* ----- static picture of the map (fully lit; darkness is drawn over it) ----- */
  function buildMapCanvas(M, s, dpr) {
    const th = THEMES[M.th] || THEMES[0];
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.ceil(M.W * s * dpr)); c.height = Math.max(1, Math.ceil(M.H * s * dpr));
    const g = c.getContext('2d');
    g.setTransform(s * dpr, 0, 0, s * dpr, 0, 0);
    let seed = 11 + M.k * 97;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const ch = (x, y) => (x < 0 || y < 0 || x >= M.W || y >= M.H ? '#' : M.c[y * M.W + x]);
    const isWall = (x, y) => WALLS.indexOf(ch(x, y)) >= 0 || ch(x, y) === 'D';
    const rgb = (a, t, k) => 'rgb(' + ((a[0] + t * k) | 0) + ',' + ((a[1] + t * k * 0.8) | 0) + ',' + ((a[2] + t * k * 0.6) | 0) + ')';
    for (let y = 0; y < M.H; y++) for (let x = 0; x < M.W; x++) {
      const c0 = ch(x, y);
      if (isWall(x, y)) continue;
      if (c0 === ',') { // snow: soft white with blue shadows and sparkles
        g.fillStyle = 'rgb(' + (196 + rnd() * 14 | 0) + ',' + (206 + rnd() * 12 | 0) + ',' + (226 + rnd() * 10 | 0) + ')'; g.fillRect(x, y, 1, 1);
        g.fillStyle = 'rgba(120,150,200,.22)'; g.beginPath(); g.ellipse(x + 0.3 + rnd() * 0.4, y + 0.3 + rnd() * 0.4, 0.3, 0.12, rnd() * 3, 0, TAU); g.fill();
        if (rnd() < 0.5) { g.fillStyle = '#ffffff'; g.fillRect(x + rnd() * 0.9, y + rnd() * 0.9, 0.05, 0.05); }
        continue;
      }
      if (c0 === '=') { // ice: pale blue with cracks and a sheen
        g.fillStyle = 'rgb(' + (150 + rnd() * 12 | 0) + ',' + (190 + rnd() * 10 | 0) + ',' + (220 + rnd() * 10 | 0) + ')'; g.fillRect(x, y, 1, 1);
        g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 0.025; g.beginPath(); const a = rnd() * 3; g.moveTo(x + 0.5, y + 0.5); g.lineTo(x + 0.5 + Math.cos(a) * 0.45, y + 0.5 + Math.sin(a) * 0.45); g.moveTo(x + 0.5, y + 0.5); g.lineTo(x + 0.5 - Math.cos(a + 0.7) * 0.4, y + 0.5 - Math.sin(a + 0.7) * 0.4); g.stroke();
        g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(x + 0.1, y + 0.12, 0.5, 0.06);
        continue;
      }
      if (th.garden && c0 === '_') { // paving stones
        g.fillStyle = '#4a4a52'; g.fillRect(x, y, 1, 1);
        g.fillStyle = 'rgb(' + (120 + rnd() * 20 | 0) + ',' + (118 + rnd() * 18 | 0) + ',' + (126 + rnd() * 16 | 0) + ')'; g.fillRect(x + 0.05, y + 0.05, 0.42, 0.42); g.fillRect(x + 0.53, y + 0.05, 0.42, 0.42); g.fillRect(x + 0.05, y + 0.53, 0.42, 0.42); g.fillRect(x + 0.53, y + 0.53, 0.42, 0.42);
        continue;
      }
      if (c0 === '~') { g.fillStyle = '#16324a'; g.fillRect(x, y, 1, 1); g.strokeStyle = 'rgba(160,210,255,.25)'; g.lineWidth = 0.04; g.beginPath(); g.moveTo(x + 0.15, y + 0.4 + rnd() * 0.2); g.quadraticCurveTo(x + 0.5, y + 0.3, x + 0.85, y + 0.5); g.stroke(); continue; }
      if (c0 === '_') {
        g.fillStyle = th.cp; g.fillRect(x, y, 1, 1);
        g.fillStyle = th.cp2;
        if (th.grass) { for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(x + rnd(), y + rnd(), 0.08, 0, TAU); g.fill(); } }
        else for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) { const cx = x + 0.25 + a * 0.5, cy = y + 0.25 + b * 0.5; g.beginPath(); g.moveTo(cx, cy - 0.15); g.lineTo(cx + 0.15, cy); g.lineTo(cx, cy + 0.15); g.lineTo(cx - 0.15, cy); g.closePath(); g.fill(); }
        continue;
      }
      const creak = c0 === ':';
      if (th.plank) {
        for (let r = 0; r < 4; r++) {
          const t = rnd();
          g.fillStyle = rgb(creak ? th.f2 : th.f, t, 18);
          g.fillRect(x, y + r * 0.25, 1, 0.25);
          g.fillStyle = 'rgba(20,10,4,.35)'; g.fillRect(x, y + r * 0.25 + 0.232, 1, 0.018);
          g.fillRect(x + (((x * 3 + r * 5 + y * 7) % 4) * 0.25 + 0.12), y + r * 0.25, 0.018, 0.25);
        }
      } else if (th.cave) { // rock floor with pebbles; creaky = loose gravel
        g.fillStyle = rgb(creak ? th.f2 : th.f, rnd(), 12); g.fillRect(x, y, 1, 1);
        g.fillStyle = 'rgba(0,0,0,.22)'; for (let k = 0; k < 2; k++) { g.beginPath(); g.ellipse(x + rnd(), y + rnd(), 0.18 + rnd() * 0.12, 0.1, rnd() * 3, 0, TAU); g.fill(); }
        g.fillStyle = creak ? 'rgba(170,160,150,.8)' : 'rgba(140,130,150,.45)'; for (let k = 0; k < (creak ? 7 : 2); k++) { g.beginPath(); g.arc(x + 0.1 + rnd() * 0.8, y + 0.1 + rnd() * 0.8, 0.035 + rnd() * 0.03, 0, TAU); g.fill(); }
      } else if (th.garden && creak) { // gravel path
        g.fillStyle = '#8a7e6a'; g.fillRect(x, y, 1, 1);
        for (let k = 0; k < 9; k++) { g.fillStyle = rnd() < 0.5 ? '#a89a82' : '#6e6452'; g.beginPath(); g.arc(x + 0.08 + rnd() * 0.84, y + 0.08 + rnd() * 0.84, 0.04, 0, TAU); g.fill(); }
      } else if (th.grass) {
        g.fillStyle = rgb(creak ? th.f2 : th.f, rnd(), 14); g.fillRect(x, y, 1, 1);
        g.strokeStyle = creak ? 'rgba(170,120,60,.8)' : 'rgba(110,150,80,.55)'; g.lineWidth = 0.035;
        for (let k = 0; k < 3; k++) { const px = x + 0.15 + rnd() * 0.7, py = y + 0.25 + rnd() * 0.6; g.beginPath(); g.moveTo(px, py); g.lineTo(px + 0.05, py - 0.14); g.stroke(); }
        if (creak) { g.fillStyle = 'rgba(190,110,40,.8)'; for (let k = 0; k < 3; k++) { g.beginPath(); g.ellipse(x + 0.2 + rnd() * 0.6, y + 0.2 + rnd() * 0.6, 0.1, 0.05, rnd() * 3, 0, TAU); g.fill(); } }
      } else {
        const t = rnd(), alt = (x + y) % 2;
        g.fillStyle = rgb(alt ? th.f : th.f2, t, 8); g.fillRect(x, y, 1, 1);
        g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 0.03; g.strokeRect(x + 0.015, y + 0.015, 0.97, 0.97);
      }
      if (creak && !th.grass && !th.cave) {
        g.strokeStyle = 'rgba(40,20,8,.85)'; g.lineWidth = 0.035; g.lineCap = 'round';
        g.beginPath(); g.moveTo(x + 0.18, y + 0.42); g.lineTo(x + 0.36, y + 0.52); g.lineTo(x + 0.5, y + 0.44); g.lineTo(x + 0.66, y + 0.56); g.lineTo(x + 0.82, y + 0.48); g.stroke();
      }
      if (c0 === 'z') { // alarm floor
        g.fillStyle = 'rgba(238,106,85,.35)'; g.fillRect(x + 0.08, y + 0.08, 0.84, 0.84);
        g.strokeStyle = 'rgba(255,160,140,.8)'; g.lineWidth = 0.05;
        for (let k = 0; k < 3; k++) { g.beginPath(); g.moveTo(x + 0.1 + k * 0.3, y + 0.9); g.lineTo(x + 0.3 + k * 0.3, y + 0.1); g.stroke(); }
      }
      if (c0 === 'd' || c0 === 'p') { g.fillStyle = 'rgba(30,16,8,.35)'; if (isWall(x - 1, y) || isWall(x + 1, y)) g.fillRect(x, y + 0.42, 1, 0.16); else g.fillRect(x + 0.42, y, 0.16, 1); }
      if (c0 >= '1' && c0 <= '3') {
        const el = M.gm.pads === '엘리베이터';
        if (el) { g.fillStyle = '#5a6578'; g.fillRect(x + 0.08, y + 0.08, 0.84, 0.84); g.fillStyle = '#8b98ad'; g.fillRect(x + 0.12, y + 0.12, 0.36, 0.76); g.fillRect(x + 0.52, y + 0.12, 0.36, 0.76); g.fillStyle = '#ffd86a'; g.beginPath(); g.arc(x + 0.5, y + 0.06, 0.06, 0, TAU); g.fill(); }
        else { g.fillStyle = '#1a1030'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.42, 0, TAU); g.fill(); g.strokeStyle = ['#ee6a55', '#5bb3e6', '#7cc66a'][+c0 - 1]; g.lineWidth = 0.1; g.stroke(); }
        g.fillStyle = '#fff'; g.font = '700 0.32px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(c0, x + 0.5, y + 0.52);
      }
    }
    // the seeker's start mark
    g.fillStyle = 'rgba(40,64,106,.8)'; g.beginPath(); g.arc(M.sx, M.sy, 0.9, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(227,174,69,.6)'; g.lineWidth = 0.05; g.beginPath(); g.arc(M.sx, M.sy, 0.8, 0, TAU); g.stroke();
    // walls
    for (let y = 0; y < M.H; y++) for (let x = 0; x < M.W; x++) {
      const c0 = ch(x, y); if (!isWall(x, y) || c0 === 'D' || c0 === 'E') continue;
      if (th.garden) { // trimmed hedge
        g.fillStyle = th.wd; g.fillRect(x, y, 1, 1);
        g.fillStyle = th.wl; g.fillRect(x + 0.03, y + 0.03, 0.94, 0.94);
        g.fillStyle = th.wt; for (let k = 0; k < 5; k++) { g.beginPath(); g.arc(x + 0.15 + rnd() * 0.7, y + 0.15 + rnd() * 0.6, 0.12, 0, TAU); g.fill(); }
        if (!isWall(x, y + 1) && y + 1 < M.H) { g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x, y + 0.82, 1, 0.18); }
        if (rnd() < 0.3) { g.fillStyle = rnd() < 0.5 ? '#f2a6c8' : '#fff3f8'; g.beginPath(); g.arc(x + 0.2 + rnd() * 0.6, y + 0.2 + rnd() * 0.5, 0.06, 0, TAU); g.fill(); }
      } else if (th.cave) { // rough rock with crystals
        g.fillStyle = th.wd; g.fillRect(x, y, 1, 1);
        g.fillStyle = th.wl; for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(x + 0.2 + rnd() * 0.6, y + 0.2 + rnd() * 0.6, 0.3, 0, TAU); g.fill(); }
        g.fillStyle = th.wt; g.beginPath(); g.arc(x + 0.3 + rnd() * 0.4, y + 0.25, 0.14, 0, TAU); g.fill();
        if (!isWall(x, y + 1) && y + 1 < M.H && rnd() < 0.35) { g.fillStyle = 'rgba(110,240,210,.85)'; g.beginPath(); const cx = x + 0.2 + rnd() * 0.6; g.moveTo(cx, y + 0.95); g.lineTo(cx - 0.08, y + 0.7); g.lineTo(cx, y + 0.5); g.lineTo(cx + 0.08, y + 0.7); g.closePath(); g.fill(); }
      } else if (th.grass) {
        g.fillStyle = th.wd; g.fillRect(x, y, 1, 1);
        g.fillStyle = th.wl; for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(x + 0.25 + rnd() * 0.5, y + 0.25 + rnd() * 0.5, 0.32, 0, TAU); g.fill(); }
        g.fillStyle = th.wt; g.beginPath(); g.arc(x + 0.35 + rnd() * 0.3, y + 0.3, 0.16, 0, TAU); g.fill();
      } else if (th.snow) { // log cabin wall with snow on top
        g.fillStyle = th.wd; g.fillRect(x, y, 1, 1);
        for (let k = 0; k < 3; k++) { g.fillStyle = k % 2 ? th.wl : th.wt; g.fillRect(x, y + k * 0.33, 1, 0.3); g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(x, y + k * 0.33 + 0.27, 1, 0.03); }
        if (!isWall(x, y - 1) || y === 0) { g.fillStyle = '#eef4ff'; g.fillRect(x, y, 1, 0.16); }
        if (!isWall(x, y + 1) && y + 1 < M.H) { g.fillStyle = 'rgba(220,240,255,.85)'; for (let k = 0; k < 3; k++) { const cx = x + 0.15 + k * 0.33; g.beginPath(); g.moveTo(cx - 0.05, y + 0.98); g.lineTo(cx + 0.05, y + 0.98); g.lineTo(cx, y + 0.98 + 0.12 + rnd() * 0.12); g.closePath(); g.fill(); } }
      } else {
        g.fillStyle = th.wd; g.fillRect(x, y, 1, 1);
        g.fillStyle = th.wl; g.fillRect(x + 0.04, y + 0.04, 0.92, 0.92);
        if (!isWall(x, y + 1) && y + 1 < M.H) { g.fillStyle = th.wt; g.fillRect(x, y + 0.7, 1, 0.3); g.fillStyle = th.tr; g.fillRect(x, y + 0.7, 1, 0.035); }
      }
      if (c0 === 'w') {
        g.fillStyle = '#16233f'; g.fillRect(x + 0.18, y + 0.18, 0.64, 0.64);
        g.fillStyle = 'rgba(160,200,255,.55)'; g.fillRect(x + 0.22, y + 0.22, 0.56, 0.56);
        g.fillStyle = '#fff8dc'; g.beginPath(); g.arc(x + 0.62, y + 0.36, 0.09, 0, TAU); g.fill();
        g.fillStyle = th.wl; g.fillRect(x + 0.47, y + 0.2, 0.06, 0.6); g.fillRect(x + 0.2, y + 0.47, 0.6, 0.06);
      }
      if (c0 === 'L') {
        const s0 = M.sw.find((q) => q.i === y * M.W + x), ox = s0 ? s0.dx * 0.3 : 0, oy = s0 ? s0.dy * 0.3 : 0;
        g.fillStyle = '#e3ae45'; g.fillRect(x + 0.36 + ox, y + 0.3 + oy, 0.28, 0.4);
        g.fillStyle = '#5a3d10'; g.fillRect(x + 0.45 + ox, y + 0.38 + oy, 0.1, 0.24);
      }
    }
    // soft shadows where floor meets a wall (depth), moonlight under windows, small decorations per map
    for (let y = 0; y < M.H; y++) for (let x = 0; x < M.W; x++) {
      if (isWall(x, y)) continue;
      if (isWall(x, y - 1)) { const gr = g.createLinearGradient(0, y, 0, y + 0.4); gr.addColorStop(0, 'rgba(0,0,0,.42)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(x, y, 1, 0.4); }
      if (isWall(x - 1, y)) { const gr = g.createLinearGradient(x, 0, x + 0.25, 0); gr.addColorStop(0, 'rgba(0,0,0,.3)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(x, y, 0.25, 1); }
      if (ch(x, y) === 'm') { // glowing mushrooms
        const gr = g.createRadialGradient(x + 0.5, y + 0.5, 0, x + 0.5, y + 0.5, 1.3); gr.addColorStop(0, 'rgba(110,255,220,.35)'); gr.addColorStop(1, 'rgba(110,255,220,0)'); g.fillStyle = gr; g.fillRect(x - 1, y - 1, 3, 3);
        for (let k = 0; k < 3; k++) { const mx = x + 0.25 + k * 0.25, my = y + 0.4 + (k % 2) * 0.25, r = 0.1 + (k === 1 ? 0.05 : 0); g.fillStyle = '#d8f8f0'; g.fillRect(mx - 0.025, my, 0.05, 0.14); g.fillStyle = k === 1 ? '#6ef2d0' : '#9af7e4'; g.beginPath(); g.arc(mx, my, r, Math.PI, 0); g.fill(); }
      }
    }
    for (let y = 0; y < M.H; y++) for (let x = 0; x < M.W; x++) {
      if (ch(x, y) !== 'w') continue;
      for (const [dx, dy] of D4) {
        const nx = x + dx, ny = y + dy; if (isWall(nx, ny) || nx < 0 || ny < 0 || nx >= M.W || ny >= M.H) continue;
        const cx = x + 0.5 + dx * 1.6, cy = y + 0.5 + dy * 1.6, gr = g.createRadialGradient(cx, cy, 0, cx, cy, 1.8);
        gr.addColorStop(0, 'rgba(170,200,255,.22)'); gr.addColorStop(1, 'rgba(170,200,255,0)'); g.fillStyle = gr; g.fillRect(cx - 1.8, cy - 1.8, 3.6, 3.6);
        g.strokeStyle = 'rgba(200,220,255,.12)'; g.lineWidth = 0.05; g.beginPath(); g.moveTo(x + 0.5 + dx * 0.6 - dy * 0.3, y + 0.5 + dy * 0.6 - dx * 0.3); g.lineTo(cx - dy * 0.5, cy - dx * 0.5); g.moveTo(x + 0.5 + dx * 0.6 + dy * 0.3, y + 0.5 + dy * 0.6 + dx * 0.3); g.lineTo(cx + dy * 0.5, cy + dx * 0.5); g.stroke();
      }
    }
    for (let y = 1; y < M.H; y++) for (let x = 0; x < M.W; x++) { // wall decorations facing the room below
      const c0 = ch(x, y); if (c0 !== '#' || isWall(x, y + 1) || y + 1 >= M.H || ch(x, y + 1) === 'E') continue;
      const h = (x * 7 + y * 13) % 11;
      if ((M.th === 0 && h === 3) || (M.th === 2 && x % 4 === 1)) { // framed paintings
        g.fillStyle = '#b8862e'; g.fillRect(x + 0.18, y + 0.22, 0.64, 0.46); g.fillStyle = ['#2a3a5a', '#4a2a3a', '#2a4a3a'][h % 3]; g.fillRect(x + 0.24, y + 0.28, 0.52, 0.34);
        g.fillStyle = 'rgba(255,240,200,.35)'; g.beginPath(); g.arc(x + 0.5, y + 0.45, 0.08, 0, TAU); g.fill();
      } else if (M.th === 3) { // string lights along the walls
        for (let k = 0; k < 2; k++) { g.fillStyle = ['#ee6a55', '#ffe36a', '#5bb3e6', '#b48cf0'][(x * 2 + k) % 4]; g.beginPath(); g.arc(x + 0.25 + k * 0.5, y + 0.86, 0.07, 0, TAU); g.fill(); }
      } else if (M.th === 4 && h < 2) { // chalkboard
        g.fillStyle = '#5a4030'; g.fillRect(x + 0.06, y + 0.2, 0.88, 0.5); g.fillStyle = '#24483a'; g.fillRect(x + 0.1, y + 0.24, 0.8, 0.42);
        g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 0.03; g.beginPath(); g.moveTo(x + 0.2, y + 0.38); g.lineTo(x + 0.5, y + 0.36); g.moveTo(x + 0.2, y + 0.5); g.lineTo(x + 0.65, y + 0.5); g.stroke();
      } else if (M.th === 0 && h === 7) { // candle sconce
        g.fillStyle = '#c99a3a'; g.fillRect(x + 0.45, y + 0.5, 0.1, 0.3); g.fillStyle = '#fff3c0'; g.beginPath(); g.arc(x + 0.5, y + 0.45, 0.07, 0, TAU); g.fill();
      }
    }
    if (th.grass && !th.garden) for (let i = 0; i < M.N; i++) { if (M.c[i] !== '.' || rnd() > 0.1) continue; const x = i % M.W, y = (i / M.W) | 0; g.fillStyle = ['#e8d36a', '#d88ad8', '#f2f2ff'][(x + y) % 3]; for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(x + 0.2 + rnd() * 0.6, y + 0.2 + rnd() * 0.6, 0.05, 0, TAU); g.fill(); } }
    // low windows (climb over)
    for (const o of M.vaults) {
      const x = o.x - 0.5, y = o.y - 0.5;
      g.fillStyle = th.wd; g.fillRect(x, y, 1, 1);
      g.fillStyle = th.grass ? '#6b4a2a' : '#7a5a3a';
      if (o.ax === 1) { g.fillRect(x, y + 0.3, 1, 0.4); g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(x, y + 0.3, 1, 0.08); }
      else { g.fillRect(x + 0.3, y, 0.4, 1); g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(x + 0.3, y, 0.08, 1); }
      g.fillStyle = '#ffe9a8'; g.beginPath(); g.arc(o.x, o.y, 0.07, 0, TAU); g.fill();
    }
 // furniture
    function furn57(c0, x, y) {
      const T = M.th;
      if (T === 5) {
        if (c0 === 'W') { g.fillStyle = '#6a4426'; g.fillRect(x + 0.06, y + 0.12, 0.88, 0.84); g.fillStyle = '#4a2c16'; g.fillRect(x + 0.35, y + 0.45, 0.3, 0.5); g.fillStyle = '#eef4ff'; g.fillRect(x + 0.02, y + 0.04, 0.96, 0.16); for (let k = 0; k < 3; k++) { g.fillStyle = '#c9a070'; g.beginPath(); g.arc(x + 0.18 + k * 0.3, y + 0.32, 0.07, 0, TAU); g.fill(); } return true; }
        if (c0 === 'X') { g.fillStyle = '#c6d6ee'; g.beginPath(); g.arc(x + 0.3, y + 0.62, 0.32, 0, TAU); g.arc(x + 0.68, y + 0.58, 0.34, 0, TAU); g.arc(x + 0.5, y + 0.36, 0.3, 0, TAU); g.fill(); g.fillStyle = '#f4f8ff'; g.beginPath(); g.arc(x + 0.42, y + 0.3, 0.18, 0, TAU); g.arc(x + 0.66, y + 0.48, 0.16, 0, TAU); g.fill(); return true; }
        if (c0 === 'P') { g.fillStyle = '#1e3a2a'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.52, 0, TAU); g.fill(); g.fillStyle = '#2e5a3a'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.36, 0, TAU); g.fill(); g.fillStyle = '#eef4ff'; g.beginPath(); g.arc(x + 0.36, y + 0.36, 0.16, 0, TAU); g.arc(x + 0.62, y + 0.6, 0.1, 0, TAU); g.fill(); return true; }
        if (c0 === 'H') { for (let r = 0; r < 2; r++) for (let k = 0; k < 3 - r; k++) { const cx = x + 0.22 + k * 0.28 + r * 0.14, cy = y + 0.7 - r * 0.26; g.fillStyle = '#8a5a32'; g.beginPath(); g.arc(cx, cy, 0.14, 0, TAU); g.fill(); g.fillStyle = '#d8b07a'; g.beginPath(); g.arc(cx, cy, 0.08, 0, TAU); g.fill(); } g.fillStyle = '#eef4ff'; g.fillRect(x + 0.2, y + 0.3, 0.6, 0.08); return true; }
        if (c0 === 'R') { g.fillStyle = '#6a6a76'; g.beginPath(); g.ellipse(x + 0.5, y + 0.56, 0.44, 0.36, 0.3, 0, TAU); g.fill(); g.fillStyle = '#eef4ff'; g.beginPath(); g.ellipse(x + 0.46, y + 0.4, 0.3, 0.16, 0.3, 0, TAU); g.fill(); return true; }
        return false;
      }
      if (T === 6) {
        if (c0 === 'W') { g.fillStyle = '#3a3346'; g.beginPath(); g.ellipse(x + 0.5, y + 0.5, 0.48, 0.44, 0.4, 0, TAU); g.fill(); g.fillStyle = '#0a0810'; g.beginPath(); g.ellipse(x + 0.5, y + 0.55, 0.12, 0.3, 0.2, 0, TAU); g.fill(); g.fillStyle = 'rgba(110,240,210,.7)'; g.beginPath(); g.arc(x + 0.25, y + 0.3, 0.05, 0, TAU); g.fill(); return true; }
        if (c0 === 'X') { for (let k = 0; k < 4; k++) { const cx = x + 0.25 + (k % 2) * 0.45, cy = y + 0.3 + (k >> 1) * 0.4; g.fillStyle = '#e6dcc8'; g.fillRect(cx - 0.04, cy, 0.08, 0.22); g.fillStyle = ['#9a5ac8', '#c86aa8'][k % 2]; g.beginPath(); g.arc(cx, cy, 0.2, Math.PI, 0); g.fill(); g.fillStyle = 'rgba(255,255,255,.6)'; g.beginPath(); g.arc(cx - 0.07, cy - 0.08, 0.035, 0, TAU); g.fill(); } return true; }
        if (c0 === 'R') { g.fillStyle = '#4a4258'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.46, 0, TAU); g.fill(); g.fillStyle = '#6a6078'; g.beginPath(); g.arc(x + 0.45, y + 0.45, 0.28, 0, TAU); g.fill(); g.fillStyle = '#8a80a0'; g.beginPath(); g.arc(x + 0.42, y + 0.42, 0.1, 0, TAU); g.fill(); return true; }
        return false;
      }
      if (T === 7) {
        if (c0 === 'W') { g.fillStyle = '#e8e2d4'; g.beginPath(); for (let k = 0; k < 8; k++) { const a = k * TAU / 8 + 0.39; g.lineTo(x + 0.5 + Math.cos(a) * 0.48, y + 0.5 + Math.sin(a) * 0.48); } g.closePath(); g.fill(); g.strokeStyle = '#5a8a7a'; g.lineWidth = 0.05; g.stroke(); g.fillStyle = '#5a8a7a'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.12, 0, TAU); g.fill(); for (let k = 0; k < 8; k++) { const a = k * TAU / 8 + 0.39; g.beginPath(); g.moveTo(x + 0.5, y + 0.5); g.lineTo(x + 0.5 + Math.cos(a) * 0.46, y + 0.5 + Math.sin(a) * 0.46); g.stroke(); } return true; }
        if (c0 === 'X') { g.fillStyle = '#2a5a26'; for (let k = 0; k < 4; k++) { g.beginPath(); g.arc(x + 0.3 + (k % 2) * 0.4, y + 0.3 + (k >> 1) * 0.4, 0.3, 0, TAU); g.fill(); } for (let k = 0; k < 5; k++) { g.fillStyle = ['#f2a6c8', '#fff3f8', '#e8d36a'][k % 3]; g.beginPath(); g.arc(x + 0.15 + rnd() * 0.7, y + 0.15 + rnd() * 0.7, 0.07, 0, TAU); g.fill(); } return true; }
        if (c0 === 'R') { g.fillStyle = '#9a96a0'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.48, 0, TAU); g.fill(); g.fillStyle = '#3a6a9a'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.36, 0, TAU); g.fill(); g.fillStyle = 'rgba(200,230,255,.7)'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.1, 0, TAU); g.fill(); g.strokeStyle = 'rgba(200,230,255,.5)'; g.lineWidth = 0.03; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.22, 0, TAU); g.stroke(); return true; }
        if (c0 === 'S') { g.fillStyle = '#7a5530'; g.fillRect(x + 0.06, y + 0.25, 0.88, 0.5); g.fillStyle = '#5a3a20'; for (let k = 1; k < 4; k++) g.fillRect(x + 0.06, y + 0.25 + k * 0.125, 0.88, 0.02); return true; }
        return false;
      }
      return false;
    }
    const wallSide = (x, y) => { if (isWall(x, y - 1)) return [0, -1]; if (isWall(x - 1, y)) return [-1, 0]; if (isWall(x + 1, y)) return [1, 0]; if (isWall(x, y + 1)) return [0, 1]; return [0, -1]; };
    for (let y = 0; y < M.H; y++) for (let x = 0; x < M.W; x++) {
      const c0 = ch(x, y);
      if ('WXTHSPRBK'.indexOf(c0) < 0) continue;
      g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x + 0.12, y + 0.16, 0.88, 0.88);
      if (M.th >= 5 && furn57(c0, x, y)) continue;
      if (c0 === 'W') {
        if (M.th === 1) { // tent
          g.fillStyle = '#c96a3a'; g.beginPath(); g.moveTo(x + 0.5, y + 0.06); g.lineTo(x + 0.95, y + 0.94); g.lineTo(x + 0.05, y + 0.94); g.closePath(); g.fill();
          g.fillStyle = '#4a2410'; g.beginPath(); g.moveTo(x + 0.5, y + 0.4); g.lineTo(x + 0.66, y + 0.94); g.lineTo(x + 0.34, y + 0.94); g.closePath(); g.fill();
        } else if (M.th === 4) { // metal locker
          g.fillStyle = '#5e7a96'; g.fillRect(x + 0.08, y + 0.04, 0.84, 0.92);
          g.fillStyle = '#2a3a4a'; for (let k = 0; k < 3; k++) g.fillRect(x + 0.2, y + 0.14 + k * 0.08, 0.6, 0.03);
          g.fillStyle = '#e3ae45'; g.fillRect(x + 0.7, y + 0.5, 0.08, 0.14);
        } else {
          g.fillStyle = M.th === 2 ? '#4a5a6a' : M.th === 3 ? '#c0436a' : '#7b4b2c'; g.fillRect(x + 0.05, y + 0.05, 0.9, 0.9);
          g.fillStyle = 'rgba(255,255,255,.14)'; g.fillRect(x + 0.05, y + 0.05, 0.9, 0.12);
          g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 0.04; g.strokeRect(x + 0.05, y + 0.05, 0.9, 0.9);
          g.beginPath(); g.moveTo(x + 0.5, y + 0.17); g.lineTo(x + 0.5, y + 0.95); g.stroke();
          g.fillStyle = '#e3ae45'; g.beginPath(); g.arc(x + 0.42, y + 0.56, 0.05, 0, TAU); g.arc(x + 0.58, y + 0.56, 0.05, 0, TAU); g.fill();
        }
      } else if (c0 === 'X') {
        if (M.th === 1) { g.fillStyle = '#2e5a2a'; for (let k = 0; k < 4; k++) { g.beginPath(); g.arc(x + 0.3 + (k % 2) * 0.4, y + 0.3 + (k >> 1) * 0.4, 0.3, 0, TAU); g.fill(); } g.fillStyle = '#c94f6a'; g.beginPath(); g.arc(x + 0.35, y + 0.4, 0.05, 0, TAU); g.arc(x + 0.65, y + 0.62, 0.05, 0, TAU); g.fill(); }
        else if (M.th === 3) { g.fillStyle = '#f07fb8'; g.fillRect(x + 0.1, y + 0.3, 0.8, 0.6); g.fillStyle = '#ffe36a'; g.beginPath(); g.arc(x + 0.3, y + 0.28, 0.16, 0, TAU); g.arc(x + 0.6, y + 0.24, 0.18, 0, TAU); g.fill(); g.fillStyle = '#333'; g.beginPath(); g.arc(x + 0.25, y + 0.92, 0.07, 0, TAU); g.arc(x + 0.75, y + 0.92, 0.07, 0, TAU); g.fill(); }
        else { g.fillStyle = '#b88954'; g.fillRect(x + 0.1, y + 0.1, 0.8, 0.8); g.strokeStyle = '#6e4c28'; g.lineWidth = 0.04; g.strokeRect(x + 0.1, y + 0.1, 0.8, 0.8); g.fillStyle = '#ead6aa'; g.fillRect(x + 0.45, y + 0.1, 0.1, 0.8); g.fillRect(x + 0.1, y + 0.45, 0.8, 0.1); }
      } else if (c0 === 'T') {
        if (M.th === 2) { g.fillStyle = 'rgba(170,210,240,.35)'; g.fillRect(x + 0.08, y + 0.08, 0.84, 0.84); g.strokeStyle = '#b8c8d8'; g.lineWidth = 0.05; g.strokeRect(x + 0.08, y + 0.08, 0.84, 0.84); g.fillStyle = ['#e3ae45', '#c94f6a', '#5bb3e6'][(x + y) % 3]; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.15, 0, TAU); g.fill(); }
        else if (M.th === 4) { g.fillStyle = '#9a7a52'; g.fillRect(x + 0.1, y + 0.15, 0.8, 0.6); g.fillStyle = '#5a4a3a'; g.fillRect(x + 0.2, y + 0.78, 0.6, 0.12); }
        else if (M.th === 1) { g.fillStyle = '#7a5530'; g.fillRect(x + 0.05, y + 0.25, 0.9, 0.5); g.strokeStyle = '#4a3018'; g.lineWidth = 0.04; g.beginPath(); g.moveTo(x + 0.05, y + 0.5); g.lineTo(x + 0.95, y + 0.5); g.stroke(); }
        else { g.fillStyle = M.th === 3 ? '#3a6a9a' : '#6b4529'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.42, 0, TAU); g.fill(); g.fillStyle = M.th === 3 ? '#f2e9d8' : '#e8dcc6'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.33, 0, TAU); g.fill(); }
      } else if (c0 === 'H') {
        if (M.th === 3) { g.fillStyle = '#5a2a5a'; g.fillRect(x + 0.04, y + 0.04, 0.92, 0.92); for (let k = 0; k < 4; k++) { g.fillStyle = k % 2 ? '#f2e9d8' : '#ee6a55'; g.fillRect(x + 0.04 + k * 0.23, y + 0.04, 0.23, 0.3); } }
        else if (M.th === 1) { g.fillStyle = '#6b4a2a'; for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(x + 0.2 + k * 0.3, y + 0.62, 0.17, 0, TAU); g.arc(x + 0.35 + (k % 2) * 0.3, y + 0.35, 0.17, 0, TAU); g.fill(); } g.fillStyle = '#c9a070'; g.beginPath(); g.arc(x + 0.2, y + 0.62, 0.08, 0, TAU); g.arc(x + 0.5, y + 0.62, 0.08, 0, TAU); g.fill(); }
        else { g.fillStyle = '#4a2d1c'; g.fillRect(x + 0.04, y + 0.04, 0.92, 0.92); const cols = ['#c94f4f', '#4f7fc9', '#d9b04a', '#5fa86a', '#9a6bc9', '#e07b39']; for (let r = 0; r < 3; r++) for (let k = 0; k < 6; k++) { g.fillStyle = cols[(x + y + r * 2 + k) % 6]; g.fillRect(x + 0.1 + k * 0.135, y + 0.1 + r * 0.28, 0.11, 0.22); } }
      } else if (c0 === 'S') {
        g.fillStyle = M.th === 1 ? '#6b4a2a' : M.th === 4 ? '#3e5a7a' : '#5d3b72'; g.fillRect(x + 0.06, y + 0.2, 0.88, 0.6);
        g.fillStyle = 'rgba(255,255,255,.15)'; g.fillRect(x + 0.1, y + 0.24, 0.8, 0.1);
      } else if (c0 === 'P') {
        if (M.th === 1) { g.fillStyle = '#1e3a1e'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.55, 0, TAU); g.fill(); g.fillStyle = '#2e5a2a'; g.beginPath(); g.arc(x + 0.42, y + 0.42, 0.4, 0, TAU); g.fill(); g.fillStyle = '#3e7a36'; g.beginPath(); g.arc(x + 0.36, y + 0.36, 0.2, 0, TAU); g.fill(); }
        else { g.fillStyle = '#a0522d'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.22, 0, TAU); g.fill(); g.fillStyle = '#3f8a4a'; for (let k = 0; k < 6; k++) { const a = k * TAU / 6; g.beginPath(); g.ellipse(x + 0.5 + Math.cos(a) * 0.22, y + 0.5 + Math.sin(a) * 0.22, 0.17, 0.08, a, 0, TAU); g.fill(); } }
      } else if (c0 === 'R') {
        if (M.th === 1) { g.fillStyle = '#6a6a72'; g.beginPath(); g.ellipse(x + 0.5, y + 0.55, 0.45, 0.38, 0.3, 0, TAU); g.fill(); g.fillStyle = '#8a8a94'; g.beginPath(); g.ellipse(x + 0.42, y + 0.45, 0.25, 0.18, 0.3, 0, TAU); g.fill(); }
        else if (M.th === 3) { g.fillStyle = ['#ee6a55', '#e3ae45', '#5bb3e6', '#b48cf0'][(x * 3 + y) % 4]; g.fillRect(x + 0.06, y + 0.06, 0.88, 0.88); g.fillStyle = '#fff3cf'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.16, 0, TAU); g.fill(); }
        else { g.fillStyle = '#4a4458'; g.fillRect(x + 0.15, y + 0.6, 0.7, 0.32); g.fillStyle = '#d8d4e4'; g.beginPath(); g.arc(x + 0.5, y + 0.38, 0.26, 0, TAU); g.fill(); g.fillRect(x + 0.32, y + 0.5, 0.36, 0.16); }
      } else if (c0 === 'B') {
        g.fillStyle = '#5b3b28'; g.fillRect(x + 0.04, y + 0.04, 0.92, 0.92);
        g.fillStyle = '#a983cc'; g.fillRect(x + 0.1, y + 0.1, 0.8, 0.8);
        const [wx, wy] = wallSide(x, y);
        g.fillStyle = '#f4ece0';
        if (wy < 0) g.fillRect(x + 0.18, y + 0.12, 0.64, 0.22); else if (wy > 0) g.fillRect(x + 0.18, y + 0.66, 0.64, 0.22); else if (wx < 0) g.fillRect(x + 0.12, y + 0.18, 0.22, 0.64); else g.fillRect(x + 0.66, y + 0.18, 0.22, 0.64);
      } else if (c0 === 'K') { // cage base
        g.fillStyle = '#3a3040'; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.46, 0, TAU); g.fill();
        g.strokeStyle = '#8a7a9a'; g.lineWidth = 0.05; g.beginPath(); g.arc(x + 0.5, y + 0.5, 0.42, 0, TAU); g.stroke();
      }
    }
    return c;
  }
  function lampPoly(W, j, out) { // light area of a lit lantern (rays stop at walls)
    const o = W.M.lans[j];
    out.length = 0;
    for (let i = 0; i <= 32; i++) { const a = i / 32 * TAU, dx = Math.cos(a), dy = Math.sin(a), d = castRay(W, o.x, o.y, dx, dy, LAMP_R); out.push(o.x + dx * d, o.y + dy * d); }
    return out;
  }
  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    const fine = (() => { try { return !!window.LOUNGE_DESKTOP || matchMedia('(pointer:fine)').matches; } catch (e) { return false; } })();
    let st = null, key = null, W = null, lay = null, aiMem = [];
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const ctrlOn = () => me() >= 0 && !auto();
    const COL = (s) => P(s).color || (L.COLORS && L.COLORS[s % 8]) || '#888';
    const curKey = () => (st ? st.rid + '.' + st.rd + '.' + (st.ph === 'pick' ? 'p' : 'g') : null);
    const myP = () => { const m = me(); return W && m >= 0 ? W.pl[m] : null; };
    function spect() { if (!W || !st || st.ph !== 'play' || W.res) return true; const p = myP(); return !p || auto() || p.st === 3 || p.st === 4; }
    const lsGet = (k) => { try { return +localStorage.getItem('lounge.fl2.' + k) || 0; } catch (e) { return 0; } };
    const lsSet = (k, v) => { try { localStorage.setItem('lounge.fl2.' + k, String(v)); } catch (e) { /* private mode */ } };

    /* ----- round start ----- */
    let ripples = [], floats = [], ghosts = [], banner = null, tipT = 0, endT = 0, shake = 0, lastFx = 0, hb = 0, pickT = 0, myPick = -1, ptGuest = null;
    let prints = [], prT = 0, prLast = [], miniCv = null, miniKey = '';
    function startRound() {
      key = curKey();
      W = newWorld(st);
      aiMem = W.pl.map(() => ({}));
      ripples = []; floats = []; ghosts = []; banner = null; lastFx = 0; lastQ = -1; lampCache = null;
      prints = []; prLast = []; sneakOn = false; bigMap = false; lastCtx = '';
      for (const k in remIn) delete remIn[k];
      locIn.act = 0; locIn.sk = 0; locIn.ck = null; netA.h = 0; netA.u = 0; netA.ck = null;
      endT = END_T; hb = 0; myPick = -1; ptGuest = null;
      if (st.ph === 'pick') {
        let human = false; for (let s = 0; s < st.np; s++) if (!isAIseat(s)) human = true;
        pickT = human ? PICK_T : auto() ? 0.6 : 1.4;
      }
      tipT = 0;
      const p = myP();
      if (st.ph === 'play' && p && ctrlOn()) { const role = p.sk ? 's' : 'k', n = lsGet('tip' + role); if (n < 2) { lsSet('tip' + role, n + 1); tipT = START_T + 3; } }
      if (st.ph === 'end' || st.ph === 'done') { W.res = { t: 0, sent: 1 }; W.t = START_T + 0.01; W.go = 1; }
      lay = null;
      layout();
      buildPick();
    }

    /* ----- layout ----- */
    let bgCv = null, bgKey = '', oc = null, octx = null;
    const cam = { x: 14, y: 15 };
    let moon = [];
    function layout() {
      if (!W) return;
      const M = W.M, w = cv.w, h = cv.h, sp = spect();
      const p = myP(), ctl = ctrlOn() && !sp && p && p.st === 0;
      const bot = ctl ? 150 : 10;
      let ts;
      if (sp) ts = Math.max(7, Math.min((w - 12) / M.W, (h - TOPH - bot - 6) / M.H));
      else ts = clamp(Math.min(w / 11, (h - TOPH) / 13.5), 24, 50);
      const first = !lay;
      lay = { w, h, bot, ts, sp, ay: sp ? TOPH + (h - TOPH - bot) / 2 : TOPH + (h - TOPH - bot * 0.5) * 0.47 };
      const dpr = Math.min(2, cv.dpr || 1), k = M.k + '|' + ts + '|' + dpr;
      if (k !== bgKey || !bgCv) {
        bgKey = k; bgCv = buildMapCanvas(M, ts, dpr);
        moon = [];
        for (let i = 0; i < M.N; i++) if (M.c[i] === 'w') { const x = i % M.W, y = (i / M.W) | 0; for (const [dx, dy] of D4) { const n = tileAt(M, x + dx + 0.5, y + dy + 0.5); if (x + dx >= 0 && y + dy >= 0 && x + dx < M.W && y + dy < M.H && !M.sol[n]) moon.push([x + 0.5 + dx * 1.6, y + 0.5 + dy * 1.6]); } }
      }
      const odpr = cv.dpr || 1;
      if (!oc) { oc = document.createElement('canvas'); octx = oc.getContext('2d'); }
      const ow = Math.max(1, Math.round(w * odpr)), oh = Math.max(1, Math.round(h * odpr));
      if (oc.width !== ow || oc.height !== oh) { oc.width = ow; oc.height = oh; }
      btnSig = '';
      const t = camTarget(); if (first || sp) { cam.x = t.x; cam.y = t.y; }
    }
    cv.onresize = () => { if (W) { lay = null; layout(); } };
    function camTarget() {
      const M = W.M;
      if (!lay || lay.sp) return { x: M.W / 2, y: M.H / 2 };
      const p = myP() || seekerOf(W);
      const hw = lay.w / 2 / lay.ts, top = (lay.ay - TOPH) / lay.ts, below = (lay.h - lay.ay) / lay.ts;
      let x = p.x, y = p.y;
      x = M.W + 2 < hw * 2 ? M.W / 2 : clamp(x, hw - 1, M.W + 1 - hw);
      y = M.H + 2 < top + below ? M.H / 2 : clamp(y, top - 1, M.H + 1 - below);
      return { x, y };
    }
    const SX = (x) => lay.w / 2 + (x - cam.x) * lay.ts;
    const SY = (y) => lay.ay + (y - cam.y) * lay.ts;

    /* ----- input: floating stick (left), seeker aims by holding the right side, buttons; keys via api.input ----- */
    const locIn = { ax: 0, ay: 0, rn: 0, sn: 0, aa: null, act: 0, sk: 0, tr: 0, ck: null, wk: null, ai: 0 };
    const netA = { h: 0, u: 0, ck: null };
    let stick = null, aimT = null, btnRun = false, mouse = null;
    function needle(p) {
      const c = p && p.chk; if (!c) return -9;
      const el = host() ? W.t - c.t0 : (c.seen ? (performance.now() - c.seen) / 1000 * SPD() : 0);
      return (el - CHK_WARN) / CHK_DUR;
    }
    function judge(p) {
      const c = p.chk, v = needle(p);
      const r = v >= c.z && v <= c.z + CHK_G ? 2 : v >= c.z - 0.01 && v <= c.z + CHK_W ? 1 : 0;
      c.ans = 1;
      if (host()) locIn.ck = [c.id, r]; else { netA.ck = [c.id, r]; pubT = 0; inT = 0; }
      api.buzz(r ? 10 : 40);
    }
    function pressAct() {
      if (!W || st.ph !== 'play') return;
      const p = myP();
      if (p && p.chk && !p.chk.ans) { if (needle(p) > -0.12) judge(p); return; }
      if (host()) locIn.act = 1; else { netA.h = (netA.h + 1) % 1000; pubT = 0; inT = 0; }
    }
    function pressSkill() {
      if (!W || st.ph !== 'play') return;
      if (host()) locIn.sk = 1; else { netA.u = (netA.u + 1) % 1000; pubT = 0; inT = 0; }
    }
    let aimHelp = null;
    function readInput(now) {
      let sx = 0, sy = 0;
      if (stick) { // small dead zone, then a gentle curve so half a push = walking (sneak only with a light touch)
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), dz = 6;
        if (d > dz) { const m = Math.min(1, (d - dz) / (STICK_R - dz)); const c = m < 0.35 ? m : 0.42 + (m - 0.35) * (0.58 / 0.65); sx = dx / d * c; sy = dy / d * c; }
      }
      if (!sx && !sy && api.input) { const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down'); if (kx || ky) { const m = hyp(kx, ky); sx = m > 1 ? kx / m : kx; sy = m > 1 ? ky / m : ky; } }
      locIn.ax = sx; locIn.ay = sy;
      locIn.rn = btnRun || !!(api.input && api.input.held('run')) ? 1 : 0;
      locIn.sn = sneakOn || (api.input && api.input.held('sneak')) ? 1 : 0;
      if (locIn.sn) locIn.rn = 0;
      locIn.aa = null;
      const p = myP();
      if (p && p.sk && lay && !lay.sp) {
        const gx = api.input ? api.input.axis('aimL', 'aimR') : 0, gy = api.input ? api.input.axis('aimU', 'aimD') : 0;
        if (aimT) locIn.aa = Math.atan2(aimT.y - SY(p.y), aimT.x - SX(p.x));
        else if (hyp(gx, gy) > 0.35) locIn.aa = Math.atan2(gy, gx);
        else if (mouse && now - mouse.t < 2500 && !stick) locIn.aa = Math.atan2(mouse.y - SY(p.y), mouse.x - SX(p.x));
        // aim help: the light faces where you walk; a survivor you can see close to that direction pulls it a little
        if (locIn.aa == null && W.go && beamOn(p) && !p.chg) {
          const base = hyp(sx, sy) > 0.3 ? Math.atan2(sy, sx) : p.a;
          let bd = 0.6, best = null;
          for (const q of W.pl) {
            if (q.sk || q.st !== 0 || hiddenFrom(q)) continue;
            const d = hyp(q.x - p.x, q.y - p.y); if (d > RANGE + 0.6 || d < 0.2) continue;
            const a = Math.atan2(q.y - p.y, q.x - p.x), da = Math.abs(wrapA(a - base));
            if (da < bd && seeFull(W, p, q)) { bd = da; best = a; }
          }
          aimHelp = best;
          if (best != null) locIn.aa = best;
        } else aimHelp = null;
      }
    }
    function onDown(e) {
      if (!ctrlOn() || !lay || lay.sp || !W || st.ph !== 'play') return;
      const pt = cv.local(e), p = myP();
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      tipT = Math.min(tipT, 0.6);
      const mr = miniRect();
      if (bigMap || (pt.x >= mr.x - 6 && pt.x <= mr.x + mr.w + 6 && pt.y >= mr.y - 6 && pt.y <= mr.y + mr.h + 6)) { bigMap = !bigMap; api.sfx('click'); api.buzz(6); return; }
      if (p && p.chk && !p.chk.ans && pt.x > cv.w * 0.45) { if (needle(p) > -0.12) judge(p); return; }
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (p && p.sk && e.pointerType !== 'mouse' && pt.x > cv.w * 0.6) { aimT = { id: e.pointerId, x: pt.x, y: pt.y }; return; }
      stick = { id: e.pointerId, bx: pt.x, by: pt.y, x: pt.x, y: pt.y };
    }
    function onMove(e) {
      const pt = cv.local(e);
      if (e.pointerType === 'mouse') mouse = { x: pt.x, y: pt.y, t: performance.now() };
      if (aimT && aimT.id === e.pointerId) { aimT.x = pt.x; aimT.y = pt.y; return; }
      if (!stick || e.pointerId !== stick.id) return;
      stick.x = pt.x; stick.y = pt.y;
      const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), mx = STICK_R * 1.25;
      if (d > mx) { stick.bx = stick.x - dx / d * mx; stick.by = stick.y - dy / d * mx; }
    }
    function onUp(e) {
      if (aimT && aimT.id === e.pointerId) aimT = null;
      if (stick && e.pointerId === stick.id) stick = null;
    }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    const btn = {};
    function mkBtn(cls, label, sub, down, up) {
      const b = L.h('button', { class: 'fl-btn ' + cls, type: 'button', 'aria-label': label }, L.h('span', { class: 'lb', text: label }), L.h('small', { text: sub }));
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); try { b.setPointerCapture(e.pointerId); } catch (er) {} b.classList.add('on'); down(e); });
      const off = () => { if (!b.classList.contains('on')) return; b.classList.remove('on'); if (up) up(); };
      b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('lostpointercapture', off);
      b.addEventListener('contextmenu', noCtx);
      b.style.display = 'none';
      root.appendChild(b);
      return b;
    }
    btn.act = mkBtn('fl-act', '행동', '', () => { pressAct(); tipT = Math.min(tipT, 0.6); api.buzz(8); });
    btn.run = mkBtn('fl-run', '달리기', '꾹', () => { btnRun = true; }, () => { btnRun = false; });
    btn.sk = mkBtn('fl-sk', '특기', '', () => { pressSkill(); api.buzz(8); });
    btn.sn = mkBtn('fl-sn', '살금', '끄기', () => { sneakOn = !sneakOn; api.buzz(6); btnSig = ''; });
    btn.sk.appendChild(L.h('i', { class: 'cd' }));
    let sneakOn = false, actP = -1, skC = -1;
    let btnSig = '';
    function setBtn(b, lb, sub, cls) {
      b.querySelector('.lb').textContent = lb; b.querySelector('small').textContent = sub; b.setAttribute('aria-label', lb);
      for (const c of ['dim', 'lit', 'pulse', 'hot']) b.classList.toggle(c, cls === c);
    }
    function ctxSub(c, p) {
      const M = W.M;
      switch (c.k) {
        case 'lan': return Math.floor(W.lan[c.j].p * 100) + '%';
        case 'stop': { const j = p.job; if (!j) return ''; return (j.k === 1 ? '등불 ' : j.k === 2 ? '대문 ' : j.k === 3 ? '치료 ' : '') + Math.floor((j.pp != null ? j.pp : j.k === 1 ? W.lan[j.j].p : j.k === 2 ? W.gate[j.j].p : j.k === 3 ? W.pl[j.j].hl : 0) * 100) + '%'; }
        case 'hide': case 'open': return (SPOT_NM[M.th] || SPOT_NM[0])[M.spots[c.j].k === 'W' ? 0 : 1];
        case 'out': return (SPOT_NM[M.th] || SPOT_NM[0])[M.spots[p.hid].k === 'W' ? 0 : 1];
        case 'rescue': case 'heal': return name(c.j).slice(0, 5);
        case 'gate': return Math.floor(W.gate[c.j].p * 100) + '%';
        case 'drop': return '살인마 막기';
        case 'vault': return '창문·책장';
        case 'lunge': return '가까이서';
        case 'kick': return Math.floor(W.lan[c.j].p * 100) + '%';
        case 'pad': return M.gm.pads || '';
        case 'sw': return W.lit[M.sw[c.j].room] > 0 ? '끄기' : '켜기';
        default: return '';
      }
    }
    function jobProg(p) { // 0..1 progress of what I'm doing now (for the ring on the big button)
      const j = p && p.job; if (!j) return 0;
      if (j.pp != null) return j.pp;
      return j.k === 1 ? W.lan[j.j].p : j.k === 2 ? W.gate[j.j].p : j.k === 3 ? W.pl[j.j].hl : clamp(j.p / jobT(j.k), 0, 1);
    }
    // where the big button's action happens (highlighted in the world so it's clear what it will do)
    function ctxSpot(c, p) {
      const M = W.M;
      switch (c.k) {
        case 'lan': case 'kick': return M.lans[c.j];
        case 'rescue': { const q = W.pl[c.j]; return q ? { x: q.x, y: q.y } : null; }
        case 'heal': { const q = W.pl[c.j]; return q ? { x: q.x, y: q.y } : null; }
        case 'hide': case 'open': return M.spots[c.j];
        case 'gate': return { x: M.gates[c.j].x, y: M.gates[c.j].y };
        case 'drop': case 'break': return M.pals[c.j];
        case 'vault': return c.v.kind === 'v' ? M.vaults[c.v.j] : M.pals[c.v.j];
        case 'pad': return M.pads[c.j];
        case 'sw': return M.sw[c.j];
        case 'hatch': return M.hatches[W.hatch];
        default: return null;
      }
    }
    let lastCtx = '';
    function syncBtns() {
      const p = myP(), vis = !!W && !!st && st.ph === 'play' && ctrlOn() && !!lay && !lay.sp && !!p && p.st === 0;
      if (!vis) { if (btnSig !== 'x') { btnSig = 'x'; for (const k in btn) btn[k].style.display = 'none'; } return; }
      let a = '…', as = '', ac = 'dim', ck = '';
      if (p.chk && !p.chk.ans && needle(p) < 1.05) { const w = needle(p) < 0; a = w ? '준비…' : '지금!'; as = w ? '바늘을 봐요' : '노란 칸'; ac = w ? 'lit' : 'hot'; }
      else if (p.sk && !W.go) { a = '덥석'; as = '세는 중…'; ac = 'dim'; }
      else {
        const c = ctxOf(W, p);
        if (c) { ck = c.k + (c.j != null ? c.j : ''); a = CTX_NM[c.k] || '행동'; as = ctxSub(c, p); ac = c.k === 'stop' || c.k === 'out' ? 'lit' : c.k === 'lunge' ? '' : 'pulse'; }
        else if (p.vt) { a = '넘는 중'; }
        else if (p.stun > 0) { a = p.sk ? '어질어질' : '덫!'; }
        else if (p.ride) { a = '이동 중'; }
        else if (p.sk && p.chg > 0) { a = '돌진 중'; }
        else if (p.sk && (p.lr > 0 || p.ln > 0)) { a = '덥석'; as = '숨 고르기'; }
        else { a = p.sk ? '덥석' : '행동'; as = p.sk ? '' : '등불 옆에서'; }
      }
      if (ck && ck !== lastCtx && ck.indexOf('lunge') < 0 && ck.indexOf('stop') < 0) api.buzz(6);   // a new thing to do nearby: tiny tap
      lastCtx = ck;
      const pr = p.job ? jobProg(p) : 0;
      if (Math.abs(pr - actP) > 0.004) { actP = pr; btn.act.style.setProperty('--p', pr.toFixed(3)); }
      const K = p.sk ? SEEKERS[p.c] : KIDS[p.c];
      let s = null, ss = '', sc = '';
      if (K && K.act) {
        s = K.act;
        if (p.cd > 0) { ss = Math.ceil(p.cd) + '초'; sc = 'dim'; }
        else if (p.sk && p.c === S_SHADE && p.cl > 0) { ss = '그림자'; sc = 'lit'; }
        else { ss = p.sk && p.c === S_MIRROR ? (W.mir ? (hyp(W.mir.x - p.x, W.mir.y - p.y) < 4 ? '옮기기' : '이동') : '세우기') : '준비'; sc = ''; }
        const c2 = p.cd > 0 && K.cd ? clamp(p.cd / K.cd, 0, 1) : 0;
        if (Math.abs(c2 - skC) > 0.01) { skC = c2; btn.sk.style.setProperty('--c', c2.toFixed(2)); }
      }
      const sig = [a, as, ac, s, ss, sc, p.sk, p.hid, sneakOn, !!p.job].join('|');
      if (sig === btnSig) return;
      btnSig = sig;
      btn.act.style.display = '';
      setBtn(btn.act, a, as, ac);
      btn.run.style.display = p.sk ? 'none' : '';
      btn.run.classList.toggle('dim', p.hid >= 0 || !!p.job || sneakOn);
      btn.sn.style.display = p.sk ? 'none' : '';
      setBtn(btn.sn, '살금', sneakOn ? '켜짐' : '꺼짐', sneakOn ? 'lit' : '');
      btn.sk.style.display = s ? '' : 'none';
      if (s) setBtn(btn.sk, s, ss, sc);
      btn.sk.style.right = p.sk ? '112px' : '25px'; btn.sk.style.bottom = p.sk ? '10px' : '118px';
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !ctrlOn() || !lay || lay.sp) return;
      if (id === 'act') { pressAct(); tipT = Math.min(tipT, 0.6); }
      else if (id === 'skill') pressSkill();
      else if (id === 'map') { bigMap = !bigMap; api.sfx('click'); }
    }) : null;
    let bigMap = false;
    const releaseAll = () => { stick = null; aimT = null; btnRun = false; for (const k in btn) btn[k].classList.remove('on'); };
    window.addEventListener('blur', releaseAll);

    /* ----- character pick (DOM) ----- */
    let pickEl = null, pickParts = null, pickSig = '';
    function portrait(cvEl, sk, c, col) {
      const g = cvEl.getContext('2d'), d = 2; cvEl.width = 40 * d; cvEl.height = 40 * d;
      g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, 40, 40);
      g.fillStyle = 'rgba(12,8,22,.6)'; g.beginPath(); g.arc(20, 20, 19, 0, TAU); g.fill();
      drawChar(g, 20, 22, sk ? 12 : 12.5, sk, c, col, Math.PI / 2, { noShadow: 1, beam: sk });
    }
    function pickLeft() { return host() ? pickT : ptGuest ? Math.max(0, ptGuest.v - (performance.now() - ptGuest.at) / 1000 * SPD()) : PICK_T; }
    function choose(c) {
      const m = me(); if (m < 0 || !st || st.ph !== 'pick') return;
      myPick = c; api.sfx('click'); api.buzz(8);
      if (host()) { const ch = st.ch.slice(); ch[m] = c; api.setState(Object.assign({}, st, { ch })); }
      else { pubT = 0; inT = 0; }
      syncPick(true);
    }
    function buildPick() {
      if (pickEl) { pickEl.remove(); pickEl = null; pickParts = null; }
      pickSig = '';
      if (!st || st.ph !== 'pick') return;
      const m = me(), can = m >= 0 && !auto(), sk = m === st.sk;
      const list = sk ? SEEKERS : KIDS;
      const head = L.h('div', { class: 'fl-pk-head' }, L.h('b', { text: st.rd + '판 · ' + MAPS[st.mk].nm }), L.h('span', { text: '' }));
      const role = L.h('div', { class: 'fl-pk-role' });
      if (can) role.innerHTML = sk ? '이번 판 당신은 <b>살인마</b>예요! 생존자 7명을 찾아 새장에 가둬요.' : '이번 판 당신은 <b>생존자</b>예요. 살인마: <b></b> · 등불 5개를 켜고 탈출해요.';
      else role.innerHTML = '캐릭터 고르는 중… 이번 판 살인마: <b></b>';
      const sb = role.querySelectorAll('b'); const nb = sb[sb.length - 1]; if (nb && !(can && sk)) nb.textContent = name(st.sk);
      const grid = L.h('div', { class: 'fl-pk-grid' });
      const cards = [];
      if (can) list.forEach((K, c) => {
        const cvEl = L.h('canvas', {});
        const b = L.h('button', { class: 'fl-card', type: 'button', onclick: () => choose(c) }, cvEl, L.h('div', { class: 't' }, L.h('b', { text: K.nm }), L.h('small', { text: (K.act ? '「' + K.act + '」 ' : '') + K.tag })));
        portrait(cvEl, sk, c, sk ? '#e3ae45' : COL(m));
        grid.appendChild(b); cards.push(b);
      });
      const desc = L.h('div', { class: 'fl-pk-desc', text: '' });
      const team = L.h('div', { class: 'fl-pk-team' });
      const inner = L.h('div', { class: 'in' }, head, role, can ? grid : null, can ? desc : null, team);
      pickEl = L.h('div', { class: 'fl-pick' }, inner);
      root.appendChild(pickEl);
      pickParts = { timer: head.querySelector('span'), cards, desc, team, sk, can };
      syncPick(true);
    }
    function syncPick(force) {
      if (!pickEl || !pickParts || !st) return;
      if (st.ph !== 'pick') { pickEl.remove(); pickEl = null; pickParts = null; return; }
      const m = me(), cur = myPick >= 0 ? myPick : m >= 0 ? st.ch[m] : -1;
      const left = Math.ceil(pickLeft());
      const sig = [st.ch.join(','), cur, left].join('|');
      if (!force && sig === pickSig) return;
      pickSig = sig;
      const all = st.ch.every((c) => c >= 0);
      pickParts.timer.textContent = all ? '곧 시작' : left + '초';
      const list = pickParts.sk ? SEEKERS : KIDS;
      pickParts.cards.forEach((b, c) => {
        b.classList.toggle('sel', c === cur);
        const taken = !pickParts.sk && st.ch.some((x, i) => i !== m && i !== st.sk && x === c);
        b.classList.toggle('taken', taken);
      });
      if (pickParts.can) pickParts.desc.textContent = cur >= 0 ? list[cur].nm + ' — ' + list[cur].d : '캐릭터를 눌러 골라요. 시간이 지나면 무작위로 정해져요.';
      pickParts.team.innerHTML = '';
      for (let s = 0; s < st.np; s++) {
        const c = st.ch[s], L2 = s === st.sk ? SEEKERS : KIDS;
        const it = L.h('span', {}, L.h('i', { style: { background: COL(s) } }), (s === st.sk ? '살인마 ' : '') + name(s).slice(0, 6) + ' · ' + (c >= 0 ? L2[c].nm : '고르는 중'));
        pickParts.team.appendChild(it);
      }
    }

    /* ----- effects ----- */
    const lastSfx = {};
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function addFloat(x, y, t, c, life) { floats.push({ x, y, txt: t, c, t: 0, life: life || 1.1 }); if (floats.length > 10) floats.shift(); }
    function setBanner(t, sub, c, life) { banner = { t, sub, c, life: life || 1.8, max: life || 1.8 }; }
    function hearsRipple(kind, x, y, src) {
      const mp = myP(), m = me();
      if (spect()) return LOUD[kind] === 1 || kind === 0 || kind === 2;
      if (!mp) return false;
      if (src === m) return false;
      const d = hyp(x - mp.x, y - mp.y);
      if (mp.sk) return LOUD[kind] === 1 || d <= (mp.c === S_BAT ? 99 : HEAR_S);
      return d < 9 && (LOUD[kind] === 1 || kind === 7);
    }
    function onFx(code, x, y, a, b) {
      const m = me(), mp = myP(), sp = spect(), mine = !!mp && !auto(), seek = mine && mp.sk;
      switch (code) {
        case 0: {
          if (hearsRipple(a, x, y, b)) { ripples.push({ x, y, k: a, t: 0 }); if (ripples.length > 24) ripples.shift(); }
          else if (b === m && a !== 6 && a !== 7) addFloat(x, y - 0.6, NOISE_NM[a] || '', '#ffd27a', 0.8);
          if (mp && b !== m && hyp(x - mp.x, y - mp.y) < 10) sfx(LOUD[a] ? 'thud' : 'tick', 140);
          if (a === 2 && b === m && mine) { api.buzz(30); setBanner('덜컹!', '너무 오래 숨어 있었어요 · 옮겨요!', '#ffd27a', 1.6); }
          if (a === 3 && b === m && mine) { setBanner('펑!', '실수해서 소리가 났어요 · 살인마가 들었어요', '#ee6a55', 1.4); api.buzz(60); shake = 0.5; }
          break;
        }
        case 1: if (a === m) { sfx('whoosh'); api.buzz(14); addFloat(x, y - 0.7, '쏙!', '#bfe3ff', 0.9); } break;
        case 2: if (a === m) sfx('pop'); break;
        case 3: {
          sfx('hit', 30);
          if (a === m && mine) { setBanner('깜짝!', '한 번 더 걸리면 새장에 갇혀요 · 도망쳐요!', '#ee6a55', 1.8); api.buzz(120); shake = 0.7; }
          else if (seek) { setBanner('깜짝 놀람!', name(a) + ' · 한 번 더 잡으면 새장', '#e3ae45', 1.3); api.buzz(40); }
          else addFloat(x, y - 0.8, name(a) + ' 깜짝!', '#ee6a55', 1.2);
          break;
        }
        case 4: {
          const c = W.M.cages[b]; ghosts.push({ x, y, x1: c ? c.x : x, y1: c ? c.y : y, i: a, t: 0, cage: 1 });
          sfx('hit', 30);
          if (a === m && mine) { setBanner('새장에 갇혔어요!', '친구가 구해 줄 때까지 기다려요 · ' + CAGE_T + '초', '#ee6a55', 2.4); api.buzz(160); shake = 0.9; }
          else if (seek) { setBanner('잡았다!', name(a) + '를 새장에 가뒀어요', '#e3ae45', 1.6); sfx('pop', 30); api.buzz(60); }
          else if (mine) setBanner('친구가 갇혔어요!', name(a) + ' · 새장으로 가서 「구출」', '#ffb3a8', 1.8);
          break;
        }
        case 5: {
          ghosts.push({ x, y, x1: x, y1: y - 1.2, i: a, t: 0 });
          if (a === m && mine) { setBanner('탈락…', '이제 유령이 되어 맵 전체를 구경해요', '#c9bfd8', 2.4); api.buzz(80); }
          else if (seek) { setBanner('탈락!', name(a) + ' +1점', '#e3ae45', 1.4); sfx('pop', 30); }
          else addFloat(x, y - 0.8, name(a) + ' 탈락', '#c9bfd8', 1.6);
          break;
        }
        case 6: {
          sfx('win', 200);
          if (a === m && mine) { setBanner('탈출 성공!', b === 2 ? '비밀 통로로 빠져나왔어요 +3점' : '대문으로 빠져나왔어요 +3점', '#7cc66a', 2.4); api.buzz(60); }
          else addFloat(x, y - 0.8, name(a) + ' 탈출!', '#7cc66a', 1.6);
          break;
        }
        case 7: {
          sfx('pop');
          if (a === m && mine) { setBanner('구출됐어요!', name(b) + ' 고마워! · 한 번 더 갇히면 탈락', '#7cc66a', 1.8); api.buzz(40); }
          else if (b === m && mine) { addFloat(x, y - 0.8, '+1 구출!', '#7cc66a', 1.2); api.buzz(20); }
          else if (seek) setBanner('철컥!', '누군가 새장을 열었어요', '#ffb3a8', 1.3);
          break;
        }
        case 8: {
          sfx('chip'); api.buzz(20);
          if (mine || sp) setBanner('등불 ' + b + '/' + NEED, b >= NEED ? '' : seek ? '생존자들이 등불을 켰어요' : '등불이 켜졌어요!', '#ffe9a8', 1.4);
          break;
        }
        case 9: case 30: {
          sfx('whoosh'); api.buzz(50);
          const s0 = code === 30 ? '새벽이 다가와요!' : '대문에 불이 들어왔어요!';
          setBanner(s0, seek ? '대문을 지켜요! ' + Math.round(W.col || (code === 30 ? DAWN_COL : COLLAPSE_T)) + '초 뒤 새벽' : '대문으로 가서 「대문 열기」 → 탈출!', '#7cc66a', 2.2);
          break;
        }
        case 10: sfx('pop'); addFloat(x, y - 0.6, '대문 열림!', '#7cc66a', 1.4); break;
        case 11: { sfx('whoosh'); setBanner('비밀 통로가 열렸어요!', seek ? '찾아서 「닫기」 하면 막을 수 있어요' : '마지막 한 명! 파란 소용돌이로 가요', '#9ad0ff', 2); break; }
        case 12: setBanner('비밀 통로가 닫혔어요!', seek ? '' : '대문으로 가요!', '#ffb3a8', 1.6); break;
        case 13: { sfx('thud'); if (b) { if (seek) { setBanner('쾅! 기절', '책장에 깔렸어요', '#ee6a55', 1.2); api.buzz(80); shake = 0.6; } else addFloat(x, y - 0.6, '쾅! 살인마 기절', '#7cc66a', 1.2); } else addFloat(x, y - 0.6, '쿵!', '#ffd27a', 0.9); break; }
        case 14: sfx('thud'); if (sp || seek || (mp && hyp(x - mp.x, y - mp.y) < 8)) addFloat(x, y - 0.6, '와장창', '#c9bfd8', 1); break;
        case 15: if (sp || seek) { addFloat(x, y - 0.6, '텅 비었네', '#c9bfd8', 1); sfx('click', 80); } break;
        case 16: if (sp || seek || (mp && hyp(x - mp.x, y - mp.y) < 9)) addFloat(x, y - 0.6, '망가뜨림!', '#ee6a55', 1.1); break;
        case 17: if (a === m && mine) { addFloat(x, y - 0.8, b === 2 ? '완벽해요!' : b === 1 ? '좋아요' : '실수!', b === 2 ? '#7cc66a' : b === 1 ? '#f2e9d8' : '#ee6a55', 0.9); sfx(b ? 'tick' : 'thud', 40); } break;
        case 18: if (a === m) addFloat(x, y - 0.6, '덫 설치', '#e3ae45', 0.9); break;
        case 19: { sfx('click'); if (a === m && mine) { setBanner('끈끈이에 걸렸어요!', '잠깐 못 움직여요 · 위치가 들켰어요', '#ee6a55', 1.4); api.buzz(60); } else if (seek) setBanner('덫에 걸렸다!', name(a), '#e3ae45', 1.2); break; }
        case 20: if (a === m) addFloat(x, y - 0.6, '거울 세움', '#d9c4ff', 0.9); break;
        case 21: sfx('whoosh'); if (a === m) shake = 0.3; break;
        case 22: { sfx('whoosh'); if (seek) addFloat(x, y - 0.8, '초음파! ' + b + '명', '#ffb3a8', 1.2); else if (mp && !mp.sk && mp.rv > 0) setBanner('초음파에 들켰어요!', '움직이면 3초 동안 보여요', '#ffb3a8', 1.2); ripples.push({ x, y, k: 99, t: 0 }); break; }
        case 23: { if (b) { sfx('pop'); if (seek) { setBanner('눈부셔!', '2초 동안 손전등이 꺼져요', '#ffe9a8', 1.3); shake = 0.3; } else if (a === m) addFloat(x, y - 0.8, '반짝!', '#ffe9a8', 1); } else if (a === m) addFloat(x, y - 0.8, '너무 멀어요', '#c9bfd8', 0.9); break; }
        case 24: if (a === m && mine) { setBanner('열쇠를 주웠어요!', '잠긴 문으로 가면 열려요', '#ffe9a8', 1.6); sfx('chip'); } break;
        case 25: sfx('pop'); addFloat(x, y - 0.6, '문 열림!', '#ffe9a8', 1.2); break;
        case 26: { sfx('roll'); api.buzz(30); setBanner(W.M.th === 4 ? '딩동댕~ 종소리!' : '댕~ 괘종시계!', '2초 동안 모두의 위치가 보여요', '#ffe9a8', 1.6); break; }
        case 27: {
          sfx('whoosh'); api.buzz(30);
          if (seek) setBanner('찾으러 가자!', '빛을 1초 비추면 깜짝 · 두 번째엔 새장', '#e3ae45', 1.8);
          else if (mine && mp.st === 0) setBanner('살인마가 움직여요!', '빛을 피해 등불을 고쳐요', '#bfe3ff', 1.8);
          break;
        }
        case 28: if (a === m) addFloat(x, y - 0.8, '질주!', '#ffe9a8', 0.9); break;
        case 29: if (a === m && mine) addFloat(x, y - 0.8, '다 나았다!', '#7cc66a', 1.1); else if (b === m) addFloat(x, y - 0.8, '+치료', '#7cc66a', 1); break;
        case 32: if (a === m && mine) setBanner('쏙 빠져나왔다!', '숨기 달인 · 한 번뿐이에요', '#7cc66a', 1.5); else if (seek) addFloat(x, y - 0.6, '빠져나갔다!', '#ee6a55', 1.2); break;
        case 33: if (mp && hyp(x - mp.x, y - mp.y) < 8) sfx('whoosh', 120); break;
        case 34: if (mp && hyp(x - mp.x, y - mp.y) < 6) sfx('tick', 100); break;
        case 35: if (a === m) sfx('whoosh'); break;
        case 36: sfx('click', 60); if (sp || (mp && hyp(x - mp.x, y - mp.y) < 8)) addFloat(x, y - 0.6, b ? '불 켜짐!' : '불 꺼짐', b ? '#ffe9a8' : '#c9bfd8', 1); break;
        case 38: if (a === m) addFloat(x, y - 0.6, '자명종!', '#ffe9a8', 0.9); break;
        case 40: {
          sfx('lose', 200);
          if (seek) setBanner('모두 가뒀다!', '남은 생존자가 모두 새장에 갇혔어요', '#e3ae45', 2.2);
          else setBanner('모두 갇혔어요…', '새장에 남은 생존자는 탈락이에요', '#ffb3a8', 2.2);
          break;
        }
        case 42: { sfx('whoosh'); api.buzz(20); setBanner('울타리가 움직여요!', HEDGE_WARN + '초 뒤 길이 바뀌어요 · 반짝이는 울타리를 피해요', '#b8f0a8', 1.8); break; }
        case 43: {
          sfx('chip', 40); api.buzz(30);
          if (seek) { setBanner('딸랑! 방울 줄', '비틀! 생존자들에게 3초 동안 보여요', '#ee6a55', 1.4); shake = 0.4; }
          else setBanner('딸랑!', (a === m ? '내 방울에 걸렸어요! ' : '') + '살인마 위치가 보여요', '#ffe9a8', 1.4);
          break;
        }
        case 44: { sfx('thud'); if (seek) { setBanner('쾅!', '벽에 박아서 어질어질', '#ee6a55', 1.1); shake = 0.8; api.buzz(90); } else if (mp && hyp(x - mp.x, y - mp.y) < 9) addFloat(x, y - 0.6, '쾅!', '#ffd27a', 0.9); break; }
        case 45: if (seek) { addFloat(x, y - 0.8, '숨죽이기…', '#c9b8ff', 1); sfx('whoosh'); } break;
        case 46: { if (seek) { sfx('whoosh'); api.buzz(25); } else if (mp && hyp(x - mp.x, y - mp.y) < 8) { addFloat(x, y - 0.8, '돌진!', '#ee6a55', 0.9); sfx('whoosh', 120); } break; }
        case 47: if (seek) { sfx('whoosh'); addFloat(x, y - 0.8, '킁킁! ' + b + '명', '#ffb3a8', 1.2); } else if (mp && !mp.sk && mp.rv > 0) setBanner('냄새를 맡았어요!', '3초 동안 살인마에게 보여요', '#ffb3a8', 1.2); break;
        case 48: { sfx('whoosh', 80); if (a === m) addFloat(x, y - 0.8, '연막!', '#d8d8e8', 1); else if (mp && hyp(x - mp.x, y - mp.y) < 9) addFloat(x, y - 0.8, '펑! 연기', '#d8d8e8', 1); break; }
        case 49: if (a === m) { addFloat(x, y - 0.6, '방울 설치', '#ffe9a8', 0.9); sfx('click'); } break;
      }
    }
    const hooks = { fx: onFx };

    /* ----- host flow ----- */
    const remIn = {};
    const newRem = () => ({ ax: 0, ay: 0, rn: 0, sn: 0, aa: null, act: 0, sk: 0, tr: 0, ck: null, wk: null, ai: 0, h: -1, u: -1, lck: 0 });
    function inputsFor(dt) {
      const out = [];
      for (let s = 0; s < W.pl.length; s++) {
        if (isAIseat(s)) out[s] = aiThink(W, W.pl[s], aiMem[s] || (aiMem[s] = {}), P(s).ai ? lvOf(s) : 2, dt);
        else if (localHuman(s)) out[s] = locIn;
        else out[s] = remIn[s] || (remIn[s] = newRem());
      }
      return out;
    }
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'pick') {
        let ch = null;
        for (let s = 0; s < st.np; s++) if (st.ch[s] < 0 && isAIseat(s)) { ch = ch || st.ch.slice(); ch[s] = U.rand(s === st.sk ? SEEKERS.length : KIDS.length); }
        if (api.online) {
          let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
          if (rem && typeof rem === 'object') for (const k in rem) {
            const s = +k, o = rem[k];
            if (!(s >= 0 && s < st.np) || isAIseat(s) || localHuman(s) || !o || o.k !== key || !fin(o.pk)) continue;
            const c = o.pk | 0; if (c < 0 || c >= (s === st.sk ? SEEKERS.length : KIDS.length)) continue;
            if ((ch || st.ch)[s] !== c) { ch = ch || st.ch.slice(); ch[s] = c; }
          }
        }
        if (ch) { api.setState(Object.assign({}, st, { ch })); return; }
        pickT -= dt;
        if (st.ch.every((c) => c >= 0)) pickT = Math.min(pickT, auto() ? 0.3 : 1.6);
        if (pickT <= 0) { pickT = 1e9; api.setState(startPlay(st)); }
        return;
      }
      if (st.ph === 'play' && W && W.res && !W.res.sent) { W.res.sent = 1; api.setState(roundOver(st, roundRows(W))); return; }
      if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextRound(st)); } }
    }

    /* ----- online ----- */
    let pubT = 0, hsQ = 0, lastQ = -1, lastSig = '', inT = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.pl.length) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remIn[s] || (remIn[s] = newRem());
        R.ax = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0; R.ay = fin(+o.ay) ? clamp(+o.ay, -1, 1) : 0;
        R.rn = o.rn ? 1 : 0; R.sn = o.sn ? 1 : 0;
        R.aa = fin(o.aa) ? clamp(+o.aa, -4, 4) : null;
        const h = o.h | 0, u = o.u | 0;
        if ((R.h >= 0 && h !== R.h) || (R.h < 0 && h > 0)) R.act = 1;
        if ((R.u >= 0 && u !== R.u) || (R.u < 0 && u > 0)) R.sk = 1;
        R.h = h; R.u = u;
        if (Array.isArray(o.ck) && (o.ck[0] | 0) !== R.lck) { R.lck = o.ck[0] | 0; R.ck = [o.ck[0] | 0, clamp(o.ck[1] | 0, 0, 2)]; }
      }
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ) return;
      lastQ = hs.q;
      if (st.ph === 'pick') { if (fin(hs.pt)) ptGuest = { v: hs.pt, at: performance.now() }; return; }
      if (!Array.isArray(hs.P)) return;
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; try { onFx(e[1] | 0, (+e[2] || 0) / 10, (+e[3] || 0) / 10, e[4] | 0, e[5] | 0); } catch (er) {} }
      const m = auto() ? -1 : me();
      try { applySnap(W, hs, m); } catch (er) { console.error(er); }
      lampCache = null;
      const p = myP(); if (p && p.chk && !p.chk.seen) p.chk.seen = performance.now();
    }
    function guestStep(dt, rdt) {
      const m = auto() ? -1 : me();
      const k = 1 - Math.exp(-rdt * 12);
      W.t += dt; syncHedge(W);
      W.pl.forEach((p, i) => {
        if (!fin(p.nx)) return;
        if (i === m && p.st === 0 && p.hid < 0 && !p.job && !p.vt && !p.ride && !(p.stun > 0)) {
          movePl(W, p, locIn, dt);
          const kk = 1 - Math.exp(-rdt * 4);
          p.x += (p.nx - p.x) * kk; p.y += (p.ny - p.y) * kk;
          return;
        }
        p.x += (p.nx - p.x) * k; p.y += (p.ny - p.y) * k;
        if (fin(p.na)) p.a = wrapA(p.a + wrapA(p.na - p.a) * k);
      });
    }
    function publish(rdt) {
      if (!api.online || !W || !st) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          if (st.ph === 'pick') { pubT = 0.5; hsQ = (hsQ + 1) % 100000; api.net.hostSend({ k: key, q: hsQ, pt: Math.round(pickT * 10) / 10 }); return; }
          if (st.ph !== 'play') return;
          pubT = 1 / 15;
          hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(snapshot(W, key, hsQ));
        } else {
          const m = me(); if (m < 0) return;
          if (st.ph === 'pick') { if (pubT > 0) return; pubT = 0.4; api.net.publish({ k: key, pk: myPick }); return; }
          const aa = fin(locIn.aa) ? Math.round(locIn.aa * 100) / 100 : null;
          const ax = Math.round(locIn.ax * 100) / 100, ay = Math.round(locIn.ay * 100) / 100;
          const sig = [ax, ay, locIn.rn, locIn.sn, aa, netA.h, netA.u, netA.ck ? netA.ck[0] : 0].join('|');
          if (sig === lastSig && inT > 0) return;
          if (pubT > 0) return;
          lastSig = sig; inT = 0.25; pubT = 1 / 20;
          api.net.publish({ k: key, ax, ay, rn: locIn.rn, sn: locIn.sn, aa, h: netA.h, u: netA.u, ck: netA.ck });
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      if (curKey() !== key) startRound();
      if (!W) return;
      const dt = rdt * SPD();
      readInput(now);
      if (host()) {
        pollHost();
        if (st.ph === 'play' && !W.res) {
          const I = inputsFor(dt);
          tickWorld(W, Math.min(dt, 0.25), I, hooks);
          locIn.act = 0; locIn.sk = 0; locIn.ck = null;
          for (const k in remIn) { remIn[k].act = 0; remIn[k].sk = 0; remIn[k].ck = null; }
        }
        hostFlow(dt);
      } else {
        pollGuest();
        if (st.ph === 'play') guestStep(Math.min(dt, 0.1), rdt);
      }
      if (lay && spect() !== lay.sp) { lay = null; layout(); }
      if (lay) { const p = myP(), ctl = ctrlOn() && !lay.sp && p && p.st === 0; if ((ctl ? 150 : 10) !== lay.bot) { lay = null; layout(); } }
      const tg = camTarget(), ck = 1 - Math.exp(-rdt * 9);
      cam.x += (tg.x - cam.x) * ck; cam.y += (tg.y - cam.y) * ck;
      for (let i = ripples.length - 1; i >= 0; i--) { ripples[i].t += rdt; if (ripples[i].t > 1.4) ripples.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t += rdt; if (floats[i].t > floats[i].life) floats.splice(i, 1); }
      for (let i = ghosts.length - 1; i >= 0; i--) { ghosts[i].t += rdt; if (ghosts[i].t > 1.6) ghosts.splice(i, 1); }
      if (banner) { banner.life -= rdt; if (banner.life <= 0) banner = null; }
      if (tipT > 0) tipT -= rdt;
      shake = Math.max(0, shake - rdt * 2.5);
      if (st.ph === 'play' && W.go) { // footprints (snow · the scent hunter's nose) are made from positions, so guests see them too
        prT -= rdt;
        if (prT <= 0) {
          prT = 0.22; const t = performance.now() / 1000, M = W.M, nose = seekerOf(W).c === S_NOSE;
          for (const q of W.pl) {
            if (q.sk || q.st !== 0 || q.hid >= 0 || q.ride || q.vt) { prLast[q.i] = null; continue; }
            const l = prLast[q.i];
            if (!l) { prLast[q.i] = { x: q.x, y: q.y, f: 0 }; continue; }
            const d = hyp(q.x - l.x, q.y - l.y); if (d < 0.42) continue;
            const sn = !!M.gm.snow && M.c[tileAt(M, q.x, q.y)] === ',' && q.c !== K_SOMI, sc = nose && q.rn;
            if (sn || sc) { prints.push({ x: q.x, y: q.y, a: Math.atan2(q.y - l.y, q.x - l.x), t, sn, sc, f: l.f }); if (prints.length > 180) prints.shift(); }
            prLast[q.i] = { x: q.x, y: q.y, f: 1 - l.f };
          }
          while (prints.length && t - prints[0].t > 9) prints.shift();
        }
      }
      const p = myP();
      if (p && p.st === 0 && !p.sk && !auto() && st.ph === 'play' && W.go) { // heartbeat buzz
        const S = seekerOf(W), d = S.cl > 0 ? 99 : hyp(S.x - p.x, S.y - p.y);
        const danger = p.ex > 0.05 ? 1 : d < TR * 0.5 ? 0.6 : 0;
        if (danger) { hb -= rdt * (danger > 0.8 ? 2.6 : 1.4); if (hb <= 0) { hb = 1; api.buzz(danger > 0.8 ? 25 : 10); } }
      }
      publish(rdt);
    }
    /* ----- drawing ----- */
    const beamPts = [], nvPts = [];
    let lampCache = null;
    function rayFan(x, y, a0, span, n, R, out) {
      out.length = 0;
      for (let i = 0; i <= n; i++) {
        const a = a0 - span / 2 + span * i / n, dx = Math.cos(a), dy = Math.sin(a);
        const d = castRay(W, x, y, dx, dy, R);
        out.push(x + dx * d, y + dy * d);
      }
      return out;
    }
    function polyPath(c, pts, x, y, full) {
      c.beginPath();
      if (!full) c.moveTo(x, y);
      for (let i = 0; i < pts.length; i += 2) { if (full && i === 0) c.moveTo(pts[0], pts[1]); else c.lineTo(pts[i], pts[i + 1]); }
      c.closePath();
    }
    function txt(t, x, y, col, font, al, stroke) {
      ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle';
      if (stroke) { ctx.lineWidth = stroke; ctx.strokeStyle = 'rgba(12,8,22,.9)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y); }
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function inX(t, x, font) { ctx.font = font; const hw = ctx.measureText(t).width / 2 + 4; return clamp(x, hw, lay.w - hw); }
    function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
    const onScr = (x, y, m) => x > -m && y > -m && x < lay.w + m && y < lay.h + m;
    function beamVisibleTo(v, S) {
      if (!beamOn(S) || !W.go) return false;
      if (!v || v === S) return true;
      if (los(W, v.x, v.y, S.x, S.y)) return true;
      const d = castRay(W, S.x, S.y, Math.cos(S.a), Math.sin(S.a), RANGE);
      for (const f of [0.4, 0.75, 0.97]) { const px = S.x + Math.cos(S.a) * d * f, py = S.y + Math.sin(S.a) * d * f; if (los(W, v.x, v.y, px, py)) return true; }
      return false;
    }
    function drawBody(q, now, aur) {
      const s = lay.ts, x = SX(q.x), y = SY(q.y);
      let r = (q.sk ? 0.42 : 0.34) * s;
      if (q.vt && !(q.vt.g)) { const k = q.vt.t / q.vt.T; r *= 1 + Math.sin(Math.PI * clamp(k, 0, 1)) * 0.3; }
      if (aur) {
        ctx.save(); ctx.strokeStyle = q.sk ? '#ff8a7a' : COL(q.i); ctx.lineWidth = 2.5; ctx.setLineDash([5, 4]);
        ctx.beginPath(); ctx.arc(x, y, r * 1.05, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
        ctx.globalAlpha = 0.35; ctx.fillStyle = q.sk ? '#ff8a7a' : COL(q.i); ctx.fill(); ctx.restore();
        return;
      }
      if (q.sk && q.chg > 0) { // speed lines
        ctx.save(); ctx.strokeStyle = 'rgba(255,200,150,.6)'; ctx.lineWidth = 2;
        for (let k = -1; k <= 1; k++) { const ox = -Math.sin(q.a) * k * r * 0.6, oy = Math.cos(q.a) * k * r * 0.6; ctx.beginPath(); ctx.moveTo(x + ox - Math.cos(q.a) * r * 1.2, y + oy - Math.sin(q.a) * r * 1.2); ctx.lineTo(x + ox - Math.cos(q.a) * r * 2.4, y + oy - Math.sin(q.a) * r * 2.4); ctx.stroke(); }
        ctx.restore();
      }
      drawChar(ctx, x, y, r, !!q.sk, q.c, COL(q.i), q.a, { beam: q.sk && beamOn(q) && W.go, t: now / 1000, scared: !q.sk && q.hp === 1, alpha: q.sk && q.cl > 0 ? 0.45 : null });
      if (q.ex > 0.01 && q.st === 0) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = Math.max(2.5, s * 0.08); ctx.beginPath(); ctx.arc(x, y, r * 1.45, -Math.PI / 2, -Math.PI / 2 + TAU * Math.min(1, q.ex / beamT(q))); ctx.stroke(); }
      if (q.stun > 0 || q.blind > 0) { ctx.fillStyle = '#ffe36a'; for (let k = 0; k < 3; k++) { const a = now / 250 + k * TAU / 3; ctx.beginPath(); ctx.arc(x + Math.cos(a) * r * 0.9, y - r * 1.1 + Math.sin(a) * r * 0.3, Math.max(2, r * 0.14), 0, TAU); ctx.fill(); } }
      if (q.key) { ctx.fillStyle = '#ffd86a'; ctx.beginPath(); ctx.arc(x + r * 0.9, y - r * 0.9, Math.max(3, r * 0.22), 0, TAU); ctx.fill(); }
      if (q.job && !q.sk && (q.job.k === 1 || q.job.k === 2 || q.job.k === 3 || q.job.k === 4)) { // working hands
        const t = now / 120; ctx.fillStyle = '#ffe9a8'; ctx.beginPath(); ctx.arc(x + Math.cos(q.a) * r * 1.1 + Math.sin(t) * 2, y + Math.sin(q.a) * r * 1.1, Math.max(2, r * 0.16), 0, TAU); ctx.fill();
      }
      if (q.job && q.sk) { const pr = q.job.pp != null ? q.job.pp : clamp(q.job.p / jobT(q.job.k), 0, 1); ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, r * 1.35, -Math.PI / 2, -Math.PI / 2 + TAU * pr); ctx.stroke(); }
    }
    function drawPeek(q, now, mine) { // a kid inside a hiding spot: two eyes in the dark
      const s = lay.ts, o = W.M.spots[q.hid], x = SX(o.x), y = SY(o.y);
      const blink = Math.sin(now / 900 + q.i * 3) > 0.95;
      ctx.save();
      ctx.strokeStyle = mine ? hexA(COL(q.i), 0.95) : 'rgba(242,233,216,.7)'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]);
      ctx.strokeRect(x - s * 0.5 + 1, y - s * 0.5 + 1, s - 2, s - 2); ctx.setLineDash([]);
      ctx.fillStyle = '#fff';
      if (blink) { ctx.fillRect(x - s * 0.2, y - 1, s * 0.14, 2); ctx.fillRect(x + s * 0.06, y - 1, s * 0.14, 2); }
      else {
        ctx.beginPath(); ctx.arc(x - s * 0.13, y, s * 0.08, 0, TAU); ctx.arc(x + s * 0.13, y, s * 0.08, 0, TAU); ctx.fill();
        ctx.fillStyle = '#1b1226'; ctx.beginPath(); ctx.arc(x - s * 0.12, y + 1, s * 0.04, 0, TAU); ctx.arc(x + s * 0.14, y + 1, s * 0.04, 0, TAU); ctx.fill();
      }
      ctx.restore();
    }
    function drawLantern(x, y, s, o, now) {
      ctx.fillStyle = '#3a2a1a'; ctx.fillRect(x - s * 0.08, y - s * 0.1, s * 0.16, s * 0.5);
      ctx.fillStyle = '#5a4a3a'; ctx.fillRect(x - s * 0.26, y + s * 0.32, s * 0.52, s * 0.1);
      const lit = o.lit, glow = lit ? 1 : o.p;
      ctx.fillStyle = lit ? '#ffe28a' : 'rgba(' + (90 + glow * 120 | 0) + ',' + (70 + glow * 90 | 0) + ',40,1)';
      ctx.strokeStyle = '#2a1a0a'; ctx.lineWidth = Math.max(1, s * 0.05);
      ctx.beginPath(); ctx.moveTo(x - s * 0.2, y - s * 0.12); ctx.lineTo(x + s * 0.2, y - s * 0.12); ctx.lineTo(x + s * 0.15, y - s * 0.42); ctx.lineTo(x - s * 0.15, y - s * 0.42); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#2a1a0a'; ctx.fillRect(x - s * 0.18, y - s * 0.48, s * 0.36, s * 0.07);
      if (!lit && o.n > 0) { ctx.fillStyle = 'rgba(255,230,140,' + (0.4 + 0.3 * Math.sin(now / 90)) + ')'; ctx.beginPath(); ctx.arc(x, y - s * 0.27, s * 0.07, 0, TAU); ctx.fill(); }
    }
    function drawDynamic(now, sp, p) {
      const M = W.M, s = lay.ts, m = s * 1.5;
      for (let j = 0; j < M.pals.length; j++) {
        const o = M.pals[j], x = SX(o.x), y = SY(o.y), v = W.pal[j];
        if (!onScr(x, y, m)) continue;
        ctx.save(); ctx.translate(x, y); if (o.ax === 1) ctx.rotate(Math.PI / 2);
        if (v === 0) { // a shelf standing by the doorway (leaning on the wall)
          ctx.fillStyle = '#5a3a20'; ctx.fillRect(-s * 0.48, -s * 0.5, s * 0.96, s * 0.24);
          const cols = ['#c94f4f', '#4f7fc9', '#d9b04a', '#5fa86a'];
          for (let k = 0; k < 6; k++) { ctx.fillStyle = cols[(k + j) % 4]; ctx.fillRect(-s * 0.42 + k * s * 0.14, -s * 0.46, s * 0.1, s * 0.16); }
          ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = 1.2; ctx.setLineDash([3, 3]); ctx.strokeRect(-s * 0.48, -s * 0.5, s * 0.96, s); ctx.setLineDash([]);
        } else if (v === 1) { // fallen across the doorway
          ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(-s * 0.2, -s * 0.46, s * 0.46, s * 0.98);
          ctx.fillStyle = '#6a4426'; ctx.fillRect(-s * 0.24, -s * 0.5, s * 0.48, s);
          ctx.fillStyle = '#8a5a32'; ctx.fillRect(-s * 0.2, -s * 0.46, s * 0.4, s * 0.92);
          ctx.strokeStyle = '#3a2210'; ctx.lineWidth = Math.max(1, s * 0.04); for (let k = 1; k < 4; k++) { ctx.beginPath(); ctx.moveTo(-s * 0.2, -s * 0.46 + k * s * 0.23); ctx.lineTo(s * 0.2, -s * 0.46 + k * s * 0.23); ctx.stroke(); }
        } else { // broken
          ctx.fillStyle = '#6a4426';
          for (let k = 0; k < 5; k++) { ctx.save(); ctx.rotate(k * 1.3 + j); ctx.fillRect(s * 0.12 * (k - 2), -s * 0.04, s * 0.22, s * 0.08); ctx.restore(); }
        }
        ctx.restore();
      }
      for (let j = 0; j < M.doors.length; j++) {
        const o = M.doors[j], x = SX(o.x), y = SY(o.y); if (!onScr(x, y, m)) continue;
        if (W.door[j]) {
          ctx.fillStyle = '#6a3f22'; ctx.fillRect(x - s / 2, y - s / 2, s, s);
          ctx.strokeStyle = '#3a200e'; ctx.lineWidth = Math.max(1, s * 0.05); ctx.strokeRect(x - s * 0.45, y - s * 0.45, s * 0.9, s * 0.9);
          ctx.fillStyle = '#ffd86a'; ctx.beginPath(); ctx.arc(x, y - s * 0.05, s * 0.12, Math.PI, 0); ctx.fill(); ctx.fillRect(x - s * 0.15, y - s * 0.05, s * 0.3, s * 0.24);
        } else { ctx.fillStyle = 'rgba(106,63,34,.8)'; ctx.fillRect(x - s / 2, y - s / 2, s * 0.12, s); }
      }
      for (let j = 0; j < M.gates.length; j++) {
        const o = M.gates[j], x = SX(o.x), y = SY(o.y); if (!onScr(x, y, m)) continue;
        const g = W.gate[j];
        ctx.fillStyle = g.open ? '#16301c' : '#2a2a34'; ctx.fillRect(x - s / 2, y - s / 2, s, s);
        ctx.strokeStyle = W.pw ? '#7cc66a' : '#8a8a9a'; ctx.lineWidth = Math.max(1.5, s * 0.07);
        const hor = o.dy !== 0;
        if (!g.open) for (let k = 1; k < 5; k++) { ctx.beginPath(); if (hor) { ctx.moveTo(x - s / 2 + k * s / 5, y - s / 2); ctx.lineTo(x - s / 2 + k * s / 5, y + s / 2); } else { ctx.moveTo(x - s / 2, y - s / 2 + k * s / 5); ctx.lineTo(x + s / 2, y - s / 2 + k * s / 5); } ctx.stroke(); }
        else { ctx.fillStyle = 'rgba(124,198,106,.45)'; ctx.fillRect(x - s / 2, y - s / 2, s, s); }
        if (W.pw) { ctx.fillStyle = '#7cc66a'; ctx.beginPath(); ctx.arc(x + o.dx * -s * 0.6, y + o.dy * -s * 0.6, s * 0.1, 0, TAU); ctx.fill(); }
      }
      for (let j = 0; j < M.lans.length; j++) { const o = M.lans[j], x = SX(o.x), y = SY(o.y); if (onScr(x, y, m)) drawLantern(x, y, s, W.lan[j], now); }
      if (M.hedge.length) { // moving hedges: tall and leafy when shut, a low trimmed ring when open; they shiver before they move
        const T = M.gm.hedge, left = W.go ? T - ((W.t - START_T) % T) : 99, warn = left < HEDGE_WARN;
        for (const o of M.hedge) {
          const x = SX(o.x), y = SY(o.y); if (!onScr(x, y, m)) continue;
          const shut = W.sol[o.i] === 1, wob = warn ? Math.sin(now / 40 + o.i) * s * 0.04 : 0;
          if (shut) {
            ctx.fillStyle = '#163a18'; ctx.fillRect(x - s / 2 + wob, y - s / 2, s, s);
            ctx.fillStyle = '#2a5a26'; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.arc(x - s * 0.22 + (k % 2) * s * 0.44 + wob, y - s * 0.22 + (k >> 1) * s * 0.44, s * 0.3, 0, TAU); ctx.fill(); }
            ctx.fillStyle = '#3e7a36'; ctx.beginPath(); ctx.arc(x - s * 0.18 + wob, y - s * 0.2, s * 0.14, 0, TAU); ctx.fill();
          } else { ctx.strokeStyle = 'rgba(70,130,60,.85)'; ctx.lineWidth = Math.max(1.5, s * 0.08); ctx.setLineDash([3, 3]); ctx.strokeRect(x - s * 0.42, y - s * 0.42, s * 0.84, s * 0.84); ctx.setLineDash([]); }
          if (warn) { ctx.strokeStyle = 'rgba(200,255,160,' + (0.5 + 0.4 * Math.sin(now / 90)) + ')'; ctx.lineWidth = 2; ctx.strokeRect(x - s / 2 + 1, y - s / 2 + 1, s - 2, s - 2); }
        }
      }
      for (let j = 0; j < M.cages.length; j++) {
        const o = M.cages[j], x = SX(o.x), y = SY(o.y); if (!onScr(x, y, m)) continue;
        const who = W.cage[j];
        if (who >= 0) { const q = W.pl[who]; drawChar(ctx, x, y, s * 0.28, false, q.c, COL(who), Math.PI / 2 + Math.sin(now / 300 + who) * 0.6, { noShadow: 1, scared: 1, t: now / 1000 }); }
        ctx.strokeStyle = '#c9b8d8'; ctx.lineWidth = Math.max(1.2, s * 0.045);
        for (let k = 0; k < 7; k++) { const xx = x - s * 0.38 + k * s * 0.127; const hh = Math.sqrt(Math.max(0, 0.42 * 0.42 - Math.pow((xx - x) / s, 2))) * s; ctx.beginPath(); ctx.moveTo(xx, y - hh); ctx.lineTo(xx, y + hh); ctx.stroke(); }
        ctx.beginPath(); ctx.arc(x, y, s * 0.42, 0, TAU); ctx.stroke();
        ctx.fillStyle = '#c9b8d8'; ctx.beginPath(); ctx.arc(x, y - s * 0.46, s * 0.07, 0, TAU); ctx.fill();
      }
      if (W.hop === 1 && W.hatch >= 0) {
        const o = M.hatches[W.hatch], x = SX(o.x), y = SY(o.y);
        if (onScr(x, y, m)) { ctx.save(); ctx.translate(x, y); ctx.rotate(now / 400); ctx.strokeStyle = '#9ad0ff'; ctx.lineWidth = 3; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(0, 0, s * (0.15 + k * 0.12), k * 2, k * 2 + 4); ctx.stroke(); } ctx.restore(); }
      }
      if (!p || !p.sk || sp) for (const k of W.keys) { const o = M.keys[k], x = SX(o.x), y = SY(o.y); if (!onScr(x, y, m)) continue; ctx.fillStyle = '#ffd86a'; ctx.beginPath(); ctx.arc(x - s * 0.12, y, s * 0.13, 0, TAU); ctx.fill(); ctx.fillRect(x - s * 0.02, y - s * 0.04, s * 0.3, s * 0.08); ctx.fillRect(x + s * 0.18, y, s * 0.06, s * 0.12); }
      for (let j = 0; j < M.crows.length; j++) {
        if (W.crow[j] > 0) continue;
        const o = M.crows[j], x = SX(o.x), y = SY(o.y); if (!onScr(x, y, m)) continue;
        for (let k = 0; k < 3; k++) { const cx = x + (k - 1) * s * 0.28, cy = y + (k % 2) * s * 0.15; ctx.fillStyle = '#141018'; ctx.beginPath(); ctx.ellipse(cx, cy, s * 0.13, s * 0.09, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#e3ae45'; ctx.fillRect(cx + s * 0.1, cy - s * 0.02, s * 0.07, s * 0.04); }
      }
      for (const o of W.toys) { const x = SX(o.x), y = SY(o.y); ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.arc(x, y, s * 0.14, 0, TAU); ctx.fill(); ctx.fillStyle = '#ffe9a8'; ctx.fillRect(x - s * 0.03, y + s * 0.1, s * 0.06, s * 0.22); }
      if (W.mir && (sp || (p && p.sk))) { const x = SX(W.mir.x), y = SY(W.mir.y); ctx.fillStyle = '#7a5a9a'; ctx.beginPath(); ctx.ellipse(x, y, s * 0.24, s * 0.34, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#dfe8ff'; ctx.beginPath(); ctx.ellipse(x, y, s * 0.17, s * 0.26, 0, 0, TAU); ctx.fill(); }
      else if (W.mir && p) { if (hyp(W.mir.x - p.x, W.mir.y - p.y) < nvOf(p) + 0.5) { const x = SX(W.mir.x), y = SY(W.mir.y); ctx.fillStyle = '#dfe8ff'; ctx.beginPath(); ctx.ellipse(x, y, s * 0.17, s * 0.26, 0, 0, TAU); ctx.fill(); } }
      for (const o of W.traps) {
        const seeIt = sp || (p && p.sk) || (p && hyp(o.x - p.x, o.y - p.y) < 1.7);
        if (!seeIt) continue;
        const x = SX(o.x), y = SY(o.y);
        ctx.fillStyle = 'rgba(150,220,120,.75)'; ctx.beginPath(); ctx.arc(x, y, s * 0.3, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(40,80,30,.9)'; ctx.lineWidth = 1.5; for (let k = 0; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(k * 1.6) * s * 0.3, y + Math.sin(k * 1.6) * s * 0.3); ctx.stroke(); }
      }
    }
    function drawMarkers(now, sp, p) { // what everyone "knows" about the map, drawn over the darkness
      const M = W.M, s = lay.ts, kid = p && !p.sk;
      for (let j = 0; j < M.lans.length; j++) {
        const o = M.lans[j], L0 = W.lan[j], x = SX(o.x), y = SY(o.y) - s * 0.25; if (!onScr(x, y, 20)) continue;
        const r = Math.max(6, s * 0.2);
        ctx.save(); ctx.globalAlpha = L0.lit ? 0.95 : 0.8;
        ctx.fillStyle = L0.lit ? '#ffe28a' : 'rgba(30,22,40,.85)'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(242,233,216,.5)'; ctx.lineWidth = 1.5; ctx.stroke();
        if (!L0.lit && L0.p > 0.005) { ctx.strokeStyle = L0.kick ? '#ee6a55' : '#ffd86a'; ctx.lineWidth = Math.max(2.5, r * 0.4); ctx.beginPath(); ctx.arc(x, y, r * 0.95, -Math.PI / 2, -Math.PI / 2 + TAU * L0.p); ctx.stroke(); }
        ctx.restore();
      }
      if (kid || sp || (p && p.sk)) for (const q of W.pl) {
        if (q.st !== 2) continue;
        const x = SX(q.x), y = SY(q.y); if (!onScr(x, y, 30)) continue;
        txt(Math.max(0, Math.ceil(q.ct)) + '초', x, y - s * 0.75, q.ct < 10 ? '#ee6a55' : '#ffb3a8', '700 12px ' + MONO, 'center', 3);
        ctx.strokeStyle = 'rgba(238,106,85,' + (0.5 + 0.3 * Math.sin(now / 200)) + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, s * 0.55, 0, TAU); ctx.stroke();
      }
      if (W.pw) for (let j = 0; j < M.gates.length; j++) {
        const o = M.gates[j], g = W.gate[j], x = SX(o.ix), y = SY(o.iy); if (!onScr(x, y, 30)) continue;
        ctx.strokeStyle = '#7cc66a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, s * 0.5, -Math.PI / 2, -Math.PI / 2 + TAU * (g.open ? 1 : Math.max(0.02, g.p))); ctx.stroke();
        txt(g.open ? '출구!' : '대문 ' + Math.floor(g.p * 100) + '%', x, y - s * 0.8, '#b8f0a8', '700 11px ' + FONT, 'center', 3);
      }
      if (W.hop === 1 && W.hatch >= 0 && (kid || sp || (p && p.sk))) { const o = M.hatches[W.hatch], x = SX(o.x), y = SY(o.y); if (onScr(x, y, 30)) txt('비밀 통로', x, y - s * 0.7, '#9ad0ff', '700 11px ' + FONT, 'center', 3); }
      if (kid) for (const k of W.keys) { const o = M.keys[k], x = SX(o.x), y = SY(o.y); if (onScr(x, y, 10)) { ctx.fillStyle = 'rgba(255,216,106,.8)'; ctx.beginPath(); ctx.arc(x, y, 4, 0, TAU); ctx.fill(); } }
      // footprints
      if (prints.length) {
        const t = performance.now() / 1000, noseMe = sp || (p && p.sk && p.c === S_NOSE);
        for (const f of prints) {
          const age = t - f.t, x = SX(f.x), y = SY(f.y); if (!onScr(x, y, 10)) continue;
          let al = 0;
          if (f.sn && (sp || !p || hyp(f.x - p.x, f.y - p.y) < 11)) al = Math.max(0, 1 - age / 8) * 0.75;
          if (f.sc && noseMe && (sp || hyp(f.x - p.x, f.y - p.y) < 18)) al = Math.max(al, Math.max(0, 1 - age / 5));
          if (al <= 0.02) continue;
          ctx.save(); ctx.translate(x, y); ctx.rotate(f.a); ctx.globalAlpha = al;
          ctx.fillStyle = f.sc && noseMe ? '#d38cff' : 'rgba(200,225,255,.95)';
          const o = (f.f ? 1 : -1) * s * 0.12;
          ctx.beginPath(); ctx.ellipse(0, o, s * 0.11, s * 0.06, 0, 0, TAU); ctx.fill();
          ctx.restore();
        }
      }
      // bell lines: every survivor knows where they are; the seeker only notices one right at their feet
      for (const b of W.bel) {
        if (!(sp || kid || (p && hyp(b.x - p.x, b.y - p.y) < 1.4))) continue;
        const x = SX(b.x), y = SY(b.y); if (!onScr(x, y, 10)) continue;
        ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x - s * 0.4, y + s * 0.15); ctx.lineTo(x + s * 0.4, y + s * 0.15); ctx.stroke();
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(x, y, Math.max(3.5, s * 0.13), Math.PI, 0); ctx.lineTo(x + s * 0.15, y + s * 0.08); ctx.lineTo(x - s * 0.15, y + s * 0.08); ctx.closePath(); ctx.fill();
      }
      // teammates (kids see each other as small dots) and auras
      if (p && !sp) for (const q of W.pl) {
        if (q === p || hiddenFrom(q)) continue;
        if (seeFull(W, p, q)) continue;
        if (aura(W, p, q)) { drawBody(q, now, true); continue; }
        if (kid && !q.sk) { const x = SX(q.x), y = SY(q.y); if (onScr(x, y, 10)) { ctx.fillStyle = hexA(COL(q.i), 0.75); ctx.beginPath(); ctx.arc(x, y, Math.max(4, s * 0.13), 0, TAU); ctx.fill(); if (q.hp === 1) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 1.5; ctx.stroke(); } } }
      }
    }
    // ----- objective: what should I do now, and which way (follows the paths, not straight through walls) -----
    function objective(p) {
      if (!p || !W.go) return null;
      const M = W.M; let best = null, bd = 1e9;
      const near = (list, f) => { for (const o of list) { const d = hyp(o.x - p.x, o.y - p.y); if (d < bd) { bd = d; best = f(o); } } };
      if (p.sk) {
        if (W.hop === 1 && W.hatch >= 0) { const o = M.hatches[W.hatch]; return { t: '비밀 통로 닫기', s: '통로', x: o.x, y: o.y, col: '#9ad0ff' }; }
        if (W.pw) { near(M.gates, (g) => ({ t: '대문 지키기', s: '대문', x: g.ix, y: g.iy, col: '#7cc66a' })); return best; }
        let bp = 0.12, bj = -1; for (let j = 0; j < W.lan.length; j++) if (!W.lan[j].lit && W.lan[j].p > bp) { bp = W.lan[j].p; bj = j; }
        if (bj >= 0) return { t: '고치던 등불 ' + Math.floor(bp * 100) + '%', s: '등불', x: M.lans[bj].x, y: M.lans[bj].y, col: '#ffd86a' };
        return { t: '생존자 찾기', x: null, col: '#e3ae45' };
      }
      if (W.hop === 1 && W.hatch >= 0) { const o = M.hatches[W.hatch]; return { t: '비밀 통로로!', s: '통로', x: o.x, y: o.y, col: '#9ad0ff' }; }
      if (W.pw) { near(M.gates.map((g, j) => ({ x: g.ix, y: g.iy, j })), (g) => ({ t: W.gate[g.j].open ? '열린 대문으로!' : '대문 열고 탈출', s: '대문', x: g.x, y: g.y, col: '#7cc66a' })); return best; }
      for (const q of W.pl) if (q.st === 2 && q.cg >= 0) { const c = M.cages[q.cg], d = hyp(c.x - p.x, c.y - p.y); if (d < 11 && d < bd) { bd = d; best = { t: '갇힌 친구 구출', s: '구출', x: c.x, y: c.y, col: '#ee6a55' }; } }
      if (best) return best;
      near(M.lans.filter((o, j) => !W.lan[j].lit), (o) => ({ t: '등불 고치기', x: o.x, y: o.y, col: '#ffd86a' }));
      return best;
    }
    function pathAim(p, x, y) { // a point a few steps along the walking path towards (x, y)
      const M = W.M, goal = tileAt(M, x, y), f = field(W, goal), cur = tileAt(M, p.x, p.y);
      if (f[cur] < 0 || f[cur] <= 2) return [x, y];
      let c = cur;
      for (let k = 0; k < 3; k++) {
        const cx = c % M.W, cy = (c / M.W) | 0; let bn = -1, bv = f[c];
        for (const [dx, dy] of D8) { const nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= M.W || ny >= M.H) continue; const n = ny * M.W + nx; if (f[n] >= 0 && f[n] < bv) { bv = f[n]; bn = n; } }
        if (bn < 0) break; c = bn;
      }
      return [(c % M.W) + 0.5, ((c / M.W) | 0) + 0.5];
    }
    function drawObjective(p, now) {
      const ob = objective(p); if (!ob) return;
      let dist = '';
      if (ob.x != null) {
        const d = hyp(ob.x - p.x, ob.y - p.y); dist = ' · ' + Math.max(1, Math.round(d)) + '칸';
        if (d > 1.6) { // compass mark around me
          const aim = pathAim(p, ob.x, ob.y), a = Math.atan2(aim[1] - p.y, aim[0] - p.x), R = lay.ts * (0.95 + 0.06 * Math.sin(now / 160));
          const x = SX(p.x) + Math.cos(a) * R, y = SY(p.y) + Math.sin(a) * R;
          ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.globalAlpha = 0.95; ctx.fillStyle = ob.col; ctx.strokeStyle = 'rgba(12,8,22,.85)'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(8, 0); ctx.lineTo(-5, -6.5); ctx.lineTo(-2, 0); ctx.lineTo(-5, 6.5); ctx.closePath(); ctx.stroke(); ctx.fill(); ctx.restore();
          const sx = SX(ob.x), sy = SY(ob.y);
          if (sx < 0 || sx > lay.w || sy < TOPH || sy > lay.h - 8) edgeArrow(sx, sy, ob.col, ob.s || ob.t.split(' ')[0]);
        }
      }
      const t = ob.t + dist, mr = miniRect(), maxW = lay.w - mr.w - 26;
      ctx.font = '700 13px ' + FONT; const tw = Math.min(maxW - 26, ctx.measureText(t).width);
      rr(ctx, 8, TOPH + 6, tw + 30, 28, 14); ctx.fillStyle = 'rgba(16,11,28,.82)'; ctx.fill(); ctx.strokeStyle = hexA(ob.col.length === 7 ? ob.col : '#e3ae45', 0.7); ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = ob.col; ctx.beginPath(); ctx.moveTo(17, TOPH + 14); ctx.lineTo(25, TOPH + 20); ctx.lineTo(17, TOPH + 26); ctx.closePath(); ctx.fill();
      ctx.save(); ctx.font = '700 13px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t, 30, TOPH + 20.5, maxW - 26); ctx.restore();
    }
    function drawTarget(p, now) { // a ring on whatever the big button would act on
      if (!p || p.st !== 0 || p.chk) return;
      const c = ctxOf(W, p); if (!c) return;
      const o = ctxSpot(c, p); if (!o) return;
      const x = SX(o.x), y = SY(o.y), r = lay.ts * (0.62 + 0.05 * Math.sin(now / 150));
      ctx.save(); ctx.strokeStyle = c.k === 'kick' || c.k === 'open' ? '#ff9a8a' : '#ffe9a8'; ctx.lineWidth = 2.5; ctx.setLineDash([6, 5]); ctx.lineDashOffset = -now / 40;
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); ctx.restore();
    }
    // ----- minimap (tap / Tab = big map) -----
    function miniRect() { const M = W.M, mw = Math.round(clamp(lay.w * 0.22, 76, 104)), k = mw / M.W; return { x: lay.w - mw - 8, y: TOPH + 6, w: mw, h: Math.round(M.H * k), k }; }
    function miniBase(k) {
      const M = W.M, key = M.k + '|' + k.toFixed(2) + '|' + W.dv;
      if (miniCv && miniKey === key) return miniCv;
      miniKey = key; miniCv = miniCv || document.createElement('canvas');
      const d = Math.min(2, cv.dpr || 1); miniCv.width = Math.ceil(M.W * k * d); miniCv.height = Math.ceil(M.H * k * d);
      const g = miniCv.getContext('2d'); g.setTransform(k * d, 0, 0, k * d, 0, 0); g.clearRect(0, 0, M.W, M.H);
      g.fillStyle = 'rgba(24,18,38,.92)'; g.fillRect(0, 0, M.W, M.H);
      for (let i = 0; i < M.N; i++) {
        const ch = M.c[i], x = i % M.W, y = (i / M.W) | 0;
        if (W.sol[i] && (WALLS.indexOf(ch) >= 0 || ch === 'D' || ch === 'o' || ch === 'O')) g.fillStyle = ch === 'o' || ch === 'O' ? '#2f6a2c' : '#6a5a86';
        else if (ch === '~') g.fillStyle = '#1e4a6a';
        else if (ch === '=') g.fillStyle = '#5a7a9a';
        else if (W.sol[i]) g.fillStyle = '#3a3050';
        else continue;
        g.fillRect(x, y, 1, 1);
      }
      return miniCv;
    }
    function drawMap(p, big, now) {
      const M = W.M; let R;
      if (big) { const k = Math.min((lay.w - 24) / M.W, (lay.h - TOPH - Math.max(40, lay.bot + 24)) / M.H); R = { w: M.W * k, h: M.H * k, k }; R.x = (lay.w - R.w) / 2; R.y = TOPH + 30; }
      else R = miniRect();
      ctx.save();
      if (big) { ctx.fillStyle = 'rgba(6,4,12,.7)'; ctx.fillRect(0, 0, lay.w, lay.h); }
      rr(ctx, R.x - 3, R.y - 3, R.w + 6, R.h + 6, 8); ctx.fillStyle = 'rgba(12,8,22,.9)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.drawImage(miniBase(R.k), R.x, R.y, R.w, R.h);
      const X = (x) => R.x + x * R.k, Y = (y) => R.y + y * R.k, dot = Math.max(2.2, R.k * 0.55);
      for (let j = 0; j < M.lans.length; j++) { // lanterns: lit yellow · unlit dark with progress
        const o = M.lans[j], L0 = W.lan[j];
        ctx.fillStyle = L0.lit ? '#ffe28a' : '#3a2a1a'; ctx.beginPath(); ctx.arc(X(o.x), Y(o.y), dot * 1.15, 0, TAU); ctx.fill();
        ctx.strokeStyle = L0.lit ? '#fff3cf' : '#ffd86a'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(X(o.x), Y(o.y), dot * 1.15, -Math.PI / 2, -Math.PI / 2 + TAU * (L0.lit ? 1 : Math.max(0.12, L0.p))); ctx.stroke();
      }
      for (let j = 0; j < M.gates.length; j++) { const o = M.gates[j]; ctx.fillStyle = W.pw ? '#7cc66a' : '#8a8a9a'; ctx.fillRect(X(o.x) - dot, Y(o.y) - dot, dot * 2, dot * 2); }
      if (W.hop === 1 && W.hatch >= 0) { const o = M.hatches[W.hatch]; ctx.strokeStyle = '#9ad0ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X(o.x), Y(o.y), dot * 1.5, 0, TAU); ctx.stroke(); }
      for (const q of W.pl) { // caged friends (everyone knows), teammates for survivors
        if (q.st === 2) { ctx.fillStyle = 'rgba(238,106,85,' + (0.6 + 0.4 * Math.sin(now / 150)) + ')'; ctx.beginPath(); ctx.arc(X(q.x), Y(q.y), dot * 1.4, 0, TAU); ctx.fill(); continue; }
        if (q === p || q.st !== 0 || q.sk || !p || p.sk || q.hid >= 0) continue;
        ctx.fillStyle = COL(q.i); ctx.beginPath(); ctx.arc(X(q.x), Y(q.y), dot * 0.85, 0, TAU); ctx.fill();
      }
      if (p) { // me
        const a = p.a; ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(12,8,22,.9)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(X(p.x) + Math.cos(a) * dot * 2.2, Y(p.y) + Math.sin(a) * dot * 2.2); ctx.lineTo(X(p.x) + Math.cos(a + 2.4) * dot * 1.5, Y(p.y) + Math.sin(a + 2.4) * dot * 1.5); ctx.lineTo(X(p.x) + Math.cos(a - 2.4) * dot * 1.5, Y(p.y) + Math.sin(a - 2.4) * dot * 1.5); ctx.closePath(); ctx.stroke(); ctx.fill();
        if (!big) { const hw = lay.w / 2 / lay.ts, top = (lay.ay - TOPH) / lay.ts, bot = (lay.h - lay.ay) / lay.ts; ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1; ctx.strokeRect(X(cam.x - hw), Y(cam.y - top), hw * 2 * R.k, (top + bot) * R.k); }
      }
      if (big) { txt('지도 · 눌러서 닫기', lay.w / 2, R.y - 14 < TOPH + 4 ? R.y + R.h + 14 : R.y - 14, '#e3ae45', '700 13px ' + FONT, 'center', 3); }
      else txt('지도', R.x + R.w - 3, R.y + R.h + 9, '#ab9fb8', '600 10px ' + FONT, 'right', 3);
      ctx.restore();
    }
    function edgeArrow(x, y, col, label, a) {
      const ang = Math.atan2(y - lay.ay, x - lay.w / 2);
      const ex = clamp(x, 20, lay.w - 20);
      let ey = clamp(y, TOPH + (lay.sp ? 20 : 50), lay.h - (lay.bot > 20 ? lay.bot + 36 : 20));
      if (!lay.sp) { const mr = miniRect(); if (ex > mr.x - 24 && ey < mr.y + mr.h + 22) ey = mr.y + mr.h + 26; }
      ctx.save(); ctx.globalAlpha = a == null ? 0.9 : a; ctx.translate(ex, ey);
      ctx.save(); ctx.rotate(ang); ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(12, 0); ctx.lineTo(-6, -8); ctx.lineTo(-6, 8); ctx.closePath(); ctx.fill(); ctx.restore();
      if (label) txt(label, clamp(-Math.cos(ang) * 22, -40, 40), -Math.sin(ang) * 16, col, '700 10px ' + FONT, 'center', 3);
      ctx.restore();
    }
    function drawArrows(p) {
      if (!p || lay.sp) return;
      const M = W.M, off = (x, y) => x < 0 || x > lay.w || y < TOPH || y > lay.h - 8;
      if (!p.sk) {
        for (const q of W.pl) if (q.st === 2) { const x = SX(q.x), y = SY(q.y); if (off(x, y)) edgeArrow(x, y, '#ee6a55', '구출'); }
        if (W.pw) for (let j = 0; j < M.gates.length; j++) { const o = M.gates[j], x = SX(o.ix), y = SY(o.iy); if (off(x, y)) edgeArrow(x, y, '#7cc66a', '대문'); }

      }
    }
    function drawWorld(now) {
      const M = W.M, s = lay.ts, sp = lay.sp, p = myP(), S = seekerOf(W);
      const ox = lay.w / 2 - cam.x * s, oy = lay.ay - cam.y * s;
      ctx.drawImage(bgCv, ox, oy, M.W * s, M.H * s);
      drawDynamic(now, sp, p);
      const order = W.pl.slice().sort((a, b) => a.y - b.y);
      for (const q of order) {
        if (q.st !== 0 || q.ride) continue;
        if (q.hid >= 0) { if (sp || q === p) drawPeek(q, now, q === p && !sp); continue; }
        if (!sp && p && q !== p && !seeFull(W, p, q)) continue;
        drawBody(q, now);
      }
      // darkness
      const dpr = cv.dpr || 1, o = octx;
      const counting = !sp && p && p.sk && !W.go;
      o.setTransform(dpr, 0, 0, dpr, 0, 0);
      o.globalCompositeOperation = 'source-over'; o.globalAlpha = 1;
      o.clearRect(0, 0, lay.w, lay.h);
      o.fillStyle = counting ? 'rgba(4,3,10,.97)' : sp ? 'rgba(8,6,20,.45)' : 'rgba(7,5,16,.93)';
      o.fillRect(0, 0, lay.w, lay.h);
      const bv = !counting && beamVisibleTo(sp ? null : p, S);
      o.globalCompositeOperation = 'destination-out';
      o.save(); o.translate(ox, oy); o.scale(s, s);
      o.fillStyle = '#000';
      for (let r = 0; r < W.lit.length; r++) {
        if (!roomLit(W, r)) continue;
        o.globalAlpha = W.lit[r] > 0 ? 0.88 : (Math.sin(now / 45) > -0.3 ? 0.8 : 0.4);
        for (const i of M.roomLit[r]) o.fillRect(i % M.W - 0.02, ((i / M.W) | 0) - 0.02, 1.04, 1.04);
      }
      if (!lampCache || lampCache.dv !== W.dv) lampCache = { dv: W.dv, p: [] };
      for (let j = 0; j < W.lan.length; j++) {
        if (!W.lan[j].lit) continue;
        const L0 = M.lans[j];
        if (!lampCache.p[j]) lampCache.p[j] = lampPoly(W, j, []);
        const gr = o.createRadialGradient(L0.x, L0.y, 0, L0.x, L0.y, LAMP_R);
        gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(0.6, 'rgba(0,0,0,.8)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        o.globalAlpha = 0.9; o.fillStyle = gr; polyPath(o, lampCache.p[j], L0.x, L0.y, true); o.fill();
      }
      if (W.M.glow.length) { // glowing mushrooms light a small patch (cached: cave walls never move)
        if (!lampCache.g) lampCache.g = W.M.glow.map((o) => { const out = []; for (let i = 0; i <= 24; i++) { const a = i / 24 * TAU, dx = Math.cos(a), dy = Math.sin(a), d = castRay(W, o.x, o.y, dx, dy, GLOW_R); out.push(o.x + dx * d, o.y + dy * d); } return out; });
        o.globalAlpha = 0.8;
        W.M.glow.forEach((g0, j) => { const gr = o.createRadialGradient(g0.x, g0.y, 0, g0.x, g0.y, GLOW_R); gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); o.fillStyle = gr; polyPath(o, lampCache.g[j], g0.x, g0.y, true); o.fill(); });
      }
      if (moon.length) { o.globalAlpha = 0.28; for (const m0 of moon) { const gr = o.createRadialGradient(m0[0], m0[1], 0, m0[0], m0[1], 1.7); gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); o.fillStyle = gr; o.fillRect(m0[0] - 1.7, m0[1] - 1.7, 3.4, 3.4); } }
      if (!counting && p && !sp) {
        const R = nvOf(p);
        rayFan(p.x, p.y, 0, TAU, 40, R, nvPts);
        const gr = o.createRadialGradient(p.x, p.y, 0, p.x, p.y, R);
        gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(0.55, 'rgba(0,0,0,.7)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        o.globalAlpha = p.sk ? 0.5 : 0.62; o.fillStyle = gr; polyPath(o, nvPts, p.x, p.y, true); o.fill();
      }
      if (bv) {
        rayFan(S.x, S.y, S.a, HALF * 2, 36, RANGE, beamPts);
        const gr = o.createRadialGradient(S.x, S.y, 0, S.x, S.y, RANGE);
        gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(0.7, 'rgba(0,0,0,.9)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        o.globalAlpha = 1; o.fillStyle = gr; polyPath(o, beamPts, S.x, S.y, false); o.fill();
      }
      if (W.go && beamOn(S) && (bv || (p && los(W, p.x, p.y, S.x, S.y)))) { o.globalAlpha = 0.8; o.fillStyle = '#000'; o.beginPath(); o.arc(S.x, S.y, 0.55, 0, TAU); o.fill(); }
      if (W.hop === 1 && W.hatch >= 0) { const hh = M.hatches[W.hatch]; o.globalAlpha = 0.7; o.beginPath(); o.arc(hh.x, hh.y, 0.8, 0, TAU); o.fill(); }
      o.restore();
      ctx.drawImage(oc, 0, 0, lay.w, lay.h);
      if (counting) { drawMarkers(now, sp, p); return; }
      if (W.fog.length) { // drifting fog banks
        ctx.save();
        for (let k = 0; k < W.fog.length; k++) {
          const f = fogPos(W, k), x = SX(f[0]), y = SY(f[1]), R = W.fog[k].r * s;
          if (!onScr(x, y, R)) continue;
          const gr = ctx.createRadialGradient(x, y, R * 0.2, x, y, R * 1.15);
          gr.addColorStop(0, 'rgba(200,210,225,.38)'); gr.addColorStop(1, 'rgba(200,210,225,0)');
          ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, R * 1.15, 0, TAU); ctx.fill();
        }
        ctx.restore();
      }
      for (const o of W.smk) { // smoke clouds
        const x = SX(o.x), y = SY(o.y), R = SMOKE_R * s * Math.min(1, 0.6 + (SMOKE_T - o.t) * 1.5), al = Math.min(1, o.t / 1.2);
        if (!onScr(x, y, R)) continue;
        ctx.save(); ctx.globalAlpha = 0.7 * al;
        for (let k = 0; k < 6; k++) { const a = k * 1.05 + now / 1400 + o.x, rr2 = R * (0.42 + 0.12 * Math.sin(now / 500 + k)); const gr = ctx.createRadialGradient(x + Math.cos(a) * R * 0.45, y + Math.sin(a) * R * 0.45, 0, x + Math.cos(a) * R * 0.45, y + Math.sin(a) * R * 0.45, rr2); gr.addColorStop(0, 'rgba(205,205,220,.85)'); gr.addColorStop(1, 'rgba(205,205,220,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x + Math.cos(a) * R * 0.45, y + Math.sin(a) * R * 0.45, rr2, 0, TAU); ctx.fill(); }
        ctx.restore();
      }
      if (bv) {
        ctx.save(); ctx.translate(ox, oy); ctx.scale(s, s);
        const gr = ctx.createRadialGradient(S.x, S.y, 0, S.x, S.y, RANGE);
        gr.addColorStop(0, 'rgba(255,214,120,.3)'); gr.addColorStop(1, 'rgba(255,214,120,0)');
        ctx.fillStyle = gr; polyPath(ctx, beamPts, S.x, S.y, false); ctx.fill();
        ctx.restore();
      }
      for (const g0 of M.glow) { const x = SX(g0.x), y = SY(g0.y); if (!onScr(x, y, s * 2)) continue; const gr = ctx.createRadialGradient(x, y, 0, x, y, GLOW_R * s); gr.addColorStop(0, 'rgba(110,255,220,.22)'); gr.addColorStop(1, 'rgba(110,255,220,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, GLOW_R * s, 0, TAU); ctx.fill(); }
      for (let j = 0; j < W.lan.length; j++) if (W.lan[j].lit) { const L0 = M.lans[j], x = SX(L0.x), y = SY(L0.y); if (!onScr(x, y, s * 3)) continue; const gr = ctx.createRadialGradient(x, y, 0, x, y, LAMP_R * s); gr.addColorStop(0, 'rgba(255,220,130,.28)'); gr.addColorStop(1, 'rgba(255,220,130,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, LAMP_R * s, 0, TAU); ctx.fill(); }
      drawMarkers(now, sp, p);
      if (!W.go && !S.st && st.ph === 'play') txt('눈 감고 세는 중… ' + Math.max(1, Math.ceil(START_T - W.t)), SX(S.x), SY(S.y) - s * 0.8, '#ffe9a8', '700 12px ' + FONT, 'center', 3);
      for (const r of ripples) {
        const k = r.t / 1.4, x = SX(r.x), y = SY(r.y);
        ctx.save();
        const loud = r.k < LOUD.length && LOUD[r.k], col = r.k === 99 ? '255,150,170' : loud ? '255,170,110' : '190,225,255';
        ctx.strokeStyle = 'rgba(' + col + ',' + (1 - k) + ')'; ctx.lineWidth = 2.5;
        const big = r.k === 99 ? 16 : loud ? 2.6 : 1.8;
        for (let j = 0; j < 2; j++) { const kk = Math.max(0, k - j * 0.18); if (kk <= 0) continue; ctx.beginPath(); ctx.arc(x, y, s * (0.3 + kk * big), 0, TAU); ctx.stroke(); }
        if (r.k !== 99) { ctx.globalAlpha = Math.max(0, 1 - k * 1.2); const t = NOISE_NM[r.k] || ''; txt(t, inX(t, x, '700 12px ' + FONT), y - s * 0.6 - k * 10, loud ? '#ffd27a' : '#e6f3ff', '700 12px ' + FONT, 'center', 3); }
        ctx.restore();
        if (!sp && r.k !== 99 && (x < 0 || x > lay.w || y < TOPH || y > lay.h - 8)) edgeArrow(x, y, loud ? '#ffd27a' : '#bfe3ff', null, 1 - k);
      }
      for (const g of ghosts) {
        const k = g.t / 1.6, x = SX(g.x + (g.x1 - g.x) * k), y = SY(g.y + (g.y1 - g.y) * k) - Math.sin(k * Math.PI) * s * (g.cage ? 1.4 : 0.4);
        ctx.save(); ctx.globalAlpha = g.cage ? 1 - k * 0.5 : 1 - k;
        ctx.fillStyle = '#f2f0ff'; ctx.beginPath(); ctx.arc(x, y, s * 0.32, Math.PI, 0); ctx.lineTo(x + s * 0.32, y + s * 0.34);
        for (let j = 0; j < 4; j++) ctx.lineTo(x + s * 0.32 - (j + 0.5) * s * 0.16, y + s * (j % 2 ? 0.34 : 0.24));
        ctx.lineTo(x - s * 0.32, y + s * 0.34); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#1b1226'; ctx.beginPath(); ctx.arc(x - s * 0.1, y - s * 0.02, s * 0.05, 0, TAU); ctx.arc(x + s * 0.1, y - s * 0.02, s * 0.05, 0, TAU); ctx.fill();
        txt(g.cage ? '새장으로!' : '탈락', x, y - s * 0.55, COL(g.i), '700 11px ' + FONT, 'center', 3);
        ctx.restore();
      }
      const tags = [];
      for (const q of W.pl) { // names under visible others (nudged apart when they overlap)
        if (q.st !== 0 || q.hid >= 0 || q.ride || q === p) continue;
        if (!sp && p && !seeFull(W, p, q)) continue;
        const t = name(q.i) + (q.sk ? ' (살인마)' : '');
        ctx.font = '700 11px ' + FONT;
        const x = inX(t, SX(q.x), '700 11px ' + FONT), hw = ctx.measureText(t).width / 2 + 3;
        let y = SY(q.y) + s * 0.66;
        for (let k = 0; k < 4; k++) { const hit = tags.find((g) => Math.abs(g[1] - y) < 13 && x - hw < g[0] + g[2] && x + hw > g[0] - g[2]); if (!hit) break; y = hit[1] + 13; }
        tags.push([x, y, hw]);
        txt(t, x, y, q.sk ? '#ffb3a8' : COL(q.i), '700 11px ' + FONT, 'center', 3);
      }
      if (p && ctrlOn() && !sp) drawTarget(p, now);
      for (const f of floats) { ctx.save(); ctx.globalAlpha = Math.min(1, (f.life - f.t) * 3); txt(f.txt, inX(f.txt, SX(f.x), '800 14px ' + FONT), SY(f.y) - f.t * 18, f.c, '800 14px ' + FONT, 'center', 3.5); ctx.restore(); }
      drawArrows(p);
      if (p && !sp && st.ph === 'play' && p.st === 0) drawObjective(p, now);
      if (p && p.st === 0 && !sp && !p.sk && W.go) { // heartbeat vignette
        const d = S.cl > 0 ? 99 : hyp(S.x - p.x, S.y - p.y);
        const k = p.ex > 0 ? Math.min(1, p.ex / BEAM_T) : d < TR ? (1 - d / TR) * (0.55 + 0.25 * Math.sin(now / (80 + d * 25))) : 0;
        if (k > 0.02) {
          const gr = ctx.createRadialGradient(lay.w / 2, lay.h / 2, Math.min(lay.w, lay.h) * 0.3, lay.w / 2, lay.h / 2, Math.max(lay.w, lay.h) * 0.75);
          gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, p.ex > 0 ? 'rgba(238,60,60,' + (0.55 * k) + ')' : 'rgba(170,90,255,' + (0.6 * k) + ')');
          ctx.fillStyle = gr; ctx.fillRect(0, 0, lay.w, lay.h);
          const wx = (lay.w - miniRect().w - 16) / 2;
          if (p.ex > 0) txt('빛에 걸렸어! 피해!', wx, TOPH + 52, '#ffb3a8', '800 15px ' + FONT, 'center', 4);
          else if (d < TR * 0.6) txt('두근두근… 가까워요', wx, TOPH + 52, '#e4cfff', '700 13px ' + FONT, 'center', 4);
        }
      }
    }
    function drawHud() {
      const w = lay.w, p = myP(), M = W.M;
      rr(ctx, 6, 4, w - 12, 62, 12); ctx.fillStyle = 'rgba(16,11,28,.86)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.35)'; ctx.lineWidth = 1; ctx.stroke();
      txt(st.rd + '/' + st.rounds + '판', 16, 19, '#ab9fb8', '600 12px ' + FONT, 'left');
      let lit = 0; for (const o of W.lan) if (o.lit) lit++;
      let mid, col = '#f2e9d8';
      if (st.ph === 'pick') mid = '캐릭터 고르기';
      else if (st.ph !== 'play') mid = st.ph === 'done' ? '게임 끝' : '판 끝';
      else if (!W.go) { mid = '살인마 출발까지 ' + Math.max(1, Math.ceil(START_T - W.t)); col = '#bfe3ff'; }
      else if (W.hop === 1) { mid = '비밀 통로 열림!'; col = '#9ad0ff'; }
      else if (W.pw) { mid = '대문 열기! ' + mmss(W.col); col = W.col < 20 ? '#ee6a55' : '#b8f0a8'; }
      else mid = '등불 ' + lit + '/' + NEED;
      if (st.ph === 'play' && W.go && !W.pw && W.hop !== 1) { // lantern pips
        ctx.font = '700 14px ' + FONT; const tw = ctx.measureText(mid).width, pw2 = NEED * 11, x0 = w / 2 - (tw + 8 + pw2) / 2;
        txt(mid, x0, 19, col, '700 14px ' + FONT, 'left');
        for (let k = 0; k < NEED; k++) { ctx.fillStyle = k < lit ? '#ffe28a' : 'rgba(242,233,216,.2)'; ctx.beginPath(); ctx.arc(x0 + tw + 12 + k * 11, 19, 4, 0, TAU); ctx.fill(); }
      } else txt(mid, w / 2, 19, col, '700 14px ' + FONT, 'center');
      if (st.ph === 'play' && W.go && !W.pw) txt('새벽 ' + mmss(CAP_T - W.t), w - 16, 19, CAP_T - W.t < 30 ? '#ee6a55' : '#ab9fb8', '600 11px ' + MONO, 'right');
      const n = st.np, cw = (w - 20) / n;
      for (let i = 0; i < n; i++) {
        const q = W.pl[i], cx = 10 + cw * i + cw / 2, y = 46, r = Math.min(10, cw * 0.24);
        ctx.save();
        const gone = q.st === 3;
        ctx.globalAlpha = gone ? 0.4 : 1;
        if (i === me()) { ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, y, r + 4, 0, TAU); ctx.stroke(); }
        if (q.sk) { ctx.fillStyle = SK_COL[q.c] || '#555'; ctx.beginPath(); ctx.arc(cx, y, r, 0, TAU); ctx.fill(); ctx.strokeStyle = COL(i); ctx.lineWidth = 2; ctx.stroke(); ctx.fillStyle = '#ffe36a'; ctx.beginPath(); ctx.moveTo(cx + r * 0.2, y); ctx.lineTo(cx + r * 1.1, y - r * 0.55); ctx.lineTo(cx + r * 1.1, y + r * 0.55); ctx.closePath(); ctx.fill(); }
        else {
          ctx.fillStyle = COL(i); ctx.beginPath(); ctx.arc(cx, y, r, 0, TAU); ctx.fill();
          if (q.hp === 1 && q.st === 0) { ctx.fillStyle = 'rgba(12,8,22,.7)'; ctx.beginPath(); ctx.arc(cx, y, r, -Math.PI / 2, Math.PI / 2); ctx.fill(); }
          if (q.st === 2) { ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 1.5; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(cx + k * r * 0.5, y - r); ctx.lineTo(cx + k * r * 0.5, y + r); ctx.stroke(); } }
          if (q.st === 3) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx - r, y - r); ctx.lineTo(cx + r, y + r); ctx.moveTo(cx + r, y - r); ctx.lineTo(cx - r, y + r); ctx.stroke(); }
          if (q.st === 4) { ctx.fillStyle = '#7cc66a'; ctx.beginPath(); ctx.arc(cx + r * 0.7, y - r * 0.7, r * 0.5, 0, TAU); ctx.fill(); }
        }
        ctx.restore();
      }
    }
    function centerText(t, sub, col, sc, cy) {
      ctx.save();
      ctx.font = Math.round(32 * sc) + 'px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 7; ctx.strokeStyle = 'rgba(12,8,22,.9)'; ctx.lineJoin = 'round'; ctx.strokeText(t, lay.w / 2, cy, lay.w - 20); ctx.fillStyle = col; ctx.fillText(t, lay.w / 2, cy, lay.w - 20);
      if (sub) { ctx.font = '700 14px ' + FONT; ctx.lineWidth = 4; ctx.strokeText(sub, lay.w / 2, cy + 30 * sc, lay.w - 24); ctx.fillStyle = '#f2e9d8'; ctx.fillText(sub, lay.w / 2, cy + 30 * sc, lay.w - 24); }
      ctx.restore();
    }
    function drawCheck(p) { // the "press when the needle is in the yellow" ring
      const c = p.chk; if (!c || c.ans) return;
      const v = needle(p); if (v > 1.05) return;
      const R = 40, cx = lay.w / 2, cy = lay.h - (lay.bot > 20 ? lay.bot : 0) - R - 34;
      ctx.save();
      ctx.fillStyle = 'rgba(16,11,28,.82)'; ctx.beginPath(); ctx.arc(cx, cy, R + 14, 0, TAU); ctx.fill();
      ctx.lineWidth = 9; ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
      const a0 = -Math.PI / 2;
      ctx.strokeStyle = '#ffd86a'; ctx.beginPath(); ctx.arc(cx, cy, R, a0 + c.z * TAU, a0 + (c.z + CHK_W) * TAU); ctx.stroke();
      ctx.strokeStyle = '#ffffff'; ctx.beginPath(); ctx.arc(cx, cy, R, a0 + c.z * TAU, a0 + (c.z + CHK_G) * TAU); ctx.stroke();
      if (v < 0) txt('!', cx, cy, '#ffd86a', '28px ' + DISP, 'center');
      else { const a = a0 + v * TAU; ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * (R - 14), cy + Math.sin(a) * (R - 14)); ctx.lineTo(cx + Math.cos(a) * (R + 9), cy + Math.sin(a) * (R + 9)); ctx.stroke(); }
      txt('노란 칸에서 「지금!」', cx, cy + R + 24, '#ffe9a8', '700 12px ' + FONT, 'center', 3);
      ctx.restore();
    }
    function drawBanners(now) {
      const p = myP(), cy = Math.max(TOPH + (lay.h - TOPH - lay.bot) * 0.3, lay.sp || !p ? 0 : miniRect().y + miniRect().h + 46);
      if (st.ph === 'end' || st.ph === 'done') { drawSummary(); return; }
      if (st.ph !== 'play') return;
      const mine = p && !auto();
      if (!W.go && W.t < 2.6) {
        ctx.save(); ctx.globalAlpha = Math.min(1, (2.6 - W.t) * 2);
        const S = seekerOf(W);
        if (mine && p.sk) centerText('내가 살인마! · ' + SEEKERS[p.c].nm, START_T + '초 뒤 출발 · 생존자 7명을 찾아요', '#e3ae45', 1, cy);
        else if (mine) centerText('나는 ' + KIDS[p.c].nm + '!', '살인마: ' + name(S.i) + ' · 등불 ' + NEED + '개를 켜고 탈출해요', '#bfe3ff', 1, cy);
        else centerText(st.rd + '판 · ' + W.M.nm, '살인마: ' + name(S.i), '#e3ae45', 0.85, cy);
        ctx.restore();
      } else if (banner) {
        const k = 1 - banner.life / banner.max;
        ctx.save(); ctx.globalAlpha = Math.min(1, banner.life * 2.5);
        centerText(banner.t, banner.sub, banner.c, k < 0.12 ? 0.7 + k * 2.5 : 1, cy);
        ctx.restore();
      }
      if (mine && p.st === 2 && !banner) centerText('새장 안 · ' + Math.max(0, Math.ceil(p.ct)) + '초', p.hk >= 2 ? '' : '친구가 와서 「구출」해 줄 때까지 기다려요', '#ffb3a8', 0.8, cy);
      if (mine && p.st === 0 && !lay.sp) drawCheck(p);
      if (tipT > 0 && ctrlOn() && p && !lay.sp && p.st === 0) {
        const lines = p.sk
          ? ['살인마 팁', '손전등은 걷는 쪽을 비춰요 · 보이는 생존자 쪽으로 살짝 따라가요', '빛을 1초 비추면 「깜짝」, 두 번째엔 새장에 가둬요', '가까우면 큰 버튼 「덥석」 · 오른쪽 화면을 끌면 손전등만 돌려요', '소리 물결을 따라가요 · 왼쪽 위 화살표 = 할 일, 오른쪽 위 = 지도', '「특기」: ' + SEEKERS[p.c].tag]
          : ['생존자 팁', '왼쪽을 끌어 걷기 · 「살금」 버튼이나 살짝 밀기 = 조용히', '등불 옆에서 「고치기」, 동그라미가 뜨면 노란 칸에서 「지금!」', '내 옆 화살표가 할 일 쪽을 가리켜요 · 오른쪽 위 지도를 누르면 크게', '빛에 1초 닿으면 깜짝, 두 번이면 새장! 친구를 「구출」해요', '등불 ' + NEED + '개 → 대문 열고 탈출!'];
        if (fine) lines.push('PC: WASD 이동 · Shift 달리기 · C 살금 · 스페이스 행동 · Q 특기 · Tab 지도');
        ctx.save(); ctx.globalAlpha = Math.min(1, tipT * 2);
        ctx.font = '600 13px ' + FONT;
        let mw = 0; for (const l of lines) mw = Math.max(mw, ctx.measureText(l).width);
        const bw = Math.min(lay.w - 16, mw + 26), bh = lines.length * 21 + 14, bx = (lay.w - bw) / 2;
        const by = Math.max(TOPH + 8, lay.h - lay.bot - bh - 8);
        rr(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(22,16,40,.93)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.2; ctx.stroke();
        lines.forEach((l, k) => { ctx.font = (k ? '600 12.5px ' : '800 13px ') + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = k === 0 ? '#e3ae45' : '#f2e9d8'; ctx.fillText(l, lay.w / 2, by + 17 + k * 21, bw - 12); });
        ctx.restore();
      }
    }
    function drawSummary() {
      const rs = st.rs || [], n = st.np;
      const bw = Math.min(lay.w - 16, 360), rowH = 30, bh = 74 + n * rowH + 8, bx = (lay.w - bw) / 2, by = Math.max(TOPH + 6, (lay.h - bh) / 2 - 10);
      rr(ctx, bx, by, bw, bh, 16); ctx.fillStyle = 'rgba(22,16,40,.95)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.stroke();
      let esc = 0; for (const r of rs) if (r[2] === 0 || r[2] === 1) esc++;
      txt(st.ph === 'done' ? '게임 끝!' : esc >= 4 ? '생존자들 승리!' : esc <= 2 ? '살인마 승리!' : '아슬아슬 무승부', lay.w / 2, by + 24, '#e3ae45', '24px ' + DISP);
      txt(st.rd + '/' + st.rounds + '판 · ' + W.M.nm + ' · 탈출 ' + esc + '명' + (st.ph === 'done' ? '' : ' · 곧 다음 판'), lay.w / 2, by + 50, '#ab9fb8', '600 12px ' + FONT, 'center', 0);
      const sorted = rs.slice().sort((a, b) => (b[2] === 9) - (a[2] === 9) || a[0] - b[0]);
      sorted.forEach((r, k) => {
        const i = r[0], y = by + 74 + k * rowH + rowH / 2;
        ctx.fillStyle = COL(i); ctx.beginPath(); ctx.arc(bx + 16, y, 6, 0, TAU); ctx.fill();
        let nm = name(i); if (nm.length > 5) nm = nm.slice(0, 5);
        txt(nm, bx + 27, y, i === me() ? '#ffe9a8' : '#f2e9d8', '700 13px ' + FONT, 'left');
        const ch = st.ch[i], cn = r[2] === 9 ? SEEKERS[ch] && SEEKERS[ch].nm : KIDS[ch] && KIDS[ch].nm;
        const det = r[2] === 9 ? '살인마 · ' + r[3] + '명 탈락' : r[2] === 0 ? '탈출!' : r[2] === 1 ? '비밀 통로 탈출!' : r[2] === 3 ? '새벽까지 못 나감' : '잡혀서 탈락';
        txt((cn || '') + ' · ' + det, bx + bw * 0.31, y, r[2] === 0 || r[2] === 1 ? '#b8f0a8' : '#c9bfd8', '600 12px ' + FONT, 'left');
        txt('+' + r[1], bx + bw - 46, y, '#7cc66a', '700 13px ' + MONO, 'right');
        txt(String(st.sc[i] | 0), bx + bw - 12, y, '#e3ae45', '700 14px ' + MONO, 'right');
      });
    }
    function drawStick() {
      if (aimT) { ctx.save(); ctx.strokeStyle = 'rgba(255,233,168,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(aimT.x, aimT.y, 18, 0, TAU); ctx.stroke(); ctx.restore(); }
      if (!stick) return;
      ctx.save();
      ctx.globalAlpha = 0.5; ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.strokeStyle = 'rgba(242,233,216,.5)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(stick.bx, stick.by, STICK_R, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.arc(stick.bx, stick.by, STICK_R * 0.55, 0, TAU); ctx.stroke();
      const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), k = d > STICK_R ? STICK_R / d : 1;
      ctx.globalAlpha = 0.85; ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(stick.bx + dx * k, stick.by + dy * k, 20, 0, TAU); ctx.fill();
      ctx.restore();
    }
    function draw(now) {
      if (!lay || !W || !bgCv) return;
      cv.clear();
      ctx.fillStyle = (THEMES[W.M.th] || THEMES[0]).bg; ctx.fillRect(0, 0, lay.w, lay.h);
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 8 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 8 : 0;
      ctx.save(); ctx.translate(sx, sy);
      drawWorld(now);
      ctx.restore();
      drawHud();
      const mp = myP();
      if (st.ph === 'play' && !lay.sp && mp && (mp.st === 0 || mp.st === 2)) drawMap(mp, false, now);
      drawStick();
      drawBanners(now);
      if (bigMap && st.ph === 'play' && !lay.sp && mp) drawMap(mp, true, now);
    }

    const stopLoop = U.loop((rdt, now) => {
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); syncBtns(); syncPick(); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (curKey() !== key) { startRound(); return; }
        if (prev && prev.ph !== next.ph && next.ph === 'end') {
          endT = END_T; stick = null; aimT = null;
          if (W && !W.res) W.res = { t: W.t, sent: 1 };
          const m = me(), r = (next.rs || []).find((q) => q[0] === m);
          if (r && !auto()) { api.sfx(r[1] > 0 ? 'win' : 'lose'); if (r[1] > 0) api.buzz(40); } else api.sfx('chip');
          lay = null; layout();
        }
        if (next.ph === 'pick') syncPick(true);
      },
      destroy() {
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        for (const k in btn) btn[k].remove();
        if (pickEl) pickEl.remove();
        styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, lay, locIn, remIn, cam, aiMem }),
    };
  }
  /* ---------- 도감 (codex): generated from KIDS / SEEKERS / MAPS / PM and the timing constants ---------- */
  function flCodex() {
    const KI = ['💨', '👣', '🔧', '🩹', '🫥', '👁', '🪞', '⏰', '🌫', '🪟', '💪', '🔔'];
    const SI = ['🕸', '🪞', '🦇', '👤', '🐂', '👃'];
    const MI = ['🏚', '🏕', '🏛', '🎡', '🏫', '🏔', '🍄', '🌿'];
    const skill = (k) => (k.act ? '특기 「' + k.act + '」 · ' + k.cd + '초마다' : '늘 켜짐 · ' + k.tag);
    const gmText = (gm) => {
      const a = [];
      if (gm.flick) a.push('방 불·네온이 가끔 깜빡 켜져요');
      if (gm.chime) a.push(gm.chime + '초마다 ' + (gm.sw ? '종소리' : '괘종시계') + ' — 2초 동안 모두의 위치가 보여요');
      if (gm.fog) a.push('안개가 떠다녀요(안개 속은 멀리서 안 보여요)');
      if (gm.crows) a.push('까마귀 옆을 뛰면 「까악!」');
      if (gm.keys) a.push('잠긴 전시실 — 바닥의 열쇠를 주워 문으로');
      if (gm.alarm) a.push('빨간 줄무늬 경보 바닥은 살금살금');
      if (gm.pads) a.push('같은 번호 ' + gm.pads + '끼리 순간 이동(' + gm.padT + '초)');
      if (gm.sw) a.push('벽 스위치로 방 불 켜기');
      if (gm.snow) a.push('눈밭에 발자국이 8초 남아요');
      if (gm.ice) a.push('얼음 호수는 미끄러워요');
      if (gm.glow) a.push('빛나는 버섯 근처는 환해요');
      if (gm.echo) a.push('동굴 메아리 — 살인마가 소리를 더 멀리서 들어요');
      if (gm.hedge) a.push(gm.hedge + '초마다 울타리가 움직여 길이 바뀌어요(' + HEDGE_WARN + '초 전에 반짝)');
      return a;
    };
    return [
      { h: '생존자', p: ['「」가 있는 능력은 「특기」 버튼으로 쓰고, 다시 쓸 때까지 기다려요. 나머지는 늘 켜져 있어요.'],
        rows: KIDS.map((k, i) => ({ icon: KI[i], name: k.nm, tag: skill(k), desc: k.d.replace(/\s*\(\d+초마다\)$/, '') })) },
      { h: '살인마', p: ['모든 살인마는 손전등(' + RANGE + '칸, ' + BEAM_T + '초 비추면 깜짝)과 「덥석」을 써요. 특기는 캐릭터마다 달라요.'],
        rows: SEEKERS.map((k, i) => ({ icon: SI[i], name: k.nm, tag: skill(k), desc: k.d.replace(/\s*\(\d+초마다\)$/, '') })) },
      { h: '맵', p: ['맵 기본값은 무작위예요(판마다 바뀌어요). 등불은 맵마다 7개, 그중 ' + NEED + '개를 켜면 대문이 열려요.'],
        rows: MAPS.map((m, i) => {
          const P = PM[i], sp = SPOT_NM[m.th] || SPOT_NM[0];
          const cnt = '등불 ' + P.lans.length + ' · 새장 ' + P.cages.length + ' · 숨을 곳 ' + P.spots.length + '(' + sp.join('·') + ') · 창문 ' + P.vaults.length + ' · 책장 ' + P.pals.length + ' · 대문 ' + P.gates.length;
          return { icon: MI[i] || '🗺', name: m.nm, tag: gmText(m.gm).length + '가지 기믹', desc: gmText(m.gm).join(' · ') + '. ' + cnt };
        }) },
      { h: '물건·장치', rows: [
        { icon: '🏮', name: '등불', tag: '고치기', desc: '옆에서 「고치기」(혼자 약 ' + LAN_T + '초, 여럿이면 더 빨라요). 동그라미가 뜨면 노란 칸에서 「지금!」. 놓치면 「펑!」 소리. 살인마는 「망가뜨리기」로 조금씩 꺼요.' },
        { icon: '🚪', name: '대문', tag: '탈출', desc: '등불 ' + NEED + '개가 켜지면 불이 들어와요. ' + GATE_T + '초 동안 열고 나가면 탈출! 새벽까지 ' + COLLAPSE_T + '초. 4분 30초가 지나면 등불이 모자라도 열려요(' + DAWN_COL + '초).' },
        { icon: '🌀', name: '비밀 통로', tag: '마지막 한 명', desc: '생존자가 한 명만 남으면 열려요. 들어가면 바로 탈출. 살인마는 「닫기」.' },
        { icon: '🪤', name: '새장', tag: CAGE_T + '초', desc: '처음 잡히면 가장 가까운 새장에 갇혀요. 친구가 옆에서 「구출」(' + RESCUE_T + '초). 살인마가 4칸 안이면 시간이 절반 속도. 두 번째로 잡히면 탈락.' },
        { icon: '🗄', name: '옷장·상자·덤불', tag: '숨기', desc: '옆에서 「숨기」. 숨으면 빛에 안 보여요. 25초 넘게 있으면 6초마다 덜컹 소리. 살인마는 「열어 보기」. 맵마다 이름이 달라요(' + SPOT_NM.map((s) => s[0]).join('·') + ' 등).' },
        { icon: '🪟', name: '낮은 창문', tag: '넘기', desc: '가운데 노란 점. 생존자는 빨리(약 ' + VAULT_K + '초), 살인마는 천천히(약 ' + VAULT_S + '초) 넘어요.' },
        { icon: '📚', name: '책장', tag: '넘어뜨리기', desc: '문 옆의 점선 상자. 넘어뜨리면 길을 막고, 살인마가 바로 옆이면 ' + STUN_T + '초 기절! 쓰러진 책장은 생존자만 넘고, 살인마는 「치우기」(돌진뿔은 부숴요).' },
        { icon: '🔑', name: '열쇠·잠긴 문', tag: '별빛 박물관', desc: '바닥의 열쇠를 주워 잠긴 문으로 가면 열려요.' },
        { icon: '🔀', name: '미끄럼 터널·엘리베이터', tag: '놀이공원·학교', desc: '같은 번호끼리 순간 이동(「타기」).' },
        { icon: '💡', name: '벽 스위치', tag: '한밤 학교', desc: '누르면 그 방 불이 켜져요. 환한 방은 잘 보여요.' },
        { icon: '🪵', name: '삐걱 마루', tag: '소리', desc: '밟으면 소리 물결이 퍼져요(살인마 화면에 보여요). 살금살금이면 조용해요. 그림자발은 소리가 안 나요.' },
        { icon: '🚨', name: '경보 바닥', tag: '별빛 박물관', desc: '빨간 줄무늬. 뛰거나 걸으면 경보가 울려요. 살금살금 지나가요.' },
        { icon: '🐦', name: '까마귀', tag: '숲속 캠프', desc: '옆을 뛰면 「까악!」 하고 날아올라 위치가 들켜요.' },
        { icon: '❄', name: '눈밭·얼음 호수', tag: '눈 덮인 산장', desc: '눈밭에는 발자국이 8초 남아요. 얼음은 빨리 미끄러지지만 잘 안 멈춰요.' },
        { icon: '🍄', name: '빛나는 버섯', tag: '반딧불 동굴', desc: '근처가 환해서 멀리서도 잘 보여요.' },
        { icon: '🌳', name: '움직이는 울타리', tag: '미로 정원', desc: '정해진 시간마다 열리고 닫혀요. 닫히기 ' + HEDGE_WARN + '초 전에 반짝이며 흔들려요.' },
        { icon: '⏰', name: '자명종', tag: '소음꾼', desc: '던진 곳에서 소리가 나서 살인마를 속여요.' },
        { icon: '🌫', name: '연기 구름', tag: '연막꾼', desc: SMOKE_T + '초 동안 연기 속은 손전등 빛도 눈길도 막혀요.' },
        { icon: '🔔', name: '방울 줄', tag: '방울꾼', desc: '2개까지. 살인마가 밟으면 딸랑! ' + BELL_STUN + '초 비틀대고 모두에게 3초 보여요.' },
        { icon: '🕸', name: '끈끈이 덫', tag: '덫사냥꾼', desc: '3개까지. 밟은 생존자는 잠깐 못 움직이고 위치가 보여요.' },
        { icon: '🪞', name: '거울', tag: '거울유령', desc: '세워 둔 거울로 멀리서 순간 이동해요.' },
      ] },
    ];
  }
  L.register({
    id: 'flashlight', name: '어둠 속 손전등 숨바꼭질', tag: '1 대 7 숨바꼭질', cat: '파티',
    blurb: '8명이 하는 한밤의 추격전! 살인마 1명은 손전등으로 쫓고, 생존자 7명은 등불 5개를 켜고 대문으로 탈출해요. 생존자 12종·살인마 6종, 맵 8곳. 내 폰에는 내 눈에 보이는 것만 보여요(한 폰에 한 명, 빈자리는 AI).',
    tint: '#3b2a6b',
    icon: '<rect x="5" y="33" width="17" height="9" rx="2" transform="rotate(-28 13 37)" fill="currentColor"/><path d="M21 30l27-17v28z" fill="currentColor" opacity=".35"/><path d="M34 40a7 7 0 0 1 14 0v10l-2.3-2-2.3 2-2.4-2-2.3 2-2.4-2-2.3 2z" fill="currentColor"/>',
    minPlayers: 8, maxPlayers: 8, defaultPlayers: 8, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.nm }))), def: -1 },
      { id: 'rounds', label: '판 수', choices: [{ v: 1, label: '1판' }, { v: 2, label: '2판' }, { v: 3, label: '3판' }], def: 2 },
      { id: 'who', label: '살인마 정하기', choices: [{ v: 'rand', label: '무작위' }, { v: 'p1', label: '1번 자리 먼저' }, { v: 'kid', label: '1번은 생존자만' }], def: 'rand' },
    ],
    controls: [
      { id: 'up', label: '위로 걷기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 걷기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 걷기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 걷기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'act', label: '행동 (고치기·숨기·넘기·덥석·지금!)', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'skill', label: '특기 (캐릭터 능력)', keys: ['KeyQ', 'KeyL'], pad: ['x', 'y'] },
      { id: 'run', label: '달리기 (꾹)', keys: ['ShiftLeft', 'KeyK'], pad: ['rt', 'b'] },
      { id: 'sneak', label: '살금살금 (꾹)', keys: ['KeyC', 'ControlLeft'], pad: ['lt', 'lb'] },
      { id: 'aimL', label: '손전등 왼쪽', keys: ['Numpad4'], pad: ['rx-'] },
      { id: 'aimR', label: '손전등 오른쪽', keys: ['Numpad6'], pad: ['rx+'] },
      { id: 'aimU', label: '손전등 위', keys: ['Numpad8'], pad: ['ry-'] },
      { id: 'aimD', label: '손전등 아래', keys: ['Numpad5', 'Numpad2'], pad: ['ry+'] },
      { id: 'map', label: '큰 지도 열기/닫기', keys: ['Tab'], pad: ['back'] },
    ],
    quick: [
      '살인마 1명 vs 생존자 7명! 생존자들은 불 꺼진 맵에서 등불 7개 중 ' + NEED + '개를 켜고 대문으로 탈출해요.',
      '생존자: 등불 옆 「고치기」, 동그라미가 뜨면 노란 칸에서 「지금!」. 살인마: 손전등 빛(1초)이나 「덥석」으로 잡아요.',
      '잡히면 새장(친구가 구출!), 두 번째엔 탈락. 밖에 남은 생존자가 없으면 판이 바로 끝나요. 탈출 +3점, 살인마는 탈락마다 +1점.',
    ],
    rules: [
      { h: '목표', p: [
        '8명이 하는 한밤의 추격전이에요. 판마다 한 명이 살인마, 나머지 7명은 생존자가 돼요(빈자리는 AI가 채워요).',
        '생존자들은 맵 곳곳의 등불 7개 중 ' + NEED + '개를 고쳐서 켜면 대문에 불이 들어와요. 대문을 열고 나가면 탈출!',
        '살인마는 생존자들을 잡아 새장에 가두고, 모두 탈락시키는 게 목표예요.',
        '내 폰에는 「내 눈에 보이는 것」만 보여요. 그래서 친구와는 각자 폰으로 해요(온라인·LAN 방, 최대 8명).',
      ] },
      { h: '한 판의 흐름', p: [
        '① 캐릭터 고르기(15초): 역할(살인마/생존자)이 정해지면 캐릭터를 골라요. 안 고르면 무작위.',
        '② 시작: 살인마는 ' + START_T + '초 동안 눈 감고 세요. 생존자들은 흩어져요.',
        '③ 등불 ' + NEED + '개가 켜지면 대문 2곳에 불이 들어오고 「새벽까지 ' + COLLAPSE_T + '초」가 흘러요. 대문을 열고(' + GATE_T + '초) 나가요.',
        '④ 새벽이 되면 아직 안에 있는 생존자는 탈락. 등불이 덜 켜졌어도 4분 30초가 지나면 새벽이 다가오며 대문이 열려요(60초).',
      ] },
      { h: '생존자가 할 일', p: [
        '등불 바로 옆에서 「고치기」를 누르면 가만히 서서 고쳐요(혼자 약 ' + LAN_T + '초, 여럿이면 더 빨라요). 움직이면 멈춰요.',
        '고치는 중 가끔 동그라미가 떠요. 빨간 바늘이 노란 칸에 올 때 「지금!」을 누르면 성공(흰 칸이면 더 빨라져요). 놓치면 「펑!」 소리가 나고 등불이 조금 망가져요.',
        '「깜짝」 놀란 친구 옆에서 「치료」(10초), 새장에 갇힌 친구 옆에서 「구출」(1초)을 할 수 있어요.',
        '마지막 한 명만 남으면 비밀 통로(파란 소용돌이)가 열려요. 들어가면 바로 탈출!',
      ] },
      { h: '살인마가 할 일', p: [
        '손전등 빛 안에 생존자가 1초 있으면 「깜짝!」 놀라요(잠깐 빨라짐). 깜짝 놀란 생존자를 한 번 더 잡으면 새장으로 가요.',
        '가까울 때 큰 버튼 「덥석」을 누르면 앞으로 휙 뛰어들어 바로 잡아요. 놓치면 잠깐 느려져요.',
        '숨을 곳 앞에서 「열어 보기」, 쓰러진 책장은 「치우기」, 고치던 등불은 「망가뜨리기」(조금씩 꺼져요), 비밀 통로는 「닫기」.',
        '빛은 벽·옷장·책장에 막혀요. 오른쪽 화면을 누르고 있으면 그쪽을 비춰요.',
      ] },
      { h: '새장과 탈락', p: [
        '처음 잡히면 가장 가까운 새장에 갇혀요. ' + CAGE_T + '초 안에 친구가 구출해 주면 다시 뛰어요(깜짝 상태).',
        '살인마가 새장 4칸 안에 있으면 새장 시간이 절반 속도로 흘러요. 마음 놓고 구하러 와도 돼요.',
        '두 번째로 잡히거나 새장 시간이 끝나면 탈락. 유령이 되어 맵 전체를 구경해요.',
        '밖에서 뛰는 생존자가 한 명도 없으면(모두 갇혔거나 탈락·탈출) 그 판은 바로 끝나요. 이때 새장에 남은 생존자는 탈락이에요.',
      ] },
      { h: '창문·책장·숨을 곳', p: [
        '낮은 창문(가운데 노란 점) 앞에서 「넘기」: 생존자는 빨리, 살인마는 천천히 넘어요.',
        '문 옆에 기대 선 책장(점선 상자) 앞에서 「넘어뜨리기」: 길을 막아요. 살인마가 바로 옆이면 2초 기절! 쓰러진 책장은 생존자만 넘을 수 있고 살인마는 「치우기」.',
        '옷장·상자·덤불 옆에서 「숨기」. 숨으면 빛에 안 보여요. 하지만 25초 넘게 있으면 6초마다 덜컹 소리가 나요.',
      ] },
      { h: '소리와 빛', p: [
        '달리기(꾹)·삐걱 마루·실수(펑!)·까마귀·경보 바닥은 소리 물결이 퍼져요. 살인마 화면에 물결이 보여요.',
        '조이스틱을 조금만 밀면 살금살금(조용). 켜진 등불과 불 켜진 방 근처는 환해서 잘 보여요.',
        '살인마가 가까우면 화면이 두근두근 보라색으로 물들어요. 빨간색이면 빛에 걸린 거예요 — 피해요!',
      ] },
      { h: '캐릭터', p: [
        '생존자 — ' + KIDS.map((k) => k.nm + '(' + k.tag + '): ' + k.d).join(' / '),
        '살인마 — ' + SEEKERS.map((k) => k.nm + '(' + k.tag + '): ' + k.d).join(' / '),
        '「」가 있는 능력은 「특기」 버튼으로 써요. 나머지는 늘 켜져 있어요.',
      ] },
      { h: '맵과 기믹', p: [
        '달빛 저택: 방 불이 가끔 깜빡 켜지고, 50초마다 괘종시계가 울리면 2초 동안 모두의 위치가 보여요.',
        '숲속 캠프: 안개가 천천히 떠다녀요(안개 속은 멀리서 안 보여요). 까마귀 옆을 뛰면 「까악!」.',
        '별빛 박물관: 잠긴 전시실 2곳 — 바닥의 열쇠를 주워 문으로 가면 열려요. 빨간 줄무늬 경보 바닥은 살금살금!',
        '달님 놀이공원: 같은 번호 미끄럼 터널끼리 순간 이동(「타기」). 네온이 가끔 깜빡여요.',
        '한밤 학교: 엘리베이터(같은 번호)로 이동, 벽 스위치로 방 불 켜기, 55초마다 종소리(모두 보임).',
        '눈 덮인 산장: 눈밭(하얀 바닥)에 발자국이 8초 남아요 — 살인마도 따라올 수 있어요. 가운데 얼음 호수는 미끄러워요(빨리 미끄러지지만 잘 안 멈춰요).',
        '반딧불 동굴: 빛나는 버섯 근처는 환해서 잘 보여요. 동굴이라 소리가 멀리 울려요(살인마가 더 멀리서 들어요).',
        '달빛 미로 정원: ' + 40 + '초마다 울타리가 움직여 길이 바뀌어요. 바뀌기 3초 전에 울타리가 반짝이며 흔들려요.',
        '맵 기본값은 무작위예요(판마다 바뀌어요).',
      ] },
      { h: '점수·우승', p: [
        '생존자: 탈출 +3점, 등불 하나를 1/4 넘게 고치면 등불마다 +1점, 친구 구출마다 +1점.',
        '살인마: 탈락한 생존자 1명마다 +1점, 7명 모두 탈락이면 +2점 더.',
        '예시) 등불 2개를 고치고 친구 1명을 구한 뒤 탈출하면 3+2+1 = 6점. 살인마가 4명을 탈락시키면 4점.',
        '판 수(1~3판)가 끝나면 합계가 가장 높은 사람이 우승! 살인마는 판마다 아직 안 해 본 사람 중에서 무작위로 정해요.',
        '판 결과: 4명 이상 탈출하면 생존자들 승리, 2명 이하면 살인마 승리, 3명이면 무승부예요.',
      ] },
      { h: '조작', p: [
        '왼쪽 엄지: 화면 아무 데나 누르고 끌면 걸어요. 살짝만 밀거나 「살금」 버튼을 켜면 조용히 걸어요. 「달리기」를 꾹 누르면 빨라요(시끄러움).',
        '오른쪽 큰 버튼: 상황에 맞게 바뀌어요(고치기·숨기·넘기·구출·덥석…). 무엇에 쓰일지 땅에 점선 동그라미로 보여요. 고치는 동안 버튼 테두리가 차올라요.',
        '작은 버튼 「특기」: 캐릭터 능력(다시 쓸 때까지 버튼이 어둡게 차올라요).',
        '할 일 안내: 왼쪽 위에 지금 할 일, 내 옆 작은 화살표가 길을 따라 그쪽을 가리켜요. 오른쪽 위 작은 지도를 누르면 큰 지도가 열려요.',
        '살인마 손전등: 걷는 쪽을 비춰요. 보이는 생존자가 앞쪽 가까이 있으면 살짝 그쪽으로 따라가요(그래도 피하면 놓쳐요). 오른쪽 화면을 누르고 끌면 손전등만 돌려요.',
        'PC: WASD·방향키 이동, Shift 달리기, C 살금, 스페이스 행동, Q 특기, Tab 지도. 살인마는 마우스 쪽을 비춰요. 패드: 왼스틱 이동, 오른스틱 손전등. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '항상 8명이에요. 혼자 하면 7명이 AI, 친구와는 온라인·LAN 방에서 각자 폰으로(빈자리는 AI).',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려운 살인마는 소리를 잘 듣고 등불을 지켜요. 어려운 생존자는 책장을 잘 쓰고 친구를 잘 구해요.',
        '「살인마 정하기」 설정: 무작위(기본), 1번 자리(방장·혼자 할 땐 나) 먼저, 1번은 생존자만.',
      ] },
    ],
    codex: flCodex(),
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { init, newWorld, tickWorld, stepWorld, aiThink, roundRows, roundOver, nextRound, startPlay, result, snapshot, applySnap, canSee, seeFull, castRay, los, ctxOf, MAPS, PM, KIDS, SEEKERS },
  });
})();
