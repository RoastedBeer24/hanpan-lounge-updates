/* 시장 흥정 — 옛날 장터 상인 게임 (1–4명, 혼자 하기는 별 3개 목표).
   하루(장날) = 아침 장보기(모두 동시에 몰래) → 손님이 한 명씩 찾아와 흥정(그 물건을 가진 상인 모두 동시에 몰래 값 부르기).
   손님(NPC)은 속마음 최고값 M(숨김)이 있고, 흥정할수록 W = M × (0.7→1.0)까지 올려 줘요. 부른 값 ≤ W면 팔리고(가장 싸게 부른 집),
   M보다 비싸면 찡그리고(인내 −2), M × 1.3을 넘으면 화나서 그 집엔 다시 안 가요. 손님이 말하는 값(o)은 W보다 조금 낮아요.
   State (JSON, small): { n, D, d, ph 'm'|'h'|'x', m[] 돈, s[] 재고(14자리 문자열), cb[][] 평균 원가, dk[] 장날 카드 순서,
     mk [[g, 도매값]...], q [[g, 손님종류, M, 인내, 말하는값 비율%, 힌트]...], ci, cu {k, pl, o, x(빠진 상인 비트), lb, ub},
     b[] 이번 단계 부른 값(null/−1 포기), or[] 아침 주문, wh [[g, 손님 수]...] 귓속말, rm 내일 소문을 들은 사람,
     sd[] 오늘 판 개수, de[] 오늘 번 돈, ts[] 모두 판 개수, fin[] 마지막 떨이, seq, last } */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- data ---------- */
  // c: f 곡식·채소, r 과일, s 생선, k 먹거리, x 약재, c 공예품
  const GOODS = [
    { n: '쌀', e: '🌾', b: 12, c: 'f' },
    { n: '고추', e: '🌶️', b: 8, c: 'f' },
    { n: '배추', e: '🥬', b: 6, c: 'f' },
    { n: '사과', e: '🍎', b: 10, c: 'r' },
    { n: '귤', e: '🍊', b: 8, c: 'r' },
    { n: '달걀', e: '🥚', b: 6, c: 'f' },
    { n: '고등어', e: '🐟', b: 12, c: 's' },
    { n: '오징어', e: '🦑', b: 14, c: 's' },
    { n: '떡', e: '🍡', b: 10, c: 'k' },
    { n: '꿀', e: '🍯', b: 18, c: 'k' },
    { n: '인삼', e: '🌿', b: 28, c: 'x' },
    { n: '바구니', e: '🧺', b: 12, c: 'c' },
    { n: '옷감', e: '🧵', b: 22, c: 'c' },
    { n: '도자기', e: '🏺', b: 26, c: 'c' },
  ];
  const NG = GOODS.length;
  /* 손님 종류: p 인내, dm 속마음 배율(기본값 대비), r 말하는 값 비율(속마음 대비) */
  const TY = [
    { n: '깐깐한 할머니', p: 4, dm: [1.25, 1.75], r: [0.55, 0.7], wt: 3 },
    { n: '바쁜 아저씨', p: 2, dm: [1.45, 2.0], r: [0.8, 0.92], wt: 2 },
    { n: '새댁', p: 3, dm: [1.35, 1.9], r: [0.68, 0.82], wt: 3 },
    { n: '부잣집 마님', p: 3, dm: [1.7, 2.4], r: [0.72, 0.86], wt: 1.2 },
    { n: '심부름 꼬마', p: 3, dm: [1.2, 1.65], r: [0.75, 0.9], wt: 2 },
    { n: '주막 주인', p: 3, dm: [1.4, 1.95], r: [0.62, 0.78], wt: 2 },
    { n: '보부상', p: 4, dm: [1.3, 1.8], r: [0.55, 0.7], wt: 1.5 },
    { n: '훈장님', p: 3, dm: [1.5, 2.1], r: [0.65, 0.8], wt: 1.5 },
  ];
  /* 장날 카드: cu 손님 수 ±, pa 인내 ±, rich 부자 손님 많음, m [[대상, 도매배율, 찾는 비중, 값배율]] 대상 = '*' | 분류 글자들 | [물건 번호] */
  const EV = [
    { n: '맑은 장날', ic: '☀️', d: '평범한 장날이에요. 시세 그대로!' },
    { n: '장마', ic: '🌧️', d: '손님이 2명 줄지만 비를 피해 오래 머물러요(인내 +1). 곡식·채소·과일 도매값 ↑', cu: -2, pa: 1, m: [['fr', 1.3, 1, 1.1]] },
    { n: '잔칫날', ic: '🎉', d: '떡·꿀·쌀 찾는 손님이 많고 값도 넉넉히 쳐 줘요(↑).', m: [[[8, 9, 0], 1.1, 3, 1.3]] },
    { n: '풍년', ic: '🌾', d: '곡식·채소·과일이 넘쳐요. 도매값 크게 ↓, 손님 값도 조금 ↓', m: [['fr', 0.6, 1.3, 0.85]] },
    { n: '인삼 소문', ic: '🌿', d: '"인삼이 몸에 좋대!" 인삼·꿀 찾는 손님이 몰리고 값 ↑', m: [[[10, 9], 1.15, 3, 1.4]] },
    { n: '풍랑', ic: '🌊', d: '뱃길이 막혀 고등어·오징어가 귀해요. 도매값 ↑, 손님 값 ↑↑', m: [['s', 1.5, 1.5, 1.5]] },
    { n: '단오장', ic: '🎐', d: '손님 3명 더! 바구니·옷감·도자기 찾는 손님이 많아요.', cu: 3, m: [['c', 1, 2.5, 1.15]] },
    { n: '김장철', ic: '🥬', d: '배추·고추 찾는 손님이 줄을 서요. 값 ↑', m: [[[2, 1], 1.1, 4, 1.4]] },
    { n: '추석 대목', ic: '🌕', d: '손님 2명 더, 모두 값을 넉넉히 쳐 줘요(↑). 쌀·사과·떡 인기!', cu: 2, m: [['*', 1, 1, 1.2], [[0, 3, 8], 1, 1.6, 1]] },
    { n: '사또 행차', ic: '🏮', d: '손님들이 바빠서 인내 −1. 대신 부자 손님이 많아요.', pa: -1, rich: 1, m: [['*', 1, 1, 1.1]] },
    { n: '장돌뱅이 떼', ic: '🎒', d: '떠돌이 장사꾼이 몰려왔어요. 도매값 ↓, 손님도 값을 짜게 쳐요(↓).', m: [['*', 0.85, 1, 0.85]] },
    { n: '가뭄', ic: '🏜️', d: '비가 안 와 쌀·고추·배추·달걀이 귀해요. 도매값 ↑, 손님 값 ↑↑', m: [['f', 1.35, 1, 1.45]] },
  ];
  const CAP = 8, START = 60, NMK = 6, BIDMAX = 150, TOO = 1.3, DMK = 1.12;   // DMK: 손님 속마음 전체 배율
  const STARS = { 4: [100, 150, 200], 5: [120, 180, 240], 7: [150, 240, 330] };

  const R = Math.random;
  const rr = (a, b) => a + R() * (b - a);
  const ri = (n) => Math.floor(R() * n);
  function wpick(ws) { let t = 0; for (const w of ws) t += w; let x = R() * t; for (let i = 0; i < ws.length; i++) { x -= ws[i]; if (x < 0) return i; } return ws.length - 1; }

  function mod(ev, g) {
    let wh = 1, dem = 1, val = 1;
    for (const [sel, a, b, c] of EV[ev].m || []) {
      const hit = sel === '*' || (typeof sel === 'string' ? sel.includes(GOODS[g].c) : sel.includes(g));
      if (hit) { wh *= a; dem *= b; val *= c; }
    }
    return { wh, dem, val };
  }
  const sise = (ev, g) => { const v = GOODS[g].b * mod(ev, g).val * DMK; return [Math.round(v * 1.4), Math.round(v * 1.9)]; };
  const wk = (P0, k) => Math.min(1, 1 - 0.1 * (P0 - 1 - k));               // 손님이 낼 마음(속마음 대비)
  const offerOf = (c, k) => Math.max(1, Math.floor(c[2] * wk(c[3], k) * c[4] / 100));
  const stk = (s, i, g) => s.s[i].charCodeAt(g) - 48;
  function setStk(s, i, g, v) { s.s[i] = s.s[i].slice(0, g) + String.fromCharCode(48 + v) + s.s[i].slice(g + 1); }
  const stkTot = (s, i) => { let t = 0; for (let g = 0; g < NG; g++) t += stk(s, i, g); return t; };
  const nCust = (n, ev) => Math.max(3, (n === 1 ? 6 : 4 + 2 * n) + (EV[ev].cu || 0));
  /* 손님 한 명이 물건 g를 찾을 확률 (생성식과 같음 — AI도 공개 정보로 계산) */
  function demandP(s, g) {
    const ev = s.dk[s.d];
    const mkW = s.mk.map(([x]) => mod(ev, x).dem), mkT = mkW.reduce((a, b) => a + b, 0);
    const allW = GOODS.map((_, x) => mod(ev, x).dem), allT = allW.reduce((a, b) => a + b, 0);
    const k = s.mk.findIndex(([x]) => x === g);
    return (k >= 0 ? 0.85 * mkW[k] / mkT : 0) + 0.15 * allW[g] / allT;
  }

  /* ---------- rules ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(1, Math.min(4, players.length));
    const D = [4, 5, 7].includes(opts.days) ? opts.days : 5;
    const dk = U.shuffle(EV.map((_, i) => i)).slice(0, D);
    const s = {
      n, D, d: 0, ph: 'm', nm: players.slice(0, n).map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 8)), m: Array(n).fill(START), s: Array(n).fill('0'.repeat(NG)), cb: Array.from({ length: n }, () => Array(NG).fill(0)),
      dk, mk: [], q: [], ci: 0, cu: null, b: Array(n).fill(null), or: Array(n).fill(null), wh: [], rm: -1,
      sd: Array(n).fill(0), de: Array(n).fill(0), ts: Array(n).fill(0), fin: null, seq: 0, last: null,
    };
    startDay(s);
    return s;
  }

  function startDay(s) {
    const ev = s.dk[s.d], E = EV[ev], n = s.n;
    // 오늘 도매시장: 장날 카드가 미는 물건 최대 2개 + 나머지 무작위
    const fav = U.shuffle(GOODS.map((_, g) => g).filter((g) => mod(ev, g).dem > 1)).slice(0, 2);
    const rest = U.shuffle(GOODS.map((_, g) => g).filter((g) => !fav.includes(g)));
    const pick = fav.concat(rest).slice(0, NMK).sort((a, b) => a - b);
    s.mk = pick.map((g) => [g, Math.max(1, Math.round(GOODS[g].b * mod(ev, g).wh * rr(0.85, 1.15)))]);
    // 오늘 올 손님들
    const C = nCust(n, ev), q = [];
    const mkW = s.mk.map(([g]) => mod(ev, g).dem), allW = GOODS.map((_, g) => mod(ev, g).dem);
    const tw = TY.map((t, i) => t.wt * (E.rich && (i === 3 || i === 7) ? 3 : 1));
    for (let j = 0; j < C; j++) {
      const g = R() < 0.85 ? s.mk[wpick(mkW)][0] : wpick(allW);
      const t = wpick(tw), T = TY[t];
      const P0 = Math.max(2, Math.min(5, T.p + (E.pa || 0)));
      const dm = rr(T.dm[0], T.dm[1]);
      const M = Math.max(3, Math.round(GOODS[g].b * mod(ev, g).val * dm * DMK));
      q.push([g, t, M, P0, Math.round(rr(T.r[0], T.r[1]) * 100), dm < 1.5 ? 0 : dm < 1.8 ? 1 : 2]);
    }
    s.q = q; s.ci = 0; s.cu = null;
    // 귓속말: 각자 다른 물건의 오늘 손님 수 (나만 봄)
    const order = U.shuffle(s.mk.map(([g]) => g));
    s.wh = Array.from({ length: n }, (_, i) => { const g = order[i % order.length]; return [g, q.filter((c) => c[0] === g).length]; });
    s.rm = s.d + 1 < s.D ? s.d % n : -1;     // 내일 장날 카드를 미리 들은 사람
    s.or = Array(n).fill(null); s.b = Array(n).fill(null);
    s.sd = Array(n).fill(0);
    s.ph = 'm';
  }

  function parts(s) {
    if (s.ph !== 'h' || !s.cu) return [];
    const g = s.q[s.ci][0], r = [];
    for (let i = 0; i < s.n; i++) if (stk(s, i, g) > 0 && !(s.cu.x >> i & 1)) r.push(i);
    return r;
  }
  function actor(s) {
    if (s.ph === 'm') return Array.from({ length: s.n }, (_, i) => i);
    if (s.ph === 'h') return parts(s);
    return null;
  }

  function nextCustomer(s, sk) {
    while (s.ci < s.q.length) {
      const c = s.q[s.ci];
      let any = false;
      for (let i = 0; i < s.n; i++) if (stk(s, i, c[0]) > 0) any = true;
      if (any) { s.cu = { k: 0, pl: c[3], o: offerOf(c, 0), x: 0, lb: 0, ub: 0 }; s.b = Array(s.n).fill(null); return false; }
      sk.push(c[0]); s.ci++;
    }
    return endDay(s);
  }
  /* returns true when the day ended */
  function endDay(s) {
    s.cu = null; s.b = Array(s.n).fill(null);
    if (s.d + 1 >= s.D) {
      s.fin = Array(s.n).fill(0);
      for (let i = 0; i < s.n; i++) {
        for (let g = 0; g < NG; g++) s.fin[i] += stk(s, i, g) * Math.floor(GOODS[g].b / 2);
        s.m[i] += s.fin[i];
        s.s[i] = '0'.repeat(NG);
      }
      s.ph = 'x';
    } else { s.d++; startDay(s); }
    return true;
  }

  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (s.ph === 'm') {
      if (s.or[seat] != null) throw new Error('already shopped');
      const list = Array.isArray(a.o) ? a.o : [];
      let cost = 0, qty = 0;
      const seen = {}, ord = [];
      for (const it of list) {
        if (!Array.isArray(it)) throw new Error('bad item');
        const g = it[0] | 0, q = it[1] | 0;
        const mk = s.mk.find(([x]) => x === g);
        if (!mk || q < 1 || q > CAP || seen[g]) throw new Error('bad item');
        seen[g] = 1; cost += mk[1] * q; qty += q; ord.push([g, q]);
      }
      if (cost > s.m[seat]) throw new Error('not enough money');
      if (stkTot(s, seat) + qty > CAP) throw new Error('stall full');
      s.or[seat] = ord;
      if (s.or.every((x) => x != null)) {
        for (let i = 0; i < s.n; i++) for (const [g, q] of s.or[i]) {
          const p = s.mk.find(([x]) => x === g)[1], old = stk(s, i, g);
          s.m[i] -= p * q;
          s.cb[i][g] = Math.round(((s.cb[i][g] || p) * old + p * q) / (old + q));
          setStk(s, i, g, old + q);
        }
        s.de = Array(s.n).fill(0);
        s.ph = 'h';
        const sk = [];
        const nd = nextCustomer(s, sk);
        s.last = { id: ++s.seq, k: 'm', d: s.d - (nd ? 1 : 0), sk, nd: nd ? 1 : 0 };
      }
      return s;
    }
    if (s.ph === 'h') {
      const P = parts(s);
      if (!P.includes(seat)) throw new Error('not in this haggle');
      if (s.b[seat] != null) throw new Error('already bid');
      const p = a.p | 0;
      if (!(p === -1 || (p >= 1 && p <= BIDMAX))) throw new Error('bad price');
      s.b[seat] = p;
      if (P.every((i) => s.b[i] != null)) resolve(s, P);
      return s;
    }
    throw new Error('game over');
  }

  function resolve(s, P) {
    const c = s.q[s.ci], cu = s.cu, g = c[0], M = c[2];
    const W = M * wk(c[3], cu.k);
    const bids = s.b.slice(), re = Array(s.n).fill(0);
    const snap = { g, t: c[1], h: c[5], o: cu.o, pl: cu.pl, P: c[3], k: cu.k, lb: cu.lb, ub: cu.ub };
    const acc = P.filter((i) => s.b[i] > 0 && s.b[i] <= W + 1e-9);
    let win = -1, price = 0, end = 0;
    const judge = (i) => {
      const b = s.b[i];
      if (b === -1) return 4;
      if (b <= M) return 1;
      if (b <= M * TOO) return 2;
      return 3;
    };
    if (acc.length) {
      price = Math.min(...acc.map((i) => s.b[i]));
      let cand = acc.filter((i) => s.b[i] === price);
      const fewest = Math.min(...cand.map((i) => s.sd[i]));
      cand = cand.filter((i) => s.sd[i] === fewest);
      win = cand[ri(cand.length)];
      s.m[win] += price; s.de[win] += price; s.sd[win]++; s.ts[win]++;
      setStk(s, win, g, stk(s, win, g) - 1);
      P.forEach((i) => { re[i] = i === win ? 5 : acc.includes(i) ? 6 : judge(i); });
      end = 1;
    } else {
      let close = false, anyBid = false;
      P.forEach((i) => {
        const j = judge(i), b = s.b[i];
        re[i] = j;
        if (j !== 4) anyBid = true;
        if (j === 1) { close = true; cu.lb = Math.max(cu.lb, b); }
        if (j === 2) cu.ub = Math.min(cu.ub || 999, b - 1);
        if (j === 3) cu.ub = Math.min(cu.ub || 999, Math.ceil(b / TOO) - 1);
        if (j === 3 || j === 4) cu.x |= 1 << i;
      });
      const annoyed = anyBid && !close;
      cu.pl -= annoyed ? 2 : 1;
      cu.k++;
      if (cu.pl <= 0) end = 2;
      else if (!parts(s).length) end = 3;
      else { cu.o = Math.max(cu.o, offerOf(c, cu.k)); s.b = Array(s.n).fill(null); }
      snap.an = annoyed ? 1 : 0;
    }
    const last = { id: ++s.seq, k: 's', c: snap, a: bids, r: re, w: win, p: price, e: end, sk: [], nd: 0 };
    if (end) {
      last.M = M;
      s.ci++;
      const d0 = s.d;
      if (nextCustomer(s, last.sk)) { last.nd = 1; last.de = s.de.slice(); last.d = d0; }
    }
    s.last = last;
  }

  function result(s) {
    if (s.ph !== 'x') return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const fin = s.fin || Array(s.n).fill(0);
    const line = (i) => s.m[i] + '냥 · 판 물건 ' + s.ts[i] + '개' + (fin[i] ? ' (떨이 +' + fin[i] + ')' : '');
    if (s.n === 1) {
      const need = STARS[s.D] || STARS[5], st = need.filter((v) => s.m[0] >= v).length;
      return { winners: st ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요', text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + line(0) + '\n별 기준 ' + need.join(' / ') + '냥' };
    }
    const top = Math.max(...s.m);
    const winners = s.m.map((v, i) => (v === top ? i : -1)).filter((i) => i >= 0);
    const order = s.m.map((_, i) => i).sort((a, b) => s.m[b] - s.m[a] || a - b);
    return { winners, title: winners.length > 1 ? '공동 우승' : nm(winners[0]) + ' 우승!', text: order.map((i) => (s.m.filter((v) => v > s.m[i]).length + 1) + '위  ' + nm(i) + '  ' + line(i)).join('\n') };
  }

  /* ---------- AI ---------- */
  function poisTail(lam, j) {      // P(X ≥ j)
    if (j <= 0) return 1;
    let p = Math.exp(-lam), c = p;
    for (let i = 1; i < j; i++) { p *= lam / i; c += p; }
    return Math.max(0, 1 - c);
  }
  function buyPlan(s, seat, lv) {
    const ev = s.dk[s.d], lastDay = s.d === s.D - 1, C = s.q.length;
    const nev = s.d + 1 < s.D ? s.dk[s.d + 1] : -1;
    let money = s.m[seat], room = CAP - stkTot(s, seat);
    const skill = lv === 1 ? 1.05 : lv === 2 ? 0.86 : 0.9;
    const share = lv === 1 ? 1 : 1 / (1 + (lv === 3 ? 0.55 : 0.45) * (s.n - 1));
    const info = s.mk.map(([g, p]) => {
      let lam = C * demandP(s, g);
      if (lv === 3 && s.wh[seat] && s.wh[seat][0] === g) lam = s.wh[seat][1];
      lam *= share;
      const v = GOODS[g].b * mod(ev, g).val * DMK * 1.62 * skill * (lv === 1 ? rr(0.7, 1.35) : 1);
      let carry = lastDay ? Math.floor(GOODS[g].b / 2) : GOODS[g].b * 0.75;
      if (lv === 3 && nev >= 0 && s.rm === seat) carry *= Math.min(1.5, mod(nev, g).val * Math.sqrt(mod(nev, g).dem));
      return { g, p, lam, v, carry, have: stk(s, seat, g), buy: 0 };
    });
    const thr = lv === 1 ? -1 : lv === 2 ? 0.6 : 1;
    for (let guard = 0; guard < 20 && room > 0; guard++) {
      let best = null, bg = thr;
      for (const it of info) {
        if (it.p > money) continue;
        const j = it.have + it.buy + 1, P = poisTail(it.lam, j);
        const gain = P * it.v + (1 - P) * it.carry - it.p;
        if (gain > bg) { bg = gain; best = it; }
      }
      if (!best) break;
      best.buy++; money -= best.p; room--;
    }
    // 쉬움: 가끔 충동구매
    if (lv === 1 && room > 0 && R() < 0.5) {
      const it = info[ri(info.length)];
      if (it.p <= money) { it.buy++; money -= it.p; room--; }
    }
    return info.filter((it) => it.buy > 0).map((it) => [it.g, it.buy]);
  }

  /* 공개 정보로 손님 속마음(M) 범위 짐작 */
  function estimate(s) {
    const c = s.q[s.ci], cu = s.cu, g = c[0], T = TY[c[1]], ev = s.dk[s.d];
    const base = GOODS[g].b * mod(ev, g).val * DMK;
    const h = c[5], cuts = [[T.dm[0], 1.5], [1.5, 1.8], [1.8, T.dm[1]]][h];
    const dlo = Math.max(T.dm[0], cuts[0]), dhi = Math.min(T.dm[1], cuts[1]);
    const w = wk(c[3], cu.k);
    let lo = Math.max(base * Math.min(dlo, dhi) - 0.5, cu.o / (w * T.r[1]), cu.lb || 0);
    let hi = Math.min(base * Math.max(dlo, dhi) + 0.5, (cu.o + 1) / (w * T.r[0]));
    if (cu.ub) hi = Math.min(hi, cu.ub);
    if (lo > hi) { const m = (lo + hi) / 2; lo = hi = m; }
    return { lo, hi, w, mid: (lo + hi) / 2 };
  }
  function bidFor(s, seat, lv) {
    const c = s.q[s.ci], cu = s.cu, g = c[0];
    const cost = s.cb[seat][g] || GOODS[g].b;
    const E = estimate(s), o = cu.o, w = E.w;
    const lastStep = cu.pl <= 1, lastDay = s.d === s.D - 1;
    const rivals = parts(s).filter((i) => i !== seat).length;
    const cl = (x) => Math.max(1, Math.min(BIDMAX, Math.round(x)));
    if (lv === 1) {
      const Mh = o / (w * 0.75);
      if (R() < (lastStep ? 0.6 : 0.3)) return o;
      return cl(Mh * rr(0.85, 1.42));
    }
    const safe = Math.max(o, Math.floor(E.lo * w));
    if (lv === 2) {
      if (lastStep && safe < cost * 0.9 && !lastDay && R() < 0.6) return -1;
      if (rivals > 0) return R() < 0.5 ? o : cl(o + (E.mid * w - o) * 0.5);
      if (lastStep) return o;
      return cl(E.mid * rr(0.92, 1.05));
    }
    // lv 3
    const keep = !lastDay && stk(s, seat, g) <= 1 && s.q.slice(s.ci + 1).some((q) => q[0] === g);
    if (rivals > 0) {
      if (safe < cost * 0.85 && !lastDay) return lastStep || keep ? -1 : cl(Math.max(safe, cost));
      return safe;
    }
    let x;
    if (lastStep) x = safe;
    else if (cu.pl === 2) x = Math.max(o, Math.floor(E.lo * wk(c[3], cu.k + 1)));
    else x = E.hi - E.lo < 2 ? Math.floor(E.lo) : Math.floor(E.lo + (E.hi - E.lo) * 0.4);
    x = Math.max(o, x);
    if (lastStep && x < cost * 0.85 && (!lastDay && (keep || R() < 0.7))) return -1;
    return cl(x);
  }

  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'm') return s.or[seat] != null ? null : { o: buyPlan(s, seat, lv) };
    if (s.ph === 'h') return (s.b[seat] != null || !parts(s).includes(seat)) ? null : { p: bidFor(s, seat, lv) };
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'm') {
      if (s.or[seat] != null) return -1;
      const done = s.or.filter((x) => x != null).length;
      return Math.max(700, [0, 2600, 2000, 1600][lv || 2] - done * 400);
    }
    if (s.ph === 'h') {
      if (s.b[seat] != null) return -1;
      const done = s.b.filter((x) => x != null).length;
      return Math.max(350, [0, 1300, 1050, 900][lv || 2] - done * 250);
    }
    return -1;
  }

  /* ---------- view ---------- */
  const CSS = `
.bz{position:absolute;inset:0;display:flex;flex-direction:column;overflow:hidden;color:var(--ink);
  background:linear-gradient(180deg,#2a1d33 0%,#3a2632 34%,#4a3328 62%,#2c2019 100%)}
.bz-stalls{display:grid;gap:5px;padding:6px 8px 0;flex:none;position:relative;z-index:3}
.bz-st{position:relative;border-radius:10px;background:linear-gradient(#5b3e26,#3d2817);border:1px solid rgba(0,0,0,.35);min-width:0;padding:0 0 4px;box-shadow:0 3px 8px rgba(0,0,0,.35);transition:box-shadow .2s,transform .2s}
.bz-st .aw{height:9px;border-radius:9px 9px 0 0;background:repeating-linear-gradient(90deg,var(--c) 0 10px,#f4ead6 10px 20px);box-shadow:0 2px 0 rgba(0,0,0,.25)}
.bz-st .r1{display:flex;align-items:center;gap:4px;padding:3px 6px 0;font-size:11.5px;font-weight:700;min-width:0}
.bz-st .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.bz-st .mo{font-family:var(--f-mono);color:#ffd77a;font-size:13px;font-weight:600;flex:none}
.bz-st .r2{display:flex;align-items:center;justify-content:space-between;gap:4px;padding:1px 6px 0;font-size:11px;color:#e9d8bd;min-height:16px;white-space:nowrap;overflow:hidden}
.bz-st .r2 span:first-child{min-width:0;overflow:hidden;text-overflow:ellipsis}.bz-st .r2 span:last-child{flex:none}
.bz-st.me{box-shadow:0 0 0 2px var(--brass),0 3px 8px rgba(0,0,0,.35)}
.bz-st.win{transform:translateY(-2px);box-shadow:0 0 0 2px #ffd77a,0 0 18px rgba(255,215,122,.6)}
.bz-st.off{opacity:.55}
.bz-bub{position:absolute;left:50%;top:calc(100% + 4px);transform:translateX(-50%);background:#f6eedc;color:#2a1d05;border-radius:12px;padding:3px 8px;font-weight:800;font-size:13px;white-space:nowrap;box-shadow:0 4px 10px rgba(0,0,0,.4);z-index:5;animation:bzPop .28s cubic-bezier(.2,.9,.3,1.4) both;font-family:var(--f-mono)}
.bz-bub:before{content:"";position:absolute;left:50%;top:-5px;margin-left:-5px;border:5px solid transparent;border-top:0;border-bottom-color:#f6eedc}
.bz-bub.good{background:#ffe08a}
.bz-bub.bad{background:#f3b3a6}
@keyframes bzPop{from{transform:translateX(-50%) scale(.3);opacity:0}to{transform:translateX(-50%) scale(1);opacity:1}}
.bz-bar{display:flex;align-items:center;gap:6px;padding:6px 8px 2px;flex:none;min-width:0}
.bz-day{font-family:var(--f-mono);font-size:12px;font-weight:700;background:rgba(0,0,0,.3);border-radius:999px;padding:4px 9px;flex:none}
.bz-ev{appearance:none;font:inherit;color:var(--ink);flex:1;min-width:0;display:flex;align-items:center;gap:6px;background:rgba(227,174,69,.14);border:1px solid rgba(227,174,69,.45);border-radius:999px;padding:3px 10px;min-height:30px;cursor:pointer;text-align:left}
.bz-ev b{flex:none;font-size:13px}
.bz-ev span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11.5px;color:#e9d8bd}
.bz-main{flex:1 1 auto;min-height:0;position:relative;display:flex;flex-direction:column}
/* morning */
.bz-mor{flex:1;min-height:0;display:flex;flex-direction:column;gap:6px;padding:4px 8px 6px;overflow-y:auto}
.bz-whisper{background:rgba(20,14,26,.6);border:1px dashed rgba(227,174,69,.55);border-radius:12px;padding:6px 10px;font-size:12.5px;line-height:1.45;flex:none}
.bz-whisper b{color:#ffd77a}
.bz-whisper .y{color:var(--muted);font-size:11.5px}
.bz-market{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:1fr;gap:6px;flex:1 0 auto;max-height:470px}
.bz-card{position:relative;border-radius:12px;background:linear-gradient(#f6eedc,#e6d6b6);color:#2a1d05;padding:6px 7px 5px;display:flex;flex-direction:column;justify-content:space-between;gap:3px;box-shadow:0 4px 10px rgba(0,0,0,.35);min-width:0}
.bz-card.hot:after{content:"인기";position:absolute;right:6px;top:5px;background:var(--coral);color:#2b0c06;font-size:10px;font-weight:800;border-radius:999px;padding:1px 6px}
.bz-card .t{display:flex;align-items:center;gap:6px;min-width:0}
.bz-card .em{font-size:24px;line-height:1;flex:none}
.bz-card .gn{font-family:var(--f-display);font-size:16px;line-height:1.1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bz-card .hv{font-size:10.5px;color:#6b5434;font-weight:700}
.bz-card .pr{display:flex;justify-content:space-between;align-items:baseline;font-size:11px;font-weight:700;color:#6b5434;gap:4px}
.bz-card .pr b{font-family:var(--f-mono);font-size:15px;color:#7a3b10}
.bz-step{display:flex;align-items:center;gap:4px}
.bz-step .btn{min-height:44px;width:44px;padding:0;font-size:22px;flex:none;background:#3d2817;color:#f6eedc;border-color:rgba(0,0,0,.3)}
.bz-step .v{flex:1;text-align:center;font-family:var(--f-mono);font-size:20px;font-weight:700}
.bz-foot{flex:none;display:flex;align-items:center;gap:8px;padding:8px;background:linear-gradient(rgba(23,19,31,0),rgba(23,19,31,.92) 25%)}
.bz-foot .sum{flex:1;min-width:0;font-size:12px;color:var(--muted);font-weight:700;line-height:1.35}
.bz-foot .sum b{font-family:var(--f-mono);color:var(--ink);font-size:14px}
.bz-foot .btn{min-height:50px;flex:none;padding:8px 18px;font-size:15px}
/* haggle */
.bz-scene{flex:1 1 auto;min-height:0;position:relative;display:flex;flex-direction:column;justify-content:space-evenly;gap:4px;padding:12px 10px 0;overflow:hidden}
.bz-scene>*{flex:none}
.bz-who{display:flex;align-items:flex-start;gap:8px}
.bz-facebox{position:relative;flex:none;display:flex;flex-direction:column;align-items:center;gap:2px}
.bz-face{display:block}
.bz-facebox.in{animation:bzWalk var(--wd,.5s) cubic-bezier(.2,.8,.3,1) both}
.bz-facebox.out{animation:bzLeave var(--wd,.5s) ease-in both}
.bz-facebox.bob .bz-face{animation:bzBob .35s ease-out}
@keyframes bzWalk{from{transform:translateX(-120%);opacity:0}to{transform:none;opacity:1}}
@keyframes bzLeave{to{transform:translateX(140%);opacity:0}}
@keyframes bzBob{0%{transform:translateY(0)}40%{transform:translateY(-6px)}100%{transform:translateY(0)}}
.bz-tn{font-size:11.5px;font-weight:700;color:#f0dfc2;white-space:nowrap}
.bz-pat{display:flex;gap:3px;align-items:center;font-size:10.5px;color:var(--muted)}
.bz-pat i{width:9px;height:9px;border-radius:50%;background:#ee6a55;display:block;box-shadow:inset 0 -2px 0 rgba(0,0,0,.25)}
.bz-pat i.e{background:rgba(255,255,255,.18)}
.bz-say{position:relative;flex:1;min-width:0;background:#f6eedc;color:#2a1d05;border-radius:14px;padding:8px 10px;font-size:14px;line-height:1.4;font-weight:600;box-shadow:0 6px 14px rgba(0,0,0,.35);margin-top:8px}
.bz-say:before{content:"";position:absolute;left:-7px;top:18px;border:7px solid transparent;border-left:0;border-right-color:#f6eedc}
.bz-say .of{display:block;margin-top:3px;font-weight:800;color:#7a3b10;font-size:16px}
.bz-say.pop{animation:bzSay .25s ease-out}
.bz-who.col{flex-direction:column-reverse;align-items:center;gap:10px}
.bz-who.col .bz-say{flex:none;max-width:94%;margin-top:0;text-align:center;font-size:15px}
.bz-who.col .bz-say:before{left:50%;top:auto;bottom:-7px;margin-left:-7px;border:7px solid transparent;border-bottom:0;border-top-color:#f6eedc}
@keyframes bzSay{from{transform:scale(.88)}to{transform:none}}
.bz-want{display:flex;flex-wrap:wrap;gap:5px;align-items:center;justify-content:center;font-size:12px}
.bz-chip{background:rgba(0,0,0,.32);border:1px solid rgba(255,255,255,.12);border-radius:999px;padding:3px 9px;white-space:nowrap;font-weight:700}
.bz-chip b{font-family:var(--f-mono);color:#ffd77a}
.bz-clue{text-align:center;font-size:11.5px;color:#e9d8bd;min-height:15px}
.bz-counter{position:relative;flex:none;margin:30px -10px 0;height:22px;background:linear-gradient(#8a6040,#4a3020);border-top:2px solid #b08055;box-shadow:0 -2px 6px rgba(0,0,0,.3);pointer-events:none}
.bz-counter .it{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);font-size:32px;line-height:1;filter:drop-shadow(0 3px 2px rgba(0,0,0,.45))}
.bz-counter .it.n2{margin-left:-14px}.bz-counter .it.n3{margin-left:14px}
.bz-ctl{flex:none;padding:6px 8px 8px;display:flex;flex-direction:column;gap:6px;background:linear-gradient(rgba(23,19,31,.4),rgba(23,19,31,.95) 20%);position:relative;z-index:2}
.bz-amt{display:flex;align-items:center;gap:5px}
.bz-amt .btn{width:48px;min-height:48px;padding:0;font-size:16px;flex:none;font-family:var(--f-mono)}
.bz-amt .v{flex:1;min-width:0;text-align:center;line-height:1}
.bz-amt .v b{font-family:var(--f-mono);font-size:34px;color:var(--brass);font-weight:700}
.bz-amt .v small{display:block;font-size:11px;color:var(--muted);font-weight:700;margin-top:2px;white-space:nowrap}
.bz-range{width:100%;accent-color:var(--brass);height:26px;margin:0}
.bz-quick{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}
.bz-quick .btn{min-height:44px;padding:2px 4px;font-size:12px;line-height:1.15;flex-direction:column;gap:0}
.bz-quick .btn b{font-family:var(--f-mono);font-size:14px}
.bz-go{display:flex;gap:6px}
.bz-go .btn{min-height:50px}
.bz-go .primary{flex:1;font-size:16px}
.bz-wait{text-align:center;font-size:13px;color:#e9d8bd;font-weight:700;padding:10px 6px 14px;line-height:1.5}
.bz-wait b{color:var(--brass);font-family:var(--f-mono)}
.bz-banner{position:absolute;left:50%;top:38%;transform:translate(-50%,-50%);z-index:8;background:linear-gradient(#f6eedc,#e6d6b6);color:#2a1d05;border-radius:16px;padding:14px 18px;box-shadow:0 16px 40px rgba(0,0,0,.6),0 0 0 3px #6b4a24;text-align:center;width:min(300px,86%);animation:bzBan .35s cubic-bezier(.2,.9,.3,1.3) both;cursor:pointer}
.bz-banner .ic{font-size:40px;line-height:1.1}
.bz-banner .t{font-family:var(--f-display);font-size:24px;margin:2px 0}
.bz-banner .d{font-size:13px;line-height:1.45;font-weight:600}
.bz-banner .s{font-size:11.5px;color:#6b5434;margin-top:6px;font-weight:700}
@keyframes bzBan{from{transform:translate(-50%,-50%) scale(.6);opacity:0}to{transform:translate(-50%,-50%) scale(1);opacity:1}}
.bz-coin{position:absolute;z-index:9;width:22px;height:22px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff0b8,#e3ae45 55%,#8a5c10);box-shadow:0 2px 6px rgba(0,0,0,.5);pointer-events:none}
.bz-hand{position:absolute;inset:0;z-index:10;background:rgba(18,13,24,.97);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:20px}
.bz-hand .big{font-family:var(--f-display);font-size:28px}
.bz-hand .btn{min-height:52px;padding:10px 26px}
.bz-sheet{position:absolute;inset:0;z-index:11;background:rgba(10,8,14,.7);display:flex;align-items:center;justify-content:center;padding:16px}
.bz-sheet .in{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:14px;max-width:340px;width:100%;max-height:100%;overflow:auto;font-size:13px;line-height:1.5}
.bz-sheet h3{font-family:var(--f-display);font-size:20px;margin:0 0 6px}
.bz-sheet .btn{width:100%;margin-top:10px}
@media (max-height:700px){
  .bz-card .em{font-size:20px}.bz-card{padding:5px 6px 4px;gap:2px}.bz-card .gn{font-size:15px}
  .bz-amt .v b{font-size:28px}.bz-say{font-size:13px;padding:6px 9px}.bz-scene{padding-top:10px}
  .bz-whisper{padding:5px 9px;font-size:12px}
}
`;

  const josa = (w, a, b) => { const c = w.charCodeAt(w.length - 1); return w + (c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b); };
  const LINES = {
    h: [
      ['주머니가 가벼워서… {g} 싸게 좀 줘요.', '{g} 있어요? 많이는 못 드려요.', '살림이 빠듯해서요. {g} 하나만요.'],
      ['{g} 하나 주세요. 값만 맞으면 사 갈게요.', '{g} 찾는데, 얼마예요?', '좋은 {g} 있으면 보여 줘요.'],
      ['{g} 급하게 필요해요! 값은 좀 쳐 줄게요.', '좋은 {g}면 값은 걱정 말아요.', '오늘 꼭 {g} 사 가야 해요!'],
    ],
    first: ['{o}냥이면 살게요.', '{o}냥에 주세요~', '{o}냥 어때요?'],
    next: ['그럼 {o}냥 어때요?', '좋아요, {o}냥까지!', '{o}냥! 이 정도면 됐죠?'],
    lastO: ['마지막이에요, {o}냥!', '{o}냥! 더는 안 돼요~'],
    sale: ['좋아요, {p}냥에 살게요!', '거래 끝! 잘 쓸게요~', '덤도 주시는 거죠? 호호', '잘 샀다~ {p}냥이면 괜찮네요.'],
    saleOther: ['저 집이 더 싸네요~ 거기서 살게요.', '{w} 가게가 제일 싸네요!'],
    close: ['음… 조금만 깎아 주면 생각해 볼게요.', '그 값이면 고민되네…', '아유, 조금만 더 빼 줘요~'],
    pricey: ['에구, 너무 비싸요!', '옆 장터는 더 싸던데요?', '그 값은 좀…'],
    angry: ['그 값엔 못 사요! 그 집엔 안 가요.', '날강도 아니에요? 흥!'],
    left: ['에잇, 그냥 갈래요.', '다음 장에 올게요~', '오늘은 안 사고 갈래요.'],
    leftA: ['다들 너무 비싸요! 그냥 갈래요.', '흥, 다른 장터로 가야겠어요.'],
    nobody: ['아무도 안 판다고요? 그럼 가야지…'],
  };
  const pick = (arr, seed) => arr[((seed % arr.length) + arr.length) % arr.length];
  const fill = (t, o) => t.replace(/\{(\w)\}/g, (_, k) => (o[k] != null ? o[k] : ''));

  /* 손님 얼굴 (canvas, 100×110 좌표) */
  const LOOK = [
    { hair: '#d9d3ca', hat: 'kerchief', cloth: '#7d6a9e', wr: 1 },
    { hair: '#2b2420', hat: 'band', cloth: '#8a6d4a', stub: 1 },
    { hair: '#1f1a1a', hat: 'pin', cloth: '#e98aa0', blush: 1 },
    { hair: '#1f1a1a', hat: 'rich', cloth: '#7a2f5a', blush: 1 },
    { hair: '#2a2220', hat: 'braid', cloth: '#e2b347', kid: 1 },
    { hair: '#2a1f1a', hat: 'scarf', cloth: '#5e8a6a' },
    { hair: '#2a2220', hat: 'straw', cloth: '#a08660' },
    { hair: '#8e8a84', hat: 'gat', cloth: '#e8e2d4', beard: 1 },
  ];
  function drawFace(ctx, S, t, ex) {
    const k = S / 100, lk = LOOK[t] || LOOK[0];
    ctx.save(); ctx.scale(k, k * 1); ctx.clearRect(0, 0, 100, 110);
    const skin = '#f0c9a0', ink = '#3a2418';
    const C = (c) => { ctx.fillStyle = c; };
    const E = (x, y, rx, ry, c) => { ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); C(c); ctx.fill(); };
    // body (저고리)
    ctx.beginPath(); ctx.moveTo(14, 110); ctx.quadraticCurveTo(18, 80, 50, 78); ctx.quadraticCurveTo(82, 80, 86, 110); ctx.closePath(); C(lk.cloth); ctx.fill();
    ctx.beginPath(); ctx.moveTo(40, 80); ctx.lineTo(50, 100); ctx.lineTo(60, 80); ctx.lineWidth = 5; ctx.strokeStyle = '#f4efe4'; ctx.stroke();
    if (t === 4 || t === 2 || t === 3) { ctx.beginPath(); ctx.moveTo(50, 98); ctx.quadraticCurveTo(58, 104, 62, 110); ctx.lineWidth = 3; ctx.strokeStyle = t === 4 ? '#c0392b' : '#b03060'; ctx.stroke(); }
    // back hair
    if (t === 2 || t === 3 || t === 4 || t === 5) E(50, 42, 31, 32, lk.hair);
    if (t === 2) E(50, 70, 13, 9, lk.hair);
    // head
    E(50, 48, 27, 29, skin);
    E(23, 50, 4, 6, skin); E(77, 50, 4, 6, skin);
    // hair / hats
    ctx.lineCap = 'round';
    if (lk.hat === 'kerchief') {
      E(50, 30, 27, 15, lk.hair);
      ctx.beginPath(); ctx.moveTo(20, 34); ctx.quadraticCurveTo(50, 2, 80, 34); ctx.quadraticCurveTo(50, 22, 20, 34); C('#f2ede2'); ctx.fill();
      E(50, 14, 8, 6, lk.hair);
    } else if (lk.hat === 'band') {
      ctx.beginPath(); ctx.ellipse(50, 30, 27, 16, 0, Math.PI, 0); C(lk.hair); ctx.fill();
      ctx.fillStyle = '#f4efe4'; ctx.fillRect(22, 28, 56, 7);
      ctx.beginPath(); ctx.moveTo(76, 30); ctx.lineTo(86, 24); ctx.lineTo(84, 34); C('#f4efe4'); ctx.fill();
    } else if (lk.hat === 'pin') {
      ctx.beginPath(); ctx.moveTo(22, 46); ctx.quadraticCurveTo(24, 16, 50, 18); ctx.quadraticCurveTo(76, 16, 78, 46); ctx.quadraticCurveTo(66, 26, 50, 26); ctx.quadraticCurveTo(34, 26, 22, 46); C(lk.hair); ctx.fill();
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(34, 72); ctx.lineTo(66, 68); ctx.stroke();
    } else if (lk.hat === 'rich') {
      E(50, 16, 24, 10, lk.hair);
      ctx.beginPath(); ctx.moveTo(22, 46); ctx.quadraticCurveTo(24, 18, 50, 20); ctx.quadraticCurveTo(76, 18, 78, 46); ctx.quadraticCurveTo(66, 28, 50, 28); ctx.quadraticCurveTo(34, 28, 22, 46); C(lk.hair); ctx.fill();
      E(50, 12, 4, 4, '#e3ae45'); E(36, 15, 3, 3, '#4fb3a0'); E(64, 15, 3, 3, '#4fb3a0');
    } else if (lk.hat === 'braid') {
      ctx.beginPath(); ctx.moveTo(22, 44); ctx.quadraticCurveTo(26, 16, 50, 18); ctx.quadraticCurveTo(74, 16, 78, 44); ctx.quadraticCurveTo(64, 30, 50, 34); ctx.quadraticCurveTo(36, 30, 22, 44); C(lk.hair); ctx.fill();
      ctx.fillStyle = '#d23b3b'; ctx.beginPath(); ctx.moveTo(78, 60); ctx.lineTo(90, 72); ctx.lineTo(84, 76); ctx.closePath(); ctx.fill();
      E(80, 58, 4, 5, lk.hair);
    } else if (lk.hat === 'scarf') {
      ctx.beginPath(); ctx.moveTo(20, 40); ctx.quadraticCurveTo(50, 2, 80, 40); ctx.quadraticCurveTo(50, 26, 20, 40); C('#3f7fa8'); ctx.fill();
      E(80, 30, 6, 4, '#3f7fa8'); E(86, 34, 5, 3, '#3f7fa8');
    } else if (lk.hat === 'straw') {
      ctx.beginPath(); ctx.ellipse(50, 32, 27, 14, 0, Math.PI, 0); C(lk.hair); ctx.fill();
      E(50, 26, 40, 6, '#c9a463');
      ctx.beginPath(); ctx.moveTo(30, 26); ctx.quadraticCurveTo(50, -2, 70, 26); C('#d8b676'); ctx.fill();
      E(18, 30, 5, 5, '#f4efe4'); E(82, 30, 5, 5, '#f4efe4');
    } else if (lk.hat === 'gat') {
      ctx.beginPath(); ctx.ellipse(50, 32, 27, 13, 0, Math.PI, 0); C(lk.hair); ctx.fill();
      ctx.globalAlpha = 0.9; E(50, 25, 42, 6, '#1d1a1c'); ctx.globalAlpha = 1;
      ctx.fillStyle = '#1d1a1c'; ctx.fillRect(38, 4, 24, 21);
      E(50, 4, 12, 3, '#1d1a1c');
      ctx.strokeStyle = '#1d1a1c'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(28, 28); ctx.lineTo(30, 66); ctx.moveTo(72, 28); ctx.lineTo(70, 66); ctx.stroke();
    }
    // face features
    const eyY = 50, mY = 66;
    ctx.strokeStyle = ink; ctx.fillStyle = ink; ctx.lineWidth = 2.6;
    const brow = (x, dy, tilt) => { ctx.beginPath(); ctx.moveTo(x - 6, eyY - 9 + dy - tilt); ctx.lineTo(x + 6, eyY - 9 + dy + tilt); ctx.stroke(); };
    const eyeR = lk.kid ? 3.6 : 2.8;
    if (ex === 'h') {
      [39, 61].forEach((x) => { ctx.beginPath(); ctx.arc(x, eyY + 1, 4.5, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); });
    } else if (ex === 's') {
      [39, 61].forEach((x) => { ctx.beginPath(); ctx.arc(x, eyY - 1, 4, Math.PI * 0.1, Math.PI * 0.9); ctx.stroke(); });
    } else {
      E(39, eyY, eyeR, eyeR + (ex === 'a' ? 0 : 0.6), ink); E(61, eyY, eyeR, eyeR + (ex === 'a' ? 0 : 0.6), ink);
      if (lk.kid) { E(40, eyY - 1.2, 1.1, 1.1, '#fff'); E(62, eyY - 1.2, 1.1, 1.1, '#fff'); }
    }
    if (ex === 't') { brow(39, -1, 0); brow(61, -4, -2.5); }
    else if (ex === 'p') { brow(39, 1, 2.5); brow(61, 1, -2.5); }
    else if (ex === 'a') { ctx.lineWidth = 3.4; brow(39, 2, 4); brow(61, 2, -4); ctx.lineWidth = 2.6; }
    else if (ex === 's') { brow(39, -1, -2.5); brow(61, -1, 2.5); }
    else if (lk.wr) { brow(39, 0, 0.5); brow(61, 0, -0.5); }
    // cheeks
    if (lk.blush || ex === 'h' || lk.kid) { ctx.globalAlpha = 0.35; E(31, 60, 5, 3, '#e8616a'); E(69, 60, 5, 3, '#e8616a'); ctx.globalAlpha = 1; }
    if (ex === 'a') { ctx.globalAlpha = 0.35; E(50, 52, 26, 22, '#e2403a'); ctx.globalAlpha = 1; }
    if (lk.wr) { ctx.lineWidth = 1.2; ctx.globalAlpha = 0.55; ctx.beginPath(); ctx.moveTo(27, 56); ctx.lineTo(31, 58); ctx.moveTo(73, 56); ctx.lineTo(69, 58); ctx.moveTo(43, 35); ctx.lineTo(57, 35); ctx.stroke(); ctx.globalAlpha = 1; ctx.lineWidth = 2.6; }
    // nose
    ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(50, 54); ctx.quadraticCurveTo(53, 59, 49, 60); ctx.stroke();
    // beard / stubble
    if (lk.beard) { ctx.beginPath(); ctx.moveTo(38, 70); ctx.quadraticCurveTo(50, 104, 62, 70); ctx.quadraticCurveTo(50, 78, 38, 70); C('#f2f0ea'); ctx.fill(); ctx.fillStyle = ink; }
    if (lk.stub) { ctx.globalAlpha = 0.35; for (let i = 0; i < 9; i++) E(38 + (i % 5) * 6 + (i > 4 ? 3 : 0), 72 + (i > 4 ? 4 : 0), 0.9, 0.9, ink); ctx.globalAlpha = 1; }
    // mouth
    ctx.lineWidth = 2.6; ctx.strokeStyle = ink;
    ctx.beginPath();
    if (ex === 'h') { ctx.moveTo(41, mY - 1); ctx.quadraticCurveTo(50, mY + 11, 59, mY - 1); ctx.closePath(); C('#8a2a2a'); ctx.fill(); ctx.stroke(); }
    else if (ex === 't') { ctx.moveTo(43, mY + 1); ctx.quadraticCurveTo(47, mY - 2, 51, mY + 1); ctx.quadraticCurveTo(55, mY + 3, 58, mY); ctx.stroke(); }
    else if (ex === 'p') { ctx.moveTo(42, mY + 3); ctx.quadraticCurveTo(50, mY - 4, 58, mY + 3); ctx.stroke(); }
    else if (ex === 'a') { ctx.ellipse(50, mY + 1, 7, 5, 0, 0, Math.PI * 2); C('#7a1f1f'); ctx.fill(); ctx.stroke(); }
    else if (ex === 's') { ctx.moveTo(44, mY + 3); ctx.quadraticCurveTo(50, mY - 1, 56, mY + 3); ctx.stroke(); }
    else { ctx.moveTo(43, mY); ctx.quadraticCurveTo(50, mY + 5, 57, mY); ctx.stroke(); }
    // extras
    if (ex === 'a') { ctx.globalAlpha = 0.8; E(14, 18, 6, 5, '#f4efe4'); E(8, 12, 4, 3, '#f4efe4'); E(86, 18, 6, 5, '#f4efe4'); E(92, 12, 4, 3, '#f4efe4'); ctx.globalAlpha = 1; }
    if (ex === 't') { ctx.fillStyle = '#8fd0ff'; ctx.beginPath(); ctx.moveTo(78, 38); ctx.quadraticCurveTo(84, 46, 78, 48); ctx.quadraticCurveTo(72, 46, 78, 38); ctx.fill(); }
    if (ex === 'p') { ctx.strokeStyle = '#3a2418'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(80, 30); ctx.lineTo(86, 26); ctx.moveTo(80, 36); ctx.lineTo(88, 36); ctx.stroke(); }
    ctx.restore();
  }

  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'bz' });
    const stallsEl = h('div', { class: 'bz-stalls' });
    const barEl = h('div', { class: 'bz-bar' });
    const mainEl = h('div', { class: 'bz-main' });
    wrap.append(stallsEl, barEl, mainEl);
    root.append(style, wrap);
    let st = null, anim = null, revealed = -1, handEl = null, handKey = '', bannerEl = null, sheetEl = null;
    let dead = false, busy = false, shownDay = -1, shownCust = '', shownStep = '', tut2 = false;
    const sent = {}, timers = new Set();
    let cart = { key: '', q: {} }, price = { key: '', v: 0 };
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms / sp()); timers.add(t); return t; };
    const multi = () => !api.online && api.mySeats().length >= 2;
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    const keyOf = (s, i) => (s.ph === 'm' ? 'm' + s.d : 'h' + s.d + '.' + s.ci + '.' + (s.cu ? s.cu.k : 0)) + ':' + i;
    const actList = (s) => actor(s) || [];
    function pendingLocal() {
      if (!st || anim) return [];
      const list = actList(st), r = [];
      for (const i of list) {
        if (!api.canAct(i) || sent[keyOf(st, i)]) continue;
        if (st.ph === 'm' ? st.or[i] == null : st.b[i] == null) r.push(i);
      }
      return r;
    }
    const soloCurtain = () => st && st.ph === 'h' && actList(st).length === 1;   // core shows its own curtain then
    /* the seat that should give input on this screen now (-1 = nobody) */
    function ctlSeat() {
      const p = pendingLocal();
      if (!p.length) return -1;
      if (!multi()) return p[0];
      if (soloCurtain()) return api.viewer() === p[0] ? p[0] : -1;
      return p.includes(revealed) ? revealed : -1;
    }
    /* whose private stuff (whisper, rumor) may be shown */
    function privSeat() {
      const mine = api.mySeats();
      if (!mine.length) return -1;
      if (!multi()) return mine[0];
      const c = ctlSeat();
      return c;
    }
    /* whose stall is "mine" for highlights */
    function meSeat() {
      const mine = api.mySeats();
      if (!mine.length) return -1;
      if (!multi()) return mine[0];
      const c = ctlSeat();
      return c >= 0 ? c : -1;
    }

    /* ---------- stalls ---------- */
    function renderStalls(s, ov) {
      stallsEl.innerHTML = '';
      stallsEl.style.gridTemplateColumns = 'repeat(' + s.n + ',minmax(0,1fr))';
      const me = meSeat();
      const g = ov ? ov.c.g : s.ph === 'h' && s.cu ? s.q[s.ci][0] : -1;
      const P = ov ? null : parts(s);
      for (let i = 0; i < s.n; i++) {
        let r2 = '';
        if (ov) {
          r2 = ov.a[i] == null ? '' : GOODS[g].e + ' 흥정';
        } else if (s.ph === 'm') r2 = s.or[i] != null ? '✓ 장보기 끝' : '🧺 장보는 중…';
        else if (s.ph === 'h') {
          const has = stk(s, i, g);
          if (!has) r2 = GOODS[g].e + ' 없음';
          else if (!P.includes(i)) r2 = GOODS[g].e + '×' + has + ' · 빠짐';
          else r2 = GOODS[g].e + '×' + has + (s.b[i] != null ? ' · ✓' : ' · 고민 중');
        } else r2 = '판 물건 ' + s.ts[i] + '개';
        const off = !ov && s.ph === 'h' && !(P || []).includes(i);
        const el = h('div', { class: 'bz-st' + (i === me ? ' me' : '') + (off ? ' off' : '') + (ov && ov.w === i ? ' win' : ''), style: { '--c': col(i) }, 'data-seat': i },
          h('div', { class: 'aw' }),
          h('div', { class: 'r1' }, h('span', { class: 'nm', text: nm(i) }), h('span', { class: 'mo', text: s.m[i] + '냥' })),
          h('div', { class: 'r2' }, h('span', { text: r2 }), h('span', { text: '📦' + stkTot(s, i) })));
        if (ov && ov.a[i] != null) {
          const r = ov.r[i], b = ov.a[i];
          const icon = ['', '🤔', '😣', '😠', '🙅', '🤝', '💸'][r];
          const txt = b === -1 ? '포기 🙅' : b + '냥 ' + icon;
          el.append(h('div', { class: 'bz-bub' + (r === 5 ? ' good' : r === 3 ? ' bad' : ''), text: txt }));
        }
        stallsEl.append(el);
      }
    }

    /* ---------- top bar ---------- */
    function renderBar(s) {
      barEl.innerHTML = '';
      const ev = EV[s.dk[Math.min(s.d, s.D - 1)]];
      barEl.append(h('span', { class: 'bz-day', text: '📅 ' + (Math.min(s.d, s.D - 1) + 1) + '/' + s.D + '일' }),
        h('button', { class: 'bz-ev', type: 'button', onclick: () => openSheet() }, h('b', { text: ev.ic + ' ' + ev.n }), h('span', { text: ev.d })));
    }
    function openSheet() {
      if (!st) return;
      closeSheet();
      api.sfx('click');
      const s = st, ev = EV[s.dk[Math.min(s.d, s.D - 1)]], ps = privSeat();
      const body = [h('h3', { text: ev.ic + ' ' + ev.n }), h('div', { text: ev.d })];
      body.push(h('div', { class: 'muted', style: { marginTop: '8px' }, text: '오늘 손님 ' + s.q.length + '명 · 내 좌판은 ' + CAP + '칸' }));
      if (ps >= 0 && s.ph !== 'x') {
        const w = s.wh[ps];
        if (w) body.push(h('div', { style: { marginTop: '8px' }, text: '🤫 귓속말: 오늘 ' + GOODS[w[0]].e + ' ' + GOODS[w[0]].n + (w[1] ? ' 찾는 손님이 ' + w[1] + '명 온대요.' : ' 찾는 손님은 한 명도 없대요.') }));
        if (s.rm === ps && s.d + 1 < s.D) { const ne = EV[s.dk[s.d + 1]]; body.push(h('div', { text: '🤫 소문: 내일은 「' + ne.ic + ' ' + ne.n + '」이래요! ' + ne.d })); }
      }
      body.push(h('button', { class: 'btn primary', type: 'button', text: '닫기', onclick: closeSheet }));
      sheetEl = h('div', { class: 'bz-sheet', onclick: (e) => { if (e.target === sheetEl) closeSheet(); } }, h('div', { class: 'in' }, ...body));
      wrap.append(sheetEl);
    }
    function closeSheet() { if (sheetEl) { sheetEl.remove(); sheetEl = null; } }

    /* ---------- morning ---------- */
    function cartOf(s, seat) {
      const key = 'm' + s.d + ':' + seat;
      if (cart.key !== key) cart = { key, q: {} };
      return cart.q;
    }
    function cartSum(s, seat) {
      const q = cartOf(s, seat);
      let cost = 0, n = 0;
      for (const [g, p] of s.mk) { cost += (q[g] || 0) * p; n += q[g] || 0; }
      return { cost, n };
    }
    function renderMorning(s) {
      const seat = ctlSeat(), ps = privSeat(), ev = s.dk[s.d];
      const box = h('div', { class: 'bz-mor' });
      // whisper / yesterday
      const wl = [];
      if (s.d > 0 && s.de.some((v) => v > 0)) {
        const me = meSeat();
        wl.push(h('div', { class: 'y', text: '어제 장사: ' + s.de.map((v, i) => (i === me ? '나' : nm(i)) + ' +' + v).join(' · ') }));
      }
      if (ps >= 0) {
        const w = s.wh[ps];
        if (w) wl.push(h('div', null, '🤫 귓속말: 오늘 ', h('b', { text: GOODS[w[0]].e + ' ' + GOODS[w[0]].n }), w[1] ? ' 찾는 손님이 ' : ' 찾는 손님은 ', h('b', { text: w[1] ? w[1] + '명' : '한 명도 없대요' }), w[1] ? ' 온대요.' : '.'));
        if (s.rm === ps && s.d + 1 < s.D) { const ne = EV[s.dk[s.d + 1]]; wl.push(h('div', null, '🤫 소문: 내일은 ', h('b', { text: ne.ic + ' ' + ne.n }), '이래요!')); }
      } else wl.push(h('div', { text: '🧺 모두 도매시장에서 물건을 고르는 중이에요. 오늘 손님 ' + s.q.length + '명.' }));
      box.append(h('div', { class: 'bz-whisper' }, ...wl));
      const grid = h('div', { class: 'bz-market' });
      const q = seat >= 0 ? cartOf(s, seat) : {};
      const sum = seat >= 0 ? cartSum(s, seat) : { cost: 0, n: 0 };
      const room = seat >= 0 ? CAP - stkTot(s, seat) - sum.n : 0;
      const left = seat >= 0 ? s.m[seat] - sum.cost : 0;
      const viewSeat = seat >= 0 ? seat : meSeat();
      for (const [g, p] of s.mk) {
        const G = GOODS[g], [a, b] = sise(ev, g), have = viewSeat >= 0 ? stk(s, viewSeat, g) : 0;
        const card = h('div', { class: 'bz-card' + (mod(ev, g).dem > 1 ? ' hot' : '') },
          h('div', { class: 't' }, h('span', { class: 'em', text: G.e }), h('div', { style: { minWidth: 0 } }, h('div', { class: 'gn', text: G.n }), h('div', { class: 'hv', text: have ? '내 좌판 ' + have + '개' : ' ' }))),
          h('div', { class: 'pr' }, h('span', null, '도매 ', h('b', { text: p })), h('span', { text: '시세 ' + a + '~' + b })));
        if (seat >= 0) {
          const v = q[g] || 0;
          const minus = h('button', { class: 'btn', type: 'button', text: '−', 'aria-label': G.n + ' 하나 빼기', disabled: v <= 0, onclick: () => { q[g] = Math.max(0, (q[g] || 0) - 1); api.sfx('tick'); render(); } });
          const plus = h('button', { class: 'btn', type: 'button', text: '+', 'aria-label': G.n + ' 하나 더', disabled: room <= 0 || left < p, onclick: () => { q[g] = (q[g] || 0) + 1; api.sfx('tick'); api.buzz(8); render(); } });
          card.append(h('div', { class: 'bz-step' }, minus, h('span', { class: 'v', text: v ? '×' + v : '0' }), plus));
        }
        grid.append(card);
      }
      box.append(grid);
      mainEl.append(box);
      // foot
      if (seat >= 0) {
        const foot = h('div', { class: 'bz-foot' },
          h('div', { class: 'sum' }, '남는 돈 ', h('b', { text: left + '냥' }), h('br'), '좌판 ', h('b', { text: (CAP - room) + '/' + CAP }), sum.n ? ' · 장바구니 ' + sum.cost + '냥' : ''),
          h('button', { class: 'btn primary bz-done', type: 'button', text: sum.n ? '장보기 끝' : '안 사고 끝', onclick: () => sendOrder(seat) }));
        mainEl.append(foot);
      } else {
        const mine = api.mySeats(), waiting = mine.some((i) => st.or[i] != null || sent[keyOf(st, i)]);
        mainEl.append(h('div', { class: 'bz-foot' }, h('div', { class: 'sum', style: { textAlign: 'center' }, text: waiting ? '다른 상인들이 장을 보는 중이에요…' : '상인들이 장을 보는 중이에요…' })));
      }
    }
    function sendOrder(seat) {
      if (!st || st.ph !== 'm') return;
      const q = cartOf(st, seat), o = [];
      for (const [g] of st.mk) if (q[g] > 0) o.push([g, q[g]]);
      sent[keyOf(st, seat)] = 1;
      api.sfx('chip'); api.buzz(15);
      api.actAs(seat, { o });
      render();
    }

    /* ---------- haggle ---------- */
    let faceCv = null;
    function faceEl(t, ex, size, cls) {
      const box = h('div', { class: 'bz-facebox ' + (cls || '') });
      const cv = h('canvas', { class: 'bz-face' });
      const dpr = Math.min(2, window.devicePixelRatio || 1), R0 = 180;
      cv.width = Math.round(R0 * dpr); cv.height = Math.round(R0 * 1.1 * dpr);
      cv.style.width = size + 'px'; cv.style.height = Math.round(size * 1.1) + 'px';
      const ctx = cv.getContext('2d'); ctx.scale(dpr, dpr);
      drawFace(ctx, R0, t, ex);
      faceCv = cv;
      box.append(cv);
      return box;
    }
    function faceSize() {
      const H = mainEl.clientHeight || 400, W = mainEl.clientWidth || 360;
      return Math.round(Math.max(76, Math.min(150, (H - 250) * 0.62, W * 0.34)));
    }
    /* grow the customer to fill the scene once the controls are laid out */
    function fitFace() {
      const sc = mainEl.querySelector('.bz-scene'), cv = sc && sc.querySelector('.bz-face');
      if (!cv) return;
      const who = sc.querySelector('.bz-who'), W = mainEl.clientWidth;
      const setSz = (z) => { cv.style.width = z + 'px'; cv.style.height = Math.round(z * 1.1) + 'px'; };
      const content = () => { let o = 12 + 4 * (sc.children.length - 1); for (const ch of sc.children) o += ch.offsetHeight; return o; };
      const fitOnce = (mx) => { const z = Math.round(Math.max(56, Math.min(mx, cv.offsetWidth + (sc.clientHeight - content() - 14) / 1.1))); setSz(z); return z; };
      who.classList.remove('col');
      const z = fitOnce(Math.min(170, W * 0.4));
      if (z >= 160 && sc.clientHeight - content() > 70) {    // tall screen: speech bubble above a bigger customer
        who.classList.add('col');
        fitOnce(Math.min(210, W * 0.55));
      } else fitOnce(Math.min(170, W * 0.4));
    }
    function patEl(P, pl) {
      const el = h('div', { class: 'bz-pat' }, h('span', { text: '인내' }));
      for (let i = 0; i < P; i++) el.append(h('i', { class: i < pl ? '' : 'e' }));
      return el;
    }
    function custSeed(s) { return s.d * 31 + s.ci * 7; }
    function clueText(lb, ub) {
      const a = [];
      if (lb) a.push(lb + '냥엔 🤔고민');
      if (ub) a.push((ub + 1) + '냥부터 😣비쌈');
      return a.length ? '단서: ' + a.join(' · ') : '';
    }
    /* scene: c = {g,t,h,o,pl,P,k,lb,ub}, ex expression, say text, offer line */
    function renderScene(c, ex, sayTxt, ofTxt, cls, extraChips, popSay) {
      const ev = st.dk[Math.min(st.d, st.D - 1)];
      const G = GOODS[c.g], [a, b] = sise(ev, c.g);
      const scene = h('div', { class: 'bz-scene' });
      const fsz = faceSize();
      const fb = faceEl(c.t, ex, fsz, cls);
      fb.style.setProperty('--wd', (0.5 / sp()) + 's');
      fb.append(h('div', { class: 'bz-tn', text: TY[c.t].n }), patEl(c.P, c.pl));
      const say = h('div', { class: 'bz-say' + (popSay === false ? '' : ' pop') }, h('span', { text: sayTxt }));
      if (ofTxt) say.append(h('span', { class: 'of', text: ofTxt }));
      scene.append(h('div', { class: 'bz-who' }, fb, say));
      const want = h('div', { class: 'bz-want' },
        h('span', { class: 'bz-chip' }, G.e + ' ' + G.n + ' 찾음'),
        h('span', { class: 'bz-chip' }, '시세 ', h('b', { text: a + '~' + b }), '냥'));
      (extraChips || []).forEach((x) => want.append(x));
      scene.append(want, h('div', { class: 'bz-clue', text: clueText(c.lb, c.ub) }), h('div', { class: 'bz-counter' }, h('span', { class: 'it', text: G.e })));
      mainEl.append(scene);
      return scene;
    }
    function curC(s) {
      const c = s.q[s.ci], cu = s.cu;
      return { g: c[0], t: c[1], h: c[5], o: cu.o, pl: cu.pl, P: c[3], k: cu.k, lb: cu.lb, ub: cu.ub };
    }
    function offerLine(c) {
      const seed = st.d * 31 + st.ci * 7 + c.k;
      const t = c.k === 0 ? pick(LINES.first, seed) : c.pl <= 1 ? pick(LINES.lastO, seed) : pick(LINES.next, seed);
      return fill(t, { o: c.o });
    }
    function renderHaggle(s) {
      const c = curC(s), G = GOODS[c.g];
      const seed = custSeed(s);
      let sayT;
      if (c.k === 0) sayT = fill(pick(LINES.h[c.h], seed), { g: G.n });
      else sayT = s.last && s.last.k === 's' && s.last.e === 0 ? reactLine(s.last) : fill(pick(LINES.h[c.h], seed), { g: G.n });
      const ex = c.k === 0 ? 'n' : s.last && s.last.k === 's' && s.last.e === 0 ? (s.last.c.an ? 'p' : 't') : 'n';
      const ckey = s.d + '.' + s.ci, skey = ckey + '.' + c.k;
      const isNew = ckey !== shownCust, stepNew = skey !== shownStep;
      shownCust = ckey; shownStep = skey;
      const seat = ctlSeat();
      const extra = [];
      const me = seat >= 0 ? seat : meSeat();
      if (me >= 0 && stk(s, me, c.g) > 0) extra.push(h('span', { class: 'bz-chip' }, '내 원가 ', h('b', { text: (s.cb[me][c.g] || G.b) }), '냥'));
      renderScene(c, ex, sayT, offerLine(c), isNew ? 'in' : stepNew ? 'bob' : '', extra, stepNew);
      if (isNew) api.sfx('pop');
      // controls
      const ctl = h('div', { class: 'bz-ctl' });
      if (seat >= 0) {
        const pk = keyOf(s, seat);
        const [a, b] = sise(s.dk[s.d], c.g);
        const cost = s.cb[seat][c.g] || G.b;
        if (price.key !== pk) {
          let v = Math.max(Math.round(c.o * 1.25), cost + 1);
          if (c.lb) v = Math.max(v, c.lb);
          if (c.ub) v = Math.min(v, c.ub);
          price = { key: pk, v: Math.max(c.o, v) };
        }
        const maxV = Math.max(b * 2, c.o + 10, 20);
        const setV = (v, snd) => { price.v = Math.max(1, Math.min(BIDMAX, Math.round(v))); if (snd) api.sfx('tick'); updAmt(); };
        const vb = h('b', { text: '' }), vs = h('small', { text: '' });
        const rng = h('input', { class: 'bz-range', type: 'range', min: 1, max: maxV, step: 1, value: Math.min(maxV, price.v), 'aria-label': '부를 값' });
        rng.addEventListener('input', () => setV(+rng.value));
        const goBtn = h('button', { class: 'btn primary bz-send', type: 'button', text: '', onclick: () => sendBid(seat, price.v) });
        function updAmt() {
          vb.textContent = price.v + '냥';
          const pr = price.v - cost;
          vs.textContent = price.v <= c.o ? '손님 값 이하 → 바로 팔려요 (' + (pr >= 0 ? '+' : '') + pr + ')' : '팔면 ' + (pr >= 0 ? '+' : '') + pr + '냥 남아요';
          if (+rng.value !== price.v) rng.value = Math.min(maxV, price.v);
          goBtn.textContent = price.v + '냥 부르기';
        }
        const stepB = (d) => h('button', { class: 'btn', type: 'button', text: (d > 0 ? '+' : '−') + Math.abs(d), 'aria-label': '값 ' + (d > 0 ? '올리기 ' : '내리기 ') + Math.abs(d), onclick: () => { setV(price.v + d, true); api.buzz(6); } });
        ctl.append(h('div', { class: 'bz-amt bz-price' }, stepB(-5), stepB(-1), h('div', { class: 'v' }, vb, vs), stepB(1), stepB(5)), rng);
        const mid = Math.round((a + b) / 2);
        const qb = (label, v, sub) => h('button', { class: 'btn', type: 'button', onclick: () => { setV(v, true); } }, h('span', { text: label }), h('b', { text: v + (sub || '') }));
        ctl.append(h('div', { class: 'bz-quick' }, qb('손님 값', c.o), qb('시세 중간', Math.max(c.o, mid)), qb('시세 위', Math.max(c.o, b))));
        ctl.append(h('div', { class: 'bz-go' },
          h('button', { class: 'btn ghost bz-pass', type: 'button', text: '포기', onclick: () => sendBid(seat, -1) }), goBtn));
        updAmt();
        if (!tut2 && !api.online && !L.debug.noTut) {
          tut2 = true;
          let seen = false;
          try { seen = localStorage.getItem('lounge.bazaar.tut2') === '1'; localStorage.setItem('lounge.bazaar.tut2', '1'); } catch (e) { seen = true; }
          if (!seen) later(() => api.tutorial(TUT2), 600);
        }
      } else {
        const P = parts(s), mine = api.mySeats();
        let txt;
        if (mine.length && mine.every((i) => !stk(s, i, c.g))) txt = '내 좌판엔 ' + G.e + ' ' + josa(G.n, '이', '가') + ' 없어요 — 구경 중… 👀';
        else if (mine.some((i) => P.includes(i) && (s.b[i] != null || sent[keyOf(s, i)]))) {
          const i = mine.find((x) => P.includes(x) && (s.b[x] != null || sent[keyOf(s, x)]));
          const v = s.b[i] != null ? s.b[i] : sent[keyOf(s, i)];
          txt = (v === -1 ? '이 손님은 포기했어요' : '<b>' + v + '냥</b> 불렀어요') + ' · 다른 상인 기다리는 중…';
        } else if (mine.some((i) => stk(s, i, c.g) > 0 && !P.includes(i))) txt = '이 손님은 내 가게엔 안 와요 (포기·화남) — 구경 중…';
        else txt = P.map((i) => nm(i)).join(', ') + ' 가게가 흥정 중이에요…';
        const w = h('div', { class: 'bz-wait' }); w.innerHTML = txt;
        ctl.append(w);
      }
      mainEl.append(ctl);
      fitFace();
    }
    function sendBid(seat, v) {
      if (!st || st.ph !== 'h') return;
      const k = keyOf(st, seat);
      if (sent[k]) return;
      sent[k] = v;
      api.sfx(v === -1 ? 'click' : 'chip'); api.buzz(15);
      api.actAs(seat, { p: v });
      render();
    }
    function reactLine(last) {
      const seed = last.id * 3;
      const R_ = last.r;
      if (last.e === 1) {
        const me = meSeat();
        if (R_.some((r) => r === 6) && last.w !== me && me >= 0 && R_[me] === 6) return fill(pick(LINES.saleOther, seed), { w: nm(last.w) });
        return fill(pick(LINES.sale, seed), { p: last.p });
      }
      if (last.e === 2) return last.c.an ? pick(LINES.leftA, seed) : pick(LINES.left, seed);
      if (last.e === 3) return R_.some((r) => r === 3) ? pick(LINES.angry, seed) : pick(LINES.nobody, seed);
      if (R_.some((r) => r === 3)) return pick(LINES.angry, seed);
      if (R_.some((r) => r === 1)) return pick(LINES.close, seed);
      return pick(LINES.pricey, seed);
    }

    /* ---------- reveal animation (from state.last) ---------- */
    function startReveal(last) {
      anim = { last };
      setBusy(true);
      closeHand();
      const c = last.c;
      // phase 1: bids + reaction
      mainEl.innerHTML = '';
      renderStalls(st, last);
      const ex = last.e === 1 ? 'h' : last.r.some((r) => r === 3) ? 'a' : last.r.some((r) => r === 1) ? 't' : last.r.some((r) => r === 2) ? 'p' : 'n';
      const say = reactLine(last);
      const chips = [];
      if (last.e) chips.push(h('span', { class: 'bz-chip' }, '속마음 최고 ', h('b', { text: last.M }), '냥'));
      const sc = renderScene(Object.assign({}, c, { pl: last.e === 2 ? 0 : c.pl }), ex, say, last.e === 1 ? '🤝 ' + last.p + '냥에 팔림 · ' + nm(last.w) : '', 'bob', chips);
      mainEl.append(h('div', { class: 'bz-ctl' }, h('div', { class: 'bz-wait', text: summaryText(last) })));
      fitFace();
      if (last.e === 1) { api.sfx('chip'); coinTo(last.w, sc); if (api.canAct(last.w)) api.buzz(25); }
      else if (last.r.some((r) => r === 3)) { api.sfx('thud'); api.buzz(20); }
      else api.sfx('pop');
      const dur = last.e ? 1700 : 1250;
      later(() => {
        if (last.e) {
          const fb = mainEl.querySelector('.bz-facebox');
          if (fb) { fb.style.setProperty('--wd', (0.45 / sp()) + 's'); fb.classList.remove('bob'); fb.classList.add('out'); }
          if (last.e !== 1) api.sfx('whoosh');
        }
      }, dur - 450);
      later(() => {
        anim = null;
        if (last.nd) dayEndToast(last);
        else if (last.sk && last.sk.length) skipToast(last.sk);
        render();
        setBusy(false);
      }, dur);
    }
    function summaryText(last) {
      const me = meSeat();
      if (last.e === 1) return (last.w === me ? '내가 ' : josa(nm(last.w), '이', '가') + ' ') + last.p + '냥에 팔았어요! (속마음은 ' + last.M + '냥)';
      if (last.e === 2) return '손님이 그냥 갔어요. (속마음은 ' + last.M + '냥이었어요)';
      if (last.e === 3) return '흥정할 가게가 없어 손님이 갔어요. (속마음 ' + last.M + '냥)';
      return last.c.an ? '모두 너무 비싸서 손님이 짜증 났어요 — 인내 −2' : '흥정 계속! 손님이 값을 올려요.';
    }
    function coinTo(seat, scene) {
      const tgt = stallsEl.querySelector('[data-seat="' + seat + '"]');
      if (!tgt || !scene) return;
      const wr = wrap.getBoundingClientRect(), tr = tgt.getBoundingClientRect(), sr = scene.getBoundingClientRect();
      for (let k = 0; k < 4; k++) {
        const c = h('div', { class: 'bz-coin' });
        const x0 = sr.left - wr.left + sr.width * 0.5 - 11 + (k - 1.5) * 12, y0 = sr.top - wr.top + sr.height * 0.45;
        const x1 = tr.left - wr.left + tr.width / 2 - 11, y1 = tr.top - wr.top + 10;
        c.style.left = x0 + 'px'; c.style.top = y0 + 'px';
        c.style.transition = 'transform ' + (0.6 / sp()) + 's cubic-bezier(.5,-0.3,.6,1) ' + (k * 0.08 / sp()) + 's, opacity .2s';
        wrap.append(c);
        requestAnimationFrame(() => requestAnimationFrame(() => { c.style.transform = 'translate(' + (x1 - x0) + 'px,' + (y1 - y0) + 'px) scale(.7)'; }));
        later(() => { c.style.opacity = '0'; }, 750 + k * 80);
        later(() => c.remove(), 1000 + k * 80);
      }
    }
    function skipToast(sk) {
      const cnt = {};
      sk.forEach((g) => { cnt[g] = (cnt[g] || 0) + 1; });
      const t = Object.keys(cnt).map((g) => GOODS[g].e + GOODS[g].n + (cnt[g] > 1 ? ' ' + cnt[g] + '명' : '')).join(', ');
      api.toast('아무도 없어서 그냥 간 손님: ' + t);
    }
    function dayEndToast(last) {
      if (!last.de) return;
      const me = meSeat();
      const best = Math.max(...last.de);
      const i = last.de.indexOf(best);
      api.toast((last.d + 1) + '일째 장 끝! ' + (me >= 0 ? '나 +' + last.de[me] + '냥' + (st.n > 1 ? ' · 최고 ' + nm(i) + ' +' + best : '') : '최고 ' + nm(i) + ' +' + best + '냥'));
    }

    /* ---------- morning banner ---------- */
    function showBanner(s) {
      if (bannerEl) bannerEl.remove();
      const ev = EV[s.dk[s.d]];
      bannerEl = h('div', { class: 'bz-banner', onclick: () => { if (bannerEl) { bannerEl.remove(); bannerEl = null; } } },
        h('div', { class: 'ic', text: ev.ic }),
        h('div', { class: 's', text: (s.d + 1) + '일째 장날' + (s.d === s.D - 1 ? ' · 마지막 날!' : '') }),
        h('div', { class: 't', text: ev.n }),
        h('div', { class: 'd', text: ev.d }),
        h('div', { class: 's', text: s.d === s.D - 1 ? '오늘 못 판 물건은 도매값 절반에 떨이돼요' : '눌러서 닫기' }));
      wrap.append(bannerEl);
      const b = bannerEl;
      later(() => { if (bannerEl === b) { b.remove(); bannerEl = null; } }, 2600);
    }

    /* ---------- pass-the-phone for several people on one phone ---------- */
    function closeHand() { if (handEl) { handEl.remove(); handEl = null; } handKey = ''; }
    function syncHand() {
      let want = -1;
      if (st && multi() && !anim && !soloCurtain() && st.ph !== 'x') {
        const p = pendingLocal();
        if (p.length && !p.includes(revealed)) want = p[0];
      }
      const key = want + ':' + (st ? keyOf(st, want) : '');
      if (key === handKey) return;
      if (handEl) { handEl.remove(); handEl = null; }
      handKey = key;
      if (want < 0) return;
      handEl = h('div', { class: 'bz-hand' },
        h('span', { class: 'dot', style: { '--c': col(want), width: '18px', height: '18px' } }),
        h('div', { class: 'big', text: nm(want) }),
        h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: st.ph === 'm' ? (st.d + 1) + '일째 아침 · 몰래 장보기' : GOODS[st.q[st.ci][0]].e + ' 손님과 흥정 · 몰래 값 부르기' }),
        h('div', { class: 'muted', text: '다른 사람은 보지 마세요' }),
        h('button', { class: 'btn primary', type: 'button', text: '내 차례 시작', onclick: () => { revealed = want; api.sfx('click'); closeHand(); render(); } }));
      wrap.append(handEl);
    }

    /* ---------- result / over ---------- */
    function renderOver(s) {
      const box = h('div', { class: 'bz-mor', style: { justifyContent: 'center', alignItems: 'center', textAlign: 'center' } });
      const order = s.m.map((_, i) => i).sort((a, b) => s.m[b] - s.m[a]);
      box.append(h('div', { class: 'bz-whisper', style: { width: '100%' } },
        h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '20px', marginBottom: '4px' }, text: '🏮 장이 모두 끝났어요' }),
        ...order.map((i) => h('div', { text: nm(i) + ' · ' + s.m[i] + '냥' + (s.fin && s.fin[i] ? ' (떨이 +' + s.fin[i] + ')' : '') }))));
      mainEl.append(box);
    }

    /* ---------- main render ---------- */
    function render() {
      if (!st || anim) return;
      const s = st;
      closeSheet();
      renderStalls(s, null);
      renderBar(s);
      mainEl.innerHTML = '';
      if (s.ph === 'm') {
        renderMorning(s);
        if (shownDay !== s.d) { shownDay = s.d; showBanner(s); }
      } else if (s.ph === 'h') { if (bannerEl) { bannerEl.remove(); bannerEl = null; } renderHaggle(s); }
      else renderOver(s);
      syncHand();
    }

    /* keyboard / pad (rebindable) */
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st || anim || handEl || sheetEl) return;
      const seat = ctlSeat();
      if (seat < 0) return;
      if (st.ph === 'm') { if (id === 'go') sendOrder(seat); return; }
      if (st.ph !== 'h') return;
      const c = st.cu;
      if (id === 'up' || id === 'down') {
        price.v = Math.max(1, Math.min(BIDMAX, price.v + (id === 'up' ? 1 : -1)));
        api.sfx('tick'); render();
      } else if (id === 'take') { price.v = c.o; api.sfx('tick'); render(); }
      else if (id === 'go') sendBid(seat, price.v);
      else if (id === 'pass') sendBid(seat, -1);
    }) : null;

    let rzT = 0;
    const onResize = () => { clearTimeout(rzT); rzT = setTimeout(() => { if (!dead && !anim) render(); }, 150); };
    window.addEventListener('resize', onResize);

    return {
      update(state, prev) {
        st = state;
        if (prev && prev !== state && state.last && (!prev.last || prev.last.id !== state.last.id)) {
          const last = state.last;
          if (last.k === 's') { startReveal(last); return; }
          if (last.k === 'm') {
            if (last.sk && last.sk.length) later(() => skipToast(last.sk), 300);
            api.sfx('whoosh');
            api.toast(last.nd ? '오늘은 아무도 물건이 없어서 장이 일찍 끝났어요' : '장이 열렸어요! 손님이 와요');
          }
        }
        if (prev == null && state.last && state.ph === 'h') shownCust = '';
        render();
      },
      destroy() {
        dead = true;
        timers.forEach(clearTimeout); timers.clear();
        clearTimeout(rzT);
        window.removeEventListener('resize', onResize);
        if (offIn) offIn();
        if (busy) api.setBusy(false);
        wrap.remove(); style.remove();
      },
    };
  }

  const TUT2 = [
    { sel: '.bz-facebox', text: '손님 얼굴과 인내 구슬을 보세요. 인내가 다 떨어지면 손님이 그냥 가요.' },
    { sel: '.bz-say', text: '손님이 부른 값(굵은 글씨)이에요. 이 값 이하로 부르면 바로 팔려요. 손님 속마음은 더 높을 수 있어요!' },
    { sel: '.bz-price', text: '−/+ 버튼이나 막대로 내가 부를 값을 정해요. 아래 칸에 남는 돈이 보여요.' },
    { sel: '.bz-quick', text: '빠른 값: 「손님 값」은 확실히 팔리는 값, 「시세」는 보통 받을 만한 값이에요.' },
    { sel: '.bz-send', text: '「부르기」! 손님이 🤔이면 아깝게 비싼 것, 😣이면 너무 비싼 것, 😠이면 화나서 우리 가게엔 다시 안 와요.' },
  ];

  /* ---------- 도감 (codex): GOODS·EV·TY·LINES 표에서 자동으로 만들어요 ---------- */
  function codex(el) {
    const h = L.h;
    const CATN = { f: '곡식·채소', r: '과일', s: '생선', k: '먹거리', x: '약재', c: '공예품' };
    const x2 = (v) => '×' + (Math.round(v * 100) / 100);
    const pct = (v) => Math.round(v * 100) + '%';
    const row = (ic, name, tag, desc) => h('div', { class: 'cx-row' },
      typeof ic === 'string' ? h('span', { class: 'cx-ic', text: ic }) : ic,
      h('div', { class: 'cx-tx' }, h('div', { class: 'cx-nm' }, h('b', { text: name }), tag ? h('span', { class: 'cx-tag', text: tag }) : null),
        ...[].concat(desc || []).map((t) => h('div', { class: 'cx-d', text: t }))));
    const note = (t) => h('p', { class: 'note', style: { margin: 0 }, text: t });
    const face = (t, ex) => {
      const cv = document.createElement('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1), px = 40;
      cv.width = Math.round(px * dpr); cv.height = Math.round(px * 1.1 * dpr);
      cv.style.cssText = 'width:' + px + 'px;height:' + Math.round(px * 1.1) + 'px;flex:none;border-radius:10px;background:var(--surface-2)';
      const c = cv.getContext('2d'); c.scale(dpr, dpr);
      try { drawFace(c, px, t, ex || 'n'); } catch (e) { /* 그림 실패해도 도감은 열려요 */ }
      return cv;
    };
    const tgt = (sel) => (sel === '*' ? '모든 물건' : typeof sel === 'string' ? sel.split('').map((k) => CATN[k]).join('·') : sel.map((g) => GOODS[g].n).join('·'));
    const twT = TY.reduce((a, t) => a + t.wt, 0);
    const secs = [
      { h: '물건', n: NG, f(p) {
        p.append(note('도매가 = 아침 도매시장에서 사는 값(기본값의 85~115%, 장날 카드로 바뀜). 시세 = 맑은 장날에 손님이 보통 내는 값.'),
          note('도매시장엔 매일 ' + NMK + '가지가 나와요. 좌판은 ' + CAP + '칸. 마지막 날 남은 물건은 기본값의 절반에 떨이돼요.'));
        GOODS.forEach((G, g) => {
          const lo = Math.max(1, Math.round(G.b * 0.85)), hi = Math.round(G.b * 1.15), ss = sise(0, g);
          p.append(row(G.e, G.n, CATN[G.c], ['도매 ' + lo + '~' + hi + '냥 (기본 ' + G.b + ') · 시세 ' + ss[0] + '~' + ss[1] + '냥', '떨이 ' + Math.floor(G.b / 2) + '냥']));
        });
      } },
      { h: '장날 카드', n: EV.length, f(p) {
        p.append(note('장날마다 ' + EV.length + '장 중 1장(겹치지 않게). 숫자는 기본값에 곱하는 배율이에요(도매값 · 찾는 손님 · 손님이 내는 값).'));
        EV.forEach((E) => {
          const a = [];
          if (E.cu) a.push('손님 ' + (E.cu > 0 ? '+' : '−') + Math.abs(E.cu) + '명');
          if (E.pa) a.push('인내 ' + (E.pa > 0 ? '+' : '−') + Math.abs(E.pa));
          if (E.rich) a.push('부잣집 마님·훈장님 3배 자주');
          const ms = (E.m || []).map(([sel, w, d, v]) => tgt(sel) + ': ' + [w !== 1 ? '도매 ' + x2(w) : '', d !== 1 ? '찾는 손님 ' + x2(d) : '', v !== 1 ? '값 ' + x2(v) : ''].filter(Boolean).join(' · '));
          p.append(row(E.ic, E.n, a.join(' · '), [E.d].concat(ms)));
        });
      } },
      { h: '손님', n: TY.length, f(p) {
        p.append(note('손님마다 속마음 최고값(기본값 × 배율, 숨김)이 있어요. 처음 말하는 값은 그 속마음의 일부만 불러요. 인내 구슬이 다 떨어지면 떠나요.'),
          note('손님 수: 혼자면 6명, 여럿이면 4 + 2×인원(장날 카드로 ±). 손님의 85%는 오늘 도매시장에 나온 물건을 찾아요.'));
        TY.forEach((T, t) => {
          const sp = T.r[1] <= 0.7 ? '처음엔 아주 싸게 불러요' : T.r[0] >= 0.8 ? '처음부터 제값 가까이 불러요' : T.r[1] >= 0.9 ? '처음 부르는 값이 꽤 후해요' : '처음엔 조금 깎아 불러요';
          const dmk = (v) => x2(v * DMK);
          p.append(row(face(t, 'n'), T.n, '인내 ' + T.p + ' · ' + pct(T.wt / twT) + ' 확률',
            ['속마음: 기본값 ' + dmk(T.dm[0]) + '~' + dmk(T.dm[1]) + (T.dm[1] >= 2.3 ? ' (넉넉한 손님)' : T.dm[1] <= 1.7 ? ' (짠 손님)' : ''),
              '말버릇: ' + sp + ' — 첫 값은 속마음의 ' + pct(T.r[0]) + '~' + pct(T.r[1]) + '.']));
        });
        p.append(note('첫마디로 주머니 사정을 알 수 있어요(손님 종류와 상관없이):'));
        [['짠 주머니', '속마음 배율 1.5 미만'], ['보통 주머니', '1.5~1.8'], ['넉넉한 주머니', '1.8 이상']].forEach(([n, d], k) =>
          p.append(row(['🪙', '💰', '💎'][k], n, d, LINES.h[k].map((t) => '「' + fill(t, { g: '고추' }) + '」').slice(0, 2))));
      } },
      { h: '흥정 반응', n: 0, f(p) {
        p.append(note('손님을 만난 상인은 몰래 값을 불러요(1~' + BIDMAX + '냥, 또는 포기). 다 부르면 한꺼번에 공개!'),
          note('손님이 이번에 낼 마음 = 속마음 × (1 − 0.1 × (인내 − 1 − 흥정 횟수)), 최대 100%. 인내 4 손님이면 70% → 80% → 90% → 100%로 올라요.'));
        p.append(row(face(2, 'h'), '팔림 🙂', '낼 마음 이하', ['부른 값이 이번에 낼 마음 이하면 팔려요. 여럿이면 가장 싸게 부른 집, 같으면 오늘 덜 판 집(그래도 같으면 무작위).', '손님이 말한 값(굵은 숫자) 이하로 부르면 꼭 팔려요(더 싼 집이 없다면).']));
        p.append(row(face(2, 't'), '🤔 고민', '속마음 이하', ['속마음 최고값 이하지만 아직 이번 마음보다 비싸요. 다음 차례엔 팔릴 수도! 인내 −1.', '이 값이 「단서: ○냥엔 🤔고민」으로 남아요.']));
        p.append(row(face(2, 'p'), '😣 비쌈', '속마음 초과', ['속마음보다 비싸요. 모두가 비쌈·화남이면 손님이 짜증 나서 인내 −2(아니면 −1).', '「단서: ○냥부터 😣비쌈」으로 남아요.']));
        p.append(row(face(2, 'a'), '😠 화남', '속마음 ×' + TOO + ' 초과', ['너무 비싸요! 이 손님은 그 가게엔 다시 안 와요(이번 흥정에서 빠져요).']));
        p.append(row('🙅', '포기', '', ['이번 손님 흥정에서 빠져요. 다른 상인은 계속 흥정해요.']));
        p.append(row('🚶', '손님이 떠남', '', ['인내 구슬이 다 떨어지거나 흥정할 상인이 없으면 떠나요. 떠날 때 속마음 값을 알려 줘요.']));
        p.append(row('🧩', '대사 예시', '', [LINES.close[0], LINES.pricey[0], LINES.angry[0], LINES.left[0]].map((t) => '「' + t + '」')));
      } },
    ];
    const tabs = h('div', { class: 'chips' }), pane = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    const show = (k) => {
      pane.innerHTML = '';
      [...tabs.children].forEach((b, i) => b.classList.toggle('on', i === k));
      secs[k].f(pane);
    };
    secs.forEach((sec, k) => tabs.append(h('button', { class: 'btn sm', text: sec.h + (sec.n ? ' ' + sec.n : ''), onclick: () => show(k) })));
    el.append(tabs, pane);
    show(0);
  }

  L.register({
    id: 'bazaar', name: '시장 흥정', tag: '장터 흥정 장사', cat: '파티',
    blurb: '옛날 장터 상인이 되어 아침엔 도매로 사고, 낮엔 손님 얼굴을 읽으며 흥정해 팔아요. 장이 끝날 때 돈이 가장 많은 상인이 승리!',
    tint: '#6b3a1c',
    icon: '<path d="M6 22L12 8h32l6 14z" fill="currentColor" opacity=".9"/><path d="M12 22v4M22 22v4M34 22v4M44 22v4" stroke="currentColor" stroke-width="3"/><rect x="9" y="26" width="38" height="4" rx="2" fill="currentColor"/><rect x="11" y="30" width="4" height="20" fill="currentColor"/><rect x="41" y="30" width="4" height="20" fill="currentColor"/><circle cx="22" cy="40" r="6" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="34" cy="42" r="4" fill="currentColor"/><rect x="8" y="48" width="40" height="4" rx="2" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: true, aiDelay: 1000,
    options: [
      { id: 'days', label: '장날 수', choices: [{ v: 4, label: '4일 (짧게)' }, { v: 5, label: '5일' }, { v: 7, label: '7일 (길게)' }], def: 5 },
    ],
    quick: [
      '아침엔 도매시장에서 물건을 사 두고, 낮엔 찾아온 손님과 값을 흥정해 팔아요.',
      '손님이 속으로 정한 값 이하로 부르면 팔려요. 너무 세게 부르면 화나서 떠나요!',
      '같은 물건을 가진 상인끼리는 더 싸게 부른 집이 팔아요. 장이 끝날 때 돈이 가장 많으면 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '옛날 장터의 상인이 되어 싸게 사서 비싸게 팔아요. 처음 돈은 60냥.',
        '장날(기본 5일)이 모두 끝났을 때 돈이 가장 많은 상인이 이겨요. 혼자 하면 돈으로 별 3개를 노려요.'] },
      { h: '하루 흐름', p: [
        '① 아침: 장날 카드가 펼쳐지고, 모두 몰래 도매시장에서 물건을 사요.',
        '② 낮: 손님이 한 명씩 와서 물건 하나를 찾아요. 그 물건을 가진 상인만 흥정에 끼어요.',
        '③ 손님이 다 다녀가면 하루 끝. 남은 물건은 다음 날 또 팔 수 있어요.'] },
      { h: '아침 장보기', p: [
        '오늘 도매시장엔 물건 6가지가 나와요. 「도매」는 살 값, 「시세」는 손님이 보통 내는 값이에요.',
        '−/+로 개수를 고르고 「장보기 끝」. 좌판은 8칸이라 물건은 모두 합쳐 8개까지 둘 수 있어요.',
        '「인기」 표시는 오늘 장날 카드 덕에 찾는 손님이 많은 물건이에요.'] },
      { h: '흥정 (값 부르기)', p: [
        '손님을 만난 상인은 모두 몰래 값을 불러요(또는 포기). 다 부르면 한꺼번에 공개!',
        '손님은 속으로 「이 값까진 낸다」는 값을 정해 두었고, 흥정할수록 그 값을 조금씩 올려요. 마지막 차례엔 속마음 최고값까지 내요.',
        '부른 값이 손님 마음 안에 들면 팔려요. 여럿이 들면 가장 싸게 부른 집이 팔아요(같으면 오늘 덜 판 집).',
        '손님이 말한 값(말풍선의 굵은 숫자) 이하로 부르면 꼭 팔려요 (더 싸게 부른 집이 없다면).'] },
      { h: '손님 얼굴 읽기', p: [
        '🤔 고민: 아깝게 비싸요. 속마음 최고값 이하예요 → 다음 차례엔 팔릴 수도!',
        '😣 비쌈: 속마음보다 비싸요. 모두가 이러면 손님이 짜증 나서 인내가 2개 줄어요.',
        '😠 화남: 속마음보다 30% 넘게 비싸게 부르면 그 가게엔 다시 안 와요.',
        '인내 구슬이 다 떨어지면 손님은 그냥 가요. 손님이 떠나면 속마음 값을 알려 줘요.',
        '첫마디도 힌트예요: 「주머니가 가벼워서…」는 짠 손님, 「값은 쳐 줄게요」는 넉넉한 손님!',
        '손님마다 성격이 달라요: 바쁜 아저씨는 인내가 짧고, 깐깐한 할머니·보부상은 처음에 아주 싸게 불러요.'] },
      { h: '장날 카드와 소문', p: [
        '장날마다 카드 1장(12종): 장마, 잔칫날, 풍년, 인삼 소문, 풍랑, 단오장, 김장철, 추석 대목, 사또 행차, 장돌뱅이 떼, 가뭄, 맑은 장날.',
        '카드에 따라 도매값, 찾는 물건, 손님이 내는 값, 손님 수와 인내가 바뀌어요. 위쪽 카드 이름을 누르면 다시 볼 수 있어요.',
        '🤫 귓속말(나만 봄): 아침마다 「오늘 ○○ 찾는 손님이 몇 명」인지 들어요.',
        '🤫 소문(돌아가며 한 명): 내일 장날 카드를 미리 들어요. 내일 비싸질 물건을 오늘 사 둘 수도!'] },
      { h: '끝 · 점수', p: [
        '마지막 날이 끝나면 남은 물건은 도매 기본값의 절반에 자동으로 떨이돼요.',
        '돈이 가장 많은 상인이 우승(같으면 공동 우승).',
        '혼자 하기 별 기준(5일): 120 / 180 / 240냥 (4일 100/150/200, 7일 150/240/330).'] },
      { h: '예시', p: [
        '고추를 도매 8냥에 샀어요. 새댁이 「고추 하나 주세요. 9냥이면 살게요」.',
        '→ 13냥을 불렀더니 🤔. 속마음은 13냥 이상이에요! 손님이 「그럼 11냥 어때요?」',
        '→ 이번엔 13냥이 손님 마음 안에 들어 팔렸어요. 8냥에 사서 13냥에 팔았으니 5냥 남았어요.',
        '→ 만약 옆집도 고추가 있어 12냥을 불렀다면, 더 싼 옆집이 팔았을 거예요.'] },
      { h: '조작', p: [
        '−5 / −1 / +1 / +5 버튼, 막대, 빠른 값(손님 값·시세 중간·시세 위)으로 값을 고르고 「부르기」.',
        'PC: ↑/→ 값 올리기, ↓/← 내리기, A 손님 값, Enter 부르기·장보기 끝, X 포기.',
        '한 폰으로 여럿이 하면 이름이 뜰 때 폰을 넘겨 몰래 장을 보고 값을 불러요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 어려움은 손님 반응을 읽고 귓속말·소문까지 써요.'] },
    ],
    tutorial: [
      { sel: '.bz-ev', text: '오늘의 장날 카드예요. 장마·잔칫날처럼 날마다 시세와 손님이 바뀌어요. 누르면 자세히 볼 수 있어요.' },
      { sel: '.bz-market', text: '아침엔 도매시장에서 물건을 사요. 「도매」보다 비싸게 팔면 남는 거예요. 「시세」는 손님이 보통 내는 값!' },
      { sel: '.bz-whisper', text: '🤫 귓속말은 나만 보는 소문이에요. 오늘 어떤 물건 손님이 몇 명 오는지 알려 줘요.' },
      { sel: '.bz-done', text: '다 골랐으면 「장보기 끝」. 모두 끝나면 손님이 한 명씩 찾아와요.' },
      { text: '손님이 오면 값을 불러요. 손님 속마음 값 이하면 팔리고, 너무 세게 부르면 화나서 떠나요. 같은 물건 가진 상인끼리는 더 싸게 부른 집이 팔아요!' },
    ],
    controls: [
      { id: 'up', label: '값 올리기', keys: ['ArrowUp', 'ArrowRight'], pad: ['up', 'right'] },
      { id: 'down', label: '값 내리기', keys: ['ArrowDown', 'ArrowLeft'], pad: ['down', 'left'] },
      { id: 'take', label: '손님 값으로', keys: ['KeyA'], pad: ['x'] },
      { id: 'go', label: '부르기 / 장보기 끝', keys: ['Enter'], pad: ['a'] },
      { id: 'pass', label: '이 손님 포기', keys: ['KeyX'], pad: ['b'] },
    ],
    codex,
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { GOODS, TY, EV, mod, sise, wk, offerOf, estimate, buyPlan, bidFor, parts, stk, STARS },
  });
})();
