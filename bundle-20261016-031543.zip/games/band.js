/* 밴드 합주 — realtime co-op rhythm band (1–4, one person per phone).
   Four parts: 드럼(패드 3) · 베이스(2줄 + 길게 누르기) · 기타(3줄 + 쓸어 치기) · 건반(4줄 + 화음).
   Ten original songs are composed procedurally (style patterns + chord progressions + seeded melodies) and played with a
   WebAudio synth; every chart is generated deterministically from (song, chart level, part).
   Each phone keeps the song clock (host clock estimated from snapshots on guests), plays all four parts locally and
   judges its own taps; a part that misses drops out of the mix until it hits again. Guests publish their running stats,
   the host owns the shared band meter (분위기) and writes the final result. Unfilled parts play as quiet backing. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const PW = 0.075, GW = 0.15, HOLD_GRACE = 0.15;  // perfect / good half-windows (s) — forgiving for phones
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); }
  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /* ======================= instruments / songs ======================= */
  const INST = [
    { nm: '드럼', lanes: 3, col: '#ee6a55', desc: '패드 3개 · 같이 오면 두 손가락' },
    { nm: '베이스', lanes: 2, col: '#8c95ff', desc: '2줄 · 긴 음표는 끝까지 꾹' },
    { nm: '기타', lanes: 3, col: '#8fe3a8', desc: '3줄 · 가로 긴 줄은 아무 칸이나' },
    { nm: '건반', lanes: 4, col: '#e3ae45', desc: '4줄 · 이어진 화음은 두 손가락' },
  ];
  const SC = { maj: [0, 2, 4, 5, 7, 9, 11], min: [0, 2, 3, 5, 7, 8, 10], dor: [0, 2, 3, 5, 7, 9, 10], pen: [0, 2, 4, 7, 9] };
  /* style patterns per bar: [verse, chorus]. drums {K kick, S snare, H hat}; bass R root(low lane) F fifth T third O octave
     (high lane), '-' = keep sounding; guitar S strum(all lanes) 1-3 single; keys C chord(2 lanes) M melody 1-4 arpeggio */
  const STY = {
    rock: { sub: 4, beats: 4, kit: 'rock', bt: 'pick', gt: 'dist', kt: 'organ',
      dr: [{ K: 'x.......x.x.....', S: '....x.......x...', H: 'x.x.x.x.x.x.x.x.' }, { K: 'x.....x.x.x.....', S: '....x.......x...', H: 'x.x.x.x.x.x.x.x.' }],
      bs: ['R.R.R.R.R.R.R.R.', 'R.R.R.R.R.R.O.F.'], g: ['S-----S-S-------', 'S.S.S.S.S.S.S.S.'], k: ['C-------C-------', 'M...M.M.M...M.M.'] },
    funk: { sub: 4, beats: 4, kit: 'rock', bt: 'pick', gt: 'clean', kt: 'piano',
      dr: [{ K: 'x..x..x...x..x..', S: '....x..x.x..x...', H: 'x.x.x.x.x.x.x.x.' }, { K: 'x..x..x...x..x..', S: '....x..x.x..x..x', H: 'xxxxxxxxxxxxxxxx' }],
      bs: ['R..R..O.R.RO..F.', 'R.OR..O.R.RO.FO.'], g: ['.1.2.1.3.1.2.1.3', 'S..S..S.S..S..S.'], k: ['..C...C...C..C..', 'M.M..M.M..M.M...'] },
    swing: { sub: 3, beats: 4, kit: 'jazz', bt: 'upright', gt: 'clean', kt: 'piano',
      dr: [{ K: 'x.....x.....', S: '...x.....x..', H: 'x..x.xx..x.x' }, { K: 'x.....x.....', S: '...x.x...xx.', H: 'x..x.xx..x.x' }],
      bs: ['R..T..F..O..', 'R..T..F..T..'], g: ['S..S..S..S..', 'S.SS..S.SS..'], k: ['C.....C..C..', 'M..M.MM..M..'] },
    march: { sub: 4, beats: 4, kit: 'soft', bt: 'upright', gt: 'nylon', kt: 'bell',
      dr: [{ K: 'x...x...x...x...', S: '....x.......x...', H: '................' }, { K: 'x...x...x...x...', S: '....x.......x.x.', H: '..x...x...x...x.' }],
      bs: ['R...F...R...F...', 'R...F...R.F.R.F.'], g: ['1...2...3...2...', 'S...S...S...S...'], k: ['C...C...C...C...', 'M.M.M.M.M---M---'] },
    trad: { sub: 3, beats: 4, kit: 'trad', bt: 'upright', gt: 'gayageum', kt: 'flute',
      dr: [{ K: 'x.....x..x..', S: '..x.x...x.x.', H: 'x.....x.....' }, { K: 'x..x..x..x..', S: '.xx.xx.xx.x.', H: 'x.xx.xx.xx.x' }],
      bs: ['R-----F-----', 'R..R..F..F..'], g: ['1..2..3..2..', '1.23.21.23.1'], k: ['M-----M--M--', 'M.MM.MM.MM..'] },
    elec: { sub: 4, beats: 4, kit: 'elec', bt: 'synth', gt: 'pluck', kt: 'synth',
      dr: [{ K: 'x...x...x...x...', S: '....x.......x...', H: '..x...x...x...x.' }, { K: 'x...x...x...x...', S: '....x.......x...', H: 'x.xxx.xxx.xxx.xx' }],
      bs: ['..R...R...R...R.', 'R.O.R.O.R.O.R.O.'], g: ['1.2.3.2.1.2.3.2.', 'S..S..S.S..S..S.'], k: ['1.2.3.4.1.2.3.4.', 'C--C--C-C--C--C-'] },
    bossa: { sub: 4, beats: 4, kit: 'soft', bt: 'upright', gt: 'nylon', kt: 'piano',
      dr: [{ K: 'x..xx..xx..xx..x', S: 'x..x..x...x..x..', H: 'x.x.x.x.x.x.x.x.' }, { K: 'x..xx..xx..xx..x', S: 'x..x...x..x..x..', H: 'x.x.x.x.x.x.x.x.' }],
      bs: ['R..F..R.R..F..R.', 'R..F..R.R..F..O.'], g: ['S..S..S...S..S..', 'S..S..S.S..S..S.'], k: ['C-------C-------', 'M...M..M.M..M...'] },
    reggae: { sub: 4, beats: 4, kit: 'rock', bt: 'synth', gt: 'clean', kt: 'organ',
      dr: [{ K: '........x.......', S: '........x.......', H: 'x.x.x.x.x.x.x.x.' }, { K: 'x.......x.......', S: '....x.......x...', H: 'x.x.x.x.x.x.x.x.' }],
      bs: ['R---..F.R---....', 'R---..F.O-F.R...'], g: ['....S.......S...', '..S...S...S...S.'], k: ['..C...C...C...C.', 'M...M...M.M.M...'] },
    metal: { sub: 4, beats: 4, kit: 'rock', bt: 'pick', gt: 'dist', kt: 'synth',
      dr: [{ K: 'x.x.x.x.x.x.x.x.', S: '....x.......x...', H: 'x...x...x...x...' }, { K: 'xxxxxxxxxxxxxxxx', S: '....x.......x...', H: 'x...x...x...x...' }],
      bs: ['R.R.R.R.R.R.R.R.', 'RRRRRRRRRRRRRRRR'], g: ['S.S.SS.S.S.SS.S.', 'S-------S-------'], k: ['C-------C-------', 'M.M.M.M.M.M.M.M.'] },
    waltz: { sub: 4, beats: 3, kit: 'soft', bt: 'upright', gt: 'nylon', kt: 'bell',
      dr: [{ K: 'x...........', S: '....x...x...', H: 'x...x...x...' }, { K: 'x.......x...', S: '....x...x...', H: 'x.x.x.x.x.x.' }],
      bs: ['R-------....', 'R...F...F...'], g: ['....S...S...', '1...S...S...'], k: ['M-------M---', 'M...M.M.M...'] },
  };
  const F = (s) => s.split(' ').map((x) => [x[0], +x.slice(1)]);
  const SONGS = [
    { nm: '새벽 질주', g: '록', sty: 'rock', bpm: 138, key: 4, sc: 'min', A: [0, 5, 2, 6], B: [5, 2, 6, 0], star: 3, form: F('I2 A8 B8 A8 B8 E2') },
    { nm: '땀방울 펑크', g: '펑크', sty: 'funk', bpm: 100, key: 9, sc: 'dor', A: [0, 3, 0, 3], B: [3, 3, 0, 4], star: 4, form: F('I2 A6 B8 A6 B8 E2') },
    { nm: '달빛 스윙', g: '재즈 스윙', sty: 'swing', bpm: 150, key: 5, sc: 'maj', A: [1, 4, 0, 0], B: [5, 1, 4, 0], star: 3, form: F('I2 A8 B8 A8 B8 E2') },
    { nm: '꼬마 행진곡', g: '동요풍', sty: 'march', bpm: 116, key: 0, sc: 'maj', A: [0, 3, 4, 0], B: [3, 0, 4, 0], star: 1, form: F('I2 A8 B8 A8 E2') },
    { nm: '마당 장단', g: '전통 장단', sty: 'trad', bpm: 90, key: 2, sc: 'pen', A: [0, 0, 3, 0], B: [3, 2, 0, 0], star: 2, form: F('I2 A8 B8 A8 E2') },
    { nm: '네온 하이웨이', g: '일렉트로', sty: 'elec', bpm: 126, key: 9, sc: 'min', A: [0, 0, 5, 6], B: [5, 6, 0, 4], star: 3, form: F('I4 A8 B8 A8 B8 E2') },
    { nm: '빗방울 보사', g: '보사노바', sty: 'bossa', bpm: 120, key: 7, sc: 'maj', A: [1, 4, 0, 5], B: [3, 2, 1, 4], star: 2, form: F('I2 A8 B8 A8 E2') },
    { nm: '바닷바람 레게', g: '레게', sty: 'reggae', bpm: 84, key: 2, sc: 'maj', A: [0, 3, 4, 3], B: [5, 3, 0, 4], star: 2, form: F('I2 A6 B8 A6 E2') },
    { nm: '강철 폭풍', g: '메탈', sty: 'metal', bpm: 168, key: 2, sc: 'min', A: [0, 0, 5, 6], B: [0, 6, 5, 4], star: 5, form: F('I2 A8 B8 A8 B8 E2') },
    { nm: '별빛 왈츠', g: '왈츠', sty: 'waltz', bpm: 138, key: 10, sc: 'maj', A: [0, 3, 4, 0], B: [5, 1, 4, 0], star: 1, form: F('I2 A8 B8 A8 B8 A8 E2') },
  ];
  SONGS.forEach((s, i) => { s.seed = 7919 * (i + 1) + 13; });

  const songCache = {};
  function song(si) {
    if (songCache[si]) return songCache[si];
    const sg = SONGS[si], sy = STY[sg.sty], sub = sy.sub, S = sub * sy.beats, sd = 60 / sg.bpm / sub, bd = 60 / sg.bpm;
    const sc = SC[sg.sc], n = sc.length, base = 36 + sg.key - (sg.key >= 7 ? 12 : 0);
    const deg = (o, d) => { const k = Math.floor(d / n), i = d - k * n; return o + k * 12 + sc[i]; };
    const tri = (o, cr) => [deg(o, cr), deg(o, cr + 2), deg(o, cr + 4)];
    const A = [[], [], [], []], C = [[], [], [], []];
    const bars = []; sg.form.forEach(([k, m]) => { for (let j = 0; j < m; j++) bars.push({ k, j, m }); });
    const imp = (st) => (st === 0 ? 3 : st % sub === 0 ? 2 : (sub === 4 ? st % 2 === 0 : st % sub === 2) ? 1 : 0);
    const snd = (p, t, k, nn, d) => A[p].push({ t, k, n: nn, d });
    const nt = (p, t, ln, im, len) => { const o = { t, ln, imp: im, len: len || 0 }; C[p].push(o); return o; };
    const dashes = (pat, st) => { let c = 0; while (st + 1 + c < pat.length && pat[st + 1 + c] === '-') c++; return c; };
    bars.forEach((b, bi) => {
      const t0 = bi * S * sd, pr = b.k === 'B' ? sg.B : sg.A, cr = b.k === 'E' ? 0 : pr[b.j % pr.length], v = b.k === 'B' ? 1 : 0;
      const c0 = C.map((a) => a.length);
      if (b.k === 'E') {
        if (b.j === 0) {
          const d = S * sd * 0.9;
          snd(0, t0, 'K', null, 0.3); nt(0, t0, 0, 3); snd(0, t0, 'C', null, 1.2); nt(0, t0, 2, 3);
          snd(1, t0, 'b', [deg(base, 0)], d); nt(1, t0, 0, 3, d * 0.85);
          snd(2, t0, 's', sy.gt === 'dist' ? [deg(base + 12, 0), deg(base + 12, 0) + 7, deg(base + 12, 0) + 12] : tri(base + 24, 0), d); nt(2, t0, -1, 3);
          snd(3, t0, 'c', tri(base + 24, 0), d); nt(3, t0, 0, 3); nt(3, t0, 1, 3);
        }
        return;
      }
      // drums (fill on the last bar of a section, crash on the first)
      const dp = sy.dr[v], sec = b.k === 'A' || b.k === 'B';
      const fill = sec && b.j === b.m - 1, crash = sec && b.j === 0;
      for (let st = 0; st < S; st++) {
        const tt = t0 + st * sd, im = imp(st);
        if (fill && st >= S / 2) {
          if (st === S / 2) { snd(0, tt, 'K', null, 0.25); nt(0, tt, 0, 2); }
          snd(0, tt, 'S', null, 0.15); nt(0, tt, 1, Math.max(im, 1));
          continue;
        }
        if (dp.K[st] === 'x') { snd(0, tt, 'K', null, 0.25); nt(0, tt, 0, im); }
        if (dp.S[st] === 'x') { snd(0, tt, 'S', null, 0.15); nt(0, tt, 1, im); }
        if (crash && st === 0) { snd(0, tt, 'C', null, 1.2); nt(0, tt, 2, 3); }
        else if (dp.H[st] === 'x') { snd(0, tt, 'H', null, 0.05); nt(0, tt, 2, Math.max(0, im - 1)); }
      }
      if (b.k === 'I') { // intro: drums + one long bass note per bar
        const d = S * sd * 0.92;
        snd(1, t0, 'b', [deg(base, cr)], d); nt(1, t0, 0, 3, d * 0.85);
      } else {
        // bass
        const bp = sy.bs[v];
        for (let st = 0; st < S; st++) {
          const c = bp[st]; if (!'RFTO'.includes(c)) continue;
          const ds = dashes(bp, st), d = (1 + ds) * sd;
          const pt = c === 'R' ? deg(base, cr) : c === 'F' ? deg(base, cr + 4) : c === 'T' ? deg(base, cr + 2) : deg(base, cr) + 12;
          snd(1, t0 + st * sd, 'b', [pt], Math.max(d * 0.92, 0.12));
          const hold = ds >= 2 && d >= 0.5;
          nt(1, t0 + st * sd, c === 'R' ? 0 : 1, imp(st) + (hold ? 1 : 0), hold ? d * 0.85 : 0);
        }
        // guitar
        const gp = sy.g[v], T3 = tri(base + 24, cr);
        for (let st = 0; st < S; st++) {
          const c = gp[st]; if (c === '.' || c === '-') continue;
          const d = (1 + dashes(gp, st)) * sd, tt = t0 + st * sd;
          if (c === 'S') { snd(2, tt, 's', sy.gt === 'dist' ? [deg(base + 12, cr), deg(base + 12, cr) + 7, deg(base + 12, cr) + 12] : T3, d); nt(2, tt, -1, imp(st)); }
          else { const i = +c - 1; snd(2, tt, 'p', [T3[i]], Math.max(d, sd * 2)); nt(2, tt, i, imp(st)); }
        }
        // keys (melody from a seeded generator: the same section bar repeats the same tune)
        const kp = sy.k[v], r = rng(sg.seed * 131 + (v ? 7 : 3) * 17 + (b.j % 4) * 5);
        let prev = cr + n; const mel = [];
        for (let st = 0; st < S; st++) {
          const c = kp[st]; if (c === '.' || c === '-') continue;
          const d = (1 + dashes(kp, st)) * sd, tt = t0 + st * sd;
          if (c === 'C') { const a = ((cr % 3) + 3) % 3; snd(3, tt, 'c', tri(base + 24, cr), Math.max(d, sd * 2)); nt(3, tt, a, imp(st)); nt(3, tt, a + 1, imp(st)); }
          else if (c === 'M') {
            let md;
            if (st % sub === 0) { const tg = prev + Math.round((r() - 0.5) * 4); let best = 0, bd2 = 99; for (let o = 0; o < 3; o++) for (const x of [0, 2, 4]) { const dd = cr + x + o * n; if (Math.abs(dd - tg) < bd2) { bd2 = Math.abs(dd - tg); best = dd; } } md = best; }
            else md = prev + [-2, -1, 1, 2][Math.floor(r() * 4)];
            md = clamp(md, n - 1, 2 * n + 3); prev = md;
            const ev = { t: tt, k: 'm', n: [deg(base + 24, md)], d: Math.max(d, sd * 1.5) }; A[3].push(ev);
            mel.push([nt(3, tt, 0, imp(st)), md]);
          } else { const i = +c - 1, T = tri(base + 24, cr); snd(3, tt, 'm', [i < 3 ? T[i] : T[0] + 12], Math.max(d, sd * 1.5)); nt(3, tt, i, imp(st)); }
        }
        if (mel.length) { // melody lanes follow the tune's contour within the bar
          let lo = 99, hi = -99; mel.forEach(([, d]) => { lo = Math.min(lo, d); hi = Math.max(hi, d); });
          mel.forEach(([o, d]) => { o.ln = hi === lo ? ((d % 4) + 4) % 4 : Math.round((d - lo) / (hi - lo) * 3); });
        }
      }
      // every bar keeps its strongest notes on easy charts: lift the bar so its best note reaches importance 2
      for (let p = 0; p < 4; p++) {
        let mx = -1; for (let i = c0[p]; i < C[p].length; i++) mx = Math.max(mx, C[p][i].imp);
        if (mx >= 0 && mx < 2) for (let i = c0[p]; i < C[p].length; i++) C[p][i].imp += 2 - mx;
      }
    });
    const len = bars.length * S * sd, lead = 4 * bd + 1.2;
    const clk = [4, 3, 2, 1].map((k) => -k * bd);
    const secAt = bars.map((b) => b.k);
    return (songCache[si] = { si, sg, sy, S, sd, bd, A, C, len, lead, clk, secAt, barLen: S * sd, chartCache: {} });
  }
  const GAP = [0, 0.3, 0.18, 0.11];
  function chart(si, lvl, p) {
    const so = song(si), key = lvl + '.' + p;
    if (so.chartCache[key]) return so.chartCache[key];
    const th = lvl === 1 ? 2 : lvl === 2 ? 1 : 0, gap = GAP[lvl] || GAP[2];
    const order = so.C[p].filter((c) => c.imp >= th).sort((a, b) => b.imp - a.imp || a.t - b.t);
    const acc = [];
    for (const c of order) {
      let ok = true, same = 0;
      for (const a of acc) {
        const d = Math.abs(a.t - c.t);
        if (d < 1e-4) { same++; if (lvl === 1 || a.ln === c.ln || same >= 2 || a.ln < 0 || c.ln < 0) { ok = false; break; } }
        else if (d < gap) { ok = false; break; }
        if (a.len > 0 && c.t > a.t && c.t < a.t + a.len + 0.05) { ok = false; break; }
        if (c.len > 0 && a.t > c.t && a.t < c.t + c.len + 0.05) { ok = false; break; }
      }
      if (ok) acc.push(c);
    }
    acc.sort((a, b) => a.t - b.t || a.ln - b.ln);
    return (so.chartCache[key] = acc.map((c) => ({ t: c.t, ln: c.ln, len: c.len })));
  }

  /* ======================= coarse state ======================= */
  function init(players, opts) {
    const o = opts || {}, n = clamp(players.length, 1, 4);
    const si = o.song === 'rand' || o.song == null || !(+o.song >= 0 && +o.song < SONGS.length) ? U.rand(SONGS.length) : +o.song;
    const s = { rid: 1 + U.rand(99999), n, nm: players.slice(0, n).map((p) => String((p && p.name) || '').slice(0, 10)), ai: players.slice(0, n).map((p) => (p && p.ai ? 1 : 0)),
      ins: players.slice(0, n).map(() => -1), song: si, lvl: [1, 2, 3].includes(+o.lvl) ? +o.lvl : 2, fail: +o.fail === 1 ? 1 : 0, ph: 'pick', fin: null, ok: 1, m: 0 };
    if (!s.ai.includes(0)) fillAI(s);
    return s;
  }
  function fillAI(s) {
    const free = [0, 1, 2, 3].filter((p) => !s.ins.includes(p));
    U.shuffle(free);
    for (let i = 0; i < s.n; i++) if (s.ins[i] < 0) s.ins[i] = free.shift();
    s.ph = 'play';
  }
  function actor(s) {
    if (!s || s.ph !== 'pick') return null;
    const a = []; for (let i = 0; i < s.n; i++) if (!s.ai[i] && s.ins[i] < 0) a.push(i);
    return a.length ? a : null;
  }
  function apply(s, seat, a) {
    if (!a || a.t !== 'pick' || s.ph !== 'pick' || s.ins[seat] !== -1 || s.ai[seat]) throw new Error('bad action');
    const p = a.p | 0; if (p < 0 || p > 3 || s.ins.includes(p)) throw new Error('taken');
    s.ins[seat] = p;
    if (!actor(s)) fillAI(s);
    return s;
  }
  function ai(s, seat) {
    if (!s || s.ph !== 'pick') return null;
    const free = [0, 1, 2, 3].filter((p) => !s.ins.includes(p));
    return free.length ? { t: 'pick', p: free[U.rand(free.length)] } : null;
  }
  const GRADES = [[95, 'S'], [88, 'A'], [78, 'B'], [65, 'C'], [0, 'D']];
  const accOf = (P, G, M) => (P + G + M ? (P + 0.7 * G) / (P + G + M) * 100 : 0);
  function bandSummary(s) {
    let P = 0, G = 0, M = 0, pts = 0;
    (s.fin || []).forEach((f) => { if (f) { P += f[0]; G += f[1]; M += f[2]; pts += f[4]; } });
    const acc = accOf(P, G, M);
    const grade = !s.ok ? 'D' : GRADES.find(([v]) => acc >= v)[1];
    return { acc, grade, pts };
  }
  function result(s) {
    if (!s || s.ph !== 'done') return null;
    const b = bandSummary(s), sg = SONGS[s.song];
    const lines = ['밴드 점수 ' + b.pts.toLocaleString('ko-KR') + ' · 밴드 정확도 ' + Math.floor(b.acc) + '%'];
    for (let i = 0; i < s.n; i++) { const f = s.fin && s.fin[i]; if (!f) continue; lines.push(s.nm[i] + ' (' + INST[s.ins[i]].nm + ') 정확도 ' + Math.floor(accOf(f[0], f[1], f[2])) + '% · 최고 콤보 ' + f[3]); }
    const all = []; for (let i = 0; i < s.n; i++) all.push(i);
    return { winners: s.ok ? all : [], title: (s.ok ? '밴드 등급 ' + b.grade : '공연 중단… 등급 D') + ' · ' + sg.nm, text: lines.join('\n') };
  }

  /* ======================= run (pure, used by host and guests) ======================= */
  const AIC = { 1: { miss: 0.12, sd: 0.06, brk: 0.25 }, 2: { miss: 0.045, sd: 0.035, brk: 0.08 }, 3: { miss: 0.012, sd: 0.018, brk: 0.02 } };
  function newRun(s, isHost) {
    const so = song(s.song), ch = [0, 1, 2, 3].map((p) => chart(s.song, s.lvl, p));
    const seats = [];
    for (let i = 0; i < s.n; i++) { const p = s.ins[i]; seats.push({ p, P: 0, G: 0, M: 0, c: 0, mc: 0, pts: 0, gr: 1, ptr: 0, jd: p >= 0 ? new Uint8Array(ch[p].length) : null, holds: {}, tails: [], ai: { k: -1 } }); }
    return { T: -so.lead, so, ch, seats, meter: 60, host: !!isHost, len: so.len, fail: !!s.fail, out: false };
  }
  function bandMult(R, i) { let k = 0; R.seats.forEach((o, j) => { if (j !== i && o.p >= 0 && o.gr) k++; }); return 1 + 0.15 * k; }
  function judge(R, i, g, nt, hooks) {
    const se = R.seats[i];
    if (g === 3) { se.M++; se.c = 0; se.gr = 0; if (R.host) R.meter = Math.max(0, R.meter - 3); }
    else {
      if (g === 1) se.P++; else se.G++;
      se.c++; if (se.c > se.mc) se.mc = se.c; se.gr = 1;
      se.pts += (g === 1 ? 100 : 60) * (1 + Math.min(3, Math.floor(se.c / 10)) * 0.5) * bandMult(R, i);
      if (R.host) R.meter = Math.min(100, R.meter + (g === 1 ? 1 : 0.6));
    }
    if (hooks && hooks.judge) hooks.judge(i, g, nt);
  }
  function applyRemote(R, i, a) { // host: a = [P,G,M,c,mc,pts,gr] from the guest's phone
    const se = R.seats[i]; if (!se || se.p < 0 || !Array.isArray(a)) return;
    const dP = (a[0] | 0) - se.P, dG = (a[1] | 0) - se.G, dM = (a[2] | 0) - se.M;
    if (dP >= 0 && dG >= 0 && dM >= 0 && R.host) R.meter = clamp(R.meter + dP + dG * 0.6 - dM * 3, 0, 100);
    se.P = a[0] | 0; se.G = a[1] | 0; se.M = a[2] | 0; se.c = a[3] | 0; se.mc = a[4] | 0; se.pts = +a[5] || 0; se.gr = a[6] ? 1 : 0;
  }
  /* human seat: notes whose window passed are misses; held notes that reach their end count as a hit */
  function sweep(R, i, Te, hooks) {
    const se = R.seats[i]; if (!se || se.p < 0) return;
    const ch = R.ch[se.p];
    while (se.ptr < ch.length && se.jd[se.ptr]) se.ptr++;
    for (let k = se.ptr; k < ch.length && ch[k].t + GW < Te; k++) if (!se.jd[k]) { se.jd[k] = 3; judge(R, i, 3, ch[k], hooks); }
    for (const ln in se.holds) { const h = se.holds[ln]; if (Te >= h.end) { delete se.holds[ln]; judge(R, i, 1, { t: h.end, ln: +ln, tail: 1 }, hooks); } }
  }
  function press(R, i, lane, Tin, hooks) {
    const se = R.seats[i]; if (!se || se.p < 0) return 0;
    const ch = R.ch[se.p];
    let best = -1;
    for (let k = se.ptr; k < ch.length && ch[k].t <= Tin + GW; k++) {
      if (se.jd[k]) continue;
      const nt = ch[k]; if (Math.abs(nt.t - Tin) > GW) continue;
      if (lane < 0 ? nt.ln !== -1 : (nt.ln !== lane && nt.ln !== -1)) continue;
      best = k; break;
    }
    if (best < 0) return 0;
    const nt = ch[best], g = Math.abs(nt.t - Tin) <= PW ? 1 : 2;
    se.jd[best] = g; judge(R, i, g, nt, hooks);
    if (nt.len > 0) se.holds[nt.ln] = { end: nt.t + nt.len, k: best };
    return g;
  }
  function release(R, i, lane, Tin, hooks) {
    const se = R.seats[i]; if (!se || !se.holds[lane]) return;
    const h = se.holds[lane]; delete se.holds[lane];
    judge(R, i, Tin < h.end - HOLD_GRACE ? 3 : 1, { t: h.end, ln: lane, tail: 1 }, hooks);
  }
  function aiSeat(R, i, lv, hooks) {
    const se = R.seats[i]; if (!se || se.p < 0) return;
    const C = AIC[lv] || AIC[2], ch = R.ch[se.p], m = se.ai;
    while (se.ptr < ch.length) {
      const k = se.ptr, nt = ch[k];
      if (se.jd[k]) { se.ptr++; continue; }
      if (m.k !== k) { m.k = k; m.miss = Math.random() < C.miss; m.off = gauss() * C.sd; m.brk = Math.random() < C.brk; }
      const due = m.miss ? nt.t + GW : nt.t + m.off;
      if (R.T < due) break;
      const ao = Math.abs(m.off), g = m.miss ? 3 : ao <= PW ? 1 : ao <= GW ? 2 : 3;
      se.jd[k] = g; se.ptr++;
      judge(R, i, g, nt, hooks);
      if (g !== 3 && nt.len > 0) se.tails.push([nt.t + nt.len * (m.brk ? 0.5 : 1), m.brk ? 3 : 1, nt.ln]);
    }
    for (let j = se.tails.length - 1; j >= 0; j--) { const tl = se.tails[j]; if (R.T >= tl[0]) { se.tails.splice(j, 1); judge(R, i, tl[1], { t: tl[0], ln: tl[2], tail: 1 }, hooks); } }
  }
  function finalize(s, R) {
    const fin = R.seats.map((se) => (se.p < 0 ? null : [se.P, se.G, se.M, se.mc, Math.round(se.pts)]));
    return Object.assign({}, s, { ph: 'done', fin, ok: R.out ? 0 : 1, m: Math.round(R.meter) });
  }
  /* headless all-AI run (node tests) */
  function simulate(s, lvs, dt) {
    const R = newRun(s, true); let guard = 0;
    while (R.T < R.len + 0.3 && guard++ < 1e6) {
      R.T += dt || 1 / 60;
      for (let i = 0; i < s.n; i++) aiSeat(R, i, lvs[i] || 2);
      if (R.fail && R.meter <= 0 && R.T > 0) { R.out = true; break; }
    }
    return finalize(s, R);
  }

  /* ======================= audio (WebAudio synth) ======================= */
  const Aud = {
    ac: null, master: null, tr: null, noise: null, curve: null,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() {
      if (!this.on()) return null;
      try {
        if (!this.ac) {
          const ac = this.ac = new (window.AudioContext || window.webkitAudioContext)();
          const comp = ac.createDynamicsCompressor(); comp.threshold.value = -16; comp.ratio.value = 4;
          this.master = ac.createGain(); this.master.gain.value = 0.8; this.master.connect(comp); comp.connect(ac.destination);
          this.tr = [0, 1, 2, 3].map(() => { const g = ac.createGain(); g.connect(this.master); return g; });
          this.tr.push(this.master); // [4] = clicks
          const nb = ac.createBuffer(1, ac.sampleRate, ac.sampleRate), d = nb.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; this.noise = nb;
          const cv = new Float32Array(256); for (let i = 0; i < 256; i++) { const x = i / 128 - 1; cv[i] = Math.tanh(x * 4); } this.curve = cv;
        }
        if (this.ac.state === 'suspended') this.ac.resume();
        return this.ac;
      } catch (e) { return null; }
    },
    close() { try { this.ac && this.ac.close(); } catch (e) {} this.ac = null; this.master = null; this.tr = null; },
  };
  const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
  function envG(ac, t, peak, a, dec, out) { const g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + dec); g.connect(out); return g; }
  function noiseHit(ac, t, out, type, f, q, peak, dec) {
    const s = ac.createBufferSource(), fl = ac.createBiquadFilter(); s.buffer = Aud.noise; fl.type = type; fl.frequency.value = f; fl.Q.value = q || 1;
    s.connect(fl).connect(envG(ac, t, peak, 0.002, dec, out)); s.start(t); s.stop(t + dec + 0.05);
  }
  function tone(ac, t, out, type, f, peak, a, dec, f2) {
    const o = ac.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + Math.min(dec, 0.2));
    o.connect(envG(ac, t, peak, a, dec, out)); o.start(t); o.stop(t + a + dec + 0.05);
  }
  function playEv(ac, out, t, ev, p, sy, sp) {
    const d = ev.d / sp;
    if (p === 0) {
      const kit = sy.kit;
      if (ev.k === 'K') { if (kit === 'trad') tone(ac, t, out, 'sine', 120, 0.9, 0.003, 0.4, 62); else if (kit === 'elec') tone(ac, t, out, 'sine', 160, 1, 0.002, 0.35, 42); else tone(ac, t, out, 'sine', 130, kit === 'soft' || kit === 'jazz' ? 0.6 : 0.9, 0.002, 0.22, 45); }
      else if (ev.k === 'S') {
        if (kit === 'trad') { noiseHit(ac, t, out, 'bandpass', 900, 2, 0.5, 0.09); tone(ac, t, out, 'triangle', 320, 0.3, 0.002, 0.08); }
        else if (kit === 'elec') { for (let k = 0; k < 3; k++) noiseHit(ac, t + k * 0.012, out, 'bandpass', 1500, 1.2, 0.35, 0.06); }
        else if (kit === 'jazz' || kit === 'soft') noiseHit(ac, t, out, 'bandpass', 1300, 0.8, 0.25, 0.14);
        else { noiseHit(ac, t, out, 'bandpass', 1900, 0.9, 0.45, 0.14); tone(ac, t, out, 'triangle', 190, 0.25, 0.002, 0.08); }
      } else if (ev.k === 'H') {
        if (kit === 'trad') { tone(ac, t, out, 'square', 1180, 0.06, 0.002, 0.16); tone(ac, t, out, 'square', 1710, 0.05, 0.002, 0.14); }
        else if (kit === 'jazz') noiseHit(ac, t, out, 'highpass', 6000, 1, 0.12, 0.28);
        else noiseHit(ac, t, out, 'highpass', 7500, 1, kit === 'soft' ? 0.08 : 0.12, 0.04);
      } else if (ev.k === 'C') {
        if (kit === 'trad') { tone(ac, t, out, 'square', 1180, 0.09, 0.002, 0.6); tone(ac, t, out, 'square', 1710, 0.07, 0.002, 0.5); }
        else noiseHit(ac, t, out, 'highpass', 4500, 0.7, 0.22, 0.9 / Math.max(1, sp * 0.5));
      }
      return;
    }
    if (p === 1) {
      const f = mtof(ev.n[0]), o = ac.createOscillator(), fl = ac.createBiquadFilter(), g = ac.createGain();
      o.type = sy.bt === 'upright' ? 'triangle' : 'sawtooth'; o.frequency.value = f;
      fl.type = 'lowpass'; fl.frequency.setValueAtTime(sy.bt === 'synth' ? 1400 : 900, t); fl.frequency.exponentialRampToValueAtTime(sy.bt === 'synth' ? 300 : 420, t + Math.min(0.3, d));
      const pk = sy.bt === 'upright' ? 0.75 : 0.42;
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(pk, t + 0.006); g.gain.exponentialRampToValueAtTime(pk * 0.55, t + 0.12);
      g.gain.setValueAtTime(pk * 0.55, t + Math.max(0.13, d)); g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(0.13, d) + 0.08);
      o.connect(fl).connect(g).connect(out); o.start(t); o.stop(t + Math.max(0.13, d) + 0.1);
      return;
    }
    if (p === 2) {
      const gt = sy.gt, notes = ev.n, stag = ev.k === 's' ? 0.014 / sp : 0;
      if (gt === 'dist') {
        const sh = ac.createWaveShaper(); sh.curve = Aud.curve; const fl = ac.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 2600;
        const g = ac.createGain(), dd = Math.max(0.12, d); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.16, t + 0.008); g.gain.setValueAtTime(0.13, t + dd); g.gain.exponentialRampToValueAtTime(0.0001, t + dd + 0.1);
        sh.connect(fl).connect(g).connect(out);
        notes.forEach((m, k) => { for (const dt of [-6, 6]) { const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = mtof(m); o.detune.value = dt; const pg = ac.createGain(); pg.gain.value = 0.35; o.connect(pg).connect(sh); o.start(t + k * stag); o.stop(t + dd + 0.12); } });
      } else {
        const ty = gt === 'pluck' ? 'square' : gt === 'nylon' ? 'triangle' : gt === 'gayageum' ? 'triangle' : 'sawtooth';
        const dec = gt === 'gayageum' ? 0.7 : gt === 'pluck' ? 0.18 : 0.45;
        notes.forEach((m, k) => {
          const tt = t + k * stag, o = ac.createOscillator(), fl = ac.createBiquadFilter(); o.type = ty;
          o.frequency.setValueAtTime(mtof(m) * (gt === 'gayageum' ? 1.02 : 1), tt); if (gt === 'gayageum') o.frequency.exponentialRampToValueAtTime(mtof(m), tt + 0.08);
          fl.type = 'lowpass'; fl.frequency.setValueAtTime(gt === 'clean' ? 2200 : 3000, tt); fl.frequency.exponentialRampToValueAtTime(600, tt + dec);
          o.connect(fl).connect(envG(ac, tt, ev.k === 's' ? 0.11 : 0.16, 0.003, Math.min(dec, d + 0.25), out)); o.start(tt); o.stop(tt + dec + 0.1);
        });
      }
      return;
    }
    // keys
    const kt = sy.kt, dd = Math.max(0.1, d), pk = ev.k === 'c' ? 0.07 : 0.12;
    ev.n.forEach((m) => {
      const f = mtof(m);
      if (kt === 'piano') { tone(ac, t, out, 'sine', f, pk * 1.4, 0.004, Math.min(1.1, dd + 0.4)); tone(ac, t, out, 'triangle', f * 2, pk * 0.35, 0.004, 0.35); }
      else if (kt === 'bell') { tone(ac, t, out, 'sine', f, pk * 1.4, 0.003, 1.0); tone(ac, t, out, 'sine', f * 2.76, pk * 0.3, 0.003, 0.4); }
      else if (kt === 'flute') {
        const o = ac.createOscillator(), lfo = ac.createOscillator(), lg = ac.createGain(), g = ac.createGain(); o.type = 'sine'; o.frequency.value = f; lfo.frequency.value = 5.5; lg.gain.value = f * 0.012;
        lfo.connect(lg).connect(o.frequency); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(pk * 1.6, t + 0.05); g.gain.setValueAtTime(pk * 1.4, t + dd); g.gain.exponentialRampToValueAtTime(0.0001, t + dd + 0.12);
        o.connect(g).connect(out); o.start(t); lfo.start(t); o.stop(t + dd + 0.15); lfo.stop(t + dd + 0.15);
      } else {
        const g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(pk, t + 0.01); g.gain.setValueAtTime(pk * 0.85, t + dd); g.gain.exponentialRampToValueAtTime(0.0001, t + dd + 0.08); g.connect(out);
        const hs = kt === 'organ' ? [[1, 'sine', 1], [2, 'sine', 0.5], [3, 'sine', 0.3]] : [[1, 'square', 0.5], [1.005, 'sawtooth', 0.4]];
        const fl = ac.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = kt === 'synth' ? 2200 : 5000; fl.connect(g);
        hs.forEach(([h, ty, v]) => { const o = ac.createOscillator(), og = ac.createGain(); o.type = ty; o.frequency.value = f * h; og.gain.value = v; o.connect(og).connect(fl); o.start(t); o.stop(t + dd + 0.1); });
      }
    });
  }
  function click(ac, out, t, acc) { tone(ac, t, out, 'sine', acc ? 2000 : 1500, 0.35, 0.001, 0.05); }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const LANE_COL = [['#ee6a55', '#f2e9d8', '#e3ae45'], ['#8c95ff', '#c08cff'], ['#8fe3a8', '#ee6a55', '#ffe27a'], ['#9fdcff', '#c3a6ff', '#ffd27a', '#8fe3a8']];
  const STRUM = '#ff9de0';
  const LOOK = [0, 1.7, 1.45, 1.25];
  const GR = { 1: ['퍼펙트!', '#ffe27a'], 2: ['좋아요', '#8fe3a8'], 3: ['놓침', '#ab9fb8'] };
  const SEC = { I: '인트로', A: '1절', B: '후렴', E: '마무리' };
  const TIPS = [
    ['음표가 선에 닿을 때 그 패드를 톡!', '두 개가 같이 오면 두 손가락으로'],
    ['음표가 선에 닿을 때 그 줄을 톡!', '꼬리가 긴 음표는 끝까지 꾹 누르기'],
    ['음표가 선에 닿을 때 그 줄을 톡!', '가로로 긴 분홍 줄은 아무 칸이나 톡'],
    ['음표가 선에 닿을 때 그 건반을 톡!', '선으로 이어진 화음은 두 손가락으로'],
  ];
  const padNames = (p, kit) => (p === 0 ? (kit === 'trad' ? ['북', '장구', '꽹과리'] : ['킥', '스네어', '심벌']) : p === 1 ? ['낮은 줄', '높은 줄'] : p === 2 ? ['줄 1', '줄 2', '줄 3'] : ['1', '2', '3', '4']);
  const CSS = `
.bd-pick{position:absolute;left:0;right:0;bottom:0;z-index:8;padding:16px 12px calc(14px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.97) 12%);display:flex;flex-direction:column;gap:10px}
.bd-pick h3{margin:0;font-family:var(--f-display,sans-serif);font-weight:400;font-size:22px;color:#f2e9d8}
.bd-pick .sub{font-size:13px;color:#ab9fb8;line-height:1.4}
.bd-pick .song{font:600 14px var(--f-body,sans-serif);color:#f2e9d8;background:#2e2640;border:1px solid rgba(227,174,69,.35);border-radius:12px;padding:8px 12px;line-height:1.4}
.bd-pick .song b{color:#e3ae45}
.bd-pick .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.bd-pick .grid button{min-height:70px;border-radius:14px;border:2px solid rgba(255,255,255,.14);background:#221c2e;color:#f2e9d8;font:20px var(--f-display,sans-serif);text-align:left;padding:8px 12px;touch-action:manipulation;position:relative}
.bd-pick .grid button small{display:block;font:600 11.5px/1.35 var(--f-body,sans-serif);color:#ab9fb8;margin-top:3px}
.bd-pick .grid button:active{transform:scale(.97)}
.bd-pick .grid button[disabled]{opacity:.42}
.bd-pick .cal{min-height:46px;border-radius:12px;border:1px solid rgba(227,174,69,.5);background:transparent;color:#e3ae45;font:700 14px var(--f-body,sans-serif);touch-action:manipulation}
.bd-cal{position:absolute;inset:0;z-index:12;background:rgba(18,14,25,.97);display:flex;flex-direction:column;align-items:stretch;gap:12px;padding:18px 16px calc(16px + env(safe-area-inset-bottom));box-sizing:border-box}
.bd-cal h3{margin:0;font-family:var(--f-display,sans-serif);font-weight:400;font-size:24px;color:#f2e9d8}
.bd-cal p{margin:0;font-size:13.5px;line-height:1.5;color:#ab9fb8}
.bd-cal .pad{flex:1;min-height:150px;border-radius:20px;border:2px solid rgba(227,174,69,.6);background:#2e2640;color:#f2e9d8;font:34px var(--f-display,sans-serif);touch-action:manipulation;transition:background .08s}
.bd-cal .pad.flash{background:#4a3a66}
.bd-cal .res{font:700 15px var(--f-mono,monospace);color:#e3ae45;text-align:center;min-height:22px}
.bd-cal .row2{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}
.bd-cal .row2 button{min-height:46px;border-radius:12px;font:700 14px var(--f-body,sans-serif);touch-action:manipulation}
`;
  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const host = () => !api.online || api.isHost;
    let st = null, key = null, R = null, partSeat = [-1, -1, -1, -1];
    let mine = -1, pick = null, pickSig = '', cal = null;
    let frameNow = performance.now(), aPtr = [0, 0, 0, 0, 0], anchor = null, lastSchedT = -1e9, trVol = [-1, -1, -1, -1];
    let endAt = 0, pubT = 0, hsQ = 0, lastQ = -1, clockBase = null, doneShown = false;
    const pidLane = {}, flash = [0, 0, 0, 0], fx = [];
    let jt = null, bgC = null, bgSig = '';
    const myLat = () => { const v = U.store.get('band.lat', null); if (v != null && isFinite(v)) return clamp(+v, -150, 400) / 1000; const ac = Aud.ac; return ac ? clamp((ac.outputLatency || ac.baseLatency || 0), 0, 0.25) : 0; };
    let latS = myLat();
    const drive = (i) => { const p = api.players[i]; if (!p) return false; return host() ? (!!p.ai || !!p.local || !api.online) : (!!p.local && !p.ai); };
    const lvOf = (i) => { const p = api.players[i]; return p && p.ai ? (p.lv || 2) : 3; };
    const autoMine = () => !!(L.debug && L.debug.autoplay);

    const hooks = {
      judge(i, g, nt) {
        if (i !== mine) return;
        jt = { txt: GR[g][0], col: GR[g][1], t: 0.55 };
        if (g !== 3 && nt && !nt.tail) {
          const lanes = nt.ln < 0 ? [...Array(INST[R.seats[i].p].lanes).keys()] : [nt.ln];
          for (const ln of lanes) { flash[ln] = 1; if (fx.length < 24) fx.push({ ln, t: 0.35, g }); }
          if (g === 1) api.buzz(8);
        }
        const c = R.seats[i].c; if (g !== 3 && c > 0 && c % 50 === 0) api.toast(c + ' 콤보!');
      },
    };

    /* ----- layout ----- */
    const HB = 70;
    function hwRect() { return { x: 6, y: HB + 4, w: cv.w - 12, h: cv.h - HB - 10 }; }
    function padH(hw) { return Math.round(clamp(hw.h * 0.17, 64, 104)); }
    function laneAt(x) { const hw = hwRect(), n = INST[R.seats[mine].p].lanes; return clamp(Math.floor((x - hw.x) / (hw.w / n)), 0, n - 1); }

    /* ----- clock / input ----- */
    function tNow(ts) {
      const pn = performance.now(); let at = pn;
      if (ts && Math.abs(ts - pn) < 1000) at = Math.min(ts, pn);
      return R.T + (at - frameNow) / 1000 * SPD();
    }
    const canPlay = () => R && st && st.ph === 'play' && mine >= 0 && R.seats[mine] && R.seats[mine].p >= 0 && !autoMine();
    function onDown(e) {
      e.preventDefault(); Aud.ctx();
      if (!canPlay()) return;
      const p = cv.local(e); if (p.y < HB) return;
      const ln = laneAt(p.x); pidLane[e.pointerId] = ln; flash[ln] = Math.max(flash[ln], 0.6);
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      if (R.T < -0.3) return;
      press(R, mine, ln, tNow(e.timeStamp) - latS, hooks);
    }
    function onUp(e) {
      const ln = pidLane[e.pointerId]; delete pidLane[e.pointerId];
      if (ln == null || !canPlay()) return;
      if (Object.values(pidLane).includes(ln)) return; // another finger still holds this lane
      release(R, mine, ln, tNow(e.timeStamp) - latS, hooks);
    }
    const keyHeld = {};
    const offIn = api.input ? api.input.on((type, id) => {
      if (!canPlay()) return;
      const n = INST[R.seats[mine].p].lanes, ln = id === 'strum' ? -1 : ['l1', 'l2', 'l3', 'l4'].indexOf(id);
      if (ln >= n || (ln < 0 && id !== 'strum')) return;
      if (type === 'down') { if (keyHeld[id]) return; keyHeld[id] = 1; Aud.ctx(); if (ln >= 0) flash[ln] = Math.max(flash[ln], 0.6); if (R.T >= -0.3) press(R, mine, ln, tNow() - latS, hooks); }
      else { keyHeld[id] = 0; if (ln >= 0) release(R, mine, ln, tNow() - latS, hooks); }
    }) : () => {};
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- instrument picker ----- */
    function syncPick() {
      if (!st || st.ph !== 'pick') { if (pick) { pick.remove(); pick = null; } pickSig = ''; return; }
      const seat = mine >= 0 && st.ins[mine] === -1 && !st.ai[mine] ? mine : -1;
      const sig = st.ins.join(',') + '|' + seat + '|' + Math.round(latS * 1000);
      if (pick && sig === pickSig) return;
      pickSig = sig; if (pick) pick.remove();
      const sg = SONGS[st.song], who = (p) => { const i = st.ins.indexOf(p); return i >= 0 ? st.nm[i] : ''; };
      const waiting = []; for (let i = 0; i < st.n; i++) if (!st.ai[i] && st.ins[i] < 0 && i !== mine) waiting.push(st.nm[i]);
      const btn = (p) => L.h('button', { disabled: seat < 0 || st.ins.includes(p), style: { borderColor: st.ins.includes(p) ? 'rgba(255,255,255,.1)' : INST[p].col }, onclick() {
        if (seat < 0) return; Aud.ctx(); api.sfx('click'); api.buzz(12); api.actAs(seat, { t: 'pick', p });
      } }, INST[p].nm, L.h('small', { text: st.ins.includes(p) ? who(p) + ' 연주' : INST[p].desc }));
      const lat = Math.round(latS * 1000);
      pick = L.h('div', { class: 'bd-pick' },
        L.h('h3', { text: seat >= 0 ? '어떤 악기를 맡을까요?' : '다른 사람이 고르는 중…' }),
        L.h('div', { class: 'song' }, '♪ ', L.h('b', { text: sg.nm }), ' · ' + sg.g + ' · ' + '★'.repeat(sg.star) + ' · 악보 ' + ['', '쉬움', '보통', '어려움'][st.lvl]),
        L.h('div', { class: 'grid' }, [0, 1, 2, 3].map(btn)),
        L.h('div', { class: 'sub', text: seat >= 0 ? '남은 악기는 AI 연주자가 맡고, 사람이 4명보다 적으면 빈 악기는 작은 반주로 깔려요.' : '기다리는 중: ' + (waiting.join(', ') || '…') }),
        L.h('button', { class: 'cal', onclick() { openCal(); } }, '⏱ 박자 맞추기 (지금 보정 ' + (lat >= 0 ? '+' : '') + lat + 'ms)'));
      pick.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(pick);
    }
    /* ----- latency calibration: tap along to 12 clicks, median offset is stored on this phone ----- */
    function openCal() {
      if (cal) return;
      const ac = Aud.ctx();
      const N = 12, gap = 0.6;
      let clicks = [], taps = [], timers = [], startPerf = 0, done = false;
      const res = L.h('div', { class: 'res', text: '' });
      const padEl = L.h('button', { class: 'pad', text: '톡!' });
      const info = L.h('p', { text: ac ? '「딱」 소리에 맞춰 큰 버튼을 톡 — 12번 울려요. 화면이 아니라 소리를 들으며 맞춰 주세요.' : '소리가 꺼져 있어요. 위의 ♪ 버튼으로 소리를 켠 뒤 다시 열어 주세요.' });
      function start() {
        timers.forEach(clearTimeout); timers = []; clicks = []; taps = []; done = false; res.textContent = '준비…';
        if (!ac) return;
        const t0 = ac.currentTime + 0.8; startPerf = performance.now() + 800;
        for (let k = 0; k < N; k++) {
          click(ac, Aud.master, t0 + k * gap, k % 4 === 0); clicks.push(startPerf + k * gap * 1000);
          timers.push(setTimeout(() => { padEl.classList.add('flash'); setTimeout(() => padEl.classList.remove('flash'), 90); }, 800 + k * gap * 1000));
        }
        timers.push(setTimeout(finish, 800 + N * gap * 1000 + 400));
      }
      function finish() {
        done = true;
        const offs = [];
        for (const tp of taps) { let best = null; for (let k = 2; k < clicks.length; k++) { const d = tp - clicks[k]; if (Math.abs(d) < 300 && (best == null || Math.abs(d) < Math.abs(best))) best = d; } if (best != null) offs.push(best); }
        if (offs.length < 5) { res.textContent = '탭이 너무 적어요. 다시 해 볼까요?'; return; }
        offs.sort((a, b) => a - b);
        const v = Math.round(clamp(offs[offs.length >> 1], -150, 400));
        U.store.set('band.lat', v); latS = myLat();
        res.textContent = '보정값 ' + (v >= 0 ? '+' : '') + v + 'ms 저장했어요';
        api.sfx('pop');
      }
      padEl.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); if (!done && clicks.length) { taps.push(e.timeStamp && Math.abs(e.timeStamp - performance.now()) < 1000 ? e.timeStamp : performance.now()); res.textContent = taps.length + ' / ' + N; } });
      cal = L.h('div', { class: 'bd-cal' },
        L.h('h3', { text: '⏱ 박자 맞추기' }), info, padEl, res,
        L.h('div', { class: 'row2' },
          L.h('button', { class: 'btn ghost', onclick() { start(); } }, '다시 하기'),
          L.h('button', { class: 'btn ghost', onclick() { U.store.set('band.lat', 0); latS = myLat(); res.textContent = '보정값 0ms로 바꿨어요'; } }, '0으로'),
          L.h('button', { class: 'btn primary', onclick() { closeCal(); } }, '닫기')));
      cal.addEventListener('pointerdown', (e) => e.stopPropagation());
      cal._stop = () => timers.forEach(clearTimeout);
      root.appendChild(cal);
      start();
    }
    function closeCal() { if (!cal) return; cal._stop(); cal.remove(); cal = null; pickSig = ''; syncPick(); }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !R) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem) return;
      for (const k in rem) { const s = +k, o = rem[k]; if (s >= 0 && s < R.seats.length && !drive(s) && o && o.k === key) applyRemote(R, s, o.s); }
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !R) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || hs.k !== key || hs.q === lastQ) return;
      lastQ = hs.q;
      const base = (+hs.t || 0) - now / 1000 * SPD();
      if (clockBase == null || base > clockBase || base < clockBase - 0.5) clockBase = base;
      R.meter = +hs.m || 0;
      if (Array.isArray(hs.s)) hs.s.forEach((a, i) => { if (i !== mine && R.seats[i] && Array.isArray(a)) { const se = R.seats[i]; se.P = a[0] | 0; se.G = a[1] | 0; se.M = a[2] | 0; se.c = a[3] | 0; se.mc = a[4] | 0; se.pts = +a[5] || 0; se.gr = a[6] ? 1 : 0; } });
    }
    function guestClock(now) {
      if (clockBase == null) return;
      const est = clockBase + now / 1000 * SPD(), d = est - R.T;
      if (Math.abs(d) > 0.4) R.T = est; else R.T += d * 0.08;
    }
    const pack = (se) => [se.P, se.G, se.M, se.c, se.mc, Math.round(se.pts), se.gr];
    function publish(rdt) {
      if (!api.online || !R) return;
      pubT -= rdt;
      if (pubT > 0) return;
      try {
        if (api.isHost) { pubT = 0.1; hsQ = (hsQ + 1) % 100000; api.net.hostSend({ k: key, q: hsQ, t: Math.round(R.T * 1000) / 1000, m: Math.round(R.meter * 10) / 10, s: R.seats.map(pack) }); }
        else if (mine >= 0 && R.seats[mine]) { pubT = 0.25; api.net.publish({ k: key, s: pack(R.seats[mine]) }); }
      } catch (e) {}
    }

    /* ----- audio scheduling on this phone's song clock ----- */
    function seekAudio() { const so = R.so; for (let p = 0; p < 4; p++) { const A = so.A[p]; let k = 0; while (k < A.length && A[k].t < R.T) k++; aPtr[p] = k; } aPtr[4] = 0; while (aPtr[4] < so.clk.length && so.clk[aPtr[4]] < R.T) aPtr[4]++; }
    function audio() {
      if (!R || !st || st.ph !== 'play') return;
      const ac = Aud.ctx(); if (!ac || !Aud.tr) return;
      const sp = SPD(), want = ac.currentTime + 0.03 - R.T / sp;
      if (anchor == null || Math.abs(want - anchor) > 0.04) anchor = want; else anchor += (want - anchor) * 0.05;
      if (R.T < lastSchedT - 0.2) seekAudio();
      lastSchedT = R.T;
      // part volumes: a part that missed drops out until it hits again; empty parts are a soft backing
      for (let p = 0; p < 4; p++) {
        const s = partSeat[p], v = s < 0 ? 0.35 : R.seats[s] && R.seats[s].gr ? 1 : 0;
        if (v !== trVol[p]) { trVol[p] = v; try { Aud.tr[p].gain.setTargetAtTime(v * (p === 2 ? 0.9 : 1), ac.currentTime, 0.015); } catch (e) {} }
      }
      const so = R.so, ahead = R.T + 0.14 * sp;
      for (let p = 0; p < 4; p++) {
        const A = so.A[p];
        while (aPtr[p] < A.length && A[aPtr[p]].t < ahead) { const ev = A[aPtr[p]++]; if (ev.t >= R.T - 0.03 * sp) { try { playEv(ac, Aud.tr[p], anchor + ev.t / sp, ev, p, so.sy, sp); } catch (e) {} } }
      }
      while (aPtr[4] < so.clk.length && so.clk[aPtr[4]] < ahead) { const t = so.clk[aPtr[4]++]; if (t >= R.T - 0.03 * sp) click(ac, Aud.master, anchor + t / sp, aPtr[4] === 1); }
    }
    function silence() { const ac = Aud.ac; if (!ac || !Aud.tr) return; for (let p = 0; p < 4; p++) { try { Aud.tr[p].gain.setTargetAtTime(0, ac.currentTime + 0.6, 0.2); } catch (e) {} trVol[p] = -1; } }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      frameNow = now;
      const dt = Math.min(rdt, 0.25) * SPD();
      if (!R || st.ph !== 'play') return;
      R.T += dt;
      if (!host()) { pollGuest(now); guestClock(now); }
      if (mine >= 0 && R.seats[mine] && R.seats[mine].p >= 0 && drive(mine)) {
        if (autoMine()) aiSeat(R, mine, 3, hooks); else sweep(R, mine, R.T - latS, hooks);
      }
      if (host()) {
        pollHost();
        for (let i = 0; i < R.seats.length; i++) if (i !== mine && drive(i) && api.players[i] && api.players[i].ai) aiSeat(R, i, lvOf(i), hooks);
        if (!endAt) {
          if (R.fail && R.meter <= 0 && R.T > 0) { R.out = true; endAt = now + Math.max(400, 1200 / SPD()); }
          else if (R.T >= R.len + 0.2) endAt = now + Math.max(600, 1200 / SPD());
        } else if (now >= endAt) { endAt = 1e15; pollHost(); api.setState(finalize(st, R)); }
      }
      publish(rdt);
      audio();
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, al) { ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,8,16,.85)'; ctx.strokeText(t, x, y); ctx.fillStyle = col; ctx.fillText(t, x, y); }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else ctx.rect(x, y, w, h); }
    function fit(t, maxW) { let s = String(t); while (s.length > 1 && ctx.measureText(s).width > maxW) s = s.slice(0, -2) + '…'; return s; }
    function background() {
      const W = cv.w, H = cv.h, sig = W + 'x' + H + ':' + cv.dpr;
      if (bgC && bgSig === sig) { ctx.drawImage(bgC, 0, 0, W, H); return; }
      bgSig = sig; bgC = document.createElement('canvas'); bgC.width = Math.round(W * cv.dpr); bgC.height = Math.round(H * cv.dpr);
      const c = bgC.getContext('2d'); c.scale(cv.dpr, cv.dpr);
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#1d1528'); g.addColorStop(0.6, '#17121f'); g.addColorStop(1, '#100c16'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      [[0.18, '#e3ae45'], [0.5, '#c06cff'], [0.82, '#ee6a55']].forEach(([fx2, col]) => { const rg = c.createRadialGradient(W * fx2, HB, 4, W * fx2, HB + H * 0.3, H * 0.55); rg.addColorStop(0, col + '30'); rg.addColorStop(1, col + '00'); c.fillStyle = rg; c.fillRect(0, 0, W, H); });
      c.fillStyle = 'rgba(255,255,255,.025)'; for (let k = 0; k < 60; k++) c.fillRect((k * 89) % W, (k * 137) % H, 2, 2);
      ctx.drawImage(bgC, 0, 0, W, H);
    }
    function icon(p, x, y, s, col) {
      ctx.save(); ctx.translate(x, y); ctx.scale(s / 20, s / 20); ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 2; ctx.lineCap = 'round';
      if (p === 0) { ctx.beginPath(); ctx.ellipse(0, 3, 8, 3, 0, 0, 7); ctx.stroke(); ctx.beginPath(); ctx.moveTo(-8, 3); ctx.lineTo(-8, 8); ctx.moveTo(8, 3); ctx.lineTo(8, 8); ctx.moveTo(-6, -8); ctx.lineTo(-1, 0); ctx.moveTo(6, -8); ctx.lineTo(1, 0); ctx.stroke(); }
      else if (p === 1 || p === 2) { ctx.beginPath(); ctx.arc(-3, 4, p === 1 ? 5 : 6, 0, 7); ctx.fill(); ctx.beginPath(); ctx.moveTo(-1, 2); ctx.lineTo(8, -8); ctx.lineWidth = p === 1 ? 2.6 : 2; ctx.stroke(); }
      else { ctx.strokeRect(-9, -5, 18, 11); ctx.beginPath(); for (const xx of [-4.5, 0, 4.5]) { ctx.moveTo(xx, -5); ctx.lineTo(xx, 6); } ctx.stroke(); ctx.fillRect(-6.5, -5, 2.5, 6); ctx.fillRect(2, -5, 2.5, 6); }
      ctx.restore();
    }
    const accTxt = (se) => (se.P + se.G + se.M ? Math.floor(accOf(se.P, se.G, se.M)) + '%' : '—');
    function drawStrip() {
      const W = cv.w, cw = (W - 8 - 12) / 4, kit = R ? R.so.sy.kit : 'rock';
      void kit;
      for (let p = 0; p < 4; p++) {
        const x = 4 + p * (cw + 4), y = 4, h = 44, s = partSeat[p], se = s >= 0 && R ? R.seats[s] : null, I = INST[p];
        const playing = st.ph === 'play' && R && R.T > 0, muted = se && playing && !se.gr;
        rr(x, y, cw, h, 10); ctx.fillStyle = s === mine && s >= 0 ? '#2e2640' : '#221c2e'; ctx.fill();
        ctx.lineWidth = s === mine && s >= 0 ? 2.5 : 1.5; ctx.strokeStyle = s === mine && s >= 0 ? '#e3ae45' : muted ? 'rgba(238,106,85,.7)' : se ? I.col + '99' : 'rgba(255,255,255,.12)'; ctx.stroke();
        icon(p, x + 13, y + 14, 15, muted ? '#6f6480' : I.col);
        ctx.font = '700 12px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = muted ? '#8d8199' : '#f2e9d8';
        ctx.fillText(fit(I.nm, cw - 30), x + 25, y + 14);
        if (muted) txt('✕', x + cw - 9, y + 13, '#ee6a55', '700 11px ' + FONT);
        else if (se && se.c >= 10) txt(String(se.c), x + cw - 6, y + 13, '#ffe27a', '700 10px ' + MONO, 'right');
        ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'left';
        const at = se ? accTxt(se) : '';
        ctx.font = '600 10.5px ' + MONO; const aw = at ? ctx.measureText(at).width + 4 : 0;
        ctx.font = '600 10.5px ' + FONT; ctx.fillText(fit(s < 0 ? (st.ph === 'pick' ? '빈 자리' : '반주') : st.nm[s], cw - 10 - aw), x + 6, y + 33);
        if (at) { ctx.font = '600 10.5px ' + MONO; ctx.textAlign = 'right'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(at, x + cw - 5, y + 33); }
      }
      // band meter + score
      const my = 56, m = R ? R.meter : 60;
      ctx.font = '600 11px ' + FONT; ctx.textAlign = 'left'; ctx.fillStyle = '#ab9fb8'; ctx.textBaseline = 'middle'; ctx.fillText('분위기', 6, my);
      let pts = 0; if (R) R.seats.forEach((se) => { pts += se.pts; });
      const sTxt = Math.round(pts).toLocaleString('ko-KR');
      ctx.font = '700 12px ' + MONO; const sw = ctx.measureText(sTxt).width;
      const bx = 46, bw = W - bx - sw - 16;
      rr(bx, my - 5, bw, 10, 5); ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.fill();
      if (st.fail) { ctx.strokeStyle = 'rgba(238,106,85,.55)'; ctx.lineWidth = 1; ctx.stroke(); }
      rr(bx, my - 5, Math.max(4, bw * m / 100), 10, 5); ctx.fillStyle = m < 25 ? '#ee6a55' : m < 60 ? '#e3ae45' : '#8fe3a8'; ctx.fill();
      ctx.textAlign = 'right'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(sTxt, W - 6, my);
      if (R && st.ph !== 'pick') { const pr = clamp(R.T / R.len, 0, 1); ctx.fillStyle = 'rgba(255,255,255,.08)'; ctx.fillRect(6, HB - 4, W - 12, 2); ctx.fillStyle = '#e3ae45'; ctx.fillRect(6, HB - 4, (W - 12) * pr, 2); }
    }
    /* one highway (own: big; spectator: four small ones) */
    function drawHighway(i, box, big) {
      const se = R.seats[i], p = se.p, I = INST[p], n = I.lanes, lw = box.w / n, ch = R.ch[p];
      const Tv = i === mine && !autoMine() ? R.T - latS : R.T;
      const ph2 = big ? padH(box) : 26, Hy = box.y + box.h - ph2, top = box.y + 4, look = LOOK[st.lvl] || 1.45, pxs = (Hy - top) / look;
      const yOf = (t) => Hy - (t - Tv) * pxs;
      ctx.save(); rr(box.x, box.y, box.w, box.h, 12); ctx.clip();
      ctx.fillStyle = 'rgba(12,9,18,.55)'; ctx.fillRect(box.x, box.y, box.w, box.h);
      for (let l = 0; l < n; l++) {
        const x = box.x + l * lw;
        if (l % 2) { ctx.fillStyle = 'rgba(255,255,255,.025)'; ctx.fillRect(x, box.y, lw, box.h); }
        if (flash[l] > 0 && big) { const g = ctx.createLinearGradient(0, Hy, 0, top); g.addColorStop(0, LANE_COL[p][l] + '55'); g.addColorStop(1, LANE_COL[p][l] + '00'); ctx.globalAlpha = flash[l]; ctx.fillStyle = g; ctx.fillRect(x, top, lw, Hy - top); ctx.globalAlpha = 1; }
        if (l) { ctx.fillStyle = 'rgba(255,255,255,.07)'; ctx.fillRect(x - 0.5, box.y, 1, box.h); }
      }
      // beat lines
      const bd = R.so.bd, beatsPerBar = R.so.sy.beats;
      for (let k = Math.ceil((Tv - 0.2) / bd); k * bd < Tv + look; k++) {
        if (k < 0) continue; const y = yOf(k * bd); if (y < top || y > Hy) continue;
        ctx.fillStyle = k % beatsPerBar === 0 ? 'rgba(242,233,216,.16)' : 'rgba(242,233,216,.06)'; ctx.fillRect(box.x, y, box.w, k % beatsPerBar === 0 ? 2 : 1);
      }
      // notes (binary search to the first visible one)
      let lo = 0, hi = ch.length; const t0 = Tv - 0.35 - 4;
      while (lo < hi) { const m = (lo + hi) >> 1; if (ch[m].t < t0) lo = m + 1; else hi = m; }
      const nh = clamp(lw * 0.26, 10, 22) * (big ? 1 : 0.8);
      for (let k = lo; k < ch.length && ch[k].t < Tv + look + 0.05; k++) {
        const nt = ch[k], jd = se.jd ? se.jd[k] : 0;
        const tailEnd = nt.t + nt.len;
        if (tailEnd < Tv - 0.35) continue;
        const holding = nt.len > 0 && se.holds[nt.ln] && se.holds[nt.ln].k === k;
        const aiHolding = nt.len > 0 && (jd === 1 || jd === 2) && i !== mine && Tv < tailEnd;
        if ((jd === 1 || jd === 2) && !holding && !aiHolding && !(nt.len > 0 && i === mine && autoMine() && Tv < tailEnd)) continue;
        let y = yOf(nt.t); if (jd === 1 || jd === 2) y = Math.min(y, Hy);
        const miss = jd === 3;
        ctx.globalAlpha = miss ? 0.3 : 1;
        if (nt.ln < 0) { // strum: full width bar
          rr(box.x + 4, y - nh * 0.4, box.w - 8, nh * 0.8, nh * 0.4); ctx.fillStyle = miss ? '#6f6480' : STRUM; ctx.fill();
          ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.fillRect(box.x + 12, y - nh * 0.25, box.w - 24, 2);
        } else {
          const x = box.x + nt.ln * lw, col = miss ? '#6f6480' : LANE_COL[p][nt.ln];
          if (nt.len > 0) { const ty = Math.max(top, yOf(tailEnd)); ctx.fillStyle = col; ctx.globalAlpha = (miss ? 0.2 : holding ? 0.85 : 0.5); rr(x + lw * 0.39, ty, lw * 0.22, Math.max(0, y - ty), lw * 0.11); ctx.fill(); ctx.globalAlpha = miss ? 0.3 : 1; }
          const wF = p === 0 && nt.ln === 0 ? 0.86 : 0.72, hF = p === 0 && nt.ln === 0 ? 0.7 : 1;
          rr(x + lw * (1 - wF) / 2, y - nh * hF / 2, lw * wF, nh * hF, Math.min(8, nh * 0.45)); ctx.fillStyle = col; ctx.fill();
          ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.fillRect(x + lw * (1 - wF) / 2 + 6, y - nh * hF / 2 + 3, lw * wF - 12, 2);
          if (p === 3 && k + 1 < ch.length && Math.abs(ch[k + 1].t - nt.t) < 1e-4 && !se.jd[k + 1] && !jd) { ctx.strokeStyle = 'rgba(242,233,216,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + lw * 0.86, y); ctx.lineTo(box.x + ch[k + 1].ln * lw + lw * 0.14, y); ctx.stroke(); }
        }
        ctx.globalAlpha = 1;
      }
      // hit line + pads
      ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.fillRect(box.x, Hy - 1.5, box.w, 3);
      if (big) {
        const names = padNames(p, R.so.sy.kit);
        for (let l = 0; l < n; l++) {
          const x = box.x + l * lw, col = LANE_COL[p][l];
          rr(x + 5, Hy + 6, lw - 10, box.y + box.h - Hy - 12, 12); ctx.fillStyle = flash[l] > 0 ? col + '55' : 'rgba(46,38,64,.85)'; ctx.fill();
          ctx.strokeStyle = col + 'aa'; ctx.lineWidth = 2; ctx.stroke();
          ctx.strokeStyle = col; ctx.lineWidth = 3; rr(x + lw * 0.14, Hy - nh / 2 - 2, lw * 0.72, nh + 4, 9); ctx.stroke();
          txt(names[l], x + lw / 2, (Hy + 6 + box.y + box.h - 6) / 2, '#f2e9d8', '700 ' + (lw < 80 ? 13 : 15) + 'px ' + FONT);
        }
        for (const f of fx) { const x = box.x + f.ln * lw + lw / 2, a = f.t / 0.35; ctx.globalAlpha = a; ctx.strokeStyle = f.g === 1 ? '#ffe27a' : '#8fe3a8'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, Hy, lw * 0.2 + (1 - a) * lw * 0.3, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
      } else {
        txt(st.nm[i], box.x + box.w / 2, box.y + box.h - 13, '#ab9fb8', '600 11px ' + FONT);
      }
      ctx.restore();
      return { Hy, top };
    }
    function drawOwn() {
      const hw = hwRect(), W = cv.w;
      const g = drawHighway(mine, hw, true);
      const se = R.seats[mine], cx = hw.x + hw.w / 2;
      // song + section + band bonus
      const bar = Math.floor(Math.max(0, R.T) / R.so.barLen), sec = R.T < 0 ? '' : SEC[R.so.secAt[Math.min(bar, R.so.secAt.length - 1)]] || '';
      ctx.font = '600 11.5px ' + FONT; ctx.textAlign = 'left'; ctx.fillStyle = '#ab9fb8'; ctx.textBaseline = 'middle';
      ctx.fillText(fit('♪ ' + R.so.sg.nm + (sec ? ' · ' + sec : ''), hw.w * 0.6), hw.x + 8, hw.y + 14);
      const bm = bandMult(R, mine); if (bm > 1 && R.T > 0) txt('합주 ×' + bm.toFixed(2), hw.x + hw.w - 8, hw.y + 14, '#e3ae45', '700 12px ' + MONO, 'right');
      if (se.c >= 5) { ctx.globalAlpha = 0.28; txt(String(se.c), cx, hw.y + hw.h * 0.36, '#f2e9d8', '52px ' + DISP); ctx.globalAlpha = 1; txt('콤보', cx, hw.y + hw.h * 0.36 + 34, 'rgba(242,233,216,.45)', '600 12px ' + FONT); }
      if (jt && jt.t > 0) { ctx.globalAlpha = Math.min(1, jt.t * 4); txt(jt.txt, cx, g.Hy - 46, jt.col, '700 20px ' + FONT); ctx.globalAlpha = 1; }
      if (R.T < 0) countIn(hw, cx, TIPS[se.p], W);
    }
    function countIn(hw, cx, tip) {
      const k = Math.ceil(-R.T / R.so.bd);
      txt(k <= 4 ? String(k) : '준비', cx, hw.y + hw.h * 0.24, '#f2e9d8', (k <= 4 ? 52 : 34) + 'px ' + DISP);
      if (tip) {
        const bw = Math.min(hw.w - 24, 320), by = hw.y + hw.h * 0.24 + 40;
        rr(cx - bw / 2, by, bw, 52, 12); ctx.fillStyle = 'rgba(23,19,31,.92)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.font = '700 13px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.fillText(fit(tip[0], bw - 16), cx, by + 17);
        ctx.font = '600 12px ' + FONT; ctx.fillStyle = '#e3ae45'; ctx.fillText(fit(tip[1], bw - 16), cx, by + 36);
      }
    }
    function drawSpectate() {
      const hw = hwRect(), gap = 6, w = (hw.w - gap * 3) / 4;
      for (let p = 0; p < 4; p++) {
        const s = partSeat[p], box = { x: hw.x + p * (w + gap), y: hw.y + 22, w, h: hw.h - 22 };
        if (s >= 0) drawHighway(s, box, false);
        else { rr(box.x, box.y, box.w, box.h, 12); ctx.fillStyle = 'rgba(12,9,18,.4)'; ctx.fill(); txt('반주', box.x + w / 2, box.y + box.h / 2, '#6f6480', '600 12px ' + FONT); }
      }
      txt('♪ ' + R.so.sg.nm + ' · ' + R.so.sg.g, hw.x + hw.w / 2, hw.y + 10, '#ab9fb8', '600 12px ' + FONT);
      if (R.T < 0) countIn(hw, hw.x + hw.w / 2, null);
    }
    function draw() {
      background();
      if (!st) return;
      drawStrip();
      if (st.ph === 'pick') { txt('♪ ' + SONGS[st.song].nm, cv.w / 2, HB + 60, '#e3ae45', '26px ' + DISP); txt(SONGS[st.song].g + ' · ' + '★'.repeat(SONGS[st.song].star), cv.w / 2, HB + 92, '#ab9fb8', '600 13px ' + FONT); return; }
      if (!R) return;
      if (mine >= 0 && R.seats[mine] && R.seats[mine].p >= 0) drawOwn(); else drawSpectate();
      if (st.ph === 'done') { const hw = hwRect(); txt(st.ok ? '공연 끝!' : '공연 중단…', hw.x + hw.w / 2, hw.y + hw.h * 0.3, st.ok ? '#ffe27a' : '#ee6a55', '40px ' + DISP); }
    }

    const stopLoop = U.loop((rdt, now) => {
      if (!st) return;
      try { frame(rdt, now); } catch (e) { console.error(e); }
      for (let l = 0; l < 4; l++) if (flash[l] > 0) flash[l] = Math.max(0, flash[l] - rdt * 4);
      for (let k = fx.length - 1; k >= 0; k--) { fx[k].t -= rdt; if (fx[k].t <= 0) fx.splice(k, 1); }
      if (jt) jt.t -= rdt;
      try { draw(); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        st = next;
        const ms = api.mySeats(); mine = ms.length ? ms[0] : -1;
        partSeat = [-1, -1, -1, -1]; st.ins.forEach((p, i) => { if (p >= 0) partSeat[p] = i; });
        syncPick();
        if (st.ph === 'pick') { R = null; key = null; return; }
        if (cal) closeCal();
        if (st.rid !== key) {
          key = st.rid; R = newRun(st, host()); endAt = 0; anchor = null; lastSchedT = -1e9; clockBase = null; lastQ = -1; doneShown = false; trVol = [-1, -1, -1, -1];
          latS = myLat(); seekAudio(); jt = null; fx.length = 0;
          for (const k in pidLane) delete pidLane[k];
        }
        if (st.ph === 'done' && !doneShown) {
          doneShown = true; silence();
          if (R && st.fin) st.fin.forEach((f, i) => { if (f && R.seats[i] && i !== mine) { const se = R.seats[i]; se.P = f[0]; se.G = f[1]; se.M = f[2]; se.mc = f[3]; se.pts = f[4]; } });
          if (R) R.meter = st.m;
        }
      },
      destroy() {
        stopLoop(); offIn();
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp); cv.cv.removeEventListener('contextmenu', noCtx);
        if (pick) pick.remove(); if (cal) { cal._stop(); cal.remove(); }
        styleEl.remove(); cv.destroy(); Aud.close();
      },
      _dbg: () => ({ R, st, mine, partSeat, latS }),
    };
  }

  L.register({
    id: 'band', name: '밴드 합주', tag: '협동 리듬 밴드', cat: '파티', coop: true,
    blurb: '드럼·베이스·기타·건반 중 하나를 맡아 같은 곡을 함께 연주해요. 박자를 맞추면 곡이 풍성해지고, 틀리면 그 악기 소리가 빠져요. 곡 10개는 모두 직접 만든 곡. 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#5a2468',
    icon: '<ellipse cx="20" cy="38" rx="13" ry="5" fill="none" stroke="currentColor" stroke-width="3"/><path d="M7 38v7c0 3 6 5 13 5s13-2 13-5v-7" fill="none" stroke="currentColor" stroke-width="3"/><path d="M10 18l9 16M31 16l-8 18" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M45 8v22" stroke="currentColor" stroke-width="3"/><circle cx="41" cy="30" r="4.5" fill="currentColor"/><path d="M45 8l7 3v5l-7-3z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 400,
    controls: [
      { id: 'l1', label: '1번 칸', keys: ['KeyD', 'ArrowLeft'], pad: ['x', 'left'] },
      { id: 'l2', label: '2번 칸', keys: ['KeyF', 'ArrowDown'], pad: ['a', 'down'] },
      { id: 'l3', label: '3번 칸', keys: ['KeyJ', 'ArrowUp'], pad: ['b', 'up'] },
      { id: 'l4', label: '4번 칸 (건반)', keys: ['KeyK', 'ArrowRight'], pad: ['y', 'right'] },
      { id: 'strum', label: '쓸어 치기 (기타 긴 줄)', keys: ['Space'], pad: ['rb', 'lb'] },
    ],
    options: [
      { id: 'song', label: '곡', choices: [{ v: 'rand', label: '무작위' }].concat(SONGS.map((s, i) => ({ v: String(i), label: s.nm + ' (' + s.g + ' ' + '★'.repeat(s.star) + ')' }))), def: 'rand' },
      { id: 'lvl', label: '악보 난이도', choices: [{ v: 1, label: '쉬움' }, { v: 2, label: '보통' }, { v: 3, label: '어려움' }], def: 2 },
      { id: 'fail', label: '분위기 0이면 공연 중단', choices: [{ v: 0, label: '끔' }, { v: 1, label: '켬' }], def: 0 },
    ],
    quick: [
      '드럼·베이스·기타·건반 중 하나를 맡아 모두 같은 곡을 함께 연주해요.',
      '떨어지는 음표가 아래 선에 닿을 때 그 칸을 톡! 틀리면 내 악기 소리가 빠져요.',
      '곡이 끝나면 밴드 등급(S~D)과 각자의 정확도·최고 콤보가 나와요.',
    ],
    rules: [
      { h: '목표', p: [
        '한 곡을 밴드가 함께 끝까지 연주하는 협동 게임이에요. 모두가 박자를 맞출수록 곡이 풍성해지고 밴드 등급이 올라가요.',
        '1~4명: 사람마다 악기 하나. 남은 악기는 AI 연주자가 맡고, 자리가 4개보다 적으면 빈 악기는 작은 반주로 깔려요.',
      ] },
      { h: '시작 전', p: [
        '악기 고르기: 드럼 · 베이스 · 기타 · 건반 중 하나를 눌러요(먼저 고른 사람 몫).',
        '「⏱ 박자 맞추기」: 소리에 맞춰 버튼을 12번 톡 → 이 폰의 소리·터치 지연을 재서 저장해요. 박자가 자꾸 어긋나면 한 번 해 보세요.',
        '시작하면 「딱 딱 딱 딱」 4번 박자를 세 주고 곡이 시작돼요.',
      ] },
      { h: '연주 방법', p: [
        '음표가 위에서 떨어져요. 아래 흰 선(패드)에 닿는 순간 그 칸을 톡! 칸 안이라면 위아래 어디를 눌러도 돼요.',
        '드럼: 패드 3개(킥 · 스네어 · 심벌). 두 개가 같이 오면 두 손가락으로 함께.',
        '베이스: 2줄. 꼬리가 달린 긴 음표는 꼬리가 끝날 때까지 꾹 누르고 있어요.',
        '기타: 3줄. 가로로 긴 분홍 줄(쓸어 치기)은 아무 칸이나 톡 하면 돼요.',
        '건반: 4줄. 선으로 이어진 두 음표(화음)는 두 손가락으로 같이.',
        'PC: D·F·J·K(또는 방향키)가 1~4번 칸, 스페이스가 쓸어 치기. 게임패드도 돼요(「⌨ 조작 설정」에서 바꾸기).',
      ] },
      { h: '판정 · 점수', p: [
        '퍼펙트(±0.075초) · 좋아요(±0.15초) · 놓침. 폰에 맞춰 넉넉하게 잡았어요. 빈 곳을 눌러도 벌점은 없어요.',
        '놓치면 내 악기 소리가 빠지고 콤보가 끊겨요. 다음 음표를 맞히면 소리가 바로 돌아와요.',
        '점수 = 퍼펙트 100 · 좋아요 60 × 콤보 보너스(10콤보마다 +0.5배, 최대 2.5배) × 합주 보너스(다른 악기가 하나 잘 연주 중일 때마다 +0.15배).',
        '분위기 막대: 맞히면 오르고 놓치면 내려가요. 「분위기 0이면 공연 중단」 옵션을 켜면 0이 되는 순간 공연이 끝나요(기본은 끔).',
      ] },
      { h: '결과', p: [
        '밴드 정확도(퍼펙트 1, 좋아요 0.7로 쳐서) 95% 이상 S · 88% A · 78% B · 65% C · 그 아래 D.',
        '사람마다 정확도와 최고 콤보도 보여 줘요. 곡을 끝까지 마치면 모두 함께 성공!',
      ] },
      { h: '예시', p: [
        '나는 베이스, AI가 드럼·기타·건반. 후렴에서 긴 음표를 끝까지 눌러 퍼펙트 → 콤보 20, 점수 2배.',
        '→ 다음 마디에서 한 음 놓침 → 베이스 소리가 뚝 끊기고 콤보 0 → 바로 다음 음표를 맞히자 베이스가 다시 들려요.',
      ] },
      { h: '곡 · 난이도', p: [
        '곡 10개(록 · 펑크 · 재즈 스윙 · 동요풍 · 전통 장단 · 일렉트로 · 보사노바 · 레게 · 메탈 · 왈츠)는 모두 이 게임에서 직접 만든 곡이에요. 기본은 무작위.',
        '★은 곡 자체의 빠르기·복잡함, 「악보 난이도」(쉬움·보통·어려움)는 음표가 얼마나 많이 나오는지예요. 쉬움은 박자마다 한 번쯤, 어려움은 화음·빠른 연타까지.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 친구와는 온라인·LAN 방에서 각자 자기 폰으로. 소리는 각 폰에서 직접 울리고 판정도 각 폰에서 해서, 인터넷이 조금 느려도 공정해요.',
        'AI 연주자 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 가끔 놓치고 박자가 흔들리고, 어려움은 거의 퍼펙트예요.',
      ] },
      { h: '팁', p: [
        '화면보다 소리를 들으며 치면 더 잘 맞아요. 이어폰을 쓰면 더 좋아요.',
        '놓쳤다고 마구 누르지 마세요. 다음 음표 하나만 맞히면 소리가 돌아와요.',
        '처음엔 「악보 난이도: 쉬움」과 ★ 하나짜리 곡(꼬마 행진곡 · 별빛 왈츠)부터!',
      ] },
    ],
    init, actor, apply, ai, result, mount,
    _t: { SONGS, STY, INST, song, chart, newRun, judge, press, release, sweep, aiSeat, applyRemote, finalize, simulate, bandSummary, accOf, init, actor, apply, ai, result, PW, GW },
  });
})();
