/* 클레이 사격 — 트랩·스키트를 섞은 사격장. 사대 5곳을 돌며 사람마다 표적 10/15/25개를 쏜다.
   표적(싱글·더블)은 상태 안의 시드로 발사 방향·속도가 정해지고 옆바람에 조금 밀린다.
   쏘는 기기는 실시간으로 「풀!」→ 탭 사격(최대 2발)을 하고 {taps:[[ms, u, v], ...]}만 보낸다.
   apply는 시드로 표적 궤적을 다시 계산하고, 산탄이 날아가는 시간(리드)을 반영해 명중을 판정한다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* ---------- world (m): x right, y up, z downrange; shooter eye at (station x, EYE, 0) ---------- */
  const DTC = 1 / 60, VP = 160, RANGE = 48, RC = 0.055, RE = 0.075, EYE = 1.6, TMAX = 4.2;
  const KDRAG = 0.010, GEFF = 7.2, WK = 0.25, MINGAP = 120;
  const STX = [-8, -4, 0, 4, 8];
  const PLANS = { 10: ['SS', 'SS', 'SS', 'D', 'D'], 25: ['SSSSS', 'SSSSS', 'SSSD', 'SDD', 'SDD'] };
  const clays = (ty) => (ty === 'D' ? 2 : 1);

  function mb(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function cam(st) { const sx = STX[st], l = Math.sqrt(sx * sx + 625); return { sx, fx: -sx / l, fz: 25 / l }; }
  function proj(c, X, Y, Z) { const dX = X - c.sx, cx = dX * c.fz - Z * c.fx, cz = dX * c.fx + Z * c.fz; return { u: cx / cz, v: (Y - EYE) / cz, z: cz }; }

  /* launch parameters of one presentation (1 or 2 clays) */
  function launch(sd, st, ty) {
    const R = mb(sd);
    const mk = (kind, side) => {
      let p, d, sp;
      if (kind === 'T') { p = [0, 0.5, 14]; const a = side ? side * (0.14 + 0.34 * R()) : R() * 1.0 - 0.5; d = [a, 0.15 + 0.13 * R(), 1]; sp = 25 + 4 * R(); }
      else if (kind === 'H') { p = [-15, 4.6, 24]; d = [1, 0.05 + 0.14 * R(), -0.25 + 0.4 * R()]; sp = 20 + 4 * R(); }
      else { p = [15, 1.0, 22]; d = [-1, 0.22 + 0.15 * R(), -0.2 + 0.4 * R()]; sp = 20 + 4 * R(); }
      const l = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
      return { k: kind, p, v: [d[0] / l * sp, d[1] / l * sp, d[2] / l * sp] };
    };
    if (ty === 'D') return R() < 0.5 ? [mk('H'), mk('L')] : [mk('T', -1), mk('T', 1)];
    const u = R();
    return [mk(u < 0.4 ? 'T' : u < 0.7 ? 'H' : 'L')];
  }
  /* clay flight sampled at 60 Hz, in the station camera's tangent plane (u right, v up) */
  function track(c, w10, st) {
    const C = cam(st), wx = WK * w10 / 10;
    let x = c.p[0], y = c.p[1], z = c.p[2], vx = c.v[0], vy = c.v[1], vz = c.v[2];
    const Uu = [], Vv = [], D = [], Z = [];
    for (let k = 0; k * DTC <= TMAX; k++) {
      const pr = proj(C, x, y, z), dX = x - C.sx, dY = y - EYE;
      Uu.push(pr.u); Vv.push(pr.v); Z.push(pr.z); D.push(Math.sqrt(dX * dX + dY * dY + z * z));
      if (y < 0 || pr.z < 1) break;
      const s = Math.sqrt(vx * vx + vy * vy + vz * vz);
      vx += (-KDRAG * s * vx + wx) * DTC; vy += (-KDRAG * s * vy - GEFF) * DTC; vz += (-KDRAG * s * vz) * DTC;
      x += vx * DTC; y += vy * DTC; z += vz * DTC;
    }
    let live = Uu.length - 1; // last sample still inside shotgun range
    while (live > 0 && D[live] > RANGE) live--;
    return { k: c.k, U: Uu, V: Vv, D, Z, n: Uu.length, live };
  }
  function tracks(sd, w, st, ty) { return launch(sd, st, ty).map((c) => track(c, w, st)); }
  function at(T, t) { // interpolated sample
    const i = clamp(t / DTC, 0, T.n - 1), k = Math.min(T.n - 2, Math.floor(i)), f = i - k;
    if (T.n < 2) return { u: T.U[0], v: T.V[0], d: T.D[0], z: T.Z[0] };
    return { u: T.U[k] + (T.U[k + 1] - T.U[k]) * f, v: T.V[k] + (T.V[k + 1] - T.V[k]) * f, d: T.D[k] + (T.D[k + 1] - T.D[k]) * f, z: T.Z[k] + (T.Z[k + 1] - T.Z[k]) * f };
  }
  /* when do pellets fired at t0 reach the clay's range? (pellet cloud travels at VP m/s) */
  function arrive(T, t0) {
    for (let k = Math.max(1, Math.ceil(t0 / DTC - 1e-9)); k < T.n; k++) {
      const tk = k * DTC;
      if (VP * (tk - t0) >= T.D[k]) {
        const tp = (k - 1) * DTC, g0 = VP * Math.max(0, tp - t0) - T.D[k - 1], g1 = VP * (tk - t0) - T.D[k];
        const f = g1 - g0 > 1e-9 ? clamp(-g0 / (g1 - g0), 0, 1) : 1;
        return { t: tp + f * DTC, u: T.U[k - 1] + (T.U[k] - T.U[k - 1]) * f, v: T.V[k - 1] + (T.V[k] - T.V[k - 1]) * f,
          d: T.D[k - 1] + (T.D[k] - T.D[k - 1]) * f, z: T.Z[k - 1] + (T.Z[k] - T.Z[k - 1]) * f, k };
      }
    }
    return null;
  }
  const edgeRoll = (sd, si, i) => mb(((sd ^ (si * 7919 + i * 104729 + 17)) >>> 0) || 1)();
  /* full evaluation of a tap record: which shell broke which clay, and why a shell missed */
  function evaluate(sd, w, st, ty, taps, tr) {
    tr = tr || tracks(sd, w, st, ty);
    const cl = tr.map(() => ({ b: -1, t: Infinity, u: 0, v: 0 }));
    const sh = [];
    taps.forEach((tp, si) => {
      const t0 = tp[0] / 1000, au = tp[1] / 1000, av = tp[2] / 1000;
      const r = { t0, au, av, ta: t0 + 0.3, hits: [], near: -1, off: 9, why: 'gone' };
      const hit = [];
      tr.forEach((T, i) => {
        if (cl[i].t <= t0) return;
        const a = arrive(T, t0);
        if (!a || cl[i].t <= a.t) return;
        const du = a.u - au, dv = a.v - av, off = Math.sqrt(du * du + dv * dv);
        if (off < r.off) { r.off = off; r.near = i; r.ta = a.t; r.a = a; }
        if (a.d <= RANGE && (off <= RC || (off <= RE && edgeRoll(sd, si, i) < (RE - off) / (RE - RC)))) hit.push([i, a]);
      });
      for (const [i, a] of hit) { cl[i] = { b: si, t: a.t, u: a.u, v: a.v, d: a.d, z: a.z }; r.hits.push(i); r.ta = a.t; }
      if (hit.length) r.why = '';
      else if (r.near >= 0) {
        const a = r.a, T = tr[r.near], k = clamp(a.k, 1, T.n - 1);
        if (a.d > RANGE) r.why = 'far';
        else {
          const vu = T.U[k] - T.U[k - 1], vv = T.V[k] - T.V[k - 1], vl = Math.sqrt(vu * vu + vv * vv) || 1;
          const ru = au - a.u, rv = av - a.v, along = (ru * vu + rv * vv) / vl, perp = (ru * -vv + rv * vu) / vl;
          r.why = Math.abs(along) >= Math.abs(perp) * 0.8 ? (along < 0 ? 'behind' : 'ahead') : (rv > 0 ? 'over' : 'under');
        }
      }
      sh.push(r);
    });
    return { tr, cl, sh };
  }
  /* time after which nothing can happen any more (all clays out of range or on the ground) */
  function doneTime(tr) { return Math.max(...tr.map((T) => T.live * DTC)); }

  /* ---------- rules / state ---------- */
  function rnd(s) { s.rs = (s.rs * 48271) % 2147483647; return s.rs / 2147483647; }
  function nextPres(s) {
    s.sd = 1 + Math.floor(rnd(s) * 2147483000);
    s.w = Math.round(clamp(s.w + (rnd(s) - 0.5) * 12, -30, 30));
  }
  const SO_ST = 2, SO_MAX = 6; // shoot-off: a double from the middle station, up to 6 rounds
  function plan(s) { return PLANS[s.N] || PLANS[25]; }
  function curSt(s) { return s.ph === 'so' ? SO_ST : s.st; }
  function curTy(s) { return s.ph === 'so' ? 'D' : plan(s)[s.st][s.j]; }
  function init(players, opts) {
    const n = players.length, N = opts && +opts.n === 10 ? 10 : 25;
    const s = { n, N, st: 0, j: 0, k: 0, ord: players.map((p, i) => i),
      rs: 1 + Math.floor(Math.random() * 2147483640), sd: 1, w: 0, r: players.map(() => ''),
      nm: players.map((p) => String(p.name || '').slice(0, 10)), seq: 0, last: null, ph: 'p', so: null };
    s.w = Math.round((rnd(s) - 0.5) * 36);
    nextPres(s);
    return s;
  }
  function actor(s) { return s.ph === 'e' ? null : s.ph === 'so' ? s.so.c[s.so.k] : s.ord[s.k]; }
  function score(s, p) { let c = 0; for (const ch of s.r[p]) if (ch !== '0') c++; return c; }
  function validTaps(a) {
    if (!a || a.type !== 'shoot' || !Array.isArray(a.taps) || a.taps.length > 2) return false;
    let prev = -1e9;
    for (const t of a.taps) {
      if (!Array.isArray(t) || t.length !== 3 || !t.every(Number.isInteger)) return false;
      if (t[0] < 0 || t[0] > TMAX * 1000 || t[0] < prev + MINGAP || Math.abs(t[1]) > 3000 || t[2] < -1000 || t[2] > 3000) return false;
      prev = t[0];
    }
    return true;
  }
  function leaders(s) {
    const sc = s.r.map((v, i) => score(s, i)), best = Math.max(...sc);
    return sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
  }
  function apply(s, seat, a) {
    if ((s.ph !== 'p' && s.ph !== 'so') || actor(s) !== seat) throw new Error('not your turn');
    if (!validTaps(a)) throw new Error('bad shot record');
    const ty = curTy(s), stn = curSt(s), taps = a.taps.map((t) => t.slice());
    const ev = evaluate(s.sd, s.w, stn, ty, taps);
    // shells fired after every clay was already broken do not count (a second shell only if needed)
    const lastBreak = Math.max(...ev.cl.map((c) => c.t));
    const used = taps.filter((t) => !(isFinite(lastBreak) && t[0] / 1000 > lastBreak + 1e-9));
    const res = ev.cl.map((c) => (c.b >= 0 ? String(c.b + 1) : '0')).join('');
    const got = res.replace(/0/g, '').length;
    s.seq++;
    s.last = { id: s.seq, s: seat, st: stn, ty, sd: s.sd, w: s.w, tp: used, res };
    if (s.ph === 'so') {
      const so = s.so;
      so.h.push(got);
      so.k++;
      s.last.so = 1;
      if (so.k >= so.c.length) { // round over: everyone in it shot the same pair
        const best = Math.max(...so.h), keep = so.c.filter((c, i) => so.h[i] === best);
        s.last.sor = so.c.map((c, i) => [c, so.h[i]]);
        if (keep.length === 1 || so.rd >= SO_MAX) { so.c = keep; so.fin = 1; s.ph = 'e'; }
        else { s.so = { c: keep, k: 0, h: [], rd: so.rd + 1, hist: so.hist.concat([s.last.sor]) }; nextPres(s); }
        if (s.ph === 'e') so.hist = so.hist.concat([s.last.sor]);
      }
      return s; // every shooter of one shoot-off round gets the same presentation
    }
    s.r[seat] += res;
    // advance: presentations of this station for this shooter, then the next shooter, then the next station
    s.j++;
    if (s.j >= plan(s)[s.st].length) {
      s.j = 0; s.k++;
      if (s.k >= s.n) {
        s.k = 0; s.st++;
        if (s.st >= 5) {
          const c = leaders(s);
          if (s.n > 1 && c.length > 1) { s.ph = 'so'; s.so = { c, k: 0, h: [], rd: 1, hist: [] }; s.last.sog = 1; }
          else s.ph = 'e';
        } else s.ord = s.ord.slice(1).concat(s.ord[0]); // first shooter rotates every station
      }
    }
    nextPres(s);
    return s;
  }
  function winners(s) { if (s.ph !== 'e') return null; return s.so ? s.so.c.slice() : leaders(s); }
  function rankOrder(s) { return s.r.map((v, i) => i).sort((a, b) => score(s, b) - score(s, a) || a - b); }
  function result(s) {
    const w = winners(s);
    if (!w) return null;
    const sc = s.r.map((v, i) => score(s, i));
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const first = (i) => s.r[i].replace(/[02]/g, '').length;
    const lines = rankOrder(s).sort((a, b) => (w.includes(b) ? 1 : 0) - (w.includes(a) ? 1 : 0)).map((i, k) => (s.n > 1 ? (k + 1) + '위 ' : '') + nm(i) + ' · ' + sc[i] + ' / ' + s.N + ' (첫발 명중 ' + first(i) + ')');
    let so = '';
    if (s.so) so = '\n슛오프 ' + s.so.hist.length + '라운드: ' + s.so.hist.map((r) => r.map((x) => nm(x[0]) + ' ' + x[1]).join(' : ')).join(' / ') + (w.length > 1 ? '\n6라운드까지 같아서 공동 우승' : '');
    return { winners: w, title: s.n === 1 ? sc[0] + ' / ' + s.N + ' 명중' : w.length > 1 ? '공동 우승' : undefined, text: lines.join('\n') + so };
  }

  /* ---------- AI: reaction time + lead estimation error by level ---------- */
  const LVC = {
    1: { re: 0.66, rs: 0.14, le: 0.6, n: 0.055, g2: 0.42 },
    2: { re: 0.46, rs: 0.09, le: 0.42, n: 0.038, g2: 0.34 },
    3: { re: 0.34, rs: 0.05, le: 0.26, n: 0.028, g2: 0.28 },
  };
  function gauss() { let u = 0, v = 0; while (u === 0) u = Math.random(); while (v === 0) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  function aiTaps(sd, w, st, ty, lv) {
    const P = LVC[lv] || LVC[2], tr = tracks(sd, w, st, ty), taps = [];
    let t = Math.max(0.15, P.re + gauss() * P.rs), aimed = -1;
    for (let shell = 0; shell < 2; shell++) {
      const ev = evaluate(sd, w, st, ty, taps, tr);
      // the AI only "sees" a break once it happened (break time before this trigger pull)
      const open = tr.map((T, i) => i).filter((i) => !(ev.cl[i].t <= t));
      if (!open.length) break;
      let i = open.find((x) => x !== aimed);
      if (i == null) i = open[0];
      if (ty === 'D' && shell === 1 && open.includes(aimed) && open.length > 1 && Math.random() < 0.5) i = aimed;
      const a = arrive(tr[i], t);
      if (!a || a.d > RANGE + 4) break;
      const p0 = at(tr[i], t), e = 1 + gauss() * P.le;
      const au = p0.u + (a.u - p0.u) * e + gauss() * P.n, av = p0.v + (a.v - p0.v) * e + gauss() * P.n;
      taps.push([Math.round(t * 1000), Math.round(au * 1000), Math.round(av * 1000)]);
      aimed = i;
      t += P.g2 + Math.random() * 0.1;
      const ev2 = evaluate(sd, w, st, ty, taps, tr);
      if (ev2.cl.every((c) => c.b >= 0) && ty === 'S') break;
    }
    return taps;
  }
  function ai(s, seat, lv) { return { type: 'shoot', taps: aiTaps(s.sd, s.w, curSt(s), curTy(s), lv) }; }

  /* ================================= view ================================= */
  const WHY = { behind: '뒤로 빗나감 · 더 앞을', ahead: '앞으로 빗나감 · 덜 앞을', over: '위로 빗나감', under: '아래로 빗나감', far: '너무 멀어요', gone: '빗나감' };
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = L.h('div', { class: 'hud top cl-top', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px', alignItems: 'stretch' } });
    root.append(top);
    // invisible boxes over canvas regions for the first-play tutorial spotlight
    const spPull = tutSpot(root, 'cl-pull'), spSky = tutSpot(root, 'cl-sky'), spInfo = tutSpot(root, 'cl-info'), spWind = tutSpot(root, 'cl-wind');
    let st = null, G = null, time = 0, anim = null, myPend = null, pops = [], parts = [], shake = 0, waitTimer = 0, recoil = 0, flash = 0, hintFlash = 0;
    let gunAim = { u: 0, v: 0.2 };
    const color = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const pname = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || '');
    const sp = () => L.debug.speed || 1;
    const stars = Array.from({ length: 36 }, (_, i) => ({ x: (i * 97.13) % 1, y: ((i * 53.7) % 100) / 100, s: i % 4 ? 1 : 1.6 }));

    function layout() {
      const W = cv.w, H = cv.h, topH = G ? G.topH : 74;
      const hy = Math.round(H * 0.64);
      const f = Math.min(W / 1.28, (hy - topH - 30) / 0.82);
      G = { W, H, topH, hy, f, cx: W / 2 };
      spSky(0, topH + 54, W, hy - topH - 54); spInfo(8, topH + 2, Math.min(170, W / 2 - 10), 48); spWind(W - 96, topH + 2, 88, 48);
    }
    const sx = (u) => G.cx + u * G.f, sy = (v) => G.hy - v * G.f;
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function humanTurn() { if (!st || st.ph === 'e') return false; const a = actor(st); return a != null && api.canAct(a); }
    function pullGeom() { return { x: G.W / 2, y: G.H - 70, r: 40 }; }

    /* ---------- scene ---------- */
    function P(c, X, Y, Z) { const p = proj(c, X, Y, Z); return { x: sx(p.u), y: sy(p.v), z: p.z }; }
    function box(c, x0, x1, y0, y1, z0, z1, front, side, roof) {
      // simple shaded block: front face (z0), right/left side, top
      const a = P(c, x0, y0, z0), b = P(c, x1, y0, z0), d = P(c, x1, y1, z0), e = P(c, x0, y1, z0);
      const b2 = P(c, x1, y0, z1), d2 = P(c, x1, y1, z1), a2 = P(c, x0, y0, z1), e2 = P(c, x0, y1, z1);
      ctx.fillStyle = side;
      const sideFace = c.sx < (x0 + x1) / 2 ? [a, e, e2, a2] : [b, d, d2, b2];
      ctx.beginPath(); sideFace.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath(); ctx.fill();
      ctx.fillStyle = roof; ctx.beginPath(); [e, d, d2, e2].forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath(); ctx.fill();
      ctx.fillStyle = front; ctx.beginPath(); [a, b, d, e].forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath(); ctx.fill();
      return { a, b, d, e };
    }
    function drawScene(stn) {
      const { W, H, hy } = G, c = cam(stn);
      const sky = ctx.createLinearGradient(0, 0, 0, hy);
      sky.addColorStop(0, '#1a1430'); sky.addColorStop(0.55, '#3d2a4f'); sky.addColorStop(0.86, '#a0566a'); sky.addColorStop(1, '#e79a6a');
      ctx.fillStyle = sky; ctx.fillRect(0, 0, W, hy);
      ctx.fillStyle = 'rgba(242,233,216,.5)';
      for (const s of stars) if (s.y * hy < hy * 0.5) ctx.fillRect(s.x * W, s.y * hy, s.s, s.s);
      // low sun glow
      const sg = ctx.createRadialGradient(W * 0.72, hy, 0, W * 0.72, hy, W * 0.6);
      sg.addColorStop(0, 'rgba(255,200,120,.45)'); sg.addColorStop(1, 'rgba(255,200,120,0)');
      ctx.fillStyle = sg; ctx.fillRect(0, hy - W * 0.6, W, W * 0.6);
      // hills + tree line (parallax with station)
      const off = -c.fx * 220;
      ctx.fillStyle = '#4a3050'; ctx.beginPath(); ctx.moveTo(0, hy);
      for (let x = 0; x <= W + 10; x += 10) ctx.lineTo(x, hy - 26 - 18 * Math.sin((x + off * 0.4) * 0.012) - 9 * Math.sin((x + off * 0.4) * 0.031 + 1));
      ctx.lineTo(W, hy); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#25182c'; ctx.beginPath(); ctx.moveTo(0, hy + 1);
      for (let x = 0; x <= W + 6; x += 6) { const q = x + off; ctx.lineTo(x, hy - 8 - 6 * Math.abs(Math.sin(q * 0.09)) - 4 * Math.abs(Math.sin(q * 0.23 + 2))); }
      ctx.lineTo(W, hy + 1); ctx.closePath(); ctx.fill();
      // field
      const gr = ctx.createLinearGradient(0, hy, 0, H);
      gr.addColorStop(0, '#3b5534'); gr.addColorStop(1, '#22331f');
      ctx.fillStyle = gr; ctx.fillRect(0, hy, W, H - hy);
      ctx.strokeStyle = 'rgba(255,255,255,.05)'; ctx.lineWidth = 1;
      for (let z = 6; z < 60; z *= 1.35) { const p = P(c, 0, 0, z); ctx.beginPath(); ctx.moveTo(0, p.y); ctx.lineTo(W, p.y); ctx.stroke(); }
      // high house (left tower), low house (right hut), trap bunker (front)
      const hh = box(c, -16.4, -13.6, 0, 6, 24, 26.4, '#5c4a64', '#4a3a52', '#6e5a78');
      ctx.fillStyle = '#17121d'; { const p = P(c, -13.7, 4.6, 24), q = P(c, -13.7, 5.3, 24); ctx.fillRect(p.x - 3, q.y, 4, p.y - q.y); }
      ctx.fillStyle = '#e3ae45'; ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText('H', (hh.e.x + hh.d.x) / 2, hh.e.y - 2);
      const lh = box(c, 14, 16.6, 0, 1.8, 22, 24.2, '#5c4a64', '#4a3a52', '#6e5a78');
      ctx.fillStyle = '#e3ae45'; ctx.fillText('L', (lh.e.x + lh.d.x) / 2, lh.e.y - 2);
      box(c, -1.8, 1.8, 0, 0.55, 13.4, 15.4, '#6f6a62', '#5a554e', '#85807a');
      { const p = P(c, -1.2, 0.18, 13.4), q = P(c, 1.2, 0.42, 13.4); ctx.fillStyle = '#1b1720'; ctx.fillRect(p.x, q.y, q.x - p.x, p.y - q.y); }
      // floodlight poles
      for (const [X, Z] of [[-24, 34], [24, 34]]) {
        const a = P(c, X, 0, Z), b = P(c, X, 11, Z);
        ctx.strokeStyle = '#2a2033'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        const lg = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, 26);
        lg.addColorStop(0, 'rgba(255,240,200,.55)'); lg.addColorStop(1, 'rgba(255,240,200,0)');
        ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(b.x, b.y, 26, 0, 7); ctx.fill();
        ctx.fillStyle = '#fff3d0'; ctx.fillRect(b.x - 4, b.y - 2, 8, 4);
      }
      // station mats at the bottom
      for (let i = 0; i < 5; i++) {
        const p = P(c, STX[i], 0, 3.2);
        if (p.x < -40 || p.x > W + 40 || p.y > H + 20) continue;
        const on = i === stn;
        ctx.fillStyle = on ? 'rgba(227,174,69,.4)' : 'rgba(242,233,216,.12)';
        ctx.beginPath(); ctx.ellipse(p.x, p.y, 26, 7, 0, 0, 7); ctx.fill();
        ctx.fillStyle = on ? '#e3ae45' : 'rgba(242,233,216,.4)'; ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.textBaseline = 'middle';
        ctx.fillText(String(i + 1), p.x, p.y);
      }
    }
    function drawClay(T, t, dim) {
      const p = at(T, t), x = sx(p.u), y = sy(p.v);
      const r = clamp(0.17 * G.f / Math.max(1, p.z), 3.2, 11);
      ctx.save(); ctx.translate(x, y);
      if (!dim) { // soft halo so a small, far clay stays easy to spot against the dusk sky
        ctx.fillStyle = 'rgba(255,190,120,.16)'; ctx.beginPath(); ctx.arc(0, 0, r * 2.4 + 4, 0, 7); ctx.fill();
      }
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(1, 1.5, r, r * 0.42, 0, 0, 7); ctx.fill();
      ctx.globalAlpha = dim ? 0.55 : 1;
      ctx.fillStyle = '#f07a2a'; ctx.beginPath(); ctx.ellipse(0, 0, r, r * 0.42, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#5a2a10'; ctx.lineWidth = Math.max(1, r * 0.18); ctx.stroke();
      ctx.fillStyle = '#ffc07a'; ctx.beginPath(); ctx.ellipse(-r * 0.15, -r * 0.08, r * 0.5, r * 0.16, 0, 0, 7); ctx.fill();
      const sp2 = Math.sin(t * 40);
      ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.fillRect(sp2 * r * 0.6 - 1, -r * 0.3, 2, r * 0.3);
      ctx.restore();
      return { x, y, r };
    }
    function shatter(x, y, vu, vv, r) {
      const n = 22;
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, s = 60 + Math.random() * 240;
        parts.push({ k: 'shard', x, y, vx: Math.cos(a) * s + vu * 0.4, vy: Math.sin(a) * s * 0.75 - vv * 0.4 - 40, rot: Math.random() * 7, vr: (Math.random() - 0.5) * 22,
          sz: (0.5 + Math.random() * 0.9) * Math.max(4, r), t: 0, life: 0.9 + Math.random() * 0.6, c: Math.random() < 0.25 ? '#5a2a10' : Math.random() < 0.5 ? '#f07a2a' : '#ff9d4a' });
      }
      for (let i = 0; i < 9; i++) {
        const a = Math.random() * Math.PI * 2, s = 20 + Math.random() * 60;
        parts.push({ k: 'dust', x, y, vx: Math.cos(a) * s + vu * 0.2, vy: Math.sin(a) * s * 0.6 - vv * 0.2, t: 0, life: 0.8 + Math.random() * 0.5, sz: 6 + Math.random() * 8 });
      }
      parts.push({ k: 'ring', x, y, t: 0, life: 0.35, sz: Math.max(14, r * 3) });
    }
    function drawParts(dt) {
      for (const p of parts) {
        p.t += dt;
        if (p.k === 'shard') { p.vy += 520 * dt; p.vx *= 1 - dt * 0.8; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt; }
        else if (p.k === 'dust') { p.vx *= 1 - dt * 2.2; p.vy *= 1 - dt * 2.2; p.vy -= 8 * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
      }
      parts = parts.filter((p) => p.t < p.life);
      for (const p of parts) {
        const k = p.t / p.life;
        if (p.k === 'shard') {
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.globalAlpha = 1 - k * k;
          ctx.fillStyle = p.c; ctx.beginPath(); ctx.moveTo(-p.sz * 0.5, -p.sz * 0.2); ctx.lineTo(p.sz * 0.45, -p.sz * 0.3); ctx.lineTo(p.sz * 0.15, p.sz * 0.3); ctx.closePath(); ctx.fill();
          ctx.restore();
        } else if (p.k === 'dust') {
          ctx.globalAlpha = 0.45 * (1 - k); ctx.fillStyle = '#c96a32';
          ctx.beginPath(); ctx.arc(p.x, p.y, p.sz * (0.6 + k * 1.4), 0, 7); ctx.fill(); ctx.globalAlpha = 1;
        } else if (p.k === 'ring') {
          ctx.globalAlpha = 1 - k; ctx.strokeStyle = '#fff1c8'; ctx.lineWidth = 3 * (1 - k) + 0.5;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.sz * (0.4 + k * 1.4), 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
        } else if (p.k === 'miss') {
          ctx.globalAlpha = 0.8 * (1 - k); ctx.fillStyle = '#f2e9d8';
          for (let i = 0; i < 16; i++) { const a = i * 2.4 + p.x, rr2 = p.sz * Math.sqrt(((i * 37) % 16) / 16); ctx.fillRect(p.x + Math.cos(a) * rr2, p.y + Math.sin(a) * rr2, 1.6, 1.6); }
          ctx.strokeStyle = 'rgba(242,233,216,.5)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(p.x, p.y, p.sz, 0, 7); ctx.stroke(); ctx.setLineDash([]);
          ctx.globalAlpha = 1;
        }
      }
    }
    /* shotgun barrels from the bottom edge toward the last aim point */
    function drawGun(col) {
      const { W, H } = G, bx = W / 2 + 34, by = H + 30 + recoil * 22;
      const tx = sx(gunAim.u), ty = sy(gunAim.v), ang = Math.atan2(ty - by, tx - bx);
      ctx.save(); ctx.translate(bx, by); ctx.rotate(ang);
      ctx.fillStyle = '#1b1720'; rr(-40, -11, 170, 22, 6); ctx.fill();
      ctx.fillStyle = '#3a3346'; rr(0, -8, 150, 7, 3); ctx.fill(); rr(0, 1, 150, 7, 3); ctx.fill();
      ctx.fillStyle = '#6a5a7a'; ctx.fillRect(0, -1, 150, 2);
      ctx.fillStyle = col; ctx.fillRect(-30, -11, 22, 22);
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(150, 0, 2.2, 0, 7); ctx.fill();
      if (flash > 0) {
        ctx.globalAlpha = Math.min(1, flash * 8);
        ctx.fillStyle = '#ffe9a8'; ctx.beginPath(); ctx.moveTo(152, -10); ctx.lineTo(190, 0); ctx.lineTo(152, 10); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(156, 0, 6, 0, 7); ctx.fill();
        ctx.globalAlpha = 1;
      }
      ctx.restore();
    }
    function hint(text, col, y) {
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const w = ctx.measureText(text).width + 26, x = G.W / 2;
      ctx.fillStyle = 'rgba(18,14,24,.85)'; rr(x - w / 2, y - 13, w, 26, 13); ctx.fill();
      ctx.fillStyle = col || '#f2e9d8'; ctx.fillText(text, x, y + 0.5);
    }
    function pop(text, col, big, life, at2) { pops = pops.filter((p) => p.big !== !!big); pops.push({ text, col, big: !!big, t: 0, life: (life || 1.1) / Math.sqrt(sp()), at: at2 }); }
    function drawPops(dt) {
      for (const p of pops) p.t += dt;
      pops = pops.filter((p) => p.t < p.life);
      for (const p of pops) {
        const a = p.t < 0.1 ? p.t / 0.1 : p.t > p.life - 0.25 ? Math.max(0, (p.life - p.t) / 0.25) : 1;
        ctx.save(); ctx.globalAlpha = a;
        ctx.font = '400 ' + (p.big ? 34 : 17) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        let x = G.W / 2, y = G.topH + (p.big ? 96 : 130);
        if (p.at) { x = clamp(p.at.x, 70, G.W - 70); y = clamp(p.at.y - 26, G.topH + 70, G.hy - 10); }
        y -= Math.min(1, p.t / 0.2) * 6;
        ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(18,14,24,.85)'; ctx.strokeText(p.text, x, y);
        ctx.fillStyle = p.col; ctx.fillText(p.text, x, y);
        ctx.restore();
      }
    }
    function drawInfo(s, stn, ty) {
      const x0 = 10, y0 = G.topH + 4;
      const seat = anim ? anim.seat : actor(s);
      const shot = seat != null ? s.r[seat].length : 0;
      const so = s.ph === 'so' || (anim && anim.last && anim.last.so);
      const t1 = so ? '슛오프 · 더블' : (stn + 1) + '번 사대 · ' + (ty === 'D' ? '더블' : '싱글');
      const t2 = so ? (s.so ? s.so.rd : 1) + '라운드 · 많이 깨면 승' : '표적 ' + Math.min(s.N, shot + 1) + (ty === 'D' && shot + 2 <= s.N ? '–' + (shot + 2) : '') + ' / ' + s.N;
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const tw = Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width) + 22;
      ctx.fillStyle = 'rgba(18,14,24,.84)'; rr(x0, y0, tw, 44, 12); ctx.fill();
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = ty === 'D' ? '#e3ae45' : '#f2e9d8'; ctx.fillText(t1, x0 + 11, y0 + 14);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText(t2, x0 + 11, y0 + 31);
    }
    function drawWind(w10) {
      const w = w10 / 10, bw = 84, x0 = G.W - 10 - bw, y0 = G.topH + 4;
      ctx.fillStyle = 'rgba(18,14,24,.84)'; rr(x0, y0, bw, 44, 12); ctx.fill();
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ab9fb8'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText('바람', x0 + 10, y0 + 14);
      ctx.fillStyle = '#f2e9d8'; ctx.font = '600 13px "IBM Plex Mono", monospace'; ctx.fillText(Math.abs(w).toFixed(1), x0 + 10, y0 + 31);
      const col = Math.abs(w) >= 2 ? '#ee6a55' : Math.abs(w) >= 1 ? '#e3ae45' : '#5fd3a0';
      const ax = x0 + 62, ay = y0 + 22, d = w > 0.05 ? 1 : w < -0.05 ? -1 : 0, len = 6 + 8 * Math.min(1, Math.abs(w) / 3);
      ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 3; ctx.lineCap = 'round';
      if (d) {
        ctx.beginPath(); ctx.moveTo(ax - d * len, ay); ctx.lineTo(ax + d * len, ay); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(ax + d * (len + 4), ay); ctx.lineTo(ax + d * (len - 3), ay - 6); ctx.lineTo(ax + d * (len - 3), ay + 6); ctx.closePath(); ctx.fill();
      } else { ctx.beginPath(); ctx.arc(ax, ay, 4, 0, 7); ctx.fill(); }
    }
    function drawShells(left) {
      const x0 = 16, y0 = G.H - 58;
      for (let i = 0; i < 2; i++) {
        const x = x0 + i * 22, on = i < left;
        ctx.globalAlpha = on ? 1 : 0.28;
        ctx.fillStyle = '#c23b2e'; rr(x, y0, 14, 30, 3); ctx.fill();
        ctx.fillStyle = '#d9b25a'; ctx.fillRect(x, y0 + 22, 14, 8);
        ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(x + 3, y0 + 2, 2, 18);
        ctx.globalAlpha = 1;
      }
      ctx.fillStyle = '#ab9fb8'; ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText('탄', x0 + 48, y0 + 15);
    }
    function drawPull(glow) {
      const g = pullGeom();
      ctx.save();
      ctx.fillStyle = 'rgba(227,174,69,' + (0.12 + 0.12 * glow * (0.6 + 0.4 * Math.sin(time * 5))) + ')'; ctx.beginPath(); ctx.arc(g.x, g.y, g.r + 10, 0, 7); ctx.fill();
      const gg = ctx.createLinearGradient(0, g.y - g.r, 0, g.y + g.r);
      gg.addColorStop(0, '#f0c25e'); gg.addColorStop(1, '#c48a26');
      ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(g.x, g.y, g.r, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#2a1d05'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '400 26px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.fillText('풀!', g.x, g.y + 1);
      ctx.restore();
    }

    /* ---------- HUD (DOM) ---------- */
    let hudKey = '';
    function renderTop(s, cur) {
      if (!s) return;
      const key = JSON.stringify([s.r, s.so, cur, s.ph]);
      if (key === hudKey) return;
      hudKey = key;
      top.innerHTML = '';
      const rk = rankOrder(s);
      for (let i = 0; i < s.n; i++) {
        const p = api.players[i] || { name: s.nm[i], color: '#fff' }, on = cur === i;
        const rs = s.r[i], tail = rs.slice(-Math.min(rs.length, s.n > 3 ? 5 : 7));
        const dots = [];
        for (const ch of tail) dots.push(L.h('span', { style: { width: '8px', height: '8px', borderRadius: '50%', flex: 'none', background: ch === '0' ? 'transparent' : ch === '1' ? '#f07a2a' : '#b35a20', border: ch === '0' ? '1.5px solid rgba(242,233,216,.35)' : '0' } }));
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '6px 8px', display: 'flex', flexDirection: 'column', gap: '3px', opacity: on || cur == null ? 1 : 0.68, borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color + ' inset' : '' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
            L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto' }, text: p.name }),
            s.n > 1 && rs.length ? L.h('span', { class: 'mono muted', style: { fontSize: '10px', flex: 'none' }, text: (rk.indexOf(i) + 1) + '위' }) : null),
          L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '3px' } },
            L.h('span', { class: 'mono', style: { fontSize: s.n > 3 ? '18px' : '22px', fontWeight: 600, lineHeight: 1 }, text: String(score(s, i)) }),
            L.h('span', { class: 'muted mono', style: { fontSize: '10px', fontWeight: 700 }, text: '/' + rs.length })),
          s.so ? L.h('div', { class: 'mono', style: { fontSize: '10px', minHeight: '9px', lineHeight: '10px', whiteSpace: 'nowrap', color: s.so.c.includes(i) ? 'var(--coral)' : 'var(--muted)' },
            text: s.so.c.includes(i) ? '슛오프' + (s.so.c.indexOf(i) < s.so.h.length ? ' ' + s.so.h[s.so.c.indexOf(i)] + '/2' : '') : '—' })
            : L.h('div', { style: { display: 'flex', gap: '3px', minHeight: '9px', alignItems: 'center', overflow: 'hidden' } }, dots)));
      }
      requestAnimationFrame(() => { const h = top.getBoundingClientRect().height; if (h && G && Math.abs(h + 4 - G.topH) > 1) { G.topH = h + 4; layout(); } });
    }

    /* ---------- turn animation (live or replay share the same driver) ---------- */
    function newAnim(mode, seat, p) {
      const tr = tracks(p.sd, p.w, p.st, p.ty);
      return { mode, seat, sd: p.sd, w: p.w, st: p.st, ty: p.ty, tr, end: doneTime(tr), taps: (p.tp || []).map((t) => t.slice()), ev: null, done: {}, ph: mode === 'live' ? 'ready' : 'pull', t: 0, pt: 0, delay: 0.45, fired: 0, last: p.last || null, snap: p.snap };
    }
    function startLive() {
      const seat = actor(st);
      anim = newAnim('live', seat, { sd: st.sd, w: st.w, st: curSt(st), ty: curTy(st), snap: st });
      anim.seq = st.seq;
      anim.ev = evaluate(anim.sd, anim.w, anim.st, anim.ty, [], anim.tr);
      gunAim = { u: 0, v: 0.12 };
    }
    function startReplay(l, prev) {
      anim = newAnim('replay', l.s, { sd: l.sd, w: l.w, st: l.st, ty: l.ty, tp: l.tp, last: l, snap: prev || st });
      anim.ev = evaluate(anim.sd, anim.w, anim.st, anim.ty, anim.taps, anim.tr);
      anim.delay = 0.35;
      gunAim = { u: 0, v: 0.12 };
      api.setBusy(true);
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim && anim.last === l) endAnim(); }, 15000);
    }
    let soShown = 0;
    function endAnim() {
      if (st && st.last && (st.last.sog || st.last.sor) && soShown !== st.last.id) {
        soShown = st.last.id;
        if (st.last.sog) { api.toast('동점! 슛오프 — 같은 더블을 한 번씩'); api.sfx('chip'); }
        else if (st.ph === 'so') api.toast('또 동점! 슛오프 ' + st.so.rd + '라운드');
      }
      anim = null; clearTimeout(waitTimer); parts = parts.filter((p) => p.k === 'shard');
      hudKey = ''; renderTop(st, st ? actor(st) : null);
      api.setBusy(false);
    }
    function fire(u, v) {
      const a = anim;
      a.taps.push([Math.round(a.t * 1000), Math.round(u * 1000), Math.round(v * 1000)]);
      a.ev = evaluate(a.sd, a.w, a.st, a.ty, a.taps, a.tr);
      a.fired = a.taps.length;
      gunAim = { u, v }; recoil = 1; flash = 0.12; shake = 0.18;
      api.sfx('hit'); api.sfx('thud'); api.buzz(18);
    }
    function finishLive() {
      const a = anim;
      a.ph = 'sent'; a.st0 = time;
      myPend = { seq: st.seq, seat: a.seat };
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim === a) endAnim(); }, 6000);
      api.act({ type: 'shoot', taps: a.taps });
    }
    function summary(a) {
      const res = a.ev.cl.map((c) => (c.b >= 0 ? 1 : 0)), got = res.reduce((x, y) => x + y, 0);
      if (a.ty === 'D') return got === 2 ? ['더블 성공!', '#5fd3a0'] : got === 1 ? ['1 / 2 명중', '#e3ae45'] : ['둘 다 놓침', '#ee6a55'];
      if (!got) return ['놓침', '#ee6a55'];
      return a.ev.cl[0].b === 0 ? ['첫발 명중!', '#5fd3a0'] : ['두 번째 탄 명중', '#e3ae45'];
    }
    function stepAnim(dt) {
      const a = anim;
      if (a.ph === 'ready') return;
      const k = dt * sp() * (a.ff ? 4 : 1);
      if (a.ph === 'pull') {
        a.pt += k;
        if (a.pt >= a.delay) { a.ph = 'fly'; a.t = 0; api.sfx('whoosh'); api.buzz(8); }
        return;
      }
      a.t += k;
      const t = a.t;
      // replay: fire recorded shells at their time
      if (a.mode === 'replay') {
        while (a.fired < a.taps.length && a.taps[a.fired][0] / 1000 <= t) {
          const tp = a.taps[a.fired]; a.fired++;
          gunAim = { u: tp[1] / 1000, v: tp[2] / 1000 }; recoil = 1; flash = 0.12; shake = 0.15;
          api.sfx('hit'); api.buzz(10);
        }
      }
      // shells arriving
      a.ev.sh.forEach((r, i) => {
        if (i >= a.fired || a.done[i] || r.ta > t) return;
        a.done[i] = 1;
        if (r.hits.length) {
          for (const c of r.hits) {
            const T = a.tr[c], cl = a.ev.cl[c], kk = clamp(Math.round(cl.t / DTC), 1, T.n - 1);
            const pz = clamp(0.17 * G.f / Math.max(1, cl.z), 3.2, 11);
            shatter(sx(cl.u), sy(cl.v), (T.U[kk] - T.U[kk - 1]) / DTC * G.f, (T.V[kk] - T.V[kk - 1]) / DTC * G.f, pz);
          }
          api.sfx('pop'); setTimeout(() => api.sfx('chip'), 40); api.buzz(30); shake = 0.3;
          pop(r.hits.length > 1 ? '한 발에 둘!' : '명중!', '#ffb35a', false, 0.9, { x: sx(a.ev.cl[r.hits[0]].u), y: sy(a.ev.cl[r.hits[0]].v) });
        } else {
          parts.push({ k: 'miss', x: sx(r.au), y: sy(r.av), t: 0, life: 0.7, sz: RC * G.f });
          if (r.near >= 0) pop(WHY[r.why] || '빗나감', '#f2e9d8', false, 1.1, { x: sx(r.au), y: sy(r.av) });
        }
      });
      // end of the presentation
      const allBroken = a.ev.cl.every((c) => c.b >= 0);
      const lastHit = Math.max(0, ...a.ev.cl.filter((c) => c.b >= 0).map((c) => c.t));
      const lastArr = Math.max(0, ...a.ev.sh.slice(0, a.fired).map((r) => r.ta));
      let over = false;
      if (allBroken && t > lastHit + 0.55) over = true;
      if (a.mode === 'live' && a.fired >= 2 && t > lastArr + 0.45) over = true;
      if (a.mode === 'replay' && a.fired >= a.taps.length && t > Math.max(lastArr + 0.45, a.taps.length >= 2 || allBroken ? 0 : a.end * 0.6)) over = true;
      if (t > a.end + 0.25) over = true;
      if (over && a.ph === 'fly') {
        a.ph = 'sum'; a.sumT = 0;
        const [txt, col] = summary(a);
        pop(txt, col, true, 1.2);
        if (a.mode === 'live') finishLive();
      }
      if (a.ph === 'sum' || a.ph === 'sent') {
        a.sumT = (a.sumT || 0) + k;
        if (a.mode === 'replay' && a.sumT > 1.0) endAnim();
        else if (a.mode === 'live' && a.ph === 'sum' && a.sumT > 1.0) endAnim();
      }
    }

    const stopLoop = U.loop((dt) => {
      time += dt;
      if (!G || !st) return;
      if (hintFlash > 0) hintFlash -= dt;
      if (!anim && humanTurn()) startLive();
      if (anim) stepAnim(dt);
      recoil = Math.max(0, recoil - dt * 6); flash = Math.max(0, flash - dt); shake = Math.max(0, shake - dt);
      draw(dt);
    });

    function draw(dt) {
      cv.clear();
      const s = st, a = anim;
      const stn = a ? a.st : s.ph === 'e' ? Math.min(4, s.st) : curSt(s), ty = a ? a.ty : s.ph === 'e' ? 'S' : curTy(s);
      ctx.save();
      if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 16, (Math.random() - 0.5) * shake * 16);
      drawScene(stn);
      if (a && (a.ph === 'fly' || a.ph === 'sum' || a.ph === 'sent')) {
        a.tr.forEach((T, i) => {
          const cl = a.ev.cl[i];
          if (cl.t <= a.t || a.t > (T.n - 1) * DTC) return;
          drawClay(T, a.t, a.t > T.live * DTC);
        });
        // pellet clouds in flight
        a.ev.sh.forEach((r, i) => {
          if (i >= a.fired || a.t > r.ta || a.t < r.t0) return;
          const k = (a.t - r.t0) / Math.max(0.05, r.ta - r.t0);
          const x0 = G.W / 2 + 34, y0 = G.H, x1 = sx(r.au), y1 = sy(r.av);
          const x = x0 + (x1 - x0) * Math.sqrt(k), y = y0 + (y1 - y0) * Math.sqrt(k), rad = 4 + RC * G.f * k;
          ctx.fillStyle = 'rgba(255,240,200,.75)';
          for (let j = 0; j < 14; j++) { const an = j * 2.39, q = rad * Math.sqrt(((j * 37) % 14) / 14); ctx.fillRect(x + Math.cos(an) * q, y + Math.sin(an) * q, 1.6, 1.6); }
        });
        // replay: show the aim reticle approaching each recorded tap
        if (a.mode === 'replay') {
          const nx = a.taps[a.fired];
          if (nx) {
            const tt = nx[0] / 1000, k = clamp(1 - (tt - a.t) / 0.35, 0, 1);
            if (k > 0) { ctx.globalAlpha = k; reticle(sx(nx[1] / 1000), sy(nx[2] / 1000), color(a.seat)); ctx.globalAlpha = 1; }
          }
        }
      }
      drawParts(dt);
      drawGun(a ? color(a.seat) : actor(s) != null ? color(actor(s)) : '#e3ae45');
      ctx.restore();
      // HUD
      drawInfo(a ? a.snap || s : s, stn, ty);
      drawWind(a ? a.w : s.w);
      const live = a && a.mode === 'live';
      { const g = pullGeom(); if (live && a.ph === 'ready') spPull(g.x - g.r - 8, g.y - g.r - 8, 2 * g.r + 16, 2 * g.r + 16); else spPull(null); }
      if (live && a.ph === 'ready') {
        drawPull(1);
        hint(hintFlash > 0 ? '먼저 「풀!」을 눌러 표적을 날리세요' : '「풀!」을 누르면 표적이 날아가요', hintFlash > 0 ? '#ee6a55' : '#f2e9d8', G.H - 134);
      } else if (live && (a.ph === 'pull' || a.ph === 'fly')) {
        drawShells(2 - a.taps.length);
        if (a.ph === 'pull') hint('풀!', '#e3ae45', G.H - 30);
        else hint(a.taps.length ? (a.ev.cl.every((c) => c.b >= 0) ? '명중!' : '한 발 더! 표적 앞쪽을 탭') : '표적 앞쪽을 탭해 쏘세요', '#f2e9d8', G.H - 30);
      } else if (a && a.mode === 'replay') {
        drawShells(2 - a.fired);
        if (a.ph !== 'sum') hint(pname(a.seat) + ' 사격 중 · 탭하면 빨리 보기', '#ab9fb8', G.H - 30);
      } else if (!a && s.ph !== 'e') {
        const seat = actor(s), p = api.players[seat];
        if (p && !api.canAct(seat)) hint(p.name + (p.ai ? ' 준비 중…' : ' 차례'), '#ab9fb8', G.H - 30);
      }
      drawPops(dt);
    }
    function reticle(x, y, col) {
      ctx.strokeStyle = col; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, RC * G.f, 0, 7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x - RC * G.f - 6, y); ctx.lineTo(x - 4, y); ctx.moveTo(x + 4, y); ctx.lineTo(x + RC * G.f + 6, y);
      ctx.moveTo(x, y - RC * G.f - 6); ctx.lineTo(x, y - 4); ctx.moveTo(x, y + 4); ctx.lineTo(x, y + RC * G.f + 6); ctx.stroke();
    }

    /* ---------- input ---------- */
    const el = cv.cv;
    function onDown(ev) {
      if (!G || !st || !ev.isPrimary && ev.pointerType === 'mouse') return;
      const p = cv.local(ev);
      ev.preventDefault();
      const a = anim;
      if (!a) return;
      if (a.mode === 'replay') { a.ff = true; return; }
      if (a.ph === 'ready') {
        const g = pullGeom();
        if (Math.hypot(p.x - g.x, p.y - g.y) <= g.r + 12) {
          a.ph = 'pull'; a.pt = 0; a.delay = 0.3 + Math.random() * 0.3;
          api.setBusy(true); api.sfx('click'); api.buzz(12);
          pop('풀!', '#e3ae45', true, 0.6);
        } else { hintFlash = 1.2; api.buzz(6); }
        return;
      }
      if (a.ph === 'fly') {
        if (a.taps.length >= 2 || a.t > TMAX - 0.05) return;
        if (a.taps.length && a.t * 1000 < a.taps[a.taps.length - 1][0] + MINGAP) return;
        if (a.ev.cl.every((c) => c.b >= 0 && c.t <= a.t)) return; // everything already broken
        if (p.y > G.H - 8) return;
        fire((p.x - G.cx) / G.f, (G.hy - p.y) / G.f);
      }
    }
    el.addEventListener('pointerdown', onDown);
    cv.onresize = () => layout();
    layout();

    return {
      _dbg: () => ({ anim, G, st }),
      update(next, prev) {
        st = next;
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          if (myPend && l.id === myPend.seq + 1 && l.s === myPend.seat && anim && anim.mode === 'live') {
            myPend = null; anim.ph = 'sum'; clearTimeout(waitTimer);
            waitTimer = setTimeout(() => { if (anim) endAnim(); }, 5000);
          } else {
            if (anim) anim = null;
            myPend = null;
            startReplay(l, prev);
          }
        } else if (anim && anim.mode === 'live' && anim.ph === 'ready' && (!humanTurn() || anim.seq !== next.seq)) {
          anim = null;
        }
        renderTop(anim && anim.snap && anim.ph !== 'sum' ? anim.snap : next, anim ? anim.seat : actor(next));
      },
      destroy() {
        stopLoop(); clearTimeout(waitTimer);
        el.removeEventListener('pointerdown', onDown);
        cv.destroy(); top.remove(); [spPull, spSky, spInfo, spWind].forEach((f) => f.el.remove());
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'clay', name: '클레이 사격', tag: '트랩 · 스키트', cat: '스포츠',
    blurb: '「풀!」로 접시 표적을 날리고 날아갈 곳을 미리 탭해 쏘세요. 산탄이 날아가는 시간만큼 앞을 겨눠야 깨져요. 표적마다 두 발, 사대 5곳을 돌며 더 많이 깬 사람이 이겨요(동점이면 슛오프).',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 600,
    tint: '#6a3418',
    icon: '<ellipse cx="38" cy="18" rx="12" ry="5" fill="currentColor"/><path d="M30 10l-4-5M44 9l3-5M50 16l5-1" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M6 52L30 30" stroke="currentColor" stroke-width="6" stroke-linecap="round"/><path d="M12 50l20-18" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".55"/><circle cx="34" cy="26" r="1.8" fill="currentColor"/>',
    options: [
      { id: 'n', label: '표적 수', choices: [{ v: 25, label: '25개 (정식)' }, { v: 10, label: '10개 (빠른 판)' }], def: 25 },
    ],
    quick: [
      '날아가는 접시 표적을 맞혀 깨요. 모든 표적을 쏜 뒤 가장 많이 깬 사람이 이겨요(1개 = 1점).',
      '내 차례: 「풀!」을 누르면 표적이 날아가요. 표적이 갈 곳(움직이는 방향의 앞쪽)을 탭하면 쏴요.',
      '표적 하나에 탄 2발(첫발을 놓치면 한 발 더). 더블은 표적 2개에 2발이에요.',
    ],
    rules: [
      { h: '목표', p: ['접시 모양 표적(클레이)을 산탄총으로 맞혀 깨는 사격이에요.',
        '사람마다 표적 25개(정식) 또는 10개(빠른 판)를 쏴서, 가장 많이 깬 사람이 이겨요.'] },
      { h: '차례에 할 일', p: ['① 사대(쏘는 자리) 1번부터 5번까지 차례로 옮겨 가며 쏴요.',
        '② 한 사대에서 한 사람이 그 사대의 표적을 모두 쏘면 다음 사람 차례예요.',
        '③ 사대가 바뀔 때마다 먼저 쏘는 사람이 한 칸씩 바뀌어요.',
        '앞쪽 사대는 싱글(표적 1개), 뒤쪽 사대에는 더블(표적 2개가 동시에)이 섞여요. 왼쪽 위 칸에 지금 사대와 싱글/더블, 몇 번째 표적인지 나와요.',
        '표적은 앞쪽 트랩 하우스(멀어지는 표적), 왼쪽 높은 탑 H(오른쪽으로 가로지름), 오른쪽 낮은 집 L(왼쪽으로 가로지름)에서 날아와요. 방향과 속도는 매번 조금씩 달라요.'] },
      { h: '조작 (손가락)', p: ['① 아래 「풀!」 버튼을 누르면 잠시 뒤 표적이 날아가요.',
        '② 화면을 탭하면 그 지점으로 바로 쏴요. 탭한 곳에 조준 원이 생겨요.',
        '③ 산탄은 날아가는 데 시간이 걸려요(25m에 약 0.15초). 그동안 표적이 움직이니까, 표적이 갈 곳 — 움직이는 방향의 앞쪽 — 을 탭해야 깨져요.',
        '④ 빗나가면 「뒤로 빗나감 · 더 앞을」처럼 알려 줘요. 싱글은 첫발을 놓쳤으면 한 발 더 쏠 수 있어요.',
        '다른 사람의 사격은 조준 원과 함께 다시보기로 보여 줘요. 탭하면 빨리 감아요.'] },
      { h: '점수·승리', p: ['깬 표적 하나에 1점.',
        '싱글은 탄 2발(첫발을 놓치면 한 발 더). 더블은 두 표적에 탄 2발이라 한 발에 하나씩 맞혀야 해요.',
        '모든 표적을 쏜 뒤 가장 많이 깬 사람이 이겨요.',
        '1등이 같으면 슛오프: 동점인 사람만 3번 사대에서 똑같은 더블을 한 번씩 쏴서 더 많이 깬 사람이 이겨요. 또 같으면 새 더블로 다시(최대 6라운드, 그래도 같으면 공동 우승).'] },
      { h: '맞는 조건', p: ['산탄이 퍼지는 원(조준 원) 안에 표적이 있으면 깨져요. 원 가장자리에 걸치면 깨질 수도 있어요.',
        '48m보다 멀어진 표적은 산탄이 약해서 안 깨져요. 너무 기다리지 마세요.',
        '옆바람이 표적을 조금 밀어요(오른쪽 위 「바람」 표시).'] },
      { h: '예시', p: ['왼쪽 탑 H에서 표적이 오른쪽으로 날아감 → 표적보다 조금 오른쪽(가는 쪽)을 탭 → 깨짐! 1점.',
        '멀어지는 표적(앞쪽 트랩 하우스)은 화면에서 천천히 움직여서, 가는 쪽을 조금만 앞서 탭하면 돼요. 너무 기다리면 48m를 넘어 안 깨져요.',
        '더블: 두 표적이 동시에 날아와요 → 하나를 쏘고, 바로 다른 하나를 쏴요(탄은 2발뿐).'] },
      { h: '공정성·다시보기', p: ['표적이 날아가는 길은 판 안의 시드로 정해져서 모든 기기에서 똑같아요. 쏜 기기는 탭한 시각과 위치만 보내고, 명중은 같은 계산으로 다시 판정해요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(반응 속도와 리드 계산 오차가 달라요).'] },
    ],
    tutorial: [
      { sel: '.cl-pull', text: '「풀!」을 누르면 잠시 뒤 접시 표적이 날아가요. 준비되면 누르세요.' },
      { sel: '.cl-sky', text: '표적이 날아가면 화면을 탭해서 쏴요. 산탄이 날아가는 동안 표적이 움직이니까, 표적이 갈 곳(움직이는 방향의 앞쪽)을 탭해야 깨져요.' },
      { sel: '.cl-sky', text: '탭한 곳의 조준 원 안에 표적이 들어오면 깨져요. 빗나가면 「더 앞을」처럼 알려 줘요. 싱글은 첫발을 놓치면 한 발 더!' },
      { sel: '.cl-info', text: '여기에 지금 사대(1~5번)와 싱글/더블, 몇 번째 표적인지 나와요. 더블은 표적 2개가 한꺼번에 날아와요.' },
      { sel: '.cl-wind', text: '옆바람이 표적을 조금 밀어요. 바람이 셀수록 숫자가 커지고 색이 빨개져요.' },
      { sel: '.cl-top', text: '깬 표적 1개 = 1점. 모든 표적을 쏜 뒤 가장 많이 깬 사람이 이겨요!' },
    ],
    init, actor, apply, ai, result, mount,
    aiDelayFor() { return 600; },
    _t: { winners, leaders, curTy, curSt, launch, track, tracks, arrive, evaluate, at, cam, proj, aiTaps, LVC, PLANS, score, validTaps, doneTime, RC, RE, VP, DTC, RANGE },
  });
})();
