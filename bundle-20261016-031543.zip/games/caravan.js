/* 사막 대상 무역로 — 육각 사막 판에 길을 깔아 오아시스 도시들을 잇고, 낙타 대상을 보내 주문(어느 도시가 어떤 물건을 원함)을 채워 금을 벌어요.
   남이 깐 길을 지나가면 칸마다 통행료를 그 주인에게 내요. 바퀴마다 사막 사건(모래폭풍·도적·시장 붐…)이 하나씩 일어나요.
   모든 이름·규칙·그림은 이 게임 자체 디자인이에요.
   상태(작게): m 지형(9×11, '.'모래 r바위 c협곡 o오아시스 m바위산 *도시), o 길 주인('.' 또는 자리 숫자), cy 도시 칸, cn 도시 이름 번호, pr 도시 특산물,
   gd 금, dl 배달 수, ti 통행료 수입, t 차례, b 이번 차례 깐 칸, sd 이번 차례 보냈나, mk 공개 주문 [[물건, 도시번호, 보상]], dk 주문 더미(2글자씩),
   ev 사건 번호, ep 사건 대상(칸 또는 물건), ed 사건 더미, rd 바퀴, nd 이번 바퀴 배달 없음, fin 마지막 바퀴, goal 목표 금, ov 끝, last 최근 일(애니메이션용). */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- hex grid (pointy-top, odd rows shifted right) ---------- */
  const W = 9, H = 11, N = W * H;
  const SQ3 = Math.sqrt(3);
  const DIR_E = [[1, 0], [0, -1], [-1, -1], [-1, 0], [-1, 1], [0, 1]];
  const DIR_O = [[1, 0], [1, -1], [0, -1], [-1, 0], [0, 1], [1, 1]];
  const NBD = [], NB = [];
  for (let i = 0; i < N; i++) {
    const q = i % W, r = (i / W) | 0, D = r & 1 ? DIR_O : DIR_E;
    NBD.push(D.map(([dq, dr]) => { const a = q + dq, b = r + dr; return a >= 0 && a < W && b >= 0 && b < H ? b * W + a : -1; }));
    NB.push(NBD[i].filter((j) => j >= 0));
  }
  function cube(i) { const q = i % W, r = (i / W) | 0; const x = q - (r - (r & 1)) / 2; return [x, -x - r, r]; }
  function hd(a, b) { const A = cube(a), B = cube(b); return Math.max(Math.abs(A[0] - B[0]), Math.abs(A[1] - B[1]), Math.abs(A[2] - B[2])); }
  const HX = (i) => SQ3 * ((i % W) + 0.5 * (((i / W) | 0) & 1)) + SQ3 / 2;
  const HY = (i) => 1.5 * ((i / W) | 0) + 1;
  const MAPB = { x0: 0, y0: 0, x1: SQ3 * (W + 0.5), y1: 1.5 * (H - 1) + 2 };

  /* ---------- content ---------- */
  const GOODS = ['향신료', '비단', '소금', '대추야자', '유리', '유향'];
  const GCOL = ['#e0702e', '#b36ad6', '#ece6d6', '#8a5a2b', '#58c3dc', '#9cc24a'];
  const GSYM = ['향', '비', '소', '대', '유', '향'];
  const GSH = ['◆', '✦', '■', '●', '▲', '✚'];
  const CNAMES = ['바람골', '붉은샘', '달모래', '노을언덕', '별우물', '황금문', '낙타목', '은빛터', '구름샘', '해돋이', '모래성', '푸른못'];
  const TERR = { '.': '모래', r: '바위', c: '협곡', o: '오아시스', m: '바위산', '*': '도시' };
  const MAXB = 3, MAXR = 30, START = 10;
  /* 사건 14종 — 바퀴가 시작될 때 한 장씩, 그 바퀴 동안 효과 */
  const EVENTS = [
    { n: '모래폭풍', s: '≋', d: '폭풍이 지나는 7칸은 이번 바퀴에 길을 깔 수도, 대상이 지나갈 수도 없어요.' },
    { n: '도적 떼', s: '⚔', d: '붉은 표시 7칸을 지나는 대상은 도적에게 금 3을 뺏겨요(한 번만).' },
    { n: '시장 붐', s: '▲', d: '이번 바퀴에 이 물건 주문은 보상이 1.5배예요.' },
    { n: '우물 마름', s: '◌', d: '이번 바퀴엔 오아시스 칸도 길 깔기에 금 2가 들어요.' },
    { n: '선선한 바람', s: '〰', d: '이번 바퀴엔 모래 칸 길 깔기가 공짜예요.' },
    { n: '통행료 두 배', s: '⨯2', d: '이번 바퀴엔 남의 길 통행료가 칸마다 2예요.' },
    { n: '상인 조합 보조금', s: '+', d: '모두 금 3을 받았어요.' },
    { n: '불볕더위', s: '☀', d: '이번 바퀴엔 한 차례에 길을 2칸까지만 깔 수 있어요.' },
    { n: '대상 축제', s: '♪', d: '이번 바퀴엔 배달할 때마다 금 +3 더 받아요.' },
    { n: '세금 걷기', s: '−', d: '금 20 이상 가진 사람은 금 3을 세금으로 냈어요.' },
    { n: '소나기', s: '☂', d: '협곡이 물에 메워져 이번 바퀴엔 협곡 칸 길 깔기가 금 1이에요.' },
    { n: '새 주문 몰림', s: '✉', d: '공개 주문을 모두 버리고 새로 4장을 깔았어요.' },
    { n: '조용한 하루', s: '·', d: '아무 일도 없어요. 길 깔기 좋은 날!' },
    { n: '오아시스 발견', s: '✿', d: '모래 한 칸이 새 오아시스가 됐어요(길 깔기 공짜).' },
  ];
  const EV_CALM = 12;

  /* ---------- map generation ---------- */
  function genMap(style, nc) {
    const P = { s: { rock: 0.1, can: 1, canL: 5, mnt: 3, oas: 8 }, k: { rock: 0.3, can: 1, canL: 6, mnt: 5, oas: 6 }, c: { rock: 0.14, can: 3, canL: 7, mnt: 4, oas: 6 } }[style];
    for (let tries = 0; tries < 300; tries++) {
      const m = new Array(N).fill('.');
      let rocks = Math.round(N * P.rock);
      while (rocks > 0) {
        let i = U.rand(N); const sz = 2 + U.rand(4);
        for (let k = 0; k < sz && rocks > 0; k++) { if (m[i] === '.') { m[i] = 'r'; rocks--; } const nb = NB[i]; i = nb[U.rand(nb.length)]; }
      }
      for (let c = 0; c < P.can; c++) {
        let i = U.rand(N), d = U.rand(6);
        for (let k = 0; k < P.canL; k++) {
          m[i] = 'c';
          const nd = (d + [0, 0, 1, 5][U.rand(4)]) % 6; const j = NBD[i][nd];
          if (j < 0) break; d = nd; i = j;
        }
      }
      for (let c = 0; c < P.mnt; c++) { let i = U.rand(N); const sz = 1 + U.rand(3); for (let k = 0; k < sz; k++) { m[i] = 'm'; i = NB[i][U.rand(NB[i].length)]; } }
      // cities: inside the edge, ≥3 apart
      const cy = [];
      for (let k = 0; k < 400 && cy.length < nc; k++) {
        const q = 1 + U.rand(W - 2), r = 1 + U.rand(H - 2), i = r * W + q;
        if (cy.every((c) => hd(c, i) >= 3)) cy.push(i);
      }
      if (cy.length < nc) continue;
      for (const c of cy) { m[c] = '*'; for (const j of NB[c]) if (m[j] === 'm') m[j] = '.'; }
      let oas = P.oas;
      for (let k = 0; k < 200 && oas > 0; k++) { const i = U.rand(N); if (m[i] === '.' && NB[i].every((j) => m[j] !== '*')) { m[i] = 'o'; oas--; } }
      // all cities must be reachable through passable hexes
      const seen = new Uint8Array(N), qq = [cy[0]]; seen[cy[0]] = 1;
      while (qq.length) { const i = qq.pop(); for (const j of NB[i]) if (!seen[j] && m[j] !== 'm') { seen[j] = 1; qq.push(j); } }
      if (!cy.every((c) => seen[c])) continue;
      return { m: m.join(''), cy };
    }
    // fallback: plain sand
    const m = new Array(N).fill('.'); const cy = [10, 16, 40, 46, 76, 82, 58, 22].slice(0, nc); cy.forEach((c) => (m[c] = '*'));
    return { m: m.join(''), cy };
  }

  /* ---------- helpers ---------- */
  const isCity = (s, i) => s.m[i] === '*';
  const cityAt = (s, i) => s.cy.indexOf(i);
  function region(s, k) { // storm / bandit region (7 hexes) for the current event
    if (s.ev !== k || s.ep < 0) return null;
    return [s.ep].concat(NB[s.ep]);
  }
  function inReg(reg, i) { return !!reg && reg.indexOf(i) >= 0; }
  function costOf(s, i) {
    const t = s.m[i];
    if (t === '.') return s.ev === 4 ? 0 : 1;
    if (t === 'r') return 2;
    if (t === 'c') return s.ev === 10 ? 1 : 3;
    if (t === 'o') return s.ev === 3 ? 2 : 0;
    return Infinity;
  }
  const maxB = (s) => (s.ev === 7 ? 2 : MAXB);
  const toll = (s) => (s.ev === 5 ? 2 : 1);
  function canBuildOn(s, i, o) { // o: owner string/array to test against (may include planned hexes)
    o = o || s.o;
    if (i < 0 || i >= N) return 0;
    const t = s.m[i];
    if (t === 'm' || t === '*' || o[i] !== '.') return 0;
    if (inReg(region(s, 0), i)) return 0;
    return NB[i].some((j) => s.m[j] === '*' || o[j] !== '.') ? 1 : 0;
  }
  function whyNot(s, i, o) {
    o = o || s.o;
    const t = s.m[i];
    if (t === 'm') return '바위산은 길을 낼 수 없어요';
    if (t === '*') return null;
    if (o[i] !== '.') return '이미 길이 깔린 칸이에요';
    if (inReg(region(s, 0), i)) return '모래폭풍 속이라 이번 바퀴엔 못 깔아요';
    return '길은 도시나 이미 깔린 길에 붙여서만 깔 수 있어요';
  }
  function cardVal(s, card) {
    let v = card[2];
    if (s.ev === 2 && s.ep === card[0]) v = Math.round(v * 1.5);
    if (s.ev === 8) v += 3;
    return v;
  }
  /* Dijkstra (dense, 99 nodes). enter(i) → cost to step onto i (Infinity = blocked) */
  function dj(srcs, enter) {
    const d = new Array(N).fill(Infinity), pr = new Array(N).fill(-1), done = new Uint8Array(N);
    for (const x of srcs) d[x] = 0;
    for (;;) {
      let u = -1, best = Infinity;
      for (let i = 0; i < N; i++) if (!done[i] && d[i] < best) { best = d[i]; u = i; }
      if (u < 0) break;
      done[u] = 1;
      for (const v of NB[u]) { if (done[v]) continue; const c = enter(v); if (c === Infinity) continue; if (d[u] + c < d[v]) { d[v] = d[u] + c; pr[v] = u; } }
    }
    return { d, pr };
  }
  function trace(pr, to) { const p = []; for (let x = to; x >= 0; x = pr[x]) p.push(x); return p.reverse(); }
  const srcsOf = (s, g) => s.cy.filter((c, k) => s.pr[k] === g);
  /* the caravan's real route: only roads & cities; cheapest tolls, then shortest */
  function route(s, seat, card) {
    const storm = region(s, 0), band = region(s, 1), me = String(seat), tl = toll(s);
    const dest = s.cy[card[1]];
    if (inReg(storm, dest)) return null;
    const srcs = srcsOf(s, card[0]).filter((c) => !inReg(storm, c));
    if (!srcs.length) return null;
    const r = dj(srcs, (i) => {
      if (inReg(storm, i)) return Infinity;
      const b = inReg(band, i) ? 3 : 0;
      if (s.m[i] === '*') return 0.001 + b;
      const o = s.o[i];
      if (o === '.') return Infinity;
      return (o === me ? 0 : tl) + 0.001 + b;
    });
    if (r.d[dest] === Infinity) return null;
    return trace(r.pr, dest);
  }
  function payout(s, seat, card, path) {
    const me = String(seat), tl = toll(s), band = region(s, 1), to = {};
    let tt = 0, bd = 0;
    for (const i of path) { const o = s.o[i]; if (o !== '.' && o !== me) { to[o] = (to[o] || 0) + tl; tt += tl; } if (inReg(band, i)) bd = 3; }
    const v = cardVal(s, card);
    return { v, to, tt, bd, net: v - tt - bd };
  }
  function canSend(s, seat, k) {
    if (s.ov || s.sd || !s.mk[k]) return false;
    const p = route(s, seat, s.mk[k]);
    if (!p) return false;
    const pay = payout(s, seat, s.mk[k], p);
    return s.gd[seat] + pay.net >= 0;
  }

  /* ---------- contracts ---------- */
  function mkCard(s) {
    for (let k = 0; k < 12; k++) {
      const g = U.rand(GOODS.length), c = U.rand(s.cy.length);
      if (s.pr[c] === g) continue;
      const srcs = srcsOf(s, g);
      if (!srcs.length) continue;
      const d = Math.min.apply(null, srcs.map((x) => hd(x, s.cy[c])));
      if (d < 3 && k < 8) continue;
      return '' + g + c;
    }
    return '' + s.pr[1] + 0;
  }
  function rewardFor(s, g, c) { const d = Math.min.apply(null, srcsOf(s, g).map((x) => hd(x, s.cy[c]))); return 2 + d; }
  function refill(s) {
    while (s.mk.length < 4) {
      if (!s.dk.length) { s.fin = 1; return; }
      const g = +s.dk[0], c = +s.dk[1]; s.dk = s.dk.slice(2);
      s.mk.push([g, c, rewardFor(s, g, c)]);
    }
  }

  /* ---------- lifecycle ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    let style = opts.map || 'r';
    if (style === 'r') style = 'skc'[U.rand(3)];
    const nc = n >= 4 ? 8 : 7;
    const mp = genMap(style, nc);
    const goods = U.shuffle([0, 1, 2, 3, 4, 5]);
    const pr = mp.cy.map((c, k) => (k < 6 ? goods[k] : U.rand(6)));
    const s = {
      g: U.rand(1e9), n, st: style, nm: players.map((p) => String(p.name || '').slice(0, 8)),
      m: mp.m, o: '.'.repeat(N), cy: mp.cy, cn: U.shuffle(CNAMES.map((_, i) => i)).slice(0, nc), pr,
      gd: players.map((_, i) => START + i), dl: players.map(() => 0), ti: players.map(() => 0),
      t: 0, b: 0, sd: 0, mk: [], dk: '', ev: EV_CALM, ep: -1, ed: '', rd: 1, nd: 1, fin: 0,
      goal: +opts.goal || 80, ov: 0, last: { id: 0, k: 'start' },
    };
    const nCards = 6 + 10 * n;
    let dk = ''; for (let k = 0; k < nCards; k++) dk += mkCard(s);
    s.dk = dk;
    refill(s);
    return s;
  }
  function actor(s) { return s.ov ? null : s.t; }

  function drawEvent(s) {
    if (!s.ed.length) s.ed = U.shuffle(EVENTS.map((_, i) => i.toString(16))).join('');
    const e = parseInt(s.ed[0], 16); s.ed = s.ed.slice(1);
    s.ev = e; s.ep = -1;
    if (e === 0 || e === 1) { // a region centre that is not a city, prefer near roads/cities
      const cand = []; for (let i = 0; i < N; i++) { const q = i % W, r = (i / W) | 0; if (q > 0 && q < W - 1 && r > 0 && r < H - 1 && s.m[i] !== '*') cand.push(i); }
      s.ep = cand[U.rand(cand.length)];
    } else if (e === 2) s.ep = s.mk.length ? s.mk[U.rand(s.mk.length)][0] : U.rand(6);
    else if (e === 6) s.gd = s.gd.map((g) => g + 3);
    else if (e === 9) s.gd = s.gd.map((g) => (g >= 20 ? g - 3 : g));
    else if (e === 11) { s.mk = []; refill(s); }
    else if (e === 13) {
      const cand = []; for (let i = 0; i < N; i++) if (s.m[i] === '.' && s.o[i] === '.') cand.push(i);
      if (cand.length) { const i = cand[U.rand(cand.length)]; s.ep = i; s.m = s.m.slice(0, i) + 'o' + s.m.slice(i + 1); }
    }
  }
  function endCheck(s) { if (s.gd.some((g) => g >= s.goal)) s.fin = 1; }

  function apply(s, seat, a) {
    if (s.ov) throw new Error('끝난 게임');
    if (seat !== s.t) throw new Error('차례 아님');
    const id = (s.last ? s.last.id : 0) + 1;
    if (a.t === 'b') {
      const hs = Array.isArray(a.h) ? a.h : [];
      if (!hs.length) throw new Error('빈 길');
      if (s.b + hs.length > maxB(s)) throw new Error('이번 차례엔 더 못 깔아요');
      const o = s.o.split('');
      let cost = 0;
      for (const i of hs) {
        if (!canBuildOn(s, i, o)) throw new Error('여긴 못 깔아요');
        cost += costOf(s, i); o[i] = String(seat);
      }
      if (cost > s.gd[seat]) throw new Error('금이 모자라요');
      s.o = o.join(''); s.gd[seat] -= cost; s.b += hs.length;
      s.last = { id, k: 'b', s: seat, h: hs.slice(), c: cost };
      return s;
    }
    if (a.t === 's') {
      const k = a.k | 0;
      if (!canSend(s, seat, k)) throw new Error('보낼 수 없어요');
      const card = s.mk[k], path = route(s, seat, card), pay = payout(s, seat, card, path);
      s.gd[seat] += pay.net;
      for (const o in pay.to) { s.gd[+o] += pay.to[o]; s.ti[+o] += pay.to[o]; }
      s.dl[seat]++; s.sd = 1; s.nd = 0;
      s.mk.splice(k, 1); refill(s); endCheck(s);
      s.last = { id, k: 's', s: seat, p: path, g: card[0], c: card[1], v: pay.v, to: pay.to, bd: pay.bd, net: pay.net };
      return s;
    }
    if (a.t === 'e') {
      s.b = 0; s.sd = 0;
      if (s.t < s.n - 1) { s.t++; s.last = { id, k: 'e', s: seat }; return s; }
      // round over
      if (s.fin || s.rd >= MAXR || (!s.mk.length && !s.dk.length)) { s.ov = 1; s.last = { id, k: 'over' }; return s; }
      let dc = -1;
      if (s.nd && s.mk.length) { dc = s.mk[0][0]; s.mk.shift(); refill(s); }
      s.rd++; s.nd = 1; s.t = 0;
      drawEvent(s);
      endCheck(s);
      s.last = { id, k: 'r', ev: s.ev, ep: s.ep, dc };
      return s;
    }
    throw new Error('알 수 없는 행동');
  }
  function rank(s) {
    const ix = s.gd.map((_, i) => i);
    ix.sort((a, b) => s.gd[b] - s.gd[a] || s.dl[b] - s.dl[a]);
    return ix;
  }
  function result(s) {
    if (!s.ov) return null;
    const r = rank(s), b = r[0];
    const w = r.filter((i) => s.gd[i] === s.gd[b] && s.dl[i] === s.dl[b]);
    const lines = r.map((i) => (s.nm[i] || '#' + (i + 1)) + ' 금 ' + s.gd[i] + ' · 배달 ' + s.dl[i] + ' · 통행료 수입 ' + s.ti[i]);
    return { winners: w, text: lines.join('\n'), title: null };
  }

  /* ---------- AI ---------- */
  /* 쉬움: 아무 주문이나 골라 대충 깔고, 통행료·남은 시간 생각 안 함.
     보통: 지금 낼 수 있는 가장 이득인 주문을 골라 가장 싼 길을 계획해서 깔아요.
     어려움: + 남 길 피하기(통행료 아끼기), 많이 다닐 길목 먼저 차지(통행료 수입), 막판엔 길 안 깔고 배달만. */
  let trafCache = { k: '', t: null };
  function traffic(s) { // how many good→city trips pass each hex on cheapest terrain paths
    const key = s.g + s.m;
    if (trafCache.k === key) return trafCache.t;
    const t = new Array(N).fill(0);
    for (let g = 0; g < 6; g++) {
      const srcs = srcsOf(s, g); if (!srcs.length) continue;
      const r = dj(srcs, (i) => (s.m[i] === 'm' ? Infinity : s.m[i] === '*' ? 0.5 : costOf(s, i) + 0.6));
      for (let c = 0; c < s.cy.length; c++) if (s.pr[c] !== g) for (const i of trace(r.pr, s.cy[c])) if (s.m[i] !== '*') t[i]++;
    }
    trafCache = { k: key, t };
    return t;
  }
  function plan(s, seat, card, lv, o) {
    o = o || s.o;
    const storm = region(s, 0), band = region(s, 1), me = String(seat), tl = toll(s);
    const dest = s.cy[card[1]];
    if (inReg(storm, dest)) return null;
    const srcs = srcsOf(s, card[0]).filter((c) => !inReg(storm, c));
    if (!srcs.length) return null;
    const tw = lv >= 3 ? 1.6 : 1, tr = lv >= 3 ? traffic(s) : null;
    const r = dj(srcs, (i) => {
      if (inReg(storm, i)) return Infinity;
      const t = s.m[i];
      if (t === 'm') return Infinity;
      const b = inReg(band, i) ? 3 : 0;
      if (t === '*') return 0.01 + b;
      const ow = o[i];
      if (ow === me) return 0.01 + b;
      if (ow !== '.') return tl * tw + 0.01 + b;
      return costOf(s, i) + 0.6 + b - (tr ? Math.min(0.5, tr[i] * 0.04) : 0);
    });
    if (r.d[dest] === Infinity) return null;
    const path = trace(r.pr, dest);
    const need = [];
    let bc = 0, tt = 0;
    for (const i of path) { const ow = o[i]; if (s.m[i] === '*') continue; if (ow === '.') { need.push(i); bc += costOf(s, i); } else if (ow !== me) tt += tl; }
    return { path, need, bc, tt };
  }
  function orderBuild(s, need, o, max, gold) { // pick buildable hexes in a valid order
    o = o.split ? o.split('') : o.slice();
    const out = []; let left = need.slice(), cost = 0, moved = true;
    while (moved && out.length < max) {
      moved = false;
      for (let k = 0; k < left.length && out.length < max; k++) {
        const i = left[k];
        if (canBuildOn(s, i, o) && cost + costOf(s, i) <= gold) { out.push(i); cost += costOf(s, i); o[i] = 'x'; left.splice(k, 1); k--; moved = true; }
      }
    }
    return out;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const left = maxB(s) - s.b, gold = s.gd[seat];
    const deckLeft = s.dk.length / 2 + s.mk.length;
    const late = s.fin || (lv >= 3 && deckLeft <= s.n * 1.2) || (lv === 2 && deckLeft <= s.n * 0.7);
    // 1) deliveries possible right now
    const now = [];
    if (!s.sd) s.mk.forEach((c, k) => { if (canSend(s, seat, k)) { const p = route(s, seat, c); now.push({ k, net: payout(s, seat, c, p).net }); } });
    if (lv <= 1) {
      const ok = now.filter((x) => x.net > 0);
      ok.sort((a, b) => b.net - a.net);
      if (ok.length && Math.random() < 0.85) return { t: 's', k: ok[Math.random() < 0.5 ? 0 : U.rand(ok.length)].k };
      if (left > 0 && Math.random() < 0.8 && s.mk.length) {
        let c = s.mk[U.rand(s.mk.length)];
        if (Math.random() < 0.6) { let bn = 99; s.mk.forEach((x) => { const q = plan(s, seat, x, 1); if (q && q.need.length && q.need.length < bn) { bn = q.need.length; c = x; } }); }
        const p = plan(s, seat, c, 1);
        if (p && p.need.length) {
          const hs = orderBuild(s, p.need, s.o, 1 + U.rand(left), gold);
          if (hs.length) return { t: 'b', h: hs };
        }
        // or a random cheap neighbour
        const cand = []; for (let i = 0; i < N; i++) if (canBuildOn(s, i) && costOf(s, i) <= Math.min(1, gold)) cand.push(i);
        if (cand.length && Math.random() < 0.5) return { t: 'b', h: [cand[U.rand(cand.length)]] };
      }
      if (ok.length) return { t: 's', k: ok[0].k };
      return { t: 'e' };
    }
    // 2) evaluate every open contract: deliver now, or build this turn then deliver, or long-term target
    const bw = lv >= 3 ? 0.55 : 0.75; // how much a gold spent on roads "hurts" (roads keep earning)
    let best = null;
    for (const x of now) if (x.net > 0 && (!best || x.net > best.sc)) best = { sc: x.net, act: { t: 's', k: x.k } };
    let target = null;
    if (left > 0 && !(late && lv >= 2 && s.fin)) {
      s.mk.forEach((c, k) => {
        const p = plan(s, seat, c, lv); if (!p || !p.need.length) return;
        const v = cardVal(s, c), net = v - p.tt;
        const turns = Math.ceil(p.need.length / MAXB);
        if (!s.sd && p.need.length <= left && p.bc <= gold) {
          const sc = net - p.bc * bw;
          if (sc > 0 && (!best || sc > best.sc)) best = { sc, act: { t: 'b', h: orderBuild(s, p.need, s.o, left, gold) } };
        }
        if (late) return;
        const sc2 = (net - p.bc * bw) / (1 + turns * 0.8) + (lv >= 3 ? p.need.reduce((a, i) => a + traffic(s)[i] * 0.12, 0) : 0);
        if (sc2 > 0 && (!target || sc2 > target.sc)) target = { sc: sc2, p };
      });
    }
    if (best && best.act.t === 'b' && !best.act.h.length) best = null;
    if (best) return best.act;
    if (target) {
      const hs = orderBuild(s, target.p.need, s.o, left, gold - (lv >= 3 ? 0 : 1));
      if (hs.length) return { t: 'b', h: hs };
    }
    // 3) 어려움: spare builds onto busy trade lanes next to the map's roads
    if (lv >= 3 && left > 0 && !late && gold >= 3) {
      const tr = traffic(s); let bi = -1, bs = 0;
      for (let i = 0; i < N; i++) if (canBuildOn(s, i) && costOf(s, i) <= Math.min(2, gold - 2)) { const sc = tr[i] - costOf(s, i) * 1.5; if (sc > bs) { bs = sc; bi = i; } }
      if (bi >= 0 && bs >= 3) return { t: 'b', h: [bi] };
    }
    const ok = now.filter((x) => x.net > 0);
    if (ok.length) return { t: 's', k: ok[0].k };
    return { t: 'e' };
  }
  function aiDelayFor(s, seat, lv) { return 640 + (lv <= 1 ? 200 : lv >= 3 ? -120 : 0); }

  const planRoute = plan;
  /* ---------- view ---------- */
  const TFILL = { '.': '#d6b274', r: '#a88a6a', c: '#9b5c3a', o: '#d6b274', m: '#6a5650', '*': '#e2c98f' };
  function hash(i, k) { let x = (i * 374761393 + k * 668265263) | 0; x = (x ^ (x >>> 13)) * 1274126177; return ((x ^ (x >>> 16)) >>> 0) / 4294967296; }
  const CSS = `
.cv-wrap{position:absolute;inset:0;display:flex;flex-direction:column;background:#17131f;-webkit-user-select:none;user-select:none}
.cv-pl{display:flex;gap:4px;padding:6px 8px 4px;flex:none}
.cv-p{flex:1 1 0;min-width:0;height:48px;border-radius:10px;background:#221c2e;border:1px solid var(--line);padding:3px 6px;display:flex;flex-direction:column;justify-content:center;gap:1px;overflow:hidden;transition:border-color .2s,box-shadow .2s}
.cv-p .nm{font-size:12px;font-weight:700;display:flex;align-items:center;gap:4px;white-space:nowrap;min-width:0;line-height:1.25}
.cv-p .nm .t{overflow:hidden;text-overflow:ellipsis;min-width:0}
.cv-p .nm .dot{flex:none;width:9px;height:9px}
.cv-p .l{font:600 11px var(--f-mono),monospace;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.3}
.cv-p .l b{color:var(--brass);font-size:13px}
.cv-pl.tight .cv-p{padding:3px 4px}.cv-pl.tight .cv-p .l{font-size:10px;letter-spacing:-.3px}
.cv-p.cur{border-color:var(--c);box-shadow:inset 0 0 0 1px var(--c),0 0 12px -4px var(--c)}
.cv-tool{display:flex;gap:6px;padding:0 8px 4px;flex:none;align-items:center}
.cv-ev{appearance:none;flex:1 1 auto;min-width:0;min-height:44px;border-radius:12px;border:1px solid var(--line);background:#2a2133;color:var(--ink);display:flex;align-items:center;gap:7px;padding:3px 10px;cursor:pointer;text-align:left;touch-action:manipulation}
.cv-ev .s{flex:none;width:28px;height:28px;border-radius:8px;background:#5a3a1c;color:#ffd890;display:grid;place-items:center;font-weight:700;font-size:14px}
.cv-ev .tx{min-width:0;display:flex;flex-direction:column;line-height:1.25}
.cv-ev .tx b{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cv-ev .tx span{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cv-ev.hot .s{background:#7c2b1e;color:#ffd2c4}
.cv-ev.good .s{background:#2f5a2c;color:#d8ffc9}
.cv-zb{appearance:none;flex:none;width:44px;height:44px;border-radius:12px;border:1px solid var(--line);background:#221c2e;color:var(--ink);font:700 19px var(--f-mono),monospace;display:grid;place-items:center;padding:0;cursor:pointer;touch-action:manipulation}
.cv-zb:active,.cv-ev:active,.cv-ct:active{transform:scale(.96)}
.cv-map{position:relative;flex:1 1 auto;min-height:120px;overflow:hidden;cursor:grab;touch-action:none;background:radial-gradient(ellipse at 50% 40%,#3a2a20,#1d1620 75%)}
.cv-map.hov{cursor:pointer}
.cv-mk{display:flex;gap:4px;padding:5px 8px 3px;flex:none}
.cv-ct{appearance:none;flex:1 1 0;min-width:0;height:64px;border-radius:10px;border:1px solid rgba(0,0,0,.4);background:#efe1bf;color:#3b2611;padding:0;cursor:pointer;display:flex;flex-direction:column;overflow:hidden;position:relative;box-shadow:0 2px 0 rgba(0,0,0,.35);touch-action:manipulation;text-align:left}
.cv-ct .gd{background:var(--gc);color:#1d130a;font-size:11.5px;font-weight:700;padding:2px 5px;display:flex;gap:3px;align-items:center;white-space:nowrap;overflow:hidden}
.cv-ct .gd.dk{color:#fff;text-shadow:0 1px 1px rgba(0,0,0,.5)}
.cv-ct .to{font-size:12px;font-weight:700;padding:2px 5px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cv-ct .v{font:700 14px var(--f-mono),monospace;padding:0 5px;color:#7a4a0c;display:flex;align-items:center;gap:3px;white-space:nowrap}
.cv-ct .v i{font-style:normal;font-size:10px;color:#fff;background:#c0392b;border-radius:5px;padding:0 3px;font-family:var(--f-body)}
.cv-ct.sel{box-shadow:0 0 0 3px var(--brass),0 2px 0 rgba(0,0,0,.35);transform:translateY(-2px)}
.cv-ct.ok::after{content:'';position:absolute;right:5px;bottom:6px;width:9px;height:9px;border-radius:50%;background:#3fae5a;box-shadow:0 0 0 2px #efe1bf}
.cv-ct.empty{background:transparent;border:1.5px dashed var(--line);box-shadow:none;cursor:default}
.cv-dk{flex:none;width:40px;height:64px;border-radius:10px;background:repeating-linear-gradient(45deg,#5a3a1c 0 6px,#4c3118 6px 12px);border:1px solid rgba(227,174,69,.45);color:#ffd890;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:10.5px;font-weight:700;line-height:1.2}
.cv-dk b{font:700 15px var(--f-mono),monospace}
.cv-bar{display:flex;gap:6px;padding:4px 8px 8px;flex:none;align-items:center;min-height:56px}
.cv-bar .inf{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;line-height:1.3}
.cv-bar .inf b{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cv-bar .inf span{font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cv-bar .inf .pos{color:#8fe0a0}.cv-bar .inf .neg{color:var(--coral)}
.cv-bar .btn{flex:none;padding:8px 11px;font-size:13.5px;min-height:46px}
.cv-bar .btn.pulse{animation:cvp 1.2s ease-in-out infinite}
@keyframes cvp{50%{box-shadow:0 0 0 4px rgba(227,174,69,.35)}}
.cv-bar .btn[disabled]{opacity:.45}
`;
  function mount(root, api) {
    const h = L.h;
    const spd = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'cv-wrap' });
    const plEl = h('div', { class: 'cv-pl' });
    const evBtn = h('button', { class: 'cv-ev', 'aria-label': '이번 바퀴 사건' });
    const zIn = h('button', { class: 'cv-zb', text: '+', 'aria-label': '확대', onclick() { zoomBy(1.4); } });
    const zOut = h('button', { class: 'cv-zb', text: '−', 'aria-label': '축소', onclick() { if (view.z <= 1.01) { view.cx = (MAPB.x0 + MAPB.x1) / 2; view.cy = (MAPB.y0 + MAPB.y1) / 2; clampView(); dirty = true; } else zoomBy(1 / 1.4); } });
    const toolEl = h('div', { class: 'cv-tool' }, evBtn, zOut, zIn);
    const mapEl = h('div', { class: 'cv-map' });
    const mkEl = h('div', { class: 'cv-mk' });
    const barEl = h('div', { class: 'cv-bar' });
    wrap.append(plEl, toolEl, mapEl, mkEl, barEl);
    root.append(style, wrap);
    const cv = U.canvas(mapEl), ctx = cv.ctx;

    let st = null, gid = null, lastId = -1, pending = false, pendT = 0;
    let plan = [], selK = -1, hoverI = -1;
    let car = null, bAnim = null, floats = [];
    let busy = false, busyT = 0, dirty = true;
    const view = { z: 1, cx: (MAPB.x0 + MAPB.x1) / 2, cy: (MAPB.y0 + MAPB.y1) / 2 };
    let T = { k: 1, ox: 0, oy: 0 };
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    function busyFor(ms) { clearTimeout(busyT); setBusy(true); busyT = setTimeout(() => setBusy(false), ms); }

    /* ---------- transform (fit + zoom + pan, with a little slack so edge hexes can be dragged into view) ---------- */
    function fitRect() { return { x: 3, y: 3, w: Math.max(40, cv.w - 6), h: Math.max(40, cv.h - 6) }; }
    function k0() { const F = fitRect(); return Math.min(F.w / (MAPB.x1 - MAPB.x0), F.h / (MAPB.y1 - MAPB.y0)); }
    function clampView() {
      view.z = U.clamp(view.z, 1, 3);
      const F = fitRect(), k = k0() * view.z;
      const hw = F.w / 2 / k, hh = F.h / 2 / k, sl = 1.2;
      const mx = (MAPB.x0 + MAPB.x1) / 2, my = (MAPB.y0 + MAPB.y1) / 2;
      const ex = Math.max(0, (MAPB.x1 - MAPB.x0) / 2 - hw) + sl, ey = Math.max(0, (MAPB.y1 - MAPB.y0) / 2 - hh) + sl;
      view.cx = U.clamp(view.cx, mx - ex, mx + ex); view.cy = U.clamp(view.cy, my - ey, my + ey);
      T = { k, ox: F.x + F.w / 2 - view.cx * k, oy: F.y + F.h / 2 - view.cy * k };
    }
    function zoomBy(f, sx, sy) {
      const F = fitRect();
      if (sx == null) { sx = F.x + F.w / 2; sy = F.y + F.h / 2; }
      const mx = (sx - T.ox) / T.k, my = (sy - T.oy) / T.k;
      view.z = U.clamp(view.z * f, 1, 3);
      const k = k0() * view.z;
      view.cx = mx - (sx - F.x - F.w / 2) / k; view.cy = my - (sy - F.y - F.h / 2) / k;
      clampView(); dirty = true;
    }
    cv.onresize = () => { clampView(); dirty = true; };
    clampView();
    const SX = (i) => T.ox + HX(i) * T.k, SY = (i) => T.oy + HY(i) * T.k;

    /* ---------- state helpers ---------- */
    const P = () => api.players;
    const nm = (i) => (P()[i] ? P()[i].name : (st && st.nm[i]) || '?');
    const col = (i) => (P()[i] ? P()[i].color : '#ccc');
    const cName = (k) => CNAMES[st.cn[k]];
    const myTurn = () => !!st && !st.ov && api.canAct(st.t) && !pending;
    const leftB = () => (st ? maxB(st) - st.b - plan.length : 0);
    const planCost = () => plan.reduce((a, i) => a + costOf(st, i), 0);
    function lockAct(a) { if (pending) return; pending = true; clearTimeout(pendT); pendT = setTimeout(() => { pending = false; renderAll(); }, 2500); api.act(a); }
    function oWithPlan() { const o = st.o.split(''); for (const i of plan) o[i] = String(st.t); return o; }
    function virt() { return Object.assign({}, st, { o: oWithPlan().join('') }); }
    function prune() { // keep only plan hexes that are still valid in order
      if (!st || !myTurn()) { plan = []; return; }
      const o = st.o.split(''), out = []; let c = 0;
      for (const i of plan) { if (out.length < maxB(st) - st.b && canBuildOn(st, i, o) && c + costOf(st, i) <= st.gd[st.t]) { out.push(i); o[i] = String(st.t); c += costOf(st, i); } }
      plan = out;
    }
    /* preview for the selected order: real route (with my plan counted as mine) or the suggested route to build */
    function preview() {
      if (!st || selK < 0 || !st.mk[selK]) return null;
      const seat = myTurn() ? st.t : (api.canAct(st.t) ? st.t : Math.max(0, P().findIndex((p) => p && p.local && !p.ai)));
      const sv = plan.length ? virt() : st, card = st.mk[selK];
      const p = route(sv, seat, card);
      if (p) { const pay = payout(sv, seat, card, p); return { ok: 1, path: p, pay, seat, needPlan: plan.length > 0 && !route(st, seat, card) }; }
      const q = planRoute(sv, seat, card, 2);
      return q ? { ok: 0, path: q.path, need: q.need, bc: q.bc, tt: q.tt, v: cardVal(st, card), seat } : { ok: 0, path: null, seat };
    }

    /* ---------- drawing ---------- */
    function hexPath(x, y, r) {
      ctx.beginPath();
      for (let k = 0; k < 6; k++) { const a = Math.PI / 180 * (60 * k - 90); const px = x + r * Math.cos(a), py = y + r * Math.sin(a); if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
      ctx.closePath();
    }
    function drawTerrain(i, x, y, k) {
      const t = st.m[i];
      hexPath(x, y, k * 0.985);
      const base = TFILL[t];
      const g = ctx.createLinearGradient(x, y - k, x, y + k);
      g.addColorStop(0, shade(base, 14 + hash(i, 1) * 8)); g.addColorStop(1, shade(base, -14));
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(70,40,15,.35)'; ctx.lineWidth = 1; ctx.stroke();
      if (t === '.' || t === 'o') { // dune ripples
        ctx.strokeStyle = 'rgba(140,95,40,.28)'; ctx.lineWidth = Math.max(1, k * 0.06);
        for (let d = 0; d < 2; d++) { const yy = y - k * 0.3 + d * k * 0.45 + hash(i, d) * k * 0.15, xx = x - k * 0.45 + hash(i, d + 3) * k * 0.2; ctx.beginPath(); ctx.moveTo(xx, yy); ctx.quadraticCurveTo(xx + k * 0.3, yy - k * 0.16, xx + k * 0.65, yy); ctx.stroke(); }
      }
      if (t === 'r') {
        for (let d = 0; d < 3; d++) { const xx = x + (hash(i, d) - 0.5) * k * 0.9, yy = y + (hash(i, d + 5) - 0.5) * k * 0.8, rr = k * (0.14 + hash(i, d + 9) * 0.12); ctx.fillStyle = '#7d634d'; ctx.beginPath(); ctx.ellipse(xx, yy, rr * 1.2, rr, 0, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,240,210,.25)'; ctx.beginPath(); ctx.ellipse(xx - rr * 0.3, yy - rr * 0.3, rr * 0.5, rr * 0.35, 0, 0, 7); ctx.fill(); }
      }
      if (t === 'c') {
        ctx.strokeStyle = '#4a2414'; ctx.lineWidth = Math.max(1.5, k * 0.16); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(x - k * 0.6, y - k * 0.2); ctx.lineTo(x - k * 0.15, y + k * 0.1); ctx.lineTo(x + k * 0.2, y - k * 0.1); ctx.lineTo(x + k * 0.6, y + k * 0.25); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,200,150,.25)'; ctx.lineWidth = Math.max(1, k * 0.05); ctx.stroke();
      }
      if (t === 'o') {
        ctx.fillStyle = '#3d9ec4'; ctx.beginPath(); ctx.ellipse(x, y + k * 0.2, k * 0.42, k * 0.22, 0, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(x - k * 0.12, y + k * 0.15, k * 0.15, k * 0.06, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = '#6b4a2a'; ctx.lineWidth = Math.max(1, k * 0.07); ctx.beginPath(); ctx.moveTo(x + k * 0.3, y + k * 0.05); ctx.quadraticCurveTo(x + k * 0.35, y - k * 0.3, x + k * 0.25, y - k * 0.5); ctx.stroke();
        ctx.fillStyle = '#3f8a3a';
        for (let d = 0; d < 4; d++) { const a = -Math.PI / 2 + (d - 1.5) * 0.8; ctx.beginPath(); ctx.ellipse(x + k * 0.25 + Math.cos(a) * k * 0.2, y - k * 0.5 + Math.sin(a) * k * 0.1 + k * 0.05, k * 0.22, k * 0.07, a, 0, 7); ctx.fill(); }
      }
      if (t === 'm') {
        ctx.fillStyle = '#4f3f3b'; ctx.beginPath(); ctx.moveTo(x - k * 0.7, y + k * 0.45); ctx.lineTo(x - k * 0.1, y - k * 0.55); ctx.lineTo(x + k * 0.25, y - k * 0.05); ctx.lineTo(x + k * 0.4, y - k * 0.3); ctx.lineTo(x + k * 0.75, y + k * 0.45); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,240,220,.35)'; ctx.beginPath(); ctx.moveTo(x - k * 0.1, y - k * 0.55); ctx.lineTo(x + k * 0.05, y - k * 0.25); ctx.lineTo(x - k * 0.25, y - k * 0.3); ctx.closePath(); ctx.fill();
      }
    }
    function shade(hex, amt) {
      const n = parseInt(hex.slice(1), 16);
      const f = (v) => Math.max(0, Math.min(255, Math.round(v + amt)));
      return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
    }
    function drawRoads(k, hideH) {
      const linkOK = (j) => j >= 0 && (st.m[j] === '*' || (st.o[j] !== '.' && !(hideH && hideH.indexOf(j) >= 0)));
      ctx.lineCap = 'round';
      for (let pass = 0; pass < 2; pass++) {
        for (let i = 0; i < N; i++) {
          const ow = st.o[i]; if (ow === '.' || (hideH && hideH.indexOf(i) >= 0)) continue;
          const x = SX(i), y = SY(i);
          if (pass === 0) { hexPath(x, y, k * 0.9); ctx.fillStyle = col(+ow) + '33'; ctx.fill(); }
          for (const j of NB[i]) {
            if (!linkOK(j)) continue;
            const mx = (x + SX(j)) / 2, my = (y + SY(j)) / 2;
            ctx.strokeStyle = pass === 0 ? 'rgba(30,18,10,.65)' : col(+ow);
            ctx.lineWidth = pass === 0 ? k * 0.36 + 3 : k * 0.36;
            ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(mx, my); ctx.stroke();
          }
          if (pass === 1) {
            ctx.fillStyle = col(+ow); ctx.beginPath(); ctx.arc(x, y, k * 0.24, 0, 7); ctx.fill();
            ctx.strokeStyle = 'rgba(30,18,10,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = 'rgba(255,245,220,.6)'; ctx.beginPath(); ctx.arc(x, y, k * 0.08, 0, 7); ctx.fill();
          }
        }
      }
    }
    function drawCity(ci, k) {
      const i = st.cy[ci], x = SX(i), y = SY(i), g = st.pr[ci];
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(x, y + k * 0.5, k * 0.65, k * 0.2, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#f0dfb2'; ctx.strokeStyle = '#8a5a22'; ctx.lineWidth = Math.max(1.5, k * 0.08);
      ctx.beginPath(); ctx.rect(x - k * 0.55, y - k * 0.15, k * 1.1, k * 0.6); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y - k * 0.15, k * 0.34, Math.PI, 0); ctx.closePath(); ctx.fillStyle = '#e8b85c'; ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#6b4416'; ctx.fillRect(x - k * 0.1, y + k * 0.12, k * 0.2, k * 0.33);
      // good badge
      const bx = x + k * 0.55, by = y - k * 0.5, br = Math.max(7, k * 0.3);
      ctx.fillStyle = GCOL[g]; ctx.strokeStyle = '#2a1a0c'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(bx, by, br, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = g === 2 || g === 5 ? '#2a1a0c' : '#fff'; ctx.font = '700 ' + Math.round(br * 1.1) + 'px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(GSH[g], bx, by + 0.5);
      // name
      const fs = Math.max(10, Math.min(14, k * 0.48));
      ctx.font = '700 ' + fs + 'px "IBM Plex Sans KR",sans-serif';
      const tw = ctx.measureText(cName(ci)).width + 8, ly = y + k * 0.78;
      ctx.fillStyle = 'rgba(28,18,12,.82)'; rr(x - tw / 2, ly - fs * 0.62, tw, fs * 1.3, 5); ctx.fill();
      ctx.fillStyle = '#ffe9b8'; ctx.fillText(cName(ci), x, ly + 0.5);
    }
    function rr(x, y, w, hh, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, hh, r); else ctx.rect(x, y, w, hh); }
    function camel(x, y, dir, ph, c, sc) {
      ctx.save(); ctx.translate(x, y); ctx.scale(dir * sc, sc);
      ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(0, 1.02, 1.0, 0.18, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#8a5a2e'; ctx.lineWidth = 0.2; ctx.lineCap = 'round';
      const sw = Math.sin(ph) * 0.28;
      [[-0.55, sw], [-0.35, -sw], [0.45, -sw], [0.65, sw]].forEach(([lx, o]) => { ctx.beginPath(); ctx.moveTo(lx, 0.2); ctx.lineTo(lx + o, 1.0); ctx.stroke(); });
      ctx.fillStyle = '#c99556';
      ctx.beginPath(); ctx.ellipse(0, 0, 0.92, 0.42, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(-0.1, -0.38, 0.46, 0.36, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#c99556'; ctx.lineWidth = 0.3; ctx.beginPath(); ctx.moveTo(0.7, -0.05); ctx.lineTo(1.08, -0.72); ctx.stroke();
      ctx.beginPath(); ctx.ellipse(1.22, -0.8, 0.3, 0.17, 0.2, 0, 7); ctx.fill();
      ctx.fillStyle = c; ctx.fillRect(-0.48, -0.42, 0.78, 0.42);
      ctx.fillStyle = 'rgba(255,240,200,.85)'; ctx.fillRect(-0.48, -0.06, 0.78, 0.08);
      ctx.fillStyle = '#2a1a0c'; ctx.beginPath(); ctx.arc(1.3, -0.85, 0.05, 0, 7); ctx.fill();
      ctx.restore();
    }
    function polyAt(pts, d) { // pts: [[x,y]...] in map units, d distance along
      for (let k = 1; k < pts.length; k++) {
        const a = pts[k - 1], b = pts[k], l = Math.hypot(b[0] - a[0], b[1] - a[1]);
        if (d <= l || k === pts.length - 1) { const f = U.clamp(d / (l || 1), 0, 1); return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, Math.sign(b[0] - a[0]) || 1, k - 1 + f]; }
        d -= l;
      }
      const z = pts[pts.length - 1]; return [z[0], z[1], 1, pts.length - 1];
    }
    function draw(now) {
      ctx.clearRect(0, 0, cv.w, cv.h);
      if (!st) return;
      const k = T.k;
      for (let i = 0; i < N; i++) drawTerrain(i, SX(i), SY(i), k);
      // event regions
      const storm = region(st, 0), band = region(st, 1);
      if (storm) for (const i of storm) {
        const x = SX(i), y = SY(i); hexPath(x, y, k * 0.96); ctx.fillStyle = 'rgba(120,80,40,.55)'; ctx.fill();
        ctx.strokeStyle = 'rgba(255,225,170,.55)'; ctx.lineWidth = Math.max(1, k * 0.06);
        const sp = now / 900;
        for (let d = 0; d < 2; d++) { ctx.beginPath(); ctx.arc(x, y, k * (0.25 + d * 0.25), sp + d * 2 + i, sp + d * 2 + i + 3.6); ctx.stroke(); }
      }
      if (band) for (const i of band) {
        const x = SX(i), y = SY(i); hexPath(x, y, k * 0.86); ctx.setLineDash([4, 3]); ctx.strokeStyle = '#e04a3a'; ctx.lineWidth = 2; ctx.stroke(); ctx.setLineDash([]);
        if (i === st.ep) { ctx.fillStyle = '#e04a3a'; ctx.font = '700 ' + Math.round(k * 0.7) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('⚔', x, y); }
      }
      const hideH = bAnim ? bAnim.h : null;
      drawRoads(k, hideH);
      // build animation: roads appear with a brass ring
      if (bAnim) {
        const f = U.clamp((now - bAnim.t0) / bAnim.dur, 0, 1);
        for (const i of bAnim.h) {
          const x = SX(i), y = SY(i);
          ctx.fillStyle = col(bAnim.s); ctx.globalAlpha = f; ctx.beginPath(); ctx.arc(x, y, k * 0.24 * (0.4 + 0.6 * f), 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          ctx.strokeStyle = 'rgba(227,174,69,' + (1 - f) + ')'; ctx.lineWidth = 3; hexPath(x, y, k * (0.5 + 0.6 * f)); ctx.stroke();
        }
      }
      // buildable hints + plan
      const mine = myTurn() && !car;
      if (mine && leftB() > 0) {
        const o = oWithPlan(), gold = st.gd[st.t] - planCost();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '700 ' + Math.round(Math.max(10, k * 0.46)) + 'px "IBM Plex Mono",monospace';
        for (let i = 0; i < N; i++) {
          if (!canBuildOn(st, i, o)) continue;
          const c = costOf(st, i), x = SX(i), y = SY(i), aff = c <= gold;
          hexPath(x, y, k * 0.82); ctx.strokeStyle = aff ? 'rgba(255,226,150,.85)' : 'rgba(255,226,150,.3)'; ctx.lineWidth = i === hoverI ? 3 : 1.5; ctx.setLineDash([3, 3]); ctx.stroke(); ctx.setLineDash([]);
          ctx.fillStyle = aff ? 'rgba(40,24,10,.75)' : 'rgba(40,24,10,.35)'; ctx.beginPath(); ctx.arc(x, y, Math.max(7, k * 0.3), 0, 7); ctx.fill();
          ctx.fillStyle = aff ? '#ffe2a0' : 'rgba(255,226,160,.5)'; ctx.fillText(String(c), x, y + 0.5);
        }
      }
      if (plan.length) {
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        plan.forEach((i, n) => {
          const x = SX(i), y = SY(i);
          hexPath(x, y, k * 0.86); ctx.fillStyle = 'rgba(227,174,69,.45)'; ctx.fill(); ctx.strokeStyle = '#ffd36a'; ctx.lineWidth = 3; ctx.stroke();
          ctx.fillStyle = col(st.t); ctx.beginPath(); ctx.arc(x, y, Math.max(8, k * 0.32), 0, 7); ctx.fill(); ctx.strokeStyle = '#2a1a0c'; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.fillStyle = '#fff'; ctx.font = '700 ' + Math.round(Math.max(10, k * 0.42)) + 'px "IBM Plex Mono",monospace'; ctx.fillText(String(n + 1), x, y + 0.5);
        });
      }
      // order preview
      const pv = !car ? preview() : null;
      if (pv && pv.path) {
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath(); pv.path.forEach((i, n) => { if (n) ctx.lineTo(SX(i), SY(i)); else ctx.moveTo(SX(i), SY(i)); });
        if (pv.ok) { ctx.strokeStyle = 'rgba(255,240,190,.35)'; ctx.lineWidth = k * 0.5; ctx.stroke(); ctx.strokeStyle = '#fff3c4'; ctx.lineWidth = Math.max(2.5, k * 0.13); ctx.stroke(); }
        else { ctx.setLineDash([6, 5]); ctx.strokeStyle = '#fff3c4'; ctx.lineWidth = Math.max(2, k * 0.1); ctx.stroke(); ctx.setLineDash([]); }
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const me = String(pv.seat), tl = toll(st), o = plan.length ? oWithPlan() : st.o;
        for (const i of pv.path) {
          const ow = o[i];
          if (ow !== '.' && ow !== me && st.m[i] !== '*') { // toll coin
            const x = SX(i) + k * 0.35, y = SY(i) - k * 0.35, r = Math.max(8, k * 0.28);
            ctx.fillStyle = '#f2c14e'; ctx.strokeStyle = '#7a4a0c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke();
            ctx.fillStyle = '#5a3206'; ctx.font = '700 ' + Math.round(r * 1.15) + 'px "IBM Plex Mono",monospace'; ctx.fillText(String(tl), x, y + 0.5);
          } else if (!pv.ok && ow === '.' && st.m[i] !== '*') {
            hexPath(SX(i), SY(i), k * 0.7); ctx.setLineDash([3, 3]); ctx.strokeStyle = '#fff3c4'; ctx.lineWidth = 2; ctx.stroke(); ctx.setLineDash([]);
          }
        }
      }
      for (let ci = 0; ci < st.cy.length; ci++) drawCity(ci, k);
      if (pv && pv.path) { // mark start/end
        const a = pv.path[0], b = pv.path[pv.path.length - 1];
        ctx.strokeStyle = '#fff3c4'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(SX(a), SY(a), k * 0.85, 0, 7); ctx.stroke();
        ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.arc(SX(b), SY(b), k * 0.85, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      // caravan
      if (car) {
        const d = Math.min(car.len, (now - car.t0) / 1000 * car.v);
        for (let c = 2; c >= 0; c--) {
          const dd = Math.max(0, d - c * 0.8), q = polyAt(car.pts, dd);
          camel(T.ox + q[0] * k, T.oy + q[1] * k - k * 0.2, q[2], (now / 1000) * 9 * spd() + c * 1.3, c === 0 ? col(car.s) : shade(col(car.s).length === 7 ? col(car.s) : '#888888', -25), Math.max(5, k * 0.33));
          if (c === 0) {
            const hi = Math.floor(q[3] + 0.5);
            while (car.fired < hi && car.fired < car.path.length - 1) { car.fired++; const i = car.path[car.fired], ow = st.o[i]; if (car.to[ow] && ow !== String(car.s) && st.m[i] !== '*') floats.push({ x: HX(i), y: HY(i), t: '+' + toll(st), c: col(+ow), t0: now }); }
          }
        }
        if (d >= car.len && !car.done) {
          car.done = true;
          const e = car.path[car.path.length - 1];
          floats.push({ x: HX(e), y: HY(e) - 0.4, t: (car.net >= 0 ? '+' : '') + car.net, c: '#ffd36a', t0: now, big: 1 });
          if (car.bd) floats.push({ x: HX(e) + 0.6, y: HY(e) + 0.4, t: '도적 −' + car.bd, c: '#ff8a7a', t0: now });
          api.sfx('chip');
          setTimeout(() => { car = null; dirty = true; setBusy(false); renderAll(); }, 380 / spd());
        }
      }
      // floating texts
      if (floats.length) {
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        floats = floats.filter((f) => now - f.t0 < 1300 / Math.min(2, spd()));
        for (const f of floats) {
          const a = (now - f.t0) / (1300 / Math.min(2, spd()));
          const x = T.ox + f.x * k, y = T.oy + (f.y - 0.6 - a * 0.8) * k;
          ctx.globalAlpha = 1 - a * a; ctx.font = '700 ' + (f.big ? 20 : 14) + 'px "IBM Plex Mono",monospace';
          ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(20,12,6,.85)'; ctx.strokeText(f.t, x, y); ctx.fillStyle = f.c; ctx.fillText(f.t, x, y);
          ctx.globalAlpha = 1;
        }
      }
    }
    const stopLoop = U.loop((dt, now) => {
      if (bAnim && now - bAnim.t0 > bAnim.dur) { bAnim = null; dirty = true; }
      const live = car || bAnim || floats.length || (st && st.ev === 0 && !st.ov);
      if (!dirty && !live) return;
      dirty = false; draw(now);
    });

    /* ---------- DOM parts ---------- */
    function renderPlayers() {
      plEl.textContent = '';
      plEl.classList.toggle('tight', st.n >= 4);
      for (let i = 0; i < st.n; i++) {
        const el = h('div', { class: 'cv-p' + (i === st.t && !st.ov ? ' cur' : ''), style: { '--c': col(i) } },
          h('div', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { class: 't', text: nm(i) })));
        const l = h('div', { class: 'l' });
        l.innerHTML = '금 <b>' + st.gd[i] + '</b>' + (st.n >= 4 ? ' · ' + st.dl[i] + '회' : ' · 배달 ' + st.dl[i]);
        el.append(l); plEl.append(el);
      }
    }
    function renderTool() {
      const E = EVENTS[st.ev];
      let sub = E.d;
      if (st.ev === 2 && st.ep >= 0) sub = GOODS[st.ep] + ' 주문 보상 1.5배';
      evBtn.className = 'cv-ev' + ([0, 1, 5, 7, 9].indexOf(st.ev) >= 0 ? ' hot' : [2, 4, 6, 8, 10, 13].indexOf(st.ev) >= 0 ? ' good' : '');
      evBtn.textContent = '';
      evBtn.append(h('span', { class: 's', text: E.s }), h('span', { class: 'tx' },
        h('b', { text: st.rd + '바퀴' + (st.fin ? '(마지막)' : '') + ' · 목표 금 ' + st.goal }), h('span', { text: E.n + ' — ' + sub })));
    }
    function renderMarket() {
      mkEl.textContent = '';
      const me = myTurn() ? st.t : -1;
      for (let k = 0; k < 4; k++) {
        const c = st.mk[k];
        if (!c) { mkEl.append(h('div', { class: 'cv-ct empty' })); continue; }
        const boom = st.ev === 2 && st.ep === c[0], v = cardVal(st, c);
        const ok = me >= 0 && !st.sd && canSend(st, me, k);
        const el = h('button', { class: 'cv-ct' + (selK === k ? ' sel' : '') + (ok ? ' ok' : ''), style: { '--gc': GCOL[c[0]] }, 'aria-label': GOODS[c[0]] + ' 주문' },
          h('div', { class: 'gd' + ([0, 1, 3, 4].indexOf(c[0]) >= 0 ? ' dk' : '') }, h('span', { text: GSH[c[0]] }), h('span', { text: GOODS[c[0]] })),
          h('div', { class: 'to', text: '→ ' + cName(c[1]) }),
          h('div', { class: 'v' }, h('span', { text: '금 ' + v }), boom ? h('i', { text: '붐' }) : st.ev === 8 ? h('i', { text: '+3' }) : null));
        el.onclick = () => { selK = selK === k ? -1 : k; api.sfx('click'); renderAll(); };
        mkEl.append(el);
      }
      mkEl.append(h('div', { class: 'cv-dk' }, h('span', { text: '주문' }), h('b', { text: String(st.dk.length / 2) }), h('span', { text: '장' })));
    }
    function btn(text, cls, fn, dis) { const b = h('button', { class: 'btn ' + (cls || ''), text }); if (dis) b.disabled = true; else b.onclick = fn; return b; }
    function renderBar() {
      barEl.textContent = '';
      const inf = h('div', { class: 'inf' });
      barEl.append(inf);
      const line = (t, cls) => { const s = h(cls === 'b' ? 'b' : 'span'); if (Array.isArray(t)) t.forEach((x) => s.append(x)); else s.textContent = t; return s; };
      if (st.ov) { inf.append(line('게임 끝!', 'b'), line('금이 가장 많은 사람이 이겨요')); return; }
      const mine = myTurn();
      const pv = preview();
      if (!mine) {
        inf.append(line(nm(st.t) + ' 차례' + (P()[st.t] && P()[st.t].ai ? '… 생각 중' : ''), 'b'), line(pv && pv.path ? previewText(pv) : '주문을 눌러 대상 길을 미리 볼 수 있어요'));
        return;
      }
      const left = maxB(st) - st.b;
      if (plan.length) {
        const c = planCost();
        inf.append(line('길 ' + plan.length + '칸 계획 · 금 ' + c, 'b'), line(pv && pv.ok && pv.needPlan ? '깔고 나면 이 주문을 보낼 수 있어요' : '칸을 다시 누르면 빼요 · 남은 짓기 ' + (left - plan.length) + '칸'));
        barEl.append(btn('취소', 'ghost', () => { plan = []; api.sfx('click'); renderAll(); }),
          btn('길 깔기 · 금 ' + c, 'primary', () => { const hs = plan.slice(); plan = []; api.buzz(12); lockAct({ t: 'b', h: hs }); }));
        return;
      }
      if (pv) {
        const c = st.mk[selK];
        inf.append(line(GOODS[c[0]] + ' → ' + cName(c[1]), 'b'), line(previewText(pv)));
        if (pv.ok) barEl.append(btn(st.sd ? '이번 차례 보냄' : '대상 보내기', st.sd ? '' : 'primary', () => { const kk = selK; selK = -1; api.buzz(15); lockAct({ t: 's', k: kk }); }, st.sd || !canSend(st, st.t, selK)));
        else if (pv.path && left > 0) barEl.append(btn('추천 길 넣기', '', () => { autoPlan(pv); }));
        barEl.append(btn('차례 끝', st.sd && left <= 0 ? 'primary pulse' : '', endTurn));
        return;
      }
      inf.append(line('짓기 ' + st.b + '/' + maxB(st) + '칸 · 배달 ' + (st.sd ? '1/1' : '0/1'), 'b'),
        line(left > 0 && !st.sd ? '빛나는 칸을 눌러 길 계획 · 주문 카드로 대상 보내기' : left > 0 ? '길을 더 깔거나 차례를 끝내요' : st.sd ? '할 일을 다 했어요' : '주문 카드를 골라 대상을 보내요'));
      barEl.append(btn('차례 끝', (st.sd && left <= 0) || (left <= 0 && !st.mk.some((_, k) => canSend(st, st.t, k))) ? 'primary pulse' : '', endTurn));
    }
    function previewText(pv) {
      const sp = (t, c) => h('span', { class: c, text: t });
      if (!pv.path) return '지금은 이을 수 있는 길이 없어요(폭풍·산)';
      if (pv.ok) {
        const p = pv.pay, parts = ['보상 ' + p.v];
        if (p.tt) parts.push('통행료 −' + p.tt);
        if (p.bd) parts.push('도적 −' + p.bd);
        return [parts.join(' · ') + ' → ', sp((p.net >= 0 ? '+' : '') + p.net, p.net >= 0 ? 'pos' : 'neg')];
      }
      return '길 ' + pv.need.length + '칸 더 필요 (금 약 ' + pv.bc + ') · 보상 ' + pv.v + (pv.tt ? ' · 통행료 ' + pv.tt : '');
    }
    function autoPlan(pv) {
      const o = oWithPlan(); let c = planCost();
      const gold = st.gd[st.t]; let added = 0;
      let moved = true;
      const need = pv.need.filter((i) => plan.indexOf(i) < 0);
      while (moved && leftB() > 0) {
        moved = false;
        for (let n = 0; n < need.length && leftB() > 0; n++) {
          const i = need[n];
          if (canBuildOn(st, i, o) && c + costOf(st, i) <= gold) { plan.push(i); o[i] = String(st.t); c += costOf(st, i); need.splice(n, 1); n--; moved = true; added++; }
        }
      }
      if (!added) api.toast(c + 1 > gold ? '금이 모자라요' : '이번 차례엔 더 못 깔아요');
      else api.sfx('pop');
      renderAll();
    }
    function endTurn() {
      if (!myTurn()) return;
      plan = []; selK = -1; api.sfx('click'); lockAct({ t: 'e' });
    }
    function renderAll() {
      if (!st) return;
      if (selK >= 0 && !st.mk[selK]) selK = -1;
      prune();
      renderPlayers(); renderTool(); renderMarket(); renderBar();
      dirty = true;
    }
    evBtn.onclick = () => { if (!st) return; const E = EVENTS[st.ev]; api.toast(E.n + ': ' + (st.ev === 2 && st.ep >= 0 ? GOODS[st.ep] + ' 주문 보상 1.5배' : E.d)); };

    /* ---------- events from state ---------- */
    function onEvent(ev, prev) {
      if (ev.k === 'b') {
        api.sfx('thud'); if (api.canAct(ev.s)) api.buzz(12);
        bAnim = { h: ev.h, s: ev.s, t0: performance.now(), dur: 420 / spd() };
        busyFor(440 / spd());
      } else if (ev.k === 's') {
        const pts = ev.p.map((i) => [HX(i), HY(i)]);
        let len = 0; for (let n = 1; n < pts.length; n++) len += Math.hypot(pts[n][0] - pts[n - 1][0], pts[n][1] - pts[n - 1][1]);
        const v = 3.2 * spd() * (len > 14 ? len / 14 : 1);
        car = { pts, len, v, t0: performance.now(), s: ev.s, path: ev.p, to: ev.to || {}, net: ev.net, bd: ev.bd, fired: 0, done: false };
        clearTimeout(busyT); setBusy(true);
        busyT = setTimeout(() => { if (car) { car = null; dirty = true; renderAll(); } setBusy(false); }, (len / v) * 1000 + 1500);
        api.sfx('whoosh');
      } else if (ev.k === 'r') {
        const E = EVENTS[ev.ev];
        const fin = prev && !prev.fin && st.fin ? '마지막 바퀴! ' : '';
        api.toast(fin + st.rd + '바퀴 · ' + E.n + (ev.ev === 2 && ev.ep >= 0 ? ' — ' + GOODS[ev.ep] + ' 보상 1.5배' : ''));
        if (ev.dc >= 0) setTimeout(() => { if (st && st.last && st.last.id === ev.id) api.toast('아무도 배달 안 해서 주문 하나가 사라졌어요'); }, 1600);
        api.sfx(ev.ev === 0 || ev.ev === 1 ? 'thud' : 'pop');
        busyFor(500 / spd());
      }
      if (ev.k !== 'r' && prev && !prev.fin && st.fin && !st.ov) setTimeout(() => api.toast('마지막 바퀴! 이 바퀴가 끝나면 게임 끝'), ev.k === 's' ? 900 / spd() : 0);
      renderAll();
    }

    /* ---------- pointer: tap a hex, drag to pan, pinch / wheel to zoom ---------- */
    const pts = new Map();
    let drag = null, pinch = null;
    function hitHex(x, y) {
      const mx = (x - T.ox) / T.k, my = (y - T.oy) / T.k;
      let best = -1, bd = 1.0;
      for (let i = 0; i < N; i++) { const d = Math.hypot(HX(i) - mx, HY(i) - my); if (d < bd) { bd = d; best = i; } }
      return best;
    }
    function tapHex(i) {
      if (!st || i < 0) return;
      const ci = cityAt(st, i);
      if (ci >= 0) { api.toast(cName(ci) + ' — ' + GOODS[st.pr[ci]] + '을(를) 내놓는 도시'); return; }
      if (myTurn() && !car) {
        const pi = plan.indexOf(i);
        if (pi >= 0) { plan.splice(pi, 1); prune(); api.sfx('tick'); renderAll(); return; }
        const o = oWithPlan();
        if (!canBuildOn(st, i, o)) { if (st.o[i] !== '.') api.toast(st.o[i] === String(st.t) ? '내 길이에요' : nm(+st.o[i]) + '의 길 — 지나가면 통행료 ' + toll(st)); else api.toast(whyNot(st, i, o)); return; }
        if (leftB() <= 0) { api.toast('한 차례에 ' + maxB(st) + '칸까지 깔 수 있어요'); return; }
        if (planCost() + costOf(st, i) > st.gd[st.t]) { api.toast('금이 모자라요'); return; }
        plan.push(i); api.sfx('tick'); api.buzz(8); renderAll(); return;
      }
      const t = st.m[i];
      if (st.o[i] !== '.') api.toast(nm(+st.o[i]) + '의 길 — 남이 지나가면 통행료 ' + toll(st));
      else api.toast(TERR[t] + (t === 'm' ? ' — 길을 낼 수 없어요' : ' — 길 깔기 금 ' + costOf(st, i)));
    }
    function onDown(e) {
      const p = cv.local(e);
      pts.set(e.pointerId, p);
      try { mapEl.setPointerCapture(e.pointerId); } catch (er) { /* ignore */ }
      if (pts.size === 1) drag = { x: p.x, y: p.y, cx: view.cx, cy: view.cy, moved: false };
      else if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, z: view.z }; if (drag) drag.moved = true; }
    }
    function onMove(e) {
      const p = cv.local(e);
      if (!pts.has(e.pointerId)) {
        if (e.pointerType === 'mouse' && myTurn()) { const i = hitHex(p.x, p.y); const ok = i >= 0 && st && canBuildOn(st, i, oWithPlan()); const hv = ok ? i : -1; if (hv !== hoverI) { hoverI = hv; mapEl.classList.toggle('hov', hv >= 0); dirty = true; } }
        return;
      }
      pts.set(e.pointerId, p);
      if (pinch && pts.size >= 2) { const [a, b] = [...pts.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y) || 1; zoomBy((pinch.z * d / pinch.d) / view.z, (a.x + b.x) / 2, (a.y + b.y) / 2); return; }
      if (drag) {
        if (!drag.moved && Math.hypot(p.x - drag.x, p.y - drag.y) > 8) drag.moved = true;
        if (drag.moved) { view.cx = drag.cx - (p.x - drag.x) / T.k; view.cy = drag.cy - (p.y - drag.y) / T.k; clampView(); dirty = true; }
      }
    }
    function onUp(e) {
      const p = cv.local(e);
      const had = pts.delete(e.pointerId);
      if (pts.size < 2) pinch = null;
      if (!had) return;
      if (pts.size === 0) { if (drag && !drag.moved && e.type === 'pointerup') tapHex(hitHex(p.x, p.y)); drag = null; }
      else if (pts.size === 1) { const q = [...pts.values()][0]; drag = { x: q.x, y: q.y, cx: view.cx, cy: view.cy, moved: true }; }
    }
    function onWheel(e) { e.preventDefault(); const p = cv.local(e); zoomBy(e.deltaY < 0 ? 1.18 : 1 / 1.18, p.x, p.y); }
    function onLeave() { if (hoverI >= 0) { hoverI = -1; mapEl.classList.remove('hov'); dirty = true; } }
    function onKey(e) {
      if (e.key === 'Escape' && (plan.length || selK >= 0)) { e.preventDefault(); plan = []; selK = -1; renderAll(); }
    }
    mapEl.addEventListener('pointerdown', onDown);
    mapEl.addEventListener('pointermove', onMove);
    mapEl.addEventListener('pointerup', onUp);
    mapEl.addEventListener('pointercancel', onUp);
    mapEl.addEventListener('pointerleave', onLeave);
    mapEl.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('keydown', onKey);
    mapEl._cv = { xy: (i) => [SX(i), SY(i)], tap: tapHex };

    return {
      update(next, prev) {
        st = next; pending = false; clearTimeout(pendT);
        if (next.g !== gid) {
          gid = next.g; lastId = next.last ? next.last.id : -1;
          car = null; bAnim = null; floats = []; plan = []; selK = -1;
          view.z = 1; clampView();
          renderAll(); return;
        }
        if (next.last && next.last.id !== lastId) {
          lastId = next.last.id;
          if (next.last.k !== 'b') plan = [];
          if (next.last.s !== undefined && next.t !== next.last.s) { plan = []; }
          onEvent(next.last, prev && prev !== next ? prev : null);
          return;
        }
        renderAll();
      },
      destroy() {
        stopLoop();
        clearTimeout(busyT); clearTimeout(pendT);
        if (busy) api.setBusy(false);
        window.removeEventListener('keydown', onKey);
        cv.destroy(); wrap.remove(); style.remove();
      },
    };
  }

  const ICON = '<path d="M28 4L48 16V40L28 52L8 40V16Z" fill="none" stroke="currentColor" stroke-width="3" opacity=".45"/>' +
    '<ellipse cx="25" cy="31" rx="11" ry="5.5" fill="currentColor"/><ellipse cx="23" cy="25.5" rx="6" ry="5" fill="currentColor"/>' +
    '<path d="M33 30L38 21" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><ellipse cx="39.5" cy="20" rx="3.6" ry="2.2" fill="currentColor"/>' +
    '<path d="M18 34L17 42M22 35L23 42M29 35L28 42M33 34L34 42" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>';

  L.register({
    id: 'caravan', name: '사막 대상 무역로', tag: '길 깔기 · 무역', cat: '보드',
    icon: ICON, tint: '#7a4a1c',
    blurb: '육각 사막에 길을 깔아 오아시스 도시를 잇고, 낙타 대상을 보내 주문을 채워 금을 벌어요. 남의 길을 지나면 통행료!',
    minPlayers: 2, maxPlayers: 5, defaultPlayers: 3, aiDelay: 640,
    options: [
      { id: 'map', label: '지도', choices: [{ v: 'r', label: '무작위' }, { v: 's', label: '모래벌판' }, { v: 'k', label: '바위 고원' }, { v: 'c', label: '협곡 지대' }], def: 'r' },
      { id: 'goal', label: '목표 금', choices: [{ v: 60, label: '60 (짧게)' }, { v: 80, label: '80' }, { v: 100, label: '100 (길게)' }], def: 80 },
    ],
    quick: [
      '사막에 길을 깔아 도시들을 잇고, 낙타 대상으로 주문받은 물건을 날라 금을 벌어요.',
      '내 차례엔 길 깔기(최대 3칸)와 대상 보내기(1번)를 원하는 순서로 하고 「차례 끝」.',
      '누가 목표 금에 닿거나 주문이 다 떨어지면 그 바퀴까지 하고 끝! 금이 가장 많은 사람이 이겨요.',
    ],
    rules: [
      { h: '목표', p: [
        '육각 칸으로 된 사막에 오아시스 도시가 7~8곳 있어요. 도시마다 내놓는 물건이 하나씩 있어요(향신료·비단·소금·대추야자·유리·유향).',
        '주문 카드는 「어느 도시가 어떤 물건을 원해요」예요. 그 물건을 내놓는 도시에서 원하는 도시까지 길이 이어져 있으면 낙타 대상을 보내 보상 금을 받아요.',
        '게임이 끝났을 때 금이 가장 많은 사람이 이겨요.'] },
      { h: '차례에 할 일', p: [
        '① 길 깔기: 한 차례에 3칸까지. 도시나 이미 깔린 길(누구 것이든) 옆 칸에만 깔 수 있어요.',
        '길 값(금): 모래 1 · 바위 2 · 협곡 3 · 오아시스 공짜. 바위산은 길을 낼 수 없어요.',
        '② 대상 보내기: 한 차례에 1번. 공개 주문 4장 중 하나를 골라요. 길과 도시만 지나서 갈 수 있어요.',
        '둘은 순서 상관없이 해도 되고, 안 해도 돼요. 다 했으면 「차례 끝」.'] },
      { h: '통행료', p: [
        '대상이 남의 길 칸을 지나가면 칸마다 금 1을 그 길 주인에게 내요(보상에서 빠져요).',
        '내 길과 도시는 공짜예요. 대상은 알아서 통행료가 가장 적게 드는 길로 가요.',
        '그래서 많이 다니는 길목을 먼저 깔면 남이 지나갈 때마다 금이 들어와요!'] },
      { h: '보상', p: [
        '주문 보상은 물건을 내놓는 가장 가까운 도시에서 떨어진 칸 수 + 2예요. 멀수록 많이 받아요.',
        '배달한 주문은 사라지고 더미에서 새 주문이 나와요.',
        '한 바퀴 동안 아무도 배달을 안 하면 맨 왼쪽 주문이 사라지고 새로 나와요.'] },
      { h: '사막 사건', p: [
        '2바퀴부터 바퀴가 시작될 때마다 사건이 하나 일어나요(14가지). 지도 위 사건 칸을 누르면 설명이 나와요.',
        '모래폭풍(7칸 막힘) · 도적 떼(지나가면 금 −3) · 시장 붐(그 물건 1.5배) · 우물 마름 · 선선한 바람 · 통행료 두 배 · 보조금 · 불볕더위(2칸만) · 대상 축제 · 세금 · 소나기 · 새 주문 몰림 · 조용한 하루 · 오아시스 발견.'] },
      { h: '끝내기', p: [
        '누군가 목표 금(기본 80)에 닿거나, 주문 더미가 다 떨어지면 「마지막 바퀴」예요. 그 바퀴 끝까지 하고 끝나요(모두 같은 횟수).',
        '금이 같으면 배달을 많이 한 사람이 이겨요. 처음 금은 10이고, 나중 차례일수록 1씩 더 받아요.'] },
      { h: '조작', p: [
        '내 차례엔 깔 수 있는 칸이 점선으로 빛나고, 가운데 숫자가 길 값이에요. 칸을 누르면 계획에 들어가고(다시 누르면 빠져요) 「길 깔기」로 확정해요.',
        '주문 카드를 누르면 지도에 대상이 갈 길과 통행료 동전이 보여요. 아직 안 이어졌으면 점선으로 깔아야 할 칸을 보여 주고, 「추천 길 넣기」로 계획에 넣을 수 있어요.',
        '초록 점이 찍힌 주문은 지금 바로 보낼 수 있어요.',
        '지도는 끌어서 옮기고, 두 손가락 · 마우스 휠 · ＋/− 버튼으로 확대해요.'] },
      { h: '예시', p: [
        '「유리 → 바람골, 금 7」 주문이 있어요. 유리는 은빛터에서 나와요.',
        '은빛터와 바람골 사이에 내 길 3칸(모래 1 + 바위 2 + 오아시스 0 = 금 3)을 깔고 대상을 보내면 금 7을 받아요.',
        '중간에 친구 길 2칸을 지나가면 통행료 2를 내서 금 5만 받고, 친구는 2를 받아요.'] },
      { h: 'AI 난이도', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움은 아무 주문이나 쫓아가요. 보통은 가장 이득인 주문을 골라 싼 길을 깔아요. 어려움은 남 길을 피하고 길목을 먼저 차지해 통행료를 벌고, 막판엔 길을 아껴요.'] },
    ],
    tutorial: [
      { sel: '.cv-map', text: '육각 사막 지도예요. 성 모양이 오아시스 도시, 옆 동그라미가 그 도시가 내놓는 물건이에요. 칸 색은 지형(모래·바위·협곡·오아시스·바위산)이에요.' },
      { sel: '.cv-mk', text: '주문 카드예요. 「물건 → 원하는 도시」와 보상 금. 그 물건이 나는 도시에서 원하는 도시까지 길이 이어지면 낙타 대상을 보내 금을 받아요.' },
      { sel: '.cv-map', text: '길 깔기: 내 차례엔 깔 수 있는 칸이 점선으로 빛나요(숫자 = 금). 칸을 눌러 계획하고 아래 「길 깔기」로 확정. 한 차례 3칸까지예요.' },
      { sel: '.cv-mk', text: '대상 보내기: 주문을 누르면 갈 길이 보여요. 남의 길을 지나면 칸마다 통행료 1을 그 주인에게 내요. 이어졌으면 「대상 보내기」(한 차례 1번)!' },
      { sel: '.cv-ev', text: '바퀴마다 사막 사건이 일어나요. 여기를 누르면 설명이 나와요. 모래폭풍·도적 떼·시장 붐…' },
      { sel: '.cv-pl', text: '목표 금에 먼저 닿거나 주문이 바닥나면 그 바퀴까지 하고 끝! 금이 가장 많은 사람이 이겨요. 다 했으면 「차례 끝」을 눌러요.' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { genMap, route, payout, plan, canBuildOn, costOf, NB, hd, N, W, H, EVENTS, canSend, traffic, HX, HY },
  });
})();
