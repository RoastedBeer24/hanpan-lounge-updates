/* 낙하산 착지 대회 — 비행기에서 뛰어내려 자유 낙하 → 낙하산 펴기 → 바람을 읽으며 조종 → 땅 직전 브레이크로 사뿐히.
   한 사람씩 번갈아 뛰고(라운드마다 장소가 바뀜), 과녁 중심 거리 점수 + 착지 점수 − 감점의 합계로 겨룬다.
   뛰는 기기는 조작 기록(펼친 틱 o, 입력 상태가 바뀐 틱 목록 ev = 틱*8 + 비트[왼1·오2·브레이크4])만 보내고,
   apply는 상태 안의 바람·출발점·맵 시드로 같은 시뮬레이션을 다시 돌려 점수를 낸다. 다른 기기는 같은 기록으로 다시 재생한다.
   시뮬 안에서는 Math.random을 쓰지 않는다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const DEG = Math.PI / 180, DT = 0.05;
  const EXIT = 320, GOOD = 160, LATE = 120, AAD = 90;   // 고도(m): 출발 · 권장 펼침 위/아래 · 자동 펼침
  const OPT = 28, MINO = 30, MAXK = 3000, MAXEV = 160;   // 펼쳐지는 시간(틱) · 비행기에서 떨어진 뒤 펼 수 있는 틱 · 최대 틱 · 입력 기록 최대
  const VA = 10, VAB = 4.5, VZ = 6, VZB = 4.2, LIFT = 5, FLT = 2.5, TF = 9.81 / (45 * 45);
  const HL = [0, 60, 150, 300];
  const LOCS = ['field', 'beach', 'summit', 'city'];
  const LNAME = ['들판', '해변', '산 정상', '도시 옥상'];
  // 착지면 종류: 0 정상 · 1 물 · 2 나무 · 3 바위 · 4 헛간/건물 · 5 길바닥 · 6 비탈 · 7 파라솔 · 8 옥상 시설물 · 9 다른 옥상 · 10 벽 · 11 늦게 펼침 · 12 자동 펼침
  const SN = ['', '물에 빠짐', '나무에 걸림', '바위에 걸림', '지붕에 걸림', '옥상 밖 길바닥', '비탈에 착지', '파라솔에 걸림', '옥상 시설물에 걸림', '다른 옥상', '벽에 부딪힘', '늦게 펼침', '자동 펼침'];
  const SPEN = [0, 30, 15, 15, 15, 40, 20, 10, 10, 10, 20, 10, 30];
  const SFAIL = [0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1];
  const GN = ['사뿐 착지', '좋은 착지', '쿵 착지', '넘어짐', '착지 실패'];
  const GPTS = [30, 20, 8, 0, 0];
  const STAR = [50, 80, 105];   // 혼자 할 때 한 번 점프 평균 별 기준
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const wrap = (a) => { a = (a + Math.PI) % (2 * Math.PI); if (a < 0) a += 2 * Math.PI; return a - Math.PI; };
  function mkR(seed) { let x = Math.abs(Math.floor(seed)) % 2147483647; if (x <= 0) x = 1234567; return () => { x = (x * 48271) % 2147483647; return x / 2147483647; }; }
  function gauss(R) { let u = 0, v = 0; while (u === 0) u = R(); while (v === 0) v = R(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  function hash3(a, b, c) { let v = Math.imul(a | 0, 73856093) ^ Math.imul(b | 0, 19349663) ^ Math.imul(c | 0, 83492791); v = Math.imul(v ^ (v >>> 13), 1274126177); return (v ^ (v >>> 16)) >>> 0; }

  /* ---------- 맵(장소) : (장소, 라운드 시드)로 결정적으로 만든다 ---------- */
  const MC = {};
  const CITYH = [-24, -18, -12, -6, 8, 14, 20];
  function genMap(li, rsd) {
    const key = li + ':' + rsd;
    if (MC[key]) return MC[key];
    const R = mkR(rsd * 13 + li * 7919 + 17);
    const M = { li, loc: LOCS[li], seed: rsd, ob: [], deco: [], cl: [], mh: 3 };
    const ok = (x, y, r, clr) => Math.hypot(x, y) > (clr || 14) + r && M.ob.every((o) => Math.hypot(o.x - x, o.y - y) > (o.s ? Math.max(o.w, o.d) * 0.72 : o.r) + r + 1.5);
    const place = (d0, d1, r, tries, extra) => {
      for (let i = 0; i < (tries || 40); i++) {
        const a = R() * 2 * Math.PI, d = d0 + R() * (d1 - d0), x = Math.cos(a) * d, y = Math.sin(a) * d;
        if (ok(x, y, r) && (!extra || extra(x, y))) return [x, y];
      }
      return null;
    };
    if (M.loc === 'field') {
      const np = 1 + (R() < 0.5 ? 1 : 0);
      for (let i = 0; i < np; i++) { const r = 13 + R() * 12, p = place(28 + r, 110, r); if (p) M.ob.push({ s: 0, x: p[0], y: p[1], r, h: 0, t: 1 }); }
      { const p = place(32, 95, 9); if (p) { M.ob.push({ s: 1, x: p[0], y: p[1], w: 14, d: 9, h: 6, t: 4, c: 0 }); M.ob.push({ s: 0, x: p[0] + 10, y: p[1] + 1, r: 3, h: 10, t: 4, c: 1 }); } }
      for (let c = 0; c < 7; c++) {
        const q = place(22, 175, 6); if (!q) continue;
        const k = 3 + Math.floor(R() * 5);
        for (let j = 0; j < k; j++) { const r = 2.3 + R() * 1.8, x = q[0] + (R() - 0.5) * 22, y = q[1] + (R() - 0.5) * 22; if (ok(x, y, r)) M.ob.push({ s: 0, x, y, r, h: 8 + R() * 5, t: 2 }); }
      }
      for (let i = 0; i < 10; i++) { const p = place(16, 140, 1.2); if (p) M.deco.push({ k: 'hay', x: p[0], y: p[1], a: R() * 3 }); }
      const ra = R() * Math.PI, rd = 30 + R() * 25;
      M.road = { nx: Math.cos(ra), ny: Math.sin(ra), d: rd };   // 흙길(장식): n·p = d 인 직선
      M.mh = 14;
    } else if (M.loc === 'beach') {
      const a = R() * 2 * Math.PI;
      M.sea = { nx: Math.cos(a), ny: Math.sin(a), d: 19 + R() * 12, p: R() * 6 };
      const land = (x, y, m) => !seaAt(M, x, y, m || 6);
      for (let i = 0; i < 14; i++) { const p = place(22, 160, 3, 40, (x, y) => land(x, y, 8)); if (p) M.ob.push({ s: 0, x: p[0], y: p[1], r: 2.8, h: 9 + R() * 2, t: 2, c: 1 }); }
      for (let i = 0; i < 12; i++) {
        const p = place(15, 80, 1.7, 40, (x, y) => { const dd = x * M.sea.nx + y * M.sea.ny; return land(x, y, 3) && dd > M.sea.d - 24; });
        if (p) M.ob.push({ s: 0, x: p[0], y: p[1], r: 1.7, h: 2.4, t: 7, c: Math.floor(R() * 4) });
      }
      { const p = place(20, 60, 2.5, 40, (x, y) => land(x, y, 4)); if (p) M.ob.push({ s: 1, x: p[0], y: p[1], w: 3, d: 3, h: 5, t: 4, c: 2 }); }
      for (let i = 0; i < 12; i++) { const p = place(10, 90, 1.2, 20, (x, y) => land(x, y, 2)); if (p) M.deco.push({ k: 'towel', x: p[0], y: p[1], a: R() * 3, c: Math.floor(R() * 4) }); }
      M.mh = 12;
    } else if (M.loc === 'summit') {
      M.pl = { p1: R() * 6.3, p2: R() * 6.3 };
      for (let i = 0; i < 7; i++) {
        const p = place(15, 34, 2.2, 40, (x, y) => Math.hypot(x, y) < platR(M, Math.atan2(y, x)) - 3);
        if (p) M.ob.push({ s: 0, x: p[0], y: p[1], r: 1.3 + R() * 1.2, h: 1.8, t: 3 });
      }
      for (let i = 0; i < 26; i++) { const a = R() * 6.3, d = 60 + R() * 260; M.deco.push({ k: 'pine', x: Math.cos(a) * d, y: Math.sin(a) * d }); }
      M.mh = 3;
    } else {
      const sx = R() < 0.5 ? 1 : -1, sy = R() < 0.5 ? 1 : -1;
      M.ob.push({ s: 0, x: 16 * sx, y: 16 * sy, r: 2.2, h: 3.5, t: 8, c: 0 });
      for (let i = 0; i < 3; i++) { const p = place(15, 21, 2, 40, (x, y) => Math.abs(x) < 20 && Math.abs(y) < 20); if (p) M.ob.push({ s: 1, x: p[0], y: p[1], w: 3, d: 2, h: 1.5, t: 8, c: 1 }); }
      M.mh = 21;
    }
    for (let i = 0; i < 9; i++) { const a = R() * 6.3, d = 40 + R() * 320; M.cl.push({ x: Math.cos(a) * d, y: Math.sin(a) * d, h: 195 + R() * 90, r: 14 + R() * 18 }); }
    MC[key] = M;
    return M;
  }
  function platR(M, a) { return 31 + 7 * Math.sin(3 * a + M.pl.p1) + 4 * Math.sin(5 * a + M.pl.p2); }
  function seaAt(M, x, y, m) { const S = M.sea, dd = x * S.nx + y * S.ny, al = -x * S.ny + y * S.nx; return dd > S.d + 3 * Math.sin(al * 0.05 + S.p) - (m || 0); }
  function bldH(M, bx, by) { return CITYH[hash3(bx, by, M.seed) % CITYH.length]; }
  const SURF = { h: 0, t: 0 };
  function surf(M, x, y) {
    let h = 0, t = 0;
    if (M.loc === 'summit') { const d = Math.hypot(x, y), pr = platR(M, Math.atan2(y, x)); if (d > pr) { h = -Math.min(150, (d - pr) * 0.9); t = 6; } }
    else if (M.loc === 'city') {
      const bx = Math.round(x / 60), by = Math.round(y / 60), lx = x - bx * 60, ly = y - by * 60;
      if (Math.abs(lx) <= 23 && Math.abs(ly) <= 23) { if (bx || by) { h = bldH(M, bx, by); t = 9; } }
      else { h = -40; t = 5; }
    } else if (M.loc === 'beach') { if (seaAt(M, x, y)) t = 1; }
    for (let i = 0; i < M.ob.length; i++) {
      const o = M.ob[i];
      const inside = o.s ? Math.abs(x - o.x) <= o.w / 2 && Math.abs(y - o.y) <= o.d / 2 : (x - o.x) * (x - o.x) + (y - o.y) * (y - o.y) <= o.r * o.r;
      if (!inside) continue;
      if (o.t === 1) { if (h <= 0) t = 1; continue; }
      if (o.h > h) { h = o.h; t = o.t; }
    }
    SURF.h = h; SURF.t = t;
    return SURF;
  }

  /* ---------- 바람 + 비행 시뮬레이션 (apply · 실시간 조작 · AI · 다시보기가 함께 씀) ---------- */
  function newRun(J) {
    const wv = new Float64Array(8);
    for (let i = 0; i < 4; i++) { const d = J.w[i * 2] * DEG, s = J.w[i * 2 + 1] / 10; wv[i * 2] = Math.cos(d) * s; wv[i * 2 + 1] = Math.sin(d) * s; }
    const sd = J.sd;
    return { k: 0, x: J.ex, y: J.ey, a: EXIT, th: J.eh * DEG, va: 14, vz: 0, ph: 0, ok: -1, oa: 0, aad: 0, T: -1, wv,
      ga: J.ga / 100, p1: (sd % 628) / 100, p2: (Math.floor(sd / 628) % 628) / 100,
      wx: 0, wy: 0, gx: 0, gy: 0, px: J.ex, py: J.ey, pa: EXIT, pth: J.eh * DEG, lx: 0, ly: 0, lvz: 0, lgs: 0, lt: 0, lh: 0, turn: 0, br: 0, fe: 0, fl: 0 };
  }
  /* 고도 a의 바람 (k ≥ 0이면 돌풍 포함) → o.wx, o.wy */
  function windAt(r, a, k, o) {
    const v = r.wv;
    let i, f;
    if (a <= 0) { i = 0; f = 0; } else if (a >= 300) { i = 2; f = 1; } else { i = a < 60 ? 0 : a < 150 ? 1 : 2; f = (a - HL[i]) / (HL[i + 1] - HL[i]); }
    let wx = v[i * 2] + (v[i * 2 + 2] - v[i * 2]) * f, wy = v[i * 2 + 1] + (v[i * 2 + 3] - v[i * 2 + 1]) * f;
    if (k >= 0) { const t = k * DT, g = 1 + r.ga * Math.sin(0.8 * t + r.p1) + r.ga * 0.6 * Math.sin(2.1 * t + r.p2); wx *= g; wy *= g; }
    o.wx = wx; o.wy = wy;
    return o;
  }
  function step(r, M, bits, openNow) {
    if (r.T >= 0) return;
    const l = bits & 1, rt = (bits >> 1) & 1, b = (bits >> 2) & 1;
    let turn = 0, br = 0;
    if (l && rt) br = 1; else turn = rt - l;
    if (b) br = 1;
    r.turn = turn; r.br = br; r.pth = r.th;
    if (r.ph === 0) {
      if (openNow && r.k >= MINO) { r.ph = 1; r.ok = r.k; r.oa = r.a; }
      else if (r.a <= AAD) { r.ph = 1; r.ok = r.k; r.oa = r.a; r.aad = 1; }
    }
    if (r.ph === 0) {
      r.vz += (9.81 - TF * r.vz * r.vz) * DT;
      r.va += (6 - r.va) * DT / 2;
      r.th -= turn * 90 * DEG * DT;
    } else if (r.ph === 1) {
      r.vz += (VZ - r.vz) * DT / 0.3;
      r.va += (VA - r.va) * DT / 0.6;
      r.th -= turn * 40 * DEG * DT;
      if (r.k - r.ok >= OPT) r.ph = 2;
    } else {
      // 브레이크를 당기는 순간의 속도가 '플레어 힘'(fe)이 되어 잠깐 하강을 거의 멈춘다. 힘은 FLT초에 걸쳐 빠진다.
      const at = Math.abs(turn);
      if (br && !r.fl) { r.fe = clamp((r.va - VAB) / (VA - VAB), 0, 1); r.fl = 1; }
      if (br) r.fe = Math.max(0, r.fe - DT / FLT); else { r.fl = 0; r.fe = 0; }
      const vt = br ? VAB : VA - 1.5 * at;
      r.va += (vt - r.va) * DT / (br ? 0.3 : 0.7);
      const zt = Math.max(0.3, (br ? VZB : VZ) + 1.6 * at * (br ? 0.5 : 1) - LIFT * r.fe);
      r.vz += (zt - r.vz) * DT / 0.25;
      r.th -= turn * 60 * DEG * DT * (br ? 0.6 : 1);
    }
    windAt(r, r.a, r.k, r);
    r.gx = r.va * Math.cos(r.th) + r.wx; r.gy = r.va * Math.sin(r.th) + r.wy;
    r.px = r.x; r.py = r.y; r.pa = r.a;
    r.x += r.gx * DT; r.y += r.gy * DT; r.a -= r.vz * DT; r.k++;
    if (r.a <= M.mh + 1 || r.k >= MAXK) {
      const S = surf(M, r.x, r.y);
      if (r.a <= S.h || r.k >= MAXK) {
        let t = S.t;
        const h = S.h;
        if (r.pa < h - 0.05) { r.lx = r.px; r.ly = r.py; if (t === 4 || t === 9) t = 10; }   // 옆에서 들이받음
        else { const f = clamp((r.pa - h) / Math.max(1e-6, r.pa - r.a), 0, 1); r.lx = r.px + (r.x - r.px) * f; r.ly = r.py + (r.y - r.py) * f; }
        r.lh = h; r.lt = t; r.lvz = r.vz; r.lgs = Math.hypot(r.gx, r.gy); r.T = r.k;
      }
    }
  }
  function simulate(J, M, rec, cb) {
    const r = newRun(J), ev = rec.ev;
    let i = 0, bits = 0;
    while (r.T < 0) {
      while (i < ev.length && (ev[i] >> 3) <= r.k) { bits = ev[i] & 7; i++; }
      step(r, M, bits, rec.o >= 0 && r.k >= rec.o);
      if (cb) cb(r, bits);
    }
    return r;
  }
  function softEff(vz, gs) { return vz + Math.max(0, gs - 7) * 0.35; }
  function grade(vz, gs) { const e = softEff(vz, gs); return e < 2.3 ? 0 : e < 3.8 ? 1 : e < 5.2 ? 2 : 3; }
  function scoreRun(r) {
    const d = Math.round(Math.hypot(r.lx, r.ly) * 10) / 10;
    let g = grade(r.lvz, r.lgs);
    if (SFAIL[r.lt]) g = 4;
    const pen = [];
    let pp = 0;
    if (r.lt) { pen.push(r.lt); pp += SPEN[r.lt]; }
    if (r.aad) { pen.push(12); pp += SPEN[12]; } else if (r.oa < LATE) { pen.push(11); pp += SPEN[11]; }
    const dp = Math.max(0, Math.round(100 - 4 * d)), lp = GPTS[g];
    return { d, g, pen, pp, dp, lp, p: Math.max(0, dp + lp - pp) };
  }
  function judge(J, M, rec) { const r = simulate(J, M, rec); const s = scoreRun(r); s.r = r; return s; }

  /* ---------- 규칙 / 상태 ---------- */
  function rnd(s) { s.rs = (s.rs * 48271) % 2147483647; return s.rs / 2147483647; }
  function baseWind(li, rsd) {
    const R = mkR(rsd * 31 + 7), mul = li === 2 ? 1.2 : 1;
    const sp = [1 + R() * 3.5, 2.5 + R() * 3.5, 4 + R() * 4, 6 + R() * 4.5].map((v) => v * mul);
    const d = [R() * 360]; for (let i = 1; i < 4; i++) d.push(d[i - 1] + (R() - 0.5) * (i === 3 ? 60 : 80));
    return { d, sp };
  }
  function nextJump(s) {
    const li = s.lc[s.r], B = baseWind(li, s.rsd[s.r]), w = [];
    for (let i = 0; i < 4; i++) { w.push(Math.round((((B.d[i] + (rnd(s) - 0.5) * 24) % 360) + 360) % 360)); w.push(Math.round(B.sp[i] * (0.88 + rnd(s) * 0.24) * 10)); }
    let ax = 0, ay = 0;
    for (let i = 2; i < 4; i++) { ax += Math.cos(w[i * 2] * DEG) * w[i * 2 + 1]; ay += Math.sin(w[i * 2] * DEG) * w[i * 2 + 1]; }
    const ang = Math.atan2(ay, ax), up = 70 + rnd(s) * 80, cr = (rnd(s) - 0.5) * 140;
    const ex = -Math.cos(ang) * up - Math.sin(ang) * cr, ey = -Math.sin(ang) * up + Math.cos(ang) * cr;
    s.J = { w, ex: Math.round(ex), ey: Math.round(ey), eh: Math.round(((ang / DEG + 180) % 360 + 360) % 360), sd: 1 + Math.floor(rnd(s) * 2147483000), ga: li === 3 ? 18 : li === 2 ? 14 : 10 };
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const R = [1, 3, 4].includes(+opts.rounds) ? +opts.rounds : 3;
    const s = { n, R, r: 0, i: 0, lc: [], rsd: [], tot: players.map(() => 0), js: players.map(() => []),
      nm: players.map((p) => String(p.name || '').slice(0, 10)), seq: 0, last: null, ph: 'p', rs: 1 + Math.floor(Math.random() * 2147483640), J: null };
    const o = opts.loc || 'rand', fixed = LOCS.indexOf(o);
    const st = Math.floor(rnd(s) * 4);
    for (let r = 0; r < R; r++) {
      s.lc.push(fixed >= 0 ? fixed : o === 'rand' ? Math.floor(rnd(s) * 4) : (st + r) % 4);
      s.rsd.push(1 + Math.floor(rnd(s) * 2147483000));
    }
    nextJump(s);
    return s;
  }
  function actor(s) { return s.ph === 'e' ? null : s.i; }
  function validRec(a) {
    if (!a || a.type !== 'jump' || !Number.isInteger(a.o) || a.o < -1 || a.o > MAXK || !Array.isArray(a.ev) || a.ev.length > MAXEV) return false;
    let p = -1;
    for (const v of a.ev) { if (!Number.isInteger(v) || v < 0 || (v >> 3) > MAXK || (v >> 3) <= p) return false; p = v >> 3; }
    return true;
  }
  function apply(s, seat, a) {
    if (s.ph !== 'p' || actor(s) !== seat) throw new Error('not your turn');
    if (!validRec(a)) throw new Error('bad jump record');
    const li = s.lc[s.r], M = genMap(li, s.rsd[s.r]);
    const res = judge(s.J, M, { o: a.o, ev: a.ev });
    s.seq++;
    s.js[seat].push([res.p, Math.round(res.d * 10), res.g]);
    s.tot[seat] += res.p;
    s.last = { id: s.seq, s: seat, r: s.r, li, rsd: s.rsd[s.r], J: s.J, o: a.o, ev: a.ev.slice(),
      lx: Math.round(res.r.lx * 10), ly: Math.round(res.r.ly * 10), d: res.d, g: res.g, pen: res.pen, dp: res.dp, lp: res.lp, p: res.p, oa: Math.round(res.r.oa) };
    s.i++;
    if (s.i >= s.n) { s.i = 0; s.r++; if (s.r >= s.R) s.ph = 'e'; }
    if (s.ph !== 'e') nextJump(s);
    return s;
  }
  function rankOrder(s) { return s.tot.map((v, i) => i).sort((a, b) => s.tot[b] - s.tot[a] || a - b); }
  function stars(s, seat) { const avg = s.tot[seat] / Math.max(1, s.R); return STAR.filter((v) => avg >= v).length; }
  function result(s) {
    if (s.ph !== 'e') return null;
    const best = Math.max(...s.tot), w = s.tot.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const lines = rankOrder(s).map((i, k) => (s.n > 1 ? (k + 1) + '위 ' : '') + nm(i) + ' · ' + s.tot[i] + '점 (' + s.js[i].map((j) => (j[1] / 10).toFixed(1) + 'm').join(' · ') + ')');
    if (s.n === 1) {
      const k = stars(s, 0);
      return { winners: k > 0 ? [0] : [], title: (k ? '★'.repeat(k) + '☆'.repeat(3 - k) : '☆☆☆') + ' ' + s.tot[0] + '점',
        text: s.R + '라운드 · 별 기준(합계) ' + STAR.map((v) => v * s.R).join(' / ') + '점\n' + lines.join('\n') };
    }
    return { winners: w, title: w.length > 1 ? '공동 우승' : undefined, text: s.R + '라운드 · ' + s.lc.map((l) => LNAME[l]).join(' → ') + '\n' + lines.join('\n') };
  }

  /* ---------- AI: 사람과 같은 조작(왼·오·브레이크)으로 날며, 실력에 따라 바람 읽기·반응·펼침 고도·브레이크 타이밍이 다름 ---------- */
  const LVP = {
    1: { wn: 0.4, dn: 35, upd: 16, tol: 16, hold: 8, low: 3, oa: 148, os: 36, fl: 0.3, nof: 0.12, fa: 0, tg: 3, brk: 0 },
    2: { wn: 0.16, dn: 13, upd: 6, tol: 9, hold: 5, low: 6, oa: 140, os: 12, fl: 0.14, nof: 0.02, fa: -0.3, tg: 4, brk: 1 },
    3: { wn: 0.03, dn: 3, upd: 2, tol: 5, hold: 3, low: 7, plan: 1, fl: 0.03, nof: 0, fa: -0.3, tg: 3, brk: 1 },
  };
  const AW = { wx: 0, wy: 0 };
  function aiFly(J, M, P, seed, openAlt, flareK) {
    const R = mkR(seed), r = newRun(J);
    const werr = Math.max(0.2, 1 + gauss(R) * P.wn), derr = gauss(R) * P.dn * DEG, ce = Math.cos(derr) * werr, se = Math.sin(derr) * werr;
    const ev = [];
    let bits = 0, lastK = -99, o = -1, dh = r.th, turnSt = 0, wantBr = 0;
    while (r.T < 0) {
      const upd = r.k % P.upd === 0;
      let nb = 0;
      if (r.ph === 0) {
        if (o < 0 && r.a <= openAlt && r.k >= MINO) o = r.k;
        if (upd) dh = Math.atan2(-r.y, -r.x);
      } else if (r.ph === 2) {
        if (flareK >= 0 && r.k >= flareK) { turnSt = 0; wantBr = 0; nb = 4; }
        else if (upd) {
          // 착지 직선(바람을 안고 과녁으로 들어오는 선) 위의 '지금 높이에 맞는 자리'로 따라간다:
          // 바람이 부는 쪽으로 (공기 속도 − 바람) × 남은 시간만큼 떨어진 곳 → 높이가 줄면 과녁으로 다가온다.
          windAt(r, r.a, -1, AW);
          const cwx = AW.wx * ce - AW.wy * se, cwy = AW.wx * se + AW.wy * ce;
          let mx = 0, my = 0;
          for (const f of [1, 0.5, 0]) { windAt(r, r.a * f, -1, AW); mx += AW.wx; my += AW.wy; }
          mx /= 3; my /= 3;
          const ewx = mx * ce - my * se, ewy = mx * se + my * ce, W = Math.hypot(ewx, ewy);
          const ux = W > 0.3 ? ewx / W : -Math.cos(r.th), uy = W > 0.3 ? ewy / W : -Math.sin(r.th);   // 바람 부는 쪽
          const G0 = VA - W, T = Math.max(0, Math.max(0, r.a) / VZ + P.fa), S0 = G0 * T;
          const es = r.x * ux + r.y * uy - S0, ec = -r.x * uy + r.y * ux;
          const vx = -ux * G0 - (es * ux - ec * uy) / P.tg, vy = -uy * G0 - (es * uy + ec * ux) / P.tg;
          const ax = vx - cwx, ay = vy - cwy, am = Math.hypot(ax, ay), base = Math.atan2(ay, ax);
          wantBr = P.brk && r.a > 30 && am < 5.5 ? 1 : 0;   // 너무 빠르면 브레이크로 천천히(땅 가까이선 풀어서 속도를 되찾음)
          const sp0 = wantBr ? VAB : VA;
          if (am >= sp0 * 0.98) dh = base;
          else {   // 남는 속도는 비스듬히(S자로) 날아 버림: 착지선 쪽으로 붙는 방향을 고른다
            const phi = Math.acos(am / sp0), h1 = base + phi, h2 = base - phi, cxv = -uy, cyv = ux;
            const c1 = (sp0 * Math.cos(h1) + cwx) * cxv + (sp0 * Math.sin(h1) + cwy) * cyv;
            if (Math.abs(ec) < 2) dh = Math.abs(wrap(h1 - r.th)) < Math.abs(wrap(h2 - r.th)) ? h1 : h2;
            else dh = (c1 < 0) === (ec > 0) ? h1 : h2;
          }
        }
      }
      if (r.ph !== 1 && nb !== 4) {
        const e = wrap(dh - r.th), tol = P.tol * DEG;
        if (r.ph === 2 && r.a < P.low) turnSt = 0;
        else if (turnSt === 0) { if (Math.abs(e) > tol) turnSt = e > 0 ? 1 : 2; }
        else if (Math.abs(e) < tol * 0.35 || (turnSt === 1) !== (e > 0)) turnSt = 0;
        nb = turnSt | (r.ph === 2 && wantBr ? 4 : 0);
      }
      if (r.ph === 1) nb = 0;
      if (nb !== bits && (r.k - lastK >= P.hold || nb === 4) && ev.length < MAXEV) { bits = nb; lastK = r.k; ev.push(r.k * 8 + bits); }
      step(r, M, bits, o >= 0 && r.k >= o);
    }
    return { o, ev, r };
  }
  /* 착지 직전 브레이크 시점 찾기: 브레이크 없이 날아 착지 틱을 구하고, 그 앞 lead초에 당겨 보며 가장 부드러운 것을 고름 */
  function bestFlare(J, M, P, seed, oa, step0) {
    const base = aiFly(J, M, P, seed, oa, -1), T = base.r.T;
    let best = null;
    for (let lead = 0.3; lead <= 1.61; lead += step0) {
      const fk = Math.max(0, T - Math.round(lead / DT));
      const f = aiFly(J, M, P, seed, oa, fk), sc = scoreRun(f.r), e = softEff(f.r.lvz, f.r.lgs);
      const v = sc.p * 10 - e;
      if (!best || v > best.v) best = { v, lead, sc, fk, T };
    }
    return best || { lead: 0.8, T, sc: scoreRun(base.r), v: 0 };
  }
  function ai(s, seat, lv) {
    const P = LVP[lv] || LVP[2];
    const J = s.J, M = genMap(s.lc[s.r], s.rsd[s.r]);
    const seed = 1 + Math.floor(Math.random() * 2147483000), R = mkR(seed * 3 + 11);
    let oa;
    if (P.plan) {
      let bv = -1e9;
      for (const c of [175, 155, 140, 127]) { const b = bestFlare(J, M, P, seed, c, 0.1); if (b.v > bv) { bv = b.v; oa = c; } }
    } else oa = clamp(P.oa + gauss(R) * P.os, 92, 280);
    const b = bestFlare(J, M, P, seed, oa, 0.05);
    let fk = -1;
    if (R() >= P.nof) { const lead = b.lead + gauss(R) * P.fl; fk = Math.max(0, b.T - Math.round(lead / DT)); }
    const f = aiFly(J, M, P, seed, oa, fk);
    return { type: 'jump', o: f.o, ev: f.ev };
  }

  /* ================================= 화면 ================================= */
  const SUNX = 0.45, SUNY = -0.3;   // 그림자 방향(고도 1m당)
  const FONT = '"IBM Plex Sans KR", sans-serif', MONO = '"IBM Plex Mono", monospace', DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = L.h('div', { class: 'hud top', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px', alignItems: 'stretch' } });
    const btnSt = (grow) => ({ flex: grow + ' 1 0', minWidth: 0, minHeight: '62px', padding: '0 6px', fontSize: '16px', touchAction: 'none', userSelect: 'none', WebkitUserSelect: 'none', borderRadius: '16px', flexDirection: 'column', gap: '1px', lineHeight: '1.1' });
    const bL = L.h('button', { class: 'btn pc-l', style: btnSt(1), 'aria-label': '왼쪽으로 돌기' });
    const bB = L.h('button', { class: 'btn primary pc-b', style: btnSt(1.45), 'aria-label': '가운데 버튼' });
    const bR = L.h('button', { class: 'btn pc-r', style: btnSt(1), 'aria-label': '오른쪽으로 돌기' });
    bL.innerHTML = '<span style="font-size:22px">◀</span><span style="font-size:12px">왼쪽</span>';
    bR.innerHTML = '<span style="font-size:22px">▶</span><span style="font-size:12px">오른쪽</span>';
    const bar = L.h('div', { class: 'hud bottom', style: { gap: '8px', flexWrap: 'nowrap', padding: '8px 10px 10px', alignItems: 'stretch' } }, bL, bB, bR);
    const altBox = L.h('div', { class: 'pc-alt', style: { position: 'absolute', pointerEvents: 'none' } });
    const mapBox = L.h('div', { class: 'pc-map', style: { position: 'absolute', pointerEvents: 'none' } });
    root.append(top, altBox, mapBox, bar);
    let st = null, G = null, time = 0, anim = null, myPend = null, pops = [], parts = [], waitTimer = 0, barKey = '';
    let PX = 0, PY = 0, cx = 0, cy = 0, F = 300, rc = 1, rs = 0;
    const C = 12;
    const cur = { x: 0, y: 0, a: EXIT, th: 0, ph: -1, bits: 0, vz: 0, k: 0, ok: -1, M: null, J: null, land: 0 };
    const ptrs = new Map();   // pointerId → 'l' | 'r' | 'b'
    const streaks = Array.from({ length: 22 }, () => ({ a: Math.random() * 6.3, d: Math.random(), v: 0.6 + Math.random() * 0.8 }));
    const color = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const pname = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || '');
    const sp = () => L.debug.speed || 1;
    const showBar = () => api.mySeats().length > 0 && st && st.ph !== 'e';

    function layout() {
      const was = G;
      G = { W: cv.w, H: cv.h, topH: was ? was.topH : 72, barH: was ? was.barH : 0 };
      measure();
    }
    function measure() {
      if (!G) return;
      const th = top.getBoundingClientRect().height, bh = bar.style.display === 'none' ? 0 : bar.getBoundingClientRect().height;
      if (th) G.topH = th + 2;
      G.barH = bh || 0;
      const botY = G.H - G.barH;
      G.botY = botY;
      G.mapS = G.W < 380 ? 92 : 104;
      G.alt = { x: 8, w: 54, y0: G.topH + 64, y1: botY - 44 };
      Object.assign(altBox.style, { left: G.alt.x + 'px', top: G.alt.y0 + 'px', width: G.alt.w + 'px', height: Math.max(10, G.alt.y1 - G.alt.y0) + 'px' });
      Object.assign(mapBox.style, { left: (G.W - G.mapS - 8) + 'px', top: (G.topH + 4) + 'px', width: G.mapS + 'px', height: G.mapS + 'px' });
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function humanTurn() { if (!st || st.ph === 'e') return false; const a = actor(st); return a != null && api.canAct(a); }

    /* ---------- 투영: 위에서 내려다보는 카메라(진행 방향이 화면 위), 높이 h의 축척 = F/(고도 − h + C) ---------- */
    function scaleAt(h) { const dz = cur.a - h + C; return dz < 0.6 ? 0 : F / dz; }
    function proj(x, y, h) {
      const s = scaleAt(h); if (!s) return 0;
      const dx = (x - cur.x) * s, dy = (y - cur.y) * s;
      PX = cx + dx * rc - dy * rs; PY = cy - (dx * rs + dy * rc);
      return s;
    }
    function setH(h) {
      const s = scaleAt(h); if (!s) return 0;
      ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      ctx.translate(cx, cy); ctx.rotate(cur.th - Math.PI / 2); ctx.scale(s, -s); ctx.translate(-cur.x, -cur.y);
      return s;
    }
    function resetT() { ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0); }
    const onScr = (m) => PX > -m && PX < G.W + m && PY > -m && PY < G.H + m;
    function viewR(s) { const dx = Math.max(cx, G.W - cx), dy = Math.max(cy, G.H - cy); return Math.hypot(dx, dy) / s + 2; }

    /* ---------- 땅 그리기 ---------- */
    const FIELD = ['#4f7d34', '#5a8a3a', '#66923f', '#7d9a45', '#9aa64e', '#b7a957', '#476f2f', '#6d8f3b'];
    function drawGround(M) {
      const { W, H } = G;
      resetT();
      if (M.loc === 'field') {
        ctx.fillStyle = '#3f6629'; ctx.fillRect(0, 0, W, H);
        const s = setH(0); if (!s) return;
        const cs = s < 1 ? 80 : 40, rv = Math.min(700, viewR(s));
        const x0 = Math.floor((cur.x - rv) / cs), x1 = Math.floor((cur.x + rv) / cs), y0 = Math.floor((cur.y - rv) / cs), y1 = Math.floor((cur.y + rv) / cs);
        const gap = Math.max(0.6, 1.2 / s);
        for (let gx = x0; gx <= x1; gx++) for (let gy = y0; gy <= y1; gy++) {
          const hv = hash3(gx, gy, M.seed + cs);
          ctx.fillStyle = FIELD[hv % FIELD.length];
          ctx.fillRect(gx * cs + gap, gy * cs + gap, cs - 2 * gap, cs - 2 * gap);
          if (s > 2.2 && (hv >> 4) % 3 === 0) { // 밭고랑
            ctx.strokeStyle = 'rgba(40,60,20,.22)'; ctx.lineWidth = 0.35; ctx.beginPath();
            for (let q = 2; q < cs; q += 2.5) { if ((hv >> 7) & 1) { ctx.moveTo(gx * cs + q, gy * cs + gap); ctx.lineTo(gx * cs + q, gy * cs + cs - gap); } else { ctx.moveTo(gx * cs + gap, gy * cs + q); ctx.lineTo(gx * cs + cs - gap, gy * cs + q); } }
            ctx.stroke();
          }
        }
        const rd = M.road, tx = -rd.ny, ty = rd.nx;
        ctx.strokeStyle = '#b89b67'; ctx.lineWidth = 4.5; ctx.lineCap = 'butt';
        ctx.beginPath(); ctx.moveTo(rd.nx * rd.d - tx * 900, rd.ny * rd.d - ty * 900); ctx.lineTo(rd.nx * rd.d + tx * 900, rd.ny * rd.d + ty * 900); ctx.stroke();
        for (const o of M.ob) if (o.t === 1) {
          ctx.fillStyle = '#5c7a3c'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r + 1.4, 0, 7); ctx.fill();
          ctx.fillStyle = '#2f6f93'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, 7); ctx.fill();
          ctx.fillStyle = 'rgba(160,215,240,.25)'; ctx.beginPath(); ctx.arc(o.x - o.r * 0.25, o.y + o.r * 0.25, o.r * 0.55, 0, 7); ctx.fill();
        }
        for (const d of M.deco) { ctx.fillStyle = '#d9b75e'; ctx.beginPath(); ctx.arc(d.x, d.y, 1.1, 0, 7); ctx.fill(); }
      } else if (M.loc === 'beach') {
        ctx.fillStyle = '#1f6b93'; ctx.fillRect(0, 0, W, H);
        const s = setH(0); if (!s) return;
        const S = M.sea, tx = -S.ny, ty = S.nx;
        if (!M.shore) {
          M.shore = [];
          for (let al = -900; al <= 900; al += 12) { const dd = S.d + 3 * Math.sin(al * 0.05 + S.p); M.shore.push([S.nx * dd + tx * al, S.ny * dd + ty * al]); }
        }
        const sh = M.shore;
        ctx.fillStyle = '#2c86b0'; ctx.beginPath();   // 얕은 물
        sh.forEach((p, i) => (i ? ctx.lineTo(p[0] + S.nx * 22, p[1] + S.ny * 22) : ctx.moveTo(p[0] + S.nx * 22, p[1] + S.ny * 22)));
        ctx.lineTo(sh[sh.length - 1][0] - S.nx * 2000, sh[sh.length - 1][1] - S.ny * 2000); ctx.lineTo(sh[0][0] - S.nx * 2000, sh[0][1] - S.ny * 2000); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#e4cd97'; ctx.beginPath();
        sh.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
        ctx.lineTo(sh[sh.length - 1][0] - S.nx * 2000, sh[sh.length - 1][1] - S.ny * 2000); ctx.lineTo(sh[0][0] - S.nx * 2000, sh[0][1] - S.ny * 2000); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#c9ad74'; ctx.lineWidth = 3;   // 젖은 모래
        ctx.beginPath(); sh.forEach((p, i) => (i ? ctx.lineTo(p[0] - S.nx * 1.5, p[1] - S.ny * 1.5) : ctx.moveTo(p[0] - S.nx * 1.5, p[1] - S.ny * 1.5))); ctx.stroke();
        const wv = (Math.sin(time * 1.3) + 1) * 2.2;
        ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = Math.max(0.5, 1.2 / s);
        ctx.beginPath(); sh.forEach((p, i) => (i ? ctx.lineTo(p[0] + S.nx * wv, p[1] + S.ny * wv) : ctx.moveTo(p[0] + S.nx * wv, p[1] + S.ny * wv))); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.3)';
        ctx.beginPath(); sh.forEach((p, i) => (i ? ctx.lineTo(p[0] + S.nx * (wv + 7), p[1] + S.ny * (wv + 7)) : ctx.moveTo(p[0] + S.nx * (wv + 7), p[1] + S.ny * (wv + 7)))); ctx.stroke();
        const TC = ['#ee6a55', '#5bb3e6', '#e8c04e', '#b48cf0'];
        for (const d of M.deco) { ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.a); ctx.fillStyle = TC[d.c]; ctx.fillRect(-0.9, -0.5, 1.8, 1); ctx.restore(); }
      } else if (M.loc === 'summit') {
        ctx.fillStyle = '#25372b'; ctx.fillRect(0, 0, W, H);
        if (!M.cont) {
          M.cont = [-110, -75, -50, -32, -18, -8, 0].map((lv) => { const pts = []; for (let i = 0; i < 64; i++) { const a = i / 64 * 2 * Math.PI, rr0 = platR(M, a) + (-lv) / 0.9; pts.push([Math.cos(a) * rr0, Math.sin(a) * rr0]); } return { lv, pts }; });
        }
        const cols = ['#2c4130', '#37503a', '#4a6245', '#5f7352', '#7a8466', '#948f78', '#a9a28a'];
        M.cont.forEach((c, i) => {
          const s = setH(c.lv); if (!s) return;
          ctx.fillStyle = cols[i]; ctx.beginPath(); c.pts.forEach((p, j) => (j ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill();
          if (i < 6) { ctx.strokeStyle = 'rgba(20,30,22,.35)'; ctx.lineWidth = 0.8 / Math.max(0.05, s) * Math.min(1, s); ctx.stroke(); }
        });
        resetT();
        for (const d of M.deco) { // 비탈의 소나무
          const dd = Math.hypot(d.x, d.y), h = -Math.min(150, Math.max(0, dd - platR(M, Math.atan2(d.y, d.x))) * 0.9);
          const s = proj(d.x, d.y, h + 6); if (!s || !onScr(20)) continue;
          ctx.fillStyle = '#1d3322'; ctx.beginPath(); ctx.arc(PX, PY, Math.max(1, 2.6 * s), 0, 7); ctx.fill();
        }
        const s = setH(0); if (!s) return;
        ctx.strokeStyle = 'rgba(240,244,250,.55)'; ctx.lineWidth = 0.5;   // 정상 표지 둘레 눈
        ctx.beginPath(); M.cont[6].pts.forEach((p, j) => (j ? ctx.lineTo(p[0] * 0.97, p[1] * 0.97) : ctx.moveTo(p[0] * 0.97, p[1] * 0.97))); ctx.closePath(); ctx.stroke();
      } else {
        ctx.fillStyle = '#26252d'; ctx.fillRect(0, 0, W, H);
        let s = setH(-40);
        if (s) {
          const rv = Math.min(520, viewR(s)), b0x = Math.round((cur.x - rv) / 60), b1x = Math.round((cur.x + rv) / 60), b0y = Math.round((cur.y - rv) / 60), b1y = Math.round((cur.y + rv) / 60);
          ctx.strokeStyle = 'rgba(230,210,120,.45)'; ctx.lineWidth = 0.6; ctx.setLineDash([4, 4]); ctx.beginPath();
          for (let i = b0x - 1; i <= b1x; i++) { ctx.moveTo(i * 60 + 30, b0y * 60 - 60); ctx.lineTo(i * 60 + 30, b1y * 60 + 60); }
          for (let j = b0y - 1; j <= b1y; j++) { ctx.moveTo(b0x * 60 - 60, j * 60 + 30); ctx.lineTo(b1x * 60 + 60, j * 60 + 30); }
          ctx.stroke(); ctx.setLineDash([]);
          resetT();
          const list = [];
          for (let i = b0x; i <= b1x; i++) for (let j = b0y; j <= b1y; j++) list.push([i, j, i || j ? bldH(M, i, j) : 0]);
          list.sort((p, q) => p[2] - q[2]);
          for (const b of list) drawBuilding(M, b[0], b[1], b[2]);
        }
      }
      resetT();
    }
    const RC = ['#7f7b84', '#8e8578', '#6f7480', '#9a8f7f', '#77707d', '#86807a', '#7c8a8a'];
    function drawBuilding(M, i, j, h) {
      const x = i * 60, y = j * 60, hw = 23;
      const sT = scaleAt(h); if (!sT) return;
      proj(x, y, h); if (!onScr(hw * sT * 1.5)) return;
      const near = Math.hypot(x - cur.x, y - cur.y) < 170 && scaleAt(-40) > 0.45;
      const cs = [[x - hw, y - hw], [x + hw, y - hw], [x + hw, y + hw], [x - hw, y + hw]];
      const T = cs.map((p) => { proj(p[0], p[1], h); return [PX, PY]; });
      if (near) {
        const B = cs.map((p) => { proj(p[0], p[1], -40); return [PX, PY]; });
        const faces = [];
        if (cur.y < y - hw) faces.push([0, 1]); if (cur.x > x + hw) faces.push([1, 2]); if (cur.y > y + hw) faces.push([2, 3]); if (cur.x < x - hw) faces.push([3, 0]);
        ctx.fillStyle = i || j ? '#4b4753' : '#5a5560';
        for (const f of faces) {
          ctx.beginPath(); ctx.moveTo(B[f[0]][0], B[f[0]][1]); ctx.lineTo(B[f[1]][0], B[f[1]][1]); ctx.lineTo(T[f[1]][0], T[f[1]][1]); ctx.lineTo(T[f[0]][0], T[f[0]][1]); ctx.closePath(); ctx.fill();
          ctx.strokeStyle = 'rgba(255,220,140,.18)'; ctx.lineWidth = 1; ctx.beginPath();   // 창문 줄
          for (let q = 1; q < 6; q++) { const f2 = q / 6; ctx.moveTo(B[f[0]][0] + (T[f[0]][0] - B[f[0]][0]) * f2, B[f[0]][1] + (T[f[0]][1] - B[f[0]][1]) * f2); ctx.lineTo(B[f[1]][0] + (T[f[1]][0] - B[f[1]][0]) * f2, B[f[1]][1] + (T[f[1]][1] - B[f[1]][1]) * f2); }
          ctx.stroke();
        }
      }
      ctx.fillStyle = i || j ? RC[hash3(i, j, 5) % RC.length] : '#a8a39a';
      ctx.beginPath(); T.forEach((p, k) => (k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(30,28,36,.55)'; ctx.lineWidth = Math.max(1, sT * 0.6); ctx.stroke();
      if ((i || j) && sT > 1.2) { // 옥상 소품
        const hv = hash3(i, j, 9);
        ctx.fillStyle = 'rgba(40,38,46,.5)';
        proj(x + ((hv % 20) - 10), y + (((hv >> 5) % 20) - 10), h); ctx.fillRect(PX - 2 * sT, PY - 1.5 * sT, 4 * sT, 3 * sT);
      }
    }
    function drawTarget(M) {
      const s = setH(0); if (!s) return;
      const lw = (px) => Math.max(px / s, 0.12);
      ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = lw(1.2); ctx.setLineDash([1.5, 1.5]);
      ctx.beginPath(); ctx.arc(0, 0, 25, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = M.loc === 'city' ? 'rgba(255,255,255,.08)' : 'rgba(255,255,255,.1)'; ctx.beginPath(); ctx.arc(0, 0, 10, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = lw(1.5); ctx.beginPath(); ctx.arc(0, 0, 10, 0, 7); ctx.stroke();
      ctx.fillStyle = M.loc === 'city' ? '#e3ae45' : '#f2e9d8';
      for (let q = 0; q < 4; q++) { ctx.save(); ctx.rotate(q * Math.PI / 2 + Math.PI / 4); ctx.fillRect(5.5, -0.75, 4, 1.5); ctx.restore(); }
      ctx.fillStyle = '#d8c08a'; ctx.beginPath(); ctx.arc(0, 0, 5, 0, 7); ctx.fill();
      ctx.strokeStyle = '#efe3c0'; ctx.lineWidth = Math.max(0.2, 1 / s); ctx.beginPath(); ctx.arc(0, 0, 2, 0, 7); ctx.stroke();
      ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.arc(0, 0, 0.5, 0, 7); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(0, 0, 0.18, 0, 7); ctx.fill();
      resetT();
    }
    function drawObstacles(M) {
      // 그림자 먼저
      const s0 = setH(0);
      if (s0) {
        ctx.fillStyle = 'rgba(10,20,10,.28)';
        for (const o of M.ob) {
          if (o.t === 1 || !o.h) continue;
          const ox = SUNX * o.h * 0.5, oy = SUNY * o.h * 0.5;
          ctx.beginPath();
          if (o.s) ctx.rect(o.x - o.w / 2 + ox, o.y - o.d / 2 + oy, o.w, o.d); else ctx.arc(o.x + ox, o.y + oy, o.r, 0, 7);
          ctx.fill();
        }
      }
      resetT();
      for (const o of M.ob) {
        if (o.t === 1) continue;
        const s = proj(o.x, o.y, o.h); if (!s) continue;
        const R0 = (o.r || Math.max(o.w, o.d)) * s;
        if (!onScr(R0 + 10)) continue;
        if (o.s) { // 상자: 보이는 옆면 + 지붕
          const cs = [[o.x - o.w / 2, o.y - o.d / 2], [o.x + o.w / 2, o.y - o.d / 2], [o.x + o.w / 2, o.y + o.d / 2], [o.x - o.w / 2, o.y + o.d / 2]];
          const B = cs.map((p) => { proj(p[0], p[1], 0); return [PX, PY]; }), T = cs.map((p) => { proj(p[0], p[1], o.h); return [PX, PY]; });
          const faces = [];
          if (cur.y < cs[0][1]) faces.push([0, 1]); if (cur.x > cs[1][0]) faces.push([1, 2]); if (cur.y > cs[2][1]) faces.push([2, 3]); if (cur.x < cs[0][0]) faces.push([3, 0]);
          ctx.fillStyle = o.t === 4 && o.c === 0 ? '#7a2f26' : '#55505c';
          for (const f of faces) { ctx.beginPath(); ctx.moveTo(B[f[0]][0], B[f[0]][1]); ctx.lineTo(B[f[1]][0], B[f[1]][1]); ctx.lineTo(T[f[1]][0], T[f[1]][1]); ctx.lineTo(T[f[0]][0], T[f[0]][1]); ctx.closePath(); ctx.fill(); }
          ctx.fillStyle = o.t === 4 && o.c === 0 ? '#a8443a' : o.t === 4 && o.c === 2 ? '#e8e2d6' : '#8b8794';
          ctx.beginPath(); T.forEach((p, k) => (k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill();
          if (o.t === 4 && o.c === 0) { ctx.strokeStyle = 'rgba(40,10,8,.5)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo((T[0][0] + T[3][0]) / 2, (T[0][1] + T[3][1]) / 2); ctx.lineTo((T[1][0] + T[2][0]) / 2, (T[1][1] + T[2][1]) / 2); ctx.stroke(); }
          if (o.t === 4 && o.c === 2) { ctx.fillStyle = '#ee6a55'; ctx.fillRect(T[0][0], T[0][1], (T[1][0] - T[0][0]) || 2, 3); }
          continue;
        }
        proj(o.x, o.y, o.h);
        const X = PX, Y = PY;
        if (o.t === 2) {
          if (o.c === 1) { // 야자수
            ctx.fillStyle = '#2f7d3a';
            for (let q = 0; q < 6; q++) { const a = q / 6 * 6.283 + o.x; ctx.beginPath(); ctx.ellipse(X + Math.cos(a) * R0 * 0.55, Y + Math.sin(a) * R0 * 0.55, R0 * 0.62, R0 * 0.2, a, 0, 7); ctx.fill(); }
            ctx.fillStyle = '#7a5a2e'; ctx.beginPath(); ctx.arc(X, Y, Math.max(1.5, R0 * 0.18), 0, 7); ctx.fill();
          } else {
            ctx.fillStyle = '#244d22'; ctx.beginPath(); ctx.arc(X, Y, R0, 0, 7); ctx.fill();
            ctx.fillStyle = '#336b2c'; ctx.beginPath(); ctx.arc(X - R0 * 0.18, Y - R0 * 0.18, R0 * 0.72, 0, 7); ctx.fill();
            ctx.fillStyle = 'rgba(140,200,110,.35)'; ctx.beginPath(); ctx.arc(X - R0 * 0.32, Y - R0 * 0.32, R0 * 0.32, 0, 7); ctx.fill();
          }
        } else if (o.t === 7) { // 파라솔
          const PC = [['#ee6a55', '#f2e9d8'], ['#5bb3e6', '#f2e9d8'], ['#e8c04e', '#e05a3a'], ['#5fd3a0', '#f2e9d8']][o.c || 0];
          ctx.fillStyle = PC[0]; ctx.beginPath(); ctx.arc(X, Y, R0, 0, 7); ctx.fill();
          ctx.fillStyle = PC[1];
          for (let q = 0; q < 4; q++) { ctx.beginPath(); ctx.moveTo(X, Y); ctx.arc(X, Y, R0, q * Math.PI / 2, q * Math.PI / 2 + Math.PI / 4); ctx.closePath(); ctx.fill(); }
        } else if (o.t === 3) { // 바위
          ctx.fillStyle = '#6b665e'; ctx.beginPath(); ctx.arc(X, Y, R0, 0, 7); ctx.fill();
          ctx.fillStyle = '#8d877c'; ctx.beginPath(); ctx.arc(X - R0 * 0.25, Y - R0 * 0.2, R0 * 0.6, 0, 7); ctx.fill();
        } else { // 사일로 · 물탱크
          ctx.fillStyle = o.t === 8 ? '#9aa3ad' : '#c9c2b4'; ctx.beginPath(); ctx.arc(X, Y, R0, 0, 7); ctx.fill();
          ctx.strokeStyle = 'rgba(40,40,50,.5)'; ctx.lineWidth = 1.2; ctx.stroke();
          ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.beginPath(); ctx.arc(X - R0 * 0.3, Y - R0 * 0.3, R0 * 0.35, 0, 7); ctx.fill();
        }
      }
    }
    function drawWindsock(M, J, run) {
      const x = 8.5, y = 8.5, hp = 5;
      const s0 = proj(x, y, 0); if (!s0) return;
      const bx = PX, by = PY;
      if (!proj(x, y, hp)) return;
      const tx = PX, ty = PY;
      if (!onScr(60)) return;
      windAt(run, 0, cur.k, AW);
      const sp0 = Math.hypot(AW.wx, AW.wy), len = 1 + 2.6 * clamp(sp0 / 5, 0.15, 1);
      const ux = sp0 > 0.05 ? AW.wx / sp0 : 1, uy = sp0 > 0.05 ? AW.wy / sp0 : 0;
      ctx.strokeStyle = '#d8d0c0'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(tx, ty); ctx.stroke();
      const seg = 4;
      for (let q = 0; q < seg; q++) {
        const f0 = q / seg, f1 = (q + 1) / seg, droop = (1 - clamp(sp0 / 5, 0, 1)) * 1.2;
        const wob = Math.sin(time * 8 + q) * 0.12;
        const pts = [];
        for (const [f, side] of [[f0, 1], [f1, 1], [f1, -1], [f0, -1]]) {
          const w = 0.45 * (1 - f * 0.55) * side;
          proj(x + ux * len * f - uy * (w + wob * f), y + uy * len * f + ux * (w + wob * f), hp - droop * f); pts.push([PX, PY]);
        }
        ctx.fillStyle = q % 2 ? '#f2e9d8' : '#ee6a55'; ctx.beginPath(); pts.forEach((p, k) => (k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath(); ctx.fill();
      }
    }
    function drawClouds(M, run) {
      if (cur.ph === -1) return;   // 계획 화면(비행기 안)에서는 구름이 가리지 않게
      for (const c of M.cl) {
        if (cur.a < c.h + 4) continue;
        const al = clamp((cur.a - c.h - 4) / 40, 0, 1) * 0.42;
        if (al <= 0.01) continue;
        windAt(run, c.h, -1, AW);
        const t = cur.k * DT;
        const s = proj(c.x + AW.wx * t, c.y + AW.wy * t, c.h); if (!s) continue;
        const R0 = c.r * s; if (!onScr(R0 * 1.6)) continue;
        ctx.fillStyle = 'rgba(252,253,255,' + al.toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(PX, PY, R0, 0, 7); ctx.arc(PX + R0 * 0.8, PY + R0 * 0.2, R0 * 0.7, 0, 7); ctx.arc(PX - R0 * 0.7, PY + R0 * 0.3, R0 * 0.6, 0, 7); ctx.fill();
      }
    }

    /* ---------- 점퍼 / 낙하산 (화면 고정, 위 = 진행 방향) ---------- */
    function drawJumper(seat) {
      const k = clamp(G.W / 400, 0.82, 1.15), col = color(seat);
      const x = cx, y = cy;
      if (cur.ph === -1) { drawPlane(x, y - 4, 1, k); return; }
      if (cur.ph === 0) {
        ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(time * 5) * 0.05 + (cur.bits & 1 ? -0.25 : cur.bits & 2 ? 0.25 : 0)); ctx.scale(k, k);
        ctx.strokeStyle = col; ctx.lineCap = 'round'; ctx.lineWidth = 5;
        ctx.beginPath(); ctx.moveTo(-4, -6); ctx.lineTo(-17, -16); ctx.moveTo(4, -6); ctx.lineTo(17, -16); ctx.stroke();   // 팔
        ctx.strokeStyle = '#2b2440'; ctx.lineWidth = 5.5;
        ctx.beginPath(); ctx.moveTo(-3, 7); ctx.lineTo(-11, 22); ctx.moveTo(3, 7); ctx.lineTo(11, 22); ctx.stroke();   // 다리
        ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, 0, 6.5, 10, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#3a3150'; ctx.fillRect(-5, -2, 10, 9);   // 배낭
        ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(0, -13, 4.6, 0, 7); ctx.fill();
        ctx.restore();
        return;
      }
      // 낙하산 (펴지는 중이면 크기 키움)
      let open = cur.ph === 1 ? clamp((cur.k - cur.ok) / OPT, 0.05, 1) : 1;
      if (cur.land) open = Math.max(0, 1 - cur.land * 1.2);
      const cw = 120 * k * (0.35 + 0.65 * open), ch = 40 * k * (0.5 + 0.5 * open), cyy = y - 34 * k - (cur.land ? cur.land * 30 * k : 0);
      // 줄
      ctx.strokeStyle = 'rgba(242,233,216,.55)'; ctx.lineWidth = 1;
      ctx.beginPath();
      for (let q = 0; q <= 4; q++) { const fx = x - cw / 2 + cw * q / 4; ctx.moveTo(fx, cyy + ch * 0.35); ctx.lineTo(x + (q - 2) * 2, y - 4); }
      ctx.stroke();
      // 사람
      ctx.save(); ctx.translate(x, y); ctx.scale(k, k);
      if (cur.land && cur.g >= 3) ctx.rotate(0.9);
      ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, 2, 6, 8, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#2b2440'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-3, 8); ctx.lineTo(-4, 16); ctx.moveTo(3, 8); ctx.lineTo(4, 16); ctx.stroke();
      ctx.strokeStyle = col; ctx.lineWidth = 3.5;
      const lb = cur.bits & 1 || cur.bits & 4 ? 6 : 0, rbb = cur.bits & 2 || cur.bits & 4 ? 6 : 0;
      ctx.beginPath(); ctx.moveTo(-5, -3); ctx.lineTo(-9, -12 + lb); ctx.moveTo(5, -3); ctx.lineTo(9, -12 + rbb); ctx.stroke();
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(0, -5, 4.2, 0, 7); ctx.fill();
      ctx.restore();
      if (open <= 0.02) return;
      // 날개(캐노피)
      ctx.save(); ctx.translate(x, cyy);
      const bank = cur.ph === 2 && !cur.land ? ((cur.bits & 3) === 1 ? -0.07 : (cur.bits & 3) === 2 ? 0.07 : 0) : 0;
      ctx.rotate(bank); ctx.globalAlpha = 0.25 + 0.75 * open;
      const cells = 7;
      ctx.fillStyle = 'rgba(0,0,0,.25)'; rr(-cw / 2 + 3, -ch / 2 + 5, cw, ch, ch * 0.4); ctx.fill();
      for (let q = 0; q < cells; q++) {
        const x0 = -cw / 2 + cw * q / cells, w = cw / cells + 0.6;
        ctx.fillStyle = q % 2 ? col : '#f2e9d8';
        const ed = q === 0 || q === cells - 1 ? ch * 0.18 : 0;
        ctx.fillRect(x0, -ch / 2 + ed, w, ch - ed * 2);
      }
      ctx.fillStyle = 'rgba(255,255,255,.28)'; ctx.fillRect(-cw / 2, -ch / 2 + 2, cw, ch * 0.22);   // 앞전 하이라이트
      const LT = (cur.bits & 1) || (cur.bits & 4), RT = (cur.bits & 2) || (cur.bits & 4);
      ctx.fillStyle = 'rgba(25,20,35,.55)';
      if (LT) ctx.fillRect(-cw / 2, ch / 2 - 7, cw * 0.32, 9);
      if (RT) ctx.fillRect(cw / 2 - cw * 0.32, ch / 2 - 7, cw * 0.32, 9);
      ctx.strokeStyle = 'rgba(20,16,28,.55)'; ctx.lineWidth = 1.2; rr(-cw / 2, -ch / 2, cw, ch, 6); ctx.stroke();
      ctx.restore();
    }
    function drawPlane(x, y, al, k) {
      ctx.save(); ctx.globalAlpha = al; ctx.translate(x, y); ctx.scale(k * 1.4, k * 1.4);
      ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.ellipse(6, 10, 9, 30, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#d9d3c6';
      ctx.beginPath(); ctx.ellipse(0, 0, 6, 30, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-36, -2); ctx.lineTo(36, -2); ctx.lineTo(36, 6); ctx.lineTo(-36, 6); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-13, 24); ctx.lineTo(13, 24); ctx.lineTo(13, 29); ctx.lineTo(-13, 29); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ee6a55'; ctx.fillRect(-36, -2, 6, 8); ctx.fillRect(30, -2, 6, 8);
      ctx.fillStyle = '#3a3150'; ctx.beginPath(); ctx.ellipse(0, -22, 3.6, 5, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.fillRect(-2, 8, 4, 8);
      const pr = time * 40;
      ctx.strokeStyle = 'rgba(40,36,52,.6)'; ctx.lineWidth = 1.5;
      for (const px of [-20, 20]) { ctx.beginPath(); ctx.moveTo(px + Math.cos(pr) * 7, -6 + Math.sin(pr) * 1.5); ctx.lineTo(px - Math.cos(pr) * 7, -6 - Math.sin(pr) * 1.5); ctx.stroke(); }
      ctx.restore();
    }
    function drawShadow() {
      if (cur.ph < 1 && !cur.land) return;
      const S = surf(cur.M, cur.x, cur.y), hh = cur.a - S.h;
      if (hh > 120) return;
      const s = setH(S.h); if (!s) return;
      ctx.translate(cur.x + SUNX * hh, cur.y + SUNY * hh); ctx.rotate(cur.th);
      if (cur.land) { const k = Math.max(0.12, 1 - cur.land); ctx.scale(k, k); }   // 접힌 낙하산은 그림자도 작게
      ctx.fillStyle = 'rgba(8,10,14,' + clamp(0.38 - hh / 400, 0.12, 0.38).toFixed(3) + ')';
      ctx.beginPath(); ctx.ellipse(0.8, 0, 1.4, 4, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(0, 0, 0.45, 0, 7); ctx.fill();
      resetT();
    }

    /* ---------- HUD (캔버스) ---------- */
    function drawAltimeter(run) {
      const A = G.alt, x0 = A.x, w = A.w, y0 = A.y0, y1 = A.y1;
      if (y1 - y0 < 120) return;
      const bx = x0 + 22, bw = 8, top0 = y0 + 10, bot0 = y1 - 10;
      const Y = (a) => bot0 - Math.sqrt(clamp(a, 0, EXIT) / EXIT) * (bot0 - top0);
      ctx.fillStyle = 'rgba(18,14,24,.78)'; rr(x0, y0, w, y1 - y0, 12); ctx.fill();
      ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.fillRect(bx, top0, bw, bot0 - top0);
      ctx.fillStyle = 'rgba(95,211,160,.85)'; ctx.fillRect(bx, Y(GOOD), bw, Y(LATE) - Y(GOOD));
      ctx.fillStyle = 'rgba(227,174,69,.85)'; ctx.fillRect(bx, Y(LATE), bw, Y(AAD) - Y(LATE));
      ctx.fillStyle = 'rgba(238,106,85,.9)'; ctx.fillRect(bx - 2, Y(AAD) - 1, bw + 4, 2);
      ctx.fillStyle = 'rgba(91,179,230,.9)'; ctx.fillRect(bx, Y(3), bw, bot0 - Y(3));
      ctx.font = '600 9px ' + MONO; ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ab9fb8';
      for (const v of [300, 160, 120, 90, 60, 20, 3]) ctx.fillText(String(v), bx - 3, Y(v));
      // 층마다 바람 화살표 (화면 기준: 위 = 내가 가는 방향)
      for (let i = 0; i < 4; i++) {
        const hh = HL[i] === 0 ? 1 : HL[i];
        windAt(run, hh, -1, AW);
        const spd = Math.hypot(AW.wx, AW.wy);
        const ay = HL[i] === 0 ? bot0 - 2 : Y(HL[i]);
        drawArrow(x0 + w - 11, ay, AW.wx, AW.wy, spd, 7, '#cfe8ff');
      }
      // 현재 고도
      const a = Math.max(0, cur.a), my = Y(a);
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(bx + bw + 1, my); ctx.lineTo(bx + bw + 8, my - 5); ctx.lineTo(bx + bw + 8, my + 5); ctx.closePath(); ctx.fill();
      ctx.fillRect(bx - 2, my - 1, bw + 4, 2);
      const t = Math.round(a) + 'm';
      ctx.font = '600 13px ' + MONO;
      const tw = ctx.measureText(t).width + 12, px = x0 + w + 4, py = clamp(my, y0 + 10, y1 - 10);
      ctx.fillStyle = 'rgba(18,14,24,.85)'; rr(px, py - 11, tw, 22, 8); ctx.fill();
      ctx.fillStyle = cur.ph === 0 ? (a > GOOD ? '#f2e9d8' : a > LATE ? '#5fd3a0' : '#ee6a55') : '#f2e9d8'; ctx.textAlign = 'left'; ctx.fillText(t, px + 6, py + 0.5);
      if (cur.ph >= 1 && cur.ph <= 2) { ctx.font = '600 10px ' + MONO; ctx.fillStyle = '#ab9fb8'; ctx.fillText('↓' + cur.vz.toFixed(1), px + 3, py + 19); }
    }
    function drawArrow(x, y, wx, wy, spd, r, col) {
      // 세계 방향 → 화면 방향 (proj와 같은 회전)
      const ux = wx * rc - wy * rs, uy = -(wx * rs + wy * rc), m = Math.hypot(ux, uy);
      ctx.save(); ctx.translate(x, y);
      if (m < 0.05 || spd < 0.3) { ctx.fillStyle = '#ab9fb8'; ctx.beginPath(); ctx.arc(0, 0, 2, 0, 7); ctx.fill(); ctx.restore(); return; }
      ctx.rotate(Math.atan2(uy, ux));
      const len = r * (0.6 + 0.5 * clamp(spd / 9, 0, 1));
      ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 2; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-len, 0); ctx.lineTo(len - 3, 0); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(len + 1, 0); ctx.lineTo(len - 5, -4); ctx.lineTo(len - 5, 4); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    function drawWindBox(run) {
      const x0 = 8, y0 = G.topH + 4, w = 104, h = 54;
      ctx.fillStyle = 'rgba(18,14,24,.84)'; rr(x0, y0, w, h, 12); ctx.fill();
      windAt(run, Math.max(1, cur.a), cur.k, AW);
      const spd = Math.hypot(AW.wx, AW.wy);
      // 내 진행 방향 기준 성분
      const fx = Math.cos(cur.th), fy = Math.sin(cur.th), along = AW.wx * fx + AW.wy * fy, side = Math.abs(AW.wx * -fy + AW.wy * fx);
      const kind = spd < 0.6 ? '바람 약함' : Math.abs(along) >= side ? (along < 0 ? '맞바람' : '뒷바람') : '옆바람';
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ab9fb8'; ctx.font = '700 11px ' + FONT; ctx.fillText('지금 ' + kind, x0 + 9, y0 + 14);
      ctx.fillStyle = '#f2e9d8'; ctx.font = '600 17px ' + MONO; ctx.fillText(spd.toFixed(1), x0 + 9, y0 + 36);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 10px ' + MONO; ctx.fillText('m/s', x0 + 44, y0 + 38);
      ctx.fillStyle = 'rgba(242,233,216,.08)'; ctx.beginPath(); ctx.arc(x0 + w - 22, y0 + h / 2, 17, 0, 7); ctx.fill();
      drawArrow(x0 + w - 22, y0 + h / 2, AW.wx, AW.wy, spd, 13, '#cfe8ff');
    }
    function drawMap(M, J) {
      const S = G.mapS, x0 = G.W - S - 8, y0 = G.topH + 4, mx = x0 + S / 2, my = y0 + S / 2, R0 = S / 2 - 3;
      const dist = Math.hypot(cur.x, cur.y), rng = clamp(dist * 1.35, 45, 420), k = R0 / rng;
      const P = (x, y) => { const dx = (x - cur.x) * k, dy = (y - cur.y) * k; return [mx + dx * rc - dy * rs, my - (dx * rs + dy * rc)]; };
      ctx.save();
      ctx.fillStyle = 'rgba(18,14,24,.88)'; ctx.beginPath(); ctx.arc(mx, my, S / 2, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(mx, my, R0, 0, 7); ctx.clip();
      ctx.fillStyle = M.loc === 'beach' ? '#6d6448' : M.loc === 'city' ? '#2e2d36' : M.loc === 'summit' ? '#2c4130' : '#35512a';
      ctx.fillRect(x0, y0, S, S);
      if (M.loc === 'beach' && M.shore) {
        ctx.fillStyle = '#1f5f83'; ctx.beginPath();
        const sh = M.shore, Sx = M.sea;
        sh.forEach((p, i) => { const q = P(p[0], p[1]); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); });
        let q = P(sh[sh.length - 1][0] + Sx.nx * 2000, sh[sh.length - 1][1] + Sx.ny * 2000); ctx.lineTo(q[0], q[1]);
        q = P(sh[0][0] + Sx.nx * 2000, sh[0][1] + Sx.ny * 2000); ctx.lineTo(q[0], q[1]); ctx.closePath(); ctx.fill();
      } else if (M.loc === 'summit' && M.cont) {
        ctx.fillStyle = '#7d7a68'; ctx.beginPath(); M.cont[6].pts.forEach((p, i) => { const q = P(p[0], p[1]); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }); ctx.closePath(); ctx.fill();
      } else if (M.loc === 'city') {
        const n = Math.ceil(rng / 60) + 1, bx = Math.round(cur.x / 60), by = Math.round(cur.y / 60);
        for (let i = bx - n; i <= bx + n; i++) for (let j = by - n; j <= by + n; j++) {
          const h = i || j ? bldH(M, i, j) : 0;
          ctx.fillStyle = !i && !j ? '#a8a39a' : h > 0 ? '#8a8494' : '#5d5866';
          const c = [P(i * 60 - 23, j * 60 - 23), P(i * 60 + 23, j * 60 - 23), P(i * 60 + 23, j * 60 + 23), P(i * 60 - 23, j * 60 + 23)];
          ctx.beginPath(); c.forEach((q, t) => (t ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); ctx.fill();
        }
      }
      for (const o of M.ob) {
        const q = P(o.x, o.y), r = Math.max(1.3, (o.r || Math.max(o.w, o.d) / 2) * k);
        ctx.fillStyle = o.t === 1 ? '#2f7fb0' : o.t === 2 ? '#1f4a1e' : o.t === 7 ? '#ee6a55' : '#9a8f7f';
        ctx.beginPath(); ctx.arc(q[0], q[1], r, 0, 7); ctx.fill();
      }
      const tq = P(0, 0);
      ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(tq[0], tq[1], Math.max(3, 10 * k), 0, 7); ctx.stroke();
      ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.arc(tq[0], tq[1], 2.2, 0, 7); ctx.fill();
      ctx.restore();
      // 북쪽 표시
      const nx = mx - rs * (S / 2 - 7), ny = my - rc * (S / 2 - 7);
      ctx.font = '700 9px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#e3ae45'; ctx.fillText('N', nx, ny);
      // 나
      ctx.fillStyle = color(anim ? anim.seat : actor(st)); ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(mx, my - 6); ctx.lineTo(mx + 4.5, my + 4.5); ctx.lineTo(mx, my + 2); ctx.lineTo(mx - 4.5, my + 4.5); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.font = '600 9px ' + MONO; ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(mx - 20, y0 + S + 1, 40, 14, 7); ctx.fill(); ctx.fillStyle = '#ab9fb8'; ctx.fillText('반경 ' + Math.round(rng) + 'm', mx, y0 + S + 8.5);
      ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(mx, my, S / 2 - 0.5, 0, 7); ctx.stroke();
    }
    function drawInfo(s, li, seatIdx) {
      const t1 = s.ph === 'e' && !anim ? '경기 끝' : (s.R > 1 ? ((anim ? anim.r : s.r) + 1) + 'R · ' : '') + LNAME[li];
      const t2 = s.ph === 'e' && !anim ? '' : (seatIdx + 1) + '/' + s.n + '번째';
      const x0 = 8 + 104 + 6, x1 = G.W - G.mapS - 14, w = x1 - x0;
      if (w < 70) return;
      const cxx = (x0 + x1) / 2, y0 = G.topH + 4;
      ctx.fillStyle = 'rgba(18,14,24,.84)'; rr(cxx - Math.min(w, 140) / 2, y0, Math.min(w, 140), t2 ? 42 : 26, 12); ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 12px ' + FONT; ctx.fillText(t1, cxx, y0 + 13, w - 10);
      if (t2) { ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px ' + FONT; ctx.fillText(t2, cxx, y0 + 30); }
    }
    function hint(text, col) {
      ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const w = Math.min(G.W - 20, ctx.measureText(text).width + 26), x = G.W / 2, y = G.botY - 22;
      ctx.fillStyle = 'rgba(18,14,24,.86)'; rr(x - w / 2, y - 13, w, 26, 13); ctx.fill();
      ctx.fillStyle = col || '#f2e9d8'; ctx.fillText(text, x, y + 0.5, w - 14);
    }
    function drawTargetPointer() {
      if (!proj(0, 0, 0)) return;
      const m = 26, inside = PX > m && PX < G.W - m && PY > G.topH + 70 && PY < G.botY - 50;
      const d = Math.hypot(cur.x, cur.y);
      if (inside) {
        if (d > 30 && cur.a > 30) {
          ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(PX - 22, PY - 30, 44, 18, 9); ctx.fill();
          ctx.fillStyle = '#e3ae45'; ctx.fillText('과녁', PX, PY - 21);
        }
        return;
      }
      const ang = Math.atan2(PY - cy, PX - cx);
      // 가장자리 교점 근사
      const xl = G.alt.x + G.alt.w + 72, xr = G.W - m, yt = G.topH + G.mapS + 40, yb = G.botY - 56;   // 고도계·지도·안내 줄을 피한 테두리
      const tx = Math.abs(Math.cos(ang)) > 1e-3 ? ((Math.cos(ang) > 0 ? xr : xl) - cx) / Math.cos(ang) : 1e9;
      const ty = Math.abs(Math.sin(ang)) > 1e-3 ? ((Math.sin(ang) > 0 ? yb : yt) - cy) / Math.sin(ang) : 1e9;
      const t = Math.min(Math.abs(tx), Math.abs(ty));
      const ax = clamp(cx + Math.cos(ang) * t, xl, xr), ay = clamp(cy + Math.sin(ang) * t, yt, yb);
      ctx.save(); ctx.translate(ax, ay); ctx.rotate(ang);
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.moveTo(29, 0); ctx.lineTo(17, -8); ctx.lineTo(17, 8); ctx.closePath(); ctx.fill();
      ctx.restore();
      ctx.fillStyle = 'rgba(18,14,24,.88)'; ctx.beginPath(); ctx.arc(ax, ay, 19, 0, 7); ctx.fill();
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.font = '600 11px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
      ctx.fillText(Math.round(d) + 'm', ax, ay + 0.5, 34);
    }
    function drawStreaks(dt) {
      if (cur.ph !== 0 || !anim || anim.ph !== 'fly') return;
      ctx.strokeStyle = 'rgba(242,233,216,.22)'; ctx.lineWidth = 1.2;
      const R = Math.hypot(G.W, G.H) / 2;
      ctx.beginPath();
      for (const q of streaks) {
        q.d += dt * q.v * sp() * 1.4; if (q.d > 1) { q.d = 0.15; q.a = Math.random() * 6.3; }
        const r0 = 40 + q.d * R, r1 = r0 + 30 * q.v;
        ctx.moveTo(cx + Math.cos(q.a) * r0, cy + Math.sin(q.a) * r0); ctx.lineTo(cx + Math.cos(q.a) * r1, cy + Math.sin(q.a) * r1);
      }
      ctx.stroke();
    }
    function drawPops() {
      for (const p of pops) {
        const a = p.t < 0.1 ? p.t / 0.1 : p.t > p.life - 0.25 ? Math.max(0, (p.life - p.t) / 0.25) : 1;
        ctx.save(); ctx.globalAlpha = a;
        ctx.font = '400 ' + (p.big ? 30 : 20) + 'px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const y = G.topH + (G.botY - G.topH) * (p.big ? 0.3 : 0.38) - Math.min(1, p.t / 0.2) * 6;
        ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(18,14,24,.85)'; ctx.strokeText(p.text, G.W / 2, y);
        ctx.fillStyle = p.col; ctx.fillText(p.text, G.W / 2, y);
        ctx.restore();
      }
    }
    function pop(text, col, big, life) { pops = pops.filter((p) => p.big !== !!big); pops.push({ text, col, big: !!big, t: 0, life: (life || 1.2) / Math.sqrt(sp()) }); }

    /* ---------- 점수 카드 ---------- */
    function drawCard(l, k) {
      const { W } = G, cw = Math.min(W - 28, 330), rows = 3 + l.pen.length, ch = 128 + rows * 22, x0 = (W - cw) / 2;
      const y0 = Math.max(G.topH + 8, G.topH + (G.botY - G.topH) * 0.46 - ch / 2);
      const a = Math.min(1, k * 6);
      ctx.save(); ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(18,14,24,.94)'; rr(x0, y0 + (1 - a) * 12, cw, ch, 16); ctx.fill();
      ctx.strokeStyle = color(l.s); ctx.lineWidth = 2; ctx.stroke();
      const cx0 = x0 + 18; let y = y0 + 24;
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillStyle = color(l.s); ctx.beginPath(); ctx.arc(cx0 + 5, y, 5, 0, 7); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 14px ' + FONT; ctx.fillText(pname(l.s), cx0 + 16, y, cw * 0.5);
      ctx.textAlign = 'right'; ctx.fillStyle = l.g >= 3 ? '#ee6a55' : l.g === 0 ? '#5fd3a0' : '#e3ae45';
      ctx.font = '700 12px ' + FONT; ctx.fillText(GN[l.g], x0 + cw - 18, y);
      y += 38;
      ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.font = '600 34px ' + MONO;
      const dt = l.d.toFixed(1); ctx.fillText(dt, cx0, y);
      const dw = ctx.measureText(dt).width;
      ctx.font = '600 13px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('m 떨어짐', cx0 + dw + 5, y + 6);
      ctx.textAlign = 'right'; ctx.font = '700 11px ' + FONT;
      ctx.fillText(LNAME[l.li] + (l.oa ? ' · ' + l.oa + 'm에서 펼침' : ''), x0 + cw - 18, y - 16, cw * 0.45);
      y += 34;
      const row = (lab, val, col) => {
        ctx.textAlign = 'left'; ctx.fillStyle = '#ab9fb8'; ctx.font = '700 12px ' + FONT; ctx.fillText(lab, cx0, y);
        ctx.textAlign = 'right'; ctx.fillStyle = col || '#f2e9d8'; ctx.font = '600 14px ' + MONO; ctx.fillText(val, x0 + cw - 18, y);
        y += 22;
      };
      row('거리 점수', String(l.dp));
      row('착지 점수 · ' + GN[l.g], String(l.lp));
      for (const c of l.pen) row('감점 · ' + SN[c], '−' + SPEN[c], '#ee6a55');
      ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.fillRect(cx0, y - 10, cw - 36, 1);
      y += 12;
      ctx.textAlign = 'left'; ctx.fillStyle = '#ab9fb8'; ctx.font = '700 12px ' + FONT;
      const rank = st ? rankOrder(st).indexOf(l.s) + 1 : 0;
      ctx.fillText('합계 ' + (st ? st.tot[l.s] : '') + (st && st.n > 1 ? ' · 현재 ' + rank + '위' : ''), cx0, y);
      ctx.textAlign = 'right'; ctx.fillStyle = '#e3ae45'; ctx.font = '400 26px ' + DISP; ctx.fillText(l.p + '점', x0 + cw - 18, y);
      if (k > 0.4) {
        ctx.font = '600 11px ' + FONT; ctx.textAlign = 'center';
        const tw = ctx.measureText('탭하면 넘기기').width + 20;
        ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(W / 2 - tw / 2, y0 + ch + 6, tw, 22, 11); ctx.fill();
        ctx.fillStyle = '#ab9fb8'; ctx.fillText('탭하면 넘기기', W / 2, y0 + ch + 17.5);
      }
      ctx.restore();
    }

    /* ---------- 위 점수판 (DOM) ---------- */
    let hudKey = '';
    function renderTop(s, curSeat) {
      if (!s) return;
      const key = JSON.stringify([s.tot, s.js.map((j) => j.length), curSeat, s.ph]);
      if (key === hudKey) return;
      hudKey = key;
      top.innerHTML = '';
      const rk = rankOrder(s);
      for (let i = 0; i < s.n; i++) {
        const p = api.players[i] || { name: s.nm[i], color: '#fff' }, on = curSeat === i;
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '6px 8px', display: 'flex', flexDirection: 'column', gap: '3px', opacity: on || curSeat == null ? 1 : 0.68, borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color + ' inset' : '' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
            L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto' }, text: p.name }),
            s.n > 1 && s.js[i].length ? L.h('span', { class: 'mono muted', style: { fontSize: '10px', flex: 'none' }, text: (rk.indexOf(i) + 1) + '위' }) : null),
          L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '3px' } },
            L.h('span', { class: 'mono', style: { fontSize: s.n > 3 ? '17px' : '20px', fontWeight: 600, lineHeight: 1 }, text: String(s.tot[i]) }),
            L.h('span', { class: 'muted', style: { fontSize: '10px', fontWeight: 700 }, text: '점' })),
          L.h('div', { class: 'mono muted', style: { fontSize: '10px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minHeight: '13px' }, text: s.js[i].map((j) => String(j[0])).join(' · ') || '—' })));
      }
      requestAnimationFrame(measure);
    }
    function renderBar() {
      const vis = showBar();
      const a = anim, live = a && a.mode === 'live';
      let lab = '기다리는 중', sub = '', on = false, glow = false;
      if (a && !live) { lab = a.ph === 'card' ? '다음' : '건너뛰기'; on = true; }
      else if (live) {
        on = true;
        if (a.ph === 'ready') { lab = '뛰어내리기'; sub = '탭'; glow = true; }
        else if (a.ph === 'fly') {
          const r = a.run;
          if (r.ph === 0 && a.rec.o < 0) { lab = '낙하산 펴기'; sub = r.a <= GOOD ? '지금!' : ''; glow = r.a <= GOOD; }
          else if (r.ph < 2) { lab = '펴지는 중'; on = false; }
          else { lab = '브레이크'; sub = '꾹 누르기'; glow = r.a - surf(a.M, r.x, r.y).h < 4; }
        } else { lab = '다음'; sub = ''; on = a.ph === 'card'; }
      }
      const key = [vis, lab, sub, on, glow, live && a.ph === 'fly'].join('|');
      if (key === barKey) return;
      barKey = key;
      bar.style.display = vis ? 'flex' : 'none';
      bB.innerHTML = '<span style="font-family:var(--f-display);font-weight:400;font-size:19px">' + lab + '</span>' + (sub ? '<span style="font-size:11px;opacity:.8">' + sub + '</span>' : '');
      const steer = live && a.ph === 'fly';
      for (const b of [bL, bR]) { b.style.opacity = steer ? '1' : '0.4'; b.style.pointerEvents = steer ? 'auto' : 'none'; }
      bB.style.opacity = on ? '1' : '0.45'; bB.style.pointerEvents = on ? 'auto' : 'none';
      bB.style.boxShadow = glow ? '0 0 0 3px rgba(95,211,160,.85), 0 0 18px rgba(95,211,160,.5)' : '';
      requestAnimationFrame(measure);
    }
    let lookKey = '';
    function pressedLook() {
      const kb = api.input || { held: () => false };
      const l = held('l') || kb.held('left'), r = held('r') || kb.held('right'), b = held('b') || kb.held('brake');
      const key = '' + +l + +r + +b;
      if (key === lookKey) return;
      lookKey = key;
      bL.style.filter = l ? 'brightness(1.45)' : '';
      bR.style.filter = r ? 'brightness(1.45)' : '';
      bB.style.filter = b ? 'brightness(1.2)' : '';
    }

    /* ---------- 애니메이션 ---------- */
    function startLive() {
      const seat = actor(st), M = genMap(st.lc[st.r], st.rsd[st.r]);
      anim = { mode: 'live', ph: 'ready', seat, r: st.r, li: st.lc[st.r], J: st.J, M, run: newRun(st.J), rec: { o: -1, ev: [] }, bits: 0, latch: false, acc: 0, t: 0, snap: st, seq: st.seq };
    }
    function startReplay(l, prev) {
      const M = genMap(l.li, l.rsd), J = l.J, path = [];
      const r = simulate(J, M, { o: l.o, ev: l.ev }, (rn, bits) => path.push([rn.x, rn.y, rn.a, rn.th, rn.ph, bits, rn.vz, rn.k, rn.ok]));
      anim = { mode: 'replay', ph: 'fly', seat: l.s, r: l.r, li: l.li, J, M, path, pi: 0, run: r, last: l, snap: prev || st, t: 0 };
      api.setBusy(true);
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim && anim.last === l) endAnim(); }, 60000);
    }
    function endAnim() {
      anim = null; clearTimeout(waitTimer); pops = []; parts = [];
      hudKey = ''; renderTop(st, st ? actor(st) : null);
      api.setBusy(false);
    }
    function toOut(r, l) {
      const a = anim;
      a.ph = 'out'; a.t = 0; a.land = { x: l ? l.lx / 10 : r.lx, y: l ? l.ly / 10 : r.ly, h: r.lh, t: r.lt, g: l ? l.g : (SFAIL[r.lt] ? 4 : grade(r.lvz, r.lgs)), th: r.th };
      const water = r.lt === 1;
      for (let i = 0; i < 26; i++) { const an = Math.random() * 6.3, v = 30 + Math.random() * 70; parts.push({ x: 0, y: 0, vx: Math.cos(an) * v, vy: Math.sin(an) * v, t: 0, life: 0.5 + Math.random() * 0.5, c: water ? 'rgba(200,235,255,.9)' : 'rgba(220,205,170,.85)' }); }
      api.sfx(a.land.g >= 3 ? 'hit' : 'thud'); api.buzz(a.land.g >= 3 ? 40 : 20);
      const d = Math.hypot(a.land.x, a.land.y);
      pop(d < 0.5 ? '정중앙!' : d.toFixed(1) + ' m', d < 0.5 ? '#e3ae45' : '#f2e9d8', true, 1.6);
      const g = a.land.g;
      setTimeout(() => { if (anim === a) pop(r.lt ? SN[r.lt] : GN[g] + (g === 0 ? '!' : ''), r.lt || g >= 3 ? '#ee6a55' : g === 0 ? '#5fd3a0' : '#e3ae45', false, 1.3); }, 260 / sp());
      if (g === 0 && !r.lt) setTimeout(() => api.sfx('pop'), 120);
    }
    function liveLanded() {
      const a = anim, r = a.run;
      toOut(r, null);
      myPend = { seq: st.seq, seat: a.seat };
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim === a && !a.last) endAnim(); }, 6000);
      api.act({ type: 'jump', o: a.rec.o, ev: a.rec.ev.slice() });
    }
    function held(k) { for (const v of ptrs.values()) if (v === k) return true; return false; }
    function liveBits() {
      const inp = api.input;
      const l = held('l') || (inp && inp.held('left')), r = held('r') || (inp && inp.held('right'));
      const b0 = held('b') || (inp && inp.held('brake'));
      const a = anim;
      if (a.latch && !b0) a.latch = false;
      const b = b0 && !a.latch && a.run.ph === 2;
      return (l ? 1 : 0) | (r ? 2 : 0) | (b ? 4 : 0);
    }
    function liveStep(dt) {
      const a = anim;
      if (a.ph !== 'fly') return;
      a.t += dt;
      a.acc += dt * sp() / DT;
      const r = a.run;
      let guard = 0;
      while (a.acc >= 1 && r.T < 0 && guard++ < 40) {
        a.acc -= 1;
        const nb = liveBits();
        if (nb !== a.bits && a.rec.ev.length < MAXEV) {
          const last = a.rec.ev[a.rec.ev.length - 1];
          if (last != null && (last >> 3) === r.k) a.rec.ev[a.rec.ev.length - 1] = r.k * 8 + nb; else a.rec.ev.push(r.k * 8 + nb);
          a.bits = nb;
        }
        const wasPh = r.ph;
        step(r, a.M, a.bits, a.rec.o >= 0 && r.k >= a.rec.o);
        if (wasPh === 0 && r.ph === 1) {
          api.sfx('whoosh'); api.buzz(30);
          if (r.aad) pop('자동 펼침! −30', '#ee6a55'); else if (r.oa < LATE) pop('늦게 펼침 −10', '#e3ae45'); else pop('낙하산 펼침', '#5fd3a0');
        }
        if (wasPh === 1 && r.ph === 2) api.sfx('pop');
      }
      if (a.acc > 4) a.acc = 0;
      if (r.T >= 0) liveLanded();
    }
    function replayStep(dt) {
      const a = anim;
      if (a.ph !== 'fly') return;
      const prevI = Math.floor(a.pi);
      a.pi += dt * sp() * 2 / DT;
      const i = Math.min(a.path.length - 1, Math.floor(a.pi));
      const p0 = a.path[prevI], p1 = a.path[i];
      if (p0 && p1 && p0[4] === 0 && p1[4] === 1) { api.sfx('whoosh'); const oa = a.last.oa; pop(oa < AAD + 1 ? '자동 펼침! −30' : oa < LATE ? '늦게 펼침 −10' : '낙하산 펼침 · ' + oa + 'm', oa < LATE ? '#ee6a55' : '#5fd3a0'); }
      if (a.pi >= a.path.length - 1) toOut(a.run, a.last);
    }
    function toCard(a) { a.ph = 'card'; a.ct = 0; pops = []; api.sfx('chip'); hudKey = ''; renderTop(st, a.seat); }
    function skip() {
      const a = anim; if (!a) return;
      if (a.mode === 'replay' && a.ph === 'fly') { a.pi = a.path.length; replayStep(0); }
      else if (a.ph === 'out' && a.last) toCard(a);
      else if (a.ph === 'card' && a.ct > 0.35) endAnim();
    }
    function action() {   // 가운데 버튼 / 브레이크 키
      const a = anim;
      if (!a) return;
      if (a.mode === 'replay' || a.ph === 'out' || a.ph === 'card') { skip(); return; }
      if (a.ph === 'ready') {
        a.ph = 'fly'; a.t = 0; a.acc = 0; a.latch = true; api.setBusy(true); api.sfx('whoosh'); api.buzz(12);
        return;
      }
      if (a.ph === 'fly' && a.run.ph === 0 && a.rec.o < 0) { a.rec.o = a.run.k; a.latch = true; api.sfx('click'); api.buzz(16); }
    }

    /* ---------- 카메라 상태 ---------- */
    function setCur() {
      const a = anim;
      let M, J, run;
      if (a) { M = a.M; J = a.J; run = a.run; }
      else {
        if (!st || !st.J || st.ph === 'e') { const l = st && st.last; if (!l) return null; M = genMap(l.li, l.rsd); J = l.J; }
        else { M = genMap(st.lc[st.r], st.rsd[st.r]); J = st.J; }
        run = newRun(J);
      }
      cur.M = M; cur.J = J; cur.land = 0; cur.g = 0;
      if (!a || (a.mode === 'live' && a.ph === 'ready')) {
        cur.x = J.ex; cur.y = J.ey; cur.a = EXIT; cur.th = J.eh * DEG; cur.ph = -1; cur.bits = 0; cur.vz = 0; cur.k = 0; cur.ok = -1;
        if (!a && st && st.ph === 'e' && st.last) { const l = st.last; cur.x = l.lx / 10; cur.y = l.ly / 10; cur.a = 0; cur.th = l.J.eh * DEG; cur.ph = 2; cur.land = 1; cur.g = l.g; }
      } else if (a.ph === 'out' || a.ph === 'card') {
        const ld = a.land;
        cur.x = ld.x; cur.y = ld.y; cur.a = ld.h; cur.th = a.run.th; cur.ph = 2; cur.bits = 0; cur.vz = 0; cur.k = a.run.k; cur.ok = a.run.ok;
        cur.land = Math.min(1, a.t * 1.4 + (a.ph === 'card' ? 1 : 0)); cur.g = ld.g;
      } else if (a.mode === 'live') {
        const r = a.run, f = clamp(a.acc, 0, 1);
        cur.x = r.px + (r.x - r.px) * f; cur.y = r.py + (r.y - r.py) * f; cur.a = r.pa + (r.a - r.pa) * f; cur.th = r.pth + wrap(r.th - r.pth) * f;
        cur.ph = r.ph; cur.bits = a.bits; cur.vz = r.vz; cur.k = r.k; cur.ok = r.ok;
      } else {
        const n = a.path.length, i = Math.min(n - 1, Math.floor(a.pi)), j = Math.min(n - 1, i + 1), f = clamp(a.pi - i, 0, 1), p = a.path[i], q = a.path[j];
        cur.x = p[0] + (q[0] - p[0]) * f; cur.y = p[1] + (q[1] - p[1]) * f; cur.a = p[2] + (q[2] - p[2]) * f; cur.th = p[3] + wrap(q[3] - p[3]) * f;
        cur.ph = p[4]; cur.bits = p[5]; cur.vz = p[6]; cur.k = p[7]; cur.ok = p[8];
      }
      return run;
    }

    const stopLoop = U.loop((dt) => {
      time += dt;
      if (!G || !st) return;
      if (!anim && humanTurn()) startLive();
      if (anim) {
        if (anim.mode === 'live') liveStep(dt); else replayStep(dt);
        if (anim && (anim.ph === 'out' || anim.ph === 'card')) {
          const a = anim; a.t += dt * sp();
          if (a.ph === 'out' && a.t > 1.5 && a.last) toCard(a);
          if (a.ph === 'card') { a.ct += dt * sp(); if (a.ct > 3.6) endAnim(); }
        }
      }
      for (const p of pops) p.t += dt;
      pops = pops.filter((p) => p.t < p.life);
      for (const p of parts) { p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.93; p.vy *= 0.93; }
      parts = parts.filter((p) => p.t < p.life);
      renderBar(); pressedLook();
      draw(dt);
    });

    function draw(dt) {
      cv.clear();
      const run = setCur();
      if (!run) return;
      const { W, H } = G;
      F = Math.min(W, H) * 0.72;
      cx = W / 2 + 10; cy = G.topH + (G.botY - G.topH) * 0.6;
      const R0 = Math.PI / 2 - cur.th; rc = Math.cos(R0); rs = Math.sin(R0);
      const M = cur.M;
      drawGround(M);
      drawTarget(M);
      drawShadow();
      drawWindsock(M, cur.J, run);
      drawObstacles(M);
      resetT();
      // 다른 사람들 이번 라운드 착지 자국
      const bs = anim ? anim.snap : st;
      if (bs && bs.last && bs.last.r === (anim ? anim.r : bs.r) && !(anim && anim.mode === 'replay' && anim.last === bs.last)) {
        const l = bs.last;
        if (proj(l.lx / 10, l.ly / 10, 0) && onScr(10)) { ctx.fillStyle = color(l.s); ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(PX, PY, 5, 0, 7); ctx.fill(); ctx.stroke(); }
      }
      drawClouds(M, run);
      drawStreaks(dt);
      // 착지 먼지·물보라
      for (const p of parts) { ctx.globalAlpha = 1 - p.t / p.life; ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(cx + p.x, cy + p.y, 3, 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
      const seat = anim ? anim.seat : actor(st);
      if (seat != null || cur.land) drawJumper(seat != null ? seat : st.last ? st.last.s : 0);
      if (anim && anim.mode === 'live' && anim.ph === 'fly' && anim.t < 1.4) drawPlane(cx, cy - 20 - anim.t * 160, 1 - anim.t / 1.4, clamp(G.W / 400, 0.82, 1.15) * (1 - anim.t * 0.35));
      drawTargetPointer();
      drawWindBox(run);
      drawMap(M, cur.J);
      drawInfo(anim ? anim.snap : st, anim ? anim.li : st.ph === 'e' ? (st.last ? st.last.li : 0) : st.lc[st.r], anim ? (anim.snap.i) : st.i);
      drawAltimeter(run);
      // 안내
      const a = anim;
      if (a && a.mode === 'live') {
        const r = a.run;
        if (a.ph === 'ready') hint('바람과 과녁을 보고 「뛰어내리기」', '#e3ae45');
        else if (a.ph === 'fly') {
          const gh = r.a - surf(M, r.x, r.y).h, d = Math.round(Math.hypot(r.x, r.y));
          if (r.ph === 0 && a.rec.o < 0) hint(r.a > GOOD ? '초록 칸(160~120m)에서 「낙하산 펴기」 · ◀▶ 방향' : r.a > LATE ? '지금 펴세요!' : '늦었어요! 바로 펴기', r.a > GOOD ? '#f2e9d8' : r.a > LATE ? '#5fd3a0' : '#ee6a55');
          else if (r.ph < 2) hint('낙하산이 펴지는 중…', '#ab9fb8');
          else if (a.bits & 4 && gh < 10) hint('브레이크!', '#5fd3a0');
          else if (gh < 3.5) hint('지금 브레이크 꾹!', '#5fd3a0');
          else if (gh < 25) hint('그림자가 몸에 닿기 직전 브레이크 · 과녁 ' + d + 'm', '#e3ae45');
          else hint('◀ ▶ 로 방향 · 과녁까지 ' + d + 'm', '#f2e9d8');
        }
      } else if (a && a.mode === 'replay' && a.ph === 'fly') hint(pname(a.seat) + ' 강하 중 · 탭하면 건너뛰기', '#ab9fb8');
      else if (!a && st.ph !== 'e') { const s0 = actor(st), p = api.players[s0]; if (p && !api.canAct(s0)) hint(p.name + (p.ai ? ' 준비 중…' : ' 차례'), '#ab9fb8'); }
      drawPops();
      if (a && a.ph === 'card' && a.last) drawCard(a.last, a.ct);
    }

    /* ---------- 입력 ---------- */
    const el = cv.cv;
    function onDown(ev) {
      if (!G || !st) return;
      ev.preventDefault();
      const a = anim;
      if (!a) return;
      if (a.mode === 'replay' || a.ph === 'out' || a.ph === 'card') { skip(); return; }
      if (a.ph === 'ready') { action(); return; }
      if (a.ph === 'fly') {
        try { el.setPointerCapture(ev.pointerId); } catch (e) {}
        const p = cv.local(ev);
        ptrs.set(ev.pointerId, p.x < G.W / 2 ? 'l' : 'r');
        api.buzz(5);
      }
    }
    function onUp(ev) { ptrs.delete(ev.pointerId); }
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);
    el.addEventListener('lostpointercapture', onUp);
    const btnOff = [];
    function bindHold(btn, kind) {
      const down = (e) => {
        e.preventDefault(); e.stopPropagation();
        try { btn.setPointerCapture(e.pointerId); } catch (er) {}
        ptrs.set(e.pointerId, kind);
        if (kind === 'b') action(); else api.buzz(5);
      };
      const up = (e) => { if (ptrs.get(e.pointerId) === kind) ptrs.delete(e.pointerId); };
      btn.addEventListener('pointerdown', down);
      ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((n) => btn.addEventListener(n, up));
      btn.addEventListener('contextmenu', (e) => e.preventDefault());
      btnOff.push(() => { btn.removeEventListener('pointerdown', down); ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((n) => btn.removeEventListener(n, up)); });
    }
    bindHold(bL, 'l'); bindHold(bB, 'b'); bindHold(bR, 'r');
    const offKey = api.input && api.input.on ? api.input.on((type, id) => { if (type === 'down' && id === 'brake') action(); }) : null;
    cv.onresize = () => layout();
    layout();

    return {
      _dbg: () => ({ anim, G, cur }),
      update(next, prev) {
        st = next;
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          if (myPend && l.id === myPend.seq + 1 && l.s === myPend.seat && anim && anim.mode === 'live') {
            anim.last = l; myPend = null; clearTimeout(waitTimer);
            if (anim.land) { anim.land.x = l.lx / 10; anim.land.y = l.ly / 10; anim.land.g = l.g; }
            waitTimer = setTimeout(() => { if (anim && anim.last === l) endAnim(); }, 20000);
          } else {
            anim = null; myPend = null;
            startReplay(l, prev);
          }
        } else if (anim && anim.mode === 'live' && anim.ph === 'ready' && (!humanTurn() || anim.seq !== next.seq)) {
          anim = null;
        }
        renderTop(anim && anim.ph !== 'card' ? anim.snap : next, anim ? anim.seat : actor(next));
        barKey = ''; renderBar();
      },
      destroy() {
        stopLoop(); clearTimeout(waitTimer);
        el.removeEventListener('pointerdown', onDown); el.removeEventListener('pointerup', onUp);
        el.removeEventListener('pointercancel', onUp); el.removeEventListener('lostpointercapture', onUp);
        btnOff.forEach((f) => f());
        if (offKey) offKey();
        cv.destroy(); top.remove(); bar.remove(); altBox.remove(); mapBox.remove();
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'parachute', name: '낙하산 착지 대회', tag: '정밀 착지', cat: '스포츠',
    blurb: '비행기에서 뛰어내려 알맞은 높이에서 낙하산을 펴고, 높이마다 다른 바람을 읽으며 과녁 한가운데로! 땅 직전 브레이크로 사뿐히 내려앉아요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 500,
    tint: '#1f4f6e',
    icon: '<path d="M8 24C8 12 18 6 28 6S48 12 48 24C44 21 40 21 36 24C32 21 24 21 20 24C16 21 12 21 8 24Z" fill="currentColor"/><path d="M9 24L26 42M20 24L27 42M36 24L29 42M47 24L30 42" stroke="currentColor" stroke-width="1.6" fill="none"/><circle cx="28" cy="44" r="3.2" fill="currentColor"/><ellipse cx="28" cy="52" rx="13" ry="2.6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="28" cy="52" r="1.2" fill="currentColor"/>',
    options: [
      { id: 'loc', label: '장소', choices: [{ v: 'rot', label: '돌아가며' }, { v: 'rand', label: '무작위' }, { v: 'field', label: '들판' }, { v: 'beach', label: '해변' }, { v: 'summit', label: '산 정상' }, { v: 'city', label: '도시 옥상' }], def: 'rand' },
      { id: 'rounds', label: '라운드', choices: [{ v: 1, label: '1번씩' }, { v: 3, label: '3번씩' }, { v: 4, label: '4번씩' }], def: 3 },
    ],
    controls: [
      { id: 'left', label: '왼쪽으로 돌기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-', 'lb'] },
      { id: 'right', label: '오른쪽으로 돌기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+', 'rb'] },
      { id: 'brake', label: '뛰어내리기 · 낙하산 펴기 · 브레이크', keys: ['Space', 'ArrowDown', 'KeyS'], pad: ['a', 'rt', 'down'] },
    ],
    quick: [
      '목표: 비행기에서 뛰어내려 과녁 한가운데에 사뿐히 내려앉아요. 라운드 점수 합계가 가장 높으면 우승!',
      '내 차례: 「뛰어내리기」 → 초록 높이에서 「낙하산 펴기」 → ◀ ▶로 방향 잡기 → 땅 직전 「브레이크」 꾹.',
      '점수: 과녁에 가까울수록 최대 100점 + 부드럽게 내리면 최대 30점. 물·나무·건물에 내리면 감점!',
    ],
    rules: [
      { h: '목표', p: [
        '한 사람씩 번갈아 뛰어요. 정한 라운드 수(1·3·4번씩)만큼 뛰고 점수 합계가 가장 높은 사람이 이겨요. 같으면 공동 우승.',
        '라운드마다 장소를 무작위로 골라요(기본). 장소 옵션에서 「돌아가며」(들판 → 해변 → 산 정상 → 도시 옥상 순서, 시작 장소는 무작위)나 한 곳만 고를 수도 있어요.',
        '혼자 하면 별을 모아요: 한 번 점프 평균 50점 ★, 80점 ★★, 105점 ★★★.',
      ] },
      { h: '차례에 할 일', p: [
        '1) 뛰어내리기: 가운데 버튼을 누르면 320m 높이의 비행기에서 뛰어내려요. 그 전에 오른쪽 위 지도와 왼쪽 바람 화살표로 계획을 세워요.',
        '2) 낙하산 펴기: 떨어지는 동안 가운데 「낙하산 펴기」를 눌러요. 왼쪽 고도계의 초록 칸(160~120m)이 좋아요. 120m보다 낮으면 늦게 펼침 −10점, 90m까지 안 펴면 자동으로 펴지고 −30점.',
        '3) 조종: ◀ ▶ 버튼(또는 화면 왼쪽·오른쪽 절반)을 누르고 있으면 그쪽으로 돌아요. 화면 위쪽이 언제나 내가 날아가는 방향이에요. 자유 낙하 중에도 몸을 돌릴 수 있어요.',
        '4) 착지: 땅에 닿기 직전(약 1~3m — 고도계가 파란 칸에 들어오고 그림자가 몸에 거의 붙을 때) 「브레이크」를 꾹 누르고 있으면 하강이 멈칫하며 사뿐히 내려요. 너무 일찍 당기면 힘이 빠져 쿵, 안 당기면 넘어져요. 브레이크를 오래 잡고 있다가 놓으면 속도가 다시 붙을 때까지 2초쯤 걸려요.',
      ] },
      { h: '바람', p: [
        '바람은 높이마다 방향과 세기가 달라요(0·60·150·300m). 왼쪽 고도계 옆 화살표가 각 높이의 바람, 왼쪽 위 상자가 지금 높이의 바람이에요. 화살표도 화면처럼 위쪽 = 내가 가는 방향이에요.',
        '높은 곳 바람이 가장 세요. 너무 일찍 펴면 오래 바람에 밀려요. 과녁 옆 바람자루는 땅 근처 바람을 보여 줘요.',
        '바람을 안고(맞바람) 내리면 땅 위 속도가 줄어 더 부드럽게 착지해요. 땅 가까이에서 돌면 빨리 떨어지니 조심!',
      ] },
      { h: '점수', p: [
        '점프 점수 = 거리 점수 + 착지 점수 − 감점 (0점 아래로는 안 내려가요).',
        '거리 점수: 과녁 한가운데(빨간 점)에서 0m면 100점, 1m 멀어질 때마다 −4점(25m 넘으면 0점).',
        '착지 점수: 사뿐 착지 30 · 좋은 착지 20 · 쿵 착지 8 · 넘어짐 0.',
        '감점: 물 −30 · 나무 −15 · 바위 −15 · 지붕 −15 · 파라솔 −10 · 옥상 시설물 −10 · 다른 옥상 −10 · 벽에 부딪힘 −20 · 비탈 −20 · 옥상 밖 길바닥 −40. 걸리거나 빠지면 착지 점수도 0이에요.',
        '예시: 과녁에서 2.5m(거리 90점) + 사뿐 착지(30점) = 120점. 늦게 펼쳤다면 110점.',
      ] },
      { h: '장소', p: [
        '들판: 나무숲·연못·헛간. 해변: 바다(물)·야자수·파라솔. 산 정상: 좁은 정상 밖은 비탈, 바위가 있고 바람이 세요. 도시 옥상: 옥상 밖은 길바닥, 더 높은 건물 벽을 조심!',
      ] },
      { h: '조작', p: [
        '◀ ▶: 누르고 있는 동안 돌기. 둘 다 누르면 브레이크와 같아요. 가운데 버튼: 뛰어내리기 → 낙하산 펴기 → 브레이크.',
        '키보드: ← → (A D) 돌기, 스페이스(↓·S) 가운데 버튼. 게임패드도 돼요(설정에서 바꾸기).',
        '다른 사람의 점프는 2배속 다시보기로 보여 줘요. 탭하면 건너뛰어요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '차례대로 뛰는 게임이라 한 폰을 돌려 가며 여럿이 해도 되고, 온라인·LAN 방에서도 할 수 있어요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(펼치는 높이, 바람 읽기, 브레이크 타이밍이 달라요).',
      ] },
    ],
    tutorial: [
      { text: '낙하산 착지 대회! 비행기에서 뛰어내려 과녁(흰 동그라미) 한가운데에 사뿐히 내려앉으면 높은 점수예요.' },
      { text: '오른쪽 위 지도: 가운데 화살표가 나, 흰 원과 빨간 점이 과녁이에요. 물·나무·건물은 감점! 지도도 화면처럼 위쪽이 내가 가는 방향이에요.', sel: '.pc-map' },
      { text: '왼쪽 고도계: 초록 칸(160~120m)에서 낙하산을 펴요. 맨 아래 파란 칸은 브레이크 구간. 옆의 화살표는 높이마다 다른 바람이에요.', sel: '.pc-alt' },
      { text: '◀ ▶ 버튼(또는 화면 왼쪽·오른쪽)을 누르고 있으면 그쪽으로 돌아요.', sel: '.pc-r' },
      { text: '가운데 버튼: 「뛰어내리기」 → 「낙하산 펴기」 → 「브레이크」. 땅 직전(고도계 파란 칸, 그림자가 몸에 닿기 직전) 브레이크를 꾹 누르면 사뿐 착지!', sel: '.pc-b' },
    ],
    init, actor, apply, ai, result, mount,
    aiDelayFor() { return 500; },
    _t: { genMap, surf, newRun, step, simulate, judge, scoreRun, aiFly, bestFlare, LVP, validRec, grade, softEff, windAt, MAXEV, DT },
  });
})();
