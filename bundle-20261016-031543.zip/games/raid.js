/* 보스 레이드 협동 — 1~4명 턴제 협동 로그라이크.
   각자 직업(전사·마법사·치유사·궁수 등 7종)을 골라 3막 × 여러 층의 갈림길 지도를 올라가요.
   전투는 "모두 동시에" 카드를 내는 방식(array actor): 각 영웅은 에너지 3, 카드 5장. 모두 「턴 종료」하면 적이 미리 보여 준
   의도(⚔ 공격 12 → 누구, 💥 광역, 🛡 방어, 🌀 약화·취약…)대로 움직여요. 도발·방어·회복·취약 같은 협력이 핵심.
   전투 뒤 카드 보상, 지도 칸: 전투/엘리트/휴식/상점/사건/보물, 막 끝에 보스(5종, 각자 다른 기믹), 마지막 보스는 2단계.
   State (JSON < 2500B, 카드·유물은 한 글자 id = AL[번호]):
     { n 영웅 수, ai AI 자리 비트, df 던전 난이도 0~2, ln 막마다 층 수, ph 'c'직업|'m'지도|'f'전투|'w'보상|'r'휴식|'s'상점|'e'사건|'x'끝,
       a 막 0~2, y 지금 층(−1 = 막 시작), x 지금 칸(0~2), mp 지도(ln×3 글자: F E R S ? T .), vt[] 지도 투표(−1 = 아직),
       g 파티 골드, rl 유물 글자들, bo[] 막별 보스 id, ft 전투 종류 F/E/B, ev 사건 번호, sh 상점 유물 2글자, rd 전투 판 수,
       kl 처치 수, fl 지나온 층 수, bk 쓰러뜨린 보스 수, sv 수호 부적 사용, res 'w'|'l'|'', lg 알림 한 줄, seq, last {id, f:[[대상,값,종류]], e},
       H[] 영웅 { k 직업(−1 = 아직), h, m, d 덱, p 뽑을 더미, q 손, r 버린 더미, e 에너지, b 방어, s 힘, w 약화, v 취약, t 도발, j 가시,
               o 이번 단계 끝냄, f 보상/상점 카드 후보, z 상점 카드 빼기 씀 },
       E[] 적 { k, h, m, b, s, w, v, p 독, z 기절, i 의도(행동 번호), g 노리는 영웅, dr 이번 판 받은 피해 } }
   대상 코드(애니메이션): 0~3 = 영웅, 10~13 = 적. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- helpers ---------- */
  const AL = (() => { let s = ''; for (let c = 35; c < 127; c++) if (c !== 92) s += String.fromCharCode(c); return s; })();
  const cid = (c) => AL.indexOf(c);
  const R = (n) => Math.floor(Math.random() * n);
  const pick = (a) => a[R(a.length)];
  const shuf = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = R(i + 1); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; };
  const clone = (o) => JSON.parse(JSON.stringify(o));

  /* ---------- classes ---------- */
  const CL = [
    { n: '전사', ic: '🛡️', hp: 80, role: '도발로 대신 맞고 버텨요', ul: 0 },
    { n: '마법사', ic: '🔮', hp: 56, role: '광역 마법·기절', ul: 0 },
    { n: '치유사', ic: '✨', hp: 62, role: '회복·보호·부활', ul: 0 },
    { n: '궁수', ic: '🏹', hp: 60, role: '취약 표시·강한 한 방', ul: 0 },
    { n: '도적', ic: '🗡️', hp: 58, role: '독을 쌓고 터뜨려요', ul: 1 },
    { n: '음유시인', ic: '🎻', hp: 58, role: '아군 힘·에너지 올리기', ul: 2 },
    { n: '정령술사', ic: '🌿', hp: 64, role: '광역 정령·가시·돌벽', ul: 3 },
  ];
  const UL_TXT = ['', '1막 보스를 쓰러뜨리면 열려요', '2막 보스를 쓰러뜨리면 열려요', '레이드에 한 번 성공하면 열려요'];

  /* ---------- cards ----------
     T: e 적 하나, E 모든 적, r 무작위 적, s 나, a 아군 하나(나 포함), A 모든 아군, d 아군(쓰러진 아군 포함)
     d 피해 hi 횟수, sb 피해=내 방어, pd +대상 독, ex 반피 이하 2배, pi 방어 무시, w 약화, v 취약, p 독, pp 독 2배, st 기절,
     b 방어, hl 회복, s 힘, en 에너지, dr 카드, j 가시, tn 도발, cl 약화·취약 풀기, rv 부활, mb 내 방어, sl 내 체력 잃음, x 1번만, u 못 씀 */
  const C = [
    // 0 전사
    { n: '베기', c: 1, k: 0, T: 'e', d: 6, S: 1 },
    { n: '막기', c: 1, k: 0, T: 's', b: 5, S: 1 },
    { n: '도발 외침', c: 1, k: 0, T: 's', tn: 1, b: 4, S: 1 },
    { n: '방패 치기', c: 1, k: 0, T: 'e', sb: 1 },
    { n: '철벽', c: 2, k: 0, T: 's', b: 13 },
    { n: '수호', c: 1, k: 0, T: 'a', b: 8 },
    { n: '회오리 베기', c: 1, k: 0, T: 'E', d: 5 },
    { n: '분노', c: 0, k: 0, T: 's', s: 2, sl: 3 },
    { n: '반격 자세', c: 1, k: 0, T: 's', b: 5, j: 4 },
    { n: '대지 강타', c: 2, k: 0, T: 'e', d: 13, w: 2 },
    // 10 마법사
    { n: '마력탄', c: 1, k: 1, T: 'e', d: 6, S: 1 },
    { n: '마력 방벽', c: 1, k: 1, T: 's', b: 5, S: 1 },
    { n: '서리 화살', c: 1, k: 1, T: 'e', d: 4, w: 1, S: 1 },
    { n: '연쇄 번개', c: 2, k: 1, T: 'E', d: 8 },
    { n: '얼음 감옥', c: 2, k: 1, T: 'e', st: 1, x: 1 },
    { n: '마나 샘', c: 0, k: 1, T: 's', en: 2, x: 1 },
    { n: '운석', c: 3, k: 1, T: 'e', d: 24 },
    { n: '비전 집중', c: 1, k: 1, T: 's', dr: 2, b: 3 },
    { n: '화염 폭풍', c: 2, k: 1, T: 'E', d: 5, p: 3 },
    { n: '마력 증폭', c: 1, k: 1, T: 'a', s: 2 },
    // 20 치유사
    { n: '빛의 일격', c: 1, k: 2, T: 'e', d: 5, S: 1 },
    { n: '치유의 손길', c: 1, k: 2, T: 'a', hl: 6, S: 1 },
    { n: '보호의 기도', c: 1, k: 2, T: 'a', b: 6, S: 1 },
    { n: '단체 치유', c: 2, k: 2, T: 'A', hl: 6 },
    { n: '부활의 기도', c: 2, k: 2, T: 'd', rv: 1, x: 1 },
    { n: '축복', c: 1, k: 2, T: 'a', en: 1, dr: 1 },
    { n: '성스러운 방패', c: 2, k: 2, T: 'A', b: 6 },
    { n: '정화', c: 0, k: 2, T: 'A', cl: 1, hl: 3 },
    { n: '심판의 빛', c: 2, k: 2, T: 'e', d: 12, v: 1 },
    { n: '희생', c: 1, k: 2, T: 'a', hl: 12, sl: 5 },
    // 30 궁수
    { n: '화살', c: 1, k: 3, T: 'e', d: 6, S: 1 },
    { n: '구르기', c: 1, k: 3, T: 's', b: 5, S: 1 },
    { n: '표적 지정', c: 1, k: 3, T: 'e', d: 2, v: 2, S: 1 },
    { n: '저격', c: 2, k: 3, T: 'e', d: 18 },
    { n: '연사', c: 1, k: 3, T: 'e', d: 3, hi: 3 },
    { n: '화살비', c: 2, k: 3, T: 'E', d: 6 },
    { n: '덫', c: 1, k: 3, T: 'e', d: 3, w: 2 },
    { n: '매의 눈', c: 0, k: 3, T: 's', dr: 1 },
    { n: '관통 사격', c: 1, k: 3, T: 'e', d: 9, pi: 1 },
    { n: '처형', c: 1, k: 3, T: 'e', d: 8, ex: 1 },
    // 40 도적
    { n: '단검', c: 1, k: 4, T: 'e', d: 6, S: 1 },
    { n: '피하기', c: 1, k: 4, T: 's', b: 5, S: 1 },
    { n: '독 바르기', c: 1, k: 4, T: 'e', p: 5, S: 1 },
    { n: '독구름', c: 2, k: 4, T: 'E', p: 5 },
    { n: '급소 찌르기', c: 1, k: 4, T: 'e', d: 4, pd: 1 },
    { n: '연속 찌르기', c: 1, k: 4, T: 'e', d: 4, hi: 2 },
    { n: '그림자 걸음', c: 1, k: 4, T: 's', b: 8, dr: 1 },
    { n: '맹독', c: 1, k: 4, T: 'e', pp: 1 },
    { n: '칼날 춤', c: 0, k: 4, T: 'e', d: 3, dr: 1 },
    { n: '연막탄', c: 1, k: 4, T: 'A', b: 4 },
    // 50 음유시인
    { n: '불협화음', c: 1, k: 5, T: 'e', d: 5, S: 1 },
    { n: '노래 방패', c: 1, k: 5, T: 's', b: 5, S: 1 },
    { n: '응원가', c: 1, k: 5, T: 'a', s: 1, S: 1 },
    { n: '전투의 노래', c: 2, k: 5, T: 'A', s: 1 },
    { n: '서두름', c: 1, k: 5, T: 'a', en: 2, x: 1 },
    { n: '자장가', c: 1, k: 5, T: 'E', w: 2 },
    { n: '영웅의 찬가', c: 2, k: 5, T: 'A', b: 7 },
    { n: '날카로운 음', c: 1, k: 5, T: 'e', d: 4, v: 2 },
    { n: '메아리', c: 1, k: 5, T: 'a', dr: 2 },
    { n: '휴식의 선율', c: 1, k: 5, T: 'A', hl: 4 },
    // 60 정령술사
    { n: '정령 화살', c: 1, k: 6, T: 'e', d: 6, S: 1 },
    { n: '바위 껍질', c: 1, k: 6, T: 's', b: 6, S: 1 },
    { n: '덩굴', c: 1, k: 6, T: 'e', d: 3, w: 1, S: 1 },
    { n: '지진', c: 2, k: 6, T: 'E', d: 9 },
    { n: '수호 정령', c: 2, k: 6, T: 'A', j: 3, b: 4 },
    { n: '번개 정령', c: 1, k: 6, T: 'r', d: 4, hi: 3 },
    { n: '생명나무', c: 2, k: 6, T: 'A', hl: 5 },
    { n: '돌벽', c: 1, k: 6, T: 'a', b: 10 },
    { n: '화산', c: 3, k: 6, T: 'E', d: 14 },
    { n: '뿌리 감옥', c: 2, k: 6, T: 'e', st: 1, x: 1 },
    // 70 공용
    { n: '응급 처치', c: 1, k: 7, T: 's', hl: 8, x: 1 },
    { n: '집중', c: 0, k: 7, T: 's', dr: 2, x: 1 },
    { n: '함성', c: 1, k: 7, T: 's', s: 1 },
    { n: '팀워크', c: 1, k: 7, T: 'a', b: 6, mb: 3 },
    { n: '기습', c: 0, k: 7, T: 'e', d: 5, x: 1 },
    // 75 저주
    { n: '상처', c: 0, k: 8, T: 's', u: 1 },
  ];
  const CURSE = 75;
  const isAtk = (c) => c.d != null || !!c.sb || !!c.pd;
  const ctype = (c) => c.u ? 'u' : isAtk(c) ? 'a' : (c.w || c.v || c.p || c.pp || c.st) ? 'd' : (c.T === 'a' || c.T === 'A' || c.T === 'd') ? 'g' : (c.s || c.en || c.dr) && !c.b ? 'p' : 's';
  const POOL = CL.map((_, k) => C.map((c, i) => (c.k === k && !c.S ? i : -1)).filter((i) => i >= 0));
  const NEUT = [70, 71, 72, 73, 74];
  const starter = (k) => { const b = k * 10; return [b, b, b, b, b + 1, b + 1, b + 1, b + 2].map((i) => AL[i]).join(''); };

  function desc(c) {
    if (c.u) return '쓸 수 없어요';
    const t = [], E = c.T === 'E', who = c.T === 'A' ? '모두 ' : (c.T === 'a' || c.T === 'd') ? '아군 ' : '';
    if (c.sl) t.push('내 체력 −' + c.sl);
    if (c.sb) t.push('피해 = 내 방어');
    if (c.d != null) t.push((E ? '모든 적 ' : c.T === 'r' ? '무작위 적 ' : '') + '피해 ' + c.d + (c.hi > 1 ? '×' + c.hi : '') + (c.pd ? '+독' : ''));
    if (c.pi) t.push('방어 무시');
    if (c.ex) t.push('반피 이하면 2배');
    const tE = E ? '모든 적 ' : '';
    if (c.w) t.push(tE + '약화 ' + c.w);
    if (c.v) t.push(tE + '취약 ' + c.v);
    if (c.p) t.push(tE + '독 ' + c.p);
    if (c.pp) t.push('독 2배');
    if (c.st) t.push('기절');
    if (c.rv) t.push('쓰러진 아군 살리기(아니면 회복 12)');
    if (c.b) t.push(who + '방어 ' + c.b);
    if (c.hl) t.push(who + '회복 ' + c.hl);
    if (c.s) t.push(who + '힘 +' + c.s);
    if (c.en) t.push(who + '에너지 +' + c.en);
    if (c.dr) t.push(who + '카드 ' + c.dr + '장');
    if (c.j) t.push(who + '가시 ' + c.j);
    if (c.cl) t.push('약화·취약 풀기');
    if (c.tn) t.push('도발');
    if (c.mb) t.push('내 방어 ' + c.mb);
    if (c.x) t.push('1번만');
    return t.join(' · ');
  }

  /* ---------- relics (party) ---------- */
  const RL = [
    { n: '붉은 깃털', ic: '🪶', d: '전투 시작: 모두 방어 6' },
    { n: '힘의 장갑', ic: '🧤', d: '전투 시작: 모두 힘 +1' },
    { n: '생명 열매', ic: '🍎', d: '얻을 때: 모두 최대 체력 +8' },
    { n: '행운의 동전', ic: '🪙', d: '전투 골드 +50%' },
    { n: '치유의 종', ic: '🔔', d: '전투가 끝나면 모두 회복 6' },
    { n: '바람 신발', ic: '👟', d: '첫 판: 모두 카드 +2장' },
    { n: '마력 수정', ic: '💠', d: '첫 판: 모두 에너지 +1' },
    { n: '가시 갑옷', ic: '🌵', d: '매 판: 모두 가시 2' },
    { n: '독 칼집', ic: '🧪', d: '전투 시작: 모든 적 독 4' },
    { n: '큰 배낭', ic: '🎒', d: '카드 보상을 4장 중에서 골라요' },
    { n: '시계 태엽', ic: '⚙️', d: '3판마다 모두 에너지 +1' },
    { n: '수호 부적', ic: '🧿', d: '전투마다 처음 쓰러질 영웅이 체력 1로 버텨요' },
    { n: '약화 가루', ic: '🌫️', d: '전투 시작: 모든 적 약화 1' },
    { n: '포근한 침낭', ic: '🛏️', d: '휴식 회복 30% → 50%' },
    { n: '상인의 배지', ic: '📛', d: '상점 가격 25% 할인' },
    { n: '사냥꾼 휘장', ic: '🎖️', d: '엘리트·보스: 시작 때 모든 적 취약 2' },
    { n: '피의 성배', ic: '🏆', d: '적을 쓰러뜨린 영웅 회복 4' },
    { n: '번개 병', ic: '⚡', d: '매 판 시작: 무작위 적 피해 5' },
    { n: '단단한 투구', ic: '⛑️', d: '맞을 때마다 받는 피해 −1' },
    { n: '우정의 반지', ic: '💍', d: '아군에게 쓰는 방어·회복 +2' },
    { n: '불씨 반지', ic: '💥', d: '모든 적 공격 카드 피해 +2' },
    { n: '금고 열쇠', ic: '🗝️', d: '얻을 때: 골드 +100' },
  ];
  const hasR = (s, i) => s.rl.indexOf(AL[i]) >= 0;

  /* ---------- enemies ----------
     mv: 행동들(|로 구분), 한 행동 = 부분들(+로 구분): a 공격(×횟수) A 광역 b 방어 B 적 모두 방어 s 힘 S 적 모두 힘 w/v 약화/취약(대상)
     W/V 모두에게 h 적 모두 회복 c 상처 카드 z 소환 C 기 모으기 K 폭발(광역) M 표식(도발 무시)
     o: 'o' 순서대로, 'r' 무작위 / bs 보스 / kb 방어도 유지 / el 엘리트 */
  const EN = [
    { n: '동굴 박쥐', ic: '🦇', h: 13, mv: 'a5|a3x2|w1+a3', o: 'r' },
    { n: '진흙 슬라임', ic: '🟢', h: 20, mv: 'a7|b6+a3', o: 'o' },
    { n: '고블린 창병', ic: '👺', h: 22, mv: 'a8|b6+a4|s2', o: 'o' },
    { n: '해골 궁수', ic: '💀', h: 18, mv: 'a9|v1+a4', o: 'r' },
    { n: '독버섯 정령', ic: '🍄', h: 17, mv: 'W1|a6|a6', o: 'o' },
    { n: '굶주린 늑대', ic: '🐺', h: 20, mv: 'a6|a3x3', o: 'r' },
    { n: '들쥐 도둑', ic: '🐀', h: 15, mv: 'a5|b7|w1+a4', o: 'r' },
    { n: '오크 투사', ic: '👹', h: 58, mv: 's2|a11|A6', o: 'o', el: 1 },
    { n: '거미 여왕', ic: '🕷️', h: 46, mv: 'z9|a8|v2+a5', o: 'o', el: 1 },
    { n: '거미 새끼', ic: '🐜', h: 8, mv: 'a4|w1', o: 'r' },
    // 10 — 2막
    { n: '사막 전갈', ic: '🦂', h: 30, mv: 'a9|w1+a5|b8+a5', o: 'r' },
    { n: '유령 기사', ic: '👻', h: 34, mv: 'a11|b10|a11', o: 'o' },
    { n: '화염 정령', ic: '🔥', h: 28, mv: 'A5|a9', o: 'o' },
    { n: '늪 마녀', ic: '🧙', h: 28, mv: 'W1+V1|a8|h8', o: 'o' },
    { n: '돌 가고일', ic: '🗿', h: 38, mv: 'b12|a12', o: 'o' },
    { n: '그림자 암살자', ic: '👤', h: 26, mv: 'a4x3|v2+a4', o: 'r' },
    { n: '저주받은 갑옷', ic: '⚔️', h: 36, mv: 'c1+a7|s3|a7', o: 'o' },
    { n: '황소 투사', ic: '🐂', h: 95, mv: 'a16|s3|A9', o: 'o', el: 1 },
    { n: '얼음 쌍둥이', ic: '❄️', h: 52, mv: 'A7|h10|a10', o: 'o', el: 1 },
    { n: '불꽃 쌍둥이', ic: '☄️', h: 52, mv: 'a12|S2|A6', o: 'o', el: 1 },
    { n: '사냥개', ic: '🐕', h: 18, mv: 'a6|a3x2', o: 'r' },
    // 21 — 3막
    { n: '심연 촉수', ic: '🦑', h: 44, mv: 'a12|w2+a6', o: 'r' },
    { n: '공허 박쥐', ic: '🌑', h: 34, mv: 'a5x3|V1', o: 'r' },
    { n: '타락한 기사', ic: '🤺', h: 54, mv: 'a14|b15|s2', o: 'o' },
    { n: '망령', ic: '☠️', h: 40, mv: 'c2|A7|a10', o: 'o' },
    { n: '수정 골렘', ic: '💎', h: 58, mv: 'b20|a18', o: 'o' },
    { n: '혼돈 술사', ic: '🌀', h: 42, mv: 'V1+W1|A10|h12', o: 'o' },
    { n: '해골 용병', ic: '🦴', h: 48, mv: 'a10+b8|a6x2', o: 'r' },
    { n: '뼈 용', ic: '🐉', h: 150, mv: 'A12|a20|s3', o: 'o', el: 1 },
    { n: '쌍두 거인', ic: '👾', h: 135, mv: 'a15|a8x2|b15+s2', o: 'o', el: 1 },
    // 30 — 보스
    { n: '이끼 골렘', ic: '⛰️', h: 120, mv: 'b14|a10|A8|b10+a6', o: 'o', bs: 1, kb: 1, tip: '방어도가 사라지지 않고 쌓여요. 취약을 걸고 큰 공격으로 한꺼번에 깨세요!' },
    { n: '도깨비 왕', ic: '👑', h: 105, mv: 'z32|a12|S2|a9+v1', o: 'o', bs: 1, tip: '꼬마 도깨비를 불러요. 「모두 힘」으로 졸개까지 강해져요 — 광역 공격으로 정리!' },
    { n: '꼬마 도깨비', ic: '😈', h: 12, mv: 'a5|b5', o: 'r' },
    { n: '시계탑 수호자', ic: '🕰️', h: 210, mv: 'a12|C|C|K28', o: 'o', bs: 1, tip: '⏳ 기를 모으는 판에 정해진 피해를 넘기면 흔들려 끊겨요. 못 끊으면 큰 광역 폭발!' },
    { n: '사냥개 우두머리', ic: '🐾', h: 190, mv: 'M+v1+a10|z20|M+a7x2|s2+b10', o: 'o', bs: 1, tip: '🎯 표식 공격은 도발을 무시해요. 노리는 영웅을 방어·회복으로 지키세요.' },
    { n: '심연의 군주', ic: '👁️', h: 360, mv: 'a16|W1+V1|A10|c2+a8', o: 'o', bs: 1, tip: '체력이 절반이 되면 각성해요(방어·힘·촉수 소환)!' },
    { n: '각성한 심연의 군주', ic: '👿', h: 360, mv: 'z21+b10|A14|a8x3|s2+A8', o: 'o', bs: 1, tip: '마지막 단계! 광역 공격이 세요 — 모두 방어를 챙기세요.' },
  ];
  EN.forEach((e) => { e.P = e.mv.split('|').map((m) => m.split('+').map((p) => { const [a, b] = p.slice(1).split('x'); return { t: p[0], v: +a || 0, n: +b || 1 }; })); });
  const NORM = [[0, 1, 2, 3, 4, 5, 6], [10, 11, 12, 13, 14, 15, 16], [21, 22, 23, 24, 25, 26, 27]];
  const ELITE = [[[7], [8, 9]], [[17], [18, 19]], [[28], [29]]];
  const BOSS = [[30, 31], [33, 34], [35]];
  const MINION = { 31: [32], 34: [20] };

  const EVT = [
    { n: '신비한 샘', ic: '⛲', t: '맑은 물이 솟는 샘이 있어요.', o: ['체력 12 회복', '최대 체력 +4'] },
    { n: '피의 제단', ic: '🩸', t: '피를 바치면 힘을 준대요.', o: ['체력 7 잃고 직업 카드 1장', '지나가기'] },
    { n: '떠돌이 상인', ic: '🧳', t: '"골드 25면 좋은 걸 줄게!"', o: ['골드 25 내고 공용 카드 1장', '지나가기'] },
    { n: '버려진 대장간', ic: '⚒️', t: '낡은 모루가 아직 쓸 만해요.', o: ['기본 공격 카드 1장 빼기', '골드 +12'] },
    { n: '수상한 상자', ic: '📦', t: '덜컹거리는 상자… 열어 볼까요?', o: ['열기(반반: 골드 +35 / 상처 카드)', '지나가기'] },
    { n: '수련장', ic: '🥋', t: '허수아비와 땀 흘릴 시간이에요.', o: ['기본 방어 카드 1장 빼기', '체력 8 회복'] },
    { n: '떠도는 영혼', ic: '👻', t: '영혼이 금화를 내밀며 손을 잡재요.', o: ['상처 카드 받고 골드 +45', '지나가기'] },
    { n: '모닥불 이야기', ic: '🔥', t: '잠깐 쉬며 옛 영웅 이야기를 들어요.', o: ['체력 20% 회복', '최대 체력 +2'] },
  ];
  const NODE = { F: { ic: '⚔️', n: '전투' }, E: { ic: '☠️', n: '엘리트' }, R: { ic: '🔥', n: '휴식' }, S: { ic: '🛒', n: '상점' }, '?': { ic: '❓', n: '사건' }, T: { ic: '🎁', n: '보물' }, B: { ic: '👑', n: '보스' } };

  /* ---------- scaling ---------- */
  const pm = (s) => [0.62, 1.9, 3.1, 4.5][s.n - 1];
  const dmH = (s) => [0.8, 1, 1.2][s.df];
  const dsc = (s) => [0.85, 1.1, 1.28, 1.42][s.n - 1] * [0.85, 1, 1.12][s.df];
  const thr = (s) => Math.round(22 * pm(s) * dmH(s));
  const price = (s, kind) => Math.round([50, 40, 140, 70][kind] * (hasR(s, 14) ? 0.75 : 1));

  /* ---------- init ---------- */
  function init(players, opts) {
    opts = opts || {};
    let ai = 0; players.forEach((p, i) => { if (p.ai) ai |= 1 << i; });
    return {
      n: players.length, ai, df: opts.diff != null ? +opts.diff : 1, ln: opts.len != null ? +opts.len : 6, ph: 'c', a: 0, y: -1, x: 1, mp: '',
      vt: players.map(() => -1), g: 30, rl: '', bo: BOSS.map((b) => pick(b)), ft: '', ev: 0, sh: '', rd: 0, kl: 0, fl: 0, bk: 0, sv: 0, res: '',
      lg: '각자 직업을 고르세요', seq: 0, last: null,
      H: players.map(() => ({ k: -1, h: 0, m: 0, d: '', p: '', q: '', r: '', e: 0, b: 0, s: 0, w: 0, v: 0, t: 0, j: 0, o: 0, f: '', z: 0 })),
      E: [],
    };
  }

  /* ---------- map ---------- */
  function genMap(s) {
    const ln = s.ln; let m = '';
    for (let r = 0; r < ln; r++) for (let c = 0; c < 3; c++) {
      if (c !== 1 && Math.random() < 0.38) { m += '.'; continue; }
      let t;
      if (r === 0) t = 'F';
      else if (r === ln - 1) t = 'R';
      else { const x = Math.random(); t = x < 0.4 ? 'F' : x < 0.55 ? (r >= 2 ? 'E' : 'F') : x < 0.73 ? '?' : x < 0.84 ? 'S' : x < 0.92 ? (r >= 2 ? 'R' : '?') : 'T'; }
      m += t;
    }
    if (ln >= 4 && m.indexOf('S') < 0) { const r = 1 + R(ln - 2); m = m.slice(0, r * 3 + 1) + 'S' + m.slice(r * 3 + 2); }
    s.mp = m;
  }
  function mapOpts(s) {
    if (s.y >= s.ln) return [];
    if (s.y === s.ln - 1) return [1];
    const row = s.y + 1, out = [];
    for (let c = 0; c < 3; c++) if (s.mp[row * 3 + c] !== '.' && (s.y < 0 || Math.abs(c - s.x) <= 1)) out.push(c);
    return out;
  }
  const nodeAt = (s, row, c) => (row >= s.ln ? 'B' : s.mp[row * 3 + c]);
  function voters(s) {
    const all = s.H.map((_, i) => i), hum = all.filter((i) => !(s.ai >> i & 1));
    return hum.length ? hum : all;
  }
  function resetDone(s) { s.H.forEach((h) => { h.o = 0; h.f = ''; h.z = 0; }); s.vt = s.H.map(() => -1); }

  function gainRelic(s, i) {
    if (i < 0 || hasR(s, i)) return;
    s.rl += AL[i];
    if (i === 2) s.H.forEach((h) => { h.m += 8; h.h += 8; });
    if (i === 21) s.g += 100;
  }
  function randRelic(s) { const c = RL.map((_, i) => i).filter((i) => !hasR(s, i)); return c.length ? pick(c) : -1; }

  function enterNode(s, c) {
    const row = s.y + 1, t = nodeAt(s, row, c);
    s.y = row; s.x = c; s.fl++;
    resetDone(s);
    if (t === 'F' || t === 'E' || t === 'B') return startFight(s, t);
    if (t === 'R') { s.ph = 'r'; s.lg = '🔥 휴식: 쉬거나 카드를 빼요'; return; }
    if (t === 'S') {
      s.ph = 's';
      s.H.forEach((h) => { const p = shuf(POOL[h.k].slice()); h.f = AL[p[0]] + AL[p[1]] + AL[pick(NEUT)]; });
      const a = randRelic(s); let b = randRelic(s); if (b === a) b = -1;
      s.sh = (a >= 0 ? AL[a] : '_') + (b >= 0 ? AL[b] : '_');
      s.lg = '🛒 상점: 골드는 파티가 함께 써요'; return;
    }
    if (t === '?') { s.ph = 'e'; s.ev = R(EVT.length); s.lg = EVT[s.ev].ic + ' ' + EVT[s.ev].n; return; }
    if (t === 'T') {
      const r = randRelic(s);
      if (r >= 0) { gainRelic(s, r); s.lg = '🎁 보물 상자: 유물 「' + RL[r].n + '」!'; } else { s.g += 60; s.lg = '🎁 보물 상자: 골드 +60'; }
      s.ph = 'm'; return;
    }
  }

  /* ---------- fight ---------- */
  let FX = null;
  const fx = (code, v, k) => { if (FX && FX.length < 26) FX.push([code, v, k]); };
  // 글자 효과 종류(k ≥ 3)
  const FXT = { 3: '기절', 4: '흔들림!', 5: '각성!', 6: '소환', 7: '약화', 8: '취약', 9: '', 10: '힘↑', 11: '저주', 12: '도발', 13: '독', 14: '살아남!', 15: '광폭화', 16: '기 모으기' };

  function addEnemy(s, id, slot) {
    const d = EN[id], var_ = d.bs || d.el ? 1 : 0.9 + Math.random() * 0.2;
    const hp = Math.max(4, Math.round(d.h * pm(s) * dmH(s) * var_ * (1 + 0.04 * s.a)));
    const e = { k: id, h: hp, m: hp, b: 0, s: 0, w: 0, v: 0, p: 0, z: 0, i: -1, g: 0, dr: 0 };
    if (slot != null) s.E[slot] = e; else s.E.push(e);
    return e;
  }
  function startFight(s, kind) {
    s.ph = 'f'; s.ft = kind; s.rd = 0; s.sv = 0; s.E = [];
    let ids;
    if (kind === 'B') { const b = s.bo[s.a]; ids = [b].concat(MINION[b] || []); }
    else if (kind === 'E') ids = pick(ELITE[s.a]);
    else { const cnt = s.y < 2 ? 1 + R(2) : 2 + (Math.random() < 0.3 ? 1 : 0); ids = []; for (let i = 0; i < cnt; i++) ids.push(pick(NORM[s.a])); }
    ids.forEach((id) => addEnemy(s, id));
    s.H.forEach((h) => { h.p = shuf(h.d.split('')).join(''); h.q = ''; h.r = ''; h.b = h.s = h.w = h.v = h.t = h.j = 0; h.o = 0; });
    s.lg = kind === 'B' ? '👑 보스 등장: ' + EN[ids[0]].n : kind === 'E' ? '☠️ 엘리트 등장!' : '⚔️ 전투 시작!';
    newRound(s);
    if (s.ph !== 'f') return;
    s.H.forEach((h) => { if (hasR(s, 0)) h.b += 6; if (hasR(s, 1)) h.s += 1; });
    s.E.forEach((e) => { if (hasR(s, 8)) e.p += 4; if (hasR(s, 12)) e.w += 1; if (hasR(s, 15) && kind !== 'F') e.v += 2; });
  }
  function draw(h, n) {
    for (let k = 0; k < n; k++) {
      if (h.q.length >= 10) return;
      if (!h.p.length) { if (!h.r.length) return; h.p = shuf(h.r.split('')).join(''); h.r = ''; }
      h.q += h.p[0]; h.p = h.p.slice(1);
    }
  }
  const living = (s) => s.H.map((h, i) => (h.h > 0 ? i : -1)).filter((i) => i >= 0);
  const livingE = (s) => s.E.map((e, i) => (e.h > 0 ? i : -1)).filter((i) => i >= 0);

  function roll(s, e) {
    const d = EN[e.k], n = d.P.length;
    if (d.o === 'o') e.i = e.i < 0 ? (d.bs ? 0 : R(n)) : (e.i + 1) % n;
    else { let j = R(n); if (n > 1 && j === e.i) j = (j + 1) % n; e.i = j; }
    const lv = living(s); e.g = lv.length ? pick(lv) : 0;
  }
  function newRound(s) {
    s.rd++;
    const first = s.rd === 1;
    s.H.forEach((h) => {
      if (h.h <= 0) { h.o = 1; return; }
      h.b = 0; h.t = 0; h.j = hasR(s, 7) ? 2 : 0; h.o = 0;
      h.e = 3 + (first && hasR(s, 6) ? 1 : 0) + (hasR(s, 10) && s.rd % 3 === 0 ? 1 : 0);
      draw(h, (s.n === 1 ? 6 : 5) + (first && hasR(s, 5) ? 2 : 0));
    });
    s.E.forEach((e) => { if (e.h > 0) { e.dr = 0; roll(s, e); } });
    if (s.rd > 20) s.E.forEach((e, i) => { if (e.h > 0) { e.s += 2; fx(10 + i, 0, 15); } });
    if (hasR(s, 17)) { const le = livingE(s); if (le.length) { dealE(s, -1, pick(le), 5, true); checkWin(s); } }
  }
  function effT(s, e, mark) {
    if (!mark) {
      let best = -1;
      s.H.forEach((h, i) => { if (h.h > 0 && h.t > 0 && (best < 0 || h.b > s.H[best].b)) best = i; });
      if (best >= 0) return best;
    }
    if (s.H[e.g] && s.H[e.g].h > 0) return e.g;
    let b = -1; s.H.forEach((h, i) => { if (h.h > 0 && (b < 0 || h.h > s.H[b].h)) b = i; });
    return b;
  }
  function eDmg(s, e, h, base) {
    let x = Math.round(base * dsc(s)) + (e ? e.s : 0);
    if (e && e.w > 0) x = Math.floor(x * 0.75);
    if (h && h.v > 0) x = Math.floor(x * 1.5);
    if (hasR(s, 18)) x -= 1;
    return Math.max(0, x);
  }
  function dealE(s, src, ei, base, pierce) {
    const e = s.E[ei]; if (!e || e.h <= 0) return 0;
    const a = src >= 0 ? s.H[src] : null;
    let d = base + (a ? a.s : 0);
    if (a && a.w > 0) d = Math.floor(d * 0.75);
    if (e.v > 0) d = Math.floor(d * 1.5);
    d = Math.max(0, d);
    let blk = 0; if (!pierce) { blk = Math.min(e.b, d); e.b -= blk; }
    const loss = Math.min(e.h, d - blk);
    e.h -= loss; e.dr += d;
    fx(10 + ei, loss, 0);
    if (e.h <= 0) {
      e.h = 0; s.kl++;
      if (a && hasR(s, 16) && a.h > 0) a.h = Math.min(a.m, a.h + 4);
    } else if (e.k === 35 && e.h * 2 <= e.m) {
      e.k = 36; e.b += Math.round(20 * pm(s) * dmH(s)); e.s += 2; e.w = e.v = e.p = e.z = 0; e.i = 0;
      fx(10 + ei, 0, 5); s.lg = '👿 심연의 군주가 각성했어요!';
    }
    return loss;
  }
  function dealH(s, ei, hi, base) {
    const e = ei >= 0 ? s.E[ei] : null, h = s.H[hi];
    if (!h || h.h <= 0) return;
    const d = eDmg(s, e, h, base);
    const blk = Math.min(h.b, d); h.b -= blk;
    const loss = Math.min(h.h, d - blk);
    h.h -= loss; fx(hi, loss, 0);
    if (h.j > 0 && e && e.h > 0) dealE(s, -1, ei, h.j, true);
    if (h.h <= 0) {
      if (hasR(s, 11) && !s.sv) { s.sv = 1; h.h = 1; fx(hi, 0, 14); return; }
      h.h = 0; h.r += h.q; h.q = ''; h.e = 0; h.b = 0; h.o = 1;
    }
  }
  function summon(s, id) {
    let slot = s.E.findIndex((e) => e.h <= 0);
    if (slot < 0 && s.E.length >= 4) return;
    const e = addEnemy(s, id, slot < 0 ? null : slot);
    e.i = -2; e.s = 0;
    fx(10 + s.E.indexOf(e), 0, 6);
  }
  function execMove(s, ei) {
    const e = s.E[ei], d = EN[e.k], parts = d.P[e.i] || [];
    const mark = parts.some((p) => p.t === 'M');
    const sc = (v) => Math.round(v * pm(s) * dmH(s));
    if (parts[0] && parts[0].t === 'C') {
      if (e.dr >= thr(s)) { fx(10 + ei, 0, 4); e.i = d.P.length - 1; e.z = 0; s.lg = '🕰️ 수호자가 흔들려 기가 끊겼어요!'; }
      else { fx(10 + ei, 0, 16); e.b += sc(6); }
      return;
    }
    for (const p of parts) {
      if (e.h <= 0 || !living(s).length) return;
      switch (p.t) {
        case 'a': for (let k = 0; k < p.n; k++) { const ti = effT(s, e, mark); if (ti < 0 || e.h <= 0) break; dealH(s, ei, ti, p.v); } break;
        case 'A': case 'K': living(s).forEach((i) => dealH(s, ei, i, p.v)); break;
        case 'b': e.b += sc(p.v); fx(10 + ei, sc(p.v), 2); break;
        case 'B': s.E.forEach((o, j) => { if (o.h > 0) { o.b += sc(p.v); fx(10 + j, sc(p.v), 2); } }); break;
        case 's': e.s += p.v; fx(10 + ei, 0, 10); break;
        case 'S': s.E.forEach((o, j) => { if (o.h > 0) { o.s += p.v; fx(10 + j, 0, 10); } }); break;
        case 'w': case 'v': { const ti = effT(s, e, mark); if (ti >= 0) { s.H[ti][p.t] += p.v; fx(ti, 0, p.t === 'w' ? 7 : 8); } break; }
        case 'W': case 'V': living(s).forEach((i) => { s.H[i][p.t.toLowerCase()] += p.v; fx(i, 0, p.t === 'W' ? 7 : 8); }); break;
        case 'h': s.E.forEach((o, j) => { if (o.h > 0) { const x = Math.min(o.m - o.h, sc(p.v)); o.h += x; fx(10 + j, x, 1); } }); break;
        case 'c': { const ti = effT(s, e, mark); if (ti >= 0) { for (let k = 0; k < p.v; k++) s.H[ti].r += AL[CURSE]; fx(ti, 0, 11); } break; }
        case 'z': summon(s, p.v); break;
      }
    }
  }
  function enemyPhase(s) {
    s.H.forEach((h) => { if (h.h > 0) { h.r += h.q; h.q = ''; h.w = Math.max(0, h.w - 1); h.v = Math.max(0, h.v - 1); } });
    for (let ei = 0; ei < s.E.length; ei++) {
      const e = s.E[ei];
      if (e.h <= 0 || e.i < 0) continue;
      if (!EN[e.k].kb) e.b = 0;
      if (e.p > 0) { const x = Math.min(e.h, e.p); e.h -= x; e.dr += x; e.p--; fx(10 + ei, x, 13); if (e.h <= 0) { e.h = 0; s.kl++; continue; } }
      fx(10 + ei, 0, 9);
      if (e.z > 0) { e.z--; fx(10 + ei, 0, 3); continue; }
      execMove(s, ei);
      if (!living(s).length) break;
    }
    s.E.forEach((e) => { if (e.h > 0) { e.w = Math.max(0, e.w - 1); e.v = Math.max(0, e.v - 1); } });
    if (!living(s).length) { s.ph = 'x'; s.res = 'l'; s.lg = '파티가 모두 쓰러졌어요…'; return; }
    if (checkWin(s)) return;
    if (s.rd >= 45) { s.ph = 'x'; s.res = 'l'; s.lg = '전투가 너무 길어져 물러났어요…'; return; }
    newRound(s);
  }
  function checkWin(s) {
    if (s.ph !== 'f' || livingE(s).length) return false;
    winFight(s); return true;
  }
  function winFight(s) {
    const kind = s.ft;
    s.H.forEach((h) => {
      if (h.h <= 0) h.h = Math.max(1, Math.round(h.m * 0.2));
      if (hasR(s, 4)) h.h = Math.min(h.m, h.h + 6);
      h.p = h.q = h.r = ''; h.b = h.s = h.w = h.v = h.t = h.j = h.e = 0;
    });
    s.E = [];
    let gold = kind === 'B' ? 60 : kind === 'E' ? 32 + R(10) : 14 + R(8);
    if (hasR(s, 3)) gold = Math.round(gold * 1.5);
    s.g += gold;
    let txt = '승리! 골드 +' + gold;
    if (kind === 'E' || kind === 'B') { const r = randRelic(s); if (r >= 0) { gainRelic(s, r); txt += ' · 유물 「' + RL[r].n + '」'; } }
    if (kind === 'B') {
      s.bk++;
      s.H.forEach((h) => { h.h = Math.min(h.m, h.h + Math.ceil((h.m - h.h) / 2)); });
      if (s.a >= 2) { s.ph = 'x'; s.res = 'w'; s.lg = '심연의 군주를 쓰러뜨렸어요!'; return; }
      txt = '👑 보스 처치! ' + txt + ' · 체력 회복';
    }
    s.lg = txt;
    resetDone(s);
    s.ph = 'w';
    const nOff = hasR(s, 9) ? 4 : 3;
    s.H.forEach((h) => { h.f = shuf(POOL[h.k].slice()).slice(0, nOff).map((i) => AL[i]).join(''); });
  }
  function afterNonFight(s) {
    if (s.ph === 'w' && s.ft === 'B') { s.a++; s.y = -1; s.x = 1; genMap(s); s.lg = (s.a + 1) + '막 시작! 다음 길을 골라요'; }
    s.ph = 'm'; resetDone(s);
  }

  function playCard(s, seat, i, g) {
    const hr = s.H[seat], chr = hr.q[i];
    if (chr == null) throw new Error('no card');
    const c = C[cid(chr)];
    if (!c || c.u) throw new Error('unplayable');
    if (c.c > hr.e) throw new Error('energy');
    if (c.T === 'e' && !(s.E[g] && s.E[g].h > 0)) throw new Error('target');
    if (c.T === 'a' && !(s.H[g] && s.H[g].h > 0)) throw new Error('ally');
    if (c.T === 'd' && !s.H[g]) throw new Error('ally');
    hr.e -= c.c; hr.q = hr.q.slice(0, i) + hr.q.slice(i + 1);
    if (!c.x) hr.r += chr;
    if (c.sl) { hr.h = Math.max(1, hr.h - c.sl); fx(seat, c.sl, 0); }
    if (isAtk(c)) {
      const hits = c.hi || 1;
      for (let k = 0; k < hits; k++) {
        if (c.T === 'e') {
          const e = s.E[g]; if (e.h <= 0) break;
          let base = c.sb ? hr.b : c.d || 0;
          if (c.pd) base += e.p;
          if (c.ex && e.h * 2 <= e.m) base *= 2;
          dealE(s, seat, g, base, c.pi);
        } else if (c.T === 'E') livingE(s).forEach((j) => dealE(s, seat, j, c.d + (hasR(s, 20) ? 2 : 0)));
        else if (c.T === 'r') { const le = livingE(s); if (!le.length) break; dealE(s, seat, pick(le), c.d); }
      }
    }
    const tE = c.T === 'e' ? [g] : c.T === 'E' ? livingE(s) : [];
    tE.forEach((j) => {
      const e = s.E[j]; if (e.h <= 0) return;
      if (c.w) { e.w += c.w; fx(10 + j, 0, 7); }
      if (c.v) { e.v += c.v; fx(10 + j, 0, 8); }
      if (c.p) { e.p += c.p; fx(10 + j, c.p, 13); }
      if (c.pp && e.p) { fx(10 + j, e.p, 13); e.p *= 2; }
      if (c.st) { e.z = 1; fx(10 + j, 0, 3); }
    });
    const ally = c.T === 'a' || c.T === 'd' || c.T === 'A';
    const tA = (c.T === 'a' || c.T === 'd') ? [g] : c.T === 'A' ? living(s) : [seat];
    const bonus = ally && hasR(s, 19) ? 2 : 0;
    tA.forEach((j) => {
      const h = s.H[j];
      if (c.rv && h.h <= 0) { h.h = Math.max(1, Math.round(h.m * 0.3)); h.o = 1; fx(j, h.h, 1); return; }
      if (h.h <= 0) return;
      if (c.rv) { const x = Math.min(h.m - h.h, 12 + bonus); h.h += x; fx(j, x, 1); }
      if (c.b) { h.b += c.b + bonus; fx(j, c.b + bonus, 2); }
      if (c.hl) { const x = Math.min(h.m - h.h, c.hl + bonus); h.h += x; fx(j, x, 1); }
      if (c.s) { h.s += c.s; fx(j, 0, 10); }
      if (c.en) h.e += c.en;
      if (c.dr) draw(h, c.dr);
      if (c.j) h.j += c.j;
      if (c.cl) { h.w = 0; h.v = 0; }
    });
    if (c.tn) { hr.t = 1; fx(seat, 0, 12); }
    if (c.mb) { hr.b += c.mb; fx(seat, c.mb, 2); }
    checkWin(s);
  }

  /* ---------- events ---------- */
  function removeFirst(h, pred) {
    const arr = h.d.split(''); const i = arr.findIndex((ch) => pred(C[cid(ch)], cid(ch)));
    if (i < 0 || arr.length <= 5) return false;
    arr.splice(i, 1); h.d = arr.join(''); return true;
  }
  function doEvent(s, seat, o) {
    const h = s.H[seat], ev = s.ev;
    const heal = (x) => { h.h = Math.min(h.m, h.h + x); };
    if (ev === 0) { if (o === 0) heal(12); else { h.m += 4; h.h += 4; } }
    else if (ev === 1) { if (o === 0) { h.h = Math.max(1, h.h - 7); h.d += AL[pick(POOL[h.k])]; } }
    else if (ev === 2) { if (o === 0 && s.g >= 25) { s.g -= 25; h.d += AL[pick(NEUT)]; } }
    else if (ev === 3) { if (o === 0) removeFirst(h, (c, i) => c.S && i % 10 === 0); else s.g += 12; }
    else if (ev === 4) { if (o === 0) { if (Math.random() < 0.5) s.g += 35; else h.d += AL[CURSE]; } }
    else if (ev === 5) { if (o === 0) removeFirst(h, (c, i) => c.S && i % 10 === 1); else heal(8); }
    else if (ev === 6) { if (o === 0) { h.d += AL[CURSE]; s.g += 45; } }
    else if (ev === 7) { if (o === 0) heal(Math.round(h.m * 0.2)); else { h.m += 2; h.h += 2; } }
  }

  /* ---------- actor / apply / result ---------- */
  function actor(s) {
    if (s.ph === 'x') return null;
    if (s.ph === 'c') return s.H.map((h, i) => (h.k < 0 ? i : -1)).filter((i) => i >= 0);
    if (s.ph === 'm') return voters(s).filter((i) => s.vt[i] < 0);
    if (s.ph === 'f') return s.H.map((h, i) => (h.h > 0 && !h.o ? i : -1)).filter((i) => i >= 0);
    return s.H.map((h, i) => (!h.o ? i : -1)).filter((i) => i >= 0);
  }
  function apply(s, seat, a) {
    const h = s.H[seat];
    if (!h || !a) throw new Error('bad');
    FX = [];
    let enemy = 0;
    const allDone = () => s.H.every((x) => x.o);
    switch (s.ph) {
      case 'c': {
        if (a.t !== 'c' || h.k >= 0) throw new Error('bad');
        const k = a.k | 0; if (!CL[k]) throw new Error('class');
        h.k = k; h.h = h.m = CL[k].hp; h.d = starter(k);
        if (s.H.every((x) => x.k >= 0)) { genMap(s); s.ph = 'm'; resetDone(s); s.lg = '1막 시작! 지도에서 갈 길을 골라요'; }
        break;
      }
      case 'm': {
        if (a.t !== 'v' || s.vt[seat] >= 0 || !voters(s).includes(seat)) throw new Error('bad');
        const ops = mapOpts(s); if (!ops.includes(a.c)) throw new Error('node');
        s.vt[seat] = a.c;
        const vs = voters(s);
        if (vs.every((i) => s.vt[i] >= 0)) {
          const cnt = [0, 0, 0]; vs.forEach((i) => cnt[s.vt[i]]++);
          const mx = Math.max(...cnt), top = [0, 1, 2].filter((c) => cnt[c] === mx);
          enterNode(s, pick(top));
          if (s.ph === 'f') enemy = 2;
        }
        break;
      }
      case 'f': {
        if (h.h <= 0 || h.o) throw new Error('bad');
        if (a.t === 'p') playCard(s, seat, a.i | 0, a.g | 0);
        else if (a.t === 'e') {
          h.o = 1;
          if (s.H.every((x) => x.h <= 0 || x.o)) { enemy = 1; enemyPhase(s); }
        } else throw new Error('bad');
        break;
      }
      case 'w': {
        if (a.t !== 'k' || h.o) throw new Error('bad');
        const i = a.i | 0;
        if (i >= 0) { if (!h.f[i]) throw new Error('offer'); h.d += h.f[i]; }
        h.o = 1;
        if (allDone()) afterNonFight(s);
        break;
      }
      case 'r': {
        if (a.t !== 'r' || h.o) throw new Error('bad');
        if (a.o === 1) {
          const j = a.j | 0; if (h.d.length <= 5 || !h.d[j]) throw new Error('card');
          h.d = h.d.slice(0, j) + h.d.slice(j + 1);
        } else h.h = Math.min(h.m, h.h + Math.round(h.m * (hasR(s, 13) ? 0.5 : 0.3)));
        h.o = 1;
        if (allDone()) afterNonFight(s);
        break;
      }
      case 's': {
        if (h.o) throw new Error('bad');
        if (a.t === 'd') { h.o = 1; if (allDone()) afterNonFight(s); break; }
        if (a.t !== 'b') throw new Error('bad');
        const i = a.i | 0;
        if (i <= 2) {
          const ch = h.f[i]; if (!ch || ch === '_') throw new Error('sold');
          const pr = price(s, C[cid(ch)].k === 7 ? 1 : 0); if (s.g < pr) throw new Error('gold');
          s.g -= pr; h.d += ch; h.f = h.f.slice(0, i) + '_' + h.f.slice(i + 1);
        } else if (i <= 4) {
          const ch = s.sh[i - 3]; if (!ch || ch === '_') throw new Error('sold');
          const pr = price(s, 2); if (s.g < pr) throw new Error('gold');
          s.g -= pr; gainRelic(s, cid(ch)); s.sh = s.sh.slice(0, i - 3) + '_' + s.sh.slice(i - 2);
        } else {
          const j = a.j | 0, pr = price(s, 3);
          if (h.z || h.d.length <= 5 || !h.d[j] || s.g < pr) throw new Error('remove');
          s.g -= pr; h.d = h.d.slice(0, j) + h.d.slice(j + 1); h.z = 1;
        }
        break;
      }
      case 'e': {
        if (a.t !== 'o' || h.o) throw new Error('bad');
        doEvent(s, seat, a.o ? 1 : 0); h.o = 1;
        if (allDone()) afterNonFight(s);
        break;
      }
      default: throw new Error('over');
    }
    s.seq++;
    s.last = { id: s.seq, f: FX, e: enemy };
    FX = null;
    return s;
  }
  function result(s) {
    if (s.ph !== 'x') return null;
    const where = (s.a + 1) + '막 ' + (s.y >= s.ln ? '보스' : Math.max(1, s.y + 1) + '층');
    if (s.res === 'w') return { winners: s.H.map((_, i) => i), title: '레이드 성공! 🎉', text: '심연의 군주를 함께 쓰러뜨렸어요.\n처치 ' + s.kl + ' · 지나온 층 ' + s.fl + ' · 유물 ' + s.rl.length + '개' };
    return { winners: [], title: '파티 전멸…', text: where + '에서 쓰러졌어요.\n처치 ' + s.kl + ' · 보스 ' + s.bk + ' · 다음엔 도발·방어로 서로 지켜 봐요!' };
  }

  /* ---------- AI ---------- */
  function incoming(s) {
    const inc = s.H.map(() => 0);
    s.E.forEach((e) => {
      if (e.h <= 0 || e.i < 0 || e.z > 0) return;
      const parts = EN[e.k].P[e.i] || [], mark = parts.some((p) => p.t === 'M');
      if (parts[0] && parts[0].t === 'C') return;
      parts.forEach((p) => {
        if (p.t === 'a') { const ti = effT(s, e, mark); if (ti >= 0) inc[ti] += eDmg(s, e, s.H[ti], p.v) * p.n; }
        else if (p.t === 'A' || p.t === 'K') s.H.forEach((h, i) => { if (h.h > 0) inc[i] += eDmg(s, e, h, p.v); });
      });
    });
    return inc;
  }
  function playable(h) { let n = 0; for (const ch of h.q) { const c = C[cid(ch)]; if (!c.u && c.c <= h.e) n++; } return n; }
  function V(s, seat, lv) {
    if (s.ph !== 'f') return s.res === 'l' ? -1e5 : 1e4;
    let v = 0;
    s.E.forEach((e) => {
      if (e.h <= 0) return;
      v -= e.h + 0.4 * e.b;
      v += Math.min(e.p * (e.p + 1) / 2, e.h) * 0.7 + 3 * Math.min(e.v, 2) + 1.2 * Math.min(e.w, 2) + (e.z ? 2 : 0);
    });
    const inc = incoming(s);
    s.H.forEach((h, i) => {
      if (h.h <= 0) { v -= 45; return; }
      const w = lv >= 3 || i === seat ? 1.2 : 0.6;
      const u = Math.max(0, inc[i] - h.b);
      v -= w * Math.min(u, h.h + 5);
      if (u >= h.h) v -= 25 * w;
      v += 0.9 * h.h + 3 * h.s + 0.6 * h.j - 1.5 * (h.w > 0) - 1.5 * (h.v > 0);
      if (!h.o) v += 3.5 * h.e + 1.5 * playable(h);
    });
    return v;
  }
  function legal(s, seat) {
    const h = s.H[seat], out = [], seen = {};
    for (let i = 0; i < h.q.length; i++) {
      const ch = h.q[i]; if (seen[ch]) continue; seen[ch] = 1;
      const c = C[cid(ch)]; if (c.u || c.c > h.e) continue;
      if (c.T === 'e') livingE(s).forEach((g) => out.push({ i, g }));
      else if (c.T === 'a') living(s).forEach((g) => out.push({ i, g }));
      else if (c.T === 'd') s.H.forEach((_, g) => out.push({ i, g }));
      else out.push({ i, g: 0 });
    }
    return out;
  }
  function cardScore(ci) {
    const c = C[ci]; if (c.u) return -20;
    let v = (c.d || 0) * (c.hi || 1) * (c.T === 'E' ? 1.8 : 1) + (c.sb ? 8 : 0) + (c.pd ? 6 : 0) + (c.ex ? 4 : 0) + (c.pi ? 2 : 0);
    const m = c.T === 'A' ? 2.2 : 1;
    v += (c.b || 0) * 0.8 * m + (c.hl || 0) * 0.7 * m + (c.s || 0) * 4 * m + (c.en || 0) * 5 + (c.dr || 0) * 2.5 + (c.j || 0) * 1.2 * m;
    v += (c.w || 0) * 2.5 * (c.T === 'E' ? 1.8 : 1) + (c.v || 0) * 3.5 + (c.p || 0) * 1.6 * (c.T === 'E' ? 1.8 : 1) + (c.pp ? 7 : 0) + (c.st ? 13 : 0) + (c.tn ? 5 : 0) + (c.rv ? 14 : 0) + (c.cl ? 3 : 0) + (c.mb || 0) * 0.8 - (c.sl || 0) * 0.6;
    return v / (c.c + 1) + (c.S ? -1.5 : 0);
  }
  function bestStep(s, seat, lv) {
    const opts = legal(s, seat);
    if (!opts.length) return null;
    const base = V(s, seat, lv);
    let best = null, bs = -1e9;
    for (const o of opts) {
      const c = C[cid(s.H[seat].q[o.i])];
      const t = clone(s);
      FX = null;
      try { playCard(t, seat, o.i, o.g); } catch (e) { continue; }
      let ev = V(t, seat, lv) - base + 3.5 * c.c + 1.5;
      if (lv === 2) ev *= 0.75 + Math.random() * 0.5;
      if (lv === 1) ev *= 0.4 + Math.random() * 1.2;
      if (ev <= 0.3) continue;
      const sc = ev / (c.c + 0.6);
      if (sc > bs) { bs = sc; best = { o, t }; }
    }
    return best;
  }
  function aiFight(s, seat, lv) {
    const opts = legal(s, seat);
    if (!opts.length) return { t: 'e' };
    if (lv === 1) {
      if (Math.random() < 0.1) return { t: 'e' };
      if (Math.random() < 0.45) { const o = pick(opts); return { t: 'p', i: o.i, g: o.g }; }
    }
    if (lv >= 3) {
      // 어려움: 이 카드를 낸 뒤 남은 에너지로 이어질 최선의 흐름까지 굴려 보고 고른다
      const endV = (t) => { const hh = t.H[seat]; return V(t, seat, 3) - (t.ph === 'f' && !hh.o ? 3.5 * hh.e + 1.5 * playable(hh) : 0); };
      let best = null, bv = endV(s) + 0.3;
      for (const o of opts) {
        let t = clone(s);
        FX = null;
        try { playCard(t, seat, o.i, o.g); } catch (e) { continue; }
        for (let k = 0; k < 5 && t.ph === 'f'; k++) { const nx = bestStep(t, seat, 3); if (!nx) break; t = nx.t; }
        const v = endV(t);
        if (v > bv) { bv = v; best = o; }
      }
      return best ? { t: 'p', i: best.i, g: best.g } : { t: 'e' };
    }
    const b = bestStep(s, seat, lv);
    return b ? { t: 'p', i: b.o.i, g: b.o.g } : { t: 'e' };
  }
  function nodeScore(s, t, lv) {
    const hpR = s.H.reduce((a, h) => a + h.h / h.m, 0) / s.n;
    switch (t) {
      case 'F': return 3;
      case 'E': return hpR > 0.7 ? (lv >= 3 ? 6 : 4) : hpR > 0.5 ? 1 : -3;
      case 'R': return (1 - hpR) * 12 - 1;
      case 'S': return s.g >= 110 ? 6 : s.g >= 60 ? 3 : 0;
      case '?': return 3;
      case 'T': return 6;
      default: return 0;
    }
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const h = s.H[seat];
    switch (s.ph) {
      case 'c': {
        if (lv === 1) return { t: 'c', k: R(CL.length) };
        const taken = s.H.map((x) => x.k);
        const pref = [0, 2, 1, 3, 4, 5, 6].filter((k) => !taken.includes(k));
        return { t: 'c', k: lv >= 3 || Math.random() < 0.7 ? pref[0] : pick(pref.length ? pref : [0, 1, 2, 3]) };
      }
      case 'm': {
        const ops = mapOpts(s);
        if (lv === 1) return { t: 'v', c: pick(ops) };
        let best = ops[0], bs = -1e9;
        ops.forEach((c) => {
          const row = s.y + 1; let v = nodeScore(s, nodeAt(s, row, c), lv);
          if (lv >= 3 && row + 1 < s.ln) { let m = -1e9; for (let d = -1; d <= 1; d++) { const cc = c + d; if (cc >= 0 && cc < 3 && s.mp[(row + 1) * 3 + cc] !== '.') m = Math.max(m, nodeScore(s, s.mp[(row + 1) * 3 + cc], lv)); } if (m > -1e9) v += 0.5 * m; }
          v += Math.random() * (lv === 2 ? 2 : 0.5);
          if (v > bs) { bs = v; best = c; }
        });
        return { t: 'v', c: best };
      }
      case 'f': return aiFight(s, seat, lv);
      case 'w': {
        if (lv === 1) return { t: 'k', i: Math.random() < 0.2 ? -1 : R(h.f.length) };
        let bi = -1, bv = lv >= 3 && h.d.length >= 14 ? 4.5 : 2;
        for (let i = 0; i < h.f.length; i++) { const v = cardScore(cid(h.f[i])) + (lv === 2 ? Math.random() * 2 : 0); if (v > bv) { bv = v; bi = i; } }
        return { t: 'k', i: bi };
      }
      case 'r': {
        const hpR = h.h / h.m;
        if (lv === 1) return Math.random() < 0.5 || h.d.length <= 5 ? { t: 'r', o: 0 } : { t: 'r', o: 1, j: R(h.d.length) };
        if (hpR < (lv >= 3 ? 0.72 : 0.6) || h.d.length <= 6) return { t: 'r', o: 0 };
        let wj = 0, wv = 1e9; for (let j = 0; j < h.d.length; j++) { const v = cardScore(cid(h.d[j])); if (v < wv) { wv = v; wj = j; } }
        return { t: 'r', o: 1, j: wj };
      }
      case 's': {
        const cur = h.d.indexOf(AL[CURSE]);
        if (lv >= 2 && !h.z && cur >= 0 && s.g >= price(s, 3) && h.d.length > 5) return { t: 'b', i: 5, j: cur };
        if (lv >= 2) for (let i = 0; i < 2; i++) if (s.sh[i] !== '_' && s.g >= price(s, 2) + (lv >= 3 ? 0 : 20)) return { t: 'b', i: 3 + i };
        const reserve = lv === 1 ? 0 : 20 * (s.n - 1);
        for (let i = 0; i < 3; i++) {
          const ch = h.f[i]; if (!ch || ch === '_') continue;
          const ci = cid(ch), pr = price(s, C[ci].k === 7 ? 1 : 0);
          if (s.g - pr >= reserve && (lv === 1 ? Math.random() < 0.5 : cardScore(ci) > (lv >= 3 ? 4.5 : 3.5))) return { t: 'b', i };
        }
        if (lv >= 3 && !h.z && h.d.length > 8 && s.g >= price(s, 3) + 20) {
          let wj = 0, wv = 1e9; for (let j = 0; j < h.d.length; j++) { const v = cardScore(cid(h.d[j])); if (v < wv) { wv = v; wj = j; } }
          return { t: 'b', i: 5, j: wj };
        }
        return { t: 'd' };
      }
      case 'e': {
        if (lv === 1) return { t: 'o', o: R(2) };
        const hpR = h.h / h.m, ev = s.ev;
        let o = 0;
        if (ev === 0) o = hpR < 0.85 ? 0 : 1;
        else if (ev === 1) o = hpR > 0.6 ? 0 : 1;
        else if (ev === 2) o = s.g >= 25 + (lv >= 3 ? 40 : 0) ? 0 : 1;
        else if (ev === 3) o = 0;
        else if (ev === 4) o = lv >= 3 ? 1 : 0;
        else if (ev === 5) o = hpR < 0.6 ? 1 : 0;
        else if (ev === 6) o = lv >= 3 ? 1 : 0;
        else if (ev === 7) o = hpR < 0.9 ? 0 : 1;
        return { t: 'o', o };
      }
    }
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'f') return [0, 1000, 750, 600][lv || 2];
    return 700;
  }

  /* ---------- view ---------- */
  const CSS = `
.rd{position:absolute;inset:0;display:flex;flex-direction:column;gap:6px;padding:6px 8px 8px;color:var(--ink);font-family:var(--f-body);font-size:13px;background:radial-gradient(120% 70% at 50% 0%,#3a2436 0%,#1c1524 62%,#141019 100%);overflow:hidden;user-select:none}
.rd *{box-sizing:border-box}
.rd-bar{display:flex;gap:6px;align-items:center;flex:none}
.rd-bar .lvl{flex:1;min-width:0;font-family:var(--f-display);font-size:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.3px}
.rd-bar .lvl small{font-family:var(--f-body);font-size:11px;color:var(--muted);margin-left:4px}
.rd-bar .btn{min-height:44px;padding:0 9px;font-size:13px;flex:none}
.rd-gold{font-family:var(--f-mono);font-weight:700;color:var(--brass);flex:none;font-size:14px}
.rd-msg{flex:none;min-height:18px;font-size:12.5px;color:var(--muted);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rd-msg b{color:var(--brass)}
.rd-ens{flex:1 1 auto;min-height:150px;display:flex;gap:5px;justify-content:center;align-items:center;padding:6px 4px;border-radius:14px;background:linear-gradient(#2d2132,#1b1520);border:1px solid #3d3047;box-shadow:inset 0 2px 12px #000a;position:relative}
.rd-en{position:relative;flex:0 1 96px;min-width:0;display:flex;flex-direction:column;align-items:center;gap:3px;padding:4px 3px 5px;border-radius:12px;border:2px solid transparent;cursor:pointer;transition:transform .15s}
.rd-en.tg{border-color:var(--coral);background:#ee6a5522;animation:rdp 1s infinite}
.rd-en.dead{opacity:.18;pointer-events:none}
.rd-en.act,.rd-he.act{transform:scale(1.07)}
.rd-int{min-height:22px;max-width:100%;padding:2px 6px;border-radius:9px;background:#f2e9d8;color:#2a1d2c;font-weight:800;font-size:11.5px;white-space:nowrap;overflow:hidden;display:flex;align-items:center;gap:3px;box-shadow:0 2px 0 #0007}
.rd-int.stun{background:#9ad0ff}
.rd-int .tdot{width:10px;height:10px;border-radius:50%;flex:none;border:1.5px solid #2a1d2c}
.rd-face{font-size:32px;line-height:50px;width:52px;height:52px;text-align:center;border-radius:50%;background:radial-gradient(circle at 40% 35%,#56435f,#231a2b);box-shadow:0 3px 0 #0008,inset 0 0 0 2px #ffffff10}
.rd-en.boss .rd-face{width:70px;height:70px;font-size:44px;line-height:68px;background:radial-gradient(circle at 40% 35%,#7a3b4a,#2a1420);box-shadow:0 0 18px #ee6a5555,0 3px 0 #0008}
.rd-nm{font-size:11px;font-weight:700;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rd-hp{position:relative;width:100%;height:14px;border-radius:7px;background:#0008;overflow:hidden;flex:none}
.rd-hp i{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(#ef7a66,#b23e2e);transition:width .3s}
.rd-he .rd-hp i{background:linear-gradient(#7fdc8a,#2f9447)}
.rd-hp span{position:relative;display:block;text-align:center;font:700 10px/14px var(--f-mono);color:#fff;text-shadow:0 1px 1px #000}
.rd-sts{display:flex;flex-wrap:wrap;gap:2px;justify-content:center;font-size:10px;min-height:14px;line-height:14px}
.rd-sts span{padding:0 3px;border-radius:5px;background:#0007;white-space:nowrap}
.rd-sts .blk{background:#2a5fae}
.rd-sts .warn{background:#8a2b22;color:#fff}
.rd-party{flex:none;display:grid;grid-template-columns:1fr 1fr;gap:5px}
.rd-party.one{grid-template-columns:1fr}
.rd-he{position:relative;padding:4px 6px 4px;border-radius:10px;background:var(--surface);border:2px solid #3a3046;border-left:6px solid var(--c);min-width:0;display:flex;flex-direction:column;gap:2px;transition:transform .15s}
.rd-he.tg{border-color:#7ee08a;border-left-color:var(--c);animation:rdq 1s infinite;cursor:pointer}
.rd-he.me{box-shadow:0 0 0 2px var(--brass) inset}
.rd-he.dead{opacity:.45}
.rd-he .r1{display:flex;align-items:center;gap:4px;font-weight:700;font-size:12px;white-space:nowrap;min-height:18px}
.rd-he .r1 .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis}
.rd-he .r1 .en{font-family:var(--f-mono);color:#ffd36b}
.rd-he .r1 .ok{color:#7ee08a}
.rd-he .rd-sts{justify-content:flex-start}
.rd-tabs{flex:none;display:flex;gap:6px;justify-content:center}
.rd-tabs .btn{min-height:44px;padding:0 10px;font-size:12.5px}
.rd-tabs .btn.on{background:var(--brass);color:#2a1d2c}
.rd-hand{flex:none;display:flex;gap:4px;justify-content:center;overflow-x:auto;overflow-y:visible;padding:10px 2px 2px;margin-top:-6px;scrollbar-width:none}
.rd-card{flex:0 0 auto;width:calc((100% - 20px)/5);max-width:84px;min-width:60px;height:98px;padding:16px 3px 4px;border-radius:10px;border:2px solid #0005;border-top-width:6px;background:linear-gradient(#f7efdd,#e3d4b6);color:#2a1d2c;display:flex;flex-direction:column;align-items:center;gap:2px;position:relative;cursor:pointer;text-align:center;font-family:inherit;transition:transform .1s,box-shadow .1s;box-shadow:0 3px 0 #0007}
.rd-card.big{width:31%;max-width:110px;height:132px;flex:0 1 auto}
.rd-card b{font-size:11.5px;line-height:1.15;word-break:keep-all}
.rd-card .cd{font-size:10px;line-height:1.2;color:#4b3b4b;word-break:keep-all}
.rd-card.big b{font-size:13px}.rd-card.big .cd{font-size:11px}
.rd-card .cost{position:absolute;left:-3px;top:-8px;width:23px;height:23px;border-radius:50%;background:#2a5fae;color:#fff;font:800 13px/23px var(--f-mono);box-shadow:0 1px 0 #0008}
.rd-card.t-a{border-top-color:#c9483a}.rd-card.t-s{border-top-color:#3d78c9}.rd-card.t-g{border-top-color:#3fa45a}.rd-card.t-d{border-top-color:#8a55c2}.rd-card.t-p{border-top-color:#d8a12e}.rd-card.t-u{border-top-color:#555;background:linear-gradient(#b9adb0,#8f8387)}
.rd-card.on{transform:translateY(-9px);box-shadow:0 0 0 3px var(--brass),0 6px 10px #0008}
.rd-card.no{opacity:.42}
.rd-card .pr{position:absolute;bottom:-9px;left:50%;transform:translateX(-50%);background:var(--brass);color:#2a1d2c;font:800 11px/16px var(--f-mono);padding:0 6px;border-radius:8px;white-space:nowrap}
.rd-card.sold{opacity:.3;pointer-events:none}
.rd-row{flex:none;display:flex;gap:6px;align-items:center}
.rd-orb{flex:none;width:46px;height:46px;border-radius:50%;background:radial-gradient(circle at 40% 35%,#ffe28a,#d08a1c);color:#2a1d2c;font:900 17px/46px var(--f-mono);text-align:center;box-shadow:0 3px 0 #0008}
.rd-pile{flex:1;min-width:0;font-size:11.5px;color:var(--muted);line-height:1.3}
.rd-row .btn{min-height:46px}
.rd-end{min-width:108px}
.rd-fl{position:absolute;left:50%;top:26%;font:900 18px var(--f-mono);color:#ff6b5b;text-shadow:0 2px 2px #000,0 0 4px #000;pointer-events:none;animation:rdf .95s ease-out forwards;z-index:5;white-space:nowrap}
.rd-fl.k1{color:#7ee08a}.rd-fl.k2{color:#8cc4ff}.rd-fl.kt{color:#ffd36b;font-size:13px;font-family:var(--f-body)}.rd-fl.k13{color:#b9f06a}
@keyframes rdf{from{opacity:1;transform:translate(-50%,0) scale(1.15)}to{opacity:0;transform:translate(-50%,-36px)}}
@keyframes rdp{50%{box-shadow:0 0 14px var(--coral)}}
@keyframes rdq{50%{box-shadow:0 0 14px #7ee08a}}
.rd .hit{animation:rdh .3s}
@keyframes rdh{25%{transform:translateX(-5px)}75%{transform:translateX(5px)}}
.rd-scroll{flex:1 1 auto;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:8px}
.rd-panel{background:color-mix(in srgb,var(--surface) 94%,transparent);border:1px solid var(--line,#3a3046);border-radius:14px;padding:10px}
.rd-panel h3{margin:0 0 6px;font-family:var(--f-display);font-weight:400;font-size:18px}
.rd-cls{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.rd-cls button{min-height:58px;display:flex;align-items:center;gap:6px;text-align:left;padding:6px 8px;border-radius:12px;border:2px solid #3a3046;background:var(--surface-2);color:var(--ink);font-family:inherit;cursor:pointer}
.rd-cls button .i{font-size:24px;flex:none}
.rd-cls button .t{min-width:0;font-size:11px;color:var(--muted);line-height:1.25}
.rd-cls button .t b{display:block;color:var(--ink);font-size:13.5px}
.rd-cls button.lock{opacity:.45}
.rd-cls button.on{border-color:var(--brass)}
.rd-who{display:flex;flex-wrap:wrap;gap:6px;font-size:12px;color:var(--muted)}
.rd-who span{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:9px;background:#0004}
.rd-map{position:relative;flex:1 1 auto;min-height:0;display:grid;border-radius:14px;background:linear-gradient(#2a2131,#1d1724);border:1px solid #3d3047;padding:4px 0}
.rd-map svg{position:absolute;inset:4px 0;width:100%;height:calc(100% - 8px);pointer-events:none}
.rd-mrow{display:grid;grid-template-columns:1fr 1fr 1fr;align-items:center;justify-items:center;position:relative;z-index:1;min-height:0}
.rd-node{position:relative;width:46px;height:46px;border-radius:50%;border:2px solid #4a3d55;background:#2b2236;font-size:21px;display:grid;place-items:center;padding:0;cursor:default;color:var(--ink)}
.rd-node.boss{width:56px;height:56px;font-size:28px;border-color:#a2423a;background:#3a1a22}
.rd-node.ok{border-color:var(--brass);background:#4a3a28;cursor:pointer;animation:rdg 1.2s infinite}
.rd-node.past{opacity:.35}
.rd-node.here{border-color:#7ee08a;box-shadow:0 0 0 3px #7ee08a55}
.rd-node .vd{position:absolute;bottom:-7px;left:50%;transform:translateX(-50%);display:flex;gap:2px}
.rd-node .vd i{width:9px;height:9px;border-radius:50%;border:1.5px solid #1b1426}
@keyframes rdg{50%{box-shadow:0 0 12px var(--brass)}}
.rd-legend{flex:none;font-size:11px;color:var(--muted);text-align:center;line-height:1.4}
.rd-opts{display:flex;flex-direction:column;gap:8px}
.rd-opts .btn{min-height:50px;justify-content:flex-start;text-align:left}
.rd-cards{display:flex;gap:8px;justify-content:center;padding:10px 0 12px;flex-wrap:wrap}
.rd-rlc{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:10px;background:#0003;min-height:48px;cursor:pointer;border:2px solid transparent}
.rd-rlc .i{font-size:22px}
.rd-rlc .t{flex:1;min-width:0;font-size:12px;color:var(--muted)}.rd-rlc .t b{display:block;color:var(--ink);font-size:13px}
.rd-rlc.sold{opacity:.3;pointer-events:none}
.rd-deck{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:8px 0}
.rd-ov{position:absolute;inset:0;z-index:20;background:#0009;display:flex;align-items:flex-end;justify-content:center}
.rd-ov .sheet{width:100%;max-height:86%;overflow-y:auto;background:var(--surface);border-radius:18px 18px 0 0;padding:12px 12px 16px}
.rd-ov .sheet h3{margin:0 0 8px;font-family:var(--f-display);font-weight:400;font-size:18px;display:flex;align-items:center;gap:8px}
.rd-ov .sheet h3 .btn{margin-left:auto}
@media (min-height:760px){.rd-card{height:108px}.rd-face{width:58px;height:58px;font-size:36px;line-height:56px}.rd-ens{min-height:190px}.rd-he{padding:6px 7px}}
`;

  function mount(root, api) {
    const h = L.h;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'rd' });
    root.append(style, wrap);
    let S = null, cur = -1, sel = -1, pend = false, pendT = 0, lastId = null, timers = [], busy = false, ov = null, rmMode = false, endArm = 0, endT = 0;
    const sp = () => L.debug.speed || 1;
    const store = U.store || { get: (k, d) => d, set() {} };
    let ul = 99;   // 판 밖 해금 없음(사용자 요청): 모든 직업을 처음부터

    const P = (i) => api.players[i] || { name: '?', color: '#888' };
    const locals = () => api.players.map((_, i) => i).filter((i) => api.canAct(i));
    const act = () => (S ? actor(S) || [] : []);
    function send(seat, a) {
      if (pend) return;
      pend = true; clearTimeout(pendT); pendT = setTimeout(() => { pend = false; render(); }, 2500);
      sel = -1; rmMode = false; endArm = 0;
      if (locals().length > 1 && api.actAs) api.actAs(seat, a); else api.act(a);
    }
    function pickCur() {
      const loc = locals(), need = act().filter((i) => loc.includes(i));
      if (need.includes(cur)) return;
      if (need.length) { cur = need[0]; sel = -1; rmMode = false; return; }
      if (!loc.includes(cur)) cur = loc.length ? loc[0] : -1;
    }

    function hpBar(v, m) { return h('div', { class: 'rd-hp' }, h('i', { style: { width: Math.round(100 * Math.max(0, v) / Math.max(1, m)) + '%' } }), h('span', { text: v + '/' + m })); }
    function intentEl(e, ei) {
      if (e.h <= 0) return h('div', { class: 'rd-int', style: { visibility: 'hidden' } }, '·');
      if (e.z > 0) return h('div', { class: 'rd-int stun' }, '💫 기절');
      if (e.i < 0) return h('div', { class: 'rd-int' }, '…');
      const parts = EN[e.k].P[e.i] || [], mark = parts.some((p) => p.t === 'M'), bits = [];
      let tgt = -1;
      parts.forEach((p) => {
        if (p.t === 'a') { tgt = effT(S, e, mark); const d = eDmg(S, e, S.H[tgt], p.v); bits.push('⚔' + d + (p.n > 1 ? '×' + p.n : '')); }
        else if (p.t === 'A') bits.push('💥' + eDmg(S, e, null, p.v));
        else if (p.t === 'K') bits.push('💥' + eDmg(S, e, null, p.v) + '!');
        else if (p.t === 'b' || p.t === 'B') bits.push('🛡');
        else if (p.t === 's' || p.t === 'S') bits.push('💪');
        else if (p.t === 'w' || p.t === 'v') { tgt = effT(S, e, mark); bits.push('🌀'); }
        else if (p.t === 'W' || p.t === 'V') bits.push('🌀');
        else if (p.t === 'h') bits.push('💚');
        else if (p.t === 'c') { tgt = effT(S, e, mark); bits.push('🩸'); }
        else if (p.t === 'z') bits.push('📯');
        else if (p.t === 'C') bits.push('⏳' + Math.min(e.dr, thr(S)) + '/' + thr(S));
        else if (p.t === 'M') bits.unshift('🎯');
      });
      const uniq = bits.filter((b, i) => bits.indexOf(b) === i || b[0] === '⚔');
      return h('div', { class: 'rd-int' }, uniq.join(''), tgt >= 0 ? h('span', { class: 'tdot', style: { background: P(tgt).color } }) : null);
    }
    function intentText(e) {
      if (e.z > 0) return '기절해서 이번엔 아무것도 못 해요';
      const parts = EN[e.k].P[e.i] || [], mark = parts.some((p) => p.t === 'M'), t = [];
      parts.forEach((p) => {
        const tg = () => { const i = effT(S, e, mark); return i >= 0 ? P(i).name : ''; };
        if (p.t === 'a') { const i = effT(S, e, mark); t.push(tg() + '에게 ' + eDmg(S, e, S.H[i], p.v) + ' 피해' + (p.n > 1 ? ' ×' + p.n : '')); }
        else if (p.t === 'A') t.push('모두에게 ' + eDmg(S, e, null, p.v) + ' 피해');
        else if (p.t === 'K') t.push('대폭발! 모두에게 ' + eDmg(S, e, null, p.v) + ' 피해');
        else if (p.t === 'b') t.push('방어');
        else if (p.t === 'B') t.push('적 모두 방어');
        else if (p.t === 's') t.push('힘 +' + p.v);
        else if (p.t === 'S') t.push('적 모두 힘 +' + p.v);
        else if (p.t === 'w') t.push(tg() + ' 약화 ' + p.v);
        else if (p.t === 'v') t.push(tg() + ' 취약 ' + p.v);
        else if (p.t === 'W') t.push('모두 약화 ' + p.v);
        else if (p.t === 'V') t.push('모두 취약 ' + p.v);
        else if (p.t === 'h') t.push('적 모두 회복');
        else if (p.t === 'c') t.push(tg() + '에게 상처 카드 ' + p.v + '장');
        else if (p.t === 'z') t.push(EN[p.v].n + ' 부르기');
        else if (p.t === 'C') t.push('기 모으기 — 이번 판 피해 ' + thr(S) + ' 넘기면 끊김(지금 ' + e.dr + ')');
        else if (p.t === 'M') t.push('🎯 표식(도발 무시)');
      });
      return t.join(', ');
    }
    function stsEl(o, hero, inc) {
      const t = [];
      if (o.b > 0) t.push(h('span', { class: 'blk', text: '🛡' + o.b }));
      if (o.s > 0) t.push(h('span', { text: '💪' + o.s }));
      if (o.w > 0) t.push(h('span', { text: '약화' + o.w }));
      if (o.v > 0) t.push(h('span', { text: '취약' + o.v }));
      if (!hero && o.p > 0) t.push(h('span', { text: '☠독' + o.p }));
      if (hero && o.t > 0) t.push(h('span', { text: '😤도발' }));
      if (hero && o.j > 0) t.push(h('span', { text: '🌵' + o.j }));
      if (hero && inc > 0 && o.h > 0) { const u = Math.max(0, inc - o.b); t.push(h('span', { class: u > 0 ? 'warn' : 'blk', text: u > 0 ? '⚠' + u : '✓막음' })); }
      return h('div', { class: 'rd-sts' }, t);
    }
    function heroEl(i, opt) {
      const hr = S.H[i], cl = CL[hr.k] || { ic: '❔', n: '고르는 중' }, p = P(i);
      const inc = opt.inc ? opt.inc[i] : 0;
      const tg = opt.tg && (opt.tg === 'd' || hr.h > 0);
      const cls = 'rd-he' + (hr.h <= 0 && hr.k >= 0 ? ' dead' : '') + (i === cur ? ' me' : '') + (tg ? ' tg' : '');
      const right = S.ph === 'f' ? (hr.h <= 0 ? h('span', { text: '💀' }) : hr.o ? h('span', { class: 'ok', text: '✓' }) : h('span', { class: 'en', text: '⚡' + hr.e }))
        : (S.ph !== 'm' && S.ph !== 'x' && hr.o) || (S.ph === 'm' && S.vt[i] >= 0) ? h('span', { class: 'ok', text: '✓' }) : null;
      return h('div', {
        class: cls, 'data-t': i, style: { '--c': p.color },
        onclick() {
          if (tg) return useSel(i);
          if (locals().includes(i) && act().includes(i) && i !== cur) { cur = i; sel = -1; render(); return; }
          if (hr.k >= 0) api.toast(p.name + ' · ' + cl.n + ' ' + hr.h + '/' + hr.m);
        },
      }, h('div', { class: 'r1' }, h('span', { text: cl.ic }), h('span', { class: 'nm', text: p.name }), right),
      hr.k >= 0 ? hpBar(hr.h, hr.m) : null, S.ph === 'f' ? stsEl(hr, true, inc) : null);
    }
    function partyEl(opt) {
      return h('div', { class: 'rd-party' + (S.n === 1 ? ' one' : '') }, S.H.map((_, i) => heroEl(i, opt || {})));
    }
    function cardEl(ch, opt) {
      const c = C[cid(ch)];
      return h('button', { class: 'rd-card t-' + ctype(c) + (opt.big ? ' big' : '') + (opt.on ? ' on' : '') + (opt.no ? ' no' : '') + (opt.sold ? ' sold' : ''), onclick: opt.onclick },
        h('span', { class: 'cost', text: c.u ? '−' : c.c }), h('b', { text: c.n }), h('span', { class: 'cd', text: desc(c) }),
        opt.price != null ? h('span', { class: 'pr', text: '💰' + opt.price }) : null);
    }
    function bar() {
      const lvl = S.ph === 'c' ? '직업 고르기' : (S.a + 1) + '막';
      const fl = S.ph === 'c' ? '' : S.y < 0 ? '출발' : S.y >= S.ln ? '보스' : (S.y + 1) + '/' + S.ln + '층';
      const me = cur >= 0 && S.H[cur] && S.H[cur].k >= 0;
      return h('div', { class: 'rd-bar' },
        h('div', { class: 'lvl' }, lvl, h('small', { text: fl + (S.ph === 'f' ? ' · ' + S.rd + '판' : '') })),
        h('span', { class: 'rd-gold', text: '💰' + S.g }),
        h('button', { class: 'btn sm ghost', text: '유물 ' + S.rl.length, onclick: () => { ov = 'rl'; render(); } }),
        me ? h('button', { class: 'btn sm ghost', text: '덱 ' + S.H[cur].d.length, onclick: () => { ov = 'dk'; render(); } }) : null);
    }
    function msg(t) { const m = h('div', { class: 'rd-msg' }); if (Array.isArray(t)) m.append(...t); else m.textContent = t; return m; }
    function tabs(need) {
      const loc = locals().filter((i) => need.includes(i));
      if (loc.length < 2) return null;
      return h('div', { class: 'rd-tabs' }, loc.map((i) => h('button', { class: 'btn sm' + (i === cur ? ' on' : ''), onclick: () => { cur = i; sel = -1; rmMode = false; render(); } },
        h('span', { class: 'dot', style: { '--c': P(i).color } }), (CL[S.H[i].k] ? CL[S.H[i].k].ic + ' ' : '') + P(i).name)));
    }
    function waitText(list) {
      const w = list.filter((i) => !locals().includes(i)).map((i) => P(i).name);
      return w.length ? w.join(', ') + ' 기다리는 중…' : '';
    }

    /* ---- targeting ---- */
    function selCard() { if (sel < 0 || cur < 0) return null; const ch = S.H[cur].q[sel]; return ch ? C[cid(ch)] : null; }
    function useSel(g) {
      const c = selCard(); if (!c) return;
      api.sfx('card'); api.buzz(12);
      send(cur, { t: 'p', i: sel, g });
    }
    function tapCard(i) {
      const hr = S.H[cur], c = C[cid(hr.q[i])];
      if (c.u) { api.toast('상처: 쓸 수 없는 카드예요'); return; }
      if (c.c > hr.e) { api.toast('에너지가 모자라요'); api.buzz(30); return; }
      if (sel === i) {
        if (c.T === 'e') { const le = livingE(S); if (le.length === 1) return useSel(le[0]); api.toast('노릴 적을 누르세요'); return; }
        if (c.T === 'a' || c.T === 'd') { useSel(cur); return; }
        return useSel(0);
      }
      sel = i; api.sfx('tick'); render();
    }

    /* ---- screens ---- */
    function scClass() {
      const loc = locals(), need = act().filter((i) => loc.includes(i));
      const me = need.includes(cur) ? cur : -1;
      const grid = h('div', { class: 'rd-cls' }, CL.map((cl, k) => {
        const locked = cl.ul > ul;
        return h('button', {
          class: (locked ? 'lock' : '') + (S.H.some((x) => x.k === k) ? ' on' : ''),
          onclick() {
            if (me < 0) return;
            if (locked) { api.toast('🔒 ' + UL_TXT[cl.ul]); return; }
            api.sfx('click'); send(me, { t: 'c', k });
          },
        }, h('span', { class: 'i', text: locked ? '🔒' : cl.ic }), h('span', { class: 't' }, h('b', { text: cl.n + ' · 체력 ' + cl.hp }), locked ? UL_TXT[cl.ul] : cl.role));
      }));
      const who = h('div', { class: 'rd-who' }, S.H.map((x, i) => h('span', {}, h('span', { class: 'dot', style: { '--c': P(i).color } }), P(i).name + ' ' + (x.k >= 0 ? CL[x.k].ic + CL[x.k].n : '…'))));
      return [msg(me >= 0 ? [h('b', { text: P(me).name }), ' 의 직업을 고르세요 (같은 직업도 돼요)'] : waitText(act()) || '모두 골랐어요'),
        tabs(act()), h('div', { class: 'rd-scroll' }, h('div', { class: 'rd-panel' }, grid), h('div', { class: 'rd-panel' }, who))];
    }
    function scMap() {
      const ops = mapOpts(S), vs = voters(S), loc = locals();
      const myV = vs.filter((i) => loc.includes(i) && S.vt[i] < 0);
      const me = myV.includes(cur) ? cur : myV[0] != null ? myV[0] : -1;
      const rows = S.ln + 1, map = h('div', { class: 'rd-map', style: { gridTemplateRows: 'repeat(' + rows + ',1fr)' } });
      const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', '0 0 300 ' + rows * 100); svg.setAttribute('preserveAspectRatio', 'none');
      const yOf = (r) => (S.ln - r) * 100 + 50, xOf = (c) => c * 100 + 50;
      const line = (x1, y1, x2, y2, on) => { const l = document.createElementNS(NS, 'line'); l.setAttribute('x1', x1); l.setAttribute('y1', y1); l.setAttribute('x2', x2); l.setAttribute('y2', y2); l.setAttribute('stroke', on ? '#e3ae45' : '#5a4a66'); l.setAttribute('stroke-width', on ? 3 : 2); l.setAttribute('stroke-dasharray', on ? '' : '5 5'); l.setAttribute('vector-effect', 'non-scaling-stroke'); svg.append(l); };
      for (let r = 0; r < S.ln; r++) for (let c = 0; c < 3; c++) {
        if (S.mp[r * 3 + c] === '.') continue;
        if (r === S.ln - 1) { line(xOf(c), yOf(r), xOf(1), yOf(S.ln), S.y === r && S.x === c); continue; }
        for (let d = -1; d <= 1; d++) { const cc = c + d; if (cc < 0 || cc > 2 || S.mp[(r + 1) * 3 + cc] === '.') continue; line(xOf(c), yOf(r), xOf(cc), yOf(r + 1), S.y === r && S.x === c); }
      }
      map.append(svg);
      for (let r = S.ln; r >= 0; r--) {
        const row = h('div', { class: 'rd-mrow' });
        for (let c = 0; c < 3; c++) {
          const t = nodeAt(S, r, c);
          if (r === S.ln && c !== 1 || t === '.') { row.append(h('span')); continue; }
          const ok = r === S.y + 1 && ops.includes(c) && me >= 0;
          const here = r === S.y && c === S.x, past = r < S.y || (r === S.y && c !== S.x);
          const vd = r === S.y + 1 ? S.vt.map((v, i) => (v === c ? h('i', { style: { background: P(i).color } }) : null)).filter(Boolean) : [];
          row.append(h('button', {
            class: 'rd-node' + (t === 'B' ? ' boss' : '') + (ok ? ' ok' : '') + (here ? ' here' : '') + (past && !here ? ' past' : ''),
            'aria-label': NODE[t].n,
            onclick() { if (ok) { api.sfx('click'); send(me, { t: 'v', c }); } else api.toast(NODE[t].ic + ' ' + NODE[t].n + (t === 'B' ? ' · ' + EN[S.bo[S.a]].n : '')); },
          }, here ? '📍' : t === 'B' ? EN[S.bo[S.a]].ic : NODE[t].ic, vd.length ? h('span', { class: 'vd' }, vd) : null));
        }
        map.append(row);
      }
      const multi = vs.length > 1;
      const m = me >= 0 ? [h('b', { text: (loc.length > 1 ? P(me).name + ' · ' : '') + '반짝이는 칸' }), ' 을 눌러 다음 길을 골라요' + (multi ? ' (표 많은 곳으로)' : '')]
        : waitText(act()) || S.lg;
      return [msg(S.lg && me >= 0 ? S.lg : ''), msg(m), tabs(myV), map,
        h('div', { class: 'rd-legend', text: '⚔️전투 ☠️엘리트 🔥휴식 🛒상점 ❓사건 🎁보물 · 바로 위 옆 칸까지 갈 수 있어요' }), partyEl()];
    }
    function scFight() {
      const inc = incoming(S), loc = locals(), A = act();
      const myTurn = cur >= 0 && A.includes(cur);
      const hr = cur >= 0 ? S.H[cur] : null;
      const c = myTurn ? selCard() : null;
      const ens = h('div', { class: 'rd-ens' }, S.E.map((e, ei) => {
        const tg = c && c.T === 'e' && e.h > 0;
        const d = EN[e.k];
        return h('div', {
          class: 'rd-en' + (d.bs ? ' boss' : '') + (e.h <= 0 ? ' dead' : '') + (tg ? ' tg' : ''), 'data-t': 10 + ei,
          onclick() { if (tg) return useSel(ei); if (e.h > 0) api.toast(d.n + ': ' + intentText(e) + (d.tip ? '\n' + d.tip : '')); },
        }, intentEl(e, ei), h('div', { class: 'rd-face', text: d.ic }), h('div', { class: 'rd-nm', text: d.n }), hpBar(e.h, e.m), stsEl(e, false));
      }));
      let hint;
      if (myTurn && c) hint = c.T === 'e' ? '🎯 노릴 적을 누르세요' : c.T === 'a' ? '💚 줄 아군을 누르세요 (카드 한 번 더 = 나에게)' : c.T === 'd' ? '💚 아군을 누르세요 (쓰러진 아군도 돼요)' : '한 번 더 누르면 사용 · 다른 카드를 눌러 바꾸기';
      else if (myTurn) hint = (loc.length > 1 ? P(cur).name + ' · ' : '') + '카드를 눌러 고르세요 · 적을 누르면 다음 행동 설명';
      else hint = waitText(A) || S.lg;
      const out = [ens, msg(myTurn ? hint : [S.lg && !hint.startsWith(S.lg) ? S.lg + ' · ' : '', hint]),
        partyEl({ inc, tg: c && (c.T === 'a' || c.T === 'd') ? c.T : null }), tabs(A)];
      if (hr && hr.k >= 0) {
        const hand = h('div', { class: 'rd-hand' }, hr.q.split('').map((ch, i) => {
          const cc = C[cid(ch)];
          return cardEl(ch, { on: myTurn && sel === i, no: !myTurn || cc.u || cc.c > hr.e, onclick: () => { if (myTurn && !pend) tapCard(i); } });
        }));
        if (!hr.q.length) hand.append(h('div', { class: 'muted', style: { padding: '30px 0', fontSize: '12px' }, text: hr.h <= 0 ? '쓰러졌어요 — 치유사의 부활을 기다려요' : '손에 카드가 없어요' }));
        const endBtn = h('button', {
          class: 'btn primary rd-end', disabled: !myTurn || pend ? true : null,
          text: !myTurn ? (hr.h > 0 && hr.o ? '기다리는 중' : '—') : endArm ? '정말 끝내기?' : '턴 종료',
          onclick() {
            if (!myTurn || pend) return;
            if (!endArm && playable(hr) > 0) { endArm = 1; clearTimeout(endT); endT = setTimeout(() => { endArm = 0; render(); }, 2200); render(); return; }
            endArm = 0; api.sfx('click'); send(cur, { t: 'e' });
          },
        });
        out.push(hand, h('div', { class: 'rd-row' }, h('div', { class: 'rd-orb', text: hr.e + '' }),
          h('div', { class: 'rd-pile' }, '뽑을 카드 ' + hr.p.length + ' · 버린 카드 ' + hr.r.length, h('br'), endArm ? '쓸 수 있는 카드가 남았어요' : CL[hr.k].ic + ' ' + P(cur).name), endBtn));
      }
      return out;
    }
    function heroPanel(me, body) {
      return h('div', { class: 'rd-panel' }, h('h3', {}, CL[S.H[me].k].ic + ' ' + P(me).name, h('small', { class: 'muted', style: { fontSize: '12px', fontFamily: 'var(--f-body)' }, text: ' 체력 ' + S.H[me].h + '/' + S.H[me].m + ' · 덱 ' + S.H[me].d.length + '장' })), body);
    }
    function deckPicker(me, onPick) {
      const hr = S.H[me];
      return h('div', {}, h('div', { class: 'muted', style: { fontSize: '12px' }, text: '뺄 카드를 누르세요 (덱은 5장 아래로 줄일 수 없어요)' }),
        h('div', { class: 'rd-deck' }, hr.d.split('').map((ch, j) => cardEl(ch, { onclick: () => onPick(j) }))),
        h('button', { class: 'btn ghost', text: '취소', onclick: () => { rmMode = false; render(); } }));
    }
    function scReward() {
      const A = act(), loc = locals(), need = A.filter((i) => loc.includes(i));
      const me = need.includes(cur) ? cur : -1;
      const out = [msg(S.lg), tabs(need)];
      if (me >= 0) {
        const hr = S.H[me];
        out.push(h('div', { class: 'rd-scroll' }, heroPanel(me, h('div', {},
          h('div', { class: 'muted', style: { fontSize: '12px' }, text: '덱에 넣을 카드 1장을 골라요' }),
          h('div', { class: 'rd-cards' }, hr.f.split('').map((ch, i) => cardEl(ch, { big: true, onclick: () => { api.sfx('card'); send(me, { t: 'k', i }); } }))),
          h('button', { class: 'btn ghost', style: { width: '100%' }, text: '건너뛰기 (덱을 가볍게)', onclick: () => send(me, { t: 'k', i: -1 }) }))), partyEl()));
      } else out.push(msg(waitText(A)), h('div', { class: 'rd-scroll' }, partyEl()));
      return out;
    }
    function scRest() {
      const A = act(), loc = locals(), need = A.filter((i) => loc.includes(i));
      const me = need.includes(cur) ? cur : -1;
      const out = [msg(S.lg), tabs(need)];
      if (me >= 0) {
        const hr = S.H[me], heal = Math.min(hr.m - hr.h, Math.round(hr.m * (hasR(S, 13) ? 0.5 : 0.3)));
        out.push(h('div', { class: 'rd-scroll' }, heroPanel(me, rmMode ? deckPicker(me, (j) => send(me, { t: 'r', o: 1, j })) : h('div', { class: 'rd-opts' },
          h('button', { class: 'btn primary', text: '🔥 쉬기 — 체력 +' + heal, onclick: () => { api.sfx('pop'); send(me, { t: 'r', o: 0 }); } }),
          h('button', { class: 'btn', text: '✂️ 카드 1장 빼기 — 덱을 날렵하게', disabled: hr.d.length <= 5 ? true : null, onclick: () => { rmMode = true; render(); } }))), partyEl()));
      } else out.push(msg(waitText(A)), h('div', { class: 'rd-scroll' }, partyEl()));
      return out;
    }
    function scShop() {
      const A = act(), loc = locals(), need = A.filter((i) => loc.includes(i));
      const me = need.includes(cur) ? cur : -1;
      const out = [msg('💰 파티 골드 ' + S.g + ' · 모두 함께 써요'), tabs(need)];
      if (me < 0) { out.push(msg(waitText(A)), h('div', { class: 'rd-scroll' }, partyEl())); return out; }
      const hr = S.H[me];
      if (rmMode) { out.push(h('div', { class: 'rd-scroll' }, heroPanel(me, deckPicker(me, (j) => send(me, { t: 'b', i: 5, j }))))); return out; }
      const cards = h('div', { class: 'rd-cards' }, hr.f.split('').map((ch, i) => {
        if (ch === '_') return cardEl(AL[CURSE], { big: true, sold: true });
        const pr = price(S, C[cid(ch)].k === 7 ? 1 : 0);
        return cardEl(ch, { big: true, price: pr, no: S.g < pr, onclick: () => { if (S.g < pr) { api.toast('골드가 모자라요'); return; } api.sfx('chip'); send(me, { t: 'b', i }); } });
      }));
      const rel = S.sh.split('').map((ch, i) => {
        if (ch === '_') return null;
        const r = RL[cid(ch)], pr = price(S, 2);
        return h('div', { class: 'rd-rlc', onclick: () => { if (S.g < pr) { api.toast('골드가 모자라요'); return; } api.sfx('chip'); send(me, { t: 'b', i: 3 + i }); } },
          h('span', { class: 'i', text: r.ic }), h('span', { class: 't' }, h('b', { text: r.n + ' (모두에게)' }), r.d), h('span', { class: 'rd-gold', text: '💰' + pr }));
      });
      const rp = price(S, 3);
      out.push(h('div', { class: 'rd-scroll' }, heroPanel(me, h('div', {}, cards, h('div', { class: 'rd-opts' }, rel,
        h('button', { class: 'btn', disabled: hr.z || hr.d.length <= 5 || S.g < rp ? true : null, text: '✂️ 카드 1장 빼기 💰' + rp + (hr.z ? ' (이미 씀)' : ''), onclick: () => { rmMode = true; render(); } }),
        h('button', { class: 'btn primary', text: '다 샀어요 →', onclick: () => send(me, { t: 'd' }) }))))));
      return out;
    }
    function scEvent() {
      const A = act(), loc = locals(), need = A.filter((i) => loc.includes(i));
      const me = need.includes(cur) ? cur : -1, ev = EVT[S.ev];
      const out = [tabs(need)];
      const body = h('div', { class: 'rd-panel' }, h('h3', { text: ev.ic + ' ' + ev.n }), h('p', { style: { margin: '0 0 10px', color: 'var(--muted)' }, text: ev.t + ' (각자 골라요)' }),
        me >= 0 ? h('div', { class: 'rd-opts' }, ev.o.map((t, o) => h('button', { class: 'btn' + (o === 0 ? ' primary' : ''), text: t, onclick: () => { api.sfx('click'); send(me, { t: 'o', o }); } })))
          : h('div', { class: 'muted', text: waitText(A) || '…' }));
      out.push(msg(me >= 0 ? [h('b', { text: P(me).name }), ' 은(는) 어떻게 할까요?'] : ''), h('div', { class: 'rd-scroll' }, body, partyEl()));
      return out;
    }
    function scEnd() {
      return [msg(S.lg), h('div', { class: 'rd-scroll' }, h('div', { class: 'rd-panel' }, h('h3', { text: S.res === 'w' ? '🎉 레이드 성공!' : '💀 파티 전멸' }),
        h('div', { class: 'muted', text: '처치 ' + S.kl + ' · 보스 ' + S.bk + ' · 지나온 층 ' + S.fl })), partyEl())];
    }
    function overlay() {
      if (!ov) return null;
      const close = () => { ov = null; render(); };
      let title, body;
      if (ov === 'rl') {
        title = '🎒 파티 유물 ' + S.rl.length + '개';
        body = S.rl.length ? h('div', { class: 'rd-opts' }, S.rl.split('').map((ch) => { const r = RL[cid(ch)]; return h('div', { class: 'rd-rlc' }, h('span', { class: 'i', text: r.ic }), h('span', { class: 't' }, h('b', { text: r.n }), r.d)); }))
          : h('div', { class: 'muted', text: '아직 유물이 없어요. 엘리트·보스·보물·상점에서 얻어요.' });
      } else {
        const hr = S.H[cur];
        title = CL[hr.k].ic + ' ' + P(cur).name + '의 덱 ' + hr.d.length + '장';
        body = h('div', { class: 'rd-deck' }, hr.d.split('').sort().map((ch) => cardEl(ch, {})));
      }
      return h('div', { class: 'rd-ov', onclick: (e) => { if (e.target.classList.contains('rd-ov')) close(); } },
        h('div', { class: 'sheet' }, h('h3', {}, title, h('button', { class: 'btn sm', text: '닫기', onclick: close })), body));
    }

    function render() {
      if (!S) return;
      pickCur();
      if (sel >= 0 && (S.ph !== 'f' || !S.H[cur] || sel >= S.H[cur].q.length)) sel = -1;
      if (ov === 'dk' && !(cur >= 0 && S.H[cur].k >= 0)) ov = null;
      let body;
      switch (S.ph) {
        case 'c': body = scClass(); break;
        case 'm': body = scMap(); break;
        case 'f': body = scFight(); break;
        case 'w': body = scReward(); break;
        case 'r': body = scRest(); break;
        case 's': body = scShop(); break;
        case 'e': body = scEvent(); break;
        default: body = scEnd();
      }
      wrap.replaceChildren(bar(), ...body.filter(Boolean));
      const o = overlay(); if (o) wrap.append(o);
    }
    function showFx(f) {
      const [code, v, k] = f;
      const el = wrap.querySelector('[data-t="' + code + '"]'); if (!el) return;
      if (k === 9) { el.classList.add('act'); timers.push(setTimeout(() => el.classList.remove('act'), 260 / sp())); return; }
      let txt, cls = 'rd-fl';
      if (k === 0) { txt = v > 0 ? '−' + v : '막음'; if (v > 0) { el.classList.remove('hit'); void el.offsetWidth; el.classList.add('hit'); } }
      else if (k === 1) { if (!v) return; txt = '+' + v; cls += ' k1'; }
      else if (k === 2) { txt = '🛡+' + v; cls += ' k2'; }
      else if (k === 13) { txt = '☠' + v; cls += ' k13'; }
      else { txt = FXT[k]; cls += ' kt'; }
      if (!txt) return;
      const fl = h('span', { class: cls, text: txt });
      el.append(fl); timers.push(setTimeout(() => fl.remove(), 950));
    }
    function playFx(prev) {
      const l = S.last;
      if (!l || l.id === lastId) return;
      const first = lastId === null; lastId = l.id;
      if (first && !prev) return;
      const list = l.f || [];
      if (l.e === 1) {
        busy = true; api.setBusy(true);
        const step = 210 / sp();
        list.forEach((f, k) => timers.push(setTimeout(() => { showFx(f); if (f[2] === 0 && f[1] > 0 && f[0] < 10) { api.sfx('hit'); if (api.canAct(f[0])) api.buzz(25); } }, k * step)));
        timers.push(setTimeout(() => { busy = false; api.setBusy(false); }, list.length * step + 200 / sp()));
      } else {
        list.forEach(showFx);
        if (list.some((f) => f[2] === 0 && f[1] > 0)) api.sfx('hit');
      }
      if (l.e === 2) api.sfx('whoosh');
      if (prev && prev.ph === 'f' && S.ph === 'w') { api.sfx('win'); api.toast(S.lg); }
      if (prev && prev.ph === 'm' && S.ph === 'm' && S.lg !== prev.lg) api.toast(S.lg);
    }
    function checkUnlock() {
      if (!api.mySeats || !api.mySeats().length) return;
      const lvl = S.res === 'w' ? 3 : Math.min(2, S.bk);
      if (lvl > ul) {
        const old = ul; return; ul = lvl; store.set('raid.ul', ul);
        CL.forEach((cl) => { if (cl.ul > old && cl.ul <= ul) api.toast('🔓 새 직업 열림: ' + cl.ic + ' ' + cl.n + '!'); });
      }
    }
    return {
      update(s, prev) {
        S = s; pend = false; clearTimeout(pendT);
        if (prev && prev !== s && (prev.ph !== s.ph)) { sel = -1; rmMode = false; ov = ov === 'rl' ? ov : null; }
        checkUnlock();
        render();
        if (prev !== s) playFx(prev);
      },
      destroy() { timers.forEach(clearTimeout); clearTimeout(pendT); clearTimeout(endT); if (busy) api.setBusy(false); style.remove(); wrap.remove(); },
    };
  }

  /* ---------- 도감 (codex) — 직업·카드·유물·적 표에서 자동 생성 ---------- */
  const CX_ACT = { a: '공격', A: '모두 공격', b: '방어', B: '적 모두 방어', s: '힘+', S: '적 모두 힘+', w: '약화', v: '취약', W: '모두 약화', V: '모두 취약', h: '적 모두 회복', c: '상처 카드', z: '소환', C: '기 모으기', K: '대폭발', M: '표식' };
  const cxMoves = (e) => e.P.map((m) => m.map((p) => p.t === 'z' ? '소환(' + EN[p.v].n + ')' : p.t === 'C' || p.t === 'M' ? CX_ACT[p.t] : CX_ACT[p.t] + ' ' + p.v + (p.n > 1 ? '×' + p.n : '')).join('+')).join(' → ');
  const cxEnemy = (e, tag) => ({ icon: e.ic, name: e.n, tag, desc: '체력 ' + e.h + ' · ' + (e.o === 'r' ? '무작위로: ' : '순서대로: ') + cxMoves(e) + (e.tip ? ' · ' + e.tip : '') });
  const cxCard = (c) => ({ icon: CL[c.k] ? CL[c.k].ic : c.k === 7 ? '🃏' : '🩸', name: c.n, tag: (CL[c.k] ? CL[c.k].n + ' ' : '') + '⚡' + c.c + (c.S ? ' · 기본' : ''), desc: desc(c) });
  const CODEX = [
    { h: '직업', p: ['시작 덱 8장: 기본 공격 ×4 · 기본 방어 ×3 · 직업 기본 카드 ×1. 에너지는 판마다 ⚡3.'],
      rows: CL.map((k, i) => ({ icon: k.ic, name: k.n, tag: '체력 ' + k.hp, desc: k.role + ' · 시작 덱: ' + C[i * 10].n + '×4, ' + C[i * 10 + 1].n + '×3, ' + C[i * 10 + 2].n + '' })) },
    { h: '스킬 카드', p: ['직업별 카드예요(직업 순서대로). 「기본」은 시작 덱 카드, 나머지는 보상·상점에서 얻어요.'], rows: C.filter((c) => c.k < 7).map(cxCard) },
    { h: '공용 카드', p: ['어느 직업이든 상점·사건에서 얻는 카드와 저주 카드예요.'], rows: C.filter((c) => c.k >= 7).map(cxCard) },
    { h: '유물', p: ['엘리트·보스·보물·상점에서 얻어요. 파티 모두에게 효과가 있어요.'], rows: RL.map((r) => ({ icon: r.ic, name: r.n, desc: r.d })) },
    { h: '적', p: ['체력은 기본값이에요(인원·난이도에 따라 늘어요). 공격·방어 수치도 난이도에 따라 달라져요.'],
      rows: EN.slice(0, 30).map((e, i) => cxEnemy(e, (i < 10 ? 1 : i < 21 ? 2 : 3) + '막' + (e.el ? ' 엘리트' : (i === 9 || i === 20) ? ' 졸개' : ''))) },
    { h: '보스', p: ['막마다 보스 하나(1·2막은 둘 중 하나), 마지막은 「심연의 군주」예요. 기믹을 알고 싸우세요!'],
      rows: [[30, '1막'], [31, '1막'], [32, '도깨비 왕 졸개'], [33, '2막'], [34, '2막'], [35, '3막 최종'], [36, '3막 2단계']].map(([i, t]) => cxEnemy(EN[i], t)) },
    { h: '사건', p: ['지도의 ❓ 칸에서 만나요. 사건은 각자 골라요.'], rows: EVT.map((e) => ({ icon: e.ic, name: e.n, desc: e.t + ' 고르기: ' + e.o.join(' / ') })) },
    { h: '지도 칸', rows: Object.keys(NODE).map((k) => ({ icon: NODE[k].ic, name: NODE[k].n, desc: { F: '보통 적과 싸워요. 골드 + 카드 보상.', E: '센 적. 이기면 유물도 줘요.', R: '체력 30% 회복 또는 카드 1장 빼기.', S: '카드·유물·카드 빼기를 골드로 사요.', '?': '사건 — 운에 맡기거나 지나가요.', T: '유물 하나를 얻어요.', B: '막의 보스. 이기면 체력이 절반쯤 회복돼요.' }[k] })) },
  ];

  L.register({
    id: 'raid', name: '보스 레이드 협동', tag: '협동 덱빌딩 로그라이크', cat: '카드', coop: true, fixedOrder: true,
    blurb: '1~4명이 각자 직업(전사·마법사·치유사·궁수 등)을 골라 층을 올라가요. 층마다 스킬 카드를 골라 성장하고, 마지막 층의 큰 보스를 함께 쓰러뜨리는 턴제 협동 로그라이크.',
    tint: '#5a2232',
    icon: '<path d="M28 8l16 6v13c0 11-7 18-16 22-9-4-16-11-16-22V14z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M28 17v20M22 31h12" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M18 4l4 4 6-5 6 5 4-4v6H18z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 3, hidden: false, aiDelay: 700,
    options: [
      { id: 'len', label: '길이', choices: [{ v: 4, label: '짧게 (막마다 4층·약 15분)' }, { v: 6, label: '보통 (6층·약 25분)' }], def: 6 },
      { id: 'diff', label: '던전 난이도', choices: [{ v: 0, label: '쉬움' }, { v: 1, label: '보통' }, { v: 2, label: '어려움' }], def: 1 },
    ],
    quick: [
      '모두 한 팀! 각자 직업을 골라 3막의 층을 올라가 마지막 보스 「심연의 군주」를 쓰러뜨려요.',
      '전투는 모두 동시에: 에너지 ⚡3으로 카드를 내고 「턴 종료」. 적 머리 위 말풍선이 다음 행동이에요.',
      '이기면 카드 보상으로 덱이 강해져요. 도발·방어·회복으로 서로 지켜 주세요!',
    ],
    rules: [
      { h: '목표', p: [
        '모두 한 편이에요. 1막·2막·3막을 올라가 막마다 보스를, 마지막에 「심연의 군주」를 쓰러뜨리면 모두 승리!',
        '전투에서 영웅이 모두 쓰러지면 패배예요. 한 명이라도 서 있으면 전투가 끝난 뒤 쓰러진 영웅도 일어나요(체력 20%).',
      ] },
      { h: '직업', p: [
        '🛡️전사(도발·방어) 🔮마법사(광역·기절) ✨치유사(회복·부활) 🏹궁수(취약·큰 한 방)로 시작해요.',
        '🗡️도적(독)은 1막 보스, 🎻음유시인(힘·에너지 주기)은 2막 보스, 🌿정령술사는 레이드 성공 때 열려요(이 기기에 저장).',
        '혼자서도 할 수 있어요. 자리에 AI 동료를 넣으면 함께 싸워요(쉬움·보통·어려움, 자리마다 골라요).',
      ] },
      { h: '지도', p: [
        '막마다 갈림길 지도가 새로 만들어져요. 지금 칸에서 바로 위 줄의 옆 칸까지 갈 수 있어요.',
        '⚔️전투 ☠️엘리트(세지만 유물) 🔥휴식(회복 또는 카드 빼기) 🛒상점 ❓사건 🎁보물(유물) 👑보스.',
        '여럿이면 투표해서 표가 많은 칸으로 가요(같으면 무작위). AI 동료는 사람이 고른 길을 따라와요.',
      ] },
      { h: '전투 — 차례에 할 일', p: [
        '판마다 영웅은 에너지 3과 카드 5장을 받아요. 모두가 동시에 카드를 내요(순서 상관없음).',
        '카드를 누르고 → 적(빨간 테두리)이나 아군(초록 테두리)을 누르면 사용. 대상이 없는 카드는 한 번 더 누르면 사용.',
        '다 했으면 「턴 종료」. 모두 끝내면 적이 행동하고, 남은 카드는 버려져요. 다음 판에 새로 5장.',
        '방어 🛡는 그 판의 피해를 먼저 막고 다음 판에 사라져요.',
      ] },
      { h: '적의 의도', p: [
        '적 머리 위 말풍선이 다음 행동이에요: ⚔공격(숫자 = 피해, 색 점 = 노리는 영웅) 💥모두에게 공격 🛡방어 💪힘 🌀약화·취약 💚회복 🩸상처 카드 📯소환.',
        '영웅 칸의 ⚠숫자는 「이대로면 받을 피해」예요. ✓막음이면 안전!',
        '적을 누르면 다음 행동을 글로 알려 줘요. 보스는 각자 특별한 기믹이 있어요.',
      ] },
      { h: '함께 싸우는 법 (예시)', p: [
        '예시: 보스가 치유사에게 ⚔18을 노려요 → 전사가 「도발 외침」을 쓰면 그 공격이 전사에게 가요. 전사는 방어로 버텨요.',
        '궁수가 「표적 지정」으로 취약(받는 피해 1.5배)을 걸고 → 마법사가 「운석」 24 → 36 피해!',
        '치유사의 「보호의 기도」로 전사 방어를 올리고 → 전사의 「방패 치기」(피해 = 내 방어)로 크게 때려요.',
      ] },
      { h: '용어', p: [
        '약화: 주는 피해 25% 줄어요. 취약: 받는 피해 50% 늘어요. 숫자는 남은 판 수.',
        '독: 적 차례마다 그만큼 피해(방어 무시), 1씩 줄어요. 기절: 다음 행동 1번 취소. 가시: 나를 때린 적이 피해를 받아요.',
        '힘: 내 공격 카드 피해 +1씩(그 전투 동안). 1번만: 이번 전투에서 쓰면 사라져요. 상처: 못 쓰는 저주 카드.',
      ] },
      { h: '보상·상점', p: [
        '전투에서 이기면 골드(파티 공용)와 각자 카드 1장(3장 중, 건너뛰기 가능). 엘리트·보스는 유물(파티 모두에게 효과)도 줘요.',
        '상점: 카드 · 유물 · 카드 빼기. 사건은 각자 고르기. 막 보스를 이기면 체력이 절반쯤 회복돼요.',
        '덱이 무거우면 좋은 카드가 잘 안 나와요. 약한 기본 카드는 휴식·상점에서 빼 주세요.',
      ] },
      { h: '옵션', p: [
        '길이: 짧게(막마다 4층, 약 15분) / 보통(6층, 약 25분). 던전 난이도: 적 체력·공격이 달라져요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(쉬움은 실수가 잦고, 어려움은 팀을 잘 지켜요).',
      ] },
    ],
    tutorial: [
      { text: '보스 레이드 협동! 1~4명이 한 팀이 되어 3막을 올라가 마지막 보스를 쓰러뜨려요. 먼저 각자 직업을 골라요.' },
      { text: '지도에서는 반짝이는 칸을 눌러 다음 길을 골라요. ⚔️전투 ☠️엘리트 🔥휴식 🛒상점 ❓사건 🎁보물 · 맨 위는 👑보스.' },
      { text: '전투: 적 머리 위 말풍선이 다음 행동이에요. ⚔12 = 12 피해, 옆 색 점 = 노리는 영웅. 적을 누르면 설명이 나와요.', sel: '.rd-ens' },
      { text: '카드를 누르고 → 대상(적·아군)을 누르면 사용해요. 카드 왼쪽 위 숫자가 에너지 ⚡예요.', sel: '.rd-hand' },
      { text: '다 했으면 「턴 종료」. 모두 끝내면 적이 움직여요. 영웅 칸의 ⚠는 받을 피해 — 도발·방어·회복으로 서로 지켜 주세요!', sel: '.rd-end' },
    ],
    codex: CODEX,
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { C, EN, RL, CL, incoming, V },
  });
})();
