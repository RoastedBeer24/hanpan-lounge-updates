/* 기찻길 노선 잇기 — 우리만의 한국 지도 위에서 기차 카드를 모아 도시 사이 노선을 깔고, 목적지 표를 이어 점수를 겨루는 게임.
   지도·이름·카드 그림·점수표는 모두 이 게임 자체 디자인이에요.
   차례에 셋 중 하나: ① 기차 카드 2장 뽑기(공개 5장 또는 더미; 공개 만능 카드는 1장으로 끝) ② 같은 색 카드로 노선 깔기 ③ 목적지 표 뽑기(1장 이상 남김).
   상태(작게): h 손패[색 7칸 개수], up 공개 카드(문자 '0'~'6', 6=만능), dk 더미, dc 버린 카드 개수[7], ro 노선 주인('.' 또는 자리 숫자),
   tk 자리별 목적지 표(문자), td 표 더미, off 고르는 중인 표, ph 0 처음 표 고르기 / 1 차례 시작 / 2 두 번째 카드 / 3 표 고르기 / 9 끝,
   t 차례, tr 남은 기차, lr 마지막 바퀴 남은 차례(-1 없음), ps 연속 넘김, fs 최종 점수, last 최근 일(애니메이션용). */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- map ---------- */
  // [이름, x, y, 이름표 방향(n/s/e/w/ne/nw/se/sw)]  — 지도 좌표 0..104 × 0..136 (남한을 단순하게 그린 우리 지도)
  const CITY = [
    ['서울', 26, 30, 'n'], ['인천', 16, 33, 'w'], ['수원', 27, 40, 'w'], ['춘천', 44, 21, 'n'], ['속초', 64, 11, 'w'], ['강릉', 72, 24, 'e'], ['원주', 49, 37, 'e'], ['삼척', 79, 34, 'e'],
    ['서산', 12, 52, 'w'], ['천안', 29, 51, 'w'], ['청주', 39, 56, 'n'], ['대전', 35, 65, 'w'], ['안동', 67, 57, 'n'], ['울진', 84, 47, 'e'], ['포항', 84, 72, 'e'], ['김천', 53, 70, 'n'],
    ['대구', 65, 78, 'w'], ['울산', 83, 87, 'e'], ['부산', 76, 97, 'se'], ['창원', 66, 95, 's'], ['진주', 52, 97, 's'], ['군산', 18, 75, 'w'], ['전주', 30, 79, 'e'], ['남원', 36, 90, 'w'],
    ['광주', 22, 98, 'w'], ['목포', 11, 108, 'w'], ['여수', 42, 110, 's'], ['제주', 22, 128, 's'], ['울릉', 96, 30, 's'],
  ];
  const NC = CITY.length;
  const cix = (n) => CITY.findIndex((c) => c[0] === n);
  // "도시 도시 칸수 색 [f배에필요한만능] [b휨]" — 색: 0빨강 1노랑 2초록 3파랑 4보라 5검정 6회색(아무 색)
  const RSRC = '서울 인천 1 6;서울 인천 1 6;서울 수원 1 1;서울 수원 1 2;인천 서산 3 3;서울 춘천 3 4;서울 춘천 3 5;서울 원주 3 1;춘천 원주 2 6;춘천 속초 3 0;' +
    '춘천 강릉 4 2;속초 강릉 2 6;원주 강릉 4 4;원주 강릉 4 3;강릉 삼척 2 5;삼척 울진 2 4;울진 포항 3 1;울진 안동 3 6;원주 안동 4 2;원주 청주 3 6;' +
    '수원 천안 2 0;수원 천안 2 5;서산 천안 2 1;천안 청주 1 6;천안 대전 2 3;천안 대전 2 2;청주 대전 1 4;서산 군산 3 5;대전 전주 2 1;대전 전주 2 0;' +
    '군산 전주 2 6;대전 김천 3 5;김천 대구 2 3;김천 대구 2 4;김천 안동 3 1;안동 대구 3 4;안동 포항 3 3;대구 포항 3 2;포항 울산 2 6;대구 부산 3 5;' +
    '대구 부산 3 1;울산 부산 2 0;대구 창원 2 4;창원 부산 1 6;창원 진주 2 2;진주 여수 2 1;진주 남원 2 6;김천 진주 4 6;전주 남원 2 4;군산 광주 3 6;' +
    '전주 광주 3 2;전주 광주 3 0;남원 광주 2 1;남원 여수 3 3;광주 목포 2 5;광주 여수 3 0;목포 여수 4 6 b4;목포 제주 3 6 f1;여수 제주 4 6 f1;부산 제주 6 6 f2 b-9;' +
    '서산 목포 6 3 b5;강릉 울릉 3 6 f1 b-3;포항 울릉 4 6 f1 b4;청주 김천 3 0;청주 안동 4 5';
  const ROUTES = RSRC.split(';').map((s) => {
    const p = s.split(' ');
    const r = { a: cix(p[0]), b: cix(p[1]), n: +p[2], c: +p[3], f: 0, bd: 0, tw: -1 };
    for (const q of p.slice(4)) { if (q[0] === 'f') r.f = +q.slice(1); if (q[0] === 'b') r.bd = +q.slice(1); }
    return r;
  });
  const NR = ROUTES.length;
  ROUTES.forEach((r, i) => { for (let j = 0; j < NR; j++) if (j !== i && ROUTES[j].a === r.a && ROUTES[j].b === r.b) r.tw = j; });
  const ADJ = Array.from({ length: NC }, () => []);
  ROUTES.forEach((r, i) => { ADJ[r.a].push(i); ADJ[r.b].push(i); });
  const other = (r, v) => (ROUTES[r].a === v ? ROUTES[r].b : ROUTES[r].a);

  const PTS = [0, 1, 2, 4, 6, 9, 12];   // 노선 칸수별 점수 (우리 점수표)
  const BONUS = 10;                      // 가장 긴 기찻길 보너스
  const TRAINS = 30;                     // 2~3명일 때 사람마다 기차 수
  const trainsFor = (n) => (n >= 5 ? 24 : n === 4 ? 27 : TRAINS); // 인원이 많으면 지도가 붐비지 않게 조금 줄여요
  const NCOL = 12, NWILD = 14;           // 색마다 12장 × 6색 + 만능 14장 = 86장
  const COLN = ['빨강', '노랑', '초록', '파랑', '보라', '검정', '만능'];
  const COLH = ['#d4473a', '#e5b52c', '#3d9a55', '#3a72c8', '#8d55c0', '#2a2631', '#b9b2a3'];
  const SYM = ['●', '▲', '■', '◆', '★', '✚', '✦'];
  const W = 6;
  const TKA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  const tkI = (ch) => TKA.indexOf(ch);

  /* 목적지 표: 점수 = 지도에서 가장 짧게 잇는 칸수 */
  const TSRC = '서울 부산;인천 부산;서울 목포;서울 제주;인천 강릉;서울 포항;춘천 대구;속초 부산;강릉 광주;서산 강릉;인천 대전;수원 전주;대전 부산;대전 목포;청주 포항;천안 여수;' +
    '군산 대구;전주 울산;광주 부산;목포 창원;여수 울산;남원 포항;안동 광주;김천 목포;진주 서울;제주 대구;울릉 서울;울릉 부산;제주 강릉;속초 목포;원주 여수;삼척 진주;서산 울산;춘천 전주';
  function sp(costOf, src) { // Dijkstra over the small map → {d, pr(route used to arrive)}
    const d = new Array(NC).fill(Infinity), pr = new Array(NC).fill(-1), done = new Array(NC).fill(false);
    d[src] = 0;
    for (;;) {
      let u = -1, best = Infinity;
      for (let i = 0; i < NC; i++) if (!done[i] && d[i] < best) { best = d[i]; u = i; }
      if (u < 0) break;
      done[u] = true;
      for (const r of ADJ[u]) { const c = costOf(r); if (c === Infinity) continue; const v = other(r, u); if (d[u] + c < d[v]) { d[v] = d[u] + c; pr[v] = r; } }
    }
    return { d, pr };
  }
  const TICKETS = TSRC.split(';').map((s) => { const p = s.split(' '); const a = cix(p[0]), b = cix(p[1]); return { a, b, p: sp((r) => ROUTES[r].n, a).d[b] }; });

  /* ---------- helpers ---------- */
  const shuffleStr = (str) => U.shuffle(str.split('')).join('');
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  const sc = (seat) => String(seat);
  function drawOne(s) {
    if (!s.dk.length) {
      let pool = '';
      for (let c = 0; c < 7; c++) pool += String(c).repeat(s.dc[c]);
      if (!pool) return null;
      s.dk = shuffleStr(pool); s.dc = [0, 0, 0, 0, 0, 0, 0];
    }
    const ch = s.dk[0]; s.dk = s.dk.slice(1);
    return ch;
  }
  const cardsLeft = (s) => s.dk.length + sum(s.dc);
  const wildsUp = (s) => s.up.split('').filter((c) => c === '6').length;
  function fillUp(s) { // refill to 5; 3 or more 만능 face up → throw all 5 away and deal again
    let reset = false;
    for (let guard = 0; guard < 8; guard++) {
      while (s.up.length < 5) { const c = drawOne(s); if (c == null) break; s.up += c; }
      if (wildsUp(s) < 3) break;
      // only reset if there are enough other cards to make a difference
      const nonWildLeft = s.dk.split('').filter((c) => c !== '6').length + sum(s.dc.slice(0, 6));
      if (nonWildLeft < 3) break;
      for (const c of s.up) s.dc[+c]++;
      s.up = ''; reset = true;
    }
    return reset;
  }
  function twinBlocked(s, seat, r) {
    const tw = ROUTES[r].tw;
    if (tw < 0 || s.ro[tw] === '.') return false;
    return s.n <= 3 || s.ro[tw] === sc(seat);
  }
  /* payment options for a route: [{c, k: colored cards, w: wilds}] — c 6 = 만능만 */
  function payOpts(hand, r) {
    const R = ROUTES[r], out = [];
    const cols = R.c === 6 ? [0, 1, 2, 3, 4, 5] : [R.c];
    for (const c of cols) {
      const k = Math.min(hand[c], R.n - R.f);
      if (k <= 0) continue;
      const w = R.n - k;
      if (hand[W] >= w) out.push({ c, k, w });
    }
    if (hand[W] >= R.n) out.push({ c: W, k: 0, w: R.n });
    out.sort((x, y) => x.w - y.w || y.k - x.k);
    return out;
  }
  function canClaim(s, seat, r) {
    return s.ro[r] === '.' && s.tr[seat] >= ROUTES[r].n && !twinBlocked(s, seat, r);
  }
  function claimable(s, seat) {
    const out = [];
    for (let r = 0; r < NR; r++) if (canClaim(s, seat, r) && payOpts(s.h[seat], r).length) out.push(r);
    return out;
  }
  const canDrawDeck = (s) => cardsLeft(s) > 0;
  const canDrawSecond = (s) => canDrawDeck(s) || s.up.split('').some((c) => c !== '6');
  const canDrawFirst = (s) => canDrawDeck(s) || s.up.length > 0;
  function comp(s, seat) { // union-find components of a seat's network
    const p = Array.from({ length: NC }, (_, i) => i);
    const f = (x) => (p[x] === x ? x : (p[x] = f(p[x])));
    for (let r = 0; r < NR; r++) if (s.ro[r] === sc(seat)) p[f(ROUTES[r].a)] = f(ROUTES[r].b);
    return f;
  }
  function ticketDone(s, seat, ti, f) { f = f || comp(s, seat); const T = TICKETS[ti]; return f(T.a) === f(T.b); }
  function longestTrail(s, seat) {
    const mine = []; for (let r = 0; r < NR; r++) if (s.ro[r] === sc(seat)) mine.push(r);
    if (!mine.length) return 0;
    const used = new Uint8Array(NR);
    let best = 0, steps = 0;
    function dfs(v, len) {
      if (len > best) best = len;
      if (++steps > 200000) return;
      for (const r of ADJ[v]) if (!used[r] && s.ro[r] === sc(seat)) { used[r] = 1; dfs(other(r, v), len + ROUTES[r].n); used[r] = 0; }
    }
    const nodes = new Set(); mine.forEach((r) => { nodes.add(ROUTES[r].a); nodes.add(ROUTES[r].b); });
    nodes.forEach((v) => dfs(v, 0));
    return best;
  }
  function routePts(s, seat) { let p = 0; for (let r = 0; r < NR; r++) if (s.ro[r] === sc(seat)) p += PTS[ROUTES[r].n]; return p; }
  /* trains still needed to finish a ticket (0 = done, Infinity = blocked) */
  function needFor(s, seat, ti) {
    const T = TICKETS[ti];
    return sp((r) => (s.ro[r] === sc(seat) ? 0 : s.ro[r] === '.' && !twinBlocked(s, seat, r) ? ROUTES[r].n : Infinity), T.a).d[T.b];
  }

  /* ---------- core logic ---------- */
  function init(players) {
    const n = players.length;
    let deck = '';
    for (let c = 0; c < 6; c++) deck += String(c).repeat(NCOL);
    deck += '6'.repeat(NWILD);
    const s = {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), tr: players.map(() => trainsFor(n)), h: players.map(() => [0, 0, 0, 0, 0, 0, 0]), up: '', dk: shuffleStr(deck), dc: [0, 0, 0, 0, 0, 0, 0],
      ro: '.'.repeat(NR), tk: players.map(() => ''), td: shuffleStr(TKA.slice(0, TICKETS.length)), off: '', ph: 0, t: 0, lr: -1, ps: 0,
      sq: 0, last: null, fs: null, g: Math.floor(Math.random() * 1e6),
    };
    for (let i = 0; i < n; i++) for (let k = 0; k < 4; k++) s.h[i][+drawOne(s)]++;
    fillUp(s);
    s.off = s.td.slice(0, 3); s.td = s.td.slice(3);
    return s;
  }
  function actor(s) { return s.ph === 9 ? null : s.t; }
  function finish(s) {
    s.ph = 9; s.off = '';
    const lg = []; for (let i = 0; i < s.n; i++) lg.push(longestTrail(s, i));
    const top = Math.max.apply(null, lg);
    s.fs = [];
    for (let i = 0; i < s.n; i++) {
      const f = comp(s, i);
      let plus = 0, minus = 0, done = 0;
      for (const ch of s.tk[i]) { const ti = tkI(ch); if (ticketDone(s, i, ti, f)) { plus += TICKETS[ti].p; done++; } else minus += TICKETS[ti].p; }
      const rp = routePts(s, i), bonus = top > 0 && lg[i] === top ? BONUS : 0;
      s.fs.push([rp, plus, minus, bonus, rp + plus - minus + bonus, done, lg[i]]);
    }
  }
  function endTurn(s, seat) {
    s.off = '';
    if (s.lr >= 0) { s.lr--; if (s.lr <= 0) { finish(s); return; } }
    else if (s.tr[seat] <= 2) s.lr = s.n;
    s.t = (s.t + 1) % s.n; s.ph = 1;
  }
  function apply(s, seat, a) {
    if (!a || s.ph === 9 || seat !== s.t) throw new Error('not your turn');
    const H = s.h[seat];
    s.sq++;
    if (a.t === 'keep') {
      if (s.ph !== 0 && s.ph !== 3) throw new Error('no tickets to keep');
      const m = a.m | 0, kept = [], back = [];
      for (let i = 0; i < s.off.length; i++) ((m >> i) & 1 ? kept : back).push(s.off[i]);
      const need = Math.min(s.ph === 0 ? 2 : 1, s.off.length);
      if (kept.length < need) throw new Error('keep more');
      s.tk[seat] += kept.join(''); s.td += back.join('');
      s.last = { id: s.sq, s: seat, k: 't', n: kept.length, m: s.off.length };
      s.ps = 0;
      if (s.ph === 0) {
        s.off = '';
        if (seat + 1 < s.n) { s.t = seat + 1; s.off = s.td.slice(0, 3); s.td = s.td.slice(3); }
        else { s.t = 0; s.ph = 1; }
      } else endTurn(s, seat);
      return s;
    }
    if (a.t === 'up' || a.t === 'dk') {
      if (s.ph !== 1 && s.ph !== 2) throw new Error('cannot draw now');
      let c, i = -1;
      if (a.t === 'up') {
        i = a.i | 0;
        if (i < 0 || i >= s.up.length) throw new Error('no card');
        c = s.up[i];
        if (c === '6' && s.ph === 2) throw new Error('wild as second card');
        s.up = s.up.slice(0, i) + s.up.slice(i + 1);
        const nc = drawOne(s);
        if (nc != null) s.up = s.up.slice(0, i) + nc + s.up.slice(i);
      } else {
        c = drawOne(s);
        if (c == null) throw new Error('deck empty');
      }
      H[+c]++;
      const reset = fillUp(s);
      s.last = { id: s.sq, s: seat, k: a.t === 'up' ? 'u' : 'd', i, c: +c, x: reset ? 1 : 0, d: s.ph };
      s.ps = 0;
      if (s.ph === 1 && !(a.t === 'up' && c === '6') && canDrawSecond(s)) s.ph = 2;
      else endTurn(s, seat);
      return s;
    }
    if (s.ph !== 1) throw new Error('finish drawing first');
    if (a.t === 'cl') {
      const r = a.r | 0;
      if (r < 0 || r >= NR || !canClaim(s, seat, r)) throw new Error('cannot claim');
      const o = payOpts(H, r).find((x) => x.c === (a.c | 0));
      if (!o) throw new Error('cannot pay');
      if (o.c !== W) { H[o.c] -= o.k; s.dc[o.c] += o.k; }
      H[W] -= o.w; s.dc[W] += o.w;
      s.ro = s.ro.slice(0, r) + sc(seat) + s.ro.slice(r + 1);
      s.tr[seat] -= ROUTES[r].n;
      s.last = { id: s.sq, s: seat, k: 'r', r, c: o.c, w: o.w };
      s.ps = 0;
      endTurn(s, seat);
      return s;
    }
    if (a.t === 'tk') {
      if (!s.td.length) throw new Error('no tickets');
      s.off = s.td.slice(0, 3); s.td = s.td.slice(3); s.ph = 3;
      s.last = { id: s.sq, s: seat, k: 'o', m: s.off.length };
      s.ps = 0;
      return s;
    }
    if (a.t === 'pass') {
      if (canDrawFirst(s) || s.td.length || claimable(s, seat).length) throw new Error('you can still play');
      s.last = { id: s.sq, s: seat, k: 'p' };
      s.ps++;
      if (s.ps >= s.n) { finish(s); return s; }
      endTurn(s, seat);
      return s;
    }
    throw new Error('bad action');
  }
  function result(s) {
    if (!s.fs) return null;
    const tot = s.fs.map((f) => f[4]);
    let best = -1e9; tot.forEach((t) => { if (t > best) best = t; });
    let w = []; tot.forEach((t, i) => { if (t === best) w.push(i); });
    if (w.length > 1) { const md = Math.max.apply(null, w.map((i) => s.fs[i][5])); w = w.filter((i) => s.fs[i][5] === md); }
    if (w.length > 1) { const ml = Math.max.apply(null, w.map((i) => s.fs[i][6])); w = w.filter((i) => s.fs[i][6] === ml); }
    const lines = s.fs.map((f, i) => ((s.nm && s.nm[i]) || '#' + (i + 1)) + ' ' + f[4] + '점 = 노선 ' + f[0] + ' · 목적지 +' + f[1] + (f[2] ? ' −' + f[2] : '') + (f[3] ? ' · 최장 +' + f[3] : ''));
    return { winners: w, text: lines.join('\n'), title: null };
  }

  /* ---------- AI ---------- */
  /* 난이도별 성향: 1 쉬움(욕심·건망증) · 2 보통(목적지 최단 경로 계획) · 3 어려움(+카드 관리·길목 막기·막판 계산) */
  const K = {
    1: { fer: 0.4, margin: 6, coef: 0.6, feas: 0, risk: 0, block: 0, bv: 99, dump: 0, tkTr: 99, tkOpp: 99, pay: 0, perm: 0 },
    2: { fer: 0.4, margin: 6, coef: 0.6, feas: 0, crowd: 1, risk: 0, block: 0, bv: 99, dump: 0, tkTr: 12, tkOpp: 6, pay: 0, perm: 0 },
    3: { fer: 0.6, margin: 8, coef: 0.6, feas: 1, crowd: 1.5, risk: 1, block: 0, bv: 6, inf: 3, bth: 3, burn: 2, dump: 1, tkTr: 12, tkOpp: 6, pay: 1, perm: 1 },
  };

  function plan(s, seat, tks, lv) { // greedy Steiner-ish: connect tickets one by one, reusing planned track
    const k = K[lv] || K[2];
    const planned = new Set();
    const me = sc(seat);
    const costOf = (r) => {
      if (s.ro[r] === me || (planned.has(r) && !k.indep)) return 0;
      if (s.ro[r] !== '.' || twinBlocked(s, seat, r)) return Infinity;
      const R = ROUTES[r];
      return R.n + R.f * k.fer - (k.lp || 0) * (PTS[R.n] - R.n);
    };
    const run = (list) => {
      planned.clear();
      let bad = 0, badPts = 0;
      for (const ti of list) {
        const T = TICKETS[ti];
        const res = sp(costOf, T.a);
        if (res.d[T.b] === Infinity) { bad++; badPts += T.p; continue; }
        let v = T.b;
        while (v !== T.a) { const r = res.pr[v]; if (s.ro[r] === '.') planned.add(r); v = other(r, v); }
      }
      const routes = [...planned];
      return { routes, cost: routes.reduce((x, r) => x + ROUTES[r].n, 0), bad, badPts };
    };
    const list = tks.slice().sort((x, y) => TICKETS[y].p - TICKETS[x].p);
    let best = run(list);
    if (k.perm && list.length > 1 && list.length <= 5) {
      // 어려움: 표를 잇는 순서를 바꿔 보며 가장 적게 드는 길을 찾기
      const perms = (a) => (a.length <= 1 ? [a] : a.flatMap((x, i) => perms(a.slice(0, i).concat(a.slice(i + 1))).map((p) => [x].concat(p))));
      for (const p of perms(list)) { const q = run(p); if (q.bad < best.bad || (q.bad === best.bad && q.cost < best.cost)) best = q; }
    }
    return best;
  }
  const myTickets = (s, seat) => s.tk[seat].split('').map(tkI);
  /* rough number of my turns left before someone runs out of trains */
  function turnsLeft(s) { if (s.lr >= 0) return 1; return Math.max(1, Math.min.apply(null, s.tr) / 1.15); }
  function turnsNeeded(s, seat, P) { const hand = sum(s.h[seat]); return P.routes.length + Math.max(0, P.cost - hand) / 2; }
  function chooseKeep(s, seat, lv) {
    const off = s.off.split('').map(tkI);
    const need = Math.min(s.ph === 0 ? 2 : 1, off.length);
    const cur = myTickets(s, seat);
    if (lv <= 1) { // 쉬움: 아무거나 최소한만 (가끔 욕심)
      let m = 0, n = 0; const order = U.shuffle(off.map((_, i) => i));
      const take = Math.random() < 0.25 ? off.length : need;
      for (const i of order) { if (n >= take) break; m |= 1 << i; n++; }
      return { t: 'keep', m };
    }
    const k = K[lv] || K[2];
    const open = cur.filter((t) => !ticketDone(s, seat, t));
    const base = plan(s, seat, open, lv);
    const budget = s.tr[seat] - k.margin - (s.n - 2) * (k.crowd || 0);
    const tl = turnsLeft(s);
    let best = null, bestSc = -1e9;
    for (let m = 1; m < 1 << off.length; m++) {
      const pick = off.filter((_, i) => (m >> i) & 1);
      if (pick.length < need) continue;
      const P = plan(s, seat, open.concat(pick), lv);
      const pts = sum(pick.map((t) => TICKETS[t].p));
      const extra = P.cost - base.cost;
      let sco = pts - k.coef * extra - 2 * (P.badPts - base.badPts) - 5 * Math.max(0, P.cost - budget);
      if (k.feas && s.ph === 3) { const over = turnsNeeded(s, seat, P) - tl * 0.8; if (over > 0) sco -= Math.min(pts * 1.6, over * 3); }
      if (sco > bestSc) { bestSc = sco; best = m; }
    }
    return { t: 'keep', m: best };
  }
  function colorNeeds(s, seat, routes) {
    const H = s.h[seat], need = [0, 0, 0, 0, 0, 0, 0];
    let gray = 0;
    for (const r of routes) { const R = ROUTES[r]; if (R.c === 6) gray += R.n - R.f; else need[R.c] += R.n - R.f; need[W] += R.f; }
    const def = need.map((x, c) => Math.max(0, x - H[c]));
    // gray tracks: best served by the colour with the most spare cards
    let gc = 0, spare = -1;
    for (let c = 0; c < 6; c++) { const sp2 = H[c] - need[c]; if (sp2 > spare) { spare = sp2; gc = c; } }
    if (gray > 0) def[gc] += Math.max(0, gray - Math.max(0, spare));
    return def;
  }
  function chooseDraw(s, seat, lv, routes) {
    const legal = [];
    for (let i = 0; i < s.up.length; i++) if (s.up[i] !== '6' || s.ph === 1) legal.push(i);
    const deckOk = canDrawDeck(s);
    const nw = legal.filter((i) => s.up[i] !== '6');
    if (lv <= 1) {
      if (deckOk && Math.random() < 0.5) return { t: 'dk' };
      const pool = nw.length && Math.random() < 0.85 ? nw : legal;
      if (pool.length) return { t: 'up', i: pool[(Math.random() * pool.length) | 0] };
      return deckOk ? { t: 'dk' } : null;
    }
    const k = K[lv] || K[2];
    if (k.blind && deckOk && Math.random() < k.blind) return { t: 'dk' };     // 보통: 가끔 공개 카드를 놓쳐요
    const def = colorNeeds(s, seat, routes);
    const totalDef = sum(def.slice(0, 6));
    let bi = -1, bs = 0;
    for (const i of legal) {
      const c = +s.up[i];
      let v = 0;
      if (c === W) { if (def[W] > 0) v = 2.6; else if (totalDef >= 5 && !deckOk) v = 1.6; }
      else if (def[c] > 0) v = 2 + Math.min(def[c], 4) * 0.1;
      if (v > bs) { bs = v; bi = i; }
    }
    if (bi >= 0 && bs >= 2) return { t: 'up', i: bi };
    if (deckOk) return { t: 'dk' };
    if (nw.length) { let q = nw[0]; for (const i of nw) if (s.h[seat][+s.up[i]] > s.h[seat][+s.up[q]]) q = i; return { t: 'up', i: q }; }
    if (legal.length) return { t: 'up', i: legal[0] };
    return null;
  }
  function bestPay(s, seat, r, lv, routes) {
    const opts = payOpts(s.h[seat], r);
    if (!(K[lv] || K[2]).pay || opts.length < 2) return opts[0];
    // 어려움: 다른 계획 노선에 필요한 색을 아끼고, 만능은 최대한 아낀다
    const need = [0, 0, 0, 0, 0, 0, 0];
    for (const q of routes) if (q !== r && ROUTES[q].c < 6) need[ROUTES[q].c] += ROUTES[q].n;
    let best = opts[0], bv = -1e9;
    for (const o of opts) {
      const left = o.c === W ? 99 : s.h[seat][o.c] - o.k;
      const v = -o.w * 3 - (o.c !== W && need[o.c] > 0 ? Math.max(0, need[o.c] - left) * 1.5 : 0);
      if (v > bv) { bv = v; best = o; }
    }
    return best;
  }
  const claimAct = (s, seat, r, lv, routes) => { const o = bestPay(s, seat, r, lv, routes); return { t: 'cl', r, c: o.c }; };
  /* 어려움: 남의 기찻길 모양만 보고(숨긴 표는 안 봐요) 노리는 목적지를 짐작해, 꼭 지나야 할 길목을 찾아요 */
  function findBlock(s, seat, aff, P, k) {
    const mine = new Set(s.tk[seat].split('').map(tkI));
    const affSet = new Set(aff);
    const spare = s.tr[seat] - P.cost;
    let best = -1, bv = 0;
    for (let i = 0; i < s.n; i++) {
      if (i === seat) continue;
      const me = sc(i);
      let owned = 0; for (let r = 0; r < NR; r++) if (s.ro[r] === me) owned++;
      if (owned < 2) continue;
      const cost = (skip) => (r) => (r === skip || (skip >= 0 && r === ROUTES[skip].tw) ? Infinity : s.ro[r] === me ? 0 : s.ro[r] === '.' && !twinBlocked(s, i, r) ? ROUTES[r].n : Infinity);
      const guesses = [];
      for (let t = 0; t < TICKETS.length; t++) {
        if (mine.has(t)) continue;
        const T = TICKETS[t];
        const res = sp(cost(-1), T.a), rem = res.d[T.b];
        if (rem === Infinity || rem === 0 || rem > s.tr[i]) continue;
        const prog = T.p - rem;
        if (prog >= 3) guesses.push({ t, rem, prog, pr: res.pr });
      }
      guesses.sort((x, y) => y.prog - x.prog);
      for (const g of guesses.slice(0, k.inf)) {
        const T = TICKETS[g.t];
        let v = T.b;
        while (v !== T.a) {
          const r = g.pr[v]; v = other(r, v);
          if (s.ro[r] !== '.' || !affSet.has(r) || ROUTES[r].n > 3 || ROUTES[r].n > spare - 2) continue;
          const alt = sp(cost(r), T.a).d[T.b];
          const val = (alt === Infinity ? 12 : alt - g.rem) * (g.prog / T.p);
          if (val > bv) { bv = val; best = r; }
        }
      }
    }
    return bv >= k.bth ? best : -1;
  }
  /* 어려움: 지금 내 기찻길로 거의 공짜로 이을 수 있는 표가 얼마나 될지(모르는 표 전체 기준) — 표를 더 뽑을지 판단 */
  function ticketOdds(s, seat, P) {
    const mine = new Set(s.tk[seat].split('').map(tkI));
    const zero = new Set(P.routes);
    const cost = (r) => (s.ro[r] === sc(seat) || zero.has(r) ? 0 : s.ro[r] === '.' && !twinBlocked(s, seat, r) ? ROUTES[r].n : Infinity);
    const spare = s.tr[seat] - P.cost;
    const cache = {};
    let good = 0, tot = 0, pts = 0;
    for (let t = 0; t < TICKETS.length; t++) {
      if (mine.has(t)) continue;
      const T = TICKETS[t];
      tot++;
      const d = (cache[T.a] = cache[T.a] || sp(cost, T.a).d)[T.b];
      if (d <= Math.min(3, spare - 2)) { good++; pts += T.p; }
    }
    return { p: tot ? good / tot : 0, avg: good ? pts / good : 0, spare };
  }
  function trailEnds(s, seat) { // cities at the dead ends of my track (where extending helps the longest train)
    const deg = new Array(NC).fill(0);
    for (let r = 0; r < NR; r++) if (s.ro[r] === sc(seat)) { deg[ROUTES[r].a]++; deg[ROUTES[r].b]++; }
    const out = new Set(); deg.forEach((d, i) => { if (d === 1) out.add(i); });
    return out;
  }
  function netNodes(s, seat) { const set = new Set(); for (let r = 0; r < NR; r++) if (s.ro[r] === sc(seat)) { set.add(ROUTES[r].a); set.add(ROUTES[r].b); } return set; }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 0 || s.ph === 3) return chooseKeep(s, seat, lv);
    const k = K[lv] || K[2];
    let tks = myTickets(s, seat).filter((t) => !ticketDone(s, seat, t));
    if (lv <= 1) tks = tks.filter(() => Math.random() < 0.7);           // 쉬움: 목적지를 자주 잊어요
    let P = plan(s, seat, tks, lv);
    if (k.feas && tks.length > 1 && turnsNeeded(s, seat, P) > turnsLeft(s) * 1.1) {
      // 어려움: 다 못 할 것 같으면 점수가 큰(또는 가까운) 표에 집중
      const ord = tks.slice().sort((x, y) => needFor(s, seat, x) - needFor(s, seat, y));
      while (ord.length > 1) { ord.pop(); P = plan(s, seat, ord, lv); if (turnsNeeded(s, seat, P) <= turnsLeft(s) * 1.1) break; }
    }
    if (s.ph === 2) return chooseDraw(s, seat, lv, P.routes) || { t: 'dk' };
    const aff = claimable(s, seat);
    const affSet = new Set(aff);
    const wantAff = P.routes.filter((r) => affSet.has(r));
    const ptsOf = (r) => PTS[ROUTES[r].n];
    const bestBy = (list, f) => { let b = list[0], bv = -1e9; for (const r of list) { const v = f(r); if (v > bv) { bv = v; b = r; } } return b; };
    const handN = sum(s.h[seat]);
    const minOpp = Math.min.apply(null, s.tr.filter((_, i) => i !== seat));

    // 마지막 바퀴: 지금 깔 수 있는 가장 좋은 노선
    if (s.lr >= 0 && aff.length) {
      const r = bestBy(aff, (q) => ptsOf(q) + (P.routes.includes(q) ? 3 : 0));
      return claimAct(s, seat, r, lv, P.routes);
    }
    if (lv <= 1) {
      if (wantAff.length && Math.random() < 0.8) return claimAct(s, seat, wantAff[(Math.random() * wantAff.length) | 0], lv, P.routes);
      if (aff.length && (Math.random() < 0.3 || handN >= 10)) return claimAct(s, seat, aff[(Math.random() * aff.length) | 0], lv, P.routes);
      if (!tks.length && !myTickets(s, seat).some((t) => !ticketDone(s, seat, t)) && s.td.length && s.tr[seat] > 12 && Math.random() < 0.3) return { t: 'tk' };
    } else {
      if (k.tev && s.td.length && s.lr < 0 && minOpp > 5) {
        const o = ticketOdds(s, seat, P);
        if (1 - Math.pow(1 - o.p, Math.min(3, s.td.length)) >= k.tev && o.spare >= 4 && (!P.routes.length || o.p >= 0.45)) return { t: 'tk' };
      }
      if (k.inf && s.n === 2 && aff.length && s.lr < 0) {   // 2명일 때만: 여럿이면 막기가 손해예요
        const b = findBlock(s, seat, aff, P, k);
        if (b >= 0 && (!wantAff.length || k.bfirst)) return claimAct(s, seat, b, lv, P.routes);
      }
      if (wantAff.length) {
        let r;
        if (k.risk) {
          const opp = []; for (let i = 0; i < s.n; i++) if (i !== seat) opp.push(netNodes(s, i));
          r = bestBy(wantAff, (q) => {
            const R = ROUTES[q];
            let risk = 0;
            if (R.tw < 0 || s.ro[R.tw] !== '.' || s.n <= 3) risk += 1;            // 대신할 나란한 노선이 없음
            for (const o of opp) if (o.has(R.a) || o.has(R.b)) risk += 0.7;        // 남이 근처에 있음
            return R.n + risk;
          });
        } else r = bestBy(wantAff, (q) => ROUTES[q].n);
        return claimAct(s, seat, r, lv, P.routes);
      }
      if (!P.routes.length) {
        const early = s.lr < 0 && minOpp > k.tkOpp;
        if (early && s.td.length && s.tr[seat] >= k.tkTr) return { t: 'tk' };
        if (k.burn) {
          // 어려움: 표를 다 이었으면 남은 기차를 긴 노선(점수 효율)과 가장 긴 기찻길에 쏟아요
          const ends = trailEnds(s, seat);
          const val = (q) => PTS[ROUTES[q].n] + (ends.has(ROUTES[q].a) || ends.has(ROUTES[q].b) ? k.burn : 0);
          if (aff.length) { const r = bestBy(aff, val); if (ROUTES[r].n >= 3 || !canDrawFirst(s) || handN >= 9 || s.tr[seat] <= 3 || s.tr[seat] <= (k.rush || 0)) return claimAct(s, seat, r, lv, P.routes); }
          const cand = []; for (let q = 0; q < NR; q++) if (canClaim(s, seat, q) && ROUTES[q].n >= 3) cand.push(q);
          cand.sort((x, y) => val(y) - val(x));
          if (cand.length && canDrawFirst(s)) { const d = chooseDraw(s, seat, lv, cand.slice(0, 2)); if (d) return d; }
        }
        if (aff.length) {
          const f = netNodes(s, seat);
          const r = bestBy(aff, (q) => ptsOf(q) + (k.risk && (f.has(ROUTES[q].a) || f.has(ROUTES[q].b)) ? 1.5 : 0));
          if (ROUTES[r].n >= 3 || !canDrawFirst(s) || handN >= 8) return claimAct(s, seat, r, lv, P.routes);
        }
      }
      if (aff.length && k.dump && minOpp <= 4 && turnsNeeded(s, seat, P) > turnsLeft(s)) {
        // 어려움: 끝이 코앞이면 계획보다 점수 챙기기
        return claimAct(s, seat, bestBy(aff, ptsOf), lv, P.routes);
      }
      if (aff.length && k.block && s.n <= k.block && s.tr[seat] > P.cost + 8 && (s.sq * 7 + seat) % 3 === 0) {
        // 어려움: 남의 기찻길 끝에 붙은, 돌아가기 힘든 짧은 길목 막기
        let blk = -1, bv = 0;
        for (const r of aff) {
          const R = ROUTES[r];
          if (R.n > 2 || (R.tw >= 0 && s.ro[R.tw] === '.' && s.n > 3)) continue;
          for (let i = 0; i < s.n; i++) {
            if (i === seat) continue;
            const o = netNodes(s, i);
            if (o.has(R.a) === o.has(R.b)) continue;
            const alt = sp((q) => (q === r || q === R.tw ? Infinity : s.ro[q] === sc(i) ? 0 : s.ro[q] === '.' ? ROUTES[q].n : Infinity), R.a).d[R.b];
            const v = alt - R.n;
            if (v >= k.bv && v > bv) { bv = v; blk = r; }
          }
        }
        if (blk >= 0) return claimAct(s, seat, blk, lv, P.routes);
      }
      if (handN >= 16 && aff.length) return claimAct(s, seat, bestBy(aff, ptsOf), lv, P.routes);
    }
    const d = canDrawFirst(s) ? chooseDraw(s, seat, lv, P.routes) : null;
    if (d) return d;
    if (aff.length) return claimAct(s, seat, bestBy(aff, ptsOf), lv, P.routes);
    if (s.td.length) return { t: 'tk' };
    return { t: 'pass' };
  }
  function aiDelayFor(s, seat, lv) {
    const b = s.ph === 2 ? 480 : s.ph === 0 || s.ph === 3 ? 900 : 760;
    return b + (lv <= 1 ? 220 : lv >= 3 ? -120 : 0);
  }

  /* ---------- view ---------- */
  const LAND = [[3, -14], [72, -14], [66, 8], [70, 17], [75, 26], [80, 34], [83, 41], [86, 49], [87, 58], [88, 66], [88.5, 74], [87, 82], [85, 89], [81, 96], [77, 101], [71, 99.5], [65, 101.5],
    [59, 100], [53, 102.5], [48, 104], [46, 108], [47, 114], [42, 113.5], [38, 109], [34, 106], [29, 108.5], [25, 105.5], [20, 110.5], [15, 113.5], [9, 111.5], [6, 105], [9, 98],
    [12, 91], [10, 84], [13, 77], [9, 69], [11, 62], [6, 58], [7, 51], [11, 46], [13, 41], [10, 37], [8, 31], [6, 24], [4, 12]];
  const ISLES = [[22, 128, 10.5, 4.8], [96, 30, 2.6, 2.2], [8, 117, 1.6, 1], [31, 116, 2, 1.1], [52, 107, 1.8, 1], [3, 97, 1.4, 1], [60, 104.5, 1.4, 0.9], [4, 44, 1.2, 0.8]];
  const MAPB = { x0: 0, y0: 3, x1: 104, y1: 135 };
  const CR = 2.3, CT = 2.3, GAP = 0.5;
  /* route geometry in map units: cars {x,y,a,l} + polyline for hit tests */
  const GEO = ROUTES.map((R, i) => {
    const A = CITY[R.a], B = CITY[R.b];
    const dx = B[1] - A[1], dy = B[2] - A[2], len = Math.hypot(dx, dy);
    const nx = -dy / len, ny = dx / len;
    const off = R.tw < 0 ? 0 : (i < R.tw ? -1.45 : 1.45);
    const p0 = [A[1] + nx * off, A[2] + ny * off], p2 = [B[1] + nx * off, B[2] + ny * off];
    const p1 = [(p0[0] + p2[0]) / 2 + nx * R.bd, (p0[1] + p2[1]) / 2 + ny * R.bd];
    const N = 40, pts = [], acc = [0];
    for (let k = 0; k <= N; k++) {
      const t = k / N, u = 1 - t;
      pts.push([u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]]);
      if (k) acc.push(acc[k - 1] + Math.hypot(pts[k][0] - pts[k - 1][0], pts[k][1] - pts[k - 1][1]));
    }
    const total = acc[N];
    const at = (d) => { let k = 1; while (k < N && acc[k] < d) k++; const f = (d - acc[k - 1]) / Math.max(1e-6, acc[k] - acc[k - 1]); const a = pts[k - 1], b = pts[k]; return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, Math.atan2(b[1] - a[1], b[0] - a[0])]; };
    const s0 = CR + 0.3, s1 = total - CR - 0.3, l = (s1 - s0 - GAP * (R.n - 1)) / R.n;
    const cars = [];
    for (let k = 0; k < R.n; k++) { const c = at(s0 + l / 2 + k * (l + GAP)); cars.push({ x: c[0], y: c[1], a: c[2], l }); }
    const poly = []; for (let k = 0; k <= 16; k++) { const c = at(s0 + (s1 - s0) * k / 16); poly.push([c[0], c[1]]); }
    const mid = at(total / 2);
    return { cars, poly, mx: mid[0], my: mid[1] };
  });
  const CSS = `
.rl-wrap{position:absolute;inset:0;display:flex;flex-direction:column;background:#17131f;-webkit-user-select:none;user-select:none}
.rl-pl{display:flex;gap:4px;padding:6px 8px 4px;flex:none}
.rl-p{flex:1 1 0;min-width:0;height:50px;border-radius:10px;background:#221c2e;border:1px solid var(--line);padding:3px 6px;display:flex;flex-direction:column;justify-content:center;gap:1px;overflow:hidden;transition:border-color .2s,box-shadow .2s}
.rl-p .nm{font-size:12px;font-weight:700;display:flex;align-items:center;gap:4px;white-space:nowrap;min-width:0;line-height:1.25}
.rl-p .nm .t{overflow:hidden;text-overflow:ellipsis;min-width:0}
.rl-p .nm .dot{flex:none;width:9px;height:9px}
.rl-p .l{font:600 10.5px var(--f-mono),monospace;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.3}
.rl-p .l b{color:var(--ink);font-weight:700}
.rl-pl.tight .rl-p{padding:3px 4px}.rl-pl.tight .rl-p .l{font-size:10px;letter-spacing:-.2px}
.rl-p.cur{border-color:var(--c);box-shadow:inset 0 0 0 1px var(--c),0 0 12px -4px var(--c)}
.rl-p .l b.low{color:var(--coral)}
.rl-map{position:relative;flex:1 1 auto;min-height:110px;overflow:hidden;cursor:grab;touch-action:none}
.rl-map.hov{cursor:pointer}
.rl-zoom{position:absolute;right:4px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:6px;z-index:2}
.rl-zoom button,.rl-tkb{appearance:none;border:1px solid var(--line);background:rgba(23,19,31,.82);color:var(--ink);border-radius:12px;cursor:pointer;touch-action:manipulation}
.rl-zoom button{width:44px;height:44px;font:700 20px var(--f-mono),monospace;display:grid;place-items:center;padding:0}
.rl-zoom button:active,.rl-tkb:active{transform:scale(.95)}
.rl-tkb{position:absolute;left:6px;top:6px;z-index:2;min-height:44px;padding:4px 10px 4px 8px;display:flex;align-items:center;gap:7px;font-weight:700;font-size:13px}
.rl-tkb .ic{width:22px;height:16px;border-radius:3px;background:#efe3c4;position:relative;flex:none;box-shadow:inset 0 0 0 1.5px #b9945a}
.rl-tkb .ic::after{content:'';position:absolute;left:4px;right:4px;top:7px;height:2px;background:#b9945a}
.rl-tkb .ct{font:700 12px var(--f-mono),monospace;color:var(--brass)}
.rl-cap{flex:none;min-height:34px;padding:2px 10px;display:flex;flex-direction:column;justify-content:center;font-size:12.5px;line-height:1.35;text-align:center}
.rl-cap div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rl-cap .ev{color:var(--ink);opacity:.86}
.rl-cap .hint{color:var(--brass);font-weight:700}
.rl-cap .fin{color:var(--coral);font-weight:700}
.rl-mkt{display:flex;gap:4px;padding:4px 8px;flex:none}
.rl-card{appearance:none;flex:1 1 0;min-width:0;height:58px;border-radius:9px;border:1px solid rgba(0,0,0,.35);position:relative;padding:0;cursor:pointer;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;box-shadow:0 2px 0 rgba(0,0,0,.35);touch-action:manipulation;overflow:hidden}
.rl-card::before{content:'';position:absolute;inset:3px;border:1.5px solid rgba(255,255,255,.55);border-radius:6px;pointer-events:none}
.rl-card .sy{font-size:19px;line-height:1;text-shadow:0 1px 2px rgba(0,0,0,.5)}
.rl-card .cn{font-size:10.5px;font-weight:700;text-shadow:0 1px 2px rgba(0,0,0,.6);white-space:nowrap}
.rl-card.c1{color:#2b1d00}.rl-card.c1 .sy,.rl-card.c1 .cn{text-shadow:none}
.rl-card.c1::before{border-color:rgba(60,40,0,.4)}
.rl-card.c6{background:conic-gradient(from 200deg,#d4473a,#e5b52c,#3d9a55,#3a72c8,#8d55c0,#d4473a)}
.rl-card.c6 .cn{background:rgba(0,0,0,.45);border-radius:5px;padding:0 4px}
.rl-card.back{background:repeating-linear-gradient(45deg,#3a2c52 0 6px,#33264a 6px 12px);color:var(--brass)}
.rl-card.back::before{border-color:rgba(227,174,69,.55)}
.rl-card.tkd{background:#efe3c4;color:#5a3d12}
.rl-card.tkd::before{border:1.5px dashed #b9945a}
.rl-card .n{font:700 15px var(--f-mono),monospace;line-height:1}
.rl-card.off{opacity:.38;cursor:default;filter:saturate(.6)}
.rl-card.on{box-shadow:0 0 0 2px var(--brass),0 2px 0 rgba(0,0,0,.35)}
.rl-card.empty{background:transparent;border:1.5px dashed var(--line);box-shadow:none;cursor:default}
.rl-card.empty::before{display:none}
.rl-card.nw{animation:rlflip .4s ease-out}
@keyframes rlflip{0%{transform:rotateY(90deg) scale(.9)}100%{transform:none}}
.rl-hand{display:flex;gap:4px;padding:2px 8px 8px;flex:none}
.rl-hc{flex:1 1 0;min-width:0;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;gap:3px;position:relative;border:1px solid rgba(0,0,0,.35);color:#fff;font:700 17px var(--f-mono),monospace;transition:opacity .2s,transform .15s;box-shadow:0 2px 0 rgba(0,0,0,.3)}
.rl-hc .sy{font-size:11px;opacity:.85;font-family:var(--f-body)}
.rl-hc.c1{color:#2b1d00}
.rl-hc.c6{background:conic-gradient(from 200deg,#d4473a,#e5b52c,#3d9a55,#3a72c8,#8d55c0,#d4473a)}
.rl-hc.c6 .v{background:rgba(0,0,0,.45);border-radius:6px;padding:0 4px}
.rl-hc.z{opacity:.28}
.rl-hc.use{box-shadow:0 0 0 2px var(--brass);transform:translateY(-3px)}
.rl-hide{flex:1;height:44px;border-radius:10px;border:1px dashed var(--line);display:grid;place-items:center;color:var(--muted);font-size:13px}
.rl-sheet{position:absolute;left:0;right:0;bottom:0;z-index:6;background:#221c2e;border-top:1px solid var(--line);border-radius:16px 16px 0 0;padding:10px 12px 10px;display:flex;flex-direction:column;gap:8px;box-shadow:0 -10px 30px rgba(0,0,0,.5);max-height:72%;overflow-y:auto;animation:rlup .18s ease-out}
@keyframes rlup{from{transform:translateY(30px);opacity:0}to{transform:none;opacity:1}}
.rl-sheet h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:19px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.rl-sheet .sub{font-size:13px;color:var(--muted);line-height:1.4}
.rl-sheet .warn{font-size:13px;color:var(--coral);font-weight:700;line-height:1.4}
.rl-sheet .row{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}
.rl-sheet .row .btn{flex:1 1 0;min-width:0}
.rl-tag{display:inline-flex;align-items:center;gap:5px;font:700 12px var(--f-body);padding:3px 8px;border-radius:999px;background:var(--surface-2);color:var(--ink)}
.rl-tag i{width:12px;height:12px;border-radius:3px;display:inline-block;border:1px solid rgba(0,0,0,.4)}
.rl-pts{font:700 13px var(--f-mono),monospace;color:var(--brass)}
.rl-opts{display:flex;gap:6px;flex-wrap:wrap}
.rl-opt{appearance:none;min-height:44px;padding:4px 10px;border-radius:10px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-weight:700;font-size:13px;display:flex;align-items:center;gap:6px;cursor:pointer}
.rl-opt i{width:14px;height:14px;border-radius:3px;border:1px solid rgba(0,0,0,.4)}
.rl-opt.on{border-color:var(--brass);box-shadow:inset 0 0 0 1px var(--brass);color:var(--brass)}
.rl-tl{display:flex;flex-direction:column;gap:5px}
.rl-sheet .hd{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:-4px 0 -4px}
.rl-sheet .x{appearance:none;width:44px;height:44px;border-radius:12px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-size:16px;cursor:pointer;flex:none}
.rl-t{appearance:none;width:100%;min-height:46px;border-radius:12px;border:1px solid var(--line);background:#2a2338;color:var(--ink);display:flex;align-items:center;gap:10px;padding:6px 10px;text-align:left;cursor:pointer;font-size:14px}
.rl-t .ck{width:22px;height:22px;border-radius:6px;border:2px solid var(--muted);flex:none;display:grid;place-items:center;font-size:14px;font-weight:900;color:var(--brass-ink)}
.rl-t.on{border-color:var(--brass);background:#3a2f22}
.rl-t.on .ck{background:var(--brass);border-color:var(--brass)}
.rl-t .nm{flex:1 1 auto;min-width:0;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rl-t .st{font-size:12px;color:var(--muted);white-space:nowrap}
.rl-t .st.ok{color:#7fd69a;font-weight:700}
.rl-t .st.bad{color:var(--coral);font-weight:700}
.rl-t .p{font:700 15px var(--f-mono),monospace;color:var(--brass);flex:none;min-width:26px;text-align:right}
.rl-t.sel{box-shadow:inset 0 0 0 2px var(--ink)}
.rl-fly{position:absolute;z-index:8;width:40px;height:54px;border-radius:7px;pointer-events:none;border:1px solid rgba(0,0,0,.4);box-shadow:0 6px 14px rgba(0,0,0,.5);transition:transform .38s cubic-bezier(.3,.7,.3,1),opacity .38s}
`;
  const cardBg = (c) => (c === W ? '' : COLH[c]);
  function mount(root, api) {
    const h = L.h;
    const spd = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'rl-wrap' });
    const plEl = h('div', { class: 'rl-pl' });
    const mapEl = h('div', { class: 'rl-map' });
    const capEl = h('div', { class: 'rl-cap' });
    const mktEl = h('div', { class: 'rl-mkt' });
    const handEl = h('div', { class: 'rl-hand' });
    wrap.append(plEl, mapEl, capEl, mktEl, handEl);
    root.append(style, wrap);
    const cv = U.canvas(mapEl), ctx = cv.ctx;
    const tkBtn = h('button', { class: 'rl-tkb', 'aria-label': '내 목적지 표 보기' });
    const zoomEl = h('div', { class: 'rl-zoom' },
      h('button', { text: '+', 'aria-label': '확대', onclick() { zoomBy(1.4); } }),
      h('button', { text: '−', 'aria-label': '축소', onclick() { zoomBy(1 / 1.4); } }),
      h('button', { text: '⤢', 'aria-label': '지도 전체 보기', onclick() { view.z = 1; clampView(); dirty = true; kick(); } }));
    mapEl.append(tkBtn, zoomEl);
    mapEl._rl = { open: (r) => openClaim(r), xy: (x, y) => [x * T.k + T.ox, y * T.k + T.oy] }; // test hook

    let st = null, gid = null, lastId = -1, pending = false, pendT = 0;
    let sheet = null, sheetKind = '', selR = -1, payC = -1, pickM = 0, pickKey = '', selT = -1;
    let hoverR = -1, padB = 0;
    let anim = null; // {r, seat, t0, dur}
    let busy = false, busyT = 0;
    let dirty = true, stopLoop = null, lastFrame = 0;
    const view = { z: 1, cx: 52, cy: 69 };   // zoom + map point at the centre of the fit rect
    let T = { k: 1, ox: 0, oy: 0 };
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    function busyFor(ms) { clearTimeout(busyT); setBusy(true); busyT = setTimeout(() => setBusy(false), ms); }

    /* ---------- transform ---------- */
    function fitRect() { const right = cv.w >= 520 ? 56 : 52; return { x: 4, y: 4, w: Math.max(40, cv.w - 4 - right), h: Math.max(40, cv.h - 8 - padB) }; }
    function k0() { const F = fitRect(); return Math.min(F.w / (MAPB.x1 - MAPB.x0), F.h / (MAPB.y1 - MAPB.y0)); }
    function clampView() {
      view.z = U.clamp(view.z, 1, 3.2);
      const F = fitRect(), k = k0() * view.z;
      const hw = F.w / 2 / k, hh = F.h / 2 / k;
      const mx = (MAPB.x0 + MAPB.x1) / 2, my = (MAPB.y0 + MAPB.y1) / 2;
      const ex = Math.max(0, (MAPB.x1 - MAPB.x0) / 2 - hw), ey = Math.max(0, (MAPB.y1 - MAPB.y0) / 2 - hh);
      view.cx = U.clamp(view.cx, mx - ex, mx + ex); view.cy = U.clamp(view.cy, my - ey, my + ey);
      T = { k, ox: F.x + F.w / 2 - view.cx * k, oy: F.y + F.h / 2 - view.cy * k };
    }
    function zoomBy(f, sx, sy) {
      const F = fitRect();
      if (sx == null) { sx = F.x + F.w / 2; sy = F.y + F.h / 2; }
      const mx = (sx - T.ox) / T.k, my = (sy - T.oy) / T.k;
      view.z = U.clamp(view.z * f, 1, 3.2);
      const k = k0() * view.z;
      view.cx = mx - (sx - F.x - F.w / 2) / k; view.cy = my - (sy - F.y - F.h / 2) / k;
      clampView(); dirty = true; kick();
    }
    cv.onresize = () => { clampView(); dirty = true; kick(); };
    clampView();
    const toMap = (x, y) => [(x - T.ox) / T.k, (y - T.oy) / T.k];

    /* ---------- state helpers ---------- */
    const P = () => api.players;
    const nm = (i) => (P()[i] ? P()[i].name : (st && st.nm && st.nm[i]) || '?');
    const cityN = (i) => CITY[i][0];
    const rName = (r) => cityN(ROUTES[r].a) + '–' + cityN(ROUTES[r].b);
    const tName = (ti) => cityN(TICKETS[ti].a) + ' → ' + cityN(TICKETS[ti].b);
    const vw = () => (st ? api.viewer() : -1);
    const myTurn = () => !!st && st.ph !== 9 && api.canAct(st.t) && vw() === st.t && !pending;
    const roShown = () => { if (!st) return ''; if (anim) return st.ro.slice(0, anim.r) + '.' + st.ro.slice(anim.r + 1); return st.ro; };
    function lockAct(a) { if (pending) return; pending = true; clearTimeout(pendT); pendT = setTimeout(() => { pending = false; renderAll(); }, 2500); api.act(a); }

    /* ---------- drawing ---------- */
    const bg = document.createElement('canvas'); const bgx = bg.getContext('2d');
    let bgKey = '';
    function carPath(g, c, inset, th) {
      const l = c.l - inset * 2, t = (th || CT) - inset * 2;
      g.save(); g.translate(c.x, c.y); g.rotate(c.a);
      g.beginPath(); if (g.roundRect) g.roundRect(-l / 2, -t / 2, l, t, 0.55); else g.rect(-l / 2, -t / 2, l, t);
      g.restore();
    }
    function drawTrainCar(g, c, col, k, alpha) {
      const th = CT * 1.18, l = c.l + 0.3;
      g.save(); g.translate(c.x, c.y); g.rotate(c.a); g.globalAlpha *= alpha;
      g.fillStyle = 'rgba(0,0,0,.5)'; g.beginPath(); if (g.roundRect) g.roundRect(-l / 2 + 0.3, -th / 2 + 0.55, l, th, 0.7); else g.rect(-l / 2 + 0.3, -th / 2 + 0.55, l, th); g.fill();
      g.beginPath(); if (g.roundRect) g.roundRect(-l / 2, -th / 2, l, th, 0.7); else g.rect(-l / 2, -th / 2, l, th);
      g.fillStyle = col; g.fill(); g.strokeStyle = '#120e18'; g.lineWidth = Math.max(0.35, 1.2 / k); g.stroke();
      g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(-l / 2 + 0.4, th / 2 - 0.75, l - 0.8, 0.4);
      g.fillStyle = 'rgba(255,250,235,.85)';
      const wn = c.l > 5 ? 3 : 2, ww = Math.min(1.1, (l - 1.4) / wn - 0.45);
      for (let i = 0; i < wn; i++) { const x = -l / 2 + 0.7 + i * ((l - 1.4) / wn) + ((l - 1.4) / wn - ww) / 2; g.fillRect(x, -th / 2 + 0.45, ww, 0.75); }
      g.restore();
    }
    function drawStatic() {
      const W0 = cv.w, H0 = cv.h, dpr = cv.dpr;
      const ro = roShown();
      const key = [W0, H0, dpr, T.k.toFixed(4), T.ox.toFixed(1), T.oy.toFixed(1), ro, st ? st.n : 0].join('|');
      if (key === bgKey) return;
      bgKey = key;
      if (bg.width !== Math.round(W0 * dpr) || bg.height !== Math.round(H0 * dpr)) { bg.width = Math.round(W0 * dpr); bg.height = Math.round(H0 * dpr); }
      const g = bgx;
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      // sea
      const sg = g.createLinearGradient(0, 0, 0, H0); sg.addColorStop(0, '#173a52'); sg.addColorStop(1, '#0f263a');
      g.fillStyle = sg; g.fillRect(0, 0, W0, H0);
      g.setTransform(dpr * T.k, 0, 0, dpr * T.k, dpr * T.ox, dpr * T.oy);
      const k = T.k;
      g.strokeStyle = 'rgba(160,210,230,.08)'; g.lineWidth = 0.35;
      for (let y = -6; y < 140; y += 7) for (let x = (y % 14 ? 0 : 6) - 6; x < 110; x += 13) { g.beginPath(); g.arc(x, y, 2.6, Math.PI * 1.15, Math.PI * 1.85); g.stroke(); }
      // land (shadow, body, coast line)
      const landPath = () => { g.beginPath(); LAND.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.closePath(); for (const e of ISLES) { g.moveTo(e[0] + e[2], e[1]); g.ellipse(e[0], e[1], e[2], e[3], 0, 0, Math.PI * 2); } };
      g.save(); g.translate(0.6, 1.1); landPath(); g.fillStyle = 'rgba(0,0,0,.35)'; g.fill(); g.restore();
      landPath();
      const lg = g.createLinearGradient(0, 0, 60, 135); lg.addColorStop(0, '#cfc29c'); lg.addColorStop(1, '#d9c597');
      g.fillStyle = lg; g.fill();
      g.strokeStyle = '#8fb3bf'; g.lineWidth = 0.7; g.stroke();
      g.strokeStyle = 'rgba(70,50,20,.35)'; g.lineWidth = 0.25; g.stroke();
      // soft hills
      g.fillStyle = 'rgba(120,140,80,.16)';
      for (const m of [[58, 30, 9, 14], [62, 62, 8, 10], [45, 85, 7, 6], [70, 44, 5, 8]]) { g.beginPath(); g.ellipse(m[0], m[1], m[2], m[3], 0.3, 0, Math.PI * 2); g.fill(); }
      // fade the north edge
      const fg = g.createLinearGradient(0, -1, 0, 9); fg.addColorStop(0, 'rgba(23,19,31,1)'); fg.addColorStop(1, 'rgba(23,19,31,0)');
      g.fillStyle = fg; g.fillRect(-200, -1, 500, 10.2);
      g.fillStyle = '#17131f'; g.fillRect(-200, -400, 500, 399.2);
      // routes
      for (let r = 0; r < NR; r++) {
        const R = ROUTES[r], o = ro[r];
        const dim = o === '.' && st && R.tw >= 0 && ro[R.tw] !== '.' && st.n <= 3;
        g.globalAlpha = dim ? 0.28 : 1;
        for (let q = 0; q < R.n; q++) {
          const c = GEO[r].cars[q];
          if (o === '.') {
            // free track: slimmer, flat slot
            carPath(g, c, 0, CT * 0.78);
            g.fillStyle = R.c === 6 ? '#b3ab99' : COLH[R.c]; g.fill();
            g.strokeStyle = 'rgba(25,18,32,.75)'; g.lineWidth = Math.max(0.25, 0.8 / k); g.stroke();
            carPath(g, c, 0.42, CT * 0.78); g.strokeStyle = R.c === 1 || R.c === 6 ? 'rgba(255,255,255,.5)' : 'rgba(255,255,255,.25)'; g.lineWidth = Math.max(0.12, 0.5 / k); g.stroke();
            if (q < R.f) { g.fillStyle = '#fff'; g.beginPath(); g.arc(c.x, c.y, 0.55, 0, Math.PI * 2); g.fill(); g.strokeStyle = '#3a72c8'; g.lineWidth = 0.25; g.stroke(); }
          } else drawTrainCar(g, c, P()[+o] ? P()[+o].color : '#ccc', k, 1);
        }
        g.globalAlpha = 1;
      }
      // cities
      const cr = Math.max(1.35, 5 / k);
      for (let i = 0; i < NC; i++) {
        const c = CITY[i];
        g.beginPath(); g.arc(c[1], c[2] + 0.25, cr, 0, Math.PI * 2); g.fillStyle = 'rgba(0,0,0,.4)'; g.fill();
        g.beginPath(); g.arc(c[1], c[2], cr, 0, Math.PI * 2); g.fillStyle = '#f6eedb'; g.fill();
        g.strokeStyle = '#2a1f33'; g.lineWidth = Math.max(0.35, 1.4 / k); g.stroke();
        g.beginPath(); g.arc(c[1], c[2], cr * 0.38, 0, Math.PI * 2); g.fillStyle = '#7a3b2a'; g.fill();
      }
      // labels in screen space (crisp)
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const fs = U.clamp(9.5 + (k - 2.8) * 0.9, 10, 13);
      g.font = '700 ' + fs + 'px "IBM Plex Sans KR", "Noto Sans KR", sans-serif';
      g.lineJoin = 'round';
      for (let i = 0; i < NC; i++) {
        const c = CITY[i], x = c[1] * k + T.ox, y = c[2] * k + T.oy, d = c[3], rr = cr * k + 2;
        let tx = x, ty = y; g.textAlign = 'center'; g.textBaseline = 'middle';
        if (d.includes('n')) ty = y - rr - fs * 0.55;
        if (d.includes('s')) ty = y + rr + fs * 0.6;
        if (d.includes('e')) { tx = x + rr + 1; g.textAlign = 'left'; if (d.length > 1) tx -= rr * 0.4; }
        if (d.includes('w')) { tx = x - rr - 1; g.textAlign = 'right'; if (d.length > 1) tx += rr * 0.4; }
        g.strokeStyle = 'rgba(23,19,31,.88)'; g.lineWidth = 3; g.strokeText(c[0], tx, ty);
        g.fillStyle = '#f6eedb'; g.fillText(c[0], tx, ty);
      }
    }
    function myTicketMarks() {
      const v = vw();
      if (!st || v < 0 || !st.tk[v]) return [];
      return st.tk[v].split('').map((ch) => { const ti = tkI(ch); return { ti, done: ticketDone(st, v, ti) }; });
    }
    function pathFor(seat, ti) {
      const Tk = TICKETS[ti];
      const res = sp((r) => (st.ro[r] === sc(seat) ? 0.01 : st.ro[r] === '.' && !twinBlocked(st, seat, r) ? ROUTES[r].n : Infinity), Tk.a);
      if (res.d[Tk.b] === Infinity) return [];
      const out = []; let v = Tk.b;
      while (v !== Tk.a) { const r = res.pr[v]; out.push(r); v = other(r, v); }
      return out;
    }
    function draw(now) {
      if (!st) return;
      drawStatic();
      cv.clear();
      ctx.drawImage(bg, 0, 0, bg.width, bg.height, 0, 0, cv.w, cv.h);
      const k = T.k;
      ctx.save();
      ctx.setTransform(cv.dpr * k, 0, 0, cv.dpr * k, cv.dpr * T.ox, cv.dpr * T.oy);
      const pulse = 0.55 + 0.45 * Math.sin(now / 260);
      // claimable highlights
      if (myTurn() && st.ph === 1 && !anim) {
        const v = st.t;
        ctx.strokeStyle = 'rgba(255,214,110,' + (0.45 + 0.5 * pulse).toFixed(3) + ')'; ctx.lineWidth = Math.max(0.5, 2.2 / k);
        for (const r of claimable(st, v)) for (const c of GEO[r].cars) { carPath(ctx, c, -0.45); ctx.stroke(); }
      }
      // ticket markers / chosen ticket path
      const showT = [];
      if (sheetKind === 'pick' && st.off) st.off.split('').forEach((ch, i) => showT.push({ ti: tkI(ch), on: (pickM >> i) & 1, pick: true }));
      else myTicketMarks().forEach((m) => showT.push(m));
      if (sheetKind === 'mine' && selT >= 0 && vw() >= 0) {
        const path = pathFor(vw(), selT);
        const line = (r) => { const pl = GEO[r].poly; ctx.beginPath(); pl.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); };
        ctx.lineCap = 'round';
        ctx.strokeStyle = 'rgba(18,14,24,.85)'; ctx.lineWidth = Math.max(1.2, 6 / k); path.forEach(line);
        ctx.setLineDash([Math.max(1, 5 / k), Math.max(0.8, 4 / k)]); ctx.lineDashOffset = -now / 60 / k;
        ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = Math.max(0.7, 3 / k); path.forEach(line);
        ctx.setLineDash([]); ctx.lineCap = 'butt';
      }
      const cr = Math.max(1.35, 5 / k);
      if (sheetKind === 'pick') { // a dashed "ticket line" between the two cities of each offered ticket
        ctx.lineCap = 'round';
        for (const m of showT) {
          const A = CITY[TICKETS[m.ti].a], B = CITY[TICKETS[m.ti].b];
          ctx.setLineDash([]); ctx.strokeStyle = 'rgba(18,14,24,.7)'; ctx.lineWidth = Math.max(0.9, 4.5 / k);
          ctx.beginPath(); ctx.moveTo(A[1], A[2]); ctx.lineTo(B[1], B[2]); ctx.stroke();
          ctx.setLineDash([Math.max(1, 5 / k), Math.max(0.8, 4 / k)]); ctx.strokeStyle = m.on ? '#ffcf5a' : '#f6eedb'; ctx.lineWidth = Math.max(0.5, 2.2 / k);
          ctx.beginPath(); ctx.moveTo(A[1], A[2]); ctx.lineTo(B[1], B[2]); ctx.stroke();
        }
        ctx.setLineDash([]); ctx.lineCap = 'butt';
      }
      for (const m of showT) {
        const focus = (sheetKind === 'mine' && m.ti === selT) || (m.pick && m.on);
        if (sheetKind === 'mine' && selT >= 0 && !focus) continue;
        const Tk = TICKETS[m.ti];
        for (const ci of [Tk.a, Tk.b]) {
          const c = CITY[ci];
          ctx.beginPath(); ctx.arc(c[1], c[2], cr + (focus ? 1.2 + pulse * 0.8 : 1.1), 0, Math.PI * 2);
          ctx.strokeStyle = m.done ? '#7fd69a' : m.pick && !m.on ? '#f6eedb' : '#ffcf5a';
          ctx.lineWidth = Math.max(0.45, (focus ? 2.6 : 1.8) / k); ctx.stroke();
        }
      }
      // hover / selected route
      for (const [r, col, w] of [[hoverR, 'rgba(255,255,255,.7)', 1.6], [selR, '#ffffff', 2.4]]) {
        if (r < 0) continue;
        ctx.strokeStyle = col; ctx.lineWidth = Math.max(0.4, w / k);
        for (const c of GEO[r].cars) { carPath(ctx, c, -0.55); ctx.stroke(); }
      }
      // claim animation: cars drop in one by one
      if (anim) {
        const R = ROUTES[anim.r], col = P()[anim.seat] ? P()[anim.seat].color : '#fff';
        const t = (performance.now() - anim.t0) / anim.dur;
        for (let q = 0; q < R.n; q++) {
          const f = U.clamp(t * (R.n + 1) - q, 0, 1);
          if (f <= 0) continue;
          const c = GEO[anim.r].cars[q];
          ctx.save(); ctx.translate(c.x, c.y); const sc2 = 1 + (1 - f) * 0.8; ctx.scale(sc2, sc2); ctx.translate(-c.x, -c.y);
          drawTrainCar(ctx, c, col, k, f);
          ctx.restore();
        }
        if (t > 0.3) {
          const G2 = GEO[anim.r];
          ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
          const x = G2.mx * k + T.ox, y = G2.my * k + T.oy - 10 - Math.min(1, t) * 14;
          ctx.globalAlpha = U.clamp(1.6 - t, 0, 1);
          ctx.font = '700 15px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 4; ctx.strokeStyle = '#17131f'; ctx.strokeText('+' + PTS[R.n], x, y);
          ctx.fillStyle = '#ffd36e'; ctx.fillText('+' + PTS[R.n], x, y);
          ctx.globalAlpha = 1;
        }
      }
      ctx.restore();
    }
    function needLoop() { return !!anim || (myTurn() && st.ph === 1) || (sheetKind === 'mine' && selT >= 0) || (sheetKind === 'pick'); }
    function kick() {
      if (stopLoop) return;
      stopLoop = U.loop((dt, now) => {
        if (anim && performance.now() - anim.t0 >= anim.dur) endAnim();
        const live = needLoop();
        if (dirty || live) {
          if (!dirty && live && !anim && now - lastFrame < 33) return;
          lastFrame = now; dirty = false; draw(now);
        }
        if (!dirty && !live) { stopLoop(); stopLoop = null; }
      });
    }

    /* ---------- events from state ---------- */
    function endAnim() {
      if (!anim) return;
      anim = null; dirty = true; bgKey = '';
      api.sfx('thud');
      renderAll();
    }
    function flyCard(fromEl, toEl, c, faceDown) {
      if (!fromEl || !toEl) return;
      const wr = wrap.getBoundingClientRect(), a = fromEl.getBoundingClientRect(), b = toEl.getBoundingClientRect();
      if (!a.width || !b.width) return;
      const el = h('div', { class: 'rl-fly' });
      if (faceDown || c == null) el.style.background = 'repeating-linear-gradient(45deg,#3a2c52 0 6px,#33264a 6px 12px)';
      else if (c === W) el.style.background = 'conic-gradient(from 200deg,#d4473a,#e5b52c,#3d9a55,#3a72c8,#8d55c0,#d4473a)';
      else el.style.background = COLH[c];
      el.style.left = (a.left - wr.left + a.width / 2 - 20) + 'px'; el.style.top = (a.top - wr.top + a.height / 2 - 27) + 'px';
      el.style.transitionDuration = (0.38 / spd()).toFixed(3) + 's';
      wrap.append(el);
      const dx = (b.left + b.width / 2) - (a.left + a.width / 2), dy = (b.top + b.height / 2) - (a.top + a.height / 2);
      requestAnimationFrame(() => requestAnimationFrame(() => { el.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(.55)'; el.style.opacity = '0.2'; }));
      setTimeout(() => el.remove(), 420 / spd() + 60);
    }
    let mktSlots = [], deckEl = null, tdEl = null, handChips = [], plChips = [];
    function onEvent(ev, prev) {
      const me = vw();
      if (ev.k === 'u' || ev.k === 'd') {
        api.sfx('card');
        const src = ev.k === 'u' ? mktSlots[ev.i] : deckEl;
        const dst = ev.s === me ? handChips[ev.c] : plChips[ev.s];
        // render first so the target exists, then fly
        renderAll(ev);
        flyCard(src, dst, ev.c, ev.k === 'd' && ev.s !== me);
        busyFor(300 / spd());
        if (ev.x) { api.toast('만능 카드가 3장 깔려서 공개 카드를 새로 깔았어요'); }
        return;
      }
      if (ev.k === 'r') {
        anim = { r: ev.r, seat: ev.s, t0: performance.now(), dur: (260 + 130 * ROUTES[ev.r].n) / spd() };
        busyFor(anim.dur + 40);
        api.sfx('chip'); if (api.canAct(ev.s)) api.buzz(18);
        // ticket finished?
        if (me >= 0 && ev.s === me && prev) {
          for (const ch of st.tk[me]) { const ti = tkI(ch); if (ticketDone(st, me, ti) && !ticketDone(prev, me, ti)) { setTimeout(() => { api.toast('목적지 완료! ' + tName(ti) + ' +' + TICKETS[ti].p); api.sfx('win'); }, anim.dur); } }
        }
      } else if (ev.k === 'o') { api.sfx('pop'); }
      else if (ev.k === 't') { api.sfx('card'); }
      else if (ev.k === 'p') { api.sfx('tick'); }
      if (prev && prev.lr < 0 && st.lr >= 0) { api.toast('마지막 바퀴! 모두 한 번씩만 더 해요'); api.buzz(30); }
      renderAll(ev);
    }

    /* ---------- DOM renders ---------- */
    function renderPlayers() {
      plEl.innerHTML = ''; plChips = [];
      plEl.classList.toggle('tight', st.n >= 5 || (st.n >= 4 && cv.w < 380));
      for (let i = 0; i < st.n; i++) {
        const p = P()[i] || { name: nm(i), color: '#ccc' };
        const cur = st.ph !== 9 && st.t === i;
        const rp = st.fs ? st.fs[i][4] : routePts(st, i);
        const el = h('div', { class: 'rl-p' + (cur ? ' cur' : ''), style: { '--c': p.color } },
          h('div', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': p.color } }), h('span', { class: 't', text: p.name })),
          h('div', { class: 'l' }, h('b', { class: st.tr[i] <= 6 ? 'low' : '', text: String(st.tr[i]) }), '량 ', h('b', { text: String(rp) }), st.fs ? '점!' : '점'),
          h('div', { class: 'l', text: '카드' + sum(st.h[i]) + ' 표' + st.tk[i].length }));
        plEl.append(el); plChips.push(el);
      }
    }
    function cardEl(c, extra) {
      const el = h('button', { class: 'rl-card c' + c + (extra || ''), style: { background: cardBg(c) || '' } },
        h('span', { class: 'sy', text: SYM[c] }), h('span', { class: 'cn', text: COLN[c] }));
      return el;
    }
    function renderMarket(ev) {
      mktEl.innerHTML = ''; mktSlots = [];
      const mine = myTurn() && (st.ph === 1 || st.ph === 2);
      for (let i = 0; i < 5; i++) {
        const ch = st.up[i];
        if (ch == null) { const e = h('div', { class: 'rl-card empty' }); mktEl.append(e); mktSlots.push(e); continue; }
        const c = +ch;
        const ok = mine && !(st.ph === 2 && c === W);
        const nw = ev && ((ev.k === 'u' && ev.i === i) || ev.x);
        const el = cardEl(c, (ok ? '' : ' off') + (nw ? ' nw' : ''));
        el.setAttribute('aria-label', '공개 카드 ' + COLN[c] + ' 가져오기');
        if (ok) el.onclick = () => { api.buzz(10); lockAct({ t: 'up', i }); };
        else el.onclick = () => { if (mine && c === W) api.toast('두 번째 카드로는 공개 만능을 못 가져가요'); };
        mktEl.append(el); mktSlots.push(el);
      }
      const left = st.dk.length + sum(st.dc);
      const dOk = mine && left > 0;
      deckEl = h('button', { class: 'rl-card back' + (dOk ? '' : ' off'), 'aria-label': '더미에서 한 장 뽑기' }, h('span', { class: 'n', text: String(left) }), h('span', { class: 'cn', text: '더미' }));
      if (dOk) deckEl.onclick = () => { api.buzz(10); lockAct({ t: 'dk' }); };
      const tOk = myTurn() && st.ph === 1 && st.td.length > 0;
      tdEl = h('button', { class: 'rl-card tkd' + (tOk ? '' : ' off'), 'aria-label': '목적지 표 뽑기' }, h('span', { class: 'n', text: String(st.td.length) }), h('span', { class: 'cn', text: '목적지' }));
      if (tOk) tdEl.onclick = () => { api.buzz(10); lockAct({ t: 'tk' }); };
      mktEl.append(deckEl, tdEl);
    }
    function renderHand() {
      handEl.innerHTML = ''; handChips = [];
      const v = vw();
      if (v < 0) { handEl.append(h('div', { class: 'rl-hide', text: st.ph === 9 ? '게임 끝' : '내 카드는 내 차례에 보여요' })); return; }
      const H = st.h[v];
      let use = null;
      if (sheetKind === 'claim' && selR >= 0) { const o = payOpts(H, selR).find((x) => x.c === payC); if (o) use = o; }
      for (let c = 0; c < 7; c++) {
        const u = use && ((use.c === c && use.k > 0) || (c === W && use.w > 0));
        const el = h('div', { class: 'rl-hc c' + c + (H[c] ? '' : ' z') + (u ? ' use' : ''), style: { background: cardBg(c) || '' }, title: COLN[c] },
          h('span', { class: 'v', text: String(H[c]) }), h('span', { class: 'sy', text: SYM[c] }));
        handEl.append(el); handChips.push(el);
      }
    }
    function renderTkBtn() {
      const m = myTicketMarks();
      tkBtn.style.display = m.length ? '' : 'none';
      tkBtn.innerHTML = '';
      tkBtn.append(h('span', { class: 'ic' }), '목적지', h('span', { class: 'ct', text: m.filter((x) => x.done).length + '/' + m.length }));
    }
    function evText(ev) {
      if (!ev) return '';
      const who = nm(ev.s) + ' · ';
      if (ev.k === 'u') return who + '공개 카드 ' + COLN[ev.c] + (ev.c === W ? ' (차례 끝)' : '') + ' 가져감';
      if (ev.k === 'd') return who + '더미에서 1장' + (ev.s === vw() ? ' (' + COLN[ev.c] + ')' : '');
      if (ev.k === 'r') return who + rName(ev.r) + ' 노선 깔기 +' + PTS[ROUTES[ev.r].n] + '점';
      if (ev.k === 'o') return who + '목적지 표 ' + ev.m + '장 보는 중';
      if (ev.k === 't') return who + '목적지 표 ' + ev.n + '장 가져감';
      if (ev.k === 'p') return who + '할 수 있는 게 없어 넘김';
      return '';
    }
    function renderCap() {
      capEl.innerHTML = '';
      const ev = st.last ? evText(st.last) : '';
      let hint = '', cls = 'hint';
      if (st.ph === 9) { hint = '게임 끝 — 결과를 확인하세요'; cls = 'fin'; }
      else if (myTurn()) {
        if (st.ph === 1) hint = '카드 2장 뽑기 · 반짝이는 노선 깔기 · 목적지 표';
        else if (st.ph === 2) hint = '한 장 더 뽑으세요 (공개 만능은 안 돼요)';
        else hint = '가져갈 목적지 표를 고르세요';
      } else if (st.ph === 0 || st.ph === 3) hint = nm(st.t) + ' 목적지 표 고르는 중…';
      else if (st.ph === 2) hint = nm(st.t) + ' 한 장 더 뽑는 중…';
      if (st.lr >= 0 && st.ph !== 9) { hint = myTurn() ? '내 마지막 차례! ' + (st.ph === 1 ? '노선 깔기 또는 카드 뽑기' : hint) : '마지막 바퀴 · ' + st.lr + '차례 남음'; cls = myTurn() ? 'hint' : 'fin'; }
      if (!ev && st.ph === 0) capEl.append(h('div', { class: 'ev', text: '같은 색 카드로 노선을 깔아 목적지 두 도시를 이어요' }));
      if (ev) capEl.append(h('div', { class: 'ev', text: ev }));
      if (hint) capEl.append(h('div', { class: cls, text: hint }));
    }
    function closeSheet() { if (sheet) sheet.remove(); sheet = null; wrap.classList.remove('sheet-on'); sheetKind = ''; selR = -1; selT = -1; setPad(0); dirty = true; kick(); }
    /* a big sheet (ticket lists) shrinks the map so the whole map stays visible above it */
    function setPad(px) { px = Math.max(0, Math.round(px)); if (Math.abs(px - padB) < 2) return; padB = px; zoomEl.style.transform = 'translateY(calc(-50% - ' + (px / 2) + 'px))'; view.z = 1; clampView(); bgKey = ''; dirty = true; kick(); }
    function fitAboveSheet() { if (!sheet) return setPad(0); setPad(Math.min(mapEl.offsetHeight - 120, mapEl.offsetTop + mapEl.offsetHeight - sheet.offsetTop)); }
    function openClaim(r) {
      if (!st) return;
      const v = vw();
      // tapped the unusable twin? use its free sibling instead
      const tw = ROUTES[r].tw;
      if (v >= 0 && tw >= 0 && myTurn() && !(canClaim(st, v, r) && payOpts(st.h[v], r).length) && canClaim(st, v, tw) && payOpts(st.h[v], tw).length) r = tw;
      selR = r; sheetKind = 'claim';
      const o0 = v >= 0 ? payOpts(st.h[v], r) : [];
      payC = o0.length ? o0[0].c : -1;
      renderSheet(); api.sfx('click');
    }
    function renderSheet() {
      if (sheet) sheet.remove(); sheet = null; wrap.classList.remove('sheet-on'); // .sheet-on: lets tutorial steps skip covered parts
      if (!st) return;
      if (sheetKind === 'pick') return renderPick();
      if (sheetKind === 'mine') return renderMine();
      if (sheetKind !== 'claim' || selR < 0) { sheetKind = ''; return; }
      const r = selR, R = ROUTES[r], v = vw();
      const owner = st.ro[r];
      const tag = h('span', { class: 'rl-tag' }, h('i', { style: { background: R.c === 6 ? 'repeating-linear-gradient(45deg,#bfb7a6 0 3px,#8f8878 3px 6px)' : COLH[R.c] } }), (R.c === 6 ? '아무 색' : COLN[R.c]) + ' ' + R.n + '칸');
      const head = h('h3', { text: rName(r) + ' ' }, tag, h('span', { class: 'rl-pts', text: '+' + PTS[R.n] + '점' }));
      const body = [];
      if (R.f) body.push(h('div', { class: 'sub', text: '배 노선: 만능 카드가 ' + R.f + '장 꼭 들어가야 해요' }));
      let can = false, opts = [];
      if (owner !== '.') body.push(h('div', { class: 'sub', text: nm(+owner) + '의 노선이에요' }));
      else if (v < 0) body.push(h('div', { class: 'sub', text: '내 차례에 깔 수 있어요' }));
      else {
        const H = st.h[v];
        opts = payOpts(H, r);
        if (twinBlocked(st, v, r)) body.push(h('div', { class: 'warn', text: st.n <= 3 ? '2~3명일 때는 나란한 두 노선 중 하나만 깔 수 있어요' : '나란한 두 노선을 한 사람이 둘 다 깔 수는 없어요' }));
        else if (st.tr[v] < R.n) body.push(h('div', { class: 'warn', text: '기차가 모자라요 (남은 기차 ' + st.tr[v] + '량)' }));
        else if (!opts.length) {
          let msg;
          if (R.c < 6) { const miss = Math.max(0, R.n - R.f - H[R.c] - Math.max(0, H[W] - R.f)) + Math.max(0, R.f - H[W]); msg = COLN[R.c] + ' 카드가 ' + miss + '장 더 필요해요 (만능으로 채울 수 있어요)'; if (H[W] < R.f) msg = '만능 카드가 ' + (R.f - H[W]) + '장 더 필요해요'; }
          else { let gc = 0; for (let c = 1; c < 6; c++) if (H[c] > H[gc]) gc = c; const miss = Math.max(0, R.n - R.f - H[gc] - Math.max(0, H[W] - R.f)) + Math.max(0, R.f - H[W]); msg = '한 가지 색으로 ' + R.n + '장이 필요해요 (지금 가장 많은 ' + COLN[gc] + ' ' + H[gc] + '장 + 만능 ' + H[W] + '장, ' + miss + '장 부족)'; }
          body.push(h('div', { class: 'warn', text: msg }));
        } else if (!myTurn()) body.push(h('div', { class: 'sub', text: '내 차례가 되면 깔 수 있어요' }));
        else if (st.ph !== 1) body.push(h('div', { class: 'sub', text: '카드를 한 장 더 뽑아야 차례가 끝나요' }));
        else {
          can = true;
          body.push(h('div', { class: 'sub', text: '낼 카드' + (opts.length > 1 ? '를 고르세요' : '') + ' · 남은 기차 ' + st.tr[v] + ' → ' + (st.tr[v] - R.n) + '량' }));
          const box = h('div', { class: 'rl-opts' });
          for (const o of opts) {
            const lab = (o.k ? COLN[o.c] + ' ' + o.k : '') + (o.k && o.w ? ' + ' : '') + (o.w ? '만능 ' + o.w : '');
            const b = h('button', { class: 'rl-opt' + (o.c === payC ? ' on' : '') }, h('i', { style: { background: o.c === W ? 'conic-gradient(#d4473a,#e5b52c,#3d9a55,#3a72c8,#8d55c0,#d4473a)' : COLH[o.c] } }), lab);
            b.onclick = () => { payC = o.c; renderSheet(); renderHand(); };
            box.append(b);
          }
          body.push(box);
        }
      }
      const okBtn = h('button', { class: 'btn primary', text: '노선 깔기' });
      okBtn.disabled = !can;
      okBtn.onclick = () => { if (!can) return; const c = payC; const rr = selR; closeSheet(); renderHand(); api.buzz(15); lockAct({ t: 'cl', r: rr, c }); };
      const row = h('div', { class: 'row' }, h('button', { class: 'btn ghost', text: '닫기', onclick() { closeSheet(); renderHand(); } }), can ? okBtn : null);
      sheet = h('div', { class: 'rl-sheet' }, head, ...body, row);
      wrap.append(sheet); wrap.classList.add('sheet-on');
      dirty = true; kick();
    }
    function ticketStatus(seat, ti) {
      if (ticketDone(st, seat, ti)) return ['완료!', 'ok'];
      const nd = needFor(st, seat, ti);
      if (nd === Infinity) return ['막힘', 'bad'];
      return ['남은 ' + nd + '칸', ''];
    }
    function renderPick() {
      const off = st.off.split('').map(tkI), need = Math.min(st.ph === 0 ? 2 : 1, off.length), v = st.t;
      const cnt = off.filter((_, i) => (pickM >> i) & 1).length;
      const list = h('div', { class: 'rl-tl' });
      off.forEach((ti, i) => {
        const on = (pickM >> i) & 1;
        const [txt, cls] = ticketStatus(v, ti);
        const b = h('button', { class: 'rl-t' + (on ? ' on' : '') }, h('span', { class: 'ck', text: on ? '✓' : '' }),
          h('span', { class: 'nm', text: tName(ti) }), h('span', { class: 'st ' + cls, text: txt }), h('span', { class: 'p', text: String(TICKETS[ti].p) }));
        b.onclick = () => { pickM ^= 1 << i; api.sfx('click'); renderSheet(); };
        list.append(b);
      });
      const ok = h('button', { class: 'btn primary', text: cnt >= need ? cnt + '장 가져가기' : need + '장 이상 고르세요' });
      ok.disabled = cnt < need;
      ok.onclick = () => { if (cnt < need) return; const m = pickM; closeSheet(); api.buzz(12); lockAct({ t: 'keep', m }); };
      sheet = h('div', { class: 'rl-sheet' },
        h('h3', { text: '목적지 표 고르기' }),
        h('div', { class: 'sub', text: '이으면 +점수, 못 이으면 −점수 · ' + need + '장 이상' }),
        list, h('div', { class: 'row' }, ok));
      wrap.append(sheet); wrap.classList.add('sheet-on');
      fitAboveSheet();
      dirty = true; kick();
    }
    function renderMine() {
      const v = vw();
      if (v < 0) { sheetKind = ''; return; }
      const list = h('div', { class: 'rl-tl' });
      let plus = 0, minus = 0;
      st.tk[v].split('').map(tkI).forEach((ti) => {
        const [txt, cls] = ticketStatus(v, ti);
        if (cls === 'ok') plus += TICKETS[ti].p; else minus += TICKETS[ti].p;
        const b = h('button', { class: 'rl-t' + (selT === ti ? ' sel' : '') }, h('span', { class: 'nm', text: tName(ti) }), h('span', { class: 'st ' + cls, text: txt }), h('span', { class: 'p', text: (cls === 'ok' ? '+' : '') + TICKETS[ti].p }));
        b.onclick = () => { selT = selT === ti ? -1 : ti; api.sfx('click'); renderSheet(); };
        list.append(b);
      });
      sheet = h('div', { class: 'rl-sheet' },
        h('div', { class: 'hd' }, h('h3', { text: '내 목적지 표' }), h('button', { class: 'x', 'aria-label': '닫기', text: '✕', onclick: closeSheet })),
        h('div', { class: 'sub', text: '지금 끝나면 +' + plus + (minus ? ' / −' + minus : '') + '점 · 표를 누르면 길이 보여요' }),
        list);
      wrap.append(sheet); wrap.classList.add('sheet-on');
      fitAboveSheet();
      dirty = true; kick();
    }
    tkBtn.onclick = () => { if (sheetKind === 'pick') return; if (sheetKind === 'mine') { closeSheet(); return; } sheetKind = 'mine'; selT = -1; selR = -1; renderSheet(); api.sfx('click'); };

    function syncSheets() {
      // ticket choice sheet appears automatically for me
      const pick = myTurn() && (st.ph === 0 || st.ph === 3) && st.off.length > 0;
      const key = st.g + ':' + st.sq;
      if (pick) {
        if (sheetKind !== 'pick' || pickKey !== key) { pickKey = key; pickM = 0; sheetKind = 'pick'; selR = -1; renderSheet(); }
      } else if (sheetKind === 'pick') closeSheet();
      else if (sheetKind === 'claim') renderSheet();
      else if (sheetKind === 'mine') { if (vw() < 0) closeSheet(); else renderSheet(); }
    }
    function renderAll(ev) {
      if (!st) return;
      renderPlayers(); renderMarket(ev); renderHand(); renderTkBtn(); renderCap(); syncSheets();
      dirty = true; kick();
    }

    /* ---------- pointer: tap a route, drag to pan, pinch / wheel to zoom ---------- */
    const pts = new Map();
    let drag = null, pinch = null;
    function hitRoute(x, y) {
      const [mx, my] = toMap(x, y);
      const tol = Math.max(2.2, 15 / T.k);
      let best = -1, bd = tol;
      for (let r = 0; r < NR; r++) {
        const pl = GEO[r].poly;
        for (let i = 1; i < pl.length; i++) {
          const ax = pl[i - 1][0], ay = pl[i - 1][1], bx = pl[i][0], by = pl[i][1];
          const dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy;
          const t = L2 ? U.clamp(((mx - ax) * dx + (my - ay) * dy) / L2, 0, 1) : 0;
          const d = Math.hypot(ax + dx * t - mx, ay + dy * t - my);
          if (d < bd) { bd = d; best = r; }
        }
      }
      return best;
    }
    function onDown(e) {
      const p = cv.local(e);
      pts.set(e.pointerId, p);
      try { mapEl.setPointerCapture(e.pointerId); } catch (er) { /* ignore */ }
      if (pts.size === 1) drag = { x: p.x, y: p.y, cx: view.cx, cy: view.cy, moved: false };
      else if (pts.size === 2) {
        const [a, b] = [...pts.values()];
        pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, z: view.z, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 };
        if (drag) drag.moved = true;
      }
    }
    function onMove(e) {
      const p = cv.local(e);
      if (!pts.has(e.pointerId)) {
        if (e.pointerType === 'mouse') { const r = hitRoute(p.x, p.y); if (r !== hoverR) { hoverR = r; mapEl.classList.toggle('hov', r >= 0); dirty = true; kick(); } }
        return;
      }
      pts.set(e.pointerId, p);
      if (pinch && pts.size >= 2) {
        const [a, b] = [...pts.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y) || 1;
        const f = (pinch.z * d / pinch.d) / view.z;
        zoomBy(f, (a.x + b.x) / 2, (a.y + b.y) / 2);
        return;
      }
      if (drag) {
        if (!drag.moved && Math.hypot(p.x - drag.x, p.y - drag.y) > 7) drag.moved = true;
        if (drag.moved && view.z > 1.001) {
          view.cx = drag.cx - (p.x - drag.x) / T.k; view.cy = drag.cy - (p.y - drag.y) / T.k;
          clampView(); dirty = true; kick();
        }
      }
    }
    function onUp(e) {
      const p = cv.local(e);
      const had = pts.delete(e.pointerId);
      if (pts.size < 2) pinch = null;
      if (!had) return;
      if (pts.size === 0) {
        if (drag && !drag.moved && e.type === 'pointerup') {
          const r = hitRoute(p.x, p.y);
          if (r >= 0) openClaim(r);
          else if (sheetKind === 'claim' || sheetKind === 'mine') { closeSheet(); renderHand(); }
        }
        drag = null;
      } else if (pts.size === 1) { const q = [...pts.values()][0]; drag = { x: q.x, y: q.y, cx: view.cx, cy: view.cy, moved: true }; }
    }
    function onWheel(e) { e.preventDefault(); const p = cv.local(e); zoomBy(e.deltaY < 0 ? 1.18 : 1 / 1.18, p.x, p.y); }
    function onLeave() { if (hoverR >= 0) { hoverR = -1; mapEl.classList.remove('hov'); dirty = true; kick(); } }
    function onKey(e) { if (e.key === 'Escape' && sheet && sheetKind !== 'pick') { e.preventDefault(); closeSheet(); renderHand(); } }
    mapEl.addEventListener('pointerdown', onDown);
    mapEl.addEventListener('pointermove', onMove);
    mapEl.addEventListener('pointerup', onUp);
    mapEl.addEventListener('pointercancel', onUp);
    mapEl.addEventListener('pointerleave', onLeave);
    mapEl.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('keydown', onKey);

    return {
      update(next, prev) {
        st = next; pending = false; clearTimeout(pendT);
        if (next.g !== gid) {
          gid = next.g; lastId = next.last ? next.last.id : -1;
          if (anim) anim = null;
          closeSheet(); renderAll(); return;
        }
        if (next.last && next.last.id !== lastId) {
          lastId = next.last.id;
          if (anim) { anim = null; bgKey = ''; }
          onEvent(next.last, prev && prev !== next ? prev : null);
          return;
        }
        renderAll();
      },
      destroy() {
        if (stopLoop) stopLoop(); stopLoop = null;
        clearTimeout(busyT); clearTimeout(pendT);
        if (busy) api.setBusy(false);
        window.removeEventListener('keydown', onKey);
        cv.destroy(); wrap.remove(); style.remove();
      },
    };
  }

  const ICON = '<circle cx="12" cy="44" r="6" fill="currentColor"/><circle cx="44" cy="12" r="6" fill="currentColor"/>' +
    '<path d="M16 40 L40 16" stroke="currentColor" stroke-width="9" stroke-linecap="round" opacity=".35" fill="none"/>' +
    '<path d="M17.5 38.5l5-5M25.5 30.5l5-5M33.5 22.5l5-5" stroke="currentColor" stroke-width="6" stroke-linecap="round" fill="none"/>' +
    '<rect x="30" y="38" width="20" height="13" rx="3" fill="currentColor"/><rect x="6" y="6" width="20" height="13" rx="3" fill="currentColor" opacity=".55"/>';

  L.register({
    id: 'rails', name: '기찻길 노선 잇기', tag: '노선 · 카드 모으기', cat: '보드', hidden: true,
    icon: ICON, tint: '#1d4b5c',
    blurb: '같은 색 기차 카드를 모아 도시 사이 노선을 깔고, 목적지 표의 두 도시를 이어 점수를 모아요.',
    minPlayers: 2, maxPlayers: 5, defaultPlayers: 3, aiDelay: 760,
    quick: [
      '기차 카드를 모아 도시 사이에 내 노선을 깔고, 목적지 표의 두 도시를 이어 점수를 모아요.',
      '내 차례엔 셋 중 하나: 카드 2장 뽑기 · 같은 색 카드로 노선 깔기 · 목적지 표 뽑기.',
      '누군가 기차가 2량 이하가 되면 한 바퀴 더 하고 끝! 노선 점수 + 목적지(이으면 +, 못 이으면 −) + 가장 긴 기찻길 보너스.',
    ],
    rules: [
      { h: '목표', p: [
        '같은 색 기차 카드를 모아 도시 사이에 내 노선(기찻길)을 깔아요. 노선을 깔 때마다 점수를 받아요.',
        '목적지 표에 적힌 두 도시를 내 노선만으로 이으면 보너스, 못 이으면 감점이에요.',
        '게임이 끝났을 때 점수가 가장 높은 사람이 이겨요.'] },
      { h: '준비', p: [
        '모두 카드 4장을 받아요.',
        '기차는 2~3명이면 ' + trainsFor(3) + '량씩. 사람이 많으면 조금 줄어요: 4명 ' + trainsFor(4) + '량, 5명 ' + trainsFor(5) + '량.',
        '목적지 표 3장을 보고 2장 이상 골라 가져가요. 1번 사람부터 차례로 골라요.',
        '내 카드와 목적지 표는 남에게 안 보여요. (한 폰으로 여럿이 하면 차례마다 가림막이 떠요.)'] },
      { h: '차례에 할 일 — 셋 중 하나만', p: [
        '① 카드 2장 뽑기: 공개 카드 5장 중에서, 또는 뒤집힌 더미에서 한 장씩 두 번 가져와요.',
        '(카드 뽑기) 공개된 만능 카드를 첫 장으로 가져오면 그 한 장으로 끝이에요.',
        '(카드 뽑기) 두 번째 장으로는 공개된 만능 카드를 가져갈 수 없어요(더미에서 뽑은 만능은 괜찮아요).',
        '② 노선 깔기: 노선의 칸 수만큼 같은 색 카드를 내고, 그 노선에 내 기차를 올려요.',
        '③ 목적지 표 뽑기: 표 3장을 보고 1장 이상 가져가요.'] },
      { h: '노선 깔기 자세히', p: [
        '노선 색과 같은 색 카드를 칸 수만큼 내요. 예: 파랑 3칸 노선 → 파랑 3장.',
        '만능 카드(무지개)는 어떤 색으로도 쓸 수 있어요. 예: 파랑 2장 + 만능 1장.',
        '회색 노선은 아무 색이나 한 가지 색으로 모아 내면 돼요.',
        '노선을 깔면 칸 수만큼 기차를 써요. 남은 기차보다 긴 노선은 못 깔아요.',
        '이미 누가 깐 노선은 다른 사람이 깔 수 없어요.'] },
      { h: '점수·승리', p: [
        '노선을 깔 때 바로: 1칸 1점 · 2칸 2점 · 3칸 4점 · 4칸 6점 · 6칸 12점. 긴 노선일수록 이득이에요.',
        '게임 끝에 목적지 표: 두 도시가 내 노선으로 이어져 있으면 +표의 점수, 아니면 −표의 점수.',
        '가장 긴 기찻길 +' + BONUS + '점: 같은 노선을 두 번 지나지 않고 쭉 이어지는 내 기찻길이 가장 긴 사람(동점이면 모두).',
        '총점이 같으면 목적지를 더 많이 이은 사람, 그래도 같으면 가장 긴 기찻길이 긴 사람이 이겨요.'] },
      { h: '끝내기', p: [
        '누군가 차례를 마쳤을 때 남은 기차가 2량 이하면 「마지막 바퀴」가 시작돼요.',
        '그 사람까지 모두 한 번씩 더 하고 게임이 끝나요.'] },
      { h: '특수 규칙', p: [
        '배 노선(바다 위, 흰 점이 찍힌 칸): 흰 점 수만큼 만능 카드가 꼭 들어가야 해요.',
        '두 줄로 나란한 노선: 한 사람이 둘 다 깔 수는 없어요. 2~3명일 때는 둘 중 한 줄만 쓸 수 있어요(나머지는 흐리게 보여요).',
        '공개 카드에 만능이 3장 깔리면 5장을 모두 버리고 새로 깔아요.',
        '더미가 떨어지면 버린 카드를 섞어 다시 써요.'] },
      { h: '카드', p: [
        '6가지 색(빨강·노랑·초록·파랑·보라·검정) 12장씩 + 만능 ' + NWILD + '장.',
        '색마다 모양(● ▲ ■ ◆ ★ ✚)도 달라서 색을 구분하기 어려워도 알아볼 수 있어요.'] },
      { h: '조작', p: [
        '지금 깔 수 있는 노선은 노랗게 반짝여요. 노선을 톡 누르면 낼 카드를 확인하고 「노선 깔기」로 깔아요.',
        '카드는 아래 공개 카드 · 더미를 톡 해서 뽑아요. 「목적지」 더미를 톡 하면 표를 뽑아요.',
        '「목적지」 버튼: 내 표와 남은 칸 수를 보여 줘요. 표를 누르면 지도에 가장 짧은 길이 점선으로 나와요.',
        '지도는 끌어서 옮기고, 두 손가락 · 마우스 휠 · ＋/− 버튼으로 확대해요. ⤢는 전체 보기.'] },
      { h: '예시', p: [
        '목적지 표 「인천 → 강릉」을 가졌어요.',
        '빨강 2장 + 만능 1장이 있어요. 빨강 3칸인 「춘천–속초」를 톡 → 「빨강 2 + 만능 1」로 「노선 깔기」 → 기차 3량을 쓰고 바로 +4점!',
        '다음엔 「인천–서울」(1칸) · 「서울–춘천」(3칸) · 「속초–강릉」(2칸)을 깔면 인천에서 강릉까지 이어져요 → 게임 끝에 표 점수만큼 +.',
        '못 이으면 그만큼 −이니, 표는 욕심내지 않게 고르세요.'] },
      { h: 'AI 난이도', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움은 목적지를 자주 잊고 아무 노선이나 깔아요. 보통은 목적지까지 가장 짧은 길을 계획해요. 어려움은 카드와 표를 더 잘 관리하고, 가끔 남의 길목도 막아요.'] },
    ],
    tutorial: [
      { sel: '.rl-map', text: '우리만의 한국 지도예요. 도시 사이의 색 칸 줄이 노선이에요. 같은 색 카드를 칸 수만큼 내면 그 노선에 내 기차를 깔 수 있어요.' },
      { sel: '.rl-sheet', text: '시작할 때 목적지 표 3장 중 2장 이상을 골라요. 표의 두 도시를 내 노선으로 이으면 +점수(오른쪽 숫자), 못 이으면 그만큼 −점수예요!' },
      { sel: '.rl-pl', text: '위쪽엔 사람마다 남은 기차(량) · 점수 · 카드와 표 수가 보여요.' },
      { sel: '.rl-wrap:not(.sheet-on) .rl-mkt', text: '내 차례엔 셋 중 하나만 해요. ① 카드 2장 뽑기: 아래 공개 카드 5장이나 더미에서 한 장씩(표를 고르면 보여요). 공개된 만능은 첫 장으로만, 가져오면 그걸로 끝!' },
      { sel: '.rl-wrap:not(.sheet-on) .rl-hand', text: '맨 아래는 내 기차 카드예요(색마다 몇 장인지). 무지개 만능 카드는 어떤 색으로도 쓸 수 있어요.' },
      { sel: '.rl-map', text: '② 노선 깔기: 지금 깔 수 있는 노선은 노랗게 반짝여요. 노선을 톡 → 낼 카드 확인 → 「노선 깔기」. 긴 노선일수록 점수가 커요(6칸 12점)!' },
      { sel: '.rl-tkb:not([style*="none"])', text: '③ 목적지 표 뽑기: 아래 「목적지」 더미를 톡 → 3장 중 1장 이상. 표를 가진 뒤엔 지도 왼쪽 위 「목적지」 버튼으로 내 표와 가장 짧은 길을 볼 수 있어요.' },
      { sel: '.rl-pl', text: '누군가 기차가 2량 이하가 되면 모두 한 번씩 더 하고 끝! 가장 긴 기찻길은 +10점. 자, 목적지 표부터 골라 볼까요?' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { K, GEO, CITY, ROUTES, TICKETS, PTS, payOpts, claimable, plan, needFor, longestTrail, ticketDone, fillUp, canDrawSecond, routePts },
  });
})();
