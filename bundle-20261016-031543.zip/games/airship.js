/* 비행선 화물 균형 — 하늘에 뜬 비행선의 화물칸(단면 9×6 칸)에 상자를 번갈아 싣는 턴제 균형 게임(1–4인).
   물리(1자유도, 결정적): 배 전체가 부력 중심 B(바닥 위 HB)에 매달린 강체. 중력 토크 = −G·Σm·X(B 기준 세계 x),
     기울기 θ(반시계 +, 왼쪽이 내려감)는 무게중심이 B 바로 아래로 올 때 멈춘다 → tanθ = (Sx − M·bx)/(Sy − M·HB).
     높이 쌓을수록(HB에 가까울수록) 복원력이 약해져 잘 기운다. 감쇠 진자(고정 스텝 1/60 s, 다항식 sin/cos)로 흔들림을 재생.
   · 상자: 위에서 칸 기둥으로 떨어뜨려(테트리스식) 싣는다. 무게·모양이 제각각, 특수 상자 4종:
     액체 탱크(물이 낮은 쪽으로 쏠림), 풍선 상자(무게 −1), 닻(무게 5, 안 미끄러짐), 동물 상자(차례 끝마다 양이 반대쪽 칸으로).
   · 흔들림이 미끄럼 각(보통 18°, 얼음 12°)을 넘으면 위가 비어 있는 상자가 낮은 쪽으로 한 칸씩 미끄러진다(화물 쏠림).
     벽이 있는 아래 4줄은 벽에 막히고, 위 2줄(열린 갑판)에서 밖으로 밀리면 떨어진다. 30°를 넘으면 추락(게임 끝).
   · 조정(한 판에 2번, 혼자 4번): 모래주머니 버리기(좌/우 각 3개) 또는 가스 옮기기(부력 중심을 좌우로, ±3단). 상자는 다음 사람에게.
   · 날씨(항로 6종): 바람(일정 토크, 미리 보임), 돌풍(충격, 미리 보임), 난기류(±T, 운 — apply에서 뽑아 last.ev에 저장), 화산재(기구 위 무게).
   apply가 끝까지 시뮬레이션하고 last={id, s, pre, ev, ...}를 남기며 뷰는 같은 시뮬레이션을 재생한다.
   State: { n, nm[], R, sd, D, dk, di, g(54칸 문자열), pc(조각당 3글자: 종류·주인·양 위치/x=떨어짐), th(밀리라디안),
            bl[2], pu, ash[2], tk[], pe[], t, tmax, cur, end(0/1 도착/2 추락), cr, sk, seq, last } */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= constants ======================= */
  const GW = 9, GH = 6, NC = GW * GH, WALLR = 3;          // rows 0..3 have side walls, rows 4..5 are the open deck
  const HB = 3.0, GRAV = 240, DT = 1 / 60;
  const M0 = 12, Y0 = -1.0, I0 = 260, ZETA = 0.36;
  const BAGW = 1.2, BAGX = 5.45, BAGY = 1.9, NBAG = 3;
  const ASHW = 0.45, ASHX = 2.8, ASHY = 10.6, ASHMAX = 5;
  const PUMP = 0.35, PUMAX = 3;
  const WU = 700, JU = 170;
  const KSL = 2.6, SLMAX = 0.9;                           // liquid slosh
  const DEG = Math.PI / 180, CRASH = 30 * DEG, SAFE = 10;
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const PI = 3.141592653589793, TAU = 2 * PI, HPI = PI / 2;
  function dsin(x) {
    x = x - TAU * Math.round(x / TAU);
    if (x > HPI) x = PI - x; else if (x < -HPI) x = -PI - x;
    const x2 = x * x;
    return x * (1 - x2 / 6 * (1 - x2 / 20 * (1 - x2 / 42 * (1 - x2 / 72 * (1 - x2 / 110 * (1 - x2 / 156))))));
  }
  const dcos = (x) => dsin(x + HPI);
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* ======================= crates ======================= */
  const L4 = [[[0, 0], [1, 0], [0, 1]], [[0, 0], [1, 0], [1, 1]], [[1, 0], [1, 1], [0, 1]], [[0, 0], [0, 1], [1, 1]]];
  const T4 = [[[0, 0], [1, 0], [2, 0], [1, 1]], [[0, 1], [1, 1], [2, 1], [1, 0]], [[0, 0], [0, 1], [0, 2], [1, 1]], [[1, 0], [1, 1], [1, 2], [0, 1]]];
  const TYPES = [
    { n: '작은 상자', w: 1, v: 1, col: '#d9a35f', rots: [[[0, 0]]] },
    { n: '긴 상자', w: 2, v: 2, col: '#c98a4a', rots: [[[0, 0], [1, 0]], [[0, 0], [0, 1]]] },
    { n: '큰 상자', w: 4, v: 4, col: '#b06f3c', rots: [[[0, 0], [1, 0], [0, 1], [1, 1]]] },
    { n: 'ㄱ자 상자', w: 3, v: 3, col: '#79a957', rots: L4 },
    { n: '막대 상자', w: 3, v: 3, col: '#5b97c4', rots: [[[0, 0], [1, 0], [2, 0]], [[0, 0], [0, 1], [0, 2]]] },
    { n: 'ㅗ자 상자', w: 4, v: 4, col: '#c46b95', rots: T4 },
    { n: '액체 탱크', w: 3, v: 4, col: '#86b4c6', rots: [[[0, 0], [1, 0]]], liq: 2, sp: 1, d: '물이 낮은 쪽으로 쏠려서 더 기울게 해요' },
    { n: '풍선 상자', w: -1, v: 2, col: '#efcf62', rots: [[[0, 0]]], sp: 1, d: '무게 −1! 놓은 쪽을 살짝 들어 올려요' },
    { n: '닻', w: 5, v: 3, col: '#59606c', rots: [[[0, 0]]], fix: 1, sp: 1, d: '아주 무거워요(5). 절대 미끄러지지 않아요' },
    { n: '동물 상자', w: 3, v: 4, col: '#d3ad78', rots: [[[0, 0], [1, 0]], [[0, 0], [1, 0]]], ani: 2, sp: 1, d: '양(무게 2)이 차례가 끝날 때마다 반대쪽 칸으로 폴짝!' },
  ];
  const DECKW = [14, 14, 9, 11, 10, 8, 8, 8, 8, 7];

  /* ======================= routes & weather ======================= */
  const ROUTES = [
    { k: 'calm', n: '잔잔한 하늘', d: '바람이 약하고 난기류도 작아요. 처음 하기 좋아요.', T: 1, sl: 15 },
    { k: 'gust', n: '돌풍 계곡', d: '3차례마다 센 돌풍이 불어요(미리 보여요).', T: 2, sl: 15 },
    { k: 'zig', n: '갈지자 해협', d: '바람 방향이 차례마다 반대로 바뀌어요.', T: 2, sl: 15 },
    { k: 'storm', n: '폭풍 전선', d: '바람이 점점 세지고 난기류가 커요.', T: 4, sl: 15 },
    { k: 'ash', n: '화산재 구름', d: '2차례마다 화산재가 기구 위 한쪽에 쌓여 무거워져요.', T: 2, sl: 15 },
    { k: 'ice', n: '얼음 구름', d: '상자가 얼어 미끄러워요(11°부터 미끄러짐).', T: 2, sl: 11 },
  ];
  function hsh(a, b) {
    let h = (Math.imul(a | 0, 0x27d4eb2d) ^ Math.imul((b | 0) + 0x165667b1, 0x9e3779b1)) >>> 0;
    h = Math.imul(h ^ (h >>> 16), 0x85ebca6b) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  // weather for turn t: w = steady wind (+ = blows to the right), gu = known gust, ash = side (−1 left / 1 right / 0)
  function wx(R, sd, t, ashNow) {
    const r = (k) => hsh(sd + k * 7919, t * 31 + k);
    const soft = () => { const q = r(1); return q < 0.45 ? 0 : (r(2) < 0.5 ? -1 : 1); };
    let w = 0, gu = 0, ash = 0;
    if (R === 0) w = soft();
    else if (R === 1) { w = soft(); if (t % 3 === 2) gu = (r(3) < 0.5 ? -1 : 1) * (r(4) < 0.5 ? 4 : 5); }
    else if (R === 2) { const d0 = hsh(sd, 77) < 0.5 ? -1 : 1; w = (t % 2 ? d0 : -d0) * (r(5) < 0.55 ? 2 : 3); }
    else if (R === 3) {
      const s0 = hsh(sd, 999) < 0.5 ? -1 : 1;
      w = s0 * Math.min(4, 1 + ((t / 4) | 0)) - (r(1) < 0.25 ? s0 : 0);
      if (r(2) < 0.3) gu = (r(3) < 0.5 ? -1 : 1) * 3;
    } else if (R === 4) { w = soft(); if (t % 2 === 1) ash = r(6) < 0.5 ? -1 : 1; }
    else w = soft();
    if (ash && ashNow && ashNow[ash < 0 ? 0 : 1] >= ASHMAX) ash = 0;
    return { w, gu, ash, T: ROUTES[R].T, sl: ROUTES[R].sl };
  }

  /* ======================= grid & config ======================= */
  const BLOCKED = (c, r) => r === 0 && (c === 0 || c === GW - 1);
  function blankGrid() { let s = ''; for (let i = 0; i < NC; i++) s += BLOCKED(i % GW, (i / GW) | 0) ? '#' : '.'; return s; }
  // decoded config: g = Int array (−1 empty, −2 blocked, else piece id), P = pieces {t,o,f,x,c:[[c,r]..]}
  function dec(o) {
    const g = new Array(NC), P = [];
    for (let k = 0; k < o.pc.length; k += 4) P.push({ t: +o.pc[k], o: +o.pc[k + 1], f: o.pc[k + 2] === '1' ? 1 : 0, x: o.pc[k + 2] === 'x', d: o.pc[k + 3], c: [] });
    for (let i = 0; i < NC; i++) {
      const ch = o.g[i];
      if (ch === '.') g[i] = -1; else if (ch === '#') g[i] = -2;
      else { const id = B64.indexOf(ch); g[i] = id; P[id].c.push([i % GW, (i / GW) | 0]); }
    }
    return { g, P, th: o.th / 1000, bl: o.bl.slice(), pu: o.pu, ash: o.ash.slice() };
  }
  function encG(g) { let s = ''; for (let i = 0; i < NC; i++) s += g[i] === -1 ? '.' : g[i] === -2 ? '#' : B64[g[i]]; return s; }
  function encP(P) { let s = ''; for (const p of P) s += p.t + '' + p.o + (p.x ? 'x' : p.f) + p.d; return s; }
  // door tag: 'L'/'R' crates score +2 when their centre sits on that half of the hold ('-' = any)
  function doorOK(p) { if (p.x || p.d === '-') return false; let cx = 0; for (const q of p.c) cx += q[0] - 4; return p.d === 'L' ? cx < 0 : cx > 0; }
  const delivered = (p) => !p.x && (p.d === '-' || doorOK(p));
  const preOf = (s) => ({ g: s.g, pc: s.pc, th: s.th, bl: s.bl.slice(), pu: s.pu, ash: s.ash.slice() });

  function shapeOf(ty, rot) { const R = TYPES[ty].rots; return R[((rot % R.length) + R.length) % R.length]; }
  function widthOf(cells) { let m = 0; for (const q of cells) m = Math.max(m, q[0]); return m + 1; }
  // hard drop: lowest row the piece reaches when dropped straight down at column col; −1 = does not fit
  function dropRow(g, cells, col) {
    for (const q of cells) if (col + q[0] < 0 || col + q[0] >= GW) return -1;
    const free = (r0) => {
      for (const q of cells) { const c = col + q[0], r = r0 + q[1]; if (r < 0) return false; if (r < GH && g[r * GW + c] !== -1) return false; }
      return true;
    };
    let r0 = GH;
    if (!free(r0)) return -1;
    while (free(r0 - 1)) r0--;
    for (const q of cells) if (r0 + q[1] >= GH) return -1;
    return r0;
  }
  function placements(g, ty) {
    const out = [], R = TYPES[ty].rots;
    for (let rot = 0; rot < R.length; rot++) {
      const w = widthOf(R[rot]);
      for (let col = 0; col + w <= GW; col++) { const r = dropRow(g, R[rot], col); if (r >= 0) out.push({ rot, col, row: r }); }
    }
    return out;
  }

  /* ======================= simulation ======================= */
  const EV0 = { pl: null, tr: '', w: 0, gu: 0, u: 0, ash: 0, sl: 18, o: 0 };
  function simNew(cfg, ev, quiet) {
    const S = {
      g: cfg.g.slice(), P: cfg.P.map((p) => ({ t: p.t, o: p.o, f: p.f, x: p.x, d: p.d, c: p.c.map((q) => q.slice()), sl: 0, mv: 0 })),
      th: cfg.th, om: 0, t: 0, bl: cfg.bl.slice(), pu0: cfg.pu, pu1: cfg.pu, bx: cfg.pu * PUMP, ash: cfg.ash.slice(),
      ev: ev || EV0, slr: (ev ? ev.sl : 18) * DEG, peak: Math.abs(cfg.th), pks: cfg.th, fall: [], log: [], quiet: !!quiet,
      slCd: 0, lastMove: -9, newId: -1, done: false, crash: false, f: { bag: 0, gust: 0, turb: 0, hop: 0, ash: 0 }, nslide: 0,
    };
    const e = S.ev;
    if (e.pl) {
      const ty = e.pl[0], cells = shapeOf(ty, e.pl[1]), col = e.pl[2], r0 = dropRow(S.g, cells, col);
      const id = S.P.length;
      const p = { t: ty, o: e.o | 0, f: TYPES[ty].ani ? (e.pl[1] & 1) : 0, x: false, d: e.pl[3] || '-', c: [], sl: 0, mv: 0 };
      for (const q of cells) { const c = col + q[0], r = r0 + q[1]; p.c.push([c, r]); S.g[r * GW + c] = id; }
      p.c.sort((a, b) => a[1] - b[1] || a[0] - b[0]);
      S.P.push(p); S.newId = id;
    }
    if (e.tr === 'gL') S.pu1 = S.pu0 - 1; else if (e.tr === 'gR') S.pu1 = S.pu0 + 1;
    for (const p of S.P) if (!p.x && TYPES[p.t].liq) p.sl = clamp(-KSL * dsin(S.th), -SLMAX, SLMAX);
    agg(S);
    return S;
  }
  // aggregates: total mass M, first moments Sx, Sy, inertia I about B, tanks list, stiffness & damping
  function agg(S) {
    let M = M0, Sx = 0, Sy = M0 * Y0, I = I0 + M0 * (Y0 - HB) * (Y0 - HB);
    const add = (m, x, y) => { M += m; Sx += m * x; Sy += m * y; I += Math.abs(m) * (x * x + (y - HB) * (y - HB)); };
    for (let k = 0; k < 2; k++) {
      const sg = k ? 1 : -1;
      if (S.bl[k]) add(S.bl[k] * BAGW, sg * BAGX, BAGY);
      if (S.ash[k]) add(S.ash[k] * ASHW, sg * ASHX, ASHY);
    }
    const tanks = [];
    for (const p of S.P) {
      if (p.x) continue;
      const T = TYPES[p.t], n = p.c.length, base = (T.w - (T.liq || 0) - (T.ani || 0)) / n;
      let cx = 0, cy = 0;
      for (const q of p.c) { const x = q[0] - 4, y = q[1] + 0.5; add(base, x, y); cx += x; cy += y; }
      cx /= n; cy /= n;
      if (T.liq) { add(T.liq, cx, cy - 0.15); tanks.push(p); }
      if (T.ani) { const q = p.c[p.f] || p.c[0]; add(T.ani, q[0] - 4, q[1] + 0.45); }
    }
    S.M = M; S.Sx = Sx; S.Sy = Sy; S.I = I; S.tanks = tanks;
    S.k = GRAV * (M * HB - Sy);
    S.c = 2 * ZETA * Math.sqrt(I * Math.max(S.k, 400));
  }
  function liqMass(p) { return TYPES[p.t].liq; }
  function torque(S, th, om) {
    let sx = S.Sx;
    for (const p of S.tanks) sx += liqMass(p) * p.sl;
    return -GRAV * ((sx - S.M * S.bx) * dcos(th) - (S.Sy - S.M * HB) * dsin(th)) - S.ev.w * WU - S.c * om;
  }
  function logE(S, e) { if (!S.quiet) { e.t = S.t; S.log.push(e); } }

  function topFree(S, p, id) {
    for (const q of p.c) { if (q[1] + 1 >= GH) continue; const v = S.g[(q[1] + 1) * GW + q[0]]; if (v >= 0 && v !== id) return false; }
    return true;
  }
  function slidePass(S, dir) {
    const ids = [];
    for (let i = 0; i < S.P.length; i++) { const p = S.P[i]; if (!p.x && !TYPES[p.t].fix) ids.push(i); }
    const lead = (p) => { let m = dir < 0 ? 99 : -99; for (const q of p.c) m = dir < 0 ? Math.min(m, q[0]) : Math.max(m, q[0]); return dir < 0 ? m : -m; };
    ids.sort((a, b) => lead(S.P[a]) - lead(S.P[b]) || a - b);
    let moved = false;
    for (const id of ids) {
      const p = S.P[id];
      if (p.x || !topFree(S, p, id)) continue;
      let blocked = false, off = false;
      for (const q of p.c) {
        const c = q[0] + dir, r = q[1];
        if (c < 0 || c >= GW) { if (r <= WALLR) { blocked = true; break; } off = true; continue; }
        const v = S.g[r * GW + c];
        if (v !== -1 && v !== id) { blocked = true; break; }
      }
      if (blocked) continue;
      for (const q of p.c) S.g[q[1] * GW + q[0]] = -1;
      if (off) {
        p.x = true;
        S.fall.push(id);
        logE(S, { k: 'fall', id, ty: p.t, o: p.o, c: p.c.map((q) => q.slice()), d: dir });
      } else {
        for (const q of p.c) { q[0] += dir; S.g[q[1] * GW + q[0]] = id; }
        p.mv++;
        logE(S, { k: 'slide', id, d: dir });
      }
      moved = true;
    }
    if (moved) gravity(S);
    return moved;
  }
  function gravity(S) {
    for (let guard = 0; guard < 40; guard++) {
      let ch = false;
      for (let id = 0; id < S.P.length; id++) {
        const p = S.P[id];
        if (p.x) continue;
        let ok = true;
        for (const q of p.c) { const r = q[1] - 1; if (r < 0) { ok = false; break; } const v = S.g[r * GW + q[0]]; if (v !== -1 && v !== id) { ok = false; break; } }
        if (!ok) continue;
        for (const q of p.c) S.g[q[1] * GW + q[0]] = -1;
        for (const q of p.c) { q[1]--; S.g[q[1] * GW + q[0]] = id; }
        ch = true;
      }
      if (!ch) break;
    }
  }
  function simStep(S) {
    if (S.done) return false;
    const e = S.ev, t = S.t, F = S.f;
    let dirty = false;
    if (!F.bag && (e.tr === 'bL' || e.tr === 'bR') && t >= 0.15) { F.bag = 1; const k = e.tr === 'bL' ? 0 : 1; if (S.bl[k] > 0) S.bl[k]--; dirty = true; logE(S, { k: 'bag', s: k }); }
    if (S.pu1 !== S.pu0) S.bx = (S.pu0 + (S.pu1 - S.pu0) * clamp(t / 0.6, 0, 1)) * PUMP;
    if (!F.gust && e.gu && t >= 0.35) { F.gust = 1; S.om += -e.gu * JU / S.I; logE(S, { k: 'gust', d: e.gu }); }
    if (!F.turb && e.u && t >= 0.9) { F.turb = 1; S.om += -e.u * JU / S.I; logE(S, { k: 'turb', d: e.u }); }
    if (!F.hop && t >= 1.3) {
      F.hop = 1;
      for (let id = 0; id < S.P.length; id++) { const p = S.P[id]; if (!p.x && TYPES[p.t].ani && id !== S.newId) { p.f = 1 - p.f; dirty = true; logE(S, { k: 'hop', id }); } }
    }
    if (!F.ash && e.ash && t >= 1.6) { F.ash = 1; const k = e.ash < 0 ? 0 : 1; if (S.ash[k] < ASHMAX) { S.ash[k]++; dirty = true; logE(S, { k: 'ash', s: k }); } }
    if (dirty) agg(S);
    // liquid follows the low side with a short lag
    if (S.tanks.length) { const tg = clamp(-KSL * dsin(S.th), -SLMAX, SLMAX); for (const p of S.tanks) p.sl += (tg - p.sl) * 0.09; }
    const a = torque(S, S.th, S.om) / S.I;
    S.om += a * DT; S.th += S.om * DT; S.t += DT;
    const ab = Math.abs(S.th);
    if (ab > S.peak) { S.peak = ab; S.pks = S.th; }
    if (ab > CRASH) { S.crash = true; S.done = true; logE(S, { k: 'crash' }); return false; }
    if (ab > S.slr) {
      S.slCd -= DT;
      if (S.slCd <= 0) {
        const mv = slidePass(S, S.th > 0 ? -1 : 1);
        S.slCd = mv ? 0.16 : 0.06;
        if (mv) { agg(S); S.lastMove = S.t; S.nslide++; }
      }
    } else S.slCd = 0;
    if (S.t > 1.9 && S.t - S.lastMove > 0.3 && Math.abs(S.om) < 0.0025 && Math.abs(a) < 0.02) S.done = true;
    if (S.t >= 9) S.done = true;
    return !S.done;
  }
  function simRun(cfg, ev, quiet) { const S = simNew(cfg, ev, quiet); while (simStep(S)); return S; }
  function cfgOfSim(S) { return { g: S.g, P: S.P, th: Math.round(S.th * 1000) / 1000, bl: S.bl, pu: S.pu1, ash: S.ash }; }

  /* ======================= game logic ======================= */
  const TKN = (n) => (n === 1 ? 3 : 2);
  function genDeck(D) {
    const out = [6, 7, 8, 9];
    const tot = DECKW.reduce((a, b) => a + b, 0);
    while (out.length < D) { let r = Math.random() * tot, k = 0; while (r >= DECKW[k]) { r -= DECKW[k]; k++; } out.push(k); }
    U.shuffle(out);
    if (TYPES[out[0]].sp) { const j = out.findIndex((v) => !TYPES[v].sp); if (j > 0) { const x = out[0]; out[0] = out[j]; out[j] = x; } }
    // door tags: about 7 in 10 crates want one side; the two sides come in equal numbers (shuffled)
    const nt = Math.round(D * 0.7) & ~1, tags = [];
    for (let k = 0; k < D; k++) tags.push(k < nt ? (k & 1 ? 'R' : 'L') : '-');
    U.shuffle(tags);
    return { dk: out.join(''), dd: tags.join('') };
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const R = opts.route == null || opts.route === 'r' ? U.rand(ROUTES.length) : clamp(+opts.route | 0, 0, ROUTES.length - 1);
    const D = clamp(+(opts.len || 16) | 0, 8, 24), dg = genDeck(D);
    return {
      n, nm: players.map((p, i) => (p && p.name) || i + 1 + '번'), R, sd: (Math.random() * 1e9) | 0, D, dk: dg.dk, dd: dg.dd,
      g: blankGrid(), pc: '', th: 0, bl: [NBAG, NBAG], pu: 0, ash: [0, 0],
      tk: Array(n).fill(TKN(n)), pe: Array(n).fill(0), t: 0, tmax: D + n * TKN(n) + 6, cur: 0, end: 0, cr: -1, sk: 0, seq: 0, last: null,
    };
  }
  function actor(s) { return s.end ? null : s.cur; }
  function weatherNow(s, t) { return wx(s.R, s.sd, t == null ? s.t : t, s.ash); }
  // the dock holds the first two crates of the remaining queue; the player loads either one
  const dockN = (s) => Math.min(2, s.dk.length);
  function dockType(s, j) { return j < s.dk.length ? +s.dk[j] : -1; }
  function dockDoor(s, j) { return j < s.dd.length ? s.dd[j] : '-'; }
  const cutAt = (str, j) => str.slice(0, j) + str.slice(j + 1);
  function trimOK(s, seat, k) {
    if (s.tk[seat] <= 0) return false;
    if (k === 'bL') return s.bl[0] > 0;
    if (k === 'bR') return s.bl[1] > 0;
    if (k === 'gL') return s.pu > -PUMAX;
    if (k === 'gR') return s.pu < PUMAX;
    return false;
  }
  function evFor(s, seat, a, u) {
    const W = weatherNow(s);
    const ev = { pl: null, tr: '', w: W.w, gu: W.gu, u: u || 0, ash: W.ash, sl: W.sl, o: seat };
    if (a.t === 'p') ev.pl = [dockType(s, a.j | 0), a.r | 0, a.c | 0, dockDoor(s, a.j | 0)]; else ev.tr = a.k;
    return ev;
  }
  function scoreOf(s, k, P) {
    P = P || dec(s).P;
    let v = 0;
    for (const p of P) if (p.o === k && !p.x) v += TYPES[p.t].v + (doorOK(p) ? 2 : 0);
    return v - 2 * s.pe[k];
  }
  function aboard(s) { let n = 0; for (let i = 0; i < s.pc.length; i += 4) if (s.pc[i + 2] !== 'x') n++; return n; }
  function deliveredN(s) { return dec(s).P.filter(delivered).length; }

  function dockFits(s, g) { for (let j = 0; j < dockN(s); j++) if (placements(g, dockType(s, j)).length) return true; return false; }
  function apply(s, seat, a) {
    if (s.end) throw new Error('game over');
    if (seat !== s.cur) throw new Error('not your turn');
    if (!a || (a.t !== 'p' && a.t !== 'tr')) throw new Error('bad action');
    const cfg = dec(s);
    if (a.t === 'p') {
      const j = a.j | 0;
      if (j < 0 || j >= dockN(s)) throw new Error('no crate');
      const ty = dockType(s, j);
      const R = TYPES[ty].rots, rot = a.r | 0;
      if (rot < 0 || rot >= R.length) throw new Error('bad rot');
      if (dropRow(cfg.g, R[rot], a.c | 0) < 0) throw new Error('does not fit');
    } else if (!trimOK(s, seat, a.k)) throw new Error('trim not allowed');
    const W = weatherNow(s);
    const u = W.T > 0 ? Math.round((Math.random() * 2 - 1) * W.T * 10) / 10 : 0;
    const ev = evFor(s, seat, a, u);
    const pre = preOf(s);
    const S = simRun(cfg, ev, true);
    s.g = encG(S.g); s.pc = encP(S.P); s.th = Math.round(S.th * 1000); s.bl = S.bl.slice(); s.pu = S.pu1; s.ash = S.ash.slice();
    if (a.t === 'p') { s.dk = cutAt(s.dk, a.j | 0); s.dd = cutAt(s.dd, a.j | 0); } else s.tk[seat]--;
    s.pe[seat] += S.fall.length;
    s.t++; s.seq++;
    s.last = { id: s.seq, s: seat, pre, ev, fl: S.fall.length, cr: S.crash ? 1 : 0, sk: 0, pk: Math.round(S.peak / DEG) };
    if (S.crash) { s.end = 2; s.cr = seat; return s; }
    const g2 = dec(s).g;
    while (s.dk.length && !dockFits(s, g2)) { s.dk = s.dk.slice(1); s.dd = s.dd.slice(1); s.sk++; s.last.sk++; }
    if (!s.dk.length || s.t >= s.tmax) { s.end = 1; return s; }
    s.cur = (s.cur + 1) % s.n;
    return s;
  }

  const starNeed = (D) => [Math.ceil(D * 0.6), D - 2, D];
  function stars(s) {
    if (s.end === 2) return 0;
    const a = deliveredN(s), q = starNeed(s.D);
    return a >= q[2] ? 3 : a >= q[1] ? 2 : a >= q[0] ? 1 : 0;
  }
  function result(s) {
    if (!s.end) return null;
    const nm = (k) => (s.nm && s.nm[k]) || k + 1 + '번';
    if (s.n === 1) {
      const a = deliveredN(s), q = starNeed(s.D);
      if (s.end === 2) return { winners: [], title: '💥 추락했어요…', text: '비행선이 너무 기울어 떨어졌어요. 무거운 상자는 낮게, 가운데 가까이!' };
      const st = stars(s);
      const need = '(★ ' + q[0] + ' · ★★ ' + q[1] + ' · ★★★ ' + q[2] + '개)';
      if (!st) return { winners: [], title: '배달 부족…', text: '제대로 배달한 상자 ' + a + '/' + s.D + '개 ' + need };
      return { winners: [0], title: '★★★'.slice(0, st) + '☆☆☆'.slice(0, 3 - st) + ' 도착!', text: '제대로 배달한 상자 ' + a + '/' + s.D + '개 ' + need };
    }
    const rows = []; for (let k = 0; k < s.n; k++) rows.push({ k, v: scoreOf(s, k) });
    const alive = rows.filter((o) => !(s.end === 2 && o.k === s.cr));
    const best = Math.max(...alive.map((o) => o.v));
    const winners = alive.filter((o) => o.v === best).map((o) => o.k);
    const order = alive.slice().sort((a, b) => b.v - a.v);
    const txt = order.map((o) => nm(o.k) + ' ' + o.v + '점').join(' · ') + (s.end === 2 ? ' · ' + nm(s.cr) + ' 추락' : '');
    if (s.end === 2) return { winners, title: '💥 ' + nm(s.cr) + ' 차례에 추락!', text: txt };
    return { winners, title: winners.length > 1 ? '공동 1등! 무사히 도착' : '무사히 도착 · ' + nm(winners[0]) + ' 승리', text: txt };
  }

  /* ======================= AI ======================= */
  function holesUnder(g, cells, col, row) {
    let h = 0;
    for (const q of cells) {
      const c = col + q[0], r = row + q[1];
      if (cells.some((o) => o[0] === q[0] && o[1] === q[1] - 1)) continue;    // own cell below
      for (let rr = r - 1; rr >= 0; rr--) { const v = g[rr * GW + c]; if (v === -1) h++; else break; }
    }
    return h;
  }
  function judge(S) { return { crash: S.crash, fall: S.fall.length, peak: S.peak / DEG, fin: Math.abs(S.th) / DEG, S }; }
  function evalAct(s, seat, a, lv, cfg) {
    const W = weatherNow(s);
    const r0 = judge(simRun(cfg, evFor(s, seat, a, 0), true));
    let sc = 0;
    if (r0.crash) sc -= 100000;
    sc -= r0.fall * (lv === 1 ? 40 : 70);
    let worst = r0;
    if (W.T > 0 && lv >= 2) {
      for (const u of [-W.T, W.T]) {
        const r = judge(simRun(cfg, evFor(s, seat, a, u), true));
        if (r.crash && !worst.crash) worst = r; else if (!worst.crash && (r.fall > worst.fall || (r.fall === worst.fall && r.peak > worst.peak))) worst = r;
      }
      if (worst.crash && !r0.crash) sc -= lv === 3 ? 4000 : 900;
      sc -= (worst.fall - r0.fall) * (lv === 3 ? 25 : 12);
    }
    const sl = W.sl;
    sc -= lv === 1 ? r0.fin * 0.8 : r0.fin * 0.8 + r0.fin * r0.fin * 0.14;
    sc -= Math.max(0, r0.peak - SAFE) * (lv === 1 ? 1 : 3);
    if (lv >= 2) {   // righting margin: how far the centre of mass sits below the balance point (top-heavy = fragile)
      const S = r0.S, rm = S.M * HB - S.Sy;
      sc -= Math.max(0, 45 - rm) * 1.2;
    }
    if (lv === 3) sc -= Math.max(0, worst.peak - (sl - 1)) * 4;
    if (a.t === 'p') {
      const ty = dockType(s, a.j | 0), cells = shapeOf(ty, a.r), row = dropRow(cfg.g, cells, a.c);
      sc += TYPES[ty].v * 12;
      const np = r0.S.newId >= 0 ? r0.S.P[r0.S.newId] : null;
      if (np && doorOK(np)) sc += s.n === 1 ? 40 : lv === 1 ? 14 : 24;
      else if (s.n === 1 && np && !np.x && np.d === '-') sc += 40;
      const hol = holesUnder(cfg.g, cells, a.c, row);
      let top = 0; for (const q of cells) top = Math.max(top, row + q[1]);
      sc -= hol * (lv === 1 ? 2 : 7);
      if (lv >= 2) sc -= top * 1.6 + (top > WALLR ? 6 : 0);
    } else sc -= s.n === 1 ? 14 : 26;
    return { sc, r0, worst };
  }
  function candidates(s, cfg) {
    const out = [];
    for (let j = 0; j < dockN(s); j++) {
      if (j === 1 && s.dk[0] === s.dk[1] && s.dd[0] === s.dd[1]) break;
      for (const p of placements(cfg.g, dockType(s, j))) out.push({ t: 'p', j, r: p.rot, c: p.col });
    }
    return out;
  }
  // best option of whoever moves next, after candidate action a (nominal outcome S) — used by the 어려움 AI
  function nextQuality(s, seat, a, S) {
    const ns = Object.assign({}, s, { g: encG(S.g), pc: encP(S.P), th: Math.round(S.th * 1000), bl: S.bl.slice(), pu: S.pu1, ash: S.ash.slice(), t: s.t + 1 });
    if (a.t === 'p') { ns.dk = cutAt(s.dk, a.j | 0); ns.dd = cutAt(s.dd, a.j | 0); } else { ns.tk = s.tk.slice(); ns.tk[seat]--; }
    ns.cur = (seat + 1) % s.n;
    if (!ns.dk.length) return 0;
    const cfg = dec(ns), cands = candidates(ns, cfg);
    let best = cands.length ? -1e9 : -10;
    for (const c of cands) { const e = evalAct(ns, ns.cur, c, 2, cfg); if (e.sc > best) best = e.sc; }
    if (best < 0 && s.n > 1) for (const k of ['bL', 'bR', 'gL', 'gR']) if (trimOK(ns, ns.cur, k)) { const e = evalAct(ns, ns.cur, { t: 'tr', k }, 2, cfg); if (e.sc > best) best = e.sc; }
    return best;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const cfg = dec(s), cands = candidates(s, cfg);
    const trims = ['bL', 'bR', 'gL', 'gR'].filter((k) => trimOK(s, seat, k)).map((k) => ({ t: 'tr', k }));
    let list = cands.map((a) => Object.assign(evalAct(s, seat, a, lv, cfg), { a }));
    if (lv >= 2 || !list.length || list.every((o) => o.r0.crash)) list = list.concat(trims.map((a) => Object.assign(evalAct(s, seat, a, lv, cfg), { a })));
    if (!list.length) return trims[0] || { t: 'p', r: 0, c: 0 };
    if (lv === 3) {
      list.sort((a, b) => b.sc - a.sc);
      for (const o of list.slice(0, 7)) {
        if (o.r0.crash) continue;
        const nq = nextQuality(s, seat, o.a, o.r0.S);
        if (s.n === 1) o.sc += 0.35 * Math.max(-200, nq);
        else if (nq < -120) o.sc += Math.min(320, -nq * 0.4);    // the next player is left with only bad options
        else o.sc -= 0.15 * clamp(nq, -120, 220);                  // what the next player can make of what we leave
      }
    }
    for (const o of list) o.sc += lv === 1 ? (Math.random() - 0.5) * 70 : lv === 2 ? (Math.random() - 0.5) * 30 : 0;
    if (lv === 1 && Math.random() < 0.2) {
      const ok = list.filter((o) => !o.r0.crash && o.a.t === 'p');
      if (ok.length) return ok[(Math.random() * ok.length) | 0].a;
    }
    list.sort((a, b) => b.sc - a.sc);
    return list[0].a;
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 1000 : lv === 3 ? 600 : 800; }

  /* ======================= view ======================= */
  const PLAY = 1.6, DROP = 0.32;
  const ZC = { ok: '#5fd3a0', warn: '#e8c04e', bad: '#ee6a55', dead: '#b8283a' };
  function mkCanvas(w, h, dpr) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w * dpr)); c.height = Math.max(1, Math.ceil(h * dpr)); const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); return [c, x]; }
  function rr(x, X, Y, w, h, r) { r = Math.min(r, w / 2, h / 2); x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + w, Y, X + w, Y + h, r); x.arcTo(X + w, Y + h, X, Y + h, r); x.arcTo(X, Y + h, X, Y, r); x.arcTo(X, Y, X + w, Y, r); x.closePath(); }
  function rng(seed) { let a = seed >>> 0 || 1; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const FONT = (px, w) => (w || 600) + ' ' + px + 'px "IBM Plex Sans KR", system-ui, sans-serif';
  const MONO = (px, w) => (w || 600) + ' ' + px + 'px "IBM Plex Mono", ui-monospace, monospace';
  const DISP = (px) => px + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const zoneCol = (deg, sl) => { const a = Math.abs(deg); return a < SAFE ? ZC.ok : a < sl ? ZC.warn : a < 30 ? ZC.bad : ZC.dead; };
  const angTxt = (deg) => { const a = Math.round(Math.abs(deg)); return a === 0 ? '0°' : (deg > 0 ? '왼 ' : '오 ') + a + '°'; };
  const SKY = [
    ['#1b2547', '#4e5f9a', '#e9a57f'], ['#1f2c40', '#5d7d93', '#d6a079'], ['#162a42', '#3c6a8f', '#93bdd2'],
    ['#100d1f', '#29223f', '#4a4565'], ['#241614', '#5f3426', '#b9703f'], ['#1b304a', '#6f98b8', '#d8e9f2'],
  ];

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, LY = null, bg = null, bgKey = '', cloudSpr = [], clouds = [];
    let anim = null, busy = false, stopLoop = null, safety = 0, shownSeq = -1, waitSeq = -1, waitUntil = 0, frame = 0, lastNow = 0;
    let snap = null;                 // sim object built from the current state (for drawing when idle)
    let sel = null, pv = null, pvKey = '', drag = null, trimOpen = false, selSeq = -1, flash = 0;
    const vis = new Map();           // piece id → {ox, oy, c0, r0, hop, f}
    const parts = [];                // crates falling overboard
    const fx = [];                   // little puffs (ash, bag)
    const anyLocal = api.players.some((p, i) => api.canAct(i));
    const pcol = (k) => (api.players[k] && api.players[k].color) || L.COLORS[k % L.COLORS.length];
    const pname = (k) => (api.players[k] && api.players[k].name) || (st && st.nm && st.nm[k]) || k + 1 + '번';

    /* --- DOM: bottom bar, hint, trim panel, spotlight anchors --- */
    const BS = { minHeight: '48px', minWidth: '44px', padding: '4px 2px', fontSize: '14px', whiteSpace: 'nowrap' };
    const hud = L.h('div', { class: 'hud bottom as-hud', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px' } });
    const mk = (cls, txt, fl, fn, extra) => L.h('button', { class: cls, style: Object.assign({}, BS, { flex: fl + ' 1 0' }, extra || {}), text: txt, onclick: fn });
    const bL = mk('btn sm ghost as-left', '◀', 0.72, () => nudge(-1), { fontSize: '17px' });
    const bR = mk('btn sm ghost as-right', '▶', 0.72, () => nudge(1), { fontSize: '17px' });
    const bRot = mk('btn sm ghost as-rot', '⟳ 돌리기', 1.12, rotate);
    const bTrim = mk('btn sm ghost as-trim', '⚖ 조정', 1.08, toggleTrim);
    const bGo = mk('btn primary as-go', '싣기', 1.45, onGo, { fontSize: '16px' });
    hud.append(bL, bR, bRot, bTrim, bGo);
    const hint = L.h('div', { class: 'as-hint', style: { position: 'absolute', left: '8px', right: '8px', textAlign: 'center', fontSize: '12.5px', lineHeight: '18px', color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', pointerEvents: 'none', textShadow: '0 1px 2px rgba(0,0,0,.7)' } });
    const trimBox = L.h('div', { class: 'panel as-trimbox', style: { position: 'absolute', left: '10px', right: '10px', display: 'none', flexDirection: 'column', gap: '6px', padding: '8px', zIndex: 5, background: 'var(--surface)', border: '1px solid rgba(227,174,69,.45)', borderRadius: '14px', boxShadow: '0 8px 24px rgba(0,0,0,.45)' } });
    if (anyLocal) root.append(hud, trimBox);
    root.append(hint);
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: x + 'px', top: y + 'px', width: Math.max(0, w) + 'px', height: Math.max(0, h) + 'px' });
    const spShip = spot('as-ship'), spGauge = spot('as-gauge'), spDock = spot('as-dock'), spWx = spot('as-wx'), spHold = spot('as-hold'), spChips = spot('as-chips');
    const setBusy = (v) => { if (busy !== v) { busy = v; api.setBusy(v); updateHud(); } };

    function myTurn() { const a = st && actor(st); return a != null && api.canAct(a); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function canInput() { return st && !st.end && myTurn() && !locked() && !busy && !anim; }
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; closeTrim(); api.act(a); updateHud(); }

    /* --- layout --- */
    function layout() {
      if (!st) return;
      const W = cv.w, H = cv.h;
      const hudH = anyLocal ? 64 : 0, chipH = 38, wxH = 24, dockH = 62, hintH = 20;
      const wxY = 4 + chipH + 4, sceneTop = wxY + wxH + 4;
      const dockY = H - hudH - dockH - 4, hintY = dockY - hintH - 2;
      const gR = Math.max(30, Math.min(46, W * 0.11, (hintY - sceneTop) * 0.12));
      const gY = sceneTop + gR + 8;
      const shipTop = gY + 14, shipBot = hintY - 4;
      const availH = shipBot - shipTop;
      const u = Math.max(12, Math.min((W - 12) / 15.2, availH / 12.9));
      const bx = W / 2, by = shipTop + 8.6 * u + Math.max(0, (availH - 12.9 * u) / 2);
      LY = { W, H, u, bx, by, hudH, chipH, wxY, wxH, dockY, dockH, hintY, sceneTop, gR, gX: W / 2, gY, shipTop, shipBot };
      hint.style.top = hintY + 'px';
      trimBox.style.bottom = (hudH + 4) + 'px';
      place(spShip, bx - 6.2 * u, by - 8.6 * u, 12.4 * u, 12.6 * u);
      place(spHold, bx - 4.6 * u, by - (6 - HB) * u - 2, 9.2 * u, 6.9 * u);
      place(spGauge, W / 2 - gR - 70, sceneTop, gR * 2 + 140, gR + 22);
      place(spDock, 4, dockY, W - 8, dockH);
      place(spWx, 4, wxY, W - 8, wxH);
      place(spChips, 4, 4, W - 8, chipH);
      bgKey = '';
      buildClouds();
    }
    function buildBg() {
      const key = LY.W + 'x' + LY.H + ':' + st.R;
      if (bgKey === key && bg) return;
      bgKey = key;
      const W = LY.W, H = LY.H, [c, x] = mkCanvas(W, H, cv.dpr), R = st.R, P = SKY[R], rnd = rng(R * 97 + 13);
      const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, P[0]); g.addColorStop(0.55, P[1]); g.addColorStop(1, P[2]);
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      const hz = LY.dockY;   // horizon features sit behind the dock panel
      if (R === 0) {
        const sg = x.createRadialGradient(W * 0.22, hz - 40, 4, W * 0.22, hz - 40, W * 0.5); sg.addColorStop(0, 'rgba(255,214,160,.75)'); sg.addColorStop(0.2, 'rgba(255,190,140,.25)'); sg.addColorStop(1, 'rgba(255,170,120,0)');
        x.fillStyle = sg; x.fillRect(0, 0, W, H);
        x.fillStyle = '#fff1d6'; x.beginPath(); x.arc(W * 0.22, hz - 40, 14, 0, 7); x.fill();
        hills(x, W, hz, '#3b3f6e', 46, rnd); hills(x, W, hz + 10, '#2b2e55', 30, rnd);
      } else if (R === 1) {
        x.fillStyle = '#4a2f2a'; cliff(x, 0, W * 0.2, H, hz, rnd, 1); x.fillStyle = '#3a2420'; cliff(x, W, W * 0.22, H, hz, rnd, -1);
      } else if (R === 2) {
        x.fillStyle = '#1d4a6a'; x.fillRect(0, hz - 26, W, H - hz + 26);
        x.strokeStyle = 'rgba(190,230,245,.25)'; x.lineWidth = 1.2;
        for (let k = 0; k < 26; k++) { const wx2 = rnd() * W, wy = hz - 20 + rnd() * (H - hz + 20), wl = 10 + rnd() * 24; x.beginPath(); x.moveTo(wx2, wy); x.quadraticCurveTo(wx2 + wl / 2, wy - 3, wx2 + wl, wy); x.stroke(); }
        hills(x, W, hz - 26, '#2c4b66', 18, rnd);
      } else if (R === 3) {
        x.fillStyle = 'rgba(20,16,36,.75)';
        for (let k = 0; k < 9; k++) { x.beginPath(); x.ellipse(rnd() * W, LY.sceneTop - 10 + rnd() * 50, 60 + rnd() * 60, 20 + rnd() * 14, 0, 0, 7); x.fill(); }
        hills(x, W, hz, '#1b1830', 26, rnd);
      } else if (R === 4) {
        x.fillStyle = '#2e1a16'; x.beginPath(); x.moveTo(W * 0.5, hz + 30); x.lineTo(W * 0.7, hz - 60); x.lineTo(W * 0.8, hz - 60); x.lineTo(W * 1.05, hz + 30); x.closePath(); x.fill();
        const lg = x.createRadialGradient(W * 0.75, hz - 60, 2, W * 0.75, hz - 60, 60); lg.addColorStop(0, 'rgba(255,140,50,.8)'); lg.addColorStop(1, 'rgba(255,90,30,0)');
        x.fillStyle = lg; x.fillRect(W * 0.5, hz - 130, W * 0.5, 140);
        x.fillStyle = 'rgba(60,40,36,.55)'; for (let k = 0; k < 7; k++) { x.beginPath(); x.arc(W * 0.75 - k * 14, hz - 80 - k * 26, 16 + k * 6, 0, 7); x.fill(); }
        hills(x, W, hz + 8, '#24130f', 20, rnd);
      } else {
        x.fillStyle = '#9fbcd2'; peaks(x, W, hz, 70, rnd); x.fillStyle = '#7d9db6'; peaks(x, W, hz + 12, 44, rnd);
      }
      bg = c;
    }
    function hills(x, W, base, col, amp, rnd) { x.fillStyle = col; x.beginPath(); x.moveTo(0, base + 200); let px = 0; x.lineTo(0, base - amp * rnd()); while (px < W) { px += 30 + rnd() * 40; x.lineTo(px, base - amp * (0.3 + 0.7 * rnd())); } x.lineTo(W, base + 200); x.closePath(); x.fill(); }
    function peaks(x, W, base, amp, rnd) { x.beginPath(); x.moveTo(0, base + 200); let px = -20; while (px < W + 20) { const w = 40 + rnd() * 50; x.lineTo(px + w / 2, base - amp * (0.5 + 0.5 * rnd())); x.lineTo(px + w, base - 6); px += w; } x.lineTo(W, base + 200); x.closePath(); x.fill(); x.fillStyle = 'rgba(255,255,255,.5)'; }
    function cliff(x, x0, w, H, hz, rnd, sg) { x.beginPath(); x.moveTo(x0, 0); let y = 0; while (y < H) { y += 20 + rnd() * 30; x.lineTo(x0 + sg * w * (0.4 + 0.6 * rnd()), y); } x.lineTo(x0, H); x.closePath(); x.fill(); }
    function buildClouds() {
      const dpr = cv.dpr; cloudSpr = [];
      for (let k = 0; k < 4; k++) {
        const w = 120 + k * 22, h = 54, [c, x] = mkCanvas(w, h, dpr), rnd = rng(k * 31 + 5);
        x.fillStyle = '#fff';
        for (let j = 0; j < 7; j++) { const cx = w * (0.18 + 0.64 * rnd()), cy = h * (0.45 + 0.25 * rnd()), r = h * (0.18 + 0.2 * rnd()); x.beginPath(); x.arc(cx, cy, r, 0, 7); x.fill(); }
        x.fillRect(w * 0.15, h * 0.62, w * 0.7, h * 0.18);
        cloudSpr.push({ c, w, h });
      }
      clouds = []; const rnd = rng(77);
      const cy0 = LY.gY + 16;
      for (let k = 0; k < 7; k++) clouds.push({ x: rnd() * LY.W, y: cy0 + rnd() * Math.max(10, LY.dockY - cy0 - 40), k: k % 4, z: k < 4 ? 0 : 1, s: 0.55 + rnd() * 0.6 });
    }

    /* --- geometry helpers (ship-local, y down, origin = balance point) --- */
    const X = (bx2) => bx2 * LY.u;
    const Yb = (by2) => (HB - by2) * LY.u;
    function toBody(px, py, th) {
      const dx = px - LY.bx, dy = py - LY.by, c = Math.cos(th), s2 = Math.sin(th);
      const lx = dx * c - dy * s2, ly = dx * s2 + dy * c;
      return { x: lx / LY.u, y: HB - ly / LY.u };
    }
    function toScreen(bx2, by2, th) {
      const lx = X(bx2), ly = Yb(by2), c = Math.cos(th), s2 = Math.sin(th);
      return { x: LY.bx + lx * c + ly * s2, y: LY.by - lx * s2 + ly * c };
    }

    /* --- current selection / preview --- */
    function dockCount() { return st ? dockN(st) : 0; }
    function ensureSel() {
      if (!st || st.end) { sel = null; return; }
      if (sel && selSeq === st.seq) return;
      selSeq = st.seq;
      const g = dec(st).g;
      let j = 0;
      if (!placements(g, dockType(st, 0)).length && dockCount() > 1) j = 1;
      sel = { j, rot: 0, col: 0 };
      centerCol(g);
      pvKey = '';
    }
    function centerCol(g) {
      const cells = shapeOf(dockType(st, sel.j), sel.rot), w = widthOf(cells);
      let best = -1, bd = 99;
      for (let c = 0; c + w <= GW; c++) { if (dropRow(g, cells, c) < 0) continue; const d = Math.abs(c + (w - 1) / 2 - 4); if (d < bd) { bd = d; best = c; } }
      sel.col = best >= 0 ? best : Math.max(0, Math.min(GW - w, Math.round(4 - (w - 1) / 2)));
    }
    function selCells() { return sel ? shapeOf(dockType(st, sel.j), sel.rot) : null; }
    function selValid() { if (!sel || !st) return false; const cells = selCells(); return dropRow(snap.g, cells, sel.col) >= 0; }
    function runPreview(a) {
      const W = weatherNow(st), cfg = dec(st), seat = st.cur;
      const one = (u) => { const S = simRun(cfg, evFor(st, seat, a, u), true); return { S, crash: S.crash, fall: S.fall.length, fin: S.th / DEG, pk: S.pks / DEG, door: S.newId >= 0 ? doorOK(S.P[S.newId]) && !S.P[S.newId].x : false }; };
      const r0 = one(0);
      let wr = r0;
      if (W.T > 0) for (const u of [-W.T, W.T]) { const r = one(u); if ((r.crash && !wr.crash) || (!wr.crash && (r.fall > wr.fall || (r.fall === wr.fall && Math.abs(r.pk) > Math.abs(wr.pk))))) wr = r; }
      return { r0, wr, T: W.T, sl: W.sl };
    }
    function preview() {
      if (!sel || !st || st.end || !myTurn()) { pv = null; return null; }
      const key = st.seq + ':' + sel.j + ':' + sel.rot + ':' + sel.col;
      if (key === pvKey) return pv;
      pvKey = key;
      pv = selValid() ? runPreview({ t: 'p', j: sel.j, r: sel.rot, c: sel.col }) : null;
      return pv;
    }

    /* --- HUD --- */
    function setDis(b, d) { b.disabled = !!d; b.style.opacity = d ? '0.45' : '1'; }
    function updateHud() {
      if (!st) return;
      const mine = canInput();
      if (mine) ensureSel();
      const p = mine ? preview() : null;
      setDis(bL, !mine); setDis(bR, !mine); setDis(bRot, !mine || !sel || TYPES[dockType(st, sel.j)].rots.length < 2);
      setDis(bTrim, !mine || st.tk[st.cur] <= 0);
      bTrim.textContent = '⚖ 조정 ' + (st.tk[st.cur] || 0);
      const ok = mine && selValid();
      setDis(bGo, !ok);
      bGo.textContent = !mine ? (st.end ? '끝' : '기다려요') : ok ? (p && p.r0.crash ? '💥 싣기' : '싣기 ✓') : '자리 없음';
      // hint line
      let t = '';
      if (st.end) t = st.end === 2 ? '💥 비행선이 추락했어요' : '🏁 목적지에 도착했어요!';
      else if (anim) t = anim.msg || '흔들흔들…';
      else if (!myTurn()) t = pname(st.cur) + ' 차례 — ' + (api.players[st.cur] && api.players[st.cur].ai ? '생각 중…' : '기다리는 중');
      else if (!sel || !selValid()) t = '여기엔 안 들어가요. ◀ ▶로 옮기거나 다른 상자를 골라요';
      else if (p) {
        const r = p.r0, w = p.wr;
        if (r.crash) t = '💥 이대로면 추락해요! 다른 자리를 골라요';
        else if (r.fall) t = '⚠ 상자 ' + r.fall + '개가 떨어져요 (−' + 2 * r.fall + '점)';
        else if (w.crash) t = '⚠ 난기류가 나쁘면 추락할 수 있어요 · 예상 ' + angTxt(r.fin);
        else if (w.fall) t = '⚠ 난기류가 나쁘면 상자가 떨어질 수 있어요 · 예상 ' + angTxt(r.fin);
        else t = '예상 ' + angTxt(r.fin) + ' · 흔들림 최대 ' + Math.round(Math.max(Math.abs(r.pk), Math.abs(w.pk))) + '°' + (r.door ? ' · 문 보너스 +2' : '');
      }
      hint.textContent = t;
      hint.style.color = p && (p.r0.crash || p.r0.fall) ? '#ffb4a6' : 'var(--ink)';
      if (trimOpen && !mine) closeTrim();
    }
    function nudge(d) {
      if (!canInput() || !sel) return;
      const w = widthOf(selCells());
      const c = clamp(sel.col + d, 0, GW - w);
      if (c === sel.col) { api.buzz(15); return; }
      sel.col = c; api.sfx('tick'); api.buzz(5); updateHud();
    }
    function rotate() {
      if (!canInput() || !sel) return;
      const n = TYPES[dockType(st, sel.j)].rots.length;
      if (n < 2) return;
      sel.rot = (sel.rot + 1) % n;
      const w = widthOf(selCells());
      sel.col = clamp(sel.col, 0, GW - w);
      api.sfx('click'); api.buzz(6); updateHud();
    }
    function pickDock(j) {
      if (!canInput() || j >= dockCount()) return;
      if (sel.j === j) return;
      sel.j = j; sel.rot = 0; centerCol(snap.g);
      api.sfx('card'); api.buzz(8); updateHud();
    }
    function onGo() {
      if (!canInput() || !sel || !selValid()) return;
      const p = preview();
      if (p && p.r0.crash) {
        if (flash > performance.now()) { /* second tap within 2 s: really do it */ }
        else { flash = performance.now() + 2000; api.toast('이대로면 추락해요! 정말이면 한 번 더 눌러요'); api.buzz(40); return; }
      }
      api.buzz(14);
      send({ t: 'p', j: sel.j, r: sel.rot, c: sel.col });
    }
    function toggleTrim() { if (trimOpen) closeTrim(); else openTrim(); }
    function closeTrim() { trimOpen = false; trimBox.style.display = 'none'; }
    function openTrim() {
      if (!canInput()) return;
      if (st.tk[st.cur] <= 0) { api.toast('조정 기회를 다 썼어요'); return; }
      trimOpen = true;
      trimBox.innerHTML = '';
      trimBox.append(L.h('div', { style: { fontSize: '12.5px', color: 'var(--muted)', lineHeight: '17px' }, text: '상자 대신 균형 잡기 (남은 ' + st.tk[st.cur] + '번) · 상자는 ' + (st.n > 1 ? '다음 사람에게' : '그대로') }));
      const grid = L.h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' } });
      const opt = (k, label) => {
        const ok = trimOK(st, st.cur, k);
        let sub = '못 해요';
        if (ok) { const r = runPreview({ t: 'tr', k }).r0; sub = r.crash ? '💥 추락!' : '→ ' + angTxt(r.fin) + (r.fall ? ' ⚠떨어짐' : ''); }
        const b = L.h('button', { class: 'btn sm', style: { minHeight: '54px', padding: '4px 6px', fontSize: '13px', lineHeight: '17px', whiteSpace: 'nowrap', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '2px', opacity: ok ? '1' : '0.4' } },
          L.h('div', { text: label }), L.h('div', { class: 'mono', style: { fontSize: '12px', color: 'var(--brass)' }, text: sub }));
        b.disabled = !ok;
        b.onclick = () => { if (!canInput()) return; api.sfx('click'); api.buzz(12); send({ t: 'tr', k }); };
        grid.append(b);
      };
      opt('bL', '🎒 왼쪽 모래 버리기 ' + st.bl[0]);
      opt('bR', '🎒 오른쪽 모래 버리기 ' + st.bl[1]);
      opt('gL', '🎈 가스로 왼쪽 들기');
      opt('gR', '🎈 가스로 오른쪽 들기');
      trimBox.append(grid, L.h('button', { class: 'btn sm ghost', style: { minHeight: '44px' }, text: '닫기', onclick: closeTrim }));
      trimBox.style.display = 'flex';
      api.sfx('tick');
    }

    /* --- input --- */
    function dockHit(x, y) {
      if (!LY || y < LY.dockY || y > LY.dockY + LY.dockH) return -1;
      const sw = slotW();
      for (let j = 0; j < dockCount(); j++) { const x0 = 8 + j * (sw + 6); if (x >= x0 && x <= x0 + sw) return j; }
      return -2;
    }
    function slotW() { return Math.floor((LY.W - 16 - 12) * 0.39); }
    function colFromX(px, py) {
      const b = toBody(px, py, snap ? snap.th : 0), w = widthOf(selCells());
      return clamp(Math.round(b.x + 4 - (w - 1) / 2), 0, GW - w);
    }
    function onDown(e) {
      if (!st || !LY) return;
      const q = cv.local(e);
      const dh = dockHit(q.x, q.y);
      if (dh >= 0) {
        if (canInput()) { closeTrim(); pickDock(dh); }
        else { const ty = dockType(st, dh); if (ty >= 0) api.toast(TYPES[ty].n + (TYPES[ty].d ? ' — ' + TYPES[ty].d : ' · 무게 ' + TYPES[ty].w)); }
        return;
      }
      if (dh === -2) return;
      if (!canInput() || !sel) return;
      closeTrim();
      drag = { x0: q.x, y0: q.y, c0: sel.col, moved: false, id: e.pointerId };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
    }
    function onMove(e) {
      if (!st || !LY) return;
      const q = cv.local(e);
      if (drag) {
        const dx = q.x - drag.x0;
        if (!drag.moved && Math.abs(dx) > 8) drag.moved = true;
        if (drag.moved && canInput()) {
          const w = widthOf(selCells()), c = clamp(drag.c0 + Math.round(dx / (LY.u * 0.9)), 0, GW - w);
          if (c !== sel.col) { sel.col = c; api.sfx('tick'); updateHud(); }
        }
        return;
      }
      if (e.pointerType === 'mouse' && canInput() && sel && q.y > LY.sceneTop && q.y < LY.hintY) {
        const c = colFromX(q.x, q.y);
        if (c !== sel.col) { sel.col = c; updateHud(); }
      }
    }
    function onUp(e) {
      if (!drag) return;
      const q = cv.local(e), d = drag; drag = null;
      if (!d.moved && canInput() && sel) {
        const c = colFromX(q.x, q.y);
        if (c !== sel.col) { sel.col = c; api.sfx('tick'); api.buzz(5); updateHud(); }
      }
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.onresize = () => { if (st) { layout(); updateHud(); } };
    const offInput = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'left') nudge(-1); else if (id === 'right') nudge(1); else if (id === 'rot') rotate();
      else if (id === 'go') onGo(); else if (id === 'trim') toggleTrim();
      else if (id === 'swap') pickDock(sel && sel.j === 0 ? 1 : 0);
    }) : null;

    /* --- animation --- */
    function snapFrom(s) { return simNew(dec(s), null, true); }
    function startAnim(next) {
      const lm = next.last;
      const S = simNew(dec(lm.pre), lm.ev, false);
      const A = { S, t0: performance.now(), drop: lm.ev.pl ? DROP : 0, li: 0, crashT: -1, endT: -1, s: lm.s, msg: '', lm };
      if (lm.ev.pl) { A.msg = pname(lm.s) + ': ' + TYPES[lm.ev.pl[0]].n + ' 싣는 중'; }
      else { const k = lm.ev.tr; A.msg = pname(lm.s) + ': ' + (k[0] === 'b' ? (k === 'bL' ? '왼쪽' : '오른쪽') + ' 모래주머니 버리기' : '가스를 ' + (k === 'gL' ? '왼쪽' : '오른쪽') + '으로'); api.sfx(k[0] === 'b' ? 'pop' : 'whoosh'); }
      for (const [id, v] of vis) { const p = S.P[id]; if (p) { v.c0 = minC(p); v.r0 = minR(p); } }
      anim = A;
      closeTrim();
      setBusy(true);
      clearTimeout(safety);
      safety = setTimeout(() => { if (anim === A) finishAnim(); }, (12000 / (L.debug.speed || 1)) + 1500);
      updateHud();
    }
    function finishAnim() {
      const A = anim;
      anim = null; clearTimeout(safety);
      snap = snapFrom(st);
      if (A && A.lm) {
        if (A.lm.sk) api.toast('자리가 없는 상자 ' + A.lm.sk + '개는 내려놓고 가요');
        if (!st.end && api.canAct(st.cur) && st.n > 1 && api.players.filter((p, i) => api.canAct(i)).length > 1) api.toast(pname(st.cur) + ' 차례예요');
      }
      setBusy(false);
      updateHud();
    }
    const minC = (p) => { let m = 99; for (const q of p.c) m = Math.min(m, q[0]); return m; };
    const minR = (p) => { let m = 99; for (const q of p.c) m = Math.min(m, q[1]); return m; };
    function animStep(now, dt) {
      const A = anim; if (!A) return;
      const sp = L.debug.speed || 1, e = (now - A.t0) / 1000 * sp;
      const S = A.S;
      if (A.crashT >= 0) { if (e - A.crashT > 1.5) finishAnim(); return; }
      if (A.endT >= 0) { if (e - A.endT > 0.25) finishAnim(); return; }
      if (e < A.drop) return;
      if (A.drop && !A.landed) { A.landed = true; api.sfx('thud'); api.buzz(18); }
      const target = (e - A.drop) * PLAY;
      let guard = 0;
      while (!S.done && S.t < target && guard++ < 400) simStep(S);
      while (A.li < S.log.length) onEvent(S.log[A.li++], S);
      if (S.done) {
        if (S.crash) A.crashT = e; else A.endT = e;
      }
    }
    function onEvent(ev, S) {
      if (ev.k === 'slide') { if (!anim.slid) { anim.slid = true; api.sfx('roll'); api.buzz(20); anim.msg = '⚠ 화물이 미끄러져요!'; updateHud(); } }
      else if (ev.k === 'fall') {
        api.sfx('whoosh'); api.buzz(50);
        api.toast(TYPES[ev.ty].n + '가 떨어졌어요! (' + pname(anim.s) + ' −2점)');
        spawnFall(ev, S);
      } else if (ev.k === 'gust') { api.sfx('whoosh'); api.buzz(15); anim.msg = '💨 돌풍!'; updateHud(); }
      else if (ev.k === 'turb') { api.sfx('bounce'); anim.msg = '〰 난기류!'; updateHud(); }
      else if (ev.k === 'hop') { api.sfx('pop'); const v = visOf(ev.id); v.hop = 1; v.hf = 1 - S.P[ev.id].f; }
      else if (ev.k === 'ash') { api.sfx('tick'); api.toast('🌋 화산재가 기구 ' + (ev.s ? '오른쪽' : '왼쪽') + '에 쌓였어요'); }
      else if (ev.k === 'bag') { api.sfx('pop'); const q = toScreen(ev.s ? BAGX : -BAGX, 1.3, S.th); parts.push({ bag: 1, x: q.x, y: q.y, vx: (ev.s ? 1 : -1) * 30, vy: 0, rot: 0, vr: (ev.s ? 1 : -1) * 2, ty: 0 }); }
      else if (ev.k === 'crash') { api.sfx('lose'); api.buzz(140); anim.msg = '💥 추락!'; updateHud(); }
    }
    function visOf(id) { let v = vis.get(id); if (!v) { v = { ox: 0, oy: 0, c0: -1, r0: -1, hop: 0, hf: 0 }; vis.set(id, v); } return v; }
    function spawnFall(ev, S) {
      let cx = 0, cy = 0; for (const q of ev.c) { cx += q[0] - 4; cy += q[1] + 0.5; } cx /= ev.c.length; cy /= ev.c.length;
      const p = toScreen(cx, cy, S.th);
      parts.push({ x: p.x, y: p.y, vx: ev.d * 90, vy: -60, rot: -S.th, vr: ev.d * 2.6, ty: ev.ty, cells: ev.c.map((q) => [q[0] - 4 - cx, q[1] + 0.5 - cy]) });
    }

    /* --- drawing: ship --- */
    function drawShip(x, S, th, tsec, opt) {
      const u = LY.u;
      x.save();
      x.translate(LY.bx + (opt && opt.dx || 0), LY.by + (opt && opt.dy || 0));
      x.rotate(-th);
      if (opt && opt.alpha != null) x.globalAlpha = opt.alpha;
      // cables
      x.strokeStyle = 'rgba(40,30,40,.85)'; x.lineWidth = Math.max(1.2, u * 0.07);
      x.beginPath();
      for (const sg of [-1, 1]) { x.moveTo(X(sg * 4.72), Yb(4.0)); x.lineTo(X(sg * 4.5), Yb(7.75)); x.moveTo(X(sg * 4.72), Yb(4.0)); x.lineTo(X(sg * 3.2), Yb(6.9)); }
      x.stroke();
      drawEnvelope(x, S, tsec, th);
      drawHull(x, S);
      drawBags(x, S);
      drawPieces(x, S, th, tsec);
      x.restore();
    }
    function drawEnvelope(x, S, tsec, th) {
      const u = LY.u, cy = Yb(9.0), rx = 5.4 * u, ry = 2.5 * u;
      // engines
      for (const sg of [-1, 1]) {
        const ex = X(sg * 5.15), ey = Yb(7.3);
        x.fillStyle = '#3b3446'; x.fillRect(ex - sg * 0.55 * u - 0.12 * u, ey - 0.06 * u, 0.24 * u + 0.1 * u, 0.12 * u);
        x.fillStyle = '#d7dde3'; x.beginPath(); x.ellipse(ex, ey, 0.42 * u, 0.26 * u, 0, 0, 7); x.fill();
        x.fillStyle = '#9aa6b2'; x.beginPath(); x.ellipse(ex, ey + 0.06 * u, 0.42 * u, 0.12 * u, 0, 0, Math.PI); x.fill();
        const bw = Math.abs(Math.sin(tsec * 23 + sg)) * 0.55 * u + 0.06 * u;
        x.fillStyle = 'rgba(240,240,250,.55)'; x.beginPath(); x.ellipse(ex + sg * 0.47 * u, ey, 0.07 * u, bw, 0, 0, 7); x.fill();
      }
      // side fins (seen end-on) + top fin
      x.fillStyle = '#c2584a';
      for (const sg of [-1, 1]) { x.beginPath(); x.moveTo(X(sg * 5.2), cy - 0.18 * u); x.lineTo(X(sg * 5.95), cy - 0.05 * u); x.lineTo(X(sg * 5.95), cy + 0.08 * u); x.lineTo(X(sg * 5.2), cy + 0.22 * u); x.closePath(); x.fill(); }
      x.beginPath(); x.moveTo(-0.16 * u, cy - ry + 0.1 * u); x.lineTo(0, cy - ry - 0.55 * u); x.lineTo(0.16 * u, cy - ry + 0.1 * u); x.closePath(); x.fill();
      // body
      const g = x.createLinearGradient(0, cy - ry, 0, cy + ry); g.addColorStop(0, '#fbf3e1'); g.addColorStop(0.6, '#e9dcc0'); g.addColorStop(1, '#bfae8f');
      x.fillStyle = g; x.beginPath(); x.ellipse(0, cy, rx, ry, 0, 0, 7); x.fill();
      x.save(); x.beginPath(); x.ellipse(0, cy, rx, ry, 0, 0, 7); x.clip();
      x.fillStyle = 'rgba(224,112,90,.88)'; x.beginPath(); x.ellipse(0, cy, rx * 0.72, ry + 2, 0, 0, 7); x.fill();
      x.fillStyle = '#f3e8d0'; x.beginPath(); x.ellipse(0, cy, rx * 0.44, ry + 2, 0, 0, 7); x.fill();
      x.fillStyle = 'rgba(224,112,90,.88)'; x.beginPath(); x.ellipse(0, cy, rx * 0.16, ry + 2, 0, 0, 7); x.fill();
      // gas cells: the fuller side glows
      const pu = S.pu1 !== S.pu0 ? S.bx / PUMP : S.pu1;
      if (Math.abs(pu) > 0.01) {
        const side = pu < 0 ? -1 : 1, a = Math.min(0.32, Math.abs(pu) * 0.1);
        x.fillStyle = 'rgba(255,255,220,' + a + ')'; x.fillRect(side < 0 ? -rx : 0, cy - ry, rx, ry * 2);
        x.fillStyle = 'rgba(30,20,50,' + a * 0.8 + ')'; x.fillRect(side < 0 ? 0 : -rx, cy - ry, rx, ry * 2);
        x.fillStyle = 'rgba(80,60,40,.75)'; x.font = MONO(Math.max(9, u * 0.5), 700); x.textAlign = 'center'; x.textBaseline = 'middle';
        x.fillText((side < 0 ? '◀' : '▶').repeat(Math.min(3, Math.round(Math.abs(pu)))), side * rx * 0.58, cy + ry * 0.45);
      }
      const hl = x.createRadialGradient(-rx * 0.35, cy - ry * 0.55, 2, -rx * 0.35, cy - ry * 0.55, rx * 0.9); hl.addColorStop(0, 'rgba(255,255,255,.45)'); hl.addColorStop(1, 'rgba(255,255,255,0)');
      x.fillStyle = hl; x.fillRect(-rx, cy - ry, rx * 2, ry * 2);
      x.restore();
      x.strokeStyle = 'rgba(70,45,40,.55)'; x.lineWidth = 1.2; x.beginPath(); x.ellipse(0, cy, rx, ry, 0, 0, 7); x.stroke();
      x.beginPath(); x.moveTo(0, cy - ry); x.lineTo(0, cy + ry); x.strokeStyle = 'rgba(70,45,40,.25)'; x.stroke();
      // ash heaps on top
      for (let k = 0; k < 2; k++) {
        const n = S.ash[k]; if (!n) continue;
        const sg = k ? 1 : -1;
        for (let j = 0; j < n; j++) {
          const fx2 = sg * (0.28 + j * 0.13), px = fx2 * rx, py = cy - ry * Math.sqrt(Math.max(0, 1 - fx2 * fx2)) + 0.05 * u;
          x.fillStyle = j & 1 ? '#5d5552' : '#716864'; x.beginPath(); x.ellipse(px, py, 0.42 * u, 0.2 * u, sg * 0.4 * fx2, 0, 7); x.fill();
        }
      }
    }
    const HULL = [[-4.95, 4.05], [-4.95, 1.1], [-4.6, 0.1], [-3.9, -0.75], [3.9, -0.75], [4.6, 0.1], [4.95, 1.1], [4.95, 4.05]];
    function hullPath(x) { x.beginPath(); HULL.forEach((q, i) => (i ? x.lineTo(X(q[0]), Yb(q[1])) : x.moveTo(X(q[0]), Yb(q[1])))); x.closePath(); }
    function drawHull(x, S) {
      const u = LY.u;
      // open deck guide (rows 4–5)
      x.strokeStyle = 'rgba(255,240,210,.22)'; x.lineWidth = 1; x.setLineDash([3, 4]);
      x.strokeRect(X(-4.5), Yb(6), 9 * u, 2 * u); x.setLineDash([]);
      hullPath(x);
      const g = x.createLinearGradient(0, Yb(4.1), 0, Yb(-0.8)); g.addColorStop(0, '#3f8a79'); g.addColorStop(1, '#1f5247');
      x.fillStyle = g; x.fill();
      x.strokeStyle = 'rgba(10,30,26,.8)'; x.lineWidth = 1.4; x.stroke();
      // interior
      x.beginPath(); x.moveTo(X(-4.5), Yb(4.0)); x.lineTo(X(-4.5), Yb(1)); x.lineTo(X(-3.5), Yb(0)); x.lineTo(X(3.5), Yb(0)); x.lineTo(X(4.5), Yb(1)); x.lineTo(X(4.5), Yb(4.0)); x.closePath();
      x.fillStyle = '#211a2e'; x.fill();
      x.save(); x.clip();
      x.strokeStyle = 'rgba(255,255,255,.05)'; x.lineWidth = 1;
      for (let c = 1; c < GW; c++) { x.beginPath(); x.moveTo(X(c - 4.5), Yb(0)); x.lineTo(X(c - 4.5), Yb(4)); x.stroke(); }
      for (let r = 1; r < 4; r++) { x.beginPath(); x.moveTo(X(-4.5), Yb(r)); x.lineTo(X(4.5), Yb(r)); x.stroke(); }
      x.fillStyle = 'rgba(255,255,255,.035)'; x.fillRect(X(-0.5), Yb(4), u, 4 * u);
      x.restore();
      // planks on the outside
      x.save(); hullPath(x); x.clip();
      x.strokeStyle = 'rgba(0,0,0,.18)'; x.lineWidth = 1;
      for (let k = 0; k < 5; k++) { const y = Yb(3.2 - k * 0.95); x.beginPath(); x.moveTo(X(-5), y); x.lineTo(X(5), y); x.stroke(); }
      x.restore();
      // wall caps + door arrows
      x.fillStyle = '#e3ae45'; x.fillRect(X(-4.98), Yb(4.12), 0.5 * u, 0.14 * u); x.fillRect(X(4.48), Yb(4.12), 0.5 * u, 0.14 * u);
      x.fillStyle = 'rgba(255,240,210,.8)'; x.font = MONO(Math.max(9, u * 0.42), 700); x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillText('◀', X(-4.73), Yb(2.6)); x.fillText('▶', X(4.73), Yb(2.6));
    }
    function drawBags(x, S) {
      const u = LY.u;
      for (let k = 0; k < 2; k++) {
        const sg = k ? 1 : -1, n = S.bl[k];
        const bx2 = X(sg * BAGX);
        x.strokeStyle = '#6b5440'; x.lineWidth = Math.max(1, u * 0.06);
        x.beginPath(); x.moveTo(X(sg * 4.95), Yb(3.7)); x.lineTo(bx2, Yb(n ? 3.1 : 3.4)); x.lineTo(bx2, Yb(n ? 2.95 - (n - 1) * 0.62 : 3.3)); x.stroke();
        for (let j = 0; j < n; j++) {
          const by2 = Yb(2.75 - j * 0.62);
          x.fillStyle = '#b89466'; x.beginPath(); x.ellipse(bx2, by2, 0.34 * u, 0.3 * u, 0, 0, 7); x.fill();
          x.fillStyle = '#8f7048'; x.fillRect(bx2 - 0.12 * u, by2 - 0.33 * u, 0.24 * u, 0.1 * u);
          x.strokeStyle = 'rgba(60,40,20,.5)'; x.lineWidth = 1; x.beginPath(); x.ellipse(bx2, by2, 0.34 * u, 0.3 * u, 0, 0, 7); x.stroke();
        }
      }
    }
    function cellOwner(S, c, r) { if (c < 0 || c >= GW || r < 0 || r >= GH) return -9; return S.g[r * GW + c]; }
    function drawPieces(x, S, th, tsec) {
      for (let id = 0; id < S.P.length; id++) {
        const p = S.P[id];
        if (p.x) continue;
        if (anim && anim.drop && id === S.newId) {
          const e = (performance.now() - anim.t0) / 1000 * (L.debug.speed || 1), k = Math.min(1, e / anim.drop);
          drawPiece(x, S, p, id, 0, (1 - k) * (1 - k) * (GH + 0.4 - minR(p)), Math.min(1, 0.3 + k * 1.5), th, tsec);
        } else {
          const v = visOf(id);
          drawPiece(x, S, p, id, v.ox, v.oy, 1, th, tsec);
        }
      }
      // ghost
      if (!anim && sel && canInput() && selValid()) {
        const cells = selCells(), r0 = dropRow(S.g, cells, sel.col), ty = dockType(st, sel.j);
        const gp = { t: ty, o: st.cur, f: TYPES[ty].ani ? sel.rot & 1 : 0, x: false, d: dockDoor(st, sel.j), c: cells.map((q) => [sel.col + q[0], r0 + q[1]]) };
        const pulse = 0.55 + 0.15 * Math.sin(tsec * 5);
        drawPiece(x, S, gp, -5, 0, 0, pulse, th, tsec, true);
        // drop guide
        const u = LY.u; let cx = 0; for (const q of gp.c) cx += q[0] - 4; cx /= gp.c.length;
        x.strokeStyle = 'rgba(255,230,160,.5)'; x.setLineDash([4, 5]); x.lineWidth = 1.5;
        let top = 0; for (const q of gp.c) top = Math.max(top, q[1] + 1);
        x.beginPath(); x.moveTo(X(cx), Yb(top)); x.lineTo(X(cx), Yb(6.6)); x.stroke(); x.setLineDash([]);
      }
    }
    function drawPiece(x, S, p, id, ox, oy, alpha, th, tsec, ghost) {
      const u = LY.u, T = TYPES[p.t];
      const own = (c, r) => p.c.some((q) => q[0] === c && q[1] === r);
      x.save();
      x.globalAlpha *= alpha;
      x.translate(ox * u, -oy * u);
      const ins = 0.05 * u;
      for (const q of p.c) {
        const x0 = X(q[0] - 4.5), y0 = Yb(q[1] + 1);
        x.fillStyle = T.col; x.fillRect(x0, y0, u, u);
        // planks
        if (p.t <= 2 || p.t === 9 || p.t === 7) { x.fillStyle = 'rgba(0,0,0,.12)'; x.fillRect(x0, y0 + u * 0.32, u, 1); x.fillRect(x0, y0 + u * 0.66, u, 1); }
        else if (p.t !== 6) { x.fillStyle = 'rgba(255,255,255,.12)'; x.fillRect(x0 + 2, y0 + 2, u - 4, u * 0.18); }
      }
      // outline along the outer edges
      x.strokeStyle = ghost ? 'rgba(255,240,200,.95)' : 'rgba(40,24,16,.85)'; x.lineWidth = ghost ? 2 : 1.6;
      if (ghost) x.setLineDash([5, 3]);
      x.beginPath();
      for (const q of p.c) {
        const x0 = X(q[0] - 4.5), y0 = Yb(q[1] + 1), x1 = x0 + u, y1 = y0 + u;
        if (!own(q[0], q[1] + 1)) { x.moveTo(x0 + ins, y0 + ins); x.lineTo(x1 - ins, y0 + ins); }
        if (!own(q[0], q[1] - 1)) { x.moveTo(x0 + ins, y1 - ins); x.lineTo(x1 - ins, y1 - ins); }
        if (!own(q[0] - 1, q[1])) { x.moveTo(x0 + ins, y0 + ins); x.lineTo(x0 + ins, y1 - ins); }
        if (!own(q[0] + 1, q[1])) { x.moveTo(x1 - ins, y0 + ins); x.lineTo(x1 - ins, y1 - ins); }
      }
      x.stroke(); x.setLineDash([]);
      let cx = 0, cy = 0; for (const q of p.c) { cx += q[0] - 4; cy += q[1] + 0.5; } cx /= p.c.length; cy /= p.c.length;
      const px = X(cx), py = Yb(cy);
      if (p.t === 2) { x.strokeStyle = 'rgba(60,30,10,.55)'; x.lineWidth = 2; x.beginPath(); x.moveTo(px - u * 0.8, py - u * 0.8); x.lineTo(px + u * 0.8, py + u * 0.8); x.moveTo(px + u * 0.8, py - u * 0.8); x.lineTo(px - u * 0.8, py + u * 0.8); x.stroke(); }
      if (p.t === 6) drawTank(x, p, px, py, th, tsec);
      else if (p.t === 7) drawBalloon(x, S, p, px, py, th, tsec, ghost);
      else if (p.t === 8) drawAnchor(x, px, py);
      else if (p.t === 9) drawSheep(x, p, id, th, tsec);
      // weight number
      if (p.t !== 6 && p.t !== 8 && p.t !== 9 && p.t !== 7) {
        x.fillStyle = 'rgba(30,18,10,.8)'; x.font = MONO(Math.max(9, u * 0.5), 700); x.textAlign = 'center'; x.textBaseline = 'middle';
        x.fillText(String(T.w), px, py + 1);
      }
      // door tag + owner dot
      if (p.d && p.d !== '-') {
        const ok = doorOK(p), q = p.c.reduce((a, b) => (b[1] > a[1] || (b[1] === a[1] && (p.d === 'L' ? b[0] < a[0] : b[0] > a[0])) ? b : a));
        const tx = X(q[0] - 4 + (p.d === 'L' ? -0.22 : 0.22)), ty = Yb(q[1] + 0.72);
        x.fillStyle = ok ? '#5fd3a0' : 'rgba(255,250,235,.95)'; x.strokeStyle = 'rgba(0,0,0,.6)'; x.lineWidth = 1;
        x.beginPath();
        const s2 = u * 0.2, dd = p.d === 'L' ? -1 : 1;
        x.moveTo(tx + dd * s2, ty); x.lineTo(tx - dd * s2 * 0.7, ty - s2 * 0.85); x.lineTo(tx - dd * s2 * 0.7, ty + s2 * 0.85); x.closePath(); x.fill(); x.stroke();
      }
      if (st && st.n > 1 && !ghost) {
        const q = p.c[0];
        x.fillStyle = pcol(p.o); x.strokeStyle = 'rgba(0,0,0,.6)'; x.lineWidth = 1;
        x.beginPath(); x.arc(X(q[0] - 4.5) + u * 0.2, Yb(q[1]) - u * 0.2, Math.max(2.5, u * 0.11), 0, 7); x.fill(); x.stroke();
      }
      x.restore();
    }
    function drawTank(x, p, px, py, th, tsec) {
      const u = LY.u, w = 1.86 * u, h = 0.82 * u;
      x.fillStyle = '#9fc4d2'; rr(x, px - w / 2, py - h / 2, w, h, h * 0.45); x.fill();
      x.save(); rr(x, px - w / 2, py - h / 2, w, h, h * 0.45); x.clip();
      x.translate(px + (p.sl || 0) * u * 0.25, py); x.rotate(th);
      const wob = Math.sin(tsec * 6) * 0.03 * u;
      x.fillStyle = 'rgba(40,120,190,.85)'; x.fillRect(-2 * u, -0.05 * u + wob, 4 * u, 2 * u);
      x.fillStyle = 'rgba(200,235,255,.6)'; x.fillRect(-2 * u, -0.05 * u + wob, 4 * u, 0.06 * u);
      x.restore();
      x.strokeStyle = 'rgba(30,50,60,.8)'; x.lineWidth = 1.3; rr(x, px - w / 2, py - h / 2, w, h, h * 0.45); x.stroke();
      x.fillStyle = '#fff'; x.font = MONO(Math.max(8, u * 0.36), 700); x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('3', px + w * 0.36, py - h * 0.18);
    }
    function drawBalloon(x, S, p, px, py, th, tsec, ghost) {
      const u = LY.u, q = p.c[0], free = cellOwner(S, q[0], q[1] + 1) === -1 || q[1] + 1 >= GH;
      x.fillStyle = 'rgba(30,18,10,.8)'; x.font = MONO(Math.max(8, u * 0.4), 700); x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('−1', px, py + u * 0.18);
      x.save(); x.translate(px, py - u * 0.3); x.rotate(th);
      const bob = Math.sin(tsec * 2.4 + q[0]) * 0.06 * u, hgt = free ? 1.05 * u : 0.0, r = free ? 0.36 * u : 0.2 * u;
      if (free) { x.strokeStyle = 'rgba(255,255,255,.7)'; x.lineWidth = 1; x.beginPath(); x.moveTo(0, 0); x.quadraticCurveTo(0.12 * u, -hgt * 0.5, 0, -hgt + r + bob); x.stroke(); }
      x.fillStyle = '#ff6f8f'; x.beginPath(); x.ellipse(0, -hgt + bob, r * 0.88, r, 0, 0, 7); x.fill();
      x.fillStyle = 'rgba(255,255,255,.55)'; x.beginPath(); x.ellipse(-r * 0.3, -hgt + bob - r * 0.35, r * 0.2, r * 0.28, -0.4, 0, 7); x.fill();
      x.restore();
    }
    function drawAnchor(x, px, py) {
      const u = LY.u;
      x.strokeStyle = '#d9dde3'; x.lineWidth = Math.max(1.5, u * 0.09); x.lineCap = 'round';
      x.beginPath(); x.arc(px, py - u * 0.27, u * 0.09, 0, 7); x.moveTo(px, py - u * 0.18); x.lineTo(px, py + u * 0.28);
      x.moveTo(px - u * 0.18, py - u * 0.06); x.lineTo(px + u * 0.18, py - u * 0.06);
      x.moveTo(px - u * 0.3, py + u * 0.08); x.quadraticCurveTo(px - u * 0.25, py + u * 0.32, px, py + u * 0.3); x.quadraticCurveTo(px + u * 0.25, py + u * 0.32, px + u * 0.3, py + u * 0.08);
      x.stroke(); x.lineCap = 'butt';
      x.fillStyle = '#e3ae45'; x.font = MONO(Math.max(8, u * 0.3), 700); x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('5', px + u * 0.32, py - u * 0.3);
    }
    function drawSheep(x, p, id, th, tsec) {
      const u = LY.u, v = visOf(id);
      const qa = p.c[0], qb = p.c[1] || p.c[0];
      let f = p.f, k = 1;
      if (v.hop > 0) { k = 1 - v.hop; f = p.f; }
      const from = f ? qa : qb, to = f ? qb : qa;
      const fx2 = (v.hop > 0 ? (from[0] + (to[0] - from[0]) * k) : to[0]) - 4, jump = v.hop > 0 ? Math.sin(k * Math.PI) * 0.45 : 0;
      const sx = X(fx2), sy = Yb(to[1] + 0.42 + jump);
      x.fillStyle = '#fbf7ef';
      for (const [dx, dy, r] of [[-0.18, 0, 0.2], [0.05, -0.1, 0.22], [0.2, 0.04, 0.19], [0, 0.1, 0.2]]) { x.beginPath(); x.arc(sx + dx * u, sy + dy * u, r * u, 0, 7); x.fill(); }
      const face = p.f ? 1 : -1;
      x.fillStyle = '#2d2622'; x.beginPath(); x.ellipse(sx + face * 0.3 * u, sy - 0.05 * u, 0.13 * u, 0.15 * u, 0, 0, 7); x.fill();
      x.fillStyle = '#fff'; x.beginPath(); x.arc(sx + face * 0.34 * u, sy - 0.09 * u, 0.035 * u, 0, 7); x.fill();
      x.fillStyle = '#2d2622'; x.fillRect(sx - 0.15 * u, sy + 0.2 * u, 0.05 * u, 0.14 * u); x.fillRect(sx + 0.1 * u, sy + 0.2 * u, 0.05 * u, 0.14 * u);
      // the other half shows where it will hop next
      const other = p.f ? qa : qb;
      if (other !== to && !anim) { x.fillStyle = 'rgba(40,20,10,.45)'; x.font = MONO(Math.max(8, u * 0.34), 700); x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(other[0] > to[0] ? '→' : '←', X(other[0] - 4), Yb(other[1] + 0.5)); }
    }

    /* --- drawing: gauge, chips, weather, dock --- */
    function drawGauge(x, th, p, sl) {
      const cx = LY.gX, cy = LY.gY, R = LY.gR, K = 2;   // dial shows the angle ×2 so small tilts are easy to read
      const ang = (deg) => -Math.PI / 2 - clamp(deg, -45, 45) * DEG * K;
      x.save();
      x.fillStyle = 'rgba(16,12,26,.62)'; x.beginPath(); x.arc(cx, cy, R + 8, Math.PI, 0); x.lineTo(cx + R + 8, cy + 6); x.lineTo(cx - R - 8, cy + 6); x.closePath(); x.fill();
      const band = (a0, a1, col) => { x.strokeStyle = col; x.lineWidth = 7; x.beginPath(); x.arc(cx, cy, R, ang(a1), ang(a0)); x.stroke(); };
      for (const sg of [-1, 1]) {
        const seg = [[0, SAFE, ZC.ok], [SAFE, sl, ZC.warn], [sl, 30, ZC.bad], [30, 45, ZC.dead]];
        for (const [a, b, c] of seg) sg > 0 ? band(a, b, c) : band(-b, -a, c);
      }
      // predicted wedge (rest → worst swing)
      if (p) {
        const a = p.r0.fin, b = Math.abs(p.wr.pk) > Math.abs(p.r0.pk) ? p.wr.pk : p.r0.pk;
        x.fillStyle = 'rgba(255,230,150,.28)'; x.beginPath(); x.moveTo(cx, cy); x.arc(cx, cy, R - 4, Math.min(ang(a), ang(b)), Math.max(ang(a), ang(b))); x.closePath(); x.fill();
        const pa = ang(a);
        x.strokeStyle = '#ffe28a'; x.lineWidth = 2.5; x.setLineDash([4, 3]);
        x.beginPath(); x.moveTo(cx, cy); x.lineTo(cx + Math.cos(pa) * (R + 2), cy + Math.sin(pa) * (R + 2)); x.stroke(); x.setLineDash([]);
      }
      const na = ang(th / DEG);
      x.strokeStyle = '#fff6e4'; x.lineWidth = 3; x.lineCap = 'round';
      x.beginPath(); x.moveTo(cx, cy); x.lineTo(cx + Math.cos(na) * (R - 6), cy + Math.sin(na) * (R - 6)); x.stroke(); x.lineCap = 'butt';
      x.fillStyle = '#e3ae45'; x.beginPath(); x.arc(cx, cy, 4, 0, 7); x.fill();
      // labels
      x.strokeStyle = 'rgba(255,245,225,.8)'; x.lineWidth = 1.5; x.beginPath();
      for (const d of [-30, -sl, -SAFE, 0, SAFE, sl, 30]) { const a = ang(d); x.moveTo(cx + Math.cos(a) * (R + 4), cy + Math.sin(a) * (R + 4)); x.lineTo(cx + Math.cos(a) * (R + 8), cy + Math.sin(a) * (R + 8)); }
      x.stroke(); x.textBaseline = 'middle';
      // side readouts
      const deg = th / DEG, side = Math.min(70, (LY.W / 2 - R - 14));
      x.textAlign = 'right'; x.fillStyle = 'rgba(255,245,225,.65)'; x.font = FONT(10.5, 600); x.fillText('지금', cx - R - 14, cy - 18);
      x.font = MONO(Math.min(17, side * 0.28 + 6), 700); x.fillStyle = zoneCol(deg, sl); x.fillText(Math.abs(deg) > 31 ? '추락!' : angTxt(deg), cx - R - 14, cy - 2);
      if (p) {
        x.textAlign = 'left'; x.fillStyle = 'rgba(255,245,225,.65)'; x.font = FONT(10.5, 600); x.fillText(p.r0.crash ? '예상' : '예상', cx + R + 14, cy - 18);
        x.font = MONO(Math.min(17, side * 0.28 + 6), 700); x.fillStyle = p.r0.crash ? ZC.dead : zoneCol(p.r0.fin, sl);
        x.fillText(p.r0.crash ? '추락!' : angTxt(p.r0.fin), cx + R + 14, cy - 2);
      }
      x.restore();
    }
    function drawChips(x) {
      const n = st.n, W = LY.W, gap = 4, cw = (W - 8 - gap * (n - 1)) / n, h = LY.chipH;
      for (let k = 0; k < n; k++) {
        const x0 = 4 + k * (cw + gap), y0 = 4, cur = !st.end && st.cur === k;
        x.fillStyle = cur ? 'rgba(227,174,69,.2)' : 'rgba(20,15,30,.62)'; rr(x, x0, y0, cw, h, 10); x.fill();
        x.strokeStyle = cur ? '#e3ae45' : 'rgba(255,255,255,.12)'; x.lineWidth = cur ? 2 : 1; x.stroke();
        x.fillStyle = pcol(k); x.beginPath(); x.arc(x0 + 11, y0 + 12, 5, 0, 7); x.fill();
        x.textAlign = 'left'; x.textBaseline = 'middle'; x.fillStyle = '#f2e9d8'; x.font = FONT(12, 700);
        let nm = pname(k).replace('(AI)', '').trim();
        while (nm.length > 1 && x.measureText(nm).width > cw - 26) nm = nm.slice(0, -1);
        x.fillText(nm, x0 + 20, y0 + 12);
        x.font = MONO(11.5, 700);
        if (n === 1) {
          const q = starNeed(st.D), dn = snap ? snap.P.filter(delivered).length : 0;
          x.fillStyle = '#e3ae45'; x.fillText('배달 ' + dn + '/' + st.D, x0 + 8, y0 + 28);
          x.fillStyle = 'rgba(242,233,216,.75)'; x.font = MONO(10.5, 600); x.textAlign = 'right';
          x.fillText('★' + q[0] + ' ★★' + q[1] + ' ★★★' + q[2] + '  ⚖' + st.tk[0], x0 + cw - 8, y0 + 28);
        } else {
          x.fillStyle = '#e3ae45'; x.fillText(scoreOf(st, k, snap ? snap.P : null) + '점', x0 + 8, y0 + 28);
          x.textAlign = 'right'; x.fillStyle = 'rgba(242,233,216,.7)'; x.font = MONO(10.5, 600); x.fillText('⚖' + st.tk[k], x0 + cw - 7, y0 + 28);
        }
      }
    }
    function drawWeather(x) {
      const W = LY.W, y0 = LY.wxY, h = LY.wxH, R = ROUTES[st.R], w = weatherNow(st), nx = weatherNow(st, st.t + 1);
      x.fillStyle = 'rgba(16,12,26,.6)'; rr(x, 4, y0, W - 8, h, h / 2); x.fill();
      x.textBaseline = 'middle'; x.textAlign = 'left';
      let px = 12;
      const put = (t, col, font) => { x.font = font || FONT(11.5, 700); x.fillStyle = col; x.fillText(t, px, y0 + h / 2 + 0.5); px += x.measureText(t).width + 8; };
      const arrows = (v) => (v === 0 ? '·잔잔' : (v < 0 ? '◀' : '▶').repeat(Math.min(3, Math.abs(v))) + (Math.abs(v) > 3 ? '+' : ''));
      put(R.n, '#e3ae45', FONT(11.5, 700));
      put('바람 ' + arrows(w.w), '#f2e9d8');
      if (w.gu) put('돌풍 ' + (w.gu < 0 ? '◀' : '▶') + Math.abs(w.gu) + '!', '#ffb4a6');
      if (w.ash) put('화산재 ' + (w.ash < 0 ? '◀' : '▶'), '#d9b8a0');
      if (w.T) put('난기류 ±' + w.T, 'rgba(242,233,216,.75)', FONT(11, 600));
      x.textAlign = 'right'; x.font = FONT(10.5, 600); x.fillStyle = 'rgba(242,233,216,.6)';
      const nt = '다음 ' + (nx.gu ? '돌풍!' : nx.ash ? '재' + (nx.ash < 0 ? '◀' : '▶') : arrows(nx.w));
      if (px + x.measureText(nt).width < W - 14) x.fillText(nt, W - 12, y0 + h / 2 + 0.5);
    }
    function drawDock(x, tsec) {
      const W = LY.W, y0 = LY.dockY, h = LY.dockH, sw = slotW(), mine = canInput();
      x.fillStyle = 'rgba(16,12,26,.78)'; rr(x, 4, y0, W - 8, h, 12); x.fill();
      x.strokeStyle = 'rgba(227,174,69,.25)'; x.lineWidth = 1; x.stroke();
      for (let j = 0; j < 2; j++) {
        const x0 = 8 + j * (sw + 6), ty = dockType(st, j);
        const on = mine && sel && sel.j === j;
        x.fillStyle = on ? 'rgba(227,174,69,.18)' : 'rgba(255,255,255,.04)'; rr(x, x0, y0 + 4, sw, h - 8, 9); x.fill();
        if (on) { x.strokeStyle = '#e3ae45'; x.lineWidth = 2; x.stroke(); }
        if (ty < 0) { x.fillStyle = 'rgba(242,233,216,.4)'; x.font = FONT(11, 600); x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('비었어요', x0 + sw / 2, y0 + h / 2); continue; }
        const T = TYPES[ty], dd = dockDoor(st, j);
        miniCrate(x, ty, x0 + 6, y0 + 10, 40, h - 20, on && sel ? sel.rot : 0);
        x.textAlign = 'left'; x.textBaseline = 'middle';
        let nm = T.n; x.font = FONT(12, 700); while (nm.length > 2 && x.measureText(nm).width > sw - 54) nm = nm.slice(0, -1);
        x.fillStyle = '#f2e9d8'; x.fillText(nm, x0 + 50, y0 + 17);
        x.font = MONO(10.5, 600); x.fillStyle = 'rgba(242,233,216,.75)'; x.fillText('무게' + (T.w < 0 ? '' : ' ') + T.w + ' · ' + T.v + '점', x0 + 50, y0 + 32);
        x.font = FONT(10.5, 700); x.fillStyle = dd === '-' ? 'rgba(242,233,216,.45)' : '#e3ae45';
        x.fillText(dd === '-' ? '아무 데나' : (dd === 'L' ? '◀ 왼쪽 +2' : '오른쪽 ▶ +2'), x0 + 50, y0 + 47);
      }
      // next + remaining
      const nx0 = 8 + 2 * (sw + 6), nw = W - 8 - nx0 - 4;
      if (nw > 30) {
        x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = FONT(10.5, 600); x.fillStyle = 'rgba(242,233,216,.6)';
        x.fillText('다음', nx0 + nw / 2, y0 + 13);
        const ty = dockType(st, 2);
        if (ty >= 0) { x.globalAlpha = 0.75; miniCrate(x, ty, nx0 + nw / 2 - 14, y0 + 21, 28, 22, 0); x.globalAlpha = 1; }
        else { x.fillStyle = 'rgba(242,233,216,.4)'; x.fillText('—', nx0 + nw / 2, y0 + 32); }
        x.font = MONO(10, 600); x.fillStyle = 'rgba(242,233,216,.6)'; x.fillText('남은 ' + Math.max(0, st.dk.length - 2), nx0 + nw / 2, y0 + h - 10);
      }
    }
    function miniCrate(x, ty, bx2, by2, bw, bh, rot) {
      const cells = shapeOf(ty, rot), T = TYPES[ty];
      let mw = 0, mh = 0; for (const q of cells) { mw = Math.max(mw, q[0] + 1); mh = Math.max(mh, q[1] + 1); }
      const c = Math.min(bw / Math.max(mw, 1.5), bh / Math.max(mh, 1.5), 18), ox = bx2 + (bw - mw * c) / 2, oy = by2 + (bh - mh * c) / 2;
      for (const q of cells) {
        const x0 = ox + q[0] * c, y0 = oy + (mh - 1 - q[1]) * c;
        x.fillStyle = T.col; x.fillRect(x0, y0, c, c); x.strokeStyle = 'rgba(30,18,10,.8)'; x.lineWidth = 1; x.strokeRect(x0 + 0.5, y0 + 0.5, c - 1, c - 1);
      }
      x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = MONO(Math.max(8, c * 0.6), 700);
      const cxp = ox + mw * c / 2, cyp = oy + mh * c / 2;
      if (ty === 7) { x.fillStyle = 'rgba(30,18,10,.85)'; x.fillText('−1', cxp, cyp); x.fillStyle = '#ff6f8f'; x.beginPath(); x.arc(cxp + c * 0.62, cyp - c * 0.5, c * 0.3, 0, 7); x.fill(); }
      else if (ty === 8) { x.fillStyle = '#e3e6ea'; x.fillText('⚓', cxp, cyp); }
      else if (ty === 9) { x.fillStyle = '#fbf7ef'; x.beginPath(); x.arc(ox + c * (rot & 1 ? 1.5 : 0.5), cyp, c * 0.32, 0, 7); x.fill(); x.fillStyle = '#2d2622'; x.beginPath(); x.arc(ox + c * (rot & 1 ? 1.75 : 0.25), cyp, c * 0.14, 0, 7); x.fill(); }
      else if (ty === 6) { x.fillStyle = 'rgba(40,120,190,.85)'; x.fillRect(ox + 2, cyp, mw * c - 4, c / 2 - 2); }
      else { x.fillStyle = 'rgba(30,18,10,.85)'; x.fillText(String(T.w), cxp, cyp + 0.5); }
    }

    /* --- frame --- */
    function draw(now) {
      if (!st || !LY) return;
      const W = LY.W, H = LY.H, tsec = now / 1000, dt = Math.min(0.05, (now - (lastNow || now)) / 1000); lastNow = now;
      buildBg();
      ctx.drawImage(bg, 0, 0, W, H);
      const S = anim ? anim.S : snap, w = weatherNow(st);
      // clouds (far layer behind the ship)
      const drift = (w.w === 0 ? -0.4 : w.w * 0.8) * (L.debug.speed > 2 ? 0 : 1);
      for (const c of clouds) {
        c.x += drift * (c.z ? 16 : 7) * dt;
        const sp = cloudSpr[c.k], cw = sp.w * c.s;
        if (c.x > W + cw / 2) c.x = -cw / 2; if (c.x < -cw / 2) c.x = W + cw / 2;
        ctx.globalAlpha = (st.R === 3 ? 0.16 : 0.3) * (c.z ? 0.75 : 1); ctx.drawImage(sp.c, c.x - cw / 2, c.y, cw, sp.h * c.s);
      }
      ctx.globalAlpha = 1;
      weatherFx(ctx, tsec, dt);
      // ship
      let th = S.th, dx = 0, dy = 0, alpha = 1;
      if (anim && anim.crashT >= 0) {
        const e = (now - anim.t0) / 1000 * (L.debug.speed || 1) - anim.crashT;
        th = S.th + Math.sign(S.th) * e * e * 1.4; dy = e * e * 260; dx = Math.sign(S.th) * -e * 40; alpha = Math.max(0, 1 - e / 1.5);
      }
      // visual offsets of sliding crates
      for (let id = 0; id < S.P.length; id++) {
        const p = S.P[id]; if (p.x) continue;
        const v = visOf(id), c0 = minC(p), r0 = minR(p);
        if (v.c0 >= 0 && (v.c0 !== c0 || v.r0 !== r0)) { v.ox += v.c0 - c0; v.oy += v.r0 - r0; }
        v.c0 = c0; v.r0 = r0;
        const k = Math.exp(-dt * 12); v.ox *= k; v.oy *= k;
        if (Math.abs(v.ox) < 0.01) v.ox = 0; if (Math.abs(v.oy) < 0.01) v.oy = 0;
        if (v.hop > 0) v.hop = Math.max(0, v.hop - dt * 3 * (L.debug.speed || 1));
      }
      const p = !anim && canInput() ? preview() : null;
      if (p && !p.r0.crash) {   // ghost hull at the predicted rest angle
        ctx.save(); ctx.translate(LY.bx, LY.by); ctx.rotate(-p.r0.fin * DEG);
        hullPath(ctx); ctx.strokeStyle = 'rgba(255,226,138,.5)'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]); ctx.stroke(); ctx.setLineDash([]);
        ctx.restore();
      }
      const wreck = st.end === 2 && !anim;
      if (!wreck) drawShip(ctx, S, th, tsec, { dx, dy, alpha });
      else {
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ffb4a6'; ctx.font = DISP(Math.round(LY.u * 1.6));
        ctx.fillText('💥 추락!', LY.bx, LY.by - LY.u * 2);
        ctx.font = FONT(13, 600); ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.fillText(pname(st.cr) + ' 차례에 너무 기울었어요', LY.bx, LY.by);
      }
      // balance point, plumb line, centre of mass
      if (!wreck && !(anim && anim.crashT >= 0)) {
        const B = toScreen(S.bx, HB, th);
        ctx.strokeStyle = 'rgba(255,255,255,.28)'; ctx.setLineDash([3, 5]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(B.x, B.y - 1.6 * LY.u); ctx.lineTo(B.x, B.y + 4.6 * LY.u); ctx.stroke(); ctx.setLineDash([]);
        ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(B.x, B.y, 4, 0, 7); ctx.stroke();
        let sx = S.Sx; for (const tp of S.tanks) sx += TYPES[tp.t].liq * tp.sl;
        const Gp = toScreen(sx / S.M, S.Sy / S.M, th);
        ctx.fillStyle = '#ffd34d'; ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.beginPath(); ctx.arc(Gp.x, Gp.y, 4.5, 0, 7); ctx.fill(); ctx.stroke();
      }
      // falling crates
      for (let i = parts.length - 1; i >= 0; i--) {
        const q = parts[i];
        q.vy += 900 * dt; q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.vr * dt;
        if (q.y > H + 120) { parts.splice(i, 1); continue; }
        ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.rot);
        if (q.bag) { ctx.fillStyle = '#b89466'; ctx.beginPath(); ctx.ellipse(0, 0, 0.34 * LY.u, 0.3 * LY.u, 0, 0, 7); ctx.fill(); }
        else for (const c of q.cells) { ctx.fillStyle = TYPES[q.ty].col; ctx.fillRect((c[0] - 0.5) * LY.u, (-c[1] - 0.5) * LY.u, LY.u, LY.u); ctx.strokeStyle = 'rgba(30,18,10,.8)'; ctx.strokeRect((c[0] - 0.5) * LY.u, (-c[1] - 0.5) * LY.u, LY.u, LY.u); }
        ctx.restore();
      }
      drawGauge(ctx, th, p, w.sl);
      drawChips(ctx);
      drawWeather(ctx);
      drawDock(ctx, tsec);
    }
    let rain = null;
    function weatherFx(x, tsec, dt) {
      const R = st.R, W = LY.W, H = LY.dockY;
      if (R !== 3 && R !== 4 && R !== 5) return;
      if (!rain) { const r2 = rng(5); rain = []; for (let k = 0; k < 40; k++) rain.push({ x: r2() * W, y: r2() * H, s: 0.5 + r2() }); }
      const wv = weatherNow(st).w;
      if (R === 3) {
        x.strokeStyle = 'rgba(180,190,230,.35)'; x.lineWidth = 1; x.beginPath();
        for (const d of rain) { d.y += 520 * d.s * dt; d.x += wv * 40 * dt; if (d.y > H) { d.y = LY.sceneTop; d.x = Math.random() * W; } x.moveTo(d.x, d.y); x.lineTo(d.x + wv * 2, d.y + 10 * d.s); }
        x.stroke();
        if (Math.sin(tsec * 0.9) > 0.995) { x.fillStyle = 'rgba(220,220,255,.18)'; x.fillRect(0, 0, W, LY.H); }
      } else {
        x.fillStyle = R === 4 ? 'rgba(90,80,76,.6)' : 'rgba(255,255,255,.75)';
        for (const d of rain) { d.y += (R === 4 ? 26 : 34) * d.s * dt; d.x += (wv * 14 + Math.sin(tsec + d.s * 9) * 8) * dt; if (d.y > H) { d.y = LY.sceneTop; d.x = Math.random() * W; } if (d.x < 0) d.x += W; if (d.x > W) d.x -= W; x.beginPath(); x.arc(d.x, d.y, 1 + d.s, 0, 7); x.fill(); }
      }
    }

    stopLoop = U.loop((dt, now) => {
      frame++;
      if (anim) animStep(now, dt);
      if (!anim && !parts.length && (frame & 1)) return;   // idle: ~30 fps is plenty
      draw(now);
    });

    return {
      update(next, prev) {
        const relayout = !st || !LY;
        const fresh = prev && prev !== next && next.seq !== shownSeq && next.last && next.last.id === next.seq;
        st = next;
        if (relayout) layout();
        if (fresh) { pvKey = ''; startAnim(next); }
        else if (!anim) snap = snapFrom(next);
        if (!snap) snap = snapFrom(next);
        shownSeq = next.seq;
        updateHud();
        draw(performance.now());
      },
      destroy() {
        if (stopLoop) stopLoop(); stopLoop = null;
        clearTimeout(safety); setBusy(false);
        if (offInput) offInput();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.destroy(); hud.remove(); hint.remove(); trimBox.remove();
        for (const d of [spShip, spGauge, spDock, spWx, spHold, spChips]) d.remove();
      },
    };
  }

  /* ======================= register ======================= */
  L.register({
    id: 'airship', name: '비행선 화물 균형', tag: '균형 화물 싣기', cat: '파티',
    icon: '<ellipse cx="28" cy="17" rx="20" ry="10" fill="currentColor"/><path d="M12 22l2 9M44 22l-2 9" stroke="currentColor" stroke-width="2"/><path d="M9 31h38l-4 15H13z" fill="currentColor" opacity=".8"/><rect x="15" y="35" width="8" height="8" fill="#000" opacity=".35"/><rect x="24" y="38" width="12" height="5" fill="#000" opacity=".35"/><rect x="37" y="34" width="5" height="9" fill="#000" opacity=".35"/>',
    tint: '#2c4f7a',
    blurb: '하늘을 나는 비행선의 화물칸에 상자를 번갈아 실어요. 한쪽이 무거우면 기울고, 너무 기울면 상자가 떨어지거나 추락! 바람을 읽고 상대를 곤란하게 만드는 균형 수 싸움.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 800,
    options: [
      { id: 'route', label: '항로·날씨', choices: [{ v: 'r', label: '무작위' }].concat(ROUTES.map((o, k) => ({ v: String(k), label: o.n }))), def: 'r' },
      { id: 'len', label: '화물 수', choices: [{ v: '12', label: '짧게 (12)' }, { v: '16', label: '보통 (16)' }, { v: '20', label: '길게 (20)' }], def: '16' },
    ],
    controls: [
      { id: 'left', label: '왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'rot', label: '돌리기', keys: ['ArrowUp', 'KeyW', 'KeyR'], pad: ['y', 'up'] },
      { id: 'swap', label: '다른 상자 고르기', keys: ['Tab', 'KeyQ'], pad: ['lb', 'rb'] },
      { id: 'go', label: '싣기', keys: ['Space', 'ArrowDown', 'KeyS'], pad: ['a', 'down'] },
      { id: 'trim', label: '균형 조정 창', keys: ['KeyT'], pad: ['x'] },
    ],
    quick: [
      '비행선 화물칸에 상자를 번갈아 실어요. 한쪽이 무거우면 배가 기울어요.',
      '내 차례: 부두의 상자 2개 중 하나를 골라 자리(◀ ▶·끌기)와 방향(⟳)을 정하고 「싣기」. 게이지 점선이 실은 뒤 예상 기울기예요.',
      '실은 상자 점수(문 맞추면 +2)가 가장 높으면 승리! 30°를 넘겨 추락시킨 사람은 꼴찌. 혼자면 상자를 많이 배달해 ★을 모아요.',
    ],
    rules: [
      { h: '목표', p: [
        '하늘을 나는 화물 비행선이에요. 모두 같은 배에 상자를 하나씩 번갈아 실어요.',
        '여럿이 하면: 상자를 다 싣고 도착했을 때 내가 실은 상자 점수가 가장 높은 사람이 이겨요. 배를 추락시킨 사람은 바로 꼴찌!',
        '혼자 하면: 상자를 제대로(문 표시가 있으면 그쪽에) 배달한 개수로 ★을 받아요. 16개 기준 ★ 10개 · ★★ 14개 · ★★★ 16개 전부.'] },
      { h: '차례에 할 일', p: [
        '아래 부두에 상자 2개가 있어요. 탭해서 하나를 고르세요(남은 하나는 다음 사람에게 가요).',
        '화물칸을 탭하거나 좌우로 끌어서(또는 ◀ ▶) 떨어뜨릴 자리를 고르고, ⟳로 방향을 바꿔요. 상자는 위에서 곧장 아래로 떨어져 쌓여요.',
        '반투명 상자 = 놓일 자리, 게이지의 노란 점선 = 실은 뒤 예상 기울기, 노란 부채꼴 = 흔들릴 수 있는 범위예요. 마음에 들면 「싣기」!',
        '또는 「⚖ 조정」: 상자 대신 균형을 잡아요(한 판에 2번, 혼자는 3번). 이때 상자는 다음 사람에게 그대로 넘어가요.'] },
      { h: '기울기와 균형', p: [
        '노란 점(●) = 무게중심, 흰 동그라미(○) = 균형점이에요. 배는 무게중심이 균형점 바로 아래 점선에 오도록 기울어요.',
        '게이지: 초록(10° 아래) 안전 · 노랑 조심 · 빨강(15° 넘음)이면 위가 비어 있는 상자가 낮은 쪽으로 미끄러져요. 30°를 넘으면 추락!',
        '아래 4줄은 벽이 있어서 미끄러져도 벽에 막혀요. 맨 위 2줄(점선 칸)은 열린 갑판이라 밖으로 밀리면 떨어져요(떨어뜨린 사람 −2점).',
        '높이 쌓을수록 배가 잘 흔들려요. 무게중심이 균형점보다 높아지면 와르르! 무거운 상자는 아래쪽, 가운데 가까이에.',
        '상자를 실으면 배가 한 번 출렁여요(멈출 기울기보다 조금 더 기울어요). 미리보기에 다 계산돼 있어요.'] },
      { h: '상자', p: [
        '상자 숫자 = 무게, 점수 = 대체로 무게만큼(작은 1 · 긴 2 · ㄱ자/막대 3 · 큰/ㅗ자 4).',
        '◀/▶ 표시 상자는 배의 그쪽 절반(가운데 줄 빼고)에 있으면 +2점(초록 표시). 끝날 때 기준이라 미끄러지면 바뀔 수 있어요.',
        '💧 액체 탱크(무게 3·4점): 물이 낮은 쪽으로 쏠려 더 기울게 해요. 🎈 풍선 상자(무게 −1·2점): 놓은 쪽을 살짝 들어 올려요.',
        '⚓ 닻(무게 5·3점): 아주 무겁지만 절대 미끄러지지 않아요. 🐑 동물 상자(무게 3·4점): 양이 매 차례 끝에 반대쪽 칸으로 폴짝 옮겨요(→ 표시).'] },
      { h: '조정 (⚖)', p: [
        '🎒 모래주머니 버리기: 배 양옆에 3개씩. 버린 쪽이 가벼워져 올라가요. 버리면 끝(되돌릴 수 없어요).',
        '🎈 가스 옮기기: 기구 안 가스를 한쪽으로 옮겨 그쪽을 들어 올려요(양쪽 3칸까지). 다음 사람이 되돌릴 수도 있어요.'] },
      { h: '날씨 (항로)', p: [
        '바람·돌풍은 위 날씨 줄에 미리 보이고, 미리보기에도 들어가 있어요. 난기류(±)는 운이라서 노란 부채꼴만큼 더 흔들릴 수 있어요.',
        '잔잔한 하늘 · 돌풍 계곡(3차례마다 센 돌풍) · 갈지자 해협(바람이 번갈아) · 폭풍 전선(바람이 점점 셈, 난기류 큼) · 화산재 구름(기구 위에 재가 쌓여 무거워짐) · 얼음 구름(11°부터 미끄러짐).'] },
      { h: '예시', p: [
        '배가 왼쪽으로 8° 기울어 있어요. 부두에 ◀닻과 ▶큰 상자가 있으면, 큰 상자를 오른쪽에 실어 +4점에 문 보너스 +2, 배도 바로 서요.',
        '그러면 다음 사람은 ◀닻을 받아요. 왼쪽에 실으면 다시 기울고 문 보너스를 받지만, 배가 이미 높이 쌓였다면 추락 위험! 이렇게 상대를 곤란하게 만드는 게 수 싸움이에요.'] },
      { h: '조작', p: [
        '탭/끌기 = 자리 고르기, ⟳ = 돌리기, 부두 상자 탭 = 상자 고르기, 「싣기」 = 확정. 추락이 예상되면 「싣기」를 한 번 더 눌러야 해요.',
        'PC: ← → 자리, ↑ 돌리기, Tab 상자 바꾸기, Space 싣기, T 조정 (「⌨ 조작 설정」에서 바꿀 수 있어요).',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움 AI는 난기류 최악의 경우와 다음 사람이 받을 상자까지 계산해요.'] },
    ],
    tutorial: [
      { sel: '.as-ship', text: '하늘을 나는 화물 비행선이에요! 화물칸에 상자를 번갈아 실어요. 한쪽이 무거우면 배가 기울어요.' },
      { sel: '.as-gauge', text: '기울기 게이지. 초록 = 안전, 노랑 = 조심, 빨강 = 위가 빈 상자가 미끄러져요. 30°를 넘으면 추락!' },
      { sel: '.as-dock', text: '부두의 상자 2개 중 하나를 골라요. 숫자 = 무게, ◀/▶ = 그쪽 절반에 실으면 +2점. 남은 상자는 다음 사람 몫!' },
      { sel: '.as-hold', text: '화물칸을 탭하거나 좌우로 끌어 자리를 고르고 ⟳로 돌려요. 반투명 상자와 게이지 점선이 "실으면 이렇게 기운다" 미리보기예요.' },
      { sel: '.as-go', text: '마음에 들면 「싣기」! 높이 쌓을수록 잘 흔들리니 무거운 건 아래로, 가운데 가까이.' },
      { sel: '.as-trim', text: '⚖ 조정: 상자 대신 모래주머니를 버리거나 가스를 옮겨 균형을 잡아요. 기회는 한 판에 2번(혼자 3번).' },
      { sel: '.as-wx', text: '날씨 줄: 바람·돌풍은 미리 보이고, 난기류(±)는 운이에요. 상대가 곤란한 상자를 받도록 머리를 써 봐요!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { TYPES, ROUTES, wx, dec, encG, encP, doorOK, delivered, deliveredN, starNeed, dockType, dockDoor, dockN, candidates, simNew, simStep, simRun, placements, dropRow, shapeOf, scoreOf, aboard, stars, evFor, weatherNow, GW, GH, DEG },
  });
})();
