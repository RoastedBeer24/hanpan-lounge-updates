/* 꼬마 기차 선로 바꾸기 — realtime train-routing game (1–4) + solo stage mode with stars.
   A wooden toy railway seen from above (7×10 cells). Coloured trains roll out of tunnels; tap junction switches so every
   train reaches the station of its own colour (and emblem). Tap a train to hold it for 3 s (level crossings!).
   Everyone plays the same layout and the same train schedule (same seed) on their own board at the same time; the host
   (or local device) also simulates the AI boards. Guests publish a score row, the host relays rows and ends the match
   with setState (cooking.js / pinball.js / tiltmaze.js pattern). Solo: pick one of 15 stages, 3 hearts, stars = hearts left.
   Track model: every cell holds directed pairs (entry edge → exit edge). Two pairs with the same entry = a switch
   (tappable), same exit = a merge (trains give way automatically), no shared edge = a crossing (level crossing → crash
   hazard, or a bridge). Trains keep their distance automatically on the same line; only level crossings can crash. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2, QA = Math.PI / 4;

  /* ======================= geometry ======================= */
  const GW = 7, GH = 10, HZ = 60, DT = 1 / HZ;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0], DIRS = { N: 0, E: 1, S: 2, W: 3 };
  const EMX = [0.5, 1, 0.5, 0], EMY = [0, 0.5, 1, 0.5], DANG = [-Math.PI / 2, 0, Math.PI / 2, Math.PI];
  const opp = (e) => (e + 2) & 3;
  const isStr = (a, b) => ((a + 2) & 3) === b;
  const PL = (a, b) => (isStr(a, b) ? 1 : QA);
  const CURVE = [];
  for (let a = 0; a < 4; a++) for (let b = 0; b < 4; b++) {
    if (a === b || isStr(a, b)) continue;
    const ew = a & 1 ? a : b, ns = a & 1 ? b : a;
    const kx = ew === 1 ? 1 : 0, ky = ns === 2 ? 1 : 0;
    const ta = Math.atan2(EMY[a] - ky, EMX[a] - kx), tb = Math.atan2(EMY[b] - ky, EMX[b] - kx);
    let dt = tb - ta; while (dt > Math.PI) dt -= TAU; while (dt < -Math.PI) dt += TAU;
    CURVE[a * 4 + b] = { kx, ky, ta, dt };
  }
  function posAt(c, a, b, p, o) {   // point + heading on the pair (a→b) of cell c at progress p (cell units)
    const cx = c % GW, cy = (c / GW) | 0;
    if (isStr(a, b)) { o.x = cx + EMX[a] + (EMX[b] - EMX[a]) * p; o.y = cy + EMY[a] + (EMY[b] - EMY[a]) * p; o.r = DANG[b]; return o; }
    const k = CURVE[a * 4 + b], th = k.ta + k.dt * p;
    o.x = cx + k.kx + 0.5 * Math.cos(th); o.y = cy + k.ky + 0.5 * Math.sin(th); o.r = th + (k.dt > 0 ? Math.PI / 2 : -Math.PI / 2);
    return o;
  }

  /* ======================= look ======================= */
  const COL = ['#e5534b', '#3b82d6', '#f2c12e', '#3fae5a', '#9b5fd6', '#f0862a'];
  const COLD = ['#a8322c', '#245ea3', '#b88a12', '#277a3c', '#6c3aa3', '#b35c14'];
  const CNAME = ['빨강', '파랑', '노랑', '초록', '보라', '주황'];
  const SNAME = ['동그라미', '네모', '세모', '별', '마름모', '십자'];

  /* ======================= trains ======================= */
  const TN = 0, TX = 1, TF = 2, TR = 3;                  // normal · express · freight · reverse
  const SPF = [1, 1.45, 0.8, 0.95];
  const CARS = [[['L', 0.55], ['C', 0.47]], [['X', 0.6], ['C', 0.47]], [['L', 0.55], ['F', 0.47], ['F', 0.47]], [['C', 0.47], ['R', 0.55]]];
  const CGAP = 0.06;
  const TLEN = CARS.map((cs) => cs.reduce((s, c) => s + c[1], 0) + CGAP * (cs.length - 1));
  const TYNAME = ['', '급행', '화물', '거꾸로'];
  const GAP = 0.22, CLAIM_D = 0.9, STOP_T = 3, READY_T = 3.4, LOST_D = 24;

  /* ======================= layouts =======================
     lines: 'T x,y moves end' = tunnel at a border cell; 'B x,y moves end' = branch out of an existing cell (makes a switch).
     moves: N/E/S/W steps. end: station colour 0–5, or M = merge into the existing last cell.
     br: crossing cells that are bridges. wa: decorative water cells (tracks over water are drawn as trestles). */
  const LAYS = [
    { n: '첫 갈림길', t: 0, lines: ['T3,0 SSSWWSSSSSS 0', 'B3,3 EESSSSSS 1'], wa: '2,6 3,6 4,6 3,7',
      tip: '스위치를 누르면 화살표가 바뀌어요. 기차 색과 같은 색 역으로 보내 주세요!' },
    { n: '세 갈래 길', t: 0, lines: ['T3,0 SSWWSSSSSSS 0', 'B3,2 EESSSSSSS 2', 'B5,5 WWSSSS 1'], wa: '2,4 3,4 4,4',
      tip: '갈림길이 두 개! 기차가 오기 전에 미리 바꿔 두면 편해요.' },
    { n: '옆문 터널', t: 0, lines: ['T0,2 EEEEESSSSSSS 1', 'B2,2 SSSWSSSS 0', 'B5,5 E 2'], wa: '3,5 3,6 4,6 3,7',
      tip: '금색 줄무늬 급행 기차는 빨라요. 터널 앞 표지판으로 다음 기차를 미리 봐요.' },
    { n: '연못 한 바퀴', t: 0, lines: ['T3,0 SSWWSSSSSSS 0', 'B3,2 EESSSSSSS 3', 'B1,7 EESS 1', 'B5,6 E 2'], wa: '2,4 3,4 4,4 2,5 3,5 4,5',
      tip: '화물 기차는 길어요. 기차가 스위치 위에 있을 땐 못 바꾸지만, 눌러 두면 지나가자마자 바뀌어요(예약).' },
    { n: '거꾸로 나무', t: 1, lines: ['T3,9 NNWWNNNNNNN 0', 'B1,5 EENNNNN 1', 'B3,7 EENNNNNNN 3', 'B5,4 WNNNN 2'], wa: '0,8 1,8 0,9 1,9',
      tip: '이번엔 터널이 아래에 있어요. 기차가 위쪽 역으로 올라가요.' },
    { n: '돌아오는 고리', t: 1, lines: ['T3,0 SSSSSSSSS 1', 'B3,3 WWSSSSSS 0', 'B3,6 EENNNNNWW M', 'B5,4 E 2', 'B3,8 EES 3'], wa: '4,3 4,4',
      tip: '고리 선로! 잘못 들어가도 한 바퀴 돌아 다시 기회가 와요. 오른쪽 역은 고리를 지나야 가요.' },
    { n: '다리 건너기', t: 1, lines: ['T1,0 SSSSEEEESSSSS 3', 'T5,0 SSWWSSSSWWSSS 0', 'B1,3 WSSSSSS 1', 'B5,2 ESSSSSSS 2'], br: '3,4', wa: '3,7 4,7 2,8 3,8 4,8',
      tip: '터널이 두 개! 가운데 다리에서는 위아래로 지나가서 부딪히지 않아요.' },
    { n: '두 터널 합류', t: 1, lines: ['T0,1 EEESSSSSSSS 1', 'T6,1 WWW M', 'B3,3 WWSSSSSS 0', 'B3,5 EESSSS 3', 'B5,7 ESS 2'], wa: '4,7 4,8 0,5 0,6',
      tip: '양쪽 터널 기차가 한 길로 모여요. 합류하는 곳에서는 기차들이 알아서 양보해요.' },
    { n: '강 건너 마을', t: 1, lines: ['T3,0 SSWWSSSSSSS 0', 'B3,2 EESSSSSSS 4', 'B1,3 W 1', 'B5,3 E 3', 'B1,7 EESS 2'], wa: '0,5 1,5 2,5 3,5 4,5 5,5 6,5',
      tip: '거꾸로 기차(기관차가 뒤에서 밀어요)는 스위치 화살표 반대쪽으로 가요!' },
    { n: '건널목', t: 2, lines: ['T0,2 EESSEEESSSSS 3', 'T4,0 SSSSSSWWWSSS 0', 'B5,6 ESSS 2', 'B4,2 EE 4', 'B2,6 SSS 1'], wa: '0,6 0,7',
      tip: '건널목(✕)에서 두 기차가 같이 지나가면 쾅! 위험하면 기차를 눌러 3초 세워요.' },
    { n: '여섯 역', t: 2, lines: ['T3,0 SSWWSSSSSSS 0', 'B1,4 WSSSSS 1', 'B1,6 ESSS 2', 'B3,2 EESSSSSSS 5', 'B5,4 ESSSSS 4', 'B5,6 WSSS 3'], wa: '3,5 3,6 3,7',
      tip: '역이 여섯 개! 색이 헷갈리면 지붕의 모양 표시를 봐요.' },
    { n: '빙글빙글 순환선', t: 2, lines: ['T3,0 SSEESSSSSWWWWNNNNNEE M', 'T6,8 WN M', 'B5,4 E 1', 'B5,6 E 3', 'B3,7 SS 2', 'B2,7 SS 4', 'B1,5 W 0'], wa: '2,4 3,4 4,4 2,5 3,5 4,5',
      tip: '빙글빙글 순환선. 기차는 시계 방향으로 돌아요. 놓쳐도 한 바퀴 돌면 다시 기회!' },
    { n: '세 터널', t: 2, lines: ['T3,0 SSSSSSSSS 2', 'T6,2 WWW M', 'T0,4 EEEEESSSSS 4', 'B3,6 WWSSS 0', 'B3,7 ESS 3', 'B5,6 ESSS 5', 'B1,4 NNNN 1'], wa: '5,0 6,0',
      tip: '터널이 세 개! 가운데 건널목과 붙어 있는 스위치 두 개를 조심해요.' },
    { n: '8자 다리', t: 2, lines: ['T0,2 EEESSSSSSWWNNNEEEENNNWW M', 'B3,7 ESS 2', 'B1,6 WSSS 0', 'B5,4 E 3', 'B2,8 S 1', 'B4,2 NN 4'], br: '3,5', wa: '2,6 2,7',
      tip: '8자 모양 선로. 가운데는 다리라서 안전해요. 놓친 기차는 8자를 한 바퀴 돌아요.' },
    { n: '기차 대소동', t: 2, lines: ['T5,0 SWWSSSSWWSSSS 0', 'T1,0 SSSEEEESSSSSS 4', 'B3,5 SEEESSS 5', 'B5,7 WSS 3', 'B1,7 ESS 2', 'B1,2 WSSSSSSS 1'], wa: '3,7 3,8 3,9',
      tip: '건널목이 두 군데! 두 기차가 동시에 다가오면 한 대를 눌러 세워요.' },
  ];
  // per-stage difficulty: n trains (solo), speed cells/s [start, end], spawn gap s [start, end], special odds [express, freight, reverse]
  const STG = [
    { n: 10, v: [0.8, 1.05], g: [5.2, 4.0], sp: [0, 0, 0] },
    { n: 12, v: [0.85, 1.15], g: [4.8, 3.6], sp: [0, 0, 0] },
    { n: 14, v: [0.9, 1.25], g: [4.6, 3.3], sp: [0.18, 0, 0] },
    { n: 16, v: [0.95, 1.3], g: [4.4, 3.0], sp: [0.14, 0.14, 0] },
    { n: 16, v: [0.95, 1.35], g: [4.2, 2.9], sp: [0.14, 0.14, 0] },
    { n: 18, v: [1.0, 1.4], g: [4.0, 2.8], sp: [0.14, 0.14, 0] },
    { n: 18, v: [1.0, 1.4], g: [3.6, 2.5], sp: [0.14, 0.14, 0] },
    { n: 18, v: [1.0, 1.45], g: [3.6, 2.5], sp: [0.14, 0.14, 0] },
    { n: 20, v: [1.05, 1.5], g: [3.6, 2.5], sp: [0.13, 0.13, 0.14] },
    { n: 20, v: [1.05, 1.5], g: [3.6, 2.5], sp: [0.13, 0.13, 0.1] },
    { n: 22, v: [1.1, 1.6], g: [3.4, 2.3], sp: [0.14, 0.14, 0.1] },
    { n: 22, v: [1.1, 1.6], g: [3.4, 2.3], sp: [0.14, 0.14, 0.1] },
    { n: 24, v: [1.1, 1.65], g: [3.2, 2.2], sp: [0.15, 0.15, 0.1] },
    { n: 24, v: [1.15, 1.7], g: [3.2, 2.2], sp: [0.15, 0.15, 0.12] },
    { n: 26, v: [1.15, 1.75], g: [3.0, 2.1], sp: [0.15, 0.15, 0.12] },
  ];
  const TIERS = [0, 1, 2].map((t) => LAYS.map((D, i) => (D.t === t ? i : -1)).filter((i) => i >= 0));

  function xy(s) { const [x, y] = s.split(',').map(Number); return [x, y]; }
  function parseLay(D) {
    const N = GW * GH, cells = new Array(N).fill(null);
    const get = (x, y) => { if (x < 0 || y < 0 || x >= GW || y >= GH) throw new Error(D.n + ': off board ' + x + ',' + y); const i = y * GW + x; return cells[i] || (cells[i] = { i, x, y, pr: [], st: -1, tun: -1 }); };
    const addPair = (c, a, b) => { if (a === b) throw new Error(D.n + ': u-turn at ' + c.x + ',' + c.y); if (!c.pr.some((p) => p.a === a && p.b === b)) c.pr.push({ a, b }); };
    const tun = [], sta = [];
    for (const ln of D.lines) {
      const [s, mv, z] = ln.split(' ');
      const [x0, y0] = xy(s.slice(1));
      let x = x0, y = y0, ein;
      const c0 = get(x, y);
      if (s[0] === 'T') {
        ein = y === 0 ? 0 : y === GH - 1 ? 2 : x === 0 ? 3 : x === GW - 1 ? 1 : -1;
        if (ein < 0 || c0.pr.length) throw new Error(D.n + ': bad tunnel ' + s);
        if (DIRS[mv[0]] !== opp(ein)) throw new Error(D.n + ': tunnel must be straight ' + s);
        c0.tun = tun.length; tun.push({ c: c0.i, a: ein });
      } else {
        const eins = [...new Set(c0.pr.map((p) => p.a))];
        if (eins.length !== 1) throw new Error(D.n + ': bad branch ' + s);
        ein = eins[0];
      }
      let cur = c0;
      for (const ch of mv) {
        const d = DIRS[ch];
        if (d == null) throw new Error(D.n + ': bad move ' + ch);
        addPair(cur, ein, d);
        x += DX[d]; y += DY[d];
        cur = get(x, y); ein = opp(d);
      }
      if (z === 'M') {
        const eouts = [...new Set(cur.pr.map((p) => p.b))];
        if (eouts.length !== 1) throw new Error(D.n + ': bad merge ' + ln);
        addPair(cur, ein, eouts[0]);
      } else {
        if (cur.pr.length) throw new Error(D.n + ': station on track ' + ln);
        addPair(cur, ein, opp(ein)); cur.st = sta.length; sta.push({ c: cur.i, k: +z, a: ein });
      }
    }
    const brs = (D.br || '').split(' ').filter(Boolean).map((q) => { const [x, y] = xy(q); return y * GW + x; });
    const water = new Array(N).fill(0);
    (D.wa || '').split(' ').filter(Boolean).forEach((q) => { const [x, y] = xy(q); water[y * GW + x] = 1; });
    // classify: 0 none, 1 plain, 2 switch, 3 merge, 4 crossing, 5 bridge
    const kind = new Array(N).fill(0), swOf = new Array(N).fill(-1), sws = [], cross = [];
    cells.forEach((c) => {
      if (!c) return;
      if (c.pr.length === 1) kind[c.i] = 1;
      else if (c.pr.length === 2) {
        const [p, q] = c.pr;
        if (p.a === q.a) { kind[c.i] = 2; }
        else if (p.b === q.b) kind[c.i] = 3;
        else if (new Set([p.a, p.b, q.a, q.b]).size === 4) { kind[c.i] = brs.includes(c.i) ? 5 : 4; if (kind[c.i] === 4) cross.push(c.i); }
        else throw new Error(D.n + ': bad junction ' + c.x + ',' + c.y);
      } else throw new Error(D.n + ': too many pairs ' + c.x + ',' + c.y);
      if (c.st >= 0 && c.pr.length !== 1) throw new Error(D.n + ': station junction');
    });
    cells.filter((c) => c && kind[c.i] === 2).sort((u, v) => u.y - v.y || u.x - v.x).forEach((c) => {
      swOf[c.i] = sws.length; sws.push({ c: c.i, a: c.pr[0].a, br: [c.pr[0].b, c.pr[1].b] });
    });
    // connectivity
    cells.forEach((c) => {
      if (!c || c.st >= 0) return;
      for (const p of c.pr) {
        const nx = c.x + DX[p.b], ny = c.y + DY[p.b];
        const n = nx >= 0 && ny >= 0 && nx < GW && ny < GH ? cells[ny * GW + nx] : null;
        if (!n || !n.pr.some((q) => q.a === opp(p.b))) throw new Error(D.n + ': dangling track at ' + c.x + ',' + c.y);
      }
    });
    const pr = cells.map((c) => (c ? c.pr : null));
    const LD = { n: D.n, tip: D.tip, t: D.t, pr, kind, swOf, sws, cross, tun, sta, water, stOf: cells.map((c) => (c ? c.st : -1)), tunOf: cells.map((c) => (c ? c.tun : -1)) };
    // shortest distance from a state (cell, entry edge) to each station colour
    const S = N * 4, INF = 1e9;
    LD.dist = [];
    for (let k = 0; k < 6; k++) {
      const d = new Float32Array(S).fill(INF);
      const st = sta.find((q) => q.k === k);
      if (st) {
        d[st.c * 4 + st.a] = 0.5;
        for (let it = 0, ch = true; ch && it < 200; it++) {
          ch = false;
          for (let c = 0; c < N; c++) {
            const ps = pr[c]; if (!ps || LD.stOf[c] >= 0) continue;
            for (const p of ps) {
              const nc = c + DX[p.b] + DY[p.b] * GW, ns = nc * 4 + opp(p.b);
              const v = PL(p.a, p.b) + d[ns];
              if (v < d[c * 4 + p.a] - 1e-6) { d[c * 4 + p.a] = v; ch = true; }
            }
          }
        }
      }
      LD.dist.push(d);
    }
    LD.reach = tun.map((t) => sta.filter((q) => LD.dist[q.k][t.c * 4 + t.a] < INF).map((q) => q.k));
    tun.forEach((t, i) => { if (LD.reach[i].length < 2) throw new Error(D.n + ': tunnel ' + i + ' reaches < 2 stations'); });
    // every reachable state must be able to reach some station
    const seen = new Uint8Array(S), q = tun.map((t) => t.c * 4 + t.a);
    q.forEach((s) => { seen[s] = 1; });
    while (q.length) {
      const s = q.pop(), c = s >> 2, a = s & 3;
      if (!sta.some((z) => LD.dist[z.k][s] < INF)) throw new Error(D.n + ': dead end from ' + (c % GW) + ',' + ((c / GW) | 0));
      if (LD.stOf[c] >= 0) continue;
      for (const p of pr[c]) { if (p.a !== a) continue; const nc = c + DX[p.b] + DY[p.b] * GW, ns = nc * 4 + opp(p.b); if (!seen[ns]) { seen[ns] = 1; q.push(ns); } }
    }
    LD.used = seen;
    return LD;
  }
  const PARSED = [];
  function lay(i) { return PARSED[i] || (PARSED[i] = parseLay(LAYS[i])); }
  const swCell = (LD, s) => LD.sws[s].c;
  function nextCell(c, b) { return c + DX[b] + DY[b] * GW; }
  // exit edge chosen when entering cell c through edge a with the switch states sw (rev: reverse train)
  function exitOf(LD, sw, c, a, rev) {
    const ps = LD.pr[c]; if (!ps) return -1;
    const si = LD.swOf[c];
    if (si >= 0 && LD.sws[si].a === a) return LD.sws[si].br[sw[si] ^ (rev ? 1 : 0)];
    for (const p of ps) if (p.a === a) return p.b;
    return -1;
  }
  function bestBranch(LD, si, k) {   // branch index that leads to station colour k (−1 = neither)
    const S = LD.sws[si], d = LD.dist[k];
    const v = S.br.map((b) => PL(S.a, b) + d[nextCell(S.c, b) * 4 + opp(b)]);
    if (v[0] >= 1e8 && v[1] >= 1e8) return -1;
    return v[0] <= v[1] ? 0 : 1;
  }

  /* ======================= schedule ======================= */
  function mkRng(seed) {
    let a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function genSched(li, n, seed) {
    const P = STG[li], LD = lay(li), r = mkRng((seed ^ (li * 7919 + 17)) >>> 0), out = [];
    let l1 = -1, l2 = -1;
    for (let i = 0; i < n; i++) {
      const f = n > 1 ? i / (n - 1) : 0;
      const tn = LD.tun.length > 1 ? Math.floor(r() * LD.tun.length) : 0;
      const ks = LD.reach[tn];
      let k = ks[Math.floor(r() * ks.length)];
      if (k === l1 && k === l2) k = ks[(ks.indexOf(k) + 1 + Math.floor(r() * (ks.length - 1))) % ks.length];
      let ty = TN; const x = r(), sp = P.sp;
      if (i >= 2) { if (x < sp[0]) ty = TX; else if (x < sp[0] + sp[1]) ty = TF; else if (x < sp[0] + sp[1] + sp[2]) ty = TR; }
      const g = i === 0 ? 0.3 : (P.g[0] + (P.g[1] - P.g[0]) * f) * (0.8 + 0.4 * r());
      out.push({ tn, k, ty, g, v: P.v[0] + (P.v[1] - P.v[0]) * f });
      l2 = l1; l1 = k;
    }
    return out;
  }

  /* ======================= board simulation ======================= */
  function newBoard(li, n, seed, solo) {
    const LD = lay(li);
    return { li, L: LD, sched: genSched(li, n, seed), qi: 0, clk: 0, sw: LD.sws.map(() => 0), rq: LD.sws.map(() => 0),
      tr: [], nid: 1, sc: 0, stk: 0, ok: 0, bad: 0, cr: 0, hp: solo ? 3 : -1, solo: !!solo, res: 0, n,
      ph: 'ready', tm: READY_T, t: 0, acc: 0, ev: [], busy: new Uint8Array(GW * GH), stall: 0, ghost: 0, ai: null };
  }
  function occOf(T) {   // cells covered by the train: [[cell, a, b, p0, p1], …] head first
    const out = [], hl = PL(T.a, T.b);
    let rem = T.len - T.p * hl;
    out.push([T.c, T.a, T.b, Math.max(0, T.p - T.len / hl), Math.min(1, T.p)]);
    for (let i = 0; i < T.trail.length && rem > 0; i++) {
      const e = T.trail[i], l = PL(e[1], e[2]);
      out.push([e[0], e[1], e[2], Math.max(0, 1 - rem / l), 1]);
      rem -= l;
    }
    return out;
  }
  function spawn(B, h) {
    if (B.qi >= B.sched.length) return;
    B.clk += h;
    const q = B.sched[B.qi];
    if (B.clk < q.g) return;
    const tu = B.L.tun[q.tn];
    if (B.busy[tu.c]) return;
    for (const T of B.tr) if (T.c === tu.c) return;
    const b = exitOf(B.L, B.sw, tu.c, tu.a, q.ty === TR);
    const T = { id: B.nid++, k: q.k, ty: q.ty, c: tu.c, a: tu.a, b, p: 0, v: q.v * SPF[q.ty] * 0.85, vm: q.v * SPF[q.ty], len: TLEN[q.ty], trail: [], stopT: 0, dl: false, oc: null, tn: q.tn, od: 0, lim: B.L.dist[q.k][tu.c * 4 + tu.a] + LOST_D };
    T.oc = occOf(T);
    B.tr.push(T); B.qi++; B.clk = 0;
    B.ev.push({ k: 'spawn', c: tu.c, col: q.k, ty: q.ty });
  }
  function isJunction(LD, c) { const k = LD.kind[c]; return k === 2 || k === 3; }
  function freeAhead(B, me, lim, owner) {
    const LD = B.L;
    let c = me.c, a = me.a, b = me.b, d0 = -me.p * PL(a, b), best = lim;
    for (let k = 0; k < 4; k++) {
      const kd = LD.kind[c], pl = PL(a, b);
      if (k > 0 && isJunction(LD, c) && owner[c] && owner[c] !== me.id) best = Math.min(best, d0);
      for (const o of B.tr) {
        if (o === me) continue;
        for (const s of o.oc) {
          if (s[0] !== c || s[4] - s[3] < 1e-4) continue;
          const sameLane = s[1] === a && s[2] === b;
          if (!sameLane && (kd === 4 || kd === 5)) continue;   // other line through a crossing / bridge
          if (sameLane) { const g = d0 + s[3] * pl; if (k > 0 || s[3] >= me.p - 1e-6) best = Math.min(best, g); }
          else if (k > 0) best = Math.min(best, d0);
        }
      }
      if (best <= d0 + 1e-6 || d0 + pl >= lim || LD.stOf[c] >= 0) break;
      const nc = nextCell(c, b), na = opp(b), nb = exitOf(LD, B.sw, nc, na, me.ty === TR);
      if (nb < 0) break;
      d0 += pl; c = nc; a = na; b = nb;
    }
    return best;
  }
  function crash(B, A, C, c) {
    A.dead = C.dead = true;
    B.cr++; B.stk = 0; B.res += 2;
    if (B.solo) B.hp = Math.max(0, B.hp - 1); else B.sc = Math.max(0, B.sc - 10);
    B.ev.push({ k: 'crash', c, x: (c % GW) + 0.5, y: ((c / GW) | 0) + 0.5, a: A.k, b: C.k });
  }
  function deliver(B, T) {
    const st = B.L.sta[B.L.stOf[T.c]];
    T.dl = true; B.res++;
    const x = (T.c % GW) + 0.5, y = ((T.c / GW) | 0) + 0.5;
    if (st.k === T.k) {
      B.ok++; B.stk++;
      const pts = (T.ty ? 15 : 10) + Math.min(5, B.stk - 1);
      B.sc += pts;
      B.ev.push({ k: 'ok', c: T.c, x, y, col: T.k, pts, stk: B.stk });
    } else {
      B.bad++; B.stk = 0;
      if (B.solo) B.hp = Math.max(0, B.hp - 1);
      B.ev.push({ k: 'bad', c: T.c, x, y, col: T.k, st: st.k });
    }
  }
  function lost(B, T) {   // wandered far too long (loops) → back to the depot, counts as a miss
    T.dead = true; B.bad++; B.stk = 0; B.res++;
    if (B.solo) B.hp = Math.max(0, B.hp - 1);
    posAt(T.c, T.a, T.b, T.p, B.tmpP || (B.tmpP = {}));
    B.ev.push({ k: 'lost', x: B.tmpP.x, y: B.tmpP.y, col: T.k });
  }
  function step(B, h) {
    const LD = B.L;
    B.t += h;
    spawn(B, h);
    const trs = B.tr;
    // junction ownership: occupant first, else the nearest train about to enter (ties → lower id)
    const owner = B.own || (B.own = new Int32Array(GW * GH)), od = B.ownD || (B.ownD = new Float32Array(GW * GH));
    owner.fill(0);
    for (const T of trs) for (const s of T.oc) if (isJunction(LD, s[0]) && s[4] - s[3] > 1e-4 && (!owner[s[0]] || od[s[0]] > -1)) { owner[s[0]] = T.id; od[s[0]] = -2; }
    for (const T of trs) {
      if (LD.stOf[T.c] >= 0) continue;
      const nc = nextCell(T.c, T.b);
      if (!isJunction(LD, nc)) continue;
      const d = (1 - T.p) * PL(T.a, T.b);
      if (d > CLAIM_D) continue;
      if (!owner[nc] || (od[nc] > -1 && d < od[nc])) { owner[nc] = T.id; od[nc] = d; }
    }
    // speeds
    const ghost = B.ghost > 0;
    let moving = false, held = false;
    for (const T of trs) {
      let vt = T.stopT > 0 ? 0 : T.vm;
      if (T.stopT > 0) { T.stopT = Math.max(0, T.stopT - h); held = true; }
      if (!ghost && !T.dl) {
        const fd = freeAhead(B, T, 2.6, owner);
        if (fd < GAP) vt = 0; else vt = Math.min(vt, (fd - GAP) * 2.4);
      }
      if (T.dl) vt = Math.max(vt, T.vm * 0.8);
      const dv = vt - T.v;
      T.v += dv > 0 ? Math.min(dv, 2.2 * h) : Math.max(dv, -7 * h);
      if (T.v < 0) T.v = 0;
      if (T.v > 0.01) moving = true;
    }
    // stall guard (should never trigger on authored layouts)
    if (!moving && !held && trs.length) { B.stall += h; if (B.stall > 4) { B.ghost = 1.2; B.stall = 0; } } else B.stall = 0;
    if (B.ghost > 0) B.ghost -= h;
    // move
    for (const T of trs) {
      let d = T.v * h;
      T.od += d;
      while (d > 1e-9) {
        const pl = PL(T.a, T.b);
        if (LD.stOf[T.c] >= 0) { T.p += d / pl; d = 0; break; }
        const left = (1 - T.p) * pl;
        if (d < left) { T.p += d / pl; d = 0; break; }
        d -= left;
        const nc = nextCell(T.c, T.b), na = opp(T.b), nb = exitOf(LD, B.sw, nc, na, T.ty === TR);
        if (nb < 0) { T.p = 1; d = 0; T.dead = true; break; }
        T.trail.unshift([T.c, T.a, T.b]); if (T.trail.length > 4) T.trail.length = 4;
        T.c = nc; T.a = na; T.b = nb; T.p = 0;
      }
      if (LD.stOf[T.c] >= 0 && !T.dl && T.p >= 0.5) deliver(B, T);
      else if (!T.dl && !T.dead && T.od > T.lim) lost(B, T);
      T.oc = occOf(T);
    }
    // crashes on level crossings
    for (const X of LD.cross) {
      let A = null;
      for (const T of trs) {
        if (T.dead) continue;
        let on = null;
        for (const s of T.oc) if (s[0] === X && s[4] - s[3] > 0.02) { on = s; break; }
        if (!on) continue;
        if (A && (A[1][1] !== on[1] || A[1][2] !== on[2])) { crash(B, A[0], T, X); A = null; break; }
        if (!A) A = [T, on];
      }
    }
    // remove arrived / crashed trains
    for (let i = trs.length - 1; i >= 0; i--) {
      const T = trs[i];
      if (T.dead || (T.dl && T.p >= 0.5 + T.len + 0.05)) trs.splice(i, 1);
    }
    // occupied cells + reserved switch flips
    B.busy.fill(0);
    for (const T of trs) for (const s of T.oc) if (s[4] - s[3] > 1e-4) B.busy[s[0]] = 1;
    for (let s = 0; s < B.rq.length; s++) if (B.rq[s] && !B.busy[swCell(LD, s)]) { B.rq[s] = 0; B.sw[s] ^= 1; B.ev.push({ k: 'flip', s, auto: 1 }); }
    // end
    if ((B.solo && B.hp <= 0) || (B.qi >= B.sched.length && !trs.length) || B.t > 600) {
      B.ph = 'over';
      B.ev.push({ k: 'over', win: !B.solo || B.hp > 0 });
    }
  }
  function runFor(B, dt, maxSteps) {
    if (B.ph === 'over') return;
    B.acc += dt;
    let n = Math.floor(B.acc / DT);
    if (n > maxSteps) { n = maxSteps; B.acc = 0; } else B.acc -= n * DT;
    for (let i = 0; i < n && B.ph !== 'over'; i++) {
      if (B.ph === 'ready') { B.tm -= DT; if (B.tm <= 0) { B.ph = 'run'; B.ev.push({ k: 'go' }); } continue; }
      if (B.ai) aiStep(B, DT);
      step(B, DT);
    }
  }
  function tapSwitch(B, s) {
    if (!B || B.ph === 'over' || s < 0 || s >= B.sw.length) return 0;
    if (B.busy[swCell(B.L, s)]) { B.rq[s] ^= 1; B.ev.push({ k: 'rq', s, on: B.rq[s] }); return 2; }
    B.sw[s] ^= 1; B.rq[s] = 0; B.ev.push({ k: 'flip', s }); return 1;
  }
  function tapTrain(B, id) {
    const T = B && B.tr.find((q) => q.id === id);
    if (!T || T.dl || B.ph !== 'run') return 0;
    T.stopT = T.stopT > 0 ? 0 : STOP_T;
    B.ev.push({ k: T.stopT > 0 ? 'stop' : 'go2', id });
    return 1;
  }

  /* ======================= AI ======================= */
  const AIP = [null,
    { r: [0.9, 1.5], err: 0.2, slip: 0.06, H: 4, eta: 2.8, cx: 0 },
    { r: [0.55, 0.95], err: 0.12, slip: 0.03, H: 6, eta: 4.2, cx: 0.45 },
    { r: [0.16, 0.28], err: 0, slip: 0.006, H: 12, eta: 99, cx: 1 }];
  function aiInit(B, lv, seed) { const l = U.clamp(lv | 0, 1, 3); B.ai = { lv: l, P: AIP[l], r: mkRng(seed), cd: 0.6 + 0.4 * l, since: 0, held: {} }; }
  function walkWant(B, T, H, cb) {   // follow the route the train should take; cb(cell, a, b, distToEntry, switchIdx, wantedBranch)
    const LD = B.L;
    let c = T.c, b = T.b, d = (1 - T.p) * PL(T.a, T.b);
    for (let i = 0; i < H; i++) {
      if (LD.stOf[c] >= 0) return;
      const nc = nextCell(c, b), na = opp(b), si = LD.swOf[nc];
      let nb, want = -1;
      if (si >= 0 && LD.sws[si].a === na) {
        want = bestBranch(LD, si, T.k);
        nb = LD.sws[si].br[want >= 0 ? want : (B.sw[si] ^ (T.ty === TR ? 1 : 0))];
      } else nb = exitOf(LD, B.sw, nc, na, false);
      if (nb < 0) return;
      if (cb(nc, na, nb, d, si >= 0 && LD.sws[si].a === na ? si : -1, want) === false) return;
      d += PL(na, nb); c = nc; b = nb;
    }
  }
  function aiStep(B, h) {
    const A = B.ai;
    if (B.ph !== 'run') return;
    A.cd -= h; A.since += h;
    if (A.cd > 0) return;
    const acted = aiThink(B);
    A.cd = acted ? A.P.r[0] + (A.P.r[1] - A.P.r[0]) * A.r() : 0.08 + 0.12 * A.r() * (4 - A.lv);
  }
  function aiThink(B) {
    const A = B.ai, P = A.P, LD = B.L, ns = LD.sws.length;
    const want = new Array(ns).fill(-1), eta = new Array(ns).fill(1e9);
    for (const T of B.tr) {
      if (T.dl) continue;
      const v = Math.max(0.35, T.vm), wait = T.stopT;
      walkWant(B, T, P.H, (c, a, b, d, si, w) => {
        if (si < 0 || w < 0) return;
        const tt = d / v + wait;
        if (tt < eta[si]) { eta[si] = tt; want[si] = T.ty === TR ? 1 - w : w; }
      });
    }
    const since = A.since; A.since = 0;
    if (ns && A.r() < 1 - Math.exp(-P.slip * since)) { tapSwitch(B, Math.floor(A.r() * ns)); return true; }   // a slip of the finger
    let best = -1, bt = 1e9;
    for (let s = 0; s < ns; s++) {
      if (want[s] < 0 || eta[s] > P.eta) continue;
      const eff = B.rq[s] ? 1 - B.sw[s] : B.sw[s];
      if (eff === want[s]) continue;
      if (eta[s] < bt) { bt = eta[s]; best = s; }
    }
    if (best >= 0) {
      if (P.err && A.r() < P.err) best = (best + 1 + Math.floor(A.r() * Math.max(1, ns - 1))) % ns;   // wrong switch
      tapSwitch(B, best); return true;
    }
    // level crossings: hold the later train while another one passes
    if (LD.cross.length && P.cx && A.r() < P.cx) return aiCross(B);
    return false;
  }
  function crossWin(B, T, X, ignoreStop) {   // [tIn, tOut] (s) of train T over crossing X, or null
    for (const s of T.oc) if (s[0] === X && s[4] - s[3] > 0.01) { const rem = (1 - s[3]) * PL(s[1], s[2]) + 0.1; return [0, rem / Math.max(0.3, T.v), s[1], s[2], 1]; }
    let w = null;
    const v = Math.max(0.35, T.vm), wait = ignoreStop ? 0 : T.stopT;
    walkWant(B, T, 6, (c, a, b, d) => {
      if (c !== X) return;
      w = [d / v + wait, (d + PL(a, b) + T.len) / v + wait, a, b, 0];
      return false;
    });
    return w;
  }
  function aiCross(B) {
    const A = B.ai, LD = B.L;
    for (const X of LD.cross) {
      const ws = [];
      for (const T of B.tr) { if (T.dl) continue; const w = crossWin(B, T, X, false); if (w) ws.push([T, w]); }
      // resume held trains that would no longer clash
      for (const [T, w] of ws) {
        if (!(T.stopT > 0) || !A.held[T.id]) continue;
        const w0 = crossWin(B, T, X, true);
        if (!w0) continue;
        const clash = ws.some(([O, o]) => O !== T && (o[2] !== w0[2] || o[3] !== w0[3]) && o[0] < w0[1] + 0.35 && w0[0] < o[1] + 0.35);
        if (!clash) { tapTrain(B, T.id); delete A.held[T.id]; return true; }
      }
      for (let i = 0; i < ws.length; i++) for (let j = i + 1; j < ws.length; j++) {
        const [T1, a] = ws[i], [T2, b] = ws[j];
        if (a[2] === b[2] && a[3] === b[3]) continue;
        if (!(a[0] < b[1] + 0.35 && b[0] < a[1] + 0.35)) continue;
        const [L2, w2] = a[0] <= b[0] ? [T2, b] : [T1, a];
        if (w2[4] || L2.stopT > 0.4) continue;   // already on it / already held
        if (L2.stopT > 0) { L2.stopT = 0; }
        tapTrain(B, L2.id); A.held[L2.id] = 1; return true;
      }
    }
    return false;
  }

  /* ======================= pure game interface ======================= */
  function pickLayout(tier, rnd) {
    const r = rnd || Math.random;
    const pool = tier >= 0 && tier <= 2 ? TIERS[tier] : LAYS.map((_, i) => i);
    return pool[Math.floor(r() * pool.length)];
  }
  function init(players, opts) {
    const o = opts || {};
    const n = players.length, tier = [0, 1, 2, 3].includes(o.map) ? o.map : 1, cnt = [16, 24, 32].includes(o.cnt) ? o.cnt : 24;
    return { rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), tier, cnt,
      sd: 1 + U.rand(2147483646), ph: n === 1 ? 'pick' : 'play', li: n === 1 ? -1 : pickLayout(tier), res: null };
  }
  function trainsFor(s) { return s.n === 1 ? STG[s.li].n : s.cnt; }
  function finish(s, rows) {   // rows: [seat, score, ok, bad, crashes, hearts]
    const res = rows.slice().sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[4] - b[4] || a[0] - b[0]);
    return Object.assign({}, s, { ph: 'done', res });
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const LDn = LAYS[s.li] ? LAYS[s.li].n : '', tot = trainsFor(s);
    if (s.n === 1) {
      const r = s.res[0], stars = r[5] > 0 ? r[5] : 0;
      const head = (s.li + 1) + '. ' + LDn;
      if (!stars) return { winners: [], title: '다음에 다시!', text: head + '\n하트를 모두 잃었어요 · 맞게 보낸 기차 ' + r[2] + '대' };
      return { winners: [r[0]], title: '별 ' + stars + '개!', text: head + '\n' + '★'.repeat(stars) + '☆'.repeat(3 - stars) + '  기차 ' + tot + '대 중 ' + r[2] + '대 성공\n' + (stars === 3 ? '한 번도 안 틀렸어요!' : '남은 하트만큼 별을 받아요') };
    }
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top && r[2] === s.res[0][2] && r[4] === s.res[0][4]).map((r) => r[0]);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '점 · 성공 ' + r[2] + (r[3] ? ' · 틀림 ' + r[3] : '') + (r[4] ? ' · 쾅 ' + r[4] : ''));
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: LDn + ' · 기차 ' + tot + '대\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `
.tr-btn{position:absolute;height:44px;min-width:84px;padding:0 14px;border-radius:22px;z-index:3;background:rgba(23,19,31,.86);
  color:var(--ink,#f2e9d8);border:1.5px solid rgba(227,174,69,.72);font:700 13px var(--f-body,sans-serif);box-shadow:0 2px 10px rgba(0,0,0,.45);
  touch-action:manipulation;-webkit-user-select:none;user-select:none;cursor:pointer;white-space:nowrap}
.tr-btn.on{background:rgba(227,174,69,.92);color:#17131f}
.tr-btn:active{transform:translateY(1px)}
.tr-btn[hidden]{display:none}
.tr-pick{position:absolute;inset:0;z-index:4;overflow-y:auto;background:rgba(18,14,24,.96);padding:12px 12px 24px;-webkit-overflow-scrolling:touch;touch-action:pan-y}
.tr-pick h3{margin:2px 0 2px;font:400 20px var(--f-display,sans-serif);color:var(--ink,#f2e9d8)}
.tr-pick .sub{color:var(--muted,#ab9fb8);font:500 12px var(--f-body,sans-serif);margin:0 0 10px}
.tr-pick .tier{color:#e3ae45;font:700 12px var(--f-body,sans-serif);margin:12px 2px 6px}
.tr-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.tr-st{position:relative;display:flex;flex-direction:column;align-items:center;gap:2px;padding:7px 3px 6px;border-radius:12px;background:#2e2640;
  border:1.5px solid rgba(255,255,255,.06);color:var(--ink,#f2e9d8);font:600 11px var(--f-body,sans-serif);cursor:pointer;min-height:44px}
.tr-st:active{transform:translateY(1px)}
.tr-st.next{border-color:#e3ae45;box-shadow:0 0 0 2px rgba(227,174,69,.25)}
.tr-st canvas{border-radius:5px;display:block}
.tr-st .nm{line-height:1.15;text-align:center;word-break:keep-all;min-height:2.3em;display:flex;align-items:center}
.tr-st .stars{color:#ffd24a;letter-spacing:1px;font-size:11px;line-height:1}
.tr-st .stars i{color:rgba(242,233,216,.22);font-style:normal}
.tr-st .no{position:absolute;left:5px;top:3px;font:700 11px var(--f-mono,monospace);color:#e3ae45;text-shadow:0 1px 2px #000}
`;
  const KEYN = { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', ShiftLeft: 'Shift', ShiftRight: 'Shift', Space: '스페이스', Enter: 'Enter' };
  const keyName = (c) => KEYN[c] || String(c || '').replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, '');
  function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
  function mkC(w, h) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; }
  function circ(g, x, y, r) { g.beginPath(); g.arc(x, y, Math.max(0.001, r), 0, TAU); }
  function hexA(hex, a) { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; }
  function mix(hex, to, f) { const a = parseInt(hex.slice(1), 16), b = parseInt(to.slice(1), 16); const c = (s) => Math.round(((a >> s) & 255) * (1 - f) + ((b >> s) & 255) * f); return 'rgb(' + c(16) + ',' + c(8) + ',' + c(0) + ')'; }
  function emblemPath(g, k, x, y, r) {
    g.beginPath();
    switch (k) {
      case 0: g.arc(x, y, r * 0.82, 0, TAU); break;
      case 1: g.rect(x - r * 0.7, y - r * 0.7, r * 1.4, r * 1.4); break;
      case 2: g.moveTo(x, y - r * 0.9); g.lineTo(x + r * 0.88, y + r * 0.66); g.lineTo(x - r * 0.88, y + r * 0.66); g.closePath(); break;
      case 3: for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, q = i & 1 ? r * 0.42 : r * 0.95; if (i) g.lineTo(x + Math.cos(a) * q, y + Math.sin(a) * q); else g.moveTo(x + Math.cos(a) * q, y + Math.sin(a) * q); } g.closePath(); break;
      case 4: g.moveTo(x, y - r * 0.95); g.lineTo(x + r * 0.72, y); g.lineTo(x, y + r * 0.95); g.lineTo(x - r * 0.72, y); g.closePath(); break;
      default: { const t = r * 0.32; g.moveTo(x - t, y - r * 0.85); g.lineTo(x + t, y - r * 0.85); g.lineTo(x + t, y - t); g.lineTo(x + r * 0.85, y - t); g.lineTo(x + r * 0.85, y + t); g.lineTo(x + t, y + t); g.lineTo(x + t, y + r * 0.85); g.lineTo(x - t, y + r * 0.85); g.lineTo(x - t, y + t); g.lineTo(x - r * 0.85, y + t); g.lineTo(x - r * 0.85, y - t); g.lineTo(x - t, y - t); g.closePath(); }
    }
  }
  function trackPath(g, X, Y, s, a, b, off) {   // centre line (lateral offset off, cells) of pair a→b in the cell at px X,Y
    g.beginPath();
    if (isStr(a, b)) {
      const dx = EMX[b] - EMX[a], dy = EMY[b] - EMY[a], nx = -dy * off, ny = dx * off;
      g.moveTo(X + (EMX[a] + nx) * s, Y + (EMY[a] + ny) * s); g.lineTo(X + (EMX[b] + nx) * s, Y + (EMY[b] + ny) * s);
    } else { const k = CURVE[a * 4 + b]; g.arc(X + k.kx * s, Y + k.ky * s, Math.max(0.01, (0.5 + off) * s), k.ta, k.ta + k.dt, k.dt < 0); }
  }
  const WOOD = { edge: '#9b7243', base: '#e2c08a', hi: '#efd6a6', groove: '#8a6436', dim: '#b9a07a' };
  function paintPairs(g, list, s, dim) {   // list: [[X, Y, a, b], …] — wooden toy track pieces
    g.lineCap = 'butt';
    const st = (w, col, off) => { g.strokeStyle = col; g.lineWidth = w; for (const q of list) { trackPath(g, q[0], q[1], s, q[2], q[3], off || 0); g.stroke(); } };
    if (!dim) { g.save(); g.translate(s * 0.03, s * 0.06); st(s * 0.5, 'rgba(30,40,20,.22)'); g.restore(); }
    st(s * 0.48, dim ? '#8d7656' : WOOD.edge);
    st(s * 0.4, dim ? WOOD.dim : WOOD.base);
    if (!dim) st(s * 0.1, WOOD.hi, -0.12);
    st(Math.max(1, s * 0.05), dim ? 'rgba(90,70,45,.55)' : WOOD.groove, 0.1);
    st(Math.max(1, s * 0.05), dim ? 'rgba(90,70,45,.55)' : WOOD.groove, -0.1);
    // joints at the piece ends
    g.strokeStyle = dim ? 'rgba(90,70,45,.35)' : 'rgba(110,80,45,.55)'; g.lineWidth = Math.max(1, s * 0.025);
    for (const q of list) for (const e of [q[2], q[3]]) {
      const x = q[0] + EMX[e] * s, y = q[1] + EMY[e] * s, h = s * 0.2;
      g.beginPath(); if (e & 1) { g.moveTo(x, y - h); g.lineTo(x, y + h); } else { g.moveTo(x - h, y); g.lineTo(x + h, y); } g.stroke();
    }
  }
  function cellsOf(LD) { const out = []; for (let c = 0; c < GW * GH; c++) if (LD.pr[c]) out.push(c); return out; }
  function paintMat(g, W, H, s, rnd) {
    const gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, '#6f9d5c'); gr.addColorStop(1, '#5f8c50');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    for (let i = 0; i < 26; i++) { g.fillStyle = 'rgba(255,255,230,' + (0.03 + rnd() * 0.04) + ')'; circ(g, rnd() * W, rnd() * H, s * (0.4 + rnd() * 1.1)); g.fill(); }
    g.fillStyle = 'rgba(30,50,20,.07)';
    for (let i = 0; i < 260; i++) g.fillRect(rnd() * W, rnd() * H, 1.2, 1.2);
  }
  function paintWater(g, LD, s) {
    const w = (x, y) => x >= 0 && y >= 0 && x < GW && y < GH && LD.water[y * GW + x];
    g.fillStyle = '#4f9fc4';
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (!w(x, y)) continue;
      const X = x * s, Y = y * s, m = s * 0.08;
      rr(g, X + m, Y + m, s - 2 * m, s - 2 * m, s * 0.32); g.fill();
      if (w(x + 1, y)) g.fillRect(X + s * 0.4, Y + m, s * 1.2 - s * 0.4, s - 2 * m);
      if (w(x, y + 1)) g.fillRect(X + m, Y + s * 0.4, s - 2 * m, s * 1.2 - s * 0.4);
    }
    g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = Math.max(1, s * 0.03);
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (!w(x, y) || LD.pr[y * GW + x]) continue;
      g.beginPath(); g.arc(x * s + s * 0.38, y * s + s * 0.42, s * 0.14, Math.PI * 1.1, Math.PI * 1.7); g.stroke();
      g.beginPath(); g.arc(x * s + s * 0.66, y * s + s * 0.66, s * 0.1, Math.PI * 1.1, Math.PI * 1.7); g.stroke();
    }
  }
  function paintTree(g, x, y, r, rnd) {
    g.fillStyle = 'rgba(20,40,15,.28)'; circ(g, x + r * 0.25, y + r * 0.35, r); g.fill();
    g.fillStyle = '#2f6b33'; circ(g, x, y, r); g.fill();
    g.fillStyle = '#3f8a3f'; circ(g, x - r * 0.25, y - r * 0.25, r * 0.68); g.fill();
    g.fillStyle = 'rgba(255,255,220,.18)'; circ(g, x - r * 0.38, y - r * 0.4, r * 0.28); g.fill();
    if (rnd() < 0.4) { g.fillStyle = '#e5534b'; circ(g, x + r * 0.3, y + r * 0.1, r * 0.1); g.fill(); circ(g, x - r * 0.1, y + r * 0.35, r * 0.1); g.fill(); }
  }
  function paintHouse(g, x, y, s, rnd) {
    const w = s * 0.46, h = s * 0.36, cols = ['#8b6d52', '#6e6a62', '#9a8063', '#7d6450'];
    g.fillStyle = 'rgba(20,30,15,.3)'; rr(g, x - w / 2 + 3, y - h / 2 + 4, w, h, 3); g.fill();
    g.fillStyle = '#f3e6cc'; rr(g, x - w / 2, y - h / 2, w, h, 3); g.fill();
    g.fillStyle = cols[Math.floor(rnd() * cols.length)]; g.beginPath(); g.moveTo(x - w / 2 - 2, y - h / 2 + 1); g.lineTo(x + w / 2 + 2, y - h / 2 + 1); g.lineTo(x + w / 2 + 2, y + 1); g.lineTo(x - w / 2 - 2, y + 1); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x - w / 2 - 2, y - h / 4); g.lineTo(x + w / 2 + 2, y - h / 4); g.stroke();
  }
  function paintDecor(g, LD, s, rnd) {
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const c = y * GW + x;
      if (LD.pr[c] || LD.water[c]) { rnd(); rnd(); continue; }
      const q = rnd(), X = x * s + s / 2, Y = y * s + s / 2;
      if (q < 0.42) paintTree(g, X + (rnd() - 0.5) * s * 0.25, Y + (rnd() - 0.5) * s * 0.25, s * (0.22 + rnd() * 0.08), rnd);
      else if (q < 0.55) { paintTree(g, X - s * 0.18, Y - s * 0.12, s * 0.16, rnd); paintTree(g, X + s * 0.17, Y + s * 0.14, s * 0.15, rnd); }
      else if (q < 0.65) paintHouse(g, X, Y, s, rnd);
      else if (q < 0.82) { const cs = ['#ffe36e', '#ffffff', '#ff9ec2', '#ffb35c']; for (let i = 0; i < 5; i++) { g.fillStyle = cs[i % 4]; circ(g, X + (rnd() - 0.5) * s * 0.7, Y + (rnd() - 0.5) * s * 0.7, s * 0.035); g.fill(); } }
      else if (q < 0.9) { g.fillStyle = '#8f8a7e'; circ(g, X + (rnd() - 0.5) * s * 0.4, Y, s * 0.09); g.fill(); g.fillStyle = '#a8a294'; circ(g, X + s * 0.12, Y + s * 0.1, s * 0.06); g.fill(); }
      else rnd();
    }
  }
  function paintCrossSign(g, X, Y, s) {
    for (const [ox, oy] of [[0.13, 0.13], [0.87, 0.87]]) {
      const x = X + ox * s, y = Y + oy * s, r = s * 0.1;
      g.fillStyle = 'rgba(0,0,0,.25)'; circ(g, x + 1, y + 2, r * 0.9); g.fill();
      g.lineCap = 'round';
      for (const [col, w] of [['#fff', s * 0.07], ['#d8443a', s * 0.035]]) {
        g.strokeStyle = col; g.lineWidth = w;
        g.beginPath(); g.moveTo(x - r, y - r); g.lineTo(x + r, y + r); g.moveTo(x + r, y - r); g.lineTo(x - r, y + r); g.stroke();
      }
      g.lineCap = 'butt';
    }
  }
  function paintTunnel(g, LD, t, s) {
    const tu = LD.tun[t], c = tu.c, X = (c % GW) * s, Y = ((c / GW) | 0) * s, a = tu.a;
    const ex = X + EMX[a] * s, ey = Y + EMY[a] * s, ix = -DX[a], iy = -DY[a];   // edge midpoint; inward direction
    const R = s * 0.56;
    g.save();
    g.fillStyle = 'rgba(20,30,10,.3)'; g.beginPath(); g.ellipse(ex + ix * s * 0.04 + 2, ey + iy * s * 0.04 + 3, R, R, 0, 0, TAU); g.fill();
    const gr = g.createRadialGradient(ex + ix * s * 0.1, ey + iy * s * 0.1, R * 0.1, ex, ey, R);
    gr.addColorStop(0, '#8fb06a'); gr.addColorStop(0.7, '#6d8f4c'); gr.addColorStop(1, '#4f6e37');
    g.fillStyle = gr; circ(g, ex, ey, R); g.fill();
    g.fillStyle = 'rgba(120,110,95,.75)'; circ(g, ex - iy * R * 0.55 + ix * R * 0.1, ey + ix * R * 0.55 + iy * R * 0.1, s * 0.07); g.fill();
    circ(g, ex + iy * R * 0.45 - ix * R * 0.05, ey - ix * R * 0.45 - iy * R * 0.05, s * 0.05); g.fill();
    // portal (stone arch) facing inward
    const px = ex + ix * R * 0.72, py = ey + iy * R * 0.72, ang = Math.atan2(iy, ix);
    g.translate(px, py); g.rotate(ang);
    g.fillStyle = '#9a8f80'; rr(g, -s * 0.16, -s * 0.3, s * 0.2, s * 0.6, s * 0.06); g.fill();
    g.fillStyle = '#2a2118'; rr(g, -s * 0.12, -s * 0.22, s * 0.2, s * 0.44, s * 0.1); g.fill();
    g.restore();
  }
  function paintStation(g, LD, st, s) {
    const c = st.c, X = (c % GW) * s, Y = ((c / GW) | 0) * s, d = opp(st.a), k = st.k;   // building toward exit edge d
    const ux = DX[d], uy = DY[d], cx = X + s / 2 + ux * s * 0.3, cy = Y + s / 2 + uy * s * 0.3;
    const along = s * 0.68, across = s * 0.92;
    g.save(); g.translate(cx, cy); g.rotate(Math.atan2(uy, ux));
    g.fillStyle = 'rgba(20,30,10,.32)'; rr(g, -along / 2 + 3, -across / 2 + 4, along, across, s * 0.08); g.fill();
    g.fillStyle = '#f2e4c6'; rr(g, -along / 2, -across / 2, along, across, s * 0.08); g.fill();   // platform
    g.fillStyle = '#cdb68e'; g.fillRect(-along / 2, -across / 2 + s * 0.04, s * 0.06, across - s * 0.08);
    const rw = along * 0.8, rh = across * 0.86;
    g.fillStyle = COLD[k]; rr(g, -rw / 2 + s * 0.06, -rh / 2, rw, rh, s * 0.06); g.fill();
    g.fillStyle = COL[k]; rr(g, -rw / 2 + s * 0.06, -rh / 2, rw, rh / 2, [s * 0.06, s * 0.06, 0, 0]); g.fill();
    g.fillStyle = mix(COL[k], '#ffffff', 0.18); rr(g, -rw / 2 + s * 0.06, rh * 0.02, rw, rh / 2 - rh * 0.02, [0, 0, s * 0.06, s * 0.06]); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.2)'; g.lineWidth = 1; g.beginPath(); g.moveTo(-rw / 2 + s * 0.06, 0); g.lineTo(rw / 2 + s * 0.06, 0); g.stroke();
    g.restore();
    // emblem badge (upright)
    const bx = X + s / 2 + ux * s * 0.33, by = Y + s / 2 + uy * s * 0.33;
    g.fillStyle = '#fffaf0'; circ(g, bx, by, s * 0.2); g.fill();
    g.strokeStyle = COLD[k]; g.lineWidth = Math.max(1, s * 0.03); g.stroke();
    g.fillStyle = COL[k]; emblemPath(g, k, bx, by, s * 0.13); g.fill();
  }
  function paintBridge(g, LD, c, s) {
    const q = LD.pr[c][1], X = (c % GW) * s, Y = ((c / GW) | 0) * s;
    g.save();
    g.lineCap = 'butt';
    g.strokeStyle = 'rgba(20,20,10,.35)'; g.lineWidth = s * 0.74; trackPath(g, X + 3, Y + 5, s, q.a, q.b, 0); g.stroke();
    g.strokeStyle = '#7a5532'; g.lineWidth = s * 0.7; trackPath(g, X, Y, s, q.a, q.b, 0); g.stroke();
    g.strokeStyle = '#a77a4b'; g.lineWidth = s * 0.62; trackPath(g, X, Y, s, q.a, q.b, 0); g.stroke();
    g.restore();
    paintPairs(g, [[X, Y, q.a, q.b]], s, false);
    g.strokeStyle = '#5a3c20'; g.lineWidth = Math.max(1.5, s * 0.05);
    trackPath(g, X, Y, s, q.a, q.b, 0.33); g.stroke(); trackPath(g, X, Y, s, q.a, q.b, -0.33); g.stroke();
  }
  function paintTrestles(g, LD, s) {
    for (let c = 0; c < GW * GH; c++) {
      if (!LD.water[c] || !LD.pr[c]) continue;
      const X = (c % GW) * s, Y = ((c / GW) | 0) * s;
      for (const p of LD.pr[c]) {
        g.strokeStyle = '#7a5532'; g.lineWidth = s * 0.64; trackPath(g, X, Y, s, p.a, p.b, 0); g.stroke();
        g.strokeStyle = '#a77a4b'; g.lineWidth = s * 0.56; trackPath(g, X, Y, s, p.a, p.b, 0); g.stroke();
      }
    }
  }
  function staticPairs(LD, s, upper) {
    const list = [];
    for (let c = 0; c < GW * GH; c++) {
      const ps = LD.pr[c]; if (!ps) continue;
      const k = LD.kind[c];
      if (k === 2) continue;
      ps.forEach((p, i) => { if (k === 5 && i === 1) return; list.push([(c % GW) * s, ((c / GW) | 0) * s, p.a, p.b]); });
    }
    return list;
  }
  function drawThumb(li, wpx, hpx) {
    const LD = lay(li), d = Math.min(2, window.devicePixelRatio || 1), cv = mkC(wpx * d, hpx * d), g = cv.getContext('2d');
    cv.style.width = wpx + 'px'; cv.style.height = hpx + 'px';
    g.scale(d, d);
    const s = Math.min(wpx / GW, hpx / GH), ox = (wpx - s * GW) / 2, oy = (hpx - s * GH) / 2;
    g.fillStyle = '#5f8c50'; g.fillRect(0, 0, wpx, hpx);
    g.translate(ox, oy);
    for (let c = 0; c < GW * GH; c++) if (LD.water[c]) { g.fillStyle = '#4f9fc4'; g.fillRect((c % GW) * s, ((c / GW) | 0) * s, s, s); }
    g.strokeStyle = '#e8c890'; g.lineWidth = Math.max(1.5, s * 0.34); g.lineCap = 'round';
    for (let c = 0; c < GW * GH; c++) { const ps = LD.pr[c]; if (!ps) continue; for (const p of ps) { trackPath(g, (c % GW) * s, ((c / GW) | 0) * s, s, p.a, p.b, 0); g.stroke(); } }
    LD.sta.forEach((q) => { g.fillStyle = COL[q.k]; g.fillRect((q.c % GW) * s + s * 0.1, ((q.c / GW) | 0) * s + s * 0.1, s * 0.8, s * 0.8); });
    LD.tun.forEach((q) => { g.fillStyle = '#2a2118'; circ(g, (q.c % GW) * s + s / 2, ((q.c / GW) | 0) * s + s / 2, s * 0.45); g.fill(); });
    return cv;
  }

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const DPR = () => Math.min(2.5, cv.dpr || 1);
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    let st = null;
    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    const fine = (() => { try { return matchMedia('(pointer:fine)').matches || !!window.LOUNGE_DESKTOP; } catch (e) { return false; } })();

    let key = null, BS = [], view = 0, lay2 = null, ff = 1, endWait = 0, pubT = 0, autoSwT = -1, overSeen = false, frameN = 0;
    let parts = [], floats = [], shakeT = 0, pick = null, pickRid = -1, hostT = 0, lastSfx = {}, bestNew = false, lastCd = -1;
    let readyHide = false, readyRect = null, statC = null, topC = null, statKey = '', swSpr = [], kbUsed = false, cur = 0, hoverT = null, finT = 0;
    const remote = {}, heard = {}, frozen = {}, swFx = {};
    const tmp = { x: 0, y: 0, r: 0 }, tmp2 = { x: 0, y: 0, r: 0 };

    /* ----- match setup ----- */
    const curKey = () => (st && st.ph !== 'pick' && st.li >= 0 ? st.rid + '.' + st.li : null);
    function ensureMatch() {
      const k = curKey();
      if (!k || k === key) return;
      key = k;
      BS = [];
      for (let s = 0; s < st.n; s++) {
        if (!simHere(s)) { BS[s] = null; continue; }
        const B = newBoard(st.li, trainsFor(st), st.sd, st.n === 1);
        const p = api.players[s];
        if (p && p.ai) aiInit(B, p.lv || 2, ((st.sd * 31) ^ (s * 104729 + 13)) >>> 0);
        else if (auto() && isMine(s)) aiInit(B, 3, (st.sd ^ (99 + s * 31)) >>> 0);
        BS[s] = B;
      }
      const m = mine(), f0 = BS.findIndex(Boolean);
      view = m.length && BS[m[0]] ? m[0] : f0 >= 0 ? f0 : 0;
      for (const x in remote) delete remote[x];
      for (const x in frozen) delete frozen[x];
      parts = []; floats = []; ff = 1; endWait = 0; autoSwT = -1; overSeen = false; bestNew = false; cur = 0; finT = 0; lastCd = -1;
      statC = null; topC = null; swSpr = []; readyHide = false; readyRect = null;
      if (st.ph === 'done') BS.forEach((B) => { if (B) B.ph = 'over'; });
      layout();
    }
    function adoptSeats() {   // a guest left (seat now AI) → keep their last score as final
      if (!api.online || !api.isHost || !st || st.ph !== 'play' || !key) return;
      for (let s = 0; s < st.n; s++) {
        if (BS[s] || frozen[s] || !simHere(s)) continue;
        const r = remote[s] || [0, 0, trainsFor(st), 0, -1, 0, 0, 0];
        frozen[s] = r.slice(); frozen[s][3] = 1;
      }
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h, hudH = 46, barH = 48, FR = 0.28;
      const availH = h - hudH - barH - 6, availW = w - 8;
      const sc = Math.max(12, Math.min(availW / (GW + 2 * FR), availH / (GH + 2 * FR)));
      const bw = (GW + 2 * FR) * sc, bh = (GH + 2 * FR) * sc;
      const extra = Math.max(0, availH - bh), stripH = extra >= 46 ? 40 : 0, rest = extra - stripH;
      const ox = (w - bw) / 2 + FR * sc, oy = hudH + 3 + stripH + rest * 0.3 + FR * sc;
      lay2 = { w, h, hudH, barH, sc, ox, oy, FR, bw, bh, barY: h - barH, stripH, stripY: hudH + 2 + rest * 0.15 };
      statC = null; topC = null; swSpr = [];
      placeBar();
    }
    cv.onresize = layout;

    /* ----- bottom bar ----- */
    const ffBtn = L.h('button', { class: 'tr-btn', type: 'button', text: '▶▶ 빨리 보기', hidden: true });
    ffBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
    ffBtn.onclick = () => { api.sfx('click'); ff = ff > 1 ? 1 : 6; syncBar(); };
    root.appendChild(ffBtn);
    function placeBar() { if (!lay2) return; ffBtn.style.top = (lay2.barY + (lay2.barH - 44) / 2) + 'px'; ffBtn.style.right = '10px'; }
    let barSig = '';
    function syncBar() {
      const M = myB(), anyAI = BS.some((X, s) => X && X.ph !== 'over' && !isMine(s));
      const showFF = !!(st && st.ph === 'play' && (!M || M.ph === 'over') && anyAI);
      const sig = showFF + '|' + ff;
      if (sig === barSig) return;
      barSig = sig;
      ffBtn.hidden = !showFF; ffBtn.textContent = ff > 1 ? '▶ 보통 속도' : '▶▶ 빨리 보기'; ffBtn.classList.toggle('on', ff > 1);
    }

    /* ----- input ----- */
    function myB() { const m = mine()[0]; return m != null ? BS[m] : null; }
    function canCtl() { const B = myB(); return !!B && view === mine()[0] && B.ph !== 'over' && !auto() && !B.ai && st && st.ph === 'play'; }
    function toBoard(p) { return { x: (p.x - lay2.ox) / lay2.sc, y: (p.y - lay2.oy) / lay2.sc }; }
    function swCenter(LD, s) { const c = LD.sws[s].c; return { x: (c % GW) + 0.5, y: ((c / GW) | 0) + 0.5 }; }
    function carsOf(T, fn) {   // fn(centreX, centreY, angle, kind, len, index)
      const cs = CARS[T.ty];
      let d = 0;
      for (let i = 0; i < cs.length; i++) {
        const ln = cs[i][1];
        pointBack(T, d + 0.02, tmp); pointBack(T, d + ln - 0.02, tmp2);
        const pc = T.p - (d + ln / 2);   // progress of the car centre in the head cell (station check)
        if (!(T.dl && pc > 0.9)) fn((tmp.x + tmp2.x) / 2, (tmp.y + tmp2.y) / 2, Math.atan2(tmp.y - tmp2.y, tmp.x - tmp2.x), cs[i][0], ln, i);
        d += ln + CGAP;
      }
    }
    function pointBack(T, d, o) {
      const pl = PL(T.a, T.b);
      if (d <= T.p * pl) return posAt(T.c, T.a, T.b, T.p - d / pl, o);
      d -= T.p * pl;
      for (const e of T.trail) { const l = PL(e[1], e[2]); if (d <= l) return posAt(e[0], e[1], e[2], 1 - d / l, o); d -= l; }
      const e = T.trail.length ? T.trail[T.trail.length - 1] : [T.c, T.a, T.b];
      return posAt(e[0], e[1], e[2], -d / PL(e[1], e[2]), o);
    }
    function hitTest(B, bx, by) {   // → {sw} | {train}
      const LD = B.L, cx = Math.floor(bx), cy = Math.floor(by);
      if (cx >= 0 && cy >= 0 && cx < GW && cy < GH) { const si = LD.swOf[cy * GW + cx]; if (si >= 0) return { sw: si }; }
      let bt = null, bd = 0.5;
      for (const T of B.tr) { if (T.dl) continue; carsOf(T, (x, y) => { const d = Math.hypot(x - bx, y - by); if (d < bd) { bd = d; bt = T; } }); }
      if (bt) return { train: bt.id };
      let bs = -1, sd = 0.98;
      LD.sws.forEach((_, s) => { const c = swCenter(LD, s), d = Math.hypot(c.x - bx, c.y - by); if (d < sd) { sd = d; bs = s; } });
      return bs >= 0 ? { sw: bs } : null;
    }
    function doSw(B, s) {
      const r = tapSwitch(B, s);
      if (!r) return;
      swFx[s] = 0.28;
      if (r === 1) { api.sfx('click'); api.buzz(12); } else { api.sfx('tick'); api.buzz(8); }
      B.ev = B.ev.filter((e) => !(e.k === 'flip' && e.s === s && !e.auto) && e.k !== 'rq');
    }
    function doTrain(B, id) {
      if (!tapTrain(B, id)) return;
      const T = B.tr.find((q) => q.id === id);
      api.sfx(T && T.stopT > 0 ? 'thud' : 'click'); api.buzz(T && T.stopT > 0 ? 20 : 10);
    }
    function onDown(e) {
      if (!lay2 || !st) return;
      const p = cv.local(e);
      if (p.y < lay2.hudH) { tapChip(p.x); return; }
      const B = myB();
      if (!canCtl()) { if (B && B.ph === 'over') tapChip(-1); return; }
      e.preventDefault();
      if (readyRect && B.ph === 'ready' && p.x >= readyRect[0] && p.x <= readyRect[0] + readyRect[2] && p.y >= readyRect[1] && p.y <= readyRect[1] + readyRect[3]) { readyHide = true; readyRect = null; api.sfx('click'); return; }
      const q = toBoard(p), h = hitTest(B, q.x, q.y);
      if (!h) return;
      if (h.sw != null) { doSw(B, h.sw); cur = h.sw; } else doTrain(B, h.train);
    }
    function onMove(e) {
      if (!lay2 || !canCtl() || e.pointerType === 'touch') return;
      const p = cv.local(e), q = toBoard(p), h = hitTest(myB(), q.x, q.y);
      const want = h ? 'pointer' : '';
      if (hoverT !== want) { hoverT = want; cv.cv.style.cursor = want; }
    }
    function tapChip(x) {
      if (!st || !key || canCtl() || st.n < 2) return;
      const n = st.n, cw = (lay2.w - 8 - (n - 1) * 4) / n;
      let s = x < 0 ? -1 : Math.floor((x - 4) / (cw + 4));
      if (s < 0 || s >= n || !BS[s]) { const idx = []; for (let i = 0; i < n; i++) if (BS[i]) idx.push(i); if (idx.length < 2) return; s = idx[(idx.indexOf(view) + 1) % idx.length]; }
      if (s === view || !BS[s]) return;
      view = s; autoSwT = -2; api.sfx('click'); statC = null;
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);
    // keyboard / pad: targets = switches + level crossings
    function targets(B) { const LD = B.L, out = LD.sws.map((_, s) => ({ sw: s, c: LD.sws[s].c })); LD.cross.forEach((c) => out.push({ x: 1, c })); return out; }
    function approaching(B, cell) {   // nearest train heading into cell (actual route), {T, d}
      let best = null;
      for (const T of B.tr) {
        if (T.dl || T.oc.some((s) => s[0] === cell && s[4] - s[3] > 0.01)) continue;
        let c = T.c, b = T.b, d = (1 - T.p) * PL(T.a, T.b);
        for (let i = 0; i < 5; i++) {
          if (B.L.stOf[c] >= 0) break;
          const nc = nextCell(c, b), na = opp(b), nb = exitOf(B.L, B.sw, nc, na, T.ty === TR);
          if (nc === cell) { if (!best || d < best.d) best = { T, d }; break; }
          if (nb < 0) break;
          d += PL(na, nb); c = nc; b = nb;
        }
      }
      return best;
    }
    const offKeys = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !canCtl()) return;
      const B = myB(), tg = targets(B);
      if (!tg.length) return;
      kbUsed = true;
      if (/^s\d$/.test(id)) { const s = +id.slice(1) - 1; if (s < B.sw.length) { doSw(B, s); cur = s; } return; }
      cur = U.clamp(cur, 0, tg.length - 1);
      if (id === 'flip') { const t = tg[cur]; if (t.sw != null) doSw(B, t.sw); else { const a = approaching(B, t.c); if (a) doTrain(B, a.T.id); } return; }
      if (id === 'hold') { const a = approaching(B, tg[cur].c); if (a) doTrain(B, a.T.id); else api.sfx('tick'); return; }
      const dir = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] }[id];
      if (!dir) return;
      const c0 = tg[cur].c, x0 = c0 % GW, y0 = (c0 / GW) | 0;
      let bi = -1, bs = 1e9;
      tg.forEach((t, i) => {
        if (i === cur) return;
        const dx = (t.c % GW) - x0, dy = ((t.c / GW) | 0) - y0, along = dx * dir[0] + dy * dir[1], side = Math.abs(dx * dir[1] - dy * dir[0]);
        if (along <= 0) return;
        const sc = along + side * 2;
        if (sc < bs) { bs = sc; bi = i; }
      });
      if (bi >= 0) { cur = bi; api.sfx('tick'); }
    }) : null;

    /* ----- solo stage picker ----- */
    function bests() { try { return JSON.parse(localStorage.getItem('lounge.trains.best') || '{}') || {}; } catch (e) { return {}; } }
    function saveBest(li, n) { const b = bests(); if ((b[li] || 0) >= n) return false; b[li] = n; try { localStorage.setItem('lounge.trains.best', JSON.stringify(b)); } catch (e) {} return true; }
    function buildPicker() {
      if (pick) return;
      const canPick = host() && mine().length > 0 && !auto();
      const B0 = bests();
      let next = LAYS.findIndex((_, i) => !(B0[i] > 0));
      if (next < 0) next = LAYS.findIndex((_, i) => (B0[i] || 0) < 3);
      const wpx = Math.max(40, Math.min(64, Math.floor(((lay2 ? lay2.w : 360) - 24 - 24) / 4) - 14));
      const go = (li) => { if (!canPick || !st || st.ph !== 'pick') return; api.sfx('click'); api.buzz(15); api.setState(Object.assign({}, st, { ph: 'play', li })); };
      const el = L.h('div', { class: 'tr-pick' }, L.h('h3', { text: '스테이지 고르기' }),
        L.h('p', { class: 'sub', text: canPick ? '하트 3개로 시작해요. 남은 하트만큼 별(★★★ = 하나도 안 틀림). 금테 칸이 다음 도전!' : '고르는 중…' }));
      let nextEl = null;
      ['쉬움', '보통', '어려움'].forEach((tn, t) => {
        el.append(L.h('div', { class: 'tier', text: tn }));
        const grid = L.h('div', { class: 'tr-grid' });
        TIERS[t].forEach((i) => {
          const n = B0[i] || 0;
          const stars = L.h('div', { class: 'stars' }); stars.innerHTML = '★'.repeat(n) + '<i>' + '★'.repeat(3 - n) + '</i>';
          const b = L.h('button', { class: 'tr-st' + (i === next ? ' next' : ''), type: 'button', 'aria-label': (i + 1) + '번 ' + LAYS[i].n, disabled: !canPick },
            L.h('span', { class: 'no', text: String(i + 1) }), drawThumb(i, wpx, Math.round(wpx * GH / GW)), L.h('span', { class: 'nm', text: LAYS[i].n }), stars);
          b.onclick = () => go(i);
          if (i === next) nextEl = b;
          grid.append(b);
        });
        el.append(grid);
      });
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el };
      if (nextEl) setTimeout(() => { try { nextEl.scrollIntoView({ block: 'nearest' }); } catch (e) {} }, 30);
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } }
    function hostPickFlow(rdt) {
      if (!host() || !st || st.ph !== 'pick') return;
      if (pickRid !== st.rid) { pickRid = st.rid; hostT = 0; }
      if (!mine().length || auto()) { hostT += rdt * SPD(); if (hostT > 1.2) { hostT = -1e9; api.setState(Object.assign({}, st, { ph: 'play', li: auto() ? 0 : U.rand(LAYS.length) })); } }
    }

    /* ----- effects ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 50)) return; lastSfx[n] = t; api.sfx(n); }
    function burst(x, y, cols, n, sp, life) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: life, T: life, c: cols[i % cols.length] }); }
      if (parts.length > 160) parts.splice(0, parts.length - 160);
    }
    function pop(x, y, text, col, big) { floats.push({ x, y, text, col: col || '#fff3c0', t: 1.4, T: 1.4, big: !!big }); if (floats.length > 8) floats.shift(); }
    function onEvents(B, me, show) {
      for (const e of B.ev) {
        if (!show) continue;
        switch (e.k) {
          case 'spawn': if (me) sfx('whoosh', 250); break;
          case 'ok': sfx('chip', 60); if (me) api.buzz(14); burst(e.x, e.y, [COL[e.col], '#fff6d0', '#ffe08a'], 14, 2.2, 0.7); pop(e.x, e.y - 0.6, B.solo ? (e.stk >= 3 ? '연속 ' + e.stk + '!' : '맞아요!') : '+' + e.pts + (e.stk >= 3 ? ' 연속 ' + e.stk : ''), '#fff3a0', e.stk >= 5); break;
          case 'bad': sfx('thud', 80); if (me) api.buzz([30, 30, 30]); pop(e.x, e.y - 0.6, B.solo ? '앗, 틀린 역! ♥−1' : '앗, 틀린 역!', '#ffb0a0', true); break;
          case 'lost': sfx('whoosh', 80); if (me) api.buzz([20, 30, 20]); burst(e.x, e.y, ['#ffffff', '#d8d0c0', COL[e.col]], 12, 1.6, 0.8); pop(e.x, e.y - 0.6, B.solo ? '길을 잃었어요 ♥−1' : '길을 잃었어요', '#ffcf9a', true); break;
          case 'crash': sfx('hit', 80); setTimeout(() => sfx('thud', 10), 90); if (me) { api.buzz([60, 40, 60]); shakeT = 0.35; } burst(e.x, e.y, ['#ffd24a', '#ff7a4a', '#ffffff', '#7a6a5a'], 26, 3.4, 0.9); pop(e.x, e.y - 0.6, B.solo ? '쾅! ♥−1' : '쾅! −10', '#ff9a7a', true); break;
          case 'flip': if (e.auto) { sfx('click', 60); swFx[e.s] = 0.28; } else if (!me) swFx[e.s] = 0.28; break;
          case 'stop': if (!me) sfx('tick', 80); break;
          case 'go': sfx('pop', 80); if (me) api.buzz(20); break;
          case 'over':
            if (me) { if (e.win) { sfx('win', 200); api.buzz([30, 40, 60]); } else { sfx('lose', 200); api.buzz([60, 40, 60]); } }
            break;
        }
      }
      B.ev.length = 0;
    }

    /* ----- online ----- */
    function rowOf(s) {   // [score, resolved, total, done, hearts, ok, bad, crashes]
      if (frozen[s]) return frozen[s];
      const B = BS[s];
      if (B) return [B.sc, B.res, B.n, B.ph === 'over' ? 1 : 0, B.hp, B.ok, B.bad, B.cr];
      return remote[s] || null;
    }
    function pollNet() {
      if (!api.online || !key) return;
      const now = performance.now();
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (rem && typeof rem === 'object') for (const k in rem) {
          const s = +k, o = rem[k];
          if (!(s >= 0 && s < st.n) || BS[s] || frozen[s] || !o || o.k !== key || !Array.isArray(o.a)) continue;
          const a = o.a.slice(0, 8).map((v) => +v || 0);
          const old = remote[s];
          if (!old || old.join() !== a.join()) heard[s] = now;
          remote[s] = a;
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (hs && typeof hs === 'object' && hs.k === key && Array.isArray(hs.s)) hs.s.forEach((a, s) => { if (BS[s] || !Array.isArray(a)) return; remote[s] = a.map((v) => +v || 0); heard[s] = now; });
      }
    }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      if (pubT > 0) return;
      pubT = 0.3;
      try {
        if (api.isHost) { const s = []; for (let i = 0; i < st.n; i++) s.push(rowOf(i) || 0); api.net.hostSend({ k: key, s }); }
        else { const m = mine()[0]; if (m != null && BS[m]) api.net.publish({ k: key, a: rowOf(m) }); }
      } catch (e) {}
    }
    function hostEnd(rdt) {
      if (!host() || !st || st.ph !== 'play' || !key) return;
      const now = performance.now();
      let all = true, localDone = true;
      for (let s = 0; s < st.n; s++) if (BS[s] && BS[s].ph !== 'over') localDone = false;
      for (let s = 0; s < st.n; s++) {
        const r = rowOf(s);
        if (r && r[3]) continue;
        if (BS[s] || !(localDone && heard[s] && now - heard[s] > 40000)) all = false;
      }
      if (!all) { endWait = 0; return; }
      endWait += rdt;
      if (endWait > 1.4) {
        endWait = -1e9;
        const rows = [];
        for (let s = 0; s < st.n; s++) { const r = rowOf(s) || [0, 0, 0, 1, 0, 0, 0, 0]; rows.push([s, r[0], r[5], r[6], r[7], r[4]]); }
        api.setState(finish(st, rows));
      }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      frameN++;
      ensureMatch();
      if ((frameN & 15) === 0) adoptSeats();
      hostPickFlow(rdt);
      if (!st || !key) { draw(now); return; }
      if (auto()) { const M0 = myB(); if (M0 && !M0.ai) aiInit(M0, 3, (st.sd ^ (99 + mine()[0] * 31)) >>> 0); }
      const dt = rdt * SPD();
      const playing = st.ph === 'play';
      BS.forEach((B, s) => {
        if (!B) return;
        if (playing) { const k = !isMine(s) || auto() ? ff : 1; runFor(B, dt * k, 900); }
        const me = isMine(s), show = s === view;
        if (me || show) onEvents(B, me, show); else B.ev.length = 0;
      });
      pollNet();
      const M = myB();
      if (M && M.ph === 'ready' && isMine(view)) { const cd = Math.ceil(M.tm / (READY_T / 3)); if (cd !== lastCd && cd <= 3 && cd >= 1) { lastCd = cd; sfx('tick', 100); } }
      if (M && M.ph === 'over' && !overSeen) {
        overSeen = true; autoSwT = 2.8; finT = 0;
        if (st.n === 1 && !auto() && M.hp > 0) bestNew = saveBest(st.li, M.hp);
      }
      if (M && M.ph === 'over') finT += rdt;
      if (autoSwT > 0) {
        autoSwT -= rdt;
        if (autoSwT <= 0) { for (let i = 0; i < st.n; i++) if (!isMine(i) && BS[i] && BS[i].ph !== 'over') { view = i; break; } }
      }
      hostEnd(rdt);
      publish(rdt);
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.vx *= 0.95; q.vy *= 0.95; if (q.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (const k in swFx) { swFx[k] -= rdt; if (swFx[k] <= 0) delete swFx[k]; }
      shakeT = Math.max(0, shakeT - rdt);
      syncBar();
      draw(now);
    }

    /* ----- cached layers ----- */
    function boardCanvas() { const d = DPR(), c = mkC(lay2.bw * d, lay2.bh * d), g = c.getContext('2d'); g.setTransform(d, 0, 0, d, lay2.FR * lay2.sc * d, lay2.FR * lay2.sc * d); return [c, g]; }
    function getStatic(B) {
      const sk = B.li + '|' + lay2.sc + '|' + DPR() + '|' + lay2.bw;
      if (statC && statKey === sk) return;
      statKey = sk;
      const LD = B.L, s = lay2.sc, fr = lay2.FR * s, rnd = mkRng(B.li * 977 + 5);
      let [c, g] = boardCanvas();
      // wooden frame + play mat
      g.fillStyle = 'rgba(0,0,0,.35)'; rr(g, -fr + 2, -fr + 4, GW * s + 2 * fr, GH * s + 2 * fr, fr * 1.1); g.fill();
      const fg = g.createLinearGradient(0, -fr, 0, GH * s + fr); fg.addColorStop(0, '#a8743e'); fg.addColorStop(1, '#7c5128');
      g.fillStyle = fg; rr(g, -fr, -fr, GW * s + 2 * fr, GH * s + 2 * fr, fr * 1.1); g.fill();
      g.strokeStyle = 'rgba(255,230,180,.25)'; g.lineWidth = 1.5; rr(g, -fr + 2, -fr + 2, GW * s + 2 * fr - 4, GH * s + 2 * fr - 4, fr); g.stroke();
      g.save(); rr(g, 0, 0, GW * s, GH * s, s * 0.12); g.clip();
      paintMat(g, GW * s, GH * s, s, rnd);
      paintWater(g, LD, s);
      paintDecor(g, LD, s, rnd);
      paintTrestles(g, LD, s);
      paintPairs(g, staticPairs(LD, s), s, false);
      for (const X of LD.cross) paintCrossSign(g, (X % GW) * s, ((X / GW) | 0) * s, s);
      g.restore();
      statC = c;
      // top layer: bridges, tunnels, stations
      [c, g] = boardCanvas();
      for (let x = 0; x < GW * GH; x++) if (LD.kind[x] === 5) paintBridge(g, LD, x, s);
      LD.tun.forEach((_, t) => paintTunnel(g, LD, t, s));
      LD.sta.forEach((q) => paintStation(g, LD, q, s));
      topC = c;
      // switch sprites (both states)
      const d = DPR();
      swSpr = LD.sws.map((S) => [0, 1].map((k) => {
        const m = 0.1 * s, cc = mkC((s + 2 * m) * d, (s + 2 * m) * d), gg = cc.getContext('2d');
        gg.setTransform(d, 0, 0, d, m * d, m * d);
        paintPairs(gg, [[0, 0, S.a, S.br[1 - k]]], s, true);
        paintPairs(gg, [[0, 0, S.a, S.br[k]]], s, false);
        return cc;
      }));
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align, base) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    function panel(x, y, w, h) { ctx.fillStyle = 'rgba(18,12,24,.88)'; rr(ctx, x, y, w, h, 14); ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.65)'; ctx.lineWidth = 1.5; ctx.stroke(); }
    function wrap(t, maxW, font) {
      ctx.font = font; const out = []; let line = '';
      for (const wd of t.split(' ')) { const tryL = line ? line + ' ' + wd : wd; if (ctx.measureText(tryL).width > maxW && line) { out.push(line); line = wd; } else line = tryL; }
      if (line) out.push(line); return out;
    }
    const PX = (x) => lay2.ox + x * lay2.sc, PY = (y) => lay2.oy + y * lay2.sc;
    function upEmb(k, cx, r, col, ang) { ctx.save(); ctx.translate(cx, 0); ctx.rotate(-ang); ctx.fillStyle = col; emblemPath(ctx, k, 0, 0, r); ctx.fill(); ctx.restore(); }
    function drawCar(x, y, ang, kind, ln, k, T, i) {
      const s = lay2.sc, L2 = (ln - 0.03) * s, W2 = 0.36 * s, r = W2 * 0.3;
      ctx.save(); ctx.translate(PX(x), PY(y)); ctx.rotate(ang);
      ctx.fillStyle = 'rgba(15,25,10,.3)'; rr(ctx, -L2 / 2 + 2, -W2 / 2 + 3, L2, W2, r); ctx.fill();
      // wheels
      ctx.fillStyle = '#2b2622';
      const wx = kind === 'C' || kind === 'F' ? [-L2 * 0.28, L2 * 0.28] : [-L2 * 0.3, 0, L2 * 0.3];
      for (const q of wx) { ctx.fillRect(q - s * 0.05, -W2 / 2 - s * 0.035, s * 0.1, s * 0.05); ctx.fillRect(q - s * 0.05, W2 / 2 - s * 0.015, s * 0.1, s * 0.05); }
      const col = COL[k], dk = COLD[k];
      const front = kind === 'R' ? -1 : 1;
      if (kind === 'L' || kind === 'R' || kind === 'X') {
        ctx.fillStyle = dk;
        if (kind === 'X') { ctx.beginPath(); ctx.moveTo(-L2 / 2, -W2 / 2); ctx.lineTo(L2 * 0.22, -W2 / 2); ctx.lineTo(L2 / 2, 0); ctx.lineTo(L2 * 0.22, W2 / 2); ctx.lineTo(-L2 / 2, W2 / 2); ctx.closePath(); ctx.fill(); }
        else { rr(ctx, -L2 / 2, -W2 / 2, L2, W2, r); ctx.fill(); }
        ctx.fillStyle = col;
        if (kind === 'X') { ctx.beginPath(); ctx.moveTo(-L2 / 2 + 1.5, -W2 / 2 + 1.5); ctx.lineTo(L2 * 0.2, -W2 / 2 + 1.5); ctx.lineTo(L2 / 2 - 2.5, 0); ctx.lineTo(L2 * 0.2, W2 / 2 - 1.5); ctx.lineTo(-L2 / 2 + 1.5, W2 / 2 - 1.5); ctx.closePath(); ctx.fill();
          ctx.fillStyle = '#ffd24a'; ctx.fillRect(-L2 / 2 + 2, -W2 * 0.1, L2 * 0.82, W2 * 0.2); }
        else {
          rr(ctx, -L2 / 2 + 1.5, -W2 / 2 + 1.5, L2 - 3, W2 - 3, r * 0.8); ctx.fill();
          // boiler toward the front, cab at the back
          ctx.fillStyle = mix(col, '#000000', 0.25); rr(ctx, front > 0 ? -L2 * 0.05 : -L2 * 0.45, -W2 * 0.28, L2 * 0.5, W2 * 0.56, W2 * 0.28); ctx.fill();
          ctx.fillStyle = '#2b2622'; circ(ctx, front * L2 * 0.3, 0, W2 * 0.14); ctx.fill();
          ctx.fillStyle = '#d8d0c0'; ctx.fillRect(front > 0 ? L2 / 2 - 2 : -L2 / 2, -W2 * 0.35, 2, W2 * 0.7);
        }
        // cab roof with emblem
        const cx = kind === 'X' ? -L2 * 0.18 : -front * L2 * 0.24, rw = L2 * 0.36;
        ctx.fillStyle = mix(col, '#ffffff', 0.55); rr(ctx, cx - rw / 2, -W2 * 0.38, rw, W2 * 0.76, 2); ctx.fill();
        upEmb(k, cx, W2 * 0.27, dk, ang);
        if (kind === 'R') { ctx.fillStyle = '#17131f'; circ(ctx, L2 * 0.12, 0, W2 * 0.24); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, s * 0.03); ctx.beginPath(); ctx.arc(L2 * 0.12, 0, W2 * 0.14, -0.3, Math.PI * 1.4); ctx.stroke(); }
      } else if (kind === 'C') {
        ctx.fillStyle = dk; rr(ctx, -L2 / 2, -W2 / 2, L2, W2, r); ctx.fill();
        ctx.fillStyle = col; rr(ctx, -L2 / 2 + 1.5, -W2 / 2 + 1.5, L2 - 3, W2 - 3, r * 0.8); ctx.fill();
        ctx.fillStyle = mix(col, '#ffffff', 0.62); rr(ctx, -L2 * 0.3, -W2 * 0.32, L2 * 0.6, W2 * 0.64, 3); ctx.fill();
        upEmb(k, 0, W2 * 0.25, dk, ang);
        if (T.ty === TX) { ctx.fillStyle = '#ffd24a'; ctx.fillRect(-L2 / 2 + 2, -W2 / 2 + 1.5, L2 - 4, 2); ctx.fillRect(-L2 / 2 + 2, W2 / 2 - 3.5, L2 - 4, 2); }
      } else {   // freight wagon with crates
        ctx.fillStyle = '#5a3c20'; rr(ctx, -L2 / 2, -W2 / 2, L2, W2, 2); ctx.fill();
        ctx.fillStyle = col; ctx.fillRect(-L2 / 2 + 1, -W2 / 2 + 1, L2 - 2, 2.5); ctx.fillRect(-L2 / 2 + 1, W2 / 2 - 3.5, L2 - 2, 2.5);
        ctx.fillStyle = '#c99a5a'; ctx.fillRect(-L2 * 0.4, -W2 * 0.28, L2 * 0.36, W2 * 0.56); ctx.fillRect(L2 * 0.04, -W2 * 0.28, L2 * 0.36, W2 * 0.56);
        ctx.strokeStyle = 'rgba(90,60,30,.6)'; ctx.lineWidth = 1; ctx.strokeRect(-L2 * 0.4, -W2 * 0.28, L2 * 0.36, W2 * 0.56); ctx.strokeRect(L2 * 0.04, -W2 * 0.28, L2 * 0.36, W2 * 0.56);
        if (i === 1) { ctx.fillStyle = '#fffaf0'; circ(ctx, -L2 * 0.22, 0, W2 * 0.2); ctx.fill(); upEmb(k, -L2 * 0.22, W2 * 0.15, col, ang); }
      }
      ctx.restore();
    }
    function drawTrains(B, pass) {
      const LD = B.L;
      for (const T of B.tr) {
        carsOf(T, (x, y, ang, kind, ln, i) => {
          const c = Math.floor(y) * GW + Math.floor(x);
          let up = false;
          if (c >= 0 && c < GW * GH && LD.kind[c] === 5) { const q = LD.pr[c][1]; up = T.oc.some((s) => s[0] === c && s[1] === q.a && s[2] === q.b); }
          if ((pass === 2) !== up) return;
          drawCar(x, y, ang, kind, ln, T.k, T, i);
        });
      }
    }
    function nextIncoming(B) {   // per switch: nearest train that will enter from the stem (actual route)
      const LD = B.L, out = LD.sws.map(() => null);
      for (const T of B.tr) {
        if (T.dl) continue;
        let c = T.c, b = T.b, d = (1 - T.p) * PL(T.a, T.b);
        for (let i = 0; i < 6 && d < 4.5; i++) {
          if (LD.stOf[c] >= 0) break;
          const nc = nextCell(c, b), na = opp(b), si = LD.swOf[nc];
          if (si >= 0 && LD.sws[si].a === na) { if (!out[si] || d < out[si].d) out[si] = { T, d }; }
          const nb = exitOf(LD, B.sw, nc, na, T.ty === TR);
          if (nb < 0) break;
          d += PL(na, nb); c = nc; b = nb;
        }
      }
      return out;
    }
    function arrow(x, y, ang, len, w, col, dash) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
      if (dash) { ctx.setLineDash([w * 0.5, w * 0.45]); ctx.strokeStyle = col; ctx.lineWidth = w * 0.42; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(len - w * 0.8, 0); ctx.stroke(); ctx.setLineDash([]); }
      else { ctx.strokeStyle = col; ctx.lineWidth = w * 0.5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(-len * 0.15, 0); ctx.lineTo(len - w * 0.8, 0); ctx.stroke(); }
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(len, 0); ctx.lineTo(len - w * 1.1, -w * 0.8); ctx.lineTo(len - w * 1.1, w * 0.8); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    function drawSwitches(B, now) {
      const LD = B.L, s = lay2.sc, inc = nextIncoming(B), tsec = now / 1000;
      LD.sws.forEach((S, si) => {
        const cx = PX((S.c % GW) + 0.5), cy = PY(((S.c / GW) | 0) + 0.5), fx = swFx[si] || 0, R = s * 0.25 * (1 + fx * 0.6);
        const busy = B.busy[S.c], on = S.br[B.sw[si]];
        ctx.fillStyle = 'rgba(15,25,10,.35)'; circ(ctx, cx + 1.5, cy + 2.5, R); ctx.fill();
        const gr = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 0.1, cx, cy, R);
        gr.addColorStop(0, '#f6dcae'); gr.addColorStop(1, '#c9955a');
        ctx.fillStyle = gr; circ(ctx, cx, cy, R); ctx.fill();
        ctx.strokeStyle = busy ? 'rgba(120,100,80,.9)' : '#e3ae45'; ctx.lineWidth = Math.max(1.5, s * 0.045); ctx.stroke();
        // incoming train colour pip on the stem side
        const q = inc[si];
        if (q) {
          const px = cx + DX[S.a] * R * 0.98, py = cy + DY[S.a] * R * 0.98;
          ctx.fillStyle = '#fffaf0'; circ(ctx, px, py, s * 0.1); ctx.fill();
          ctx.fillStyle = COL[q.T.k]; circ(ctx, px, py, s * 0.075); ctx.fill();
        }
        const ang = Math.atan2(DY[on] * 1, DX[on] * 1);
        arrow(cx, cy, ang, s * 0.42, s * 0.12, busy ? 'rgba(80,60,40,.8)' : '#5a2e12', false);
        if (q && q.T.ty === TR) {
          const alt = S.br[1 - B.sw[si]];
          arrow(cx, cy, Math.atan2(DY[alt], DX[alt]), s * 0.44, s * 0.1, 'rgba(255,255,255,.95)', true);
          txt('↺', cx + DX[alt] * s * 0.18 + DY[alt] * s * 0.18, cy + DY[alt] * s * 0.18 - DX[alt] * s * 0.18, '#fff', '700 ' + Math.round(s * 0.26) + 'px ' + FONT);
        }
        if (B.rq[si]) {
          ctx.save(); ctx.translate(cx, cy); ctx.rotate(tsec * 3);
          ctx.setLineDash([s * 0.08, s * 0.06]); ctx.strokeStyle = '#ffe08a'; ctx.lineWidth = Math.max(2, s * 0.06);
          circ(ctx, 0, 0, s * 0.4); ctx.stroke(); ctx.setLineDash([]); ctx.restore();
          const alt = S.br[1 - B.sw[si]];
          arrow(cx, cy, Math.atan2(DY[alt], DX[alt]), s * 0.42, s * 0.1, 'rgba(255,224,138,.9)', true);
        }
        if (fine && LD.sws.length <= 7) {
          const bx = cx - s * 0.33, by = cy - s * 0.33;
          ctx.fillStyle = 'rgba(23,19,31,.82)'; circ(ctx, bx, by, s * 0.13); ctx.fill();
          txt(String(si + 1), bx, by + 0.5, '#ffe9b0', '700 ' + Math.round(s * 0.18) + 'px ' + MONO);
        }
      });
    }
    function crossWarn(B, now) {
      const LD = B.L, s = lay2.sc;
      for (const X of LD.cross) {
        const ws = [];
        for (const T of B.tr) {
          if (T.dl) continue;
          const inX = T.oc.find((q) => q[0] === X && q[4] - q[3] > 0.01);
          if (inX) { ws.push([0, 1, inX[1]]); continue; }
          let c = T.c, b = T.b, d = (1 - T.p) * PL(T.a, T.b);
          for (let i = 0; i < 4 && d < 3; i++) {
            if (LD.stOf[c] >= 0) break;
            const nc = nextCell(c, b), na = opp(b), nb = exitOf(LD, B.sw, nc, na, T.ty === TR);
            if (nc === X) { const v = Math.max(0.3, T.vm), w0 = d / v + T.stopT; ws.push([w0, w0 + (PL(na, nb) + T.len) / v, na]); break; }
            if (nb < 0) break;
            d += PL(na, nb); c = nc; b = nb;
          }
        }
        let warn = false;
        for (let i = 0; i < ws.length && !warn; i++) for (let j = i + 1; j < ws.length; j++) if ((ws[i][2] & 1) !== (ws[j][2] & 1) && ws[i][0] < ws[j][1] + 0.3 && ws[j][0] < ws[i][1] + 0.3 && Math.min(ws[i][0], ws[j][0]) < 2.2) { warn = true; break; }
        if (!warn) continue;
        const cx = PX((X % GW) + 0.5), cy = PY(((X / GW) | 0) + 0.5), k = 0.5 + 0.5 * Math.sin(now / 90);
        ctx.strokeStyle = 'rgba(255,70,50,' + (0.5 + 0.5 * k) + ')'; ctx.lineWidth = Math.max(2, s * 0.08); circ(ctx, cx, cy, s * (0.52 + 0.06 * k)); ctx.stroke();
        ctx.fillStyle = '#ff4632'; circ(ctx, cx + s * 0.42, cy - s * 0.42, s * 0.17); ctx.fill();
        txt('!', cx + s * 0.42, cy - s * 0.41, '#fff', '800 ' + Math.round(s * 0.26) + 'px ' + FONT);
      }
    }
    function drawTunnelSigns(B) {
      const LD = B.L, s = lay2.sc;
      LD.tun.forEach((tu, t) => {
        let qi = -1;
        for (let i = B.qi; i < B.sched.length; i++) if (B.sched[i].tn === t) { qi = i; break; }
        const a = tu.a, c = tu.c;
        const x = PX((c % GW) + 0.5 + DX[a] * 0.12 + (a & 1 ? 0 : 0.42)), y = PY(((c / GW) | 0) + 0.5 + DY[a] * 0.12 + (a & 1 ? -0.42 : 0));
        const R = s * 0.2;
        ctx.fillStyle = 'rgba(15,20,10,.4)'; circ(ctx, x + 1, y + 2, R + 3); ctx.fill();
        ctx.fillStyle = '#fffaf0'; circ(ctx, x, y, R + 2.5); ctx.fill();
        if (qi < 0) { txt('끝', x, y + 0.5, '#7a6a5a', '700 ' + Math.round(s * 0.2) + 'px ' + FONT); return; }
        const q = B.sched[qi];
        ctx.fillStyle = COL[q.k]; circ(ctx, x, y, R); ctx.fill();
        ctx.fillStyle = '#fffaf0'; emblemPath(ctx, q.k, x, y, R * 0.6); ctx.fill();
        if (qi === B.qi && B.ph === 'run') {
          const f = U.clamp(B.clk / Math.max(0.01, q.g), 0, 1);
          ctx.strokeStyle = '#3a2a1a'; ctx.lineWidth = Math.max(2, s * 0.06); ctx.beginPath(); ctx.arc(x, y, R + 2.5, -Math.PI / 2, -Math.PI / 2 + TAU * f); ctx.stroke();
        }
        if (q.ty) {
          const lb = q.ty === TX ? '급' : q.ty === TF ? '화' : '↺', bx = x + R * 0.95, by = y + R * 0.85;
          ctx.fillStyle = q.ty === TX ? '#ffd24a' : q.ty === TF ? '#8a5a2a' : '#17131f'; circ(ctx, bx, by, s * 0.12); ctx.fill();
          txt(lb, bx, by + 0.5, q.ty === TX ? '#3a2a00' : '#fff', '800 ' + Math.round(s * 0.15) + 'px ' + FONT);
        }
      });
    }
    function tunArrow(LD, t) {   // where a tunnel sits: ↖ ↑ ↗ / ← → / ↙ ↓ ↘
      const tu = LD.tun[t], x = tu.c % GW;
      if (tu.a === 1) return '→'; if (tu.a === 3) return '←';
      const top = tu.a === 0;
      return x < 3 ? (top ? '↖' : '↙') : x > 3 ? (top ? '↗' : '↘') : (top ? '↑' : '↓');
    }
    function drawQueue(B) {   // upcoming trains, in order (tall screens only)
      if (!lay2.stripH) return;
      const y = lay2.stripY + lay2.stripH / 2, n = Math.min(7, B.sched.length - B.qi);
      txt('다음 기차', 12, y, '#c9bcd6', '600 12px ' + FONT, 'left');
      if (n <= 0) { txt('모두 나왔어요', 80, y, '#9dffb0', '600 12px ' + FONT, 'left'); return; }
      const multi = B.L.tun.length > 1, step = Math.min(42, (lay2.w - 86) / n);
      for (let i = 0; i < n; i++) {
        const q = B.sched[B.qi + i], x = 86 + i * step, R = i ? 11 : 13;
        ctx.globalAlpha = i ? 0.9 - i * 0.07 : 1;
        ctx.fillStyle = '#fffaf0'; circ(ctx, x, y, R + 2); ctx.fill();
        ctx.fillStyle = COL[q.k]; circ(ctx, x, y, R); ctx.fill();
        ctx.fillStyle = '#fffaf0'; emblemPath(ctx, q.k, x, y, R * 0.6); ctx.fill();
        if (q.ty) { const bx = x + R * 0.8, by = y + R * 0.75; ctx.fillStyle = q.ty === TX ? '#ffd24a' : q.ty === TF ? '#8a5a2a' : '#17131f'; circ(ctx, bx, by, 7); ctx.fill(); txt(q.ty === TX ? '급' : q.ty === TF ? '화' : '↺', bx, by + 0.5, q.ty === TX ? '#3a2a00' : '#fff', '800 9px ' + FONT); }
        if (multi) txt(tunArrow(B.L, q.tn), x - R * 0.9, y - R * 0.85, '#ffe9b0', '700 11px ' + FONT);
        ctx.globalAlpha = 1;
      }
    }
    function drawStops(B, now) {
      const s = lay2.sc;
      for (const T of B.tr) {
        if (!(T.stopT > 0)) continue;
        pointBack(T, 0.3, tmp);
        const x = PX(tmp.x), y = PY(tmp.y) - s * 0.42, R = s * 0.16;
        ctx.fillStyle = '#d8382e'; circ(ctx, x, y, R); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1.5, s * 0.035); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.fillRect(x - R * 0.5, y - R * 0.15, R, R * 0.3);
        ctx.strokeStyle = '#ffd24a'; ctx.lineWidth = Math.max(2, s * 0.05); ctx.beginPath(); ctx.arc(x, y, R + 3, -Math.PI / 2, -Math.PI / 2 + TAU * (T.stopT / STOP_T)); ctx.stroke();
      }
    }
    function drawCursor(B, now) {
      if (!kbUsed || !canCtl()) return;
      const tg = targets(B); if (!tg.length) return;
      cur = U.clamp(cur, 0, tg.length - 1);
      const c = tg[cur].c, s = lay2.sc, x = PX(c % GW), y = PY((c / GW) | 0), k = 0.5 + 0.5 * Math.sin(now / 160);
      ctx.strokeStyle = 'rgba(255,224,138,' + (0.6 + 0.4 * k) + ')'; ctx.lineWidth = 3; rr(ctx, x + 1, y + 1, s - 2, s - 2, s * 0.2); ctx.stroke();
    }
    function drawHud(B) {
      const n = st.n;
      if (n === 1) {
        const r = rowOf(0), hp = B ? B.hp : r ? r[4] : 3;
        for (let i = 0; i < 3; i++) heart(18 + i * 26, lay2.hudH / 2, 10, i < hp);
        const nm = (st.li + 1) + '. ' + LAYS[st.li].n;
        txt(fitText(nm, lay2.w - 210, '700 14px ' + FONT), lay2.w / 2 + 4, lay2.hudH / 2, '#f2e9d8', '700 14px ' + FONT);
        const tot = B ? B.n : trainsFor(st), done = B ? B.res : 0;
        txt('기차 ' + done + '/' + tot, lay2.w - 12, lay2.hudH / 2, '#ffe9b0', '700 13px ' + MONO, 'right');
        return;
      }
      const cw = (lay2.w - 8 - (n - 1) * 4) / n, ch = lay2.hudH - 8;
      let top = -1; for (let s = 0; s < n; s++) { const r = rowOf(s); if (r && r[0] > top) top = r[0]; }
      for (let s = 0; s < n; s++) {
        const x = 4 + s * (cw + 4), y = 3, r = rowOf(s), P = Pl(s);
        ctx.fillStyle = s === view ? 'rgba(227,174,69,.22)' : 'rgba(255,255,255,.06)'; rr(ctx, x, y, cw, ch, 8); ctx.fill();
        if (s === view) { ctx.strokeStyle = 'rgba(227,174,69,.85)'; ctx.lineWidth = 1.5; ctx.stroke(); }
        ctx.fillStyle = P.color || '#888'; rr(ctx, x + 4, y + 5, 4, ch - 10, 2); ctx.fill();
        const f1 = '600 11px ' + FONT;
        const crown = r && r[0] > 0 && r[0] === top ? '♛ ' : '';
        txt(fitText(crown + name(s), cw - 18, f1), x + 12, y + 10, '#f2e9d8', f1, 'left');
        const f2 = '700 ' + (cw < 96 ? 12 : 14) + 'px ' + MONO;
        txt(r ? String(r[0]) : '…', x + 12, y + ch - 9, r && r[3] ? '#9dffb0' : '#fff6e0', f2, 'left');
        if (r && r[2]) { ctx.font = '600 9px ' + MONO; txt(r[1] + '/' + r[2], x + cw - 5, y + ch - 9, '#c9bcd6', '600 9px ' + MONO, 'right'); }
      }
    }
    function heart(x, y, r, on) {
      ctx.fillStyle = on ? '#ee6a55' : 'rgba(242,233,216,.16)';
      ctx.beginPath(); ctx.moveTo(x, y + r * 0.85);
      ctx.bezierCurveTo(x - r * 1.3, y, x - r * 0.8, y - r * 1.05, x, y - r * 0.4);
      ctx.bezierCurveTo(x + r * 0.8, y - r * 1.05, x + r * 1.3, y, x, y + r * 0.85); ctx.fill();
    }
    function controlTip() {
      if (fine) {
        const b = (api.input && api.input.bindings) ? api.input.bindings() : [], kn = (id) => { const x = b.find((o) => o.id === id); return x && x.keys[0] ? keyName(x.keys[0]) : '?'; };
        return '클릭으로 스위치·기차를 눌러요. 키보드: 숫자 = 그 번호 스위치, 방향키로 고르고 ' + kn('flip') + ' = 바꾸기, ' + kn('hold') + ' = 기차 멈춤.';
      }
      return '동그란 스위치를 누르면 화살표 쪽으로 길이 바뀌어요. 달리는 기차를 누르면 3초 멈춰요.';
    }
    function drawReady(B) {
      const w = Math.min(lay2.w - 28, 340), x = (lay2.w - w) / 2, LD = B.L;
      const tipFont = '600 13px ' + FONT, ctlFont = '500 12px ' + FONT;
      const tipL = wrap(LD.tip || '', w - 32, tipFont), ctlL = wrap(controlTip(), w - 32, ctlFont);
      const h = 96 + tipL.length * 18 + 10 + ctlL.length * 16 + 22;
      const y = lay2.oy + Math.max(lay2.sc * 1.2, (GH * lay2.sc - h) * 0.42);
      const al = readyHide ? 0 : U.clamp(B.tm / 0.9, 0, 1);
      readyRect = al > 0.3 ? [x, y, w, h] : null;
      if (al <= 0) return;
      ctx.globalAlpha = al;
      panel(x, y, w, h);
      txt(st.n === 1 ? '스테이지 ' + (st.li + 1) : '기차 ' + B.n + '대 · 모두 같은 선로', lay2.w / 2, y + 18, '#e3ae45', '700 12px ' + FONT);
      txt(fitText(LD.n, w - 80, '400 22px ' + DISP), lay2.w / 2, y + 44, '#f2e9d8', '400 22px ' + DISP);
      let yy = y + 70;
      tipL.forEach((l) => { txt(l, lay2.w / 2, yy, '#f2e9d8', tipFont); yy += 18; });
      yy += 6; ctlL.forEach((l) => { txt(l, lay2.w / 2, yy, '#c9bcd6', ctlFont); yy += 16; });
      yy += 8;
      // colour → emblem legend
      const ks = LD.sta.map((q) => q.k).sort((a, b) => a - b), gap = Math.min(40, (w - 30) / ks.length);
      ks.forEach((k, i) => { const cx = lay2.w / 2 + (i - (ks.length - 1) / 2) * gap; ctx.fillStyle = COL[k]; circ(ctx, cx, yy + 4, 9); ctx.fill(); ctx.fillStyle = '#fffaf0'; emblemPath(ctx, k, cx, yy + 4, 6); ctx.fill(); });
      const cd = Math.max(1, Math.ceil(B.tm / (READY_T / 3)));
      txt(String(cd), x + w - 24, y + 22, '#ffd24a', '800 24px ' + MONO);
      txt('눌러서 닫기', x + w - 10, y + h - 9, 'rgba(201,188,214,.6)', '500 10px ' + FONT, 'right');
      ctx.globalAlpha = 1;
    }
    function drawFin(B) {
      const w = Math.min(lay2.w - 40, 300), h = 100, x = (lay2.w - w) / 2, y = lay2.oy + lay2.sc * 3;
      const a = Math.min(1, finT * 3); ctx.globalAlpha = a;
      panel(x, y, w, h);
      if (B.solo) {
        const win = B.hp > 0;
        txt(win ? '모두 보냈어요!' : '하트를 다 잃었어요', lay2.w / 2, y + 26, win ? '#ffe08a' : '#ffb0a0', '400 22px ' + DISP);
        if (win) { for (let i = 0; i < 3; i++) txt('★', lay2.w / 2 + (i - 1) * 30, y + 58, i < B.hp ? '#ffd24a' : 'rgba(242,233,216,.2)', '700 26px ' + FONT); }
        else txt('맞게 보낸 기차 ' + B.ok + '대', lay2.w / 2, y + 58, '#f2e9d8', '700 14px ' + FONT);
        txt(bestNew ? '새 기록!' : '성공 ' + B.ok + ' · 틀림 ' + B.bad + ' · 쾅 ' + B.cr, lay2.w / 2, y + 84, '#c9bcd6', '600 12px ' + FONT);
      } else {
        txt('끝! ' + B.sc + '점', lay2.w / 2, y + 28, '#ffe08a', '400 24px ' + DISP);
        txt('성공 ' + B.ok + ' · 틀림 ' + B.bad + ' · 쾅 ' + B.cr, lay2.w / 2, y + 58, '#f2e9d8', '700 14px ' + FONT);
        txt(st.ph === 'play' ? '다른 사람을 기다리는 중…' : '', lay2.w / 2, y + 82, '#c9bcd6', '600 12px ' + FONT);
      }
      ctx.globalAlpha = 1;
    }
    function hint(B) {
      if (!B || !st) return '';
      if (!isMine(view)) return mine().length ? '구경 중: ' + name(view) + ' · 위 점수판을 눌러 바꾸기' : '';
      if (!canCtl()) return '';
      if (B.ph === 'ready') return '시작 전에 스위치를 미리 바꿔 둘 수 있어요';
      if (fine) return '숫자 1~' + Math.min(7, B.sw.length) + ' = 스위치 · 방향키+스페이스 · Q = 기차 멈춤';
      const LD = B.L;
      if (LD.cross.length) return '✕ 건널목이 깜빡이면 기차 한 대를 눌러 세워요';
      return '스위치를 눌러 화살표를 바꿔요 · 기차 색 = 역 색';
    }
    function draw(now) {
      const w = cv.w, h = cv.h;
      ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h);
      if (!st || !lay2 || st.ph === 'pick') return;
      if (!key) { txt('준비 중…', w / 2, h / 2, '#ab9fb8', '600 14px ' + FONT); return; }
      const B = BS[view];
      drawHud(B);
      if (!B) { txt(name(view) + ' 님이 하는 중…', w / 2, h / 2, '#ab9fb8', '600 14px ' + FONT); return; }
      getStatic(B);
      const s = lay2.sc, fr = lay2.FR * s;
      const sx = shakeT > 0 ? Math.sin(now * 0.09) * shakeT * 12 : 0;
      ctx.save(); ctx.translate(sx, 0);
      ctx.drawImage(statC, lay2.ox - fr, lay2.oy - fr, lay2.bw, lay2.bh);
      const m = 0.1 * s;
      B.L.sws.forEach((S, si) => { const sp = swSpr[si]; if (sp) ctx.drawImage(sp[B.sw[si]], PX(S.c % GW) - m, PY((S.c / GW) | 0) - m, s + 2 * m, s + 2 * m); });
      drawSwitches(B, now);
      ctx.save(); ctx.beginPath(); ctx.rect(lay2.ox, lay2.oy, GW * s, GH * s); ctx.clip();
      drawTrains(B, 1);
      ctx.restore();
      ctx.drawImage(topC, lay2.ox - fr, lay2.oy - fr, lay2.bw, lay2.bh);
      drawTrains(B, 2);
      drawTunnelSigns(B);
      drawStops(B, now);
      drawQueue(B);
      crossWarn(B, now);
      if (isMine(view)) drawCursor(B, now);
      for (const q of parts) { ctx.globalAlpha = Math.max(0, q.t / q.T); ctx.fillStyle = q.c; ctx.fillRect(PX(q.x) - 2.5, PY(q.y) - 2.5, 5, 5); }
      ctx.globalAlpha = 1;
      for (const f of floats) {
        const k = f.t / f.T, yy = PY(f.y) - (1 - k) * s * 0.7, font = (f.big ? '400 20px ' : '400 16px ') + DISP;
        ctx.globalAlpha = Math.min(1, k * 2.5);
        ctx.font = font; const tw = ctx.measureText(f.text).width, xx = U.clamp(PX(f.x), tw / 2 + 6, w - tw / 2 - 6);
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.strokeText(f.text, xx, yy);
        txt(f.text, xx, yy, f.col, font);
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      if (B.ph === 'ready' && (isMine(view) || !mine().length)) drawReady(B); else readyRect = null;
      if (B.ph === 'over' && isMine(view)) drawFin(B);
      const hl = hint(B);
      if (hl) txt(fitText(hl, ffBtn.hidden ? w - 20 : w - 150, '600 12px ' + FONT), ffBtn.hidden ? w / 2 : 12, lay2.barY + lay2.barH / 2, 'rgba(242,233,216,.78)', '600 12px ' + FONT, ffBtn.hidden ? 'center' : 'left');
    }

    const stop = U.loop(frame);
    layout();
    root._tr = { BS: () => BS, view: () => view, lay: () => lay2, st: () => st, hit: (x, y) => { const B = myB(); return B ? hitTest(B, x, y) : null; }, px: (x, y) => ({ x: PX(x), y: PY(y) }) };   // test hook
    return {
      update(state) {
        st = state;
        if (!st) return;
        if (st.ph === 'pick') buildPicker(); else dropPicker();
        if (st.ph === 'done') BS.forEach((B) => { if (B) B.ph = 'over'; });
        syncBar();
      },
      destroy() {
        stop();
        if (offKeys) offKeys();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('contextmenu', noCtx);
        ffBtn.remove(); dropPicker();
        cv.destroy(); styleEl.remove();
      },
    };
  }

  L.register({
    id: 'trains', name: '꼬마 기차 선로 바꾸기', tag: '실시간 선로 바꾸기', cat: '아케이드',
    blurb: '터널에서 나온 색깔 기차를 같은 색 역으로! 갈림길 스위치를 톡톡 바꿔 길을 열어 줘요. 여럿이면 같은 선로에서 동시에 점수 대결, 혼자면 15개 스테이지 별 모으기.',
    tint: '#2f5a2a',
    icon: '<path d="M8 50V30a12 12 0 0 1 12-12h28" fill="none" stroke="currentColor" stroke-width="4"/><path d="M20 50V36a6 6 0 0 1 6-6h22" fill="none" stroke="currentColor" stroke-width="4" opacity=".55"/><rect x="30" y="8" width="18" height="12" rx="3" fill="currentColor"/><circle cx="35" cy="22" r="2.6" fill="currentColor"/><circle cx="44" cy="22" r="2.6" fill="currentColor"/><circle cx="14" cy="30" r="5" fill="none" stroke="currentColor" stroke-width="3"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'map', label: '선로 (여럿이 할 때)', choices: [{ v: 0, label: '쉬움' }, { v: 1, label: '보통' }, { v: 2, label: '어려움' }, { v: 3, label: '무작위' }], def: 1 },
      { id: 'cnt', label: '기차 수 (여럿이 할 때)', choices: [{ v: 16, label: '16대' }, { v: 24, label: '24대' }, { v: 32, label: '32대' }], def: 24 },
    ],
    controls: [
      { id: 'up', label: '스위치 고르기 ↑', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '스위치 고르기 ↓', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '스위치 고르기 ←', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '스위치 고르기 →', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'flip', label: '고른 스위치 바꾸기', keys: ['Space', 'Enter'], pad: ['a'] },
      { id: 'hold', label: '고른 곳으로 오는 기차 멈춤·출발', keys: ['KeyQ', 'ShiftLeft'], pad: ['x', 'b'] },
      { id: 's1', label: '1번 스위치 바꾸기', keys: ['Digit1', 'Numpad1'], pad: [] },
      { id: 's2', label: '2번 스위치 바꾸기', keys: ['Digit2', 'Numpad2'], pad: [] },
      { id: 's3', label: '3번 스위치 바꾸기', keys: ['Digit3', 'Numpad3'], pad: [] },
      { id: 's4', label: '4번 스위치 바꾸기', keys: ['Digit4', 'Numpad4'], pad: [] },
      { id: 's5', label: '5번 스위치 바꾸기', keys: ['Digit5', 'Numpad5'], pad: [] },
      { id: 's6', label: '6번 스위치 바꾸기', keys: ['Digit6', 'Numpad6'], pad: [] },
      { id: 's7', label: '7번 스위치 바꾸기', keys: ['Digit7', 'Numpad7'], pad: [] },
    ],
    quick: [
      '터널에서 나온 색깔 기차를 같은 색(같은 모양 표시) 역으로 보내요.',
      '갈림길의 동그란 스위치를 누르면 화살표 쪽으로 길이 바뀌어요. 기차를 누르면 3초 멈춰요.',
      '혼자: 하트 3개, 끝까지 가면 남은 하트만큼 별! 여럿: 같은 선로에서 동시에, 점수가 가장 높으면 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '장난감 나무 기찻길이에요. 터널에서 빨강·파랑·노랑… 색깔 기차가 차례로 나와요.',
        '기차마다 같은 색 역이 있어요. 역 지붕과 기차 지붕에 같은 모양(동그라미·네모·세모·별·마름모·십자)이 그려져 있어 색이 헷갈려도 구분할 수 있어요.',
        '갈림길 스위치를 바꿔 모든 기차를 자기 역으로 보내면 성공!',
      ] },
      { h: '조작', p: [
        '스위치: 갈림길 가운데의 동그란 나무 손잡이. 누르면 화살표가 반대쪽으로 바뀌고, 밝은 선로 쪽으로 기차가 가요. 손잡이 근처 아무 데나 눌러도 돼요.',
        '기차가 스위치 위를 지나는 동안은 바뀌지 않아요. 그때 누르면 「예약」 — 기차가 지나가자마자 바뀌어요(다시 누르면 취소).',
        '기차 멈추기: 달리는 기차를 누르면 3초 동안 서요(빨간 표시). 다시 누르면 바로 출발.',
        '스위치 둘레의 작은 색 점은 「다음에 올 기차」의 색이에요. 화살표와 색 점을 함께 보면 편해요.',
        '터널 위 표지판은 그 터널에서 다음에 나올 기차예요. 빙 둘러 차오르는 테두리가 다 차면 나와요.',
        '화면이 길면 맨 위에 「다음 기차」 순서가 보여요(작은 화살표 = 나올 터널 방향). 시작 전 안내판은 눌러서 닫을 수 있어요.',
        'PC: 숫자 1~7 = 그 번호 스위치 바꾸기. 방향키·WASD로 고르고 스페이스·Enter로 바꾸기, Q·Shift = 고른 곳으로 오는 기차 멈춤·출발. 마우스 클릭도 돼요. 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '특별한 기차', p: [
        '급행(금색 줄, 뾰족한 앞): 1.5배쯤 빨라요.',
        '화물(짐칸 2개): 느리지만 길어서 스위치를 오래 막아요.',
        '거꾸로 기차(기관차가 뒤에서 밀고, ↺ 표시): 스위치 화살표의 반대쪽으로 가요! 거꾸로 기차가 다가오면 스위치에 점선 ↺ 화살표로 진짜 갈 길을 보여 줘요.',
        '특별한 기차는 맞게 보내면 점수가 더 커요(15점).',
      ] },
      { h: '선로', p: [
        '합류: 두 길이 하나로 모이는 곳은 기차들이 알아서 양보해요. 같은 길에서도 앞 기차와 알아서 거리를 둬요.',
        '건널목(빨강·하양 ✕ 표시): 두 길이 그냥 엇갈리는 곳. 두 기차가 동시에 지나가면 쾅! 위험하면 경고 표시가 깜빡여요. 한 대를 눌러 세워요.',
        '다리: 위아래로 지나가서 부딪히지 않아요. 고리·순환선: 놓친 기차가 한 바퀴 돌아 다시 와요.',
        '너무 오래 빙빙 도는 기차(한 바퀴 넘게 헤매기)는 길을 잃고 차고로 돌아가요. 틀린 것과 같아요.',
        '갈수록 기차가 빨라지고 더 자주 나와요.',
      ] },
      { h: '점수·승리', p: [
        '혼자(스테이지 15개): 하트 3개로 시작. 틀린 역에 가거나 쾅 부딪히면 하트 −1. 기차를 모두 보내면 남은 하트만큼 별(★★★ = 한 번도 안 틀림). 하트를 다 잃으면 다시 도전!',
        '여럿: 모두 같은 선로, 같은 순서의 기차로 각자 자기 판에서 동시에 해요. 맞게 보내면 10점(특별한 기차 15점) + 연속 보너스(연속으로 맞히면 +1, +2 … 최대 +5). 틀리면 0점이고 연속이 끊겨요. 쾅 부딪히면 −10점.',
        '모두 끝나면 점수가 가장 높은 사람이 승리(같으면 성공한 기차 수, 그다음 덜 부딪힌 사람).',
      ] },
      { h: '예시', p: [
        '터널 표지판에 파란 네모 기차가 보여요 → 갈림길 스위치를 눌러 화살표를 파란 역 쪽으로 → 기차가 파란 역에 쏙 = 「+10」.',
        '바로 뒤에 빨간 기차가 와요 → 파란 기차가 스위치를 지나자마자 다시 눌러 빨간 역 쪽으로(기차가 위에 있을 때 누르면 예약돼요).',
        '건널목에 두 기차가 동시에 다가와 ✕가 깜빡여요 → 한 대를 톡 눌러 세우면, 다른 기차가 지나간 뒤 다시 출발!',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 해요. 혼자 시작하면서 자리를 늘리면 나머지는 AI예요(각자 자기 판).',
        '친구와는 온라인·LAN 방으로: 각자 폰에서 자기 판을 하고, 위 점수판에 모두의 점수가 실시간으로 보여요.',
        '설정에서 선로(쉬움·보통·어려움·무작위)와 기차 수(16·24·32대)를 골라요. 혼자 할 때는 스테이지 고르기 화면이 나와요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 늦게 바꾸거나 가끔 헷갈리고, 어려움은 빨리 바꾸고 건널목에서 기차를 세울 줄 알아요.',
        '내 판이 끝나면 AI 판을 구경할 수 있어요(위 점수판을 눌러 바꾸기, 「빨리 보기」).',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { LAYS, STG, TIERS, lay, parseLay, genSched, newBoard, step, runFor, tapSwitch, tapTrain, aiInit, aiThink, exitOf, bestBranch, finish, occOf, posAt, TLEN, GW, GH, DT, HZ },
  });
})();
