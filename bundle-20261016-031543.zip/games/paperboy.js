/* 신문 배달 자전거 — realtime newspaper-delivery bike race (1–4 riders, one per phone).
   Top-down street that scrolls upward: the bike rides forward on its own, the player steers left/right and throws papers to
   the left or right side. A paper always flies the same distance sideways (D_THROW) and lands a little ahead (the bike's
   speed × flight time), so WHERE you ride decides where it lands: centre line = mailboxes, closer to a side = that side's
   doorstep. Subscriber houses (bright roof + newspaper badge, flag up) score; "신문 사절" houses (grey roof, red badge) cost
   points. Obstacles: trash cans, dogs that dash out, construction, cars, cats, puddles, snowmen, stalls … (10 streets).
   Everyone rides their own copy of the same seeded street at the same time (own board); the clock ends the round.
   Online: each device simulates the riders it owns (host: its human + AI, guest: its own human) on the host's clock and
   publishes compact snapshots (~12 Hz); the host relays everyone + the clock and ends the round. Rivals show as ghosts. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const CURB = 24, ROAD0 = 30, ROAD1 = 70, XMIN = 26, XMAX = 74, MID = 50;
  const D_THROW = 28, T_FLY = 0.6, CD_THROW = 0.3, HMAX = 9;
  const VX = 46, ACC_N = 280, ACC_PUD = 35;
  const RR = 2.0, RB = 3, RF = 4;                        // bike capsule: y-RB … y+RF, radius RR
  const H = 1 / 60;
  const PAPER0 = 12, PAPER_MAX = 20, BUNDLE = 6;
  const PTS = { mb: 150, door: 100, lawn: 50 }, BADP = 50, CB = 10, CBMAX = 10;
  const STUN = 0.9, RECOV = 0.8, INV = 1.9, DOG_V = 24;
  const MBX = 21.5, MBR = 3.6, HOUSE_X1 = 13, DOOR_X1 = 18.5, DOOR_HH = 6;
  const COUNT = 3, INTRO = 2.8, GRACE = 1.0;
  const STARF = [0.35, 0.55, 0.72];
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const fmtT = (s) => { s = Math.max(0, Math.ceil(s)); const m = Math.floor(s / 60), r = s - m * 60; return m + ':' + (r < 10 ? '0' : '') + r; };
  function hash32(a, b) {
    let h = (Math.imul(a | 0, 0x9E3779B1) ^ Math.imul((b | 0) + 0x632BE5AB, 0x85EBCA77)) >>> 0;
    h ^= h >>> 16; h = Math.imul(h, 0x7feb352d) >>> 0; h ^= h >>> 15; h = Math.imul(h, 0x846ca68b) >>> 0; h ^= h >>> 16;
    return h >>> 0;
  }
  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) * 1.4;

  /* streets: v0 base speed, acc steering grip, sub = share of subscribers, gap = metres between events, ev = event weights */
  const MAPS = [
    { id: 'sunny', nm: '햇살 골목', th: 'day', hint: '조용한 동네 골목. 처음 하기 딱 좋아요.', v0: 30, sub: 0.36, gap: [36, 60], ev: { can: 3, dog: 1.2, park: 1.2, car: 0.6, oncar: 0.6, cat: 0.6 } },
    { id: 'dogs', nm: '멍멍 마을', th: 'day', hint: '마당의 개가 자전거를 보면 길로 뛰어나와요!', v0: 30, sub: 0.34, gap: [26, 44], ev: { dog: 5, can: 1.2, cat: 1.6, park: 0.6 } },
    { id: 'work', nm: '공사 중 거리', th: 'work', hint: '공사 칸막이와 고깔이 길을 막아요. 틈으로 빠져나가요.', v0: 29, sub: 0.34, gap: [32, 52], ev: { work: 3.5, cone: 2.5, can: 1, park: 0.6 } },
    { id: 'traffic', nm: '출근길 큰길', th: 'day', hint: '차가 다녀요. 가운데 줄 왼쪽은 마주 오는 차, 오른쪽은 느린 차!', v0: 31, sub: 0.34, gap: [26, 42], ev: { car: 2.4, oncar: 3, park: 2, can: 0.6, cat: 0.4 } },
    { id: 'rain', nm: '비 오는 날', th: 'rain', hint: '길이 미끄러워 핸들이 늦게 들어요. 물웅덩이는 더 미끄러워요.', v0: 28, acc: 130, sub: 0.34, gap: [30, 50], ev: { puddle: 3.5, can: 1.4, oncar: 1, dog: 0.8, park: 0.8 } },
    { id: 'wind', nm: '바람 부는 날', th: 'dusk', hint: '옆바람이 신문을 밀어요. 떨어질 자리 표시를 잘 봐요.', v0: 29, wind: 7, sub: 0.34, gap: [34, 56], ev: { can: 2, dog: 1.2, cat: 0.8, park: 1, cone: 0.6 } },
    { id: 'hill', nm: '오르락내리락', th: 'dusk', hint: '오르막은 느리고 내리막은 빨라요. 던지는 때가 달라져요.', v0: 30, hill: 0.36, sub: 0.34, gap: [32, 52], ev: { can: 2, park: 1.4, oncar: 1, car: 0.6, dog: 1 } },
    { id: 'night', nm: '새벽 배달', th: 'night', hint: '아직 깜깜해요. 전조등·가로등 불빛과 구독 집 현관등을 봐요.', v0: 28, dark: 1, sub: 0.34, gap: [34, 54], ev: { can: 2.4, dog: 1.6, park: 1.2, cat: 0.8 } },
    { id: 'snow', nm: '눈 오는 날', th: 'snow', hint: '눈길이라 미끄러워요. 눈사람과 썰매 타는 아이를 조심!', v0: 27, acc: 110, sub: 0.34, gap: [30, 50], ev: { snowman: 2.6, sled: 1.8, can: 0.6 } },
    { id: 'market', nm: '시장 골목', th: 'market', hint: '좁고 북적여요. 노점과 길 건너는 사람을 피해요.', v0: 26, sub: 0.36, gap: [22, 38], ev: { stall: 2.6, walk: 3.2, can: 1.6 } },
  ];
  const mapOf = (id) => MAPS.find((m) => m.id === id) || MAPS[0];

  function speedAt(W, t, y) {
    const M = W.M;
    let v = M.v0 * (1 + 0.22 * clamp(t / W.dur, 0, 1));
    if (M.hill) v *= 1 + M.hill * Math.sin(y * 6.283 / 560 + 0.6);
    return v;
  }
  const hillAt = (W, y) => (W.M.hill ? W.M.hill * Math.sin(y * 6.283 / 560 + 0.6) : 0);
  function windAt(W, t) { const k = W.M.wind; return k ? k * (0.8 * Math.sin(t * 6.283 / 12 + W.wph) + 0.2 * Math.sin(t * 6.283 / 4.7 + W.wph * 2)) : 0; }
  function nomT(W, y) { const a = W.nom; let lo = 0, hi = a.length - 1; if (y <= 0) return 0; if (y >= a[hi]) return hi * 0.1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (a[m] < y) lo = m; else hi = m; } return (lo + (y - a[lo]) / Math.max(1e-6, a[hi] - a[lo])) * 0.1; }
  const nomY = (W, t) => { const i = clamp(Math.floor(t * 10), 0, W.nom.length - 1); return W.nom[i]; };
  function lowerBound(arr, y) { let lo = 0, hi = arr.length; while (lo < hi) { const m = (lo + hi) >> 1; if (arr[m].y < y) lo = m + 1; else hi = m; } return lo; }

  function buildWorld(seed, mid, dur) {
    const M = mapOf(mid), R = rng(seed);
    const W = { seed: seed >>> 0, M, dur, lots: [[], []], st: [], mv: [], dogs: [], pud: [], bun: [], wph: R() * 6.283, nom: null, maxY: 0, perf: 0, nsub: 0 };
    const nom = [0]; let y = 0;
    const nT = Math.ceil((dur + 6) / 0.1);
    for (let i = 1; i <= nT; i++) { y += speedAt(W, i * 0.1 - 0.05, y) * 0.1; nom.push(y); }
    W.nom = nom; W.maxY = y + 260;
    for (let sd = 0; sd < 2; sd++) {
      let yy = -70, i = 0, run = 0;
      while (yy < W.maxY) {
        const len = 46 + Math.floor(R() * 4) * 5;
        let sub = R() < M.sub; if (run >= 3) sub = true;
        if (yy + len < 34) sub = false;
        run = sub ? 0 : run + 1;
        const dy = yy + len * (0.3 + R() * 0.4);
        let my = dy + (R() < 0.5 ? -1 : 1) * (13 + R() * 5);
        if (my < yy + 5 || my > yy + len - 5) my = dy - (my - dy);
        my = clamp(my, yy + 5, yy + len - 5);
        W.lots[sd].push({ i, sd, y0: yy, y1: yy + len, sub: sub ? 1 : 0, dy, my, c: Math.floor(R() * 5), k: Math.floor(R() * 4) });
        yy += len; i++;
      }
    }
    const evs = Object.keys(M.ev), tot = evs.reduce((a, k) => a + M.ev[k], 0);
    let ey = 95;
    while (ey < W.maxY - 60) {
      let q = R() * tot, k = evs[0];
      for (const e of evs) { q -= M.ev[e]; if (q <= 0) { k = e; break; } }
      place(W, R, k, ey);
      ey += M.gap[0] + R() * (M.gap[1] - M.gap[0]);
    }
    W.st.sort((a, b) => a.y - b.y); W.dogs.sort((a, b) => a.y - b.y); W.pud.sort((a, b) => a.y - b.y);
    W.dogs.forEach((d, i) => { d.i = i; });
    let by = 110 + R() * 40;
    while (by < W.maxY) {
      let x = 33 + R() * 34;
      if (collide(W, x, by, 0, 2, [], null)) x = 100 - x;
      if (collide(W, x, by, 0, 2, [], null)) x = MID;
      W.bun.push({ i: W.bun.length, x, y: by });
      by += 220 + R() * 100;
    }
    // a perfect run (no crash, every subscriber hit in the mailbox) → star targets for solo play
    const endY = nomY(W, dur);
    let n = 0, perf = 0;
    for (let sd = 0; sd < 2; sd++) for (const lot of W.lots[sd]) if (lot.sub && lot.y1 > 30 && lot.y1 + 6 < endY) n++;
    for (let k = 0; k < n; k++) perf += PTS.mb + CB * Math.min(k, CBMAX);
    W.perf = perf; W.nsub = n;
    return W;
  }
  function place(W, R, k, y) {
    const side = R() < 0.5 ? 0 : 1, mir = (x) => (side ? 100 - x : x);
    const tm = nomT(W, y);
    if (k === 'can') {
      const n = R() < 0.35 ? 2 : 1;
      for (let j = 0; j < n; j++) { const x = R() < 0.5 ? mir(26.5 + R() * 2.5) : mir(31 + R() * 5); W.st.push({ k: 'can', x, y: y + j * 8, r: 2.3 }); }
    } else if (k === 'cone') {
      const n = 2 + Math.floor(R() * 3), x0 = 32 + R() * (36 - n * 5);
      for (let j = 0; j < n; j++) W.st.push({ k: 'cone', x: x0 + j * 5, y: y + (R() - 0.5) * 2, r: 1.7 });
    } else if (k === 'work') {
      if (R() < 0.5) {
        const gw = 14 + R() * 5, gc = 34 + R() * 32, a = gc - gw / 2, b = gc + gw / 2;
        if (a > XMIN + 1) W.st.push({ k: 'bar', x: (XMIN - 2 + a) / 2, y, hw: (a - XMIN + 2) / 2, hh: 1.6 });
        if (b < XMAX - 1) W.st.push({ k: 'bar', x: (b + XMAX + 2) / 2, y, hw: (XMAX + 2 - b) / 2, hh: 1.6 });
      } else {
        const len = 24 + R() * 18, lft = R() < 0.5;
        const xa = lft ? XMIN - 2 : 52 + R() * 4, xb = lft ? 48 - R() * 4 : XMAX + 2;
        W.st.push({ k: 'pit', x: (xa + xb) / 2, y: y + len / 2, hw: (xb - xa) / 2, hh: len / 2 });
      }
    } else if (k === 'park') {
      W.st.push({ k: 'park', x: side ? 66 : 34, y, hw: 3.9, hh: 7.8, c: Math.floor(R() * 6), d: R() < 0.5 ? 1 : -1 });
    } else if (k === 'car') {
      const vy = 11 + R() * 6, x = 55 + R() * 3;
      W.mv.push({ k: 'car', x, y0: y - vy * tm, vy, hw: 4, hh: 7.8, c: Math.floor(R() * 6) });
    } else if (k === 'oncar') {
      const vy = -(16 + R() * 8), x = 42 + R() * 3;
      W.mv.push({ k: 'oncar', x, y0: y - vy * tm, vy, hw: 4, hh: 7.8, c: Math.floor(R() * 6) });
    } else if (k === 'cat' || k === 'sled' || k === 'walk') {
      const sp = k === 'cat' ? 13 + R() * 5 : k === 'sled' ? 20 + R() * 6 : 5 + R() * 3, dir = side ? -1 : 1;
      const xs = dir > 0 ? 20 : 80, xm = 34 + R() * 32;
      W.mv.push({ k, xs, vx: sp * dir, t0: tm - (xm - xs) / (sp * dir), y, r: k === 'cat' ? 1.6 : k === 'sled' ? 2.5 : 2.0, c: Math.floor(R() * 6) });
    } else if (k === 'dog') {
      W.dogs.push({ k: 'dog', x: side ? 81 - R() * 3 : 19 + R() * 3, y, dir: side ? -1 : 1, run: 12 + R() * 22, trig: 40 + R() * 16, c: Math.floor(R() * 4) });
    } else if (k === 'snowman') {
      W.st.push({ k: 'snow', x: R() < 0.3 ? mir(28) : 32 + R() * 36, y, r: 2.9 });
    } else if (k === 'stall') {
      const len = 12 + R() * 10;
      W.st.push({ k: 'stall', x: side ? 71.5 : 28.5, y: y + len / 2, hw: 4.5, hh: len / 2, c: Math.floor(R() * 5) });
    } else if (k === 'puddle') {
      W.pud.push({ x: 34 + R() * 32, y, rx: 4.5 + R() * 2.5, ry: 6 + R() * 3 });
    }
  }

  /* moving things: cars drive along their lane on the shared clock, crossers cross at a fixed y */
  function mvPos(o, t, out) {
    if (o.k === 'car' || o.k === 'oncar') { out[0] = o.x; out[1] = o.y0 + o.vy * t; return out; }
    out[0] = clamp(o.xs + o.vx * Math.max(0, t - o.t0), 20, 80); out[1] = o.y; return out;
  }
  function dogPos(o, ta, t, out) { // out[2]: 0 home, 1 running out, 2 barking, 3 going back
    out[0] = o.x; out[1] = o.y; out[2] = 0;
    if (ta == null || ta < 0 || t < ta) return out;
    const e = t - ta, go = o.run / DOG_V;
    if (e < go) { out[0] = o.x + o.dir * DOG_V * e; out[2] = 1; }
    else if (e < go + 1.3) { out[0] = o.x + o.dir * o.run; out[2] = 2; }
    else if (e < go * 2 + 1.3) { out[0] = o.x + o.dir * (o.run - DOG_V * (e - go - 1.3)); out[2] = 3; }
    return out;
  }
  function hitC(x, y, ox, oy, rad) { const cy = clamp(oy, y - RB, y + RF), dx = ox - x, dy = oy - cy; return dx * dx + dy * dy < (rad + RR) * (rad + RR); }
  function hitR(x, y, cx, cy, hw, hh, m) { const dx = Math.max(0, Math.abs(x - cx) - hw), dy = Math.max(0, cy - hh - (y + RF), y - RB - (cy + hh)); return dx * dx + dy * dy < (RR + m) * (RR + m); }
  const TMP = [0, 0, 0];
  /* first obstacle the bike at (x, y) touches at time t (m = extra safety margin); dogTa(o) → trigger time or null */
  function collide(W, x, y, t, m, mvs, dogTa) {
    const S = W.st;
    for (let i = lowerBound(S, y - 26); i < S.length && S[i].y < y + 26; i++) {
      const o = S[i];
      if (o.r != null ? hitC(x, y, o.x, o.y, o.r + m) : hitR(x, y, o.x, o.y, o.hw, o.hh, m)) return o;
    }
    for (let i = 0; i < mvs.length; i++) {
      const o = mvs[i], p = mvPos(o, t, TMP);
      if (Math.abs(p[1] - y) > 16) continue;
      if (o.r != null ? hitC(x, y, p[0], p[1], o.r + m) : hitR(x, y, p[0], p[1], o.hw, o.hh, m)) return o;
    }
    if (dogTa) {
      const D = W.dogs;
      for (let i = lowerBound(D, y - 8); i < D.length && D[i].y < y + 8; i++) {
        const o = D[i], p = dogPos(o, dogTa(o), t, TMP);
        if (p[2] && hitC(x, y, p[0], p[1], 2.1 + m)) return o;
      }
    }
    return null;
  }
  function inPuddle(W, x, y) {
    const P = W.pud;
    for (let i = lowerBound(P, y - 10); i < P.length && P[i].y < y + 10; i++) { const p = P[i], dx = (x - p.x) / p.rx, dy = (y - p.y) / p.ry; if (dx * dx + dy * dy < 1) return true; }
    return false;
  }
  function lotAt(W, sd, y) {
    const A = W.lots[sd]; let lo = 0, hi = A.length - 1;
    if (!A.length || y < A[0].y0 || y >= A[hi].y1) return null;
    while (lo < hi) { const m = (lo + hi + 1) >> 1; if (A[m].y0 <= y) lo = m; else hi = m - 1; }
    return A[lo];
  }
  /* where on the yard a paper lands: mb (mailbox) · door (doorstep mat) · lawn · roof · back (over the back fence) · street */
  function zoneAt(W, sd, x, y) {
    const xx = sd === 0 ? x : 100 - x;
    if (xx > CURB) return { z: 'street', lot: null };
    const lot = lotAt(W, sd, y);
    if (!lot) return { z: 'street', lot: null };
    if (xx < 0) return { z: 'back', lot };
    const dx = xx - MBX, dy = y - lot.my;
    if (dx * dx + dy * dy <= MBR * MBR) return { z: 'mb', lot };
    if (xx >= HOUSE_X1 && xx <= DOOR_X1 && Math.abs(y - lot.dy) <= DOOR_HH) return { z: 'door', lot };
    if (xx < HOUSE_X1 && y > lot.y0 + 3 && y < lot.y1 - 3) return { z: 'roof', lot };
    return { z: 'lawn', lot };
  }
  const landPoint = (W, r, side, t, out) => { out[0] = r.x + side * D_THROW + windAt(W, t); out[1] = r.y + r.v * T_FLY; return out; };

  function newRider(s) {
    return { s, x: MID, y: 0, vx: 0, v: 0, stun: 0, rec: 1, inv: 0, cd: 0, pp: PAPER0, sc: 0, cb: 0, mc: 0, del: 0, subs: 0, acc: 0, cr: 0, bad: 0,
      fl: [], dl: new Set(), bg: new Set(), dg: {}, pi: [0, 0], di: 0, bi: 0, done: 0, slip: 0, fq: 0 };
  }
  /* pointers after a teleport (a seat taken over online) */
  function resync(W, r) {
    for (let sd = 0; sd < 2; sd++) { const A = W.lots[sd]; let i = 0; while (i < A.length && A[i].y1 + 6 < r.y) i++; r.pi[sd] = i; }
    r.di = lowerBound(W.dogs, r.y - 2); r.bi = lowerBound(W.bun, r.y - 8);
  }
  function landPaper(W, r, p, hooks) {
    const sd = p.lx < MID ? 0 : 1, z = zoneAt(W, sd, p.lx, p.ly);
    let pts = 0, kind = z.z;
    if (z.lot) {
      const key = sd * 1000 + z.lot.i;
      if (!z.lot.sub) { pts = -BADP; r.bad++; r.cb = 0; kind = 'bad'; }
      else if (z.z === 'roof' || z.z === 'back') kind = z.z;
      else if (r.dl.has(key)) kind = 'dup';
      else {
        r.dl.add(key); r.del++; if (z.z !== 'lawn') r.acc++;
        pts = PTS[z.z] + CB * Math.min(r.cb, CBMAX); r.cb++; if (r.cb > r.mc) r.mc = r.cb;
      }
    }
    r.sc = Math.max(0, r.sc + pts);
    if (hooks && hooks.land) hooks.land(r, p, kind, pts, z.lot, sd);
  }
  /* one rider, dt seconds. inp = {u: −1…1 steer, th: −1/0/1 throw, k: AI target key} */
  function stepRider(W, r, t, dt, inp, hooks) {
    for (let i = r.fl.length - 1; i >= 0; i--) { const p = r.fl[i]; if (t >= p.t0 + T_FLY) { r.fl.splice(i, 1); landPaper(W, r, p, hooks); } }
    for (let sd = 0; sd < 2; sd++) {
      const A = W.lots[sd];
      while (r.pi[sd] < A.length && A[r.pi[sd]].y1 + 6 < r.y) {
        const lot = A[r.pi[sd]++];
        if (lot.sub && lot.y1 > 30) { r.subs++; if (!r.dl.has(sd * 1000 + lot.i)) { r.cb = 0; if (hooks && hooks.miss) hooks.miss(r, lot, sd); } }
      }
    }
    if (t >= W.dur) {
      if (!r.done) { r.done = 1; if (hooks && hooks.end) hooks.end(r); }
      r.v = Math.max(0, r.v - 45 * dt); r.vx *= 0.9; r.y += r.v * dt; r.x = clamp(r.x + r.vx * dt, XMIN, XMAX);
      return;
    }
    if (r.inv > 0) r.inv -= dt;
    if (r.cd > 0) r.cd -= dt;
    if (r.stun > 0) { r.stun -= dt; r.rec = 0; } else r.rec = Math.min(1, r.rec + dt / RECOV);
    r.v = r.stun > 0 ? 0 : speedAt(W, t, r.y) * (0.3 + 0.7 * r.rec);
    const u = r.stun > 0 ? 0 : clamp((inp && inp.u) || 0, -1, 1);
    r.slip = inPuddle(W, r.x, r.y) ? 1 : 0;
    const acc = r.slip ? ACC_PUD : (W.M.acc || ACC_N);
    const dv = u * VX - r.vx, mx = acc * dt;
    r.vx += clamp(dv, -mx, mx);
    if (r.stun > 0) r.vx *= 0.85;
    r.x += r.vx * dt;
    if (r.x < XMIN) { r.x = XMIN; if (r.vx < 0) r.vx = 0; }
    if (r.x > XMAX) { r.x = XMAX; if (r.vx > 0) r.vx = 0; }
    r.y += r.v * dt;
    // dogs notice the bike
    const D = W.dogs;
    while (r.di < D.length && D[r.di].y - D[r.di].trig <= r.y) { const o = D[r.di++]; if (r.dg[o.i] == null) { r.dg[o.i] = t; if (hooks && hooks.dog) hooks.dog(r, o); } }
    // bundles
    const B = W.bun;
    while (r.bi < B.length && B[r.bi].y < r.y - 8) r.bi++;
    for (let j = r.bi; j < B.length && B[j].y < r.y + 8; j++) {
      const b = B[j];
      if (r.bg.has(b.i) || !hitC(r.x, r.y, b.x, b.y, 2.6)) continue;
      r.bg.add(b.i); const got = Math.min(BUNDLE, PAPER_MAX - r.pp); r.pp += got;
      if (hooks && hooks.pick) hooks.pick(r, b, got);
    }
    // throw
    const th = inp && inp.th;
    if (th && r.stun <= 0 && r.cd <= 0) {
      if (r.pp <= 0) { if (hooks && hooks.empty) hooks.empty(r); }
      else {
        r.pp--; r.cd = CD_THROW; r.fq = (r.fq + 1) % 1000;
        const lp = landPoint(W, r, th < 0 ? -1 : 1, t, [0, 0]);
        const p = { sx: r.x, sy: r.y, side: th < 0 ? -1 : 1, t0: t, lx: lp[0], ly: lp[1], k: inp.k != null ? inp.k : -1 };
        r.fl.push(p);
        if (hooks && hooks.throw) hooks.throw(r, p);
      }
    }
    // crash
    if (r.inv <= 0 && r.stun <= 0) {
      const o = collide(W, r.x, r.y, t, 0, W.mv, (d) => r.dg[d.i]);
      if (o) {
        r.stun = STUN; r.inv = INV; r.cb = 0; r.cr++; r.rec = 0;
        const ox = o.k === 'dog' ? dogPos(o, r.dg[o.i], t, TMP)[0] : o.xs != null ? mvPos(o, t, TMP)[0] : o.x;
        r.vx = (r.x >= ox ? 1 : -1) * 14;
        if (hooks && hooks.crash) hooks.crash(r, o);
      }
    }
  }
  function ranking(R) { return R.slice().sort((a, b) => b.sc - a.sc || b.acc - a.acc || a.cr - b.cr || a.s - b.s); }

  /* ----- AI: pick the next subscriber + the zone it aims for, choose a lane that avoids what it can see, throw when its
     (slightly wrong, per level) sense of the landing spot says so ----- */
  const AIP = { // look: s of road it checks · think: s between plans · err: landing-sense error · skip: forgets a house · bad: throws at a 신문 사절 house · mar: safety margin
    1: { look: 0.95, think: 0.26, err: 3.6, skip: 0.12, bad: 0.03, mar: 0.1, want: 1, low: 2 },
    2: { look: 1.45, think: 0.13, err: 2.3, skip: 0.05, bad: 0.012, mar: 0.7, want: 2, low: 5 },
    3: { look: 2.1, think: 0.07, err: 1.0, skip: 0.012, bad: 0, mar: 1.2, want: 3, low: 7 },
  };
  const RANKZ = { mb: 3, door: 2, lawn: 1 };
  const inFlight = (r, kk) => r.fl.some((p) => p.k === kk);
  const MVS = [];
  function plan(W, r, mem, P, t) {
    const v = Math.max(r.v, speedAt(W, t, r.y) * 0.5, 8), w = windAt(W, t + 0.6);
    const ly = r.y + v * T_FLY;
    let best = null;
    for (let sd = 0; sd < 2; sd++) {
      const A = W.lots[sd];
      for (let i = r.pi[sd]; i < A.length; i++) {
        const lot = A[i];
        if (lot.y0 > ly + v * 2.4) break;
        if (!lot.sub || lot.y1 - 5 < ly) continue;
        const kk = sd * 1000 + lot.i;
        if (r.dl.has(kk) || inFlight(r, kk)) continue;
        if (mem.sk[kk] === undefined) mem.sk[kk] = Math.random() < P.skip ? 1 : 0;
        if (mem.sk[kk] === 1) continue;
        let tz = P.want === 3 ? 'mb' : P.want === 2 ? ((lot.i + sd + mem.sv) % 3 ? 'door' : 'mb') : 'lawn';
        if (tz === 'mb' && lot.my + MBR * 0.4 < ly) tz = 'door';
        if (tz === 'door' && lot.dy + DOOR_HH * 0.5 < ly) tz = 'lawn';
        const ty = tz === 'mb' ? lot.my : tz === 'door' ? lot.dy : Math.max(ly + 3, (lot.y0 + lot.y1) / 2);
        const tt = (ty - ly) / v;
        const txx = tz === 'mb' ? MBX : tz === 'door' ? 15.8 : 19.5, side = sd ? 1 : -1;
        const rx = clamp((sd ? 100 - txx : txx) - side * D_THROW - w, XMIN, XMAX);
        if (!best || tt < best.tt) best = { tt, rx, kk, tz, sd, lot };
      }
    }
    let want = best ? best.rx : MID;
    if (!best || best.tt > 1.2) { // nothing urgent: drift toward a bundle if low on papers
      if (r.pp <= P.low) for (let j = r.bi; j < W.bun.length && W.bun[j].y < r.y + v * P.look * 1.4; j++) { const b = W.bun[j]; if (!r.bg.has(b.i) && b.y > r.y + 4) { want = b.x; break; } }
      else if (!best) want = MID;
    }
    // lanes
    const look = P.look * (W.M.dark ? 0.8 : 1), N = Math.max(4, Math.ceil(look / 0.05)), acc = W.M.acc || ACC_N;
    const y0 = r.y - 14, y1 = r.y + v * look + 18;
    MVS.length = 0;
    for (const o of W.mv) { const a = mvPos(o, t, TMP)[1], b = mvPos(o, t + look, TMP)[1]; if (Math.max(a, b) > y0 - 10 && Math.min(a, b) < y1 + 10) MVS.push(o); }
    const dogTa = (o) => (r.dg[o.i] != null ? r.dg[o.i] : t + Math.max(0, o.y - o.trig - r.y) / v);
    let bestC = 1e9, bestCx = r.x;
    const tryLane = (cx) => {
      let x = r.x, vx = r.vx, y = r.y, tt = t, c = 0, gotB = false;
      for (let k = 1; k <= N; k++) {
        const u = clamp((cx - x) / 2.5, -1, 1), dv = u * VX - vx, mx = acc * 0.05;
        vx += clamp(dv, -mx, mx); x = clamp(x + vx * 0.05, XMIN, XMAX); y += v * 0.05; tt += 0.05;
        if (r.inv > k * 0.05) continue;
        if (collide(W, x, y, tt, P.mar, MVS, dogTa)) { c += 1000 * (1 - 0.5 * k / N); break; }
        if (!gotB && r.pp <= P.low) for (let j = r.bi; j < W.bun.length && W.bun[j].y < y + 4; j++) { const b = W.bun[j]; if (!r.bg.has(b.i) && hitC(x, y, b.x, b.y, 2.6)) { gotB = true; c -= r.pp === 0 ? 90 : 35; break; } }
        if (P.want > 1 && inPuddle(W, x, y)) c += 3;
      }
      c += Math.abs(cx - want) * 2 + Math.abs(cx - mem.cx) * 0.35;
      if (c < bestC) { bestC = c; bestCx = cx; }
    };
    tryLane(clamp(want, XMIN, XMAX));
    for (let cx = XMIN + 1; cx <= XMAX - 1; cx += 3) tryLane(cx);
    mem.cx = bestCx;
    if (best) {
      let tz = best.tz;
      if (Math.abs(bestCx - best.rx) > 2.2) {
        const side = best.sd ? 1 : -1, dRx = clamp((best.sd ? 100 - 15.8 : 15.8) - side * D_THROW - w, XMIN, XMAX);
        tz = Math.abs(bestCx - dRx) < 2.2 && best.lot.dy + DOOR_HH * 0.5 >= ly ? 'door' : 'lawn';
      }
      mem.tz[best.kk] = tz;
    }
  }
  const LP = [0, 0];
  function aiThink(W, r, mem, lv, t, dt) {
    const out = mem.out || (mem.out = { u: 0, th: 0, k: -1 });
    out.th = 0; out.k = -1;
    if (!mem.P || mem.lv !== lv) { mem.lv = lv; mem.P = AIP[lv] || AIP[2]; mem.cx = r.x; mem.th = Math.random() * 0.1; mem.err = {}; mem.sk = {}; mem.tz = {}; mem.sv = Math.floor(Math.random() * 3); }
    if (r.done || r.stun > 0) { out.u = 0; return out; }
    const P = mem.P;
    mem.th -= dt;
    if (mem.th <= 0) { mem.th = P.think * (0.8 + Math.random() * 0.4); plan(W, r, mem, P, t); }
    const d = mem.cx - r.x;
    out.u = Math.abs(d) < 0.35 ? 0 : clamp(d / 2.5, -1, 1);
    if (r.cd > 0 || r.pp <= 0) return out;
    for (let k = 0; k < 2; k++) {
      const side = k ? 1 : -1, sd = k;
      landPoint(W, r, side, t, LP);
      const lot0 = lotAt(W, sd, LP[1]); if (!lot0) continue;
      const k0 = sd * 1000 + lot0.i;
      let e = mem.err[k0]; if (!e) e = mem.err[k0] = [gauss() * P.err, gauss() * P.err * 0.6];
      const z = zoneAt(W, sd, LP[0] + e[0], LP[1] + e[1]);
      if (!z.lot || z.z === 'street' || z.z === 'back' || z.z === 'roof') continue;
      const lot = z.lot, kk = sd * 1000 + lot.i;
      if (LP[1] + e[1] < lot.y0 + 3) continue; // not over the hedge yet
      if (!lot.sub) {
        if (mem.sk[kk] === undefined) mem.sk[kk] = Math.random() < P.bad ? 2 : 0;
        if (mem.sk[kk] === 2 && !mem['b' + kk]) { mem['b' + kk] = 1; out.th = side; out.k = kk; return out; }
        continue;
      }
      if (r.dl.has(kk) || inFlight(r, kk)) continue;
      if (mem.sk[kk] === undefined) mem.sk[kk] = Math.random() < P.skip ? 1 : 0;
      if (mem.sk[kk] === 1) continue;
      let tz = mem.tz[kk] || (P.want === 3 ? 'mb' : P.want === 2 ? 'door' : 'lawn');
      const yy = LP[1] + e[1];
      if (tz === 'mb' && yy > lot.my + MBR) tz = 'door';
      if (tz === 'door' && yy > lot.dy + DOOR_HH) tz = 'lawn';
      const late = yy > lot.y1 - 7;
      if (RANKZ[z.z] >= RANKZ[tz] || late) { out.th = side; out.k = kk; return out; }
    }
    return out;
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    let mp = String(o.map || 'rand');
    if (!MAPS.some((m) => m.id === mp)) mp = MAPS[U.rand(MAPS.length)].id;
    const dur = [60, 90, 120].indexOf(+o.time) >= 0 ? +o.time : 90;
    const sd = 1 + U.rand(2147483000);
    const s = { rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), mp, dur, sd, ph: 'count', res: null };
    if (n === 1) { const W = buildWorld(sd, mp, dur); s.sv = STARF.map((f) => Math.max(50, Math.round(W.perf * f / 50) * 50)); }
    return s;
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const M = mapOf(s.mp);
    const line = (r) => r[1] + '점 · 배달 ' + r[2] + '/' + r[3] + ' · 정확 ' + r[4] + (r[5] ? ' · 꽈당 ' + r[5] : '') + (r[6] ? ' · 사절 집 ' + r[6] : '');
    if (s.n === 1) {
      const r = s.res[0], sv = s.sv || [1e9, 1e9, 1e9], k = sv.filter((v) => r[1] >= v).length;
      const nb = s.bst != null && r[1] > s.bst;
      return { winners: k ? [r[0]] : [], title: '★'.repeat(k) + '☆'.repeat(3 - k) + '  ' + r[1] + '점',
        text: M.nm + ' · ' + s.dur + '초\n' + (nb ? '새 최고 기록!\n' : s.bst ? '최고 기록 ' + s.bst + '점\n' : '') + line(r) + '\n별 기준: ' + sv.join(' / ') + '점' };
    }
    const top = s.res[0][1], win = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = s.res.map((r, k) => (s.res.findIndex((q) => q[1] === r[1]) + 1) + '위  ' + nm(r[0]) + '  ' + line(r));
    return { winners: win, title: win.length > 1 ? '공동 1위! ' + top + '점' : nm(win[0]) + ' 1위! ' + top + '점', text: M.nm + ' · ' + s.dur + '초\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else c.rect(x, y, w, h); }
  function rgbOf(hex) { const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return [200, 200, 200]; const n = parseInt(m[1], 16); return [n >> 16, (n >> 8) & 255, n & 255]; }
  function hexA(hex, a) { const c = rgbOf(hex); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function shade(hex, k) { const c = rgbOf(hex), f = (v) => Math.round(k >= 0 ? v + (255 - v) * k : v * (1 + k)); return 'rgb(' + f(c[0]) + ',' + f(c[1]) + ',' + f(c[2]) + ')'; }
  const THEMES = {
    day: { lawn: '#3f8a52', lawn2: '#47925a', back: '#2c6440', hedge: '#235238', walk: '#a39282', walk2: '#8e7f70', road: '#3d3848', road2: '#45404f', line: '#f2e9d8', mid: '#e3ae45' },
    work: { lawn: '#4a8a4c', lawn2: '#529253', back: '#33653a', hedge: '#285236', walk: '#a8957f', walk2: '#93826d', road: '#45404a', road2: '#4d4752', line: '#f2e9d8', mid: '#e3ae45' },
    rain: { lawn: '#2f6a4a', lawn2: '#34704f', back: '#234d38', hedge: '#1b402f', walk: '#7f7683', walk2: '#6c6471', road: '#2b2937', road2: '#33303f', line: '#cfc7bb', mid: '#c99a3f' },
    dusk: { lawn: '#5a8a46', lawn2: '#62914c', back: '#3f6634', hedge: '#2e4f2c', walk: '#b09a84', walk2: '#9b8571', road: '#423a4a', road2: '#4a4252', line: '#f2e9d8', mid: '#e3ae45' },
    night: { lawn: '#356f4a', lawn2: '#3b7650', back: '#24503a', hedge: '#1c4330', walk: '#8f8293', walk2: '#7d7181', road: '#36323f', road2: '#3d3947', line: '#e4dccf', mid: '#d9a43f' },
    snow: { lawn: '#e3e8ef', lawn2: '#d9e0e9', back: '#c6d0dc', hedge: '#2e5a46', walk: '#b8b5bf', walk2: '#a7a4ae', road: '#67657a', road2: '#706e82', line: '#f6f2ea', mid: '#e3ae45' },
    market: { lawn: '#4b8650', lawn2: '#538d57', back: '#356039', hedge: '#2a5034', walk: '#b88d63', walk2: '#a37a53', road: '#4a3f48', road2: '#524650', line: '#f2e9d8', mid: '#e3ae45' },
  };
  const ROOF = ['#c8553f', '#c9902f', '#2f8a86', '#7a4a8a', '#3f68a8'];
  const CARC = ['#d0503c', '#3f68a8', '#e3ae45', '#f2e9d8', '#2f8a86', '#6b4f8f'];
  const DOGC = ['#b07a45', '#efe6d6', '#3a3030', '#d9a35c'];
  const PPLC = ['#e0705a', '#5a8fd0', '#e3ae45', '#7cc28a', '#b07ad0', '#f2e9d8'];
  const CSS = `
.pb-ctl{position:absolute;left:0;right:0;bottom:0;display:flex;align-items:stretch;justify-content:space-between;gap:10px;padding:8px 10px calc(8px + env(safe-area-inset-bottom));pointer-events:none;z-index:3;box-sizing:border-box}
.pb-steer{pointer-events:auto;display:flex;flex:0 1 200px;min-width:0;border-radius:18px;background:rgba(46,38,64,.9);border:1.5px solid rgba(227,174,69,.45);overflow:hidden;touch-action:none;user-select:none;-webkit-user-select:none;cursor:pointer}
.pb-steer>div{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;color:#f2e9d8;font:700 11px/1 "IBM Plex Sans KR",system-ui,sans-serif;min-width:44px}
.pb-steer>div+div{border-left:1px solid rgba(227,174,69,.28)}
.pb-steer>div.on{background:rgba(227,174,69,.32)}
.pb-steer svg,.pb-tb svg{display:block;pointer-events:none}
.pb-th{pointer-events:auto;display:flex;gap:8px;flex:0 1 210px;min-width:0}
.pb-tb{flex:1;min-width:44px;appearance:none;margin:0;padding:2px;border:1.5px solid rgba(242,233,216,.28);border-radius:18px;background:linear-gradient(#3d3157,#2a2140);color:#f2e9d8;font:700 11.5px/1.1 "IBM Plex Sans KR",system-ui,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;touch-action:none;user-select:none;-webkit-user-select:none;cursor:pointer}
.pb-tb.on{background:linear-gradient(#f0c565,#c08a2c);color:#17131f;border-color:#f6dc9a}
.pb-tb.off{opacity:.45}
.pb-ctl.idle .pb-steer,.pb-ctl.idle .pb-th{opacity:.6}
`;
  const SVG_L = '<svg width="26" height="26" viewBox="0 0 26 26"><path d="M16 5 8 13l8 8" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const SVG_R = '<svg width="26" height="26" viewBox="0 0 26 26"><path d="M10 5l8 8-8 8" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const svgThrow = (d) => '<svg width="34" height="24" viewBox="0 0 34 24"><g transform="' + (d < 0 ? 'translate(34 0) scale(-1 1)' : '') + '"><path d="M4 20C8 9 17 5 27 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-dasharray="3 3"/><path d="M23 3l6 4-5 5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><rect x="2" y="14" width="9" height="6" rx="2" fill="currentColor"/></g></svg>';

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    cv.cv.style.touchAction = 'none';
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const me = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const isMine = (s) => s >= 0 && s === me();
    const auto = () => !!(L.debug && L.debug.autoplay);
    let st = null, key = null, W = null, phase = 'wait', cd = 0, acc = 0, lay = null, camY = 0;
    let aiMem = [], autoMem = {}, thQ = [], parts = [], floats = [], marks = [], banner = null, shake = 0, lastSfx = {};
    let doneSent = false, hintT = 0, thrown = false, best = null, strips = new Map(), owned = [], scPop = 0, dispSc = 0;
    let pubT = 0, hsQ = 0, inQ = 0, lastQ = -1, gotClock = false, nightC = null;
    const snaps = {}, remQ = {}, lastPack = {}, vis = [];
    const T = () => THEMES[(W && W.M.th) || 'day'];

    /* ----- controls (DOM) ----- */
    const ctl = L.h('div', { class: 'pb-ctl' });
    const steer = L.h('div', { class: 'pb-steer' }), sL = L.h('div', null), sR = L.h('div', null);
    sL.innerHTML = SVG_L + '<span>왼쪽</span>'; sR.innerHTML = SVG_R + '<span>오른쪽</span>';
    steer.appendChild(sL); steer.appendChild(sR);
    const thW = L.h('div', { class: 'pb-th' });
    const bL = L.h('button', { class: 'pb-tb', type: 'button', 'aria-label': '왼쪽 집으로 던지기' }), bR = L.h('button', { class: 'pb-tb', type: 'button', 'aria-label': '오른쪽 집으로 던지기' });
    bL.innerHTML = svgThrow(-1) + '<span>왼쪽 던지기</span>'; bR.innerHTML = svgThrow(1) + '<span>오른쪽 던지기</span>';
    thW.appendChild(bL); thW.appendChild(bR);
    ctl.appendChild(steer); ctl.appendChild(thW);
    root.appendChild(ctl);
    const steerPtr = new Map();
    let steerTouch = 0, dragP = null;
    function steerFrom(e) { const rc = steer.getBoundingClientRect(); return e.clientX < rc.left + rc.width / 2 ? -1 : 1; }
    function steerUpd() { let v = 0; for (const d of steerPtr.values()) v = d; steerTouch = v; sL.classList.toggle('on', v < 0); sR.classList.toggle('on', v > 0); }
    function sDown(e) { e.preventDefault(); try { steer.setPointerCapture(e.pointerId); } catch (er) {} steerPtr.set(e.pointerId, steerFrom(e)); steerUpd(); }
    function sMove(e) { if (!steerPtr.has(e.pointerId)) return; steerPtr.set(e.pointerId, steerFrom(e)); steerUpd(); }
    function sUp(e) { steerPtr.delete(e.pointerId); steerUpd(); }
    steer.addEventListener('pointerdown', sDown); steer.addEventListener('pointermove', sMove);
    steer.addEventListener('pointerup', sUp); steer.addEventListener('pointercancel', sUp); steer.addEventListener('lostpointercapture', sUp);
    function throwBtn(d) { return (e) => { e.preventDefault(); queueThrow(d); const b = d < 0 ? bL : bR; b.classList.add('on'); setTimeout(() => b.classList.remove('on'), 130); }; }
    const tL = throwBtn(-1), tR = throwBtn(1);
    bL.addEventListener('pointerdown', tL); bR.addEventListener('pointerdown', tR);
    const noCtx = (e) => e.preventDefault();
    ctl.addEventListener('contextmenu', noCtx); cv.cv.addEventListener('contextmenu', noCtx);
    // drag on the street = steer (the bike follows the finger sideways)
    function cDown(e) { if (me() < 0 || !W) return; e.preventDefault(); const r = W.r[me()]; dragP = { id: e.pointerId, px: e.clientX, bx: r.x, tx: r.x }; try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {} }
    function cMove(e) { if (!dragP || e.pointerId !== dragP.id || !lay) return; dragP.tx = clamp(dragP.bx + (e.clientX - dragP.px) / lay.s * 1.25, XMIN, XMAX); }
    function cUp(e) { if (dragP && e.pointerId === dragP.id) dragP = null; }
    cv.cv.addEventListener('pointerdown', cDown); cv.cv.addEventListener('pointermove', cMove);
    cv.cv.addEventListener('pointerup', cUp); cv.cv.addEventListener('pointercancel', cUp);
    const offIn = api.input ? api.input.on((type, id) => { if (type !== 'down') return; if (id === 'throwL') queueThrow(-1); else if (id === 'throwR') queueThrow(1); }) : () => {};
    function queueThrow(d) {
      if (me() < 0 || !W || phase !== 'race') return;
      if (thQ.length < 3) thQ.push(d);
      thrown = true;
    }
    function steerInput(r) {
      let u = 0;
      try { if (api.input) u = api.input.axis('left', 'right') || 0; } catch (e) { u = 0; }
      if (!u && steerTouch) u = steerTouch;
      if (!u && dragP) { const d = dragP.tx - r.x; u = Math.abs(d) < 0.4 ? 0 : clamp(d / 3, -1, 1); }
      return u;
    }
    const myInp = { u: 0, th: 0, k: -1 };

    function curKey() { return st ? st.rid + '.' + st.sd : null; }
    const bestKey = () => 'lounge.paperboy.best.' + (st ? st.mp + '.' + st.dur : '');
    function startRace() {
      W = buildWorld(st.sd, st.mp, st.dur);
      W.t = 0; W.r = []; for (let s = 0; s < st.n; s++) W.r.push(newRider(s));
      aiMem = W.r.map(() => ({})); autoMem = {};
      vis.length = 0; W.r.forEach(() => vis.push({ cr: 0, st: 0, fq: 0, tr: 0 }));
      parts = []; floats = []; marks = []; banner = null; thQ = []; acc = 0; doneSent = false; owned = [];
      lastQ = -1; gotClock = false; for (const k in snaps) delete snaps[k]; for (const k in remQ) delete remQ[k]; for (const k in lastPack) delete lastPack[k];
      phase = st.ph === 'race' ? 'race' : st.ph === 'done' ? 'done' : 'count';
      cd = phase === 'count' ? INTRO + COUNT : 0;
      hintT = me() >= 0 ? 7 : 0; thrown = false; dispSc = 0;
      best = null; if (st.n === 1) { try { const v = localStorage.getItem(bestKey()); if (v != null && v !== '' && isFinite(+v)) best = +v; } catch (e) {} }
      layout();
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h;
      const hudH = 60, ctlH = me() >= 0 ? clamp(Math.round(h * 0.13), 84, 104) : 0;
      ctl.style.display = me() >= 0 ? '' : 'none';
      ctl.style.height = ctlH + 'px';
      const avail = Math.max(120, h - hudH - ctlH);
      let s = w / 100; if (avail / s < 108) s = avail / 108;
      s = Math.max(2, s);
      const ox = (w - 100 * s) / 2;
      lay = { w, h, hudH, ctlH, s, ox, bikeY: hudH + avail * 0.77, avail };
      strips.clear(); nightC = null;
    }
    cv.onresize = () => { layout(); };
    const X = (x) => lay.ox + x * lay.s, Y = (y) => lay.bikeY - (y - camY) * lay.s;

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function burst(x, y, col, n, sp, life, kind) {
      for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = sp * (0.35 + Math.random() * 0.8); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: life * (0.6 + Math.random() * 0.5), T: life, c: col, k: kind || 0 }); }
      if (parts.length > 220) parts.splice(0, parts.length - 220);
    }
    function addFloat(x, y, text, col, t, big) { floats.push({ x, y, text, col, t: t || 1.2, T: t || 1.2, big: !!big }); if (floats.length > 10) floats.shift(); }
    const ZN = { mb: '우편함 쏙!', door: '현관 배달!', lawn: '마당 배달' };
    const hooks = {
      throw(r) { if (isMine(r.s)) { sfx('whoosh', 50); api.buzz(8); } },
      land(r, p, kind, pts, lot, sd) {
        if (!isMine(r.s)) return;
        marks.push({ x: p.lx, y: p.ly, a: (p.t0 * 7) % 6.28, k: kind }); if (marks.length > 40) marks.shift();
        if (kind === 'mb' || kind === 'door' || kind === 'lawn') {
          burst(p.lx, p.ly, kind === 'mb' ? '#ffd76a' : kind === 'door' ? '#f6ecd6' : '#9fe0a8', kind === 'lawn' ? 6 : 12, 22, 0.6, 1);
          addFloat(p.lx, p.ly + 5, ZN[kind] + ' +' + pts, kind === 'mb' ? '#ffd76a' : kind === 'door' ? '#f6ecd6' : '#bdf0c4', 1.2, kind !== 'lawn');
          if (r.cb >= 3 && (r.cb === 3 || r.cb % 5 === 0)) banner = { text: '콤보 ' + r.cb + '!', sub: '연속 배달 보너스 +' + CB * Math.min(r.cb, CBMAX), t: 1.3, small: 1 };
          sfx(kind === 'mb' ? 'win' : kind === 'door' ? 'pop' : 'chip', 60); api.buzz(kind === 'mb' ? 25 : 12); scPop = 1;
        } else if (kind === 'bad') { addFloat(p.lx, p.ly + 5, '신문 사절 집! −' + BADP, '#ff9a86', 1.4, true); sfx('thud', 120); api.buzz([30, 30, 30]); burst(p.lx, p.ly, '#ff8a70', 8, 20, 0.5, 0); }
        else if (kind === 'dup') addFloat(p.lx, p.ly + 5, '이미 배달한 집', '#cfc6d8', 1.0);
        else if (kind === 'roof') { addFloat(p.lx, p.ly + 5, '지붕에 올라갔어요', '#cfc6d8', 1.0); sfx('thud', 120); }
        else if (kind === 'back') addFloat(p.lx, p.ly + 5, '담장 너머로…', '#cfc6d8', 1.0);
        else { addFloat(p.lx, p.ly + 5, '길에 떨어졌어요', '#cfc6d8', 1.0); sfx('tick', 80); }
      },
      miss(r, lot, sd) { if (isMine(r.s)) { addFloat(sd ? 88 : 12, lot.y1 - 6, '놓쳤어요', '#ff9a86', 1.1); sfx('lose', 300); } },
      crash(r, o) {
        if (!isMine(r.s)) return;
        sfx('hit', 100); api.buzz([50, 40, 60]); shake = 1;
        const nm = { can: '쓰레기통', cone: '고깔', bar: '공사 칸막이', pit: '공사장', park: '세워 둔 차', car: '자동차', oncar: '마주 오는 차', cat: '고양이', sled: '썰매', walk: '사람', dog: '강아지', snow: '눈사람', stall: '노점' }[o.k] || '장애물';
        addFloat(r.x, r.y + 10, '꽈당! ' + nm, '#ff9a86', 1.3, true);
      },
      dog(r, o) { if (isMine(r.s)) sfx('bounce', 200); },
      pick(r, b, got) { if (isMine(r.s)) { sfx('card', 80); api.buzz(15); addFloat(b.x, b.y + 6, got ? '신문 +' + got : '가방이 가득해요', '#ffd76a', 1.1); burst(b.x, b.y, '#f6ecd6', 10, 26, 0.5, 1); } },
      empty(r) { if (isMine(r.s)) { sfx('thud', 300); addFloat(r.x, r.y + 12, '신문이 없어요! 묶음을 주워요', '#ff9a86', 1.2); } },
      end(r) { if (isMine(r.s)) { banner = { text: '시간 끝!', sub: r.sc + '점 · 배달 ' + r.del + '집', t: 3 }; sfx('pop', 100); } },
    };
    function observe() { // effects for riders seen remotely (or simulated here)
      W.r.forEach((r, s) => {
        const v = vis[s]; if (!v) return;
        if (r.cr !== v.cr) { if (v.cr < r.cr) burst(r.x, r.y, '#d9cbb8', 14, 30, 0.6, 0); v.cr = r.cr; }
      });
    }

    /* ----- host flow ----- */
    function hostFlow() {
      if (!host() || !st || !W) return;
      if (st.ph === 'count' && phase === 'race') { api.setState(Object.assign({}, st, { ph: 'race' })); return; }
      if (st.ph !== 'race' || doneSent || W.t < W.dur + GRACE) return;
      doneSent = true;
      const res = ranking(W.r).map((r) => [r.s, r.sc | 0, r.del | 0, Math.max(r.subs | 0, r.del | 0), r.acc | 0, r.cr | 0, r.bad | 0]);
      const extra = {};
      if (st.n === 1) {
        const sc = res[0][1];
        extra.bst = best != null ? best : 0;
        if (best == null || sc > best) { try { localStorage.setItem(bestKey(), String(sc)); } catch (e) {} }
      }
      api.setState(Object.assign({}, st, { ph: 'done', res }, extra));
    }

    /* ----- online ----- */
    const pack = (r) => [r1(r.x), r1(r.y), r.sc, r.del, r.subs, r.acc, r.cr, r.bad, r.cb, r.pp, (r.stun > 0 ? 1 : 0) | (r.inv > 0 ? 2 : 0) | (r.done ? 4 : 0), r.fq];
    function unpack(s, a, now) {
      const r = W.r[s]; if (!r || !Array.isArray(a) || !fin(a[0]) || !fin(a[1])) return;
      r.sc = a[2] | 0; r.del = a[3] | 0; r.subs = a[4] | 0; r.acc = a[5] | 0; r.cr = a[6] | 0; r.bad = a[7] | 0; r.cb = a[8] | 0; r.pp = a[9] | 0;
      const f = a[10] | 0; r.stun = f & 1 ? 0.5 : 0; r.inv = f & 2 ? 0.5 : 0; r.done = f & 4 ? 1 : 0; r.fq = a[11] | 0;
      const q = snaps[s] || (snaps[s] = []);
      q.push({ at: now, x: a[0], y: a[1] }); if (q.length > 6) q.shift();
    }
    function pollHost(now) {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.r.length) || simHere(s) || !o || o.k !== key || !Array.isArray(o.r) || o.q === remQ[s]) continue;
        remQ[s] = o.q; lastPack[s] = o.r; unpack(s, o.r, now);
      }
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.c)) return;
      lastQ = hs.q;
      if (fin(hs.t)) {
        const target = hs.t + 0.05;
        if (!gotClock || Math.abs(W.t - target) > 0.4) W.t = target; else W.t += (target - W.t) * 0.2;
        gotClock = hs.t > 0;
      }
      hs.c.forEach((a, s) => { if (!simHere(s)) unpack(s, a, now); });
    }
    function interpRemote(now) {
      const rt = now - 110;
      W.r.forEach((r, s) => {
        if (simHere(s)) return;
        const q = snaps[s]; if (!q || !q.length) return;
        let A = null, B = q[q.length - 1], k = 1;
        for (let i = q.length - 1; i > 0; i--) if (q[i - 1].at <= rt) { A = q[i - 1]; B = q[i]; break; }
        if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.2);
        if (A) { r.x = A.x + (B.x - A.x) * k; r.y = A.y + (B.y - A.y) * k; } else { r.x = B.x; r.y = B.y; }
      });
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt; if (pubT > 0) return;
      pubT = 1 / 12;
      try {
        if (api.isHost) { hsQ = (hsQ + 1) % 100000; api.net.hostSend({ k: key, q: hsQ, t: Math.round(W.t * 100) / 100, c: W.r.map((r, s) => (simHere(s) ? pack(r) : lastPack[s] || pack(r))) }); }
        else { const s = me(); if (s < 0) return; inQ = (inQ + 1) % 100000; api.net.publish({ k: key, q: inQ, r: pack(W.r[s]) }); }
      } catch (e) {}
    }

    /* ----- simulation ----- */
    function inputFor(s, r) {
      const p = api.players[s];
      if (p && p.ai) return aiThink(W, r, aiMem[s], p.lv || 2, W.t, H);
      if (isMine(s) && auto()) return aiThink(W, r, autoMem, 2, W.t, H);
      if (isMine(s)) { myInp.u = steerInput(r); myInp.th = thQ.length && r.cd <= 0 && r.stun <= 0 ? thQ.shift() : 0; myInp.k = -1; if (r.stun > 0) thQ.length = 0; return myInp; }
      return null;
    }
    function simStep() {
      W.t += H;
      for (const r of W.r) {
        const s = r.s;
        if (!simHere(s)) continue;
        if (!owned[s]) { owned[s] = true; if (W.t > 0.5) resync(W, r); }
        stepRider(W, r, W.t, H, inputFor(s, r), hooks);
      }
    }
    function guestStep() {
      W.t += H;
      const s = me(); if (s < 0) return;
      const r = W.r[s];
      stepRider(W, r, W.t, H, inputFor(s, r), hooks);
    }
    function frame(rdt, now) {
      if (!st || !W) return;
      const dt = rdt * SPD();
      if (phase === 'count') {
        const prevN = Math.ceil(cd); cd -= dt; const nowN = Math.ceil(cd);
        if (nowN !== prevN && nowN > 0 && nowN <= COUNT) api.sfx('tick');
        if (cd <= 0) { phase = 'race'; api.sfx('pop'); api.buzz(20); thQ = []; }
      }
      if (hintT > 0 && phase === 'race') hintT -= rdt;
      if (host()) {
        pollHost(now);
        if (phase === 'race' && st.ph !== 'done') {
          acc += Math.min(dt, 0.5); let n = 0;
          while (acc >= H && n < 90) { simStep(); acc -= H; n++; }
          if (n >= 90) acc = 0;
        }
        hostFlow();
      } else {
        pollGuest(now);
        if (phase === 'race' && st.ph !== 'done' && gotClock) {
          acc += Math.min(dt, 0.5); let n = 0;
          while (acc >= H && n < 90) { guestStep(); acc -= H; n++; }
          if (n >= 90) acc = 0;
        } else if (phase === 'count' || !gotClock) thQ = [];
      }
      if (api.online) interpRemote(now);
      observe();
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.92; p.vy *= 0.92;
        if (p.t <= 0) parts.splice(i, 1);
      }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      if (banner) { banner.t -= rdt; if (banner.t <= 0) banner = null; }
      shake = Math.max(0, shake - rdt * 3); scPop = Math.max(0, scPop - rdt * 3);
      publish(rdt);
    }
    function focus() {
      const s = me();
      if (s >= 0 && W.r[s]) return W.r[s];
      return ranking(W.r)[0];
    }

    /* ----- static street, cached in strips of 100 m ----- */
    function renderStrip(si) {
      const s = lay.s, dpr = cv.dpr, c = document.createElement('canvas');
      const pw = lay.w, ph = 100 * s;
      c.width = Math.max(1, Math.ceil(pw * dpr)); c.height = Math.max(1, Math.ceil(ph * dpr));
      const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const yT = (si + 1) * 100, yB = si * 100, th = T();
      const gx = (x) => lay.ox + x * s, gy = (y) => (yT - y) * s;
      const xL = -lay.ox / s - 1, xR = 100 + lay.ox / s + 1;
      // back gardens + lawns
      g.fillStyle = th.back; g.fillRect(0, 0, pw, ph);
      for (let sd = 0; sd < 2; sd++) {
        const mx = (x) => (sd ? 100 - x : x);
        const fR = (xa, xb, ya, yb) => { const a = gx(Math.min(mx(xa), mx(xb))), b = gx(Math.max(mx(xa), mx(xb))); g.fillRect(a, gy(yb), b - a, (yb - ya) * s); };
        for (const lot of W.lots[sd]) {
          if (lot.y1 < yB - 2 || lot.y0 > yT + 2) continue;
          g.fillStyle = lot.i % 2 ? th.lawn : th.lawn2; fR(0, CURB, lot.y0, lot.y1);
          // mowing stripes
          g.fillStyle = 'rgba(255,255,255,.035)';
          for (let yy = lot.y0 + 2; yy < lot.y1; yy += 6) fR(0, CURB, yy, yy + 3);
        }
      }
      // trees in the back
      for (let k = Math.floor(yB / 9) - 1; k <= Math.ceil(yT / 9) + 1; k++) {
        for (let sd = 0; sd < 2; sd++) {
          const hv = hash32(k * 2 + sd, 77);
          const tx = sd ? 100 + 2 + (hv % 100) / 100 * Math.max(2, xR - 104) : -2 - (hv % 100) / 100 * Math.max(2, -xL - 4), ty = k * 9 + ((hv >>> 8) % 9);
          if (tx < xL - 6 || tx > xR + 6) continue;
          const rr = (2.6 + ((hv >>> 12) % 30) / 10) * s;
          g.fillStyle = 'rgba(0,0,0,.22)'; g.beginPath(); g.arc(gx(tx) + rr * 0.25, gy(ty) + rr * 0.3, rr, 0, 6.3); g.fill();
          g.fillStyle = W.M.th === 'snow' ? '#dfe7ee' : th.hedge; g.beginPath(); g.arc(gx(tx), gy(ty), rr, 0, 6.3); g.fill();
          g.fillStyle = W.M.th === 'snow' ? '#f6f8fb' : 'rgba(255,255,255,.08)'; g.beginPath(); g.arc(gx(tx) - rr * 0.3, gy(ty) - rr * 0.3, rr * 0.5, 0, 6.3); g.fill();
        }
      }
      // sidewalks + road
      g.fillStyle = th.walk; g.fillRect(gx(CURB), 0, (ROAD0 - CURB) * s, ph); g.fillRect(gx(ROAD1), 0, (100 - CURB - ROAD1) * s, ph);
      g.strokeStyle = th.walk2; g.lineWidth = 1;
      g.beginPath();
      for (let yy = Math.ceil(yB / 6) * 6; yy <= yT; yy += 6) { g.moveTo(gx(CURB), gy(yy)); g.lineTo(gx(ROAD0), gy(yy)); g.moveTo(gx(ROAD1), gy(yy)); g.lineTo(gx(100 - CURB), gy(yy)); }
      g.moveTo(gx(27), 0); g.lineTo(gx(27), ph); g.moveTo(gx(73), 0); g.lineTo(gx(73), ph);
      g.stroke();
      const rg = g.createLinearGradient(gx(ROAD0), 0, gx(ROAD1), 0); rg.addColorStop(0, th.road); rg.addColorStop(0.5, th.road2); rg.addColorStop(1, th.road);
      g.fillStyle = rg; g.fillRect(gx(ROAD0), 0, (ROAD1 - ROAD0) * s, ph);
      for (let i = 0; i < 90; i++) { const hv = hash32(si, i + 5); g.fillStyle = (hv & 1) ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.08)'; g.fillRect(gx(ROAD0 + (hv % 400) / 10), ((hv >>> 9) % 1000) / 1000 * ph, 1.5, 1.5); }
      // curbs
      g.fillStyle = 'rgba(242,233,216,.55)'; g.fillRect(gx(ROAD0) - 1.5, 0, 2, ph); g.fillRect(gx(ROAD1) - 0.5, 0, 2, ph);
      g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(gx(ROAD0) + 0.5, 0, 2, ph); g.fillRect(gx(ROAD1) - 2.5, 0, 2, ph);
      // centre line (the "mailbox lane")
      g.fillStyle = th.mid;
      if (W.M.id === 'traffic') { g.fillRect(gx(MID) - 2.6, 0, 1.6, ph); g.fillRect(gx(MID) + 1, 0, 1.6, ph); }
      else for (let yy = Math.floor(yB / 10) * 10; yy < yT + 10; yy += 10) g.fillRect(gx(MID) - 1, gy(yy + 5), 2, 5 * s);
      if (W.M.id === 'work') for (let k = Math.floor(yB / 37); k <= yT / 37; k++) { const hv = hash32(k, 31); if (hv % 3) continue; g.fillStyle = 'rgba(20,16,26,.45)'; const px = 34 + (hv >>> 4) % 30, py = k * 37; g.fillRect(gx(px), gy(py + 6), 7 * s, 6 * s); g.strokeStyle = 'rgba(160,150,170,.35)'; g.strokeRect(gx(px), gy(py + 6), 7 * s, 6 * s); }
      if (W.M.hill) for (let yy = Math.floor(yB / 40) * 40; yy < yT + 40; yy += 40) {
        const k = hillAt(W, yy); if (Math.abs(k) < 0.12) continue;
        const cx = gx(MID), cy = gy(yy);
        g.fillStyle = k > 0 ? 'rgba(127,224,170,.55)' : 'rgba(238,150,110,.55)';
        g.font = '700 ' + Math.round(clamp(3.4 * s, 10, 14)) + 'px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(k > 0 ? '내리막 ▲▲' : '오르막 ▬', cx + 10 * s, cy);
      }
      // puddles
      for (const p of W.pud) {
        if (p.y + p.ry < yB - 1 || p.y - p.ry > yT + 1) continue;
        g.fillStyle = 'rgba(90,140,200,.55)'; g.beginPath(); g.ellipse(gx(p.x), gy(p.y), p.rx * s, p.ry * s, 0, 0, 6.3); g.fill();
        g.strokeStyle = 'rgba(200,225,255,.6)'; g.lineWidth = 1.5; g.beginPath(); g.ellipse(gx(p.x) - p.rx * s * 0.25, gy(p.y) - p.ry * s * 0.3, p.rx * s * 0.4, p.ry * s * 0.25, 0, 3.6, 5.6); g.stroke();
      }
      // houses
      for (let sd = 0; sd < 2; sd++) for (const lot of W.lots[sd]) { if (lot.y1 < yB - 2 || lot.y0 > yT + 2) continue; drawLot(g, lot, sd, gx, gy, s, th); }
      // static obstacles
      for (const o of W.st) {
        const ext = o.r != null ? o.r + 2 : o.hh + 2;
        if (o.y + ext < yB - 1 || o.y - ext > yT + 1) continue;
        drawStatic(g, o, gx, gy, s);
      }
      return c;
    }
    function drawLot(g, lot, sd, gx, gy, s, th) {
      const mx = (x) => (sd ? 100 - x : x);
      const box = (xa, xb, ya, yb) => { const a = gx(Math.min(mx(xa), mx(xb))), b = gx(Math.max(mx(xa), mx(xb))); return [a, gy(yb), b - a, (yb - ya) * s]; };
      const fR = (xa, xb, ya, yb) => { const q = box(xa, xb, ya, yb); g.fillRect(q[0], q[1], q[2], q[3]); };
      const snow = W.M.th === 'snow';
      // hedge between lots + front fence with a gate
      g.fillStyle = th.hedge; fR(0, CURB - 0.6, lot.y0 - 0.7, lot.y0 + 0.7);
      g.fillStyle = 'rgba(242,233,216,.55)';
      for (let yy = lot.y0 + 1; yy < lot.y1 - 1; yy += 2.2) { if (Math.abs(yy - lot.dy) < 2.6) continue; fR(CURB - 0.9, CURB - 0.3, yy, yy + 1.2); }
      // path from the door to the sidewalk
      g.fillStyle = snow ? '#c9cfd8' : '#b9a891'; fR(HOUSE_X1, CURB, lot.dy - 1.6, lot.dy + 1.6);
      // house (shadow, walls, gable roof)
      const y0 = lot.y0 + 4, y1 = lot.y1 - 4;
      g.fillStyle = 'rgba(0,0,0,.28)'; { const q = box(1, HOUSE_X1, y0, y1); g.fillRect(q[0] + 3, q[1] + 4, q[2], q[3]); }
      const col = lot.sub ? ROOF[lot.c] : '#6d6576';
      g.fillStyle = shade(col, lot.sub ? 0.12 : 0.05); fR(1, 7, y0, y1);
      g.fillStyle = shade(col, -0.18); fR(7, HOUSE_X1, y0, y1);
      g.strokeStyle = 'rgba(0,0,0,.15)'; g.lineWidth = 1; g.beginPath();
      for (let yy = y0 + 2; yy < y1; yy += 2.2) { const a = gx(mx(1)), b = gx(mx(HOUSE_X1)); g.moveTo(a, gy(yy)); g.lineTo(b, gy(yy)); }
      g.stroke();
      g.fillStyle = shade(col, 0.35); fR(6.6, 7.4, y0, y1);
      if (snow) { g.fillStyle = 'rgba(246,248,251,.82)'; fR(1.4, 6.6, y0 + 0.8, y1 - 0.8); g.fillStyle = 'rgba(232,238,245,.7)'; fR(7.4, HOUSE_X1 - 0.6, y0 + 0.8, y1 - 0.8); }
      g.fillStyle = shade(col, -0.4); fR(2.6, 4.8, y1 - 7, y1 - 4.6);
      // porch step + doormat (the "현관" target)
      g.fillStyle = '#d8ccb6'; fR(HOUSE_X1, HOUSE_X1 + 1.3, lot.dy - 3.6, lot.dy + 3.6);
      g.fillStyle = lot.sub ? '#b5492f' : '#5e5666'; fR(HOUSE_X1 + 1.5, DOOR_X1 - 0.6, lot.dy - 3.6, lot.dy + 3.6);
      g.strokeStyle = lot.sub ? '#f0c565' : '#857c8e'; g.lineWidth = 1.2; { const q = box(HOUSE_X1 + 1.9, DOOR_X1 - 1, lot.dy - 3.1, lot.dy + 3.1); g.strokeRect(q[0], q[1], q[2], q[3]); }
      // mailbox on a post
      const mbx = gx(mx(MBX)), mby = gy(lot.my);
      g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(mbx - 1.4 * s + 2, mby - 2 * s + 3, 2.8 * s, 4 * s);
      g.fillStyle = lot.sub ? '#d0503c' : '#7d7488'; rrect(g, mbx - 1.4 * s, mby - 2 * s, 2.8 * s, 4 * s, 0.8 * s); g.fill();
      g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(mbx - 1.4 * s, mby - 2 * s, 2.8 * s, 0.8 * s);
      g.fillStyle = '#17131f'; g.fillRect(mbx - 0.9 * s, mby - 1.2 * s, 1.8 * s, 0.5 * s);
      if (lot.sub) { // flag up
        const fx = gx(mx(MBX + (sd ? -1.6 : 1.6)));
        g.fillStyle = '#e3ae45'; g.fillRect(Math.min(fx, fx + (sd ? -0.6 : 0.6) * s), mby - 2.8 * s, 0.6 * s, 2.6 * s);
        g.fillRect(Math.min(fx, fx + (sd ? -1.8 : 1.8) * s), mby - 2.8 * s, 1.8 * s, 1 * s);
      }
      // roof badge: newspaper (subscriber) / "신문 사절" (red slashed circle)
      const bx = gx(mx(7)), by = gy((y0 + y1) / 2), br = 2.9 * s;
      g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.arc(bx + 1.5, by + 2, br, 0, 6.3); g.fill();
      if (lot.sub) {
        g.fillStyle = '#f6ecd6'; g.beginPath(); g.arc(bx, by, br, 0, 6.3); g.fill();
        g.strokeStyle = '#e3ae45'; g.lineWidth = Math.max(1.5, 0.45 * s); g.stroke();
        g.fillStyle = '#3a3346'; g.fillRect(bx - br * 0.5, by - br * 0.45, br * 1.0, br * 0.22);
        g.fillStyle = '#8b8296'; for (let k = 0; k < 3; k++) g.fillRect(bx - br * 0.5, by - br * 0.1 + k * br * 0.2, br * (k === 2 ? 0.6 : 1.0), br * 0.1);
      } else {
        g.fillStyle = '#efe6d6'; g.beginPath(); g.arc(bx, by, br, 0, 6.3); g.fill();
        g.strokeStyle = '#d2412e'; g.lineWidth = Math.max(2, 0.6 * s); g.beginPath(); g.arc(bx, by, br * 0.78, 0, 6.3); g.stroke();
        g.beginPath(); g.moveTo(bx - br * 0.55, by - br * 0.55); g.lineTo(bx + br * 0.55, by + br * 0.55); g.stroke();
      }
    }
    function drawCar(g, x, y, s, col, dir, hw, hh) {
      g.save(); g.translate(x, y); if (dir < 0) g.rotate(Math.PI);
      const w = hw * 2 * s, h = hh * 2 * s;
      g.fillStyle = 'rgba(0,0,0,.3)'; rrect(g, -w / 2 + 2, -h / 2 + 3, w, h, w * 0.3); g.fill();
      g.fillStyle = col; rrect(g, -w / 2, -h / 2, w, h, w * 0.3); g.fill();
      g.fillStyle = 'rgba(23,19,31,.75)'; rrect(g, -w * 0.38, -h * 0.28, w * 0.76, h * 0.16, w * 0.1); g.fill();
      rrect(g, -w * 0.36, h * 0.2, w * 0.72, h * 0.12, w * 0.1); g.fill();
      g.fillStyle = shade(col, -0.15); rrect(g, -w * 0.36, -h * 0.1, w * 0.72, h * 0.28, w * 0.1); g.fill();
      g.fillStyle = '#fff3c4'; g.fillRect(-w * 0.42, -h / 2, w * 0.18, h * 0.05); g.fillRect(w * 0.24, -h / 2, w * 0.18, h * 0.05);
      g.fillStyle = '#d2412e'; g.fillRect(-w * 0.42, h / 2 - h * 0.04, w * 0.16, h * 0.04); g.fillRect(w * 0.26, h / 2 - h * 0.04, w * 0.16, h * 0.04);
      g.restore();
    }
    function drawStatic(g, o, gx, gy, s) {
      const x = gx(o.x), y = gy(o.y);
      if (o.k === 'can') {
        const r = o.r * s;
        g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.arc(x + 2, y + 3, r, 0, 6.3); g.fill();
        g.fillStyle = '#5d7a6a'; g.beginPath(); g.arc(x, y, r, 0, 6.3); g.fill();
        g.strokeStyle = '#8fb09c'; g.lineWidth = Math.max(1.5, 0.4 * s); g.beginPath(); g.arc(x, y, r * 0.78, 0, 6.3); g.stroke();
        g.fillStyle = '#3d5446'; g.fillRect(x - r * 0.35, y - r * 0.1, r * 0.7, r * 0.2);
      } else if (o.k === 'cone') {
        const r = o.r * s;
        g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(x - r * 1.1 + 2, y - r * 1.1 + 3, r * 2.2, r * 2.2);
        g.fillStyle = '#2b2533'; g.fillRect(x - r * 1.1, y - r * 1.1, r * 2.2, r * 2.2);
        g.fillStyle = '#ff8a3c'; g.beginPath(); g.arc(x, y, r, 0, 6.3); g.fill();
        g.strokeStyle = '#f6ecd6'; g.lineWidth = Math.max(1.5, 0.35 * s); g.beginPath(); g.arc(x, y, r * 0.55, 0, 6.3); g.stroke();
      } else if (o.k === 'bar' || o.k === 'pit') {
        const a = gx(o.x - o.hw), b = gx(o.x + o.hw), t = gy(o.y + o.hh), bt = gy(o.y - o.hh);
        g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(a + 2, t + 3, b - a, bt - t);
        if (o.k === 'pit') { g.fillStyle = '#6b5440'; g.fillRect(a, t, b - a, bt - t); g.fillStyle = 'rgba(0,0,0,.25)'; for (let k = 0; k < 6; k++) { const hv = hash32(Math.round(o.y), k); g.beginPath(); g.arc(a + (hv % 100) / 100 * (b - a), t + ((hv >>> 8) % 100) / 100 * (bt - t), 2 + (hv >>> 16) % 4, 0, 6.3); g.fill(); } }
        g.save(); g.beginPath(); if (o.k === 'pit') { g.rect(a, t, b - a, 1.6 * s); g.rect(a, bt - 1.6 * s, b - a, 1.6 * s); g.rect(a, t, 1.6 * s, bt - t); g.rect(b - 1.6 * s, t, 1.6 * s, bt - t); } else g.rect(a, t, b - a, bt - t);
        g.clip(); g.fillStyle = '#f6ecd6'; g.fillRect(a, t, b - a, bt - t);
        g.fillStyle = '#ff7a2c'; const st2 = 3 * s; for (let xx = a - (bt - t) - st2 * 2; xx < b + st2; xx += st2 * 2) { g.beginPath(); g.moveTo(xx, bt); g.lineTo(xx + st2, bt); g.lineTo(xx + st2 + (bt - t), t); g.lineTo(xx + (bt - t), t); g.closePath(); g.fill(); }
        g.restore();
        g.fillStyle = '#ffd76a'; g.beginPath(); g.arc(a + 2, t + 2, 2, 0, 6.3); g.arc(b - 2, t + 2, 2, 0, 6.3); g.fill();
      } else if (o.k === 'park') {
        drawCar(g, x, y, s, CARC[o.c], o.d, o.hw, o.hh);
      } else if (o.k === 'snow') {
        const r = o.r * s;
        g.fillStyle = 'rgba(40,60,90,.25)'; g.beginPath(); g.arc(x + 2, y + 3, r, 0, 6.3); g.fill();
        g.fillStyle = '#f8fbff'; g.beginPath(); g.arc(x, y, r, 0, 6.3); g.fill();
        g.strokeStyle = '#c3cfdd'; g.lineWidth = 1.2; g.stroke();
        g.fillStyle = '#eef3f9'; g.beginPath(); g.arc(x, y - r * 0.15, r * 0.62, 0, 6.3); g.fill();
        g.fillStyle = '#2b2533'; g.beginPath(); g.arc(x, y - r * 0.2, r * 0.36, 0, 6.3); g.fill();
        g.fillStyle = '#ff8a3c'; g.beginPath(); g.moveTo(x - r * 0.12, y - r * 0.55); g.lineTo(x + r * 0.12, y - r * 0.55); g.lineTo(x, y - r * 1.0); g.closePath(); g.fill();
      } else if (o.k === 'stall') {
        const a = gx(o.x - o.hw), b = gx(o.x + o.hw), t = gy(o.y + o.hh), bt = gy(o.y - o.hh);
        g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(a + 2, t + 3, b - a, bt - t);
        const c1 = ['#d0503c', '#2f8a86', '#c9902f', '#3f68a8', '#7a4a8a'][o.c];
        for (let k = 0, n = Math.max(2, Math.round((bt - t) / (2.4 * s))); k < n; k++) { g.fillStyle = k % 2 ? '#f6ecd6' : c1; g.fillRect(a, t + (bt - t) * k / n, b - a, (bt - t) / n + 0.5); }
        g.strokeStyle = 'rgba(23,19,31,.5)'; g.lineWidth = 1; g.strokeRect(a, t, b - a, bt - t);
        g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(a, t, (b - a) * 0.4, bt - t);
      }
    }
    function drawStrips() {
      const s = lay.s, vT = camY + lay.bikeY / s, vB = camY - (lay.h - lay.bikeY) / s;
      const i0 = Math.floor(vB / 100), i1 = Math.floor(vT / 100);
      for (let i = i0; i <= i1; i++) {
        let c = strips.get(i);
        if (!c) { c = renderStrip(i); strips.set(i, c); }
        const y0 = Math.round(Y((i + 1) * 100)), y1 = Math.round(Y(i * 100));
        ctx.drawImage(c, 0, y0, lay.w, y1 - y0);
      }
      if (strips.size > 6) for (const k of strips.keys()) if (k < i0 - 1 || k > i1 + 1) strips.delete(k);
    }

    /* ----- dynamic things ----- */
    const PT = [0, 0, 0];
    function visY(y, m) { const s = lay.s; return y > camY - (lay.h - lay.bikeY) / s - m && y < camY + lay.bikeY / s + m; }
    function drawDog(o, r, now) {
      const p = dogPos(o, r ? r.dg[o.i] : null, W.t, PT);
      if (!visY(p[1], 10)) return;
      const s = lay.s, x = X(p[0]), y = Y(p[1]), run = p[2] === 1 || p[2] === 3, dir = p[2] === 3 ? -o.dir : o.dir;
      const col = DOGC[o.c];
      ctx.save(); ctx.translate(x, y); if (dir < 0) ctx.scale(-1, 1);
      const legs = run ? Math.sin(now / 45) : 0;
      ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(1.5, 2.5, 2.6 * s, 1.4 * s, 0, 0, 6.3); ctx.fill();
      ctx.fillStyle = shade(col, -0.35);
      for (const k of [-1, 1]) { ctx.fillRect(-1.6 * s + legs * 0.4 * s * k, k * 1.1 * s - 0.3 * s, 0.6 * s, 0.6 * s); ctx.fillRect(1.0 * s - legs * 0.4 * s * k, k * 1.1 * s - 0.3 * s, 0.6 * s, 0.6 * s); }
      ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, 0, 2.3 * s, 1.15 * s, 0, 0, 6.3); ctx.fill();
      ctx.beginPath(); ctx.arc(2.3 * s, 0, 0.95 * s, 0, 6.3); ctx.fill();
      ctx.fillStyle = shade(col, -0.3); ctx.beginPath(); ctx.ellipse(2.1 * s, -0.8 * s, 0.4 * s, 0.6 * s, 0.4, 0, 6.3); ctx.ellipse(2.1 * s, 0.8 * s, 0.4 * s, 0.6 * s, -0.4, 0, 6.3); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 0.5 * s; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(-2.2 * s, 0); ctx.lineTo(-3.2 * s, Math.sin(now / 70) * 0.8 * s); ctx.stroke(); ctx.lineCap = 'butt';
      ctx.restore();
      if (p[2] === 2 && Math.sin(now / 120) > -0.2) txtO('멍!', x, y - 3.4 * s, '#f6ecd6', '700 11px ' + FONT);
    }
    function drawMover(o, now) {
      const p = mvPos(o, W.t, PT);
      if (!visY(p[1], 12)) return;
      const s = lay.s, x = X(p[0]), y = Y(p[1]);
      if (o.k === 'car' || o.k === 'oncar') {
        if (o.k === 'oncar') { const g2 = ctx.createRadialGradient(x, y + o.hh * s, 2, x, y + (o.hh + 8) * s, 12 * s); g2.addColorStop(0, 'rgba(255,240,180,.35)'); g2.addColorStop(1, 'rgba(255,240,180,0)'); ctx.fillStyle = g2; ctx.fillRect(x - 12 * s, y + o.hh * s, 24 * s, 18 * s); }
        drawCar(ctx, x, y, s, CARC[o.c], o.k === 'oncar' ? -1 : 1, o.hw, o.hh);
        return;
      }
      const moving = W.t >= o.t0 && p[0] > 20.2 && p[0] < 79.8, sw = moving ? Math.sin(now / (o.k === 'walk' ? 140 : 60)) : 0;
      ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.arc(x + 1.5, y + 2.5, o.r * s, 0, 6.3); ctx.fill();
      if (o.k === 'cat') {
        ctx.save(); ctx.translate(x, y); if (o.vx < 0) ctx.scale(-1, 1);
        ctx.fillStyle = ['#3a3030', '#d98a3c', '#8d8396', '#efe6d6', '#3a3030', '#d98a3c'][o.c];
        ctx.beginPath(); ctx.ellipse(0, 0, 1.8 * s, 0.9 * s, 0, 0, 6.3); ctx.fill(); ctx.beginPath(); ctx.arc(1.8 * s, 0, 0.8 * s, 0, 6.3); ctx.fill();
        ctx.beginPath(); ctx.moveTo(2.0 * s, -0.6 * s); ctx.lineTo(2.6 * s, -1.1 * s); ctx.lineTo(2.4 * s, -0.3 * s); ctx.fill();
        ctx.strokeStyle = ctx.fillStyle; ctx.lineWidth = 0.4 * s; ctx.beginPath(); ctx.moveTo(-1.7 * s, 0); ctx.quadraticCurveTo(-2.8 * s, sw * 1.2 * s, -3 * s, -0.8 * s); ctx.stroke();
        ctx.restore();
      } else if (o.k === 'sled') {
        ctx.save(); ctx.translate(x, y); if (o.vx < 0) ctx.scale(-1, 1);
        ctx.fillStyle = '#d0503c'; rrect(ctx, -2.6 * s, -1.6 * s, 5.2 * s, 3.2 * s, 0.8 * s); ctx.fill();
        ctx.strokeStyle = '#3a3346'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-2.8 * s, -1.8 * s); ctx.lineTo(3.2 * s, -1.8 * s); ctx.moveTo(-2.8 * s, 1.8 * s); ctx.lineTo(3.2 * s, 1.8 * s); ctx.stroke();
        ctx.fillStyle = PPLC[o.c]; ctx.beginPath(); ctx.arc(0, 0, 1.3 * s, 0, 6.3); ctx.fill();
        ctx.fillStyle = '#f2d3b0'; ctx.beginPath(); ctx.arc(0.4 * s, 0, 0.75 * s, 0, 6.3); ctx.fill();
        ctx.restore();
      } else {
        const c = PPLC[o.c];
        ctx.fillStyle = shade(c, -0.3); ctx.beginPath(); ctx.arc(x + sw * 0.6 * s, y - 0.9 * s, 0.5 * s, 0, 6.3); ctx.arc(x - sw * 0.6 * s, y + 0.9 * s, 0.5 * s, 0, 6.3); ctx.fill();
        ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(x, y, 1.35 * s, 2.3 * s, 0, 0, 6.3); ctx.fill();
        ctx.fillStyle = '#3a2a22'; ctx.beginPath(); ctx.arc(x, y, 1.05 * s, 0, 6.3); ctx.fill();
      }
    }
    function drawBundles(r, now) {
      const s = lay.s;
      for (const b of W.bun) {
        if (!visY(b.y, 8) || (r && r.bg.has(b.i))) continue;
        const x = X(b.x), y = Y(b.y), pul = 0.5 + 0.5 * Math.sin(now / 200);
        ctx.strokeStyle = 'rgba(255,215,106,' + (0.35 + 0.4 * pul) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, (3.6 + pul * 0.6) * s, 0, 6.3); ctx.stroke();
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fillRect(x - 2.4 * s + 2, y - 1.8 * s + 3, 4.8 * s, 3.6 * s);
        ctx.fillStyle = '#e9dfcb'; ctx.fillRect(x - 2.4 * s, y - 1.8 * s, 4.8 * s, 3.6 * s);
        ctx.fillStyle = '#b8ab95'; for (let k = 0; k < 3; k++) ctx.fillRect(x - 2.4 * s, y - 1.8 * s + k * 1.2 * s, 4.8 * s, 0.25 * s);
        ctx.strokeStyle = '#c0503a'; ctx.lineWidth = Math.max(1.2, 0.35 * s); ctx.beginPath(); ctx.moveTo(x, y - 1.8 * s); ctx.lineTo(x, y + 1.8 * s); ctx.moveTo(x - 2.4 * s, y); ctx.lineTo(x + 2.4 * s, y); ctx.stroke();
      }
    }
    function drawHouseState(r, now) { // my deliveries: a check on the roof badge; next subscribers: a soft pulse
      if (!r) return;
      const s = lay.s, pul = 0.5 + 0.5 * Math.sin(now / 180);
      for (let sd = 0; sd < 2; sd++) {
        const A = W.lots[sd];
        for (let i = Math.max(0, r.pi[sd] - 4); i < A.length; i++) {
          const lot = A[i]; if (lot.y0 > camY + lay.bikeY / s + 4) break;
          if (!lot.sub || lot.y1 < camY - (lay.h - lay.bikeY) / s) continue;
          const bx = X(sd ? 93 : 7), by = Y((lot.y0 + lot.y1) / 2), br = 2.9 * s;
          if (r.dl.has(sd * 1000 + lot.i)) {
            ctx.fillStyle = '#3fae6a'; ctx.beginPath(); ctx.arc(bx, by, br, 0, 6.3); ctx.fill();
            ctx.strokeStyle = '#f6ecd6'; ctx.lineWidth = Math.max(2, 0.55 * s); ctx.beginPath(); ctx.moveTo(bx - br * 0.45, by); ctx.lineTo(bx - br * 0.1, by + br * 0.38); ctx.lineTo(bx + br * 0.5, by - br * 0.4); ctx.stroke();
          } else if (lot.y1 > r.y) {
            ctx.strokeStyle = 'rgba(255,215,106,' + (0.25 + 0.45 * pul) + ')'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(X(sd ? 100 - MBX : MBX), Y(lot.my), (3.4 + pul) * s, 0, 6.3); ctx.stroke();
          }
        }
      }
    }
    function drawMarks() {
      const s = lay.s;
      for (const m of marks) {
        if (!visY(m.y, 6)) continue;
        const x = X(m.x), y = Y(m.y);
        ctx.save(); ctx.translate(x, y); ctx.rotate(m.a);
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(-1.6 * s + 1, -0.7 * s + 2, 3.2 * s, 1.4 * s);
        ctx.fillStyle = '#ece3d0'; rrect(ctx, -1.6 * s, -0.7 * s, 3.2 * s, 1.4 * s, 0.6 * s); ctx.fill();
        ctx.fillStyle = '#c0503a'; ctx.fillRect(-0.2 * s, -0.7 * s, 0.4 * s, 1.4 * s);
        ctx.restore();
      }
    }
    const ZC = { mb: '#ffd76a', door: '#f6ecd6', lawn: '#8fe0a0', bad: '#ff8a70', roof: '#a99fb6', back: '#a99fb6', street: '#a99fb6', dup: '#a99fb6' };
    function drawAim(r, now) {
      if (!r || phase !== 'race' || r.done || r.stun > 0 || r.pp <= 0) return;
      const s = lay.s;
      for (const side of [-1, 1]) {
        landPoint(W, r, side, W.t, LP);
        const sd = side < 0 ? 0 : 1, z = zoneAt(W, sd, LP[0], LP[1]);
        let k = z.z; if (z.lot && !z.lot.sub) k = 'bad'; else if (z.lot && r.dl.has(sd * 1000 + z.lot.i) && (k === 'mb' || k === 'door' || k === 'lawn')) k = 'dup';
        const good = k === 'mb' || k === 'door' || k === 'lawn';
        const x = X(LP[0]), y = Y(LP[1]), rr = (good ? 2.6 : 2.1) * s;
        ctx.strokeStyle = hexA(ZC[k], good ? 0.95 : 0.55); ctx.lineWidth = good ? 2.4 : 1.6;
        ctx.setLineDash(good ? [] : [3, 3]);
        ctx.beginPath(); ctx.arc(x, y, rr, 0, 6.3); ctx.stroke(); ctx.setLineDash([]);
        ctx.beginPath(); ctx.moveTo(x - rr * 0.5, y); ctx.lineTo(x + rr * 0.5, y); ctx.moveTo(x, y - rr * 0.5); ctx.lineTo(x, y + rr * 0.5); ctx.stroke();
        if (k === 'mb' || k === 'door') { ctx.fillStyle = hexA(ZC[k], 0.22 + 0.15 * Math.sin(now / 90)); ctx.beginPath(); ctx.arc(x, y, rr, 0, 6.3); ctx.fill(); }
        if (k === 'bad') { ctx.strokeStyle = 'rgba(255,138,112,.9)'; ctx.beginPath(); ctx.moveTo(x - rr * 0.7, y - rr * 0.7); ctx.lineTo(x + rr * 0.7, y + rr * 0.7); ctx.stroke(); }
      }
    }
    function drawPapers(r, now) {
      if (!r) return;
      const s = lay.s;
      for (const p of r.fl) {
        const u = clamp((W.t - p.t0) / T_FLY, 0, 1), x = p.sx + (p.lx - p.sx) * u, y = p.sy + (p.ly - p.sy) * u, hgt = 4 * u * (1 - u) * HMAX;
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(X(x), Y(y), 1.6 * s, 0.8 * s, 0, 0, 6.3); ctx.fill();
        const sc = 1 + hgt / 14;
        ctx.save(); ctx.translate(X(x), Y(y + hgt * 0.5) - hgt * s * 0.35); ctx.rotate(p.side * u * 9); ctx.scale(sc, sc);
        ctx.fillStyle = '#f2e9d8'; rrect(ctx, -1.7 * s, -0.75 * s, 3.4 * s, 1.5 * s, 0.7 * s); ctx.fill();
        ctx.strokeStyle = 'rgba(23,19,31,.5)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = '#c0503a'; ctx.fillRect(-0.2 * s, -0.75 * s, 0.4 * s, 1.5 * s);
        ctx.restore();
      }
    }
    function drawBike(r, alpha, now, mine) {
      if (!visY(r.y, 10)) return;
      const s = lay.s, col = P(r.s).color || '#e3ae45', x = X(r.x), y = Y(r.y);
      const blink = r.inv > 0 && r.stun <= 0 && Math.floor(now / 90) % 2 === 0;
      ctx.save(); ctx.globalAlpha = alpha * (blink ? 0.45 : 1);
      ctx.translate(x, y);
      const fallen = r.stun > 0;
      ctx.rotate(fallen ? 1.35 * (r.vx >= 0 ? 1 : -1) : clamp(r.vx / VX, -1, 1) * 0.28);
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(2, 3, 2.6 * s, 4.6 * s, 0, 0, 6.3); ctx.fill();
      // wheels + frame
      ctx.fillStyle = '#1f1a28'; rrect(ctx, -0.6 * s, -4.4 * s, 1.2 * s, 2.8 * s, 0.6 * s); ctx.fill(); rrect(ctx, -0.6 * s, 1.6 * s, 1.2 * s, 2.8 * s, 0.6 * s); ctx.fill();
      ctx.strokeStyle = shade(col, -0.35); ctx.lineWidth = Math.max(1.5, 0.5 * s); ctx.beginPath(); ctx.moveTo(0, 2.6 * s); ctx.lineTo(0, -2.8 * s); ctx.stroke();
      // handlebar
      ctx.strokeStyle = '#b9b0c4'; ctx.lineWidth = Math.max(1.5, 0.45 * s); ctx.beginPath(); ctx.moveTo(-2.2 * s, 2.4 * s); ctx.lineTo(2.2 * s, 2.4 * s); ctx.stroke();
      // paper bag on the back (fuller = more papers)
      ctx.fillStyle = '#c9a46a'; rrect(ctx, -1.9 * s, -3.4 * s, 3.8 * s, 2.0 * s, 0.5 * s); ctx.fill();
      const nP = Math.min(4, Math.ceil(r.pp / 5)); ctx.fillStyle = '#f2e9d8'; for (let k = 0; k < nP; k++) ctx.fillRect(-1.6 * s + k * 0.85 * s, -3.2 * s, 0.6 * s, 1.6 * s);
      // rider: arms, body, head with a cap
      ctx.strokeStyle = shade(col, -0.2); ctx.lineWidth = Math.max(1.5, 0.6 * s); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-1.5 * s, 0.6 * s); ctx.lineTo(-2.0 * s, 2.3 * s); ctx.moveTo(1.5 * s, 0.6 * s); ctx.lineTo(2.0 * s, 2.3 * s); ctx.stroke(); ctx.lineCap = 'butt';
      const g2 = ctx.createLinearGradient(-2 * s, 0, 2 * s, 0); g2.addColorStop(0, shade(col, 0.2)); g2.addColorStop(1, shade(col, -0.2));
      ctx.fillStyle = g2; ctx.beginPath(); ctx.ellipse(0, 0, 2.0 * s, 1.5 * s, 0, 0, 6.3); ctx.fill();
      ctx.strokeStyle = mine ? '#f2e9d8' : 'rgba(23,19,31,.7)'; ctx.lineWidth = mine ? 1.6 : 1; ctx.stroke();
      ctx.fillStyle = '#f2d3b0'; ctx.beginPath(); ctx.arc(0, 0.4 * s, 1.1 * s, 0, 6.3); ctx.fill();
      ctx.fillStyle = shade(col, -0.35); ctx.beginPath(); ctx.arc(0, 0.25 * s, 1.05 * s, Math.PI * 1.05, Math.PI * 1.95 + 6.283, false); ctx.fill();
      ctx.beginPath(); ctx.ellipse(0, 1.3 * s, 0.9 * s, 0.45 * s, 0, 0, 6.3); ctx.fill();
      ctx.restore();
      if (fallen) for (let k = 0; k < 3; k++) { const a = now / 200 + k * 2.09; txtO('★', x + Math.cos(a) * 3 * s, y - 2 * s + Math.sin(a) * 1.4 * s, '#ffd76a', '10px ' + FONT); }
      if (mine) { ctx.fillStyle = 'rgba(242,233,216,.9)'; ctx.beginPath(); ctx.moveTo(x, y + 6.2 * s); ctx.lineTo(x - 1.4 * s, y + 8 * s); ctx.lineTo(x + 1.4 * s, y + 8 * s); ctx.closePath(); ctx.fill(); }
    }
    const tagBox = [];
    function drawTag(r, alpha) {
      if (!visY(r.y, 10)) return;
      const x = X(r.x), y = Y(r.y) - 6.5 * lay.s, nm = String(P(r.s).name || '').slice(0, 5);
      ctx.font = '700 10px ' + FONT;
      const tw = ctx.measureText(nm).width + 10;
      if (tagBox.some((b) => Math.abs(b[0] - x) < (b[2] + tw) / 2 + 2 && Math.abs(b[1] - y) < 17)) return; // crowded: the colour is enough
      tagBox.push([x, y, tw]);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = 'rgba(23,19,31,.72)'; rrect(ctx, x - tw / 2, y - 8, tw, 15, 7); ctx.fill();
      ctx.fillStyle = P(r.s).color || '#fff'; ctx.fillRect(x - tw / 2 + 3, y - 4, 2, 7);
      ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(nm, x + 1.5, y);
      ctx.globalAlpha = 1;
    }
    function drawParts() {
      for (const p of parts) {
        const a = clamp(p.t / p.T, 0, 1);
        ctx.globalAlpha = a; ctx.fillStyle = p.c;
        const sz = (p.k === 1 ? 2.2 : 2.6) * Math.max(1, lay.s * 0.35);
        if (p.k === 1) { ctx.beginPath(); ctx.arc(X(p.x), Y(p.y), sz * 0.6, 0, 6.3); ctx.fill(); }
        else ctx.fillRect(X(p.x) - sz / 2, Y(p.y) - sz / 2, sz, sz);
      }
      ctx.globalAlpha = 1;
    }
    function txtO(t, x, y, col, font, al, bl) {
      ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = bl || 'middle';
      ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(23,19,31,.88)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y);
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    /* weather + light */
    function drawWeather(now, r) {
      const w = lay.w, h = lay.h, th = W.M.th, s = lay.s;
      if (th === 'rain') {
        ctx.strokeStyle = 'rgba(190,210,255,.28)'; ctx.lineWidth = 1; ctx.beginPath();
        for (let i = 0; i < 70; i++) { const hv = hash32(i, 9), x = ((hv % 1000) / 1000 * w + now * 0.05) % w, y = (((hv >>> 10) % 1000) / 1000 * h + now * 0.9) % h; ctx.moveTo(x, y); ctx.lineTo(x - 3, y + 12); }
        ctx.stroke();
      } else if (th === 'snow') {
        ctx.fillStyle = 'rgba(255,255,255,.8)';
        for (let i = 0; i < 60; i++) { const hv = hash32(i, 13), x = ((hv % 1000) / 1000 * w + Math.sin(now / 900 + i) * 14 + w) % w, y = (((hv >>> 10) % 1000) / 1000 * h + now * (0.04 + (i % 4) * 0.012)) % h; ctx.beginPath(); ctx.arc(x, y, 1 + (i % 3) * 0.7, 0, 6.3); ctx.fill(); }
      } else if (W.M.wind) {
        const wd = windAt(W, W.t), k = clamp(Math.abs(wd) / W.M.wind, 0, 1);
        ctx.strokeStyle = 'rgba(242,233,216,' + (0.1 + 0.18 * k) + ')'; ctx.lineWidth = 1.2; ctx.beginPath();
        for (let i = 0; i < 16; i++) { const hv = hash32(i, 21), y = ((hv % 1000) / 1000) * h, len = 14 + k * 30, x = (((hv >>> 10) % 1000) / 1000 * (w + 80) + Math.sign(wd || 1) * now * (0.05 + 0.25 * k)) % (w + 80); const xx = x < 0 ? x + w + 80 : x; ctx.moveTo(xx - 40, y); ctx.lineTo(xx - 40 + Math.sign(wd || 1) * len, y); }
        ctx.stroke();
      }
      if (W.M.dark) {
        if (!nightC) { nightC = document.createElement('canvas'); }
        const dpr = cv.dpr;
        if (nightC.width !== Math.round(w * dpr) || nightC.height !== Math.round(h * dpr)) { nightC.width = Math.round(w * dpr); nightC.height = Math.round(h * dpr); }
        const g = nightC.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
        g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, w, h); g.fillStyle = 'rgba(8,6,22,.8)'; g.fillRect(0, 0, w, h);
        g.globalCompositeOperation = 'destination-out';
        const hole = (x, y, rad, a) => { const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, 'rgba(0,0,0,' + a + ')'); gr.addColorStop(0.6, 'rgba(0,0,0,' + a * 0.6 + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, rad, 0, 6.3); g.fill(); };
        const vB = camY - (h - lay.bikeY) / s, vT = camY + lay.bikeY / s;
        for (let yy = Math.floor(vB / 70) * 70; yy < vT + 70; yy += 70) { hole(X(ROAD0 - 1), Y(yy), 30 * s, 0.85); hole(X(ROAD1 + 1), Y(yy + 35), 30 * s, 0.85); }
        for (let sd = 0; sd < 2; sd++) for (let i = r ? Math.max(0, r.pi[sd] - 3) : 0; i < W.lots[sd].length; i++) { const lot = W.lots[sd][i]; if (lot.y0 > vT) break; if (lot.sub && lot.y1 > vB) hole(X(sd ? 100 - 16 : 16), Y(lot.dy), 10 * s, 0.9); }
        for (const q of W.r) { if (!visY(q.y, 20)) continue; const f = isMine(q.s) || me() < 0 ? 1 : 0.5; const gr = g.createRadialGradient(X(q.x), Y(q.y + 18), 0, X(q.x), Y(q.y + 18), 34 * s); gr.addColorStop(0, 'rgba(0,0,0,' + f + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.ellipse(X(q.x), Y(q.y + 18), 18 * s, 30 * s, 0, 0, 6.3); g.fill(); hole(X(q.x), Y(q.y), 9 * s, f); }
        g.globalCompositeOperation = 'source-over';
        ctx.drawImage(nightC, 0, 0, w, h);
        // lamp heads + lit porches
        for (let yy = Math.floor(vB / 70) * 70; yy < vT + 70; yy += 70) { for (const [lx, ly] of [[ROAD0 - 1, yy], [ROAD1 + 1, yy + 35]]) { ctx.fillStyle = '#ffe9a8'; ctx.beginPath(); ctx.arc(X(lx), Y(ly), 1.3 * s, 0, 6.3); ctx.fill(); } }
      }
    }
    function drawOncomingWarn(r, now) {
      if (!r) return;
      const s = lay.s, vT = camY + (lay.bikeY - lay.hudH) / s;
      for (const o of W.mv) {
        if (o.k !== 'oncar' && o.k !== 'sled') continue;
        const p = mvPos(o, W.t, PT);
        if (o.k === 'oncar' ? (p[1] < vT || p[1] > vT + Math.abs(o.vy) * 1.4 + 30) : true) continue;
        const x = X(p[0]), y = lay.hudH + 18, a = 0.6 + 0.4 * Math.sin(now / 80);
        ctx.globalAlpha = a; ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.moveTo(x, y + 10); ctx.lineTo(x - 9, y - 6); ctx.lineTo(x + 9, y - 6); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('!', x, y - 1); ctx.globalAlpha = 1;
      }
    }
    function drawHud(now) {
      const w = lay.w, HH = lay.hudH, R = focus(), mine = me() >= 0 ? W.r[me()] : null;
      ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.fillRect(0, 0, w, HH);
      ctx.fillStyle = 'rgba(227,174,69,.35)'; ctx.fillRect(0, HH - 1, w, 1);
      const left = Math.max(0, W.dur - (phase === 'count' ? 0 : W.t));
      // time
      ctx.textBaseline = 'middle';
      ctx.font = '700 15px ' + MONO; ctx.textAlign = 'left'; ctx.fillStyle = left <= 10 && phase === 'race' ? '#ff8a70' : '#f2e9d8';
      ctx.fillText('⏱ ' + fmtT(left), 10, 16);
      // my score + combo
      const R2 = mine || R;
      if (R2) {
        dispSc += (R2.sc - dispSc) * 0.25; if (Math.abs(R2.sc - dispSc) < 1) dispSc = R2.sc;
        txtO(String(Math.round(dispSc)), w / 2, 17, '#e3ae45', Math.round(22 + scPop * 6) + 'px ' + DISP);
        ctx.font = '700 10px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'right'; ctx.fillText(mine ? '내 점수' : String(P(R2.s).name).slice(0, 5), w / 2 - 30, 18);
        if (R2.cb >= 2) { ctx.font = '700 11px ' + FONT; ctx.textAlign = 'left'; ctx.fillStyle = '#ffd76a'; ctx.fillText('콤보 ' + R2.cb, w / 2 + 30, 18); }
        // papers
        const pp = R2.pp, px = w - 12;
        ctx.font = '700 15px ' + MONO; ctx.textAlign = 'right'; ctx.fillStyle = pp <= 3 ? '#ff8a70' : '#f2e9d8'; ctx.fillText('×' + pp, px, 16);
        const tw = ctx.measureText('×' + pp).width;
        ctx.fillStyle = '#ece3d0'; rrect(ctx, px - tw - 22, 10, 16, 11, 4); ctx.fill(); ctx.fillStyle = '#c0503a'; ctx.fillRect(px - tw - 15, 10, 2.5, 11);
      }
      // row 2: board
      const rk = ranking(W.r);
      if (st.n === 1) {
        const sv = st.sv || [0, 0, 0], sc = R2 ? R2.sc : 0, x0 = 14, x1 = w - 14, by = 44, span = sv[2] * 1.12;
        ctx.strokeStyle = 'rgba(242,233,216,.2)'; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x0, by); ctx.lineTo(x1, by); ctx.stroke();
        ctx.strokeStyle = '#e3ae45'; ctx.beginPath(); ctx.moveTo(x0, by); ctx.lineTo(x0 + clamp(sc / span, 0, 1) * (x1 - x0) + 0.1, by); ctx.stroke(); ctx.lineCap = 'butt';
        sv.forEach((v, i) => txtO('★', x0 + v / span * (x1 - x0), by, sc >= v ? '#ffd76a' : 'rgba(242,233,216,.5)', (12 + i * 2) + 'px ' + FONT));
        if (best) { const bx = x0 + clamp(best / span, 0, 1) * (x1 - x0); ctx.fillStyle = '#ee6a55'; ctx.fillRect(bx - 1, by - 7, 2, 14); }
      } else {
        const n = rk.length, gap = 4, cw = (w - 16 - gap * (n - 1)) / n;
        rk.forEach((r, i) => {
          const x = 8 + i * (cw + gap), y = 33, m = isMine(r.s);
          ctx.fillStyle = m ? 'rgba(227,174,69,.22)' : 'rgba(46,38,64,.85)'; rrect(ctx, x, y, cw, 21, 8); ctx.fill();
          if (m) { ctx.strokeStyle = 'rgba(242,233,216,.7)'; ctx.lineWidth = 1.2; ctx.stroke(); }
          ctx.fillStyle = P(r.s).color; ctx.beginPath(); ctx.arc(x + 9, y + 10.5, 4, 0, 6.3); ctx.fill();
          ctx.font = '700 11px ' + MONO; ctx.textAlign = 'right'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(String(r.sc), x + cw - 6, y + 11);
          const sw = ctx.measureText(String(r.sc)).width;
          ctx.font = '700 10px ' + FONT; ctx.textAlign = 'left'; ctx.fillStyle = '#cfc6d8';
          let nm = m ? '나' : String(P(r.s).name || '');
          const maxW = cw - 26 - sw; while (nm.length > 1 && ctx.measureText(nm).width > maxW) nm = nm.slice(0, -1);
          if (maxW > 10) ctx.fillText(nm, x + 16, y + 11);
        });
      }
      // gimmick badge (wind / hill) under the bar
      if (W.M.wind && phase !== 'count') {
        const wd = windAt(W, W.t), x = w - 50, y = HH + 16;
        ctx.fillStyle = 'rgba(23,19,31,.72)'; rrect(ctx, x - 40, y - 11, 80, 22, 11); ctx.fill();
        ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#cfe8ff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('바람 ' + (Math.abs(wd) < 0.6 ? '잔잔' : (wd < 0 ? '◀ ' : '') + Math.round(Math.abs(wd)) + (wd > 0 ? ' ▶' : '')), x, y + 0.5);
      } else if (W.M.hill && R2 && phase !== 'count') {
        const k = hillAt(W, R2.y), x = w - 50, y = HH + 16;
        if (Math.abs(k) > 0.12) { ctx.fillStyle = 'rgba(23,19,31,.72)'; rrect(ctx, x - 40, y - 11, 80, 22, 11); ctx.fill(); ctx.font = '700 11px ' + FONT; ctx.fillStyle = k > 0 ? '#9ff0c0' : '#ffb592'; ctx.textAlign = 'center'; ctx.fillText(k > 0 ? '내리막 빨라요' : '오르막 느려요', x, y + 0.5); }
      }
      void now;
    }
    function drawOverlay(now) {
      const w = lay.w, cy0 = lay.hudH, ch = lay.h - lay.hudH - lay.ctlH;
      if (phase === 'count') {
        const tips = me() >= 0, pw = Math.min(w - 24, 380), ph = tips ? 170 : 78, py = cy0 + Math.max(8, (ch - ph - 70) / 2.4), px = (w - pw) / 2;
        ctx.fillStyle = 'rgba(23,19,31,.9)'; rrect(ctx, px, py, pw, ph, 14); ctx.fill();
        ctx.strokeStyle = 'rgba(227,174,69,.5)'; ctx.lineWidth = 1.5; ctx.stroke();
        txtO(W.M.nm, w / 2, py + 22, '#e3ae45', '21px ' + DISP);
        ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(W.M.hint, w / 2, py + 46, pw - 18);
        ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#ab9fb8';
        ctx.fillText(st.n === 1 ? st.dur + '초 · 별 ' + (st.sv || []).join(' / ') + '점' + (best ? ' · 최고 ' + best : '') : st.dur + '초 동안 점수가 가장 높으면 승리!', w / 2, py + 64, pw - 18);
        if (tips) {
          ctx.fillStyle = 'rgba(227,174,69,.3)'; ctx.fillRect(px + 14, py + 76, pw - 28, 1);
          const lines = [['◀ ▶', '핸들 (길을 끌어도 돼요)'], ['던지기', '왼쪽·오른쪽 집으로 신문 휙!'], ['◎ 표시', '신문이 떨어질 자리 — 금색이면 우편함'], ['⊘ 빨간 표', '신문 사절 집 — 던지면 −' + BADP]];
          lines.forEach((l, i) => {
            const y = py + 94 + i * 19;
            ctx.font = '700 11.5px ' + FONT; ctx.textAlign = 'right'; ctx.fillStyle = i === 3 ? '#ff9a86' : '#ffd76a'; ctx.fillText(l[0], px + 86, y);
            ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(l[1], px + 94, y, pw - 104);
          });
        }
        const n = Math.ceil(cd);
        if (n <= COUNT) { const k = cd - Math.floor(cd); ctx.globalAlpha = clamp(k * 2, 0, 1); txtO(String(n), w / 2, py + ph + 38, '#f2e9d8', Math.round(46 + 16 * k) + 'px ' + DISP); ctx.globalAlpha = 1; }
      } else if (phase === 'race' && W.t < 0.9) {
        ctx.globalAlpha = clamp(1 - W.t / 0.9, 0, 1); txtO('출발!', w / 2, cy0 + ch * 0.4, '#e3ae45', '50px ' + DISP); ctx.globalAlpha = 1;
      }
      if (banner) {
        ctx.globalAlpha = clamp(banner.t * 2.5, 0, 1);
        const y = cy0 + ch * (banner.small ? 0.2 : 0.36);
        txtO(banner.text, w / 2, y, '#e3ae45', (banner.small ? 26 : 34) + 'px ' + DISP);
        txtO(banner.sub, w / 2, y + (banner.small ? 24 : 30), '#f2e9d8', '700 13px ' + FONT);
        ctx.globalAlpha = 1;
      }
      if (me() >= 0 && phase === 'race' && hintT > 0 && !thrown && W.t > 1) {
        const a = clamp(hintT, 0, 1) * (0.7 + 0.3 * Math.sin(now / 160));
        ctx.globalAlpha = a; txtO('구독 집이 다가오면 ◎ 표시를 맞추고 「던지기」!', w / 2, lay.h - lay.ctlH - 16, '#ffd76a', '700 12.5px ' + FONT); ctx.globalAlpha = 1;
      }
      const r = me() >= 0 ? W.r[me()] : null;
      if (r && phase === 'race' && r.pp <= 0 && !r.done) txtO('신문이 없어요 — 길 위의 신문 묶음을 주워요!', w / 2, lay.h - lay.ctlH - 16, '#ff9a86', '700 12.5px ' + FONT);
    }
    function drawFloats() {
      for (const f of floats) {
        if (!visY(f.y, 30)) continue;
        const k = 1 - f.t / f.T, a = clamp(f.t * 2.5, 0, 1);
        ctx.globalAlpha = a;
        const font = '700 ' + (f.big ? 14 : 12) + 'px ' + FONT;
        ctx.font = font; const tw = ctx.measureText(f.text).width;
        const x = clamp(X(f.x), tw / 2 + 6, lay.w - tw / 2 - 6);
        txtO(f.text, x, Y(f.y) - k * 22, f.col, font);
      }
      ctx.globalAlpha = 1;
    }
    function draw(now) {
      cv.clear();
      if (!W || !lay) { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, cv.w, cv.h); return; }
      const f = focus(); if (f) camY = f.y;
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 6 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 6 : 0;
      ctx.save(); ctx.translate(sx, sy);
      drawStrips();
      const mine = me() >= 0 ? W.r[me()] : f;
      drawHouseState(mine, now);
      drawMarks();
      drawBundles(mine, now);
      for (const o of W.dogs) if (visY(o.y, 12)) drawDog(o, mine, now);
      for (const o of W.mv) drawMover(o, now);
      drawAim(me() >= 0 ? W.r[me()] : null, now);
      const others = W.r.filter((r) => r !== mine);
      for (const r of others) drawBike(r, 0.4, now, false);
      if (mine) drawBike(mine, 1, now, me() >= 0);
      drawPapers(mine, now);
      drawParts();
      ctx.restore();
      drawWeather(now, mine);
      tagBox.length = 0;
      if (mine && me() >= 0) tagBox.push([X(mine.x), Y(mine.y) - 2 * lay.s, 9 * lay.s], [X(mine.x), Y(mine.y) - 6.5 * lay.s, 9 * lay.s]);
      for (const r of others) drawTag(r, 0.75);
      drawFloats();
      drawOncomingWarn(mine, now);
      drawHud(now);
      drawOverlay(now);
      ctl.classList.toggle('idle', phase !== 'race');
      if (mine && me() >= 0) { bL.classList.toggle('off', mine.pp <= 0); bR.classList.toggle('off', mine.pp <= 0); }
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; startRace(); }
        if (st.ph === 'race' && phase === 'count' && !host()) { phase = 'race'; cd = 0; }
        if (st.ph === 'done' && phase !== 'done') { phase = 'done'; thQ = []; }
      },
      destroy() {
        stopLoop();
        steer.removeEventListener('pointerdown', sDown); steer.removeEventListener('pointermove', sMove);
        steer.removeEventListener('pointerup', sUp); steer.removeEventListener('pointercancel', sUp); steer.removeEventListener('lostpointercapture', sUp);
        bL.removeEventListener('pointerdown', tL); bR.removeEventListener('pointerdown', tR);
        cv.cv.removeEventListener('pointerdown', cDown); cv.cv.removeEventListener('pointermove', cMove);
        cv.cv.removeEventListener('pointerup', cUp); cv.cv.removeEventListener('pointercancel', cUp);
        cv.cv.removeEventListener('contextmenu', noCtx); ctl.removeEventListener('contextmenu', noCtx);
        offIn();
        strips.clear();
        ctl.remove(); styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, phase, lay, camY, queueThrow }),
    };
  }

  L.register({
    id: 'paperboy', name: '신문 배달 자전거', tag: '실시간 배달 레이스', cat: '아케이드',
    blurb: '자전거로 골목을 달리며 구독하는 집 우편함·현관에 신문을 휙! 신문 사절 집은 피하고 개·쓰레기통·공사장·자동차를 피해, 제한 시간 안에 가장 많이 정확하게 배달하면 승리.',
    tint: '#2f5a7a',
    icon: '<circle cx="15" cy="40" r="9" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="41" cy="40" r="9" fill="none" stroke="currentColor" stroke-width="3"/><path d="M15 40l9-14h12l5 14M24 26l-3-6h-5M36 26l2-5h5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><rect x="33" y="5" width="16" height="9" rx="4" transform="rotate(-20 41 9.5)" fill="currentColor"/><path d="M27 15c2-5 5-7 8-8" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-dasharray="2.5 3"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'left', label: '왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'throwL', label: '왼쪽 집으로 던지기', keys: ['KeyZ', 'KeyJ', 'KeyQ'], pad: ['x', 'lb', 'lt'] },
      { id: 'throwR', label: '오른쪽 집으로 던지기', keys: ['KeyX', 'KeyK', 'KeyE'], pad: ['b', 'rb', 'rt'] },
    ],
    options: [
      { id: 'map', label: '거리', choices: [{ v: 'rand', label: '무작위' }].concat(MAPS.map((m) => ({ v: m.id, label: m.nm }))), def: 'rand' },
      { id: 'time', label: '제한 시간', choices: [{ v: 60, label: '60초' }, { v: 90, label: '90초' }, { v: 120, label: '120초' }], def: 90 },
    ],
    quick: [
      '목표: 제한 시간 안에 구독하는 집에 신문을 정확히 많이 배달해요.',
      '할 일: ◀▶로 자전거를 움직이고, 「왼쪽/오른쪽 던지기」로 그쪽 집에 신문을 던져요.',
      '이기는 법: 우편함 150 · 현관 100 · 마당 50점! 「신문 사절」 집과 장애물은 피해요.',
    ],
    rules: [
      { h: '목표', p: [
        '자전거는 저절로 앞으로 달려요. 길 양쪽 집 중 구독하는 집에 신문을 던져 넣어요.',
        '시간이 끝났을 때 점수가 가장 높은 사람이 이겨요(같으면 공동 1위).',
      ] },
      { h: '집 구별하기', p: [
        '구독 집: 지붕이 알록달록하고 지붕에 하얀 신문 표시, 빨간 우편함에 노란 깃발이 서 있어요.',
        '신문 사절 집: 지붕이 회색이고 지붕에 빨간 ⊘ 표시. 여기에 떨어지면 −' + BADP + '점, 콤보도 끊겨요.',
        '배달한 집은 지붕 표시가 초록 ✓로 바뀌어요. 같은 집에 또 던지면 점수 없어요.',
      ] },
      { h: '던지기', p: [
        '신문은 언제나 옆으로 같은 거리만큼 날아가고, 달리는 만큼 조금 앞에 떨어져요.',
        '그래서 내가 달리는 자리가 곧 조준이에요. 가운데 노란 줄 위 = 양쪽 우편함, 왼쪽(오른쪽)으로 붙으면 그쪽 현관.',
        '길 위의 ◎ 표시가 지금 던지면 떨어질 자리예요. 금색 = 우편함, 흰색 = 현관, 초록 = 마당, 빨강 = 사절 집.',
        '점수: 우편함 150 · 현관 매트 100 · 마당 50. 지붕·담장 너머·길에 떨어지면 0점.',
        '콤보: 연속으로 배달할 때마다 +10점씩 더(최대 +100). 구독 집을 그냥 지나치거나, 사절 집에 던지거나, 넘어지면 끊겨요.',
        '예시: 왼쪽 구독 집 우편함이 다가와요 → 가운데 줄에 맞춰 달리다가 ◎가 금색이 되는 순간 「왼쪽 던지기」 → 우편함 쏙! +150.',
      ] },
      { h: '신문과 장애물', p: [
        '신문은 ' + PAPER0 + '부로 시작해요(최대 ' + PAPER_MAX + '부). 길 위의 신문 묶음을 지나가면 +' + BUNDLE + '부.',
        '쓰레기통·고깔·공사장·세워 둔 차·자동차·개·고양이·사람에 부딪히면 꽈당! 잠깐 멈추고 콤보가 끊겨요(점수는 그대로).',
        '마당의 개는 자전거가 가까이 오면 길로 뛰어나와요. 위쪽에 빨간 ! 가 보이면 마주 오는 차가 와요.',
      ] },
      { h: '거리 (10곳)', p: MAPS.map((m) => m.nm + ': ' + m.hint).concat(['「무작위」를 고르면 매 판 한 곳이 골라져요.']) },
      { h: '조작', p: [
        '폰: 왼쪽 아래 ◀▶를 누르고 있으면 그쪽으로 움직여요(누른 채 옆으로 밀어도 돼요). 길을 손가락으로 끌어도 자전거가 따라와요.',
        '오른쪽 아래 「왼쪽 던지기」「오른쪽 던지기」로 던져요. 한 번 던지면 0.3초 쉬어요.',
        'PC 키보드·게임패드: ←→(A·D) 이동, Z·X(J·K) 던지기. 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '함께 하기', p: [
        '모두 같은 거리를 각자 달려요. 다른 사람 자전거는 반투명하게 보이고 서로 부딪히지 않아요. 위쪽 점수판에서 점수를 비교해요.',
        '한 폰에서는 한 명만 해요. 나머지 자리는 AI예요. 친구와는 온라인·LAN 방으로 각자 폰에서.',
        '혼자 하기(1명): 점수로 별 3개에 도전! 최고 기록이 이 폰에 남아요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 마당에 대충 던지고 자주 부딪혀요, 어려움은 우편함을 노리고 멀리 내다봐요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { MAPS, buildWorld, newRider, stepRider, aiThink, ranking, zoneAt, lotAt, landPoint, collide, windAt, speedAt, H, PTS, D_THROW, T_FLY, STARF },
  });
})();
