/* 주사위 마을 짓기 — 여러 종류의 주사위 중 골라 굴리고, 나온 수에 맞는 건물이 돈을 벌어 오는 마을 짓기 게임.
   (독자 설계: 주사위 6종 · 건물 16종 · 랜드마크 5개 · 혼자 하기 별점) */
(function () {
  const L = window.Lounge, U = L.util;

  /* ======================= data ======================= */
  // k: F 들판(누가 굴려도·은행) / G 가게(내가 굴릴 때·은행) / R 요금(남이 굴릴 때·굴린 사람이 내게) / P 특별(내가 굴릴 때·한 사람 1개)
  const BL = [
    { k: 'F', n: [1], c: 1, nm: '밀밭', p: 1, lo: 1 },
    { k: 'F', n: [2], c: 1, nm: '양 목장', p: 1, lo: 1 },
    { k: 'F', n: [4], c: 2, nm: '사과밭', p: 1, lo: 1 },
    { k: 'F', n: [6], c: 3, nm: '숲', p: 2 },
    { k: 'F', n: [9], c: 5, nm: '광산', p: 7 },
    { k: 'F', n: [11], c: 3, nm: '고깃배', p: 5 },
    { k: 'G', n: [3], c: 1, nm: '떡집', p: 2, lo: 1 },
    { k: 'G', n: [5], c: 2, nm: '꽃가게', p: 4 },
    { k: 'G', n: [7], c: 3, nm: '양털 공방', p: 3, per: 1 },
    { k: 'G', n: [8], c: 3, nm: '잼 공장', p: 4, per: 2 },
    { k: 'G', n: [10], c: 3, nm: '목공소', p: 4, per: 3 },
    { k: 'G', n: [12], c: 3, nm: '수산시장', p: 6, per: 5 },
    { k: 'R', n: [4], c: 2, nm: '분식집', p: 1, lo: 1 },
    { k: 'R', n: [7], c: 3, nm: '주차장', p: 2 },
    { k: 'P', n: [7], c: 6, nm: '축제 무대', p: 2 },
    { k: 'P', n: [6], c: 4, nm: '주사위 박물관', p: 2 },
  ];
  const NB = BL.length;
  const LM = [
    { nm: '주사위 공방', c: 4, fx: '큰 주사위(5–12)를 쓸 수 있어요' },
    { nm: '조폐소', c: 10, fx: '동전 주사위를 같이 굴릴 수 있어요' },
    { nm: '쌍둥이 탑', c: 15, fx: '쌍둥이 주사위(두 눈의 합)를 쓸 수 있어요. 같은 눈이면 내 수입 두 배' },
    { nm: '별빛 천문대', c: 20, fx: '별 주사위(두 배·할인·번개…)를 쓸 수 있어요' },
    { nm: '소원 우물', c: 26, fx: '차례마다 한 번, 주사위를 모두 다시 굴릴 수 있어요' },
  ];
  // dice kinds: S 작은(1–4) · M 보통(1–6) · B 큰(5–12) · T 쌍둥이(2d6) / add-ons: C 동전 · X 별
  const DK = {
    S: { nm: '작은 주사위', sh: '작은', rg: '1–4', slots: 1, need: -1 },
    M: { nm: '보통 주사위', sh: '보통', rg: '1–6', slots: 1, need: -1 },
    B: { nm: '큰 주사위', sh: '큰', rg: '5–12', slots: 1, need: 0 },
    T: { nm: '쌍둥이 주사위', sh: '쌍둥이', rg: '2–12', slots: 2, need: 2 },
    C: { nm: '동전 주사위', sh: '동전', rg: '0–3원', slots: 1, need: 1 },
    X: { nm: '별 주사위', sh: '별', rg: '특수', slots: 1, need: 3 },
  };
  const NUMK = ['S', 'M', 'B', 'T'];
  const COIN = [0, 1, 1, 2, 2, 3];
  // star faces: 0 두 배 · 1 두 배 · 2 할인 · 3 번개 · 4 빈칸 · 5 먹구름
  const STAR = ['두 배', '두 배', '할인', '번개', '빈칸', '먹구름'];
  const START_COINS = 3, MAX_ROUNDS = 60;
  const SOLO_LIMIT = 30, SOLO_STARS = [17, 21, 25]; // ★★★ ≤ 17턴 · ★★ ≤ 21 · ★ ≤ 25 (30턴 안에 못 지으면 실패)

  const hasL = (s, p, i) => (s.lm[p] >> i) & 1;
  const lmCount = (s, p) => { let k = 0; for (let i = 0; i < 5; i++) k += hasL(s, p, i); return k; };
  const soloOff = (i) => BL[i].k === 'R' || i === 14; // 혼자 할 땐 요금 건물·축제 무대 없음
  // shop stock per building: low numbers (1–4) n+1, others n+3 (solo 3 / 5); the starting 밀밭·떡집 come on top
  function supMax(s, i) { return (BL[i].lo ? (s.n === 1 ? 3 : s.n) : (s.n === 1 ? 5 : s.n + 3)) + (i === 0 || i === 6 ? s.n : 0); }
  function supplyLeft(s, i) {
    if (BL[i].k === 'P') return 1;
    let t = 0; for (let p = 0; p < s.n; p++) t += s.b[p][i];
    return supMax(s, i) - t;
  }
  function priceOf(s, base) { return Math.max(1, base - (s.disc || 0)); }
  function canBuyB(s, p, i) {
    if (i < 0 || i >= NB) return false;
    if (s.n === 1 && soloOff(i)) return false;
    if (BL[i].k === 'P' && s.b[p][i] > 0) return false;
    if (supplyLeft(s, i) <= 0) return false;
    return s.c[p] >= priceOf(s, BL[i].c);
  }
  function canBuyL(s, p, i) { return i >= 0 && i < 5 && !hasL(s, p, i) && s.c[p] >= priceOf(s, LM[i].c); }

  /* ---------- dice selection ---------- */
  function legalSel(s, p, sel) {
    if (!sel || !DK[sel.n] || !NUMK.includes(sel.n)) return false;
    const need = DK[sel.n].need;
    if (need >= 0 && !hasL(s, p, need)) return false;
    if (sel.c && !hasL(s, p, 1)) return false;
    if (sel.x && !hasL(s, p, 3)) return false;
    return !(sel.c && sel.x); // 숫자 주사위 1개 + 덤 주사위(동전 또는 별) 1개까지
  }
  function allSels(s, p) {
    const out = [];
    for (const n of NUMK) for (const c of [0, 1]) for (const x of [0, 1]) { const sel = { n, c, x }; if (legalSel(s, p, sel)) out.push(sel); }
    return out;
  }
  const diceCount = (sel) => DK[sel.n].slots + (sel.c ? 1 : 0) + (sel.x ? 1 : 0);
  // number outcomes: [{v, p, dbl}]
  const DIST = {
    S: [1, 2, 3, 4].map((v) => ({ v, p: 1 / 4, dbl: 0 })),
    M: [1, 2, 3, 4, 5, 6].map((v) => ({ v, p: 1 / 6, dbl: 0 })),
    B: [5, 6, 7, 8, 9, 10, 11, 12].map((v) => ({ v, p: 1 / 8, dbl: 0 })),
    T: (() => { const o = []; for (let a = 1; a <= 6; a++) for (let b = 1; b <= 6; b++) o.push({ v: a + b, p: 1 / 36, dbl: a === b ? 1 : 0 }); return o; })(),
  };
  function sumDist(n) { // [{v, p}] merged (for the payout strip)
    const m = {}; DIST[n].forEach((o) => { m[o.v] = (m[o.v] || 0) + o.p; });
    return Object.keys(m).map((v) => ({ v: +v, p: m[v] })).sort((a, b) => a.v - b.v);
  }

  /* ---------- settling a roll ---------- */
  // mutates c (coins array); returns events [[code, to, from, amt]] — code: building idx, 20 coin die, 21 번개, 22 더블, 23 저금
  function settle(s, c, seat, sum, nd, mult, dbl, coinFace, starFace, ev) {
    ev = ev || [];
    const n = s.n;
    if (coinFace > 0) { c[seat] += coinFace; ev.push([20, seat, -1, coinFace]); }
    // 1) 요금: other owners take from the roller
    for (let k = 1; k < n; k++) {
      const o = (seat + k) % n;
      for (let i = 0; i < NB; i++) {
        const B = BL[i]; if (B.k !== 'R' || !s.b[o][i] || !B.n.includes(sum)) continue;
        const amt = Math.min(B.p * s.b[o][i], c[seat]);
        if (amt > 0) { c[seat] -= amt; c[o] += amt; ev.push([i, o, seat, amt]); }
      }
    }
    // 2) 들판: every owner, from the bank
    for (let k = 0; k < n; k++) {
      const o = (seat + k) % n;
      for (let i = 0; i < NB; i++) {
        const B = BL[i]; if (B.k !== 'F' || !s.b[o][i] || !B.n.includes(sum)) continue;
        const amt = B.p * s.b[o][i] * (o === seat ? mult : 1);
        if (amt > 0) { c[o] += amt; ev.push([i, o, -1, amt]); }
      }
    }
    // 3) 가게 + 4) 특별: roller only
    for (let i = 0; i < NB; i++) {
      const B = BL[i]; if (!s.b[seat][i] || !B.n.includes(sum)) continue;
      if (B.k === 'G') {
        const base = B.per != null ? B.p * s.b[seat][B.per] : B.p;
        const amt = base * s.b[seat][i] * mult;
        if (amt > 0) { c[seat] += amt; ev.push([i, seat, -1, amt]); }
      } else if (i === 14) {
        for (let k = 1; k < n; k++) { const o = (seat + k) % n; const amt = Math.min(B.p, c[o]); if (amt > 0) { c[o] -= amt; c[seat] += amt; ev.push([i, seat, o, amt]); } }
      } else if (i === 15) {
        const amt = B.p * nd * mult;
        if (amt > 0) { c[seat] += amt; ev.push([i, seat, -1, amt]); }
      }
    }
    if (starFace === 3) {
      if (n === 1) { c[seat] += 2; ev.push([21, seat, -1, 2]); }
      else {
        let best = -1;
        for (let k = 1; k < n; k++) { const o = (seat + k) % n; if (best < 0 || c[o] > c[best]) best = o; }
        const amt = Math.min(3, c[best]);
        if (amt > 0) { c[best] -= amt; c[seat] += amt; ev.push([21, seat, best, amt]); }
      }
    }
    return ev;
  }
  const multOf = (x) => (x === 0 || x === 1 ? 2 : x === 5 ? 0 : 1);

  /* expected values (used by the hint strip and the AIs) */
  // gain for `seat` if `roller` rolls `sum` (ignores coin/star dice), plus total gain of others
  function gainAt(s, roller, sum, nd, mult, dbl, me) {
    const c = s.c.slice();
    settle(s, c, roller, sum, nd, mult, dbl, 0, -1);
    let mine = 0, oth = 0;
    for (let p = 0; p < s.n; p++) { const d = c[p] - s.c[p]; if (p === me) mine += d; else oth += d; }
    return [mine, oth];
  }
  // EV of a selection for the roller: {ev, oth, strip:[{v,p,g}]}
  function evSel(s, seat, sel) {
    const nd = diceCount(sel);
    let ev = 0, oth = 0;
    const per = {};
    for (const o of DIST[sel.n]) {
      const dbl = sel.n === 'T' && o.dbl ? 1 : 0;
      let g, h;
      if (sel.x) { // average over star faces
        g = 0; h = 0;
        for (let f = 0; f < 6; f++) { const r = gainAt(s, seat, o.v, nd, multOf(f) * (dbl ? 2 : 1), dbl, seat); g += r[0] / 6; h += r[1] / 6; }
      } else { const r = gainAt(s, seat, o.v, nd, dbl ? 2 : 1, dbl, seat); g = r[0]; h = r[1]; }
      ev += o.p * g; oth += o.p * h;
      const r1 = per[o.v] || (per[o.v] = { v: o.v, p: 0, g: gainAt(s, seat, o.v, nd, 1, 0, seat)[0] });
      r1.p += o.p;
    }
    if (sel.c) ev += 1.5;
    if (sel.x) { ev += 0.5 /* 할인 ~3/6 */ + (s.n > 1 ? 0.45 : 0.33); }
    const strip = Object.keys(per).map((k) => per[k]).sort((a, b) => a.v - b.v);
    return { ev, oth, strip };
  }

  /* ======================= state ======================= */
  function init(players) {
    const n = players.length;
    const b = players.map(() => { const a = Array(NB).fill(0); a[0] = 1; a[6] = 1; return a; });
    return {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), c: players.map(() => START_COINS), b, lm: players.map(() => 0),
      t: 0, ph: 'r', tn: 0, rr: 0, disc: 0, sel: null, roll: null, win: -1, end: 0,
      last: null, seq: 0, g: Math.floor(Math.random() * 1e6),
    };
  }
  function actor(s) { return s.end ? null : s.t; }
  function rollDice(sel) {
    const r = { n: sel.n, v: [], c: -1, x: -1 };
    if (sel.n === 'S') r.v = [1 + Math.floor(Math.random() * 4)];
    else if (sel.n === 'M') r.v = [1 + Math.floor(Math.random() * 6)];
    else if (sel.n === 'B') r.v = [5 + Math.floor(Math.random() * 8)];
    else r.v = [1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)];
    if (sel.c) r.c = Math.floor(Math.random() * 6);
    if (sel.x) r.x = Math.floor(Math.random() * 6);
    return r;
  }
  const rollSum = (r) => r.v.reduce((a, v) => a + v, 0);
  function resolveRoll(s, seat) {
    const r = s.roll, sel = s.sel;
    const sum = rollSum(r), dbl = r.n === 'T' && r.v[0] === r.v[1] ? 1 : 0;
    const before = s.c.slice();
    const ev = settle(s, s.c, seat, sum, diceCount(sel), (r.x >= 0 ? multOf(r.x) : 1) * (dbl ? 2 : 1), dbl, r.c >= 0 ? COIN[r.c] : 0, r.x);
    s.disc = r.x === 2 ? 3 : 0;
    s.ph = 'b';
    s.last = { id: ++s.seq, k: 'res', s: seat, r, sum, d: s.c.map((v, i) => v - before[i]), e: ev.slice(0, 40) };
  }
  function endTurn(s) {
    s.tn++; s.rr = 0; s.disc = 0; s.sel = null; s.roll = null; s.ph = 'r';
    if (s.n === 1) { if (s.tn >= SOLO_LIMIT) s.end = 1; }
    else if (s.tn >= s.n * MAX_ROUNDS) s.end = 1;
    s.t = (s.t + 1) % s.n;
  }
  function apply(s, seat, a) {
    if (s.end || seat !== s.t || !a) throw new Error('not your turn');
    if (a.t === 'r') { // roll (or reroll in the keep phase)
      if (s.ph === 'r') {
        const sel = { n: a.n, c: a.c ? 1 : 0, x: a.x ? 1 : 0 };
        if (!legalSel(s, seat, sel)) throw new Error('illegal dice');
        s.sel = sel;
      } else if (s.ph === 'k') {
        if (s.rr) throw new Error('reroll used');
        s.rr = 1;
      } else throw new Error('not rolling now');
      s.roll = rollDice(s.sel);
      s.last = { id: ++s.seq, k: 'roll', s: seat, r: s.roll, re: s.ph === 'k' ? 1 : 0 };
      if (hasL(s, seat, 4) && !s.rr) { s.ph = 'k'; return s; }
      resolveRoll(s, seat);
      s.last.k = 'roll+'; // rolled and settled in one go
      return s;
    }
    if (a.t === 'k') { if (s.ph !== 'k') throw new Error('nothing to keep'); resolveRoll(s, seat); return s; }
    if (s.ph !== 'b') throw new Error('roll first');
    if (a.t === 'b') {
      const i = a.i | 0;
      if (!canBuyB(s, seat, i)) throw new Error('cannot build');
      const pr = priceOf(s, BL[i].c);
      s.c[seat] -= pr; s.b[seat][i]++;
      s.last = { id: ++s.seq, k: 'b', s: seat, i, pr };
      endTurn(s); return s;
    }
    if (a.t === 'l') {
      const i = a.i | 0;
      if (!canBuyL(s, seat, i)) throw new Error('cannot build');
      const pr = priceOf(s, LM[i].c);
      s.c[seat] -= pr; s.lm[seat] |= 1 << i;
      s.last = { id: ++s.seq, k: 'l', s: seat, i, pr };
      if (lmCount(s, seat) === 5) { s.win = seat; s.end = 1; s.done = s.tn + 1; return s; }
      endTurn(s); return s;
    }
    if (a.t === 'p') {
      s.c[seat] += 1;
      s.last = { id: ++s.seq, k: 'p', s: seat };
      endTurn(s); return s;
    }
    throw new Error('bad action');
  }
  function soloStars(s) { if (s.win !== 0) return 0; const t = s.done; return t <= SOLO_STARS[0] ? 3 : t <= SOLO_STARS[1] ? 2 : t <= SOLO_STARS[2] ? 1 : 0; }
  function result(s) {
    if (!s.end) return null;
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    if (s.n === 1) {
      const st = soloStars(s);
      if (s.win === 0) return { winners: [0], title: st ? '별 ' + st + '개!' : '마을 완성!', text: '★'.repeat(st) + '☆'.repeat(3 - st) + '\n' + s.done + '턴 만에 랜드마크 5개 완성\n(★★★ ' + SOLO_STARS[0] + '턴 · ★★ ' + SOLO_STARS[1] + '턴 · ★ ' + SOLO_STARS[2] + '턴 안에)' };
      return { winners: [], title: '아쉬워요', text: SOLO_LIMIT + '턴 안에 랜드마크를 ' + lmCount(s, 0) + '개 지었어요. 5개를 모두 지으면 성공!' };
    }
    if (s.win >= 0) return { winners: [s.win], title: nm(s.win) + ' 마을 완성!', text: '랜드마크 5개를 가장 먼저 지었어요.\n' + rank(s) };
    // round cap: most landmarks, then coins
    const sc = (p) => lmCount(s, p) * 1000 + s.c[p];
    const top = Math.max(...s.nm.map((_, p) => sc(p)));
    const winners = s.nm.map((_, p) => p).filter((p) => sc(p) === top);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 승리' : '공동 승리', text: MAX_ROUNDS + '바퀴가 지나 랜드마크·돈으로 정했어요.\n' + rank(s) };
  }
  function rank(s) {
    const ord = s.nm.map((_, p) => p).sort((a, b) => lmCount(s, b) - lmCount(s, a) || s.c[b] - s.c[a]);
    return ord.map((p) => (s.nm[p] || p + 1 + '번') + ' · 랜드마크 ' + lmCount(s, p) + ' · ' + s.c[p] + '원').join('\n');
  }

  /* ======================= AI ======================= */
  // which dice would `p` likely roll (best own EV) — used to guess opponents' number distribution
  function bestSel(s, p, w) {
    let best = null, bv = -1e9;
    for (const sel of allSels(s, p)) {
      const e = evSel(s, p, sel);
      const v = e.ev - (w || 0) * e.oth / Math.max(1, s.n - 1);
      if (v > bv + 1e-9) { bv = v; best = sel; }
    }
    return best || { n: 'M', c: 0, x: 0 };
  }
  function selProbs(sel) { const m = {}; for (const o of DIST[sel.n]) m[o.v] = (m[o.v] || 0) + o.p; return m; }
  // expected income per full round for player p (own roll + others' rolls), with fixed opponent dice guesses
  function incomeRound(s, p, oppProbs, mySel) {
    let tot = evSel(s, p, mySel).ev;
    for (let o = 0; o < s.n; o++) {
      if (o === p) continue;
      const pr = oppProbs[o];
      for (const v in pr) {
        const sum = +v;
        let g = 0;
        for (let i = 0; i < NB; i++) {
          const B = BL[i]; if (!s.b[p][i] || !B.n.includes(sum)) continue;
          if (B.k === 'F') g += B.p * s.b[p][i];
          else if (B.k === 'R') g += Math.min(B.p * s.b[p][i], Math.max(1, s.c[o] * 0.6));
        }
        if (s.b[o][14] && sum === 7) g -= Math.min(2, s.c[p]); // their stage takes from me
        tot += pr[v] * g;
      }
    }
    return tot;
  }
  function oppGuess(s, p) {
    const o = [];
    for (let q = 0; q < s.n; q++) o.push(q === p ? null : selProbs(bestSel(s, q, 0)));
    return o;
  }
  function withB(s, p, i) { const t = { n: s.n, c: s.c, b: s.b.map((r) => r.slice()), lm: s.lm.slice(), disc: 0 }; t.b[p][i]++; return t; }
  function withL(s, p, i) { const t = { n: s.n, c: s.c, b: s.b, lm: s.lm.slice(), disc: 0 }; t.lm[p] |= 1 << i; return t; }
  function remainingL(s, p) { let c = 0; for (let i = 0; i < 5; i++) if (!hasL(s, p, i)) c += LM[i].c; return c; }

  function aiRoll(s, p, lv) {
    const sels = allSels(s, p);
    if (lv === 1) {
      // beginner: usually the plain die, sometimes something random, never thinks about others
      let r;
      if (Math.random() < 0.5) { r = bestSel(s, p, 0); } // sometimes it reads the hint strip…
      else if (Math.random() < 0.5) r = { n: 'M', c: hasL(s, p, 1) ? 1 : 0, x: 0 }; // …often just the plain die
      else r = sels[Math.floor(Math.random() * sels.length)];
      return { t: 'r', n: r.n, c: r.c, x: r.x };
    }
    const w = lv >= 3 ? 0.35 : 0;
    let best = sels[0], bv = -1e9;
    for (const sel of sels) {
      const e = evSel(s, p, sel);
      let v = e.ev - w * e.oth / Math.max(1, s.n - 1);
      if (lv === 2) v += (Math.random() - 0.5) * 0.4;
      if (v > bv) { bv = v; best = sel; }
    }
    return { t: 'r', n: best.n, c: best.c, x: best.x };
  }
  function realized(s, p) {
    const r = s.roll, sum = rollSum(r), dbl = r.n === 'T' && r.v[0] === r.v[1] ? 1 : 0;
    const c = s.c.slice();
    settle(s, c, p, sum, diceCount(s.sel), (r.x >= 0 ? multOf(r.x) : 1) * (dbl ? 2 : 1), dbl, r.c >= 0 ? COIN[r.c] : 0, r.x);
    return c[p] - s.c[p] + (r.x === 2 ? 2 : 0);
  }
  function aiKeep(s, p, lv) {
    const got = realized(s, p);
    if (lv === 1) return Math.random() < 0.25 && got <= 0 ? { t: 'r' } : { t: 'k' };
    const ev = evSel(s, p, s.sel).ev;
    if (lv === 2) return got <= 0 && ev > 0.6 ? { t: 'r' } : { t: 'k' };
    return got < ev - 0.4 ? { t: 'r' } : { t: 'k' };
  }

  function aiBuild(s, p, lv) {
    const coins = s.c[p];
    const affB = [], affL = [];
    for (let i = 0; i < NB; i++) if (canBuyB(s, p, i)) affB.push(i);
    for (let i = 0; i < 5; i++) if (canBuyL(s, p, i)) affL.push(i);
    if (lv === 1) {
      if (affL.length && Math.random() < 0.75) return { t: 'l', i: affL[Math.floor(Math.random() * affL.length)] };
      if (!affB.length || Math.random() < 0.2) return { t: 'p' };
      const cheap = affB.filter((i) => BL[i].c <= Math.max(2, coins / 2));
      const pool = cheap.length && Math.random() < 0.7 ? cheap : affB;
      return { t: 'b', i: pool[Math.floor(Math.random() * pool.length)] };
    }
    const opp = oppGuess(s, p);
    const mySel = bestSel(s, p, 0);
    const base = incomeRound(s, p, opp, mySel);
    const remL = remainingL(s, p);
    // rounds left until someone finishes (rough)
    let H = remL / Math.max(1.2, base);
    if (lv >= 3) for (let q = 0; q < s.n; q++) if (q !== p) { const rq = remainingL(s, q); if (rq <= 20) H = Math.min(H, 2 + rq / 4); }
    H = U.clamp(H, 2, 14);
    // landmarks
    if (affL.length) {
      if (lv === 2) { // the priciest landmark it can afford
        return { t: 'l', i: affL.reduce((a, b) => (LM[b].c > LM[a].c ? b : a)) };
      }
      let bi = -1, bv = -1e9;
      for (const i of affL) {
        const t = withL(s, p, i);
        const inc = incomeRound(t, p, opp, bestSel(t, p, 0)) - base;
        const v = inc * H + LM[i].c * 0.3;
        if (v > bv) { bv = v; bi = i; }
      }
      // last landmark wins on the spot; otherwise buy unless an engine piece is clearly better early on
      if (lmCount(s, p) === 4) return { t: 'l', i: bi };
      let bestB = -1e9;
      for (const i of affB) { const t = withB(s, p, i); const v = (incomeRound(t, p, opp, bestSel(t, p, 0)) - base) * H - BL[i].c; if (v > bestB) bestB = v; }
      if (bestB < LM[bi].c * 0.8 || base > 3) return { t: 'l', i: bi };
    }
    let bi = -1, bv = 0;
    const sels = allSels(s, p), evNow = sels.map((sel) => evSel(s, p, sel).ev);
    const wPlan = lv >= 3 ? 0.5 : 0.25;
    for (const i of affB) {
      const t = withB(s, p, i);
      let plan = 0;
      sels.forEach((sel, k) => { plan = Math.max(plan, evSel(t, p, sel).ev - evNow[k]); });
      const inc = (incomeRound(t, p, opp, bestSel(t, p, 0)) - base) * (1 - wPlan) + plan * wPlan;
      let v = inc * H - BL[i].c * (lv >= 3 ? 1 : 0.8);
      if (lv === 2) v += (Math.random() - 0.5) * 0.8;
      if (v > bv) { bv = v; bi = i; }
    }
    if (lv >= 3) {
      // save up when the next landmark is in reach next turn and the best building is only marginal
      let cheapest = 1e9; for (let i = 0; i < 5; i++) if (!hasL(s, p, i)) cheapest = Math.min(cheapest, LM[i].c);
      if (bi >= 0 && coins - BL[bi].c < cheapest && coins + 1 + base >= cheapest && bv < 2.5) return { t: 'p' };
    }
    return bi >= 0 ? { t: 'b', i: bi } : { t: 'p' };
  }
  function ai(s, p, lv) {
    lv = lv || 2;
    if (s.ph === 'r') return aiRoll(s, p, lv);
    if (s.ph === 'k') return aiKeep(s, p, lv);
    return aiBuild(s, p, lv);
  }
  function aiDelayFor(s, p, lv) {
    const base = s.ph === 'r' ? 650 : s.ph === 'k' ? 700 : 850;
    return base * (lv === 1 ? 1.25 : lv === 3 ? 0.85 : 1);
  }

  /* ======================= view ======================= */
  const TC = { F: '#4f9a4a', G: '#3f86c6', R: '#d9604a', P: '#b8862a', L: '#7b5cc8' };
  const TN = { F: '들판', G: '가게', R: '요금', P: '특별' };
  const numLabel = (B) => B.n.length > 1 ? B.n[0] + '–' + B.n[B.n.length - 1] : String(B.n[0]);
  function fxText(i) {
    const B = BL[i];
    if (B.k === 'F') return '누가 굴려도 +' + B.p;
    if (B.k === 'G') return B.per != null ? '내가 굴리면 ' + BL[B.per].nm + '마다 +' + B.p : '내가 굴리면 +' + B.p;
    if (B.k === 'R') return '남이 굴리면 그 사람에게서 ' + B.p + '원';
    if (i === 14) return '내가 굴리면 모두에게서 2원씩';
    return '내가 굴리면 굴린 주사위마다 +2';
  }
  const esc = (t) => String(t).replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';

  /* ---------- icons (drawn once → data URLs) ---------- */
  const ICON = {};
  function E(g, x, y, rx, ry, col) { g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, 7); g.fillStyle = col; g.fill(); }
  function P(g, pts, col, stroke) { g.beginPath(); pts.forEach((q, k) => (k ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1]))); g.closePath(); if (col) { g.fillStyle = col; g.fill(); } if (stroke) { g.strokeStyle = stroke; g.stroke(); } }
  function R(g, x, y, w, h, r, col) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); g.fillStyle = col; g.fill(); }
  const ICONS = {
    b0(g) { E(g, 32, 54, 24, 6, '#7a5a2a'); for (const x of [18, 32, 46]) { g.strokeStyle = '#9a7a2a'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(x, 54); g.lineTo(x, 20); g.stroke(); for (let k = 0; k < 4; k++) { E(g, x - 4, 22 + k * 7, 3.2, 5, '#e8b93c'); E(g, x + 4, 22 + k * 7, 3.2, 5, '#f2c94c'); } E(g, x, 16, 3, 5, '#f2c94c'); } },
    b1(g) { E(g, 32, 56, 22, 4, 'rgba(0,0,0,.2)'); g.fillStyle = '#3a2d2a'; for (const x of [22, 28, 38, 44]) g.fillRect(x, 42, 3, 13); for (const [x, y, r] of [[22, 34, 9], [32, 30, 10], [42, 34, 9], [28, 40, 8], [38, 40, 8]]) E(g, x, y, r, r, '#f7f3ea'); E(g, 50, 30, 6, 7, '#3a2d2a'); E(g, 52, 29, 1.5, 1.5, '#fff'); },
    b2(g) { g.fillStyle = '#7a4f2a'; g.fillRect(29, 34, 6, 22); E(g, 32, 26, 20, 17, '#4f9a4a'); E(g, 26, 22, 9, 8, '#6cb85e'); for (const [x, y] of [[22, 28], [36, 20], [42, 31], [30, 34], [26, 18]]) { E(g, x, y, 4, 4, '#d9363a'); E(g, x - 1, y - 1.5, 1.2, 1.2, '#ffb0a0'); } },
    b3(g) { for (const [x, s, c] of [[22, 1, '#3e8a48'], [42, 0.9, '#2f7a3e'], [32, 1.15, '#4f9a4a']]) { g.fillStyle = '#6a4626'; g.fillRect(x - 2, 44, 4, 12); P(g, [[x, 8 + (1 - s) * 30], [x + 13 * s, 32], [x - 13 * s, 32]], c); P(g, [[x, 20], [x + 15 * s, 46], [x - 15 * s, 46]], c); } },
    b4(g) { P(g, [[4, 56], [26, 14], [40, 30], [60, 56]], '#7b6f80'); P(g, [[26, 14], [32, 26], [40, 30], [34, 22]], '#988ca0'); g.beginPath(); g.arc(30, 56, 10, Math.PI, 0); g.fillStyle = '#2a2030'; g.fill(); P(g, [[46, 36], [54, 44], [46, 54], [38, 44]], '#5fd4e6'); P(g, [[46, 36], [54, 44], [46, 44]], '#a8f0fa'); },
    b5(g) { g.fillStyle = '#3f86c6'; g.fillRect(4, 48, 56, 12); g.strokeStyle = '#9fd0f5'; g.lineWidth = 2; g.beginPath(); for (let x = 4; x < 60; x += 8) { g.moveTo(x, 50); g.quadraticCurveTo(x + 4, 46, x + 8, 50); } g.stroke(); P(g, [[10, 42], [54, 42], [48, 52], [16, 52]], '#8a5a2b'); g.fillStyle = '#5a3a1a'; g.fillRect(31, 10, 3, 32); P(g, [[34, 12], [52, 38], [34, 38]], '#f7f3ea'); P(g, [[30, 16], [30, 38], [16, 38]], '#e8dcc4'); },
    b6(g) { g.strokeStyle = '#8a5a2b'; g.lineWidth = 3; g.beginPath(); g.moveTo(14, 56); g.lineTo(48, 8); g.stroke(); for (const [k, c] of [[0, '#f29bb5'], [1, '#f7f3ea'], [2, '#8cc56a']]) { const x = 22 + k * 9, y = 44 - k * 12.5; E(g, x, y, 9, 9, c); E(g, x - 3, y - 3, 2.5, 2.5, 'rgba(255,255,255,.6)'); } },
    b7(g) { P(g, [[18, 40], [46, 40], [42, 58], [22, 58]], '#c8693a'); g.fillStyle = '#a5532c'; g.fillRect(16, 38, 32, 5); g.strokeStyle = '#4f9a4a'; g.lineWidth = 2.5; for (const [x, y] of [[22, 20], [32, 14], [42, 22]]) { g.beginPath(); g.moveTo(32, 40); g.lineTo(x, y); g.stroke(); } for (const [x, y, c] of [[22, 20, '#ee6a55'], [32, 14, '#f2c94c'], [42, 22, '#d36be0']]) { for (let a = 0; a < 5; a++) E(g, x + Math.cos(a * 1.26) * 5, y + Math.sin(a * 1.26) * 5, 3.6, 3.6, c); E(g, x, y, 2.6, 2.6, '#fff3c0'); } },
    b8(g) { E(g, 30, 36, 18, 18, '#e48aa8'); g.strokeStyle = '#b8587a'; g.lineWidth = 2; for (const a of [-0.6, 0, 0.6]) { g.beginPath(); g.ellipse(30, 36, 17, 7, a + 0.9, 0, 7); g.stroke(); } g.strokeStyle = '#c9b48a'; g.lineWidth = 3; g.beginPath(); g.moveTo(40, 12); g.lineTo(58, 50); g.stroke(); },
    b9(g) { R(g, 18, 18, 28, 38, 7, '#f0e6e6'); R(g, 20, 28, 24, 26, 5, '#c62f45'); R(g, 16, 12, 32, 9, 3, '#d9a441'); R(g, 23, 34, 18, 10, 2, '#fff7e0'); E(g, 32, 39, 3.5, 3.5, '#d9363a'); },
    b10(g) { R(g, 8, 44, 48, 9, 2, '#c99a5c'); g.fillStyle = '#8a6a3a'; for (let x = 12; x < 56; x += 10) g.fillRect(x, 44, 1.5, 9); P(g, [[14, 14], [50, 30], [46, 38], [10, 22]], '#c8ccd4'); g.fillStyle = '#7a808c'; for (let k = 0; k < 7; k++) P(g, [[12 + k * 5.2, 22 + k * 2.3], [15 + k * 5.2, 27 + k * 2.3], [17 + k * 5.2, 23 + k * 2.3]], '#7a808c'); R(g, 4, 6, 14, 14, 4, '#b5652c'); },
    b11(g) { P(g, [[44, 32], [60, 20], [60, 44]], '#3f86c6'); E(g, 30, 32, 22, 13, '#5aa2dc'); E(g, 28, 36, 18, 7, '#9fd0f5'); E(g, 16, 29, 3, 3, '#fff'); E(g, 16, 29, 1.5, 1.5, '#222'); g.strokeStyle = '#2f6aa0'; g.lineWidth = 1.5; g.beginPath(); g.arc(24, 32, 9, -1, 1); g.stroke(); },
    b12(g) { g.strokeStyle = '#c9a66b'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(36, 8); g.lineTo(28, 36); g.moveTo(44, 10); g.lineTo(32, 36); g.stroke(); g.beginPath(); g.arc(32, 34, 24, 0, Math.PI); g.fillStyle = '#d9604a'; g.fill(); R(g, 6, 32, 52, 5, 2, '#f0d7a0'); g.strokeStyle = '#f7e6b0'; g.lineWidth = 2; for (const x of [18, 28, 38, 48]) { g.beginPath(); g.moveTo(x, 30); g.quadraticCurveTo(x + 4, 24, x, 18); g.stroke(); } },
    b13(g) { R(g, 10, 8, 44, 44, 9, '#3f86c6'); R(g, 13, 11, 38, 38, 7, '#2f6fb0'); g.fillStyle = '#fff'; g.font = '900 34px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('P', 32, 32); g.fillStyle = '#777'; g.fillRect(30, 52, 4, 10); },
    b14(g) { P(g, [[32, 8], [58, 46], [6, 46]], '#e05a4a'); for (let k = 0; k < 3; k++) P(g, [[32, 8], [14 + k * 16, 46], [22 + k * 16, 46]], '#f7f3ea'); R(g, 6, 44, 52, 12, 2, '#b8862a'); P(g, [[26, 56], [32, 46], [38, 56]], '#3a1f2a'); g.strokeStyle = '#3a2d2a'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(32, 8); g.lineTo(32, 1); g.stroke(); P(g, [[32, 1], [42, 4], [32, 7]], '#f2c94c'); },
    b15(g) { P(g, [[6, 22], [32, 8], [58, 22]], '#c9b48a'); R(g, 8, 50, 48, 6, 1, '#b8a070'); g.fillStyle = '#e6d6b0'; for (const x of [12, 24, 36, 48]) g.fillRect(x, 24, 5, 26); R(g, 24, 28, 17, 17, 4, '#f7f3ea'); E(g, 28, 32, 1.8, 1.8, '#222'); E(g, 32.5, 36.5, 1.8, 1.8, '#222'); E(g, 37, 41, 1.8, 1.8, '#222'); },
    L0(g) { E(g, 32, 56, 22, 4, 'rgba(0,0,0,.25)'); P(g, [[32, 4], [56, 22], [56, 40], [32, 58], [8, 40], [8, 22]], '#a83a2c'); P(g, [[32, 10], [52, 24], [52, 38], [32, 52], [12, 38], [12, 24]], '#e0664f'); g.fillStyle = '#fff'; g.font = '800 20px ' + MONO; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('12', 32, 32); },
    L1(g) { for (let k = 0; k < 4; k++) { E(g, 32, 50 - k * 9, 20, 7, '#a8761c'); E(g, 32, 47 - k * 9, 20, 7, k === 3 ? '#ffd76a' : '#e3ae45'); } g.fillStyle = '#a8761c'; g.font = '800 10px ' + MONO; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('₩', 32, 20); },
    L2(g) { for (const x of [20, 44]) { R(g, x - 8, 16, 16, 42, 2, '#9a8ab8'); P(g, [[x - 10, 18], [x, 4], [x + 10, 18]], '#5a4a88'); g.fillStyle = '#f2e9a8'; g.fillRect(x - 3, 26, 6, 7); g.fillRect(x - 3, 40, 6, 7); } g.strokeStyle = '#c9b48a'; g.lineWidth = 3; g.beginPath(); g.moveTo(28, 36); g.lineTo(36, 36); g.stroke(); },
    L3(g) { R(g, 12, 34, 40, 24, 3, '#8a7aa8'); g.beginPath(); g.arc(32, 34, 20, Math.PI, 0); g.fillStyle = '#b8aad0'; g.fill(); g.save(); g.translate(32, 30); g.rotate(-0.5); g.fillStyle = '#3a2d4a'; g.fillRect(-3, -16, 7, 14); g.restore(); const st = (x, y, r) => { g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? r * 0.45 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } g.closePath(); g.fillStyle = '#ffd76a'; g.fill(); }; st(50, 10, 8); st(14, 14, 4); },
    L4(g) { E(g, 32, 52, 22, 7, '#5a5068'); R(g, 10, 36, 44, 16, 3, '#8a8098'); g.fillStyle = '#6a6078'; for (let x = 12; x < 52; x += 9) g.fillRect(x, 36, 1.5, 16); E(g, 32, 37, 21, 5, '#2a3a6a'); g.strokeStyle = '#6a4626'; g.lineWidth = 3; g.beginPath(); g.moveTo(14, 36); g.lineTo(14, 12); g.moveTo(50, 36); g.lineTo(50, 12); g.stroke(); P(g, [[8, 14], [32, 2], [56, 14]], '#b5652c'); R(g, 28, 18, 8, 8, 2, '#c9a66b'); },
  };
  function iconURL(key) {
    if (ICON[key]) return ICON[key];
    try {
      const c = document.createElement('canvas'); c.width = c.height = 128;
      const g = c.getContext('2d'); g.scale(2, 2); g.lineCap = 'round'; g.lineJoin = 'round';
      if (ICONS[key]) ICONS[key](g); else if (key[0] === 'd') drawDie(g, key.slice(1), 32, 30, 40, 0, key[1] === 'T' ? [5, 2] : key[1] === 'C' ? 2 : key[1] === 'X' ? 0 : key[1] === 'B' ? 12 : key[1] === 'S' ? 4 : 6, {});
      ICON[key] = c.toDataURL();
    } catch (e) { ICON[key] = ''; }
    return ICON[key];
  }

  /* ---------- dice drawing (shared by tray + buttons) ---------- */
  const PIPS = { 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] };
  const DSTY = {
    S: { face: '#3fb3a6', face2: '#2a8f84', side: '#1d6a62', ink: '#fff' },
    M: { face: '#fffaf0', face2: '#e9dfc9', side: '#b9a987', ink: '#21161f' },
    B: { face: '#ee7a5f', face2: '#d9563e', side: '#9a3526', ink: '#fff' },
    T: { face: '#cfe2ff', face2: '#9fbfef', side: '#5f7fb8', ink: '#1a2a4a' },
    C: { face: '#ffd76a', face2: '#e3ae45', side: '#a8761c', ink: '#6a4508' },
    X: { face: '#9b7be0', face2: '#6f50c0', side: '#432d85', ink: '#fff6c8' },
  };
  function diePath(g, kind, s) {
    const h = s / 2;
    g.beginPath();
    if (kind === 'S') { g.moveTo(0, -h * 1.05); g.lineTo(h * 1.05, h * 0.8); g.lineTo(-h * 1.05, h * 0.8); g.closePath(); }
    else if (kind === 'B') { g.moveTo(0, -h * 1.05); g.lineTo(h, -h * 0.42); g.lineTo(h, h * 0.42); g.lineTo(0, h * 1.05); g.lineTo(-h, h * 0.42); g.lineTo(-h, -h * 0.42); g.closePath(); }
    else if (g.roundRect) g.roundRect(-h, -h, s, s, s * 0.2); else g.rect(-h, -h, s, s);
  }
  function starShape(g, x, y, r) { g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? r * 0.45 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } g.closePath(); }
  // face: number (S/M/B/T one die), C: coin face index, X: star face index; o: {alpha, lift, squash, glow}
  function drawDie(g, kind, x, y, s, rot, face, o) {
    o = o || {};
    if (kind === 'T' && Array.isArray(face)) { drawDie(g, 'T', x - s * 0.36, y, s * 0.68, rot - 0.12, face[0], o); drawDie(g, 'T', x + s * 0.36, y + s * 0.06, s * 0.68, rot + 0.15, face[1], o); return; }
    const st = DSTY[kind], lift = o.lift || 0, dep = s * 0.1;
    g.save();
    if (o.alpha != null) g.globalAlpha = o.alpha;
    // shadow on the felt
    g.save(); g.translate(x + 2 + lift * 0.25, y + s * 0.42 + lift * 0.1); g.scale(1, 0.35); g.beginPath(); g.arc(0, 0, s * 0.5 * (1 - Math.min(0.4, lift / (s * 3))), 0, 7); g.fillStyle = 'rgba(0,0,0,.35)'; g.fill(); g.restore();
    g.translate(x, y - lift); g.rotate(rot || 0);
    if (o.squash) g.scale(1 + o.squash, 1 - o.squash);
    // extruded body
    g.save(); g.translate(0, dep); diePath(g, kind, s); g.fillStyle = st.side; g.fill(); g.restore();
    diePath(g, kind, s);
    const gr = g.createLinearGradient(-s / 2, -s / 2, s / 2, s / 2); gr.addColorStop(0, st.face); gr.addColorStop(1, st.face2);
    g.fillStyle = gr; g.fill();
    if (o.glow) { g.lineWidth = 3; g.strokeStyle = '#ffd76a'; g.stroke(); } else { g.lineWidth = 1; g.strokeStyle = 'rgba(0,0,0,.25)'; g.stroke(); }
    // top-left gloss
    g.save(); diePath(g, kind, s); g.clip(); g.fillStyle = 'rgba(255,255,255,.22)'; g.beginPath(); g.ellipse(-s * 0.2, -s * 0.32, s * 0.42, s * 0.16, -0.5, 0, 7); g.fill(); g.restore();
    g.fillStyle = st.ink; g.textAlign = 'center'; g.textBaseline = 'middle';
    if (kind === 'M' || kind === 'T') {
      const v = U.clamp(face | 0, 1, 6);
      (PIPS[v] || []).forEach(([px, py]) => { g.beginPath(); g.arc(px * s * 0.25, py * s * 0.25, v === 1 ? s * 0.12 : s * 0.085, 0, 7); g.fillStyle = v === 1 && kind === 'M' ? '#b8321f' : st.ink; g.fill(); });
    } else if (kind === 'S') {
      g.font = '800 ' + Math.round(s * 0.42) + 'px ' + MONO; g.fillText(String(face), 0, s * 0.14);
    } else if (kind === 'B') {
      g.font = '800 ' + Math.round(s * (face >= 10 ? 0.42 : 0.5)) + 'px ' + MONO; g.fillText(String(face), 0, s * 0.03);
    } else if (kind === 'C') {
      const k = COIN[face] != null ? COIN[face] : 0;
      if (!k) { g.font = '800 ' + Math.round(s * 0.4) + 'px ' + MONO; g.globalAlpha *= 0.6; g.fillText('0', 0, s * 0.03); }
      else for (let j = 0; j < k; j++) { const cx = (j - (k - 1) / 2) * s * 0.26, cy = (j % 2 ? 0.08 : -0.06) * s; g.beginPath(); g.arc(cx, cy, s * 0.15, 0, 7); g.fillStyle = '#a8761c'; g.fill(); g.beginPath(); g.arc(cx, cy, s * 0.1, 0, 7); g.fillStyle = '#ffe9a8'; g.fill(); }
    } else if (kind === 'X') {
      const f = face | 0;
      if (f <= 1) { g.font = '900 ' + Math.round(s * 0.42) + 'px ' + MONO; g.fillText('×2', 0, s * 0.03); }
      else if (f === 2) { g.beginPath(); g.moveTo(-s * 0.3, -s * 0.16); g.lineTo(s * 0.18, -s * 0.16); g.lineTo(s * 0.32, 0); g.lineTo(s * 0.18, s * 0.16); g.lineTo(-s * 0.3, s * 0.16); g.closePath(); g.fillStyle = st.ink; g.fill(); g.fillStyle = '#5a3a9a'; g.font = '800 ' + Math.round(s * 0.24) + 'px ' + MONO; g.fillText('-3', -s * 0.04, s * 0.01); }
      else if (f === 3) { g.beginPath(); g.moveTo(s * 0.08, -s * 0.36); g.lineTo(-s * 0.2, s * 0.04); g.lineTo(-s * 0.01, s * 0.04); g.lineTo(-s * 0.1, s * 0.36); g.lineTo(s * 0.22, -s * 0.06); g.lineTo(s * 0.02, -s * 0.06); g.closePath(); g.fillStyle = '#ffd76a'; g.fill(); }
      else if (f === 4) { starShape(g, 0, 0, s * 0.3); g.lineWidth = 2; g.strokeStyle = 'rgba(255,246,200,.6)'; g.stroke(); }
      else { for (const [cx, cy, r] of [[-s * 0.14, s * 0.04, s * 0.15], [s * 0.1, -s * 0.04, s * 0.19], [s * 0.2, s * 0.08, s * 0.12]]) { g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fillStyle = '#4a4458'; g.fill(); } g.fillRect(-s * 0.26, s * 0.06, s * 0.52, s * 0.12); }
    }
    g.restore();
  }

  const CSS = `
.dt-root{position:absolute;inset:0;display:flex;flex-direction:column;gap:6px;padding:8px 10px 10px;box-sizing:border-box;font-family:var(--f-body);color:var(--ink);background:radial-gradient(120% 70% at 50% 0%,#2c2140 0%,#17131f 70%)}
.dt-root *{box-sizing:border-box}
.dt-players{display:flex;gap:5px;flex:none}
.dt-pl{flex:1 1 0;min-width:0;min-height:46px;border-radius:12px;background:var(--surface);border:1.5px solid var(--line);padding:3px 6px;display:flex;flex-direction:column;justify-content:center;gap:2px;cursor:pointer;color:inherit;font:inherit;text-align:left;position:relative;transition:background .15s}
.dt-pl.cur{border-color:var(--brass)}
.dt-pl.view{background:var(--surface-2);box-shadow:inset 0 -3px 0 var(--pc)}
.dt-pl .nm{font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:4px;min-width:0}
.dt-pl .nm span:last-child{overflow:hidden;text-overflow:ellipsis}
.dt-pl .r2{display:flex;align-items:center;gap:3px;font-family:var(--f-mono);font-size:13px;font-weight:700}
.dt-pips{display:flex;gap:2px;margin-left:auto}.dt-pips i{width:5px;height:9px;border-radius:2px;background:rgba(255,255,255,.16)}.dt-pips i.on{background:#b48cff}
.dt-coin{display:inline-block;width:12px;height:12px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#ffe9a8,#e3ae45 55%,#a8761c);box-shadow:inset 0 0 0 1.5px rgba(120,80,10,.55);flex:none;vertical-align:-1px}
.dt-bub{position:absolute;left:50%;top:-4px;transform:translateX(-50%);font-family:var(--f-mono);font-weight:800;font-size:14px;padding:1px 7px;border-radius:999px;pointer-events:none;animation:dtBub 1.5s ease-out forwards;z-index:5;white-space:nowrap}
.dt-bub.pos{background:#e3ae45;color:#2a1a05}.dt-bub.neg{background:#ee6a55;color:#2b0c06}
@keyframes dtBub{0%{opacity:0;transform:translate(-50%,6px) scale(.7)}15%{opacity:1;transform:translate(-50%,-6px) scale(1.1)}70%{opacity:1;transform:translate(-50%,-14px)}100%{opacity:0;transform:translate(-50%,-22px)}}
.dt-town{flex:1 1 auto;min-height:0;overflow-y:auto;touch-action:pan-y;background:linear-gradient(#2a2137,#211a2c);border-radius:14px;border:1px solid var(--line);padding:7px 8px 8px;display:flex;flex-direction:column;gap:7px}
.dt-th{display:flex;align-items:center;gap:6px;min-height:28px}
.dt-th b{font-family:var(--f-display);font-weight:400;font-size:17px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.dt-th .sp{flex:1}
.dt-th .btn{min-height:44px;padding:4px 12px;font-size:12.5px}
.dt-lms{display:grid;grid-template-columns:repeat(5,1fr);gap:5px}
.dt-lm{border-radius:10px;min-height:50px;background:rgba(255,255,255,.035);border:1px dashed rgba(255,255,255,.2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;font-size:10px;color:var(--muted);cursor:pointer;padding:2px;font-family:var(--f-mono);font-weight:700}
.dt-lm img{width:28px;height:28px;filter:grayscale(1);opacity:.5}
.dt-lm.on{border:1px solid #b48cff;background:linear-gradient(#4f3a80,#33264f);color:#e8dcff}
.dt-lm.on img{filter:none;opacity:1}
.dt-lm.flash,.dt-mini.flash{animation:dtFlash 1.2s ease-out}
@keyframes dtFlash{0%,40%{box-shadow:0 0 0 3px #ffd76a,0 0 18px #ffd76a}100%{box-shadow:0 0 0 0 transparent}}
.dt-bgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(76px,1fr));gap:5px}
.dt-mini{display:flex;align-items:center;gap:3px;border-radius:9px;background:#f3e8d2;color:#2a1f18;height:44px;padding:0 6px 0 0;overflow:hidden;position:relative;cursor:pointer;border:0;font:inherit;text-align:left}
.dt-mini .num{align-self:stretch;min-width:22px;padding:0 3px;display:grid;place-items:center;font-family:var(--f-mono);font-weight:800;font-size:13px;color:#fff;background:var(--tc)}
.dt-mini img{width:28px;height:28px;flex:none}
.dt-mini .cnt{font-family:var(--f-mono);font-weight:800;font-size:13px;margin-left:auto}
.dt-mini.hit{box-shadow:0 0 0 2px #ffd76a}
.dt-tray{flex:none;height:clamp(88px,15%,128px);position:relative;border-radius:14px;overflow:hidden;box-shadow:inset 0 0 0 3px #5a3a22,inset 0 0 0 5px #3a2416}
.dt-tray canvas{position:absolute;inset:0;width:100%;height:100%}
.dt-rcpt{position:absolute;left:6px;right:6px;bottom:4px;display:flex;justify-content:center;gap:8px;flex-wrap:nowrap;overflow:hidden;font-size:12px;font-weight:700;pointer-events:none;white-space:nowrap}
.dt-rcpt>span{background:rgba(10,8,15,.6);border-radius:999px;padding:1px 7px;display:inline-flex;align-items:center;gap:4px}
.dt-panel{flex:none;display:flex;flex-direction:column;gap:6px}
.dt-dice{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}
.dt-dbtn{min-height:52px;border-radius:12px;border:1.5px solid var(--line);background:var(--surface-2);color:var(--ink);display:flex;align-items:center;gap:3px;padding:2px 4px;font:inherit;cursor:pointer;text-align:left;min-width:0;position:relative}
.dt-dbtn img{width:26px;height:26px;flex:none}
.dt-dbtn .t{font-size:11.5px;font-weight:700;line-height:1.2;white-space:nowrap}
.dt-dbtn .rg{font-family:var(--f-mono);font-size:11px;font-weight:700;line-height:1.2;white-space:nowrap;color:#d8c9e8}
.dt-dbtn .ev{font-family:var(--f-mono);font-size:11px;line-height:1.2;color:var(--muted);white-space:nowrap}
.dt-dbtn.on{border-color:var(--brass);background:#4a3a22;box-shadow:0 0 0 1px var(--brass) inset}
.dt-dbtn.on .ev{color:var(--brass)}
.dt-dbtn.lock{opacity:.38}
.dt-dbtn .lk{position:absolute;top:2px;right:4px;font-size:9px;color:var(--muted)}
.dt-add{display:grid;grid-template-columns:auto 1fr 1fr 1fr;gap:5px;align-items:center}
.dt-add .lb{font-size:12px;color:var(--muted);padding:0 2px;line-height:1.1}
.dt-add .dt-dbtn{min-height:44px;justify-content:center}
.dt-add .dt-dbtn img{width:24px;height:24px}
.dt-strip{display:flex;gap:2px;height:44px}
.dt-cell{flex:1;min-width:0;border-radius:6px;background:rgba(255,255,255,.05);position:relative;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:2px 0 3px;overflow:hidden}
.dt-cell .bar{position:absolute;left:0;right:0;bottom:0;background:rgba(227,174,69,.2)}
.dt-cell .v{font-family:var(--f-mono);font-size:11px;color:var(--muted);position:relative}
.dt-cell .g{font-family:var(--f-mono);font-weight:800;font-size:13px;position:relative;letter-spacing:-.5px}
.dt-cell .g.pos{color:#a6e38a}.dt-cell .g.neg{color:#ff8a76}.dt-cell .g.zero{color:rgba(255,255,255,.25)}
.dt-line{display:flex;align-items:center;gap:6px;font-size:13px;min-height:22px;color:var(--muted);min-width:0}
.dt-line b{color:var(--ink)}
.dt-line .txt{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1}
.dt-row{display:flex;gap:6px}
.dt-row .btn{flex:1;min-height:50px;font-size:15px}
.dt-big{min-height:54px!important;font-size:17px!important}
.dt-rec{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted)}
.dt-rec .btn{min-height:44px;font-size:13px;padding:4px 10px;flex:none}
.dt-tag{font-size:11px;border-radius:999px;padding:1px 7px;background:#6f50c0;color:#fff;font-weight:700;white-space:nowrap}
.dt-mk{position:absolute;inset:0;z-index:15;background:rgba(16,12,22,.97);display:flex;flex-direction:column;animation:fade .15s}
.dt-mkh{display:flex;align-items:center;gap:8px;padding:8px 10px 6px}
.dt-mkh h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:22px}
.dt-mkh .sp{flex:1}
.dt-mkh .money{font-family:var(--f-mono);font-weight:800;font-size:16px;display:flex;align-items:center;gap:4px}
.dt-mkb{flex:1;min-height:0;overflow-y:auto;touch-action:pan-y;padding:0 10px 10px}
.dt-sec{font-size:12px;color:var(--muted);margin:10px 2px 6px;display:flex;align-items:center;gap:6px;font-weight:700}
.dt-sec i{width:10px;height:10px;border-radius:3px;background:var(--tc);flex:none}
.dt-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:7px}
.dt-card{border-radius:12px;background:#f6ecd9;color:#2a1f18;overflow:hidden;display:flex;flex-direction:column;cursor:pointer;border:0;outline:2px solid transparent;position:relative;min-height:148px;font:inherit;padding:0;text-align:center}
.dt-card .band{background:var(--tc);color:#fff;display:flex;align-items:center;justify-content:space-between;padding:2px 7px;font-size:10px;font-weight:700;width:100%}
.dt-card .band .n{font-family:var(--f-mono);font-size:15px;font-weight:800}
.dt-card img{width:42px;height:42px;margin:3px auto 0;display:block}
.dt-card .nm{font-weight:800;font-size:13px;line-height:1.15;padding:0 3px}
.dt-card .fx{font-size:10.5px;line-height:1.25;color:#5b4a3c;padding:1px 4px 0;flex:1;word-break:keep-all}
.dt-card .ft{display:flex;align-items:center;justify-content:space-between;padding:3px 6px 4px;font-size:10.5px;color:#6b5a4a;width:100%}
.dt-card .cost{font-family:var(--f-mono);font-weight:800;font-size:13px;display:flex;align-items:center;gap:3px;color:#2a1f18}
.dt-card .cost s{opacity:.5;font-size:11px}
.dt-card .evh{font-family:var(--f-mono);font-size:10px;color:#2f7a3e;font-weight:700}
.dt-card.no{opacity:.42}
.dt-card.sel{outline-color:var(--brass);box-shadow:0 0 0 4px rgba(227,174,69,.35)}
.dt-card .tag{position:absolute;top:24px;right:4px;font-size:10px;background:#2a1f18;color:#f6ecd9;border-radius:6px;padding:1px 5px;font-weight:700}
.dt-card .tag.ok{background:#4f9a4a;color:#fff}
.dt-card .tag.rec{background:#e3ae45;color:#2a1a05;left:4px;right:auto}
.dt-mkf{padding:8px 10px 10px;border-top:1px solid var(--line);display:flex;flex-direction:column;gap:6px;background:var(--surface)}
.dt-mkf .info{font-size:12.5px;color:var(--muted);min-height:18px;line-height:1.35}
.dt-mkf .info b{color:var(--ink)}
`;

  function mount(root, api) {
    const h = L.h;
    const style = h('style', { text: CSS });
    const el = h('div', { class: 'dt-root' });
    root.append(style, el);
    const plBar = h('div', { class: 'dt-players' });
    const town = h('div', { class: 'dt-town' });
    const tray = h('div', { class: 'dt-tray' });
    const panel = h('div', { class: 'dt-panel' });
    el.append(plBar, town, tray, panel);
    const tcv = h('canvas'); const rcpt = h('div', { class: 'dt-rcpt' });
    tray.append(tcv, rcpt);
    const tctx = tcv.getContext('2d');
    let TW = 1, TH = 1, dpr = 1;
    const ro = new ResizeObserver(() => { fitTray(); drawTray(); });
    ro.observe(tray);
    function fitTray() {
      const r = tray.getBoundingClientRect(); dpr = Math.min(2.5, window.devicePixelRatio || 1);
      TW = Math.max(1, Math.round(r.width)); TH = Math.max(1, Math.round(r.height));
      tcv.width = Math.round(TW * dpr); tcv.height = Math.round(TH * dpr); feltImg = null;
    }

    let st = null, pend = false, pendT = 0, pinned = null, pinTurn = -1, shown = '', mkSel = null, mkView = false;
    let autoPin = null, autoT = 0, mySel = null, selTurn = '', anim = null, stopLoop = null, busyT = 0, watchdog = 0, hitSum = -1, flashKey = null;
    const N = () => (st ? st.n : 1);
    const nm = (i) => (api.players[i] && api.players[i].name) || (st && st.nm[i]) || (i + 1) + '번';
    const col = (i) => (api.players[i] && api.players[i].color) || '#e3ae45';
    const mine = (i) => api.canAct(i);
    const localHumans = () => { let k = 0; for (let i = 0; i < N(); i++) if (mine(i)) k++; return k; };
    const meName = (i) => (localHumans() === 1 && mine(i) ? '나' : nm(i));

    // one toast at a time (core toasts stack on top of each other)
    let toastAt = 0, toastQ = [], toastT = 0;
    function say(text, now) {
      if (now) { toastQ = []; clearTimeout(toastT); toastAt = Date.now(); api.toast(text, 1600); return; }
      toastQ.push(text); if (toastQ.length > 2) toastQ.shift();
      pump();
    }
    function pump() {
      clearTimeout(toastT);
      if (!toastQ.length) return;
      const wait = toastAt + 1500 - Date.now();
      if (wait > 0) { toastT = setTimeout(pump, wait); return; }
      toastAt = Date.now(); api.toast(toastQ.shift(), 1450);
      if (toastQ.length) toastT = setTimeout(pump, 1500);
    }
    function act(a) {
      if (pend) return;
      pend = true; clearTimeout(pendT); pendT = setTimeout(() => { pend = false; render(); }, 2500);
      api.buzz(10); api.act(a);
    }

    /* ---------- players bar ---------- */
    function renderPlayers() {
      plBar.innerHTML = '';
      if (!st) return;
      const cur = actor(st), vs = viewSeat();
      for (let i = 0; i < st.n; i++) {
        const pips = h('span', { class: 'dt-pips' });
        for (let k = 0; k < 5; k++) pips.append(h('i', { class: hasL(st, i, k) ? 'on' : '' }));
        const b = h('button', { class: 'dt-pl' + (cur === i ? ' cur' : '') + (vs === i ? ' view' : ''), style: { '--pc': col(i) }, 'aria-label': nm(i) + '의 마을 보기',
          onclick() { pinned = pinned === i && i !== actor(st) ? null : i; pinTurn = st.tn; api.sfx('click'); renderPlayers(); renderTown(); } },
          h('div', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': col(i), flex: 'none' } }), h('span', { text: meName(i) })),
          h('div', { class: 'r2' }, h('span', { class: 'dt-coin' }), h('span', { text: String(st.c[i]) }),
            st.n === 1 ? h('span', { class: 'muted', style: { fontSize: '12px', marginLeft: '8px', fontFamily: 'var(--f-body)' }, text: '턴 ' + Math.min(SOLO_LIMIT, st.tn + 1) + '/' + SOLO_LIMIT + ' · ★★★는 ' + SOLO_STARS[0] + '턴 안에' }) : null, pips));
        b.dataset.seat = i;
        plBar.append(b);
      }
    }
    function bubble(i, d) {
      const b = plBar.querySelector('[data-seat="' + i + '"]'); if (!b || !d) return;
      const e = h('span', { class: 'dt-bub ' + (d > 0 ? 'pos' : 'neg'), text: (d > 0 ? '+' : '−') + Math.abs(d) });
      b.append(e); setTimeout(() => e.remove(), 1600);
    }

    /* ---------- town ---------- */
    function viewSeat() {
      if (!st) return 0;
      if (pinned != null && pinned < st.n && pinTurn === st.tn) return pinned;
      pinned = null;
      if (autoPin && autoPin.until > Date.now() && autoPin.seat < st.n) return autoPin.seat;
      return st.end ? (st.win >= 0 ? st.win : 0) : st.t;
    }
    function renderTown() {
      town.innerHTML = '';
      if (!st) return;
      const v = viewSeat();
      const head = h('div', { class: 'dt-th' },
        h('span', { class: 'dot', style: { '--c': col(v), flex: 'none' } }),
        h('b', { text: (localHumans() === 1 && mine(v) ? '내' : nm(v) + '의') + ' 마을' }),
        h('span', { class: 'muted', style: { fontSize: '12px', whiteSpace: 'nowrap' }, text: '랜드마크 ' + lmCount(st, v) + '/5' }),
        h('span', { class: 'sp' }),
        h('button', { class: 'btn sm ghost dt-mkbtn', text: '시장 보기', onclick() { openMarket(true); } }));
      const lms = h('div', { class: 'dt-lms' });
      for (let i = 0; i < 5; i++) {
        const on = hasL(st, v, i);
        const t = h('button', { class: 'dt-lm' + (on ? ' on' : '') + (flashKey === 'l' + v + ':' + i ? ' flash' : ''), 'aria-label': LM[i].nm, onclick() { say(LM[i].nm + (on ? ' ✓ · ' : ' (' + LM[i].c + '원) · ') + LM[i].fx, true); } },
          h('img', { src: iconURL('L' + i), alt: '' }), h('span', { text: on ? '완성' : LM[i].c + '원' }));
        lms.append(t);
      }
      const grid = h('div', { class: 'dt-bgrid' });
      for (let i = 0; i < NB; i++) {
        const k = st.b[v][i]; if (!k) continue;
        const B = BL[i];
        const hit = hitSum >= 0 && B.n.includes(hitSum);
        grid.append(h('button', { class: 'dt-mini' + (hit ? ' hit' : '') + (flashKey === 'b' + v + ':' + i ? ' flash' : ''), style: { '--tc': TC[B.k] }, 'aria-label': B.nm, onclick() { say(B.nm + ' [' + numLabel(B) + '] ' + fxText(i), true); } },
          h('span', { class: 'num', text: numLabel(B) }), h('img', { src: iconURL('b' + i), alt: '' }), h('span', { class: 'cnt', text: '×' + k })));
      }
      town.append(head, lms, grid);
    }

    /* ---------- tray (dice) ---------- */
    let feltImg = null;
    function felt() {
      if (feltImg) return feltImg;
      const c = document.createElement('canvas'); c.width = tcv.width; c.height = tcv.height;
      const g = c.getContext('2d');
      const gr = g.createRadialGradient(c.width / 2, c.height * 0.4, 10, c.width / 2, c.height / 2, c.width * 0.7);
      gr.addColorStop(0, '#227a5e'); gr.addColorStop(1, '#0f3f30');
      g.fillStyle = gr; g.fillRect(0, 0, c.width, c.height);
      let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      for (let k = 0; k < (c.width * c.height) / 90; k++) { g.fillStyle = rnd() < 0.5 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.08)'; g.fillRect(rnd() * c.width, rnd() * c.height, 1.5, 1.5); }
      feltImg = c; return c;
    }
    function trayDice() { // what to show at rest: [{kind, face, x, y, s}]
      const r = st && st.roll ? st.roll : st && st.last && st.last.r ? st.last.r : null;
      let list = [];
      if (anim) return anim.dice;
      const myTurn = st && !st.end && st.ph === 'r' && mine(st.t) && mySel;
      if (myTurn) list = selKinds(mySel).map((k) => ({ kind: k, face: sampleFace(k), ghost: true }));
      else if (r && (st.ph !== 'r' || (st.last && st.last.k !== 'b' && st.last.k !== 'l' && st.last.k !== 'p'))) list = rollKinds(r);
      return place(list);
    }
    const sampleFace = (k) => (k === 'S' ? 4 : k === 'M' ? 6 : k === 'B' ? 12 : k === 'T' ? [5, 2] : k === 'C' ? 5 : 0);
    function selKinds(sel) { const o = [sel.n]; if (sel.c) o.push('C'); if (sel.x) o.push('X'); return o; }
    function rollKinds(r) {
      const o = [];
      if (r.n === 'T') o.push({ kind: 'T', face: r.v[0] }, { kind: 'T', face: r.v[1] }); else o.push({ kind: r.n, face: r.v[0] });
      if (r.c >= 0) o.push({ kind: 'C', face: r.c });
      if (r.x >= 0) o.push({ kind: 'X', face: r.x });
      return o;
    }
    function place(list) {
      const out = [];
      const k = list.length; if (!k) return out;
      const s = Math.max(12, Math.min(50, TH * 0.52, (TW - 80) / (k * 1.35)));
      const gap = s * 1.35, x0 = TW / 2 - ((k - 1) * gap) / 2 - (sumLabel() ? 26 : 0);
      list.forEach((d, j) => {
        if (d.kind === 'T' && Array.isArray(d.face)) out.push(Object.assign({}, d, { x: x0 + j * gap, y: TH * 0.42, s: s * 1.2 }));
        else out.push(Object.assign({}, d, { x: x0 + j * gap, y: TH * 0.42, s }));
      });
      return out;
    }
    function sumLabel() {
      if (anim && !anim.done) return '';
      if (!st) return '';
      const r = st.roll || (st.last && st.last.r);
      if (!r || (st.ph === 'r' && !st.end && mine(st.t))) return '';
      if (st.ph === 'r' && st.last && (st.last.k === 'b' || st.last.k === 'l' || st.last.k === 'p')) return '';
      return String(rollSum(r));
    }
    function drawTray() {
      const g = tctx;
      if (TW < 40 || TH < 30) return;
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.drawImage(felt(), 0, 0);
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (!st) return;
      const dice = trayDice();
      for (const d of dice) drawDie(g, d.kind, d.x, d.y, d.s, d.rot || 0, d.face, { alpha: d.ghost ? 0.55 : 1, lift: d.lift || 0, squash: d.squash || 0, glow: !!d.glow });
      const sl = sumLabel();
      if (sl) {
        g.font = '800 30px ' + MONO; g.textAlign = 'right'; g.textBaseline = 'middle';
        g.fillStyle = 'rgba(0,0,0,.35)'; g.fillText(sl, TW - 14, TH * 0.42 + 2);
        g.fillStyle = '#ffd76a'; g.fillText(sl, TW - 16, TH * 0.42);
        g.font = '700 10px ' + FONT; g.fillStyle = 'rgba(255,255,255,.6)'; g.fillText('나온 수', TW - 16, TH * 0.42 - 24);
      }
      if (!dice.length) {
        g.font = '700 13px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = 'rgba(255,255,255,.5)';
        g.fillText(st.end ? '게임 끝' : nm(st.t) + ' 차례', TW / 2, TH * 0.42);
      }
    }
    function startRollAnim(last) {
      const fin = place(rollKinds(last.r));
      const dice = fin.map((d, j) => ({ kind: d.kind, face: d.face, fx: d.x, fy: d.y, s: d.s, x: -40 - j * 30, y: TH * 0.3, rot: 0, spin: (Math.random() < 0.5 ? -1 : 1) * (8 + Math.random() * 6), delay: j * 0.06, lift: 0, final: d.face }));
      anim = { t: 0, dur: 0.95, dice, last, bounced: 0, done: false };
      api.sfx('roll'); api.setBusy(true); busyFlag = true;
      clearTimeout(watchdog);
      watchdog = setTimeout(() => finishAnim(), 2600 / Math.max(0.2, L.debug.speed) + 800);
      if (stopLoop) stopLoop();
      stopLoop = U.loop((dt) => {
        if (!anim) return;
        anim.t += dt * (L.debug.speed || 1);
        let allDone = true;
        for (const d of anim.dice) {
          const u = U.clamp((anim.t - d.delay) / (anim.dur - d.delay), 0, 1);
          if (u < 1) allDone = false;
          const e = 1 - Math.pow(1 - u, 3);
          d.x = U.lerp(-30, d.fx, e);
          const hop = Math.abs(Math.sin(u * Math.PI * 2.5)) * (1 - u) * TH * 0.45;
          d.lift = hop; d.y = d.fy;
          d.rot = (1 - e) * d.spin;
          d.squash = hop < 2 && u < 0.95 ? 0.08 * (1 - u) : 0;
          if (u < 0.82) { if (Math.random() < 0.35) d.face = randFace(d.kind); } else d.face = d.final;
        }
        const b = Math.floor(anim.t / 0.25);
        if (b > anim.bounced && anim.t < anim.dur) { anim.bounced = b; api.sfx('bounce'); }
        drawTray();
        if (allDone) finishAnim();
      });
    }
    const randFace = (k) => (k === 'S' ? 1 + U.rand(4) : k === 'B' ? 5 + U.rand(8) : k === 'C' || k === 'X' ? U.rand(6) : 1 + U.rand(6));
    let busyFlag = false;
    function finishAnim() {
      clearTimeout(watchdog);
      if (stopLoop) { stopLoop(); stopLoop = null; }
      if (!anim) return;
      const last = anim.last; anim = null;
      api.sfx('thud');
      if (last.k === 'roll+') showSettle(st.last && st.last.id === last.id ? st.last : last);
      else if (last.k === 'roll') { // waiting for keep / reroll
        hitSum = rollSum(last.r); renderTown(); render();
        releaseBusy(200);
      }
      drawTray();
    }
    function releaseBusy(ms) {
      clearTimeout(busyT);
      busyT = setTimeout(() => { if (busyFlag) { busyFlag = false; api.setBusy(false); } }, ms / Math.max(0.2, L.debug.speed));
    }

    /* settlement feedback: bubbles, receipt, toasts */
    function showSettle(last) {
      hitSum = last.sum;
      rcpt.innerHTML = '';
      const d = last.d || [];
      for (let i = 0; i < d.length; i++) if (d[i]) bubble(i, d[i]);
      const parts = [];
      for (let i = 0; i < d.length; i++) if (d[i]) parts.push(h('span', null, h('span', { class: 'dot', style: { '--c': col(i), width: '8px', height: '8px' } }), meName(i) + ' ' + (d[i] > 0 ? '+' : '−') + Math.abs(d[i])));
      if (!parts.length) parts.push(h('span', { text: '아무도 못 벌었어요' }));
      parts.slice(0, 4).forEach((p) => rcpt.append(p));
      // special faces / events
      const r = last.r, notes = [];
      if (r && r.n === 'T' && r.v[0] === r.v[1]) notes.push('더블! 수입 두 배');
      if (r && r.x >= 0) notes.push(r.x <= 1 ? '별: 두 배!' : r.x === 2 ? '별: 이번 차례 짓기 3원 할인' : r.x === 3 ? '별: 번개!' : r.x === 5 ? '별: 먹구름… 내 수입 없음' : '');
      const myD = localHumans() === 1 ? d.reduce((a, v, i) => a + (mine(i) ? v : 0), 0) : 0;
      if (localHumans() === 1 && myD) notes.unshift('내 수입 ' + (myD > 0 ? '+' : '−') + Math.abs(myD) + '원');
      const n2 = notes.filter(Boolean);
      if (n2.length) say(n2.join(' · '));
      if (myD > 0) { api.sfx('chip'); } else if (myD < 0) api.sfx('lose'); else if (d.some((v) => v)) api.sfx('chip');
      renderPlayers(); renderTown(); render(); drawTray();
      releaseBusy(650);
    }

    /* ---------- control panel ---------- */
    function defaultSel() {
      const b = bestSel(st, st.t, 0);
      return { n: b.n, c: b.c, x: b.x };
    }
    function render() {
      panel.innerHTML = '';
      if (!st) return;
      const cur = actor(st);
      if (cur == null) { panel.append(h('div', { class: 'dt-line' }, h('span', { class: 'txt', text: '게임이 끝났어요' }))); return; }
      const me = mine(cur);
      const animBusy = !!anim;
      if (!me) {
        let txt;
        if (st.ph === 'r') txt = nm(cur) + ' · 주사위 고르는 중…';
        else if (st.ph === 'k') txt = nm(cur) + ' · 다시 굴릴지 생각 중…';
        else txt = nm(cur) + ' · 무엇을 지을지 고르는 중…';
        panel.append(lastLine(), h('div', { class: 'dt-line' }, h('span', { class: 'dot', style: { '--c': col(cur), flex: 'none' } }), h('span', { class: 'txt', text: txt })));
        if (localHumans() >= 1) panel.append(myIncomeHint());
        return;
      }
      if (st.ph === 'r') renderPick(cur, animBusy);
      else if (st.ph === 'k') renderKeep(cur, animBusy);
      else renderBuild(cur, animBusy);
    }
    function lastLine() {
      const l = st.last;
      let t = '랜드마크 5개를 먼저 지으면 이겨요';
      if (l) {
        if (l.k === 'b') t = nm(l.s) + ' · ' + BL[l.i].nm + ' 지음 (' + l.pr + '원)';
        else if (l.k === 'l') t = nm(l.s) + ' · 랜드마크 ' + LM[l.i].nm + ' 완성!';
        else if (l.k === 'p') t = nm(l.s) + ' · 저금하고 넘김 (+1원)';
        else if (l.r) t = nm(l.s) + ' · ' + DK[l.r.n].nm + ' → ' + rollSum(l.r);
      }
      return h('div', { class: 'dt-line' }, l ? h('span', { class: 'dot', style: { '--c': col(l.s), flex: 'none' } }) : null, h('span', { class: 'txt', text: t }));
    }
    function myIncomeHint() { // during others' turns: what their likely roll pays me
      const meSeat = st.nm.findIndex((_, i) => mine(i));
      if (meSeat < 0 || st.ph !== 'r') return h('div', { class: 'dt-line', style: { visibility: 'hidden' } }, '·');
      const hits = [];
      for (let v = 1; v <= 12; v++) {
        let g = 0;
        for (let i = 0; i < NB; i++) { const B = BL[i]; if (!st.b[meSeat][i] || !B.n.includes(v)) continue; if (B.k === 'F') g += B.p * st.b[meSeat][i]; if (B.k === 'R') g += B.p * st.b[meSeat][i]; }
        if (g) hits.push(v + '→+' + g);
      }
      return h('div', { class: 'dt-line' }, h('span', { class: 'txt', text: hits.length ? '남이 굴려도 나한테: ' + hits.join(' · ') : '남이 굴릴 때 받는 건물(들판·요금)이 아직 없어요' }));
    }
    function renderPick(cur, animBusy) {
      const key = st.g + ':' + st.tn;
      if (!mySel || selTurn !== key || !legalSel(st, cur, mySel)) { mySel = defaultSel(); selTurn = key; }
      const addKey = mySel.c ? 'c' : mySel.x ? 'x' : '';
      // number dice
      const row = h('div', { class: 'dt-dice dt-pick' });
      for (const n of NUMK) {
        const need = DK[n].need, ok = need < 0 || hasL(st, cur, need);
        const sel = { n, c: mySel.c, x: mySel.x };
        const ev = ok && legalSel(st, cur, sel) ? evSel(st, cur, sel).ev : null;
        row.append(h('button', { class: 'dt-dbtn' + (mySel.n === n ? ' on' : '') + (ok ? '' : ' lock'), 'aria-label': DK[n].nm,
          onclick() { if (!ok) { say(LM[need].nm + '(랜드마크)를 지으면 쓸 수 있어요', true); return; } mySel = { n, c: mySel.c, x: mySel.x }; api.sfx('click'); render(); drawTray(); } },
          h('img', { src: iconURL('d' + n), alt: '' }),
          h('div', { style: { minWidth: 0 } }, h('div', { class: 't', text: DK[n].sh }), h('div', { class: 'rg', text: DK[n].rg }), h('div', { class: 'ev', text: ok ? fmt(ev) : '잠김' }))));
      }
      // add-on die
      const add = h('div', { class: 'dt-add' }, h('span', { class: 'lb', html: '덤<br>주사위' }));
      const addBtn = (k, label, icon, need) => {
        const ok = need < 0 || hasL(st, cur, need);
        return h('button', { class: 'dt-dbtn' + (addKey === k ? ' on' : '') + (ok ? '' : ' lock'), 'aria-label': label,
          onclick() { if (!ok) { say(LM[need].nm + '(랜드마크)를 지으면 쓸 수 있어요', true); return; } mySel = { n: mySel.n, c: k === 'c' ? 1 : 0, x: k === 'x' ? 1 : 0 }; api.sfx('click'); render(); drawTray(); } },
          icon ? h('img', { src: iconURL(icon), alt: '' }) : null, h('span', { class: 't', text: label }));
      };
      add.append(addBtn('', '없음', null, -1), addBtn('c', '동전', 'dC', 1), addBtn('x', '별', 'dX', 3));
      // payout strip
      const e = evSel(st, cur, mySel);
      const strip = h('div', { class: 'dt-strip' });
      const pmax = Math.max(...e.strip.map((c) => c.p));
      for (const c of e.strip) {
        strip.append(h('div', { class: 'dt-cell' }, h('div', { class: 'bar', style: { height: Math.round((c.p / pmax) * 70) + '%' } }),
          h('span', { class: 'v', text: String(c.v) }), h('span', { class: 'g ' + (c.g > 0 ? 'pos' : c.g < 0 ? 'neg' : 'zero'), text: c.g > 0 ? '+' + c.g : c.g < 0 ? '−' + -c.g : '·' })));
      }
      const extra = mySel.c ? ' · 동전 +0~3' : mySel.x ? ' · 별: 두 배/할인/번개…' : '';
      const info = h('div', { class: 'dt-line dt-strip-cap' }, h('span', { class: 'txt', html: '나올 수 → <b>내가 받을 돈</b>' + extra }));
      const roll = h('button', { class: 'btn primary block dt-big dt-roll', disabled: pend || animBusy, text: '굴리기 · 평균 ' + fmt(e.ev) + '원', onclick() { api.sfx('click'); act({ t: 'r', n: mySel.n, c: mySel.c, x: mySel.x }); } });
      const wrapStrip = h('div', { class: 'dt-strip-wrap', style: { display: 'flex', flexDirection: 'column', gap: '3px' } }, info, strip);
      wrapStrip.classList.add('dt-strip-box');
      panel.append(row, add, wrapStrip, roll);
    }
    const fmt = (v) => (v == null ? '–' : (v >= 0 ? '+' : '−') + (Math.round(Math.abs(v) * 10) / 10).toFixed(1));
    function renderKeep(cur, animBusy) {
      const got = st.roll ? realized(st, cur) : 0;
      panel.append(lastLine(),
        h('div', { class: 'dt-line' }, h('span', { class: 'txt', html: '이대로 받으면 <b>' + (got >= 0 ? '+' : '−') + Math.abs(got) + '원</b> · 소원 우물로 한 번 다시 굴릴 수 있어요' })),
        h('div', { class: 'dt-row' },
          h('button', { class: 'btn', disabled: pend || animBusy, text: '다시 굴리기', onclick() { act({ t: 'r' }); } }),
          h('button', { class: 'btn primary dt-keep', disabled: pend || animBusy, text: '이대로 받기', onclick() { act({ t: 'k' }); } })));
    }
    function renderBuild(cur, animBusy) {
      let nB = 0; for (let i = 0; i < NB; i++) if (canBuyB(st, cur, i)) nB++;
      let nL = 0; for (let i = 0; i < 5; i++) if (canBuyL(st, cur, i)) nL++;
      const rec = recommend(cur);
      panel.append(lastLine(),
        h('div', { class: 'dt-line' }, h('span', { class: 'dt-coin' }), h('span', { class: 'txt', html: '<b>' + st.c[cur] + '원</b> · 지을 수 있는 것 ' + (nB + nL) + '개' + (nL ? ' (랜드마크 ' + nL + ')' : '') }), st.disc ? h('span', { class: 'dt-tag', text: '할인 −' + st.disc }) : null),
        rec ? h('div', { class: 'dt-rec' }, h('span', { class: 'txt', style: { flex: 1, minWidth: 0 }, text: '추천: ' + rec.name }), h('button', { class: 'btn sm', text: '추천 보기', onclick() { openMarket(false, rec.key); } })) : null,
        h('div', { class: 'dt-row' },
          h('button', { class: 'btn dt-pass', disabled: pend || animBusy, text: '저금 +1원 · 끝내기', onclick() { act({ t: 'p' }); } }),
          h('button', { class: 'btn primary dt-open', disabled: pend || animBusy, text: '시장 열기', onclick() { openMarket(false); } })));
    }
    function recommend(p) {
      try {
        const a = aiBuild(st, p, 3);
        if (a.t === 'b') return { key: 'b' + a.i, name: BL[a.i].nm + ' (' + priceOf(st, BL[a.i].c) + '원)' };
        if (a.t === 'l') return { key: 'l' + a.i, name: '랜드마크 ' + LM[a.i].nm + ' (' + priceOf(st, LM[a.i].c) + '원)' };
        return { key: '', name: '이번엔 저금해서 다음에 크게 짓기' };
      } catch (e) { return null; }
    }

    /* ---------- market sheet ---------- */
    let mk = null;
    function openMarket(viewOnly, preselect) {
      closeMarket(true);
      mkView = !!viewOnly; mkSel = preselect || null;
      mk = h('div', { class: 'dt-mk' });
      el.append(mk);
      renderMarket();
      api.sfx('pop');
    }
    function closeMarket(silent) { if (mk) { mk.remove(); mk = null; } if (!silent) api.sfx('click'); }
    function renderMarket() {
      if (!mk || !st) return;
      const cur = actor(st);
      const buyer = cur != null && mine(cur) && st.ph === 'b' && !mkView ? cur : null;
      const who = buyer != null ? buyer : (st.nm.findIndex((_, i) => mine(i)) >= 0 ? st.nm.findIndex((_, i) => mine(i)) : viewSeat());
      const scroll = mk.querySelector('.dt-mkb') ? mk.querySelector('.dt-mkb').scrollTop : 0;
      mk.innerHTML = '';
      const recK = buyer != null ? (recommend(buyer) || {}).key : '';
      // marginal income hints (per full round) for `who`
      let opp = null, base = 0, mySel0 = null;
      try { opp = oppGuess(st, who); mySel0 = bestSel(st, who, 0); base = incomeRound(st, who, opp, mySel0); } catch (e) { opp = null; }
      const gainOf = (t) => { if (!opp) return null; try { return incomeRound(t, who, opp, bestSel(t, who, 0)) - base; } catch (e) { return null; } };
      mk.append(h('div', { class: 'dt-mkh' },
        h('h3', { text: buyer != null ? '무엇을 지을까요?' : '시장' }),
        h('span', { class: 'sp' }),
        h('span', { class: 'money' }, h('span', { class: 'dt-coin' }), String(st.c[who]) + '원'),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', style: { minWidth: '44px', minHeight: '44px' }, onclick() { closeMarket(); } })));
      const body = h('div', { class: 'dt-mkb' });
      const sec = (title, c) => h('div', { class: 'dt-sec', style: { '--tc': c } }, h('i'), title);
      // landmarks
      body.append(sec('랜드마크 · 5개 모두 지으면 승리 (순서 자유)', TC.L));
      const lc = h('div', { class: 'dt-cards' });
      for (let i = 0; i < 5; i++) {
        const own = hasL(st, who, i), can = buyer != null && canBuyL(st, buyer, i);
        const price = buyer != null ? priceOf(st, LM[i].c) : LM[i].c;
        const key = 'l' + i;
        lc.append(card(key, TC.L, '★', '랜드마크', 'L' + i, LM[i].nm, LM[i].fx, price, LM[i].c, own ? '지음 ✓' : null, own ? 'ok' : '', !own && (buyer == null || can), recK === key, own || buyer == null ? null : null));
      }
      body.append(lc);
      const groups = [['F', '들판 · 누가 굴려도 은행에서 받아요'], ['G', '가게 · 내가 굴릴 때만 받아요'], ['R', '요금 · 남이 굴리면 그 사람이 내게 내요'], ['P', '특별 · 내가 굴릴 때 · 한 사람 1개']];
      for (const [k, title] of groups) {
        if (st.n === 1 && k === 'R') continue;
        body.append(sec(title, TC[k]));
        const cc = h('div', { class: 'dt-cards' });
        for (let i = 0; i < NB; i++) {
          const B = BL[i]; if (B.k !== k) continue;
          if (st.n === 1 && soloOff(i)) continue;
          const left = supplyLeft(st, i), own = st.b[who][i];
          const soldOut = B.k === 'P' ? own > 0 : left <= 0;
          const can = buyer != null && canBuyB(st, buyer, i);
          const price = buyer != null ? priceOf(st, B.c) : B.c;
          let gain = null;
          if (!soldOut) { const t = withB(st, who, i); gain = gainOf(t); }
          const tag = B.k === 'P' ? (own ? '보유 ✓' : null) : soldOut ? '다 팔림' : null;
          const foot = (own ? '보유 ' + own : '') + (B.k !== 'P' ? (own ? ' · ' : '') + '남은 ' + left : '');
          cc.append(card('b' + i, TC[k], numLabel(B), TN[k], 'b' + i, B.nm, fxText(i), price, B.c, tag, own && B.k === 'P' ? 'ok' : '', !soldOut && (buyer == null || can), recK === 'b' + i, foot, gain));
        }
        body.append(cc);
      }
      mk.append(body);
      body.scrollTop = scroll;
      // footer
      const f = h('div', { class: 'dt-mkf' });
      if (buyer == null) {
        f.append(h('div', { class: 'info', html: mkView ? '살펴보기만 할 수 있어요. 지금 <b>' + esc(cur != null ? nm(cur) : '') + '</b> 차례예요.' : '' }),
          h('button', { class: 'btn block', text: '닫기', onclick() { closeMarket(); } }));
      } else {
        let info = '카드를 눌러 고른 뒤 「짓기」를 누르세요.', label = '골라 주세요', ok = false;
        if (mkSel) {
          const isL = mkSel[0] === 'l', i = +mkSel.slice(1);
          const name = isL ? LM[i].nm : BL[i].nm, price = priceOf(st, isL ? LM[i].c : BL[i].c);
          ok = isL ? canBuyL(st, buyer, i) : canBuyB(st, buyer, i);
          let tip = '';
          if (!isL) { // which die makes this building shine (own roll only)
            let bn = '', bg = 0; const t = withB(st, buyer, i);
            for (const n of NUMK) { const sel = { n, c: 0, x: 0 }; if (!legalSel(st, buyer, sel)) continue; const g2 = evSel(t, buyer, sel).ev - evSel(st, buyer, sel).ev; if (g2 > bg + 0.01) { bg = g2; bn = n; } }
            if (bn && bg > 0.05) tip = ' · ' + DK[bn].sh + ' 주사위로 굴리면 평균 +' + (Math.round(bg * 10) / 10).toFixed(1);
          }
          info = '<b>' + name + '</b> · ' + (isL ? LM[i].fx : '[' + numLabel(BL[i]) + '] ' + fxText(i)) + tip + (ok ? '' : ' · <span style="color:var(--coral)">' + (st.c[buyer] < price ? '돈이 ' + (price - st.c[buyer]) + '원 모자라요' : '지을 수 없어요') + '</span>');
          label = name + ' 짓기 · ' + price + '원';
          if (isL && lmCount(st, buyer) === 4 && ok) label = name + ' 짓고 승리! · ' + price + '원';
        }
        f.append(h('div', { class: 'info', html: info }),
          h('div', { class: 'dt-row' },
            h('button', { class: 'btn', style: { flex: '0 0 auto', minWidth: '88px' }, text: '닫기', onclick() { closeMarket(); } }),
            h('button', { class: 'btn primary dt-buy', disabled: !ok || pend, text: label, onclick() {
              const isL = mkSel[0] === 'l', i = +mkSel.slice(1);
              closeMarket(true); api.sfx('thud'); act({ t: isL ? 'l' : 'b', i });
            } })));
      }
      mk.append(f);
    }
    function card(key, tc, numTxt, typeTxt, icon, name, fx, price, base, tag, tagCls, enabled, rec, foot, gain) {
      const sel = mkSel === key;
      const c = h('button', { class: 'dt-card' + (enabled ? '' : ' no') + (sel ? ' sel' : ''), style: { '--tc': tc }, 'aria-label': name + ' ' + price + '원',
        onclick() { mkSel = key; api.sfx('click'); renderMarket(); } },
        h('div', { class: 'band' }, h('span', { class: 'n', text: numTxt }), h('span', { text: typeTxt })),
        h('img', { src: iconURL(icon), alt: '' }),
        h('div', { class: 'nm', text: name }),
        h('div', { class: 'fx', text: fx }),
        h('div', { class: 'ft' },
          h('span', { class: 'cost' }, h('span', { class: 'dt-coin' }), price !== base ? h('s', { text: String(base) }) : null, String(price)),
          gain != null && gain > 0.05 ? h('span', { class: 'evh', text: '+' + (Math.round(gain * 10) / 10).toFixed(1) + '/바퀴' }) : h('span', { text: foot || '' })));
      if (tag) c.append(h('span', { class: 'tag ' + (tagCls || ''), text: tag }));
      if (rec) c.append(h('span', { class: 'tag rec', text: '추천' }));
      return c;
    }

    /* ---------- keyboard / pad shortcuts ---------- */
    const offInput = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      const cur = actor(st); if (cur == null || !mine(cur)) { if (id === 'back' && mk) closeMarket(); return; }
      if (id === 'back') { if (mk) closeMarket(); return; }
      if (id === 'market') { if (mk) closeMarket(); else openMarket(st.ph !== 'b'); return; }
      if (id === 'dice' && st.ph === 'r' && mySel) {
        const opts = NUMK.filter((n) => DK[n].need < 0 || hasL(st, cur, DK[n].need));
        mySel = { n: opts[(opts.indexOf(mySel.n) + 1) % opts.length], c: mySel.c, x: mySel.x }; render(); drawTray(); return;
      }
      if (id === 'pass' && st.ph === 'b' && !mk) { act({ t: 'p' }); return; }
      if (id === 'roll') {
        if (st.ph === 'r' && mySel && !anim) act({ t: 'r', n: mySel.n, c: mySel.c, x: mySel.x });
        else if (st.ph === 'k' && !anim) act({ t: 'k' });
        else if (st.ph === 'b') { const b = mk && mk.querySelector('.dt-buy'); if (b && !b.disabled) b.click(); else if (!mk) openMarket(false); }
      }
    }) : null;

    /* ---------- update ---------- */
    function syncAll() { renderPlayers(); renderTown(); render(); drawTray(); if (mk) renderMarket(); }
    return {
      update(next, prev) {
        st = next;
        pend = false; clearTimeout(pendT);
        const l = next.last, key = l ? next.g + ':' + l.id : '';
        const fresh = l && key !== shown && prev && prev !== next;
        shown = key;
        if (!fresh) { syncAll(); return; }
        if (l.k === 'roll' || l.k === 'roll+') {
          hitSum = -1; rcpt.innerHTML = ''; flashKey = null;
          if (mk) closeMarket(true);
          // show coins as they were before the roll until the dice land
          syncAll();
          if (anim) finishAnim();
          startRollAnim(l);
          if (l.k === 'roll+') { // keep the old coin numbers until settlement
            const saved = st; st = Object.assign({}, next, { c: next.c.map((v, i) => v - (l.d ? l.d[i] : 0)) }); renderPlayers(); st = saved;
          }
          render();
        } else if (l.k === 'res') {
          syncAll(); showSettle(l); busyFlag = true; api.setBusy(true); releaseBusy(650);
        } else {
          hitSum = -1; rcpt.innerHTML = '';
          if (l.k === 'b') flashKey = 'b' + l.s + ':' + l.i; else if (l.k === 'l') flashKey = 'l' + l.s + ':' + l.i; else flashKey = null;
          // show the builder's town for a moment so the new building is visible
          if ((l.k === 'b' || l.k === 'l') && l.s !== next.t) {
            autoPin = { seat: l.s, until: Date.now() + 1500 / Math.max(1, L.debug.speed) };
            clearTimeout(autoT); autoT = setTimeout(() => { autoPin = null; if (st) { renderPlayers(); renderTown(); } }, 1550 / Math.max(1, L.debug.speed));
          }
          if (mk) closeMarket(true);
          syncAll();
          if (l.k === 'l') { api.sfx('win'); say(nm(l.s) + ' · ' + LM[l.i].nm + ' 완성! (' + lmCount(next, l.s) + '/5)'); }
          else if (l.k === 'b') api.sfx('thud');
          else api.sfx('chip');
          if (l.k === 'p') bubble(l.s, 1);
          setTimeout(() => { flashKey = null; }, 1300);
        }
      },
      destroy() {
        if (stopLoop) stopLoop(); clearTimeout(watchdog); clearTimeout(busyT); clearTimeout(pendT); clearTimeout(autoT); clearTimeout(toastT);
        if (busyFlag || anim) api.setBusy(false);
        if (offInput) offInput();
        ro.disconnect(); el.remove(); style.remove();
      },
    };
  }

  L.register({
    id: 'dicetown', name: '주사위 마을 짓기', tag: '주사위 · 마을', cat: '보드',
    blurb: '여러 가지 주사위 중 골라 굴리고, 나온 수에 맞는 건물로 돈을 벌어요. 랜드마크 5개를 먼저 지으면 승리!',
    icon: '<rect x="6" y="26" width="18" height="22" rx="2" fill="currentColor" opacity=".55"/><path d="M4 28 15 18 26 28z" fill="currentColor" opacity=".8"/><rect x="28" y="16" width="14" height="32" rx="2" fill="currentColor" opacity=".7"/><path d="M26 18 35 8 44 18z" fill="currentColor"/><rect x="34" y="30" width="18" height="18" rx="4" fill="currentColor"/><circle cx="39" cy="35" r="2" fill="#000" opacity=".55"/><circle cx="47" cy="43" r="2" fill="#000" opacity=".55"/><circle cx="43" cy="39" r="2" fill="#000" opacity=".55"/>',
    tint: '#2f5a3a',
    quick: [
      '목표: 랜드마크 5개를 가장 먼저 다 지으면 이겨요.',
      '내 차례: 주사위를 골라 굴리기 → 나온 수의 건물이 돈을 벌어요 → 건물이나 랜드마크 하나 짓기.',
      '주사위마다 나오는 수가 달라요. 아래 줄에 수마다 내가 받을 돈이 미리 보여요.',
    ],
    rules: [
      { h: '목표', p: ['돈을 벌어 마을을 키우고, 랜드마크 5개(주사위 공방·조폐소·쌍둥이 탑·별빛 천문대·소원 우물)를 가장 먼저 모두 지으면 승리!', '랜드마크는 어떤 순서로 지어도 돼요. 지을 때마다 새 주사위나 힘이 생겨요.'] },
      { h: '준비', p: ['모두 3원과 밀밭(1)·떡집(3)을 가지고 시작해요.'] },
      { h: '차례에 할 일', p: ['① 주사위 고르기: 숫자 주사위 1개 + 덤 주사위(동전 또는 별) 1개까지.', '② 굴리기: 나온 수(쌍둥이는 두 눈의 합)와 같은 번호의 건물이 일해요.', '③ 짓기: 시장에서 건물 1개 또는 랜드마크 1개를 지어요. 안 지으면 저금으로 1원을 받아요.'] },
      { h: '주사위 종류', p: ['작은 주사위 1–4 · 보통 주사위 1–6: 처음부터 있어요.', '큰 주사위 5–12 (주사위 공방): 큰 수만 나와요. 1–4번 건물은 안 일해요.', '쌍둥이 주사위 2–12 (쌍둥이 탑): 두 개를 더해요. 7 근처가 잘 나오고, 같은 눈(더블)이면 내 수입이 두 배!', '동전 주사위 (조폐소): 금화 0·1·1·2·2·3개만큼 바로 받아요.', '별 주사위 (별빛 천문대): 두 배(2면)·할인(짓기 3원 싸게)·번개(돈 제일 많은 사람에게서 3원)·빈칸·먹구름(이번 내 은행 수입 없음).'] },
      { h: '건물 4가지', p: ['초록 들판: 누가 굴려도 그 수가 나오면 은행에서 받아요.', '파랑 가게: 내가 굴릴 때만 받아요. 「양 목장마다 +3」처럼 다른 건물 수만큼 버는 가게도 있어요.', '빨강 요금: 남이 굴려서 그 수가 나오면, 굴린 사람이 내게 돈을 내요. (가진 만큼만)', '금색 특별: 내가 굴릴 때. 축제 무대(모두에게서 2원씩), 주사위 박물관(굴린 주사위마다 +2). 한 사람 1개씩.', '돈 받는 순서: 요금 → 들판 → 가게 → 특별.'] },
      { h: '시장', p: ['건물마다 남은 개수가 있어요. 1–4번 건물은 적게 있어요.', '카드의 「+0.8/바퀴」는 그 건물을 지으면 한 바퀴(모두 한 번씩)에 평균 얼마 더 버는지 알려 줘요.', '돈이 모자란 카드는 흐리게 보여요. 「추천」 표시는 컴퓨터가 고른 좋은 선택이에요.'] },
      { h: '예시', p: ['내게 숲(6, +2)과 꽃가게(5, 내 굴림 +4)가 있어요. 보통 주사위를 골라 5가 나오면 꽃가게로 +4원!', '친구가 6을 굴려도 내 숲이 +2원을 벌어요(들판).', '돈이 모이면 주사위 공방(4원)을 지어 큰 주사위를 열고, 9번 광산(+7) 같은 큰 건물을 노려 봐요.'] },
      { h: '혼자 하기', p: ['혼자면 ' + SOLO_LIMIT + '턴 안에 랜드마크 5개를 지으면 성공! 빨리 지을수록 별이 많아요.', '★★★ ' + SOLO_STARS[0] + '턴 · ★★ ' + SOLO_STARS[1] + '턴 · ★ ' + SOLO_STARS[2] + '턴 안에. 혼자일 땐 요금 건물·축제 무대가 없고, 번개는 은행에서 2원이에요.'] },
      { h: '조작', p: ['위쪽 이름을 누르면 그 사람 마을을 볼 수 있어요. 건물을 누르면 설명이 나와요.', '「시장 보기」로 언제든 시장을 살펴볼 수 있어요.', 'PC: R 굴리기/받기 · D 주사위 바꾸기 · M 시장 · P 저금 · Esc 닫기.', 'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
    ],
    tutorial: [
      { sel: '.dt-players', text: '사람마다 가진 돈과 랜드마크(작은 칸 5개)가 보여요. 랜드마크 5개를 먼저 다 지으면 이겨요!' },
      { sel: '.dt-town', text: '지금 차례인 사람의 마을이에요. 건물 왼쪽 숫자가 나오면 그 건물이 돈을 벌어요. 처음엔 밀밭(1)과 떡집(3)이 있어요.' },
      { sel: '.dt-pick', text: '굴릴 주사위를 골라요. 작은 1–4, 보통 1–6. 랜드마크를 지으면 큰·쌍둥이·동전·별 주사위가 열려요.' },
      { sel: '.dt-strip-box', text: '고른 주사위로 나올 수 있는 수와, 그 수가 나오면 내가 받을 돈이에요. 막대가 높을수록 잘 나와요.' },
      { sel: '.dt-roll', text: '「굴리기」를 누르면 끝! 그다음 시장에서 건물이나 랜드마크를 하나 지어요. 무엇을 지을지 모르겠으면 「추천 보기」를 눌러요.' },
    ],
    controls: [
      { id: 'roll', label: '굴리기 · 받기 · 짓기', keys: ['KeyR'], pad: ['a'] },
      { id: 'dice', label: '주사위 바꾸기', keys: ['KeyD'], pad: ['rb'] },
      { id: 'market', label: '시장 열기/닫기', keys: ['KeyM'], pad: ['y'] },
      { id: 'pass', label: '저금하고 끝내기', keys: ['KeyP'], pad: ['x'] },
      { id: 'back', label: '닫기', keys: ['Escape'], pad: ['b'] },
    ],
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 3,
    init, actor, apply, result, ai, aiDelayFor, mount,
    _t: { BL, LM, DK, allSels, evSel, settle, soloStars, incomeRound, bestSel, SOLO_LIMIT, SOLO_STARS, lmCount, canBuyB, canBuyL },
  });
})();
