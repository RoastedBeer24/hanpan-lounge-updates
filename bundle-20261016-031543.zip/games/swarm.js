/* 생존 탄막 — realtime co-op survival roguelike (1–4, one person per phone; bots fill the rest).
   You only move (floating stick, optional dash); every weapon fires by itself. Enemies swarm in, drop XP gems,
   the TEAM levels up together and each player picks 1 of 3 cards (or skips: refund = 50% of that level's XP / players).
   Builds: 공용 빌드 (shared weapons + items anyone can get) + 캐릭터 전용 빌드 (each character's 2 exclusive weapons,
   2 exclusive traits and 2 exclusive evolutions). No meta progression: everything is open from the start (도감 shows all).
   Relic chests (유물 상자): guaranteed on boss kill (team chest: everyone chooses), sometimes from elites / rare drops.
   Opening shows 3 relics (일반/희귀/영웅/전설) → pick one or skip.
   Downed players are revived by a teammate standing next to them for 3 s. Everyone down = defeat.
   Network: host-authoritative fixed-step sim (1/30 s). Coarse phases via setState (pick → count → play → done).
   Host streams compact snapshots (hostSend ~20 Hz): enemies by pool slot in two interleaved halves (5 chars each,
   quantized 0.5 u, only near remote players), projectiles/gems/fx as short strings. Guests predict their own movement
   and publish {x, y, mx, my, d, pk, rk, ch}; host trusts plausible positions.
   Choices: if only ONE human is in the game → the whole game pauses while they choose (classic feel);
   with 2+ humans (online) nobody pauses: the chooser keeps moving inside a protective bubble (auto-pick after 12–15 s). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;

  /* ======================= constants ======================= */
  const WS = 2000, H = 1 / 30, MAXE = 350, MAXP = 260, MAXG = 110;
  const PR = 10, CS = 40, GW = Math.ceil(WS / CS), SPAWN_R = 430, VIEW_R = 520;
  const WMAX = 6, PMAX_SLOTS = 6, WLV = 6, TMX = 3;
  // card ids: 0..29 weapons, 30..43 shared items, 44..83 character traits, 95 heal, 96 might, 100.. evolutions (EVO index)
  const PI0 = 30, TR0 = 44, EV0 = 100, FH = 95, FM = 96;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = (x, y) => Math.sqrt(x * x + y * y);
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  function mkRng(seed) {
    let a = (seed >>> 0) || 0x9e3779b9;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ======================= content ======================= */
  // weapons. ex = owner character (exclusive) or undefined (shared). ev = card id of the evolution partner
  // (shared item PI0+i, or the owner's trait TR0+i). en/ed = evolved name/description.
  const WP = [
    { nm: '빛 화살', d: '가까운 적에게 화살을 쏴요', col: '#ffe08a', ev: PI0 + 2, en: '빛의 소나기', ed: '화살을 쉴 새 없이 쏟아부어요' },
    { nm: '수호 구슬', d: '구슬이 내 둘레를 돌며 때려요', col: '#8fb6ff', ev: PI0 + 1, en: '은하 고리', ed: '구슬이 쉬지 않고 돌고 더 많아져요' },
    { nm: '불꽃 고리', d: '가까이 온 적을 계속 태워요', col: '#ff8a4a', ev: PI0 + 6, en: '태양 심장', ed: '더 넓고 뜨겁게, 내 체력도 회복' },
    { nm: '번개 부적', d: '근처 적에게 번개가 떨어져요', col: '#d9c6ff', ev: PI0 + 9, en: '뇌우', ed: '번개가 옆 적들에게 튀어요' },
    { nm: '나무 부메랑', d: '던지면 돌아와요 · 뚫고 지나가요', col: '#d8a35a', ev: PI0 + 5, en: '쌍둥이 초승달', ed: '크고 빠른 부메랑이 여러 개' },
    { nm: '서리 파편', d: '가까운 적 쪽으로 얼음 조각 · 적이 느려져요', col: '#a8e6ff', ex: 2, ev: TR0 + 4, en: '눈보라', ed: '사방으로 쏘고 적을 얼려요' },
    { nm: '불꽃 폭탄', d: '적에게 폭탄을 던져 쾅', col: '#ff6a5a', ex: 1, ev: TR0 + 3, en: '불꽃 축제', ed: '터진 뒤 작은 폭발이 연달아' },
    { nm: '바람 베기', d: '옆으로 길게 베어요', col: '#c8f5e0', ex: 0, ev: TR0 + 1, en: '붉은 달 베기', ed: '양옆을 크게 베고 체력을 흡수' },
    { nm: '독 웅덩이', d: '바닥에 독 웅덩이를 깔아요', col: '#9be05a', ev: PI0 + 11, en: '생명의 늪', ed: '늪 안의 우리 편은 체력 회복' },
    { nm: '반딧불', d: '적을 쫓아가는 작은 불빛', col: '#fff38a', ev: PI0 + 8, en: '별빛 무리', ed: '불빛이 두 배, 적을 뚫어요' },
    { nm: '대지 울림', d: '퍼지는 충격파로 적을 밀쳐요', col: '#e0c08a', ev: PI0 + 7, en: '대지 진동', ed: '두 겹 충격파, 적을 기절시켜요' },
    { nm: '빛 줄기', d: '가까운 적 쪽으로 긴 광선', col: '#fff6c8', ex: 5, ev: TR0 + 11, en: '태양 창', ed: '훨씬 길고 굵은 광선' },
    { nm: '가시 덫', d: '지나간 자리에 밟으면 터지는 덫', col: '#c9a0ff', ev: PI0 + 4, en: '가시 지뢰밭', ed: '덫이 크게 터지며 작은 덫을 흩뿌려요' },
    { nm: '튕김 공', d: '적 사이를 통통 튕겨 다녀요', col: '#7fe3d0', ex: 8, ev: TR0 + 16, en: '혜성 공', ed: '두 배로 튕기고 더 세게' },
    { nm: '꼬마 드론', d: '나를 따라다니며 총을 쏴요', col: '#b8c4d0', ex: 3, ev: TR0 + 6, en: '드론 편대', ed: '드론이 늘고 더 빨리 쏴요' },
    { nm: '회오리', d: '적을 빨아들이는 회오리', col: '#b0f0ff', ex: 2, ev: TR0 + 5, en: '얼음 폭풍', ed: '큰 회오리가 적을 빨아들여 얼려요' },
    { nm: '별똥별', d: '적 무리에 별똥별이 쾅', col: '#ffb070', ev: PI0 + 0, en: '유성우', ed: '별똥별이 비처럼 쏟아져요' },
    { nm: '그림자 단검', d: '가까운 적에게 단검을 빠르게 던져요', col: '#9a8ac8', ex: 0, ev: TR0 + 0, en: '칼날 비', ed: '단검이 부채꼴로 쏟아지고 뚫어요' },
    { nm: '가시 폭발', d: '내 둘레로 가시가 사방에 튀어요', col: '#ff8aa8', ex: 7, ev: TR0 + 14, en: '장미 폭풍', ed: '가시가 두 배, 적을 뚫어요' },
    { nm: '화염 방사', d: '가까운 적 쪽으로 불길을 뿜어요', col: '#ff9a3a', ex: 1, ev: TR0 + 2, en: '용의 숨결', ed: '더 넓고 길게 뿜어요' },
    { nm: '도끼 던지기', d: '위로 던진 도끼가 떨어지며 때려요', col: '#c8b098', ex: 6, ev: TR0 + 12, en: '거인 도끼', ed: '아주 큰 도끼가 두 배로' },
    { nm: '사슬 회전날', d: '사슬 끝 날이 내 둘레를 쓸어요', col: '#b8c8d8', ex: 4, ev: TR0 + 8, en: '강철 회오리날', ed: '날이 둘, 더 길게' },
    { nm: '수정 창', d: '적 무리를 꿰뚫는 느린 창', col: '#a8f0ff', ex: 5, ev: TR0 + 10, en: '수정 폭풍', ed: '창이 부채꼴로 여러 개' },
    { nm: '음파 종', d: '가까운 적 쪽으로 음파를 울려 밀쳐요', col: '#f0d890', ex: 4, ev: TR0 + 9, en: '천둥 종', ed: '사방으로 두 번 울려요' },
    { nm: '불새', d: '큰 불새가 넓게 날며 부딪혀요', col: '#ff7a4a', ex: 9, ev: TR0 + 18, en: '불사조 무리', ed: '불새 셋이 날아요' },
    { nm: '증기 포탑', d: '발밑에 포탑을 세워요 · 가까운 적을 쏴요', col: '#d0b080', ex: 3, ev: TR0 + 7, en: '요새 포탑', ed: '두 발씩 쏘고 오래 버티는 포탑' },
    { nm: '회전 베기', d: '도끼를 휘둘러 내 둘레를 한 바퀴 베요', col: '#e0a070', ex: 6, ev: TR0 + 13, en: '피의 소용돌이', ed: '넓게 자주 돌고, 벨 때마다 체력 회복' },
    { nm: '치유 꽃', d: '발밑에 꽃을 심어요 · 우리 편 회복 + 가시 발사', col: '#ff9ac0', ex: 7, ev: TR0 + 15, en: '세계수 싹', ed: '큰 꽃 · 꽃 안에 쓰러진 친구는 저절로 살아나요' },
    { nm: '번개 사슬', d: '번개가 적에서 적으로 줄줄이 튀어요', col: '#a8d8ff', ex: 8, ev: TR0 + 17, en: '뇌신의 그물', ed: '사슬 두 줄, 더 멀리 더 세게' },
    { nm: '매 사냥', d: '매가 멀리 있는 강한 적에게 내리꽂혀요', col: '#d8b888', ex: 9, ev: TR0 + 19, en: '폭풍 독수리', ed: '매 두 마리 · 꽂힐 때마다 폭발' },
  ];
  // shared items (passives). mx = max level
  const PS = [
    { nm: '힘 반지', d: '모든 피해 +10%', mx: 5, col: '#ff8a6a' },
    { nm: '확장 렌즈', d: '공격 범위 +10%', mx: 5, col: '#8fd0ff' },
    { nm: '연사 장갑', d: '공격 대기 시간 −8%', mx: 5, col: '#ffd36a' },
    { nm: '메아리 구슬', d: '발사 개수 +1', mx: 2, col: '#d7a8ff' },
    { nm: '모래시계', d: '지속 시간 +15%', mx: 5, col: '#e8c890' },
    { nm: '날개 신발', d: '이동 속도 +8%', mx: 5, col: '#a8f0c8' },
    { nm: '심장석', d: '최대 체력 +20', mx: 5, col: '#ff6a8a' },
    { nm: '철갑 조끼', d: '받는 피해 −1', mx: 5, col: '#b8c0cc' },
    { nm: '자석 돌', d: '보석 줍는 거리 +30%', mx: 5, col: '#ff7070' },
    { nm: '행운 부적', d: '치명타 +5% (피해 2배)', mx: 5, col: '#7ee08a' },
    { nm: '흡혈 송곳니', d: '처치할 때 가끔 체력 회복', mx: 5, col: '#e05a6a' },
    { nm: '재생 이끼', d: '초당 체력 +0.25', mx: 5, col: '#6fcf6a' },
    { nm: '속도 깃털', d: '투사체 속도 +12%', mx: 5, col: '#f0f0ff' },
    { nm: '성장 책', d: '팀 경험치 +6%', mx: 5, col: '#e3ae45' },
  ];
  // character traits (exclusive upgrades, max Lv 3). g = glyph id used for the icon
  const TR = [
    { nm: '그림자 걸음', d: '대시를 시작하고 끝낼 때 칼날이 터져요 (레벨마다 더 세게)', g: 17 },
    { nm: '급소', d: '치명타 +6% · 치명타 피해 +40% (레벨마다)', g: 39 },
    { nm: '장작불', d: '화상 피해 +40% · 화상 시간 +0.5초 (레벨마다)', g: 2 },
    { nm: '불씨 번짐', d: '불타는 적이 쓰러지면 펑 터져요 (레벨마다 더 크게)', g: 6 },
    { nm: '산산조각', d: '느려지거나 언 적을 쓰러뜨리면 얼음 조각이 튀어요', g: 5 },
    { nm: '한기', d: '내 모든 공격이 적을 느리게 해요 (레벨마다 더 오래)', g: 15 },
    { nm: '과부하', d: '드론·포탑 공격 대기 −12% (레벨마다)', g: 14 },
    { nm: '수리 장치', d: '포탑 둘레 우리 편 체력 회복 · 포탑 +1개', g: 90 },
    { nm: '반격', d: '맞으면 둘레 적에게 충격파 (레벨마다 더 세게)', g: 10 },
    { nm: '수호 맹세', d: '나와 근처 우리 편 받는 피해 −1 (레벨마다)', g: 37 },
    { nm: '굴절', d: '수정 창이 끝에서 여러 갈래로 갈라져요', g: 22 },
    { nm: '집중', d: '멈춰 서 있으면 피해 +12% · 범위 +5% (레벨마다)', g: 31 },
    { nm: '광기', d: '체력 절반 아래: 공격 대기 −8% · 이동 +6% (레벨마다)', g: 20 },
    { nm: '피의 갈증', d: '처치할 때 20% 확률로 체력 회복 (레벨마다 더 많이)', g: 36 },
    { nm: '덩굴 손', d: '내 가시에 맞은 적이 아주 느려지고 피해 +10% (레벨마다)', g: 18 },
    { nm: '생명의 정원', d: '꽃 회복 +40% · 친구 살리는 속도 +30% (레벨마다)', g: 27 },
    { nm: '탄성', d: '튕길 때마다 피해 +12%씩 커져요 (레벨마다)', g: 13 },
    { nm: '과충전', d: '번개 사슬 +1칸 · 마지막 적이 펑 (레벨마다)', g: 3 },
    { nm: '깃털 바람', d: '불새·매가 15% 빨라지고 불새가 커져요 (레벨마다)', g: 24 },
    { nm: '사냥 본능', d: '강한 적·보스에게 주는 피해 +20% (레벨마다)', g: 29 },
    // 2nd path traits (index 20..39): w = the weapon they shape, m = weapon mods per level
    { nm: '독 칼날', d: '단검 피해 +10% · 맞힌 적이 중독돼요(지속 피해) (레벨마다)', g: 8, w: 17, m: { dm: 0.1, burn: 3 } },
    { nm: '피의 춤', d: '베기 범위 +10% · 벨 때 8% 확률로 체력 회복 (레벨마다)', g: 36, w: 7, m: { ar: 0.1, vamp: 0.08 } },
    { nm: '푸른 불꽃', d: '화염 범위 +8% · 불길에 맞은 적이 느려져요 (레벨마다)', g: 15, w: 19, m: { ar: 0.08, slow: 0.4 } },
    { nm: '점착 폭약', d: '폭탄 피해 +12% · 맞힌 적이 15% 확률로 또 터져요 (레벨마다)', g: 6, w: 6, m: { dm: 0.12, boom: 0.15 } },
    { nm: '얼음 창', d: '서리 파편 피해 +15% · 빠르기 +10% · 치명타 +4% (레벨마다)', g: 22, w: 5, m: { dm: 0.15, ps: 0.1, crit: 0.04 } },
    { nm: '눈사태', d: '회오리 크기 +12% · 피해 +10% (레벨마다)', g: 15, w: 15, m: { ar: 0.12, dm: 0.1 } },
    { nm: '폭발 탄두', d: '드론 탄이 10% 확률로 폭발 · 피해 +8% (레벨마다)', g: 6, w: 14, m: { boom: 0.1, dm: 0.08 } },
    { nm: '전기 코일', d: '포탑 탄이 12% 확률로 번개 · 포탑 대기 −8% (레벨마다)', g: 3, w: 25, m: { zap: 0.12, cd: 0.08 } },
    { nm: '가시 사슬', d: '회전날 피해 +12% · 맞힌 적이 느려져요 (레벨마다)', g: 12, w: 21, m: { dm: 0.12, slow: 0.5 } },
    { nm: '성가', d: '종이 울릴 때 나와 근처 우리 편 체력 +1 (레벨마다)', g: 23, w: 23, m: { heal: 1 } },
    { nm: '꿰뚫는 의지', d: '창 피해 +12% · 체력이 조금 남은 적을 바로 처치 (레벨마다)', g: 42, w: 22, m: { dm: 0.12, exe: 0.05 } },
    { nm: '프리즘', d: '광선 범위 +8% · 2레벨마다 광선 +1 (레벨마다)', g: 11, w: 11, m: { ar: 0.08, n: 0.5 } },
    { nm: '대지 쪼개기', d: '도끼가 12% 확률로 땅을 터뜨려요 · 도끼 크기 +8% (레벨마다)', g: 10, w: 20, m: { boom: 0.12, ar: 0.08 } },
    { nm: '폭풍 회전', d: '회전 베기 대기 −10% · 범위 +6% (레벨마다)', g: 26, w: 26, m: { cd: 0.1, ar: 0.06 } },
    { nm: '독가시', d: '가시가 적을 중독시켜요 · 가시 피해 +8% (레벨마다)', g: 8, w: 18, m: { burn: 3, dm: 0.08 } },
    { nm: '꽃가루 폭발', d: '꽃 가시가 12% 확률로 터져요 · 꽃 크기 +8% (레벨마다)', g: 27, w: 27, m: { boom: 0.12, ar: 0.08 } },
    { nm: '불붙은 공', d: '튕김 공이 적을 태워요 · 공 빠르기 +10% (레벨마다)', g: 2, w: 13, m: { burn: 3, ps: 0.1 } },
    { nm: '얼음 전류', d: '번개 사슬에 맞은 적이 느려지고 5% 확률로 얼어요 (레벨마다)', g: 5, w: 28, m: { slow: 0.4, frz: 0.05 } },
    { nm: '잿불 깃털', d: '불새가 적을 태워요 · 불새 피해 +8% (레벨마다)', g: 24, w: 24, m: { burn: 3, dm: 0.08 } },
    { nm: '매의 눈', d: '매 치명타 +8% · 매 피해 +10% (레벨마다)', g: 29, w: 29, m: { crit: 0.08, dm: 0.1 } },
  ];
  // characters: w = signature (starting) weapon, w2 = 2nd exclusive weapon, tr = [trait for w, trait for w2]
  const CH = [
    { nm: '그림자 칼잡이', t: '기습형', w: 17, w2: 7, tr: [0, 1, 20, 21], pt: [['그림자 걸음', '대시로 파고들 때마다 칼날이 터져요'], ['맹독', '단검으로 중독시켜 서서히 녹여요'], ['급소', '치명타로 한 번에 크게 베어요'], ['피의 춤', '베면서 체력을 빨아들여요']], col: '#6a5a9a', hat: 13, sp: 0.1, hp: -10, d: '대시 대기 −40% · 대시 뒤 2초간 치명타 +25% · 이동 +10%', st: '대시로 파고들어 급소를 노려요' },
    { nm: '불꽃 술사', t: '화상형', w: 19, w2: 6, tr: [2, 3, 22, 23], pt: [['장작불', '화상을 더 뜨겁고 길게'], ['푸른 불꽃', '불길로 적을 느리게 묶어요'], ['불씨 번짐', '불타는 적이 터지며 옮겨 붙어요'], ['점착 폭약', '폭탄이 연달아 터져요']], col: '#d04a2a', hat: 15, d: '내 모든 공격이 적을 2초간 태워요(화상)', st: '불을 붙이고 번지게 해요' },
    { nm: '서리 마법사', t: '제어형', w: 5, w2: 15, tr: [4, 5, 24, 25], pt: [['산산조각', '얼린 적을 깨뜨려 파편을 튀겨요'], ['얼음 창', '빠르고 날카로운 얼음 사격'], ['한기', '모든 공격이 적을 느리게'], ['눈사태', '거대한 회오리로 휩쓸어요']], col: '#8fcaf0', hat: 10, d: '느려지거나 언 적에게 피해 +25%', st: '적을 묶고 얼려서 깨뜨려요' },
    { nm: '태엽 기술자', t: '설치형', w: 14, w2: 25, tr: [6, 7, 26, 27], pt: [['과부하', '드론을 더 빨리, 더 많이'], ['폭발 탄두', '드론 탄이 터져요'], ['수리 장치', '포탑이 우리 편을 고쳐요'], ['전기 코일', '포탑이 번개를 쏴요']], col: '#9aa3ad', hat: 9, ar: 1, sp: -0.04, d: '드론·포탑 피해 +20% · 받는 피해 −1', st: '드론과 포탑이 대신 싸워요' },
    { nm: '방패 기사', t: '수호형', w: 21, w2: 23, tr: [8, 9, 28, 29], pt: [['반격', '맞을수록 충격파로 되갚아요'], ['가시 사슬', '회전날로 적을 묶어요'], ['수호 맹세', '근처 우리 편을 단단하게'], ['성가', '종소리로 우리 편을 치유해요']], col: '#7a8fd6', hat: 3, ar: 2, hp: 30, sp: -0.08, d: '받는 피해 −2 · 체력 +30 · 근처 우리 편 받는 피해 −1', st: '앞에서 버티며 친구를 지켜요' },
    { nm: '수정 창병', t: '관통형', w: 22, w2: 11, tr: [10, 11, 30, 31], pt: [['굴절', '창이 갈라지며 흩어져요'], ['꿰뚫는 의지', '약해진 적을 단번에 처치'], ['집중', '멈춰 서서 강하게 쏴요'], ['프리즘', '광선을 여러 갈래로']], col: '#4ab0c8', hat: 18, ps: 0.2, area: 0.1, d: '투사체 속도 +20% · 공격 범위 +10%', st: '멈춰 서서 줄줄이 꿰뚫어요' },
    { nm: '도끼 광전사', t: '광폭형', w: 20, w2: 26, tr: [12, 13, 32, 33], pt: [['광기', '위험할수록 빠르고 거칠게'], ['대지 쪼개기', '도끼로 땅을 터뜨려요'], ['피의 갈증', '베어 넘길 때마다 회복'], ['폭풍 회전', '쉬지 않고 휘돌아요']], col: '#a0724a', hat: 16, hp: 30, d: '체력 +30 · 잃은 체력만큼 피해 최대 +40%', st: '아슬아슬할수록 강해져요' },
    { nm: '장미 정원사', t: '치유형', w: 18, w2: 27, tr: [14, 15, 34, 35], pt: [['덩굴 손', '가시로 적을 묶어요'], ['독가시', '가시로 중독시켜요'], ['생명의 정원', '꽃으로 팀을 살려요'], ['꽃가루 폭발', '꽃이 폭탄이 돼요']], col: '#d0587a', hat: 14, rg: 0.3, d: '회복량 +30% · 초당 체력 +0.3 · 친구 살리는 속도 +30%', st: '꽃을 심어 팀을 살려요' },
    { nm: '튕김 곡예사', t: '연쇄형', w: 13, w2: 28, tr: [16, 17, 36, 37], pt: [['탄성', '튕길수록 세져요'], ['불붙은 공', '튕기며 불을 붙여요'], ['과충전', '더 긴 번개 사슬'], ['얼음 전류', '번개로 적을 얼려요']], col: '#4fc8b0', hat: 7, sp: 0.08, d: '튕기는 공격·번개 사슬 +1번 더 · 이동 +8%', st: '적 사이를 줄줄이 튕겨요' },
    { nm: '불새 조련사', t: '소환형', w: 24, w2: 29, tr: [18, 19, 38, 39], pt: [['깃털 바람', '빠르고 큰 불새 무리'], ['잿불 깃털', '불새가 모든 것을 태워요'], ['사냥 본능', '강한 적과 보스 사냥'], ['매의 눈', '매가 급소를 꿰뚫어요']], col: '#e0843a', hat: 0, sp: 0.05, d: '불새·매·회전 공격 피해 +20% · 이동 +5%', st: '새들을 부려 멀리서 사냥해요' },
  ];

  // ---- evolutions: branching + 2nd evolutions ----
  // req: [[card id, min level], ...] (shared item / trait / another weapon). base 1 = the weapon's own "evolved" behaviour,
  // base 0 = normal behaviour + strong mods. from = the evolution it grows out of (2nd evolution) or -1.
  // mods m: dm/ar/du/ps (+%), cd (−% wait), n (+count), burn (dps), slow (s), frz/boom/zap/vamp/crit (chance), exe (execute hp %), heal
  const EVO = WP.map((q, i) => ({ w: i, nm: q.en, d: q.ed, req: [[q.ev, 1]], base: 1, m: {}, from: -1, k: 'A' }));
  const P_ = (i) => PI0 + i, T_R = (i) => TR0 + i;
  [ // branch B (and C) — same weapon, different partner → different evolution
    [0, [[P_(0), 1]], '폭발 화살', '화살이 꽂히면 30% 확률로 펑', { boom: 0.3, dm: 0.4, n: 1 }],
    [0, [[9, 4]], '별빛 연사', '반딧불과 함께: 화살 +2, 더 빨리', { n: 2, dm: 0.5, cd: 0.2 }, 'C'],
    [1, [[P_(4), 1]], '얼음 위성', '구슬이 적을 느리게 하고 가끔 얼려요', { frz: 0.12, slow: 1, dm: 0.4 }],
    [2, [[P_(0), 1]], '지옥불 고리', '고리가 적을 오래 태워요', { burn: 6, ar: 0.3, dm: 0.3 }],
    [2, [[8, 4]], '유독 불길', '독 웅덩이와 함께: 태우고 느리게', { burn: 5, slow: 0.8, ar: 0.4, dm: 0.3 }, 'C'],
    [3, [[P_(1), 1]], '천벌', '아주 넓은 번개가 내리쳐요', { ar: 1.5, dm: 0.8, cd: 0.1 }],
    [4, [[P_(10), 1]], '피의 부메랑', '맞힐 때 가끔 체력 회복 · 하나 더', { vamp: 0.15, dm: 0.5, n: 1 }],
    [8, [[P_(4), 1]], '산성 늪', '훨씬 아프고 적을 느리게 해요', { dm: 0.8, slow: 1, ar: 0.3 }],
    [9, [[P_(3), 1]], '불나방 떼', '불빛 +2, 적을 태워요', { burn: 5, n: 2, dm: 0.3 }],
    [10, [[P_(1), 1]], '해일', '더 넓게 퍼지며 적을 느리게', { ar: 0.6, dm: 0.5, slow: 1 }],
    [10, [[3, 4]], '천둥 지진', '번개 부적과 함께: 충격파에 번개가 튀어요', { zap: 0.3, dm: 0.6 }, 'C'],
    [12, [[P_(9), 1]], '번개 덫', '덫이 터질 때 번개가 튀어요', { zap: 0.6, dm: 0.4 }],
    [16, [[P_(12), 1]], '얼음 혜성', '별똥별이 적을 얼려요 · 더 자주', { frz: 0.2, dm: 0.4, cd: 0.2 }],
    [17, [[T_R(20), 1]], '맹독 단검비', '단검 +2, 맞히면 강한 중독', { n: 2, cd: 0.25, burn: 6, dm: 0.3 }],
    [7, [[T_R(21), 1]], '피바람 베기', '크게 베며 체력을 자주 빨아들여요', { ar: 0.4, dm: 0.5, vamp: 0.25, cd: 0.2 }],
    [19, [[T_R(22), 1]], '청염 방사', '푸른 불길이 적을 느리게 하고 얼려요', { ar: 0.4, dm: 0.5, slow: 1.2, frz: 0.08 }],
    [6, [[T_R(23), 1]], '연쇄 폭뢰', '폭탄 +2, 맞은 적이 또 터져요', { n: 2, boom: 0.35, dm: 0.4, cd: 0.2 }],
    [5, [[T_R(24), 1]], '빙창 사격', '파편 +2, 아주 날카롭게 꽂혀요', { n: 2, dm: 0.7, crit: 0.2, ps: 0.4 }],
    [15, [[T_R(25), 1]], '눈사태 회오리', '거대한 회오리가 오래 남아요', { ar: 0.7, dm: 0.6, du: 0.4, frz: 0.06 }],
    [14, [[T_R(26), 1]], '폭격 드론', '드론 +1, 탄이 자주 폭발해요', { boom: 0.4, dm: 0.6, n: 1 }],
    [25, [[T_R(27), 1]], '테슬라 포탑', '포탑이 빠르게 쏘고 번개가 튀어요', { zap: 0.35, cd: 0.3, dm: 0.5 }],
    [21, [[T_R(28), 1]], '가시 철퇴', '무거운 철퇴가 적을 붙잡아요', { dm: 0.8, slow: 1.2, ar: 0.3 }],
    [23, [[T_R(29), 1]], '성스러운 종', '넓게 울리며 우리 편을 치유해요', { ar: 0.5, dm: 0.4, cd: 0.2, heal: 3 }],
    [22, [[T_R(30), 1]], '심판의 창', '체력 20% 아래의 적을 바로 처치', { dm: 0.8, exe: 0.2, ps: 0.3 }],
    [11, [[T_R(31), 1]], '무지개 광선', '광선 +3, 맞은 적을 태워요', { n: 3, ar: 0.3, dm: 0.3, burn: 4 }],
    [20, [[T_R(32), 1]], '지진 도끼', '떨어진 도끼가 자주 땅을 터뜨려요', { boom: 0.5, ar: 0.4, dm: 0.4 }],
    [26, [[T_R(33), 1]], '회오리 돌진', '쉬지 않고 빠르게 휘돌아요', { cd: 0.5, ar: 0.3, dm: 0.3 }],
    [18, [[T_R(34), 1]], '독장미 덤불', '가시가 아주 많고 강하게 중독시켜요', { n: 6, burn: 8, dm: 0.3 }],
    [27, [[T_R(35), 1]], '꽃폭탄 정원', '꽃 +1, 꽃 가시가 자주 터져요', { boom: 0.5, ar: 0.4, dm: 0.6, n: 1 }],
    [13, [[T_R(36), 1]], '유성 공', '공 +1, 튕기며 크게 태워요', { burn: 8, dm: 0.5, ps: 0.3, n: 1 }],
    [28, [[T_R(37), 1]], '서리 번개', '번개가 적을 느리게 하고 자주 얼려요', { frz: 0.2, slow: 1.2, dm: 0.5 }],
    [24, [[T_R(38), 1]], '업화의 새', '불새가 닿는 모든 적을 크게 태워요', { burn: 10, dm: 0.6, ar: 0.3 }],
    [29, [[T_R(39), 1]], '송골매 저격', '매가 급소만 노려요(치명타 +40%)', { crit: 0.4, dm: 0.8, ps: 0.3 }],
  ].forEach((b) => EVO.push({ w: b[0], req: b[1], nm: b[2], d: b[3], m: b[4], base: 0, from: -1, k: b[5] || 'B' }));
  const evoOf = (w, k) => EVO.findIndex((e) => e.w === w && e.k === k && e.from < 0);
  [ // 2nd evolutions: [weapon, from branch, req, name, desc, mods]
    [0, 'A', [[P_(2), 5], [P_(3), 2]], '천상의 화살비', '하늘을 덮는 화살비', { n: 2, dm: 0.6 }],
    [1, 'A', [[P_(1), 5], [P_(4), 3]], '은하수', '거대한 별 고리', { ar: 0.4, dm: 0.6 }],
    [3, 'A', [[P_(9), 5], [P_(0), 3]], '뇌신의 분노', '번개가 번개를 불러요', { zap: 0.3, dm: 0.7 }],
    [8, 'B', [[P_(4), 5], [P_(11), 3]], '죽음의 늪', '모든 것을 녹이는 늪 · 안에선 우리 편 회복', { dm: 0.9, slow: 1.5, ar: 0.3 }],
    [17, 'A', [[T_R(0), 3], [7, 4]], '그림자 군무', '칼날이 춤추듯 쏟아져요 · 치명타 +15%', { n: 3, dm: 0.4, crit: 0.15 }],
    [7, 'B', [[T_R(21), 3], [17, 4]], '핏빛 초승달', '거대한 핏빛 베기, 흡혈 강화', { ar: 0.5, dm: 0.6, vamp: 0.3 }],
    [19, 'A', [[T_R(2), 3], [6, 4]], '태양룡의 숨결', '모든 것을 태우는 불길', { ar: 0.4, dm: 0.6, burn: 8 }],
    [6, 'B', [[T_R(23), 3], [19, 4]], '대폭발 축제', '폭탄 +2, 끝없는 연쇄 폭발', { n: 2, boom: 0.4, dm: 0.5 }],
    [5, 'A', [[T_R(4), 3], [15, 4]], '절대 영도', '사방이 얼어붙어요', { n: 4, dm: 0.5, frz: 0.15 }],
    [15, 'B', [[T_R(25), 3], [5, 4]], '빙하 소용돌이', '얼음 회오리가 모두 얼려요', { ar: 0.6, dm: 0.6, frz: 0.1 }],
    [14, 'A', [[T_R(6), 3], [25, 4]], '강철 함대', '드론 +2, 쉴 새 없이 쏴요', { n: 2, dm: 0.5, cd: 0.2 }],
    [25, 'B', [[T_R(27), 3], [14, 4]], '번개탑 요새', '포탑 +1, 번개 폭풍', { zap: 0.4, dm: 0.6, n: 1 }],
    [21, 'A', [[T_R(8), 3], [23, 4]], '수호 칼날 폭풍', '날이 적을 붙잡아 갈아요', { dm: 0.6, ar: 0.3, slow: 1 }],
    [23, 'B', [[T_R(29), 3], [21, 4]], '천상의 종', '종소리마다 크게 치유', { heal: 4, ar: 0.4, dm: 0.5 }],
    [22, 'A', [[T_R(10), 3], [11, 4]], '수정 성운', '창 +2, 갈라지는 수정 폭풍', { n: 2, dm: 0.6 }],
    [11, 'B', [[T_R(31), 3], [22, 4]], '극광', '하늘을 가르는 무지개빛 광선', { n: 2, dm: 0.6, burn: 6 }],
    [20, 'A', [[T_R(12), 3], [26, 4]], '분노의 거인 도끼', '도끼 +2, 치명타 +15%', { n: 2, dm: 0.6, crit: 0.15 }],
    [26, 'B', [[T_R(33), 3], [20, 4]], '광란의 폭풍', '멈추지 않는 회전, 흡혈', { cd: 0.3, ar: 0.3, dm: 0.5, vamp: 0.2 }],
    [18, 'A', [[T_R(14), 3], [27, 4]], '가시 왕관', '가시가 하늘을 덮고 적을 묶어요', { n: 6, dm: 0.5, slow: 1 }],
    [27, 'B', [[T_R(35), 3], [18, 4]], '만개', '꽃이 피어날 때마다 폭발', { boom: 0.4, ar: 0.3, dm: 0.5 }],
    [13, 'A', [[T_R(16), 3], [28, 4]], '별똥 곡예', '공 +2, 튕길 때 번개', { n: 2, dm: 0.6, zap: 0.15 }],
    [28, 'B', [[T_R(37), 3], [13, 4]], '얼음 폭풍우', '번개마다 얼음이 터져요', { frz: 0.25, dm: 0.6 }],
    [24, 'A', [[T_R(18), 3], [29, 4]], '태양새 군단', '불새 +1, 태양처럼 타올라요', { n: 1, dm: 0.6, burn: 6 }],
    [29, 'B', [[T_R(39), 3], [24, 4]], '하늘의 사냥꾼', '매 +1, 약한 적을 바로 처치', { n: 1, crit: 0.3, dm: 0.6, exe: 0.12 }],
  ].forEach((b) => EVO.push({ w: b[0], from: evoOf(b[0], b[1]), req: b[2], nm: b[3], d: b[4], m: b[5], base: 1, k: '2' }));
  EVO.forEach((e) => { e.ex = WP[e.w].ex; });
  const ebase = (w) => (w.e ? EVO[w.e - 1].base : 0);
  // relics (유물). r = rarity 0 일반, 1 희귀, 2 영웅, 3 전설. rk = risky trade-off. g = glyph
  const RAR = [{ nm: '일반', col: '#c8c0d4' }, { nm: '희귀', col: '#5ab0ff' }, { nm: '영웅', col: '#c58aff' }, { nm: '전설', col: '#ffb030' }];
  const RE = [
    { nm: '낡은 숫돌', r: 0, d: '모든 피해 +8%', g: 30 },
    { nm: '가벼운 장화', r: 0, d: '이동 속도 +8%', g: 35 },
    { nm: '두꺼운 외투', r: 0, d: '최대 체력 +25', g: 36 },
    { nm: '작은 자석', r: 0, d: '보석 줍는 거리 +40%', g: 38 },
    { nm: '모래 주머니', r: 0, d: '받는 피해 −1', g: 37 },
    { nm: '반짝 돋보기', r: 0, d: '공격 범위 +8%', g: 31 },
    { nm: '태엽 시계', r: 0, d: '공격 대기 시간 −5%', g: 32 },
    { nm: '행운 동전', r: 0, d: '치명타 +5%', g: 39 },
    { nm: '약초 주머니', r: 0, d: '초당 체력 +0.3', g: 8 },
    { nm: '빠른 깃', r: 0, d: '투사체 속도 +15% · 지속 시간 +10%', g: 42 },
    { nm: '도시락', r: 0, d: '얻자마자 체력 모두 회복 · 고기 회복 +50%', g: 90 },
    { nm: '경험 수첩', r: 0, d: '팀 경험치 +5%', g: 43 },
    { nm: '흡혈 이빨', r: 1, d: '처치할 때 8% 확률로 체력 +3', g: 40 },
    { nm: '폭발 씨앗', r: 1, d: '처치한 적이 10% 확률로 펑 터져요', g: 6 },
    { nm: '얼음 반지', r: 1, d: '맞힌 적을 10% 확률로 1초 얼려요', g: 5 },
    { nm: '가시 갑옷', r: 1, d: '나에게 닿은 적에게 피해 25를 되돌려요', g: 12 },
    { nm: '질풍 망토', r: 1, d: '대시 대기 −30% · 대시로 부딪힌 적에게 피해', g: 4 },
    { nm: '응원 깃발', r: 1, d: '팀 모두의 피해 +6%', g: 41 },
    { nm: '치유 종', r: 1, d: '15초마다 나와 근처 우리 편 체력 +15', g: 23 },
    { nm: '전기 장갑', r: 1, d: '25번 맞힐 때마다 근처 적 3마리에게 번개', g: 3 },
    { nm: '거인의 허리띠', r: 1, d: '최대 체력 +50 · 이동 −5%', g: 43 },
    { nm: '메아리 피리', r: 1, d: '발사 개수 +1', g: 33 },
    { nm: '불사조 깃털', r: 2, d: '쓰러질 때 한 번, 체력 절반으로 바로 일어나요', g: 24 },
    { nm: '시간 모래', r: 2, d: '레벨업할 때마다 적이 3초간 느려져요(팀)', g: 34 },
    { nm: '유리 대포', r: 2, rk: 1, d: '모든 피해 +40% · 최대 체력 −40%', g: 11 },
    { nm: '피의 계약', r: 2, rk: 1, d: '모든 피해 +25% · 초당 체력 −0.5', g: 36 },
    { nm: '광전사 투구', r: 2, d: '체력이 낮을수록 피해 증가(최대 +50%)', g: 20 },
    { nm: '번개 발걸음', r: 2, d: '걸어간 거리 120마다 근처 적에게 번개', g: 3 },
    { nm: '수호 천사', r: 2, d: '근처 우리 편이 쓰러질 피해를 받으면 1 남겨요(60초마다)', g: 37 },
    { nm: '쌍둥이 별', r: 2, d: '치명타 +10% · 치명타 피해 +50%', g: 9 },
    { nm: '왕관', r: 3, d: '피해·범위·이동·체력 +10% · 공격 대기 −10%', g: 41 },
    { nm: '무한 탄창', r: 3, d: '공격 대기 −20% · 발사 개수 +1', g: 0 },
    { nm: '검은 태양', r: 3, d: '4초마다 내 둘레에 큰 폭발', g: 2 },
    { nm: '생명의 나무', r: 3, d: '팀 모두 초당 체력 +1 · 친구 살리는 속도 2배', g: 27 },
    { nm: '현자의 돌', r: 3, d: '레벨업할 때마다 내 무기 하나가 저절로 +1', g: 22 },
    { nm: '저주받은 왕관', r: 3, rk: 1, d: '적이 25% 많고 세져요 · 팀 경험치 +50% · 피해 +30%', g: 16 },
  ];
  const RW_ELITE = [55, 30, 12, 3], RW_BOSS = [15, 40, 30, 15];
  // enemy behaviours
  const B_CHASE = 0, B_FLY = 1, B_GHOST = 2, B_TANK = 3, B_DASH = 4, B_RANGED = 5, B_SPLIT = 6, B_BOSS = 8;
  // enemy types: [name, r, hp, speed, dmg, xp, behaviour, colour, shape]
  const ET = [
    ['꼬마 해골', 9, 10, 40, 6, 1, B_CHASE, '#e8e2cf', 'skull'], ['밤 박쥐', 7, 6, 64, 4, 1, B_FLY, '#7a5aa0', 'bat'],
    ['떠돌이 유령', 10, 16, 34, 7, 2, B_GHOST, '#bfe3ff', 'ghost'], ['뼈 궁수', 9, 14, 30, 6, 2, B_RANGED, '#d8cfa8', 'archer'],
    ['무덤 골렘', 15, 70, 26, 12, 4, B_TANK, '#7d8a6a', 'golem'],
    ['버섯 졸개', 9, 12, 38, 6, 1, B_CHASE, '#d9584a', 'shroom'], ['말벌', 6, 5, 70, 4, 1, B_FLY, '#f2c230', 'bee'],
    ['덩굴 덩이', 12, 24, 30, 8, 2, B_SPLIT, '#4f9a4a', 'blob'], ['포자 꽃', 11, 20, 26, 6, 2, B_RANGED, '#c46bd1', 'flower'],
    ['나무 정령', 16, 80, 22, 12, 4, B_TANK, '#7a5a36', 'treant'],
    ['눈뭉치', 9, 12, 38, 6, 1, B_CHASE, '#eef6ff', 'snow'], ['얼음 박쥐', 7, 6, 66, 4, 1, B_FLY, '#7fc8f0', 'bat'],
    ['서리 늑대', 10, 18, 44, 8, 2, B_DASH, '#a8c0d8', 'wolf'], ['얼음 요정', 8, 14, 30, 6, 2, B_RANGED, '#a8f0ff', 'fairy'],
    ['설인', 16, 85, 24, 13, 4, B_TANK, '#e6ecf2', 'yeti'],
    ['불도마뱀', 9, 14, 42, 7, 1, B_DASH, '#ff7a3a', 'lizard'], ['불씨 정령', 7, 7, 66, 5, 1, B_FLY, '#ffc04a', 'flame'],
    ['용암 덩이', 12, 26, 30, 8, 2, B_SPLIT, '#e04a2a', 'blob'], ['재 마법사', 9, 16, 28, 6, 2, B_RANGED, '#5a4a5a', 'mage'],
    ['바위 거인', 17, 95, 22, 14, 5, B_TANK, '#8a6a5a', 'golem'],
    ['태엽 쥐', 8, 9, 56, 5, 1, B_CHASE, '#c0a080', 'mouse'], ['톱니 굴렁쇠', 10, 18, 40, 8, 2, B_DASH, '#b0b8c0', 'gear'],
    ['깡통 벌', 7, 7, 66, 5, 1, B_FLY, '#d8c060', 'bee'], ['증기 포탑병', 10, 18, 26, 6, 2, B_RANGED, '#8a9aa8', 'turret'],
    ['강철 기사', 16, 90, 24, 14, 5, B_TANK, '#7a8898', 'knight'],
    ['모래게', 9, 12, 40, 6, 1, B_CHASE, '#e07a4a', 'crab'], ['갈매기', 7, 6, 70, 4, 1, B_FLY, '#f0f0f0', 'bird'],
    ['해파리', 10, 16, 32, 7, 2, B_GHOST, '#f0a0e0', 'jelly'], ['물총 소라', 9, 16, 26, 6, 2, B_RANGED, '#f0c8a0', 'shell'],
    ['바위 거북', 16, 90, 22, 13, 5, B_TANK, '#6a8a6a', 'turtle'],
    // bosses (30..35)
    ['해골 왕', 30, 1500, 34, 20, 60, B_BOSS, '#efe6cc', 'skull'], ['썩은 고목', 32, 1700, 30, 20, 60, B_BOSS, '#6a5030', 'treant'],
    ['빙하 거인', 32, 1700, 32, 22, 60, B_BOSS, '#d6ecff', 'yeti'], ['화산 군주', 31, 1800, 32, 22, 60, B_BOSS, '#c83a1a', 'flame'],
    ['태엽 거신', 32, 1900, 30, 24, 60, B_BOSS, '#a0a8b0', 'knight'], ['큰 문어', 33, 1800, 32, 22, 60, B_BOSS, '#c05a9a', 'octo'],
    // new stages (36..50) and their bosses (51..53)
    ['독 전갈', 9, 13, 40, 7, 1, B_CHASE, '#c8783a', 'scorp'], ['모래 독수리', 8, 7, 68, 5, 1, B_FLY, '#a8784a', 'bird'],
    ['모래 벌레', 11, 20, 42, 8, 2, B_DASH, '#d8b878', 'worm'], ['붕대 주술사', 9, 16, 28, 6, 2, B_RANGED, '#e8e0c8', 'mummy'],
    ['사암 골렘', 17, 95, 22, 14, 5, B_TANK, '#c8a060', 'golem'],
    ['촛불 유령', 9, 15, 34, 7, 2, B_GHOST, '#ffe8a8', 'candle'], ['날개 찻잔', 7, 7, 66, 5, 1, B_FLY, '#e8f0ff', 'teacup'],
    ['실 거미', 11, 22, 34, 8, 2, B_SPLIT, '#4a3a5a', 'spider'], ['거울 그림자', 9, 16, 28, 6, 2, B_RANGED, '#7a6a9a', 'mage'],
    ['빈 갑옷', 16, 92, 24, 14, 5, B_TANK, '#8a8aa0', 'knight'],
    ['구름 양', 10, 13, 38, 6, 1, B_CHASE, '#f4f4fa', 'sheep'], ['바람 정령', 7, 7, 70, 5, 1, B_FLY, '#b8f0e0', 'fairy'],
    ['천둥 새', 9, 17, 46, 8, 2, B_DASH, '#ffe05a', 'bird'], ['구름 포탑', 10, 18, 26, 6, 2, B_RANGED, '#c8d8f0', 'cloud'],
    ['무지개 거북', 16, 92, 22, 13, 5, B_TANK, '#8ac8a0', 'turtle'],
    ['모래 왕 전갈', 32, 1900, 34, 23, 60, B_BOSS, '#d08a3a', 'scorp'], ['저택의 그림자', 31, 1800, 32, 22, 60, B_BOSS, '#3a2a4a', 'ghost'],
    ['폭풍 용', 33, 2000, 34, 24, 60, B_BOSS, '#5a8ad8', 'dragon'],
  ];
  const NB = 30;
  // stages. en: 5 enemy ids (introduced over time), hz: gimmick, pal: ground colours
  const STG = [
    { nm: '달빛 묘지', sub: '비석 사이 · 땅에서 손이 불쑥(잠깐 묶여요)', en: [0, 1, 2, 3, 4], boss: 30, hz: 'hand',
      pal: ['#1d2a26', '#24342e', '#3a4a40'], ob: { n: 46, r: [12, 20], col: '#7a8078', k: 'tomb' } },
    { nm: '버섯 숲', sub: '나무 사이 · 떠다니는 독 포자 구름', en: [5, 6, 7, 8, 9], boss: 31, hz: 'spore',
      pal: ['#1f3320', '#26402a', '#355a32'], ob: { n: 52, r: [16, 30], col: '#3a5a2a', k: 'tree' } },
    { nm: '얼음 동굴', sub: '미끄러운 빙판 · 떨어지는 고드름', en: [10, 11, 12, 13, 14], boss: 32, hz: 'icicle', ice: 1,
      pal: ['#2a3a52', '#33486a', '#4a6488'], ob: { n: 40, r: [14, 26], col: '#a8d0f0', k: 'crystal' } },
    { nm: '용암 협곡', sub: '용암 웅덩이 · 땅에서 불기둥', en: [15, 16, 17, 18, 19], boss: 33, hz: 'erupt', lava: 1,
      pal: ['#2a1c1c', '#36211c', '#4a2a20'], ob: { n: 38, r: [14, 28], col: '#5a4038', k: 'rock' } },
    { nm: '태엽 공장', sub: '움직이는 컨베이어 · 증기 분출구', en: [20, 21, 22, 23, 24], boss: 34, hz: 'steam', conv: 1,
      pal: ['#262a30', '#2e333a', '#3e4550'], ob: { n: 34, r: [14, 22], col: '#8a6a3a', k: 'crate' } },
    { nm: '별빛 해변', sub: '밀물이 들어오면 물속에서 느려져요', en: [25, 26, 27, 28, 29], boss: 35, hz: 'tide',
      pal: ['#5a4c34', '#66573c', '#7a6a4a'], ob: { n: 36, r: [14, 24], col: '#5a7a4a', k: 'palm' } },
    { nm: '모래 폭풍 사막', sub: '모래 폭풍이 불면 모두 바람에 밀려요', en: [36, 37, 38, 39, 40], boss: 51, hz: 'sand',
      pal: ['#6a5434', '#7a6240', '#8a7250'], ob: { n: 36, r: [14, 24], col: '#5a8a4a', k: 'cactus' } },
    { nm: '유령 저택', sub: '가끔 불이 꺼져요 · 내 둘레만 보여요', en: [41, 42, 43, 44, 45], boss: 52, hz: 'dark',
      pal: ['#2a2030', '#33283a', '#45364a'], ob: { n: 40, r: [14, 24], col: '#6a4a3a', k: 'furniture' } },
    { nm: '하늘 정원', sub: '구름 위 · 번개가 내리치는 자리를 피해요', en: [46, 47, 48, 49, 50], boss: 53, hz: 'storm',
      pal: ['#3a5a7a', '#45688a', '#5a7a9a'], ob: { n: 34, r: [16, 28], col: '#e8f0fa', k: 'cloud' } },
  ];
  const INTRO = [0, 0.1, 0.22, 0.36, 0.5];
  // boss attack patterns (by boss type id)
  const BPAT = { 30: ['ring', 'summon', 'charge', 'fan'], 31: ['summon', 'spiral', 'slam'], 32: ['charge', 'slam', 'ring'], 33: ['spiral', 'slam', 'fan'],
    34: ['charge', 'fan', 'ring', 'summon'], 35: ['spiral', 'summon', 'fan'], 51: ['charge', 'fan', 'slam'], 52: ['blink', 'spiral', 'summon'], 53: ['fan', 'spiral', 'charge', 'slam'] };

  /* ======================= map generation (deterministic, shared by host & guests) ======================= */
  function genMap(sg, seed) {
    const R = mkRng(seed), S = STG[sg] || STG[0], ob = [], pools = [], vents = [], conv = [];
    const C = WS / 2;
    if (S.conv) for (let k = 0; k < 4; k++) conv.push({ y: 330 + k * 440 + (R() - 0.5) * 60, h: 76, d: k % 2 ? -1 : 1 });
    const free = (x, y, r, pad) => {
      if (hyp(x - C, y - C) < 230 + r) return false;
      for (const o of ob) if (hyp(o.x - x, o.y - y) < o.r + r + pad) return false;
      for (const p of pools) if (hyp(p.x - x, p.y - y) < p.r + r + pad) return false;
      for (const c of conv) if (Math.abs(c.y - y) < c.h / 2 + r + 6) return false;
      return true;
    };
    if (S.lava) for (let k = 0, tries = 0; k < 8 && tries < 400; tries++) {
      const r = 40 + R() * 36, x = 120 + R() * (WS - 240), y = 120 + R() * (WS - 240);
      if (free(x, y, r, 60)) { pools.push({ x, y, r }); k++; }
    }
    for (let k = 0, tries = 0; k < S.ob.n && tries < 1500; tries++) {
      const r = S.ob.r[0] + R() * (S.ob.r[1] - S.ob.r[0]), x = 60 + R() * (WS - 120), y = 60 + R() * (WS - 120);
      if (free(x, y, r, 70)) { ob.push({ x, y, r, v: (R() * 4) | 0 }); k++; }
    }
    if (S.hz === 'steam') for (let k = 0, tries = 0; k < 16 && tries < 400; tries++) {
      const x = 100 + R() * (WS - 200), y = 100 + R() * (WS - 200);
      if (free(x, y, 30, 40)) { vents.push({ x, y }); k++; }
    }
    // obstacle grid (cells of 100)
    const OG = 20, og = [];
    for (let i = 0; i < OG * OG; i++) og.push([]);
    ob.forEach((o, i) => {
      const x0 = clamp(Math.floor((o.x - o.r - 40) / 100), 0, OG - 1), x1 = clamp(Math.floor((o.x + o.r + 40) / 100), 0, OG - 1);
      const y0 = clamp(Math.floor((o.y - o.r - 40) / 100), 0, OG - 1), y1 = clamp(Math.floor((o.y + o.r + 40) / 100), 0, OG - 1);
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) og[y * OG + x].push(i);
    });
    return { ob, pools, vents, conv, og };
  }
  const PO = { x: 0, y: 0, hit: 0 };
  function pushOut(M, x, y, r) {
    PO.x = x; PO.y = y; PO.hit = 0;
    const cx = clamp(Math.floor(x / 100), 0, 19), cy = clamp(Math.floor(y / 100), 0, 19), list = M.og[cy * 20 + cx];
    for (let k = 0; k < list.length; k++) {
      const o = M.ob[list[k]], dx = PO.x - o.x, dy = PO.y - o.y, m = o.r + r, d2 = dx * dx + dy * dy;
      if (d2 < m * m) { const d = Math.sqrt(d2) || 0.01; PO.x = o.x + dx / d * m; PO.y = o.y + dy / d * m; PO.hit = 1; }
    }
    return PO;
  }
  function inPool(M, x, y) { for (const p of M.pools) if (hyp(p.x - x, p.y - y) < p.r - 4) return 1; return 0; }
  function convAt(M, y) { for (const c of M.conv) if (Math.abs(c.y - y) < c.h / 2) return c.d; return 0; }

  /* ======================= player stats ======================= */
  function plvl(p, id) { for (const q of p.P) if (q.i === id) return q.l; return 0; }
  function tlvl(p, id) { for (const q of p.T) if (q.i === id) return q.l; return 0; }
  function hasR(p, id) { return p.R.indexOf(id) >= 0; }
  // team-wide relic effects (computed by recalcAll on the host; guests only need movement speed)
  const NOTEAM = { dm: 0, rg: 0, rv: 1 };
  function recalc(p, team) {
    const c = CH[p.ch] || CH[0], lv = (i) => plvl(p, i), tl = (i) => tlvl(p, i), has = (i) => hasR(p, i), tm = team || NOTEAM;
    const S = p.S || (p.S = {}), crown = has(30) ? 0.1 : 0;
    S.dm = (1 + 0.1 * lv(0) + 0.08 * has(0) + 0.4 * has(24) + 0.25 * has(25) + 0.3 * has(35) + crown + tm.dm) * (1 + 0.02 * (p.mt || 0));
    S.ar = 1 + 0.1 * lv(1) + (c.area || 0) + 0.08 * has(5) + crown + 0.05 * tl(11);
    S.cd = Math.max(0.35, (1 - 0.08 * lv(2) - 0.05 * has(6) - 0.2 * has(31)) * (1 - crown));
    S.am = lv(3) + has(21) + has(31);
    S.du = 1 + 0.15 * lv(4) + 0.1 * has(9);
    S.sp = 74 * (1 + 0.08 * lv(5) + (c.sp || 0) + 0.08 * has(1) - 0.05 * has(20) + crown);
    let mhp = (100 + 20 * lv(6) + (c.hp || 0) + 25 * has(2) + 50 * has(20)) * (1 + crown) * (has(24) ? 0.6 : 1);
    mhp = Math.round(mhp);
    if (p.mhp && mhp > p.mhp) p.hp += mhp - p.mhp;
    p.mhp = mhp; if (p.hp > mhp) p.hp = mhp;
    S.arm = lv(7) + (c.ar || 0) + has(4) + tl(9);
    S.aura = (p.ch === 4 ? 1 : 0) + tl(9);                 // armor given to allies nearby (방패 기사)
    S.pk = 46 * (1 + 0.3 * lv(8) + 0.4 * has(3));
    S.cr = 0.05 * lv(9) + 0.06 * tl(1) + 0.05 * has(7) + 0.1 * has(29);
    S.cm = 2 + 0.4 * tl(1) + 0.5 * has(29);
    S.ls = 0.03 * lv(10);
    S.rg = 0.25 * lv(11) + (c.rg || 0) + 0.3 * has(8) - 0.5 * has(25) + tm.rg;
    S.ps = 1 + 0.12 * lv(12) + (c.ps || 0) + 0.15 * has(9);
    S.xp = 0.06 * lv(13) + 0.05 * has(11) + 0.5 * has(35);
    S.hm = p.ch === 7 ? 1.3 : 1;                           // heal multiplier
    S.fd = has(10) ? 1.5 : 1;                              // food heal
    S.rvs = (p.ch === 7 ? 1.3 : 1) + 0.3 * tl(15);         // how fast I revive others
    S.tmR = tm.rv;
    S.dcd = 3.5 * (p.ch === 0 ? 0.6 : 1) * (has(16) ? 0.7 : 1);
    // character mechanics
    S.burn = p.ch === 1 ? 2.6 * (1 + 0.4 * tl(2)) : 0;      // burn dps (× damage mult at hit time)
    S.bnT = 2 + 0.5 * tl(2);
    S.slowB = p.ch === 2 ? 0.25 : 0;
    S.chill = tl(5) ? 0.6 + 0.4 * tl(5) : 0;
    S.mech = p.ch === 3 ? 1.2 : 1;
    S.ov = 1 - 0.12 * tl(6);
    S.bnc = p.ch === 8 ? 1 : 0;
    S.bird = p.ch === 9 ? 1.2 : 1;
    S.eb = 0.2 * tl(19);
    S.thn = 0.1 * tl(14);
    S.frzC = has(14) ? 0.1 : 0;
    S.zap = has(19) ? 1 : 0;
    S.kd = !!(has(12) || has(13) || tl(3) || tl(4) || tl(13));   // has on-kill effects
    // per-weapon mods from the weapon's evolution + traits that shape it
    p.sv = (p.sv | 0) + 1;
    const MW = p.MW || (p.MW = new Array(WP.length).fill(null));
    MW.fill(null);
    for (const w of p.W) {
      const m = {};
      if (w.e && EVO[w.e - 1]) addM(m, EVO[w.e - 1].m, 1);
      for (const t of p.T) { const q = TR[t.i]; if (q && q.w === w.i && q.m) addM(m, q.m, t.l); }
      MW[w.i] = m;
    }
    return S;
  }
  function addM(m, src, k) { for (const key in src) m[key] = (m[key] || 0) + src[key] * k; }
  // stats for one weapon (player stats × that weapon's mods), cached until the player's stats change
  function wst(p, w) {
    if (w._S && w._v === p.sv) return w._S;
    const o = w._S || (w._S = {}), m = p.MW && p.MW[w.i];
    Object.assign(o, p.S);
    o.heal = 0;
    if (m) {
      if (m.dm) o.dm *= 1 + m.dm;
      if (m.ar) o.ar *= 1 + m.ar;
      if (m.du) o.du *= 1 + m.du;
      if (m.ps) o.ps *= 1 + m.ps;
      if (m.cd) o.cd *= Math.max(0.3, 1 - m.cd);
      if (m.n) o.am += Math.floor(m.n + 1e-6);
      o.heal = m.heal || 0;
    }
    w._v = p.sv;
    return o;
  }
  // host: recompute every player's stats including team relic effects
  function recalcAll(W) {
    const tm = { dm: 0, rg: 0, rv: 1 };
    let curse = 0, sands = 0, stone = 0;
    for (const q of W.pl) {
      if (hasR(q, 17)) tm.dm += 0.06;
      if (hasR(q, 33)) { tm.rg += 1; tm.rv = 2; }
      if (hasR(q, 35)) curse++;
      if (hasR(q, 23)) sands++;
      if (hasR(q, 34)) stone++;
    }
    W.curse = curse; W.sands = sands; W.stone = stone;
    for (const q of W.pl) recalc(q, tm);
  }
  function heal(p, v) { if (!p.dn) p.hp = Math.min(p.mhp, p.hp + v * (p.S ? p.S.hm : 1)); }
  function newPlayer(s, ch, x, y) {
    const c = CH[ch] || CH[0];
    const p = { s, ch, x, y, vx: 0, vy: 0, fx: 1, fy: 0, hp: 100, mhp: 0, dn: 0, rv: 0, iv: 2, hc: 0, rt: 0, dc: 0, dt: 0, ddx: 0, ddy: 0,
      W: [], P: [], T: [], R: [], wd: new Array(WP.length).fill(0), tk: 0, kills: 0, dmg: 0, revs: 0, evo: 0, chest: 0, skips: 0,
      pq: [], off: null, offT: 0, rq: [], ro: null, roT: 0, mt: 0, S: null, hurtF: 0,
      dyn: 1, dcr: 0, still: 0, hitN: 0, mvd: 0, bsT: 4, hbT: 15, gaT: 0, phx: 0, rvT: 0, lt: 0 };
    p.W.push({ i: c.w, l: 1, e: 0, cd: 0.5, t: 0 });
    recalc(p); p.hp = p.mhp;
    return p;
  }

  /* ======================= world ======================= */
  function newWorld(st) {
    const M = genMap(st.sg, st.seed);
    const W = {
      st, M, sg: st.sg, S: STG[st.sg] || STG[0], np: st.np, dur: st.dur, T: 0, over: 0, win: 0,
      // enemies (SoA pool)
      ex: new Float32Array(MAXE), ey: new Float32Array(MAXE), ekx: new Float32Array(MAXE), eky: new Float32Array(MAXE),
      ehp: new Float32Array(MAXE), emh: new Float32Array(MAXE), et: new Uint8Array(MAXE), eel: new Uint8Array(MAXE),
      eal: new Uint8Array(MAXE), esl: new Float32Array(MAXE), efz: new Float32Array(MAXE), ecd: new Float32Array(MAXE),
      eoc: new Float32Array(MAXE), ewv: new Int32Array(MAXE), efl: new Float32Array(MAXE), eph: new Uint8Array(MAXE),
      er: new Float32Array(MAXE), esp: new Float32Array(MAXE), edm: new Float32Array(MAXE), exv: new Float32Array(MAXE),
      edx: new Float32Array(MAXE), edy: new Float32Array(MAXE), bdx: new Float32Array(MAXE), bdy: new Float32Array(MAXE), eag: new Float32Array(MAXE), ne: 0, hiE: 0, eptr: 0,
      ebn: new Float32Array(MAXE), ebd: new Float32Array(MAXE), ebo: new Int8Array(MAXE),
      // spatial grid
      gStart: new Int32Array(GW * GW + 1), gItems: new Int16Array(MAXE), gCell: new Int32Array(MAXE),
      // projectiles
      px: new Float32Array(MAXP), py: new Float32Array(MAXP), pvx: new Float32Array(MAXP), pvy: new Float32Array(MAXP),
      pL: new Float32Array(MAXP), pk: new Uint8Array(MAXP), pdm: new Float32Array(MAXP), ppi: new Int16Array(MAXP),
      po: new Int8Array(MAXP), pw: new Int8Array(MAXP), pr: new Float32Array(MAXP), pa: new Float32Array(MAXP), pb: new Float32Array(MAXP),
      pt: new Float32Array(MAXP), ptg: new Int16Array(MAXP), pmem: new Int16Array(MAXP * 4), pal: new Uint8Array(MAXP), nP: 0, hiP: 0,
      // gems & items: kind 0-3 gem tiers, 4 food, 5 magnet, 6 clock, 7 chest, 8 big chest
      gx: new Float32Array(MAXG), gy: new Float32Array(MAXG), gv: new Float32Array(MAXG), gk: new Uint8Array(MAXG),
      gal: new Uint8Array(MAXG), gm: new Int8Array(MAXG), nG: 0,
      pl: [], Z: [], zid: 0, fx: [], fq: 0, dq: [], kills: 0, lv: 1, xp: 0, chests: 0, bosses: 0, bossI: [],
      spT: 0, evT: 110, wind: null, dark: null, eliteT: 75, nextBoss: 0, bossN: 0, hzT: 20, waveT: 150, wid: 1, bid: 0, oq: 0, frz: 0, tide: null, tideT: 40,
      paused: 0, solo: 1, lastSpawnSeat: 0, dfr: [], curse: 0, sands: 0, stone: 0, slowT: 0,
    };
    W.bossAt = bossTimes(st.dur);
    const C = WS / 2;
    for (let i = 0; i < st.np; i++) {
      const a = -Math.PI / 2 + i * TAU / st.np, rr = st.np > 1 ? 34 : 0;
      W.pl.push(newPlayer(i, st.ch && st.ch[i] >= 0 ? st.ch[i] : 0, C + Math.cos(a) * rr, C + Math.sin(a) * rr));
    }
    if (W.S.hz === 'spore') for (let k = 0; k < 3; k++) addSpore(W);
    recalcAll(W);
    return W;
  }
  function bossTimes(dur) {
    const out = [];
    for (let t = 300; t < dur - 90; t += 300) out.push(t);
    out.push(dur - 60);
    return out;
  }
  function fx(W, k, x, y, a, b) {
    W.fq++;
    W.fx.push([W.fq, k, Math.round(x), Math.round(y), a | 0, b | 0]);
    if (W.fx.length > 40) W.fx.splice(0, W.fx.length - 40);
  }
  const prog = (W) => W.T / 600;   // difficulty clock (10 min = 1)
  // difficulty: starts gentle and ramps up with time; more players → more and tougher enemies
  const npMul = (W) => 0.3 + 0.7 * W.np;   // density: 1p 1.0 · 2p 1.7 · 3p 2.4 · 4p 3.1
  function hpMul(W) { const f = Math.min(prog(W), 2.4); return (0.75 + 0.5 * f + 3.4 * f * f) * (0.6 + 0.4 * W.np) * (1 + 0.2 * W.curse); }

  /* ---------- enemies ---------- */
  function addE(W, t, x, y, elite) {
    let i = -1;
    for (let k = 0; k < MAXE; k++) { const j = (W.eptr + k) % MAXE; if (!W.eal[j]) { i = j; break; } }
    if (i < 0) return -1;
    W.eptr = (i + 1) % MAXE;
    const T = ET[t], boss = T[6] === B_BOSS, f = prog(W);
    let hp = T[2] * hpMul(W);
    if (elite) hp = hp * 14 + 120;
    if (boss) hp = T[2] * (1 + 0.55 * W.bossN) * (0.6 + 0.4 * W.np) * (1 + 0.5 * f);
    W.eal[i] = 1; W.et[i] = t; W.eel[i] = elite ? 1 : 0; W.ex[i] = x; W.ey[i] = y; W.ekx[i] = 0; W.eky[i] = 0;
    W.ehp[i] = hp; W.emh[i] = hp; W.esl[i] = 0; W.efz[i] = 0; W.ecd[i] = 1 + Math.random() * 2; W.eoc[i] = 0; W.ewv[i] = 0;
    W.efl[i] = 0; W.eph[i] = 0; W.eag[i] = 0; W.ebn[i] = 0; W.ebd[i] = 0;
    W.er[i] = T[1] * (elite ? 1.55 : 1);
    W.esp[i] = T[3] * (0.94 + 0.2 * Math.min(1.5, f)) * (elite ? 0.9 : 1) * (0.92 + Math.random() * 0.16);
    W.edm[i] = T[4] * (0.5 + 1.3 * Math.min(f, 2)) * (elite ? 1.5 : 1) * (1 + 0.15 * W.curse) * (0.9 + 0.1 * W.np);
    W.exv[i] = boss ? T[5] : elite ? 12 : T[5];
    W.edx[i] = 0; W.edy[i] = 0;
    W.ne++; if (i >= W.hiE) W.hiE = i + 1;
    return i;
  }
  function remE(W, i) {
    if (!W.eal[i]) return;
    W.eal[i] = 0; W.ne--;
    if (i === W.hiE - 1) { let h = i; while (h > 0 && !W.eal[h - 1]) h--; W.hiE = h; }
  }
  function alivePl(W) { const o = []; for (const p of W.pl) if (!p.dn) o.push(p); return o; }
  function spawnPos(W, p, dist) {
    for (let k = 0; k < 10; k++) {
      const a = Math.random() * TAU, d = dist + Math.random() * 60, x = p.x + Math.cos(a) * d, y = p.y + Math.sin(a) * d;
      if (x < 20 || y < 20 || x > WS - 20 || y > WS - 20) continue;
      let near = false;
      for (const q of W.pl) if (!q.dn && hyp(q.x - x, q.y - y) < dist - 40) { near = true; break; }
      if (near) continue;
      const o = pushOut(W.M, x, y, 12);
      if (o.hit) continue;
      return [x, y];
    }
    return null;
  }
  function director(W, h) {
    const al = alivePl(W);
    if (!al.length) return;
    const f = prog(W), S = W.S, pm = npMul(W), fc = Math.min(f, 2.2);
    const target = Math.min(MAXE - 20, (5 + 40 * fc + 190 * Math.pow(fc, 1.5)) * pm * (1 + 0.25 * W.curse));
    W.spT -= h;
    if (W.spT <= 0) {
      W.spT = 0.25;
      const need = target - W.ne;
      if (need > 0) {
        const n = Math.min(Math.ceil(need), Math.round((2 + 26 * Math.min(f, 2)) * pm * 0.25 + 1));
        const intro = INTRO.map((v) => v * Math.min(W.dur, 900)), avail = [];
        S.en.forEach((t, k) => { if (W.T >= intro[k]) avail.push(t); });
        for (let k = 0; k < n; k++) {
          const p = al[(W.lastSpawnSeat++) % al.length], pos = spawnPos(W, p, SPAWN_R);
          if (!pos) continue;
          // weight: newer types appear more as time goes on; tanks rarer
          let t = avail[Math.floor(Math.random() * avail.length)];
          if (ET[t][6] === B_TANK && Math.random() < 0.5) t = avail[0];
          addE(W, t, pos[0], pos[1], 0);
        }
      }
    }
    // elite every minute (not when a boss is due)
    W.eliteT -= h;
    if (W.eliteT <= 0) {
      W.eliteT = W.T > 300 ? 55 : 70;
      const p = al[Math.floor(Math.random() * al.length)], pos = spawnPos(W, p, SPAWN_R - 40);
      if (pos) {
        const pool = S.en.filter((t, k) => W.T >= INTRO[k] * Math.min(W.dur, 900));
        const i = addE(W, pool[Math.floor(Math.random() * pool.length)], pos[0], pos[1], 1);
        if (i >= 0) fx(W, 8, pos[0], pos[1], i, 0);
      }
    }
    // swarm line (fliers crossing) every ~60s after 1:40
    W.waveT -= h;
    if (W.waveT <= 0) {
      W.waveT = 55 + Math.random() * 15;
      const p = al[Math.floor(Math.random() * al.length)], a = Math.random() * TAU, n = 6 + Math.round(10 * Math.min(f, 1.5));
      const fly = S.en[1], dx = Math.cos(a), dy = Math.sin(a), sx = p.x - dx * 380, sy = p.y - dy * 380;
      for (let k = 0; k < n; k++) {
        const off = (k - n / 2) * 18, x = sx - dy * off + (Math.random() - 0.5) * 12, y = sy + dx * off;
        if (x < 10 || y < 10 || x > WS - 10 || y > WS - 10) continue;
        const i = addE(W, fly, x, y, 0);
        if (i >= 0) { W.eph[i] = 9; W.edx[i] = dx; W.edy[i] = dy; W.esp[i] *= 1.25; }
      }
    }
    // map events (every ~100-130 s, not right before a boss)
    W.evT -= h;
    if (W.evT <= 0) {
      W.evT = 100 + Math.random() * 30;
      const nb = W.bossAt[W.bossN];
      if (!(nb && nb - W.T < 25) && W.T < W.dur - 40) mapEvent(W, al);
    }
    // bosses
    if (W.bossN < W.bossAt.length && W.T >= W.bossAt[W.bossN]) {
      const p = al[Math.floor(Math.random() * al.length)], pos = spawnPos(W, p, 330) || [clamp(p.x + 300, 60, WS - 60), p.y];
      const i = addE(W, S.boss, pos[0], pos[1], 0);
      W.bossN++;
      if (i >= 0) { W.bossI.push(i); fx(W, 7, pos[0], pos[1], i, W.bossN === W.bossAt.length ? 1 : 0); }
    }
  }

  function mapEvent(W, al) {
    const ev = Math.floor(Math.random() * 4), p = al[Math.floor(Math.random() * al.length)];
    if (ev === 0) {          // supply drop: one relic chest + food + magnet
      [7, 4, 5].forEach((kd) => { const a = Math.random() * TAU, d = 90 + Math.random() * 160; addG(W, clamp(p.x + Math.cos(a) * d, 30, WS - 30), clamp(p.y + Math.sin(a) * d, 30, WS - 30), 0, kd); });
    } else if (ev === 1) {   // elite pack
      const pool = W.S.en.filter((t, k) => W.T >= INTRO[k] * Math.min(W.dur, 900));
      for (let k = 0; k < 3; k++) { const pos = spawnPos(W, p, SPAWN_R - 30); if (pos) addE(W, pool[Math.floor(Math.random() * pool.length)], pos[0], pos[1], 1); }
    } else if (ev === 2) {   // gem shower
      for (let k = 0; k < 24; k++) { const a = Math.random() * TAU, d = 60 + Math.random() * 220; addG(W, clamp(p.x + Math.cos(a) * d, 20, WS - 20), clamp(p.y + Math.sin(a) * d, 20, WS - 20), 4 + Math.round(prog(W) * 6), 0); }
    } else {                 // encircling ring
      const t = W.S.en[0], n = 36;
      for (let k = 0; k < n; k++) { const a = k * TAU / n, x = p.x + Math.cos(a) * 330, y = p.y + Math.sin(a) * 330; if (x > 20 && y > 20 && x < WS - 20 && y < WS - 20 && !pushOut(W.M, x, y, 10).hit) addE(W, t, x, y, 0); }
    }
    fx(W, 17, p.x, p.y, 10 + ev, 0);
  }

  /* ---------- spatial grid ---------- */
  function buildGrid(W) {
    const gs = W.gStart, gi = W.gItems, gc = W.gCell, n = GW * GW;
    gs.fill(0);
    for (let i = 0; i < W.hiE; i++) {
      if (!W.eal[i]) { gc[i] = -1; continue; }
      const c = clamp((W.ey[i] / CS) | 0, 0, GW - 1) * GW + clamp((W.ex[i] / CS) | 0, 0, GW - 1);
      gc[i] = c; gs[c + 1]++;
    }
    for (let c = 0; c < n; c++) gs[c + 1] += gs[c];
    const fillP = W._fp || (W._fp = new Int32Array(n));
    fillP.set(gs.subarray(0, n));
    for (let i = 0; i < W.hiE; i++) { const c = gc[i]; if (c >= 0) gi[fillP[c]++] = i; }
  }
  const QB = new Int16Array(MAXE);
  // enemies whose cell lies within the square around (x,y,r) → QB, returns count
  function query(W, x, y, r) {
    const x0 = clamp(((x - r) / CS) | 0, 0, GW - 1), x1 = clamp(((x + r) / CS) | 0, 0, GW - 1);
    const y0 = clamp(((y - r) / CS) | 0, 0, GW - 1), y1 = clamp(((y + r) / CS) | 0, 0, GW - 1);
    let n = 0;
    for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) {
      const c = cy * GW + cx, a = W.gStart[c], b = W.gStart[c + 1];
      for (let k = a; k < b; k++) QB[n++] = W.gItems[k];
    }
    return n;
  }
  function nearestE(W, x, y, range) {
    let best = -1, bd = range * range;
    for (let i = 0; i < W.hiE; i++) {
      if (!W.eal[i]) continue;
      const dx = W.ex[i] - x, dy = W.ey[i] - y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  const NN = [], ND = [];
  function nearestN(W, x, y, range, n) {
    NN.length = 0; ND.length = 0;
    const r2 = range * range;
    for (let i = 0; i < W.hiE; i++) {
      if (!W.eal[i]) continue;
      const dx = W.ex[i] - x, dy = W.ey[i] - y, d = dx * dx + dy * dy;
      if (d > r2) continue;
      if (NN.length < n) { NN.push(i); ND.push(d); }
      else { let w = 0; for (let k = 1; k < n; k++) if (ND[k] > ND[w]) w = k; if (d < ND[w]) { NN[w] = i; ND[w] = d; } }
    }
    return NN;
  }
  function randomE(W, x, y, range, n) {
    NN.length = 0; let seen = 0; const r2 = range * range;
    for (let i = 0; i < W.hiE; i++) {
      if (!W.eal[i]) continue;
      const dx = W.ex[i] - x, dy = W.ey[i] - y;
      if (dx * dx + dy * dy > r2) continue;
      seen++;
      if (NN.length < n) NN.push(i); else { const j = Math.floor(Math.random() * seen); if (j < n) NN[j] = i; }
    }
    return NN;
  }

  /* ---------- damage ---------- */
  let ZAPPING = 0;
  function isBossE(W, i) { return ET[W.et[i]][6] === B_BOSS; }
  function hurtE(W, i, dmg, o, kx, ky, kb) {
    if (!W.eal[i]) return;
    const p = W.pl[o], boss = isBossE(W, i);
    if (p) {
      const S = p.S;
      dmg *= p.dyn;
      if (S.slowB && (W.esl[i] > 0 || W.efz[i] > 0)) dmg *= 1 + S.slowB;
      if (S.eb && (boss || W.eel[i])) dmg *= 1 + S.eb;
      if (Math.random() < S.cr + (p.dcr > 0 ? 0.25 : 0)) { dmg *= S.cm; if (W.crit && W.crit.length < 60) W.crit.push(W.ex[i], W.ey[i], dmg, o); }
      if (S.burn) { W.ebn[i] = S.bnT; W.ebd[i] = Math.max(W.ebd[i], S.burn * S.dm); W.ebo[i] = o; }
      if (S.chill) W.esl[i] = Math.max(W.esl[i], S.chill);
      if (S.frzC && !boss && Math.random() < S.frzC) W.efz[i] = Math.max(W.efz[i], 1);
      if (S.zap && !ZAPPING && ++p.hitN >= 25) { p.hitN = 0; W.dfr.push(1, W.ex[i], W.ey[i], 3, 30 * S.dm, o); }
      // weapon mods from evolutions / path traits
      const M = CURW >= 0 && p.MW ? p.MW[CURW] : null;
      if (M) {
        if (M.crit && Math.random() < M.crit) dmg *= S.cm;
        if (M.burn) { W.ebn[i] = Math.max(W.ebn[i], 2.5); W.ebd[i] = Math.max(W.ebd[i], M.burn * S.dm); W.ebo[i] = o; }
        if (M.slow) W.esl[i] = Math.max(W.esl[i], M.slow);
        if (M.frz && !boss && Math.random() < M.frz) W.efz[i] = Math.max(W.efz[i], 0.8);
        if (M.exe && !boss && W.ehp[i] - dmg < W.emh[i] * M.exe) dmg = W.ehp[i] + 1;
        if (M.vamp && !p.dn && Math.random() < M.vamp) heal(p, 1);
        if (!ZAPPING && W.dfr.length < 180) {
          if (M.boom && Math.random() < M.boom) W.dfr.push(0, W.ex[i], W.ey[i], 40, Math.min(dmg * 0.6, 400 * S.dm), o);
          if (M.zap && Math.random() < M.zap) W.dfr.push(1, W.ex[i], W.ey[i], 2, Math.min(dmg * 0.5, 300 * S.dm), o);
        }
      }
    }
    W.ehp[i] -= dmg; W.efl[i] = 0.1;
    if (W.hq && W.hq.length < 60) W.hq.push(W.ex[i], W.ey[i], CURW);
    if (p) { p.dmg += dmg; if (CURW >= 0 && CURW < p.wd.length) p.wd[CURW] += dmg; }
    const b = ET[W.et[i]][6];
    if (kb && b !== B_BOSS) {
      const res = b === B_TANK || W.eel[i] ? 0.35 : 1, d = hyp(kx, ky) || 1;
      W.ekx[i] += kx / d * kb * res; W.eky[i] += ky / d * kb * res;
    }
    if (W.ehp[i] <= 0) killE(W, i, o);
  }
  // deferred effects (explosions / zaps triggered inside loops): [type, x, y, a, dmg, owner]
  function runDeferred(W) {
    const q = W.dfr; let n = 0;
    while (q.length && n++ < 40) {
      const t = q.shift(), x = q.shift(), y = q.shift(), a = q.shift(), dm = q.shift(), o = q.shift();
      CURW = -1;
      if (t === 0) explode(W, x, y, a, dm, o, 60, 3);
      else if (t === 1) zap(W, x, y, a | 0, dm, o);
      else if (t === 2) explode(W, x, y, a, dm, o, 120, 4);
    }
    if (q.length > 240) q.length = 0;
  }
  function zap(W, x, y, n, dm, o) {
    ZAPPING = 1;
    const T = nearestN(W, x, y, 220, n).slice();
    for (const t of T) { if (!W.eal[t]) continue; fx(W, 1, W.ex[t], W.ey[t], o, 0); hurtE(W, t, dm, o, 0, 0, 0); }
    ZAPPING = 0;
  }
  function killE(W, i, o) {
    const t = W.et[i], T = ET[t], x = W.ex[i], y = W.ey[i], el = W.eel[i], boss = T[6] === B_BOSS;
    const burning = W.ebn[i] > 0, chilled = W.esl[i] > 0 || W.efz[i] > 0;
    remE(W, i);
    W.ebn[i] = 0; W.ebd[i] = 0;
    W.kills++;
    W.dq.push(x, y, t, el || boss ? 1 : 0);
    if (W.dq.length > 400) W.dq.splice(0, W.dq.length - 400);
    const p = W.pl[o];
    if (p) {
      p.kills++;
      const S = p.S;
      if (!p.dn) {
        if (S.ls > 0 && Math.random() < S.ls) heal(p, 3);
        if (S.kd) {
          if (hasR(p, 12) && Math.random() < 0.08) heal(p, 3);
          if (hasR(p, 13) && Math.random() < 0.1) W.dfr.push(0, x, y, 45, 20 * S.dm, o);
          const bl = tlvl(p, 13); if (bl && Math.random() < 0.2) heal(p, 1 + bl);
          const em = tlvl(p, 3); if (em && burning) W.dfr.push(0, x, y, 36 + 8 * em, (10 + 8 * em) * S.dm, o);
          const sh = tlvl(p, 4);
          if (sh && chilled) { const n = 3 + sh, a0 = Math.random() * TAU; CURW = 5; for (let k = 0; k < n; k++) addP(W, K.FROST, x, y, a0 + k * TAU / n, 260 * S.ps, 0.5, (8 + 4 * sh) * S.dm, 1, o, 4); }
        }
      }
    }
    if (W.eph[i] === 9) { if (Math.random() < 0.5) addG(W, x, y, 1, 0); return; }
    if (boss) {
      W.bosses++;
      const k = W.bossI.indexOf(i); if (k >= 0) W.bossI.splice(k, 1);
      addG(W, x, y, 0, 8); addG(W, x + 24, y, 0, 4);
      for (let k2 = 0; k2 < 6; k2++) addG(W, x + (Math.random() - 0.5) * 60, y + (Math.random() - 0.5) * 60, 15, 0);
      fx(W, 9, x, y, t, 0);
      return;
    }
    if (el) {
      if (Math.random() < 0.3) addG(W, x, y, 0, 7); else addG(W, x, y, 0, Math.random() < 0.5 ? 4 : 5);
      addG(W, x + 12, y + 6, 12, 0); fx(W, 0, x, y, 40, 3); return;
    }
    addG(W, x, y, W.exv[i], 0);
    const r = Math.random();
    if (r < 0.004) addG(W, x + 6, y, 0, 4); else if (r < 0.005) addG(W, x + 6, y, 0, 5); else if (r < 0.0058) addG(W, x + 6, y, 0, 6); else if (r < 0.0059) addG(W, x + 6, y, 0, 7);
    if (T[6] === B_SPLIT && W.ne < MAXE - 4) {
      const kid = W.S.en[0];
      for (let k = 0; k < 2; k++) { const j = addE(W, kid, x + (k ? 7 : -7), y, 0); if (j >= 0) { W.er[j] *= 0.8; W.ehp[j] *= 0.5; } }
    }
  }
  function gemTier(v) { return v < 3 ? 0 : v < 10 ? 1 : v < 40 ? 2 : 3; }
  function addG(W, x, y, v, kind) {
    if (kind === 0 && v <= 0) return;
    let j = -1;
    for (let k = 0; k < MAXG; k++) if (!W.gal[k]) { j = k; break; }
    if (j < 0) {
      if (kind) { // need room for an item: overwrite a gem far away, folding its value into another gem
        let far = -1;
        for (let k = 0; k < MAXG; k++) if (W.gk[k] < 4 && W.gm[k] < 0) { far = k; break; }
        if (far < 0) return;
        const v2 = W.gv[far]; W.gal[far] = 0; W.nG--;
        for (let k = 0; k < MAXG; k++) if (W.gal[k] && W.gk[k] < 4) { W.gv[k] += v2; W.gk[k] = gemTier(W.gv[k]); break; }
        j = far;
      } else {
        // merge into the closest gem
        let best = -1, bd = 1e12;
        for (let k = 0; k < MAXG; k++) { if (!W.gal[k] || W.gk[k] > 3) continue; const d = (W.gx[k] - x) ** 2 + (W.gy[k] - y) ** 2; if (d < bd) { bd = d; best = k; } }
        if (best >= 0) { W.gv[best] += v; W.gk[best] = gemTier(W.gv[best]); }
        return;
      }
    }
    W.gal[j] = 1; W.nG++; W.gx[j] = clamp(x, 8, WS - 8); W.gy[j] = clamp(y, 8, WS - 8); W.gv[j] = v; W.gm[j] = -1;
    W.gk[j] = kind || gemTier(v);
  }

  /* ---------- projectiles ---------- */
  const K = { BOLT: 0, BOLTE: 1, BOOM: 2, BOOME: 3, FROST: 4, FROSTE: 5, BOMB: 6, WISP: 7, WISPE: 8, BNC: 9, BNCE: 10, DRB: 11,
    EB: 12, PUD: 13, PUDE: 14, MINE: 15, TORN: 16, MET: 17, WAVE: 18, WAVEE: 19, BEAM: 20, BEAME: 21, BB: 22, DBL: 23,
    KNF: 24, KNFE: 25, THN: 26, FIRE: 27, AXE: 28, SPR: 29, TUR: 30, TURE: 31, FLW: 32, FLWE: 33, HAWK: 34, HAWKE: 35, TORNE: 36 };
  const MOVING = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1];
  // drawn under the players (ground zones / placed objects)
  const GROUND = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1];
  const isTorn = (k) => k === K.TORN || k === K.TORNE;
  let CURW = -1;   // weapon currently dealing damage (for the per-weapon damage table)
  function addP(W, k, x, y, a, sp, life, dmg, pierce, o, r) {
    let i = -1;
    for (let q = 0; q < MAXP; q++) if (!W.pal[q]) { i = q; break; }
    if (i < 0) return -1;
    W.pal[i] = 1; W.nP++; if (i >= W.hiP) W.hiP = i + 1;
    W.pk[i] = k; W.px[i] = x; W.py[i] = y; W.pvx[i] = Math.cos(a) * sp; W.pvy[i] = Math.sin(a) * sp; W.pL[i] = life;
    W.pdm[i] = dmg; W.ppi[i] = pierce; W.po[i] = o; W.pw[i] = CURW; W.pr[i] = r; W.pa[i] = 0; W.pb[i] = 0; W.pt[i] = 0; W.ptg[i] = -1;
    const m = i * 4; W.pmem[m] = W.pmem[m + 1] = W.pmem[m + 2] = W.pmem[m + 3] = -1;
    return i;
  }
  function remP(W, i) {
    if (!W.pal[i]) return;
    W.pal[i] = 0; W.nP--;
    if (i === W.hiP - 1) { let h = i; while (h > 0 && !W.pal[h - 1]) h--; W.hiP = h; }
  }
  function memHas(W, i, e) { const m = i * 4; return W.pmem[m] === e || W.pmem[m + 1] === e || W.pmem[m + 2] === e || W.pmem[m + 3] === e; }
  function memAdd(W, i, e) { const m = i * 4; W.pmem[m + 3] = W.pmem[m + 2]; W.pmem[m + 2] = W.pmem[m + 1]; W.pmem[m + 1] = W.pmem[m]; W.pmem[m] = e; }
  function explode(W, x, y, r, dmg, o, kb, style) {
    const n = query(W, x, y, r + 40);
    for (let k = 0; k < n; k++) {
      const i = QB[k], dx = W.ex[i] - x, dy = W.ey[i] - y, rr = r + W.er[i];
      if (dx * dx + dy * dy < rr * rr) hurtE(W, i, dmg, o, dx, dy, kb);
    }
    fx(W, 0, x, y, r, style | 0);
  }
  function zoneHit(W, x, y, r, dmg, o, slow, pull) {
    const n = query(W, x, y, r + 40);
    for (let k = 0; k < n; k++) {
      const i = QB[k], dx = W.ex[i] - x, dy = W.ey[i] - y, rr = r + W.er[i] * 0.6;
      if (dx * dx + dy * dy >= rr * rr) continue;
      if (slow) W.esl[i] = Math.max(W.esl[i], slow);
      if (pull && ET[W.et[i]][6] !== B_BOSS) { const d = hyp(dx, dy) || 1; W.ekx[i] -= dx / d * pull; W.eky[i] -= dy / d * pull; }
      hurtE(W, i, dmg, o, 0, 0, 0);
    }
  }
  function stepProj(W, h) {
    for (let i = 0; i < W.hiP; i++) {
      if (!W.pal[i]) continue;
      const k = W.pk[i];
      W.pL[i] -= h; W.pt[i] += h;
      const o = W.po[i], p = W.pl[o];
      CURW = W.pw[i];
      if (k === K.AXE) W.pvy[i] += 620 * h;
      if (k === K.WISP || k === K.WISPE) {
        let t = W.ptg[i];
        if (t < 0 || !W.eal[t]) { t = nearestE(W, W.px[i], W.py[i], 320); W.ptg[i] = t; }
        if (t >= 0) steer(W, i, W.ex[t], W.ey[t], 6 * h);
      } else if ((k === K.HAWK || k === K.HAWKE) && p) {
        if (!W.pb[i]) {   // hunting: home in on the target
          let t = W.ptg[i];
          if (t < 0 || !W.eal[t]) { t = pickPrey(W, W.px[i], W.py[i], 360); W.ptg[i] = t; }
          if (t >= 0) steer(W, i, W.ex[t], W.ey[t], 7 * h);
          if (W.pt[i] > 2.2) W.pb[i] = 1;
        } else {           // fly back to the owner
          steer(W, i, p.x, p.y, 9 * h);
          if ((p.x - W.px[i]) ** 2 + (p.y - W.py[i]) ** 2 < 20 * 20 || W.pt[i] > 5) { remP(W, i); continue; }
        }
        W.pL[i] = 1;
      } else if ((k === K.BOOM || k === K.BOOME) && p) {
        if (W.pt[i] > W.pa[i]) { // returning
          if (!W.pb[i]) { W.pb[i] = 1; const m = i * 4; W.pmem[m] = W.pmem[m + 1] = W.pmem[m + 2] = W.pmem[m + 3] = -1; }
          const dx = p.x - W.px[i], dy = p.y - W.py[i], d = hyp(dx, dy) || 1, sp = hyp(W.pvx[i], W.pvy[i]);
          const ax = dx / d * sp, ay = dy / d * sp;
          W.pvx[i] += (ax - W.pvx[i]) * Math.min(1, h * 7); W.pvy[i] += (ay - W.pvy[i]) * Math.min(1, h * 7);
          if (d < 16) { remP(W, i); continue; }
        }
      } else if (isTorn(k)) {
        const sp0 = k === K.TORNE ? 90 : 75;
        if (Math.random() < h * 1.5) { const t = nearestE(W, W.px[i], W.py[i], 200), a = t >= 0 && Math.random() < 0.7 ? Math.atan2(W.ey[t] - W.py[i], W.ex[t] - W.px[i]) : Math.random() * TAU; W.pvx[i] = Math.cos(a) * sp0; W.pvy[i] = Math.sin(a) * sp0; }
        if (W.px[i] < 30 || W.px[i] > WS - 30) W.pvx[i] = W.px[i] < 30 ? 70 : -70;
        if (W.py[i] < 30 || W.py[i] > WS - 30) W.pvy[i] = W.py[i] < 30 ? 70 : -70;
      } else if (k === K.WAVE || k === K.WAVEE) {
        W.pr[i] = W.pa[i] * Math.min(1, W.pt[i] / 0.45);
      }
      if (MOVING[k]) { W.px[i] += W.pvx[i] * h; W.py[i] += W.pvy[i] * h; }
      if (k === K.WAVE || k === K.WAVEE) { if (p) { W.px[i] = p.x; W.py[i] = p.y; } }
      const x = W.px[i], y = W.py[i];
      if (x < -60 || y < -60 || x > WS + 60 || y > WS + 60) { remP(W, i); continue; }
      switch (k) {
        case K.EB: case K.BB: {
          for (const q of W.pl) {
            if (q.dn || q.iv > 0 || (q.off || q.ro) && !W.solo) continue;
            const rr = W.pr[i] * 0.8 + PR * 0.6;
            if ((q.x - x) ** 2 + (q.y - y) ** 2 < rr * rr) { SRC = 'bul'; hurtP(W, q, W.pdm[i]); SRC = 'hz'; W.pL[i] = 0; break; }
          }
          if (k === K.EB && pushOut(W.M, x, y, 3).hit) W.pL[i] = 0;
          break;
        }
        case K.BOMB:
          if (W.pL[i] <= 0) {
            explode(W, W.pa[i], W.pb[i], W.pr[i], W.pdm[i], o, 90, 1);
            if (W.ptg[i] === 1) for (let q = 0; q < 3; q++) {
              const a = q * TAU / 3 + Math.random(), j = addP(W, K.DBL, W.pa[i] + Math.cos(a) * W.pr[i], W.pb[i] + Math.sin(a) * W.pr[i], 0, 0, 0.22 + q * 0.1, W.pdm[i] * 0.6, 0, o, W.pr[i] * 0.7);
              if (j < 0) break;
            }
          }
          break;
        case K.DBL:
          if (W.pL[i] <= 0) explode(W, x, y, W.pr[i], W.pdm[i], o, 60, 1);
          break;
        case K.MET:
          if (W.pL[i] <= 0) explode(W, x, y, W.pr[i], W.pdm[i], o, 140, 2);
          break;
        case K.MINE: {
          if (W.pt[i] < 0.5) break;
          const n = query(W, x, y, 40);
          let boom = 0;
          for (let q = 0; q < n; q++) { const e = QB[q]; if ((W.ex[e] - x) ** 2 + (W.ey[e] - y) ** 2 < (14 + W.er[e]) ** 2) { boom = 1; break; } }
          if (boom) {
            explode(W, x, y, W.pr[i], W.pdm[i], o, 120, 1); W.pL[i] = 0;
            if (W.pb[i] === 1) for (let q = 0; q < 3; q++) { const a = q * TAU / 3 + Math.random(), j = addP(W, K.MINE, x + Math.cos(a) * 46, y + Math.sin(a) * 46, 0, 0, 6, W.pdm[i] * 0.5, 0, o, W.pr[i] * 0.6); if (j < 0) break; W.pt[j] = 0.2; }
          }
          break;
        }
        case K.PUD: case K.PUDE: case K.TORN: case K.TORNE:
          W.pa[i] -= h;
          if (W.pa[i] <= 0) {
            const tor = isTorn(k);
            W.pa[i] = tor ? 0.3 : 0.35;
            zoneHit(W, x, y, W.pr[i], W.pdm[i], o, tor ? (k === K.TORNE ? 1.2 : 0) : 0.6, tor ? (k === K.TORNE ? 40 : 26) : 0);
            if (k === K.TORNE) { const n = query(W, x, y, W.pr[i] * 0.5); for (let q = 0; q < n; q++) { const e = QB[q]; if (!isBossE(W, e) && (W.ex[e] - x) ** 2 + (W.ey[e] - y) ** 2 < (W.pr[i] * 0.45) ** 2) W.efz[e] = Math.max(W.efz[e], 0.5); } }
            if (k === K.PUDE) for (const q of W.pl) if (!q.dn && (q.x - x) ** 2 + (q.y - y) ** 2 < W.pr[i] ** 2) heal(q, 0.8);
          }
          break;
        case K.TUR: case K.TURE: {
          W.pa[i] -= h;
          if (W.pa[i] <= 0) {
            const t = nearestE(W, x, y, 270);
            W.pa[i] = W.pb[i];
            if (t >= 0) {
              const a = Math.atan2(W.ey[t] - y, W.ex[t] - x);
              W.ptg[i] = Math.round(a * 100);
              for (let q = 0; q < (k === K.TURE ? 2 : 1); q++) addP(W, K.DRB, x + Math.cos(a) * 8, y - 8 + Math.sin(a) * 8, a + (q ? 0.12 : 0), 380, 0.85, W.pdm[i], k === K.TURE ? 2 : 0, o, 3.5);
            }
            const rep = p ? tlvl(p, 7) : 0;
            if (rep) for (const q of W.pl) if (!q.dn && (q.x - x) ** 2 + (q.y - y) ** 2 < 85 * 85) heal(q, 0.5 * rep * W.pb[i]);
          }
          break;
        }
        case K.FLW: case K.FLWE: {
          W.pa[i] -= h; W.pb[i] -= h;
          const R2 = W.pr[i] * W.pr[i];
          if (W.pa[i] <= 0) {
            W.pa[i] = 0.5;
            const hv = (k === K.FLWE ? 2.2 : 1.3) * (p ? 1 + 0.4 * tlvl(p, 15) : 1) * 0.5;
            for (const q of W.pl) {
              if ((q.x - x) ** 2 + (q.y - y) ** 2 >= R2) continue;
              if (!q.dn) heal(q, hv);
              else if (k === K.FLWE) q.rv += 0.5 / 3;
            }
          }
          if (W.pb[i] <= 0) {
            W.pb[i] = k === K.FLWE ? 0.45 : 0.75;
            const t = nearestE(W, x, y, W.pr[i] + 90);
            if (t >= 0) { CURW = 27; addP(W, K.THN, x, y - 6, Math.atan2(W.ey[t] - y, W.ex[t] - x), 260, 0.6, W.pdm[i], 1, o, 4.5); }
          }
          break;
        }
        case K.WAVE: case K.WAVEE: {
          const r = W.pr[i], n = query(W, x, y, r + 30), id = W.ptg[i];
          for (let q = 0; q < n; q++) {
            const e = QB[q]; if (W.ewv[e] === id) continue;
            const dx = W.ex[e] - x, dy = W.ey[e] - y, d = hyp(dx, dy);
            if (d < r + W.er[e]) { W.ewv[e] = id; if (k === K.WAVEE) W.efz[e] = Math.max(W.efz[e], isBossE(W, e) ? 0 : 0.5); hurtE(W, e, W.pdm[i], o, dx, dy, 170); }
          }
          break;
        }
        case K.BEAM: case K.BEAME: break;
        default: {
          // moving hitters
          if (k !== K.BOOM && k !== K.BOOME && k !== K.HAWK && k !== K.HAWKE && k !== K.WISPE && pushOut(W.M, x, y, 2).hit) { remP(W, i); continue; }
          if ((k === K.HAWK || k === K.HAWKE) && W.pb[i]) break;
          const r = W.pr[i], n = query(W, x, y, r + 40);
          let bounced = -1;
          for (let q = 0; q < n; q++) {
            const e = QB[q];
            if (memHas(W, i, e)) continue;
            const dx = W.ex[e] - x, dy = W.ey[e] - y, rr = r + W.er[e];
            if (dx * dx + dy * dy >= rr * rr) continue;
            memAdd(W, i, e);
            const kb = k === K.BOOM || k === K.BOOME ? 40 : k === K.BOLTE ? 30 : k === K.HAWK || k === K.HAWKE ? 90 : 50;
            if (k === K.FROST) W.esl[e] = Math.max(W.esl[e], 1.6);
            if (k === K.FROSTE && !isBossE(W, e)) W.efz[e] = Math.max(W.efz[e], 1);
            if (k === K.THN && p && p.S.thn) W.esl[e] = Math.max(W.esl[e], 0.5 + 3 * p.S.thn);
            const ex0 = W.ex[e], ey0 = W.ey[e];
            hurtE(W, e, W.pdm[i] * (k === K.THN && p ? 1 + p.S.thn : 1), o, W.pvx[i], W.pvy[i], kb);
            if (k === K.BOOM || k === K.BOOME) continue;
            if (k === K.HAWKE) W.dfr.push(0, ex0, ey0, 42, W.pdm[i] * 0.5, o);
            W.ppi[i]--;
            if (k === K.HAWK || k === K.HAWKE) { if (W.ppi[i] < 0) { W.pb[i] = 1; break; } W.ptg[i] = -1; continue; }
            if (k === K.BNC || k === K.BNCE) { bounced = e; if (p) { const el = tlvl(p, 16); if (el) W.pdm[i] *= 1 + 0.12 * el; } break; }
            if (W.ppi[i] < 0) { W.pL[i] = 0; break; }
          }
          if (bounced >= 0) {
            if (W.ppi[i] < 0) W.pL[i] = 0;
            else {   // hop to the nearest other enemy
              let best = -1, bd = 170 * 170;
              const m = query(W, x, y, 170);
              for (let z = 0; z < m; z++) { const f = QB[z]; if (f === bounced || memHas(W, i, f)) continue; const d = (W.ex[f] - x) ** 2 + (W.ey[f] - y) ** 2; if (d < bd) { bd = d; best = f; } }
              if (best >= 0) { const sp = hyp(W.pvx[i], W.pvy[i]), a = Math.atan2(W.ey[best] - y, W.ex[best] - x); W.pvx[i] = Math.cos(a) * sp; W.pvy[i] = Math.sin(a) * sp; W.pL[i] = Math.max(W.pL[i], 0.6); }
              else W.pL[i] = 0;
            }
          }
        }
      }
      if (W.pL[i] <= 0) {
        if (k === K.SPR && p) {   // 굴절: the spear splits at the end
          const rf = tlvl(p, 10);
          if (rf) { const n = 2 + rf, a0 = Math.atan2(W.pvy[i], W.pvx[i]); for (let q = 0; q < n; q++) addP(W, K.THN, x, y, a0 + (q - (n - 1) / 2) * 0.5, 280, 0.45, W.pdm[i] * 0.5, 1, o, 4.5); }
        }
        remP(W, i);
      }
    }
  }
  function steer(W, i, tx, ty, turn) {
    const sp = hyp(W.pvx[i], W.pvy[i]) || 1, a0 = Math.atan2(W.pvy[i], W.pvx[i]), a1 = Math.atan2(ty - W.py[i], tx - W.px[i]);
    let da = a1 - a0; da = Math.atan2(Math.sin(da), Math.cos(da));
    const a = a0 + clamp(da, -turn, turn);
    W.pvx[i] = Math.cos(a) * sp; W.pvy[i] = Math.sin(a) * sp;
  }
  // hawk target: prefer bosses / elites, else the toughest enemy in range
  function pickPrey(W, x, y, range) {
    let best = -1, bs = -1;
    for (let i = 0; i < W.hiE; i++) {
      if (!W.eal[i]) continue;
      const d2 = (W.ex[i] - x) ** 2 + (W.ey[i] - y) ** 2;
      if (d2 > range * range) continue;
      const sc = (isBossE(W, i) ? 3e6 : W.eel[i] ? 2e6 : 0) + W.ehp[i] * 10 + d2 * 0.01;
      if (sc > bs) { bs = sc; best = i; }
    }
    return best;
  }

  /* ---------- weapons ---------- */
  function orbitInfo(p, w, T) {
    const S = wst(p, w), l = w.l, e = ebase(w);
    const n = (e ? 6 : 1 + Math.ceil(l / 2)) + S.am, rad = (e ? 72 : 50 + 3 * l) * S.ar;
    const on = e || ((T + p.s * 1.3) % 5) < Math.min(4.6, (2.6 + 0.25 * l) * S.du);
    return { n, rad, br: (e ? 11 : 8) * Math.sqrt(S.ar), sp: (e ? 3.6 : 3) * S.ps, on };
  }
  function auraR(p, w) { return (ebase(w) ? 82 : 46 + 5 * w.l) * wst(p, w).ar; }
  function droneN(p, w) { return Math.min(7, (ebase(w) ? 4 : 1 + Math.floor((w.l - 1) / 3)) + wst(p, w).am); }
  function fireWeapon(W, p, w) {
    const S = wst(p, w), l = w.l, e = ebase(w), am = S.am, s = p.s, dmM = S.dm;
    CURW = w.i;
    switch (w.i) {
      case 0: {
        if (e) {
          const t = nearestE(W, p.x, p.y, 400); if (t < 0) return 0.3;
          const a0 = Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x), n = 1 + am;
          for (let k = 0; k < n; k++) addP(W, K.BOLTE, p.x, p.y, a0 + (k - (n - 1) / 2) * 0.14 + (Math.random() - 0.5) * 0.08, 400 * S.ps, 1.1, (12 + 2 * l) * dmM, 3, s, 5);
          return 0.17 * S.cd;
        }
        const n = 1 + (l >> 1) + am, T = nearestN(W, p.x, p.y, 380, n);
        if (!T.length) return 0.3;
        for (let k = 0; k < n; k++) {
          const t = T[k % T.length], a = Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x) + (k >= T.length ? (Math.random() - 0.5) * 0.3 : 0);
          addP(W, K.BOLT, p.x, p.y, a, 330 * S.ps, 1.2, (12 + 3 * (l - 1)) * dmM, l >= 5 ? 2 : 1, s, 4);
        }
        return (0.9 - 0.05 * (l - 1)) * S.cd;
      }
      case 1: return 1;  // orbit handled continuously
      case 2: {
        const r = auraR(p, w);
        zoneHit(W, p.x, p.y, r, (e ? 9 + l : 4 + 1.6 * (l - 1)) * dmM, s, e ? 0.5 : 0.25, 0);
        if (e) p.hp = Math.min(p.mhp, p.hp + 0.25);
        return 0.45 * S.cd;
      }
      case 3: {
        const n = 1 + (l >> 1) + am + (e ? 1 : 0), T = randomE(W, p.x, p.y, 300, n), dm = (20 + 5 * (l - 1)) * dmM * (e ? 1.3 : 1);
        if (!T.length) return 0.5;
        const tl = T.slice();
        for (const t of tl) {
          if (!W.eal[t]) continue;
          const x = W.ex[t], y = W.ey[t];
          fx(W, 1, x, y, s, 0);
          explode(W, x, y, 22 * S.ar, dm, s, 20, -1);
          if (e) { let cx = x, cy = y; for (let c = 0; c < 3; c++) { const nx = nearestOther(W, cx, cy, 140, t); if (nx < 0) break; const x2 = W.ex[nx], y2 = W.ey[nx]; fx(W, 1, x2, y2, s, 1); hurtE(W, nx, dm * 0.7, s, 0, 0, 0); cx = x2; cy = y2; } }
        }
        return (2.0 - 0.12 * (l - 1)) * S.cd * (e ? 0.55 : 1);
      }
      case 4: {
        const n = 1 + ((l - 1) >> 1) + am + (e ? 1 : 0), t = nearestE(W, p.x, p.y, 360);
        const a0 = t >= 0 ? Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x) : Math.atan2(p.fy, p.fx);
        for (let k = 0; k < n; k++) {
          const i = addP(W, e ? K.BOOME : K.BOOM, p.x, p.y, a0 + (k - (n - 1) / 2) * 0.5, (e ? 380 : 320) * S.ps, 3, (12 + 3 * (l - 1)) * dmM * (e ? 1.5 : 1), 999, s, (e ? 13 : 9) * S.ar);
          if (i >= 0) W.pa[i] = (e ? 0.6 : 0.5) * S.du;
        }
        return (e ? 1.0 : 1.7) * S.cd;
      }
      case 5: {
        if (e) {
          const n = 12 + am * 2, a0 = Math.random() * TAU;
          for (let k = 0; k < n; k++) addP(W, K.FROSTE, p.x, p.y, a0 + k * TAU / n, 260 * S.ps, 0.75 * S.du, (9 + 2 * l) * dmM, 2, s, 5 * S.ar);
          return 1.2 * S.cd;
        }
        const n = 3 + ((l - 1) >> 1) + am, t = nearestE(W, p.x, p.y, 300);
        const a0 = t >= 0 ? Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x) : Math.atan2(p.fy, p.fx);
        for (let k = 0; k < n; k++) addP(W, K.FROST, p.x, p.y, a0 + (k - (n - 1) / 2) * 0.22, 280 * S.ps, 0.65 * S.du, (7 + 2 * (l - 1)) * dmM, 1, s, 4 * S.ar);
        return 1.45 * S.cd;
      }
      case 6: {
        const n = 1 + ((l - 1) >> 1) + am, T = randomE(W, p.x, p.y, 280, n);
        if (!T.length) return 0.5;
        for (let k = 0; k < n; k++) {
          const t = T[k % T.length], tx = W.ex[t] + (k >= T.length ? (Math.random() - 0.5) * 60 : 0), ty = W.ey[t];
          const fl = 0.6, i = addP(W, K.BOMB, p.x, p.y, Math.atan2(ty - p.y, tx - p.x), hyp(tx - p.x, ty - p.y) / fl, fl, (22 + 6 * (l - 1)) * dmM, 0, s, 44 * S.ar * (1 + 0.06 * (l - 1)));
          if (i >= 0) { W.pa[i] = tx; W.pb[i] = ty; W.ptg[i] = e ? 1 : 0; }
        }
        return 2.5 * S.cd * (e ? 0.8 : 1);
      }
      case 7: {
        const len = (e ? 175 : 115 + 6 * l) * S.ar, wid = (e ? 52 : 34) * S.ar, dm = (14 + 4 * (l - 1)) * dmM * (e ? 1.4 : 1);
        const dir = p.fx >= 0 ? 1 : -1, sides = e || l >= 3 ? [dir, -dir] : [dir];
        let heal = 0;
        for (const sd of sides) {
          const cx = p.x + sd * len / 2, n = query(W, cx, p.y, len / 2 + 30);
          for (let q = 0; q < n; q++) {
            const i = QB[q], dx = W.ex[i] - p.x;
            if (dx * sd < -4 || Math.abs(dx) > len + W.er[i] || Math.abs(W.ey[i] - p.y) > wid / 2 + W.er[i]) continue;
            hurtE(W, i, dm, s, sd, 0, 70); if (e) heal++;
          }
          fx(W, 2, p.x, p.y, sd * Math.round(len), Math.round(wid));
        }
        if (heal) p.hp = Math.min(p.mhp, p.hp + Math.min(6, heal));
        return 1.35 * S.cd;
      }
      case 8: {
        const n = 1 + Math.floor(l / 3) + am + (e ? 1 : 0);
        for (let k = 0; k < n; k++) {
          const T = randomE(W, p.x, p.y, 160, 1);
          let x = p.x + (Math.random() - 0.5) * 180, y = p.y + (Math.random() - 0.5) * 180;
          if (T.length) { x = W.ex[T[0]]; y = W.ey[T[0]]; }
          const i = addP(W, e ? K.PUDE : K.PUD, x, y, 0, 0, 3 * S.du * (e ? 1.3 : 1), (4 + 1.5 * (l - 1)) * dmM * (e ? 1.5 : 1), 0, s, 34 * S.ar * (1 + 0.05 * (l - 1)) * (e ? 1.3 : 1));
          if (i < 0) break;
        }
        return 3.2 * S.cd;
      }
      case 9: {
        const n = (2 + ((l - 1) >> 1) + am) * (e ? 2 : 1);
        for (let k = 0; k < n; k++) addP(W, e ? K.WISPE : K.WISP, p.x, p.y, Math.random() * TAU, 190 * S.ps, 2.6 * S.du, (9 + 2.5 * (l - 1)) * dmM, e ? 2 : 0, s, 5);
        return (e ? 0.9 : 1.5) * S.cd;
      }
      case 10: {
        const r = 110 * S.ar * (1 + 0.06 * (l - 1)), dm = (12 + 4 * (l - 1)) * dmM * (e ? 1.6 : 1);
        for (let k = 0; k < (e ? 2 : 1); k++) {
          const i = addP(W, e ? K.WAVEE : K.WAVE, p.x, p.y, 0, 0, 0.5 + k * 0.3, dm, 0, s, 1);
          if (i >= 0) { W.pa[i] = r * (k ? 1.4 : 1); W.ptg[i] = (W.wid = (W.wid % 30000) + 1); W.pt[i] = -k * 0.3; }
        }
        return 3.1 * S.cd;
      }
      case 11: {
        const n = 1 + Math.floor((l - 1) / 3) + am, t = nearestE(W, p.x, p.y, 420);
        const a0 = t >= 0 ? Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x) : Math.atan2(p.fy, p.fx);
        const len = (e ? 420 : 260) * S.ar, wid = (e ? 26 : 13) * S.ar, dm = (22 + 6 * (l - 1)) * dmM * (e ? 1.5 : 1);
        for (let k = 0; k < n; k++) {
          const a = a0 + (k - (n - 1) / 2) * 0.35, cx = Math.cos(a), cy = Math.sin(a), bid = -(W.bid = (W.bid % 30000) + 1);
          const i = addP(W, e ? K.BEAME : K.BEAM, p.x, p.y, a, 0, 0.25, 0, 0, s, len);
          if (i >= 0) W.pa[i] = a;
          // hit everything along the line once
          for (let st = 0; st < len; st += 60) {
            const m = query(W, p.x + cx * (st + 30), p.y + cy * (st + 30), 70);
            for (let q = 0; q < m; q++) {
              const e2 = QB[q]; if (W.ewv[e2] === bid) continue;
              const dx = W.ex[e2] - p.x, dy = W.ey[e2] - p.y, along = dx * cx + dy * cy, perp = Math.abs(dx * cy - dy * cx);
              if (along < 0 || along > len || perp > wid / 2 + W.er[e2]) continue;
              W.ewv[e2] = bid; hurtE(W, e2, dm, s, cx, cy, 40);
            }
          }
        }
        return (e ? 1.4 : 2.6) * S.cd;
      }
      case 12: {
        let cnt = 0; for (let i = 0; i < W.hiP; i++) if (W.pal[i] && W.pk[i] === K.MINE && W.po[i] === s) cnt++;
        if (cnt >= 3 + l + (e ? 3 : 0)) return 0.5;
        const mi = addP(W, K.MINE, p.x - p.fx * 12, p.y - p.fy * 12, 0, 0, 10 * S.du, (26 + 7 * (l - 1)) * dmM * (e ? 1.5 : 1), 0, s, 40 * S.ar * (1 + 0.06 * l) * (e ? 1.3 : 1));
        if (mi >= 0 && e) W.pb[mi] = 1;
        return (2.0 - 0.1 * (l - 1)) * S.cd / (1 + 0.5 * am) * (e ? 0.7 : 1);
      }
      case 13: {
        const n = 1 + Math.floor((l - 1) / 3) + am, t = nearestE(W, p.x, p.y, 360);
        if (t < 0) return 0.4;
        for (let k = 0; k < n; k++) addP(W, e ? K.BNCE : K.BNC, p.x, p.y, Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x) + k * 0.4, 360 * S.ps, 1.2, (11 + 3 * (l - 1)) * dmM * (e ? 1.4 : 1), (3 + l) * (e ? 2 : 1) + S.bnc, s, 6);
        return (e ? 1.2 : 2.1) * S.cd;
      }
      case 14: {
        const n = droneN(p, w);
        for (let k = 0; k < n; k++) {
          const dp = dronePos(p, k, n, W.T), t = nearestE(W, dp[0], dp[1], 280);
          if (t >= 0) addP(W, K.DRB, dp[0], dp[1], Math.atan2(W.ey[t] - dp[1], W.ex[t] - dp[0]), 360 * S.ps, 0.9, (8 + 2 * (l - 1)) * dmM * S.mech, 0, s, 3);
        }
        return (0.62 - 0.04 * (l - 1)) * S.cd * (e ? 0.65 : 1) * S.ov;
      }
      case 15: {
        const n = 1 + Math.floor((l - 1) / 3) + am, T = nearestN(W, p.x, p.y, 260, n);
        for (let k = 0; k < n; k++) {
          const a = T.length ? Math.atan2(W.ey[T[k % T.length]] - p.y, W.ex[T[k % T.length]] - p.x) : Math.random() * TAU;
          const i = addP(W, e ? K.TORNE : K.TORN, p.x, p.y, a, 75, 3.2 * S.du * (e ? 1.3 : 1), (6 + 2 * (l - 1)) * dmM * (e ? 1.5 : 1), 0, s, 28 * S.ar * (1 + 0.05 * l) * (e ? 1.5 : 1));
          if (i < 0) break;
        }
        return (2.8 - 0.1 * (l - 1)) * S.cd * (e ? 0.8 : 1);
      }
      case 16: {
        const n = 1 + ((l - 1) >> 1) + am + (e ? 3 : 0), T = randomE(W, p.x, p.y, e ? 340 : 300, n);
        if (!T.length) return 0.6;
        for (const t of T.slice()) addP(W, K.MET, W.ex[t], W.ey[t], 0, 0, 0.8, (40 + 10 * (l - 1)) * dmM * (e ? 1.3 : 1), 0, s, 58 * S.ar);
        return (3.2 - 0.15 * (l - 1)) * S.cd * (e ? 0.7 : 1);
      }
      case 17: {   // shadow knives: fast knives at the nearest enemy (where you walk if nobody is near)
        const tk = nearestE(W, p.x, p.y, 280), n = 1 + ((l - 1) >> 1) + am + (e ? 2 : 0), a0 = tk >= 0 ? Math.atan2(W.ey[tk] - p.y, W.ex[tk] - p.x) : Math.atan2(p.fy, p.fx);
        for (let k = 0; k < n; k++) addP(W, e ? K.KNFE : K.KNF, p.x, p.y, a0 + (k - (n - 1) / 2) * (e ? 0.16 : 0.09) + (Math.random() - 0.5) * 0.05, 430 * S.ps, 0.8, (8 + 2.5 * (l - 1)) * dmM, e ? 2 : l >= 4 ? 1 : 0, s, 4);
        return (e ? 0.3 : 0.55 - 0.03 * (l - 1)) * S.cd;
      }
      case 18: {   // thorn burst: radial spikes
        const n = (e ? 16 : 6 + l) + am * 2, a0 = Math.random() * TAU;
        for (let k = 0; k < n; k++) addP(W, K.THN, p.x, p.y, a0 + k * TAU / n, 240 * S.ps, 0.45 * S.du * (e ? 1.3 : 1), (9 + 2.5 * (l - 1)) * dmM * (e ? 1.5 : 1), e ? 3 : 1, s, e ? 6 : 4.5);
        return (e ? 1.6 : 2.2) * S.cd;
      }
      case 19: {   // flamethrower: short cone of fire toward the nearest enemy
        const t = nearestE(W, p.x, p.y, 200);
        const a0 = t >= 0 ? Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x) : Math.atan2(p.fy, p.fx), n = 4 + l + am, spr = e ? 0.55 : 0.35;
        for (let k = 0; k < n; k++) addP(W, K.FIRE, p.x, p.y, a0 + (Math.random() - 0.5) * spr * 2, (190 + Math.random() * 60) * S.ps, (e ? 0.55 : 0.36) * S.du, (4 + 1.5 * (l - 1)) * dmM * (e ? 1.5 : 1), 99, s, (e ? 9 : 7) * S.ar);
        return 0.9 * S.cd;
      }
      case 20: {   // axes: tossed up, fall down through enemies
        const n = 1 + ((l - 1) >> 1) + am + (e ? 1 : 0);
        for (let k = 0; k < n; k++) {
          const side = (p.fx >= 0 ? 1 : -1) * (k % 2 ? -1 : 1), i = addP(W, K.AXE, p.x, p.y, 0, 0, 1.4, (20 + 5 * (l - 1)) * dmM * (e ? 1.5 : 1), 99, s, (e ? 16 : 9) * S.ar);
          if (i >= 0) { W.pvx[i] = side * (50 + Math.random() * 70) * S.ps; W.pvy[i] = -330 * S.ps; }
        }
        return (e ? 1.3 : 1.8 - 0.06 * (l - 1)) * S.cd;
      }
      case 21: return 1;   // chain blade: continuous (stepWeapons)
      case 22: {   // crystal spear: slow, pierces everything
        const n = 1 + Math.floor((l - 1) / 3) + am + (e ? 2 : 0), t = nearestE(W, p.x, p.y, 380);
        const a0 = t >= 0 ? Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x) : Math.atan2(p.fy, p.fx);
        for (let k = 0; k < n; k++) addP(W, K.SPR, p.x, p.y, a0 + (k - (n - 1) / 2) * 0.25, 260 * S.ps, 1.6 * S.du, (20 + 6 * (l - 1)) * dmM * (e ? 1.5 : 1), 99, s, (e ? 9 : 7) * S.ar);
        return (e ? 0.9 : 1.25 - 0.03 * l) * S.cd;
      }
      case 23: {   // sonic bell: cone push where you face (evolved: all around, twice)
        const tg = nearestE(W, p.x, p.y, 220), rng = (115 + 6 * l) * S.ar, dm = (12 + 3.5 * (l - 1)) * dmM * (e ? 1.4 : 1), fa = tg >= 0 ? Math.atan2(W.ey[tg] - p.y, W.ex[tg] - p.x) : Math.atan2(p.fy, p.fx), half = e ? Math.PI : 0.7;
        const n = query(W, p.x, p.y, rng + 20);
        for (let q = 0; q < n; q++) {
          const i = QB[q], dx = W.ex[i] - p.x, dy = W.ey[i] - p.y, d = hyp(dx, dy);
          if (d > rng + W.er[i]) continue;
          let da2 = Math.atan2(dy, dx) - fa; da2 = Math.abs(Math.atan2(Math.sin(da2), Math.cos(da2)));
          if (da2 > half) continue;
          hurtE(W, i, dm, s, dx, dy, 210);
        }
        fx(W, 18, p.x, p.y, Math.round(fa * 100), Math.round(rng) + (e ? 1000 : 0));
        const hl = S.heal;
        if (hl) { for (const q of W.pl) if (!q.dn && (q.x - p.x) ** 2 + (q.y - p.y) ** 2 < 140 * 140) heal(q, hl); }
        if (e && !w.t) { w.t = 1; return 0.35; }
        w.t = 0;
        return (e ? 1.6 : 2.0) * S.cd;
      }
      case 24: return 1;   // firebird: continuous (stepWeapons)
      case 25: {   // steam turret: placed at my feet
        let cnt = 0; for (let i = 0; i < W.hiP; i++) if (W.pal[i] && (W.pk[i] === K.TUR || W.pk[i] === K.TURE) && W.po[i] === s) cnt++;
        if (cnt >= 1 + (l >= 3 ? 1 : 0) + (l >= 6 ? 1 : 0) + am + (tlvl(p, 7) ? 1 : 0)) return 0.6;
        const i = addP(W, e ? K.TURE : K.TUR, p.x, p.y, 0, 0, (8 + 0.5 * l) * S.du * (e ? 1.5 : 1), (9 + 2.5 * (l - 1)) * dmM * S.mech, 0, s, 12);
        if (i >= 0) { W.pb[i] = Math.max(0.2, (0.75 - 0.04 * l) * S.cd * S.ov); W.pa[i] = 0.3; }
        return (3.2 - 0.15 * l) * S.cd;
      }
      case 26: {   // spin slash: hit everything around me
        const r = (e ? 95 : 62 + 4 * l) * S.ar, dm = (16 + 5 * (l - 1)) * dmM * (e ? 1.3 : 1);
        const n = query(W, p.x, p.y, r + 20);
        let hit = 0;
        for (let q = 0; q < n; q++) { const i = QB[q], dx = W.ex[i] - p.x, dy = W.ey[i] - p.y; if (dx * dx + dy * dy < (r + W.er[i]) ** 2) { hurtE(W, i, dm, s, dx, dy, 110); hit++; } }
        if (e && hit) heal(p, Math.min(5, hit * 0.5));
        fx(W, 19, p.x, p.y, Math.round(r), e ? 1 : 0);
        return (e ? 0.9 : 2.3 - 0.1 * l) * S.cd;
      }
      case 27: {   // healing flower
        let cnt = 0; for (let i = 0; i < W.hiP; i++) if (W.pal[i] && (W.pk[i] === K.FLW || W.pk[i] === K.FLWE) && W.po[i] === s) cnt++;
        if (cnt >= 1 + (l >= 4 ? 1 : 0) + am) return 0.6;
        const i = addP(W, e ? K.FLWE : K.FLW, p.x, p.y, 0, 0, (6 + 0.4 * l) * S.du * (e ? 1.5 : 1), (8 + 2.5 * (l - 1)) * dmM, 0, s, (e ? 90 : 58 + 2 * l) * S.ar);
        if (i >= 0) { W.pa[i] = 0.2; W.pb[i] = 0.3; }
        return (e ? 3.5 : 5 - 0.2 * l) * S.cd;
      }
      case 28: {   // chain lightning: hop from enemy to enemy
        const hops = 3 + l + S.bnc + am + tlvl(p, 17) + (e ? 3 : 0), dm = (14 + 4 * (l - 1)) * dmM * (e ? 1.4 : 1);
        for (let c = 0; c < (e ? 2 : 1); c++) {
          let t = c ? randomE(W, p.x, p.y, 230, 1)[0] : nearestE(W, p.x, p.y, 230);
          if (t == null || t < 0) break;
          let px = p.x, py = p.y; const hit = [];
          for (let k = 0; k < hops && t >= 0; k++) {
            const x2 = W.ex[t], y2 = W.ey[t];
            fx(W, 20, px, py, Math.round(x2), Math.round(y2));
            hit.push(t); hurtE(W, t, dm, s, x2 - px, y2 - py, 30);
            px = x2; py = y2;
            t = nearestNot(W, px, py, e ? 170 : 140, hit);
          }
          const oc = tlvl(p, 17); if (oc) W.dfr.push(0, px, py, 34 + 6 * oc, dm * 0.6, s);
        }
        return (e ? 0.9 : 1.6 - 0.06 * l) * S.cd;
      }
      case 29: {   // hawk: dives at a tough enemy and returns
        let cnt = 0; for (let i = 0; i < W.hiP; i++) if (W.pal[i] && (W.pk[i] === K.HAWK || W.pk[i] === K.HAWKE) && W.po[i] === s) cnt++;
        const max = (e ? 2 : 1) + (l >= 5 ? 1 : 0);
        if (cnt >= max) return 0.4;
        const t = pickPrey(W, p.x, p.y, 380);
        if (t < 0) return 0.5;
        const sp = 300 * S.ps * (1 + 0.15 * tlvl(p, 18));
        const i = addP(W, e ? K.HAWKE : K.HAWK, p.x, p.y - 10, Math.atan2(W.ey[t] - p.y, W.ex[t] - p.x), sp, 9, (34 + 9 * (l - 1)) * dmM * S.bird * (e ? 1.3 : 1), 1 + (l >> 1), s, e ? 14 : 11);
        if (i >= 0) W.ptg[i] = t;
        return (e ? 0.8 : 1.4 - 0.05 * l) * S.cd;
      }
    }
    return 1;
  }
  function nearestNot(W, x, y, range, not) {
    const n = query(W, x, y, range); let best = -1, bd = range * range;
    for (let q = 0; q < n; q++) { const i = QB[q]; if (not.indexOf(i) >= 0) continue; const d = (W.ex[i] - x) ** 2 + (W.ey[i] - y) ** 2; if (d < bd) { bd = d; best = i; } }
    return best;
  }
  function nearestOther(W, x, y, range, not) {
    const n = query(W, x, y, range); let best = -1, bd = range * range;
    for (let q = 0; q < n; q++) { const i = QB[q]; if (i === not) continue; const d = (W.ex[i] - x) ** 2 + (W.ey[i] - y) ** 2; if (d < bd && d > 4) { bd = d; best = i; } }
    return best;
  }
  function dronePos(p, k, n, T) { const a = T * 1.6 + k * TAU / n; return [p.x + Math.cos(a) * 30, p.y + Math.sin(a) * 30 - 6]; }
  function chainInfo(p, w) { const S = wst(p, w), e = ebase(w); return { n: e ? 2 : 1, len: (e ? 150 : 80 + 8 * w.l) * S.ar, sp: (e ? 3.6 : 3) * S.ps }; }
  function birdInfo(p, w) { const fw = tlvl(p, 18), S = wst(p, w), e = ebase(w); return { n: Math.min(6, (e ? 3 : 1 + (w.l >= 2 ? 1 : 0) + (w.l >= 5 ? 1 : 0)) + S.am), rad: 88 * S.ar, sp: 2.4 * S.ps * (1 + 0.15 * fw), br: (e ? 18 : 15) * Math.sqrt(S.ar) * (1 + 0.08 * fw) }; }
  function stepWeapons(W, p, h) {
    for (const w of p.W) {
      if (w.i === 21) {
        CURW = 21;
        const o = chainInfo(p, w), dm = (12 + 3 * (w.l - 1)) * wst(p, w).dm * (ebase(w) ? 1.5 : 1) * p.S.bird;
        for (let k = 0; k < o.n; k++) {
          const a = -W.T * o.sp + k * Math.PI, cx = Math.cos(a), cy = Math.sin(a);
          const m = query(W, p.x + cx * o.len / 2, p.y + cy * o.len / 2, o.len / 2 + 30);
          for (let q = 0; q < m; q++) {
            const e = QB[q]; if (W.eoc[e] > 0) continue;
            const dx = W.ex[e] - p.x, dy = W.ey[e] - p.y, al = dx * cx + dy * cy, pp = Math.abs(dx * cy - dy * cx);
            if (al < 8 || al > o.len + W.er[e] || pp > 7 + W.er[e]) continue;
            W.eoc[e] = 0.35; hurtE(W, e, dm, p.s, dx, dy, 70);
          }
        }
        continue;
      }
      if (w.i === 24) {
        CURW = 24;
        const o = birdInfo(p, w), dm = (14 + 4 * (w.l - 1)) * wst(p, w).dm * (ebase(w) ? 1.4 : 1) * p.S.bird;
        for (let k = 0; k < o.n; k++) {
          const a = W.T * o.sp + k * TAU / o.n, bx = p.x + Math.cos(a) * o.rad, by = p.y + Math.sin(a) * o.rad * 0.8;
          const m = query(W, bx, by, o.br + 40);
          for (let q = 0; q < m; q++) {
            const e = QB[q]; if (W.eoc[e] > 0) continue;
            const rr = o.br + W.er[e];
            if ((W.ex[e] - bx) ** 2 + (W.ey[e] - by) ** 2 < rr * rr) { W.eoc[e] = 0.45; hurtE(W, e, dm, p.s, W.ex[e] - p.x, W.ey[e] - p.y, 80); }
          }
        }
        continue;
      }
      if (w.i === 1) {
        CURW = 1;
        const o = orbitInfo(p, w, W.T);
        if (!o.on) continue;
        const dm = (9 + 2.5 * (w.l - 1)) * wst(p, w).dm * (ebase(w) ? 1.5 : 1) * p.S.bird;
        for (let k = 0; k < o.n; k++) {
          const a = W.T * o.sp + k * TAU / o.n, bx = p.x + Math.cos(a) * o.rad, by = p.y + Math.sin(a) * o.rad;
          const m = query(W, bx, by, o.br + 40);
          for (let q = 0; q < m; q++) {
            const e = QB[q]; if (W.eoc[e] > 0) continue;
            const rr = o.br + W.er[e];
            if ((W.ex[e] - bx) ** 2 + (W.ey[e] - by) ** 2 < rr * rr) { W.eoc[e] = 0.4; hurtE(W, e, dm, p.s, W.ex[e] - p.x, W.ey[e] - p.y, 60); }
          }
        }
        continue;
      }
      w.cd -= h;
      if (w.cd <= 0) w.cd = fireWeapon(W, p, w);
    }
  }

  /* ---------- players ---------- */
  let SRC = 0;
  function hurtP(W, p, dmg, src) {
    if (p.dn || p.iv > 0 || p.dt > 0) return;
    if ((p.off || p.ro) && !W.solo) return;   // choosing a card online: protective bubble
    let arm = p.S.arm;
    for (const q of W.pl) if (q !== p && !q.dn && q.S.aura && (q.x - p.x) ** 2 + (q.y - p.y) ** 2 < 130 * 130) arm += q.S.aura;
    const d = Math.max(1, dmg - arm);
    if (W.dbg) W.dbg[SRC] = (W.dbg[SRC] || 0) + d;
    p.hp -= d; p.hurtF = 0.25; p.tk += d; p.iv = Math.max(p.iv, 0.5);
    // 반격 (방패 기사 trait): shockwave when hit
    const ct = tlvl(p, 8);
    if (ct && !(p.ctT > 0)) { p.ctT = 0.8; CURW = 21; explode(W, p.x, p.y, 80 * p.S.ar, (15 + 15 * ct) * p.S.dm, p.s, 150, 5); }
    // 가시 갑옷 relic: hurt the enemy that touched me
    if (src >= 0 && hasR(p, 15)) { CURW = -1; hurtE(W, src, 25 * p.S.dm, p.s, W.ex[src] - p.x, W.ey[src] - p.y, 60); }
    if (p.hp <= 0) {
      // 수호 천사 (any nearby owner, 60 s cooldown) then 불사조 깃털 (once)
      for (const q of W.pl) {
        if (q.dn || !hasR(q, 28) || q.gaT > 0 || (q.x - p.x) ** 2 + (q.y - p.y) ** 2 > 160 * 160) continue;
        q.gaT = 60; p.hp = 1; p.iv = 1.5; fx(W, 21, p.x, p.y, p.s, 1); return;
      }
      if (hasR(p, 22) && !p.phx) { p.phx = 1; p.hp = Math.round(p.mhp * 0.5); p.iv = 2; fx(W, 21, p.x, p.y, p.s, 2); explode(W, p.x, p.y, 90, 40 * p.S.dm, p.s, 200, 1); return; }
      p.hp = 0; p.dn = 1; p.rv = 0; p.vx = p.vy = 0;
      fx(W, 5, p.x, p.y, p.s, 0);
    }
  }
  function movePlayer(W, p, mx, my, h) {
    const S = W.S, M = W.M;
    let m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; m = 1; }
    if (m > 0.15) { p.fx = mx / m; p.fy = my / m; }
    let sp = p.S.sp * (p.spd || 1);
    if (p.rt > 0) sp = 0;
    if (W.tide && W.tide.on && inTide(W, p.x)) sp *= 0.55;
    let tx = mx * sp, ty = my * sp;
    if (p.dt > 0) { tx = p.ddx * 300; ty = p.ddy * 300; p.vx = tx; p.vy = ty; }
    else if (S.ice) { const k = Math.min(1, h * (m > 0.15 ? 4 : 2.6)); p.vx += (tx - p.vx) * k; p.vy += (ty - p.vy) * k; }
    else { p.vx = tx; p.vy = ty; }
    let cx = 0;
    let cy = 0;
    if (S.conv) cx = convAt(M, p.y) * 42;
    if (W.wind && W.wind.on) { cx += Math.cos(W.wind.a) * 30; cy += Math.sin(W.wind.a) * 30; }
    let x = p.x + (p.vx + cx) * h, y = p.y + (p.vy + cy) * h;
    const o = pushOut(M, x, y, PR);
    x = clamp(o.x, PR + 2, WS - PR - 2); y = clamp(o.y, PR + 2, WS - PR - 2);
    if (S.ice && o.hit) { p.vx *= 0.6; p.vy *= 0.6; }
    p.x = x; p.y = y;
  }
  function inTide(W, x) { const t = W.tide; return t && (t.side < 0 ? x < t.x : x > t.x); }
  function doDash(W, p) {
    if (p.dc > 0 || p.dn || p.rt > 0) return false;
    let dx = p.fx, dy = p.fy; const m = hyp(dx, dy) || 1;
    p.ddx = dx / m; p.ddy = dy / m; p.dt = 0.2; p.dc = p.S ? p.S.dcd : 3.5; p.iv = Math.max(p.iv, 0.35);
    if (W.ehp) {   // host world only (guests predict movement)
      if (p.ch === 0) p.dcr = 2.2;
      const sw = tlvl(p, 0);
      if (sw) { CURW = 17; explode(W, p.x, p.y, 58 * p.S.ar, (18 + 14 * sw) * p.S.dm, p.s, 90, 6); p.swd = 1; }
    }
    return true;
  }
  function stepPlayers(W, C, h) {
    for (const p of W.pl) {
      const c = C[p.s] || NOC, S = p.S;
      if (p.iv > 0) p.iv -= h;
      if (p.hc > 0) p.hc -= h;
      if (p.rt > 0) p.rt -= h;
      if (p.dc > 0) p.dc -= h;
      if (p.hurtF > 0) p.hurtF -= h;
      if (p.dcr > 0) p.dcr -= h;
      if (p.ctT > 0) p.ctT -= h;
      if (p.gaT > 0) p.gaT -= h;
      if (p.dn) {
        // revive: teammates within 42 fill the ring (3 s, faster with more helpers / healers)
        let helpers = 0, mul = 0;
        for (const q of W.pl) if (q !== p && !q.dn && hyp(q.x - p.x, q.y - p.y) < 42) { helpers++; mul += q.S.rvs; }
        if (helpers) { p.rv += h / 3 * (mul / helpers) * (1 + 0.5 * (helpers - 1)) * S.tmR; }
        else p.rv = Math.max(0, p.rv - h / 6);
        if (p.rv >= 1) {
          p.dn = 0; p.hp = Math.round(p.mhp * 0.5); p.iv = 2.5; p.rv = 0;
          for (const q of W.pl) if (q !== p && !q.dn && hyp(q.x - p.x, q.y - p.y) < 42) q.revs++;
          fx(W, 6, p.x, p.y, p.s, 0);
        }
        continue;
      }
      if (c.d && c.d !== p.dseq) { p.dseq = c.d; const mm = hyp(c.mx || 0, c.my || 0); if (mm > 0.2) { p.fx = c.mx / mm; p.fy = c.my / mm; } if (W.st.dsh) doDash(W, p); }
      const wasDash = p.dt > 0;
      if (p.dt > 0) p.dt -= h;
      // dynamic modifiers (berserk, focus)
      const lost = 1 - clamp(p.hp / (p.mhp || 1), 0, 1);
      let dyn = 1;
      if (p.ch === 6) dyn *= 1 + 0.4 * lost;
      if (hasR(p, 26)) dyn *= 1 + 0.5 * lost;
      const fo = tlvl(p, 11);
      if (fo && p.still > 0.6) dyn *= 1 + 0.12 * fo;
      p.dyn = dyn;
      const mad = tlvl(p, 12), low = p.hp < p.mhp * 0.5;
      p.spd = mad && low ? 1 + 0.06 * mad : 1;
      p.cdk = mad && low ? 1 / (1 - 0.08 * mad) : 1;
      const ox = p.x, oy = p.y;
      if (c.px != null && fin(c.px) && fin(c.py)) {
        // remote (guest-predicted) position; accept if plausible
        const dx = c.px - p.x, dy = c.py - p.y, d = hyp(dx, dy), lim = S.sp * 0.6 * p.spd + 40 + (p.dt > 0 ? 80 : 0);
        if (p.rt > 0) { /* rooted: stay */ }
        else if (d < lim) { const o = pushOut(W.M, c.px, c.py, PR); p.x = clamp(o.x, PR, WS - PR); p.y = clamp(o.y, PR, WS - PR); }
        else movePlayer(W, p, dx / (d || 1), dy / (d || 1), h);
        if (hyp(c.mx || 0, c.my || 0) > 0.15) { const m = hyp(c.mx, c.my); p.fx = c.mx / m; p.fy = c.my / m; }
      } else movePlayer(W, p, c.mx || 0, c.my || 0, h);
      const mv = hyp(p.x - ox, p.y - oy);
      p.still = mv < S.sp * h * 0.3 ? p.still + h : 0;
      if (wasDash && p.dt <= 0 && p.swd) { p.swd = 0; const sw = tlvl(p, 0); if (sw) { CURW = 17; explode(W, p.x, p.y, 58 * S.ar, (18 + 14 * sw) * S.dm, p.s, 90, 6); } }
      if (p.dt > 0 && hasR(p, 16)) {   // 질풍 망토: dash rams enemies
        CURW = -1; const n = query(W, p.x, p.y, 40);
        for (let q = 0; q < n; q++) { const e = QB[q]; if (W.eoc[e] > 0) continue; if ((W.ex[e] - p.x) ** 2 + (W.ey[e] - p.y) ** 2 < (W.er[e] + 16) ** 2) { W.eoc[e] = 0.3; hurtE(W, e, 30 * S.dm, p.s, p.ddx, p.ddy, 160); } }
      }
      // relic timers
      if (hasR(p, 27)) { p.mvd += mv; if (p.mvd >= 120) { p.mvd = 0; W.dfr.push(1, p.x, p.y, 2, 22 * S.dm, p.s); } }
      if (hasR(p, 32)) { p.bsT -= h; if (p.bsT <= 0) { p.bsT = 4; W.dfr.push(2, p.x, p.y, 140 * S.ar, 55 * S.dm, p.s); } }
      if (hasR(p, 18)) { p.hbT -= h; if (p.hbT <= 0) { p.hbT = 15; for (const q of W.pl) if (!q.dn && hyp(q.x - p.x, q.y - p.y) < 150) heal(q, 15); fx(W, 21, p.x, p.y, p.s, 3); } }
      if (S.rg > 0) heal(p, S.rg * h);
      else if (S.rg < 0) p.hp = Math.max(1, p.hp + S.rg * h);
      // stage hazards on players
      if (W.S.lava && inPool(W.M, p.x, p.y)) lavaTick(W, p, h);
      stepWeapons(W, p, h * p.cdk);
    }
  }
  function lavaTick(W, p, h) {
    p.lt = (p.lt || 0) - h;
    if (p.lt <= 0) { p.lt = 0.5; hurtP(W, p, 5); }
  }

  /* ---------- enemies step ---------- */
  function stepEnemies(W, h) {
    buildGrid(W);
    const pl = W.pl, np = pl.length, M = W.M, S = W.S;
    const frz = W.frz > 0;
    for (let i = 0; i < W.hiE; i++) {
      if (!W.eal[i]) continue;
      W.eag[i] += h;
      if (W.eoc[i] > 0) W.eoc[i] -= h;
      if (W.efl[i] > 0) W.efl[i] -= h;
      if (W.esl[i] > 0) W.esl[i] -= h;
      if (W.ebn[i] > 0) {   // burning (불꽃 술사)
        W.ebn[i] -= h;
        const bd = W.ebd[i] * h, bo = W.pl[W.ebo[i]];
        W.ehp[i] -= bd; if (bo) bo.dmg += bd;
        if (W.ebn[i] <= 0) W.ebd[i] = 0;
        if (W.ehp[i] <= 0) { killE(W, i, W.ebo[i]); continue; }
      }
      const b = ET[W.et[i]][6], boss = b === B_BOSS;
      let x = W.ex[i], y = W.ey[i];
      // nearest target
      let tp = null, td = 1e9;
      for (let k = 0; k < np; k++) { const p = pl[k]; if (p.dn) continue; const d = (p.x - x) ** 2 + (p.y - y) ** 2; if (d < td) { td = d; tp = p; } }
      td = Math.sqrt(td);
      let vx = 0, vy = 0;
      const froze = W.efz[i] > 0 || (frz && !boss);
      if (W.efz[i] > 0) W.efz[i] -= h;
      if (W.eph[i] === 9) {   // line swarm: straight flight, despawn after a while
        vx = W.edx[i] * W.esp[i]; vy = W.edy[i] * W.esp[i];
        if (W.eag[i] > 10) { remE(W, i); continue; }
      } else if (tp && !froze) {
        const dx = tp.x - x, dy = tp.y - y, ux = dx / (td || 1), uy = dy / (td || 1);
        let sp = W.esp[i];
        if (W.esl[i] > 0) sp *= 0.5;
        if (W.slowT > 0 && !boss) sp *= 0.5;
        if (W.tide && W.tide.on && b !== B_FLY && inTide(W, x)) sp *= 0.55;
        switch (b) {
          case B_FLY: { const w = Math.sin(W.eag[i] * 4 + i) * 0.7; vx = (ux - uy * w) * sp; vy = (uy + ux * w) * sp; break; }
          case B_GHOST: { const w = Math.sin(W.eag[i] * 2 + i) * 0.4; vx = (ux - uy * w) * sp; vy = (uy + ux * w) * sp; break; }
          case B_DASH: {
            W.ecd[i] -= h;
            if (W.eph[i] === 0) { vx = ux * sp * 0.8; vy = uy * sp * 0.8; if (W.ecd[i] <= 0 && td < 200) { W.eph[i] = 1; W.ecd[i] = 0.55; W.edx[i] = ux; W.edy[i] = uy; } }
            else if (W.eph[i] === 1) { if (W.ecd[i] <= 0) { W.eph[i] = 2; W.ecd[i] = 0.45; } }
            else { vx = W.edx[i] * sp * 4.2; vy = W.edy[i] * sp * 4.2; if (W.ecd[i] <= 0) { W.eph[i] = 0; W.ecd[i] = 2.4 + Math.random(); } }
            break;
          }
          case B_RANGED: {
            const f = td > 175 ? 1 : td < 115 ? -0.8 : 0, side = (i & 1) ? 1 : -1;
            vx = (ux * f - uy * side * 0.5) * sp; vy = (uy * f + ux * side * 0.5) * sp;
            W.ecd[i] -= h;
            if (W.ecd[i] <= 0 && td < 280) { W.ecd[i] = 3.4 + Math.random() * 1.2; addP(W, K.EB, x, y, Math.atan2(dy, dx), 95, 4, W.edm[i] * 0.6, 0, -1, 5); }
            break;
          }
          case B_BOSS: bossAct(W, i, tp, ux, uy, td, h); vx = W.edx[i]; vy = W.edy[i]; break;
          default: vx = ux * sp; vy = uy * sp;
        }
      }
      // knockback
      const kx = W.ekx[i], ky = W.eky[i];
      if (kx || ky) { const dk = Math.exp(-h * 9); W.ekx[i] = Math.abs(kx) < 1 ? 0 : kx * dk; W.eky[i] = Math.abs(ky) < 1 ? 0 : ky * dk; }
      let cvx = 0;
      let cvy = 0;
      if (S.conv && b !== B_FLY && b !== B_GHOST && !boss) cvx = convAt(M, y) * 36;
      if (W.wind && W.wind.on && !boss) { cvx += Math.cos(W.wind.a) * 24; cvy += Math.sin(W.wind.a) * 24; }
      x += (vx + kx + cvx) * h; y += (vy + ky + cvy) * h;
      // separation (light)
      const r = W.er[i], c = W.gCell[i];
      if (c >= 0) {
        const cx0 = c % GW, cy0 = (c / GW) | 0;
        let checks = 0;
        for (let yy = Math.max(0, cy0 - 1); yy <= Math.min(GW - 1, cy0 + 1) && checks < 14; yy++) for (let xx = Math.max(0, cx0 - 1); xx <= Math.min(GW - 1, cx0 + 1) && checks < 14; xx++) {
          const cc = yy * GW + xx, a = W.gStart[cc], e = W.gStart[cc + 1];
          for (let k = a; k < e && checks < 14; k++) {
            const j = W.gItems[k]; if (j === i || !W.eal[j]) continue;
            checks++;
            const dx = x - W.ex[j], dy = y - W.ey[j], m = r + W.er[j] - 2, d2 = dx * dx + dy * dy;
            if (d2 < m * m && d2 > 0.0001) {
              const d = Math.sqrt(d2), push = (m - d) * (boss ? 0.1 : 0.45);
              x += dx / d * push; y += dy / d * push;
            }
          }
        }
      }
      if (b !== B_FLY && b !== B_GHOST && W.eph[i] !== 9) { const o = pushOut(M, x, y, r * 0.8); x = o.x; y = o.y; }
      if (W.eph[i] !== 9) { x = clamp(x, r, WS - r); y = clamp(y, r, WS - r); }
      W.ex[i] = x; W.ey[i] = y;
      // contact damage
      if (!froze) for (let k = 0; k < np; k++) {
        const p = pl[k]; if (p.dn || p.hc > 0) continue;
        const m = r * 0.85 + PR * 0.75;
        if ((p.x - x) ** 2 + (p.y - y) ** 2 < m * m) { p.hc = 0.5; SRC = boss ? 'boss' : b; hurtP(W, p, W.edm[i], i); SRC = 'hz'; if (!W.eal[i]) break; }
      }
    }
  }
  function bossAct(W, i, tp, ux, uy, td, h) {
    W.ecd[i] -= h;
    const sp = W.esp[i] * (W.esl[i] > 0 ? 0.7 : 1), x = W.ex[i], y = W.ey[i], dm = W.edm[i] * 0.6;
    const ph = W.eph[i];
    if (ph === 0) {
      W.edx[i] = ux * sp; W.edy[i] = uy * sp;
      if (W.ecd[i] > 0) return;
      const list = BPAT[W.et[i]] || ['ring', 'summon', 'charge'], pat = list[Math.floor(Math.random() * list.length)];
      W.ecd[i] = 3.2;
      if (pat === 'ring') {      // wind up (glowing ring), then a ring of bullets
        W.eph[i] = 5; W.ecd[i] = 0.7; fx(W, 10, x, y, 0, 0);
      } else if (pat === 'summon') {
        const t = W.S.en[Math.floor(Math.random() * 3)];
        for (let k = 0; k < 7; k++) { const a = k * TAU / 7; addE(W, t, clamp(x + Math.cos(a) * 50, 20, WS - 20), clamp(y + Math.sin(a) * 50, 20, WS - 20), 0); }
        fx(W, 10, x, y, 1, 0);
      } else if (pat === 'charge') {
        W.eph[i] = 1; W.ecd[i] = 0.8; W.esl[i] = 0; fx(W, 10, x, y, 2, Math.round(Math.atan2(uy, ux) * 100));
        W.bdx[i] = ux; W.bdy[i] = uy;
      } else if (pat === 'spiral') {   // rotating stream of bullets for 2 s
        W.eph[i] = 3; W.ecd[i] = 2.4; W.bdx[i] = Math.random() * TAU; W.bdy[i] = 0.45; fx(W, 10, x, y, 3, 0);
      } else if (pat === 'fan') {      // three aimed 5-way volleys
        W.eph[i] = 4; W.ecd[i] = 2.0; W.bdy[i] = 0.45; fx(W, 10, x, y, 4, Math.round(Math.atan2(uy, ux) * 100));
      } else if (pat === 'slam') {     // red circles around the target, then they explode
        if (tp) for (let k = 0; k < 4; k++) {
          const a = Math.random() * TAU, d = k ? 50 + Math.random() * 90 : 0;
          W.Z.push({ k: 'slam', id: ++W.zid, x: clamp(tp.x + Math.cos(a) * d, 20, WS - 20), y: clamp(tp.y + Math.sin(a) * d, 20, WS - 20), r: 44, ph: 0, t: 1.2, dur: 0.3 });
        }
        fx(W, 10, x, y, 5, 0);
      } else if (pat === 'blink' && tp) {   // vanish and reappear next to the target, then a bullet ring
        const a = Math.random() * TAU, nx = clamp(tp.x + Math.cos(a) * 150, 40, WS - 40), ny = clamp(tp.y + Math.sin(a) * 150, 40, WS - 40);
        fx(W, 10, x, y, 6, 0); W.ex[i] = nx; W.ey[i] = ny; fx(W, 10, nx, ny, 6, 0);
        W.eph[i] = 1; W.ecd[i] = 0.7; W.bdx[i] = 0; W.bdy[i] = 0; W.bdy[i] = 9;   // 9 = ring after windup
      }
    } else if (ph === 1) {
      W.edx[i] = 0; W.edy[i] = 0;
      if (W.ecd[i] <= 0) {
        if (W.bdy[i] === 9) { const n = 16, a0 = Math.random() * TAU; for (let k = 0; k < n; k++) addP(W, K.BB, x, y, a0 + k * TAU / n, 100, 5, dm, 0, -1, 8); W.eph[i] = 0; W.ecd[i] = 2.6; }
        else { W.eph[i] = 2; W.ecd[i] = 0.9; }
      }
    } else if (ph === 2) {
      W.edx[i] = W.bdx[i] * sp * 5; W.edy[i] = W.bdy[i] * sp * 5;
      if (W.ecd[i] <= 0) { W.eph[i] = 0; W.ecd[i] = 2.5; }
    } else if (ph === 3) {
      W.edx[i] = ux * sp * 0.3; W.edy[i] = uy * sp * 0.3;
      W.bdy[i] -= h;
      if (W.bdy[i] <= 0) { W.bdy[i] = 0.11; W.bdx[i] += 0.42; for (let k = 0; k < 2; k++) addP(W, K.BB, x, y, W.bdx[i] + k * Math.PI, 90, 5, dm, 0, -1, 7); }
      if (W.ecd[i] <= 0) { W.eph[i] = 0; W.ecd[i] = 2.4; }
    } else if (ph === 4) {
      W.edx[i] = 0; W.edy[i] = 0;
      W.bdy[i] -= h;
      if (W.bdy[i] <= 0) { W.bdy[i] = 0.5; const a0 = Math.atan2(uy, ux); for (let k = -2; k <= 2; k++) addP(W, K.BB, x, y, a0 + k * 0.22, 115, 4, dm, 0, -1, 7); }
      if (W.ecd[i] <= 0) { W.eph[i] = 0; W.ecd[i] = 2.4; }
    } else if (ph === 5) {
      W.edx[i] = 0; W.edy[i] = 0;
      if (W.ecd[i] <= 0) { const n = 14, a0 = Math.random() * TAU; for (let k = 0; k < n; k++) addP(W, K.BB, x, y, a0 + k * TAU / n, 95, 5, dm, 0, -1, 8); W.eph[i] = 0; W.ecd[i] = 2.6; fx(W, 10, x, y, 7, 0); }
    }
  }

  /* ---------- gems / items ---------- */
  function xpNeed(W) { const l = W.lv; return Math.round((4 + 3 * l + 0.6 * l * l) * (0.8 + 0.2 * W.np)); }
  function teamXpMul(W) { let m = 1; for (const p of W.pl) m += p.S.xp; return m; }
  function stepGems(W, h) {
    const pl = W.pl;
    for (let j = 0; j < MAXG; j++) {
      if (!W.gal[j]) continue;
      const kd = W.gk[j];
      let x = W.gx[j], y = W.gy[j], tgt = W.gm[j] >= 0 ? pl[W.gm[j]] : null;
      if (tgt && tgt.dn) { W.gm[j] = -1; tgt = null; }
      if (!tgt) {
        for (const p of pl) {
          if (p.dn) continue;
          const pr = kd >= 4 ? 24 : p.S.pk, d2 = (p.x - x) ** 2 + (p.y - y) ** 2;
          if (d2 < pr * pr) { W.gm[j] = p.s; tgt = p; break; }
        }
      }
      if (!tgt) continue;
      const dx = tgt.x - x, dy = tgt.y - y, d = hyp(dx, dy);
      if (d < 14) { collect(W, j, tgt); continue; }
      const sp = kd >= 7 ? 0 : 300;
      if (kd >= 7) { if (d < 26) collect(W, j, tgt); continue; }
      W.gx[j] = x + dx / d * Math.min(d, sp * h); W.gy[j] = y + dy / d * Math.min(d, sp * h);
    }
  }
  function collect(W, j, p) {
    const kd = W.gk[j], v = W.gv[j], x = W.gx[j], y = W.gy[j];
    W.gal[j] = 0; W.nG--;
    if (kd < 4) { W.xp += v * teamXpMul(W); levelCheck(W); return; }
    if (kd === 4) { heal(p, 30 * p.S.fd); fx(W, 12, x, y, p.s, 0); }
    else if (kd === 5) { for (let k = 0; k < MAXG; k++) if (W.gal[k] && W.gk[k] < 4) W.gm[k] = p.s; fx(W, 13, x, y, p.s, 0); }
    else if (kd === 6) { W.frz = 4; fx(W, 14, x, y, p.s, 0); }
    else if (kd === 7) { p.rq.push(0); W.chests++; p.chest++; fx(W, 22, x, y, p.s, 0); }
    else if (kd === 8) { for (const q of W.pl) { q.rq.push(1); q.chest++; } W.chests++; fx(W, 22, x, y, p.s, 1); }
  }
  function levelCheck(W) {
    let guard = 0;
    while (W.xp >= xpNeed(W) && guard++ < 10) {
      const need = xpNeed(W);
      W.xp -= need; W.lv++;
      for (const p of W.pl) p.pq.push(need);
      if (W.sands) W.slowT = 3;
      if (W.stone) for (const p of W.pl) if (hasR(p, 34)) {
        const up = p.W.filter((w) => !w.e && w.l < WLV);
        if (up.length) { const w = up[Math.floor(Math.random() * up.length)]; w.l++; fx(W, 21, p.x, p.y, p.s, 4); }
      }
      fx(W, 3, 0, 0, W.lv, 0);
    }
  }
  // skipping a level-up refunds half of that level's XP, split by the number of players (XP is shared)
  const refundOf = (W, need) => 0.5 * need / W.np;

  /* ---------- cards ---------- */
  const isW = (id) => id >= 0 && id < WP.length, isP = (id) => id >= PI0 && id < TR0, isT = (id) => id >= TR0 && id < TR0 + TR.length, isEv = (id) => id >= EV0 && id < EV0 + EVO.length;
  // level the player has of any card (weapon / item / trait)
  function cardLv(p, id) { if (isW(id)) { const w = p.W.find((x) => x.i === id); return w ? w.l : 0; } return isT(id) ? tlvl(p, id - TR0) : isP(id) ? plvl(p, id - PI0) : 0; }
  const partnerLv = cardLv;
  function canHaveW(p, i) { const ex = WP[i].ex; return ex == null || ex === p.ch; }
  function isExcl(p, id) { return (isW(id) && WP[id].ex === p.ch) || (isEv(id) && EVO[id - EV0].ex === p.ch) || (isT(id) && (CH[p.ch] || CH[0]).tr.indexOf(id - TR0) >= 0); }
  // is evolution k available to this weapon right now? (1st: Lv 6, not evolved; 2nd: currently the parent evolution)
  function evoStageOk(w, E) { return E.from < 0 ? (!w.e && w.l >= WLV) : w.e === E.from + 1; }
  function reqMet(p, E) { for (const r of E.req) if (cardLv(p, r[0]) < r[1]) return false; return true; }
  function evoReady(p) {
    const o = [];
    EVO.forEach((E, k) => { if (WP[E.w].ex != null && WP[E.w].ex !== p.ch) return; const w = p.W.find((x) => x.i === E.w); if (w && evoStageOk(w, E) && reqMet(p, E)) o.push(EV0 + k); });
    return o;
  }
  // evolutions this card helps towards (for the "고르면 ○○ 진화" hint)
  function evoHints(p, id) {
    const out = [];
    EVO.forEach((E) => {
      if (WP[E.w].ex != null && WP[E.w].ex !== p.ch) return;
      const w = p.W.find((x) => x.i === E.w);
      if (isW(id) && id === E.w && E.from < 0) out.push(E);
      else if (E.req.some((r) => r[0] === id) && (w || E.from < 0 && isExcl(p, E.w))) {
        if (E.from >= 0 && !(w && w.e)) return;
        out.push(E);
      }
    });
    return out;
  }
  function cardPool(p) {
    const out = [], c = CH[p.ch] || CH[0];
    for (const id of evoReady(p)) out.push([id, 8]);
    for (const w of p.W) if (!w.e && w.l < WLV) out.push([w.i, WP[w.i].ex != null ? 3.5 : 3]);
    for (const q of p.P) if (q.l < PS[q.i].mx) out.push([PI0 + q.i, 2]);
    // a path trait shows up once its weapon is owned (sig weapon from the start, the 2nd weapon after you pick it)
    c.tr.forEach((t, k) => { const l = tlvl(p, t), pw = k === 0 || k === 2 ? c.w : c.w2; if (l < TMX && (l || p.W.some((w) => w.i === pw))) out.push([TR0 + t, l ? 2.5 : 1.8]); });
    if (p.W.length < WMAX) for (let i = 0; i < WP.length; i++) if (canHaveW(p, i) && !p.W.some((w) => w.i === i)) out.push([i, WP[i].ex === p.ch ? 3 : 1]);
    if (p.P.length < PMAX_SLOTS) for (let i = 0; i < PS.length; i++) if (!p.P.some((q) => q.i === i)) out.push([PI0 + i, 1]);
    return out;
  }
  function wpick(list, not) {
    let tot = 0; for (const e of list) if (not.indexOf(e[0]) < 0) tot += e[1];
    if (tot <= 0) return -1;
    let r = Math.random() * tot;
    for (const e of list) { if (not.indexOf(e[0]) >= 0) continue; r -= e[1]; if (r <= 0) return e[0]; }
    return -1;
  }
  function makeOffer(W, p) {
    const pool = cardPool(p), c = [];
    const ev = U.shuffle(pool.filter((e) => isEv(e[0])));
    for (const e of ev) if (c.length < 2) c.push(e[0]);   // up to 2 evolutions → branch choice
    // every offer mixes in the character's own build when anything exclusive is left
    if (!c.some((id) => isExcl(p, id))) { const ex = pool.filter((e) => isExcl(p, e[0])), id = wpick(ex, c); if (id >= 0) c.push(id); }
    while (c.length < 3) { const id = wpick(pool, c); if (id < 0) break; c.push(id); }
    if (c.length < 3) c.push(FH);
    if (c.length < 3) c.push(FM);
    W.oq = (W.oq % 30000) + 1;
    p.off = { q: W.oq, c: U.shuffle(c), n: p.pq[0] || xpNeed(W) }; p.offT = 0;
  }
  function applyCard(W, p, id) {
    if (isEv(id)) {
      const k = id - EV0, E = EVO[k], w = p.W.find((x) => x.i === E.w);
      if (w && evoStageOk(w, E)) { w.e = k + 1; w.l = WLV; p.evo++; fx(W, 11, p.x, p.y, p.s, k); }
    } else if (isT(id)) {
      const t = id - TR0, q = p.T.find((x) => x.i === t);
      if (q) q.l = Math.min(TMX, q.l + 1); else if ((CH[p.ch] || CH[0]).tr.indexOf(t) >= 0) p.T.push({ i: t, l: 1 });
    } else if (isP(id)) {
      const q = p.P.find((x) => x.i === id - PI0);
      if (q) q.l = Math.min(PS[q.i].mx, q.l + 1); else if (p.P.length < PMAX_SLOTS) p.P.push({ i: id - PI0, l: 1 });
    } else if (isW(id)) {
      const w = p.W.find((x) => x.i === id);
      if (w) w.l = Math.min(WLV, w.l + 1); else if (p.W.length < WMAX && canHaveW(p, id)) p.W.push({ i: id, l: 1, e: 0, cd: 0.3, t: 0 });
    } else if (id === FH) heal(p, 30);
    else if (id === FM) p.mt = (p.mt || 0) + 1;
    recalcAll(W);
  }
  // idx < 0 = skip (refund part of the XP)
  function pickCard(W, p, idx) {
    if (!p.off) return;
    const o = p.off;
    p.off = null; p.pq.shift();
    if (idx < 0) {
      const rf = refundOf(W, o.n);
      p.skips++; W.xp += rf;
      fx(W, 23, p.x, p.y, p.s, Math.round(rf * 10));
      levelCheck(W);
      return;
    }
    applyCard(W, p, o.c[clamp(idx | 0, 0, o.c.length - 1)]);
  }

  /* ---------- relics ---------- */
  function rollRelic(p, big, not) {
    const wt = big ? RW_BOSS : RW_ELITE;
    let tot = 0; for (const v of wt) tot += v;
    let r = Math.random() * tot, rar = 0;
    for (let k = 0; k < 4; k++) { r -= wt[k]; if (r <= 0) { rar = k; break; } }
    for (let d = 0; d < 4; d++) {   // fall back to the nearest rarity that still has something left
      for (const rr of d ? [rar - d, rar + d] : [rar]) {
        if (rr < 0 || rr > 3) continue;
        const list = [];
        RE.forEach((x, i) => { if (x.r === rr && p.R.indexOf(i) < 0 && not.indexOf(i) < 0) list.push(i); });
        if (list.length) return list[Math.floor(Math.random() * list.length)];
      }
    }
    return -1;
  }
  function makeRelicOffer(W, p) {
    const big = p.rq[0] | 0, c = [];
    for (let k = 0; k < 3; k++) { const id = rollRelic(p, big, c); if (id < 0) break; c.push(id); }
    if (!c.length) { p.rq.shift(); return; }
    W.oq = (W.oq % 30000) + 1;
    p.ro = { q: W.oq, c, b: big }; p.roT = 0;
  }
  function pickRelic(W, p, idx) {
    if (!p.ro) return;
    const c = p.ro.c;
    p.ro = null; p.rq.shift();
    if (!(idx >= 0 && idx < c.length)) { fx(W, 24, p.x, p.y, p.s, 0); return; }
    const id = c[idx];
    if (p.R.indexOf(id) >= 0) return;
    p.R.push(id);
    recalcAll(W);
    if (id === 10) p.hp = p.mhp;
    fx(W, 4, p.x, p.y, p.s, id);
  }

  /* ---------- AI (bots) ---------- */
  const AIP = {
    1: { re: 0.25, R: 110, tw: 320, noise: 0.4, gem: 140, coh: 230, dash: 0, hz: 0.8, rev: 220, pickR: 0 },
    2: { re: 0.16, R: 130, tw: 480, noise: 0.25, gem: 230, coh: 260, dash: 0.5, hz: 0.9, rev: 600, pickR: 1 },
    3: { re: 0.08, R: 170, tw: 600, noise: 0.05, gem: 300, coh: 280, dash: 1, hz: 1, rev: 2000, pickR: 2 },
  };
  function aiThink(W, s, mem, lv, h, out) {
    const p = W.pl[s], D = AIP[lv] || AIP[2];
    out.d = out.d || 0;
    if (!p || p.dn) { out.mx = out.my = 0; return; }
    if (p.ro || p.off) {
      // choose a relic / card
      mem.pk = (mem.pk || 0) + h;
      if (mem.pk > (lv === 1 ? 0.6 : 0.3) || W.solo) { mem.pk = 0; if (p.ro) pickRelic(W, p, aiRelic(p, lv)); else pickCard(W, p, aiCard(p, lv)); }
    }
    mem.t = (mem.t || 0) - h;
    if (mem.t > 0) return;
    mem.t = D.re * (0.8 + Math.random() * 0.4);
    let ax = 0, ay = 0, thr = 0;
    // enemies (threat field)
    const R = D.R, n = query(W, p.x, p.y, R);
    for (let q = 0; q < n; q++) {
      const i = QB[q], dx = p.x - W.ex[i], dy = p.y - W.ey[i], d = hyp(dx, dy);
      if (d > R) continue;
      const g = d - W.er[i] - PR, w = Math.sqrt(W.edm[i] / 6) * (ET[W.et[i]][6] === B_BOSS ? 4 : W.eel[i] ? 2 : 1) / Math.max(6, g) ** 2 * D.tw;
      ax += dx / (d || 1) * w; ay += dy / (d || 1) * w; thr += w;
    }
    // bullets
    if (lv >= 2) for (let i = 0; i < W.hiP; i++) {
      if (!W.pal[i] || (W.pk[i] !== K.EB && W.pk[i] !== K.BB)) continue;
      const dx = p.x - W.px[i], dy = p.y - W.py[i];
      if (dx * dx + dy * dy > 160 * 160) continue;
      const vx = W.pvx[i], vy = W.pvy[i], v2 = vx * vx + vy * vy || 1, ts = (dx * vx + dy * vy) / v2;
      if (ts < 0 || ts > 1.4) continue;
      const cx = dx - vx * ts, cy = dy - vy * ts, cd = hyp(cx, cy), lim = W.pr[i] + PR + 10;
      if (cd > lim) continue;
      const w = 3 * (1 - cd / lim + 0.3) * (1.5 - ts);
      ax += (cd > 0.5 ? cx / cd : -vy / Math.sqrt(v2)) * w; ay += (cd > 0.5 ? cy / cd : vx / Math.sqrt(v2)) * w; thr += w * 0.5;
    }
    // hazards
    for (const z of W.Z) {
      if (z.k === 'spore' || z.ph >= 0) {
        if (Math.random() > D.hz) continue;
        const dx = p.x - z.x, dy = p.y - z.y, d = hyp(dx, dy), m = z.r + 26;
        if (d < m) { const w = 3 * (1 - d / m) + 0.6; ax += dx / (d || 1) * w; ay += dy / (d || 1) * w; thr += w; }
      }
    }
    if (W.S.lava) for (const pl of W.M.pools) { const dx = p.x - pl.x, dy = p.y - pl.y, d = hyp(dx, dy), m = pl.r + 30; if (d < m) { const w = 2.5 * (1 - d / m) + 0.4; ax += dx / (d || 1) * w; ay += dy / (d || 1) * w; } }
    if (W.tide && lv >= 2 && (W.tide.on || W.tide.warn > 0)) {
      const sd = W.tide.side;
      if (sd < 0 ? p.x < 900 : p.x > WS - 900) ax += -sd * 1.6;
    }
    // walls
    const wm = 140;
    if (p.x < wm) ax += (wm - p.x) / wm * 2.5; if (p.x > WS - wm) ax -= (p.x - WS + wm) / wm * 2.5;
    if (p.y < wm) ay += (wm - p.y) / wm * 2.5; if (p.y > WS - wm) ay -= (p.y - WS + wm) / wm * 2.5;
    // strafe sideways around the threat (keeps kiting instead of running into a wall)
    if (thr > 0.05) {
      const tm = hyp(ax, ay) || 1, tx = ax / tm, ty = ay / tm;
      if (!mem.sd || Math.random() < 0.02) mem.sd = Math.random() < 0.5 ? 1 : -1;
      const cx = WS / 2 - p.x, cy = WS / 2 - p.y; // bias the strafe toward open (central) space
      const sx = -ty * mem.sd, sy = tx * mem.sd;
      if (sx * cx + sy * cy < 0 && hyp(cx, cy) > 500) mem.sd = -mem.sd;
      ax += -ty * mem.sd * Math.min(1.2, thr) * 0.8; ay += tx * mem.sd * Math.min(1.2, thr) * 0.8;
    }
    // goals
    let gx = 0, gy = 0, gw = 0;
    const down = W.pl.find((q) => q.dn && hyp(q.x - p.x, q.y - p.y) < D.rev);
    let anchor = null;
    for (const q of W.pl) if (q !== p && !q.dn && W.st.hu && W.st.hu[q.s]) { if (!anchor || hyp(q.x - p.x, q.y - p.y) < hyp(anchor.x - p.x, anchor.y - p.y)) anchor = q; }
    if (!anchor) for (const q of W.pl) if (q !== p && !q.dn) { anchor = q; break; }
    if (down) { gx = down.x; gy = down.y; gw = lv === 3 ? 3.2 : 2.2; }
    else {
      // items first (chest, food when hurt), else nearest gem cluster
      let best = -1, bs = 0;
      for (let j = 0; j < MAXG; j++) {
        if (!W.gal[j]) continue;
        const d = hyp(W.gx[j] - p.x, W.gy[j] - p.y), kd = W.gk[j];
        let val = kd >= 7 ? 6 : kd === 4 ? (p.hp < p.mhp * 0.6 ? 5 : 0.2) : kd === 5 || kd === 6 ? 3 : 1 + kd * 0.6;
        const lim = kd >= 4 ? D.gem * 1.8 : D.gem;
        if (d > lim) continue;
        let risk = 0;
        if (lv > 1) { const m = query(W, W.gx[j], W.gy[j], 40); for (let q = 0; q < m; q++) { const e = QB[q]; if ((W.ex[e] - W.gx[j]) ** 2 + (W.ey[e] - W.gy[j]) ** 2 < 1600) risk++; } }
        const sc = val / (40 + d) / (1 + risk * 0.3);
        if (sc > bs) { bs = sc; best = j; }
      }
      if (best >= 0) { gx = W.gx[best]; gy = W.gy[best]; gw = W.gk[best] >= 4 ? 2 : 1.4; }
    }
    if (gw) { const dx = gx - p.x, dy = gy - p.y, d = hyp(dx, dy) || 1, k = down ? gw : gw / (1 + thr * 0.4); ax += dx / d * k; ay += dy / d * k; }
    if (anchor) {
      const dx = anchor.x - p.x, dy = anchor.y - p.y, d = hyp(dx, dy);
      if (d > D.coh * 0.6) { const w = Math.min(2.4, (d - D.coh * 0.6) / D.coh * 2); ax += dx / d * w; ay += dy / d * w; }
    }
    if (!gw && thr < 0.05 && hyp(ax, ay) < 0.2) {
      // idle: drift in a slow circle around the centre / anchor
      mem.wa = (mem.wa || Math.random() * TAU) + 0.6 * D.re * 3;
      ax += Math.cos(mem.wa) * 0.6; ay += Math.sin(mem.wa) * 0.6;
    }
    let m = hyp(ax, ay);
    if (m < 0.08) { out.mx = 0; out.my = 0; return; }
    let a = Math.atan2(ay, ax) + (Math.random() - 0.5) * D.noise * 2 * (lv === 1 ? 1 : 0.6);
    out.mx = Math.cos(a); out.my = Math.sin(a);
    if (D.dash && W.st.dsh && p.dc <= 0 && thr > 1.6 && Math.random() < D.dash) { out.d = (out.d % 1000) + 1; }
  }
  // card choice. returns -1 to skip (refund) when nothing on offer is worth a slot
  function aiCard(p, lv) {
    const c = p.off.c;
    if (lv === 1) return Math.random() < 0.05 ? -1 : Math.floor(Math.random() * c.length);
    let best = 0, bs = -1e9;
    c.forEach((id, k) => {
      let sc = 0;
      if (isEv(id)) { const E = EVO[id - EV0]; sc = 200 + (E.from >= 0 ? 30 : 0) + (lv === 3 && p.ap != null && E.req.some((r) => r[0] === TR0 + (CH[p.ch] || CH[0]).tr[p.ap]) ? 20 : 0) + Math.random() * 10; }
      else if (isW(id)) {
        const w = p.W.find((x) => x.i === id), ex = WP[id].ex === p.ch;
        sc = w ? 40 + w.l * (lv === 3 ? 4 : 1) + (ex ? 8 : 0) : ex ? 48 : (p.W.length < (lv === 3 ? 4 : 5) ? 30 : 6);
        if (lv === 3 && !w && !ex && p.W.length >= 4) sc -= 20;   // keep slots for the own build
      } else if (isT(id)) {
        const t = id - TR0, has = tlvl(p, t);
        sc = 44 + has * 3;
        // bots commit to one build path (갈래) and favour its trait
        if (p.ap == null) p.ap = Math.floor(Math.random() * 4);
        if (lv >= 2 && (CH[p.ch] || CH[0]).tr[p.ap] === t) sc += lv === 3 && p.W.some((w) => w.l >= 3) ? 26 : 8;
        if (lv === 3 && evoHints(p, id).some((E) => p.W.some((w) => w.i === E.w))) sc += 10;
      } else if (isP(id)) {
        const pi = id - PI0, has = plvl(p, pi);
        sc = 22 + has * 2;
        if (lv === 3) { if (evoHints(p, id).some((E) => p.W.some((w) => w.i === E.w))) sc += 26; if ([0, 2, 3, 6].includes(pi)) sc += 8; if (!has && p.P.length >= 4) sc -= 14; }
      } else sc = id === FH ? (p.hp < p.mhp * 0.5 ? 30 : 2) : 3;
      sc += Math.random() * (lv === 3 ? 3 : 10);
      if (sc > bs) { bs = sc; best = k; }
    });
    // skip (get XP back) when every card is filler / a waste of a slot
    if (bs < (lv === 3 ? 12 : 6)) return -1;
    return best;
  }
  // relic choice. risky relics only when the bot can afford them; skip if nothing fits
  function aiRelic(p, lv) {
    const c = p.ro.c;
    if (lv === 1) return Math.random() < 0.1 ? -1 : Math.floor(Math.random() * c.length);
    let best = -1, bs = 0;
    c.forEach((id, k) => {
      const r = RE[id];
      let sc = 10 + r.r * 12 + Math.random() * (lv === 3 ? 2 : 6);
      if (r.rk) {
        const tough = p.S.arm >= 3 || p.S.rg >= 0.6 || p.mhp >= 160;
        sc = lv === 3 && tough ? sc + 6 : lv === 3 ? sc - 30 : sc - 20;
      }
      if (id === 10 && p.hp < p.mhp * 0.5) sc += 15;
      if ((id === 17 || id === 33 || id === 28) && p.ch === 4) sc += 6;
      if (sc > bs) { bs = sc; best = k; }
    });
    return best;
  }

  /* ---------- stage gimmicks ---------- */
  function addSpore(W) {
    const a = Math.random() * TAU, sp = 18 + Math.random() * 10;
    W.Z.push({ k: 'spore', id: ++W.zid, x: 300 + Math.random() * (WS - 600), y: 300 + Math.random() * (WS - 600), r: 62, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, ph: 1, t: 0 });
  }
  function hazards(W, h) {
    const S = W.S, al = alivePl(W);
    if (W.frz > 0) W.frz -= h;
    CURW = -1;
    for (const key of ['wind', 'dark']) {
      const g = W[key]; if (!g) continue;
      if (g.warn > 0) { g.warn -= h; if (g.warn <= 0) g.on = 1; }
      else if (g.on) { g.t -= h; if (g.t <= 0) W[key] = null; }
    }
    // tide
    if (S.hz === 'tide') {
      if (!W.tide) W.tide = { on: 0, warn: 0, x: 0, side: -1, t: 0 };
      const t = W.tide;
      W.tideT -= h;
      if (!t.on && t.warn <= 0 && W.tideT <= 0) { t.side = Math.random() < 0.5 ? -1 : 1; t.warn = 3; fx(W, 15, 0, 0, t.side, 0); }
      if (t.warn > 0) { t.warn -= h; if (t.warn <= 0) { t.on = 1; t.t = 14; } }
      if (t.on) { t.t -= h; if (t.t <= 0) { t.on = 0; W.tideT = 40; } }
      const goal = t.on ? (t.side < 0 ? 820 : WS - 820) : (t.side < 0 ? -10 : WS + 10);
      t.x += (goal - t.x) * Math.min(1, h * 1.2);
      if (!t.on && t.warn <= 0 && Math.abs(t.x - goal) < 2) t.x = goal;
    }
    // drifting / timed zones
    for (let k = W.Z.length - 1; k >= 0; k--) {
      const z = W.Z[k];
      if (z.k === 'spore') {
        z.x += z.vx * h; z.y += z.vy * h;
        if (z.x < 120 || z.x > WS - 120) z.vx = -z.vx;
        if (z.y < 120 || z.y > WS - 120) z.vy = -z.vy;
        if (Math.random() < h * 0.2 && al.length) { const p = al[Math.floor(Math.random() * al.length)], a = Math.atan2(p.y - z.y, p.x - z.x), sp = hyp(z.vx, z.vy); z.vx = Math.cos(a) * sp; z.vy = Math.sin(a) * sp; }
        z.t -= h;
        if (z.t <= 0) { z.t = 0.5; for (const p of al) if (hyp(p.x - z.x, p.y - z.y) < z.r) hurtP(W, p, 3); }
        continue;
      }
      z.t -= h;
      if (z.ph === 0 && z.t <= 0) {
        z.ph = 1; z.t = z.dur;
        if (z.k === 'hand') { for (const p of al) if (hyp(p.x - z.x, p.y - z.y) < z.r + PR) { p.rt = Math.max(p.rt, 1.1); hurtP(W, p, 8); } }
        else if (z.k === 'icicle') { for (const p of al) if (hyp(p.x - z.x, p.y - z.y) < z.r + PR * 0.6) hurtP(W, p, 14); zoneHit(W, z.x, z.y, z.r, 60, -1, 0, 0); }
        else if (z.k === 'bolt') { for (const p of al) if (hyp(p.x - z.x, p.y - z.y) < z.r + PR * 0.6) hurtP(W, p, 15); zoneHit(W, z.x, z.y, z.r, 80, -1, 0, 0); }
        else if (z.k === 'slam') { for (const p of al) if (hyp(p.x - z.x, p.y - z.y) < z.r + PR * 0.6) hurtP(W, p, 16); }
        else if (z.k === 'steam') {
          for (const p of al) { const dx = p.x - z.x, dy = p.y - z.y, d = hyp(dx, dy); if (d < z.r + PR) { hurtP(W, p, 9); p.vx = 0; const o = pushOut(W.M, p.x + dx / (d || 1) * 60, p.y + dy / (d || 1) * 60, PR); p.x = clamp(o.x, PR, WS - PR); p.y = clamp(o.y, PR, WS - PR); } }
          zoneHit(W, z.x, z.y, z.r, 30, -1, 0, -60);
        }
        fx(W, 16, z.x, z.y, z.r, ['hand', 'icicle', 'erupt', 'steam', 'bolt', 'slam'].indexOf(z.k));
      } else if (z.ph === 1) {
        if (z.k === 'erupt') {
          z.tk = (z.tk || 0) - h;
          if (z.tk <= 0) { z.tk = 0.4; for (const p of al) if (hyp(p.x - z.x, p.y - z.y) < z.r + PR) hurtP(W, p, 7); zoneHit(W, z.x, z.y, z.r, 20, -1, 0, 0); }
        }
        if (z.t <= 0) W.Z.splice(k, 1);
      }
    }
    // spawn new timed hazards
    W.hzT -= h;
    if (W.hzT <= 0 && al.length) {
      const f = prog(W);
      if (S.hz === 'hand') {
        W.hzT = Math.max(6, 10 - 3 * f);
        for (const p of al) W.Z.push({ k: 'hand', id: ++W.zid, x: p.x + p.vx * 0.5, y: p.y + p.vy * 0.5, r: 30, ph: 0, t: 1.3, dur: 0.35 });
      } else if (S.hz === 'icicle') {
        W.hzT = Math.max(2.8, 4.6 - 1.4 * f);
        for (let q = 0; q < 2; q++) { const p = al[Math.floor(Math.random() * al.length)]; W.Z.push({ k: 'icicle', id: ++W.zid, x: clamp(p.x + p.vx * 0.8 + (Math.random() - 0.5) * 140, 20, WS - 20), y: clamp(p.y + p.vy * 0.8 + (Math.random() - 0.5) * 140, 20, WS - 20), r: 26, ph: 0, t: 1.1, dur: 0.3 }); }
      } else if (S.hz === 'erupt') {
        W.hzT = Math.max(3.5, 6 - 2 * f);
        for (let q = 0; q < 2; q++) { const p = al[Math.floor(Math.random() * al.length)]; W.Z.push({ k: 'erupt', id: ++W.zid, x: clamp(p.x + (Math.random() - 0.5) * 220, 30, WS - 30), y: clamp(p.y + (Math.random() - 0.5) * 220, 30, WS - 30), r: 46, ph: 0, t: 1.3, dur: 1.6 }); }
      } else if (S.hz === 'steam') {
        W.hzT = Math.max(3, 5 - 1.5 * f);
        const near = W.M.vents.filter((v) => al.some((p) => hyp(p.x - v.x, p.y - v.y) < 380));
        U.shuffle(near).slice(0, 3).forEach((v) => W.Z.push({ k: 'steam', id: ++W.zid, x: v.x, y: v.y, r: 42, ph: 0, t: 1.0, dur: 0.5 }));
      } else if (S.hz === 'spore') {
        W.hzT = 30;
        if (W.Z.length < 3 + Math.floor(f * 2)) addSpore(W);
      } else if (S.hz === 'storm') {
        W.hzT = Math.max(2.4, 4 - 1.2 * f);
        for (let q = 0; q < 2; q++) { const p = al[Math.floor(Math.random() * al.length)]; W.Z.push({ k: 'bolt', id: ++W.zid, x: clamp(p.x + p.vx * 0.9 + (Math.random() - 0.5) * 160, 20, WS - 20), y: clamp(p.y + p.vy * 0.9 + (Math.random() - 0.5) * 160, 20, WS - 20), r: 36, ph: 0, t: 1.0, dur: 0.25 }); }
      } else if (S.hz === 'sand') {
        W.hzT = 34 + Math.random() * 8;
        W.wind = { on: 0, warn: 3, t: 10, a: Math.random() * TAU };
        fx(W, 17, 0, 0, 1, Math.round(W.wind.a * 100));
      } else if (S.hz === 'dark') {
        W.hzT = 38 + Math.random() * 8;
        W.dark = { on: 0, warn: 3, t: 13 };
        fx(W, 17, 0, 0, 2, 0);
      } else W.hzT = 10;
    }
  }

  /* ---------- main step ---------- */
  const NOC = { mx: 0, my: 0, d: 0 };
  function stepWorld(W, C, h) {
    if (W.over) return;
    if (W.paused) return;
    W.T += h;
    director(W, h);
    hazards(W, h);
    stepPlayers(W, C, h);
    stepEnemies(W, h);
    stepProj(W, h);
    stepGems(W, h);
    runDeferred(W);
    if (W.slowT > 0) W.slowT -= h;
    // offers: relic chests first, then level-up cards; online multi-human: auto-pick after 15 / 12 s
    for (const p of W.pl) {
      if (!p.ro && !p.off && p.rq.length) makeRelicOffer(W, p);
      if (!p.ro && !p.off && p.pq.length) makeOffer(W, p);
      if (p.ro) { p.roT += h; if (!W.solo && p.roT > 15) pickRelic(W, p, aiRelic(p, 2)); }
      else if (p.off) { p.offT += h; if (!W.solo && p.offT > 12) pickCard(W, p, Math.floor(Math.random() * p.off.c.length)); }
    }
    // end conditions
    const al = alivePl(W);
    if (!al.length) { W.over = 1; W.win = 0; }
    else if (W.T >= W.dur) { W.over = 1; W.win = 1; }
  }

  /* ======================= coarse state ======================= */
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 1, 4);
    const so = typeof o.stage === 'number' && o.stage >= -1 && o.stage < STG.length ? o.stage : -1;
    let mins = +o.time; if (!(mins >= 1 && mins <= 20)) mins = 10;
    const hu = players.map((p) => (p && !p.ai ? 1 : 0));
    const ch = players.map((p, i) => (p && p.ai ? -1 : -1));
    // bots: random characters, different from each other where possible
    const bag = U.shuffle(CH.map((c, i) => i));
    players.forEach((p, i) => { if (p && p.ai) ch[i] = bag[i % bag.length]; });
    return { rid: 1 + U.rand(99999), nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), np, hu,
      so, sg: so >= 0 ? so : U.rand(STG.length), dur: Math.round(mins * 60), dsh: o.dash === 0 ? 0 : 1,
      seed: 1 + U.rand(2147483000), ph: 'pick', ch, res: null };
  }
  function finish(st, W) {
    const res = W.pl.map((p) => {
      const top = p.wd.map((v, i) => [i, v]).filter((q) => q[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 3);
      const r = [p.kills | 0, Math.round(p.dmg / 100), p.revs | 0, p.dn ? 0 : 1, p.evo | 0, p.chest | 0, Math.round(p.tk), p.R.length];
      top.forEach((q) => r.push(q[0], Math.round(q[1] / 100)));
      return r;
    });
    return Object.assign({}, st, { ph: 'done', res, win: W.win ? 1 : 0, t: Math.round(Math.min(W.T, W.dur)), lv: W.lv, kills: W.kills, bosses: W.bosses });
  }
  function fmt(t) { t = Math.max(0, Math.floor(t)); const m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s; }
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res)) return null;
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번', S = STG[st.sg] || STG[0];
    const order = st.res.map((r, i) => i).sort((a, b) => st.res[b][0] - st.res[a][0]);
    const kf = (v) => (v >= 100 ? (v / 100).toFixed(1) + '만' : String(v * 100));
    const lines = [];
    order.forEach((i) => {
      const r = st.res[i];
      lines.push(nm(i) + ' (' + (CH[st.ch[i]] || CH[0]).nm + ') — 처치 ' + r[0] + ' · 받은 피해 ' + (r[6] | 0) + (r[2] ? ' · 살림 ' + r[2] : '') + (r[7] ? ' · 유물 ' + r[7] : '') + (r[4] ? ' · 진화 ' + r[4] : ''));
      const ws = [];
      for (let k = 8; k + 1 < r.length; k += 2) if (WP[r[k]] && r[k + 1] > 0) ws.push(WP[r[k]].nm + ' ' + kf(r[k + 1] | 0));
      if (ws.length) lines.push('   무기 피해: ' + ws.join(' · '));
    });
    const head = S.nm + ' · ' + fmt(st.t) + ' / ' + fmt(st.dur) + ' · 팀 레벨 ' + st.lv + ' · 보스 ' + (st.bosses | 0);
    if (st.win) return { winners: st.res.map((r, i) => i), title: '새벽까지 버텼어요!', text: head + '\n' + lines.join('\n') };
    return { winners: [], title: '전멸… ' + fmt(st.t) + ' 버팀', text: head + '\n' + lines.join('\n') };
  }

  /* ======================= net encoding ======================= */
  const ZK = ['spore', 'hand', 'icicle', 'erupt', 'steam', 'bolt', 'slam'];
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const B64I = {}; for (let i = 0; i < 64; i++) B64I[B64[i]] = i;
  let TA = ''; for (let c = 35; c <= 126; c++) if (c !== 92) TA += String.fromCharCode(c);
  const TAI = {}; for (let i = 0; i < TA.length; i++) TAI[TA[i]] = i;
  const q2 = (v) => { const n = clamp(Math.round(v * 2), 0, 4095); return B64[n >> 6] + B64[n & 63]; };
  const d2 = (s, o) => ((B64I[s[o]] | 0) * 64 + (B64I[s[o + 1]] | 0)) / 2;
  const qa = (a) => B64[((Math.round(a / TAU * 64) % 64) + 64) % 64];
  const da = (c) => (B64I[c] | 0) / 64 * TAU;
  const qc = (v) => B64[clamp(Math.round(v), 0, 63)];
  function invStr(p) {
    let s = '';
    for (const w of p.W) s += TA[w.i] + TA[w.l] + TA[w.e | 0];
    for (const q of p.P) s += TA[PI0 + q.i] + TA[q.l];
    for (const q of p.T) s += TA[TR0 + q.i] + TA[q.l];
    return s;
  }
  const relStr = (p) => p.R.map((i) => TA[i]).join('');
  function parseRel(s, p) { p.R = []; if (typeof s !== 'string') return; for (let k = 0; k < s.length && k < 40; k++) { const i = TAI[s[k]]; if (i >= 0 && i < RE.length && p.R.indexOf(i) < 0) p.R.push(i); } }
  function parseInv(s, p) {
    p.W = []; p.P = []; p.T = [];
    if (typeof s !== 'string') return;
    for (let k = 0; k + 1 < s.length; k += 2) {
      const a = TAI[s[k]] | 0, b = TAI[s[k + 1]] | 0;
      if (a < PI0) { const e = TAI[s[k + 2]] | 0; k++; if (a < WP.length) p.W.push({ i: a, l: clamp(b, 1, WLV), e: e > 0 && e <= EVO.length ? e : 0, cd: 0, t: 0 }); }
      else if (a < TR0) { if (a - PI0 < PS.length) p.P.push({ i: a - PI0, l: b }); }
      else if (a < EV0 && a - TR0 < TR.length) p.T.push({ i: a - TR0, l: b });
    }
  }
  // remote players' positions (only stream what they can see)
  function nearAny(xs, ys, x, y) { for (let k = 0; k < xs.length; k++) { const dx = xs[k] - x, dy = ys[k] - y; if (dx * dx + dy * dy < VIEW_R * VIEW_R) return true; } return false; }
  const b36 = (v) => (v | 0).toString(36);
  function encFx(list) { return list.length ? [list[0][0], list.map((e) => b36(e[1]) + '.' + b36(e[2]) + '.' + b36(e[3]) + '.' + b36(e[4]) + '.' + b36(e[5])).join('|')] : null; }
  function decFx(F) {
    if (!Array.isArray(F) || F.length < 2 || typeof F[1] !== 'string') return [];
    const out = [], seq0 = F[0] | 0;
    F[1].split('|').forEach((t, k) => { const a = t.split('.').map((v) => parseInt(v, 36) || 0); if (a.length >= 5) out.push([seq0 + k, a[0], a[1], a[2], a[3], a[4]]); });
    return out;
  }
  function encodeWorld(W, key, q, viewers) {
    const xs = [], ys = [];
    for (const s of viewers) { const p = W.pl[s]; if (p) { xs.push(p.x); ys.push(p.y); } }
    const half = q & 1;
    let E = '';
    let last = 0;
    for (let i = half; i < W.hiE; i += 2) {
      if (W.eal[i] && nearAny(xs, ys, W.ex[i], W.ey[i])) {
        E += (W.eel[i] ? '!' : '') + TA[W.et[i]] + q2(W.ex[i]) + q2(W.ey[i]); last = E.length;
      } else E += ' ';
    }
    E = E.slice(0, last);
    let B = '', nb = 0;
    for (let i = 0; i < W.hiP && nb < 64; i++) {
      if (!W.pal[i]) continue;
      const k = W.pk[i], x = W.px[i], y = W.py[i];
      if (!nearAny(xs, ys, x, y)) continue;
      const moving = MOVING[k] && !isTorn(k), a = k === K.BEAM || k === K.BEAME ? W.pa[i] : k === K.TUR || k === K.TURE ? W.ptg[i] / 100 : moving ? Math.atan2(W.pvy[i], W.pvx[i]) : 0;
      const rad = k === K.BEAM || k === K.BEAME ? W.pr[i] / 8 : k === K.WAVE || k === K.WAVEE ? W.pa[i] / 4 : W.pr[i] / 2;
      B += TA[k] + q2(x) + q2(y) + qa(a) + qc(k === K.BOMB ? hyp(W.pa[i] - x, W.pb[i] - y) / 8 : rad);
      nb++;
    }
    let G = '', ng = 0;
    for (let j = 0; j < MAXG && ng < 60; j++) {
      if (!W.gal[j] || !nearAny(xs, ys, W.gx[j], W.gy[j])) continue;
      G += TA[W.gk[j]] + q2(W.gx[j]) + q2(W.gy[j]); ng++;
    }
    const P = W.pl.map((p) => [Math.round(p.x * 2), Math.round(p.y * 2), Math.ceil(p.hp), p.mhp, (p.dn ? 1 : 0) | (p.iv > 0 ? 2 : 0) | (p.rt > 0 ? 4 : 0) | ((p.off || p.ro) && !W.solo ? 8 : 0) | (p.dt > 0 ? 16 : 0) | (p.hurtF > 0 ? 32 : 0),
      Math.round(p.rv * 100), qa(Math.atan2(p.fy, p.fx)), invStr(p), p.kills, Math.round(p.dc * 10), relStr(p), p.rq.length + p.pq.length]);
    const O = {}, RO = {};
    for (const s of viewers) {
      const p = W.pl[s]; if (!p) continue;
      if (p.off) O[s] = [p.off.q, Math.round(refundOf(W, p.off.n) * 10)].concat(p.off.c);
      if (p.ro) RO[s] = [p.ro.q, p.ro.b].concat(p.ro.c);
    }
    const Z = W.Z.map((z) => [z.id, ZK.indexOf(z.k), Math.round(z.x), Math.round(z.y), z.r, z.ph, Math.round(z.t * 10)]);
    const F = encFx(W.fx.slice(-14));
    const o = { k: key, q, h: half, n: (W.hiE + 1 - half) >> 1, T: Math.round(W.T * 10), L: W.lv, X: Math.round(W.xp / xpNeed(W) * 100), K: W.kills, P, E, B, G, Z, F, O, RO };
    if (W.slowT > 0) o.sl = 1;
    if (W.tide) o.td = [Math.round(W.tide.x), W.tide.side, W.tide.on ? 1 : 0, Math.round(W.tide.warn * 10)];
    if (W.frz > 0) o.fz = 1;
    if (W.wind) o.wd = [Math.round(W.wind.a * 100), W.wind.on ? 1 : 0];
    if (W.dark) o.dk = W.dark.on ? 1 : 0;
    if (W.bossI.length) { const i = W.bossI[0]; if (W.eal[i]) o.bh = [W.et[i], Math.round(W.ehp[i] / W.emh[i] * 100)]; }
    return o;
  }

  /* ======================= sizes / exports for tests ======================= */
  const T_ = { BPAT, WP, PS, TR, CH, RE, ET, STG, init, newWorld, stepWorld, aiThink, encodeWorld, finish, result, genMap, xpNeed, MAXE, recalc, recalcAll,
    makeOffer, pickCard, applyCard, cardPool, evoReady, bossTimes, H, invStr, parseInv, parseRel, relStr, TA, d2, da, B64I, TAI, K, MOVING, WS,
    makeRelicOffer, pickRelic, aiCard, aiRelic, refundOf, levelCheck, collect, addG, isExcl, PI0, TR0, EV0, FH, FM, EVO, evoHints, reqMet, wst };

  /* ======================= view ======================= */
  // (mount defined below)
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `
.sw-ui{position:absolute;inset:0;pointer-events:none;z-index:3;font-family:var(--f-body,system-ui)}
.sw-hint{position:absolute;left:50%;top:92px;transform:translateX(-50%);max-width:calc(100% - 24px);font:600 12.5px var(--f-body,system-ui);color:#f2e9d8;
  background:rgba(20,14,30,.78);border:1px solid rgba(242,233,216,.18);border-radius:999px;padding:5px 12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:opacity .3s}
.sw-hint.warn{border-color:#ee6a55;color:#ffd2c8}
.sw-hint.off{opacity:0}
.sw-dash{position:absolute;right:14px;bottom:18px;width:70px;height:70px;border-radius:50%;border:2px solid rgba(242,233,216,.35);pointer-events:auto;
  background:conic-gradient(rgba(227,174,69,.9) var(--p,100%),rgba(40,30,56,.92) 0);color:#1d1406;font:800 14px var(--f-body,system-ui);
  display:flex;align-items:center;justify-content:center;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;box-shadow:0 4px 14px rgba(0,0,0,.45);padding:0}
.sw-dash span{background:rgba(255,246,220,.92);border-radius:50%;width:52px;height:52px;display:flex;align-items:center;justify-content:center}
.sw-dash.cool span{background:rgba(60,48,80,.95);color:#bdb2c8}
.sw-dash[hidden]{display:none}
.sw-cards{position:absolute;left:8px;right:8px;top:70px;pointer-events:auto;background:rgba(24,17,36,.95);border:1.5px solid rgba(227,174,69,.6);
  border-radius:16px;padding:10px 10px 8px;box-shadow:0 10px 30px rgba(0,0,0,.55);max-width:460px;margin:0 auto;max-height:calc(100% - 82px);overflow-y:auto;overscroll-behavior:contain}
.sw-cards[hidden]{display:none}
.sw-cards.in{animation:swIn .22s ease-out}
@keyframes swIn{from{transform:translateY(-14px) scale(.96);opacity:0}to{transform:none;opacity:1}}
.sw-cards h3{margin:0 0 2px;font:400 19px var(--f-display,sans-serif);color:#e3ae45;text-align:center}
.sw-cards .sub{font-size:11.5px;color:#ab9fb8;text-align:center;margin-bottom:7px}
.sw-tbar{height:4px;border-radius:3px;background:rgba(255,255,255,.12);margin:0 4px 8px;overflow:hidden}
.sw-tbar i{display:block;height:100%;background:#e3ae45;width:100%}
.sw-card{position:relative;display:flex;align-items:center;gap:10px;width:100%;min-height:70px;margin:0 0 7px;padding:7px 10px;border-radius:12px;text-align:left;cursor:pointer;
  background:linear-gradient(180deg,#2e2640,#251e34);border:1.5px solid rgba(242,233,216,.2);color:#f2e9d8;-webkit-tap-highlight-color:transparent;font-family:inherit;overflow:hidden}
.sw-card:active{transform:scale(.98)}
.sw-card.ex{border-color:var(--c);box-shadow:inset 4px 0 0 var(--c)}
.sw-card.evo{border-color:#ffd36a;background:linear-gradient(180deg,#4a3818,#2e2412);box-shadow:0 0 0 2px rgba(255,211,106,.3)}
.sw-card.evo::after,.sw-rc.r2::after,.sw-rc.r3::after{content:'';position:absolute;top:0;bottom:0;width:40%;left:-50%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.16),transparent);animation:swShine 2.2s ease-in-out infinite}
@keyframes swShine{0%{left:-50%}60%,100%{left:120%}}
.sw-card canvas{flex:0 0 44px;width:44px;height:44px}
.sw-card .tx{flex:1 1 auto;min-width:0}
.sw-card b{display:block;font-size:15.5px;line-height:1.25}
.sw-card em{font-style:normal;font-size:11px;font-weight:700;color:#e3ae45;margin-left:5px}
.sw-card small{display:block;font-size:12.5px;line-height:1.3;color:#cfc3dc;margin-top:2px}
.sw-card kbd,.sw-skip kbd{flex:0 0 auto;font:600 11px var(--f-mono,monospace);color:#ab9fb8;border:1px solid rgba(242,233,216,.2);border-radius:5px;padding:1px 5px;margin-left:6px}
.sw-chip{display:inline-block;vertical-align:1px;margin-left:5px;font:700 10.5px var(--f-body,system-ui);line-height:1;padding:3px 6px;border-radius:999px;color:var(--c);border:1px solid var(--c);background:rgba(0,0,0,.25);white-space:nowrap}
.sw-skip{display:flex;align-items:center;justify-content:center;width:100%;min-height:46px;border-radius:12px;border:1.5px dashed rgba(242,233,216,.3);background:rgba(0,0,0,.2);
  color:#e6dcef;font:700 14px var(--f-body,system-ui);cursor:pointer;-webkit-tap-highlight-color:transparent;padding:4px 8px}
.sw-skip small{font-weight:600;font-size:12px;color:#8fd0ff}
.sw-skip:active{transform:scale(.98)}
.sw-rel{border-color:#c58aff;background:radial-gradient(ellipse at top,rgba(70,40,100,.97),rgba(24,17,36,.97) 70%)}
.sw-rel h3{color:#e6c8ff}
.sw-rc{border-color:var(--c);animation:swFlip .35s ease-out both}
.sw-rc.r1{background:linear-gradient(180deg,#22304a,#1e2236)}
.sw-rc.r2{background:linear-gradient(180deg,#3a2650,#261c38);box-shadow:0 0 12px rgba(197,138,255,.25)}
.sw-rc.r3{background:linear-gradient(180deg,#4a3410,#2e2210);box-shadow:0 0 16px rgba(255,176,48,.35)}
@keyframes swFlip{from{transform:rotateX(70deg) scale(.9);opacity:0}to{transform:none;opacity:1}}
.sw-got{position:absolute;left:50%;top:96px;transform:translateX(-50%);width:min(92%,420px);display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:14px;
  background:rgba(20,14,30,.94);border:1.5px solid var(--c,#ffd36a);box-shadow:0 0 18px rgba(0,0,0,.5),0 0 14px var(--c,#ffd36a);color:#f2e9d8;pointer-events:none}
.sw-got[hidden]{display:none}
.sw-got.in{animation:swGot 3.4s ease both}
@keyframes swGot{0%{opacity:0;transform:translateX(-50%) translateY(-10px) scale(.9)}8%{opacity:1;transform:translateX(-50%) scale(1.03)}14%{transform:translateX(-50%)}85%{opacity:1}100%{opacity:0;transform:translateX(-50%) translateY(-6px)}}
.sw-got canvas{flex:0 0 40px}
.sw-got .tx{min-width:0}
.sw-got em{display:block;font-style:normal;font-size:11px;font-weight:800;color:var(--c,#ffd36a)}
.sw-got b{display:block;font-size:15px;line-height:1.2}
.sw-got small{display:block;font-size:12.5px;line-height:1.3;color:#e6dcef}
.sw-bagb{position:absolute;left:14px;bottom:18px;width:56px;height:56px;border-radius:16px;border:2px solid rgba(242,233,216,.3);pointer-events:auto;background:rgba(40,30,56,.92);
  color:#f2e9d8;font:800 13px var(--f-body,system-ui);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(0,0,0,.45);padding:0;touch-action:none;-webkit-tap-highlight-color:transparent;cursor:pointer}
.sw-bagb[hidden]{display:none}
.sw-bagb i{position:absolute;right:-5px;top:-6px;min-width:20px;height:20px;border-radius:10px;background:#c58aff;color:#1a1024;font:800 11px/20px var(--f-mono,monospace);text-align:center;font-style:normal}
.sw-bagb i:empty{display:none}
.sw-sheet{position:absolute;inset:0;z-index:6;pointer-events:auto;background:rgba(14,10,22,.97);color:#f2e9d8;display:flex;flex-direction:column;font-family:var(--f-body,system-ui)}
.sw-sheet[hidden]{display:none}
.sw-codex{z-index:7}
.sw-sh-h{flex:0 0 auto;position:relative;padding:10px 60px 8px 14px;border-bottom:1px solid rgba(242,233,216,.12)}
.sw-sh-h b{display:block;font:400 20px var(--f-display,sans-serif);color:#e3ae45}
.sw-sh-h span{font-size:12px;color:#ab9fb8}
.sw-x{position:absolute;right:8px;top:8px;width:46px;height:46px;border-radius:12px;border:1.5px solid rgba(242,233,216,.25);background:rgba(255,255,255,.06);color:#f2e9d8;font:700 18px var(--f-body,system-ui);cursor:pointer}
.sw-tabs{flex:0 0 auto;display:flex;gap:4px;padding:8px 8px 0;overflow-x:auto}
.sw-tab{flex:1 0 auto;min-height:44px;padding:0 10px;border-radius:10px 10px 0 0;border:1.5px solid rgba(242,233,216,.15);border-bottom:none;background:rgba(255,255,255,.04);color:#cfc3dc;font:700 13.5px var(--f-body,system-ui);cursor:pointer}
.sw-tab.on{background:#2e2640;color:#ffd36a;border-color:rgba(227,174,69,.6)}
.sw-sh-b{flex:1 1 auto;overflow-y:auto;padding:6px 10px 20px;background:#1d1729;overscroll-behavior:contain}
.sw-sh-b h4{margin:12px 2px 6px;font:400 16px var(--f-display,sans-serif);color:#e3ae45}
.sw-sh-b h4 small{font:600 11.5px var(--f-body,system-ui);color:#ab9fb8}
.sw-row{display:flex;gap:10px;align-items:flex-start;padding:7px 6px;border-radius:10px;background:rgba(255,255,255,.035);margin-bottom:5px}
.sw-row>canvas{flex:0 0 auto;margin-top:2px}
.sw-row .tx{flex:1 1 auto;min-width:0}
.sw-row b{display:block;font-size:14.5px;line-height:1.3}
.sw-row small{display:block;font-size:12.5px;line-height:1.4;color:#d6cbe2}
.sw-evo,.sw-ex-l{display:flex;flex-wrap:wrap;align-items:center;gap:3px;margin-top:4px;font-size:12px;color:#cfc3dc}
.sw-evo canvas,.sw-ex-l canvas{flex:0 0 auto}
.sw-evo b{color:#ffd36a;font-size:12.5px}
.sw-evo i{font-style:normal;font-size:10.5px;color:#ab9fb8}
.sw-tree{margin-top:2px}
.sw-tree .sw-ed{display:block;font-size:11.5px;color:#ab9fb8;margin:0 0 3px 4px}
.sw-e2{margin:0 0 4px 14px;padding-left:6px;border-left:2px solid rgba(255,138,74,.5)}
.sw-e2 em{font-style:normal;font-size:11px;font-weight:800;color:#ff8a4a}
.sw-paths{margin-top:4px;display:flex;flex-direction:column;gap:3px}
.sw-path{display:flex;flex-wrap:wrap;align-items:center;gap:3px;font-size:12px;color:#cfc3dc;background:rgba(255,255,255,.04);border-radius:8px;padding:3px 6px}
.sw-path em{font-style:normal;font-weight:800;color:#e3ae45;min-width:118px;font-size:12px}
.sw-path small{flex-basis:100%;font-size:11.5px;color:#ab9fb8}
.sw-ex-l em{font-style:normal;font-weight:800;color:#e3ae45;min-width:52px;font-size:11.5px}
.sw-note{font-size:12px;line-height:1.5;color:#ab9fb8;margin:6px 4px}
.sw-wide{display:block;width:100%;min-height:46px;margin-top:12px}
.sw-pick{position:absolute;inset:0;pointer-events:auto;overflow-y:auto;background:radial-gradient(ellipse at top,#33244a,#17131f 70%);padding:10px 10px 84px;color:#f2e9d8}
.sw-pick[hidden]{display:none}
.sw-pk-h{position:relative;text-align:center;margin:2px 0 8px;padding:0 64px}
.sw-pk-h b{display:block;font:400 21px var(--f-display,sans-serif);color:#e3ae45}
.sw-pk-h span{font-size:12.5px;color:#cfc3dc}
.sw-pk-s{font-size:11.5px;color:#ab9fb8;margin-top:2px}
.sw-cxb{position:absolute;right:0;top:0;min-width:60px;min-height:44px;padding:0 8px;border-radius:12px;border:1.5px solid rgba(227,174,69,.55);background:rgba(40,30,56,.9);color:#ffd36a;font:800 13px var(--f-body,system-ui);cursor:pointer}
.sw-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:5px;max-width:460px;margin:0 auto}
.sw-cc{position:relative;min-height:80px;border-radius:12px;border:1.5px solid rgba(242,233,216,.18);background:#251e34;color:#f2e9d8;padding:4px 1px 5px;
  display:flex;flex-direction:column;align-items:center;gap:1px;cursor:pointer;font-family:inherit;-webkit-tap-highlight-color:transparent;box-shadow:inset 0 -3px 0 var(--c)}
.sw-cc canvas{width:36px;height:36px}
.sw-cc b{font-size:11.5px;line-height:1.15;text-align:center;word-break:keep-all}
.sw-cc small{font-size:10px;line-height:1.15;color:#ab9fb8;text-align:center;padding:0 2px}
.sw-cc.sel{border-color:#e3ae45;background:#3a2c18;box-shadow:0 0 0 2px rgba(227,174,69,.35),inset 0 -3px 0 var(--c)}
.sw-info{max-width:460px;margin:8px auto 0;background:rgba(0,0,0,.28);border-radius:12px;padding:8px 10px;font-size:12.5px;line-height:1.45;color:#e6dcef}
.sw-info-h b{font-size:15px;color:#ffd36a}
.sw-info-h span:last-child{display:block;font-size:12px;color:#cfc3dc}
.sw-info-d{margin-top:3px}
.sw-info-d em{font-style:normal;font-weight:800;color:#e3ae45}
.sw-info-n{margin-top:5px;font-size:11.5px;color:#ab9fb8}
.sw-tips{max-width:460px;margin:8px auto 0;border:1px dashed rgba(227,174,69,.5);border-radius:12px;padding:7px 10px;font-size:12px;line-height:1.5;color:#e6dcef}
.sw-tips b{color:#e3ae45}
.sw-go{position:absolute;left:50%;bottom:14px;transform:translateX(-50%);min-width:180px;height:52px;font-size:17px!important;pointer-events:auto}
.sw-go[hidden]{display:none}
.sw-wait{position:absolute;left:0;right:0;bottom:70px;text-align:center;font-size:13px;color:#ab9fb8;pointer-events:none}
`;
  const PSPD = [330, 400, 320, 380, 280, 260, 0, 190, 190, 360, 360, 360, 95, 0, 0, 0, 75, 0, 0, 0, 0, 0, 95, 0, 430, 430, 240, 210, 0, 260];
  const GEMC = ['#5ab0ff', '#5fe08a', '#ff5a7a', '#c58aff'];

  /* ---------- small drawing helpers ---------- */
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(255,255,255,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, f) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return hex;
    const n = parseInt(m[1], 16), c = (v) => clamp(Math.round(f < 0 ? v * (1 + f) : v + (255 - v) * f), 0, 255);
    return 'rgb(' + c(n >> 16) + ',' + c((n >> 8) & 255) + ',' + c(n & 255) + ')';
  }
  function circ(c, x, y, r, fill) { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fillStyle = fill; c.fill(); }
  function eyes(c, r, y, col, gap) { const g = gap || 0.36; circ(c, -r * g, y, r * 0.16, col || '#1a1020'); circ(c, r * g, y, r * 0.16, col || '#1a1020'); }
  function drawEnemyShape(c, sh, r, col) {
    const dk = shade(col, -0.45), lt = shade(col, 0.35);
    c.lineWidth = Math.max(1, r * 0.12); c.strokeStyle = dk;
    switch (sh) {
      case 'skull': circ(c, 0, -r * 0.1, r * 0.9, col); c.stroke(); c.fillStyle = col; c.fillRect(-r * 0.45, r * 0.45, r * 0.9, r * 0.4); circ(c, -r * 0.35, -r * 0.1, r * 0.24, '#2a1a20'); circ(c, r * 0.35, -r * 0.1, r * 0.24, '#2a1a20'); c.fillStyle = '#2a1a20'; c.fillRect(-r * 0.3, r * 0.55, r * 0.12, r * 0.25); c.fillRect(r * 0.18, r * 0.55, r * 0.12, r * 0.25); break;
      case 'bat': c.fillStyle = dk; c.beginPath(); c.moveTo(0, 0); c.lineTo(-r * 1.15, -r * 0.5); c.lineTo(-r * 0.8, r * 0.3); c.lineTo(-r * 0.4, 0); c.closePath(); c.fill(); c.beginPath(); c.moveTo(0, 0); c.lineTo(r * 1.15, -r * 0.5); c.lineTo(r * 0.8, r * 0.3); c.lineTo(r * 0.4, 0); c.closePath(); c.fill(); circ(c, 0, 0, r * 0.55, col); eyes(c, r, -r * 0.1, '#ff6a6a', 0.22); break;
      case 'ghost': case 'jelly': {
        c.fillStyle = hexA(col, sh === 'jelly' ? 0.75 : 0.85); c.beginPath(); c.arc(0, -r * 0.1, r * 0.85, Math.PI, 0); c.lineTo(r * 0.85, r * 0.75);
        for (let k = 0; k < 4; k++) c.quadraticCurveTo(r * (0.64 - k * 0.42), r * (k % 2 ? 0.95 : 0.45), r * (0.42 - k * 0.42), r * 0.75);
        c.closePath(); c.fill(); eyes(c, r, -r * 0.1, sh === 'jelly' ? '#6a2a5a' : '#2a3a5a'); break;
      }
      case 'archer': circ(c, 0, 0, r * 0.85, col); c.stroke(); eyes(c, r, -r * 0.1, '#2a1a20'); c.strokeStyle = '#8a5a2a'; c.lineWidth = r * 0.15; c.beginPath(); c.arc(r * 0.6, 0, r * 0.75, -1.2, 1.2); c.stroke(); break;
      case 'golem': case 'knight': case 'turret': {
        c.fillStyle = col; c.beginPath(); if (c.roundRect) c.roundRect(-r * 0.85, -r * 0.85, r * 1.7, r * 1.7, r * 0.35); else c.rect(-r * 0.85, -r * 0.85, r * 1.7, r * 1.7); c.fill(); c.stroke();
        if (sh === 'knight') { c.fillStyle = '#1a1a24'; c.fillRect(-r * 0.6, -r * 0.2, r * 1.2, r * 0.22); circ(c, 0, -r * 0.95, r * 0.18, '#d04a4a'); }
        else if (sh === 'turret') { c.fillStyle = dk; c.fillRect(-r * 0.15, -r * 1.25, r * 0.3, r * 0.6); eyes(c, r, r * 0.1, '#ffd36a'); }
        else { eyes(c, r, -r * 0.1, '#ffb84a'); c.beginPath(); c.moveTo(-r * 0.5, r * 0.4); c.lineTo(-r * 0.1, r * 0.2); c.lineTo(r * 0.3, r * 0.5); c.stroke(); }
        break;
      }
      case 'shroom': c.fillStyle = '#f2e6cc'; c.fillRect(-r * 0.35, -r * 0.1, r * 0.7, r * 0.9); c.fillStyle = col; c.beginPath(); c.arc(0, -r * 0.05, r * 0.95, Math.PI, 0); c.closePath(); c.fill(); circ(c, -r * 0.4, -r * 0.45, r * 0.16, '#fff'); circ(c, r * 0.3, -r * 0.6, r * 0.13, '#fff'); eyes(c, r, r * 0.35, '#2a1a20', 0.18); break;
      case 'bee': c.fillStyle = 'rgba(255,255,255,.6)'; c.beginPath(); c.ellipse(-r * 0.35, -r * 0.7, r * 0.4, r * 0.25, -0.5, 0, TAU); c.ellipse(r * 0.35, -r * 0.7, r * 0.4, r * 0.25, 0.5, 0, TAU); c.fill(); c.fillStyle = col; c.beginPath(); c.ellipse(0, 0, r, r * 0.75, 0, 0, TAU); c.fill(); c.fillStyle = '#2a2018'; c.fillRect(-r * 0.25, -r * 0.7, r * 0.2, r * 1.4); c.fillRect(r * 0.25, -r * 0.65, r * 0.2, r * 1.3); break;
      case 'blob': c.fillStyle = col; c.beginPath(); c.ellipse(0, r * 0.1, r, r * 0.85, 0, 0, TAU); c.fill(); c.stroke(); circ(c, -r * 0.35, -r * 0.35, r * 0.2, hexA('#ffffff', 0.5)); eyes(c, r, 0, '#1a1020', 0.3); break;
      case 'flower': for (let k = 0; k < 6; k++) { const a = k * TAU / 6; circ(c, Math.cos(a) * r * 0.6, Math.sin(a) * r * 0.6, r * 0.42, col); } circ(c, 0, 0, r * 0.45, '#ffe07a'); eyes(c, r, 0, '#3a2010', 0.18); break;
      case 'treant': c.fillStyle = col; c.beginPath(); c.ellipse(0, r * 0.1, r * 0.8, r * 0.95, 0, 0, TAU); c.fill(); c.stroke(); circ(c, -r * 0.6, -r * 0.8, r * 0.4, '#4f8a3a'); circ(c, r * 0.5, -r * 0.9, r * 0.45, '#4f8a3a'); circ(c, 0, -r * 1.05, r * 0.4, '#5a9a42'); eyes(c, r, 0, '#ffd36a'); break;
      case 'snow': circ(c, 0, 0, r * 0.9, col); c.strokeStyle = '#a8c0d8'; c.stroke(); eyes(c, r, -r * 0.15, '#2a2a3a'); c.fillStyle = '#ff8a3a'; c.beginPath(); c.moveTo(0, 0); c.lineTo(r * 0.5, r * 0.1); c.lineTo(0, r * 0.2); c.fill(); break;
      case 'wolf': c.fillStyle = col; c.beginPath(); c.moveTo(-r * 0.7, -r * 0.4); c.lineTo(-r * 0.5, -r * 1.05); c.lineTo(-r * 0.15, -r * 0.6); c.moveTo(r * 0.7, -r * 0.4); c.lineTo(r * 0.5, -r * 1.05); c.lineTo(r * 0.15, -r * 0.6); c.fill(); circ(c, 0, 0, r * 0.85, col); c.stroke(); circ(c, 0, r * 0.35, r * 0.3, lt); eyes(c, r, -r * 0.15, '#5ab0ff', 0.32); break;
      case 'fairy': c.fillStyle = 'rgba(200,250,255,.55)'; c.beginPath(); c.ellipse(-r * 0.6, -r * 0.3, r * 0.6, r * 0.3, -0.6, 0, TAU); c.ellipse(r * 0.6, -r * 0.3, r * 0.6, r * 0.3, 0.6, 0, TAU); c.fill(); circ(c, 0, 0, r * 0.6, col); eyes(c, r, -r * 0.05, '#2a4a6a', 0.22); break;
      case 'yeti': for (let k = 0; k < 8; k++) { const a = k * TAU / 8; circ(c, Math.cos(a) * r * 0.55, Math.sin(a) * r * 0.55, r * 0.5, col); } circ(c, 0, r * 0.05, r * 0.45, '#8a9aaa'); eyes(c, r, 0, '#1a2030', 0.2); break;
      case 'lizard': c.strokeStyle = col; c.lineWidth = r * 0.3; c.beginPath(); c.moveTo(0, r * 0.4); c.quadraticCurveTo(-r * 0.6, r * 1.1, -r * 1.1, r * 0.8); c.stroke(); c.fillStyle = col; c.beginPath(); c.ellipse(0, 0, r * 0.7, r * 0.9, 0, 0, TAU); c.fill(); eyes(c, r, -r * 0.35, '#fff27a', 0.3); break;
      case 'flame': c.fillStyle = col; c.beginPath(); c.moveTo(0, -r * 1.15); c.quadraticCurveTo(r * 0.95, -r * 0.1, r * 0.6, r * 0.6); c.quadraticCurveTo(0, r * 1.05, -r * 0.6, r * 0.6); c.quadraticCurveTo(-r * 0.95, -r * 0.1, 0, -r * 1.15); c.fill(); circ(c, 0, r * 0.3, r * 0.4, '#fff0a0'); eyes(c, r, r * 0.15, '#5a1a0a', 0.22); break;
      case 'mage': c.fillStyle = col; c.beginPath(); c.moveTo(0, -r * 1.1); c.lineTo(r * 0.9, r * 0.85); c.lineTo(-r * 0.9, r * 0.85); c.closePath(); c.fill(); circ(c, 0, r * 0.15, r * 0.4, '#1a1018'); eyes(c, r, r * 0.12, '#ff9a3a', 0.18); break;
      case 'mouse': circ(c, -r * 0.55, -r * 0.6, r * 0.35, lt); circ(c, r * 0.55, -r * 0.6, r * 0.35, lt); circ(c, 0, 0, r * 0.8, col); c.stroke(); eyes(c, r, -r * 0.1, '#1a1020', 0.28); c.fillStyle = '#d0a040'; c.fillRect(-r * 0.12, r * 0.6, r * 0.24, r * 0.5); break;
      case 'gear': c.fillStyle = col; c.beginPath(); for (let k = 0; k < 16; k++) { const a = k * TAU / 16, rr = k % 2 ? r * 0.75 : r; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); c.fill(); circ(c, 0, 0, r * 0.4, dk); circ(c, 0, 0, r * 0.18, '#ff5a3a'); break;
      case 'crab': c.fillStyle = col; circ(c, -r * 0.9, -r * 0.35, r * 0.35, col); circ(c, r * 0.9, -r * 0.35, r * 0.35, col); c.beginPath(); c.ellipse(0, 0, r * 0.85, r * 0.6, 0, 0, TAU); c.fill(); c.stroke(); eyes(c, r, -r * 0.25, '#1a1020', 0.25); break;
      case 'bird': c.fillStyle = '#c8ccd4'; c.beginPath(); c.ellipse(-r * 0.6, 0, r * 0.7, r * 0.25, 0.3, 0, TAU); c.ellipse(r * 0.6, 0, r * 0.7, r * 0.25, -0.3, 0, TAU); c.fill(); circ(c, 0, 0, r * 0.55, col); c.fillStyle = '#ffb04a'; c.beginPath(); c.moveTo(-r * 0.15, r * 0.2); c.lineTo(r * 0.15, r * 0.2); c.lineTo(0, r * 0.6); c.fill(); eyes(c, r, -r * 0.1, '#1a1020', 0.2); break;
      case 'shell': c.fillStyle = col; c.beginPath(); c.moveTo(0, -r); c.lineTo(r * 0.85, r * 0.7); c.lineTo(-r * 0.85, r * 0.7); c.closePath(); c.fill(); c.stroke(); c.beginPath(); c.moveTo(-r * 0.4, 0); c.lineTo(r * 0.4, 0); c.moveTo(-r * 0.6, r * 0.4); c.lineTo(r * 0.6, r * 0.4); c.stroke(); eyes(c, r, r * 0.2, '#1a1020', 0.2); break;
      case 'turtle': circ(c, 0, -r * 0.85, r * 0.35, '#9aba7a'); c.fillStyle = col; c.beginPath(); for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + Math.PI / 6; c.lineTo(Math.cos(a) * r * 0.9, Math.sin(a) * r * 0.9); } c.closePath(); c.fill(); c.stroke(); c.strokeStyle = lt; c.beginPath(); c.arc(0, 0, r * 0.45, 0, TAU); c.stroke(); break;
      case 'scorp': { c.strokeStyle = col; c.lineWidth = r * 0.22; c.beginPath(); c.moveTo(0, r * 0.5); c.quadraticCurveTo(r * 1.1, r * 0.9, r * 0.6, -r * 0.6); c.stroke(); circ(c, r * 0.6, -r * 0.7, r * 0.2, dk);
        circ(c, -r * 0.85, -r * 0.55, r * 0.3, col); circ(c, r * 0.05, -r * 0.75, r * 0.3, col); c.fillStyle = col; c.beginPath(); c.ellipse(0, 0, r * 0.75, r * 0.55, 0, 0, TAU); c.fill(); c.strokeStyle = dk; c.lineWidth = r * 0.1; c.stroke(); eyes(c, r, -r * 0.1, '#1a1020', 0.22); break; }
      case 'worm': for (let k = 3; k >= 0; k--) circ(c, -r * 0.45 * k + r * 0.3, r * 0.25 * Math.sin(k), r * (0.55 - k * 0.06), k % 2 ? dk : col); circ(c, r * 0.3, 0, r * 0.6, col); circ(c, r * 0.55, 0, r * 0.25, '#3a1a10'); break;
      case 'mummy': circ(c, 0, 0, r * 0.85, col); c.strokeStyle = shade(col, -0.25); c.lineWidth = r * 0.12; for (let k = -2; k <= 2; k++) { c.beginPath(); c.moveTo(-r * 0.8, k * r * 0.3); c.lineTo(r * 0.8, k * r * 0.3 + r * 0.15); c.stroke(); } circ(c, -r * 0.3, -r * 0.15, r * 0.14, '#7aff9a'); circ(c, r * 0.3, -r * 0.15, r * 0.14, '#7aff9a'); break;
      case 'candle': c.fillStyle = col; c.fillRect(-r * 0.45, -r * 0.3, r * 0.9, r * 1.1); c.fillStyle = '#ffb04a'; c.beginPath(); c.moveTo(0, -r * 1.15); c.quadraticCurveTo(r * 0.35, -r * 0.6, 0, -r * 0.35); c.quadraticCurveTo(-r * 0.35, -r * 0.6, 0, -r * 1.15); c.fill(); eyes(c, r, r * 0.2, '#5a3a1a', 0.2); break;
      case 'teacup': c.fillStyle = 'rgba(255,255,255,.55)'; c.beginPath(); c.ellipse(-r * 0.75, -r * 0.4, r * 0.45, r * 0.22, -0.5, 0, TAU); c.ellipse(r * 0.75, -r * 0.4, r * 0.45, r * 0.22, 0.5, 0, TAU); c.fill();
        c.fillStyle = col; c.beginPath(); c.moveTo(-r * 0.75, -r * 0.3); c.lineTo(r * 0.75, -r * 0.3); c.quadraticCurveTo(r * 0.7, r * 0.75, 0, r * 0.75); c.quadraticCurveTo(-r * 0.7, r * 0.75, -r * 0.75, -r * 0.3); c.fill(); c.strokeStyle = '#7a8aaa'; c.lineWidth = r * 0.1; c.stroke(); c.beginPath(); c.arc(r * 0.85, r * 0.15, r * 0.25, -1.2, 1.2); c.stroke(); eyes(c, r, r * 0.15, '#2a2a4a', 0.25); break;
      case 'spider': c.strokeStyle = dk; c.lineWidth = r * 0.12; for (let k = 0; k < 4; k++) { const yy = -r * 0.45 + k * r * 0.3; c.beginPath(); c.moveTo(-r * 0.3, yy); c.lineTo(-r * 1.1, yy - r * 0.25); c.lineTo(-r * 1.25, yy + r * 0.3); c.moveTo(r * 0.3, yy); c.lineTo(r * 1.1, yy - r * 0.25); c.lineTo(r * 1.25, yy + r * 0.3); c.stroke(); }
        circ(c, 0, r * 0.2, r * 0.6, col); circ(c, 0, -r * 0.45, r * 0.4, col); circ(c, -r * 0.14, -r * 0.5, r * 0.09, '#ff4a4a'); circ(c, r * 0.14, -r * 0.5, r * 0.09, '#ff4a4a'); break;
      case 'sheep': for (let k = 0; k < 7; k++) { const a = k * TAU / 7; circ(c, Math.cos(a) * r * 0.5, Math.sin(a) * r * 0.45, r * 0.42, col); } circ(c, r * 0.55, -r * 0.1, r * 0.35, '#3a3a4a'); circ(c, r * 0.65, -r * 0.15, r * 0.08, '#fff'); break;
      case 'cloud': circ(c, -r * 0.4, r * 0.1, r * 0.5, col); circ(c, r * 0.4, r * 0.1, r * 0.5, col); circ(c, 0, -r * 0.25, r * 0.6, col); c.fillStyle = '#5a6a8a'; c.fillRect(-r * 0.15, r * 0.4, r * 0.3, r * 0.55); eyes(c, r, -r * 0.1, '#2a3a5a', 0.25); break;
      case 'dragon': c.fillStyle = shade(col, -0.2); c.beginPath(); c.moveTo(-r * 0.3, 0); c.lineTo(-r * 1.25, -r * 0.8); c.lineTo(-r * 0.9, r * 0.1); c.closePath(); c.moveTo(r * 0.3, 0); c.lineTo(r * 1.25, -r * 0.8); c.lineTo(r * 0.9, r * 0.1); c.closePath(); c.fill();
        c.fillStyle = col; c.beginPath(); c.ellipse(0, r * 0.1, r * 0.6, r * 0.8, 0, 0, TAU); c.fill(); circ(c, 0, -r * 0.7, r * 0.42, col); c.fillStyle = '#ffe07a'; c.beginPath(); c.moveTo(-r * 0.25, -r * 1); c.lineTo(-r * 0.35, -r * 1.35); c.lineTo(-r * 0.1, -r * 1.05); c.moveTo(r * 0.25, -r * 1); c.lineTo(r * 0.35, -r * 1.35); c.lineTo(r * 0.1, -r * 1.05); c.fill(); eyes(c, r * 0.6, -r * 0.75, '#ffe07a', 0.4); break;
      case 'octo': for (let k = 0; k < 6; k++) { const a = Math.PI * 0.15 + k * Math.PI * 0.14; c.strokeStyle = col; c.lineWidth = r * 0.18; c.beginPath(); c.moveTo(Math.cos(a) * r * 0.4, Math.sin(a) * r * 0.4); c.quadraticCurveTo(Math.cos(a) * r * 1.0, Math.sin(a) * r * 0.7, Math.cos(a) * r * 1.1, Math.sin(a) * r * 1.1); c.stroke(); }
        c.fillStyle = col; c.beginPath(); c.ellipse(0, -r * 0.15, r * 0.8, r * 0.75, 0, 0, TAU); c.fill(); eyes(c, r, -r * 0.15, '#ffe07a', 0.3); break;
      default: circ(c, 0, 0, r, col); eyes(c, r, 0);
    }
  }
  function drawHero(c, chi, r) {
    const ch = CH[chi] || CH[0], col = ch.col, dk = shade(col, -0.45);
    c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(0, r * 0.95, r * 0.8, r * 0.3, 0, 0, TAU); c.fill();
    // body (cloak) + head
    c.fillStyle = col; c.beginPath(); c.moveTo(-r * 0.85, r * 0.9); c.quadraticCurveTo(-r * 0.9, -r * 0.1, 0, -r * 0.2); c.quadraticCurveTo(r * 0.9, -r * 0.1, r * 0.85, r * 0.9); c.closePath(); c.fill();
    c.strokeStyle = dk; c.lineWidth = r * 0.12; c.stroke();
    circ(c, 0, -r * 0.45, r * 0.55, '#f3d6b4'); c.stroke();
    circ(c, -r * 0.2, -r * 0.42, r * 0.09, '#2a1a20'); circ(c, r * 0.2, -r * 0.42, r * 0.09, '#2a1a20');
    c.fillStyle = dk; c.strokeStyle = dk;
    const hy = -r * 0.85;
    switch (ch.hat) {
      case 0: c.beginPath(); c.moveTo(-r * 0.55, hy + r * 0.2); c.lineTo(0, hy - r * 0.45); c.lineTo(r * 0.55, hy + r * 0.2); c.fill(); c.strokeStyle = '#ffe08a'; c.lineWidth = r * 0.1; c.beginPath(); c.moveTo(r * 0.2, hy - r * 0.1); c.lineTo(r * 0.7, hy - r * 0.55); c.stroke(); break;
      case 1: c.fillRect(-r * 0.6, hy - r * 0.05, r * 1.2, r * 0.3); c.fillRect(-r * 0.4, hy - r * 0.35, r * 0.8, r * 0.35); break;
      case 2: c.fillStyle = '#e8f4ff'; c.fillRect(-r * 0.55, hy + r * 0.05, r * 1.1, r * 0.18); c.beginPath(); c.moveTo(r * 0.5, hy + r * 0.1); c.lineTo(r * 0.9, hy + r * 0.3); c.lineTo(r * 0.55, hy + r * 0.25); c.fill(); break;
      case 3: c.fillStyle = '#c8d0dc'; c.beginPath(); c.arc(0, -r * 0.5, r * 0.62, Math.PI, 0); c.fill(); c.fillStyle = '#e05a5a'; c.fillRect(-r * 0.08, hy - r * 0.45, r * 0.16, r * 0.4); break;
      case 4: c.beginPath(); c.moveTo(-r * 0.7, hy + r * 0.25); c.lineTo(r * 0.15, hy - r * 0.7); c.lineTo(r * 0.7, hy + r * 0.25); c.fill(); circ(c, r * 0.12, hy - r * 0.62, r * 0.13, '#ffe07a'); break;
      case 5: for (let k = -1; k <= 1; k++) { c.fillStyle = '#5fbf4a'; c.beginPath(); c.ellipse(k * r * 0.35, hy + r * 0.05, r * 0.15, r * 0.3, k * 0.6, 0, TAU); c.fill(); } break;
      case 6: c.fillStyle = '#3a2a20'; c.fillRect(-r * 0.6, -r * 0.6, r * 1.2, r * 0.16); circ(c, -r * 0.22, -r * 0.55, r * 0.17, '#9fd8f5'); circ(c, r * 0.22, -r * 0.55, r * 0.17, '#9fd8f5'); break;
      case 7: c.fillStyle = '#e05a5a'; c.fillRect(-r * 0.58, hy + r * 0.12, r * 1.16, r * 0.14); c.beginPath(); c.moveTo(-r * 0.5, hy + r * 0.2); c.lineTo(-r * 1.05, hy + r * 0.5); c.lineTo(-r * 0.95, hy + r * 0.25); c.fill(); break;
      case 8: c.lineWidth = r * 0.08; c.beginPath(); c.moveTo(0, hy); c.lineTo(0, hy - r * 0.5); c.stroke(); circ(c, 0, hy - r * 0.55, r * 0.17, '#ffe07a'); break;
      case 9: c.beginPath(); c.arc(0, -r * 0.55, r * 0.6, Math.PI, 0); c.fill(); circ(c, 0, hy - r * 0.05, r * 0.16, '#d0a040'); break;
      case 10: c.fillStyle = '#e8f6ff'; c.beginPath(); c.arc(0, -r * 0.55, r * 0.6, Math.PI, 0); c.fill(); circ(c, 0, hy - r * 0.3, r * 0.17, '#fff'); break;
      case 11: circ(c, r * 0.4, hy + r * 0.1, r * 0.2, '#ffb0c8'); circ(c, r * 0.4, hy + r * 0.1, r * 0.08, '#ffe07a'); break;
      case 12: c.beginPath(); c.moveTo(-r * 0.8, hy + r * 0.3); c.lineTo(0, hy - r * 0.3); c.lineTo(r * 0.8, hy + r * 0.3); c.closePath(); c.fill(); break;
      case 13: c.fillStyle = '#2a2034'; c.beginPath(); c.arc(0, -r * 0.5, r * 0.62, Math.PI * 0.9, Math.PI * 2.1); c.fill(); c.fillRect(-r * 0.6, -r * 0.42, r * 1.2, r * 0.14); circ(c, -r * 0.2, -r * 0.42, r * 0.08, '#c8a0ff'); circ(c, r * 0.2, -r * 0.42, r * 0.08, '#c8a0ff'); break;
      case 14: for (let k = 0; k < 5; k++) circ(c, Math.cos(k * 1.26) * r * 0.16 - r * 0.35, hy + Math.sin(k * 1.26) * r * 0.16 + r * 0.1, r * 0.14, '#ff6a8a'); circ(c, -r * 0.35, hy + r * 0.1, r * 0.08, '#ffe07a'); c.fillStyle = '#4fa04a'; c.fillRect(-r * 0.6, hy + r * 0.2, r * 1.2, r * 0.1); break;
      case 15: c.fillStyle = '#ff8a3a'; c.beginPath(); c.moveTo(-r * 0.5, hy + r * 0.2); c.quadraticCurveTo(-r * 0.3, hy - r * 0.6, 0, hy - r * 0.2); c.quadraticCurveTo(r * 0.2, hy - r * 0.8, r * 0.5, hy + r * 0.2); c.fill(); circ(c, 0, hy + r * 0.05, r * 0.2, '#ffe07a'); break;
      case 16: c.fillStyle = '#8a8a90'; c.beginPath(); c.arc(0, -r * 0.5, r * 0.6, Math.PI, 0); c.fill(); c.fillStyle = '#e8e2cf'; c.beginPath(); c.moveTo(-r * 0.55, hy + r * 0.1); c.lineTo(-r * 0.95, hy - r * 0.35); c.lineTo(-r * 0.4, hy - r * 0.05); c.moveTo(r * 0.55, hy + r * 0.1); c.lineTo(r * 0.95, hy - r * 0.35); c.lineTo(r * 0.4, hy - r * 0.05); c.fill(); break;
      case 17: c.strokeStyle = '#c8d0dc'; c.lineWidth = r * 0.14; c.beginPath(); c.arc(0, -r * 0.5, r * 0.62, Math.PI, 0); c.stroke(); for (let k = -1; k <= 1; k++) circ(c, k * r * 0.4, hy + r * 0.05 - Math.abs(k) * r * -0.1, r * 0.1, '#c8d0dc'); break;
      case 18: c.fillStyle = '#5ab8c8'; c.beginPath(); c.moveTo(0, hy - r * 0.6); c.lineTo(r * 0.3, hy + r * 0.1); c.lineTo(-r * 0.3, hy + r * 0.1); c.closePath(); c.fill(); c.fillStyle = 'rgba(255,255,255,.6)'; c.beginPath(); c.moveTo(0, hy - r * 0.6); c.lineTo(r * 0.08, hy); c.lineTo(-r * 0.12, hy); c.fill(); break;
    }
  }
  // tiny item glyphs (weapons 0-16, passives 20-33, 60 heal, 61 might)
  function glyph(c, id, s, col) {
    c.save(); c.scale(s / 24, s / 24);
    c.strokeStyle = col; c.fillStyle = col; c.lineWidth = 2.4; c.lineCap = 'round'; c.lineJoin = 'round';
    const P = (pts, fill) => { c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); if (fill) { c.closePath(); c.fill(); } else c.stroke(); };
    const C = (x, y, r, f) => { c.beginPath(); c.arc(x, y, r, 0, TAU); f ? c.fill() : c.stroke(); };
    switch (id) {
      case 0: P([[-8, 8], [8, -8]]); P([[8, -8], [1, -7], [7, -1]], 1); break;
      case 1: C(0, 0, 3, 1); C(0, -8, 3, 1); C(7, 5, 3, 1); C(-7, 5, 3, 1); break;
      case 2: c.lineWidth = 3.5; C(0, 0, 8); break;
      case 3: P([[2, -10], [-5, 1], [0, 1], [-2, 10], [6, -2], [1, -2]], 1); break;
      case 4: P([[-9, -2], [0, 7], [9, -2]]); break;
      case 5: for (let k = 0; k < 3; k++) { const a = k * Math.PI / 3; P([[Math.cos(a) * 9, Math.sin(a) * 9], [-Math.cos(a) * 9, -Math.sin(a) * 9]]); } break;
      case 6: C(-1, 2, 7, 1); P([[4, -4], [8, -9]]); break;
      case 7: c.beginPath(); c.arc(-4, 2, 11, -1.1, 0.9); c.stroke(); break;
      case 8: c.beginPath(); c.ellipse(0, 3, 10, 5, 0, 0, TAU); c.fill(); C(-3, -5, 2, 1); C(4, -7, 1.6, 1); break;
      case 9: C(-6, 4, 2.6, 1); C(5, -5, 2.6, 1); C(4, 6, 2, 1); C(-3, -6, 1.6, 1); break;
      case 10: c.beginPath(); c.arc(0, 6, 4, Math.PI, 0); c.stroke(); c.beginPath(); c.arc(0, 6, 9, Math.PI, 0); c.stroke(); break;
      case 11: c.lineWidth = 4; P([[-10, 6], [10, -6]]); break;
      case 12: for (let k = 0; k < 6; k++) { const a = k * TAU / 6; P([[0, 0], [Math.cos(a) * 9, Math.sin(a) * 9]]); } C(0, 0, 4, 1); break;
      case 13: C(5, -5, 4, 1); c.setLineDash([2, 3]); P([[-9, 8], [-4, -1], [1, 4]]); c.setLineDash([]); break;
      case 14: c.fillRect(-5, -3, 10, 6); P([[-9, -6], [-3, -6]]); P([[3, -6], [9, -6]]); break;
      case 15: for (let k = 0; k < 4; k++) { c.beginPath(); c.ellipse(k - 1.5, -7 + k * 5, 9 - k * 2, 2.2, 0, 0, TAU); c.stroke(); } break;
      case 16: C(4, 4, 5, 1); P([[1, 1], [-9, -9]]); P([[5, -1], [-3, -10]]); break;
      case 30: C(0, 2, 7); P([[-3, -6], [0, -10], [3, -6]], 1); break;
      case 31: C(-2, -2, 6); P([[3, 3], [9, 9]]); break;
      case 32: c.fillRect(-7, -2, 12, 10); for (let k = 0; k < 3; k++) c.fillRect(-7 + k * 4.4, -9, 3, 7); break;
      case 33: C(0, 0, 3, 1); C(0, 0, 7); C(0, 0, 10.5); break;
      case 34: P([[-7, -9], [7, -9], [-7, 9], [7, 9]], 0); P([[-7, -9], [7, -9], [0, 0]], 1); break;
      case 35: P([[-8, 6], [6, 6], [8, 2], [-2, 2]], 1); P([[-6, 0], [-9, -8], [0, -3]], 1); break;
      case 36: c.beginPath(); c.moveTo(0, 9); c.bezierCurveTo(-12, 0, -6, -10, 0, -4); c.bezierCurveTo(6, -10, 12, 0, 0, 9); c.fill(); break;
      case 37: P([[0, -10], [9, -6], [7, 5], [0, 10], [-7, 5], [-9, -6]], 1); break;
      case 38: c.lineWidth = 4; c.beginPath(); c.arc(0, 0, 7, Math.PI, 0, true); c.stroke(); P([[-7, 0], [-7, -8]]); P([[7, 0], [7, -8]]); break;
      case 39: C(-4, -4, 4.4, 1); C(4, -4, 4.4, 1); C(-4, 4, 4.4, 1); C(4, 4, 4.4, 1); break;
      case 17: P([[-9, 9], [5, -5]]); P([[5, -5], [9, -9], [2, -6]], 1); P([[-3, 9], [9, -3]]); break;
      case 18: for (let k = 0; k < 8; k++) { const a = k * TAU / 8; P([[Math.cos(a) * 4, Math.sin(a) * 4], [Math.cos(a) * 10, Math.sin(a) * 10]]); } C(0, 0, 3, 1); break;
      case 19: c.beginPath(); c.moveTo(-9, 0); c.lineTo(9, -8); c.quadraticCurveTo(4, 0, 9, 8); c.closePath(); c.fill(); break;
      case 20: P([[-6, 9], [4, -6]]); c.beginPath(); c.moveTo(1, -9); c.quadraticCurveTo(10, -8, 9, 2); c.lineTo(3, -3); c.closePath(); c.fill(); break;
      case 21: C(0, 0, 3, 1); c.setLineDash([2.5, 2.5]); P([[0, 0], [8, -6]]); c.setLineDash([]); P([[8, -6], [11, -9], [7, -10]], 1); P([[8, -6], [11, -2], [12, -6]], 1); break;
      case 22: c.lineWidth = 2; P([[-10, 10], [6, -6]]); P([[6, -6], [11, -11], [9, -3], [3, -9]], 1); break;
      case 23: c.beginPath(); c.moveTo(-7, 5); c.quadraticCurveTo(-7, -9, 0, -9); c.quadraticCurveTo(7, -9, 7, 5); c.closePath(); c.fill(); C(0, 7, 2.2, 1); c.beginPath(); c.arc(0, 0, 11, -0.6, 0.6); c.stroke(); break;
      case 24: c.beginPath(); c.moveTo(-10, -2); c.quadraticCurveTo(-3, -9, 0, -1); c.quadraticCurveTo(3, -9, 10, -2); c.quadraticCurveTo(3, 2, 0, 9); c.quadraticCurveTo(-3, 2, -10, -2); c.fill(); break;
      case 40: P([[-8, -6], [-3, -6], [-5, 8]], 1); P([[3, -6], [8, -6], [5, 8]], 1); break;
      case 41: c.beginPath(); c.ellipse(0, 0, 5, 10, 0.6, 0, TAU); c.fill(); break;
      case 42: c.beginPath(); c.ellipse(1, -1, 4, 10, 0.7, 0, TAU); c.fill(); P([[-8, 9], [3, -2]]); break;
      case 43: c.fillRect(-8, -9, 16, 18); c.fillStyle = '#1a1020'; c.fillRect(-5, -6, 10, 2); c.fillRect(-5, -2, 8, 2); break;
      case 90: c.fillRect(-2.5, -9, 5, 18); c.fillRect(-9, -2.5, 18, 5); break;
      case 25: c.fillRect(-7, 2, 14, 7); c.fillRect(-4, -4, 8, 7); c.lineWidth = 3; P([[0, -1], [10, -7]]); C(-4, 10, 1.6, 1); C(4, 10, 1.6, 1); break;
      case 26: c.lineWidth = 3; c.beginPath(); c.arc(0, 0, 9, 0.3, 5.2); c.stroke(); P([[9, -4], [10, 4], [4, 0]], 1); C(0, 0, 3, 1); break;
      case 27: for (let k = 0; k < 5; k++) { const a = k * TAU / 5 - Math.PI / 2; c.beginPath(); c.ellipse(Math.cos(a) * 5, Math.sin(a) * 5 - 2, 3.6, 5, a + Math.PI / 2, 0, TAU); c.fill(); } c.fillStyle = '#ffe07a'; C(0, -2, 2.6, 1); c.strokeStyle = '#6fcf6a'; P([[0, 4], [0, 11]]); break;
      case 28: c.lineWidth = 2.2; P([[-10, -6], [-3, 0], [-6, 3], [3, 8], [0, 3], [10, 6]]); C(-10, -6, 2, 1); C(10, 6, 2, 1); break;
      case 29: c.beginPath(); c.moveTo(-11, -4); c.quadraticCurveTo(-4, -8, 0, -2); c.quadraticCurveTo(4, -8, 11, -4); c.quadraticCurveTo(4, 0, 2, 4); c.lineTo(0, 10); c.lineTo(-2, 4); c.quadraticCurveTo(-4, 0, -11, -4); c.fill(); break;
      default: { c.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, r = k % 2 ? 4 : 10; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); }
    }
    c.restore();
  }
  const TR_OWN = TR.map((t, i) => CH.findIndex((c) => c.tr.indexOf(i) >= 0));
  // build paths (갈래) of a character: k0 sig+trait0, k1 sig+trait2, k2 2nd weapon+trait1, k3 2nd weapon+trait3
  function pathsOf(ci) {
    const c = CH[ci] || CH[0], W2 = [c.w, c.w, c.w2, c.w2], TT = [c.tr[0], c.tr[2], c.tr[1], c.tr[3]];
    return [0, 1, 2, 3].map((k) => {
      const t = TT[k], ev = EVO.findIndex((E) => E.w === W2[k] && E.from < 0 && E.req.some((r) => r[0] === TR0 + t));
      const ev2 = EVO.findIndex((E) => E.from === ev);
      return { nm: c.pt[k][0], d: c.pt[k][1], w: W2[k], t, ev, ev2 };
    });
  }
  const evoCol = (E) => (E.from >= 0 ? '#ff8a4a' : E.k === 'A' ? '#ffd36a' : '#ff9ad0');
  const reqText = (E) => E.req.map((r) => itemName(r[0]) + (isW(r[0]) ? ' Lv' + r[1] : r[1] > 1 ? ' Lv' + r[1] : '')).join(' + ');
  const cardGlyph = (id) => (isEv(id) ? EVO[id - EV0].w : isT(id) ? TR[id - TR0].g : id === FH ? 90 : id === FM ? 99 : id);
  const itemCol = (id) => (isEv(id) ? evoCol(EVO[id - EV0]) : isT(id) ? shade((CH[TR_OWN[id - TR0]] || CH[0]).col, 0.35) : isP(id) ? PS[id - PI0].col : isW(id) ? WP[id].col : id === FH ? '#ff6a8a' : '#ffd36a');
  const itemName = (id) => (isEv(id) ? EVO[id - EV0].nm : isT(id) ? TR[id - TR0].nm : isP(id) ? PS[id - PI0].nm : isW(id) ? WP[id].nm : id === FH ? '회복 고기' : '작은 힘');
  // icon tiles: kind 'c' = card id, 'r' = relic id. Exclusive things get the owner's colour, relics a rarity frame
  function drawTile(g, kind, id, s) {
    const rr = (x, y, w, h, r) => { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); };
    g.save();
    if (kind === 'r') {
      const R = RE[id] || RE[0], col = RAR[R.r].col;
      g.translate(s / 2, s / 2);
      g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.moveTo(0, -s * 0.48); g.lineTo(s * 0.48, 0); g.lineTo(0, s * 0.48); g.lineTo(-s * 0.48, 0); g.closePath(); g.fill();
      g.strokeStyle = col; g.lineWidth = Math.max(1.5, s * 0.06); g.stroke();
      if (R.r >= 2) { g.fillStyle = hexA(col, 0.18); g.fill(); }
      glyph(g, R.g, s * 0.5, col);
      if (R.rk) { g.fillStyle = '#ff5a4a'; g.beginPath(); g.arc(s * 0.3, -s * 0.3, s * 0.1, 0, TAU); g.fill(); }
    } else {
      const ev = isEv(id), tr = isT(id), wx = isW(id) && WP[id].ex != null, own = tr ? TR_OWN[id - TR0] : wx ? WP[id].ex : ev ? EVO[id - EV0].ex : null;
      const oc = own != null ? CH[own].col : null;
      g.fillStyle = ev ? 'rgba(90,60,10,.6)' : 'rgba(0,0,0,.35)';
      if (tr) { g.beginPath(); for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + Math.PI / 6; g.lineTo(s / 2 + Math.cos(a) * s * 0.49, s / 2 + Math.sin(a) * s * 0.49); } g.closePath(); g.fill(); }
      else { rr(1, 1, s - 2, s - 2, s * 0.22); g.fill(); }
      if (oc || ev) { g.strokeStyle = ev ? evoCol(EVO[id - EV0]) : shade(oc, 0.25); g.lineWidth = Math.max(1.4, s * 0.05); g.stroke(); }
      if (ev && EVO[id - EV0].from >= 0) { rr(s * 0.12, s * 0.12, s * 0.76, s * 0.76, s * 0.16); g.lineWidth = 1; g.stroke(); }
      g.translate(s / 2, s / 2); glyph(g, cardGlyph(id), s * 0.66, itemCol(id));
    }
    g.restore();
  }
  function tileCanvas(kind, id, s) {
    const c = document.createElement('canvas'), d = Math.min(3, window.devicePixelRatio || 1);
    c.width = c.height = Math.round(s * d); c.style.width = c.style.height = s + 'px';
    const g = c.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); drawTile(g, kind, id, s);
    return c;
  }

  /* ---------- small per-device conveniences (last character, tips seen). No progression of any kind. ---------- */
  try { localStorage.removeItem('lounge.swarm.meta'); } catch (e) {}   // old achievement data (unlocks were removed)
  function lsGet(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

  /* ---------- guest world ---------- */
  function guestWorld(st) {
    const M = genMap(st.sg, st.seed);
    const G = { st, M, S: STG[st.sg] || STG[0], np: st.np, T: 0, lv: 1, xpf: 0, kills: 0, frz: 0, tide: null, Z: [], bh: null, solo: 0,
      ex: new Float32Array(MAXE), ey: new Float32Array(MAXE), tx: new Float32Array(MAXE), ty: new Float32Array(MAXE),
      vx: new Float32Array(MAXE), vy: new Float32Array(MAXE), ut: new Float64Array(MAXE), et: new Uint8Array(MAXE), eel: new Uint8Array(MAXE),
      eal: new Uint8Array(MAXE), efl: new Float32Array(MAXE), hiE: 0, pl: [], deaths: [],
      B: { n: 0, k: new Uint8Array(80), x: new Float32Array(80), y: new Float32Array(80), a: new Float32Array(80), r: new Float32Array(80), t: 0 },
      Gm: { n: 0, k: new Uint8Array(80), x: new Float32Array(80), y: new Float32Array(80) }, off: {}, lastQ: -1, fxSeq: 0, Tl: 0 };
    for (let s = 0; s < st.np; s++) {
      const p = newPlayer(s, st.ch && st.ch[s] >= 0 ? st.ch[s] : 0, WS / 2, WS / 2);
      p.tx = p.x; p.ty = p.y; p.rx = p.x; p.ry = p.y; p.flags = 0;
      G.pl.push(p);
    }
    return G;
  }
  function applySnap(G, hs, now, mySeat, onDeath) {
    if (!hs || typeof hs !== 'object') return;
    const h = hs.h ? 1 : 0, E = typeof hs.E === 'string' ? hs.E : '';
    let pos = 0, hi = 0;
    for (let i = h; i < MAXE; i += 2) {
      if (pos < E.length && E[pos] !== ' ') {
        let el = 0; if (E[pos] === '!') { el = 1; pos++; }
        const t = (TAI[E[pos]] | 0) % ET.length, x = d2(E, pos + 1), y = d2(E, pos + 3);
        pos += 5;
        if (G.eal[i] && G.et[i] === t) {
          const dt = Math.max(0.03, (now - G.ut[i]) / 1000);
          let vx = (x - G.tx[i]) / dt, vy = (y - G.ty[i]) / dt; const v = hyp(vx, vy);
          if (v > 320) { vx *= 320 / v; vy *= 320 / v; }
          G.vx[i] = vx; G.vy[i] = vy;
          if (hyp(x - G.ex[i], y - G.ey[i]) > 90) { G.ex[i] = x; G.ey[i] = y; }
        } else { G.ex[i] = x; G.ey[i] = y; G.vx[i] = 0; G.vy[i] = 0; }
        G.tx[i] = x; G.ty[i] = y; G.ut[i] = now; G.et[i] = t; G.eel[i] = el; G.eal[i] = 1;
      } else {
        if (pos < E.length) pos++;
        if (G.eal[i]) { G.eal[i] = 0; onDeath(G.ex[i], G.ey[i], G.et[i], G.eel[i]); }
      }
    }
    for (let i = 0; i < MAXE; i++) if (G.eal[i]) hi = i + 1;
    G.hiE = hi;
    if (fin(hs.T)) { G.T = hs.T / 10; if (Math.abs(G.Tl - G.T) > 1) G.Tl = G.T; }
    G.lv = hs.L | 0 || 1; G.xpf = clamp((hs.X | 0) / 100, 0, 1); G.kills = hs.K | 0; G.frz = hs.fz ? 1 : 0;
    G.bh = Array.isArray(hs.bh) ? hs.bh : null;
    G.wind = Array.isArray(hs.wd) ? { a: (+hs.wd[0] || 0) / 100, on: hs.wd[1] ? 1 : 0, warn: hs.wd[1] ? 0 : 1 } : null;
    G.dark = hs.dk != null ? { on: hs.dk ? 1 : 0, warn: hs.dk ? 0 : 1 } : null;
    if (Array.isArray(hs.td)) G.tide = { x: +hs.td[0] || 0, side: hs.td[1] < 0 ? -1 : 1, on: hs.td[2] ? 1 : 0, warn: (+hs.td[3] || 0) / 10 }; else G.tide = null;
    G.Z = Array.isArray(hs.Z) ? hs.Z.filter((z) => Array.isArray(z) && z.length >= 7).map((z) => ({ id: z[0], k: ZK[z[1]] || 'hand', x: +z[2], y: +z[3], r: +z[4], ph: z[5] | 0, t: (+z[6] || 0) / 10 })) : [];
    // projectiles / gems
    const B = G.B, bs = typeof hs.B === 'string' ? hs.B : '';
    B.n = 0; B.t = now;
    for (let k = 0; k + 6 < bs.length + 0 && B.n < 80; k += 7) {
      B.k[B.n] = TAI[bs[k]] | 0; B.x[B.n] = d2(bs, k + 1); B.y[B.n] = d2(bs, k + 3); B.a[B.n] = da(bs[k + 5]); B.r[B.n] = (B64I[bs[k + 6]] | 0); B.n++;
    }
    const Gm = G.Gm, gs = typeof hs.G === 'string' ? hs.G : '';
    Gm.n = 0;
    for (let k = 0; k + 4 < gs.length && Gm.n < 80; k += 5) { Gm.k[Gm.n] = TAI[gs[k]] | 0; Gm.x[Gm.n] = d2(gs, k + 1); Gm.y[Gm.n] = d2(gs, k + 3); Gm.n++; }
    // players
    if (Array.isArray(hs.P)) hs.P.forEach((a, s) => {
      const p = G.pl[s]; if (!p || !Array.isArray(a) || a.length < 10) return;
      p.tx = (+a[0] || 0) / 2; p.ty = (+a[1] || 0) / 2; p.hp = +a[2] || 0; p.mhp = +a[3] || 100;
      const f = a[4] | 0; p.flags = f; p.dn = f & 1; p.iv = f & 2 ? 0.1 : 0; p.rt = f & 4 ? 0.1 : 0; p.bub = f & 8 ? 1 : 0; p.dt = f & 16 ? 0.1 : 0; p.hurtF = f & 32 ? 0.2 : 0;
      p.rv = (+a[5] || 0) / 100;
      if (s !== mySeat) { const an = da(String(a[6] || 'A')[0]); p.fx = Math.cos(an); p.fy = Math.sin(an); }
      const inv = String(a[7] || '');
      const rel = String(a[10] || '');
      if (inv !== p.invS || rel !== p.relS) { p.invS = inv; p.relS = rel; parseInv(inv, p); parseRel(rel, p); recalc(p); p.hp = +a[2] || 0; }
      p.kills = a[8] | 0;
      p.qn = a[11] | 0;
      if (s !== mySeat) p.dc = (+a[9] || 0) / 10;
    });
    G.off = hs.O && typeof hs.O === 'object' ? hs.O : {};
    G.roff = hs.RO && typeof hs.RO === 'object' ? hs.RO : {};
    G.slowT = hs.sl ? 1 : 0;
  }

  /* ---------- 도감 (codex) renderer — shared by the in-game sheet and def.codex (setup screen / lobby) ---------- */
  const tn = (t) => document.createTextNode(t);
  const CX_TABS = ['캐릭터', '무기', '진화', '아이템', '유물'];
  function portrait(i, size) {
    const c = document.createElement('canvas'), d = Math.min(3, window.devicePixelRatio || 1);
    c.width = c.height = Math.round(size * d); c.style.width = c.style.height = size + 'px';
    const g = c.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); g.translate(size / 2, size * 0.58); drawHero(g, i, size * 0.36);
    return c;
  }
  const chip = (text, col, cls) => L.h('span', { class: 'sw-chip' + (cls ? ' ' + cls : ''), style: { '--c': col || '#e3ae45' }, text });

  function row(tile, title, desc, extra) {
    const r = L.h('div', { class: 'sw-row' });
    const tx = L.h('div', { class: 'tx' }), b = L.h('b');
    if (Array.isArray(title)) b.append(...title); else b.append(tn(title));
    tx.append(b);
    if (desc) tx.append(L.h('small', { text: desc }));
    if (extra) tx.append(extra);
    r.append(tile, tx);
    return r;
  }
  // one evolution step: [from tile] + [req tiles] → [evo tile] name
  function evoStep(k, small) {
    const E = EVO[k], d = L.h('div', { class: 'sw-evo' + (E.from >= 0 ? ' e2' : '') }), sz = small ? 22 : 26;
    d.append(tileCanvas('c', E.from >= 0 ? EV0 + E.from : E.w, sz), tn(E.from >= 0 ? ' + ' : ' Lv6 + '));
    E.req.forEach((r, j) => { if (j) d.append(tn(' + ')); d.append(tileCanvas('c', r[0], sz)); if (r[1] > 1 || isW(r[0])) d.append(L.h('i', { text: 'Lv' + r[1] })); });
    d.append(tn(' → '), tileCanvas('c', EV0 + k, sz), L.h('b', { style: { color: evoCol(E) }, text: ' ' + E.nm }));
    return d;
  }
  // evolution tree of one weapon: branches and their 2nd evolutions
  function evoTree(i) {
    const box = L.h('div', { class: 'sw-tree' });
    EVO.forEach((E, k) => {
      if (E.w !== i || E.from >= 0) return;
      box.append(evoStep(k), L.h('small', { class: 'sw-ed', text: E.d }));
      EVO.forEach((E2, k2) => { if (E2.from === k) box.append(L.h('div', { class: 'sw-e2' }, L.h('em', { text: '└ 2차 진화' }), evoStep(k2, true), L.h('small', { class: 'sw-ed', text: E2.d }))); });
    });
    return box;
  }
  function pathBox(ci, tiny) {
    const box = L.h('div', { class: 'sw-paths' });
    pathsOf(ci).forEach((P, k) => {
      const l = L.h('div', { class: 'sw-path' });
      l.append(L.h('em', { text: '갈래 ' + (k + 1) + ' · ' + P.nm }), tileCanvas('c', P.w, 22), tn('+'), tileCanvas('c', TR0 + P.t, 22), tn('→'), tileCanvas('c', EV0 + P.ev, 22));
      if (P.ev2 >= 0) l.append(tn('→'), tileCanvas('c', EV0 + P.ev2, 22));
      if (!tiny) l.append(L.h('small', { text: P.d + ' · ' + EVO[P.ev].nm + (P.ev2 >= 0 ? ' → ' + EVO[P.ev2].nm : '') }));
      else l.append(L.h('small', { text: P.d }));
      box.append(l);
    });
    return box;
  }
  function codexBody(body, tab) {
    const sec = (t, sub) => body.append(L.h('h4', {}, tn(t), sub ? L.h('small', { text: ' ' + sub }) : ''));
    if (tab === 0) {
      sec('캐릭터 10명', '모두 처음부터 고를 수 있어요');
      CH.forEach((c, i) => {
        const ex = L.h('div', { class: 'sw-ex' });
        ex.append(L.h('div', { class: 'sw-ex-l' }, L.h('em', { text: '전용 무기' }), tileCanvas('c', c.w, 24), tn(WP[c.w].nm + ' (시작)'), tileCanvas('c', c.w2, 24), tn(WP[c.w2].nm)));
        ex.append(pathBox(i));
        body.append(row(portrait(i, 44), [L.h('span', { style: { color: shade(c.col, 0.35) }, text: c.nm }), chip(c.t, shade(c.col, 0.3))], c.d + ' — ' + c.st, ex));
      });
    } else if (tab === 1) {
      sec('공용 무기', '누구나 레벨업 카드로 얻어요');
      WP.forEach((q, i) => { if (q.ex == null) body.append(row(tileCanvas('c', i, 40), q.nm, q.d + ' · 진화 ' + EVO.filter((E) => E.w === i).length + '가지(도감 「진화」)')); });
      sec('캐릭터 전용 무기', '그 캐릭터만 얻어요');
      CH.forEach((c) => [c.w, c.w2].forEach((i) => body.append(row(tileCanvas('c', i, 40), [tn(WP[i].nm), chip(c.nm, shade(c.col, 0.3))], WP[i].d + ' · 진화 ' + EVO.filter((E) => E.w === i).length + '가지'))));
      body.append(L.h('p', { class: 'sw-note', text: '무기는 최대 6개, 각각 Lv 6까지. Lv 6 + 짝을 가지면 다음 레벨업 카드에 진화가 나와요. 짝에 따라 진화가 갈라지고, 일부는 2차 진화까지 있어요.' }));
    } else if (tab === 2) {
      sec('진화 ' + EVO.length + '가지', '같은 무기도 짝에 따라 갈라져요');
      body.append(L.h('p', { class: 'sw-note', text: '금색 = 기본 진화 · 분홍 = 다른 갈래 · 주황(겹테두리) = 2차 진화. 진화 카드가 두 장 나오면 하나를 골라 갈래를 정해요. 한 번 정한 갈래는 그 판에서 바뀌지 않아요.' }));
      const one = (i) => { const q = WP[i], own = q.ex != null ? CH[q.ex] : null; body.append(row(tileCanvas('c', i, 40), own ? [tn(q.nm), chip(own.nm + ' 전용', shade(own.col, 0.3))] : [tn(q.nm), chip('공용', '#c8c0d4')], '', evoTree(i))); };
      sec('공용 무기');
      WP.forEach((q, i) => { if (q.ex == null) one(i); });
      CH.forEach((c) => { sec(c.nm); one(c.w); one(c.w2); });
    } else if (tab === 3) {
      sec('공용 아이템', '누구나 · 최대 6개');
      PS.forEach((q, i) => body.append(row(tileCanvas('c', PI0 + i, 40), q.nm, q.d + ' · 최대 Lv ' + q.mx)));
      sec('캐릭터 전용 특성', '그 캐릭터만 · 최대 Lv 3 · 고르는 특성이 갈래를 정해요');
      TR.forEach((t, i) => { const c = CH[TR_OWN[i]]; body.append(row(tileCanvas('c', TR0 + i, 40), [tn(t.nm), chip(c.nm, shade(c.col, 0.3))], t.d)); });
    } else {
      sec('유물 ' + RE.length + '개', '유물 상자에서 3개 중 1개');
      body.append(L.h('p', { class: 'sw-note', text: '보스를 쓰러뜨리면 반드시 큰 유물 상자(모두 하나씩 골라요). 강한 적·보급 상자·아주 드물게 일반 적에게서도 나와요. 마음에 안 들면 건너뛸 수 있어요. 빨간 점 = 위험한 거래.' }));
      for (let r = 0; r < 4; r++) {
        sec(RAR[r].nm, r === 0 ? '자주 나와요' : r === 3 ? '아주 드물고 강해요' : '');
        RE.forEach((q, i) => { if (q.r === r) body.append(row(tileCanvas('r', i, 40), [L.h('span', { style: { color: RAR[r].col }, text: q.nm }), q.rk ? chip('위험한 거래', '#ff7a6a') : ''], q.d)); });
      }
    }
  }
  // def.codex: same tabs/data, drawn inside core's 📖 도감 sheet
  function codexSheet(el) {
    let tab = 0;
    const wrap = L.h('div', { class: 'sw-cxw' });
    const draw = () => {
      wrap.textContent = '';
      const tabs = L.h('div', { class: 'sw-tabs' });
      CX_TABS.forEach((t, k) => { const b = L.h('button', { class: 'sw-tab' + (k === tab ? ' on' : ''), type: 'button', text: t }); b.onclick = () => { tab = k; draw(); const sh = wrap.closest('.sheet'); if (sh) { const dy = wrap.getBoundingClientRect().top - sh.getBoundingClientRect().top; if (dy < 0) sh.scrollTop += dy; } }; tabs.append(b); });
      const body = L.h('div', { class: 'sw-sh-b' });
      body.append(L.h('p', { class: 'sw-note', text: '처음부터 모두 열려 있어요 · 한 판 안에서만 강해져요' }));
      codexBody(body, tab);
      wrap.append(tabs, body);
    };
    el.append(L.h('style', { text: CSS + CX_CSS }), wrap);
    draw();
  }
  const CX_CSS = '.sw-cxw{margin:0 -8px;border-radius:12px;overflow:hidden;background:#1d1729;color:#f2e9d8;font-family:var(--f-body,system-ui)}'
    + '.sw-cxw .sw-tabs{flex-wrap:wrap;overflow:visible;background:#16111f;padding:8px 6px 0}.sw-cxw .sw-tab{flex:1 0 auto}'
    + '.sw-cxw .sw-sh-b{overflow:visible;padding:6px 8px 14px}';

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    const COL = (s) => P(s).color || ['#ee6a55', '#5bb3e6', '#7cc66a', '#e3ae45'][s % 4];
    let st = null, key = null, W = null, Gw = null, phase = 'wait', cd = 0, acc = 0;
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st || auto()) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const RW = () => (host() ? W : Gw);
    const loc = { mx: 0, my: 0, d: 0 };
    const aiC = [], mem = [], remC = {};
    let C = [];

    /* ---------- DOM ---------- */
    const ui = L.h('div', { class: 'sw-ui' });
    const hint = L.h('div', { class: 'sw-hint off', text: '' });
    const dashB = L.h('button', { class: 'sw-dash', type: 'button', 'aria-label': '대시' });
    dashB.innerHTML = '<span>대시</span>'; dashB.hidden = true;
    const bagB = L.h('button', { class: 'sw-bagb', type: 'button', 'aria-label': '내 빌드 보기' });
    bagB.innerHTML = '<span>가방</span><i></i>'; bagB.hidden = true;
    const cards = L.h('div', { class: 'sw-cards' }); cards.hidden = true;
    const relP = L.h('div', { class: 'sw-cards sw-rel' }); relP.hidden = true;
    const gotEl = L.h('div', { class: 'sw-got' }); gotEl.hidden = true;
    const pick = L.h('div', { class: 'sw-pick' }); pick.hidden = true;
    const goB = L.h('button', { class: 'btn primary sw-go', type: 'button', text: '출발!' }); goB.hidden = true;
    const waitT = L.h('div', { class: 'sw-wait', text: '' });
    const bag = L.h('div', { class: 'sw-sheet sw-bag' }); bag.hidden = true;
    const codex = L.h('div', { class: 'sw-sheet sw-codex' }); codex.hidden = true;
    ui.append(hint, dashB, bagB, cards, relP, gotEl);
    root.append(ui, pick, goB, waitT, bag, codex);
    for (const el of [cards, relP, bag, codex, bagB, gotEl]) el.addEventListener('pointerdown', (e) => e.stopPropagation());
    function dashNow() {
      const R = RW(), m = me();
      if (!R || m < 0 || !st || !st.dsh || phase !== 'play') return;
      const p = R.pl[m];
      if (!p || p.dn || p.dc > 0) return;
      loc.d = (loc.d % 1000) + 1;
      const mm = hyp(loc.mx, loc.my); if (mm > 0.2 && !host()) { p.fx = loc.mx / mm; p.fy = loc.my / mm; }
      if (!host()) doDash(Gw, p);
      api.sfx('whoosh'); api.buzz(12);
    }
    dashB.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); dashNow(); });
    const T_ = (t) => document.createTextNode(t);
    /* ---------- 도감 (codex): everything visible from the start (renderer: codexBody, module level) ---------- */
    let codexTab = 0, codexOpen = false;
    function buildCodex() {
      codex.textContent = '';
      const head = L.h('div', { class: 'sw-sh-h' }, L.h('b', { text: '📖 도감' }), L.h('span', { text: '처음부터 모두 열려 있어요 · 한 판 안에서만 강해져요' }));
      const x = L.h('button', { class: 'sw-x', type: 'button', 'aria-label': '닫기', text: '✕' });
      x.onclick = () => openCodex(false);
      head.append(x);
      const tabs = L.h('div', { class: 'sw-tabs' });
      CX_TABS.forEach((t, k) => { const b = L.h('button', { class: 'sw-tab' + (k === codexTab ? ' on' : ''), type: 'button', text: t }); b.onclick = () => { codexTab = k; api.sfx('tick'); buildCodex(); }; tabs.append(b); });
      const body = L.h('div', { class: 'sw-sh-b' });
      codexBody(body, codexTab);
      codex.append(head, tabs, body);
    }
    function openCodex(on) {
      codexOpen = !!on; codex.hidden = !on;
      if (on) { buildCodex(); api.sfx('click'); }
    }

    /* ---------- 가방 (my build, in-run) ---------- */
    let bagOpen = false;
    function buildBag() {
      const R = RW(), m = me(), p = R && m >= 0 ? R.pl[m] : null;
      bag.textContent = '';
      const head = L.h('div', { class: 'sw-sh-h' }, L.h('b', { text: '가방 · 내 빌드' }), L.h('span', { text: R && R.solo ? '보는 동안 잠깐 멈춰요' : '보는 동안에도 게임은 계속돼요' }));
      const x = L.h('button', { class: 'sw-x', type: 'button', 'aria-label': '닫기', text: '✕' });
      x.onclick = () => openBag(false);
      head.append(x);
      const body = L.h('div', { class: 'sw-sh-b' });
      if (p) {
        const c = CH[p.ch] || CH[0];
        body.append(row(portrait(p.ch, 44), [L.h('span', { style: { color: shade(c.col, 0.35) }, text: c.nm }), chip(c.t, shade(c.col, 0.3))], c.d));
        body.append(L.h('h4', { text: '무기 ' + p.W.length + '/' + WMAX }));
        p.W.forEach((w) => {
          const q = WP[w.i], E = w.e ? EVO[w.e - 1] : null;
          const nxt = EVO.filter((X) => X.w === w.i && (E ? X.from === w.e - 1 : X.from < 0));
          const hint = nxt.length ? (E ? ' · 2차 진화: ' : ' · 진화: Lv 6 + ') + nxt.map((X) => reqText(X) + (reqMet(p, X) ? ' ✓' : '') + ' → ' + X.nm).join(' / ') : '';
          body.append(row(tileCanvas('c', E ? EV0 + w.e - 1 : w.i, 40), E ? [T_(E.nm), chip(E.from >= 0 ? '2차 진화' : '진화', evoCol(E))] : [T_(q.nm + ' Lv ' + w.l), q.ex != null ? chip('전용', shade(c.col, 0.3)) : ''],
            (E ? E.d : q.d) + hint));
        });
        if (p.T.length) { body.append(L.h('h4', { text: '전용 특성' })); p.T.forEach((t) => body.append(row(tileCanvas('c', TR0 + t.i, 40), TR[t.i].nm + ' Lv ' + t.l + '/' + TMX, TR[t.i].d))); }
        if (p.P.length) { body.append(L.h('h4', { text: '아이템 ' + p.P.length + '/' + PMAX_SLOTS })); p.P.forEach((q) => body.append(row(tileCanvas('c', PI0 + q.i, 40), PS[q.i].nm + ' Lv ' + q.l + '/' + PS[q.i].mx, PS[q.i].d))); }
        body.append(L.h('h4', { text: '유물 ' + p.R.length + '개' }));
        if (!p.R.length) body.append(L.h('p', { class: 'sw-note', text: '아직 없어요. 보스나 강한 적이 떨어뜨리는 유물 상자를 열어 보세요.' }));
        p.R.forEach((i) => body.append(row(tileCanvas('r', i, 40), [L.h('span', { style: { color: RAR[RE[i].r].col }, text: RE[i].nm }), chip(RAR[RE[i].r].nm, RAR[RE[i].r].col)], RE[i].d)));
      }
      const cb = L.h('button', { class: 'btn sw-wide', type: 'button', text: '📖 도감 보기' });
      cb.onclick = () => openCodex(true);
      body.append(cb);
      bag.append(head, body);
    }
    function openBag(on) {
      bagOpen = !!on; bag.hidden = !on;
      if (on) { buildBag(); api.sfx('click'); } else openCodex(false);
    }
    bagB.onclick = () => openBag(!bagOpen);
    function closeOverlays() { openBag(false); openCodex(false); }
    // Esc closes the codex / bag first (core uses Esc for "back" otherwise)
    const onEsc = (e) => { if (e.key === 'Escape' && (codexOpen || bagOpen)) { e.preventDefault(); e.stopPropagation(); if (codexOpen) openCodex(false); else openBag(false); } };
    window.addEventListener('keydown', onEsc, true);

    /* ---------- character pick ---------- */
    let selCh = clamp(lsGet('lounge.swarm.last', 0) | 0, 0, CH.length - 1);
    let pickSent = -1, pickBuilt = '';
    function buildPick() {
      const sig = st.rid + '|' + selCh + '|' + pickSent + '|' + (st.ch || []).join(',');
      if (sig === pickBuilt) return;
      pickBuilt = sig;
      pick.textContent = '';
      const S = STG[st.sg] || STG[0];
      const cxB = L.h('button', { class: 'sw-cxb', type: 'button', text: '📖 도감' });
      cxB.onclick = () => openCodex(true);
      pick.append(L.h('div', { class: 'sw-pk-h' }, L.h('b', { text: '캐릭터를 골라요' }),
        L.h('span', { text: (st.so < 0 ? '무작위 무대: ' : '무대: ') + S.nm + ' · ' + Math.round(st.dur / 60) + '분 버티기' }),
        L.h('div', { class: 'sw-pk-s', text: S.sub }), cxB));
      const grid = L.h('div', { class: 'sw-grid' });
      CH.forEach((c, i) => {
        const b = L.h('button', { class: 'sw-cc' + (i === selCh ? ' sel' : ''), type: 'button', style: { '--c': c.col } });
        b.append(portrait(i, 36), L.h('b', { text: c.nm }), L.h('small', { text: c.t }));
        b.onclick = () => { if (pickSent >= 0) return; selCh = i; api.sfx('click'); buildPick(); };
        grid.append(b);
      });
      pick.append(grid);
      const c = CH[selCh];
      const info = L.h('div', { class: 'sw-info' });
      info.append(L.h('div', { class: 'sw-info-h' }, L.h('b', { text: c.nm }), chip(c.t, shade(c.col, 0.3)), L.h('span', { text: c.st })));
      info.append(L.h('div', { class: 'sw-info-d' }, L.h('em', { text: '고유 능력 ' }), T_(c.d)));
      info.append(L.h('div', { class: 'sw-ex-l' }, L.h('em', { text: '전용 무기' }), tileCanvas('c', c.w, 24), T_(WP[c.w].nm + ' (시작)'), tileCanvas('c', c.w2, 24), T_(WP[c.w2].nm)));
      info.append(pathBox(selCh, true));
      info.append(L.h('div', { class: 'sw-info-n', text: '갈래 4개 중 어디로 갈지는 판 안에서 레벨업 카드(전용 특성)로 정해요. 자세한 진화는 📖 도감.' }));
      pick.append(info);
      if (!lsGet('lounge.swarm.tips2', 0)) {
        pick.append(L.h('div', { class: 'sw-tips' }, L.h('b', { text: '처음이라면' }), L.h('br'),
          T_('① 공격은 저절로! 화면 아무 데나 손가락을 대고 끌면 그쪽으로 걸어요.'), L.h('br'),
          T_('② 보석을 모아 레벨업 → 카드 3장 중 1장. 마음에 안 들면 건너뛰고 경험치 일부를 돌려받아요.'), L.h('br'),
          T_('③ 보스·강한 적의 유물 상자에서 유물을 골라요. 모든 내용은 📖 도감에 있어요.')));
      }
      const humans = (st.hu || []).reduce((a, v) => a + v, 0);
      if (humans > 1) {
        const left = (st.hu || []).map((v, i) => (v && !(st.ch[i] >= 0) ? name(i) : null)).filter(Boolean);
        waitT.textContent = pickSent >= 0 ? (left.length ? '기다리는 중: ' + left.join(', ') : '곧 시작해요') : '';
      } else waitT.textContent = '';
      goB.textContent = pickSent >= 0 ? '골랐어요 ✓' : '출발!';
      goB.disabled = pickSent >= 0;
    }
    goB.onclick = () => {
      if (!st || st.ph !== 'pick' || pickSent >= 0) return;
      const m = me(); if (m < 0) return;
      pickSent = selCh; lsSet('lounge.swarm.last', selCh); lsSet('lounge.swarm.tips2', 1);
      api.sfx('chip'); api.buzz(14);
      if (host()) { const ch = st.ch.slice(); ch[m] = selCh; api.setState(Object.assign({}, st, { ch })); }
      buildPick();
    };

    /* ---------- level-up cards (with skip) ---------- */
    let cardSig = '', cardSent = -1, cardIdx = 0, cardAt = 0;
    // [q, refund×10, ids...]
    function myOffer() {
      const m = me(); if (m < 0) return null;
      if (host()) { const p = W && W.pl[m]; return p && p.off && !p.ro ? [p.off.q, Math.round(refundOf(W, p.off.n) * 10)].concat(p.off.c) : null; }
      const o = Gw && Gw.off && Gw.off[m]; return Array.isArray(o) && o.length >= 3 && !(Gw.roff && Gw.roff[m]) ? o : null;
    }
    function cardText(id, p) {
      const ex = isExcl(p, id);
      if (isEv(id)) { const E = EVO[id - EV0]; return [E.from >= 0 ? '2차 진화!' : '진화!', E.nm, E.d + ' · ' + WP[E.w].nm + (E.from >= 0 ? '의 최종 형태' : '의 갈래'), ex]; }
      // hint: which evolution this card leads to
      const hs = evoHints(p, id).filter((E) => !isW(id) || E.from < 0).slice(0, 2);
      const hint = hs.length ? (isW(id) ? ' · 진화: ' + hs.map((E) => E.nm).join(' / ') : ' · 고르면 → ' + hs.map((E) => E.nm).join(' / ') + ' 진화 가능') : '';
      if (isT(id)) {
        const t = id - TR0, l = tlvl(p, t), k = (CH[p.ch] || CH[0]).tr.indexOf(t), pk = [0, 2, 1, 3][k];
        return [l ? 'Lv ' + l + ' → ' + (l + 1) : '새 특성', TR[t].nm, (pk >= 0 ? '갈래 ' + (pk + 1) + ' · ' : '') + TR[t].d + hint, true];
      }
      if (isP(id)) { const l = plvl(p, id - PI0), q = PS[id - PI0]; return [l ? 'Lv ' + l + ' → ' + (l + 1) : '새 아이템', q.nm, q.d + (l ? '' : ' · 최대 Lv ' + q.mx) + hint, false]; }
      if (isW(id)) {
        const w = p.W.find((x) => x.i === id), q = WP[id];
        return [w ? 'Lv ' + w.l + ' → ' + (w.l + 1) : '새 무기', q.nm, (w ? (w.l + 1 >= WLV ? '최대 레벨! 이제 진화할 수 있어요' : '더 세고 많아져요') : q.d) + hint, ex];
      }
      return id === FH ? ['', '회복 고기', '체력 +30', false] : ['', '작은 힘', '모든 피해 +2%', false];
    }
    function choose(idx) {
      const o = myOffer(); if (!o) return;
      if (performance.now() - cardAt < 250) return;   // guard against a tap that was meant for movement
      if (idx >= o.length - 2) return;
      api.sfx(idx < 0 ? 'tick' : 'card'); api.buzz(14);
      if (host()) pickCard(W, W.pl[me()], idx);
      else { cardSent = o[0]; cardIdx = idx; }
      cards.hidden = true; cardSig = '';
    }
    function syncCards() {
      const o = phase === 'play' ? myOffer() : null;
      if (!o || (!host() && cardSent === o[0])) { if (!cards.hidden) { cards.hidden = true; cardSig = ''; } return; }
      const sig = o.join(',');
      const R = RW(), p = R.pl[me()];
      if (sig !== cardSig) {
        cardSig = sig;
        cards.textContent = '';
        const solo = R.solo, chc = CH[p.ch] || CH[0];
        cards.append(L.h('h3', { text: '레벨 업! 카드 1장을 골라요' }),
          L.h('div', { class: 'sub', text: solo ? '고르는 동안 잠깐 멈춰요' : '고르는 동안 보호막이 지켜 줘요 · 계속 움직일 수 있어요' }));
        if (!solo) { const tb = L.h('div', { class: 'sw-tbar' }); tb.append(L.h('i')); cards.append(tb); }
        o.slice(2).forEach((id, k) => {
          const t = cardText(id, p), b = L.h('button', { class: 'sw-card' + (isEv(id) ? ' evo' : '') + (t[3] ? ' ex' : ''), type: 'button', style: { '--c': shade(chc.col, 0.25) } });
          const tx = L.h('div', { class: 'tx' }), bb = L.h('b', { text: t[1] });
          if (t[0]) bb.append(L.h('em', { text: t[0] }));
          if (t[3] && !isEv(id)) bb.append(chip('전용', shade(chc.col, 0.3)));
          tx.append(bb, L.h('small', { text: t[2] }));
          b.append(tileCanvas('c', id, 44), tx);
          if (!('ontouchstart' in window)) b.append(L.h('kbd', { text: String(k + 1) }));
          b.onclick = () => choose(k);
          cards.append(b);
        });
        const rf = (o[1] | 0) / 10;
        const sk = L.h('button', { class: 'sw-skip', type: 'button' }, T_('건너뛰기'), L.h('small', { text: ' · 경험치 ' + (rf >= 10 ? Math.round(rf) : rf.toFixed(1)) + ' 돌려받기' + (R.np > 1 ? ' (' + R.np + '명 → ÷' + R.np + ')' : '') }));
        if (!('ontouchstart' in window)) sk.append(L.h('kbd', { text: 'X' }));
        sk.onclick = () => choose(-1);
        cards.append(sk);
        cards.hidden = false; cards.classList.remove('in'); void cards.offsetWidth; cards.classList.add('in'); cardAt = performance.now();
        api.sfx('pop');
      }
      const tb = cards.querySelector('.sw-tbar i');
      if (tb && p) { const left = host() ? Math.max(0, 1 - (W.pl[me()].offT || 0) / 12) : 1; tb.style.width = Math.round(left * 100) + '%'; }
    }

    /* ---------- relic chest (pick 1 of 3 or skip) ---------- */
    let relSig = '', relSent = -1, relIdx = 0, relAt = 0;
    // [q, big, ids...]
    function myRelic() {
      const m = me(); if (m < 0) return null;
      if (host()) { const p = W && W.pl[m]; return p && p.ro ? [p.ro.q, p.ro.b].concat(p.ro.c) : null; }
      const o = Gw && Gw.roff && Gw.roff[m]; return Array.isArray(o) && o.length >= 3 ? o : null;
    }
    function chooseRelic(idx) {
      const o = myRelic(); if (!o) return;
      if (performance.now() - relAt < 400) return;
      if (idx >= o.length - 2) return;
      api.sfx(idx < 0 ? 'tick' : 'chip'); api.buzz(idx < 0 ? 10 : 24);
      if (host()) pickRelic(W, W.pl[me()], idx);
      else { relSent = o[0]; relIdx = idx; if (idx >= 0) showGot('r', o[2 + idx]); }
      relP.hidden = true; relSig = '';
    }
    function syncRelic() {
      const o = phase === 'play' ? myRelic() : null;
      if (!o || (!host() && relSent === o[0])) { if (!relP.hidden) { relP.hidden = true; relSig = ''; } return; }
      const sig = o.join(','), R = RW();
      if (sig !== relSig) {
        relSig = sig;
        relP.textContent = '';
        relP.append(L.h('h3', { text: o[1] ? '보스 유물 상자!' : '유물 상자!' }),
          L.h('div', { class: 'sub', text: (o[1] ? '모두 하나씩 골라요 · ' : '') + '3개 중 1개를 고르거나 건너뛰어요' + (R.solo ? ' · 잠깐 멈춤' : '') }));
        if (!R.solo) { const tb = L.h('div', { class: 'sw-tbar' }); tb.append(L.h('i')); relP.append(tb); }
        o.slice(2).forEach((id, k) => {
          const q = RE[id], rc = RAR[q.r].col;
          const b = L.h('button', { class: 'sw-card sw-rc r' + q.r, type: 'button', style: { '--c': rc, animationDelay: (k * 0.07) + 's' } });
          const tx = L.h('div', { class: 'tx' }), bb = L.h('b', { style: { color: shade(rc, 0.2) }, text: q.nm });
          bb.append(chip(RAR[q.r].nm, rc));
          if (q.rk) bb.append(chip('위험한 거래', '#ff7a6a'));
          tx.append(bb, L.h('small', { text: q.d }));
          b.append(tileCanvas('r', id, 44), tx);
          if (!('ontouchstart' in window)) b.append(L.h('kbd', { text: String(k + 1) }));
          b.onclick = () => chooseRelic(k);
          relP.append(b);
        });
        const sk = L.h('button', { class: 'sw-skip', type: 'button' }, T_('건너뛰기'), L.h('small', { text: ' · 아무것도 안 가져요' }));
        if (!('ontouchstart' in window)) sk.append(L.h('kbd', { text: 'X' }));
        sk.onclick = () => chooseRelic(-1);
        relP.append(sk);
        relP.hidden = false; relP.classList.remove('in'); void relP.offsetWidth; relP.classList.add('in'); relAt = performance.now();
        api.sfx('roll'); api.buzz(20);
        openBag(false);
      }
      const tb = relP.querySelector('.sw-tbar i');
      if (tb) { const left = host() ? Math.max(0, 1 - (W.pl[me()].roT || 0) / 15) : 1; tb.style.width = Math.round(left * 100) + '%'; }
    }
    // "got it" popup: shows exactly what a relic / evolution does
    let gotT = 0;
    function showGot(kind, id) {
      gotEl.textContent = '';
      let title, nm, d, col;
      if (kind === 'r') { const q = RE[id]; col = RAR[q.r].col; title = '유물 획득 · ' + RAR[q.r].nm; nm = q.nm; d = q.d; }
      else { const E = EVO[id] || EVO[0]; col = evoCol(E); title = E.from >= 0 ? '2차 진화!' : '진화!'; nm = E.nm; d = E.d; }
      gotEl.style.setProperty('--c', col);
      gotEl.append(tileCanvas(kind === 'r' ? 'r' : 'c', kind === 'r' ? id : EV0 + id, 40), L.h('div', { class: 'tx' }, L.h('em', { text: title }), L.h('b', { text: nm }), L.h('small', { text: d })));
      gotEl.hidden = false; gotEl.classList.remove('in'); void gotEl.offsetWidth; gotEl.classList.add('in');
      gotT = 3.4;
    }

    /* ---------- input: floating stick + keys ---------- */
    let stick = null;
    function onDown(e) {
      if (phase !== 'play' || me() < 0) return;
      if (stick) return;
      const pt = cv.local(e);
      stick = { id: e.pointerId, ox: pt.x, oy: pt.y, x: pt.x, y: pt.y };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
    }
    function onMove(e) {
      if (!stick || e.pointerId !== stick.id) return;
      const pt = cv.local(e), R = 48;
      stick.x = pt.x; stick.y = pt.y;
      const dx = pt.x - stick.ox, dy = pt.y - stick.oy, d = hyp(dx, dy);
      if (d > R * 1.25) { stick.ox = pt.x - dx / d * R * 1.25; stick.oy = pt.y - dy / d * R * 1.25; }
    }
    function onUp(e) { if (stick && e.pointerId === stick.id) stick = null; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'dash') dashNow();
      else if (/^card[123]$/.test(id)) { const k = +id[4] - 1; if (myRelic()) chooseRelic(k); else choose(k); }
      else if (id === 'skip') { if (myRelic()) chooseRelic(-1); else choose(-1); }
      else if (id === 'bag' && phase === 'play' && me() >= 0) openBag(!bagOpen);
    }) : null;
    function readInput() {
      let mx = 0, my = 0;
      if (stick) {
        const dx = stick.x - stick.ox, dy = stick.y - stick.oy, d = hyp(dx, dy);
        if (d > 7) { const m = Math.pow(Math.min(1, (d - 7) / 30), 0.75); mx = dx / d * m; my = dy / d * m; }
      }
      if (api.input && !mx && !my) {
        mx = api.input.axis('left', 'right'); my = api.input.axis('up', 'down');
        const m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
      }
      loc.mx = mx; loc.my = my;
    }

    /* ---------- state flow ---------- */
    function startGame() {
      key = st.rid; W = null; Gw = null; acc = 0; pickSent = -1; pickBuilt = ''; cardSig = ''; cardSent = -1; relSig = ''; relSent = -1; doneSeen = false;
      closeOverlays(); gotEl.hidden = true;
      parts.n = 0; fxl.length = 0; floats.length = 0; banners.length = 0; lastFx = 0; hintI = 0; tPlay = 0;
      for (let s = 0; s < st.np; s++) { aiC[s] = { mx: 0, my: 0, d: 0 }; mem[s] = {}; }
      for (const k in remC) delete remC[k];
      phase = st.ph;
      if (phase === 'count' || phase === 'play') buildWorld();
      if (phase === 'count') cd = 3;
      layout();
    }
    function buildWorld() {
      if (host()) {
        W = newWorld(st);
        W.solo = (st.hu || []).reduce((a, v) => a + v, 0) <= 1 ? 1 : 0;
        W.hq = []; W.crit = [];
      } else Gw = guestWorld(st);
      sprites = {}; bgKey = '';
    }
    function layout() {
      const inPick = phase === 'pick';
      pick.hidden = !inPick; goB.hidden = !inPick || me() < 0; waitT.hidden = !inPick;
      if (inPick) buildPick();
      ui.hidden = inPick;
      if (phase !== 'play') { cards.hidden = true; cardSig = ''; relP.hidden = true; relSig = ''; if (bagOpen) openBag(false); }
    }
    function hostPick() {
      if (!host()) return;
      let ch = st.ch.slice(), changed = false;
      for (let s = 0; s < st.np; s++) {
        if (ch[s] >= 0) continue;
        if (isAIseat(s)) { ch[s] = Math.floor(Math.random() * CH.length); changed = true; continue; }
        if (localHuman(s)) continue;
        const o = remote()[s];
        if (o && o.k === key && fin(o.ch) && o.ch >= 0 && o.ch < CH.length) { ch[s] = o.ch | 0; changed = true; }
      }
      pickT += 1 / 60;
      if (pickT > 60) for (let s = 0; s < st.np; s++) if (ch[s] < 0) { ch[s] = 0; changed = true; }
      const all = ch.every((v) => v >= 0);
      if (changed || all) api.setState(Object.assign({}, st, { ch, ph: all ? 'count' : 'pick' }));
    }
    let pickT = 0, remCache = null, remAt = 0;
    function remote() {
      const t = performance.now();
      if (remCache && t - remAt < 30) return remCache;
      let r = null; try { r = api.net.remote(); } catch (e) { r = null; }
      remCache = r && typeof r === 'object' ? r : {}; remAt = t;
      return remCache;
    }
    function viewers() { const o = []; for (let s = 0; s < st.np; s++) if (!localHuman(s) && !P(s).ai) o.push(s); return o; }
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      const rem = remote();
      for (const kk in rem) {
        const s = +kk, o = rem[kk];
        if (!(s >= 0 && s < W.pl.length) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remC[s] || (remC[s] = { mx: 0, my: 0, d: 0 });
        R.mx = clamp(+o.mx || 0, -1, 1); R.my = clamp(+o.my || 0, -1, 1); R.d = o.d | 0;
        if (fin(o.x) && fin(o.y)) { R.px = clamp(o.x, 0, WS); R.py = clamp(o.y, 0, WS); }
        const p = W.pl[s];
        if (Array.isArray(o.rk) && p.ro && o.rk[0] === p.ro.q) pickRelic(W, p, o.rk[1] | 0);
        if (Array.isArray(o.pk) && p.off && o.pk[0] === p.off.q) pickCard(W, p, o.pk[1] | 0);
      }
    }
    let pubT = 0, hsQ = 0, lastQ = -1;
    function publish(rdt) {
      if (!api.online || !st) return;
      pubT -= rdt;
      if (pubT > 0) return;
      pubT = 1 / 20;
      try {
        if (api.isHost) {
          if (!W || phase !== 'play') return;
          const v = viewers(); if (!v.length) return;
          hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(encodeWorld(W, key, hsQ, v));
        } else {
          const m = me(); if (m < 0) return;
          const o = { k: key, mx: r1(loc.mx), my: r1(loc.my), d: loc.d };
          if (st.ph === 'pick' && pickSent >= 0) o.ch = pickSent;
          if (Gw && Gw.pl[m]) { o.x = r1(Gw.pl[m].x); o.y = r1(Gw.pl[m].y); }
          if (cardSent >= 0) o.pk = [cardSent, cardIdx];
          if (relSent >= 0) o.rk = [relSent, relIdx];
          api.net.publish(o);
        }
      } catch (e) {}
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !Gw) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ) return;
      lastQ = hs.q;
      applySnap(Gw, hs, now, me(), (x, y, t, el) => puff(x, y, t, el));
      for (const e of decFx(hs.F)) if (e[0] > lastFx) { lastFx = e[0]; onFx(e); }
      if (!myOffer()) cardSent = -1;
      if (!myRelic()) relSent = -1;
    }
    function controls() {
      C.length = st.np;
      for (let s = 0; s < st.np; s++) {
        if (isAIseat(s)) C[s] = aiC[s];
        else if (localHuman(s)) C[s] = loc;
        else C[s] = remC[s] || (remC[s] = { mx: 0, my: 0, d: 0 });
      }
    }
    let doneSeen = false, tPlay = 0;
    function frame(rdt, now) {
      if (!st) return;
      if (st.rid !== key) startGame();
      const dt = Math.min(0.25, rdt) * SPD();
      if (phase === 'pick') { if (host()) hostPick(); publish(rdt); return; }
      if (phase === 'count') {
        if (!W && !Gw) buildWorld();
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0) api.sfx('tick');
        if (cd <= 0 && host()) { phase = 'play'; api.sfx('pop'); api.buzz(16); api.setState(Object.assign({}, st, { ph: 'play' })); layout(); }
      }
      if (phase === 'play') {
        tPlay += dt;
        readInput();
        if (host()) {
          pollHost();
          controls();
          const m = me();
          W.paused = W.solo && m >= 0 && (W.pl[m].off || W.pl[m].ro || bagOpen || codexOpen) ? 1 : 0;
          acc += dt;
          let n = 0;
          while (acc >= H && n < 14) {
            for (let s = 0; s < st.np; s++) if (isAIseat(s)) aiThink(W, s, mem[s], P(s).ai ? lvOf(s) : 2, H, aiC[s]);
            stepWorld(W, C, H);
            acc -= H; n++;
          }
          if (n >= 14) acc = 0;
          // events for the host view
          for (const e of W.fx) if (e[0] > lastFx) { lastFx = e[0]; onFx(e); }
          for (let k = 0; k < W.dq.length; k += 4) puff(W.dq[k], W.dq[k + 1], W.dq[k + 2], W.dq[k + 3]);
          W.dq.length = 0;
          sparkN = 0;
          for (let k = 0; k < W.hq.length; k += 3) { const wi = W.hq[k + 2]; spark(W.hq[k], W.hq[k + 1], wi >= 0 && WP[wi] ? WP[wi].col : '#ffffff'); }
          W.hq.length = 0;
          for (let k = 0; k < W.crit.length; k += 4) if (W.crit[k + 3] === m || k < 12) { const f = { x: W.crit[k] + (Math.random() - 0.5) * 8, y: W.crit[k + 1] - 10, text: String(Math.round(W.crit[k + 2])), col: W.crit[k + 3] === m ? '#ffe07a' : '#e6dcef', t: 0, life: 0.6, crit: 1 }; if (floats.length < 28) floats.push(f); }
          W.crit.length = 0;
          if (W.over && st.ph === 'play') { phase = 'done'; api.setState(finish(st, W)); layout(); }
        } else {
          pollGuest(now);
          guestPredict(dt, now);
        }
      }
      publish(rdt);
    }
    function guestPredict(dt, now) {
      const G = Gw; if (!G) return;
      G.Tl += dt;
      if (Math.abs(G.Tl - G.T) > 0.6) G.Tl = G.T;
      const k = 1 - Math.exp(-dt * 14);
      for (let i = 0; i < G.hiE; i++) {
        if (!G.eal[i]) continue;
        const age = Math.min(0.16, (now - G.ut[i]) / 1000);
        G.ex[i] += (G.tx[i] + G.vx[i] * age - G.ex[i]) * k; G.ey[i] += (G.ty[i] + G.vy[i] * age - G.ey[i]) * k;
      }
      const m = me();
      G.pl.forEach((p, s) => {
        if (s === m && !p.dn && !p.rt) {
          if (p.dc > 0) p.dc -= dt;
          if (p.dt > 0) p.dt -= dt;
          movePlayer(G, p, loc.mx, loc.my, dt);
          if (hyp(p.tx - p.x, p.ty - p.y) > 140) { p.x = p.tx; p.y = p.ty; }
        } else {
          p.x += (p.tx - p.x) * k; p.y += (p.ty - p.y) * k;
          if (hyp(p.tx - p.x, p.ty - p.y) > 120) { p.x = p.tx; p.y = p.ty; }
        }
      });
    }

    /* ---------- effects (pooled, capped) ---------- */
    const MAXPART = 520;
    const parts = { n: 0, x: new Float32Array(MAXPART), y: new Float32Array(MAXPART), vx: new Float32Array(MAXPART), vy: new Float32Array(MAXPART),
      t: new Float32Array(MAXPART), life: new Float32Array(MAXPART), s: new Float32Array(MAXPART), k: new Uint8Array(MAXPART), g: new Float32Array(MAXPART), c: [] };
    // k: 0 square chip, 1 streak (spark), 2 soft glow dot. g = gravity
    function part(x, y, vx, vy, life, s, col, k, g) {
      let i = parts.n;
      if (i >= MAXPART) i = Math.floor(Math.random() * MAXPART); else parts.n++;
      parts.x[i] = x; parts.y[i] = y; parts.vx[i] = vx; parts.vy[i] = vy; parts.t[i] = 0; parts.life[i] = life; parts.s[i] = s; parts.c[i] = col; parts.k[i] = k | 0; parts.g[i] = g || 0;
    }
    function burst(x, y, col, n, sp, life, s, k, g) { for (let q = 0; q < n; q++) { const a = Math.random() * TAU, v = sp * (0.4 + Math.random() * 0.8); part(x, y, Math.cos(a) * v, Math.sin(a) * v, life * (0.6 + Math.random() * 0.6), s, col, k, g); } }
    const nearCam = (x, y, m) => Math.abs(x - camC.x) < (m || 460) && Math.abs(y - camC.y) < (m || 460) + 100;
    function puff(x, y, t, big) {
      if (!nearCam(x, y)) return;
      const T = ET[t] || ET[0];
      if (big) { burst(x, y, T[7], 14, 120, 0.6, 3.5); burst(x, y, '#fff3c8', 10, 200, 0.35, 2, 1); fxl.push({ k: 30, x, y, r: 30, t: 0, life: 0.4, col: '#ffd36a' }); }
      else { burst(x, y, T[7], 4, 70, 0.35, 2.6); if (Math.random() < 0.35) burst(x, y, '#ffffff', 2, 110, 0.18, 1.6, 1); }
    }
    let sparkN = 0;
    function spark(x, y, col) {
      if (sparkN > 26 || !nearCam(x, y, 420)) return;
      sparkN++;
      for (let q = 0; q < 2; q++) { const a = Math.random() * TAU, v = 140 + Math.random() * 120; part(x, y, Math.cos(a) * v, Math.sin(a) * v, 0.16 + Math.random() * 0.08, 1.6, col, 1); }
    }
    const fxl = [], floats = [], banners = [];
    let hurtV = 0, lvlV = 0, lastHp = -1, flashV = 0, flashC = '#ffd36a';
    let lastFx = 0, sndT = {};
    function snd(n, gap) { const t = performance.now(); if (t - (sndT[n] || 0) < (gap || 80)) return; sndT[n] = t; api.sfx(n); }
    function banner(text, col, life) { banners.push({ text, col: col || '#e3ae45', t: 0, life: life || 2.4 }); if (banners.length > 3) banners.shift(); }
    function flo(x, y, text, col, life, big) { floats.push({ x, y, text, col, t: 0, life: life || 1.2, big: !!big }); if (floats.length > 28) floats.shift(); }
    function addFx(o) { fxl.push(o); if (fxl.length > 90) fxl.splice(0, fxl.length - 90); }
    function flash(col, v) { flashC = col; flashV = Math.max(flashV, v); }
    function onFx(e) {
      const k = e[1], x = e[2], y = e[3], a = e[4], b = e[5], m = me(), R = RW();
      switch (k) {
        case 0: {
          if (!nearCam(x, y, 520)) break;
          const col = b === 2 ? '#ffb070' : b === 3 ? '#ffd36a' : b === 4 ? '#b06aff' : b === 5 ? '#8fb6ff' : b === 6 ? '#b8a8ff' : '#ff8a4a';
          addFx({ k: 0, x, y, r: a, b, col, t: 0, life: b === 4 ? 0.5 : 0.35 });
          burst(x, y, col, b === 3 || b === 4 ? 16 : 6, a * 2.2, 0.4, 2.6);
          burst(x, y, '#fff3c8', b === 4 ? 10 : 4, a * 3, 0.22, 1.8, 1);
          if (b === 4) { shake = Math.max(shake, 0.12); snd('thud', 300); } else snd('hit', 90);
          break;
        }
        case 1: if (nearCam(x, y, 520)) { addFx({ k: 1, x, y, t: 0, life: 0.25, seed: Math.random() * 1000 }); burst(x, y, '#e8dcff', 4, 120, 0.2, 1.8, 1); } snd('tick', 90); break;
        case 2: addFx({ k: 2, x, y, a, b, t: 0, life: 0.22 }); break;
        case 3:
          if (R) for (const p of R.pl) if (!p.dn) { addFx({ k: 3, x: p.x, y: p.y, t: 0, life: 0.9 }); burst(p.x, p.y, '#ffd36a', 16, 120, 0.7, 3, 2, -60); }
          lvlV = 1.1; snd('chip', 200); if (m >= 0) api.buzz(10);
          break;
        case 4: {   // relic obtained (a = seat, b = relic id)
          const q = RE[b] || RE[0], col = RAR[q.r].col;
          addFx({ k: 31, x, y, col, t: 0, life: 1.1 });
          burst(x, y, col, 18 + q.r * 8, 150, 0.9, 3, 2, -40); burst(x, y, '#ffffff', 8, 220, 0.4, 2, 1);
          flo(x, y - 24, (a === m ? '' : name(a) + ': ') + q.nm, shade(col, 0.2), 2.2, true);
          if (a === m) { if (host()) showGot('r', b); if (q.r >= 3) flash(col, 0.5); api.buzz(q.r >= 2 ? 40 : 20); }
          snd(q.r >= 3 ? 'win' : 'chip', 200);
          break;
        }
        case 5:
          burst(x, y, '#ff5a4a', 20, 140, 0.7, 3); burst(x, y, '#2a1020', 10, 80, 0.9, 4);
          addFx({ k: 30, x, y, r: 46, t: 0, life: 0.6, col: '#ff5a4a' });
          if (a === m) { api.buzz(60); shake = 0.35; flash('#ff3030', 0.45); } else banner(name(a) + ' 쓰러짐! 옆에 3초 서 있으면 살려요', '#ff8a7a', 3);
          snd('thud', 150);
          break;
        case 6: banner(name(a) + ' 부활!', '#8af0b0'); burst(x, y, '#8af0b0', 20, 110, 0.8, 3, 2, -50); addFx({ k: 30, x, y, r: 50, t: 0, life: 0.6, col: '#8af0b0' }); snd('pop', 150); break;
        case 7:
          banner((b ? '마지막 보스: ' : '보스 등장: ') + ET[(R && R.S && R.S.boss) || 30][0] + '!', '#ff8a6a', 3);
          addFx({ k: 32, x, y, t: 0, life: 1.4 }); flash('#ff3030', 0.35);
          snd('bounce', 200); api.buzz(50); shake = 0.45;
          break;
        case 8: banner('강한 적 등장! 가끔 유물 상자를 떨어뜨려요', '#ffd36a', 2.2); addFx({ k: 30, x, y, r: 40, t: 0, life: 0.7, col: '#ffd36a' }); break;
        case 9:
          banner('보스 처치! 유물 상자가 떨어졌어요 — 모두 하나씩!', '#ffd36a', 3);
          burst(x, y, '#ffd36a', 44, 240, 1.1, 4, 2, -30); burst(x, y, '#ffffff', 20, 320, 0.5, 2, 1);
          addFx({ k: 31, x, y, col: '#ffd36a', t: 0, life: 1.4 }); flash('#ffd36a', 0.4);
          snd('win', 300); shake = 0.35;
          break;
        case 10: {
          const ang = b / 100;
          addFx({ k: 10, x, y, a, ang, t: 0, life: a === 2 ? 0.8 : a === 0 ? 0.7 : a === 4 ? 0.5 : a === 7 ? 0.45 : 0.55 });
          if (a === 6) burst(x, y, '#5a3a7a', 18, 120, 0.6, 3);
          if (a === 2 || a === 0) snd('whoosh', 250);
          break;
        }
        case 11: {
          const wpn = EVO[b];
          flo(x, y - 24, '✨ 진화! ' + (wpn ? wpn.nm : ''), wpn ? evoCol(wpn) : '#ffd36a', 2.4, true);
          addFx({ k: 33, x, y, t: 0, life: 1.2 });
          burst(x, y, '#fff3b0', 30, 160, 1, 3, 2, -40); burst(x, y, '#ffd36a', 14, 260, 0.5, 2, 1);
          if (a === m) { showGot('e', b); flash('#ffe8a0', 0.55); api.buzz(40); }
          snd('win', 300);
          break;
        }
        case 12: flo(x, y - 12, '+' + Math.round(30 * (R && R.pl[a] && R.pl[a].S ? R.pl[a].S.fd : 1)), '#8af0b0'); burst(x, y, '#8af0b0', 8, 60, 0.5, 2.4, 2, -40); snd('pop', 100); break;
        case 13: banner('자석! 보석이 모두 날아와요', '#ff9a9a', 1.8); snd('whoosh', 200); break;
        case 14: banner('시간 멈춤! 적이 4초 동안 얼어요', '#a8e6ff', 1.8); flash('#a8e6ff', 0.25); snd('whoosh', 200); break;
        case 15: banner('밀물이 들어와요! ' + (a < 0 ? '오른쪽' : '왼쪽') + '으로 피해요', '#8fd0ff', 2.6); break;
        case 16: addFx({ k: 16, x, y, r: a, b, t: 0, life: 0.5 }); burst(x, y, ['#3a2a3a', '#e8f6ff', '#ff7a3a', '#f0f0f0', '#fff6a0', '#ff8a5a'][b] || '#fff', 10, 90, 0.5, 3); if (b >= 4) { snd('hit', 120); shake = Math.max(shake, 0.12); } break;
        case 17: {
          const evs = { 1: '모래 폭풍이 와요! 곧 바람에 밀려요', 2: '곧 불이 꺼져요! 친구 곁에 붙어요', 10: '보급 상자! 유물 상자·고기·자석이 떨어졌어요', 11: '강한 적 무리가 몰려와요!', 12: '보석 비! 얼른 주워요', 13: '포위! 적이 동그랗게 둘러쌌어요 · 대시로 빠져나가요' };
          banner(evs[a] || '', a >= 10 ? '#ffd36a' : '#ffb98a', 2.8); snd('bounce', 300); if (a === 10) burst(x, y, '#ffd36a', 20, 120, 0.8, 3); break;
        }
        case 18: addFx({ k: 18, x, y, a: a / 100, r: b % 1000, e: b >= 1000, t: 0, life: 0.3 }); break;
        case 19: if (nearCam(x, y, 520)) { addFx({ k: 19, x, y, r: a, e: b, t: 0, life: 0.28 }); snd('whoosh', 160); } break;
        case 20: if (nearCam(x, y, 600)) { addFx({ k: 20, x, y, x2: a, y2: b, t: 0, life: 0.22, seed: Math.random() * 1000 }); burst(a, b, '#cfe8ff', 2, 120, 0.15, 1.6, 1); } snd('tick', 70); break;
        case 21: {
          const t = { 1: ['수호 천사!', '#fff3b0'], 2: ['불사조 부활!', '#ffb050'], 3: ['치유 종 +15', '#8af0b0'], 4: ['현자의 돌: 무기 +1', '#c58aff'] }[b] || ['', '#fff'];
          flo(x, y - 26, t[0], t[1], 1.8, b <= 2);
          addFx({ k: 30, x, y, r: b === 3 ? 150 : 60, t: 0, life: 0.7, col: t[1] });
          burst(x, y, t[1], b <= 2 ? 26 : 10, 140, 0.8, 3, 2, -40);
          if (b <= 2 && a === m) flash(t[1], 0.45);
          snd(b <= 2 ? 'win' : 'pop', 200);
          break;
        }
        case 22: {
          addFx({ k: 31, x, y, col: b ? '#ffd36a' : '#c58aff', t: 0, life: 1 });
          burst(x, y, b ? '#ffd36a' : '#c58aff', b ? 30 : 18, 160, 0.9, 3, 2, -50);
          if (b) banner('유물 상자! 모두 하나씩 골라요', '#ffd36a', 2.4);
          else if (a !== m) flo(x, y - 18, name(a) + ' 유물 상자', '#e6d0ff', 1.6);
          snd('roll', 200);
          break;
        }
        case 23: flo(x, y - 20, '건너뜀 · 경험치 +' + (b / 10 >= 10 ? Math.round(b / 10) : (b / 10).toFixed(1)), '#8fd0ff', 1.6); break;
        case 24: if (a === m) flo(x, y - 20, '유물 건너뜀', '#cfc3dc', 1.2); break;
      }
    }

    /* ---------- sprites ---------- */
    let sprites = {}, bgKey = '', bgTile = null, scale = 1;
    function sprite(key, size, draw) {
      let s = sprites[key];
      if (s) return s;
      const d = cv.dpr * scale, px = Math.max(4, Math.ceil(size * d));
      const c = document.createElement('canvas'); c.width = c.height = px;
      const g = c.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); g.translate(size / 2, size / 2);
      draw(g);
      sprites[key] = s = { c, size };
      return s;
    }
    function enemySprite(t, el) {
      const T = ET[t], r = T[1] * (el ? 1.55 : 1), size = r * 2.6 + 6;
      return sprite('e' + t + '_' + el, size, (g) => {
        g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(0, r * 0.85, r * 0.85, r * 0.3, 0, 0, TAU); g.fill();
        if (el || T[6] === B_BOSS) { g.fillStyle = 'rgba(255,211,106,.25)'; g.beginPath(); g.arc(0, 0, r * 1.2, 0, TAU); g.fill(); }
        g.save(); g.shadowColor = 'rgba(0,0,0,.75)'; g.shadowBlur = 2.5; drawEnemyShape(g, T[8], r, T[7]); g.restore();
        if (el) { g.strokeStyle = '#ffd36a'; g.lineWidth = 1.6; g.beginPath(); g.arc(0, 0, r * 1.12, 0, TAU); g.stroke(); }
        if (T[6] === B_BOSS) { g.fillStyle = '#ffd36a'; g.beginPath(); g.moveTo(-r * 0.5, -r * 0.95); g.lineTo(-r * 0.5, -r * 1.3); g.lineTo(-r * 0.25, -r * 1.1); g.lineTo(0, -r * 1.4); g.lineTo(r * 0.25, -r * 1.1); g.lineTo(r * 0.5, -r * 1.3); g.lineTo(r * 0.5, -r * 0.95); g.closePath(); g.fill(); }
      });
    }
    function heroSprite(ch) { return sprite('h' + ch, 34, (g) => drawHero(g, ch, 11)); }
    function gemSprite(k) {
      return sprite('g' + k, 22, (g) => {
        if (k < 4) {
          const s = 3.2 + k * 1.1; g.fillStyle = GEMC[k]; g.beginPath(); g.moveTo(0, -s * 1.3); g.lineTo(s, 0); g.lineTo(0, s * 1.3); g.lineTo(-s, 0); g.closePath(); g.fill();
          g.fillStyle = 'rgba(255,255,255,.6)'; g.beginPath(); g.moveTo(0, -s * 1.3); g.lineTo(s * 0.4, -s * 0.2); g.lineTo(-s * 0.3, -s * 0.1); g.fill();
        } else if (k === 4) { g.fillStyle = '#c86a3a'; g.beginPath(); g.ellipse(-1, -1, 6, 4.5, -0.5, 0, TAU); g.fill(); g.fillStyle = '#f2e6cc'; g.fillRect(3, 2, 4, 2.4); circ(g, 7.5, 2, 1.6, '#f2e6cc'); circ(g, 7.5, 4.6, 1.6, '#f2e6cc'); }
        else if (k === 5) { g.strokeStyle = '#ff5a5a'; g.lineWidth = 3.4; g.beginPath(); g.arc(0, 1, 5, Math.PI, 0, true); g.stroke(); g.fillStyle = '#e8e8f0'; g.fillRect(-6.7, -5, 3.4, 3); g.fillRect(3.3, -5, 3.4, 3); }
        else if (k === 6) { circ(g, 0, 0, 7, '#e8f6ff'); g.strokeStyle = '#3a6a9a'; g.lineWidth = 1.6; g.beginPath(); g.arc(0, 0, 7, 0, TAU); g.moveTo(0, 0); g.lineTo(0, -5); g.moveTo(0, 0); g.lineTo(3.5, 1); g.stroke(); }
        else {   // relic chests: 7 = purple (elite / rare), 8 = gold (boss, everyone)
          const big = k === 8, w = big ? 10 : 8.5, body = big ? '#6a3a10' : '#3a2458', trim = big ? '#ffd36a' : '#c58aff';
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, w * 0.85, w * 1.05, w * 0.3, 0, 0, TAU); g.fill();
          g.fillStyle = body; g.beginPath(); if (g.roundRect) g.roundRect(-w, -w * 0.45, w * 2, w * 1.25, 2); else g.rect(-w, -w * 0.45, w * 2, w * 1.25); g.fill();
          g.fillStyle = shade(body, 0.25); g.beginPath(); g.ellipse(0, -w * 0.45, w, w * 0.42, 0, Math.PI, 0); g.fill();
          g.fillStyle = trim; g.fillRect(-w, -w * 0.5, w * 2, w * 0.18); g.fillRect(-w * 0.18, -w * 0.85, w * 0.36, w * 1.65);
          g.beginPath(); g.moveTo(0, -w * 0.2); g.lineTo(w * 0.28, w * 0.1); g.lineTo(0, w * 0.4); g.lineTo(-w * 0.28, w * 0.1); g.closePath(); g.fillStyle = '#fff3c8'; g.fill();
        }
      });
    }

    /* ---------- background ---------- */
    function buildBg(R) {
      const S = R.S, pal = S.pal, d = cv.dpr * scale, T = 192;
      bgKey = st.sg + '|' + d.toFixed(3) + '|' + st.seed;
      const c = document.createElement('canvas'); c.width = c.height = Math.ceil(T * d);
      const g = c.getContext('2d'); g.setTransform(c.width / T, 0, 0, c.width / T, 0, 0);
      g.fillStyle = pal[0]; g.fillRect(0, 0, T, T);
      const rnd = mkRng(st.sg * 977 + 13);
      for (let k = 0; k < 120; k++) { g.fillStyle = k % 3 ? hexA(pal[1].length === 7 ? pal[1] : '#ffffff', 0.55) : hexA(pal[2], 0.35); const x = rnd() * T, y = rnd() * T, s = 1 + rnd() * 3; g.fillRect(x, y, s, s); }
      g.strokeStyle = hexA(pal[2], 0.3); g.lineWidth = 1;
      if (S.ice) for (let k = 0; k < 6; k++) { g.beginPath(); let x = rnd() * T, y = rnd() * T; g.moveTo(x, y); for (let q = 0; q < 4; q++) { x += (rnd() - 0.5) * 40; y += (rnd() - 0.5) * 40; g.lineTo(x, y); } g.stroke(); }
      if (S.conv) { g.strokeStyle = 'rgba(255,255,255,.06)'; g.strokeRect(0.5, 0.5, T / 2, T / 2); g.strokeRect(T / 2 + 0.5, T / 2 + 0.5, T / 2 - 1, T / 2 - 1); for (let k = 0; k < 8; k++) circ(g, (k % 4) * 48 + 4, Math.floor(k / 4) * 96 + 4, 1.5, 'rgba(255,255,255,.12)'); }
      if (S.lava) for (let k = 0; k < 5; k++) { g.strokeStyle = 'rgba(255,110,40,.18)'; g.beginPath(); let x = rnd() * T, y = rnd() * T; g.moveTo(x, y); for (let q = 0; q < 3; q++) { x += (rnd() - 0.5) * 50; y += (rnd() - 0.5) * 50; g.lineTo(x, y); } g.stroke(); }
      if (st.sg === 1 || st.sg === 0) for (let k = 0; k < 14; k++) { g.strokeStyle = hexA(pal[2], 0.6); g.beginPath(); const x = rnd() * T, y = rnd() * T; g.moveTo(x, y); g.lineTo(x - 2, y - 5); g.moveTo(x, y); g.lineTo(x + 2, y - 4); g.stroke(); }
      if (st.sg === 5) for (let k = 0; k < 10; k++) { g.strokeStyle = 'rgba(255,240,200,.18)'; g.beginPath(); const x = rnd() * T, y = rnd() * T; g.arc(x, y, 3 + rnd() * 4, 0, Math.PI); g.stroke(); }
      bgTile = c;
    }
    function drawObstacle(c, o, kind, col) {
      const r = o.r;
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(o.x + 3, o.y + r * 0.45, r * 0.95, r * 0.5, 0, 0, TAU); c.fill();
      switch (kind) {
        case 'tomb': { c.fillStyle = col; c.beginPath(); c.moveTo(o.x - r * 0.7, o.y + r * 0.6); c.lineTo(o.x - r * 0.7, o.y - r * 0.3); c.arc(o.x, o.y - r * 0.3, r * 0.7, Math.PI, 0); c.lineTo(o.x + r * 0.7, o.y + r * 0.6); c.closePath(); c.fill(); c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(o.x - r * 0.08, o.y - r * 0.5, r * 0.16, r * 0.6); c.fillRect(o.x - r * 0.3, o.y - r * 0.3, r * 0.6, r * 0.14); break; }
        case 'tree': circ(c, o.x, o.y, r, '#2c4a22'); circ(c, o.x - r * 0.3, o.y - r * 0.3, r * 0.65, '#3a6a2c'); circ(c, o.x + r * 0.35, o.y - r * 0.1, r * 0.5, '#447a32'); break;
        case 'crystal': c.fillStyle = col; c.beginPath(); c.moveTo(o.x, o.y - r * 1.2); c.lineTo(o.x + r * 0.7, o.y); c.lineTo(o.x, o.y + r * 0.7); c.lineTo(o.x - r * 0.7, o.y); c.closePath(); c.fill(); c.fillStyle = 'rgba(255,255,255,.4)'; c.beginPath(); c.moveTo(o.x, o.y - r * 1.2); c.lineTo(o.x + r * 0.2, o.y); c.lineTo(o.x - r * 0.35, o.y); c.fill(); break;
        case 'rock': circ(c, o.x, o.y, r, col); circ(c, o.x - r * 0.25, o.y - r * 0.3, r * 0.55, shade(col, 0.15)); break;
        case 'crate': c.fillStyle = col; c.fillRect(o.x - r * 0.8, o.y - r * 0.8, r * 1.6, r * 1.6); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 2; c.strokeRect(o.x - r * 0.8, o.y - r * 0.8, r * 1.6, r * 1.6); c.beginPath(); c.moveTo(o.x - r * 0.8, o.y - r * 0.8); c.lineTo(o.x + r * 0.8, o.y + r * 0.8); c.stroke(); break;
        case 'cactus': c.fillStyle = col; c.fillRect(o.x - r * 0.25, o.y - r, r * 0.5, r * 1.6); c.fillRect(o.x - r * 0.75, o.y - r * 0.5, r * 0.22, r * 0.6); c.fillRect(o.x - r * 0.75, o.y + r * 0.05, r * 0.6, r * 0.2); c.fillRect(o.x + r * 0.5, o.y - r * 0.7, r * 0.22, r * 0.55); c.fillRect(o.x + r * 0.15, o.y - r * 0.2, r * 0.55, r * 0.2); break;
        case 'furniture': c.fillStyle = col; c.fillRect(o.x - r * 0.8, o.y - r * 0.9, r * 1.6, r * 1.6); c.fillStyle = shade(col, -0.35); c.fillRect(o.x - r * 0.65, o.y - r * 0.75, r * 0.6, r * 1.3); c.fillRect(o.x + r * 0.05, o.y - r * 0.75, r * 0.6, r * 1.3); circ(c, o.x - r * 0.12, o.y - r * 0.1, r * 0.07, '#e3ae45'); circ(c, o.x + r * 0.12, o.y - r * 0.1, r * 0.07, '#e3ae45'); break;
        case 'cloud': circ(c, o.x - r * 0.45, o.y + r * 0.1, r * 0.55, col); circ(c, o.x + r * 0.45, o.y + r * 0.1, r * 0.55, col); circ(c, o.x, o.y - r * 0.25, r * 0.7, '#ffffff'); break;
        case 'palm': circ(c, o.x, o.y, r * 0.35, '#8a6a3a'); c.fillStyle = col; for (let k = 0; k < 5; k++) { const a = k * TAU / 5 + o.v; c.beginPath(); c.ellipse(o.x + Math.cos(a) * r * 0.6, o.y + Math.sin(a) * r * 0.6, r * 0.6, r * 0.22, a, 0, TAU); c.fill(); } break;
      }
    }

    /* ---------- drawing ---------- */
    let shake = 0;
    const camC = { x: WS / 2, y: WS / 2 };
    function camSeat(R) {
      const m = me();
      if (m >= 0) return m;
      for (let s = 0; s < R.pl.length; s++) if (!R.pl[s].dn) return s;
      return 0;
    }
    function drawProj(c, k, x, y, a, r, T) {
      switch (k) {
        case K.BOLT: case K.BOLTE: { const L2 = k === K.BOLTE ? 13 : 10; c.strokeStyle = k === K.BOLTE ? '#ffd36a' : '#ffe08a'; c.lineWidth = k === K.BOLTE ? 3.4 : 2.6; c.beginPath(); c.moveTo(x - Math.cos(a) * L2, y - Math.sin(a) * L2); c.lineTo(x, y); c.stroke(); circ(c, x, y, 1.8, '#fff'); break; }
        case K.BOOM: case K.BOOME: { const s = k === K.BOOME ? 1.4 : 1, rot = T * 16; c.save(); c.translate(x, y); c.rotate(rot); c.strokeStyle = k === K.BOOME ? '#ffe08a' : '#d8a35a'; c.lineWidth = 3.4 * s; c.beginPath(); c.moveTo(-8 * s, -3 * s); c.lineTo(0, 4 * s); c.lineTo(8 * s, -3 * s); c.stroke(); c.restore(); break; }
        case K.FROST: case K.FROSTE: { const s = k === K.FROSTE ? 6 : 4.5; c.fillStyle = '#c8f0ff'; c.save(); c.translate(x, y); c.rotate(a); c.beginPath(); c.moveTo(s * 1.6, 0); c.lineTo(0, s * 0.6); c.lineTo(-s, 0); c.lineTo(0, -s * 0.6); c.closePath(); c.fill(); c.restore(); break; }
        case K.BOMB: { circ(c, x, y + 6, 4, 'rgba(0,0,0,.3)'); const hgt = Math.min(24, r * 2.5); circ(c, x, y - hgt * 0.4, 5.5, '#3a2a3a'); circ(c, x + 3, y - hgt * 0.4 - 5, 2, (T * 10 | 0) % 2 ? '#ffd36a' : '#ff6a3a'); break; }
        case K.WISP: case K.WISPE: circ(c, x, y, 7, 'rgba(255,243,138,.25)'); circ(c, x, y, 3.2, k === K.WISPE ? '#fff' : '#fff38a'); break;
        case K.BNC: case K.BNCE: circ(c, x, y, k === K.BNCE ? 7 : 6, k === K.BNCE ? '#b0fff0' : '#7fe3d0'); circ(c, x - 2, y - 2, 2, '#fff'); break;
        case K.DRB: circ(c, x, y, 2.4, '#e8eef4'); break;
        case K.EB: circ(c, x, y, 6.5, 'rgba(255,60,140,.35)'); circ(c, x, y, 4.2, '#ff4a9a'); circ(c, x, y, 1.8, '#fff'); break;
        case K.BB: circ(c, x, y, 10, 'rgba(200,40,90,.35)'); circ(c, x, y, 7, '#e0306a'); circ(c, x, y, 2.6, '#ffd0e0'); break;
        case K.PUD: case K.PUDE: { c.fillStyle = k === K.PUDE ? 'rgba(120,240,170,.32)' : 'rgba(150,220,70,.3)'; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); c.strokeStyle = k === K.PUDE ? 'rgba(160,255,200,.6)' : 'rgba(170,230,90,.55)'; c.lineWidth = 2; c.stroke(); const b = (T * 3) % 1; circ(c, x + r * 0.3, y - r * 0.2, 2 + b * 2, 'rgba(220,255,160,' + (0.6 - b * 0.5) + ')'); break; }
        case K.MINE: { const on = (T * 3 | 0) % 2; for (let q = 0; q < 6; q++) { const aa = q * TAU / 6; c.strokeStyle = '#c9a0ff'; c.lineWidth = 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(aa) * 8, y + Math.sin(aa) * 8); c.stroke(); } circ(c, x, y, 4, on ? '#ff6a9a' : '#7a4aa0'); break; }
        case K.TORN: { c.strokeStyle = 'rgba(200,245,255,.6)'; c.lineWidth = 2; for (let q = 0; q < 4; q++) { const rr = r * (0.35 + q * 0.2); c.beginPath(); c.ellipse(x + Math.sin(T * 8 + q) * 3, y - q * r * 0.25 + r * 0.3, rr, rr * 0.35, 0, T * 6 + q, T * 6 + q + 4.5); c.stroke(); } break; }
        case K.MET: { const p2 = 0.5 + 0.5 * Math.sin(T * 14); c.strokeStyle = 'rgba(255,150,70,' + (0.4 + p2 * 0.4) + ')'; c.lineWidth = 2; c.setLineDash([6, 5]); c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke(); c.setLineDash([]); c.fillStyle = 'rgba(255,120,40,.12)'; c.fill(); break; }
        case K.WAVE: case K.WAVEE: if (r > 1) { c.strokeStyle = k === K.WAVEE ? 'rgba(255,220,140,.8)' : 'rgba(224,192,138,.7)'; c.lineWidth = k === K.WAVEE ? 6 : 4; c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke(); } break;
        case K.BEAM: case K.BEAME: { const w = k === K.BEAME ? 22 : 11; c.strokeStyle = 'rgba(255,246,200,.35)'; c.lineWidth = w * 1.8; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); c.stroke(); c.strokeStyle = '#fff6c8'; c.lineWidth = w * 0.6; c.stroke(); break; }
        case K.DBL: circ(c, x, y, 6, 'rgba(255,140,60,.5)'); break;
        case K.KNF: case K.KNFE: { c.save(); c.translate(x, y); c.rotate(a); c.fillStyle = k === K.KNFE ? '#d8c8ff' : '#b8a8e8'; c.beginPath(); c.moveTo(8, 0); c.lineTo(-3, -2.4); c.lineTo(-3, 2.4); c.closePath(); c.fill(); c.fillStyle = '#3a2a4a'; c.fillRect(-7, -1.4, 4, 2.8); c.restore(); break; }
        case K.THN: { c.save(); c.translate(x, y); c.rotate(a); c.fillStyle = '#ff8aa8'; c.beginPath(); c.moveTo(r * 1.6, 0); c.lineTo(-r, -r * 0.6); c.lineTo(-r, r * 0.6); c.closePath(); c.fill(); c.restore(); break; }
        case K.FIRE: { circ(c, x, y, r * 1.2, 'rgba(255,120,40,.3)'); circ(c, x, y, r * 0.7, 'rgba(255,200,90,.85)'); break; }
        case K.AXE: { c.save(); c.translate(x, y); c.rotate(T * 14); const q = r / 9; c.fillStyle = '#7a5a3a'; c.fillRect(-1.5 * q, -9 * q, 3 * q, 18 * q); c.fillStyle = '#d8dce4'; c.beginPath(); c.moveTo(1.5 * q, -9 * q); c.quadraticCurveTo(10 * q, -8 * q, 9 * q, 1 * q); c.lineTo(1.5 * q, -2 * q); c.closePath(); c.fill(); c.restore(); break; }
        case K.SPR: { c.save(); c.translate(x, y); c.rotate(a); c.strokeStyle = 'rgba(168,240,255,.4)'; c.lineWidth = r * 1.4; c.beginPath(); c.moveTo(-r * 3, 0); c.lineTo(r, 0); c.stroke(); c.fillStyle = '#c8f6ff'; c.beginPath(); c.moveTo(r * 2.2, 0); c.lineTo(-r * 0.5, -r * 0.7); c.lineTo(-r * 3, 0); c.lineTo(-r * 0.5, r * 0.7); c.closePath(); c.fill(); c.restore(); break; }
        case K.TUR: case K.TURE: {
          const ev = k === K.TURE;
          c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(x, y + 7, 12, 4.5, 0, 0, TAU); c.fill();
          c.fillStyle = ev ? '#8a6a3a' : '#5a4a3a'; c.fillRect(x - 9, y - 2, 18, 9); c.fillStyle = ev ? '#ffd36a' : '#d0b080'; c.fillRect(x - 9, y - 3, 18, 2.5);
          circ(c, x, y - 6, ev ? 7 : 6, ev ? '#c8a060' : '#9a8a70');
          c.save(); c.translate(x, y - 6); c.rotate(a); c.fillStyle = '#3a3440'; c.fillRect(0, -2, ev ? 12 : 10, 4); if (ev) c.fillRect(0, -5, 10, 2.5); c.restore();
          circ(c, x, y - 6, 2.2, (T * 4 | 0) % 2 ? '#ffd36a' : '#ff7a3a');
          const pf = (T * 1.7 + x * 0.01) % 1; circ(c, x - 4 + pf * 3, y - 14 - pf * 14, 3 + pf * 3, 'rgba(240,240,240,' + (0.35 * (1 - pf)).toFixed(2) + ')');
          break;
        }
        case K.FLW: case K.FLWE: {
          const ev = k === K.FLWE, pul = 0.5 + 0.5 * Math.sin(T * 3 + x);
          c.fillStyle = ev ? 'rgba(140,255,170,' + (0.1 + pul * 0.06).toFixed(3) + ')' : 'rgba(255,160,200,' + (0.08 + pul * 0.05).toFixed(3) + ')';
          c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
          c.strokeStyle = ev ? 'rgba(160,255,190,.55)' : 'rgba(255,170,210,.5)'; c.lineWidth = 2; c.setLineDash([4, 6]); c.lineDashOffset = -T * 10; c.stroke(); c.setLineDash([]); c.lineDashOffset = 0;
          c.strokeStyle = '#4f9a4a'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(x, y + 8); c.lineTo(x, y - 4); c.stroke();
          const s2 = ev ? 1.5 : 1;
          for (let q = 0; q < 5; q++) { const aa = q * TAU / 5 + T * 0.6; c.fillStyle = ev ? '#9affc0' : '#ff8ab8'; c.beginPath(); c.ellipse(x + Math.cos(aa) * 4.5 * s2, y - 6 + Math.sin(aa) * 4.5 * s2, 3.4 * s2, 4.8 * s2, aa + Math.PI / 2, 0, TAU); c.fill(); }
          circ(c, x, y - 6, 2.6 * s2, '#ffe07a');
          if (((T * 2 + x) % 1) < 0.5) circ(c, x + Math.sin(T * 5 + y) * r * 0.5, y - Math.cos(T * 4 + x) * r * 0.4, 1.6, '#c8ffd8');
          break;
        }
        case K.HAWK: case K.HAWKE: {
          const ev = k === K.HAWKE, s2 = ev ? 1.3 : 1, fl = Math.sin(T * 22 + x * 0.1) * 0.5;
          c.save(); c.translate(x, y); c.rotate(a);
          c.fillStyle = ev ? 'rgba(160,210,255,.25)' : 'rgba(255,220,160,.18)'; c.beginPath(); c.moveTo(-26 * s2, 0); c.lineTo(0, -6 * s2); c.lineTo(0, 6 * s2); c.closePath(); c.fill();
          c.fillStyle = ev ? '#c8d8f0' : '#a07850';
          c.beginPath(); c.moveTo(10 * s2, 0); c.quadraticCurveTo(0, -14 * s2 * (0.6 + fl), -8 * s2, -13 * s2 * (0.7 + fl)); c.lineTo(-4 * s2, 0); c.lineTo(-8 * s2, 13 * s2 * (0.7 + fl)); c.quadraticCurveTo(0, 14 * s2 * (0.6 + fl), 10 * s2, 0); c.fill();
          c.fillStyle = ev ? '#e8f0ff' : '#e8d8b8'; c.beginPath(); c.ellipse(2 * s2, 0, 7 * s2, 3.4 * s2, 0, 0, TAU); c.fill();
          circ(c, 8 * s2, 0, 2.6 * s2, '#ffd36a');
          c.restore();
          break;
        }
        case K.TORNE: { c.strokeStyle = 'rgba(200,240,255,.75)'; c.lineWidth = 2.6; for (let q = 0; q < 5; q++) { const rr = r * (0.3 + q * 0.17); c.beginPath(); c.ellipse(x + Math.sin(T * 8 + q) * 3, y - q * r * 0.2 + r * 0.3, rr, rr * 0.35, 0, T * 7 + q, T * 7 + q + 4.5); c.stroke(); } circ(c, x, y + r * 0.3, r * 0.5, 'rgba(180,230,255,.15)'); break; }
      }
    }
    let hintTxt = null, hintWarn = false, hintI = 0;
    function draw(now, rdt) {
      const w = cv.w, h = cv.h;
      ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const R = RW();
      if (!st || !R || phase === 'pick' || phase === 'wait') { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h); return; }
      const ns = clamp(hyp(w, h) / 2 / 400, 0.72, 1.5);
      if (Math.abs(ns - scale) > 0.001) { scale = ns; sprites = {}; bgKey = ''; }
      if (!bgTile || bgKey !== st.sg + '|' + (cv.dpr * scale).toFixed(3) + '|' + st.seed) buildBg(R);
      const T = host() ? R.T : R.Tl;
      const cs = camSeat(R), cp = R.pl[cs];
      if (cp) { camC.x += (cp.x - camC.x) * Math.min(1, rdt * 10); camC.y += (cp.y - camC.y) * Math.min(1, rdt * 10); if (hyp(cp.x - camC.x, cp.y - camC.y) > 300) { camC.x = cp.x; camC.y = cp.y; } }
      const vw = w / scale, vh = h / scale;
      let cx = camC.x - vw / 2, cy = camC.y - vh / 2;
      if (shake > 0) { shake -= rdt; cx += (Math.random() - 0.5) * 6 * shake * 4; cy += (Math.random() - 0.5) * 6 * shake * 4; }
      ctx.fillStyle = '#0c0a12'; ctx.fillRect(0, 0, w, h);
      ctx.setTransform(cv.dpr * scale, 0, 0, cv.dpr * scale, -cx * cv.dpr * scale, -cy * cv.dpr * scale);
      // ground tiles
      const TS = 192, x0 = Math.max(0, Math.floor(cx / TS) * TS), y0 = Math.max(0, Math.floor(cy / TS) * TS);
      for (let ty = y0; ty < Math.min(WS, cy + vh); ty += TS) for (let tx = x0; tx < Math.min(WS, cx + vw); tx += TS) ctx.drawImage(bgTile, tx, ty, TS + 0.5, TS + 0.5);
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.strokeRect(-1.5, -1.5, WS + 3, WS + 3);
      const M = R.M, inV = (x, y, r) => x + r > cx && x - r < cx + vw && y + r > cy && y - r < cy + vh;
      // static features
      for (const pl of M.pools) if (inV(pl.x, pl.y, pl.r)) {
        const gg = ctx.createRadialGradient(pl.x, pl.y, pl.r * 0.2, pl.x, pl.y, pl.r);
        gg.addColorStop(0, '#ffb04a'); gg.addColorStop(0.7, '#ff5a1a'); gg.addColorStop(1, '#5a1a0a');
        ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(pl.x, pl.y, pl.r, 0, TAU); ctx.fill();
        circ(ctx, pl.x + Math.sin(T * 2 + pl.x) * pl.r * 0.4, pl.y + Math.cos(T * 1.7 + pl.y) * pl.r * 0.3, 3 + Math.sin(T * 5) * 1.5, 'rgba(255,240,160,.7)');
      }
      for (const cvb of M.conv) if (cvb.y + cvb.h / 2 > cy && cvb.y - cvb.h / 2 < cy + vh) {
        const y1 = cvb.y - cvb.h / 2;
        ctx.fillStyle = '#1c1f24'; ctx.fillRect(Math.max(0, cx), y1, Math.min(WS, cx + vw) - Math.max(0, cx), cvb.h);
        ctx.strokeStyle = 'rgba(227,174,69,.35)'; ctx.lineWidth = 3;
        const off = ((T * 42 * cvb.d) % 40 + 40) % 40;
        for (let x = Math.floor(cx / 40) * 40 - 40 + off; x < cx + vw + 40; x += 40) { ctx.beginPath(); ctx.moveTo(x - 6 * cvb.d, y1 + 14); ctx.lineTo(x + 6 * cvb.d, cvb.y); ctx.lineTo(x - 6 * cvb.d, y1 + cvb.h - 14); ctx.stroke(); }
        ctx.fillStyle = '#e3ae45'; ctx.fillRect(Math.max(0, cx), y1, vw, 3); ctx.fillRect(Math.max(0, cx), y1 + cvb.h - 3, vw, 3);
      }
      for (const v of M.vents) if (inV(v.x, v.y, 30)) { circ(ctx, v.x, v.y, 20, '#2a2e34'); ctx.strokeStyle = '#5a6068'; ctx.lineWidth = 2; for (let q = -12; q <= 12; q += 6) { ctx.beginPath(); ctx.moveTo(v.x - 14, v.y + q); ctx.lineTo(v.x + 14, v.y + q); ctx.stroke(); } }
      // tide
      const td = R.tide;
      if (td && (td.on || Math.abs(td.x - (td.side < 0 ? 0 : WS)) > 4)) {
        const xe = td.x, xa = td.side < 0 ? 0 : xe, xb = td.side < 0 ? xe : WS;
        ctx.fillStyle = 'rgba(60,140,210,.38)'; ctx.fillRect(xa, Math.max(0, cy), xb - xa, vh);
        ctx.strokeStyle = 'rgba(220,245,255,.7)'; ctx.lineWidth = 3; ctx.beginPath();
        for (let y = Math.floor(cy / 20) * 20; y < cy + vh + 20; y += 20) ctx.lineTo(xe + Math.sin(y * 0.05 + T * 3) * 6, y);
        ctx.stroke();
      }
      if (td && td.warn > 0 && (T * 4 | 0) % 2) { ctx.fillStyle = 'rgba(120,190,255,.25)'; const ex = td.side < 0 ? 0 : WS - 820; ctx.fillRect(ex, Math.max(0, cy), 820, vh); }
      // hazards
      for (const z of R.Z) {
        if (!inV(z.x, z.y, z.r + 10)) continue;
        if (z.k === 'spore') {
          for (let q = 0; q < 5; q++) { const a = q * 1.3 + T * 0.4; circ(ctx, z.x + Math.cos(a) * z.r * 0.4, z.y + Math.sin(a) * z.r * 0.35, z.r * 0.55, 'rgba(170,110,200,.16)'); }
          ctx.strokeStyle = 'rgba(200,140,230,.4)'; ctx.lineWidth = 2; ctx.setLineDash([5, 6]); ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
          continue;
        }
        if (z.ph === 0) {
          const pp = 0.5 + 0.5 * Math.sin(T * 16);
          ctx.fillStyle = 'rgba(255,70,50,' + (0.12 + pp * 0.12) + ')'; ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.fill();
          ctx.strokeStyle = 'rgba(255,90,70,.85)'; ctx.lineWidth = 2; ctx.setLineDash([6, 4]); ctx.stroke(); ctx.setLineDash([]);
          ctx.fillStyle = '#ffd2c8'; ctx.font = '700 14px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('!', z.x, z.y);
        } else if (z.k === 'erupt') {
          const fl = 0.7 + 0.3 * Math.sin(T * 30);
          const gg = ctx.createRadialGradient(z.x, z.y, 2, z.x, z.y, z.r);
          gg.addColorStop(0, 'rgba(255,240,160,' + fl + ')'); gg.addColorStop(0.6, 'rgba(255,110,30,.75)'); gg.addColorStop(1, 'rgba(255,60,20,0)');
          ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.fill();
        } else if (z.k === 'hand') {
          ctx.fillStyle = '#3a2a3a'; for (let q = 0; q < 3; q++) { const a = q * 2.1; ctx.fillRect(z.x + Math.cos(a) * 12 - 3, z.y + Math.sin(a) * 10 - 12, 6, 14); }
        } else if (z.k === 'bolt') { ctx.strokeStyle = '#fff6a0'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(z.x + 10, z.y - 200); ctx.lineTo(z.x - 8, z.y - 90); ctx.lineTo(z.x + 6, z.y - 60); ctx.lineTo(z.x, z.y); ctx.stroke(); circ(ctx, z.x, z.y, z.r * 0.8, 'rgba(255,250,180,.45)'); }
        else if (z.k === 'slam') { circ(ctx, z.x, z.y, z.r, 'rgba(255,90,60,.4)'); }
        else if (z.k === 'steam') { for (let q = 0; q < 4; q++) circ(ctx, z.x + Math.sin(q * 2 + T * 6) * 10, z.y - q * 9, z.r * (0.4 + q * 0.1), 'rgba(240,240,240,.35)'); }
      }
      // gems & items
      const GL = gemList(R);
      for (let j = 0; j < GL.n; j++) {
        const x = GL.x[j], y = GL.y[j]; if (!inV(x, y, 12)) continue;
        const k = GL.k[j], s = gemSprite(k), bob = k >= 4 ? Math.sin(T * 4 + j) * 1.5 : 0;
        if (k >= 7) { ctx.fillStyle = 'rgba(255,211,106,' + (0.18 + 0.12 * Math.sin(T * 5)) + ')'; ctx.beginPath(); ctx.arc(x, y, 16, 0, TAU); ctx.fill(); }
        ctx.drawImage(s.c, x - s.size / 2, y - s.size / 2 + bob, s.size, s.size);
      }
      // obstacles
      const okind = R.S.ob.k, ocol = R.S.ob.col;
      for (const o of M.ob) if (inV(o.x, o.y, o.r * 1.3)) drawObstacle(ctx, o, okind, ocol);
      // ground-level projectiles (zones) first
      const PLs = projList(R, now);
      for (let q = 0; q < PLs.n; q++) { const k = PLs.k[q]; if (GROUND[k]) { if (inV(PLs.x[q], PLs.y[q], PLs.r[q] + 16)) drawProj(ctx, k, PLs.x[q], PLs.y[q], PLs.a[q], PLs.r[q], T); } }
      // auras under players
      for (const p of R.pl) {
        if (p.dn) continue;
        for (const wp of p.W) if (wp.i === 2) {
          const r = auraR(p, wp), a2 = 0.13 + 0.05 * Math.sin(T * 6);
          ctx.fillStyle = wp.e ? 'rgba(255,200,80,' + a2 + ')' : 'rgba(255,120,60,' + a2 + ')'; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill();
          ctx.strokeStyle = wp.e ? 'rgba(255,220,120,.5)' : 'rgba(255,140,80,.4)'; ctx.lineWidth = 2; ctx.stroke();
        }
      }
      // enemies
      const ex = R.ex, ey = R.ey, eal = R.eal, et = R.et, eel = R.eel, efl = R.efl, frz = R.frz > 0;
      for (let i = 0; i < R.hiE; i++) {
        if (!eal[i]) continue;
        const x = ex[i], y = ey[i]; if (!inV(x, y, 40)) continue;
        const s = enemySprite(et[i], eel[i]);
        const bob = ET[et[i]][6] === B_FLY ? Math.sin(T * 10 + i) * 2 : 0;
        ctx.drawImage(s.c, x - s.size / 2, y - s.size / 2 + bob, s.size, s.size);
        const er = ET[et[i]][1] * (eel[i] ? 1.5 : 1);
        if (efl[i] > 0) { ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.arc(x, y + bob, er, 0, TAU); ctx.fill(); }
        if (R.ebn) {   // host only: burning / frozen / slowed marks
          if (R.ebn[i] > 0) { const fl = (T * 9 + i) % 1; ctx.fillStyle = 'rgba(255,140,40,' + (0.75 - fl * 0.6).toFixed(2) + ')'; ctx.beginPath(); ctx.ellipse(x + Math.sin(i + T * 7) * er * 0.3, y - er * 0.6 - fl * er * 0.9, er * 0.32 * (1 - fl * 0.5), er * 0.5 * (1 - fl * 0.4), 0, 0, TAU); ctx.fill(); }
          if (R.efz[i] > 0) { ctx.fillStyle = 'rgba(190,235,255,.45)'; ctx.beginPath(); ctx.arc(x, y + bob, er * 1.05, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(230,250,255,.9)'; ctx.lineWidth = 1.2; ctx.stroke(); }
          else if (R.esl[i] > 0) { ctx.strokeStyle = 'rgba(150,215,255,.7)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(x, y + bob, er + 2, 0, TAU); ctx.stroke(); }
        }
      }
      if (frz) { ctx.fillStyle = 'rgba(160,220,255,.12)'; ctx.fillRect(cx, cy, vw, vh); }
      if (R.slowT > 0) { ctx.fillStyle = 'rgba(200,170,255,.07)'; ctx.fillRect(cx, cy, vw, vh); }
      if (R.wind) {
        const wa = R.wind.a, on = R.wind.on, n = on ? 40 : 10, wx = Math.cos(wa), wy = Math.sin(wa);
        ctx.strokeStyle = on ? 'rgba(240,220,170,.45)' : 'rgba(240,220,170,.2)'; ctx.lineWidth = 2;
        for (let q = 0; q < n; q++) { const sx = cx + ((q * 97 + T * 260 * wx) % vw + vw) % vw, sy = cy + ((q * 61 + T * 260 * wy) % vh + vh) % vh; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx - wx * 26, sy - wy * 26); ctx.stroke(); }
        if (on) { ctx.fillStyle = 'rgba(200,160,90,.16)'; ctx.fillRect(cx, cy, vw, vh); }
      }
      // players
      R.pl.forEach((p, s) => {
        if (!inV(p.x, p.y, 40)) return;
        const col = COL(s);
        circ(ctx, p.x, p.y + 11, 12, hexA(col, 0.35));
        if (p.dn) {
          ctx.globalAlpha = 0.55; const hs = heroSprite(p.ch); ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(Math.PI / 2); ctx.drawImage(hs.c, -hs.size / 2, -hs.size / 2, hs.size, hs.size); ctx.restore(); ctx.globalAlpha = 1;
          ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(p.x, p.y, 42, 0, TAU); ctx.stroke();
          if (p.rv > 0) { ctx.strokeStyle = '#8af0b0'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(p.x, p.y, 42, -Math.PI / 2, -Math.PI / 2 + TAU * p.rv); ctx.stroke(); }
          ctx.fillStyle = '#ffd2c8'; ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillText('살려 줘요!', p.x, p.y - 18);
          return;
        }
        const blink = (p.iv > 0 || p.dt > 0) && (T * 20 | 0) % 2;
        if (p.iv > 0 && !p.dt) { ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(p.x, p.y, 16, 0, TAU); ctx.stroke(); }
        if (p.bub || (p.off && !R.solo)) { ctx.strokeStyle = 'rgba(160,220,255,.7)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(p.x, p.y, 20, 0, TAU); ctx.stroke(); ctx.fillStyle = 'rgba(160,220,255,.12)'; ctx.fill(); }
        if (p.rt > 0) { ctx.fillStyle = '#3a2a3a'; ctx.fillRect(p.x - 9, p.y + 2, 4, 10); ctx.fillRect(p.x + 5, p.y + 2, 4, 10); }
        const hs = heroSprite(p.ch);
        ctx.globalAlpha = blink ? 0.45 : 1;
        ctx.save(); ctx.translate(p.x, p.y); if (p.fx < -0.1) ctx.scale(-1, 1);
        ctx.drawImage(hs.c, -hs.size / 2, -hs.size / 2 - 2, hs.size, hs.size); ctx.restore();
        ctx.globalAlpha = 1;
        if (p.hurtF > 0) { ctx.fillStyle = 'rgba(255,60,60,.4)'; ctx.beginPath(); ctx.arc(p.x, p.y, 12, 0, TAU); ctx.fill(); }
        // hp bar
        const f = clamp(p.hp / (p.mhp || 100), 0, 1);
        ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(p.x - 14, p.y + 15, 28, 4.5);
        ctx.fillStyle = f > 0.5 ? '#6fdc7a' : f > 0.25 ? '#ffc04a' : '#ff5a4a'; ctx.fillRect(p.x - 13.5, p.y + 15.5, 27 * f, 3.5);
        if (R.pl.length > 1) { ctx.fillStyle = col; ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText(s === me() ? '나' : name(s), p.x, p.y + 21); }
      });
      // orbit balls & drones
      for (const p of R.pl) {
        if (p.dn || !p.S) continue;
        for (const wp of p.W) {
          if (wp.i === 1) {
            const o = orbitInfo(p, wp, T); if (!o.on) continue;
            for (let k = 0; k < o.n; k++) { const a = T * o.sp + k * TAU / o.n, bx = p.x + Math.cos(a) * o.rad, by = p.y + Math.sin(a) * o.rad; circ(ctx, bx, by, o.br + 3, wp.e ? 'rgba(180,200,255,.3)' : 'rgba(143,182,255,.25)'); circ(ctx, bx, by, o.br, wp.e ? '#d8e4ff' : '#8fb6ff'); circ(ctx, bx - o.br * 0.3, by - o.br * 0.3, o.br * 0.3, '#fff'); }
          } else if (wp.i === 21) {
            const o = chainInfo(p, wp);
            for (let k = 0; k < o.n; k++) {
              const a = -T * o.sp + k * Math.PI, ex2 = p.x + Math.cos(a) * o.len, ey2 = p.y + Math.sin(a) * o.len;
              ctx.strokeStyle = 'rgba(184,200,216,.8)'; ctx.lineWidth = 2; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(ex2, ey2); ctx.stroke(); ctx.setLineDash([]);
              ctx.save(); ctx.translate(ex2, ey2); ctx.rotate(a + T * 8); ctx.fillStyle = wp.e ? '#e8f0ff' : '#c8d4e0';
              ctx.beginPath(); for (let q = 0; q < 8; q++) { const b = q * TAU / 8, rr = q % 2 ? 4 : 9; ctx.lineTo(Math.cos(b) * rr, Math.sin(b) * rr); } ctx.closePath(); ctx.fill(); ctx.restore();
            }
          } else if (wp.i === 24) {
            const o = birdInfo(p, wp);
            for (let k = 0; k < o.n; k++) {
              const a = T * o.sp + k * TAU / o.n, bx = p.x + Math.cos(a) * o.rad, by = p.y + Math.sin(a) * o.rad * 0.8, fl = Math.sin(T * 14 + k) * 0.5;
              circ(ctx, bx, by, o.br * 1.5, 'rgba(255,120,60,.18)');
              ctx.save(); ctx.translate(bx, by); ctx.rotate(a + Math.PI / 2); ctx.fillStyle = wp.e ? '#ffd36a' : '#ff7a4a';
              ctx.beginPath(); ctx.moveTo(0, -o.br); ctx.quadraticCurveTo(o.br * 1.3, -o.br * (0.2 + fl), o.br * 0.4, o.br * 0.3); ctx.lineTo(0, o.br * 1.1); ctx.lineTo(-o.br * 0.4, o.br * 0.3); ctx.quadraticCurveTo(-o.br * 1.3, -o.br * (0.2 + fl), 0, -o.br); ctx.fill();
              circ(ctx, 0, -o.br * 0.5, o.br * 0.25, '#fff3b0'); ctx.restore();
            }
          } else if (wp.i === 14) {
            const n = droneN(p, wp);
            for (let k = 0; k < n; k++) { const dp = dronePos(p, k, n, T); ctx.fillStyle = '#b8c4d0'; ctx.fillRect(dp[0] - 5, dp[1] - 3, 10, 6); ctx.fillStyle = 'rgba(220,230,240,.6)'; ctx.fillRect(dp[0] - 8, dp[1] - 6, 6, 1.5); ctx.fillRect(dp[0] + 2, dp[1] - 6, 6, 1.5); circ(ctx, dp[0], dp[1], 1.5, '#5fd3a0'); }
          }
        }
      }
      // flying projectiles
      for (let q = 0; q < PLs.n; q++) { const k = PLs.k[q]; if (!GROUND[k]) { if (inV(PLs.x[q], PLs.y[q], k === K.BEAM || k === K.BEAME ? PLs.r[q] : 26)) drawProj(ctx, k, PLs.x[q], PLs.y[q], PLs.a[q], PLs.r[q], T); } }
      // particles
      const pt = parts;
      for (let i = 0; i < pt.n; i++) {
        pt.t[i] += rdt;
        if (pt.t[i] >= pt.life[i]) { const L2 = --pt.n; if (i < L2) { pt.x[i] = pt.x[L2]; pt.y[i] = pt.y[L2]; pt.vx[i] = pt.vx[L2]; pt.vy[i] = pt.vy[L2]; pt.t[i] = pt.t[L2]; pt.life[i] = pt.life[L2]; pt.s[i] = pt.s[L2]; pt.c[i] = pt.c[L2]; pt.k[i] = pt.k[L2]; pt.g[i] = pt.g[L2]; i--; } continue; }
        const dmp = pt.k[i] === 1 ? 0.88 : 0.92;
        pt.vy[i] += pt.g[i] * rdt;
        pt.x[i] += pt.vx[i] * rdt; pt.y[i] += pt.vy[i] * rdt; pt.vx[i] *= dmp; pt.vy[i] *= dmp;
        if (!inV(pt.x[i], pt.y[i], 6)) continue;
        const al = 1 - pt.t[i] / pt.life[i], s = pt.s[i], pk = pt.k[i];
        ctx.globalAlpha = al;
        if (pk === 1) { ctx.strokeStyle = pt.c[i]; ctx.lineWidth = s; ctx.beginPath(); ctx.moveTo(pt.x[i], pt.y[i]); ctx.lineTo(pt.x[i] - pt.vx[i] * 0.05, pt.y[i] - pt.vy[i] * 0.05); ctx.stroke(); }
        else if (pk === 2) { ctx.fillStyle = pt.c[i]; ctx.globalAlpha = al * 0.35; ctx.beginPath(); ctx.arc(pt.x[i], pt.y[i], s * 1.6, 0, TAU); ctx.fill(); ctx.globalAlpha = al; ctx.fillRect(pt.x[i] - s / 2, pt.y[i] - s / 2, s, s); }
        else { ctx.fillStyle = pt.c[i]; ctx.fillRect(pt.x[i] - s / 2, pt.y[i] - s / 2, s, s); }
      }
      ctx.globalAlpha = 1;
      // effect list
      for (let i = fxl.length - 1; i >= 0; i--) {
        const f = fxl[i]; f.t += rdt; const u = f.t / f.life;
        if (u >= 1) { fxl.splice(i, 1); continue; }
        if (!inV(f.x, f.y, 300)) continue;
        ctx.globalAlpha = 1 - u;
        if (f.k === 0) {
          const rr = f.r * (0.45 + Math.sqrt(u) * 0.65);
          ctx.fillStyle = hexA(f.col, 0.42 * (1 - u)); ctx.beginPath(); ctx.arc(f.x, f.y, rr, 0, TAU); ctx.fill();
          ctx.fillStyle = 'rgba(255,250,220,' + (0.7 * (1 - u * 2.5)).toFixed(3) + ')'; if (u < 0.4) { ctx.beginPath(); ctx.arc(f.x, f.y, rr * 0.45, 0, TAU); ctx.fill(); }
          ctx.strokeStyle = f.col; ctx.lineWidth = 3 * (1 - u) + 1; ctx.beginPath(); ctx.arc(f.x, f.y, rr, 0, TAU); ctx.stroke();
        }
        else if (f.k === 1) { ctx.strokeStyle = '#efe6ff'; ctx.lineWidth = 3; ctx.beginPath(); let x = f.x + 20, y = f.y - 260; ctx.moveTo(x, y); const r2 = mkRng(f.seed | 0); for (let q = 1; q <= 7; q++) { x = f.x + (r2() - 0.5) * 30 * (1 - q / 7); y = f.y - 260 + q * 260 / 7; ctx.lineTo(x, y); } ctx.stroke(); circ(ctx, f.x, f.y, 14 * (1 - u), 'rgba(220,200,255,.6)'); }
        else if (f.k === 2) { const sd = f.a >= 0 ? 1 : -1, len = Math.abs(f.a), wd = f.b; ctx.fillStyle = 'rgba(200,245,224,.55)'; ctx.beginPath(); ctx.ellipse(f.x + sd * len / 2, f.y, len / 2, wd / 2 * (1 - u * 0.5), 0, 0, TAU); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(f.x + sd * len / 2, f.y - wd * 0.15, len / 2, wd * 0.3, 0, sd > 0 ? Math.PI : 0, sd > 0 ? TAU : Math.PI); ctx.stroke(); }
        else if (f.k === 3) {   // level up: pillar of light + ring
          const gg = ctx.createLinearGradient(f.x, f.y - 120, f.x, f.y + 10);
          gg.addColorStop(0, 'rgba(255,220,120,0)'); gg.addColorStop(1, 'rgba(255,220,120,.55)');
          ctx.fillStyle = gg; const pw = 22 * (1 - u * 0.6); ctx.fillRect(f.x - pw / 2, f.y - 120, pw, 130);
          ctx.strokeStyle = '#ffd36a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(f.x, f.y + 8, 14 + u * 40, (14 + u * 40) * 0.4, 0, 0, TAU); ctx.stroke();
        }
        else if (f.k === 10) {   // boss telegraphs
          const bx = f.x, by = f.y;
          ctx.globalAlpha = 1;
          if (f.a === 2) {        // charge lane
            const len = 380, wd = 46, pul = 0.5 + 0.5 * Math.sin(f.t * 30);
            ctx.save(); ctx.translate(bx, by); ctx.rotate(f.ang);
            ctx.fillStyle = 'rgba(255,60,50,' + (0.14 + pul * 0.12) * (1 - u * 0.5) + ')'; ctx.fillRect(0, -wd / 2, len, wd);
            ctx.fillStyle = 'rgba(255,90,70,' + (0.5 * (1 - u)).toFixed(2) + ')'; ctx.fillRect(0, -wd / 2, len * Math.min(1, u * 1.4), wd);
            ctx.strokeStyle = 'rgba(255,120,90,.85)'; ctx.lineWidth = 2; ctx.setLineDash([10, 8]); ctx.strokeRect(0, -wd / 2, len, wd); ctx.setLineDash([]);
            for (let q = 1; q <= 3; q++) { const ax = len * q / 4; ctx.beginPath(); ctx.moveTo(ax, -10); ctx.lineTo(ax + 14, 0); ctx.lineTo(ax, 10); ctx.stroke(); }
            ctx.restore();
          } else if (f.a === 0) { // ring wind-up: glow shrinking onto the boss
            ctx.strokeStyle = 'rgba(255,90,160,' + (0.4 + 0.6 * u).toFixed(2) + ')'; ctx.lineWidth = 3 + u * 4; ctx.beginPath(); ctx.arc(bx, by, 120 - u * 80, 0, TAU); ctx.stroke();
            ctx.fillStyle = 'rgba(255,90,160,' + (0.25 * u).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(bx, by, 40, 0, TAU); ctx.fill();
          } else if (f.a === 4) { // fan cone
            ctx.fillStyle = 'rgba(255,80,140,' + (0.22 * (1 - u)).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(bx, by); ctx.arc(bx, by, 300, f.ang - 0.5, f.ang + 0.5); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(255,120,170,' + (0.7 * (1 - u)).toFixed(2) + ')'; ctx.lineWidth = 2; ctx.stroke();
          } else if (f.a === 7) { ctx.strokeStyle = 'rgba(255,200,230,' + (1 - u).toFixed(2) + ')'; ctx.lineWidth = 5 * (1 - u) + 1; ctx.beginPath(); ctx.arc(bx, by, 30 + u * 90, 0, TAU); ctx.stroke(); }
          else { ctx.globalAlpha = 1 - u; ctx.strokeStyle = f.a === 6 ? '#b88aff' : f.a === 1 ? '#c86aff' : '#ff9ad0'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(bx, by, 34 + u * 50, 0, TAU); ctx.stroke(); }
        }
        else if (f.k === 19) {  // spin slash
          const r = f.r, a0 = f.t * 26;
          ctx.strokeStyle = f.e ? 'rgba(255,90,90,.8)' : 'rgba(255,220,180,.85)'; ctx.lineWidth = 7 * (1 - u) + 2;
          ctx.beginPath(); ctx.arc(f.x, f.y, r * (0.75 + u * 0.25), a0, a0 + 4.2); ctx.stroke();
          ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(f.x, f.y, r * (0.75 + u * 0.25), a0 + 3.2, a0 + 4.2); ctx.stroke();
        }
        else if (f.k === 20) {  // chain lightning segment
          ctx.strokeStyle = '#d8ecff'; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.moveTo(f.x, f.y);
          const r2 = mkRng(f.seed | 0), dx = f.x2 - f.x, dy = f.y2 - f.y;
          for (let q = 1; q < 5; q++) { const tt = q / 5; ctx.lineTo(f.x + dx * tt + (r2() - 0.5) * 18, f.y + dy * tt + (r2() - 0.5) * 18); }
          ctx.lineTo(f.x2, f.y2); ctx.stroke(); ctx.strokeStyle = 'rgba(120,180,255,.35)'; ctx.lineWidth = 7; ctx.stroke();
        }
        else if (f.k === 30) { ctx.strokeStyle = f.col; ctx.lineWidth = 4 * (1 - u) + 1; ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (0.4 + u * 0.8), 0, TAU); ctx.stroke(); }
        else if (f.k === 31) {  // beam of light (relic / chest / boss kill)
          const gg = ctx.createLinearGradient(f.x, f.y - 220, f.x, f.y);
          gg.addColorStop(0, hexA(f.col, 0)); gg.addColorStop(1, hexA(f.col, 0.6));
          ctx.fillStyle = gg; const bw = 34 * (1 - u * 0.7); ctx.fillRect(f.x - bw / 2, f.y - 220, bw, 224);
          ctx.strokeStyle = f.col; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(f.x, f.y, 18 + u * 46, 0, TAU); ctx.stroke();
        }
        else if (f.k === 32) {  // boss arrival: shock ring + dark pulse
          ctx.strokeStyle = 'rgba(255,70,60,' + (1 - u).toFixed(2) + ')'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(f.x, f.y, 40 + u * 220, 0, TAU); ctx.stroke();
          ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(f.x, f.y, 20 + u * 140, 0, TAU); ctx.stroke();
        }
        else if (f.k === 33) {  // evolution: rotating rays
          ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.t * 1.5);
          ctx.fillStyle = 'rgba(255,236,160,' + (0.45 * (1 - u)).toFixed(3) + ')';
          for (let q = 0; q < 10; q++) { ctx.rotate(TAU / 10); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(90 + u * 40, -7); ctx.lineTo(90 + u * 40, 7); ctx.closePath(); ctx.fill(); }
          ctx.restore();
          ctx.strokeStyle = '#ffd36a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(f.x, f.y, 20 + u * 60, 0, TAU); ctx.stroke();
        }
        else if (f.k === 18) { ctx.fillStyle = 'rgba(240,216,144,.35)'; ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.arc(f.x, f.y, f.r * (0.5 + u * 0.5), f.e ? 0 : f.a - 0.65, f.e ? TAU : f.a + 0.65); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#fff3c8'; ctx.lineWidth = 2; ctx.stroke(); }
        else if (f.k === 16) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (0.6 + u * 0.6), 0, TAU); ctx.stroke(); }
      }
      ctx.globalAlpha = 1;
      // floats (world)
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let i = floats.length - 1; i >= 0; i--) {
        const f = floats[i]; f.t += rdt; if (f.t > f.life) { floats.splice(i, 1); continue; }
        const pop = f.big ? 1 + Math.max(0, 0.35 - f.t) * 1.2 : 1;
        ctx.globalAlpha = Math.min(1, (f.life - f.t) * 3); ctx.font = (f.big ? '800 14px ' : f.crit ? '800 11px ' : '700 12px ') + FONT;
        ctx.save(); ctx.translate(f.x, f.y - f.t * (f.crit ? 30 : 18)); if (pop !== 1) ctx.scale(pop, pop);
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.75)'; ctx.strokeText(f.text, 0, 0); ctx.fillStyle = f.col; ctx.fillText(f.text, 0, 0);
        ctx.restore();
      }
      ctx.globalAlpha = 1;
      // screen space
      ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      if (R.dark && R.dark.on && cp) {
        const sx = (cp.x - cx) * scale, sy = (cp.y - cy) * scale, gg = ctx.createRadialGradient(sx, sy, 120 * scale, sx, sy, 230 * scale);
        gg.addColorStop(0, 'rgba(6,4,10,0)'); gg.addColorStop(1, 'rgba(6,4,10,.93)'); ctx.fillStyle = gg; ctx.fillRect(0, 0, w, h);
      } else if (R.dark && (T * 4 | 0) % 2) { ctx.fillStyle = 'rgba(6,4,10,.25)'; ctx.fillRect(0, 0, w, h); }
      drawArrows(R, cx, cy, vw, vh, w, h);
      drawDanger(R, cx, cy, w, h, T);
      const m = me(), mp = m >= 0 ? R.pl[m] : null;
      if (hurtV > 0) { hurtV -= rdt; ctx.fillStyle = 'rgba(255,40,40,' + (hurtV * 1.2).toFixed(3) + ')'; ctx.fillRect(0, 0, w, h); }
      if (flashV > 0) { flashV -= rdt; ctx.fillStyle = hexA(flashC, Math.min(0.45, flashV * 0.9)); ctx.fillRect(0, 0, w, h); }
      if (lvlV > 0) {
        lvlV -= rdt; const u = 1 - lvlV / 1.1, sc = u < 0.2 ? 0.6 + u * 2.2 : 1.04 - (u - 0.2) * 0.05;
        ctx.save(); ctx.globalAlpha = Math.min(1, lvlV * 3); ctx.translate(w / 2, h * 0.3); ctx.scale(sc, sc);
        ctx.font = '400 34px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(40,20,0,.8)'; ctx.strokeText('레벨 업!', 0, 0); ctx.fillStyle = '#ffd36a'; ctx.fillText('레벨 업!', 0, 0);
        ctx.restore();
      }
      if (mp && !mp.dn && mp.hp < mp.mhp * 0.3) { const a = 0.18 + 0.12 * Math.sin(T * 8); const gg = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.7); gg.addColorStop(0, 'rgba(255,0,0,0)'); gg.addColorStop(1, 'rgba(255,30,30,' + a + ')'); ctx.fillStyle = gg; ctx.fillRect(0, 0, w, h); }
      drawHud(R, w, h, T);
      if (stick && phase === 'play') {
        ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(stick.ox, stick.oy, 48, 0, TAU); ctx.stroke(); ctx.fillStyle = 'rgba(242,233,216,.08)'; ctx.fill();
        const dx = stick.x - stick.ox, dy = stick.y - stick.oy, d = hyp(dx, dy), mm = Math.min(d, 48);
        circ(ctx, stick.ox + (d ? dx / d * mm : 0), stick.oy + (d ? dy / d * mm : 0), 20, 'rgba(227,174,69,.75)');
      }
      if (phase === 'count') {
        ctx.fillStyle = 'rgba(10,8,16,.55)'; ctx.fillRect(0, 0, w, h);
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#e3ae45'; ctx.font = '400 26px ' + DISP; ctx.fillText(R.S.nm, w / 2, h * 0.36);
        ctx.fillStyle = '#cfc3dc'; ctx.font = '600 13px ' + FONT; ctx.fillText(R.S.sub, w / 2, h * 0.36 + 28);
        ctx.fillStyle = '#f2e9d8'; ctx.font = '400 72px ' + DISP; ctx.fillText(String(Math.max(1, Math.ceil(cd))), w / 2, h * 0.52);
        ctx.font = '600 13px ' + FONT; ctx.fillStyle = '#cfc3dc'; ctx.fillText(Math.round(st.dur / 60) + '분 동안 버티면 승리!', w / 2, h * 0.52 + 52);
      }
      if (mp && mp.dn && phase === 'play') {
        ctx.fillStyle = 'rgba(10,8,16,.45)'; ctx.fillRect(0, h * 0.62, w, 64);
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ffd2c8'; ctx.font = '700 15px ' + FONT;
        ctx.fillText('쓰러졌어요', w / 2, h * 0.62 + 20); ctx.font = '600 12.5px ' + FONT; ctx.fillStyle = '#e6dcef';
        ctx.fillText(R.pl.some((q) => !q.dn) ? '친구가 옆에 3초 서 있으면 살아나요' : '', w / 2, h * 0.62 + 44);
      }
    }
    // reusable render lists (host: built from the pools each frame; guest: from the snapshot)
    const RL = { n: 0, k: new Uint8Array(MAXP), x: new Float32Array(MAXP), y: new Float32Array(MAXP), a: new Float32Array(MAXP), r: new Float32Array(MAXP) };
    const GLs = { n: 0, k: new Uint8Array(MAXG), x: new Float32Array(MAXG), y: new Float32Array(MAXG) };
    function projList(R, now) {
      RL.n = 0;
      if (host()) {
        for (let i = 0; i < R.hiP; i++) {
          if (!R.pal[i]) continue;
          const k = R.pk[i], n = RL.n++;
          RL.k[n] = k; RL.x[n] = R.px[i]; RL.y[n] = R.py[i];
          RL.a[n] = k === K.BEAM || k === K.BEAME ? R.pa[i] : k === K.TUR || k === K.TURE ? R.ptg[i] / 100 : Math.atan2(R.pvy[i], R.pvx[i]);
          RL.r[n] = k === K.BOMB ? Math.min(10, R.pL[i] * 16) : R.pr[i];
          if (k === K.MET) RL.r[n] = R.pr[i];
        }
      } else {
        const B = R.B, age = Math.min(0.12, (now - B.t) / 1000);
        for (let q = 0; q < B.n; q++) {
          const k = B.k[q], n = RL.n++, sp = PSPD[k] || 0;
          RL.k[n] = k; RL.a[n] = B.a[q];
          RL.x[n] = B.x[q] + (sp && !isTorn(k) ? Math.cos(B.a[q]) * sp * age : 0); RL.y[n] = B.y[q] + (sp && !isTorn(k) ? Math.sin(B.a[q]) * sp * age : 0);
          RL.r[n] = k === K.BEAM || k === K.BEAME ? B.r[q] * 8 : k === K.WAVE || k === K.WAVEE ? B.r[q] * 4 : B.r[q] * 2;
          if (k === K.BOMB) RL.r[n] = Math.min(10, B.r[q]);
        }
      }
      return RL;
    }
    function gemList(R) {
      if (!host()) return R.Gm;
      GLs.n = 0;
      for (let j = 0; j < MAXG; j++) if (R.gal[j]) { const n = GLs.n++; GLs.k[n] = R.gk[j]; GLs.x[n] = R.gx[j]; GLs.y[n] = R.gy[j]; }
      return GLs;
    }
    // off-screen dangers: bosses / elites / warning circles get a marker on the screen edge
    function drawDanger(R, cx, cy, w, h, T) {
      const edge = (x, y, col, big) => {
        const sx = (x - cx) * scale, sy = (y - cy) * scale;
        if (sx > 0 && sx < w && sy > 70 && sy < h) return;
        const ax = clamp(sx, 16, w - 16), ay = clamp(sy, 84, h - 16), a = Math.atan2(sy - ay, sx - ax), s2 = big ? 1.4 : 1;
        ctx.save(); ctx.translate(ax, ay); ctx.rotate(a); ctx.globalAlpha = 0.6 + 0.4 * Math.sin(T * 10);
        ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(9 * s2, 0); ctx.lineTo(-5 * s2, -7 * s2); ctx.lineTo(-2 * s2, 0); ctx.lineTo(-5 * s2, 7 * s2); ctx.closePath(); ctx.fill(); ctx.restore(); ctx.globalAlpha = 1;
      };
      const cp = R.pl[camSeat(R)]; if (!cp) return;
      for (let i = 0; i < R.hiE; i++) {
        if (!R.eal[i]) continue;
        const boss = ET[R.et[i]][6] === B_BOSS;
        if (!boss && !R.eel[i]) continue;
        if (hyp(R.ex[i] - cp.x, R.ey[i] - cp.y) < 900) edge(R.ex[i], R.ey[i], boss ? '#ff4a4a' : '#ffd36a', boss);
      }
      for (const z of R.Z) if (z.ph === 0 && hyp(z.x - cp.x, z.y - cp.y) < 420) edge(z.x, z.y, '#ff7a5a', false);
    }
    function drawArrows(R, cx, cy, vw, vh, w, h) {
      R.pl.forEach((p, s) => {
        if (s === me()) return;
        const sx = (p.x - cx) * scale, sy = (p.y - cy) * scale;
        if (sx > 0 && sx < w && sy > 70 && sy < h) return;
        const ax = clamp(sx, 22, w - 22), ay = clamp(sy, 92, h - 22), a = Math.atan2(sy - ay, sx - ax);
        ctx.save(); ctx.translate(ax, ay); ctx.rotate(a);
        ctx.fillStyle = p.dn ? '#ff5a4a' : COL(s); ctx.beginPath(); ctx.moveTo(14, 0); ctx.lineTo(-6, -9); ctx.lineTo(-6, 9); ctx.closePath(); ctx.fill();
        ctx.restore();
        ctx.fillStyle = '#fff'; ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(p.dn ? '!' : name(s).slice(0, 2), ax - Math.cos(a) * 16, ay - Math.sin(a) * 16);
      });
    }
    function drawHud(R, w, h, T) {
      const xpf = host() ? clamp(R.xp / xpNeed(R), 0, 1) : R.xpf;
      ctx.fillStyle = 'rgba(12,9,18,.82)'; ctx.fillRect(0, 0, w, 8);
      ctx.fillStyle = '#5ab0ff'; ctx.fillRect(0, 0, w * xpf, 8);
      ctx.fillStyle = 'rgba(12,9,18,.6)'; ctx.fillRect(0, 8, w, 58);
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#e3ae45'; ctx.font = '400 17px ' + DISP; ctx.textAlign = 'left'; ctx.fillText('Lv ' + R.lv, 10, 25);
      const left = Math.max(0, st.dur - (host() ? R.T : R.Tl));
      ctx.textAlign = 'center'; ctx.fillStyle = left < 60 ? '#ffd36a' : '#f2e9d8'; ctx.font = '700 20px ' + MONO; ctx.fillText(fmt(Math.ceil(left)), w / 2, 24);
      ctx.font = '600 10px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('새벽까지', w / 2, 41);
      ctx.textAlign = 'right'; ctx.fillStyle = '#f2e9d8'; ctx.font = '700 14px ' + MONO; ctx.fillText('☠ ' + R.kills, w - 10, 25);
      // my items
      const m = me(), cs = m >= 0 ? m : camSeat(R), p = R.pl[cs];
      if (p) {
        let x = 8;
        const all = p.W.map((q) => [q.e ? EV0 + q.e - 1 : q.i, q.l, q.e]).concat(p.T.map((q) => [TR0 + q.i, q.l, 0]), p.P.map((q) => [PI0 + q.i, q.l, 0]));
        const sz = Math.min(20, (w - 16) / Math.max(1, all.length) - 3);
        for (const it of all) {
          ctx.save(); ctx.translate(x, 44); drawTile(ctx, 'c', it[0], sz); ctx.restore();
          ctx.fillStyle = '#fff'; ctx.font = '700 8px ' + MONO; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic'; ctx.fillText(it[2] ? '★' : String(it[1]), x + sz - 1, 44 + sz - 1);
          x += sz + 3;
        }
        ctx.textBaseline = 'middle';
      }
      // boss bar
      let bh = null;
      if (host()) { for (const i of R.bossI) if (R.eal[i]) { bh = [R.et[i], R.ehp[i] / R.emh[i]]; break; } }
      else if (R.bh) bh = [R.bh[0], R.bh[1] / 100];
      if (bh) {
        ctx.fillStyle = 'rgba(12,9,18,.75)'; ctx.fillRect(10, 70, w - 20, 16);
        ctx.fillStyle = '#c8304a'; ctx.fillRect(12, 72, (w - 24) * clamp(bh[1], 0, 1), 12);
        ctx.fillStyle = '#fff'; ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.fillText('보스 ' + ((ET[bh[0]] || ET[30])[0]), w / 2, 78.5);
      }
      // banners
      let by = bh ? 104 : 88;
      for (let i = banners.length - 1; i >= 0; i--) {
        const b = banners[i]; b.t += 1 / 60 * (SPD() > 1 ? 1 : 1);
        if (b.t > b.life) { banners.splice(i, 1); continue; }
      }
      banners.forEach((b) => {
        ctx.globalAlpha = Math.min(1, (b.life - b.t) * 2, b.t * 6);
        ctx.font = '700 13px ' + FONT; const tw = Math.min(w - 20, ctx.measureText(b.text).width + 24);
        ctx.fillStyle = 'rgba(20,14,30,.85)'; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(w / 2 - tw / 2, by, tw, 26, 13); else ctx.rect(w / 2 - tw / 2, by, tw, 26); ctx.fill();
        ctx.fillStyle = b.col; ctx.textAlign = 'center'; ctx.fillText(b.text, w / 2, by + 13.5, w - 30);
        by += 30;
      });
      ctx.globalAlpha = 1;
    }

    /* ---------- hint & dash ui ---------- */
    const TIPS = ['손가락을 대고 끌면 그쪽으로 걸어요 · 공격은 저절로!', '보석을 주우면 레벨업 → 카드 1장 (건너뛰기도 돼요)', '빨간 동그라미·줄은 곧 위험해요. 피해요!', '보스·강한 적의 유물 상자를 주워요', '왼쪽 아래 「가방」에서 내 빌드를 볼 수 있어요'];
    function syncUi(rdt) {
      const R = RW(), m = me();
      if (phase === 'play' && R && m >= 0 && R.pl[m]) {
        const hp = R.pl[m].hp;
        if (lastHp >= 0 && hp < lastHp - 0.5 && !R.pl[m].dn) { hurtV = 0.22; shake = Math.max(shake, 0.12); snd('thud', 260); api.buzz(20); }
        lastHp = hp;
      } else lastHp = -1;
      const showDash = phase === 'play' && st && st.dsh && m >= 0 && R && R.pl[m] && !R.pl[m].dn;
      dashB.hidden = !showDash;
      const showBag = phase === 'play' && m >= 0 && R && R.pl[m] && cards.hidden && relP.hidden;
      bagB.hidden = !showBag;
      if (showBag) { const n = R.pl[m].R.length, bi = bagB.lastChild; if (bi.textContent !== (n ? String(n) : '')) bi.textContent = n ? String(n) : ''; }
      if (gotT > 0) { gotT -= rdt; if (gotT <= 0) gotEl.hidden = true; }
      if (showDash) {
        const p = R.pl[m], f = p.dc > 0 ? 1 - p.dc / (p.S ? p.S.dcd : 3.5) : 1;
        dashB.style.setProperty('--p', Math.round(f * 100) + '%');
        dashB.classList.toggle('cool', p.dc > 0);
      }
      let t = '', warn = false;
      if (phase === 'play' && R && m >= 0) {
        const p = R.pl[m];
        const z = R.Z.find((q) => q.ph === 0 && hyp(q.x - p.x, q.y - p.y) < q.r + 30);
        if (p.dn || !cards.hidden || !relP.hidden || gotT > 0) t = '';
        else if (z) { t = '⚠ 빨간 동그라미에서 피해요!'; warn = true; }
        else if (R.tide && R.tide.warn > 0) { t = '🌊 밀물! ' + (R.tide.side < 0 ? '오른쪽' : '왼쪽') + '으로 피해요'; warn = true; }
        else if (R.pl.some((q, s) => s !== m && q.dn)) { t = '친구가 쓰러졌어요! 화살표를 따라가 살려요'; warn = true; }
        else if (tPlay < 25) t = TIPS[Math.min(TIPS.length - 1, Math.floor(tPlay / 6))];
      }
      if (t !== hintTxt) { hintTxt = t; hint.textContent = t; hint.classList.toggle('off', !t); }
      if (warn !== hintWarn) { hintWarn = warn; hint.classList.toggle('warn', warn); }
      if (phase === 'pick' && st) buildPick();
      syncRelic();
      syncCards();
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now || performance.now()); syncUi(rdt); } catch (e) { console.error(e); }
      try { draw(now || performance.now(), Math.min(0.1, rdt) * SPD()); } catch (e) { console.error(e); }
    });

    function onDone(next) {
      if (doneSeen) return; doneSeen = true;
      closeOverlays();
      const m = me();
      if (m >= 0 && Array.isArray(next.res) && next.res[m]) api.sfx(next.win ? 'win' : 'lose');
    }

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (next.rid !== key) { startGame(); return; }
        if (prev && prev.ph !== next.ph) {
          if (next.ph === 'count' && phase === 'pick') { phase = 'count'; cd = 3; buildWorld(); layout(); }
          else if (next.ph === 'play' && phase !== 'play' && phase !== 'done') { if (!W && !Gw) buildWorld(); phase = 'play'; api.sfx('pop'); layout(); }
          else if (next.ph === 'done') { phase = 'done'; layout(); }
        }
        if (next.ph === 'done') onDone(next);
        if (phase === 'pick') buildPick();
      },
      destroy() {
        stopLoop();
        if (offIn) offIn();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        window.removeEventListener('keydown', onEsc, true);
        ui.remove(); pick.remove(); goB.remove(); waitT.remove(); bag.remove(); codex.remove(); styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, Gw, st, phase, loc, scale }),
    };
  }

  L.register({
    id: 'swarm', name: '생존 탄막', tag: '협동 생존 로그라이크', cat: '아케이드',
    blurb: '공격은 자동이고 움직이기만 해요. 적을 처치해 보석을 모아 레벨업하고, 캐릭터마다 다른 전용 빌드와 유물로 강해지며 정해진 시간을 버티는 1~4인 협동 로그라이크.',
    tint: '#3a1f4f',
    icon: '<circle cx="28" cy="30" r="7" fill="currentColor"/><circle cx="28" cy="30" r="15" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="5 4"/><circle cx="8" cy="12" r="4" fill="currentColor"/><circle cx="48" cy="10" r="4" fill="currentColor"/><circle cx="50" cy="44" r="4.5" fill="currentColor"/><circle cx="7" cy="46" r="4" fill="currentColor"/><circle cx="28" cy="5" r="3" fill="currentColor"/><path d="M14 18l6 6M43 16l-6 6M44 40l-6-4M13 41l6-4" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><path d="M26 52l2-4 2 4-2 3z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, coop: true, aiDelay: 0,
    options: [
      { id: 'stage', label: '무대', choices: [{ v: -1, label: '무작위' }].concat(STG.map((s, i) => ({ v: i, label: s.nm }))), def: -1 },
      { id: 'time', label: '버틸 시간', choices: [{ v: 10, label: '10분' }, { v: 15, label: '15분' }, { v: 20, label: '20분' }], def: 10 },
      { id: 'dash', label: '대시 버튼', choices: [{ v: 1, label: '켬' }, { v: 0, label: '끔' }], def: 1 },
    ],
    controls: [
      { id: 'left', label: '왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'up', label: '위로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'dash', label: '대시 (짧게 빠르게, 잠깐 무적)', keys: ['Space', 'ShiftLeft'], pad: ['a', 'rt'] },
      { id: 'card1', label: '레벨업 카드 1번 고르기', keys: ['Digit1', 'KeyJ'], pad: ['x'] },
      { id: 'card2', label: '레벨업 카드 2번 고르기', keys: ['Digit2', 'KeyK'], pad: ['y'] },
      { id: 'card3', label: '레벨업 카드 3번 고르기', keys: ['Digit3', 'KeyL'], pad: ['b'] },
      { id: 'skip', label: '레벨업·유물 건너뛰기', keys: ['KeyX', 'Digit0'], pad: ['lb'] },
      { id: 'bag', label: '가방(내 빌드) 열기', keys: ['KeyB', 'KeyI'], pad: ['start'] },
    ],
    quick: [
      '공격은 저절로! 화면 아무 데나 손가락을 대고 끌어서 움직이기만 해요.',
      '보석을 모아 레벨업 → 카드 3장 중 1장(공용 + 전용). 전용 특성으로 빌드 갈래를 정하고, 짝에 따라 진화도 갈라져요.',
      '보스·강한 적의 유물 상자에서 유물을 골라요. 정해진 시간(기본 10분)을 버티면 승리!',
    ],
    codex: codexSheet,
    rules: [
      { h: '목표', p: [
        '모두 한 편이에요. 몰려오는 적을 피하며 정해진 시간(10·15·20분)이 끝날 때까지 버티면 모두 승리!',
        '모두 쓰러지면 패배예요. 혼자 할 때는 쓰러지면 바로 끝나요.',
        '처음엔 적이 적고 약해서 쉽고, 시간이 갈수록 많아지고 세져요. 함께 하는 사람이 많을수록 적도 많아요.',
        '한 판이 끝나면 처음부터 다시 시작해요. 판 밖에서 영구히 강해지는 것(해금·업그레이드)은 없어요. 모든 캐릭터·무기·유물은 처음부터 열려 있어요(📖 도감).',
      ] },
      { h: '조작', p: [
        '화면 아무 데나 손가락을 대고 끌면 그쪽으로 걸어요(손을 댄 곳이 조이스틱 중심). 떼면 멈춰요.',
        '공격은 모두 저절로 해요. 무기마다 쏘는 방향·주기가 달라요.',
        '「대시」 버튼: 짧게 빠르게 달리고 그동안 다치지 않아요(3.5초마다). 설정에서 끌 수 있어요.',
        '왼쪽 아래 「가방」: 내 무기·특성·아이템·유물과 그 효과를 봐요(혼자면 보는 동안 멈춰요).',
        'PC: 방향키·WASD 이동, 스페이스 대시, 1·2·3 고르기, X 건너뛰기, B 가방. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '캐릭터와 빌드', p: [
        '캐릭터 10명, 모두 처음부터 골라요. 이름은 능력·역할이에요(예: 그림자 칼잡이, 장미 정원사).',
        '캐릭터마다 고유 능력 + 전용 무기 2개(하나는 시작 무기) + 전용 특성 4개가 있고, 이걸로 전용 빌드 4갈래가 만들어져요.',
        '갈래 = 전용 무기 + 전용 특성 조합. 어느 특성을 고르느냐로 판 안에서 갈래를 정해요(여러 갈래를 섞어도 돼요).',
        '공용 빌드는 누구나 얻는 공용 무기 10개와 공용 아이템 14개예요.',
        '예시: 불꽃 술사 — 화염 방사 + 「장작불」 → 용의 숨결 → 태양룡의 숨결 / 화염 방사 + 「푸른 불꽃」 → 청염 방사(적을 느리게·얼림).',
      ] },
      { h: '레벨업과 카드', p: [
        '보석을 주우면 팀 경험치가 올라요. 경험치는 모두 함께 쓰고, 레벨업하면 모든 사람이 각자 카드 3장 중 1장을 골라요.',
        '카드에는 공용 카드와 내 캐릭터 전용 카드(색 테두리 · 「전용」 표시)가 섞여 나와요. 진화가 준비되면 진화 카드가 꼭 나와요.',
        '무기는 최대 6개(각 Lv 6), 아이템 최대 6개, 전용 특성은 2개(각 Lv 3).',
        '건너뛰기: 그 레벨에 필요했던 경험치의 50%를 사람 수로 나눠 돌려받아요(혼자 50%, 2명 25%, 4명 12.5%).',
        '혼자(사람 1명)일 때는 고르는 동안 게임이 멈춰요. 친구와 할 때는 멈추지 않고, 고르는 사람은 보호막에 싸여 계속 움직일 수 있어요(12초 지나면 자동으로 골라요).',
      ] },
      { h: '진화', p: [
        '무기를 Lv 6까지 키우고 진화 짝(아이템·전용 특성·다른 무기)을 가지고 있으면 다음 레벨업 카드에 진화가 나와요.',
        '같은 무기라도 짝에 따라 진화가 갈라져요(무기마다 2~3갈래). 진화 카드가 두 장 나오면 하나를 골라 갈래를 정해요. 한 번 진화하면 그 판에서는 다른 갈래로 못 바꿔요.',
        '2차 진화: 일부 진화 무기는 추가 조건(특성 Lv 3, 아이템 최대 레벨, 다른 무기 Lv 4 등)을 채우면 최종 형태로 한 번 더 진화해요.',
        '카드 설명에 「고르면 ○○ 진화 가능」이 보이면 그 카드가 진화의 짝이에요. 모든 갈래와 조건은 도감 「진화」에 나무처럼 정리돼 있어요.',
        '예시: 빛 화살 Lv 6 + 연사 장갑 → 빛의 소나기 → (연사 장갑 Lv 5 + 메아리 구슬 Lv 2) → 천상의 화살비. 빛 화살 Lv 6 + 힘 반지 → 폭발 화살.',
      ] },
      { h: '유물 상자', p: [
        '보스를 쓰러뜨리면 반드시 큰 유물 상자가 떨어지고, 누가 주워도 모두 하나씩 골라요.',
        '강한 적(금테)·보급 상자·아주 드물게 일반 적도 유물 상자를 떨어뜨려요(주운 사람만).',
        '상자를 열면 유물 3개가 나와요. 1개를 고르거나 건너뛰어요. 얻으면 효과가 화면에 크게 나와요.',
        '등급: 일반(회색) · 희귀(파랑) · 영웅(보라) · 전설(금색). 등급이 높을수록 강해요. 빨간 점 = 위험한 거래(큰 힘 + 대가).',
        '유물 36개: 능력치, 맞힐 때·처치할 때 효과, 대시·걸음 효과, 팀 지원, 위험한 거래 등. 모두 도감 「유물」에 있어요.',
      ] },
      { h: '적 · 보스', p: [
        '강한 적(금테)이 1분 남짓마다 나와요. 5분마다 보스, 끝나기 1분 전에는 마지막 보스가 나와요.',
        '보스 공격은 미리 보여요: 빨간 줄(돌진), 분홍 부채꼴(연발), 줄어드는 고리(총알 고리), 빨간 동그라미(내려찍기). 피해요!',
        '분홍색 구슬은 적의 총알이에요. 가끔 떨어지는 고기(체력 +30), 자석(보석 끌어오기), 시계(적 4초 멈춤)도 있어요.',
        '맵 이벤트(약 2분마다): 보급 상자 · 강한 적 무리 · 보석 비 · 포위.',
        '화면 가장자리의 빨간·금색 화살표는 화면 밖 보스·강한 적·위험 지역이에요.',
      ] },
      { h: '쓰러짐과 부활', p: [
        '체력이 0이 되면 쓰러져요. 친구가 옆(초록 원 안)에 3초 서 있으면 체력 절반으로 살아나요. 둘이 함께 서면 더 빨라요.',
        '쓰러진 친구는 화면 가장자리의 빨간 화살표로 보여요.',
      ] },
      { h: '무대 9곳 (기본 무작위)', p: STG.map((x) => x.nm + ': ' + x.sub + '.') },
      { h: '함께 하기', p: [
        '한 폰에는 한 명만. 혼자 하면 나머지 자리는 AI 동료예요. 친구와는 온라인·LAN 방에서 각자 폰으로(1~4명).',
        'AI 동료 난이도는 자리마다 쉬움·보통·어려움. 보통·어려움은 갈래 하나를 정해 그 특성과 진화를 노려요. 어려움은 총알을 피하고, 쓰러진 친구를 먼저 살리고, 쓸모없는 카드는 건너뛰어요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount: (root, api) => mount(root, api),
    _t: T_,
  });
})();
