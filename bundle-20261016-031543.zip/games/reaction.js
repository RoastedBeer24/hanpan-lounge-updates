/* 순발력 대결 — 반응속도 미니게임 모음 (신호등 · 과일 종 · 색과 글자 · 쌍둥이 그림 · 화살표).
   Timing model: every round is a short "stream" of frames. Frame i appears at pre + i*iv ms after the device
   received the round (local clock); frame k is the target (the moment it is right to tap). The host stores only the
   schedule; each device plays it back and measures reaction time from when IT painted frame k, then submits
   {type:'tap', q, ms, e}. The host resolves when every seat tapped, or on a deadline action ('to') sent by the host's
   own seat (or by the first AI seat when nobody human plays). */
(function () {
  const L = window.Lounge, U = L.util;

  const MODES = ['신호등', '과일 종', '색과 글자', '쌍둥이 그림', '화살표'];
  const HOW = [
    '초록불이 켜지면 탭! 빨간불에 누르면 부정 출발',
    '네 장 중 같은 과일이 딱 5개면 종을 탭!',
    '글자 뜻과 글자색이 같을 때만 탭!',
    '두 카드 그림이 위치까지 똑같으면 탭!',
    '화살표가 가리키는 쪽 절반을 탭!',
  ];
  const MCOL = ['#5fd38a', '#f0b440', '#b48cf0', '#5bb3e6', '#ee6a55'];
  const SETS = { all: '01234', quick: '04', eye: '123', '0': '0', '1': '1', '2': '2', '3': '3', '4': '4' };
  const INTRO = 1400, WIN = 2400, SLACK = 700;
  const STREAM = [false, true, true, true, false];

  /* ---------- deterministic helpers (AI plans are a pure function of the state) ---------- */
  function hash() {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < arguments.length; i++) { h = Math.imul(h ^ (arguments[i] | 0), 16777619); h ^= h >>> 13; }
    return h >>> 0;
  }
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const rnd = (n) => Math.floor(Math.random() * n);

  /* ---------- schedule ---------- */
  const tgt = (s) => s.pre + s.k * s.iv;            // target frame time (ms after the round arrived)
  const dline = (s) => tgt(s) + WIN + SLACK;         // host-side deadline
  const revealMs = (s) => 1500 + s.n * 260;
  function frameAt(s, el) {                          // index of the frame visible at elapsed el (−1 = none yet), frozen at k
    if (el < s.pre) return -1;
    if (!STREAM[s.m]) return 0;
    return Math.min(s.k, Math.floor((el - s.pre) / s.iv));
  }
  /* mode data decoders (shared by logic tests and view) */
  function fruitSlots(d, i) {
    const sl = [null, null, null, null];
    for (let j = 0; j <= i; j++) sl[j % 4] = { f: +d[2 * j], c: +d[2 * j + 1] };
    return sl;
  }
  function fruitTotals(sl) { const t = [0, 0, 0, 0]; sl.forEach((c) => { if (c) t[c.f] += c.c; }); return t; }
  const fruitHit = (d, i) => fruitTotals(fruitSlots(d, i)).includes(5);
  const stroopAt = (d, i) => ({ w: +d[2 * i], c: +d[2 * i + 1] });
  const twinAt = (d, i) => ({ a: d.substr(8 * i, 4), b: d.substr(8 * i + 4, 4) });

  function genFruit() {
    const W = [1, 1, 1, 2, 2, 2, 3, 3, 4, 5];
    for (let tries = 0; tries < 400; tries++) {
      let d = '';
      for (let i = 0; i < 13; i++) {
        d += rnd(4) + '' + W[rnd(W.length)];
        if (fruitHit(d, i)) { if (i >= 4) return { d, k: i }; break; }
      }
    }
    // fallback (practically unreachable): build a hit by hand
    return { d: '11221331' + '04' + '22' + '33' + '01', k: 7 };
  }
  function genStroop() {
    const k = 2 + rnd(6);
    let d = '';
    for (let i = 0; i < k; i++) { const w = rnd(5); let c = rnd(4); if (c >= w) c++; d += w + '' + c; }
    const w = rnd(5);
    return { d: d + w + w, k };
  }
  function genTwins() {
    const k = 1 + rnd(5);
    let d = '';
    for (let i = 0; i <= k; i++) {
      const all = U.shuffle([0, 1, 2, 3, 4, 5]);
      const a = all.slice(0, 4), b = a.slice();
      if (i < k) {
        if (Math.random() < 0.55) b[rnd(4)] = all[4 + rnd(2)];
        else { const x = rnd(4); let y = rnd(3); if (y >= x) y++; [b[x], b[y]] = [b[y], b[x]]; }
      }
      d += a.join('') + b.join('');
    }
    return { d, k };
  }

  function newRound(s) {
    s.rn++; s.q++;
    const pool = s.set.split('').map(Number);
    let m = pool[rnd(pool.length)];
    if (pool.length > 1 && m === s.lm) m = pool.filter((x) => x !== s.lm)[rnd(pool.length - 1)];
    s.m = m;
    s.k = 0; s.iv = 0; s.d = '';
    if (m === 0 || m === 4) {
      s.pre = INTRO + 700 + rnd(3000);
      if (m === 4) s.d = (Math.random() < 0.5 ? 'L' : 'R') + (Math.random() < 0.5 ? 'L' : 'R');
    } else {
      s.pre = INTRO + 800 + rnd(500);
      const g = m === 1 ? genFruit() : m === 2 ? genStroop() : genTwins();
      s.d = g.d; s.k = g.k;
      s.iv = m === 1 ? 900 + rnd(250) : m === 2 ? 850 + rnd(250) : 1300 + rnd(300);
    }
    s.tp = Array(s.n).fill(null);
    s.w = [];
    s.ph = 'p';
    s.t0 = Date.now();
    s.lm = m;
  }

  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const s = {
      n, hu: players.some((p) => !p.ai), nm: players.map((p) => String(p.name || '').slice(0, 10)), g: Math.floor(Math.random() * 1e9),
      R: [5, 7, 10].includes(+opts.rounds) ? +opts.rounds : 7,
      pen: opts.pen === 0 ? 0 : 1,
      set: SETS[opts.set] || SETS.all,
      rn: 0, q: 0, ph: 'p', t0: 0, m: 0, pre: 0, iv: 0, k: 0, d: '', lm: -1,
      tp: [], w: [], sc: Array(n).fill(0), bt: Array(n).fill(-1),
    };
    newRound(s);
    return s;
  }

  function actor(s) {
    if (s.ph === 'e') return null;
    return Array.from({ length: s.n }, (_, i) => i);
  }

  function resolve(s) {
    let best = Infinity;
    s.tp.forEach((v) => { if (v != null && v >= 0 && v < best) best = v; });
    s.w = [];
    s.tp.forEach((v, i) => {
      if (v != null && v >= 0) {
        if (v === best) { s.w.push(i); s.sc[i]++; }
        if (s.bt[i] < 0 || v < s.bt[i]) s.bt[i] = v;
      } else if (v != null && v < 0) s.sc[i] -= s.pen;
    });
    s.ph = 'r';
    s.t0 = Date.now();
  }

  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (a.q !== s.q) throw new Error('stale round');
    if (a.type === 'tap') {
      if (s.ph !== 'p') throw new Error('not tapping now');
      if (s.tp[seat] != null) throw new Error('already tapped');
      const e = a.e | 0;
      if (e < 0 || e > 2 || (e === 2 && s.m !== 4)) throw new Error('bad tap');
      if (e === 0) {
        if (typeof a.ms !== 'number' || !isFinite(a.ms)) throw new Error('bad ms');
        s.tp[seat] = U.clamp(Math.round(a.ms), 0, 9999);
      } else s.tp[seat] = -e;
      if (s.tp.every((v) => v != null)) resolve(s);
      return s;
    }
    if (a.type === 'to') { if (s.ph !== 'p') throw new Error('not running'); resolve(s); return s; }
    if (a.type === 'next') {
      if (s.ph !== 'r') throw new Error('not revealing');
      if (s.rn >= s.R) { s.ph = 'e'; s.tp = []; return s; }
      newRound(s);
      return s;
    }
    throw new Error('bad action');
  }

  function result(s) {
    if (s.ph !== 'e') return null;
    const top = Math.max(...s.sc);
    const winners = s.sc.map((v, i) => (v === top ? i : -1)).filter((i) => i >= 0);
    const ord = s.sc.map((v, i) => i).sort((a, b) => s.sc[b] - s.sc[a]);
    let fast = -1;
    s.bt.forEach((v, i) => { if (v >= 0 && (fast < 0 || v < s.bt[fast])) fast = i; });
    return {
      winners,
      text: ord.map((i) => s.nm[i] + ' ' + s.sc[i] + '점').join(' · ') + (fast >= 0 ? '\n가장 빠른 반응: ' + s.nm[fast] + ' ' + s.bt[fast] + 'ms' : ''),
    };
  }

  /* ---------- AI ---------- */
  /* per-seat level (1 쉬움 / 2 보통 / 3 어려움): base reaction (ms), its spread, recognition-time factor for the
     "eye" games, chance to zone out, false-start/wrong-tap factor, fastest possible tap */
  const RLV = {
    1: { b: 265, sk: 150, sp: 150, rec: 1.25, zo: 0.06, fs: 1.7, min: 200 },
    2: { b: 230, sk: 130, sp: 90, rec: 1, zo: 0.03, fs: 1, min: 170 },
    3: { b: 205, sk: 90, sp: 90, rec: 0.8, zo: 0.015, fs: 0.5, min: 160 },
  };
  function aiPlan(s, seat, lv) {
    const K = RLV[lv] || RLV[2];
    const sk = prng(hash(s.g, seat, 77))();
    const r = prng(hash(s.g, s.q, seat, 5));
    let rt = K.b + (1 - sk) * K.sk + r() * K.sp;              // lv2: 230–450 ms base
    rt += [0, 170, 140, 260, 45][s.m] * K.rec + (r() - 0.5) * 80; // harder recognition in the "eye" games
    rt = Math.round(Math.max(K.min, rt));
    const T = tgt(s), x = r(), y = r(), z = r();
    if (x < K.zo) return { at: Infinity };                   // zoned out — no tap
    if (y < [0.08, 0.07, 0.07, 0.06, 0.07][s.m] * K.fs) {
      if (s.m === 4 && z < 0.5) return { at: T + rt, e: 2 };
      if (!STREAM[s.m]) return { at: Math.max(INTRO + 80, T - 60 - z * Math.min(800, T - INTRO - 200)), e: 1 };
      if (s.k >= 1) return { at: s.pre + Math.floor(z * s.k) * s.iv + rt * 0.7, e: 1 };
    }
    return { at: T + rt, e: 0, ms: rt };
  }
  const driverSeat = (s) => (s.hu ? -1 : 0);   // with no human in the match the first AI keeps the clock
  function elapsed(s) { return (Date.now() - s.t0) * ((L.debug && L.debug.speed) || 1); }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'e') return -1;
    const el = elapsed(s);
    if (s.ph === 'p') {
      if (s.tp[seat] == null) {
        const p = aiPlan(s, seat, lv);
        if (isFinite(p.at)) return Math.max(0, p.at - el);
      }
      return seat === driverSeat(s) ? Math.max(0, dline(s) - el) : -1;
    }
    return seat === driverSeat(s) ? Math.max(0, revealMs(s) - el) : -1;
  }
  function ai(s, seat, lv) {
    if (s.ph === 'p') {
      if (s.tp[seat] == null) {
        const p = aiPlan(s, seat, lv);
        if (isFinite(p.at) && (seat !== driverSeat(s) || elapsed(s) < dline(s))) return { type: 'tap', q: s.q, e: p.e, ms: p.e === 0 ? p.ms : 0 };
      }
      return seat === driverSeat(s) ? { type: 'to', q: s.q } : null;
    }
    if (s.ph === 'r' && seat === driverSeat(s)) return { type: 'next', q: s.q };
    return null;
  }

  /* ---------- view ---------- */
  const FD = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const FB = '"IBM Plex Sans KR","Apple SD Gothic Neo",sans-serif';
  const FM = '"IBM Plex Mono",ui-monospace,monospace';
  const INK = ['#ff4d5a', '#3e8ef7', '#f5cf3a', '#36c46e', '#b77cff'];
  const INKN = ['빨강', '파랑', '노랑', '초록', '보라'];

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const hud = L.h('div', { class: 'hud top', style: { gap: '5px', padding: '8px 8px 0' } });
    root.append(hud);
    const sp = () => L.debug.speed || 1;
    let st = null, key = '', localStart = performance.now(), shownAt = null, lastFrame = -2, revealAt = 0;
    let myTap = {}, zones = [], hudH = 0, drv = 0, introStep = 0, rowsPlayed = 0, winPlayed = false;
    const ring = {}; // seat -> time of the last tap (bell / ripple anim)
    let actx = null;

    /* own tiny sounds for the bell and the "go" cue (respects the app's sound toggle) */
    function tone(parts, dur, vol) {
      if (!U.store.get('sound', true)) return;
      try {
        if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
        const t = actx.currentTime;
        parts.forEach(([f, v], i) => {
          const o = actx.createOscillator(), g = actx.createGain();
          o.type = i ? 'sine' : 'triangle'; o.frequency.setValueAtTime(f, t);
          g.gain.setValueAtTime(vol * v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
          o.connect(g).connect(actx.destination); o.start(t); o.stop(t + dur + 0.02);
        });
      } catch (e) {}
    }
    const ding = () => tone([[1568, 1], [2349, 0.5], [3136, 0.25]], 0.7, 0.16);
    const goBeep = () => tone([[988, 1], [1976, 0.3]], 0.18, 0.2);

    const locals = () => api.mySeats();
    const isMulti = () => !api.online && locals().length >= 2;

    function layout() {
      const W = cv.w, H = cv.h;
      if (!isMulti()) {
        hud.hidden = false;
        hudH = hud.offsetHeight + 4;
        const me = locals();
        zones = [{ seat: me.length ? me[0] : -1, x: 0, y: hudH, w: W, h: H - hudH, rot: 0 }];
        return;
      }
      hud.hidden = true; hudH = 0;
      const hs = locals(), P = Math.PI, n = hs.length;
      const z = [];
      const add = (i, x, y, w, h, rot) => z.push({ seat: hs[i], x: x + 2, y: y + 2, w: w - 4, h: h - 4, rot });
      if (n === 2) { add(0, 0, H / 2, W, H / 2, 0); add(1, 0, 0, W, H / 2, P); }
      else if (n === 3) { add(0, 0, H / 2, W / 2, H / 2, 0); add(1, W / 2, H / 2, W / 2, H / 2, 0); add(2, 0, 0, W, H / 2, P); }
      else if (n === 4) { add(0, 0, H / 2, W / 2, H / 2, 0); add(1, W / 2, H / 2, W / 2, H / 2, 0); add(2, W / 2, 0, W / 2, H / 2, P); add(3, 0, 0, W / 2, H / 2, P); }
      else {
        const a = H * 0.3, b = H * 0.4;
        if (n === 5) add(0, 0, a + b, W, a, 0);
        else { add(0, 0, a + b, W / 2, a, 0); add(1, W / 2, a + b, W / 2, a, 0); }
        const o = n === 5 ? 1 : 2;
        add(o, W / 2, a, W / 2, b, -P / 2); add(o + 1, W / 2, 0, W / 2, a, P); add(o + 2, 0, 0, W / 2, a, P); add(o + 3, 0, a, W / 2, b, P / 2);
      }
      zones = z;
    }
    cv.onresize = () => layout();

    function zoneDims(z) { const side = Math.abs(Math.abs(z.rot) - Math.PI / 2) < 0.01; return side ? { w: z.h, h: z.w } : { w: z.w, h: z.h }; }
    function toLocal(z, px, py) {
      const d = zoneDims(z);
      const dx = px - (z.x + z.w / 2), dy = py - (z.y + z.h / 2);
      const c = Math.cos(-z.rot), s = Math.sin(-z.rot);
      return { x: dx * c - dy * s + d.w / 2, y: dx * s + dy * c + d.h / 2, w: d.w, h: d.h };
    }

    /* ---------- HUD (single-screen scoreboard) ---------- */
    function renderHud() {
      hud.innerHTML = '';
      if (!st || isMulti()) return;
      const top = Math.max(...st.sc);
      api.players.forEach((p, i) => {
        hud.append(L.h('span', { class: 'turn', style: { padding: '3px 9px 3px 7px', fontSize: '12px', borderColor: st.sc[i] === top && top > 0 ? 'var(--brass)' : '' } },
          L.h('span', { class: 'dot', style: { '--c': p.color } }), L.h('span', { style: { maxWidth: '64px', overflow: 'hidden', textOverflow: 'ellipsis' }, text: p.name }),
          L.h('b', { class: 'mono', text: String(st.sc[i]) })));
      });
      const h0 = hudH;
      hudH = hud.offsetHeight + 4;
      if (Math.abs(h0 - hudH) > 1) layout();
    }

    /* ---------- input ---------- */
    function onDown(ev) {
      ev.preventDefault();
      if (!st || st.ph !== 'p') return;
      const r = cv.cv.getBoundingClientRect();
      const px = ev.clientX - r.left, py = ev.clientY - r.top;
      const z = zones.find((q) => px >= q.x && px <= q.x + q.w && py >= q.y && py <= q.y + q.h);
      if (!z || z.seat < 0 || !api.canAct(z.seat)) return;
      const seat = z.seat;
      if (myTap[seat] || st.tp[seat] != null) return;
      const t = ev.timeStamp || performance.now();
      const el = (t - localStart) * sp();
      if (el < INTRO) return; // title card: accidental taps from the last round are ignored
      let e = 0, ms = 0;
      if (shownAt == null || t < shownAt) e = 1;
      else {
        ms = Math.max(0, Math.round((t - shownAt) * sp()));
        if (st.m === 4) { const lp = toLocal(z, px, py); if ((lp.x < lp.w / 2 ? 'L' : 'R') !== st.d[0]) e = 2; }
      }
      myTap[seat] = { e, ms, at: performance.now() };
      ring[seat] = performance.now();
      if (e === 0) { if (st.m === 1) ding(); else api.sfx('hit'); api.buzz(25); }
      else { api.sfx('lose'); api.buzz(90); }
      api.actAs(seat, { type: 'tap', q: st.q, e, ms });
    }
    cv.cv.addEventListener('pointerdown', onDown);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ---------- host clock (deadline / next round) ---------- */
    function setDriver() {
      clearTimeout(drv); drv = 0;
      if (!st || !api.isHost || !st.hu || st.ph === 'e') return;
      const seat = locals()[0];
      if (seat == null) return;
      const q = st.q, ph = st.ph;
      const wait = ph === 'p' ? dline(st) / sp() - (performance.now() - localStart) : revealMs(st) / sp();
      drv = setTimeout(function fire() {
        if (!st || st.q !== q || st.ph !== ph) return;
        if (document.querySelector('.overlay.rules-ov') && !api.online) { drv = setTimeout(fire, 300); return; }
        api.actAs(seat, ph === 'p' ? { type: 'to', q } : { type: 'next', q });
      }, Math.max(0, wait));
    }

    /* ---------- drawing helpers ---------- */
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function fnt(size, font) { const m = /^(\d{3}) (.*)$/.exec(font || FD); return m ? m[1] + ' ' + size + 'px ' + m[2] : size + 'px ' + (font || FD); }
    function txt(t, x, y, size, col, font, align, base) {
      ctx.font = fnt(size, font); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y);
    }
    function fitSize(t, maxW, size, font) { ctx.font = fnt(size, font); const w = ctx.measureText(t).width; return w > maxW ? Math.max(8, size * maxW / w) : size; }
    function wrap(t, maxW, size, font) {
      ctx.font = fnt(size, font);
      const words = t.split(' '), lines = [];
      let cur = '';
      words.forEach((w) => { const tr = cur ? cur + ' ' + w : w; if (ctx.measureText(tr).width > maxW && cur) { lines.push(cur); cur = w; } else cur = tr; });
      if (cur) lines.push(cur);
      return lines;
    }
    function alpha(hex, a) { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; }

    function drawFruit(f, x, y, r) {
      ctx.save(); ctx.translate(x, y);
      if (f === 0) { // apple
        ctx.fillStyle = '#d93a3a';
        ctx.beginPath(); ctx.arc(-r * 0.32, r * 0.05, r * 0.68, 0, 7); ctx.arc(r * 0.32, r * 0.05, r * 0.68, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(-r * 0.45, -r * 0.2, r * 0.18, r * 0.28, -0.4, 0, 7); ctx.fill();
        ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = Math.max(1.5, r * 0.12); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0, -r * 0.45); ctx.lineTo(r * 0.08, -r * 0.85); ctx.stroke();
        ctx.fillStyle = '#4caf50'; ctx.beginPath(); ctx.ellipse(r * 0.35, -r * 0.78, r * 0.3, r * 0.14, -0.5, 0, 7); ctx.fill();
      } else if (f === 1) { // lemon
        ctx.rotate(-0.35);
        ctx.fillStyle = '#f6d23a';
        ctx.beginPath(); ctx.ellipse(0, 0, r * 0.85, r * 0.62, 0, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.ellipse(r * 0.85, 0, r * 0.18, r * 0.12, 0, 0, 7); ctx.ellipse(-r * 0.85, 0, r * 0.18, r * 0.12, 0, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.beginPath(); ctx.ellipse(-r * 0.25, -r * 0.28, r * 0.3, r * 0.12, -0.2, 0, 7); ctx.fill();
      } else if (f === 2) { // grapes
        ctx.fillStyle = '#7d3fb8';
        const g = [[-0.42, -0.35], [0, -0.35], [0.42, -0.35], [-0.21, 0.02], [0.21, 0.02], [0, 0.38]];
        g.forEach(([a, b]) => { ctx.beginPath(); ctx.arc(a * r * 1.05, b * r * 1.05 + r * 0.1, r * 0.27, 0, 7); ctx.fill(); });
        ctx.fillStyle = 'rgba(255,255,255,.35)';
        g.forEach(([a, b]) => { ctx.beginPath(); ctx.arc(a * r * 1.05 - r * 0.08, b * r * 1.05 + r * 0.02, r * 0.07, 0, 7); ctx.fill(); });
        ctx.strokeStyle = '#4a7a2a'; ctx.lineWidth = Math.max(1.5, r * 0.1); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0, -r * 0.55); ctx.quadraticCurveTo(r * 0.1, -r * 0.85, r * 0.3, -r * 0.9); ctx.stroke();
      } else { // kiwi slice
        ctx.fillStyle = '#7a5a32'; ctx.beginPath(); ctx.arc(0, 0, r * 0.8, 0, 7); ctx.fill();
        ctx.fillStyle = '#7cc242'; ctx.beginPath(); ctx.arc(0, 0, r * 0.68, 0, 7); ctx.fill();
        ctx.fillStyle = '#e8f3c8'; ctx.beginPath(); ctx.arc(0, 0, r * 0.22, 0, 7); ctx.fill();
        ctx.fillStyle = '#1d1a12';
        for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2; ctx.beginPath(); ctx.ellipse(Math.cos(a) * r * 0.38, Math.sin(a) * r * 0.38, r * 0.06, r * 0.035, a, 0, 7); ctx.fill(); }
      }
      ctx.restore();
    }
    const PIPS = [[[0, 0]], [[-1, -1], [1, 1]], [[-1, -1], [0, 0], [1, 1]], [[-1, -1], [1, -1], [-1, 1], [1, 1]], [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]]];
    function drawCard(card, x, y, w, h, flip) {
      ctx.save(); ctx.translate(x + w / 2, y + h / 2);
      if (flip != null && flip < 1) ctx.scale(Math.max(0.05, Math.abs(Math.cos((1 - flip) * Math.PI / 2))), 1);
      ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(-w / 2 + 2, -h / 2 + 4, w, h, w * 0.1); ctx.fill();
      if (!card) {
        ctx.strokeStyle = 'rgba(242,233,216,.18)'; ctx.setLineDash([5, 5]); ctx.lineWidth = 2; rr(-w / 2, -h / 2, w, h, w * 0.1); ctx.stroke(); ctx.setLineDash([]);
        ctx.restore(); return;
      }
      ctx.fillStyle = '#f7efdf'; rr(-w / 2, -h / 2, w, h, w * 0.1); ctx.fill();
      ctx.strokeStyle = '#d8c7a3'; ctx.lineWidth = 2; rr(-w / 2 + 4, -h / 2 + 4, w - 8, h - 8, w * 0.07); ctx.stroke();
      const r = Math.min(w, h * 0.72) * 0.17;
      PIPS[card.c - 1].forEach(([a, b]) => drawFruit(card.f, a * w * 0.25, b * h * 0.28, r));
      ctx.restore();
    }
    function drawSym(k, x, y, r) {
      ctx.save(); ctx.translate(x, y);
      const col = ['#f0b440', '#ee5a6e', '#9fc4ff', '#55c27a', '#3e8ef7', '#ff8a3d'][k];
      ctx.fillStyle = col; ctx.beginPath();
      if (k === 0) { for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr2 = i % 2 ? r * 0.42 : r; ctx.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2); } ctx.closePath(); ctx.fill(); }
      else if (k === 1) { ctx.moveTo(0, r * 0.85); ctx.bezierCurveTo(-r * 1.3, -r * 0.1, -r * 0.55, -r * 1.05, 0, -r * 0.35); ctx.bezierCurveTo(r * 0.55, -r * 1.05, r * 1.3, -r * 0.1, 0, r * 0.85); ctx.fill(); }
      else if (k === 2) { ctx.arc(0, 0, r * 0.9, 0, 7); ctx.fill(); ctx.globalCompositeOperation = 'destination-out'; ctx.beginPath(); ctx.arc(r * 0.42, -r * 0.25, r * 0.75, 0, 7); ctx.fill(); ctx.globalCompositeOperation = 'source-over'; }
      else if (k === 3) { ctx.moveTo(0, -r * 0.9); ctx.lineTo(r * 0.95, r * 0.75); ctx.lineTo(-r * 0.95, r * 0.75); ctx.closePath(); ctx.fill(); }
      else if (k === 4) { ctx.moveTo(0, -r); ctx.bezierCurveTo(r * 0.3, -r * 0.4, r * 0.8, 0, r * 0.8, r * 0.3); ctx.arc(0, r * 0.3, r * 0.8, 0, Math.PI); ctx.bezierCurveTo(-r * 0.8, 0, -r * 0.3, -r * 0.4, 0, -r); ctx.fill(); }
      else { ctx.moveTo(r * 0.25, -r); ctx.lineTo(-r * 0.6, r * 0.15); ctx.lineTo(-r * 0.02, r * 0.15); ctx.lineTo(-r * 0.3, r); ctx.lineTo(r * 0.65, -r * 0.2); ctx.lineTo(r * 0.06, -r * 0.2); ctx.closePath(); ctx.fill(); }
      ctx.restore();
    }
    function drawTwinCard(code, x, y, s) {
      ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(x + 2, y + 4, s, s, s * 0.1); ctx.fill();
      ctx.fillStyle = '#2a2238'; rr(x, y, s, s, s * 0.1); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 2; rr(x + 3, y + 3, s - 6, s - 6, s * 0.08); ctx.stroke();
      for (let i = 0; i < 4; i++) drawSym(+code[i], x + s * (i % 2 ? 0.72 : 0.28), y + s * (i < 2 ? 0.28 : 0.72), s * 0.16);
    }
    function drawBell(x, y, r, shake) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(shake * 40) * 0.25 * Math.max(0, 1 - shake * 3));
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(2, r * 0.62, r * 1.05, r * 0.25, 0, 0, 7); ctx.fill();
      const g = ctx.createLinearGradient(-r, 0, r, 0); g.addColorStop(0, '#9c6b1c'); g.addColorStop(0.45, '#f4d27a'); g.addColorStop(1, '#a8741f');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(-r, r * 0.5); ctx.quadraticCurveTo(-r * 0.92, -r * 0.75, 0, -r * 0.78); ctx.quadraticCurveTo(r * 0.92, -r * 0.75, r, r * 0.5); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#5b3d10'; rr(-r * 1.05, r * 0.42, r * 2.1, r * 0.2, r * 0.1); ctx.fill();
      ctx.fillStyle = '#f4d27a'; ctx.beginPath(); ctx.arc(0, -r * 0.86, r * 0.16, 0, 7); ctx.fill();
      ctx.restore();
    }
    function drawArrow(x, y, s, dir, col) {
      ctx.save(); ctx.translate(x, y); if (dir === 'L') ctx.scale(-1, 1);
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.translate(3, 5);
      const path = () => { ctx.beginPath(); ctx.moveTo(-s, -s * 0.28); ctx.lineTo(s * 0.15, -s * 0.28); ctx.lineTo(s * 0.15, -s * 0.7); ctx.lineTo(s, 0); ctx.lineTo(s * 0.15, s * 0.7); ctx.lineTo(s * 0.15, s * 0.28); ctx.lineTo(-s, s * 0.28); ctx.closePath(); };
      path(); ctx.fill(); ctx.translate(-3, -5);
      ctx.fillStyle = col; path(); ctx.fill();
      ctx.restore();
    }

    /* ---------- per-zone rendering ---------- */
    function tapOf(seat) {
      if (seat < 0 || !st) return null;
      const v = st.tp && st.tp[seat];
      if (v != null) return v;
      const m = myTap[seat];
      return m ? (m.e ? -m.e : m.ms) : null;
    }
    function badLabel(v, m) { return v === -2 ? '반대쪽!' : STREAM[m] ? '잘못 누름' : '부정 출발'; }

    function drawZone(z, w, h, now) {
      const seat = z.seat, multi = isMulti();
      const p = seat >= 0 ? api.players[seat] : null;
      // table
      const bg = ctx.createRadialGradient(w / 2, h * 0.45, 10, w / 2, h * 0.45, Math.max(w, h) * 0.75);
      bg.addColorStop(0, '#2c2240'); bg.addColorStop(1, '#17121f');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
      if (multi && p) { ctx.fillStyle = alpha(p.color, 0.1); ctx.fillRect(0, 0, w, h); ctx.fillStyle = p.color; ctx.fillRect(0, h - 5, w, 5); }
      const el = (now - localStart) * sp();
      // header
      const hh = multi ? 30 : 26;
      if (multi && p) {
        ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(14, hh / 2 + 2, 6, 0, 7); ctx.fill();
        const ns = fitSize(p.name, w * 0.42, 15, FB);
        ctx.font = '700 ' + ns + 'px ' + FB; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(p.name, 26, hh / 2 + 2);
        txt(String(st.sc[seat]), 26 + ctx.measureText(p.name).width + 10, hh / 2 + 2, 16, '#e3ae45', FM, 'left');
        if (st.ph !== 'e') txt((st.rn) + '/' + st.R + ' · ' + MODES[st.m], w - 10, hh / 2 + 2, fitSize(MODES[st.m] + ' 10/10', w * 0.4, 12, FB), '#ab9fb8', FB, 'right');
      } else if (st.ph !== 'e') {
        txt(MODES[st.m], 12, hh / 2 + 2, 15, MCOL[st.m], FD, 'left');
        txt('라운드 ' + st.rn + '/' + st.R, w - 12, hh / 2 + 2, 12, '#ab9fb8', FM, 'right');
      }
      const by = hh + 4, bh = h - by - (multi ? 10 : 34);
      if (st.ph === 'e') { drawFinal(w, by, bh, seat); return; }
      if (st.ph === 'r') { drawReveal(w, by, bh, seat, now); return; }
      if (el < INTRO) drawIntro(w, by, bh, el);
      else drawStim(z, w, by, bh, now, el, seat);
      // own feedback
      const v = tapOf(seat);
      if (v != null) {
        const t0 = myTap[seat] ? myTap[seat].at : now - 1000;
        const k = Math.min(1, (now - t0) / 160);
        const cy = by + bh * 0.5, s = Math.min(w, bh);
        if (v >= 0) {
          ctx.fillStyle = 'rgba(16,12,22,' + (0.72 * k) + ')'; ctx.fillRect(0, by, w, bh);
          const sz = Math.min(w * 0.26, s * 0.3) * (1.25 - 0.25 * k);
          txt(String(v), w / 2 - sz * 0.05, cy, sz, p ? p.color : '#f2e9d8', '700 ' + FM, 'right');
          txt('ms', w / 2 + 4, cy + sz * 0.18, sz * 0.4, '#f2e9d8', '600 ' + FM, 'left');
          txt('기록 완료 · 다른 사람 기다리는 중', w / 2, cy + sz * 0.85, fitSize('기록 완료 · 다른 사람 기다리는 중', w - 24, 13, FB), '#ab9fb8', FB);
        } else {
          ctx.fillStyle = 'rgba(120,20,30,' + (0.6 * k) + ')'; ctx.fillRect(0, by, w, bh);
          const sh = k < 1 ? Math.sin(now / 18) * 8 * (1 - k) : 0;
          const lab = badLabel(v, st.m);
          txt(lab, w / 2 + sh, cy, fitSize(lab, w - 30, Math.min(w * 0.16, s * 0.18), FD), '#ffd9d4', FD);
          txt(st.pen ? '이번 라운드 탈락 · −1점' : '이번 라운드 탈락', w / 2, cy + Math.min(w * 0.16, s * 0.18) * 0.9, 13, '#f2e9d8', FB);
        }
      } else if (!multi && seat >= 0 && el >= INTRO) {
        txt(HOW[st.m], w / 2, h - 18, fitSize(HOW[st.m], w - 24, 13, FB), '#ab9fb8', FB);
      } else if (!multi && seat < 0) {
        txt('관전 중', w / 2, h - 18, 13, '#ab9fb8', FB);
      }
    }

    function drawIntro(w, by, bh, el) {
      const k = Math.min(1, el / 220);
      const cy = by + bh * 0.42;
      const big = fitSize(MODES[st.m], w - 40, Math.min(w * 0.2, bh * 0.2), FD) * (0.85 + 0.15 * k);
      ctx.globalAlpha = k;
      txt('ROUND ' + st.rn + ' / ' + st.R, w / 2, cy - big * 0.95, Math.min(14, w * 0.05), '#ab9fb8', '600 ' + FM);
      txt(MODES[st.m], w / 2, cy, big, MCOL[st.m], FD);
      const fs = Math.min(16, w * 0.05);
      const lines = wrap(HOW[st.m], w - 40, fs, FB);
      lines.forEach((l, i) => txt(l, w / 2, cy + big * 0.85 + i * fs * 1.35, fs, '#f2e9d8', FB));
      ctx.fillStyle = 'rgba(242,233,216,.12)'; rr(w * 0.3, cy + big * 0.85 + lines.length * fs * 1.35 + 8, w * 0.4, 4, 2); ctx.fill();
      ctx.fillStyle = MCOL[st.m]; rr(w * 0.3, cy + big * 0.85 + lines.length * fs * 1.35 + 8, w * 0.4 * Math.min(1, el / INTRO), 4, 2); ctx.fill();
      ctx.globalAlpha = 1;
    }
    function readyText(w, y, now, size) {
      const a = 0.55 + 0.45 * Math.sin(now / 180);
      ctx.globalAlpha = a; txt('준비…', w / 2, y, size, '#f2e9d8', FD); ctx.globalAlpha = 1;
    }

    function drawStim(z, w, by, bh, now, el, seat) {
      const fi = frameAt(st, el);
      const cx = w / 2, cy = by + bh / 2, m = st.m;
      const hit = fi === st.k;
      if (m === 0) {
        const vert = bh > w * 0.9;
        const lr = Math.min(vert ? Math.min(w * 0.26, bh * 0.14) : Math.min(bh * 0.25, w * 0.15), 110);
        const hw = vert ? lr * 2.7 : lr * 5, hhh = vert ? lr * 5 : lr * 2.7;
        const hx = cx - hw / 2, hy = cy - hhh / 2 - (vert ? lr * 0.3 : 0);
        if (hit) { const f = Math.max(0, 1 - (now - (shownAt || now)) / 400); ctx.fillStyle = 'rgba(95,211,138,' + (0.12 + 0.35 * f) + ')'; ctx.fillRect(0, by, w, bh); }
        ctx.fillStyle = 'rgba(0,0,0,.4)'; rr(hx + 4, hy + 6, hw, hhh, lr * 0.6); ctx.fill();
        ctx.fillStyle = '#1b1622'; rr(hx, hy, hw, hhh, lr * 0.6); ctx.fill();
        ctx.strokeStyle = '#8a6a2a'; ctx.lineWidth = 3; rr(hx + 2, hy + 2, hw - 4, hhh - 4, lr * 0.55); ctx.stroke();
        const p1 = vert ? [cx, hy + hhh * 0.28] : [hx + hw * 0.28, cy];
        const p2 = vert ? [cx, hy + hhh * 0.72] : [hx + hw * 0.72, cy];
        const lamp = (pt, on, col, dim) => {
          if (on) { const g = ctx.createRadialGradient(pt[0], pt[1], lr * 0.2, pt[0], pt[1], lr * 1.6); g.addColorStop(0, alpha(col, 0.55)); g.addColorStop(1, alpha(col, 0)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(pt[0], pt[1], lr * 1.6, 0, 7); ctx.fill(); }
          ctx.fillStyle = on ? col : dim; ctx.beginPath(); ctx.arc(pt[0], pt[1], lr, 0, 7); ctx.fill();
          ctx.fillStyle = on ? 'rgba(255,255,255,.35)' : 'rgba(255,255,255,.05)'; ctx.beginPath(); ctx.arc(pt[0] - lr * 0.3, pt[1] - lr * 0.3, lr * 0.3, 0, 7); ctx.fill();
        };
        lamp(p1, !hit, '#ff3b3b', '#3a1a1e'); lamp(p2, hit, '#3dff8a', '#16301f');
        const ty = vert ? hy + hhh + Math.min(36, (by + bh - hy - hhh) / 2) : hy + hhh + 26;
        if (hit) txt('지금!', cx, Math.min(ty, by + bh - 14), Math.min(34, w * 0.1), '#3dff8a', FD);
        else readyText(w, Math.min(ty, by + bh - 14), now, Math.min(30, w * 0.09));
      } else if (m === 4) {
        const s = Math.min(w * 0.3, bh * 0.32);
        ctx.strokeStyle = 'rgba(242,233,216,.12)'; ctx.setLineDash([6, 8]); ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(cx, by + 6); ctx.lineTo(cx, by + bh - 6); ctx.stroke(); ctx.setLineDash([]);
        txt('◀ 왼쪽', 14, by + bh - 14, 13, 'rgba(242,233,216,.45)', FB, 'left');
        txt('오른쪽 ▶', w - 14, by + bh - 14, 13, 'rgba(242,233,216,.45)', FB, 'right');
        if (hit) {
          const k = Math.min(1, (now - (shownAt || now)) / 90);
          const ox = (st.d[1] === 'L' ? -1 : 1) * w * 0.16;
          drawArrow(cx + ox, cy, s * (0.7 + 0.3 * k), st.d[0], '#ee6a55');
        } else {
          const a = 0.5 + 0.5 * Math.sin(now / 150);
          ctx.strokeStyle = 'rgba(238,106,85,' + (0.3 + 0.4 * a) + ')'; ctx.lineWidth = 4;
          ctx.beginPath(); ctx.arc(cx, cy, s * 0.55, 0, 7); ctx.stroke();
          readyText(w, cy, now, Math.min(30, w * 0.09));
        }
      } else if (m === 1) {
        const bellH = Math.min(bh * 0.26, 90);
        const gh = bh - bellH - 6, gw = w - 20;
        const wide = gw > gh * 1.6;
        const cols = wide ? 4 : 2, rows = wide ? 1 : 2;
        let cw = Math.min((gw - (cols - 1) * 10) / cols, ((gh - (rows - 1) * 10) / rows) * 0.72);
        const ch = cw / 0.72;
        const ox = cx - (cols * cw + (cols - 1) * 10) / 2, oy = by + (gh - (rows * ch + (rows - 1) * 10)) / 2;
        const sl = fi >= 0 ? fruitSlots(st.d, fi) : [null, null, null, null];
        for (let i = 0; i < 4; i++) {
          const x = ox + (i % cols) * (cw + 10), y = oy + Math.floor(i / cols) * (ch + 10);
          let flip = null;
          if (fi >= 0 && fi % 4 === i) { const tf = localStart + (st.pre + fi * st.iv) / sp(); flip = Math.min(1, (now - tf) * sp() / 130); }
          if (fi >= 4 && fi % 4 === i && flip < 1) drawCard(fruitSlots(st.d, fi - 4)[i], x, y, cw, ch, null);
          drawCard(sl[i], x, y, cw, ch, flip);
        }
        const rt = seat >= 0 && ring[seat] ? (now - ring[seat]) / 1000 : 9;
        const br = bellH * 0.42;
        drawBell(cx, by + bh - bellH / 2 - 2, br, rt);
        if (fi < 0) readyText(w, oy + rows * ch / 2 + (rows - 1) * 5, now, Math.min(28, w * 0.09));
      } else if (m === 2) {
        if (fi < 0) { readyText(w, cy, now, Math.min(30, w * 0.09)); return; }
        const f = stroopAt(st.d, fi);
        const tf = localStart + (st.pre + fi * st.iv) / sp();
        const k = Math.min(1, (now - tf) * sp() / 90);
        const cwid = Math.min(w - 30, bh * 1.3), chgt = Math.min(bh * 0.62, cwid * 0.62);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(cx - cwid / 2 + 3, cy - chgt / 2 + 5, cwid, chgt, 18); ctx.fill();
        ctx.fillStyle = '#ece3d0'; rr(cx - cwid / 2, cy - chgt / 2, cwid, chgt, 18); ctx.fill();
        const size = fitSize(INKN[f.w], cwid * 0.8, chgt * 0.6, FD) * (0.8 + 0.2 * k);
        ctx.globalAlpha = k; txt(INKN[f.w], cx, cy + 2, size, INK[f.c], FD); ctx.globalAlpha = 1;
      } else if (m === 3) {
        if (fi < 0) { readyText(w, cy, now, Math.min(30, w * 0.09)); return; }
        const f = twinAt(st.d, fi);
        const side = w >= bh * 0.95;
        const s = side ? Math.min((w - 36) / 2, bh * 0.82) : Math.min(w * 0.6, (bh - 18) / 2);
        const tf = localStart + (st.pre + fi * st.iv) / sp();
        const k = Math.min(1, (now - tf) * sp() / 100);
        ctx.globalAlpha = k;
        if (side) { drawTwinCard(f.a, cx - s - 6, cy - s / 2, s); drawTwinCard(f.b, cx + 6, cy - s / 2, s); }
        else { drawTwinCard(f.a, cx - s / 2, cy - s - 6, s); drawTwinCard(f.b, cx - s / 2, cy + 6, s); }
        ctx.globalAlpha = 1;
      }
    }

    function revealRows() {
      const ord = Array.from({ length: st.n }, (_, i) => i);
      const rank = (i) => { const v = st.tp[i]; return v == null ? 1e5 : v < 0 ? 2e5 - v : v; };
      ord.sort((a, b) => rank(a) - rank(b) || a - b);
      return ord;
    }
    function drawReveal(w, by, bh, seat, now) {
      const ord = revealRows();
      const t = (now - revealAt) * sp();
      const step = 150, n = ord.length;
      const title = st.w.length ? (st.w.length > 1 ? '공동 1등!' : api.players[st.w[0]].name + ' 승!') : '이번 라운드 승자 없음';
      const allIn = t > n * step + 100;
      const tsize = fitSize(title, w - 30, Math.min(30, w * 0.09), FD);
      ctx.globalAlpha = Math.min(1, t / 150);
      txt(title, w / 2, by + tsize * 0.75, tsize, st.w.length ? '#e3ae45' : '#ab9fb8', FD);
      ctx.globalAlpha = 1;
      const top = by + tsize * 1.6;
      const rh = Math.min(40, (bh - (top - by) - 6) / n);
      if (rh < 21 && seat >= 0) { // small zone: just my own result, big
        const v = st.tp[seat], cy = top + (by + bh - top) * 0.42, k = Math.min(1, t / 200);
        const lab = v == null ? '미응답' : v < 0 ? badLabel(v, st.m) : v + 'ms';
        const sz = fitSize(lab, w * 0.8, Math.min(w * 0.14, (by + bh - top) * 0.36), '700 ' + FM);
        ctx.globalAlpha = k;
        txt(lab, w / 2, cy, sz, v != null && v < 0 ? '#ff8a7a' : '#f2e9d8', '700 ' + (v != null && v >= 0 ? FM : FB));
        const rank = v != null && v >= 0 ? ord.indexOf(seat) + 1 : 0;
        const sub = (st.w.includes(seat) ? '+1점' : v != null && v < 0 && st.pen ? '−1점' : '') + (rank ? (st.w.includes(seat) ? ' · ' : '') + rank + '위' : '');
        if (sub) txt(sub, w / 2, cy + sz * 0.85, Math.min(15, sz * 0.5), st.w.includes(seat) ? '#e3ae45' : '#ab9fb8', '700 ' + FB);
        ctx.globalAlpha = 1;
        return;
      }
      const maxMs = Math.max(500, ...st.tp.filter((v) => v != null && v >= 0));
      const fs = Math.max(10, Math.min(16, rh * 0.48, w / 21));
      ord.forEach((i, r) => {
        const appear = (n - 1 - r) * step;
        if (t < appear) return;
        const k = Math.min(1, (t - appear) / 140);
        const y = top + r * rh, x = 10 + (1 - k) * 40;
        const v = st.tp[i], win = st.w.includes(i), p = api.players[i];
        ctx.globalAlpha = k;
        ctx.fillStyle = win ? 'rgba(227,174,69,.22)' : i === seat ? 'rgba(242,233,216,.1)' : 'rgba(255,255,255,.04)';
        rr(x, y + 2, w - 20, rh - 4, 8); ctx.fill();
        if (win && allIn) { ctx.strokeStyle = 'rgba(227,174,69,' + (0.5 + 0.5 * Math.sin(now / 120)) + ')'; ctx.lineWidth = 2; rr(x, y + 2, w - 20, rh - 4, 8); ctx.stroke(); }
        const mid = y + rh / 2, W2 = w - 20, xr = x + W2 - 8;
        txt(v != null && v >= 0 ? String(r + 1) : '–', x + 12, mid, fs * 0.9, '#ab9fb8', '600 ' + FM);
        ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(x + 26, mid, Math.min(5, fs * 0.35), 0, 7); ctx.fill();
        const lab = v == null ? '미응답' : v < 0 ? badLabel(v, st.m) : v + 'ms';
        const lc = v == null ? '#ab9fb8' : v < 0 ? '#ff8a7a' : '#f2e9d8';
        const valR = xr - fs * 2, valW = fs * 3.9;
        const avail = valR - valW - (x + 34) - 6;
        const nameW = avail > 170 ? avail * 0.42 : avail;
        txt(p.name, x + 34, mid, fitSize(p.name, nameW, fs, '700 ' + FB), '#f2e9d8', '700 ' + FB, 'left');
        const bx = x + 34 + nameW + 8, bw = avail - nameW - 8;
        if (avail > 170 && v != null && v >= 0) {
          ctx.fillStyle = alpha(p.color, 0.8); rr(bx, mid - 4, Math.max(4, bw * Math.min(1, v / maxMs) * k), 8, 4); ctx.fill();
        }
        if (v != null && v >= 0) txt(lab, valR, mid, fitSize(lab, valW, fs, '600 ' + FM), lc, '600 ' + FM, 'right');
        else txt(lab, valR, mid, fitSize(lab, valW, fs * 0.9, FB), lc, FB, 'right');
        const dl = win ? '+1' : v != null && v < 0 && st.pen ? '−1' : '';
        if (dl) {
          const pop = win && allIn ? 1 + 0.25 * Math.max(0, 1 - (t - n * step - 100) / 250) : 1;
          txt(dl, xr, mid, fs * pop, win ? '#e3ae45' : '#ff8a7a', '700 ' + FM, 'right');
        } else txt(String(st.sc[i]), xr, mid, fs * 0.85, '#ab9fb8', FM, 'right');
        ctx.globalAlpha = 1;
      });
      if (allIn && st.w.length) { // sparks around the title
        const tt = (t - n * step - 100) / 700;
        if (tt < 1) for (let j = 0; j < 14; j++) {
          const a = j / 14 * Math.PI * 2, d = 20 + tt * Math.min(w * 0.45, 140);
          ctx.fillStyle = alpha(api.players[st.w[0]].color, 1 - tt);
          ctx.beginPath(); ctx.arc(w / 2 + Math.cos(a) * d, by + tsize * 0.75 + Math.sin(a) * d * 0.5, 3.5 * (1 - tt) + 1, 0, 7); ctx.fill();
        }
      }
    }
    function drawFinal(w, by, bh, seat) {
      const ord = Array.from({ length: st.n }, (_, i) => i).sort((a, b) => st.sc[b] - st.sc[a] || a - b);
      txt('최종 점수', w / 2, by + 22, Math.min(28, w * 0.09), '#e3ae45', FD);
      const top = by + 50, rh = Math.min(40, (bh - 56) / st.n), fs = Math.max(11, Math.min(17, rh * 0.45));
      const best = st.sc[ord[0]];
      ord.forEach((i, r) => {
        const y = top + r * rh, p = api.players[i];
        ctx.fillStyle = st.sc[i] === best ? 'rgba(227,174,69,.2)' : i === seat ? 'rgba(242,233,216,.1)' : 'rgba(255,255,255,.04)';
        rr(10, y + 2, w - 20, rh - 4, 8); ctx.fill();
        ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(28, y + rh / 2, 6, 0, 7); ctx.fill();
        txt(p.name, 42, y + rh / 2, fitSize(p.name, w * 0.4, fs, '700 ' + FB), '#f2e9d8', '700 ' + FB, 'left');
        if (st.bt[i] >= 0) txt('최고 ' + st.bt[i] + 'ms', w - 70, y + rh / 2, fs * 0.75, '#ab9fb8', FM, 'right');
        txt(String(st.sc[i]), w - 26, y + rh / 2, fs * 1.1, st.sc[i] === best ? '#e3ae45' : '#f2e9d8', '700 ' + FM, 'right');
      });
    }

    /* ---------- loop: events + paint ---------- */
    const stopLoop = U.loop((dt, now) => {
      if (!st) return;
      if (st.ph === 'p') {
        const el = (now - localStart) * sp();
        if (introStep === 0) { introStep = 1; api.sfx('whoosh'); }
        if (introStep === 1 && el >= INTRO) { introStep = 2; api.sfx('tick'); }
        const fi = el >= INTRO ? frameAt(st, el) : -1;
        if (fi !== lastFrame) {
          if (fi === st.k && shownAt == null) {
            shownAt = now;
            if (st.m === 0) { goBeep(); } else if (st.m === 4) api.sfx('pop'); else api.sfx('card');
          } else if (fi >= 0) api.sfx('card');
          lastFrame = fi;
        }
      } else if (st.ph === 'r') {
        const t = (now - revealAt) * sp();
        const n = st.n;
        while (rowsPlayed < n && t >= rowsPlayed * 150) { rowsPlayed++; api.sfx('tick'); }
        if (!winPlayed && t > n * 150 + 100) {
          winPlayed = true;
          const mine = st.w.some((i) => api.canAct(i));
          if (st.w.length) { api.sfx(mine || !locals().length ? 'win' : 'chip'); if (mine) api.buzz(40); }
        }
      }
      draw(now);
    });

    function draw(now) {
      cv.clear();
      ctx.fillStyle = '#120e18'; ctx.fillRect(0, 0, cv.w, cv.h);
      if (!st) return;
      zones.forEach((z) => {
        const d = zoneDims(z);
        ctx.save();
        rr(z.x, z.y, z.w, z.h, isMulti() ? 12 : 0); ctx.clip();
        ctx.translate(z.x + z.w / 2, z.y + z.h / 2); ctx.rotate(z.rot); ctx.translate(-d.w / 2, -d.h / 2);
        drawZone(z, d.w, d.h, now);
        // tap ripple
        const rt = z.seat >= 0 && ring[z.seat] ? (now - ring[z.seat]) / 350 : 9;
        if (rt < 1 && z.seat >= 0) { ctx.strokeStyle = alpha(api.players[z.seat].color, 1 - rt); ctx.lineWidth = 6 * (1 - rt) + 1; rr(3, 3, d.w - 6, d.h - 6, 12); ctx.stroke(); }
        ctx.restore();
      });
    }

    layout();
    return {
      update(next) {
        st = next;
        const k = next.g + ':' + next.q + ':' + next.ph;
        if (k !== key) {
          key = k;
          if (next.ph === 'p') { localStart = performance.now(); shownAt = null; lastFrame = -2; myTap = {}; introStep = 0; }
          if (next.ph === 'r') { revealAt = performance.now(); rowsPlayed = 0; winPlayed = false; }
          setDriver();
        }
        layout();
        renderHud();
      },
      destroy() { stopLoop(); clearTimeout(drv); cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('contextmenu', noCtx); cv.destroy(); hud.remove(); if (actx) { try { actx.close(); } catch (e) {} } },
    };
  }

  L.register({
    id: 'reaction', name: '순발력 대결', tag: '반응속도', cat: '파티',
    blurb: '다섯 가지 반응속도 미니게임을 번갈아 해요. 신호가 오면 누구보다 빨리 탭! 너무 빨리 누르면 실격.',
    quick: [
      '라운드마다 반응속도 미니게임이 하나 나와요. 정답 순간에 가장 먼저 탭하면 +1점!',
      '제목 카드의 한 줄 설명을 읽고 → 「준비…」가 뜨면 집중 → 정답 순간에 내 구역을 탭.',
      '너무 빨리 누르거나 잘못 누르면 그 라운드 탈락(−1점). 라운드가 끝났을 때 점수 1등이 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '다섯 가지 반응속도 미니게임을 번갈아 해요.',
        '라운드마다 가장 빨리 정확하게 탭한 사람이 1점. 점수를 가장 많이 모으면 이겨요.'] },
      { h: '준비', p: [
        '설정에서 라운드 수(5 · 7 · 10, 기본 7), 게임 종류(모두 섞기 · 순발력 · 눈썰미 · 하나만), 실수 벌점(−1점 · 없음)을 골라요.',
        '한 폰을 가운데 두면 사람 수만큼 화면이 나뉘어요. 각자 자기 색 구역을 탭해요(동시에 눌러도 돼요).',
        '온라인이면 각자 자기 폰에서 탭해요.'] },
      { h: '라운드마다 할 일', p: [
        '① 제목 카드에 이번 미니게임 이름과 한 줄 설명이 나와요. 꼭 읽으세요!',
        '② 「준비…」가 뜨면 집중해요. 화면이 바뀌어도 정답 순간이 아니면 참아요.',
        '③ 정답 순간이 오면 바로 탭!',
        '④ 모두 누르면(또는 잠시 뒤) 모두의 반응 시간(ms, 1000ms = 1초)이 공개돼요.'] },
      { h: '점수·승리', p: [
        '라운드에서 가장 빠른 사람 +1점(완전히 같은 기록이면 함께 +1).',
        '정답 순간보다 먼저 누르거나 잘못 누르면 그 라운드는 탈락이에요. 실수 벌점이 「−1점」(기본)이면 1점을 잃어요.',
        '아무도 누르지 않으면 잠시 뒤 라운드가 자동으로 끝나요.',
        '정해진 라운드가 끝나면 점수가 가장 높은 사람이 승리, 같으면 공동 승리예요.'] },
      { h: '미니게임 5가지', p: [
        '신호등: 빨간불이 초록불로 바뀌는 순간 탭. 빨간불에 누르면 부정 출발.',
        '과일 종: 네 자리에 카드가 차례로 한 장씩 펼쳐지고, 다 차면 가장 오래된 카드 위에 새 카드가 덮여요. 보이는 카드에서 같은 과일이 모두 합쳐 정확히 5개가 되면 탭(종 울리기). 4개나 6개일 때 누르면 잘못 누름.',
        '색과 글자: 색 이름(빨강 · 파랑 …)이 여러 색 글씨로 바뀌어요. 글자 뜻과 글자색이 같을 때만 탭. 예: 빨간 글씨 「빨강」 = 탭! 파란 글씨 「빨강」 = 참기.',
        '쌍둥이 그림: 두 카드의 그림 네 개가 위치까지 완전히 같아지면 탭.',
        '화살표: 화살표가 나오면 가리키는 쪽 절반(왼쪽/오른쪽)을 탭. 화살표가 놓인 위치에 속지 마세요. 반대쪽을 누르면 탈락.'] },
      { h: '조작', p: [
        '한 폰: 내 색 구역 아무 데나 탭해요. 화살표 게임만 내 구역의 왼쪽/오른쪽 절반을 골라 탭해요.',
        '온라인: 화면 아무 데나 탭(화살표는 왼쪽/오른쪽 절반). 반응 시간은 각 폰이 화면에 신호를 띄운 순간부터 재요.'] },
      { h: '예시', p: [
        '과일 종 라운드: 펼쳐진 카드가 사과 2 · 바나나 3 · 사과 2 → 사과가 4개라서 아직 참아요.',
        '네 번째 자리에 사과 1이 펼쳐지면 사과가 딱 5개! → 탭. 내가 312ms로 가장 빨라서 +1점.',
        '그 전에 성급하게 누른 사람은 「잘못 누름」으로 탈락, −1점이에요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(반응 속도와 부정 출발·멍때림 확률이 달라요).'] },
    ],
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, aiDelay: 400,
    options: [
      { id: 'rounds', label: '라운드 수', choices: [{ v: 5, label: '5' }, { v: 7, label: '7' }, { v: 10, label: '10' }], def: 7 },
      { id: 'set', label: '게임 종류', def: 'all', choices: [
        { v: 'all', label: '모두 섞기' }, { v: 'quick', label: '순발력(신호등·화살표)' }, { v: 'eye', label: '눈썰미(과일·색·그림)' },
        { v: '0', label: '신호등' }, { v: '1', label: '과일 종' }, { v: '2', label: '색과 글자' }, { v: '3', label: '쌍둥이 그림' }, { v: '4', label: '화살표' }] },
      { id: 'pen', label: '실수 벌점', def: 1, choices: [{ v: 1, label: '−1점' }, { v: 0, label: '없음(탈락만)' }] },
    ],
    init, actor, apply, result, ai, aiDelayFor, mount,
    _t: { tgt, dline, revealMs, frameAt, fruitSlots, fruitTotals, fruitHit, stroopAt, twinAt, aiPlan, newRound, INTRO, SETS },
  });
})();
