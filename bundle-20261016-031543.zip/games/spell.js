/* 마법진 결투 — simultaneous-round wizard duel (2–4 wizards, free-for-all when 3–4).
   Every round all living wizards secretly draw a rune pattern on a 3×3 grid (= pick a spell), then all spells are revealed
   and resolved at once: element triangle 물살 ▶ 불꽃 ▶ 덩굴 ▶ 물살, 방패/거울 defence, 번개 pierces the shield, mana + HP.
   State (JSON, tiny): { n, mx (max HP), tl (time limit s), hp[], m[], ch[] (scrambled choice | null), r, ph 'c'|'e', w[],
                         seq, last, hs[] (recent spells per seat), la[] (who last hurt each seat) }
   last = { id, r, k[] (spell per seat, -1 = out), t[] (target per seat), a: [[src, tgt, spell, dmg, flags, hitSeat]...],
            ph[] / pm[] (HP / mana before the round), dead[] (seats that fell this round) } */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- spells ---------- */
  const MMAX = 10, M0 = 3, REGEN = 2, RMAX = 30, STORM0 = 10, HEAL = 4, FOCUS_GAIN = 2, DRAIN = 2;
  const F = { WIN: 1, LOST: 2, TIE: 4, REFL: 8, BLOCK: 16, HALF: 32, VULN: 64 };
  // rune grid: 0 1 2 / 3 4 5 / 6 7 8 — `p` is a one-stroke path (straight passes through a middle rune include it)
  const SP = [
    { id: 'focus', n: '기 모으기', c: 0, p: [1, 4, 7], col: '#8fb8ff', d: '마나 +2 더 (모두 +4). 대신 이번에 맞으면 피해 +1' },
    { id: 'fire', n: '불꽃', c: 2, dm: 4, el: 'f', p: [1, 6, 8, 1], col: '#ff7a3d', d: '피해 4 · 덩굴을 이겨요' },
    { id: 'water', n: '물살', c: 2, dm: 4, el: 'w', p: [0, 2, 7, 0], col: '#45b0ff', d: '피해 4 · 불꽃을 이겨요' },
    { id: 'vine', n: '덩굴', c: 2, dm: 4, el: 'l', p: [1, 5, 7, 3, 1], col: '#5fcf6c', d: '피해 4 · 물살을 이겨요' },
    { id: 'bolt', n: '번개', c: 3, dm: 5, p: [1, 3, 5, 7], col: '#ffe04a', d: '피해 5 · 방패를 뚫어요' },
    { id: 'frost', n: '서리', c: 2, dm: 3, p: [6, 0, 8, 2], col: '#a4ecff', d: '피해 3 + 상대 마나 −2' },
    { id: 'shield', n: '방패', c: 1, p: [6, 3, 1, 5, 8], col: '#e3ae45', d: '공격을 막아요 (번개는 못 막고, 별똥별은 반만)' },
    { id: 'mirror', n: '거울', c: 3, p: [0, 2, 6, 8, 0], col: '#c8b6ff', d: '받은 공격을 쏜 사람에게 그대로 되돌려요' },
    { id: 'heal', n: '치유', c: 3, p: [0, 2, 8, 6, 0], col: '#7dffb0', d: '체력 +4' },
    { id: 'meteor', n: '별똥별', c: 4, dm: 8, p: [6, 1, 8, 3, 5, 6], col: '#ff5a8a', d: '피해 8 · 방패에 막혀도 반은 들어가요' },
  ];
  const FOCUS = 0, BOLT = 4, FROST = 5, SHIELD = 6, MIRROR = 7, HEALK = 8, METEOR = 9;
  const BEAT = { w: 'f', f: 'l', l: 'w' };   // key beats value
  const ELN = { f: '불꽃', w: '물살', l: '덩굴' };

  /* rune geometry: straight lines through a middle rune pass through it (like a phone unlock pattern) */
  const MID = {};
  [[0, 2, 1], [3, 5, 4], [6, 8, 7], [0, 6, 3], [1, 7, 4], [2, 8, 5], [0, 8, 4], [2, 6, 4]].forEach(([a, b, m]) => { MID[a * 9 + b] = m; MID[b * 9 + a] = m; });
  const ekey = (a, b) => (a < b ? a * 9 + b : b * 9 + a);
  /* expand a rune path (inserting passed-through runes) → sorted unique edge keys */
  function edgesOf(path) {
    const set = new Set();
    for (let i = 1; i < path.length; i++) {
      const a = path[i - 1], b = path[i];
      if (a === b) continue;
      const m = MID[a * 9 + b];
      if (m != null) { set.add(ekey(a, m)); set.add(ekey(m, b)); } else set.add(ekey(a, b));
    }
    return [...set].sort((x, y) => x - y);
  }
  SP.forEach((S) => { S.e = edgesOf(S.p); S.ek = S.e.join(','); });
  /* which spell does this drawn edge list make? (-1 = none) */
  function match(edges) { const k = edges.slice().sort((x, y) => x - y).join(','); return SP.findIndex((S) => S.ek === k); }
  /* best spell this partial drawing could still become: { k, miss: [edge keys still missing] } or null */
  function guess(edges) {
    if (!edges.length) return null;
    let best = null;
    SP.forEach((S, k) => {
      if (!edges.every((e) => S.e.includes(e))) return;
      const miss = S.e.filter((e) => !edges.includes(e));
      if (!best || miss.length < best.miss.length) best = { k, miss };
    });
    return best;
  }

  /* ---------- hidden choices (lightly scrambled; the view never shows them before the reveal) ---------- */
  const enc = (s, i, k, t) => String.fromCharCode(65 + ((k * 5 + t + 1 + 7 * i + 3 * s.r) % 50));
  function dec(s, i) {
    const x = s.ch[i];
    if (x == null) return null;
    const v = (((x.charCodeAt(0) - 65 - 7 * i - 3 * s.r) % 50) + 50) % 50;
    return { k: Math.floor(v / 5), t: (v % 5) - 1 };
  }

  /* ---------- rules ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(2, Math.min(4, players.length));
    const mx = [15, 20, 30].includes(opts.hp) ? opts.hp : 20;
    const tl = [0, 20, 10].includes(opts.tl) ? opts.tl : 20;
    return {
      n, mx, tl, hp: Array(n).fill(mx), m: Array(n).fill(M0), ch: Array(n).fill(null), r: 0, ph: 'c', w: null,
      seq: 0, last: null, hs: Array(n).fill(''), la: Array(n).fill(-1),
    };
  }
  const alive = (s, i) => s.hp[i] > 0;
  const aliveList = (s) => { const r = []; for (let i = 0; i < s.n; i++) if (s.hp[i] > 0) r.push(i); return r; };
  /* every living wizard is listed while choosing (so the core never puts up its single-seat curtain); seats that already chose are rejected */
  function actor(s) { return s.ph === 'c' ? aliveList(s) : null; }

  /* resolve one round from plain arrays (shared by apply and the AI) */
  /* 마력 폭풍: from round 11 every wizard loses 1 HP per round (2 from round 16, 3 from round 21) so duels always end */
  const storm = (r) => (r < STORM0 ? 0 : r < STORM0 + 5 ? 1 : r < STORM0 + 10 ? 2 : 3);
  function outcome(n, hp, m, ks, ts, mx, r) {
    const at = [];
    for (let i = 0; i < n; i++) { const k = ks[i]; if (k >= 0 && hp[i] > 0 && SP[k].dm) at.push([i, ts[i], k, SP[k].dm, 0, -1]); }
    // element clash: two wizards who aim at each other with element spells
    for (let a = 0; a < at.length; a++) for (let b = a + 1; b < at.length; b++) {
      const A = at[a], B = at[b];
      if (A[0] !== B[1] || B[0] !== A[1]) continue;
      const ea = SP[A[2]].el, eb = SP[B[2]].el;
      if (!ea || !eb) continue;
      if (ea === eb) { A[4] |= F.TIE; B[4] |= F.TIE; }
      else if (BEAT[ea] === eb) { A[3]++; A[4] |= F.WIN; B[4] |= F.LOST; }
      else { B[3]++; B[4] |= F.WIN; A[4] |= F.LOST; }
    }
    const dmg = Array(n).fill(0), drain = Array(n).fill(0);
    for (const A of at) {
      if (A[4] & (F.LOST | F.TIE)) { A[3] = 0; continue; }
      const T = A[1], tk = ks[T];
      let d = A[3], hit = T;
      if (tk === MIRROR) { A[4] |= F.REFL; hit = A[0]; }
      else if (tk === SHIELD) {
        if (A[2] === METEOR) { d = Math.floor(d / 2); A[4] |= F.HALF; }
        else if (A[2] !== BOLT) { d = 0; A[4] |= F.BLOCK; }
      } else if (tk === FOCUS) { d++; A[4] |= F.VULN; }
      A[3] = d; A[5] = hit;
      dmg[hit] += d;
      if (A[2] === FROST && d > 0) drain[hit] += DRAIN;
    }
    const nhp = hp.slice(), nm = m.slice(), raw = hp.slice(), st = storm(r || 0);
    for (let i = 0; i < n; i++) {
      if (hp[i] <= 0) continue;
      const k = ks[i] < 0 ? FOCUS : ks[i];
      raw[i] = Math.min(mx, hp[i] - dmg[i] + (k === HEALK ? HEAL : 0)) - st;
      nhp[i] = Math.max(0, raw[i]);
      nm[i] = Math.max(0, Math.min(MMAX, m[i] - SP[k].c + REGEN + (k === FOCUS ? FOCUS_GAIN : 0) - drain[i]));
    }
    return { hp: nhp, m: nm, at, dmg, drain, raw, st };
  }

  function legalTargets(s, seat) { return aliveList(s).filter((j) => j !== seat); }
  function apply(s, seat, a) {
    if (s.ph !== 'c') throw new Error('not choosing');
    if (!alive(s, seat)) throw new Error('out');
    if (s.ch[seat] != null) throw new Error('already chose');
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const k = a.k | 0;
    if (!(k >= 0 && k < SP.length) || a.k !== k) throw new Error('bad spell');
    if (SP[k].c > s.m[seat]) throw new Error('not enough mana');
    let t = -1;
    if (SP[k].dm) {
      const tg = legalTargets(s, seat);
      t = tg.length === 1 ? tg[0] : (a.t | 0);
      if (!tg.includes(t)) throw new Error('bad target');
    }
    s.ch[seat] = enc(s, seat, k, t);
    if (aliveList(s).every((i) => s.ch[i] != null)) resolve(s);
    return s;
  }
  function resolve(s) {
    const n = s.n, ks = Array(n).fill(-1), ts = Array(n).fill(-1);
    for (let i = 0; i < n; i++) if (alive(s, i)) { const c = dec(s, i); ks[i] = c.k; ts[i] = c.t; }
    const o = outcome(n, s.hp, s.m, ks, ts, s.mx, s.r);
    const dead = [];
    for (let i = 0; i < n; i++) if (s.hp[i] > 0 && o.hp[i] <= 0) dead.push(i);
    o.at.forEach((A) => { if (A[3] > 0 && A[5] !== A[0]) s.la[A[5]] = A[0]; else if (A[3] > 0 && A[5] === A[0]) s.la[A[0]] = A[1]; });
    s.last = { id: ++s.seq, r: s.r, k: ks, t: ts, a: o.at, ph: s.hp.slice(), pm: s.m.slice(), dead, st: o.st };
    for (let i = 0; i < n; i++) if (ks[i] >= 0) s.hs[i] = (s.hs[i] + ks[i]).slice(-8);
    s.hp = o.hp; s.m = o.m; s.ch = Array(n).fill(null); s.r++;
    const al = aliveList(s);
    if (!al.length) {
      // everyone left fell together: the one who stayed least below zero wins (exact tie = draw)
      const top = Math.max(...dead.map((i) => o.raw[i])), best = dead.filter((i) => o.raw[i] === top);
      s.ph = 'e'; s.w = best.length === 1 ? best : []; s.tz = 1;
    } else if (al.length === 1) { s.ph = 'e'; s.w = al; }
    else if (s.r >= RMAX) {
      const top = Math.max(...al.map((i) => s.hp[i]));
      s.ph = 'e'; s.w = al.filter((i) => s.hp[i] === top); s.tm = 1;
    }
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const w = s.w || [];
    if (!w.length) return { winners: [], title: '무승부', text: '마지막 마법사들이 똑같이 쓰러졌어요 · ' + s.r + '라운드' };
    if (s.tz) return { winners: w.slice(), text: '모두 함께 쓰러졌지만 덜 다친 쪽이 이겼어요 · ' + s.r + '라운드' };
    const txt = s.tm ? RMAX + '라운드가 끝나 남은 체력으로 정했어요' : s.r + '라운드 만에 결투 끝';
    return { winners: w.slice(), text: txt + ' · 남은 체력 ' + s.hp[w[0]] };
  }

  /* ---------- AI ---------- */
  const BASE_W = [0.6, 1, 1, 1, 0.8, 0.6, 0.8, 0.5, 0.3, 1.4];
  function choices(s, seat) {
    const out = [], tg = legalTargets(s, seat);
    SP.forEach((S, k) => {
      if (S.c > s.m[seat]) return;
      if (S.dm) tg.forEach((t) => out.push({ k, t })); else out.push({ k, t: -1 });
    });
    return out;
  }
  /* naive guess of what wizard j might play: any spell they can afford, with a mild taste for attacks → [{k,t,w}] */
  function prior(s, j) {
    const tg = legalTargets(s, j), out = [];
    const low = Math.min(...tg.map((t) => s.hp[t]));
    SP.forEach((S, k) => {
      if (S.c > s.m[j]) return;
      if (!S.dm) { out.push({ k, t: -1, w: BASE_W[k] }); return; }
      const tw = tg.map((t) => 1 + (s.hp[t] === low ? 1 : 0) + (s.la[j] === t ? 1 : 0));
      const tws = tw.reduce((x, y) => x + y, 0);
      tg.forEach((t, q) => out.push({ k, t, w: BASE_W[k] * tw[q] / tws }));
    });
    return out;
  }
  function pickW(list) {
    let sum = 0; for (const x of list) sum += x.w;
    let r = Math.random() * sum;
    for (const x of list) { r -= x.w; if (r <= 0) return x; }
    return list[list.length - 1];
  }
  function value(o, s, seat, lv) {
    const me = o.hp[seat], mm = o.m[seat];
    let v = me + Math.min(me, 6) * 0.6 + (Math.min(mm, 6) + Math.max(0, mm - 6) * 0.3) * (lv >= 3 ? 0.5 : 0.42);
    if (me <= 0) v -= 50;
    const opp = legalTargets(s, seat), wt = 1 / opp.length;
    for (const j of opp) {
      const h = o.hp[j];
      v -= (h + Math.min(h, 6) * 0.6 + o.m[j] * 0.3) * wt;
      if (h <= 0) v += (opp.length === 1 ? 50 : 14);
    }
    return v;
  }
  /* expected value of each of my choices against sampled guesses of the others → softmax weights */
  function evalChoices(s, seat, lv, dist, K, T) {
    const others = legalTargets(s, seat), n = s.n, ch = choices(s, seat), samples = [];
    for (let q = 0; q < K; q++) {
      const ks = Array(n).fill(-1), ts = Array(n).fill(-1);
      others.forEach((j) => { const p = pickW(dist[j]); ks[j] = p.k; ts[j] = p.t; });
      samples.push([ks, ts]);
    }
    const ev = ch.map((c) => {
      let tot = 0;
      for (const [ks, ts] of samples) { ks[seat] = c.k; ts[seat] = c.t; tot += value(outcome(n, s.hp, s.m, ks, ts, s.mx, s.r), s, seat, lv); }
      return tot / K;
    });
    const top = Math.max(...ev);
    return ch.map((c, q) => ({ k: c.k, t: c.t, w: Math.exp((ev[q] - top) / T) }));
  }
  /* 어려움: "what would a sensible wizard do in j's shoes?" (their HP · mana · my mana), blended with j's habits so far */
  function readOpponent(s, j) {
    const dist = {};
    legalTargets(s, j).forEach((o) => { dist[o] = prior(s, o); });
    const pol = evalChoices(s, j, 2, dist, 18, 1.2);
    let ps = 0; pol.forEach((x) => { ps += x.w; });
    const hs = s.hs[j] || '', freq = Array(SP.length).fill(0);
    for (let q = 0; q < Math.min(6, hs.length); q++) freq[+hs[hs.length - 1 - q]] += q === 0 ? 1.5 : 1;
    const habit = pol.map((x) => freq[x.k] / (SP[x.k].dm ? Math.max(1, legalTargets(s, j).length) : 1));
    let hsum = 0; habit.forEach((x) => { hsum += x; });
    const mix = hs.length >= 3 && hsum > 0 ? 0.3 : 0;
    return pol.map((x, q) => ({ k: x.k, t: x.t, w: (1 - mix) * x.w / ps + (mix ? mix * habit[q] / hsum : 0) + 0.01 }));
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph !== 'c' || s.ch[seat] != null || !alive(s, seat)) return null;
    if (lv <= 1) {
      // 쉬움: likes flashy attacks and hardly thinks about the opponent
      const list = choices(s, seat).map((c) => {
        let w = BASE_W[c.k];
        if (SP[c.k].dm) w *= 1.4;
        if (c.k === METEOR) w += 2;
        if (c.k === FOCUS) w = s.m[seat] < 2 ? 3 : 0.5;
        if (c.k === HEALK && s.hp[seat] < s.mx * 0.4) w += 1;
        return { k: c.k, t: c.t, w };
      });
      const p = pickW(list);
      return { k: p.k, t: p.t };
    }
    const dist = {};
    legalTargets(s, seat).forEach((j) => { dist[j] = lv >= 3 ? readOpponent(s, j) : prior(s, j); });
    const p = pickW(evalChoices(s, seat, lv, dist, lv >= 3 ? 64 : 28, lv >= 3 ? 0.45 : 1.1));
    return { k: p.k, t: p.t };
  }
  /* "drawing" time: the AI shows as busy drawing for a moment */
  function aiDelayFor(s, seat, lv) {
    if (s.ph !== 'c' || s.ch[seat] != null || !alive(s, seat)) return -1;
    const base = lv >= 3 ? 1500 : lv <= 1 ? 2600 : 2000;
    return base + Math.random() * 1300;
  }

  /* ---------- sound (own tiny synth; follows the app's sound switch) ---------- */
  const Snd = {
    ac: null, nb: null,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    tone(f, d, type, vol, f2, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
        o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
        if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.1, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + d + 0.03);
      } catch (e) {}
    },
    noise(d, type, f0, f1, vol, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        if (!this.nb) { const n = ac.sampleRate * 1.5, b = ac.createBuffer(1, n, ac.sampleRate), x = b.getChannelData(0); for (let i = 0; i < n; i++) x[i] = Math.random() * 2 - 1; this.nb = b; }
        const t = ac.currentTime + (delay || 0), src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.nb; f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + d); f.Q.value = 0.8;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + d + 0.05);
      } catch (e) {}
    },
    rune(i) { const sc = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21]; this.tone(392 * Math.pow(2, sc[Math.min(i, 9)] / 12), 0.16, 'triangle', 0.09); },
    ready() { [0, 4, 7, 12].forEach((s, i) => this.tone(523 * Math.pow(2, s / 12), 0.22, 'sine', 0.07, 0, i * 0.05)); },
    cast() { this.noise(0.35, 'bandpass', 300, 2400, 0.12); },
    spell(k) {
      switch (SP[k].id) {
        case 'focus': this.tone(260, 0.6, 'sine', 0.1, 820); break;
        case 'fire': this.noise(0.55, 'lowpass', 1600, 300, 0.22); this.tone(180, 0.3, 'sawtooth', 0.04, 90); break;
        case 'water': this.noise(0.6, 'bandpass', 380, 1400, 0.2); break;
        case 'vine': this.tone(196, 0.3, 'triangle', 0.1, 330); this.noise(0.35, 'highpass', 1800, 900, 0.07); break;
        case 'bolt': this.noise(0.18, 'highpass', 3000, 1200, 0.3); this.tone(1400, 0.25, 'sawtooth', 0.06, 120); break;
        case 'frost': this.tone(1760, 0.5, 'sine', 0.05, 2640); this.tone(2350, 0.4, 'sine', 0.035, 0, 0.08); break;
        case 'shield': this.tone(165, 0.6, 'sine', 0.14, 175); this.tone(330, 0.5, 'triangle', 0.05); break;
        case 'mirror': this.tone(1320, 0.5, 'sine', 0.08); this.tone(1980, 0.45, 'sine', 0.05, 0, 0.06); break;
        case 'heal': [0, 4, 7, 12].forEach((s, i) => this.tone(392 * Math.pow(2, s / 12), 0.35, 'sine', 0.07, 0, i * 0.08)); break;
        case 'meteor': this.noise(1.1, 'lowpass', 900, 120, 0.26); this.tone(110, 1.0, 'sawtooth', 0.05, 40); break;
      }
    },
    boom(big) { this.noise(big ? 0.7 : 0.35, 'lowpass', big ? 700 : 1200, 80, big ? 0.32 : 0.2); this.tone(big ? 90 : 140, big ? 0.5 : 0.25, 'sine', 0.22, 45); },
    clash() { this.noise(0.5, 'bandpass', 2400, 300, 0.25); this.tone(620, 0.2, 'square', 0.04, 200); },
    ping() { this.tone(2200, 0.25, 'sine', 0.08, 1500); },
    storm() { this.noise(0.9, 'lowpass', 500, 90, 0.2); this.tone(70, 0.8, 'sawtooth', 0.04, 50); },
    tick() { this.tone(1200, 0.05, 'square', 0.035); },
  };

  /* ---------- drawing helpers (shared by canvas + book icons) ---------- */
  const node = (i) => [(i % 3) - 1, Math.floor(i / 3) - 1];
  function sigil(ctx, k, x, y, size, col, alpha, lw) {
    const g = size * 0.36;
    ctx.save(); ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.fillStyle = 'rgba(242,233,216,0.35)';
    for (let i = 0; i < 9; i++) { const [c, r] = node(i); ctx.beginPath(); ctx.arc(x + c * g, y + r * g, Math.max(1.2, size * 0.045), 0, 7); ctx.fill(); }
    ctx.strokeStyle = col; ctx.lineWidth = lw || Math.max(1.6, size * 0.07); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.shadowColor = col; ctx.shadowBlur = size * 0.18;
    ctx.beginPath();
    SP[k].p.forEach((p, q) => { const [c, r] = node(p); if (q) ctx.lineTo(x + c * g, y + r * g); else ctx.moveTo(x + c * g, y + r * g); });
    ctx.stroke(); ctx.restore();
  }
  function rr(ctx, x, y, w, hh, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + hh, r); ctx.arcTo(x + w, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  const FONT = '"IBM Plex Sans KR", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif';
  const DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const MONO = '"IBM Plex Mono", ui-monospace, monospace';

  const CSS = `
.sp-bot{position:absolute;left:0;right:0;bottom:0;display:flex;gap:8px;padding:8px 12px;z-index:3}
.sp-bot .btn{min-height:48px;padding:0 10px;font-size:15px}
.sp-bot .sp-book{flex:1}.sp-bot .sp-clear{flex:0 0 72px}.sp-bot .sp-cast{flex:1.35}
.sp-cast.ready{animation:spPulse 1s ease-in-out infinite}
@keyframes spPulse{0%,100%{box-shadow:0 0 0 0 rgba(227,174,69,.55)}50%{box-shadow:0 0 0 7px rgba(227,174,69,0)}}
.sp-spot{position:absolute;pointer-events:none;border-radius:16px}
.sp-ov{position:absolute;inset:0;z-index:15;background:rgba(10,8,15,.8);display:flex;align-items:flex-end;justify-content:center;padding:10px;animation:fade .15s ease-out}
.sp-sheet{background:var(--surface);border:1px solid var(--line);border-radius:18px;width:min(440px,100%);max-height:100%;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px}
.sp-sheet>*{flex:none}
.sp-sheet h3{font-family:var(--f-display);font-weight:400;font-size:22px;margin:0}
.sp-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.sp-x{min-width:44px;min-height:44px;border-radius:12px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-size:18px;cursor:pointer}
.sp-tri{font-size:13px;line-height:1.45;background:var(--surface-2);border-radius:12px;padding:8px 10px;color:var(--muted)}
.sp-tri b{font-weight:700}
.sp-row{display:grid;grid-template-columns:52px 1fr auto;gap:10px;align-items:center;padding:6px 10px 6px 6px;border-radius:12px;background:var(--surface-2);border:1px solid transparent;min-height:60px;text-align:left;color:var(--ink);font:inherit;width:100%;cursor:pointer}
.sp-row:active{transform:scale(.98)}
.sp-row.off{opacity:.42}
.sp-row canvas{width:52px;height:52px;border-radius:10px;background:#140f1d}
.sp-row .nm{font-weight:700;font-size:15px}.sp-row .ds{font-size:12px;color:var(--muted);line-height:1.35}
.sp-mana{font-family:var(--f-mono);font-size:13px;font-weight:700;color:#9cc4ff;background:rgba(80,130,255,.14);border-radius:8px;padding:3px 7px;white-space:nowrap}
.sp-note{font-size:12px;color:var(--muted);line-height:1.45;margin:2px 2px 0}
.sp-hand{position:absolute;inset:0;z-index:14;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:24px;background:radial-gradient(circle at 50% 40%,#2c2142,#120e19 70%)}
.sp-hand .big{font-family:var(--f-display);font-size:30px}
.sp-hand .btn{min-width:200px;min-height:52px;font-size:17px}
`;

  /* ---------- view ---------- */
  function mount(root, api) {
    const h = L.h;
    const style = h('style', { text: CSS });
    root.appendChild(style);
    const cv = U.canvas(root), ctx = cv.ctx;
    const bookBtn = h('button', { class: 'btn sp-book', type: 'button', text: '📖 주문책' });
    const clearBtn = h('button', { class: 'btn sp-clear', type: 'button', text: '지우기' });
    const castBtn = h('button', { class: 'btn primary sp-cast', type: 'button', text: '✨ 시전' });
    const bot = h('div', { class: 'sp-bot' }, bookBtn, clearBtn, castBtn);
    const spotGrid = h('div', { class: 'sp-spot sp-gridbox' }), spotMe = h('div', { class: 'sp-spot sp-mebox' }), spotOpp = h('div', { class: 'sp-spot sp-oppbox' });
    root.append(spotGrid, spotMe, spotOpp, bot);

    let st = null, dead = false, anim = null, seenId = -1, revealed = -1, handEl = null, handKey = '', bookEl = null;
    let path = [], edges = [], dragging = false, fx = 0, fy = 0, target = -1, lockK = -1, trace = null;
    let tKey = '', tStart = 0, tPause = 0, lastTick = -1, ovCheck = 0, ovOpen = false, shake = 0, flash = 0, roundBanner = 0;
    const sent = {}, hitT = {}, parts = [], timers = new Set();
    const shownHP = [], shownM = [];
    const Lay = { W: 0, H: 0, cx: 0, cy: 0, R: 100, g: 30, hitR: 12, OZ: 150, MYy: 0, PVy: 0, slots: [], bg: null, bgKey: '' };
    const spd = () => L.debug.speed || 1;
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms); timers.add(t); return t; };
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const multi = () => !api.online && api.mySeats().length >= 2;
    let busy = false;
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }

    /* ---- whose screen / who draws ---- */
    function pendingLocal() {
      if (!st || st.ph !== 'c' || anim) return [];
      const r = [];
      for (let i = 0; i < st.n; i++) if (api.canAct(i) && st.hp[i] > 0 && st.ch[i] == null && sent[i] !== st.r) r.push(i);
      return r;
    }
    function drawer() {
      const p = pendingLocal();
      if (!p.length) return -1;
      if (multi()) return p.includes(revealed) ? revealed : -1;
      return p[0];
    }
    function persp() {
      if (multi() && revealed >= 0 && st && st.hp[revealed] > 0 && !anim) return revealed;
      const m = api.mySeats();
      return m.length ? m[0] : 0;
    }
    function opps() { const p = persp(), r = []; for (let q = 1; q < (st ? st.n : 2); q++) r.push((p + q) % st.n); return r; }

    /* ---- layout ---- */
    function layout() {
      const W = cv.w, H = cv.h, BB = 64, MY = 42, PV = 36;
      const D = Math.max(170, Math.min(W - 36, H - BB - MY - PV - 150 - 6, 330));
      Lay.W = W; Lay.H = H; Lay.R = D / 2; Lay.cx = W / 2; Lay.cy = H - BB - D / 2 - 4;
      Lay.g = D * 0.29; Lay.hitR = Lay.g * 0.42;
      Lay.MYy = Lay.cy - Lay.R - MY; Lay.PVy = Lay.MYy - PV; Lay.OZ = Math.max(110, Lay.PVy);
      const os = st ? opps() : [1], k = os.length, sw = W / k;
      const sc = Math.max(0.5, Math.min(1.15, (Lay.OZ - 62) / 108, sw / 120)), feet = Lay.OZ - 8;
      Lay.hudY = Math.max(4, Math.round(feet - 106 * sc - 60));
      Lay.slots = os.map((seat, q) => ({ seat, x: sw * (q + 0.5), x0: sw * q, w: sw, feet, sc, chest: feet - 50 * sc }));
      const place = (el, x, y, w, hh) => { el.style.left = x + 'px'; el.style.top = y + 'px'; el.style.width = w + 'px'; el.style.height = hh + 'px'; };
      place(spotGrid, Lay.cx - Lay.R - 6, Lay.cy - Lay.R - 6, D + 12, D + 12);
      place(spotMe, 8, Lay.MYy, W - 16, MY);
      place(spotOpp, 6, 4, W - 12, Lay.OZ - 4);
      const key = W + 'x' + H + ':' + cv.dpr + ':' + k + ':' + D;
      if (key !== Lay.bgKey) { Lay.bgKey = key; buildBg(); }
    }
    function posOf(seat) {
      if (seat === persp()) return { x: Lay.cx, y: Lay.cy - Lay.R * 0.15 };
      const s = Lay.slots.find((q) => q.seat === seat);
      return s ? { x: s.x, y: s.chest } : { x: Lay.cx, y: 40 };
    }

    /* ---- cached background: night sky, stone stage, the magic circle ---- */
    function buildBg() {
      const dpr = cv.dpr, W = Lay.W, H = Lay.H;
      const c = document.createElement('canvas'); c.width = Math.ceil(W * dpr); c.height = Math.ceil(H * dpr);
      const b = c.getContext('2d'); b.scale(dpr, dpr);
      const sky = b.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, '#1b1430'); sky.addColorStop(0.45, '#1a1426'); sky.addColorStop(1, '#100c17');
      b.fillStyle = sky; b.fillRect(0, 0, W, H);
      let seed = 7; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      for (let i = 0; i < 70; i++) { b.fillStyle = 'rgba(242,233,216,' + (0.15 + rnd() * 0.5).toFixed(2) + ')'; b.beginPath(); b.arc(rnd() * W, rnd() * Lay.OZ * 0.8, rnd() * 1.3 + 0.3, 0, 7); b.fill(); }
      // moon (only when a single opponent leaves the corner free)
      if (Lay.slots.length === 1) {
      b.fillStyle = 'rgba(242,233,216,0.08)'; b.beginPath(); b.arc(W * 0.86, Lay.OZ * 0.18, 26, 0, 7); b.fill();
      b.fillStyle = 'rgba(242,233,216,0.5)'; b.beginPath(); b.arc(W * 0.86, Lay.OZ * 0.18, 12, 0, 7); b.fill();
      b.fillStyle = '#1b1430'; b.beginPath(); b.arc(W * 0.86 + 5, Lay.OZ * 0.18 - 3, 11, 0, 7); b.fill();
      }
      // far towers silhouette
      b.fillStyle = '#150f22';
      b.beginPath(); b.moveTo(0, Lay.OZ - 30);
      for (let x = 0; x <= W; x += 24) b.lineTo(x, Lay.OZ - 34 - (Math.sin(x * 0.05) * 10 + 8 * ((x / 24) % 3 === 0 ? 2 : 0)));
      b.lineTo(W, Lay.OZ + 10); b.lineTo(0, Lay.OZ + 10); b.fill();
      // stone floor of the arena
      const fl = b.createLinearGradient(0, Lay.OZ - 26, 0, H);
      fl.addColorStop(0, '#2a2236'); fl.addColorStop(0.3, '#201a2b'); fl.addColorStop(1, '#130f1b');
      b.fillStyle = fl; b.fillRect(0, Lay.OZ - 26, W, H - Lay.OZ + 26);
      b.strokeStyle = 'rgba(242,233,216,0.04)'; b.lineWidth = 1;
      for (let y = Lay.OZ - 10; y < H; y += 22) { b.beginPath(); b.moveTo(0, y); b.lineTo(W, y); b.stroke(); }
      // platforms under the opponents
      Lay.slots.forEach((s) => {
        b.save(); b.translate(s.x, s.feet); b.scale(1, 0.3);
        const pg = b.createRadialGradient(0, 0, 4, 0, 0, 44 * s.sc + 10);
        pg.addColorStop(0, 'rgba(200,182,255,0.22)'); pg.addColorStop(1, 'rgba(200,182,255,0)');
        b.fillStyle = pg; b.beginPath(); b.arc(0, 0, 44 * s.sc + 10, 0, 7); b.fill();
        b.strokeStyle = 'rgba(227,174,69,0.35)'; b.lineWidth = 2.5; b.beginPath(); b.arc(0, 0, 36 * s.sc + 6, 0, 7); b.stroke();
        b.restore();
      });
      // my magic circle
      const cx = Lay.cx, cy = Lay.cy, R = Lay.R;
      const glow = b.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * 1.1);
      glow.addColorStop(0, 'rgba(60,40,110,0.55)'); glow.addColorStop(1, 'rgba(60,40,110,0)');
      b.fillStyle = glow; b.beginPath(); b.arc(cx, cy, R * 1.1, 0, 7); b.fill();
      b.fillStyle = 'rgba(14,10,22,0.75)'; b.beginPath(); b.arc(cx, cy, R, 0, 7); b.fill();
      b.strokeStyle = 'rgba(227,174,69,0.7)'; b.lineWidth = 2; b.beginPath(); b.arc(cx, cy, R, 0, 7); b.stroke();
      b.strokeStyle = 'rgba(227,174,69,0.3)'; b.lineWidth = 1; b.beginPath(); b.arc(cx, cy, R - 12, 0, 7); b.stroke();
      b.beginPath(); b.arc(cx, cy, R * 0.62, 0, 7); b.stroke();
      for (let q = 0; q < 48; q++) {
        const a = q / 48 * Math.PI * 2, l = q % 4 === 0 ? 8 : 4;
        b.beginPath(); b.moveTo(cx + Math.cos(a) * (R - 12), cy + Math.sin(a) * (R - 12)); b.lineTo(cx + Math.cos(a) * (R - 12 + l * 0.5 + 2), cy + Math.sin(a) * (R - 12 + l * 0.5 + 2)); b.stroke();
      }
      // little rune glyphs between the rings
      b.fillStyle = 'rgba(227,174,69,0.4)'; b.font = '700 ' + Math.round(R * 0.07 + 4) + 'px ' + MONO; b.textAlign = 'center'; b.textBaseline = 'middle';
      const gl = 'ᚠᚢᚦᚨᚱᚲᚷᚹᚺᚾᛁᛃ';
      const gr2 = (R - 12 + R * 0.62) / 2;   // between the rings, away from the corner runes (45°)
      for (let q = 0; q < 12; q++) { const a = (Math.floor(q / 3) * 90 + (q % 3 - 1) * 18) * Math.PI / 180; b.fillText(gl[q], cx + Math.cos(a) * gr2, cy + Math.sin(a) * gr2); }
      // hexagram faint
      b.strokeStyle = 'rgba(200,182,255,0.1)'; b.lineWidth = 1;
      for (const off of [0, Math.PI / 3]) { b.beginPath(); for (let q = 0; q <= 3; q++) { const a = off + q * Math.PI * 2 / 3 - Math.PI / 2; const x = cx + Math.cos(a) * R * 0.62, y = cy + Math.sin(a) * R * 0.62; q ? b.lineTo(x, y) : b.moveTo(x, y); } b.stroke(); }
      Lay.bg = c;
    }

    /* ---- drawing input ---- */
    const nodeXY = (i) => { const [c, r] = node(i); return [Lay.cx + c * Lay.g, Lay.cy + r * Lay.g]; };
    function canDraw() { return !!st && st.ph === 'c' && !anim && !trace && drawer() >= 0; }
    function addNode(i) {
      if (path.length && path[path.length - 1] === i) return;
      path.push(i); edges = edgesOf(path);
      Snd.rune(path.length - 1); api.buzz(8);
      const [x, y] = nodeXY(i);
      for (let q = 0; q < 6; q++) spawn({ x, y, vx: (Math.random() - 0.5) * 70, vy: (Math.random() - 0.5) * 70, life: 0.4, col: col(drawer() >= 0 ? drawer() : persp()), r: 2 });
    }
    function addAlong(x0, y0, x1, y1) {
      const dx = x1 - x0, dy = y1 - y0, L2 = dx * dx + dy * dy || 1, hits = [];
      for (let i = 0; i < 9; i++) {
        const [nx, ny] = nodeXY(i);
        let t = ((nx - x0) * dx + (ny - y0) * dy) / L2; t = Math.max(0, Math.min(1, t));
        const ex = x0 + dx * t - nx, ey = y0 + dy * t - ny;
        if (ex * ex + ey * ey < Lay.hitR * Lay.hitR) hits.push([t, i]);
      }
      hits.sort((a, b) => a[0] - b[0]).forEach(([, i]) => addNode(i));
    }
    function clearDraw() { path = []; edges = []; trace = null; refreshButtons(); }
    const matched = () => (edges.length ? match(edges) : -1);
    function onDown(ev) {
      if (!st) return;
      const p = cv.local(ev);
      // choose a target (3–4 wizards)
      if (p.y < Lay.OZ && st.n > 2 && canDraw()) {
        const s = Lay.slots.find((q) => p.x >= q.x0 && p.x < q.x0 + q.w);
        if (s && st.hp[s.seat] > 0) { target = s.seat; api.sfx('click'); refreshButtons(); }
        return;
      }
      const dx = p.x - Lay.cx, dy = p.y - Lay.cy;
      if (!canDraw() || dx * dx + dy * dy > (Lay.R + 26) * (Lay.R + 26)) return;
      ev.preventDefault();
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      dragging = true; path = []; edges = []; trace = null; fx = p.x; fy = p.y;
      addAlong(p.x, p.y, p.x, p.y);
      refreshButtons();
    }
    function onMove(ev) {
      if (!dragging) return;
      const p = cv.local(ev);
      if (!canDraw()) { dragging = false; return; }
      addAlong(fx, fy, p.x, p.y); fx = p.x; fy = p.y;
    }
    function onUp() {
      if (!dragging) return;
      dragging = false;
      if (path.length < 2) { path = []; edges = []; }
      const k = matched();
      if (k >= 0) { Snd.ready(); api.buzz(18); burstRunes(k); }
      refreshButtons();
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    function burstRunes(k) {
      SP[k].p.forEach((i) => { const [x, y] = nodeXY(i); for (let q = 0; q < 5; q++) spawn({ x, y, vx: (Math.random() - 0.5) * 120, vy: (Math.random() - 0.5) * 120, life: 0.6, col: SP[k].col, r: 2.4 }); });
    }
    /* tap a spell in the book → it draws itself */
    function autoTrace(k) {
      if (!canDraw()) return;
      path = []; edges = [];
      trace = { k, i: 0, t: 0 };
      refreshButtons();
    }
    function stepTrace(dt) {
      if (!trace) return;
      trace.t += dt;
      while (trace && trace.t >= 0.09) {
        trace.t -= 0.09;
        addNode(SP[trace.k].p[trace.i++]);
        if (trace.i >= SP[trace.k].p.length) { const k = trace.k; trace = null; Snd.ready(); burstRunes(k); refreshButtons(); }
      }
    }

    function defaultTarget(seat) {
      const tg = []; for (let i = 0; i < st.n; i++) if (i !== seat && st.hp[i] > 0) tg.push(i);
      if (tg.includes(target)) return target;
      const low = Math.min(...tg.map((t) => st.hp[t]));
      const lows = tg.filter((t) => st.hp[t] === low);
      return lows.includes(st.la[seat]) ? st.la[seat] : lows[0];
    }
    function cast(auto) {
      const seat = drawer();
      if (seat < 0 || !st || anim) return;
      let k = matched();
      if (k < 0 || SP[k].c > st.m[seat]) { if (!auto) return; k = FOCUS; }
      const t = SP[k].dm ? defaultTarget(seat) : -1;
      sent[seat] = st.r; lockK = multi() ? -1 : k;
      Snd.cast(); api.buzz(20);
      if (auto) api.toast(k === FOCUS && matched() !== FOCUS ? '시간 끝! 기 모으기' : '시간 끝! ' + SP[k].n + ' 시전');
      api.actAs(seat, { k, t });
      if (multi()) { revealed = -1; path = []; edges = []; }
      target = -1;
      refreshButtons(); syncHand();
    }
    clearBtn.onclick = () => { if (canDraw()) { clearDraw(); api.sfx('click'); } };
    castBtn.onclick = () => cast(false);
    bookBtn.onclick = () => openBook();

    function refreshButtons() {
      const can = canDraw(), k = matched(), seat = drawer();
      const ok = can && k >= 0 && seat >= 0 && SP[k].c <= st.m[seat];
      castBtn.disabled = !ok; clearBtn.disabled = !can || !path.length;
      castBtn.classList.toggle('ready', ok);
      castBtn.textContent = ok ? '✨ ' + SP[k].n + ' 시전' : '✨ 시전';
    }

    /* ---- spell book ---- */
    function openBook() {
      if (bookEl) return;
      api.sfx('click');
      const seat = drawer(), can = canDraw(), mana = seat >= 0 ? st.m[seat] : (st ? st.m[persp()] : 10);
      const close = () => { if (bookEl) { bookEl.remove(); bookEl = null; } };
      const list = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
      SP.forEach((S, k) => {
        const icv = h('canvas', { width: 104, height: 104 });
        const c2 = icv.getContext('2d'); c2.scale(2, 2); sigil(c2, k, 26, 26, 46, S.col, 1, 2.6);
        const off = can && S.c > mana;
        const row = h('button', { class: 'sp-row' + (off ? ' off' : ''), type: 'button' },
          icv, h('div', null, h('div', { class: 'nm', text: S.n, style: { color: S.col } }), h('div', { class: 'ds', text: S.d })),
          h('span', { class: 'sp-mana', text: '마나 ' + S.c }));
        row.onclick = () => {
          if (!can) { api.toast('지금은 볼 수만 있어요'); return; }
          if (off) { api.toast('마나가 모자라요 (필요 ' + S.c + ')'); api.buzz(30); return; }
          close(); autoTrace(k);
        };
        list.append(row);
      });
      bookEl = h('div', { class: 'sp-ov' }, h('div', { class: 'sp-sheet' },
        h('div', { class: 'sp-head' }, h('h3', { text: '주문책 · 10가지' }), h('button', { class: 'sp-x', type: 'button', 'aria-label': '주문책 닫기', text: '✕', onclick: close })),
        h('div', { class: 'sp-tri', html: '<b style="color:#45b0ff">물살</b> ▶ <b style="color:#ff7a3d">불꽃</b> ▶ <b style="color:#5fcf6c">덩굴</b> ▶ <b style="color:#45b0ff">물살</b><br>서로 노린 속성 주문끼리 부딪치면 이긴 쪽은 피해 +1, 진 쪽은 사라져요. 같은 속성이면 둘 다 사라져요.' }),
        h('div', { class: 'sp-note', text: can ? '주문을 누르면 마법진에 자동으로 그려져요. 모양은 방향·시작점과 상관없어요.' : '주문의 모양과 효과예요.' }),
        list,
        h('div', { class: 'sp-note', text: '마나는 라운드마다 +2 (최대 10). 11라운드부터 마력 폭풍으로 모두 체력이 조금씩 깎여요.' })));
      bookEl.addEventListener('click', (e) => { if (e.target === bookEl) close(); });
      root.append(bookEl);
    }
    function onKeyEsc(e) { if (e.key === 'Escape' && bookEl) { e.preventDefault(); bookEl.remove(); bookEl = null; } }
    addEventListener('keydown', onKeyEsc, true);

    /* ---- keyboard / pad (rebindable) ---- */
    const offInput = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || dead) return;
      if (id === 'book') { if (bookEl) { bookEl.remove(); bookEl = null; } else openBook(); return; }
      if (bookEl) return;
      if (id === 'cast') { cast(false); return; }
      if (id === 'clear') { if (canDraw()) clearDraw(); return; }
      if (id[0] === 'r' && canDraw()) {
        if (!dragging && path.length && matched() >= 0) { path = []; edges = []; }
        addNode(+id.slice(1));
        const k = matched(); if (k >= 0) { Snd.ready(); burstRunes(k); }
        refreshButtons();
      }
    }) : null;

    /* ---- pass-the-phone (several people on one phone) ---- */
    function syncHand() {
      let want = -1;
      if (st && multi() && st.ph === 'c' && !anim) {
        const p = pendingLocal();
        if (p.length && !p.includes(revealed)) want = p[0];
      }
      const key = want + ':' + (st ? st.r : 0);
      if (key === handKey) return;
      handKey = key;
      if (handEl) { handEl.remove(); handEl = null; }
      if (want < 0) return;
      if (bookEl) { bookEl.remove(); bookEl = null; }
      handEl = h('div', { class: 'sp-hand' },
        h('span', { class: 'dot', style: { '--c': col(want), width: '18px', height: '18px' } }),
        h('div', { class: 'big', text: nm(want) }),
        h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: '라운드 ' + (st.r + 1) + ' · 몰래 주문 그리기' }),
        h('div', { class: 'muted', text: '다른 사람은 보지 마세요' }),
        h('button', { class: 'btn primary', type: 'button', text: '그리기 시작', onclick: () => { revealed = want; path = []; edges = []; api.sfx('click'); handKey = ''; syncHand(); layout(); refreshButtons(); } }));
      root.append(handEl);
    }

    /* ---- particles ---- */
    function spawn(p) { if (parts.length > 260) parts.shift(); p.t = 0; p.max = p.life; parts.push(p); }
    function floatText(x, y, text, color, big) { spawn({ x, y, vx: 0, vy: -38, life: 1.3, col: color, text, big }); }

    /* ---- the reveal animation (from state.last, so online guests see the same) ---- */
    function startAnim(last) {
      const evs = [];
      const me = persp();
      last.a.forEach((A) => {
        const [s, t, k, d, f, hit] = A;
        evs.push({ s, t, k, d, f, hit, done: false, hitDone: false });
      });
      anim = { last, t: 0, evs, dur: 2.5 + (last.st ? 0.6 : 0) + (last.dead.length ? 0.4 : 0), msg: summary(last, me), sfx: {} };
      if (bookEl) { bookEl.remove(); bookEl = null; }
      dragging = false; trace = null;
      setBusy(true);
      syncHand();
    }
    const jo = (w, a, b) => { const c = w.charCodeAt(w.length - 1); return w + (c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b); };
    function summary(last, me) {
      const out = [];
      for (const A of last.a) {
        const [s, t, k, , f] = A;
        if (f & F.WIN) { const o = last.a.find((B) => B[0] === t && B[1] === s); out.push([s === me || t === me ? 3 : 1, jo(SP[k].n, '이', '가') + ' ' + (o ? jo(SP[o[2]].n, '을', '를') : '') + ' 이겼어요!']); }
        else if ((f & F.TIE) && s < t) out.push([s === me || t === me ? 3 : 1, '같은 ' + SP[k].n + '끼리 부딪쳐 사라졌어요']);
        if (f & F.REFL) out.push([s === me || t === me ? 4 : 2, '거울! ' + jo(SP[k].n, '이', '가') + ' 되돌아갔어요']);
        if (f & F.BLOCK) out.push([t === me ? 2 : 1, '방패가 ' + jo(SP[k].n, '을', '를') + ' 막았어요']);
        if (f & F.HALF) out.push([2, '방패가 별똥별을 반 막았어요']);
        if (k === BOLT && last.k[t] === SHIELD) out.push([2, '번개가 방패를 뚫었어요!']);
      }
      out.sort((a, b) => b[0] - a[0]);
      return out.length ? out[0][1] : '주문 공개!';
    }
    const ease = (x) => (x < 0 ? 0 : x > 1 ? 1 : 1 - (1 - x) * (1 - x));
    function stepAnim(dt) {
      if (!anim) return;
      const a = anim, T0 = a.t;
      a.t += dt * spd();
      const at = (x) => T0 < x && a.t >= x;
      const last = a.last, n = last.k.length, me = persp();
      if (at(0.02)) {
        let any = false;
        for (let i = 0; i < n; i++) if (last.k[i] >= 0) { any = true; const p = posOf(i); for (let q = 0; q < 10; q++) spawn({ x: p.x, y: p.y - (i === me ? 0 : 40), vx: (Math.random() - 0.5) * 140, vy: (Math.random() - 0.5) * 140, life: 0.5, col: SP[last.k[i]].col, r: 2.5 }); }
        if (any) Snd.cast();
      }
      if (at(0.45)) {
        const played = new Set(); for (let i = 0; i < n; i++) if (last.k[i] >= 0) played.add(last.k[i]);
        [...played].slice(0, 3).forEach((k, q) => later(() => Snd.spell(k), q * 70));
        for (let i = 0; i < n; i++) {
          const k = last.k[i]; if (k < 0) continue; const p = posOf(i);
          if (k === FOCUS) { floatText(p.x, p.y - 20, '마나 +' + (FOCUS_GAIN + REGEN), '#8fb8ff'); for (let q = 0; q < 16; q++) { const ang = Math.random() * 7, rr2 = 60; spawn({ x: p.x + Math.cos(ang) * rr2, y: p.y + Math.sin(ang) * rr2, vx: -Math.cos(ang) * rr2 * 1.6, vy: -Math.sin(ang) * rr2 * 1.6, life: 0.6, col: '#8fb8ff', r: 2.2 }); } }
          if (k === HEALK) { floatText(p.x, p.y - 30, '+' + HEAL, '#7dffb0', true); for (let q = 0; q < 18; q++) spawn({ x: p.x + (Math.random() - 0.5) * 70, y: p.y + 20 + Math.random() * 20, vx: 0, vy: -60 - Math.random() * 50, life: 1, col: '#7dffb0', r: 2.4, plus: true }); }
        }
      }
      for (const e of a.evs) {
        const tl = timeline(e);
        if (!e.done && a.t >= tl.meet && (e.f & (F.WIN | F.LOST | F.TIE)) && e.s < e.t) {
          e.done = true; const p1 = posOf(e.s), p2 = posOf(e.t), mx = (p1.x + p2.x) / 2, my = (p1.y + p2.y) / 2;
          Snd.clash(); shake = Math.max(shake, 6); api.buzz(25);
          for (let q = 0; q < 26; q++) { const ang = Math.random() * 7, v = 60 + Math.random() * 160; spawn({ x: mx, y: my, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v, life: 0.7, col: q % 2 ? SP[e.k].col : '#fff6dc', r: 3 }); }
        }
        if (!e.hitDone && a.t >= tl.hit && !(e.f & (F.LOST | F.TIE))) {
          e.hitDone = true;
          const p = posOf(e.hit), big = e.k === METEOR;
          if (e.f & F.BLOCK) { Snd.ping(); floatText(p.x, p.y - 24, '막음', '#e3ae45'); }
          else {
            Snd.boom(big || e.d >= 6); hitT[e.hit] = performance.now();
            floatText(p.x, p.y - 26, '−' + e.d, '#ff6b5a', true);
            if (e.k === FROST) floatText(p.x + 26, p.y - 4, '마나 −' + DRAIN, '#a4ecff');
            if (e.hit === me) { shake = Math.max(shake, big ? 16 : 9); flash = 1; api.buzz(big ? 60 : 35); }
            for (let q = 0; q < (big ? 40 : 22); q++) { const ang = Math.random() * 7, v = 40 + Math.random() * (big ? 220 : 140); spawn({ x: p.x, y: p.y, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v - 30, life: 0.75, col: q % 3 ? SP[e.k].col : '#fff6dc', r: big ? 3.6 : 2.8 }); }
          }
        }
      }
      if (last.st && at(2.0)) {
        Snd.storm(); shake = Math.max(shake, 7); flash = Math.max(flash, 0.5);
        for (let i = 0; i < n; i++) if (last.ph[i] > 0) { const p = posOf(i); floatText(p.x, p.y - 8, '폭풍 −' + last.st, '#d48cff'); hitT[i] = performance.now(); }
      }
      if (last.dead.length && at(a.dur - 0.5)) { Snd.boom(true); last.dead.forEach((i) => { const p = posOf(i); floatText(p.x, p.y - 40, '쓰러짐', '#f2e9d8', true); }); }
      if (a.t >= a.dur) {
        anim = null; lockK = -1; path = []; edges = []; target = -1;
        roundBanner = st && st.ph === 'c' ? 1.4 : 0;
        setBusy(false); syncHand(); refreshButtons();
      }
    }
    /* per attack: launch 0.75 → meet (clash) → hit; reflections bounce back */
    function timeline(e) {
      const clash = e.f & (F.WIN | F.LOST | F.TIE);
      if (e.k === BOLT) return { go: 1.0, meet: 1.0, hit: e.f & F.REFL ? 1.45 : 1.15, arr: 1.15 };
      if (e.k === METEOR) return { go: 0.75, meet: 1.3, hit: e.f & F.REFL ? 1.85 : 1.45, arr: 1.45 };
      return { go: 0.75, meet: 1.12, hit: e.f & F.REFL ? 1.85 : clash ? 1.5 : 1.4, arr: 1.4 };
    }

    /* ---- timer ---- */
    function timeLeft() {
      if (!st || !st.tl || !canDraw()) return -1;
      const key = st.r + ':' + drawer();
      if (key !== tKey) { tKey = key; tStart = performance.now(); tPause = 0; lastTick = -1; }
      return st.tl - (performance.now() - tStart - tPause) / 1000;
    }

    /* ---- render ---- */
    function drawWizard(x, y, sc, color, t, opt) {
      ctx.save(); ctx.translate(x, y); ctx.scale(sc, sc);
      if (opt.dead) { ctx.globalAlpha = 0.35; ctx.rotate(-0.12); }
      const bob = opt.dead ? 0 : Math.sin(t * 2.2 + x) * 1.6;
      ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(0, 0, 26, 6, 0, 0, 7); ctx.fill();
      ctx.translate(0, bob);
      // staff
      ctx.strokeStyle = '#7a5532'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(25, 0); ctx.lineTo(28, -80); ctx.stroke();
      const orb = opt.orb || color;
      ctx.save(); ctx.shadowColor = orb; ctx.shadowBlur = 14 + Math.sin(t * 4) * 4; ctx.fillStyle = orb; ctx.beginPath(); ctx.arc(28.5, -84, 6, 0, 7); ctx.fill(); ctx.restore();
      ctx.fillStyle = '#fff6dc'; ctx.beginPath(); ctx.arc(27, -86, 2, 0, 7); ctx.fill();
      // robe
      const rg = ctx.createLinearGradient(-20, -50, 20, 0); rg.addColorStop(0, shade(color, 0.12)); rg.addColorStop(1, shade(color, -0.45));
      ctx.fillStyle = rg; ctx.beginPath(); ctx.moveTo(-23, 0); ctx.quadraticCurveTo(0, 4, 23, 0); ctx.lineTo(11, -50); ctx.quadraticCurveTo(0, -55, -11, -50); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,0.85)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-21, -3); ctx.quadraticCurveTo(0, 1, 21, -3); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-14, -30); ctx.lineTo(14, -30); ctx.stroke();
      // sleeve + hand on staff
      ctx.fillStyle = shade(color, -0.2); ctx.beginPath(); ctx.moveTo(6, -46); ctx.lineTo(26, -40); ctx.lineTo(24, -33); ctx.lineTo(5, -36); ctx.fill();
      ctx.fillStyle = '#f0d9b5'; ctx.beginPath(); ctx.arc(26, -37, 3.4, 0, 7); ctx.fill();
      // head + beard
      ctx.fillStyle = '#f0d9b5'; ctx.beginPath(); ctx.arc(0, -58, 9.5, 0, 7); ctx.fill();
      ctx.fillStyle = '#ece4d6'; ctx.beginPath(); ctx.moveTo(-8, -56); ctx.quadraticCurveTo(0, -30, 8, -56); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#231b2e'; ctx.beginPath(); ctx.arc(-3.4, -60, 1.3, 0, 7); ctx.arc(3.4, -60, 1.3, 0, 7); ctx.fill();
      // hat
      ctx.fillStyle = shade(color, -0.3); ctx.beginPath(); ctx.ellipse(0, -65, 19, 4.5, 0, 0, 7); ctx.fill();
      ctx.fillStyle = shade(color, -0.15); ctx.beginPath(); ctx.moveTo(-12, -66); ctx.quadraticCurveTo(-4, -86, 3, -100); ctx.quadraticCurveTo(10, -104, 14, -96); ctx.quadraticCurveTo(8, -94, 6, -88); ctx.lineTo(12, -66); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); for (let q = 0; q < 10; q++) { const ang = q * Math.PI / 5 - Math.PI / 2, r = q % 2 ? 1.6 : 3.8; ctx.lineTo(Math.cos(ang) * r, -76 + Math.sin(ang) * r); } ctx.fill();
      // hurt flash
      if (opt.hurt > 0) { ctx.globalCompositeOperation = 'source-atop'; ctx.fillStyle = 'rgba(255,90,70,' + (opt.hurt * 0.6).toFixed(2) + ')'; ctx.fillRect(-30, -110, 64, 112); ctx.globalCompositeOperation = 'source-over'; }
      ctx.restore();
    }
    function bar(x, y, w, hh, v, max, c1, label) {
      ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x, y, w, hh, hh / 2); ctx.fill();
      const f = Math.max(0, Math.min(1, v / max));
      if (f > 0) { ctx.fillStyle = c1; rr(ctx, x, y, Math.max(hh, w * f), hh, hh / 2); ctx.fill(); }
      ctx.strokeStyle = 'rgba(242,233,216,0.18)'; ctx.lineWidth = 1; rr(ctx, x + 0.5, y + 0.5, w - 1, hh - 1, hh / 2); ctx.stroke();
      if (label) { ctx.fillStyle = '#f2e9d8'; ctx.font = '700 ' + Math.max(9, hh - 2) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, x + w / 2, y + hh / 2 + 0.5); }
    }
    function pips(x, y, cnt, max, sz) {
      for (let q = 0; q < max; q++) {
        ctx.fillStyle = q < cnt ? '#6fa8ff' : 'rgba(111,168,255,0.16)';
        ctx.beginPath(); ctx.arc(x + q * (sz + 2.5) + sz / 2, y + sz / 2, sz / 2, 0, 7); ctx.fill();
      }
    }
    function fitText(text, maxW, size, weight, family) {
      let s = size;
      ctx.font = weight + ' ' + s + 'px ' + family;
      while (s > 10 && ctx.measureText(text).width > maxW) { s -= 1; ctx.font = weight + ' ' + s + 'px ' + family; }
      return s;
    }
    function hpColor(v, mx) { const f = v / mx; return f > 0.5 ? '#5fcf6c' : f > 0.25 ? '#e3ae45' : '#ee6a55'; }

    function draw(now) {
      const W = cv.w, H = cv.h;
      if (W !== Lay.W || H !== Lay.H) layout();
      cv.clear();
      ctx.save();
      if (shake > 0.2) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
      if (Lay.bg) ctx.drawImage(Lay.bg, 0, 0, W, H);
      if (!st) { ctx.restore(); return; }
      const t = now / 1000, me = persp(), last = anim ? anim.last : null, at = anim ? anim.t : 99;
      const n = st.n;
      for (let i = 0; i < n; i++) {
        const gHP = anim && at < 1.55 ? last.ph[i] : anim && at < 2.05 && last.st && last.ph[i] > 0 ? Math.min(st.hp[i] + last.st, st.mx) : st.hp[i];
        const gM = anim && at < 1.9 ? last.pm[i] : st.m[i];
        if (shownHP[i] == null) { shownHP[i] = gHP; shownM[i] = gM; }
        shownHP[i] += (gHP - shownHP[i]) * 0.14; shownM[i] += (gM - shownM[i]) * 0.2;
        if (Math.abs(gHP - shownHP[i]) < 0.05) shownHP[i] = gHP;
      }
      const isDead = (i) => st.hp[i] <= 0 && (!anim || at > anim.dur - 0.5 || last.ph[i] <= 0);

      /* opponents */
      for (const s of Lay.slots) {
        const i = s.seat, dd = isDead(i);
        const hurt = hitT[i] ? Math.max(0, 1 - (now - hitT[i]) / 380) : 0;
        const k = anim && at > 0.02 ? last.k[i] : -1;
        drawWizard(s.x, s.feet, s.sc, col(i), t, { dead: dd, hurt, orb: k >= 0 ? SP[k].col : null });
        // name + bars
        const bw = Math.min(150, s.w - 22), bx = s.x - bw / 2;
        ctx.textAlign = 'center'; ctx.textBaseline = 'top';
        const hy = Lay.hudY;
        fitText(nm(i), bw - 10, 13, '700', FONT); ctx.fillStyle = dd ? 'rgba(242,233,216,0.45)' : '#f2e9d8';
        const nw = Math.min(bw - 10, ctx.measureText(nm(i)).width);
        ctx.fillText(nm(i), s.x + 5, hy);
        ctx.fillStyle = col(i); ctx.beginPath(); ctx.arc(s.x - nw / 2 - 4, hy + 8, 4, 0, 7); ctx.fill();
        bar(bx, hy + 19, bw, 13, shownHP[i], st.mx, hpColor(shownHP[i], st.mx), Math.round(shownHP[i]) + '/' + st.mx);
        const pz = Math.min(8, (bw - 9 * 2.5) / 10);
        pips(s.x - (10 * (pz + 2.5) - 2.5) / 2, hy + 37, Math.round(shownM[i]), MMAX, pz);
        // status: badge beside the head while choosing, the revealed sigil in front of the wizard
        if (dd) { ctx.fillStyle = 'rgba(242,233,216,0.7)'; ctx.font = '700 13px ' + FONT; ctx.textBaseline = 'middle'; ctx.fillText('탈락', s.x, s.chest); }
        else if (anim && at > 0.02) {
          const kk = last.k[i];
          if (kk >= 0) {
            const a2 = Math.min(1, at * 4), sz = Math.max(30, Math.min(46, 40 * s.sc));
            ctx.save(); ctx.globalAlpha = a2;
            ctx.fillStyle = 'rgba(14,10,22,0.82)'; rr(ctx, s.x - sz / 2 - 4, s.chest - sz / 2 - 10, sz + 8, sz + 8, 9); ctx.fill();
            sigil(ctx, kk, s.x, s.chest - 6, sz, SP[kk].col, 1);
            ctx.textBaseline = 'middle'; fitText(SP[kk].n, s.w - 8, 12, '700', FONT);
            const tw = ctx.measureText(SP[kk].n).width + 12;
            ctx.fillStyle = 'rgba(14,10,22,0.85)'; rr(ctx, s.x - tw / 2, s.chest + sz / 2 + 2, tw, 18, 9); ctx.fill();
            ctx.fillStyle = SP[kk].col; ctx.fillText(SP[kk].n, s.x, s.chest + sz / 2 + 11.5);
            ctx.restore();
          }
        } else if (st.ph === 'c') {
          const ready = st.ch[i] != null, bxx = s.x - 30 * s.sc, byy = s.feet - 74 * s.sc;
          ctx.fillStyle = ready ? '#e3ae45' : 'rgba(46,38,64,0.95)'; ctx.strokeStyle = ready ? '#fff1c8' : 'rgba(200,182,255,0.5)'; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.arc(bxx, byy, 11, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = ready ? '#2a1d05' : '#d9cfe6'; ctx.font = '700 12px ' + FONT; ctx.textBaseline = 'middle';
          ctx.fillText(ready ? '✓' : '···'.slice(0, 1 + Math.floor(t * 2.5) % 3), bxx, byy - (ready ? 0 : 2));
          if (s.w >= 200) {
            const txt = ready ? '준비 완료' : '그리는 중';
            ctx.font = '700 11px ' + FONT; ctx.textAlign = 'right'; ctx.fillStyle = ready ? '#e3ae45' : '#b9add0';
            ctx.fillText(txt, bxx - 15, byy); ctx.textAlign = 'center';
          }
        }
        // shield / mirror on this wizard
        if (anim && at > 0.45 && at < anim.dur - 0.3) {
          const kk = last.k[i], cx2 = s.x, cy2 = s.feet - 50 * s.sc;
          const fade = Math.min(1, (at - 0.45) * 4) * Math.min(1, (anim.dur - 0.3 - at) * 3);
          if (kk === SHIELD) { ctx.save(); ctx.globalAlpha = 0.85 * fade; ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.shadowColor = '#e3ae45'; ctx.shadowBlur = 16; ctx.beginPath(); ctx.arc(cx2, cy2 + 10 * s.sc, 58 * s.sc, Math.PI * 1.02, Math.PI * 1.98); ctx.stroke(); ctx.globalAlpha = 0.15 * fade; ctx.fillStyle = '#e3ae45'; ctx.fill(); ctx.restore(); }
          if (kk === MIRROR) { ctx.save(); ctx.globalAlpha = 0.8 * fade; const mw = 64 * s.sc, mh = 14; const yy = s.feet + 4; const gr = ctx.createLinearGradient(cx2 - mw / 2, 0, cx2 + mw / 2, 0); gr.addColorStop(0, 'rgba(200,182,255,0.4)'); gr.addColorStop((t * 0.8) % 1, '#ffffff'); gr.addColorStop(1, 'rgba(200,182,255,0.4)'); ctx.fillStyle = gr; ctx.shadowColor = '#c8b6ff'; ctx.shadowBlur = 14; rr(ctx, cx2 - mw / 2, yy - mh, mw, mh, 4); ctx.fill(); ctx.restore(); }
        }
        // target reticle
        if (st.n > 2 && canDraw() && !dd) {
          const k2 = matched(), seat = drawer();
          if (k2 >= 0 && SP[k2].dm && defaultTarget(seat) === i) {
            ctx.save(); ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2.5; ctx.setLineDash([6, 5]); ctx.lineDashOffset = -t * 20;
            ctx.beginPath(); ctx.arc(s.x, s.feet - 50 * s.sc, 46 * s.sc, 0, 7); ctx.stroke(); ctx.restore();
          }
        }
      }

      /* preview / message line */
      const pvy = Lay.PVy + 18, seat = drawer(), can = canDraw();
      let msg = '', mcol = '#d9cfe6', big = false;
      if (anim) { msg = anim.msg; mcol = '#f2e9d8'; big = true; }
      else if (st.ph !== 'c') msg = '';
      else if (roundBanner > 0) { msg = '라운드 ' + (st.r + 1) + (storm(st.r) ? ' · 마력 폭풍 −' + storm(st.r) : ''); mcol = storm(st.r) ? '#d48cff' : '#e3ae45'; big = true; }
      else if (can) {
        const k = matched();
        if (trace) { msg = '주문책: ' + SP[trace.k].n + ' 그리는 중…'; mcol = SP[trace.k].col; }
        else if (k >= 0) {
          if (SP[k].c > st.m[seat]) { msg = SP[k].n + ' — 마나가 모자라요 (필요 ' + SP[k].c + ')'; mcol = '#ee6a55'; }
          else { msg = SP[k].n + ' · ' + SP[k].d + (st.n > 2 && SP[k].dm ? ' → ' + nm(defaultTarget(seat)) : ''); mcol = SP[k].col; big = true; }
        } else if (!edges.length) msg = path.length ? '이어서 그려요' : '룬(점)을 이어 마법진을 그려요';
        else { const gs = guess(edges); if (gs) { msg = SP[gs.k].n + '까지 ' + gs.miss.length + '줄 더'; mcol = SP[gs.k].col; } else { msg = '모르는 모양이에요 — 새로 그려요'; mcol = '#ee6a55'; } }
      } else if (st.hp[me] <= 0) msg = '탈락 — 끝까지 지켜봐요';
      else if (api.canAct(me) && st.ch[me] != null || sent[me] === st.r) msg = (lockK >= 0 ? '「' + SP[lockK].n + '」 준비 완료 · ' : '준비 완료 · ') + '상대를 기다려요';
      else if (multi()) msg = '폰을 넘겨 차례로 몰래 그려요';
      else msg = nm(me) + ' · 주문을 고르는 중…';
      if (msg) {
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        fitText(msg, W - 24, big ? 16 : 14, '700', FONT); ctx.fillStyle = mcol; ctx.fillText(msg, W / 2, pvy);
      }

      /* my HUD */
      {
        const y = Lay.MYy + 4, x0 = 14, dd = st.hp[me] <= 0;
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillStyle = col(me); ctx.beginPath(); ctx.arc(x0 + 5, y + 8, 5, 0, 7); ctx.fill();
        const label = (api.canAct(me) && !multi() ? '나 · ' : '') + nm(me);
        fitText(label, W * 0.34, 13, '700', FONT); ctx.fillStyle = dd ? 'rgba(242,233,216,0.5)' : '#f2e9d8'; ctx.fillText(label, x0 + 14, y + 8);
        const bx = Math.max(x0 + 14 + Math.min(W * 0.34, ctx.measureText(label).width) + 10, W * 0.36), bw = W - 14 - bx;
        bar(bx, y + 1, bw, 14, shownHP[me], st.mx, hpColor(shownHP[me], st.mx), '체력 ' + Math.round(shownHP[me]) + '/' + st.mx);
        const pz = Math.min(10, (bw - 40 - 9 * 2.5) / 10);
        ctx.fillStyle = '#9cc4ff'; ctx.font = '700 11px ' + MONO; ctx.textAlign = 'left'; ctx.fillText('마나 ' + Math.round(shownM[me]), bx, y + 26);
        pips(bx + 52, y + 26 - pz / 2, Math.round(shownM[me]), MMAX, pz);
        const hurt = hitT[me] ? Math.max(0, 1 - (now - hitT[me]) / 380) : 0;
        if (hurt > 0) { ctx.fillStyle = 'rgba(238,106,85,' + (hurt * 0.25).toFixed(2) + ')'; rr(ctx, 8, Lay.MYy, W - 16, 42, 10); ctx.fill(); }
      }

      /* my magic circle */
      const cx = Lay.cx, cy = Lay.cy, R = Lay.R;
      const tl = timeLeft();
      if (tl >= 0) {
        const f = Math.max(0, tl / st.tl), warn = tl <= 5;
        ctx.save(); ctx.strokeStyle = warn ? '#ee6a55' : 'rgba(227,174,69,0.9)'; ctx.lineWidth = 4; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(cx, cy, R + 7, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * f); ctx.stroke(); ctx.restore();
        ctx.fillStyle = warn ? '#ee6a55' : '#e3ae45'; ctx.font = '700 15px ' + MONO; ctx.textAlign = 'right'; ctx.textBaseline = 'top';
        ctx.fillText(Math.ceil(Math.max(0, tl)) + '초', W - 10, cy - R - 2 < Lay.MYy + 44 ? cy - R + 2 : cy - R);
      }
      // which pattern to show on my circle
      let showK = -1, showA = 1;
      if (anim && last.k[me] >= 0) { showK = last.k[me]; showA = Math.min(1, at * 3); }
      const curCol = can ? (matched() >= 0 ? SP[matched()].col : col(seat)) : col(me);
      const lit = new Set();
      if (showK >= 0) SP[showK].p.forEach((i) => lit.add(i)); else path.forEach((i) => lit.add(i));
      // ghost guide
      if (can && !trace && edges.length && matched() < 0) {
        const gs = guess(edges);
        if (gs) {
          ctx.save(); ctx.strokeStyle = SP[gs.k].col; ctx.globalAlpha = 0.4; ctx.lineWidth = 3; ctx.setLineDash([5, 7]); ctx.lineCap = 'round';
          for (const e of gs.miss) { const a = Math.floor(e / 9), b = e % 9; const [x1, y1] = nodeXY(a), [x2, y2] = nodeXY(b); ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
          ctx.restore();
        }
      }
      // lines
      const linePath = showK >= 0 ? SP[showK].p : path;
      if (linePath.length > 1) {
        const lc = showK >= 0 ? SP[showK].col : curCol;
        ctx.save(); ctx.globalAlpha = showA * (anim || can || lockK < 0 ? 1 : 0.6);
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.strokeStyle = lc; ctx.shadowColor = lc; ctx.shadowBlur = 18; ctx.lineWidth = Math.max(5, R * 0.05);
        ctx.beginPath(); linePath.forEach((i, q) => { const [x, y] = nodeXY(i); q ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.stroke();
        ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(255,250,235,0.85)'; ctx.lineWidth = Math.max(1.5, R * 0.014); ctx.stroke();
        ctx.restore();
      } else if (!can && lockK >= 0 && !anim) {
        // (single phone) my sealed spell stays dimly visible
      }
      if (dragging && path.length) {
        const [x, y] = nodeXY(path[path.length - 1]);
        ctx.save(); ctx.strokeStyle = curCol; ctx.globalAlpha = 0.55; ctx.lineWidth = 3; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(fx, fy); ctx.stroke(); ctx.restore();
      }
      if (lockK >= 0 && !anim && !can && path.length === 0 && api.canAct(me) && st.ph === 'c') {
        sigil(ctx, lockK, cx, cy, R * 1.1, SP[lockK].col, 0.45, Math.max(4, R * 0.04));
      }
      // rune stones
      const nr = Math.max(9, R * 0.085);
      for (let i = 0; i < 9; i++) {
        const [x, y] = nodeXY(i), on = lit.has(i);
        ctx.fillStyle = on ? (showK >= 0 ? SP[showK].col : curCol) : 'rgba(242,233,216,0.12)';
        ctx.save(); if (on) { ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 16; }
        ctx.beginPath(); ctx.arc(x, y, nr, 0, 7); ctx.fill(); ctx.restore();
        ctx.strokeStyle = on ? '#fff6dc' : (can ? 'rgba(227,174,69,0.75)' : 'rgba(227,174,69,0.3)'); ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(x, y, nr, 0, 7); ctx.stroke();
        ctx.fillStyle = on ? '#2a1d05' : 'rgba(227,174,69,' + (can ? 0.8 : 0.35) + ')';
        ctx.beginPath(); ctx.arc(x, y, nr * 0.3, 0, 7); ctx.fill();
        if (can && !path.length && !trace) { ctx.save(); ctx.globalAlpha = 0.25 + 0.2 * Math.sin(t * 3 + i); ctx.strokeStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(x, y, nr + 5, 0, 7); ctx.stroke(); ctx.restore(); }
      }
      if (st.hp[me] <= 0 && !anim) { ctx.fillStyle = 'rgba(16,12,23,0.6)'; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.fill(); }
      // my shield / mirror during the reveal
      if (anim && at > 0.45 && at < anim.dur - 0.3) {
        const kk = last.k[me], fade = Math.min(1, (at - 0.45) * 4) * Math.min(1, (anim.dur - 0.3 - at) * 3);
        if (kk === SHIELD) { ctx.save(); ctx.globalAlpha = 0.9 * fade; ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 5; ctx.shadowColor = '#e3ae45'; ctx.shadowBlur = 22; ctx.beginPath(); ctx.arc(cx, cy, R + 16, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); ctx.restore(); }
        if (kk === MIRROR) { ctx.save(); ctx.globalAlpha = 0.85 * fade; const gr = ctx.createLinearGradient(cx - R, 0, cx + R, 0); gr.addColorStop(0, 'rgba(200,182,255,0.3)'); gr.addColorStop((t * 0.8) % 1, '#ffffff'); gr.addColorStop(1, 'rgba(200,182,255,0.3)'); ctx.fillStyle = gr; ctx.shadowColor = '#c8b6ff'; ctx.shadowBlur = 18; rr(ctx, cx - R * 0.8, cy - R - 20, R * 1.6, 10, 5); ctx.fill(); ctx.restore(); }
      }

      /* projectiles */
      if (anim) for (const e of anim.evs) drawShot(e, at, t);

      /* storm */
      if (anim && last.st && at > 1.95 && at < 2.5) {
        ctx.save(); ctx.globalAlpha = (2.5 - at) * 1.4; ctx.strokeStyle = '#d48cff'; ctx.lineWidth = 2.5; ctx.shadowColor = '#d48cff'; ctx.shadowBlur = 14;
        for (let q = 0; q < 3; q++) { let x = Math.random() * W, y = 0; ctx.beginPath(); ctx.moveTo(x, y); while (y < H * 0.75) { x += (Math.random() - 0.5) * 50; y += 24; ctx.lineTo(x, y); } ctx.stroke(); }
        ctx.restore();
      }

      /* particles */
      for (const p of parts) {
        const f = 1 - p.t / p.max;
        if (p.text) {
          ctx.save(); ctx.globalAlpha = Math.min(1, f * 2); ctx.fillStyle = p.col; ctx.font = '700 ' + (p.big ? 22 : 13) + 'px ' + (p.big ? DISP : FONT);
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.strokeStyle = 'rgba(16,12,23,0.85)'; ctx.lineWidth = 4; ctx.strokeText(p.text, p.x, p.y); ctx.fillText(p.text, p.x, p.y); ctx.restore();
        } else {
          ctx.globalAlpha = Math.max(0, f); ctx.fillStyle = p.col;
          if (p.plus) { ctx.fillRect(p.x - p.r * 1.5, p.y - 0.8, p.r * 3, 1.6 + 0.6); ctx.fillRect(p.x - 0.8, p.y - p.r * 1.5, 1.6 + 0.6, p.r * 3); }
          else { ctx.beginPath(); ctx.arc(p.x, p.y, p.r * (0.5 + f * 0.5), 0, 7); ctx.fill(); }
          ctx.globalAlpha = 1;
        }
      }
      ctx.restore();
      if (flash > 0.02) { ctx.fillStyle = 'rgba(238,80,60,' + (flash * 0.28).toFixed(3) + ')'; ctx.fillRect(0, 0, W, H); }
    }
    function drawShot(e, at, t) {
      const tl = timeline(e), k = e.k, S = SP[k];
      const cancelled = e.f & (F.LOST | F.TIE), refl = e.f & F.REFL;
      const A = posOf(e.s), B = posOf(e.t);
      let x, y, vis = false;
      if (k === BOLT) {
        // jagged lightning, instant
        const draws = [];
        if (at >= 1.0 && at < 1.3) draws.push([A, B, 1.3 - at]);
        if (refl && at >= 1.3 && at < 1.6) draws.push([B, A, 1.6 - at]);
        for (const [P, Q, life] of draws) {
          ctx.save(); ctx.globalAlpha = Math.min(1, life * 5); ctx.strokeStyle = S.col; ctx.shadowColor = S.col; ctx.shadowBlur = 20; ctx.lineWidth = 3.5; ctx.lineJoin = 'round';
          for (let r2 = 0; r2 < 2; r2++) { ctx.beginPath(); ctx.moveTo(P.x, P.y); const seg = 9; for (let q = 1; q < seg; q++) { const f = q / seg; ctx.lineTo(P.x + (Q.x - P.x) * f + (Math.random() - 0.5) * 26, P.y + (Q.y - P.y) * f + (Math.random() - 0.5) * 12); } ctx.lineTo(Q.x, Q.y); ctx.stroke(); ctx.lineWidth = 1.5; ctx.strokeStyle = '#fffbe6'; }
          ctx.restore();
        }
        return;
      }
      if (k === METEOR) {
        const T = refl ? A : B;
        if (at >= 0.75 && at < 1.45) { const f = ease((at - 0.75) / 0.7); const sx = B.x + 120, sy = -30; x = sx + (B.x - sx) * f; y = sy + (B.y - sy) * f; vis = true; }
        if (refl && at >= 1.45 && at < 1.85) { const f = ease((at - 1.45) / 0.4); x = B.x + (T.x - B.x) * f; y = B.y + (T.y - B.y) * f; vis = true; }
        if (vis) {
          for (let q = 0; q < 3; q++) spawn({ x: x + (Math.random() - 0.5) * 14, y: y + (Math.random() - 0.5) * 14, vx: 30 + Math.random() * 40, vy: -40 - Math.random() * 40, life: 0.45, col: q ? '#ff9a3d' : '#ffd36b', r: 4 });
          ctx.save(); ctx.shadowColor = '#ff5a8a'; ctx.shadowBlur = 26; const g = ctx.createRadialGradient(x - 4, y - 4, 2, x, y, 17); g.addColorStop(0, '#ffe0b0'); g.addColorStop(0.5, '#c2543e'); g.addColorStop(1, '#5a2a26');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 17, 0, 7); ctx.fill(); ctx.restore();
        }
        return;
      }
      // orbs: fly to the middle (clash) or all the way; reflections bounce back
      const mid = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 };
      if (at >= tl.go) {
        if (cancelled) { if (at < tl.meet) { const f = ease((at - tl.go) / (tl.meet - tl.go)); x = A.x + (mid.x - A.x) * f; y = A.y + (mid.y - A.y) * f; vis = true; } }
        else if (e.f & F.WIN) {
          if (at < tl.meet) { const f = ease((at - tl.go) / (tl.meet - tl.go)); x = A.x + (mid.x - A.x) * f; y = A.y + (mid.y - A.y) * f; vis = true; }
          else if (at < tl.hit) { const f = ease((at - tl.meet) / (tl.hit - tl.meet)); x = mid.x + (B.x - mid.x) * f; y = mid.y + (B.y - mid.y) * f; vis = true; }
        } else if (at < tl.arr) { const f = ease((at - tl.go) / (tl.arr - tl.go)); x = A.x + (B.x - A.x) * f; y = A.y + (B.y - A.y) * f; vis = true; }
        else if (refl && at < tl.hit) { const f = ease((at - tl.arr) / (tl.hit - tl.arr)); x = B.x + (A.x - B.x) * f; y = B.y + (A.y - B.y) * f; vis = true; if (!e.pinged) { e.pinged = 1; Snd.ping(); } }
      }
      if (!vis) return;
      const rad = k === FROST ? 8 : 10;
      if (Math.random() < 0.8) spawn({ x, y, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 40, life: 0.4, col: S.col, r: k === 2 ? 2.4 : 2.8 });
      ctx.save(); ctx.shadowColor = S.col; ctx.shadowBlur = 22;
      if (S.id === 'vine') {
        ctx.translate(x, y); ctx.rotate(t * 9);
        ctx.fillStyle = S.col; for (let q = 0; q < 3; q++) { ctx.rotate(Math.PI * 2 / 3); ctx.beginPath(); ctx.ellipse(7, 0, 8, 3.6, 0, 0, 7); ctx.fill(); }
        ctx.fillStyle = '#e9ffd8'; ctx.beginPath(); ctx.arc(0, 0, 3, 0, 7); ctx.fill();
      } else if (S.id === 'frost') {
        ctx.translate(x, y); ctx.rotate(Math.atan2(B.y - A.y, B.x - A.x));
        ctx.fillStyle = S.col; ctx.beginPath(); ctx.moveTo(13, 0); ctx.lineTo(0, 6); ctx.lineTo(-10, 0); ctx.lineTo(0, -6); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(8, 0); ctx.lineTo(0, 2.5); ctx.lineTo(-4, 0); ctx.lineTo(0, -2.5); ctx.fill();
      } else {
        const g = ctx.createRadialGradient(x, y, 1, x, y, rad);
        g.addColorStop(0, '#fffbe6'); g.addColorStop(0.45, S.col); g.addColorStop(1, shade(S.col, -0.4));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, rad, 0, 7); ctx.fill();
      }
      ctx.restore();
    }

    /* ---- main loop ---- */
    const stop = U.loop((dt, now) => {
      if (dead) return;
      stepTrace(dt);
      stepAnim(dt);
      if (roundBanner > 0) roundBanner -= dt;
      shake *= Math.pow(0.02, dt); flash *= Math.pow(0.02, dt);
      for (let q = parts.length - 1; q >= 0; q--) { const p = parts[q]; p.t += dt; if (p.t >= p.max) { parts.splice(q, 1); continue; } p.x += p.vx * dt; p.y += p.vy * dt; if (!p.text) { p.vx *= 0.96; p.vy *= 0.96; } }
      // time limit (paused while the tutorial / rules / a sheet is open)
      ovCheck -= dt;
      if (ovCheck <= 0) { ovCheck = 0.25; ovOpen = !!document.querySelector('.tut-card, .overlay[data-core]:not(.result)'); }
      if (st && st.tl && canDraw()) {
        if (ovOpen) tPause += dt * 1000;
        const tl = timeLeft();
        if (tl <= 5 && tl > 0 && Math.ceil(tl) !== lastTick) { lastTick = Math.ceil(tl); Snd.tick(); }
        if (tl <= 0 && !dragging && !trace) cast(true);
      }
      draw(now);
    });

    function update(next, prev) {
      const first = !st;
      st = next;
      if (prev && prev !== next && next.last && next.last.id !== seenId) { seenId = next.last.id; startAnim(next.last); }
      else if (next.last) seenId = next.last.id;
      if (first || !prev) { for (let i = 0; i < st.n; i++) { shownHP[i] = st.hp[i]; shownM[i] = st.m[i]; } }
      if (!canDraw() && !anim && (st.ph !== 'c' || drawer() < 0)) { dragging = false; }
      layout(); syncHand(); refreshButtons();
    }
    cv.onresize = () => { layout(); };

    return {
      update,
      destroy() {
        dead = true; stop(); cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp);
        removeEventListener('keydown', onKeyEsc, true);
        if (offInput) offInput();
        timers.forEach(clearTimeout); timers.clear();
        if (busy) api.setBusy(false);
        cv.destroy(); root.innerHTML = '';
      },
    };
  }

  const RUNE_KEYS = [['KeyQ', 'Numpad7'], ['KeyW', 'Numpad8'], ['KeyE', 'Numpad9'], ['KeyA', 'Numpad4'], ['KeyS', 'Numpad5'], ['KeyD', 'Numpad6'], ['KeyZ', 'Numpad1'], ['KeyX', 'Numpad2'], ['KeyC', 'Numpad3']];
  const RUNE_NM = ['왼쪽 위', '위', '오른쪽 위', '왼쪽', '가운데', '오른쪽', '왼쪽 아래', '아래', '오른쪽 아래'];
  /* ---------- 도감 (codex): generated from SP / BEAT / constants above ---------- */
  function runeSvg(k) {
    const xy = (i) => [8 + (i % 3) * 12, 8 + Math.floor(i / 3) * 12];
    let dots = '';
    for (let i = 0; i < 9; i++) { const [x, y] = xy(i); dots += '<circle cx="' + x + '" cy="' + y + '" r="1.8" fill="currentColor" opacity=".45"/>'; }
    const pts = SP[k].p.map((i) => xy(i).join(',')).join(' ');
    return '<svg viewBox="0 0 40 40" aria-hidden="true">' + dots + '<polyline points="' + pts + '" fill="none" stroke="' + SP[k].col + '" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  }
  function spCodex() {
    const more = (S, k) => {
      const o = [];
      if (S.el) { const lose = Object.keys(BEAT).find((x) => BEAT[x] === S.el); o.push(ELN[lose] + '에 져요(이기면 피해 +1, 같은 속성끼리는 둘 다 사라져요)'); }
      if (S.dm) o.push((k === BOLT || k === METEOR ? '' : '방패에 막히고 ') + '거울에 되돌아와요');
      if (k === HEALK) o.push('같은 라운드에 받은 피해도 메워요(최대 체력까지)');
      return o.length ? ' ' + o.join(' · ') + '.' : '';
    };
    return [
      { h: '주문', p: ['그림은 마법진 모양(시작점·방향은 상관없어요). 마나는 처음 ' + M0 + ', 라운드마다 +' + REGEN + ' (최대 ' + MMAX + ').'],
        rows: SP.map((S, k) => ({ icon: runeSvg(k), name: S.n, tag: '마나 ' + S.c + (S.dm ? ' · 피해 ' + S.dm : '') + (S.el ? ' · ' + ELN[S.el] + ' 속성' : ''),
          desc: S.d + '.' + more(S, k) })) },
      { h: '상성 규칙', p: [
        Object.keys(BEAT).map((e) => ELN[e] + ' ▶ ' + ELN[BEAT[e]]).join(' · ') + '.',
        '서로를 노린 속성 주문끼리만 부딪쳐요. 이긴 쪽은 피해 +1로 들어가고 진 쪽은 사라져요. 같은 속성이면 둘 다 사라져요.',
        '번개·서리·별똥별은 부딪치지 않고 그대로 날아가요.',
        '방패: 나를 노린 공격을 막아요. 번개는 못 막고, 별똥별은 반만 막아요.',
        '거울: 나를 노린 공격을 쏜 사람에게 그대로 되돌려요. 공격이 안 오면 헛수고.',
        '기 모으기 중에 맞으면 피해 +1. 시간이 끝나도 못 고르면 기 모으기가 나가요.',
        '마력 폭풍: ' + (STORM0 + 1) + '라운드부터 모두 체력 −1 (' + (STORM0 + 6) + '라운드부터 −2, ' + (STORM0 + 11) + '라운드부터 −3). ' + RMAX + '라운드가 끝나면 체력이 가장 많은 사람이 이겨요.'] },
    ];
  }
  L.register({
    id: 'spell', name: '마법진 결투', tag: '룬 그리기 결투', cat: '파티',
    blurb: '룬을 이어 마법진을 그리면 주문이 나가요. 모두 몰래 그리고 동시에 공개 — 상성과 마나를 읽는 수 싸움!',
    tint: '#3b2466',
    icon: '<circle cx="28" cy="28" r="23" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="17" fill="none" stroke="currentColor" stroke-width="1.5" opacity=".5"/><path d="M18 39L28 14l10 25-24-15h28z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="28" cy="14" r="3" fill="currentColor"/><circle cx="18" cy="39" r="3" fill="currentColor"/><circle cx="38" cy="39" r="3" fill="currentColor"/><circle cx="14" cy="24" r="3" fill="currentColor"/><circle cx="42" cy="24" r="3" fill="currentColor"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: true, aiDelay: 2000,
    options: [
      { id: 'hp', label: '체력', choices: [{ v: 15, label: '15 (짧게)' }, { v: 20, label: '20' }, { v: 30, label: '30 (길게)' }], def: 20 },
      { id: 'tl', label: '그리기 시간', choices: [{ v: 20, label: '20초' }, { v: 10, label: '10초 (빠르게)' }, { v: 0, label: '제한 없음' }], def: 20 },
    ],
    quick: [
      '가운데 원의 룬(점)을 손가락으로 이어 모양을 그리면 그 주문이 준비돼요. 📖 주문책에서 눌러도 돼요.',
      '라운드마다 모두 몰래 주문을 고르고, 다 고르면 동시에 공개돼요.',
      '상성·방패·거울로 맞받아쳐 상대 체력을 0으로! 마지막까지 남으면 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '마법사끼리 주문을 주고받는 결투예요. 상대의 체력(처음 20)을 0으로 만들면 이겨요.',
        '3–4명이면 모두가 서로의 적이에요. 마지막까지 남은 한 명이 이겨요.'] },
      { h: '한 라운드', p: [
        '① 모두 몰래 마법진을 그려 주문을 골라요 (기본 20초).',
        '② 「시전」을 누르면 준비 완료. 상대에겐 「준비 완료」만 보이고 무슨 주문인지는 안 보여요.',
        '③ 모두 고르면 주문이 한꺼번에 공개되고 결과가 나와요. 그리고 다음 라운드!'] },
      { h: '그리는 법', p: [
        '원 안의 점 9개(룬) 중 하나를 누르고 손가락을 떼지 않고 다음 룬으로 끌어요. 방향과 시작점은 상관없어요.',
        '모양이 맞으면 위에 주문 이름이 떠요. 그리다 보면 가장 비슷한 주문의 남은 선이 점선으로 보여요.',
        '틀렸으면 그냥 새로 그리면 돼요(「지우기」도 있어요).',
        '📖 주문책에서 주문을 누르면 마법진에 자동으로 그려 줘요.',
        '시간이 끝나면 그려 둔 주문이 나가고, 없으면 「기 모으기」가 나가요.'] },
      { h: '주문 10가지 (괄호 = 마나)', p: SP.map((S) => S.n + ' (' + S.c + '): ' + S.d) },
      { h: '상성과 막기', p: [
        '물살 ▶ 불꽃 ▶ 덩굴 ▶ 물살. 서로를 노린 속성 주문끼리 부딪치면 이긴 쪽은 피해 +1로 들어가고 진 쪽은 사라져요.',
        '같은 속성끼리 부딪치면 둘 다 사라져요. 번개·서리·별똥별은 부딪치지 않고 그대로 날아가요.',
        '방패는 나를 노린 공격을 막아요. 번개는 못 막고, 별똥별은 반만 막아요.',
        '거울은 나를 노린 공격을 쏜 사람에게 그대로 되돌려요. 공격이 안 오면 헛수고예요.',
        '기 모으기를 하다 맞으면 피해가 1 더 들어가요.'] },
      { h: '마나와 체력', p: [
        '처음 마나는 3, 라운드마다 +2 (최대 10). 마나가 모자란 주문은 쓸 수 없어요.',
        '모두의 체력과 마나가 보여요. 상대 마나를 보고 다음 수를 읽어 보세요.',
        '치유는 같은 라운드에 받은 피해도 메워요 (최대 체력까지).'] },
      { h: '마력 폭풍 · 끝내기', p: [
        '11라운드부터 마력 폭풍이 불어 라운드마다 모두 체력이 1씩 깎여요 (16라운드부터 2, 21라운드부터 3).',
        '마지막 마법사들이 같은 라운드에 함께 쓰러지면 덜 깎인 쪽이 이겨요. 똑같으면 무승부.',
        '30라운드가 끝나면 체력이 가장 많은 사람이 이겨요.'] },
      { h: '예시', p: [
        '내가 불꽃, 상대가 물살 → 물살이 이겨서 내 불꽃은 사라지고 나만 피해 5를 받아요.',
        '상대 마나가 1뿐 → 공격 주문(마나 2 이상)을 못 써요. 방패나 기 모으기를 할 테니 번개(방패 뚫기)가 좋아요.',
        '상대 마나가 4 이상 → 별똥별(피해 8)이 올 수 있어요. 거울로 되돌리면 상대가 8을 맞아요!'] },
      { h: '여럿이 할 때', p: [
        '공격 주문을 그린 뒤 위쪽 상대를 눌러 노릴 사람을 골라요 (기본: 체력이 가장 적은 상대).',
        '한 폰에서 여럿이 하면 이름이 뜰 때 폰을 넘겨 차례로 몰래 그려요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 골라요. 어려움은 마나·체력과 내 버릇까지 읽어요.'] },
      { h: 'PC 조작', p: [
        '마우스로 끌어서 그려요. 키보드는 Q W E / A S D / Z X C (또는 숫자패드)가 룬 9개예요.',
        'Enter·스페이스 = 시전, Backspace = 지우기, B = 주문책.'] },
    ],
    tutorial: [
      { sel: '.sp-gridbox', text: '이 원이 내 마법진이에요. 룬(점)을 손가락으로 이어 모양을 그리면 그 모양의 주문이 준비돼요.' },
      { sel: '.sp-book', text: '📖 주문책에 10가지 모양과 효과가 다 있어요. 책에서 주문을 누르면 자동으로 그려 줘요.' },
      { sel: '.sp-cast', text: '모양이 맞으면 「시전」! 상대도 몰래 고르고, 모두 고르면 동시에 공개돼요.' },
      { sel: '.sp-oppbox', text: '상대의 체력과 마나(파란 구슬)는 다 보여요. 마나가 적으면 큰 주문을 못 써요 — 읽고 맞받아치세요.' },
      { sel: '.sp-mebox', text: '상성: 물살 ▶ 불꽃 ▶ 덩굴 ▶ 물살. 방패는 막고(번개는 뚫음), 거울은 되돌려요. 마나가 모자라면 기 모으기(세로 한 줄)!' },
    ],
    controls: [
      ...RUNE_KEYS.map((keys, i) => ({ id: 'r' + i, label: '룬 ' + (i + 1) + ' (' + RUNE_NM[i] + ')', keys })),
      { id: 'cast', label: '시전', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'clear', label: '지우기', keys: ['Backspace'], pad: ['b'] },
      { id: 'book', label: '주문책', keys: ['KeyB'], pad: ['y'] },
    ],
    codex: spCodex(),
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { SP, outcome, edgesOf, match, guess, enc, dec, F, choices },
  });
})();
