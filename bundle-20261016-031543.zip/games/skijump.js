/* 스키점프 — 노멀힐(K90) / 라지힐(K120) / 플라잉힐(K185). 한 사람씩 번갈아 뛰고 라운드마다 순위 역순으로 출발한다.
   점수 = 거리 점수(K점 기준 ± 미터당 점수) + 자세 점수(심판 5명, 최고·최저 제외) + 바람 보정(선택).
   뛰는 기기는 실시간 입력(도약 타이밍 ms, 균형 누름/뗌 틱 목록, 착지 틱)을 비행 기록으로 보내고,
   apply는 상태 안의 바람·시드로 같은 시뮬레이션을 다시 돌려 거리와 점수를 계산한다(거리 값을 직접 보낼 수 없음).
   다른 기기는 같은 기록으로 점프를 다시 재생한다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const DEG = Math.PI / 180, DT = 0.01, MAXK = 1500, MINTAP = 30, MAXTG = 80;
  const TA = 10.5 * DEG, POP = 2.4, KL = 0.0046, KD = 0.0034, CW = 0.03;
  const IN_D = 3.0; // seconds of in-run before the table edge (live)
  const HILLS = {
    N: { K: 90, HS: 100, bm: 34.5, v0: 24.4, ppm: 2.0, base: 60, hf: 6.0, name: '노멀힐' },
    L: { K: 120, HS: 134, bm: 35.5, v0: 26.0, ppm: 1.8, base: 60, hf: 8.0, name: '라지힐' },
    F: { K: 185, HS: 215, bm: 36, v0: 29.9, ppm: 1.2, base: 120, hf: 9.5, name: '플라잉힐' },
  };
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const sq = (v) => v * v;
  const r1 = (v) => Math.round(v * 10) / 10;

  /* ---------- hill profile (m): x right, y up, origin = table edge ---------- */
  const HC = {};
  function hill(id) {
    if (HC[id]) return HC[id];
    const P = HILLS[id], K = P.K, HS = P.HS, bm = P.bm;
    const h0 = 0.03 * K, s1 = 0.3 * K, s2 = K, s3 = HS + 0.5 * K, end = s3 + 0.9 * K;
    const beta = (s) => {
      if (s < s1) { const f = s / s1, sm = f * f * (3 - 2 * f); return (2 + (bm - 2) * sm) * DEG; }
      if (s < s2) return bm * DEG;
      if (s < s3) { const f = (s - s2) / (s3 - s2); return bm * DEG * (0.5 + 0.5 * Math.cos(Math.PI * f)); }
      return 0;
    };
    let x = 0, y = -h0, s = 0;
    const ds = 0.25, pts = [[x, y, s]];
    while (s < end) { const b = beta(s + ds / 2); x += Math.cos(b) * ds; y -= Math.sin(b) * ds; s += ds; pts.push([x, y, s]); }
    const DX = 0.5, n = Math.ceil(x / DX) + 1, Y = new Float64Array(n), S = new Float64Array(n);
    let j = 0;
    for (let i = 0; i < n; i++) {
      const xx = i * DX;
      while (j < pts.length - 2 && pts[j + 1][0] < xx) j++;
      const a = pts[j], b = pts[j + 1], f = clamp((xx - a[0]) / (b[0] - a[0] || 1), 0, 1);
      Y[i] = a[1] + (b[1] - a[1]) * f; S[i] = a[2] + (b[2] - a[2]) * f;
    }
    HC[id] = { id, K, HS, h0, Y, S, DX, xmax: (n - 1) * DX, s3, yEnd: Y[n - 1] };
    return HC[id];
  }
  function hy(H, x) {
    if (x <= 0) return -H.h0 - x * 0.35; // ground under the in-run rises gently behind the table
    const i = x / H.DX; if (i >= H.Y.length - 1) return H.yEnd;
    const k = Math.floor(i), f = i - k; return H.Y[k] + (H.Y[k + 1] - H.Y[k]) * f;
  }
  function hs(H, x) {
    if (x <= 0) return 0;
    const i = x / H.DX; if (i >= H.S.length - 1) return H.S[H.S.length - 1] + (x - H.xmax);
    const k = Math.floor(i), f = i - k; return H.S[k] + (H.S[k + 1] - H.S[k]) * f;
  }
  function xAtS(H, s) {
    const S = H.S;
    if (s <= 0) return 0;
    if (s >= S[S.length - 1]) return H.xmax + (s - S[S.length - 1]);
    let lo = 0, hi = S.length - 1;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (S[m] < s) lo = m; else hi = m; }
    return (lo + (s - S[lo]) / (S[hi] - S[lo] || 1)) * H.DX;
  }
  /* seconds until touching the slope at the current approach rate */
  function ttg(H, x, y, vx, vy) { const gap = y - hy(H, x), sl = (hy(H, x + 1) - hy(H, x - 1)) / 2, ap = sl * vx - vy; return ap > 0.05 ? gap / ap : 99; }
  function slopeAt(H, x) { return Math.atan2(hy(H, x + 0.5) - hy(H, x - 0.5), 1); }

  /* ---------- jump simulation (shared by live play, apply, AI and replay) ---------- */
  function gustOf(sd, w10) {
    const a = sd % 997, b = Math.floor(sd / 997) % 991, c = Math.floor(sd / 987000) % 983;
    return { A: 5 + 2.5 * Math.abs(w10 / 10), f1: 1.3 + (a % 100) / 100, f2: 2.9 + (b % 100) / 60, p1: a * 0.0063, p2: b * 0.0063, p3: c * 0.0063 };
  }
  function gust(G, k) {
    const t = k * DT;
    return G.A * (0.6 * Math.sin(G.f1 * t + G.p1) + 0.4 * Math.sin(G.f2 * t + G.p2) + 0.25 * Math.sin(0.5 * t + G.p3));
  }
  /* take-off quality from timing (ms; <0 early, >0 late) */
  function qOf(t) { return Math.max(0, 1 - Math.pow(Math.abs(t) / (t < 0 ? 260 : 200), 1.5)); }
  function newRun(hid, w10, sd, t) {
    const P = HILLS[hid], H = hill(hid);
    const v = P.v0 * (1 - 0.08 * Math.max(0, -t) / 1000);
    return { hid, H, w: w10 / 10, G: gustOf(sd, w10), k: 0, x: 0, y: 0, px: 0, py: 0, vx: v * Math.cos(-TA), vy: v * Math.sin(-TA),
      e: 3, om: 0, t, pk: t > 0 ? Math.round(t / 10) : 0, popped: false, tap: -1, T: -1, se: 0, ne: 0, lx: 0 };
  }
  function doPop(r) {
    const q = qOf(r.t);
    r.vx += Math.sin(TA) * POP * q; r.vy += Math.cos(TA) * POP * q;
    r.e = clamp(r.e + clamp(r.t / 25, -8, 8), -25, 25);
    r.popped = true;
  }
  function step(r, hold, tapNow) {
    if (r.T >= 0) return;
    if (!r.popped && r.k >= r.pk) doPop(r);
    if (tapNow && r.tap < 0 && r.k >= MINTAP) r.tap = r.k;
    if (r.tap < 0) {
      const tr = hold ? -17 : 11;
      r.om += (tr + gust(r.G, r.k) - r.om) * DT / 0.12;
      r.e = clamp(r.e + r.om * DT, -25, 25);
      r.se += Math.abs(r.e); r.ne++;
    } else { r.e *= 0.96; r.om = 0; }
    const tp = r.tap >= 0, e = r.e;
    const rx = r.vx + r.w, ry = r.vy, sp = Math.sqrt(rx * rx + ry * ry);
    const fL = Math.max(0.3, 1 - sq(e / 28)) * (tp ? 0.55 : 1) * (1 + CW * r.w);
    const fD = (1 + 0.5 * sq(Math.max(0, e) / 20) + 0.15 * sq(e / 20)) * (tp ? 1.4 : 1);
    r.vx += (-KD * fD * sp * rx - KL * fL * sp * ry) * DT;
    r.vy += (-KD * fD * sp * ry + KL * fL * sp * rx - 9.81) * DT;
    r.px = r.x; r.py = r.y;
    r.x += r.vx * DT; r.y += r.vy * DT; r.k++;
    const g = hy(r.H, r.x);
    if (r.y <= g || r.k >= MAXK) {
      const g0 = hy(r.H, r.px), d0 = r.py - g0, d1 = r.y - g, f = d0 - d1 > 1e-9 ? clamp(d0 / (d0 - d1), 0, 1) : 1;
      r.lx = r.px + (r.x - r.px) * f;
      r.T = r.k;
    }
  }
  /* rerun a flight record {t, h:[toggle ticks], l} */
  function simulate(hid, w10, sd, rec, cb) {
    const r = newRun(hid, w10, sd, rec.t);
    let hi = 0, hold = false;
    while (r.T < 0) {
      while (hi < rec.h.length && rec.h[hi] <= r.k) { hold = !hold; hi++; }
      step(r, hold, rec.l >= 0 && r.k >= rec.l);
      if (cb) cb(r, hold);
    }
    return r;
  }
  const TK = ['완벽한 도약', '좋은 도약', '', '']; // [2]/[3] filled by early/late text
  function tkClass(t) { const a = Math.abs(t); return a <= 45 ? 0 : a <= 110 ? 1 : a <= 190 ? 2 : 3; }
  function tkText(t) { const c = tkClass(t); return c < 2 ? TK[c] : (t < 0 ? (c === 3 ? '너무 빠른 도약' : '빠른 도약') : (c === 3 ? '너무 늦은 도약' : '늦은 도약')); }
  const LD = ['텔레마크', '텔레마크', '두 발 착지', '불안한 착지', '넘어짐'];
  const LDED = [0, 0.5, 2, 2.5, 7];
  function ldClass(lead) {
    if (lead == null || lead < 0.06) return 4;
    if (lead < 0.12) return 3;
    if (lead < 0.18) return 1;
    if (lead <= 0.45) return 0;
    if (lead <= 0.6) return 1;
    return 2;
  }
  function windPts(hid, w10) { const w = w10 / 10, hf = HILLS[hid].hf; return r1(w > 0 ? -w * hf : -w * hf * 1.21) + 0; }
  function distPts(hid, d) { const P = HILLS[hid]; return Math.max(0, r1(P.base + (d - P.K) * P.ppm)); }
  /* full scoring of a record */
  function judge(hid, w10, sd, rec, wcOn) {
    const r = simulate(hid, w10, sd, rec);
    const H = r.H;
    const d = Math.round(hs(H, r.lx) * 2) / 2;
    const lead = r.tap >= 0 ? (r.T - r.tap) * DT : null;
    const ld = ldClass(lead), tk = tkClass(rec.t);
    const me = r.ne ? r.se / r.ne : 0;
    const ded = [0, 0.5, 1, 1.5][tk] + clamp((me - 2.5) * 0.25, 0, 3) + LDED[ld];
    const st = [];
    for (let j = 0; j < 5; j++) {
      const nz = (Math.floor(sd / Math.pow(3, j + 2)) % 3 - 1) * 0.5;
      st.push(clamp(Math.round((20 - ded + nz) * 2) / 2, 0, 20));
    }
    const so = st.slice().sort((a, b) => a - b), sty = so[1] + so[2] + so[3];
    const dp = distPts(hid, d), wp = wcOn ? windPts(hid, w10) : 0;
    const p = Math.max(0, r1(dp + sty + wp));
    return { d, dp, st, sty, wp, p, tk, ld, fall: ld === 4 ? 1 : 0, me: r1(me), T: r.T, tap: r.tap, lead };
  }

  /* ---------- rules / state ---------- */
  function rnd(s) { s.rs = (s.rs * 48271) % 2147483647; return s.rs / 2147483647; }
  function nextJump(s) {
    const g = rnd(s) + rnd(s) + rnd(s) - 1.5;
    s.w = Math.round(clamp(0.3 + g * 1.6, -2.0, 2.5) * 10);
    s.sd = 1 + Math.floor(rnd(s) * 2147483000);
  }
  function init(players, opts) {
    const n = players.length;
    const hl = opts && HILLS[opts.hill] ? opts.hill : 'NLF'[Math.floor(Math.random() * 3)];
    const R = opts && [1, 2, 3].includes(+opts.rounds) ? +opts.rounds : 2;
    const s = { n, hl, R, wc: opts && opts.wind === 'off' ? 0 : 1, r: 0, ord: players.map((p, i) => i), i: 0,
      js: players.map(() => []), tot: players.map(() => 0), w: 0, sd: 1, rs: 1 + Math.floor(Math.random() * 2147483640),
      nm: players.map((p) => String(p.name || '').slice(0, 10)), seq: 0, last: null, ph: 'p' };
    nextJump(s);
    return s;
  }
  function actor(s) { return s.ph === 'e' ? null : s.ord[s.i]; }
  function validRec(a) {
    if (!a || a.type !== 'jump' || !Number.isInteger(a.t) || !Array.isArray(a.h) || !Number.isInteger(a.l)) return false;
    if (a.h.length > MAXTG || a.l < -1 || a.l > MAXK) return false;
    let p = -1;
    for (const v of a.h) { if (!Number.isInteger(v) || v < 0 || v > MAXK || v <= p) return false; p = v; }
    return true;
  }
  function apply(s, seat, a) {
    if (s.ph !== 'p' || actor(s) !== seat) throw new Error('not your turn');
    if (!validRec(a)) throw new Error('bad flight record');
    const rec = { t: clamp(a.t, -300, 250), h: a.h.slice(), l: a.l };
    const res = judge(s.hl, s.w, s.sd, rec, s.wc);
    s.seq++;
    s.js[seat].push([res.d * 2, Math.round(res.p * 10), res.fall]);
    s.tot[seat] += Math.round(res.p * 10);
    s.last = { id: s.seq, s: seat, r: s.r, t: rec.t, h: rec.h, l: rec.l, w: s.w, sd: s.sd, d: res.d, dp: res.dp, st: res.st, wp: res.wp, p: res.p, tk: res.tk, ld: res.ld };
    s.i++;
    if (s.i >= s.n) {
      s.r++; s.i = 0;
      if (s.r >= s.R) s.ph = 'e';
      else { const prev = s.ord.slice(); s.ord = prev.slice().sort((x, y) => s.tot[x] - s.tot[y] || prev.indexOf(x) - prev.indexOf(y)); } // leader jumps last
    }
    nextJump(s);
    return s;
  }
  function rankOrder(s) { return s.tot.map((v, i) => i).sort((a, b) => s.tot[b] - s.tot[a] || a - b); }
  function result(s) {
    if (s.ph !== 'e') return null;
    const best = Math.max(...s.tot), w = s.tot.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const lines = rankOrder(s).map((i, k) => (k + 1) + '위 ' + nm(i) + ' · ' + (s.tot[i] / 10).toFixed(1) + '점 (' + s.js[i].map((j) => (j[0] / 2).toFixed(1) + 'm' + (j[2] ? '↓' : '')).join(' · ') + ')');
    return { winners: w, title: s.n === 1 ? (best / 10).toFixed(1) + '점' : w.length > 1 ? '공동 우승' : undefined,
      text: HILLS[s.hl].name + ' K' + HILLS[s.hl].K + ' · ' + s.R + '라운드\n' + lines.join('\n') };
  }

  /* ---------- AI: same controller loop a person would run, with level-dependent reaction/noise ---------- */
  const LVJ = {
    1: { st: 110, dl: 26, th: 5.5, nz: 3, lm: 0.34, ls: 0.2, lapse: 0.6 },
    2: { st: 48, dl: 13, th: 2.4, nz: 1.2, lm: 0.31, ls: 0.08, lapse: 0.12 },
    3: { st: 18, dl: 5, th: 1.0, nz: 0.4, lm: 0.3, ls: 0.035, lapse: 0 },
  };
  function gauss(R) { let u = 0, v = 0; while (u === 0) u = R(); while (v === 0) v = R(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  function mkR(seed) { let x = seed; return () => { x = (x * 48271) % 2147483647; return x / 2147483647; }; }
  function aiFly(s, P, seed, tapAt) {
    const R = mkR(seed);
    const t = Math.round(clamp(gauss(R) * P.st, -300, 250));
    const r = newRun(s.hl, s.w, s.sd, t);
    const hist = [], h = [];
    let hold = false, nz = 0, lapse = R() < P.lapse ? 30 + Math.floor(R() * 200) : -1, lapseEnd = lapse + 40 + Math.floor(R() * 40);
    while (r.T < 0) {
      hist.push(r.e);
      if (r.k % 10 === 0) nz = gauss(R) * P.nz;
      const pe = hist[Math.max(0, hist.length - 1 - P.dl)] + nz;
      const off = r.k >= lapse && r.k < lapseEnd;
      let want = hold;
      if (!off) { if (!hold && pe > P.th) want = true; else if (hold && pe < -P.th * 0.4) want = false; }
      if (want !== hold && h.length < MAXTG) { hold = want; h.push(r.k); }
      step(r, hold, tapAt >= 0 && r.k >= tapAt);
    }
    return { t, h, T: r.T };
  }
  function ai(s, seat, lv) {
    const P = LVJ[lv] || LVJ[2];
    const seed = 1 + Math.floor(Math.random() * 2147483000);
    const a = aiFly(s, P, seed, -1);
    const R = mkR(1 + (seed * 7 + 13) % 2147483000);
    const lead = P.lm + gauss(R) * P.ls;
    const l = Math.max(MINTAP, a.T - Math.round(lead / DT));
    const b = aiFly(s, P, seed, l);
    return { type: 'jump', t: b.t, h: b.h, l: lead < 0.03 ? -1 : l };
  }

  /* ================================= view ================================= */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = L.h('div', { class: 'hud top', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px', alignItems: 'stretch' } });
    root.append(top);
    let st = null, G = null, time = 0, anim = null, myPend = null, pops = [], spray = [], hintFlash = 0, waitTimer = 0;
    const cam = { x: -20, y: 20, sc: 9, init: false };
    const ptrs = new Map(); // pointerId -> 'bal' | 'land'
    const snow = Array.from({ length: 70 }, () => ({ x: Math.random(), y: Math.random(), z: 0.4 + Math.random() * 0.8, p: Math.random() * 7 }));
    const color = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const pname = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || '');
    const sp = () => L.debug.speed || 1;

    /* landscape (main layout): a one-line scoreboard, the hill seen wide (further down the slope), the 착지 button at the
       right edge and a 「누르고 있기」 pad at the left edge for the thumbs. Portrait (fallback): the old tall layout. */
    function layout() {
      const land = cv.w > cv.h * 1.15, was = G && G.land;
      G = { W: cv.w, H: cv.h, land, topH: G && was === land ? G.topH : land ? 40 : 72 };
      top.style.padding = land ? '4px 8px' : '8px 10px';
      if (was !== land) { hudKey = ''; if (st) renderTop(anim && anim.ph !== 'card' ? anim.snap : st, anim ? anim.seat : actor(st)); }
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    const SX = (x) => G.W * 0.5 + (x - cam.x) * cam.sc, SY = (y) => G.H * 0.5 - (y - cam.y) * cam.sc;

    /* in-run path: u = metres before the table edge */
    const INR = {};
    function inrun(hid) {
      if (INR[hid]) return INR[hid];
      const pts = [[0, 0]]; let x = 0, y = 0;
      for (let u = 0.25; u <= 90; u += 0.25) {
        const f = clamp((u - 6) / 18, 0, 1), a = (10.5 + (35 - 10.5) * f * f * (3 - 2 * f)) * DEG;
        x -= Math.cos(a) * 0.25; y += Math.sin(a) * 0.25; pts.push([x, y]);
      }
      INR[hid] = pts; return pts;
    }
    function inrunAt(hid, u) {
      const p = inrun(hid), i = clamp(u / 0.25, 0, p.length - 2), k = Math.floor(i), f = i - k;
      const a = p[k], b = p[k + 1];
      return { x: a[0] + (b[0] - a[0]) * f, y: a[1] + (b[1] - a[1]) * f, ang: Math.atan2(a[1] - b[1], a[0] - b[0]) };
    }
    const inLen = (hid) => HILLS[hid].v0 * IN_D / 2;

    function humanTurn() {
      if (!st || st.ph === 'e') return false;
      const a = actor(st);
      return a != null && api.canAct(a);
    }

    /* ---------- jumper pose drawing ---------- */
    function drawJumper(x, y, ang, pose, col, e, k2) {
      // ang: ski direction (rad, math coords); pose: 'crouch'|'pop'|'fly'|'tele'|'land'|'fall'
      const s = cam.sc * 1.55;
      ctx.save();
      ctx.translate(SX(x), SY(y));
      ctx.rotate(-ang);
      const skiL = 2.5 * s;
      const drawSki = (dx, dy, c, w) => {
        ctx.strokeStyle = c; ctx.lineWidth = w; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(-skiL * 0.38 + dx, dy); ctx.lineTo(skiL * 0.58 + dx, dy); ctx.quadraticCurveTo(skiL * 0.66 + dx, dy, skiL * 0.68 + dx, dy - 0.1 * s); ctx.stroke();
      };
      const suit = col, dark = 'rgba(15,12,22,.85)';
      if (pose === 'fly') {
        // V-style: the far ski opens upward, both skis spread at the tips
        ctx.save(); ctx.rotate(-0.16); drawSki(0, -0.08 * s, 'rgba(40,36,52,.75)', Math.max(1.6, 0.11 * s)); ctx.restore();
        drawSki(0, 0, '#22202c', Math.max(2, 0.13 * s));
        ctx.fillStyle = '#ffe14d'; ctx.fillRect(skiL * 0.55, -0.06 * s, 0.12 * s, 0.12 * s);
        // body nearly parallel to the skis, leaning forward over them
        const bodyA = -(0.32 + clamp(e, -25, 25) * 0.012);
        ctx.rotate(bodyA);
        ctx.fillStyle = suit; ctx.strokeStyle = dark; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.ellipse(0.85 * s, -0.12 * s, 0.95 * s, 0.24 * s, 0, 0, 7); ctx.fill(); ctx.stroke();
        // arms along the body
        ctx.strokeStyle = suit; ctx.lineWidth = Math.max(1.5, 0.12 * s);
        ctx.beginPath(); ctx.moveTo(1.4 * s, -0.08 * s); ctx.lineTo(0.35 * s, 0.12 * s); ctx.stroke();
        // helmet
        ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(1.95 * s, -0.2 * s, 0.2 * s, 0, 7); ctx.fill();
        ctx.fillStyle = '#5bb3e6'; ctx.fillRect(2.0 * s, -0.24 * s, 0.14 * s, 0.08 * s);
      } else if (pose === 'fall') {
        ctx.rotate((k2 || 0) * 5);
        drawSki(-0.4 * s, 0.1 * s, '#22202c', Math.max(2, 0.13 * s));
        ctx.save(); ctx.rotate(0.9); drawSki(0, 0, 'rgba(40,36,52,.8)', Math.max(1.6, 0.11 * s)); ctx.restore();
        ctx.fillStyle = suit; ctx.beginPath(); ctx.ellipse(0, -0.35 * s, 0.75 * s, 0.3 * s, 0.6, 0, 7); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(0.6 * s, -0.75 * s, 0.2 * s, 0, 7); ctx.fill();
      } else {
        drawSki(0, 0, '#22202c', Math.max(2, 0.13 * s));
        ctx.fillStyle = '#ffe14d'; ctx.fillRect(skiL * 0.55, -0.06 * s, 0.12 * s, 0.12 * s);
        ctx.strokeStyle = suit; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(2, 0.2 * s);
        let hip, knee, sh, head, arm;
        if (pose === 'crouch') { knee = [0.45, -0.45]; hip = [-0.15, -0.55]; sh = [0.55, -0.85]; head = [0.85, -0.85]; arm = [[0.3, -0.55], [-0.3, -0.45]]; }
        else if (pose === 'pop') { knee = [0.35, -0.6]; hip = [0.05, -1.0]; sh = [0.75, -1.45]; head = [1.0, -1.6]; arm = [[0.3, -1.1], [-0.2, -0.9]]; }
        else if (pose === 'tele') { knee = [0.6, -0.4]; hip = [0.1, -0.8]; sh = [0.3, -1.45]; head = [0.42, -1.75]; arm = [[-0.5, -1.35], [1.1, -1.4]]; }
        else { knee = [0.4, -0.5]; hip = [0.05, -0.85]; sh = [0.35, -1.45]; head = [0.5, -1.75]; arm = [[-0.3, -1.2], [0.9, -1.2]]; }
        const P = (p) => [p[0] * s, p[1] * s];
        const ank = P([0.1, -0.05]);
        ctx.beginPath(); ctx.moveTo(ank[0], ank[1]); ctx.lineTo(...P(knee)); ctx.lineTo(...P(hip)); ctx.stroke();
        if (pose === 'tele') { ctx.globalAlpha = 0.7; ctx.beginPath(); ctx.moveTo(-0.45 * s, -0.05 * s); ctx.lineTo(-0.35 * s, -0.4 * s); ctx.lineTo(...P(hip)); ctx.stroke(); ctx.globalAlpha = 1; }
        ctx.lineWidth = Math.max(2.4, 0.3 * s);
        ctx.beginPath(); ctx.moveTo(...P(hip)); ctx.lineTo(...P(sh)); ctx.stroke();
        ctx.lineWidth = Math.max(1.5, 0.12 * s);
        ctx.beginPath(); ctx.moveTo(...P(sh)); ctx.lineTo(...P(arm[0])); ctx.moveTo(...P(sh)); ctx.lineTo(...P(arm[1])); ctx.stroke();
        ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(head[0] * s, head[1] * s, 0.2 * s, 0, 7); ctx.fill();
      }
      ctx.restore();
    }

    /* ---------- scene ---------- */
    function mtn(x, seed, amp) { return amp * (0.5 * Math.sin(x * 0.011 + seed) + 0.3 * Math.sin(x * 0.027 + seed * 2.1) + 0.2 * Math.sin(x * 0.061 + seed * 3.7)); }
    function drawSky() {
      const { W, H } = G;
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#0d1230'); g.addColorStop(0.55, '#2a2350'); g.addColorStop(1, '#4b3b67');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(242,233,216,.55)';
      for (let i = 0; i < 40; i++) { const x = ((i * 97.3 - cam.x * 0.4) % W + W) % W, y = (i * 53.7) % (H * 0.45); ctx.fillRect(x, y, i % 3 ? 1 : 1.6, i % 3 ? 1 : 1.6); }
      // moon
      ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.beginPath(); ctx.arc(W * 0.8, H * 0.18, 16, 0, 7); ctx.fill();
      ctx.fillStyle = '#18183a'; ctx.beginPath(); ctx.arc(W * 0.8 + 6, H * 0.18 - 4, 14, 0, 7); ctx.fill();
      // far mountains (parallax)
      const layers = [[0.06, '#2f2b55', 0.62, 70, 1.3], [0.16, '#252142', 0.74, 55, 4.2]];
      for (const [pf, c, base, amp, seed] of layers) {
        ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(0, H);
        const oy = (cam.y * cam.sc) * pf * 0.25;
        for (let x = 0; x <= W + 8; x += 8) { const wx = x / 1 + cam.x * cam.sc * pf; ctx.lineTo(x, H * base - mtn(wx, seed, amp) + oy); }
        ctx.lineTo(W, H); ctx.closePath(); ctx.fill();
        if (pf > 0.1) { // snow caps hint
          ctx.strokeStyle = 'rgba(200,210,240,.12)'; ctx.lineWidth = 2; ctx.beginPath();
          for (let x = 0; x <= W + 8; x += 8) { const wx = x + cam.x * cam.sc * pf; const yy = H * base - mtn(wx, seed, amp) + oy; x ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy); }
          ctx.stroke();
        }
      }
    }
    function drawWorld(hid) {
      const H = hill(hid), P = HILLS[hid], { W } = G;
      const xL = cam.x - W / 2 / cam.sc - 4, xR = cam.x + W / 2 / cam.sc + 4;
      // floodlight poles (behind)
      for (let s0 = -40; s0 < H.s3 + 80; s0 += 45) {
        const x = s0 < 0 ? s0 : xAtS(H, s0); if (x < xL - 10 || x > xR + 10) continue;
        const gy = hy(H, x) + 4, ty = gy + 26;
        ctx.strokeStyle = '#1b1830'; ctx.lineWidth = Math.max(1.5, 0.35 * cam.sc);
        ctx.beginPath(); ctx.moveTo(SX(x), SY(gy - 6)); ctx.lineTo(SX(x), SY(ty)); ctx.stroke();
        ctx.fillStyle = '#fff6d8'; ctx.fillRect(SX(x) - 0.9 * cam.sc, SY(ty) - 0.3 * cam.sc, 1.8 * cam.sc, 0.6 * cam.sc);
        const lg = ctx.createRadialGradient(SX(x), SY(ty), 0, SX(x), SY(ty), 9 * cam.sc);
        lg.addColorStop(0, 'rgba(255,240,200,.28)'); lg.addColorStop(1, 'rgba(255,240,200,0)');
        ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(SX(x), SY(ty), 9 * cam.sc, 0, 7); ctx.fill();
      }
      // judge tower beside the hill near the K point
      {
        const x = xAtS(H, P.K) - 6, gy = hy(H, x), w = 7, hgt = 20;
        if (x + w > xL && x - w < xR) {
          ctx.fillStyle = '#2b2440'; ctx.fillRect(SX(x - w / 2), SY(gy + hgt), w * cam.sc, (hgt + 6) * cam.sc);
          ctx.fillStyle = '#3b3256'; ctx.fillRect(SX(x - w / 2 - 0.6), SY(gy + hgt + 1.2), (w + 1.2) * cam.sc, 1.4 * cam.sc);
          ctx.fillStyle = '#ffd98a'; ctx.fillRect(SX(x - w / 2 + 0.5), SY(gy + hgt - 1.2), (w - 1) * cam.sc, 2.6 * cam.sc);
          ctx.fillStyle = '#2b2440';
          for (let j = 0; j < 5; j++) { const jx = x - w / 2 + 0.9 + j * 1.3; ctx.beginPath(); ctx.arc(SX(jx), SY(gy + hgt - 2.3), 0.38 * cam.sc, 0, 7); ctx.fill(); }
          ctx.fillStyle = 'rgba(242,233,216,.8)'; ctx.font = '700 ' + Math.max(9, Math.round(cam.sc * 1.1)) + 'px "IBM Plex Sans KR", sans-serif';
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('심판석', SX(x), SY(gy + hgt + 2.8));
        }
      }
      // crowd stands at the outrun
      {
        const x0 = xAtS(H, H.s3) + 4, x1 = x0 + 70, gy = H.yEnd;
        if (x1 > xL && x0 < xR) {
          ctx.fillStyle = '#2a2340';
          ctx.beginPath(); ctx.moveTo(SX(x0), SY(gy)); ctx.lineTo(SX(x0 + 8), SY(gy + 7)); ctx.lineTo(SX(x1), SY(gy + 7)); ctx.lineTo(SX(x1), SY(gy)); ctx.closePath(); ctx.fill();
          const cols = ['#ee6a55', '#5bb3e6', '#e8c04e', '#5fd3a0', '#b48cf0', '#f2e9d8', '#f07fb8'];
          for (let row = 0; row < 5; row++) for (let i = 0; i < 46; i++) {
            const cx = x0 + 3 + row * 1.6 + i * 1.45, cy = gy + 1.1 + row * 1.25 + 0.25 * Math.sin(time * 6 + i * 1.3 + row);
            if (cx > x1 - 1) continue;
            ctx.fillStyle = cols[(i * 7 + row * 3) % cols.length]; ctx.beginPath(); ctx.arc(SX(cx), SY(cy), Math.max(1.2, 0.42 * cam.sc), 0, 7); ctx.fill();
          }
          for (let i = 0; i < 6; i++) { // flags
            const fx = x0 + 8 + i * 11, fy = gy + 8.5, wv = Math.sin(time * 4 + i) * 0.4;
            ctx.strokeStyle = '#d8d0c0'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(SX(fx), SY(gy + 6)); ctx.lineTo(SX(fx), SY(fy + 1.5)); ctx.stroke();
            ctx.fillStyle = cols[i % cols.length]; ctx.beginPath(); ctx.moveTo(SX(fx), SY(fy + 1.5)); ctx.lineTo(SX(fx + 2.6), SY(fy + 1 + wv)); ctx.lineTo(SX(fx), SY(fy + 0.4)); ctx.fill();
          }
        }
      }
      // in-run tower: truss + track
      {
        const p = inrun(hid), uMax = inLen(hid) + 6, top = inrunAt(hid, uMax);
        ctx.strokeStyle = '#3a3152'; ctx.lineWidth = Math.max(1, 0.25 * cam.sc);
        for (let u = 4; u < uMax; u += 4) {
          const a = inrunAt(hid, u), gy = hy(H, a.x);
          if (a.x < xL - 5 || a.x > xR + 5) continue;
          ctx.beginPath(); ctx.moveTo(SX(a.x), SY(a.y - 0.6)); ctx.lineTo(SX(a.x), SY(gy - 2));
          const b = inrunAt(hid, u + 4); ctx.lineTo(SX(b.x), SY(b.y - 0.6)); ctx.stroke();
        }
        ctx.strokeStyle = '#4a3f66'; ctx.lineWidth = Math.max(3, 1.0 * cam.sc);
        ctx.beginPath();
        for (let i = 0; i < p.length && i * 0.25 <= uMax; i += 2) { const q = p[i]; i ? ctx.lineTo(SX(q[0]), SY(q[1] - 0.5)) : ctx.moveTo(SX(q[0]), SY(q[1] - 0.5)); }
        ctx.stroke();
        ctx.strokeStyle = '#e9eef8'; ctx.lineWidth = Math.max(1.5, 0.35 * cam.sc);
        ctx.beginPath();
        for (let i = 0; i < p.length && i * 0.25 <= uMax; i += 2) { const q = p[i]; i ? ctx.lineTo(SX(q[0]), SY(q[1])) : ctx.moveTo(SX(q[0]), SY(q[1])); }
        ctx.stroke();
        // start cabin
        ctx.fillStyle = '#3b3256'; ctx.fillRect(SX(top.x - 3), SY(top.y + 4), 4 * cam.sc, 4.6 * cam.sc);
        ctx.fillStyle = '#ffd98a'; ctx.fillRect(SX(top.x - 2.2), SY(top.y + 3), 1.6 * cam.sc, 1.2 * cam.sc);
        // table edge mark
        ctx.fillStyle = '#ee6a55'; ctx.fillRect(SX(-0.3), SY(0.15), 0.6 * cam.sc, 0.5 * cam.sc);
      }
      // landing hill
      const g = ctx.createLinearGradient(0, SY(cam.y + 30), 0, G.H);
      g.addColorStop(0, '#f1f5fb'); g.addColorStop(1, '#b9c6e2');
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(SX(xL), G.H + 5);
      const stp = Math.max(0.5, 3 / cam.sc);
      for (let x = xL; x <= xR; x += stp) ctx.lineTo(SX(x), SY(hy(H, x)));
      ctx.lineTo(SX(xR), G.H + 5); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(120,140,190,.45)'; ctx.lineWidth = 1;
      for (let dd = 1; dd < 4; dd++) { ctx.beginPath(); for (let x = xL; x <= xR; x += stp * 2) { const yy = SY(hy(H, x)) + dd * dd * 5; x === xL ? ctx.moveTo(SX(x), yy) : ctx.lineTo(SX(x), yy); } ctx.stroke(); }
      // distance markers along the slope + ad fence
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const fs = Math.max(9, Math.min(13, Math.round(cam.sc * 1.2)));
      for (let d = Math.max(10, Math.floor((P.K - 60) / 5) * 5); d <= P.HS + 30; d += 5) {
        const x = xAtS(H, d); if (x < xL || x > xR) continue;
        const y = hy(H, x), isK = d === P.K, big = d % 10 === 0;
        ctx.strokeStyle = isK ? '#e0413a' : d === P.HS ? '#2b2440' : big ? 'rgba(60,70,120,.55)' : 'rgba(60,70,120,.3)';
        ctx.lineWidth = isK || d === P.HS ? 3 : big ? 1.6 : 1;
        ctx.beginPath(); ctx.moveTo(SX(x), SY(y) + 1); ctx.lineTo(SX(x), SY(y) + (isK ? 14 : big ? 10 : 5)); ctx.stroke();
        if (big || isK) {
          const by = SY(y + 2.6);
          ctx.fillStyle = isK ? '#e0413a' : 'rgba(33,28,50,.82)'; rr(SX(x) - 13, by - 7, 26, 14, 3); ctx.fill();
          ctx.fillStyle = '#f2e9d8'; ctx.font = '600 ' + fs + 'px "IBM Plex Mono", monospace'; ctx.fillText(isK ? 'K' + d : String(d), SX(x), by + 0.5);
        }
      }
      { const x = xAtS(H, P.HS); if (x > xL && x < xR) { ctx.fillStyle = '#2b2440'; ctx.font = '700 ' + fs + 'px "IBM Plex Sans KR", sans-serif'; ctx.fillText('HS' + P.HS, SX(x), SY(hy(H, x)) + 22); } }
    }
    function drawFlagAt(hid, d, col, label) {
      const H = hill(hid), x = xAtS(H, d), y = hy(H, x);
      if (SX(x) < -20 || SX(x) > G.W + 20) return;
      ctx.strokeStyle = '#2b2440'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(SX(x), SY(y)); ctx.lineTo(SX(x), SY(y) - 22); ctx.stroke();
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(SX(x), SY(y) - 22); ctx.lineTo(SX(x) + 11, SY(y) - 18); ctx.lineTo(SX(x), SY(y) - 14); ctx.fill();
      if (label) { ctx.fillStyle = '#2b2440'; ctx.font = '600 10px "IBM Plex Mono", monospace'; ctx.textAlign = 'left'; ctx.fillText(label, SX(x) + 3, SY(y) - 28); }
    }
    /* distance that would put the current jumper in the lead (style 54, current wind) */
    function leadLine(s, seat) {
      if (!s || s.n < 2) return null;
      const others = s.tot.filter((v, i) => i !== seat);
      if (!others.some((v, i) => true) || s.js.every((j) => !j.length)) return null;
      const best = Math.max(...s.tot.map((v, i) => (i === seat ? -1 : v))) / 10;
      if (best <= 0) return null;
      const P = HILLS[s.hl], need = best - s.tot[seat] / 10 - 54 - (s.wc ? windPts(s.hl, s.w) : 0);
      const d = P.K + (need - P.base) / P.ppm;
      return d > 0 ? clamp(d, P.K - 60, P.HS + 40) : null;
    }
    function drawLeadLine(hid, d) {
      const H = hill(hid), x = xAtS(H, d), y = hy(H, x);
      if (SX(x) < -10 || SX(x) > G.W + 10) return;
      const g = ctx.createLinearGradient(0, SY(y + 14), 0, SY(y));
      g.addColorStop(0, 'rgba(95,211,160,0)'); g.addColorStop(1, 'rgba(95,211,160,.65)');
      ctx.fillStyle = g; ctx.fillRect(SX(x) - 1.5, SY(y + 14), 3, 14 * cam.sc);
      ctx.fillStyle = '#5fd3a0'; ctx.fillRect(SX(x) - 6, SY(y) - 1.5, 12, 3);
      ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(18,14,24,.75)'; rr(SX(x) - 24, SY(y + 14) - 16, 48, 15, 6); ctx.fill();
      ctx.fillStyle = '#5fd3a0'; ctx.fillText('선두 ' + d.toFixed(1), SX(x), SY(y + 14) - 8);
    }

    /* ---------- HUD (canvas) ---------- */
    function drawWind(w10, live) {
      const w = w10 / 10, x0 = 10, y0 = G.topH + 4, bw = 104, bh = 54;
      ctx.fillStyle = 'rgba(18,14,24,.84)'; rr(x0, y0, bw, bh, 12); ctx.fill();
      ctx.strokeStyle = 'rgba(242,233,216,.14)'; ctx.lineWidth = 1; ctx.stroke();
      const head = w > 0.05, tail = w < -0.05, col = head ? '#5fd3a0' : tail ? '#ee6a55' : '#ab9fb8';
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ab9fb8'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif';
      ctx.fillText(head ? '맞바람' : tail ? '뒷바람' : '바람 없음', x0 + 10, y0 + 14);
      ctx.fillStyle = '#f2e9d8'; ctx.font = '600 16px "IBM Plex Mono", monospace';
      ctx.fillText(Math.abs(w).toFixed(1), x0 + 10, y0 + 36);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 10px "IBM Plex Mono", monospace'; ctx.fillText('m/s', x0 + 44, y0 + 38);
      // gauge: horizontal bar, centre = calm, left = tail, right = head
      const gx = x0 + 68, gy = y0 + 12, gh = 32, gw = 26;
      ctx.fillStyle = 'rgba(242,233,216,.1)'; rr(gx, gy, gw, gh, 6); ctx.fill();
      const mid = gy + gh / 2, f = clamp(w / 2.5, -1, 1);
      ctx.fillStyle = col; rr(gx + 4, f > 0 ? mid - f * gh / 2 : mid, gw - 8, Math.abs(f) * gh / 2 + 1, 3); ctx.fill();
      ctx.fillStyle = 'rgba(242,233,216,.5)'; ctx.fillRect(gx + 2, mid - 0.5, gw - 4, 1);
      // little arrow showing direction relative to the jumper (who flies →)
      ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.beginPath();
      const ax = gx + gw / 2, dir = head ? -1 : 1; if (head || tail) { ctx.moveTo(ax - 7 * dir, y0 + bh - 5); ctx.lineTo(ax + 7 * dir, y0 + bh - 5); ctx.lineTo(ax + 3 * dir, y0 + bh - 8); ctx.moveTo(ax + 7 * dir, y0 + bh - 5); ctx.lineTo(ax + 3 * dir, y0 + bh - 2); ctx.stroke(); }
      void live;
    }
    function drawInfo(s) {
      const P = HILLS[s.hl];
      const t1 = s.ph === 'e' ? '경기 종료' : (s.R > 1 ? (Math.min(s.r, s.R - 1) + 1) + '라운드 · ' : '') + (s.i + 1) + '/' + s.n + '번째';
      const t2 = P.name + ' K' + P.K;
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const tw = Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width) + 22, x0 = G.W - 10 - tw, y0 = G.topH + 4;
      ctx.fillStyle = 'rgba(18,14,24,.84)'; rr(x0, y0, tw, 44, 12); ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t1, x0 + tw / 2, y0 + 14);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText(t2, x0 + tw / 2, y0 + 31);
    }
    function balGeom() {
      if (G.land) { const r = landGeom().r, w = Math.min(300, G.W - 4 * r - 90); return { x: (G.W - w) / 2, y: G.H - 38, w, h: 22 }; }
      const w = Math.min(250, G.W - 150), x = 16 + (G.W - 120 - w) / 2 + 4; return { x, y: G.H - 64, w, h: 22 };
    }
    function landGeom() {
      if (G.land) { const r = Math.round(clamp(G.H * 0.16, 44, 56)); return { x: G.W - r - 18, y: G.H - r - 16, r }; }
      return { x: G.W - 58, y: G.H - 66, r: 42 };
    }
    function holdGeom() { const r = landGeom().r; return { x: 14, y: G.H - 2 * r - 16, w: 2 * r + 16, h: 2 * r }; }
    function drawHoldPad(on) { // landscape: shows where the left thumb rests (the whole screen works, this is the obvious spot)
      const g = holdGeom();
      ctx.fillStyle = on ? 'rgba(46,107,84,.9)' : 'rgba(18,14,24,.6)'; rr(g.x, g.y, g.w, g.h, 16); ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = on ? '#5fd3a0' : 'rgba(242,233,216,.28)'; ctx.stroke();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = on ? '#f2e9d8' : '#ab9fb8';
      ctx.font = '400 17px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.fillText('누르기', g.x + g.w / 2, g.y + g.h / 2 - 9);
      ctx.font = '600 10px "IBM Plex Sans KR", sans-serif'; ctx.fillText(on ? '앞으로 숙이는 중' : '떼면 뒤로 젖혀요', g.x + g.w / 2, g.y + g.h / 2 + 12, g.w - 8);
    }
    function drawBalance(e, live, held) {
      const b = balGeom();
      ctx.fillStyle = 'rgba(18,14,24,.82)'; rr(b.x - 10, b.y - 26, b.w + 20, b.h + 36, 12); ctx.fill();
      const toX = (v) => b.x + b.w / 2 + clamp(v, -20, 20) / 20 * b.w / 2; // left = forward (hold), right = back
      const zone = (a, c) => { ctx.fillStyle = c; ctx.fillRect(toX(-a), b.y, toX(a) - toX(-a), b.h); };
      ctx.fillStyle = 'rgba(238,106,85,.55)'; rr(b.x, b.y, b.w, b.h, 6); ctx.fill();
      zone(10, 'rgba(227,174,69,.75)'); zone(4, '#5fd3a0');
      // needle (e>0 → too upright/back → right)
      const nx = toX(e);
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(nx, b.y - 3); ctx.lineTo(nx - 6, b.y - 11); ctx.lineTo(nx + 6, b.y - 11); ctx.closePath(); ctx.fill();
      ctx.fillRect(nx - 1.5, b.y - 3, 3, b.h + 6);
      ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textBaseline = 'middle';
      ctx.fillStyle = held ? '#5fd3a0' : '#ab9fb8'; ctx.textAlign = 'left'; ctx.fillText('◀ 앞으로', b.x, b.y - 16);
      ctx.fillStyle = !held && live ? '#e3ae45' : '#ab9fb8'; ctx.textAlign = 'right'; ctx.fillText('뒤로 ▶', b.x + b.w, b.y - 16);
      ctx.textAlign = 'center'; ctx.fillStyle = '#ab9fb8'; ctx.fillText('자세', b.x + b.w / 2, b.y - 16);
    }
    function drawLandBtn(on, glow, pressed) {
      const g = landGeom();
      ctx.save();
      if (glow > 0) { ctx.fillStyle = 'rgba(95,211,160,' + (0.18 + 0.25 * glow * (0.6 + 0.4 * Math.sin(time * 14))) + ')'; ctx.beginPath(); ctx.arc(g.x, g.y, g.r + 10, 0, 7); ctx.fill(); }
      ctx.fillStyle = pressed ? '#3d8f6c' : on ? '#2e6b54' : 'rgba(46,38,64,.85)';
      ctx.beginPath(); ctx.arc(g.x, g.y, g.r, 0, 7); ctx.fill();
      ctx.lineWidth = 2; ctx.strokeStyle = on ? '#5fd3a0' : 'rgba(242,233,216,.2)'; ctx.stroke();
      ctx.fillStyle = on ? '#f2e9d8' : '#ab9fb8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '400 19px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.fillText('착지', g.x, g.y - 4);
      ctx.font = '600 9.5px "IBM Plex Sans KR", sans-serif'; ctx.fillText('텔레마크', g.x, g.y + 14);
      ctx.restore();
    }
    function hint(text, col, y, topInLand) {
      if (G.land && topInLand) y = G.topH + 20;
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const w = ctx.measureText(text).width + 26, x = G.W / 2;
      ctx.fillStyle = 'rgba(18,14,24,.85)'; rr(x - w / 2, y - 13, w, 26, 13); ctx.fill();
      ctx.fillStyle = col || '#f2e9d8'; ctx.fillText(text, x, y + 0.5);
    }
    function drawPops() {
      for (const p of pops) {
        const a = p.t < 0.1 ? p.t / 0.1 : p.t > p.life - 0.25 ? Math.max(0, (p.life - p.t) / 0.25) : 1;
        ctx.save(); ctx.globalAlpha = a;
        ctx.font = '400 ' + (p.big ? 30 : 20) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const y = G.H * (p.big ? 0.3 : 0.36) - Math.min(1, p.t / 0.2) * 6;
        ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(18,14,24,.85)'; ctx.strokeText(p.text, G.W / 2, y);
        ctx.fillStyle = p.col; ctx.fillText(p.text, G.W / 2, y);
        ctx.restore();
      }
    }
    function pop(text, col, big, life) { pops = pops.filter((p) => p.big !== !!big); pops.push({ text, col, big: !!big, t: 0, life: (life || 1.1) / Math.sqrt(sp()) }); }

    /* ---------- score card ---------- */
    function drawCard(l, k) {
      const { W, H } = G, cw = Math.min(W - 28, 330), ch = st && st.wc ? 210 : 186, x0 = (W - cw) / 2;
      const y0 = G.land ? Math.max(G.topH + 6, Math.min(H * 0.45 - ch / 2, H - ch - 32)) : Math.max(G.topH + 64, H * 0.42 - ch / 2);
      const a = Math.min(1, k * 6);
      ctx.save(); ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(18,14,24,.93)'; rr(x0, y0 + (1 - a) * 12, cw, ch, 16); ctx.fill();
      ctx.strokeStyle = color(l.s); ctx.lineWidth = 2; ctx.stroke();
      const cx = x0 + 18;
      let y = y0 + 24;
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillStyle = color(l.s); ctx.beginPath(); ctx.arc(cx + 5, y, 5, 0, 7); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 14px "IBM Plex Sans KR", sans-serif'; ctx.fillText(pname(l.s), cx + 16, y);
      ctx.textAlign = 'right'; ctx.fillStyle = l.ld === 4 ? '#ee6a55' : l.ld <= 1 ? '#5fd3a0' : '#e3ae45';
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.fillText(LD[l.ld], x0 + cw - 18, y);
      y += 36;
      ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.font = '600 34px "IBM Plex Mono", monospace';
      ctx.fillText(l.d.toFixed(1), cx, y);
      const dw = ctx.measureText(l.d.toFixed(1)).width;
      ctx.font = '600 16px "IBM Plex Mono", monospace'; ctx.fillStyle = '#ab9fb8'; ctx.fillText('m', cx + dw + 4, y + 5);
      ctx.textAlign = 'right'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ab9fb8';
      ctx.fillText(tkText(l.t), x0 + cw - 18, y - 6);
      ctx.fillText((l.w > 0 ? '맞바람 ' : l.w < 0 ? '뒷바람 ' : '바람 ') + Math.abs(l.w / 10).toFixed(1) + 'm/s', x0 + cw - 18, y + 10);
      y += 32;
      const row = (lab, val, sub) => {
        ctx.textAlign = 'left'; ctx.fillStyle = '#ab9fb8'; ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.fillText(lab, cx, y);
        ctx.textAlign = 'right'; ctx.fillStyle = '#f2e9d8'; ctx.font = '600 14px "IBM Plex Mono", monospace'; ctx.fillText(val, x0 + cw - 18, y);
        if (sub) sub();
        y += 24;
      };
      row('거리 점수', l.dp.toFixed(1));
      const so = l.st.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]), drop = [so[0][1], so[4][1]];
      row('자세 점수', (so[1][0] + so[2][0] + so[3][0]).toFixed(1), () => {
        ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center';
        const jx = cx + 70, step = Math.min(34, (cw - 150) / 5);
        l.st.forEach((v, i) => {
          const x = jx + i * step, out = drop.includes(i);
          ctx.fillStyle = out ? 'rgba(171,159,184,.55)' : '#e3ae45'; ctx.fillText(v.toFixed(1), x + step / 2, y);
          if (out) { ctx.strokeStyle = 'rgba(171,159,184,.7)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x + 3, y); ctx.lineTo(x + step - 3, y); ctx.stroke(); }
        });
      });
      if (st && st.wc) row('바람 보정', (l.wp > 0 ? '+' : l.wp < 0 ? '−' : '') + Math.abs(l.wp).toFixed(1));
      ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.fillRect(cx, y - 10, cw - 36, 1);
      y += 10;
      ctx.textAlign = 'left'; ctx.fillStyle = '#ab9fb8'; ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const rank = st ? rankOrder(st).indexOf(l.s) + 1 : 0;
      ctx.fillText(st && st.n > 1 ? '합계 ' + (st.tot[l.s] / 10).toFixed(1) + ' · 현재 ' + rank + '위' : '합계 ' + (st ? (st.tot[l.s] / 10).toFixed(1) : ''), cx, y);
      ctx.textAlign = 'right'; ctx.fillStyle = '#e3ae45'; ctx.font = '400 26px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
      ctx.fillText(l.p.toFixed(1) + '점', x0 + cw - 18, y);
      if (k > 0.4) { // the card closes on its own; a tap closes it sooner
        ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center';
        const tw = ctx.measureText('탭하면 넘기기').width + 20;
        ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(W / 2 - tw / 2, y0 + ch + 6, tw, 22, 11); ctx.fill();
        ctx.fillStyle = '#ab9fb8'; ctx.fillText('탭하면 넘기기', W / 2, y0 + ch + 17.5);
      }
      ctx.restore();
    }

    /* ---------- top scoreboard (DOM) ---------- */
    let hudKey = '';
    function renderTop(s, cur) {
      if (!s) return;
      const land = !!(G && G.land);
      const key = JSON.stringify([s.tot, s.js.map((j) => j.length), cur, s.ph, land]);
      if (key === hudKey) return;
      hudKey = key;
      top.innerHTML = '';
      const rk = rankOrder(s);
      for (let i = 0; i < s.n; i++) {
        const p = api.players[i] || { name: s.nm[i], color: '#fff' }, on = cur === i;
        const js = s.js[i];
        if (land) { // landscape: one line per player (dot · name · rank · total)
          top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '4px 8px', display: 'flex', alignItems: 'center', gap: '5px', opacity: on || cur == null ? 1 : 0.68, borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color + ' inset' : '' } },
            L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
            L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto', fontSize: '12px', fontWeight: 700 }, text: p.name }),
            s.n > 1 && js.length ? L.h('span', { class: 'mono muted', style: { fontSize: '10px', flex: 'none' }, text: (rk.indexOf(i) + 1) + '위' }) : null,
            L.h('span', { class: 'mono', style: { fontSize: '16px', fontWeight: 600, lineHeight: 1, flex: 'none' }, text: (s.tot[i] / 10).toFixed(1) })));
          continue;
        }
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '6px 8px', display: 'flex', flexDirection: 'column', gap: '3px', opacity: on || cur == null ? 1 : 0.68, borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color + ' inset' : '' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
            L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto' }, text: p.name }),
            s.n > 1 && js.length ? L.h('span', { class: 'mono muted', style: { fontSize: '10px', flex: 'none' }, text: (rk.indexOf(i) + 1) + '위' }) : null),
          L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '3px' } },
            L.h('span', { class: 'mono', style: { fontSize: s.n > 3 ? '17px' : '20px', fontWeight: 600, lineHeight: 1 }, text: (s.tot[i] / 10).toFixed(1) }),
            L.h('span', { class: 'muted', style: { fontSize: '10px', fontWeight: 700 }, text: '점' })),
          L.h('div', { class: 'mono muted', style: { fontSize: '10px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minHeight: '13px' }, text: js.map((j) => (j[0] / 2).toFixed(1) + (j[2] ? '↓' : '')).join(' · ') || '—' })));
      }
      requestAnimationFrame(() => { const h = top.getBoundingClientRect().height; if (h && G && Math.abs(h + 4 - G.topH) > 1) G.topH = h + 4; });
    }

    /* ---------- animation driver ---------- */
    function startLive() {
      const seat = actor(st);
      anim = { mode: 'live', ph: 'ready', seat, hid: st.hl, w10: st.w, sd: st.sd, t: 0, tapT: null, run: null, acc: 0, rec: { t: 250, h: [], l: -1 }, hold: false, path: [], snap: st, seq: st.seq };
    }
    function startReplay(l, prev) {
      const hid = (prev || st).hl;
      const rec = { t: l.t, h: l.h, l: l.l };
      const path = [];
      const r = simulate(hid, l.w, l.sd, rec, (rn, hold) => path.push([rn.x, rn.y, rn.e, hold ? 1 : 0, rn.tap >= 0 ? 1 : 0, rn.popped ? 1 : 0]));
      anim = { mode: 'replay', ph: 'inrun', seat: l.s, hid, w10: l.w, sd: l.sd, t: 0, path, pi: 0, acc: 0, run: r, last: l, snap: prev || st, tkShown: false };
      cam.init = false; // cut straight to the start gate instead of panning up the empty hill
      api.setBusy(true);
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim && anim.last === l) endAnim(); }, 30000);
    }
    function endAnim() {
      anim = null; clearTimeout(waitTimer); pops = [];
      hudKey = ''; renderTop(st, st ? actor(st) : null);
      api.setBusy(false);
    }
    function curJumper() {
      if (!anim) return null;
      const a = anim, hid = a.hid, D = a.mode === 'live' ? IN_D : 1.5, Lin = inLen(hid);
      if (a.ph === 'ready') { const p = inrunAt(hid, Lin); return { x: p.x, y: p.y, ang: p.ang, pose: 'crouch' }; }
      if (a.ph === 'inrun') { const f = clamp(a.t / D, 0, 1), p = inrunAt(hid, Lin * (1 - f * f)); return { x: p.x, y: p.y, ang: p.ang, pose: a.tapT != null && a.t - a.tapT < 0.35 ? 'pop' : 'crouch' }; }
      if (a.ph === 'flight') {
        let x, y, e, vx, vy, k, popped, tap;
        if (a.mode === 'live') { const r = a.run; x = r.x; y = r.y; e = r.e; vx = r.vx; vy = r.vy; k = r.k; popped = r.popped; tap = r.tap >= 0; }
        else { const i = Math.min(a.path.length - 1, Math.floor(a.pi)), p = a.path[i], q = a.path[Math.max(0, i - 1)]; x = p[0]; y = p[1]; e = p[2]; vx = (p[0] - q[0]) / DT || 25; vy = (p[1] - q[1]) / DT; k = i; popped = p[5]; tap = p[4]; }
        const pa = Math.atan2(vy, vx);
        const gap = y - hy(hill(hid), x);
        const pose = !popped || k < 18 ? 'pop' : tap && gap < 2.2 ? 'tele' : 'fly';
        const ang = pose === 'fly' ? pa + (30 + e * 0.6) * DEG * 0.55 : pose === 'tele' ? slopeAt(hill(hid), x) : pa + 0.1;
        return { x, y, ang, pose, e, gap, tg: ttg(hill(hid), x, y, vx, vy) };
      }
      if (a.ph === 'out' || a.ph === 'card') {
        const H = hill(hid), x = xAtS(H, a.os), y = hy(H, x);
        const fall = a.fall;
        return { x, y: y + (fall ? 0.3 : 0), ang: slopeAt(H, x), pose: fall ? (a.ov > 2 ? 'fall' : 'fall') : a.ld <= 1 ? (a.t < 0.5 ? 'tele' : 'land') : 'land', spin: fall ? Math.min(a.t, 0.9) : 0 };
      }
      return null;
    }
    function toOut(r, ld) {
      const a = anim, H = r.H;
      a.ph = 'out'; a.t = 0;
      a.os = hs(H, r.lx); a.ov = Math.max(8, Math.sqrt(r.vx * r.vx + r.vy * r.vy) * 0.9);
      a.ld = ld; a.fall = ld === 4;
      const x = r.lx, y = hy(H, x);
      for (let i = 0; i < 26; i++) spray.push({ x, y, vx: (Math.random() * 0.6 + 0.2) * a.ov * 0.5, vy: Math.random() * 5 + 1, t: 0, life: 0.6 + Math.random() * 0.5 });
      api.sfx(a.fall ? 'hit' : 'thud'); api.buzz(a.fall ? 40 : 22);
      if (ld <= 1) setTimeout(() => api.sfx('pop'), 120);
    }
    function liveLanded() {
      const a = anim, r = a.run;
      const lead = r.tap >= 0 ? (r.T - r.tap) * DT : null, ld = ldClass(lead);
      toOut(r, ld);
      const d = Math.round(hs(r.H, r.lx) * 2) / 2;
      pop(d.toFixed(1) + ' m', '#f2e9d8', true, 1.6);
      setTimeout(() => { if (anim === a) pop(LD[ld] + (ld === 0 ? '!' : ''), ld === 4 ? '#ee6a55' : ld <= 1 ? '#5fd3a0' : '#e3ae45', false, 1.2); }, 250 / sp());
      // submit the flight record
      const rec = { type: 'jump', t: a.rec.t, h: a.rec.h, l: r.tap };
      myPend = { seq: st.seq, seat: a.seat };
      a.waitSeq = st.seq;
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim === a && !a.last) endAnim(); }, 6000);
      api.act(rec);
    }
    function liveStep(dt) {
      const a = anim;
      if (a.ph === 'inrun') {
        a.t += dt * sp();
        if (a.t >= IN_D) {
          const t = a.tapT != null ? clamp(Math.round((a.tapT - IN_D) * 1000), -300, -1) : 250;
          a.rec.t = t;
          a.run = newRun(a.hid, a.w10, a.sd, t);
          a.ph = 'flight'; a.acc = 0;
          if (a.tapT == null) a.lateOpen = true; // may still pop within 250 ms
          api.sfx('whoosh');
          if (a.tapT != null) { pop(tkText(t), tkClass(t) === 0 ? '#5fd3a0' : tkClass(t) === 1 ? '#e3ae45' : '#ee6a55'); api.buzz(tkClass(t) === 0 ? 25 : 12); }
        }
        return;
      }
      if (a.ph === 'flight') {
        a.acc += dt * sp() / DT;
        const r = a.run;
        while (a.acc >= 1 && r.T < 0) {
          a.acc -= 1;
          const hold = ptrCount('bal') > 0;
          if (a.lateOpen && (a.pendPop || r.k >= 25)) { // late take-off: the pop happens on this tick
            const missed = !a.pendPop, t = missed ? 250 : Math.max(1, r.k) * 10;
            r.t = t; r.pk = r.k; a.rec.t = t; a.lateOpen = false; a.pendPop = false;
            pop(missed ? '도약 놓침' : tkText(t), tkClass(t) === 0 ? '#5fd3a0' : tkClass(t) === 1 ? '#e3ae45' : '#ee6a55');
            api.buzz(missed ? 30 : 12);
          }
          if (!a.lateOpen && hold !== a.hold && a.rec.h.length < MAXTG && r.tap < 0) { a.hold = hold; a.rec.h.push(r.k); }
          step(r, a.hold, !!a.wantTap);
          if (r.tap >= 0) a.wantTap = false;
        }
        if (r.T >= 0) liveLanded();
      }
    }
    function replayStep(dt) {
      const a = anim;
      if (a.ph === 'inrun') {
        a.t += dt * sp();
        if (a.t >= 1.5) { a.ph = 'flight'; a.pi = 0; api.sfx('whoosh'); }
        return;
      }
      if (a.ph === 'flight') {
        a.pi += dt * sp() * 1.25 / DT;
        if (!a.tkShown && a.pi > Math.max(5, a.last.t / 10)) { a.tkShown = true; const c = tkClass(a.last.t); pop(tkText(a.last.t), c === 0 ? '#5fd3a0' : c === 1 ? '#e3ae45' : '#ee6a55'); }
        if (a.pi >= a.path.length - 1) {
          toOut(a.run, a.last.ld);
          pop(a.last.d.toFixed(1) + ' m', '#f2e9d8', true, 1.6);
        }
      }
    }
    function toCard(a) { a.ph = 'card'; a.ct = 0; pops = []; api.sfx('chip'); hudKey = ''; renderTop(st, a.seat); }
    function ptrCount(kind) { let n = 0; for (const v of ptrs.values()) if (v === kind) n++; return n; }

    const stopLoop = U.loop((dt) => {
      time += dt;
      if (!G || !st) return;
      if (hintFlash > 0) hintFlash -= dt;
      if (!anim && humanTurn()) startLive();
      if (anim) {
        if (anim.mode === 'live') liveStep(dt); else replayStep(dt);
        if (anim && (anim.ph === 'out' || anim.ph === 'card')) {
          const a = anim; a.t += dt * sp();
          const H = hill(a.hid);
          const dec = a.fall ? 14 : 5.5;
          a.ov = Math.max(0, a.ov - dec * dt * sp()); a.os += a.ov * dt * sp();
          if (a.ph === 'out' && a.t > 1.3 && a.last) toCard(a);
          if (a.ph === 'card') { a.ct += dt * sp(); if (a.ct > 3.2) endAnim(); }
          void H;
        }
      }
      for (const p of pops) p.t += dt;
      pops = pops.filter((p) => p.t < p.life);
      for (const s of spray) { s.t += dt; s.vy -= 9 * dt; s.x += s.vx * dt; s.y += s.vy * dt; }
      spray = spray.filter((s) => s.t < s.life);
      // camera
      const j = curJumper();
      const hid = anim ? anim.hid : st.hl;
      // landscape: zoom by the height and keep the flyer in the upper left so the slope ahead stays on screen
      let tx, ty, tsc = G.land ? clamp(G.H / 28, 8, 12) : clamp(G.W / 40, 8, 12);
      if (j) {
        const fl = anim.ph === 'flight';
        tx = j.x + (fl ? G.W * (G.land ? 0.2 : 0.16) / cam.sc : anim.ph === 'ready' ? 8 : 4);
        ty = j.y - (fl ? (G.land ? G.H * 0.22 / cam.sc : Math.min(9, G.H * 0.1 / cam.sc)) : 1);
        if (fl) tsc = G.land ? clamp(G.H / 34, 6.5, 11) : clamp(G.W / 46, 7, 11);
      } else { const p = inrunAt(hid, inLen(hid)); tx = p.x + 10; ty = p.y - 2; }
      if (!cam.init) { cam.x = tx; cam.y = ty; cam.sc = tsc; cam.init = true; }
      const k = Math.min(1, dt * (anim && anim.ph === 'flight' ? 6 : 3.5) * Math.sqrt(sp()));
      cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k; cam.sc += (tsc - cam.sc) * Math.min(1, dt * 2);
      draw(j);
    });

    function draw(j) {
      cv.clear();
      const s = st, a = anim;
      const hid = a ? a.hid : s.hl;
      drawSky();
      drawWorld(hid);
      // flags: each player's latest jump this round (from the board being shown)
      const bs = a ? a.snap : s;
      if (bs && bs.hl === hid) {
        for (let i = 0; i < bs.n; i++) { const js = bs.js[i]; if (js.length && (a ? a.seat !== i : true)) drawFlagAt(hid, js[js.length - 1][0] / 2, color(i)); }
        const seat = a ? a.seat : actor(s);
        if (seat != null && (!a || a.ph !== 'card')) { const d = leadLine(bs, seat); if (d) drawLeadLine(hid, d); }
      }
      if (a && (a.ph === 'out' || a.ph === 'card')) {
        const H = hill(hid), dd = a.last ? a.last.d : null;
        if (dd != null) drawFlagAt(hid, dd, color(a.seat), dd.toFixed(1));
        void H;
      }
      // spray
      ctx.fillStyle = 'rgba(245,248,255,.9)';
      for (const p of spray) { ctx.globalAlpha = 1 - p.t / p.life; ctx.beginPath(); ctx.arc(SX(p.x), SY(p.y), Math.max(1, 0.25 * cam.sc), 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
      // jumper (or an idle one waiting at the gate)
      if (j) drawJumper(j.x, j.y, j.ang, j.pose, color(a.seat), j.e || 0, j.spin || 0);
      else if (s.ph !== 'e') { const p = inrunAt(hid, inLen(hid)), seat = actor(s); drawJumper(p.x, p.y, p.ang, 'crouch', color(seat), 0, 0); }
      // falling snow
      ctx.fillStyle = 'rgba(240,244,255,.7)';
      for (const f of snow) {
        f.y += 0.0009 * f.z; f.x += Math.sin(time + f.p) * 0.0004 - 0.0006 * f.z * ((a ? a.w10 : s.w) / 10);
        if (f.y > 1) { f.y = 0; f.x = Math.random(); } if (f.x < 0) f.x += 1; if (f.x > 1) f.x -= 1;
        ctx.fillRect(f.x * G.W, f.y * G.H, 1.3 * f.z, 1.3 * f.z);
      }
      // HUD
      drawWind(a ? a.w10 : s.w);
      drawInfo(bs || s);
      const live = a && a.mode === 'live';
      if (a && a.ph === 'flight') {
        const e = j ? j.e : 0;
        drawBalance(e, live, live && a.hold);
        if (live) {
          const r = a.run, on = r.k >= MINTAP && r.tap < 0, tg = j ? j.tg : 99;
          if (G.land) drawHoldPad(ptrCount('bal') > 0);
          drawLandBtn(on, on && tg < 1.0 ? clamp((1.0 - tg) / 0.6, 0, 1) : 0, ptrCount('land') > 0 || r.tap >= 0);
          let t = '누르고 있으면 앞으로 숙여요 · 바늘을 초록에', c = '#f2e9d8';
          if (a.lateOpen) { t = '지금 탭! 도약'; c = '#ee6a55'; }
          else if (r.tap >= 0) { t = '착지 자세!'; c = '#5fd3a0'; }
          else if (tg < 0.9) { t = '땅이 가까워요 · 착지 버튼!'; c = '#5fd3a0'; }
          hint(t, c, G.H - 118, true);
        } else hint(pname(a.seat) + ' 점프 중 · 탭하면 건너뛰기', '#ab9fb8', G.H - 15);
        // speed readout
        ctx.font = '600 12px "IBM Plex Mono", monospace'; ctx.textAlign = 'right'; ctx.fillStyle = 'rgba(242,233,216,.85)';
        if (j) { const r = a.mode === 'live' ? a.run : null; const v = r ? Math.sqrt(r.vx * r.vx + r.vy * r.vy) : 0; if (r) ctx.fillText((v * 3.6).toFixed(1) + ' km/h', G.W - 12, G.topH + 64); }
      } else if (live && (a.ph === 'ready' || a.ph === 'inrun')) {
        const P = HILLS[a.hid];
        if (a.ph === 'ready') hint('화면을 탭하면 출발해요', '#e3ae45', G.H - 70);
        else {
          const left = IN_D - a.t;
          hint(hintFlash > 0 ? '아직이에요! 도약대 끝에서 탭' : left > 0.9 ? '도약대 끝(빨간 선)에서 탭!' : '지금…!', hintFlash > 0 ? '#ee6a55' : left > 0.9 ? '#f2e9d8' : '#5fd3a0', G.H - 70);
          const f = clamp(a.t / IN_D, 0, 1);
          ctx.font = '600 13px "IBM Plex Mono", monospace'; ctx.textAlign = 'right'; ctx.fillStyle = 'rgba(242,233,216,.9)';
          ctx.fillText((P.v0 * f * 3.6).toFixed(1) + ' km/h', G.W - 12, G.topH + 64);
          // timing bar: closes in on the edge
          const bw = Math.min(240, G.W - 60), bx = (G.W - bw) / 2, by = G.H - 40;
          ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(bx - 6, by - 9, bw + 12, 18, 9); ctx.fill();
          const ex = bx + bw * 0.85;
          ctx.fillStyle = 'rgba(95,211,160,.35)'; ctx.fillRect(ex - bw * 0.045, by - 5, bw * 0.09, 10);
          ctx.fillStyle = '#ee6a55'; ctx.fillRect(ex - 1, by - 7, 2, 14);
          const px = bx + bw * 0.85 * Math.min(1.15, (a.t / IN_D) ** 2);
          ctx.fillStyle = color(a.seat); ctx.beginPath(); ctx.arc(px, by, 5, 0, 7); ctx.fill();
        }
      } else if (!a && s.ph !== 'e') {
        const seat = actor(s), p = api.players[seat];
        if (p && !api.canAct(seat)) hint(p.name + (p.ai ? ' 준비 중…' : ' 차례'), '#ab9fb8', G.H - 30);
      } else if (a && a.mode === 'replay' && a.ph !== 'card') {
        drawBalanceMini(a, j);
        hint(pname(a.seat) + ' 점프 중 · 탭하면 건너뛰기', '#ab9fb8', G.H - 22);
      }
      drawPops();
      if (a && a.ph === 'card' && a.last) drawCard(a.last, a.ct);
    }
    function drawBalanceMini(a, j) {
      if (a.ph !== 'flight' || !j) return;
      void a;
    }

    /* ---------- input ---------- */
    const el = cv.cv;
    function inLand(p) { const g = landGeom(); return Math.hypot(p.x - g.x, p.y - g.y) <= g.r + 8; }
    function onDown(ev) {
      if (!G || !st) return;
      const p = cv.local(ev);
      const a = anim;
      try { el.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
      if (!a) return;
      if (a.mode === 'replay') { // skip to the score card
        if (a.ph === 'inrun' || a.ph === 'flight') { a.pi = a.path.length; a.ph = 'flight'; replayStep(0); }
        else if (a.ph === 'out' && a.last) toCard(a);
        else if (a.ph === 'card' && a.ct > 0.4) endAnim();
        return;
      }
      if (a.ph === 'ready') {
        a.ph = 'inrun'; a.t = 0; api.setBusy(true); api.sfx('click'); api.buzz(10);
        return;
      }
      if (a.ph === 'inrun') {
        if (a.tapT != null) { ptrs.set(ev.pointerId, 'bal'); return; }
        if (a.t < IN_D - 0.6) { hintFlash = 0.9; api.buzz(6); return; }
        a.tapT = a.t; ptrs.set(ev.pointerId, 'bal'); api.sfx('tick'); api.buzz(14);
        return;
      }
      if (a.ph === 'flight') {
        const r = a.run;
        if (inLand(p)) {
          ptrs.set(ev.pointerId, 'land');
          if (!a.lateOpen && r.k >= MINTAP && r.tap < 0) { a.wantTap = true; api.sfx('click'); api.buzz(16); }
          return;
        }
        ptrs.set(ev.pointerId, 'bal');
        if (a.lateOpen) { a.pendPop = true; api.sfx('tick'); api.buzz(14); }
        else api.buzz(5);
        return;
      }
      if (a.ph === 'card' && a.ct > 0.4) endAnim();
      else if (a.ph === 'out' && a.last) toCard(a);
    }
    function onUp(ev) { ptrs.delete(ev.pointerId); }
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);
    el.addEventListener('lostpointercapture', onUp);
    cv.onresize = () => layout();
    layout();

    return {
      _dbg: () => ({ anim, G, cam }),
      update(next, prev) {
        st = next;
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          if (myPend && l.id === myPend.seq + 1 && l.s === myPend.seat && anim && anim.mode === 'live') {
            anim.last = l; myPend = null; clearTimeout(waitTimer);
            waitTimer = setTimeout(() => { if (anim && anim.last === l) endAnim(); }, 20000);
          } else {
            if (anim) { anim = null; }
            myPend = null;
            startReplay(l, prev);
          }
        } else if (anim && anim.mode === 'live' && anim.ph === 'ready' && (!humanTurn() || anim.seq !== next.seq)) {
          anim = null;
        }
        renderTop(anim && anim.ph !== 'card' ? anim.snap : next, anim ? anim.seat : actor(next));
      },
      destroy() {
        stopLoop(); clearTimeout(waitTimer);
        el.removeEventListener('pointerdown', onDown); el.removeEventListener('pointerup', onUp);
        el.removeEventListener('pointercancel', onUp); el.removeEventListener('lostpointercapture', onUp);
        cv.destroy(); top.remove();
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'skijump', name: '스키점프', tag: '텔레마크 착지', cat: '스포츠',
    blurb: '도약대 끝에서 탭해 날아오르고, 공중에선 눌러서 자세를 잡고, 땅에 닿기 직전 착지 버튼으로 텔레마크! 거리 점수와 심판 자세 점수를 합해 겨뤄요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 500, landscape: true,
    tint: '#1d3a63',
    icon: '<path d="M4 50C18 50 26 24 52 20" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M6 14L22 22" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M20 30L44 12M22 34L46 18" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><path d="M27 28L41 19" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><circle cx="44" cy="16" r="3.4" fill="currentColor"/><circle cx="12" cy="44" r="1.6" fill="currentColor"/><circle cx="48" cy="40" r="1.6" fill="currentColor"/>',
    options: [
      { id: 'hill', label: '언덕', choices: [{ v: 'rand', label: '무작위' }, { v: 'N', label: '노멀힐 K90' }, { v: 'L', label: '라지힐 K120' }, { v: 'F', label: '플라잉힐 K185' }], def: 'rand' },
      { id: 'rounds', label: '라운드', choices: [{ v: 1, label: '1번씩' }, { v: 2, label: '2번씩' }, { v: 3, label: '3번씩' }], def: 2 },
      { id: 'wind', label: '바람 보정 점수', choices: [{ v: 'on', label: '켜기' }, { v: 'off', label: '끄기' }], def: 'on' },
    ],
    quick: [
      '목표: 멀리, 예쁘게 날아서 모든 점프 점수의 합계가 가장 높으면 우승해요.',
      '내 차례: 탭해서 출발 → 도약대 끝에서 탭 → 날면서 누르기/떼기로 자세 → 땅 직전에 「착지」.',
      '이기는 법: 자세 바늘을 초록 칸에 두고, 착지 버튼을 알맞게 눌러 텔레마크로 내려와요.',
    ],
    rules: [
      { h: '목표', p: [
        '한 사람씩 번갈아 뛰어요. 정한 라운드 수(1·2·3번씩)만큼 뛰고, 모든 점프 점수의 합계가 가장 높은 사람이 이겨요. 합계가 같으면 공동 우승.',
        '1라운드는 자리 순서대로, 2라운드부터는 합계가 낮은 사람부터 뛰어요(선두가 마지막).',
      ] },
      { h: '내 차례에 할 일', p: [
        '1) 출발: 화면을 탭하면 도약대를 내려가요. 속도는 저절로 붙어요.',
        '2) 도약: 도약대 끝(빨간 선)에 닿는 순간 탭! 아래 막대의 점이 빨간 선에 올 때예요. 빠르면 속도를 잃고, 늦으면 힘껏 차오르지 못해요. 끝을 0.25초 넘기면 도약을 놓쳐요.',
        '3) 비행: 화면을 누르고 있으면 몸이 앞으로 숙여지고, 떼면 뒤로 젖혀져요. 돌풍이 바늘을 흔들어요. 아래 「자세」 바늘을 초록 칸에 두면 가장 멀리 날아요.',
        '4) 착지: 땅에 닿기 직전(약 0.2~0.45초 전) 「착지」 버튼을 눌러요. 버튼이 초록으로 반짝이기 시작하면 땅이 가까워요. 너무 일찍 누르면 일찍 내려앉아 거리가 줄고 두 발 착지, 늦거나 안 누르면 넘어져요.',
      ] },
      { h: '조작 위치', p: [
        '가로 화면: 왼손 엄지는 왼쪽 아래 「누르기」 자리(화면 어디를 눌러도 같아요), 오른손 엄지는 오른쪽 아래 「착지」 버튼.',
        '세로 화면: 화면 아무 데나 누르기, 오른쪽 아래 「착지」 버튼.',
        '다른 사람의 점프는 다시보기로 보여 줘요. 탭하면 건너뛰어요.',
      ] },
      { h: '점수', p: [
        '점프 점수 = 거리 점수 + 자세 점수 + 바람 보정.',
        '거리 점수: K점(빨간 K 표시)에 착지하면 60점(플라잉힐은 120점). 1m 더 갈 때마다 +2.0점(노멀힐)·+1.8점(라지힐)·+1.2점(플라잉힐), 짧으면 그만큼 빼요. 거리는 0.5m 단위.',
        '자세 점수: 심판 5명이 20점 만점으로 매기고, 가장 높은 점수와 가장 낮은 점수를 빼고 3명을 더해요(최대 60점). 도약 타이밍, 비행 중 자세(바늘이 초록에 있었는지), 착지가 점수를 깎아요.',
        '착지: 텔레마크(가장 좋음) · 두 발 착지(−2) · 불안한 착지(−2.5) · 넘어짐(심판마다 −7). 넘어져도 거리는 그대로 인정돼요.',
        '바람 보정(켜면): 맞바람은 멀리 가기 쉬워서 점수를 빼고, 뒷바람은 더해 줘요. 1m/s마다 노멀 6.0 · 라지 8.0 · 플라잉 9.5점(뒷바람은 1.21배).',
        '예시(라지힐 K120): 125m 착지 → 거리 60 + 5×1.8 = 69점. 심판 18·18.5·18.5·19·17.5 → 가운데 셋 18+18.5+18.5 = 55점. 합계 124점(바람 보정 전).',
      ] },
      { h: '바람 · 선두 선', p: [
        '바람은 점프마다 바뀌고 왼쪽 위에 보여요. 맞바람(초록)은 더 멀리, 뒷바람(빨강)은 덜 날아요.',
        '초록 「선두」 선은 심판 점수 54점을 받는다고 할 때 1위가 되려면 넘어야 하는 거리예요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '가로 화면용 게임이에요. 폰을 돌릴 수 없으면 「세로로 그냥 하기」로 세로 화면에서도 할 수 있어요.',
        '차례대로 뛰는 게임이라 한 폰을 돌려 가며 여럿이 해도 되고, 온라인·LAN 방에서도 할 수 있어요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(도약 타이밍·자세 반응·착지 정확도가 달라요).',
      ] },
    ],
    init, actor, apply, ai, result, mount,
    aiDelayFor() { return 500; },
    _t: { ttg, HILLS, hill, hy, hs, xAtS, simulate, judge, newRun, step, distPts, windPts, ldClass, tkClass, qOf, LVJ, aiFly, validRec },
  });
})();
