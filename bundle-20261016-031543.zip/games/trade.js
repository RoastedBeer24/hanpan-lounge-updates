/* 우주 화물선 협상 (2판) — 2~5인 우주 무역. 행성 12곳 · 물품 14가지(5분류).
   차례마다 ① 행성으로 이동(이동비 = 거리 × 출발 행성 연료값, 엔진에 따라 한 번에 4·6·9칸)
   → ② 시장 사고팔기 · 계약 납품 · 배 업그레이드(조선소) · 다른 선장에게 거래 제안(약속은 지켜도 어겨도 됨) → ③ 턴 끝.
   시세는 사고팔수록 움직이고 라운드마다 제자리 쪽으로 돌아오며 조금씩 출렁인다. 라운드 시작 때 이벤트가 끼어든다.
   축제 행성은 라운드마다 "축제 물품"을 아주 비싸게 산다. N라운드 뒤 가장 부자(현금 + 화물 + 배 업그레이드 절반)가 승리.
   제안이 걸려 있으면 actor = [차례인 선장, 받는 선장] (배열 actor) — 받는 쪽은 남의 차례에도 바로 답한다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- goods ---------- */
  const CATS = [
    { n: '원자재', c: '#b4accb' }, { n: '식량', c: '#e6c46a' }, { n: '기술', c: '#8aa2ff' }, { n: '사치품', c: '#f07fb8' }, { n: '위험물', c: '#ff5a4f' },
  ];
  const GD = [
    { n: '얼음', b: 10, v: 0.03, k: 0, c: '#dff1ff' },
    { n: '광석', b: 16, v: 0.035, k: 0, c: '#b4accb' },
    { n: '가스', b: 22, v: 0.04, k: 0, c: '#9ee0d0' },
    { n: '곡물', b: 12, v: 0.03, k: 1, c: '#e6c46a' },
    { n: '과일', b: 20, v: 0.04, k: 1, c: '#ffa057' },
    { n: '향신료', b: 36, v: 0.05, k: 1, c: '#d0703a' },
    { n: '부품', b: 28, v: 0.045, k: 2, c: '#c58cf0' },
    { n: '칩', b: 48, v: 0.05, k: 2, c: '#6bdc6b' },
    { n: '로봇', b: 72, v: 0.055, k: 2, c: '#8aa2ff' },
    { n: '보석', b: 60, v: 0.055, k: 3, c: '#7ad7ff' },
    { n: '예술품', b: 88, v: 0.06, k: 3, c: '#f07fb8' },
    { n: '와인', b: 40, v: 0.05, k: 3, c: '#d24a66' },
    { n: '무기', b: 56, v: 0.06, k: 4, c: '#ff5a4f' },
    { n: '우라늄', b: 52, v: 0.06, k: 4, c: '#c6ff2e' },
  ];
  const NG = GD.length, CRI = NG; // trade vectors: NG goods + credits at index NG

  /* ---------- planets ---------- */
  const PL = [
    { n: '센트럴 허브', s: '허브', ty: 'hub', x: 0.40, y: 0.47, c: '#e3ae45', fu: 0.8, sp: 0.86, yard: 1,
      m: { 0: 1.05, 1: 1, 2: 1, 3: 1.05, 4: 1.05, 5: 1.1, 6: 1, 7: 1, 8: 1.05, 9: 1.05, 10: 1, 11: 1.1 },
      d: '모든 항로가 모이는 정거장. 위험물만 빼고 다 사고팔아요(값은 보통). 조선소가 있고, 경비대 덕에 해적이 못 와요.' },
    { n: '그린베일', s: '그린베일', ty: 'farm', x: 0.36, y: 0.06, c: '#7cc35a', fu: 1.2,
      m: { 3: 0.5, 4: 0.6, 0: 1.35, 6: 1.4, 8: 1.45, 7: 1.2, 11: 1.15 }, d: '농업 행성: 곡물·과일이 싸요. 부품·로봇을 비싸게 사요.' },
    { n: '프로스트', s: '프로스트', ty: 'ice', x: 0.07, y: 0.08, c: '#9fd8ff', fu: 1.1,
      m: { 0: 0.45, 2: 0.7, 3: 1.5, 4: 1.55, 11: 1.35, 5: 1.3, 6: 1.15 }, d: '얼음 위성: 얼음·가스가 싸요. 먹을거리를 비싸게 사요.' },
    { n: '아이언록', s: '아이언록', ty: 'mine', x: 0.66, y: 0.12, c: '#c9874a', fu: 1,
      m: { 1: 0.45, 13: 0.65, 3: 1.4, 4: 1.3, 8: 1.4, 6: 1.35, 12: 1.25, 0: 1.2 }, d: '광산 행성: 광석·우라늄이 싸요. 먹을거리와 기계를 비싸게 사요.' },
    { n: '템페스트', s: '템페스트', ty: 'gas', x: 0.94, y: 0.08, c: '#f0a24a', fu: 0.55,
      m: { 2: 0.45, 0: 1.5, 6: 1.4, 7: 1.3, 5: 1.35, 3: 1.25, 1: 1.2 }, d: '가스 거인 정거장: 가스가 싸고 연료값이 가장 싸요. 얼음·부품을 비싸게 사요.' },
    { n: '포지', s: '포지', ty: 'forge', x: 0.93, y: 0.45, c: '#ee6a55', fu: 1, yard: 2,
      m: { 6: 0.5, 8: 0.65, 1: 1.55, 2: 1.45, 7: 1.35, 0: 1.2, 3: 1.25, 13: 1.3 }, d: '공업 행성: 부품·로봇이 싸요. 광석·가스를 비싸게 사요. 조선소가 20% 싸요.' },
    { n: '아카데미아', s: '아카데미아', ty: 'lab', x: 0.92, y: 0.87, c: '#c58cf0', fu: 1.1,
      m: { 7: 0.5, 13: 1.65, 9: 1.35, 0: 1.3, 4: 1.3, 11: 1.2, 6: 1.25, 10: 1.2 }, d: '연구소: 칩이 싸요. 우라늄·보석을 비싸게 사요.' },
    { n: '루미에르', s: '루미에르', ty: 'resort', x: 0.62, y: 0.93, c: '#ffd27a', fu: 1.25,
      m: { 11: 0.5, 10: 0.7, 5: 1.5, 9: 1.5, 4: 1.4, 3: 1.2, 8: 1.25 }, d: '휴양 행성: 와인·예술품이 싸요. 향신료·보석을 비싸게 사요.' },
    { n: '크리스탈리아', s: '크리스탈', ty: 'crystal', x: 0.08, y: 0.5, c: '#6fd6f0', fu: 1.15,
      m: { 9: 0.5, 0: 0.8, 7: 1.4, 6: 1.3, 3: 1.35, 11: 1.3, 12: 1.2 }, d: '결정 성운: 보석이 싸요(얼음도 조금). 칩·곡물을 비싸게 사요.' },
    { n: '스컬 항구', s: '스컬항', ty: 'pirate', x: 0.07, y: 0.92, c: '#c46a7e', fu: 0.9,
      m: { 12: 0.5, 5: 0.65, 10: 1.45, 11: 1.5, 8: 1.3, 9: 1.25, 13: 1.2, 3: 1.3 }, d: '해적 소굴: 무기·향신료가 싸요. 예술품·와인을 비싸게 사요. 여기선 해적이 공격하지 않아요.' },
    { n: '그림자 시장', s: '그림자', ty: 'black', x: 0.33, y: 0.86, c: '#9a8cff', fu: 1.3, sp: 0.93, bf: 1.12,
      m: { 0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1.05, 6: 1, 7: 1.05, 8: 1.05, 9: 1.15, 10: 1.2, 11: 1.05, 12: 1.5, 13: 1.6 },
      d: '블랙마켓: 무엇이든 사고팔아요. 살 땐 비싸지만 팔 때 덜 깎이고, 무기·우라늄을 아주 비싸게 사요.' },
    { n: '카니발', s: '카니발', ty: 'fest', x: 0.67, y: 0.57, c: '#f07fb8', fu: 1.1,
      m: { 4: 1.35, 11: 1.35, 5: 1.3, 10: 1.3, 3: 1.2, 9: 1.2, 0: 1.15 }, d: '축제 행성: 라운드마다 바뀌는 "축제 물품"을 거의 두 배 값에 사요.' },
  ];
  const NP = PL.length, HUB = 0, FEST = 11, PIRATE = 9;
  const M = PL.map((P) => { const a = Array(NG).fill(0); for (const k in P.m) a[+k] = P.m[k]; return a; });
  const SP = PL.map((P) => P.sp || 0.84), BF = PL.map((P) => P.bf || 1);
  const FESTG = [3, 4, 5, 9, 10, 11], FESTM = 1.9;
  const EDGES = [[2, 1, 2], [2, 8, 2], [1, 0, 1], [1, 3, 2], [3, 4, 2], [3, 0, 2], [3, 11, 2], [4, 5, 2], [8, 0, 2], [8, 9, 2], [8, 10, 2],
    [0, 11, 1], [0, 10, 2], [11, 5, 2], [11, 7, 1], [11, 6, 2], [9, 10, 1], [10, 7, 2], [7, 6, 2], [5, 6, 2]];
  const DIST = [], NXT = [];
  (function () {
    for (let a = 0; a < NP; a++) { DIST.push(Array(NP).fill(99)); NXT.push(Array(NP).fill(-1)); DIST[a][a] = 0; NXT[a][a] = a; }
    for (const [a, b, c] of EDGES) { DIST[a][b] = DIST[b][a] = c; NXT[a][b] = b; NXT[b][a] = a; }
    for (let k = 0; k < NP; k++) for (let a = 0; a < NP; a++) for (let b = 0; b < NP; b++) {
      if (DIST[a][k] + DIST[k][b] < DIST[a][b]) { DIST[a][b] = DIST[a][k] + DIST[k][b]; NXT[a][b] = NXT[a][k]; }
    }
  })();
  function pathOf(a, b) { const p = [a]; let x = a; for (let g = 0; g < 20 && x !== b; g++) { x = NXT[x][b]; p.push(x); } return p; }

  const START_CR = 160, HOLD = [10, 15, 20], RANGE = [4, 6, 9], SHIELD = [0.5, 0.25, 0];
  const UPN = ['화물칸', '엔진', '방어막'], UPC = [[140, 300], [100, 220], [80, 180]];
  const PMIN = -12, PMAX = 14, FUELB = 6, MAXOF = 2, NCT = 4, NLOG = 10;
  const EVN = { P: '해적 출몰', S: '태양 폭풍', B: '가격 폭등', G: '대량 공급', F: '대축제', T: '기술 박람회', W: '전쟁 소문', H: '흉년', O: '연료 파동' };
  const EVW = [['P', 24], ['S', 10], ['B', 16], ['G', 14], ['F', 9], ['T', 8], ['W', 8], ['H', 6], ['O', 5]];
  const Z = () => Array(NG).fill(0);
  const Z1 = () => Array(NG + 1).fill(0);

  /* ---------- market math ---------- */
  const prOf = (s, p, g) => s.pr.charCodeAt(p * NG + g) - 75;
  function setPr(s, p, g, v) { const i = p * NG + g; v = U.clamp(Math.round(v), PMIN, PMAX); s.pr = s.pr.slice(0, i) + String.fromCharCode(75 + v) + s.pr.slice(i + 1); }
  const mulOf = (s, p, g) => (p === FEST && g === s.fg ? FESTM : M[p][g]);
  const trades = (s, p, g) => mulOf(s, p, g) > 0;
  const rawP = (g, m, o) => GD[g].b * m * (1 + GD[g].v * o);
  const buyAt = (s, p, g, o) => Math.max(1, Math.ceil(rawP(g, mulOf(s, p, g), o) * BF[p] - 0.2));
  const sellAt = (s, p, g, o) => Math.max(1, Math.floor(rawP(g, mulOf(s, p, g), o) * SP[p] + 0.2));
  const buyNow = (s, p, g) => buyAt(s, p, g, prOf(s, p, g));
  const sellNow = (s, p, g) => sellAt(s, p, g, prOf(s, p, g));
  /* n > 0: cost of buying n units; n < 0: revenue of selling −n units. Every unit moves the price one step. */
  function quote(s, p, g, n) {
    let o = prOf(s, p, g), v = 0;
    if (n > 0) for (let k = 0; k < n; k++) { v += buyAt(s, p, g, o); o = Math.min(PMAX, o + 1); }
    else for (let k = 0; k < -n; k++) { v += sellAt(s, p, g, o); o = Math.max(PMIN, o - 1); }
    return { v, o };
  }
  const hold = (s, i) => s.cg[i].reduce((a, b) => a + b, 0);
  const cap = (s, i) => HOLD[s.up[i][0]];
  const range = (s, i) => RANGE[s.up[i][1]];
  const fuelP = (s, p) => FUELB * PL[p].fu * (s.ev && s.ev.k === 'O' ? 1.5 : 1);
  /* credits to fly seat from where it is to p; null = out of engine range */
  function moveCost(s, i, p) {
    const from = s.loc[i];
    if (p === from) return 0;
    const d = DIST[from][p];
    if (d > range(s, i)) return null;
    return Math.ceil((d + (s.ev && s.ev.k === 'S' ? 1 : 0)) * fuelP(s, from) - 1e-9);
  }
  function upPrice(s, p, u, l) {
    if (!PL[p].yard || l > 1) return null;
    return Math.round(UPC[u][l] * (PL[p].yard === 2 ? 0.8 : 1) * (s.ev && s.ev.k === 'T' ? 0.7 : 1));
  }
  function upVal(s, i) { let v = 0; for (let u = 0; u < 3; u++) for (let l = 0; l < s.up[i][u]; l++) v += UPC[u][l] / 2; return v; }
  /* what the cargo fetches at the planet where the ship is (end of game) */
  function liqG(s, p, g, n) { return !n ? 0 : trades(s, p, g) ? quote(s, p, g, -n).v : Math.floor(n * GD[g].b * 0.5); }
  function liquid(s, i) { let v = 0; for (let g = 0; g < NG; g++) v += liqG(s, s.loc[i], g, s.cg[i][g]); return v; }
  const wealth = (s, i) => s.cr[i] + liquid(s, i) + upVal(s, i);
  function afterPirates(s, i, cg) {
    const fr = SHIELD[s.up[i][2]];
    let pg = -1;
    for (let g = 0; g < NG; g++) if (cg[g] && (pg < 0 || GD[g].b > GD[pg].b)) pg = g;
    const out = cg.slice();
    let pn = 0;
    if (pg >= 0 && fr > 0) { pn = Math.ceil(cg[pg] * fr); out[pg] -= pn; }
    return { cg: out, pg, pn };
  }
  const pirAt = (s, i, p) => p !== s.loc[i] && s.ev && s.ev.k === 'P' && s.ev.p === p;

  /* ---------- setup ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const s = {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), R: [10, 12, 15].includes(opts.turns) ? opts.turns : 12,
      rd: 1, st: 0, k: 0, t: 0, ph: 'm',
      cr: Array(n).fill(START_CR), cg: Array.from({ length: n }, Z), bs: Array.from({ length: n }, Z),
      loc: Array(n).fill(HUB), up: Array.from({ length: n }, () => [0, 0, 0]),
      pr: 'K'.repeat(NP * NG), fg: FESTG[U.rand(FESTG.length)], ev: null, ct: [],
      of: null, oc: 0, tk: 0, pm: [], rp: Array.from({ length: n }, () => [0, 0]), lg: [], ls: 0, last: null, seq: 0,
    };
    for (let p = 0; p < NP; p++) for (let g = 0; g < NG; g++) if (M[p][g]) setPr(s, p, g, U.rand(5) - 2);
    while (s.ct.length < NCT) s.ct.push(newContract(s));
    log(s, 'rd', 1);
    return s;
  }
  function log(s, ...a) { s.ls++; s.lg.push([s.ls, ...a]); if (s.lg.length > NLOG) s.lg.shift(); }
  /* contract = [good, count, planet, reward, last round, urgent] */
  function newContract(s) {
    for (let k = 0; k < 80; k++) {
      const g = U.rand(NG), p = U.rand(NP), m = M[p][g];
      if (m && m < 1.15) continue; // never where it is made or sold at a normal price
      if (s.ct.some((c) => c[0] === g && c[2] === p)) continue;
      const B = GD[g].b, n = U.clamp(Math.round(128 / B) + U.rand(3), 2, 8);
      const urgent = Math.random() < 0.2 ? 1 : 0;
      const b = Math.round((n * B * Math.max(m, 1.3) * 1.05 + 10) * (urgent ? 1.25 : 1));
      return [g, n, p, b, s.rd + (urgent ? 1 : 3 + U.rand(2)), urgent];
    }
    return [6, 4, 1, 180, s.rd + 3, 0];
  }
  function pickEvent(s) {
    const tot = EVW.reduce((a, x) => a + x[1], 0);
    let x = Math.random() * tot, k = 'P';
    for (const [kk, w] of EVW) { if ((x -= w) < 0) { k = kk; break; } }
    const ev = { k, p: -1, g: -1 };
    if (k === 'P') {
      const c = [];
      for (let p = 0; p < NP; p++) if (p !== HUB && p !== PIRATE) for (let w = DIST[PIRATE][p] <= 2 ? 3 : 1; w > 0; w--) c.push(p);
      ev.p = c[U.rand(c.length)];
    } else if (k === 'B' || k === 'G') {
      for (let q = 0; q < 30; q++) {
        const p = U.rand(NP), g = U.rand(NG), m = M[p][g];
        if (!m || (k === 'B' ? m < 0.95 : m > 1.25)) continue;
        ev.p = p; ev.g = g; break;
      }
      if (ev.p < 0) { ev.p = 1; ev.g = 3; }
      setPr(s, ev.p, ev.g, prOf(s, ev.p, ev.g) + (k === 'B' ? 8 : -8));
    } else if (k === 'F') {
      ev.p = FEST; ev.g = s.fg;
      for (const g of FESTG) setPr(s, FEST, g, prOf(s, FEST, g) + (g === s.fg ? 5 : 3));
    } else if (k === 'W') {
      ev.g = 12;
      for (let p = 0; p < NP; p++) if (M[p][12]) setPr(s, p, 12, prOf(s, p, 12) + 7);
    } else if (k === 'H') {
      for (let p = 0; p < NP; p++) for (const g of [3, 4, 5]) if (M[p][g]) setPr(s, p, g, prOf(s, p, g) + 5);
    }
    return ev;
  }
  function newRound(s) {
    for (let p = 0; p < NP; p++) for (let g = 0; g < NG; g++) {
      if (!M[p][g]) continue;
      let o = Math.trunc(prOf(s, p, g) * 0.6);
      if (Math.random() < 0.12 + GD[g].v * 2) o += (Math.random() < 0.5 ? -1 : 1) * (1 + U.rand(2)); // markets breathe a little
      setPr(s, p, g, o);
    }
    s.ct = s.ct.filter((c) => c[4] >= s.rd);
    while (s.ct.length < NCT) s.ct.push(newContract(s));
    { const o = FESTG.filter((g) => g !== s.fg); s.fg = o[U.rand(o.length)]; }
    s.ev = null;
    log(s, 'rd', s.rd);
    if (Math.random() < 0.7) { s.ev = pickEvent(s); log(s, 'ev', s.ev.k, s.ev.p, s.ev.g); }
    s.st = (s.rd - 1) % s.n; s.k = 0; s.t = s.st;
  }
  function endTurn(s) {
    if (s.of) { log(s, 'cx', s.of.f); s.of = null; }
    s.pm = s.pm.filter((pm) => {
      if (pm.f !== s.t || s.rd < pm.d) return true;
      const ok = pm.g >= pm.n;
      s.rp[pm.f][ok ? 0 : 1]++;
      log(s, ok ? 'pk' : 'pb', pm.f, pm.to, pm.r, pm.n);
      return false;
    });
    s.oc = 0; s.tk = 0; s.k++;
    if (s.k >= s.n) {
      s.rd++;
      if (s.rd > s.R) { s.ph = 'e'; s.rd = s.R; s.pm = []; s.of = null; log(s, 'end'); return; }
      newRound(s);
    } else s.t = (s.st + s.k) % s.n;
    s.ph = 'm';
  }

  /* ---------- rules ---------- */
  function actor(s) {
    if (s.ph === 'e') return null;
    const a = [s.t];
    if (s.of) { if (!a.includes(s.of.to)) a.push(s.of.to); if (!a.includes(s.of.f)) a.push(s.of.f); }
    return a.length === 1 ? a[0] : a;
  }
  const isInt = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  function vecN(v) {
    if (!Array.isArray(v) || v.length !== NG + 1) throw new Error('bad vector');
    return v.map((x) => { if (!isInt(x, 0, 9999)) throw new Error('bad amount'); return x; });
  }
  const has = (s, i, v) => v[CRI] <= s.cr[i] && s.cg[i].every((x, g) => v[g] <= x);
  const goods = (v) => { let n = 0; for (let g = 0; g < NG; g++) n += v[g]; return n; };
  /* goods change hands: the receiver takes over the giver's purchase price (basis) */
  function moveGoods(s, a, b, g, n) {
    if (!n) return;
    const hb = s.cg[b][g];
    s.bs[b][g] = Math.round((s.bs[b][g] * hb + (s.bs[a][g] || GD[g].b) * n) / (hb + n));
    s.cg[a][g] -= n; s.cg[b][g] += n;
    if (!s.cg[a][g]) s.bs[a][g] = 0;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object' || s.ph === 'e') throw new Error('bad action');
    if (!isInt(seat, 0, s.n - 1)) throw new Error('bad seat');
    const t = a.t;
    if (t === 're' || t === 'co') {
      const of = s.of;
      if (!of || of.to !== seat) throw new Error('no offer for you');
      if (t === 're') {
        if (a.ok) {
          const ok = has(s, of.f, of.g) && has(s, of.to, of.w) &&
            hold(s, of.f) - goods(of.g) + goods(of.w) <= cap(s, of.f) && hold(s, of.to) - goods(of.w) + goods(of.g) <= cap(s, of.to);
          if (!ok) { log(s, 'fl', of.f, of.to); s.of = null; return s; }
          for (let g = 0; g < NG; g++) { moveGoods(s, of.f, of.to, g, of.g[g]); moveGoods(s, of.to, of.f, g, of.w[g]); }
          s.cr[of.f] += of.w[CRI] - of.g[CRI]; s.cr[of.to] += of.g[CRI] - of.w[CRI];
          if (of.pm) s.pm.push({ f: of.f, to: of.to, r: of.pm[0], n: of.pm[1], d: s.rd + 1, g: 0, k: of.k });
          log(s, 'ok', of.f, of.to);
          s.last = { id: ++s.seq, k: 'tr', a: of.f, b: of.to, v: of.g.map((x, g) => x - of.w[g]) };
        } else log(s, 'no', of.f, of.to);
        s.of = null;
        return s;
      }
      if (of.c) throw new Error('cannot counter a counter');
      const g = vecN(a.g), w = vecN(a.w);
      if (!g.some((x) => x) && !w.some((x) => x)) throw new Error('empty');
      if (!has(s, seat, g)) throw new Error('you do not have that');
      s.of = { f: seat, to: of.f, g, w, pm: null, c: 1, k: ++s.seq };
      log(s, 'co', seat, of.f);
      return s;
    }
    if (t === 'cx') {
      if (!s.of || s.of.f !== seat) throw new Error('no offer');
      log(s, 'cx', seat); s.of = null;
      return s;
    }
    if (seat !== s.t) throw new Error('not your turn');
    const me = seat, here = s.loc[me];
    if (t === 'mv') {
      if (s.ph !== 'm' || !isInt(a.p, 0, NP - 1)) throw new Error('bad move');
      const cost = moveCost(s, me, a.p);
      if (cost == null) throw new Error('cannot go there'); // short of credits → the rest becomes debt (minus credits)
      const pir = pirAt(s, me, a.p);
      s.cr[me] -= cost; s.loc[me] = a.p; s.ph = 't';
      let pg = -1, pn = 0;
      if (pir) {
        const r = afterPirates(s, me, s.cg[me]);
        pg = r.pg; pn = r.pn; s.cg[me] = r.cg;
        if (pg >= 0 && !s.cg[me][pg]) s.bs[me][pg] = 0;
      }
      log(s, 'mv', me, here, a.p, cost);
      if (pir) log(s, 'pi', me, pg, pn);
      s.last = { id: ++s.seq, k: 'mv', s: me, path: pathOf(here, a.p), pg, pn, pi: pir ? 1 : 0 };
      return s;
    }
    if (s.ph !== 't') throw new Error('move first');
    if (t === 'mk') {
      const d = a.d;
      if (!Array.isArray(d) || d.length !== NG || !d.every((x) => isInt(x, -99, 99)) || d.every((x) => !x)) throw new Error('bad market');
      let net = 0, bu = 0, so = 0;
      for (let g = 0; g < NG; g++) if (d[g] < 0) {
        if (!trades(s, here, g)) throw new Error('not traded here');
        if (s.cg[me][g] < -d[g]) throw new Error('not enough cargo');
        const q = quote(s, here, g, d[g]); s.cr[me] += q.v; net += q.v; so -= d[g]; s.cg[me][g] += d[g]; setPr(s, here, g, q.o);
        if (!s.cg[me][g]) s.bs[me][g] = 0;
      }
      for (let g = 0; g < NG; g++) if (d[g] > 0) {
        if (!trades(s, here, g)) throw new Error('not traded here');
        const q = quote(s, here, g, d[g]);
        if (q.v > s.cr[me]) throw new Error('not enough credits');
        const h0 = s.cg[me][g];
        s.bs[me][g] = Math.round((s.bs[me][g] * h0 + q.v) / (h0 + d[g]));
        s.cr[me] -= q.v; net -= q.v; bu += d[g]; s.cg[me][g] += d[g]; setPr(s, here, g, q.o);
      }
      if (hold(s, me) > cap(s, me)) throw new Error('hold full');
      s.tk++;
      log(s, 'mk', me, bu, so, net);
      s.last = { id: ++s.seq, k: 'mk', s: me, net, d: d.slice() };
      return s;
    }
    if (t === 'ct') {
      const c = s.ct[a.i];
      if (!isInt(a.i, 0, s.ct.length - 1) || !c || here !== c[2] || s.cg[me][c[0]] < c[1] || c[4] < s.rd) throw new Error('cannot deliver');
      s.cg[me][c[0]] -= c[1]; s.cr[me] += c[3];
      if (!s.cg[me][c[0]]) s.bs[me][c[0]] = 0;
      log(s, 'ct', me, c[0], c[1], c[2], c[3]);
      s.ct[a.i] = newContract(s);
      s.last = { id: ++s.seq, k: 'ct', s: me, b: c[3] };
      return s;
    }
    if (t === 'up') {
      if (!isInt(a.u, 0, 2)) throw new Error('bad upgrade');
      const l = s.up[me][a.u], price = upPrice(s, here, a.u, l);
      if (price == null || price > s.cr[me]) throw new Error('cannot upgrade');
      s.cr[me] -= price; s.up[me][a.u]++;
      log(s, 'up', me, a.u, l + 1, price);
      s.last = { id: ++s.seq, k: 'up', s: me, u: a.u };
      return s;
    }
    if (t === 'gf') {
      if (!isInt(a.to, 0, s.n - 1) || a.to === me || !isInt(a.r, 0, CRI) || !isInt(a.n, 1, 9999)) throw new Error('bad gift');
      if (a.r === CRI) { if (s.cr[me] < a.n) throw new Error('no credits'); s.cr[me] -= a.n; s.cr[a.to] += a.n; }
      else {
        if (s.cg[me][a.r] < a.n || hold(s, a.to) + a.n > cap(s, a.to)) throw new Error('cannot gift');
        moveGoods(s, me, a.to, a.r, a.n);
      }
      const pm = s.pm.find((x) => x.f === me && x.to === a.to && x.r === a.r && x.g < x.n);
      if (pm) pm.g += a.n;
      log(s, 'gf', me, a.to, a.r, a.n);
      const v = Z1(); v[a.r] = a.n;
      s.last = { id: ++s.seq, k: 'tr', a: me, b: a.to, v };
      return s;
    }
    if (t === 'of') {
      if (s.of || s.oc >= MAXOF) throw new Error('no more offers');
      if (!isInt(a.to, 0, s.n - 1) || a.to === me) throw new Error('bad target');
      const g = vecN(a.g), w = vecN(a.w);
      if (!g.some((x) => x) && !w.some((x) => x)) throw new Error('empty');
      if (!has(s, me, g)) throw new Error('you do not have that');
      let pm = null;
      if (a.pm != null) { if (!Array.isArray(a.pm) || !isInt(a.pm[0], 0, CRI) || !isInt(a.pm[1], 1, 99)) throw new Error('bad promise'); pm = [a.pm[0], a.pm[1]]; }
      s.of = { f: me, to: a.to, g, w, pm, c: 0, k: ++s.seq };
      s.oc++;
      log(s, 'of', me, a.to);
      return s;
    }
    if (t === 'end') { endTurn(s); return s; }
    throw new Error('bad action');
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const w = Array.from({ length: s.n }, (_, i) => Math.round(wealth(s, i)));
    const best = Math.max(...w);
    const win = w.map((x, i) => (x === best ? i : -1)).filter((i) => i >= 0);
    const lines = w.map((x, i) => [x, i]).sort((a, b) => b[0] - a[0])
      .map(([x, i]) => (s.nm[i] || (i + 1) + '번') + ' · ' + x + ' (현금 ' + s.cr[i] + ' + 화물 ' + liquid(s, i) + (upVal(s, i) ? ' + 배 ' + upVal(s, i) : '') + ')' +
        (s.rp[i][1] ? ' · 약속 어김 ' + s.rp[i][1] : ''));
    return { winners: win, title: win.length === 1 ? (s.nm[win[0]] || '') + ' 선장 승리' : '공동 승리',
      text: lines.join('\n') + '\n시작 자금은 ' + START_CR + '. 남은 화물은 지금 있는 행성 시세로, 업그레이드는 정가의 절반으로 쳤어요.' };
  }

  /* ---------- AI ---------- */
  const lvF = (lv) => (lv === 3 ? 0.9 : 0.85);
  function othersHave(s, seat, g) { let o = 0; for (let i = 0; i < s.n; i++) if (i !== seat) o += s.cg[i][g]; return o; }
  /* what one unit of g should fetch at q on my next turn: prices drift back (×0.6) at the round change, the festival
     moves on, other captains carrying g will sell some of it too, and each unit I sell lowers the price (k sold before) */
  function projSell(s, seat, g, q, k, lv) {
    if (!M[q][g]) return 0;
    if (lv === 1) return sellAt(s, q, g, prOf(s, q, g) - k); // 쉬움: today's price, as if it stayed
    const off = U.clamp(Math.trunc(prOf(s, q, g) * 0.6) - Math.floor(othersHave(s, seat, g) / 3) - k, PMIN, PMAX);
    return Math.max(1, Math.floor(rawP(g, M[q][g], off) * SP[q] + 0.2));
  }
  function bestProjQ(s, seat, g, from, k, lv) {
    let v = 0, at = -1;
    const rng = range(s, seat), tight = s.rd >= s.R - 1;
    for (let q = 0; q < NP; q++) {
      if (q === from || !M[q][g]) continue;
      const d = DIST[from][q];
      if (lv >= 2 && tight && d > rng) continue; // must be able to get there before the end
      const x = projSell(s, seat, g, q, k, lv) - (lv >= 2 ? d * 1 : 0);
      if (x > v) { v = x; at = q; }
    }
    return [v, at];
  }
  const bestProj = (s, seat, g, from, k, lv) => bestProjQ(s, seat, g, from, k, lv)[0];
  /* contracts worth buying for at planet p right now (보통/어려움; 쉬움 uses it with a higher bar) */
  function ctDeals(s, seat, p, lv, cash, room) {
    const out = [];
    for (let i = 0; i < s.ct.length; i++) {
      const [g, n, q, b, dl] = s.ct[i], have = s.cg[seat][g], need = n - have;
      if (need <= 0 || need > room || !trades(s, p, g)) continue;
      const far = q === p ? 0 : DIST[p][q];
      if (far > range(s, seat) || dl < s.rd + (far ? 1 : 0) || (far && s.rd >= s.R)) continue;
      const cost = quote(s, p, g, need).v;
      if (cost > cash) continue;
      let rival = false;
      for (let o = 0; o < s.n; o++) if (o !== seat && s.cg[o][g] >= n && DIST[s.loc[o]][q] <= Math.max(1, Math.min(far, range(s, o)))) rival = true;
      const travel = far ? Math.ceil(far * fuelP(s, p)) : 0;
      const v = (b - cost - have * (trades(s, p, g) ? sellNow(s, p, g) : GD[g].b * 0.5) - travel) * (rival ? 0.35 : 1) * (far ? 0.85 : 1);
      if (v > (lv === 3 ? 10 : lv === 2 ? 14 : 24)) out.push({ i, g, need, cost, v, far, q });
    }
    return out.sort((a, b) => b.v - a.v);
  }
  /* worth of holding cargo cg — market value later, or the reward of a contract it completes */
  function posVal(s, seat, cg, lv) {
    const loc = s.loc[seat], last = s.rd >= s.R, f = lvF(lv);
    let v = 0;
    for (let g = 0; g < NG; g++) {
      const n = cg[g]; if (n <= 0) continue;
      const mk = last ? liqG(s, loc, g, 1) : Math.max(bestProj(s, seat, g, loc, n >> 1, lv) * f, trades(s, loc, g) ? sellNow(s, loc, g) : 0);
      let best = n * mk;
      for (const c of s.ct) {
        if (c[0] !== g || n < c[1]) continue;
        const far = c[2] === loc ? 0 : DIST[loc][c[2]];
        if (c[4] < s.rd + (far ? 1 : 0) || (far && last) || far > range(s, seat)) continue;
        best = Math.max(best, c[3] * (far ? f : 1) - far * 4 + (n - c[1]) * mk);
      }
      v += best;
    }
    return v;
  }
  /* what a deal is worth to `seat`: receive vector get, hand over vector give (NG+1 entries, last = credits) */
  function dealVal(s, seat, get, give, lv) {
    const cg = s.cg[seat], after = cg.map((x, g) => x + (get[g] || 0) - (give[g] || 0));
    return posVal(s, seat, after, lv) - posVal(s, seat, cg, lv) + (get[CRI] || 0) - (give[CRI] || 0);
  }
  const barOf = (lv, c) => (lv === 3 ? 3 + c * 0.05 : lv === 2 ? 4 + c * 0.07 : 0);
  /* greedy speculative buying at p: best margin first, unit by unit (prices move as we go) */
  function greedyBuy(s, seat, p, cash, room, lv, skip) {
    const o = Array.from({ length: NG }, (_, g) => prOf(s, p, g)), n = Z(), memo = {};
    let gain = 0;
    for (let k = 0; k < room; k++) {
      let best = -1, bx = 0, bm = 0;
      for (let g = 0; g < NG; g++) {
        if (!trades(s, p, g) || (skip && skip[g])) continue;
        const c = buyAt(s, p, g, o[g]);
        if (c > cash) continue;
        const key = g * 64 + s.cg[seat][g] + n[g];
        if (memo[key] == null) memo[key] = bestProj(s, seat, g, p, s.cg[seat][g] + n[g], lv);
        let m = memo[key] - c;
        if (lv === 1) m = memo[key] * (0.8 + Math.random() * 0.5) - c;
        const x = m - barOf(lv, c);
        if (x > bx) { bx = x; bm = m; best = g; }
      }
      if (best < 0) break;
      cash -= buyAt(s, p, best, o[best]); o[best] = Math.min(PMAX, o[best] + 1); n[best]++; gain += bm;
    }
    return { gain, n };
  }
  /* 어려움: play the turn out at every destination (move → contracts → market with the same planners) and
     compare what the ship is worth afterwards — cash + cargo at its projected value */
  function simValue(s, seat, p, deep) {
    let x = U.clone(s);
    try {
      x = apply(x, seat, { t: 'mv', p });
      for (let k = 0; k < 4; k++) {
        const i = x.ct.findIndex((c) => c[2] === p && x.cg[seat][c[0]] >= c[1] && c[4] >= x.rd);
        if (i < 0) break;
        x = apply(x, seat, { t: 'ct', i });
      }
      const sells = planSells(x, seat, 3);
      let cash = x.cr[seat], n = 0;
      for (let g = 0; g < NG; g++) if (sells[g]) { cash += quote(x, p, g, sells[g]).v; n -= sells[g]; }
      const buys = planBuys(x, seat, 3, cash, cap(x, seat) - hold(x, seat) + n, sells);
      const d = sells.map((v, g) => v + buys[g]);
      if (any(d)) x = apply(x, seat, { t: 'mk', d });
    } catch (e) { return -1e9; }
    const c = x.cr[seat];
    const v1 = c + (c < 0 ? c * 1.5 : 0) + posVal(x, seat, x.cg[seat], 3);
    if (!deep || x.rd >= x.R) return v1;
    // second turn: next round (prices drift back), same captain moves again
    x.rd++; x.ph = 'm'; x.t = seat; x.tk = 0; x.of = null; x.ev = null;
    for (let q = 0; q < NP; q++) for (let g = 0; g < NG; g++) if (M[q][g]) setPr(x, q, g, Math.trunc(prOf(x, q, g) * 0.6));
    let v2 = -1e9;
    for (let q = 0; q < NP; q++) if (moveCost(x, seat, q) != null) v2 = Math.max(v2, simValue(x, seat, q, false));
    return v1 * 0.5 + v2 * 0.5;
  }
  function planMove(s, seat, lv) {
    if (lv === 3) {
      let best = s.loc[seat], bv = -Infinity;
      for (let p = 0; p < NP; p++) { if (moveCost(s, seat, p) == null) continue; const v = simValue(s, seat, p, true); if (v > bv) { bv = v; best = p; } }
      return best;
    }
    const from = s.loc[seat], cg0 = s.cg[seat], cash = s.cr[seat], last = s.rd >= s.R, C = cap(s, seat);
    let best = from, bv = -Infinity;
    for (let p = 0; p < NP; p++) {
      const cost = moveCost(s, seat, p);
      if (cost == null) continue;
      const pir = pirAt(s, seat, p);
      const cg = pir && lv >= 2 ? afterPirates(s, seat, cg0).cg : cg0;
      let v = 0, cash2 = cash - cost, carry = 0;
      const unit = Z();
      for (let g = 0; g < NG; g++) {
        const n = cg[g]; if (!n) continue;
        const tr = trades(s, p, g), sale = tr ? quote(s, p, g, -n).v : 0;
        if (last) { const x = liqG(s, p, g, n); v += x; unit[g] = x / n; continue; }
        if (lv >= 2) {
          const keepV = n * bestProj(s, seat, g, p, n >> 1, lv) * lvF(lv);
          if (keepV > sale) { v += keepV; unit[g] = keepV / n; carry += n; continue; }
        } else if (!tr) { v += n * GD[g].b * 0.8; unit[g] = GD[g].b * 0.8; carry += n; continue; }
        v += sale; unit[g] = sale / n; cash2 += sale;
      }
      for (const c of s.ct) if (c[2] === p && cg[c[0]] >= c[1] && c[4] >= s.rd) v += c[3] - c[1] * unit[c[0]];
      if (!last) {
        const resv = lv === 1 ? 8 : Math.ceil(4 * fuelP(s, p));
        const dl = ctDeals(s, seat, p, lv, cash2 - resv, C - carry);
        if (dl.length) v += dl[0].v * (lv === 3 ? 0.8 : lv === 2 ? 0.7 : 0.4);
        v += greedyBuy(s, seat, p, cash2 - resv, C - carry, lv).gain * (lv === 3 ? 0.75 : lv === 2 ? 0.6 : 0.5);
      }
      v -= cost + Math.max(0, cost - Math.max(0, cash)) * (lv === 1 ? 0 : 1.5); // going into debt hurts (can't buy)
      if (pir) {
        if (lv === 1) { const r = afterPirates(s, seat, cg0); v -= r.pn * (r.pg >= 0 ? GD[r.pg].b : 0) * 0.2; }
        else if (cg !== cg0) v -= 8;
      }
      if (lv === 1) v = v * (0.6 + Math.random() * 0.8) + Math.random() * 12;
      else if (lv === 2) v *= 0.92 + Math.random() * 0.16;
      if (v > bv) { bv = v; best = p; }
    }
    return best;
  }
  /* sell orders for this turn (negative entries) */
  function planSells(s, seat, lv) {
    const p = s.loc[seat], cg = s.cg[seat], last = s.rd >= s.R, d = Z(), keep = Z();
    if (!last) for (const c of s.ct) {
      const [g, n, q, b, dl] = c;
      if (q === p || dl <= s.rd || DIST[p][q] > range(s, seat)) continue;
      if (lv === 1 ? cg[g] >= Math.ceil(n / 2) : cg[g] >= n && (!trades(s, p, g) || b > quote(s, p, g, -n).v * 1.1)) keep[g] = Math.max(keep[g], n);
    }
    if (lv >= 2 && !last) for (const x of ctDeals(s, seat, p, lv, s.cr[seat] + liquid(s, seat), cap(s, seat))) keep[x.g] = Math.max(keep[x.g], cg[x.g]);
    for (let g = 0; g < NG; g++) {
      const extra = cg[g] - keep[g];
      if (extra <= 0 || !trades(s, p, g)) continue;
      if (last) { d[g] = -extra; continue; }
      const here = sellNow(s, p, g), there = bestProj(s, seat, g, p, 0, lv) - (lv >= 2 ? 2 : 0);
      const thr = lv === 1 ? 0.7 + Math.random() * 0.3 : lv === 2 ? 0.85 : 0.9;
      if (here >= there * thr || (lv >= 2 && s.rd >= s.R - 1 && here >= there * 0.75)) d[g] = -extra;
    }
    return d;
  }
  /* buy orders (positive entries) with cash/room available after the sells */
  function planBuys(s, seat, lv, cash, room, sold) {
    const d = Z();
    if (s.rd >= s.R) return d;
    const p = s.loc[seat];
    const resv = lv === 1 ? 8 : Math.ceil(4 * fuelP(s, p)) + (lv === 3 ? 4 : 8);
    let money = cash - resv;
    if (money <= 0 || room <= 0) return d;
    if (lv >= 2 || Math.random() < 0.5) for (const x of ctDeals(s, seat, p, lv, money, room)) {
      if (d[x.g] || (sold && sold[x.g])) continue;
      const c = quote(s, p, x.g, x.need).v;
      if (c > money || x.need > room) continue;
      // buy from the planet's prices as they are after the earlier contract buys (rare: two contracts on one good)
      d[x.g] += x.need; money -= c; room -= x.need;
    }
    // speculative buys (the contract buys above already moved nothing in state; greedy starts from current prices,
    // so skip goods we already buy for contracts to keep the plan honest)
    const skip = Z(); for (let g = 0; g < NG; g++) skip[g] = d[g] || (sold && sold[g]) ? 1 : 0;
    const gb = greedyBuy(s, seat, p, money, room, lv, skip);
    for (let g = 0; g < NG; g++) d[g] += gb.n[g];
    return d;
  }
  /* ship upgrades: worth it while enough rounds remain to earn the price back */
  function wantUp(s, seat, lv, cash) {
    const p = s.loc[seat];
    if (!PL[p].yard) return -1;
    const left = s.R - s.rd;
    for (let u = 0; u < 3; u++) {
      const l = s.up[seat][u], price = upPrice(s, p, u, l);
      if (price == null || price > cash) continue;
      if (lv === 1) { if (Math.random() < 0.25 && cash >= price + 20) return u; continue; }
      if (u === 0) { if (left >= (lv === 3 ? 4 : 5) + l && cash >= price + (lv === 3 ? 100 : 160) + l * (lv === 3 ? 160 : 280)) return u; }
      else if (u === 1) { if (lv === 3 && left >= 5 && s.up[seat][0] >= 1 && cash >= price + 280 + l * 240) return u; }
      else if (lv === 3 && left >= 4 && s.up[seat][0] >= 1 && cash >= price + 440 + l * 400) return u;
    }
    return -1;
  }
  function rnd(seed) { const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); }
  function keepsPromise(s, seat, lv, pm) {
    const x = rnd(pm.k * 7 + seat * 13);
    if (lv === 1) return x < 0.5;
    if (lv === 3) return x < (s.rd >= s.R - 1 ? 0.25 : 0.7);
    return x < 0.92;
  }
  function planOffer(s, seat, lv) {
    if (s.oc >= 1 || s.rd >= s.R || s.of) return null;
    if (Math.random() > (lv === 1 ? 0.3 : lv === 3 ? 0.55 : 0.4)) return null;
    const me = s.loc[seat], cands = [], room = cap(s, seat) - hold(s, seat);
    if (lv >= 2) { // buy exactly what completes a contract, paying a bit over what the seller thinks it is worth
      for (const c of s.ct) {
        const [g, n, q, , dl] = c, need = n - s.cg[seat][g], far = q === me ? 0 : DIST[me][q];
        if (need <= 0 || dl < s.rd + 1 || far > range(s, seat) || need > room) continue;
        const get = Z1(); get[g] = need;
        const mine = dealVal(s, seat, get, Z1(), lv);
        for (let o = 0; o < s.n; o++) {
          if (o === seat || s.cg[o][g] < need) continue;
          const theirs = -dealVal(s, o, Z1(), get, 2);
          const price = Math.max(1, Math.ceil(theirs * (lv === 3 ? 1 : 1.04)) + (lv === 3 ? 6 : 4));
          const gain = mine - price;
          if (gain > (lv === 3 ? 6 : 4) && price <= s.cr[seat]) cands.push({ o, g, n: need, price, gain });
        }
      }
    } else for (let o = 0; o < s.n; o++) {
      if (o === seat) continue;
      for (let g = 0; g < NG; g++) {
        if (!s.cg[o][g]) continue;
        let unit = trades(s, me, g) ? sellNow(s, me, g) * 0.95 : GD[g].b * 0.6, lim = 4;
        for (const c of s.ct) if (c[0] === g && c[4] > s.rd && DIST[me][c[2]] <= 2) { const need = c[1] - s.cg[seat][g]; if (need > 0 && need <= s.cg[o][g]) { unit = Math.max(unit, c[3] / c[1]); lim = need; } }
        const n = Math.min(s.cg[o][g], lim, room);
        if (n <= 0) continue;
        const theirs = GD[g].b * (0.9 + Math.random() * 0.5);
        const price = Math.ceil(n * theirs * 1.04) + 4;
        const gain = n * unit - price;
        if (gain > 4 && price <= s.cr[seat]) cands.push({ o, g, n, price, gain });
      }
    }
    if (!cands.length) return null;
    cands.sort((a, b) => b.gain - a.gain);
    const c = cands[lv === 1 ? U.rand(cands.length) : 0];
    const give = Z1(), want = Z1();
    give[CRI] = c.price; want[c.g] = c.n;
    let pm = null;
    // sweeten with a promise instead of part of the payment (may or may not be kept…)
    if (lv !== 2 && Math.random() < 0.45 && c.price >= 16) { const cut = Math.min(c.price - 4, 16); give[CRI] -= cut; pm = [CRI, cut + 4]; }
    return { t: 'of', to: c.o, g: give, w: want, pm };
  }
  function respond(s, seat, lv) {
    const of = s.of;
    if (!has(s, seat, of.w) || hold(s, seat) - goods(of.w) + goods(of.g) > cap(s, seat)) return { t: 're', ok: false };
    let ev;
    if (lv === 1) { ev = 0; for (let g = 0; g < NG; g++) ev += (of.g[g] - of.w[g]) * GD[g].b; ev += of.g[CRI] - of.w[CRI]; }
    else ev = dealVal(s, seat, of.g, of.w, lv);
    if (of.pm) {
      const rp = s.rp[of.f], trust = (rp[0] + 1) / (rp[0] + rp[1] + 2);
      const pv = of.pm[0] === CRI ? 1 : GD[of.pm[0]].b * 0.8;
      ev += of.pm[1] * pv * trust * (lv === 1 ? 1.2 : lv === 2 ? 0.8 : 0.6);
    }
    if (of.c) return { t: 're', ok: lv === 1 ? ev > -8 + Math.random() * 12 : ev >= (lv === 3 ? 2 : -2) };
    let thr = lv === 1 ? -6 + (Math.random() * 2 - 1) * 12 : lv === 2 ? 2 : 6;
    if (lv === 3) { // do not feed the leader
      const wl = Array.from({ length: s.n }, (_, i) => wealth(s, i));
      if (wl[of.f] >= Math.max(...wl) && of.f !== seat) thr += 8;
    }
    if (ev >= thr) return { t: 're', ok: true };
    if (lv >= 2 && ev > -80 && Math.random() < (lv === 3 ? 0.7 : 0.5)) {
      const extra = Math.ceil(thr - ev + 4 + U.rand(6));
      const g = of.w.slice(), w = of.g.slice();
      w[CRI] += extra;
      if (s.cr[of.f] >= w[CRI] && has(s, seat, g)) return { t: 'co', g, w };
    }
    return { t: 're', ok: false };
  }
  function legal(s, seat, a) { try { apply(U.clone(s), seat, a); return true; } catch (e) { return false; } }
  function ai(s, seat, lv) {
    const a = aiRaw(s, seat, lv || 2);
    if (!a || legal(s, seat, a)) return a;
    if (a.t === 'mv') return { t: 'mv', p: s.loc[seat] };
    if (a.t === 'co') return { t: 're', ok: false };
    if (seat === s.t && s.ph === 't') return { t: 'end' };
    return null;
  }
  const any = (d) => d.some((x) => x);
  function aiRaw(s, seat, lv) {
    if (s.ph === 'e') return null;
    if (s.of && s.of.to === seat) return respond(s, seat, lv);
    if (s.of && s.of.f === seat) return { t: 'cx' }; // waited long enough
    if (seat !== s.t) return null;
    if (s.ph === 'm') return { t: 'mv', p: planMove(s, seat, lv) };
    const here = s.loc[seat];
    // 1) promises due
    for (const pm of s.pm) {
      if (pm.f !== seat || pm.g >= pm.n || s.rd < pm.d || !keepsPromise(s, seat, lv, pm)) continue;
      const left = pm.n - pm.g;
      const can = pm.r === CRI ? Math.min(left, s.cr[seat]) : Math.min(left, s.cg[seat][pm.r], cap(s, pm.to) - hold(s, pm.to));
      if (can > 0) return { t: 'gf', to: pm.to, r: pm.r, n: can };
    }
    // 2) deliver contracts here
    for (let i = 0; i < s.ct.length; i++) { const c = s.ct[i]; if (c[2] === here && s.cg[seat][c[0]] >= c[1] && c[4] >= s.rd) return { t: 'ct', i }; }
    // 3) market (sell → maybe upgrade → buy); at most 3 market actions a turn
    if (s.tk < 3) {
      const sells = planSells(s, seat, lv);
      if (any(sells)) {
        let cash = s.cr[seat], n = 0;
        for (let g = 0; g < NG; g++) if (sells[g]) { cash += quote(s, here, g, sells[g]).v; n -= sells[g]; }
        if (wantUp(s, seat, lv, cash) >= 0) return { t: 'mk', d: sells };
        const buys = planBuys(s, seat, lv, cash, cap(s, seat) - hold(s, seat) + n, sells);
        return { t: 'mk', d: sells.map((x, g) => x + buys[g]) };
      }
      const u = wantUp(s, seat, lv, s.cr[seat]);
      if (u >= 0) return { t: 'up', u };
      const buys = planBuys(s, seat, lv, s.cr[seat], cap(s, seat) - hold(s, seat), null);
      if (any(buys)) return { t: 'mk', d: buys };
    }
    // 4) maybe a deal with another captain
    const of = planOffer(s, seat, lv);
    if (of) return of;
    return { t: 'end' };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'e') return -1;
    if (s.of && s.of.to === seat) return 1100 + U.rand(700);
    if (s.of && s.of.f === seat) return 25000; // waiting for an answer; give up after a while
    if (seat !== s.t) return -1;
    return (s.ph === 'm' ? 600 : 420) + (lv === 1 ? 220 : lv === 3 ? -100 : 0);
  }

  /* ---------- planner for people (pure; the view shows it) ---------- */
  function basis(s, i, g) { return s.bs[i][g] || GD[g].b; }
  /* what going to p is likely worth for seat me: sell cargo, deliver contracts, buy something good there */
  function routeInfo(s, me, p) {
    const from = s.loc[me], cost = moveCost(s, me, p);
    const o = { p, cost, est: -1e9, rev: 0, prof: 0, sellN: 0, sellG: [], ctB: 0, ctN: 0, buy: null, lost: 0, pir: false, ok: false };
    if (cost == null) return o;
    o.ok = true; o.debt = Math.max(0, cost - Math.max(0, s.cr[me]));
    const last = s.rd >= s.R;
    let cg = s.cg[me];
    if (pirAt(s, me, p)) { o.pir = true; const r = afterPirates(s, me, cg); cg = r.cg; if (r.pn) o.lost = r.pn * basis(s, me, r.pg); }
    let room = cap(s, me) - cg.reduce((a, b) => a + b, 0);
    const used = Z();
    for (const c of s.ct) if (c[2] === p && c[4] >= s.rd && cg[c[0]] - used[c[0]] >= c[1]) { used[c[0]] += c[1]; o.ctB += c[3]; o.ctN++; o.prof += c[3] - c[1] * basis(s, me, c[0]); room += c[1]; }
    for (let g = 0; g < NG; g++) {
      const n = cg[g] - used[g]; if (n <= 0 || !trades(s, p, g)) continue;
      const there = bestProj(s, me, g, p, 0, 3);
      if (!last && sellNow(s, p, g) < there * 0.9) continue;
      const q = quote(s, p, g, -n).v;
      o.rev += q; o.prof += q - n * basis(s, me, g); o.sellN += n; o.sellG.push(g); room += n;
    }
    if (!last) {
      let cash = s.cr[me] - cost + o.rev + o.ctB - Math.ceil(3 * fuelP(s, p));
      let best = null;
      for (let g = 0; g < NG; g++) {
        if (!trades(s, p, g)) continue;
        const [v, q] = bestProjQ(s, me, g, p, 0, 3);
        let k = 0, tot = 0, off = prOf(s, p, g), c = cash;
        while (k < room) { const b = buyAt(s, p, g, off), m = v - k - b; if (b > c || m < 3) break; c -= b; tot += m; k++; off = Math.min(PMAX, off + 1); }
        if (k && (!best || tot > best.tot)) best = { g, k, q, tot: Math.round(tot), m: Math.round(tot / k) };
      }
      o.buy = best;
    }
    // ranking = the 어려움 planner (two turns ahead); shown as the change in what the ship is worth
    const c0 = s.cr[me];
    o.est = Math.round(simValue(s, me, p, true) - (c0 + (c0 < 0 ? c0 * 1.5 : 0) + posVal(s, me, s.cg[me], 3)));
    return o;
  }
  /* the strong planner's market plan for a person (sell + buy draft) */
  function planDraft(s, me) {
    const sells = planSells(s, me, 3), here = s.loc[me];
    let cash = s.cr[me], n = 0;
    for (let g = 0; g < NG; g++) if (sells[g]) { cash += quote(s, here, g, sells[g]).v; n -= sells[g]; }
    const buys = planBuys(s, me, 3, cash, cap(s, me) - hold(s, me) + n, sells);
    return sells.map((x, g) => x + buys[g]);
  }

  /* ---------- small text helpers (pure) ---------- */
  /* Korean particle: jo('광석','이','가') → '광석이' */
  function jo(w, a, b) { const c = w.charCodeAt(w.length - 1) - 0xac00; return w + (c >= 0 && c < 11172 && c % 28 ? a : b); }
  const sgn = (v) => (v > 0 ? '+' : v < 0 ? '−' : '±') + Math.abs(Math.round(v));

  /* ---------- icons: 16×16 paths shared by DOM (svg) and canvas (Path2D) ---------- */
  const f2 = (v) => +v.toFixed(2);
  function E(cx, cy, rx, ry, deg) {
    const a = deg * Math.PI / 180, dx = Math.cos(a) * rx, dy = Math.sin(a) * rx;
    const p1 = f2(cx + dx) + ' ' + f2(cy + dy), p2 = f2(cx - dx) + ' ' + f2(cy - dy);
    return 'M' + p1 + 'A' + rx + ' ' + ry + ' ' + deg + ' 1 0 ' + p2 + 'A' + rx + ' ' + ry + ' ' + deg + ' 1 0 ' + p1 + 'Z';
  }
  const CI = (cx, cy, r) => E(cx, cy, r, r, 0);
  const poly = (pts) => 'M' + pts.map((p) => f2(p[0]) + ' ' + f2(p[1])).join('L') + 'Z';
  const rect = (x, y, w, hh) => 'M' + x + ' ' + y + 'h' + w + 'v' + hh + 'h' + (-w) + 'Z';
  function starP(cx, cy, n, r1, r2, rot) { const p = []; for (let k = 0; k < n * 2; k++) { const a = rot + k * Math.PI / n, r = k % 2 ? r2 : r1; p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } return poly(p); }
  const hex = (r) => poly(Array.from({ length: 6 }, (_, k) => [8 + Math.cos(-Math.PI / 2 + k * Math.PI / 3) * r, 8 + Math.sin(-Math.PI / 2 + k * Math.PI / 3) * r]));
  const GEAR = (() => {
    let d = '';
    for (let k = 0; k < 32; k++) { const a = ((k + 0.5) / 32) * Math.PI * 2, r = (k >> 1) % 2 ? 5.2 : 7.4; d += (k ? 'L' : 'M') + f2(8 + Math.cos(a) * r) + ' ' + f2(8 + Math.sin(a) * r); }
    return d + 'Z' + CI(8, 8, 2.4);
  })();
  const CHIP = (() => { let d = rect(4, 4, 8, 8) + CI(6.2, 6.2, 0.9); for (const i of [4.8, 7.4, 10]) d += rect(i, 1.6, 1.2, 2.4) + rect(i, 12, 1.2, 2.4) + rect(1.6, i, 2.4, 1.2) + rect(12, i, 2.4, 1.2); return d; })();
  const TREF = (() => {
    const P = (r, a) => f2(8 + Math.cos(a) * r) + ' ' + f2(8 + Math.sin(a) * r);
    let d = CI(8, 8, 1.5);
    for (const c of [90, 210, 330]) {
      const a1 = (c - 30) * Math.PI / 180, a2 = (c + 30) * Math.PI / 180;
      d += 'M' + P(2.6, a1) + 'L' + P(7.3, a1) + 'A7.3 7.3 0 0 1 ' + P(7.3, a2) + 'L' + P(2.6, a2) + 'A2.6 2.6 0 0 0 ' + P(2.6, a1) + 'Z';
    }
    return d;
  })();
  const WHEAT = rect(7.4, 6.5, 1.2, 9) + E(8, 2.8, 1.1, 2.1, 0) +
    [5.2, 8.2, 11.2].map((y) => E(5.9, y, 2.1, 1.05, 35) + E(10.1, y, 2.1, 1.05, -35)).join('');
  const ICONS = [
    [hex(7.3) + hex(4.7) + hex(2.2), 1], // 얼음
    ['M4.6 2.4L11.2 1.8L14.6 6.8L12.9 12.9L5.8 14.4L1.4 9.4ZM5.2 4.2L4.2 8.6L7.4 7.2Z', 1], // 광석
    [CI(5.8, 10, 4.4) + CI(11.6, 4.6, 3) + CI(12.6, 11.8, 2.1), 1], // 가스
    [WHEAT, 0], // 곡물
    ['M8 4.6C5.5 3 1.6 4 1.8 8.6C2 12.6 5 15.4 8 14.2C11 15.4 14 12.6 14.2 8.6C14.4 4 10.5 3 8 4.6ZM8.3 4C8.3 2.1 9.7 .9 11.9 .8C11.7 2.8 10.3 3.9 8.3 4Z', 0], // 과일
    [starP(8, 8, 8, 7.4, 3.3, -Math.PI / 2) + CI(8, 8, 1.4), 1], // 향신료
    [GEAR, 1], // 부품
    [CHIP, 1], // 칩
    [rect(3, 5.2, 10, 8.6) + CI(6, 8.8, 1.3) + CI(10, 8.8, 1.3) + rect(6, 11.4, 4, 0.9) + rect(7.4, 2.6, 1.2, 2.6) + CI(8, 1.5, 1.05) + rect(1.4, 7.4, 1.6, 3.4) + rect(13, 7.4, 1.6, 3.4), 1], // 로봇
    ['M8 1.2L14 6.2L8 14.8L2 6.2ZM8 3.4L4.6 6.2L8 6.2Z', 1], // 보석
    ['M6 1.5h4v1.6c0 1 3.6 2.4 3.6 6.4c0 3.5-2 5.4-3 6h-5.2c-1-.6-3-2.5-3-6c0-4 3.6-5.4 3.6-6.4ZM4.3 8.2h7.4v1.5h-7.4Z', 1], // 예술품
    ['M7 1h2v3.6c0 .8 2.6 1.6 2.6 4.4v5.6c0 .6-.4 1-1 1h-5.2c-.6 0-1-.4-1-1v-5.6c0-2.8 2.6-3.6 2.6-4.4ZM6 9.2h4v3h-4Z', 1], // 와인
    ['M8 .8c2 1.8 3 4.4 3 7.2v4h-6v-4c0-2.8 1-5.4 3-7.2ZM5 8.6L2.4 11.6v2.8L5 12.8ZM11 8.6L13.6 11.6v2.8L11 12.8ZM6.6 12.6h2.8L8 15.4Z' + CI(8, 6, 1.2), 1], // 무기
    [TREF, 1], // 우라늄
    ['M14.6 8A6.6 6.6 0 1 1 1.4 8A6.6 6.6 0 1 1 14.6 8ZM12.5 8A4.5 4.5 0 1 0 3.5 8A4.5 4.5 0 1 0 12.5 8ZM10.4 8A2.4 2.4 0 1 1 5.6 8A2.4 2.4 0 1 1 10.4 8Z', 1], // 크레딧
    ['M8 1.2C8 1.2 2.8 7.3 2.8 10.4A5.2 5.2 0 0 0 13.2 10.4C13.2 7.3 8 1.2 8 1.2Z', 0], // 연료
    ['M8 1.3L14.4 4.6V11.4L8 14.7L1.6 11.4V4.6ZM8 3.1L4 5.1L8 7.1L12 5.1Z', 1], // 화물칸
    ['M5 1.5h6v5.2L9.4 8.8H6.6L5 6.7ZM6.4 10h3.2L8 15.2Z', 0], // 엔진
    ['M8 1L14 3.4V8c0 3.6-2.6 6-6 7c-3.4-1-6-3.4-6-7V3.4ZM8 3.2L3.9 4.9V8c0 2.5 1.7 4.3 4.1 5.1Z', 1], // 방어막
  ];
  const IC_CR = 14, IC_UP = [16, 17, 18];
  const GC = GD.map((x) => x.c).concat('#e3ae45', '#f08a3c', '#d9b98a', '#ff9d5c', '#7ad7ff');
  function ico(i, sz) {
    const el = document.createElement('span');
    el.className = 'tr-ic';
    el.innerHTML = '<svg viewBox="0 0 16 16" width="' + sz + '" height="' + sz + '" aria-hidden="true"><path fill="' + GC[i] + '"' + (ICONS[i][1] ? ' fill-rule="evenodd"' : '') + ' d="' + ICONS[i][0] + '"/></svg>';
    return el;
  }

  /* ---------- view ---------- */
  const CSS = `
.tr{position:absolute;inset:0;display:flex;flex-direction:column;background:#0c0a14;overflow:hidden;word-break:keep-all}
.tr-ic{display:inline-flex;flex:none;line-height:0}
.tr-top{display:grid;gap:5px;padding:5px 8px 4px;flex:none;position:relative;z-index:2;background:#0c0a14}
.tr-p{appearance:none;font:inherit;color:var(--ink);text-align:left;border:1px solid var(--line);background:rgba(34,28,46,.92);border-radius:12px;padding:4px 6px 6px;min-height:46px;display:flex;flex-direction:column;min-width:0;cursor:pointer;position:relative;overflow:hidden;transition:opacity .2s}
.tr-p .r1{display:flex;align-items:center;gap:4px;font-size:11.5px;font-weight:700;min-width:0}
.tr-p .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1 1 auto;min-width:0}
.tr-p .r2{display:flex;align-items:center;justify-content:space-between;gap:3px;font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;min-width:0}
.tr-p .cr{font-family:var(--f-mono);font-weight:600;font-size:15px;color:var(--brass)}
.tr-p .lc{overflow:hidden;text-overflow:ellipsis;min-width:0}
.tr-p .hb{position:absolute;left:0;bottom:0;height:3px;border-radius:0 2px 2px 0;opacity:.8}
.tr-p .cw{flex:none;color:var(--brass);font-size:10px;line-height:1}
.tr-p .rp{font-size:10px;flex:none;color:#ff9d8a}
.tr-map{position:relative;flex:1 1 auto;min-height:150px}
.tr-map canvas{position:absolute;inset:0}
.tr-bar{position:absolute;left:8px;right:8px;top:6px;display:flex;gap:6px;align-items:center;pointer-events:none}
.tr-bar>*{pointer-events:auto}
.tr-pill{font-size:11.5px;font-weight:700;background:rgba(18,14,24,.85);border:1px solid var(--line);border-radius:999px;padding:5px 10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;color:var(--ink)}
.tr-pill.ev{color:#ffd27a;border-color:rgba(227,174,69,.5);flex:0 1 auto;cursor:pointer;font:inherit;font-size:11.5px;font-weight:700;min-height:30px}
.tr-bar .sp{flex:1 1 0}
.tr-bar .btn{min-height:44px;padding:3px 10px;font-size:12.5px;flex:none;background:rgba(46,38,64,.92)}
.tr-pan{flex:none;background:var(--surface);border-top:1px solid var(--line);padding:7px 10px 10px;display:flex;flex-direction:column;gap:6px;max-height:calc(100% - 215px);overflow-y:auto;position:relative;z-index:2;box-shadow:0 -10px 24px rgba(0,0,0,.35)}
.tr.mv .tr-pan{max-height:52%}
.tr-pan>*{flex-shrink:0}
.tr-hint{display:flex;align-items:center;gap:7px;font-size:12.5px;font-weight:700;min-height:24px;line-height:1.3}
.tr-hint .ph{flex:none;font-size:11px;font-weight:800;border-radius:999px;padding:3px 8px;background:var(--brass);color:var(--brass-ink);white-space:nowrap}
.tr-hint .ph.w{background:var(--surface-2);color:var(--muted)}
.tr-hint .tx{flex:1 1 auto;min-width:0}
.tr-hint .sub{flex:none;font-family:var(--f-mono);font-size:13px;color:var(--brass);white-space:nowrap;display:flex;align-items:center;gap:3px}
.tr-hint .btn{flex:none;min-height:44px;padding:4px 12px;font-size:13px}
.tr-guide{background:linear-gradient(135deg,rgba(227,174,69,.16),rgba(111,214,240,.08));border:1px solid rgba(227,174,69,.4);border-radius:12px;padding:7px 10px;display:flex;gap:8px;align-items:center}
.tr-guide ol{margin:0;padding-left:18px;font-size:12px;line-height:1.45;flex:1 1 auto}
.tr-guide b{color:var(--brass)}
.tr-guide .btn{flex:none;min-height:44px;padding:4px 10px;font-size:12.5px}
.tr-rts{display:flex;flex-direction:column;gap:5px}
.tr-rt{appearance:none;font:inherit;color:var(--ink);text-align:left;display:grid;grid-template-columns:minmax(0,1fr) auto;gap:1px 8px;align-items:center;padding:5px 10px;min-height:50px;border-radius:12px;background:var(--bg);border:1px solid var(--line);cursor:pointer;position:relative}
.tr-rt.on{border-color:var(--brass);box-shadow:inset 0 0 0 1px var(--brass);background:rgba(227,174,69,.1)}
.tr-rt .a{font-weight:800;font-size:13.5px;display:flex;align-items:center;gap:6px;white-space:nowrap;overflow:hidden;min-width:0}
.tr-rt .a small{font-weight:600;font-size:11px;color:var(--muted);overflow:hidden;text-overflow:ellipsis}
.tr-rt .b{grid-column:1;font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.tr-rt .b .w{color:#ff9d8a}
.tr-rt .v{grid-row:1 / span 2;grid-column:2;text-align:right;font-family:var(--f-mono);font-weight:700;font-size:16px;line-height:1.1}
.tr-rt .v small{display:block;font-family:var(--f-body);font-size:10px;color:var(--muted);font-weight:600}
.tr-rt .rec{position:absolute;top:-6px;left:8px;font-size:9.5px;font-weight:800;background:#7fe0a8;color:#10301c;border-radius:999px;padding:0 6px;line-height:15px}
.tr-tabs{display:flex;gap:6px;align-items:stretch}
.tr-tabs .seg{flex:1 1 auto;display:flex;min-width:0}
.tr-tabs .seg button{flex:1 1 0;min-height:44px;font-size:12.5px;position:relative;padding:4px 2px;min-width:0;white-space:nowrap}
.tr-tabs .seg button i{font-style:normal;display:inline-grid;place-items:center;min-width:16px;height:16px;border-radius:8px;background:#ee6a55;color:#fff;font-size:10px;margin-left:2px;padding:0 3px;vertical-align:1px}
.tr-tabs .end{flex:none;min-height:44px;padding:6px 10px;font-size:13px}
.tr-rows{display:flex;flex-direction:column;gap:2px}
.tr-row{display:grid;grid-template-columns:minmax(0,1fr) 34px 44px 124px;align-items:center;gap:4px;min-height:46px;padding:0 3px 0 6px;border-radius:10px;background:var(--bg)}
.tr-row.ch{box-shadow:inset 0 0 0 1px rgba(227,174,69,.55);background:rgba(227,174,69,.07)}
.tr-row.na{opacity:.7}
.tr-row .rn{appearance:none;border:0;background:none;color:inherit;font:inherit;text-align:left;padding:0;display:flex;flex-direction:column;min-width:0;line-height:1.2;cursor:pointer;min-height:44px;justify-content:center}
.tr-row .rn .a{display:flex;align-items:center;gap:5px;font-size:13px;font-weight:700;white-space:nowrap}
.tr-row .rn .b{font-size:10px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-left:21px}
.tr-row .rn .b.g{color:#7fe0a8}.tr-row .rn .b.r{color:#ff9d8a}.tr-row .rn .b.y{color:#ffd27a}
.tr-row .hv{font-family:var(--f-mono);font-size:14px;text-align:center;font-weight:600;white-space:nowrap;line-height:1.1}
.tr-row .hv small{display:block;font-size:9px;color:var(--muted);font-family:var(--f-body);font-weight:600}
.tr-row .px{display:flex;flex-direction:column;font-family:var(--f-mono);font-size:11.5px;line-height:1.3;text-align:right;white-space:nowrap}
.tr-row .px .b{color:#ff9d8a}.tr-row .px .s{color:#7fe0a8}
.tr-step{display:grid;grid-template-columns:44px 1fr 44px;align-items:center;gap:2px}
.tr-step .btn{min-height:44px;padding:0;font-size:20px;border-radius:10px}
.tr-step .v{font-family:var(--f-mono);font-size:15px;text-align:center;font-weight:700}
.tr-step .v.p{color:#ff9d8a}.tr-step .v.m{color:#7fe0a8}
.tr-foot{display:flex;align-items:center;gap:6px;position:sticky;bottom:0;background:var(--surface);padding:5px 0 2px;z-index:1;box-shadow:0 10px 0 var(--surface)}
.tr-foot .sum{flex:1 1 auto;min-width:0;font-size:11.5px;color:var(--muted);line-height:1.35}
.tr-foot .sum b{font-family:var(--f-mono);color:var(--ink);font-size:13px}
.tr-foot .btn{flex:none;min-height:46px;padding:6px 10px;font-size:13px}
.tr-ct{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:12px;background:var(--bg);min-height:52px;border:1px solid transparent}
.tr-ct.go{border-color:rgba(127,224,168,.6);background:linear-gradient(90deg,rgba(127,224,168,.14),var(--bg))}
.tr-ct .tx{flex:1 1 auto;min-width:0;font-size:11.5px;line-height:1.35;color:var(--muted)}
.tr-ct .t1{display:flex;align-items:center;gap:5px;font-weight:700;font-size:13px;color:var(--ink);white-space:nowrap;overflow:hidden}
.tr-ct .t1 .u{font-size:10px;font-weight:800;color:#2b0c06;background:#ff9d5c;border-radius:6px;padding:0 5px}
.tr-ct .pg{height:5px;border-radius:3px;background:rgba(255,255,255,.08);overflow:hidden;margin:3px 0 1px}
.tr-ct .pg i{display:block;height:100%;border-radius:3px}
.tr-ct .rw{font-family:var(--f-mono);font-weight:700;color:var(--brass);font-size:16px;flex:none}
.tr-ct .btn{flex:none;min-height:44px;padding:4px 12px}
.tr-pips{display:inline-flex;gap:3px;margin-left:4px}
.tr-pips i{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.15)}
.tr-pips i.on{background:var(--brass)}
.tr-tip{font-size:11.5px;color:var(--muted);line-height:1.4}
.tr-gl{display:flex;flex-wrap:wrap;gap:4px;min-width:0}
.tr-g{display:inline-flex;align-items:center;gap:4px;background:rgba(255,255,255,.06);border-radius:8px;padding:3px 7px;font-size:12px;font-weight:700;white-space:nowrap}
.tr-g b{font-family:var(--f-mono);font-size:14px}
.tr-me{background:var(--bg);border-radius:12px;padding:7px 9px;display:flex;flex-direction:column;gap:5px;font-size:12.5px}
.tr-me .l1{display:flex;align-items:center;gap:6px;font-weight:700;flex-wrap:wrap}
.tr-me .l1 .cr{margin-left:auto;font-family:var(--f-mono);color:var(--brass);font-size:16px;display:flex;align-items:center;gap:3px}
.tr-me .l2{display:flex;gap:8px;font-size:11px;color:var(--muted);flex-wrap:wrap}
.tr-me .l2 span{display:inline-flex;align-items:center;gap:3px}
.tr-log{display:flex;flex-direction:column;gap:2px;font-size:12px;color:var(--muted)}
.tr-log div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tr-log div:last-child{color:var(--ink)}
.tr-hl{display:flex;flex-direction:column;gap:3px;font-size:12.5px;line-height:1.4}
.tr-hl div{padding:3px 8px;border-radius:8px;background:var(--bg)}
.tr-hl div.rd{background:transparent;color:var(--brass);font-weight:800;padding-top:6px}
.tr-ov{position:absolute;inset:0;z-index:16;display:flex;align-items:flex-end;justify-content:center;padding:8px;background:rgba(10,8,15,.66);animation:fade .15s}
.tr-ov .sheet{gap:9px;max-height:96%;padding:14px}
.tr-ov .sheet.cmp{overflow:hidden}
.tr-ov .sheet h2{font-size:22px;margin:0}
.tr-sc{flex:1 1 auto;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:5px;margin:0 -4px;padding:0 4px}
.tr-sec{font-size:12px;font-weight:800;display:flex;align-items:center;gap:6px;margin-top:3px}
.tr-sec small{font-weight:600;color:var(--muted)}
.tr-cr{display:grid;grid-template-columns:minmax(0,1fr) 130px;gap:6px;align-items:center;min-height:46px;background:var(--bg);border-radius:10px;padding:0 3px 0 8px}
.tr-cr .rn{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:700;min-width:0;white-space:nowrap;overflow:hidden}
.tr-cr .rn small{font-family:var(--f-mono);font-size:11px;color:var(--muted);font-weight:500}
.tr-chips{display:flex;gap:5px;flex-wrap:wrap;align-items:center}
.tr-chips .btn{min-height:44px;padding:4px 10px;font-size:12.5px}
.tr-chips .btn.on{background:var(--brass);color:var(--brass-ink);border-color:transparent}
.tr-chips .btn small{font-size:11px;font-weight:600;opacity:.75}
.tr-sum{font-size:12.5px;line-height:1.5;background:var(--bg);border-radius:10px;padding:8px 10px}
.tr-sum b{font-family:var(--f-mono)}
.tr-vd{display:flex;align-items:center;justify-content:space-between;gap:8px;border-radius:10px;padding:6px 10px;font-size:12.5px;font-weight:700;border:1px solid var(--line)}
.tr-vd b{font-family:var(--f-mono);font-size:16px}
.tr-deal{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.tr-deal>div{background:var(--bg);border-radius:12px;padding:8px;display:flex;flex-direction:column;gap:5px;min-width:0;border:1px solid}
.tr-deal .hd{font-size:11.5px;font-weight:800}
.tr-btns{display:flex;gap:6px}
.tr-btns .btn{flex:1;min-height:48px;padding:6px 8px}
.tr-gsel{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:4px}
.tr-gsel button{appearance:none;border:1px solid var(--line);background:var(--bg);border-radius:10px;min-height:44px;display:grid;place-items:center;cursor:pointer;padding:0}
.tr-gsel button.on{border-color:var(--brass);background:rgba(227,174,69,.18)}
.tr-pl{display:grid;grid-template-columns:minmax(0,1fr) 40px 46px 46px;gap:3px;font-size:12.5px;align-items:center}
.tr-pl>span{padding:6px 4px;border-radius:7px;background:var(--bg);font-family:var(--f-mono);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tr-pl>span.n{font-family:var(--f-body);font-weight:700;text-align:left;display:flex;align-items:center;gap:5px}
.tr-pl>span.h{background:transparent;font-family:var(--f-body);font-weight:700;color:var(--muted);font-size:11px;padding:2px 4px}
.tr-pl>span.hi{outline:1.5px solid #7fe0a8;color:#7fe0a8}
.tr-pl>span.lo{outline:1.5px solid #ff9d8a;color:#ff9d8a}
.tr-pl>span.x{color:var(--muted)}
.tr-pl>span.e{background:transparent}
.tr-cat{font-size:10.5px;font-weight:800;border-radius:6px;padding:1px 6px;color:#14101c}
`;
  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'tr' });
    const top = h('div', { class: 'tr-top' });
    const mapBox = h('div', { class: 'tr-map' });
    const pan = h('div', { class: 'tr-pan' });
    wrap.append(top, mapBox, pan);
    root.append(style, wrap);
    const cv = U.canvas(mapBox), ctx = cv.ctx;
    const bar = h('div', { class: 'tr-bar' });
    mapBox.append(bar);
    let st = null, anim = null, sel = -1, tab = 'mk', md = Z(), mdKey = '', pending = false, pendT = 0, ovEl = null, ovKind = '', time = 0;
    let panKey = '', panPh = '', lastLog = 0, rtKey = '', rtV = null, pdKey = '', pdV = null;
    const hist = [];
    const cam = { x: 0.5, y: 0.5, z: 1 };
    const fx = [];
    const P2 = ICONS.map(([d]) => new Path2D(d));
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#999');
    const rn = (g) => (g === CRI ? '크레딧' : GD[g].n);
    const fmtV = (v) => v.map((x, g) => (x ? rn(g) + ' ' + x : null)).filter(Boolean).join(', ') || '없음';
    const gl = (v, empty) => { const el = h('div', { class: 'tr-gl' }); v.forEach((x, g) => { if (x) el.append(h('span', { class: 'tr-g' }, ico(g, 14), rn(g), h('b', { text: String(x) }))); }); if (!el.childNodes.length) el.append(h('span', { class: 'muted', style: { fontSize: '12px' }, text: empty || '없음' })); return el; };
    const stars = []; { let sd = 7; const R = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; }; for (let i = 0; i < 170; i++) stars.push([R(), R(), R() * 1.3 + 0.3, R() * 6]); }
    const myTurn = () => st && st.ph !== 'e' && api.canAct(st.t);
    const view = () => (anim ? anim.prev : st);
    const mySeat = () => { const m = api.mySeats ? api.mySeats() : []; return m.length === 1 ? m[0] : -1; };
    const multi = () => api.mySeats().length > 1;

    function act(a, seat) {
      if (pending || !st) return;
      pending = true; clearTimeout(pendT);
      pendT = setTimeout(() => { pending = false; render(true); }, 2500);
      api.sfx('click'); api.buzz(12);
      api.actAs(seat == null ? st.t : seat, a);
      if (pending) render(true);
    }

    /* ---- geometry & camera ---- */
    function frame() {
      const W = cv.w, H = cv.h, padX = Math.max(30, W * 0.08), oy = 70, sh = Math.max(40, H - oy - 30);
      return { W, H, ox: padX, oy, sw: W - 2 * padX, sh };
    }
    function wp(x, y) { const F = frame(); return { x: F.W / 2 + F.sw * (x - cam.x) * cam.z, y: F.oy + F.sh / 2 + F.sh * (y - cam.y) * cam.z }; }
    const ppos = (p) => wp(PL[p].x, PL[p].y);
    const pR = () => { const F = frame(); return U.clamp(Math.min(F.sw / 9, (F.sh * cam.z) / 5.5) * 0.42, 8, 17); };
    function camTarget() {
      const s = view(), F = frame();
      if (!s || F.sh >= 190 || (s.ph === 'm' && myTurn() && !anim)) return [0.5, 0.5, 1];
      const z = U.clamp(200 / F.sh, 1, 2.1);
      const p = anim && anim.l.k === 'mv' ? anim.l.path[anim.l.path.length - 1] : s.loc[s.t];
      const hx = F.W / 2 / (F.sw * z), hy = (F.sh / 2 + 20) / (F.sh * z);
      const x = hx >= 0.56 ? 0.5 : U.clamp(PL[p].x, hx - 0.06, 1.06 - hx), y = hy >= 0.56 ? 0.5 : U.clamp(PL[p].y, hy - 0.06, 1.06 - hy);
      return [x, y, z];
    }
    function shipPos(s, i) {
      const p = s.loc[i], c = ppos(p), r = pR() + 9;
      const here = []; for (let k = 0; k < s.n; k++) if (s.loc[k] === p) here.push(k);
      const idx = here.indexOf(i), a = -Math.PI / 2 + Math.PI * 0.18 + (idx - (here.length - 1) / 2) * 0.62;
      return { x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, a };
    }
    /* route info for every planet (cached per state) */
    function routes(s, me) {
      const k = s.seq + ':' + s.ls + ':' + me + ':' + s.ph;
      if (rtKey !== k) {
        rtKey = k;
        try { rtV = PL.map((_, p) => routeInfo(s, me, p)); } catch (e) { console.error(e); rtV = PL.map((_, p) => ({ p, ok: p === s.loc[me], cost: 0, est: 0, sellG: [] })); }
      }
      return rtV;
    }
    function draft(s, me) {
      const k = s.seq + ':' + s.ls + ':' + me;
      if (pdKey !== k) { pdKey = k; try { pdV = planDraft(s, me); } catch (e) { console.error(e); pdV = Z(); } }
      return pdV;
    }

    /* ---- cached layers ---- */
    let bgC = null, bgKey = '', plC = null, plKey = '';
    function bgLayer() {
      const W = cv.w, H = cv.h, dpr = cv.dpr, key = W + 'x' + H + '@' + dpr;
      if (bgC && bgKey === key) return bgC;
      bgKey = key; bgC = bgC || document.createElement('canvas');
      bgC.width = Math.max(1, Math.round(W * dpr)); bgC.height = Math.max(1, Math.round(H * dpr));
      const g = bgC.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const bg = g.createRadialGradient(W * 0.5, H * 0.45, 10, W * 0.5, H * 0.5, Math.max(W, H) * 0.8);
      bg.addColorStop(0, '#1d1732'); bg.addColorStop(1, '#07060d');
      g.fillStyle = bg; g.fillRect(0, 0, W, H);
      for (const [x, y, r, c] of [[0.2, 0.75, 0.5, '111,214,240'], [0.85, 0.2, 0.45, '238,106,85'], [0.55, 0.05, 0.3, '197,140,240'], [0.7, 0.9, 0.35, '240,127,184']]) {
        const nb = g.createRadialGradient(W * x, H * y, 5, W * x, H * y, W * r);
        nb.addColorStop(0, 'rgba(' + c + ',.10)'); nb.addColorStop(1, 'rgba(' + c + ',0)');
        g.fillStyle = nb; g.fillRect(0, 0, W, H);
      }
      g.fillStyle = '#fff';
      for (let i = 60; i < stars.length; i++) { const [x, y, r] = stars[i]; g.globalAlpha = 0.22 + (i % 5) * 0.08; g.fillRect(x * W, y * H, r, r); }
      g.globalAlpha = 1;
      return bgC;
    }
    function sphere(g, x, y, R, c) {
      const pg = g.createRadialGradient(x - R * 0.35, y - R * 0.4, R * 0.1, x, y, R);
      pg.addColorStop(0, '#ffffff77'); pg.addColorStop(0.3, c); pg.addColorStop(1, '#000000b0');
      g.fillStyle = c; g.beginPath(); g.arc(x, y, R, 0, 7); g.fill();
      g.fillStyle = pg; g.beginPath(); g.arc(x, y, R, 0, 7); g.fill();
    }
    function planetBody(g, p, R) {
      const { x, y } = ppos(p), P = PL[p], ty = P.ty;
      const glow = g.createRadialGradient(x, y, R * 0.5, x, y, R * 2.1);
      glow.addColorStop(0, P.c + '40'); glow.addColorStop(1, P.c + '00');
      g.fillStyle = glow; g.beginPath(); g.arc(x, y, R * 2.1, 0, 7); g.fill();
      if (ty === 'gas' || ty === 'lab') { g.strokeStyle = P.c + '66'; g.lineWidth = Math.max(1.5, R * 0.14); g.beginPath(); g.ellipse(x, y, R * 1.65, R * 0.45, -0.35, Math.PI, Math.PI * 2); g.stroke(); }
      if (ty === 'hub') {
        g.fillStyle = 'rgba(20,16,30,.95)'; g.beginPath(); g.arc(x, y, R, 0, 7); g.fill();
        g.strokeStyle = P.c; g.lineWidth = Math.max(2.5, R * 0.22); g.beginPath(); g.arc(x, y, R * 0.78, 0, 7); g.stroke();
        g.fillStyle = '#c9b48a'; for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + 0.4; g.save(); g.translate(x, y); g.rotate(a); g.fillRect(R * 0.15, -1.5, R * 0.6, 3); g.restore(); }
        g.fillStyle = '#f2e9d8'; g.beginPath(); g.arc(x, y, R * 0.26, 0, 7); g.fill();
      } else if (ty === 'crystal') {
        g.fillStyle = P.c; g.beginPath(); g.moveTo(x, y - R * 1.15); g.lineTo(x + R * 0.9, y - R * 0.1); g.lineTo(x, y + R * 1.15); g.lineTo(x - R * 0.9, y - R * 0.1); g.closePath(); g.fill();
        g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.moveTo(x, y - R * 1.15); g.lineTo(x - R * 0.9, y - R * 0.1); g.lineTo(x, y - R * 0.1); g.closePath(); g.fill();
        g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.moveTo(x, y + R * 1.15); g.lineTo(x + R * 0.9, y - R * 0.1); g.lineTo(x, y - R * 0.1); g.closePath(); g.fill();
      } else {
        sphere(g, x, y, R, ty === 'black' ? '#2a2340' : ty === 'pirate' ? '#5a2a36' : P.c);
        g.save(); g.beginPath(); g.arc(x, y, R, 0, 7); g.clip();
        if (ty === 'gas') { g.strokeStyle = 'rgba(80,30,0,.28)'; g.lineWidth = R * 0.2; for (let k = -1; k <= 1; k++) { g.beginPath(); g.ellipse(x, y + k * R * 0.45, R * 1.2, R * 0.12, 0.2, 0, 7); g.stroke(); } }
        else if (ty === 'farm') { g.fillStyle = 'rgba(30,70,20,.45)'; for (const [dx, dy, w] of [[-0.6, -0.2, 0.5], [0.1, 0.25, 0.6], [-0.2, 0.6, 0.4]]) g.fillRect(x + dx * R, y + dy * R, w * R, R * 0.22); }
        else if (ty === 'ice') { g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.ellipse(x, y - R * 0.95, R * 0.8, R * 0.35, 0, 0, 7); g.fill(); g.beginPath(); g.ellipse(x, y + R * 1.0, R * 0.7, R * 0.3, 0, 0, 7); g.fill(); }
        else if (ty === 'mine') { g.fillStyle = 'rgba(0,0,0,.3)'; for (const [dx, dy, rr] of [[-0.3, 0.2, 0.2], [0.35, -0.2, 0.15], [0.1, 0.55, 0.12], [-0.4, -0.45, 0.1]]) { g.beginPath(); g.arc(x + dx * R, y + dy * R, rr * R, 0, 7); g.fill(); } }
        else if (ty === 'forge') { g.strokeStyle = 'rgba(255,220,120,.85)'; g.lineWidth = Math.max(1, R * 0.08); g.beginPath(); g.moveTo(x - R * 0.7, y - R * 0.2); g.lineTo(x - R * 0.1, y + R * 0.05); g.lineTo(x + R * 0.2, y - R * 0.4); g.lineTo(x + R * 0.7, y + R * 0.2); g.moveTo(x - R * 0.1, y + R * 0.05); g.lineTo(x, y + R * 0.6); g.stroke(); }
        else if (ty === 'resort') { g.fillStyle = 'rgba(80,200,210,.55)'; g.beginPath(); g.arc(x + R * 0.3, y + R * 0.35, R * 0.75, 0, 7); g.fill(); g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = Math.max(1, R * 0.1); g.beginPath(); g.arc(x - R * 0.2, y - R * 0.1, R * 0.45, 3.6, 5.8); g.stroke(); }
        else if (ty === 'fest') { const cs = ['#ffd27a', '#7ad7ff', '#7fe0a8', '#fff']; for (let k = 0; k < 7; k++) { g.fillStyle = cs[k % 4]; g.beginPath(); g.arc(x + Math.cos(k * 2.3) * R * 0.55, y + Math.sin(k * 2.3) * R * 0.55, R * 0.11, 0, 7); g.fill(); } }
        else if (ty === 'lab') { g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = Math.max(1, R * 0.08); g.beginPath(); g.moveTo(x - R, y + R * 0.1); g.lineTo(x + R, y + R * 0.1); g.moveTo(x, y - R); g.lineTo(x, y + R); g.stroke(); }
        else if (ty === 'pirate') { g.strokeStyle = '#f2e9d8'; g.lineWidth = Math.max(1.5, R * 0.13); g.lineCap = 'round'; g.beginPath(); g.moveTo(x - R * 0.45, y + R * 0.05); g.lineTo(x + R * 0.45, y + R * 0.55); g.moveTo(x + R * 0.45, y + R * 0.05); g.lineTo(x - R * 0.45, y + R * 0.55); g.stroke(); g.lineCap = 'butt'; g.fillStyle = '#f2e9d8'; g.beginPath(); g.arc(x, y - R * 0.25, R * 0.32, 0, 7); g.fill(); }
        g.restore();
        if (ty === 'black') { g.strokeStyle = '#b4a8ff'; g.lineWidth = Math.max(1.5, R * 0.12); g.beginPath(); g.arc(x, y, R * 0.95, 0, 7); g.stroke(); g.fillStyle = '#b4a8ff'; g.font = '800 ' + Math.round(R * 1.1) + 'px "IBM Plex Mono", monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('?', x, y + 1); }
        g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1; g.beginPath(); g.arc(x, y, R - 0.5, Math.PI * 1.05, Math.PI * 1.6); g.stroke();
      }
      if (ty === 'gas' || ty === 'lab') { g.strokeStyle = P.c + 'aa'; g.lineWidth = Math.max(1.5, R * 0.14); g.beginPath(); g.ellipse(x, y, R * 1.65, R * 0.45, -0.35, 0, Math.PI); g.stroke(); }
      if (ty === 'lab') { g.fillStyle = '#f2e9d8'; g.beginPath(); g.arc(x + R * 1.3, y - R * 0.9, R * 0.18, 0, 7); g.fill(); }
      const fs = R > 12 ? 11.5 : 10.5;
      g.font = '700 ' + fs + 'px "IBM Plex Sans KR", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'top';
      g.lineWidth = 3; g.strokeStyle = 'rgba(7,6,13,.92)'; g.strokeText(P.s, x, y + R * (ty === 'crystal' ? 1.2 : 1) + 3);
      g.fillStyle = '#f2e9d8'; g.fillText(P.s, x, y + R * (ty === 'crystal' ? 1.2 : 1) + 3);
    }
    function planetLayer() {
      const W = cv.w, H = cv.h, dpr = cv.dpr, key = W + 'x' + H + '@' + dpr + ':' + cam.x.toFixed(3) + ',' + cam.y.toFixed(3) + ',' + cam.z.toFixed(3);
      if (plC && plKey === key) return plC;
      plKey = key; plC = plC || document.createElement('canvas');
      plC.width = Math.max(1, Math.round(W * dpr)); plC.height = Math.max(1, Math.round(H * dpr));
      const g = plC.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
      const R = pR();
      for (const [a, b, c] of EDGES) {
        const A = ppos(a), B = ppos(b);
        g.setLineDash(c >= 2 ? [5, 5] : []);
        g.strokeStyle = c === 1 ? 'rgba(227,174,69,.30)' : 'rgba(242,233,216,.16)'; g.lineWidth = 1.5;
        g.beginPath(); g.moveTo(A.x, A.y); g.lineTo(B.x, B.y); g.stroke();
        if (cam.z <= 1.01 && R >= 11) { // distance dot
          const mx = (A.x + B.x) / 2, my = (A.y + B.y) / 2;
          g.setLineDash([]); g.fillStyle = 'rgba(12,10,20,.9)'; g.beginPath(); g.arc(mx, my, 6.5, 0, 7); g.fill();
          g.fillStyle = 'rgba(242,233,216,.6)'; g.font = '700 9px "IBM Plex Mono", monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(c), mx, my + 0.5);
        }
      }
      g.setLineDash([]);
      for (let p = 0; p < NP; p++) planetBody(g, p, R);
      return plC;
    }

    /* ---- map drawing ---- */
    function cIcon(i, x, y, sz) { ctx.save(); ctx.translate(x - sz / 2, y - sz / 2); ctx.scale(sz / 16, sz / 16); ctx.fillStyle = GC[i]; ctx.fill(P2[i], ICONS[i][1] ? 'evenodd' : 'nonzero'); ctx.restore(); }
    function rr(x, y, w, hh, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, hh, r); else ctx.rect(x, y, w, hh); }
    function tag(x, y, t, bg, fg, ic) {
      ctx.font = '800 10.5px "IBM Plex Sans KR", sans-serif';
      const iw = ic != null ? 13 : 0, w = ctx.measureText(t).width + 12 + iw;
      ctx.fillStyle = bg; rr(x - w / 2, y - 8, w, 16, 8); ctx.fill();
      if (ic != null) cIcon(ic, x - w / 2 + 6 + 5, y, 11);
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, x + iw / 2, y + 0.5);
    }
    function drawShip(x, y, ang, c, big, frac, flame) {
      const s = big ? 8 : 6.2;
      ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
      if (flame) {
        const fl = s * (1.1 + 0.45 * Math.sin(time * 47) + 0.25 * Math.sin(time * 31));
        ctx.fillStyle = 'rgba(255,190,90,.85)'; ctx.beginPath(); ctx.moveTo(-s * 0.95, -s * 0.32); ctx.lineTo(-s * 0.95 - fl, 0); ctx.lineTo(-s * 0.95, s * 0.32); ctx.fill();
      }
      for (const sd of [-1, 1]) {
        ctx.fillStyle = '#211a2e'; rr(-s * 0.85, sd > 0 ? s * 0.5 : -s * 0.95, s * 1.3, s * 0.45, s * 0.15); ctx.fill();
        if (frac > 0) { ctx.fillStyle = '#f2e9d8'; rr(-s * 0.85, sd > 0 ? s * 0.5 : -s * 0.95, s * 1.3 * Math.min(1, frac), s * 0.45, s * 0.15); ctx.fill(); }
      }
      if (big) { ctx.shadowColor = c; ctx.shadowBlur = 12; }
      ctx.fillStyle = c; ctx.beginPath();
      ctx.moveTo(s * 1.55, 0); ctx.quadraticCurveTo(s * 0.7, -s * 0.72, -s, -s * 0.58); ctx.lineTo(-s * 0.8, 0); ctx.lineTo(-s, s * 0.58); ctx.quadraticCurveTo(s * 0.7, s * 0.72, s * 1.55, 0); ctx.closePath(); ctx.fill();
      ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(12,10,20,.85)'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(s * 0.7, 0, s * 0.2, 0, 7); ctx.fill();
      ctx.restore();
    }
    function pathPts(path) { return path.map((p) => ppos(p)); }
    function strokePath(pts) { ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.stroke(); }
    function draw(dt) {
      const W = cv.w, H = cv.h, s = view(), now = performance.now();
      const [tx, ty, tz] = camTarget(), kk = Math.min(1, dt * 7);
      cam.x += (tx - cam.x) * kk; cam.y += (ty - cam.y) * kk; cam.z += (tz - cam.z) * kk;
      if (Math.abs(tx - cam.x) < 1e-3 && Math.abs(ty - cam.y) < 1e-3 && Math.abs(tz - cam.z) < 1e-3) { cam.x = tx; cam.y = ty; cam.z = tz; }
      ctx.drawImage(bgLayer(), 0, 0, W, H);
      ctx.fillStyle = '#fff';
      for (let i = 0; i < 60; i++) { const [x, y, r, ph] = stars[i]; ctx.globalAlpha = 0.3 + 0.4 * Math.sin(time * 1.5 + ph); ctx.fillRect(x * W, y * H, r, r); }
      ctx.globalAlpha = 1;
      ctx.drawImage(planetLayer(), 0, 0, W, H);
      if (!s) return;
      const R = pR();
      const me = s.ph === 'm' && myTurn() && !anim ? s.t : -1;
      const rts = me >= 0 ? routes(s, me) : null;
      if (s.ev && s.ev.k === 'S') { ctx.fillStyle = 'rgba(255,200,80,' + (0.05 + 0.04 * Math.sin(time * 3)) + ')'; ctx.fillRect(0, 0, W, H); }
      // reachable / selected
      if (me >= 0) {
        const from = s.loc[me];
        let topP = -1, topV = -1e9; rts.forEach((o) => { if (o.ok && o.est > topV) { topV = o.est; topP = o.p; } });
        if (sel >= 0 && sel !== from) {
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.setLineDash([8, 6]); ctx.lineDashOffset = -time * 30;
          strokePath(pathPts(pathOf(from, sel))); ctx.setLineDash([]); ctx.lineDashOffset = 0;
        }
        for (let p = 0; p < NP; p++) {
          const c = ppos(p), o = rts[p];
          if (!o.ok) { ctx.fillStyle = 'rgba(7,6,13,.6)'; ctx.beginPath(); ctx.arc(c.x, c.y, R * 1.25, 0, 7); ctx.fill(); continue; }
          if (p === sel) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(c.x, c.y, R + 5 + Math.sin(time * 5) * 1.5, 0, 7); ctx.stroke(); }
          if (p !== from) tag(c.x + R + 6, c.y - R - 2, String(o.cost), p === sel ? '#e3ae45' : o.debt ? 'rgba(90,30,30,.95)' : 'rgba(34,28,46,.95)', p === sel ? '#2a1d05' : o.debt ? '#ff9d8a' : '#ffd27a', IC_CR);
          if (p === topP) tag(c.x - R - 10, c.y - R - 2, '추천', '#7fe0a8', '#10301c');
        }
      }
      for (let p = 0; p < NP; p++) {
        const c = ppos(p);
        if (s.ev && s.ev.p === p && s.ev.k === 'P') {
          ctx.strokeStyle = 'rgba(238,80,60,' + (0.55 + 0.35 * Math.sin(time * 6)) + ')'; ctx.lineWidth = 2.5; ctx.setLineDash([4, 4]);
          ctx.beginPath(); ctx.arc(c.x, c.y, R + 8, 0, 7); ctx.stroke(); ctx.setLineDash([]);
          tag(c.x, c.y - R - 14, '☠ 해적', '#ee5a45', '#fff');
        } else if (s.ev && s.ev.p === p && (s.ev.k === 'B' || s.ev.k === 'G')) {
          const up = s.ev.k === 'B';
          tag(c.x, c.y - R - 14, up ? '▲' : '▼', up ? '#e3ae45' : '#5fd3a0', '#1a1206', s.ev.g);
        }
        if (p === FEST && !(s.ev && s.ev.p === p && s.ev.k !== 'F')) tag(c.x, c.y - R - 14, (s.ev && s.ev.k === 'F' ? '대축제' : '축제'), 'rgba(70,18,48,.95)', '#ff9fd0', s.fg);
        // contracts waiting at this planet (only for planets on screen)
        const cts = c.x < -R || c.x > W + R || c.y < -R || c.y > H + R ? [] : s.ct.filter((x) => x[2] === p && x[4] >= s.rd);
        cts.forEach((ct, k) => {
          const can = me >= 0 && s.cg[me][ct[0]] >= ct[1];
          ctx.font = '700 10px "IBM Plex Mono", monospace';
          const t = '×' + ct[1], tw = ctx.measureText(t).width + 21;
          const right = PL[p].x < 0.25, x = right ? c.x + R + 4 + tw : c.x - R - 4, y = c.y + R * 0.25 + k * 16;
          ctx.fillStyle = can ? 'rgba(127,224,168,.92)' : ct[5] ? 'rgba(80,30,10,.92)' : 'rgba(12,10,20,.88)'; rr(x - tw, y - 7.5, tw, 15, 7.5); ctx.fill();
          ctx.strokeStyle = ct[5] ? 'rgba(255,157,92,.8)' : 'rgba(227,174,69,.5)'; ctx.lineWidth = 1; ctx.stroke();
          cIcon(ct[0], x - tw + 8.5, y, 11);
          ctx.fillStyle = can ? '#10301c' : '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(t, x - tw + 15, y + 0.5);
        });
      }
      // ships
      const moving = anim && anim.l.k === 'mv' ? anim : null, mine = mySeat();
      for (let i = 0; i < s.n; i++) {
        if (moving && moving.l.s === i) continue;
        const q = shipPos(s, i), cur = i === s.t && s.ph !== 'e';
        if (cur) { ctx.strokeStyle = col(i); ctx.globalAlpha = 0.45 + 0.3 * Math.sin(time * 4); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(q.x, q.y, 12, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
        drawShip(q.x, q.y, q.a + Math.PI, col(i), cur, hold(s, i) / cap(s, i), false);
        if (i === mine && R >= 11) tag(q.x, q.y - 16, '나', col(i), '#14101c');
      }
      if (moving) {
        const l = moving.l, pts = pathPts(l.path);
        const nx = U.clone(moving.prev); nx.loc[l.s] = l.path[l.path.length - 1];
        const A = shipPos(moving.prev, l.s), B = shipPos(nx, l.s);
        pts[0] = A; pts[pts.length - 1] = B;
        const k = U.clamp((now - moving.t0) * sp() / moving.dur, 0, 1), e = k * k * (3 - 2 * k);
        let tot = 0; const seg = []; for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y); seg.push(d); tot += d; }
        let x = A.x, y = A.y, ang = A.a + Math.PI;
        if (tot > 0) {
          let dd = e * tot, i = 0;
          while (i < seg.length - 1 && dd > seg[i]) { dd -= seg[i]; i++; }
          const f = seg[i] ? dd / seg[i] : 1;
          x = U.lerp(pts[i].x, pts[i + 1].x, f); y = U.lerp(pts[i].y, pts[i + 1].y, f);
          ang = Math.atan2(pts[i + 1].y - pts[i].y, pts[i + 1].x - pts[i].x);
          ctx.strokeStyle = col(l.s) + '66'; ctx.lineWidth = 3; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y); for (let j = 1; j <= i; j++) ctx.lineTo(pts[j].x, pts[j].y); ctx.lineTo(x, y); ctx.stroke(); ctx.lineCap = 'butt';
        }
        drawShip(x, y, ang, col(l.s), true, hold(moving.prev, l.s) / cap(moving.prev, l.s), tot > 0 && k < 0.95);
        if (k >= 1 && !moving.ended) { moving.ended = true; setTimeout(() => endAnim(moving), 100 / sp()); }
      }
      drawFx(now);
    }

    /* ---- effects (all triggered from state changes, so guests see them too) ---- */
    function addFx(o) { o.t0 = performance.now(); fx.push(o); if (fx.length > 48) fx.shift(); }
    function drawFx(now) {
      const W = cv.w, H = cv.h;
      for (let i = fx.length - 1; i >= 0; i--) {
        const f = fx[i], k = ((now - f.t0) * sp()) / f.dur - (f.dl || 0);
        if (k >= 1) { fx.splice(i, 1); continue; }
        if (k < 0) continue;
        const fade = k < 0.7 ? 1 : (1 - k) / 0.3;
        if (f.k === 'txt') {
          const y = f.y - 26 * (1 - (1 - k) * (1 - k));
          ctx.globalAlpha = fade; ctx.font = '800 ' + (f.sz || 15) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          const tw = ctx.measureText(f.t).width, ix = f.r != null ? 9 : 0;
          ctx.fillStyle = 'rgba(12,10,20,.85)'; rr(f.x - tw / 2 - 7 - ix, y - 11, tw + 14 + ix * 2, 22, 11); ctx.fill();
          if (f.r != null) cIcon(f.r, f.x - tw / 2 - 4, y, 13);
          ctx.fillStyle = f.c; ctx.fillText(f.t, f.x + ix, y + 1);
          ctx.globalAlpha = 1;
        } else if (f.k === 'ring') {
          ctx.globalAlpha = 1 - k; ctx.strokeStyle = f.c; ctx.lineWidth = 3 * (1 - k) + 1; ctx.beginPath(); ctx.arc(f.x, f.y, f.r0 + 34 * k, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
        } else if (f.k === 'box') {
          const e = k * k * (3 - 2 * k), x = U.lerp(f.ax, f.bx, e), y = U.lerp(f.ay, f.by, e) - Math.sin(Math.PI * e) * f.arc;
          ctx.globalAlpha = Math.min(1, fade * 1.5);
          ctx.fillStyle = 'rgba(12,10,20,.78)'; ctx.beginPath(); ctx.arc(x, y, 8.5, 0, 7); ctx.fill();
          cIcon(f.r, x, y, 12); ctx.globalAlpha = 1;
        } else if (f.k === 'flash') {
          ctx.fillStyle = f.c; ctx.globalAlpha = 0.28 * (1 - k); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
        } else if (f.k === 'ban') {
          const a = k < 0.12 ? k / 0.12 : k > 0.8 ? (1 - k) / 0.2 : 1;
          ctx.globalAlpha = a;
          ctx.font = '400 21px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
          const w1 = ctx.measureText(f.t).width; ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
          const w2 = f.sub ? ctx.measureText(f.sub).width : 0;
          const bw = Math.min(W - 20, Math.max(w1, w2) + 36), bh = f.sub ? 56 : 40, by = Math.max(50, H * 0.5 - bh / 2) + (1 - a) * 8;
          ctx.fillStyle = 'rgba(14,11,22,.93)'; rr(W / 2 - bw / 2, by, bw, bh, 14); ctx.fill();
          ctx.strokeStyle = f.c || 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.font = '400 21px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(f.t, W / 2, by + (f.sub ? 20 : bh / 2 + 1));
          if (f.sub) { ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = f.c || '#ffd27a'; ctx.fillText(f.sub, W / 2, by + 41, bw - 16); }
          ctx.globalAlpha = 1;
        }
      }
    }
    function fxFor(l, s, prev) {
      if (l.k === 'mk') {
        const q = shipPos(s, l.s), c = ppos(s.loc[l.s]);
        addFx({ k: 'txt', x: q.x, y: q.y - 18, t: sgn(l.net), c: l.net >= 0 ? '#7fe0a8' : '#ff9d8a', r: IC_CR, dur: 1400 });
        let n = 0;
        for (let g = 0; g < NG && n < 5; g++) {
          const d = l.d ? l.d[g] : 0;
          if (!d) continue;
          const toShip = d > 0;
          addFx({ k: 'box', r: g, ax: toShip ? c.x : q.x, ay: toShip ? c.y : q.y, bx: toShip ? q.x : c.x, by: toShip ? q.y : c.y, arc: 12, dur: 520, dl: n * 0.35 });
          n++;
        }
      } else if (l.k === 'ct') {
        const c = ppos(s.loc[l.s]);
        addFx({ k: 'ring', x: c.x, y: c.y, r0: pR(), c: '#e3ae45', dur: 900 });
        addFx({ k: 'ring', x: c.x, y: c.y, r0: pR() * 0.6, c: '#ffd27a', dur: 900, dl: 0.25 });
        addFx({ k: 'txt', x: c.x, y: c.y - pR() - 6, t: '계약 +' + l.b, c: '#ffd27a', dur: 1700, sz: 16 });
      } else if (l.k === 'up') {
        const q = shipPos(s, l.s);
        addFx({ k: 'ring', x: q.x, y: q.y, r0: 8, c: GC[IC_UP[l.u]], dur: 800 });
        addFx({ k: 'txt', x: q.x, y: q.y - 18, t: UPN[l.u] + ' ↑', c: '#ffd27a', r: IC_UP[l.u], dur: 1500 });
      } else if (l.k === 'tr') {
        const A = shipPos(s, l.a), B = shipPos(s, l.b);
        let n = 0;
        for (let g = 0; g <= CRI && n < 6; g++) {
          const d = l.v ? l.v[g] : 0;
          if (!d) continue;
          const toB = d > 0;
          addFx({ k: 'box', r: g, ax: toB ? A.x : B.x, ay: toB ? A.y : B.y, bx: toB ? B.x : A.x, by: toB ? B.y : A.y, arc: 30, dur: 900, dl: n * 0.25 });
          n++;
        }
        addFx({ k: 'txt', x: (A.x + B.x) / 2, y: Math.min(A.y, B.y) - 22, t: '거래!', c: '#ffd27a', dur: 1500 });
      }
    }
    function pirateFx(l, s) {
      if (!s) return;
      const q = shipPos(s, l.s);
      addFx({ k: 'flash', c: '#ee3a2a', dur: 600 });
      addFx({ k: 'txt', x: q.x, y: q.y - 18, t: l.pn ? '해적! −' + l.pn : '해적 무사 통과', c: '#ff9d8a', r: l.pn ? l.pg : null, dur: 1800 });
    }

    const stopLoop = U.loop((dt) => { time += dt; draw(dt); if (!ovEl && st && st.of && !anim && api.canAct(st.of.to)) syncOffer(); });
    cv.cv.addEventListener('pointerdown', onMapDown);
    function onMapDown(ev) {
      if (!st) return;
      const q = cv.local(ev);
      let best = -1, bd = Math.max(24, pR() + 12);
      for (let p = 0; p < NP; p++) { const c = ppos(p), d = Math.hypot(q.x - c.x, q.y - c.y); if (d < bd) { bd = d; best = p; } }
      if (best < 0) return;
      const p = best;
      if (st.ph === 'm' && myTurn() && !anim) {
        if (p === sel) { planetSheet(p); return; }
        const o = routes(st, st.t)[p];
        if (!o.ok) { api.toast(o.cost == null ? '엔진이 닿지 않아요 (한 번에 ' + range(st, st.t) + '칸까지)' : '이동비가 모자라요 (' + o.cost + ' 필요)'); api.buzz(30); return; }
        sel = p; api.sfx('tick'); api.buzz(8); render(true);
      } else planetSheet(p);
    }

    /* ---- log text ---- */
    function logText(e) {
      const [, k, a, b, c, d, f] = e;
      switch (k) {
        case 'rd': return '— 라운드 ' + a + ' —';
        case 'ev': return '이벤트 · ' + evText({ k: a, p: b, g: c });
        case 'mv': return b === c ? nm(a) + ' · ' + PL[c].s + '에 머묾' : nm(a) + ' · ' + PL[b].s + ' → ' + PL[c].s + ' (이동비 ' + d + ')';
        case 'pi': return b < 0 || !c ? nm(a) + ' · 해적을 만났지만 무사' : nm(a) + ' · 해적에게 ' + GD[b].n + ' ' + c + '개 빼앗김!';
        case 'mk': return nm(a) + ' · 시장 ' + (c ? c + '개 팔고 ' : '') + (b ? b + '개 사고 ' : '') + '(' + sgn(d) + ')';
        case 'ct': return nm(a) + ' · 계약 완료 ' + GD[b].n + ' ' + c + ' → ' + PL[d].s + ' (+' + f + ')';
        case 'up': return nm(a) + ' · ' + UPN[b] + ' ' + c + '단계로 업그레이드 (−' + d + ')';
        case 'of': return nm(a) + ' → ' + nm(b) + ' · 거래 제안';
        case 'co': return nm(a) + ' → ' + nm(b) + ' · 역제안';
        case 'ok': return nm(b) + ' · ' + nm(a) + '의 제안 수락';
        case 'no': return nm(b) + ' · ' + nm(a) + '의 제안 거절';
        case 'fl': return nm(a) + '·' + nm(b) + ' 거래 실패 (물건이나 화물칸 부족)';
        case 'cx': return nm(a) + ' · 제안 취소';
        case 'gf': return nm(a) + ' → ' + nm(b) + ' · ' + rn(c) + ' ' + d + ' 보냄';
        case 'pk': return nm(a) + ' · ' + nm(b) + '와의 약속을 지켰어요 (' + rn(c) + ' ' + d + ')';
        case 'pb': return nm(a) + ' · ' + nm(b) + '와의 약속을 어겼어요! (' + rn(c) + ' ' + d + ')';
        case 'end': return '— 항해 끝 —';
      }
      return '';
    }
    function evText(ev) {
      if (!ev) return '';
      switch (ev.k) {
        case 'P': return '해적 출몰: ' + PL[ev.p].s + '에 들어가면 가장 비싼 화물을 빼앗겨요(방어막이 막아요)';
        case 'S': return '태양 폭풍: 이번 라운드 이동비 1칸만큼 더';
        case 'B': return '가격 폭등: ' + PL[ev.p].s + '의 ' + GD[ev.g].n + ' 값이 치솟았어요';
        case 'G': return '대량 공급: ' + PL[ev.p].s + '의 ' + GD[ev.g].n + ' 값이 뚝 떨어졌어요';
        case 'F': return '대축제: 카니발의 축제 물품(' + GD[ev.g].n + ')과 먹을거리·사치품 값이 더 올랐어요';
        case 'T': return '기술 박람회: 이번 라운드 조선소 업그레이드 30% 할인';
        case 'W': return '전쟁 소문: 무기 값이 모든 곳에서 올랐어요';
        case 'H': return '흉년: 곡물·과일·향신료 값이 모든 곳에서 올랐어요';
        case 'O': return '연료 파동: 이번 라운드 연료값 1.5배';
      }
      return '';
    }

    /* ---- top strip & map bar ---- */
    function renderTop() {
      const s = view(); if (!s) return;
      top.innerHTML = '';
      top.style.gridTemplateColumns = 'repeat(' + s.n + ',minmax(0,1fr))';
      const w = Array.from({ length: s.n }, (_, i) => wealth(s, i)), best = Math.max(...w);
      const lead = s.rd > 1 && w.filter((x) => x === best).length === 1 ? w.indexOf(best) : -1;
      for (let i = 0; i < s.n; i++) {
        const on = s.ph !== 'e' && s.t === i, br = s.rp[i][1];
        top.append(h('button', { class: 'tr-p', 'aria-label': nm(i) + ' 정보 · 크레딧 ' + s.cr[i], onclick: () => playerSheet(i),
          style: { borderColor: on ? col(i) : '', boxShadow: on ? '0 0 0 1.5px ' + col(i) + ' inset, 0 4px 14px ' + col(i) + '33' : '', opacity: on || s.ph === 'e' ? 1 : 0.82 } },
        h('div', { class: 'r1' }, h('span', { class: 'dot', style: { '--c': col(i), flex: 'none' } }), h('span', { class: 'nm', text: nm(i) }),
          i === lead ? h('span', { class: 'cw', 'aria-label': '1등', text: '♛' }) : null,
          br ? h('span', { class: 'rp', 'aria-label': '약속 어김 ' + br, text: '✗' + br }) : null),
        h('div', { class: 'r2' }, h('span', { class: 'cr', text: String(s.cr[i]) }), h('span', { class: 'lc', text: PL[s.loc[i]].s })),
        h('span', { class: 'hb', style: { width: (100 * hold(s, i) / cap(s, i)) + '%', background: col(i) } })));
      }
    }
    function renderBar() {
      const s = view(); if (!s) return;
      bar.innerHTML = '';
      const last = s.rd >= s.R && s.ph !== 'e', narrow = cv.w < 390;
      bar.append(h('span', { class: 'tr-pill', style: { flex: 'none', color: last ? '#ffd27a' : '' }, text: s.ph === 'e' ? '항해 끝' : last ? '마지막' : (narrow ? 'R' : '라운드 ') + s.rd + '/' + s.R }));
      if (s.ev) bar.append(h('button', { class: 'tr-pill ev', text: EVN[s.ev.k] + (narrow ? '' : (s.ev.p >= 0 ? ' · ' + PL[s.ev.p].s : '')), onclick: eventSheet }));
      bar.append(h('span', { class: 'sp' }));
      bar.append(h('button', { class: 'btn', text: '시세표', onclick: () => priceSheet(-1) }));
      bar.append(h('button', { class: 'btn', text: '기록', 'aria-label': '지난 기록', onclick: historySheet }));
    }

    /* ---- bottom panel ---- */
    function holdRepeat(btn, fn) {
      let t1 = 0, t2 = 0, n = 0;
      const stop = () => { clearTimeout(t1); clearInterval(t2); };
      btn.addEventListener('pointerdown', (e) => { e.preventDefault(); if (btn.disabled) return; n = 0; fn(1); api.buzz(6); t1 = setTimeout(() => { t2 = setInterval(() => fn(++n > 10 ? 5 : 1), 90); }, 380); });
      ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => btn.addEventListener(ev, stop));
      btn.addEventListener('click', (e) => { if (e.detail === 0 && !btn.disabled) fn(1); }); // keyboard
    }
    function stepper(get, set, lo, hi, signed) {
      const v = h('span', { class: 'v' });
      const m = h('button', { class: 'btn', text: '−', 'aria-label': '줄이기' });
      const p = h('button', { class: 'btn', text: '+', 'aria-label': '늘리기' });
      const upd = () => { const x = get(); v.textContent = signed && x > 0 ? '+' + x : String(x); v.className = 'v' + (signed && x > 0 ? ' p' : signed && x < 0 ? ' m' : ''); m.disabled = x <= lo(); p.disabled = x >= hi(); };
      holdRepeat(m, (k) => { const x = Math.max(lo(), get() - k); if (x !== get()) { set(x); api.sfx('tick'); } });
      holdRepeat(p, (k) => { const x = Math.min(hi(), get() + k); if (x !== get()) { set(x); api.sfx('tick'); } });
      const el = h('div', { class: 'tr-step' }, m, v, p);
      el.upd = upd; upd();
      return el;
    }
    function render(force) {
      renderTop();
      buildPan(force);
      renderBar();
    }
    function buildPan(force) {
      const s = st; if (!s) return;
      const key = JSON.stringify([s.seq, s.ls, s.ph, s.t, sel, tab, pending, !!anim, s.of && s.of.k]);
      if (key === panKey && !force) return;
      panKey = key;
      const pk = s.ph + ':' + s.t + ':' + tab, keepScroll = pk === panPh ? pan.scrollTop : 0;
      panPh = pk;
      pan.innerHTML = '';
      syncOffer();
      wrap.classList.toggle('mv', s.ph === 'm' || !myTurn() || !!anim);
      if (s.ph === 'e') { pan.append(h('div', { class: 'tr-hint' }, h('span', { class: 'ph w', text: '끝' }), h('span', { class: 'tx', text: '항해가 끝났어요. 남은 화물은 지금 있는 행성 시세로 팔려요.' }))); return; }
      if (anim || !myTurn()) waitPanel();
      else if (s.ph === 'm') movePanel();
      else tradePanel();
      pan.scrollTop = keepScroll;
    }
    function shipLine(s, i) {
      return h('div', { class: 'l2' },
        h('span', null, ico(16, 12), '화물칸 ' + hold(s, i) + '/' + cap(s, i)),
        h('span', null, ico(17, 12), '엔진 ' + range(s, i) + '칸'),
        h('span', null, ico(18, 12), '방어막 ' + ['없음', '1단계', '2단계'][s.up[i][2]]));
    }
    function myCard(s, me) {
      return h('div', { class: 'tr-me' },
        h('div', { class: 'l1' }, h('span', { class: 'dot', style: { '--c': col(me) } }), h('span', { text: nm(me) + ' · ' + PL[s.loc[me]].s }),
          h('span', { class: 'cr' }, ico(IC_CR, 14), String(s.cr[me]))),
        shipLine(s, me),
        gl(s.cg[me].concat(0), '화물 없음'));
    }
    function waitPanel() {
      const s = st, me = mySeat() >= 0 ? mySeat() : (api.mySeats ? api.mySeats()[0] : null);
      pan.append(h('div', { class: 'tr-hint' }, h('span', { class: 'ph w', text: s.ph === 'm' ? '이동' : '거래' }), h('span', { class: 'dot', style: { '--c': col(s.t) } }),
        h('span', { class: 'tx', text: nm(s.t) + (anim ? ' · 항해 중…' : s.ph === 'm' ? ' · 항로 고르는 중…' : ' · ' + PL[s.loc[s.t]].s + '에서 거래 중…') })));
      if (s.of && s.of.f !== s.t && api.canAct(s.of.f)) pan.append(h('div', { class: 'tr-ct' }, h('div', { class: 'tx', text: nm(s.of.to) + '에게 역제안을 보냈어요 · 답 기다리는 중' }), h('button', { class: 'btn', text: '취소', onclick: () => act({ t: 'cx' }, s.of.f) })));
      if (me != null && me >= 0) {
        pan.append(myCard(s, me));
        s.pm.filter((x) => x.to === me).forEach((x) => pan.append(h('div', { class: 'tr-tip', text: nm(x.f) + '의 약속: ' + rn(x.r) + ' ' + x.n + (x.g ? ' (' + x.g + ' 받음)' : '') + ' · ' + nm(x.f) + '의 다음 차례까지' })));
      }
      const lgBox = h('div', { class: 'tr-log' });
      s.lg.slice(-3).forEach((e) => lgBox.append(h('div', { text: logText(e) })));
      pan.append(lgBox);
    }
    function reasons(o, last) {
      const parts = [];
      if (o.debt) parts.push(h('span', { class: 'w', text: '빚 ' + o.debt }));
      if (o.pir) parts.push(h('span', { class: 'w', text: '☠ 해적' + (o.lost ? ' −' + o.lost : '') }));
      if (o.ctN) parts.push('계약 +' + o.ctB);
      if (o.sellN) parts.push(GD[o.sellG[0]].n + (o.sellG.length > 1 ? ' 등' : '') + ' 팔기 ' + o.rev);
      if (o.buy) parts.push(GD[o.buy.g].n + ' ' + o.buy.k + '개 사서 →' + PL[o.buy.q].s);
      if (!parts.length) parts.push(last ? '팔 화물이 없어요' : '살 만한 게 별로 없어요');
      const el = h('span', { class: 'b' });
      parts.forEach((x, i) => { if (i) el.append(' · '); el.append(x); });
      return el;
    }
    function movePanel() {
      const s = st, me = s.t, from = s.loc[me], last = s.rd >= s.R;
      const rts = routes(s, me), ok = rts.filter((o) => o.ok).sort((a, b) => b.est - a.est);
      if (sel < 0 || !rts[sel] || !rts[sel].ok) sel = ok.length ? ok[0].p : from;
      const topP = ok.length ? ok[0].p : from;
      let hint;
      if (last) hint = '마지막 라운드! 화물을 가장 비싸게 팔 곳으로 가요';
      else if (s.cr[me] < 10 && !hold(s, me)) hint = '돈이 거의 없어요 · 다른 선장에게 거래를 부탁해 봐요';
      else if (s.cr[me] < 10) hint = '돈이 모자라요 · 화물을 비싸게 사 주는 곳으로 가요(모자란 이동비는 빚)';
      else if (rts[topP].ctN) hint = '추천: ' + PL[topP].s + ' — 계약 납품 +' + rts[topP].ctB;
      else hint = '추천 항로를 누르거나 지도에서 행성을 골라요';
      pan.append(h('div', { class: 'tr-hint' }, h('span', { class: 'ph', text: '1 이동' }),
        h('span', { class: 'tx', text: (multi() ? nm(me) + ' · ' : '') + hint }),
        h('span', { class: 'sub' }, ico(IC_CR, 13), String(s.cr[me]))));
      const small = wrap.clientHeight < 700, list = ok.slice(0, small ? 2 : 3);
      if (!list.some((o) => o.p === sel) && rts[sel]) list.unshift(rts[sel]);
      if (!small && !list.some((o) => o.p === from)) list.push(rts[from]);
      const box = h('div', { class: 'tr-rts' });
      for (const o of list) {
        const p = o.p, d = DIST[from][p];
        box.append(h('button', { class: 'tr-rt' + (p === sel ? ' on' : ''), 'aria-pressed': String(p === sel), onclick: () => { if (sel === p) { planetSheet(p); return; } sel = p; api.sfx('tick'); api.buzz(8); render(true); } },
          p === topP ? h('span', { class: 'rec', text: '추천' }) : null,
          h('span', { class: 'a' }, h('span', { class: 'dot', style: { '--c': PL[p].c, flex: 'none' } }), p === from ? '머무르기 · ' + PL[p].s : PL[p].s,
            h('small', { text: p === from ? '이동비 0' : d + '칸 · 이동비 ' + o.cost })),
          reasons(o, last),
          h('span', { class: 'v', style: { color: o.est > 0 ? '#7fe0a8' : o.est < 0 ? '#ff9d8a' : '' } }, sgn(o.est), h('small', { text: last ? '끝날 때' : '예상' }))));
      }
      pan.append(box);
      if (!small) pan.append(h('div', { class: 'tr-tip', text: '다른 행성은 지도에서 눌러요 · 고른 걸 한 번 더 누르면 행성 정보' }));
      const o = rts[sel];
      pan.append(h('button', { class: 'btn primary block tr-go', style: { minHeight: '50px', fontSize: '15px' }, disabled: pending || !o || !o.ok ? true : null,
        text: sel === from ? PL[from].s + '에 머물고 거래하기' : jo(PL[sel].s, '으로', '로') + ' 출발 · 이동비 ' + o.cost + (o.debt ? ' (빚 ' + o.debt + ')' : ''),
        onclick: () => {
          const p = sel;
          if (!o.debt) { act({ t: 'mv', p }); return; }
          sheet('info', h('h2', { text: '빚을 지고 갈까요?' }),
            h('div', { class: 'tr-sum' }, '이동비 ', h('b', { text: String(o.cost) }), ' 중 ', h('b', { style: { color: '#ff9d8a' }, text: String(o.debt) }), '이 모자라요. 모자란 만큼 크레딧이 마이너스(빚)가 되고, 빚이 있는 동안은 물건을 살 수 없어요. 팔기는 돼요.'),
            h('div', { class: 'tr-btns' }, h('button', { class: 'btn', text: '취소', onclick: closeOv }),
              h('button', { class: 'btn primary', text: '그래도 출발', onclick: () => { closeOv(); act({ t: 'mv', p }); } })));
        } }));
    }
    /* what to do now (trade phase) */
    function tradeTodo(s, me) {
      const loc = s.loc[me];
      const pm = s.pm.find((x) => x.f === me && x.g < x.n);
      if (pm) {
        const left = pm.n - pm.g, can = pm.r === CRI ? s.cr[me] >= left : s.cg[me][pm.r] >= left && hold(s, pm.to) + left <= cap(s, pm.to);
        return { t: nm(pm.to) + '에게 한 약속: ' + rn(pm.r) + ' ' + left + (s.rd >= pm.d ? ' (이번 차례까지)' : ''), b: can ? { l: '지키기', a: { t: 'gf', to: pm.to, r: pm.r, n: left } } : null };
      }
      const ci = s.ct.findIndex((c) => c[2] === loc && s.cg[me][c[0]] >= c[1] && c[4] >= s.rd);
      if (ci >= 0) { const c = s.ct[ci]; return { t: '계약 완료 가능! ' + GD[c[0]].n + ' ' + c[1] + '개', b: { l: '납품 +' + c[3], a: { t: 'ct', i: ci } } }; }
      if (md.some((x) => x)) return { t: '담은 거래는 [거래 확정]을 눌러야 이루어져요' };
      const dv = draft(s, me);
      if (dv.some((x) => x) && s.tk < 4) {
        const so = [], bu = [];
        dv.forEach((x, g) => { if (x < 0) so.push(GD[g].n); else if (x > 0) bu.push(GD[g].n + ' ' + x); });
        const t = (so.length ? so.slice(0, 2).join('·') + ' 팔기' : '') + (so.length && bu.length ? ', ' : '') + (bu.length ? bu.slice(0, 2).join('·') + ' 사기' : '');
        return { t: '추천: ' + t, b: { l: '담기', fn: () => { tab = 'mk'; mdKey = s.seq + ':' + me; md = dv.slice(); api.sfx('tick'); render(true); } } };
      }
      const u = PL[loc].yard ? wantUp(s, me, 3, s.cr[me]) : -1;
      if (u >= 0 && tab !== 'up') return { t: '조선소: ' + UPN[u] + ' 업그레이드를 추천해요', b: { l: '보기', fn: () => { tab = 'up'; render(true); } } };
      if (s.rd >= s.R) return { t: '마지막 라운드! 남은 화물은 끝날 때 여기 시세로 팔려요' };
      if (hold(s, me)) {
        let bv = 0, bt = '';
        for (let g = 0; g < NG; g++) if (s.cg[me][g]) { const [v, q] = bestProjQ(s, me, g, loc, 0, 3); if (q >= 0 && v * s.cg[me][g] > bv) { bv = v * s.cg[me][g]; bt = jo(GD[g].n, '은', '는') + ' ' + PL[q].s + '에서 비싸요'; } }
        if (bt) return { t: bt + ' · 다 했으면 [턴 끝]' };
      }
      return { t: '할 일을 마쳤으면 [턴 끝]' };
    }
    function tradePanel() {
      const s = st, me = s.t, here = s.loc[me];
      const ctHere = s.ct.filter((c) => c[2] === here && s.cg[me][c[0]] >= c[1] && c[4] >= s.rd).length;
      const myPm = s.pm.filter((x) => x.f === me && x.g < x.n).length + (s.of && s.of.f === me ? 1 : 0);
      const yard = !!PL[here].yard;
      if (tab === 'up' && !yard) tab = 'mk';
      const td = tradeTodo(s, me);
      pan.append(h('div', { class: 'tr-hint' }, h('span', { class: 'ph', text: '2 거래' }),
        h('span', { class: 'tx', text: (multi() ? nm(me) + ' · ' : '') + td.t }),
        td.b ? h('button', { class: 'btn primary', disabled: pending ? true : null, text: td.b.l, onclick: () => (td.b.fn ? td.b.fn() : act(td.b.a)) }) : null));
      const tb = (id, label, badge) => h('button', { class: tab === id ? 'on' : '', onclick: () => { tab = id; render(true); } }, label, badge ? h('i', { text: String(badge) }) : null);
      const seg = h('div', { class: 'seg' }, tb('mk', '시장'), tb('ct', '계약', ctHere), yard ? tb('up', '조선소') : null, tb('cm', '교신', myPm));
      pan.append(h('div', { class: 'tr-tabs' }, seg, h('button', { class: 'btn end tr-end', disabled: pending ? true : null, text: '턴 끝', onclick: askEnd })));
      if (tab === 'mk') marketTab();
      else if (tab === 'ct') contractTab();
      else if (tab === 'up') yardTab();
      else commTab();
    }
    function askEnd() {
      const s = st, me = s.t, warn = [];
      if (md.some((x) => x)) warn.push('확정하지 않은 시장 거래는 사라져요.');
      const c = s.ct.find((x) => x[2] === s.loc[me] && s.cg[me][x[0]] >= x[1] && x[4] >= s.rd);
      if (c) warn.push('지금 납품할 수 있는 계약이 있어요 (+' + c[3] + ').');
      if (s.pm.some((x) => x.f === me && x.g < x.n && s.rd >= x.d)) warn.push('약속을 안 지키고 끝내면 "약속 어김"으로 기록돼요.');
      if (s.of && s.of.f === me) warn.push('걸어 둔 제안은 취소돼요.');
      if (s.rd >= s.R && hold(s, me)) warn.push('마지막 차례예요. 남은 화물은 끝날 때 여기 시세로 팔려요(안 사는 물품은 기본값의 절반).');
      if (!warn.length) { md = Z(); act({ t: 'end' }); return; }
      sheet('info', h('h2', { text: '턴을 끝낼까요?' }), ...warn.map((t) => h('div', { class: 'tr-sum', text: t })),
        h('div', { class: 'tr-btns' }, h('button', { class: 'btn', text: '돌아가기', onclick: closeOv }),
          h('button', { class: 'btn primary', text: '턴 끝내기', onclick: () => { closeOv(); md = Z(); act({ t: 'end' }); } })));
      api.sfx('click');
    }
    function marketTab() {
      const s = st, me = s.t, p = s.loc[me], C = cap(s, me);
      const k = s.seq + ':' + me;
      if (mdKey !== k) { md = Z(); mdKey = k; }
      const list = [];
      for (let g = 0; g < NG; g++) if (trades(s, p, g) || s.cg[me][g]) list.push(g);
      const info = {};
      for (const g of list) {
        const tr = trades(s, p, g), [v, q] = bestProjQ(s, me, g, p, 0, 3);
        info[g] = { tr, v: Math.floor(v), q, b: tr ? buyNow(s, p, g) : 0, sv: tr ? sellNow(s, p, g) : 0 };
        info[g].m = tr ? info[g].v - info[g].b : -99;
      }
      list.sort((a, b) => (s.cg[me][b] > 0) - (s.cg[me][a] > 0) || (s.cg[me][a] ? info[b].sv * s.cg[me][b] - info[a].sv * s.cg[me][a] : info[b].m - info[a].m));
      const rows = h('div', { class: 'tr-rows' });
      const steps = [], rowEls = {}, hvEls = {}, tipEls = {};
      const sum = h('div', { class: 'sum' });
      const go = h('button', { class: 'btn primary', text: '거래 확정' });
      const quick = h('button', { class: 'btn' });
      function calc() {
        let cr = s.cr[me], hl = hold(s, me), prof = 0, ok = true;
        const v = {};
        for (let g = 0; g < NG; g++) if (md[g] < 0) { const q = quote(s, p, g, md[g]).v; v[g] = q; cr += q; hl += md[g]; prof += q + md[g] * basis(s, me, g); }
        for (let g = 0; g < NG; g++) if (md[g] > 0) { const q = quote(s, p, g, md[g]).v; v[g] = q; cr -= q; hl += md[g]; }
        if ((cr < 0 && md.some((x) => x > 0)) || hl > C) ok = false; // in debt you may still sell
        return { cr, hl, ok, net: cr - s.cr[me], prof, v };
      }
      const sellable = () => s.cg[me].some((x, g) => x && trades(s, p, g));
      function tipFor(g, c) {
        const I = info[g], n = md[g], have = s.cg[me][g];
        if (n < 0) { const pr = c.v[g] + n * basis(s, me, g); return [(-n) + '개 팔면 +' + c.v[g] + ' (산 값보다 ' + sgn(pr) + ')', pr >= 0 ? 'g' : 'r']; }
        if (n > 0) { const back = I.q >= 0 ? ' · ' + PL[I.q].s + '에서 ≈' + I.v * n : ''; return [n + '개 사면 −' + c.v[g] + back, 'y']; }
        if (!I.tr) return ['여기선 안 사요' + (I.q >= 0 ? ' · ' + PL[I.q].s + ' ' + I.v : ''), 'r'];
        if (have) {
          const bs = basis(s, me, g);
          if (I.sv >= I.v) return ['여기가 최고가 · 산 값 ' + bs, 'g'];
          return [(I.q >= 0 ? PL[I.q].s + '에서 ' + I.v : '') + ' · 산 값 ' + bs, ''];
        }
        if (I.m >= 4) return ['→' + PL[I.q].s + ' ' + I.v + ' (+' + I.m + ')', 'g'];
        return [I.q >= 0 ? '최고 ' + PL[I.q].s + ' ' + I.v : '팔 곳이 없어요', ''];
      }
      function upd() {
        steps.forEach((x) => x.upd());
        const c = calc();
        for (const g of list) {
          rowEls[g].classList.toggle('ch', !!md[g]);
          hvEls[g].innerHTML = '';
          if (md[g]) hvEls[g].append(String(s.cg[me][g] + md[g]), h('small', { text: s.cg[me][g] + '→' }));
          else hvEls[g].append(String(s.cg[me][g]), h('small', { text: '보유' }));
          const [t, cls] = tipFor(g, c);
          tipEls[g].textContent = t; tipEls[g].className = 'b' + (cls ? ' ' + cls : '');
        }
        sum.innerHTML = '';
        sum.append(ico(IC_CR, 12), ' ', h('b', { text: String(s.cr[me]) }), c.net ? h('span', { style: { color: c.net > 0 ? '#7fe0a8' : '#ff9d8a', fontFamily: 'var(--f-mono)', fontWeight: 700 }, text: ' ' + sgn(c.net) + ' → ' + c.cr }) : '',
          h('br'), '화물 ', h('b', { style: { color: c.hl > C ? '#ff9d8a' : '' }, text: c.hl + '/' + C }),
          !c.ok ? h('span', { style: { color: '#ff9d8a' }, text: c.cr < 0 ? ' 돈 부족' : ' 칸 부족' }) : md.some((x) => x < 0) ? h('span', { style: { color: c.prof >= 0 ? '#7fe0a8' : '#ff9d8a' }, text: ' 이익 ' + sgn(c.prof) }) : '');
        go.disabled = !c.ok || !md.some((x) => x) || pending;
        const dv = draft(s, me);
        if (md.some((x) => x)) { quick.textContent = '되돌리기'; quick.onclick = () => { md = Z(); api.sfx('tick'); upd(); }; quick.disabled = false; }
        else if (dv.some((x) => x)) { quick.textContent = '추천 담기'; quick.onclick = () => { md = dv.slice(); api.sfx('chip'); upd(); }; quick.disabled = false; }
        else if (sellable()) { quick.textContent = '다 팔기'; quick.onclick = () => { for (let g = 0; g < NG; g++) if (trades(s, p, g)) md[g] = -s.cg[me][g]; api.sfx('tick'); upd(); }; quick.disabled = false; }
        else { quick.textContent = '추천 없음'; quick.disabled = true; }
      }
      for (const g of list) {
        const I = info[g];
        const stp = stepper(() => md[g], (v) => { md[g] = v; upd(); }, () => (I.tr ? -s.cg[me][g] : 0), () => {
          if (!I.tr) return 0;
          let hi = Math.max(0, md[g]);
          for (let k2 = 0; k2 < 99; k2++) { const save = md[g]; md[g] = hi + 1; const c = calc(); md[g] = save; if (!c.ok) break; hi++; }
          return hi;
        }, true);
        steps.push(stp);
        const hv = h('span', { class: 'hv' }), tip = h('span', { class: 'b' });
        hvEls[g] = hv; tipEls[g] = tip;
        const row = h('div', { class: 'tr-row' + (I.tr ? '' : ' na') },
          h('button', { class: 'rn', 'aria-label': GD[g].n + ' 시세 보기', onclick: () => priceSheet(g) },
            h('span', { class: 'a' }, ico(g, 16), GD[g].n, p === FEST && g === s.fg ? h('span', { style: { color: '#f07fb8', fontSize: '10px' }, text: '축제' }) : null), tip),
          hv,
          h('span', { class: 'px' }, I.tr ? h('span', { class: 'b', text: '살 ' + I.b }) : h('span', { class: 'b', text: '—' }), I.tr ? h('span', { class: 's', text: '팔 ' + I.sv }) : null),
          stp);
        rowEls[g] = row;
        rows.append(row);
      }
      go.onclick = () => { const d = md.slice(); if (!d.some((x) => x)) return; md = Z(); mdKey = ''; act({ t: 'mk', d }); };
      pan.append(rows, h('div', { class: 'tr-foot' }, sum, quick, go));
      upd();
    }
    function contractTab() {
      const s = st, me = s.t, loc = s.loc[me];
      const list = s.ct.map((c, i) => ({ c, i, here: loc === c[2], have: s.cg[me][c[0]] })).filter((x) => x.c[4] >= s.rd);
      list.sort((a, b) => (b.here && b.have >= b.c[1]) - (a.here && a.have >= a.c[1]) || b.have / b.c[1] - a.have / a.c[1]);
      list.forEach(({ c, i, here, have }) => {
        const [g, n, p, b, dl, u] = c, ok = here && have >= n;
        let cheap = -1; for (let q = 0; q < NP; q++) if (M[q][g] && (cheap < 0 || buyNow(s, q, g) < buyNow(s, cheap, g))) cheap = q;
        const left = dl - s.rd + 1;
        pan.append(h('div', { class: 'tr-ct' + (ok ? ' go' : '') },
          h('div', { class: 'tx' },
            h('div', { class: 't1' }, ico(g, 16), GD[g].n + ' ' + n + '개 → ' + PL[p].s, u ? h('span', { class: 'u', text: '긴급' }) : null),
            h('div', { class: 'pg' }, h('i', { style: { width: Math.min(100, 100 * have / n) + '%', background: GD[g].c } })),
            (have >= n ? '다 모았어요' : '보유 ' + have + '/' + n) + ' · ' + (left <= 1 ? '이번 라운드까지' : left + '라운드 남음') + (here ? ' · 여기!' : ' · ' + DIST[loc][p] + '칸') + (cheap >= 0 && have < n ? ' · ' + PL[cheap].s + '에서 싸요' : '')),
          h('span', { class: 'rw', text: '+' + b }),
          ok ? h('button', { class: 'btn primary', disabled: pending ? true : null, text: '납품', onclick: () => act({ t: 'ct', i }) }) : null));
      });
      pan.append(h('div', { class: 'tr-tip', text: '계약은 모두가 함께 노려요. 적힌 행성에서 먼저 납품한 선장이 보상을 받아요. 그 행성이 안 사는 물품도 계약으론 팔 수 있어요.' }));
    }
    function upEffect(u, l) {
      if (u === 0) return '화물칸 ' + HOLD[l] + ' → ' + HOLD[l + 1];
      if (u === 1) return '한 번에 ' + RANGE[l] + '칸 → ' + RANGE[l + 1] + '칸';
      return '해적에게 ' + Math.round(SHIELD[l] * 100) + '% → ' + Math.round(SHIELD[l + 1] * 100) + '% 뺏김';
    }
    function yardTab() {
      const s = st, me = s.t, p = s.loc[me];
      const rec = wantUp(s, me, 3, s.cr[me]);
      for (let u = 0; u < 3; u++) {
        const l = s.up[me][u], price = upPrice(s, p, u, l);
        const pips = h('span', { class: 'tr-pips', 'aria-label': l + '단계' }, [0, 1].map((k) => h('i', { class: k < l ? 'on' : '' })));
        pan.append(h('div', { class: 'tr-ct' + (u === rec ? ' go' : '') },
          ico(IC_UP[u], 22),
          h('div', { class: 'tx' }, h('div', { class: 't1' }, UPN[u], pips, u === rec ? h('span', { style: { color: '#7fe0a8', fontSize: '11px' }, text: '추천' }) : null),
            l >= 2 ? '최고 단계예요' : upEffect(u, l)),
          l < 2 ? h('span', { class: 'rw', text: String(price) }) : null,
          l < 2 ? h('button', { class: 'btn' + (u === rec ? ' primary' : ''), disabled: pending || price > s.cr[me] ? true : null, text: '올리기', onclick: () => upConfirm(u) }) : null));
      }
      pan.append(h('div', { class: 'tr-tip', text: (PL[p].yard === 2 ? '여기 포지 조선소는 20% 싸요. ' : '포지 조선소에 가면 20% 싸요. ') + (s.ev && s.ev.k === 'T' ? '박람회로 30% 더 할인 중! ' : '') + '업그레이드는 게임이 끝날 때 정가의 절반으로 점수에 들어가요.' }));
    }
    function upConfirm(u) {
      const s = st, me = s.t, l = s.up[me][u], price = upPrice(s, s.loc[me], u, l);
      sheet('info', h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, ico(IC_UP[u], 26), h('h2', { text: UPN[u] + ' ' + (l + 1) + '단계' })),
        h('div', { class: 'tr-sum' }, upEffect(u, l), h('br'), '크레딧 ', h('b', { text: String(s.cr[me]) }), ' → ', h('b', { style: { color: '#ff9d8a' }, text: String(s.cr[me] - price) }),
          h('br'), h('span', { class: 'muted', text: '끝날 때 ' + UPC[u][l] / 2 + ' 크레딧으로 쳐요 · ' + (s.R - s.rd) + '라운드 남음' })),
        h('div', { class: 'tr-btns' }, h('button', { class: 'btn', text: '취소', onclick: closeOv }),
          h('button', { class: 'btn primary', text: '업그레이드 −' + price, onclick: () => { closeOv(); act({ t: 'up', u }); } })));
      api.sfx('click');
    }
    function commTab() {
      const s = st, me = s.t;
      s.pm.filter((x) => x.f === me && x.g < x.n).forEach((x) => {
        const left = x.n - x.g, can = x.r === CRI ? s.cr[me] >= left : s.cg[me][x.r] >= left && hold(s, x.to) + left <= cap(s, x.to);
        pan.append(h('div', { class: 'tr-ct', style: { borderColor: 'rgba(227,174,69,.45)' } },
          h('div', { class: 'tx' }, h('div', { class: 't1' }, ico(x.r, 16), nm(x.to) + '에게 ' + rn(x.r) + ' ' + left), s.rd >= x.d ? '이번 차례가 끝나면 기록돼요' : '다음 차례까지 지키면 돼요'),
          h('button', { class: 'btn primary', disabled: !can || pending ? true : null, text: '지키기', onclick: () => act({ t: 'gf', to: x.to, r: x.r, n: left }) })));
      });
      if (s.of && s.of.f === me) {
        pan.append(h('div', { class: 'tr-ct' }, h('div', { class: 'tx' }, h('div', { class: 't1', text: nm(s.of.to) + '에게 제안 보냄 · 답 기다리는 중' }), '줄 것: ' + fmtV(s.of.g) + ' / 받을 것: ' + fmtV(s.of.w)),
          h('button', { class: 'btn', text: '취소', onclick: () => act({ t: 'cx' }) })));
      } else if (!s.of) {
        pan.append(h('button', { class: 'btn primary block', style: { minHeight: '50px' }, disabled: s.oc >= MAXOF || pending ? true : null,
          text: s.oc >= MAXOF ? '이번 턴 제안을 다 썼어요' : '거래 제안하기 (남은 ' + (MAXOF - s.oc) + '번)', onclick: () => composer({ mode: 'of' }) }));
      }
      pan.append(h('button', { class: 'btn block', text: '선물 보내기', onclick: () => composer({ mode: 'gf' }) }));
      s.pm.filter((x) => x.to === me).forEach((x) => pan.append(h('div', { class: 'tr-tip', text: nm(x.f) + '의 약속: ' + rn(x.r) + ' ' + x.n + (x.g ? ' (' + x.g + ' 받음)' : '') })));
      pan.append(h('div', { class: 'tr-tip', text: '다른 선장과는 어디서든 무선으로 거래해요. 제안에 붙인 약속은 강제가 아니에요. 지키면 "약속 지킴", 어기면 "약속 어김"이 모두에게 기록돼요.' }));
    }

    /* ---- offers: composer and incoming sheet ---- */
    function closeOv() { if (ovEl) { ovEl.remove(); ovEl = null; ovKind = ''; } }
    function sheet(kind, ...kids) {
      closeOv();
      const box = h('div', { class: 'sheet' }, ...kids);
      ovEl = h('div', { class: 'tr-ov' }, box); ovKind = kind;
      if (kind !== 'in') ovEl.addEventListener('click', (e) => { if (e.target === ovEl) closeOv(); });
      wrap.append(ovEl);
      return box;
    }
    function afterLine(s, me, gv, wv) { // my side if this goes through (gv: I give, wv: I get)
      const cr = s.cr[me] - gv[CRI] + wv[CRI], hl = hold(s, me) - goods(gv) + goods(wv);
      const el = h('div', null, '내 크레딧 ', h('b', { text: String(s.cr[me]) }), ' → ', h('b', { style: { color: cr > s.cr[me] ? '#7fe0a8' : cr < s.cr[me] ? '#ff9d8a' : '' }, text: String(cr) }),
        ' · 화물 ', h('b', { style: { color: hl > cap(s, me) ? '#ff9d8a' : '' }, text: hl + '/' + cap(s, me) }));
      return { el, ok: hl <= cap(s, me) && cr >= 0 };
    }
    function verdict(v, who) {
      const c = v >= 6 ? '#7fe0a8' : v >= 0 ? '#ffd27a' : '#ff9d8a';
      const word = who === 'them' ? (v >= 6 ? '받아줄 만해요' : v >= 0 ? '아슬아슬해요' : '거절할 것 같아요') : (v >= 6 ? '이득이에요' : v >= -2 ? '비슷해요' : '손해예요');
      return h('div', { class: 'tr-vd', style: { borderColor: c + '88' } }, h('span', null, (who === 'them' ? '상대 입장(시세·계약) · ' : '시세·계약으로 따지면 · ') + word), h('b', { style: { color: c }, text: sgn(v) }));
    }
    function composer(o) {
      const s = st;
      const me = o.mode === 'co' ? s.of.to : s.t;
      const others = []; for (let i = 0; i < s.n; i++) if (i !== me) others.push(i);
      const C = { to: o.to != null ? o.to : others[0], g: o.g ? o.g.slice() : Z1(), w: o.w ? o.w.slice() : Z1(), pm: null, pmOpen: false, gr: -1, gn: 1 };
      const box = sheet('cmp'); box.classList.add('cmp');
      function drawC() {
        box.innerHTML = '';
        const title = o.mode === 'co' ? '역제안' : o.mode === 'gf' ? '선물 보내기' : '거래 제안';
        box.append(h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap', flex: 'none' } }, h('h2', { text: title }), h('button', { class: 'iconbtn', text: '✕', 'aria-label': '닫기', style: { width: '44px', height: '44px' }, onclick: closeOv })));
        if (o.mode !== 'co') box.append(h('div', { class: 'tr-chips', style: { flex: 'none' } }, others.map((i) => h('button', { class: 'btn' + (C.to === i ? ' on' : ''), onclick: () => { C.to = i; C.w = Z1(); drawC(); } },
          h('span', { class: 'dot', style: { '--c': col(i) } }), nm(i), h('small', { text: PL[s.loc[i]].s })))));
        else box.append(h('div', { class: 'muted', style: { fontSize: '12.5px', flex: 'none' }, text: nm(C.to) + '에게 조건을 바꿔 다시 제안해요. 역제안은 한 번만, 약속은 못 붙여요.' }));
        const them = C.to;
        if (o.mode === 'gf') return drawGift(them);
        const sc = h('div', { class: 'tr-sc' });
        const stps = [];
        const addRows = (vec, who) => {
          let anyR = false;
          for (let g = 0; g <= CRI; g++) {
            const have = g === CRI ? s.cr[who] : s.cg[who][g];
            if (have <= 0 && !vec[g]) continue;
            anyR = true;
            const stp = stepper(() => vec[g], (v) => { vec[g] = v; upd(); }, () => 0, () => have);
            stps.push(stp);
            sc.append(h('div', { class: 'tr-cr' }, h('span', { class: 'rn' }, ico(g, 16), rn(g), h('small', { text: '/' + have })), stp));
          }
          if (!anyR) sc.append(h('div', { class: 'tr-tip', text: '없어요' }));
        };
        sc.append(h('div', { class: 'tr-sec', style: { color: '#ff9d8a' } }, '내가 줄 것', h('small', { text: '(내 보유)' })));
        addRows(C.g, me);
        sc.append(h('div', { class: 'tr-sec', style: { color: '#7fe0a8' } }, '내가 받을 것', h('small', { text: '(' + nm(them) + ' 보유)' })));
        addRows(C.w, them);
        if (o.mode === 'of') {
          if (!C.pmOpen && !C.pm) sc.append(h('button', { class: 'btn ghost block', text: '+ 약속 덧붙이기 (선택)', onclick: () => { C.pmOpen = true; drawC(); } }));
          else {
            sc.append(h('div', { class: 'tr-sec' }, '약속', h('small', { text: '다음 차례에 줄게요 · 강제 아님' })));
            const pmOpts = [CRI].concat(s.cg[me].map((x, g) => (x ? g : -1)).filter((g) => g >= 0));
            sc.append(h('div', { class: 'tr-chips' },
              h('button', { class: 'btn' + (!C.pm ? ' on' : ''), text: '없음', onclick: () => { C.pm = null; C.pmOpen = false; drawC(); } }),
              pmOpts.map((g) => h('button', { class: 'btn' + (C.pm && C.pm[0] === g ? ' on' : ''), 'aria-label': rn(g), onclick: () => { C.pm = [g, g === CRI ? 10 : 1]; drawC(); } }, ico(g, 16)))));
            if (C.pm) {
              const ps = stepper(() => C.pm[1], (v) => { C.pm[1] = v; upd(); }, () => 1, () => 60);
              stps.push(ps);
              sc.append(h('div', { class: 'tr-cr' }, h('span', { class: 'rn' }, ico(C.pm[0], 16), '다음 차례에 ' + rn(C.pm[0])), ps));
            }
          }
        }
        box.append(sc);
        const prev = h('div', { class: 'tr-sum', style: { flex: 'none' } });
        const vd = h('div', { style: { flex: 'none' } });
        const send = h('button', { class: 'btn primary' });
        const fairB = h('button', { class: 'btn', text: '값 맞추기', onclick: fair });
        function fair() {
          if (!goods(C.g) && !goods(C.w)) { api.toast('먼저 주고받을 물품을 골라요'); return; }
          const ev = dealVal(s, them, C.g.slice(0, NG).concat(0), C.w.slice(0, NG).concat(0), 2);
          const need = 6 - ev;
          if (need > 0) { C.g[CRI] = Math.min(s.cr[me], Math.ceil(need)); C.w[CRI] = 0; } else { C.w[CRI] = Math.min(s.cr[them], Math.floor(-need)); C.g[CRI] = 0; }
          api.sfx('chip'); drawC();
        }
        function upd() {
          stps.forEach((x) => x.upd());
          const a = afterLine(s, me, C.g, C.w);
          prev.innerHTML = '';
          prev.append(h('span', { class: 'muted', text: '수락되면 · ' }), a.el);
          vd.innerHTML = '';
          vd.append(verdict(Math.round(dealVal(s, them, C.g, C.w, 2)), 'them'));
          const empty = !C.g.some((x) => x) && !C.w.some((x) => x);
          send.disabled = empty || pending || !a.ok;
          send.textContent = o.mode === 'co' ? '역제안 보내기' : '보내기';
        }
        box.append(prev, vd, h('div', { class: 'tr-btns', style: { flex: 'none' } }, fairB, h('button', { class: 'btn', text: '취소', onclick: closeOv }), send));
        send.onclick = () => {
          const a = o.mode === 'co' ? { t: 'co', g: C.g.slice(), w: C.w.slice() } : { t: 'of', to: them, g: C.g.slice(), w: C.w.slice(), pm: C.pm ? C.pm.slice() : null };
          closeOv(); api.sfx('whoosh'); act(a, me); tab = 'cm';
        };
        upd();
      }
      function drawGift(them) {
        const opts = [];
        for (let g = 0; g <= CRI; g++) if ((g === CRI ? s.cr[me] : s.cg[me][g]) > 0) opts.push(g);
        if (C.gr < 0 || !opts.includes(C.gr)) C.gr = opts.length ? opts[0] : CRI;
        box.append(h('div', { class: 'tr-chips' }, opts.map((g) => h('button', { class: 'btn' + (C.gr === g ? ' on' : ''), onclick: () => { C.gr = g; C.gn = 1; drawC(); } }, ico(g, 16), rn(g)))));
        const maxG = () => (C.gr === CRI ? s.cr[me] : Math.min(s.cg[me][C.gr], cap(s, them) - hold(s, them)));
        const stp = stepper(() => C.gn, (v) => { C.gn = v; stp.upd(); }, () => 1, () => Math.max(1, maxG()));
        box.append(h('div', { class: 'tr-cr' }, h('span', { class: 'rn' }, ico(C.gr, 16), rn(C.gr), h('small', { text: '/' + (C.gr === CRI ? s.cr[me] : s.cg[me][C.gr]) })), stp));
        const pm = s.pm.find((x) => x.f === me && x.to === them && x.r === C.gr && x.g < x.n);
        box.append(h('div', { class: 'tr-tip', text: pm ? '이 선물은 ' + nm(them) + '에게 한 약속(' + rn(pm.r) + ' ' + (pm.n - pm.g) + ')에 들어가요.' : '선물은 대가 없이 그냥 주는 거예요.' }));
        box.append(h('div', { class: 'tr-btns' }, h('button', { class: 'btn', text: '취소', onclick: closeOv }),
          h('button', { class: 'btn primary', disabled: maxG() < 1 || pending ? true : null, text: nm(them) + '에게 보내기', onclick: () => { closeOv(); act({ t: 'gf', to: them, r: C.gr, n: Math.min(C.gn, maxG()) }); } })));
      }
      drawC();
    }
    function syncOffer() {
      const s = st;
      const want = s && s.of && s.ph !== 'e' && !anim && api.canAct(s.of.to) ? s.of.k : 0;
      if (ovKind === 'in' && (!want || ovEl.dataset.k !== String(want))) closeOv();
      if (!want || ovKind === 'in' || ovKind === 'cmp') return;
      const of = s.of, me = of.to;
      const gv = Math.round(dealVal(s, me, of.g, of.w, 2));
      const can = has(s, me, of.w), fits = hold(s, me) - goods(of.w) + goods(of.g) <= cap(s, me);
      const rp = s.rp[of.f];
      api.sfx('pop'); api.buzz([15, 40, 15]);
      const a = afterLine(s, me, of.w, of.g);
      sheet('in',
        h('span', { class: 'label', text: '교신 · ' + nm(me) + '에게 온 제안' }),
        h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, h('span', { class: 'dot', style: { '--c': col(of.f), width: '14px', height: '14px' } }),
          h('h2', { text: nm(of.f) + (of.c ? '의 역제안' : '의 제안') })),
        h('div', { class: 'tr-deal' },
          h('div', { style: { borderColor: 'rgba(127,224,168,.45)' } }, h('span', { class: 'hd', style: { color: '#7fe0a8' }, text: '내가 받는 것' }), gl(of.g)),
          h('div', { style: { borderColor: 'rgba(255,157,138,.45)' } }, h('span', { class: 'hd', style: { color: '#ff9d8a' }, text: '내가 주는 것' }), gl(of.w))),
        of.pm ? h('div', { class: 'tr-sum' }, '약속: 다음 차례에 ', h('span', { style: { fontWeight: 800, color: 'var(--brass)' }, text: rn(of.pm[0]) + ' ' + of.pm[1] }), ' 더 줄게요', h('br'),
          h('span', { class: 'muted', text: '강제 아님 · 이 선장 약속 기록: 지킴 ' + rp[0] + ' / 어김 ' + rp[1] })) : null,
        h('div', { class: 'tr-sum' }, h('span', { class: 'muted', text: '수락하면 · ' }), a.el,
          !can ? h('div', { style: { color: '#ff9d8a', marginTop: '2px' }, text: '줄 물건이 모자라요' }) : !fits ? h('div', { style: { color: '#ff9d8a', marginTop: '2px' }, text: '화물칸이 모자라요' }) : null),
        verdict(gv, 'me'),
        h('div', { class: 'tr-btns' },
          h('button', { class: 'btn', text: '거절', onclick: () => { closeOv(); act({ t: 're', ok: false }, me); } }),
          !of.c ? h('button', { class: 'btn', text: '역제안', onclick: () => { closeOv(); composer({ mode: 'co', to: of.f, g: of.w, w: of.g }); } }) : null,
          h('button', { class: 'btn primary', disabled: !can || !fits ? true : null, text: '수락', onclick: () => { closeOv(); act({ t: 're', ok: true }, me); } })));
      ovEl.dataset.k = String(want);
    }

    /* ---- info sheets ---- */
    function infoSheet(...kids) {
      const box = sheet('info', ...kids, h('button', { class: 'btn block', text: '닫기', onclick: closeOv }));
      api.sfx('click');
      return box;
    }
    const refSeat = () => { const s = view(); const m = mySeat(); return m >= 0 ? m : s ? s.t : 0; };
    function planetSheet(p) {
      const s = view(); if (!s) return;
      const me = refSeat(), P = PL[p];
      const tbl = h('div', { class: 'tr-pl', style: { gridTemplateColumns: 'minmax(0,1fr) 46px 46px 50px' } }, h('span', { class: 'h', text: '물품' }), h('span', { class: 'h', text: '살 때' }), h('span', { class: 'h', text: '팔 때' }), h('span', { class: 'h', text: '내 보유' }));
      const gs = []; for (let g = 0; g < NG; g++) if (trades(s, p, g)) gs.push(g);
      gs.sort((a, b) => mulOf(s, p, a) - mulOf(s, p, b));
      for (const g of gs) {
        const m = mulOf(s, p, g);
        tbl.append(h('span', { class: 'n' }, ico(g, 14), GD[g].n, m <= 0.7 ? h('small', { style: { color: '#ff9d8a' }, text: '쌈' }) : m >= 1.3 ? h('small', { style: { color: '#7fe0a8' }, text: '비쌈' }) : null),
          h('span', { style: { color: '#ff9d8a' }, text: String(buyNow(s, p, g)) }), h('span', { style: { color: '#7fe0a8' }, text: String(sellNow(s, p, g)) }), h('span', { class: s.cg[me][g] ? 'x' : 'x e', text: s.cg[me][g] ? String(s.cg[me][g]) : '' }));
      }
      const cts = s.ct.filter((c) => c[2] === p && c[4] >= s.rd);
      const here = []; for (let i = 0; i < s.n; i++) if (s.loc[i] === p) here.push(nm(i));
      infoSheet(h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, h('span', { class: 'dot', style: { '--c': P.c, width: '16px', height: '16px' } }), h('h2', { text: P.n })),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '12.5px', lineHeight: 1.45 }, text: P.d }),
        h('div', { class: 'tr-sum' }, '연료값 칸당 ', h('b', { text: fuelP(s, p).toFixed(1) }), ' · ' + (s.loc[me] === p ? '지금 여기 있어요' : '여기까지 ' + DIST[s.loc[me]][p] + '칸') + (P.yard ? ' · 조선소' + (P.yard === 2 ? '(20% 할인)' : '') : '') + (here.length ? ' · 정박: ' + here.join(', ') : '')),
        p === FEST ? h('div', { style: { fontSize: '12.5px', color: '#f07fb8' }, text: '이번 라운드 축제 물품: ' + GD[s.fg].n + ' (거의 두 배 값)' }) : null,
        s.ev && s.ev.p === p ? h('div', { style: { fontSize: '12.5px', color: '#ffd27a' }, text: evText(s.ev) }) : null,
        cts.length ? h('div', { style: { fontSize: '12.5px' }, text: '계약: ' + cts.map((c) => GD[c[0]].n + ' ' + c[1] + '개 → +' + c[3]).join(' · ') }) : null,
        tbl);
    }
    function priceSheet(g0) {
      const s = view(); if (!s) return;
      const me = refSeat();
      let g = g0 >= 0 ? g0 : (() => { const p = s.loc[me]; for (let x = 0; x < NG; x++) if (s.cg[me][x]) return x; for (let x = 0; x < NG; x++) if (M[p][x] && M[p][x] < 0.9) return x; return 0; })();
      const box = sheet('info');
      function drawP() {
        box.innerHTML = '';
        box.append(h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } }, h('h2', { text: '시세표' }), h('button', { class: 'iconbtn', text: '✕', 'aria-label': '닫기', style: { width: '44px', height: '44px' }, onclick: closeOv })));
        box.append(h('div', { class: 'tr-gsel' }, GD.map((G, x) => h('button', { class: x === g ? 'on' : '', 'aria-label': G.n, title: G.n, onclick: () => { g = x; api.sfx('tick'); drawP(); } }, ico(x, 20)))));
        const G = GD[g];
        box.append(h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', fontWeight: 700 } }, ico(g, 20), G.n,
          h('span', { class: 'tr-cat', style: { background: CATS[G.k].c }, text: CATS[G.k].n }), h('span', { class: 'muted', style: { fontWeight: 600, fontSize: '12px' }, text: '기본값 ' + G.b + (s.cg[me][g] ? ' · 내 보유 ' + s.cg[me][g] + ' (산 값 ' + basis(s, me, g) + ')' : '') })));
        const ps = []; for (let p = 0; p < NP; p++) if (trades(s, p, g)) ps.push(p);
        const sells = ps.map((p) => sellNow(s, p, g)), buys = ps.map((p) => buyNow(s, p, g));
        const hi = Math.max(...sells), lo = Math.min(...buys);
        const order = ps.map((p, i) => i).sort((a, b) => sells[b] - sells[a]);
        const tbl = h('div', { class: 'tr-pl' }, h('span', { class: 'h', text: '행성' }), h('span', { class: 'h', text: '거리' }), h('span', { class: 'h', text: '살 때' }), h('span', { class: 'h', text: '팔 때' }));
        for (const i of order) {
          const p = ps[i];
          tbl.append(h('span', { class: 'n' }, h('span', { class: 'dot', style: { '--c': PL[p].c, flex: 'none' } }), PL[p].s, p === FEST && g === s.fg ? h('small', { style: { color: '#f07fb8' }, text: '축제' }) : null),
            h('span', { class: 'x', text: s.loc[me] === p ? '여기' : DIST[s.loc[me]][p] + '칸' }),
            h('span', { class: buys[i] === lo ? 'lo' : '', text: String(buys[i]) }), h('span', { class: sells[i] === hi ? 'hi' : '', text: String(sells[i]) }));
        }
        box.append(tbl);
        const ct = s.ct.filter((c) => c[0] === g && c[4] >= s.rd);
        if (ct.length) box.append(h('div', { class: 'tr-tip', style: { color: '#ffd27a' }, text: '계약: ' + ct.map((c) => c[1] + '개 → ' + PL[c[2]].s + ' +' + c[3]).join(' · ') }));
        box.append(h('p', { class: 'muted', style: { margin: 0, fontSize: '11.5px' }, text: '빨간 테두리 = 가장 싸게 사는 곳, 초록 테두리 = 가장 비싸게 파는 곳. 한 개 사고팔 때마다 값이 한 칸씩 움직이고, 라운드가 바뀌면 원래 값 쪽으로 돌아와요.' }));
        box.append(h('button', { class: 'btn block', text: '닫기', onclick: closeOv }));
      }
      drawP(); api.sfx('click');
    }
    function playerSheet(i) {
      const s = view(); if (!s) return;
      const pms = s.pm.filter((x) => x.f === i || x.to === i);
      infoSheet(h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, h('span', { class: 'dot', style: { '--c': col(i), width: '16px', height: '16px' } }), h('h2', { text: nm(i) })),
        myCard(s, i),
        h('div', { class: 'tr-sum' }, '지금 끝나면 ≈ ', h('b', { text: String(Math.round(wealth(s, i))) }), ' (현금 ' + s.cr[i] + ' + 화물 ' + liquid(s, i) + ' + 배 ' + upVal(s, i) + ')', h('br'),
          '약속 기록: 지킴 ', h('b', { text: String(s.rp[i][0]) }), ' · 어김 ', h('b', { style: { color: s.rp[i][1] ? '#ff9d8a' : '' }, text: String(s.rp[i][1]) })),
        pms.length ? h('div', { class: 'tr-tip', text: pms.map((x) => nm(x.f) + ' → ' + nm(x.to) + ': ' + rn(x.r) + ' ' + x.n + (x.g ? ' (' + x.g + ' 받음)' : '')).join(' · ') }) : null);
    }
    function eventSheet() {
      const s = view(); if (!s || !s.ev) return;
      infoSheet(h('h2', { text: EVN[s.ev.k] }), h('p', { style: { margin: 0 }, text: evText(s.ev) }),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '12px' }, text: '이벤트는 이번 라운드 동안만 이어져요. 값 변화는 다음 라운드부터 서서히 돌아와요.' }));
    }
    function historySheet() {
      const box = h('div', { class: 'tr-hl' });
      hist.slice().reverse().forEach((t) => box.append(h('div', { class: t.startsWith('—') ? 'rd' : '', text: t })));
      if (!hist.length) box.append(h('div', { text: '아직 기록이 없어요' }));
      infoSheet(h('h2', { text: '항해 기록' }), box);
    }

    /* ---- events from the state ---- */
    function pushHist(next) {
      for (const e of next.lg) if (e[0] > lastLog) { const t = logText(e); if (t) hist.push(t); }
      if (hist.length > 120) hist.splice(0, hist.length - 120);
    }
    function feedback(next) {
      let ban = null;
      for (const e of next.lg) {
        if (e[0] <= lastLog) continue;
        const [, k, a, b] = e;
        const mine = (x) => x >= 0 && api.canAct(x);
        if (k === 'rd') ban = { t: (a >= next.R ? '마지막 라운드' : '라운드 ' + a), sub: '' };
        else if (k === 'ev' && ban) { ban.sub = evText({ k: a, p: b, g: e[4] }); ban.c = a === 'P' ? '#ff8a78' : '#ffd27a'; }
        else if (k === 'end') ban = { t: '항해 끝', sub: '' };
        if (k === 'ok' && (mine(a) || mine(b))) { api.toast('거래 성사! ' + nm(a) + ' ↔ ' + nm(b)); api.sfx('win'); api.buzz(25); }
        else if (k === 'no' && mine(a)) { api.toast(nm(b) + ' · 제안 거절'); api.sfx('lose'); }
        else if (k === 'co' && mine(b)) api.toast(nm(a) + '의 역제안이 왔어요');
        else if (k === 'fl' && (mine(a) || mine(b))) api.toast('거래 실패: 물건이나 화물칸이 모자라요');
        else if (k === 'pb') { api.toast(jo(nm(a), '이', '가') + ' 약속을 어겼어요!'); if (mine(b)) { api.sfx('lose'); api.buzz(40); } }
        else if (k === 'pk' && mine(b)) api.toast(jo(nm(a), '이', '가') + ' 약속을 지켰어요');
        else if (k === 'pi') { api.toast(!e[4] ? nm(a) + ' · 해적을 따돌렸어요' : nm(a) + ' · 해적에게 털렸어요!'); if (mine(a)) { api.sfx('hit'); api.buzz(40); } }
        else if (k === 'ct') { if (mine(a)) { api.sfx('win'); api.buzz(20); } else api.toast(nm(a) + ' · 계약 완료 +' + e[6]); }
        else if (k === 'up' && mine(a)) { api.sfx('pop'); api.buzz(20); }
        else if (k === 'mk' && mine(a)) api.sfx('chip');
        else if (k === 'ev') api.sfx('whoosh');
      }
      if (ban) addFx({ k: 'ban', t: ban.t, sub: ban.sub || (ban.t === '항해 끝' ? '' : '조용한 우주 · 이벤트 없음'), c: ban.c, dur: 2300 });
    }
    function startAnim(l, prev) {
      endAnim(anim, true);
      const hops = Math.max(0, l.path.length - 1);
      anim = { l, prev, t0: performance.now(), dur: hops ? 380 + 260 * hops : 260 };
      api.setBusy(true);
      api.sfx(hops ? 'whoosh' : 'click');
      anim.safety = setTimeout(() => endAnim(anim), (anim.dur + 1500) / sp());
    }
    function endAnim(a, silent) {
      if (!a || anim !== a) return;
      clearTimeout(a.safety);
      anim = null; api.setBusy(false);
      const dest = a.l.path[a.l.path.length - 1];
      if (a.l.path.length > 1 && !silent) { const c = ppos(dest); addFx({ k: 'ring', x: c.x, y: c.y, r0: pR() * 0.8, c: col(a.l.s), dur: 600 }); }
      if (a.l.pi) pirateFx(a.l, st || a.prev);
      if (!silent) render(true);
    }

    cv.onresize = () => { bgKey = ''; plKey = ''; };
    return {
      update(next, prev) {
        st = next;
        if (!prev) {
          endAnim(anim, true);
          if (!hist.length) for (const e of next.lg) { const t = logText(e); if (t) hist.push(t); }
          if (next.rd === 1 && next.k === 0 && next.ph === 'm' && next.ls <= 2) addFx({ k: 'ban', t: '출항!', sub: '싸게 사서 비싸게 팔아요 · ' + next.R + '라운드', dur: 2300 });
        } else if (prev !== next) { pushHist(next); feedback(next); }
        lastLog = next.ls;
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          if (l.k === 'mv') startAnim(l, prev);
          else fxFor(l, next, prev);
        }
        if (!prev || next.t !== prev.t || next.ph !== prev.ph) { sel = -1; if (next.ph === 't' && (!prev || prev.ph !== 't' || prev.t !== next.t)) tab = 'mk'; }
        pending = false; clearTimeout(pendT);
        if (ovKind === 'cmp' && (next.ph === 'e' || (prev && prev.t !== next.t && !(next.of && api.canAct(next.of.to))))) closeOv();
        render(true);
      },
      destroy() {
        stopLoop(); clearTimeout(pendT); if (anim) clearTimeout(anim.safety);
        cv.cv.removeEventListener('pointerdown', onMapDown);
        closeOv(); cv.destroy(); wrap.remove(); style.remove();
        api.setBusy(false);
      },
    };
  }

  const ICON = '<circle cx="16" cy="40" r="9" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="44" cy="14" r="6" fill="currentColor"/><path d="M22 34L38 18" stroke="currentColor" stroke-width="2" stroke-dasharray="3 3"/><path d="M30 40l12-12 5 5-12 12-7 2z" fill="currentColor"/><rect x="8" y="8" width="10" height="10" rx="2" fill="currentColor" opacity=".7"/><circle cx="46" cy="46" r="3" fill="currentColor"/>';

  L.register({
    id: 'trade', name: '우주 화물선 협상', tag: '우주 무역', cat: '보드', icon: ICON, tint: '#23345e',
    blurb: '행성 12곳을 오가며 물품 14가지를 싸게 사서 비싸게 팔아요. 계약·업그레이드·이벤트, 다른 선장과의 거래와 (지켜도 어겨도 되는) 약속까지! 가장 부자가 이겨요.',
    minPlayers: 2, maxPlayers: 5, defaultPlayers: 4, hidden: false, aiDelay: 600, aiDelayFor,
    options: [
      { id: 'turns', label: '라운드', choices: [{ v: 10, label: '10' }, { v: 12, label: '12' }, { v: 15, label: '15' }], def: 12 },
    ],
    quick: [
      '목표: 정해진 라운드가 끝날 때 가장 부자인 선장이 이겨요.',
      '내 차례: ① 행성으로 이동 → ② 사고팔기·계약 납품·업그레이드·거래 제안 → ③ [턴 끝].',
      '돈 버는 법: 싸게 파는 행성에서 사서 비싸게 사 주는 행성에 팔아요. [추천 항로]·[추천 담기]가 도와줘요.',
    ],
    tutorial: [
      { text: '지도에서 행성을 눌러 목적지를 골라요. 행성 옆 숫자가 이동비(크레딧)예요.', sel: '.tr-map' },
      { text: '추천 항로: 가면 얼마나 벌지 미리 계산해 줘요. 누르면 바로 선택돼요.', sel: '.tr-rts' },
      { text: '[출발]을 누르면 날아가요. 도착하면 시장이 열려요.', sel: '.tr-go' },
      { text: '시장에서는 [+]로 담고 [−]로 팔아요. [추천 담기]를 누르면 알아서 골라 주고, [거래 확정] 전에는 [되돌리기]로 취소돼요.', sel: '.tr-pan' },
      { text: '다 했으면 [턴 끝]. 위쪽 선장 카드를 누르면 다른 선장의 화물도 볼 수 있어요.', sel: '.tr-top' },
    ],
    rules: [
      { h: '목표', p: ['화물선 선장이 되어 행성 12곳을 오가며 물품을 사고팔아요. 정해진 라운드(10·12·15, 기본 12)가 끝날 때 가장 부자인 선장이 이겨요.',
        '모두 크레딧 160, 빈 화물칸 10칸으로 센트럴 허브에서 출발해요.'] },
      { h: '차례에 할 일', p: ['① 이동: 갈 행성을 골라 [출발]. 머무르면 공짜예요.',
        '② 거래: 시장에서 사고팔기, 계약 납품, 조선소 업그레이드, 다른 선장과 거래 제안을 원하는 만큼(순서 자유).',
        '③ [턴 끝]. 한 라운드 = 모두 한 번씩. 라운드마다 먼저 하는 선장이 한 칸씩 바뀌어요.',
        '화면 아래 "지금 할 일" 줄이 다음에 할 만한 일을 알려 주고, 버튼 한 번으로 해 줘요.'] },
      { h: '점수·승리', p: ['끝 점수 = 현금 + 실은 화물 + 배 업그레이드.',
        '화물은 그때 있는 행성 시세로 판 값으로 쳐요(그 행성이 안 사는 물품은 기본값의 절반). 그러니 마지막 차례엔 화물을 비싸게 사 주는 곳에 가 있어야 해요.',
        '업그레이드는 정가의 절반으로 쳐요. 점수가 같으면 공동 승리.'] },
      { h: '이동과 이동비', p: ['이동비 = 거리(칸) × 지금 있는 행성의 연료값. 템페스트·허브는 연료가 싸요. 지도 선 위 숫자가 칸 수, 행성 옆 동전 숫자가 이동비예요.',
        '한 번에 갈 수 있는 거리는 엔진에 따라 4·6·9칸. 더 멀면 두 번에 나눠 가요.',
        '돈이 모자라도 출발할 수 있어요. 모자란 만큼은 빚(마이너스 크레딧)이 되고, 빚이 있는 동안은 살 수 없어요(팔기는 돼요).',
        '[추천 항로]는 그 행성에 가서 추천대로 거래하면 배의 가치가 얼마나 늘지(다음 차례까지 내다본 값) 보여 줘요.'] },
      { h: '시장', p: ['물품 14가지 — 원자재: 얼음·광석·가스 / 식량: 곡물·과일·향신료 / 기술: 부품·칩·로봇 / 사치품: 보석·예술품·와인 / 위험물: 무기·우라늄.',
        '행성마다 다루는 물품이 달라요. 만드는 곳(생산지)은 싸고, 필요한 곳(수요지)은 비싸게 사요. 안 다루는 물품은 거기서 못 팔아요.',
        '[+]·[−]로 담으면 돈·화물칸 변화와 "산 값보다 얼마 이득"이 바로 보여요. [거래 확정]을 눌러야 이루어지고, 그 전엔 [되돌리기]로 없던 일이 돼요.',
        '[추천 담기]는 똑똑한 선장이라면 할 거래를 담아 줘요. 물품 이름을 누르면 그 물품의 행성별 시세가 나와요.',
        '많이 사면 값이 오르고 많이 팔면 내려가요(1개마다 한 칸). 라운드가 바뀌면 원래 값 쪽으로 돌아오고 조금씩 출렁여요.'] },
      { h: '계약', p: ['"칩 3개 → 포지 +210" 같은 주문이 4개 걸려 있어요. 적힌 행성에서 [납품]하면 보상! 보통 시장보다 많이 줘요.',
        '먼저 납품한 선장이 가져가요. 기한이 지나면 새 계약으로 바뀌어요. "긴급"은 기한이 짧은 대신 보상이 커요. 그 행성이 안 사는 물품도 계약으로는 팔 수 있어요.'] },
      { h: '배 업그레이드 (조선소)', p: ['허브와 포지(20% 할인)의 [조선소] 탭에서 해요. 각각 2단계까지.',
        '화물칸 10 → 15 → 20칸 / 엔진: 한 번에 4 → 6 → 9칸 / 방어막: 해적에게 뺏기는 양 50% → 25% → 0%.'] },
      { h: '특별한 행성', p: ['센트럴 허브: 위험물만 빼고 다 다뤄요(값은 보통). 조선소가 있고 해적이 못 와요.',
        '그림자 시장(블랙마켓): 무엇이든 사고팔아요. 살 땐 비싸지만 팔 때 덜 깎이고, 무기·우라늄을 아주 비싸게 사요.',
        '스컬 항구(해적 소굴): 무기·향신료가 싸요. 여기선 해적이 공격하지 않지만, 근처 행성에 해적이 자주 나타나요.',
        '카니발(축제 행성): 라운드마다 바뀌는 "축제 물품"을 거의 두 배 값에 사요(지도의 분홍 표시).',
        '아카데미아(연구소): 칩이 싸고 우라늄을 비싸게 사요. 템페스트: 연료가 가장 싸요.'] },
      { h: '이벤트 (라운드 시작 때 가끔)', p: ['해적 출몰: 그 행성에 들어가면 가장 비싼 화물을 절반 빼앗겨요(방어막이 줄여 줘요, 머무는 배는 안전).',
        '태양 폭풍: 이동비 1칸만큼 더. 연료 파동: 연료값 1.5배. 기술 박람회: 업그레이드 30% 할인.',
        '가격 폭등·대량 공급: 한 행성의 한 물품 값이 크게 오르거나 내려요. 전쟁 소문: 무기 값 상승. 흉년: 먹을거리 값 상승. 대축제: 카니발이 더 비싸게 사요.'] },
      { h: '선장끼리 거래와 약속', p: ['[교신] 탭에서 다른 선장에게 거래를 제안해요(어디서든 무선으로, 턴마다 2번까지). 줄 것·받을 것(물품·크레딧)을 고르고 보내요. [값 맞추기]는 상대가 받아줄 만한 크레딧으로 맞춰 줘요.',
        '받은 선장은 남의 차례여도 바로 수락·거절·역제안해요. 역제안에는 수락·거절만 할 수 있어요.',
        '제안에 "다음 차례에 크레딧 10" 같은 약속을 붙일 수 있어요. 강제가 아니에요! 지켰는지 어겼는지는 모두에게 기록돼요(이름 옆 ✗ = 어긴 횟수).'] },
      { h: '예시', p: ['1라운드: 허브에서 그린베일로 이동(1칸, 이동비 5) → 곡물 8개를 사요(개당 6~8, 살수록 조금씩 올라요) → [턴 끝].',
        '2라운드: 프로스트로 이동(2칸, 이동비 15) → 곡물 8개를 팔아요(개당 15에서 12까지). 이동비를 빼도 30쯤 벌었어요! 이어서 프로스트의 싼 얼음을 사서 템페스트로 가져가면 또 벌어요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 골라요. 쉬움은 시세를 대충 보고 가끔 손해를 봐요. 보통은 대체로 이득을 내고 계약을 노려요. 어려움은 값이 돌아오는 것·다른 선장과의 경쟁·두 차례 앞까지 계산해서 거의 항상 이득을 내고, 1등을 돕는 거래는 잘 안 받고, 계산해서 약속을 어기기도 해요.'] },
    ],
    init, actor, apply, ai, result, mount,
    _t: { quote, buyAt, sellAt, buyNow, sellNow, prOf, setPr, hold, cap, range, wealth, liquid, upVal, moveCost, upPrice, fuelP, DIST, PL, GD, M, NG, NP, HOLD,
      routeInfo, planDraft, planMove, planSells, planBuys, wantUp, dealVal, posVal, ctDeals, planOffer, respond, newContract, endTurn, pathOf, ICONS },
  });
})();
