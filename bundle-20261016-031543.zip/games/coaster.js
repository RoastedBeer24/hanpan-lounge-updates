/* 롤러코스터 설계 대회 — 옆에서 본 레일 조각을 이어 롤러코스터를 설계하고, 실제 물리(에너지 보존 + 마찰)로 시험 운행해 심사받는 대결.
   라운드마다 모두 같은 부지·주문서(예산 · 높이 제한 · 길이 · 요구 사항)를 받고 동시에 설계 → 모두 내면 한 대씩 시험 운행 + 심사.
   트랙 = 조각 글자 문자열 (C 체인 · U 오르막 · D 내리막 · M 낙하 · X 큰 낙하 · F 평지 · H 언덕 · O 루프 · S 나선 · T 커브 · B 부스터 · Z 브레이크).
   물리: 조각마다 미리 만든 표본(1m 안팎) 위에서 v² = v² − 2gΔy − 2·w·(μ·g·|G| + c·v²)·Δs (w = 그날 날씨 마찰 배율).
   G = v²κ/g + cos(기울기) (루프·나선은 꼭대기에서 G<0이면 실패), 커브는 경사(뱅크) 공식으로 옆 G.
   apply에서 끝까지 계산해 결과를 state.last에 담고, 화면은 같은 계산을 다시 돌려 애니메이션만 한다(결정적, Math.random 없음).
   State: { n, nm[], R, r, ph 'pick'|'b'|'v'|'end', ss[] (라운드별 부지), si, tl, tr[] (낸 트랙|null), rd[], sc[], rs[[]],
            solo, last {id, r, si, w, tr[], res[[f, tot, ex, sa, bu, br, t]]}, seq, t0 } */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= 물리 상수 ======================= */
  const GR = 9.81, MU = 0.02, CD = 0.0007, V0 = 2.5, VCH = 4, BOOST_A = 11, TRIM = 12;
  const ST_Y = 3, ST_LEN = 12, END_LEN = 14, CLEAR = 1, MAXP = 30;
  const BANK_R = 15, BANK = 50 * Math.PI / 180;
  const LIM = { gHi: 6.0, gLo: -2.0, lat: 2.6, gHiP: 4.5, gLoP: -1.0, latP: 1.6, vEnd: 15 };
  const q6 = (v) => Math.round(v * 1e6) / 1e6;

  /* ======================= 조각 ======================= */
  // fl: 0 보통, 1 체인, 2 부스터, 3 브레이크, 4 커브(뱅크)
  const PCS = {
    C: { n: '체인', nl: '체인 오르막', cost: 80, d: '체인이 열차를 천천히(시속 14km) 끌어 올려요. 속도가 없어도 올라가요. 높이 +12m', cmd: [['a', 40, 10, 1], ['s', 11.4, 1], ['a', -40, 10, 1]] },
    U: { n: '오르막', nl: '오르막', cost: 40, d: '체인 없는 오르막(+10m). 속도가 모자라면 멈춰요!', cmd: [['a', 35, 14], ['s', 4], ['a', -35, 30]] },
    D: { n: '내리막', nl: '내리막', cost: 40, d: '완만한 내리막(−10m).', cmd: [['a', -40, 14], ['s', 5], ['a', 40, 16]] },
    M: { n: '낙하', nl: '낙하', cost: 60, d: '가파른 낙하(−20m). 속도가 확 붙어요.', cmd: [['a', -55, 12], ['s', 8], ['a', 55, 20]] },
    X: { n: '큰 낙하', nl: '큰 낙하', cost: 90, d: '아주 큰 낙하(−35m). 짜릿함 최고, 바닥에서 G가 세져요.', cmd: [['a', -65, 12], ['s', 16], ['a', 65, 24]] },
    F: { n: '평지', nl: '평지', cost: 20, d: '평평한 길(8m). 길이를 맞출 때 써요.', cmd: [['s', 8]] },
    H: { n: '언덕', nl: '에어타임 언덕', cost: 70, d: '둥근 언덕(+6m). 빠르게 넘으면 몸이 붕 떠요(에어타임). 너무 빠르면 위험!', cmd: [['a', 35, 12], ['s', 3], ['a', -70, 14], ['s', 3], ['a', 35, 12]] },
    O: { n: '루프', nl: '루프', cost: 160, d: '한 바퀴 뒤집히는 원(높이 약 16m). 꼭대기 속도가 모자라면 실패!', loop: 1 },
    S: { n: '나선', nl: '나선(코르크스크루)', cost: 170, d: '비틀며 한 바퀴 뒤집혀요(높이 8m). 꼭대기 속도가 모자라면 실패!', cork: 1 },
    T: { n: '커브', nl: '커브(경사 U턴)', cost: 60, d: '기울어진 U턴(길이 47m). 너무 빠르면 옆으로 쏠려 위험!', curve: 1 },
    B: { n: '부스터', nl: '부스터', cost: 140, d: '바퀴가 열차를 확 밀어 줘요(속도↑). 체인 대신 써도 돼요.', cmd: [['s', 14, 2]] },
    Z: { n: '브레이크', nl: '브레이크', cost: 30, d: '시속 43km보다 빠르면 그만큼 줄여 줘요. 안전용.', cmd: [['s', 8, 3]] },
  };
  const CODES = 'CUDMXFHOSTBZ';
  const PAL = 'CUDMXFHOSTBZ'.split('');

  function mkT() { return { x: [], y: [], ds: [], dy: [], ca: [], k: [], fl: [], qx: [], qy: [], bk: [] }; }
  function push(T, x, y, ds, dy, ca, k, fl, qx, qy, bk) {
    T.x.push(q6(x)); T.y.push(q6(y)); T.ds.push(q6(ds)); T.dy.push(q6(dy)); T.ca.push(q6(ca)); T.k.push(q6(k)); T.fl.push(fl | 0);
    T.qx.push(q6(qx == null ? x : qx)); T.qy.push(q6(qy == null ? y : qy)); T.bk.push(bk ? 1 : 0);
  }
  function turtle(T, cmds, st) {
    for (const c of cmds) {
      if (c[0] === 's') {
        const n = Math.max(1, Math.ceil(c[1] / 1.0)), ds = c[1] / n;
        for (let i = 0; i < n; i++) {
          const nx = st.x + ds * Math.cos(st.th), ny = st.y + ds * Math.sin(st.th);
          push(T, nx, ny, ds, ny - st.y, Math.cos(st.th), 0, c[2]); st.x = nx; st.y = ny;
        }
      } else {
        const dth = c[1] * Math.PI / 180, R = c[2], n = Math.max(3, Math.ceil(Math.abs(dth) * R / 1.0));
        const st0 = dth / n, ds = R * Math.abs(st0), k = Math.sign(dth) / R;
        for (let i = 0; i < n; i++) {
          const tm = st.th + st0 / 2, ch = 2 * R * Math.sin(Math.abs(st0) / 2);
          const nx = st.x + ch * Math.cos(tm), ny = st.y + ch * Math.sin(tm);
          push(T, nx, ny, ds, ny - st.y, Math.cos(tm), k, c[3]); st.x = nx; st.y = ny; st.th += st0;
        }
        st.th = Math.round(st.th * 1e9) / 1e9;
      }
    }
  }
  function buildPiece(code) {
    const p = PCS[code], T = mkT(), st = { x: 0, y: 0, th: 0 };
    if (p.cmd) turtle(T, p.cmd, st);
    else if (p.loop) {
      turtle(T, [['s', 2]], st);
      const Rb = 16, Rt = 5.5, N = 96, dth = 2 * Math.PI / N;
      let maxX = st.x;
      for (let i = 0; i < N; i++) {
        const tm = (i + 0.5) * dth, kap = 1 / Rb + (1 / Rt - 1 / Rb) * (1 - Math.cos(tm)) / 2, ds = dth / kap;
        const nx = st.x + ds * Math.cos(tm), ny = st.y + ds * Math.sin(tm);
        push(T, nx, ny, ds, ny - st.y, Math.cos(tm), kap, 0, null, null, tm > Math.PI * 0.35 && tm < Math.PI * 1.65 ? 0 : 0);
        st.x = nx; st.y = ny; if (nx > maxX) maxX = nx;
      }
      // 끝을 정확히 바닥 높이로
      const yErr = st.y; st.y = 0; T.y[T.y.length - 1] = 0; T.dy[T.dy.length - 1] = q6(T.dy[T.dy.length - 1] - yErr);
      st.th = 0;
      turtle(T, [['s', Math.max(3, maxX + 3 - st.x)]], st);
    } else if (p.cork) {
      turtle(T, [['s', 3]], st);
      const r = 3.5, Lc = 30, N = 72, c = Lc / (2 * Math.PI), kap = r / (r * r + c * c);
      let px = st.x, py = 0, pz = 0;
      for (let i = 1; i <= N; i++) {
        const ph = i / N * 2 * Math.PI, pm = (i - 0.5) / N * 2 * Math.PI;
        const nx = 3 + Lc * i / N, ny = r * (1 - Math.cos(ph)), nz = r * Math.sin(ph);
        const ds = Math.hypot(nx - px, ny - py, nz - pz);
        push(T, nx, ny, ds, ny - py, Math.cos(pm), kap, 0, nx + 2.1 * nz, ny, Math.sin(pm) < 0);
        px = nx; py = ny; pz = nz;
      }
      st.x = px; st.y = 0; T.y[T.y.length - 1] = 0;
      turtle(T, [['s', 3]], st);
    } else if (p.curve) {
      const N = 32, len = Math.PI * BANK_R, a = 8, b = 3.2;
      for (let i = 1; i <= N; i++) {
        const t = i / N * Math.PI, tm = (i - 0.5) / N * Math.PI;
        push(T, 2 * a * i / N, 0, len / N, 0, 1, 0, 4, 2 * a * i / N, b * Math.sin(t) * Math.sin(t), Math.sin(tm) > 0.35);
      }
      st.x = 2 * a;
      // 커브 앞뒤로 조금 곧게
      const T2 = mkT(), s2 = { x: 0, y: 0, th: 0 };
      turtle(T2, [['s', 2]], s2);
      const out = mkT();
      for (const key of Object.keys(out)) out[key] = T2[key].slice();
      const off = 2;
      for (let i = 0; i < T.x.length; i++) push(out, T.x[i] + off, T.y[i], T.ds[i], T.dy[i], T.ca[i], T.k[i], T.fl[i], T.qx[i] + off, T.qy[i], T.bk[i]);
      const s3 = { x: off + 2 * a, y: 0, th: 0 };
      turtle(out, [['s', 2]], s3);
      return fin(out, code);
    }
    return fin(T, code);
  }
  function fin(T, code) {
    const n = T.x.length;
    let minY = 0, maxY = 0, minX = 0, maxX = 0;
    for (let i = 0; i < n; i++) { minY = Math.min(minY, T.y[i]); maxY = Math.max(maxY, T.y[i]); minX = Math.min(minX, T.x[i]); maxX = Math.max(maxX, T.x[i]); }
    T.n = n; T.DX = q6(T.x[n - 1]); T.DY = q6(T.y[n - 1]); T.minY = minY; T.maxY = maxY; T.maxX = maxX; T.code = code;
    T.len = T.ds.reduce((a, b) => a + b, 0);
    return T;
  }
  const TPL = {};
  for (const c of CODES) TPL[c] = buildPiece(c);

  /* ======================= 부지(주문서) ======================= */
  // g: 땅 높이 꺾은선 [[x,y]...] (트랙 x 기준, 0 = 출발 승강장 끝). req: [kind, value]
  const SITES = [
    { n: '바닷가 부두', e: '🌊', th: 0, L: 230, H: 40, B: 1100, w: [0.95, 1.15], req: [['loop', 1], ['vmax', 80]], d: '바다 위 나무 부두예요. 첫 루프로 손님을 놀라게 해 주세요.' },
    { n: '숲속 가족 공원', e: '🌲', th: 1, L: 260, H: 30, B: 900, w: [0.95, 1.15], req: [['inv0', 0], ['air', 1.0], ['gmax', 4.0]], d: '아이들도 타는 가족용이에요. 뒤집기 없이, 부드럽게, 몸이 붕 뜨는 재미를!' },
    { n: '사막 협곡', e: '🏜', th: 2, L: 250, H: 30, B: 1200, w: [0.9, 1.15], g: [[0, 0], [95, 0], [108, -24], [168, -24], [180, 0]], req: [['drop', 40]], d: '깊은 협곡이 있어요. 협곡 아래로 뛰어드는 큰 낙하가 필요해요.' },
    { n: '도시 옥상', e: '🏙', th: 3, L: 200, H: 50, B: 1400, w: [1.0, 1.2], req: [['inv', 2]], d: '빌딩 옥상의 좁은 부지예요. 높이 쌓아 뒤집기 2번!' },
    { n: '눈 덮인 산', e: '🏔', th: 4, L: 250, H: 50, B: 1300, w: [1.0, 1.3], g: [[0, 0], [100, 0], [122, 16], [152, 16], [172, 0]], req: [['vmax', 90]], d: '가운데에 눈 언덕이 있어요(높이 16m). 언덕을 넘고 시속 90km를 넘겨요.' },
    { n: '호숫가 공원', e: '🦆', th: 5, L: 280, H: 40, B: 1500, w: [0.95, 1.15], req: [['loop', 2], ['cork', 1]], d: '넓은 호숫가예요. 루프 2개와 나선 1개를 넣어 주세요.' },
    { n: '화산섬', e: '🌋', th: 6, L: 300, H: 60, B: 1900, w: [0.95, 1.2], req: [['vmax', 100], ['inv', 3]], d: '가장 큰 부지! 시속 100km와 뒤집기 3번에 도전해요.' },
    { n: '폭풍 해안', e: '⛈', th: 7, L: 260, H: 40, B: 1300, w: [0.9, 1.4], req: [['loop', 1], ['air', 1.0]], d: '날씨가 들쭉날쭉해요(마찰 ×0.9~1.4). 속도에 넉넉한 여유를 두세요.' },
    { n: '우주 기지', e: '🚀', th: 8, L: 260, H: 45, B: 1600, w: [0.95, 1.1], req: [['nochain', 0], ['inv', 2]], d: '체인 없이 부스터로만 달려요. 뒤집기 2번!' },
    { n: '놀이공원 개장식', e: '🎡', th: 9, L: 300, H: 45, B: 1600, w: [0.95, 1.2], req: [['time', 45], ['inv', 1]], d: '개장 기념 대표 놀이기구! 45초 넘게 오래 타고 뒤집기도 한 번.' },
    { n: '밤하늘 축제', e: '🏮', th: 10, L: 240, H: 40, B: 1200, w: [0.95, 1.15], req: [['air', 2.0], ['gmax', 4.5]], d: '불꽃놀이 아래에서 붕붕 뜨는 언덕 코스. 에어타임 2초!' },
  ];
  const SOLO = [1, 0, 2, 7, 3, 10, 4, 5, 8, 9, 6];   // 혼자 하기 순서(쉬운 것부터)
  function groundAt(site, x) {
    const g = site.g;
    if (!g) return 0;
    if (x <= g[0][0]) return g[0][1];
    for (let i = 1; i < g.length; i++) if (x <= g[i][0]) { const a = g[i - 1], b = g[i]; return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]); }
    return g[g.length - 1][1];
  }
  const REQ_TXT = {
    loop: (v) => '루프 ' + v + '개 이상', cork: (v) => '나선 ' + v + '개 이상', inv: (v) => '뒤집기 ' + v + '번 이상', inv0: () => '뒤집기 없이',
    air: (v) => '에어타임 ' + v.toFixed(1) + '초', gmax: (v) => '최대 ' + v.toFixed(1) + 'G 이하', vmax: (v) => '시속 ' + v + 'km 이상',
    drop: (v) => '한 번에 ' + v + 'm 낙하', time: (v) => '탑승 ' + v + '초 이상', nochain: () => '체인 없이',
  };
  function reqOk(rq, m) {
    const [k, v] = rq;
    switch (k) {
      case 'loop': return m.loops >= v;
      case 'cork': return m.corks >= v;
      case 'inv': return m.inv >= v;
      case 'inv0': return m.inv === 0;
      case 'air': return m.air >= v;
      case 'gmax': return m.gmax <= v;
      case 'vmax': return m.vmax * 3.6 >= v;
      case 'drop': return m.drop >= v;
      case 'time': return m.time >= v;
      case 'nochain': return m.chains === 0;
    }
    return false;
  }

  /* ======================= 배치 검사 ======================= */
  // 트랙 문자열 → {ok, err, ei(문제 조각), cost, x, y (끝), xs[] ys[] (조각 시작점)}
  function layout(code, site) {
    let x = 0, y = ST_Y, cost = 0;
    const xs = [], ys = [];
    if (code.length > MAXP) return { ok: false, err: '조각은 ' + MAXP + '개까지예요', ei: MAXP, cost, x, y, xs, ys };
    for (let i = 0; i < code.length; i++) {
      const c = code[i], T = TPL[c];
      if (!T) return { ok: false, err: '알 수 없는 조각', ei: i, cost, x, y, xs, ys };
      xs.push(x); ys.push(y);
      cost += PCS[c].cost;
      if (c === 'C' && site.req.some((r) => r[0] === 'nochain')) return { ok: false, err: '이 부지는 체인을 못 써요', ei: i, cost, x, y, xs, ys };
      if (y + T.maxY > site.H + 1e-6) return { ok: false, err: '높이 제한 ' + site.H + 'm를 넘어요', ei: i, cost, x, y, xs, ys };
      for (let j = 0; j < T.n; j++) {
        const ax = x + T.x[j], ay = y + T.y[j];
        if (ay < groundAt(site, ax) + CLEAR - 1e-6) return { ok: false, err: '땅에 부딪혀요', ei: i, cost, x, y, xs, ys };
      }
      x += T.DX; y += T.DY;
      if (x > site.L + 1e-6) return { ok: false, err: '부지 길이 ' + site.L + 'm를 넘어요', ei: i, cost, x, y, xs, ys };
    }
    // 도착 승강장 자리
    for (let ax = x; ax <= x + END_LEN; ax += 2) if (y < groundAt(site, ax) + CLEAR - 1e-6) return { ok: false, err: '도착 승강장이 땅에 묻혀요', ei: code.length - 1, cost, x, y, xs, ys };
    if (cost > site.B) return { ok: false, err: '예산을 넘어요', ei: code.length - 1, cost, x, y, xs, ys };
    return { ok: true, err: '', ei: -1, cost, x, y, xs, ys };
  }

  /* ======================= 시험 운행 (결정적) ======================= */
  // rec=true면 화면용 표본 배열(속도·시간·G)도 돌려줌
  const FAIL = ['', '멈췄어요', '꼭대기 속도 부족', 'G가 너무 세요', '몸이 튕겨 나가요', '커브에서 쏠려요'];
  function simulate(code, site, w, rec) {
    let v2 = V0 * V0, t = 0, s = 0;
    const m = { f: 0, fi: -1, fp: -1, vmax: V0, gmax: 1, gmin: 1, lat: 0, air: 0, drop: 0, sumDrop: 0, inv: 0, loops: 0, corks: 0, chains: 0, len: 0, time: 0, vend: 0, types: 0 };
    const R = rec ? { s: [], t: [], v: [], g: [], l: [], p: [], x: [], y: [], qx: [], qy: [], bk: [] } : null;
    let x0 = 0, y0 = ST_Y, peak = ST_Y, curDrop = 0, prevY = ST_Y;
    const seen = {};
    // 출발 승강장 (평지, 밀어 줌)
    if (R) { R.s.push(0); R.t.push(0); R.v.push(V0); R.g.push(1); R.l.push(0); R.p.push(-1); R.x.push(-ST_LEN); R.y.push(ST_Y); R.qx.push(-ST_LEN); R.qy.push(ST_Y); R.bk.push(0); }
    s = ST_LEN; t = ST_LEN / V0 * 0.6;
    if (R) { R.s.push(s); R.t.push(t); R.v.push(V0); R.g.push(1); R.l.push(0); R.p.push(-1); R.x.push(0); R.y.push(ST_Y); R.qx.push(0); R.qy.push(ST_Y); R.bk.push(0); }
    let done = false;
    for (let i = 0; i < code.length && !done; i++) {
      const c = code[i], T = TPL[c];
      if (!seen[c]) { seen[c] = 1; m.types++; }
      if (c === 'O') { m.loops++; m.inv++; } else if (c === 'S') { m.corks++; m.inv++; } else if (c === 'C') m.chains++;
      for (let j = 0; j < T.n; j++) {
        const ds = T.ds[j], fl = T.fl[j];
        let G, lat = 0;
        if (fl === 4) {
          const a = v2 / (GR * BANK_R);
          G = a * Math.sin(BANK) + Math.cos(BANK); lat = Math.abs(a * Math.cos(BANK) - Math.sin(BANK));
        } else G = v2 * T.k[j] / GR + T.ca[j];
        // 판정
        if (G > m.gmax) m.gmax = G;
        if (G < m.gmin) m.gmin = G;
        if (lat > m.lat) m.lat = lat;
        if (!m.f) {
          if (T.ca[j] < -0.2 && G < 0) { m.f = 2; }
          else if (G > LIM.gHi) m.f = 3;
          else if (G < LIM.gLo) m.f = 4;
          else if (lat > LIM.lat) m.f = 5;
          if (m.f) { m.fi = i; m.fp = j; }
        }
        let n2 = v2 - 2 * GR * T.dy[j] - 2 * w * (MU * GR * Math.abs(G) + CD * v2) * ds;
        if (fl === 1 && n2 < VCH * VCH) n2 = VCH * VCH;
        if (fl === 2) n2 += 2 * BOOST_A * ds;
        if (fl === 3 && n2 > TRIM * TRIM) n2 = TRIM * TRIM;
        if (n2 <= 0.04) {
          if (!m.f) { m.f = 1; m.fi = i; m.fp = j; }
          n2 = 0.04;
        }
        const va = Math.sqrt(v2), vb = Math.sqrt(n2), dt = ds / Math.max(0.25, (va + vb) / 2);
        if (G < 0.3 && T.ca[j] > 0.2 && fl !== 4) m.air += dt;
        t += dt; s += ds; v2 = n2;
        if (vb > m.vmax) m.vmax = vb;
        const ay = y0 + T.y[j];
        if (ay < prevY) { curDrop += prevY - ay; m.sumDrop += prevY - ay; if (curDrop > m.drop) m.drop = curDrop; }
        else if (ay > prevY + 0.05) { curDrop = 0; }
        prevY = ay; if (ay > peak) peak = ay;
        if (R) { R.s.push(s); R.t.push(t); R.v.push(vb); R.g.push(G); R.l.push(lat); R.p.push(i); R.x.push(x0 + T.x[j]); R.y.push(ay); R.qx.push(x0 + T.qx[j]); R.qy.push(y0 + T.qy[j]); R.bk.push(T.bk[j]); }
        if (m.f === 1 || m.f >= 2) { /* 실패 — 기록은 여기까지 */ }
        if (m.f) { done = true; break; }
      }
      x0 += T.DX; y0 += T.DY;
    }
    // 승강장 브레이크
    m.len = s; m.time = t; m.vend = Math.sqrt(v2);
    if (!m.f && R) {
      const ve = Math.sqrt(v2), stopT = Math.max(1.2, ve / 6);
      R.s.push(s + END_LEN); R.t.push(t + stopT); R.v.push(0); R.g.push(1); R.l.push(0); R.p.push(code.length); R.x.push(x0 + END_LEN); R.y.push(y0); R.qx.push(x0 + END_LEN); R.qy.push(y0); R.bk.push(0);
    }
    if (R) m.rec = R;
    m.ok = !m.f;
    return m;
  }

  /* ======================= 심사 ======================= */
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  function judge(code, site, m, cost) {
    if (m.f) return { tot: 0, ex: 0, sa: 0, bu: 0, br: 0, reqs: site.req.map((r) => reqOk(r, m)), pen: [] };
    const vk = m.vmax * 3.6;
    let ex = 0;
    ex += cl((vk - 30) / 75, 0, 1) * 10;
    ex += cl(m.sumDrop / 110, 0, 1) * 8;
    ex += Math.min(4, m.inv) * 2.5;
    ex += cl(m.air / 2.5, 0, 1) * 6;
    ex += cl((m.gmax - 2) / 2.2, 0, 1) * 3;
    ex += cl((m.types - 2) / 4, 0, 1) * 3;
    ex = Math.round(ex);
    const pen = [];
    let sa = 25;
    if (m.gmax > LIM.gHiP) { const p = Math.round((m.gmax - LIM.gHiP) * 10); sa -= p; pen.push(['G가 셌어요 ' + m.gmax.toFixed(1) + 'G', p]); }
    if (m.gmin < LIM.gLoP) { const p = Math.round((LIM.gLoP - m.gmin) * 12); sa -= p; pen.push(['몸이 많이 떴어요 ' + m.gmin.toFixed(1) + 'G', p]); }
    if (m.lat > LIM.latP) { const p = Math.round((m.lat - LIM.latP) * 15); sa -= p; pen.push(['옆으로 쏠렸어요 ' + m.lat.toFixed(1) + 'G', p]); }
    if (m.vend > LIM.vEnd) { const p = Math.round((m.vend - LIM.vEnd) * 1.2); sa -= p; pen.push(['도착이 빨라요 시속 ' + Math.round(m.vend * 3.6) + 'km', p]); }
    if (m.gmax < 2.2 && m.inv === 0 && m.air < 0.3) { sa -= 8; pen.push(['너무 심심해요', 8]); }
    const fun = cl(ex / 15, 0, 1);
    sa = Math.round(Math.max(0, sa) * fun);
    const left = Math.max(0, site.B - cost);
    const bu = Math.round(15 * cl(left / (0.5 * site.B), 0, 1) * fun);
    const reqs = site.req.map((r) => reqOk(r, m));
    const per = 20 / site.req.length;
    const br = Math.round(reqs.reduce((a, ok) => a + (ok ? per : 0), 0));
    return { tot: ex + sa + bu + br, ex, sa, bu, br, reqs, pen };
  }
  function evalTrack(code, site, w) {
    const lay = layout(code, site);
    const m = simulate(code, site, w, false);
    return { m, j: judge(code, site, m, lay.cost), lay };
  }

  /* ======================= 규칙 ======================= */
  const T_LIM = { 0: 0, 180: 180, 300: 300 };
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, R = n === 1 ? 1 : ([2, 3, 4].includes(opts.rounds) ? opts.rounds : 3);
    const tl = T_LIM[opts.time] != null ? T_LIM[opts.time] : 300;
    const ss = U.shuffle(SITES.map((_, i) => i)).slice(0, R);
    return {
      n, nm: players.map((p, i) => String(p.name || i + 1 + '번').slice(0, 10)), R, r: 0, ph: n === 1 ? 'pick' : 'b',
      ss, si: n === 1 ? -1 : ss[0], tl, solo: n === 1 ? 1 : 0,
      tr: Array(n).fill(null), rd: Array(n).fill(0), sc: Array(n).fill(0), rs: [], last: null, seq: 0, t0: Date.now(),
    };
  }
  function actor(s) {
    if (s.ph === 'end') return null;
    if (s.ph === 'pick') return [0];
    const a = []; for (let i = 0; i < s.n; i++) a.push(i); return a;
  }
  function finishRound(s) {
    const site = SITES[s.si];
    const w = Math.round((site.w[0] + Math.random() * (site.w[1] - site.w[0])) * 100) / 100;
    const res = [], rsc = [];
    for (let i = 0; i < s.n; i++) {
      const { m, j } = evalTrack(s.tr[i], site, w);
      res.push([m.f, j.tot, j.ex, j.sa, j.bu, j.br, Math.round(m.time * 10)]);
      rsc.push(j.tot); s.sc[i] += j.tot;
    }
    s.rs.push(rsc);
    s.last = { id: ++s.seq, r: s.r, si: s.si, w, tr: s.tr.slice(), res };
    s.ph = 'v'; s.tr = Array(s.n).fill(null); s.rd = Array(s.n).fill(0); s.t0 = Date.now();
  }
  function advance(s) {
    if (s.r + 1 >= s.R) { s.ph = 'end'; return; }
    s.r++; s.si = s.ss[s.r]; s.ph = 'b';
    s.tr = Array(s.n).fill(null); s.rd = Array(s.n).fill(0); s.t0 = Date.now();
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object' || seat < 0 || seat >= s.n) throw new Error('bad action');
    if (a.k === 'p') {
      if (s.ph !== 'pick' || seat !== 0) throw new Error('not now');
      const i = a.i | 0;
      if (!(i >= 0 && i < SITES.length)) throw new Error('bad site');
      s.si = i; s.ss = [i]; s.ph = 'b'; s.t0 = Date.now();
      return s;
    }
    if (a.k === 't') {
      if (s.ph !== 'b' || s.tr[seat] != null) throw new Error('not now');
      const c = String(a.c == null ? '' : a.c);
      if (c.length > MAXP || /[^CUDMXFHOSTBZ]/.test(c)) throw new Error('bad track');
      if (!layout(c, SITES[s.si]).ok) throw new Error('track breaks site rules');
      s.tr[seat] = c;
      if (s.tr.every((x) => x != null)) finishRound(s);
      return s;
    }
    if (a.k === 'n') {
      if (s.ph !== 'v' || s.rd[seat]) throw new Error('not now');
      s.rd[seat] = 1;
      if (s.rd.every((x) => x)) advance(s);
      return s;
    }
    throw new Error('unknown action');
  }
  const STARS = [45, 65, 80];
  function result(s) {
    if (!s || s.ph !== 'end') return null;
    const nm = (i) => s.nm[i] || i + 1 + '번';
    const site = SITES[s.ss[0]];
    if (s.solo) {
      const v = s.sc[0], st = STARS.filter((x) => v >= x).length;
      const f = s.last && s.last.res[0][0];
      return { winners: st ? [0] : [], title: st ? '별 ' + st + '개!' : f ? '시험 운행 실패' : '아쉬워요',
        text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + (site ? site.n : '') + ' · ' + v + '점\n별 기준 ' + STARS.join(' / ') + '점' };
    }
    const per = (i) => s.rs.map((r) => r[i]).join(' · ');
    const ord = s.sc.map((_, i) => i).sort((a, b) => s.sc[b] - s.sc[a] || a - b);
    const top = s.sc[ord[0]], winners = ord.filter((i) => s.sc[i] === top);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승',
      text: ord.map((i) => (s.sc.filter((v) => v > s.sc[i]).length + 1) + '위  ' + nm(i) + '  ' + s.sc[i] + '점  (' + per(i) + ')').join('\n') };
  }

  /* ======================= AI ======================= */
  // 무작위로 여러 개 지어 보고(+어려움은 다듬기) 가장 점수가 좋은 설계를 고름.
  const AIP = {
    1: { tries: 16, climb: 0, wEval: 'lo', noise: 12, reqCare: 0.4 },
    2: { tries: 60, climb: 80, wEval: 'mid', noise: 5, reqCare: 0.85 },
    3: { tries: 220, climb: 1200, wEval: 'both', noise: 0, reqCare: 1 },
  };
  const WEIGHTS = { C: 0, U: 4, D: 6, M: 6, X: 5, F: 2, H: 8, O: 6, S: 5, T: 4, B: 3, Z: 2 };
  function genTrack(site, rnd) {
    const noChain = site.req.some((r) => r[0] === 'nochain');
    let code = '';
    const tryAdd = (c) => { const n = code + c; if (layout(n, site).ok) { code = n; return true; } return false; };
    if (noChain) { tryAdd('B'); if (rnd() < 0.7) tryAdd('B'); }
    const target = site.H * (0.55 + rnd() * 0.45);
    let guard = 0;
    while (guard++ < 8) {
      const lay = layout(code, site);
      if (lay.y + 12 > target) break;
      if (!tryAdd(noChain ? 'U' : 'C')) break;
    }
    const firsts = ['X', 'M', 'X', 'M', 'D'];
    for (let k = 0; k < 4; k++) if (tryAdd(firsts[Math.floor(rnd() * firsts.length)])) break;
    const pool = [];
    for (const c of CODES) for (let k = 0; k < WEIGHTS[c]; k++) pool.push(c);
    let fails = 0;
    while (fails < 12 && code.length < MAXP) {
      let c = pool[Math.floor(rnd() * pool.length)];
      if (c === 'C' && !noChain && rnd() < 0.5) c = 'C';
      if (!tryAdd(c)) fails++;
      if (rnd() < 0.03) break;
    }
    return code;
  }
  function mutate(code, site, rnd) {
    const a = code.split('');
    const r = rnd(), i = Math.floor(rnd() * (a.length + 1));
    const pc = PAL[Math.floor(rnd() * PAL.length)];
    if (r < 0.3 && a.length) a[Math.min(i, a.length - 1)] = pc;
    else if (r < 0.6 && a.length < MAXP) a.splice(i, 0, pc);
    else if (r < 0.8 && a.length > 2) { const j = Math.min(i, a.length - 2); const t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
    else if (a.length > 1) a.splice(Math.min(i, a.length - 1), 1);
    const n = a.join('');
    return layout(n, site).ok ? n : null;
  }
  function aiScore(code, site, P) {
    const lay = layout(code, site);
    if (!lay.ok) return -1;
    const ws = P.wEval === 'both' ? [site.w[0], site.w[1]] : P.wEval === 'mid' ? [(site.w[0] + site.w[1]) / 2] : [site.w[0]];
    let worst = 1e9;
    for (const w of ws) {
      const m = simulate(code, site, w, false);
      if (m.f) return -1;
      const j = judge(code, site, m, lay.cost);
      const sc = j.ex + j.sa + j.bu + j.br * P.reqCare;
      if (sc < worst) worst = sc;
    }
    return worst;
  }
  function aiBuild(site, lv, rnd) {
    const P = AIP[lv] || AIP[2];
    let best = '', bestS = -1;
    const cands = [];
    for (let k = 0; k < P.tries; k++) {
      const c = genTrack(site, rnd), sc = aiScore(c, site, P);
      if (sc >= 0) cands.push([sc + (rnd() * 2 - 1) * P.noise, c, sc]);
      if (sc > bestS) { bestS = sc; best = c; }
    }
    if (P.noise && cands.length) { cands.sort((a, b) => b[0] - a[0]); best = cands[0][1]; bestS = cands[0][2]; }
    for (let k = 0; k < P.climb; k++) {
      const n = mutate(best, site, rnd);
      if (!n) continue;
      const sc = aiScore(n, site, P);
      if (sc > bestS) { bestS = sc; best = n; }
    }
    if (bestS < 0 && !best) best = '';
    return best;
  }
  function aiFrac(s, seat, lv) {
    let h = (s.seq * 7919 + s.r * 104729 + seat * 31337 + (s.si + 1) * 977) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 0x5bd1e995) >>> 0;
    const u = (h % 1000) / 1000;
    return lv >= 3 ? 0.35 + 0.2 * u : lv <= 1 ? 0.65 + 0.25 * u : 0.5 + 0.2 * u;
  }
  function animSecs(t) { return Math.max(6, Math.min(13, t / 3.2)); }
  function revealMs(last) { let ms = 2500; last.res.forEach((r) => { ms += (0.9 + (r[0] ? 8 : animSecs(r[6] / 10)) + 3.4) * 1000; }); return ms; }
  function aiDelayFor(s, seat, lv) {
    const sp = (L.debug && L.debug.speed) || 1;
    const el = Math.max(0, Date.now() - (s.t0 || 0)) * sp;
    if (s.ph === 'pick') return 1200;
    if (s.ph === 'b') {
      if (s.tr[seat] != null) return -1;
      const base = s.tl ? s.tl : 75;
      return Math.max(300, aiFrac(s, seat, lv || 2) * Math.min(base, 75) * 1000 - el);
    }
    if (s.ph === 'v') { if (s.rd[seat] || !s.last) return -1; return Math.max(300, revealMs(s.last) - el); }
    return -1;
  }
  function ai(s, seat, lv) {
    if (s.ph === 'pick') return seat === 0 ? { k: 'p', i: SOLO[Math.floor(Math.random() * SOLO.length)] } : null;
    if (s.ph === 'v') return s.rd[seat] ? null : { k: 'n' };
    if (s.ph !== 'b' || s.tr[seat] != null) return null;
    return { k: 't', c: aiBuild(SITES[s.si], lv || 2, Math.random) };
  }

  /* ======================= 화면 도구 ======================= */
  const FONT = '"IBM Plex Sans KR", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif';
  const DISP = '"Black Han Sans", ' + FONT;
  const MONO = '"IBM Plex Mono", ui-monospace, Menlo, monospace';
  const EMO = '"Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
  const THEMES = [
    { sky: ['#2a2046', '#7d4a62', '#d9825f'], gr: '#1d4f6e', top: '#7fc6e0', deco: 'pier' },
    { sky: ['#16202e', '#24394a', '#3f6150'], gr: '#2a4628', top: '#5a8a46', deco: 'trees' },
    { sky: ['#2e1c3a', '#7a3f45', '#e08a52'], gr: '#7e4430', top: '#c47a4a', deco: 'mesa' },
    { sky: ['#0f1430', '#242a5a', '#4a3f7a'], gr: '#2a2a38', top: '#62627a', deco: 'city' },
    { sky: ['#16223e', '#3a5582', '#8aa6cc'], gr: '#b9c8de', top: '#ffffff', deco: 'peaks' },
    { sky: ['#1e2a48', '#5a5a7a', '#e8a070'], gr: '#2c5436', top: '#5c9a50', deco: 'lake' },
    { sky: ['#1a0a10', '#4a1a1a', '#a83a20'], gr: '#2e2220', top: '#6a4030', deco: 'volcano' },
    { sky: ['#11151e', '#262e3c', '#46505e'], gr: '#363a32', top: '#68705a', deco: 'rain' },
    { sky: ['#03040c', '#0e0e2a', '#241a4a'], gr: '#55556a', top: '#9a9aac', deco: 'space' },
    { sky: ['#22123a', '#5a2a5a', '#e0708a'], gr: '#2c4630', top: '#56864a', deco: 'wheel' },
    { sky: ['#070a22', '#151a44', '#2a2a5e'], gr: '#20301c', top: '#46663a', deco: 'lanterns' },
  ];
  // 속도 색 (km/h): 느림 파랑 → 빠름 빨강
  const SPC = ['#4f8cff', '#4fb4ff', '#4fd8c8', '#7fe08a', '#d8e05a', '#ffc04a', '#ff8a3a', '#ff4a4a'];
  const spB = (v) => Math.max(0, Math.min(7, Math.floor(v * 3.6 / 15)));
  const minGround = (site) => (site.g ? Math.min(0, ...site.g.map((p) => p[1])) : 0);
  const kmh = (v) => Math.round(v * 3.6);
  const josa = (w, a, b) => { const c = w.charCodeAt(w.length - 1); return w + (c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b); };

  function shape(code) {
    const S = { px: [], py: [], qx: [], qy: [], bk: [], pi: [], pj: [], st: [], endX: 0, endY: ST_Y };
    let x0 = 0, y0 = ST_Y;
    for (let i = 0; i < code.length; i++) {
      const T = TPL[code[i]]; S.st.push(S.px.length);
      for (let j = 0; j < T.n; j++) { S.px.push(x0 + T.x[j]); S.py.push(y0 + T.y[j]); S.qx.push(x0 + T.qx[j]); S.qy.push(y0 + T.qy[j]); S.bk.push(T.bk[j]); S.pi.push(i); S.pj.push(j); }
      x0 += T.DX; y0 += T.DY;
    }
    S.endX = x0; S.endY = y0; S.st.push(S.px.length);
    return S;
  }
  // 설계 미리보기 / 시험 운행 데이터 (그리기용 Path2D 포함)
  function preview(code, site, w) {
    const sh = shape(code), lay = layout(code, site);
    const m = simulate(code, site, w, true), j = judge(code, site, m, lay.cost);
    const N = sh.px.length, rec = m.rec;
    const v = new Array(N), gg = new Array(N);
    for (let k = 0; k < N; k++) { const r = k + 2; v[k] = r < rec.v.length && rec.p[r] < code.length ? rec.v[r] : -1; gg[k] = r < rec.g.length ? rec.g[r] : 1; }
    const front = [], back = [];
    for (let b = 0; b <= 8; b++) { front.push(new Path2D()); back.push(new Path2D()); }
    const base = new Path2D(), sup = new Path2D();
    let lx = 0, ly = ST_Y, lastSup = -99;
    front[spB(V0)].moveTo(-ST_LEN, ST_Y); front[spB(V0)].lineTo(0, ST_Y); base.moveTo(-ST_LEN, ST_Y); base.lineTo(0, ST_Y);
    for (let k = 0; k < N; k++) {
      const b = v[k] < 0 ? 8 : spB(v[k]), x = sh.qx[k], y = sh.qy[k];
      const P = sh.bk[k] ? back[b] : front[b];
      P.moveTo(lx, ly); P.lineTo(x, y);
      if (!sh.bk[k]) { base.moveTo(lx, ly); base.lineTo(x, y); }
      const T = TPL[code[sh.pi[k]]], jj = sh.pj[k];
      const plain = T.k[jj] === 0 && T.fl[jj] !== 4 && T.ca[jj] > 0.2;
      if ((plain || T.fl[jj] === 4 && !sh.bk[k]) && sh.px[k] - lastSup >= 4) {
        const g = groundAt(site, sh.px[k]);
        if (y - g > 1.2) { sup.moveTo(x, y - 0.4); sup.lineTo(x, g); }
        lastSup = sh.px[k];
      }
      lx = x; ly = y;
    }
    const eb = m.f ? 8 : 0;
    if (code.length) { front[eb].moveTo(sh.endX, sh.endY); front[eb].lineTo(sh.endX + END_LEN, sh.endY); base.moveTo(sh.endX, sh.endY); base.lineTo(sh.endX + END_LEN, sh.endY); }
    for (let x = -ST_LEN + 2; x <= 0; x += 4) { sup.moveTo(x, ST_Y); sup.lineTo(x, groundAt(site, x)); }
    if (code.length) for (let x = sh.endX + 2; x <= sh.endX + END_LEN; x += 4) { const g = groundAt(site, x); if (sh.endY - g > 1) { sup.moveTo(x, sh.endY); sup.lineTo(x, g); } }
    // 경고 자리(조각마다 가장 나쁜 곳 하나)
    const warn = [];
    for (let i = 0; i < code.length; i++) {
      let wk = -1, wv = 0, wt = '';
      for (let k = sh.st[i]; k < sh.st[i + 1]; k++) {
        const r = k + 2; if (r >= rec.v.length) break;
        const G = rec.g[r], la = rec.l[r];
        let sv = 0, t = '';
        if (G > LIM.gHiP) { sv = G - LIM.gHiP; t = G.toFixed(1) + 'G'; }
        if (G < LIM.gLoP && LIM.gLoP - G > sv) { sv = LIM.gLoP - G; t = G.toFixed(1) + 'G'; }
        if (la > LIM.latP && la - LIM.latP > sv) { sv = la - LIM.latP; t = '옆 ' + la.toFixed(1) + 'G'; }
        if (sv > wv) { wv = sv; wk = k; wt = t; }
      }
      if (wk >= 0) warn.push({ k: wk, t: wt });
    }
    const fk = m.f ? Math.max(0, Math.min(N - 1, rec.v.length - 3)) : -1;
    return { code, site, w, sh, lay, m, j, v, gg, front, back, base, sup, warn, fk };
  }
  function terrainPath(site) {
    const P = new Path2D(), T = new Path2D();
    const x0 = -ST_LEN - 60, x1 = site.L + END_LEN + 80, bot = minGround(site) - 80;
    const pts = [[x0, groundAt(site, x0)]];
    if (site.g) site.g.forEach((p) => pts.push(p));
    pts.push([x1, groundAt(site, x1)]);
    P.moveTo(x0, bot); pts.forEach((p) => P.lineTo(p[0], p[1])); P.lineTo(x1, bot); P.closePath();
    T.moveTo(pts[0][0], pts[0][1]); pts.forEach((p) => T.lineTo(p[0], p[1]));
    return { P, T };
  }

  /* ======================= 소리 ======================= */
  const Snd = {
    ac: null, nb: null,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    tone(f, d, type, vol, f2, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
        o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.1, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + d + 0.03);
      } catch (e) {}
    },
    noise(d, type, f0, f1, vol, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        if (!this.nb) { const n = ac.sampleRate, b = ac.createBuffer(1, n, ac.sampleRate), x = b.getChannelData(0); for (let i = 0; i < n; i++) x[i] = Math.random() * 2 - 1; this.nb = b; }
        const t = ac.currentTime + (delay || 0), src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.nb; f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + d); f.Q.value = 0.9;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + d + 0.05);
      } catch (e) {}
    },
    clack() { this.noise(0.04, 'bandpass', 1800, 1200, 0.06); this.tone(320, 0.03, 'square', 0.02); },
    place() { this.tone(260, 0.08, 'triangle', 0.09, 180); this.noise(0.06, 'lowpass', 1600, 400, 0.08); },
    nope() { this.tone(200, 0.16, 'sawtooth', 0.05, 140); },
    tap() { this.tone(1100, 0.04, 'triangle', 0.05); },
    whoosh() { this.noise(0.9, 'bandpass', 500, 2400, 0.12); },
    scream() { const b = 900 + Math.random() * 300; this.tone(b, 0.5, 'sawtooth', 0.025, b * 1.35); this.tone(b * 1.26, 0.45, 'triangle', 0.03, b * 1.6, 0.05); },
    wow() { this.tone(500, 0.35, 'triangle', 0.04, 820); },
    boost() { this.tone(180, 0.5, 'sawtooth', 0.05, 900); this.noise(0.5, 'highpass', 800, 3000, 0.06); },
    brake() { this.noise(0.6, 'highpass', 3000, 1500, 0.07); },
    crash() { this.noise(0.7, 'lowpass', 2000, 120, 0.22); this.tone(120, 0.5, 'square', 0.06, 50); },
    ding() { this.tone(1318, 0.18, 'sine', 0.07); this.tone(1760, 0.22, 'sine', 0.06, 0, 0.07); },
    bell() { [1568, 2093, 1568].forEach((f, i) => this.tone(f, 0.35, 'sine', 0.06, 0, i * 0.12)); },
    done() { [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.18, 'triangle', 0.07, 0, i * 0.06)); },
    tick() { this.tone(1500, 0.05, 'square', 0.03); },
    fanfare() { [523, 659, 784, 1046, 784, 1046].forEach((f, i) => this.tone(f, 0.22, 'triangle', 0.08, 0, i * 0.09)); },
  };

  const CSS = `
.cs-brief{position:absolute;left:8px;right:8px;top:6px;z-index:3;background:rgba(30,23,40,.93);border:1px solid var(--line);border-radius:14px;padding:6px 10px 7px;display:flex;flex-direction:column;gap:4px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.35)}
.cs-b1{display:flex;align-items:center;gap:8px;min-width:0}
.cs-b1 .nm{font:400 18px var(--f-display);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.cs-b1 .rd{font:600 12px var(--f-body);color:var(--muted);white-space:nowrap}
.cs-b1 .tm{margin-left:auto;font:600 15px var(--f-mono);color:var(--brass);white-space:nowrap}
.cs-b1 .tm.low{color:var(--coral)}
.cs-b1 .more{font:600 11px var(--f-body);color:var(--muted);border:1px solid var(--line);border-radius:8px;padding:1px 6px;white-space:nowrap}
.cs-reqs{display:flex;flex-wrap:wrap;gap:4px}
.cs-rq{font:600 11.5px var(--f-body);padding:2px 8px;border-radius:999px;background:var(--surface-2);color:var(--muted);border:1px solid var(--line);white-space:nowrap}
.cs-rq.ok{background:#1f4a35;color:#c4f2d4;border-color:#2f7a52}
.cs-rq.lim{background:transparent}
.cs-bot{position:absolute;left:0;right:0;bottom:0;z-index:3;padding:6px 6px 7px;display:flex;flex-direction:column;gap:5px;background:linear-gradient(rgba(23,19,31,.0),rgba(23,19,31,.94) 10px)}
.cs-stat{display:flex;flex-direction:column;gap:2px;padding:0 4px}
.cs-st1{display:flex;align-items:center;gap:7px;font:600 12.5px var(--f-body);min-width:0}
.cs-bud{flex:0 0 auto;font-family:var(--f-mono);font-size:12px}
.cs-bud.over{color:var(--coral)}
.cs-budbar{flex:0 0 52px;height:7px;border-radius:4px;background:#3a3048;overflow:hidden}
.cs-budbar i{display:block;height:100%;background:var(--brass);transition:width .2s}
.cs-run{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:right}
.cs-run.ok{color:#8fe3b0}.cs-run.bad{color:#ff8a78}.cs-run.warn{color:#ffc46a}
.cs-st2{font:500 11.5px var(--f-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cs-st2 b{color:var(--ink);font-weight:600}
.cs-pal{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:4px}
.cs-pc{appearance:none;height:50px;border-radius:10px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;padding:1px 0;font:600 11px/1.15 var(--f-body);cursor:pointer;touch-action:manipulation;min-width:0;white-space:nowrap;user-select:none;-webkit-user-select:none}
.cs-pc canvas{width:38px;height:17px;pointer-events:none}
.cs-pc .c{font:500 9.5px var(--f-mono);color:var(--muted)}
.cs-pc.no{opacity:.36}
.cs-pc.inv{box-shadow:inset 0 -2px 0 #b07ad8}
.cs-pc:active{transform:scale(.94)}
.cs-act{display:flex;gap:5px}
.cs-act .btn{min-height:46px;padding:0 4px;font-size:15px}
.cs-undo,.cs-del,.cs-fit{flex:0 0 50px;font-size:19px!important}
.cs-del:disabled,.cs-undo:disabled{opacity:.35}
.cs-fit.on{background:#43351f;border-color:var(--brass)}
.cs-done{flex:1 1 auto;min-width:0}
.cs-done.armed{background:var(--coral);border-color:var(--coral);animation:csPulse .7s ease-in-out infinite}
@keyframes csPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.04)}}
.cs-hid{display:none!important}
.cs-rev{position:absolute;left:0;right:0;bottom:0;z-index:3;display:flex;gap:8px;align-items:center;padding:8px 10px 10px;background:linear-gradient(rgba(23,19,31,0),rgba(23,19,31,.94) 14px)}
.cs-rev .btn{flex:1;min-height:50px;font-size:16px}
.cs-rev .muted{flex:1;text-align:center;font-size:14px;min-height:44px;display:flex;align-items:center;justify-content:center}
.cs-hand,.cs-pick{position:absolute;inset:0;z-index:12;background:radial-gradient(circle at 50% 35%,#3a2440,#140e18 72%)}
.cs-hand{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:24px}
.cs-hand .big{font-family:var(--f-display);font-size:30px}
.cs-hand .btn{min-width:200px;min-height:52px;font-size:17px}
.cs-pick{overflow-y:auto;padding:12px 12px 24px;-webkit-overflow-scrolling:touch;touch-action:pan-y}
.cs-pick h3{margin:2px 2px 2px;font:400 22px var(--f-display)}
.cs-pick .sub{color:var(--muted);font:500 12.5px var(--f-body);margin:0 2px 10px}
.cs-card{display:flex;align-items:center;gap:10px;width:100%;text-align:left;border:1px solid var(--line);background:var(--surface);border-radius:14px;padding:9px 10px;margin:0 0 7px;color:var(--ink);cursor:pointer;min-height:64px;font:inherit}
.cs-card:active{transform:scale(.98)}
.cs-card .em{font:24px/1 ${EMO};flex:0 0 32px;text-align:center}
.cs-card .tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.cs-card .t1{font:700 15px var(--f-body)}
.cs-card .t2{font:500 11.5px var(--f-body);color:var(--muted);white-space:normal}
.cs-card .stars{font:600 15px var(--f-mono);color:var(--brass);flex:0 0 auto;letter-spacing:1px}
.cs-spot{position:absolute;pointer-events:none;border-radius:12px}
.cs-ov{position:absolute;inset:0;z-index:16;background:rgba(10,8,15,.78);display:flex;align-items:flex-end;justify-content:center;padding:10px;animation:fade .15s ease-out}
.cs-sheet{background:var(--surface);border:1px solid var(--line);border-radius:18px;width:min(460px,100%);max-height:calc(100% - 6px);box-sizing:border-box;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px;touch-action:pan-y}
.cs-sheet>*{flex:none}
.cs-sheet h3{font-family:var(--f-display);font-weight:400;font-size:21px;margin:0}
.cs-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.cs-x{min-width:44px;min-height:44px;border-radius:12px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-size:18px;cursor:pointer}
.cs-li{font-size:13.5px;line-height:1.45;background:var(--surface-2);border-radius:10px;padding:7px 10px}
.cs-li b{color:var(--brass)}
.cs-li.ok{color:#c4f2d4}
`;

  function drawIcon(cv, code) {
    const g = cv.getContext('2d'), T = TPL[code], W = cv.width, H = cv.height;
    let x0 = 0, x1 = 0, y0 = 0, y1 = 0;
    for (let i = 0; i < T.n; i++) { x0 = Math.min(x0, T.qx[i]); x1 = Math.max(x1, T.qx[i]); y0 = Math.min(y0, T.qy[i]); y1 = Math.max(y1, T.qy[i]); }
    const s = Math.min((W - 8) / Math.max(4, x1 - x0), (H - 8) / Math.max(4, y1 - y0));
    const ox = (W - (x1 - x0) * s) / 2 - x0 * s, oy = (H + (y1 - y0) * s) / 2 + y0 * s;
    g.clearRect(0, 0, W, H);
    g.lineCap = 'round'; g.lineJoin = 'round';
    const pass = (bk, col, lw) => {
      g.strokeStyle = col; g.lineWidth = lw; g.beginPath(); let lx = ox, ly = oy, on = false;
      for (let i = 0; i < T.n; i++) {
        const x = ox + T.qx[i] * s, y = oy - T.qy[i] * s;
        if (!!T.bk[i] === bk) { if (!on) { g.moveTo(lx, ly); on = true; } g.lineTo(x, y); } else on = false;
        lx = x; ly = y;
      }
      g.stroke();
    };
    pass(true, 'rgba(242,233,216,.35)', 2.4);
    pass(false, T.fl.some((f) => f === 1) ? '#9fd0ff' : T.fl.some((f) => f === 2) ? '#ffb04a' : T.fl.some((f) => f === 3) ? '#ff8a78' : '#f2e9d8', 3);
  }

  /* ======================= 화면 ======================= */
  function mount(root, api) {
    const h = L.h;
    root.appendChild(h('style', { text: CSS }));
    const cv = U.canvas(root), ctx = cv.ctx;
    const spd = () => (L.debug && L.debug.speed) || 1;
    let st = null, dead = false;
    const nm = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || i + 1 + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const multi = () => !api.online && api.mySeats().length >= 2;

    /* ---- DOM ---- */
    const bName = h('span', { class: 'nm' }), bRound = h('span', { class: 'rd' }), bTime = h('span', { class: 'tm' });
    const bReqs = h('div', { class: 'cs-reqs' });
    const brief = h('div', { class: 'cs-brief', role: 'button', 'aria-label': '주문서 자세히', onclick: () => openBrief() },
      h('div', { class: 'cs-b1' }, bName, bRound, bTime, h('span', { class: 'more', text: '자세히' })), bReqs);
    const spotView = h('div', { class: 'cs-spot cs-spot-view' });
    const budTxt = h('span', { class: 'cs-bud' }), budBar = h('i'), runTxt = h('span', { class: 'cs-run' });
    const st2 = h('div', { class: 'cs-st2' });
    const stat = h('div', { class: 'cs-stat' }, h('div', { class: 'cs-st1' }, budTxt, h('span', { class: 'cs-budbar' }, budBar), runTxt), st2);
    const pal = h('div', { class: 'cs-pal' });
    const palBtns = {};
    let lpT = 0, lpFired = false;
    PAL.forEach((c) => {
      const icv = h('canvas', { width: 76, height: 34 });
      drawIcon(icv, c);
      const b = h('button', { class: 'cs-pc' + (PCS[c].loop || PCS[c].cork ? ' inv' : ''), type: 'button', title: PCS[c].nl + ' (' + PCS[c].cost + ') — ' + PCS[c].d, 'aria-label': PCS[c].nl },
        icv, h('span', { text: PCS[c].n }), h('span', { class: 'c', text: '' + PCS[c].cost }));
      b.addEventListener('pointerdown', () => { lpFired = false; clearTimeout(lpT); lpT = setTimeout(() => { lpFired = true; api.toast(PCS[c].nl + ' · ' + PCS[c].cost + ' — ' + PCS[c].d); api.buzz(12); }, 480); });
      const cancel = () => clearTimeout(lpT);
      b.addEventListener('pointerup', cancel); b.addEventListener('pointerleave', cancel); b.addEventListener('pointercancel', cancel);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
      b.addEventListener('click', () => { if (lpFired) { lpFired = false; return; } addPiece(c); });
      palBtns[c] = b; pal.append(b);
    });
    const undoBtn = h('button', { class: 'btn cs-undo', type: 'button', 'aria-label': '되돌리기', title: '되돌리기 (Z)', text: '↶', onclick: () => undo() });
    const delBtn = h('button', { class: 'btn cs-del', type: 'button', 'aria-label': '고른 조각 빼기', title: '고른 조각 빼기 (Delete)', text: '✕', onclick: () => del() });
    const fitBtn = h('button', { class: 'btn cs-fit', type: 'button', 'aria-label': '전체 보기', title: '전체 보기 / 크게 보기 (F)', text: '⤢', onclick: () => toggleFit() });
    const doneBtn = h('button', { class: 'btn primary cs-done', type: 'button', text: '완성!', onclick: () => pressDone() });
    const bot = h('div', { class: 'cs-bot' }, stat, pal, h('div', { class: 'cs-act' }, undoBtn, delBtn, fitBtn, doneBtn));
    const revBtn = h('button', { class: 'btn primary', type: 'button', text: '', onclick: () => pressRev() });
    const revMsg = h('div', { class: 'muted', text: '' });
    const revBar = h('div', { class: 'cs-rev cs-hid' }, revBtn, revMsg);
    root.append(brief, spotView, bot, revBar);

    /* ---- 상태 ---- */
    let roundKey = '', active = -1, curMode = '', work = {}, tStart = {}, tPause = {}, sent = {}, readySent = {};
    let armedT = 0, handEl = null, handKey = '', pickEl = null, sheetEl = null, lastTick = -1, clock = 0, drawErr = 0;
    let P = null, Pkey = '', fit = false;
    const Vw = { W: 0, H: 0, top: 0, bot: 0, my0: 0, mh: 0, y0: 0, y1: 0, sc: 6, base: 0, key: '' };
    let camX = -ST_LEN - 4, camT = null, drag = null, followHold = 0;
    let rv = null, revId = -1, autoT = -1;
    const parts = [], pops = [];
    let skyC = null, skyKey = '', terr = null, terrSite = null, mmC = null, mmKey = '';

    const rKey = () => (st ? st.r + ':' + st.si + ':' + st.ph : '');
    function pendingLocal() {
      if (!st || st.ph !== 'b') return [];
      const out = [];
      for (let i = 0; i < st.n; i++) if (api.canAct(i) && st.tr[i] == null && sent[i] !== roundKey) out.push(i);
      return out;
    }
    function editSeat() { const p = pendingLocal(); if (!p.length) return -1; if (multi()) return p.includes(active) ? active : -1; return p[0]; }
    function mode() {
      if (!st) return 'none';
      if (st.ph === 'pick') return 'pick';
      if (st.ph === 'b') { if (editSeat() >= 0) return 'edit'; if (multi() && pendingLocal().length) return 'hand'; return 'wait'; }
      return st.last ? 'rev' : 'wait';
    }
    function W(seat) { if (!work[seat]) work[seat] = { code: '', undo: [], sel: -1 }; return work[seat]; }
    function paused() { return !!document.querySelector('.tut-layer') || (!api.online && !!document.querySelector('.overlay.rules-ov')); }
    function elapsed(seat) { if (tStart[seat] == null) return 0; return ((clock - tStart[seat] - (tPause[seat] || 0)) * spd()) / 1000; }
    const site = () => (st && st.si >= 0 ? SITES[st.si] : SITES[9]);
    function mySeatShown() { const m = api.mySeats(); if (!m.length) return -1; if (multi()) return active >= 0 ? active : -1; return m[0]; }

    /* ---- 설계 ---- */
    function curCode() { const s = editSeat(); return s >= 0 ? W(s).code : ''; }
    function refreshPreview(force) {
      const m = curMode;
      let code = '', sv = site(), w = 1;
      if (m === 'edit') code = curCode();
      else if (m === 'wait') { const s = mySeatShown(); code = s >= 0 && work[s] ? work[s].code : (s >= 0 && st.tr[s]) || ''; }
      else if (m === 'rev' && rv) {
        if (rv.cur) { const k2 = 'rev|' + rv.id + '|' + rv.i; if (force || k2 !== Pkey) { Pkey = k2; P = rv.cur.p; mmKey = ''; } return; }
        code = rv.code; sv = SITES[rv.si]; w = rv.w;
      }
      const key = code + '|' + (sv && sv.n) + '|' + w;
      if (!force && key === Pkey) return;
      Pkey = key; P = preview(code, sv, w);
      if (m === 'edit') { syncStat(); syncPal(); syncReqs(); }
      mmKey = '';
    }
    function canPlace(code, sel, c) {
      const n = sel >= 0 ? code.slice(0, sel + 1) + c + code.slice(sel + 1) : code + c;
      return layout(n, site());
    }
    function addPiece(c) {
      const s = editSeat(); if (s < 0) return;
      const w = W(s);
      const r = canPlace(w.code, w.sel, c);
      if (!r.ok) { api.toast(PCS[c].n + ': ' + r.err); Snd.nope(); api.buzz([10, 30, 10]); return; }
      w.undo.push({ code: w.code, sel: w.sel }); if (w.undo.length > 80) w.undo.shift();
      if (w.sel >= 0) { w.code = w.code.slice(0, w.sel + 1) + c + w.code.slice(w.sel + 1); w.sel++; } else w.code += c;
      Snd.place(); api.buzz(8);
      refreshPreview();
      const i = w.sel >= 0 ? w.sel : w.code.length - 1;
      showPiece(i);
    }
    function undo() {
      const s = editSeat(); if (s < 0) return;
      const w = W(s); if (!w.undo.length) { api.toast('되돌릴 게 없어요'); return; }
      const u = w.undo.pop(); w.code = u.code; w.sel = u.sel; Snd.tap(); refreshPreview();
    }
    function del() {
      const s = editSeat(); if (s < 0) return;
      const w = W(s);
      if (w.sel < 0) { if (!w.code.length) return; w.sel = w.code.length - 1; }
      const n = w.code.slice(0, w.sel) + w.code.slice(w.sel + 1), r = layout(n, site());
      if (!r.ok) { api.toast('그 조각을 빼면 ' + r.err); Snd.nope(); api.buzz([10, 30, 10]); return; }
      w.undo.push({ code: w.code, sel: w.sel });
      w.code = n; w.sel = Math.min(w.sel - 1, n.length - 1); Snd.tap(); api.buzz(8); refreshPreview();
    }
    function toggleFit() { fit = !fit; fitBtn.classList.toggle('on', fit); Vw.key = ''; Snd.tap(); }
    function pressDone() {
      const s = editSeat(); if (s < 0) return;
      const now = performance.now();
      if (now - armedT < 2600) { armedT = 0; resetDone(); submit(s, false); return; }
      armedT = now; doneBtn.classList.add('armed');
      doneBtn.textContent = P && P.m.f ? '실패해도 낼까요?' : P && !W(s).code.length ? '빈 트랙을 낼까요?' : '한 번 더 눌러 제출';
      api.buzz(10); Snd.tap();
    }
    function resetDone() { armedT = 0; doneBtn.classList.remove('armed'); doneBtn.textContent = '완성!'; }
    function submit(seat, auto) {
      if (!st || st.ph !== 'b') return;
      const w = W(seat); sent[seat] = roundKey;
      if (multi()) active = -1;
      Snd.done(); api.buzz(25);
      if (auto) api.toast('시간 끝! 지금 설계 그대로 냈어요');
      api.actAs(seat, { k: 't', c: w.code });
      sync();
    }
    function showPiece(i) {
      if (!P || i < 0) return;
      const sh = P.sh, a = sh.st[i], b = sh.st[i + 1] - 1;
      if (a == null || b < a) return;
      const xe = sh.px[b], vw = Vw.W / Vw.sc;
      if (xe > camX + vw * 0.85 || sh.px[a] < camX + vw * 0.05) { const [lo, hi] = camRange(); camT = U.clamp(xe - vw * 0.7, lo, hi); }
    }

    /* ---- 상태 줄 ---- */
    function syncReqs() {
      const sv = site(); bReqs.innerHTML = '';
      const m = P && P.code.length ? P.m : null;
      sv.req.forEach((rq) => bReqs.append(h('span', { class: 'cs-rq' + (m && !m.f && reqOk(rq, m) ? ' ok' : ''), text: (m && !m.f && reqOk(rq, m) ? '✓ ' : '○ ') + REQ_TXT[rq[0]](rq[1]) })));
      bReqs.append(h('span', { class: 'cs-rq lim', text: '↕' + sv.H + 'm · ↔' + sv.L + 'm' }));
    }
    function syncStat() {
      if (!P) return;
      const sv = site(), cost = P.lay.cost;
      budTxt.textContent = '💰' + cost + '/' + sv.B; budTxt.classList.toggle('over', cost > sv.B);
      budBar.style.width = Math.min(100, cost / sv.B * 100) + '%';
      const m = P.m;
      let cls = 'ok', txt;
      const lo = simulate(P.code, sv, sv.w[0], false), hi = simulate(P.code, sv, sv.w[1], false);
      if (!P.code.length) { cls = 'warn'; txt = '조각을 눌러 트랙을 이어요'; }
      else if (m.f) { cls = 'bad'; txt = '✗ ' + (m.fi + 1) + '번째 ' + PCS[P.code[m.fi]].n + ': ' + FAIL[m.f]; }
      else if (lo.f || hi.f) { const x = hi.f ? hi : lo; cls = 'warn'; txt = '⚠ 날씨가 ' + (hi.f ? '나쁘면' : '좋으면') + ' ' + (x.fi + 1) + '번째 ' + PCS[P.code[x.fi]].n + ' 실패'; }
      else txt = '✓ 무사히 도착 · 예상 ' + P.j.tot + '점';
      runTxt.className = 'cs-run ' + cls; runTxt.textContent = txt;
      const s = editSeat(), sel = s >= 0 ? W(s).sel : -1;
      if (sel >= 0 && sel < P.code.length) {
        const sh = P.sh, a = sh.st[sel], b = sh.st[sel + 1] - 1;
        let vin = P.v[a], vout = P.v[b], gx = 1, vmin = 1e9;
        for (let k = a; k <= b; k++) { if (P.v[k] < 0) break; gx = Math.max(gx, P.gg[k]); vmin = Math.min(vmin, P.v[k]); }
        st2.innerHTML = '';
        st2.append(h('b', { text: (sel + 1) + '번째 ' + PCS[P.code[sel]].n }),
          vin < 0 ? ' · 열차가 못 와요' : ' · ' + kmh(vin) + '→' + (vout < 0 ? '✗' : kmh(vout)) + 'km/h · 최저 ' + kmh(vmin) + ' · ' + gx.toFixed(1) + 'G · 새 조각은 이 뒤에');
      } else if (!P.code.length) st2.textContent = '꾹 누르면 조각 설명 · 트랙을 누르면 그 조각을 골라요';
      else {
        st2.textContent = '';
        st2.append(h('b', { text: '최고 ' + kmh(m.vmax) + 'km/h' }), ' · ' + m.gmax.toFixed(1) + 'G · 뒤집기 ' + m.inv + ' · 에어 ' + m.air.toFixed(1) + '초 · ' + Math.round(m.time) + '초');
      }
      undoBtn.disabled = !(s >= 0 && W(s).undo.length);
      delBtn.disabled = !(s >= 0 && W(s).code.length);
    }
    function syncPal() {
      const s = editSeat(); if (s < 0) return;
      const w = W(s);
      PAL.forEach((c) => palBtns[c].classList.toggle('no', !canPlace(w.code, w.sel, c).ok));
    }

    /* ---- 시트 ---- */
    function closeSheet() { if (sheetEl) { sheetEl.remove(); sheetEl = null; } }
    function openSheet(title, kids) {
      closeSheet();
      const sh = h('div', { class: 'cs-sheet' }, h('div', { class: 'cs-head' }, h('h3', { text: title }), h('button', { class: 'cs-x', type: 'button', 'aria-label': '닫기', text: '✕', onclick: () => closeSheet() })), ...kids);
      sheetEl = h('div', { class: 'cs-ov', onclick: (e) => { if (e.target === sheetEl) closeSheet(); } }, sh);
      root.append(sheetEl);
    }
    function openBrief() {
      if (!st || st.si < 0) return;
      const sv = site(); Snd.tap();
      openSheet(sv.e + ' ' + sv.n, [
        h('div', { class: 'cs-li', text: sv.d }),
        h('div', { class: 'cs-li' }, h('b', { text: '조건  ' }), '예산 ' + sv.B + ' · 높이 제한 ' + sv.H + 'm · 부지 길이 ' + sv.L + 'm · 날씨 마찰 ×' + sv.w[0] + '~' + sv.w[1]),
        h('div', { class: 'cs-li' }, h('b', { text: '주문 보너스 (모두 20점)  ' }), sv.req.map((r) => REQ_TXT[r[0]](r[1])).join(' · ')),
        h('div', { class: 'cs-li', text: '점수 = 짜릿함(40) + 안전·편안함(25) + 남은 예산(15) + 주문(20). 시험 운행에서 멈추거나 탈선하면 0점!' }),
        ...PAL.map((c) => h('div', { class: 'cs-li' }, h('b', { text: PCS[c].nl + ' ' + PCS[c].cost + '  ' }), PCS[c].d)),
      ]);
    }

    /* ---- 한 폰 여럿: 넘겨주기 ---- */
    function syncHand() {
      let want = -1;
      if (st && st.ph === 'b' && multi()) { const p = pendingLocal(); if (p.length && !p.includes(active)) want = p[0]; }
      const key = want + ':' + roundKey;
      if (key === handKey) return;
      handKey = key;
      if (handEl) { handEl.remove(); handEl = null; }
      if (want < 0) return;
      closeSheet();
      const sv = site();
      handEl = h('div', { class: 'cs-hand' },
        h('span', { class: 'dot', style: { '--c': col(want), width: '18px', height: '18px' } }),
        h('div', { class: 'big', text: nm(want) }),
        h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: (st.r + 1) + '/' + st.R + '판 · ' + sv.e + ' ' + sv.n }),
        h('div', { class: 'muted', text: '혼자 몰래 설계해요. 다른 사람은 보지 마세요!' }),
        h('button', { class: 'btn primary', type: 'button', text: '설계 시작', onclick: () => { active = want; api.sfx('click'); handKey = ''; sync(); } }));
      root.append(handEl);
    }
    /* ---- 혼자: 부지 고르기 ---- */
    function bests() { try { return JSON.parse(localStorage.getItem('lounge.coaster.best') || '{}') || {}; } catch (e) { return {}; } }
    function saveBest(si, stars, score) {
      const b = bests(), o = b[si] || [0, 0];
      if (stars < o[0] || (stars === o[0] && score <= o[1])) return;
      b[si] = [stars, score]; try { localStorage.setItem('lounge.coaster.best', JSON.stringify(b)); } catch (e) {}
    }
    function syncPick() {
      const want = st && st.ph === 'pick';
      if (!want) { if (pickEl) { pickEl.remove(); pickEl = null; } return; }
      if (pickEl) return;
      const can = api.canAct(0), b = bests();
      const list = SOLO.map((si, k) => {
        const sv = SITES[si], bs = b[si] ? b[si][0] : 0;
        return h('button', { class: 'cs-card', type: 'button', disabled: !can, onclick: () => { if (!can || !st || st.ph !== 'pick') return; api.sfx('click'); api.buzz(12); api.act({ k: 'p', i: si }); } },
          h('span', { class: 'em', text: sv.e }),
          h('span', { class: 'tx' }, h('span', { class: 't1', text: (k + 1) + '. ' + sv.n }), h('span', { class: 't2', text: '예산 ' + sv.B + ' · 높이 ' + sv.H + 'm · ' + sv.req.map((r) => REQ_TXT[r[0]](r[1])).join(' · ') })),
          h('span', { class: 'stars', text: '★'.repeat(bs) + '☆'.repeat(3 - bs) }));
      });
      pickEl = h('div', { class: 'cs-pick' }, h('h3', { text: '혼자 하기 · 부지 고르기' }),
        h('div', { class: 'sub', text: can ? '부지마다 주문이 달라요. 점수 ' + STARS.join(' / ') + '점이면 별 1·2·3개!' : 'AI가 부지를 고르는 중…' }), ...list);
      root.append(pickEl);
    }

    /* ---- 시험 운행 (공개) ---- */
    function animFor(code, si, w, res) {
      const sv = SITES[si], p = preview(code, sv, w), rec = p.m.rec;
      const A = [0];
      for (let i = 1; i < rec.t.length; i++) {
        const pc = rec.p[i] >= 0 && rec.p[i] < code.length ? code[rec.p[i]] : '';
        A.push(A[i - 1] + (rec.t[i] - rec.t[i - 1]) * (pc === 'C' ? 0.3 : i === 1 ? 0.4 : 1));
      }
      const tot = A[A.length - 1] || 1, target = res[0] ? Math.max(2.5, Math.min(7, tot / 2.6)) : animSecs(rec.t[rec.t.length - 1]);
      for (let i = 0; i < A.length; i++) A[i] = A[i] / tot * target;
      // 탑승객 반응
      const ev = [];
      let lastPc = -2;
      for (let i = 2; i < rec.t.length; i++) {
        const pi = rec.p[i]; if (pi === lastPc || pi < 0 || pi >= code.length) continue;
        lastPc = pi; const c = code[pi];
        if (res[0] && pi >= p.m.fi) break;
        const say = { C: ['두근두근…', '😬'], X: ['꺄아아아!', '😱'], M: ['으아아!', '😱'], O: ['우와아~!', '🙃'], S: ['빙그르르~', '😵‍💫'], H: ['붕~ 떴다!', '😆'], B: ['슈우웅!', '🤩'], T: ['쏠린다~', '😮'], Z: ['끼이익', '😌'] }[c];
        if (say) ev.push({ at: A[i] + (c === 'H' || c === 'O' || c === 'S' ? (A[Math.min(A.length - 1, i + 12)] - A[i]) : 0), t: say[0], e: say[1], c });
      }
      return { code, si, w, res, p, rec, A, dur: target, ev };
    }
    function startRev(s) {
      const last = s.last;
      rv = { id: last.id, si: last.si, w: last.w, i: 0, ph: 'intro', t: 0, cur: null, done: false, code: '' };
      revId = last.id; autoT = -1; pops.length = 0; parts.length = 0;
      setRide(0);
    }
    function setRide(i) {
      const last = st.last;
      if (i >= st.n) { rv.ph = 'board'; rv.t = 0; rv.done = true; rv.cur = null; autoT = 20; Snd.fanfare(); syncRev(); return; }
      rv.i = i; rv.ph = 'intro'; rv.t = 0; rv.evI = 0; rv.chT = 0; rv.crash = false;
      rv.cur = animFor(last.tr[i] || '', last.si, last.w, last.res[i]);
      rv.code = rv.cur.code; Pkey = ''; refreshPreview(true);
      camX = -ST_LEN - 4; camT = null; followHold = 0;
      syncRev();
    }
    function pressRev() {
      if (!st || !st.last || !rv) return;
      if (st.ph === 'v' && rv.done) { pressNext(); return; }
      if (rv.ph === 'board') return;
      Snd.tap();
      if (rv.ph === 'intro' || rv.ph === 'ride' || rv.ph === 'crash') { rv.ph = 'card'; rv.t = 0; Snd.ding(); }
      else setRide(rv.i + 1);
      syncRev();
    }
    function pressNext() {
      if (!st || st.ph !== 'v' || !st.last) return;
      const id = st.last.id;
      const seats = api.mySeats().filter((i) => !st.rd[i] && readySent[i] !== id);
      seats.forEach((i) => { readySent[i] = id; });
      Snd.tap();
      seats.forEach((i) => { if (st && st.ph === 'v' && !st.rd[i]) api.actAs(i, { k: 'n' }); });
      syncRev();
    }
    function syncRev() {
      const m = curMode;
      if (m === 'wait') {
        revBtn.classList.add('cs-hid'); revMsg.classList.remove('cs-hid');
        const done = st ? st.tr.filter((x) => x != null).length : 0;
        revMsg.textContent = (api.mySeats().length ? '제출 완료! ' : '') + '다른 설계자를 기다려요 (' + done + '/' + (st ? st.n : 0) + ')';
        return;
      }
      if (m !== 'rev' || !st || !st.last || !rv) return;
      const mine = api.mySeats(), pend = mine.filter((i) => !st.rd[i] && readySent[i] !== st.last.id);
      if (!rv.done) { revBtn.classList.remove('cs-hid'); revMsg.classList.add('cs-hid'); revBtn.textContent = '▶▶ 넘기기'; return; }
      if (st.ph === 'v' && pend.length) {
        revBtn.classList.remove('cs-hid'); revMsg.classList.add('cs-hid');
        const left = autoT >= 0 ? Math.ceil(autoT) : -1, fin = st.last.r + 1 >= st.R;
        revBtn.textContent = (fin ? '최종 결과 보기' : '다음 판 ▶') + (left >= 0 && left <= 10 ? ' (' + left + ')' : '');
      } else {
        revBtn.classList.add('cs-hid'); revMsg.classList.remove('cs-hid');
        const ready = st.rd.filter((x) => x).length;
        revMsg.textContent = st.ph === 'end' ? '최종 결과!' : mine.length ? '다른 사람을 기다려요 (' + ready + '/' + st.n + ')' : '심사 중… (' + ready + '/' + st.n + ')';
      }
    }

    /* ---- 화면 상태 맞추기 ---- */
    function sync() {
      const m = mode();
      const changed = m !== curMode;
      curMode = m;
      const showBuild = m === 'edit' || m === 'hand' || m === 'pick';
      bot.classList.toggle('cs-hid', !showBuild);
      brief.classList.toggle('cs-hid', m === 'rev' || m === 'none');
      revBar.classList.toggle('cs-hid', !(m === 'rev' || m === 'wait'));
      if (m === 'edit') {
        const s = editSeat();
        if (tStart[s] == null) { tStart[s] = clock || performance.now(); tPause[s] = 0; lastTick = -1; camX = -ST_LEN - 4; camT = null; }
      }
      if (m !== 'edit') resetDone();
      if (m !== 'edit' && m !== 'wait' && sheetEl && m !== 'pick') closeSheet();
      if (st && st.si >= 0) { const sv = site(); bName.textContent = sv.e + ' ' + sv.n; bRound.textContent = st.solo ? '혼자 하기' : (st.r + 1) + '/' + st.R + '판'; }
      else if (st) { bName.textContent = '🎢 부지 고르기'; bRound.textContent = '혼자 하기'; bReqs.innerHTML = ''; }
      syncHand(); syncPick();
      if (changed) Vw.key = '';
      refreshPreview(changed);
      if (m === 'edit') { syncStat(); syncPal(); }
      if (m === 'edit' || m === 'wait') syncReqs();
      syncRev();
    }

    /* ---- 레이아웃 ---- */
    function layoutView() {
      const Wd = cv.w, Hh = cv.h, m = curMode;
      const sv = m === 'rev' && rv ? SITES[rv.si] : site();
      const bTop = brief.classList.contains('cs-hid') ? 0 : brief.offsetTop + brief.offsetHeight;
      const top = m === 'rev' ? 46 : Math.max(8, bTop + 6);
      const bottom = !bot.classList.contains('cs-hid') ? Hh - bot.offsetHeight + 4 : !revBar.classList.contains('cs-hid') ? Hh - revBar.offsetHeight + 6 : Hh;
      Vw.W = Wd; Vw.H = Hh; Vw.top = top; Vw.bot = bottom;
      Vw.my0 = top; Vw.mh = 28;
      Vw.y0 = top + Vw.mh + 6; Vw.y1 = bottom - 4;
      const depth = -minGround(sv), vh = Math.max(60, Vw.y1 - Vw.y0);
      let s = U.clamp((vh - 14) / (sv.H + 9 + depth), 2, 8.5);
      s = Math.min(s, Wd / 55);
      if (fit && m === 'edit') s = Math.min(s, (Wd - 12) / (sv.L + ST_LEN + END_LEN + 10));
      Vw.sc = s; Vw.base = Vw.y1 - (depth + 2.5) * s;
      Vw.site = sv;
      Vw.key = Wd + 'x' + Hh + ':' + m + ':' + bTop + ':' + bot.offsetHeight + ':' + fit + ':' + sv.n;
      spotView.style.left = '4px'; spotView.style.top = Vw.y0 + 'px'; spotView.style.width = (Wd - 8) + 'px'; spotView.style.height = Math.max(20, Vw.y1 - Vw.y0) + 'px';
      mmKey = ''; skyKey = '';
      clampCam();
    }
    function camRange() { const sv = Vw.site || site(); const a = -ST_LEN - 6, b = sv.L + END_LEN + 10 - Vw.W / Vw.sc; return [a, Math.max(a, b)]; }
    function clampCam() { const [a, b] = camRange(); camX = U.clamp(camX, a, b); }
    cv.onresize = () => { Vw.key = ''; };

    /* ---- 배경 (캐시) ---- */
    function buildSky(sv) {
      const Wd = Vw.W, Hh = Vw.H, dpr = cv.dpr, th = THEMES[sv.th];
      const c = document.createElement('canvas'); c.width = Math.ceil(Wd * dpr); c.height = Math.ceil(Hh * dpr);
      const b = c.getContext('2d'); b.scale(dpr, dpr);
      const g = b.createLinearGradient(0, 0, 0, Hh); g.addColorStop(0, th.sky[0]); g.addColorStop(0.6, th.sky[1]); g.addColorStop(1, th.sky[2]);
      b.fillStyle = g; b.fillRect(0, 0, Wd, Hh);
      let sd = 17 + sv.th * 31; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
      const gy = Vw.base;   // 땅 높이(화면)
      const dk = 'rgba(10,6,18,0.45)';
      if (['trees', 'space', 'lanterns', 'city', 'peaks', 'pier', 'wheel'].includes(th.deco)) {
        for (let i = 0; i < 40; i++) { b.fillStyle = 'rgba(255,245,220,' + (0.15 + r() * 0.5).toFixed(2) + ')'; b.fillRect(r() * Wd, r() * gy * 0.6, 1.3, 1.3); }
      }
      b.fillStyle = dk;
      switch (th.deco) {
        case 'trees': for (let x = -10; x < Wd; x += 14 + r() * 12) { const hh = 24 + r() * 40; b.beginPath(); b.moveTo(x, gy); b.lineTo(x + 9, gy - hh); b.lineTo(x + 18, gy); b.fill(); } break;
        case 'city': for (let x = 0; x < Wd; x += 18 + r() * 20) { const hh = 40 + r() * 110, w = 16 + r() * 18; b.fillStyle = dk; b.fillRect(x, gy - hh, w, hh); b.fillStyle = 'rgba(255,214,140,.35)'; for (let yy = gy - hh + 6; yy < gy - 6; yy += 9) for (let xx = x + 3; xx < x + w - 4; xx += 6) if (r() < 0.4) b.fillRect(xx, yy, 2.5, 3.5); } break;
        case 'peaks': b.fillStyle = 'rgba(220,232,250,.18)'; b.beginPath(); b.moveTo(0, gy); for (let x = 0; x <= Wd; x += 40) b.lineTo(x, gy - 60 - r() * 120); b.lineTo(Wd, gy); b.fill(); break;
        case 'mesa': b.fillStyle = 'rgba(90,30,30,.35)'; for (let x = -20; x < Wd; x += 90 + r() * 60) { const hh = 50 + r() * 70, w = 50 + r() * 60; b.fillRect(x, gy - hh, w, hh); } break;
        case 'volcano': b.fillStyle = 'rgba(20,8,8,.6)'; b.beginPath(); b.moveTo(Wd * 0.3, gy); b.lineTo(Wd * 0.55, gy - 150); b.lineTo(Wd * 0.65, gy - 150); b.lineTo(Wd * 0.95, gy); b.fill(); b.fillStyle = 'rgba(255,110,40,.45)'; b.beginPath(); b.ellipse(Wd * 0.6, gy - 152, 18, 6, 0, 0, 7); b.fill(); break;
        case 'rain': b.strokeStyle = 'rgba(200,215,235,.13)'; b.lineWidth = 1; for (let i = 0; i < 90; i++) { const x = r() * Wd, y = r() * Hh; b.beginPath(); b.moveTo(x, y); b.lineTo(x - 4, y + 14); b.stroke(); } break;
        case 'space': b.fillStyle = 'rgba(160,140,255,.25)'; b.beginPath(); b.arc(Wd * 0.78, Hh * 0.22, 34, 0, 7); b.fill(); b.strokeStyle = 'rgba(200,180,255,.25)'; b.lineWidth = 2; b.beginPath(); b.ellipse(Wd * 0.78, Hh * 0.22, 56, 12, -0.3, 0, 7); b.stroke(); break;
        case 'wheel': { const cx = Wd * 0.8, cy = gy - 80, R = 62; b.strokeStyle = 'rgba(255,220,240,.18)'; b.lineWidth = 2; b.beginPath(); b.arc(cx, cy, R, 0, 7); b.stroke(); for (let k = 0; k < 10; k++) { const a = k / 10 * Math.PI * 2; b.beginPath(); b.moveTo(cx, cy); b.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R); b.stroke(); } b.beginPath(); b.moveTo(cx - 30, gy); b.lineTo(cx, cy); b.lineTo(cx + 30, gy); b.stroke(); break; }
        case 'lanterns': for (let i = 0; i < 14; i++) { const x = r() * Wd, y = 20 + r() * gy * 0.5; b.fillStyle = 'rgba(255,170,80,.5)'; b.beginPath(); b.ellipse(x, y, 4, 5.5, 0, 0, 7); b.fill(); } break;
        case 'lake': case 'pier': b.fillStyle = 'rgba(255,220,180,.2)'; b.beginPath(); b.arc(Wd * 0.78, Vw.y0 + 70, 20, 0, 7); b.fill(); break;
      }
      skyC = c;
    }
    function buildMini() {
      const sv = Vw.site, dpr = cv.dpr, w = Vw.W - 16, hh = Vw.mh;
      const c = document.createElement('canvas'); c.width = Math.ceil(w * dpr); c.height = Math.ceil(hh * dpr);
      const b = c.getContext('2d'); b.scale(dpr, dpr);
      b.fillStyle = 'rgba(12,9,18,.72)'; b.beginPath(); b.roundRect ? b.roundRect(0, 0, w, hh, 8) : b.rect(0, 0, w, hh); b.fill();
      const x0 = -ST_LEN - 6, x1 = sv.L + END_LEN + 10, depth = -minGround(sv);
      const sx = (w - 8) / (x1 - x0), sy = (hh - 6) / (sv.H + depth + 4);
      const X = (x) => 4 + (x - x0) * sx, Y = (y) => hh - 3 - (y + depth + 1) * sy;
      b.fillStyle = THEMES[sv.th].gr; b.beginPath(); b.moveTo(X(x0), hh); for (let x = x0; x <= x1; x += 2) b.lineTo(X(x), Y(groundAt(sv, x))); b.lineTo(X(x1), hh); b.fill();
      b.strokeStyle = 'rgba(255,255,255,.25)'; b.setLineDash([3, 3]); b.lineWidth = 1; b.beginPath(); b.moveTo(X(x0), Y(sv.H)); b.lineTo(X(x1), Y(sv.H)); b.moveTo(X(sv.L + END_LEN), 2); b.lineTo(X(sv.L + END_LEN), hh - 2); b.stroke(); b.setLineDash([]);
      if (P) {
        b.lineWidth = 1.6; b.lineCap = 'round';
        let lx = X(0), ly = Y(ST_Y);
        for (let k = 0; k < P.sh.qx.length; k++) {
          const x = X(P.sh.qx[k]), y = Y(P.sh.qy[k]);
          b.strokeStyle = P.v[k] < 0 ? '#777' : SPC[spB(P.v[k])]; b.beginPath(); b.moveTo(lx, ly); b.lineTo(x, y); b.stroke(); lx = x; ly = y;
        }
        if (P.fk >= 0) { b.fillStyle = '#ff5a4a'; b.beginPath(); b.arc(X(P.sh.qx[P.fk]), Y(P.sh.qy[P.fk]), 3, 0, 7); b.fill(); }
      }
      mmC = { c, X, sx, x0, w };
    }

    /* ---- 그리기 ---- */
    const X = (x) => (x - camX) * Vw.sc, Y = (y) => Vw.base - y * Vw.sc;
    function rr(x, y, w, hh, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + hh, r); ctx.arcTo(x + w, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function drawWorld(sv, Q, sel) {
      const sc = Vw.sc, th = THEMES[sv.th];
      ctx.save();
      ctx.beginPath(); ctx.rect(0, Vw.y0 - 4, Vw.W, Vw.H - Vw.y0 + 4); ctx.clip();
      // 높이 제한
      ctx.strokeStyle = 'rgba(255,214,140,.35)'; ctx.setLineDash([6, 6]); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, Y(sv.H)); ctx.lineTo(Vw.W, Y(sv.H)); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(255,214,140,.6)'; ctx.font = '600 10.5px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.fillText('높이 제한 ' + sv.H + 'm', 6, Y(sv.H) - 2);
      // 땅 + 트랙 (월드 좌표)
      if (terrSite !== sv) { terr = terrainPath(sv); terrSite = sv; }
      ctx.save(); ctx.translate(-camX * sc, Vw.base); ctx.scale(sc, -sc);
      ctx.fillStyle = th.gr; ctx.fill(terr.P);
      ctx.strokeStyle = th.top; ctx.lineWidth = 2.2 / sc; ctx.stroke(terr.T);
      if (Q) {
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.strokeStyle = 'rgba(210,196,176,.33)'; ctx.lineWidth = Math.max(1.2 / sc, 0.22); ctx.stroke(Q.sup);
        ctx.globalAlpha = 0.42; ctx.lineWidth = Math.max(2 / sc, 0.35);
        for (let b = 0; b <= 8; b++) { ctx.strokeStyle = b === 8 ? '#8a8494' : SPC[b]; ctx.stroke(Q.back[b]); }
        ctx.globalAlpha = 1;
        ctx.strokeStyle = '#1b1424'; ctx.lineWidth = Math.max(5.5 / sc, 0.9); ctx.stroke(Q.base);
        ctx.lineWidth = Math.max(2.6 / sc, 0.42);
        for (let b = 0; b <= 8; b++) { ctx.strokeStyle = b === 8 ? '#8a8494' : SPC[b]; ctx.stroke(Q.front[b]); }
      }
      ctx.restore();
      // 부지 끝
      const xe = X(sv.L + END_LEN);
      if (xe < Vw.W + 4) {
        ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.moveTo(xe, Vw.y0); ctx.lineTo(xe, Vw.y1); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.textAlign = 'right'; ctx.textBaseline = 'top'; ctx.font = '600 10.5px ' + FONT; ctx.fillText('부지 끝', xe - 4, Vw.y0 + 2);
      }
      if (Q) {
        drawStation(-ST_LEN, ST_Y, '출발');
        if (Q.code.length) drawStation(Q.sh.endX, Q.sh.endY, '도착');
        // 고른 조각
        if (sel >= 0 && sel < Q.code.length) {
          const a = Q.sh.st[sel], b2 = Q.sh.st[sel + 1];
          ctx.strokeStyle = 'rgba(255,214,120,.55)'; ctx.lineWidth = 9; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          ctx.beginPath(); ctx.moveTo(X(a > 0 ? Q.sh.qx[a - 1] : 0), Y(a > 0 ? Q.sh.qy[a - 1] : ST_Y));
          for (let k = a; k < b2; k++) ctx.lineTo(X(Q.sh.qx[k]), Y(Q.sh.qy[k]));
          ctx.stroke();
        }
        // 끼워 넣을 자리
        if (curMode === 'edit') {
          const k = sel >= 0 ? Q.sh.st[sel + 1] - 1 : Q.sh.qx.length - 1;
          const x = k >= 0 ? Q.sh.qx[k] : 0, y = k >= 0 ? Q.sh.qy[k] : ST_Y;
          const bob = Math.sin(clock / 220) * 2;
          ctx.fillStyle = '#ffd36a'; ctx.beginPath(); ctx.moveTo(X(x), Y(y) - 8 + bob); ctx.lineTo(X(x) - 6, Y(y) - 18 + bob); ctx.lineTo(X(x) + 6, Y(y) - 18 + bob); ctx.closePath(); ctx.fill();
        }
        // 경고·실패
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        Q.warn.forEach((wv) => {
          const x = X(Q.sh.qx[wv.k]), y = Y(Q.sh.qy[wv.k]);
          if (x < -20 || x > Vw.W + 20) return;
          ctx.fillStyle = '#ffb030'; ctx.beginPath(); ctx.arc(x, y, 7, 0, 7); ctx.fill();
          ctx.fillStyle = '#2a1a08'; ctx.font = '700 10px ' + FONT; ctx.fillText('!', x, y + 0.5);
          if (curMode === 'edit') { ctx.font = '600 10px ' + MONO; ctx.fillStyle = '#ffd08a'; ctx.fillText(wv.t, x, y - 14); }
        });
        if (Q.fk >= 0 && (curMode !== 'rev' || (rv && (rv.ph === 'card' || rv.ph === 'crash')))) {
          const x = X(Q.sh.qx[Q.fk]), y = Y(Q.sh.qy[Q.fk]);
          ctx.fillStyle = '#ff4a3a'; ctx.beginPath(); ctx.arc(x, y, 9, 0, 7); ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(x - 4, y - 4); ctx.lineTo(x + 4, y + 4); ctx.moveTo(x + 4, y - 4); ctx.lineTo(x - 4, y + 4); ctx.stroke();
          if (curMode === 'edit') label(x, y - 22, FAIL[Q.m.f], '#ff8a78');
        }
      }
      ctx.restore();
    }
    function label(x, y, t, c) {
      ctx.font = '700 11.5px ' + FONT; const w = ctx.measureText(t).width + 12;
      const lx = U.clamp(x - w / 2, 4, Vw.W - w - 4);
      ctx.fillStyle = 'rgba(20,12,24,.85)'; rr(lx, y - 10, w, 20, 8); ctx.fill();
      ctx.fillStyle = c; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, lx + w / 2, y + 0.5);
    }
    function drawStation(x0, y, t) {
      const sc = Vw.sc, len = (x0 < 0 ? ST_LEN : END_LEN) * sc, x = X(x0), yy = Y(y);
      if (x > Vw.W + 10 || x + len < -10) return;
      ctx.fillStyle = 'rgba(70,52,40,.95)'; ctx.fillRect(x, yy + 2, len, 5);
      ctx.fillStyle = '#c94f3c'; ctx.beginPath(); ctx.moveTo(x - 3, yy - 3.4 * sc); ctx.lineTo(x + len / 2, yy - 4.6 * sc); ctx.lineTo(x + len + 3, yy - 3.4 * sc); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,240,210,.85)'; ctx.fillRect(x + 2, yy - 3.4 * sc, 2, 3.4 * sc); ctx.fillRect(x + len - 4, yy - 3.4 * sc, 2, 3.4 * sc);
      ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillStyle = '#ffe8c0'; ctx.fillText(t, x + len / 2, yy - 4.8 * sc - 1);
    }
    // 열차: rec 위의 거리 s(m)에 있는 점·각도
    function pathAt(rec, s) {
      const S = rec.s; let lo = 0, hi = S.length - 1;
      if (s <= S[0]) return [rec.qx[0], rec.qy[0], 0];
      if (s >= S[hi]) { const a = Math.max(0, hi - 1); return [rec.qx[hi], rec.qy[hi], Math.atan2(rec.qy[hi] - rec.qy[a], rec.qx[hi] - rec.qx[a] || 1e-6)]; }
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (S[m] <= s) lo = m; else hi = m; }
      const f = (s - S[lo]) / Math.max(1e-6, S[hi] - S[lo]);
      return [rec.qx[lo] + (rec.qx[hi] - rec.qx[lo]) * f, rec.qy[lo] + (rec.qy[hi] - rec.qy[lo]) * f, Math.atan2(rec.qy[hi] - rec.qy[lo], rec.qx[hi] - rec.qx[lo])];
    }
    function drawTrain(rec, s, color, mood, shake) {
      const sc = Vw.sc, cl = Math.max(15, 3.1 * sc), chh = Math.max(8, 1.3 * sc);
      let head = null;
      for (let c = 0; c < 3; c++) {
        const [x, y, a] = pathAt(rec, s - c * 3.4 - 1.5);
        const px = X(x) + (shake ? (Math.random() - 0.5) * 3 : 0), py = Y(y);
        ctx.save(); ctx.translate(px, py); ctx.rotate(-a);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(-cl / 2, -chh - 1, cl, chh + 2, 3); ctx.fill();
        ctx.fillStyle = color; rr(-cl / 2, -chh, cl, chh, 3); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(-cl / 2 + 2, -chh + 2, cl - 4, 2);
        ctx.fillStyle = '#ffe2c4';
        ctx.beginPath(); ctx.arc(-cl * 0.2, -chh - 3, 2.6, 0, 7); ctx.arc(cl * 0.2, -chh - 3, 2.6, 0, 7); ctx.fill();
        ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(-cl * 0.3, 0, 2, 0, 7); ctx.arc(cl * 0.3, 0, 2, 0, 7); ctx.fill();
        ctx.restore();
        if (c === 0) head = [px, py, a];
      }
      if (mood && head) {
        const [px, py] = head;
        ctx.font = '20px ' + EMO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = 'rgba(255,250,240,.92)'; ctx.beginPath(); ctx.arc(px, py - chh - 22, 14, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.moveTo(px - 4, py - chh - 10); ctx.lineTo(px + 4, py - chh - 10); ctx.lineTo(px, py - chh - 4); ctx.fill();
        ctx.fillStyle = '#000'; ctx.fillText(mood, px, py - chh - 21);
      }
      return head;
    }
    function drawMini() {
      if (!mmC || mmKey !== 'ok') { buildMini(); mmKey = 'ok'; }
      const x = 8, y = Vw.my0;
      ctx.drawImage(mmC.c, x, y, mmC.w, Vw.mh);
      const a = x + mmC.X(camX), b = x + mmC.X(camX + Vw.W / Vw.sc);
      ctx.strokeStyle = 'rgba(255,214,120,.9)'; ctx.lineWidth = 1.5; rr(Math.max(x, a), y + 1, Math.min(x + mmC.w, b) - Math.max(x, a), Vw.mh - 2, 5); ctx.stroke();
    }
    function drawHUD(v, G, y, t) {
      const x = 10, top = Vw.y0 + 6;
      ctx.fillStyle = 'rgba(16,11,22,.78)'; rr(x, top, 112, 52, 10); ctx.fill();
      ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
      ctx.fillStyle = SPC[spB(v)]; ctx.font = '700 22px ' + MONO; ctx.fillText(String(kmh(v)), x + 8, top + 24);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 10px ' + FONT; ctx.fillText('km/h', x + 8, top + 37);
      ctx.font = '700 14px ' + MONO; ctx.fillStyle = G > LIM.gHiP || G < LIM.gLoP ? '#ffb030' : '#f2e9d8'; ctx.fillText(G.toFixed(1) + 'G', x + 62, top + 22);
      ctx.font = '600 10.5px ' + MONO; ctx.fillStyle = '#ab9fb8'; ctx.fillText(Math.round(y) + 'm · ' + t.toFixed(0) + 's', x + 62, top + 38);
      // G 막대
      const gx = x + 8, gy = top + 42, gw = 96;
      ctx.fillStyle = '#3a3048'; ctx.fillRect(gx, gy, gw, 4);
      const z = gx + gw * (2 / 8);   // -2G ~ 6G
      ctx.fillStyle = G < 0.3 ? '#7fd0ff' : G > LIM.gHiP ? '#ff8a3a' : '#e3ae45';
      const gp = gx + gw * U.clamp((G + 2) / 8, 0, 1);
      ctx.fillRect(Math.min(z, gp), gy, Math.abs(gp - z), 4);
    }
    function drawEdit() {
      const sv = site(), s = editSeat(), sel = s >= 0 ? W(s).sel : -1;
      drawWorld(sv, P, sel);
      if (P) drawTrain(P.m.rec, 11, s >= 0 ? col(s) : '#e3ae45', null, false);
      drawMini();
      if (!P || !P.code.length) {
        ctx.font = '600 13px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        label(Vw.W / 2, Vw.y0 + 40, '↓ 아래 조각을 누르면 출발 승강장 뒤에 붙어요', '#ffe8c0');
      }
    }
    function drawWait() {
      const sv = site();
      drawWorld(sv, P, -1);
      if (P) drawTrain(P.m.rec, 11, '#e3ae45', null, false);
      drawMini();
      const others = [];
      if (st) for (let i = 0; i < st.n; i++) others.push([nm(i), st.tr[i] != null, col(i)]);
      let y = Vw.y0 + 10;
      ctx.font = '600 12px ' + FONT;
      others.forEach(([n, d, c]) => {
        const t = (d ? '✓ ' : '… ') + n + (d ? ' 완성' : ' 설계 중');
        const w = ctx.measureText(t).width + 16;
        ctx.fillStyle = 'rgba(16,11,22,.78)'; rr(Vw.W - w - 8, y, w, 22, 9); ctx.fill();
        ctx.fillStyle = d ? '#9fe8bc' : '#d8cce6'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(t, Vw.W - w, y + 11.5);
        y += 26;
      });
    }
    function drawPickBg() { drawWorld(SITES[9], null, -1); }

    /* ---- 공개 진행 ---- */
    function stepRev(dt) {
      if (!rv || !rv.cur) return;
      const sp = spd(), R = rv.cur;
      rv.t += dt * sp;
      if (rv.ph === 'intro' && rv.t > 0.9) { rv.ph = 'ride'; rv.t = 0; Snd.clack(); }
      else if (rv.ph === 'ride') {
        // 이벤트
        while (rv.evI < R.ev.length && R.ev[rv.evI].at <= rv.t) {
          const e = R.ev[rv.evI++];
          const [x, y] = pathAt(R.rec, sAt(R, e.at));
          pops.push({ x, y, t: e.t, life: 1.6, age: 0 });
          if (e.c === 'X' || e.c === 'M') { Snd.whoosh(); Snd.scream(); api.buzz(20); }
          else if (e.c === 'O' || e.c === 'S') Snd.wow();
          else if (e.c === 'H') Snd.scream();
          else if (e.c === 'B') Snd.boost();
          else if (e.c === 'Z') Snd.brake();
        }
        const sNow = sAt(R, rv.t), i = idxAt(R, rv.t), pc = R.rec.p[i];
        if (pc >= 0 && pc < R.code.length && R.code[pc] === 'C') { rv.chT -= dt * sp; if (rv.chT <= 0) { rv.chT = 0.16; Snd.clack(); } }
        void sNow;
        if (rv.t >= R.dur) {
          if (R.res[0]) { rv.ph = 'crash'; rv.t = 0; Snd.crash(); api.buzz([40, 30, 60]); const [x, y] = pathAt(R.rec, sAt(R, R.dur)); for (let k = 0; k < 26; k++) { const a = Math.random() * 7, v = 3 + Math.random() * 9; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v + 4, age: 0, life: 0.6 + Math.random() * 0.6, c: k % 2 ? '#ffd24a' : '#ff7a3a' }); } }
          else { rv.ph = 'card'; rv.t = 0; Snd.brake(); Snd.ding(); }
          syncRev();
        }
      } else if (rv.ph === 'crash' && rv.t > 1.8) { rv.ph = 'card'; rv.t = 0; Snd.ding(); syncRev(); }
      else if (rv.ph === 'card' && rv.t > 3.4) setRide(rv.i + 1);
      // 파티클
      for (let k = parts.length - 1; k >= 0; k--) { const p = parts[k]; p.age += dt; if (p.age > p.life) { parts.splice(k, 1); continue; } p.x += p.vx * dt; p.y += p.vy * dt; p.vy -= 18 * dt; }
      for (let k = pops.length - 1; k >= 0; k--) { pops[k].age += dt * Math.min(2, sp); if (pops[k].age > pops[k].life) pops.splice(k, 1); }
    }
    function idxAt(R, t) { const A = R.A; let lo = 0, hi = A.length - 1; if (t >= A[hi]) return hi; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (A[m] <= t) lo = m; else hi = m; } return lo; }
    function sAt(R, t) {
      const A = R.A, S = R.rec.s, i = idxAt(R, t);
      if (i >= A.length - 1) return S[S.length - 1];
      const f = (t - A[i]) / Math.max(1e-6, A[i + 1] - A[i]);
      return S[i] + (S[i + 1] - S[i]) * U.clamp(f, 0, 1);
    }
    function drawRev(dt) {
      if (!rv) return;
      const sv = SITES[rv.si];
      if (rv.ph !== 'board' && rv.cur) {
        const R = rv.cur, rec = R.rec;
        let s = 11, v = 0, G = 1, y = ST_Y, tt = 0, shake = false, mood = '🙂';
        if (rv.ph === 'ride') {
          s = sAt(R, rv.t); const i = idxAt(R, rv.t); v = rec.v[i]; G = rec.g[i]; y = rec.y[i]; tt = rec.t[i];
          const pc = rec.p[i], c = pc >= 0 && pc < R.code.length ? R.code[pc] : '';
          mood = c === 'C' ? '😬' : G < 0.3 ? '😆' : G > 4 ? '😖' : v > 24 ? '😱' : v > 14 ? '😄' : '🙂';
        } else if (rv.ph === 'crash' || rv.ph === 'card') {
          s = sAt(R, R.dur); const i = rec.v.length - 1; v = rv.ph === 'crash' ? rec.v[i] * Math.max(0, 1 - rv.t) : 0; G = rec.g[i]; y = rec.y[i]; tt = rec.t[i];
          if (R.res[0] === 1 && rv.ph === 'crash') s -= Math.min(6, rv.t * rv.t * 2.2);
          if (R.res[0] === 1 && rv.ph === 'card') s -= 7;
          mood = R.res[0] ? '😵' : R.res[1] >= 75 ? '🤩' : R.res[1] >= 50 ? '😄' : '😐';
          shake = rv.ph === 'crash' && R.res[0] !== 1 && rv.t < 0.8;
        }
        // 카메라 따라가기
        const [hx] = pathAt(rec, s);
        if (followHold > 0) followHold -= dt;
        else { const want = hx - Vw.W / Vw.sc * 0.4; camX += (want - camX) * Math.min(1, dt * 10); clampCam(); }
        drawWorld(sv, P, -1);
        // 파티클 · 말풍선
        parts.forEach((p) => { ctx.globalAlpha = 1 - p.age / p.life; ctx.fillStyle = p.c; ctx.fillRect(X(p.x) - 2, Y(p.y) - 2, 4, 4); });
        ctx.globalAlpha = 1;
        drawTrain(rec, s, col(rv.i), mood, shake);
        pops.forEach((p) => { ctx.globalAlpha = Math.min(1, (p.life - p.age) * 2); label(X(p.x), Y(p.y) - 46 - p.age * 14, p.t, '#fff1c8'); });
        ctx.globalAlpha = 1;
        drawMini();
        drawHUD(v, G, y, tt);
        if (rv.ph === 'crash' || (rv.ph === 'card' && R.res[0])) label(Vw.W / 2, Vw.y0 + 76, '비상 정지! ' + FAIL[R.res[0]], '#ff8a78');
        if (rv.ph === 'card') drawCard(R, Math.min(1, rv.t * 3));
        if (rv.ph === 'intro') { ctx.globalAlpha = Math.min(1, (0.9 - rv.t) * 3); label(Vw.W / 2, (Vw.y0 + Vw.y1) / 2, nm(rv.i) + '의 코스터 출발!', '#ffe8a8'); ctx.globalAlpha = 1; }
      } else {
        drawWorld(sv, null, -1);
        drawBoard();
      }
      drawRevHead(sv);
    }
    function drawRevHead(sv) {
      ctx.fillStyle = 'rgba(16,11,22,.88)'; ctx.fillRect(0, 0, Vw.W, 42);
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      let x = 10;
      if (rv && rv.ph !== 'board') {
        ctx.fillStyle = col(rv.i); ctx.beginPath(); ctx.arc(x + 6, 15, 6, 0, 7); ctx.fill(); x += 18;
        ctx.fillStyle = '#f2e9d8'; ctx.font = '400 17px ' + DISP;
        let t = nm(rv.i) + '의 코스터';
        while (t.length > 3 && ctx.measureText(t).width > Vw.W - 120) t = t.slice(0, -2) + '…';
        ctx.fillText(t, x, 15);
      } else { ctx.fillStyle = '#f2e9d8'; ctx.font = '400 17px ' + DISP; ctx.fillText((st.last ? (st.solo ? '혼자 하기' : (st.last.r + 1) + '/' + st.R + '판') : '') + ' 심사 결과', x, 15); }
      ctx.font = '600 11px ' + FONT; ctx.fillStyle = '#ab9fb8';
      ctx.fillText(sv.e + ' ' + sv.n + ' · 오늘 날씨 마찰 ×' + (rv ? rv.w.toFixed(2) : '1.00') + (rv && rv.w > (sv.w[0] + sv.w[1]) / 2 + 0.04 ? ' (바람 셈)' : rv && rv.w < (sv.w[0] + sv.w[1]) / 2 - 0.04 ? ' (잔잔)' : ''), 10, 33);
      if (rv && rv.ph !== 'board' && st) { ctx.textAlign = 'right'; ctx.font = '600 12px ' + MONO; ctx.fillStyle = '#e3ae45'; ctx.fillText((rv.i + 1) + '/' + st.n, Vw.W - 10, 15); }
    }
    function bar(x, y, w, label0, v, max, c) {
      ctx.font = '600 12px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#d8cce6'; ctx.fillText(label0, x, y);
      const bx = x + 84, bw = w - 84 - 46;
      ctx.fillStyle = '#3a3048'; rr(bx, y - 4, bw, 8, 4); ctx.fill();
      ctx.fillStyle = c; if (v > 0) { rr(bx, y - 4, Math.max(6, bw * v / max), 8, 4); ctx.fill(); }
      ctx.textAlign = 'right'; ctx.font = '600 12px ' + MONO; ctx.fillStyle = '#f2e9d8'; ctx.fillText(v + '/' + max, x + w, y);
    }
    function comment(R) {
      const r = R.res, m = R.p.m;
      if (r[0]) return ['', '속도가 모자랐어요. 더 높이 올려요!', '꼭대기에서 느렸어요. 여유 속도를!', '골짜기·루프 바닥이 너무 빨랐어요', '언덕을 너무 빨리 넘었어요', '커브에 너무 빨리 들어갔어요'][r[0]];
      if (r[1] >= 85) return '전설의 코스터! 줄이 끝이 없어요';
      if (r[2] >= 28) return '비명이 끊이지 않아요!';
      if (r[3] < 12) return '짜릿하지만 좀 아파요…';
      if (r[2] < 12) return '조금 심심해요';
      if (r[4] >= 12) return '알뜰하게 잘 지었어요';
      if (m.inv >= 2) return '빙글빙글 신나요!';
      return '멋진 코스터예요!';
    }
    function drawCard(R, a) {
      const r = R.res, sv = SITES[rv.si], m = R.p.m;
      const w = Math.min(Vw.W - 24, 330), hh = 196, x = (Vw.W - w) / 2, y = Math.max(Vw.y0 + 4, Math.min((Vw.y0 + Vw.y1) / 2 - hh / 2, Vw.y1 - hh - 4));
      ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(28,21,38,.95)'; rr(x, y, w, hh, 16); ctx.fill();
      ctx.strokeStyle = col(rv.i); ctx.lineWidth = 2; rr(x, y, w, hh, 16); ctx.stroke();
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.font = '400 17px ' + DISP;
      let t = nm(rv.i); while (t.length > 2 && ctx.measureText(t).width > w - 110) t = t.slice(0, -2) + '…';
      ctx.fillText(t, x + 14, y + 22);
      ctx.textAlign = 'right'; ctx.font = '700 30px ' + MONO; ctx.fillStyle = r[0] ? '#ff8a78' : '#ffd36a'; ctx.fillText(String(r[1]), x + w - 14, y + 26);
      ctx.font = '600 10px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('점', x + w - 14, y + 46);
      ctx.textAlign = 'left'; ctx.font = '500 11.5px ' + FONT; ctx.fillStyle = '#ab9fb8';
      ctx.fillText(r[0] ? '시험 운행 실패 → 0점' : '최고 ' + kmh(m.vmax) + 'km/h · ' + m.gmax.toFixed(1) + 'G · 뒤집기 ' + m.inv + ' · 에어 ' + m.air.toFixed(1) + '초', x + 14, y + 46);
      const bw = w - 28;
      bar(x + 14, y + 70, bw, '짜릿함', r[2], 40, '#ff8a5a');
      bar(x + 14, y + 92, bw, '안전·편안함', r[3], 25, '#7fd0a0');
      bar(x + 14, y + 114, bw, '남은 예산', r[4], 15, '#e3ae45');
      bar(x + 14, y + 136, bw, '주문 보너스', r[5], 20, '#b08aff');
      ctx.font = '600 12.5px ' + FONT; ctx.fillStyle = '#ffe8c0'; ctx.textAlign = 'center';
      let cm = '“' + comment(R) + '”'; while (cm.length > 4 && ctx.measureText(cm).width > w - 20) cm = cm.slice(0, -3) + '…”';
      ctx.fillText(cm, x + w / 2, y + 162);
      if (!r[0]) {
        ctx.font = '500 11px ' + FONT; ctx.fillStyle = '#ab9fb8';
        let q = sv.req.map((rq) => (reqOk(rq, m) ? '✓' : '✗') + REQ_TXT[rq[0]](rq[1])).join('  ');
        while (q.length > 4 && ctx.measureText(q).width > w - 20) q = q.slice(0, -2) + '…';
        ctx.fillText(q, x + w / 2, y + 182);
      }
      ctx.globalAlpha = 1;
    }
    function drawBoard() {
      const last = st.last; if (!last) return;
      const n = st.n, rowH = 44, w = Math.min(Vw.W - 20, 360), hh = 56 + n * rowH, x = (Vw.W - w) / 2;
      const y = Math.max(52, Math.min((Vw.y0 + Vw.y1) / 2 - hh / 2, Vw.bot - hh - 6));
      ctx.fillStyle = 'rgba(28,21,38,.95)'; rr(x, y, w, hh, 16); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; rr(x, y, w, hh, 16); ctx.stroke();
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillStyle = '#e3ae45'; ctx.font = '400 17px ' + DISP;
      ctx.fillText(st.solo ? '심사 결과' : '이번 판 점수', x + 14, y + 22);
      ctx.textAlign = 'right'; ctx.font = '600 11px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText(st.solo ? '' : '이번 판 · 합계', x + w - 14, y + 22);
      const ord = last.res.map((_, i) => i).sort((a, b) => last.res[b][1] - last.res[a][1] || a - b);
      ord.forEach((i, k) => {
        const yy = y + 50 + k * rowH, r = last.res[i];
        ctx.fillStyle = k % 2 ? 'rgba(255,255,255,.03)' : 'rgba(255,255,255,.06)'; ctx.fillRect(x + 8, yy - 4, w - 16, rowH - 4);
        ctx.textAlign = 'left'; ctx.font = '700 15px ' + MONO; ctx.fillStyle = '#ffd36a'; ctx.fillText((last.res.filter((q) => q[1] > r[1]).length + 1) + '', x + 16, yy + 14);
        ctx.fillStyle = col(i); ctx.beginPath(); ctx.arc(x + 40, yy + 14, 6, 0, 7); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.font = '600 14px ' + FONT;
        let t = nm(i); while (t.length > 2 && ctx.measureText(t).width > w - 190) t = t.slice(0, -2) + '…';
        ctx.fillText(t, x + 52, yy + 9);
        ctx.font = '500 11px ' + FONT; ctx.fillStyle = r[0] ? '#ff8a78' : '#ab9fb8';
        ctx.fillText(r[0] ? '실패: ' + FAIL[r[0]] : '짜릿 ' + r[2] + ' · 안전 ' + r[3] + ' · 예산 ' + r[4] + ' · 주문 ' + r[5], x + 52, yy + 26);
        ctx.textAlign = 'right'; ctx.font = '700 17px ' + MONO; ctx.fillStyle = '#f2e9d8';
        ctx.fillText(st.solo ? String(r[1]) : r[1] + ' · ' + st.sc[i], x + w - 14, yy + 14);
      });
      if (st.solo) {
        const v = last.res[0][1], stars = STARS.filter((q) => v >= q).length;
        ctx.textAlign = 'center'; ctx.font = '700 22px ' + MONO; ctx.fillStyle = '#ffd36a';
        ctx.fillText('★'.repeat(stars) + '☆'.repeat(3 - stars), Vw.W / 2, y + hh + 22);
      }
    }

    /* ---- 손가락 ---- */
    function onDown(e) {
      if (dead || !st) return;
      const p = cv.local(e);
      if ((curMode === 'edit' || curMode === 'wait' || curMode === 'rev') && p.y >= Vw.my0 && p.y <= Vw.my0 + Vw.mh && mmC) {
        drag = { mm: true }; jumpMini(p.x); return;
      }
      if (p.y < Vw.y0 - 4 || p.y > Vw.y1 + 4) return;
      drag = { x: p.x, y: p.y, cam: camX, moved: false, id: e.pointerId };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
    }
    function jumpMini(px) { if (!mmC) return; const x = mmC.x0 + (px - 8 - 4) / mmC.sx; camX = x - Vw.W / Vw.sc / 2; camT = null; followHold = 3; clampCam(); }
    function onMove(e) {
      if (!drag) return;
      const p = cv.local(e);
      if (drag.mm) { jumpMini(p.x); return; }
      if (!drag.moved && Math.abs(p.x - drag.x) + Math.abs(p.y - drag.y) > 7) drag.moved = true;
      if (drag.moved) { camX = drag.cam - (p.x - drag.x) / Vw.sc; camT = null; followHold = 3; clampCam(); }
    }
    function onUp(e) {
      if (!drag) return;
      const d = drag; drag = null;
      if (d.mm || d.moved) return;
      if (curMode !== 'edit' || !P) return;
      const p = cv.local(e), s = editSeat(); if (s < 0) return;
      let best = -1, bd = 26;
      for (let k = 0; k < P.sh.qx.length; k++) { const dd = Math.hypot(X(P.sh.qx[k]) - p.x, Y(P.sh.qy[k]) - p.y); if (dd < bd) { bd = dd; best = k; } }
      const w = W(s);
      const ni = best >= 0 ? P.sh.pi[best] : -1;
      w.sel = ni === w.sel ? -1 : ni;
      Snd.tap(); api.buzz(6);
      if (w.sel >= 0) api.toast((w.sel + 1) + '번째 ' + PCS[P.code[w.sel]].n + ' 고름 · 새 조각은 이 뒤에 들어가요');
      syncStat(); syncPal();
    }
    function onWheel(e) { if (!st) return; camX += (e.deltaX || e.deltaY) / Vw.sc; camT = null; followHold = 3; clampCam(); e.preventDefault(); }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', () => { drag = null; });
    cv.cv.addEventListener('wheel', onWheel, { passive: false });

    /* ---- 키보드 · 패드 ---- */
    const offInput = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || dead) return;
      if (id === 'left' || id === 'right') { camX += (id === 'left' ? -1 : 1) * Vw.W / Vw.sc * 0.4; camT = null; followHold = 3; clampCam(); return; }
      if (curMode === 'rev' || curMode === 'wait') { if (id === 'done') pressRev(); return; }
      if (curMode !== 'edit') return;
      if (id === 'undo') undo(); else if (id === 'del') del(); else if (id === 'done') pressDone(); else if (id === 'fit') toggleFit(); else if (id === 'brief') { if (sheetEl) closeSheet(); else openBrief(); }
    }) : null;
    function onEsc(e) { if (e.key === 'Escape' && sheetEl) { e.preventDefault(); e.stopPropagation(); closeSheet(); } }
    addEventListener('keydown', onEsc, true);

    /* ---- 매 프레임 ---- */
    const stop = U.loop((dt, now) => {
      if (dead) return;
      clock = now;
      if (!st) return;
      let m = mode();
      if (m !== curMode) sync();
      // 설계 시간
      if (m === 'edit') {
        const s = editSeat();
        if (paused() || sheetEl) tPause[s] = (tPause[s] || 0) + dt * 1000;
        if (st.tl) {
          const left = st.tl - elapsed(s);
          const mm = Math.max(0, Math.ceil(left));
          bTime.textContent = Math.floor(mm / 60) + ':' + String(mm % 60).padStart(2, '0');
          bTime.classList.toggle('low', left < 30);
          if (left <= 10.5 && left > 0 && Math.ceil(left) !== lastTick) { lastTick = Math.ceil(left); Snd.tick(); if (lastTick <= 3) api.buzz(8); }
          if (left <= 0 && !paused()) { closeSheet(); submit(s, true); m = mode(); }
        } else bTime.textContent = '';
      } else if (m === 'wait') bTime.textContent = '';
      if (armedT && now - armedT > 2600) resetDone();
      if (m === 'rev' && rv && rv.done && st.ph === 'v' && autoT >= 0) {
        const before = Math.ceil(autoT); autoT -= dt * spd();
        if (Math.ceil(autoT) !== before) syncRev();
        if (autoT <= 0) { autoT = -1; if (api.mySeats().some((i) => !st.rd[i])) pressNext(); }
      }
      const vk = cv.w + 'x' + cv.h + ':' + m + ':' + (brief.classList.contains('cs-hid') ? 0 : brief.offsetTop + brief.offsetHeight) + ':' + bot.offsetHeight + ':' + fit + ':' + ((m === 'rev' && rv ? SITES[rv.si] : site()).n);
      if (vk !== Vw.key) layoutView();
      if (camT != null && (m !== 'edit' || drag)) camT = null;
      if (camT != null) { camX += (camT - camX) * Math.min(1, dt * 7); clampCam(); if (Math.abs(camT - camX) < 0.05) camT = null; }
      const sv = Vw.site;
      const sk = Vw.W + 'x' + Vw.H + ':' + cv.dpr + ':' + sv.n + ':' + Math.round(Vw.base);
      if (sk !== skyKey) { buildSky(sv); skyKey = sk; }
      try {
        ctx.drawImage(skyC, 0, 0, Vw.W, Vw.H);
        if (m === 'rev') { stepRev(dt); drawRev(dt); }
        else if (m === 'edit') drawEdit();
        else if (m === 'pick') drawPickBg();
        else drawWait();
      } catch (e) { if (!drawErr) { drawErr = 1; console.error(e); } }
    });

    return {
      update(s, prev) {
        st = s;
        if (!s) return;
        const k = rKey();
        if (s.ph === 'b' && k !== roundKey) {
          roundKey = k; work = {}; tStart = {}; tPause = {}; active = -1; sent = {}; fit = false; fitBtn.classList.remove('on');
          closeSheet(); Snd.bell(); Pkey = ''; rv = null;
        }
        if ((s.ph === 'v' || s.ph === 'end') && s.last && s.last.id !== revId) {
          closeSheet(); startRev(s);
          if (s.ph === 'end' && (!prev || prev.ph === 'end')) setRide(s.n);
        }
        if (s.ph === 'end' && s.solo && s.last && api.canAct(0)) {
          const v = s.last.res[0][1]; saveBest(s.last.si, STARS.filter((q) => v >= q).length, v);
        }
        if (s.ph === 'b') roundKey = k;
        sync();
      },
      destroy() {
        dead = true; stop(); if (offInput) offInput();
        removeEventListener('keydown', onEsc, true);
        clearTimeout(lpT);
        closeSheet(); if (handEl) handEl.remove(); if (pickEl) pickEl.remove();
        cv.destroy(); root.innerHTML = '';
      },
    };
  }

  /* ======================= 등록 ======================= */
  L.register({
    id: 'coaster', name: '롤러코스터 설계 대회', tag: '설계 · 물리 시험 운행', cat: '파티',
    blurb: '예산과 부지 안에서 레일 조각을 이어 롤러코스터를 설계해요. 실제 물리로 시험 운행해서 멈추거나 탈선하면 실패! 짜릿함·안전·예산으로 심사해요.',
    tint: '#6b2f6a',
    icon: '<path d="M4 46h48" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M6 44C10 20 16 12 20 12s6 10 8 22c2 10 6 12 10 6" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/><circle cx="41" cy="27" r="9" fill="none" stroke="currentColor" stroke-width="3.2"/><path d="M38 36c3 6 8 8 14 8" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/><path d="M14 46V26M24 46V24M34 46V40" stroke="currentColor" stroke-width="1.8" opacity=".55"/><rect x="15" y="9" width="9" height="5" rx="2" fill="currentColor" transform="rotate(20 19 11)"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: true, aiDelay: 3000,
    options: [
      { id: 'rounds', label: '판 수 (여럿이 할 때)', choices: [{ v: 2, label: '2판' }, { v: 3, label: '3판' }, { v: 4, label: '4판' }], def: 3 },
      { id: 'time', label: '설계 시간', choices: [{ v: 180, label: '3분' }, { v: 300, label: '5분' }, { v: 0, label: '제한 없음' }], def: 300 },
    ],
    quick: [
      '모두 같은 부지·예산·주문서를 받고, 레일 조각을 이어 롤러코스터를 설계해요.',
      '「완성!」하면 실제 물리로 시험 운행! 속도가 모자라 멈추거나, 너무 빨라 G가 세면 실패(0점).',
      '짜릿함 + 안전 + 남은 예산 + 주문 보너스로 심사해요. 판마다 점수를 더해 가장 높으면 우승!',
    ],
    rules: [
      { h: '목표', p: [
        '롤러코스터 설계 대결이에요. 같은 부지(땅 모양·높이 제한·길이)와 예산 안에서 가장 신나고 안전한 코스터를 만들어요.',
        '기본 3판(옵션 2·4판). 판마다 부지와 주문서가 바뀌어요. 점수를 모두 더해 가장 높은 사람이 우승해요.'] },
      { h: '설계하는 법', p: [
        '① 위쪽 주문서를 봐요(누르면 자세히). 요구 사항을 맞추면 칩에 ✓가 떠요.',
        '② 아래 조각을 누르면 트랙 끝(노란 ▼ 자리)에 붙어요. 조각을 꾹 누르면 설명이 나와요.',
        '③ 트랙의 조각을 누르면 골라져요(노란 빛). 그다음 누르는 조각은 그 뒤에 끼워 넣어지고, ✕를 누르면 고른 조각이 빠져요(안 고르면 맨 끝 조각). ↶는 되돌리기.',
        '④ 화면을 옆으로 끌면 트랙을 따라 움직여요. 위쪽 작은 지도를 눌러도 돼요. ⤢는 전체 보기.',
        '⑤ 다 되면 「완성!」을 두 번 눌러 제출. 설계 시간(기본 5분)이 끝나면 지금 설계 그대로 제출돼요.'] },
      { h: '조각', p: [
        '체인 오르막(80): 속도가 없어도 천천히 끌어 올려요(+12m). 처음엔 보통 체인으로 높이 올라가요.',
        '오르막(40) +10m · 내리막(40) −10m · 낙하(60) −20m · 큰 낙하(90) −35m · 평지(20) 8m.',
        '언덕(70): 빠르게 넘으면 몸이 붕 떠요(에어타임). 루프(160)·나선(170): 한 바퀴 뒤집혀요(뒤집기).',
        '커브(60): 기울어진 U턴. 부스터(140): 열차를 확 밀어 줘요. 브레이크(30): 시속 43km 넘으면 줄여 줘요.'] },
      { h: '물리 (쉽게)', p: [
        '높은 곳에서 내려가면 빨라지고, 올라가면 느려져요(에너지 보존). 바퀴·바람 마찰 때문에 조금씩 느려져요.',
        '트랙 색이 속도예요: 파랑 = 느림 → 노랑 → 빨강 = 빠름. 회색은 열차가 못 가는 곳이에요.',
        '루프·나선은 꼭대기에서도 충분히 빨라야 해요. 골짜기·루프 바닥을 너무 빨리 지나면 G(몸이 눌리는 힘)가 세져요.'] },
      { h: '실패 (0점)', p: [
        '멈춤: 오르막·언덕을 못 넘어요. · 꼭대기 속도 부족: 루프·나선 꼭대기에서 느려요.',
        'G 과다: 6G를 넘어요. · 튕김: 언덕을 너무 빨리 넘어 −2G보다 떠요. · 커브 쏠림: 옆 G 2.6 넘음.',
        '「!」 표시는 감점 위험, 「✗」는 실패 자리예요. 아래 줄에 「✓ 무사히 도착」이 떠야 안심!'] },
      { h: '날씨', p: [
        '시험 운행 날에는 바람·승객 무게로 마찰이 조금 달라져요(부지마다 범위가 달라요, 예: ×0.95~1.15).',
        '설계 중에는 범위의 양 끝을 미리 계산해서 「⚠ 날씨가 나쁘면 … 실패」처럼 알려 줘요. 속도에 여유를 두세요.'] },
      { h: '점수 (100점)', p: [
        '짜릿함 40: 최고 속도 · 낙하 높이 합 · 뒤집기 수 · 에어타임 · 센 G · 조각 종류.',
        '안전·편안함 25: 4.5G 넘음, −1G보다 뜸, 옆 1.6G 넘음, 너무 빠른 도착(시속 54km 넘음), 너무 심심함은 감점.',
        '남은 예산 15: 예산의 절반 이상 남기면 15점. 주문 보너스 20: 요구 사항을 나눠서 점수.',
        '짜릿함이 15점보다 낮으면 안전·예산 점수도 그만큼 줄어요(빈 트랙은 0점).'] },
      { h: '예시', p: [
        '체인 3개(39m) → 큰 낙하 → 루프 → 언덕 → 브레이크.',
        '→ 큰 낙하로 시속 90km! 루프 바닥이 5G쯤이라 「!」(감점)가 떠요. 큰 낙하 대신 낙하를 쓰면 G가 줄지만 루프 꼭대기가 느려질 수 있어요.',
        '→ 마지막에 브레이크를 두면 「도착이 빨라요」 감점이 없어져요.'] },
      { h: '여럿이 · 혼자', p: [
        '한 폰에서 여럿이 하면 이름이 뜰 때 폰을 넘겨 한 명씩 몰래 설계해요. 온라인·LAN이면 각자 폰에서 동시에.',
        '모두 내면 한 대씩 시험 운행을 보고 심사 점수가 나와요. 「▶▶ 넘기기」로 빨리 볼 수 있어요.',
        '혼자 하기: 부지 11곳 중 하나를 골라 도전해요. ★ ' + STARS[0] + ' · ★★ ' + STARS[1] + ' · ★★★ ' + STARS[2] + '점.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 대충 짓고 날씨를 생각 안 해서 가끔 실패해요. 어려움은 꼼꼼하게 다듬어요.'] },
      { h: 'PC 조작', p: [
        '마우스로 누르고 끌어요(휠 = 옆으로 이동). ←/→ 화면 이동, Z 되돌리기, Delete 빼기, F 전체 보기, B 주문서, Enter 완성(두 번)·넘기기.'] },
    ],
    tutorial: [
      { sel: '.cs-brief', text: '주문서예요. 부지 이름, 요구 사항(맞추면 ✓, 보너스 점수), 높이 제한·부지 길이, 남은 시간이 있어요. 누르면 자세히 보여요.' },
      { sel: '.cs-pal', text: '조각을 누르면 트랙 끝에 붙어요. 꾹 누르면 설명! 처음엔 체인으로 높이 올라간 다음 낙하로 시작해 보세요.' },
      { sel: '.cs-spot-view', text: '트랙 색은 속도예요(파랑 느림 → 빨강 빠름). 「!」는 감점 위험, 「✗」는 실패 자리. 옆으로 끌어서 보고, 조각을 누르면 골라서 그 뒤에 끼우거나 ✕로 빼요.' },
      { sel: '.cs-stat', text: '예산과 미리 계산한 결과예요. 「✓ 무사히 도착」이 떠야 안전해요. 날씨에 따라 마찰이 조금 달라지니 여유를 두세요.' },
      { sel: '.cs-done', text: '다 되면 「완성!」을 두 번. 모두 내면 한 대씩 시험 운행하고 심사해요!' },
    ],
    controls: [
      { id: 'left', label: '화면 왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '화면 오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'undo', label: '되돌리기', keys: ['KeyZ', 'Backspace'], pad: ['b'] },
      { id: 'del', label: '고른 조각 빼기', keys: ['Delete', 'KeyX'], pad: ['x'] },
      { id: 'fit', label: '전체 보기', keys: ['KeyF'], pad: ['y'] },
      { id: 'brief', label: '주문서 보기', keys: ['KeyB'], pad: ['back'] },
      { id: 'done', label: '완성 / 넘기기', keys: ['Enter', 'Space'], pad: ['a'] },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { PCS, TPL, SITES, SOLO, layout, simulate, judge, evalTrack, aiBuild, genTrack, groundAt, reqOk, REQ_TXT, STARS, FAIL },
  });
})();
