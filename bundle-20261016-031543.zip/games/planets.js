/* 행성 점령전 — realtime mini space strategy (2–8, one person per phone; bots fill the rest).
   Every owned planet grows ships by itself (bigger = faster). Pick your planet(s), tap another planet: the chosen
   share (25/50/100%) flies there as a stream of ships. Arrive with more than the defenders → captured.
   Special planets: 방어 행성(defenders count double), 조선소(double growth), 웜홀 쌍(launch from the twin),
   블랙홀(fleets crawl inside its pull). Maps: 8 symmetric galaxy styles generated from a seed, scaled by players.
   Network: host-authoritative fixed-step sim (1/20 s). The coarse state (setState) only holds the map seed,
   names, teams, phase and the final result; the map itself is rebuilt from the seed on every phone.
   Host streams compact snapshots (hostSend ~10 Hz: planet owners/counts + fleets); guests dead-reckon between
   snapshots and publish their orders [seq, sources, target, ratio]; the host applies unseen orders. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure) ======================= */
  const H = 1 / 20;                       // sim step (s)
  const SPEED = 52;                       // fleet speed (world units / s)
  const BH_SLOW = 0.4;                    // speed factor inside a black hole's pull
  const RAD = [0, 15, 21, 28];            // planet radius by size 1..3
  const RATE = [0, 0.45, 0.8, 1.25];      // ships / s by size
  const CAP = [0, 40, 70, 110];           // growth stops here
  const NORM = 0, FORT = 1, YARD = 2, WORM = 3;
  const MAXF = 90;                        // fleets in flight (snapshot budget)
  const COUNT = 3;
  const HOME_N = 30;
  const MAPS = [
    { v: 'ring', label: '고리 은하' }, { v: 'spiral', label: '나선 은하' }, { v: 'cluster', label: '성단 지대' },
    { v: 'hole', label: '블랙홀 중심' }, { v: 'yard', label: '조선소 전선' }, { v: 'fort', label: '요새 띠' },
    { v: 'worm', label: '웜홀 교차로' }, { v: 'scatter', label: '흩어진 별들' },
  ];
  const TEAMC = ['#5bb3e6', '#ee6a55', '#8fe3a8', '#e3ae45'];
  const TEAMN = ['청팀', '홍팀', '녹팀', '금팀'];

  function rng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const rateOf = (mp) => RATE[mp.s] * (mp.k === YARD ? 2 : mp.k === FORT ? 0.6 : 1);
  const capOf = (mp) => CAP[mp.s] * (mp.k === YARD ? 1.3 : 1);
  const defOf = (mp) => (mp.k === FORT ? 2 : 1);

  /* map: planets {x,y,s,k,tw,o,n} + black holes {x,y,r}. Rotationally symmetric so every start is fair. */
  function genMap(seed, mt, n, tm) {
    const R = rng(seed);
    const f = 1 + 0.1 * (Math.max(2, n) - 2);
    const w = Math.round(560 * f), h = Math.round(760 * f);
    const rx = w / 2 - 44, ry = h / 2 - 44, cx = w / 2, cy = h / 2;
    const sec = 2 * Math.PI / n, a0 = n === 2 ? -Math.PI / 2 : -Math.PI / 2 + Math.PI / n;
    const P = [], B = [];
    const toW = (r, a) => [cx + Math.cos(a) * r * rx, cy + Math.sin(a) * r * ry];
    const gap = (s1, s2) => RAD[s1] + RAD[s2] + 34;
    function fits(x, y, s) {
      if (x < RAD[s] + 10 || x > w - RAD[s] - 10 || y < RAD[s] + 10 || y > h - RAD[s] - 10) return false;
      for (const p of P) if (Math.hypot(p.x - x, p.y - y) < gap(p.s, s)) return false;
      for (const b of B) if (Math.hypot(b.x - x, b.y - y) < b.r * 0.55 + RAD[s]) return false;
      return true;
    }
    const garr = (s, k) => Math.round((s === 1 ? 5 + R() * 6 : s === 2 ? 11 + R() * 10 : 22 + R() * 14) * (k === FORT ? 1.5 : k === YARD ? 1.3 : 1));
    function addSym(r, off, s, k, g) {
      if (g == null) g = garr(s, k);
      const pts = [];
      for (let i = 0; i < n; i++) pts.push(toW(r, a0 + (i + off) * sec));
      for (let i = 0; i < pts.length; i++) {
        if (!fits(pts[i][0], pts[i][1], s)) return null;
        for (let j = 0; j < i; j++) if (Math.hypot(pts[i][0] - pts[j][0], pts[i][1] - pts[j][1]) < gap(s, s)) return null;
      }
      return pts.map(([x, y]) => P.push({ x: Math.round(x), y: Math.round(y), s, k, tw: -1, o: -1, n: g }) - 1);
    }
    function addOne(x, y, s, k, g) {
      if (!fits(x, y, s)) return -1;
      return P.push({ x: Math.round(x), y: Math.round(y), s, k, tw: -1, o: -1, n: g == null ? garr(s, k) : g }) - 1;
    }
    const mirror = (r, off, s, k) => { const g = garr(s, k); addSym(r, off, s, k, g); addSym(r, -off, s, k, g); };
    const pairOpp = (ids) => { // wormholes: sector i ↔ sector i + n/2 (even n only)
      if (!ids) return;
      if (n % 2) { ids.forEach((i) => { P[i].k = NORM; }); return; }
      for (let i = 0; i < n / 2; i++) { P[ids[i]].tw = ids[i + n / 2]; P[ids[i + n / 2]].tw = ids[i]; }
    };
    // homes: teammates sit side by side
    const order = []; for (let i = 0; i < n; i++) order.push(i);
    order.sort((a, b) => (tm[a] - tm[b]) || (a - b));
    for (let i = 0; i < n; i++) { const [x, y] = toW(0.9, a0 + i * sec); P.push({ x: Math.round(x), y: Math.round(y), s: 3, k: NORM, tw: -1, o: order[i], n: HOME_N }); }
    const j = () => (R() - 0.5) * 0.06;
    switch (MAPS[mt] ? MAPS[mt].v : 'ring') {
      case 'ring':
        addOne(cx, cy, 3, NORM, garr(3, NORM) + 10);
        mirror(0.64 + j(), 0.2 + R() * 0.08, 1, NORM);
        addSym(0.8 + j(), 0.5, 2, NORM);
        addSym(0.4 + j(), 0.5, 2, R() < 0.5 ? YARD : NORM);
        if (R() < 0.6) pairOpp(addSym(0.6, 0.5, 2, WORM));
        break;
      case 'spiral':
        B.push({ x: cx, y: cy, r: Math.round(0.17 * rx) });
        for (let k = 1; k <= 4; k++) addSym(0.88 - k * 0.15 + j(), k * 0.17, k % 2 ? 1 : 2, k === 3 ? YARD : NORM);
        addSym(0.72 + j(), 0.62, 1, NORM);
        addSym(0.5 + j(), 0.85, 2, R() < 0.5 ? FORT : NORM);
        break;
      case 'cluster': {
        addOne(cx, cy, 3, FORT, 34 + Math.round(R() * 10));
        const c = 0.56 + j();
        addSym(c - 0.06, -0.14, 1, NORM); addSym(c + 0.04, 0.12, 1, NORM); addSym(c + 0.14, -0.02, 1, R() < 0.4 ? YARD : NORM);
        mirror(0.8, 0.44, 1, NORM);
        addSym(0.3 + j(), 0.5, 2, NORM);
        break;
      }
      case 'hole':
        B.push({ x: cx, y: cy, r: Math.round(0.26 * rx) });
        mirror(0.47 + j(), 0.25, 2, NORM);
        addSym(0.68 + j(), 0, 1, NORM);
        addSym(0.76 + j(), 0.5, 2, R() < 0.5 ? FORT : NORM);
        pairOpp(addSym(0.36, 0.5, 2, WORM));
        break;
      case 'yard':
        addSym(0.66 + j(), 0.5, 2, YARD);
        mirror(0.7 + j(), 0.2, 1, NORM);
        addSym(0.38 + j(), 0, 1, NORM);
        addOne(cx, cy, 2, NORM);
        if (R() < 0.5) pairOpp(addSym(0.25, 0.5, 1, WORM));
        break;
      case 'fort':
        addOne(cx, cy, 3, FORT, 46);
        addSym(0.52 + j(), 0, 2, FORT);
        addSym(0.55 + j(), 0.5, 2, FORT);
        mirror(0.75 + j(), 0.24, 1, NORM);
        addSym(0.3, 0.5, 1, R() < 0.5 ? YARD : NORM);
        break;
      case 'worm': {
        addOne(cx, cy, 3, NORM);
        const gw = garr(2, WORM);
        const A = addSym(0.66 + j(), 0.27, 2, WORM, gw), Bq = addSym(0.66, -0.27, 2, WORM, gw);
        const m = Math.floor(n / 2);
        if (A && Bq) for (let i = 0; i < n; i++) { const a = A[i], b = Bq[(i + m) % n]; P[a].tw = b; P[b].tw = a; }
        else { (A || []).concat(Bq || []).forEach((i) => { P[i].k = NORM; }); }
        addSym(0.45 + j(), 0.5, 1, NORM);
        addSym(0.33 + j(), 0, 1, NORM);
        break;
      }
      default: { // scatter
        if (R() < 0.5) B.push({ x: cx, y: cy, r: Math.round(0.2 * rx) }); else addOne(cx, cy, 2 + (R() < 0.5 ? 1 : 0), R() < 0.3 ? FORT : NORM);
        const m = 3 + Math.floor(R() * 3);
        for (let k = 0; k < m; k++) {
          const s = R() < 0.45 ? 1 : R() < 0.8 ? 2 : 3, q = R();
          addSym(0.25 + R() * 0.6, R() - 0.5, s, q < 0.12 ? FORT : q < 0.24 ? YARD : NORM);
        }
        break;
      }
    }
    // make sure every sector has something to take
    for (let t = 0; t < 30 && P.length < n * 4 + 1; t++) addSym(0.3 + R() * 0.55, R() - 0.5, R() < 0.6 ? 1 : 2, NORM);
    // nearest lists (for AI) and travel geometry
    const N = P.length, D = [];
    for (let a = 0; a < N; a++) { D.push([]); for (let b = 0; b < N; b++) D[a].push(Math.hypot(P[a].x - P[b].x, P[a].y - P[b].y)); }
    const near = P.map((_, a) => P.map((__, b) => b).filter((b) => b !== a).sort((x, y) => D[a][x] - D[a][y]));
    return { w, h, n, P, B, D, near, G: {}, name: MAPS[mt] ? MAPS[mt].label : '' };
  }
  function geom(M, f, t) {
    const k = f * 256 + t;
    let g = M.G[k];
    if (!g) {
      const a = M.P[f], b = M.P[t], dx = b.x - a.x, dy = b.y - a.y, Ln = Math.hypot(dx, dy) || 1;
      g = M.G[k] = { ux: dx / Ln, uy: dy / Ln, d: Math.max(0, Ln - RAD[a.s] - RAD[b.s]) };
    }
    return g;
  }
  function fleetXY(M, fl) {
    const a = M.P[fl.f], g = geom(M, fl.f, fl.t), q = RAD[a.s] + Math.min(fl.p, g.d);
    return [a.x + g.ux * q, a.y + g.uy * q];
  }
  function fleetSpeed(M, fl) {
    if (!M.B.length) return SPEED;
    const [x, y] = fleetXY(M, fl);
    for (const b of M.B) if ((x - b.x) * (x - b.x) + (y - b.y) * (y - b.y) < b.r * b.r) return SPEED * BH_SLOW;
    return SPEED;
  }

  function newWorld(M) { return { t: 0, P: M.P.map((p) => ({ o: p.o, n: p.n })), F: [], el: Array(M.n).fill(-1), over: false }; }
  const sameTeam = (tm, a, b) => a >= 0 && b >= 0 && tm[a] === tm[b];
  function arrive(W, M, fl, tm) {
    const pl = W.P[fl.t], mp = M.P[fl.t];
    if (pl.o === fl.o || sameTeam(tm, pl.o, fl.o)) { pl.n += fl.n; return; }
    const m = defOf(mp), def = pl.n * m;
    if (fl.n > def) { pl.o = fl.o; pl.n = fl.n - def; } else pl.n = Math.max(0, pl.n - fl.n / m);
  }
  function alive(W, s) {
    for (const p of W.P) if (p.o === s) return true;
    for (const f of W.F) if (f.o === s) return true;
    return false;
  }
  function step(W, M, dt, tm, tl) {
    if (W.over) return;
    W.t += dt;
    for (let i = 0; i < W.P.length; i++) {
      const p = W.P[i];
      if (p.o < 0) continue;
      const mp = M.P[i], c = capOf(mp);
      if (p.n < c) p.n = Math.min(c, p.n + rateOf(mp) * dt);
    }
    for (let k = 0; k < W.F.length; k++) {
      const fl = W.F[k];
      fl.p += fleetSpeed(M, fl) * dt;
      if (fl.p >= fl.d) { arrive(W, M, fl, tm); W.F.splice(k, 1); k--; }
    }
    const teams = {};
    for (let s = 0; s < W.el.length; s++) {
      if (W.el[s] >= 0) continue;
      if (!alive(W, s)) W.el[s] = Math.round(W.t * 10) / 10; else teams[tm[s]] = 1;
    }
    if (Object.keys(teams).length <= 1 || (tl > 0 && W.t >= tl)) W.over = true;
  }
  /* send floor(ships × r%) from each own source to tgt. Returns ships sent. */
  function order(W, M, seat, srcs, tgt, r, tm) {
    if (W.over || W.el[seat] >= 0 || !(tgt >= 0 && tgt < W.P.length) || ![25, 50, 100].includes(r) || !Array.isArray(srcs)) return 0;
    let sent = 0;
    const seen = {};
    for (const s of srcs) {
      if (!(s >= 0 && s < W.P.length) || s === tgt || seen[s]) continue;
      seen[s] = 1;
      const pl = W.P[s];
      if (pl.o !== seat) continue;
      const k = Math.floor(Math.floor(pl.n) * r / 100);
      if (k < 1) continue;
      let from = s;
      const mp = M.P[s];
      if (mp.k === WORM && mp.tw >= 0 && (mp.tw === tgt || M.D[mp.tw][tgt] + 1 < M.D[s][tgt])) from = mp.tw;
      if (from === tgt) { pl.n -= k; arrive(W, M, { o: seat, n: k, f: from, t: tgt }, tm); sent += k; continue; }
      let fl = W.F.find((q) => q.o === seat && q.f === from && q.t === tgt && q.p < 10);
      if (!fl && W.F.length >= MAXF) fl = W.F.find((q) => q.o === seat && q.t === tgt);
      if (fl) fl.n += k;
      else if (W.F.length < MAXF) W.F.push({ o: seat, n: k, f: from, t: tgt, p: 0, d: geom(M, from, tgt).d });
      else continue;
      pl.n -= k; sent += k;
    }
    return sent;
  }
  function scores(W, n) {
    const sc = Array(n).fill(0), pl = Array(n).fill(0);
    for (const p of W.P) if (p.o >= 0) { sc[p.o] += Math.floor(p.n); pl[p.o]++; }
    for (const f of W.F) sc[f.o] += f.n;
    return { sc, pl };
  }

  /* ----- AI ----- */
  const AIP = { 1: { iv: 2.8, jit: 1.4, k: 1 }, 2: { iv: 1.6, jit: 0.6, k: 2 }, 3: { iv: 1.1, jit: 0.4, k: 2 } };
  function incoming(W, M) {
    const inc = W.P.map(() => []);
    for (const f of W.F) inc[f.t].push({ o: f.o, n: f.n, eta: (f.d - f.p) / SPEED });
    inc.forEach((l) => l.sort((a, b) => a.eta - b.eta));
    return inc;
  }
  /* predicted owner/garrison of planet j after T seconds (full = account for fleets already flying) */
  function proj(W, M, j, T, inc, tm, full, grow) {
    let o = W.P[j].o, n = W.P[j].n, t = 0;
    const mp = M.P[j], c = capOf(mp), m = defOf(mp);
    const g = (to) => { if (grow && o >= 0 && n < c) n = Math.min(c, n + rateOf(mp) * (to - t)); t = to; };
    if (full) for (const x of inc[j]) {
      if (x.eta > T) break;
      g(x.eta);
      if (x.o === o || sameTeam(tm, x.o, o)) n += x.n;
      else if (x.n > n * m) { n = x.n - n * m; o = x.o; } else n -= x.n / m;
    }
    g(T);
    return { o, n };
  }
  function aiThink(W, M, seat, lv, tm, tl) {
    const P = W.P, N = P.length, out = [];
    const my = []; for (let i = 0; i < N; i++) if (P[i].o === seat) my.push(i);
    if (!my.length) return out;
    const av = P.map((p) => Math.floor(p.n));
    const mine = (o) => o === seat || sameTeam(tm, o, seat);
    const pickR = (have, need, maxR) => { for (const r of [25, 50, 100]) { if (maxR && r > maxR) break; const k = Math.floor(have * r / 100); if (k >= need) return [r, k]; } return null; };
    const send = (s, t, r) => { const k = Math.floor(av[s] * r / 100); if (k < 1) return 0; av[s] -= k; out.push({ s: [s], t, r }); return k; };
    if (lv <= 1) {
      const src = my.filter((i) => av[i] >= 6);
      if (!src.length) return out;
      const s = src[Math.floor(Math.random() * src.length)];
      if (Math.random() < 0.15 && my.length > 1) { const t = my[Math.floor(Math.random() * my.length)]; if (t !== s) send(s, t, 50); return out; }
      const cand = M.near[s].filter((t) => !mine(P[t].o)).slice(0, 4);
      if (!cand.length) return out;
      const t = cand[Math.floor(Math.random() * cand.length)];
      send(s, t, Math.random() < 0.3 ? 100 : 50);
      return out;
    }
    const inc = incoming(W, M), full = lv >= 3;
    const threat = P.map((p, i) => inc[i].some((x) => !mine(x.o)));
    const front = P.map((p, i) => p.o === seat && M.near[i].some((t) => M.D[i][t] < 420 && P[t].o >= 0 && !mine(P[t].o)));
    // 1) defend planets that are about to fall
    for (const i of my) {
      if (out.length >= AIP[lv].k) break;
      if (!threat[i] || (lv === 2 && Math.random() < 0.5)) continue;
      const enemy = inc[i].filter((x) => !mine(x.o));
      const last = enemy[enemy.length - 1].eta;
      const r = proj(W, M, i, last + 0.05, inc, tm, true, true);
      if (mine(r.o)) continue;
      let need = Math.ceil(r.n / defOf(M.P[i])) + 2;
      for (const hp of M.near[i]) {
        if (need <= 0 || out.length >= AIP[lv].k) break;
        if (P[hp].o !== seat || threat[hp] || av[hp] < 3) continue;
        if (lv >= 3 && M.D[hp][i] / SPEED > last + 0.3) continue;
        const pr = pickR(av[hp], need);
        if (pr) { send(hp, i, pr[0]); need = 0; } else if (lv >= 3) need -= send(hp, i, 50);
      }
    }
    // 2) attack / expand (lv3: sees fleets already flying, skips neutrals that won't pay back before time runs out,
    //    snipes weakened planets and gangs up from several planets when one is not enough)
    const rem = tl > 0 ? tl - W.t : 1e9;
    let guard = 0;
    while (out.length < AIP[lv].k && guard++ < 4) {
      let best = null;
      for (let j = 0; j < N; j++) {
        if (mine(P[j].o)) continue;
        const mp = M.P[j], foe = P[j].o >= 0;
        const val = rateOf(mp) + (foe ? 0.5 : 0) + (mp.k === YARD ? 0.6 : 0);
        let found = false;
        for (const s of my) {
          if (av[s] < 6 || threat[s]) continue;
          const T = M.D[s][j] / SPEED, pr = proj(W, M, j, T, inc, tm, full, true);
          if (mine(pr.o)) continue;
          const need = Math.ceil(pr.n * defOf(mp) * 1.1) + 2 + (foe ? 2 : 0);
          if (full && !foe && T + need / rateOf(mp) > rem) continue;
          const rk = pickR(av[s], need, front[s] ? 50 : 100);
          if (!rk) continue;
          found = true;
          const sc = (val + (full && foe && pr.n < 6 ? 0.6 : 0)) / (need + 6) / (1 + T * 0.25);
          if (!best || sc > best.sc) best = { sc, plan: [[s, rk[0]]], t: j };
        }
        if (found || !full) continue;
        let tot = 0, Tm = 0, plan = [], firstD = -1;
        for (const s of M.near[j]) {
          if (P[s].o !== seat || threat[s] || av[s] < 4) continue;
          if (firstD < 0) firstD = M.D[s][j];
          else if (M.D[s][j] > firstD * 1.7 + 60) break;
          Tm = Math.max(Tm, M.D[s][j] / SPEED);
          const pr = proj(W, M, j, Tm, inc, tm, true, true);
          if (mine(pr.o)) break;
          const need = Math.ceil(pr.n * defOf(mp) * 1.15) + 2;
          if (!foe && Tm + need / rateOf(mp) > rem) break;
          const maxR = front[s] ? 50 : 100; // keep a guard on the frontline
          let rk = null;
          for (const r of [25, 50, 100]) { if (r > maxR) break; rk = [r, Math.floor(av[s] * r / 100)]; if (rk[1] >= need - tot) break; }
          if (!rk || rk[1] < 1) continue;
          plan.push([s, rk[0]]); tot += rk[1];
          if (tot >= need) {
            const sc = 0.85 * (val + (foe && pr.n < 6 ? 0.6 : 0)) / (need + 6) / (1 + Tm * 0.25);
            if (!best || sc > best.sc) best = { sc, plan: plan.slice(), t: j };
            break;
          }
          if (plan.length >= 3) break;
        }
      }
      if (!best) break;
      for (const [s, r] of best.plan) send(s, best.t, r);
    }
    // 3) nothing to do: move surplus from full rear planets to the front
    if (!out.length && lv >= 2) {
      for (const i of my) {
        if (front[i] || av[i] < capOf(M.P[i]) * 0.9) continue;
        const f = M.near[i].find((t) => front[t] && P[t].o === seat);
        if (f != null) { send(i, f, 50); break; }
      }
    }
    return out;
  }

  /* ----- coarse state ----- */
  function teamsFor(n, mode) {
    const tm = [];
    for (let i = 0; i < n; i++) tm.push(mode === 'two' ? i % 2 : mode === 'pair' ? Math.floor(i / 2) : i);
    if (new Set(tm).size < 2) return tm.map((_, i) => i);
    return tm;
  }
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    const mode = ['ffa', 'two', 'pair'].includes(o.team) ? o.team : 'ffa';
    let mt = MAPS.findIndex((m) => m.v === o.map);
    if (mt < 0) mt = U.rand(MAPS.length);
    const tl = [180, 300, 480, 720].includes(+o.time) ? +o.time : 300;
    const tm = teamsFor(n, mode);
    return { rid: 1 + U.rand(999999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), tm, mode: n > 2 || mode === 'ffa' ? mode : 'ffa',
      mt, seed: 1 + U.rand(2147483000), tl, ph: 'count', res: null };
  }
  function finish(st, W) {
    const n = st.n, { sc, pl } = scores(W, n);
    const tsc = {}, tpl = {}, al = {};
    for (let s = 0; s < n; s++) { const t = st.tm[s]; tsc[t] = (tsc[t] || 0) + sc[s]; tpl[t] = (tpl[t] || 0) + pl[s]; if (W.el[s] < 0) al[t] = 1; }
    let teams = Object.keys(al).map(Number);
    if (!teams.length) teams = Object.keys(tsc).map(Number);
    let top = [];
    for (const t of teams) {
      if (!top.length) { top = [t]; continue; }
      const a = top[0];
      if (tsc[t] > tsc[a] || (tsc[t] === tsc[a] && tpl[t] > tpl[a])) top = [t];
      else if (tsc[t] === tsc[a] && tpl[t] === tpl[a]) top.push(t);
    }
    const w = []; for (let s = 0; s < n; s++) if (top.includes(st.tm[s])) w.push(s);
    const why = Object.keys(al).length <= 1 ? 'elim' : 'time';
    return Object.assign({}, st, { ph: 'done', res: { w, sc, pl, el: W.el.map((v) => (v < 0 ? -1 : Math.round(v))), why, t: Math.round(W.t) } });
  }
  function result(st) {
    if (!st || st.ph !== 'done' || !st.res) return null;
    const R = st.res, n = st.n, team = st.mode !== 'ffa';
    const idx = []; for (let s = 0; s < n; s++) idx.push(s);
    idx.sort((a, b) => ((R.el[b] < 0) - (R.el[a] < 0)) || (R.el[a] < 0 ? (R.sc[b] - R.sc[a]) || (R.pl[b] - R.pl[a]) : R.el[b] - R.el[a]));
    const lines = idx.map((s, k) => (k + 1) + '. ' + st.nm[s] + (team ? ' (' + TEAMN[st.tm[s] % 4] + ')' : '') + ' — ' + (R.el[s] >= 0 ? '탈락 ' + fmtT(R.el[s]) : '함선 ' + R.sc[s] + ' · 행성 ' + R.pl[s]));
    let title;
    if (!R.w.length) title = '무승부';
    else if (team) title = (R.w.length && new Set(R.w.map((s) => st.tm[s])).size === 1 ? TEAMN[st.tm[R.w[0]] % 4] + ' 승리!' : '공동 승리!');
    else title = R.w.length === 1 ? st.nm[R.w[0]] + ' 승리!' : '공동 승리!';
    const why = R.why === 'elim' ? '모두 물리쳤어요!' : '시간 종료 — 함선이 가장 많아요';
    return { winners: R.w.slice(), title, text: why + '\n' + lines.join('\n') };
  }
  function fmtT(s) { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const NEUTRAL = '#7d7590';
  const KNAME = ['행성', '방어 행성', '조선소', '웜홀'];
  const SIZEN = ['', '작은', '중간', '큰'];
  const CSS = `
.pl-bar{position:absolute;left:0;right:0;bottom:0;z-index:5;display:flex;gap:6px;align-items:center;padding:8px 8px calc(8px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(18,14,25,.6),rgba(18,14,25,.96) 30%)}
.pl-seg{display:flex;flex:1 1 auto;min-width:0;gap:3px;padding:3px;border-radius:13px;background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.08)}
.pl-seg button{flex:1;min-width:0;min-height:44px;border:0;border-radius:10px;background:transparent;color:#ab9fb8;font:700 15px "IBM Plex Mono",monospace;touch-action:manipulation;cursor:pointer}
.pl-seg button.on{background:#e3ae45;color:#17131f}
.pl-b{flex:0 0 auto;min-width:54px;min-height:50px;padding:0 10px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:#2e2640;color:#f2e9d8;font:700 14px "IBM Plex Sans KR",sans-serif;touch-action:manipulation;cursor:pointer}
.pl-b.on{background:#4a3b66;border-color:#e3ae45}
.pl-b:active,.pl-seg button:active{transform:scale(.96)}
.pl-note{flex:1;color:#ab9fb8;font:600 13px "IBM Plex Sans KR",sans-serif;text-align:center}
.pl-hint{position:absolute;left:8px;right:8px;z-index:4;text-align:center;color:#f2e9d8;font:600 12.5px/1.3 "IBM Plex Sans KR",sans-serif;text-shadow:0 1px 3px #000,0 0 6px #000;pointer-events:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pl-tip{position:absolute;left:50%;bottom:120px;transform:translate(-50%,6px);z-index:7;width:max-content;max-width:calc(100% - 28px);box-sizing:border-box;padding:10px 14px;border-radius:14px;background:rgba(23,19,31,.96);border:1px solid rgba(227,174,69,.55);box-shadow:0 6px 20px rgba(0,0,0,.35);color:#f2e9d8;font:600 13px/1.5 "IBM Plex Sans KR",sans-serif;word-break:keep-all;pointer-events:none;opacity:0;transition:opacity .4s,transform .4s}
.pl-tip.on{opacity:1;transform:translate(-50%,0)}
.pl-tip b{display:block;color:#e3ae45;margin-bottom:2px}
`;
  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const me = () => { const m = mine(); return m.length ? m[0] : -1; };
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; return !!p.ai || !!p.local; };
    const colOf = (o) => (o >= 0 && api.players[o] ? api.players[o].color : NEUTRAL);

    let st = null, key = null, M = null, W = null, phase = 'wait', cd = 0, acc = 0, sentPlay = false, sentDone = false;
    let aiMem = [], fast = 1;
    let sel = new Set(), ratio = 50, focus = -1, hover = -1;
    let cam = { x: 0, y: 0, z: 1 }, VR = { x: 0, y: 44, w: 1, h: 1 }, fitZ = 1, barH = 66;
    let fx = [], banner = null, lastO = null, lastEl = null, info = null, tipEl = null, firstSent = false;
    let stars = null;
    // net
    let pubT = 0, hsQ = 0, lastQ = -1, myOrders = [], ordSeq = 0, snapAt = 0;
    const remSeen = {};

    /* ----- DOM: bottom bar + hint ----- */
    const hint = L.h('div', { class: 'pl-hint' });
    const bar = L.h('div', { class: 'pl-bar' });
    root.appendChild(hint); root.appendChild(bar);
    const noFocus = (e) => { e.preventDefault(); e.stopPropagation(); };
    bar.addEventListener('pointerdown', noFocus);
    let barSig = '', segBtns = {}, allBtn = null, zoomBtn = null, fastBtn = null;
    function role() {
      if (!st) return 'none';
      const m = me();
      if (m < 0) return 'watch';
      if (st.ph === 'done') return 'done';
      if (W && W.el[m] >= 0) return 'out';
      return 'play';
    }
    function buildBar() {
      const r = role(), sig = r + (api.online ? 'o' : 'l');
      if (sig === barSig) return;
      barSig = sig; bar.innerHTML = ''; segBtns = {}; allBtn = null; fastBtn = null;
      zoomBtn = L.h('button', { class: 'pl-b', 'aria-label': '확대 / 전체 보기', text: '🔍', onclick: () => { toggleZoom(); api.sfx('click'); } });
      if (r === 'play') {
        const seg = L.h('div', { class: 'pl-seg', role: 'group', 'aria-label': '보낼 비율' });
        for (const v of [25, 50, 100]) { segBtns[v] = L.h('button', { text: v + '%', onclick: () => setRatio(v) }); seg.appendChild(segBtns[v]); }
        allBtn = L.h('button', { class: 'pl-b', text: '모두', 'aria-label': '내 행성 모두 고르기', onclick: () => { selectAll(); } });
        bar.append(seg, allBtn, zoomBtn);
        setRatio(ratio, true);
      } else {
        bar.append(L.h('div', { class: 'pl-note', text: r === 'out' ? '탈락 — 관전 중' : r === 'done' ? '게임 끝' : 'AI끼리 대결 중' }));
        if (!api.online && (r === 'out' || r === 'watch')) {
          fastBtn = L.h('button', { class: 'pl-b' + (fast > 1 ? ' on' : ''), text: fast > 1 ? '⏩ 4배' : '⏩ 빠르게', onclick: () => { fast = fast > 1 ? 1 : 4; fastBtn.textContent = fast > 1 ? '⏩ 4배' : '⏩ 빠르게'; fastBtn.classList.toggle('on', fast > 1); api.sfx('click'); } });
          bar.append(fastBtn);
        }
        bar.append(zoomBtn);
      }
      layout();
    }
    function setRatio(v, quiet) {
      ratio = v;
      for (const k in segBtns) segBtns[k].classList.toggle('on', +k === v);
      if (!quiet) { api.sfx('tick'); api.buzz(8); }
    }

    /* ----- camera ----- */
    function layout() {
      if (!M) return;
      barH = Math.max(56, Math.round(bar.getBoundingClientRect().height || 66));
      hint.style.bottom = (barH + 2) + 'px';
      VR = { x: 0, y: 46, w: cv.w, h: Math.max(80, cv.h - 46 - barH - 22) };
      const oldFit = fitZ;
      fitZ = Math.min((VR.w - 12) / M.w, (VR.h - 6) / M.h);
      if (!cam.init || Math.abs(cam.z - oldFit) < 1e-6) { cam.z = fitZ; cam.x = M.w / 2; cam.y = M.h / 2; cam.init = true; }
      clampCam();
      stars = null;
    }
    cv.onresize = () => layout();
    function clampCam() {
      if (!M) return;
      cam.z = U.clamp(cam.z, fitZ, fitZ * 3.2);
      const hw = VR.w / 2 / cam.z, hh = VR.h / 2 / cam.z;
      cam.x = M.w <= hw * 2 ? M.w / 2 : U.clamp(cam.x, hw - 20, M.w - hw + 20);
      cam.y = M.h <= hh * 2 ? M.h / 2 : U.clamp(cam.y, hh - 20, M.h - hh + 20);
    }
    const sx = (x) => VR.x + VR.w / 2 + (x - cam.x) * cam.z;
    const sy = (y) => VR.y + VR.h / 2 + (y - cam.y) * cam.z;
    const wx = (px) => cam.x + (px - VR.x - VR.w / 2) / cam.z;
    const wy = (py) => cam.y + (py - VR.y - VR.h / 2) / cam.z;
    function zoomAt(px, py, z) {
      const X = wx(px), Y = wy(py);
      cam.z = U.clamp(z, fitZ, fitZ * 3.2);
      cam.x = X - (px - VR.x - VR.w / 2) / cam.z; cam.y = Y - (py - VR.y - VR.h / 2) / cam.z;
      clampCam();
    }
    function toggleZoom() {
      if (!M) return;
      if (cam.z > fitZ * 1.05) { cam.z = fitZ; cam.x = M.w / 2; cam.y = M.h / 2; clampCam(); return; }
      let c = null;
      const pts = sel.size ? [...sel] : focus >= 0 ? [focus] : W ? W.P.map((p, i) => (p.o === me() ? i : -1)).filter((i) => i >= 0) : [];
      if (pts.length) { let X = 0, Y = 0; pts.forEach((i) => { X += M.P[i].x; Y += M.P[i].y; }); c = [X / pts.length, Y / pts.length]; }
      cam.z = fitZ * 2; if (c) { cam.x = c[0]; cam.y = c[1]; }
      clampCam();
    }
    const pr = (i) => Math.max(RAD[M.P[i].s] * cam.z, 6 + M.P[i].s * 2.5);
    function planetAt(px, py, extra) {
      if (!M) return -1;
      let best = -1, bd = 1e9;
      for (let i = 0; i < M.P.length; i++) {
        const d = Math.hypot(sx(M.P[i].x) - px, sy(M.P[i].y) - py), lim = Math.max(24, pr(i) + (extra == null ? 12 : extra));
        if (d < lim && d < bd) { bd = d; best = i; }
      }
      return best;
    }
    function ensureVisible(i) {
      const x = sx(M.P[i].x), y = sy(M.P[i].y);
      if (x < VR.x + 30 || x > VR.x + VR.w - 30 || y < VR.y + 30 || y > VR.y + VR.h - 30) { cam.x = M.P[i].x; cam.y = M.P[i].y; clampCam(); }
    }

    /* ----- play actions ----- */
    const canPlay = () => st && st.ph === 'play' && W && role() === 'play';
    const own = (i) => W && i >= 0 && W.P[i].o === me() && me() >= 0;
    function shipsFor(srcs) { let k = 0; for (const s of srcs) if (own(s)) k += Math.floor(Math.floor(W.P[s].n) * ratio / 100); return k; }
    function showInfo(i) {
      const mp = M.P[i], p = W.P[i];
      const who = p.o < 0 ? '중립' : p.o === me() ? '내' : (st.nm[p.o] || '') + '의';
      let t = who + ' ' + (mp.k === NORM ? SIZEN[mp.s] + ' 행성' : KNAME[mp.k]) + ' · 함선 ' + Math.floor(p.n);
      if (mp.k === FORT) t += ' · 지키는 함선 1척이 2척 몫';
      else if (mp.k === YARD) t += ' · 함선이 2배 빨리 늘어요';
      else if (mp.k === WORM) t += ' · 짝 웜홀에서 출발할 수 있어요';
      else t += ' · 1초에 +' + rateOf(mp).toFixed(1);
      info = { text: t, t: 2.6 };
    }
    function sendTo(t) {
      if (!canPlay() || !sel.size) return;
      const srcs = [...sel].filter((s) => s !== t && own(s));
      if (!srcs.length) return;
      const k = shipsFor(srcs);
      if (k < 1) { info = { text: '보낼 함선이 모자라요 — 비율을 올려 보세요', t: 2 }; api.buzz(30); return; }
      const m = me();
      if (host()) order(W, M, m, srcs, t, ratio, st.tm);
      else {
        ordSeq = (ordSeq + 1) % 100000;
        myOrders.push([ordSeq, srcs, t, ratio]); if (myOrders.length > 8) myOrders.shift();
        for (const s of srcs) { const pl = W.P[s]; pl.n -= Math.floor(Math.floor(pl.n) * ratio / 100); } // optimistic
        pubT = 0;
      }
      fx.push({ kind: 'send', i: t, age: 0, col: colOf(m) });
      api.sfx('whoosh'); api.buzz(14);
      sel.clear(); firstSent = true;
    }
    function tapPlanet(i) {
      if (!W || i < 0) { sel.clear(); return; }
      if (!canPlay()) { showInfo(i); return; }
      if (sel.size) {
        if (sel.has(i)) { sel.delete(i); api.sfx('click'); return; }
        sendTo(i); return;
      }
      if (own(i)) { sel.add(i); api.sfx('tick'); api.buzz(8); return; }
      showInfo(i);
    }
    function selectAll() {
      if (!canPlay()) return;
      const all = W.P.map((p, i) => (p.o === me() ? i : -1)).filter((i) => i >= 0);
      if (all.length && all.every((i) => sel.has(i))) sel.clear(); else { sel = new Set(all); }
      api.sfx('tick'); api.buzz(8);
    }

    /* ----- pointer input ----- */
    const ptrs = new Map();
    let gest = null; // {mode:'sweep'|'pan'|'pinch', ...}
    function onDown(e) {
      e.preventDefault();
      if (!M) return;
      const p = cv.local(e);
      ptrs.set(e.pointerId, p);
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        gest = { mode: 'pinch', d: Math.max(20, Math.hypot(a.x - b.x, a.y - b.y)), z: cam.z, X: wx((a.x + b.x) / 2), Y: wy((a.y + b.y) / 2) };
        return;
      }
      if (ptrs.size > 2) return;
      if (e.button === 2) { sel.clear(); return; }
      const hit = planetAt(p.x, p.y);
      if (hit >= 0 && own(hit) && canPlay()) gest = { mode: 'sweep', start: hit, sw: [hit], x0: p.x, y0: p.y, x: p.x, y: p.y, moved: false };
      else gest = { mode: 'pan', hit, x0: p.x, y0: p.y, cx: cam.x, cy: cam.y, moved: false };
    }
    function onMove(e) {
      if (!M) return;
      const p = cv.local(e);
      if (e.pointerType === 'mouse' && !ptrs.size) { hover = planetAt(p.x, p.y); return; }
      if (!ptrs.has(e.pointerId)) return;
      ptrs.set(e.pointerId, p);
      if (!gest) return;
      if (gest.mode === 'pinch') {
        if (ptrs.size < 2) return;
        const [a, b] = [...ptrs.values()], d = Math.max(20, Math.hypot(a.x - b.x, a.y - b.y));
        const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        cam.z = U.clamp(gest.z * d / gest.d, fitZ, fitZ * 3.2);
        cam.x = gest.X - (mx - VR.x - VR.w / 2) / cam.z; cam.y = gest.Y - (my - VR.y - VR.h / 2) / cam.z;
        clampCam(); return;
      }
      if (Math.hypot(p.x - gest.x0, p.y - gest.y0) > 9) gest.moved = true;
      if (gest.mode === 'sweep') {
        gest.x = p.x; gest.y = p.y;
        const h = planetAt(p.x, p.y, 4);
        hover = h;
        if (h >= 0 && own(h) && !gest.sw.includes(h)) { gest.sw.push(h); api.sfx('tick'); api.buzz(6); }
      } else if (gest.mode === 'pan' && gest.moved) {
        cam.x = gest.cx - (p.x - gest.x0) / cam.z; cam.y = gest.cy - (p.y - gest.y0) / cam.z; clampCam();
      }
    }
    function onUp(e) {
      const had = ptrs.has(e.pointerId);
      ptrs.delete(e.pointerId);
      if (!had || !gest || !M) return;
      if (gest.mode === 'pinch') { if (!ptrs.size) gest = null; return; }
      const p = cv.local(e), g = gest; gest = null;
      if (e.type === 'pointercancel') return;
      if (g.mode === 'sweep') {
        if (!g.moved) { tapPlanet(g.start); return; }
        const t = planetAt(p.x, p.y, 4);
        if (sel.size && !g.sw.every((i) => sel.has(i))) sel.clear();
        g.sw.forEach((i) => sel.add(i));
        if (t >= 0 && !own(t)) sendTo(t);
        else if (t >= 0 && own(t) && !g.sw.includes(t)) sendTo(t);
        return;
      }
      if (!g.moved) {
        if (g.hit >= 0) tapPlanet(g.hit);
        else if (sel.size) { sel.clear(); api.sfx('click'); }
      }
    }
    function onWheel(e) {
      e.preventDefault();
      const p = cv.local(e);
      zoomAt(p.x, p.y, cam.z * (e.deltaY < 0 ? 1.15 : 1 / 1.15));
    }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('pointerleave', () => { if (!ptrs.size) hover = -1; });
    cv.cv.addEventListener('wheel', onWheel, { passive: false });
    cv.cv.addEventListener('contextmenu', noCtx);

    /* keyboard / gamepad: move a focus ring between planets, pick = tap */
    function moveFocus(dx, dy) {
      if (!M) return;
      let from = focus;
      if (from < 0) { const m = me(); from = W ? W.P.findIndex((p) => p.o === m) : -1; if (from < 0) from = 0; focus = from; ensureVisible(focus); return; }
      const a = M.P[from];
      let best = -1, bs = 1e9;
      for (let i = 0; i < M.P.length; i++) {
        if (i === from) continue;
        const vx = M.P[i].x - a.x, vy = M.P[i].y - a.y, d = Math.hypot(vx, vy) || 1, dot = (vx * dx + vy * dy) / d;
        if (dot < 0.4) continue;
        const s = d * (2.2 - dot);
        if (s < bs) { bs = s; best = i; }
      }
      if (best >= 0) { focus = best; ensureVisible(best); api.sfx('tick'); }
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      if (id === 'up') moveFocus(0, -1); else if (id === 'down') moveFocus(0, 1);
      else if (id === 'left') moveFocus(-1, 0); else if (id === 'right') moveFocus(1, 0);
      else if (id === 'pick') { if (focus < 0) moveFocus(0, 0); else tapPlanet(focus); }
      else if (id === 'cancel') { sel.clear(); api.sfx('click'); }
      else if (id === 'all') selectAll();
      else if (id === 'ratio') setRatio(ratio === 25 ? 50 : ratio === 50 ? 100 : 25);
      else if (id === 'r25') setRatio(25); else if (id === 'r50') setRatio(50); else if (id === 'r100') setRatio(100);
      else if (id === 'zoom') toggleZoom();
    }) : () => {};

    /* ----- host / guest flow ----- */
    function startGame() {
      M = genMap(st.seed, st.mt, st.n, st.tm);
      W = newWorld(M);
      aiMem = []; for (let s = 0; s < st.n; s++) aiMem.push({ next: 0.6 + Math.random() * 1.2 });
      phase = st.ph; cd = COUNT; acc = 0; sentPlay = false; sentDone = false;
      sel.clear(); focus = -1; fx = []; banner = null; lastO = W.P.map((p) => p.o); lastEl = W.el.slice();
      myOrders = []; lastQ = -1; cam.init = false; barSig = '';
      buildBar(); layout();
      if (!tipEl && me() >= 0) tipEl = firstTip();
    }
    function firstTip() {
      try { if (localStorage.getItem('lounge.tip.planets')) return null; localStorage.setItem('lounge.tip.planets', '1'); } catch (e) { /* show anyway */ }
      const el = L.h('div', { class: 'pl-tip', role: 'status' }, L.h('b', { text: '처음이라면 이렇게!' }),
        L.h('div', { text: '① 반짝이는 내 행성을 톡 (끌면 여러 개)' }), L.h('div', { text: '② 보낼 행성을 톡 → 함선이 날아가요' }),
        L.h('div', { text: '아래 25·50·100%로 보낼 양을 골라요' }));
      el.style.bottom = (barH + 30) + 'px';
      root.appendChild(el);
      requestAnimationFrame(() => el.classList.add('on'));
      const tm = setTimeout(() => { el.classList.remove('on'); setTimeout(() => el.remove(), 450); }, 7000);
      return { remove() { clearTimeout(tm); el.remove(); } };
    }
    function aiTick() {
      for (let s = 0; s < st.n; s++) {
        const p = api.players[s];
        if (!p || !simHere(s) || W.el[s] >= 0) continue;
        const isAI = !!p.ai, drive = isAI || (auto() && s === me());
        if (!drive) continue;
        const mem = aiMem[s];
        if (W.t < mem.next) continue;
        const lv = isAI ? (p.lv || 2) : 3, C = AIP[lv] || AIP[2];
        mem.next = W.t + C.iv + Math.random() * C.jit;
        for (const o of aiThink(W, M, s, lv, st.tm, st.tl)) order(W, M, s, o.s, o.t, o.r, st.tm);
      }
    }
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem) return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.n) || simHere(s) || !o || o.k !== key || !Array.isArray(o.o)) continue;
        const seen = remSeen[key + ':' + s] || (remSeen[key + ':' + s] = { q: -1 });
        for (const od of o.o) {
          if (!Array.isArray(od) || !(od[0] > seen.q)) continue;
          seen.q = od[0];
          if (st.ph === 'play') order(W, M, s, od[1], od[2] | 0, od[3] | 0, st.tm);
        }
      }
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || hs.k !== key || hs.q === lastQ) return;
      lastQ = hs.q; snapAt = performance.now();
      W.t = (+hs.t || 0) / 10;
      if (Array.isArray(hs.p)) for (let i = 0; i < W.P.length; i++) { const o = hs.p[i * 2], n = hs.p[i * 2 + 1]; if (o != null) { W.P[i].o = o | 0; W.P[i].n = +n || 0; } }
      if (Array.isArray(hs.f)) {
        const F = [];
        for (let i = 0; i + 4 < hs.f.length + 0; i += 5) {
          const f = hs.f[i + 2] | 0, t = hs.f[i + 3] | 0;
          if (!M.P[f] || !M.P[t] || f === t) continue;
          F.push({ o: hs.f[i] | 0, n: hs.f[i + 1] | 0, f, t, p: +hs.f[i + 4] || 0, d: geom(M, f, t).d });
        }
        W.F = F;
      }
      if (typeof hs.x === 'string') for (let s = 0; s < st.n; s++) W.el[s] = hs.x[s] === '1' ? 1 : -1;
    }
    function guestAdvance(dt) {
      if (performance.now() - snapAt > 1500) return; // no news from the host: freeze
      W.t += dt;
      for (let i = 0; i < W.P.length; i++) { const p = W.P[i]; if (p.o < 0) continue; const mp = M.P[i], c = capOf(mp); if (p.n < c) p.n = Math.min(c, p.n + rateOf(mp) * dt); }
      for (const fl of W.F) fl.p = Math.min(fl.d, fl.p + fleetSpeed(M, fl) * dt);
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 0.1;
          hsQ = (hsQ + 1) % 100000;
          const p = [], f = [];
          for (const q of W.P) p.push(q.o, Math.floor(q.n));
          for (const q of W.F) f.push(q.o, q.n, q.f, q.t, Math.round(q.p));
          api.net.hostSend({ k: key, q: hsQ, t: Math.round(W.t * 10), p, f, x: W.el.map((v) => (v >= 0 ? '1' : '0')).join('') });
        } else {
          if (pubT > 0) return;
          pubT = 1;
          api.net.publish({ k: key, o: myOrders.slice() });
        }
      } catch (e) {}
    }
    function events() {
      if (!W || !lastO) return;
      const m = me();
      for (let i = 0; i < W.P.length; i++) {
        const o = W.P[i].o;
        if (o === lastO[i]) continue;
        const was = lastO[i]; lastO[i] = o;
        fx.push({ kind: 'cap', i, age: 0, col: colOf(o) });
        if (sel.has(i) && o !== m) sel.delete(i);
        if (m >= 0 && o === m) { fx.push({ kind: 'txt', i, age: 0, col: colOf(o), text: '점령!' }); api.sfx('pop'); api.buzz(18); }
        else if (m >= 0 && was === m) { fx.push({ kind: 'txt', i, age: 0, col: '#ee6a55', text: '빼앗김!' }); api.sfx('thud'); api.buzz(40); }
      }
      for (let s = 0; s < st.n; s++) {
        const e = W.el[s] >= 0;
        if (e && !(lastEl[s] >= 0)) {
          banner = { text: (st.nm[s] || '') + ' 탈락!', col: colOf(s), age: 0 };
          if (s === m) { api.toast('탈락했어요 — 이제 관전해요'); api.sfx('lose'); api.buzz([40, 40, 80]); sel.clear(); }
          else api.sfx('chip');
        }
        lastEl[s] = W.el[s];
      }
    }
    function frame(rdt) {
      if (!st || !M) return;
      const dt = rdt * SPD() * (api.online ? 1 : fast);
      if (st.ph === 'count') {
        const a = Math.ceil(cd); cd -= rdt * SPD();
        if (Math.ceil(cd) !== a && cd > 0) api.sfx('tick');
        if (cd <= 0 && host() && !sentPlay) { sentPlay = true; api.setState(Object.assign({}, st, { ph: 'play' })); }
      }
      if (host()) {
        pollHost();
        if (st.ph === 'play' && !W.over) {
          acc += Math.min(dt, 2);
          let n = 0;
          while (acc >= H && n < 60 && !W.over) { aiTick(); step(W, M, H, st.tm, st.tl); acc -= H; n++; }
          if (n >= 60) acc = 0;
        }
        if (W.over && st.ph === 'play' && !sentDone) { sentDone = true; api.setState(finish(st, W)); }
      } else {
        pollGuest();
        if (st.ph === 'play') guestAdvance(dt);
      }
      events();
      publish(rdt);
      buildBar();
      for (const f of fx) f.age += rdt;
      fx = fx.filter((f) => f.age < 1.1);
      if (banner) { banner.age += rdt; if (banner.age > 2.2) banner = null; }
      if (info) { info.t -= rdt; if (info.t <= 0) info = null; }
      updateHint();
    }
    let hintTxt = '';
    function updateHint() {
      let t = '';
      const r = role();
      if (!st) t = '';
      else if (st.ph === 'count') t = me() >= 0 ? '곧 시작해요 — 반짝이는 행성이 내 본진이에요' : '곧 시작해요';
      else if (info) t = info.text;
      else if (r === 'play') {
        if (sel.size) t = '보낼 곳을 누르세요 · ' + shipsFor([...sel]) + '척 출발 (' + ratio + '%)';
        else t = firstSent ? '내 행성 톡 → 보낼 곳 톡' : '내 행성을 눌러 고르세요 · 끌면 여러 개';
      } else if (r === 'out') t = '탈락했어요 — 남은 사람들의 대결을 지켜봐요';
      if (t !== hintTxt) { hintTxt = t; hint.textContent = t; }
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, al, lw) { ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = lw || 3.5; ctx.strokeStyle = 'rgba(8,6,14,.9)'; ctx.strokeText(t, x, y); ctx.fillStyle = col; ctx.fillText(t, x, y); }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else ctx.rect(x, y, w, h); }
    function makeStars() {
      const c = document.createElement('canvas'), d = cv.dpr;
      c.width = Math.max(1, Math.round(cv.w * d)); c.height = Math.max(1, Math.round(cv.h * d));
      const g = c.getContext('2d'); g.scale(d, d);
      const bg = g.createLinearGradient(0, 0, 0, cv.h); bg.addColorStop(0, '#0d0a16'); bg.addColorStop(1, '#151021');
      g.fillStyle = bg; g.fillRect(0, 0, cv.w, cv.h);
      const R = rng(7);
      for (const [x, y, r, c1] of [[0.2, 0.3, 0.5, 'rgba(110,60,150,.18)'], [0.85, 0.7, 0.6, 'rgba(40,90,140,.16)'], [0.5, 0.95, 0.4, 'rgba(150,70,80,.10)']]) {
        const gr = g.createRadialGradient(x * cv.w, y * cv.h, 0, x * cv.w, y * cv.h, r * Math.max(cv.w, cv.h));
        gr.addColorStop(0, c1); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, cv.w, cv.h);
      }
      for (let i = 0; i < 160; i++) {
        const a = 0.25 + R() * 0.6, s = R() < 0.1 ? 1.6 : 0.9;
        g.fillStyle = 'rgba(242,233,216,' + a.toFixed(2) + ')'; g.fillRect(R() * cv.w, R() * cv.h, s, s);
      }
      return c;
    }
    function draw(now) {
      cv.clear();
      if (!stars) stars = makeStars();
      ctx.drawImage(stars, 0, 0, cv.w, cv.h);
      if (!st || !M || !W) return;
      ctx.save();
      ctx.beginPath(); ctx.rect(VR.x, VR.y - 4, VR.w, VR.h + 8); ctx.clip();
      // map edge
      ctx.strokeStyle = 'rgba(227,174,69,.12)'; ctx.lineWidth = 1; ctx.setLineDash([2, 6]);
      rr(sx(0), sy(0), M.w * cam.z, M.h * cam.z, 18); ctx.stroke(); ctx.setLineDash([]);
      drawHoles(now);
      drawLinks(now);
      drawFleets();
      drawPreview(now);
      for (let i = 0; i < M.P.length; i++) drawPlanet(i, now);
      drawFx();
      ctx.restore();
      drawHud(now);
    }
    function drawHoles(now) {
      for (const b of M.B) {
        const x = sx(b.x), y = sy(b.y), r = b.r * cam.z;
        const g = ctx.createRadialGradient(x, y, r * 0.15, x, y, r);
        g.addColorStop(0, 'rgba(120,60,160,.28)'); g.addColorStop(1, 'rgba(60,20,90,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(185,140,255,.35)'; ctx.lineWidth = 1.2; ctx.setLineDash([3, 6]); ctx.lineDashOffset = now / 80;
        ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
        ctx.save(); ctx.translate(x, y); ctx.rotate(now / 900);
        ctx.strokeStyle = 'rgba(255,170,90,.75)'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.ellipse(0, 0, r * 0.34, r * 0.14, 0, 0, 5); ctx.stroke();
        ctx.restore();
        ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(x, y, Math.max(5, r * 0.16), 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,200,140,.8)'; ctx.lineWidth = 1.5; ctx.stroke();
      }
    }
    function drawLinks(now) {
      ctx.lineWidth = 1.5; ctx.setLineDash([2, 7]); ctx.lineDashOffset = -now / 60;
      for (let i = 0; i < M.P.length; i++) {
        const p = M.P[i];
        if (p.k !== WORM || p.tw < i) continue;
        const q = M.P[p.tw];
        ctx.strokeStyle = 'rgba(185,140,255,.32)';
        ctx.beginPath(); ctx.moveTo(sx(p.x), sy(p.y)); ctx.lineTo(sx(q.x), sy(q.y)); ctx.stroke();
      }
      ctx.setLineDash([]); ctx.lineDashOffset = 0;
    }
    function drawFleets() {
      for (const fl of W.F) {
        const a = M.P[fl.f], g = geom(M, fl.f, fl.t), [hx, hy] = fleetXY(M, fl);
        const X = sx(hx), Y = sy(hy), ux = g.ux, uy = g.uy;
        const k = Math.min(12, 2 + Math.floor(Math.sqrt(fl.n) * 1.4)), back = Math.min(fl.p, g.d) * cam.z;
        ctx.fillStyle = colOf(fl.o);
        ctx.beginPath();
        for (let j = 0; j < k; j++) {
          const off = j * 6;
          if (off > back + 0.1) break;
          const jx = X - ux * off + (j % 2 ? -uy : uy) * 2.2, jy = Y - uy * off + (j % 2 ? ux : -ux) * 2.2, s = j === 0 ? 4.2 : 3.2;
          ctx.moveTo(jx + ux * s, jy + uy * s); ctx.lineTo(jx - ux * s - uy * s * 0.7, jy - uy * s + ux * s * 0.7); ctx.lineTo(jx - ux * s + uy * s * 0.7, jy - uy * s - ux * s * 0.7); ctx.closePath();
        }
        ctx.fill();
        void a;
        txt(String(fl.n), X - uy * 11, Y + ux * 11, '#f2e9d8', '700 10px ' + MONO, 'center', 3);
      }
    }
    function drawPreview(now) {
      const m = me();
      // drag sweep line
      if (gest && gest.mode === 'sweep' && gest.moved) {
        const last = gest.sw[gest.sw.length - 1];
        ctx.strokeStyle = 'rgba(227,174,69,.85)'; ctx.lineWidth = 2.5; ctx.setLineDash([6, 5]);
        ctx.beginPath(); ctx.moveTo(sx(M.P[last].x), sy(M.P[last].y)); ctx.lineTo(gest.x, gest.y); ctx.stroke(); ctx.setLineDash([]);
        for (const i of gest.sw) ring(i, pr(i) + 8, '#e3ae45', 3, now);
      }
      const tgt = gest && gest.mode === 'sweep' && gest.moved ? hover : (hover >= 0 ? hover : focus);
      const srcs = gest && gest.mode === 'sweep' && gest.moved ? gest.sw : [...sel];
      if (!srcs.length || tgt < 0 || srcs.includes(tgt) && srcs.length === 1 || !canPlay()) return;
      const k = (() => { let z = 0; for (const s of srcs) if (s !== tgt && own(s)) z += Math.floor(Math.floor(W.P[s].n) * ratio / 100); return z; })();
      ctx.strokeStyle = 'rgba(242,233,216,.55)'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 6]); ctx.lineDashOffset = -now / 40;
      for (const s of srcs) { if (s === tgt) continue; ctx.beginPath(); ctx.moveTo(sx(M.P[s].x), sy(M.P[s].y)); ctx.lineTo(sx(M.P[tgt].x), sy(M.P[tgt].y)); ctx.stroke(); }
      ctx.setLineDash([]); ctx.lineDashOffset = 0;
      const p = W.P[tgt], friend = p.o === m || sameTeam(st.tm, p.o, m);
      const ok = friend || k > p.n * defOf(M.P[tgt]);
      const lab = '→ ' + k + '척' + (friend ? ' 지원' : ok ? ' 점령 가능' : ' 부족');
      txt(lab, sx(M.P[tgt].x), sy(M.P[tgt].y) - pr(tgt) - 14, friend ? '#8fd3ff' : ok ? '#8fe3a8' : '#ee8a75', '700 12px ' + FONT);
    }
    function ring(i, r, col, lw, now) {
      const x = sx(M.P[i].x), y = sy(M.P[i].y);
      ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); ctx.arc(x, y, r + Math.sin(now / 160) * 1.2, 0, 7); ctx.stroke();
    }
    function hexPath(x, y, r) { ctx.beginPath(); for (let k = 0; k < 6; k++) { const a = Math.PI / 6 + k * Math.PI / 3; if (k) ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); else ctx.moveTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } ctx.closePath(); }
    function drawPlanet(i, now) {
      const mp = M.P[i], p = W.P[i], x = sx(mp.x), y = sy(mp.y), r = pr(i), m = me();
      const col = colOf(p.o);
      // glow for owned
      if (p.o >= 0) { ctx.fillStyle = col; ctx.globalAlpha = 0.16; ctx.beginPath(); ctx.arc(x, y, r + 6, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
      // body
      ctx.fillStyle = p.o >= 0 ? col : '#4a4458';
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      const g = ctx.createRadialGradient(x - r * 0.4, y - r * 0.45, r * 0.1, x, y, r);
      g.addColorStop(0, 'rgba(255,255,255,.5)'); g.addColorStop(0.55, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,.28)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      // special marks
      if (mp.k === FORT) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; hexPath(x, y, r + 5); ctx.stroke(); }
      else if (mp.k === YARD) { ctx.strokeStyle = '#8fe3a8'; ctx.lineWidth = 3; ctx.setLineDash([3, 4]); ctx.lineDashOffset = -now / 70; ctx.beginPath(); ctx.arc(x, y, r + 5, 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0; }
      else if (mp.k === WORM) {
        ctx.strokeStyle = '#b98cff'; ctx.lineWidth = 2.2;
        for (let k = 0; k < 3; k++) { const a = now / 500 + k * 2.09; ctx.beginPath(); ctx.arc(x, y, r + 5, a, a + 1.2); ctx.stroke(); }
      }
      // team ring
      if (st.mode !== 'ffa' && p.o >= 0) { ctx.strokeStyle = TEAMC[st.tm[p.o] % 4]; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r - 1, 0, 7); ctx.stroke(); }
      // my home during countdown / mine highlight
      if (m >= 0 && p.o === m && st.ph === 'count') { ctx.strokeStyle = 'rgba(255,240,180,' + (0.5 + 0.5 * Math.sin(now / 150)) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, r + 11, 0, 7); ctx.stroke(); }
      if (sel.has(i)) ring(i, r + 9, '#e3ae45', 3.2, now);
      if (focus === i) { ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 2; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.arc(x, y, r + 13, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
      else if (hover === i && !(gest && gest.mode === 'sweep')) { ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y, r + 12, 0, 7); ctx.stroke(); }
      // count
      const fs = Math.round(U.clamp(r * 0.85, 11, 17));
      txt(String(Math.floor(p.n)), x, y + 0.5, p.o >= 0 ? '#ffffff' : '#d9d2e6', '700 ' + fs + 'px ' + MONO, 'center', 3.5);
    }
    function drawFx() {
      for (const f of fx) {
        const mp = M.P[f.i], x = sx(mp.x), y = sy(mp.y), r = pr(f.i), a = Math.max(0, 1 - f.age / 1.1);
        ctx.globalAlpha = a;
        if (f.kind === 'cap' || f.kind === 'send') {
          ctx.strokeStyle = f.col; ctx.lineWidth = f.kind === 'cap' ? 3 : 2;
          ctx.beginPath(); ctx.arc(x, y, r + 4 + f.age * (f.kind === 'cap' ? 26 : 14), 0, 7); ctx.stroke();
        } else if (f.kind === 'txt') txt(f.text, x, y - r - 12 - f.age * 16, f.col, '800 14px ' + FONT);
        ctx.globalAlpha = 1;
      }
    }
    function drawHud(now) {
      const Wd = cv.w, m = me();
      ctx.fillStyle = 'rgba(14,10,22,.82)'; ctx.fillRect(0, 0, Wd, 44);
      ctx.fillStyle = 'rgba(227,174,69,.25)'; ctx.fillRect(0, 44, Wd, 1);
      const left = st.ph === 'count' ? st.tl : Math.max(0, st.tl - W.t);
      txt('⏱ ' + fmtT(st.ph === 'done' && st.res ? st.tl - st.res.t : left), 10, 15, left < 30 && st.ph === 'play' ? '#ee8a75' : '#f2e9d8', '700 15px ' + MONO, 'left');
      const { sc, pl } = scores(W, st.n);
      if (m >= 0) {
        const out = W.el[m] >= 0;
        txt(out ? '관전 중' : sc[m] + '척 · ' + pl[m] + '행성', Wd - 10, 15, out ? '#ab9fb8' : colOf(m), '700 14px ' + FONT, 'right');
      }
      txt(M.name + (st.mode === 'two' ? ' · 2팀' : st.mode === 'pair' ? ' · 2명씩 팀' : ''), Wd / 2, 15, '#ab9fb8', '600 11px ' + FONT, 'center', 3);
      // strength bar
      const tot = sc.reduce((a, b) => a + b, 0) || 1, bx = 10, bw = Wd - 20, by = 31;
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(bx, by - 4, bw, 9, 4.5); ctx.fill();
      const ord = []; for (let s = 0; s < st.n; s++) ord.push(s);
      ord.sort((a, b) => (st.tm[a] - st.tm[b]) || (a - b));
      let x = bx;
      ctx.save(); rr(bx, by - 4, bw, 9, 4.5); ctx.clip();
      for (const s of ord) { const w = bw * sc[s] / tot; if (w <= 0) continue; ctx.fillStyle = colOf(s); ctx.fillRect(x, by - 4, w, 9); if (s === m) { ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.fillRect(x, by - 4, w, 3); } x += w; }
      ctx.restore();
      // countdown
      if (st.ph === 'count') {
        txt(String(Math.max(1, Math.ceil(cd))), Wd / 2, VR.y + VR.h * 0.42, '#f2e9d8', '56px ' + DISP, 'center', 6);
        if (m >= 0) {
          const t = '나는 이 색이에요';
          ctx.font = '700 15px ' + FONT; const tw = ctx.measureText(t).width;
          const cx = Wd / 2 - (tw + 22) / 2;
          ctx.fillStyle = colOf(m); ctx.beginPath(); ctx.arc(cx + 8, VR.y + VR.h * 0.42 + 46, 8, 0, 7); ctx.fill();
          txt(t, cx + 22, VR.y + VR.h * 0.42 + 46, '#f2e9d8', '700 15px ' + FONT, 'left');
        }
      }
      if (banner) {
        const a = Math.min(1, (2.2 - banner.age) * 3);
        ctx.globalAlpha = a; txt(banner.text, Wd / 2, VR.y + 26, banner.col, '24px ' + DISP, 'center', 5); ctx.globalAlpha = 1;
      }
      if (fast > 1 && !api.online) txt('⏩ 4배', Wd - 10, VR.y + 14, '#e3ae45', '700 12px ' + FONT, 'right');
      void now;
    }

    const stopLoop = U.loop((rdt, now) => {
      if (!st) return;
      try { frame(rdt); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        st = next;
        const k = String(st.rid);
        if (k !== key) { key = k; startGame(); }
        if (st.ph === 'play' && phase === 'count') { phase = 'play'; cd = 0; api.sfx('pop'); api.buzz(25); }
        if (st.ph === 'done') { phase = 'done'; sel.clear(); }
        buildBar();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('wheel', onWheel);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        if (tipEl) tipEl.remove();
        bar.remove(); hint.remove(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ st, M, W, cam, sel, VR, fitZ, tapPlanet, sendTo, sx, sy, selectAll, toggleZoom, setHover: (i) => { hover = i; } }),
    };
  }

  L.register({
    id: 'planets', name: '행성 점령전', tag: '실시간 우주 전략', cat: '보드',
    blurb: '행성마다 함선이 저절로 늘어나요. 내 행성을 누르고 다른 행성을 누르면 함선이 날아가 공격·지원! 더 많은 함선으로 도착하면 점령. 2~8인 실시간 미니 전략(한 폰에 한 명, 나머지는 AI).',
    tint: '#2c3a78',
    icon: '<circle cx="15" cy="39" r="9" fill="currentColor"/><circle cx="42" cy="15" r="7" fill="none" stroke="currentColor" stroke-width="3"/><path d="M22 32l13-12" stroke="currentColor" stroke-width="3" stroke-dasharray="2 5" stroke-linecap="round"/><path d="M31 18l7-3-2 7z" fill="currentColor"/><circle cx="45" cy="44" r="4" fill="currentColor"/><path d="M4 41c6 3 16 3 22-2" stroke="currentColor" stroke-width="2" fill="none" opacity=".6"/>',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'up', label: '위쪽 행성으로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래쪽 행성으로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽 행성으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽 행성으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'pick', label: '고르기 / 보내기', keys: ['Space', 'Enter'], pad: ['a'] },
      { id: 'cancel', label: '선택 취소', keys: ['KeyX', 'Backspace'], pad: ['b'] },
      { id: 'all', label: '내 행성 모두 고르기', keys: ['KeyQ'], pad: ['x'] },
      { id: 'ratio', label: '보낼 비율 바꾸기', keys: ['KeyR'], pad: ['rb', 'lb'] },
      { id: 'r25', label: '25% 보내기', keys: ['Digit1'], pad: [] },
      { id: 'r50', label: '50% 보내기', keys: ['Digit2'], pad: [] },
      { id: 'r100', label: '100% 보내기', keys: ['Digit3'], pad: [] },
      { id: 'zoom', label: '확대 / 전체 보기', keys: ['KeyZ'], pad: ['y'] },
    ],
    options: [
      { id: 'map', label: '은하', choices: [{ v: 'rand', label: '무작위' }].concat(MAPS.map((m) => ({ v: m.v, label: m.label }))), def: 'rand' },
      { id: 'time', label: '제한 시간', choices: [{ v: 180, label: '3분' }, { v: 300, label: '5분' }, { v: 480, label: '8분' }, { v: 720, label: '12분' }], def: 300 },
      { id: 'team', label: '편', choices: [{ v: 'ffa', label: '각자' }, { v: 'two', label: '2팀' }, { v: 'pair', label: '2명씩 팀' }], def: 'ffa' },
    ],
    quick: [
      '행성마다 함선이 저절로 늘어나요. 큰 행성일수록 빨리 늘어요.',
      '내 행성을 톡(끌면 여러 개) → 다른 행성을 톡하면 함선이 날아가요. 아래 25·50·100%로 보낼 양을 골라요.',
      '지키는 함선보다 많이 도착하면 점령! 모두 물리치거나, 시간이 끝났을 때 함선이 가장 많으면 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '다른 사람의 행성을 모두 빼앗아 물리치면 승리예요.',
        '제한 시간(기본 5분)이 끝나면 함선(행성 위 + 날아가는 중)이 가장 많은 사람이 이겨요. 같으면 행성 수로.',
        '행성도 함선도 하나도 없으면 탈락 — 남은 게임은 관전해요.',
      ] },
      { h: '조작 (터치)', p: [
        '① 내 행성(내 색)을 톡 → 금색 고리로 골라져요. 손가락을 떼지 않고 내 행성들을 쓸고 지나가면 여러 개를 한 번에 골라요.',
        '② 보낼 곳을 톡 → 고른 행성마다 함선이 줄지어 날아가요. 끌어서 다른 행성 위에서 떼도 바로 보내요.',
        '아래 25% · 50% · 100%: 고른 행성에서 함선을 얼마나 보낼지(기본 50%). 「모두」는 내 행성 전부 고르기.',
        '빈 곳을 톡하면 선택 취소. 다른 행성(중립·상대)을 그냥 톡하면 그 행성의 정보가 보여요.',
        '🔍 버튼·두 손가락 벌리기·마우스 휠로 확대, 확대한 뒤 빈 곳을 끌면 화면이 움직여요.',
        'PC: 마우스로 똑같이 하거나, 화살표로 행성 옮겨 다니기 · 스페이스로 고르기/보내기 · 1·2·3 비율 · Q 모두 · X 취소 · Z 확대. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '전투 계산', p: [
        '도착한 함선 수가 지키는 함선 수보다 많으면 점령하고, 남은 함선이 그 행성에 남아요. 적거나 같으면 그만큼 지키는 함선만 줄어요.',
        '내 행성(같은 팀 행성)에 보내면 지원: 함선이 그대로 더해져요.',
        '중립 행성(회색)은 함선이 늘지 않지만, 처음부터 지키는 함선이 있어요.',
      ] },
      { h: '예시', p: [
        '내 행성에 40척, 50%로 보내면 20척이 출발해요. 상대 행성에 12척이 있으면 20 − 12 = 8척으로 점령!',
        '방어 행성에 10척이 있으면 20척 몫으로 버텨요 → 20척을 보내도 점령 못 해요(21척 이상 필요).',
      ] },
      { h: '특별한 행성', p: [
        '크기: 작은 행성 1초에 +0.45 · 중간 +0.8 · 큰 행성 +1.25척. 일정 수(작은 40 · 중간 70 · 큰 110)가 차면 더 늘지 않아요.',
        '🛡 방어 행성(금색 육각 테두리): 지키는 함선 1척이 2척 몫을 해요. 대신 함선은 천천히 늘어요.',
        '⚙ 조선소(초록 점선 테두리, 돌아감): 함선이 2배 빨리 늘어요.',
        '🌀 웜홀(보라 고리, 점선으로 짝과 연결): 웜홀 행성에서 보낸 함선은 짝 웜홀이 목적지에 더 가까우면 짝 웜홀에서 바로 출발해요. 짝 웜홀로 보내면 즉시 도착!',
        '⚫ 블랙홀(검은 점 + 보라 점선 원): 행성이 아니에요. 점선 원 안을 지나는 함선은 아주 느려져요.',
      ] },
      { h: '은하 · 옵션', p: [
        '은하 8종: 고리 은하 · 나선 은하 · 성단 지대 · 블랙홀 중심 · 조선소 전선 · 요새 띠 · 웜홀 교차로 · 흩어진 별들. 기본은 「무작위」이고, 같은 종류라도 판마다 모양이 조금씩 달라요.',
        '모든 지도는 대칭이라 시작 위치가 공평해요. 인원이 많을수록 은하가 커져요.',
        '제한 시간 3 · 5 · 8 · 12분. 편: 각자(기본) · 2팀 · 2명씩 팀. 같은 팀은 서로 공격하지 않고, 같은 팀 행성에 보내면 지원이 돼요. 팀전은 팀원 함선을 합쳐서 겨뤄요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지 자리는 AI예요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로 해요.',
        '탈락하면 관전해요. 혼자 하는 중이면 「⏩ 빠르게」로 남은 대결을 빨리 볼 수 있어요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 아무 곳이나 보내고 잘 못 지켜요. 보통은 이길 만한 곳을 골라 공격해요. 어려움은 여러 행성에서 함께 몰아치고, 약해진 행성을 노리고, 위험한 행성을 지원해요.',
      ] },
      { h: '팁', p: [
        '처음엔 가까운 중립 행성부터! 큰 행성·조선소를 먼저 가지면 함선이 빨리 불어나요.',
        '100%로 다 보내면 그 행성은 빈집이 돼요. 상대 근처 행성은 50%로 남겨 두세요.',
        '상대가 큰 함대를 보낸 직후의 행성은 약해요 — 그때 노려 보세요.',
        '위쪽 막대는 모두의 함선 비율이에요. 한 사람이 너무 커지기 전에 견제해요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { H, SPEED, MAPS, genMap, newWorld, step, order, aiThink, scores, finish, result, init, teamsFor, proj, incoming, geom, AIP },
  });
})();
