/* 벽돌 깨기 대전 — realtime breakout versus. Each phone simulates its own field (paddle, balls, brick wall);
   attacks travel as cumulative per-target counters inside presence snapshots; the host decides eliminations
   and the result via setState. Solo = stage mode with levels and a score. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const FW = 320, FH = 480;            // field units
  const COLS = 10, BW = 32, BH = 14, BT = 24, NR = 24, TOPROW = 2, DR = 19; // brick grid; DR = danger row
  const DANGER_Y = BT + DR * BH;        // a brick reaching this line ends the run (versus)
  const PY = 440, PH = 9, R = 5, PWB = 64; // paddle top y, height, ball radius, base paddle width
  const MAXANG = 1.05;                  // max bounce angle from vertical (≈60°)
  const MAXV = 900, IV = 130, LV = 720; // ball speed cap, item fall speed, laser speed
  const LIVES = 3, AUTOL = 4, METER = 100, MAXBALLS = 8;
  const CREEP0 = 60;                    // versus: after this many seconds the wall starts creeping down
  const DUR = { w: 12, l: 9, s: 9, z: 8, k: 8, f: 6 }; // wide laser slow | speed shrink fog (received)
  // items: 1 넓게 2 분열 3 레이저 4 느리게 | 5 줄 공격 6 가속 공격 7 축소 공격 8 안개 공격 | 9 생명(혼자)
  const ATK_NAMES = ['벽돌 줄', '공 가속', '패들 축소', '안개'];

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* seeded wall for a stage — identical on every phone for the same (seed, stage, solo) */
  const PATS = 8;
  function patOn(p, r, c, rows) {
    const cx = Math.abs(c - 4.5);
    switch (p) {
      case 0: return true;
      case 1: return cx < 1 + r * 0.8;                                   // pyramid
      case 2: return (r + c) % 2 === 0 || r % 3 === 0;                   // lattice
      case 3: return cx / 5 + Math.abs(r - (rows - 1) / 2) / (rows / 2 + 0.5) <= 1.05; // diamond
      case 4: return true;                                               // stripes with hard rows
      case 5: return !(r >= rows - 3 && c >= 3 && c <= 6);               // arch
      case 6: return c % 3 !== 2;                                        // columns
      default: return (c + r) % 4 !== 0;                                 // zigzag
    }
  }
  function genWall(seed, stage, solo) {
    const r = rng(((seed >>> 0) ^ Math.imul(stage + 1, 0x9E3779B1) ^ (solo ? 0x5bd1e995 : 0)) >>> 0);
    const g = new Uint8Array(NR * COLS), it = new Uint8Array(NR * COLS);
    const pat = stage === 0 ? 0 : solo ? stage % PATS : 1 + Math.floor(r() * (PATS - 1));
    const rows = solo ? Math.min(10, 5 + Math.floor(stage / 2) + (stage ? 1 : 0)) : 8;
    const hardP = solo ? (stage ? Math.min(0.4, 0.1 + stage * 0.04) : 0) : 0.08;
    const shift = Math.floor(r() * 5);
    for (let rr = 0; rr < rows; rr++) for (let c = 0; c < COLS; c++) {
      const x = r(), y = r(), z = r();
      if (!patOn(pat, rr, c, rows)) continue;
      const i = (TOPROW + rr) * COLS + c;
      let v = 1 + ((rr + shift) % 5);
      if ((pat === 4 && rr % 3 === 1 && stage) || x < hardP) v = 6;
      g[i] = v;
      if (solo) { if (y < 0.13) it[i] = 1 + Math.floor(z * 4); }
      else if (y < 0.10) it[i] = 1 + Math.floor(z * 4);
      else if (y < 0.19) it[i] = 5 + Math.floor(z * 4);
    }
    return { g, it };
  }

  function newField(seed, o) {
    o = o || {};
    const seat = o.seat | 0;
    const f = {
      seat, solo: !!o.solo, sd: seed >>> 0, stage: 0, g: null, it: null,
      balls: [], px: FW / 2, lives: LIVES, score: 0, meter: 0, cum: {}, seen: {}, items: [], lasers: [],
      eff: { w: 0, l: 0, s: 0, z: 0, k: 0, f: 0 }, combo: 0, t: 0, st: 0, dead: false, deadT: 0, ev: [],
      bricks: 0, sent: 0, grng: rng((seed ^ Math.imul(seat + 1, 0x85EBCA6B)) >>> 0), creep: 0, stuckT: 0, laserT: 0,
      tg: -1, lastAtk: -1, ai: null,
    };
    loadStage(f, 0);
    f.balls.push(newBall(f));
    return f;
  }
  function loadStage(f, k) {
    f.stage = k;
    const w = genWall(f.sd, k, f.solo);
    f.g = w.g; f.it = w.it;
    breakOverlaps(f);
  }
  function newBall(f) { return { x: f.px, y: PY - R - 0.5, dx: 0, dy: -1, stuck: true, off: 0 }; }
  const pwOf = (f) => PWB * (f.eff.w > 0 ? 1.5 : 1) * (f.eff.k > 0 ? 0.6 : 1);
  function speedOf(f) {
    const base = f.solo ? 250 * (1 + 0.07 * f.stage) * (1 + Math.min(0.3, f.st / 150)) : 270 * (1 + Math.min(0.55, f.t / 170));
    return Math.min(MAXV, base * (f.eff.s > 0 ? 0.7 : 1) * (f.eff.z > 0 ? 1.4 : 1));
  }
  const brickCount = (f) => { let n = 0; for (let i = 0; i < f.g.length; i++) if (f.g[i]) n++; return n; };
  function lowestRow(f) { for (let r = NR - 1; r >= 0; r--) for (let c = 0; c < COLS; c++) if (f.g[r * COLS + c]) return r; return -1; }
  const cellAt = (f, r, c) => (r < 0 || r >= NR || c < 0 || c >= COLS ? 0 : f.g[r * COLS + c]);

  /* ray from (px,py) along (dx,dy) for t∈[0,1] against AABB; returns entry {t,nx,ny} or null */
  function ray(px, py, dx, dy, x0, y0, x1, y1) {
    let tmin = -Infinity, tmax = Infinity, nx = 0, ny = 0;
    if (dx !== 0) {
      const t1 = (x0 - px) / dx, t2 = (x1 - px) / dx, tn = Math.min(t1, t2), tf = Math.max(t1, t2);
      if (tn > tmin) { tmin = tn; nx = dx > 0 ? -1 : 1; ny = 0; }
      if (tf < tmax) tmax = tf;
    } else if (px <= x0 || px >= x1) return null;
    if (dy !== 0) {
      const t1 = (y0 - py) / dy, t2 = (y1 - py) / dy, tn = Math.min(t1, t2), tf = Math.max(t1, t2);
      if (tn > tmin) { tmin = tn; nx = 0; ny = dy > 0 ? -1 : 1; }
      if (tf < tmax) tmax = tf;
    } else if (py <= y0 || py >= y1) return null;
    if (tmin > tmax || tmax <= 0 || tmin > 1 || tmin < -1e-9) return null;
    return { t: Math.max(0, tmin), nx, ny };
  }
  function minDy(b) {
    if (Math.abs(b.dy) < 0.26) {
      b.dy = (b.dy < 0 ? -1 : b.dy > 0 ? 1 : -1) * 0.26;
      b.dx = (b.dx < 0 ? -1 : 1) * Math.sqrt(1 - b.dy * b.dy);
    }
    const m = Math.hypot(b.dx, b.dy) || 1; b.dx /= m; b.dy /= m;
  }
  function paddleBounce(f, b) {
    const pw = pwOf(f);
    const rel = clamp((b.x - f.px) / (pw / 2), -1, 1);
    const a = rel * MAXANG;
    b.dx = Math.sin(a); b.dy = -Math.cos(a);
    minDy(b);
    f.combo = 0;
    f.ev.push({ k: 'pad', x: b.x, rel });
  }
  /* continuous collision: the ball sweeps its whole path for this step, bouncing as often as needed */
  function sweep(f, b, dt, spd, env) {
    let rem = 1;
    for (let it = 0; it < 16 && rem > 1e-9; it++) {
      const mx = b.dx * spd * dt * rem, my = b.dy * spd * dt * rem;
      let bt = 1, bn = null;
      if (mx < 0 && b.x + mx < R) { const t = (R - b.x) / mx; if (t < bt) { bt = Math.max(0, t); bn = { k: 'w', nx: 1, ny: 0 }; } }
      if (mx > 0 && b.x + mx > FW - R) { const t = (FW - R - b.x) / mx; if (t < bt) { bt = Math.max(0, t); bn = { k: 'w', nx: -1, ny: 0 }; } }
      if (my < 0 && b.y + my < R) { const t = (R - b.y) / my; if (t < bt) { bt = Math.max(0, t); bn = { k: 'w', nx: 0, ny: 1 }; } }
      const xa = Math.min(b.x, b.x + mx) - R, xb = Math.max(b.x, b.x + mx) + R;
      const ya = Math.min(b.y, b.y + my) - R, yb = Math.max(b.y, b.y + my) + R;
      const c0 = Math.max(0, Math.floor(xa / BW)), c1 = Math.min(COLS - 1, Math.floor(xb / BW));
      const r0 = Math.max(0, Math.floor((ya - BT) / BH)), r1 = Math.min(NR - 1, Math.floor((yb - BT) / BH));
      for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
        if (!f.g[r * COLS + c]) continue;
        const h = ray(b.x, b.y, mx, my, c * BW - R, BT + r * BH - R, (c + 1) * BW + R, BT + (r + 1) * BH + R);
        if (h && h.t < bt) { bt = h.t; bn = { k: 'b', nx: h.nx, ny: h.ny, r, c }; }
      }
      if (my > 0) {
        const pw = pwOf(f);
        const h = ray(b.x, b.y, mx, my, f.px - pw / 2 - R, PY - R, f.px + pw / 2 + R, PY + PH + R);
        if (h && h.t <= bt) { bt = h.t; bn = { k: 'p', nx: h.nx, ny: h.ny }; }
      }
      if (!bn) { b.x += mx; b.y += my; break; }
      b.x += mx * bt; b.y += my * bt;
      rem *= 1 - bt;
      let { nx, ny } = bn;
      if (bn.k === 'b') {
        // faces shared with a neighbouring brick are interior: bounce off the exposed axis instead
        if (nx && cellAt(f, bn.r, bn.c + nx)) { nx = 0; ny = b.dy > 0 ? -1 : 1; }
        else if (ny && cellAt(f, bn.r + ny, bn.c)) { ny = 0; nx = b.dx > 0 ? -1 : 1; }
      }
      if (bn.k === 'p' && ny === -1) paddleBounce(f, b);
      else {
        if (nx) b.dx = Math.abs(b.dx) * nx;
        if (ny) b.dy = Math.abs(b.dy) * ny;
        minDy(b);
      }
      b.x += nx * 0.002; b.y += ny * 0.002;
      if (bn.k === 'b') hitBrick(f, bn.r, bn.c, env);
      else if (bn.k === 'w') f.ev.push({ k: 'wall' });
    }
  }
  function hitBrick(f, r, c, env) {
    const i = r * COLS + c, v = f.g[i];
    if (!v) return;
    const x = c * BW + BW / 2, y = BT + r * BH + BH / 2, mul = f.solo ? 1 + f.stage : 1;
    if (v === 6) { f.g[i] = 7; f.score += 5 * mul; f.ev.push({ k: 'dent', x, y }); return; }
    f.g[i] = 0; f.bricks++; f.combo++;
    f.score += (v === 7 ? 20 : v === 8 ? 5 : 10) * mul + (f.combo > 1 ? Math.min(10, f.combo) * mul : 0);
    if (f.it[i]) { f.items.push({ x, y, k: f.it[i] }); f.it[i] = 0; }
    f.ev.push({ k: 'brk', x, y, v, combo: f.combo });
    if (!f.solo) {
      f.meter += (v === 7 ? 10 : v === 8 ? 5 : 7) + Math.min(8, f.combo - 1);
      while (f.meter >= METER) { f.meter -= METER; sendAtk(f, 0, env); }
    }
  }
  function sendAtk(f, type, env) {
    const tg = env && env.target ? env.target(f) : -1;
    if (tg < 0) return false;
    const c = f.cum[tg] || (f.cum[tg] = [0, 0, 0, 0]);
    c[type]++; f.sent++; f.tg = tg;
    f.ev.push({ k: 'send', type, tg });
    return true;
  }
  function receive(f, type) {
    if (f.dead) return;
    if (type === 0) pushRow(f, 'g');
    else if (type === 1) f.eff.z = DUR.z;
    else if (type === 2) f.eff.k = DUR.k;
    else if (type === 3) f.eff.f = DUR.f;
    f.ev.push({ k: 'got', type });
  }
  function breakOverlaps(f) {
    for (const b of f.balls) {
      const c0 = Math.max(0, Math.floor((b.x - R) / BW)), c1 = Math.min(COLS - 1, Math.floor((b.x + R) / BW));
      const r0 = Math.max(0, Math.floor((b.y - R - BT) / BH)), r1 = Math.min(NR - 1, Math.floor((b.y + R - BT) / BH));
      for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) { f.g[r * COLS + c] = 0; f.it[r * COLS + c] = 0; }
    }
  }
  /* push the wall down one row and add a new row on top of it ('g' = attack garbage, 'c' = creep) */
  function pushRow(f, kind) {
    for (let r = NR - 1; r > TOPROW; r--) {
      f.g.copyWithin(r * COLS, (r - 1) * COLS, r * COLS);
      f.it.copyWithin(r * COLS, (r - 1) * COLS, r * COLS);
    }
    const holes = kind === 'g' ? [Math.floor(f.grng() * COLS), Math.floor(f.grng() * COLS)] : [];
    const col = 1 + Math.floor(f.grng() * 5);
    for (let c = 0; c < COLS; c++) {
      const i = TOPROW * COLS + c;
      f.it[i] = 0;
      f.g[i] = kind === 'g' ? (holes.indexOf(c) >= 0 ? 0 : 8) : col;
    }
    breakOverlaps(f);
    if (lowestRow(f) >= DR) die(f);
  }
  function die(f) { if (f.dead) return; f.dead = true; f.deadT = Math.max(0.1, f.t); f.balls = []; f.items = []; f.lasers = []; f.ev.push({ k: 'die' }); }
  function loseLife(f) {
    f.lives--; f.combo = 0;
    f.eff.w = 0; f.eff.l = 0; f.eff.s = 0;
    f.ev.push({ k: 'life', n: f.lives });
    if (f.lives <= 0) { f.lives = 0; die(f); return; }
    f.balls = [newBall(f)]; f.stuckT = 0;
  }
  function launch(f) {
    const b = f.balls.find((x) => x.stuck);
    if (!b || f.dead) return false;
    const a = clamp(b.off / (pwOf(f) / 2), -1, 1) * 0.5 + (Math.random() - 0.5) * 0.3;
    b.stuck = false; b.dx = Math.sin(a); b.dy = -Math.cos(a); minDy(b);
    f.stuckT = 0;
    f.ev.push({ k: 'launch' });
    return true;
  }
  function applyItem(f, k, env) {
    if (k === 1) f.eff.w = DUR.w;
    else if (k === 2) {
      if (f.balls.every((b) => b.stuck)) launch(f);
      const add = [];
      for (const b of f.balls) {
        if (b.stuck) continue;
        for (const da of [-0.35, 0.35]) {
          if (f.balls.length + add.length >= MAXBALLS) break;
          const a = Math.atan2(b.dx, -b.dy) + da;
          const nb = { x: b.x, y: b.y, dx: Math.sin(a), dy: -Math.cos(a), stuck: false, off: 0 };
          minDy(nb); add.push(nb);
        }
      }
      f.balls.push(...add);
    } else if (k === 3) f.eff.l = DUR.l;
    else if (k === 4) f.eff.s = DUR.s;
    else if (k >= 5 && k <= 8) { if (!sendAtk(f, k - 5, env)) f.score += 50; }
    f.ev.push({ k: 'item', it: k });
  }
  function stageClear(f, env) {
    f.stage++;
    f.ev.push({ k: 'clear', stage: f.stage });
    if (f.solo) {
      f.score += 500 * f.stage;
      f.items = []; f.lasers = []; f.eff.w = f.eff.l = f.eff.s = 0;
      f.balls = [newBall(f)]; f.stuckT = 0; f.st = 0;
      loadStage(f, f.stage);
    } else {
      loadStage(f, f.stage);
      sendAtk(f, 0, env); sendAtk(f, 0, env); // clearing the whole wall: two brick rows to an opponent
    }
  }
  function stepField(f, dt, env) {
    if (f.dead) return;
    f.t += dt; f.st += dt;
    for (const k in f.eff) if (f.eff[k] > 0) f.eff[k] = Math.max(0, f.eff[k] - dt);
    const pw = pwOf(f);
    f.px = clamp(f.px, pw / 2, FW - pw / 2);
    const spd = speedOf(f);
    let stuck = false;
    for (const b of f.balls) {
      if (b.stuck) { stuck = true; b.off = clamp(b.off, -pw / 2 + R, pw / 2 - R); b.x = f.px + b.off; b.y = PY - R - 0.5; continue; }
      // the paddle moved into a falling ball: count it as a paddle hit
      if (b.dy > 0 && b.y + R > PY && b.y < PY + PH && Math.abs(b.x - f.px) < pw / 2 + R) { paddleBounce(f, b); b.y = PY - R - 0.01; }
      sweep(f, b, dt, spd, env);
    }
    if (stuck) { f.stuckT += dt; if (!f.ai && f.stuckT > AUTOL) launch(f); }
    f.balls = f.balls.filter((b) => b.y - R <= FH);
    // items
    for (let i = f.items.length - 1; i >= 0; i--) {
      const it = f.items[i];
      it.y += IV * dt;
      if (it.y + 6 >= PY && it.y - 6 <= PY + PH && Math.abs(it.x - f.px) <= pw / 2 + 13) { f.items.splice(i, 1); applyItem(f, it.k, env); }
      else if (it.y > FH + 10) f.items.splice(i, 1);
    }
    // lasers
    if (f.eff.l > 0) {
      f.laserT -= dt;
      if (f.laserT <= 0) { f.laserT = 0.32; f.lasers.push({ x: f.px - pw / 2 + 5, y: PY }, { x: f.px + pw / 2 - 5, y: PY }); f.ev.push({ k: 'laser' }); }
    }
    for (let i = f.lasers.length - 1; i >= 0; i--) {
      const z = f.lasers[i], y0 = z.y, y1 = z.y - LV * dt, c = Math.floor(z.x / BW);
      let hit = false;
      const ra = Math.min(NR - 1, Math.floor((y0 - BT) / BH)), rb = Math.max(0, Math.floor((y1 - BT) / BH));
      for (let r = ra; r >= rb && !hit; r--) if (c >= 0 && c < COLS && f.g[r * COLS + c]) { hitBrick(f, r, c, env); hit = true; }
      if (hit || y1 < 0) f.lasers.splice(i, 1); else z.y = y1;
    }
    if (f.dead) return;
    if (!f.balls.length) { loseLife(f); if (f.dead) return; }
    if (!brickCount(f)) stageClear(f, env);
    if (!f.solo && f.t > CREEP0) {
      f.creep += dt;
      const iv = Math.max(6, 14 - (f.t - CREEP0) / 20);
      if (f.creep >= iv) { f.creep = 0; pushRow(f, 'c'); f.ev.push({ k: 'creep' }); }
    }
  }

  /* ----- AI: tracks the ball with a reaction delay and error; 어려움 aims bounces at bricks ----- */
  const AICFG = {
    1: { react: 0.36, err: 36, spd: 280, aim: false, rr: 0.5, item: 0.15, launch: 1.6 },
    2: { react: 0.16, err: 11, spd: 520, aim: false, rr: 0.9, item: 0.55, launch: 1.0 },
    3: { react: 0.05, err: 2.5, spd: 900, aim: true, rr: 0, item: 1, launch: 0.55 },
  };
  function reflectX(x) {
    const Lw = FW - 2 * R;
    let u = (x - R) % (2 * Lw); if (u < 0) u += 2 * Lw;
    if (u > Lw) u = 2 * Lw - u;
    return R + u;
  }
  function aimRel(f, lx) {
    // prefer exposed bricks carrying items, then the lowest exposed brick near the landing point
    let best = null, bs = -1e9;
    for (let r = 0; r < NR; r++) for (let c = 0; c < COLS; c++) {
      const i = r * COLS + c;
      if (!f.g[i] || cellAt(f, r + 1, c)) continue;
      const x = c * BW + BW / 2, y = BT + r * BH + BH;
      const th = Math.atan2(x - lx, PY - y);
      if (Math.abs(th) > 0.95) continue;
      const s = r * 2 + (f.it[i] ? (f.it[i] >= 5 ? 14 : 10) : 0) + (f.g[i] === 6 ? -3 : 0) - Math.abs(th) * 3;
      if (s > bs) { bs = s; best = th; }
    }
    return best == null ? 0 : clamp(best / MAXANG, -0.95, 0.95);
  }
  function aiTarget(f, cfg, rnd) {
    const spd = speedOf(f), pw = pwOf(f);
    let best = null, bt = 1e9;
    for (const b of f.balls) {
      if (b.stuck || b.dy <= 0) continue;
      const t = (PY - R - b.y) / (b.dy * spd);
      if (t >= 0 && t < bt) { bt = t; best = b; }
    }
    const err = cfg.err * (f.eff.f > 0 ? 2.5 : 1) * (f.eff.z > 0 ? 1.4 : 1);
    const lx0 = best ? reflectX(best.x + best.dx * spd * bt) : null;
    if (cfg.item > 0 && f.items.length && rnd() < cfg.item) {
      for (const it of f.items) {
        const ti = (PY - it.y) / IV;
        if (ti <= 0) continue;
        const travel = Math.abs(it.x - f.px) / cfg.spd;
        if (travel > ti + 0.1) continue;
        if (!best || bt > ti + Math.abs(lx0 - it.x) / cfg.spd + 0.25) return it.x;
      }
    }
    if (!best) {
      const b = f.balls.find((x) => !x.stuck);
      if (!b) return f.px;
      return clamp(b.x + (rnd() - 0.5) * err * 2, 0, FW);
    }
    const lx = lx0 + (rnd() - 0.5) * 2 * err;
    const rel = cfg.aim ? aimRel(f, lx) : (rnd() - 0.5) * cfg.rr;
    return lx - rel * pw / 2 * 0.9;
  }
  function aiStep(f, dt, cfg, rnd) {
    rnd = rnd || Math.random;
    if (f.dead) return;
    const a = f.ai || (f.ai = { cfg });
    if (a.cd == null) { a.cd = 0; a.tx = f.px; a.lt = 0; a.ld = cfg.launch; }
    if (f.balls.some((b) => b.stuck)) {
      a.lt += dt;
      if (cfg.aim) { const b = f.balls.find((x) => x.stuck); a.tx = clamp(FW / 2 + (b ? 0 : 0), 0, FW); }
      if (a.lt >= a.ld) { launch(f); a.lt = 0; a.ld = cfg.launch * (0.6 + rnd() * 0.8); a.cd = 0; }
    }
    a.cd -= dt;
    if (a.cd <= 0) { a.cd = cfg.react * (0.7 + rnd() * 0.6); a.tx = aiTarget(f, cfg, rnd); }
    const mv = cfg.spd * dt, pw = pwOf(f);
    f.px = clamp(f.px + clamp(a.tx - f.px, -mv, mv), pw / 2, FW - pw / 2);
  }

  /* ----- compact snapshot for presence (~300 B) ----- */
  const r1 = (v) => Math.round(v * 10) / 10;
  function gridStr(g) {
    let last = -1;
    for (let i = g.length - 1; i >= 0; i--) if (g[i]) { last = i; break; }
    if (last < 0) return '';
    const end = (Math.floor(last / COLS) + 1) * COLS;
    let s = '';
    for (let i = 0; i < end; i++) s += g[i];
    return s;
  }
  function decodeGrid(s) {
    const g = new Uint8Array(NR * COLS);
    if (typeof s !== 'string') return g;
    for (let i = 0; i < s.length && i < g.length; i++) { const v = s.charCodeAt(i) - 48; g[i] = v > 0 && v <= 8 ? v : 0; }
    return g;
  }
  function packField(f) {
    const e = (f.eff.f > 0 ? 1 : 0) | (f.eff.z > 0 ? 2 : 0) | (f.eff.k > 0 ? 4 : 0) | (f.eff.w > 0 ? 8 : 0) | (f.eff.l > 0 ? 16 : 0) | (f.eff.s > 0 ? 32 : 0);
    return {
      g: gridStr(f.g), b: f.balls.slice(0, 6).map((b) => [Math.round(b.x), Math.round(b.y)]), p: [Math.round(f.px), Math.round(pwOf(f))],
      i: f.items.slice(0, 4).map((it) => [Math.round(it.x), Math.round(it.y), it.k]),
      l: f.lives, m: Math.round(f.meter), a: f.cum, s: f.stage, sc: f.score, k: f.bricks, at: f.sent, t: r1(f.t),
      d: f.dead ? r1(f.deadT) || 0.1 : 0, e, tg: f.tg,
    };
  }

  /* ======================= pure game interface ======================= */
  function init(players) {
    return {
      rid: 1 + U.rand(999999), sd: 1 + U.rand(2147483646), n: players.length,
      nm: players.map((p) => String(p.name || '').slice(0, 10)),
      ph: 'go', out: [], res: null,
    };
  }
  const fmtS = (s) => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || ((i + 1) + '번');
    if (s.n === 1) {
      const r = s.res[0]; // [seat, 'x', t, score, bricks, sent, stage]
      return { winners: [0], title: '게임 오버', text: '점수 ' + (r[3] || 0).toLocaleString() + '\n스테이지 ' + ((r[6] | 0) + 1) + ' · 벽돌 ' + (r[4] || 0) + '개 · ' + fmtS(r[2]) };
    }
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  벽돌 ' + (r[4] || 0) + ' · 공격 ' + (r[5] || 0) + (r[1] === 'x' ? ' · ' + fmtS(r[2]) + ' 탈락' : ''));
    const r0 = s.res[0];
    return { winners: [r0[0]], title: nm(r0[0]) + ' 승리!', text: lines.join('\n') };
  }

  /* ======================= view ======================= */
  const BRC = ['#000', '#ee6a55', '#f0974e', '#e8c04e', '#5fd3a0', '#5bb3e6', '#c9ad78', '#a8916a', '#6a6175'];
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const ITEM = {
    1: ['#5bb3e6', '넓게'], 2: ['#b48cf0', '분열'], 3: ['#ee6a55', '레이저'], 4: ['#5fd3a0', '느리게'],
    5: ['#e3ae45', '벽돌 줄'], 6: ['#e3ae45', '가속'], 7: ['#e3ae45', '축소'], 8: ['#e3ae45', '안개'],
  };

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const STEP = 1 / 120;
    let st = null, key = null, phase = 'wait', cd = 0, goT = 0, acc = 0, pubT = 0, hostT = 0;
    let fields = {}, blobs = {}, decs = {}, outSeen = 0, lay = null, bg = null, now = 0;
    let parts = [], floats = [], shake = 0, hitT = 0, redT = 0, sndT = 0;
    let best = 0;
    try { best = +(localStorage.getItem('lounge.breakout.best') || 0) || 0; } catch (e) {}
    const tiles = {};
    const P = (seat) => api.players[seat] || { name: '?', color: '#888', ai: true };
    const N = () => (st ? st.n : api.players.length);
    function controlledHere(seat) {
      const p = api.players[seat];
      if (!p) return false;
      if (!api.online) return true;
      if (api.isHost) return !!p.ai || !!p.local;
      return !p.ai && !!p.local;
    }
    const mySeat = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const mainSeat = () => { const s = mySeat(); return s >= 0 ? s : 0; };
    const myF = () => { const s = mySeat(); return s >= 0 && phase === 'play' ? fields[s] || null : null; };
    const isOut = (s) => !!st && (st.out || []).some((o) => o[0] === s);
    function aliveSeat(s) {
      if (isOut(s)) return false;
      if (fields[s]) return !fields[s].dead;
      const b = blobs[s];
      return !(b && b.d > 0);
    }
    const env = {
      target(f) {
        const alive = [];
        for (let s = 0; s < N(); s++) if (s !== f.seat && aliveSeat(s)) alive.push(s);
        if (!alive.length) return -1;
        return alive[Math.floor(Math.random() * alive.length)];
      },
    };

    /* ----- fields ----- */
    function makeLocal(seat) {
      const f = newField(st.sd, { seat, solo: st.n === 1 });
      const p = P(seat);
      if (p.ai) f.ai = { cfg: AICFG[p.lv] || AICFG[2] };
      return f;
    }
    function attackCum(a, s) {
      if (fields[a]) return fields[a].cum[s] || null;
      const b = blobs[a];
      return (b && b.a && Array.isArray(b.a[s]) && b.a[s]) || null;
    }
    function fromBlob(seat, b) {
      const f = makeLocal(seat);
      if (b && typeof b === 'object') {
        f.stage = b.s | 0;
        const w = genWall(f.sd, f.stage, f.solo);
        f.g = typeof b.g === 'string' ? decodeGrid(b.g) : w.g; f.it = new Uint8Array(NR * COLS);
        f.lives = b.l | 0 || 1; f.score = b.sc | 0; f.bricks = b.k | 0; f.sent = b.at | 0; f.t = +b.t || 0; f.meter = b.m | 0;
        f.cum = {}; if (b.a && typeof b.a === 'object') for (const k in b.a) if (Array.isArray(b.a[k])) f.cum[k] = b.a[k].map((v) => v | 0);
        if (b.d > 0) { f.dead = true; f.deadT = b.d; f.balls = []; }
      }
      for (let a = 0; a < N(); a++) if (a !== seat) f.seen[a] = (attackCum(a, seat) || [0, 0, 0, 0]).slice();
      return f;
    }
    function takeovers() {
      if (!st || phase === 'wait') return;
      for (let s = 0; s < N(); s++) if (controlledHere(s) && !fields[s]) { fields[s] = fromBlob(s, blobs[s]); delete blobs[s]; }
    }
    function reset() {
      fields = {}; blobs = {}; decs = {}; parts = []; floats = []; outSeen = 0; acc = 0; hostT = 0; drag = null;
      for (let s = 0; s < st.n; s++) if (controlledHere(s)) fields[s] = makeLocal(s);
      layout();
    }
    function deliver() {
      for (const k in fields) {
        const f = fields[k], s = +k;
        if (f.dead) continue;
        for (let a = 0; a < N(); a++) {
          if (a === s) continue;
          const cum = attackCum(a, s);
          if (!cum) continue;
          const seen = f.seen[a] || (f.seen[a] = [0, 0, 0, 0]);
          for (let t = 0; t < 4; t++) {
            const c = cum[t] | 0;
            if (c > seen[t]) { const n = Math.min(6, c - seen[t]); seen[t] = c; for (let i = 0; i < n; i++) receive(f, t); f.lastAtk = a; }
          }
        }
      }
    }
    function step(dt) {
      deliver();
      for (const k in fields) {
        const f = fields[k];
        if (f.dead) continue;
        if (f.ai) aiStep(f, dt, f.ai.cfg);
        else if (+k === mySeat()) keyMove(f, dt);
        stepField(f, dt, env);
      }
      for (const k in fields) drainEv(fields[k]);
    }

    /* ----- feedback (main field only) ----- */
    function burst(x, y, col, n, sp, life) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, v = sp * (0.3 + Math.random());
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - sp * 0.2, t: life * (0.6 + Math.random() * 0.6), t0: life, c: col, s: 1.5 + Math.random() * 2.2 });
      }
      if (parts.length > 400) parts.splice(0, parts.length - 400);
    }
    function float(text, col, big) { floats.push({ text, col: col || '#f2e9d8', t: 1.2, big: !!big }); while (floats.length > 3) floats.shift(); }
    function drainEv(f) {
      if (!f.ev.length) return;
      const show = f.seat === mainSeat(), mine = f.seat === mySeat();
      const evs = f.ev; f.ev = [];
      if (!show) return;
      for (const e of evs) {
        if (e.k === 'brk') {
          burst(e.x, e.y, BRC[e.v], 12, 120, 0.55);
          if (mine && now - sndT > 35) { api.sfx(e.combo >= 4 ? 'chip' : 'pop'); sndT = now; }
          if (mine) api.buzz(e.combo >= 5 ? 14 : 6);
          if (e.combo === 5 || e.combo === 10 || e.combo === 15) float(e.combo + ' 연속!', '#e3ae45');
        } else if (e.k === 'dent') { burst(e.x, e.y, '#d8c49a', 6, 80, 0.35); if (mine) { api.sfx('tick'); api.buzz(5); } }
        else if (e.k === 'pad') { burst(e.x, PY, '#f2e9d8', 5, 70, 0.3); if (mine) { api.sfx('bounce'); api.buzz(10); } }
        else if (e.k === 'wall') { if (mine && now - sndT > 60) { api.sfx('tick'); sndT = now; } }
        else if (e.k === 'item') {
          const it = ITEM[e.it];
          float(e.it >= 5 && e.it <= 8 ? it[1] + ' 공격!' : it[1] + '!', it[0]);
          if (mine) { api.sfx(e.it >= 5 && e.it <= 8 ? 'whoosh' : 'chip'); api.buzz(18); }
        } else if (e.k === 'send') {
          if (e.type === 0 && st && st.n > 1) float('공격 → ' + P(e.tg).name, '#e3ae45');
          if (mine) { setTimeout(() => api.sfx('whoosh'), 60); api.buzz(14); }
        } else if (e.k === 'got') {
          float(['벽돌 줄 +1', '공 가속!', '패들 축소!', '안개!'][e.type], '#ee6a55', true);
          hitT = 0.6; if (e.type === 0) shake = 6;
          if (mine) { api.sfx('hit'); api.buzz(30); }
        } else if (e.k === 'creep') { shake = Math.max(shake, 3); if (mine) { api.sfx('thud'); api.buzz(12); } }
        else if (e.k === 'life') {
          redT = 0.5; shake = 7;
          float(e.n > 0 ? '공을 놓쳤어요 · 남은 공 ' + e.n : '공을 모두 놓쳤어요', '#ee6a55', true);
          if (mine) { api.sfx('lose'); api.buzz(80); }
        } else if (e.k === 'die') { redT = 0.8; if (mine) { api.sfx('lose'); api.buzz(140); } }
        else if (e.k === 'clear') {
          for (let i = 0; i < 6; i++) burst(40 + Math.random() * 240, 60 + Math.random() * 120, BRC[1 + (i % 5)], 14, 160, 0.9);
          float(f.solo ? '스테이지 ' + (e.stage + 1) : '벽 완파! 공격 +2', '#5fd3a0', true);
          if (mine) { api.sfx('win'); api.buzz(40); }
        } else if (e.k === 'launch') { if (mine) { api.sfx('click'); api.buzz(8); } }
        else if (e.k === 'laser') { if (mine && now - sndT > 50) { api.sfx('tick'); sndT = now; } }
      }
    }

    /* ----- online ----- */
    function pollRemote() {
      if (!api.online || !st) return;
      const take = (o) => {
        if (!o || o.k !== key || !o.w || typeof o.w !== 'object') return;
        for (const s in o.w) { const sv = +s; if (sv >= 0 && sv < N() && !fields[sv] && o.w[s] && typeof o.w[s] === 'object') blobs[sv] = o.w[s]; }
      };
      let rem = null;
      try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (rem && typeof rem === 'object') for (const k in rem) take(rem[k]);
      if (!api.isHost) { try { take(api.net.hostState()); } catch (e) {} }
    }
    function publish(rdt) {
      if (!api.online || !st || phase === 'wait') return;
      pubT -= rdt;
      if (pubT > 0) return;
      pubT = 0.1;
      try {
        const mine = {}, ai = {};
        let nm = 0, na = 0;
        for (const k in fields) { if (P(+k).ai) { ai[k] = packField(fields[k]); na++; } else { mine[k] = packField(fields[k]); nm++; } }
        if (api.isHost) { if (nm) api.net.publish({ k: key, w: mine }); if (na) api.net.hostSend({ k: key, w: ai }); }
        else if (nm) api.net.publish({ k: key, w: mine });
      } catch (e) {}
    }
    /* host / local: eliminations and the end of the match */
    function infoOf(s) {
      const f = fields[s];
      if (f) return { d: f.dead ? f.deadT || 0.1 : 0, sc: f.score, k: f.bricks, at: f.sent, t: f.t, s: f.stage };
      const b = blobs[s];
      if (b) return { d: +b.d || 0, sc: b.sc | 0, k: b.k | 0, at: b.at | 0, t: +b.t || 0, s: b.s | 0 };
      return null;
    }
    function hostCheck(rdt) {
      hostT -= rdt;
      if (hostT > 0 || !st || st.ph === 'done') return;
      hostT = 0.15;
      const out = (st.out || []).slice();
      const fresh = [];
      for (let s = 0; s < st.n; s++) {
        const i = infoOf(s);
        if (i && i.d > 0 && !out.some((o) => o[0] === s)) fresh.push([s, r1(i.d), i.sc, i.k, i.at, i.s]);
      }
      if (!fresh.length) return;
      fresh.sort((a, b) => a[1] - b[1]);
      out.push(...fresh);
      let done = false, res = null;
      const inOut = (s) => out.some((o) => o[0] === s);
      if (st.n === 1) {
        done = true;
        const o = out[0];
        res = [[0, 'x', o[1], o[2], o[3], o[4], o[5]]];
      } else {
        const alive = [...Array(st.n).keys()].filter((s) => !inOut(s));
        if (alive.length <= 1) {
          done = true;
          res = alive.map((s) => { const i = infoOf(s) || { sc: 0, k: 0, at: 0, t: 0, s: 0 }; return [s, 'w', r1(i.t), i.sc, i.k, i.at, i.s]; });
          res = res.concat(out.slice().reverse().map((o) => [o[0], 'x', o[1], o[2], o[3], o[4], o[5]]));
        }
      }
      api.setState(Object.assign({}, st, { out, ph: done ? 'done' : 'go', res: done ? res : null }));
    }

    /* ----- layout ----- */
    function layout() {
      const W = cv.w, H = cv.h, nOpp = Math.max(0, N() - 1);
      const miniH = nOpp ? Math.round(U.clamp(H * 0.16, 80, 128)) : 0;
      const hudH = 30, hintH = 26, gap = nOpp ? 6 : 0;
      const availH = H - miniH - gap - hudH - hintH - 14;
      const s = Math.max(0.3, Math.min((W - 20) / FW, availH / FH));
      const fw = FW * s, fh = FH * s;
      const fx = Math.round((W - fw) / 2);
      const extra = Math.max(0, availH - fh);
      const fy = Math.round(miniH + gap + hudH + 6 + extra * 0.3);
      lay = { W, H, s, fw, fh, fx, fy, miniH, hudH, nOpp, dragY: fy + fh * 0.4 };
      bg = null; fogTex = null;
    }
    cv.onresize = layout;

    /* ----- input: relative 1:1 drag in the lower area, tap to launch ----- */
    let drag = null;
    const taps = new Map();
    function onDown(e) {
      if (!lay) return;
      const p = cv.local(e);
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      const f = myF();
      if (!drag && p.y >= lay.dragY) drag = { id: e.pointerId, sx: p.x, px0: f ? f.px : FW / 2, x0: p.x, y0: p.y, t0: performance.now(), moved: 0 };
      else taps.set(e.pointerId, { x0: p.x, y0: p.y, t0: performance.now(), moved: 0 });
    }
    function onMove(e) {
      const p = cv.local(e);
      const tp = taps.get(e.pointerId);
      if (tp) { tp.moved = Math.max(tp.moved, Math.hypot(p.x - tp.x0, p.y - tp.y0)); return; }
      if (!drag || drag.id !== e.pointerId) return;
      drag.moved = Math.max(drag.moved, Math.hypot(p.x - drag.x0, p.y - drag.y0));
      const f = myF();
      if (!f || f.dead) { drag.sx = p.x; return; }
      const pw = pwOf(f), want = drag.px0 + (p.x - drag.sx) / lay.s, cl = clamp(want, pw / 2, FW - pw / 2);
      f.px = cl;
      if (cl !== want) { drag.px0 = cl; drag.sx = p.x; } // re-anchor at the wall so reversing responds at once
    }
    function onUp(e) {
      const tp = taps.get(e.pointerId);
      let g = null;
      if (tp) { taps.delete(e.pointerId); g = tp; }
      else if (drag && drag.id === e.pointerId) { g = drag; drag = null; }
      if (!g || e.type === 'pointercancel') return;
      if (g.moved < 12 && performance.now() - g.t0 < 350) { const f = myF(); if (f) { launch(f); drainEv(f); } }
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.style.touchAction = 'none';
    /* keyboard / gamepad — api.input (rebindable in 「⌨ 조작 설정」): a stick moves the paddle in proportion */
    const inp = api.input || null;
    const offIn = inp ? inp.on((type, id) => {
      if (type === 'down' && id === 'go') { const f = myF(); if (f) { launch(f); drainEv(f); } }
    }) : () => {};
    function keyMove(f, dt) {
      const d = inp ? inp.axis('L', 'R') : 0;
      if (d) f.px += d * 460 * dt;
    }
    function onBlur() { drag = null; taps.clear(); }
    window.addEventListener('blur', onBlur);

    /* ----- drawing ----- */
    function rr(x, a, b, w, h, r) { r = Math.min(r, w / 2, h / 2); x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); }
    function brickTile(v, w, h) {
      const k = v + '_' + w.toFixed(1) + '_' + h.toFixed(1) + '_' + cv.dpr;
      if (tiles[k]) return tiles[k];
      const c = document.createElement('canvas'), d = cv.dpr;
      c.width = Math.ceil(w * d); c.height = Math.ceil(h * d);
      const x = c.getContext('2d'); x.scale(d, d);
      const i = Math.max(0.6, h * 0.06), r = Math.max(1.5, h * 0.22);
      x.fillStyle = BRC[v]; rr(x, i, i, w - 2 * i, h - 2 * i, r); x.fill();
      const gr = x.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, 'rgba(255,255,255,.38)'); gr.addColorStop(0.42, 'rgba(255,255,255,.05)'); gr.addColorStop(1, 'rgba(0,0,0,.35)');
      x.fillStyle = gr; rr(x, i, i, w - 2 * i, h - 2 * i, r); x.fill();
      x.fillStyle = 'rgba(255,255,255,.22)'; rr(x, w * 0.12, h * 0.2, w * 0.5, h * 0.18, h * 0.09); x.fill();
      if (v === 6 || v === 7) { // riveted brass plate
        x.fillStyle = 'rgba(60,40,20,.55)';
        for (const px of [w * 0.12, w * 0.88]) { x.beginPath(); x.arc(px, h / 2, Math.max(1, h * 0.12), 0, Math.PI * 2); x.fill(); }
        if (v === 7) { x.strokeStyle = 'rgba(30,20,10,.75)'; x.lineWidth = Math.max(0.8, h * 0.08); x.beginPath(); x.moveTo(w * 0.42, i); x.lineTo(w * 0.5, h * 0.45); x.lineTo(w * 0.44, h * 0.62); x.lineTo(w * 0.56, h - i); x.stroke(); }
      }
      if (v === 8) { x.strokeStyle = 'rgba(0,0,0,.35)'; x.lineWidth = 1; x.beginPath(); x.moveTo(w * 0.33, i); x.lineTo(w * 0.33, h - i); x.moveTo(w * 0.66, i); x.lineTo(w * 0.66, h - i); x.stroke(); }
      x.strokeStyle = 'rgba(0,0,0,.35)'; x.lineWidth = Math.max(0.6, h * 0.06); rr(x, i + 0.4, i + 0.4, w - 2 * i - 0.8, h - 2 * i - 0.8, r); x.stroke();
      tiles[k] = c;
      return c;
    }
    let fogTex = null;
    function fogTexture(w, h) {
      if (fogTex && fogTex.w === w && fogTex.h === h) return fogTex.c;
      const c = document.createElement('canvas'), d = cv.dpr;
      c.width = Math.ceil(w * d); c.height = Math.ceil(h * d);
      const x = c.getContext('2d'); x.scale(d, d);
      const r = rng(11);
      for (let i = 0; i < 70; i++) {
        const cx = r() * w, cy = h * (0.15 + r() * 0.7), rad = (0.12 + r() * 0.18) * w;
        const g = x.createRadialGradient(cx, cy, 0, cx, cy, rad);
        g.addColorStop(0, 'rgba(196,186,214,.42)'); g.addColorStop(1, 'rgba(196,186,214,0)');
        x.fillStyle = g;
        for (const sh of [-w, 0, w]) { x.save(); x.translate(sh, 0); x.fillRect(cx - rad, cy - rad, rad * 2, rad * 2); x.restore(); } // wraps horizontally
      }
      const lg = x.createLinearGradient(0, 0, 0, h);
      lg.addColorStop(0, 'rgba(120,110,140,0)'); lg.addColorStop(0.18, 'rgba(120,110,140,.82)'); lg.addColorStop(0.82, 'rgba(120,110,140,.82)'); lg.addColorStop(1, 'rgba(120,110,140,0)');
      x.globalCompositeOperation = 'destination-over'; x.fillStyle = lg; x.fillRect(0, 0, w, h);
      fogTex = { w, h, c };
      return c;
    }
    function drawBg() {
      const W = cv.w, H = cv.h;
      if (!bg) {
        bg = document.createElement('canvas');
        bg.width = Math.ceil(W * cv.dpr); bg.height = Math.ceil(H * cv.dpr);
        const x = bg.getContext('2d'); x.scale(cv.dpr, cv.dpr);
        const g = x.createRadialGradient(W / 2, H * 0.5, 20, W / 2, H * 0.5, Math.max(W, H) * 0.8);
        g.addColorStop(0, '#2a2038'); g.addColorStop(1, '#130f1a');
        x.fillStyle = g; x.fillRect(0, 0, W, H);
        const r = rng(5);
        x.fillStyle = 'rgba(255,240,220,.025)';
        for (let i = 0; i < W * H / 60; i++) x.fillRect(r() * W, r() * H, 1, 1);
      }
      ctx.drawImage(bg, 0, 0, W, H);
    }
    function vmOf(seat) {
      const f = fields[seat];
      if (f) return { f, g: f.g, it: f.it, balls: f.balls, px: f.px, pw: pwOf(f), items: f.items, lasers: f.lasers, lives: f.lives, m: f.meter, s: f.stage, sc: f.score, k: f.bricks, dead: f.dead, eff: f.eff, e: 0, t: f.t };
      const b = blobs[seat];
      if (!b) return null;
      let dc = decs[seat];
      if (!dc || dc.s !== b.g) dc = decs[seat] = { s: b.g, g: decodeGrid(b.g) };
      const p = Array.isArray(b.p) ? b.p : [FW / 2, PWB];
      const e = b.e | 0;
      return {
        f: null, g: dc.g, it: null, balls: (Array.isArray(b.b) ? b.b : []).map((q) => ({ x: +q[0] || 0, y: +q[1] || 0, stuck: false })),
        px: +p[0] || FW / 2, pw: +p[1] || PWB, items: (Array.isArray(b.i) ? b.i : []).map((q) => ({ x: +q[0], y: +q[1], k: q[2] | 0 })), lasers: [],
        lives: b.l | 0, m: b.m | 0, s: b.s | 0, sc: b.sc | 0, k: b.k | 0, dead: b.d > 0, e, t: +b.t || 0,
        eff: { f: e & 1 ? 1 : 0, z: e & 2 ? 1 : 0, k: e & 4 ? 1 : 0, w: e & 8 ? 1 : 0, l: e & 16 ? 1 : 0, s: e & 32 ? 1 : 0 },
      };
    }
    function heart(x, y, s, col) {
      ctx.fillStyle = col; ctx.beginPath();
      ctx.moveTo(x, y + s * 0.35);
      ctx.bezierCurveTo(x, y, x - s * 0.5, y, x - s * 0.5, y + s * 0.3);
      ctx.bezierCurveTo(x - s * 0.5, y + s * 0.6, x, y + s * 0.8, x, y + s);
      ctx.bezierCurveTo(x, y + s * 0.8, x + s * 0.5, y + s * 0.6, x + s * 0.5, y + s * 0.3);
      ctx.bezierCurveTo(x + s * 0.5, y, x, y, x, y + s * 0.35);
      ctx.fill();
    }
    function itemIcon(k, cx, cy, s) {
      ctx.strokeStyle = '#1a1422'; ctx.fillStyle = '#1a1422'; ctx.lineWidth = Math.max(1, s * 0.13); ctx.lineCap = 'round';
      const u = s * 0.5;
      ctx.beginPath();
      if (k === 1 || k === 7) { // ↔ (wide) / →← (shrink)
        const o = k === 1 ? 1 : -1;
        ctx.moveTo(cx - u * 1.1, cy); ctx.lineTo(cx + u * 1.1, cy);
        ctx.moveTo(cx - u * 1.1 + (o < 0 ? 0 : 0), cy); ctx.lineTo(cx - u * (1.1 - 0.45 * o), cy - u * 0.45); ctx.moveTo(cx - u * 1.1, cy); ctx.lineTo(cx - u * (1.1 - 0.45 * o), cy + u * 0.45);
        ctx.moveTo(cx + u * 1.1, cy); ctx.lineTo(cx + u * (1.1 - 0.45 * o), cy - u * 0.45); ctx.moveTo(cx + u * 1.1, cy); ctx.lineTo(cx + u * (1.1 - 0.45 * o), cy + u * 0.45);
        ctx.stroke();
      } else if (k === 2) { for (const dx of [-0.75, 0, 0.75]) { ctx.moveTo(cx + dx * u + u * 0.28, cy); ctx.arc(cx + dx * u, cy, u * 0.28, 0, Math.PI * 2); } ctx.fill(); }
      else if (k === 3) { ctx.moveTo(cx - u * 0.5, cy + u * 0.5); ctx.lineTo(cx - u * 0.5, cy - u * 0.5); ctx.moveTo(cx + u * 0.5, cy + u * 0.5); ctx.lineTo(cx + u * 0.5, cy - u * 0.5); ctx.stroke(); }
      else if (k === 4) { ctx.moveTo(cx - u * 0.5, cy - u * 0.55); ctx.lineTo(cx + u * 0.5, cy - u * 0.55); ctx.lineTo(cx - u * 0.5, cy + u * 0.55); ctx.lineTo(cx + u * 0.5, cy + u * 0.55); ctx.closePath(); ctx.stroke(); }
      else if (k === 5) { ctx.rect(cx - u, cy - u * 0.5, u * 0.9, u * 0.4); ctx.rect(cx + u * 0.1, cy - u * 0.5, u * 0.9, u * 0.4); ctx.rect(cx - u * 0.45, cy + u * 0.1, u * 0.9, u * 0.4); ctx.fill(); }
      else if (k === 6) { for (const dx of [-0.45, 0.25]) { ctx.moveTo(cx + dx * u - u * 0.25, cy - u * 0.5); ctx.lineTo(cx + dx * u + u * 0.25, cy); ctx.lineTo(cx + dx * u - u * 0.25, cy + u * 0.5); } ctx.stroke(); }
      else if (k === 8) { for (const [dx, dy, r] of [[-0.5, 0.1, 0.38], [0.1, -0.15, 0.48], [0.6, 0.12, 0.34]]) { ctx.moveTo(cx + dx * u + r * u, cy + dy * u); ctx.arc(cx + dx * u, cy + dy * u, r * u, 0, Math.PI * 2); } ctx.fill(); }
      ctx.lineCap = 'butt';
    }
    function drawField(vm, seat, ox, oy, s, big) {
      const fw = FW * s, fh = FH * s;
      const X = (u) => ox + u * s, Y = (u) => oy + u * s;
      ctx.fillStyle = '#0f0c16'; ctx.fillRect(ox, oy, fw, fh);
      if (big) {
        const g = ctx.createLinearGradient(0, oy, 0, oy + fh);
        g.addColorStop(0, 'rgba(91,179,230,.05)'); g.addColorStop(1, 'rgba(238,106,85,.05)');
        ctx.fillStyle = g; ctx.fillRect(ox, oy, fw, fh);
        ctx.strokeStyle = 'rgba(242,233,216,.035)'; ctx.lineWidth = 1; ctx.beginPath();
        for (let c = 1; c < COLS; c++) { ctx.moveTo(Math.round(X(c * BW)) + 0.5, oy); ctx.lineTo(Math.round(X(c * BW)) + 0.5, oy + fh); }
        ctx.stroke();
      }
      if (!vm) return;
      // danger line (versus)
      if (st && st.n > 1) {
        const low = (() => { for (let r = NR - 1; r >= 0; r--) for (let c = 0; c < COLS; c++) if (vm.g[r * COLS + c]) return r; return -1; })();
        const near = low >= DR - 3 && !vm.dead;
        ctx.strokeStyle = near ? 'rgba(238,106,85,' + (0.6 + 0.4 * Math.sin(now / 110)).toFixed(2) + ')' : 'rgba(238,106,85,.35)';
        ctx.lineWidth = big ? 1.5 : 1; ctx.setLineDash(big ? [6, 5] : [3, 3]);
        ctx.beginPath(); ctx.moveTo(ox, Y(DANGER_Y) + 0.5); ctx.lineTo(ox + fw, Y(DANGER_Y) + 0.5); ctx.stroke(); ctx.setLineDash([]);
        if (big && near) { ctx.fillStyle = 'rgba(238,106,85,.08)'; ctx.fillRect(ox, Y(DANGER_Y - 3 * BH), fw, 3 * BH * s); }
      }
      // bricks
      const bw = BW * s, bh = BH * s;
      for (let r = 0; r < NR; r++) for (let c = 0; c < COLS; c++) {
        const v = vm.g[r * COLS + c];
        if (!v) continue;
        const x = X(c * BW), y = Y(BT + r * BH);
        if (big) {
          ctx.drawImage(brickTile(vm.dead ? 8 : v, bw, bh), x, y, bw, bh);
          const k = vm.it && vm.it[r * COLS + c];
          if (k && !vm.dead) {
            ctx.fillStyle = k >= 5 && k <= 8 ? '#1a1422' : 'rgba(255,255,255,.9)';
            ctx.beginPath();
            if (k >= 5 && k <= 8) { const cx = x + bw / 2, cy = y + bh / 2, q = bh * 0.26; ctx.moveTo(cx, cy - q); ctx.lineTo(cx + q, cy); ctx.lineTo(cx, cy + q); ctx.lineTo(cx - q, cy); }
            else ctx.arc(x + bw / 2, y + bh / 2, bh * 0.18, 0, Math.PI * 2);
            ctx.fill();
          }
        } else { ctx.fillStyle = vm.dead ? '#4a4452' : BRC[v]; ctx.fillRect(x, y, Math.max(1, bw - 1), Math.max(1, bh - 1)); }
      }
      if (vm.dead && !big) return;
      // items
      for (const it of vm.items) {
        const d = ITEM[it.k]; if (!d) continue;
        const w = 26 * s, h = 12 * s, x = X(it.x) - w / 2, y = Y(it.y) - h / 2;
        if (big) {
          ctx.save(); ctx.shadowColor = d[0]; ctx.shadowBlur = 8;
          ctx.fillStyle = d[0]; rr(ctx, x, y, w, h, h / 2); ctx.fill(); ctx.restore();
          if (it.k >= 5 && it.k <= 8) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2; rr(ctx, x + 1, y + 1, w - 2, h - 2, h / 2); ctx.stroke(); }
          ctx.fillStyle = 'rgba(255,255,255,.3)'; rr(ctx, x + h * 0.3, y + 1.5, w - h * 0.6, h * 0.3, h * 0.15); ctx.fill();
          itemIcon(it.k, X(it.x), Y(it.y), h);
        } else { ctx.fillStyle = d[0]; ctx.fillRect(x, y, w, h); }
      }
      // lasers
      if (big) for (const z of vm.lasers) { ctx.fillStyle = '#ffb3a6'; ctx.fillRect(X(z.x) - 1.2, Y(z.y), 2.4, 12 * s); ctx.fillStyle = 'rgba(238,106,85,.35)'; ctx.fillRect(X(z.x) - 3, Y(z.y), 6, 12 * s); }
      // paddle
      const pc = P(seat).color, pw = vm.pw, ph = PH * s;
      const px = X(vm.px - pw / 2), py = Y(PY), pww = pw * s;
      if (big) {
        ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 8; ctx.shadowOffsetY = 3;
        const gr = ctx.createLinearGradient(0, py, 0, py + ph);
        gr.addColorStop(0, '#f6e3b0'); gr.addColorStop(0.5, '#e3ae45'); gr.addColorStop(1, '#8a6420');
        ctx.fillStyle = gr; rr(ctx, px, py, pww, ph, ph / 2); ctx.fill(); ctx.restore();
        ctx.fillStyle = pc; rr(ctx, px + pww * 0.3, py + ph * 0.3, pww * 0.4, ph * 0.4, ph * 0.2); ctx.fill();
        if (vm.eff.l > 0) { ctx.fillStyle = '#ee6a55'; for (const ex of [px + 2, px + pww - 2 - 4 * s]) ctx.fillRect(ex, py - 4 * s, 4 * s, 5 * s); }
        if (vm.eff.k > 0) { ctx.strokeStyle = 'rgba(238,106,85,.8)'; ctx.lineWidth = 1.5; rr(ctx, px - 2, py - 2, pww + 4, ph + 4, ph / 2 + 2); ctx.stroke(); }
      } else { ctx.fillStyle = pc; ctx.fillRect(px, py, Math.max(2, pww), Math.max(2, ph)); }
      // balls
      const fast = vm.eff.z > 0;
      for (const b of vm.balls) {
        const bx = X(b.x), by = Y(b.y), br = Math.max(big ? 2.5 : 1.5, R * s);
        if (big) {
          if (!b.stuck && b.tr) for (let i = 0; i < b.tr.length; i++) {
            const q = b.tr[i], a = (i + 1) / (b.tr.length + 1);
            ctx.fillStyle = fast ? 'rgba(238,106,85,' + (a * 0.35).toFixed(3) + ')' : 'rgba(242,233,216,' + (a * 0.22).toFixed(3) + ')';
            ctx.beginPath(); ctx.arc(X(q[0]), Y(q[1]), br * (0.5 + a * 0.4), 0, Math.PI * 2); ctx.fill();
          }
          ctx.save(); ctx.shadowColor = fast ? '#ee6a55' : 'rgba(255,240,200,.9)'; ctx.shadowBlur = 10;
          const g = ctx.createRadialGradient(bx - br * 0.35, by - br * 0.35, br * 0.1, bx, by, br);
          g.addColorStop(0, '#ffffff'); g.addColorStop(1, fast ? '#f2a08f' : '#e8dcc0');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(bx, by, br, 0, Math.PI * 2); ctx.fill(); ctx.restore();
        } else { ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(bx, by, br, 0, Math.PI * 2); ctx.fill(); }
      }
      // fog
      if (vm.eff.f > 0) {
        const fy0 = Y(FH * 0.26), fh2 = FH * 0.6 * s;
        if (big) {
          const left = vm.f ? vm.eff.f : 3;
          ctx.globalAlpha = Math.min(1, left * 2, (DUR.f - left) * 4 + 0.2);
          const drift = (now / 40) % fw;
          const tex = fogTexture(fw, fh2);
          ctx.save(); ctx.beginPath(); ctx.rect(ox, fy0, fw, fh2); ctx.clip();
          ctx.drawImage(tex, ox + drift - fw, fy0, fw, fh2); ctx.drawImage(tex, ox + drift, fy0, fw, fh2);
          ctx.restore(); ctx.globalAlpha = 1;
        } else { ctx.fillStyle = 'rgba(150,140,170,.75)'; ctx.fillRect(ox, fy0, fw, fh2); }
      }
    }
    function drawMain() {
      const seat = mainSeat(), vm = vmOf(seat), { fx, fy, fw, fh, s } = lay;
      const sx = shake ? (Math.random() - 0.5) * shake : 0, sy = shake ? (Math.random() - 0.5) * shake * 0.6 : 0;
      ctx.save(); ctx.translate(sx, sy);
      // cabinet: wood frame + brass bead
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 18; ctx.shadowOffsetY = 6;
      const fg = ctx.createLinearGradient(0, fy - 8, 0, fy + fh + 8);
      fg.addColorStop(0, '#4a3322'); fg.addColorStop(1, '#2a1c12');
      ctx.fillStyle = fg; rr(ctx, fx - 8, fy - 8, fw + 16, fh + 12, 10); ctx.fill();
      ctx.restore();
      ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1.5; rr(ctx, fx - 3, fy - 3, fw + 6, fh + 4, 5); ctx.stroke();
      ctx.save(); ctx.beginPath(); ctx.rect(fx, fy, fw, fh); ctx.clip();
      drawField(vm, seat, fx, fy, s, true);
      // particles
      for (const p of parts) {
        const a = Math.max(0, p.t / p.t0);
        ctx.globalAlpha = a; ctx.fillStyle = p.c;
        ctx.fillRect(fx + p.x * s - p.s / 2, fy + p.y * s - p.s / 2, p.s, p.s);
      }
      ctx.globalAlpha = 1;
      if (redT > 0) { ctx.fillStyle = 'rgba(238,106,85,' + (redT * 0.4).toFixed(3) + ')'; ctx.fillRect(fx, fy, fw, fh); }
      ctx.restore();
      if (hitT > 0) { ctx.strokeStyle = 'rgba(238,106,85,' + Math.min(1, hitT * 1.6).toFixed(3) + ')'; ctx.lineWidth = 3; rr(ctx, fx - 4, fy - 4, fw + 8, fh + 6, 6); ctx.stroke(); }
      ctx.restore();
      // overlays
      const cxm = fx + fw / 2;
      ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      if (vm && vm.dead) {
        ctx.fillStyle = 'rgba(14,11,20,.62)'; ctx.fillRect(fx, fy, fw, fh);
        ctx.fillStyle = '#ee6a55'; ctx.font = Math.round(fw * 0.12) + 'px ' + DISP;
        ctx.fillText(st.n > 1 ? '탈락' : '게임 오버', cxm, fy + fh * 0.42);
        ctx.font = '600 ' + Math.max(12, Math.round(fw * 0.045)) + 'px ' + MONO; ctx.fillStyle = '#f2e9d8';
        ctx.fillText(st.n > 1 ? (phase === 'play' && st.ph !== 'done' ? '관전 중' : '벽돌 ' + vm.k + '개') : '점수 ' + vm.sc.toLocaleString(), cxm, fy + fh * 0.42 + fw * 0.08);
      }
      if (phase === 'count') {
        const nn = Math.max(1, Math.ceil(cd)), fr = cd - Math.floor(cd);
        ctx.fillStyle = 'rgba(14,11,20,.45)'; ctx.fillRect(fx, fy, fw, fh);
        ctx.fillStyle = '#e3ae45'; ctx.font = Math.round(fw * (0.22 + fr * 0.06)) + 'px ' + DISP;
        ctx.fillText(String(nn), cxm, fy + fh * 0.5);
        ctx.font = '700 ' + Math.max(12, Math.round(fw * 0.045)) + 'px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.85)';
        ctx.fillText(st.n > 1 ? '마지막까지 버티면 승리' : '스테이지를 깨며 점수 쌓기', cxm, fy + fh * 0.5 + fw * 0.09);
      } else if (goT > 0) {
        ctx.globalAlpha = Math.min(1, goT * 2); ctx.fillStyle = '#5fd3a0';
        ctx.font = Math.round(fw * 0.15) + 'px ' + DISP; ctx.fillText('시작!', cxm, fy + fh * 0.5); ctx.globalAlpha = 1;
      }
      // floats
      let yy = fy + fh * 0.62;
      for (const f of floats) {
        const a = Math.min(1, f.t * 2.5), up = (1.2 - f.t) * 26;
        ctx.globalAlpha = a; ctx.font = Math.round(fw * (f.big ? 0.07 : 0.058)) + 'px ' + DISP;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(14,11,20,.85)'; ctx.fillStyle = f.col;
        ctx.strokeText(f.text, cxm, yy - up); ctx.fillText(f.text, cxm, yy - up);
        ctx.globalAlpha = 1; yy += fw * 0.085;
      }
      // launch hint
      const me = myF();
      if (me && !me.dead && me.balls.some((b) => b.stuck) && phase === 'play') {
        ctx.globalAlpha = 0.6 + 0.4 * Math.sin(now / 200);
        ctx.font = '700 ' + Math.max(12, Math.round(fw * 0.045)) + 'px ' + FONT; ctx.fillStyle = '#f2e9d8';
        ctx.fillText('탭해서 공 발사', cxm, fy + (PY - 60) * s);
        ctx.globalAlpha = 1;
      }
      drawHud(vm, seat);
    }
    function drawHud(vm, seat) {
      const { fx, fw, fy, hudH } = lay, y0 = fy - hudH - 4, cy = y0 + hudH / 2;
      if (!vm) return;
      // lives
      for (let i = 0; i < Math.max(LIVES, vm.lives); i++) heart(fx + 9 + i * 17, cy - 7, 14, i < vm.lives ? '#ee6a55' : 'rgba(242,233,216,.15)');
      // score / stage
      ctx.textBaseline = 'middle';
      ctx.textAlign = 'right'; ctx.font = '600 15px ' + MONO; ctx.fillStyle = '#f2e9d8';
      ctx.fillText(vm.sc.toLocaleString(), fx + fw - 2, cy);
      const sw = ctx.measureText(vm.sc.toLocaleString()).width;
      ctx.font = '700 10px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.55)';
      ctx.fillText(st.n > 1 ? '점수' : '스테이지 ' + (vm.s + 1) + ' · 점수', fx + fw - 8 - sw, cy + 1);
      const leftEnd = fx + 9 + Math.max(LIVES, vm.lives) * 17 + 6;
      if (st.n > 1) { // attack meter
        const labelW = 28, mx = leftEnd + labelW, mw = Math.max(40, fx + fw - 8 - sw - 40 - mx - 8);
        ctx.textAlign = 'left'; ctx.font = '700 10px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.55)'; ctx.fillText('공격', leftEnd, cy + 1);
        ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, mx, cy - 5, mw, 10, 5); ctx.fill();
        const fr = clamp(vm.m / METER, 0, 1);
        if (fr > 0) { ctx.fillStyle = fr > 0.85 ? '#ee6a55' : '#e3ae45'; rr(ctx, mx, cy - 5, Math.max(10, mw * fr), 10, 5); ctx.fill(); }
      } else if (best > 0) {
        ctx.textAlign = 'left'; ctx.font = '700 10px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.5)';
        ctx.fillText('최고 ' + best.toLocaleString(), leftEnd, cy + 1);
      }
      ctx.textBaseline = 'alphabetic';
      // active effects as pills under the hud, inside the field top
      const pills = [];
      const E = vm.eff, tm = (v) => (vm.f ? ' ' + Math.ceil(v) : '');
      if (E.w > 0) pills.push(['넓게' + tm(E.w), '#5bb3e6']);
      if (E.l > 0) pills.push(['레이저' + tm(E.l), '#ee6a55']);
      if (E.s > 0) pills.push(['느리게' + tm(E.s), '#5fd3a0']);
      if (E.z > 0) pills.push(['가속' + tm(E.z), '#ee6a55']);
      if (E.k > 0) pills.push(['축소' + tm(E.k), '#ee6a55']);
      if (E.f > 0) pills.push(['안개' + tm(E.f), '#ab9fb8']);
      let px = fx + 4;
      ctx.font = '700 10px ' + FONT;
      for (const [t, c] of pills) {
        const w = ctx.measureText(t).width + 12;
        ctx.fillStyle = 'rgba(14,11,20,.75)'; rr(ctx, px, fy + 4, w, 16, 8); ctx.fill();
        ctx.strokeStyle = c; ctx.lineWidth = 1; rr(ctx, px + 0.5, fy + 4.5, w - 1, 15, 7.5); ctx.stroke();
        ctx.fillStyle = c; ctx.textAlign = 'left'; ctx.fillText(t, px + 6, fy + 16);
        px += w + 4;
      }
      // whose field (spectating)
      if (mySeat() < 0 && st) { ctx.textAlign = 'center'; ctx.font = '700 11px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.7)'; ctx.fillText(P(seat).name, fx + fw / 2, fy + lay.fh + 18); }
    }
    function drawMinis() {
      if (!lay.nOpp) return;
      const ms = mainSeat(), seats = [];
      for (let s = 0; s < N(); s++) if (s !== ms) seats.push(s);
      const slot = (lay.W - 16) / seats.length, mh0 = lay.miniH - 22;
      const sc = Math.min(mh0 / FH, (slot - 44) / FW);
      const mw = FW * sc, mh = FH * sc;
      const myTarget = fields[ms] ? fields[ms].tg : -1;
      seats.forEach((s, i) => {
        const x0 = Math.round(8 + slot * (i + 0.5) - mw / 2), y0 = 20;
        const vm = vmOf(s), p = P(s), out = isOut(s) || (vm && vm.dead);
        ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(8 + slot * i + 8, 10, 4, 0, Math.PI * 2); ctx.fill();
        ctx.save(); ctx.beginPath(); ctx.rect(8 + slot * i + 14, 0, slot - 18, 18); ctx.clip();
        ctx.textAlign = 'left'; ctx.font = '700 11px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.fillText(p.name, 8 + slot * i + 15, 14);
        ctx.restore();
        const tgt = st && st.n > 2 && myTarget === s && !out;
        ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, mw, mh); ctx.clip();
        drawField(vm, s, x0, y0, sc, false);
        ctx.restore();
        ctx.strokeStyle = tgt ? '#e3ae45' : 'rgba(227,174,69,.3)'; ctx.lineWidth = tgt ? 2 : 1; ctx.strokeRect(x0 - 1, y0 - 1, mw + 2, mh + 2);
        // side info: lives + meter
        if (vm && !out) {
          for (let k = 0; k < vm.lives; k++) { ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.arc(x0 + mw + 7, y0 + 5 + k * 9, 3, 0, Math.PI * 2); ctx.fill(); }
          const fr = clamp(vm.m / METER, 0, 1), bh2 = mh * 0.55;
          ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(x0 - 8, y0 + mh - bh2, 4, bh2);
          ctx.fillStyle = '#e3ae45'; ctx.fillRect(x0 - 8, y0 + mh - bh2 * fr, 4, bh2 * fr);
          ctx.textAlign = 'left'; ctx.font = '600 10px ' + MONO; ctx.fillStyle = 'rgba(242,233,216,.7)';
          ctx.fillText(String(vm.k), x0 + mw + 3, y0 + mh - 2);
        }
        if (out) {
          ctx.fillStyle = 'rgba(14,11,20,.55)'; ctx.fillRect(x0, y0, mw, mh);
          const idx = st && st.out ? st.out.findIndex((o) => o[0] === s) : -1;
          const place = idx >= 0 ? st.n - idx : 0;
          ctx.textAlign = 'center'; ctx.fillStyle = '#ee6a55'; ctx.font = Math.round(Math.max(13, mw * 0.24)) + 'px ' + DISP;
          ctx.fillText(place > 0 ? place + '위' : '탈락', x0 + mw / 2, y0 + mh / 2 + 5);
        }
        if (tgt) { ctx.textAlign = 'center'; ctx.font = '700 9px ' + FONT; ctx.fillStyle = '#e3ae45'; ctx.fillText('목표', x0 + mw / 2, y0 + mh + 11 > lay.miniH + 4 ? y0 + 10 : y0 + mh + 11); }
      });
    }
    function drawBottom() {
      const { W, fy, fh } = lay;
      if (mySeat() < 0) return;
      ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      ctx.font = '500 ' + (W < 380 ? 11 : 12) + 'px ' + FONT; ctx.fillStyle = 'rgba(171,159,184,.85)';
      ctx.fillText('아래쪽 아무 데나 좌우로 끌어 패들 이동 · 탭 = 발사', W / 2, fy + fh + 20);
    }
    function draw() {
      if (!lay) layout();
      cv.clear();
      drawBg();
      if (!st) return;
      drawMinis();
      drawMain();
      drawBottom();
    }

    /* ----- loop ----- */
    function frame(rdt) {
      if (!st) return;
      now = performance.now();
      takeovers();
      pollRemote();
      const dt = rdt * SPD();
      if (phase === 'count') {
        const prev = Math.ceil(cd);
        cd -= dt;
        if (Math.ceil(cd) !== prev && cd > 0) { api.sfx('tick'); api.buzz(8); }
        if (cd <= 0) { phase = 'play'; goT = 0.8; api.sfx('pop'); api.buzz(30); }
      }
      if (phase === 'play') {
        acc += dt;
        let n = 0;
        while (acc >= STEP && n < 480) { acc -= STEP; n++; step(STEP); }
        if (n >= 480) acc = 0;
        if (api.isHost) hostCheck(rdt);
      }
      // trails for the shown field
      const f = fields[mainSeat()];
      if (f) for (const b of f.balls) { b.tr = b.tr || []; b.tr.push([b.x, b.y]); if (b.tr.length > 6) b.tr.shift(); }
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.t -= rdt;
        if (p.t <= 0) { parts.splice(i, 1); continue; }
        p.x += p.vx * rdt; p.y += p.vy * rdt; p.vy += 260 * rdt;
      }
      if (goT > 0) goT -= rdt;
      if (hitT > 0) hitT -= rdt;
      if (redT > 0) redT -= rdt;
      shake = Math.max(0, shake - rdt * 22);
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      publish(rdt);
    }
    const stopLoop = U.loop((rdt) => {
      try { frame(rdt); } catch (e) { console.error(e); }
      try { draw(); } catch (e) { console.error(e); }
    });
    layout();

    return {
      update(next) {
        if (!next) return;
        const prevSt = st;
        st = next;
        if (key !== next.rid) {
          key = next.rid;
          reset();
          if (next.ph === 'done') phase = 'done';
          else { phase = 'count'; cd = 3; api.sfx('tick'); }
        } else if (next.ph === 'done' && phase !== 'done') {
          phase = 'done'; drag = null;
          const me = fields[mySeat()];
          if (me && me.solo && me.score > best) { best = me.score; try { localStorage.setItem('lounge.breakout.best', String(best)); } catch (e) {} }
        }
        const out = next.out || [];
        if (out.length > outSeen && prevSt) {
          for (let i = outSeen; i < out.length; i++) {
            const s = out[i][0];
            if (s !== mySeat() && next.n > 2 && next.ph !== 'done') api.toast(P(s).name + ' 탈락');
          }
        }
        outSeen = out.length;
        if (N() !== (lay && lay.nOpp + 1)) layout();
      },
      destroy() {
        stopLoop();
        offIn();
        window.removeEventListener('blur', onBlur);
        cv.destroy();
      },
      _dbg: () => ({ fields, blobs, phase, lay, mySeat: mySeat(), st }),
    };
  }

  L.register({
    id: 'breakout', name: '벽돌 깨기 대전', tag: '실시간 아케이드', cat: '아케이드',
    blurb: '패들로 공을 튕겨 벽돌을 깨고, 모은 공격으로 상대 판에 벽돌 줄·가속·축소·안개를 보내요. 마지막까지 버티면 승리. 혼자면 스테이지 모드.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    tint: '#6a2f1e',
    icon: '<g fill="currentColor"><rect x="6" y="8" width="13" height="7" rx="1.5"/><rect x="21.5" y="8" width="13" height="7" rx="1.5"/><rect x="37" y="8" width="13" height="7" rx="1.5"/><rect x="6" y="17" width="13" height="7" rx="1.5" opacity=".55"/><rect x="37" y="17" width="13" height="7" rx="1.5" opacity=".55"/><circle cx="31" cy="34" r="4"/><rect x="15" y="44" width="26" height="6" rx="3"/></g><path d="M24 24l5 7" stroke="currentColor" stroke-width="2" stroke-dasharray="2 2" fill="none"/>',
    controls: [
      { id: 'L', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'R', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'go', label: '공 발사', keys: ['Space', 'ArrowUp'], pad: ['a', 'rb'] },
    ],
    quick: [
      '패들(아래 막대)로 공을 튕겨 위쪽 벽돌을 깨요. 공을 모두 놓치면 생명이 하나 줄어요(생명 3개).',
      '화면 아래쪽 아무 데나 손가락을 대고 좌우로 끌면 패들이 움직여요. 탭하면 공 발사.',
      '벽돌을 깨 모은 공격으로 상대를 방해! 마지막까지 남으면 승리(혼자면 스테이지 점수 기록).',
    ],
    rules: [
      { h: '목표', p: [
        '각자 자기 판에서 패들로 공을 튕겨 위쪽 벽돌을 깨요. 모두 같은 배치의 벽을 받아요.',
        '마지막까지 남은 사람이 승리. 혼자 하면 스테이지 모드예요(아래 참고).',
        '한 기기에 한 명씩. 혼자 시작하면 나머지 자리는 AI가 맡아요.',
      ] },
      { h: '조작 (터치)', p: [
        '패들 움직이기: 화면 아래쪽(판의 아래 60%와 그 밑) 아무 데나 손가락을 대고 좌우로 끌어요. 패들은 손가락이 움직인 만큼만 똑같이 움직여요(손가락 위치로 순간 이동하지 않아요).',
        '발사: 공이 패들 위에 붙어 있을 때 화면을 톡. 4초가 지나면 저절로 발사돼요.',
        '튀는 각도: 공이 패들 가운데에 맞으면 거의 위로, 끝에 맞을수록 비스듬히 튀어요.',
        'PC 키보드·게임패드: ←→(A·D)·왼스틱 이동(스틱은 기운 만큼 빠르게), 스페이스·↑·Ⓐ·RB 발사. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '탈락 · 승리', p: [
        '공을 모두 놓치면 생명 하나를 잃어요(왼쪽 위 하트 3개).',
        '생명을 다 잃거나, 벽돌이 아래쪽 빨간 점선까지 내려오면 탈락이에요.',
        '벽을 전부 깨면 다음 벽이 나오고, 상대에게 벽돌 줄 2개를 보내요.',
        '60초가 지나면 벽이 조금씩 저절로 내려오고(점점 빨라져요), 공도 시간이 갈수록 빨라져요.',
      ] },
      { h: '공격 (대전)', p: [
        '벽돌을 깰 때마다 위쪽 「공격」 막대가 차요. 패들에 닿기 전에 여러 개를 연달아 깰수록 더 많이 차요. 가득 차면 상대에게 벽돌 줄 하나를 자동으로 보내요.',
        '빨간 테두리 캡슐(◆ 표시 벽돌에서 떨어짐)을 패들로 받으면 그 공격이 바로 상대에게 가요:',
        '벽돌 줄 = 상대 벽을 한 칸 밀어 내리고 맨 위에 회색 벽돌 줄 추가 · 가속 = 8초 동안 상대 공이 빨라짐 · 축소 = 8초 동안 상대 패들이 작아짐 · 안개 = 6초 동안 상대 판 가운데가 가려짐.',
        '3–4명일 때는 살아 있는 상대 중 무작위로 보내요. 위쪽 작은 판에 상대들의 판·생명(빨간 점)·공격 막대가 보여요.',
      ] },
      { h: '아이템 (● 표시 벽돌)', p: [
        '넓게: 12초 동안 패들이 1.5배 · 분열: 날아가는 공마다 3개로 · 레이저: 9초 동안 패들에서 레이저 자동 발사 · 느리게: 9초 동안 공이 느려짐.',
        '혼자 할 때는 공격 아이템이 나오지 않아요.',
        '공을 놓치면 넓게·레이저·느리게 효과는 사라져요.',
      ] },
      { h: '혼자 하기 (스테이지 모드)', p: [
        '벽을 다 깰 때마다 다음 스테이지로 가요. 스테이지가 오를수록 배치가 바뀌고 단단한 벽돌(두 번 맞아야 깨짐)이 늘고 공이 빨라져요.',
        '점수: 벽돌 10점(단단한 벽돌 20점) × 스테이지, 연속으로 깨면 보너스, 스테이지 완료 보너스. 이 폰의 최고 점수를 기억해요.',
      ] },
      { h: '팁', p: [
        '공을 패들 끝으로 받으면 비스듬히 날아가 옆쪽 벽돌을 노릴 수 있어요.',
        '공이 벽돌 위로 넘어가 위쪽에서 튕기면 한 번에 여러 개를 깨서 공격 막대가 빨리 차요.',
        '떨어지는 캡슐을 받으러 가다 공을 놓치지 않게, 공이 높이 있을 때 움직이세요.',
      ] },
      { h: '온라인 · AI', p: [
        '각자 폰에서 자기 판을 움직이고, 위쪽 작은 판으로 상대 판이 실시간으로 보여요. 친구가 나가면 그 자리는 AI(보통)가 이어서 해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(반응 속도·정확도가 다르고, 어려움은 벽돌과 아이템을 노려 쳐요).',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { FW, FH, COLS, BW, BH, BT, NR, TOPROW, DR, PY, PH, R, PWB, MAXV, LIVES, METER, AICFG, genWall, newField, stepField, sweep, ray, hitBrick, sendAtk, receive, pushRow, loseLife, launch, applyItem, aiStep, packField, decodeGrid, gridStr, speedOf, pwOf, lowestRow, brickCount, init, result, rng },
  });
})();
