/* 탑 쌓기 — 모양이 제각각인 나무 블록을 받침대(맵) 위에 번갈아 떨어뜨려 쌓는 물리 게임.
   결정적 2D 강체 시뮬레이션(고정 스텝 1/60 s, + − × ÷ √ 와 다항식 sin만 사용):
   · 블록 = 볼록 다각형 하나 또는 여러 개를 붙인 복합체(아치·L자·별), 원기둥은 16각형.
   · 충돌: 분리축(SAT)으로 기준면/사건 모서리를 찾고 클리핑해 접촉점 최대 2개(부품 쌍마다), 접촉 특징 id로 웜 스타트.
   · 풀이: 순차 충격량(법선 + 쿨롱 마찰, 면마다 마찰 계수) 12회 반복, 바움가르테 위치 보정, 섬(island) 단위 잠들기.
   · 맵 9종: 고정 받침대 조각(볼록 다각형) + 움직이는 맵 조각(시소 판 = 무게중심에 핀 고정, 회전만 함).
     맵 번호는 state.mp, 움직이는 조각의 자세는 탑 문자열(tw)에 블록처럼 들어간다.
   · 판정: 모든 블록이 잠들면 정지, 맵의 '떨어짐 선'(fy)보다 무게중심이 아래로 내려간 블록 = 떨어진 블록.
   · 놓는 높이: 블록을 그대로 내렸을 때 처음 닿는 자리(정확한 수직 스윕)에서 0.45 위 → 미리보기 그림자와 실제가 같다.
   apply가 놓은 자리(x, 각도)로 끝까지 시뮬레이션하고 last={id, pre, b, x, a, m}을 남기며, 뷰는 같은 시뮬레이션을 재생한다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- constants ---------- */
  const DT = 1 / 60, GRAV = 30, ITER = 12;
  const KILL_Y = -40, FLOOR_Y = -12;      // table top; remove below KILL_Y
  const XLIM = 9;                         // drop x range
  const MU = 0.62, BETA = 0.2, SLOP = 0.008, MARGIN = 0.03;   // contacts within MARGIN are kept (speculative) so they don't flicker
  const SLEEP_V = 0.06, SLEEP_W = 0.06, SLEEP_T = 0.45, TCAP = 14;
  const DROP_H = 0.45;                    // the block is let go this far above where it first touches
  const PI = 3.141592653589793, TAU = 2 * PI, HPI = PI / 2;
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  function dsin(x) {
    x = x - TAU * Math.round(x / TAU);
    if (x > HPI) x = PI - x; else if (x < -HPI) x = -PI - x;
    const x2 = x * x;
    return x * (1 - x2 / 6 * (1 - x2 / 20 * (1 - x2 / 42 * (1 - x2 / 72 * (1 - x2 / 110 * (1 - x2 / 156))))));
  }
  const dcos = (x) => dsin(x + HPI);
  function mixc(a, b, t) {
    const A = parseInt(a.slice(1), 16), B = parseInt(b.slice(1), 16);
    const f = (sh) => Math.round(((A >> sh) & 255) * (1 - t) + ((B >> sh) & 255) * t);
    return 'rgb(' + f(16) + ',' + f(8) + ',' + f(0) + ')';
  }

  /* ---------- shapes (local coords, y up; recentred on the centroid) ---------- */
  const rect = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
  function ngon(n, r, rot) { const o = []; for (let i = 0; i < n; i++) { const a = rot + i * TAU / n; o.push([r * dcos(a), r * dsin(a)]); } return o; }
  function area(v) { let a = 0; for (let i = 0; i < v.length; i++) { const p = v[i], q = v[(i + 1) % v.length]; a += p[0] * q[1] - q[0] * p[1]; } return a / 2; }
  function starParts(R, r) {
    const out = [], inner = [], outer = [];
    for (let i = 0; i < 5; i++) { const a = HPI + i * TAU / 5; outer.push([R * dcos(a), R * dsin(a)]); const b = a + TAU / 10; inner.push([r * dcos(b), r * dsin(b)]); }
    out.push(inner.slice());
    for (let i = 0; i < 5; i++) out.push([inner[(i + 4) % 5], outer[i], inner[i]].map((p) => p.slice()));
    return out.map((p) => (area(p) < 0 ? p.slice().reverse() : p));   // every part counter-clockwise
  }
  function starOutline(R, r) { const o = []; for (let i = 0; i < 5; i++) { const a = HPI + i * TAU / 5; o.push([R * dcos(a), R * dsin(a)]); const b = a + TAU / 10; o.push([r * dcos(b), r * dsin(b)]); } return o; }
  function normsOf(p) { return p.map((q, i) => { const w = p[(i + 1) % p.length], ex = w[0] - q[0], ey = w[1] - q[1], l = Math.sqrt(ex * ex + ey * ey); return [ey / l, -ex / l]; }); }
  const NB = 6;   // block types 0..5 come in the random sequence; 6+ are map pieces
  const SHAPES = [
    { id: 'rect', nm: '직사각형', col: '#d9a35f', parts: [rect(-3, -0.8, 3, 0.8)], angs: [0, 90] },
    { id: 'tri', nm: '삼각형', col: '#e07a4f', parts: [[[-2.4, -1.1], [2.4, -1.1], [0, 2.0]]], angs: [0, 180, 90, 270] },
    { id: 'arch', nm: '아치', col: '#8fb35e', parts: [rect(-3, 0.7, 3, 1.6), rect(-3, -1.6, -1.8, 0.7), rect(1.8, -1.6, 3, 0.7)], angs: [0, 180],
      ol: [[-3, -1.6], [-1.8, -1.6], [-1.8, 0.1], [-1.55, 0.45], [-1.0, 0.68], [0, 0.72], [1.0, 0.68], [1.55, 0.45], [1.8, 0.1], [1.8, -1.6], [3, -1.6], [3, 1.6], [-3, 1.6]] },
    { id: 'cyl', nm: '원기둥', col: '#c98f56', parts: [ngon(16, 1.5, 0)], angs: [0] },
    { id: 'L', nm: 'L자', col: '#5f9cc9', parts: [rect(-2.5, -1.4, 2.5, -0.2), rect(-2.5, -0.2, -1.3, 2.2)], angs: [0, 90, 180, 270],
      ol: [[-2.5, -1.4], [2.5, -1.4], [2.5, -0.2], [-1.3, -0.2], [-1.3, 2.2], [-2.5, 2.2]] },
    { id: 'star', nm: '별', col: '#e8bf45', parts: starParts(2.3, 0.95), angs: [0, 36, 18], ol: starOutline(2.3, 0.95) },
    // seesaw plank: heavy, pinned at its centre of mass (rotates only), little lips at both ends
    { id: 'plank', nm: '시소 판', col: '#c4553f', parts: [rect(-7, -0.35, 7, 0.35), rect(-7, 0.35, -6.55, 0.85), rect(6.55, 0.35, 7, 0.85)], angs: [0], map: 1, pin: 1, den: 3,
      ol: [[-7, -0.35], [7, -0.35], [7, 0.85], [6.55, 0.85], [6.55, 0.35], [-6.55, 0.35], [-6.55, 0.85], [-7, 0.85]] },
  ];
  (function prep() {
    for (const S of SHAPES) {
      let A = 0, cx = 0, cy = 0;
      for (const p of S.parts) {
        const a = area(p); let sx = 0, sy = 0;
        for (let i = 0; i < p.length; i++) { const u = p[i], w = p[(i + 1) % p.length], c = u[0] * w[1] - w[0] * u[1]; sx += (u[0] + w[0]) * c; sy += (u[1] + w[1]) * c; }
        A += a; cx += sx / 6; cy += sy / 6;
      }
      cx /= A; cy /= A;
      S.ol = (S.ol || S.parts[0]).map((q) => [q[0] - cx, q[1] - cy]);
      S.parts = S.parts.map((p) => p.map((q) => [q[0] - cx, q[1] - cy]));
      let I = 0;
      for (const p of S.parts) for (let i = 0; i < p.length; i++) {
        const u = p[i], w = p[(i + 1) % p.length], c = u[0] * w[1] - w[0] * u[1];
        I += c * (u[0] * u[0] + u[0] * w[0] + w[0] * w[0] + u[1] * u[1] + u[1] * w[1] + w[1] * w[1]) / 12;
      }
      const den = S.den || 1;
      S.mass = A * den; S.I = I * den;
      S.norms = S.parts.map(normsOf);
      let r = 0; for (const p of S.parts) for (const q of p) r = Math.max(r, Math.sqrt(q[0] * q[0] + q[1] * q[1]));
      S.r = r;
    }
  })();

  /* ---------- maps: fixed pieces (r = rect, p = convex polygon CCW), m = look, mu = surface friction ---------- */
  const F = FLOOR_Y, PLANK = 6;
  const PLB = Math.min(...SHAPES[PLANK].parts[0].map((q) => q[1]));   // plank underside (local)
  const MAPS = [
    { id: 'wood', nm: '나무 받침대', hint: '넓고 평평한 기본 받침대예요', th: 'parlor',
      pc: [{ r: [-6, F, 6, 0], m: 'wood' }] },
    { id: 'narrow', nm: '외기둥', hint: '폭이 좁은 돌기둥이에요', th: 'night',
      pc: [{ r: [-3.4, F, 3.4, 0], m: 'marble' }] },
    { id: 'twin', nm: '쌍둥이 기둥', hint: '가운데 틈에 빠지지 않게!', th: 'canyon',
      pc: [{ r: [-6.4, F, -1.3, 0], m: 'brick' }, { r: [1.3, F, 6.4, 0], m: 'brick' }] },
    { id: 'podium', nm: '시상대', hint: '가운데만 높고 양옆은 낮아요', th: 'stage', fy: -2.3,
      pc: [{ r: [-2.5, F, 2.5, 0], m: 'gold', lab: '1' }, { r: [-7, F, -2.5, -1.8], m: 'gold', lab: '2' }, { r: [2.5, F, 7, -1.8], m: 'gold', lab: '3' }] },
    { id: 'bowl', nm: '오목 그릇', hint: '양쪽 비탈이 가운데로 모여요', th: 'desert', fy: -1.9,
      pc: [{ p: [[-7, F], [0, F], [0, -1.4], [-7, 0]], m: 'clay' }, { p: [[0, F], [7, F], [7, 0], [0, -1.4]], m: 'clay' }] },
    { id: 'slope', nm: '비탈 언덕', hint: '왼쪽으로 기울었어요 · 끝에 턱이 있어요', th: 'hill', fy: -1.5,
      pc: [{ p: [[-6.6, F], [6.6, F], [6.6, 0.9], [-6.6, -0.9]], m: 'grass' }, { r: [-6.6, -1.2, -6.0, -0.15], m: 'stone' }] },
    { id: 'seesaw', nm: '시소', hint: '한쪽에 몰리면 판이 기울어요', th: 'park', fy: -2.2, cam: -5.6,
      pc: [{ r: [-7.6, F, 7.6, -4], m: 'plinth' }, { p: [[-1.7, -4], [1.7, -4], [0, PLB - 0.06]], m: 'iron' },
        { r: [-6.3, -4, -5.5, -1.25], m: 'iron' }, { r: [5.5, -4, 6.3, -1.25], m: 'iron' }],
      dyn: [[PLANK, 0, 0]] },
    { id: 'isles', nm: '공중 발판', hint: '양옆에 매달린 낮은 발판도 쓸 수 있어요', th: 'sky', fy: -1.6,
      pc: [{ r: [-2.8, F, 2.8, 0], m: 'wood' }, { r: [-8.6, -1.7, -4.8, -1.0], m: 'shelf', hang: 1 }, { r: [4.8, -1.7, 8.6, -1.0], m: 'shelf', hang: 1 }] },
    { id: 'ice', nm: '얼음판', hint: '바닥이 아주 미끄러워요!', th: 'snow',
      pc: [{ r: [-6, F, 6, 0], m: 'ice', mu: 0.12 }] },
  ];
  for (const M of MAPS) {
    if (M.fy == null) M.fy = -0.5;
    let top = -1e9, x0 = 1e9, x1 = -1e9;
    for (const pc of M.pc) {
      pc.poly = pc.r ? rect(pc.r[0], pc.r[1], pc.r[2], pc.r[3]) : pc.p;
      let t = -1e9; for (const q of pc.poly) t = Math.max(t, q[1]);
      if (t > top) top = t;
      if (t >= M.fy) for (const q of pc.poly) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); }
    }
    for (const d of M.dyn || []) { const S = SHAPES[d[0]]; top = Math.max(top, d[2] + S.r * 0.2); x0 = Math.min(x0, d[1] - S.r); x1 = Math.max(x1, d[1] + S.r); }
    M.top = top; M.x0 = x0; M.x1 = x1;
  }

  /* ---------- bodies ---------- */
  let BID = 0;
  function Body(type, x, y, a, stat) {
    this.id = BID++; this.t = type; this.x = x; this.y = y; this.a = a; this.vx = 0; this.vy = 0; this.w = 0;
    this.st = !!stat; this.awake = !stat; this.sl = 0; this.gone = 0;
    if (stat) { this.im = 0; this.ii = 0; } else { const S = SHAPES[type]; this.im = S.pin ? 0 : 1 / S.mass; this.ii = 1 / S.I; }
    this.upd();
  }
  Body.prototype.mu = null;
  Body.prototype.upd = function () {
    this.c = dcos(this.a); this.s = dsin(this.a);
    const c = this.c, s = this.s, x = this.x, y = this.y;
    const parts = this.st ? this.sp : SHAPES[this.t].parts, norms = this.st ? this.sn : SHAPES[this.t].norms;
    this.wp = [];
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (let k = 0; k < parts.length; k++) {
      const v = parts[k].map((q) => { const px = x + c * q[0] - s * q[1], py = y + s * q[0] + c * q[1]; if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py; return [px, py]; });
      const n = norms[k].map((q) => [c * q[0] - s * q[1], s * q[0] + c * q[1]]);
      let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
      for (const p of v) { if (p[0] < bx0) bx0 = p[0]; if (p[0] > bx1) bx1 = p[0]; if (p[1] < by0) by0 = p[1]; if (p[1] > by1) by1 = p[1]; }
      this.wp.push({ v, n, bb: [bx0, by0, bx1, by1] });
    }
    this.bb = [x0, y0, x1, y1];
  };
  function staticPoly(poly, mu, pc) {
    const b = Object.create(Body.prototype);
    b.sp = [poly]; b.sn = [normsOf(poly)];
    b.id = BID++; b.t = -1; b.x = 0; b.y = 0; b.a = 0; b.vx = b.vy = b.w = 0; b.st = true; b.awake = false; b.sl = 0; b.gone = 0; b.im = 0; b.ii = 0;
    b.mu = mu == null ? null : mu; b.pc = pc || null;
    b.upd();
    return b;
  }
  const statCache = [];
  function mapStatics(mi) {   // static bodies never change, so every world of a map shares them
    if (statCache[mi]) return statCache[mi];
    const out = MAPS[mi].pc.map((pc) => staticPoly(pc.poly, pc.mu, pc));
    out.push(staticPoly(rect(-80, F - 2, 80, F)));
    return (statCache[mi] = out);
  }

  /* ---------- narrow phase: convex polygon vs convex polygon ---------- */
  function maxSep(A, B) {
    let best = -1e9, bi = 0;
    for (let i = 0; i < A.n.length; i++) {
      const n = A.n[i], v = A.v[i];
      let m = 1e9;
      for (const p of B.v) { const d = n[0] * (p[0] - v[0]) + n[1] * (p[1] - v[1]); if (d < m) m = d; }
      if (m > best) { best = m; bi = i; }
    }
    return [best, bi];
  }
  function clip(pts, nx, ny, off) {
    const out = [], d0 = nx * pts[0][0] + ny * pts[0][1] - off, d1 = nx * pts[1][0] + ny * pts[1][1] - off;
    if (d0 <= 0) out.push(pts[0]);
    if (d1 <= 0) out.push(pts[1]);
    if (d0 * d1 < 0) { const t = d0 / (d0 - d1); out.push([pts[0][0] + t * (pts[1][0] - pts[0][0]), pts[0][1] + t * (pts[1][1] - pts[0][1])]); }
    return out;
  }
  function collide(A, B) {
    const [sa, ea] = maxSep(A, B); if (sa > MARGIN) return null;
    const [sb, eb] = maxSep(B, A); if (sb > MARGIN) return null;
    let ref, inc, edge, flip;
    if (sb > 0.98 * sa + 0.001) { ref = B; inc = A; edge = eb; flip = 1; } else { ref = A; inc = B; edge = ea; flip = 0; }
    const n = ref.n[edge], m = ref.v.length;
    let ie = 0, md = 1e9;
    for (let i = 0; i < inc.n.length; i++) { const d = n[0] * inc.n[i][0] + n[1] * inc.n[i][1]; if (d < md) { md = d; ie = i; } }
    const i1 = inc.v[ie], i2 = inc.v[(ie + 1) % inc.v.length];
    const v1 = ref.v[edge], v2 = ref.v[(edge + 1) % m];
    let tx = v2[0] - v1[0], ty = v2[1] - v1[1]; const tl = Math.sqrt(tx * tx + ty * ty); tx /= tl; ty /= tl;
    let cp = [[i1[0], i1[1]], [i2[0], i2[1]]];
    cp = clip(cp, -tx, -ty, -(tx * v1[0] + ty * v1[1]));
    if (cp.length < 2) return null;
    cp = clip(cp, tx, ty, tx * v2[0] + ty * v2[1]);
    if (cp.length < 2) return null;
    const out = [];
    for (let k = 0; k < cp.length; k++) {
      const p = cp[k], sep = n[0] * (p[0] - v1[0]) + n[1] * (p[1] - v1[1]);
      if (sep <= MARGIN) out.push({ x: p[0], y: p[1], pen: -sep, f: flip * 100000 + edge * 1000 + ie * 10 + k });
    }
    return out.length ? { nx: flip ? -n[0] : n[0], ny: flip ? -n[1] : n[1], pts: out } : null;
  }

  /* ---------- world ---------- */
  function World(bodies, mi) {
    this.b = bodies; this.t = 0; this.cache = new Map(); this.snd = []; this.done = false; this.fell = []; this.n = 0;
    this.mi = mi; this.fy = MAPS[mi].fy;
    this.stat = mapStatics(mi);
  }
  World.prototype.pairs = function () {
    const all = this.b, out = [];
    for (let i = 0; i < all.length; i++) {
      const A = all[i]; if (A.gone) continue;
      for (const S of this.stat) if (A.awake && ov(A.bb, S.bb)) out.push([S, A]);
      for (let j = i + 1; j < all.length; j++) {
        const B = all[j]; if (B.gone || (!A.awake && !B.awake)) continue;
        if (ov(A.bb, B.bb)) out.push([A, B]);
      }
    }
    return out;
  };
  function ov(a, b) { return a[0] <= b[2] + 0.05 && b[0] <= a[2] + 0.05 && a[1] <= b[3] + 0.05 && b[1] <= a[3] + 0.05; }
  World.prototype.step = function () {
    if (this.done) return;
    const dt = DT, bs = this.b;
    // whatever touches a moving block wakes up (and so on through the tower)
    const q = bs.filter((b) => b.awake && !b.gone);
    while (q.length) {
      const A = q.pop();
      for (const B of bs) if (!B.awake && !B.gone && ov(A.bb, B.bb)) { B.awake = true; B.sl = 0; q.push(B); }
    }
    // gravity (a pinned map piece only turns, with a little damping)
    for (const b of bs) {
      if (!b.awake || b.gone) continue;
      if (b.im) { b.vy -= GRAV * dt; b.vx *= 0.999; b.w *= 0.995; } else { b.vx = 0; b.vy = 0; b.w *= 0.985; }
    }
    // contacts
    const cs = [], mfs = [], newCache = new Map();
    for (const [A, B] of this.pairs()) {
      for (let pa = 0; pa < A.wp.length; pa++) for (let pb = 0; pb < B.wp.length; pb++) {
        const PA = A.wp[pa], PB = B.wp[pb];
        if (!ov(PA.bb, PB.bb)) continue;
        const m = collide(PA, PB);
        if (!m) continue;
        if (!A.st && !A.awake) { A.awake = true; A.sl = 0; }
        if (!B.st && !B.awake) { B.awake = true; B.sl = 0; }
        const mf = { A, B, pts: [] };
        const mu = A.mu != null ? A.mu : B.mu != null ? B.mu : MU;
        for (const p of m.pts) {
          const key = A.id + ':' + B.id + ':' + pa + ':' + pb + ':' + p.f;
          const old = this.cache.get(key);
          const c = { A, B, mu, nx: m.nx, ny: m.ny, x: p.x, y: p.y, pen: p.pen, key, pn: old ? old[0] : 0, pt: old ? old[1] : 0 };
          cs.push(c); mf.pts.push(c);
        }
        mfs.push(mf);
      }
    }
    // prepare
    for (const c of cs) {
      const A = c.A, B = c.B;
      c.ax = c.x - A.x; c.ay = c.y - A.y; c.bx = c.x - B.x; c.by = c.y - B.y;
      const rnA = c.ax * c.ny - c.ay * c.nx, rnB = c.bx * c.ny - c.by * c.nx;
      c.mn = 1 / (A.im + B.im + A.ii * rnA * rnA + B.ii * rnB * rnB);
      const tx = c.ny, ty = -c.nx, rtA = c.ax * ty - c.ay * tx, rtB = c.bx * ty - c.by * tx;
      c.mt = 1 / (A.im + B.im + A.ii * rtA * rtA + B.ii * rtB * rtB);
      c.bias = c.pen < 0 ? c.pen / dt : BETA / dt * Math.max(0, c.pen - SLOP);
      // restitution only for hard hits
      const dvx = B.vx - B.w * c.by - A.vx + A.w * c.ay, dvy = B.vy + B.w * c.bx - A.vy - A.w * c.ax, vn = dvx * c.nx + dvy * c.ny;
      if (vn < -4) { c.bias = Math.max(c.bias, -0.15 * vn); if (vn < -6) this.snd.push({ k: 'hit', x: c.x, y: c.y, v: -vn }); }
    }
    // warm start (after every restitution check above has seen the untouched velocities)
    for (const c of cs) {
      const A = c.A, B = c.B, px = c.nx * c.pn + c.ny * c.pt, py = c.ny * c.pn - c.nx * c.pt;
      A.vx -= A.im * px; A.vy -= A.im * py; A.w -= A.ii * (c.ax * py - c.ay * px);
      B.vx += B.im * px; B.vy += B.im * py; B.w += B.ii * (c.bx * py - c.by * px);
    }
    // 2-point manifolds: solve both normal impulses together (block solver), as long as K is well conditioned
    for (const m of mfs) {
      if (m.pts.length !== 2) continue;
      const A = m.A, B = m.B, c1 = m.pts[0], c2 = m.pts[1];
      const r1A = c1.ax * c1.ny - c1.ay * c1.nx, r1B = c1.bx * c1.ny - c1.by * c1.nx, r2A = c2.ax * c2.ny - c2.ay * c2.nx, r2B = c2.bx * c2.ny - c2.by * c2.nx;
      const k11 = A.im + B.im + A.ii * r1A * r1A + B.ii * r1B * r1B, k22 = A.im + B.im + A.ii * r2A * r2A + B.ii * r2B * r2B;
      const k12 = A.im + B.im + A.ii * r1A * r2A + B.ii * r1B * r2B, det = k11 * k22 - k12 * k12;
      if (k11 * k11 < 1000 * det) m.K = [k11, k12, k22, det];
    }
    const applyN = (c, d) => {
      const A = c.A, B = c.B, px = c.nx * d, py = c.ny * d;
      A.vx -= A.im * px; A.vy -= A.im * py; A.w -= A.ii * (c.ax * py - c.ay * px);
      B.vx += B.im * px; B.vy += B.im * py; B.w += B.ii * (c.bx * py - c.by * px);
    };
    const vnOf = (c) => { const A = c.A, B = c.B; return (B.vx - B.w * c.by - A.vx + A.w * c.ay) * c.nx + (B.vy + B.w * c.bx - A.vy - A.w * c.ax) * c.ny; };
    for (let it = 0; it < ITER; it++) {
      for (const m of mfs) {
        // friction first (bounded by the current normal impulse)
        for (const c of m.pts) {
          const A = c.A, B = c.B, tx = c.ny, ty = -c.nx;
          const dvx = B.vx - B.w * c.by - A.vx + A.w * c.ay, dvy = B.vy + B.w * c.bx - A.vy - A.w * c.ax;
          const vt = dvx * tx + dvy * ty;
          let dpt = -c.mt * vt; const maxT = c.mu * c.pn, opt = c.pt; c.pt = clamp(opt + dpt, -maxT, maxT); dpt = c.pt - opt;
          const px = tx * dpt, py = ty * dpt;
          A.vx -= A.im * px; A.vy -= A.im * py; A.w -= A.ii * (c.ax * py - c.ay * px);
          B.vx += B.im * px; B.vy += B.im * py; B.w += B.ii * (c.bx * py - c.by * px);
        }
        if (!m.K) {
          for (const c of m.pts) { const d = c.mn * (-vnOf(c) + c.bias); const o = c.pn; c.pn = Math.max(o + d, 0); applyN(c, c.pn - o); }
          continue;
        }
        const c1 = m.pts[0], c2 = m.pts[1], [k11, k12, k22, det] = m.K, a1 = c1.pn, a2 = c2.pn;
        const b1 = vnOf(c1) - c1.bias - (k11 * a1 + k12 * a2), b2 = vnOf(c2) - c2.bias - (k12 * a1 + k22 * a2);
        let x1 = -(k22 * b1 - k12 * b2) / det, x2 = -(k11 * b2 - k12 * b1) / det;
        if (!(x1 >= 0 && x2 >= 0)) {
          x1 = -b1 / k11; x2 = 0;
          if (!(x1 >= 0 && k12 * x1 + b2 >= 0)) {
            x1 = 0; x2 = -b2 / k22;
            if (!(x2 >= 0 && k12 * x2 + b1 >= 0)) { x1 = 0; x2 = 0; if (!(b1 >= 0 && b2 >= 0)) { x1 = a1; x2 = a2; } }
          }
        }
        applyN(c1, x1 - a1); applyN(c2, x2 - a2); c1.pn = x1; c2.pn = x2;
      }
    }
    for (const c of cs) newCache.set(c.key, [c.pn, c.pt]);
    this.cache = newCache;
    // integrate
    for (const b of bs) {
      if (!b.awake || b.gone) continue;
      b.x += b.vx * dt; b.y += b.vy * dt; b.a += b.w * dt;
      if (b.a > PI) b.a -= TAU; else if (b.a < -PI) b.a += TAU;
      b.upd();
      const v2 = b.vx * b.vx + b.vy * b.vy;
      b.sl = v2 < SLEEP_V * SLEEP_V && b.w * b.w < SLEEP_W * SLEEP_W ? b.sl + dt : 0;
      if (b.y < KILL_Y) { b.gone = 1; b.awake = false; this.snd.push({ k: 'drop', x: b.x, y: b.y }); }
    }
    // islands of touching awake bodies fall asleep together
    const par = new Map();
    const find = (x) => { while (par.get(x) !== x) { par.set(x, par.get(par.get(x))); x = par.get(x); } return x; };
    for (const b of bs) if (b.awake) par.set(b.id, b.id);
    for (const c of cs) if (!c.A.st && !c.B.st && par.has(c.A.id) && par.has(c.B.id)) { const ra = find(c.A.id), rb = find(c.B.id); if (ra !== rb) par.set(ra, rb); }
    const minSl = new Map();
    for (const b of bs) if (b.awake) { const r = find(b.id); const m = minSl.get(r); minSl.set(r, m == null ? b.sl : Math.min(m, b.sl)); }
    for (const b of bs) if (b.awake && minSl.get(find(b.id)) >= SLEEP_T) { b.awake = false; b.vx = b.vy = b.w = 0; }
    for (const b of bs) if (!b.gone && b.t < NB && b.y < this.fy && !this.fell.includes(b.id)) { this.fell.push(b.id); this.snd.push({ k: 'fall', x: b.x, y: b.y }); }
    this.t += dt; this.n++;
    if (!bs.some((b) => b.awake) || this.t > TCAP) this.done = true;
  };
  World.prototype.run = function () { let g = 0; while (!this.done && g++ < TCAP / DT + 5) this.step(); return this; };
  World.prototype.height = function () { let h = 0; for (const b of this.b) if (!b.gone && b.t < NB && b.y > this.fy) for (const p of b.wp) for (const v of p.v) if (v[1] > h) h = v[1]; return h; };

  /* ---------- tower encoding: 10 chars per body (type, x, y, angle); map pieces are always kept ---------- */
  const enc3 = (v) => B64[(v >> 12) & 63] + B64[(v >> 6) & 63] + B64[v & 63];
  const dec3 = (s, i) => (B64.indexOf(s[i]) << 12) | (B64.indexOf(s[i + 1]) << 6) | B64.indexOf(s[i + 2]);
  function encT(bodies, fy) {
    let s = '';
    for (const b of bodies) {
      if (b.gone || (b.t < NB && b.y < fy)) continue;
      let a = b.a % TAU; if (a < 0) a += TAU;
      s += B64[b.t] + enc3(clamp(Math.round((b.x + 64) * 1000), 0, 262143)) + enc3(clamp(Math.round((b.y + 16) * 1000), 0, 262143)) + enc3(Math.round(a * 10000) % 62832);
    }
    return s;
  }
  function decT(s) {
    const out = [];
    for (let i = 0; i + 9 < s.length; i += 10) {
      const t = B64.indexOf(s[i]);
      const b = new Body(t, dec3(s, i + 1) / 1000 - 64, dec3(s, i + 4) / 1000 - 16, dec3(s, i + 7) / 10000);
      b.awake = false;
      out.push(b);
    }
    return out;
  }
  function mapTw(mi) { const M = MAPS[mi]; return M.dyn ? encT(M.dyn.map((d) => new Body(d[0], d[1], d[2], 0)), M.fy) : ''; }

  /* ---------- where a block first touches when lowered straight down (exact for polygons) ---------- */
  function sweepDown(P, Q) {   // how far polygon P can move down before touching polygon Q
    let best = 1e9;
    const np = P.length, nq = Q.length;
    for (let i = 0; i < np; i++) {
      const px = P[i][0], py = P[i][1];
      for (let j = 0; j < nq; j++) {
        const a = Q[j], b = Q[(j + 1) % nq], dx = b[0] - a[0];
        if (dx > -1e-9 && dx < 1e-9) continue;
        const t = (px - a[0]) / dx; if (t < 0 || t > 1) continue;
        const d = py - (a[1] + t * (b[1] - a[1])); if (d > -1e-6 && d < best) best = d;
      }
    }
    for (let j = 0; j < nq; j++) {
      const qx = Q[j][0], qy = Q[j][1];
      for (let i = 0; i < np; i++) {
        const a = P[i], b = P[(i + 1) % np], dx = b[0] - a[0];
        if (dx > -1e-9 && dx < 1e-9) continue;
        const t = (qx - a[0]) / dx; if (t < 0 || t > 1) continue;
        const d = (a[1] + t * (b[1] - a[1])) - qy; if (d > -1e-6 && d < best) best = d;
      }
    }
    return best;
  }
  function landInfo(bodies, mi, type, x, a) {
    const S = SHAPES[type], M = MAPS[mi], stat = mapStatics(mi), c = dcos(a), s = dsin(a);
    let top = M.top; for (const b of bodies) if (!b.gone && b.bb[3] > top) top = b.bb[3];
    const y0 = top + S.r + 1;
    let lo = 1e9, hi = -1e9, mx0 = 1e9, mx1 = -1e9;
    const P = S.parts.map((p) => p.map((q) => {
      const px = x + c * q[0] - s * q[1], ly = s * q[0] + c * q[1];
      if (ly < lo) lo = ly; if (ly > hi) hi = ly; if (px < mx0) mx0 = px; if (px > mx1) mx1 = px;
      return [px, y0 + ly];
    }));
    let d = 1e9;
    const test = (wp) => {
      for (const Q of wp) {
        if (Q.bb[2] < mx0 - 1e-6 || Q.bb[0] > mx1 + 1e-6) continue;
        for (const p of P) { const v = sweepDown(p, Q.v); if (v < d) d = v; }
      }
    };
    for (const b of stat) test(b.wp);
    for (const b of bodies) if (!b.gone) test(b.wp);
    const y = y0 - Math.max(0, d), miss = y + lo < M.fy;
    // a miss falls past everything anyway: let it go just above the map instead of near the table
    return { y, lo, hi, miss, sp: miss ? Math.max(M.top, 0) + DROP_H - lo : y + DROP_H };
  }
  function dropSim(pre, type, x, aDeg, mi) {
    const bodies = decT(pre), a = aDeg * PI / 180, Ld = landInfo(bodies, mi, type, x, a);
    const nb = new Body(type, x, Ld.sp, a);
    // a real hand is never perfect: a tiny, deterministic spin so nothing balances on a knife edge forever
    const h = ((pre.length * 31 + Math.round(x * 100) * 17 + aDeg * 7) % 13 + 13) % 13 - 6;
    nb.w = (h || 3) * 0.012;
    bodies.push(nb);
    const w = new World(bodies, mi);
    w.nb = nb; w.land = Ld;
    return w;
  }

  /* ---------- block sequence (seeded) ---------- */
  function rng(seed, k) {
    let t = (seed + Math.imul(k + 1, 0x6d2b79f5)) | 0;
    t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  const WEIGHTS = [26, 15, 14, 12, 17, 16];
  function blockAt(seed, k) {
    if (k === 0) return 0;
    let r = rng(seed, k) * 100;
    for (let i = 0; i < WEIGHTS.length; i++) { r -= WEIGHTS[i]; if (r < 0) return i; }
    return 0;
  }

  /* ---------- state ---------- */
  const MODES = { duel: '대결', height: '높이 경쟁', coop: '협동' };
  const newSeed = () => 1 + Math.floor(Math.random() * 2147483000);
  function pickMap(not) { let m; do { m = Math.floor(Math.random() * MAPS.length); } while (m === not); return m; }
  const COOP_TG = { s: 24, l: 28 };   // 협동 목표 높이 (짧게 블록 15개 · 길게 22개 안에)
  const CAP = 40;   // a duel round on one tower ends (no loser) after this many blocks
  function init(players, opts) {
    const n = players.length, md = opts && MODES[opts.mode] ? opts.mode : 'duel', ln = opts && opts.len === 'l' ? 'l' : 's';
    let mp = MAPS.findIndex((m) => opts && m.id === opts.map);
    const mr = mp < 0 ? 1 : 0;
    if (mp < 0) mp = pickMap(-1);
    const t0 = mapTw(mp);
    const s = {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), md, ln, mp, mr, sd: newSeed(), c: 0, ph: 'p', seq: 0, last: null,
      sc: players.map(() => 0), rd: 1, k: [0], tw: [t0], hi: players.map(() => 0),
    };
    if (md === 'duel') s.nr = ln === 'l' ? 5 : 3;
    if (md === 'height') { s.nb = ln === 'l' ? 12 : 8; s.tw = players.map(() => t0); s.k = players.map(() => 0); }
    if (md === 'coop') { s.tg = COOP_TG[ln]; s.nb = (ln === 'l' ? 22 : 15); s.lost = 0; }
    return s;
  }
  function actor(s) { return s.ph === 'e' ? null : s.c; }
  const towerOf = (s, seat) => (s.md === 'height' ? seat : 0);
  function apply(s, seat, a) {
    if (s.ph === 'e') throw new Error('game over');
    if (seat !== s.c) throw new Error('not your turn');
    if (!a || a.k !== 'd' || !isFinite(a.x) || !isFinite(a.a)) throw new Error('bad action');
    const x = Math.round(clamp(+a.x, -XLIM, XLIM) * 100) / 100, ad = ((Math.round(+a.a) % 360) + 360) % 360;
    const ti = towerOf(s, seat), type = blockAt(s.sd, s.k[ti]), pre = s.tw[ti], mi = s.mp, fy = MAPS[mi].fy;
    const w = dropSim(pre, type, x, ad, mi).run();
    s.seq++;
    s.last = { id: s.seq, s: seat, ti, pre, b: type, x, a: ad, m: mi, sd: s.sd, f: w.fell.length };
    s.k[ti]++;
    const h = w.height();
    if (s.md === 'duel') {
      if (w.fell.length) {
        s.last.lose = 1;
        for (let i = 0; i < s.n; i++) if (i !== seat) s.sc[i]++;
        s.hi[seat] = Math.max(s.hi[seat], s.k[0] - 1);
        return endRound(s, seat);
      }
      s.tw[0] = encT(w.b, fy);
      if (s.k[0] >= CAP) { s.last.cap = 1; return endRound(s, -1); }
      s.c = (seat + 1) % s.n;
      return s;
    }
    s.tw[ti] = encT(w.b, fy);
    if (s.md === 'height') {
      s.hi[seat] = Math.round(h * 100) / 100;
      // next player who still has blocks
      for (let k = 1; k <= s.n; k++) { const q = (seat + k) % s.n; if (s.k[q] < s.nb) { s.c = q; return s; } }
      s.ph = 'e';
      return s;
    }
    // coop
    s.lost += w.fell.length;
    s.hi[0] = Math.round(h * 100) / 100;
    if (h >= s.tg || s.k[0] >= s.nb) { s.ph = 'e'; return s; }
    s.c = (seat + 1) % s.n;
    return s;
  }
  function endRound(s, loser) {
    if (s.n === 1 || s.rd >= s.nr) { s.ph = 'e'; return s; }
    s.rd++; s.sd = newSeed(); s.k = [0];
    if (s.mr) s.mp = pickMap(s.mp);   // 무작위 맵: a new map every round
    s.tw = [mapTw(s.mp)];
    s.c = loser >= 0 ? loser : (s.c + 1) % s.n;   // the player who toppled the tower starts the next one
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const mapLine = s.md === 'duel' && s.mr && s.n > 1 ? '' : '\n맵 · ' + MAPS[s.mp].nm;
    if (s.md === 'coop') {
      const h = s.hi[0], ok = h >= s.tg, all = []; for (let i = 0; i < s.n; i++) all.push(i);
      return { winners: ok ? all : [], title: ok ? '목표 달성!' : '아깝게 실패', text: '높이 ' + h.toFixed(1) + ' / 목표 ' + s.tg + ' · 블록 ' + s.k[0] + '개 사용' + (s.lost ? ' · 떨어진 블록 ' + s.lost + '개' : '') + mapLine };
    }
    if (s.md === 'height') {
      const best = Math.max(...s.hi), w = []; s.hi.forEach((v, i) => { if (v === best) w.push(i); });
      const order = s.hi.map((v, i) => [v, i]).sort((a, b) => b[0] - a[0] || a[1] - b[1]);
      return { winners: w, title: s.n === 1 ? '높이 ' + best.toFixed(1) : undefined, text: order.map(([v, i], r) => (r + 1) + '위 ' + nm(i) + ' · 높이 ' + v.toFixed(1)).join('\n') + mapLine };
    }
    if (s.n === 1) return { winners: [0], title: '블록 ' + s.hi[0] + '개 성공', text: (s.last && s.last.cap ? '끝까지 무너지지 않았어요!' : (s.hi[0] + 1) + '번째 블록에서 무너졌어요.') + mapLine };
    const best = Math.max(...s.sc), w = []; s.sc.forEach((v, i) => { if (v === best) w.push(i); });
    const order = s.sc.map((v, i) => [v, i]).sort((a, b) => b[0] - a[0] || a[1] - b[1]);
    return { winners: w, text: order.map(([v, i], r) => (r + 1) + '위 ' + nm(i) + ' · ' + v + '점').join('\n') + mapLine };
  }

  /* ---------- AI: simulate candidate placements, pick the most stable (and tallest when it matters) ---------- */
  const wrapA = (d) => { d = d % TAU; if (d > PI) d -= TAU; else if (d < -PI) d += TAU; return Math.abs(d); };
  function evalDrop(pre, type, x, ad, md, mi, tg, hw) {
    const pb = decT(pre);
    if (landInfo(pb, mi, type, x, ad * PI / 180).miss) return { v: -1e4, fell: 1, h: 0 };
    const before = pb.map((b) => [b.x, b.y, b.a, b.t]);
    const w = dropSim(pre, type, x, ad, mi); w.run();
    let moved = 0;
    for (let i = 0; i < before.length; i++) {
      const b = w.b[i];
      if (b.gone) { moved += 20; continue; }
      moved += Math.abs(b.x - before[i][0]) + Math.abs(b.y - before[i][1]) + wrapA(b.a - before[i][2]) * (before[i][3] < NB ? 2 : 6);
    }
    const nb = w.nb;
    const da = wrapA(nb.a - ad * PI / 180);
    const h = w.height();
    let v = -moved * 3 - da * 2 - Math.abs(nb.x) * 0.12 - (w.t >= TCAP ? 3 : 0);
    if (md !== 'duel') v += h * (hw || 1.2) - w.fell.length * 25;
    if (tg && h >= tg) v += 80;   // 협동: reaching the goal is what counts
    else v -= h * 0.25;   // in a duel a low, wide tower is safer
    if (w.fell.length) v -= 100;
    return { v, fell: w.fell.length, h };
  }
  function ai(s, seat, lv) {
    lv = clamp(lv || 2, 1, 3);
    const ti = towerOf(s, seat), type = blockAt(s.sd, s.k[ti]), pre = s.tw[ti], S = SHAPES[type], mi = s.mp, M = MAPS[mi];
    const t0 = Date.now(), budget = [80, 130, 250][lv - 1];
    // 협동: 보통부터 목표를 의식하고, 어려움은 높이를 더 적극적으로 노린다
    const tg = s.md === 'coop' && lv > 1 ? s.tg : 0, hw = s.md === 'coop' && lv === 3 ? 1.7 : 1.2;
    const bodies = decT(pre);
    let angs = S.angs.slice();
    if (lv === 1 && Math.random() < 0.6) angs = [angs[Math.floor(Math.random() * angs.length)]];
    // the tower's centre of mass: promising spots are near it
    let cx = 0, m = 0; for (const b of bodies) if (b.t < NB) { const q = SHAPES[b.t].mass; cx += b.x * q; m += q; }
    cx = m ? cx / m : 0;
    const step = [1.2, 0.8, 0.6][lv - 1], xa = Math.max(-XLIM + 1, M.x0 - 1), xb = Math.min(XLIM - 1, M.x1 + 1);
    const cands = [];
    for (const ad of angs) for (let x = xa; x <= xb + 1e-9; x += step) {
      const xr = Math.round(x * 100) / 100;
      if (landInfo(bodies, mi, type, xr, ad * PI / 180).miss) continue;   // would fall straight off the map
      cands.push({ x: xr, ad, d: Math.abs(xr - cx) });
    }
    if (!cands.length) cands.push({ x: Math.round(cx * 100) / 100, ad: angs[0], d: 0 });
    cands.sort((a, b) => a.d - b.d);
    const scored = [], main = lv === 3 ? budget * 0.65 : budget;
    for (const c of cands) {
      if (scored.length && Date.now() - t0 > main) break;
      const r = evalDrop(pre, type, c.x, c.ad, s.md, mi, tg, hw);
      scored.push({ v: r.v, x: c.x, ad: c.ad, fell: r.fell });
    }
    scored.sort((a, b) => b.v - a.v);
    let best = scored[0];
    if (lv === 3) {
      // polish the best few: nudge sideways, and prefer spots where a small miss would not topple it either
      const top = scored.slice(0, 3), seen = new Set(scored.map((c) => c.ad + ':' + c.x));
      for (const c of top) for (const dx of [-0.2, 0.2]) {
        if (Date.now() - t0 > budget * 0.8) break;
        const x = Math.round(clamp(c.x + dx, -XLIM + 1, XLIM - 1) * 100) / 100;
        if (seen.has(c.ad + ':' + x)) continue; seen.add(c.ad + ':' + x);
        const r = evalDrop(pre, type, x, c.ad, s.md, mi, tg, hw);
        top.push({ v: r.v, x, ad: c.ad, fell: r.fell });
      }
      top.sort((a, b) => b.v - a.v);
      best = top[0];
      for (const c of top.slice(0, 3)) {
        if (Date.now() - t0 > budget) break;
        if (c.fell) continue;
        const r2 = evalDrop(pre, type, c.x + 0.35, c.ad, s.md, mi, tg, hw), r3 = evalDrop(pre, type, c.x - 0.35, c.ad, s.md, mi, tg, hw);
        c.rv = c.v + Math.min(r2.v, r3.v) * 0.5;
        if (best.rv == null || c.rv > best.rv) best = c;
      }
    } else if (lv === 1 && scored.length > 1 && Math.random() < 0.3) {
      best = scored[Math.floor(Math.random() * Math.min(4, scored.length))];   // a beginner does not always see the best spot
    }
    const sig = [0.9, 0.3, 0.06][lv - 1], g = (Math.random() + Math.random() + Math.random() - 1.5) * 0.8;
    let x = Math.round(clamp(best.x + g * sig, -XLIM, XLIM) * 100) / 100, ad = best.ad;
    if (lv > 1 && landInfo(bodies, mi, type, x, ad * PI / 180).miss) x = best.x;
    if (lv === 1 && Math.random() < 0.3) ad += Math.round((Math.random() - 0.5) * 30);
    return { k: 'd', x, a: ((ad % 360) + 360) % 360 };
  }
  function aiDelayFor(s, seat, lv) { return [1500, 1100, 800][clamp((lv || 2) - 1, 0, 2)]; }

  /* ---------- view ---------- */
  const TWX = 26;   // world distance between towers in 높이 경쟁
  // material colours: light side, middle, dark side, top edge
  const MAT = {
    wood: ['#7a4e2a', '#55331a', '#2e1b0d', '#d09a55'],
    marble: ['#e8e2d8', '#bfb7ac', '#857d73', '#fffaf0'],
    brick: ['#a0482f', '#7a3120', '#4a1c12', '#c9744e'],
    gold: ['#f2c65e', '#c38d2e', '#7a5418', '#fff0b4'],
    clay: ['#cc7a46', '#9e542a', '#64301a', '#eea676'],
    grass: ['#64462a', '#46301c', '#28190d', '#7cc052'],
    stone: ['#a29cae', '#77718a', '#4c4656', '#cdc7d8'],
    iron: ['#737a8c', '#4a5060', '#2a2e38', '#b2bacc'],
    shelf: ['#a26c38', '#7a4e24', '#4c2e14', '#e8b26c'],
    ice: ['#dff4ff', '#9fd2f0', '#5b96c6', '#ffffff'],
    plinth: ['#746a80', '#544c60', '#332c3c', '#9a92ac'],
  };
  const THEMES = {
    parlor: ['#251c34', '#1a1424', '#110c17'],
    night: ['#0b1132', '#141640', '#1d1430'],
    canyon: ['#1a0f2e', '#3d1b3a', '#7d3c36'],
    stage: ['#1e0a14', '#290d19', '#14070d'],
    desert: ['#1f0f28', '#4c1d31', '#8f4630'],
    hill: ['#0a1624', '#10272c', '#0d1e1b'],
    park: ['#111634', '#1f1f48', '#2c2142'],
    sky: ['#151f4a', '#2b3268', '#4d3c6c'],
    snow: ['#06101c', '#0c1c2d', '#163044'],
  };

  function mount(root, api) {
    const cv = U.canvas(root);
    let ctx = cv.ctx;
    const topEl = L.h('div', { class: 'hud top', style: { padding: '6px 8px 0', justifyContent: 'space-between', flexWrap: 'nowrap', gap: '6px', alignItems: 'flex-start' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px', flexDirection: 'column', alignItems: 'stretch', gap: '6px' } });
    root.append(topEl, bot);
    const color = (i) => (api.players[i] ? api.players[i].color : '#ccc');
    const nameOf = (i) => (api.players[i] ? api.players[i].name : '');
    let st = null, alive = true, dirty = true, sentAt = 0;
    let towers = [];          // decoded bodies per tower (idle)
    let rep = null;           // {w, last, ti, m, hold, lt, lead, ly0, before}
    let frozen = null;        // {ti, m, b}: bodies kept on screen after the final drop
    let held = null;          // {x, a, turn}
    let hInfo = null;         // cached landing preview for the held block
    let flash = null, shake = null, armMiss = 0, lastDrop = null, holdT = 0;
    const disp = { x: 0, y: 0, a: 0, ok: false };
    const fx = [], pops = [];
    const ptrs = new Map();
    let gest = null;
    const cam = { x: 0, y: -4, tx: 0, ty: -4 };
    let V = null, bgC = null, sceneC = null, hintEl = null;
    const spr = new Map(), sndT = {};

    function area() {
      const tb = topEl.getBoundingClientRect(), bb = bot.getBoundingClientRect(), rr = cv.cv.getBoundingClientRect();
      const top = Math.max(0, (tb.bottom || 0) - rr.top) + 4, b = Math.min(cv.h, (bb.top || cv.h) - rr.top) - 4;
      return { top, bot: Math.max(top + 160, b) };
    }
    function setView() {
      const ar = area(), h = ar.bot - ar.top;
      const s = Math.min(cv.w / 22, h / 21);
      V = { s, ar, h, visH: h / s };
    }
    const WX = (x) => cv.w / 2 + (x - cam.x) * V.s;
    const WY = (y) => V.ar.bot - (y - cam.y) * V.s;

    /* ---- helpers ---- */
    const myTurn = () => st && st.ph !== 'e' && !rep && api.canAct(actor(st)) && !(sentAt && performance.now() - sentAt < 6000);
    const towerX = (ti) => (st && st.md === 'height' ? ti * TWX : 0);
    const mapIdx = () => (rep ? rep.m : frozen ? frozen.m : st ? st.mp : 0);
    function topOf(bodies) { let t = 0; for (const b of bodies) if (!b.gone && b.y > -3) if (b.bb[3] > t) t = b.bb[3]; return t; }
    function heldInfo() {
      if (!held || !st) return null;
      const ti = towerOf(st, st.c), type = blockAt(st.sd, st.k[ti]);
      const key = st.seq + ':' + ti + ':' + type + ':' + held.x + ':' + held.a + ':' + st.mp;
      if (hInfo && hInfo.key === key) return hInfo;
      const a = held.a * PI / 180, Ld = landInfo(towers[ti] || [], st.mp, type, held.x, a);
      hInfo = { key, type, ti, x: held.x, a, land: Ld.y, miss: Ld.miss, hy: Ld.sp + (Ld.hi - Ld.lo) + 0.9 };
      return hInfo;
    }

    /* ---- background (screen space, cached per theme and size) ---- */
    function paintBg(g, w, h, th) {
      let sd = 4242; const R = () => (sd = (sd * 16807) % 2147483647) / 2147483647;
      const T = THEMES[th] || THEMES.parlor;
      const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, T[0]); gr.addColorStop(0.55, T[1]); gr.addColorStop(1, T[2]);
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      const glow = (x, y, r, c) => { const q = g.createRadialGradient(x, y, 0, x, y, r); q.addColorStop(0, c); q.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = q; g.fillRect(x - r, y - r, 2 * r, 2 * r); };
      const stars = (n, y1, a) => { for (let i = 0; i < n; i++) { g.globalAlpha = (0.25 + R() * 0.6) * a; g.fillStyle = '#fff8e8'; g.beginPath(); g.arc(R() * w, R() * h * y1, 0.4 + R() * 1.1, 0, 7); g.fill(); } g.globalAlpha = 1; };
      const ridge = (y, amp, step, col, seed) => { g.fillStyle = col; g.beginPath(); g.moveTo(0, h); for (let x = 0; x <= w + step; x += step) g.lineTo(x, y - Math.abs(Math.sin(x * 0.013 + seed) * amp + Math.sin(x * 0.031 + seed * 2) * amp * 0.4) - R() * amp * 0.15); g.lineTo(w, h); g.closePath(); g.fill(); };
      const hills = (y, amp, col, seed) => { g.fillStyle = col; g.beginPath(); g.moveTo(0, h); for (let x = 0; x <= w + 8; x += 8) g.lineTo(x, y - (Math.sin(x * 0.009 + seed) * 0.6 + Math.sin(x * 0.021 + seed * 3) * 0.4) * amp); g.lineTo(w, h); g.closePath(); g.fill(); };
      if (th === 'parlor') {
        g.fillStyle = 'rgba(255,236,210,.022)'; for (let x = 0; x < w; x += 28) g.fillRect(x, 0, 14, h);
        g.fillStyle = 'rgba(255,236,210,.035)'; for (let y = 20; y < h; y += 40) for (let x = (y / 40 % 2) * 14 + 7; x < w; x += 28) { g.beginPath(); g.arc(x, y, 2, 0, 7); g.fill(); }
        glow(w / 2, h * 0.05, h * 0.75, 'rgba(227,174,69,.13)');
      } else if (th === 'night') {
        stars(90, 0.8, 1);
        glow(w * 0.78, h * 0.17, 80, 'rgba(240,230,200,.16)');
        g.fillStyle = '#f2e9d8'; g.beginPath(); g.arc(w * 0.78, h * 0.17, 20, 0, 7); g.fill();
        g.fillStyle = T[0]; g.beginPath(); g.arc(w * 0.78 + 9, h * 0.17 - 5, 18, 0, 7); g.fill();
      } else if (th === 'canyon') {
        stars(30, 0.4, 0.7);
        glow(w * 0.3, h * 0.78, w * 0.5, 'rgba(255,140,80,.18)');
        ridge(h * 0.62, 70, 14, '#2c1430', 1.3); ridge(h * 0.74, 55, 10, '#1d0d20', 4.1);
      } else if (th === 'stage') {
        for (const sx of [0.22, 0.78]) {
          const q = g.createLinearGradient(0, 0, 0, h); q.addColorStop(0, 'rgba(255,232,180,.13)'); q.addColorStop(1, 'rgba(255,232,180,0)');
          g.fillStyle = q; g.beginPath(); g.moveTo(w * sx - 12, 0); g.lineTo(w * sx + 12, 0); g.lineTo(w * 0.5 + (sx - 0.5) * w * 0.25 + w * 0.2, h); g.lineTo(w * 0.5 + (sx - 0.5) * w * 0.25 - w * 0.2, h); g.closePath(); g.fill();
        }
        for (const side of [0, 1]) {
          const cw = Math.max(26, w * 0.09);
          for (let i = 0; i < 4; i++) {
            const x0 = side ? w - cw + i * cw / 4 : i * cw / 4, q = g.createLinearGradient(x0, 0, x0 + cw / 4, 0);
            q.addColorStop(0, '#4a0c18'); q.addColorStop(0.5, '#8a1a2a'); q.addColorStop(1, '#3a0812'); g.fillStyle = q; g.fillRect(x0, 0, cw / 4 + 0.5, h);
          }
        }
        g.fillStyle = '#6a1020'; for (let x = 0; x < w; x += 30) { g.beginPath(); g.arc(x + 15, 0, 17, 0, PI); g.fill(); }
      } else if (th === 'desert') {
        stars(25, 0.35, 0.6);
        glow(w * 0.5, h * 0.66, w * 0.6, 'rgba(255,150,80,.22)');
        const q = g.createLinearGradient(0, h * 0.5, 0, h * 0.8); q.addColorStop(0, '#ffb35e'); q.addColorStop(1, '#e0533a');
        g.globalAlpha = 0.55; g.fillStyle = q; g.beginPath(); g.arc(w * 0.5, h * 0.66, w * 0.17, 0, 7); g.fill(); g.globalAlpha = 1;
        hills(h * 0.74, 26, '#3a1622', 2.2); hills(h * 0.84, 20, '#250e18', 5.1);
      } else if (th === 'hill') {
        stars(50, 0.5, 0.8);
        g.fillStyle = 'rgba(240,235,210,.8)'; g.beginPath(); g.arc(w * 0.2, h * 0.14, 9, 0, 7); g.fill();
        hills(h * 0.6, 40, '#12302a', 0.7); hills(h * 0.72, 34, '#0e2621', 2.9); hills(h * 0.84, 26, '#0a1c18', 5.3);
        for (let i = 0; i < 26; i++) { const x = R() * w, y = h * (0.45 + R() * 0.5); glow(x, y, 7, 'rgba(216,240,122,.35)'); g.fillStyle = 'rgba(230,250,150,.85)'; g.fillRect(x - 0.8, y - 0.8, 1.6, 1.6); }
      } else if (th === 'park') {
        stars(30, 0.4, 0.6);
        let x = -10; const by = h * 0.66;
        while (x < w) {
          const bw = 22 + R() * 34, bh = 30 + R() * h * 0.2;
          g.fillStyle = '#17152e'; g.fillRect(x, by - bh, bw, h);
          for (let yy = by - bh + 6; yy < by + 40; yy += 9) for (let xx = x + 4; xx < x + bw - 5; xx += 7) if (R() < 0.28) { g.fillStyle = R() < 0.8 ? 'rgba(227,174,69,.45)' : 'rgba(170,210,255,.4)'; g.fillRect(xx, yy, 3, 4); }
          x += bw + 2 + R() * 6;
        }
        hills(h * 0.8, 10, '#121026', 1.1);
      } else if (th === 'sky') {
        stars(40, 0.35, 0.7);
        for (let i = 0; i < 9; i++) {
          const cx = R() * w, cy = h * (0.15 + R() * 0.75), sc = 0.6 + R() * 1.1;
          g.fillStyle = 'rgba(235,225,255,' + (0.05 + R() * 0.07).toFixed(3) + ')';
          for (let k = 0; k < 6; k++) { g.beginPath(); g.ellipse(cx + (k - 2.5) * 16 * sc, cy + Math.sin(k * 2.1) * 5 * sc, 20 * sc, 12 * sc, 0, 0, 7); g.fill(); }
        }
      } else if (th === 'snow') {
        stars(60, 0.6, 0.8);
        for (let b = 0; b < 3; b++) {
          const q = g.createLinearGradient(0, h * 0.08, 0, h * 0.45); q.addColorStop(0, 'rgba(120,255,190,0)'); q.addColorStop(0.5, b === 1 ? 'rgba(110,200,255,.13)' : 'rgba(120,255,190,.14)'); q.addColorStop(1, 'rgba(120,255,190,0)');
          g.fillStyle = q; g.beginPath(); g.moveTo(0, h * 0.45);
          for (let x = 0; x <= w + 10; x += 10) g.lineTo(x, h * (0.2 + b * 0.06) + Math.sin(x * 0.015 + b * 2) * 26 + Math.sin(x * 0.04 + b) * 8);
          for (let x = w + 10; x >= 0; x -= 10) g.lineTo(x, h * (0.34 + b * 0.06) + Math.sin(x * 0.012 + b * 2.4) * 22);
          g.closePath(); g.fill();
        }
        hills(h * 0.78, 22, '#1d344a', 1.7); hills(h * 0.88, 16, '#243e56', 4.2);
        g.fillStyle = 'rgba(255,255,255,.55)'; for (let i = 0; i < 70; i++) { g.beginPath(); g.arc(R() * w, R() * h, 0.6 + R() * 1.2, 0, 7); g.fill(); }
      }
      // gentle vignette so the tower stays the brightest thing
      const vg = g.createRadialGradient(w / 2, h * 0.55, Math.min(w, h) * 0.3, w / 2, h * 0.55, Math.max(w, h) * 0.8);
      vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.35)'); g.fillStyle = vg; g.fillRect(0, 0, w, h);
    }
    function bgCanvas(th) {
      const key = th + ':' + cv.w + 'x' + cv.h + ':' + cv.dpr;
      if (bgC && bgC.key === key) return bgC.c;
      const c = document.createElement('canvas'); c.width = Math.round(cv.w * cv.dpr); c.height = Math.round(cv.h * cv.dpr);
      const g = c.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      paintBg(g, cv.w, cv.h, th);
      bgC = { key, c }; return c;
    }

    /* ---- block sprites (texture baked once per shape and zoom) ---- */
    function paintBlock(g, S, type, k) {
      const R = S.r, px = 1 / k;
      let sd = 97 + type * 131; const rnd = () => (sd = (sd * 16807) % 2147483647) / 2147483647;
      const path = () => { g.beginPath(); S.ol.forEach((q, i) => (i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1]))); g.closePath(); };
      path();
      const gr = g.createLinearGradient(-R * 0.6, R * 0.6, R * 0.6, -R * 0.6);
      gr.addColorStop(0, mixc(S.col, '#fff6e0', 0.2)); gr.addColorStop(0.5, S.col); gr.addColorStop(1, mixc(S.col, '#2a1606', 0.22));
      g.fillStyle = gr; g.fill();
      g.save(); path(); g.clip();
      if (S.id === 'cyl') {
        for (let r = 0.18; r < R; r += 0.16 + rnd() * 0.12) { g.beginPath(); g.arc(0.08, -0.05, r, 0, 7); g.strokeStyle = 'rgba(70,36,10,' + (0.1 + rnd() * 0.16).toFixed(2) + ')'; g.lineWidth = (0.7 + rnd()) * px; g.stroke(); }
        g.strokeStyle = 'rgba(60,30,8,.3)'; g.lineWidth = 1.2 * px; g.beginPath(); g.moveTo(0.08, -0.05); g.lineTo(R * 0.8, -R * 0.35); g.stroke();
      } else {
        for (let y = -R; y <= R; y += 0.14 + rnd() * 0.16) {
          const amp = 0.03 + rnd() * 0.05, ph = rnd() * 6, fq = 0.6 + rnd() * 0.9;
          g.beginPath();
          for (let x = -R; x <= R + 0.01; x += 0.3) { const yy = y + Math.sin(x * fq + ph) * amp; x === -R ? g.moveTo(x, yy) : g.lineTo(x, yy); }
          g.strokeStyle = rnd() < 0.25 ? 'rgba(255,240,210,.12)' : 'rgba(60,30,8,' + (0.07 + rnd() * 0.14).toFixed(2) + ')';
          g.lineWidth = (0.6 + rnd() * 1.1) * px; g.stroke();
        }
        if (S.id === 'rect' || S.id === 'L' || S.id === 'plank') {   // a knot
          const kx = (rnd() - 0.5) * R * 0.8, ky = (rnd() - 0.5) * 0.5;
          for (let r = 0.08; r < 0.34; r += 0.08) { g.beginPath(); g.ellipse(kx, ky, r * 1.8, r, 0, 0, 7); g.strokeStyle = 'rgba(70,34,8,.28)'; g.lineWidth = px; g.stroke(); }
        }
      }
      if (S.id === 'plank') {   // painted chevrons
        g.fillStyle = 'rgba(242,196,72,.9)';
        for (let x = -6.6; x < 6.6; x += 1.5) { g.beginPath(); g.moveTo(x, -0.38); g.lineTo(x + 0.55, -0.38); g.lineTo(x + 0.95, 0.38); g.lineTo(x + 0.4, 0.38); g.closePath(); g.fill(); }
      }
      for (let i = 0; i < 50; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(40,18,4,.10)' : 'rgba(255,245,220,.08)'; g.fillRect((rnd() - 0.5) * 2 * R, (rnd() - 0.5) * 2 * R, 1.3 * px, 1.3 * px); }
      // soft inner bevel all round
      g.lineJoin = 'round';
      path(); g.strokeStyle = 'rgba(255,248,230,.22)'; g.lineWidth = 0.22; g.stroke();
      path(); g.strokeStyle = 'rgba(30,14,2,.18)'; g.lineWidth = 0.09; g.stroke();
      g.restore();
      path(); g.strokeStyle = 'rgba(42,20,6,.85)'; g.lineWidth = 1.3 * px; g.stroke();
    }
    function sprite(type) {
      const k = V.s * cv.dpr, key = type + ':' + k.toFixed(3);
      let e = spr.get(key); if (e) return e;
      if (spr.size > 30) spr.clear();
      const S = SHAPES[type], n = Math.ceil(2 * (S.r + 0.2) * k) + 4;
      const mk = () => { const c = document.createElement('canvas'); c.width = c.height = n; const g = c.getContext('2d'); g.translate(n / 2, n / 2); g.scale(k, -k); return [c, g]; };
      const [c, g] = mk(); paintBlock(g, S, type, k);
      const [sh, g2] = mk(); g2.beginPath(); S.ol.forEach((q, i) => (i ? g2.lineTo(q[0], q[1]) : g2.moveTo(q[0], q[1]))); g2.closePath(); g2.fillStyle = 'rgba(8,4,12,.42)'; g2.fill();
      e = { c, sh, n: n / cv.dpr }; spr.set(key, e); return e;
    }
    function pathOutline(S, x, y, a) {
      const c = dcos(a), s = dsin(a);
      ctx.beginPath();
      S.ol.forEach((q, i) => { const px = WX(x + c * q[0] - s * q[1]), py = WY(y + s * q[0] + c * q[1]); i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); });
      ctx.closePath();
    }
    function drawShadow(type, x, y, a) { const e = sprite(type); ctx.save(); ctx.translate(WX(x) + 2.5, WY(y) + 3.5); ctx.rotate(-a); ctx.drawImage(e.sh, -e.n / 2, -e.n / 2, e.n, e.n); ctx.restore(); }
    function drawBlock(type, x, y, a, o) {
      const S = SHAPES[type], e = sprite(type);
      ctx.save();
      if (o && o.alpha != null) ctx.globalAlpha = o.alpha;
      ctx.translate(WX(x), WY(y)); ctx.rotate(-a); ctx.drawImage(e.c, -e.n / 2, -e.n / 2, e.n, e.n);
      ctx.restore();
      // light always comes from above, whatever way the block is turned
      const R = Math.min(S.r, 2.6) * V.s, cy = WY(y);
      pathOutline(S, x, y, a);
      const lg = ctx.createLinearGradient(0, cy - R, 0, cy + R);
      lg.addColorStop(0, 'rgba(255,244,222,.16)'); lg.addColorStop(0.45, 'rgba(255,244,222,0)'); lg.addColorStop(1, 'rgba(10,4,0,.2)');
      ctx.fillStyle = lg; ctx.fill();
      if (o && o.hl) { ctx.strokeStyle = o.hl; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.stroke(); }
      if (S.pin) {   // the seesaw bolt
        const px = WX(x), py = WY(y), r = Math.max(4, 0.3 * V.s);
        ctx.fillStyle = '#2a2e38'; ctx.beginPath(); ctx.arc(px, py, r + 1.5, 0, 7); ctx.fill();
        ctx.fillStyle = '#b2bacc'; ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.beginPath(); ctx.arc(px - r * 0.3, py - r * 0.3, r * 0.35, 0, 7); ctx.fill();
      }
    }

    /* ---- map pieces ---- */
    function polyPath(poly, ox) { ctx.beginPath(); poly.forEach((p, i) => (i ? ctx.lineTo(WX(p[0] + ox), WY(p[1])) : ctx.moveTo(WX(p[0] + ox), WY(p[1])))); ctx.closePath(); }
    function hLine(x0, x1, y) { ctx.beginPath(); ctx.moveTo(WX(x0), WY(y)); ctx.lineTo(WX(x1), WY(y)); ctx.stroke(); }
    function vLine(x, y0, y1) { ctx.beginPath(); ctx.moveTo(WX(x), WY(y0)); ctx.lineTo(WX(x), WY(y1)); ctx.stroke(); }
    function drawChains(pc, ox) {
      const yT = cam.y + V.visH + 1, y0 = pc.poly[2][1];
      ctx.lineWidth = 1.6; ctx.strokeStyle = '#8a8fa0';
      for (const x of [pc.poly[0][0] + 0.45, pc.poly[1][0] - 0.45]) {
        let i = 0;
        for (let y = y0; y < yT; y += 0.42, i++) {
          ctx.beginPath();
          if (i % 2) ctx.ellipse(WX(x + ox), WY(y + 0.21), 1.4, 0.24 * V.s, 0, 0, 7); else ctx.ellipse(WX(x + ox), WY(y + 0.21), 0.13 * V.s, 0.26 * V.s, 0, 0, 7);
          ctx.stroke();
        }
      }
    }
    function drawPiece(pc, ox, hlTop) {
      const C = MAT[pc.m], poly = pc.poly;
      let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
      for (const p of poly) { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); }
      const yb = Math.max(y0, cam.y - 1.5);
      if (yb > y1) return;
      x0 += ox; x1 += ox;
      if (WX(x1) < -20 || WX(x0) > cv.w + 20) return;
      polyPath(poly, ox);
      const g = ctx.createLinearGradient(WX(x0), 0, WX(x1), 0);
      g.addColorStop(0, C[0]); g.addColorStop(0.45, C[1]); g.addColorStop(1, C[2]);
      ctx.fillStyle = g; ctx.fill();
      ctx.save(); ctx.clip();
      ctx.lineWidth = 1;
      const m = pc.m;
      if (m === 'wood') {
        ctx.strokeStyle = 'rgba(20,10,2,.28)';
        for (let x = x0 + 0.4; x < x1; x += 0.75) { ctx.beginPath(); for (let y = y1; y >= yb - 0.5; y -= 0.5) { const px = WX(x + Math.sin(y * 1.3 + x * 2.7) * 0.07), py = WY(y); y === y1 ? ctx.moveTo(px, py) : ctx.lineTo(px, py); } ctx.stroke(); }
        ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.fillRect(WX(x0), WY(y1 - 0.55), WX(x1) - WX(x0), 2);
      } else if (m === 'shelf') {
        ctx.strokeStyle = 'rgba(20,10,2,.3)'; hLine(x0, x1, (y0 + y1) / 2);
        ctx.fillStyle = '#2a2e38'; for (const x of [x0 + 0.45, x1 - 0.45]) { ctx.beginPath(); ctx.arc(WX(x), WY((y0 + y1) / 2), 2.2, 0, 7); ctx.fill(); }
      } else if (m === 'marble') {
        for (let x = x0 + 0.42; x < x1 - 0.2; x += 0.85) { ctx.strokeStyle = 'rgba(255,255,255,.35)'; vLine(x, y1 - 0.5, yb); ctx.strokeStyle = 'rgba(70,60,70,.28)'; vLine(x + 0.14, y1 - 0.5, yb); }
        ctx.strokeStyle = 'rgba(90,80,100,.35)';
        for (let v = 0; v < 3; v++) { ctx.beginPath(); let x = x0 + 1 + v * 2; for (let y = y1; y > yb; y -= 0.6) { x += Math.sin(y * 2.3 + v * 5) * 0.25; y === y1 ? ctx.moveTo(WX(x), WY(y)) : ctx.lineTo(WX(x), WY(y)); } ctx.stroke(); }
        ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(WX(x0), WY(y1 - 0.25), WX(x1) - WX(x0), 2);
        ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.fillRect(WX(x0), WY(y1 - 0.5), WX(x1) - WX(x0), 2);
      } else if (m === 'brick') {
        ctx.strokeStyle = 'rgba(30,10,6,.6)'; ctx.lineWidth = 1.5;
        let row = 0;
        for (let y = y1; y > yb - 0.8; y -= 0.8, row++) {
          hLine(x0, x1, y);
          for (let x = x0 + (row % 2 ? 0.8 : 0); x < x1; x += 1.6) vLine(x, y, y - 0.8);
          ctx.fillStyle = row % 3 === 1 ? 'rgba(255,200,170,.06)' : 'rgba(0,0,0,.05)'; ctx.fillRect(WX(x0), WY(y), WX(x1) - WX(x0), 0.8 * V.s);
        }
      } else if (m === 'gold') {
        ctx.fillStyle = 'rgba(255,250,220,.2)';
        for (const f of [0.18, 0.62]) { const xa = x0 + (x1 - x0) * f; ctx.beginPath(); ctx.moveTo(WX(xa), WY(y1)); ctx.lineTo(WX(xa + 0.5), WY(y1)); ctx.lineTo(WX(xa - 1.5), WY(yb)); ctx.lineTo(WX(xa - 2), WY(yb)); ctx.closePath(); ctx.fill(); }
        ctx.strokeStyle = 'rgba(90,56,10,.5)'; hLine(x0, x1, y1 - 0.35);
        if (pc.lab) {
          const fs = Math.round(1.25 * V.s);
          ctx.font = '400 ' + fs + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillStyle = 'rgba(90,56,10,.6)'; ctx.fillText(pc.lab, (WX(x0) + WX(x1)) / 2, WY(y1 - 1.35));
        }
      } else if (m === 'clay') {
        ctx.strokeStyle = 'rgba(250,220,170,.55)'; ctx.lineWidth = 1.4;
        hLine(x0, x1, -2.3); hLine(x0, x1, -3.5);
        ctx.beginPath(); for (let x = x0, i = 0; x <= x1 + 0.01; x += 0.6, i++) { const y = i % 2 ? -2.5 : -3.3; i ? ctx.lineTo(WX(x), WY(y)) : ctx.moveTo(WX(x), WY(y)); } ctx.stroke();
        ctx.fillStyle = 'rgba(40,14,4,.25)'; for (let x = x0 + 0.3; x < x1; x += 1.2) { ctx.beginPath(); ctx.arc(WX(x), WY(-4.3), 1.8, 0, 7); ctx.fill(); }
      } else if (m === 'grass') {
        ctx.fillStyle = 'rgba(0,0,0,.18)';
        for (let i = 0; i < 40; i++) { const x = x0 + ((i * 37) % 97) / 97 * (x1 - x0), y = y1 - 1.2 - ((i * 53) % 89) / 89 * 9; if (y > yb) { ctx.beginPath(); ctx.ellipse(WX(x), WY(y), 0.22 * V.s, 0.14 * V.s, 0, 0, 7); ctx.fill(); } }
      } else if (m === 'stone') {
        ctx.fillStyle = 'rgba(0,0,0,.2)'; for (let i = 0; i < 6; i++) ctx.fillRect(WX(x0 + 0.1 + (i % 3) * 0.18), WY(y1 - 0.15 - Math.floor(i / 3) * 0.4), 1.5, 1.5);
      } else if (m === 'iron') {
        ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(WX(x0) + 2, WY(y1), 2, WY(yb) - WY(y1));
        ctx.fillStyle = '#2a2e38'; for (let y = y1 - 0.4; y > yb; y -= 1.1) { ctx.beginPath(); ctx.arc((WX(x0) + WX(x1)) / 2, WY(y), 1.6, 0, 7); ctx.fill(); }
      } else if (m === 'ice') {
        ctx.strokeStyle = 'rgba(255,255,255,.45)'; ctx.lineWidth = 1.2;
        for (let x = x0 + 0.8; x < x1; x += 2.1) { ctx.beginPath(); ctx.moveTo(WX(x), WY(y1 - 0.5)); ctx.lineTo(WX(x + 1.1), WY(y1 - 2.6)); ctx.stroke(); }
        ctx.strokeStyle = 'rgba(40,90,140,.35)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(WX(x0 + 2), WY(y1 - 1)); ctx.lineTo(WX(x0 + 2.9), WY(y1 - 2.2)); ctx.lineTo(WX(x0 + 2.4), WY(y1 - 3.3)); ctx.moveTo(WX(x0 + 2.9), WY(y1 - 2.2)); ctx.lineTo(WX(x0 + 3.8), WY(y1 - 2.6)); ctx.stroke();
      } else if (m === 'plinth') {
        ctx.strokeStyle = 'rgba(20,14,28,.5)';
        let row = 0; for (let y = y1; y > yb - 1; y -= 1.1, row++) { hLine(x0, x1, y); for (let x = x0 + (row % 2 ? 1.3 : 0); x < x1; x += 2.6) vLine(x, y, y - 1.1); }
      }
      ctx.restore();
      // top edges (outward normal pointing up) get the light
      ctx.lineCap = 'round';
      for (let i = 0; i < poly.length; i++) {
        const a = poly[i], b = poly[(i + 1) % poly.length], ex = b[0] - a[0], ey = b[1] - a[1], l = Math.hypot(ex, ey);
        if (-ex / l < 0.4) continue;   // outward normal of a CCW edge is (ey, -ex)/l
        const ax = WX(a[0] + ox), ay = WY(a[1]), bx = WX(b[0] + ox), by = WY(b[1]);
        if (m === 'grass') {
          ctx.strokeStyle = '#3e7a2c'; ctx.lineWidth = 0.42 * V.s; ctx.beginPath(); ctx.moveTo(ax, ay + 0.12 * V.s); ctx.lineTo(bx, by + 0.12 * V.s); ctx.stroke();
          ctx.strokeStyle = C[3]; ctx.lineWidth = 2;
          for (let t = 0.02; t < 1; t += 0.035) { const x = ax + (bx - ax) * t, y = ay + (by - ay) * t; ctx.beginPath(); ctx.moveTo(x, y + 2); ctx.lineTo(x + Math.sin(t * 97) * 2, y - 3 - Math.abs(Math.sin(t * 53)) * 3); ctx.stroke(); }
        } else if (m === 'ice') {
          ctx.strokeStyle = '#f4fbff'; ctx.lineWidth = Math.max(4, 0.32 * V.s); ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
          ctx.fillStyle = '#f4fbff'; for (let t = 0.1; t < 1; t += 0.23) { ctx.beginPath(); ctx.ellipse(ax + (bx - ax) * t, ay + 0.2 * V.s, 0.12 * V.s, 0.3 * V.s, 0, 0, 7); ctx.fill(); }
        } else { ctx.strokeStyle = C[3]; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(ax, ay + 1); ctx.lineTo(bx, by + 1); ctx.stroke(); }
        if (hlTop) { ctx.strokeStyle = 'rgba(227,174,69,.9)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(ax, ay - 2); ctx.lineTo(bx, by - 2); ctx.stroke(); }
      }
      ctx.lineCap = 'butt';
      polyPath(poly, ox); ctx.strokeStyle = 'rgba(8,4,12,.5)'; ctx.lineWidth = 1; ctx.stroke();
    }
    function drawMap(mi, ox, hlTop) {
      const M = MAPS[mi];
      for (const pc of M.pc) if (pc.hang) drawChains(pc, ox);
      for (const pc of M.pc) drawPiece(pc, ox, hlTop);
    }

    function drawRuler() {
      const x = 14, step = 2;
      ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.fillStyle = 'rgba(242,233,216,.5)'; ctx.lineWidth = 1;
      ctx.font = '500 10px "IBM Plex Mono", monospace'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      const y0 = Math.max(0, Math.floor(cam.y / step) * step);
      for (let h = y0; h < cam.y + V.visH + 2; h += step) {
        const py = WY(h); if (py < V.ar.top + 8 || py > V.ar.bot + 4) continue;
        const big = h % 10 === 0;
        ctx.beginPath(); ctx.moveTo(x, py); ctx.lineTo(x + (big ? 12 : 6), py); ctx.stroke();
        if (big || h % 4 === 0) ctx.fillText(String(h), x + 15, py);
      }
      if (st && st.md === 'coop') {
        const py = WY(st.tg);
        if (py >= V.ar.top + 6) {
          ctx.strokeStyle = '#e3ae45'; ctx.setLineDash([6, 5]); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(cv.w, py); ctx.stroke(); ctx.setLineDash([]);
          ctx.fillStyle = '#e3ae45'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.fillText('목표 ' + st.tg, 50, py - 9);
        } else {   // goal above the view: a pill at the top that says how far it is
          const h = rep ? rep.w.height() : st.hi[0], t = '▲ 목표 ' + st.tg + ' · ' + Math.max(0, st.tg - h).toFixed(1) + ' 남음';
          ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; const tw = ctx.measureText(t).width + 20, x = cv.w / 2 - tw / 2, y = V.ar.top + 4;
          ctx.fillStyle = 'rgba(34,28,46,.9)'; ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, tw, 24, 12) : ctx.rect(x, y, tw, 24); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#e3ae45'; ctx.fillText(t, cv.w / 2, y + 12);
        }
      }
    }
    // everything that does not move while a player aims (cached between frames)
    function drawStatic() {
      ctx.drawImage(bgCanvas((MAPS[mapIdx()] || MAPS[0]).th), 0, 0, cv.w, cv.h);
      if (!st) return;
      drawRuler();
      const mi = mapIdx(), nT = st.md === 'height' ? st.n : 1;
      const act = rep ? rep.ti : st.ph !== 'e' ? towerOf(st, st.c) : -1;
      for (let ti = 0; ti < nT; ti++) {
        const ox = towerX(ti);
        if (Math.abs(WX(ox) - cv.w / 2) > cv.w) continue;
        drawMap(mi, ox, st.md === 'height' && ti === act);
        if (st.md === 'height') {
          ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
          ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,6,14,.7)'; const ty = WY(MAPS[mi].fy) + 10;
          ctx.strokeText(nameOf(ti), WX(ox), ty); ctx.fillStyle = color(ti); ctx.fillText(nameOf(ti), WX(ox), ty);
        }
        const list = rep && rep.ti === ti ? rep.w.b : frozen && frozen.ti === ti ? frozen.b : towers[ti] || [];
        const leadNb = rep && rep.ti === ti && rep.lt < rep.lead ? rep.w.nb : null;
        for (const b of list) if (!b.gone) drawShadow(b.t, b.x + ox, leadY(b), b.a);
        for (const b of list) {
          if (b.gone) continue;
          drawBlock(b.t, b.x + ox, leadY(b), b.a, rep && rep.ti === ti && b === rep.w.nb && !rep.w.done ? { hl: 'rgba(227,174,69,.9)' } : null);
        }
        if (leadNb) {   // a short speed trail while it is let go
          ctx.strokeStyle = 'rgba(242,233,216,.18)'; ctx.lineWidth = 2;
          vLine(leadNb.x + ox - 0.6, leadY(leadNb) + SHAPES[leadNb.t].r * 0.6, leadY(leadNb) + SHAPES[leadNb.t].r * 0.6 + 1.2);
          vLine(leadNb.x + ox + 0.6, leadY(leadNb) + SHAPES[leadNb.t].r * 0.6, leadY(leadNb) + SHAPES[leadNb.t].r * 0.6 + 1.2);
        }
        if (st.md === 'height') {
          const h = rep && rep.ti === ti ? rep.w.height() : st.hi[ti];
          if (h > 0.2) { const py = WY(h); ctx.strokeStyle = color(ti); ctx.globalAlpha = 0.7; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(WX(ox + MAPS[mi].x0 - 0.5), py); ctx.lineTo(WX(ox + MAPS[mi].x1 + 0.5), py); ctx.stroke(); ctx.globalAlpha = 1; }
        }
      }
      drawNext(drawMinis());
    }
    function leadY(b) {
      if (!rep || b !== rep.w.nb || rep.lt >= rep.lead) return b.y;
      const k = rep.lt / rep.lead;
      return rep.ly0 + (b.y - rep.ly0) * k * k;
    }
    function drawScene(now) {
      setView();
      cv.clear();
      ctx.save();
      if (shake) {
        const k = (now - shake.t0) / 600;
        if (k >= 1) shake = null; else ctx.translate(Math.sin(now * 0.09) * shake.amp * (1 - k), Math.cos(now * 0.11) * shake.amp * 0.5 * (1 - k));
      }
      if (!st) { ctx.drawImage(bgCanvas('parlor'), 0, 0, cv.w, cv.h); ctx.restore(); return; }
      if (rep || shake) drawStatic();
      else {
        const key = [cv.w, cv.h, cv.dpr, cam.x.toFixed(3), cam.y.toFixed(3), st.seq, st.ph, st.c, frozen ? 1 : 0, mapIdx(), towers.length, V.ar.top, V.ar.bot].join('|');
        if (!sceneC || sceneC.key !== key) {
          const W = Math.round(cv.w * cv.dpr), H = Math.round(cv.h * cv.dpr);
          if (!sceneC || sceneC.c.width !== W || sceneC.c.height !== H) { const c = document.createElement('canvas'); c.width = W; c.height = H; sceneC = { c, g: c.getContext('2d'), key: '' }; }
          const g = sceneC.g; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
          ctx = g; try { drawStatic(); } finally { ctx = cv.ctx; }
          sceneC.key = key;
        }
        ctx.drawImage(sceneC.c, 0, 0, cv.w, cv.h);
      }
      if (!st) { ctx.restore(); return; }
      // held block, its fall line and the landing preview
      const hp = myTurn() && held ? heldInfo() : null;
      if (hp) {
        const ox = towerX(hp.ti), S = SHAPES[hp.type], bob = Math.sin(now / 380) * 0.08;
        const lcol = hp.miss ? 'rgba(238,106,85,.75)' : 'rgba(227,174,69,.55)';
        ctx.strokeStyle = lcol; ctx.setLineDash([3, 5]); ctx.lineWidth = 1.3;
        if (!hp.miss) vLine(hp.x + ox, disp.y - 0.5, hp.land);
        else vLine(hp.x + ox, disp.y - 0.5, cam.y - 2);
        ctx.setLineDash([]);
        if (!hp.miss) {
          drawBlock(hp.type, hp.x + ox, hp.land, hp.a, { alpha: 0.32 });
          pathOutline(S, hp.x + ox, hp.land, hp.a);
          ctx.setLineDash([5, 4]); ctx.strokeStyle = 'rgba(242,233,216,.85)'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]);
          // centre of mass + plumb line: shows which way it will lean
          const cx = WX(hp.x + ox), cy = WY(hp.land);
          ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx, cy + S.r * V.s + 6); ctx.stroke();
          ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(cx, cy, 3.2, 0, 7); ctx.fill(); ctx.strokeStyle = '#1a1424'; ctx.lineWidth = 1.2; ctx.stroke();
        }
        drawShadow(hp.type, disp.x + ox, disp.y + bob, disp.a);
        drawBlock(hp.type, disp.x + ox, disp.y + bob, disp.a, { hl: hp.miss ? '#ee6a55' : '#e3ae45' });
        if (hp.miss) {
          const tx = clamp(WX(hp.x + ox), 70, cv.w - 70), ty = WY(disp.y + SHAPES[hp.type].r + 0.9);
          ctx.font = '700 12.5px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,12,24,.85)'; ctx.strokeText('받침대 밖이에요!', tx, ty);
          ctx.fillStyle = '#ee6a55'; ctx.fillText('받침대 밖이에요!', tx, ty);
        }
      }
      // dust and labels
      for (const p of fx) { ctx.globalAlpha = clamp(p.life / p.l0, 0, 1) * 0.5; ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(WX(p.x), WY(p.y), p.r * (1.6 - p.life / p.l0 * 0.6), 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
      for (const p of pops) {
        const k = (now - p.t0) / 1100; if (k >= 1) continue;
        ctx.globalAlpha = k < 0.15 ? k / 0.15 : 1 - Math.max(0, (k - 0.6) / 0.4);
        ctx.font = '700 15px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const y = WY(p.y) - k * 22;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,12,24,.85)'; ctx.strokeText(p.text, WX(p.x), y); ctx.fillStyle = p.c; ctx.fillText(p.text, WX(p.x), y);
      }
      ctx.globalAlpha = 1;
      if (flash) {
        const k = clamp((now - flash.t0) / (flash.d || 1400), 0, 1);
        if (k >= 1) flash = null;
        else {
          ctx.globalAlpha = k < 0.12 ? k / 0.12 : 1 - Math.max(0, (k - 0.6) / 0.4);
          const y = V.ar.top + V.h * 0.3, sc = 1 + (1 - k) * 0.12;
          ctx.font = '400 ' + Math.round(34 * sc) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, cv.w / 2, y);
          ctx.fillStyle = flash.c; ctx.fillText(flash.text, cv.w / 2, y);
          if (flash.sub) { ctx.font = '700 13px "IBM Plex Sans KR", sans-serif'; ctx.lineWidth = 4; ctx.strokeText(flash.sub, cv.w / 2, y + 30); ctx.fillStyle = '#f2e9d8'; ctx.fillText(flash.sub, cv.w / 2, y + 30); }
          ctx.globalAlpha = 1;
        }
      }
      ctx.restore();
    }
    // 높이 경쟁: every tower in miniature, side by side
    function drawMinis() {
      if (!st || st.md !== 'height' || st.n < 2) return 0;
      const n = st.n, cw = 40, gap = 6, H = 66, W = n * cw + (n - 1) * gap + 12, x0 = cv.w - W - 8, y0 = V.ar.top + 2;
      ctx.fillStyle = 'rgba(34,28,46,.88)'; ctx.strokeStyle = 'rgba(242,233,216,.13)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x0, y0, W, H, 10) : ctx.rect(x0, y0, W, H); ctx.fill(); ctx.stroke();
      let hmax = 12; for (let i = 0; i < n; i++) hmax = Math.max(hmax, st.hi[i] + 1, rep && rep.ti === i ? rep.w.height() + 1 : 0);
      const m = Math.min(2.4, (H - 18) / hmax), M = MAPS[mapIdx()];
      for (let i = 0; i < n; i++) {
        const cx = x0 + 6 + i * (cw + gap) + cw / 2, by = y0 + H - 12;
        const act = (rep ? rep.ti : towerOf(st, st.c)) === i;
        ctx.save(); ctx.beginPath(); ctx.rect(cx - cw / 2, y0 + 3, cw, H - 6); ctx.clip();
        ctx.fillStyle = act ? '#c9934e' : '#6a4a2c';
        for (const pc of M.pc) { ctx.beginPath(); pc.poly.forEach((q, k) => (k ? ctx.lineTo(cx + q[0] * m, by - Math.max(q[1], -3) * m) : ctx.moveTo(cx + q[0] * m, by - Math.max(q[1], -3) * m))); ctx.closePath(); ctx.fill(); }
        const list = rep && rep.ti === i ? rep.w.b : frozen && frozen.ti === i ? frozen.b : towers[i] || [];
        for (const b of list) {
          if (b.gone) continue;
          const S = SHAPES[b.t], c = dcos(b.a), sn = dsin(b.a);
          ctx.beginPath();
          S.ol.forEach((q, k) => { const px = cx + (b.x + c * q[0] - sn * q[1]) * m, py = by - (b.y + sn * q[0] + c * q[1]) * m; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); });
          ctx.closePath(); ctx.fillStyle = S.col; ctx.fill();
        }
        ctx.restore();
        ctx.fillStyle = color(i); ctx.beginPath(); ctx.arc(cx, by + 7, 3, 0, 7); ctx.fill();
        if (act) { ctx.strokeStyle = 'rgba(227,174,69,.8)'; ctx.lineWidth = 1.2; ctx.strokeRect(cx - cw / 2, y0 + 4, cw, H - 8); }
      }
      return H + 6;
    }
    function drawNext(dy) {
      if (!st || st.ph === 'e' || rep) return;
      const ti = towerOf(st, st.c), k = st.k[ti];
      if (st.md !== 'duel' && k + 1 >= (st.nb || 1e9)) return;
      const t = blockAt(st.sd, k + 1), S = SHAPES[t];
      const bw = 64, bh = 54, x = cv.w - bw - 8, y = V.ar.top + 2 + (dy || 0);
      ctx.fillStyle = 'rgba(34,28,46,.88)'; ctx.strokeStyle = 'rgba(242,233,216,.13)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, bw, bh, 10) : ctx.rect(x, y, bw, bh); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#ab9fb8'; ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText('다음', x + bw / 2, y + 4);
      const e = sprite(t), sz = e.n * (16 / (S.r * V.s));
      ctx.drawImage(e.c, x + bw / 2 - sz / 2, y + 33 - sz / 2, sz, sz);
    }

    /* ---- camera ---- */
    function camTarget() {
      if (!st || !V) return;
      const ti = rep ? rep.ti : st.ph !== 'e' ? towerOf(st, st.c) : frozen ? frozen.ti : 0, M = MAPS[mapIdx()];
      cam.tx = towerX(ti);
      let top = Math.max(0, M.top);
      if (rep) { for (const b of rep.w.b) if (!b.gone && b.y > M.fy && b !== rep.w.nb) top = Math.max(top, b.bb[3]); top = Math.max(top, rep.w.nb.y - 2); }
      else top = Math.max(top, topOf(frozen && frozen.ti === ti ? frozen.b : towers[ti] || []));
      const need = top + 11;               // room for the held block above the tower
      cam.ty = Math.max(M.cam != null ? M.cam : -4.5, need - V.visH);
    }

    /* ---- input ---- */
    function newHeld() { held = { x: 0, a: 0, turn: st.seq + ':' + st.c }; disp.ok = false; armMiss = 0; }
    function setX(nx) {
      nx = Math.round(clamp(nx, -XLIM + 1, XLIM - 1) * 20) / 20;
      if (Math.floor(nx) !== Math.floor(held.x)) api.sfx('tick');
      if (nx !== held.x) armMiss = 0;
      held.x = nx; dirty = true;
    }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (!myTurn()) return;
      const p = cv.local(ev);
      ptrs.set(ev.pointerId, p);
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      if (!held) newHeld();
      if (ptrs.size === 1) gest = { mode: 'drag', x0: p.x, y0: p.y, hx0: held.x, moved: false, twisted: false };
      else if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        gest = Object.assign(gest || {}, { mode: 'twist', ang0: Math.atan2(b.y - a.y, b.x - a.x), a0: held.a, twisted: true });
      }
      dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!ptrs.has(ev.pointerId) || !gest || !held) return;
      const p = cv.local(ev); ptrs.set(ev.pointerId, p);
      if (gest.mode === 'drag' && ptrs.size === 1) {
        const dx = p.x - gest.x0;
        if (Math.abs(dx) > 6 || Math.abs(p.y - gest.y0) > 6) gest.moved = true;
        if (gest.moved) setX(gest.hx0 + dx / V.s);
      } else if (gest.mode === 'twist' && ptrs.size >= 2) {
        const [a, b] = [...ptrs.values()];
        const d = Math.atan2(b.y - a.y, b.x - a.x) - gest.ang0;
        const na = Math.round((gest.a0 - d * 180 / PI) / 5) * 5;
        if (Math.round(na / 15) !== Math.round(held.a / 15)) api.sfx('tick');
        held.a = ((na % 360) + 360) % 360; armMiss = 0; updHint();
      }
      dirty = true;
    });
    function endPtr(ev) {
      if (!ptrs.has(ev.pointerId)) return;
      const p = cv.local(ev);
      ptrs.delete(ev.pointerId);
      if (!gest) return;
      if (ptrs.size > 0) { if (gest.mode === 'twist') gest.mode = 'idle'; return; }
      const g = gest; gest = null;
      if (!held || !myTurn()) return;
      // a tap moves the block straight to that spot (it never drops it — only the button does)
      if (!g.moved && !g.twisted && g.mode === 'drag') { setX(cam.x + (p.x - cv.w / 2) / V.s - towerX(towerOf(st, st.c))); api.buzz(6); }
      updHint();
    }
    cv.cv.addEventListener('pointerup', endPtr);
    cv.cv.addEventListener('pointercancel', (ev) => { ptrs.delete(ev.pointerId); gest = null; });
    function drop() {
      if (!myTurn()) return;
      if (!held) newHeld();
      const hp = heldInfo();
      if (hp && hp.miss && !(armMiss && performance.now() - armMiss < 3000)) {
        armMiss = performance.now(); api.sfx('click'); api.buzz(20);
        api.toast('받침대 밖이에요! 정말 놓으려면 한 번 더 눌러요', 2400);
        return;
      }
      armMiss = 0;
      api.sfx('whoosh'); api.buzz(14);
      if (!api.isHost) sentAt = performance.now();
      lastDrop = { y: disp.ok ? disp.y : null, t: performance.now() };
      api.act({ k: 'd', x: Math.round(held.x * 100) / 100, a: held.a });
      renderHud(true);
    }
    function rot(d) { if (!myTurn()) return; if (!held) newHeld(); held.a = ((held.a + d) % 360 + 360) % 360; armMiss = 0; api.sfx('tick'); api.buzz(6); updHint(); dirty = true; }
    function stopHold() { if (holdT) { clearTimeout(holdT); clearInterval(holdT); holdT = 0; } }
    function onKey(ev) {
      if (!myTurn() || ev.ctrlKey || ev.metaKey || ev.altKey) return;
      const tg = ev.target && ev.target.tagName;
      if (tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'BUTTON' || document.querySelector('.overlay')) return;
      if (!held) newHeld();
      const k = ev.key;
      if (k === 'ArrowLeft' || k === 'ArrowRight') { setX(held.x + (k === 'ArrowLeft' ? -1 : 1) * (ev.shiftKey ? 1 : 0.25)); updHint(); }
      else if (k === 'q' || k === 'Q' || k === 'z' || k === 'Z' || k === 'ArrowUp') rot(15);
      else if (k === 'e' || k === 'E' || k === 'x' || k === 'X' || k === 'ArrowDown') rot(-15);
      else if (k === ' ' || k === 'Enter') drop();
      else return;
      ev.preventDefault();
    }
    window.addEventListener('keydown', onKey);

    /* ---- HUD ---- */
    let hudKey = '';
    function hintText() {
      if (!st || !held) return '';
      const S = SHAPES[blockAt(st.sd, st.k[towerOf(st, st.c)])];
      return (api.mySeats().length > 1 ? nameOf(st.c) + ' · ' : '') + S.nm + ' ' + held.a + '° · 끌거나 탭해서 옮기고, 버튼으로 놓아요';
    }
    function updHint() { if (hintEl) hintEl.textContent = hintText(); }
    function renderHud(force) {
      if (!st) return;
      const mine = myTurn();
      const key = [st.seq, st.c, st.ph, mine, rep ? 1 : 0, st.rd, st.sc.join(','), sentAt ? 1 : 0, mapIdx()].join('|');
      if (key === hudKey && !force) return;
      hudKey = key; stopHold();
      topEl.innerHTML = '';
      const chip = (txt, b) => L.h('div', { class: 'panel', style: { padding: '5px 10px', fontSize: '12px', whiteSpace: 'nowrap' } }, txt, b ? L.h('b', { class: 'mono', style: { color: 'var(--brass)' }, text: b }) : null);
      const row = (...k) => L.h('div', { style: { display: 'flex', gap: '4px', flexWrap: 'wrap', alignItems: 'center' } }, ...k);
      const mapChip = L.h('div', { class: 'panel', style: { padding: '5px 10px', fontSize: '12px', whiteSpace: 'nowrap', color: 'var(--muted)' }, text: MAPS[mapIdx()].nm });
      const scores = (vals) => L.h('div', { class: 'panel mono sk-scores', style: { padding: '4px 8px', fontSize: '11.5px', display: 'flex', gap: '8px', flexWrap: 'wrap', alignSelf: 'flex-start' } },
        vals.map((v, i) => L.h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '4px' } }, L.h('span', { class: 'dot', style: { '--c': color(i), width: '8px', height: '8px' } }), v)));
      const left = L.h('div', { class: 'sk-info', style: { display: 'flex', flexDirection: 'column', gap: '4px', alignItems: 'flex-start', minWidth: 0 } });
      if (st.md === 'duel') {
        left.append(row(chip(st.n > 1 ? '라운드 ' : '혼자 쌓기 ', st.n > 1 ? st.rd + '/' + st.nr : ''), chip('블록 ', String(st.k[0])), mapChip));
        if (st.n > 1) left.append(scores(st.sc.map(String)));
      } else if (st.md === 'height') {
        left.append(row(chip('블록 ', Math.min(st.k[towerOf(st, st.c)] + (st.ph === 'e' ? 0 : 1), st.nb) + '/' + st.nb), mapChip));
        left.append(scores(st.hi.map((v) => v.toFixed(1))));
      } else {
        left.append(row(chip('높이 ', st.hi[0].toFixed(1) + ' / ' + st.tg), chip('남은 블록 ', String(Math.max(0, st.nb - st.k[0]))), mapChip));
      }
      topEl.append(left);
      bot.innerHTML = ''; hintEl = null;
      if (st.ph === 'e') return;
      const a = rep ? rep.last.s : actor(st);
      if (mine) {
        if (!held || held.turn !== st.seq + ':' + st.c) newHeld();
        const rb = (t, lab, d) => {
          let fired = false;
          const b = L.h('button', { class: 'btn sk-rot', type: 'button', 'aria-label': lab, text: t, style: { flex: 'none', width: '54px', padding: 0, fontSize: '21px', minHeight: '50px' }, onclick: () => { if (fired) { fired = false; return; } rot(d); } });
          // hold to keep turning
          b.addEventListener('pointerdown', () => { fired = false; stopHold(); holdT = setTimeout(() => { fired = true; rot(d); holdT = setInterval(() => rot(d), 110); }, 380); });
          for (const e of ['pointerup', 'pointerleave', 'pointercancel']) b.addEventListener(e, stopHold);
          return b;
        };
        hintEl = L.h('div', { class: 'sk-hint', style: { fontSize: '11.5px', textAlign: 'center', color: '#e6dccb', background: 'rgba(23,19,31,.78)', borderRadius: '10px', padding: '3px 10px', alignSelf: 'center', maxWidth: '100%', boxSizing: 'border-box', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: hintText() });
        bot.append(hintEl,
          L.h('div', { style: { display: 'flex', gap: '8px' } }, rb('⟲', '왼쪽으로 15° 돌리기', 15),
            L.h('button', { class: 'btn primary sk-drop', type: 'button', text: '떨어뜨리기', style: { flex: '1 1 auto', minHeight: '50px', fontSize: '16px' }, onclick: drop }),
            rb('⟳', '오른쪽으로 15° 돌리기', -15)));
      } else {
        const hint = rep ? '블록이 떨어지는 중…' : sentAt ? '보내는 중…' : api.players[a] && api.players[a].ai ? '어디에 둘지 보는 중…' : '차례를 기다리는 중';
        bot.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px' } },
          L.h('span', { class: 'dot', style: { '--c': color(a) } }), L.h('b', { style: { fontSize: '13px' }, text: nameOf(a) }), L.h('span', { class: 'muted', style: { fontSize: '12px' }, text: hint })));
      }
    }

    /* ---- replay ---- */
    function startReplay(l) {
      const w = dropSim(l.pre, l.b, l.x, l.a, l.m);
      const before = w.b.slice(0, -1).map((b) => [b.x, b.y, b.t]);
      const mineDrop = lastDrop && performance.now() - lastDrop.t < 7000 && lastDrop.y != null && api.canAct(l.s);
      const ly0 = mineDrop ? Math.max(lastDrop.y, w.nb.y) : w.nb.y + 2.4;
      lastDrop = null;
      rep = { w, last: l, ti: l.ti, m: l.m, hold: 0, lt: 0, lead: ly0 - w.nb.y > 0.05 ? clamp(Math.sqrt(2 * (ly0 - w.nb.y) / 40), 0.12, 0.32) : 0, ly0, before };
      frozen = null;
      api.setBusy(true);
      renderHud(true);
    }
    function playSounds(w, ox) {
      const now = performance.now();
      for (const e of w.snd) {
        if (e.k === 'hit' && fx.length < 60) {
          const n = e.v > 10 ? 6 : 3;
          for (let i = 0; i < n; i++) fx.push({ x: e.x + ox + (Math.random() - 0.5) * 0.6, y: e.y, vx: (Math.random() - 0.5) * 3, vy: 0.5 + Math.random() * 1.5, r: 2 + Math.random() * 2.5, life: 0.5 + Math.random() * 0.3, l0: 0.8, c: '#e9dcc4' });
        }
        const m = { hit: [e.v > 9 ? 'thud' : 'tick', 50], fall: ['whoosh', 200], drop: ['thud', 200] }[e.k];
        if (!m || (sndT[e.k] && now - sndT[e.k] < m[1])) continue;
        sndT[e.k] = now; api.sfx(m[0]); if (e.k === 'hit' && e.v > 9) api.buzz(10);
      }
      w.snd.length = 0;
    }
    let acc = 0;
    function tickReplay(dt) {
      if (!rep) return;
      const w = rep.w, sp = L.debug.speed;
      if (rep.lt < rep.lead) { rep.lt += dt * sp; dirty = true; return; }
      if (!w.done) {
        acc += dt * sp;
        let n = 0;
        while (acc >= DT && !w.done && n < 400) { w.step(); acc -= DT; n++; }
        playSounds(w, towerX(rep.ti));
        if (w.done) finishSim();
      } else {
        rep.hold -= dt * sp;
        if (rep.hold <= 0) endReplay();
      }
      dirty = true;
    }
    function finishSim() {
      const w = rep.w, l = rep.last, now = performance.now(), ox = towerX(rep.ti);
      rep.hold = 0.9;
      let moved = 0;
      rep.before.forEach((p, i) => { const b = w.b[i]; if (p[2] < NB && !b.gone) moved = Math.max(moved, Math.abs(b.x - p[0]) + Math.abs(b.y - p[1])); });
      if (l.lose) {
        flash = { text: '와르르!', c: '#ee6a55', t0: now, sub: st.n > 1 ? nameOf(l.s) + ' 님이 떨어뜨렸어요' : '' };
        shake = { t0: now, amp: 6 }; api.sfx('lose'); api.buzz(60); rep.hold = 1.8;
      } else if (l.f) {
        flash = { text: '떨어졌어요', c: '#ee9a55', t0: now, sub: '블록 ' + l.f + '개가 사라져요' }; shake = { t0: now, amp: 3 }; api.sfx('pop'); rep.hold = 1.2;
      } else if (l.cap) { flash = { text: CAP + '개 완성!', c: '#e3ae45', t0: now }; api.sfx('win'); rep.hold = 1.6; }
      else {
        const wob = moved > 0.35, nb = w.nb;
        const txt = wob ? '휘청…' : st.md === 'duel' ? '좋아요!' : '높이 ' + w.height().toFixed(1);
        pops.push({ x: nb.x + ox, y: nb.bb[3] + 0.8, text: txt, c: wob ? '#ee9a55' : '#f2e9d8', t0: now });
        api.sfx(wob ? 'tick' : 'chip'); api.buzz(wob ? 25 : 8);
      }
      if (st && st.md === 'coop' && st.ph === 'e' && st.hi[0] >= st.tg) { flash = { text: '목표 달성!', c: '#5fd3a0', t0: now }; rep.hold = 1.6; }
    }
    function endReplay() {
      const r = rep; rep = null; acc = 0;
      if (st && (st.ph === 'e' || (st.md === 'duel' && r.last.lose))) {
        if (st.ph === 'e') frozen = { ti: r.ti, m: r.m, b: r.w.b };
        else {
          const M = MAPS[st.mp];
          flash = { text: '라운드 ' + st.rd, c: '#e3ae45', t0: performance.now(), d: 2200, sub: M.nm + ' · ' + nameOf(st.c) + ' 님부터' };
        }
      }
      syncTowers();
      api.setBusy(false);
      renderHud(true); dirty = true;
    }
    function introFlash(s) { const M = MAPS[s.mp]; flash = { text: M.nm, c: '#e3ae45', t0: performance.now(), d: 2600, sub: s.md === 'coop' ? '목표 높이 ' + s.tg + ' · 블록 ' + s.nb + '개 안에' : M.hint }; }
    function syncTowers() { if (st) towers = st.tw.map((t) => decT(t)); hInfo = null; }

    const stop = U.loop((dt, now) => {
      if (!alive) return;
      tickReplay(dt);
      if (V) {
        camTarget();
        if (Math.abs(cam.tx - cam.x) > 8) { cam.x = cam.tx; dirty = true; }
        const k = Math.min(1, dt * 4); cam.x += (cam.tx - cam.x) * k; cam.y += (cam.ty - cam.y) * k;
        if (Math.abs(cam.tx - cam.x) + Math.abs(cam.ty - cam.y) > 0.01) dirty = true; else { cam.x = cam.tx; cam.y = cam.ty; }
      }
      if (myTurn() && held) {
        const hp = heldInfo();
        if (hp) {
          if (!disp.ok) { disp.x = hp.x; disp.y = hp.hy; disp.a = hp.a; disp.ok = true; }
          const k = 1 - Math.exp(-dt * 22);
          disp.x += (hp.x - disp.x) * k; disp.y += (hp.hy - disp.y) * (1 - Math.exp(-dt * 12));
          let da = hp.a - disp.a; da -= TAU * Math.round(da / TAU); disp.a += da * k;
        }
      }
      for (let i = fx.length - 1; i >= 0; i--) { const p = fx[i]; p.life -= dt; if (p.life <= 0) { fx.splice(i, 1); continue; } p.x += p.vx * dt; p.y += p.vy * dt; p.vy -= 2.5 * dt; }
      for (let i = pops.length - 1; i >= 0; i--) if (now - pops[i].t0 > 1100) pops.splice(i, 1);
      if (sentAt && performance.now() - sentAt > 6000) { sentAt = 0; renderHud(true); }
      if (myTurn() || flash || dirty || fx.length || pops.length || shake) { dirty = false; drawScene(now); }
    });
    cv.onresize = () => { dirty = true; };
    cv.cv._dbg = () => ({ held, my: myTurn(), s: V ? V.s : 0, rep: !!rep, hp: heldInfo() });

    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        const l = next.last;
        if (!prev) {
          syncTowers();
          if (next.ph === 'e' && l) { const w = dropSim(l.pre, l.b, l.x, l.a, l.m).run(); frozen = { ti: l.ti, m: l.m, b: w.b }; }
          setView(); camTarget(); cam.x = cam.tx; cam.y = cam.ty;
          if (next.seq === 0) introFlash(next);
        } else if (prev !== next && l && (!prev.last || prev.last.id !== l.id)) {
          startReplay(l);
        } else if (!rep) {
          syncTowers();
          if (next.seq === 0 && (prev.seq !== 0 || prev.sd !== next.sd)) { frozen = null; introFlash(next); }
        }
        if (!rep && next.ph !== 'e' && (!held || held.turn !== next.seq + ':' + next.c)) held = null;
        renderHud(true); dirty = true;
      },
      destroy() { alive = false; stop(); stopHold(); window.removeEventListener('keydown', onKey); cv.destroy(); topEl.remove(); bot.remove(); api.setBusy(false); },
    };
  }

  L.register({
    id: 'stack', name: '탑 쌓기', tag: '물리 쌓기', cat: '파티',
    blurb: '모양이 제각각인 나무 블록을 번갈아 떨어뜨려 쌓아요. 받침대 모양이 다른 맵 9곳! 내가 놓은 블록 때문에 받침대에서 떨어지면 라운드를 져요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 1100,
    tint: '#6b4a1e',
    icon: '<rect x="14" y="44" width="28" height="6" rx="1" fill="currentColor" opacity=".55"/><rect x="16" y="35" width="24" height="8" rx="1.5" fill="currentColor"/><path d="M20 34 L28 22 L36 34 Z" fill="currentColor"/><circle cx="28" cy="15" r="5" fill="currentColor"/><path d="M42 12 l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5-3.6-3.5 5-.7z" fill="currentColor" transform="rotate(14 42 18)"/>',
    options: [
      { id: 'mode', label: '방식', choices: [{ v: 'duel', label: '대결' }, { v: 'height', label: '높이 경쟁' }, { v: 'coop', label: '협동' }], def: 'duel' },
      { id: 'len', label: '길이', choices: [{ v: 's', label: '짧게' }, { v: 'l', label: '길게' }], def: 's' },
      { id: 'map', label: '맵', choices: [{ v: 'rand', label: '무작위' }].concat(MAPS.map((m) => ({ v: m.id, label: m.nm }))), def: 'rand' },
    ],
    quick: [
      '모양이 제각각인 블록을 받침대 위에 번갈아 떨어뜨려 쌓아요.',
      '내 차례: 위에 뜬 블록을 끌어 옮기고 ⟲ ⟳로 돌린 뒤 「떨어뜨리기」.',
      '대결: 내 블록 때문에 받침대에서 무엇이든 떨어지면 그 라운드는 내가 져요. 점수 1등이 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '직사각형 · 삼각형 · 아치 · 원기둥 · L자 · 별 모양 나무 블록을 받침대 위에 쌓아요.',
        '기본 방식은 「대결」이에요. 모두 한 탑에 번갈아 쌓고, 탑을 무너뜨리지 않는 게 목표예요.',
        '옵션으로 「높이 경쟁」 「협동」도 있어요(아래 「방식」).'] },
      { h: '준비', p: [
        '맵(받침대)이 정해지고 첫 블록이 화면 위에 떠 있어요. 블록 순서는 정해져 있어요.',
        '오른쪽 위 「다음」 칸에 그다음 블록이 미리 보여요.'] },
      { h: '차례에 할 일', p: [
        '① 옮기기: 위에 떠 있는 블록을 좌우로 끌거나, 놓고 싶은 곳을 탭해요. 손을 떼도 아직 안 떨어져요.',
        '② 돌리기: ⟲ ⟳ 버튼(15°씩, 꾹 누르면 계속) 또는 두 손가락으로 비틀어요.',
        '③ 확인: 점선 그림자 = 블록이 처음 닿을 자리, 노란 점 = 무게중심이에요.',
        '④ 「떨어뜨리기」를 눌러요. 받침대 밖이면 빨갛게 알려 주고, 한 번 더 눌러야 떨어져요.',
        '⑤ 탑이 완전히 멈추면 다음 사람 차례예요.'] },
      { h: '점수·승리 (대결)', p: [
        '내가 놓은 블록 때문에 어떤 블록이든 받침대 아래로 떨어지면 그 라운드는 내가 져요. 나머지 사람이 1점씩 받아요.',
        '짧게 3라운드 · 길게 5라운드. 점수가 가장 높은 사람이 이겨요(같으면 공동 승리).',
        '무너뜨린 사람이 다음 라운드를 먼저 시작해요. 한 탑에 블록이 40개 쌓이면 진 사람 없이 라운드가 끝나요.',
        '혼자 하면 무너지기 전까지 몇 개를 쌓는지 도전해요.'] },
      { h: '방식 (옵션)', p: [
        '높이 경쟁: 각자 자기 받침대에 같은 순서의 블록을 쌓아요(짧게 8개 · 길게 12개). 다 쌓았을 때 가장 높은 탑이 이겨요. 떨어진 블록은 그냥 사라져요.',
        '협동: 모두 한 탑을 함께 쌓아, 정해진 블록 수 안에 목표 높이를 넘기면 모두 승리! (짧게: 블록 15개로 높이 24 · 길게: 블록 22개로 높이 28) 점선이 목표 높이예요.',
        '높이는 받침대의 0 눈금부터 재요.'] },
      { h: '맵', p: [
        '나무 받침대(넓고 평평) · 외기둥(좁은 돌기둥) · 쌍둥이 기둥(가운데 틈) · 시상대(가운데만 높음) · 오목 그릇(가운데로 모이는 비탈) · 비탈 언덕(기운 받침대, 끝에 턱) · 시소(한쪽에 몰리면 기울어요) · 공중 발판(양옆에 매달린 발판) · 얼음판(아주 미끄러움).',
        '「무작위」(기본)면 대결은 라운드마다 맵이 바뀌어요. 높이 경쟁은 모두 같은 맵에서 쌓아요.',
        '받침대(시소 판·발판 포함) 아래로 떨어진 블록은 「떨어진 블록」이에요.'] },
      { h: '블록 특징', p: [
        '모양마다 무게중심과 닿는 면이 달라요.',
        '원기둥은 굴러가요. 별과 삼각형은 뾰족해서 미끄러지기 쉬워요. 넓고 평평한 면을 아래로 놓으면 안정적이에요.'] },
      { h: '조작', p: [
        '끌기 / 탭 → 옮기기. ⟲ ⟳ 또는 두 손가락 비틀기 → 돌리기. 「떨어뜨리기」 → 놓기.',
        '키보드: ← → 이동, Q/E 돌리기, 스페이스 떨어뜨리기.',
        '버튼 위 안내 줄에 지금 블록 이름과 각도가 보여요.'] },
      { h: '예시', p: [
        '탑 맨 위가 평평한 직사각형이에요. 내 블록은 삼각형.',
        '→ 삼각형을 평평한 면이 아래로 가게 돌리고(⟲), 그림자가 직사각형 한가운데 오게 옮겨요. 노란 점(무게중심)도 가운데!',
        '→ 「떨어뜨리기」. 탑이 멈추고 아무것도 안 떨어졌으면 성공, 다음 사람 차례예요.',
        '만약 원기둥을 비탈에 놓았다가 굴러떨어지면 → 내가 이번 라운드를 져요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 많은 자리를 실제로 떨어뜨려 보고 가장 안정적인 곳을 정확히 골라요.'] },
    ],
    tutorial: [
      { text: '모양이 제각각인 블록을 번갈아 떨어뜨려 쌓아요. 대결에서는 내 블록 때문에 무엇이든 받침대에서 떨어지면 그 라운드는 내가 져요!' },
      { sel: '.sk-info', text: '여기에 라운드 · 쌓인 블록 수 · 맵 이름과 점수가 보여요. 오른쪽 위 「다음」 칸은 그다음 블록이에요.' },
      { text: '위에 떠 있는 블록을 좌우로 끌거나, 놓고 싶은 곳을 탭해서 옮겨요. 손을 떼도 아직 안 떨어져요.' },
      { sel: '.sk-rot', text: '⟲ ⟳ 버튼으로 15°씩 돌려요(꾹 누르면 계속). 두 손가락으로 비틀어도 돼요.' },
      { text: '점선 그림자가 블록이 처음 닿을 자리, 노란 점이 무게중심이에요. 무게중심이 아래 블록 위에 오게 놓으면 안정적이에요.' },
      { sel: '.sk-drop', text: '자리를 정했으면 「떨어뜨리기」! 받침대 밖이면 빨갛게 알려 주고 한 번 더 눌러야 떨어져요. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _sim: { World, Body, SHAPES, MAPS, dropSim, encT, decT, mapTw, mapStatics, landInfo, blockAt, collide, evalDrop, dsin, DT, NB },
  });
})();
