/* 해저 잠수정 탐사 — 공용 산소를 나눠 쓰는 욕심 잠수 보드게임 (3판).
   모두 같은 잠수정에서 출발해 깊이 칸 길을 따라 내려가요. 주사위 1개(1~6) − 짐 무게÷2 만큼 움직이고,
   차례 시작마다 공용 산소가 「들고 있는 보물 무게 (+깊은 곳 수압 1)」만큼 줄어요. 산소가 바닥나면 판 끝:
   잠수정에서 3칸 안이면 구조 로프로 가장 값진 보물 1개만 건지고, 더 멀면 들고 있던 보물을 모두 잃어요.
   독자 요소: 물살(2칸 더 밀어 줌)·해파리(산소 −2)·공기 방울(산소 +3) 칸, 보물 3종(진주·금화·유물) 세트 보너스,
   빈 자리에 보물 내려놓기(가벼워지기), 판마다 빈 자리 절반이 새 보물로 채워짐, 뒤처진 사람이 다음 판 먼저. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------------- 데이터 ---------------- */
  const A64 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_';
  const TY = [
    { n: '진주', c: '#eef2f6', k: '#9fb3c4', e: '⚪' },
    { n: '금화', c: '#f2c14e', k: '#a8751c', e: '🟡' },
    { n: '유물', c: '#d8794c', k: '#7e3a1c', e: '🏺' },
  ];
  const tcode = (t, v) => A64[t * 16 + v];
  const tval = (ch) => A64.indexOf(ch) & 15;
  const ttype = (ch) => A64.indexOf(ch) >> 4;
  const twt = (ch) => (tval(ch) >= 6 ? 2 : 1);
  const ZV = [null, [1, 3], [3, 5], [6, 8], [9, 12]];
  const ZN = ['잠수정', '얕은 바다', '산호 숲', '어스름 해구', '깊은 심해'];
  const SEAS = {
    reef: { n: '산호초', N: 26, c: 3, j: 2, a: 3 },
    trench: { n: '깊은 해구', N: 32, c: 5, j: 3, a: 2 },
    jelly: { n: '해파리 숲', N: 28, c: 2, j: 6, a: 3 },
    calm: { n: '잔잔한 바다', N: 28, c: 2, j: 1, a: 2 },
  };
  const SEAK = ['reef', 'trench', 'jelly', 'calm'];
  const MAXC = 4, SETB = 5, ROPE = 3, ROUNDS = 3, PUSH = 2, JELLY = 2, AIR = 3;
  const STARS = [18, 28, 38];
  const o2Max = (n) => (n === 1 ? 15 : 12 + 5 * n);

  const zoneOf = (s, i) => (i <= 0 ? 0 : 1 + Math.floor(((i - 1) * 4) / s.N));
  const wt = (c) => { let w = 0; for (const ch of c) w += twt(ch); return w; };
  const val = (c) => { let v = 0; for (const ch of c) v += tval(ch); return v; };
  const slowOf = (c) => Math.floor(wt(c) / 2);
  const costAt = (s, c, pos) => wt(c) + (zoneOf(s, pos) >= 3 ? 1 : 0);
  const costOf = (s, q) => costAt(s, s.c[q], s.p[q]);
  const inWater = (s, q) => s.d[q] <= 1;
  function setsOf(str) { const k = [0, 0, 0]; for (const ch of str) k[ttype(ch)]++; return Math.min(k[0], k[1], k[2]); }
  function scoreOf(s, i) { const v = val(s.b[i]), st = setsOf(s.b[i]); return { v, st, tot: v + st * SETB }; }
  function genT(z) { const r = ZV[z]; return tcode(Math.floor(Math.random() * 3), r[0] + Math.floor(Math.random() * (r[1] - r[0] + 1))); }
  const rep = (str, i, ch) => str.slice(0, i) + ch + str.slice(i + 1);

  /* ---------------- 초기화 ---------------- */
  function init(players, opts) {
    const n = players.length;
    let sea = (opts && opts.sea) || 'rand';
    if (!SEAS[sea]) sea = SEAK[Math.floor(Math.random() * SEAK.length)];
    const S = SEAS[sea], N = S.N;
    const kinds = Array(N + 1).fill('t'); kinds[0] = 'S';
    const cand = []; for (let i = 3; i < N; i++) cand.push(i);
    U.shuffle(cand);
    let k = 0;
    const put = (ch, cnt) => { for (let q = 0; q < cnt && k < cand.length; q++) kinds[cand[k++]] = ch; };
    put('c', S.c); put('j', S.j); put('a', S.a);
    const s = {
      n, N, sea, tl: kinds.join(''), tr: '.',
      nm: players.map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 8)),
      p: Array(n).fill(0), d: Array(n).fill(0), c: Array(n).fill(''), b: Array(n).fill(''), rg: Array(n).fill(0),
      O: o2Max(n), o2: o2Max(n), r: 0, cur: 0, ph: 'r', sq: 0, last: { id: 0 },
    };
    let tr = '.';
    for (let i = 1; i <= N; i++) {
      if (kinds[i] !== 't') tr += '.';
      else if (i === N) tr += tcode(Math.floor(Math.random() * 3), 11 + Math.floor(Math.random() * 2));
      else tr += Math.random() < 0.86 ? genT(zoneOf(s, i)) : '.';
    }
    s.tr = tr;
    return s;
  }

  function actor(s) { return s.ph === 'x' ? null : s.cur; }

  /* 판 끝: 남은 잠수부 정리 */
  function endRound(s, out) {
    const end = [];
    for (let i = 0; i < s.n; i++) {
      if (s.d[i] === 2) { end.push([0, s.rg[i], 0]); continue; }
      const c = s.c[i];
      if (s.d[i] <= 1 && s.p[i] <= ROPE && c.length) {
        let best = 0; for (let j = 1; j < c.length; j++) if (tval(c[j]) > tval(c[best])) best = j;
        s.b[i] += c[best]; s.rg[i] += tval(c[best]);
        end.push([1, s.rg[i], val(c) - tval(c[best])]);
      } else if (s.d[i] <= 1 && s.p[i] <= ROPE) end.push([1, s.rg[i], 0]);
      else end.push([2, s.rg[i], val(c)]);
      s.c[i] = '';
    }
    s.r++;
    if (s.r >= ROUNDS) { s.ph = 'x'; s.d = s.d.map((v) => (v === 2 ? 2 : v <= 1 ? 3 : v)); return { e: end, o: out ? 1 : 0 }; }
    // 다음 판 준비
    let tr = s.tr, tl = s.tl;
    for (let i = 1; i <= s.N; i++) {
      if (tl[i] === 'A') tl = rep(tl, i, 'a');
      if (tl[i] === 't' && tr[i] === '.' && Math.random() < 0.5) tr = rep(tr, i, genT(zoneOf(s, i)));
    }
    s.tr = tr; s.tl = tl;
    s.p = Array(s.n).fill(0); s.d = Array(s.n).fill(0); s.c = Array(s.n).fill(''); s.rg = Array(s.n).fill(0);
    s.o2 = s.O; s.ph = 'r';
    // 점수가 가장 낮은 사람이 먼저 (같으면 앞 자리)
    let lo = 0;
    for (let i = 1; i < s.n; i++) if (scoreOf(s, i).tot < scoreOf(s, lo).tot) lo = i;
    s.cur = lo;
    return { e: end, o: out ? 1 : 0 };
  }

  /* 차례 넘기기: 다음 잠수부의 차례 시작에 산소를 써요 */
  function endTurn(s) {
    const r0 = s.r;
    let nx = -1;
    for (let j = 1; j <= s.n; j++) { const q = (s.cur + j) % s.n; if (inWater(s, q)) { nx = q; break; } }
    if (nx < 0) return { end: endRound(s, false), dr: null, r0 };
    if (s.o2 <= 0) return { end: endRound(s, true), dr: null, r0 };
    const cost = costOf(s, nx);
    s.o2 = Math.max(0, s.o2 - cost);
    s.cur = nx; s.ph = 'r';
    return { end: null, dr: cost ? [nx, cost] : null, r0 };
  }
  function canTake(s, i) { const pos = s.p[i]; return pos > 0 && s.tl[pos] === 't' && s.tr[pos] !== '.' && s.c[i].length < MAXC; }
  function canDrop(s, i) { const pos = s.p[i]; return pos > 0 && s.tl[pos] === 't' && s.tr[pos] === '.' && s.c[i].length > 0; }

  function finish(s, L0) {
    const t = endTurn(s);
    s.sq++;
    L0.id = s.sq;
    if (t.dr) L0.dr = t.dr;
    if (t.end) { L0.end = t.end.e; L0.out = t.end.o; L0.r = t.r0; }
    s.last = L0;
    return s;
  }

  function apply(s, seat, a) {
    if (s.ph === 'x') throw new Error('game over');
    if (seat !== s.cur) throw new Error('not your turn');
    if (!a) throw new Error('no action');
    if (s.ph === 'r') {
      const g = a.g;
      if (g === 'u') { if (s.d[seat] !== 0 || s.p[seat] <= 0) throw new Error('bad'); s.d[seat] = 1; }
      else if (g === 'd') { if (s.d[seat] !== 0 || s.p[seat] >= s.N) throw new Error('bad'); }
      else if (g === 'r') { if (s.d[seat] !== 1) throw new Error('bad'); }
      else throw new Error('bad');
      const die = 1 + Math.floor(Math.random() * 6);
      const slow = slowOf(s.c[seat]);
      const m = Math.max(0, die - slow);
      const dir = s.d[seat] === 0 ? 1 : -1;
      const path = [s.p[seat]];
      const ev = [];
      let pos = s.p[seat];
      for (let k = 0; k < m; k++) { const np = pos + dir; if (np < 0 || np > s.N) break; pos = np; path.push(pos); }
      if (m === 0 && slow > 0) ev.push('z');
      if (m > 0 && pos > 0 && s.tl[pos] === 'c') {
        ev.push('c');
        for (let k = 0; k < PUSH; k++) { const np = pos + dir; if (np < 0 || np > s.N) break; pos = np; path.push(pos); }
      }
      s.p[seat] = pos;
      if (m > 0 && pos > 0) {
        if (s.tl[pos] === 'j') { ev.push('j'); s.o2 = Math.max(0, s.o2 - JELLY); }
        else if (s.tl[pos] === 'a') { ev.push('a'); s.o2 = Math.min(s.O, s.o2 + AIR); s.tl = rep(s.tl, pos, 'A'); }
      }
      if (s.d[seat] === 0 && pos >= s.N) { s.d[seat] = 1; ev.push('b'); }
      if (s.d[seat] === 1 && pos <= 0) {
        s.d[seat] = 2; s.b[seat] += s.c[seat]; s.rg[seat] += val(s.c[seat]); ev.push('h');
        ev.push(String(val(s.c[seat]))); s.c[seat] = '';
      }
      const L0 = { k: 'mv', s: seat, g, die, path, ev };
      if (s.d[seat] <= 1 && (canTake(s, seat) || canDrop(s, seat))) {
        s.ph = 'p'; s.sq++; L0.id = s.sq; s.last = L0;
        return s;
      }
      return finish(s, L0);
    }
    if (s.ph === 'p') {
      const pos = s.p[seat];
      const L0 = { s: seat, i: pos };
      if (a.k === 1) {
        if (!canTake(s, seat)) throw new Error('cannot take');
        L0.k = 'tk'; L0.ch = s.tr[pos];
        s.c[seat] += s.tr[pos]; s.tr = rep(s.tr, pos, '.');
      } else if (a.k === 2) {
        const j = a.i | 0;
        if (!canDrop(s, seat) || j < 0 || j >= s.c[seat].length) throw new Error('cannot drop');
        L0.k = 'dp'; L0.ch = s.c[seat][j];
        s.tr = rep(s.tr, pos, s.c[seat][j]); s.c[seat] = s.c[seat].slice(0, j) + s.c[seat].slice(j + 1);
      } else if (a.k === 0) L0.k = 'sk';
      else throw new Error('bad');
      return finish(s, L0);
    }
    throw new Error('bad phase');
  }

  function result(s) {
    if (s.ph !== 'x') return null;
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const sc = s.b.map((_, i) => scoreOf(s, i));
    const line = (i) => nm(i) + '  💰' + sc[i].tot + (sc[i].st ? ' (세트 +' + sc[i].st * SETB + ')' : '') + ' · 보물 ' + s.b[i].length + '개';
    if (s.n === 1) {
      const t = sc[0].tot, st = STARS.filter((v) => t >= v).length;
      return { winners: st ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요', text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + line(0) + '\n별 기준 ' + STARS.join(' / ') };
    }
    const top = Math.max(...sc.map((x) => x.tot));
    let win = sc.map((x, i) => (x.tot === top ? i : -1)).filter((i) => i >= 0);
    if (win.length > 1) { const bc = Math.max(...win.map((i) => s.b[i].length)); win = win.filter((i) => s.b[i].length === bc); }
    const order = sc.map((_, i) => i).sort((a, b) => sc[b].tot - sc[a].tot || a - b);
    return {
      winners: win, title: win.length > 1 ? '공동 우승' : nm(win[0]) + ' 우승!',
      text: order.map((i) => (sc.filter((x) => x.tot > sc[i].tot).length + 1) + '위  ' + line(i)).join('\n'),
    };
  }

  /* ---------------- 귀환 계산 (도우미·AI 공용) ---------------- */
  const MD = [];
  function moveDist(slow) {
    if (MD[slow]) return MD[slow];
    const p = Array(7).fill(0);
    for (let d = 1; d <= 6; d++) p[Math.max(0, d - slow)] += 1 / 6;
    return (MD[slow] = p);
  }
  const emove = (slow) => { const p = moveDist(slow); let e = 0; for (let m = 0; m < 7; m++) e += m * p[m]; return e; };
  function probReach(dist, turns, slow) {
    if (dist <= 0) return 1;
    if (turns <= 0) return 0;
    const md = moveDist(slow);
    let dp = new Float64Array(dist + 1); dp[0] = 1;
    for (let t = 0; t < turns; t++) {
      const nd = new Float64Array(dist + 1);
      nd[dist] = dp[dist];
      for (let x = 0; x < dist; x++) { const v = dp[x]; if (!v) continue; for (let m = 0; m < 7; m++) if (md[m]) nd[Math.min(dist, x + m)] += v * md[m]; }
      dp = nd;
    }
    return dp[dist];
  }
  /* 지금 차례 다음부터 내가 받을 차례 수 (산소가 버티는 동안). 다른 잠수부 소모는 지금 그대로라고 봐요. */
  function futureTurns(s, seat, myCost, o2) {
    let o = o2 == null ? s.o2 : o2, k = 0;
    const others = [];
    for (let j = 1; j < s.n; j++) { const q = (seat + j) % s.n; if (inWater(s, q)) others.push(costOf(s, q)); }
    for (let it = 0; it < 60; it++) {
      for (const c of others) { if (o <= 0) return k; o = Math.max(0, o - c); }
      if (o <= 0) return k;
      o = Math.max(0, o - myCost); k++;
    }
    return k;
  }
  /* 화면 도우미: 지금 돌아가기 시작하면? */
  function helpInfo(s, i) {
    const pos = s.p[i], c = s.c[i], slow = slowOf(c), cost = costAt(s, c, pos);
    const mine = s.cur === i && s.ph === 'r';
    const turns = futureTurns(s, i, cost) + (mine ? 1 : 0);
    const e = emove(slow);
    return { dist: pos, slow, e, need: e > 0 ? Math.ceil(pos / e) : 99, turns, prob: probReach(pos, turns, slow), cost };
  }
  function cycleCost(s) { let c = 0; for (let q = 0; q < s.n; q++) if (inWater(s, q)) c += costOf(s, q); return c; }

  /* ---------------- AI ---------------- */
  function worth(s, i, ch, base) {
    // 보물 ch의 값어치 (세트 보너스 증가분 포함)
    const own = s.b[i] + base;
    return tval(ch) + (setsOf(own + ch) - setsOf(own)) * SETB;
  }
  function stateEV(s, i, carry, pos, turns) {
    const slow = slowOf(carry);
    const P = probReach(pos, turns, slow);
    let V = 0; for (let j = 0; j < carry.length; j++) V += worth(s, i, carry[j], carry.slice(0, j));
    if (!carry.length) return 0;
    let mx = 0; for (const ch of carry) mx = Math.max(mx, tval(ch));
    const Pr = pos > ROPE ? probReach(pos - ROPE, turns, slow) : 1;
    return P * V + Math.max(0, Pr - P) * mx;
  }
  function aiR(s, seat, lv) {
    const pos = s.p[seat], c = s.c[seat];
    if (s.d[seat] === 1) return { g: 'r' };
    if (pos <= 0) return { g: 'd' };
    if (pos >= s.N) return { g: 'u' };
    const slow = slowOf(c), cost = costAt(s, c, pos), K = futureTurns(s, seat, cost);
    if (lv === 1) {
      if (c.length >= 3 + (s.r & 1)) return { g: 'u' };
      if (c.length && s.o2 < s.O * 0.3) return { g: 'u' };
      if (c.length && Math.random() < 0.08) return { g: 'u' };
      return { g: 'd' };
    }
    if (lv === 2) {
      if (!c.length) return { g: 'd' };
      const need = pos / Math.max(0.5, emove(slow));
      if (K + 1 < need * 1.35 + 1) return { g: 'u' };
      if (c.length >= 3) return { g: 'u' };
      if (val(c) >= 16 && zoneOf(s, pos) >= 3) return { g: 'u' };
      return { g: 'd' };
    }
    // lv3: 지금 돌아가기 vs 한 번 더 내려가 보기 (기댓값)
    const up = stateEV(s, seat, c, pos, K + 1);
    let dn = 0;
    const md = moveDist(slow);
    for (let m = 0; m < 7; m++) {
      if (!md[m]) continue;
      let np = Math.min(s.N, pos + m);
      if (m > 0 && s.tl[np] === 'c') np = Math.min(s.N, np + PUSH);
      let o2 = s.o2;
      if (m > 0 && s.tl[np] === 'j') o2 = Math.max(0, o2 - JELLY);
      if (m > 0 && s.tl[np] === 'a') o2 = Math.min(s.O, o2 + AIR);
      let best = stateEV(s, seat, c, np, futureTurns(s, seat, costAt(s, c, np), o2));
      if (np > 0 && s.tl[np] === 't' && s.tr[np] !== '.' && c.length < MAXC) {
        const c2 = c + s.tr[np];
        best = Math.max(best, stateEV(s, seat, c2, np, futureTurns(s, seat, costAt(s, c2, np), o2)));
      }
      dn += md[m] * best;
    }
    // 앞서가는 사람이 있으면 마지막 판엔 조금 더 대담하게
    let bold = 1;
    if (s.n > 1 && s.r === ROUNDS - 1) {
      const me = scoreOf(s, seat).tot + val(c), lead = Math.max(...s.b.map((_, q) => (q === seat ? -1 : scoreOf(s, q).tot)));
      if (lead > me) bold = 1.12;
    }
    return { g: dn * bold > up + 0.05 ? 'd' : 'u' };
  }
  function aiP(s, seat, lv) {
    const pos = s.p[seat], c = s.c[seat];
    const take = canTake(s, seat), drop = canDrop(s, seat);
    if (lv === 1) {
      if (take) return { k: Math.random() < 0.85 ? 1 : 0 };
      return { k: 0 };
    }
    if (lv === 2) {
      if (take) {
        const c2 = c + s.tr[pos], slow2 = slowOf(c2);
        const K = futureTurns(s, seat, costAt(s, c2, pos));
        const need = pos / Math.max(0.5, emove(slow2));
        if (s.d[seat] === 0) return { k: K >= need * 1.25 + 1 || c.length === 0 ? 1 : 0 };
        return { k: K >= need * 1.15 + 0.5 ? 1 : 0 };
      }
      if (drop && s.d[seat] === 1) {
        const K = futureTurns(s, seat, costAt(s, c, pos)), need = pos / Math.max(0.5, emove(slowOf(c)));
        if (K < need) { let j = 0; for (let q = 1; q < c.length; q++) if (twt(c[q]) * 10 - tval(c[q]) > twt(c[j]) * 10 - tval(c[j])) j = q; return { k: 2, i: j }; }
      }
      return { k: 0 };
    }
    // lv3: 기댓값으로 줍기·내려놓기 비교
    const K0 = futureTurns(s, seat, costAt(s, c, pos));
    let best = { k: 0 }, bv = stateEV(s, seat, c, pos, K0);
    if (take) {
      const c2 = c + s.tr[pos];
      const v = stateEV(s, seat, c2, pos, futureTurns(s, seat, costAt(s, c2, pos)));
      // 내려가는 중이면 앞으로 더 주울 기회도 조금 쳐 줘요
      if (v + (s.d[seat] === 0 ? 0.3 : 0) > bv) { bv = v; best = { k: 1 }; }
    }
    if (drop) {
      for (let j = 0; j < c.length; j++) {
        const c2 = c.slice(0, j) + c.slice(j + 1);
        const v = stateEV(s, seat, c2, pos, futureTurns(s, seat, costAt(s, c2, pos)));
        if (v > bv + 0.2) { bv = v; best = { k: 2, i: j }; }
      }
    }
    return best;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'x' || seat !== s.cur) return null;
    return s.ph === 'r' ? aiR(s, seat, lv) : aiP(s, seat, lv);
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'x' || seat !== s.cur) return -1;
    if (s.ph === 'r' && (s.d[seat] === 1 || s.p[seat] === 0)) return 450;
    return [0, 900, 700, 600][lv || 2];
  }

  /* ---------------- 화면 ---------------- */
  const CSS = `
.sd{position:absolute;inset:0;display:flex;flex-direction:column;background:#0a1a2e;color:var(--ink);font-family:var(--f-body)}
.sd-strip{display:grid;gap:4px;padding:5px 6px 3px;flex:none}
.sd-pc{border:1px solid rgba(255,255,255,.1);background:rgba(20,40,64,.88);border-radius:10px;padding:3px 6px;min-width:0;display:flex;flex-direction:column;gap:1px;min-height:44px;box-sizing:border-box;position:relative}
.sd-pc.on{border-color:var(--brass);box-shadow:0 0 0 1px var(--brass) inset}
.sd-pc.gone{opacity:.62}
.sd-pc .nm{display:flex;align-items:center;gap:4px;font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden}
.sd-pc .nm .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis}
.sd-pc .nm .sc{font-family:var(--f-mono);color:#ffe39a;flex:none}
.sd-pc .r2{display:flex;align-items:center;gap:3px;height:18px;overflow:hidden;font-size:11px;color:var(--muted);white-space:nowrap}
.sd-tc{flex:none;display:inline-flex;align-items:center;justify-content:center;min-width:17px;height:17px;border-radius:50%;font:700 10px var(--f-mono);color:#1b1408;box-sizing:border-box;border:1.5px solid rgba(0,0,0,.35)}
.sd-tank{flex:none;display:flex;align-items:center;gap:7px;padding:2px 8px 3px}
.sd-tank .lb{font-size:12px;font-weight:700;white-space:nowrap}
.sd-tank .bar{flex:1;height:14px;border-radius:7px;background:rgba(255,255,255,.1);overflow:hidden;position:relative;border:1px solid rgba(255,255,255,.15)}
.sd-tank .bar i{position:absolute;left:0;top:0;bottom:0;border-radius:7px;transition:width .35s,background .35s}
.sd-tank .bar b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;color:#fff;text-shadow:0 1px 2px #000}
.sd-tank .rd{font:700 12px var(--f-mono);white-space:nowrap;color:#cfe7f2}
.sd-cv{position:relative;flex:1;min-height:0}
.sd-help{flex:none;margin:3px 8px 0;padding:5px 9px;border-radius:10px;background:rgba(255,255,255,.07);font-size:12.5px;line-height:1.3;min-height:36px;box-sizing:border-box;display:flex;align-items:center;gap:8px}
.sd-help .tx{flex:1;min-width:0}
.sd-help .pc{flex:none;font:800 14px var(--f-mono);padding:3px 8px;border-radius:999px;background:rgba(0,0,0,.3)}
.sd-help b{color:#ffe39a}
.sd-bar{flex:none;display:flex;gap:8px;padding:6px 8px 9px;align-items:stretch;min-height:66px;box-sizing:border-box}
.sd-bar .btn{min-height:52px;font-size:15.5px;flex:1;padding:4px 6px;line-height:1.15;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px}
.sd-bar .btn small{display:block;font-size:11px;font-weight:400;opacity:.85}
.sd-bar .wide{flex:1.5}
.sd-wait{flex:1;display:flex;align-items:center;justify-content:center;text-align:center;font-size:13.5px;color:var(--muted)}
.sd-drop{flex:1;display:flex;flex-direction:column;gap:4px;min-width:0}
.sd-drop .q{font-size:12px;color:var(--muted)}
.sd-drop .row{display:flex;gap:6px}
.sd-drop .row .btn{min-height:48px;min-width:44px;flex:1;font-size:14px;padding:2px 4px}
.sd-sum{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(88%,330px);background:rgba(12,26,44,.99);border:1px solid rgba(227,174,69,.6);border-radius:14px;padding:10px 12px;z-index:4;box-shadow:0 10px 30px rgba(0,0,0,.6);display:none}
.sd-sum.show{display:block;animation:sdIn .3s}
@keyframes sdIn{from{opacity:0;transform:translate(-50%,-44%)}to{opacity:1;transform:translate(-50%,-50%)}}
.sd-sum h3{margin:0 0 2px;font-family:var(--f-display);font-weight:400;color:var(--brass);font-size:19px}
.sd-sum .sub{font-size:12px;color:var(--muted);margin-bottom:6px}
.sd-sum .rw{display:flex;align-items:center;gap:6px;font-size:13px;padding:3px 0;border-top:1px solid rgba(255,255,255,.07)}
.sd-sum .rw .n{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:700}
.sd-sum .rw .v{font-family:var(--f-mono);white-space:nowrap}
.sd-sum .tap{font-size:11px;color:var(--muted);text-align:center;margin-top:5px}
`;

  function chip(ch, sm) {
    const t = TY[ttype(ch)];
    return L.h('span', { class: 'sd-tc', style: { background: t.c, minWidth: sm ? '15px' : '17px', height: sm ? '15px' : '17px', fontSize: sm ? '9px' : '10px' }, text: String(tval(ch)), title: t.n + ' ' + tval(ch) });
  }
  const pcol = (p) => (p >= 0.8 ? '#4fd6a0' : p >= 0.5 ? '#f2b84b' : '#ff6a4a');

  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'sd' });
    const strip = h('div', { class: 'sd-strip' });
    const tank = h('div', { class: 'sd-tank' });
    const cvw = h('div', { class: 'sd-cv' });
    const help = h('div', { class: 'sd-help' });
    const bar = h('div', { class: 'sd-bar' });
    const sum = h('div', { class: 'sd-sum' });
    cvw.append(sum);
    wrap.append(strip, tank, cvw, help, bar);
    root.append(style, wrap);
    const cv = U.canvas(cvw), ctx = cv.ctx;
    sum.style.zIndex = 4;

    let st = null, vs = null, dead = false, busy = false, sentKey = '', G = null, bg = null, bgKey = '';
    const timers = new Set();
    const tok = { seat: -1, x: 0, y: 0 };      // 움직이는 잠수부 (재생 중)
    const floats = [], parts = [], bubbles = [], glows = [];
    let dice = null, sumUntil = 0, flyT = null;
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms / sp()); timers.add(t); return t; };
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    for (let i = 0; i < 22; i++) bubbles.push({ x: Math.random(), y: Math.random(), r: 1 + Math.random() * 2.5, v: 0.02 + Math.random() * 0.05, w: Math.random() * 6 });
    for (let i = 0; i < 26; i++) glows.push({ x: Math.random(), y: 0.55 + Math.random() * 0.45, ph: Math.random() * 6, c: Math.random() < 0.5 ? '#7ff3ff' : '#c08bff' });

    /* ---------- 배치 ---------- */
    function layout() {
      const W = cv.w, H = cv.h, s = vs || st;
      if (!s) return;
      const N = s.N, K = W >= 390 ? 7 : 6, rows = Math.ceil(N / K);
      const top = Math.max(54, Math.min(74, H * 0.15)), bot = 16;
      const padX = 10, colW = (W - padX * 2 - 26) / K;
      const rowGap = (H - top - bot) / rows;
      const r = Math.max(11, Math.min(21, Math.min(colW, rowGap) * 0.36));
      const pts = [[padX + 26 + colW * 0.5 - colW * 0.15, top * 0.5]];
      for (let i = 1; i <= N; i++) {
        const row = Math.floor((i - 1) / K); let cl = (i - 1) % K; if (row & 1) cl = K - 1 - cl;
        pts.push([padX + 26 + colW * (cl + 0.5), top + rowGap * (row + 0.5)]);
      }
      G = { W, H, N, K, top, r, pts, colW, rowGap, padX };
      bgKey = '';
    }
    cv.onresize = () => { layout(); };

    function zoneY(s, z) {   // 깊이 구역 경계 y
      let a = 1e9, b = -1e9;
      for (let i = 1; i <= s.N; i++) if (zoneOf(s, i) === z) { a = Math.min(a, G.pts[i][1]); b = Math.max(b, G.pts[i][1]); }
      return [a, b];
    }
    function buildBg() {
      const s = vs || st;
      const key = G.W + 'x' + G.H + ':' + s.N + s.sea;
      if (bgKey === key && bg) return;
      bgKey = key;
      const dpr = cv.dpr || 1;
      bg = document.createElement('canvas');
      bg.width = Math.round(G.W * dpr); bg.height = Math.round(G.H * dpr);
      const b = bg.getContext('2d'); b.scale(dpr, dpr);
      const W = G.W, H = G.H;
      const gr = b.createLinearGradient(0, 0, 0, H);
      gr.addColorStop(0, '#6cc9dc'); gr.addColorStop(0.08, '#3a9bbd'); gr.addColorStop(0.3, '#1a6593');
      gr.addColorStop(0.55, '#0f3d68'); gr.addColorStop(0.78, '#0a2145'); gr.addColorStop(1, '#040915');
      b.fillStyle = gr; b.fillRect(0, 0, W, H);
      // 햇살
      b.save(); b.globalCompositeOperation = 'lighter';
      for (let k = 0; k < 5; k++) {
        const x = W * (0.12 + k * 0.2), w = 18 + k * 7 % 20;
        const lg = b.createLinearGradient(0, 0, 0, H * 0.6);
        lg.addColorStop(0, 'rgba(255,255,230,.16)'); lg.addColorStop(1, 'rgba(255,255,230,0)');
        b.fillStyle = lg; b.beginPath(); b.moveTo(x, 0); b.lineTo(x + w, 0); b.lineTo(x + w * 2.4 + 30, H * 0.6); b.lineTo(x + 30, H * 0.6); b.closePath(); b.fill();
      }
      b.restore();
      // 수면
      const sy = G.top * 0.5 + 10;
      b.fillStyle = 'rgba(200,240,255,.18)'; b.fillRect(0, 0, W, sy - 14);
      b.strokeStyle = 'rgba(230,250,255,.55)'; b.lineWidth = 2; b.beginPath();
      for (let x = 0; x <= W; x += 6) { const y = sy - 14 + Math.sin(x / 14) * 2.2; if (x) b.lineTo(x, y); else b.moveTo(x, y); }
      b.stroke();
      // 바닥 모래·바위·해초
      b.fillStyle = '#1a1712';
      b.beginPath(); b.moveTo(0, H);
      for (let x = 0; x <= W; x += 10) b.lineTo(x, H - 8 - Math.sin(x / 23) * 4 - Math.cos(x / 9) * 2);
      b.lineTo(W, H); b.closePath(); b.fill();
      const kelp = (x, h0, c) => {
        b.strokeStyle = c; b.lineWidth = 3; b.lineCap = 'round'; b.beginPath(); b.moveTo(x, H - 6);
        for (let y = 0; y < h0; y += 6) b.lineTo(x + Math.sin(y / 11 + x) * 5, H - 6 - y);
        b.stroke();
      };
      kelp(8, H * 0.28, 'rgba(40,110,80,.55)'); kelp(16, H * 0.18, 'rgba(30,90,70,.5)');
      kelp(W - 10, H * 0.22, 'rgba(40,110,80,.5)'); kelp(W - 18, H * 0.32, 'rgba(30,90,70,.45)');
      // 길(밧줄)
      b.strokeStyle = 'rgba(0,0,0,.35)'; b.lineWidth = 7; b.lineJoin = 'round'; b.lineCap = 'round';
      const pathLine = () => { b.beginPath(); b.moveTo(G.pts[0][0], G.pts[0][1] + 12); for (let i = 1; i <= s.N; i++) b.lineTo(G.pts[i][0], G.pts[i][1]); };
      pathLine(); b.stroke();
      b.strokeStyle = 'rgba(214,190,140,.55)'; b.lineWidth = 2.5; b.setLineDash([5, 4]); pathLine(); b.stroke(); b.setLineDash([]);
      // 구역 이름: 각 구역 첫 칸 위에 작은 표지
      b.font = '700 10px "IBM Plex Sans KR",sans-serif'; b.textBaseline = 'middle';
      for (let z = 2; z <= 4; z++) {
        let f = -1; for (let i = 1; i <= s.N; i++) if (zoneOf(s, i) === z) { f = i; break; }
        if (f < 0) continue;
        const [x, y] = G.pts[f], tx = ZN[z] + (z >= 3 ? ' · 수압 +1' : '');
        const w = b.measureText(tx).width + 10, lx = Math.max(2, Math.min(W - w - 2, x - w / 2)), ly = y + G.r + 8;
        b.fillStyle = z >= 3 ? 'rgba(40,20,70,.75)' : 'rgba(10,50,80,.7)';
        b.beginPath(); if (b.roundRect) b.roundRect(lx, ly - 7, w, 14, 7); else b.rect(lx, ly - 7, w, 14); b.fill();
        b.fillStyle = z >= 3 ? '#d6c2ff' : '#dff6ff'; b.textAlign = 'left'; b.fillText(tx, lx + 5, ly + 0.5);
      }
    }

    /* ---------- 그림 조각 ---------- */
    function drawTreasure(x, y, ch, r, a) {
      const t = ttype(ch), v = tval(ch);
      ctx.save(); ctx.translate(x, y); ctx.globalAlpha = a == null ? 1 : a;
      if (t === 0) {          // 진주: 조개 + 진주
        ctx.fillStyle = '#c99aa8'; ctx.beginPath(); ctx.ellipse(0, r * 0.25, r * 0.85, r * 0.45, 0, 0, Math.PI); ctx.fill();
        const g = ctx.createRadialGradient(-r * 0.2, -r * 0.2, 1, 0, 0, r * 0.55);
        g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#b9c8d6');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r * 0.48, 0, 7); ctx.fill();
      } else if (t === 1) {   // 금화 더미
        for (let k = 2; k >= 0; k--) {
          ctx.fillStyle = '#a8751c'; ctx.beginPath(); ctx.ellipse(0, r * 0.3 - k * r * 0.22, r * 0.62, r * 0.26, 0, 0, 7); ctx.fill();
          ctx.fillStyle = '#f2c14e'; ctx.beginPath(); ctx.ellipse(0, r * 0.24 - k * r * 0.22, r * 0.58, r * 0.22, 0, 0, 7); ctx.fill();
        }
      } else {                // 유물 항아리
        ctx.fillStyle = '#d8794c';
        ctx.beginPath(); ctx.moveTo(-r * 0.22, -r * 0.6); ctx.lineTo(r * 0.22, -r * 0.6); ctx.lineTo(r * 0.18, -r * 0.4);
        ctx.quadraticCurveTo(r * 0.75, -r * 0.1, r * 0.3, r * 0.6); ctx.lineTo(-r * 0.3, r * 0.6);
        ctx.quadraticCurveTo(-r * 0.75, -r * 0.1, -r * 0.18, -r * 0.4); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#7e3a1c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-r * 0.45, 0); ctx.lineTo(r * 0.45, 0); ctx.stroke();
      }
      ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(0,0,0,.75)'; ctx.lineWidth = 3;
      ctx.font = '800 ' + Math.round(r * 0.72) + 'px "IBM Plex Mono",monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.strokeText(String(v), r * 0.55, r * 0.55); ctx.fillText(String(v), r * 0.55, r * 0.55);
      ctx.restore();
    }
    function drawTile(s, i, now) {
      const [x, y] = G.pts[i], r = G.r, k = s.tl[i], z = zoneOf(s, i);
      const deep = z >= 3;
      // 타일 바탕 (깊을수록 은은한 빛 테두리)
      ctx.fillStyle = deep ? 'rgba(10,20,40,.78)' : 'rgba(10,40,70,.55)';
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = k === 'j' ? 'rgba(255,120,200,.8)' : k === 'c' ? 'rgba(110,230,255,.8)' : k === 'a' ? 'rgba(200,250,255,.85)' : deep ? 'rgba(120,200,255,' + (0.35 + 0.15 * Math.sin(now / 700 + i)) + ')' : 'rgba(220,240,255,.3)';
      ctx.stroke();
      if (k === 't') {
        if (s.tr[i] !== '.') drawTreasure(x, y, s.tr[i], r * 0.95);
        else { ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.arc(x, y, r * 0.5, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
      } else if (k === 'c') {
        ctx.strokeStyle = '#7fe8ff'; ctx.lineWidth = 2; const a0 = now / 500;
        for (let q = 0; q < 2; q++) { ctx.beginPath(); ctx.arc(x, y, r * (0.35 + q * 0.22), a0 + q * 2, a0 + q * 2 + 3.6); ctx.stroke(); }
        ctx.fillStyle = '#7fe8ff'; ctx.font = '700 ' + Math.round(r * 0.6) + 'px "IBM Plex Mono",monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('»', x, y + 1);
      } else if (k === 'j') {
        const bob = Math.sin(now / 400 + i) * 2;
        ctx.save(); ctx.shadowColor = '#ff7ad0'; ctx.shadowBlur = 10;
        ctx.fillStyle = 'rgba(255,140,215,.85)'; ctx.beginPath(); ctx.arc(x, y - 2 + bob, r * 0.48, Math.PI, 0); ctx.closePath(); ctx.fill();
        ctx.restore();
        ctx.strokeStyle = 'rgba(255,170,225,.8)'; ctx.lineWidth = 1.5;
        for (let q = -1; q <= 1; q++) { ctx.beginPath(); ctx.moveTo(x + q * r * 0.25, y - 1 + bob); ctx.quadraticCurveTo(x + q * r * 0.3 + Math.sin(now / 300 + q) * 3, y + r * 0.4, x + q * r * 0.2, y + r * 0.7 + bob); ctx.stroke(); }
      } else if (k === 'a' || k === 'A') {
        const used = k === 'A';
        ctx.globalAlpha = used ? 0.25 : 1;
        ctx.strokeStyle = '#dffaff'; ctx.lineWidth = 1.6; ctx.fillStyle = 'rgba(200,245,255,.25)';
        const bb = [[0, -0.1, 0.4], [-0.32, 0.28, 0.22], [0.34, 0.3, 0.18]];
        for (const [dx, dy, rr] of bb) { ctx.beginPath(); ctx.arc(x + dx * r, y + dy * r + (used ? 0 : Math.sin(now / 500 + dx * 9) * 1.5), rr * r, 0, 7); ctx.fill(); ctx.stroke(); }
        ctx.globalAlpha = 1;
      }
    }
    function drawSub(now, s) {
      const [x, y] = G.pts[0];
      const bob = Math.sin(now / 900) * 2;
      ctx.save(); ctx.translate(x, y + bob);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(2, 16, 34, 5, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#e8b33c'; ctx.beginPath(); ctx.ellipse(0, 4, 34, 13, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#c98f22'; ctx.fillRect(-10, -14, 20, 10);
      ctx.fillStyle = '#e8b33c'; ctx.beginPath(); ctx.ellipse(0, -14, 10, 3, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#8c6216'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(4, -14); ctx.lineTo(4, -21); ctx.lineTo(9, -21); ctx.stroke();
      // 창문: 돌아온 잠수부 얼굴
      const home = []; for (let i = 0; i < s.n; i++) if (s.d[i] === 2) home.push(i);
      for (let k = 0; k < 3; k++) {
        const wx = -18 + k * 14;
        ctx.fillStyle = '#20384f'; ctx.beginPath(); ctx.arc(wx, 4, 5, 0, 7); ctx.fill();
        ctx.strokeStyle = '#8c6216'; ctx.lineWidth = 1.5; ctx.stroke();
      }
      home.forEach((q, k) => { const wx = -24 + (k % 6) * 9.5, wy = -4 + (k >= 6 ? 6 : 0); ctx.fillStyle = col(q); ctx.beginPath(); ctx.arc(wx + 2, wy + 8, 3.2, 0, 7); ctx.fill(); });
      // 프로펠러
      const pa = now / 80;
      ctx.fillStyle = '#8c6216'; ctx.beginPath(); ctx.ellipse(-36, 4, 3, 8 * Math.abs(Math.sin(pa)), 0, 0, 7); ctx.fill();
      ctx.restore();
    }
    function drawDiver(x, y, c, on, carry, now, sc) {
      const r = G.r * 0.62 * (sc || 1);
      ctx.save(); ctx.translate(x, y);
      if (on) { ctx.strokeStyle = 'rgba(255,227,154,' + (0.55 + 0.4 * Math.sin(now / 200)) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, r + 5, 0, 7); ctx.stroke(); }
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(1.5, 2.5, r, 0, 7); ctx.fill();
      ctx.fillStyle = c; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill();
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.stroke();
      ctx.fillStyle = 'rgba(190,235,255,.9)'; ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.5, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.7)'; ctx.beginPath(); ctx.arc(-r * 0.18, -r * 0.28, r * 0.15, 0, 7); ctx.fill();
      if (carry) for (let k = 0; k < carry.length; k++) {
        ctx.fillStyle = TY[ttype(carry[k])].c; ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(-r + k * (r * 0.66), r + 3, 3.4, 0, 7); ctx.fill(); ctx.stroke();
      }
      ctx.restore();
    }
    function diverXY(s, q, posOverride) {
      const pos = posOverride != null ? posOverride : s.p[q];
      const [x, y] = G.pts[Math.max(0, Math.min(s.N, Math.round(pos)))];
      if (pos <= 0) return [x - 26 + q * 10, y + 28];
      const same = []; for (let j = 0; j < s.n; j++) if (s.d[j] <= 1 && s.p[j] === pos) same.push(j);
      const k = same.indexOf(q), m = same.length;
      if (m <= 1 || k < 0) return [x, y - G.r * 0.75];
      const a = -Math.PI / 2 + (k - (m - 1) / 2) * 0.8;
      return [x + Math.cos(a) * G.r * 0.95, y + Math.sin(a) * G.r * 0.95];
    }
    function drawDie(x, y, v, rot) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(rot || 0);
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.fillRect(-12, -10, 26, 26);
      ctx.fillStyle = '#f6efe1'; ctx.strokeStyle = '#3a2d1a'; ctx.lineWidth = 2;
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(-13, -13, 26, 26, 5); else ctx.rect(-13, -13, 26, 26); ctx.fill(); ctx.stroke();
      const P = { 1: [[0, 0]], 2: [[-6, -6], [6, 6]], 3: [[-6, -6], [0, 0], [6, 6]], 4: [[-6, -6], [6, -6], [-6, 6], [6, 6]], 5: [[-6, -6], [6, -6], [0, 0], [-6, 6], [6, 6]], 6: [[-6, -6], [6, -6], [-6, 0], [6, 0], [-6, 6], [6, 6]] }[v] || [];
      ctx.fillStyle = '#2a1d10'; for (const [a, b] of P) { ctx.beginPath(); ctx.arc(a, b, 2.6, 0, 7); ctx.fill(); }
      ctx.restore();
    }

    function drawScene(now) {
      const s = vs || st;
      if (!s || !G) return;
      if (G.N !== s.N) layout();
      buildBg();
      ctx.drawImage(bg, 0, 0, G.W, G.H);
      // 깊은 곳 발광 플랑크톤
      for (const g of glows) {
        const a = 0.25 + 0.35 * Math.sin(now / 900 + g.ph);
        if (a <= 0) continue;
        ctx.globalAlpha = a; ctx.fillStyle = g.c;
        ctx.beginPath(); ctx.arc(g.x * G.W + Math.sin(now / 3000 + g.ph) * 6, g.y * G.H, 1.6, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
      // 아귀 불빛
      const ax = G.W * 0.82 + Math.sin(now / 2200) * 18, ay = G.H - 26;
      ctx.save(); ctx.shadowColor = '#fff6a0'; ctx.shadowBlur = 14; ctx.fillStyle = '#fff6a0';
      ctx.beginPath(); ctx.arc(ax, ay - 12, 2.6 + Math.sin(now / 300), 0, 7); ctx.fill(); ctx.restore();
      ctx.strokeStyle = 'rgba(80,90,110,.6)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(ax, ay - 12); ctx.quadraticCurveTo(ax + 8, ay - 16, ax + 10, ay - 3); ctx.stroke();
      ctx.fillStyle = 'rgba(30,36,50,.85)'; ctx.beginPath(); ctx.ellipse(ax + 14, ay + 2, 12, 7, 0, 0, 7); ctx.fill();
      // 타일
      for (let i = 1; i <= s.N; i++) drawTile(s, i, now);
      // 거품
      ctx.strokeStyle = 'rgba(220,250,255,.45)'; ctx.lineWidth = 1;
      for (const b of bubbles) {
        b.y -= b.v * 0.016 * sp(); if (b.y < 0.05) { b.y = 1; b.x = Math.random(); }
        ctx.beginPath(); ctx.arc(b.x * G.W + Math.sin(now / 600 + b.w) * 3, b.y * G.H, b.r, 0, 7); ctx.stroke();
      }
      drawSub(now, s);
      // 잠수부
      const busyMove = tok.seat >= 0;
      for (let q = 0; q < s.n; q++) {
        if (s.d[q] >= 2) continue;
        if (busyMove && q === tok.seat) continue;
        const [x, y] = diverXY(s, q);
        drawDiver(x, y, col(q), !busy && s.ph !== 'x' && q === s.cur, s.c[q], now);
      }
      if (busyMove) drawDiver(tok.x, tok.y, col(tok.seat), true, s.c[tok.seat], now, 1.1);
      if (flyT) {
        const k = Math.min(1, (now - flyT.t0) / flyT.dur);
        const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        drawTreasure(flyT.x0 + (flyT.x1 - flyT.x0) * e, flyT.y0 + (flyT.y1 - flyT.y0) * e - Math.sin(Math.PI * e) * 22, flyT.ch, G.r * 0.9);
        if (k >= 1) flyT = null;
      }
      if (dice) {
        const k = (now - dice.t0) / (dice.dur);
        if (k > 1.6) dice = null;
        else drawDie(dice.x, dice.y, k < 0.5 ? 1 + Math.floor((now / 60) % 6) : dice.v, k < 0.5 ? Math.sin(now / 40) * 0.5 : 0);
      }
      // 반짝이·글자
      for (let j = parts.length - 1; j >= 0; j--) {
        const P = parts[j]; P.life -= 0.016 * sp(); if (P.life <= 0) { parts.splice(j, 1); continue; }
        P.x += P.vx; P.y += P.vy; P.vy += P.g;
        ctx.globalAlpha = Math.min(1, P.life * 2); ctx.fillStyle = P.c; ctx.beginPath(); ctx.arc(P.x, P.y, P.r, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let j = floats.length - 1; j >= 0; j--) {
        const T = floats[j], k = (now - T.t0) / (1300 / sp());
        if (k >= 1) { floats.splice(j, 1); continue; }
        if (k < 0) continue;
        ctx.globalAlpha = 1 - k * k; ctx.font = '800 14px "IBM Plex Sans KR",sans-serif';
        const x = Math.max(50, Math.min(G.W - 50, T.x));
        ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.lineWidth = 3.5; ctx.strokeText(T.s, x, T.y - k * 30);
        ctx.fillStyle = T.c; ctx.fillText(T.s, x, T.y - k * 30);
      }
      ctx.globalAlpha = 1;
      // 바다 이름
      ctx.textAlign = 'right'; ctx.textBaseline = 'top'; ctx.font = '700 11px "IBM Plex Sans KR",sans-serif';
      ctx.fillStyle = 'rgba(10,30,50,.75)'; ctx.fillText('🌊 ' + SEAS[s.sea].n, G.W - 8, 6);
    }
    const float = (x, y, t, c, delay) => floats.push({ x, y, s: t, c: c || '#fff', t0: performance.now() + (delay || 0) / sp() });
    function sparkle(x, y, c, n) { for (let k = 0; k < (n || 12); k++) { const a = Math.random() * 7, v = 1 + Math.random() * 2.2; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 1, g: 0.06, r: 1.5 + Math.random() * 2, c, life: 0.7 + Math.random() * 0.4 }); } }

    /* ---------- DOM ---------- */
    function renderStrip() {
      const s = vs || st;
      const cols = s.n <= 3 ? s.n : s.n === 4 ? 2 : 3;
      strip.style.gridTemplateColumns = 'repeat(' + cols + ',minmax(0,1fr))';
      strip.textContent = '';
      for (let i = 0; i < s.n; i++) {
        const sc = scoreOf(s, i);
        const ic = s.d[i] === 2 ? '🏠' : s.d[i] === 3 ? '💀' : s.p[i] === 0 ? '🚤' : s.d[i] === 1 ? '⬆' : '⬇';
        const r2 = h('div', { class: 'r2' });
        if (s.c[i].length) for (const ch of s.c[i]) r2.append(chip(ch, true));
        else r2.append(h('span', { text: s.d[i] === 2 ? '귀환 완료' : s.p[i] ? '빈손 · ' + s.p[i] + '칸' : '잠수정' }));
        if (s.c[i].length) r2.append(h('span', { text: ' ' + s.p[i] + '칸' }));
        strip.append(h('div', { class: 'sd-pc' + (!busy && s.ph !== 'x' && s.cur === i ? ' on' : '') + (s.d[i] >= 2 ? ' gone' : '') },
          h('div', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { class: 't', text: ic + ' ' + nm(i) }),
            h('span', { class: 'sc', text: '💰' + sc.tot })),
          r2));
      }
    }
    function renderTank() {
      const s = vs || st;
      tank.textContent = '';
      const f = s.o2 / s.O, cc = f > 0.5 ? '#4fd6a0' : f > 0.25 ? '#f2b84b' : '#ff6a4a';
      const cyc = cycleCost(s);
      tank.append(h('span', { class: 'lb', text: 'O₂ 산소' }),
        h('div', { class: 'bar' }, h('i', { style: { width: Math.max(0, Math.min(100, f * 100)) + '%', background: cc } }), h('b', { text: s.o2 + '/' + s.O + (cyc ? ' · 한 바퀴 −' + cyc : '') })),
        h('span', { class: 'rd', text: Math.min(s.r + 1, ROUNDS) + '/' + ROUNDS + '판' }));
    }
    function viewSeat() {
      const s = st;
      if (s.ph !== 'x' && api.canAct(s.cur)) return s.cur;
      const m = api.mySeats ? api.mySeats() : [];
      for (const q of m) if (s.d[q] <= 1) return q;
      return m.length ? m[0] : s.cur;
    }
    function renderHelp() {
      const s = vs || st;
      help.textContent = '';
      if (s.ph === 'x') { help.append(h('span', { class: 'tx', text: '탐사 끝! 결과를 확인해요.' })); return; }
      const V = busy ? (tok.seat >= 0 ? tok.seat : s.cur) : viewSeat();
      const who = s.n > 1 ? nm(V) + ': ' : '';
      if (s.d[V] === 2) { help.append(h('span', { class: 'tx', text: who + '잠수정에 돌아왔어요. 보물은 안전해요! 💰' + s.rg[V] })); return; }
      if (s.p[V] === 0) { help.append(h('span', { class: 'tx', text: who + '잠수정에서 출발! 아래로 내려가며 보물을 주워요. 들수록 산소가 빨리 줄어요.' })); return; }
      const I = helpInfo(s, V);
      const pc = Math.round(I.prob * 100);
      const tx = h('span', { class: 'tx' });
      tx.innerHTML = '<b>돌아갈 수 있나?</b> ' + (s.n > 1 ? nm(V).slice(0, 5) + ' · ' : '') + '🚤까지 <b>' + I.dist + '칸</b> · 한 번에 약 ' + I.e.toFixed(1) + '칸 → <b>' + (I.need > 30 ? '∞' : I.need) + '번</b> 필요 · 산소로 <b>' + I.turns + '번</b> 더';
      help.append(tx, h('span', { class: 'pc', style: { color: pcol(I.prob) }, text: '귀환 ' + pc + '%' }));
    }
    let barKey = '';
    function renderBar() {
      const s = st;
      const me = s.ph !== 'x' && !busy && api.canAct(s.cur) && sentKey !== s.sq + s.ph;
      const key = [me, s.sq, s.ph, busy, sentKey].join('|');
      if (key === barKey) return;
      barKey = key;
      bar.textContent = '';
      if (s.ph === 'x') { bar.append(h('div', { class: 'sd-wait', text: '탐사가 끝났어요' })); return; }
      if (!me) {
        bar.append(h('div', { class: 'sd-wait', text: busy ? '…' : (api.players[s.cur] && api.players[s.cur].ai ? '🤖 ' : '') + nm(s.cur) + ' 차례 · ' + (s.ph === 'p' ? '보물 고르는 중' : s.d[s.cur] === 1 ? '올라가는 중' : '내려갈까 돌아갈까…') }));
        return;
      }
      const i = s.cur, c = s.c[i], slow = slowOf(c);
      const sub = (t) => h('small', { text: t });
      if (s.ph === 'r') {
        const mv = slow ? '🎲 −' + slow + ' (짐 무게)' : '🎲 1~6칸';
        if (s.d[i] === 1) {
          bar.append(h('button', { class: 'btn primary', onclick: () => send({ g: 'r' }) }, '⬆ 굴려서 올라가기', sub(mv)));
        } else if (s.p[i] === 0) {
          bar.append(h('button', { class: 'btn primary', onclick: () => send({ g: 'd' }) }, '⬇ 잠수 시작', sub('🎲 1~6칸 내려가요')));
        } else {
          bar.append(h('button', { class: 'btn', onclick: () => send({ g: 'u' }) }, '⬆ 돌아가기', sub('이제부터 위로 · ' + mv)),
            h('button', { class: 'btn primary wide', onclick: () => send({ g: 'd' }) }, '⬇ 더 깊이', sub(mv)));
        }
        return;
      }
      // 'p' 단계
      const pos = s.p[i];
      if (canTake(s, i)) {
        const ch = s.tr[pos], T = TY[ttype(ch)];
        const ex = slowOf(c + ch) > slow ? ' · 느려져요' : '';
        bar.append(h('button', { class: 'btn', onclick: () => send({ k: 0 }) }, '그냥 두기', sub('안 가져가요')),
          h('button', { class: 'btn primary wide', onclick: () => send({ k: 1 }) }, '✋ ' + T.n + ' ' + tval(ch) + ' 줍기', sub('무게 ' + twt(ch) + ' · 산소 −' + twt(ch) + '/차례' + ex)));
      } else if (canDrop(s, i)) {
        const box = h('div', { class: 'sd-drop' }, h('div', { class: 'q', text: '빈 자리예요. 보물을 내려놓아 가벼워질까요?' }));
        const row = h('div', { class: 'row' });
        for (let j = 0; j < c.length; j++) {
          const ch = c[j];
          row.append(h('button', { class: 'btn sm', title: TY[ttype(ch)].n + ' ' + tval(ch) + ' 내려놓기', onclick: () => send({ k: 2, i: j }) }, chip(ch), h('span', { text: ' ↓' })));
        }
        row.append(h('button', { class: 'btn sm primary', style: { flex: '1.6' }, onclick: () => send({ k: 0 }) }, '그냥 가기'));
        box.append(row);
        bar.append(box);
      } else bar.append(h('div', { class: 'sd-wait', text: '…' }));
    }
    function render() { if (!st) return; renderStrip(); renderTank(); renderHelp(); renderBar(); }
    function send(a) {
      if (!st || busy) return;
      const k = st.sq + st.ph;
      if (sentKey === k) return;
      sentKey = k;
      api.sfx('click');
      api.act(a);
      later(() => { if (st && sentKey === k && st.sq + st.ph === k) { sentKey = ''; barKey = ''; renderBar(); } }, 2500);
      renderBar();
    }

    /* ---------- 재생 ---------- */
    function snap() { vs = null; tok.seat = -1; barKey = ''; }
    function showSum(L0, s) {
      sum.textContent = '';
      sum.append(h('h3', { text: (L0.r + 1) + '판 끝!' }), h('div', { class: 'sub', text: L0.out ? 'O₂ 산소가 바닥났어요' : '모두 잠수정으로 돌아왔어요' }));
      for (let i = 0; i < L0.end.length; i++) {
        const [k, g, lost] = L0.end[i];
        const tx = k === 0 ? '🏠 +' + g : k === 1 ? '⚓ 로프 구조 +' + g + (lost ? ' (−' + lost + ')' : '') : (lost ? '💀 잃음 −' + lost : '💀 못 돌아옴') + (g ? ' · +' + g : '');
        sum.append(h('div', { class: 'rw' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { class: 'n', text: nm(i) }), h('span', { class: 'v', text: tx })));
      }
      sum.append(h('div', { class: 'tap', text: st.ph === 'x' ? '눌러서 결과 보기' : '눌러서 다음 판 · 빈 자리 절반에 새 보물이 생겨요' }));
      sum.classList.add('show');
      const anyLost = L0.end.some((e) => e[0] === 2 && e[2] > 0);
      api.sfx(anyLost ? 'lose' : 'win');
      sumUntil = performance.now() + 3200 / sp();
      later(closeSum, 3200);
    }
    function closeSum() {
      if (!sum.classList.contains('show')) return;
      sum.classList.remove('show');
      snap(); setBusy(false); render();
    }
    sum.addEventListener('pointerdown', (e) => { e.stopPropagation(); closeSum(); });

    function afterAnim(L0, s) {
      if (L0.dr) {
        const [q, c] = L0.dr;
        float(G.W / 2, 22, (s.n > 1 ? nm(q).slice(0, 5) + ' 숨쉬기 ' : '숨쉬기 ') + 'O₂ −' + c, '#bfe9ff');
      }
      if (L0.end) { showSum(L0, s); return; }
      snap(); setBusy(false); render();
    }
    function playMove(L0, prev, s) {
      vs = prev;
      setBusy(true);
      const q = L0.s, path = L0.path;
      tok.seat = q;
      const start = diverXY(prev, q, path[0]);
      tok.x = start[0]; tok.y = start[1];
      const dx = G.pts[path[0]];
      dice = { x: Math.max(30, Math.min(G.W - 30, dx[0] + 30)), y: Math.max(30, dx[1] - 26), v: L0.die, t0: performance.now(), dur: 520 / sp() };
      api.sfx('roll');
      render();
      let t = 560;
      const stepMs = 170;
      const evs = L0.ev || [];
      const pushAt = evs.includes('c') ? path.length - 1 - PUSH : -1;
      for (let k = 1; k < path.length; k++) {
        const pk = path[k], isPush = pushAt > 0 && k > pushAt;
        later(() => {
          const xy = pk === 0 ? diverXY(prev, q, 0) : [G.pts[pk][0], G.pts[pk][1] - G.r * 0.75];
          tok.x = xy[0]; tok.y = xy[1];
          api.sfx(isPush ? 'whoosh' : 'tick');
          if (isPush && k === pushAt + 1) float(xy[0], xy[1] - 10, '물살! +' + PUSH + '칸', '#7fe8ff');
        }, t);
        t += isPush ? 110 : stepMs;
      }
      if (path.length === 1 && evs.includes('z')) later(() => { float(tok.x, tok.y - 14, '너무 무거워요! 제자리', '#ffb09a'); api.buzz(30); }, t);
      later(() => {
        const last = path[path.length - 1];
        const [x, y] = last > 0 ? G.pts[last] : [tok.x, tok.y];
        if (evs.includes('j')) { float(x, y - 16, '해파리! 산소 −' + JELLY, '#ff9ad8'); api.sfx('hit'); api.buzz(40); sparkle(x, y, '#ff7ad0', 10); }
        if (evs.includes('a')) { float(x, y - 16, '공기 방울! 산소 +' + AIR, '#dffaff'); api.sfx('pop'); sparkle(x, y, '#dffaff', 14); }
        if (evs.includes('b')) { float(x, y - 16, '바닥! 이제 올라가요', '#ffe39a'); api.sfx('thud'); }
        const hi = evs.indexOf('h');
        if (hi >= 0) { const v = +evs[hi + 1] || 0; float(tok.x + 30, tok.y - 10, v ? '🏠 귀환! +' + v : '🏠 귀환', '#ffe39a'); if (v) { api.sfx('chip'); sparkle(tok.x, tok.y, '#ffd36b', 16); } }
        vs = null;            // 실제 상태로
        if (L0.g === 'u') float(x, y - 30, '⬆ 돌아가기 시작', '#cfe7f2');
        if (s.ph === 'p' && !L0.end) { tok.seat = -1; setBusy(false); barKey = ''; render(); return; }
        if (L0.end) { vs = prev; tok.seat = q; }
        afterAnim(L0, s);
      }, t + 80);
    }
    function playPick(L0, prev, s) {
      vs = prev;
      setBusy(true);
      const [x, y] = G.pts[L0.i], d = diverXY(prev, L0.s);
      if (L0.k === 'tk') { flyT = { x0: x, y0: y, x1: d[0], y1: d[1], ch: L0.ch, t0: performance.now(), dur: 380 / sp() }; api.sfx('chip'); float(x, y - 22, '+' + TY[ttype(L0.ch)].n + ' ' + tval(L0.ch), '#ffe39a'); }
      else if (L0.k === 'dp') { flyT = { x0: d[0], y0: d[1], x1: x, y1: y, ch: L0.ch, t0: performance.now(), dur: 380 / sp() }; api.sfx('thud'); float(x, y - 22, '내려놓기', '#cfe7f2'); }
      render();
      later(() => {
        if (L0.end) { vs = prev; } else vs = null;
        flyT = null;
        afterAnim(L0, s);
      }, L0.k === 'sk' ? 60 : 420);
    }
    function update(s, prev) {
      const first = !st;
      st = s;
      if (first || !G) layout();
      const pl = prev && prev.last ? prev.last.id : -1;
      if (!first && prev && s.last && s.last.id === pl + 1 && prev.N === s.N) {
        sum.classList.remove('show');
        if (s.last.k === 'mv') { playMove(s.last, prev, s); return; }
        if (s.last.k === 'tk' || s.last.k === 'dp' || s.last.k === 'sk') { playPick(s.last, prev, s); return; }
      }
      if (!busy) snap();
      render();
    }
    const stopLoop = U.loop((dt, now) => {
      drawScene(now);
    });

    // 칸 눌러서 설명 보기
    const TIPS = { c: '» 물살: 여기서 멈추면 가던 쪽으로 2칸 더 밀려요', j: '해파리: 여기서 멈추면 공용 산소 −2', a: '공기 방울: 여기서 멈추면 산소 +3 (판마다 1번)', A: '다 쓴 공기 방울 (다음 판에 다시 생겨요)' };
    function onDown(e) {
      const s = vs || st; if (!s || !G) return;
      const p = cv.local(e);
      for (let i = 1; i <= s.N; i++) {
        const [x, y] = G.pts[i];
        if ((p.x - x) ** 2 + (p.y - y) ** 2 < (G.r + 8) ** 2) {
          const k = s.tl[i], z = zoneOf(s, i);
          let t = TIPS[k];
          if (!t) t = s.tr[i] !== '.' ? TY[ttype(s.tr[i])].n + ' ' + tval(s.tr[i]) + ' · 무게 ' + twt(s.tr[i]) : '빈 자리 (보물을 내려놓을 수 있어요)';
          api.toast(i + '칸 · ' + ZN[z] + ' — ' + t);
          return;
        }
      }
    }
    cv.cv.addEventListener('pointerdown', onDown);

    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st || busy || st.ph === 'x' || !api.canAct(st.cur)) return;
      const i = st.cur;
      if (st.ph === 'r') {
        if (id === 'dive') send(st.d[i] === 1 ? { g: 'r' } : { g: 'd' });
        else if (id === 'back') { if (st.d[i] === 1) send({ g: 'r' }); else if (st.p[i] > 0) send({ g: 'u' }); }
      } else if (st.ph === 'p') {
        if (id === 'dive') send(canTake(st, i) ? { k: 1 } : { k: 0 });
        else if (id === 'back') send({ k: 0 });
      }
    }) : null;

    return {
      update,
      destroy() {
        dead = true; stopLoop(); timers.forEach(clearTimeout); timers.clear();
        if (offIn) offIn();
        cv.cv.removeEventListener('pointerdown', onDown);
        if (busy) api.setBusy(false);
        cv.destroy(); wrap.remove(); style.remove();
      },
    };
  }

  L.register({
    id: 'subdive', name: '해저 잠수정 탐사', tag: '산소 나눠 쓰기 욕심', cat: '보드',
    blurb: '모두 한 잠수정에서 출발해 공용 산소를 나눠 써요. 깊이 갈수록 보물이 비싸지만, 들수록 산소가 빨리 줄고 느려져요. 산소가 바닥나기 전에 돌아와야 보물이 내 것!',
    tint: '#0f4a6e',
    icon: '<ellipse cx="28" cy="22" rx="18" ry="8" fill="currentColor"/><rect x="23" y="9" width="10" height="7" rx="2" fill="currentColor"/><circle cx="12" cy="44" r="5" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="26" cy="38" r="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M38 50l4-8 4 8z" fill="currentColor"/><path d="M28 30v8" stroke="currentColor" stroke-width="2" stroke-dasharray="2 2"/>',
    minPlayers: 1, maxPlayers: 6, defaultPlayers: 3, hidden: false, aiDelay: 700,
    options: [
      { id: 'sea', label: '바다', choices: [{ v: 'rand', label: '무작위' }, { v: 'reef', label: '산호초 (짧게)' }, { v: 'calm', label: '잔잔한 바다' }, { v: 'jelly', label: '해파리 숲' }, { v: 'trench', label: '깊은 해구 (길게)' }], def: 'rand' },
    ],
    quick: [
      '차례마다 「⬇ 더 깊이」나 「⬆ 돌아가기」를 고르고 주사위만큼 움직여요. 멈춘 칸의 보물은 주울 수 있어요.',
      '산소는 모두 함께 써요. 차례가 올 때마다 내가 든 보물 무게만큼 산소가 줄고, 무거우면 느려져요.',
      '산소가 바닥나기 전에 잠수정으로 돌아와야 보물이 내 것! 3판 뒤 💰가 가장 많으면 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '모두 같은 잠수정을 타고 바닷속 보물을 건져 와요. 3판이 끝났을 때 잠수정으로 가져온 보물 💰가 가장 많으면 우승.',
        '같으면 보물 개수가 많은 사람이 이겨요. 혼자 하면 💰 18 / 28 / 38로 별 1~3개.'] },
      { h: '차례에 할 일', p: [
        '① 내려가는 중이면 「⬇ 더 깊이」나 「⬆ 돌아가기」를 골라요. 한 번 돌아가기로 하면 그 판엔 다시 못 내려가요.',
        '② 주사위(1~6)를 굴려 그만큼 움직여요. 단, 짐 무게 2마다 1칸씩 덜 가요 (짐 무게 4면 −2칸, 0칸이면 제자리).',
        '③ 보물이 있는 칸에 멈추면 「줍기」나 「그냥 두기」. 빈 자리에 멈추면 들고 있는 보물을 내려놓아 가벼워질 수 있어요.',
        '여러 사람이 같은 칸에 있어도 괜찮아요. 맨 아래 칸에 닿으면 저절로 돌아가기 시작해요.'] },
      { h: '공용 산소', p: [
        '산소 탱크 하나를 모두 함께 써요 (사람 수에 따라 22~42, 혼자면 15).',
        '내 차례가 시작될 때마다 산소가 「들고 있는 보물 무게」만큼 줄어요. 얕은·중간 보물은 무게 1, 깊은 보물(6 이상)은 무게 2.',
        '어스름 해구·깊은 심해(아래쪽 절반)에선 수압 때문에 숨이 1 더 들어요.',
        '산소가 0이 된 다음 차례가 오면 그 판은 끝나요. 위쪽 산소 막대 옆 「한 바퀴 −N」은 모두가 한 번씩 할 때 줄어드는 양이에요.'] },
      { h: '판 끝', p: [
        '잠수정에 돌아온 사람은 들고 온 보물을 지켜요.',
        '못 돌아왔지만 잠수정에서 3칸 안이면 ⚓ 구조 로프로 가장 값진 보물 1개만 건져요.',
        '그보다 멀면 들고 있던 보물을 모두 잃어요 (해류에 휩쓸려 사라져요).',
        '다음 판엔 빈 자리 절반쯤에 새 보물이 생기고, 산소가 다시 가득 차요. 💰가 가장 적은 사람이 먼저 해요.'] },
      { h: '보물과 특별한 칸', p: [
        '깊을수록 비싸요: 얕은 바다 1~3, 산호 숲 3~5, 어스름 해구 6~8, 깊은 심해 9~12. 맨 아래엔 11~12짜리 큰 보물!',
        '보물은 ⚪ 진주, 🟡 금화, 🏺 유물 3종이에요. 게임 끝에 세 종류를 한 벌 모을 때마다 💰 +5.',
        '» 물살: 멈추면 가던 쪽으로 2칸 더 밀려요 (올라갈 땐 큰 도움!).',
        '해파리: 멈추면 공용 산소 −2. 공기 방울: 멈추면 산소 +3 (판마다 한 번).',
        '칸을 누르면 무엇인지 알려 줘요.'] },
      { h: '돌아갈 수 있나?', p: [
        '아래 도우미 줄이 잠수정까지 남은 칸, 한 번에 가는 평균 칸, 산소로 버틸 수 있는 내 차례 수, 귀환 확률을 보여 줘요.',
        '귀환 확률이 초록(80%↑)이면 여유, 노랑이면 조심, 빨강이면 지금 바로 돌아가세요!'] },
      { h: '예시', p: [
        '산소 20, 나는 20칸(어스름 해구)에서 유물 7(무게 2)과 진주 2(무게 1)를 들었어요 → 짐 무게 3, 주사위에서 −1칸.',
        '내 차례마다 산소 −4(무게 3 + 수압 1), 다른 두 사람이 한 바퀴에 −2를 써요 → 한 바퀴 −6, 산소로 약 3번 더 움직여요.',
        '평균 2.5칸씩이면 20칸에 8번이 필요 → 위험! 빈 자리에 진주를 내려놓거나, 물살 칸을 노리거나, 바로 돌아가야 해요.'] },
      { h: '조작', p: [
        '아래 큰 버튼으로 골라요. 한 폰으로 여럿이 할 때는 차례인 사람이 누르면 돼요 (숨긴 정보가 없어요).',
        'PC: Space·↓ 더 깊이/굴리기/줍기, U·↑ 돌아가기/그냥 두기.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 욕심부리다 자주 잃고, 어려움은 귀환 확률과 기댓값을 계산해요.'] },
    ],
    tutorial: [
      { sel: '.sd-cv', text: '위의 노란 잠수정에서 출발해 점선 길을 따라 바다 아래로 내려가요. 깊을수록 보물이 비싸요. 칸을 누르면 설명이 나와요.' },
      { sel: '.sd-tank', text: '모두 함께 쓰는 산소 탱크예요. 차례가 올 때마다 그 사람이 든 보물 무게만큼 줄어요. 바닥나면 판 끝!' },
      { sel: '.sd-help', text: '「돌아갈 수 있나?」 도우미예요. 남은 칸과 산소로 버틸 차례 수, 귀환 확률을 알려 줘요. 빨간색이면 서둘러요!' },
      { sel: '.sd-bar', text: '「더 깊이」로 내려가거나 「돌아가기」로 방향을 바꿔요. 보물 칸에 멈추면 줍기, 빈 자리에선 내려놓기도 할 수 있어요.' },
      { sel: '.sd-strip', text: '모두의 보물(💰)과 들고 있는 보물이에요. 잠수정 3칸 안에서 산소가 끝나면 로프로 1개는 건져요. 3판 뒤 💰가 많으면 승리!' },
    ],
    controls: [
      { id: 'dive', label: '더 깊이 / 굴리기 / 줍기', keys: ['Space', 'ArrowDown'], pad: ['a'] },
      { id: 'back', label: '돌아가기 / 그냥 두기', keys: ['KeyU', 'ArrowUp'], pad: ['b'] },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { helpInfo, probReach, futureTurns, scoreOf, o2Max, SEAS },
  });
})();
