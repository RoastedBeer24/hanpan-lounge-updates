/* 다른 그림 찾기 대결 — everyone searches the same pair of pictures at the same time (a race).
   Pictures are procedural scenes drawn on canvas from a seed (30 places, ~220 drawable things). Each round has 5–7
   differences: removed / extra thing, colour, size, changed detail; from round 2 also mirrored, moved, tilted, pattern,
   count, text/number. Later rounds: more things, smaller changes, trickier kinds (difficulty dv = k − 5). Tap a difference on either picture →
   circled on both in your colour. Wrong taps lock you for a moment (anti-spam). Limited hints. 3 or 5 rounds.
   Realtime (one person per phone): the host's view runs the round clock and the AI searchers and publishes the state;
   a phone judges its own taps locally (same seed → same scene) and sends {t:'hit', i}; the host's apply decides who
   was first. Solo = time attack with stars. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= constants ======================= */
  const W = 1000, H = 660, TAU = Math.PI * 2;
  const OL = '#2b2233';
  const COUNT_MS = 3200, END_MS = 5600, HINTS = 3, HINT_AFTER = 8000, HINT_SOLO_PEN = 10;
  const PAL = ['#e5484d', '#f28a2e', '#f6cd3b', '#4caf50', '#22b3a6', '#3d7ee6', '#8f5bd8', '#f483b6', '#9b6332', '#f6f2ea', '#8f909c', '#3b3542'];
  const NEAR = { 0: [1, 7, 8], 1: [0, 2, 8], 2: [1, 9], 3: [4], 4: [3, 5], 5: [4, 6], 6: [5, 7, 11], 7: [6, 0], 8: [1, 0, 11], 9: [2, 10], 10: [9, 11], 11: [10, 8, 6] };
  const KH = { col: 0.85, rm: 0.9, ex: 0.95, sz: 1.15, pat: 1.05, cnt: 1.25, var: 1.25, rot: 1.15, mv: 1.3, mir: 1.3, txt: 1.35 };
  const MINRR = 30;

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const ri = (R, n) => Math.floor(R() * n);
  const pick = (R, a) => a[ri(R, a.length)];
  function shuf(R, a) { for (let i = a.length - 1; i > 0; i--) { const j = ri(R, i + 1); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ======================= drawing helpers (X = current ctx) ======================= */
  let X = null, LWv = 3.2;
  const LWB = 3.2;
  function ink() { X.lineWidth = LWv; X.strokeStyle = OL; X.lineJoin = 'round'; X.lineCap = 'round'; X.stroke(); }
  function F(col) { X.fillStyle = col; X.fill(); ink(); }
  function Fn(col) { X.fillStyle = col; X.fill(); }
  function C(x, y, r, col, no) { X.beginPath(); X.arc(x, y, r, 0, TAU); if (no) Fn(col); else F(col); }
  function E(x, y, rx, ry, col, rot, no) { X.beginPath(); X.ellipse(x, y, rx, ry, rot || 0, 0, TAU); if (no) Fn(col); else F(col); }
  function rrp(x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); X.moveTo(x + r, y); X.arcTo(x + w, y, x + w, y + h, r); X.arcTo(x + w, y + h, x, y + h, r); X.arcTo(x, y + h, x, y, r); X.arcTo(x, y, x + w, y, r); X.closePath(); }
  function RR(x, y, w, h, r, col, no) { X.beginPath(); rrp(x, y, w, h, r); if (no) Fn(col); else F(col); }
  function P(a, col, no) { X.beginPath(); X.moveTo(a[0], a[1]); for (let i = 2; i < a.length; i += 2) X.lineTo(a[i], a[i + 1]); X.closePath(); if (no) Fn(col); else F(col); }
  function S(a, w, col) { X.beginPath(); X.moveTo(a[0], a[1]); for (let i = 2; i < a.length; i += 2) X.lineTo(a[i], a[i + 1]); X.lineWidth = w; X.strokeStyle = col; X.lineCap = 'round'; X.lineJoin = 'round'; X.stroke(); }
  function SO(a, w, col) { S(a, w + LWv * 2, OL); S(a, w, col); }
  function Qd(x0, y0, cx, cy, x1, y1, w, col, out) {
    X.lineCap = 'round';
    if (out) { X.beginPath(); X.moveTo(x0, y0); X.quadraticCurveTo(cx, cy, x1, y1); X.lineWidth = w + LWv * 2; X.strokeStyle = OL; X.stroke(); }
    X.beginPath(); X.moveTo(x0, y0); X.quadraticCurveTo(cx, cy, x1, y1); X.lineWidth = w; X.strokeStyle = col; X.stroke();
  }
  function blob(list, col) { // union of circles [x,y,r,...] with one outline
    X.lineWidth = LWv * 2; X.strokeStyle = OL;
    for (let i = 0; i < list.length; i += 3) { X.beginPath(); X.arc(list[i], list[i + 1], list[i + 2], 0, TAU); X.stroke(); }
    X.fillStyle = col;
    for (let i = 0; i < list.length; i += 3) { X.beginPath(); X.arc(list[i], list[i + 1], list[i + 2], 0, TAU); X.fill(); }
  }
  function starP(x, y, n, ro, rin, col, rot) {
    const a = [];
    for (let i = 0; i < n * 2; i++) { const ang = (rot == null ? -Math.PI / 2 : rot) + i * Math.PI / n, r = i % 2 ? rin : ro; a.push(x + Math.cos(ang) * r, y + Math.sin(ang) * r); }
    P(a, col);
  }
  const shC = {};
  function sh(hex, f) {
    const key = hex + f; if (shC[key]) return shC[key];
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return (shC[key] = 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')');
  }
  function eye(x, y, r, light) { C(x, y, r, light ? '#ffe27a' : OL, true); C(x + r * 0.35, y - r * 0.35, r * 0.35, '#fff', true); }
  function glow(x, y, r, col) { const g = X.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(255,230,140,0)'); X.fillStyle = g; X.beginPath(); X.arc(x, y, r, 0, TAU); X.fill(); }
  function clipDo(pathFn, fn) { X.save(); X.beginPath(); pathFn(); X.clip(); fn(); X.restore(); }
  const KFONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  function TX(s, x, y, sz, col, mono) { X.fillStyle = col; X.font = '700 ' + sz + 'px ' + (mono ? '"IBM Plex Mono",ui-monospace,Menlo,monospace' : KFONT); X.textAlign = 'center'; X.textBaseline = 'middle'; X.fillText(s, x, y); }
  function RG(x, y, r, w, col, a0, a1) { X.beginPath(); X.arc(x, y, r, a0 || 0, a1 == null ? TAU : a1); X.lineCap = 'round'; X.lineWidth = w + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = w; X.strokeStyle = col; X.stroke(); }
  function lum(hex) { if (!hex || hex[0] !== '#') return 0.5; const n = parseInt(hex.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; }
  // pattern inside a path: 0 none, 1 diagonal stripes, 2 dots, 3 flat stripes
  function patt(path, p, k) {
    if (!p) return;
    const c = lum(k) > 0.62 ? 'rgba(43,34,51,.42)' : 'rgba(255,255,255,.82)';
    clipDo(path, () => {
      X.fillStyle = c;
      if (p === 1) { X.save(); X.rotate(-0.6); for (let x = -130; x < 130; x += 20) X.fillRect(x, -130, 9, 260); X.restore(); }
      else if (p === 2) { for (let j = 0, y = -108; y < 110; y += 18, j++) for (let x = -108 + (j % 2) * 9; x < 110; x += 18) { X.beginPath(); X.arc(x, y, 4.4, 0, TAU); X.fill(); } }
      else { for (let y = -112; y < 112; y += 22) X.fillRect(-130, y, 260, 9); }
    });
  }
  function pfill(path, k, p) { X.beginPath(); path(); Fn(k); patt(path, p, k); X.beginPath(); path(); ink(); }

  /* ======================= drawable things ======================= */
  // r = bounding radius (local units, origin = centre), ft = how far the base sits below the centre,
  // col = palette indices it may take (null = fixed colours), vn = number of detail variants, asym = mirror diff allowed.
  const TY = {};
  function def(name, r, o, draw) { TY[name] = Object.assign({ r, ft: r * 0.85, col: null, vn: 1, asym: false, draw }, o); }
  const GREEN = '#4caf50', DGREEN = '#3b8a3a', WOOD = '#9b6332', WOOD2 = '#c58a4a', WHITE = '#f6f2ea', GOLD = '#f6cd3b';

  def('flower', 36, { ft: 32, col: [0, 1, 2, 5, 6, 7, 9], vn: 2 }, (k, v) => {
    S([0, -6, 0, 32], 4.5, DGREEN); E(9, 20, 9, 4.5, GREEN, -0.6);
    const n = v ? 8 : 5, pr = v ? 6.5 : 8.5, d = v ? 12.5 : 11;
    for (let i = 0; i < n; i++) { const a = i / n * TAU - Math.PI / 2; C(Math.cos(a) * d, -12 + Math.sin(a) * d, pr, k); }
    C(0, -12, 6.5, k === PAL[2] ? '#8a5a2b' : GOLD);
  });
  def('tree', 95, { ft: 90, col: [3, 1, 2], vn: 2 }, (k, v) => {
    RR(-11, 10, 22, 80, 4, '#8a5a32');
    blob([0, -32, 48, -32, -4, 32, 32, -4, 32, 0, -58, 30], k);
    E(-14, -46, 14, 9, sh(k, 0.25), -0.5, true);
    if (v) { const pts = [-24, -18, 10, -40, 26, -10, -6, -2, 4, -66, -36, -40]; for (let i = 0; i < pts.length; i += 2) C(pts[i], pts[i + 1], 6, PAL[0]); }
  });
  def('pine', 95, { ft: 88, col: [3, 4], vn: 2 }, (k, v) => {
    RR(-9, 60, 18, 28, 3, '#7a4f2c');
    P([0, -25, 68, 64, -68, 64], sh(k, -0.12)); P([0, -60, 56, 14, -56, 14], k); P([0, -90, 42, -26, -42, -26], sh(k, 0.1));
    if (v) { const pts = [-30, 50, 24, 40, -14, 4, 20, -4, 0, -42, 40, 58]; const cs = [PAL[0], GOLD, PAL[5], PAL[0], GOLD, PAL[7]]; for (let i = 0; i < pts.length; i += 2) C(pts[i], pts[i + 1], 6, cs[i / 2]); }
  });
  def('cloud', 62, { vn: 2 }, (k, v) => {
    const l = [-30, 10, 24, 0, -4, 32, 32, 10, 24, -46, 18, 16, 46, 18, 16];
    if (v) l.push(20, -22, 20);
    blob(l, '#fbfcff'); E(-8, -14, 14, 7, '#fff', -0.3, true);
  });
  def('sun', 58, { vn: 2 }, (k, v) => {
    for (let i = 0; i < 10; i++) { const a = i / 10 * TAU; const c = Math.cos(a), s = Math.sin(a); P([c * 54, s * 54, c * 38 - s * 9, s * 38 + c * 9, c * 38 + s * 9, s * 38 - c * 9], '#f5a524'); }
    C(0, 0, 33, GOLD);
    if (v) { eye(-11, -6, 4); eye(11, -6, 4); X.beginPath(); X.arc(0, 4, 13, 0.3, Math.PI - 0.3); ink(); }
  });
  def('bird', 32, { col: [0, 2, 5, 6, 7, 1], asym: true, ft: 22 }, (k) => {
    P([-18, 2, -32, -8, -30, 12], sh(k, -0.15)); E(-2, 4, 20, 13, k); E(-6, 3, 11, 7, sh(k, -0.2), -0.3);
    C(14, -8, 10, k); eye(17, -10, 2.6); P([23, -10, 33, -6, 23, -2], '#f5a524');
  });
  def('star', 36, { col: [2, 9, 7, 1, 4], vn: 2, rt: 1 }, (k, v) => { starP(0, 0, v ? 6 : 5, 33, v ? 17 : 14, k); C(-6, -6, 4, '#fff', true); });
  def('balloon', 48, { ft: 46, col: [0, 1, 2, 3, 5, 6, 7], vn: 2, rt: 1 }, (k, v) => {
    Qd(0, 22, -8, 34, 2, 46, 2, '#6d6474');
    E(0, -12, 26, 32, k);
    if (v) clipDo(() => X.ellipse(0, -12, 26, 32, 0, 0, TAU), () => { X.fillStyle = 'rgba(255,255,255,.8)'; X.fillRect(-30, -10, 60, 11); });
    P([-5, 22, 5, 22, 0, 16], sh(k, -0.2)); E(-9, -26, 6, 10, 'rgba(255,255,255,.55)', 0.4, true);
  });
  def('gift', 40, { ft: 31, col: [0, 3, 5, 6, 7, 1], vn: 2 }, (k, v) => {
    const rb = k === PAL[2] ? WHITE : GOLD;
    RR(-28, -12, 56, 43, 4, k); RR(-31, -22, 62, 13, 3, sh(k, 0.15)); RR(-6, -22, 12, 53, 0, rb);
    if (!v) { E(-11, -29, 11, 7, rb, -0.4); E(11, -29, 11, 7, rb, 0.4); C(0, -27, 4.5, rb); }
    else { RR(9, -2, 15, 11, 2, WHITE); }
  });
  def('mug', 34, { ft: 22, col: [0, 5, 3, 9, 2, 7], vn: 2, asym: true }, (k, v) => {
    X.beginPath(); X.arc(21, 2, 10, -1.4, 1.4); X.lineWidth = 7 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 7; X.strokeStyle = k; X.stroke();
    RR(-20, -17, 40, 39, 6, k); E(0, -17, 20, 5, sh(k, -0.3)); C(-4, 4, 6, 'rgba(255,255,255,.5)', true);
    if (v) { Qd(-8, -24, -14, -34, -6, -42, 3, '#d8d3e0'); Qd(6, -24, 0, -34, 8, -42, 3, '#d8d3e0'); }
  });
  def('books', 42, { ft: 26, col: [0, 5, 3, 6, 1], vn: 2 }, (k, v) => {
    const cs = [k, PAL[(PAL.indexOf(k) + 4) % 8], PAL[(PAL.indexOf(k) + 2) % 8]];
    const ys = v ? [12, -2, -16] : [12, -2];
    ys.forEach((y, i) => { const off = i % 2 ? 4 : -2; RR(-34 + off, y, 68, 14, 3, cs[i]); RR(26 + off, y + 3, 6, 8, 1, WHITE, true); });
  });
  def('clock', 42, { col: [8, 0, 5, 11, 3], vn: 5, tx: 1 }, (k, v) => {
    C(0, 0, 35, k); C(0, 0, 27, '#fbf7ee');
    for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; S([Math.cos(a) * 20, Math.sin(a) * 20, Math.cos(a) * 25, Math.sin(a) * 25], 3, OL); }
    const hd = [[13, 0, 0, -21], [-13, 0, 0, -21], [8, 10, 0, 21], [0, 13, 21, 0], [-10, -8, 0, 21]][v];
    S([0, 0, hd[0], hd[1]], 4.5, OL); S([0, 0, hd[2], hd[3]], 3, OL); C(0, 0, 3.5, PAL[0], true);
  });
  def('lamp', 64, { ft: 60, col: [2, 0, 5, 3, 7, 4], vn: 2 }, (k, v) => {
    if (v) glow(0, -30, 64, 'rgba(255,230,140,.55)');
    E(0, 57, 18, 5, '#3b3542'); S([0, -20, 0, 56], 4, '#3b3542');
    P([-20, -58, 20, -58, 32, -18, -32, -18], k);
    if (v) E(0, -17, 12, 4, '#fff6c8', 0, true);
  });
  def('plant', 48, { ft: 44, col: [8, 0, 5, 1, 9], vn: 2 }, (k, v) => {
    if (v) { E(-24, -2, 7, 18, GREEN, -1.1); E(24, -2, 7, 18, GREEN, 1.1); }
    E(-14, -14, 8, 22, GREEN, -0.5); E(14, -14, 8, 22, GREEN, 0.5); E(0, -22, 8, 26, '#3f9a45');
    P([-22, 10, 22, 10, 17, 44, -17, 44], k); RR(-25, 4, 50, 10, 3, sh(k, 0.15));
  });
  def('cat', 46, { ft: 40, col: [1, 10, 11, 9], vn: 2, asym: true }, (k, v) => {
    if (v) Qd(-20, 34, -36, 40, -46, 34, 7, k, true); else Qd(-20, 30, -44, 20, -34, -6, 7, k, true);
    E(-4, 16, 24, 26, k); E(-2, 22, 12, 16, sh(k, 0.3), 0, true);
    P([-2, -28, 0, -44, 10, -32], k); P([14, -32, 24, -44, 26, -26], k);
    C(10, -16, 18, k);
    const lt = k === PAL[11] || k === PAL[10];
    eye(4, -18, 2.8, lt); eye(17, -18, 2.8, lt); C(11, -10, 2.4, PAL[7], true);
    S([20, -10, 32, -12], 1.5, OL); S([20, -7, 32, -5], 1.5, OL);
  });
  def('ball', 30, { ft: 28, col: [0, 5, 2, 3, 1, 6], vn: 2 }, (k, v) => {
    C(0, 0, 28, k);
    clipDo(() => X.arc(0, 0, 28, 0, TAU), () => {
      if (!v) { X.fillStyle = WHITE; X.save(); X.rotate(-0.5); X.fillRect(-30, -6, 60, 12); X.restore(); }
      else { C(-10, -8, 6, WHITE, true); C(10, 6, 6, WHITE, true); C(-6, 14, 5, WHITE, true); C(12, -14, 4, WHITE, true); }
    });
    X.beginPath(); X.arc(0, 0, 28, 0, TAU); ink(); C(-10, -12, 5, 'rgba(255,255,255,.6)', true);
  });
  def('apple', 28, { ft: 22, col: [0, 3, 2], vn: 2 }, (k, v) => {
    S([0, -12, 3, -24], 3.5, '#6b4423'); blob([-8, 4, 18, 8, 4, 18], k); C(-9, -3, 5, 'rgba(255,255,255,.5)', true);
    if (!v) E(10, -20, 8, 4, GREEN, -0.5);
  });
  def('fish', 46, { col: [1, 2, 5, 0, 6, 4, 7], vn: 2, asym: true, ft: 22 }, (k, v) => {
    P([-26, 0, -44, -16, -44, 16], sh(k, -0.12)); P([-6, -16, 6, -29, 12, -16], sh(k, -0.18));
    E(0, 0, 30, 19, k);
    if (v) { E(-8, 0, 4, 16, 'rgba(255,255,255,.75)', 0, true); E(4, 0, 4, 17, 'rgba(255,255,255,.75)', 0, true); }
    C(17, -4, 5, '#fff'); C(18, -4, 2.4, OL, true); S([27, 5, 22, 7], 2, OL);
  });
  def('frame', 58, { col: [8, 2, 0, 11], vn: 3, rt: 1 }, (k, v) => {
    RR(-46, -36, 92, 72, 4, k);
    clipDo(() => rrp(-38, -28, 76, 56, 2), () => {
      X.fillStyle = v === 1 ? '#fde3ea' : '#cfe8f5'; X.fillRect(-40, -30, 80, 60);
      if (v === 0) { P([-40, 30, -12, -6, 6, 14, 18, 0, 40, 30], '#5aa36a'); C(22, -14, 7, GOLD); }
      else if (v === 1) { X.beginPath(); X.moveTo(0, 18); X.bezierCurveTo(-30, -2, -14, -24, 0, -10); X.bezierCurveTo(14, -24, 30, -2, 0, 18); F(PAL[0]); }
      else { RR(-4, 0, 8, 30, 2, '#8a5a32'); C(0, -6, 15, GREEN); X.fillStyle = '#9fd36a'; X.fillRect(-40, 22, 80, 10); }
    });
    X.beginPath(); rrp(-38, -28, 76, 56, 2); ink();
  });
  def('window', 92, { col: [0, 5, 3, 7, 2], vn: 2 }, (k, v) => {
    RR(-70, -60, 140, 120, 6, WHITE);
    clipDo(() => rrp(-60, -50, 120, 100, 2), () => {
      const g = X.createLinearGradient(0, -50, 0, 50); g.addColorStop(0, '#8fd0f5'); g.addColorStop(1, '#d6f0ff'); X.fillStyle = g; X.fillRect(-60, -50, 120, 100);
      if (v) blob([-16, 0, 14, 4, -8, 17, 22, 2, 12], '#fff'); else C(26, -22, 12, GOLD);
    });
    X.beginPath(); rrp(-60, -50, 120, 100, 2); ink();
    S([0, -50, 0, 50], 6, WHITE); S([-60, 0, 60, 0], 6, WHITE);
    P([-66, -58, -36, -58, -50, 20, -66, 56], k); P([66, -58, 36, -58, 50, 20, 66, 56], k);
    RR(-76, -66, 152, 10, 4, sh(k, -0.25));
  });
  def('cushion', 34, { ft: 26, col: [0, 1, 2, 3, 5, 6, 7], vn: 2 }, (k, v) => {
    RR(-27, -23, 54, 46, 15, k); RR(-20, -16, 40, 32, 10, sh(k, 0.18), true);
    if (v) { C(-10, -8, 4, WHITE, true); C(10, -8, 4, WHITE, true); C(-10, 8, 4, WHITE, true); C(10, 8, 4, WHITE, true); }
  });
  def('sofa', 185, { ft: 80, col: [0, 5, 3, 6, 8, 4] }, (k) => {
    RR(-150, 66, 12, 16, 3, '#3b3542'); RR(138, 66, 12, 16, 3, '#3b3542');
    RR(-160, -60, 320, 86, 26, k); RR(-140, -46, 130, 56, 18, sh(k, 0.12), true); RR(10, -46, 130, 56, 18, sh(k, 0.12), true);
    RR(-150, 4, 300, 64, 14, sh(k, 0.06));
    RR(-178, -20, 44, 90, 20, k); RR(134, -20, 44, 90, 20, k);
  });
  def('rug', 200, { ft: 0, col: [0, 5, 6, 4, 1] }, (k) => {
    E(0, 0, 192, 48, k); E(0, 0, 160, 36, sh(k, 0.22), 0, true); E(0, 0, 120, 24, k, 0, true);
  });
  def('tv', 72, { ft: 66, vn: 3 }, (k, v) => {
    S([-30, 34, -40, 66], 5, '#3b3542'); S([30, 34, 40, 66], 5, '#3b3542');
    RR(-62, -52, 124, 86, 8, '#3b3542');
    clipDo(() => rrp(-54, -44, 108, 70, 4), () => {
      if (v === 0) { X.fillStyle = '#5bc0eb'; X.fillRect(-56, -46, 112, 74); X.beginPath(); X.moveTo(-56, 6); for (let x = -56; x <= 56; x += 8) X.lineTo(x, 6 + Math.sin(x / 9) * 6); X.lineTo(56, 30); X.lineTo(-56, 30); X.fillStyle = '#2f7fd6'; X.fill(); }
      else if (v === 1) { X.fillStyle = '#7cc35f'; X.fillRect(-56, -46, 112, 74); C(4, 2, 12, WHITE); C(4, 2, 4, OL, true); }
      else { const cs = ['#f6f2ea', GOLD, '#22b3a6', '#4caf50', '#8f5bd8', '#e5484d']; cs.forEach((c, i) => { X.fillStyle = c; X.fillRect(-54 + i * 18, -44, 18, 70); }); }
    });
    X.beginPath(); rrp(-54, -44, 108, 70, 4); ink();
  });
  def('vase', 50, { ft: 46, col: [5, 0, 4, 9, 2], vn: 2 }, (k, v) => {
    const st = v ? [[-16, -28], [0, -38], [16, -28]] : [[-11, -32], [11, -32]];
    const fc = [PAL[0], GOLD, PAL[7]];
    st.forEach((p, i) => { S([0, 0, p[0], p[1]], 3, DGREEN); C(p[0], p[1], 8, fc[i]); C(p[0], p[1], 3, '#fff6c8', true); });
    E(0, 24, 20, 22, k); RR(-9, -2, 18, 10, 3, k); E(-6, 18, 4, 9, 'rgba(255,255,255,.4)', 0, true);
  });

  def('shelf', 120, { ft: 6 }, () => {
    P([-90, 6, -90, 30, -70, 6], '#8a5a32'); P([90, 6, 90, 30, 70, 6], '#8a5a32');
    RR(-112, -6, 224, 13, 3, WOOD2);
  });

  /* sea */
  def('crab', 42, { ft: 24, col: [0, 1, 6], vn: 2 }, (k, v) => {
    for (let i = 0; i < 3; i++) { SO([-14, 10 + i * 4, -30, 16 + i * 6], 3, k); SO([14, 10 + i * 4, 30, 16 + i * 6], 3, k); }
    if (!v) { SO([-18, 0, -28, -14], 5, k); SO([18, 0, 28, -14], 5, k); C(-30, -20, 10, k); C(30, -20, 10, k); S([-30, -30, -30, -20], 2.5, OL); S([30, -30, 30, -20], 2.5, OL); }
    else { SO([-20, 6, -32, 8], 5, k); SO([20, 6, 32, 8], 5, k); C(-36, 6, 10, k); C(36, 6, 10, k); S([-46, 6, -36, 6], 2.5, OL); S([46, 6, 36, 6], 2.5, OL); }
    E(0, 6, 26, 16, k); S([-6, -8, -8, -18], 3, OL); S([6, -8, 8, -18], 3, OL); C(-8, -19, 4, '#fff'); C(8, -19, 4, '#fff'); C(-8, -19, 1.8, OL, true); C(8, -19, 1.8, OL, true);
  });
  def('starfish', 36, { ft: 20, col: [1, 0, 2, 7, 6], vn: 2 }, (k, v) => {
    starP(0, 0, 5, 33, 14, k);
    if (v) for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * TAU / 5; C(Math.cos(a) * 18, Math.sin(a) * 18, 3.2, WHITE, true); }
    C(0, 0, 4, sh(k, 0.3), true);
  });
  def('seaweed', 62, { ft: 60, col: [3, 4], vn: 2 }, (k, v) => {
    const fr = v ? [-16, 0, 16] : [-9, 9];
    fr.forEach((x, i) => { X.beginPath(); X.moveTo(x, 60); X.bezierCurveTo(x + 22, 30, x - 22, 0, x + (i % 2 ? 12 : -12), -58); X.lineCap = 'round'; X.lineWidth = 11 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 11; X.strokeStyle = i % 2 ? sh(k, 0.12) : k; X.stroke(); });
  });
  def('coral', 52, { ft: 48, col: [7, 1, 6, 0, 2], vn: 2 }, (k, v) => {
    const br = [[0, 48, 0, 8], [0, 18, -26, -28], [0, 12, 0, -46], [0, 18, 24, -30]];
    if (v) br.push([-12, -4, -38, -8], [12, 0, 38, -4]);
    br.forEach((b) => S([b[0], b[1], b[2], b[3]], 13 + LWv * 2, OL));
    br.forEach((b) => S([b[0], b[1], b[2], b[3]], 13, k));
    br.slice(1).forEach((b) => C(b[2], b[3], 4, sh(k, 0.35), true));
  });
  def('shell', 30, { ft: 18, col: [7, 9, 1, 2], asym: true }, (k) => {
    P([-26, 14, 20, 14, 26, -2, 8, -20, -12, -12], k);
    X.beginPath(); X.arc(6, -2, 10, 0, 5); ink(); X.beginPath(); X.arc(6, -2, 4.5, 0, 5); ink();
    S([-20, 10, -6, -8], 2, OL); S([-10, 13, 0, -6], 2, OL);
  });
  def('bubbles', 36, { vn: 2 }, (k, v) => {
    const l = v ? [-12, 12, 12, 10, -6, 10, -2, -18, 8, 18, -22, 6] : [-12, 12, 12, 10, -6, 10, -2, -18, 8];
    for (let i = 0; i < l.length; i += 3) { X.beginPath(); X.arc(l[i], l[i + 1], l[i + 2], 0, TAU); X.fillStyle = 'rgba(220,245,255,.28)'; X.fill(); X.lineWidth = 2.5; X.strokeStyle = '#e8f8ff'; X.stroke(); C(l[i] - l[i + 2] * 0.35, l[i + 1] - l[i + 2] * 0.35, l[i + 2] * 0.25, '#fff', true); }
  });
  def('jelly', 46, { col: [7, 6, 5, 2], vn: 2 }, (k, v) => {
    const n = v ? 5 : 3;
    for (let i = 0; i < n; i++) { const x = -16 + i * 32 / (n - 1); Qd(x, 4, x + (i % 2 ? 10 : -10), 22, x, 42, 4, sh(k, 0.25), true); }
    X.beginPath(); X.arc(0, 2, 27, Math.PI, 0); X.quadraticCurveTo(14, 12, 0, 6); X.quadraticCurveTo(-14, 12, -27, 2); X.closePath(); F(k);
    E(-10, -10, 7, 5, 'rgba(255,255,255,.5)', -0.4, true); eye(-7, -2, 2.3); eye(7, -2, 2.3);
  });
  def('octopus', 52, { ft: 40, col: [6, 0, 7, 1], vn: 2 }, (k, v) => {
    for (let i = 0; i < 6; i++) { const x = -20 + i * 8; const dir = x < 0 ? -1 : 1; Qd(x, 4, x + dir * 18, 30, x + dir * 26, 18 + (i % 2) * 18, 7, k, true); }
    E(0, -14, 26, 28, k);
    if (v) { C(-10, -26, 4, sh(k, 0.35), true); C(8, -32, 3, sh(k, 0.35), true); C(14, -18, 3.5, sh(k, 0.35), true); }
    eye(-8, -10, 4); eye(8, -10, 4); X.beginPath(); X.arc(0, -2, 5, 0.3, Math.PI - 0.3); ink();
  });
  def('chest', 58, { ft: 40, vn: 2 }, (k, v) => {
    if (v) {
      P([-46, -10, 46, -10, 40, -50, -40, -50], '#a86d38'); RR(-40, -46, 80, 8, 2, '#7a4f2c', true);
      blob([-24, -12, 9, -8, -16, 10, 10, -12, 9, 26, -14, 8], GOLD); C(-4, -22, 5, '#fff3b0', true);
    }
    RR(-44, -10, 88, 48, 4, WOOD);
    if (!v) { X.beginPath(); X.moveTo(-46, -10); X.lineTo(-46, -24); X.quadraticCurveTo(0, -46, 46, -24); X.lineTo(46, -10); X.closePath(); F('#a86d38'); }
    RR(-34, -10, 8, 48, 1, GOLD); RR(26, -10, 8, 48, 1, GOLD); RR(-7, -6, 14, 16, 2, GOLD);
  });
  def('rock', 52, { ft: 30, vn: 2 }, (k, v) => {
    P([-44, 28, -38, -4, -14, -26, 16, -24, 40, -2, 46, 28], '#8f909c'); P([-30, 26, -22, 4, 4, -6, 22, 10, 28, 26], '#a9aab5', true);
    if (v) P([20, 30, 26, 10, 42, 6, 50, 30], '#7c7d89');
  });
  def('turtle', 54, { ft: 30, col: [3, 4, 8], asym: true }, (k) => {
    E(-20, 18, 9, 6, '#8fd18a'); E(18, 18, 9, 6, '#8fd18a'); P([-34, 6, -46, 4, -34, 12], '#8fd18a');
    C(38, -2, 11, '#8fd18a'); eye(42, -5, 2.5);
    X.beginPath(); X.ellipse(0, 4, 36, 26, 0, Math.PI, 0); X.closePath(); F(k);
    S([-18, 4, -12, -14, 12, -14, 18, 4], 2.5, sh(k, -0.35)); S([-12, -14, -4, -24], 2.5, sh(k, -0.35)); S([12, -14, 4, -24], 2.5, sh(k, -0.35));
  });

  /* camping */
  def('tent', 120, { ft: 70, col: [1, 0, 3, 5, 2], vn: 2 }, (k, v) => {
    P([-100, 70, 0, -92, 100, 70], k); P([0, -92, 100, 70, 60, 70], sh(k, -0.15));
    if (!v) { P([-30, 70, 0, -12, 30, 70], sh(k, -0.3)); S([0, -12, 0, 70], 2.5, OL); }
    else { P([-34, 70, 0, -16, 34, 70], '#2b2233'); P([-34, 70, 0, -16, -48, 70], sh(k, 0.15)); }
    S([0, -92, 0, -110], 4, OL);
  });
  def('fire', 42, { ft: 24, vn: 2 }, (k, v) => {
    RR(-30, 14, 60, 12, 6, '#8a5a32'); X.save(); X.rotate(0.35); RR(-30, 8, 60, 12, 6, '#7a4f2c'); X.restore();
    const fl = v ? [[-14, 16, 13, 32], [14, 16, 13, 32], [0, 16, 15, 44]] : [[-8, 16, 14, 34], [10, 16, 13, 28]];
    fl.forEach((f) => { P([f[0] - f[2], f[1], f[0], f[1] - f[3], f[0] + f[2], f[1]], '#f28a2e'); P([f[0] - f[2] * 0.5, f[1], f[0], f[1] - f[3] * 0.55, f[0] + f[2] * 0.5, f[1]], GOLD, true); });
  });
  def('mushroom', 32, { ft: 28, col: [0, 8, 1], vn: 2 }, (k, v) => {
    RR(-8, -2, 16, 30, 6, '#f3e6cf');
    X.beginPath(); X.arc(0, 2, 27, Math.PI, 0); X.closePath(); F(k);
    if (!v) { C(-12, -8, 4.5, WHITE, true); C(6, -16, 4, WHITE, true); C(13, -4, 3.5, WHITE, true); }
  });
  def('log', 52, { ft: 22, asym: true }, () => {
    RR(-48, -18, 90, 36, 18, WOOD); S([-30, -8, -6, -8], 2.5, '#6b4423'); S([-20, 6, 10, 6], 2.5, '#6b4423');
    E(42, 0, 10, 18, '#d7a86e'); X.beginPath(); X.ellipse(42, 0, 5, 10, 0, 0, TAU); X.lineWidth = 2; X.strokeStyle = '#8a5a32'; X.stroke();
  });
  def('backpack', 40, { ft: 36, col: [0, 5, 3, 1, 6], vn: 2 }, (k, v) => {
    X.beginPath(); X.arc(0, -32, 9, Math.PI, 0); X.lineWidth = 4 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 4; X.strokeStyle = sh(k, -0.25); X.stroke();
    RR(-24, -30, 48, 64, 14, k); RR(-24, -30, 48, 24, 12, sh(k, -0.15));
    if (v) RR(-14, 6, 28, 20, 6, sh(k, 0.18));
    RR(-4, -12, 8, 8, 2, GOLD);
  });
  def('lantern', 38, { ft: 34, col: [0, 3, 5, 11], vn: 2 }, (k, v) => {
    if (!v) glow(0, 2, 38, 'rgba(255,226,122,.6)');
    X.beginPath(); X.arc(0, -26, 8, Math.PI, 0); X.lineWidth = 3; X.strokeStyle = OL; X.stroke();
    P([-14, -18, 14, -18, 10, -26, -10, -26], k);
    RR(-13, -18, 26, 36, 6, v ? '#5a5466' : '#ffe27a');
    RR(-16, 18, 32, 8, 2, k);
  });
  def('rabbit', 38, { ft: 32, col: [9, 10, 8], vn: 2, asym: true }, (k, v) => {
    C(-24, 14, 6, '#fff');
    E(8, -30, 4.5, 14, k);
    if (v) E(24, -22, 4.5, 14, k, 1.2); else E(17, -31, 4.5, 14, k, 0.25);
    E(-4, 14, 20, 18, k); C(12, -6, 13, k); eye(17, -8, 2.4); C(24, -3, 2.2, PAL[7], true);
  });
  def('butterfly', 32, { ft: 60, col: [5, 1, 7, 2, 6], vn: 2 }, (k, v) => {
    E(-12, -8, 13, 10, k, -0.5); E(12, -8, 13, 10, k, 0.5); E(-10, 9, 9, 7, sh(k, -0.15), 0.4); E(10, 9, 9, 7, sh(k, -0.15), -0.4);
    if (v) { C(-14, -9, 3.5, WHITE, true); C(14, -9, 3.5, WHITE, true); }
    E(0, 0, 3.5, 14, OL, 0, true); S([0, -12, -6, -22], 2, OL); S([0, -12, 6, -22], 2, OL);
  });
  def('sign', 46, { ft: 44, asym: true }, () => {
    RR(-5, -14, 10, 58, 2, '#8a5a32');
    P([-30, -36, 22, -36, 36, -24, 22, -12, -30, -12], WOOD2); S([-20, -24, 14, -24], 2.5, '#8a5a32');
  });

  /* space */
  def('planet', 62, { col: [1, 5, 6, 0, 4, 2], vn: 2 }, (k, v) => {
    if (v) { X.beginPath(); X.ellipse(0, 0, 58, 14, -0.3, Math.PI, TAU); X.lineWidth = 7 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 7; X.strokeStyle = '#e8d9b5'; X.stroke(); }
    C(0, 0, 34, k);
    clipDo(() => X.arc(0, 0, 34, 0, TAU), () => { X.fillStyle = sh(k, -0.2); X.fillRect(-40, 4, 80, 9); X.fillRect(-40, -18, 80, 6); });
    X.beginPath(); X.arc(0, 0, 34, 0, TAU); ink();
    if (v) { X.beginPath(); X.ellipse(0, 0, 58, 14, -0.3, 0, Math.PI); X.lineWidth = 7 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 7; X.strokeStyle = '#e8d9b5'; X.stroke(); }
  });
  def('rocket', 62, { col: [0, 5, 3, 6], asym: true }, (k) => {
    X.save(); X.rotate(0.6);
    P([-6, 40, 0, 62, 6, 40], '#f5a524'); P([-16, 22, -28, 44, -12, 38], k); P([16, 22, 28, 44, 12, 38], k);
    E(0, 0, 17, 42, WHITE); clipDo(() => X.ellipse(0, 0, 17, 42, 0, 0, TAU), () => { X.fillStyle = k; X.fillRect(-20, -44, 40, 20); });
    X.beginPath(); X.ellipse(0, 0, 17, 42, 0, 0, TAU); ink(); C(0, -6, 7, '#9fd3f0');
    X.restore();
  });
  def('astro', 46, { col: [2, 1, 5], asym: true }, (k) => {
    SO([14, 4, 32, -16], 10, WHITE); SO([-14, 6, -22, 24], 10, WHITE);
    RR(-14, 26, 11, 16, 4, WHITE); RR(3, 26, 11, 16, 4, WHITE);
    RR(-18, -2, 36, 36, 12, WHITE); RR(-8, 8, 16, 10, 2, '#d8d3e0');
    C(0, -20, 18, WHITE); E(3, -20, 12, 9, k); E(0, -23, 4, 2.5, 'rgba(255,255,255,.7)', 0, true);
  });
  def('sat', 52, { asym: true }, () => {
    RR(-52, -10, 34, 20, 2, '#3d7ee6'); S([-41, -10, -41, 10], 1.5, '#cfe2ff'); S([-30, -10, -30, 10], 1.5, '#cfe2ff');
    S([-18, 0, -12, 0], 3, OL);
    RR(-12, -13, 24, 26, 3, '#c9ccd6');
    X.beginPath(); X.arc(24, 0, 14, -1.9, 1.9); X.closePath(); F('#e3e5ec'); S([24, 0, 40, -10], 2.5, OL); C(40, -10, 3, PAL[0]);
  });
  def('ufo', 52, { col: [3, 7, 4, 2], vn: 2 }, (k, v) => {
    X.beginPath(); X.arc(0, -4, 20, Math.PI, 0); X.closePath(); X.fillStyle = sh(k, 0.35); X.fill(); ink();
    E(0, 6, 46, 14, '#c9ccd6'); E(0, 3, 30, 5, sh(k, -0.1), 0, true);
    const n = v ? 5 : 3; for (let i = 0; i < n; i++) C(-30 + i * 60 / (n - 1), 10, 3.5, GOLD);
  });
  def('comet', 52, { col: [2, 4, 9], asym: true }, (k) => {
    const g = X.createLinearGradient(24, -16, -46, 26); g.addColorStop(0, k); g.addColorStop(1, 'rgba(255,255,255,0)');
    X.beginPath(); X.moveTo(18, -28); X.lineTo(-48, 26); X.lineTo(30, -6); X.closePath(); X.fillStyle = g; X.fill();
    C(24, -16, 13, '#fffbe6'); C(20, -20, 4, '#fff', true);
  });
  def('moon', 42, { col: [2, 9], asym: true }, (k) => {
    X.beginPath(); X.arc(0, 0, 34, -Math.PI / 2, Math.PI / 2, false); X.arc(-42.2, 0, 54.2, 0.678, -0.678, true); X.closePath(); F(k);
    C(20, -10, 4, sh(k, -0.15), true); C(22, 12, 3, sh(k, -0.15), true);
  });
  def('alien', 42, { ft: 38, col: [3, 6, 7, 4], vn: 2 }, (k, v) => {
    S([-8, -26, -14, -40], 2.5, OL); S([8, -26, 14, -40], 2.5, OL); C(-14, -40, 4, GOLD); C(14, -40, 4, GOLD);
    SO([-18, 8, -30, 0], 5, k); SO([18, 8, 30, 0], 5, k);
    E(0, 6, 22, 30, k);
    if (!v) { C(0, -6, 10, '#fff'); C(1, -5, 4.5, OL, true); }
    else { C(-10, -4, 6, '#fff'); C(10, -4, 6, '#fff'); C(0, -16, 6, '#fff'); C(-9, -3, 2.5, OL, true); C(11, -3, 2.5, OL, true); C(1, -15, 2.5, OL, true); }
    X.beginPath(); X.arc(0, 12, 6, 0.2, Math.PI - 0.2); ink();
  });
  def('asteroid', 44, {}, () => {
    P([-36, 6, -28, -22, -4, -34, 24, -26, 38, -2, 28, 26, 0, 34, -26, 26], '#8a8496');
    C(-10, -10, 7, '#6f6a7b'); C(14, 8, 5, '#6f6a7b'); C(-14, 16, 4, '#6f6a7b');
  });

  /* market */
  def('stall', 195, { ft: 92, col: [0, 5, 3, 1, 6] }, (k) => {
    RR(-140, -150, 10, 240, 2, '#8a5a32'); RR(130, -150, 10, 240, 2, '#8a5a32');
    for (let i = 0; i < 6; i++) { const x = -160 + i * 320 / 6; P([x, -175, x + 320 / 6, -175, x + 320 / 6, -128, x, -128], i % 2 ? WHITE : k); X.beginPath(); X.arc(x + 160 / 6, -128, 160 / 6, 0, Math.PI); F(i % 2 ? WHITE : k); }
    RR(-150, 12, 300, 80, 4, '#b5793f'); RR(-158, 6, 316, 14, 3, '#d4a064');
    S([-120, 50, 120, 50], 2.5, '#8a5a32');
  });
  def('crate', 52, { ft: 38, col: [0, 1, 2, 3], vn: 2 }, (k, v) => {
    const fr = v ? [-14, 14] : [-30, -10, 10, 30];
    fr.forEach((x) => { C(x, -14, 11, k); C(x - 3, -18, 3, 'rgba(255,255,255,.5)', true); });
    RR(-44, -10, 88, 48, 4, WOOD2); S([-44, 6, 44, 6], 2.5, '#8a5a32'); S([-44, 22, 44, 22], 2.5, '#8a5a32');
  });
  def('banana', 36, { ft: 18, col: [2, 3], asym: true }, (k) => {
    for (let i = 0; i < 3; i++) { X.beginPath(); X.moveTo(-28, -10 + i * 7); X.quadraticCurveTo(-2, 30 + i * 4, 28, -4 + i * 6); X.quadraticCurveTo(-2, 14 + i * 4, -28, -10 + i * 7); X.closePath(); F(i === 1 ? sh(k, -0.08) : k); }
    RR(-34, -16, 10, 12, 3, '#6b4423');
  });
  def('melon', 46, { ft: 32, vn: 2 }, (k, v) => {
    if (!v) { E(0, 0, 40, 32, '#3c9a45'); for (let i = -2; i <= 2; i++) { X.beginPath(); X.ellipse(0, 0, Math.abs(i) * 12 + 3, 31, 0, -1.3, 1.3); X.lineWidth = 4; X.strokeStyle = '#1f6b2a'; X.stroke(); } }
    else { X.beginPath(); X.arc(0, -6, 40, 0, Math.PI); X.closePath(); F('#3c9a45'); X.beginPath(); X.arc(0, -6, 34, 0, Math.PI); X.closePath(); F('#f05a5a'); for (let i = 0; i < 5; i++) E(-20 + i * 10, 6 + (i % 2) * 8, 2, 3.5, OL, 0, true); }
  });
  def('carrot', 36, { ft: 14, col: [1, 6], asym: true }, (k) => {
    E(24, -10, 10, 4, GREEN, -0.9); E(28, -2, 10, 4, GREEN, 0.2); E(22, -16, 9, 4, DGREEN, -1.5);
    P([-32, 12, 20, -12, 24, 0], k); S([-10, 0, -4, 6], 2, sh(k, -0.3)); S([4, -4, 8, 2], 2, sh(k, -0.3));
  });
  def('basket', 42, { ft: 30, col: [8, 2], vn: 2 }, (k, v) => {
    X.beginPath(); X.arc(0, -4, 26, Math.PI, 0); X.lineWidth = 5 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 5; X.strokeStyle = sh(k, -0.2); X.stroke();
    if (v) { E(-10, -6, 16, 9, '#d9a25b', -0.3); E(12, -8, 15, 9, '#e0b06b', 0.3); }
    P([-38, -4, 38, -4, 30, 30, -30, 30], k);
    for (let i = 0; i < 3; i++) S([-34 + i * 2, 6 + i * 8, 34 - i * 2, 6 + i * 8], 2, sh(k, -0.3));
  });
  def('pricetag', 34, { ft: 32, vn: 3, tx: 1 }, (k, v) => {
    RR(-3, -2, 6, 34, 2, '#8a5a32'); RR(-30, -30, 60, 30, 5, WHITE);
    X.fillStyle = PAL[0]; X.font = '700 19px "IBM Plex Mono",monospace'; X.textAlign = 'center'; X.textBaseline = 'middle'; X.fillText(['500', '800', '300'][v], 0, -14);
  });
  def('umbrella', 90, { ft: 86, col: [0, 5, 3, 2, 7], vn: 2 }, (k, v) => {
    RR(-3, -40, 6, 126, 2, '#e3e1e8');
    X.beginPath(); X.moveTo(-86, -30); X.quadraticCurveTo(0, -112, 86, -30); X.closePath(); F(k);
    if (!v) clipDo(() => { X.moveTo(-86, -30); X.quadraticCurveTo(0, -112, 86, -30); X.closePath(); }, () => { X.fillStyle = WHITE; for (let i = 0; i < 3; i++) { X.beginPath(); X.moveTo(0, -80); X.lineTo(-62 + i * 52, -24); X.lineTo(-40 + i * 52, -24); X.closePath(); X.fill(); } });
    X.beginPath(); X.moveTo(-86, -30); X.quadraticCurveTo(0, -112, 86, -30); X.closePath(); ink();
    C(0, -80, 4, k);
  });

  /* amusement park */
  def('ferris', 190, { ft: 176, col: [0, 5, 6, 7, 4], vn: 2 }, (k, v) => {
    SO([0, -40, -92, 176], 8, '#cfd3dd'); SO([0, -40, 92, 176], 8, '#cfd3dd');
    X.beginPath(); X.arc(0, -40, 128, 0, TAU); X.lineWidth = 6 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 6; X.strokeStyle = '#e8eaf2'; X.stroke();
    const n = v ? 8 : 6;
    for (let i = 0; i < n; i++) { const a = i / n * TAU; S([0, -40, Math.cos(a) * 128, -40 + Math.sin(a) * 128], 3, '#cfd3dd'); }
    for (let i = 0; i < n; i++) { const a = i / n * TAU, x = Math.cos(a) * 128, y = -40 + Math.sin(a) * 128; RR(x - 13, y, 26, 22, 6, i % 2 ? k : sh(k, 0.35)); }
    C(0, -40, 12, GOLD);
  });
  def('icecream', 44, { ft: 40, col: [7, 9, 8, 3], vn: 2 }, (k, v) => {
    P([-15, 0, 15, 0, 0, 40], '#d9a25b'); S([-8, 6, 4, 26], 1.5, '#a8743a'); S([8, 6, -4, 26], 1.5, '#a8743a');
    if (v) C(0, -30, 14, PAL[(PAL.indexOf(k) + 3) % 8]);
    C(0, -8, 17, k); C(0, v ? -46 : -26, 4, PAL[0]);
  });
  def('cotton', 44, { ft: 40, col: [7, 5, 9] }, (k) => {
    S([0, 0, 0, 40], 3.5, '#d7c3a1'); blob([-10, -18, 15, 10, -20, 15, 0, -32, 13, -2, -8, 14], k);
  });
  def('flag', 44, { ft: 42, col: [0, 5, 2, 3, 6], asym: true }, (k) => {
    S([-14, 42, -14, -40], 3.5 + LWv * 2, OL); S([-14, 42, -14, -40], 3.5, '#d8d3e0');
    P([-12, -40, 32, -27, -12, -12], k); C(-14, -42, 3.5, GOLD);
  });
  def('popcorn', 40, { ft: 36, col: [0, 5], vn: 2 }, (k, v) => {
    const pc = v ? [-10, -18, 10, 8, -20, 10, 0, -26, 9] : [-16, -16, 10, 0, -22, 11, 16, -16, 10, -6, -32, 9, 10, -30, 9];
    blob(pc, '#fff6d8');
    P([-24, -12, 24, -12, 18, 36, -18, 36], WHITE);
    clipDo(() => { X.moveTo(-24, -12); X.lineTo(24, -12); X.lineTo(18, 36); X.lineTo(-18, 36); X.closePath(); }, () => { X.fillStyle = k; for (let i = 0; i < 3; i++) X.fillRect(-22 + i * 16, -14, 8, 52); });
    P([-24, -12, 24, -12, 18, 36, -18, 36], 'rgba(0,0,0,0)');
  });
  def('booth', 95, { ft: 88, col: [0, 5, 3, 6] }, (k) => {
    RR(-60, -30, 120, 118, 4, '#f3e6cf'); RR(-40, -14, 80, 46, 4, '#8fd0f5'); RR(-62, 30, 124, 12, 3, WOOD2);
    P([-78, -30, 0, -88, 78, -30], k); P([-26, -30, 0, -88, 26, -30], WHITE);
    RR(-24, 50, 48, 22, 3, GOLD); X.fillStyle = OL; X.font = '700 16px "IBM Plex Sans KR",sans-serif'; X.textAlign = 'center'; X.textBaseline = 'middle'; X.fillText('표', 0, 62);
  });
  def('bench', 62, { ft: 26, col: [8, 3, 0, 5] }, (k) => {
    RR(-50, 6, 8, 22, 2, '#3b3542'); RR(42, 6, 8, 22, 2, '#3b3542');
    RR(-58, -26, 116, 12, 3, k); RR(-58, -10, 116, 12, 3, k); RR(-60, 4, 120, 10, 3, sh(k, -0.12));
  });

  /* kitchen */
  def('pot', 52, { ft: 34, col: [0, 5, 10, 3], vn: 2 }, (k, v) => {
    RR(-46, -10, 14, 8, 3, sh(k, -0.2)); RR(32, -10, 14, 8, 3, sh(k, -0.2));
    RR(-36, -16, 72, 50, 9, k); E(-20, 8, 6, 14, 'rgba(255,255,255,.3)', 0, true);
    if (!v) { E(0, -17, 39, 8, sh(k, 0.12)); RR(-7, -30, 14, 9, 4, OL); }
    else { E(0, -16, 35, 7, '#7a3b22'); Qd(-10, -26, -18, -38, -8, -50, 3, '#d8d3e0'); Qd(10, -26, 2, -38, 12, -50, 3, '#d8d3e0'); }
  });
  def('pan', 54, { ft: 14, col: [11, 0, 5], vn: 2, asym: true }, (k, v) => {
    RR(22, -4, 34, 9, 4, '#3b3542'); RR(-46, -8, 70, 20, 9, k);
    if (v) { E(-12, -12, 18, 6, '#fff'); C(-10, -14, 5, GOLD); }
  });
  def('kettle', 46, { ft: 40, col: [0, 5, 9, 2, 3], asym: true }, (k) => {
    X.beginPath(); X.arc(0, -16, 18, Math.PI * 1.05, -0.05 * Math.PI); X.lineWidth = 5 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 5; X.strokeStyle = '#3b3542'; X.stroke();
    P([22, 6, 44, -16, 48, -12, 28, 22], k);
    X.beginPath(); X.moveTo(-30, 40); X.lineTo(30, 40); X.quadraticCurveTo(34, -10, 0, -12); X.quadraticCurveTo(-34, -10, -30, 40); X.closePath(); F(k);
    RR(-8, -18, 16, 7, 3, sh(k, -0.25)); E(-14, 14, 5, 12, 'rgba(255,255,255,.35)', 0, true);
  });
  def('plates', 42, { ft: 20, col: [5, 4, 0], vn: 2 }, (k, v) => {
    const n = v ? 3 : 2;
    for (let i = 0; i < n; i++) { const y = 12 - i * 10; E(0, y, 38, 8, WHITE); X.beginPath(); X.ellipse(0, y, 30, 5.5, 0, 0, TAU); X.lineWidth = 2.5; X.strokeStyle = k; X.stroke(); }
  });
  def('jar', 38, { ft: 34, col: [0, 3, 1, 5], vn: 2 }, (k, v) => {
    RR(-22, -18, 44, 52, 10, 'rgba(225,242,255,.7)');
    if (!v) { C(-8, 20, 7, '#b5793f'); C(8, 18, 7, '#c58a4a'); C(0, 4, 7, '#b5793f'); }
    else RR(-19, 6, 38, 25, 8, '#c92f4a', true);
    RR(-24, -28, 48, 12, 3, k); E(-12, 0, 3, 10, 'rgba(255,255,255,.6)', 0, true);
  });
  def('bread', 44, { ft: 22, vn: 2 }, (k, v) => {
    E(0, 0, 40, 22, '#d9a25b'); E(0, -6, 34, 12, '#e8b876', 0, true);
    const n = v ? 3 : 2; for (let i = 0; i < n; i++) { const x = -((n - 1) * 14) / 2 + i * 14; S([x - 5, 6, x + 5, -10], 3, '#a8743a'); }
  });

  /* winter */
  def('house', 130, { ft: 92, col: [0, 5, 3, 2, 8], vn: 2 }, (k, v) => {
    RR(40, -86, 20, 40, 2, '#9b5b44');
    RR(-80, -20, 160, 112, 2, k);
    P([-102, -14, 0, -96, 102, -14], '#7a3b2e'); P([-102, -14, -84, -2, 0, -70, 84, -2, 102, -14, 0, -96], '#f8fbff');
    RR(-18, 34, 36, 58, 4, '#6b4423'); C(10, 64, 3, GOLD, true);
    const wc = v ? '#4b5a8a' : '#ffd96a';
    RR(-66, 4, 34, 30, 3, wc); RR(32, 4, 34, 30, 3, wc); S([-49, 4, -49, 34], 2.5, WHITE); S([49, 4, 49, 34], 2.5, WHITE);
  });
  def('snowman', 72, { ft: 58, col: [0, 5, 3, 6, 2], vn: 2, asym: true }, (k, v) => {
    SO([-18, -8, -40, -22], 3, '#7a4f2c'); SO([18, -8, 40, -24], 3, '#7a4f2c');
    C(0, 30, 28, '#fbfbff'); C(0, -8, 21, '#fbfbff'); C(0, -38, 15, '#fbfbff');
    RR(-15, -26, 30, 8, 4, k); RR(4, -26, 8, 22, 3, k);
    C(-5, -42, 2.4, OL, true); C(6, -42, 2.4, OL, true); P([2, -37, 22, -34, 2, -32], '#f28a2e');
    C(0, -6, 2.6, OL, true); C(0, 4, 2.6, OL, true);
    if (!v) { RR(-17, -54, 34, 6, 2, '#2b2a33'); RR(-11, -72, 22, 20, 2, '#2b2a33'); RR(-11, -60, 22, 4, 0, PAL[0], true); }
  });
  def('sled', 50, { ft: 22, col: [0, 5, 8, 3], asym: true }, (k) => {
    X.beginPath(); X.moveTo(-44, 18); X.lineTo(34, 18); X.quadraticCurveTo(50, 18, 46, 2); X.lineWidth = 4 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 4; X.strokeStyle = '#c9ccd6'; X.stroke();
    S([-30, 6, -30, 18], 3, OL); S([20, 6, 20, 18], 3, OL);
    RR(-44, -8, 82, 14, 4, k); RR(-40, -20, 74, 12, 4, sh(k, 0.12));
  });
  def('flake', 28, {}, () => {
    for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, c = Math.cos(a), s = Math.sin(a); SO([0, 0, c * 24, s * 24], 3, '#f4f9ff'); }
    for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, c = Math.cos(a), s = Math.sin(a); S([c * 14 - s * 6, s * 14 + c * 6, c * 18, s * 18, c * 14 + s * 6, s * 14 - c * 6], 2.5, '#f4f9ff'); }
    C(0, 0, 4, '#f4f9ff');
  });
  def('lamppost', 92, { ft: 90, vn: 2 }, (k, v) => {
    if (!v) glow(0, -62, 70, 'rgba(255,226,122,.55)');
    RR(-5, -50, 10, 138, 2, '#3b3542'); RR(-14, 80, 28, 10, 3, '#3b3542');
    P([-16, -50, 16, -50, 12, -76, -12, -76], v ? '#5a5466' : '#ffe27a'); P([-20, -76, 20, -76, 0, -90], '#3b3542');
  });
  def('mitten', 32, { ft: 30, col: [0, 5, 3, 6, 7], asym: true }, (k) => {
    E(14, -4, 7, 12, k, 0.5); RR(-16, -26, 28, 44, 13, k); RR(-18, 14, 32, 14, 4, WHITE);
    S([-10, -6, 6, -6], 2.5, sh(k, 0.35));
  });
  def('penguin', 42, { ft: 38, col: [0, 5, 3, 2], asym: true }, (k) => {
    E(-10, 38, 9, 4, '#f5a524'); E(10, 38, 9, 4, '#f5a524');
    E(0, 4, 24, 34, '#2b2a33'); E(2, 10, 16, 26, WHITE, 0, true);
    E(22, 0, 6, 16, '#2b2a33', -0.6); eye(4, -18, 3); eye(14, -18, 3); P([10, -12, 26, -10, 10, -6], '#f5a524');
    RR(-20, -6, 40, 8, 4, k);
  });

  /* beach */
  def('palm', 150, { ft: 145, asym: true }, () => {
    for (let i = 0; i < 8; i++) { const t = i / 8; RR(-12 + t * 34 - 1, 140 - i * 34 - 20, 26 - t * 6, 30, 6, i % 2 ? '#b5793f' : '#a26a36'); }
    const lv = [[34, -120, -60, -104], [34, -120, 120, -94], [34, -120, -10, -150], [34, -120, 96, -150], [34, -120, -44, -70], [34, -120, 110, -60]];
    lv.forEach((l) => { const mx = (l[0] + l[2]) / 2, my = (l[1] + l[3]) / 2 - 18; X.beginPath(); X.moveTo(l[0], l[1]); X.quadraticCurveTo(mx, my - 14, l[2], l[3]); X.quadraticCurveTo(mx, my + 12, l[0], l[1]); X.closePath(); F('#3f9a45'); });
    C(28, -112, 8, '#7a4f2c'); C(42, -110, 8, '#7a4f2c');
  });
  def('towel', 120, { ft: 0, col: [0, 5, 6, 3, 7] }, (k) => {
    RR(-110, -26, 220, 52, 6, k); for (let i = 0; i < 3; i++) RR(-80 + i * 60, -26, 22, 52, 0, WHITE, true);
    X.beginPath(); rrp(-110, -26, 220, 52, 6); ink();
  });
  def('bucket', 38, { ft: 30, col: [0, 5, 2, 3, 7], vn: 2 }, (k, v) => {
    if (v) { RR(6, -46, 6, 30, 2, '#8a5a32'); P([2, -46, 16, -46, 18, -60, 0, -60], GOLD); }
    X.beginPath(); X.arc(0, -12, 24, Math.PI, 0); X.lineWidth = 3; X.strokeStyle = OL; X.stroke();
    P([-24, -12, 24, -12, 18, 30, -18, 30], k); RR(-26, -16, 52, 8, 3, sh(k, 0.2));
  });
  def('castle', 62, { ft: 40, vn: 2 }, (k, v) => {
    const sand = '#e6c27a', tw = v ? [-38, 0, 38] : [-30, 30];
    RR(-50, 0, 100, 40, 3, sand);
    tw.forEach((x) => { RR(x - 13, -30, 26, 40, 2, sand); for (let i = 0; i < 3; i++) RR(x - 13 + i * 10, -38, 6, 9, 1, sand); });
    RR(-9, 18, 18, 22, 8, '#b08a4a'); S([0, -34, 0, -58], 2.5, OL); P([0, -58, 18, -52, 0, -46], PAL[0]);
  });
  def('boat', 70, { ft: 30, col: [0, 5, 2, 9], asym: true }, (k) => {
    S([-4, 14, -4, -62], 4, '#7a4f2c');
    P([0, -60, 0, 6, 46, 6], WHITE); P([-8, -54, -8, 6, -44, 6], k);
    P([-56, 14, 58, 14, 40, 34, -44, 34], '#a86d38'); S([-50, 22, 52, 22], 2.5, '#7a4f2c');
  });

  /* farm */
  def('barn', 160, { ft: 112, col: [0, 8], vn: 2 }, (k, v) => {
    RR(-110, -30, 220, 142, 2, k); P([-124, -24, -70, -100, 70, -100, 124, -24], sh(k, -0.25)); P([-70, -100, 70, -100, 50, -86, -50, -86], WHITE, true);
    RR(-26, -76, 52, 36, 3, WHITE); RR(-20, -70, 40, 24, 2, '#3b2a24', true);
    if (!v) { RR(-46, 22, 92, 90, 2, WHITE); S([-46, 22, 46, 112], 5, WHITE); RR(-40, 28, 80, 78, 1, k, true); S([-40, 28, 40, 106], 6, WHITE); S([40, 28, -40, 106], 6, WHITE); X.beginPath(); rrp(-46, 22, 92, 90, 2); ink(); }
    else { RR(-46, 22, 92, 90, 2, '#2b2233'); RR(-80, 22, 34, 90, 2, k); RR(46, 22, 34, 90, 2, k); }
  });
  def('chicken', 34, { ft: 32, col: [9, 8, 1], asym: true }, (k) => {
    S([-4, 18, -6, 32], 3, '#f5a524'); S([6, 18, 8, 32], 3, '#f5a524');
    P([-30, -6, -18, -16, -14, 6], sh(k, -0.1)); E(-2, 6, 22, 16, k); C(14, -10, 11, k);
    P([10, -21, 14, -27, 18, -21], PAL[0]); P([24, -12, 32, -9, 24, -6], '#f5a524'); E(22, -2, 3, 5, PAL[0], 0, true); eye(16, -12, 2.2);
    E(-4, 6, 11, 7, sh(k, -0.12), -0.3);
  });
  def('pig', 42, { ft: 30, vn: 2, asym: true }, (k, v) => {
    const pk = '#f4a7b9';
    RR(-20, 14, 8, 16, 3, pk); RR(10, 14, 8, 16, 3, pk); Qd(-34, -2, -44, -10, -40, 4, 3, OL);
    E(-4, 2, 32, 22, pk);
    if (v) { E(-14, 10, 8, 5, '#9b6332', 0.3, true); E(4, -8, 6, 4, '#9b6332', 0, true); }
    C(24, -6, 15, pk); P([16, -18, 22, -30, 28, -18], pk); E(36, -2, 6, 7, '#f283a0'); C(35, -4, 1.5, OL, true); C(37, 0, 1.5, OL, true); eye(26, -10, 2.4);
  });
  def('sheep', 46, { ft: 36, asym: true }, () => {
    RR(-22, 16, 7, 20, 3, '#3b3542'); RR(12, 16, 7, 20, 3, '#3b3542');
    blob([-24, 0, 16, -6, -10, 18, 14, -2, 17, -8, 12, 18, 8, 10, 15], '#fbfbff');
    E(30, -8, 12, 15, '#3b3542'); E(22, -18, 8, 4, '#3b3542', -0.4); eye(34, -12, 2.3, true);
  });
  def('cow', 58, { ft: 44, col: [11, 8], vn: 2, asym: true }, (k, v) => {
    RR(-36, 18, 9, 26, 3, '#f6f2ea'); RR(22, 18, 9, 26, 3, '#f6f2ea'); Qd(-44, -10, -54, 4, -50, 20, 3, OL);
    RR(-46, -24, 84, 50, 18, '#fbfbff');
    E(-22, -8, 12, 9, k, 0.3, true); E(8, 6, 10, 8, k, -0.2, true);
    X.beginPath(); rrp(-46, -24, 84, 50, 18); ink();
    if (v) { S([40, -2, 40, 12], 2, OL); C(40, 16, 6, GOLD); }
    RR(30, -34, 30, 34, 12, '#fbfbff'); E(48, -8, 12, 8, '#f4a7b9'); P([32, -34, 28, -46, 38, -36], '#e6dccb'); eye(42, -22, 2.6);
  });
  def('hay', 40, { ft: 30, vn: 2 }, (k, v) => {
    if (!v) { RR(-36, -24, 72, 52, 5, '#e8c45a'); S([-36, -6, 36, -6], 2, '#b8932f'); S([-36, 10, 36, 10], 2, '#b8932f'); S([-12, -24, -12, 28], 3, '#a8743a'); S([12, -24, 12, 28], 3, '#a8743a'); }
    else { C(0, 0, 30, '#e8c45a'); X.beginPath(); X.arc(0, 0, 20, 0, 5.5); X.lineWidth = 2; X.strokeStyle = '#b8932f'; X.stroke(); X.beginPath(); X.arc(0, 0, 10, 0, 5.5); X.stroke(); }
  });

  /* ---------- round 12: more things (pn = patterns, cn = [min,max] count, tx = text detail, rt = may tilt, hot = prop diff spot) ---------- */
  const SKIN = '#f3c9a0', METAL = '#8f909c', DARK = '#3b3542';
  function signType(name, words, cols) {
    def(name, 70, { ft: 26, col: cols || [0, 5, 3, 6, 8], vn: words.length, tx: 1, rt: 1 }, (k, v) => {
      RR(-66, -27, 132, 54, 10, k); RR(-59, -20, 118, 40, 7, sh(k, -0.18), true);
      TX(words[v], 0, 1, 30, '#fffaf0');
    });
  }
  signType('libsign', ['쉿!', '조용히', '책 읽기', '도서관']);
  signType('flowsign', ['꽃', '새싹', '화분', '선물']);
  signType('bakesign', ['빵', '갓 구움', '쿠키', '케이크']);
  signType('shopsign', ['카페', '빵집', '꽃집', '책방']);

  /* space station */
  def('porthole', 92, { ft: 0, vn: 3, hot: [0, 0, 70] }, (k, v) => {
    C(0, 0, 86, '#9aa3b5'); C(0, 0, 70, '#0e1430');
    clipDo(() => X.arc(0, 0, 70, 0, TAU), () => {
      X.fillStyle = 'rgba(255,255,255,.8)'; for (let i = 0; i < 16; i++) { X.beginPath(); X.arc(((i * 53) % 130) - 65, ((i * 37) % 130) - 65, 1.8, 0, TAU); X.fill(); }
      if (v === 0) { C(26, 32, 54, '#3d7ee6'); blob([8, 14, 18, 30, 30, 14, 2, 44, 10], '#4caf50'); }
      else if (v === 1) { C(-12, -6, 38, '#d8d3e0'); C(-24, -16, 9, '#b9b3c6', true); C(0, 8, 7, '#b9b3c6', true); C(-26, 12, 6, '#b9b3c6', true); }
      else { X.beginPath(); X.ellipse(0, 0, 54, 13, -0.3, 0, TAU); X.lineWidth = 7; X.strokeStyle = '#e8d9b5'; X.stroke(); C(0, 0, 26, '#f28a2e'); }
    });
    X.beginPath(); X.arc(0, 0, 70, 0, TAU); ink();
    for (let i = 0; i < 8; i++) { const a = i / 8 * TAU + 0.2; C(Math.cos(a) * 78, Math.sin(a) * 78, 3.5, '#6d7486', true); }
    E(-30, -36, 18, 7, 'rgba(255,255,255,.18)', -0.7, true);
  });
  def('wrench', 46, { col: [10, 0, 5, 2], rt: 1, asym: true }, (k) => {
    X.save(); X.rotate(0.75);
    P([-6, 30, 6, 30, 6, -24, 15, -32, 11, -44, 5, -38, -5, -38, -11, -44, -15, -32, -6, -24], k);
    C(0, 32, 11, k); C(0, 32, 4.5, '#2b2233', true);
    X.restore();
  });
  def('screen', 50, { ft: 30, vn: 4, tx: 1, rt: 1 }, (k, v) => {
    RR(-44, -31, 88, 62, 7, DARK); RR(-36, -24, 72, 46, 4, '#163447');
    TX(['12', '47', '08', '93'][v], 0, -1, 32, '#7fe3c1', 1);
  });
  def('pouch', 36, { col: [0, 3, 1, 5, 6], vn: 2, rt: 1 }, (k, v) => {
    S([6, -22, 10, -34], 3, '#e3e1e8');
    RR(-17, -22, 34, 46, 7, k);
    if (v) RR(-17, -4, 34, 12, 0, WHITE, true);
    X.beginPath(); rrp(-17, -22, 34, 46, 7); ink();
  });
  def('helmet', 40, { col: [5, 2, 1, 4], vn: 2 }, (k, v) => {
    if (v) { S([-20, -22, -28, -38], 3, OL); C(-28, -38, 4.5, PAL[0]); }
    C(0, 0, 33, WHITE); E(4, 2, 22, 17, sh(k, -0.3)); E(-4, -4, 7, 5, 'rgba(255,255,255,.6)', -0.4, true);
    RR(-26, 22, 52, 10, 4, '#c9ccd6');
  });
  def('panel', 54, { ft: 26, cn: [3, 6], rt: 1 }, (k, v, o) => {
    RR(-50, -28, 100, 56, 6, '#5a6273'); RR(-44, -22, 88, 26, 4, '#2f3542');
    const n = o.n || 4, cs = [PAL[0], PAL[3], GOLD, PAL[5], PAL[1], PAL[7]];
    for (let i = 0; i < n; i++) C(-34 + i * 68 / Math.max(1, n - 1), -9, 7, cs[i]);
    RR(-32, 10, 24, 11, 3, METAL); RR(8, 10, 24, 11, 3, METAL);
  });

  /* classroom */
  def('chalkboard', 205, { ft: 96, vn: 4, tx: 1, hot: [0, -16, 120] }, (k, v) => {
    RR(-196, -96, 392, 184, 6, '#8a5a32'); RR(-184, -84, 368, 160, 3, '#2f5d4a');
    X.fillStyle = 'rgba(255,255,255,.06)'; X.fillRect(-170, -70, 120, 40); X.fillRect(40, 30, 110, 30);
    TX(['1 + 2 = 3', '가 나 다 라', '5 × 2 = 10', '안녕하세요'][v], 0, -16, 44, '#f4f1e6');
    S([-150, 42, -60, 42], 4, '#f4f1e6');
    RR(-190, 84, 380, 10, 3, '#a86d38'); RR(100, 74, 26, 8, 2, WHITE, true); RR(134, 74, 20, 8, 2, GOLD, true);
  });
  def('desk', 112, { ft: 70, col: [8, 5, 3, 10] }, (k) => {
    RR(-92, -6, 8, 76, 2, '#5a5466'); RR(84, -6, 8, 76, 2, '#5a5466');
    RR(-80, 4, 160, 34, 3, sh(k, -0.1));
    RR(-104, -16, 208, 16, 4, '#d4a064');
  });
  def('globe', 44, { ft: 40, col: [5, 4] }, (k) => {
    RR(-16, 32, 32, 8, 3, '#8a5a32'); S([0, 22, 0, 32], 5, '#8a5a32');
    C(0, -6, 28, k);
    clipDo(() => X.arc(0, -6, 28, 0, TAU), () => { blob([-12, -16, 10, -2, -10, 8, 14, 4, 9, 6, 10, 6], '#5cb85c'); });
    X.beginPath(); X.arc(0, -6, 28, 0, TAU); ink();
    RG(0, -6, 35, 4, '#c9a447', -2.4, 0.75);
  });
  def('pencils', 40, { ft: 30, col: [5, 0, 3, 6], cn: [2, 5] }, (k, v, o) => {
    const n = o.n || 3, cs = [PAL[0], GOLD, PAL[5], PAL[3], PAL[6]];
    for (let i = 0; i < n; i++) { const x = n === 1 ? 0 : -13 + i * 26 / (n - 1); X.save(); X.translate(x, -2); X.rotate(x / 45); RR(-4, -32, 8, 32, 1, cs[i]); P([-4, -32, 4, -32, 0, -40], '#f3e6cf'); X.restore(); }
    RR(-18, -6, 36, 36, 5, k);
  });
  def('calendar', 46, { vn: 5, tx: 1, rt: 1 }, (k, v) => {
    RR(-32, -30, 64, 62, 5, WHITE); RR(-32, -30, 64, 17, 5, PAL[0]);
    TX(['3', '7', '12', '25', '9'][v], 0, 10, 32, OL, 1);
    C(-16, -30, 4, METAL); C(16, -30, 4, METAL);
  });
  def('trophy', 42, { ft: 36, col: [2, 10, 8], vn: 2 }, (k, v) => {
    RR(-20, 26, 40, 10, 2, '#6b4423'); RR(-5, 6, 10, 22, 2, k);
    if (!v) { RG(-24, -14, 10, 5, k); RG(24, -14, 10, 5, k); }
    X.beginPath(); X.moveTo(-24, -32); X.lineTo(24, -32); X.quadraticCurveTo(24, 10, 0, 10); X.quadraticCurveTo(-24, 10, -24, -32); X.closePath(); F(k);
    starP(0, -14, 5, 9, 4, WHITE);
  });
  def('plane2', 40, { asym: true, rt: 1 }, () => {
    P([-36, 8, 36, -8, -22, -18], WHITE); P([-36, 8, 36, -8, -14, 6], '#dfe3ec'); P([-14, 6, 36, -8, -10, 16], '#c9ccd6');
  });
  def('chair', 58, { ft: 52, col: [0, 5, 3, 1, 8], asym: true }, (k) => {
    RR(-30, -54, 9, 106, 3, '#5a5466'); RR(22, 0, 8, 52, 3, '#5a5466');
    RR(-34, -54, 18, 46, 5, k); RR(-34, -8, 68, 12, 4, k);
  });

  /* jungle */
  def('monkey', 46, { ft: 40, vn: 2, asym: true }, (k, v) => {
    const b = '#8a5a32', f = '#e9c08f';
    Qd(-14, 26, -44, 30, -38, 2, 6, b, true);
    E(-2, 16, 18, 22, b); E(0, 20, 10, 14, f, 0, true);
    C(-20, -20, 8, b); C(20, -20, 8, b); C(-20, -20, 4, f, true); C(20, -20, 4, f, true);
    C(0, -18, 18, b); E(0, -12, 13, 10, f); E(-6, -24, 5, 6, f, 0, true); E(6, -24, 5, 6, f, 0, true);
    eye(-5, -23, 2.4); eye(5, -23, 2.4); X.beginPath(); X.arc(0, -11, 5, 0.3, Math.PI - 0.3); ink();
    if (v) { X.save(); X.translate(24, 8); X.rotate(-0.5); X.beginPath(); X.moveTo(-6, -15); X.quadraticCurveTo(12, 0, -6, 15); X.quadraticCurveTo(3, 0, -6, -15); X.closePath(); F(GOLD); X.restore(); }
  });
  def('parrot', 42, { ft: 36, col: [0, 5, 3, 2], asym: true }, (k) => {
    SO([-30, 32, 30, 32], 5, '#7a4f2c');
    P([-8, 16, -18, 40, 0, 22], sh(k, -0.2));
    E(-2, 4, 14, 22, k); E(-6, 8, 8, 14, k === PAL[5] ? GOLD : PAL[5], -0.2);
    C(4, -16, 12, k); E(6, -14, 6, 5, WHITE, 0, true); C(8, -18, 2.4, OL, true);
    P([14, -22, 26, -16, 20, -8, 14, -10], '#f3e6cf');
  });
  def('frog', 34, { ft: 18, col: [3, 4, 2, 7], vn: 2 }, (k, v) => {
    E(-18, 14, 12, 6, sh(k, -0.15)); E(18, 14, 12, 6, sh(k, -0.15));
    E(0, 4, 26, 16, k); C(-11, -12, 8, k); C(11, -12, 8, k);
    C(-11, -12, 4, '#fff', true); C(11, -12, 4, '#fff', true); C(-11, -12, 2, OL, true); C(11, -12, 2, OL, true);
    X.beginPath(); X.arc(0, 2, 12, 0.3, Math.PI - 0.3); ink();
    if (v) { C(-12, 8, 3.5, sh(k, -0.3), true); C(10, 12, 3.5, sh(k, -0.3), true); C(16, 2, 3, sh(k, -0.3), true); }
  });
  def('snake', 58, { ft: 14, col: [3, 2, 0, 6, 4], vn: 2, asym: true }, (k, v) => {
    X.beginPath(); X.moveTo(-46, 8); X.bezierCurveTo(-30, -14, -12, 22, 4, 4); X.bezierCurveTo(16, -10, 28, -6, 34, -12);
    X.lineCap = 'round'; X.lineWidth = 13 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 13; X.strokeStyle = k; X.stroke();
    if (v) { const pts = [-40, 1, -27, 0, -13, 7, 2, 5, 16, -5]; for (let i = 0; i < pts.length; i += 2) C(pts[i], pts[i + 1], 3.4, sh(k, -0.4), true); }
    E(38, -14, 13, 10, k, -0.3); eye(42, -18, 2.4); S([50, -12, 56, -10], 2, PAL[0]);
  });
  def('fern', 54, { ft: 32, col: [3, 4] }, (k) => {
    const lv = [[-0.95, 54], [-0.48, 60], [0, 64], [0.48, 60], [0.95, 54]];
    lv.forEach((q, i) => { X.save(); X.translate(0, 30); X.rotate(q[0]); E(0, -q[1] / 2 - 2, 11, q[1] / 2, i % 2 ? sh(k, 0.12) : k); S([0, -4, 0, -q[1]], 2, sh(k, -0.3)); X.restore(); });
  });
  def('hibiscus', 34, { col: [0, 7, 1, 2, 6] }, (k) => {
    for (let i = 0; i < 5; i++) { const a = i / 5 * TAU - Math.PI / 2; E(Math.cos(a) * 14, Math.sin(a) * 14, 14, 10, k, a); }
    C(0, 0, 7, sh(k, -0.3)); S([0, 0, 10, -14], 2.5, GOLD); C(10, -14, 3, GOLD, true);
  });
  def('toucan', 46, { ft: 36, col: [1, 2, 0], asym: true }, (k) => {
    SO([-30, 34, 26, 34], 5, '#7a4f2c');
    P([-14, 18, -22, 38, -6, 22], '#2b2a33');
    E(-4, 6, 14, 24, '#2b2a33'); E(2, -4, 8, 10, '#fbf3d8', 0, true);
    C(2, -18, 12, '#2b2a33'); C(4, -20, 3.5, '#ffe27a', true); C(4, -20, 1.6, OL, true);
    P([10, -24, 42, -16, 12, -10], k); S([14, -17, 38, -16], 2, sh(k, -0.3));
  });

  /* dinosaurs */
  def('dlong', 112, { ft: 70, col: [3, 4, 8, 1, 6], vn: 2, asym: true }, (k, v) => {
    const d = sh(k, -0.18);
    RR(-46, 20, 16, 50, 6, d); RR(18, 20, 16, 50, 6, d);
    Qd(-50, 10, -78, 24, -94, 42, 13, k, true);
    Qd(28, -4, 52, -30, 58, -70, 16, k, true);
    E(-6, 6, 58, 34, k);
    RR(-36, 24, 16, 46, 6, k); RR(30, 22, 16, 48, 6, k);
    E(68, -76, 19, 12, k, 0.2); eye(74, -80, 2.8);
    if (v) { C(-20, -8, 7, sh(k, 0.3), true); C(4, -14, 6, sh(k, 0.3), true); C(20, 6, 6, sh(k, 0.3), true); C(-36, 10, 5, sh(k, 0.3), true); }
  });
  def('trex', 82, { ft: 72, col: [3, 0, 1, 6, 4], vn: 2, asym: true }, (k, v) => {
    const d = sh(k, -0.18);
    Qd(-14, 14, -50, 34, -72, 56, 15, k, true);
    RR(-14, 30, 14, 42, 5, d); RR(10, 30, 14, 42, 5, k);
    E(0, 10, 30, 34, k, -0.3);
    SO([22, 2, 32, 12], 4, k);
    if (v) { X.save(); X.translate(16, -40); X.rotate(0.4); RR(0, 0, 46, 13, 5, k); for (let i = 0; i < 4; i++) P([8 + i * 9, 0, 12 + i * 9, -6, 16 + i * 9, 0], WHITE, true); X.restore(); }
    else RR(14, -42, 48, 14, 6, k);
    SO([4, -12, 22, -44], 20, k);
    RR(6, -68, 60, 32, 13, k); eye(42, -56, 3.2);
    if (v) for (let i = 0; i < 4; i++) P([24 + i * 9, -36, 28 + i * 9, -30, 32 + i * 9, -36], WHITE, true);
  });
  def('trice', 72, { ft: 42, col: [1, 4, 8, 6, 2], asym: true }, (k) => {
    const d = sh(k, -0.18);
    P([-40, 0, -68, 20, -38, 16], k);
    RR(-34, 14, 14, 28, 5, d); RR(16, 14, 14, 28, 5, d);
    E(-4, 4, 40, 26, k);
    RR(-26, 16, 14, 26, 5, k); RR(24, 16, 14, 26, 5, k);
    E(38, -12, 22, 26, sh(k, 0.18), -0.5);
    E(48, 0, 18, 14, k);
    P([48, -8, 70, -24, 56, -2], WHITE); P([60, 2, 72, 4, 62, 8], WHITE);
    eye(52, -4, 2.6);
  });
  def('ptero', 52, { col: [1, 8, 6, 4, 0], asym: true }, (k) => {
    P([-6, 0, -50, -24, -30, 8], sh(k, -0.12)); P([6, 0, 48, -28, 30, 10], k);
    E(0, 2, 13, 9, k); P([4, -6, -14, -18, 2, -2], k); P([8, -4, 36, -6, 10, 4], GOLD); eye(8, -2, 2);
  });
  def('nest', 46, { ft: 18, cn: [2, 5] }, (k, v, o) => {
    const n = o.n || 3;
    for (let i = 0; i < n; i++) { const x = -((n - 1) * 15) / 2 + i * 15; E(x, -8, 10, 13, '#f6f2ea'); C(x - 3, -12, 2.2, '#c9b9a0', true); }
    E(0, 8, 42, 12, '#9b6332'); S([-36, 6, 36, 10], 2, '#6b4423'); S([-30, 13, 30, 9], 2, '#6b4423');
  });

  /* castle hall */
  def('throne', 132, { ft: 110, col: [0, 6, 5, 3] }, (k) => {
    RR(-70, -110, 140, 150, 20, GOLD); RR(-54, -94, 108, 120, 14, k);
    RR(-80, 56, 18, 54, 4, GOLD); RR(62, 56, 18, 54, 4, GOLD);
    RR(-82, 20, 164, 40, 8, GOLD); RR(-66, 14, 132, 26, 8, sh(k, 0.15));
    starP(0, -112, 5, 18, 8, GOLD);
  });
  def('shield', 42, { col: [0, 5, 3, 6, 2], pn: 4, vn: 2, rt: 1 }, (k, v, o) => {
    pfill(() => { X.moveTo(-28, -34); X.lineTo(28, -34); X.lineTo(28, 0); X.quadraticCurveTo(26, 26, 0, 38); X.quadraticCurveTo(-26, 26, -28, 0); X.closePath(); }, k, o.p);
    if (v) starP(0, -2, 5, 13, 5.5, GOLD); else C(0, -2, 10, GOLD);
  });
  def('sword', 54, { rt: 1 }, () => {
    P([-6, -20, 6, -20, 6, 38, 0, 50, -6, 38], '#dfe3ec'); S([0, -16, 0, 38], 1.5, '#9aa3b5');
    RR(-20, -30, 40, 9, 3, GOLD); RR(-4, -48, 8, 20, 3, '#6b4423'); C(0, -51, 5.5, GOLD);
  });
  def('torch', 48, { ft: 42, vn: 2 }, (k, v) => {
    if (!v) glow(0, -24, 48, 'rgba(255,200,90,.55)');
    P([-8, -6, 8, -6, 4, 40, -4, 40], '#6b4423'); RR(-12, -12, 24, 10, 3, '#5a5466');
    if (!v) { P([-13, -12, 0, -46, 13, -12], '#f28a2e'); P([-6, -12, 0, -30, 6, -12], GOLD, true); }
    else { Qd(-2, -16, 8, -26, 0, -38, 3, '#cfcbd8'); }
  });
  def('armor', 82, { ft: 76, col: [10, 2, 9], vn: 2 }, (k, v) => {
    const d = sh(k, -0.2);
    RR(-20, 24, 16, 50, 4, d); RR(4, 24, 16, 50, 4, d); RR(-24, 68, 22, 9, 3, DARK); RR(2, 68, 22, 9, 3, DARK);
    RR(-40, -24, 14, 42, 6, d); RR(26, -24, 14, 42, 6, d);
    RR(-28, -26, 56, 56, 12, k);
    if (!v) Qd(0, -62, 14, -84, 30, -76, 8, PAL[0], true);
    C(0, -44, 20, k); RR(-14, -48, 28, 6, 2, '#2b2233', true);
  });
  def('crown', 46, { ft: 18, col: [2, 10], cn: [3, 5] }, (k, v, o) => {
    const n = o.n || 3, w = 38, st = 2 * w / n, a = [-w, 18, -w, -2];
    for (let i = 0; i < n; i++) { const x = -w + st * (i + 0.5); a.push(x, -30, -w + st * (i + 1), -2); }
    a.push(w, 18);
    P(a, k);
    for (let i = 0; i < n; i++) C(-w + st * (i + 0.5), -30, 5, PAL[0]);
    RR(-w, 2, 2 * w, 8, 2, sh(k, -0.2), true); C(0, 6, 3.5, PAL[5], true);
  });
  def('goblet', 34, { ft: 30, col: [2, 10, 0] }, (k) => {
    RR(-14, 24, 28, 6, 3, k); RR(-3, 4, 6, 22, 2, k);
    X.beginPath(); X.moveTo(-18, -28); X.lineTo(18, -28); X.quadraticCurveTo(18, 6, 0, 6); X.quadraticCurveTo(-18, 6, -18, -28); X.closePath(); F(k);
    C(0, -12, 4.5, PAL[0]);
  });
  def('candles', 46, { ft: 40, cn: [2, 5] }, (k, v, o) => {
    const n = o.n || 3;
    RR(-18, 34, 36, 7, 3, GOLD); SO([0, 34, 0, 8], 5, GOLD); SO([-32, 6, 32, 6], 4, GOLD);
    for (let i = 0; i < n; i++) { const x = -32 + i * 64 / (n - 1); RR(x - 5, -18, 10, 24, 2, WHITE); P([x - 5, -18, x, -34, x + 5, -18], '#f28a2e'); }
  });
  def('banner', 58, { col: [0, 5, 6, 3], pn: 4, vn: 2 }, (k, v, o) => {
    SO([-32, -50, 32, -50], 5, '#7a4f2c');
    pfill(() => { X.moveTo(-24, -48); X.lineTo(24, -48); X.lineTo(24, 48); X.lineTo(0, 34); X.lineTo(-24, 48); X.closePath(); }, k, o.p);
    if (v) starP(0, -12, 5, 14, 6, GOLD); else { C(0, -12, 12, GOLD); C(0, -12, 5, k, true); }
  });
  def('barrel', 42, { ft: 38, vn: 2 }, (k, v) => {
    X.beginPath(); X.moveTo(-26, -36); X.quadraticCurveTo(-36, 0, -26, 36); X.lineTo(26, 36); X.quadraticCurveTo(36, 0, 26, -36); X.closePath(); F('#a86d38');
    S([-31, -18, 31, -18], 4, '#5a5466'); S([-31, 18, 31, 18], 4, '#5a5466'); E(0, -36, 26, 6, '#c58a4a');
    if (v) { RR(-7, -2, 14, 9, 2, '#5a5466'); RR(-3, 6, 6, 8, 1, '#5a5466'); }
  });

  /* library */
  def('bookcase', 175, { ft: 160, col: [8, 11, 6] }, (k) => {
    RR(-110, -160, 220, 320, 6, k === PAL[8] ? '#7a4f2c' : sh(k, -0.1)); RR(-98, -148, 196, 296, 3, '#4a2f1e', true);
    for (let s = 0; s < 4; s++) {
      const y = -148 + s * 74; let x = -94, i = s * 7;
      while (x < 86) { const w = Math.min(10 + ((i * 7) % 4) * 3, 94 - x), hh = 44 + ((i * 5) % 4) * 6; RR(x, y + 70 - hh, w, hh, 2, PAL[(i * 3) % 8]); x += w + 2; i++; }
      RR(-98, y + 70, 196, 6, 1, '#a86d38', true);
    }
  });
  def('table', 160, { ft: 70, col: [8, 11] }, (k) => {
    RR(-130, -10, 14, 80, 3, '#7a4f2c'); RR(116, -10, 14, 80, 3, '#7a4f2c'); RR(-150, -22, 300, 18, 4, '#a86d38');
  });
  def('openbook', 42, { ft: 10, vn: 2, col: [0, 5, 3, 6] }, (k, v) => {
    P([-42, 8, -40, -16, 0, -12, 40, -16, 42, 8, 0, 12], k);
    P([-38, 4, -36, -20, -2, -16, -2, 8], WHITE); P([38, 4, 36, -20, 2, -16, 2, 8], WHITE);
    if (!v) { for (let i = 0; i < 4; i++) { S([-32, -13 + i * 5, -8, -11 + i * 5], 1.8, METAL); S([8, -11 + i * 5, 32, -13 + i * 5], 1.8, METAL); } }
    else { C(-20, -6, 8, PAL[0]); P([8, 3, 20, -15, 32, 3], PAL[3]); }
  });
  def('hourglass', 38, { ft: 36, vn: 2 }, (k, v) => {
    const path = () => { X.moveTo(-17, -28); X.lineTo(17, -28); X.lineTo(3, 0); X.lineTo(17, 28); X.lineTo(-17, 28); X.lineTo(-3, 0); X.closePath(); };
    X.beginPath(); path(); Fn('rgba(220,240,255,.8)');
    if (!v) { P([-14, -25, 14, -25, 2, -3, -2, -3], GOLD, true); P([-7, 28, 7, 28, 0, 20], GOLD, true); }
    else { P([-15, 28, 15, 28, 3, 4, -3, 4], GOLD, true); P([-5, -5, 5, -5, 0, -1], GOLD, true); }
    X.beginPath(); path(); ink();
    RR(-23, -36, 46, 9, 3, WOOD); RR(-23, 27, 46, 9, 3, WOOD);
  });
  def('magnifier', 42, { asym: true, rt: 1, col: [0, 5, 11] }, (k) => {
    SO([10, 10, 32, 32], 9, k);
    C(-6, -6, 22, '#cfe8f5'); E(-12, -12, 8, 5, 'rgba(255,255,255,.75)', -0.7, true);
    RG(-6, -6, 22, 6, '#c9ccd6');
  });
  def('scroll', 40, { ft: 16, rt: 1 }, () => {
    RR(-30, -16, 60, 32, 2, '#f3e6cf'); E(-30, 0, 7, 18, '#e3d0b0'); E(30, 0, 7, 18, '#e3d0b0');
    S([-20, -6, 20, -6], 2, '#9b8b70'); S([-20, 4, 14, 4], 2, '#9b8b70');
  });

  /* subway */
  def('seats', 232, { ft: 40, col: [5, 0, 3, 6] }, (k) => {
    RR(-212, 0, 424, 40, 4, '#9aa3b5');
    RR(-220, -72, 440, 48, 10, sh(k, -0.12));
    for (let i = 1; i < 6; i++) S([-220 + i * 440 / 6, -66, -220 + i * 440 / 6, -30], 2.5, sh(k, -0.3));
    RR(-226, -28, 452, 28, 9, k);
  });
  def('person', 58, { ft: 54, col: [0, 5, 3, 6, 1, 7, 4], pn: 4, vn: 3 }, (k, v, o) => {
    RR(-13, 20, 11, 34, 4, '#3b3f5a'); RR(2, 20, 11, 34, 4, '#3b3f5a');
    SO([-20, -10, -26, 18], 8, k); SO([20, -10, 26, 18], 8, k);
    pfill(() => rrp(-20, -18, 40, 44, 11), k, o.p);
    if (v === 1) { RR(-17, -46, 34, 34, 12, '#3b2a24'); }
    C(0, -32, 14, SKIN);
    if (v === 0) { X.beginPath(); X.arc(0, -34, 15, Math.PI * 1.05, -0.05); X.closePath(); F('#3b2a24'); }
    else if (v === 1) { X.beginPath(); X.arc(0, -35, 15, Math.PI, 0); X.closePath(); F('#3b2a24'); }
    else { RR(-19, -44, 38, 7, 3, GOLD); RR(-12, -56, 24, 14, 5, GOLD); }
    C(-5, -31, 1.8, OL, true); C(5, -31, 1.8, OL, true);
  });
  def('strap', 36, { ft: -32 }, () => {
    S([0, -32, 0, 2], 4, '#8f909c'); RG(0, 14, 12, 5, GOLD);
  });
  def('routemap', 72, { ft: 0, col: [3, 0, 5, 1], cn: [4, 7] }, (k, v, o) => {
    RR(-66, -26, 132, 52, 5, WHITE); SO([-52, 6, 52, 6], 6, k);
    const n = o.n || 5; for (let i = 0; i < n; i++) C(-52 + i * 104 / (n - 1), 6, 6.5, WHITE);
    RR(-56, -18, 44, 9, 3, k, true);
  });
  def('stsign', 72, { vn: 4, tx: 1 }, (k, v) => {
    RR(-68, -26, 136, 52, 8, '#1f6b3a'); RR(-63, -21, 126, 42, 6, '#2a8a4c', true);
    TX(['꽃마을', '별빛역', '솔숲역', '달빛역'][v], 0, 1, 30, WHITE);
  });
  def('bag', 38, { ft: 30, col: [0, 1, 2, 5, 7, 3], pn: 4 }, (k, v, o) => {
    RG(0, -16, 11, 3.5, sh(k, -0.3), Math.PI, TAU);
    pfill(() => rrp(-24, -16, 48, 46, 4), k, o.p);
  });

  /* desert oasis */
  def('camel', 92, { ft: 64, vn: 2, asym: true }, (k, v) => {
    const c = '#d9a25b', d = '#b98250';
    RR(-40, 10, 10, 54, 4, d); RR(14, 10, 10, 54, 4, d);
    Qd(-44, -4, -56, 10, -52, 26, 4, c, true);
    if (v) { E(-20, -22, 16, 17, c); E(12, -22, 16, 17, c); } else E(-4, -24, 22, 21, c);
    Qd(34, -6, 54, -20, 58, -46, 13, c, true);
    E(-4, -2, 48, 22, c);
    RR(-22, 10, 10, 54, 4, c); RR(30, 10, 10, 54, 4, c);
    E(66, -50, 16, 10, c, 0.2); eye(68, -54, 2.4);
  });
  def('cactus', 54, { ft: 48, col: [3, 4], cn: [1, 3] }, (k, v, o) => {
    const n = o.n || 2, arm = (sx, y, l) => SO([0, y, sx * 24, y, sx * 24, y - l], 13, k);
    if (n >= 1) arm(-1, 8, 28);
    if (n >= 2) arm(1, -8, 26);
    if (n >= 3) arm(1, 26, 16);
    RR(-13, -46, 26, 94, 13, k); S([-4, -36, -4, 40], 2, sh(k, -0.25)); S([5, -36, 5, 40], 2, sh(k, -0.25));
  });
  def('amphora', 42, { ft: 38, col: [8, 1, 0, 4, 5], pn: 4 }, (k, v, o) => {
    RG(-16, -16, 9, 4, sh(k, -0.2), 1.4, 4.4); RG(16, -16, 9, 4, sh(k, -0.2), -1.3, 1.7);
    pfill(() => { X.moveTo(-10, -30); X.lineTo(10, -30); X.lineTo(8, -20); X.quadraticCurveTo(36, -8, 18, 34); X.lineTo(-18, 34); X.quadraticCurveTo(-36, -8, -8, -20); X.closePath(); }, k, o.p);
    RR(-13, -38, 26, 9, 3, sh(k, -0.15));
  });
  def('lizard', 46, { ft: 10, col: [3, 2, 1, 4], asym: true }, (k) => {
    Qd(-14, 0, -32, 8, -46, -4, 7, k, true);
    SO([-12, 2, -18, 12], 4, k); SO([14, 2, 20, 12], 4, k); SO([-12, -2, -18, -10], 4, k); SO([14, -2, 20, -10], 4, k);
    E(2, 0, 20, 8, k); E(26, -2, 11, 7, k); eye(30, -4, 1.9);
  });
  def('reeds', 44, { ft: 40, vn: 2 }, (k, v) => {
    const st = v ? [-16, -5, 6, 17] : [-11, 2, 14];
    st.forEach((x, i) => { const tx = x + (i % 2 ? 5 : -5), ty = -18 - (i % 2) * 10; S([x, 40, tx, ty], 3.5, '#5e8a3a'); E(tx, ty - 6, 4.5, 11, '#7a4f2c'); });
  });

  /* pirate ship */
  def('mast', 236, { ft: 220, vn: 2, hot: [0, -112, 62] }, (k, v) => {
    RR(-8, -230, 16, 450, 3, '#7a4f2c');
    X.beginPath(); X.moveTo(-120, -190); X.quadraticCurveTo(0, -160, 120, -190); X.lineTo(132, -40); X.quadraticCurveTo(0, -10, -132, -40); X.closePath(); F('#f3ead6');
    SO([-134, -196, 134, -196], 7, '#7a4f2c'); SO([-140, -40, 140, -40], 6, '#7a4f2c');
    if (!v) { C(0, -118, 26, '#2b2233'); C(-9, -122, 6, '#f3ead6', true); C(9, -122, 6, '#f3ead6', true); RR(-10, -100, 20, 10, 2, '#2b2233'); }
    else { starP(0, -112, 8, 34, 13, '#2b2233'); C(0, -112, 7, '#f3ead6', true); }
    P([8, -230, 62, -216, 8, -202], PAL[0]);
  });
  def('cannon', 60, { ft: 30, col: [11, 10, 8], asym: true }, (k) => {
    X.save(); X.translate(-6, -6); X.rotate(-0.25); RR(-40, -14, 84, 28, 12, k); RR(36, -17, 10, 34, 4, sh(k, 0.25)); X.restore();
    C(-26, 16, 14, WOOD); C(-26, 16, 4, '#5a3a22', true); C(10, 16, 14, WOOD); C(10, 16, 4, '#5a3a22', true);
  });
  def('anchor', 48, { ft: 42, col: [10, 11, 2] }, (k) => {
    RG(0, -34, 9, 5, k); SO([0, -24, 0, 36], 7, k); SO([-18, -14, 18, -14], 6, k);
    RG(0, 4, 32, 7, k, 0.35, Math.PI - 0.35);
    P([28, 14, 40, 2, 36, 24], k); P([-28, 14, -40, 2, -36, 24], k);
  });
  def('helm', 52, { ft: 48, vn: 2 }, (k, v) => {
    const n = v ? 8 : 6;
    for (let i = 0; i < n; i++) { const a = i / n * TAU, c = Math.cos(a), s = Math.sin(a); SO([c * 14, s * 14, c * 44, s * 44], 6, WOOD2); C(c * 46, s * 46, 5.5, WOOD2); }
    RG(0, 0, 32, 8, '#a86d38'); C(0, 0, 12, WOOD);
  });
  def('rope', 34, { ft: 14 }, () => {
    E(0, 4, 32, 12, '#d8b47a'); E(0, 0, 24, 9, '#c9a06a'); E(0, -3, 14, 5, '#b88f5a'); SO([14, -3, 28, -18], 4, '#d8b47a');
  });
  def('balls', 44, { ft: 18, cn: [3, 6] }, (k, v, o) => {
    const n = o.n || 3, pos = [[-24, 6], [0, 6], [24, 6], [-12, -14], [12, -14], [0, -33]];
    for (let i = 0; i < n; i++) { C(pos[i][0], pos[i][1], 12, DARK); C(pos[i][0] - 4, pos[i][1] - 4, 3, 'rgba(255,255,255,.45)', true); }
  });
  def('tmap', 46, { ft: 10, vn: 2, rt: 1 }, (k, v) => {
    P([-40, -26, 40, -30, 42, 26, -38, 30], '#ecd9a6');
    X.setLineDash([6, 6]); S([-28, 16, -10, -4, 6, 10, 24, -10], 3, '#a8743a'); X.setLineDash([]);
    const m = v ? [-26, -14] : [24, -12];
    S([m[0] - 7, m[1] - 7, m[0] + 7, m[1] + 7], 4, PAL[0]); S([m[0] + 7, m[1] - 7, m[0] - 7, m[1] + 7], 4, PAL[0]);
  });
  def('bottle', 36, { ft: 30, col: [3, 4, 8, 5], vn: 2 }, (k, v) => {
    RR(-6, -36, 12, 10, 2, '#a86d38'); RR(-15, -26, 30, 56, 10, sh(k, 0.15));
    if (v) { RR(-8, -10, 16, 28, 3, '#f3e6cf'); S([-8, -2, 8, -2], 2, '#a8743a'); }
    E(-7, -6, 3, 12, 'rgba(255,255,255,.55)', 0, true);
  });

  /* robot factory */
  def('belt', 480, { ft: 54 }, () => {
    for (const x of [-400, -150, 150, 400]) RR(x - 6, 12, 12, 42, 2, '#5a5466');
    RR(-470, -14, 940, 28, 14, DARK);
    for (let x = -450; x <= 450; x += 60) C(x, 0, 8, METAL);
  });
  def('robot', 56, { ft: 50, col: [0, 5, 3, 2, 10, 4], pn: 4, vn: 3 }, (k, v, o) => {
    RR(-20, 30, 14, 20, 3, '#5a5466'); RR(6, 30, 14, 20, 3, '#5a5466');
    SO([-26, -4, -38, 18], 6, METAL); SO([26, -4, 38, 18], 6, METAL);
    pfill(() => rrp(-26, -10, 52, 42, 8), k, o.p);
    S([0, -44, 0, -54], 3, OL); C(0, -56, 4.5, GOLD);
    RR(-20, -44, 40, 32, 8, '#c9ccd6');
    if (v === 0) { C(-8, -28, 5, '#2b2233'); C(8, -28, 5, '#2b2233'); }
    else if (v === 1) RR(-15, -32, 30, 9, 4, '#22b3a6');
    else { C(0, -28, 8.5, PAL[0]); C(2, -30, 2.5, '#fff', true); }
  });
  def('gear', 42, { col: [10, 2, 1, 5, 0], cn: [6, 10], rt: 1 }, (k, v, o) => {
    const n = o.n || 8, w = Math.PI / n * 0.55, a = [];
    for (let i = 0; i < n; i++) { const t = i / n * TAU; a.push(Math.cos(t - w * 1.3) * 28, Math.sin(t - w * 1.3) * 28, Math.cos(t - w) * 40, Math.sin(t - w) * 40, Math.cos(t + w) * 40, Math.sin(t + w) * 40, Math.cos(t + w * 1.3) * 28, Math.sin(t + w * 1.3) * 28); }
    P(a, k); C(0, 0, 11, '#2b2233'); C(0, 0, 20, 'rgba(255,255,255,.18)', true);
  });
  def('arm', 86, { ft: 80, col: [2, 1, 0, 5], asym: true }, (k) => {
    RR(-30, 64, 60, 16, 4, '#5a5466');
    SO([0, 64, -14, 0, 30, -50], 16, k); C(-14, 0, 11, '#5a5466'); C(0, 62, 10, '#5a5466');
    SO([30, -50, 52, -60, 64, -46], 6, METAL); SO([30, -50, 48, -34, 64, -32], 6, METAL); C(30, -50, 10, '#5a5466');
  });
  def('battery', 42, { ft: 32, cn: [1, 4], col: [3, 2, 0] }, (k, v, o) => {
    RR(-8, -38, 16, 8, 2, METAL); RR(-18, -32, 36, 64, 6, DARK);
    const n = o.n || 2; for (let i = 0; i < n; i++) RR(-12, 14 - i * 14, 24, 11, 2, k, true);
  });
  def('cbox', 46, { ft: 34, vn: 3 }, (k, v) => {
    RR(-38, -26, 76, 60, 3, '#c9955a'); RR(-38, -26, 76, 10, 2, '#b98250'); RR(-7, -26, 14, 22, 0, '#e3c48a', true);
    if (v === 0) { S([-20, 24, -20, 4], 3.5, OL); P([-27, 6, -20, -4, -13, 6], OL, true); S([16, 24, 16, 4], 3.5, OL); P([9, 6, 16, -4, 23, 6], OL, true); }
    else if (v === 1) { X.beginPath(); X.moveTo(-8, 2); X.lineTo(8, 2); X.quadraticCurveTo(8, 16, 0, 16); X.quadraticCurveTo(-8, 16, -8, 2); X.lineWidth = 3; X.strokeStyle = PAL[0]; X.stroke(); S([0, 16, 0, 26, -6, 26, 6, 26], 3, PAL[0]); }
  });
  def('beacon', 34, { ft: 26, col: [0, 1, 5], vn: 2 }, (k, v) => {
    if (!v) glow(0, 0, 36, 'rgba(255,170,90,.55)');
    RR(-18, 14, 36, 12, 3, DARK);
    X.beginPath(); X.arc(0, 14, 15, Math.PI, 0); X.closePath(); F(v ? sh(k, -0.4) : k);
    if (!v) E(-5, 4, 4, 6, 'rgba(255,255,255,.6)', 0, true);
  });

  /* flower shop */
  def('counter', 232, { ft: 70, col: [7, 4, 5, 3, 8] }, (k) => {
    RR(-220, -20, 440, 90, 6, k); RR(-220, 12, 440, 10, 0, sh(k, 0.22), true);
    RR(-228, -32, 456, 16, 4, '#d4a064');
  });
  def('bouquet', 48, { ft: 42, col: [0, 7, 1, 2, 6, 9], vn: 2 }, (k, v) => {
    S([-4, 0, -12, -16], 2.5, DGREEN); S([4, 0, 12, -16], 2.5, DGREEN);
    const fl = [-14, -18, 0, -30, 14, -18, -5, -8, 8, -6];
    for (let i = 0; i < fl.length; i += 2) { C(fl[i], fl[i + 1], 10, k); C(fl[i], fl[i + 1], 3.5, GOLD, true); }
    P([-22, -4, 22, -4, 6, 42, -6, 42], '#cfe8c0');
    if (v) { E(-9, 22, 8, 5, PAL[0], 0.3); E(9, 22, 8, 5, PAL[0], -0.3); C(0, 22, 4, PAL[0]); }
  });
  def('tulips', 48, { ft: 42, col: [0, 7, 2, 6, 1], cn: [2, 5] }, (k, v, o) => {
    const n = o.n || 3;
    for (let i = 0; i < n; i++) {
      const x = -18 + i * 36 / (n - 1), tx = x * 1.25;
      S([x, 10, tx, -22], 3, DGREEN);
      P([tx - 9, -34, tx - 9, -24, tx, -18, tx + 9, -24, tx + 9, -34, tx + 4, -28, tx, -36, tx - 4, -28], k);
    }
    P([-24, 6, 24, 6, 18, 42, -18, 42], '#9aa3b5'); RR(-26, 2, 52, 8, 3, '#b8bfcc');
  });
  def('wcan', 46, { ft: 30, col: [5, 3, 0, 2, 4], asym: true }, (k) => {
    SO([14, 12, 42, -18], 6, k); E(44, -20, 7, 4, sh(k, -0.2), 0.6);
    RG(-6, -12, 18, 5, sh(k, -0.2), Math.PI, TAU);
    RR(-30, -12, 48, 42, 8, k); E(-14, 6, 5, 12, 'rgba(255,255,255,.35)', 0, true);
  });
  def('succ', 34, { ft: 28, vn: 2 }, (k, v) => {
    const n = v ? 7 : 5;
    for (let i = 0; i < n; i++) { const a = -Math.PI + (i + 0.5) / n * Math.PI; E(Math.cos(a) * 12, -4 + Math.sin(a) * 12, 6, 13, i % 2 ? '#8fcf9b' : '#6fb27f', a + Math.PI / 2); }
    P([-19, 4, 19, 4, 14, 28, -14, 28], '#d9875a'); RR(-21, 0, 42, 8, 3, '#e29a6d');
  });

  /* night city */
  def('bldg', 176, { ft: 160, col: [6, 5, 11, 4], vn: 4, hot: [0, -10, 120] }, (k, v) => {
    RR(-70, -160, 140, 320, 3, sh(k, -0.5)); RR(-76, -166, 152, 12, 2, sh(k, -0.35));
    for (let r = 0; r < 8; r++) for (let c = 0; c < 3; c++) { const lit = ((r * 3 + c) * 7 + v * 5 + r * c * (v + 1)) % 3 !== 0; RR(-52 + c * 38, -140 + r * 36, 28, 22, 2, lit ? '#ffd96a' : '#2b2a40', true); }
  });
  def('car', 64, { ft: 30, col: [0, 5, 2, 3, 9, 6], vn: 2, asym: true }, (k, v) => {
    if (v) RR(-12, -42, 24, 10, 3, GOLD);
    P([-34, -6, -22, -32, 22, -32, 38, -6], k);
    P([-28, -8, -18, -27, -2, -27, -2, -8], '#9fd3f0'); P([4, -8, 4, -27, 18, -27, 30, -8], '#9fd3f0');
    RR(-60, -8, 120, 28, 10, k); E(55, 2, 4, 6, GOLD, 0, true); RR(-58, 0, 6, 8, 2, PAL[0], true);
    C(-32, 20, 12, '#2b2a33'); C(-32, 20, 4.5, '#c9ccd6', true); C(32, 20, 12, '#2b2a33'); C(32, 20, 4.5, '#c9ccd6', true);
  });
  def('tlight', 66, { ft: 62, vn: 3 }, (k, v) => {
    RR(-4, -8, 8, 70, 2, DARK); RR(-17, -62, 34, 58, 8, DARK);
    const cs = ['#e5484d', '#f6cd3b', '#4caf50'];
    for (let i = 0; i < 3; i++) { if (i === v) glow(0, -48 + i * 18, 16, 'rgba(255,240,180,.5)'); C(0, -48 + i * 18, 7, i === v ? cs[i] : '#4b4458', true); }
  });
  def('billboard', 86, { ft: 80, vn: 4, tx: 1, col: [0, 5, 6, 3] }, (k, v) => {
    RR(-6, -8, 12, 88, 2, '#5a5466');
    RR(-78, -66, 156, 62, 6, k); RR(-70, -58, 140, 46, 4, '#fbf7ee');
    TX(['24시', '세일', '맛집', '영업중'][v], 0, -34, 30, k === PAL[2] ? OL : k);
  });
  def('jet', 52, { col: [9, 0, 5], asym: true }, (k) => {
    P([-6, 0, -26, 26, -14, 26, 10, 2], '#c9ccd6'); P([-6, -4, -24, -24, -14, -24, 8, -4], '#dfe3ec');
    E(0, 0, 46, 10, k === PAL[9] ? WHITE : k); P([-40, -2, -50, -22, -34, -6], sh(k === PAL[9] ? PAL[5] : k, -0.15));
    for (let i = 0; i < 4; i++) C(-12 + i * 12, -2, 2.6, '#3d7ee6', true);
  });
  def('firework', 48, { col: [0, 2, 7, 4, 6], vn: 2 }, (k, v) => {
    const n = v ? 12 : 8;
    for (let i = 0; i < n; i++) { const a = i / n * TAU, c = Math.cos(a), s = Math.sin(a); S([c * 12, s * 12, c * 38, s * 38], 4.5, k); C(c * 43, s * 43, 4, sh(k, 0.45), true); }
    C(0, 0, 6, '#fff', true);
  });

  /* birthday */
  def('ctable', 205, { ft: 80, col: [0, 5, 7, 3] }, (k) => {
    RR(-170, 0, 14, 80, 3, '#7a4f2c'); RR(156, 0, 14, 80, 3, '#7a4f2c');
    for (let x = -186; x <= 186; x += 24) C(x, 30, 12, k);
    P([-190, -22, 190, -22, 196, 30, -196, 30], k);
    RR(-196, -26, 392, 8, 3, sh(k, 0.3));
  });
  def('cake', 60, { ft: 40, col: [7, 9, 6, 0, 4], cn: [1, 5] }, (k, v, o) => {
    const n = o.n || 3;
    E(0, 40, 58, 8, '#e3e1e8');
    for (let i = 0; i < n; i++) { const x = n === 1 ? 0 : -30 + i * 60 / (n - 1); RR(x - 4, -46, 8, 24, 2, PAL[(i * 2 + 1) % 8]); P([x - 4, -46, x, -58, x + 4, -46], '#f28a2e'); }
    RR(-50, -24, 100, 64, 10, '#f3e6cf'); RR(-50, 8, 100, 8, 0, k, true);
    RR(-52, -28, 104, 18, 8, k); for (let i = 0; i < 5; i++) C(-40 + i * 20, -10, 5, k, true);
  });
  def('phat', 40, { ft: 30, col: [0, 5, 2, 3, 6, 7], pn: 4, rt: 1 }, (k, v, o) => {
    pfill(() => { X.moveTo(0, -36); X.lineTo(25, 28); X.lineTo(-25, 28); X.closePath(); }, k, o.p);
    C(0, -38, 6.5, GOLD); E(0, 28, 27, 5, WHITE);
  });
  def('cupcake', 34, { ft: 28, col: [7, 9, 8, 5], vn: 2 }, (k, v) => {
    P([-18, 0, 18, 0, 13, 28, -13, 28], '#e9b6c9'); S([-8, 2, -6, 26], 2, '#c98aa3'); S([8, 2, 6, 26], 2, '#c98aa3');
    blob([-10, -6, 12, 10, -6, 12, 0, -16, 13], k);
    if (!v) { C(0, -31, 6.5, PAL[0]); S([0, -37, 4, -44], 2, DGREEN); }
    else { const cs = [PAL[0], PAL[5], GOLD, PAL[3]]; for (let i = 0; i < 6; i++) { X.fillStyle = cs[i % 4]; X.fillRect(-14 + i * 5.5, -14 + (i % 3) * 5 - 6, 4, 2.5); } }
  });
  def('teddy', 50, { ft: 44, col: [8, 1, 9, 7], vn: 2 }, (k, v) => {
    const lt = sh(k, 0.35);
    E(-14, 36, 10, 8, k); E(14, 36, 10, 8, k);
    E(-22, 10, 8, 14, k, 0.4); E(22, 10, 8, 14, k, -0.4);
    E(0, 16, 22, 24, k); E(0, 20, 12, 14, lt, 0, true);
    C(-14, -32, 8, k); C(14, -32, 8, k); C(0, -16, 19, k); E(0, -10, 9, 7, lt);
    eye(-7, -20, 2.5); eye(7, -20, 2.5); C(0, -12, 3, OL, true);
    if (v) { P([-12, -2, 0, 2, -12, 8], PAL[0]); P([12, -2, 0, 2, 12, 8], PAL[0]); }
  });
  def('juice', 32, { ft: 28, col: [1, 0, 6, 3, 2], vn: 2 }, (k, v) => {
    if (v) SO([4, -8, 14, -38], 3, WHITE);
    P([-15, -12, 15, -12, 12, 26, -12, 26], k, true);
    P([-17, -26, 17, -26, 12, 28, -12, 28], 'rgba(225,242,255,.35)');
  });
  def('nballoon', 50, { ft: 46, col: [0, 5, 2, 6, 7], vn: 4, tx: 1, rt: 1 }, (k, v) => {
    Qd(0, 22, -8, 34, 2, 46, 2, '#6d6474');
    E(0, -12, 30, 34, k); P([-5, 22, 5, 22, 0, 16], sh(k, -0.2));
    TX(['5', '7', '8', '9'][v], 0, -10, 40, lum(k) > 0.62 ? OL : '#fff', 1);
  });

  /* playground */
  def('slide', 140, { ft: 110, col: [0, 2, 5, 3, 1] }, (k) => {
    SO([-96, 110, -78, -60], 5, METAL); SO([-60, 110, -42, -60], 5, METAL);
    for (let i = 0; i < 6; i++) { const t = i / 6, y = 100 - t * 150; S([-94 + t * 18 + 0, y, -58 + t * 18, y], 4, METAL); }
    RR(-86, -72, 66, 12, 3, METAL);
    X.beginPath(); X.moveTo(-26, -66); X.quadraticCurveTo(40, -40, 70, 60); X.quadraticCurveTo(84, 100, 124, 100);
    X.lineWidth = 22 + LWv * 2; X.strokeStyle = OL; X.lineCap = 'round'; X.stroke(); X.lineWidth = 22; X.strokeStyle = k; X.stroke();
    X.lineWidth = 6; X.strokeStyle = sh(k, 0.3); X.stroke();
  });
  def('swing', 150, { ft: 130, col: [0, 5, 3, 2] }, (k) => {
    SO([-122, 130, -94, -118], 7, METAL); SO([-66, 130, -94, -118], 7, METAL); SO([122, 130, 94, -118], 7, METAL); SO([66, 130, 94, -118], 7, METAL);
    SO([-100, -120, 100, -120], 8, k);
    S([-52, -120, -52, 44], 2.5, '#5a5466'); S([-18, -120, -18, 44], 2.5, '#5a5466'); RR(-60, 42, 50, 9, 3, k);
    S([18, -120, 22, 40], 2.5, '#5a5466'); S([52, -120, 56, 40], 2.5, '#5a5466'); RR(14, 38, 50, 9, 3, k);
  });
  def('seesaw', 86, { ft: 30, col: [0, 5, 3, 2], asym: true }, (k) => {
    P([-16, 30, 16, 30, 0, 0], METAL);
    X.save(); X.rotate(-0.22); RR(-80, -8, 160, 12, 4, k); RR(-72, -26, 7, 18, 2, '#5a5466'); RR(64, -26, 7, 18, 2, '#5a5466'); X.restore();
  });
  def('kite', 50, { col: [0, 5, 2, 6, 3], pn: 4, rt: 1 }, (k, v, o) => {
    X.beginPath(); X.moveTo(0, 30); X.bezierCurveTo(-14, 38, 12, 42, -2, 50); X.lineWidth = 2; X.strokeStyle = '#6d6474'; X.stroke();
    P([-6, 38, 0, 36, -4, 44], PAL[0], true); P([2, 44, 8, 42, 4, 48], GOLD, true);
    pfill(() => { X.moveTo(0, -42); X.lineTo(27, -6); X.lineTo(0, 30); X.lineTo(-27, -6); X.closePath(); }, k, o.p);
    S([0, -42, 0, 30], 2, sh(k, -0.3)); S([-27, -6, 27, -6], 2, sh(k, -0.3));
  });
  def('scooter', 46, { ft: 40, col: [0, 5, 3, 7], asym: true }, (k) => {
    SO([30, 30, 22, -36], 5, k); SO([12, -36, 32, -36], 5, '#3b3542');
    RR(-34, 20, 62, 9, 4, k);
    C(-28, 34, 7, DARK); C(30, 34, 7, DARK);
  });

  /* bakery */
  def('showcase', 240, { ft: 90, col: [8, 7, 4, 5] }, (k) => {
    RR(-230, 20, 460, 70, 6, k); RR(-230, 46, 460, 8, 0, sh(k, 0.25), true);
    RR(-224, -70, 448, 92, 4, 'rgba(210,235,250,.42)'); S([-224, -24, 224, -24], 4, '#e3e1e8');
    X.fillStyle = 'rgba(255,255,255,.35)'; X.beginPath(); X.moveTo(-200, -66); X.lineTo(-170, -66); X.lineTo(-210, 16); X.lineTo(-222, 16); X.closePath(); X.fill();
  });
  def('croissant', 40, { ft: 16 }, () => {
    E(-26, 2, 11, 9, '#d9a25b', 0.6); E(26, 2, 11, 9, '#d9a25b', -0.6); E(-13, -6, 14, 13, '#e0a85e', 0.3); E(13, -6, 14, 13, '#e0a85e', -0.3); E(0, -10, 15, 15, '#e8b876');
  });
  def('donut', 34, { ft: 18, col: [7, 11, 2, 9, 1], vn: 2 }, (k, v) => {
    E(0, 0, 32, 18, '#d9a25b'); E(0, -3, 27, 13, k); E(0, -2, 9, 4.5, '#8a5a32');
    if (v) { const cs = [PAL[0], PAL[5], GOLD, PAL[3], '#fff']; for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; X.fillStyle = cs[i % 5]; X.fillRect(Math.cos(a) * 18 - 2, -3 + Math.sin(a) * 8 - 1, 5, 2.5); } }
  });
  def('baguettes', 50, { ft: 34, cn: [2, 4] }, (k, v, o) => {
    const n = o.n || 3;
    for (let i = 0; i < n; i++) { const x = -18 + i * 36 / (n - 1); X.save(); X.translate(x, -12); X.rotate((i - (n - 1) / 2) * 0.2); RR(-7, -34, 14, 52, 7, '#d9a25b'); S([-3, -24, 3, -18], 2, '#a8743a'); S([-3, -12, 3, -6], 2, '#a8743a'); X.restore(); }
    P([-34, 0, 34, 0, 26, 32, -26, 32], '#b5793f'); S([-30, 10, 30, 10], 2, '#8a5a32'); S([-28, 20, 28, 20], 2, '#8a5a32');
  });
  def('pie', 46, { ft: 16, vn: 2, col: [0, 6, 1] }, (k, v) => {
    E(0, 6, 44, 14, '#c9ccd6'); E(0, 0, 38, 12, '#d9a25b');
    if (v) { clipDo(() => X.ellipse(0, 0, 32, 9, 0, 0, TAU), () => { X.fillStyle = k; X.fillRect(-34, -10, 68, 20); X.fillStyle = '#e8b876'; for (let i = -3; i <= 3; i++) { X.fillRect(i * 10 - 2, -10, 5, 20); } X.fillRect(-34, -3, 68, 4); }); }
    else { E(0, -1, 32, 9, '#e8b876', 0, true); S([-12, -2, -4, 2], 2.5, '#a8743a'); S([4, -2, 12, 2], 2.5, '#a8743a'); }
  });
  def('slice', 38, { ft: 22, col: [7, 9, 8, 6], asym: true }, (k) => {
    P([-32, 0, 30, -14, 30, 22, -32, 22], '#f3e6cf'); P([-32, 8, 30, 2, 30, 8, -32, 14], k, true);
    P([-32, 0, 30, -14, 30, -20, -32, -6], k); C(20, -24, 7, PAL[0]);
  });

  /* halloween */
  def('pumpkin', 42, { ft: 30, vn: 3, col: [1, 3, 9] }, (k, v) => {
    RR(-4, -40, 8, 14, 3, '#5e8a3a');
    E(-18, 2, 18, 28, sh(k, -0.1)); E(18, 2, 18, 28, sh(k, -0.1)); E(0, 2, 20, 30, k);
    const fc = '#3b2a10';
    if (v === 1) { P([-16, -8, -6, -8, -11, -16], GOLD); P([6, -8, 16, -8, 11, -16], GOLD); X.beginPath(); X.moveTo(-16, 6); X.quadraticCurveTo(0, 22, 16, 6); X.quadraticCurveTo(0, 14, -16, 6); X.closePath(); F(GOLD); }
    else if (v === 2) { P([-18, -14, -6, -8, -16, -4], fc); P([18, -14, 6, -8, 16, -4], fc); P([-16, 8, -10, 4, -5, 10, 0, 4, 5, 10, 10, 4, 16, 8, 8, 16, -8, 16], fc); }
  });
  def('ghost', 42, { vn: 2, asym: true }, (k, v) => {
    P([22, 0, 38, -10, 24, 12], '#f6f6ff');
    X.beginPath(); X.moveTo(-24, 30); X.lineTo(-24, -8); X.arc(0, -8, 24, Math.PI, 0); X.lineTo(24, 30);
    X.quadraticCurveTo(20, 22, 16, 30); X.quadraticCurveTo(12, 38, 8, 30); X.quadraticCurveTo(4, 22, 0, 30); X.quadraticCurveTo(-4, 38, -8, 30); X.quadraticCurveTo(-12, 22, -16, 30); X.quadraticCurveTo(-20, 38, -24, 30); X.closePath(); F('#f6f6ff');
    E(-8, -10, 4, 6, OL, 0, true); E(8, -10, 4, 6, OL, 0, true);
    if (v) { E(0, 6, 6, 8, OL, 0, true); E(0, 10, 4, 4, '#f483b6', 0, true); } else E(0, 4, 4, 3, OL, 0, true);
  });
  def('bat', 42, {}, (k, v) => {
    P([0, -4, -16, -14, -42, -10, -32, 0, -38, 10, -22, 6, -12, 12, 0, 4, 12, 12, 22, 6, 38, 10, 32, 0, 42, -10, 16, -14], '#2a2238');
    C(0, -6, 10, '#2a2238'); P([-8, -12, -6, -22, -2, -14], '#2a2238'); P([8, -12, 6, -22, 2, -14], '#2a2238');
    const ec = v ? PAL[0] : GOLD; C(-4, -7, 2.6, ec, true); C(4, -7, 2.6, ec, true);
  });
  def('what', 42, { ft: 22, col: [6, 3, 0, 1], asym: true }, (k) => {
    E(0, 16, 40, 9, '#2a2238'); P([-22, 14, 22, 14, 10, -16, 26, -36, 4, -24], '#2a2238');
    RR(-22, 4, 44, 10, 2, k); RR(-5, 4, 10, 10, 1, GOLD, true);
  });
  def('candy', 32, { col: [0, 5, 3, 6, 7, 2], pn: 3, rt: 1 }, (k, v, o) => {
    P([-12, 0, -30, -12, -30, 12], sh(k, 0.2)); P([12, 0, 30, -12, 30, 12], sh(k, 0.2));
    pfill(() => X.ellipse(0, 0, 16, 12, 0, 0, TAU), k, o.p);
  });
  def('grave', 48, { ft: 42, vn: 3 }, (k, v) => {
    X.beginPath(); X.moveTo(-26, 42); X.lineTo(-26, -14); X.arc(0, -14, 26, Math.PI, 0); X.lineTo(26, 42); X.closePath(); F('#9aa0ad');
    if (v === 0) { S([0, -30, 0, 8], 5, '#6f7584'); S([-11, -18, 11, -18], 5, '#6f7584'); }
    else if (v === 1) S([-6, -38, 4, -18, -6, -2, 4, 16], 3, '#5b6170');
    else { S([-14, -16, 14, -16], 4, '#6f7584'); S([-14, -4, 14, -4], 4, '#6f7584'); S([-14, 8, 6, 8], 4, '#6f7584'); }
    S([-30, 42, 30, 42], 5, '#3f6b3a');
  });
  def('web', 50, { vn: 2 }, (k, v) => {
    X.strokeStyle = '#e8e6f0'; X.lineWidth = 2.5;
    for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; X.beginPath(); X.moveTo(0, 0); X.lineTo(Math.cos(a) * 44, Math.sin(a) * 44); X.stroke(); }
    for (const r of [14, 26, 38]) { X.beginPath(); for (let i = 0; i <= 8; i++) { const a = i / 8 * TAU; X[i ? 'lineTo' : 'moveTo'](Math.cos(a) * r, Math.sin(a) * r); } X.stroke(); }
    if (v) { S([0, 0, 0, 18], 2, '#e8e6f0'); for (let i = 0; i < 4; i++) { S([-6, 22 + i * 4, -18, 16 + i * 6], 2.5, '#1a1424'); S([6, 22 + i * 4, 18, 16 + i * 6], 2.5, '#1a1424'); } C(0, 28, 11, '#1a1424', true); C(-4, 24, 2, PAL[0], true); C(4, 24, 2, PAL[0], true); }
  });
  def('manor', 172, { ft: 120, vn: 2, hot: [0, -10, 110] }, (k, v) => {
    RR(60, -160, 50, 120, 2, '#3b3150'); P([52, -158, 85, -200, 118, -158], '#241d33');
    RR(-120, -60, 240, 180, 2, '#4a3f63'); P([-140, -54, 0, -150, 140, -54], '#2e2640');
    RR(-20, 50, 40, 70, 18, '#241d33');
    const L = '#ffd96a', D = '#2b2440';
    for (let r = 0; r < 2; r++) for (let c = 0; c < 4; c++) { if (c === 1 || c === 2) { if (r === 1) continue; } const lit = ((r * 4 + c) + v * 3) % 3 !== 0; RR(-100 + c * 56, -36 + r * 56, 32, 36, 3, lit ? L : D); }
    RR(73, -138, 24, 28, 3, v ? D : L);
  });

  /* gallery */
  def('painting', 90, { col: [2, 8, 11, 9], vn: 4, rt: 1 }, (k, v) => {
    RR(-72, -54, 144, 108, 4, k);
    clipDo(() => rrp(-60, -42, 120, 84, 2), () => {
      if (v === 0) { X.fillStyle = '#f6a96b'; X.fillRect(-62, -44, 124, 88); C(0, 4, 18, GOLD, true); X.fillStyle = '#3d7ee6'; X.fillRect(-62, 6, 124, 40); }
      else if (v === 1) { X.fillStyle = '#f6f2ea'; X.fillRect(-62, -44, 124, 88); C(-26, -6, 22, PAL[0]); RR(4, -32, 40, 40, 0, PAL[5]); P([-10, 42, 18, 2, 46, 42], GOLD); }
      else if (v === 2) { X.fillStyle = '#cfe8f5'; X.fillRect(-62, -44, 124, 88); P([-62, 44, -20, -22, 6, 14, 28, -8, 62, 44], '#5aa36a'); P([-28, -12, -20, -22, -12, -12], WHITE, true); }
      else { X.fillStyle = '#5b4a6e'; X.fillRect(-62, -44, 124, 88); E(0, 40, 32, 22, PAL[6]); C(0, -4, 18, SKIN); X.beginPath(); X.arc(0, -8, 19, Math.PI, 0); X.closePath(); F('#3b2a24'); }
    });
    X.beginPath(); rrp(-60, -42, 120, 84, 2); ink();
  });
  def('statue', 82, { ft: 78, col: [9, 2, 10, 4, 7], vn: 3 }, (k, v) => {
    RR(-30, 10, 60, 64, 3, '#e3e1e8'); RR(-36, 4, 72, 10, 3, '#f6f2ea'); RR(-36, 70, 72, 8, 2, '#c9ccd6');
    if (v === 0) { C(0, -26, 28, k); E(-9, -36, 8, 6, 'rgba(255,255,255,.45)', -0.5, true); }
    else if (v === 1) P([-26, 4, 0, -62, 26, 4], k);
    else RG(0, -28, 22, 12, k);
  });
  def('rope2', 80, { ft: 34, col: [0, 6, 5] }, (k) => {
    E(-67, 32, 12, 4, GOLD); E(67, 32, 12, 4, GOLD);
    RR(-72, -30, 10, 62, 3, GOLD); RR(62, -30, 10, 62, 3, GOLD);
    Qd(-67, -24, 0, 12, 67, -24, 7, k, true);
    C(-67, -32, 7, GOLD); C(67, -32, 7, GOLD);
  });

  /* toy shop */
  def('blocks', 52, { ft: 36, cn: [2, 4] }, (k, v, o) => {
    const n = o.n || 3, cs = [PAL[0], PAL[5], GOLD, PAL[3]], lt = ['가', 'A', '1', '나'];
    for (let i = 0; i < n; i++) { const y = 25 - i * 22, x = i % 2 ? 4 : -4; RR(x - 13, y - 11, 26, 22, 3, cs[i]); TX(lt[i], x, y + 1, 15, i === 2 ? OL : WHITE); }
  });
  def('duck', 36, { ft: 24, col: [2, 1, 9, 7], asym: true }, (k) => {
    P([-26, 6, -36, -8, -22, 0], k);
    E(-2, 10, 26, 14, k); E(-6, 6, 12, 7, sh(k, -0.12), -0.2, true);
    C(14, -10, 12, k); P([24, -12, 36, -8, 24, -4], '#f28a2e'); eye(16, -13, 2.4);
  });
  def('stop', 36, { ft: 30, col: [0, 5, 3, 6, 2], pn: 4 }, (k, v, o) => {
    RR(-3, -40, 6, 14, 2, '#7a4f2c');
    pfill(() => { X.moveTo(-30, -18); X.quadraticCurveTo(0, -36, 30, -18); X.lineTo(0, 30); X.closePath(); }, k, o.p);
  });
  def('drum', 40, { ft: 28, col: [0, 5, 3, 1], pn: 4 }, (k, v, o) => {
    SO([-20, -32, 4, -18], 3, WOOD2); SO([24, -34, 8, -18], 3, WOOD2);
    pfill(() => rrp(-32, -14, 64, 42, 4), k, o.p);
    E(0, -14, 32, 9, '#f6f2ea'); RR(-32, 22, 64, 6, 2, GOLD, true);
  });
  def('ttrain', 76, { ft: 26, col: [0, 5, 3, 2], cn: [1, 3], asym: true }, (k, v, o) => {
    const n = o.n || 2;
    for (let i = 0; i < n; i++) { const x = 16 - (i + 1) * 28; S([x + 24, 6, x + 30, 6], 3, OL); RR(x, -8, 24, 24, 3, PAL[(i * 2 + 5) % 8]); C(x + 6, 18, 5, DARK); C(x + 18, 18, 5, DARK); }
    RR(20, -18, 38, 34, 4, k); RR(34, -38, 24, 22, 3, sh(k, -0.15)); RR(22, -36, 10, 18, 2, DARK);
    C(28, 18, 7, DARK); C(50, 18, 7, DARK);
  });

  /* rainy street */
  def('umbr', 52, { ft: 46, col: [0, 5, 2, 3, 6, 7], pn: 3 }, (k, v, o) => {
    S([0, -24, 0, 34], 3.5, '#5a5466'); RG(-7, 34, 7, 3.5, '#5a5466', 0, Math.PI);
    pfill(() => { X.moveTo(-48, -14); X.quadraticCurveTo(0, -76, 48, -14); X.quadraticCurveTo(40, -22, 32, -14); X.quadraticCurveTo(24, -22, 16, -14); X.quadraticCurveTo(8, -22, 0, -14); X.quadraticCurveTo(-8, -22, -16, -14); X.quadraticCurveTo(-24, -22, -32, -14); X.quadraticCurveTo(-40, -22, -48, -14); X.closePath(); }, k, o.p);
    C(0, -46, 3.5, k);
  });
  def('boots', 38, { ft: 30, col: [2, 0, 5, 3, 7], vn: 2 }, (k, v) => {
    for (const ox of [-18, 14]) { P([ox - 12, -26, ox + 4, -26, ox + 4, 16, ox + 18, 18, ox + 18, 30, ox - 12, 30], k); if (v) RR(ox - 12, -26, 16, 8, 2, WHITE, true); RR(ox - 12, 24, 30, 6, 2, sh(k, -0.3), true); }
  });
  def('mailbox', 54, { ft: 50, col: [0, 5, 3], vn: 2 }, (k, v) => {
    RR(-6, 0, 12, 50, 2, '#5a5466');
    RR(-26, -38, 52, 42, 12, k); RR(-15, -26, 30, 6, 2, OL, true);
    if (v) { X.save(); X.translate(0, -26); X.rotate(-0.15); RR(-10, -16, 22, 16, 1, WHITE); S([-10, -16, 1, -8, 12, -16], 1.5, METAL); X.restore(); }
    SO([26, -32, 34, -32, 34, -46], 3, PAL[0]);
  });
  def('busstop', 86, { ft: 82, vn: 4, tx: 1 }, (k, v) => {
    RR(-4, -40, 8, 122, 2, METAL); C(0, -52, 30, '#3d7ee6'); C(0, -52, 23, WHITE);
    TX(['12', '37', '5', '61'][v], 0, -51, 26, OL, 1);
  });
  def('snail', 36, { ft: 16, col: [8, 1, 2, 7], asym: true }, (k) => {
    S([24, 2, 30, -16], 2.5, OL); S([28, 2, 38, -12], 2.5, OL); C(30, -16, 2.5, OL, true); C(38, -12, 2.5, OL, true);
    E(2, 10, 32, 7, '#c9b48a');
    C(-4, -6, 19, k); X.beginPath(); X.arc(-4, -6, 11, 0, 5); ink(); X.beginPath(); X.arc(-4, -6, 5, 0, 5); ink();
  });

  /* garden */
  def('gnome', 50, { ft: 44, col: [0, 5, 3, 6], vn: 2, asym: true }, (k, v) => {
    SO([28, 40, 32, -6], 3, WOOD); P([24, 40, 36, 40, 38, 28, 22, 28], METAL);
    RR(-16, 32, 14, 12, 4, '#6b4423'); RR(2, 32, 14, 12, 4, '#6b4423');
    RR(-18, 0, 36, 38, 10, k === PAL[3] ? PAL[5] : PAL[3]);
    if (v) P([-12, -2, 12, -2, 0, 30], WHITE); else P([-12, -2, 12, -2, 0, 12], WHITE);
    C(0, -8, 10, SKIN); C(0, -4, 3.5, '#f283a0', true);
    P([-16, -12, 16, -12, 6, -46], k);
  });
  def('bhouse', 58, { ft: 54, col: [0, 5, 3, 8, 2], vn: 2 }, (k, v) => {
    RR(-5, 0, 10, 54, 2, WOOD);
    RR(-22, -32, 44, 38, 3, k); P([-30, -30, 0, -54, 30, -30], '#7a3b2e');
    C(0, -15, 9, '#2b2233');
    if (v) { C(0, -16, 7.5, GOLD); C(2, -18, 1.8, OL, true); P([6, -16, 12, -14, 6, -12], '#f28a2e', true); }
    RR(-3, -4, 6, 4, 1, WOOD, true);
  });
  def('bee', 32, { asym: true }, () => {
    E(-6, -14, 10, 8, 'rgba(230,245,255,.9)', -0.4); E(6, -15, 10, 8, 'rgba(230,245,255,.9)', 0.4);
    P([-20, 0, -30, 0, -20, 4], OL);
    E(0, 0, 20, 13, GOLD);
    clipDo(() => X.ellipse(0, 0, 20, 13, 0, 0, TAU), () => { X.fillStyle = '#2b2233'; X.fillRect(-10, -14, 6, 28); X.fillRect(2, -14, 6, 28); });
    X.beginPath(); X.ellipse(0, 0, 20, 13, 0, 0, TAU); ink(); eye(14, -3, 2.4);
  });
  def('wbarrow', 64, { ft: 30, col: [0, 5, 3, 2], asym: true }, (k) => {
    SO([-62, -16, -12, 4], 4, '#7a4f2c'); SO([-20, 6, -24, 28], 4, '#5a5466');
    P([-32, -22, 46, -22, 32, 14, -22, 14], k); S([-26, -14, 40, -14], 2, sh(k, 0.3));
    C(30, 20, 12, DARK); C(30, 20, 4, '#c9ccd6', true);
  });
  def('ladybug', 38, { ft: 18, cn: [2, 6] }, (k, v, o) => {
    C(28, 0, 10, '#2b2233'); C(30, -4, 2, '#fff', true);
    E(0, 0, 30, 20, PAL[0]); S([0, -20, 0, 20], 2.5, OL);
    const sp = [[-12, -8], [12, -8], [-14, 8], [14, 8], [-22, 0], [22, 0]], n = o.n || 3;
    for (let i = 0; i < n; i++) C(sp[i][0], sp[i][1], 5, '#2b2233', true);
  });

  /* ======================= places (themes) ======================= */
  function grad(c0, c1, y0, y1) { const g = X.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, c0); g.addColorStop(1, c1); X.fillStyle = g; X.fillRect(0, y0, W, y1 - y0); }
  function hills(R, y, amp, col, n) { X.beginPath(); X.moveTo(0, H); X.lineTo(0, y); const seg = W / n; for (let i = 0; i < n; i++) { const x0 = i * seg; X.quadraticCurveTo(x0 + seg / 2, y - amp * (0.5 + R()), x0 + seg, y + (R() - 0.5) * amp * 0.4); } X.lineTo(W, H); X.closePath(); X.fillStyle = col; X.fill(); }
  function dots(R, n, x0, y0, x1, y1, col, r0, r1) { X.fillStyle = col; for (let i = 0; i < n; i++) { X.beginPath(); X.arc(x0 + R() * (x1 - x0), y0 + R() * (y1 - y0), r0 + R() * (r1 - r0), 0, TAU); X.fill(); } }
  const SKY = [['#8fd0f5', '#dff3ff'], ['#f6a96b', '#fde2b0'], ['#9cc7ef', '#f3e6ff']];
  const pc = (R, t) => pick(R, TY[t].col || [0]);

  const THEMES = [
    { id: 'living', name: '거실', g: 'in',
      bg(v, R) {
        const wall = ['#efe2c8', '#cfe3d6', '#d7dceb', '#f0d5d5'][v % 4];
        X.fillStyle = wall; X.fillRect(0, 0, W, 440);
        X.fillStyle = 'rgba(0,0,0,.035)'; for (let x = 0; x < W; x += 56) X.fillRect(x, 0, 26, 430);
        X.fillStyle = '#b98250'; X.fillRect(0, 430, W, 230);
        X.strokeStyle = 'rgba(70,40,20,.35)'; X.lineWidth = 2;
        for (let y = 470; y < H; y += 48) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); const off = R() * 200; for (let x = off; x < W; x += 230) { X.beginPath(); X.moveTo(x, y - 48); X.lineTo(x, y); X.stroke(); } }
        X.fillStyle = WHITE; X.fillRect(0, 424, W, 14); X.fillStyle = 'rgba(0,0,0,.15)'; X.fillRect(0, 438, W, 4);
      },
      lay(R) {
        const wx = 150 + R() * 700, sx = 230 + R() * 540;
        const hx = wx < 500 ? wx + 230 + R() * (880 - wx - 230) : 120 + R() * (wx - 350);
        return { bv: ri(R, 4), props: [
          { t: 'window', x: wx, y: 190, sol: 1, pd: 1 },
          { t: 'shelf', x: hx, y: 262 },
          { t: 'rug', x: 500 + (R() - 0.5) * 200, y: 596, pd: 1 },
          { t: 'sofa', x: sx, y: 432, pd: 1 },
        ], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 256, y1: 256, ty: ['books', 'plant', 'vase', 'mug', 'apple', 'books'], n: [2, 3], s: [0.6, 0.72] },
          { x0: 20, x1: 980, y0: 18, y1: 360, fl: 1, ty: ['frame', 'clock', 'frame', 'star'], n: [3, 4], s: [0.62, 0.82], no: [[hx - 120, 140, hx + 120, 275]] },
          { x0: sx - 150, x1: sx + 150, y0: 440, y1: 444, ty: ['cushion', 'cushion', 'cat', 'books'], n: [2, 3], s: [0.66, 0.8] },
          { x0: 10, x1: 990, y0: 540, y1: 652, ty: ['plant', 'cat', 'ball', 'books', 'gift', 'lamp', 'vase', 'tv', 'ball', 'plant'], n: [7, 9], s: [0.66, 0.9] },
        ] };
      } },
    { id: 'sea', name: '바닷속', g: 'fan',
      bg(v, R) {
        const g = [['#5fd0e6', '#0f5d8a'], ['#46b6c9', '#103f6b'], ['#7ad6c8', '#16607a']][v % 3];
        grad(g[0], g[1], 0, H);
        X.fillStyle = 'rgba(255,255,255,.07)'; for (let i = 0; i < 4; i++) { const x = R() * W; X.beginPath(); X.moveTo(x, 0); X.lineTo(x + 60, 0); X.lineTo(x - 80 + R() * 40, H); X.lineTo(x - 180, H); X.closePath(); X.fill(); }
        hills(R, 520, 60, 'rgba(10,40,70,.25)', 5);
        X.beginPath(); X.moveTo(0, H); X.lineTo(0, 570); for (let x = 0; x <= W; x += 50) X.lineTo(x, 566 + Math.sin(x / 70 + v) * 10); X.lineTo(W, H); X.closePath(); X.fillStyle = '#e9cf91'; X.fill(); X.lineWidth = 3; X.strokeStyle = 'rgba(43,34,51,.5)'; X.stroke();
        dots(R, 60, 0, 580, W, H, 'rgba(160,120,60,.35)', 1.5, 3.5);
        X.strokeStyle = 'rgba(255,255,255,.4)'; X.lineWidth = 2; for (let i = 0; i < 26; i++) { X.beginPath(); X.arc(R() * W, R() * 540, 2 + R() * 5, 0, TAU); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 20, y1: 500, fl: 1, ty: ['fish', 'fish', 'fish', 'jelly', 'bubbles', 'turtle', 'fish'], n: [7, 9], s: [0.68, 0.95] },
          { x0: 10, x1: 990, y0: 596, y1: 652, ty: ['crab', 'starfish', 'shell', 'seaweed', 'coral', 'rock', 'chest', 'octopus', 'seaweed', 'coral'], n: [7, 9], s: [0.66, 0.92] },
        ] };
      } },
    { id: 'camp', name: '숲속 캠핑', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 420);
        hills(R, 330, 120, '#8aa6c8', 4); hills(R, 380, 70, '#6f9a7a', 5);
        X.fillStyle = '#7cc35f'; X.fillRect(0, 400, W, 260); X.fillStyle = '#6cb352'; X.fillRect(0, 400, W, 14);
        X.strokeStyle = '#4f9a3e'; X.lineWidth = 3; for (let i = 0; i < 40; i++) { const x = R() * W, y = 430 + R() * 220; X.beginPath(); X.moveTo(x - 5, y); X.lineTo(x, y - 9); X.lineTo(x + 5, y); X.stroke(); }
      },
      lay(R) {
        const tx = 200 + R() * 600;
        return { bv: ri(R, 3), props: [{ t: 'tent', x: tx, y: 412, sol: 1, pd: 1 }], zones: [
          { x0: 30, x1: 970, y0: 16, y1: 170, fl: 1, nx: 1, ty: ['sun'], n: [1, 1], s: [0.66, 0.78] },
          { x0: 10, x1: 990, y0: 14, y1: 260, fl: 1, ty: ['cloud', 'cloud', 'bird', 'bird'], n: [3, 5], s: [0.58, 0.8] },
          { x0: 10, x1: 990, y0: 430, y1: 470, ty: ['pine', 'tree', 'pine'], n: [2, 3], s: [0.58, 0.72] },
          { x0: 10, x1: 990, y0: 520, y1: 652, ty: ['fire', 'mushroom', 'log', 'backpack', 'lantern', 'rabbit', 'flower', 'sign', 'butterfly', 'mushroom', 'flower'], n: [8, 10], s: [0.7, 0.92] },
        ] };
      } },
    { id: 'space', name: '우주', g: 'fan',
      bg(v, R) {
        const g = [['#120c2a', '#2a1650'], ['#0b1530', '#1d2d5c'], ['#0d1f26', '#21304f']][v % 3]; grad(g[0], g[1], 0, H);
        for (let i = 0; i < 3; i++) { const x = R() * W, y = R() * H, r = 160 + R() * 160; const rg = X.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, ['rgba(143,91,216,.28)', 'rgba(34,179,166,.2)', 'rgba(244,131,182,.2)'][i]); rg.addColorStop(1, 'rgba(0,0,0,0)'); X.fillStyle = rg; X.fillRect(0, 0, W, H); }
        dots(R, 150, 0, 0, W, H, 'rgba(255,255,255,.75)', 0.8, 2.4);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 10, y1: 650, fl: 1, ty: ['planet', 'rocket', 'astro', 'sat', 'ufo', 'comet', 'moon', 'alien', 'asteroid', 'star', 'star', 'asteroid', 'alien', 'planet'], n: [13, 16], s: [0.6, 0.88] },
        ] };
      } },
    { id: 'market', name: '시장', g: 'out',
      bg(v, R) {
        grad('#9ed8f0', '#dff3ff', 0, 160);
        const cs = ['#e9c9a0', '#d9b3a0', '#c9d3b8', '#e3d0b0'];
        for (let x = 0; x < W; x += 200) { X.fillStyle = cs[(x / 200 + v) % 4]; X.fillRect(x, 60 + R() * 30, 200, 420); X.fillStyle = 'rgba(80,60,40,.25)'; X.fillRect(x + 50, 140, 40, 50); X.fillRect(x + 120, 140, 40, 50); }
        X.fillStyle = '#d6c7aa'; X.fillRect(0, 470, W, 190);
        X.strokeStyle = 'rgba(90,70,40,.25)'; X.lineWidth = 2; for (let y = 500; y < H; y += 40) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
        X.beginPath(); X.moveTo(0, 30); X.quadraticCurveTo(500, 90, W, 30); X.lineWidth = 2; X.strokeStyle = '#5a4a3a'; X.stroke();
        for (let i = 0; i < 14; i++) { const t = (i + 0.5) / 14, x = t * W, y = 30 + 60 * 2 * t * (1 - t) * 1; X.beginPath(); X.moveTo(x - 16, y); X.lineTo(x + 16, y); X.lineTo(x, y + 26); X.closePath(); X.fillStyle = PAL[(i * 3 + v) % 8]; X.fill(); }
      },
      lay(R) {
        const a = 245 + (R() - 0.5) * 60, b = 755 + (R() - 0.5) * 60;
        return { bv: ri(R, 4), props: [{ t: 'stall', x: a, y: 392, pd: 1 }, { t: 'stall', x: b, y: 392, pd: 1 }], zones: [
          { x0: a - 146, x1: a + 146, y0: 402, y1: 404, ty: ['crate', 'melon', 'banana', 'basket', 'apple', 'carrot', 'pricetag', 'fish', 'apple'], n: [3, 4], s: [0.6, 0.74] },
          { x0: b - 146, x1: b + 146, y0: 402, y1: 404, ty: ['crate', 'melon', 'banana', 'basket', 'apple', 'carrot', 'pricetag', 'fish', 'apple'], n: [3, 4], s: [0.6, 0.74] },
          { x0: 10, x1: 990, y0: 540, y1: 652, ty: ['crate', 'basket', 'cat', 'ball', 'melon', 'basket', 'flower', 'apple'], n: [5, 7], s: [0.66, 0.88] },
          { x0: 10, x1: 990, y0: 70, y1: 200, fl: 1, ty: ['bird', 'balloon'], n: [1, 3], s: [0.58, 0.72] },
        ] };
      } },
    { id: 'park', name: '놀이공원', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 480);
        hills(R, 440, 50, '#86c26e', 6);
        X.fillStyle = '#7cc35f'; X.fillRect(0, 470, W, 190); X.fillStyle = '#ead7ad'; X.beginPath(); X.moveTo(0, 520); X.lineTo(W, 500); X.lineTo(W, H); X.lineTo(0, H); X.closePath(); X.fill();
        dots(R, 30, 0, 520, W, H, 'rgba(160,120,60,.25)', 2, 4);
      },
      lay(R) {
        const left = R() < 0.5, fx = left ? 200 + R() * 60 : 800 - R() * 60, bx = left ? 780 + R() * 80 : 220 - R() * 80;
        return { bv: ri(R, 3), props: [{ t: 'ferris', x: fx, y: 312, pd: 1 }, { t: 'booth', x: bx, y: 420, sol: 1, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 14, y1: 350, fl: 1, ty: ['balloon', 'balloon', 'cloud', 'bird', 'balloon', 'star'], n: [6, 8], s: [0.56, 0.8] },
          { x0: 10, x1: 990, y0: 540, y1: 652, ty: ['icecream', 'cotton', 'popcorn', 'gift', 'bench', 'flag', 'tree', 'balloon', 'icecream'], n: [7, 9], s: [0.62, 0.86] },
        ] };
      } },
    { id: 'kitchen', name: '부엌', g: 'in',
      bg(v, R) {
        const t = ['#e7f0ee', '#f4ead8', '#e8e6f4', '#f6e3e0'][v % 4];
        X.fillStyle = t; X.fillRect(0, 0, W, 500);
        X.strokeStyle = 'rgba(80,80,100,.16)'; X.lineWidth = 2; for (let y = 120; y < 490; y += 40) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); } for (let x = 0; x < W; x += 40) { X.beginPath(); X.moveTo(x, 120); X.lineTo(x, 490); X.stroke(); }
        X.fillStyle = '#c58a4a'; X.fillRect(0, 0, W, 112); X.strokeStyle = 'rgba(60,30,10,.4)'; X.lineWidth = 3;
        for (let x = 0; x < W; x += 125) { X.strokeRect(x + 8, 8, 109, 96); X.fillStyle = '#e3ae45'; X.fillRect(x + 100, 70, 8, 22); }
        X.fillStyle = '#e8e2d6'; X.fillRect(0, 488, W, 24); X.fillStyle = 'rgba(0,0,0,.12)'; X.fillRect(0, 512, W, 6);
        X.fillStyle = '#b07a45'; X.fillRect(0, 518, W, 142); X.strokeStyle = 'rgba(60,30,10,.4)';
        for (let x = 0; x < W; x += 166) { X.strokeRect(x + 10, 530, 146, 124); X.fillStyle = '#e3ae45'; X.fillRect(x + 70, 542, 26, 7); }
      },
      lay(R) {
        const wx = 150 + R() * 700;
        const hx = wx < 500 ? wx + 230 + R() * (880 - wx - 230) : 120 + R() * (wx - 350);
        return { bv: ri(R, 4), props: [{ t: 'window', x: wx, y: 232, sol: 1, pd: 1, s: 0.95 }, { t: 'shelf', x: hx, y: 268 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 262, y1: 262, ty: ['jar', 'mug', 'plates', 'plant', 'jar', 'books'], n: [2, 3], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 124, y1: 380, fl: 1, ty: ['clock', 'frame'], n: [1, 2], s: [0.58, 0.74], no: [[hx - 120, 150, hx + 120, 282]] },
          { x0: 10, x1: 990, y0: 492, y1: 494, ty: ['pot', 'pan', 'kettle', 'plates', 'jar', 'bread', 'mug', 'apple', 'carrot', 'melon', 'banana', 'plant', 'jar', 'mug'], n: [8, 10], s: [0.72, 0.95] },
        ] };
      } },
    { id: 'winter', name: '겨울 마을', g: 'out',
      bg(v, R) {
        const g = [['#1d2a55', '#4a5d99'], ['#bfe0f5', '#eef8ff'], ['#f3b38a', '#c9d6f0']][v % 3]; grad(g[0], g[1], 0, 440);
        if (v % 3 === 0) dots(R, 80, 0, 0, W, 380, 'rgba(255,255,255,.8)', 0.8, 2);
        hills(R, 380, 80, '#dfe9f6', 4);
        X.fillStyle = '#f3f6fb'; X.fillRect(0, 440, W, 220); hills(R, 450, 30, '#f8fbff', 6);
        X.fillStyle = 'rgba(120,150,200,.18)'; for (let i = 0; i < 8; i++) { X.beginPath(); X.ellipse(R() * W, 500 + R() * 150, 60 + R() * 60, 8, 0, 0, TAU); X.fill(); }
      },
      lay(R) {
        const a = 180 + R() * 150, b = 600 + R() * 220;
        return { bv: ri(R, 3), props: [{ t: 'house', x: a, y: 386, sol: 1, pd: 1, s: 0.95 }, { t: 'house', x: b, y: 386, sol: 1, pd: 1, s: 0.95 }], zones: [
          { x0: 10, x1: 990, y0: 14, y1: 260, fl: 1, ty: ['flake', 'flake', 'flake', 'bird', 'star', 'flake'], n: [5, 7], s: [0.66, 0.95] },
          { x0: 10, x1: 990, y0: 520, y1: 652, ty: ['snowman', 'sled', 'pine', 'gift', 'mitten', 'penguin', 'lamppost', 'pine', 'snowman', 'mitten', 'penguin'], n: [7, 10], s: [0.6, 0.84] },
        ] };
      } },
    { id: 'beach', name: '바닷가', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 260);
        grad('#3fb6d6', '#1f86b0', 250, 420);
        X.strokeStyle = 'rgba(255,255,255,.5)'; X.lineWidth = 3; for (let i = 0; i < 12; i++) { const x = R() * W, y = 270 + R() * 120; X.beginPath(); X.moveTo(x, y); X.quadraticCurveTo(x + 15, y - 6, x + 30, y); X.stroke(); }
        X.beginPath(); X.moveTo(0, H); X.lineTo(0, 418); for (let x = 0; x <= W; x += 40) X.lineTo(x, 414 + Math.sin(x / 60) * 8); X.lineTo(W, H); X.closePath(); X.fillStyle = '#f0d9a0'; X.fill(); X.lineWidth = 4; X.strokeStyle = '#ffffff'; X.stroke();
        dots(R, 50, 0, 430, W, H, 'rgba(170,130,60,.3)', 1.5, 3);
      },
      lay(R) {
        const left = R() < 0.5;
        return { bv: ri(R, 3), props: [{ t: 'palm', x: left ? 110 : 890, y: 380, f: left ? 0 : 1 }, { t: 'towel', x: 300 + R() * 400, y: 610, pd: 1 }], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 170, fl: 1, nx: 1, ty: ['sun'], n: [1, 1], s: [0.62, 0.76] },
          { x0: 10, x1: 990, y0: 14, y1: 230, fl: 1, ty: ['cloud', 'cloud', 'bird', 'bird'], n: [3, 5], s: [0.56, 0.8] },
          { x0: 10, x1: 990, y0: 392, y1: 400, ty: ['boat'], n: [1, 2], s: [0.6, 0.7] },
          { x0: 10, x1: 990, y0: 470, y1: 652, ty: ['bucket', 'castle', 'crab', 'shell', 'starfish', 'ball', 'umbrella', 'shell', 'crab', 'bucket'], n: [8, 10], s: [0.64, 0.86] },
        ] };
      } },
    { id: 'farm', name: '농장', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 420);
        hills(R, 360, 80, '#9fd17d', 4);
        X.fillStyle = '#8ccf6a'; X.fillRect(0, 410, W, 250);
        X.fillStyle = '#e8d3a8'; X.beginPath(); X.moveTo(440, 660); X.quadraticCurveTo(520, 520, 470, 430); X.lineTo(500, 430); X.quadraticCurveTo(580, 540, 560, 660); X.closePath(); X.fill();
        for (let x = 10; x < W; x += 70) { X.fillStyle = '#c99a62'; X.fillRect(x, 432, 10, 46); }
        X.fillStyle = '#d8ad74'; X.fillRect(0, 442, W, 8); X.fillRect(0, 462, W, 8);
      },
      lay(R) {
        const left = R() < 0.5, bx = left ? 170 + R() * 70 : 830 - R() * 70;
        return { bv: ri(R, 3), props: [{ t: 'barn', x: bx, y: 372, sol: 1, pd: 1, s: 0.9 }], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 160, fl: 1, nx: 1, ty: ['sun'], n: [0, 1], s: [0.62, 0.76] },
          { x0: 10, x1: 990, y0: 14, y1: 240, fl: 1, ty: ['cloud', 'cloud', 'bird', 'bird'], n: [3, 5], s: [0.56, 0.8] },
          { x0: 10, x1: 990, y0: 500, y1: 652, ty: ['chicken', 'pig', 'sheep', 'cow', 'hay', 'flower', 'chicken', 'tree', 'pig', 'sheep', 'flower'], n: [8, 11], s: [0.62, 0.84] },
        ] };
      } },
    /* ----- round 12: 20 more places ----- */
    { id: 'station', name: '우주 정거장', g: 'fan',
      bg(v, R) {
        const wall = ['#3a4152', '#41394f', '#2f4a4f'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, H);
        X.strokeStyle = 'rgba(255,255,255,.08)'; X.lineWidth = 3;
        for (let x = 0; x <= W; x += 125) { X.beginPath(); X.moveTo(x, 0); X.lineTo(x, H); X.stroke(); }
        for (const y of [220, 440]) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
        X.fillStyle = 'rgba(255,255,255,.14)'; for (let x = 0; x <= W; x += 125) for (const y of [220, 440]) { X.beginPath(); X.arc(x, y, 4, 0, TAU); X.fill(); }
        X.fillStyle = 'rgba(0,0,0,.18)'; X.fillRect(0, 96, W, 18); X.fillRect(0, 548, W, 18);
        X.fillStyle = 'rgba(120,220,255,.22)'; for (let x = 30 + R() * 60; x < W; x += 140 + R() * 80) X.fillRect(x, 100, 40, 10);
        X.fillStyle = '#e3ae45'; X.fillRect(0, 636, W, 24); X.fillStyle = '#2b2233'; for (let x = -20; x < W; x += 40) { X.beginPath(); X.moveTo(x, 660); X.lineTo(x + 18, 636); X.lineTo(x + 32, 636); X.lineTo(x + 14, 660); X.closePath(); X.fill(); }
      },
      lay(R) {
        const a = { t: 'porthole', x: 170 + R() * 200, y: 170 + R() * 80, s: 1 + R() * 0.15, sol: 1, pd: 1 };
        const b = { t: 'porthole', x: 630 + R() * 200, y: 380 + R() * 90, s: 0.9 + R() * 0.15, sol: 1, pd: 1 };
        return { bv: ri(R, 3), props: R() < 0.5 ? [a, b] : [R() < 0.5 ? a : b], zones: [
          { x0: 10, x1: 990, y0: 10, y1: 628, fl: 1, ty: ['astro', 'wrench', 'screen', 'pouch', 'helmet', 'panel', 'plant', 'books', 'mug', 'robot', 'pouch', 'wrench', 'apple', 'astro'], n: [12, 15], s: [0.62, 0.86] },
        ] };
      } },
    { id: 'classroom', name: '교실', g: 'in',
      bg(v, R) {
        const wall = ['#f1e6cc', '#d6ead9', '#dfe2f0', '#f3dcd0'][v % 4];
        X.fillStyle = wall; X.fillRect(0, 0, W, 470);
        X.fillStyle = 'rgba(0,0,0,.05)'; X.fillRect(0, 330, W, 140);
        X.fillStyle = WHITE; X.fillRect(0, 326, W, 8);
        X.fillStyle = '#c99a62'; X.fillRect(0, 470, W, 190);
        X.strokeStyle = 'rgba(80,50,20,.3)'; X.lineWidth = 2;
        for (let y = 500; y < H; y += 40) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
        for (let x = R() * 80; x < W; x += 120) { X.beginPath(); X.moveTo(x, 470); X.lineTo(x - 60, H); X.stroke(); }
        X.fillStyle = 'rgba(0,0,0,.15)'; X.fillRect(0, 470, W, 6);
      },
      lay(R) {
        const bx = 500 + (R() - 0.5) * 160, d1 = 190 + R() * 50, d2 = 810 - R() * 50, dy = 470;
        return { bv: ri(R, 4), props: [
          { t: 'chalkboard', x: bx, y: 172, s: 0.95, sol: 1, pd: 1 },
          { t: 'desk', x: d1, y: dy, pd: 1 }, { t: 'desk', x: d2, y: dy, pd: 1 },
        ], zones: [
          { x0: d1 - 98, x1: d1 + 98, y0: dy - 16, y1: dy - 16, ty: ['books', 'apple', 'globe', 'pencils', 'trophy', 'mug', 'plant', 'calendar'], n: [2, 3], s: [0.58, 0.7] },
          { x0: d2 - 98, x1: d2 + 98, y0: dy - 16, y1: dy - 16, ty: ['books', 'apple', 'globe', 'pencils', 'trophy', 'mug', 'plant', 'calendar'], n: [2, 3], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 12, y1: 320, fl: 1, ty: ['clock', 'frame', 'calendar', 'plane2', 'star', 'clock', 'frame'], n: [3, 5], s: [0.6, 0.8] },
          { x0: 10, x1: 990, y0: 572, y1: 652, ty: ['backpack', 'chair', 'ball', 'books', 'plant', 'backpack', 'globe', 'chair', 'trophy'], n: [5, 7], s: [0.62, 0.84] },
        ] };
      } },
    { id: 'jungle', name: '정글', g: 'out',
      bg(v, R) {
        const g = [['#8fd18f', '#2f6b45'], ['#a6d98a', '#3b6b2f'], ['#7cc8a8', '#1f5a4a']][v % 3];
        grad(g[0], g[1], 0, 560);
        X.fillStyle = 'rgba(255,255,220,.12)'; for (let i = 0; i < 3; i++) { const x = R() * W; X.beginPath(); X.moveTo(x, 0); X.lineTo(x + 70, 0); X.lineTo(x + 10, 560); X.lineTo(x - 100, 560); X.closePath(); X.fill(); }
        X.fillStyle = 'rgba(30,70,40,.45)'; for (let i = 0; i < 6; i++) { const x = R() * W; X.fillRect(x, 0, 26 + R() * 30, 560); }
        X.fillStyle = 'rgba(40,110,60,.9)'; for (let i = 0; i < 14; i++) { X.beginPath(); X.ellipse(i * 76 + R() * 30, -10 + R() * 30, 70, 44, R(), 0, TAU); X.fill(); }
        X.strokeStyle = '#3f7f3a'; X.lineWidth = 5; for (let i = 0; i < 7; i++) { const x = R() * W, l = 140 + R() * 220; X.beginPath(); X.moveTo(x, 0); X.quadraticCurveTo(x + 30, l / 2, x - 10, l); X.stroke(); }
        X.fillStyle = '#4f7f3a'; X.beginPath(); X.moveTo(0, H); X.lineTo(0, 540); for (let x = 0; x <= W; x += 50) X.lineTo(x, 536 + Math.sin(x / 40 + v) * 8); X.lineTo(W, H); X.closePath(); X.fill();
        X.fillStyle = '#5f9a45'; for (let i = 0; i < 30; i++) { const x = R() * W, y = 560 + R() * 100; X.beginPath(); X.moveTo(x - 7, y); X.lineTo(x, y - 14); X.lineTo(x + 7, y); X.fill(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 40, y1: 300, fl: 1, ty: ['parrot', 'toucan', 'monkey', 'butterfly', 'hibiscus', 'parrot', 'banana'], n: [5, 7], s: [0.62, 0.84] },
          { x0: 10, x1: 990, y0: 320, y1: 500, fl: 1, ty: ['butterfly', 'hibiscus', 'monkey', 'toucan'], n: [2, 3], s: [0.6, 0.78] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['frog', 'snake', 'fern', 'hibiscus', 'mushroom', 'fern', 'rock', 'frog', 'banana', 'snake'], n: [7, 9], s: [0.62, 0.88] },
        ] };
      } },
    { id: 'dino', name: '공룡 시대', g: 'fan',
      bg(v, R) {
        const g = [['#f7c08a', '#fde8c2'], ['#bfe2f0', '#f6efd2'], ['#e99a7a', '#f9d8a8']][v % 3];
        grad(g[0], g[1], 0, 440);
        const vx = 120 + R() * 760;
        X.fillStyle = '#7c6b78'; X.beginPath(); X.moveTo(vx - 260, 440); X.lineTo(vx - 50, 150); X.lineTo(vx + 50, 150); X.lineTo(vx + 260, 440); X.closePath(); X.fill();
        X.fillStyle = '#f28a2e'; X.beginPath(); X.moveTo(vx - 50, 150); X.lineTo(vx - 30, 200); X.lineTo(vx - 10, 165); X.lineTo(vx + 15, 215); X.lineTo(vx + 50, 150); X.closePath(); X.fill();
        X.fillStyle = 'rgba(120,110,120,.45)'; for (let i = 0; i < 5; i++) { X.beginPath(); X.arc(vx - 20 + i * 14 + R() * 20, 120 - i * 26, 26 + i * 6, 0, TAU); X.fill(); }
        hills(R, 400, 60, '#8fb07a', 5);
        X.fillStyle = '#a9c47a'; X.fillRect(0, 440, W, 220);
        X.fillStyle = 'rgba(70,110,50,.35)'; for (let i = 0; i < 12; i++) { const x = R() * W, y = 470 + R() * 180; X.beginPath(); X.ellipse(x, y, 30 + R() * 30, 8, 0, 0, TAU); X.fill(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 14, y1: 240, fl: 1, ty: ['ptero', 'ptero', 'cloud'], n: [2, 4], s: [0.6, 0.82] },
          { x0: 10, x1: 990, y0: 476, y1: 530, ty: ['dlong', 'trex', 'trice'], n: [2, 3], s: [0.56, 0.68] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['nest', 'fern', 'rock', 'trice', 'fern', 'nest', 'palm', 'rock'], n: [5, 7], s: [0.6, 0.84] },
        ] };
      } },
    { id: 'hall', name: '성 안', g: 'fan',
      bg(v, R) {
        const st = ['#8d8a9b', '#9b8f84', '#7f8899'][v % 3];
        X.fillStyle = st; X.fillRect(0, 0, W, 470);
        X.strokeStyle = 'rgba(40,30,50,.28)'; X.lineWidth = 2;
        for (let r = 0, y = 0; y < 470; y += 40, r++) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); for (let x = (r % 2) * 50; x < W; x += 100) { X.beginPath(); X.moveTo(x, y); X.lineTo(x, y + 40); X.stroke(); } }
        X.fillStyle = 'rgba(0,0,0,.08)'; for (let i = 0; i < 18; i++) X.fillRect(Math.floor(R() * 10) * 100 + (R() < 0.5 ? 0 : 50), Math.floor(R() * 11) * 40, 100, 40);
        X.fillStyle = '#5d5866'; X.fillRect(0, 470, W, 190);
        X.strokeStyle = 'rgba(0,0,0,.25)'; for (let y = 500; y < H; y += 45) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
        X.fillStyle = '#a3263a'; X.beginPath(); X.moveTo(440, 470); X.lineTo(560, 470); X.lineTo(640, H); X.lineTo(360, H); X.closePath(); X.fill();
        X.fillStyle = GOLD; X.fillRect(436, 470, 6, 4); X.fillStyle = 'rgba(246,205,59,.7)'; X.beginPath(); X.moveTo(440, 470); X.lineTo(446, 470); X.lineTo(370, H); X.lineTo(362, H); X.closePath(); X.fill(); X.beginPath(); X.moveTo(554, 470); X.lineTo(560, 470); X.lineTo(640, H); X.lineTo(632, H); X.closePath(); X.fill();
      },
      lay(R) {
        return { bv: ri(R, 3), props: [{ t: 'throne', x: 500, y: 366, s: 0.9, sol: 1, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 18, y1: 330, fl: 1, ty: ['banner', 'shield', 'torch', 'painting', 'shield', 'sword', 'banner', 'frame', 'torch'], n: [5, 7], s: [0.6, 0.78] },
          { x0: 10, x1: 990, y0: 560, y1: 652, ty: ['armor', 'chest', 'barrel', 'candles', 'goblet', 'crown', 'armor', 'barrel', 'chest'], n: [6, 8], s: [0.62, 0.84] },
        ] };
      } },
    { id: 'library', name: '도서관', g: 'in',
      bg(v, R) {
        const wall = ['#eadcc0', '#d9e0cf', '#e6d4cc'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 500);
        X.fillStyle = 'rgba(0,0,0,.04)'; for (let x = 0; x < W; x += 40) X.fillRect(x, 0, 20, 500);
        X.fillStyle = '#9b6332'; X.fillRect(0, 500, W, 160);
        X.strokeStyle = 'rgba(50,25,10,.35)'; X.lineWidth = 2;
        for (let y = 530; y < H; y += 34) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); const off = R() * 160; for (let x = off; x < W; x += 200) { X.beginPath(); X.moveTo(x, y - 34); X.lineTo(x, y); X.stroke(); } }
        X.fillStyle = '#6b4423'; X.fillRect(0, 492, W, 12);
      },
      lay(R) {
        const a = 140 + R() * 40, b = 860 - R() * 40, tx = 500 + (R() - 0.5) * 80;
        return { bv: ri(R, 3), props: [
          { t: 'bookcase', x: a, y: 334, s: 0.95, sol: 1 }, { t: 'bookcase', x: b, y: 334, s: 0.95, sol: 1 },
          { t: 'table', x: tx, y: 560, s: 0.95, pd: 1 },
        ], zones: [
          { x0: 260, x1: 740, y0: 16, y1: 340, fl: 1, ty: ['clock', 'frame', 'painting', 'calendar', 'libsign', 'frame', 'clock'], n: [3, 5], s: [0.58, 0.74] },
          { x0: tx - 140, x1: tx + 140, y0: 560 - 22 * 0.95, y1: 560 - 22 * 0.95, ty: ['openbook', 'hourglass', 'books', 'magnifier', 'mug', 'globe', 'scroll', 'candles', 'plant'], n: [3, 4], s: [0.62, 0.74] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['books', 'cat', 'plant', 'backpack', 'libsign', 'books', 'globe', 'chair', 'lamp'], n: [4, 6], s: [0.6, 0.8], no: [[tx - 150, 540, tx + 150, 660]] },
        ] };
      } },
    { id: 'subway', name: '지하철', g: 'in',
      bg(v, R) {
        const wall = ['#e3e6ec', '#ece6dc', '#dde8e6'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 530);
        X.fillStyle = '#c9ced8'; X.fillRect(0, 0, W, 34); X.fillStyle = '#fffbe6'; for (let x = 60; x < W; x += 220) X.fillRect(x, 10, 120, 12);
        const tun = ['#1c2236', '#2a2238', '#1d2a2c'][v % 3];
        for (let i = 0; i < 4; i++) { const x = 20 + i * 245; RR(x, 80, 215, 150, 16, '#9aa3b5'); X.fillStyle = tun; X.beginPath(); rrp(x + 10, 90, 195, 130, 10); X.fill();
          X.fillStyle = 'rgba(255,230,150,.55)'; for (let j = 0; j < 3; j++) X.fillRect(x + 20 + R() * 160, 110 + R() * 90, 30 + R() * 30, 3); }
        X.fillStyle = '#8f96a3'; X.fillRect(0, 530, W, 130);
        X.fillStyle = 'rgba(255,255,255,.12)'; for (let i = 0; i < 50; i++) { X.beginPath(); X.arc(R() * W, 540 + R() * 120, 3, 0, TAU); X.fill(); }
        X.fillStyle = '#f2c94c'; for (const x of [12, 494, 980]) X.fillRect(x, 34, 9, 496);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [{ t: 'seats', x: 255, y: 466, s: 0.9 }, { t: 'seats', x: 745, y: 466, s: 0.9 }], zones: [
          { x0: 10, x1: 990, y0: 40, y1: 40, ty: ['strap'], n: [5, 8], s: [0.75, 0.92] },
          { x0: 30, x1: 970, y0: 236, y1: 396, fl: 1, ty: ['routemap', 'stsign', 'frame', 'clock', 'screen', 'routemap'], n: [3, 4], s: [0.58, 0.72] },
          { x0: 50, x1: 950, y0: 466 - 26 * 0.9, y1: 466 - 26 * 0.9, ty: ['bag', 'books', 'backpack', 'mug', 'cat', 'bag'], n: [2, 4], s: [0.55, 0.68], no: [[462, 300, 538, 470]] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['person', 'person', 'bag', 'person', 'umbr', 'backpack', 'person', 'bag'], n: [5, 7], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'oasis', name: '사막 오아시스', g: 'out',
      bg(v, R) {
        const g = [['#f9d79a', '#fdf0cf'], ['#9fd2ef', '#f8ecd0'], ['#f2a774', '#fbe0b2']][v % 3];
        grad(g[0], g[1], 0, 420);
        for (let i = 0; i < 2; i++) { const x = 150 + R() * 700, s = 70 + R() * 50; X.fillStyle = 'rgba(200,150,90,.55)'; X.beginPath(); X.moveTo(x - s, 400); X.lineTo(x, 400 - s * 0.9); X.lineTo(x + s, 400); X.closePath(); X.fill(); }
        hills(R, 400, 50, '#e8c27a', 4);
        X.fillStyle = '#efd39a'; X.fillRect(0, 430, W, 230); hills(R, 460, 26, '#f3dca8', 5);
        const px = 360 + R() * 280;
        X.fillStyle = '#7fcf8f'; X.beginPath(); X.ellipse(px, 528, 250, 62, 0, 0, TAU); X.fill();
        X.fillStyle = '#3fb6d6'; X.beginPath(); X.ellipse(px, 528, 220, 46, 0, 0, TAU); X.fill();
        X.strokeStyle = 'rgba(255,255,255,.6)'; X.lineWidth = 3; for (let i = 0; i < 5; i++) { const x = px - 150 + R() * 300, y = 515 + R() * 26; X.beginPath(); X.moveTo(x, y); X.quadraticCurveTo(x + 12, y - 5, x + 24, y); X.stroke(); }
        dots(R, 50, 0, 590, W, H, 'rgba(170,120,60,.3)', 1.5, 3);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 170, fl: 1, nx: 1, ty: ['sun'], n: [1, 1], s: [0.6, 0.74] },
          { x0: 10, x1: 990, y0: 14, y1: 250, fl: 1, ty: ['bird', 'cloud', 'bird'], n: [2, 4], s: [0.56, 0.76] },
          { x0: 10, x1: 990, y0: 440, y1: 480, ty: ['camel', 'tent', 'palm', 'camel', 'cactus'], n: [2, 3], s: [0.55, 0.66] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['cactus', 'amphora', 'lizard', 'rock', 'basket', 'reeds', 'melon', 'amphora', 'lizard'], n: [6, 8], s: [0.62, 0.84] },
        ] };
      } },
    { id: 'pirate', name: '해적선', g: 'fan',
      bg(v, R) {
        const g = [['#8fd0f5', '#e6f6ff'], ['#f6a96b', '#fde2b0'], ['#2a3566', '#7a6aa8']][v % 3];
        grad(g[0], g[1], 0, 280);
        if (v % 3 === 2) dots(R, 60, 0, 0, W, 240, 'rgba(255,255,255,.8)', 0.8, 2);
        grad('#2f8fc0', '#1d5f8a', 270, 340);
        X.strokeStyle = 'rgba(255,255,255,.5)'; X.lineWidth = 3; for (let i = 0; i < 10; i++) { const x = R() * W, y = 285 + R() * 45; X.beginPath(); X.moveTo(x, y); X.quadraticCurveTo(x + 15, y - 6, x + 30, y); X.stroke(); }
        X.fillStyle = '#8a5a32'; X.fillRect(0, 330, W, 30); X.fillStyle = '#6b4423'; for (let x = 20; x < W; x += 70) X.fillRect(x, 300, 12, 34); X.fillRect(0, 294, W, 10);
        X.fillStyle = '#b5793f'; X.fillRect(0, 360, W, 300);
        X.strokeStyle = 'rgba(70,40,20,.4)'; X.lineWidth = 2; for (let y = 390; y < H; y += 32) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); const off = R() * 200; for (let x = off; x < W; x += 260) { X.beginPath(); X.moveTo(x, y - 32); X.lineTo(x, y); X.stroke(); } }
      },
      lay(R) {
        const mx = 500 + (R() - 0.5) * 300, my = 570 - 220;
        return { bv: ri(R, 3), props: [{ t: 'mast', x: mx, y: my, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 14, y1: 260, fl: 1, ty: ['bird', 'cloud', 'bird', 'cloud'], n: [2, 4], s: [0.56, 0.76], no: [[mx - 145, 0, mx + 145, 340]] },
          { x0: 10, x1: 990, y0: 440, y1: 480, ty: ['barrel', 'cannon', 'helm', 'barrel', 'chest', 'cannon'], n: [3, 4], s: [0.6, 0.74], no: [[mx - 30, 300, mx + 30, 600]] },
          { x0: 10, x1: 990, y0: 586, y1: 652, ty: ['chest', 'barrel', 'parrot', 'anchor', 'rope', 'balls', 'tmap', 'bottle', 'cannon', 'balls'], n: [7, 9], s: [0.62, 0.84] },
        ] };
      } },
    { id: 'factory', name: '로봇 공장', g: 'fan',
      bg(v, R) {
        const wall = ['#6b7385', '#5f6f6b', '#75687f'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 480);
        X.fillStyle = 'rgba(0,0,0,.12)'; for (let x = 0; x < W; x += 100) X.fillRect(x, 0, 4, 480);
        X.fillStyle = 'rgba(180,220,255,.25)'; for (let x = 40; x < W; x += 200) X.fillRect(x, 18, 120, 50);
        X.strokeStyle = '#9aa3b5'; X.lineWidth = 12; for (let i = 0; i < 2; i++) { const y = 300 + i * 26; X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
        X.fillStyle = '#4a5060'; X.fillRect(0, 480, W, 180);
        X.fillStyle = '#e3ae45'; X.fillRect(0, 480, W, 16); X.fillStyle = '#2b2233'; for (let x = -20; x < W; x += 36) { X.beginPath(); X.moveTo(x, 496); X.lineTo(x + 16, 480); X.lineTo(x + 28, 480); X.lineTo(x + 12, 496); X.closePath(); X.fill(); }
        X.strokeStyle = 'rgba(255,255,255,.08)'; X.lineWidth = 2; for (let x = 0; x < W; x += 80) { X.beginPath(); X.moveTo(x, 496); X.lineTo(x - 40, H); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [{ t: 'belt', x: 500, y: 400 }], zones: [
          { x0: 30, x1: 970, y0: 386, y1: 386, ty: ['robot', 'cbox', 'robot', 'battery', 'gear', 'cbox', 'robot'], n: [4, 5], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 80, y1: 280, fl: 1, ty: ['gear', 'gear', 'screen', 'panel', 'clock', 'gear', 'beacon'], n: [4, 6], s: [0.6, 0.8] },
          { x0: 10, x1: 990, y0: 580, y1: 652, ty: ['arm', 'robot', 'cbox', 'battery', 'beacon', 'cbox', 'arm', 'robot'], n: [5, 7], s: [0.6, 0.82] },
        ] };
      } },
    { id: 'florist', name: '꽃집', g: 'in',
      bg(v, R) {
        const wall = ['#f6dfe4', '#dcefe3', '#f3ecd6'][v % 4 % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 480);
        X.fillStyle = 'rgba(255,255,255,.35)'; for (let x = 0; x < W; x += 60) for (let y = 20; y < 470; y += 60) { X.beginPath(); X.arc(x + ((y / 60) % 2) * 30, y, 5, 0, TAU); X.fill(); }
        for (let y = 480; y < H; y += 45) for (let x = 0; x < W; x += 45) { X.fillStyle = ((x + y) / 45) % 2 ? '#e9e2d6' : '#d6cdbf'; X.fillRect(x, y, 45, 45); }
        X.fillStyle = 'rgba(0,0,0,.12)'; X.fillRect(0, 480, W, 6);
      },
      lay(R) {
        const cx = 500 + (R() - 0.5) * 160, hx = cx < 500 ? 760 + R() * 100 : 140 + R() * 100;
        return { bv: ri(R, 3), props: [{ t: 'shelf', x: hx, y: 220 }, { t: 'counter', x: cx, y: 470, s: 0.86, pd: 1 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 214, y1: 214, ty: ['succ', 'plant', 'vase', 'flower', 'succ', 'jar'], n: [2, 3], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 14, y1: 320, fl: 1, ty: ['frame', 'clock', 'flowsign', 'painting', 'flowsign'], n: [2, 3], s: [0.58, 0.74], no: [[hx - 120, 110, hx + 120, 236]] },
          { x0: cx - 190, x1: cx + 190, y0: 470 - 32 * 0.86, y1: 470 - 32 * 0.86, ty: ['bouquet', 'vase', 'pricetag', 'basket', 'succ', 'tulips', 'wcan'], n: [3, 4], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['tulips', 'plant', 'wcan', 'bucket', 'cactus', 'tulips', 'flower', 'cat', 'basket', 'bouquet'], n: [6, 8], s: [0.6, 0.82] },
        ] };
      } },
    { id: 'night', name: '야경 도시', g: 'out',
      bg(v, R) {
        const g = [['#0e1330', '#2f3566'], ['#1d1238', '#5a3a6e'], ['#0b1c2c', '#2a4a5e']][v % 3];
        grad(g[0], g[1], 0, 520);
        dots(R, 90, 0, 0, W, 380, 'rgba(255,255,255,.7)', 0.8, 2);
        X.fillStyle = 'rgba(20,20,45,.7)'; for (let x = 0; x < W;) { const w = 50 + R() * 60, h = 80 + R() * 140; X.fillRect(x, 520 - h - 40, w, h + 40); x += w + 4; }
        X.fillStyle = '#5a5e70'; X.fillRect(0, 500, W, 34); X.fillStyle = '#353a4a'; X.fillRect(0, 534, W, 126);
        X.fillStyle = '#e3ae45'; for (let x = 20; x < W; x += 90) X.fillRect(x, 594, 46, 6);
        X.fillStyle = 'rgba(255,217,106,.08)'; for (let i = 0; i < 6; i++) X.fillRect(R() * W, 540, 30, 120);
      },
      lay(R) {
        const n = 3 + (R() < 0.5 ? 1 : 0), props = [], no = [];
        for (let i = 0; i < n; i++) { const s = 0.72 + R() * 0.3, x = (i + 0.5) * W / n + (R() - 0.5) * 40; props.push({ t: 'bldg', x, y: 500 - 160 * s, s, pd: 1 }); no.push([x - 76 * s, 500 - 330 * s, x + 76 * s, 520]); }
        return { bv: ri(R, 3), props, zones: [
          { x0: 30, x1: 970, y0: 14, y1: 150, fl: 1, nx: 1, ty: ['moon'], n: [0, 1], s: [0.62, 0.76], no },
          { x0: 10, x1: 990, y0: 14, y1: 340, fl: 1, ty: ['star', 'jet', 'firework', 'star', 'firework', 'balloon'], n: [3, 5], s: [0.58, 0.78], no },
          { x0: 10, x1: 990, y0: 586, y1: 652, ty: ['car', 'car', 'tlight', 'lamppost', 'billboard', 'cat', 'car', 'person', 'tlight'], n: [4, 6], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'party', name: '생일 파티', g: 'in',
      bg(v, R) {
        const wall = ['#fbe3ea', '#e3eefb', '#fdf0d0'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 500);
        X.fillStyle = 'rgba(255,255,255,.45)'; for (let x = 0; x < W; x += 50) X.fillRect(x, 0, 22, 500);
        for (let s = 0; s < 2; s++) { const x0 = s * 500, sag = 50; X.strokeStyle = '#8f909c'; X.lineWidth = 2; X.beginPath(); X.moveTo(x0, 20); X.quadraticCurveTo(x0 + 250, 20 + sag * 2, x0 + 500, 20); X.stroke();
          for (let i = 0; i < 9; i++) { const t = (i + 0.5) / 9, x = x0 + t * 500, y = 20 + sag * 2 * 2 * t * (1 - t) * 1; X.fillStyle = PAL[(i + s * 3 + v) % 8]; X.beginPath(); X.moveTo(x - 18, y); X.lineTo(x + 18, y); X.lineTo(x, y + 32); X.closePath(); X.fill(); } }
        const cs = [PAL[0], PAL[2], PAL[5], PAL[7], PAL[3]]; for (let i = 0; i < 40; i++) { X.fillStyle = cs[i % 5]; X.globalAlpha = 0.5; X.fillRect(R() * W, 120 + R() * 360, 6, 6); } X.globalAlpha = 1;
        X.fillStyle = '#c99a62'; X.fillRect(0, 500, W, 160); X.fillStyle = 'rgba(0,0,0,.14)'; X.fillRect(0, 500, W, 6);
        X.strokeStyle = 'rgba(80,50,20,.3)'; X.lineWidth = 2; for (let y = 530; y < H; y += 36) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
      },
      lay(R) {
        const tx = 500 + (R() - 0.5) * 160;
        return { bv: ri(R, 3), props: [{ t: 'ctable', x: tx, y: 446, s: 0.92, pd: 1 }], zones: [
          { x0: tx - 170, x1: tx + 170, y0: 446 - 26 * 0.92, y1: 446 - 26 * 0.92, ty: ['cake', 'cupcake', 'juice', 'phat', 'gift', 'cupcake', 'juice'], n: [4, 5], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 80, y1: 330, fl: 1, ty: ['balloon', 'nballoon', 'balloon', 'star', 'balloon', 'phat'], n: [4, 6], s: [0.58, 0.78] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['gift', 'teddy', 'phat', 'ball', 'gift', 'balloon', 'teddy', 'cat', 'gift'], n: [5, 7], s: [0.6, 0.82] },
        ] };
      } },
    { id: 'playground', name: '놀이터', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 400);
        X.fillStyle = '#5f9a55'; for (let i = 0; i < 9; i++) { const x = i * 120 + R() * 40; X.beginPath(); X.arc(x, 380, 50 + R() * 30, Math.PI, 0); X.fill(); }
        X.fillStyle = '#86c26e'; X.fillRect(0, 380, W, 280);
        X.fillStyle = '#ecd7a6'; X.beginPath(); X.ellipse(500 + (R() - 0.5) * 200, 590, 420, 80, 0, 0, TAU); X.fill();
        dots(R, 40, 0, 520, W, H, 'rgba(160,120,60,.25)', 2, 4);
      },
      lay(R) {
        const left = R() < 0.5, sx = left ? 190 + R() * 60 : 810 - R() * 60, wx = left ? 760 + R() * 60 : 240 - R() * 60;
        return { bv: ri(R, 3), props: [{ t: 'slide', x: sx, y: 520 - 110 * 0.9, s: 0.9, f: left ? 0 : 1, pd: 1 }, { t: 'swing', x: wx, y: 520 - 130 * 0.85, s: 0.85, pd: 1 }], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 150, fl: 1, nx: 1, ty: ['sun'], n: [0, 1], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 14, y1: 260, fl: 1, ty: ['kite', 'cloud', 'bird', 'kite', 'balloon', 'cloud'], n: [3, 5], s: [0.58, 0.8] },
          { x0: 10, x1: 990, y0: 586, y1: 652, ty: ['ball', 'bucket', 'scooter', 'seesaw', 'bench', 'person', 'flower', 'cat', 'person', 'ball', 'castle'], n: [6, 8], s: [0.6, 0.82] },
        ] };
      } },
    { id: 'bakery', name: '빵집', g: 'in',
      bg(v, R) {
        const wall = ['#f4e2c6', '#f1d6cf', '#e5e8d2'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 420);
        X.fillStyle = 'rgba(160,100,60,.08)'; for (let y = 0; y < 420; y += 30) for (let x = (y / 30 % 2) * 30; x < W; x += 60) X.fillRect(x, y, 30, 30);
        X.fillStyle = '#b07a45'; X.fillRect(0, 420, W, 240); X.fillStyle = WHITE; X.fillRect(0, 414, W, 10);
        X.strokeStyle = 'rgba(60,30,10,.3)'; X.lineWidth = 2; for (let x = 0; x < W; x += 50) { X.beginPath(); X.moveTo(x, 424); X.lineTo(x, H); X.stroke(); }
        X.fillStyle = '#d9875a'; X.beginPath(); X.moveTo(0, 0); for (let x = 0; x <= W; x += 50) { X.lineTo(x, 34); X.lineTo(x + 25, 46); } X.lineTo(W, 0); X.closePath(); X.fill();
      },
      lay(R) {
        const hx = R() < 0.5 ? 180 + R() * 80 : 820 - R() * 80;
        return { bv: ri(R, 3), props: [{ t: 'shelf', x: hx, y: 236 }, { t: 'showcase', x: 500, y: 520, s: 0.95, pd: 1 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 230, y1: 230, ty: ['bread', 'croissant', 'jar', 'baguettes', 'pie'], n: [2, 3], s: [0.56, 0.68] },
          { x0: 10, x1: 990, y0: 60, y1: 330, fl: 1, ty: ['clock', 'frame', 'bakesign', 'calendar', 'bakesign'], n: [2, 3], s: [0.58, 0.74], no: [[hx - 120, 120, hx + 120, 252]] },
          { x0: 290, x1: 710, y0: 520 - 70 * 0.95, y1: 520 - 70 * 0.95, ty: ['cake', 'pie', 'slice', 'donut', 'croissant', 'cupcake', 'pricetag', 'donut'], n: [3, 4], s: [0.58, 0.7] },
          { x0: 300, x1: 700, y0: 520 - 24 * 0.95, y1: 520 - 24 * 0.95, ty: ['donut', 'croissant', 'slice', 'cupcake', 'bread'], n: [3, 4], s: [0.52, 0.6] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['baguettes', 'basket', 'cat', 'plant', 'bread'], n: [2, 3], s: [0.6, 0.76], no: [[268, 400, 732, 660]] },
        ] };
      } },
    { id: 'halloween', name: '할로윈 밤', g: 'fan',
      bg(v, R) {
        const g = [['#3a2a6e', '#e08a4a'], ['#2a2a5e', '#9b5aa8'], ['#4a2a5a', '#f0a050']][v % 3];
        grad(g[0], g[1], 0, 480);
        const mx = 100 + R() * 800; X.fillStyle = 'rgba(255,240,200,.25)'; X.beginPath(); X.arc(mx, 120, 90, 0, TAU); X.fill(); X.fillStyle = '#fff3c4'; X.beginPath(); X.arc(mx, 120, 60, 0, TAU); X.fill();
        dots(R, 40, 0, 0, W, 300, 'rgba(255,255,255,.6)', 0.8, 1.8);
        hills(R, 440, 80, '#2a2040', 4);
        X.fillStyle = '#3b2f4a'; X.fillRect(0, 470, W, 190);
        X.fillStyle = '#251c33'; for (let x = 10; x < W; x += 34) { X.fillRect(x, 430, 10, 50); X.beginPath(); X.moveTo(x - 2, 430); X.lineTo(x + 5, 420); X.lineTo(x + 12, 430); X.fill(); } X.fillRect(0, 444, W, 6); X.fillRect(0, 464, W, 6);
        X.fillStyle = 'rgba(160,140,200,.15)'; for (let i = 0; i < 6; i++) { X.beginPath(); X.ellipse(R() * W, 520 + R() * 120, 90, 12, 0, 0, TAU); X.fill(); }
      },
      lay(R) {
        const left = R() < 0.5, hx = left ? 170 + R() * 50 : 830 - R() * 50, s = 0.82;
        const no = [[hx - 145 * s, 470 - 330 * s, hx + 145 * s, 480]];
        return { bv: ri(R, 3), props: [{ t: 'manor', x: hx, y: 470 - 120 * s, s, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 14, y1: 340, fl: 1, ty: ['bat', 'bat', 'ghost', 'web', 'bat', 'ghost', 'star'], n: [5, 7], s: [0.6, 0.82], no },
          { x0: 10, x1: 990, y0: 560, y1: 652, ty: ['pumpkin', 'grave', 'cat', 'candy', 'what', 'lantern', 'pumpkin', 'grave', 'mushroom', 'pumpkin'], n: [7, 9], s: [0.62, 0.86] },
        ] };
      } },
    { id: 'gallery', name: '미술관', g: 'in',
      bg(v, R) {
        const wall = ['#f2efe8', '#e3e6ea', '#efe4dc'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 470);
        X.fillStyle = 'rgba(255,240,200,.35)'; for (let x = 100; x < W; x += 200) { X.beginPath(); X.moveTo(x - 20, 0); X.lineTo(x + 20, 0); X.lineTo(x + 110, 360); X.lineTo(x - 110, 360); X.closePath(); X.fill(); }
        X.fillStyle = '#3b3542'; for (let x = 100; x < W; x += 200) X.fillRect(x - 14, 0, 28, 10);
        X.fillStyle = '#d8d2c6'; X.fillRect(0, 456, W, 14);
        X.fillStyle = '#a9794a'; X.fillRect(0, 470, W, 190);
        X.strokeStyle = 'rgba(60,30,10,.3)'; X.lineWidth = 2; for (let y = 500; y < H; y += 30) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 30, y1: 380, fl: 1, ty: ['painting', 'painting', 'frame', 'painting', 'frame'], n: [4, 5], s: [0.6, 0.78] },
          { x0: 10, x1: 990, y0: 570, y1: 652, ty: ['statue', 'rope2', 'bench', 'person', 'plant', 'statue', 'person', 'rope2'], n: [4, 6], s: [0.6, 0.82] },
        ] };
      } },
    { id: 'toyshop', name: '장난감 가게', g: 'in',
      bg(v, R) {
        const cs = [['#f8d8e0', '#fdf1d4'], ['#d6ecf8', '#e8f6dc'], ['#efe0fa', '#fde8d4']][v % 3];
        for (let x = 0; x < W; x += 60) { X.fillStyle = cs[(x / 60) % 2]; X.fillRect(x, 0, 60, 480); }
        for (let y = 480; y < H; y += 45) for (let x = 0; x < W; x += 45) { X.fillStyle = ((x + y) / 45) % 2 ? '#f6f2ea' : '#e3a2a2'; X.fillRect(x, y, 45, 45); }
        X.fillStyle = 'rgba(0,0,0,.14)'; X.fillRect(0, 480, W, 6);
      },
      lay(R) {
        const l = R() < 0.5, ax = 220 + (R() - 0.5) * 120, bx = 780 + (R() - 0.5) * 120, ay = l ? 210 : 330, by = l ? 330 : 210;
        return { bv: ri(R, 3), props: [{ t: 'shelf', x: ax, y: ay }, { t: 'shelf', x: bx, y: by }], zones: [
          { x0: ax - 108, x1: ax + 108, y0: ay - 6, y1: ay - 6, ty: ['teddy', 'duck', 'stop', 'blocks', 'robot', 'drum', 'ball'], n: [2, 3], s: [0.55, 0.66] },
          { x0: bx - 108, x1: bx + 108, y0: by - 6, y1: by - 6, ty: ['teddy', 'duck', 'stop', 'blocks', 'robot', 'drum', 'ball'], n: [2, 3], s: [0.55, 0.66] },
          { x0: 10, x1: 990, y0: 14, y1: 420, fl: 1, ty: ['kite', 'balloon', 'star', 'plane2', 'balloon', 'rocket'], n: [2, 4], s: [0.56, 0.74], no: [[ax - 125, ay - 160, ax + 125, ay + 30], [bx - 125, by - 160, bx + 125, by + 30]] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['ttrain', 'blocks', 'ball', 'teddy', 'drum', 'robot', 'car', 'duck', 'stop', 'gift'], n: [7, 9], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'rain', name: '비 오는 거리', g: 'out',
      bg(v, R) {
        const g = [['#8a93a6', '#c6ccd6'], ['#6f7a90', '#aab3c4'], ['#9a9aae', '#d0cdd8']][v % 3];
        grad(g[0], g[1], 0, 200);
        const fc = ['#c9a0a0', '#a0b8c9', '#c9c0a0', '#a8c9a0', '#bfa8c9'];
        for (let i = 0; i < 5; i++) { const x = i * 200; X.fillStyle = fc[(i + v) % 5]; X.fillRect(x, 70 + (i % 2) * 30, 200, 410);
          X.fillStyle = 'rgba(40,50,70,.35)'; X.fillRect(x + 30, 330, 140, 110); X.fillStyle = 'rgba(255,240,200,.3)'; X.fillRect(x + 36, 336, 128, 98);
          X.fillStyle = PAL[(i * 3 + v) % 8]; X.beginPath(); X.moveTo(x + 20, 300); X.lineTo(x + 180, 300); X.lineTo(x + 192, 326); X.lineTo(x + 8, 326); X.closePath(); X.fill(); }
        X.fillStyle = '#9ba1ad'; X.fillRect(0, 480, W, 70); X.fillStyle = '#4a4f5c'; X.fillRect(0, 550, W, 110);
        X.fillStyle = 'rgba(160,180,210,.35)'; for (let i = 0; i < 6; i++) { X.beginPath(); X.ellipse(R() * W, 580 + R() * 70, 50 + R() * 50, 9, 0, 0, TAU); X.fill(); }
        X.strokeStyle = 'rgba(220,235,255,.45)'; X.lineWidth = 2; for (let i = 0; i < 110; i++) { const x = R() * W, y = R() * H; X.beginPath(); X.moveTo(x, y); X.lineTo(x - 5, y + 18); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 110, y1: 290, fl: 1, ty: ['shopsign', 'clock', 'shopsign', 'flag'], n: [2, 4], s: [0.58, 0.74] },
          { x0: 10, x1: 990, y0: 520, y1: 540, ty: ['person', 'mailbox', 'busstop', 'lamppost', 'tlight', 'person', 'umbr'], n: [3, 5], s: [0.58, 0.74] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['car', 'umbr', 'boots', 'snail', 'frog', 'car', 'umbr'], n: [4, 6], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'garden', name: '정원', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 420);
        hills(R, 380, 50, '#a6d48a', 5);
        X.fillStyle = '#86c26e'; X.fillRect(0, 420, W, 240);
        X.fillStyle = '#fbfbff'; for (let x = 6; x < W; x += 36) { X.fillRect(x, 384, 20, 64); X.beginPath(); X.moveTo(x, 384); X.lineTo(x + 10, 372); X.lineTo(x + 20, 384); X.fill(); } X.fillRect(0, 400, W, 8); X.fillRect(0, 428, W, 8);
        X.fillStyle = '#8a5a32'; X.fillRect(0, 470, W, 26);
        const cs = [PAL[0], PAL[7], GOLD, PAL[6], WHITE]; for (let i = 0; i < 60; i++) { X.fillStyle = cs[i % 5]; X.beginPath(); X.arc(R() * W, 466 + R() * 26, 4, 0, TAU); X.fill(); }
        X.strokeStyle = '#6cb352'; X.lineWidth = 3; for (let i = 0; i < 40; i++) { const x = R() * W, y = 520 + R() * 130; X.beginPath(); X.moveTo(x - 5, y); X.lineTo(x, y - 9); X.lineTo(x + 5, y); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 150, fl: 1, nx: 1, ty: ['sun'], n: [0, 1], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 14, y1: 300, fl: 1, ty: ['cloud', 'bird', 'bee', 'butterfly', 'cloud', 'bee'], n: [3, 5], s: [0.58, 0.8] },
          { x0: 10, x1: 990, y0: 470, y1: 500, ty: ['tree', 'bhouse', 'gnome', 'wbarrow', 'bhouse'], n: [2, 3], s: [0.56, 0.68] },
          { x0: 10, x1: 990, y0: 586, y1: 652, ty: ['flower', 'gnome', 'wcan', 'ladybug', 'snail', 'mushroom', 'bucket', 'flower', 'rabbit', 'wbarrow', 'ladybug'], n: [7, 9], s: [0.6, 0.84] },
        ] };
      } },
  ];

  /* ======================= scene generator (pure, deterministic) ======================= */
  const MARGIN = 6, ISC = 1.3;
  function mk(t, x, y, s, c, v, f, Lr, extra) {
    const ty = TY[t];
    return Object.assign({ t, x, y, s, c: c | 0, v: v | 0, f: f | 0, L: Lr, r: ty.r * s, b: y + ty.ft * s }, extra || {});
  }
  function freeAt(x, y, r, objs, avoid, skip) {
    if (x - r < MARGIN || x + r > W - MARGIN || y - r < MARGIN || y + r > H - MARGIN) return false;
    for (let j = 0; j < objs.length; j++) {
      if (j === skip) continue;
      const o = objs[j]; if (o.L !== 1 && !o.sol) continue;
      const dx = x - o.x, dy = y - o.y, rr = r + o.r + 4; if (dx * dx + dy * dy < rr * rr) return false;
    }
    if (avoid) for (const d of avoid) { const dx = x - d.x, dy = y - d.y, rr = r + d.rr + 14; if (dx * dx + dy * dy < rr * rr) return false; }
    return true;
  }
  function hitsNo(z, x, y, r) {
    if (z.no) for (const q of z.no) { const nx = Math.max(q[0], Math.min(q[2], x)), ny = Math.max(q[1], Math.min(q[3], y)); if ((nx - x) * (nx - x) + (ny - y) * (ny - y) < r * r) return true; }
    return false;
  }
  function place(R, z, t, objs, avoid, zi) {
    const ty = TY[t];
    const s = Math.round((z.s[0] + R() * (z.s[1] - z.s[0])) * ISC * 100) / 100, r = ty.r * s;
    const x = z.x1 - z.x0 > 2 * r ? z.x0 + r + R() * (z.x1 - z.x0 - 2 * r) : (z.x0 + z.x1) / 2;
    let y;
    if (z.fl) y = z.y1 - z.y0 > 2 * r ? z.y0 + r + R() * (z.y1 - z.y0 - 2 * r) : (z.y0 + z.y1) / 2;
    else y = z.y0 + R() * (z.y1 - z.y0) - ty.ft * s;
    const c = ty.col ? pick(R, ty.col) : 0, v = ri(R, ty.vn), f = ty.asym && R() < 0.5 ? 1 : 0;
    const p = ty.pn ? ri(R, ty.pn) : 0, n = ty.cn ? ty.cn[0] + ri(R, ty.cn[1] - ty.cn[0] + 1) : 0;
    if (hitsNo(z, x, y, r)) return null;
    if (!freeAt(x, y, r, objs, avoid, -1)) return null;
    return mk(t, x, y, s, c, v, f, 1, { p, n, z: zi, fl: z.fl ? 1 : 0 });
  }
  function farColor(R, o) {
    const ty = TY[o.t]; if (!ty.col) return -1;
    const ok = ty.col.filter((c) => c !== o.c && !NEAR[o.c].includes(c));
    return ok.length ? pick(R, ok) : -1;
  }
  // difficulty dv 0..2 (from the round): which kinds may appear, how small the changed thing may be
  const KIND_EASY = ['rm', 'ex', 'col', 'sz', 'var'], TRICKY = ['mir', 'mv', 'rot', 'txt'];
  const MIN_R = [36, 31, 28], MIN_DET = [40, 35, 32];
  function tryScene(seed, th, K) {
    const R = rng(seed);
    const dv = Math.max(0, Math.min(2, K - 5));
    const T = THEMES[th];
    const lay = T.lay(R);
    const objs = [];
    for (const p of lay.props) {
      const ty = TY[p.t];
      objs.push(mk(p.t, p.x, p.y, p.s || 1, p.c != null ? p.c : pc(R, p.t), ri(R, ty.vn), p.f || 0, 0, { sol: p.sol ? 1 : 0, pd: p.pd ? 1 : 0, p: 0, n: ty.cn ? ty.cn[0] : 0 }));
    }
    lay.zones.forEach((z, zi) => {
      const n = z.n[0] + ri(R, z.n[1] - z.n[0] + 1) + (dv >= 2 && z.n[1] >= 4 ? 1 : 0);
      let placed = 0;
      for (let tries = 0; placed < n && tries < n * 40; tries++) { const o = place(R, z, pick(R, z.ty), objs, null, zi); if (o) { objs.push(o); placed++; } }
    });
    const items = objs.filter((o) => o.L === 1).length;
    if (items < K + 3) return null;
    // differences
    const cands = shuf(R, objs.map((o, i) => i).filter((i) => objs[i].L === 1 || objs[i].pd));
    const diffs = [], cnt = {}, cap = 2, trickyCap = dv >= 2 ? 2 : 1;
    const nEx = K >= 6 ? 1 : (R() < 0.5 ? 1 : 0);
    const minR = MIN_R[dv], minDet = MIN_DET[dv];
    let propD = 0;
    for (const i of cands) {
      if (diffs.length >= K - nEx) break;
      const o = objs[i], ty = TY[o.t], prop = o.L === 0;
      if (prop && propD >= 1) continue;
      const ops = [];
      if (!prop && o.r >= minR) ops.push('rm', 'sz');
      if (ty.col && o.r >= minR && farColor(R, o) >= 0) ops.push('col');
      if (ty.vn > 1 && o.r >= (ty.tx && !prop ? Math.max(40, minDet) : minDet)) ops.push(ty.tx ? 'txt' : 'var');
      if (!prop && ty.pn && o.r >= minDet) ops.push('pat');
      if (!prop && ty.cn && o.r >= minDet) ops.push('cnt');
      if (dv > 0) {
        if (!prop && ty.asym && o.r >= minR) ops.push('mir');
        if (!prop && ty.rt && o.fl && o.r >= minR) ops.push('rot');
        if (!prop && o.r >= minR && o.t !== 'strap') ops.push('mv');
      }
      const allowed = ops.filter((k) => dv > 0 || KIND_EASY.includes(k));
      if (!allowed.length) continue;
      shuf(R, allowed); allowed.sort((a, b) => (cnt[a] || 0) - (cnt[b] || 0));
      for (const op of allowed) {
        if ((cnt[op] || 0) >= (TRICKY.includes(op) ? trickyCap : cap)) continue;
        const d = { o: i, k: op, sd: R() < 0.5 ? 0 : 1, x: o.x, y: o.y, rr: o.r, a: 0 };
        if (op === 'col') d.a = farColor(R, o);
        else if (op === 'var' || op === 'txt') d.a = (o.v + 1 + ri(R, ty.vn - 1)) % ty.vn;
        else if (op === 'mir') d.a = 1;
        else if (op === 'sz') {
          const up = [1.45, 1.4, 1.34][dv], dn = [0.6, 0.64, 0.68][dv];
          const cy = (q) => (o.fl ? o.y : o.b - ty.ft * o.s * q); // grounded things keep their feet on the ground
          const grow = R() < 0.5 && freeAt(o.x, cy(up), o.r * up, objs, null, i) && !hitsNo(lay.zones[o.z] || {}, o.x, cy(up), o.r * up);
          if (grow) d.a = up; else if (o.r * dn >= 20) d.a = dn; else continue;
          const ny = cy(d.a);
          d.y = (o.y + ny) / 2; d.rr = Math.max(o.r, o.r * d.a) + Math.abs(ny - o.y) / 2;
        } else if (op === 'pat') {
          const ch = []; for (let p = 0; p < ty.pn; p++) if (p !== o.p && !((o.p === 1 && p === 3) || (o.p === 3 && p === 1))) ch.push(p);
          if (!ch.length) continue;
          d.a = pick(R, ch);
        } else if (op === 'cnt') {
          const lo = ty.cn[0], hi = ty.cn[1], md = hi - lo >= 3 || dv === 0 ? 2 : 1, ch = [];
          for (let q = lo; q <= hi; q++) if (Math.abs(q - o.n) >= md) ch.push(q);
          if (!ch.length) for (let q = lo; q <= hi; q++) if (q !== o.n) ch.push(q);
          if (!ch.length) continue;
          d.a = pick(R, ch);
        } else if (op === 'rot') {
          d.a = Math.round((R() < 0.5 ? -1 : 1) * (0.42 + R() * 0.2) * 100) / 100;
        } else if (op === 'mv') {
          const z = lay.zones[o.z]; if (!z) continue;
          let ok = false;
          for (let tr = 0; tr < 8 && !ok; tr++) {
            const dist = Math.max(44, o.r * (0.9 + R() * 0.4));
            const ang = z.fl ? R() * TAU : (R() < 0.5 ? 0 : Math.PI);
            const nx = Math.round(o.x + Math.cos(ang) * dist), ny = Math.round(o.y + Math.sin(ang) * dist);
            if (nx - o.r < z.x0 - 1 || nx + o.r > z.x1 + 1) continue;
            if (z.fl && (ny - o.r < z.y0 - 1 || ny + o.r > z.y1 + 1)) continue;
            if (hitsNo(z, nx, ny, o.r) || !freeAt(nx, ny, o.r, objs, null, i)) continue;
            d.a = [nx, ny]; d.x = (o.x + nx) / 2; d.y = (o.y + ny) / 2; d.rr = o.r + dist / 2; ok = true;
          }
          if (!ok) continue;
        }
        if (prop) {
          if (ty.hot) { d.x = o.x + ty.hot[0] * o.s * (o.f ? -1 : 1); d.y = o.y + ty.hot[1] * o.s; d.rr = ty.hot[2] * o.s; }
          else d.rr = Math.min(o.r * 0.72, 150);
        }
        d.rr = Math.max(MINRR, d.rr);
        if (d.x < 20 || d.x > W - 20 || d.y < 20 || d.y > H - 20) continue;
        let clash = false;
        for (const e of diffs) { const dx = d.x - e.x, dy = d.y - e.y, rr = d.rr + e.rr + 14; if (dx * dx + dy * dy < rr * rr) { clash = true; break; } }
        if (clash) continue;
        d.x = Math.round(d.x); d.y = Math.round(d.y); d.rr = Math.round(d.rr);
        diffs.push(d); cnt[op] = (cnt[op] || 0) + 1; if (prop) propD++;
        break;
      }
    }
    // extra things (exist on one side only)
    for (let g = 0; diffs.length < K && g < 300; g++) {
      const zi = ri(R, lay.zones.length), z = lay.zones[zi]; if (z.nx) continue;
      const t = pick(R, z.ty);
      if (TY[t].r * z.s[1] * ISC < minR) continue;
      const o = place(R, z, t, objs, diffs, zi);
      if (!o || o.r < minR) continue;
      diffs.push({ o: -1, k: 'ex', sd: R() < 0.5 ? 0 : 1, x: Math.round(o.x), y: Math.round(o.y), rr: Math.round(Math.max(MINRR, o.r)), a: o });
    }
    if (diffs.length < K) return null;
    shuf(R, diffs);
    for (const d of diffs) { const q = Math.sqrt(48 / d.rr); d.h = Math.round(KH[d.k] * Math.min(1.4, Math.max(0.75, q)) * 100) / 100; }
    return { th, seed, dv, bs: Math.floor(R() * 2147483647), bv: lay.bv, objs, diffs };
  }
  function genScene(seed, th, K) {
    for (let a = 0; a < 30; a++) { const s = tryScene((seed + a * 7919) >>> 0, th, K); if (s) return s; }
    throw new Error('scene failed ' + seed + '/' + th);
  }
  const sceneCache = [];
  function sceneOf(s) {
    const key = s.sd + '.' + s.th + '.' + s.k;
    for (const c of sceneCache) if (c.key === key) return c.sc;
    const sc = genScene(s.sd, s.th, s.k);
    sceneCache.unshift({ key, sc }); if (sceneCache.length > 4) sceneCache.pop();
    return sc;
  }
  function sideObjs(sc, side) {
    sc._side = sc._side || [];
    if (sc._side[side]) return sc._side[side];
    const list = sc.objs.map((o) => Object.assign({}, o));
    const rm = {};
    for (const d of sc.diffs) {
      if (d.sd !== side) continue;
      if (d.k === 'ex') { list.push(Object.assign({}, d.a)); continue; }
      const o = list[d.o];
      if (d.k === 'rm') rm[d.o] = 1;
      else if (d.k === 'col') o.c = d.a;
      else if (d.k === 'var' || d.k === 'txt') o.v = d.a;
      else if (d.k === 'mir') o.f = o.f ? 0 : 1;
      else if (d.k === 'sz') { o.s *= d.a; if (!o.fl) o.y = o.b - TY[o.t].ft * o.s; }
      else if (d.k === 'pat') o.p = d.a;
      else if (d.k === 'cnt') o.n = d.a;
      else if (d.k === 'rot') o.ro = d.a;
      else if (d.k === 'mv') { o.b += d.a[1] - o.y; o.x = d.a[0]; o.y = d.a[1]; }
    }
    const out = list.filter((o, i) => !rm[i]).sort((a, b) => (a.L - b.L) || (a.b - b.b));
    sc._side[side] = out;
    return out;
  }
  function drawObj(o) {
    const ty = TY[o.t];
    X.save(); X.translate(o.x, o.y); if (o.ro) X.rotate(o.ro); X.scale(o.f ? -o.s : o.s, o.s);
    LWv = LWB / o.s;
    ty.draw(PAL[o.c] || PAL[0], o.v | 0, o);
    X.restore();
  }
  function paintScene(c, sc, side) {
    X = c;
    X.save();
    X.beginPath(); X.rect(0, 0, W, H); X.clip();
    X.lineJoin = 'round'; X.lineCap = 'round';
    THEMES[sc.th].bg(sc.bv, rng(sc.bs));
    for (const o of sideObjs(sc, side)) drawObj(o);
    X.restore();
    X = null;
  }

  /* ======================= game logic (pure) ======================= */
  const kFor = (rd, R) => (R <= 1 ? 6 : 5 + Math.round((rd - 1) * 2 / (R - 1)));
  const newSeed = () => Math.floor(Math.random() * 2147483647);
  function themeOrder(opt, R) {
    const ix = THEMES.findIndex((t) => t.id === opt);
    if (ix >= 0) return Array(R).fill(ix);
    let pool = THEMES.map((t, i) => i);
    if (opt === 'in' || opt === 'out' || opt === 'fan') pool = pool.filter((i) => THEMES[i].g === opt);
    const a = shuf(Math.random, pool);
    const out = []; for (let i = 0; i < R; i++) out.push(a[i % a.length]);
    return out;
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, R = +opts.rounds === 5 ? 5 : 3;
    const lim = [60, 90, 120].includes(+opts.time) ? +opts.time : 90;
    const tl = themeOrder(opts.theme || 'mix', R);
    const k = kFor(1, R);
    return { rid: Math.floor(Math.random() * 1e9), n, nm: players.map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 10)),
      R, lim, rd: 1, ph: 'count', tl, th: tl[0], sd: newSeed(), k, f: '-'.repeat(k),
      sc: Array(n).fill(0), hn: Array(n).fill(HINTS), hu: 0, el: 0, rh: [], ss: [], tm: [], last: null };
  }
  function actor(s) {
    if (!s || s.ph !== 'play') return null;
    const a = []; for (let i = 0; i < s.n; i++) a.push(i);
    return a;
  }
  function apply(s, seat, a) {
    if (!a || s.ph !== 'play' || seat < 0 || seat >= s.n) throw new Error('bad action');
    const id = (s.last ? s.last.id : 0) + 1;
    if (a.t === 'hit') {
      const i = a.i | 0;
      if (i < 0 || i >= s.k || s.f[i] !== '-') throw new Error('taken');
      s.f = s.f.slice(0, i) + seat + s.f.slice(i + 1);
      s.sc[seat]++;
      s.last = { id, k: 'hit', s: seat, i };
      return s;
    }
    if (a.t === 'hint') {
      if (s.hn[seat] <= 0) throw new Error('no hints');
      if ((s.el || 0) < HINT_AFTER - 1200) throw new Error('too early');
      const un = []; for (let i = 0; i < s.k; i++) if (s.f[i] === '-') un.push(i);
      if (!un.length) throw new Error('none left');
      s.hn[seat]--;
      if (s.n === 1) s.hu++;
      s.last = { id, k: 'hint', s: seat, i: un[Math.floor(Math.random() * un.length)] };
      return s;
    }
    throw new Error('bad action');
  }
  const allFound = (s) => s.f.indexOf('-') < 0;
  function starsFor(s, ms) {
    if (!allFound(s)) return 0;
    const t = ms / 1000 + s.hu * HINT_SOLO_PEN;
    return t <= s.k * 5.5 ? 3 : t <= s.k * 10 ? 2 : 1;
  }
  function endRound(s, clock) {
    const n = JSON.parse(JSON.stringify(s));
    n.ph = 'end'; n.el = Math.round(Math.min(clock, n.lim * 1000));
    n.rh.push(n.f);
    n.tm.push(Math.round(n.el / 100));
    if (n.n === 1) n.ss.push(starsFor(n, n.el));
    return n;
  }
  function nextRound(s) {
    const n = JSON.parse(JSON.stringify(s));
    if (n.rd >= n.R) { n.ph = 'done'; return n; }
    n.rd++; n.th = n.tl[n.rd - 1]; n.sd = newSeed(); n.k = kFor(n.rd, n.R); n.f = '-'.repeat(n.k);
    n.ph = 'count'; n.el = 0; n.hu = 0;
    return n;
  }
  // AI searchers: each AI looks for one difference at a time; the time depends on level and how hard the difference is
  const AIB = [0, 13000, 8400, 5300];
  function aiPlan(s, sc, lv, R, first, slow) {
    const un = []; for (let i = 0; i < s.k; i++) if (s.f[i] === '-') un.push(i);
    if (!un.length) return { tgt: -1, t: 1e9 };
    let tot = 0; const w = un.map((i) => { const x = 1 / sc.diffs[i].h; tot += x; return x; });
    let r = R() * tot, tgt = un[un.length - 1];
    for (let j = 0; j < un.length; j++) { r -= w[j]; if (r <= 0) { tgt = un[j]; break; } }
    let t = AIB[lv] * sc.diffs[tgt].h * (0.55 + R() * 0.9) * (slow || 1) * (1 + 0.08 * (sc.dv || 0));
    if (first) t += 1400 + R() * 1200;
    if (lv === 1 && R() < 0.3) t += 2500;      // 헛짚어서 잠깐 멈춤
    if (lv === 2 && R() < 0.12) t += 2000;
    return { tgt, t };
  }
  // host-only: advances the round clock, the AI searchers and the phases. Returns a new state or null (no change).
  function hostStep(s, mem, dt, aiLv, R) {
    R = R || Math.random;
    const key = s.rid + '.' + s.rd + '.' + s.ph;
    if (mem.key !== key) { mem.key = key; mem.clock = s.ph === 'play' ? (s.el || 0) : 0; mem.pub = Math.floor(mem.clock / 1000); mem.ai = {}; }
    mem.clock += dt;
    if (s.ph === 'count') return mem.clock >= COUNT_MS ? Object.assign(JSON.parse(JSON.stringify(s)), { ph: 'play', el: 0 }) : null;
    if (s.ph === 'end') return mem.clock >= END_MS ? nextRound(s) : null;
    if (s.ph !== 'play') return null;
    const sc = sceneOf(s);
    let cur = s, changed = false;
    for (let seat = 0; seat < s.n; seat++) {
      const lv = aiLv[seat]; if (!lv) { delete mem.ai[seat]; continue; }
      let m = mem.ai[seat];
      if (!m) m = mem.ai[seat] = aiPlan(cur, sc, lv, R, true);
      if (m.tgt >= 0 && cur.f[m.tgt] !== '-') m = mem.ai[seat] = aiPlan(cur, sc, lv, R, false, 0.6);
      m.t -= dt;
      if (m.t <= 0 && m.tgt >= 0) {
        if (cur.f[m.tgt] === '-') { cur = apply(changed ? cur : JSON.parse(JSON.stringify(cur)), seat, { t: 'hit', i: m.tgt }); changed = true; }
        mem.ai[seat] = aiPlan(cur, sc, lv, R, false);
      }
    }
    if (allFound(cur) || mem.clock >= s.lim * 1000) return endRound(cur, mem.clock);
    const sec = Math.floor(mem.clock / 1000);
    if (changed || sec !== mem.pub) {
      mem.pub = sec;
      if (!changed) cur = JSON.parse(JSON.stringify(cur));
      cur.el = Math.round(mem.clock);
      return cur;
    }
    return null;
  }
  function result(s) {
    if (!s || s.ph !== 'done') return null;
    if (s.n === 1) {
      const tot = s.ss.reduce((a, b) => a + b, 0), max = s.R * 3;
      const lines = s.ss.map((v, i) => (i + 1) + '라운드 ' + THEMES[s.tl[i]].name + ' — ' + '★'.repeat(v) + '☆'.repeat(3 - v) + (v ? ' (' + (s.tm[i] / 10).toFixed(1) + '초)' : ' (시간 초과)'));
      const clear = s.ss.every((v) => v > 0);
      return { winners: clear ? [0] : [], title: (clear ? '클리어! ' : '아쉬워요 · ') + '별 ' + tot + ' / ' + max, text: lines.join('\n') };
    }
    const best = Math.max.apply(null, s.sc);
    const winners = []; for (let i = 0; i < s.n; i++) if (s.sc[i] === best) winners.push(i);
    const order = s.sc.map((v, i) => i).sort((a, b) => s.sc[b] - s.sc[a]);
    const per = (i) => s.rh.map((f) => f.split('').filter((c) => c === String(i)).length).join('·');
    const text = order.map((i, r) => (r + 1) + '위 ' + s.nm[i] + ' — ' + s.sc[i] + '개 (' + per(i) + ')').join('\n');
    return { winners, title: best === 0 ? '아무도 못 찾았어요' : undefined, text };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const CSS = `
.sd-top{position:absolute;left:0;right:0;top:0;height:46px;display:flex;align-items:center;gap:8px;padding:0 12px;z-index:3;pointer-events:none}
.sd-rd{font:700 12px ${MONO};color:#e3ae45;background:rgba(227,174,69,.12);border:1px solid rgba(227,174,69,.45);border-radius:999px;padding:3px 8px;flex:none}
.sd-th{font:700 14px ${FONT};color:#f2e9d8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;flex:0 1 auto}
.sd-dots{display:flex;gap:4px;margin-left:auto;flex:none}
.sd-dots i{width:13px;height:13px;border-radius:50%;border:2px solid rgba(242,233,216,.4);box-sizing:border-box;display:block}
.sd-dots i.on{border-color:#fff;background:var(--c)}
.sd-time{font:700 19px ${MONO};color:#f2e9d8;min-width:54px;text-align:right;flex:none}
.sd-time.low{color:#ee6a55}
.sd-bar{position:absolute;left:0;right:0;bottom:0;height:62px;display:flex;align-items:center;gap:8px;padding:0 10px;z-index:3}
.sd-chips{display:flex;flex-wrap:wrap;gap:4px 5px;flex:1 1 auto;min-width:0;align-content:center;max-height:58px;overflow:hidden}
.sd-chip{display:inline-flex;align-items:center;gap:4px;height:24px;padding:0 7px 0 5px;border-radius:999px;background:#221c2e;border:1.5px solid rgba(242,233,216,.14);font:700 14px ${MONO};color:#f2e9d8;flex:none;box-sizing:border-box}
.sd-chip i{width:11px;height:11px;border-radius:50%;background:var(--c);display:block;box-shadow:0 0 0 1.5px rgba(0,0,0,.3)}
.sd-chip.me{border-color:#e3ae45}
.sd-chip.pop{animation:sdpop .7s}
.sd-chip.miss{animation:sdmiss .5s}
@keyframes sdpop{0%{transform:scale(1.3);background:var(--c)}100%{transform:scale(1)}}
@keyframes sdmiss{0%,100%{transform:none}30%{transform:translateX(-3px)}60%{transform:translateX(3px)}}
.sd-goal{font:600 12px/1.35 ${FONT};color:#ab9fb8;flex:1 1 auto;min-width:0}
.sd-goal b{color:#e3ae45;font-weight:700}
.sd-hint{min-width:84px;padding:0 10px !important;font-size:14px}
.sd-hint[disabled]{opacity:.45}
.sd-zoom{width:48px;padding:0 !important;font:700 14px ${MONO}}
.sd-card{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:4;width:min(300px,86%);box-sizing:border-box;padding:16px 16px 14px;border-radius:18px;background:rgba(23,19,31,.94);border:1px solid rgba(227,174,69,.5);box-shadow:0 10px 30px rgba(0,0,0,.45);color:#f2e9d8;text-align:center;pointer-events:none;font-family:${FONT}}
.sd-card .k{font:700 12px ${MONO};color:#e3ae45;letter-spacing:.06em}
.sd-card h3{margin:4px 0 2px;font:400 30px "Black Han Sans",${FONT}}
.sd-card .s{font-size:13px;color:#ab9fb8;margin-top:2px}
.sd-card .big{font:700 46px ${MONO};color:#e3ae45;line-height:1.1;margin-top:6px}
.sd-card .rows{display:flex;flex-direction:column;gap:5px;margin-top:10px;text-align:left}
.sd-card .row{display:flex;align-items:center;gap:8px;font-size:14px}
.sd-card .row i{width:12px;height:12px;border-radius:50%;background:var(--c);flex:none}
.sd-card .row .n{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sd-card .row .p{font:700 14px ${MONO};color:#8fe3a8}
.sd-card .row .t{font:700 14px ${MONO};color:#f2e9d8;min-width:30px;text-align:right}
.sd-card .stars{font-size:34px;color:#e3ae45;letter-spacing:4px;margin-top:6px}
.sd-tip{position:absolute;left:50%;transform:translate(-50%,6px);top:58px;z-index:5;width:max-content;max-width:calc(100% - 28px);box-sizing:border-box;padding:10px 14px;border-radius:14px;background:rgba(23,19,31,.97);border:1px solid rgba(227,174,69,.55);box-shadow:0 6px 20px rgba(0,0,0,.35);color:#f2e9d8;font:600 13px/1.45 ${FONT};text-align:center;word-break:keep-all;pointer-events:none;opacity:0;transition:opacity .4s,transform .4s}
.sd-tip.on{opacity:1;transform:translate(-50%,0)}
.sd-tip b{display:block;color:#e3ae45;font-weight:800;margin-bottom:2px}
`;
  const ZOOMS = [1, 2, 3];

  function mount(root, api) {
    const h = L.h;
    const styleEl = h('style', { text: CSS }); root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    cv.cv.style.touchAction = 'none';
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const host = () => !api.online || api.isHost;
    const me = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const nameOf = (i) => (api.players[i] && api.players[i].name) || (st && st.nm[i]) || (i + 1) + '번';
    const colOf = (i) => (api.players[i] && api.players[i].color) || '#e3ae45';

    // DOM HUD
    const rdEl = h('span', { class: 'sd-rd' }), thEl = h('span', { class: 'sd-th' }), dotsEl = h('div', { class: 'sd-dots' }), timeEl = h('span', { class: 'sd-time' });
    const top = h('div', { class: 'sd-top' }, rdEl, thEl, dotsEl, timeEl);
    const chips = h('div', { class: 'sd-chips' });
    const hintBtn = h('button', { class: 'btn sd-hint', 'aria-label': '힌트', onclick: () => doHint() });
    const zoomBtn = h('button', { class: 'btn sd-zoom', 'aria-label': '확대 바꾸기', onclick: () => cycleZoom() });
    const bar = h('div', { class: 'sd-bar' }, chips, hintBtn, zoomBtn);
    root.append(top, bar);
    let card = null, cardSig = '';

    let st = null, scene = null, sceneKey = '', rects = [], scl = 1;
    const mem = { key: null, clock: 0, pub: 0, ai: {} };
    let elBase = 0, elAt = performance.now(), phaseAt = performance.now(), phaseKey = '';
    let z = 1, vx = W / 2, vy = H / 2;
    let base = [null, null], sharp = [null, null], sharpSig = '', viewMovedAt = 0;
    let lockUntil = 0, lockDur = 0, missStreak = 0, lastMissAt = 0;
    const misses = [], pops = [], pending = {};
    let hintFx = null, lastId = -1, prevF = '', tip = null, tipShown = false, lastTick = -1;
    const cursor = { x: W / 2, y: H / 2, on: false };

    function phaseClock() { // ms in the current phase (host = authoritative)
      if (!st) return 0;
      if (host()) return mem.key === st.rid + '.' + st.rd + '.' + st.ph ? mem.clock : (st.ph === 'play' ? st.el : 0);
      if (st.ph === 'play') return elBase + (performance.now() - elAt) * SPD();
      return (performance.now() - phaseAt) * SPD();
    }

    /* ----- layout & caches ----- */
    function layout() {
      const Wc = cv.w, Hc = cv.h, topH = 46, barH = 62, gap = 10;
      const a0 = topH + 2, a1 = Hc - barH - 2;
      let iw, ih;
      if (Wc > Hc * 1.15) { // wide window: side by side
        iw = Math.min((Wc - 24 - gap) / 2, (a1 - a0) * W / H); ih = iw * H / W;
        const x = (Wc - iw * 2 - gap) / 2, y = a0 + (a1 - a0 - ih) / 2;
        rects = [{ x, y, w: iw, h: ih }, { x: x + iw + gap, y, w: iw, h: ih }];
      } else {
        ih = Math.min((a1 - a0 - gap) / 2, (Wc - 14) * H / W); iw = ih * W / H;
        const x = (Wc - iw) / 2, y = a0 + Math.max(0, (a1 - a0 - ih * 2 - gap) / 2);
        rects = [{ x, y, w: iw, h: ih }, { x, y: y + ih + gap, w: iw, h: ih }];
      }
      scl = iw / W;
      base = [null, null]; sharp = [null, null]; sharpSig = '';
    }
    cv.onresize = layout;
    function ensureScene() {
      if (!st) return;
      const key = st.sd + '.' + st.th + '.' + st.k;
      if (key === sceneKey) return;
      sceneKey = key; scene = sceneOf(st);
      base = [null, null]; sharp = [null, null]; sharpSig = '';
      z = 1; vx = W / 2; vy = H / 2; cursor.x = W / 2; cursor.y = H / 2;
    }
    function mkCanvas(w, hh) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(hh)); return c; }
    function buildBase(side) {
      const r = rects[side]; if (!r || !scene) return null;
      const f = Math.min(1.6, 2400 / (r.w * cv.dpr));
      const c = mkCanvas(r.w * cv.dpr * f, r.h * cv.dpr * f);
      const g = c.getContext('2d'); g.setTransform(c.width / W, 0, 0, c.height / H, 0, 0);
      paintScene(g, scene, side);
      return c;
    }
    function buildSharp(side) {
      const r = rects[side];
      const c = mkCanvas(r.w * cv.dpr, r.h * cv.dpr), g = c.getContext('2d');
      const k = c.width / W * z;
      g.setTransform(k, 0, 0, k, -(vx - W / (2 * z)) * k, -(vy - H / (2 * z)) * k);
      paintScene(g, scene, side);
      return c;
    }
    function clampView() {
      z = Math.max(1, Math.min(3, z));
      const hw = W / (2 * z), hh = H / (2 * z);
      vx = Math.max(hw, Math.min(W - hw, vx)); vy = Math.max(hh, Math.min(H - hh, vy));
      viewMovedAt = performance.now();
    }
    // logical (picture) → screen, and back
    const toS = (side, lx, ly) => { const r = rects[side]; return { x: r.x + (lx - (vx - W / (2 * z))) * scl * z, y: r.y + (ly - (vy - H / (2 * z))) * scl * z }; };
    const toL = (side, sx, sy) => { const r = rects[side]; return { x: vx - W / (2 * z) + (sx - r.x) / (scl * z), y: vy - H / (2 * z) + (sy - r.y) / (scl * z) }; };
    const sideAt = (x, y) => { for (let i = 0; i < 2; i++) { const r = rects[i]; if (r && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return i; } return -1; };

    /* ----- input ----- */
    const ptrs = new Map();
    let gest = null;
    function onDown(e) {
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      const p = cv.local(e);
      cursor.on = false;
      ptrs.set(e.pointerId, { x: p.x, y: p.y, sx: p.x, sy: p.y, t: performance.now() });
      if (ptrs.size === 1) gest = { moved: false, pinch: false, side: sideAt(p.x, p.y) };
      else if (ptrs.size === 2) startPinch();
    }
    function startPinch() {
      const a = [...ptrs.values()];
      const mx = (a[0].x + a[1].x) / 2, my = (a[0].y + a[1].y) / 2;
      let side = sideAt(mx, my); if (side < 0) side = gest && gest.side >= 0 ? gest.side : 0;
      gest = { moved: true, pinch: true, side, d0: Math.max(10, Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y)), z0: z, m: toL(side, mx, my) };
    }
    function onMove(e) {
      const q = ptrs.get(e.pointerId); if (!q) return;
      const p = cv.local(e);
      const dx = p.x - q.x, dy = p.y - q.y; q.x = p.x; q.y = p.y;
      if (!gest) return;
      if (gest.pinch && ptrs.size >= 2) {
        const a = [...ptrs.values()];
        const mx = (a[0].x + a[1].x) / 2, my = (a[0].y + a[1].y) / 2;
        z = gest.z0 * Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) / gest.d0;
        z = Math.max(1, Math.min(3, z));
        const r = rects[gest.side];
        vx = gest.m.x - (mx - r.x) / (scl * z) + W / (2 * z); vy = gest.m.y - (my - r.y) / (scl * z) + H / (2 * z);
        clampView();
        return;
      }
      if (!gest.moved && Math.hypot(p.x - q.sx, p.y - q.sy) > 9) gest.moved = true;
      if (gest.moved && !gest.pinch && z > 1.001) { vx -= dx / (scl * z); vy -= dy / (scl * z); clampView(); }
    }
    function onUp(e) {
      const q = ptrs.get(e.pointerId); if (!q) return;
      ptrs.delete(e.pointerId);
      if (gest && !gest.moved && !gest.pinch && ptrs.size === 0 && performance.now() - q.t < 700) {
        const side = sideAt(q.x, q.y);
        if (side >= 0) { const l = toL(side, q.x, q.y); tapAt(side, l.x, l.y); }
      }
      if (ptrs.size === 0) gest = null;
      else if (gest && gest.pinch) gest = { moved: true, pinch: false, side: gest.side }; // one finger left: no tap
    }
    function onWheel(e) {
      e.preventDefault();
      const p = cv.local(e), side = sideAt(p.x, p.y); if (side < 0) return;
      zoomAt(side, p.x, p.y, e.deltaY < 0 ? 1.25 : 0.8);
    }
    function zoomAt(side, sx, sy, f) {
      const m = toL(side, sx, sy), r = rects[side];
      z = Math.max(1, Math.min(3, z * f));
      vx = m.x - (sx - r.x) / (scl * z) + W / (2 * z); vy = m.y - (sy - r.y) / (scl * z) + H / (2 * z);
      clampView(); syncZoomBtn();
    }
    function cycleZoom() {
      const i = ZOOMS.findIndex((v) => v > z + 0.05);
      const nz = i < 0 ? 1 : ZOOMS[i];
      const cx = cursor.on ? cursor.x : vx, cy = cursor.on ? cursor.y : vy;
      z = nz; vx = cx; vy = cy; clampView(); syncZoomBtn(); api.sfx('click');
    }
    function syncZoomBtn() { const t = (Math.round(z * 10) / 10) + '×'; if (zoomBtn.textContent !== t) zoomBtn.textContent = t; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('wheel', onWheel, { passive: false });
    cv.cv.addEventListener('contextmenu', noCtx);
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'tap') { if (!cursor.on) { cursor.on = true; cursor.x = vx; cursor.y = vy; return; } tapAt(0, cursor.x, cursor.y); }
      else if (id === 'hint') doHint();
      else if (id === 'zin' || id === 'zout') { if (!cursor.on) { cursor.x = vx; cursor.y = vy; } const s0 = toS(0, cursor.x, cursor.y); zoomAt(0, s0.x, s0.y, id === 'zin' ? 1.5 : 1 / 1.5); }
    }) : () => {};

    const canPlay = () => st && st.ph === 'play' && me() >= 0;
    function tapAt(side, lx, ly) {
      if (!canPlay() || !scene) return;
      const now = performance.now();
      if (now < lockUntil) { api.buzz(20); return; }
      const slop = 12 / (scl * z);
      let best = -1, bd = 1e18;
      scene.diffs.forEach((d, i) => { const dx = lx - d.x, dy = ly - d.y, d2 = dx * dx + dy * dy, lim = d.rr + slop; if (d2 <= lim * lim && d2 < bd) { bd = d2; best = i; } });
      if (best >= 0) {
        if (st.f[best] !== '-' || pending[best]) return; // already circled: no penalty
        pending[best] = { t: now, n: 1 };
        missStreak = 0;
        api.sfx('pop'); api.buzz(18);
        api.act({ t: 'hit', i: best });
        return;
      }
      if (now - lastMissAt > 6000) missStreak = 0;
      missStreak++; lastMissAt = now;
      lockDur = Math.min(4000, 1500 + (missStreak - 1) * 1000);
      lockUntil = now + lockDur;
      misses.push({ side, x: lx, y: ly, t: now });
      api.sfx('thud'); api.buzz(60);
      const c = chips.querySelector('.sd-chip.me'); if (c) { c.classList.remove('miss'); void c.offsetWidth; c.classList.add('miss'); }
    }
    function hintReady() { return canPlay() && st.hn[me()] > 0 && phaseClock() >= HINT_AFTER && st.f.indexOf('-') >= 0; }
    function doHint() {
      if (!canPlay()) return;
      if (st.hn[me()] <= 0) { api.toast('힌트를 다 썼어요'); return; }
      if (phaseClock() < HINT_AFTER) { api.toast('힌트는 시작 ' + (HINT_AFTER / 1000) + '초 뒤부터 쓸 수 있어요'); return; }
      api.sfx('whoosh'); api.act({ t: 'hint' });
    }

    /* ----- host loop: clock, AI, phases ----- */
    function aiLv() { return api.players.map((p) => (p && p.ai ? (p.lv || 2) : 0)); }
    function hostFrame(dtMs) {
      if (!st || !host()) return;
      let ns = null;
      try { ns = hostStep(st, mem, dtMs, aiLv()); } catch (e) { console.error(e); }
      if (ns) api.setState(ns);
    }

    /* ----- HUD ----- */
    function fmt(ms) { const s = Math.max(0, Math.ceil(ms / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
    let chipSig = '';
    function renderHud() {
      if (!st) return;
      rdEl.textContent = st.rd + '/' + st.R;
      thEl.textContent = THEMES[st.th].name;
      const ds = st.f.split('').map((c) => (c === '-' ? '' : colOf(+c))).join(',');
      if (dotsEl.dataset.sig !== ds) {
        dotsEl.dataset.sig = ds; dotsEl.innerHTML = '';
        st.f.split('').forEach((c) => dotsEl.append(h('i', { class: c === '-' ? '' : 'on', style: c === '-' ? {} : { '--c': colOf(+c) } })));
      }
      const m = me();
      const sig = st.n + '|' + st.sc.join(',') + '|' + m + '|' + api.players.map((p) => p && p.color).join(',') + '|' + (st.n === 1 ? st.ss.join('') + st.k : '');
      if (sig !== chipSig) {
        chipSig = sig; chips.innerHTML = '';
        if (st.n === 1) {
          const k = st.k;
          chips.append(h('div', { class: 'sd-goal' }, h('b', { text: '★★★ ' + Math.floor(k * 5.5) + '초' }), ' · ★★ ' + (k * 10) + '초 안에 모두', h('br'), '모은 별 ' + st.ss.reduce((a, b) => a + b, 0) + '개'));
        } else {
          for (let i = 0; i < st.n; i++) chips.append(h('span', { class: 'sd-chip' + (i === m ? ' me' : ''), title: nameOf(i), 'data-s': i, style: { '--c': colOf(i) } }, h('i'), String(st.sc[i])));
        }
      }
      const showHint = m >= 0;
      hintBtn.hidden = !showHint;
      if (showHint) {
        const left = st.hn[m];
        const t = '힌트 ' + left;
        if (hintBtn.textContent !== t) hintBtn.textContent = t;
        const dis = !hintReady();
        if (hintBtn.disabled !== dis) hintBtn.disabled = dis;
      }
      syncZoomBtn();
    }
    function renderTime() {
      if (!st) return;
      let t = '', low = false;
      if (st.ph === 'play') { const left = st.lim * 1000 - phaseClock(); t = fmt(left); low = left < 10500; }
      else if (st.ph === 'count') t = fmt(st.lim * 1000);
      else if (st.ph === 'end' || st.ph === 'done') t = fmt(st.lim * 1000 - st.el);
      if (timeEl.textContent !== t) timeEl.textContent = t;
      timeEl.classList.toggle('low', low);
      if (st.ph === 'play' && hintBtn.disabled === hintReady() && me() >= 0) hintBtn.disabled = !hintReady();
    }
    function setCard(sig, build) {
      if (sig === cardSig) return;
      cardSig = sig;
      if (card) { card.remove(); card = null; }
      if (build) { card = build(); root.appendChild(card); }
    }
    function renderCard() {
      if (!st) return;
      const pc = phaseClock();
      if (st.ph === 'count') {
        const n = Math.max(1, Math.ceil((COUNT_MS - pc) / 1000));
        setCard('c' + st.rid + st.rd + n, () => h('div', { class: 'sd-card' },
          h('div', { class: 'k', text: '라운드 ' + st.rd + ' / ' + st.R }),
          h('h3', { text: THEMES[st.th].name }),
          h('div', { class: 's', text: '다른 곳 ' + st.k + '개를 찾아요' + (st.n === 1 ? '' : ' · 먼저 찾으면 내 것!') }),
          h('div', { class: 'big', text: String(n) })));
        if (n !== lastTick) { lastTick = n; api.sfx('tick'); }
      } else if (st.ph === 'end') {
        const left = Math.max(1, Math.ceil((END_MS - pc) / 1000));
        const lastR = st.rd >= st.R;
        setCard('e' + st.rid + st.rd + left, () => {
          const f = st.f;
          if (st.n === 1) {
            const v = st.ss[st.ss.length - 1] || 0;
            return h('div', { class: 'sd-card' },
              h('div', { class: 'k', text: '라운드 ' + st.rd + ' 끝' }),
              h('div', { class: 'stars', text: '★'.repeat(v) + '☆'.repeat(3 - v) }),
              h('div', { class: 's', text: (allFound(st) ? '모두 찾았어요 · ' + (st.el / 1000).toFixed(1) + '초' : '시간 초과 · ' + f.split('').filter((c) => c !== '-').length + ' / ' + st.k + '개') + (st.hu ? ' (힌트 +' + st.hu * HINT_SOLO_PEN + '초)' : '') }),
              h('div', { class: 's', text: lastR ? '결과를 보여 줄게요… ' + left : '다음 라운드 ' + left }));
          }
          const order = st.sc.map((v, i) => i).sort((a, b) => st.sc[b] - st.sc[a]);
          return h('div', { class: 'sd-card' },
            h('div', { class: 'k', text: '라운드 ' + st.rd + ' 끝' + (allFound(st) ? '' : ' · 시간 초과') }),
            h('div', { class: 'rows' }, order.map((i) => {
              const got = f.split('').filter((c) => c === String(i)).length;
              return h('div', { class: 'row' }, h('i', { style: { '--c': colOf(i) } }), h('span', { class: 'n', text: nameOf(i) + (i === me() ? ' (나)' : '') }), h('span', { class: 'p', text: got ? '+' + got : '' }), h('span', { class: 't', text: String(st.sc[i]) }));
            })),
            h('div', { class: 's', style: { marginTop: '8px' }, text: lastR ? '결과를 보여 줄게요… ' + left : '다음 라운드 ' + left }));
        });
      } else setCard('', null);
    }

    /* ----- drawing ----- */
    function ring(x, y, r, col, w, dash) {
      ctx.setLineDash(dash || []);
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.lineWidth = w + 3; ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.stroke();
      ctx.lineWidth = w; ctx.strokeStyle = col; ctx.stroke();
      ctx.setLineDash([]);
    }
    function draw(now) {
      const Wc = cv.w, Hc = cv.h;
      ctx.clearRect(0, 0, Wc, Hc);
      const bg = ctx.createLinearGradient(0, 0, 0, Hc); bg.addColorStop(0, '#1d1727'); bg.addColorStop(1, '#17131f');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, Wc, Hc);
      if (!st || !scene || !rects.length) return;
      const hideImgs = st.ph === 'count';
      // sharp redraw once the view settles
      const sig = sceneKey + '|' + z.toFixed(3) + '|' + vx.toFixed(1) + '|' + vy.toFixed(1) + '|' + rects[0].w;
      if (z > 1.01 && sig !== sharpSig && now - viewMovedAt > 140 && !hideImgs) { sharp = [buildSharp(0), buildSharp(1)]; sharpSig = sig; }
      for (let side = 0; side < 2; side++) {
        const r = rects[side];
        ctx.save();
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(r.x, r.y, r.w, r.h, 8) : ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
        if (hideImgs) {
          ctx.fillStyle = '#2e2640'; ctx.fillRect(r.x, r.y, r.w, r.h);
          ctx.fillStyle = 'rgba(227,174,69,.12)'; ctx.font = '700 ' + Math.round(r.h * 0.35) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('?', r.x + r.w / 2, r.y + r.h / 2);
        } else {
          if (!base[side]) base[side] = buildBase(side);
          if (z > 1.01 && sharp[side] && sig === sharpSig) ctx.drawImage(sharp[side], r.x, r.y, r.w, r.h);
          else { const b = base[side], k = b.width / W; ctx.drawImage(b, (vx - W / (2 * z)) * k, (vy - H / (2 * z)) * k, W / z * k, H / z * k, r.x, r.y, r.w, r.h); }
          drawMarks(side, now);
        }
        ctx.restore();
        ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(227,174,69,.7)';
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(r.x - 1, r.y - 1, r.w + 2, r.h + 2, 9) : ctx.rect(r.x - 1, r.y - 1, r.w + 2, r.h + 2); ctx.stroke();
        if (z > 1.01) { // mini map: where the zoomed view is
          const mw = 54, mh = mw * H / W, mx = r.x + r.w - mw - 6, my = r.y + 6;
          ctx.fillStyle = 'rgba(23,19,31,.6)'; ctx.fillRect(mx, my, mw, mh);
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.strokeRect(mx + (vx - W / (2 * z)) / W * mw, my + (vy - H / (2 * z)) / H * mh, mw / z, mh / z);
        }
      }
      // penalty veil
      if (now < lockUntil && st.ph === 'play') {
        const left = (lockUntil - now) / 1000;
        for (const r of rects) { ctx.fillStyle = 'rgba(30,20,40,.35)'; ctx.fillRect(r.x, r.y, r.w, r.h); }
        const r0 = rects[0], r1 = rects[1];
        const cx = (r0.x + r1.x + r1.w) / 2, cy = r0.y === r1.y ? r0.y + r0.h / 2 : (r0.y + r0.h + r1.y) / 2;
        const t = '틀렸어요! ' + left.toFixed(1) + '초';
        ctx.font = '700 15px ' + FONT; const tw = ctx.measureText(t).width + 28;
        ctx.fillStyle = 'rgba(238,106,85,.95)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(cx - tw / 2, cy - 17, tw, 34, 17) : ctx.rect(cx - tw / 2, cy - 17, tw, 34); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, cx, cy + 1);
        const w = tw - 24; ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.fillRect(cx - w / 2, cy + 12, w * Math.max(0, (lockUntil - now) / lockDur), 2);
      }
    }
    function drawMarks(side, now) {
      const k = scl * z;
      // found circles
      scene.diffs.forEach((d, i) => {
        const c = st.f[i];
        const p = toS(side, d.x, d.y), rr = d.rr * k + 4;
        if (c !== '-') {
          const pp = pops.find((q) => q.i === i);
          let sc = 1; if (pp) { const a = Math.min(1, (now - pp.t) / 320); sc = 1 + (1 - a) * (1 - a) * 0.7; }
          ring(p.x, p.y, rr * sc, colOf(+c), 3.5);
        } else if (pending[i]) ring(p.x, p.y, rr, colOf(me()), 3, [6, 5]);
        else if (st.ph === 'end' || st.ph === 'done') { const a = 0.55 + 0.45 * Math.sin(now / 160); ctx.globalAlpha = a; ring(p.x, p.y, rr, '#ee6a55', 3, [7, 5]); ctx.globalAlpha = 1; }
      });
      // name tags of fresh finds
      for (const q of pops) {
        const age = now - q.t; if (age > 1500) continue;
        const d = scene.diffs[q.i], p = toS(side, d.x, d.y), rr = d.rr * k + 4;
        const t = q.s === me() ? '찾았다!' : nameOf(q.s);
        ctx.globalAlpha = Math.min(1, (1500 - age) / 300);
        ctx.font = '700 12px ' + FONT; const tw = ctx.measureText(t).width + 12;
        const y = p.y - rr - 12 - Math.min(1, age / 400) * 6;
        ctx.fillStyle = colOf(q.s); ctx.beginPath(); ctx.roundRect ? ctx.roundRect(p.x - tw / 2, y - 10, tw, 20, 10) : ctx.rect(p.x - tw / 2, y - 10, tw, 20); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, p.x, y + 1);
        ctx.globalAlpha = 1;
      }
      // misses
      for (const m of misses) {
        const age = now - m.t; if (age > 900 || m.side !== side) continue;
        const p = toS(side, m.x, m.y), s = 11;
        ctx.globalAlpha = 1 - age / 900; ctx.lineCap = 'round';
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(p.x - s, p.y - s); ctx.lineTo(p.x + s, p.y + s); ctx.moveTo(p.x + s, p.y - s); ctx.lineTo(p.x - s, p.y + s); ctx.stroke();
        ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 4; ctx.stroke();
        ctx.globalAlpha = 1;
      }
      // hint ring
      if (hintFx && now - hintFx.t < 4500 && st.ph === 'play' && st.f[hintFx.i] === '-') {
        const p = toS(side, hintFx.x, hintFx.y), base = hintFx.r * k;
        const a = (now - hintFx.t) / 650;
        ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a * Math.PI);
        ring(p.x, p.y, base * (1 + 0.08 * Math.sin(a * TAU)), '#e3ae45', 4, [10, 7]);
        ctx.globalAlpha = 1;
      }
      // keyboard / pad cursor
      if (cursor.on && st.ph === 'play') {
        const p = toS(side, cursor.x, cursor.y);
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(p.x, p.y, 12, 0, TAU); ctx.moveTo(p.x - 20, p.y); ctx.lineTo(p.x - 6, p.y); ctx.moveTo(p.x + 6, p.y); ctx.lineTo(p.x + 20, p.y); ctx.moveTo(p.x, p.y - 20); ctx.lineTo(p.x, p.y - 6); ctx.moveTo(p.x, p.y + 6); ctx.lineTo(p.x, p.y + 20); ctx.stroke();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.stroke();
      }
    }

    /* ----- frame ----- */
    function frame(rdt, now) {
      if (!st) return;
      hostFrame(rdt * 1000 * SPD());
      // keyboard / pad cursor movement
      if (api.input && canPlay()) {
        const ax = api.input.axis('left', 'right'), ay = api.input.axis('up', 'down');
        if (ax || ay) {
          if (!cursor.on) { cursor.on = true; cursor.x = vx; cursor.y = vy; }
          const sp = 460 / z;
          cursor.x = Math.max(0, Math.min(W, cursor.x + ax * sp * rdt)); cursor.y = Math.max(0, Math.min(H, cursor.y + ay * sp * rdt));
          if (z > 1.01) { const hw = W / (2 * z) * 0.8, hh = H / (2 * z) * 0.8; if (cursor.x < vx - hw) vx = cursor.x + hw; if (cursor.x > vx + hw) vx = cursor.x - hw; if (cursor.y < vy - hh) vy = cursor.y + hh; if (cursor.y > vy + hh) vy = cursor.y - hh; clampView(); }
        }
      }
      // pending claims: resend if lost, clear when decided
      for (const k in pending) {
        const i = +k, p = pending[k];
        if (!st || st.ph !== 'play') { delete pending[k]; continue; }
        if (st.f[i] !== '-') { delete pending[k]; continue; }
        if (now - p.t > 900) { if (p.n >= 4) { delete pending[k]; continue; } p.t = now; p.n++; api.act({ t: 'hit', i }); }
      }
      while (misses.length && now - misses[0].t > 1000) misses.shift();
      while (pops.length && now - pops[0].t > 1600) pops.shift();
      // first-play tip (once per device), during the first countdown
      if (!tipShown && st.ph === 'count' && st.rd === 1 && me() >= 0) { tipShown = true; tip = firstTip(); }
      if (tip && st.ph === 'play' && phaseClock() > 2500) tip.hide();
      renderTime(); renderCard();
    }
    function firstTip() {
      try { if (localStorage.getItem('lounge.tip.spotdiff')) return null; localStorage.setItem('lounge.tip.spotdiff', '1'); } catch (e) { /* storage blocked */ }
      const el = h('div', { class: 'sd-tip', role: 'status' }, h('b', { text: '처음이라면 이렇게!' }),
        h('div', { text: '위·아래 그림에서 다른 곳을 톡! (어느 그림이든 OK)' }),
        h('div', { text: '두 손가락으로 크게 · 틀리면 잠깐 못 눌러요' }));
      root.appendChild(el);
      requestAnimationFrame(() => el.classList.add('on'));
      let gone = false;
      const hide = () => { if (gone) return; gone = true; el.classList.remove('on'); setTimeout(() => el.remove(), 450); };
      const tm = setTimeout(hide, 7000);
      return { hide, remove() { clearTimeout(tm); gone = true; el.remove(); } };
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });
    layout();

    return {
      update(next) {
        if (!next) return;
        const was = st; st = next;
        const pk = st.rid + '.' + st.rd + '.' + st.ph;
        if (pk !== phaseKey) {
          phaseKey = pk; phaseAt = performance.now(); lastTick = -1;
          if (st.ph === 'play') { api.sfx('whoosh'); lockUntil = 0; missStreak = 0; }
          if (st.ph === 'end' && was && was.ph === 'play') api.sfx(allFound(st) ? 'chip' : 'lose');
          if (st.ph === 'count') { hintFx = null; for (const k in pending) delete pending[k]; misses.length = 0; pops.length = 0; }
        }
        if (st.ph === 'play' && (!was || was.el !== st.el || was.ph !== 'play')) { elBase = st.el || 0; elAt = performance.now(); }
        ensureScene();
        // fresh finds → pop animation + who found it
        if (was && was.rid === st.rid && was.rd === st.rd && was.f.length === st.f.length) {
          for (let i = 0; i < st.f.length; i++) {
            if (was.f[i] === '-' && st.f[i] !== '-') {
              const s = +st.f[i];
              pops.push({ i, s, t: performance.now() });
              const mine = s === me();
              if (mine) { api.sfx('chip'); }
              else {
                api.sfx('click');
                if (pending[i]) api.toast('아깝다! ' + nameOf(s) + ' 님이 먼저 찾았어요');
              }
              const c = chips.querySelector('.sd-chip[data-s="' + s + '"]'); if (c) { c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop'); }
            }
          }
        }
        const lid = st.last ? st.last.id : 0;
        if (lastId < 0) lastId = lid; // first render: don't replay old events
        else if (lid !== lastId) {
          lastId = lid;
          if (st.last.k === 'hint' && st.last.s === me() && scene && st.ph === 'play') {
            const d = scene.diffs[st.last.i];
            // a loose ring around the area (not the exact spot)
            const R = rng(st.sd + st.last.id * 31);
            const ang = R() * TAU, off = d.rr * (0.4 + R() * 0.5);
            hintFx = { i: st.last.i, x: d.x + Math.cos(ang) * off, y: d.y + Math.sin(ang) * off, r: d.rr * 2.3 + 24, t: performance.now() };
            api.toast(st.n === 1 ? '이 근처에 있어요! (+' + HINT_SOLO_PEN + '초)' : '이 근처에 있어요!');
          }
        }
        prevF = st.f;
        renderHud(); renderTime(); renderCard();
        void prevF;
      },
      destroy() {
        stopLoop(); offIn();
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('wheel', onWheel); cv.cv.removeEventListener('contextmenu', noCtx);
        if (tip) tip.remove(); if (card) card.remove();
        top.remove(); bar.remove(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ st, scene, rects, z, vx, vy, mem, tapAt, toS, lock: lockUntil }),
    };
  }

  /* ======================= registration ======================= */
  L.register({
    id: 'spotdiff', name: '다른 그림 찾기 대결', tag: '눈썰미 레이스', cat: '파티',
    blurb: '똑같아 보이는 두 그림에서 다른 곳을 먼저 찾는 사람이 임자! 장소 30곳, 매번 새 그림을 모두 동시에 봐요. 혼자 하면 별 3개 타임어택. 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#1f5a6e',
    icon: '<rect x="8" y="5" width="40" height="20" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><rect x="8" y="31" width="40" height="20" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="19" cy="15" r="4" fill="currentColor"/><circle cx="19" cy="41" r="4" fill="currentColor"/><path d="M36 10l-5 9h10z" fill="currentColor"/><circle cx="36" cy="41" r="7" fill="none" stroke="currentColor" stroke-width="2.5"/>',
    minPlayers: 1, maxPlayers: 6, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'left', label: '커서 왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '커서 오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'up', label: '커서 위', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '커서 아래', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'tap', label: '여기 콕! (찍기)', keys: ['Space', 'Enter'], pad: ['a'] },
      { id: 'hint', label: '힌트', keys: ['KeyH'], pad: ['y'] },
      { id: 'zin', label: '확대', keys: ['KeyE', 'Equal', 'NumpadAdd'], pad: ['rb'] },
      { id: 'zout', label: '축소', keys: ['KeyQ', 'Minus', 'NumpadSubtract'], pad: ['lb'] },
    ],
    options: [
      { id: 'rounds', label: '라운드', choices: [{ v: 3, label: '3라운드' }, { v: 5, label: '5라운드' }], def: 3 },
      { id: 'time', label: '라운드 시간', choices: [{ v: 60, label: '60초' }, { v: 90, label: '90초' }, { v: 120, label: '120초' }], def: 90 },
      { id: 'theme', label: '장소', choices: [{ v: 'mix', label: '무작위(섞어서)' }, { v: 'in', label: '실내만' }, { v: 'out', label: '바깥만' }, { v: 'fan', label: '모험·상상' }].concat(THEMES.map((t) => ({ v: t.id, label: t.name }))), def: 'mix' },
    ],
    quick: [
      '위·아래 두 그림은 거의 같지만 다른 곳이 5~7군데 있어요. 장소 30곳, 매번 새 그림! 모두 같은 그림을 동시에 봐요.',
      '다른 곳을 찾으면 어느 그림이든 그 자리를 톡! 맞으면 두 그림에 내 색 동그라미가 생겨요.',
      '먼저 찾은 사람이 1점. 라운드 3번(또는 5번) 합계가 가장 많은 사람이 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '위·아래 두 그림에서 서로 다른 곳을 남보다 먼저 찾아요. 한 곳 = 1점.',
        '라운드마다 새 그림(장소)이 나오고, 다른 곳은 5개에서 시작해 마지막 라운드엔 7개까지 늘어요.',
        '라운드가 갈수록 어려워져요: 물건이 많아지고, 바뀐 곳이 작아지고, 찾기 까다로운 종류(위치·기울기·무늬·개수·글자)가 섞여요.',
        '모든 라운드가 끝났을 때 점수가 가장 높은 사람이 승리(같으면 공동 승리).',
      ] },
      { h: '찾기', p: [
        '다른 곳이 보이면 위 그림이든 아래 그림이든 그 자리를 톡! 맞으면 두 그림 모두에 내 색 동그라미가 그려져요.',
        '이미 누가 찾은 곳(동그라미)은 다시 눌러도 점수가 없지만, 벌칙도 없어요.',
        '틀린 곳을 누르면 1.5초 동안 못 눌러요. 연달아 틀리면 2.5초, 3.5초… 길어져요(최대 4초). 마구 누르기 금지!',
        '모두 찾거나 시간(기본 90초)이 끝나면 라운드 끝. 못 찾은 곳은 빨간 점선으로 알려 줘요.',
      ] },
      { h: '어떤 게 달라요?', p: [
        '1라운드: 없어진 물건 / 생긴 물건, 색이 바뀐 것, 크기가 바뀐 것, 모양이 살짝 바뀐 것(꽃잎 수, 창문 불빛, 표정 등).',
        '2라운드부터 더: 좌우가 뒤집힌 것, 자리를 옮긴 것, 기울어진 것(액자·간판), 무늬(줄무늬·물방울), 개수(촛불·양초·전등 수), 시계 바늘·글자·숫자.',
        '옮겨진 물건은 원래 자리나 새 자리 어디를 눌러도 정답이에요.',
        '배경(벽·하늘·바닥 무늬)은 두 그림이 늘 똑같아요. 물건만 보면 돼요.',
      ] },
      { h: '확대 · 힌트', p: [
        '두 손가락으로 벌리면 확대, 한 손가락으로 끌면 이동. 두 그림이 같이 움직여요. 오른쪽 아래 「1×」 버튼으로 1× → 2× → 3× 바꿀 수도 있어요.',
        '힌트: 한 게임에 3번. 라운드 시작 8초 뒤부터 쓸 수 있고, 아직 아무도 못 찾은 곳 근처를 금색 점선으로 보여 줘요(나만 보여요).',
        'PC: 마우스 클릭으로 찍고 휠로 확대해요. 키보드·패드는 방향키(스틱)로 커서를 옮기고 스페이스(Ⓐ)로 찍어요. H=힌트, E/Q=확대/축소. 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '혼자 하기 (별 모으기)', p: [
        '혼자 하면 타임어택! 라운드마다 다른 곳을 모두 찾은 시간으로 별을 받아요.',
        '★★★ = 개수 × 5.5초 안 (6개면 33초), ★★ = 개수 × 10초 안, ★ = 시간 안에 모두. 힌트를 쓰면 한 번에 +10초로 계산해요.',
        '모든 라운드에서 별을 1개 이상 받으면 클리어!',
      ] },
      { h: '예시', p: [
        '거실 그림: 위 그림의 쿠션은 빨강인데 아래는 파랑 → 아무 쿠션이나 톡 → 「찾았다!」 +1점.',
        '→ 그런데 AI 2가 0.5초 먼저 찾았다면 「아깝다!」 — 그 점수는 AI 2의 것이에요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '모두 같은 그림을 동시에 보는 경주라서 한 폰에는 한 명만: 혼자 하면 나머지 자리는 AI예요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로 해요.',
        '장소 30곳: 거실·부엌·교실·도서관·지하철·꽃집·빵집·생일 파티·미술관·장난감 가게 / 시장·놀이공원·겨울 마을·바닷가·농장·숲속 캠핑·정글·사막 오아시스·놀이터·야경 도시·비 오는 거리·정원 / 바닷속·우주·우주 정거장·공룡 시대·성 안·해적선·로봇 공장·할로윈 밤.',
        '기본은 「무작위(섞어서)」: 라운드마다 다른 장소가 나와요. 「실내만·바깥만·모험·상상」이나 한 장소만 고를 수도 있어요. 같은 장소라도 물건 배치·색·종류가 매번 새로 만들어져요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 혼자 찾을 때 한 곳에 쉬움은 15초쯤(가끔 헤맴), 보통은 10초쯤, 어려움은 6~7초쯤 걸려요. 뒤 라운드일수록 AI도 조금 느려져요.',
      ] },
    ],
    init, actor, apply,
    // never scheduled by core (realtime: the host view runs the AI searchers); kept pure for test tools
    ai(s) { if (!s || s.ph !== 'play') return null; const un = []; for (let i = 0; i < s.k; i++) if (s.f[i] === '-') un.push(i); return un.length ? { t: 'hit', i: un[Math.floor(Math.random() * un.length)] } : null; },
    result, mount,
    _t: { W, H, TY, THEMES, PAL, NEAR, rng, genScene, tryScene, sceneOf, sideObjs, paintScene, kFor, init, actor, apply, hostStep, endRound, nextRound, result, aiPlan, COUNT_MS, END_MS, HINT_AFTER },
  });
})();
