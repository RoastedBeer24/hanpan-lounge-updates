/* 컬링 — 2팀, 엔드당 팀별 8스톤. 결정적 고정 스텝 물리(얼음 마찰, 속도 의존 컬, TOI 보정 탄성 충돌):
   apply가 끝까지 시뮬레이션하고 last={id,pre,shot}을 남기며, 뷰는 같은 Sim으로 재생한다.
   단위: m·s. x = 시트 가로(오른쪽 +), y = 가까운 호그 라인(릴리스 지점)에서 먼 하우스 쪽으로.
   스윕은 던질 때 고르는 행동의 일부(안 함/살짝/세게) — 던진 스톤이 다른 스톤에 닿거나 티 라인을 지나기 전까지 적용. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }
  /* The first-play tutorial opens right away, maybe while an AI moves first: then the steps about my own controls
     had nothing to point at. If it was watched to the end like that, replay just those steps (sels) the first time
     my controls are up. Call the returned tick(mine) every frame. */
  function tutCatchUp(root, api, id, sels) {
    let missed = false, last = false, done = false;
    return (mine) => {
      if (done) return;
      const card = root.querySelector('.tut-layer .tut-card');
      if (card) {
        const m = /(\d+)\s*\/\s*(\d+)/.exec((card.querySelector('.label') || {}).textContent || '');
        last = !!m && m[1] === m[2];
        if (!mine) missed = true;
        return;
      }
      if (!missed) { if (mine) done = true; return; }
      if (!last) { done = true; return; }   // skipped: don't bring it back
      if (!mine) return;
      done = true;
      setTimeout(() => {
        const def = L.games[id], full = def && def.tutorial;
        if (!full || root.querySelector('.tut-layer')) return;
        def.tutorial = full.filter((s) => sels.includes(s.sel));
        try { api.tutorial(); } finally { def.tutorial = full; }
      }, 400);
    };
  }

  /* ---------- sheet geometry (WCF) ---------- */
  const HW = 2.375, R = 0.145, HOG = 21.945, TEE = HOG + 6.401, HR = 1.829, BACK = TEE + 1.829;
  const RINGS = [1.829, 1.219, 0.610, 0.152];
  const MASS = 19.96; // kg — equal masses: cancels out of the impulse, kept for documentation
  /* ice: constant kinetic deceleration + lateral curl a⊥ = KC·spin/(v+VC) (curls more as the stone slows) */
  const DT = 1 / 200, A0 = 0.0785, KC = 0.012, VC = 0.5, E = 0.92, VSTOP = 0.003, MAXT = 80;
  const SWA = [1, 0.95, 0.9], SWC = [1, 0.85, 0.7]; // sweeping: less friction (farther) and less curl
  const VMIN = 1.4, VMAX = 4.2, NS = 8;
  const r3 = (v) => Math.round(v * 1000) / 1000, r4 = (v) => Math.round(v * 10000) / 10000;
  void MASS;

  /* ---------- deterministic simulation (+ − × ÷ √ only) ---------- */
  function Sim(pre, shot) {
    const n = pre.length + 1;
    this.n = n; this.d = n - 1;
    this.x = new Float64Array(n); this.y = new Float64Array(n); this.vx = new Float64Array(n); this.vy = new Float64Array(n);
    this.tm = new Int8Array(n); this.on = new Uint8Array(n); this.sp = new Float64Array(n);
    for (let i = 0; i < pre.length; i++) { this.x[i] = +pre[i][0]; this.y[i] = +pre[i][1]; this.tm[i] = pre[i][2]; this.on[i] = 1; }
    const d = this.d;
    this.on[d] = 1; this.tm[d] = shot.tm | 0; this.vx[d] = +shot.vx; this.vy[d] = +shot.vy; this.sp[d] = shot.t === -1 ? -1 : 1;
    this.sw = shot.sw | 0; this.hit = false; this.hits = 0; this.hitV = 0; this.swp = 0;
    this.outs = []; this.steps = 0; this.done = false;
  }
  Sim.prototype.step = function () {
    const x = this.x, y = this.y, vx = this.vx, vy = this.vy, on = this.on, sp = this.sp, n = this.n, d = this.d;
    let moving = 0; this.swp = 0;
    for (let i = 0; i < n; i++) {
      if (!on[i]) continue;
      const sx = vx[i], sy = vy[i];
      if (sx === 0 && sy === 0) continue;
      const v = Math.sqrt(sx * sx + sy * sy);
      let a = A0, c = KC;
      if (i === d && this.sw && !this.hit && y[i] < TEE) { a *= SWA[this.sw]; c *= SWC[this.sw]; this.swp = 1; }
      const ns = v - a * DT;
      if (ns <= VSTOP) { vx[i] = 0; vy[i] = 0; continue; }
      const ux = sx / v, uy = sy / v, al = sp[i] === 0 ? 0 : c * sp[i] / (v + VC) * DT;
      const nx = ux * ns + uy * al, ny = uy * ns - ux * al, l = Math.sqrt(nx * nx + ny * ny);
      vx[i] = nx / l * ns; vy[i] = ny / l * ns;
      x[i] += vx[i] * DT; y[i] += vy[i] * DT;
      moving++;
    }
    // stone–stone: rewind to the contact instant inside the step, exchange the normal impulse, advance again
    const D = 2 * R, D2 = D * D;
    for (let i = 0; i < n - 1; i++) {
      if (!on[i]) continue;
      for (let j = i + 1; j < n; j++) {
        if (!on[j]) continue;
        if (vx[i] === 0 && vy[i] === 0 && vx[j] === 0 && vy[j] === 0) continue;
        let dx = x[j] - x[i], dy = y[j] - y[i];
        if (dx > D || dx < -D || dy > D || dy < -D) continue;
        const d2 = dx * dx + dy * dy;
        if (d2 >= D2) continue;
        const wx = vx[j] - vx[i], wy = vy[j] - vy[i], dw = dx * wx + dy * wy;
        if (dw < 0) {
          const ww = wx * wx + wy * wy;
          let tau = 0;
          if (ww > 1e-12) { const disc = dw * dw - ww * (d2 - D2); tau = (Math.sqrt(disc) + dw) / ww; if (tau > DT) tau = DT; if (tau < 0) tau = 0; }
          x[i] -= vx[i] * tau; y[i] -= vy[i] * tau; x[j] -= vx[j] * tau; y[j] -= vy[j] * tau;
          dx = x[j] - x[i]; dy = y[j] - y[i];
          let l = Math.sqrt(dx * dx + dy * dy); if (l < 1e-9) l = 1e-9;
          const nx = dx / l, ny = dy / l, rel = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny;
          if (rel > 0) {
            const jm = rel * (1 + E) / 2;
            vx[i] -= jm * nx; vy[i] -= jm * ny; vx[j] += jm * nx; vy[j] += jm * ny;
            if (i === d || j === d) this.hit = true;
            this.hits++; if (rel > this.hitV) this.hitV = rel;
          }
          x[i] += vx[i] * tau; y[i] += vy[i] * tau; x[j] += vx[j] * tau; y[j] += vy[j] * tau;
        }
        dx = x[j] - x[i]; dy = y[j] - y[i];
        const e2 = dx * dx + dy * dy;
        if (e2 < D2) {
          const l = Math.sqrt(e2);
          if (l > 1e-9) { const p = (D - l) / 2 + 1e-6, nx = dx / l, ny = dy / l; x[i] -= nx * p; y[i] -= ny * p; x[j] += nx * p; y[j] += ny * p; }
        }
      }
    }
    // out of play: touching a side line, or completely past the back line
    for (let i = 0; i < n; i++) {
      if (!on[i]) continue;
      if (x[i] + R > HW || x[i] - R < -HW) { on[i] = 0; vx[i] = vy[i] = 0; this.outs.push([i, 's']); }
      else if (y[i] - R > BACK) { on[i] = 0; vx[i] = vy[i] = 0; this.outs.push([i, 'b']); }
    }
    this.steps++;
    let still = true;
    for (let i = 0; i < n; i++) if (on[i] && (vx[i] !== 0 || vy[i] !== 0)) { still = false; break; }
    if (still || this.steps > MAXT / DT) {
      for (let i = 0; i < n; i++) { vx[i] = 0; vy[i] = 0; }
      // a delivered stone that touched nothing must come to rest completely past the far hog line
      if (on[d] && !this.hit && y[d] - R < HOG) { on[d] = 0; this.outs.push([d, 'h']); }
      this.done = true;
    }
    void moving;
  };
  Sim.prototype.run = function () { while (!this.done) this.step(); return this; };
  Sim.prototype.stones = function () {
    const out = [];
    for (let i = 0; i < this.n; i++) if (this.on[i]) out.push([r3(this.x[i]), r3(this.y[i]), this.tm[i]]);
    return out;
  };
  function simulate(pre, shot) { return new Sim(pre, shot).run(); }

  /* ---------- rules ---------- */
  const tdist = (x, y) => Math.sqrt(x * x + (y - TEE) * (y - TEE));
  const inHouse = (x, y) => tdist(x, y) - R <= HR;
  // free guard zone: between the hog line and the tee line, not in the house
  const inFGZ = (x, y) => !inHouse(x, y) && y - R < TEE && y + R > HOG;
  function scoreEnd(st) {
    const hs = st.filter((q) => inHouse(q[0], q[1])).map((q) => [tdist(q[0], q[1]), q[2]]).sort((a, b) => a[0] - b[0]);
    if (!hs.length) return { t: -1, p: 0 };
    const t = hs[0][1];
    let p = 0;
    for (const q of hs) { if (q[1] !== t) break; p++; }
    return { t, p };
  }
  const teamSeats = (s, t) => { const a = []; for (let i = t; i < s.n; i += 2) a.push(i); return a; };
  const throwTeam = (s, ti) => (ti % 2 === 0 ? 1 - s.ham : s.ham);
  // j = the team's stone number in this end (0..7). Positions: 리드 1–2, 세컨드 3–4, 서드 5–6, 스킵 7–8.
  // 4 players (2 vs 2): real delivery order — each player throws two stones in a row (A1: 1–2·5–6, A2: 3–4·7–8),
  // teams still alternate every stone. 2–3 players: unchanged (a solo team throws all 8; in 3p the pair alternates per stone).
  const POS = ['리드', '세컨드', '서드', '스킵'];
  const posOf = (ti) => POS[Math.floor(Math.floor(ti / 2) / 2)];
  function throwerOf(s, ti) {
    const t = throwTeam(s, ti), m = teamSeats(s, t), j = Math.floor(ti / 2);
    return m[(s.n === 4 ? Math.floor(j / 2) : j) % m.length];
  }
  const tot = (s, t) => s.sc[t].reduce((a, b) => a + b, 0);

  function init(players, opts) {
    const o = opts || {};
    const ne = [4, 6, 8].includes(+o.ends) ? +o.ends : 4;
    return { n: players.length, nm: players.map((p) => String(p.name || '').slice(0, 10)), ne, fg: o.fgz === 0 ? 0 : 1,
      e: 0, ti: 0, ham: Math.random() < 0.5 ? 0 : 1, st: [], sc: [[], []], ph: 'p', seq: 0, last: null };
  }
  function actor(s) { return s.ph === 'p' ? throwerOf(s, s.ti) : null; }
  function apply(s, seat, a) {
    if (s.ph !== 'p' || actor(s) !== seat) throw new Error('not your turn');
    if (!a || a.type !== 'throw') throw new Error('bad action');
    const ang = +a.a, v = +a.v, t = +a.t, sw = +a.sw;
    if (!isFinite(ang) || !isFinite(v) || (t !== 1 && t !== -1) || ![0, 1, 2].includes(sw)) throw new Error('bad throw');
    const an = U.clamp(ang, -0.2, 0.2), vv = U.clamp(v, VMIN, VMAX);
    const tm = throwTeam(s, s.ti), pre = s.st.map((q) => q.slice());
    const shot = { vx: r4(vv * Math.sin(an)), vy: r4(vv * Math.cos(an)), t, sw, tm };
    const prot = [];
    if (s.fg && s.ti < 5) pre.forEach((q, i) => { if (q[2] !== tm && inFGZ(q[0], q[1])) prot.push(i); });
    const sim = simulate(pre, shot);
    let ev = '', st = sim.stones();
    const dOut = sim.outs.find((o) => o[0] === sim.d);
    if (dOut) ev = dOut[1];
    if (prot.some((i) => !sim.on[i])) { ev = 'fgz'; st = pre.map((q) => q.slice()); }
    const k = s.ti, e = s.e;
    s.st = st; s.ti++; s.seq++;
    let er = null;
    if (s.ti >= 2 * NS) {
      const r = scoreEnd(s.st);
      er = { t: r.t, p: r.p };
      s.sc[0].push(r.t === 0 ? r.p : 0); s.sc[1].push(r.t === 1 ? r.p : 0);
      if (r.t >= 0) s.ham = 1 - r.t; // the team that did not score gets the hammer; a blank end keeps it
      s.e++; s.ti = 0; s.st = [];
      if (s.e >= s.ne && tot(s, 0) !== tot(s, 1)) s.ph = 'e';
    }
    s.last = { id: s.seq, s: seat, tm, pre, shot, ev, er, k, e };
    return s;
  }
  function teamName(s, t) { return teamSeats(s, t).map((i) => s.nm[i] || (i + 1) + '번').join('·'); }
  function result(s) {
    if (s.ph !== 'e') return null;
    const a = tot(s, 0), b = tot(s, 1), w = a > b ? 0 : 1;
    const ext = s.e - s.ne;
    return { winners: teamSeats(s, w), title: s.n > 2 ? teamName(s, w) + ' 팀 승리' : undefined,
      text: teamName(s, 0) + ' ' + a + ' : ' + b + ' ' + teamName(s, 1) + '\n' + s.ne + '엔드' + (ext > 0 ? ' + 연장 ' + ext + '엔드' : '') };
  }

  /* ---------- AI ---------- */
  let TAB = null;
  function tables() {
    if (TAB) return TAB;
    // draw table: release speed → rest point (distance ρ and curl angle φ, for an in-turn from the centre line)
    const draw = [];
    for (let v = 1.85; v <= 2.45; v += 0.005) {
      const sm = new Sim([], { vx: 0, vy: v, t: 1, sw: 0, tm: 0 }); sm.run();
      const x = sm.x[0], y = sm.y[0];
      draw.push([v, Math.sqrt(x * x + y * y), Math.atan2(x, y)]);
    }
    // hit paths: polar samples along the path for a few takeout weights
    const hit = {};
    for (const v of [2.45, 2.8, 3.2, 3.7]) {
      const sm = new Sim([], { vx: 0, vy: v, t: 1, sw: 0, tm: 0 }), pts = [];
      while (!sm.done && sm.on[0]) { sm.step(); if (sm.steps % 10 === 0) { const x = sm.x[0], y = sm.y[0]; pts.push([Math.sqrt(x * x + y * y), Math.atan2(x, y)]); } }
      hit[v] = pts;
    }
    return (TAB = { draw, hit });
  }
  function interp(arr, key, val, out) {
    if (val <= arr[0][key]) return arr[0][out];
    for (let i = 1; i < arr.length; i++) if (arr[i][key] >= val) { const a = arr[i - 1], b = arr[i], f = (val - a[key]) / (b[key] - a[key] || 1); return a[out] + (b[out] - a[out]) * f; }
    return arr[arr.length - 1][out];
  }
  function solveDraw(tx, ty, t) {
    const T = tables().draw, rho = Math.sqrt(tx * tx + ty * ty), th = Math.atan2(tx, ty);
    return { a: th - t * interp(T, 1, rho, 2), v: interp(T, 1, rho, 0) };
  }
  function solveHit(tx, ty, t, v) {
    const P = tables().hit[v], rho = Math.sqrt(tx * tx + ty * ty), th = Math.atan2(tx, ty);
    return { a: th - t * interp(P, 0, rho, 1), v };
  }
  function evalPos(s, st, me, rem) {
    const r = scoreEnd(st), pts = r.t === me ? r.p : r.t >= 0 ? -r.p : 0, ham = s.ham;
    const lastEnd = s.e >= s.ne - 1;
    if (rem === 0) {
      if (lastEnd) {
        const m = tot(s, me) - tot(s, 1 - me) + pts;
        return m > 0 ? 20 + m : m < 0 ? -20 + m : (r.t < 0 ? (ham === me ? 1 : -1) : (pts > 0 ? -1 : 1)) * 2;
      }
      let v = pts;
      if (r.t < 0) v += ham === me ? 0.35 : -0.35;
      else if (pts === 1 && ham === me) v -= 0.3;
      return v;
    }
    let v = 0.85 * U.clamp(pts, -3, 3);
    let mh = 0, th = 0;
    const hs = st.map((q) => [tdist(q[0], q[1]), q]).filter((z) => z[0] - R <= HR).sort((a, b) => a[0] - b[0]);
    for (const z of hs) (z[1][2] === me ? mh++ : th++);
    v += 0.22 * (mh - th);
    const early = s.ti < 9;
    for (const q of st) {
      if (!inFGZ(q[0], q[1])) continue;
      const ax = Math.abs(q[0]), mine = q[2] === me;
      let g = 0;
      if (early) g = ham === me ? (ax > 0.5 && ax < 1.7 ? 0.18 : 0.04) : (ax < 0.6 ? 0.24 : 0.08);
      v += mine ? g : -g * 0.6;
    }
    // counting stones covered by a guard are hard to remove
    if (pts > 0) for (let i = 0; i < Math.min(pts, 2); i++) {
      const q = hs[i][1];
      if (st.some((g) => g !== q && Math.abs(g[0] - q[0]) < 0.3 && q[1] - g[1] > 0.35 && q[1] - g[1] < 7)) v += 0.22;
    }
    return v;
  }
  const LVA = { 1: { a: 0.0065, v: 0.026, n: 12, ms: 120 }, 2: { a: 0.004, v: 0.016, n: 40, ms: 170 }, 3: { a: 0.0018, v: 0.007, n: 200, ms: 260 } };
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 0.5;
  function candidates(s, me) {
    const out = [], st = s.st;
    const draw = (x, y) => { for (const t of [1, -1]) out.push(Object.assign(solveDraw(x, y, t), { t, k: 'd' })); };
    [[0, TEE], [0.4, TEE], [-0.4, TEE], [0, TEE - 0.55], [0, TEE + 0.6], [0.85, TEE - 0.25], [-0.85, TEE - 0.25], [0, TEE - 1.25], [0.6, TEE + 1.0], [-0.6, TEE + 1.0]].forEach((p) => draw(p[0], p[1]));
    [[0, TEE - 3.4], [0, HOG + 2.3], [0.3, TEE - 4.4], [-0.3, TEE - 4.4], [1.1, TEE - 3.1], [-1.1, TEE - 3.1]].forEach((p) => draw(p[0], p[1]));
    for (const q of st) {
      if (q[1] > HOG - 1 && q[1] < TEE + 1.2) { const fy = q[1] + 2 * R + 0.03; if (fy < BACK - 0.2) draw(q[0], fy); }
      if (inFGZ(q[0], q[1])) for (const dx of [-0.2, 0.2]) { const ty = Math.min(TEE + 0.3, q[1] + 1.6); draw(q[0] + dx, ty); }
    }
    for (const q of st) {
      if (q[2] === me && !inFGZ(q[0], q[1])) continue;
      for (const v of [2.8, 3.2, 3.7]) for (const off of [0, R * 0.6, -R * 0.6]) for (const t of [1, -1]) {
        out.push(Object.assign(solveHit(q[0] + off, q[1], t, v), { t, k: 'h' }));
      }
      if (inHouse(q[0], q[1])) for (const t of [1, -1]) out.push(Object.assign(solveHit(q[0], q[1], t, 2.45), { t, k: 'h' }));
    }
    return out;
  }
  function ai(s, seat, lv) {
    const P = LVA[lv] || LVA[2], me = throwTeam(s, s.ti), rem = 2 * NS - s.ti - 1, t0 = Date.now();
    let cs = U.shuffle(candidates(s, me));
    if (cs.length > P.n) cs = cs.slice(0, P.n);
    const ev = (c, da, dv) => {
      const a = U.clamp(c.a + da, -0.2, 0.2), v = U.clamp(c.v + dv, VMIN, VMAX), tm = me;
      const sh = { vx: v * Math.sin(a), vy: v * Math.cos(a), t: c.t, sw: 0, tm };
      const pre = s.st;
      const prot = [];
      if (s.fg && s.ti < 5) pre.forEach((q, i) => { if (q[2] !== tm && inFGZ(q[0], q[1])) prot.push(i); });
      const sm = simulate(pre, sh);
      if (prot.some((i) => !sm.on[i])) return evalPos(s, pre, me, rem) - 0.4;
      return evalPos(s, sm.stones(), me, rem);
    };
    const sc = [];
    for (const c of cs) { if (Date.now() - t0 > P.ms && sc.length > 4) break; sc.push({ c, v: ev(c, 0, 0) }); }
    sc.sort((a, b) => b.v - a.v);
    let pick = sc[0];
    if (lv >= 3) {
      // prefer shots that still work with a small miss
      let best = null;
      for (const z of sc.slice(0, 5)) {
        if (Date.now() - t0 > P.ms + 60) break;
        const r = (z.v * 2 + ev(z.c, P.a * 1.5, P.v) + ev(z.c, -P.a * 1.5, -P.v)) / 4;
        if (!best || r > best.v) best = { c: z.c, v: r };
      }
      if (best) pick = best;
    } else if (lv <= 1 && sc.length > 2 && Math.random() < 0.35) pick = sc[1 + U.rand(Math.min(4, sc.length - 1))];
    const c = pick ? pick.c : solveDraw(0, TEE, 1);
    const t = pick ? c.t : 1;
    return { type: 'throw', a: U.clamp(c.a + gauss() * P.a, -0.2, 0.2), v: U.clamp(c.v + gauss() * P.v, VMIN, VMAX), t, sw: 0 };
  }

  /* ---------- weight slider mapping (shared by view & tests) ---------- */
  const DIST = (v) => v * v / (2 * A0);
  const VOF = (rho) => Math.sqrt(2 * A0 * rho);
  const Z1 = 45, Z2 = 75, VT0 = VOF(30.6);
  function wToV(u) {
    if (u <= Z1) return VOF(22.35 + (u / Z1) * (26.45 - 22.35));
    if (u <= Z2) return VOF(26.45 + ((u - Z1) / (Z2 - Z1)) * (30.6 - 26.45));
    return VT0 + ((u - Z2) / (100 - Z2)) * (VMAX - VT0);
  }
  const zoneOf = (u) => (u <= Z1 ? 0 : u <= Z2 ? 1 : 2);
  const ZN = ['가드', '드로우', '테이크아웃'], ZC = ['#5bb3e6', '#5fd3a0', '#ee6a55'];
  void DIST;

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, sim = null, simAcc = 0, animLast = null, shownKey = '', dirty = true, fast = false;
    let finTimer = 0, animTimer = 0, cardTimer = 0, sentAt = 0, cardEl = null, ghosts = [], flash = null, lastHits = 0, prevOn = null;
    let set = null, setSeat = -1, drag = null, prevKey = '', prevStop = null, zoom = false, camY = 0, camK = 1;
    try { zoom = !!U.store.get('curling.zoom', false); } catch (e) {}
    const top = L.h('div', { class: 'hud top cu-board', style: { padding: '6px 8px 0', display: 'block' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px', display: 'flex', flexDirection: 'column', alignItems: 'stretch', gap: '6px' } });
    const zbtn = L.h('button', { class: 'btn sm cu-zoom', style: { position: 'absolute', right: '6px', minHeight: '44px', minWidth: '44px', padding: '0 8px', zIndex: 3, fontSize: '12px', lineHeight: 1.1 },
      'aria-label': '하우스 확대', onclick() { zoom = !zoom; try { U.store.set('curling.zoom', zoom); } catch (e) {} api.sfx('click'); api.buzz(8); zbtn.innerHTML = zoom ? '전체<br>보기' : '하우스<br>확대'; layout(); } });
    zbtn.innerHTML = zoom ? '전체<br>보기' : '하우스<br>확대';
    root.append(top, bot, zbtn);
    // invisible boxes over the house / guard zone / broom for the first-play tutorial spotlight
    const spHouse = tutSpot(root, 'cu-house'), spFgz = tutSpot(root, 'cu-fgz'), spBroom = tutSpot(root, 'cu-broom');
    const color = (i) => (api.players[i] ? api.players[i].color : '#fff');
    const tcol = (t) => color(t);
    const V = { top: 60, bot: 500, w: 360 };

    /* ---- per-player settings (this phone) ---- */
    function nameOf(i) { return api.players[i] ? api.players[i].name : ''; }
    function mySet() {
      const a = st ? actor(st) : null;
      if (a == null) return null;
      if (setSeat !== a || !set) {
        setSeat = a; let v = null;
        try { v = U.store.get('curling.set.' + nameOf(a), null); } catch (e) {}
        if (!v || !isFinite(v.bx) || !isFinite(v.by) || !isFinite(v.u)) v = { bx: -1.15, by: TEE, u: 58, t: 1, sw: 0 };
        set = { bx: U.clamp(v.bx, -HW + 0.1, HW - 0.1), by: U.clamp(v.by, HOG - 2, BACK + 0.4), u: U.clamp(Math.round(v.u), 0, 100), t: v.t === -1 ? -1 : 1, sw: [0, 1, 2].includes(v.sw) ? v.sw : 0 };
      }
      return set;
    }
    function saveSet() { if (set && setSeat >= 0) try { U.store.set('curling.set.' + nameOf(setSeat), set); } catch (e) {} }

    /* ---- camera ---- */
    function viewRange() { return zoom ? [TEE - HR - 0.7, BACK + 0.55] : [HOG - 0.5, BACK + 0.6]; }
    function layout() {
      const th = top.getBoundingClientRect().height || 50, bh = bot.getBoundingClientRect().height || 60;
      V.top = th + 4; V.bot = cv.h - bh - 4; V.w = cv.w;
      const [y0, y1] = viewRange();
      camK = Math.max(8, Math.min((cv.w - 64) / (2 * HW + 0.2), (V.bot - V.top) / (y1 - y0)));
      if (!sim) camY = restCam();
      zbtn.style.top = (V.top + 2) + 'px';
      dirty = true;
    }
    cv.onresize = layout;
    function restCam() { const [y0, y1] = viewRange(), half = (V.bot - V.top) / 2 / camK; return Math.min((y0 + y1) / 2, y1 - half); }
    const SX = (x) => cv.w / 2 + x * camK;
    const SY = (y) => (V.top + V.bot) / 2 - (y - camY) * camK;
    const WY = (py) => camY - (py - (V.top + V.bot) / 2) / camK;
    const WX = (px) => (px - cv.w / 2) / camK;

    /* ---- drawing ---- */
    let pebble = null;
    function makePebble() {
      const c = document.createElement('canvas'); c.width = 96; c.height = 96;
      const g = c.getContext('2d'), im = g.createImageData(96, 96);
      for (let i = 0; i < im.data.length; i += 4) { const n = Math.random(); im.data[i] = 120; im.data[i + 1] = 150; im.data[i + 2] = 180; im.data[i + 3] = n < 0.06 ? 40 : n < 0.5 ? 6 : 0; }
      g.putImageData(im, 0, 0);
      return ctx.createPattern(c, 'repeat');
    }
    function drawSheet() {
      const k = camK, x0 = SX(-HW), x1 = SX(HW);
      const bg = ctx.createLinearGradient(0, 0, cv.w, 0);
      bg.addColorStop(0, '#120f19'); bg.addColorStop(0.5, '#1d1828'); bg.addColorStop(1, '#120f19');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, cv.w, cv.h);
      // boards
      ctx.fillStyle = '#3a2a3e'; ctx.fillRect(x0 - 7, 0, 7, cv.h); ctx.fillRect(x1, 0, 7, cv.h);
      ctx.fillStyle = '#e3ae45'; ctx.fillRect(x0 - 2, 0, 2, cv.h); ctx.fillRect(x1, 0, 2, cv.h);
      // ice
      const ig = ctx.createLinearGradient(x0, 0, x1, 0);
      ig.addColorStop(0, '#cfdfe9'); ig.addColorStop(0.5, '#eef5f9'); ig.addColorStop(1, '#cfdfe9');
      ctx.fillStyle = ig; ctx.fillRect(x0, 0, x1 - x0, cv.h);
      if (!pebble) pebble = makePebble();
      ctx.save(); ctx.translate(0, (SY(0) % 96)); ctx.fillStyle = pebble; ctx.fillRect(x0, -96, x1 - x0, cv.h + 192); ctx.restore();
      // house
      const cx = SX(0), cy = SY(TEE);
      const RC = ['#2f5f9e', '#eef5f9', '#c8463c', '#eef5f9'];
      RINGS.forEach((r, i) => { ctx.fillStyle = RC[i]; ctx.beginPath(); ctx.arc(cx, cy, r * k, 0, 7); ctx.fill(); });
      ctx.strokeStyle = 'rgba(20,30,50,.25)'; ctx.lineWidth = 1;
      RINGS.forEach((r) => { ctx.beginPath(); ctx.arc(cx, cy, r * k, 0, 7); ctx.stroke(); });
      // lines
      const line = (y, w, c) => { const py = SY(y); if (py < -10 || py > cv.h + 10) return; ctx.fillStyle = c; ctx.fillRect(x0, py - w / 2, x1 - x0, w); };
      line(TEE, Math.max(1, 0.013 * k), '#33405a');
      line(BACK, Math.max(1, 0.013 * k), '#33405a');
      line(HOG, Math.max(2, 0.1 * k), '#c8463c');
      line(0, Math.max(2, 0.1 * k), '#c8463c');
      ctx.fillStyle = '#33405a'; ctx.fillRect(cx - Math.max(0.5, 0.006 * k), SY(BACK + 1.83), Math.max(1, 0.013 * k), SY(-6.4) - SY(BACK + 1.83));
      // hack
      const hy = SY(TEE + 3.658);
      if (hy > -20) { ctx.fillStyle = '#2b2333'; ctx.fillRect(cx - 0.25 * k, hy - 0.1 * k, 0.18 * k, 0.2 * k); ctx.fillRect(cx + 0.07 * k, hy - 0.1 * k, 0.18 * k, 0.2 * k); }
      // free guard zone tint
      if (st && st.fg) {
        ctx.save(); ctx.beginPath(); ctx.rect(x0, SY(TEE), x1 - x0, SY(HOG) - SY(TEE)); ctx.moveTo(cx + HR * k, cy); ctx.arc(cx, cy, HR * k, 0, Math.PI * 2, true); ctx.clip('evenodd');
        ctx.fillStyle = 'rgba(227,174,69,.07)'; ctx.fillRect(x0, SY(TEE), x1 - x0, SY(HOG) - SY(TEE)); ctx.restore();
      }
      // labels
      ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = 'rgba(200,70,60,.9)'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      const hp = SY(HOG); if (hp > V.top + 10 && hp < V.bot) ctx.fillText('호그 라인', x0 + 4, hp - 3);
      const rp = SY(0); if (rp > V.top + 10 && rp < V.bot) ctx.fillText('릴리스', x0 + 4, rp - 3);
    }
    function drawStone(x, y, t, alpha, hl) {
      const k = camK, px = SX(x), py = SY(y), r = R * k;
      if (py < -r * 2 || py > cv.h + r * 2) return;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = 'rgba(10,20,40,.28)'; ctx.beginPath(); ctx.ellipse(px + r * 0.15, py + r * 0.3, r * 1.04, r * 0.95, 0, 0, 7); ctx.fill();
      const g = ctx.createRadialGradient(px - r * 0.35, py - r * 0.35, r * 0.1, px, py, r);
      g.addColorStop(0, '#b9b6bd'); g.addColorStop(0.7, '#77727c'); g.addColorStop(1, '#4b4651');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill();
      ctx.fillStyle = tcol(t); ctx.beginPath(); ctx.arc(px, py, r * 0.62, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = Math.max(1, r * 0.12); ctx.beginPath(); ctx.moveTo(px, py + r * 0.05); ctx.lineTo(px, py - r * 0.55); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.arc(px - r * 0.2, py - r * 0.25, r * 0.18, 0, 7); ctx.fill();
      if (hl) { ctx.strokeStyle = hl; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py, r + 3, 0, 7); ctx.stroke(); }
      ctx.globalAlpha = 1;
    }
    function drawBroom(bx, by, t, active) {
      const px = SX(bx), py = SY(by);
      ctx.strokeStyle = 'rgba(23,19,31,.6)'; ctx.lineWidth = 2;
      ctx.fillStyle = active ? '#e3ae45' : 'rgba(227,174,69,.92)';
      ctx.beginPath(); ctx.ellipse(px, py, 15, 7, 0, 0, 7); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(23,19,31,.55)'; ctx.lineWidth = 1;
      for (let i = -10; i <= 10; i += 4) { ctx.beginPath(); ctx.moveTo(px + i, py - 5); ctx.lineTo(px + i, py + 5); ctx.stroke(); }
      ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(px + 4, py - 3); ctx.lineTo(px + 20, py - 26); ctx.stroke();
      // curl hint: small arc toward where the stone will fall
      ctx.strokeStyle = 'rgba(23,19,31,.75)'; ctx.lineWidth = 2.5;
      const sx = px - t * 22, sy = py + 22;
      ctx.beginPath(); ctx.moveTo(sx, sy + 26); ctx.quadraticCurveTo(sx, sy, sx + t * 18, sy - 6); ctx.stroke();
      ctx.fillStyle = 'rgba(23,19,31,.75)'; ctx.beginPath(); ctx.moveTo(sx + t * 24, sy - 8); ctx.lineTo(sx + t * 13, sy - 12); ctx.lineTo(sx + t * 15, sy - 1); ctx.closePath(); ctx.fill();
    }
    function drawMini() {
      const mw = Math.min(18, (cv.w / 2 - HW * camK - 14) * 0.5);
      if (mw < 9) return;
      const y0 = V.top + 10, y1 = V.bot - 6, mx = 8, k = (y1 - y0) / (BACK + 1.2 + 1), MY = (y) => y1 - (y + 1) * k, MX = (x) => mx + mw / 2 + x / HW * mw / 2;
      ctx.fillStyle = 'rgba(238,245,249,.88)'; ctx.fillRect(mx, y0, mw, y1 - y0);
      ctx.fillStyle = '#2f5f9e'; ctx.beginPath(); ctx.arc(MX(0), MY(TEE), HR / HW * mw / 2, 0, 7); ctx.fill();
      ctx.fillStyle = '#c8463c'; ctx.fillRect(mx, MY(HOG) - 0.5, mw, 1.2); ctx.fillRect(mx, MY(0) - 0.5, mw, 1.2);
      const pts = sim ? Array.from({ length: sim.n }, (_, i) => (sim.on[i] ? [sim.x[i], sim.y[i], sim.tm[i]] : null)).filter(Boolean) : (st ? st.st : []);
      for (const q of pts) { ctx.fillStyle = tcol(q[2]); ctx.beginPath(); ctx.arc(MX(q[0]), MY(q[1]), 2, 0, 7); ctx.fill(); }
      // camera window
      const a = WY(V.bot), b = WY(V.top);
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.2; ctx.strokeRect(mx - 1.5, MY(Math.min(b, BACK + 1.2)), mw + 3, MY(Math.max(a, -1)) - MY(Math.min(b, BACK + 1.2)));
    }
    function drawRemaining() {
      if (!st) return;
      const ti = sim ? animLast.k + 1 : st.ti, ham = sim ? (animLast.k % 2 === 0 ? 1 - animLast.tm : animLast.tm) : st.ham;
      if (sim && animLast.er) { /* still the old end */ }
      const left = (t) => NS - (t === ham ? Math.floor(ti / 2) : Math.ceil(ti / 2));
      const xr = SX(HW) + 10, room = cv.w - xr - 4;
      if (room < 10) return;
      const r = Math.min(5.5, room / 4.4), gap = r * 2.5;
      [1 - ham, ham].forEach((t, c) => {
        const n = left(t), x = xr + r + c * (r * 2.2) + (c ? 0 : 0);
        for (let i = 0; i < n; i++) {
          const y = V.bot - 10 - i * gap;
          ctx.fillStyle = '#6d6873'; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
          ctx.fillStyle = tcol(t); ctx.beginPath(); ctx.arc(x, y, r * 0.6, 0, 7); ctx.fill();
        }
      });
    }
    /* aim preview: the delivered stone's own path on open ice (same Sim), cut at the first stone it would touch.
       Nothing after a contact is predicted. */
    function freePath(s0) {
      const stones = st ? st.st : [];
      const key = [s0.bx, s0.by, s0.u, s0.t, s0.sw, st ? st.seq : 0].join(',');
      if (key === prevKey) return prevStop;
      prevKey = key;
      const v = wToV(s0.u), a = Math.atan2(s0.bx, s0.by), D2 = 4 * R * R;
      const sm = new Sim([], { vx: v * Math.sin(a), vy: v * Math.cos(a), t: s0.t, sw: s0.sw, tm: 0 });
      const pts = [[0, 0]];
      let hit = null;
      while (!sm.done && sm.on[0] && !hit) {
        sm.step();
        const x = sm.x[0], y = sm.y[0];
        if (sm.steps % 16 === 0) pts.push([x, y]);
        if (y > HOG - 1.5) for (let i = 0; i < stones.length; i++) { const q = stones[i], dx = q[0] - x, dy = q[1] - y; if (dx * dx + dy * dy < D2) { hit = { x, y, i }; break; } }
      }
      const x = sm.x[0], y = sm.y[0];
      pts.push([x, y]);
      const out = !hit && (!sm.on[0] || y - R > BACK);
      return (prevStop = { pts, x, y, hit, out, hog: !hit && !out && y - R < HOG });
    }
    function chip(text, x, y, align, col) {
      ctx.font = '700 11px "IBM Plex Sans KR", sans-serif';
      const w = ctx.measureText(text).width + 14, h = 20;
      const x0 = align === 'left' ? x : align === 'right' ? x - w : x - w / 2;
      ctx.fillStyle = 'rgba(23,19,31,.84)'; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x0, y - h / 2, w, h, 10); else ctx.rect(x0, y - h / 2, w, h); ctx.fill();
      ctx.fillStyle = col; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, x0 + w / 2, y + 0.5);
      return { x0, w };
    }
    function drawPreview(s0) {
      const z = zoneOf(s0.u), col = ZC[z], fp = freePath(s0), rk = R * camK;
      // the stone's own curling path (dark underlay so it reads on white ice)
      ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath(); fp.pts.forEach((p, i) => (i ? ctx.lineTo(SX(p[0]), SY(p[1])) : ctx.moveTo(SX(p[0]), SY(p[1]))));
      ctx.strokeStyle = 'rgba(23,19,31,.32)'; ctx.lineWidth = 4.5; ctx.stroke();
      ctx.strokeStyle = col; ctx.lineWidth = 2.2; ctx.setLineDash([3, 6]); ctx.stroke(); ctx.setLineDash([]);
      ctx.restore();
      const bpx = SX(s0.bx), leftSide = bpx > cv.w / 2; // labels go to the side away from the broom
      const lx = leftSide ? SX(-HW) + 6 : SX(HW) - 6, al = leftSide ? 'left' : 'right';
      if (fp.hit) {
        // first contact: ghost of the delivered stone + ring on the stone it reaches
        const q = st.st[fp.hit.i], gx = SX(fp.hit.x), gy = SY(fp.hit.y);
        ctx.fillStyle = 'rgba(242,233,216,.35)'; ctx.beginPath(); ctx.arc(gx, gy, rk, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(23,19,31,.8)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 3]); ctx.stroke(); ctx.setLineDash([]);
        ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(SX(q[0]), SY(q[1]), rk + 4, 0, 7); ctx.stroke();
      } else if (fp.out) {
        chip('이대로면 아웃', lx, V.top + 40, al, '#ee6a55');
      } else {
        const py = SY(fp.y), px = SX(fp.x);
        ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.setLineDash([6, 7]);
        ctx.beginPath(); ctx.moveTo(SX(-HW), py); ctx.lineTo(SX(HW), py); ctx.stroke();
        ctx.lineWidth = 2.5; ctx.setLineDash([4, 4]); ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.beginPath(); ctx.arc(px, py, rk, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        const txt = fp.hog ? '호그 라인 못 넘어요' : '여기쯤 멈춰요';
        ctx.font = '700 11px "IBM Plex Sans KR", sans-serif';
        const w = ctx.measureText(txt).width + 14, cx0 = leftSide ? lx : lx - w;
        const clash = px + rk + 4 > cx0 && px - rk - 4 < cx0 + w;
        chip(txt, lx, clash ? py + rk + 14 : py - 14, al, fp.hog ? '#ee6a55' : '#f2e9d8');
      }
    }
    function draw(now) {
      cv.clear();
      if (!st) return;
      drawSheet();
      // stones
      if (sim) {
        for (const g of ghosts) drawStone(g.x, g.y, g.t, Math.max(0, 1 - g.a), null);
        const d = sim.d;
        for (let i = 0; i < sim.n; i++) if (sim.on[i]) drawStone(sim.x[i], sim.y[i], sim.tm[i], 1, i === d ? 'rgba(242,233,216,.8)' : null);
        if (sim.swp && sim.on[d]) {
          const px = SX(sim.x[d]), py = SY(sim.y[d] + R * 2.6), w = Math.sin(now / 45) * 6;
          ctx.fillStyle = '#e3ae45';
          ctx.fillRect(px - 15 + w, py - 3, 12, 5); ctx.fillRect(px + 3 - w, py - 9, 12, 5);
        }
      } else {
        const sc = st.ph === 'p' ? scoreEnd(st.st) : { t: -1, p: 0 };
        const ranked = st.st.map((q) => [tdist(q[0], q[1]), q]).sort((a, b) => a[0] - b[0]);
        st.st.forEach((q) => {
          const ix = ranked.findIndex((z) => z[1] === q);
          drawStone(q[0], q[1], q[2], 1, sc.t >= 0 && q[2] === sc.t && ix < sc.p ? '#f2e9d8' : null);
        });
        const a = actor(st);
        if (a != null && api.canAct(a) && !waitingNet()) {
          const s0 = mySet();
          // straight line from the release point to the broom (initial direction)
          ctx.strokeStyle = 'rgba(23,19,31,.4)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 7]);
          ctx.beginPath(); ctx.moveTo(SX(0), SY(0)); ctx.lineTo(SX(s0.bx), SY(s0.by)); ctx.stroke(); ctx.setLineDash([]);
          drawPreview(s0);
          drawBroom(s0.bx, s0.by, s0.t, !!drag);
        }
      }
      drawMini(); drawRemaining();
      placeSpots();
      if (flash) {
        const k = U.clamp((now - flash.t0) / 1300, 0, 1);
        if (k >= 1) flash = null;
        else {
          ctx.globalAlpha = k < 0.12 ? k / 0.12 : 1 - Math.max(0, (k - 0.65) / 0.35);
          const y = V.top + (V.bot - V.top) * 0.3;
          ctx.font = '400 30px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, cv.w / 2, y);
          ctx.fillStyle = flash.c; ctx.fillText(flash.text, cv.w / 2, y);
          ctx.globalAlpha = 1;
        }
      }
      if (sim && !fast) {
        ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillStyle = 'rgba(23,19,31,.55)';
        ctx.fillText('화면을 누르면 빨리 감기', cv.w / 2, V.bot - 4);
      }
    }

    function placeSpots() {
      const k = camK, x0 = SX(-HW), x1 = SX(HW), cy = SY(TEE), clip = (y) => U.clamp(y, V.top, V.bot);
      spHouse(SX(0) - HR * k - 4, clip(cy - HR * k - 4), HR * k * 2 + 8, clip(cy + HR * k + 4) - clip(cy - HR * k - 4));
      if (st && st.fg && !sim) { const ya = clip(SY(TEE)), yb = clip(SY(HOG) + 3); spFgz(x0, ya, x1 - x0, yb - ya); } else spFgz(null);
      const a = st && !sim ? actor(st) : null;
      if (a != null && api.canAct(a) && !waitingNet()) { const s0 = mySet(); spBroom(SX(s0.bx) - 30, SY(s0.by) - 30, 60, 60); } else spBroom(null);
    }

    /* ---- HUD ---- */
    let topKey = '';
    function renderTop() {
      if (!st) return;
      const hideLast = sim && animLast && animLast.er;
      const sc = [0, 1].map((t) => (hideLast ? st.sc[t].slice(0, -1) : st.sc[t]));
      const ham = sim ? (animLast.k % 2 === 0 ? 1 - animLast.tm : animLast.tm) : st.ham;
      const e = sim ? animLast.e : st.e, ne = st.ne;
      const key = JSON.stringify([sc, ham, e, st.ph]);
      if (key === topKey) return;
      topKey = key;
      top.innerHTML = '';
      const cols = Math.max(ne, sc[0].length + (st.ph === 'p' || sim ? 1 : 0));
      const show = Math.min(cols, 8), first = cols - show;
      const grid = L.h('div', { class: 'panel', style: { padding: '4px 6px', display: 'grid', gridTemplateColumns: 'minmax(0,1fr) repeat(' + show + ', 19px) 30px', gap: '2px 1px', alignItems: 'center', fontSize: '11px' } });
      grid.append(L.h('div', { class: 'muted', style: { fontSize: '10px' }, text: e < ne ? (e + 1) + ' / ' + ne + ' 엔드' : '연장 ' + (e - ne + 1) }));
      for (let c = first; c < cols; c++) grid.append(L.h('div', { class: 'mono', style: { textAlign: 'center', fontSize: '10px', color: c === e ? 'var(--brass)' : 'var(--muted)', fontWeight: c === e ? 700 : 400 }, text: c < ne ? String(c + 1) : '연' }));
      grid.append(L.h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '10px' }, text: '합' }));
      for (let t = 0; t < 2; t++) {
        grid.append(L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '4px', minWidth: 0, fontWeight: 700, fontSize: '12px' } },
          L.h('span', { class: 'dot', style: { '--c': tcol(t), flex: 'none' } }),
          L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, text: teamName(st, t) }),
          ham === t && st.ph === 'p' ? L.h('span', { style: { flex: 'none', fontSize: '9.5px', padding: '1px 5px', borderRadius: '6px', background: 'var(--brass)', color: '#17131f' }, text: '해머' }) : null));
        for (let c = first; c < cols; c++) {
          const v = sc[t][c];
          grid.append(L.h('div', { class: 'mono', style: { textAlign: 'center', background: 'var(--surface-2)', borderRadius: '3px', height: '18px', lineHeight: '18px', color: v ? 'var(--ink)' : 'var(--muted)', fontWeight: v ? 700 : 400, outline: c === e ? '1px solid rgba(227,174,69,.5)' : 'none' }, text: v == null ? '' : String(v) }));
        }
        grid.append(L.h('div', { class: 'mono', style: { textAlign: 'center', fontWeight: 700, fontSize: '14px', color: 'var(--brass)' }, text: String(sc[t].reduce((a, b) => a + b, 0)) }));
      }
      top.append(grid);
      layout();
    }
    let botKey = '', ctl = null;
    function waitingNet() { return sentAt && performance.now() - sentAt < 6000; }
    function canHuman() { return st && !sim && !cardEl && st.ph === 'p' && api.canAct(actor(st)) && !waitingNet(); }
    function renderBot(force) {
      if (!st) return;
      const a = sim ? animLast.s : actor(st), mine = !sim && st.ph === 'p' && a != null && api.canAct(a) && !waitingNet();
      const ti = sim ? animLast.k : st.ti;
      const key = [a, mine, ti, st.ph, !!sim, !!cardEl].join('|');
      if (key === botKey && !force) return;
      botKey = key; bot.innerHTML = ''; ctl = null;
      if (st.ph === 'e' || a == null) { layout(); return; }
      const nth = Math.floor(ti / 2) + 1;
      const tm = sim ? animLast.tm : throwTeam(st, st.ti);
      const info = L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 10px', minWidth: 0 } },
        L.h('span', { class: 'dot', style: { '--c': tcol(tm), flex: 'none' } }),
        L.h('span', { style: { fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0 }, text: nameOf(a) }),
        st.n === 4 ? L.h('span', { style: { flex: 'none', fontSize: '11px', fontWeight: 700, padding: '2px 6px', borderRadius: '6px', background: tcol(tm), color: '#17131f' }, text: posOf(ti) }) : null,
        L.h('span', { class: 'mono muted', style: { fontSize: '12px', flex: 'none' }, text: st.n === 4 ? nth + '/' + NS : nth + '/' + NS + '번째 스톤' }),
        L.h('span', { class: 'muted', style: { fontSize: '12px', marginLeft: 'auto', flex: 'none' }, text: sim ? '미끄러지는 중…' : mine ? '브룸을 끌어 조준' : api.players[a].ai ? '생각 중…' : '차례' }));
      if (!mine) { bot.append(info); layout(); return; }
      const s0 = mySet();
      // weight
      const zl = L.h('span', { style: { fontWeight: 700, fontSize: '13px' } }), vl = L.h('span', { class: 'mono muted', style: { fontSize: '12px', marginLeft: 'auto' } });
      const rng = L.h('input', { type: 'range', min: '0', max: '100', step: '1', value: String(s0.u), 'aria-label': '무게', style: { width: '100%', margin: '0', height: '30px', accentColor: '#e3ae45' } });
      const bar = L.h('div', { style: { display: 'flex', height: '16px', borderRadius: '5px', overflow: 'hidden', fontSize: '10px', fontWeight: 700, color: '#17131f', lineHeight: '16px', textAlign: 'center' } },
        L.h('div', { style: { flex: Z1 + ' 0 0', background: ZC[0] }, text: '가드' }), L.h('div', { style: { flex: (Z2 - Z1) + ' 0 0', background: ZC[1] }, text: '드로우' }), L.h('div', { style: { flex: (100 - Z2) + ' 0 0', background: ZC[2] }, text: '테이크아웃' }));
      const syncW = () => { const z = zoneOf(s0.u); zl.textContent = '무게 · ' + ZN[z]; zl.style.color = ZC[z]; vl.textContent = wToV(s0.u).toFixed(2) + ' m/s'; };
      let lastZ = zoneOf(s0.u);
      rng.addEventListener('input', () => { s0.u = +rng.value; const z = zoneOf(s0.u); if (z !== lastZ) { lastZ = z; api.buzz(10); api.sfx('tick'); } syncW(); dirty = true; });
      rng.addEventListener('change', () => { saveSet(); });
      syncW();
      const wp = L.h('div', { class: 'panel cu-weight', style: { padding: '5px 10px 7px', display: 'flex', flexDirection: 'column', gap: '2px' } }, L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } }, zl, vl), rng, bar);
      // turn + sweep + throw
      const tb = L.h('button', { class: 'btn cu-turn', style: { flex: 'none', minWidth: '74px', padding: '0 8px', fontSize: '13px', flexDirection: 'column', gap: 0, lineHeight: 1.1 },
        'aria-label': '회전 방향', onclick() { s0.t = -s0.t; s0.bx = U.clamp(-s0.bx, -HW + 0.1, HW - 0.1); saveSet(); api.sfx('click'); api.buzz(8); syncT(); dirty = true; } });
      const syncT = () => { tb.innerHTML = ''; tb.append(L.h('span', { style: { fontSize: '17px' }, text: s0.t === 1 ? '↻' : '↺' }), L.h('span', { style: { fontSize: '11px' }, text: s0.t === 1 ? '인턴' : '아웃턴' })); };
      syncT();
      const seg = L.h('div', { class: 'seg', style: { flex: 'none' } });
      const sws = ['안 함', '살짝', '세게'].map((txt, i) => L.h('button', { type: 'button', class: s0.sw === i ? 'on' : '', style: { minHeight: '44px', padding: '0 9px' }, text: txt,
        onclick() { s0.sw = i; saveSet(); sws.forEach((b, j) => b.classList.toggle('on', j === i)); api.sfx('tick'); api.buzz(8); dirty = true; } }));
      sws.forEach((b) => seg.append(b));
      const swWrap = L.h('div', { class: 'cu-sweep', style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1px', flex: 'none' } }, L.h('span', { class: 'muted', style: { fontSize: '10px', fontWeight: 700 }, text: '스윕' }), seg);
      const go = L.h('button', { class: 'btn primary cu-go', style: { flex: '1 1 auto', minHeight: '48px', fontSize: '16px', padding: '0 10px' }, text: '던지기',
        onclick(e) {
          if (!canHuman()) return;
          e.currentTarget.disabled = true;
          const v = wToV(s0.u), ang = Math.atan2(s0.bx, s0.by);
          saveSet(); api.sfx('whoosh'); api.buzz(18);
          if (!api.isHost) sentAt = performance.now();
          api.act({ type: 'throw', a: ang, v, t: s0.t, sw: s0.sw });
        } });
      const row = L.h('div', { class: 'panel', style: { display: 'flex', gap: '6px', alignItems: 'flex-end', padding: '5px 6px' } }, tb, swWrap, go);
      bot.append(wp, row);
      ctl = { rng };
      layout();
    }

    /* ---- input: drag the broom ---- */
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (sim) { fast = true; dirty = true; return; }
      if (!canHuman() || drag) return;
      const p = cv.local(ev);
      if (p.y < V.top || p.y > V.bot + 4) return;
      const s0 = mySet(), bx = SX(s0.bx), by = SY(s0.by);
      const near = Math.hypot(p.x - bx, p.y - by) < 44;
      if (!near) { s0.bx = U.clamp(WX(p.x), -HW + 0.1, HW - 0.1); s0.by = U.clamp(WY(p.y), HOG - 2, BACK + 0.4); api.sfx('tick'); }
      drag = { id: ev.pointerId, ox: p.x, oy: p.y, bx: s0.bx, by: s0.by };
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      api.buzz(8); dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const p = cv.local(ev), s0 = mySet(); if (!s0) return;
      s0.bx = U.clamp(drag.bx + (p.x - drag.ox) / camK, -HW + 0.1, HW - 0.1);
      s0.by = U.clamp(drag.by - (p.y - drag.oy) / camK, Math.max(HOG - 2, WY(V.bot)), Math.min(BACK + 0.4, WY(V.top)));
      dirty = true;
    });
    const endDrag = (ev) => { if (!drag || drag.id !== ev.pointerId) return; drag = null; saveSet(); dirty = true; };
    cv.cv.addEventListener('pointerup', endDrag);
    cv.cv.addEventListener('pointercancel', endDrag);

    /* ---- animation ---- */
    function camTarget(lead) { return Math.min(restCam(), lead + (V.bot - V.top) / 2 / camK * 0.45); }
    function startAnim(last) {
      clearTimeout(finTimer); clearTimeout(animTimer); closeCard(true);
      sim = new Sim(last.pre, last.shot); animLast = last; simAcc = 0; fast = false; ghosts = []; lastHits = 0; prevOn = Uint8Array.from(sim.on);
      camY = camTarget(0);
      api.setBusy(true);
      const mine = sim, dur = new Sim(last.pre, last.shot).run().steps * DT;
      animTimer = setTimeout(() => { if (sim === mine && !sim.done) { sim.run(); finishAnim(); } }, (dur / 2 / L.debug.speed) * 1000 + 4000);
      renderTop(); renderBot();
    }
    function finishAnim() {
      clearTimeout(animTimer);
      const l = animLast, s = sim;
      announce(l, s);
      clearTimeout(finTimer);
      finTimer = setTimeout(() => {
        if (sim !== s) return;
        sim = null; animLast = null; ghosts = [];
        layout();
        if (l.er) showCard(l);
        else api.setBusy(false);
        renderTop(); renderBot(); dirty = true;
      }, (l.er ? 900 : 650) / L.debug.speed);
    }
    function announce(l, s) {
      const opp = l.pre.filter((q, i) => q[2] !== l.tm && !s.on[i]).length;
      if (l.ev === 'fgz') { flash = { text: '프리 가드 존 위반', c: '#ee6a55', t0: performance.now() }; api.toast('보호된 가드를 쳐냈어요 — 스톤을 원위치하고 던진 스톤 제거'); api.sfx('lose'); return; }
      if (l.ev === 'h') { flash = { text: '호그 라인 미달', c: '#ab9fb8', t0: performance.now() }; api.sfx('thud'); return; }
      if (opp >= 2) { flash = { text: '더블 테이크아웃!', c: '#e3ae45', t0: performance.now() }; api.sfx('win'); api.buzz(30); return; }
      if (opp === 1) { flash = { text: '테이크아웃', c: '#f2e9d8', t0: performance.now() }; api.sfx('pop'); api.buzz(15); return; }
      if (l.ev === 's' || l.ev === 'b') { flash = { text: '아웃', c: '#ab9fb8', t0: performance.now() }; api.sfx('thud'); return; }
      const d = s.on[s.d] ? tdist(s.x[s.d], s.y[s.d]) : 9;
      if (d < 0.15 + R) { flash = { text: '버튼!', c: '#e3ae45', t0: performance.now() }; api.sfx('win'); api.buzz(25); }
      else api.sfx('tick');
    }
    function showCard(l) {
      closeCard(true);
      const er = l.er, en = l.e < st.ne ? (l.e + 1) + '엔드' : '연장 ' + (l.e - st.ne + 1) + '엔드';
      const msg = er.t < 0 ? '블랭크 엔드 · 해머 유지' : teamName(st, er.t) + ' ' + er.p + '점';
      const sub = er.t < 0 ? '하우스에 스톤이 없어 점수 없음' : '다음 엔드 해머: ' + teamName(st, st.ham);
      cardEl = L.h('div', { class: 'overlay', style: { zIndex: 15, background: 'rgba(10,8,15,.35)', backdropFilter: 'none', alignItems: 'center' }, onclick() { closeCard(); } },
        L.h('div', { class: 'sheet', style: { gap: '8px', textAlign: 'center', padding: '18px', width: 'min(320px,100%)' } },
          L.h('span', { class: 'label', text: en + ' 끝' }),
          L.h('h2', { style: { fontSize: '26px', color: er.t < 0 ? 'var(--ink)' : tcol(er.t) }, text: msg }),
          L.h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: sub }),
          L.h('p', { class: 'mono', style: { margin: 0, fontSize: '18px', fontWeight: 700 }, text: tot(st, 0) + ' : ' + tot(st, 1) }),
          L.h('p', { class: 'muted', style: { margin: 0, fontSize: '11px' }, text: '누르면 닫기' })));
      root.append(cardEl);
      api.sfx(er.p >= 2 ? 'win' : 'chip'); api.buzz(20);
      cardTimer = setTimeout(() => closeCard(), 2600 / L.debug.speed);
    }
    function closeCard(silent) {
      clearTimeout(cardTimer);
      if (cardEl) { cardEl.remove(); cardEl = null; if (!silent) { api.setBusy(false); renderBot(); dirty = true; } else api.setBusy(false); }
    }
    const tutTick = tutCatchUp(root, api, 'curling', ['.cu-broom', '.cu-weight', '.cu-turn', '.cu-sweep', '.cu-go']);
    const stop = U.loop((dt, now) => {
      tutTick(!!(canHuman() && bot.querySelector('.cu-go')));
      if (sim) {
        if (!sim.done) {
          const d = sim.d, before = sim.y[d] < HOG - 2.5 && !sim.hit;
          const rate = (fast ? 10 : before ? 5 : 3) * L.debug.speed;
          simAcc += dt * rate;
          let n = 0;
          while (simAcc >= DT && !sim.done && n < 6000) {
            sim.step(); simAcc -= DT; n++;
            for (let i = 0; i < sim.n; i++) if (prevOn[i] && !sim.on[i]) { prevOn[i] = 0; ghosts.push({ x: sim.x[i], y: sim.y[i], t: sim.tm[i], a: 0 }); }
          }
          if (sim.hits > lastHits) { lastHits = sim.hits; api.sfx(sim.hitV > 1 ? 'hit' : 'chip'); api.buzz(sim.hitV > 1 ? 25 : 10); }
          if (sim.done) finishAnim();
        }
        ghosts.forEach((g) => (g.a += dt * 1.4 * L.debug.speed));
        ghosts = ghosts.filter((g) => g.a < 1);
        // follow the stone; never past the overview
        let lead = sim.on[sim.d] ? sim.y[sim.d] : camY;
        if (sim.hit) for (let i = 0; i < sim.n; i++) if (sim.on[i] && (sim.vx[i] || sim.vy[i])) lead = Math.max(lead, sim.y[i]);
        camY += (camTarget(lead) - camY) * Math.min(1, dt * 7 * Math.max(1, Math.sqrt(L.debug.speed)));
        dirty = true;
      }
      if (flash || drag) dirty = true;
      if (dirty) { dirty = false; draw(now); }
    });

    layout();
    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        const key = next.last ? next.last.id + ':' + next.last.shot.vx + ':' + next.last.shot.vy : '';
        if (next.last && key !== shownKey && prev && prev !== next) { shownKey = key; startAnim(next.last); }
        else shownKey = key;
        if (!sim) { const a = actor(next); if (a !== setSeat) { set = null; setSeat = -1; } }
        renderTop(); renderBot(); dirty = true;
      },
      destroy() { stop(); clearTimeout(finTimer); clearTimeout(animTimer); clearTimeout(cardTimer); if (cardEl) cardEl.remove(); cv.destroy(); top.remove(); bot.remove(); zbtn.remove(); [spHouse, spFgz, spBroom].forEach((f) => f.el.remove()); api.setBusy(false); },
    };
  }

  L.register({
    id: 'curling', name: '컬링', tag: '얼음 위 전략', cat: '스포츠',
    blurb: '2팀이 번갈아 스톤을 8개씩 던져 하우스 중심(버튼)에 더 가까이 붙여요. 브룸으로 조준하고 무게·회전·스윕을 골라 던집니다.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 700,
    tint: '#1f3f5a',
    icon: '<ellipse cx="28" cy="44" rx="21" ry="5" fill="currentColor" opacity=".35"/><path d="M8 35c0-7 9-11 20-11s20 4 20 11v3c0 4-9 7-20 7S8 42 8 38z" fill="currentColor"/><path d="M8 35c0 4 9 7 20 7s20-3 20-7" fill="none" stroke="#1f3f5a" stroke-width="2"/><path d="M22 24v-7c0-3 2-5 5-5h14" fill="none" stroke="currentColor" stroke-width="4.5" stroke-linecap="round"/>',
    options: [
      { id: 'ends', label: '엔드 수', choices: [{ v: 4, label: '4엔드' }, { v: 6, label: '6엔드' }, { v: 8, label: '8엔드' }], def: 4 },
      { id: 'fgz', label: '프리 가드 존(5스톤 룰)', choices: [{ v: 1, label: '켜기' }, { v: 0, label: '끄기' }], def: 1 },
    ],
    quick: [
      '두 팀이 스톤을 번갈아 미끄러뜨려, 과녁(하우스) 한가운데에 더 가까이 붙이는 게임이에요.',
      '내 차례: 노란 브룸을 끌어 조준하고, 무게(세기)·회전·스윕을 고른 뒤 「던지기」.',
      '엔드가 끝날 때 가장 가까운 스톤의 팀만, 상대보다 가까운 스톤 수만큼 점수를 얻어요. 정한 엔드 뒤 점수가 많은 팀 승리.',
    ],
    rules: [
      { h: '목표', p: ['2팀 대결이에요. 2명이면 1:1, 3–4명이면 1·3번 자리 대 2·4번 자리 팀이에요.',
        '얼음 위로 스톤을 미끄러뜨려 「하우스」(파랑·흰색·빨강 과녁) 한가운데(버튼)에 상대보다 가까이 붙이면 점수를 얻어요.',
        '「엔드」는 한 판이에요. 정한 엔드(4·6·8)가 끝났을 때 점수가 많은 팀이 이기고, 같으면 승부가 날 때까지 연장 엔드를 해요.'] },
      { h: '차례에 할 일', p: ['① 두 팀이 스톤을 하나씩 번갈아 던져요. 한 엔드에 팀마다 8개씩, 모두 16개예요.',
        '② 16개를 다 던지면 엔드가 끝나고 점수를 매겨요. 그리고 다음 엔드를 시작해요.',
        '③ 「해머」(엔드의 마지막 스톤)를 가진 팀이 항상 마지막에 던져요. 마지막에 던지는 쪽이 유리해요.',
        '4명(2:2)이면 실제 컬링처럼 한 사람이 자기 팀 스톤을 2개씩 연달아 던져요: 첫 사람이 리드(1–2번)·서드(5–6번), 둘째 사람이 세컨드(3–4번)·스킵(7–8번). 아래 막대에 던지는 사람과 포지션이 나와요.',
        '3명이면 혼자인 팀은 8개를 모두 던지고, 2명인 팀은 스톤마다 번갈아 던져요.'] },
      { h: '조작 (손가락)', p: ['① 조준: 하우스 쪽의 노란 브룸을 끌거나, 원하는 곳을 누르면 브룸이 그리로 가요. 점선이 처음 출발하는 방향이에요.',
        '② 스톤은 똑바로 가지 않고 회전 방향으로 휘어 들어가요(브룸 옆 화살표). 그래서 노릴 곳보다 조금 옆을 겨눠요.',
        '③ 무게: 아래 막대를 좌우로 밀어 세기를 정해요. 가드(하우스 앞에 멈춤) · 드로우(하우스 안에 멈춤) · 테이크아웃(세게, 상대 스톤 쳐내기).',
        '④ 회전: 「↻ 인턴」(오른쪽으로 휨) / 「↺ 아웃턴」(왼쪽으로 휨) 버튼으로 바꿔요. 바꾸면 브룸도 좌우로 뒤집혀요.',
        '⑤ 스윕: 안 함 / 살짝 / 세게. 앞을 닦아 주면 조금 더 멀리, 덜 휘어 가요.',
        '⑥ 「던지기」를 누르면 출발!',
        '색 점선 = 스톤이 휘어 가는 길이에요. 다른 스톤에 처음 닿는 곳에서 끊기고(흰 원 = 닿는 자리, 빨간 테 = 맞을 스톤), 아무것도 안 맞으면 멈출 곳(「여기쯤 멈춰요」)이 보여요. 부딪힌 뒤 어떻게 될지는 안 보여 줘요.',
        '「하우스 확대」 버튼으로 하우스를 크게 볼 수 있어요. 스톤이 가는 동안 화면을 누르면 빨리 감기. 조준·무게·회전·스윕은 사람마다 이 폰에 기억돼요.'] },
      { h: '점수·승리', p: ['엔드가 끝나면 하우스에 닿은 스톤만 세요.',
        '버튼(한가운데)에 가장 가까운 스톤의 팀만 점수를 얻어요. 상대 팀에서 가장 가까운 스톤보다 더 가까운 내 스톤 하나당 1점이에요.',
        '점수가 나는 스톤에는 흰 테가 표시돼요.',
        '해머: 앞 엔드에서 점수를 못 낸 팀이 다음 엔드의 마지막 스톤을 가져가요. 아무도 점수를 못 내면(블랭크 엔드) 해머는 그대로예요. 첫 엔드 해머는 무작위예요.'] },
      { h: '라인과 아웃', p: ['던진 스톤이 다른 스톤에 닿지 않고 먼 쪽 호그 라인(빨간 선)을 완전히 넘지 못하면 빼요.',
        '옆줄(사이드 라인)에 닿거나 하우스 뒤 백 라인을 완전히 넘어간 스톤도 빼요.'] },
      { h: '프리 가드 존 (5스톤 룰)', p: ['「프리 가드 존」은 호그 라인과 티 라인(하우스 가운데를 지나는 가로선) 사이, 하우스를 뺀 구역이에요. 노랗게 칠해져 있어요.',
        '엔드의 처음 5개 스톤이 던져지는 동안에는, 이 구역에 있는 상대 스톤(가드)을 시트 밖으로 쳐낼 수 없어요.',
        '어기면 스톤들이 원래 자리로 돌아가고, 던진 스톤만 빠져요.',
        '설정에서 끌 수 있어요(기본 켜기).'] },
      { h: '예시', p: ['엔드가 끝났을 때 버튼에서 가까운 순서: 빨강 팀 스톤 → 빨강 팀 스톤 → 파랑 팀 스톤 → 빨강 팀 스톤.',
        '→ 빨강 팀이 2점(파랑의 가장 가까운 스톤보다 가까운 것 2개). 세 번째 빨강 스톤은 파랑보다 멀어서 안 세요. 파랑 팀은 0점.',
        '→ 다음 엔드 해머(마지막 스톤)는 점수를 못 낸 파랑 팀이 가져가요.',
        '하우스 안에 스톤이 하나도 없으면 블랭크 엔드: 아무도 점수가 없고, 해머도 그대로예요.'] },
      { h: '물리', p: ['스톤(19.96 kg)은 얼음 위를 천천히 미끄러지며, 느려질수록 더 많이 휘어요(컬).',
        '스톤끼리는 거의 탄성 충돌을 해요. 정면으로 맞히면 맞힌 스톤이 멈추고 맞은 스톤이 밀려나요.',
        '스윕은 던진 스톤이 다른 스톤에 닿거나 티 라인을 지날 때까지만 해요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 드로우·가드·테이크아웃 후보를 더 많이 시뮬레이션해 보고, 더 정확하게 던져요.'] },
    ],
    tutorial: [
      { sel: '.cu-house', text: '이게 하우스(과녁)예요. 스톤을 한가운데에 상대보다 가까이 붙이면 점수! 엔드가 끝날 때 가장 가까운 팀만, 상대보다 가까운 스톤 수만큼 점수를 얻어요.' },
      { sel: '.cu-broom', text: '조준: 노란 브룸을 끌거나 원하는 곳을 누르세요. 스톤은 회전 방향으로 휘어 들어가니, 색 점선(휘어 가는 길)을 보고 맞추세요.' },
      { sel: '.cu-weight', text: '무게(세기): 막대를 밀어요. 가드 = 하우스 앞에 멈춤, 드로우 = 하우스 안에 멈춤, 테이크아웃 = 세게 쳐내기.' },
      { sel: '.cu-turn', text: '회전: ↻ 인턴은 오른쪽, ↺ 아웃턴은 왼쪽으로 휘어요. 바꾸면 브룸도 반대쪽으로 옮겨져요.' },
      { sel: '.cu-sweep', text: '스윕: 앞을 닦으면 조금 더 멀리, 덜 휘어 가요. 처음엔 「안 함」으로 시작해 보세요.' },
      { sel: '.cu-go', text: '다 정했으면 「던지기」! 스톤이 가는 동안 화면을 누르면 빨리 감기예요.' },
      { sel: '.cu-fgz', text: '노랗게 칠한 곳은 프리 가드 존이에요. 엔드의 처음 5개 스톤 동안은 여기 있는 상대 스톤을 밖으로 쳐낼 수 없어요. 그럼 시작!' },
    ],
    init, actor, apply, ai, result, mount,
    _sim: { Sim, simulate, scoreEnd, inFGZ, inHouse, solveDraw, solveHit, wToV, throwerOf, posOf, TEE, HOG, BACK, HW, R },
  });
})();
