/* 잠수함 숨바꼭질 — 2인 숨은 함대 찾기 (턴제, 숨김 정보). 내 바다에 잠수함을 숨기고 상대 바다를 한 칸씩 쏴서 먼저 모두 가라앉히면 승리. */
(function () {
  const L = window.Lounge, U = L.util;
  const FLEETS = { 10: [5, 4, 3, 3, 2], 8: [4, 3, 3, 2] };
  const ALLNAMES = ['고래', '상어', '돌고래', '가오리', '해마'];
  const COLS = 'ABCDEFGHIJ';
  const lensOf = (N) => FLEETS[N];
  const namesOf = (N) => ALLNAMES.slice(5 - FLEETS[N].length);
  const label = (c, N) => COLS[c % N] + (Math.floor(c / N) + 1);

  /* ---------- fleet helpers (ship = cell + 100 if vertical; cell = y*N + x = bow/top-left end) ---------- */
  function cellsOf(v, len, N) {
    const vert = v >= 100, c = v % 100, x = c % N, y = Math.floor(c / N), out = [];
    for (let i = 0; i < len; i++) out.push(vert ? (y + i) * N + x : y * N + x + i);
    return out;
  }
  function fits(v, len, N) {
    if (!Number.isInteger(v) || v < 0 || v >= 200) return false;
    const vert = v >= 100, c = v % 100;
    if (c >= N * N) return false;
    const x = c % N, y = Math.floor(c / N);
    return vert ? y + len <= N : x + len <= N;
  }
  function validFleet(f, N) {
    const lens = lensOf(N);
    if (!Array.isArray(f) || f.length !== lens.length) return false;
    const occ = new Uint8Array(N * N);
    for (let i = 0; i < lens.length; i++) {
      if (!fits(f[i], lens[i], N)) return false;
      for (const c of cellsOf(f[i], lens[i], N)) { if (occ[c]) return false; occ[c] = 1; }
    }
    return true;
  }
  function randomFleet(N) {
    const lens = lensOf(N);
    for (let tries = 0; tries < 200; tries++) {
      const occ = new Uint8Array(N * N), f = [];
      let ok = true;
      for (let i = 0; i < lens.length && ok; i++) {
        const len = lens[i];
        let placed = false;
        for (let k = 0; k < 300 && !placed; k++) {
          const vert = Math.random() < 0.5;
          const x = U.rand(vert ? N : N - len + 1), y = U.rand(vert ? N - len + 1 : N);
          const v = y * N + x + (vert ? 100 : 0);
          const cs = cellsOf(v, len, N);
          if (cs.some((c) => occ[c])) continue;
          cs.forEach((c) => (occ[c] = 1)); f.push(v); placed = true;
        }
        if (!placed) ok = false;
      }
      if (ok) return f;
    }
    return lens.map((_, i) => i * 2 * N); // fallback: one ship per even row
  }
  function areaOf(c, N) {
    const x = c % N, y = Math.floor(c / N), out = [];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) out.push((y + dy) * N + x + dx);
    return out;
  }
  function clampCenter(c, N) {
    const x = U.clamp(c % N, 1, N - 2), y = U.clamp(Math.floor(c / N), 1, N - 2);
    return y * N + x;
  }

  /* ---------- pure logic ---------- */
  function init(players, opts) {
    opts = opts || {};
    const N = String(opts.size) === '8' ? 8 : 10;
    const sonar = String(opts.sonar == null ? '1' : opts.sonar) === '1' ? 1 : 0;
    const s = {
      N, fl: [null, null], sh: ['.'.repeat(N * N), '.'.repeat(N * N)], sk: [[], []], so: [null, null], sn: [sonar, sonar],
      xs: String(opts.extra) === '1' ? 1 : 0, ph: 'p', turn: U.rand(2), seq: 0, last: null, win: null, g: Math.floor(Math.random() * 1e6),
    };
    players.forEach((p, i) => { if (p && p.ai && i < 2) s.fl[i] = randomFleet(N); });
    if (s.fl[0] && s.fl[1]) s.ph = 'f';
    return s;
  }
  function actor(s) {
    if (s.ph === 'p') { const i = s.fl.findIndex((f) => !f); return i < 0 ? null : i; }
    if (s.ph === 'f') return s.turn;
    return null;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const N = s.N;
    if (a.t === 'p') {
      if (s.ph !== 'p' || s.fl[seat] || actor(s) !== seat) throw new Error('not placing');
      if (!validFleet(a.f, N)) throw new Error('bad fleet');
      s.fl[seat] = a.f.slice();
      s.seq++; s.last = { id: s.seq, k: 'p', seat };
      if (s.fl[0] && s.fl[1]) s.ph = 'f';
      return s;
    }
    if (s.ph !== 'f' || seat !== s.turn) throw new Error('not your turn');
    const d = 1 - seat, c = a.c;
    if (!Number.isInteger(c) || c < 0 || c >= N * N) throw new Error('bad cell');
    const lens = lensOf(N);
    if (a.t === 'f') {
      if (s.sh[seat][c] !== '.') throw new Error('already shot');
      let hit = -1;
      for (let i = 0; i < lens.length && hit < 0; i++) if (cellsOf(s.fl[d][i], lens[i], N).includes(c)) hit = i;
      s.sh[seat] = s.sh[seat].slice(0, c) + (hit >= 0 ? 'x' : 'o') + s.sh[seat].slice(c + 1);
      let r = hit >= 0 ? 'x' : 'o';
      if (hit >= 0 && cellsOf(s.fl[d][hit], lens[hit], N).every((k) => s.sh[seat][k] === 'x')) { s.sk[seat].push(hit); r = 's'; }
      s.seq++;
      s.last = { id: s.seq, k: 'f', seat, c, r };
      if (r === 's') s.last.i = hit;
      if (s.sk[seat].length === lens.length) { s.win = seat; s.ph = 'e'; }
      else if (!(hit >= 0 && s.xs)) s.turn = d;
      return s;
    }
    if (a.t === 's') {
      if (!(s.sn[seat] > 0)) throw new Error('no sonar');
      if (clampCenter(c, N) !== c) throw new Error('bad sonar center');
      const occ = new Uint8Array(N * N);
      for (let i = 0; i < lens.length; i++) for (const k of cellsOf(s.fl[d][i], lens[i], N)) occ[k] = 1;
      const n = areaOf(c, N).reduce((m, k) => m + occ[k], 0);
      s.sn[seat]--; s.so[seat] = [c, n];
      s.seq++; s.last = { id: s.seq, k: 's', seat, c, n };
      s.turn = d;
      return s;
    }
    throw new Error('bad action');
  }
  function shotStats(sh) {
    let shots = 0, hits = 0;
    for (let i = 0; i < sh.length; i++) { if (sh[i] !== '.') shots++; if (sh[i] === 'x') hits++; }
    return { shots, hits };
  }
  function result(s) {
    if (s.win == null) return null;
    const t = shotStats(s.sh[s.win]);
    return { winners: [s.win], text: t.shots + '발 만에 상대 함대를 모두 가라앉혔어요.\n명중 ' + t.hits + '발 · 명중률 ' + Math.round((t.hits / Math.max(1, t.shots)) * 100) + '%' };
  }

  /* ---------- AI ---------- */
  // What the shooter legitimately knows: own shots, sunk ships (their outline is shown to everyone) and sonar.
  function know(s, seat) {
    const N = s.N, NN = N * N, d = 1 - seat, sh = s.sh[seat], lens = lensOf(N);
    const blocked = new Uint8Array(NN), hitU = new Uint8Array(NN);
    for (let c = 0; c < NN; c++) { if (sh[c] === 'o') blocked[c] = 1; else if (sh[c] === 'x') hitU[c] = 1; }
    for (const i of s.sk[seat]) for (const c of cellsOf(s.fl[d][i], lens[i], N)) { blocked[c] = 1; hitU[c] = 0; }
    let boost = null;
    const so = s.so[seat];
    if (so) {
      const area = areaOf(so[0], N);
      const left = so[1] - area.filter((c) => sh[c] === 'x').length;
      const unk = area.filter((c) => sh[c] === '.');
      if (left <= 0) unk.forEach((c) => (blocked[c] = 1));
      else if (unk.length) boost = { cells: unk, f: 1 + (3 * left) / unk.length };
    }
    const rem = [];
    lens.forEach((l, i) => { if (!s.sk[seat].includes(i)) rem.push(l); });
    const hits = [];
    for (let c = 0; c < NN; c++) if (hitU[c]) hits.push(c);
    return { N, sh, blocked, hitU, hits, rem, boost };
  }
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  function unshot(K, avoidBlocked) {
    const out = [];
    for (let c = 0; c < K.N * K.N; c++) if (K.sh[c] === '.' && !(avoidBlocked && K.blocked[c])) out.push(c);
    return out;
  }
  function neighbors(K, c) {
    const N = K.N, x = c % N, y = Math.floor(c / N), out = [];
    if (x > 0) out.push(c - 1); if (x < N - 1) out.push(c + 1); if (y > 0) out.push(c - N); if (y < N - 1) out.push(c + N);
    return out;
  }
  function targetNeighbors(K) {
    const out = [];
    for (const h of K.hits) for (const n of neighbors(K, h)) if (K.sh[n] === '.' && !K.blocked[n] && !out.includes(n)) out.push(n);
    return out;
  }
  function lineEnds(K) {
    const N = K.N, out = [];
    for (const h of K.hits) {
      const x = h % N, y = Math.floor(h / N);
      for (const [dx, dy] of [[1, 0], [0, 1]]) {
        const inb = (xx, yy) => xx >= 0 && yy >= 0 && xx < N && yy < N;
        const hitAt = (xx, yy) => inb(xx, yy) && K.hitU[yy * N + xx];
        if (!hitAt(x + dx, y + dy) && !hitAt(x - dx, y - dy)) continue;
        for (const sg of [1, -1]) {
          let xx = x, yy = y;
          while (hitAt(xx, yy)) { xx += dx * sg; yy += dy * sg; }
          if (inb(xx, yy)) { const c = yy * N + xx; if (K.sh[c] === '.' && !K.blocked[c] && !out.includes(c)) out.push(c); }
        }
      }
    }
    return out;
  }
  function density(K) {
    const N = K.N, D = new Float64Array(N * N), target = K.hits.length > 0;
    for (const len of K.rem) for (let vert = 0; vert < 2; vert++) for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      if (vert ? y + len > N : x + len > N) continue;
      let ok = true, h = 0;
      for (let k = 0; k < len; k++) {
        const c = vert ? (y + k) * N + x : y * N + x + k;
        if (K.blocked[c]) { ok = false; break; }
        if (K.hitU[c]) h++;
      }
      if (!ok || (target && h === 0)) continue;
      const w = target ? Math.pow(30, h) : 1;
      for (let k = 0; k < len; k++) { const c = vert ? (y + k) * N + x : y * N + x + k; if (K.sh[c] === '.') D[c] += w; }
    }
    if (K.boost) for (const c of K.boost.cells) D[c] *= K.boost.f;
    return D;
  }
  function argmax(D, cells) {
    let best = -1, out = [];
    for (const c of cells) { if (D[c] > best + 1e-9) { best = D[c]; out = [c]; } else if (Math.abs(D[c] - best) <= 1e-9) out.push(c); }
    return best > 0 ? pick(out) : -1;
  }
  function sonarCenters(K, minUnshot) {
    const N = K.N, out = [];
    for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
      const c = y * N + x;
      if (areaOf(c, N).filter((k) => K.sh[k] === '.' && !K.blocked[k]).length >= minUnshot) out.push(c);
    }
    return out;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'p') return { t: 'p', f: randomFleet(s.N) };
    const K = know(s, seat), N = s.N;
    const fired = shotStats(s.sh[seat]).shots;
    const any = unshot(K, false);
    const free = unshot(K, true);
    if (lv <= 1) {
      if (K.hits.length && Math.random() < 0.45) { const t = targetNeighbors(K); if (t.length) return { t: 'f', c: pick(t) }; }
      if (s.sn[seat] > 0 && !K.hits.length && fired >= 3 && Math.random() < 0.08) { const cs = sonarCenters(K, 1); if (cs.length) return { t: 's', c: pick(cs) }; }
      return { t: 'f', c: pick(any) };
    }
    if (lv === 2) {
      if (K.hits.length) {
        const e = lineEnds(K); if (e.length) return { t: 'f', c: pick(e) };
        const t = targetNeighbors(K); if (t.length) return { t: 'f', c: pick(t) };
      }
      if (s.sn[seat] > 0 && !K.hits.length && fired >= 5 && Math.random() < 0.3) { const cs = sonarCenters(K, 6); if (cs.length) return { t: 's', c: pick(cs) }; }
      if (K.boost && !K.hits.length && Math.random() < 0.8) { const b = K.boost.cells.filter((c) => K.sh[c] === '.'); if (b.length) return { t: 'f', c: pick(b) }; }
      return { t: 'f', c: pick(free.length ? free : any) };
    }
    // lv 3: probability density + parity
    const D = density(K);
    if (!K.hits.length) {
      if (s.sn[seat] > 0 && fired >= 3) {
        let best = -1, bc = -1;
        for (const c of sonarCenters(K, 5)) { let sum = 0; for (const k of areaOf(c, N)) if (K.sh[k] === '.') sum += D[k]; if (sum > best) { best = sum; bc = c; } }
        if (bc >= 0) return { t: 's', c: bc };
      }
      const m = Math.min.apply(null, K.rem);
      const tot = new Array(m).fill(0);
      for (const c of free) tot[((c % N) + Math.floor(c / N)) % m] += D[c];
      let r = 0; for (let i = 1; i < m; i++) if (tot[i] > tot[r]) r = i;
      const cls = free.filter((c) => ((c % N) + Math.floor(c / N)) % m === r);
      const c = argmax(D, cls.length ? cls : free);
      if (c >= 0) return { t: 'f', c };
    } else {
      const c = argmax(D, free);
      if (c >= 0) return { t: 'f', c };
    }
    return { t: 'f', c: pick(free.length ? free : any) };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'p') return 300;
    if (s.ph !== 'f') return -1;
    return lv <= 1 ? 950 : lv === 2 ? 760 : 620;
  }

  /* ---------- view ---------- */
  const SWEEP = Array.from({ length: 8 }, (_, k) => 'rgba(70,255,170,' + (0.08 * (1 - k / 8)).toFixed(3) + ')');
  const STYLE = {
    own: ['#a7c6d4', '#557886', '#2a414c', 'rgba(8,18,24,.85)'],
    reveal: ['#a7c6d4', '#557886', '#2a414c', 'rgba(170,230,255,.7)'],
    sunk: ['#b0634a', '#62301f', '#2e1510', 'rgba(255,120,90,.9)'],
    bad: ['#f08a78', '#a8443a', '#5a1f1a', 'rgba(255,90,70,.95)'],
  };

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, G = null, lastKey = '', curG = -1, layoutPh = '';
    let aim = -1, hover = -1, kcur = -1, sonarMode = false, peek = false, pending = false, pendTimer = 0;
    let anim = null, preKey = '', queued = null, watchdog = 0;
    let draft = null, draftFor = -1, sel = -1, drag = null, aimDrag = null;
    let shownD = -1, fade = 1, now = 0, acc = 0;
    const parts = [];
    const layers = {};

    /* --- DOM controls --- */
    const hud = L.h('div', { class: 'hud bottom sb-hud', style: { flexWrap: 'nowrap', gap: '8px' } });
    const mk = (cls, text, fn, style) => L.h('button', { class: 'btn ' + cls, text, onclick: fn, style: Object.assign({ minHeight: '50px' }, style || {}) });
    const bRot = mk('sb-rot', '↻ 회전', () => { if (sel < 0) { api.toast('돌릴 배를 먼저 톡 하세요'); api.buzz(10); return; } rotateShip(sel); });
    const bAuto = mk('sb-auto', '자동 배치', () => { if (!placing()) return; draft = randomFleet(st.N); sel = -1; api.sfx('roll'); api.buzz(10); refreshHud(); });
    const bDone = mk('primary sb-done', '숨기기 완료', () => placeDone(), { flex: '1 1 auto', maxWidth: '170px' });
    const bSonar = mk('', '소나', () => toggleSonar(), { minWidth: '92px' });
    const bFire = mk('primary', '발사', () => fire(), { flex: '1 1 auto', maxWidth: '230px' });
    hud.append(bRot, bAuto, bDone, bSonar, bFire);
    // tutorial spotlight targets (invisible): the big sea and the row under it (ship dock / small boards)
    const boardMark = L.h('div', { class: 'sb-board', style: { position: 'absolute', pointerEvents: 'none' } });
    const rowMark = L.h('div', { class: 'sb-row', style: { position: 'absolute', pointerEvents: 'none' } });
    root.append(boardMark, rowMark, hud);
    [bRot, bAuto, bDone, bSonar, bFire].forEach((b) => (b.hidden = true));

    const vs = () => (anim ? anim.s : st);
    const persp = () => api.viewer();
    const spectator = () => api.mySeats().length === 0;
    const localMulti = () => !api.online && api.mySeats().length > 1;
    const placing = () => !!st && st.ph === 'p' && actor(st) != null && api.canAct(actor(st));
    const nm = (i) => (api.players[i] ? api.players[i].name : '플레이어 ' + (i + 1));
    const keyOf = (s) => s.g + ':' + (s.last ? s.last.id : 0);
    function visible(s, D) { return spectator() || D === persp() || s.ph === 'e'; }
    function canTarget() {
      return !!st && st.ph === 'f' && api.canAct(st.turn) && !anim && !pending && !queued && bigD() === 1 - st.turn;
    }
    function bigD() {
      const s = vs();
      if (!s) return 0;
      if (anim) return anim.d;
      let D;
      if (s.ph === 'p') { const p = persp(); D = p >= 0 ? p : (actor(s) || 0); return D; }
      if (s.ph === 'e') { const p = persp(); D = p >= 0 && !spectator() ? 1 - p : 1 - s.win; }
      else D = 1 - s.turn;
      return peek ? 1 - D : D;
    }

    /* --- layout --- */
    function layout() {
      const W = cv.w, H = cv.h, pad = 10, hudH = 72, hintH = 30, capH = 20, gut = 15, gap = 10;
      const N = st ? st.N : 10, plc = st && st.ph === 'p';
      const miniS = Math.round(U.clamp(W * 0.3, 92, 150));
      const rowH = plc ? 56 : miniS;
      let s = Math.min(W - pad * 2 - gut, H - hintH - capH - 6 - gut - hudH - rowH - gap * 2);
      s = Math.max(N * 10, s);
      const c = Math.floor(s / N); s = c * N;
      const total = hintH + capH + 6 + gut + s + gap + rowH;
      const top = Math.max(2, Math.floor((H - hudH - total) / 2));
      const bx = Math.round((W - s - gut) / 2) + gut, by = top + hintH + capH + 6 + gut;
      G = { N, W, H, gut, hintY: top + hintH / 2, capY: top + hintH + capH / 2, big: { x: bx, y: by, c, s }, rowY: by + s + gap, rowH, miniS };
      G.mini = { x: bx - gut, y: G.rowY, c: miniS / N, s: miniS };
      G.bg = ctx.createLinearGradient(0, 0, 0, H);
      G.bg.addColorStop(0, '#17132a'); G.bg.addColorStop(1, '#08161d');
      layoutPh = st ? st.ph : '';
      Object.assign(boardMark.style, { left: (bx - gut - 4) + 'px', top: (by - gut - 4) + 'px', width: (s + gut + 8) + 'px', height: (s + gut + 8) + 'px' });
      Object.assign(rowMark.style, { left: (bx - gut) + 'px', top: G.rowY + 'px', width: (s + gut) + 'px', height: rowH + 'px' });
    }
    cv.onresize = () => { if (st) layout(); };

    function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
    function boardLayer(B, labels) {
      const N = G.N, gut = labels ? G.gut : 0, m = labels ? 6 : 4, s = B.s, size = s + gut + m * 2;
      const key = [N, B.c, gut, cv.dpr].join('|');
      if (layers[key]) return layers[key];
      const oc = document.createElement('canvas');
      oc.width = Math.ceil(size * cv.dpr); oc.height = Math.ceil(size * cv.dpr);
      const g = oc.getContext('2d'); g.scale(cv.dpr, cv.dpr);
      const o = gut + m;
      // brass-rimmed console bezel
      const mg = g.createLinearGradient(0, 0, 0, size); mg.addColorStop(0, '#332b40'); mg.addColorStop(1, '#141019');
      rr(g, 0.5, 0.5, size - 1, size - 1, labels ? 12 : 9); g.fillStyle = mg; g.fill();
      g.strokeStyle = 'rgba(227,174,69,.55)'; g.lineWidth = 1.2; g.stroke();
      // sea screen
      const sg = g.createRadialGradient(o + s / 2, o + s / 2, s * 0.05, o + s / 2, o + s / 2, s * 0.75);
      sg.addColorStop(0, '#0d4644'); sg.addColorStop(0.6, '#062a2f'); sg.addColorStop(1, '#021417');
      rr(g, o, o, s, s, 5); g.fillStyle = sg; g.fill();
      g.save(); rr(g, o, o, s, s, 5); g.clip();
      // plankton specks (deterministic)
      let seed = 1234 + N * 7;
      const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      g.fillStyle = 'rgba(150,255,210,.10)';
      for (let i = 0; i < N * 6; i++) { g.beginPath(); g.arc(o + rnd() * s, o + rnd() * s, 0.5 + rnd() * 1.1, 0, 7); g.fill(); }
      // range rings
      g.strokeStyle = 'rgba(80,255,170,.07)'; g.lineWidth = 1;
      for (const f of [0.2, 0.38, 0.56, 0.74]) { g.beginPath(); g.arc(o + s / 2, o + s / 2, s * f, 0, 7); g.stroke(); }
      // grid
      g.strokeStyle = 'rgba(90,255,180,.2)';
      g.beginPath();
      for (let i = 1; i < N; i++) { const p = Math.round(o + i * B.c) + 0.5; g.moveTo(p, o); g.lineTo(p, o + s); g.moveTo(o, p); g.lineTo(o + s, p); }
      g.stroke();
      g.restore();
      g.shadowColor = 'rgba(62,240,166,.7)'; g.shadowBlur = 8;
      rr(g, o, o, s, s, 5); g.strokeStyle = 'rgba(62,240,166,.6)'; g.lineWidth = 1.4; g.stroke();
      g.shadowBlur = 0;
      if (labels) {
        g.fillStyle = 'rgba(150,255,205,.8)'; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.font = '600 ' + Math.round(U.clamp(B.c * 0.36, 9, 12)) + 'px "IBM Plex Mono", monospace';
        for (let i = 0; i < N; i++) {
          g.fillText(COLS[i], o + (i + 0.5) * B.c, m + gut / 2 + 1);
          g.fillText(String(i + 1), m + gut / 2, o + (i + 0.5) * B.c);
        }
      }
      return (layers[key] = { cv: oc, off: o, size });
    }

    /* --- drawing --- */
    function capsule(x, y, w, h) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, h / 2); else ctx.rect(x, y, w, h); }
    function drawSub(B, v, len, style, extra) {
      const N = G.N, vert = v >= 100, c0 = v % 100, x = c0 % N, y = Math.floor(c0 / N), c = B.c;
      const col = STYLE[style] || STYLE.own;
      ctx.save();
      ctx.translate(B.x + x * c, B.y + y * c);
      if (vert) { ctx.translate(c, 0); ctx.rotate(Math.PI / 2); }
      if (style === 'reveal') ctx.globalAlpha *= 0.6;
      if (extra === 'lift') ctx.globalAlpha *= 0.85;
      const Lp = len * c, m = c * 0.1, hh = c * 0.6, top = (c - hh) / 2;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; capsule(m + 1.5, top + 2.5, Lp - 2 * m, hh); ctx.fill();
      const gr = ctx.createLinearGradient(0, top, 0, top + hh);
      gr.addColorStop(0, col[0]); gr.addColorStop(0.55, col[1]); gr.addColorStop(1, col[2]);
      capsule(m, top, Lp - 2 * m, hh); ctx.fillStyle = gr; ctx.fill();
      ctx.lineWidth = extra === 'sel' ? 2.5 : 1.2; ctx.strokeStyle = extra === 'sel' ? '#e3ae45' : col[3]; ctx.stroke();
      // stern fins + propeller
      ctx.strokeStyle = col[2]; ctx.lineWidth = Math.max(1.5, c * 0.08); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(m + c * 0.26, top - c * 0.04); ctx.lineTo(m + c * 0.26, top + hh + c * 0.04); ctx.stroke();
      // deck line
      ctx.strokeStyle = 'rgba(255,255,255,.2)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(m + hh * 0.6, c / 2); ctx.lineTo(Lp - m - hh * 0.6, c / 2); ctx.stroke();
      // sail (conning tower)
      const sw = Math.min(c * 1.15, Lp * 0.3), sx = Lp * 0.45 - sw / 2;
      capsule(sx, c / 2 - hh * 0.28, sw, hh * 0.56); ctx.fillStyle = col[2]; ctx.fill();
      ctx.fillStyle = style === 'sunk' ? 'rgba(255,140,90,.5)' : 'rgba(180,255,230,.55)';
      ctx.beginPath(); ctx.arc(sx + sw * 0.7, c / 2, Math.max(1.2, c * 0.05), 0, 7); ctx.fill();
      // portholes
      ctx.fillStyle = style === 'sunk' ? 'rgba(20,8,4,.6)' : 'rgba(220,250,255,.45)';
      for (let k = 1; k < len; k++) { const px = k * c; if (Math.abs(px - (sx + sw / 2)) < sw * 0.7) continue; ctx.beginPath(); ctx.arc(px, c / 2, Math.max(1, c * 0.045), 0, 7); ctx.fill(); }
      ctx.restore();
    }
    function sunkShown(s, shooter, i) {
      if (!s.sk[shooter].includes(i)) return false;
      return !(anim && anim.k === 'f' && anim.r === 's' && anim.seat === shooter && anim.i === i && anim.t < 0.62);
    }
    function drawSonarBox(B, so) {
      const N = G.N, c = B.c, x = (so[0] % N) - 1, y = Math.floor(so[0] / N) - 1, px = B.x + x * c, py = B.y + y * c;
      ctx.save();
      if (so[1] === 0) { ctx.fillStyle = 'rgba(90,255,170,.08)'; ctx.fillRect(px, py, c * 3, c * 3); }
      ctx.setLineDash([4, 3]); ctx.strokeStyle = 'rgba(90,255,170,.85)'; ctx.lineWidth = 1.5;
      ctx.strokeRect(px + 1, py + 1, c * 3 - 2, c * 3 - 2);
      ctx.setLineDash([]);
      const r = Math.max(7, c * 0.3);
      ctx.fillStyle = '#3ef0a6'; ctx.beginPath(); ctx.arc(px + c * 3 - r - 2, py + r + 2, r, 0, 7); ctx.fill();
      ctx.fillStyle = '#04201a'; ctx.font = '700 ' + Math.round(r * 1.25) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(so[1]), px + c * 3 - r - 2, py + r + 2.5);
      ctx.restore();
    }
    function drawReticle(B, cell, strong, sonar) {
      const N = G.N, c = B.c;
      if (sonar) {
        const cc = clampCenter(cell, N), x = (cc % N) - 1, y = Math.floor(cc / N) - 1;
        ctx.fillStyle = strong ? 'rgba(62,240,166,.18)' : 'rgba(62,240,166,.08)';
        ctx.fillRect(B.x + x * c, B.y + y * c, c * 3, c * 3);
        ctx.strokeStyle = strong ? '#3ef0a6' : 'rgba(62,240,166,.6)'; ctx.lineWidth = 2;
        ctx.strokeRect(B.x + x * c + 1, B.y + y * c + 1, c * 3 - 2, c * 3 - 2);
        return;
      }
      const x = B.x + ((cell % N) + 0.5) * c, y = B.y + (Math.floor(cell / N) + 0.5) * c;
      ctx.strokeStyle = strong ? '#ffd36b' : 'rgba(255,211,107,.55)'; ctx.lineWidth = strong ? 2.2 : 1.5;
      if (strong) { ctx.fillStyle = 'rgba(255,211,107,.16)'; ctx.fillRect(B.x + (cell % N) * c, B.y + Math.floor(cell / N) * c, c, c); }
      const r = c * 0.36 + (strong ? Math.sin(now / 160) * 1.2 : 0);
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x - c * 0.55, y); ctx.lineTo(x - c * 0.18, y); ctx.moveTo(x + c * 0.18, y); ctx.lineTo(x + c * 0.55, y);
      ctx.moveTo(x, y - c * 0.55); ctx.lineTo(x, y - c * 0.18); ctx.moveTo(x, y + c * 0.18); ctx.lineTo(x, y + c * 0.55);
      ctx.stroke();
    }
    function drawBoard(B, D, isBig, ships) {
      const s = vs(), N = G.N, c = B.c, lens = lensOf(N), shooter = 1 - D, sh = s.sh[shooter];
      const L0 = boardLayer(B, isBig);
      ctx.drawImage(L0.cv, B.x - L0.off, B.y - L0.off, L0.size, L0.size);
      ctx.save();
      ctx.beginPath(); ctx.rect(B.x, B.y, B.s, B.s); ctx.clip();
      if (isBig) { // sonar sweep
        const cx = B.x + B.s / 2, cy = B.y + B.s / 2, R = B.s * 0.75, a = now * 0.0011;
        for (let k = 0; k < 8; k++) { ctx.fillStyle = SWEEP[k]; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, a - (k + 1) * 0.07, a - k * 0.07); ctx.closePath(); ctx.fill(); }
        ctx.strokeStyle = 'rgba(120,255,200,.35)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R); ctx.stroke();
      }
      if (ships) { // placement draft
        const bad = conflicts();
        ships.forEach((v, i) => { if (!drag || drag.i !== i) drawSub(B, v, lens[i], bad.has(i) ? 'bad' : 'own', sel === i ? 'sel' : null); });
        if (drag) drawSub(B, ships[drag.i], lens[drag.i], bad.has(drag.i) ? 'bad' : 'own', 'sel');
        ctx.restore();
        return;
      }
      const so = s.so[shooter];
      if (so && !(anim && anim.k === 's' && anim.d === D && anim.t < 0.9)) drawSonarBox(B, so);
      const fl = s.fl[D];
      if (fl) {
        const vis = visible(s, D), mine = D === persp() && !spectator();
        for (let i = 0; i < lens.length; i++) {
          const sk = sunkShown(s, shooter, i);
          if (sk) drawSub(B, fl[i], lens[i], 'sunk');
          else if (vis) drawSub(B, fl[i], lens[i], mine || spectator() || s.ph !== 'e' ? 'own' : 'reveal');
        }
      }
      // shot marks
      const hideC = anim && anim.k === 'f' && anim.d === D && anim.t < 0.38 ? anim.c : -1;
      let sunkCells = null;
      if (fl && s.sk[shooter].length) { sunkCells = new Set(); s.sk[shooter].forEach((i) => { if (sunkShown(s, shooter, i)) cellsOf(fl[i], lens[i], N).forEach((k) => sunkCells.add(k)); }); }
      const fl2 = 0.75 + 0.25 * Math.sin(now / 130);
      for (let k = 0; k < N * N; k++) {
        const ch = sh[k];
        if (ch === '.' || k === hideC) continue;
        const x = B.x + ((k % N) + 0.5) * c, y = B.y + (Math.floor(k / N) + 0.5) * c;
        if (ch === 'o') {
          ctx.strokeStyle = 'rgba(190,235,255,.35)'; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.arc(x, y, c * 0.27, 0, 7); ctx.stroke();
          ctx.fillStyle = 'rgba(205,240,255,.8)'; ctx.beginPath(); ctx.arc(x, y, Math.max(1.6, c * 0.11), 0, 7); ctx.fill();
        } else if (sunkCells && sunkCells.has(k)) {
          ctx.fillStyle = 'rgba(255,150,90,.85)'; ctx.beginPath(); ctx.arc(x, y, Math.max(1.6, c * 0.1), 0, 7); ctx.fill();
        } else {
          const gr = ctx.createRadialGradient(x, y, 0, x, y, c * 0.48);
          gr.addColorStop(0, 'rgba(255,200,90,' + (0.9 * fl2).toFixed(2) + ')'); gr.addColorStop(0.45, 'rgba(255,90,50,' + (0.55 * fl2).toFixed(2) + ')'); gr.addColorStop(1, 'rgba(255,60,40,0)');
          ctx.fillStyle = gr; ctx.fillRect(x - c * 0.5, y - c * 0.5, c, c);
          ctx.fillStyle = '#ff5a3a'; ctx.beginPath(); ctx.arc(x, y, Math.max(2, c * 0.16), 0, 7); ctx.fill();
          ctx.fillStyle = '#ffe3a0'; ctx.beginPath(); ctx.arc(x - c * 0.04, y - c * 0.04, Math.max(1, c * 0.06), 0, 7); ctx.fill();
        }
      }
      // last shot on this board
      const l = s.last;
      if (!anim && l && l.k === 'f' && 1 - l.seat === D) {
        const x = B.x + (l.c % N) * c, y = B.y + Math.floor(l.c / N) * c;
        ctx.strokeStyle = 'rgba(227,174,69,' + (0.55 + 0.35 * Math.sin(now / 220)).toFixed(2) + ')'; ctx.lineWidth = isBig ? 2 : 1.5;
        ctx.strokeRect(x + 1, y + 1, c - 2, c - 2);
      }
      if (isBig && canTarget()) {
        if (hover >= 0 && hover !== aim) drawReticle(B, hover, false, sonarMode);
        if (aim >= 0) drawReticle(B, aim, true, sonarMode);
      }
      ctx.restore();
    }
    function drawText(t, x, y, size, color, align, weight) {
      ctx.font = (weight || 700) + ' ' + size + 'px "IBM Plex Sans KR", "Apple SD Gothic Neo", sans-serif';
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = color; ctx.fillText(t, x, y);
    }
    function fitText(t, maxW, size, weight) {
      ctx.font = (weight || 700) + ' ' + size + 'px "IBM Plex Sans KR", "Apple SD Gothic Neo", sans-serif';
      if (ctx.measureText(t).width <= maxW) return t;
      while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
      return t + '…';
    }
    function hintText() {
      const s = st;
      if (s.ph === 'e') { const p = persp(); return spectator() || p < 0 ? nm(s.win) + ' 승리!' : s.win === p ? '승리! 상대 함대를 모두 찾았어요' : '내 함대가 모두 가라앉았어요'; }
      const a = actor(s);
      if (s.ph === 'p') return placing() ? '배를 끌어서 옮기고, 고른 배를 한 번 더 톡 하면 돌아가요' : nm(a) + ' 함대 숨기는 중…';
      if (anim || queued) {
        const who = anim && !api.canAct(anim.seat) ? nm(anim.seat) + ' ' : '';
        return who + (anim && anim.k === 's' ? '소나 탐지 중…' : '발사!');
      }
      if (api.canAct(a)) {
        if (pending) return '발사!';
        if (peek) return '내 바다를 보는 중 · 아래 작은 판을 톡 하면 돌아가요';
        if (sonarMode) return aim >= 0 ? label(aim, s.N) + ' 주변 3×3 · 소나 쏘기를 누르세요' : '소나로 살펴볼 구역을 톡 하세요';
        return aim >= 0 ? label(aim, s.N) + ' 조준 · 발사 버튼 또는 한 번 더 톡' : '상대 바다에서 쏠 칸을 톡 하세요';
      }
      return nm(a) + (api.players[a] && api.players[a].ai ? ' 조준 중…' : ' 차례');
    }
    function drawHeader(D) {
      const s = vs(), B = G.big, mineTurn = st.ph !== 'e' && actor(st) != null && api.canAct(actor(st));
      const t = fitText(hintText(), G.W - 24, 14);
      drawText(t, G.W / 2, G.hintY, 14, mineTurn ? '#e3ae45' : '#d9cfe6');
      const left = B.x - G.gut, right = B.x + B.s;
      let cap;
      if (s.ph === 'p') cap = placing() ? '내 바다 · 함대 숨기기' : (D === persp() ? '내 바다' : nm(D) + '의 바다');
      else cap = spectator() || persp() < 0 ? nm(D) + '의 바다' : D === persp() ? '내 바다' : '상대 바다';
      ctx.fillStyle = api.players[D] ? api.players[D].color : '#888';
      ctx.beginPath(); ctx.arc(left + 5, G.capY, 4.5, 0, 7); ctx.fill();
      drawText(fitText(cap, B.s * 0.55, 13), left + 14, G.capY, 13, '#f2e9d8', 'left');
      if (s.ph !== 'p') {
        const t2 = shotStats(s.sh[1 - D]);
        drawText('발사 ' + t2.shots + ' · 명중 ' + t2.hits, right, G.capY, 12, '#ab9fb8', 'right', 600);
      }
    }
    function drawFleets(s) {
      const x0 = G.mini.x + G.miniS + 10, x1 = G.big.x + G.big.s, y0 = G.rowY, h = G.miniS, w = x1 - x0;
      if (w < 110) return;
      const P = persp(), spec = spectator() || P < 0, N = G.N, lens = lensOf(N), names = namesOf(N);
      const seats = spec ? [0, 1] : [1 - P, P];
      const colW = (w - 8) / 2;
      seats.forEach((seat, j) => {
        const cx = x0 + j * (colW + 8);
        rr(ctx, cx, y0, colW, h, 9); ctx.fillStyle = 'rgba(28,22,40,.75)'; ctx.fill();
        ctx.strokeStyle = 'rgba(227,174,69,.28)'; ctx.lineWidth = 1; ctx.stroke();
        const shooter = 1 - seat, fl = s.fl[seat], vis = spec || seat === P || s.ph === 'e';
        let alive = 0; lens.forEach((_, i) => { if (!sunkShown(s, shooter, i)) alive++; });
        ctx.fillStyle = api.players[seat] ? api.players[seat].color : '#888';
        ctx.beginPath(); ctx.arc(cx + 10, y0 + 13, 4, 0, 7); ctx.fill();
        const head = !spec && seat === P ? '내 함대' : !spec ? '상대 함대' : nm(seat);
        drawText(fitText(head, colW - 46, 12), cx + 18, y0 + 13, 12, '#f2e9d8', 'left');
        drawText(alive + '/' + lens.length, cx + colW - 8, y0 + 13, 11, alive ? '#3ef0a6' : '#ee6a55', 'right', 700);
        const step = Math.min(19, (h - 28) / lens.length), u = Math.min(11, (colW - 16) / 5), bh = Math.max(5, Math.min(9, step - 6));
        const showName = colW - 8 - 5 * u - 8 >= 26;
        const hitSh = s.sh[shooter];
        lens.forEach((len, i) => {
          const y = y0 + 26 + i * step + (step - bh) / 2;
          const sunk = sunkShown(s, shooter, i);
          const cells = fl ? cellsOf(fl[i], len, N) : null;
          for (let k = 0; k < len; k++) {
            const hit = vis && cells && hitSh[cells[k]] === 'x';
            ctx.fillStyle = sunk ? '#8a3f2c' : hit ? '#ff6a45' : vis ? '#7fa3b3' : 'rgba(127,163,179,.4)';
            rr(ctx, cx + 8 + k * u, y, u - 1.5, bh, 2); ctx.fill();
          }
          if (sunk) { ctx.strokeStyle = '#ffb199'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(cx + 6, y + bh / 2); ctx.lineTo(cx + 10 + len * u, y + bh / 2); ctx.stroke(); }
          if (showName) drawText(names[i], cx + 8 + 5 * u + 6, y + bh / 2, 10, sunk ? '#a0897f' : '#c9bfd6', 'left', 600);
        });
      });
    }
    function drawMiniTag(D) {
      const B = G.mini, P = persp();
      const t = spectator() || P < 0 ? nm(D) : D === P ? '내 바다' : '상대 바다';
      ctx.font = '700 10px "IBM Plex Sans KR", sans-serif';
      const w = ctx.measureText(t).width + 10;
      rr(ctx, B.x + 3, B.y + 3, w, 15, 7); ctx.fillStyle = 'rgba(5,15,18,.75)'; ctx.fill();
      drawText(t, B.x + 8, B.y + 11, 10, '#bfffe4', 'left');
      if (st.ph === 'f') { // "tap to enlarge" glyph
        ctx.strokeStyle = 'rgba(191,255,228,.75)'; ctx.lineWidth = 1.5;
        const x = B.x + B.s - 15, y = B.y + B.s - 15;
        ctx.beginPath(); ctx.moveTo(x, y + 4); ctx.lineTo(x, y); ctx.lineTo(x + 4, y); ctx.moveTo(x + 10, y + 6); ctx.lineTo(x + 10, y + 10); ctx.lineTo(x + 6, y + 10); ctx.moveTo(x, y); ctx.lineTo(x + 10, y + 10); ctx.stroke();
      }
    }
    function drawAnim() {
      const B = G.big, N = G.N, c = B.c, t = anim.t;
      const x = B.x + ((anim.c % N) + 0.5) * c, y = B.y + (Math.floor(anim.c / N) + 0.5) * c;
      ctx.save();
      ctx.beginPath(); ctx.rect(B.x - 4, B.y - 4, B.s + 8, B.s + 8); ctx.clip();
      if (anim.k === 'f') {
        const T = 0.38;
        if (t < T) {
          const u = t / T;
          ctx.strokeStyle = 'rgba(255,215,120,' + (0.35 + 0.6 * u).toFixed(2) + ')'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(x, y, c * (1.7 - 1.25 * u), 0, 7); ctx.stroke();
          ctx.fillStyle = 'rgba(0,0,0,' + (0.15 + 0.3 * u).toFixed(2) + ')';
          ctx.beginPath(); ctx.ellipse(x, y, c * 0.18 * (0.4 + u), c * 0.12 * (0.4 + u), 0, 0, 7); ctx.fill();
          const sy = y - (1 - u) * c * 3.2;
          ctx.strokeStyle = 'rgba(255,240,200,.35)'; ctx.lineWidth = c * 0.08;
          ctx.beginPath(); ctx.moveTo(x, sy - c * 0.8); ctx.lineTo(x, sy); ctx.stroke();
          ctx.fillStyle = '#e8e2d0'; ctx.beginPath(); ctx.arc(x, sy, Math.max(2.5, c * 0.13), 0, 7); ctx.fill();
        } else {
          const u = (t - T) / (anim.dur - T);
          if (anim.r === 'o') {
            for (let k = 0; k < 3; k++) {
              const q = U.clamp(u * 1.3 - k * 0.18, 0, 1);
              if (q <= 0 || q >= 1) continue;
              ctx.strokeStyle = 'rgba(200,240,255,' + (0.8 * (1 - q)).toFixed(2) + ')'; ctx.lineWidth = 2;
              ctx.beginPath(); ctx.arc(x, y, c * (0.15 + q * 0.75), 0, 7); ctx.stroke();
            }
          } else {
            const big = anim.r === 's' ? 1.5 : 1;
            const gr = ctx.createRadialGradient(x, y, 0, x, y, c * (0.5 + u * 0.9) * big);
            gr.addColorStop(0, 'rgba(255,240,180,' + (1 - u).toFixed(2) + ')'); gr.addColorStop(0.4, 'rgba(255,120,50,' + (0.8 * (1 - u)).toFixed(2) + ')'); gr.addColorStop(1, 'rgba(255,60,30,0)');
            ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, c * (0.5 + u * 0.9) * big, 0, 7); ctx.fill();
            if (anim.r === 's' && t >= 0.62) { // sunk: flash the whole hull outline
              const fl = anim.s.fl[anim.d], len = lensOf(N)[anim.i];
              const cs = cellsOf(fl[anim.i], len, N), x0 = cs[0] % N, y0 = Math.floor(cs[0] / N), vert = fl[anim.i] >= 100;
              const q = U.clamp((t - 0.62) / (anim.dur - 0.62), 0, 1);
              ctx.strokeStyle = 'rgba(255,140,90,' + (1 - q).toFixed(2) + ')'; ctx.lineWidth = 3 + 4 * (1 - q);
              ctx.strokeRect(B.x + x0 * c - 2, B.y + y0 * c - 2, (vert ? 1 : len) * c + 4, (vert ? len : 1) * c + 4);
            }
          }
          for (const p of parts) {
            ctx.globalAlpha = U.clamp(p.life, 0, 1);
            ctx.fillStyle = p.col; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
          }
          ctx.globalAlpha = 1;
        }
      } else { // sonar
        const cc = anim.c, cx = B.x + ((cc % N) + 0.5) * c, cy = B.y + (Math.floor(cc / N) + 0.5) * c;
        for (let k = 0; k < 3; k++) {
          const q = U.clamp((t - k * 0.25) / 0.6, 0, 1);
          if (q <= 0 || q >= 1) continue;
          ctx.strokeStyle = 'rgba(62,240,166,' + (0.9 * (1 - q)).toFixed(2) + ')'; ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.arc(cx, cy, c * (0.2 + q * 1.6), 0, 7); ctx.stroke();
        }
        if (t >= 0.9) drawSonarBox(B, [cc, anim.n]);
      }
      ctx.restore();
      // floating result text
      if (anim.txt && t >= anim.tt) {
        const q = U.clamp((t - anim.tt) / (anim.dur - anim.tt), 0, 1);
        const tx = U.clamp(x, B.x + 70, B.x + B.s - 70), ty = Math.max(B.y + 16, y - c * 0.9) - q * c * 0.5;
        ctx.globalAlpha = q < 0.75 ? 1 : (1 - q) / 0.25;
        ctx.font = '22px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(5,12,16,.9)'; ctx.strokeText(anim.txt, tx, ty);
        ctx.fillStyle = anim.col; ctx.fillText(anim.txt, tx, ty);
        ctx.globalAlpha = 1;
      }
    }
    function drawPlacementInfo() {
      const N = G.N, lens = lensOf(N), names = namesOf(N), y = G.rowY + 12;
      const t = lens.map((l, i) => names[i] + ' ' + l).join(' · ');
      drawText(fitText('숨길 배: ' + t, G.W - 24, 12, 600), G.W / 2, y, 12, '#c9bfd6', 'center', 600);
      drawText(fitText('가로·세로로 놓고 겹치지만 않으면 붙여도 돼요', G.W - 24, 12, 600), G.W / 2, y + 20, 12, '#ab9fb8', 'center', 600);
    }
    function draw(dt) {
      cv.clear();
      ctx.fillStyle = G ? G.bg : '#17131f'; ctx.fillRect(0, 0, cv.w, cv.h);
      if (!st || !G) return;
      const D = bigD();
      if (D !== shownD) { if (shownD >= 0) fade = 0; shownD = D; }
      fade = Math.min(1, fade + dt * 6 * L.debug.speed);
      drawHeader(D);
      let sx = 0, sy = 0;
      if (anim && anim.k === 'f' && anim.r !== 'o' && anim.t > 0.38 && anim.t < 0.7) { const a = (0.7 - anim.t) * (anim.r === 's' ? 14 : 8); sx = (Math.random() - 0.5) * a; sy = (Math.random() - 0.5) * a; }
      ctx.save(); ctx.translate(sx, sy);
      ctx.globalAlpha = 0.3 + 0.7 * fade;
      drawBoard(G.big, D, true, placing() ? draft : null);
      ctx.globalAlpha = 1;
      if (anim) drawAnim();
      ctx.restore();
      if (st.ph === 'p') { drawPlacementInfo(); return; }
      drawBoard(G.mini, 1 - D, false, null);
      drawMiniTag(1 - D);
      drawFleets(vs());
    }

    /* --- animation --- */
    function startAnim(last, s) {
      const N = s.N;
      anim = { k: last.k, d: 1 - last.seat, c: last.c, r: last.r, i: last.i, n: last.n, seat: last.seat, t: 0, s, hit: false, txt: '', tt: 0.38, col: '#fff' };
      if (last.k === 's') {
        anim.dur = 1.35; anim.tt = 0.9;
        anim.txt = last.n ? '배 조각 ' + last.n + '칸!' : '조용해요… 0칸'; anim.col = '#3ef0a6';
        api.sfx('pop');
      } else {
        anim.dur = last.r === 's' ? 1.45 : last.r === 'x' ? 1.05 : 0.95;
        anim.txt = last.r === 'o' ? '빗나감' : last.r === 'x' ? '명중!' : namesOf(N)[last.i] + ' 격침!';
        anim.col = last.r === 'o' ? '#cdeeff' : last.r === 'x' ? '#ffb15a' : '#ff7a55';
        api.sfx('whoosh');
      }
      peek = false; parts.length = 0;
      api.setBusy(true);
      clearTimeout(watchdog);
      watchdog = setTimeout(endAnim, (anim.dur * 1000) / L.debug.speed + 1500);
    }
    function impact() {
      const B = G.big, N = G.N, c = B.c;
      const x = B.x + ((anim.c % N) + 0.5) * c, y = B.y + (Math.floor(anim.c / N) + 0.5) * c;
      const P = persp(), victimMine = anim.d === P && api.canAct(P), shooterMine = api.canAct(anim.seat) && !spectator();
      if (anim.r === 'o') {
        api.sfx('bounce');
        for (let k = 0; k < 12; k++) { const a = Math.random() * 6.28, v = c * (1.2 + Math.random() * 2); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.7 + Math.random() * 0.3, r: Math.max(1, c * 0.06), col: '#d8f3ff' }); }
      } else {
        api.sfx(anim.r === 's' ? 'thud' : 'hit');
        if (victimMine) api.buzz(anim.r === 's' ? 70 : 35); else if (shooterMine) api.buzz(18);
        const n = anim.r === 's' ? 26 : 16;
        for (let k = 0; k < n; k++) { const a = Math.random() * 6.28, v = c * (1.5 + Math.random() * (anim.r === 's' ? 3.5 : 2.4)); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.6 + Math.random() * 0.5, r: Math.max(1.2, c * (0.05 + Math.random() * 0.07)), col: Math.random() < 0.5 ? '#ffcf6b' : '#ff6a3d' }); }
        for (let k = 0; k < 6; k++) parts.push({ x: x + (Math.random() - 0.5) * c * 0.4, y: y + (Math.random() - 0.5) * c * 0.4, vx: (Math.random() - 0.5) * c, vy: -c * (0.3 + Math.random() * 0.5), life: 1, r: c * (0.18 + Math.random() * 0.12), col: 'rgba(60,60,70,.55)' });
        if (anim.r === 's') {
          const nmShip = namesOf(N)[anim.i];
          api.toast(victimMine ? '내 ' + nmShip + '가 가라앉았어요' : shooterMine ? '상대 ' + nmShip + ' 격침!' : nm(anim.seat) + ' · ' + nmShip + ' 격침!');
        }
      }
    }
    function tickAnim(dt) {
      if (!anim) return;
      const t0 = anim.t;
      anim.t += dt * L.debug.speed;
      if (anim.k === 'f' && t0 < 0.38 && anim.t >= 0.38) impact();
      if (anim.k === 's') {
        for (const k of [0, 0.25, 0.5]) if (t0 < k + 0.001 && anim.t >= k + 0.001 && k > 0) api.sfx('tick');
        if (t0 < 0.9 && anim.t >= 0.9) { api.sfx(anim.n ? 'chip' : 'click'); if (api.canAct(anim.seat)) api.buzz(12); }
      }
      if (anim.k === 'f' && anim.r === 's' && t0 < 0.62 && anim.t >= 0.62) {
        const P = persp();
        api.sfx(api.canAct(anim.seat) && !spectator() ? 'win' : anim.d === P && api.canAct(P) ? 'lose' : 'chip');
      }
      const sdt = dt * L.debug.speed;
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.x += p.vx * sdt; p.y += p.vy * sdt; p.vx *= 1 - 2.5 * sdt; p.vy *= 1 - 2.5 * sdt; p.life -= sdt * 1.3;
        if (p.life <= 0) parts.splice(i, 1);
      }
      if (anim.t >= anim.dur) endAnim();
    }
    function endAnim() {
      if (!anim) return;
      anim = null; parts.length = 0;
      clearTimeout(watchdog);
      api.setBusy(false);
      if (queued) { const a = queued; queued = null; api.act(a); }
      refreshHud();
    }

    /* --- placement --- */
    function conflicts() {
      const out = new Set();
      if (!draft || !st) return out;
      const N = st.N, lens = lensOf(N), own = new Int8Array(N * N).fill(-1);
      draft.forEach((v, i) => cellsOf(v, lens[i], N).forEach((c) => { if (own[c] >= 0) { out.add(i); out.add(own[c]); } else own[c] = i; }));
      return out;
    }
    function overlapsOthers(v, i) {
      const N = st.N, lens = lensOf(N), mine = cellsOf(v, lens[i], N);
      return draft.some((w, j) => j !== i && cellsOf(w, lens[j], N).some((c) => mine.includes(c)));
    }
    function shipAt(c) {
      const N = st.N, lens = lensOf(N);
      for (let i = draft.length - 1; i >= 0; i--) if (cellsOf(draft[i], lens[i], N).includes(c)) return i;
      return -1;
    }
    function anchorV(x, y, vert, len) {
      const N = st.N;
      x = U.clamp(x, 0, vert ? N - 1 : N - len); y = U.clamp(y, 0, vert ? N - len : N - 1);
      return y * N + x + (vert ? 100 : 0);
    }
    function rotateShip(i) {
      if (!placing() || i < 0) return;
      const N = st.N, len = lensOf(N)[i], v = draft[i], vert = v >= 100, c0 = v % 100, x = c0 % N, y = Math.floor(c0 / N);
      for (let d = 0; d <= 3; d++) for (let dy = -d; dy <= d; dy++) for (let dx = -d; dx <= d; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== d) continue;
        const cand = anchorV(x + dx, y + dy, !vert, len);
        if (!overlapsOthers(cand, i)) { draft[i] = cand; api.sfx('click'); api.buzz(8); refreshHud(); return; }
      }
      api.toast('돌릴 자리가 없어요'); api.buzz(20); api.sfx('thud');
    }
    function moveShip(i, dx, dy) {
      const N = st.N, len = lensOf(N)[i], v = draft[i], vert = v >= 100, c0 = v % 100;
      const cand = anchorV((c0 % N) + dx, Math.floor(c0 / N) + dy, vert, len);
      if (cand !== v && !overlapsOthers(cand, i)) { draft[i] = cand; api.sfx('tick'); }
    }
    function placeDone() {
      if (!placing() || pending) return;
      if (conflicts().size || !validFleet(draft, st.N)) { api.toast('겹친 배가 있어요'); api.buzz(20); return; }
      api.sfx('chip'); api.buzz(15);
      pending = true; clearTimeout(pendTimer); pendTimer = setTimeout(() => { pending = false; refreshHud(); }, 4000);
      sel = -1;
      api.act({ t: 'p', f: draft.slice() });
      refreshHud();
    }

    /* --- firing --- */
    function setAim(c, fromTap) {
      if (c < 0) return;
      if (sonarMode) c = clampCenter(c, st.N);
      else if (st.sh[st.turn][c] !== '.') { if (fromTap) { api.buzz(8); api.toast('이미 쏜 칸이에요'); } return; }
      if (aim !== c) { aim = c; api.sfx('tick'); refreshHud(); }
    }
    function toggleSonar() {
      if (!canTarget() || !(st.sn[st.turn] > 0)) return;
      sonarMode = !sonarMode; aim = -1; hover = -1;
      api.sfx('click'); refreshHud();
    }
    function fire() {
      if (!canTarget() || aim < 0) return;
      const action = sonarMode ? { t: 's', c: clampCenter(aim, st.N) } : { t: 'f', c: aim };
      aim = -1; hover = -1; sonarMode = false;
      api.buzz(15);
      if (localMulti()) { // pass-and-play: show the result before the curtain comes down
        let nx;
        try { nx = apply(U.clone(st), st.turn, action); } catch (e) { return; }
        queued = action; preKey = keyOf(nx);
        startAnim(nx.last, nx);
        refreshHud();
        return;
      }
      pending = true; clearTimeout(pendTimer); pendTimer = setTimeout(() => { pending = false; refreshHud(); }, 4000);
      api.act(action);
      refreshHud();
    }

    /* --- HUD --- */
    function setTxt(b, t) { if (b.textContent !== t) b.textContent = t; }
    function refreshHud() {
      if (!st) return;
      const plc = placing();
      bRot.hidden = bAuto.hidden = bDone.hidden = !plc;
      bDone.disabled = pending;
      const ctl = st.ph === 'f' && api.canAct(st.turn);
      bFire.hidden = !ctl;
      const sn = st.sn[st.turn], hasSonar = ctl && (sn > 0 || !!st.so[st.turn]);
      bSonar.hidden = !hasSonar;
      if (ctl) {
        const busy = !!anim || pending || !!queued || peek;
        setTxt(bFire, sonarMode ? (aim >= 0 ? '소나 쏘기' : '구역을 고르세요') : aim >= 0 ? '🎯 ' + label(aim, st.N) + ' 발사' : '칸을 고르세요');
        bFire.disabled = busy || aim < 0;
        setTxt(bSonar, sonarMode ? '취소' : sn > 0 ? '소나 ' + sn + '회' : '소나 끝');
        bSonar.disabled = busy || !(sn > 0);
        bSonar.classList.toggle('ghost', !sonarMode);
      }
      cv.cv.style.cursor = plc ? 'grab' : canTarget() ? 'crosshair' : 'default';
    }

    /* --- input --- */
    function gridXY(B, p) { return { x: Math.floor((p.x - B.x) / B.c), y: Math.floor((p.y - B.y) / B.c) }; }
    function cellIn(B, p) { const q = gridXY(B, p), N = G.N; return q.x >= 0 && q.y >= 0 && q.x < N && q.y < N ? q.y * N + q.x : -1; }
    function inRect(p, B) { return p.x >= B.x - 4 && p.y >= B.y - 4 && p.x <= B.x + B.s + 4 && p.y <= B.y + B.s + 4; }
    function onDown(e) {
      if (!st || !G) return;
      const p = cv.local(e);
      if (st.ph === 'p') {
        if (!placing() || pending) return;
        const c = cellIn(G.big, p);
        if (c < 0) { sel = -1; return; }
        const i = shipAt(c);
        if (i < 0) { sel = -1; return; }
        const cs = cellsOf(draft[i], lensOf(st.N)[i], st.N);
        drag = { i, orig: draft[i], grab: cs.indexOf(c), moved: false, wasSel: sel === i, id: e.pointerId };
        sel = i; api.sfx('click');
        try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
        return;
      }
      if (st.ph !== 'f') return;
      if (inRect(p, G.mini)) { if (anim || queued) return; peek = !peek; aim = -1; sonarMode = false; api.sfx('click'); refreshHud(); return; }
      if (!canTarget()) return;
      const c = cellIn(G.big, p);
      if (c < 0) return;
      const target = sonarMode ? clampCenter(c, st.N) : c;
      aimDrag = { prev: aim, moved: false, id: e.pointerId };
      setAim(c, true);
      if (aim !== target) aimDrag.moved = true;
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
    }
    function onMove(e) {
      if (!st || !G) return;
      const p = cv.local(e);
      if (drag) {
        const q = gridXY(G.big, p), N = st.N, len = lensOf(N)[drag.i], vert = draft[drag.i] >= 100;
        const v = anchorV(vert ? q.x : q.x - drag.grab, vert ? q.y - drag.grab : q.y, vert, len);
        if (v !== draft[drag.i]) { draft[drag.i] = v; drag.moved = true; }
        return;
      }
      if (aimDrag) {
        const c = cellIn(G.big, p);
        if (c >= 0) { const before = aim; setAim(c, false); if (aim !== before) aimDrag.moved = true; }
        return;
      }
      if (e.pointerType === 'mouse' && canTarget()) { const c = cellIn(G.big, p); hover = c >= 0 && (sonarMode || st.sh[st.turn][c] === '.') ? c : -1; }
    }
    function onUp(e) {
      if (drag) {
        const d = drag; drag = null;
        if (!d.moved) { if (d.wasSel) rotateShip(d.i); }
        else if (conflicts().has(d.i)) { draft[d.i] = d.orig; api.sfx('thud'); api.buzz(20); api.toast('다른 배와 겹쳐요'); }
        else { api.sfx('click'); api.buzz(8); }
        refreshHud();
        return;
      }
      if (aimDrag) {
        const d = aimDrag; aimDrag = null;
        if (e.type === 'pointerup' && !d.moved && aim >= 0 && d.prev === aim) fire();
        refreshHud();
      }
    }
    function onLeave() { if (hover >= 0) hover = -1; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('pointerleave', onLeave);

    function onKey(e) {
      if (!st || !G || !root.isConnected || root.querySelector('.overlay')) return;
      if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
      const N = st.N, k = e.key;
      const dirs = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
      if (placing()) {
        if (dirs[k]) { if (sel < 0) sel = 0; moveShip(sel, dirs[k][0], dirs[k][1]); e.preventDefault(); }
        else if (k === 'r' || k === 'R' || k === ' ') { if (sel < 0) sel = 0; rotateShip(sel); e.preventDefault(); }
        else if (k === 'Tab') { sel = (sel + 1) % draft.length; e.preventDefault(); }
        else if (k === 'a' || k === 'A') bAuto.click();
        else if (k === 'Enter') { placeDone(); e.preventDefault(); }
        return;
      }
      if (!canTarget()) return;
      if (dirs[k]) {
        if (kcur < 0) kcur = aim >= 0 ? aim : Math.floor(N / 2) * N + Math.floor(N / 2);
        const x = U.clamp((kcur % N) + dirs[k][0], 0, N - 1), y = U.clamp(Math.floor(kcur / N) + dirs[k][1], 0, N - 1);
        kcur = y * N + x;
        if (sonarMode || st.sh[st.turn][kcur] === '.') { setAim(kcur, false); hover = -1; } else { aim = -1; hover = kcur; refreshHud(); }
        e.preventDefault();
      } else if (k === 'Enter' || k === ' ') { fire(); e.preventDefault(); }
      else if (k === 's' || k === 'S') toggleSonar();
      else if (k === 'Escape') { if (aim >= 0 || sonarMode) e.preventDefault(); aim = -1; if (sonarMode) toggleSonar(); refreshHud(); }
    }
    window.addEventListener('keydown', onKey);

    const stopLoop = U.loop((dt) => {
      now += dt * 1000;
      tickAnim(dt);
      acc += dt;
      if (!anim && !drag && !aimDrag && fade >= 1 && acc < 1 / 30) return; // idle: ~30 fps is plenty for the sweep
      const d = acc; acc = 0;
      draw(d);
    });

    return {
      update(next, prev) {
        st = next;
        pending = false; clearTimeout(pendTimer);
        if (next.g !== curG) { curG = next.g; draftFor = -1; preKey = ''; queued = null; peek = false; aim = -1; sonarMode = false; shownD = -1; }
        if (!G || G.N !== next.N || layoutPh !== next.ph) layout();
        const key = keyOf(next);
        if (key !== lastKey) {
          lastKey = key;
          const l = next.last;
          if (key === preKey) preKey = '';
          else if (l && prev && (l.k === 'f' || l.k === 's')) { if (anim) endAnim(); startAnim(l, next); }
          else if (l && l.k === 'p' && prev && !api.canAct(l.seat)) api.sfx('chip');
          if (!api.canAct(next.turn) || next.ph !== 'f') { aim = -1; sonarMode = false; }
          if (aim >= 0 && next.sh[next.turn][aim] !== '.') aim = -1;
          hover = -1; kcur = -1;
        }
        if (next.ph === 'p' && placing()) {
          const a = actor(next);
          if (draftFor !== a) { draft = randomFleet(next.N); draftFor = a; sel = -1; }
        } else drag = null;
        if (next.ph !== 'f') { aimDrag = null; peek = false; }
        refreshHud();
        draw(0);
      },
      destroy() {
        stopLoop();
        clearTimeout(watchdog); clearTimeout(pendTimer);
        if (anim) { anim = null; api.setBusy(false); }
        window.removeEventListener('keydown', onKey);
        cv.destroy(); hud.remove(); boardMark.remove(); rowMark.remove();
      },
    };
  }

  const ICON = '<rect x="6" y="30" width="38" height="12" rx="6" fill="currentColor"/>' +
    '<rect x="19" y="22" width="12" height="10" rx="3" fill="currentColor"/>' +
    '<path d="M27 22v-7h5" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>' +
    '<path d="M43 36l8-6v12z" fill="currentColor"/>' +
    '<circle cx="14" cy="36" r="2.2" fill="#0d4a4c"/>' +
    '<path d="M38 13a9 9 0 0 1 9 9M38 6a16 16 0 0 1 16 16" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round" opacity=".7"/>' +
    '<path d="M4 50q5-4 10 0t10 0 10 0 10 0 10 0" stroke="currentColor" stroke-width="2.5" fill="none" opacity=".55"/>';

  L.register({
    id: 'submarine', name: '잠수함 숨바꼭질', tag: '숨은 함대 · 추리', cat: '보드', hidden: true,
    icon: ICON, tint: '#0d4a4c',
    blurb: '내 바다에 잠수함을 몰래 숨기고, 상대 바다를 한 칸씩 쏴서 숨은 함대를 먼저 모두 가라앉히면 승리!',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, aiDelay: 760,
    options: [
      { id: 'size', label: '바다 크기', choices: [{ v: '10', label: '10×10 (5척)' }, { v: '8', label: '8×8 (4척, 짧게)' }], def: '10' },
      { id: 'extra', label: '맞히면 한 번 더', choices: [{ v: '0', label: '끔' }, { v: '1', label: '켬' }], def: '0' },
      { id: 'sonar', label: '소나', choices: [{ v: '1', label: '한 판에 1번' }, { v: '0', label: '없음' }], def: '1' },
    ],
    quick: [
      '내 바다에 잠수함을 몰래 숨기고, 상대 바다에 숨은 잠수함을 먼저 모두 가라앉히면 이겨요.',
      '내 차례: 상대 바다에서 한 칸을 골라 쏴요. 물보라 = 빗나감, 불꽃 = 명중!',
      '배의 모든 칸을 맞히면 격침. 한 판에 한 번 「소나」로 3×3 구역의 배 칸 수를 알아볼 수 있어요.',
    ],
    rules: [
      { h: '목표', p: [
        '두 사람이 각자 바다에 잠수함 함대를 숨겨요.',
        '상대 함대를 먼저 모두 가라앉히는 사람이 이겨요.'] },
      { h: '준비 (숨기기)', p: [
        '내 바다(10×10)에 잠수함 5척을 숨겨요: 고래 5칸 · 상어 4칸 · 돌고래 3칸 · 가오리 3칸 · 해마 2칸.',
        '배는 가로나 세로로 일자로 놓아요. 겹치면 안 되지만 서로 붙는 건 괜찮아요.',
        '배를 끌어서 옮기고, 고른 배를 한 번 더 톡 하거나 「↻ 회전」을 누르면 가로·세로가 바뀌어요. 「자동 배치」로 한 번에 놓을 수도 있어요.',
        '다 놓았으면 「숨기기 완료」. 상대는 내 배 위치를 볼 수 없어요.'] },
      { h: '차례에 할 일', p: [
        '상대 바다에서 아직 안 쏜 칸 하나를 골라 쏴요.',
        '물보라 = 빗나감, 불꽃 = 명중!',
        '기본은 한 발 쏘면 차례가 넘어가요. 「맞히면 한 번 더」(설정, 기본 끔)를 켜면 맞힐 때마다 한 발 더 쏴요.',
        '발사 대신 소나를 쓸 수도 있어요(아래 참고).'] },
      { h: '점수·승리', p: [
        '어떤 배의 모든 칸을 맞히면 「격침」! 어느 배인지 알려 주고 모양이 드러나요.',
        '상대 배를 모두 격침하면 승리. 결과 화면에 몇 발 만에 이겼는지, 명중률이 나와요.'] },
      { h: '소나 (특수 규칙)', p: [
        '설정에서 켜면(기본 켬) 한 판에 한 번, 발사 대신 소나를 쓸 수 있어요. 차례를 한 번 써요.',
        '고른 3×3 구역(9칸)에 배 조각이 몇 칸 있는지 숫자로 알려 줘요. 이미 맞힌 칸도 세요.',
        '0이면 그 구역은 텅 빈 바다예요. 숫자가 크면 그 근처를 노리세요!'] },
      { h: '조작', p: [
        '칸을 톡 하면 조준, 「발사」를 누르거나 같은 칸을 한 번 더 톡 하면 쏴요. 누른 채 끌면 조준을 옮길 수 있어요.',
        '「소나」를 켠 뒤 구역 가운데 칸을 고르면 소나를 써요.',
        '상대 차례에는 내 바다가 크게 보여요. 아래 작은 판을 톡 하면 다른 바다를 크게 볼 수 있어요.',
        'PC: 방향키로 조준, Enter로 발사, S는 소나. 숨기기에서는 방향키로 옮기고 R로 회전, Tab으로 배 고르기.'] },
      { h: '예시', p: [
        'C5를 쐈더니 불꽃(명중)! 배는 일자니까 다음엔 C4 · C6 · B5 · D5 중에서 노려요.',
        'C6도 명중 → 배가 가로로 누워 있어요. C7, C8… 차례로 쏴서 「격침! 돌고래」.',
        '어디를 쏠지 막막하면 소나로 넓은 구역을 먼저 훑어보세요.'] },
      { h: '판 크기 · 여럿이 · AI', p: [
        '8×8 판(설정)은 고래 없이 4척(상어 · 돌고래 · 가오리 · 해마)이라 빨리 끝나요.',
        '2명 전용이에요. 한 폰으로 둘이 할 때는 차례마다 가림막이 떠요. 숨기기도 한 사람씩 차례로 해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 아무 데나 쏘고, 보통은 맞힌 곳 주변을 노리고, 어려움은 확률을 계산해서 노려요.'] },
    ],
    tutorial: [
      { sel: '.sb-board', text: '여기는 내 바다예요. 먼저 잠수함들을 숨겨요. 상대는 내 배가 어디 있는지 볼 수 없어요.' },
      { sel: '.sb-board', text: '배를 끌어서 옮겨요. 고른 배를 한 번 더 톡 하면 가로·세로가 바뀌어요. 배끼리 겹치면 안 돼요.' },
      { sel: '.sb-auto', text: '귀찮으면 「자동 배치」! 한 번에 알아서 숨겨 줘요. 여러 번 눌러도 돼요.' },
      { sel: '.sb-done', text: '다 놓았으면 「숨기기 완료」. 그다음부터 번갈아 상대 바다를 쏴요.' },
      { text: '쏠 때는 상대 바다의 칸을 톡 → 「발사」(또는 한 번 더 톡). 물보라는 빗나감, 불꽃은 명중! 배의 모든 칸을 맞히면 격침이에요.' },
      { text: '한 판에 한 번 「소나」를 쓰면 3×3 구역 안에 배 조각이 몇 칸 있는지 알려 줘요. 상대 함대를 먼저 모두 가라앉히면 승리!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { cellsOf, validFleet, randomFleet, know, density, lensOf, clampCenter, areaOf },
  });
})();
