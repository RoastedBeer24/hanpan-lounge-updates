/* 탱크 미로 대전 — realtime top-down maze tank duel (2–4). Shells bounce off the maze walls; one hit destroys a tank
   (your own bounced shell too). Last tank standing wins the round, first to 3 (or 5) round wins takes the match.
   Mazes: generated each round from a seed (symmetric, fair corner spawns) or one of a few hand-made layouts.
   Host-authoritative fixed-step sim (1/120 s); guests publish stick/key input + fire/special counters, receive ~20 Hz
   snapshots, predict their own tank and re-simulate shells locally between snapshots. One person per phone. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const H = 1 / 120;
  const CS = 40, WT = 5, TR = 7.5, SR = 2.2, PR = 1.7, MR = 3, BM = 16;
  /* tank handling: top speed, reverse, turn rate (rad/s); speed / turn ramp up and down (units/s², rad/s²) so the tank
     feels weighty but stops quickly when you let go */
  const TSPD = 38, TBACK = 27, TURN = 2.9, ACC = 110, DEC = 190, WACC = 20, WDEC = 55, SGAIN = 12;
  const SSPD = 72, SLIFE = 6, SMAX = 5, FIRE_CD = 0.35;
  const PSPD = 118, PLIFE = 1.5, PN = 7, PSPREAD = 0.4;
  const MSPD = 56, MLIFE = 10, MTURN = 2.5, MDELAY = 0.55;
  const LZ_B = 6, LZ_LEN = 1100;
  const MINE_ARM = 1.2, MINE_R = 8, MINE_BOOM = 26, MINE_LIFE = 25;
  const SHIELD_T = 8;
  const COUNT = 3, END_T = 2.6, LAST_T = 0.3, CAP_T = 100, PU_FIRST = 5, PU_EVERY = 7, PU_MAX = 2;
  const PU = {
    L: { nm: '레이저', ch: '레', col: '#ff5470' },
    S: { nm: '산탄', ch: '산', col: '#ffb35c' },
    M: { nm: '유도탄', ch: '유', col: '#c9a0ff' },
    N: { nm: '지뢰', ch: '지', col: '#e3ae45' },
    D: { nm: '방패', ch: '방', col: '#7fe3ff' },
  };
  const PU_KEYS = 'LSMND', SPK = 'LSMN', SKK = 'spm';
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const wrapA = (a) => { a = (a + Math.PI) % (Math.PI * 2); if (a < 0) a += Math.PI * 2; return a - Math.PI; };
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ----- mazes: h[j*C+i] = wall on horizontal grid line j over column i; v[j*(C+1)+i] = wall on vertical line i over row j ----- */
  function emptyMaze(C, R) {
    const M = { C, R, h: new Array((R + 1) * C).fill(0), v: new Array((C + 1) * R).fill(0) };
    for (let i = 0; i < C; i++) { M.h[i] = 1; M.h[R * C + i] = 1; }
    for (let j = 0; j < R; j++) { M.v[j * (C + 1)] = 1; M.v[j * (C + 1) + C] = 1; }
    return M;
  }
  /* an edge's images under the map symmetry (2 = half turn, 4 = both mirrors). Edge id: h index, or (R+1)*C + v index */
  function edgeImgs(C, R, e, sym) {
    const HV = (R + 1) * C, out = [e];
    if (e < HV) {
      const j = Math.floor(e / C), i = e % C;
      out.push((R - j) * C + (C - 1 - i));
      if (sym >= 4) { out.push(j * C + (C - 1 - i)); out.push((R - j) * C + i); }
    } else {
      const q = e - HV, j = Math.floor(q / (C + 1)), i = q % (C + 1);
      out.push(HV + (R - 1 - j) * (C + 1) + (C - i));
      if (sym >= 4) { out.push(HV + j * (C + 1) + (C - i)); out.push(HV + (R - 1 - j) * (C + 1) + i); }
    }
    return out.filter((x, k) => out.indexOf(x) === k);
  }
  /* no straight line of fire between two start corners: add symmetric wall pieces across such lines (keeping every cell
     reachable), preferring pieces near the middle of the line */
  function blockSpawnLOS(W, sym) {
    const { C, R, M } = W, HV = (R + 1) * C;
    const get = (e) => (e < HV ? M.h[e] : M.v[e - HV]);
    const set = (e, v) => { if (e < HV) M.h[e] = v; else M.v[e - HV] = v; };
    const conn = () => { const D = bfs(W, 0, null); for (let k = 0; k < D.length; k++) if (D[k] < 0) return false; return true; };
    const reconnect = (o) => { // open one symmetric wall between the cut-off part and the rest
      const D = bfs(W, 0, null);
      for (let j = 0; j < R; j++) for (let i = 0; i < C; i++) {
        const c = j * C + i; if (D[c] >= 0) continue;
        const es = [];
        if (i < C - 1 && D[c + 1] >= 0) es.push(HV + j * (C + 1) + i + 1);
        if (i > 0 && D[c - 1] >= 0) es.push(HV + j * (C + 1) + i);
        if (j < R - 1 && D[c + C] >= 0) es.push((j + 1) * C + i);
        if (j > 0 && D[c - C] >= 0) es.push(j * C + i);
        for (const e of es) {
          if (o.includes(e)) continue;
          const oo = edgeImgs(C, R, e, sym).filter((x) => get(x) && !o.includes(x));
          oo.forEach((x) => set(x, 0));
          if (conn()) return true;
          oo.forEach((x) => set(x, 1));
        }
      }
      return false;
    };
    const sp = spawnCells(W, W.mk > 0 ? 4 : W.n);
    for (let it = 0; it < 8; it++) {
      buildRects(W);
      let pair = null;
      for (let a = 0; a < sp.length && !pair; a++) for (let b = a + 1; b < sp.length && !pair; b++) {
        const pa = cellXY(W, sp[a]), pb = cellXY(W, sp[b]);
        if (clearLine(W, pa[0], pa[1], pb[0], pb[1], SR)) pair = [pa, pb];
      }
      if (!pair) return;
      // open edges crossed by the line, ordered from its middle outward
      const cand = [];
      let prev = cellIdx(W, pair[0][0], pair[0][1]);
      const L = Math.hypot(pair[1][0] - pair[0][0], pair[1][1] - pair[0][1]);
      for (let d = 2; d < L; d += 2) {
        const u = d / L, c = cellIdx(W, pair[0][0] + (pair[1][0] - pair[0][0]) * u, pair[0][1] + (pair[1][1] - pair[0][1]) * u);
        if (c === prev) continue;
        const ia = prev % C, ja = (prev / C) | 0, ib = c % C, jb = (c / C) | 0;
        if (ja === jb && Math.abs(ia - ib) === 1) cand.push([HV + ja * (C + 1) + Math.max(ia, ib), Math.abs(u - 0.5)]);
        else if (ia === ib && Math.abs(ja - jb) === 1) cand.push([Math.max(ja, jb) * C + ia, Math.abs(u - 0.5)]);
        prev = c;
      }
      cand.sort((x, y) => x[1] - y[1]);
      let done = false;
      for (const cc of cand) {
        const o = edgeImgs(C, R, cc[0], sym).filter((e) => !get(e));
        if (!o.length) continue;
        o.forEach((e) => set(e, 1));
        if (conn() || reconnect(o)) { done = true; break; }
        o.forEach((e) => set(e, 0));
      }
      if (!done) { buildRects(W); return; }
    }
    buildRects(W);
  }
  function spawnCells(W, n) {
    const cs = [0, W.C * W.R - 1, W.C - 1, (W.R - 1) * W.C];
    return cs.slice(0, Math.max(2, Math.min(4, n)));
  }
  /* hand-made layouts (7×9): segments [x0,y0,x1,y1] on grid lines for the top-left quarter, mirrored both ways */
  const FIXED = [
    { nm: '기둥 광장', sub: '탁 트인 광장에 기둥 몇 개', seg: [[3, 0, 3, 1], [1, 1, 2, 1], [1, 1, 1, 2], [3, 2, 4, 2], [2, 3, 2, 4], [3, 4, 4, 4], [0, 4, 1, 4]] },
    { nm: '쌍둥이 복도', sub: '긴 벽이 만든 세 갈래 길', seg: [[3, 0, 3, 1], [2, 1, 2, 4], [0, 2, 1, 2], [1, 3, 2, 3], [3, 3, 3, 4]] },
    { nm: '네 개의 방', sub: '방 네 개와 가운데 복도', seg: [[0, 4, 2, 4], [3, 0, 3, 1], [3, 2, 3, 4], [1, 2, 1, 3]] },
    { nm: '요새', sub: '가운데 요새를 둘러싼 싸움', seg: [[2, 3, 3, 3], [2, 3, 2, 4], [0, 2, 1, 2], [2, 0, 2, 1], [1, 4, 2, 4]] },
  ];
  function buildFixed(k) {
    const F = FIXED[k], C = 7, R = 9, M = emptyMaze(C, R);
    for (const s of F.seg) for (let mx = 0; mx < 2; mx++) for (let my = 0; my < 2; my++) {
      let x0 = s[0], y0 = s[1], x1 = s[2], y1 = s[3];
      if (mx) { x0 = C - x0; x1 = C - x1; }
      if (my) { y0 = R - y0; y1 = R - y1; }
      if (y0 === y1) { for (let i = Math.min(x0, x1); i < Math.max(x0, x1); i++) M.h[y0 * C + i] = 1; }
      else { for (let j = Math.min(y0, y1); j < Math.max(y0, y1); j++) M.v[j * (C + 1) + x0] = 1; }
    }
    return M;
  }
  /* generated maze: Kruskal over symmetry orbits of wall edges (180° turn for 2 players, both mirrors for 3–4), then a few
     extra openings (never a fully open 2×2 block). Same seed → same maze on every device. */
  function genMaze(sd, n) {
    const rnd = prng((sd ^ 0x5bd1e995) >>> 0);
    const SZ = [[6, 8], [7, 9], [8, 10]], z = SZ[Math.floor(rnd() * 3)], C = z[0], R = z[1];
    const M = emptyMaze(C, R), HV = (R + 1) * C;
    const get = (e) => (e < HV ? M.h[e] : M.v[e - HV]);
    const set = (e, v) => { if (e < HV) M.h[e] = v; else M.v[e - HV] = v; };
    const ids = [];
    for (let j = 1; j < R; j++) for (let i = 0; i < C; i++) ids.push(j * C + i);
    for (let j = 0; j < R; j++) for (let i = 1; i < C; i++) ids.push(HV + j * (C + 1) + i);
    for (const e of ids) set(e, 1);
    const imgs = (e) => edgeImgs(C, R, e, n >= 3 ? 4 : 2);
    const seen = new Set(), orbits = [];
    for (const e of ids) { if (seen.has(e)) continue; const o = imgs(e); o.forEach((x) => seen.add(x)); orbits.push(o); }
    for (let k = orbits.length - 1; k > 0; k--) { const r = Math.floor(rnd() * (k + 1)); const t = orbits[k]; orbits[k] = orbits[r]; orbits[r] = t; }
    const par = []; for (let k = 0; k < C * R; k++) par.push(k);
    const find = (x) => { while (par[x] !== x) { par[x] = par[par[x]]; x = par[x]; } return x; };
    const cellsOf = (e) => {
      if (e < HV) { const j = Math.floor(e / C), i = e % C; return [(j - 1) * C + i, j * C + i]; }
      const q = e - HV, j = Math.floor(q / (C + 1)), i = q % (C + 1); return [j * C + i - 1, j * C + i];
    };
    for (const o of orbits) {
      if (!o.some((e) => { const c = cellsOf(e); return find(c[0]) !== find(c[1]); })) continue;
      for (const e of o) { set(e, 0); const c = cellsOf(e); par[find(c[0])] = find(c[1]); }
    }
    const openBlock = (a, b) => { // 2×2 block with top-left cell (a, b) has no inner wall at all
      if (a < 0 || b < 0 || a + 1 >= C || b + 1 >= R) return false;
      return !M.v[b * (C + 1) + a + 1] && !M.v[(b + 1) * (C + 1) + a + 1] && !M.h[(b + 1) * C + a] && !M.h[(b + 1) * C + a + 1];
    };
    const badAt = (e) => {
      if (e < HV) { const j = Math.floor(e / C), i = e % C; return openBlock(i - 1, j - 1) || openBlock(i, j - 1); }
      const q = e - HV, j = Math.floor(q / (C + 1)), i = q % (C + 1); return openBlock(i - 1, j - 1) || openBlock(i - 1, j);
    };
    for (const o of orbits) {
      if (!get(o[0]) || rnd() > 0.34) continue;
      for (const e of o) set(e, 0);
      if (o.some(badAt)) for (const e of o) set(e, 1);
    }
    return M;
  }

  /* ----- world geometry: merged wall boxes + per-cell buckets ----- */
  function buildRects(W) {
    const { C, R, M, ox, oy } = W, out = [], hw = WT / 2;
    for (let j = 0; j <= R; j++) for (let i = 0; i < C;) {
      if (!M.h[j * C + i]) { i++; continue; }
      let i1 = i; while (i1 < C && M.h[j * C + i1]) i1++;
      out.push(ox + i * CS - hw, oy + j * CS - hw, ox + i1 * CS + hw, oy + j * CS + hw); i = i1;
    }
    for (let i = 0; i <= C; i++) for (let j = 0; j < R;) {
      if (!M.v[j * (C + 1) + i]) { j++; continue; }
      let j1 = j; while (j1 < R && M.v[j1 * (C + 1) + i]) j1++;
      out.push(ox + i * CS - hw, oy + j * CS - hw, ox + i * CS + hw, oy + j1 * CS + hw); j = j1;
    }
    W.rects = out; W.nr = out.length / 4; W.bk = [];
    for (let j = 0; j < R; j++) for (let i = 0; i < C; i++) {
      const bx0 = ox + i * CS - BM, by0 = oy + j * CS - BM, bx1 = ox + (i + 1) * CS + BM, by1 = oy + (j + 1) * CS + BM, l = [];
      for (let k = 0; k < W.nr; k++) { const q = k * 4; if (out[q] < bx1 && out[q + 2] > bx0 && out[q + 1] < by1 && out[q + 3] > by0) l.push(k); }
      W.bk.push(l);
    }
  }
  const cellIdx = (W, x, y) => clamp(Math.floor((y - W.oy) / CS), 0, W.R - 1) * W.C + clamp(Math.floor((x - W.ox) / CS), 0, W.C - 1);
  const cellXY = (W, c) => [W.ox + ((c % W.C) + 0.5) * CS, W.oy + (Math.floor(c / W.C) + 0.5) * CS];
  const bucket = (W, x, y) => W.bk[cellIdx(W, x, y)];

  /* swept point (radius r) vs wall boxes. Sets HT (0..1 along d) and HA (1 = x face, 2 = y face, 3 = corner) */
  let HT = 0, HA = 0;
  function cast(W, px, py, dx, dy, r, list) {
    const Rr = W.rects, N = list ? list.length : W.nr;
    let best = 2, ax = 0;
    const mx = dx > 1e-12 || dx < -1e-12, my = dy > 1e-12 || dy < -1e-12;
    for (let q = 0; q < N; q++) {
      const k = (list ? list[q] : q) * 4;
      const x0 = Rr[k] - r, y0 = Rr[k + 1] - r, x1 = Rr[k + 2] + r, y1 = Rr[k + 3] + r;
      let tn = -1e9, tf = 1e9, a = 0;
      if (mx) { let t0 = (x0 - px) / dx, t1 = (x1 - px) / dx; if (t0 > t1) { const t = t0; t0 = t1; t1 = t; } tn = t0; tf = t1; a = 1; }
      else if (px <= x0 || px >= x1) continue;
      if (my) {
        let t0 = (y0 - py) / dy, t1 = (y1 - py) / dy; if (t0 > t1) { const t = t0; t0 = t1; t1 = t; }
        if (t0 > tn + 1e-9) { tn = t0; a = 2; } else if (t0 > tn - 1e-9) a = 3;
        if (t1 < tf) tf = t1;
      } else if (py <= y0 || py >= y1) continue;
      if (tn > tf || tn < 0 || tf <= 1e-9 || tn >= best) continue;
      best = tn; ax = a;
    }
    if (best > 1) return false;
    HT = best; HA = ax; return true;
  }
  const clearLine = (W, x0, y0, x1, y1, r) => !cast(W, x0, y0, x1 - x0, y1 - y0, r, null);
  function insideWall(W, x, y, r) {
    const Rr = W.rects;
    for (const k0 of bucket(W, x, y)) { const k = k0 * 4; if (x > Rr[k] - r && x < Rr[k + 2] + r && y > Rr[k + 1] - r && y < Rr[k + 3] + r) return true; }
    return false;
  }
  /* bouncing ray (laser, aim line, AI): fills out[] with x,y points, returns the point count */
  function traceRay(W, x, y, a, maxB, maxLen, r, out) {
    let dx = Math.cos(a), dy = Math.sin(a), rem = maxLen, n = 0;
    out[n++] = x; out[n++] = y;
    for (let b = 0; b <= maxB && rem > 0.01; b++) {
      if (!cast(W, x, y, dx * rem, dy * rem, r, null)) { x += dx * rem; y += dy * rem; out[n++] = x; out[n++] = y; break; }
      const t = HT, ax = HA;
      x += dx * rem * t; y += dy * rem * t; rem -= rem * t;
      out[n++] = x; out[n++] = y;
      if (ax & 1) { dx = -dx; x += Math.sign(dx) * 1e-3; }
      if (ax & 2) { dy = -dy; y += Math.sign(dy) * 1e-3; }
    }
    return n / 2;
  }
  /* first entry of segment a→b into circle (cx, cy, r): param 0..1, or −1 */
  function segCircle(ax, ay, bx, by, cx, cy, r) {
    const dx = bx - ax, dy = by - ay, fx = ax - cx, fy = ay - cy;
    const A = dx * dx + dy * dy, B = 2 * (fx * dx + fy * dy), Cc = fx * fx + fy * fy - r * r;
    if (Cc <= 0) return 0;
    if (A < 1e-12) return -1;
    const D = B * B - 4 * A * Cc;
    if (D < 0) return -1;
    const t = (-B - Math.sqrt(D)) / (2 * A);
    return t >= 0 && t <= 1 ? t : -1;
  }

  /* ----- maze graph ----- */
  function bfs(W, start, blk) {
    const C = W.C, R = W.R, M = W.M, N = C * R, D = new Int16Array(N).fill(-1), q = new Int16Array(N);
    if (start < 0 || start >= N) return D;
    let hd = 0, tl = 0; D[start] = 0; q[tl++] = start;
    while (hd < tl) {
      const c = q[hd++], i = c % C, j = (c / C) | 0, d = D[c] + 1;
      const go = (nn) => { if (D[nn] < 0 && !(blk && blk[nn])) { D[nn] = d; q[tl++] = nn; } };
      if (i < C - 1 && !M.v[j * (C + 1) + i + 1]) go(c + 1);
      if (i > 0 && !M.v[j * (C + 1) + i]) go(c - 1);
      if (j < R - 1 && !M.h[(j + 1) * C + i]) go(c + C);
      if (j > 0 && !M.h[j * C + i]) go(c - C);
    }
    return D;
  }
  function nextCell(W, D, c) {
    const C = W.C, M = W.M, i = c % C, j = (c / C) | 0;
    if (D[c] <= 0) return -1;
    const ok = (nn) => D[nn] >= 0 && D[nn] < D[c];
    if (i < C - 1 && !M.v[j * (C + 1) + i + 1] && ok(c + 1)) return c + 1;
    if (i > 0 && !M.v[j * (C + 1) + i] && ok(c - 1)) return c - 1;
    if (j < W.R - 1 && !M.h[(j + 1) * C + i] && ok(c + C)) return c + C;
    if (j > 0 && !M.h[j * C + i] && ok(c - C)) return c - C;
    return -1;
  }

  /* ----- world ----- */
  function spawnAngle(W, i, j) {
    const C = W.C, R = W.R, M = W.M, dn = j < R / 2, rt = i < C / 2;
    const vOpen = dn ? (j < R - 1 && !M.h[(j + 1) * C + i]) : (j > 0 && !M.h[j * C + i]);
    const hOpen = rt ? (i < C - 1 && !M.v[j * (C + 1) + i + 1]) : (i > 0 && !M.v[j * (C + 1) + i]);
    if (vOpen) return dn ? Math.PI / 2 : -Math.PI / 2;
    if (hOpen) return rt ? 0 : Math.PI;
    return dn ? Math.PI / 2 : -Math.PI / 2;
  }
  function newWorld(mk, sd, n, rd) {
    const fixed = mk > 0 && mk <= FIXED.length;
    const M = fixed ? buildFixed(mk - 1) : genMaze(sd, n);
    const W = { mk: fixed ? mk : 0, sd, n, C: M.C, R: M.R, M, ox: -M.C * CS / 2, oy: -M.R * CS / 2, t: 0, tanks: [], shells: [], mines: [], pu: [], puT: PU_FIRST, fx: [], fxq: 0, over: false, sq: 0 };
    blockSpawnLOS(W, fixed || n >= 3 ? 4 : 2);
    const corners = [[0, 0], [W.C - 1, W.R - 1], [W.C - 1, 0], [0, W.R - 1]];
    for (let s = 0; s < n; s++) {
      const cc = corners[(s + Math.max(0, (rd | 0) - 1)) % n], p = cellXY(W, cc[1] * W.C + cc[0]);
      W.tanks.push({ seat: s, x: p[0], y: p[1], a: spawnAngle(W, cc[0], cc[1]), v: 0, w: 0, alive: true, cd: 0, sp: '', sh: 0, fq: null, sq: null, by: -1 });
    }
    return W;
  }
  function emit(W, hooks, code, a, b, c, d, e) {
    W.fxq++;
    W.fx.push([W.fxq, code, a, b, c, d, e]);
    if (W.fx.length > 12) W.fx.shift();
    if (hooks && hooks.fx) hooks.fx(code, a, b, c, d, e);
  }
  function pushOut(W, c) {
    const Rr = W.rects;
    for (let it = 0; it < 2; it++) {
      for (const k0 of bucket(W, c.x, c.y)) {
        const k = k0 * 4, x0 = Rr[k], y0 = Rr[k + 1], x1 = Rr[k + 2], y1 = Rr[k + 3];
        const qx = clamp(c.x, x0, x1), qy = clamp(c.y, y0, y1), dx = c.x - qx, dy = c.y - qy, d2 = dx * dx + dy * dy;
        if (d2 >= TR * TR) continue;
        if (d2 > 1e-10) { const d = Math.sqrt(d2), p = TR - d; c.x += dx / d * p; c.y += dy / d * p; }
        else { // centre inside the box: leave by the nearest face
          const l = c.x - x0, r = x1 - c.x, u = c.y - y0, b = y1 - c.y, m = Math.min(l, r, u, b);
          if (m === l) c.x = x0 - TR; else if (m === r) c.x = x1 + TR; else if (m === u) c.y = y0 - TR; else c.y = y1 + TR;
        }
      }
    }
    const hx = W.C * CS / 2 - WT / 2 - TR, hy = W.R * CS / 2 - WT / 2 - TR;
    c.x = clamp(c.x, -hx, hx); c.y = clamp(c.y, -hy, hy);
  }
  const NOIN = {};
  /* inp: {m:'s', x, y} stick (turn toward + drive) or {m:'k', v (−1..1 forward), t (−1..1 turn)}; fc/sc fire counters */
  function stepTank(W, c, inp, h) {
    if (!c.alive) return;
    if (c.cd > 0) c.cd -= h;
    if (c.sh > 0) c.sh -= h;
    const i = inp || NOIN;
    let v = 0, w = 0;
    if (i.m === 'k') {
      w = clamp(+i.t || 0, -1, 1) * TURN;
      const f = clamp(+i.v || 0, -1, 1); v = f >= 0 ? f * TSPD : f * TBACK;
    } else {
      const x = clamp(+i.x || 0, -1, 1), y = clamp(+i.y || 0, -1, 1), m = Math.min(1, Math.hypot(x, y));
      if (m > 0.2) {
        const d = wrapA(Math.atan2(y, x) - c.a);
        w = clamp(d * SGAIN, -TURN, TURN); // eases in on the stick direction, no overshoot
        v = m * TSPD * clamp((Math.cos(d) - 0.3) / 0.7, 0, 1);
      }
    }
    // ramp toward the wanted speed / turn: speeding up is gentle, slowing down (or reversing) is quicker
    const cw = c.w || 0, wu = Math.abs(w) > Math.abs(cw) && w * cw >= 0 ? WACC : WDEC;
    c.w = cw + clamp(w - cw, -wu * h, wu * h);
    if (c.w) c.a = wrapA(c.a + c.w * h);
    const cv0 = c.v || 0, vu = Math.abs(v) > Math.abs(cv0) && v * cv0 >= 0 ? ACC : DEC;
    c.v = cv0 + clamp(v - cv0, -vu * h, vu * h);
    if (c.v) { c.x += Math.cos(c.a) * c.v * h; c.y += Math.sin(c.a) * c.v * h; pushOut(W, c); }
  }
  function tankBump(W) {
    const ts = W.tanks;
    for (let i = 0; i < ts.length; i++) {
      const a = ts[i]; if (!a.alive) continue;
      for (let j = i + 1; j < ts.length; j++) {
        const b = ts[j]; if (!b.alive) continue;
        let dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
        if (d >= TR * 2) continue;
        if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
        const p = (TR * 2 - d) / 2;
        a.x -= dx / d * p; a.y -= dy / d * p; b.x += dx / d * p; b.y += dy / d * p;
        pushOut(W, a); pushOut(W, b);
      }
    }
  }
  const radOf = (s) => (s.k === 'p' ? PR : s.k === 'm' ? MR : SR);
  const spdOf = (k) => (k === 'p' ? PSPD : k === 'm' ? MSPD : SSPD);
  const lifeOf = (k) => (k === 'p' ? PLIFE : k === 'm' ? MLIFE : SLIFE);
  function moveShell(W, s, h, hooks) {
    let rem = h, g = 0;
    const r = radOf(s);
    while (rem > 1e-9 && g++ < 4) {
      const dx = s.vx * rem, dy = s.vy * rem;
      if (!cast(W, s.x, s.y, dx, dy, r, bucket(W, s.x, s.y))) { s.x += dx; s.y += dy; return; }
      const t = HT, ax = HA;
      s.x += dx * t; s.y += dy * t; rem -= rem * t;
      if (ax & 1) { s.vx = -s.vx; s.x += Math.sign(s.vx) * 1e-4; }
      if (ax & 2) { s.vy = -s.vy; s.y += Math.sign(s.vy) * 1e-4; }
      s.bt = s.t;
      if (hooks && hooks.bounce) hooks.bounce(s);
    }
  }
  function shellsOf(W, seat) { let n = 0; for (const s of W.shells) if (s.o === seat && s.k === 's') n++; return n; }
  function spawnShell(W, c, ang, k) {
    const sp = spdOf(k);
    const s = { id: ++W.sq, x: c.x, y: c.y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, o: c.seat, k, t: 0, arm: 0, bt: 0 };
    moveShell(W, s, (TR + 3) / sp, null); // from the hull centre out of the muzzle (bounces back if the muzzle is in a wall)
    s.bt = 0;
    W.shells.push(s);
    return s;
  }
  function fire(W, c, hooks) {
    if (!c.alive || c.cd > 0) return 0;
    if (shellsOf(W, c.seat) >= SMAX) { if (hooks && hooks.empty) hooks.empty(c); return -1; }
    spawnShell(W, c, c.a, 's');
    c.cd = FIRE_CD;
    emit(W, hooks, 'f', c.seat, 0, r1(c.x), r1(c.y), r2(c.a));
    return 1;
  }
  function hurt(W, c, by, hooks) {
    if (!c.alive) return false;
    if (c.sh > 0) { c.sh = 0; emit(W, hooks, 's', c.seat, r1(c.x), r1(c.y)); return false; }
    c.alive = false; c.by = by; c.v = 0; c.w = 0;
    emit(W, hooks, 'x', c.seat, by, r1(c.x), r1(c.y), r2(c.a));
    return true;
  }
  const TB = new Float64Array(64);
  function laserPath(W, x, y, a, out) { return traceRay(W, x, y, a, LZ_B, LZ_LEN, 0.6, out); }
  function laser(W, c, hooks) {
    const n = laserPath(W, c.x, c.y, c.a, TB);
    let cum = 0, hitL = -1, hitT = null;
    for (let k = 0; k < n - 1; k++) {
      const ax = TB[2 * k], ay = TB[2 * k + 1], bx = TB[2 * k + 2], by = TB[2 * k + 3], sl = Math.hypot(bx - ax, by - ay);
      for (const q of W.tanks) {
        if (!q.alive || (q === c && k === 0)) continue;
        const u = segCircle(ax, ay, bx, by, q.x, q.y, TR);
        if (u >= 0 && (hitL < 0 || cum + u * sl < hitL)) { hitL = cum + u * sl; hitT = q; }
      }
      if (hitL >= 0) break;
      cum += sl;
    }
    emit(W, hooks, 'l', c.seat, r1(c.x), r1(c.y), r2(c.a), Math.round(hitL >= 0 ? hitL : cum + 1));
    if (hitT) hurt(W, hitT, c.seat, hooks);
  }
  function special(W, c, hooks) {
    if (!c.alive || !c.sp || c.cd > 0) return 0;
    const k = c.sp;
    c.sp = ''; c.cd = FIRE_CD;
    if (k === 'L') laser(W, c, hooks);
    else if (k === 'S') { for (let i = 0; i < PN; i++) spawnShell(W, c, c.a + (i / (PN - 1) - 0.5) * 2 * PSPREAD, 'p'); emit(W, hooks, 'f', c.seat, 1, r1(c.x), r1(c.y), r2(c.a)); }
    else if (k === 'M') { spawnShell(W, c, c.a, 'm'); emit(W, hooks, 'f', c.seat, 2, r1(c.x), r1(c.y), r2(c.a)); }
    else if (k === 'N') {
      let x = c.x - Math.cos(c.a) * (TR + 3), y = c.y - Math.sin(c.a) * (TR + 3);
      if (insideWall(W, x, y, 4)) { x = c.x; y = c.y; }
      W.mines.push({ x: r1(x), y: r1(y), o: c.seat, t: 0, lf: 0 });
      emit(W, hooks, 'f', c.seat, 3, r1(x), r1(y), r2(c.a));
    }
    return 1;
  }
  /* homing missile: after a short straight run it follows the maze toward the nearest enemy */
  function steerMissile(W, s, h) {
    s.rt = (s.rt || 0) - h;
    if (s.rt <= 0) {
      s.rt = 0.15;
      const ci = cellIdx(W, s.x, s.y), D = bfs(W, ci, null);
      let best = null, bd = 1e9;
      for (const c of W.tanks) {
        if (!c.alive || c.seat === s.o) continue;
        const d = D[cellIdx(W, c.x, c.y)], dd = (d < 0 ? 99 : d) * CS + Math.hypot(c.x - s.x, c.y - s.y) * 0.01;
        if (dd < bd) { bd = dd; best = c; }
      }
      s.gx = null;
      if (best) {
        const tc = cellIdx(W, best.x, best.y);
        if (tc === ci || clearLine(W, s.x, s.y, best.x, best.y, MR + 1)) { s.gx = best.x; s.gy = best.y; }
        else {
          const Dt = bfs(W, tc, null), nx = nextCell(W, Dt, ci);
          if (nx < 0) { s.gx = best.x; s.gy = best.y; }
          else {
            const n2 = nextCell(W, Dt, nx), p2 = n2 >= 0 ? cellXY(W, n2) : null;
            const p = p2 && clearLine(W, s.x, s.y, p2[0], p2[1], MR + 1) ? p2 : cellXY(W, nx);
            s.gx = p[0]; s.gy = p[1];
          }
        }
      }
    }
    if (s.gx == null) return;
    const want = Math.atan2(s.gy - s.y, s.gx - s.x), cur = Math.atan2(s.vy, s.vx), d = wrapA(want - cur), na = cur + clamp(d, -MTURN * h, MTURN * h);
    s.vx = Math.cos(na) * MSPD; s.vy = Math.sin(na) * MSPD;
  }
  function boom(W, m, hooks) {
    const i = W.mines.indexOf(m); if (i < 0) return;
    W.mines.splice(i, 1);
    emit(W, hooks, 'b', r1(m.x), r1(m.y), m.o);
    for (const c of W.tanks) if (c.alive && Math.hypot(c.x - m.x, c.y - m.y) < MINE_BOOM + TR * 0.4 && clearLine(W, m.x, m.y, c.x, c.y, 0)) hurt(W, c, m.o, hooks);
    for (const q of W.mines.slice()) if (Math.hypot(q.x - m.x, q.y - m.y) < MINE_BOOM) boom(W, q, hooks);
  }
  function stepShells(W, h, hooks, host) {
    const sh = W.shells;
    for (let k = sh.length - 1; k >= 0; k--) {
      const s = sh[k];
      if (!s) continue;
      s.t += h;
      if (s.t >= lifeOf(s.k) || Math.abs(s.x) > W.C * CS || Math.abs(s.y) > W.R * CS) { sh.splice(k, 1); if (hooks && hooks.fizzle) hooks.fizzle(s); continue; }
      if (s.k === 'm' && s.t > MDELAY) steerMissile(W, s, h);
      moveShell(W, s, h, hooks);
      const r = radOf(s);
      const o = W.tanks[s.o];
      if (!s.arm && (!o || !o.alive || Math.hypot(o.x - s.x, o.y - s.y) > TR + r + 0.5)) s.arm = 1;
      if (W.over) continue;
      let gone = false;
      for (const c of W.tanks) {
        if (!c.alive || (c.seat === s.o && !s.arm)) continue;
        const dx = c.x - s.x, dy = c.y - s.y;
        if (dx * dx + dy * dy >= (TR + r) * (TR + r)) continue;
        gone = true;
        if (host) hurt(W, c, s.o, hooks);
        break;
      }
      if (!gone && host) for (const m of W.mines) {
        if (Math.hypot(m.x - s.x, m.y - s.y) < r + 4) { gone = true; boom(W, m, hooks); break; }
      }
      if (gone) { const i = sh.indexOf(s); if (i >= 0) sh.splice(i, 1); }
    }
  }
  function stepMines(W, h, hooks, host) {
    for (let k = W.mines.length - 1; k >= 0; k--) {
      const m = W.mines[k];
      if (!m) continue;
      m.t += h;
      const o = W.tanks[m.o];
      if (!m.lf && (!o || !o.alive || Math.hypot(o.x - m.x, o.y - m.y) > MINE_R + TR + 3)) m.lf = 1;
      if (m.t > MINE_LIFE) { W.mines.splice(k, 1); continue; }
      if (!host || W.over || m.t < MINE_ARM) continue;
      for (const c of W.tanks) {
        if (!c.alive || (c.seat === m.o && !m.lf)) continue;
        if (Math.hypot(c.x - m.x, c.y - m.y) < MINE_R + TR * 0.5) { boom(W, m, hooks); break; }
      }
    }
  }
  function pickups(W, hooks) {
    for (let k = W.pu.length - 1; k >= 0; k--) {
      const p = W.pu[k];
      for (const c of W.tanks) {
        if (!c.alive || Math.hypot(c.x - p.x, c.y - p.y) > TR + 6) continue;
        if (p.k === 'D') c.sh = SHIELD_T;
        else if (!c.sp) c.sp = p.k;
        else continue;
        W.pu.splice(k, 1);
        emit(W, hooks, 'p', c.seat, PU_KEYS.indexOf(p.k), r1(p.x), r1(p.y));
        break;
      }
    }
  }
  /* host only (Math.random): a crate now and then */
  function maybePowerup(W, dt, hooks) {
    W.puT -= dt;
    if (W.puT > 0) return;
    W.puT = PU_EVERY;
    if (W.pu.length >= PU_MAX) return;
    for (let tries = 0; tries < 24; tries++) {
      const p = cellXY(W, Math.floor(Math.random() * W.C * W.R));
      if (W.tanks.some((c) => c.alive && Math.hypot(c.x - p[0], c.y - p[1]) < CS * 1.6)) continue;
      if (W.pu.some((q) => Math.hypot(q.x - p[0], q.y - p[1]) < 5) || W.mines.some((q) => Math.hypot(q.x - p[0], q.y - p[1]) < CS * 0.6)) continue;
      const k = PU_KEYS[Math.floor(Math.random() * PU_KEYS.length)];
      W.pu.push({ x: r1(p[0]), y: r1(p[1]), k });
      emit(W, hooks, 'u', r1(p[0]), r1(p[1]), PU_KEYS.indexOf(k));
      return;
    }
  }
  /* one fixed step. host = this device decides hits / pick-ups (guests only move shells) */
  function stepWorld(W, inputs, hooks, host) {
    W.t += H;
    for (const c of W.tanks) {
      const i = W.over ? null : inputs && inputs[c.seat];
      stepTank(W, c, i, H);
      if (!host || !i || !c.alive || W.over) continue;
      const fc = i.fc | 0, sc = i.sc | 0;
      if (c.fq == null) c.fq = fc;
      else if (fc !== c.fq && c.cd <= 0) { c.fq = fc; fire(W, c, hooks); } // a press during the cooldown waits for it
      if (c.sq == null) c.sq = sc;
      else if (sc !== c.sq && c.cd <= 0) { c.sq = sc; special(W, c, hooks); }
    }
    tankBump(W);
    stepShells(W, H, hooks, host);
    stepMines(W, H, hooks, host);
    if (host && !W.over) pickups(W, hooks);
  }

  /* ======================= AI ======================= */
  const AIC = {
    /* rate = think interval (s), dodge = chance to check incoming shells per think, margin = gap (units) that triggers a
       dodge, gap = min time between shots, B = wall bounces it plans, horizon = planned shot flight time (s) */
    1: { rate: 0.3, noise: 0.13, B: 0, dodge: 0.15, margin: 4, gap: 1.4, lead: 0, safe: 1, strict: 0, tol: 0.1, N: 0, seek: 0.35, wild: 0.12, mineAvoid: 0, horizon: 2.4 },
    2: { rate: 0.14, noise: 0.1, B: 1, dodge: 0.95, margin: 5, gap: 1.0, lead: 0.5, safe: 1, strict: 0, tol: 0.05, N: 48, seek: 1, wild: 0, mineAvoid: 1, horizon: 2.6 },
    3: { rate: 0.08, noise: 0.01, B: 3, dodge: 1, margin: 5, gap: 0.4, lead: 1, safe: 1, strict: 1, tol: 0.035, N: 72, seek: 1, wild: 0, mineAvoid: 1, horizon: 3.4 },
  };
  const AT = new Float64Array(64);
  /* length along the shot until it hits an enemy, or Infinity (miss / hits me first) */
  function shotEval(W, c, ang, C, en, maxB, maxLen, spd, laserMode) {
    const n = traceRay(W, c.x, c.y, ang, maxB, maxLen, laserMode ? 0.6 : SR, AT);
    let cum = 0, best = Infinity, self = Infinity;
    const hitR = laserMode ? TR - 0.5 : TR + SR - 1.5;
    for (let k = 0; k < n - 1; k++) {
      const ax = AT[2 * k], ay = AT[2 * k + 1], bx = AT[2 * k + 2], by = AT[2 * k + 3], sl = Math.hypot(bx - ax, by - ay);
      if (sl < 1e-6) continue;
      const ux = (bx - ax) / sl, uy = (by - ay) / sl;
      if (best === Infinity) for (const e of en) {
        let ex = e.x, ey = e.y, pr = clamp((ex - ax) * ux + (ey - ay) * uy, 0, sl);
        if (C.lead && !laserMode && e.v) { const tt = (cum + pr) / spd; ex += Math.cos(e.a) * e.v * tt * C.lead; ey += Math.sin(e.a) * e.v * tt * C.lead; pr = clamp((ex - ax) * ux + (ey - ay) * uy, 0, sl); }
        const d = Math.hypot(ex - (ax + ux * pr), ey - (ay + uy * pr));
        if (d < hitR) { const L = cum + pr - Math.sqrt(Math.max(0, hitR * hitR - d * d)); if (L < best) best = L; }
      }
      if ((C.safe || laserMode) && k > 0) {
        const pr = clamp((c.x - ax) * ux + (c.y - ay) * uy, 0, sl), d = Math.hypot(c.x - (ax + ux * pr), c.y - (ay + uy * pr));
        if (d < TR + SR + 3 && cum + pr < self) self = cum + pr;
      }
      if (best < Infinity && !C.strict) break;
      cum += sl;
    }
    if (best === Infinity || self < best) return Infinity;
    if (C.strict && !laserMode && self < Infinity && best / spd > 0.5) return Infinity; // a miss would come back at me
    return best;
  }
  function canFire(W, c) { return c.alive && c.cd <= 0 && shellsOf(W, c.seat) < SMAX; }
  function findShot(W, c, C, en, mem, laserMode) {
    const maxB = laserMode ? LZ_B : C.B, maxLen = laserMode ? LZ_LEN : SSPD * C.horizon, spd = laserMode ? 1e6 : SSPD;
    let bestA = null, bestS = Infinity;
    const tryA = (ang) => {
      const L = shotEval(W, c, ang, C, en, maxB, maxLen, spd, laserMode);
      if (L === Infinity) return;
      const s = L / (laserMode ? 1e4 : spd) + Math.abs(wrapA(ang - c.a)) / TURN * 1.2;
      if (s < bestS) { bestS = s; bestA = ang; }
    };
    tryA(c.a);
    for (const e of en) tryA(Math.atan2(e.y - c.y, e.x - c.x));
    const N = laserMode ? Math.max(C.N, 24) : C.N, jit = Math.random() * Math.PI * 2 / Math.max(1, N);
    for (let k = 0; k < N; k++) tryA(k / N * Math.PI * 2 + jit);
    return bestA;
  }
  /* nearby shells sampled every 1/30 s over the next ~1 s (bounces included) */
  function threats(W, c) {
    const out = [];
    for (const s of W.shells) {
      if (s.o === c.seat && !s.arm) continue;
      const sp = Math.hypot(s.vx, s.vy), d0 = Math.hypot(s.x - c.x, s.y - c.y);
      if (d0 > sp * 1.05 + 30) continue;
      const n = traceRay(W, s.x, s.y, Math.atan2(s.vy, s.vx), 3, Math.min(sp * 1.0, sp * Math.max(0, lifeOf(s.k) - s.t)), radOf(s), AT);
      const smp = [radOf(s)], step = sp / 30;
      let k = 0, used = 0;
      for (let q = 0; q <= 30 && n > 1; q++) {
        const want = step * q;
        let sl = Math.hypot(AT[2 * k + 2] - AT[2 * k], AT[2 * k + 3] - AT[2 * k + 1]);
        while (want - used > sl && k < n - 2) { used += sl; k++; sl = Math.hypot(AT[2 * k + 2] - AT[2 * k], AT[2 * k + 3] - AT[2 * k + 1]); }
        if (want - used > sl + 0.01) break; // the shell's path (or life) ends here
        const u = sl > 0 ? clamp((want - used) / sl, 0, 1) : 0;
        smp.push(AT[2 * k] + (AT[2 * k + 2] - AT[2 * k]) * u, AT[2 * k + 1] + (AT[2 * k + 3] - AT[2 * k + 1]) * u);
      }
      if (smp.length > 2) out.push(smp);
    }
    return out;
  }
  const GHOST = { seat: -1, x: 0, y: 0, a: 0, v: 0, w: 0, alive: true, cd: 0, sh: 0 };
  const CANDS = [[1, 0], [1, -1], [1, 1], [-1, 0], [-1, -1], [-1, 1], [0, -1], [0, 1], [0, 0], [0.5, -1], [0.5, 1]];
  const GIN = { m: 'k', v: 0, t: 0 };
  /* smallest gap between my hull and any of the shells if I hold (v, t) for the next 1 s */
  function clearance(W, c, v, t, th) {
    GHOST.x = c.x; GHOST.y = c.y; GHOST.a = c.a; GHOST.v = c.v || 0; GHOST.w = c.w || 0; GHOST.alive = true; GIN.v = v; GIN.t = t;
    let clear = 1e9;
    for (let k = 0; k <= 30; k++) {
      if (k) stepTank(W, GHOST, GIN, 1 / 30);
      for (const smp of th) { if (2 * k + 2 >= smp.length) continue; const d = Math.hypot(GHOST.x - smp[2 * k + 1], GHOST.y - smp[2 * k + 2]) - smp[0] - TR; if (d < clear) clear = d; }
    }
    return clear;
  }
  function dodgeMove(W, c, th) {
    let best = null, bs = -1e9;
    for (const cd of CANDS) {
      const s = Math.min(clearance(W, c, cd[0], cd[1], th), 30) + (cd[0] ? 0.4 : 0);
      if (s > bs) { bs = s; best = cd; }
    }
    return [best, bs];
  }
  function aiThink(W, c, mem, lv, dt) {
    const inp = mem.inp || (mem.inp = { m: 'k', v: 0, t: 0, x: 0, y: 0, fc: 0, sc: 0 });
    if (!c.alive || W.over) { inp.v = 0; inp.t = 0; return inp; }
    const C = AIC[lv] || AIC[2];
    mem.t = (mem.t || 0) - dt;
    if (mem.t <= 0) { mem.t = C.rate * (0.8 + Math.random() * 0.4); think(W, c, mem, C, lv); }
    if (mem.dodgeT > W.t) { inp.v = mem.dv; inp.t = mem.dtn; return inp; }
    if (mem.backT > W.t) { inp.v = -1; inp.t = mem.bt; return inp; }
    if (mem.aim != null) {
      const d = wrapA(mem.aim + (mem.noff || 0) - c.a);
      inp.t = clamp(d * 3.2, -1, 1); inp.v = 0;
      const k = mem.aimK || 'f';
      if (Math.abs(d) < C.tol && c.cd <= 0) {
        if (k === 'f') { if (canFire(W, c) && W.t - (mem.lf == null ? -9 : mem.lf) > C.gap) { inp.fc = (inp.fc + 1) % 1000; mem.lf = W.t; mem.aim = null; } }
        else if (c.sp) { inp.sc = (inp.sc + 1) % 1000; mem.aim = null; mem.lf = W.t; }
        else mem.aim = null;
      }
      return inp;
    }
    if (mem.gx != null) {
      const d = wrapA(Math.atan2(mem.gy - c.y, mem.gx - c.x) - c.a);
      inp.t = clamp(d * 3.2, -1, 1); inp.v = Math.abs(d) < 0.4 ? 1 : Math.abs(d) < 1.0 ? 0.3 : 0;
    } else { inp.v = 0; inp.t = 0; }
    return inp;
  }
  function think(W, c, mem, C, lv) {
    const en = W.tanks.filter((o) => o.alive && o !== c);
    const inp = mem.inp;
    if (!en.length) { mem.aim = null; mem.gx = null; return; }
    // 1) incoming shells
    if (C.dodge && Math.random() < C.dodge) {
      const th = threats(W, c);
      if (th.length) {
        const cur = mem.aim != null ? clearance(W, c, 0, clamp(wrapA(mem.aim - c.a) * 3.2, -1, 1), th) : clearance(W, c, inp.v, inp.t, th);
        if (cur < C.margin) {
          const m = dodgeMove(W, c, th);
          if (m[1] > cur + 0.5) { mem.dv = m[0][0]; mem.dtn = m[0][1]; mem.dodgeT = W.t + 0.2; mem.aim = null; return; }
        }
      }
    }
    // 2) stuck against something while driving
    if (mem.gx != null && mem.aim == null) {
      if (!mem.p0) mem.p0 = [c.x, c.y, W.t];
      else if (W.t - mem.p0[2] > 0.9) {
        if (Math.hypot(c.x - mem.p0[0], c.y - mem.p0[1]) < 2) { mem.backT = W.t + 0.35; mem.bt = Math.random() < 0.5 ? -1 : 1; }
        mem.p0 = [c.x, c.y, W.t];
      }
    } else mem.p0 = null;
    // 3) keep a still-valid plan (stops flip-flopping between angles)
    if (mem.aim != null && W.t < (mem.aimUntil || 0)) {
      const k = mem.aimK || 'f';
      const ok = k === 'f' ? shotEval(W, c, mem.aim, C, en, C.B, SSPD * C.horizon, SSPD, false) < Infinity
        : k === 'L' ? shotEval(W, c, mem.aim, C, en, LZ_B, LZ_LEN, 1e6, true) < Infinity : true;
      if (ok) return;
    }
    mem.aim = null;
    const setAim = (a, k, noise) => { mem.aim = a; mem.aimK = k; mem.noff = noise ? (Math.random() + Math.random() + Math.random() - 1.5) * C.noise * 1.4 : 0; mem.aimUntil = W.t + 1.2; };
    // 4) special weapons
    if (c.sp && c.cd <= 0) {
      const sp = c.sp;
      if (sp === 'N') {
        const D = bfs(W, cellIdx(W, c.x, c.y), null);
        const far = en.every((e) => { const d = D[cellIdx(W, e.x, e.y)]; return d < 0 || d >= 2; });
        if (lv === 1 || (far && Math.abs(c.v) > 10)) { inp.sc = (inp.sc + 1) % 1000; return; }
      } else if (sp === 'L') {
        const a = lv === 1 ? (shotEval(W, c, c.a, C, en, LZ_B, LZ_LEN, 1e6, true) < Infinity ? c.a : null) : findShot(W, c, C, en, mem, true);
        if (a != null) { setAim(a, 'L', false); return; }
        if (lv === 1 && Math.random() < 0.05) { inp.sc = (inp.sc + 1) % 1000; return; }
      } else if (sp === 'S') {
        for (const e of en) {
          const d = Math.hypot(e.x - c.x, e.y - c.y);
          if (d < 105 && clearLine(W, c.x, c.y, e.x, e.y, 1)) { setAim(Math.atan2(e.y - c.y, e.x - c.x), 'S', true); return; }
        }
      } else if (sp === 'M') {
        const close = en.some((e) => Math.hypot(e.x - c.x, e.y - c.y) < 55);
        if (!close && clearLine(W, c.x, c.y, c.x + Math.cos(c.a) * 30, c.y + Math.sin(c.a) * 30, MR)) { inp.sc = (inp.sc + 1) % 1000; return; }
      }
    }
    // 5) normal shells
    if (canFire(W, c) && W.t - (mem.lf == null ? -9 : mem.lf) > C.gap) {
      let a = null;
      if (C.N) a = findShot(W, c, C, en, mem, false);
      else { // 쉬움: only straight shots at someone in plain sight
        for (const e of en) if (clearLine(W, c.x, c.y, e.x, e.y, SR)) { a = Math.atan2(e.y - c.y, e.x - c.x); break; }
        if (a == null && Math.random() < C.wild && W.t - (mem.lf == null ? -9 : mem.lf) > 2.5 && clearLine(W, c.x, c.y, c.x + Math.cos(c.a) * 70, c.y + Math.sin(c.a) * 70, SR)) a = c.a;
      }
      if (a != null) {
        if (lv >= 3 && Math.abs(wrapA(a - c.a)) < C.tol) { inp.fc = (inp.fc + 1) % 1000; mem.lf = W.t; return; }
        setAim(a, 'f', true); return;
      }
    }
    // 6) where to drive
    let blk = null;
    if (C.mineAvoid && W.mines.length) { blk = new Uint8Array(W.C * W.R); for (const m of W.mines) blk[cellIdx(W, m.x, m.y)] = 1; }
    const myC = cellIdx(W, c.x, c.y);
    if (blk) blk[myC] = 0;
    const D = bfs(W, myC, blk);
    let tgt = null, td = 1e9;
    for (const e of en) { const d = D[cellIdx(W, e.x, e.y)], dd = d < 0 ? 500 + Math.hypot(e.x - c.x, e.y - c.y) / CS : d; if (dd < td) { td = dd; tgt = e; } }
    let goal = cellIdx(W, tgt.x, tgt.y), gp = [tgt.x, tgt.y];
    if (lv === 1) {
      if (mem.wc == null || W.t > (mem.wT || 0) || mem.wc === myC) {
        mem.wc = Math.random() < 0.45 ? goal : Math.floor(Math.random() * W.C * W.R); mem.wT = W.t + 4;
      }
      goal = mem.wc; gp = cellXY(W, goal);
    }
    if (Math.random() < C.seek && W.pu.length) {
      let bp = null, bd = 1e9;
      for (const p of W.pu) {
        if (p.k !== 'D' && c.sp) continue;
        const d = D[cellIdx(W, p.x, p.y)];
        if (d >= 0 && d < bd) { bd = d; bp = p; }
      }
      if (bp && bd <= td + 1) { goal = cellIdx(W, bp.x, bp.y); gp = [bp.x, bp.y]; }
    }
    if (blk) blk[goal] = 0;
    if (goal === myC) { mem.gx = gp[0]; mem.gy = gp[1]; return; }
    const Dg = bfs(W, goal, blk), nx = nextCell(W, Dg, myC);
    if (nx < 0) { mem.gx = gp[0]; mem.gy = gp[1]; return; }
    const n2 = nextCell(W, Dg, nx), p2 = n2 >= 0 ? cellXY(W, n2) : n2 === -1 && nx === goal ? gp : null;
    const p = p2 && clearLine(W, c.x, c.y, p2[0], p2[1], TR) ? p2 : cellXY(W, nx);
    mem.gx = p[0]; mem.gy = p[1];
  }

  /* ======================= pure game interface ======================= */
  function pickMap(mp, prev) {
    if (mp >= 0) return Math.min(mp, FIXED.length);
    if (Math.random() < 0.5) return 0;
    let k = 1 + Math.floor(Math.random() * FIXED.length);
    if (k === prev) k = 1 + (k % FIXED.length);
    return k;
  }
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    const mp = typeof o.map === 'number' && o.map >= -1 && o.map <= FIXED.length ? o.map : -1;
    return {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      need: o.rounds === 5 ? 5 : 3, mp, it: o.items === 0 ? 0 : 1,
      ph: 'count', rd: 1, sd: 1 + U.rand(2147483646), mk: pickMap(mp, -1), wins: Array(n).fill(0), rw: -1, res: null,
    };
  }
  function roundOver(s, winner) {
    const n = Object.assign({}, s, { wins: (s.wins || []).slice(), ph: 'end', rw: winner });
    if (winner >= 0) n.wins[winner] = (n.wins[winner] | 0) + 1;
    return n;
  }
  function nextRound(s) {
    const mx = Math.max(...s.wins);
    if (mx >= s.need || s.rd >= s.need * s.n + 4) {
      const order = s.wins.map((v, i) => [i, v]).sort((a, b) => b[1] - a[1] || a[0] - b[0]);
      return Object.assign({}, s, { ph: 'done', res: order });
    }
    return Object.assign({}, s, { rd: s.rd + 1, sd: 1 + U.rand(2147483646), mk: pickMap(s.mp, s.mk), ph: 'count', rw: -1 });
  }
  function mapName(mk) { return mk > 0 && FIXED[mk - 1] ? FIXED[mk - 1].nm : '새 미로'; }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '승');
    const mode = s.mp < 0 ? '무작위 맵' : mapName(s.mp);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: mode + ' · ' + s.need + '승 먼저\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `.tk-chip{position:absolute;right:8px;top:4px;z-index:6;appearance:none;border:1px solid rgba(242,233,216,.2);background:rgba(23,19,31,.86);color:var(--ink,#f2e9d8);border-radius:12px;min-height:44px;min-width:44px;padding:4px 11px;font:700 12px/1.2 "IBM Plex Sans KR",system-ui,sans-serif;cursor:pointer;touch-action:manipulation;user-select:none;-webkit-user-select:none}
.tk-chip b{color:var(--brass,#e3ae45)}
.tk-chip:active{transform:scale(.96)}`;
  const STICK_R = 46, TOPH = 52, FR = 9;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let st = null, key = null, W = null, phase = 'wait', cd = 0, endT = 0, lastT = 0, acc = 0, lay = null, hintT = 0, shake = 0, lastSfx = 0, chipW = 0;
    const cfg = { aim: 1 };
    try { const c = JSON.parse(localStorage.getItem('lounge.tanks.cfg') || 'null'); if (c && (c.aim === 0 || c.aim === 1)) cfg.aim = c.aim; } catch (e) {}
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const autoSeat = (s) => { const p = api.players[s]; if (!p) return false; if (p.ai) return true; return !api.online && p.local && !isMine(s); };
    let aiMem = [], inputs = {}, parts = [], floats = [], rings = [], beams = [], vis = [];
    const locIn = {};
    let pubT = 0, hsQ = 0, inQ = 0, lastSig = '', inT = 0, snaps = [], lastQ = -1, lastFx = 0, rtt = 0.15;
    const sendT = {}, iqOf = {}, remIn = {};
    let groundCv = null, wallCv = null, gctx = null;
    const TBV = new Float64Array(64);

    function curKey() { return st ? st.rid + '.' + st.rd : null; }
    function startRound() {
      W = newWorld(st.mk, st.sd, st.n, st.rd);
      aiMem = W.tanks.map(() => ({}));
      inputs = {}; parts = []; floats = []; rings = []; beams = []; snaps = []; lastQ = -1; lastFx = 0; acc = 0; lastT = 0;
      vis = W.tanks.map((c) => ({ px: c.x, py: c.y, pa: c.a, tl: 0, tr: 0, sx: c.x, sy: c.y, fl: 0, rc: 0, dead: false }));
      for (const s of mine()) { const o = locIn[s]; locIn[s] = { m: 's', x: 0, y: 0, v: 0, t: 0, fc: o ? o.fc : 0, sc: o ? o.sc : 0 }; }
      phase = st.ph === 'play' ? 'play' : 'count';
      cd = COUNT; endT = END_T;
      if (st.rd === 1 && mine().length) hintT = 6;
      W.over = st.ph === 'end' || st.ph === 'done';
      layout();
    }

    /* ----- layout: the whole maze on screen, a control band at the bottom ----- */
    function layout() {
      const w = cv.w, h = cv.h, bot = mine().length ? 132 : 14;
      const ww = (W ? W.C : 7) * CS + FR * 2, wh = (W ? W.R : 9) * CS + FR * 2;
      const s = Math.max(0.4, Math.min((w - 10) / ww, (h - TOPH - bot - 6) / wh));
      lay = { s, cx: w / 2, cy: TOPH + 3 + (h - TOPH - bot - 6) / 2, ww, wh, bot };
      syncChip();
      buildStatic();
    }
    cv.onresize = layout;
    const X = (x) => lay.cx + x * lay.s, Y = (y) => lay.cy + y * lay.s;

    /* ----- static layers: felt floor (+ tread marks) and the wooden walls ----- */
    function hash(a, b) { let h = (Math.imul(a | 0, 0x9E3779B1) ^ Math.imul((b | 0) + 0x632BE5AB, 0x85EBCA77)) >>> 0; h ^= h >>> 16; h = Math.imul(h, 0x7feb352d) >>> 0; h ^= h >>> 15; return h >>> 0; }
    function buildStatic() {
      if (!W || !lay) return;
      const k = lay.s * cv.dpr, pw = Math.max(1, Math.ceil(lay.ww * k)), ph = Math.max(1, Math.ceil(lay.wh * k));
      groundCv = document.createElement('canvas'); groundCv.width = pw; groundCv.height = ph;
      wallCv = document.createElement('canvas'); wallCv.width = pw; wallCv.height = ph;
      gctx = groundCv.getContext('2d');
      const tf = (g) => g.setTransform(k, 0, 0, k, lay.ww / 2 * k, lay.wh / 2 * k);
      tf(gctx);
      const g = gctx, hw = W.C * CS / 2, hh = W.R * CS / 2;
      // table rail
      rrect(g, -hw - FR, -hh - FR, (hw + FR) * 2, (hh + FR) * 2, 7);
      const rg = g.createLinearGradient(0, -hh - FR, 0, hh + FR); rg.addColorStop(0, '#6e4a2c'); rg.addColorStop(1, '#4a2f1b'); g.fillStyle = rg; g.fill();
      g.lineWidth = 1; g.strokeStyle = 'rgba(227,174,69,.55)'; rrect(g, -hw - FR + 1.5, -hh - FR + 1.5, (hw + FR) * 2 - 3, (hh + FR) * 2 - 3, 6); g.stroke();
      // felt
      const fg = g.createRadialGradient(0, 0, 10, 0, 0, Math.hypot(hw, hh)); fg.addColorStop(0, '#2c5a4b'); fg.addColorStop(1, '#1c4236');
      g.fillStyle = fg; g.fillRect(-hw - 1, -hh - 1, hw * 2 + 2, hh * 2 + 2);
      for (let i = 0; i < W.C * W.R * 14; i++) { const a = hash(i, 7), b = hash(i, 13); g.fillStyle = (a & 1) ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.07)'; g.fillRect(-hw + (a % 1000) / 1000 * hw * 2, -hh + (b % 1000) / 1000 * hh * 2, 0.8, 0.8); }
      g.strokeStyle = 'rgba(242,233,216,.045)'; g.lineWidth = 0.5; g.beginPath();
      for (let i = 1; i < W.C; i++) { g.moveTo(-hw + i * CS, -hh); g.lineTo(-hw + i * CS, hh); }
      for (let j = 1; j < W.R; j++) { g.moveTo(-hw, -hh + j * CS); g.lineTo(hw, -hh + j * CS); }
      g.stroke();
      // corner spawn pads
      for (const cc of [[0, 0], [W.C - 1, W.R - 1], [W.C - 1, 0], [0, W.R - 1]].slice(0, Math.max(2, W.n))) {
        const p = cellXY(W, cc[1] * W.C + cc[0]);
        g.beginPath(); g.arc(p[0], p[1], 13, 0, 7); g.strokeStyle = 'rgba(242,233,216,.08)'; g.lineWidth = 1.2; g.setLineDash([3, 3]); g.stroke(); g.setLineDash([]);
      }
      // walls
      const wg = wallCv.getContext('2d'); tf(wg);
      const Rr = W.rects;
      wg.fillStyle = 'rgba(5,10,8,.45)';
      for (let q = 0; q < W.nr; q++) { const i = q * 4; wg.fillRect(Rr[i] + 1.3, Rr[i + 1] + 2.2, Rr[i + 2] - Rr[i], Rr[i + 3] - Rr[i + 1]); }
      for (let q = 0; q < W.nr; q++) {
        const i = q * 4, x0 = Rr[i], y0 = Rr[i + 1], x1 = Rr[i + 2], y1 = Rr[i + 3], horiz = x1 - x0 > y1 - y0;
        const lg = horiz ? wg.createLinearGradient(0, y0, 0, y1) : wg.createLinearGradient(x0, 0, x1, 0);
        lg.addColorStop(0, '#c49460'); lg.addColorStop(0.45, '#9a6c40'); lg.addColorStop(1, '#6a4526');
        wg.fillStyle = lg; wg.fillRect(x0, y0, x1 - x0, y1 - y0);
        wg.strokeStyle = 'rgba(40,22,10,.55)'; wg.lineWidth = 0.35;
        wg.beginPath();
        if (horiz) { for (let gx = x0 + 6 + (hash(q, 3) % 9); gx < x1 - 2; gx += 11 + (hash(q, gx | 0) % 9)) { wg.moveTo(gx, y0 + 0.6); wg.lineTo(gx + 2.5, y1 - 0.6); } }
        else { for (let gy = y0 + 6 + (hash(q, 5) % 9); gy < y1 - 2; gy += 11 + (hash(q, gy | 0) % 9)) { wg.moveTo(x0 + 0.6, gy); wg.lineTo(x1 - 0.6, gy + 2.5); } }
        wg.stroke();
        wg.strokeStyle = 'rgba(30,16,6,.8)'; wg.lineWidth = 0.5; wg.strokeRect(x0 + 0.25, y0 + 0.25, x1 - x0 - 0.5, y1 - y0 - 0.5);
      }
      // brass studs where walls meet
      const M = W.M, C = W.C, R = W.R;
      for (let j = 0; j <= R; j++) for (let i = 0; i <= C; i++) {
        const hl = i > 0 && M.h[j * C + i - 1], hr = i < C && M.h[j * C + i], vu = j > 0 && M.v[(j - 1) * (C + 1) + i], vd = j < R && M.v[j * (C + 1) + i];
        const cnt = (hl ? 1 : 0) + (hr ? 1 : 0) + (vu ? 1 : 0) + (vd ? 1 : 0);
        if (!cnt || (cnt === 2 && ((hl && hr) || (vu && vd)))) continue;
        const x = W.ox + i * CS, y = W.oy + j * CS;
        wg.beginPath(); wg.arc(x, y, 1.6, 0, 7); wg.fillStyle = '#e3ae45'; wg.fill();
        wg.beginPath(); wg.arc(x - 0.4, y - 0.4, 0.6, 0, 7); wg.fillStyle = '#fff3cf'; wg.fill();
      }
    }
    function stampTreads(c, v) {
      if (!gctx) return;
      gctx.save(); gctx.translate(c.x, c.y); gctx.rotate(c.a);
      gctx.fillStyle = 'rgba(6,18,14,.2)';
      gctx.fillRect(-1.2, -7.1, 2.2, 3.4); gctx.fillRect(-1.2, 3.7, 2.2, 3.4);
      gctx.restore();
      void v;
    }
    function scorch(x, y) {
      if (!gctx) return;
      const rg = gctx.createRadialGradient(x, y, 1, x, y, 15); rg.addColorStop(0, 'rgba(8,6,6,.6)'); rg.addColorStop(0.6, 'rgba(10,8,8,.3)'); rg.addColorStop(1, 'rgba(10,8,8,0)');
      gctx.fillStyle = rg; gctx.beginPath(); gctx.arc(x, y, 15, 0, 7); gctx.fill();
      gctx.strokeStyle = 'rgba(8,6,6,.35)'; gctx.lineWidth = 0.8; gctx.beginPath();
      for (let i = 0; i < 9; i++) { const a = i * 0.7 + Math.random() * 0.4, r0 = 5, r1v = 11 + Math.random() * 7; gctx.moveTo(x + Math.cos(a) * r0, y + Math.sin(a) * r0); gctx.lineTo(x + Math.cos(a) * r1v, y + Math.sin(a) * r1v); }
      gctx.stroke();
    }

    /* ----- input ----- */
    const ptrs = new Map();
    function fireBtn() { const r = 40; return { x: cv.w - r - 18, y: cv.h - r - 24, r }; }
    function specBtn() { const r = 30; return { x: cv.w - 40 * 2 - 18 - 14 - r, y: cv.h - r - 34, r }; }
    function refresh() {
      for (const s of mine()) {
        const I = locIn[s] || (locIn[s] = { m: 's', x: 0, y: 0, v: 0, t: 0, fc: 0, sc: 0 });
        I.m = 's'; I.x = 0; I.y = 0; I.v = 0; I.t = 0;
        let stick = false;
        for (const p of ptrs.values()) {
          if (p.seat !== s || p.kind !== 'stick') continue;
          const dx = p.x - p.ax, dy = p.y - p.ay, d = Math.hypot(dx, dy);
          stick = true;
          if (d > 6) { const m = Math.min(1, d / STICK_R); I.x = r2(dx / d * m); I.y = r2(dy / d * m); }
        }
        if (!stick && api.input) {
          let v = 0, t = 0;
          try { v = api.input.axis('down', 'up'); t = api.input.axis('left', 'right'); } catch (e) {}
          if (v || t) { I.m = 'k'; I.v = r2(v); I.t = r2(t); }
        }
      }
    }
    function myTank() { const m = mine(); return m.length && W ? W.tanks[m[0]] : null; }
    function pressFire() {
      const s = mine()[0], I = s != null ? locIn[s] : null, c = myTank();
      if (!I || !c || !W || phase !== 'play' || W.over) return;
      if (!c.alive) { api.buzz(4); return; }
      if (shellsOf(W, s) >= SMAX) { api.buzz(4); sfx('click', 60); return; }
      I.fc = ((I.fc | 0) + 1) % 1000; api.buzz(12); pubT = 0; inT = 0;
    }
    function pressSpec() {
      const s = mine()[0], I = s != null ? locIn[s] : null, c = myTank();
      if (!I || !c || !W || phase !== 'play' || W.over) return;
      if (!c.alive || !c.sp) { api.buzz(4); return; }
      I.sc = ((I.sc | 0) + 1) % 1000; api.buzz(18); pubT = 0; inT = 0;
    }
    function onDown(e) {
      const p = cv.local(e), seat = mine()[0];
      if (seat == null || !W) return;
      e.preventDefault();
      if (p.y < TOPH) return;
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      hintT = Math.min(hintT, 1.2);
      const sb = specBtn();
      if (Math.hypot(p.x - sb.x, p.y - sb.y) < sb.r + 8) { ptrs.set(e.pointerId, { seat, kind: 'spec', x: p.x, y: p.y }); pressSpec(); refresh(); return; }
      if (p.x >= cv.w / 2) { ptrs.set(e.pointerId, { seat, kind: 'fire', x: p.x, y: p.y }); pressFire(); refresh(); return; }
      for (const [id, q] of ptrs) if (q.seat === seat && q.kind === 'stick') ptrs.delete(id);
      ptrs.set(e.pointerId, { seat, kind: 'stick', ax: p.x, ay: p.y, x: p.x, y: p.y });
      refresh();
    }
    function onMove(e) {
      const q = ptrs.get(e.pointerId);
      if (!q) return;
      const p = cv.local(e);
      q.x = p.x; q.y = p.y;
      if (q.kind === 'stick') {
        const d = Math.hypot(q.x - q.ax, q.y - q.ay);
        if (d > STICK_R * 1.3) { const k = STICK_R * 1.3 / d; q.ax = q.x - (q.x - q.ax) * k; q.ay = q.y - (q.y - q.ay) * k; } // the base follows the thumb
      }
      refresh();
    }
    function onUp(e) { if (ptrs.delete(e.pointerId)) refresh(); }
    const releaseAll = () => { ptrs.clear(); refresh(); };
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    window.addEventListener('blur', releaseAll);
    let offInput = null;
    try { if (api.input && api.input.on) offInput = api.input.on((type, id) => { if (type !== 'down') return; hintT = Math.min(hintT, 1.2); if (id === 'fire') pressFire(); else if (id === 'special') pressSpec(); }); } catch (e) { offInput = null; }

    const chip = L.h('button', { class: 'tk-chip', type: 'button', 'aria-label': '조준선 켜고 끄기', onclick() { api.sfx('click'); cfg.aim = cfg.aim ? 0 : 1; try { localStorage.setItem('lounge.tanks.cfg', JSON.stringify(cfg)); } catch (e) {} syncChip(); } });
    chip.addEventListener('pointerdown', (e) => e.stopPropagation());
    root.appendChild(chip);
    function syncChip() {
      chip.innerHTML = '';
      chip.append('조준선 ', L.h('b', { text: cfg.aim ? '켬' : '끔' }));
      chip.hidden = !mine().length || !st || st.ph === 'done';
      chipW = chip.hidden ? 0 : (chip.getBoundingClientRect().width || 84);
    }

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 50)) return; lastSfx = t; api.sfx(n); }
    function puff(x, y, col, n, sp, life, kind, sz) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.283, v = sp * (0.25 + Math.random());
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: (life || 0.5) * (0.6 + Math.random() * 0.6), T: life || 0.5, c: col, k: kind || 0, sz: sz || 1, r: Math.random() * 6, w: (Math.random() - 0.5) * 14 });
      }
      if (parts.length > 420) parts.splice(0, parts.length - 420);
    }
    function onFx(code, a, b, c, d, e) {
      if (code === 'f') { // shot: a seat, b kind, c/d pos, e angle
        const v = vis[a]; if (v) { v.fl = 0.09; v.rc = 0.12; }
        const mx = c + Math.cos(e) * (TR + 4), my = d + Math.sin(e) * (TR + 4);
        if (b === 3) { sfx('click', 40); if (isMine(a)) api.buzz(12); return; }
        puff(mx, my, 'rgba(230,225,215,.55)', 3, 14, 0.45, 2, 1.4);
        puff(mx, my, '#ffd27a', b === 1 ? 7 : 3, 60, 0.18, 0, 1);
        if (b === 2) sfx('whoosh', 40); else sfx(b === 1 ? 'thud' : 'hit', 40);
        if (isMine(a)) api.buzz(b === 1 ? 25 : 10);
      } else if (code === 'x') { // destroyed: a seat, b by, c/d pos
        const col = P(a).color;
        boomFx(c, d, col, true);
        scorch(c, d);
        const v = vis[a]; if (v) v.dead = true;
        if (isMine(a)) { api.sfx('lose'); api.buzz(140); shake = 1; }
        else if (b >= 0 && isMine(b)) { sfx('thud', 20); api.buzz(45); shake = Math.min(1, shake + 0.5); }
        else { sfx('thud', 20); shake = Math.min(1, shake + 0.35); }
        addFloat(c, d - 12, b === a ? name(a) + ' 자폭!' : b >= 0 ? name(b) + ' → ' + name(a) : name(a) + ' 격파!', b >= 0 && b !== a ? P(b).color : col, 1.8);
      } else if (code === 's') {
        rings.push({ x: b, y: c, r0: 8, r1: 20, t: 0.35, T: 0.35, col: PU.D.col });
        puff(b, c, PU.D.col, 10, 70, 0.35);
        sfx('bounce', 30); if (isMine(a)) api.buzz(40);
        addFloat(b, c - 12, '방패!', PU.D.col, 1);
      } else if (code === 'l') { // laser: a seat, b/c origin, d angle, e length
        const n = laserPath(W, b, c, d, TBV), pts = [];
        let rem = e;
        for (let k = 0; k < n; k++) {
          const x = TBV[2 * k], y = TBV[2 * k + 1];
          if (k > 0) { const px = pts[pts.length - 2], py = pts[pts.length - 1], sl = Math.hypot(x - px, y - py); if (sl >= rem) { const u = rem / (sl || 1); pts.push(px + (x - px) * u, py + (y - py) * u); break; } rem -= sl; }
          pts.push(x, y);
        }
        beams.push({ pts, t: 0.45, T: 0.45, col: P(a).color });
        const v = vis[a]; if (v) { v.fl = 0.12; v.rc = 0.15; }
        sfx('whoosh', 20); shake = Math.min(1, shake + 0.25); if (isMine(a)) api.buzz(30);
        for (let k = 2; k < pts.length - 2; k += 2) puff(pts[k], pts[k + 1], '#ffd0d8', 3, 40, 0.3);
      } else if (code === 'p') { // pick-up: a seat, b kind idx, c/d pos
        const k = PU_KEYS[b] || 'D', I = PU[k];
        rings.push({ x: c, y: d, r0: 4, r1: 18, t: 0.3, T: 0.3, col: I.col });
        addFloat(c, d - 10, I.nm + '!', I.col, 1.2);
        sfx('chip', 30); if (isMine(a)) { api.buzz(22); }
      } else if (code === 'b') { // mine: a/b pos, c owner
        boomFx(a, b, PU.N.col, false);
        rings.push({ x: a, y: b, r0: 4, r1: MINE_BOOM, t: 0.35, T: 0.35, col: '#ffb35c' });
        scorch(a, b); sfx('thud', 20); shake = Math.min(1, shake + 0.45);
      } else if (code === 'u') { // crate appears
        rings.push({ x: a, y: b, r0: 14, r1: 4, t: 0.4, T: 0.4, col: (PU[PU_KEYS[c]] || PU.D).col });
        sfx('pop', 60);
      }
    }
    function addFloat(x, y, text, col, T) { // stack labels that pop up at the same spot
      for (const f of floats) if (Math.abs(f.x - x) < 40 && Math.abs(f.y - y) < 9 && f.t > f.T - 0.6) y = f.y - 11;
      floats.push({ x, y, text, col, t: T, T });
    }
    function boomFx(x, y, col, big) {
      rings.push({ x, y, r0: 3, r1: big ? 30 : 22, t: 0.32, T: 0.32, col: '#fff3cf' });
      puff(x, y, '#ffd27a', big ? 18 : 12, 120, 0.4, 0, 1.2);
      puff(x, y, '#ff7a3d', big ? 14 : 10, 90, 0.5, 0, 1.4);
      puff(x, y, 'rgba(60,52,58,.7)', big ? 10 : 6, 30, 1.1, 2, 2.4);
      if (big) { puff(x, y, col, 10, 95, 0.9, 1, 1.4); parts.push({ x, y, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 60, t: 0.9, T: 0.9, c: col, k: 3, sz: 1, r: 0, w: (Math.random() - 0.5) * 18 }); }
    }
    const hooks = {
      fx: onFx,
      bounce(s) { if (s.k !== 'p' && Math.random() < 0.6) puff(s.x, s.y, '#fff3cf', 2, 30, 0.18); if (isMine(s.o) && s.k === 's') sfx('tick', 110); },
      empty(c) { void c; },
    };

    /* ----- host: round flow ----- */
    function hostFlow(dt) {
      if (!host() || !st || !W) return;
      if (st.ph === 'count' && phase === 'play') { api.setState(Object.assign({}, st, { ph: 'play' })); return; }
      if (st.ph === 'play') {
        const alive = W.tanks.filter((c) => c.alive);
        if (alive.length <= 1) { lastT += dt; if (lastT >= LAST_T) { lastT = -1e9; api.setState(roundOver(st, alive.length === 1 ? alive[0].seat : -1)); } }
        else if (W.t > CAP_T) api.setState(roundOver(st, -1));
      } else if (st.ph === 'end') {
        endT -= dt;
        if (endT <= 0) { endT = 1e9; api.setState(nextRound(st)); }
      }
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.tanks.length) || simHere(s) || !o || o.k !== key) continue;
        remIn[s] = { m: o.m === 'k' ? 'k' : 's', x: clamp(+o.x || 0, -1, 1), y: clamp(+o.y || 0, -1, 1), v: clamp(+o.v || 0, -1, 1), t: clamp(+o.t || 0, -1, 1), fc: o.fc | 0, sc: o.sc | 0 };
        if (fin(o.q)) iqOf[s] = o.q;
      }
    }
    function encode() {
      const T = W.tanks.map((c) => [r1(c.x), r1(c.y), r2(c.a), c.alive ? 1 : 0, c.sp ? SPK.indexOf(c.sp) + 1 : 0, r1(Math.max(0, c.sh)), Math.round(c.v || 0)]);
      const S = [], sh = W.shells.length > 40 ? W.shells.slice(-40) : W.shells;
      for (const s of sh) S.push(r1(s.x), r1(s.y), Math.round(s.vx), Math.round(s.vy), s.o, SKK.indexOf(s.k), r2(s.t), s.arm ? 1 : 0);
      const M = []; for (const m of W.mines) M.push(m.x, m.y, m.o, r1(m.t), m.lf ? 1 : 0);
      const Pu = []; for (const p of W.pu) Pu.push(p.x, p.y, PU_KEYS.indexOf(p.k));
      return { k: key, q: hsQ, t: r2(W.t), T, S, M, P: Pu, fx: W.fx.slice(-8), iq: Object.assign({}, iqOf) };
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.T)) return;
      lastQ = hs.q;
      if (fin(hs.t)) W.t = hs.t;
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; try { onFx(e[1], e[2], e[3], e[4], e[5], e[6]); } catch (er) {} }
      const lag = Math.min(0.2, rtt / 2);
      hs.T.forEach((a, i) => {
        const c = W.tanks[i];
        if (!c || !Array.isArray(a)) return;
        c.alive = !!(a[3] & 1); c.sp = SPK[(a[4] | 0) - 1] || ''; c.sh = +a[5] || 0; c.v = +a[6] || 0;
        if (!isMine(i)) return;
        if (hs.iq && fin(hs.iq[i]) && sendT[hs.iq[i]]) { const sm = (now - sendT[hs.iq[i]]) / 1000; if (sm > 0 && sm < 2) rtt = rtt * 0.85 + sm * 0.15; }
        const tx = a[0] + Math.cos(a[2]) * c.v * lag, ty = a[1] + Math.sin(a[2]) * c.v * lag;
        if (!c.alive || Math.hypot(tx - c.x, ty - c.y) > 30) { c.x = tx; c.y = ty; c.a = a[2]; }
        else { c.x += (tx - c.x) * 0.3; c.y += (ty - c.y) * 0.3; if (Math.abs(wrapA(a[2] - c.a)) > 0.6) c.a = a[2]; }
      });
      const S = Array.isArray(hs.S) ? hs.S : [];
      W.shells = [];
      for (let i = 0; i + 7 < S.length; i += 8) W.shells.push({ x: +S[i], y: +S[i + 1], vx: +S[i + 2], vy: +S[i + 3], o: S[i + 4] | 0, k: SKK[S[i + 5]] || 's', t: +S[i + 6] || 0, arm: S[i + 7] ? 1 : 0, bt: -1, id: 0 });
      let k = lag * SPD(); while (k > 1e-6) { const hh = Math.min(H * 2, k); stepShells(W, hh, null, false); k -= hh; }
      const Mi = Array.isArray(hs.M) ? hs.M : []; W.mines = [];
      for (let i = 0; i + 4 < Mi.length; i += 5) W.mines.push({ x: +Mi[i], y: +Mi[i + 1], o: Mi[i + 2] | 0, t: +Mi[i + 3] || 0, lf: Mi[i + 4] ? 1 : 0 });
      const Pp = Array.isArray(hs.P) ? hs.P : []; W.pu = [];
      for (let i = 0; i + 2 < Pp.length; i += 3) W.pu.push({ x: +Pp[i], y: +Pp[i + 1], k: PU_KEYS[Pp[i + 2]] || 'D' });
      snaps.push({ at: now, T: hs.T }); if (snaps.length > 4) snaps.shift();
    }
    function interpOthers(now) {
      if (host() || !snaps.length || !W) return;
      const rt = now - 100;
      let A = null, B = snaps[snaps.length - 1], k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.25);
      W.tanks.forEach((c, s) => {
        if (isMine(s)) return;
        const b = B.T[s], a = A ? A.T[s] : null;
        if (!Array.isArray(b)) return;
        if (a && Array.isArray(a) && Math.hypot(b[0] - a[0], b[1] - a[1]) < 60) { c.x = a[0] + (b[0] - a[0]) * k; c.y = a[1] + (b[1] - a[1]) * k; c.a = a[2] + wrapA(b[2] - a[2]) * k; }
        else { c.x = b[0]; c.y = b[1]; c.a = b[2]; }
      });
    }
    function publish(rdt, now) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          let o = encode();
          if (JSON.stringify(o).length > 2600) { o.S = o.S.slice(-160); o.fx = o.fx.slice(-4); }
          api.net.hostSend(o);
        } else {
          const s = mine()[0];
          if (s == null) return;
          const I = locIn[s]; if (!I) return;
          const sig = [I.m, I.x, I.y, I.v, I.t, I.fc, I.sc].join('|');
          if (sig === lastSig && inT > 0) return;
          lastSig = sig; inT = 0.15;
          inQ = (inQ + 1) % 100000; sendT[inQ] = now; delete sendT[(inQ + 99900) % 100000];
          api.net.publish({ k: key, q: inQ, m: I.m, x: I.x, y: I.y, v: I.v, t: I.t, fc: I.fc | 0, sc: I.sc | 0 });
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      const dt = rdt * SPD();
      if (W && phase === 'count') {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0) api.sfx('tick');
        if (cd <= 0 && (host() || st.ph === 'play')) { phase = 'play'; api.sfx('pop'); api.buzz(20); }
      }
      if (hintT > 0 && phase === 'play') hintT -= rdt;
      refresh();
      const auto = L.debug && L.debug.autoplay;
      if (host()) {
        pollHost();
        if (W && phase === 'play' && (st.ph === 'play' || st.ph === 'count' || st.ph === 'end')) {
          W.over = st.ph === 'end';
          W.tanks.forEach((c, i) => {
            const p = api.players[i]; if (!p) return;
            if (simHere(i)) inputs[i] = autoSeat(i) || auto ? aiThink(W, c, aiMem[i], p.ai ? (p.lv || 2) : 2, dt) : locIn[i];
            else inputs[i] = remIn[i];
          });
          acc += Math.min(dt, 0.25);
          let n = 0;
          while (acc >= H && n < 120) { stepWorld(W, inputs, hooks, true); acc -= H; n++; }
          if (st.ph === 'play' && st.it) maybePowerup(W, dt, hooks);
        }
        hostFlow(dt);
      } else if (W) {
        pollGuest(now);
        if (phase === 'play' && (st.ph === 'play' || st.ph === 'end')) {
          W.t += dt;
          const s = mine()[0], c = s != null ? W.tanks[s] : null;
          if (c && c.alive && st.ph === 'play') {
            if (auto) { const I = aiThink(W, c, aiMem[s] || (aiMem[s] = {}), 2, dt), Lc = locIn[s]; if (Lc) { Lc.m = 'k'; Lc.v = I.v; Lc.t = I.t; Lc.fc = I.fc; Lc.sc = I.sc; } }
            let k = Math.min(dt, 0.1); while (k > 1e-6) { const hh = Math.min(H * 2, k); stepTank(W, c, locIn[s], hh); k -= hh; }
          }
          let k = Math.min(dt, 0.1); while (k > 1e-6) { const hh = Math.min(H * 2, k); stepShells(W, hh, hooks, false); stepMines(W, hh, null, false); k -= hh; }
        }
        interpOthers(now);
      }
      // per-tank visuals: tread phase, tread marks, missile smoke
      if (W) W.tanks.forEach((c, i) => {
        const v = vis[i]; if (!v) return;
        if (c.alive) {
          const dx = c.x - v.px, dy = c.y - v.py, fwd = dx * Math.cos(c.a) + dy * Math.sin(c.a), da = wrapA(c.a - v.pa);
          if (Math.abs(fwd) < 20) { v.tl += fwd - da * 5.3; v.tr += fwd + da * 5.3; }
          if (Math.hypot(c.x - v.sx, c.y - v.sy) > 2.6 || Math.abs(da) > 0.25) { stampTreads(c, v); v.sx = c.x; v.sy = c.y; }
          v.dead = false;
        }
        v.px = c.x; v.py = c.y; v.pa = c.a;
        if (v.fl > 0) v.fl -= rdt;
        if (v.rc > 0) v.rc -= rdt;
      });
      if (W) for (const s of W.shells) if (s.k === 'm' && Math.random() < 0.7) parts.push({ x: s.x - s.vx * 0.04, y: s.y - s.vy * 0.04, vx: (Math.random() - 0.5) * 8, vy: (Math.random() - 0.5) * 8, t: 0.5, T: 0.5, c: 'rgba(210,205,215,.55)', k: 2, sz: 1.1, r: 0, w: 0 });
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; const f = p.k === 2 ? 0.96 : 0.9; p.vx *= f; p.vy *= f; p.r += p.w * rdt; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t -= rdt; if (rings[i].t <= 0) rings.splice(i, 1); }
      for (let i = beams.length - 1; i >= 0; i--) { beams[i].t -= rdt; if (beams[i].t <= 0) beams.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 3);
      publish(rdt, now);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, al) {
      ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(16,12,22,.88)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y); ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function drawTank(g, x, y, a, col, v, now) {
      g.save(); g.translate(x, y); g.rotate(a);
      g.fillStyle = 'rgba(0,0,0,.32)'; rrect(g, -7.2 + 1.1, -7.3 + 1.9, 14.4, 14.6, 3); g.fill();
      for (let sd = -1; sd <= 1; sd += 2) {
        const ty = sd * 5.3, ph = v ? (sd < 0 ? v.tl : v.tr) : 0;
        g.fillStyle = '#272230'; rrect(g, -7.3, ty - 2.05, 14.6, 4.1, 1.8); g.fill();
        g.strokeStyle = 'rgba(170,160,182,.55)'; g.lineWidth = 0.6; g.beginPath();
        const off = ((ph % 2.4) + 2.4) % 2.4;
        for (let u = -7 + off; u < 7.1; u += 2.4) { g.moveTo(u, ty - 1.6); g.lineTo(u, ty + 1.6); }
        g.stroke();
      }
      rrect(g, -6, -4.1, 12, 8.2, 2.2); g.fillStyle = col; g.fill();
      g.lineWidth = 0.8; g.strokeStyle = 'rgba(18,12,26,.9)'; g.stroke();
      g.fillStyle = 'rgba(255,255,255,.26)'; rrect(g, -5.3, -3.5, 10.6, 2, 1); g.fill();
      g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(-5.4, 2.1, 10.8, 1.3);
      g.fillStyle = 'rgba(18,12,26,.45)'; for (let k = 0; k < 3; k++) g.fillRect(-5.2 + k * 1.2, -1.6, 0.6, 3.2);
      const rc = v && v.rc > 0 ? (v.rc / 0.12) * 2 : 0;
      g.fillStyle = shade(col, -0.42); rrect(g, 1 - rc, -1.2, 10.4, 2.4, 0.9); g.fill(); g.strokeStyle = 'rgba(18,12,26,.9)'; g.lineWidth = 0.6; g.stroke();
      g.fillStyle = '#272230'; g.fillRect(9.6 - rc, -1.55, 1.9, 3.1);
      g.beginPath(); g.arc(-0.4, 0, 3.8, 0, 7); g.fillStyle = shade(col, -0.16); g.fill(); g.lineWidth = 0.8; g.strokeStyle = 'rgba(18,12,26,.9)'; g.stroke();
      g.beginPath(); g.arc(-1.2, -0.9, 1.5, 0, 7); g.fillStyle = 'rgba(255,255,255,.33)'; g.fill();
      if (v && v.fl > 0) { // muzzle flash
        const k = v.fl / 0.09;
        g.globalAlpha = Math.min(1, k);
        g.fillStyle = '#ffe9a8'; g.beginPath();
        for (let i = 0; i < 10; i++) { const an = (i / 10) * Math.PI * 2, r = i % 2 ? 1.8 : 4.6 * (0.7 + 0.3 * k); g.lineTo(13.5 + Math.cos(an) * r * 1.3, Math.sin(an) * r); }
        g.closePath(); g.fill();
        g.beginPath(); g.arc(13, 0, 1.8, 0, 7); g.fillStyle = '#ffffff'; g.fill();
        g.globalAlpha = 1;
      }
      g.restore();
      void now;
    }
    function drawWorld(now) {
      const me = mine()[0];
      // mines
      for (const m of W.mines) {
        const armed = m.t >= MINE_ARM, col = P(m.o).color;
        ctx.beginPath(); ctx.arc(m.x + 0.6, m.y + 1, 4.4, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fill();
        ctx.beginPath(); ctx.arc(m.x, m.y, 4.4, 0, 7); ctx.fillStyle = '#2e2836'; ctx.fill(); ctx.lineWidth = 1.1; ctx.strokeStyle = col; ctx.stroke();
        for (let k = 0; k < 4; k++) { const an = k * Math.PI / 2 + 0.6; ctx.fillStyle = '#6b6276'; ctx.fillRect(m.x + Math.cos(an) * 4.6 - 0.7, m.y + Math.sin(an) * 4.6 - 0.7, 1.4, 1.4); }
        const blink = armed ? (Math.sin(now / 110) > 0 ? 1 : 0.25) : 0.35;
        ctx.beginPath(); ctx.arc(m.x, m.y, 1.5, 0, 7); ctx.fillStyle = armed ? 'rgba(255,70,80,' + blink + ')' : 'rgba(227,174,69,.6)'; ctx.fill();
        if (armed && blink > 0.5) { ctx.beginPath(); ctx.arc(m.x, m.y, 3.2, 0, 7); ctx.fillStyle = 'rgba(255,70,80,.25)'; ctx.fill(); }
      }
      // crates
      for (const p of W.pu) {
        const I = PU[p.k] || PU.D, b = 1 + 0.07 * Math.sin(now / 230 + p.x * 0.1);
        ctx.save(); ctx.translate(p.x, p.y); ctx.scale(b, b);
        ctx.beginPath(); ctx.arc(0, 0, 10.5, 0, 7); ctx.fillStyle = hexA(I.col, 0.16 + 0.08 * Math.sin(now / 180)); ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,.35)'; rrect(ctx, -6 + 0.8, -6 + 1.4, 12, 12, 2.2); ctx.fill();
        rrect(ctx, -6, -6, 12, 12, 2.2); ctx.fillStyle = '#a77b4d'; ctx.fill(); ctx.lineWidth = 0.8; ctx.strokeStyle = '#4a2f1b'; ctx.stroke();
        ctx.strokeStyle = 'rgba(74,47,27,.6)'; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(-6, -2); ctx.lineTo(6, -2); ctx.moveTo(-6, 2.2); ctx.lineTo(6, 2.2); ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 0, 4.6, 0, 7); ctx.fillStyle = I.col; ctx.fill(); ctx.lineWidth = 0.7; ctx.strokeStyle = 'rgba(18,12,26,.8)'; ctx.stroke();
        ctx.font = '6.4px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#17131f'; ctx.fillText(I.ch, 0, 0.4);
        ctx.restore();
      }
      // laser sights (everyone holding a laser) and my aim line
      for (const c of W.tanks) {
        if (!c.alive || c.sp !== 'L') continue;
        const n = laserPath(W, c.x, c.y, c.a, TBV);
        ctx.save(); ctx.setLineDash([2, 3]); ctx.lineWidth = isMine(c.seat) ? 1.1 : 0.8; ctx.strokeStyle = isMine(c.seat) ? 'rgba(255,84,112,.85)' : 'rgba(255,84,112,.35)';
        ctx.beginPath(); ctx.moveTo(TBV[0] + Math.cos(c.a) * (TR + 4), TBV[1] + Math.sin(c.a) * (TR + 4));
        for (let k = 1; k < n; k++) ctx.lineTo(TBV[2 * k], TBV[2 * k + 1]);
        ctx.stroke(); ctx.restore();
      }
      if (me != null && cfg.aim && W.tanks[me] && W.tanks[me].alive && W.tanks[me].sp !== 'L' && st.ph !== 'end' && st.ph !== 'done') {
        const c = W.tanks[me], n = traceRay(W, c.x, c.y, c.a, 1, 300, SR, TBV), col = P(me).color;
        ctx.save(); ctx.lineCap = 'round';
        let used = 0;
        for (let k = 0; k < n - 1; k++) {
          let ax = TBV[2 * k], ay = TBV[2 * k + 1];
          const bx = TBV[2 * k + 2], by = TBV[2 * k + 3], sl = Math.hypot(bx - ax, by - ay);
          if (k === 0) { const u = Math.min(1, (TR + 5) / (sl || 1)); ax += (bx - ax) * u; ay += (by - ay) * u; }
          let ex = bx, ey = by;
          if (k === 1) { const lim = 70; if (sl > lim) { ex = ax + (bx - ax) * lim / sl; ey = ay + (by - ay) * lim / sl; } }
          ctx.setLineDash([2.5, 3.5]); ctx.lineDashOffset = -(now / 40) % 6;
          ctx.strokeStyle = hexA(col, k === 0 ? 0.6 : 0.32); ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ex, ey); ctx.stroke();
          if (k === 0 && n > 2) { ctx.setLineDash([]); ctx.beginPath(); ctx.arc(bx, by, 1.6, 0, 7); ctx.fillStyle = hexA(col, 0.75); ctx.fill(); }
          used += sl;
        }
        void used;
        ctx.restore();
      }
      // shells
      for (const s of W.shells) {
        const col = P(s.o).color;
        if (s.k === 'm') {
          const an = Math.atan2(s.vy, s.vx);
          ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(an);
          ctx.fillStyle = 'rgba(255,170,80,' + (0.6 + Math.random() * 0.4) + ')'; ctx.beginPath(); ctx.moveTo(-4, -1.2); ctx.lineTo(-7 - Math.random() * 2, 0); ctx.lineTo(-4, 1.2); ctx.fill();
          ctx.fillStyle = shade(col, -0.3); ctx.beginPath(); ctx.moveTo(-4, -2.6); ctx.lineTo(-2, -1); ctx.lineTo(-2, 1); ctx.lineTo(-4, 2.6); ctx.fill();
          rrect(ctx, -4.2, -1.5, 8, 3, 1.4); ctx.fillStyle = col; ctx.fill(); ctx.lineWidth = 0.6; ctx.strokeStyle = 'rgba(18,12,26,.9)'; ctx.stroke();
          ctx.beginPath(); ctx.arc(3.6, 0, 1.4, 0, 7); ctx.fillStyle = '#fbf3df'; ctx.fill();
          ctx.restore();
          continue;
        }
        const r = s.k === 'p' ? PR : SR, tl = Math.min(0.045, Math.max(0, s.t - (s.bt > 0 ? s.bt : 0)));
        if (tl > 0.004) { ctx.strokeStyle = hexA(col, 0.5); ctx.lineWidth = r * 1.3; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(s.x - s.vx * tl, s.y - s.vy * tl); ctx.lineTo(s.x, s.y); ctx.stroke(); }
        ctx.beginPath(); ctx.arc(s.x, s.y, r, 0, 7); ctx.fillStyle = s.k === 'p' ? '#ffe2b8' : '#fbf3df'; ctx.fill();
        ctx.lineWidth = 0.6; ctx.strokeStyle = 'rgba(18,12,26,.9)'; ctx.stroke();
      }
      // tanks
      W.tanks.forEach((c, i) => {
        if (!c.alive) return;
        const col = P(i).color;
        if (phase === 'count' && isMine(i)) { ctx.beginPath(); ctx.arc(c.x, c.y, 12 + 2 * Math.sin(now / 150), 0, 7); ctx.strokeStyle = hexA(col, 0.8); ctx.lineWidth = 1.4; ctx.stroke(); }
        drawTank(ctx, c.x, c.y, c.a, col, vis[i], now);
        if (c.sh > 0) {
          const pulse = 0.5 + 0.2 * Math.sin(now / 90), fade = c.sh < 1.5 ? (Math.sin(now / 60) > 0 ? 1 : 0.35) : 1;
          ctx.beginPath(); ctx.arc(c.x, c.y, 11.5, 0, 7); ctx.fillStyle = 'rgba(127,227,255,' + (0.12 * fade) + ')'; ctx.fill();
          ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(127,227,255,' + (pulse * fade) + ')'; ctx.stroke();
          ctx.beginPath(); ctx.arc(c.x, c.y, 13.2, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * clamp(c.sh / SHIELD_T, 0, 1)); ctx.strokeStyle = 'rgba(127,227,255,.6)'; ctx.lineWidth = 0.8; ctx.stroke();
        }
        if (c.sp && PU[c.sp]) {
          const I = PU[c.sp], bx = c.x + 8, by = c.y - 9;
          ctx.beginPath(); ctx.arc(bx, by, 3.6, 0, 7); ctx.fillStyle = I.col; ctx.fill(); ctx.lineWidth = 0.6; ctx.strokeStyle = 'rgba(18,12,26,.9)'; ctx.stroke();
          ctx.font = '4.8px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#17131f'; ctx.fillText(I.ch, bx, by + 0.3);
        }
      });
      // laser beams
      for (const b of beams) {
        const k = b.t / b.T;
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(b.pts[0], b.pts[1]); for (let i = 2; i < b.pts.length; i += 2) ctx.lineTo(b.pts[i], b.pts[i + 1]);
        ctx.strokeStyle = 'rgba(255,84,112,' + (0.55 * k) + ')'; ctx.lineWidth = 4.5 * k + 1; ctx.stroke();
        ctx.strokeStyle = hexA(b.col, 0.8 * k); ctx.lineWidth = 2 * k + 0.5; ctx.stroke();
        ctx.strokeStyle = 'rgba(255,245,245,' + k + ')'; ctx.lineWidth = 0.9; ctx.stroke();
        ctx.restore();
      }
      // particles
      for (const p of parts) {
        const k = clamp(p.t / p.T, 0, 1);
        if (p.k === 2) { ctx.globalAlpha = k * 0.8; ctx.beginPath(); ctx.arc(p.x, p.y, p.sz * (2.6 - k * 1.4), 0, 7); ctx.fillStyle = p.c; ctx.fill(); }
        else if (p.k === 1) { ctx.globalAlpha = Math.min(1, k * 1.5); ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.fillRect(-1.6, -1, 3.2, 2); ctx.restore(); }
        else if (p.k === 3) { ctx.globalAlpha = Math.min(1, k * 1.5); ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.beginPath(); ctx.arc(0, 0, 3.6, 0, 7); ctx.fillStyle = shade(p.c, -0.2); ctx.fill(); ctx.fillStyle = '#272230'; ctx.fillRect(1, -1, 7, 2); ctx.restore(); }
        else { ctx.globalAlpha = k; ctx.fillStyle = p.c; ctx.fillRect(p.x - 0.8 * p.sz, p.y - 0.8 * p.sz, 1.6 * p.sz, 1.6 * p.sz); }
      }
      ctx.globalAlpha = 1;
      for (const r of rings) {
        const k = 1 - r.t / r.T;
        ctx.beginPath(); ctx.arc(r.x, r.y, r.r0 + (r.r1 - r.r0) * k, 0, 7); ctx.strokeStyle = hexA(r.col, 0.85 * (1 - k)); ctx.lineWidth = 2 * (1 - k) + 0.5; ctx.stroke();
      }
    }
    function drawStrip() {
      const n = st.n, need = st.need, avail = cv.w - 16 - (chipW ? chipW + 8 : 0);
      ctx.font = '700 13px ' + MONO;
      const lab = 'R' + st.rd, labW = ctx.measureText(lab).width + 16;
      let per = 24 + need * 8 + 8, pips = true;
      if (labW + n * per + 8 > avail) { pips = false; per = 46; }
      const bw = Math.min(avail, labW + n * per + 8), x0 = 8, y0 = 4, bh = 44;
      rrect(ctx, x0, y0, bw, bh, 12); ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.fill(); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(227,174,69,.28)'; ctx.stroke();
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#e3ae45'; ctx.fillText(lab, x0 + 10, y0 + bh / 2);
      let x = x0 + labW;
      for (let s = 0; s < n; s++) {
        const c = W && W.tanks[s], dead = c && !c.alive && st.ph !== 'count', col = P(s).color, cy = y0 + bh / 2;
        ctx.globalAlpha = dead ? 0.38 : 1;
        ctx.save(); ctx.translate(x + 10, cy); ctx.scale(0.95, 0.95); drawTank(ctx, 0, 0, -Math.PI / 2, col, null, 0); ctx.restore();
        if (pips) for (let k = 0; k < need; k++) { ctx.beginPath(); ctx.arc(x + 25 + k * 8, cy, 3, 0, 7); ctx.fillStyle = st.wins[s] > k ? col : 'rgba(242,233,216,.16)'; ctx.fill(); }
        else { ctx.font = '700 15px ' + MONO; ctx.textAlign = 'left'; ctx.fillStyle = col; ctx.fillText(String(st.wins[s] | 0), x + 22, cy + 1); }
        if (isMine(s)) { ctx.fillStyle = '#e3ae45'; ctx.fillRect(x + 2, y0 + bh - 6, per - 10, 2); }
        x += per;
      }
      ctx.globalAlpha = 1;
    }
    function draw(now) {
      cv.clear();
      const w = cv.w, h = cv.h;
      ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h);
      if (!st || !W) return;
      if (!lay || !groundCv) layout();
      const sh = shake > 0.02 ? shake : 0, ox = sh ? (Math.random() - 0.5) * sh * 6 : 0, oy = sh ? (Math.random() - 0.5) * sh * 6 : 0;
      const bx = X(-lay.ww / 2) + ox, by = Y(-lay.wh / 2) + oy, bw = lay.ww * lay.s, bh = lay.wh * lay.s;
      ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.5)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 6; ctx.fillStyle = '#3a2616'; rrect(ctx, bx, by, bw, bh, 7 * lay.s); ctx.fill(); ctx.restore();
      ctx.drawImage(groundCv, bx, by, bw, bh);
      ctx.drawImage(wallCv, bx, by, bw, bh);
      ctx.save(); ctx.translate(lay.cx + ox, lay.cy + oy); ctx.scale(lay.s, lay.s);
      drawWorld(now);
      ctx.restore();
      // world-space labels at screen size
      for (const f of floats) { ctx.globalAlpha = Math.min(1, f.t / 0.4); txt(f.text, X(f.x), Y(f.y) - (1 - f.t / f.T) * 16, f.col, '700 12px ' + FONT); }
      ctx.globalAlpha = 1;
      if (phase === 'count') W.tanks.forEach((c, i) => { if (c.alive) txt(isMine(i) ? '나' : name(i), X(c.x), Y(c.y) - 14 * lay.s - 8, P(i).color, '700 11px ' + FONT); });
      drawHud(now);
    }
    function drawHud(now) {
      const w = cv.w, h = cv.h, m = mine();
      drawStrip();
      if (st.ph !== 'done') for (const s of m) drawControls(s, now);
      const midY = lay.cy;
      if (phase === 'count' && st.ph === 'count') {
        txt('라운드 ' + st.rd + ' · ' + mapName(st.mk), w / 2, midY - 52, '#f2e9d8', '20px ' + DISP);
        txt(String(Math.max(1, Math.ceil(cd))), w / 2, midY, '#e3ae45', '64px ' + DISP);
        if (st.rd > 1 || st.mk > 0) txt(st.mk > 0 ? FIXED[st.mk - 1].sub : '라운드마다 새로 만든 미로', w / 2, midY + 46, '#cfc3dc', '600 12.5px ' + FONT);
      }
      if (st.ph === 'end') {
        const t = st.rw >= 0 ? name(st.rw) + ' 라운드 승리!' : '무승부 · 모두 격파';
        rrect(ctx, 16, midY - 30, w - 32, 60, 14); ctx.fillStyle = 'rgba(23,19,31,.82)'; ctx.fill();
        txt(t, w / 2, midY - 8, st.rw >= 0 ? P(st.rw).color : '#f2e9d8', '22px ' + DISP);
        let sub = st.need + '승 먼저 · ' + st.wins.map((v, i) => name(i) + ' ' + v).join(' · ');
        ctx.font = '600 11.5px ' + FONT;
        if (ctx.measureText(sub).width > w - 44) sub = st.need + '승 먼저 · ' + st.wins.join(' : ');
        txt(sub, w / 2, midY + 16, '#cfc3dc', '600 11.5px ' + FONT);
      }
      if (st.ph === 'play' && W.t > CAP_T - 10 && W.t < CAP_T) txt('시간 종료 ' + Math.ceil(CAP_T - W.t) + '초 전', w / 2, TOPH + 22, '#ee6a55', '17px ' + DISP);
      if (hintT > 0 && m.length && phase === 'play' && st.ph === 'play' && W.tanks[m[0]] && W.tanks[m[0]].alive) {
        ctx.globalAlpha = Math.min(1, hintT);
        const t1 = '왼쪽을 끌면 그쪽으로 달려요', t2 = '오른쪽을 누르면 발사 · 포탄은 벽에 튕겨요';
        ctx.font = '600 12.5px ' + FONT;
        const bw2 = Math.min(w - 16, Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width) + 26), y0 = lay.cy - 24;
        rrect(ctx, (w - bw2) / 2, y0, bw2, 48, 13); ctx.fillStyle = 'rgba(23,19,31,.8)'; ctx.fill();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t1, w / 2, y0 + 15); ctx.fillStyle = '#e3ae45'; ctx.fillText(t2, w / 2, y0 + 33);
        ctx.globalAlpha = 1;
      }
    }
    function drawControls(s, now) {
      const w = cv.w, h = cv.h, c = W.tanks[s], col = P(s).color, dead = !c || !c.alive;
      ctx.save();
      ctx.globalAlpha = dead ? 0.3 : 1;
      let fP = false, sP = false; for (const p of ptrs.values()) if (p.seat === s) { if (p.kind === 'fire') fP = true; if (p.kind === 'spec') sP = true; }
      // special
      const sb = specBtn(), has = c && c.sp && PU[c.sp];
      ctx.beginPath(); ctx.arc(sb.x, sb.y, sb.r * (sP ? 0.92 : 1), 0, 7); ctx.fillStyle = has ? hexA(PU[c.sp].col, 0.9) : 'rgba(46,38,64,.85)'; ctx.fill();
      ctx.lineWidth = 2.5; ctx.strokeStyle = has ? '#fff3cf' : 'rgba(242,233,216,.22)'; ctx.stroke();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (has) { ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#17131f'; ctx.fillText(PU[c.sp].nm, sb.x, sb.y - 5); ctx.font = '600 9.5px ' + FONT; ctx.fillText('특수', sb.x, sb.y + 9); }
      else { ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('특수', sb.x, sb.y - 6); ctx.fillText('없음', sb.x, sb.y + 8); }
      // fire
      const fb = fireBtn(), ammo = c ? SMAX - shellsOf(W, s) : 0;
      if (fP) { ctx.beginPath(); ctx.arc(fb.x, fb.y, fb.r + 7, 0, 7); ctx.strokeStyle = hexA(col, 0.5); ctx.lineWidth = 3; ctx.stroke(); }
      ctx.beginPath(); ctx.arc(fb.x, fb.y, fb.r * (fP ? 0.93 : 1), 0, 7); ctx.fillStyle = hexA(col, ammo > 0 ? (fP ? 0.98 : 0.78) : 0.35); ctx.fill();
      ctx.lineWidth = 3; ctx.strokeStyle = '#fff3cf'; ctx.stroke();
      ctx.font = '19px ' + DISP; ctx.fillStyle = '#17131f'; ctx.fillText('발사', fb.x, fb.y - 3);
      for (let k = 0; k < SMAX; k++) { ctx.beginPath(); ctx.arc(fb.x - 14 + k * 7, fb.y + 15, 2.4, 0, 7); ctx.fillStyle = k < ammo ? '#17131f' : 'rgba(23,19,31,.25)'; ctx.fill(); }
      // stick
      let q = null; for (const p of ptrs.values()) if (p.seat === s && p.kind === 'stick') q = p;
      const ax = q ? q.ax : 22 + STICK_R + 6, ay = q ? q.ay : h - STICK_R - 30;
      ctx.globalAlpha = (dead ? 0.3 : 1) * (q ? 0.95 : 0.55);
      ctx.beginPath(); ctx.arc(ax, ay, STICK_R, 0, 7); ctx.fillStyle = 'rgba(23,19,31,.55)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.stroke();
      let kx = ax, ky = ay;
      if (q) { const dx = q.x - q.ax, dy = q.y - q.ay, d = Math.hypot(dx, dy), mm = Math.min(d, STICK_R); if (d > 0) { kx = ax + dx / d * mm; ky = ay + dy / d * mm; } }
      ctx.beginPath(); ctx.arc(kx, ky, 20, 0, 7); ctx.fillStyle = hexA(col, 0.9); ctx.fill(); ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.stroke();
      if (!q) { ctx.font = '600 11px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.9)'; ctx.fillText('이동', ax, ay - STICK_R - 10); }
      ctx.globalAlpha = 1;
      ctx.restore();
      if (dead && st.ph === 'play') txt('격파됨 · 관전 중', w / 2, h - lay.bot + 22, '#ee6a55', '17px ' + DISP);
      void now;
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; startRound(); }
        if (st.ph === 'play' && phase === 'count' && !host()) { phase = 'play'; cd = 0; api.sfx('pop'); }
        if (W) W.over = st.ph === 'end' || st.ph === 'done';
        if (st.ph === 'end' && (!prev || prev.ph !== 'end')) {
          endT = END_T;
          if (st.rw >= 0 && isMine(st.rw)) { api.sfx('win'); api.buzz(60); } else api.sfx('chip');
        }
        syncChip();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        window.removeEventListener('blur', releaseAll);
        try { if (offInput) offInput(); } catch (e) {}
        chip.remove(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ W, st, phase, locIn, cfg, lay, ptrs, X, Y, pressFire, pressSpec, aiMem }),
    };
  }

  /* ---------- helpers ---------- */
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'tanks', name: '탱크 미로 대전', tag: '실시간 미로 포격전', cat: '아케이드',
    blurb: '미로 속 장난감 탱크 대결! 벽에 튕기는 포탄으로 상대를 맞히고 끝까지 살아남으면 라운드 승리. 친구와는 온라인·LAN 방으로.',
    tint: '#2e4a2c',
    icon: '<rect x="5" y="14" width="27" height="6" rx="3" fill="currentColor"/><rect x="5" y="36" width="27" height="6" rx="3" fill="currentColor"/><rect x="8" y="19" width="21" height="18" rx="4" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="18" cy="28" r="5" fill="currentColor"/><path d="M21 28h17" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M51 4v48" stroke="currentColor" stroke-width="4"/><path d="M40 28L48 18L40 8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-dasharray="3 3"/><circle cx="40" cy="8" r="2.8" fill="currentColor"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 3, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'rounds', label: '승리 조건', choices: [{ v: 3, label: '3승 먼저' }, { v: 5, label: '5승 먼저' }], def: 3 },
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '새 미로' }].concat(FIXED.map((f, i) => ({ v: i + 1, label: f.nm }))), def: -1 },
      { id: 'items', label: '아이템', choices: [{ v: 1, label: '켜기' }, { v: 0, label: '끄기' }], def: 1 },
    ],
    controls: [
      { id: 'up', label: '전진', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '후진', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 돌기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 돌기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'fire', label: '발사', keys: ['Space', 'KeyJ'], pad: ['a', 'rt'] },
      { id: 'special', label: '특수 무기', keys: ['KeyK', 'ShiftLeft', 'KeyE'], pad: ['b', 'x', 'lt'] },
    ],
    quick: [
      '미로 속 탱크 대결! 포탄 한 방이면 탱크가 부서져요.',
      '화면 왼쪽을 끌면 그쪽으로 달리고, 오른쪽을 누르면 발사. 포탄은 벽에 튕겨요 — 내 포탄에 나도 맞아요!',
      '마지막까지 살아남으면 라운드 승리. 3승(또는 5승)을 먼저 하면 우승.',
    ],
    rules: [
      { h: '목표', p: [
        '미로 속 장난감 탱크 대결이에요. 포탄 한 방이면 탱크가 부서져요.',
        '마지막까지 살아남은 탱크가 라운드 승리. 먼저 3승(또는 5승)한 사람이 우승이에요.',
      ] },
      { h: '조작 (터치)', p: [
        '이동: 화면 왼쪽 아무 데나 엄지를 대고 끌면 조이스틱이 생겨요. 미는 방향으로 탱크가 돌아서 달려가요. 살짝만 밀면 천천히 움직여요.',
        '탱크는 묵직해서 천천히 속도를 올리고, 손을 떼면 금방 멈춰요.',
        '발사: 화면 오른쪽 아무 데나 톡. 발사 버튼의 점이 남은 포탄 수예요.',
        '특수 무기: 동그란 「특수」 버튼. 주운 특수 무기를 써요.',
        '점선 조준선은 포탄이 처음 튕기는 곳까지 보여 줘요. 오른쪽 위 「조준선」 칩으로 켜고 꺼요(이 폰에 기억돼요).',
        'PC 키보드·게임패드: ↑↓(W·S) 전진·후진, ←→(A·D) 돌기, 스페이스·J·Ⓐ 발사, K·Shift·E·Ⓑ 특수 무기. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '승리 · 라운드', p: [
        '마지막 남은 탱크도 0.3초 안에 같이 부서지면 무승부 라운드(점수 없음).',
        '라운드가 100초를 넘기면 무승부로 끝나요.',
        '점수는 라운드 승리 수뿐이에요. 몇 대를 부쉈는지는 세지 않아요.',
      ] },
      { h: '포탄', p: [
        '포탄은 벽에 여러 번 튕기다가 6초 뒤 사라져요. 탱크보다 두 배쯤 빨라서, 멀리서 날아오는 건 보고 피할 수 있어요.',
        '내 포탄에 나도 맞아요! 튕겨 돌아오는 포탄을 조심하세요.',
        '한 탱크가 한꺼번에 쏠 수 있는 포탄은 5발이에요. 쏜 포탄이 사라지면 다시 쏠 수 있어요.',
      ] },
      { h: '아이템 5종', p: [
        '아이템을 켜면 약 7초마다 미로에 상자가 나타나요(한 번에 2개까지). 지나가면 주워요.',
        '특수 무기는 하나만 들 수 있어요. 들고 있으면 다른 무기 상자는 안 주워져요(방패는 언제나 주워져요).',
        '「레」 레이저: 벽에 6번까지 튕기는 광선을 바로 쏴요. 들고 있는 동안 빨간 조준선이 모두에게 보여요.',
        '「산」 산탄: 작은 포탄 7발을 부채꼴로 흩뿌려요. 멀리는 못 가요.',
        '「유」 유도탄: 잠깐 곧게 날아간 뒤 미로 길을 따라 가장 가까운 상대를 쫓아가요. 10초 뒤 사라져요.',
        '「지」 지뢰: 탱크 뒤에 놓아요. 1초 뒤 빨간 불이 깜빡이며 켜지고, 탱크가 밟으면 터져요. 내가 멀어진 뒤엔 나도 터져요. 포탄으로 맞혀 터뜨릴 수도 있어요.',
        '「방」 방패: 주우면 바로 켜져서 8초 동안 한 번 막아 줘요.',
      ] },
      { h: '맵', p: [
        '새 미로: 라운드마다 새로 만든 미로예요. 출발 자리끼리 공평하도록 대칭으로 만들어요.',
        '고정 맵: 기둥 광장(탁 트임), 쌍둥이 복도(긴 벽 세 갈래), 네 개의 방(방과 복도), 요새(가운데 요새).',
        '무작위(기본): 라운드마다 새 미로나 고정 맵 중 하나가 나와요.',
        '출발 자리는 네 모서리이고, 라운드마다 돌아가며 바뀌어요.',
      ] },
      { h: '팁', p: [
        '벽 모서리 뒤에서 벽에 한 번 튕겨 쏘면 숨은 상대도 맞힐 수 있어요. 조준선으로 튕기는 곳을 확인해요.',
        '좁은 복도에서 앞벽에 바로 쏘면 포탄이 나에게 되돌아와요!',
        '5발을 한꺼번에 다 쏘면 한동안 못 쏴요. 한두 발은 아껴 두세요.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 조종해요. 혼자 하면 나머지 자리는 AI 탱크예요.',
        '친구와는 온라인·LAN 방으로 각자 폰에서 한 대씩. 포탄과 명중 판정은 호스트 폰이 계산해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움: 쉬움은 돌아다니며 대충 쏘고, 보통은 길을 찾아와 한 번 튕기는 샷도 쓰고, 어려움은 두세 번 튕기는 샷을 계산하고 날아오는 포탄을 피해요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { FIXED, PU, PU_KEYS, genMaze, buildFixed, newWorld, stepWorld, stepTank, stepShells, fire, special, aiThink, maybePowerup, bfs, nextCell, cellIdx, cellXY, traceRay, cast, shellsOf, insideWall, roundOver, nextRound, pickMap, laserPath, H, CS, TR, SR, SMAX, CAP_T, LAST_T },
  });
})();
