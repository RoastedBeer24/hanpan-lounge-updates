/* 케이크 데코 대결 — 주문서대로 케이크를 꾸미는 정밀·창작 대결 (라운드제, 모두 동시에).
   라운드마다 모두 같은 손님 주문서를 받고, 제한 시간 안에 각자 케이크(시트 색 · 테두리/가운데 원 크림 · 토핑 · 가루 · 글씨판)를
   꾸며 「완성」. 모두 내면 심사: 주문과 얼마나 같은지(개수·색·자리·고른 간격) − 깔끔함 감점 + 균형·빠름 보너스.
   케이크는 짧은 문자열로 상태에 담겨요 (enc/dec):
     [0]시트 [1]깍지 [2]가루 [3]글씨('-'|0-7) [4,5]글씨판 x,y  [6..29]테두리 24칸 [30..53]가운데 원 24칸  [54..]토핑 3글자씩(종류,x,y)
   State: { n, nm[], R, tm, r, sd, ph 'd'|'j'|'end', o (주문|null), ck[] (낸 케이크|null), tt[] (걸린 초), rd[] (다음 준비),
            sc[] (합계), rs[[라운드 점수]], last {id, r, o, ck[], tt[], s[]} (심사 공개용), seq, t0 (호스트 시계, AI 타이밍) } */
(function () {
  const L = window.Lounge, U = L.util;

  /* ======================= 재료 ======================= */
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const NS = 24, MAXT = 30, SQ = 0.6, PLAIN = 6, TS = 1.2;   // TS = 토핑 그림 배율
  const SHEETS = [
    { n: '바닐라', c: '#f6e6c4' }, { n: '딸기', c: '#f7b2c4' }, { n: '초코', c: '#7a4a32' },
    { n: '녹차', c: '#b4d388' }, { n: '블루베리', c: '#b6a2e2' }, { n: '레몬', c: '#f7dc6c' },
  ];
  const CREAMS = [
    { n: '생크림', c: '#fffaf0' }, { n: '분홍', c: '#ff9cbd' }, { n: '초코', c: '#5f3624' },
    { n: '민트', c: '#93e0c3' }, { n: '노랑', c: '#ffd45a' }, { n: '보라', c: '#c29bff' },
  ];
  const TIPS = [{ n: '별 깍지' }, { n: '동글 깍지' }, { n: '물결 깍지' }];
  const SPR = [{ n: '없음', sn: '없음' }, { n: '무지개 스프링클', sn: '무지개' }, { n: '초코 스프링클', sn: '초코 가루' }, { n: '슈가 파우더', sn: '슈가' }];
  // s = 크기(케이크 반지름 기준), hc = 누르기 중심 높이(크기 배수)
  const TOPS = [
    { n: '딸기', s: 0.085, hc: 0.75 }, { n: '블루베리', s: 0.05, hc: 0.8 }, { n: '체리', s: 0.068, hc: 0.9 },
    { n: '키위', s: 0.085, hc: 0.35 }, { n: '귤 조각', s: 0.08, hc: 0.5 }, { n: '바나나', s: 0.072, hc: 0.3 },
    { n: '초콜릿', s: 0.075, hc: 0.8 }, { n: '마카롱', s: 0.085, hc: 0.65 }, { n: '쿠키', s: 0.088, hc: 0.35 },
    { n: '하트 초콜릿', s: 0.072, hc: 0.9 }, { n: '별 사탕', s: 0.072, hc: 0.85 }, { n: '민트 잎', s: 0.07, hc: 0.4 },
    { n: '설탕 꽃', s: 0.08, hc: 0.4 }, { n: '진주 구슬', s: 0.042, hc: 0.8 }, { n: '머랭', s: 0.07, hc: 0.9 },
    { n: '곰 젤리', s: 0.068, hc: 1.0 }, { n: '초', s: 0.05, hc: 2.2 },
  ];
  const TSN = ['딸기', '블루베리', '체리', '키위', '귤', '바나나', '초콜릿', '마카롱', '쿠키', '하트', '별사탕', '민트', '꽃', '진주', '머랭', '곰젤리', '초'];
  const T = { ST: 0, BB: 1, CH: 2, KW: 3, OR: 4, BA: 5, CC: 6, MC: 7, CK: 8, HT: 9, SR: 10, MT: 11, FL: 12, PL: 13, MR: 14, GB: 15, CD: 16 };
  const WORDS = ['생일 축하해', '사랑해', '고마워요', '축하해요', '힘내!', '최고야', '합격 축하', '행복해'];
  const ZN = ['아무 데나', '가운데', '중간', '바깥'];
  const ZW = ['아무 데나', '가운데에', '중간 고리에', '바깥 고리에'];
  const SNAP_R = [0.45, 0, 0.45, 0.78];
  const RING_R = { ro: 0.9, ri: 0.31 };
  const CUST = ['토끼 손님', '곰 아저씨', '고양이 아가씨', '다람쥐 꼬마', '여우 신사', '펭귄 가족', '부엉이 할머니', '강아지 형제', '판다 선생님', '오리 남매'];
  const BASE_T = [60, 72, 85, 100, 115];
  const jo = (w, a, b) => { const c = w.charCodeAt(w.length - 1); return w + (c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b); };
  const pw = (k) => 0.16 + 0.1 * WORDS[k].length;   // 글씨판 너비(케이크 반지름 기준)
  const PH = 0.12;                                     // 글씨판 반높이(v 단위)

  /* ======================= 난수 ======================= */
  function rng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const hash = (...xs) => { let h = 2166136261; xs.forEach((x) => { h ^= (x | 0) & 0xffff; h = Math.imul(h, 16777619); h ^= (x >>> 16) & 0xffff; h = Math.imul(h, 16777619); }); return h >>> 0; };

  /* ======================= 케이크 문자열 ======================= */
  function blank() { return { s: PLAIN, tp: 0, sp: 0, w: -1, wx: 0, wy: 0.14, ro: Array(NS).fill(-1), ri: Array(NS).fill(-1), it: [] }; }
  const qz = (v) => Math.max(0, Math.min(63, Math.round((v + 1) * 31.5)));
  const dq = (ch) => B64.indexOf(ch) / 31.5 - 1;
  const qv = (v) => dq(B64[qz(v)]);
  function enc(c) {
    let s = '' + c.s + c.tp + c.sp + (c.w < 0 ? '-' : c.w) + B64[qz(c.wx)] + B64[qz(c.wy)];
    for (let i = 0; i < NS; i++) s += c.ro[i] < 0 ? '.' : c.ro[i];
    for (let i = 0; i < NS; i++) s += c.ri[i] < 0 ? '.' : c.ri[i];
    for (const t of c.it) s += B64[t[0]] + B64[qz(t[1])] + B64[qz(t[2])];
    return s;
  }
  const RE = /^[0-6][0-2][0-3][-0-7][A-Za-z0-9_-]{2}[.0-5]{48}([A-Za-z0-9_-]{3})*$/;
  function valid(str) {
    if (typeof str !== 'string' || str.length < 54 || str.length > 54 + 3 * MAXT || !RE.test(str)) return false;
    for (let i = 54; i < str.length; i += 3) if (B64.indexOf(str[i]) >= TOPS.length) return false;
    return true;
  }
  function dec(str) {
    const c = blank();
    if (!valid(str)) return c;
    c.s = +str[0]; c.tp = +str[1]; c.sp = +str[2]; c.w = str[3] === '-' ? -1 : +str[3]; c.wx = dq(str[4]); c.wy = dq(str[5]);
    for (let i = 0; i < NS; i++) { const a = str[6 + i], b = str[30 + i]; c.ro[i] = a === '.' ? -1 : +a; c.ri[i] = b === '.' ? -1 : +b; }
    for (let i = 54; i < str.length; i += 3) c.it.push([B64.indexOf(str[i]), dq(str[i + 1]), dq(str[i + 2])]);
    return c;
  }

  /* ======================= 주문서 ======================= */
  // o = { tp 템플릿, cu 손님, s 시트, ro null|[무늬 0단색/1번갈아/2반반, 색1, 색2], ri -1|색, tip -1|깍지, it [[종류, 개수, 자리(0아무/1가운데/2중간/3바깥), 고르게]], sp, w, tl 초, d }
  const TPL = [
    { n: '딸기 생크림 케이크', f(o, d, ri, pk) { o.s = pk([0, 1]); o.ro = [0, 0, 1]; o.it.push([T.ST, ri(3, 4) + (d >> 1), 3, 1], [T.CD, d >= 1 ? ri(1, 3) : 1, 1, 0]); } },
    { n: '진한 초코 케이크', f(o, d, ri, pk) { o.s = 2; o.ro = [0, pk([2, 0]), 1]; o.it.push([T.CC, ri(3, 4) + (d >> 1), 3, 1], [T.CH, 1, 1, 0]); if (d >= 2) o.sp = 2; } },
    { n: '과일 타르트 케이크', f(o, d, ri, pk) { o.s = pk([0, 5]); o.it.push([T.KW, ri(4, 6), 3, 1], [T.OR, ri(3, 4) + (d >> 1), 2, d >= 1 ? 1 : 0]); if (d >= 1) o.it.push([T.BB, ri(1, 3), 1, 0]); } },
    { n: '생일 축하 케이크', f(o, d, ri, pk) { o.s = ri(0, 5); o.ro = [0, ri(0, 5), 0]; o.it.push([T.CD, ri(1, 3) + (d >> 1), 1, 0], [pk([T.ST, T.HT]), ri(4, 6), 3, 1]); if (d >= 1) o.w = 0; } },
    { n: '꽃밭 케이크', f(o, d, ri, pk) { o.s = pk([3, 1]); o.it.push([T.FL, ri(4, 6), 3, 1], [T.MT, ri(3, 5), 2, d >= 2 ? 1 : 0]); if (d >= 1) { o.ri = pk([4, 0]); o.ro = [0, 0, 1]; } } },
    { n: '마카롱 탑 케이크', f(o, d, ri, pk) { o.s = pk([4, 1]); o.ro = [0, 1, 0]; o.it.push([T.MC, ri(3, 5), 3, 1], [T.PL, ri(4, 6) + (d >> 1), 2, 0]); } },
    { n: '곰돌이 파티 케이크', f(o, d, ri, pk) { o.s = ri(0, 5); o.sp = 1; o.ro = [0, ri(0, 5), 0]; o.it.push([T.GB, ri(3, 6), 3, 1], [T.SR, ri(2, 4), 2, 0]); } },
    { n: '하트 뿅뿅 케이크', f(o, d, ri, pk) { o.s = 1; o.ro = d >= 2 ? [1, 1, 0] : [0, 1, 0]; o.it.push([T.HT, ri(4, 6), 2, 1]); if (d >= 2) o.w = 1; if (d >= 3) o.it.push([T.PL, ri(3, 6), 3, 0]); } },
    { n: '쿠키 앤 크림 케이크', f(o, d, ri, pk) { o.s = pk([2, 0]); o.ro = [0, 0, 2]; o.it.push([T.CK, ri(3, 5), 3, 1], [T.MR, ri(1, 3), 1, 0]); if (d >= 1) o.sp = 2; } },
    { n: '레몬 머랭 케이크', f(o, d, ri, pk) { o.s = 5; o.ri = 4; o.it.push([T.MR, ri(4, 6), 3, 1], [T.OR, ri(2, 4), 2, d >= 2 ? 1 : 0]); if (d >= 1) o.ro = [0, 0, 4]; } },
    { n: '숲속 베리 케이크', f(o, d, ri, pk) { o.s = 3; o.ro = d >= 3 ? [2, 2, 3] : [0, 2, 3]; o.it.push([T.MT, ri(3, 5), 2, 0], [T.BB, ri(5, 8), 3, 1], [T.CH, 1, 1, 0]); } },
    { n: '별밤 케이크', f(o, d, ri, pk) { o.s = 4; o.ro = [0, 5, 0]; o.sp = 3; o.it.push([T.SR, ri(4, 6), 3, 1], [T.PL, ri(3, 6), 2, 0]); if (d >= 2) o.it.push([T.CD, 1, 1, 0]); } },
    { n: '바나나 초코 케이크', f(o, d, ri, pk) { o.s = 2; o.ro = [0, 4, 0]; o.it.push([T.BA, ri(4, 6), 3, 1], [T.CC, ri(1, 2), 1, 0]); if (d >= 2) o.w = pk([3, 5]); } },
    { n: '합격 축하 케이크', f(o, d, ri, pk) { o.s = ri(0, 5); o.w = 6; o.ro = [0, ri(0, 5), 0]; o.it.push([T.SR, ri(3, 5), 3, 1], [T.FL, ri(2, 3), 2, 0]); } },
  ];
  function tplOrder(sd) {
    const r = rng(sd ^ 0x9e3779b9), a = TPL.map((_, i) => i);
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }
  const diffOf = (r, R) => (R <= 1 ? 1 : Math.round((r * 4) / (R - 1)));
  function genOrder(sd, r, R, tm) {
    const rnd = rng((sd + r * 7919 + 13) >>> 0);
    const ri = (a, b) => a + Math.floor(rnd() * (b - a + 1));
    const pk = (arr) => arr[Math.floor(rnd() * arr.length)];
    const d = diffOf(r, R), tp = tplOrder(sd)[r % TPL.length];
    const o = { tp, cu: ri(0, CUST.length - 1), s: 0, ro: null, ri: -1, tip: -1, it: [], sp: 0, w: -1, tl: 60, d };
    TPL[tp].f(o, d, ri, pk, rnd);
    if (!o.ro && o.ri < 0 && d >= 1 && rnd() < 0.5) o.ro = [0, ri(0, 5), 0];
    if (o.ro && o.ro[0] === 0 && d >= 2 && rnd() < 0.45) { let c2 = ri(0, 5); if (c2 === o.ro[1]) c2 = (c2 + 1 + ri(0, 4)) % 6; o.ro = [rnd() < 0.55 ? 1 : 2, o.ro[1], c2]; }
    if (o.ro && o.ro[0] && o.ro[1] === o.ro[2]) o.ro[2] = (o.ro[1] + 1) % 6;
    if (o.ri < 0 && d >= 2 && rnd() < 0.35) o.ri = ri(0, 5);
    if ((o.ro || o.ri >= 0) && d >= 1 && rnd() < 0.3 + 0.12 * d) o.tip = ri(0, 2);
    if (o.w < 0 && d >= 3 && rnd() < 0.4) o.w = ri(0, WORDS.length - 1);
    if (o.sp === 0 && d >= 3 && rnd() < 0.3) o.sp = ri(1, 3);
    if (d >= 4 && o.it.length < 3 && rnd() < 0.65) {
      const have = o.it.map((x) => x[0]), pool = [T.BB, T.PL, T.SR, T.HT, T.FL, T.MT, T.CH, T.MR].filter((k) => !have.includes(k));
      o.it.push([pk(pool), ri(2, 3), rnd() < 0.5 ? 2 : 0, 0]);
    }
    // 개수 상한(가운데 6개, 전체 20개)
    let cen = 0, tot = 0;
    o.it.forEach((x) => { if (x[2] === 1) { x[1] = Math.max(1, Math.min(x[1], 6 - cen)); cen += x[1]; } x[1] = Math.min(x[1], 8); tot += x[1]; });
    while (tot > 20) { const x = o.it.reduce((a, b) => (b[1] > a[1] ? b : a)); x[1]--; tot--; }
    o.tl = Math.max(30, Math.round((BASE_T[d] * tm) / 5) * 5);
    return o;
  }

  /* ======================= 모범 답안(심사 견본 · AI 바탕) ======================= */
  function idealItems(o) {
    const out = [], cen = [], rings = { 2: [], 3: [] };
    o.it.forEach(([k, n, z]) => { if (z === 1) for (let i = 0; i < n; i++) cen.push(k); else rings[z === 0 ? 2 : z].push([k, n]); });
    if (cen.length === 1 && o.w < 0) out.push([cen[0], 0, 0]);
    else if (o.w >= 0) cen.forEach((k, i) => out.push([k, (i - (cen.length - 1) / 2) * 0.1, -0.14]));
    else cen.forEach((k, i) => { const a = -Math.PI / 2 + (i * 2 * Math.PI) / cen.length; out.push([k, Math.cos(a) * 0.14, Math.sin(a) * 0.14]); });
    [2, 3].forEach((z) => {
      const R = SNAP_R[z], taken = [];
      rings[z].forEach(([k, n], gi) => {
        const step = (2 * Math.PI) / n;
        let off = -Math.PI / 2;
        if (gi > 0) {
          let best = -1;
          for (let j = 0; j < 24; j++) {
            const of = -Math.PI / 2 + (step * (j + 0.5)) / 24;
            let md = 9;
            for (let i = 0; i < n; i++) for (const t of taken) { let dd = Math.abs(((of + i * step - t) % (2 * Math.PI) + 3 * Math.PI) % (2 * Math.PI) - Math.PI); md = Math.min(md, dd); }
            if (md > best) { best = md; off = of; }
          }
        }
        for (let i = 0; i < n; i++) { const a = off + i * step; taken.push(a); out.push([k, Math.cos(a) * R, Math.sin(a) * R]); }
      });
    });
    return out.map(([k, u, v]) => [k, qv(u), qv(v)]);
  }
  function ringTarget(ro) {
    const t = [];
    for (let i = 0; i < NS; i++) t.push(ro[0] === 0 ? ro[1] : ro[0] === 1 ? (Math.floor(i / 3) % 2 ? ro[2] : ro[1]) : i < 12 ? ro[1] : ro[2]);
    return t;
  }
  function idealCake(o) {
    const c = blank();
    c.s = o.s; c.tp = o.tip >= 0 ? o.tip : 0; c.sp = o.sp;
    if (o.ro) c.ro = ringTarget(o.ro);
    if (o.ri >= 0) c.ri = Array(NS).fill(o.ri);
    if (o.w >= 0) { c.w = o.w; c.wx = qv(0); c.wy = qv(0.14); }
    c.it = idealItems(o);
    return c;
  }

  /* ======================= 심사 ======================= */
  const zoneOf = (u, v) => { const r = Math.hypot(u, v); return r < 0.27 ? 1 : r < 0.62 ? 2 : 3; };
  function ringMatch(arr, tg) {
    let best = 0;
    for (let r = 0; r < NS; r++) { let k = 0; for (let i = 0; i < NS; i++) if (arr[(i + r) % NS] === tg[i]) k++; if (k > best) best = k; }
    return best / NS;
  }
  function evenness(its) {
    const a = its.map((i) => Math.atan2(i[2], i[1])).sort((x, y) => x - y), m = a.length, ideal = (2 * Math.PI) / m;
    let dev = 0;
    for (let i = 0; i < m; i++) { const g = i === m - 1 ? a[0] + 2 * Math.PI - a[i] : a[i + 1] - a[i]; dev += Math.abs(g - ideal); }
    dev /= 2 * Math.PI;
    return Math.max(0, Math.min(1, 1 - Math.max(0, dev - 0.08) * 1.8));
  }
  function judge(o, c, t, tl) {
    let W = 0, E = 0, pen = 0;
    const lw = [], lp = [];
    const part = (w, got, txt) => { W += w; E += got; if (w - got > 0.01 && txt) lw.push([w - got, txt]); };
    part(15, c.s === o.s ? 15 : 0, c.s === PLAIN ? '시트에 크림을 안 발랐어요' : '시트 색이 「' + SHEETS[o.s].n + '」가 아니에요');
    const ringPart = (req, arr, w, nmR) => {
      const filled = arr.filter((x) => x >= 0).length;
      if (req) {
        const f = ringMatch(arr, req);
        part(w, w * f, filled < 3 ? nmR + ' 크림을 깜빡했어요' : filled >= 22 ? nmR + (o.ro && req.length && arr === c.ro && o.ro[0] ? ' 무늬가 주문과 달라요' : ' 크림 색이 달라요') : nmR + ' 크림이 군데군데 비었어요');
      } else if (filled) { const p = (filled / NS) * (w === 15 ? 8 : 6); pen += p; lp.push([p, nmR + ' 크림은 주문에 없었어요']); }
    };
    ringPart(o.ro ? ringTarget(o.ro) : null, c.ro, 15, '테두리');
    ringPart(o.ri >= 0 ? Array(NS).fill(o.ri) : null, c.ri, 10, '가운데 원');
    if (o.tip >= 0) part(5, c.tp === o.tip ? 5 : 0, '깍지가 「' + TIPS[o.tip].n + '」가 아니에요');
    const cnt = Array(TOPS.length).fill(0);
    c.it.forEach((i) => cnt[i[0]]++);
    const req = new Set();
    o.it.forEach(([k, n, z, ev]) => {
      req.add(k);
      const nm = TOPS[k].n, have = cnt[k];
      const its = c.it.filter((i) => i[0] === k);
      const inz = z === 0 ? its : its.filter((i) => zoneOf(i[1], i[2]) === z);
      part(6, 6 * Math.max(0, 1 - Math.abs(have - n) / n), have < n ? jo(nm, '이', '가') + ' ' + (n - have) + '개 모자라요' : jo(nm, '이', '가') + ' ' + (have - n) + '개 많아요');
      part(6, (6 * Math.min(inz.length, n)) / n, have ? jo(nm, '은', '는') + ' ' + ZW[z] + ' 올려 달랬어요' : null);
      if (ev && n >= 2) part(5, inz.length >= 2 ? (5 * evenness(inz) * Math.min(inz.length, n)) / n : 0, inz.length >= 2 ? nm + ' 간격이 들쭉날쭉해요' : null);
    });
    let ex = 0, exk = -1;
    cnt.forEach((v, k) => { if (v && !req.has(k)) { ex += v; if (exk < 0) exk = k; } });
    if (ex) { const p = Math.min(16, ex * 2.5); pen += p; lp.push([p, '주문에 없는 ' + jo(TOPS[exk].n, '이', '가') + ' 있어요']); }
    if (o.sp) part(6, c.sp === o.sp ? 6 : c.sp ? 2 : 0, c.sp ? '뿌린 가루가 주문과 달라요' : jo(SPR[o.sp].n, '을', '를') + ' 깜빡했어요');
    else if (c.sp) { pen += 4; lp.push([4, '가루는 주문에 없었어요']); }
    if (o.w >= 0) {
      const near = c.w >= 0 && Math.hypot(c.wx, c.wy) < 0.45;
      part(10, (c.w === o.w ? 7 : c.w >= 0 ? 2 : 0) + (near ? 3 : 0), c.w < 0 ? '글씨판이 빠졌어요' : c.w !== o.w ? '글씨가 「' + WORDS[o.w] + '」가 아니에요' : '글씨판은 가운데쯤 놓아 주세요');
    } else if (c.w >= 0) { pen += 3; lp.push([3, '글씨판은 주문에 없었어요']); }
    let ov = 0;
    for (let i = 0; i < c.it.length; i++) {
      const A = c.it[i];
      for (let j = i + 1; j < c.it.length; j++) { const B = c.it[j]; if (Math.hypot(A[1] - B[1], A[2] - B[2]) < (TOPS[A[0]].s + TOPS[B[0]].s) * 0.6) ov++; }
      if (c.w >= 0 && Math.abs(A[1] - c.wx) < pw(c.w) / 2 && Math.abs(A[2] - c.wy) < PH) ov++;
    }
    if (ov) { const p = Math.min(9, ov * 1.5); pen += p; lp.push([p, '토핑이 서로 겹쳐서 지저분해요']); }
    let sym = 0;
    if (c.it.length >= 3) { let mx = 0, my = 0; c.it.forEach((i) => { mx += i[1]; my += i[2]; }); if (Math.hypot(mx / c.it.length, my / c.it.length) < 0.07) sym = 3; }
    const acc = W ? (E / W) * 100 : 100;
    const base = Math.max(0, Math.min(100, acc - pen));
    const tb = base >= 60 ? Math.max(0, Math.min(4, Math.floor(5 * (1 - (t || 0) / (tl || 60))))) : 0;
    const loss = lw.map(([w, s]) => [(w * 100) / W, s]).concat(lp).sort((a, b) => b[0] - a[0]);
    return { sc: Math.round(base + sym + tb), acc: Math.round(acc), pen: Math.round(pen), sym, tb, loss };
  }
  const GREAT = ['손님이 사진부터 찍었어요', '주문서를 그대로 옮긴 것 같아요', '진열장에 두고 싶은 케이크예요', '손님이 감동해서 울컥했대요', '이대로 가게 간판 해도 돼요'];
  function comment(det, salt) {
    const sc = det.sc, top = det.loss[0];
    const mood = sc >= 97 ? '완벽해요!' : sc >= 88 ? '거의 완벽!' : sc >= 75 ? '맛있어 보여요' : sc >= 55 ? '조금 아쉬워요' : '음… 주문서 보셨나요?';
    const sub = !top || top[0] < 1.5 || sc >= 97 ? GREAT[salt % GREAT.length] : top[1];
    return [mood, sub];
  }

  /* ======================= 규칙 ======================= */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, R = opts.rounds === 5 ? 5 : 3;
    const tm = opts.time === 'long' ? 1.4 : opts.time === 'short' ? 0.75 : 1;
    const sd = Math.floor(Math.random() * 1e9);
    return {
      n, nm: players.map((p, i) => String(p.name || i + 1 + '번').slice(0, 10)), R, tm, r: 0, sd, ph: 'd',
      o: genOrder(sd, 0, R, tm), ck: Array(n).fill(null), tt: Array(n).fill(0), rd: Array(n).fill(0),
      sc: Array(n).fill(0), rs: [], last: null, seq: 0, t0: Date.now(),
    };
  }
  // 고를 때는 모두가 actor (core의 한 명용 가림막이 뜨지 않게) — 이미 낸 자리는 apply에서 거절
  function actor(s) { if (s.ph === 'end') return null; const a = []; for (let i = 0; i < s.n; i++) a.push(i); return a; }
  function finishRound(s) {
    const o = s.o, rsc = [];
    for (let i = 0; i < s.n; i++) { const d = judge(o, dec(s.ck[i]), s.tt[i], o.tl); rsc.push(d.sc); s.sc[i] += d.sc; }
    s.rs.push(rsc);
    s.last = { id: ++s.seq, r: s.r, o, ck: s.ck, tt: s.tt, s: rsc };
    s.ph = 'j'; s.o = null; s.ck = Array(s.n).fill(null); s.tt = Array(s.n).fill(0); s.rd = Array(s.n).fill(0); s.t0 = Date.now();
  }
  function advance(s) {
    if (s.r + 1 >= s.R) { s.ph = 'end'; return; }
    s.r++; s.o = genOrder(s.sd, s.r, s.R, s.tm); s.ph = 'd'; s.last = null;
    s.ck = Array(s.n).fill(null); s.tt = Array(s.n).fill(0); s.rd = Array(s.n).fill(0); s.t0 = Date.now();
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object' || seat < 0 || seat >= s.n) throw new Error('bad action');
    if (a.k === 'c') {
      if (s.ph !== 'd' || s.ck[seat] != null) throw new Error('not now');
      if (!valid(a.c)) throw new Error('bad cake');
      s.ck[seat] = a.c; s.tt[seat] = Math.max(0, Math.min(s.o.tl, Math.round(+a.t || 0)));
      if (s.ck.every((x) => x != null)) finishRound(s);
      return s;
    }
    if (a.k === 'n') {
      if (s.ph !== 'j' || s.rd[seat]) throw new Error('not now');
      s.rd[seat] = 1;
      if (s.rd.every((x) => x)) advance(s);
      return s;
    }
    throw new Error('unknown action');
  }
  const STARS = [60, 78, 92];
  function result(s) {
    if (!s || s.ph !== 'end') return null;
    const nm = (i) => s.nm[i] || i + 1 + '번';
    const per = (i) => s.rs.map((r) => r[i]).join(' · ');
    if (s.n === 1) {
      const avg = s.sc[0] / s.R, st = STARS.filter((v) => avg >= v).length;
      return { winners: st ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요',
        text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  평균 ' + Math.round(avg) + '점 (합계 ' + s.sc[0] + ')\n라운드 점수: ' + per(0) + '\n별 기준(평균) ' + STARS.join(' / ') + '점' };
    }
    const ord = s.sc.map((_, i) => i).sort((a, b) => s.sc[b] - s.sc[a] || a - b);
    const top = s.sc[ord[0]], winners = ord.filter((i) => s.sc[i] === top);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승',
      text: ord.map((i) => (s.sc.filter((v) => v > s.sc[i]).length + 1) + '위  ' + nm(i) + '  ' + s.sc[i] + '점  (' + per(i) + ')').join('\n') };
  }

  /* ======================= AI ======================= */
  const AIP = {
    1: { sheet: 0.2, tip: 0.5, gap: 0.85, gapMax: 7, pat: 0.6, cnt: 0.5, jit: 18, rj: 0.07, zone: 0.14, extra: 0.45, spMiss: 0.35, wMiss: 0.2, wWrong: 0.3 },
    2: { sheet: 0.08, tip: 0.3, gap: 0.65, gapMax: 5, pat: 0.35, cnt: 0.28, jit: 10, rj: 0.045, zone: 0.07, extra: 0.2, spMiss: 0.12, wMiss: 0.06, wWrong: 0.1 },
    3: { sheet: 0.01, tip: 0.08, gap: 0.25, gapMax: 2, pat: 0.08, cnt: 0.07, jit: 4, rj: 0.02, zone: 0.015, extra: 0.05, spMiss: 0.04, wMiss: 0.01, wWrong: 0.04 },
  };
  function aiCake(o, lv, rnd) {
    const P = AIP[lv] || AIP[2];
    const ri = (a, b) => a + Math.floor(rnd() * (b - a + 1));
    const c = blank();
    c.s = rnd() < P.sheet ? (o.s + ri(1, 5)) % 6 : o.s;
    c.tp = o.tip >= 0 ? (rnd() < P.tip ? (o.tip + ri(1, 2)) % 3 : o.tip) : ri(0, 2);
    const ring = (tg) => {
      const a = tg.slice();
      if (rnd() < P.gap) { const n = ri(1, P.gapMax), s0 = ri(0, NS - 1); for (let i = 0; i < n; i++) a[(s0 + i) % NS] = -1; }
      const rot = ri(0, NS - 1);
      return a.map((_, i) => a[(i + rot) % NS]);
    };
    if (o.ro) { const tg = ringTarget(o.ro); if (o.ro[0] && rnd() < P.pat) { const s0 = ri(0, NS - 1); for (let i = 0; i < 3; i++) tg[(s0 + i) % NS] = tg[(s0 + i + 3) % NS]; } c.ro = ring(tg); }
    if (o.ri >= 0) c.ri = ring(Array(NS).fill(o.ri));
    let items = idealItems(o);
    o.it.forEach(([k, n, z]) => {
      if (rnd() >= P.cnt) return;
      if (rnd() < 0.5 && n > 1) { for (let i = items.length - 1; i >= 0; i--) if (items[i][0] === k) { items.splice(i, 1); break; } }
      else { const a = rnd() * 2 * Math.PI, r = z === 1 ? 0.12 : SNAP_R[z]; items.push([k, Math.cos(a) * r, Math.sin(a) * r]); }
    });
    items = items.map(([k, u, v]) => {
      let r = Math.hypot(u, v), a = Math.atan2(v, u);
      if (r > 0.3) {
        a += (rnd() * 2 - 1) * P.jit * Math.PI / 180; r += (rnd() * 2 - 1) * P.rj;
        if (rnd() < P.zone) r = r > 0.6 ? 0.45 : 0.78;
        return [k, Math.cos(a) * r, Math.sin(a) * r];
      }
      if (rnd() < P.zone) { const b = rnd() * 2 * Math.PI; return [k, Math.cos(b) * 0.45, Math.sin(b) * 0.45]; }
      return [k, u + (rnd() * 2 - 1) * P.rj, v + (rnd() * 2 - 1) * P.rj];
    });
    if (rnd() < P.extra) {
      const have = o.it.map((x) => x[0]), pool = TOPS.map((_, k) => k).filter((k) => !have.includes(k));
      const a = rnd() * 2 * Math.PI;
      items.push([pool[ri(0, pool.length - 1)], Math.cos(a) * 0.45, Math.sin(a) * 0.45]);
    }
    c.it = items.slice(0, MAXT).map(([k, u, v]) => [k, qv(u), qv(v)]);
    c.sp = o.sp ? (rnd() < P.spMiss ? 0 : o.sp) : 0;
    if (o.w >= 0 && rnd() >= P.wMiss) { c.w = rnd() < P.wWrong ? (o.w + ri(1, WORDS.length - 1)) % WORDS.length : o.w; c.wx = qv(0); c.wy = qv(0.14); }
    return c;
  }
  function aiFrac(s, seat, lv) {
    const u = rng(hash(s.sd, s.r, seat, 77))();
    return lv >= 3 ? 0.45 + 0.15 * u : lv <= 1 ? 0.78 + 0.18 * u : 0.6 + 0.2 * u;
  }
  const revealMs = (n) => 5200 + 800 * n;
  function aiDelayFor(s, seat, lv) {
    const sp = (L.debug && L.debug.speed) || 1;
    const el = Math.max(0, Date.now() - (s.t0 || 0)) * sp;
    if (s.ph === 'd') { if (s.ck[seat] != null) return -1; return Math.max(250, aiFrac(s, seat, lv || 2) * s.o.tl * 1000 + 1500 - el); }
    if (s.ph === 'j') { if (s.rd[seat]) return -1; return Math.max(250, revealMs(s.n) - el); }
    return -1;
  }
  function ai(s, seat, lv) {
    if (s.ph === 'j') return s.rd[seat] ? null : { k: 'n' };
    if (s.ph !== 'd' || s.ck[seat] != null) return null;
    const l = lv || 2;
    return { k: 'c', c: enc(aiCake(s.o, l, Math.random)), t: Math.round(aiFrac(s, seat, l) * s.o.tl) };
  }

  /* ======================= 그리기 도구 ======================= */
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  function rr(g, x, y, w, hh, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + hh, r); g.arcTo(x + w, y + hh, x, y + hh, r); g.arcTo(x, y + hh, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  const FONT = '"IBM Plex Sans KR", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif';
  const DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const MONO = '"IBM Plex Mono", ui-monospace, monospace';
  function ell(g, x, y, a, b, fill) { g.beginPath(); g.ellipse(x, y, Math.max(0.1, a), Math.max(0.1, b), 0, 0, 7); g.fillStyle = fill; g.fill(); }
  function gloss(g, x, y, r, a) { g.fillStyle = 'rgba(255,255,255,' + a + ')'; g.beginPath(); g.ellipse(x - r * 0.35, y - r * 0.38, r * 0.32, r * 0.18, -0.6, 0, 7); g.fill(); }
  function radial(g, x, y, r, c0, c1) { const gr = g.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r * 1.1); gr.addColorStop(0, c0); gr.addColorStop(1, c1); return gr; }
  function heartPath(g, x, y, R) {
    g.beginPath(); g.moveTo(x, y + R * 0.75);
    g.bezierCurveTo(x - R * 1.25, y - R * 0.05, x - R * 0.7, y - R * 1.05, x, y - R * 0.45);
    g.bezierCurveTo(x + R * 0.7, y - R * 1.05, x + R * 1.25, y - R * 0.05, x, y + R * 0.75);
    g.closePath();
  }
  function starPath(g, x, y, R, ri, n, rot) {
    g.beginPath();
    for (let i = 0; i < n * 2; i++) { const a = rot + (i * Math.PI) / n, r = i % 2 ? R * ri : R; if (i) g.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); else g.moveTo(x + Math.cos(a) * r, y + Math.sin(a) * r); }
    g.closePath();
  }
  function shadowE(g, x, y, R) { ell(g, x, y + R * 0.05, R * 0.95, R * 0.3, 'rgba(70,30,20,0.22)'); }
  // (x, y) = 토핑이 케이크에 닿는 점, R = 크기(px)
  function drawTop(g, k, x, y, R) {
    g.save();
    switch (k) {
      case 0: { // 딸기
        shadowE(g, x, y, R);
        g.beginPath(); g.moveTo(x, y);
        g.bezierCurveTo(x - R * 1.15, y - R * 0.45, x - R * 1.0, y - R * 1.6, x, y - R * 1.4);
        g.bezierCurveTo(x + R * 1.0, y - R * 1.6, x + R * 1.15, y - R * 0.45, x, y);
        g.fillStyle = radial(g, x, y - R * 0.8, R, '#ff7a86', '#c3163a'); g.fill();
        g.fillStyle = '#ffe9a0';
        [[-0.4, -0.6], [0.35, -0.65], [0, -0.35], [-0.5, -1.0], [0.48, -1.02], [0, -0.85], [-0.2, -1.15], [0.22, -1.2]].forEach(([a, b]) => { g.beginPath(); g.ellipse(x + a * R, y + b * R, R * 0.07, R * 0.1, 0, 0, 7); g.fill(); });
        g.fillStyle = '#3f9a3c';
        for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * 0.55; g.beginPath(); g.ellipse(x + Math.cos(a) * R * 0.32, y - R * 1.42 + Math.sin(a) * R * 0.12, R * 0.34, R * 0.12, a, 0, 7); g.fill(); }
        gloss(g, x, y - R * 0.85, R * 0.9, 0.45);
        break;
      }
      case 1: { // 블루베리
        shadowE(g, x, y, R);
        g.beginPath(); g.arc(x, y - R * 0.85, R * 0.9, 0, 7); g.fillStyle = radial(g, x, y - R * 0.85, R * 0.9, '#7a8cf0', '#262a6e'); g.fill();
        g.fillStyle = 'rgba(200,210,255,0.22)'; g.beginPath(); g.arc(x - R * 0.2, y - R * 1.0, R * 0.55, 0, 7); g.fill();
        g.fillStyle = '#1a1c48'; starPath(g, x, y - R * 1.45, R * 0.28, 0.45, 5, -Math.PI / 2); g.fill();
        break;
      }
      case 2: { // 체리
        shadowE(g, x, y, R);
        g.strokeStyle = '#5b7a2a'; g.lineWidth = Math.max(1, R * 0.16); g.lineCap = 'round';
        g.beginPath(); g.moveTo(x, y - R * 1.6); g.quadraticCurveTo(x + R * 0.2, y - R * 2.5, x + R * 0.9, y - R * 2.8); g.stroke();
        g.beginPath(); g.arc(x, y - R * 0.9, R * 0.92, 0, 7); g.fillStyle = radial(g, x, y - R * 0.9, R * 0.92, '#ff6a78', '#8e0820'); g.fill();
        gloss(g, x, y - R * 0.9, R * 0.95, 0.75);
        break;
      }
      case 3: { // 키위 (누운 단면)
        const cy = y - R * 0.35;
        ell(g, x, cy + R * 0.12, R * 1.02, R * 0.62, '#7a5a2e');
        ell(g, x, cy, R, R * 0.6, '#8fd24b');
        ell(g, x, cy, R * 0.82, R * 0.48, '#a9e05e');
        ell(g, x, cy, R * 0.3, R * 0.17, '#eef8c8');
        g.fillStyle = '#1d1a12';
        for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; g.beginPath(); g.ellipse(x + Math.cos(a) * R * 0.5, cy + Math.sin(a) * R * 0.3, R * 0.06, R * 0.035, a, 0, 7); g.fill(); }
        break;
      }
      case 4: { // 귤 조각
        shadowE(g, x, y, R);
        g.beginPath(); g.moveTo(x - R, y - R * 0.1); g.quadraticCurveTo(x, y - R * 1.6, x + R, y - R * 0.1); g.quadraticCurveTo(x, y + R * 0.15, x - R, y - R * 0.1);
        g.fillStyle = radial(g, x, y - R * 0.6, R, '#ffc46a', '#f07f12'); g.fill();
        g.strokeStyle = 'rgba(255,240,210,0.7)'; g.lineWidth = Math.max(0.8, R * 0.06);
        for (let i = -1; i <= 1; i++) { g.beginPath(); g.moveTo(x + i * R * 0.42, y - R * 0.12); g.lineTo(x + i * R * 0.3, y - R * 0.7); g.stroke(); }
        gloss(g, x, y - R * 0.55, R * 0.8, 0.4);
        break;
      }
      case 5: { // 바나나 (누운 단면)
        const cy = y - R * 0.3;
        ell(g, x, cy + R * 0.12, R, R * 0.6, '#e2c46a');
        ell(g, x, cy, R * 0.98, R * 0.58, '#fff3c2');
        ell(g, x, cy, R * 0.45, R * 0.26, '#f7e3a0');
        g.fillStyle = '#8a6a3a';
        for (let i = 0; i < 3; i++) { const a = -Math.PI / 2 + (i * 2 * Math.PI) / 3; g.beginPath(); g.arc(x + Math.cos(a) * R * 0.18, cy + Math.sin(a) * R * 0.1, R * 0.06, 0, 7); g.fill(); }
        break;
      }
      case 6: { // 초콜릿 조각
        shadowE(g, x, y, R);
        g.translate(x, y - R * 0.85); g.rotate(-0.22);
        g.fillStyle = '#3e2215'; g.fillRect(-R * 0.78 + R * 0.1, -R * 0.78 + R * 0.12, R * 1.56, R * 1.56);
        g.fillStyle = '#6b3d26'; g.fillRect(-R * 0.78, -R * 0.78, R * 1.56, R * 1.56);
        g.fillStyle = '#8a5434'; g.beginPath(); g.moveTo(-R * 0.78, -R * 0.78); g.lineTo(R * 0.78, -R * 0.78); g.lineTo(R * 0.6, -R * 0.6); g.lineTo(-R * 0.6, -R * 0.6); g.lineTo(-R * 0.6, R * 0.6); g.lineTo(-R * 0.78, R * 0.78); g.closePath(); g.fill();
        g.strokeStyle = '#4a2818'; g.lineWidth = Math.max(0.8, R * 0.06); g.beginPath(); g.moveTo(0, -R * 0.6); g.lineTo(0, R * 0.6); g.moveTo(-R * 0.6, 0); g.lineTo(R * 0.6, 0); g.stroke();
        break;
      }
      case 7: { // 마카롱
        shadowE(g, x, y, R);
        const c0 = '#8fdcbf';
        ell(g, x, y - R * 0.35, R, R * 0.4, shade(c0, -0.12));
        ell(g, x, y - R * 0.62, R * 0.9, R * 0.22, '#fff6e6');
        g.beginPath(); g.ellipse(x, y - R * 0.8, R, R * 0.55, 0, Math.PI, 0); g.lineTo(x + R, y - R * 0.74); g.ellipse(x, y - R * 0.74, R, R * 0.14, 0, 0, Math.PI); g.closePath();
        g.fillStyle = radial(g, x, y - R * 1.0, R, shade(c0, 0.35), c0); g.fill();
        g.strokeStyle = shade(c0, -0.2); g.lineWidth = Math.max(0.8, R * 0.08); g.setLineDash([R * 0.12, R * 0.08]);
        g.beginPath(); g.ellipse(x, y - R * 0.74, R * 0.98, R * 0.14, 0, 0.1, Math.PI - 0.1); g.stroke(); g.setLineDash([]);
        gloss(g, x, y - R * 1.0, R * 0.8, 0.45);
        break;
      }
      case 8: { // 쿠키
        const cy = y - R * 0.32;
        ell(g, x, cy + R * 0.14, R, R * 0.62, '#a8682e');
        ell(g, x, cy, R, R * 0.62, '#dda262');
        ell(g, x - R * 0.15, cy - R * 0.1, R * 0.6, R * 0.32, 'rgba(255,230,180,0.35)');
        g.fillStyle = '#4a2a18';
        [[-0.45, -0.1], [0.3, -0.25], [0.05, 0.22], [0.55, 0.15], [-0.15, -0.35]].forEach(([a, b]) => { g.beginPath(); g.ellipse(x + a * R, cy + b * R, R * 0.13, R * 0.09, 0.4, 0, 7); g.fill(); });
        break;
      }
      case 9: { // 하트 초콜릿
        shadowE(g, x, y, R);
        heartPath(g, x, y - R * 0.95, R * 0.95); g.fillStyle = radial(g, x, y - R * 1.05, R, '#ff8db0', '#c2185b'); g.fill();
        gloss(g, x - R * 0.15, y - R * 1.1, R * 0.7, 0.6);
        break;
      }
      case 10: { // 별 사탕
        shadowE(g, x, y, R);
        starPath(g, x, y - R * 0.9, R * 1.0, 0.48, 5, -Math.PI / 2); g.fillStyle = radial(g, x, y - R * 0.9, R, '#fff2a0', '#f2b705'); g.fill();
        g.strokeStyle = '#d99a00'; g.lineWidth = Math.max(0.8, R * 0.07); g.stroke();
        gloss(g, x, y - R * 1.0, R * 0.6, 0.6);
        break;
      }
      case 11: { // 민트 잎
        const cy = y - R * 0.35;
        [[-0.6, '#3a9a52'], [0.55, '#46ad5e']].forEach(([a, c], i) => {
          g.save(); g.translate(x, cy); g.rotate(a);
          g.beginPath(); g.moveTo(0, R * 0.1); g.quadraticCurveTo(-R * 0.55, -R * 0.45, 0, -R * 1.05); g.quadraticCurveTo(R * 0.55, -R * 0.45, 0, R * 0.1);
          g.fillStyle = c; g.fill();
          g.strokeStyle = 'rgba(200,250,200,0.6)'; g.lineWidth = Math.max(0.6, R * 0.05); g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -R * 0.9); g.stroke();
          g.restore(); void i;
        });
        break;
      }
      case 12: { // 설탕 꽃
        const cy = y - R * 0.4;
        for (let i = 0; i < 5; i++) {
          const a = -Math.PI / 2 + (i * 2 * Math.PI) / 5;
          g.beginPath(); g.ellipse(x + Math.cos(a) * R * 0.5, cy + Math.sin(a) * R * 0.36, R * 0.42, R * 0.3, a, 0, 7);
          g.fillStyle = radial(g, x + Math.cos(a) * R * 0.5, cy + Math.sin(a) * R * 0.36, R * 0.42, '#ffffff', '#ffadc9'); g.fill();
        }
        ell(g, x, cy, R * 0.24, R * 0.2, '#ffcf3f');
        break;
      }
      case 13: { // 진주 구슬
        shadowE(g, x, y, R);
        g.beginPath(); g.arc(x, y - R * 0.85, R * 0.85, 0, 7);
        const gr = g.createRadialGradient(x - R * 0.3, y - R * 1.15, R * 0.05, x, y - R * 0.85, R); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.5, '#d7dde6'); gr.addColorStop(1, '#7a8494');
        g.fillStyle = gr; g.fill();
        break;
      }
      case 14: { // 머랭
        shadowE(g, x, y, R);
        g.beginPath(); g.moveTo(x - R, y - R * 0.2);
        g.bezierCurveTo(x - R * 1.0, y - R * 1.0, x - R * 0.2, y - R * 1.3, x + R * 0.15, y - R * 2.0);
        g.bezierCurveTo(x + R * 0.1, y - R * 1.3, x + R * 1.0, y - R * 1.0, x + R, y - R * 0.2);
        g.quadraticCurveTo(x, y + R * 0.15, x - R, y - R * 0.2);
        g.fillStyle = radial(g, x, y - R * 0.8, R * 1.1, '#ffffff', '#f1dcc0'); g.fill();
        g.strokeStyle = 'rgba(210,180,140,0.55)'; g.lineWidth = Math.max(0.7, R * 0.07);
        for (let i = -1; i <= 1; i++) { g.beginPath(); g.moveTo(x + i * R * 0.55, y - R * 0.2); g.quadraticCurveTo(x + i * R * 0.35, y - R * 0.9, x + R * 0.1, y - R * 1.7); g.stroke(); }
        break;
      }
      case 15: { // 곰 젤리
        shadowE(g, x, y, R);
        g.globalAlpha = 0.93;
        const c = '#ff8a3d', c2 = '#e35d14';
        ell(g, x - R * 0.42, y - R * 0.18, R * 0.24, R * 0.18, c2); ell(g, x + R * 0.42, y - R * 0.18, R * 0.24, R * 0.18, c2);
        g.beginPath(); g.ellipse(x, y - R * 0.6, R * 0.58, R * 0.6, 0, 0, 7); g.fillStyle = radial(g, x, y - R * 0.6, R * 0.6, '#ffc08a', c); g.fill();
        ell(g, x - R * 0.62, y - R * 0.75, R * 0.2, R * 0.15, c2); ell(g, x + R * 0.62, y - R * 0.75, R * 0.2, R * 0.15, c2);
        ell(g, x - R * 0.36, y - R * 1.62, R * 0.2, R * 0.2, c); ell(g, x + R * 0.36, y - R * 1.62, R * 0.2, R * 0.2, c);
        g.beginPath(); g.arc(x, y - R * 1.3, R * 0.48, 0, 7); g.fillStyle = radial(g, x, y - R * 1.3, R * 0.48, '#ffc08a', c); g.fill();
        g.globalAlpha = 1;
        g.fillStyle = 'rgba(120,40,0,0.55)'; g.beginPath(); g.arc(x - R * 0.17, y - R * 1.35, R * 0.06, 0, 7); g.arc(x + R * 0.17, y - R * 1.35, R * 0.06, 0, 7); g.fill();
        gloss(g, x, y - R * 1.3, R * 0.5, 0.55);
        break;
      }
      case 16: { // 초
        const hgt = R * 4.4, wd = R * 0.7;
        shadowE(g, x, y, R * 0.8);
        g.fillStyle = '#86c5e8'; rr(g, x - wd / 2, y - hgt, wd, hgt, wd * 0.25); g.fill();
        g.save(); rr(g, x - wd / 2, y - hgt, wd, hgt, wd * 0.25); g.clip();
        g.strokeStyle = '#ffffff'; g.lineWidth = wd * 0.32;
        for (let i = -1; i < 6; i++) { g.beginPath(); g.moveTo(x - wd, y - i * wd * 1.3); g.lineTo(x + wd, y - i * wd * 1.3 - wd * 1.1); g.stroke(); }
        g.fillStyle = 'rgba(255,255,255,0.25)'; g.fillRect(x - wd / 2, y - hgt, wd * 0.3, hgt);
        g.restore();
        g.strokeStyle = '#2a2018'; g.lineWidth = Math.max(0.8, R * 0.1); g.beginPath(); g.moveTo(x, y - hgt); g.lineTo(x, y - hgt - R * 0.35); g.stroke();
        break;
      }
    }
    g.restore();
  }
  function drawFlame(g, x, y, R, t, seed) {
    const f = 1 + Math.sin(t * 13 + seed) * 0.08 + Math.sin(t * 7.3 + seed * 2) * 0.06;
    const gl = g.createRadialGradient(x, y - R * 0.5, 0, x, y - R * 0.5, R * 2.2);
    gl.addColorStop(0, 'rgba(255,210,120,0.45)'); gl.addColorStop(1, 'rgba(255,180,80,0)');
    g.fillStyle = gl; g.beginPath(); g.arc(x, y - R * 0.5, R * 2.2, 0, 7); g.fill();
    g.beginPath(); g.moveTo(x, y - R * 1.5 * f); g.quadraticCurveTo(x + R * 0.5, y - R * 0.3, x, y + R * 0.05); g.quadraticCurveTo(x - R * 0.5, y - R * 0.3, x, y - R * 1.5 * f);
    g.fillStyle = '#ffb53d'; g.fill();
    g.beginPath(); g.ellipse(x, y - R * 0.3, R * 0.17, R * 0.38, 0, 0, 7); g.fillStyle = '#fff6d0'; g.fill();
  }
  // 크림 한 덩이: (x, y) 화면 위치, a = 둘레 각도, s = 크기(px)
  function drawBlob(g, tp, col, x, y, a, s) {
    const dark = shade(col, -0.22), lite = shade(col, 0.45);
    ell(g, x, y + s * 0.42, s * 0.95, s * 0.36, 'rgba(60,25,15,0.18)');
    if (tp === 0) { // 별 깍지 로제트
      starPath(g, x, y - s * 0.2, s, 0.72, 7, a); g.fillStyle = radial(g, x, y - s * 0.2, s, lite, col); g.fill();
      g.strokeStyle = dark; g.lineWidth = Math.max(0.6, s * 0.1);
      for (let i = 0; i < 7; i++) { const b = a + (i * 2 * Math.PI) / 7; g.beginPath(); g.moveTo(x + Math.cos(b) * s * 0.22, y - s * 0.2 + Math.sin(b) * s * 0.22); g.lineTo(x + Math.cos(b) * s * 0.75, y - s * 0.2 + Math.sin(b) * s * 0.75); g.stroke(); }
      ell(g, x - s * 0.15, y - s * 0.4, s * 0.22, s * 0.14, 'rgba(255,255,255,0.45)');
    } else if (tp === 1) { // 동글 깍지
      g.beginPath(); g.ellipse(x, y - s * 0.25, s * 0.85, s * 0.75, 0, 0, 7); g.fillStyle = radial(g, x, y - s * 0.25, s * 0.85, lite, col); g.fill();
      ell(g, x - s * 0.25, y - s * 0.55, s * 0.24, s * 0.15, 'rgba(255,255,255,0.55)');
      g.beginPath(); g.moveTo(x - s * 0.05, y - s * 0.9); g.quadraticCurveTo(x + s * 0.15, y - s * 1.1, x + s * 0.3, y - s * 0.95); g.strokeStyle = col; g.lineWidth = s * 0.22; g.lineCap = 'round'; g.stroke();
    } else { // 물결(조개) 깍지 — 둘레 방향으로 누운 물방울
      const tx = -Math.sin(a), ty = Math.cos(a) * SQ, tl = Math.hypot(tx, ty) || 1, ang = Math.atan2(ty / tl, tx / tl);
      g.save(); g.translate(x, y - s * 0.2); g.rotate(ang);
      g.beginPath(); g.moveTo(-s * 1.2, 0); g.bezierCurveTo(-s * 0.6, -s * 0.9, s * 0.8, -s * 0.9, s * 0.95, 0); g.bezierCurveTo(s * 0.8, s * 0.7, -s * 0.6, s * 0.7, -s * 1.2, 0);
      g.fillStyle = radial(g, 0, 0, s, lite, col); g.fill();
      g.strokeStyle = dark; g.lineWidth = Math.max(0.6, s * 0.09);
      for (let i = -1; i <= 1; i++) { g.beginPath(); g.moveTo(-s * 0.9, 0); g.quadraticCurveTo(0, i * s * 0.5, s * 0.8, i * s * 0.25); g.stroke(); }
      g.restore();
    }
  }
  const SPRC = { 1: ['#ff5d8f', '#ffd166', '#06d6a0', '#4cc9f0', '#b388ff', '#ffffff', '#ff9f43'], 2: ['#3e2215', '#5b341f', '#2a160d', '#7a4a2c'] };
  const SPRINK = (() => { const r = rng(4242), a = []; for (let i = 0; i < 90; i++) { const rr_ = Math.sqrt(r()) * 0.86, t = r() * Math.PI * 2; a.push([Math.cos(t) * rr_, Math.sin(t) * rr_, r() * Math.PI, r()]); } return a; })();

  /* 케이크 전체 그리기: (cx, cy) = 윗면 중심, rx = 반지름(px). 불꽃 위치를 돌려줌 */
  function drawCake(g, c, cx, cy, rx, opt) {
    opt = opt || {};
    const ry = rx * SQ, sh = rx * 0.3, flames = [];
    // 돌림판 받침
    ell(g, cx, cy + sh + ry * 0.35, rx * 1.28, ry * 1.2, 'rgba(0,0,0,0.25)');
    g.fillStyle = '#c9c2bb';
    g.beginPath(); g.moveTo(cx - rx * 0.32, cy + sh + ry * 1.05); g.lineTo(cx - rx * 0.22, cy + sh + ry * 1.05 + rx * 0.14); g.lineTo(cx + rx * 0.22, cy + sh + ry * 1.05 + rx * 0.14); g.lineTo(cx + rx * 0.32, cy + sh + ry * 1.05); g.fill();
    ell(g, cx, cy + sh + ry * 1.05 + rx * 0.14, rx * 0.36, rx * 0.06, '#aaa29a');
    ell(g, cx, cy + sh + ry * 0.12 + rx * 0.045, rx * 1.16, ry * 1.12, '#b9b1a9');
    const pg = g.createLinearGradient(cx - rx * 1.16, 0, cx + rx * 1.16, 0);
    pg.addColorStop(0, '#e9e4dd'); pg.addColorStop(0.5, '#ffffff'); pg.addColorStop(1, '#d9d2ca');
    ell(g, cx, cy + sh + ry * 0.12, rx * 1.16, ry * 1.12, pg);
    // 옆면
    const plain = c.s === PLAIN, base = plain ? '#e9c58d' : SHEETS[c.s].c;
    const sg = g.createLinearGradient(cx - rx, 0, cx + rx, 0);
    sg.addColorStop(0, shade(base, -0.25)); sg.addColorStop(0.35, shade(base, 0.08)); sg.addColorStop(0.7, base); sg.addColorStop(1, shade(base, -0.3));
    g.beginPath(); g.moveTo(cx - rx, cy); g.lineTo(cx - rx, cy + sh); g.ellipse(cx, cy + sh, rx, ry, 0, Math.PI, 0, true); g.lineTo(cx + rx, cy); g.closePath();
    g.fillStyle = sg; g.fill();
    if (plain) {
      g.save(); g.clip();
      [0.36, 0.68].forEach((f) => { g.strokeStyle = 'rgba(255,248,232,0.95)'; g.lineWidth = sh * 0.12; g.beginPath(); g.ellipse(cx, cy + sh * f, rx, ry, 0, Math.PI, 0, true); g.stroke(); });
      g.fillStyle = 'rgba(160,110,50,0.25)';
      const r0 = rng(99); for (let i = 0; i < 40; i++) { const a = Math.PI * r0(), yy = cy + sh * r0(); g.beginPath(); g.arc(cx - Math.cos(a) * rx * 0.98, yy + Math.sin(a) * ry, rx * 0.012, 0, 7); g.fill(); }
      g.restore();
    } else {
      g.strokeStyle = 'rgba(255,255,255,0.12)'; g.lineWidth = 1;
      for (let i = 1; i < 10; i++) { const a = Math.PI * (i / 10); const xx = cx - Math.cos(a) * rx; g.beginPath(); g.moveTo(xx, cy + Math.sin(a) * ry * 0.2); g.lineTo(xx, cy + sh + Math.sin(a) * ry); g.stroke(); }
    }
    // 윗면
    const tg = g.createRadialGradient(cx - rx * 0.3, cy - ry * 0.4, rx * 0.05, cx, cy, rx * 1.05);
    tg.addColorStop(0, shade(base, plain ? 0.15 : 0.32)); tg.addColorStop(1, plain ? '#dcb377' : shade(base, -0.05));
    ell(g, cx, cy, rx, ry, tg);
    if (plain) { g.fillStyle = 'rgba(170,120,60,0.2)'; const r0 = rng(7); for (let i = 0; i < 70; i++) { const a = r0() * 7, d = Math.sqrt(r0()) * 0.95; g.beginPath(); g.arc(cx + Math.cos(a) * d * rx, cy + Math.sin(a) * d * ry, rx * 0.012, 0, 7); g.fill(); } }
    g.strokeStyle = 'rgba(255,255,255,0.22)'; g.lineWidth = Math.max(1, rx * 0.01); g.beginPath(); g.ellipse(cx, cy, rx * 0.985, ry * 0.985, 0, Math.PI * 1.05, Math.PI * 1.75); g.stroke();
    // 가루
    if (c.sp === 1 || c.sp === 2) {
      const cols = SPRC[c.sp]; g.lineCap = 'round'; g.lineWidth = Math.max(1.2, rx * 0.017);
      SPRINK.forEach(([u, v, a, q], i) => { const x = cx + u * rx, y = cy + v * ry, l = rx * 0.025; g.strokeStyle = cols[i % cols.length]; g.beginPath(); g.moveTo(x - Math.cos(a) * l, y - Math.sin(a) * l * SQ); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l * SQ); g.stroke(); void q; });
    } else if (c.sp === 3) {
      g.fillStyle = 'rgba(255,255,255,0.6)';
      SPRINK.forEach(([u, v, a, q]) => { g.beginPath(); g.arc(cx + u * rx, cy + v * ry, rx * (0.008 + q * 0.012), 0, 7); g.fill(); g.beginPath(); g.arc(cx + v * rx * 0.9, cy - u * ry * 0.9, rx * 0.008, 0, 7); g.fill(); void a; });
    }
    if (opt.guide) opt.guide(g);
    // 앞뒤 순서대로: 크림 덩이 + 토핑 + 글씨판
    const list = [];
    ['ro', 'ri'].forEach((key) => {
      const R = RING_R[key], bs = rx * (key === 'ro' ? 0.085 : 0.06);
      c[key].forEach((cc, i) => { if (cc < 0) return; const a = ((i + 0.5) / NS) * 2 * Math.PI; list.push([Math.sin(a) * R, 0, cc, a, R, bs]); });
    });
    c.it.forEach((it, i) => list.push([it[2], 1, it, i]));
    if (c.w >= 0) list.push([c.wy, 2]);
    list.sort((A, B) => A[0] - B[0]);
    for (const e of list) {
      if (e[1] === 0) { const [, , cc, a, R, bs] = e; drawBlob(g, c.tp, CREAMS[cc].c, cx + Math.cos(a) * R * rx, cy + Math.sin(a) * R * ry, a, bs); }
      else if (e[1] === 1) {
        const it = e[2]; if (opt.skip === e[3]) continue;
        const x = cx + it[1] * rx, y = cy + it[2] * ry, R = TOPS[it[0]].s * rx * TS;
        drawTop(g, it[0], x, y, R);
        if (it[0] === T.CD) flames.push([x, y - R * 4.4 - R * 0.35, R]);
      } else if (!opt.skipW) drawPlaque(g, c.w, cx + c.wx * rx, cy + c.wy * ry, rx);
    }
    return flames;
  }
  function drawPlaque(g, w, x, y, rx) {
    const ww = pw(w) * rx, hh = PH * 2 * rx * SQ;
    ell(g, x + rx * 0.01, y + hh * 0.18, ww / 2, hh / 2, 'rgba(90,50,20,0.25)');
    g.beginPath(); g.ellipse(x, y, ww / 2, hh / 2, 0, 0, 7);
    const gr = g.createLinearGradient(0, y - hh / 2, 0, y + hh / 2); gr.addColorStop(0, '#fffaf0'); gr.addColorStop(1, '#efe0c4');
    g.fillStyle = gr; g.fill(); g.strokeStyle = '#d9c39c'; g.lineWidth = Math.max(1, rx * 0.012); g.stroke();
    g.fillStyle = '#4a2716'; g.font = Math.round(rx * 0.1) + 'px ' + DISP; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(WORDS[w], x, y + rx * 0.005);
  }
  // 은빛 덮개(클로슈): lift 0 = 덮임, 1 = 다 열림
  function drawCloche(g, cx, cy, rx, lift, glass) {
    const ry = rx * SQ, sh = rx * 0.3, base = cy + sh + ry * 0.12, w = rx * 1.12, ht = rx * 1.12;
    const dy = -lift * rx * 1.4;
    g.save(); g.globalAlpha = glass ? 1 : Math.max(0, 1 - lift * 1.1);
    g.translate(0, dy);
    g.beginPath(); g.moveTo(cx - w, base); g.bezierCurveTo(cx - w, base - ht * 1.15, cx + w, base - ht * 1.15, cx + w, base); g.ellipse(cx, base, w, ry * 1.05, 0, 0, Math.PI); g.closePath();
    if (glass) {
      g.fillStyle = 'rgba(200,230,255,0.10)'; g.fill(); g.strokeStyle = 'rgba(230,245,255,0.55)'; g.lineWidth = 1.5; g.stroke();
      g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = rx * 0.05; g.lineCap = 'round';
      g.beginPath(); g.moveTo(cx - w * 0.72, base - ht * 0.25); g.quadraticCurveTo(cx - w * 0.7, base - ht * 0.72, cx - w * 0.3, base - ht * 0.84); g.stroke();
    } else {
      const gr = g.createLinearGradient(cx - w, 0, cx + w, 0);
      gr.addColorStop(0, '#8d949e'); gr.addColorStop(0.3, '#f4f6f8'); gr.addColorStop(0.55, '#c9ced5'); gr.addColorStop(1, '#6f7680');
      g.fillStyle = gr; g.fill();
      g.strokeStyle = 'rgba(255,255,255,0.65)'; g.lineWidth = rx * 0.04; g.lineCap = 'round';
      g.beginPath(); g.moveTo(cx - w * 0.62, base - ht * 0.3); g.quadraticCurveTo(cx - w * 0.6, base - ht * 0.7, cx - w * 0.25, base - ht * 0.8); g.stroke();
      ell(g, cx, base, w, ry * 0.18, '#9aa1aa');
    }
    const ky = base - ht * 0.86;
    ell(g, cx, ky, rx * 0.13, rx * 0.09, glass ? 'rgba(230,245,255,0.6)' : '#d9dde2');
    ell(g, cx, ky - rx * 0.05, rx * 0.09, rx * 0.06, glass ? 'rgba(255,255,255,0.7)' : '#ffffff');
    g.restore();
  }

  /* ======================= 소리 ======================= */
  const Snd = {
    ac: null, nb: null, lastSq: 0,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    tone(f, d, type, vol, f2, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
        o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.1, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + d + 0.03);
      } catch (e) {}
    },
    noise(d, type, f0, f1, vol, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        if (!this.nb) { const n = ac.sampleRate, b = ac.createBuffer(1, n, ac.sampleRate), x = b.getChannelData(0); for (let i = 0; i < n; i++) x[i] = Math.random() * 2 - 1; this.nb = b; }
        const t = ac.currentTime + (delay || 0), src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.nb; f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + d); f.Q.value = 0.9;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + d + 0.05);
      } catch (e) {}
    },
    squish() { const n = performance.now(); if (n - this.lastSq < 70) return; this.lastSq = n; this.noise(0.09, 'lowpass', 900, 300, 0.12); this.tone(220 + Math.random() * 60, 0.07, 'sine', 0.04, 160); },
    pop() { this.tone(520, 0.09, 'sine', 0.12, 900); this.noise(0.04, 'highpass', 2500, 1500, 0.05); },
    plop() { this.tone(500, 0.14, 'sine', 0.1, 180); },
    splat() { this.noise(0.22, 'lowpass', 1400, 250, 0.16); },
    tapk() { this.tone(1100, 0.04, 'triangle', 0.05); },
    ding() { this.tone(1318, 0.18, 'sine', 0.07); this.tone(1760, 0.22, 'sine', 0.06, 0, 0.07); },
    bell() { [1568, 2093, 1568].forEach((f, i) => this.tone(f, 0.35, 'sine', 0.06, 0, i * 0.12)); },
    tick() { this.tone(1500, 0.05, 'square', 0.03); },
    done() { [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.18, 'triangle', 0.07, 0, i * 0.06)); },
    lift() { this.noise(0.35, 'highpass', 900, 4000, 0.08); this.tone(880, 0.25, 'sine', 0.05, 1320); },
    score(v) { const b = v >= 95 ? 1046 : v >= 80 ? 880 : v >= 60 ? 659 : 440; this.tone(b, 0.25, 'triangle', 0.08); if (v >= 95) this.tone(b * 1.5, 0.3, 'triangle', 0.06, 0, 0.1); },
    fanfare() { [523, 659, 784, 1046, 784, 1046].forEach((f, i) => this.tone(f, 0.22, 'triangle', 0.08, 0, i * 0.09)); },
  };

  /* ======================= 화면 ======================= */
  const CSS = `
.cdk-bot{position:absolute;left:0;right:0;bottom:0;z-index:3;display:flex;flex-direction:column;gap:6px;padding:6px 8px 8px;background:linear-gradient(rgba(23,19,31,0),rgba(23,19,31,.92) 22%)}
.cdk-pal{display:flex;gap:6px;overflow-x:auto;overflow-y:hidden;touch-action:pan-x;scrollbar-width:none;padding:2px 2px 0;scroll-behavior:smooth}
.cdk-pal::-webkit-scrollbar{display:none}
.cdk-it{flex:0 0 auto;width:56px;height:58px;border-radius:12px;border:1px solid var(--line);background:var(--surface-2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;color:var(--ink);font:600 10.5px var(--f-body);padding:2px;cursor:pointer;white-space:nowrap;touch-action:pan-x}
.cdk-it canvas{width:30px;height:30px;pointer-events:none}
.cdk-it.wide{width:84px}
.cdk-it.on{border-color:var(--brass);box-shadow:inset 0 0 0 2px var(--brass);background:#43351f}
.cdk-it:active{transform:scale(.95)}
.cdk-sep{flex:0 0 1px;background:var(--line);margin:6px 2px}
.cdk-tabs{display:flex;gap:5px}
.cdk-tab{flex:1 1 0;min-width:0;padding:0 2px;min-height:46px;font-size:14px}
.cdk-tab.on{background:var(--brass);color:#2a1d0c;border-color:var(--brass)}
.cdk-undo{flex:0 0 46px;padding:0;font-size:20px;min-height:46px}
.cdk-done{flex:0 0 80px;padding:0 4px;min-height:46px;font-size:15px}
.cdk-done.armed{background:var(--coral);border-color:var(--coral);animation:cdkPulse .7s ease-in-out infinite}
@keyframes cdkPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}
.cdk-rev{position:absolute;left:0;right:0;bottom:0;z-index:3;display:flex;gap:8px;align-items:center;padding:8px 12px 10px;background:linear-gradient(rgba(23,19,31,0),rgba(23,19,31,.92) 25%)}
.cdk-rev .btn{flex:1;min-height:50px;font-size:16px}
.cdk-rev .muted{flex:1;text-align:center;font-size:14px}
.cdk-hand{position:absolute;inset:0;z-index:14;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:24px;background:radial-gradient(circle at 50% 40%,#3a2438,#140e18 70%)}
.cdk-hand .big{font-family:var(--f-display);font-size:30px}
.cdk-hand .btn{min-width:200px;min-height:52px;font-size:17px}
.cdk-spot{position:absolute;pointer-events:none;border-radius:14px}
.cdk-ov{position:absolute;inset:0;z-index:16;background:rgba(10,8,15,.78);display:flex;align-items:flex-end;justify-content:center;padding:10px;animation:fade .15s ease-out}
.cdk-sheet{background:var(--surface);border:1px solid var(--line);border-radius:18px;width:min(440px,100%);max-height:100%;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px}
.cdk-sheet>*{flex:none}
.cdk-sheet h3{font-family:var(--f-display);font-weight:400;font-size:21px;margin:0}
.cdk-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.cdk-x{min-width:44px;min-height:44px;border-radius:12px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-size:18px;cursor:pointer}
.cdk-li{font-size:14px;line-height:1.45;background:var(--surface-2);border-radius:10px;padding:7px 10px}
.cdk-li.ok{color:#9fe3a8}
.cdk-note{font-size:12px;color:var(--muted);line-height:1.45}
.cdk-sheet canvas{width:100%;height:auto;border-radius:12px;background:#1d1626}
.cdk-hid{display:none!important}
`;
  const TABS = ['시트', '크림', '토핑', '장식'];
  const HINTS = ['아래에서 시트 색을 골라요', '테두리나 가운데 원을 손가락으로 빙 둘러 그어요', '케이크를 눌러 올려요 · 끌어서 옮기고, 밖으로 끌면 빠져요', '가루는 눌러서 뿌려요 · 글씨판은 끌어서 옮겨요'];

  // 주문 줄: 짧은 칩 + 긴 문장 + 진행도
  function orderRows(o) {
    const rows = [];
    rows.push({ t: 'sheet', s: '시트 ' + SHEETS[o.s].n, l: '시트는 「' + SHEETS[o.s].n + '」 색으로 발라 주세요.' });
    if (o.ro) {
      const a = CREAMS[o.ro[1]].n, b = CREAMS[o.ro[2]].n;
      rows.push({ t: 'ro', s: o.ro[0] === 0 ? '테두리 ' + a : o.ro[0] === 1 ? '테두리 ' + a + '·' + b + ' 번갈아' : '테두리 반반 ' + a + '·' + b,
        l: o.ro[0] === 0 ? '테두리를 빙 둘러 ' + a + ' 크림으로 짜 주세요.' : o.ro[0] === 1 ? '테두리를 8조각으로 나눠 ' + a + '·' + b + ' 크림을 번갈아 짜 주세요. (크림 탭의 작은 눈금이 조각 경계예요)' : '테두리 절반은 ' + a + ', 나머지 절반은 ' + b + ' 크림으로 짜 주세요.' });
    }
    if (o.ri >= 0) rows.push({ t: 'ri', s: '가운데 원 ' + CREAMS[o.ri].n, l: '가운데에 ' + CREAMS[o.ri].n + ' 크림으로 작은 동그라미를 둘러 주세요.' });
    if (o.tip >= 0) rows.push({ t: 'tip', s: TIPS[o.tip].n, l: '크림은 「' + TIPS[o.tip].n + '」로 짜 주세요.' });
    o.it.forEach((x, i) => rows.push({ t: 'it', i, s: TSN[x[0]] + ' ' + x[1] + ' · ' + ZN[x[2]] + (x[3] ? ' 고르게' : ''),
      l: TOPS[x[0]].n + ' ' + x[1] + '개를 ' + ZW[x[2]] + (x[3] ? ' 같은 간격으로 빙 둘러' : '') + ' 올려 주세요.' }));
    if (o.sp) rows.push({ t: 'sp', s: SPR[o.sp].n, l: jo(SPR[o.sp].n, '을', '를') + ' 뿌려 주세요.' });
    if (o.w >= 0) rows.push({ t: 'w', s: '글씨 「' + WORDS[o.w] + '」', l: '초코펜 글씨판 「' + WORDS[o.w] + '」를 가운데쯤 올려 주세요.' });
    return rows;
  }
  function rowProg(o, row, c) {
    switch (row.t) {
      case 'sheet': return [c.s === o.s, ''];
      case 'ro': { const f = ringMatch(c.ro, ringTarget(o.ro)); return [f >= 0.96, Math.round(f * 100) + '%']; }
      case 'ri': { const f = ringMatch(c.ri, Array(NS).fill(o.ri)); return [f >= 0.96, Math.round(f * 100) + '%']; }
      case 'tip': return [c.tp === o.tip, ''];
      case 'it': {
        const [k, n, z] = o.it[row.i], its = c.it.filter((x) => x[0] === k), inz = z === 0 ? its.length : its.filter((x) => zoneOf(x[1], x[2]) === z).length;
        return [its.length === n && inz === n, (its.length > n ? '+' + (its.length - n) : inz + '/' + n)];
      }
      case 'sp': return [c.sp === o.sp, ''];
      case 'w': return [c.w === o.w && Math.hypot(c.wx, c.wy) < 0.45, ''];
    }
    return [false, ''];
  }

  function mount(root, api) {
    const h = L.h;
    root.appendChild(h('style', { text: CSS }));
    const cv = U.canvas(root), ctx = cv.ctx;
    const spotOrder = h('div', { class: 'cdk-spot cdk-spot-order' }), spotCake = h('div', { class: 'cdk-spot cdk-spot-cake' });
    const pal = h('div', { class: 'cdk-pal' });
    const tabBtns = TABS.map((t, i) => h('button', { class: 'btn cdk-tab', type: 'button', text: t, onclick: () => setTab(i) }));
    const undoBtn = h('button', { class: 'btn cdk-undo', type: 'button', 'aria-label': '되돌리기', title: '되돌리기', text: '↶', onclick: () => undo() });
    const doneBtn = h('button', { class: 'btn primary cdk-done', type: 'button', text: '완성!', onclick: () => pressDone() });
    const tabsEl = h('div', { class: 'cdk-tabs' }, ...tabBtns, undoBtn, doneBtn);
    const bot = h('div', { class: 'cdk-bot' }, pal, tabsEl);
    const revBtn = h('button', { class: 'btn primary', type: 'button', text: '다음 주문 받기', onclick: () => pressNext() });
    const revMsg = h('div', { class: 'muted', text: '' });
    const revBar = h('div', { class: 'cdk-rev cdk-hid' }, revBtn, revMsg);
    root.append(spotOrder, spotCake, bot, revBar);

    const spd = () => (L.debug && L.debug.speed) || 1;
    const nm = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || i + 1 + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const multi = () => !api.online && api.mySeats().length >= 2;
    let st = null, dead = false, roundKey = '', active = -1, tab = 0, curMode = '';
    const tool = { cream: 0, top: 0, dec: 1 };
    let work = {}, tStart = {}, tPause = {}, sent = {}, readySent = {};
    let drag = null, armedT = 0, banner = 0, lastTick = -1, hintFlash = 0, orderEl = null, detailEl = null, handEl = null, handKey = '';
    let revId = -1, revT = 0, revDone = false, autoT = -1, layKey = '', palKey = '', clock = 0, progDone = '';
    const parts = [], detCache = {};
    let drawErr = 0;
    const Lay = { W: 0, H: 0, cx: 0, cy: 0, rx: 100, card: { x: 8, y: 34, w: 100, h: 60 }, chips: [], botH: 122 };
    const cache = new Map();

    /* ---- 누가 무엇을 하나 ---- */
    const rKey = () => (st ? st.sd + ':' + st.r : '');
    function pendingLocal() {
      if (!st || st.ph !== 'd') return [];
      const out = [];
      for (let i = 0; i < st.n; i++) if (api.canAct(i) && st.ck[i] == null && sent[i] !== roundKey) out.push(i);
      return out;
    }
    function editSeat() {
      const p = pendingLocal();
      if (!p.length) return -1;
      if (multi()) return p.includes(active) ? active : -1;
      return p[0];
    }
    function mode() {
      if (!st) return 'none';
      if (st.ph === 'd' && st.o) { if (editSeat() >= 0) return 'edit'; if (multi() && pendingLocal().length) return 'hand'; return 'wait'; }
      return st.last ? 'rev' : 'wait';
    }
    function W(seat) {
      if (!work[seat]) { const c = blank(); work[seat] = { c, undo: [], str: enc(c) }; }
      return work[seat];
    }
    function paused() { return !!document.querySelector('.tut-layer') || (!api.online && !!document.querySelector('.overlay.rules-ov')); }
    function elapsed(seat) { if (tStart[seat] == null) return 0; return ((clock - tStart[seat] - (tPause[seat] || 0)) * spd()) / 1000; }

    /* ---- 레이아웃 ---- */
    function chipsLayout(width) {
      const o = st && st.o; Lay.chips = [];
      if (!o) return 0;
      ctx.font = '600 12px ' + FONT;
      const rows = orderRows(o), inner = width - 16;
      let x = 0, y = 0;
      rows.forEach((r) => {
        const w = Math.min(inner, 8 + 18 + 5 + ctx.measureText(r.s).width + 6 + 30);
        if (x > 0 && x + w > inner) { x = 0; y += 26; }
        Lay.chips.push({ r, x, y, w });
        x += w + 5;
      });
      return y + 26;
    }
    function layout() {
      const Wd = cv.w, Hh = cv.h;
      Lay.W = Wd; Lay.H = Hh;
      Lay.botH = bot.offsetHeight || 124;
      const ch = chipsLayout(Wd - 16);
      Lay.card = { x: 8, y: 32, w: Wd - 16, h: 30 + ch + 6 };
      const top = Lay.card.y + Lay.card.h + 4, bottom = Hh - Lay.botH - 20, avail = Math.max(120, bottom - top);
      const K = 1.98, rx = Math.max(60, Math.min((Wd - 12) / 2.36, avail / K, 210));
      Lay.rx = rx; Lay.cx = Wd / 2; Lay.cy = top + Math.max(0, avail - K * rx) * 0.15 + rx * 0.85;
      Lay.hintY = Math.min(bottom + 10, Lay.cy + rx * 1.13 + 12);
      const place = (el, x, y, w, hh) => { el.style.left = x + 'px'; el.style.top = y + 'px'; el.style.width = w + 'px'; el.style.height = hh + 'px'; };
      place(spotOrder, Lay.card.x - 2, Lay.card.y - 2, Lay.card.w + 4, Lay.card.h + 4);
      place(spotCake, Lay.cx - rx * 1.1, Lay.cy - rx * SQ - rx * 0.2, rx * 2.2, rx * (SQ * 2.3 + 0.5));
      layKey = Wd + 'x' + Hh + ':' + Lay.botH + ':' + (st && st.o ? JSON.stringify(st.o) : '');
    }
    cv.onresize = () => { layKey = ''; bgKey = ''; };

    /* ---- 배경 (캐시) ---- */
    let bg = null, bgWall = null, bgKey = '';
    function buildBg() {
      const Wd = Lay.W, Hh = Lay.H, dpr = cv.dpr;
      const c = document.createElement('canvas'); c.width = Math.ceil(Wd * dpr); c.height = Math.ceil(Hh * dpr);
      const b = c.getContext('2d'); b.scale(dpr, dpr);
      const sky = b.createLinearGradient(0, 0, 0, Hh); sky.addColorStop(0, '#2a1a2c'); sky.addColorStop(0.55, '#21172a'); sky.addColorStop(1, '#150f1b');
      b.fillStyle = sky; b.fillRect(0, 0, Wd, Hh);
      b.fillStyle = 'rgba(255,170,200,0.035)';
      for (let x = 0; x < Wd; x += 36) b.fillRect(x, 0, 16, Hh);
      const r0 = rng(31);
      for (let i = 0; i < 26; i++) { b.fillStyle = 'rgba(255,214,150,' + (0.03 + r0() * 0.05).toFixed(3) + ')'; b.beginPath(); b.arc(r0() * Wd, r0() * Hh * 0.6, 2 + r0() * 3, 0, 7); b.fill(); }
      // 따뜻한 조명
      const lg = b.createRadialGradient(Wd / 2, Hh * 0.45, 10, Wd / 2, Hh * 0.45, Math.max(Wd, Hh) * 0.6);
      lg.addColorStop(0, 'rgba(255,200,140,0.10)'); lg.addColorStop(1, 'rgba(255,200,140,0)');
      b.fillStyle = lg; b.fillRect(0, 0, Wd, Hh);
      bgWall = c;
      // 나무 작업대 (꾸미기 화면: 돌림판이 놓인 높이부터)
      const c2 = document.createElement('canvas'); c2.width = c.width; c2.height = c.height;
      const b2 = c2.getContext('2d'); b2.drawImage(c, 0, 0); b2.scale(dpr, dpr);
      drawCounter(b2, Wd, Hh, Math.round(Lay.cy + Lay.rx * 0.42));
      bg = c2;
      bgKey = Wd + 'x' + Hh + ':' + dpr + ':' + Math.round(Lay.cy + Lay.rx * 0.42);
    }
    function drawCounter(b, Wd, Hh, ty) {
      const wg = b.createLinearGradient(0, ty, 0, Hh); wg.addColorStop(0, '#6b4129'); wg.addColorStop(0.08, '#5a351f'); wg.addColorStop(1, '#2c190f');
      b.fillStyle = wg; b.fillRect(0, ty, Wd, Hh - ty);
      b.fillStyle = 'rgba(255,220,170,0.18)'; b.fillRect(0, ty, Wd, 2);
      b.strokeStyle = 'rgba(30,15,8,0.35)'; b.lineWidth = 1;
      for (let i = 0; i < 9; i++) { const y = ty + 12 + i * ((Hh - ty) / 9); b.beginPath(); b.moveTo(0, y); for (let x = 0; x <= Wd; x += 30) b.lineTo(x, y + Math.sin(x * 0.03 + i) * 2.5); b.stroke(); }
    }

    /* ---- 케이크 그림 캐시 ---- */
    function cakeImg(str, rx, extra, gt) {
      const key = str + '|' + rx.toFixed(1) + '|' + (extra || '') + '|' + (gt || 0);
      let e = cache.get(key);
      if (e) return e;
      const dpr = cv.dpr, w = rx * 2.7, hh = rx * 2.5, ox = w / 2, oy = rx * (SQ + 0.62);
      const c = document.createElement('canvas'); c.width = Math.ceil(w * dpr); c.height = Math.ceil(hh * dpr);
      const g = c.getContext('2d'); g.scale(dpr, dpr);
      const opt = extra === 'skipW' ? { skipW: 1 } : extra && extra[0] === 's' ? { skip: +extra.slice(1) } : {};
      if (gt) opt.guide = (gg) => drawGuides(gg, ox, oy, rx, gt);
      const fl = drawCake(g, dec(str), ox, oy, rx, opt);
      e = { c, ox, oy, w, h: hh, fl };
      if (cache.size > 24) cache.delete(cache.keys().next().value);
      cache.set(key, e);
      return e;
    }
    function putCake(str, cx, cy, rx, extra, flames, gt) {
      const e = cakeImg(str, rx, extra, gt);
      ctx.drawImage(e.c, cx - e.ox, cy - e.oy, e.w, e.h);
      if (flames !== false) e.fl.forEach(([x, y, R], i) => drawFlame(ctx, cx - e.ox + x, cy - e.oy + y, R, clock / 1000, i * 1.7));
    }

    /* ---- 팔레트 ---- */
    function icon(draw) {
      const c = h('canvas'), d = 2; c.width = 30 * d; c.height = 30 * d;
      const g = c.getContext('2d'); g.scale(d, d); draw(g); return c;
    }
    function palItem(cls, label, draw, onclick, title) {
      const b = h('button', { class: 'cdk-it' + (cls ? ' ' + cls : ''), type: 'button', title: title || label, 'aria-label': title || label, onclick });
      if (draw) b.append(icon(draw));
      b.append(h('span', { text: label }));
      return b;
    }
    let palItems = [];
    function buildPal() {
      pal.innerHTML = ''; palItems = [];
      const add = (el, sel) => { pal.append(el); palItems.push({ el, sel }); };
      if (tab === 0) {
        SHEETS.forEach((S, i) => add(palItem('', S.n, (g) => { ell(g, 15, 18, 13, 8, shade(S.c, -0.25)); g.fillRect(2, 12, 26, 6); ell(g, 15, 12, 13, 8, S.c); ell(g, 11, 10, 5, 2.5, 'rgba(255,255,255,0.35)'); }, () => setSheet(i), '시트 ' + S.n), () => cur().s === i));
      } else if (tab === 1) {
        TIPS.forEach((tp, i) => add(palItem('', tp.n.replace(' 깍지', ''), (g) => drawBlob(g, i, '#fff6e8', 15, 19, 0, 10), () => setTip(i), tp.n), () => cur().tp === i));
        pal.append(h('div', { class: 'cdk-sep' }));
        CREAMS.forEach((C, i) => add(palItem('', C.n, (g) => drawBlob(g, cur().tp, C.c, 15, 19, 0, 10), () => { tool.cream = i; Snd.tapk(); refreshPal(); }, C.n + ' 크림'), () => tool.cream === i));
        add(palItem('', '지우개', (g) => { g.fillStyle = '#f2a0a8'; rr(g, 5, 9, 20, 12, 3); g.fill(); g.fillStyle = '#e8e2d6'; rr(g, 15, 9, 10, 12, 3); g.fill(); }, () => { tool.cream = -1; Snd.tapk(); refreshPal(); }, '크림 지우개'), () => tool.cream === -1);
      } else if (tab === 2) {
        TOPS.forEach((tp, i) => add(palItem('', TSN[i], (g) => drawTop(g, i, 15, i === T.CD ? 29 : 25, i === T.CD ? 5.6 : i === T.PL ? 10 : 12), () => { tool.top = i; Snd.tapk(); refreshPal(); }, tp.n), () => tool.top === i));
      } else {
        [1, 2, 3].forEach((i) => add(palItem('', SPR[i].sn, (g) => { const cols = SPRC[i] || ['#fff']; for (let k = 0; k < 16; k++) { const a = k * 2.4, d = 3 + (k % 5) * 2.2; g.fillStyle = cols[k % cols.length]; g.fillRect(15 + Math.cos(a) * d - 1.5, 15 + Math.sin(a) * d - 1, i === 3 ? 2 : 4, 2); } }, () => setSpr(i), SPR[i].n), () => cur().sp === i));
        pal.append(h('div', { class: 'cdk-sep' }));
        WORDS.forEach((w, i) => add(palItem('wide', w, (g) => { g.fillStyle = '#fff6e6'; g.beginPath(); g.ellipse(15, 15, 13, 7, 0, 0, 7); g.fill(); g.fillStyle = '#4a2716'; g.fillRect(8, 14, 14, 2); }, () => setWord(i), '글씨판 ' + w), () => cur().w === i));
      }
      palKey = tab + ':' + (tab === 1 ? cur().tp : '');
      refreshPal();
    }
    function refreshPal() { palItems.forEach((p) => p.el.classList.toggle('on', !!p.sel())); tabBtns.forEach((b, i) => b.classList.toggle('on', i === tab)); }
    pal.addEventListener('wheel', (e) => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { pal.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
    function setTab(i) { if (tab === i) return; tab = i; Snd.tapk(); buildPal(); pal.scrollLeft = 0; scrollToSel(); }
    function scrollToSel() { const p = palItems.find((q) => q.sel()); if (p) { const el = p.el; const l = el.offsetLeft - pal.clientWidth / 2 + el.offsetWidth / 2; pal.scrollLeft = Math.max(0, l); } }

    /* ---- 꾸미기 동작 ---- */
    const cur = () => W(Math.max(0, editSeat() >= 0 ? editSeat() : 0)).c;
    function pushUndo(w) { w.undo.push(enc(w.c)); if (w.undo.length > 60) w.undo.shift(); }
    function changed(w) {
      w.str = enc(w.c);
      const o = st && st.o; if (!o) return;
      const rows = orderRows(o), done = rows.map((r) => (rowProg(o, r, w.c)[0] ? 1 : 0)).join('');
      if (progDone && done.length === progDone.length) for (let i = 0; i < done.length; i++) if (done[i] === '1' && progDone[i] === '0') { Snd.ding(); const ch = Lay.chips[i]; if (ch) burst(Lay.card.x + 8 + ch.x + 12, Lay.card.y + 30 + ch.y + 11, '#9fe3a8', 6); break; }
      progDone = done;
    }
    function edit(fn) { const s = editSeat(); if (s < 0) return; const w = W(s); pushUndo(w); fn(w.c); changed(w); refreshPal(); }
    function setSheet(i) { if (cur().s === i) return; edit((c) => { c.s = i; }); Snd.splat(); api.buzz(8); }
    function setTip(i) { if (cur().tp === i) return; edit((c) => { c.tp = i; }); Snd.squish(); buildPal(); }
    function setSpr(i) { edit((c) => { c.sp = c.sp === i ? 0 : i; }); Snd.noise(0.3, 'highpass', 4000, 2000, 0.07); }
    function setWord(i) { edit((c) => { if (c.w === i) c.w = -1; else { if (c.w < 0) { c.wx = qv(0); c.wy = qv(0.14); } c.w = i; } }); Snd.pop(); }
    function undo() {
      const s = editSeat(); if (s < 0) return;
      const w = W(s); if (!w.undo.length) { api.toast('되돌릴 게 없어요'); return; }
      w.c = dec(w.undo.pop()); changed(w); refreshPal(); if (tab === 1) buildPal(); Snd.plop();
    }
    function pressDone() {
      const s = editSeat(); if (s < 0) return;
      const now = performance.now();
      if (now - armedT < 2600) { armedT = 0; doneBtn.classList.remove('armed'); doneBtn.textContent = '완성!'; submitCake(s, false); return; }
      armedT = now; doneBtn.classList.add('armed'); doneBtn.textContent = '한 번 더!'; api.buzz(10); Snd.tapk();
    }
    function submitCake(seat, auto) {
      if (!st || !st.o) return;
      const w = W(seat), t = Math.min(st.o.tl, Math.round(elapsed(seat)));
      drag = null; sent[seat] = roundKey;
      if (multi()) active = -1;
      Snd.done(); api.buzz(25);
      if (auto) api.toast('시간 끝! 지금 모습 그대로 냈어요');
      api.actAs(seat, { k: 'c', c: enc(w.c), t });
      sync();
    }
    function pressNext() {
      if (!st || st.ph !== 'j' || !st.last) return;
      if (!revDone) { revT = 99; return; }
      const id = st.last.id;
      const seats = api.mySeats().filter((i) => !st.rd[i] && readySent[i] !== id);
      seats.forEach((i) => { readySent[i] = id; });
      Snd.tapk();
      seats.forEach((i) => { if (st && st.ph === 'j' && !st.rd[i]) api.actAs(i, { k: 'n' }); });
      sync();
    }

    /* ---- 손가락 ---- */
    const toUV = (p) => ({ u: (p.x - Lay.cx) / Lay.rx, v: (p.y - Lay.cy) / (Lay.rx * SQ) });
    function snapUV(u, v) {
      let r = Math.hypot(u, v), a = Math.atan2(v, u);
      if (r < 0.27) { if (r > 0.24) r = 0.24; }
      else { r = r < 0.62 ? 0.45 : 0.78; a = Math.round(a / (Math.PI / 12)) * (Math.PI / 12); }
      return [qv(Math.cos(a) * r), qv(Math.sin(a) * r)];
    }
    function hitItem(c, p) {
      const rx = Lay.rx, ry = rx * SQ;
      if (c.w >= 0) { const x = Lay.cx + c.wx * rx, y = Lay.cy + c.wy * ry; if (Math.abs(p.x - x) < (pw(c.w) * rx) / 2 + 4 && Math.abs(p.y - y) < PH * ry + 8) return { w: 1 }; }
      let best = null, bd = 1e9;
      c.it.forEach((it, i) => {
        const R = TOPS[it[0]].s * rx * TS, x = Lay.cx + it[1] * rx, y = Lay.cy + it[2] * ry - R * TOPS[it[0]].hc;
        const d = Math.hypot(p.x - x, p.y - y), lim = Math.max(20, R * 1.25);
        if (d < lim && d - it[2] * 4 < bd) { bd = d - it[2] * 4; best = { i }; }
      });
      return best;
    }
    function pipeAt(w, uv) {
      const a = Math.atan2(uv.v, uv.u), sec = Math.floor((((a + 2 * Math.PI) % (2 * Math.PI)) / (2 * Math.PI)) * NS) % NS;
      const ring = w.c[drag.ring], val = tool.cream;
      const fill = (i) => { if (ring[i] !== val) { ring[i] = val; drag.changed = true; } };
      if (drag.last < 0) fill(sec);
      else if (drag.last !== sec) {
        let d = (sec - drag.last + NS) % NS; const dir = d <= NS / 2 ? 1 : -1; if (dir < 0) d = NS - d;
        for (let k = 1; k <= d; k++) fill((drag.last + dir * k + NS) % NS);
      }
      if (drag.last !== sec && drag.changed) { Snd.squish(); const R = RING_R[drag.ring]; if (Math.random() < 0.5) burst(Lay.cx + Math.cos(a) * R * Lay.rx, Lay.cy + Math.sin(a) * R * Lay.rx * SQ, val >= 0 ? CREAMS[val].c : '#f2a0a8', 2); }
      drag.last = sec;
      if (drag.changed) w.str = enc(w.c);
    }
    function onDown(e) {
      const p = cv.local(e), m = mode();
      if (m === 'rev') {
        if (!revDone) { revT = 99; return; }
        const cell = (Lay.cells || []).findIndex((c) => p.x >= c.x && p.x <= c.x + c.w && p.y >= c.y && p.y <= c.y + c.h);
        if (cell >= 0) openDetail(cell);
        return;
      }
      if (m !== 'edit') return;
      if (p.x >= Lay.card.x && p.x <= Lay.card.x + Lay.card.w && p.y >= Lay.card.y && p.y <= Lay.card.y + Lay.card.h) { openOrder(); return; }
      const seat = editSeat(), w = W(seat), uv = toUV(p), r = Math.hypot(uv.u, uv.v);
      if (tab === 1) {
        if (r > 1.3) return;
        pushUndo(w);
        drag = { kind: 'cream', ring: r >= 0.6 ? 'ro' : 'ri', last: -1, changed: false, id: e.pointerId };
        pipeAt(w, uv);
      } else if (tab === 2 || tab === 3) {
        const hit = hitItem(w.c, p);
        if (hit) {
          drag = { kind: 'move', w: !!hit.w, i: hit.i, sx: p.x, sy: p.y, moved: false, id: e.pointerId, uv: hit.w ? [w.c.wx, w.c.wy] : [w.c.it[hit.i][1], w.c.it[hit.i][2]], out: false };
        } else if (tab === 2) {
          if (r > 1.12) return;
          drag = { kind: 'place', k: tool.top, uv: snapUV(uv.u, uv.v), out: false, id: e.pointerId };
        } else { hintFlash = 2; return; }
      } else { hintFlash = 2; if (r < 1.1) api.toast('아래에서 시트 색을 골라요'); return; }
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
    }
    function onMove(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const seat = editSeat(); if (seat < 0) { drag = null; return; }
      const p = cv.local(e), uv = toUV(p), r = Math.hypot(uv.u, uv.v), w = W(seat);
      if (drag.kind === 'cream') pipeAt(w, uv);
      else if (drag.kind === 'place') { drag.out = r > 1.12; if (!drag.out) drag.uv = snapUV(uv.u, uv.v); }
      else if (drag.kind === 'move') {
        if (!drag.moved && Math.hypot(p.x - drag.sx, p.y - drag.sy) < 6) return;
        drag.moved = true; drag.out = r > 1.12;
        if (!drag.out) drag.uv = drag.w ? [qv(Math.max(-0.75, Math.min(0.75, uv.u))), qv(Math.max(-0.7, Math.min(0.7, uv.v)))] : snapUV(uv.u, uv.v);
      }
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag; drag = null;
      const seat = editSeat(); if (seat < 0) return;
      const w = W(seat);
      if (d.kind === 'cream') { if (!d.changed) w.undo.pop(); else changed(w); return; }
      if (d.kind === 'place') {
        if (d.out) return;
        if (w.c.it.length >= MAXT) { api.toast('토핑은 ' + MAXT + '개까지 올릴 수 있어요'); return; }
        pushUndo(w); w.c.it.push([d.k, d.uv[0], d.uv[1]]); changed(w);
        Snd.pop(); api.buzz(8);
        burst(Lay.cx + d.uv[0] * Lay.rx, Lay.cy + d.uv[1] * Lay.rx * SQ - 6, '#fff3c8', 4);
        return;
      }
      if (d.kind === 'move' && d.moved) {
        pushUndo(w);
        if (d.out) { if (d.w) w.c.w = -1; else w.c.it.splice(d.i, 1); Snd.plop(); api.buzz(12); }
        else if (d.w) { w.c.wx = d.uv[0]; w.c.wy = d.uv[1]; Snd.pop(); }
        else { w.c.it[d.i][1] = d.uv[0]; w.c.it[d.i][2] = d.uv[1]; Snd.pop(); }
        changed(w); refreshPal();
      }
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', (e) => { if (drag && e.pointerId === drag.id) { if (drag.kind === 'cream' && drag.changed) changed(W(editSeat())); drag = null; } });

    /* ---- 주문서 크게 / 점수 자세히 ---- */
    function closeOv() { if (orderEl) { orderEl.remove(); orderEl = null; } if (detailEl) { detailEl.remove(); detailEl = null; } }
    function sheetOv(title, kids) {
      const x = h('button', { class: 'cdk-x', type: 'button', 'aria-label': '닫기', text: '✕' });
      const ov = h('div', { class: 'cdk-ov' }, h('div', { class: 'cdk-sheet' }, h('div', { class: 'cdk-head' }, h('h3', { text: title }), x), ...kids));
      ov.addEventListener('click', (e) => { if (e.target === ov || e.target === x) closeOv(); });
      root.append(ov);
      return ov;
    }
    function openOrder() {
      if (!st || !st.o) return;
      closeOv(); Snd.tapk();
      const o = st.o, s = editSeat(), c = s >= 0 ? W(s).c : null;
      orderEl = sheetOv(TPL[o.tp].n, [
        h('div', { class: 'cdk-note', text: CUST[o.cu] + '의 주문 · 제한 시간 ' + o.tl + '초' }),
        ...orderRows(o).map((r) => { const ok = c && rowProg(o, r, c)[0]; return h('div', { class: 'cdk-li' + (ok ? ' ok' : ''), text: (ok ? '✓ ' : '• ') + r.l }); }),
        h('div', { class: 'cdk-note', text: '주문에 없는 토핑·크림·가루는 감점이에요. 자리: 가운데(안쪽 작은 원) · 중간 고리 · 바깥 고리 — 토핑 탭에서 점선으로 보여요. 빨리 「완성」하면 보너스(최대 +4)!' }),
      ]);
    }
    function openDetail(i) {
      if (!st || !st.last) return;
      closeOv(); Snd.tapk();
      const L0 = st.last, c = dec(L0.ck[i]), det = judge(L0.o, c, L0.tt[i], L0.o.tl);
      const pc = h('canvas'); const dpr = Math.min(2, window.devicePixelRatio || 1), cw = 300, chh = 210;
      pc.width = cw * dpr; pc.height = chh * dpr; const g = pc.getContext('2d'); g.scale(dpr, dpr);
      g.fillStyle = '#241a2b'; g.fillRect(0, 0, cw, chh);
      drawCake(g, c, cw / 2, 92, 92);
      const items = det.loss.filter((x) => x[0] >= 0.5).slice(0, 6).map((x) => h('div', { class: 'cdk-li', text: '−' + Math.round(x[0]) + '  ' + x[1] }));
      detailEl = sheetOv(nm(i) + ' · ' + L0.s[i] + '점', [pc,
        h('div', { class: 'cdk-note', text: '주문 정확도 ' + det.acc + '% · 감점 ' + det.pen + (det.sym ? ' · 균형 보너스 +' + det.sym : '') + (det.tb ? ' · 빠름 보너스 +' + det.tb : '') + ' · ' + L0.tt[i] + '초 걸림' }),
        ...(items.length ? items : [h('div', { class: 'cdk-li ok', text: '깎인 점수가 없어요. 완벽!' })])]);
    }

    /* ---- 한 폰 여럿: 넘겨주기 화면 ---- */
    function syncHand() {
      let want = -1;
      if (st && st.ph === 'd' && multi()) { const p = pendingLocal(); if (p.length && !p.includes(active)) want = p[0]; }
      const key = want + ':' + roundKey;
      if (key === handKey) return;
      handKey = key;
      if (handEl) { handEl.remove(); handEl = null; }
      if (want < 0) return;
      closeOv();
      handEl = h('div', { class: 'cdk-hand' },
        h('span', { class: 'dot', style: { '--c': col(want), width: '18px', height: '18px' } }),
        h('div', { class: 'big', text: nm(want) }),
        h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: '주문 ' + (st.r + 1) + '/' + st.R + ' · ' + TPL[st.o.tp].n }),
        h('div', { class: 'muted', text: '내 차례에 혼자 꾸며요. 다른 사람은 보지 마세요!' }),
        h('button', { class: 'btn primary', type: 'button', text: '꾸미기 시작', onclick: () => { active = want; api.sfx('click'); handKey = ''; sync(); } }));
      root.append(handEl);
    }

    /* ---- 화면 상태 맞추기 ---- */
    function sync() {
      const m = mode();
      bot.classList.toggle('cdk-hid', m !== 'edit');
      revBar.classList.toggle('cdk-hid', m !== 'rev' || !st || st.ph !== 'j');
      if (m === 'edit') {
        const s = editSeat();
        if (tStart[s] == null) { tStart[s] = clock || performance.now(); tPause[s] = 0; lastTick = -1; progDone = ''; changed(W(s)); }
        if (curMode !== 'edit' || palKey.split(':')[0] !== String(tab)) buildPal(); else refreshPal();
      }
      if (m !== 'edit' && orderEl) closeOv();
      if (m !== 'edit') { armedT = 0; doneBtn.classList.remove('armed'); doneBtn.textContent = '완성!'; }
      syncHand();
      syncRevBar();
      curMode = m;
    }
    function syncRevBar() {
      if (!st || st.ph !== 'j' || !st.last) return;
      const mine = api.mySeats(), pend = mine.filter((i) => !st.rd[i] && readySent[i] !== st.last.id);
      const ready = st.rd.filter((x) => x).length, fin = st.last.r + 1 >= st.R;
      if (pend.length) {
        revBtn.classList.remove('cdk-hid'); revMsg.classList.add('cdk-hid');
        const left = autoT >= 0 ? Math.ceil(autoT) : -1;
        revBtn.textContent = (!revDone ? '건너뛰기 ▶▶' : fin ? '최종 결과 보기' : '다음 주문 받기') + (revDone && left >= 0 && left <= 10 ? ' (' + left + ')' : '');
      } else {
        revBtn.classList.add('cdk-hid'); revMsg.classList.remove('cdk-hid');
        revMsg.textContent = mine.length ? '다른 사람을 기다려요 (' + ready + '/' + st.n + ')' : '심사 중… (' + ready + '/' + st.n + ')';
      }
    }

    /* ---- 파티클 ---- */
    function burst(x, y, c, n) { for (let i = 0; i < n; i++) { if (parts.length > 120) parts.shift(); const a = Math.random() * 7, v = 30 + Math.random() * 60; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, t: 0, life: 0.5 + Math.random() * 0.4, c, s: 1.5 + Math.random() * 2 }); } }
    function confetti(x, y, n) { const cs = ['#ffd166', '#ff7aa2', '#7ee0b5', '#9fb8ff', '#fff']; for (let i = 0; i < n; i++) { const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.2, v = 90 + Math.random() * 140; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, life: 1.2 + Math.random() * 0.6, c: cs[i % cs.length], s: 2 + Math.random() * 2.5, g: 1 }); } }
    function stepParts(dt) {
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.t += dt; if (p.t >= p.life) { parts.splice(i, 1); continue; }
        p.x += p.vx * dt; p.y += p.vy * dt; p.vy += (p.g ? 220 : 120) * dt;
        ctx.globalAlpha = 1 - p.t / p.life; ctx.fillStyle = p.c;
        if (p.g) ctx.fillRect(p.x, p.y, p.s * 1.6, p.s); else { ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, 7); ctx.fill(); }
      }
      ctx.globalAlpha = 1;
    }

    /* ---- 그리기: 위쪽 줄 · 주문서 ---- */
    function drawTopStrip(m) {
      const Wd = Lay.W;
      ctx.font = '700 12px ' + FONT; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      const lab = st.ph === 'd' ? '주문 ' + (st.r + 1) + '/' + st.R : '심사 ' + ((st.last ? st.last.r : st.r) + 1) + '/' + st.R;
      const lw = ctx.measureText(lab).width + 16;
      ctx.fillStyle = 'rgba(227,174,69,0.18)'; rr(ctx, 8, 6, lw, 22, 11); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.fillText(lab, 16, 17.5);
      // 사람들 상태
      const n = st.n, dw = 24;
      let x = Wd - 8 - n * dw;
      if (n > 1) for (let i = 0; i < n; i++) {
        const done = st.ph === 'd' ? st.ck[i] != null || sent[i] === roundKey : !!st.rd[i];
        const cx = x + i * dw + dw / 2;
        ctx.beginPath(); ctx.arc(cx, 17, 9.5, 0, 7); ctx.fillStyle = col(i); ctx.fill();
        ctx.lineWidth = 2; ctx.strokeStyle = done ? '#9fe3a8' : 'rgba(0,0,0,0.35)'; ctx.stroke();
        ctx.fillStyle = '#17131f'; ctx.font = '800 11px ' + FONT; ctx.textAlign = 'center';
        if (done) ctx.fillText('✓', cx, 17.5);
        else if (st.ph === 'd') { const k = Math.floor(clock / 300 + i) % 3; ctx.fillText('·'.repeat(k + 1), cx, 16); }
        ctx.textAlign = 'left';
      }
      else { ctx.font = '700 12px ' + MONO; ctx.textAlign = 'right'; ctx.fillStyle = '#ab9fb8'; ctx.fillText('합계 ' + st.sc[0], Wd - 10, 17.5); ctx.textAlign = 'left'; }
      // 타이머
      const tx0 = 8 + lw + 8, tx1 = (n > 1 ? x : Wd - 76) - 8;
      if (m === 'edit' && tx1 - tx0 > 40) {
        const s = editSeat(), left = Math.max(0, st.o.tl - elapsed(s)), f = left / st.o.tl, warn = left <= 10;
        ctx.fillStyle = 'rgba(255,255,255,0.08)'; rr(ctx, tx0, 11, tx1 - tx0, 12, 6); ctx.fill();
        ctx.fillStyle = warn ? '#ee6a55' : '#7ee0b5'; rr(ctx, tx0, 11, Math.max(12, (tx1 - tx0) * f), 12, 6); ctx.fill();
        ctx.font = '700 11px ' + MONO; ctx.fillStyle = '#17131f'; ctx.textAlign = 'left';
        const tt = Math.ceil(left) + '초';
        if ((tx1 - tx0) * f > 40) ctx.fillText(tt, tx0 + 6, 17.5); else { ctx.fillStyle = warn ? '#ee6a55' : '#f2e9d8'; ctx.fillText(tt, tx0 + Math.max(12, (tx1 - tx0) * f) + 4, 17.5); }
      } else if (m !== 'edit' && st.ph === 'd' && tx1 - tx0 > 60) {
        ctx.font = '600 12px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'center';
        ctx.fillText(st.ck.filter((x) => x != null).length + '/' + n + ' 완성', (tx0 + tx1) / 2, 17.5); ctx.textAlign = 'left';
      }
    }
    function drawOrderCard(c) {
      const o = st.o, k = Lay.card, slide = banner > 0 ? Math.pow(banner, 2) * -60 : 0;
      ctx.save(); ctx.translate(0, slide); ctx.globalAlpha = banner > 0 ? 1 - banner * 0.6 : 1;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; rr(ctx, k.x + 2, k.y + 3, k.w, k.h, 12); ctx.fill();
      const pg = ctx.createLinearGradient(0, k.y, 0, k.y + k.h); pg.addColorStop(0, '#fff8ea'); pg.addColorStop(1, '#f3e6cc');
      ctx.fillStyle = pg; rr(ctx, k.x, k.y, k.w, k.h, 12); ctx.fill();
      ctx.strokeStyle = 'rgba(200,120,140,0.5)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1; rr(ctx, k.x + 4, k.y + 4, k.w - 8, k.h - 8, 9); ctx.stroke(); ctx.setLineDash([]);
      // 핀
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(k.x + k.w / 2, k.y + 2, 4, 0, 7); ctx.fill();
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      ctx.font = '13px ' + DISP; ctx.fillStyle = '#c2185b'; ctx.fillText('주문서', k.x + 12, k.y + 17);
      const tw = ctx.measureText('주문서').width;
      ctx.font = '700 14px ' + FONT; ctx.fillStyle = '#3a2216'; ctx.fillText(TPL[o.tp].n, k.x + 12 + tw + 8, k.y + 17);
      ctx.font = '600 11px ' + FONT; ctx.fillStyle = '#8a6a5a'; ctx.textAlign = 'right';
      const nmw = ctx.measureText(TPL[o.tp].n).width;
      if (k.x + 12 + tw + 8 + nmw + 14 + ctx.measureText(CUST[o.cu] + ' ⓘ').width < k.x + k.w - 10) ctx.fillText(CUST[o.cu] + ' ⓘ', k.x + k.w - 10, k.y + 17);
      else ctx.fillText('ⓘ', k.x + k.w - 10, k.y + 17);
      ctx.textAlign = 'left';
      Lay.chips.forEach((ch) => {
        const x = k.x + 8 + ch.x, y = k.y + 30 + ch.y, r = ch.r;
        const [ok, pr] = c ? rowProg(o, r, c) : [false, ''];
        ctx.fillStyle = ok ? 'rgba(80,170,100,0.18)' : 'rgba(120,70,50,0.08)'; rr(ctx, x, y, ch.w, 22, 11); ctx.fill();
        chipIcon(r, o, x + 13, y + 11);
        ctx.font = '600 12px ' + FONT; ctx.fillStyle = '#3a2216'; ctx.fillText(r.s, x + 26, y + 11.5);
        ctx.textAlign = 'right';
        if (ok) { ctx.fillStyle = '#2f8a48'; ctx.font = '800 13px ' + FONT; ctx.fillText('✓', x + ch.w - 8, y + 11.5); }
        else if (c && pr) { ctx.fillStyle = pr[0] === '+' ? '#c0392b' : '#9a7a6a'; ctx.font = '700 10.5px ' + MONO; ctx.fillText(pr, x + ch.w - 6, y + 11.5); }
        ctx.textAlign = 'left';
      });
      ctx.restore();
    }
    function chipIcon(r, o, x, y) {
      switch (r.t) {
        case 'sheet': ctx.beginPath(); ctx.arc(x, y, 7, 0, 7); ctx.fillStyle = SHEETS[o.s].c; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1; ctx.stroke(); break;
        case 'ro': case 'ri': {
          const tg = r.t === 'ro' ? ringTarget(o.ro) : Array(NS).fill(o.ri), R = r.t === 'ro' ? 6.5 : 4;
          if (r.t === 'ri') { ctx.beginPath(); ctx.arc(x, y, 7.5, 0, 7); ctx.strokeStyle = 'rgba(0,0,0,0.2)'; ctx.lineWidth = 1; ctx.stroke(); }
          for (let i = 0; i < NS; i += 2) { const a = ((i + 0.5) / NS) * 2 * Math.PI; ctx.beginPath(); ctx.arc(x + Math.cos(a) * R, y + Math.sin(a) * R, 1.9, 0, 7); ctx.fillStyle = CREAMS[tg[i]].c; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 0.6; ctx.stroke(); }
          break;
        }
        case 'tip': drawBlob(ctx, o.tip, '#fff1dc', x, y + 3, 0, 6.5); break;
        case 'it': { const k = o.it[r.i][0]; drawTop(ctx, k, x, y + (k === T.CD ? 9 : 7), k === T.CD ? 3.6 : k === T.PL ? 6.5 : 7.5); break; }
        case 'sp': { const cols = SPRC[o.sp] || ['#ffffff']; for (let i = 0; i < 9; i++) { const a = i * 2.3, d = 1 + (i % 4) * 1.8; ctx.fillStyle = o.sp === 3 ? '#c9b8a6' : cols[i % cols.length]; ctx.fillRect(x + Math.cos(a) * d - 1.5, y + Math.sin(a) * d - 0.8, o.sp === 3 ? 2 : 3.5, 1.8); } break; }
        case 'w': ctx.beginPath(); ctx.ellipse(x, y, 8, 5, 0, 0, 7); ctx.fillStyle = '#fffaf0'; ctx.fill(); ctx.strokeStyle = '#c9a77a'; ctx.lineWidth = 1; ctx.stroke(); ctx.fillStyle = '#4a2716'; ctx.fillRect(x - 4.5, y - 0.8, 9, 1.6); break;
      }
    }

    /* ---- 그리기: 꾸미기 ---- */
    function drawGuides(g, ox, oy, rx, tab) {
      const ry = rx * SQ;
      g.save();
      if (tab === 2) {
        g.setLineDash([5, 5]); g.lineWidth = 1.2; g.strokeStyle = 'rgba(80,40,30,0.32)';
        [0.27, 0.62].forEach((r) => { g.beginPath(); g.ellipse(ox, oy, r * rx, r * ry, 0, 0, 7); g.stroke(); });
        g.setLineDash([]);
        g.fillStyle = 'rgba(80,40,30,0.28)';
        [0.45, 0.78].forEach((r) => { for (let i = 0; i < 24; i++) { const a = (i * Math.PI) / 12; g.beginPath(); g.arc(ox + Math.cos(a) * r * rx, oy + Math.sin(a) * r * ry, 1.6, 0, 7); g.fill(); } });
        g.font = '700 10px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = 'rgba(70,35,25,0.55)';
        const la = Math.PI * 1.125, lc = Math.cos(la), ls = Math.sin(la);
        [['가운데', 0.15], ['중간', 0.45], ['바깥', 0.78]].forEach(([t, r]) => g.fillText(t, ox + lc * r * rx, oy + ls * r * ry));
      } else if (tab === 1) {
        g.setLineDash([3, 5]); g.lineWidth = 2; g.strokeStyle = 'rgba(255,255,255,0.4)';
        [RING_R.ro, RING_R.ri].forEach((r) => { g.beginPath(); g.ellipse(ox, oy, r * rx, r * ry, 0, 0, 7); g.stroke(); });
        g.setLineDash([]);
        g.strokeStyle = 'rgba(80,40,30,0.5)'; g.lineWidth = 1.5;
        for (let i = 0; i < 8; i++) { const a = (i * Math.PI) / 4; g.beginPath(); g.moveTo(ox + Math.cos(a) * 0.985 * rx, oy + Math.sin(a) * 0.985 * ry); g.lineTo(ox + Math.cos(a) * 1.05 * rx, oy + Math.sin(a) * 1.05 * ry); g.stroke(); }
      }
      g.restore();
    }
    function drawEdit() {
      const s = editSeat(), w = W(s), rx = Lay.rx;
      drawOrderCard(w.c);
      // 케이크 (끌고 있는 토핑은 빼고 그림)
      const ex = drag && drag.kind === 'move' && drag.moved ? (drag.w ? 'skipW' : 's' + drag.i) : '';
      putCake(w.str, Lay.cx, Lay.cy, rx, ex, true, tab);
      // 미리보기
      if (drag && (drag.kind === 'place' || (drag.kind === 'move' && drag.moved))) {
        ctx.save(); ctx.globalAlpha = drag.out ? 0.35 : 0.85;
        if (drag.kind === 'move' && drag.w) drawPlaque(ctx, w.c.w, Lay.cx + drag.uv[0] * rx, Lay.cy + drag.uv[1] * rx * SQ, rx);
        else {
          const k = drag.kind === 'place' ? drag.k : w.c.it[drag.i][0], x = Lay.cx + drag.uv[0] * rx, y = Lay.cy + drag.uv[1] * rx * SQ;
          if (!drag.out) { ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(x, y, TOPS[k].s * rx * 1.5, TOPS[k].s * rx * 0.7, 0, 0, 7); ctx.stroke(); }
          drawTop(ctx, k, x, y, TOPS[k].s * rx * TS);
        }
        ctx.restore();
        if (drag.out && drag.kind === 'move') { ctx.font = '700 13px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = '#ee6a55'; ctx.fillText('놓으면 빠져요', Lay.cx, Lay.cy - rx * SQ - 10); }
      }
      // 도움말 한 줄
      ctx.font = '600 12px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = hintFlash > 0 ? '#ffd166' : 'rgba(242,233,216,0.72)';
      ctx.fillText(HINTS[tab], Lay.W / 2, Math.min(Lay.H - Lay.botH - 10, Lay.hintY));
      if (banner > 0) {
        ctx.save(); ctx.globalAlpha = Math.min(1, banner * 2);
        ctx.font = '26px ' + DISP; ctx.fillStyle = '#ffd166'; ctx.strokeStyle = 'rgba(40,20,30,0.8)'; ctx.lineWidth = 5;
        const y = Lay.cy - 10; ctx.strokeText('새 주문 도착!', Lay.W / 2, y); ctx.fillText('새 주문 도착!', Lay.W / 2, y);
        ctx.restore();
      }
    }

    /* ---- 그리기: 기다리기 · 심사 격자 ---- */
    function gridCells(n, top, bottom) {
      const Wd = Lay.W, cols = n === 1 ? 1 : 2, rows = n <= 2 ? 1 : 2;
      const cw = (Wd - 16 - (cols - 1) * 8) / cols;
      let ch = (bottom - top - (rows - 1) * 8) / rows;
      const rx = Math.max(26, Math.min(cw * 0.4, (ch - 92) / 1.98, 150));
      ch = Math.min(ch, 92 + 1.98 * rx + 8);
      const y0 = top + Math.max(0, (bottom - top - rows * ch - (rows - 1) * 8) / 2) * 0.6;
      const cells = [];
      for (let i = 0; i < n; i++) {
        const r = Math.floor(i / cols), c = i % cols;
        let x = 8 + c * (cw + 8); if (n === 3 && i === 2) x = (Wd - cw) / 2;
        cells.push({ x, y: y0 + r * (ch + 8), w: cw, h: ch, rx });
      }
      return cells;
    }
    function cellFrame(c, i, hl) {
      ctx.fillStyle = hl ? 'rgba(227,174,69,0.16)' : 'rgba(255,255,255,0.045)'; rr(ctx, c.x, c.y, c.w, c.h, 14); ctx.fill();
      if (hl) { ctx.strokeStyle = 'rgba(227,174,69,0.75)'; ctx.lineWidth = 2; rr(ctx, c.x, c.y, c.w, c.h, 14); ctx.stroke(); }
      ctx.beginPath(); ctx.arc(c.x + 14, c.y + 15, 6, 0, 7); ctx.fillStyle = col(i); ctx.fill();
      ctx.font = '700 13px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
      let name = nm(i); const maxW = c.w - 84;
      while (name.length > 1 && ctx.measureText(name).width > maxW) name = name.slice(0, -1);
      ctx.fillText(name + (name !== nm(i) ? '…' : ''), c.x + 25, c.y + 15.5);
    }
    const cakeCY = (c) => c.y + 30 + c.rx * 0.85;
    function drawWait() {
      const o = st.o;
      if (o) drawOrderCard(null);
      const top = o ? Lay.card.y + Lay.card.h + 8 : 36;
      const cells = gridCells(st.n, top, Lay.H - 12);
      cells.forEach((c, i) => {
        const doneS = st.ck[i] != null || sent[i] === roundKey;
        cellFrame(c, i, false);
        const cx = c.x + c.w / 2, cy = cakeCY(c);
        const mine = api.canAct(i) && !multi();
        if (doneS) {
          const str = st.ck[i] || (work[i] && work[i].str);
          if (mine && str) { putCake(str, cx, cy, c.rx); drawCloche(ctx, cx, cy, c.rx, 0, true); }
          else { putCake(enc(blank()), cx, cy, c.rx, '', false); drawCloche(ctx, cx, cy, c.rx, 0, false); }
        } else {
          putCake(enc(blank()), cx, cy, c.rx, '', false);
          for (let d = 0; d < 3; d++) { const ph = clock / 180 + d * 0.9 + i; ctx.beginPath(); ctx.arc(cx + (d - 1) * 12, cy - c.rx * 0.95 - Math.max(0, Math.sin(ph)) * 6, 3.5, 0, 7); ctx.fillStyle = '#e3ae45'; ctx.fill(); }
        }
        ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = doneS ? '#9fe3a8' : '#ab9fb8';
        ctx.fillText(doneS ? '완성! 뚜껑 덮음' : '꾸미는 중…', cx, c.y + c.h - 16);
      });
    }
    function drawRev(dt) {
      const L0 = st.last, n = st.n;
      // 머리: 견본 + 제목
      const hy = 32;
      ctx.fillStyle = 'rgba(255,248,234,0.06)'; rr(ctx, 8, hy, Lay.W - 16, 56, 12); ctx.fill();
      putCake(enc(idealCake(L0.o)), 44, hy + 24, 24, '', true);
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.font = '600 11px ' + FONT; ctx.fillStyle = revDone && st.ph === 'j' ? '#e3ae45' : '#ab9fb8';
      ctx.fillText(revDone && st.ph === 'j' ? '케이크를 누르면 점수를 자세히 봐요' : '주문 견본 · ' + CUST[L0.o.cu], 80, hy + 16);
      ctx.font = '17px ' + DISP; ctx.fillStyle = '#ffd166'; ctx.fillText(TPL[L0.o.tp].n, 80, hy + 37);
      const isJ = st.ph === 'j';
      const bottom = Lay.H - (isJ ? 72 : 12);
      const cells = gridCells(n, hy + 64, bottom);
      Lay.cells = cells;
      const best = Math.max(...L0.s);
      cells.forEach((c, i) => {
        const t0 = 0.5 + i * 0.75, lt = (revT - t0) / 0.5, lift = Math.max(0, Math.min(1, lt));
        const shownSc = lt <= 1 ? 0 : Math.round(Math.min(1, (revT - t0 - 0.5) / 0.6) * L0.s[i]);
        const win = revDone && L0.s[i] === best && n > 1;
        cellFrame(c, i, win);
        const cx = c.x + c.w / 2, cy = cakeCY(c);
        putCake(L0.ck[i], cx, cy, c.rx, '', lift >= 1);
        if (lift < 1) drawCloche(ctx, cx, cy, c.rx, lift, false);
        // 점수
        ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
        if (lt > 1) {
          ctx.font = '20px ' + DISP; ctx.fillStyle = shownSc >= 95 ? '#ffd166' : shownSc >= 75 ? '#f2e9d8' : '#ee9a8a';
          ctx.fillText(shownSc + '점', c.x + c.w - 10, c.y + 16);
        }
        if (win) { // 왕관
          const x = c.x + c.w - 14, y = c.y - 2;
          ctx.fillStyle = '#ffd166'; ctx.beginPath(); ctx.moveTo(x - 10, y + 6); ctx.lineTo(x - 10, y - 4); ctx.lineTo(x - 5, y + 1); ctx.lineTo(x, y - 7); ctx.lineTo(x + 5, y + 1); ctx.lineTo(x + 10, y - 4); ctx.lineTo(x + 10, y + 6); ctx.closePath(); ctx.fill();
        }
        if (revT > t0 + 1.1) {
          const ck = L0.id + ':' + i;
          if (!detCache[ck]) { const det = judge(L0.o, dec(L0.ck[i]), L0.tt[i], L0.o.tl); detCache[ck] = { det, cm: comment(det, hash(st.sd, L0.r, i) % 97) }; }
          const { det, cm } = detCache[ck], [mood, sub] = cm;
          const by = c.y + c.h - 56;
          ctx.textAlign = 'center';
          ctx.font = '700 12.5px ' + FONT; ctx.fillStyle = '#ffd166'; ctx.fillText(mood, cx, by);
          ctx.font = '500 11.5px ' + FONT; ctx.fillStyle = '#f2e9d8';
          wrap(sub, cx, by + 15, c.w - 14, 14, 2);
          ctx.font = '600 10.5px ' + MONO; ctx.fillStyle = '#ab9fb8';
          const tags = (det.sym ? '균형+' + det.sym + ' ' : '') + (det.tb ? '빠름+' + det.tb + ' ' : '') + '합계 ' + st.sc[i];
          ctx.fillText(tags, cx, c.y + c.h - 11);
        }
      });
      if (!revDone) {
        const T0 = revT; revT += dt * spd();
        cells.forEach((c, i) => {
          const t0 = 0.5 + i * 0.75;
          if (T0 < t0 && revT >= t0) Snd.lift();
          if (T0 < t0 + 1.1 && revT >= t0 + 1.1) { Snd.score(L0.s[i]); if (L0.s[i] >= 90) confetti(c.x + c.w / 2, c.y + c.h * 0.4, 14); }
        });
        if (revT >= 0.5 + n * 0.75 + 1.0) {
          revDone = true; autoT = 20;
          if (n > 1 || L0.s[0] >= 90) Snd.fanfare();
          const wi = L0.s.indexOf(best); if (n > 1 && cells[wi]) confetti(cells[wi].x + cells[wi].w / 2, cells[wi].y + 20, 24);
          syncRevBar();
        }
      }
    }
    function wrap(text, x, y, maxW, lh, maxLines) {
      const words = text.split(' '), lines = [];
      let line = '';
      for (let i = 0; i < words.length; i++) {
        const t = line ? line + ' ' + words[i] : words[i];
        if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = words[i]; } else line = t;
      }
      if (line) lines.push(line);
      if (lines.length > maxLines) { lines.length = maxLines; lines[maxLines - 1] += '…'; }
      lines.forEach((ln, k) => {
        let s = ln;
        while (s.length > 2 && ctx.measureText(s).width > maxW) s = s.slice(0, -2) + '…';
        ctx.fillText(s, x, y + k * lh);
      });
    }

    /* ---- 키보드 · 패드 ---- */
    const offInput = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || dead) return;
      const m = mode();
      if (m === 'rev') { if (id === 'done') pressNext(); return; }
      if (m !== 'edit') return;
      if (id[0] === 't' && id.length === 2) { setTab(+id[1] - 1); return; }
      if (id === 'undo') { undo(); return; }
      if (id === 'done') { pressDone(); return; }
      if (id === 'order') { if (orderEl) closeOv(); else openOrder(); return; }
      if (id === 'prev' || id === 'next') {
        const d = id === 'next' ? 1 : -1;
        if (tab === 0) { const cs = cur().s; setSheet(cs === PLAIN ? (d > 0 ? 0 : 5) : (cs + d + 6) % 6); }
        else if (tab === 1) { tool.cream = ((tool.cream + 1 + d + 7) % 7) - 1; refreshPal(); }
        else if (tab === 2) { tool.top = (tool.top + d + TOPS.length) % TOPS.length; refreshPal(); }
        Snd.tapk(); scrollToSel();
      }
    }) : null;
    function onEsc(e) { if (e.key === 'Escape' && (orderEl || detailEl)) { e.preventDefault(); e.stopPropagation(); closeOv(); } }
    addEventListener('keydown', onEsc, true);

    /* ---- 매 프레임 ---- */
    const stop = U.loop((dt, now) => {
      if (dead) return;
      clock = now;
      if (!st) return;
      let m = mode();
      if (Lay.W !== cv.w || Lay.H !== cv.h || !layKey || layKey !== cv.w + 'x' + cv.h + ':' + (bot.offsetHeight || 124) + ':' + (st.o ? JSON.stringify(st.o) : '')) layout();
      if (bgKey !== Lay.W + 'x' + Lay.H + ':' + cv.dpr + ':' + Math.round(Lay.cy + Lay.rx * 0.42)) buildBg();
      // 시간
      if (m === 'edit') {
        const s = editSeat();
        if (paused()) tPause[s] = (tPause[s] || 0) + dt * 1000;
        const left = st.o.tl - elapsed(s);
        if (left <= 5.5 && left > 0 && Math.ceil(left) !== lastTick) { lastTick = Math.ceil(left); Snd.tick(); if (lastTick <= 3) api.buzz(8); }
        if (left <= 0 && !paused()) { submitCake(s, true); m = mode(); }
      }
      if (armedT && now - armedT > 2600) { armedT = 0; doneBtn.classList.remove('armed'); doneBtn.textContent = '완성!'; }
      if (banner > 0) banner = Math.max(0, banner - dt * 1.4 * spd());
      if (hintFlash > 0) hintFlash -= dt;
      if (m === 'rev' && revDone && st.ph === 'j' && autoT >= 0) {
        const before = Math.ceil(autoT); autoT -= dt * spd();
        if (Math.ceil(autoT) !== before) syncRevBar();
        if (autoT <= 0) { autoT = -1; if (api.mySeats().some((i) => !st.rd[i])) pressNext(); }
      }
      m = mode();
      if (m !== curMode) sync();
      // 그리기
      try {
        ctx.drawImage(m === 'edit' ? bg : bgWall, 0, 0, Lay.W, Lay.H);
        drawTopStrip(m);
        if (m === 'edit') drawEdit();
        else if (m === 'rev') drawRev(dt);
        else drawWait();
        stepParts(dt);
      } catch (e) { if (!drawErr) { drawErr = 1; console.error(e); } }
    });

    return {
      update(s, prev) {
        st = s;
        if (!s) return;
        if (s.ph === 'd') {
          const k = rKey();
          if (k !== roundKey) {
            roundKey = k; work = {}; tStart = {}; tPause = {}; active = -1; drag = null; progDone = ''; banner = 1; tab = 0; tool.cream = 0;
            closeOv(); Snd.bell(); layKey = '';
            cache.clear();
          }
        } else if (s.last && s.last.id !== revId) {
          revId = s.last.id; revT = 0; revDone = false; autoT = -1; drag = null; closeOv();
          if (s.ph === 'end' && prev && prev.ph === 'end') revT = 99;
        }
        if (s.ph === 'end' && !prev) revT = 99;
        void prev;
        sync();
      },
      destroy() {
        dead = true; stop(); if (offInput) offInput();
        removeEventListener('keydown', onEsc, true);
        closeOv(); if (handEl) handEl.remove();
        cv.destroy(); root.innerHTML = '';
      },
    };
  }

  /* ======================= 등록 ======================= */
  L.register({
    id: 'cake', name: '케이크 데코 대결', tag: '주문서 케이크 꾸미기', cat: '파티',
    blurb: '손님 주문서를 보고 제한 시간 안에 케이크를 꾸며요. 시트 색·크림 테두리·토핑 개수와 자리까지 주문과 똑같을수록 높은 점수!',
    tint: '#7a2e4f',
    icon: '<ellipse cx="28" cy="40" rx="20" ry="6" fill="none" stroke="currentColor" stroke-width="3"/><path d="M10 30v10M46 30v10" stroke="currentColor" stroke-width="3"/><ellipse cx="28" cy="30" rx="18" ry="7" fill="currentColor" opacity=".35"/><ellipse cx="28" cy="30" rx="18" ry="7" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="18" cy="29" r="3.2" fill="currentColor"/><circle cx="28" cy="33" r="3.2" fill="currentColor"/><circle cx="38" cy="29" r="3.2" fill="currentColor"/><rect x="26.5" y="12" width="3" height="14" rx="1.5" fill="currentColor"/><path d="M28 5c3 3 2 6 0 6s-3-3 0-6z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: true, aiDelay: 3000,
    options: [
      { id: 'rounds', label: '주문 수', choices: [{ v: 3, label: '3판' }, { v: 5, label: '5판' }], def: 3 },
      { id: 'time', label: '제한 시간', choices: [{ v: 'long', label: '넉넉히' }, { v: 'normal', label: '보통' }, { v: 'short', label: '빠르게' }], def: 'normal' },
    ],
    quick: [
      '모두 같은 손님 주문서를 받아요. 시트 색 · 크림 · 토핑 개수와 자리가 적혀 있어요.',
      '제한 시간 안에 내 케이크를 손가락으로 꾸미고 「완성!」 (시간이 끝나면 그대로 제출).',
      '주문과 똑같을수록 점수가 높아요. 판마다 점수를 더해 가장 높은 사람이 우승!',
    ],
    rules: [
      { h: '목표', p: [
        '케이크 가게 대결이에요. 손님 주문서와 똑같은 케이크를 만들수록 점수(100점 만점 + 보너스)가 높아요.',
        '기본 3판(옵션 5판). 판마다 주문이 조금씩 어려워져요. 점수를 모두 더해 가장 높은 사람이 우승해요.'] },
      { h: '한 판의 흐름', p: [
        '① 위쪽 주문서를 읽어요. 주문서를 누르면 크게 볼 수 있어요.',
        '② 아래 탭(시트 · 크림 · 토핑 · 장식)으로 케이크를 꾸며요. 맞춘 줄엔 ✓가 떠요.',
        '③ 「완성!」을 두 번 누르면 제출(실수 방지). 제한 시간이 끝나면 지금 모습 그대로 제출돼요.',
        '④ 모두 내면 심사! 뚜껑을 열고 점수와 심사평이 나와요. 케이크를 누르면 깎인 점수를 자세히 볼 수 있어요.'] },
      { h: '꾸미는 법', p: [
        '시트: 아래에서 색을 누르면 케이크 전체에 크림이 발려요. (처음엔 맨 빵이에요)',
        '크림: 색을 고르고 케이크 테두리(또는 가운데 작은 원)를 손가락으로 빙 둘러 그어요. 깍지 모양(별·동글·물결)은 케이크 전체에 적용돼요. 지우개로 지울 수 있어요.',
        '토핑: 고른 뒤 케이크를 누르면 올라가요. 손가락을 누른 채 움직이면 미리 보이고, 떼면 놓여요. 중간·바깥 고리는 눈금에 맞춰 착 붙어요.',
        '올린 토핑은 끌어서 옮기고, 케이크 밖으로 끌어내면 빠져요. ↶ 되돌리기도 있어요.',
        '장식: 가루(무지개·초코·슈가)는 눌러서 뿌리고 한 번 더 누르면 걷어요. 글씨판은 골라서 올리고 끌어서 옮겨요.'] },
      { h: '자리', p: [
        '가운데 = 안쪽 작은 원, 중간 = 그 바깥 고리, 바깥 = 가장자리 고리. 토핑 탭에서 점선으로 보여요.',
        '「고르게」는 같은 간격으로 빙 둘러 놓으라는 뜻이에요 (예: 3개면 시계의 12시·4시·8시).'] },
      { h: '점수', p: [
        '시트 색 · 크림(빈 곳 없이, 무늬까지) · 깍지 · 토핑 개수 · 토핑 자리 · 고른 간격 · 가루 · 글씨판을 주문과 비교해요.',
        '주문에 없는 토핑·크림·가루, 서로 겹친 토핑은 감점이에요.',
        '보너스: 토핑 무게 중심이 가운데면 균형 +3, 일찍 낼수록 빠름 +0~4 (주문을 60% 이상 맞혔을 때만).'] },
      { h: '예시', p: [
        '주문 「시트 딸기 · 테두리 초코 · 딸기 3 · 바깥 고르게 · 초 1 · 가운데」',
        '→ 시트 탭에서 「딸기」, 크림 탭에서 「초코」를 고르고 테두리를 한 바퀴 그어요.',
        '→ 토핑 탭에서 딸기를 바깥 고리 12시·4시·8시에 하나씩, 초를 한가운데에 하나. 모든 줄에 ✓가 뜨면 「완성!」.'] },
      { h: '여럿이 · 혼자', p: [
        '한 폰에서 여럿이 하면 이름이 뜰 때 폰을 넘겨 한 명씩 몰래 꾸며요 (각자 제한 시간).',
        '온라인·LAN이면 각자 폰에서 동시에 꾸며요.',
        '혼자 하면 평균 점수로 별을 받아요: ★ 60 · ★★ 78 · ★★★ 92점.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 골라요. 쉬움은 느리고 실수가 많고, 어려움은 빠르고 꼼꼼해요.'] },
      { h: 'PC 조작', p: [
        '마우스로 누르고 끌어요. 1~4 = 탭 바꾸기, Q/E(←/→) = 재료 바꾸기, Z = 되돌리기, Enter = 완성(두 번)·다음, O = 주문서 크게.'] },
    ],
    tutorial: [
      { sel: '.cdk-spot-order', text: '손님 주문서예요. 시트 색, 크림, 토핑 개수와 자리를 잘 보세요. 맞춘 줄엔 ✓가 떠요. 누르면 크게 보여요.' },
      { sel: '.cdk-tabs', text: '아래 탭에서 시트 → 크림 → 토핑 → 장식 순서로 꾸며요.' },
      { sel: '.cdk-spot-cake', text: '크림 탭: 테두리를 손가락으로 빙 둘러 그으면 크림이 짜져요. 토핑 탭: 케이크를 누르면 올라가요(고리 눈금에 착 붙어요).' },
      { sel: '.cdk-spot-cake', text: '올린 토핑은 끌어서 옮기고, 케이크 밖으로 끌어내면 빠져요. 실수하면 ↶ 되돌리기!' },
      { sel: '.cdk-done', text: '다 됐으면 「완성!」을 두 번. 시간이 끝나면 그대로 제출돼요. 빨리 끝낼수록 작은 보너스가 있어요.' },
    ],
    controls: [
      { id: 't1', label: '시트 탭', keys: ['Digit1'] },
      { id: 't2', label: '크림 탭', keys: ['Digit2'] },
      { id: 't3', label: '토핑 탭', keys: ['Digit3'] },
      { id: 't4', label: '장식 탭', keys: ['Digit4'] },
      { id: 'prev', label: '이전 재료', keys: ['KeyQ', 'ArrowLeft'], pad: ['lb'] },
      { id: 'next', label: '다음 재료', keys: ['KeyE', 'ArrowRight'], pad: ['rb'] },
      { id: 'undo', label: '되돌리기', keys: ['KeyZ', 'Backspace'], pad: ['b'] },
      { id: 'done', label: '완성 / 다음', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'order', label: '주문서 크게 보기', keys: ['KeyO'], pad: ['y'] },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { enc, dec, valid, judge, genOrder, idealCake, aiCake, blank, TPL, TOPS, comment, orderRows, rowProg },
  });
})();
