/* 슬라임 합체 대전 — realtime sliding-merge battle (1–4).
   Every player has their own 4×4 (or 5×5) jelly tray. Swipe: every slime slides that way; two equal slimes merge
   into the next size. Big merges throw 돌 슬라임 (stones) onto an opponent's tray; a stone slides like a slime but never
   merges and breaks after two merges right next to it. Pending stones can be cancelled by your own attacks.
   No legal move = out. Last one standing wins, or the best survivor score when the clock runs out.
   Solo: 왕관 슬라임 만들기 (goal, time = stars) or 점수 도전 (time limit, score = stars).
   Network (cooking.js / pinball.js pattern): each device simulates its own board (the host also runs the AI boards).
   Guests publish {k,sc,a,b,o,mx,p}; the host relays every row with hostSend({k,t,s:[[sc,a,b,o,mx,p]..]}) and ends the
   match with setState. Attacks travel as cumulative per-target counters (o[seat]), so lost/duplicated packets are harmless. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;

  /* ======================= constants ======================= */
  const GOAL = 8;                       // 왕관 슬라임
  const DROP_DELAY = 2.6;               // s from arrival until pending stones fall
  const DROP_MAX = 3, DROP_RETRY = 1.0;
  const RAIN_AT = 240, RAIN_EVERY = 8;  // no time limit (versus): stones rain on everyone after 4 minutes
  const COUNT = 3.2;                    // pre-start countdown (s)
  const NAMES = ['', '물방울', '아기', '꼬마', '말랑', '통통', '쫀득', '탱글', '왕관', '별빛', '보석', '무지개', '전설', '우주', '신화', '태초', '끝판'];
  const COLS = ['#888', '#8fd8ff', '#6fe3a6', '#c2ea62', '#ffd457', '#ffa057', '#ff7088', '#e57bff', '#a68bff', '#5c9dff', '#36d6c6', '#ff9ad1', '#ffe27a', '#b0c4ff', '#ff6a4d', '#f2e9d8', '#ffffff'];
  const lvName = (v) => NAMES[Math.min(v, NAMES.length - 1)] || ('Lv' + v);
  const lvCol = (v) => COLS[Math.min(v, COLS.length - 1)];
  const fmt = (n) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const mmss = (t) => { t = Math.max(0, Math.ceil(t)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };

  function mkRng(seed) {
    let a = (seed >>> 0) || 0x9e3779b9;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ======================= board logic (pure) ======================= */
  // cell values: 0 empty, v>0 slime level v, -1 stone (2 hits left), -2 cracked stone (1 hit left)
  const LINES = {};
  function lines(n) { // [dir][line] -> cell indices ordered from the wall we slide toward. dir 0 up 1 right 2 down 3 left
    if (LINES[n]) return LINES[n];
    const out = [];
    for (let d = 0; d < 4; d++) {
      const ls = [];
      for (let k = 0; k < n; k++) {
        const l = [];
        for (let i = 0; i < n; i++) {
          let r, c;
          if (d === 0) { r = i; c = k; } else if (d === 2) { r = n - 1 - i; c = k; } else if (d === 3) { r = k; c = i; } else { r = k; c = n - 1 - i; }
          l.push(r * n + c);
        }
        ls.push(l);
      }
      out.push(ls);
    }
    return (LINES[n] = out);
  }
  // returns null when nothing moves; trk (optional) receives triples [from, to, mergedAway]
  function slide(c, n, d, trk) {
    const o = new Array(n * n).fill(0), mg = [];
    let gain = 0, moved = false;
    const LS = lines(n)[d];
    for (let k = 0; k < n; k++) {
      const l = LS[k];
      let w = 0, open = false;
      for (let i = 0; i < n; i++) {
        const idx = l[i], v = c[idx];
        if (!v) continue;
        if (v > 0 && open && o[l[w - 1]] === v) {
          const t = l[w - 1];
          o[t] = v + 1; gain += Math.pow(2, v + 1); mg.push(t); open = false; moved = true;
          if (trk) trk.push(idx, t, 1);
        } else {
          const t = l[w];
          o[t] = v; if (t !== idx) moved = true; open = v > 0; w++;
          if (trk) trk.push(idx, t, 0);
        }
      }
    }
    return moved ? { o, gain, mg } : null;
  }
  function canMove(c, n) {
    for (let i = 0; i < c.length; i++) if (!c[i]) return true;
    for (let r = 0; r < n; r++) for (let q = 0; q < n; q++) {
      const v = c[r * n + q];
      if (v <= 0) continue;
      if (q + 1 < n && c[r * n + q + 1] === v) return true;
      if (r + 1 < n && c[(r + 1) * n + q] === v) return true;
    }
    return false;
  }
  function neighbors(n, i) { const r = (i / n) | 0, q = i % n, out = []; if (r > 0) out.push(i - n); if (r < n - 1) out.push(i + n); if (q > 0) out.push(i - 1); if (q < n - 1) out.push(i + 1); return out; }
  // attack size of one merge creating level v (mode 1 = 보통, 2 = 많이, 0 = off)
  function atkOf(v, mode) {
    if (!mode) return 0;
    if (mode === 2) return v >= 4 ? Math.min(5, v - 3) : 0;
    return v >= 5 ? [1, 1, 2, 3][Math.min(3, v - 5)] + (v >= 9 ? 1 : 0) : 0;
  }
  const COMBO = [99, 3, 2];  // merges in one swipe for +1 stone

  function newBoard(n, seed) {
    const B = { n, c: new Array(n * n).fill(0), id: new Array(n * n).fill(0), nid: 1, sc: 0, mv: 0, mx: 1, alive: true, done: false,
      out: [0, 0, 0, 0], inTot: 0, abs: 0, pendT: -1, rng: mkRng(seed), deadT: -1, sent: 0, broke: 0, recv: 0, seq: 0, rec: null, goalT: -1 };
    spawnSlime(B); spawnSlime(B);
    return B;
  }
  function emptyCells(c) { const e = []; for (let i = 0; i < c.length; i++) if (!c[i]) e.push(i); return e; }
  function spawnSlime(B) {
    const e = emptyCells(B.c);
    if (!e.length) return -1;
    const i = e[Math.floor(B.rng() * e.length)];
    B.c[i] = B.rng() < 0.1 ? 2 : 1; B.id[i] = B.nid++;
    return i;
  }
  const pendOf = (B) => Math.max(0, B.inTot - B.abs);
  // new incoming total (net + rain) → returns how many just arrived
  function setIncoming(B, tot, tl) {
    if (!(tot > B.inTot)) return 0;
    const add = tot - B.inTot;
    if (pendOf(B) <= 0) B.pendT = tl;
    B.inTot = tot; B.recv += add;
    return add;
  }
  function dropStones(B, tl) { // pending stones fall (time-based). returns dropped cells
    const p = pendOf(B);
    if (p <= 0 || B.pendT < 0 || tl - B.pendT < DROP_DELAY || !B.alive || B.done) return null;
    const e = emptyCells(B.c), k = Math.min(p, DROP_MAX, e.length), cells = [];
    for (let j = 0; j < k; j++) {
      const x = Math.floor(B.rng() * e.length), i = e.splice(x, 1)[0];
      B.c[i] = -1; B.id[i] = B.nid++; cells.push(i); B.abs++;
    }
    if (pendOf(B) > 0) B.pendT = tl - DROP_DELAY + DROP_RETRY; else B.pendT = -1;
    if (!canMove(B.c, B.n)) { B.alive = false; B.deadT = tl; }
    if (!cells.length) return null;
    B.seq++; B.rec = { seq: B.seq, k: 'drop', drops: cells };
    return cells;
  }
  // a swipe. pick(a) chooses the target seat for `a` stones (or -1). Returns the move record or null.
  function doMove(B, d, tl, atk, pick) {
    if (!B.alive || B.done) return null;
    const n = B.n, trk = [];
    const r = slide(B.c, n, d, trk);
    if (!r) return null;
    const nid = new Array(n * n).fill(0), mv = [];
    for (let k = 0; k < trk.length; k += 3) {
      const f = trk[k], t = trk[k + 1], m = trk[k + 2];
      mv.push([f, t, B.c[f], B.id[f], m]);
      if (!m) nid[t] = B.id[f];
    }
    for (const t of r.mg) nid[t] = B.nid++;
    B.c = r.o; B.id = nid;
    // merges next to stones crack / break them
    const cr = [], cl = [];
    for (const t of r.mg) for (const j of neighbors(n, t)) {
      if (B.c[j] === -1) { B.c[j] = -2; cr.push(j); }
      else if (B.c[j] === -2) { B.c[j] = 0; B.id[j] = 0; cl.push(j); B.broke++; const x = cr.indexOf(j); if (x >= 0) cr.splice(x, 1); }
    }
    B.sc += r.gain; B.mv++;
    for (const t of r.mg) if (B.c[t] > B.mx) B.mx = B.c[t];
    // attack: cancel own pending stones first, the rest flies to an opponent
    let a = 0;
    for (const t of r.mg) a += atkOf(B.c[t], atk);
    if (atk && r.mg.length >= COMBO[atk]) a += 1;
    const cancel = Math.min(a, pendOf(B));
    B.abs += cancel; a -= cancel;
    if (pendOf(B) <= 0) B.pendT = -1;
    let tgt = -1;
    if (a > 0 && pick) { tgt = pick(a); if (tgt >= 0 && tgt < 4) { B.out[tgt] += a; B.sent += a; } else a = 0; }
    const sp = spawnSlime(B);
    if (!canMove(B.c, n)) { B.alive = false; B.deadT = tl; }
    B.seq++;
    B.rec = { seq: B.seq, k: 'move', d, mv, mg: r.mg, cr, cl, sp, gain: r.gain, sent: a, tgt, cancel };
    return B.rec;
  }

  /* ----- AI ----- */
  const SNK = {};
  function snake(n) { // gradient weights along a snake path from the top-left corner
    if (SNK[n]) return SNK[n];
    const w = new Array(n * n);
    let k = 0;
    for (let r = 0; r < n; r++) for (let j = 0; j < n; j++) { const q = r % 2 ? n - 1 - j : j; w[r * n + q] = Math.pow(0.42, k++); }
    return (SNK[n] = w);
  }
  function evalC(c, n) {
    const w = snake(n);
    let s = 0, emp = 0, st = 0, adj = 0, mx = 0;
    for (let i = 0; i < c.length; i++) {
      const v = c[i];
      if (v > 0) { const p = Math.pow(2, v); s += p * w[i]; if (v > mx) mx = v; }
      else if (v === 0) emp++;
      else st++;
    }
    for (let r = 0; r < n; r++) for (let q = 0; q < n; q++) {
      const v = c[r * n + q];
      if (v <= 0) continue;
      if (q + 1 < n && c[r * n + q + 1] === v) adj++;
      if (r + 1 < n && c[(r + 1) * n + q] === v) adj++;
    }
    const big = Math.pow(2, mx);
    return s + (emp * 0.45 + adj * 0.18 - st * 0.35) * big + (emp === 0 && !adj ? -big * 8 : 0);
  }
  function aiPick(B, lv, rng) {
    const c = B.c, n = B.n, opts = [];
    for (let d = 0; d < 4; d++) { const r = slide(c, n, d); if (r) opts.push([d, r]); }
    if (!opts.length) return -1;
    if (opts.length === 1) return opts[0][0];
    if (lv <= 1) {
      if (rng() < 0.32) return opts[Math.floor(rng() * opts.length)][0];
      let best = -1e18, bd = opts[0][0];
      for (const [d, r] of opts) { const e = r.gain + emptyCells(r.o).length * 4 + rng() * 6; if (e > best) { best = e; bd = d; } }
      return bd;
    }
    if (lv === 2) {
      if (rng() < 0.05) return opts[Math.floor(rng() * opts.length)][0];
      let best = -1e18, bd = opts[0][0];
      for (const [d, r] of opts) { const e = evalC(r.o, n) * (1 + (rng() - 0.5) * 0.08); if (e > best) { best = e; bd = d; } }
      return bd;
    }
    // lv3: expectimax depth 2 (spawn sampled)
    let best = -1e18, bd = opts[0][0];
    for (const [d, r] of opts) {
      const e = emptyCells(r.o);
      let tot = 0, cnt = 0;
      const samp = e.length <= 6 ? e : e.filter((_, i) => i % Math.ceil(e.length / 6) === 0);
      for (const i of samp) {
        for (const sv of [1, 2]) {
          const pr = sv === 1 ? 0.9 : 0.1;
          const c2 = r.o.slice(); c2[i] = sv;
          let m = -1e18;
          for (let d2 = 0; d2 < 4; d2++) { const r2 = slide(c2, n, d2); if (r2) { const v = evalC(r2.o, n); if (v > m) m = v; } }
          if (m === -1e18) m = -Math.pow(2, 20);
          tot += m * pr; cnt += pr;
        }
      }
      const v = cnt ? tot / cnt : evalC(r.o, n);
      if (v > best) { best = v; bd = d; }
    }
    return bd;
  }
  // AI think time (s) per level
  function aiDelay(lv, rng) { return lv <= 1 ? 1.05 + rng() * 0.6 : lv === 2 ? 0.66 + rng() * 0.3 : 0.6 + rng() * 0.26; }
  // stone rain (versus without a time limit): from 4:00 one stone per 8 s, getting faster every minute
  const rainOf = (tl) => { if (tl < RAIN_AT) return 0; const k = tl - RAIN_AT; return Math.floor(k / RAIN_EVERY + 4 * (k / 60) * (k / 60)) + 1; };
  // target for my attack: the alive opponent with the highest score (ties → next seat after me)
  function pickTarget(me, n, alive, score) {
    let best = -1, bs = -1;
    for (let k = 1; k < n; k++) { const s = (me + k) % n; if (!alive(s)) continue; const v = score(s); if (v > bs) { bs = v; best = s; } }
    return best;
  }
  function encode(B) { // compact board string for mini views: '.' empty, a.. levels, '#' stone, '%' cracked
    let s = '';
    for (const v of B.c) s += v === 0 ? '.' : v === -1 ? '#' : v === -2 ? '%' : String.fromCharCode(96 + Math.min(26, v));
    return s;
  }
  function decode(str, n) {
    const c = new Array(n * n).fill(0);
    for (let i = 0; i < n * n && i < str.length; i++) { const ch = str[i]; c[i] = ch === '.' ? 0 : ch === '#' ? -1 : ch === '%' ? -2 : Math.max(1, ch.charCodeAt(0) - 96); }
    return c;
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    const n = Math.max(1, Math.min(4, players.length));
    return {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      sz: o.size === 5 ? 5 : 4, T: [0, 120, 180, 300].includes(o.time) ? o.time : 180, atk: [0, 1, 2].includes(o.atk) ? o.atk : 1,
      solo: o.solo === 'score' ? 'score' : 'goal', sd: 1 + U.rand(2147483646), ph: 'play', res: null,
    };
  }
  const soloKind = (s) => (s.n === 1 ? s.solo : null);
  const timeOf = (s) => (s.n === 1 ? (s.solo === 'goal' ? 0 : (s.T || 180)) : s.T);
  // rows: [seat, score, alive(1/0), dieOrder, maxLevel, time]
  function finish(s, rows) {
    const res = rows.map((r) => r.slice()).sort((a, b) => (b[2] - a[2]) || (a[2] ? b[1] - a[1] : (b[3] - a[3]) || (b[1] - a[1])) || a[0] - b[0]);
    return Object.assign({}, s, { ph: 'done', res });
  }
  function starsOf(s, r) {
    if (s.solo === 'goal') { if (r[4] < GOAL) return 0; return r[5] <= 100 ? 3 : r[5] <= 170 ? 2 : 1; }
    const T = timeOf(s) || 180, k = T / 180;
    const need = [1400, 2600, 3800].map((v) => Math.round(v * Math.pow(k, 1.25) / 100) * 100);
    return need.filter((v) => r[1] >= v).length;
  }
  function starNeed(s) { const T = timeOf(s) || 180, k = T / 180; return [1400, 2600, 3800].map((v) => Math.round(v * Math.pow(k, 1.25) / 100) * 100); }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const head = s.sz + '×' + s.sz + (s.n > 1 ? ' · ' + (s.T ? mmss(s.T) : '시간 무제한') + ' · 방해 ' + ['끄기', '보통', '많이'][s.atk] : '');
    if (s.n === 1) {
      const r = s.res[0], st = starsOf(s, r), stars = '★'.repeat(st) + '☆'.repeat(3 - st);
      if (s.solo === 'goal') {
        if (r[4] >= GOAL) return { winners: [r[0]], title: '왕관 슬라임 완성!', text: head + ' · 왕관 만들기\n' + stars + '  ' + mmss(r[5]) + ' 걸렸어요\n점수 ' + fmt(r[1]) };
        return { winners: [], title: '아쉬워요', text: head + ' · 왕관 만들기\n더 밀 수 없어요. 가장 큰 슬라임: ' + lvName(r[4]) + ' (Lv' + r[4] + ')\n점수 ' + fmt(r[1]) };
      }
      return { winners: st > 0 ? [r[0]] : [], title: st ? '별 ' + st + '개!' : '아쉬워요', text: head + ' · 점수 도전\n' + stars + '  ' + fmt(r[1]) + '점 · 가장 큰 슬라임 Lv' + r[4] };
    }
    const top = s.res[0];
    const winners = s.res.filter((r) => r[2] === top[2] && r[1] === top[1] && (top[2] || r[3] === top[3])).map((r) => r[0]);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + fmt(r[1]) + '점' + (r[2] ? '' : ' · 탈락'));
    const alive = s.res.filter((r) => r[2]).length;
    const why = alive === 1 ? '마지막까지 버텼어요!' : alive === 0 ? '모두 막혔어요' : '시간 끝 · 남은 사람 중 최고 점수';
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: head + '\n' + why + '\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `
.sl-btn{position:absolute;left:50%;transform:translateX(-50%);min-width:120px;height:44px;padding:0 16px;border-radius:22px;z-index:3;
  background:rgba(23,19,31,.82);color:var(--ink,#f2e9d8);border:1.5px solid rgba(227,174,69,.75);font:700 14px var(--f-body,sans-serif);
  box-shadow:0 2px 10px rgba(0,0,0,.45);touch-action:none;-webkit-user-select:none;user-select:none;cursor:pointer}
.sl-btn:active{background:rgba(227,174,69,.9);color:#17131f}
.sl-btn[hidden]{display:none}
`;
  const KEYN = { Space: '스페이스', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Enter: 'Enter' };
  const keyName = (c) => KEYN[c] || String(c || '').replace(/^Key/, '').replace(/^Digit/, '');
  const DIRV = [[0, -1], [1, 0], [0, 1], [-1, 0]];
  const SL = 0.095, POP = 0.26, GROW = 0.2, LAND = 0.17, FALL = 0.36;
  function shade(hex, f) { // f>0 lighter, f<0 darker
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  const easeOut = (p) => 1 - (1 - p) * (1 - p);
  const easeBack = (p) => { const c = 1.9; return 1 + (c + 1) * Math.pow(p - 1, 3) + c * Math.pow(p - 1, 2); };

  // ---- slime art (drawn once per level/size into a sprite) ----
  function bodyPath(g, cx, by, bw, bh) {
    g.beginPath();
    g.moveTo(cx - bw / 2, by - bh * 0.24);
    g.bezierCurveTo(cx - bw / 2, by - bh * 0.86, cx - bw * 0.3, by - bh, cx, by - bh);
    g.bezierCurveTo(cx + bw * 0.3, by - bh, cx + bw / 2, by - bh * 0.86, cx + bw / 2, by - bh * 0.24);
    g.quadraticCurveTo(cx + bw / 2, by, cx + bw * 0.3, by);
    g.lineTo(cx - bw * 0.3, by);
    g.quadraticCurveTo(cx - bw / 2, by, cx - bw / 2, by - bh * 0.24);
    g.closePath();
  }
  function star(g, x, y, r, col) {
    g.beginPath();
    for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? r * 0.45 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); }
    g.closePath(); g.fillStyle = col; g.fill();
  }
  function drawSlime(g, S, v, blink, badge) {
    const cx = S / 2, by = S * 0.93;
    if (v < 0) { // stone slime
      const bw = S * 0.82, bh = S * 0.7;
      g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(cx, by - S * 0.01, bw * 0.46, S * 0.05, 0, 0, TAU); g.fill();
      g.beginPath();
      const P = [[-0.5, -0.12], [-0.46, -0.62], [-0.22, -0.97], [0.12, -1], [0.4, -0.8], [0.5, -0.36], [0.44, -0.02], [-0.4, 0]];
      P.forEach((p, i) => { const x = cx + p[0] * bw, y = by + p[1] * bh; if (i) g.lineTo(x, y); else g.moveTo(x, y); });
      g.closePath();
      const gr = g.createLinearGradient(0, by - bh, 0, by);
      gr.addColorStop(0, '#a7a2ad'); gr.addColorStop(1, '#5d5864');
      g.fillStyle = gr; g.fill();
      g.lineJoin = 'round'; g.lineWidth = Math.max(1.5, S * 0.035); g.strokeStyle = '#3a3640'; g.stroke();
      g.fillStyle = 'rgba(255,255,255,.18)'; g.beginPath(); g.ellipse(cx - bw * 0.18, by - bh * 0.72, bw * 0.16, bh * 0.08, -0.4, 0, TAU); g.fill();
      // grumpy face
      const ey = by - bh * 0.45, ex = bw * 0.17;
      g.strokeStyle = '#25212b'; g.lineWidth = Math.max(1.5, S * 0.045); g.lineCap = 'round';
      g.beginPath(); g.moveTo(cx - ex - S * 0.06, ey - S * 0.035); g.lineTo(cx - ex + S * 0.05, ey); g.moveTo(cx + ex + S * 0.06, ey - S * 0.035); g.lineTo(cx + ex - S * 0.05, ey); g.stroke();
      g.fillStyle = '#25212b';
      g.beginPath(); g.arc(cx - ex, ey + S * 0.035, S * 0.032, 0, TAU); g.arc(cx + ex, ey + S * 0.035, S * 0.032, 0, TAU); g.fill();
      g.beginPath(); g.moveTo(cx - S * 0.07, by - bh * 0.18); g.quadraticCurveTo(cx, by - bh * 0.28, cx + S * 0.07, by - bh * 0.18); g.stroke();
      if (v === -2) { // cracked
        g.strokeStyle = '#1d1a22'; g.lineWidth = Math.max(1.2, S * 0.03);
        g.beginPath(); g.moveTo(cx + bw * 0.1, by - bh); g.lineTo(cx + bw * 0.02, by - bh * 0.78); g.lineTo(cx + bw * 0.14, by - bh * 0.66); g.lineTo(cx + bw * 0.05, by - bh * 0.5);
        g.moveTo(cx - bw * 0.46, by - bh * 0.4); g.lineTo(cx - bw * 0.3, by - bh * 0.3); g.lineTo(cx - bw * 0.34, by - bh * 0.14); g.stroke();
      }
      return;
    }
    const k = Math.min(1, 0.66 + v * 0.042), col = lvCol(v);
    const bw = S * 0.86 * k, bh = S * 0.76 * k;
    g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(cx, by - S * 0.005, bw * 0.48, S * 0.05, 0, 0, TAU); g.fill();
    bodyPath(g, cx, by, bw, bh);
    const gr = g.createRadialGradient(cx - bw * 0.18, by - bh * 0.72, bw * 0.05, cx, by - bh * 0.45, bw * 0.75);
    gr.addColorStop(0, shade(col, 0.55)); gr.addColorStop(0.55, col); gr.addColorStop(1, shade(col, -0.32));
    g.fillStyle = gr; g.fill();
    g.lineWidth = Math.max(1.5, S * 0.035); g.strokeStyle = shade(col, -0.55); g.stroke();
    // jelly shine
    g.fillStyle = 'rgba(255,255,255,.55)';
    g.beginPath(); g.ellipse(cx - bw * 0.24, by - bh * 0.74, bw * 0.12, bh * 0.07, -0.6, 0, TAU); g.fill();
    g.beginPath(); g.arc(cx - bw * 0.07, by - bh * 0.86, bw * 0.03, 0, TAU); g.fill();
    // face
    const ey = by - bh * 0.46, ex = bw * 0.18, er = Math.max(1.6, bw * 0.072);
    g.fillStyle = '#231a2a'; g.strokeStyle = '#231a2a'; g.lineCap = 'round';
    if (blink) {
      g.lineWidth = Math.max(1.4, er * 0.55);
      g.beginPath(); g.arc(cx - ex, ey, er * 0.8, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke();
      g.beginPath(); g.arc(cx + ex, ey, er * 0.8, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke();
    } else {
      g.beginPath(); g.ellipse(cx - ex, ey, er * 0.85, er, 0, 0, TAU); g.ellipse(cx + ex, ey, er * 0.85, er, 0, 0, TAU); g.fill();
      g.fillStyle = '#fff';
      g.beginPath(); g.arc(cx - ex - er * 0.25, ey - er * 0.35, er * 0.33, 0, TAU); g.arc(cx + ex - er * 0.25, ey - er * 0.35, er * 0.33, 0, TAU); g.fill();
    }
    g.fillStyle = 'rgba(255,110,140,.45)';
    g.beginPath(); g.ellipse(cx - ex * 1.75, ey + er * 1.35, er * 0.95, er * 0.55, 0, 0, TAU); g.ellipse(cx + ex * 1.75, ey + er * 1.35, er * 0.95, er * 0.55, 0, 0, TAU); g.fill();
    g.lineWidth = Math.max(1.3, bw * 0.03);
    g.beginPath();
    if (v <= 2) { g.arc(cx, ey + er * 1.45, er * 0.42, 0, TAU); g.fillStyle = '#231a2a'; g.fill(); }
    else { g.arc(cx, ey + er * 0.75, er * 0.85, 0.2 * Math.PI, 0.8 * Math.PI); g.stroke(); }
    // accessories
    const top = by - bh;
    if (v === 3) { g.strokeStyle = shade(col, -0.3); g.lineWidth = Math.max(1.5, S * 0.035); g.beginPath(); g.moveTo(cx, top + 1); g.quadraticCurveTo(cx - S * 0.02, top - S * 0.07, cx + S * 0.06, top - S * 0.09); g.stroke(); }
    if (v === 4) { g.fillStyle = '#4fbf5a'; g.beginPath(); g.ellipse(cx + S * 0.05, top - S * 0.05, S * 0.07, S * 0.035, -0.6, 0, TAU); g.fill(); g.strokeStyle = '#2c7a33'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(cx, top + 1); g.lineTo(cx + S * 0.02, top - S * 0.04); g.stroke(); }
    if (v === 5) { g.fillStyle = '#ff5f8a'; g.beginPath(); g.moveTo(cx + bw * 0.2, top + bh * 0.1); g.lineTo(cx + bw * 0.06, top - S * 0.03); g.lineTo(cx + bw * 0.06, top + bh * 0.2); g.closePath(); g.moveTo(cx + bw * 0.2, top + bh * 0.1); g.lineTo(cx + bw * 0.34, top - S * 0.01); g.lineTo(cx + bw * 0.33, top + bh * 0.22); g.closePath(); g.fill(); g.beginPath(); g.arc(cx + bw * 0.2, top + bh * 0.1, S * 0.025, 0, TAU); g.fillStyle = '#d93f6a'; g.fill(); }
    if (v === 6) star(g, cx + bw * 0.24, top + bh * 0.12, S * 0.07, '#fff27a');
    if (v === 7) { for (let i = 0; i < 5; i++) { const a = i * TAU / 5; g.fillStyle = '#ffe9f6'; g.beginPath(); g.arc(cx - bw * 0.22 + Math.cos(a) * S * 0.035, top + bh * 0.12 + Math.sin(a) * S * 0.035, S * 0.03, 0, TAU); g.fill(); } g.fillStyle = '#ffcf4a'; g.beginPath(); g.arc(cx - bw * 0.22, top + bh * 0.12, S * 0.025, 0, TAU); g.fill(); }
    if (v >= 8) { // crown
      const cw = S * (v >= 12 ? 0.42 : 0.34), ch = S * 0.15, cy = top + S * 0.025;
      if (v >= 11) { g.strokeStyle = 'rgba(255,240,170,.85)'; g.lineWidth = S * 0.025; g.beginPath(); g.ellipse(cx, cy - ch * 1.05, cw * 0.62, ch * 0.32, 0, 0, TAU); g.stroke(); }
      g.beginPath(); g.moveTo(cx - cw / 2, cy); g.lineTo(cx - cw / 2, cy - ch); g.lineTo(cx - cw / 4, cy - ch * 0.55); g.lineTo(cx, cy - ch * 1.15); g.lineTo(cx + cw / 4, cy - ch * 0.55); g.lineTo(cx + cw / 2, cy - ch); g.lineTo(cx + cw / 2, cy); g.closePath();
      const cg = g.createLinearGradient(0, cy - ch, 0, cy); cg.addColorStop(0, '#fff2a8'); cg.addColorStop(1, '#d99a1e');
      g.fillStyle = cg; g.fill(); g.lineWidth = Math.max(1, S * 0.02); g.strokeStyle = '#8a5a10'; g.stroke();
      g.fillStyle = v >= 10 ? '#ff4f7a' : '#7ad8ff'; g.beginPath(); g.arc(cx, cy - ch * 0.42, S * 0.022, 0, TAU); g.fill();
      if (v >= 9) { star(g, cx - bw * 0.42, top + bh * 0.18, S * 0.045, '#fff7c0'); star(g, cx + bw * 0.44, top + bh * 0.3, S * 0.035, '#fff7c0'); }
    }
    if (badge) { // level number
      const r = S * 0.12, x = S - r - S * 0.03, y = S - r - S * 0.03;
      g.fillStyle = 'rgba(23,19,31,.82)'; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
      g.lineWidth = Math.max(1, S * 0.018); g.strokeStyle = shade(col, 0.2); g.stroke();
      g.fillStyle = '#fff'; g.font = '700 ' + Math.round(r * (v >= 10 ? 1.1 : 1.3)) + 'px ' + MONO; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(String(v), x, y + r * 0.08);
    }
  }

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const DPR = () => Math.min(2.5, cv.dpr || 1);
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    const fine = (() => { try { return matchMedia('(pointer:fine)').matches || !!window.LOUNGE_DESKTOP; } catch (e) { return false; } })();

    let st = null, key = null, BS = [], mem = [], view = 0, lay = null, tl = -COUNT, ff = 1, vt = 0;
    let endWait = 0, dieSeq = 0, pubT = 0, lastSig = '', shake = 0, hostT = null, overSeen = false, moves = 0, bumpT = 0, bumpD = 0;
    let anim = null, later = [], parts = [], floats = [], shots = [], dispSc = 0, flash = {}, pendShake = 0, endSeen = false;
    const fx = new Map(), remote = {}, dOrd = {}, lastOut = {}, sprites = new Map(), ptr = new Map();
    let trayC = null, best = null, bgG = null, bgW = 0, bgH = 0;
    const bestKey = () => 'lounge.slime.best.' + st.solo + '.' + st.sz + (st.solo === 'score' ? '.' + timeOf(st) : '');
    const recordOf = (B) => (st.solo === 'goal' ? (B.done && B.goalT >= 0 ? Math.round(B.goalT) : null) : B.sc);
    function loadBest() { best = null; if (!st || st.n !== 1) return; try { const v = localStorage.getItem(bestKey()); if (v != null && v !== '' && isFinite(+v)) best = +v; } catch (e) {} }

    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const T = () => (st ? timeOf(st) : 0);
    const timeUp = () => T() > 0 && tl >= T();
    const versus = () => !!st && st.n > 1;

    function ensureMatch() {
      if (!st) return;
      const k = st.rid + '.' + st.sz + '.' + st.n;
      if (k === key) return;
      key = k;
      BS = []; mem = [];
      for (let s = 0; s < st.n; s++) {
        BS[s] = simHere(s) ? newBoard(st.sz, (st.sd ^ (s * 7919 + 13)) >>> 0) : null;
        mem[s] = { cd: 0.4 + s * 0.13, rng: mkRng((st.sd ^ (s * 104729 + 7)) >>> 0) };
      }
      const m = mine(), fst = BS.findIndex(Boolean);
      view = m.length && BS[m[0]] ? m[0] : (fst >= 0 ? fst : 0);
      for (const x in remote) delete remote[x];
      for (const x in dOrd) delete dOrd[x];
      for (const x in lastOut) delete lastOut[x];
      tl = st.ph === 'done' ? 1e6 : -COUNT; ff = 1; endWait = 0; dieSeq = 0; hostT = null; overSeen = st.ph === 'done'; moves = 0; endSeen = false;
      loadBest();
      anim = null; fx.clear(); later = []; parts = []; floats = []; shots = []; dispSc = 0; flash = {};
      if (st.ph === 'done') BS.forEach((B) => { if (B) B.done = true; });
      layout();
    }
    // a seat I simulate but had no board for (a guest left → AI takes over on the host): continue from their last snapshot
    function adoptSeats() {
      if (!st || !key) return;
      for (let s = 0; s < st.n; s++) {
        if (BS[s] || !simHere(s)) continue;
        const B = newBoard(st.sz, (st.sd ^ (s * 7919 + 99)) >>> 0), r = remote[s];
        if (r) {
          B.c = decode(r.b, st.sz); B.id = B.c.map((v) => (v ? B.nid++ : 0));
          B.sc = r.sc; B.mx = Math.max(1, r.mx); B.out = (r.o || [0, 0, 0, 0]).slice(); while (B.out.length < 4) B.out.push(0);
          B.alive = !!r.a;
          B.inTot = incomingFor(s); B.abs = Math.max(0, B.inTot - (r.p | 0)); B.pendT = r.p > 0 ? tl : -1;
          if (B.alive && !canMove(B.c, B.n)) B.alive = false;
        }
        BS[s] = B; mem[s] = { cd: 0.8, rng: mkRng((st.sd ^ (s * 31 + 5)) >>> 0) };
      }
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h, pad = 10;
      const k = st ? st.n - 1 : 0;
      const miniH = k <= 0 ? 0 : k === 1 ? 70 : 100;
      const miniY = 6, top = miniY + miniH + (miniH ? 6 : 0), hudH = 46, rowH = 30, hintH = 34;
      const avail = h - top - hudH - rowH - hintH - 12;
      const bs = Math.max(120, Math.min(w - pad * 2, avail, 560));
      const off = Math.round(Math.max(0, (avail - bs) * 0.4));
      const hudY = top + off, rowY = hudY + hudH;
      const bx = Math.round((w - bs) / 2), by = Math.round(rowY + rowH + 4);
      const n = st ? st.sz : 4, bp = bs * 0.045, gap = bs * (n === 5 ? 0.018 : 0.022), cs = (bs - bp * 2 - gap * (n - 1)) / n;
      lay = { w, h, pad, k, miniY, miniH, hudY, hudH, rowY, rowH, bs, bx, by, bp, gap, cs, n, hintY: by + bs + 6 };
      sprites.clear(); trayC = null;
      placeButtons();
    }
    cv.onresize = layout;
    const cellXY = (i) => { const n = lay.n, r = (i / n) | 0, q = i % n; return [lay.bx + lay.bp + q * (lay.cs + lay.gap), lay.by + lay.bp + r * (lay.cs + lay.gap)]; };

    /* ----- buttons ----- */
    const ffBtn = L.h('button', { class: 'sl-btn', type: 'button', text: '▶▶ 빨리 보기', hidden: true });
    ffBtn.addEventListener('pointerdown', (e) => { e.stopPropagation(); e.preventDefault(); ff = ff > 1 ? 1 : 5; api.sfx('click'); btnSig = ''; syncButtons(); });
    root.appendChild(ffBtn);
    function placeButtons() { if (lay) ffBtn.style.top = Math.min(lay.h - 50, lay.hintY - 4) + 'px'; }
    let btnSig = '';
    function syncButtons() {
      const M = myB();
      const others = BS.some((B, s) => B && !isMine(s) && B.alive && !B.done);
      const show = !api.online && !!M && (!M.alive || M.done) && others && !!st && st.ph === 'play' && !timeUp();
      if (!show) ff = 1;
      const sig = (show ? 1 : 0) + '|' + ff;
      if (sig === btnSig) return;
      btnSig = sig; ffBtn.hidden = !show; ffBtn.textContent = ff > 1 ? '▶ 보통 속도' : '▶▶ 빨리 보기';
    }

    /* ----- network helpers ----- */
    const zeros = [0, 0, 0, 0];
    function outOf(s) { const B = BS[s]; if (B) return B.out; const r = remote[s]; return r && r.o ? r.o : zeros; }
    function aliveOf(s) { const B = BS[s]; if (B) return B.alive && !B.done; const r = remote[s]; return r ? !!r.a : true; }
    function scoreOf(s) { const B = BS[s]; if (B) return B.sc; const r = remote[s]; return r ? r.sc : 0; }
    function mxOf(s) { const B = BS[s]; if (B) return B.mx; const r = remote[s]; return r ? r.mx : 1; }
    function pendFor(s) { const B = BS[s]; if (B) return pendOf(B); const r = remote[s]; return r ? r.p | 0 : 0; }
    function cellsOf(s) { const B = BS[s]; if (B) return B.c; const r = remote[s]; return r ? r.c : null; }
    function incomingFor(s) {
      let t = versus() && T() === 0 ? rainOf(Math.max(0, tl)) : 0;
      for (let o = 0; o < st.n; o++) if (o !== s) t += outOf(o)[s] | 0;
      return t;
    }
    function takeRow(s, v) {
      const old = remote[s];
      const o = Array.isArray(v.o) ? v.o.slice(0, 4).map((x) => Math.max(0, x | 0)) : [0, 0, 0, 0];
      while (o.length < 4) o.push(0);
      if (old && old.o) for (let i = 0; i < 4; i++) o[i] = Math.max(o[i] | 0, old.o[i] | 0);
      const b = typeof v.b === 'string' ? v.b.slice(0, 25) : (old ? old.b : '');
      remote[s] = { sc: Math.max(0, v.sc | 0), a: v.a ? 1 : 0, b, c: old && old.b === b ? old.c : decode(b, st.sz), o, mx: Math.max(1, v.mx | 0), p: Math.max(0, v.p | 0) };
    }
    function pollNet() {
      if (!api.online || !key) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) { const s = +k, o = rem[k]; if (!(s >= 0 && s < st.n) || BS[s] || !o || o.k !== key) continue; takeRow(s, o); }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== key || !Array.isArray(hs.s)) return;
        hs.s.forEach((a, s) => { if (BS[s] || !Array.isArray(a)) return; takeRow(s, { sc: a[0], a: a[1], b: a[2], o: a[3], mx: a[4], p: a[5] }); });
        if (typeof hs.t === 'number' && st.ph === 'play' && hostT !== hs.t) { hostT = hs.t; if (Math.abs(hs.t - tl) > 0.8) tl = hs.t; }
      }
    }
    function row(s) { return [scoreOf(s), aliveOf(s) || (BS[s] && BS[s].done) ? 1 : 0, BS[s] ? encode(BS[s]) : (remote[s] ? remote[s].b : ''), outOf(s).slice(0, st.n), mxOf(s), pendFor(s)]; }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 0.2;
          const s = []; for (let i = 0; i < st.n; i++) s.push(row(i));
          api.net.hostSend({ k: key, t: Math.round(tl * 10) / 10, s });
        } else {
          const m = mine()[0], B = m != null ? BS[m] : null;
          if (!B || pubT > 0) return;
          const r = row(m), sig = JSON.stringify(r);
          if (sig === lastSig && pubT > -1.2) return;
          lastSig = sig; pubT = 0.15;
          api.net.publish({ k: key, sc: r[0], a: r[1], b: r[2], o: r[3], mx: r[4], p: r[5] });
        }
      } catch (e) {}
    }
    function hostEnd(rdt) {
      if (!host() || !st || st.ph !== 'play' || tl < 0) return;
      let alive = 0;
      for (let s = 0; s < st.n; s++) {
        const B = BS[s], dead = B ? !B.alive : (remote[s] ? !remote[s].a : false);
        if (dead && !dOrd[s]) dOrd[s] = ++dieSeq;
        if (!dead) alive++;
      }
      let over = timeUp();
      if (st.n > 1) { if (alive <= 1) over = true; } else { const B = BS[0]; if (B && (!B.alive || B.done)) over = true; }
      if (!over) { endWait = 0; return; }
      endWait += rdt;
      if (endWait < (api.online ? 1.4 : 1.1)) return;
      const rows = [];
      for (let s = 0; s < st.n; s++) {
        const B = BS[s];
        rows.push([s, scoreOf(s), (B ? B.alive : (remote[s] ? remote[s].a : 1)) ? 1 : 0, dOrd[s] || 0, mxOf(s), Math.round(B && B.goalT >= 0 ? B.goalT : Math.min(tl, T() || tl))]);
      }
      endWait = -1e9;
      api.setState(finish(st, rows));
    }

    /* ----- input ----- */
    function myB() { const m = mine()[0]; return m != null ? BS[m] : null; }
    function canCtl() { const B = myB(); return !!B && !!st && st.ph === 'play' && tl >= 0 && !timeUp() && B.alive && !B.done && !auto(); }
    function pickFor(s) { return () => pickTarget(s, st.n, aliveOf, scoreOf); }
    function moveBoard(s, d) {
      const B = BS[s];
      if (!B) return null;
      return doMove(B, d, tl, versus() ? st.atk : 0, versus() ? pickFor(s) : null);
    }
    function tryMove(d) {
      if (!canCtl()) return;
      const r = moveBoard(mine()[0], d);
      if (!r) { bumpT = 0.16; bumpD = d; api.buzz(6); return; }
      moves++;
      api.buzz(r.mg.length ? 14 : 7);
    }
    function onDown(e) {
      if (!lay || !st) return;
      e.preventDefault();
      const p = cv.local(e);
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      ptr.set(e.pointerId, { x: p.x, y: p.y, used: false });
    }
    function swipeDir(q, p, th) {
      const dx = p.x - q.x, dy = p.y - q.y;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < th) return -1;
      return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
    }
    function onMove(e) {
      const q = ptr.get(e.pointerId);
      if (!q || q.used) return;
      const d = swipeDir(q, cv.local(e), Math.max(18, (lay ? lay.cs : 60) * 0.24));
      if (d >= 0) { q.used = true; tryMove(d); }
    }
    function onUp(e) {
      const q = ptr.get(e.pointerId);
      if (!q) return;
      ptr.delete(e.pointerId);
      if (!q.used) { const d = swipeDir(q, cv.local(e), 12); if (d >= 0) tryMove(d); }
    }
    const onCancel = (e) => ptr.delete(e.pointerId);
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);
    const DIRID = { up: 0, right: 1, down: 2, left: 3 };
    const offKeys = api.input && api.input.on ? api.input.on((type, id) => { if (type === 'down' && DIRID[id] != null) tryMove(DIRID[id]); }) : null;

    /* ----- effects ----- */
    function burst(x, y, col, n, sp, life, r) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = sp * (0.35 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - sp * 0.3, t: life, T: life, c: col, r: (r || 4) * (0.6 + Math.random() * 0.6) }); }
      if (parts.length > 180) parts.splice(0, parts.length - 180);
    }
    function pop(x, y, text, col, big) { floats.push({ x, y, text, col: col || '#fff3c0', t: 1.0, T: 1.0, big: !!big }); if (floats.length > 12) floats.shift(); }
    function cellC(i) { const [x, y] = cellXY(i); return [x + lay.cs / 2, y + lay.cs / 2]; }
    function anchor(s) { // screen point of a seat (my board or its mini card)
      if (s === view) return [lay.bx + lay.bs / 2, lay.by + 8];
      const c = cards().find((q) => q.s === s);
      return c ? [c.x + c.w / 2, c.y + c.h / 2] : [lay.w / 2, 0];
    }
    function onRec(B, rec, me) { // effects for a record of the viewed board
      const sfxOn = me || !mine().length;
      if (rec.k === 'drop') {
        for (const i of rec.drops) fx.set(B.id[i], { fall: vt });
        later.push({ at: vt + FALL, fn: () => { if (sfxOn) { api.sfx('thud'); api.buzz([30, 20, 30]); } shake = Math.max(shake, 0.9); for (const i of rec.drops) { const [x, y] = cellC(i); burst(x, y + lay.cs * 0.35, '#8d8794', 6, 70, 0.4, 3); } } });
        return;
      }
      if (fx.size > 90) fx.clear();
      anim = { t0: vt, mv: rec.mv, d: rec.d };
      for (const m of rec.mv) if (m[0] !== m[1] && !m[4]) fx.set(m[3], { land: vt + SL, d: rec.d });
      let big = 0;
      for (const t of rec.mg) { const v = B.c[t]; fx.set(B.id[t], { pop: vt + SL }); if (v > big) big = v; }
      if (rec.sp >= 0) fx.set(B.id[rec.sp], { grow: vt + SL * 0.6 });
      for (const j of rec.cr) fx.set(B.id[j], { crack: vt + SL });
      const mgv = rec.mg.map((t) => Math.max(1, B.c[t]));
      later.push({ at: vt + SL, fn: () => {
        rec.mg.forEach((t, i) => { const [x, y] = cellC(t), v = mgv[i]; burst(x, y, lvCol(v), 7 + Math.min(8, v), 60 + v * 12, 0.45, 3.5); });
        for (const j of rec.cl) { const [x, y] = cellC(j); burst(x, y, '#9a94a1', 12, 110, 0.55, 4.5); pop(x, y - lay.cs * 0.2, '깨짐!', '#e8e2ee'); }
        rec.mg.forEach((t, i) => { const v = mgv[i], [x, y] = cellC(t); pop(x, y - lay.cs * 0.3, '+' + fmt(Math.pow(2, v)), v >= 7 ? '#ffe27a' : '#fff3c0', v >= 7); });
        if (rec.cancel > 0) pop(lay.bx + lay.bs * 0.5, lay.rowY + lay.rowH / 2 + 4, '막았다! 돌 −' + rec.cancel, '#9dffb0', true);
        if (sfxOn) {
          if (rec.cl.length || rec.cr.length) api.sfx('hit');
          if (big >= GOAL) api.sfx('win'); else if (big >= 5) api.sfx('chip'); else if (big) api.sfx('pop'); else api.sfx('tick');
        }
        if (big >= 6) shake = Math.max(shake, 0.35 + (big - 6) * 0.15);
        if (big > 0 && big > (B._bestShown || 4)) { B._bestShown = big; const [x, y] = cellC(rec.mg[0]); pop(x, y + lay.cs * 0.12, lvName(big) + ' 슬라임!', shade(lvCol(big), 0.5), true); if (me) api.buzz([20, 30, 20]); }
      } });
    }
    function watchShots() { // attack projectiles between any two seats (from the cumulative counters)
      if (!st || !lay) return;
      for (let s = 0; s < st.n; s++) {
        const o = outOf(s), lo = lastOut[s] || (lastOut[s] = [0, 0, 0, 0]);
        for (let t = 0; t < st.n; t++) {
          const d = (o[t] | 0) - lo[t];
          if (d > 0) {
            const [sx, sy] = anchor(s), [tx, ty] = anchor(t);
            for (let k = 0; k < Math.min(d, 5); k++) shots.push({ sx: sx + (k - (Math.min(d, 5) - 1) / 2) * 10, sy, tx, ty, t: -k * 0.06, T: 0.55, to: t, first: k === 0 });
            if (s === view && (isMine(s) || !mine().length)) { api.sfx('whoosh'); pop(sx, sy + lay.bs * 0.18, '돌 ' + d + '개 보냄! → ' + name(t), '#ffcf7a', true); }
          }
          lo[t] = o[t] | 0;
        }
      }
      if (shots.length > 30) shots.splice(0, shots.length - 30);
    }

    /* ----- main loop ----- */
    function frame(rdt) {
      if (!st) { draw(); return; }
      ensureMatch();
      if (!key) { draw(); return; }
      adoptSeats();
      const playing = st.ph === 'play';
      const sp = SPD();
      const fast = ff > 1 && !api.online ? ff : 1;
      const dt = rdt * sp * fast;
      const was = tl;
      if (playing && !timeUp()) tl += dt;
      if (playing && T() > 0 && tl > T()) tl = T();
      pollNet();
      if (playing && was < 0) { const a = Math.ceil(-was), b = Math.ceil(-tl); if (tl < 0 && a !== b && a <= 3) api.sfx('tick'); if (tl >= 0) { api.sfx('pop'); api.buzz(20); } }
      if (playing && tl >= 0 && !timeUp()) {
        BS.forEach((B, s) => {
          if (!B || !B.alive || B.done) return;
          const add = setIncoming(B, incomingFor(s), tl);
          if (add > 0 && s === view && (isMine(s) || !mine().length)) { api.sfx('thud'); api.buzz(25); }
          dropStones(B, tl);
        });
        BS.forEach((B, s) => {
          if (!B || !B.alive || B.done) return;
          const p = api.players[s], bot = p && (p.ai || (auto() && isMine(s)));
          if (!bot) return;
          const m = mem[s];
          m.cd -= dt;
          let guard = 0;
          while (m.cd <= 0 && B.alive && guard++ < 6) {
            const lv = p.ai ? (p.lv || 2) : 3;
            m.cd += aiDelay(lv, m.rng);
            const d = aiPick(B, lv, m.rng);
            if (d < 0) break;
            moveBoard(s, d);
          }
        });
        if (soloKind(st) === 'goal') BS.forEach((B) => { if (B && !B.done && B.mx >= GOAL) { B.done = true; B.goalT = tl; } });
      }
      // records of the viewed board → animation / effects
      BS.forEach((B, s) => { if (B && B.rec && B.rec.seq !== B._seen) { B._seen = B.rec.seq; if (s === view) onRec(B, B.rec, isMine(s)); } });
      watchShots();
      const M = BS[view];
      if (M && (!M.alive || M.done || timeUp()) && !overSeen && playing && tl > 0) {
        overSeen = true;
        const me = isMine(view) || !mine().length;
        if (M.done) { api.sfx('win'); api.buzz([30, 40, 30, 40, 60]); for (let i = 0; i < 5; i++) later.push({ at: vt + i * 0.18, fn: () => burst(lay.bx + lay.bs * (0.2 + Math.random() * 0.6), lay.by + lay.bs * (0.2 + Math.random() * 0.5), lvCol(1 + (Math.random() * 10 | 0)), 16, 160, 0.9, 4) }); }
        else if (!M.alive) { if (me) { api.sfx('lose'); api.buzz([60, 40, 90]); } }
        else if (me) api.sfx('whoosh');
        if (isMine(view) && !auto() && st.n === 1) {
          const nb = recordOf(M);
          if (nb != null && (best == null || (st.solo === 'goal' ? nb < best : nb > best))) {
            if (best != null) pop(lay.w / 2, lay.by + lay.bs * 0.3, '최고 기록! ' + (st.solo === 'goal' ? mmss(nb) : fmt(nb) + '점'), '#ffe27a', true);
            best = nb; try { localStorage.setItem(bestKey(), String(nb)); } catch (e) {}
          }
        }
      }
      if (playing && versus() && T() === 0 && was < RAIN_AT && tl >= RAIN_AT && lay) { api.toast('돌 비가 내리기 시작해요!'); api.sfx('whoosh'); }
      if (timeUp() && !endSeen && playing) { endSeen = true; api.buzz([30, 40, 30]); }
      if (playing && T() > 0 && tl >= T() - 5 && !timeUp() && Math.ceil(T() - was) !== Math.ceil(T() - tl)) api.sfx('tick');
      hostEnd(rdt);
      publish(rdt);
      // effect timers (real time × debug speed)
      const ad = rdt * sp;
      vt += ad;
      for (let i = later.length - 1; i >= 0; i--) if (vt >= later[i].at) { const f = later[i].fn; later.splice(i, 1); try { f(); } catch (e) {} }
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= ad; q.x += q.vx * ad; q.y += q.vy * ad; q.vy += 380 * ad; q.vx *= 0.97; if (q.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= ad; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = shots.length - 1; i >= 0; i--) {
        const q = shots[i]; q.t += ad;
        if (q.t >= q.T) { shots.splice(i, 1); if (q.first) { if (q.to === view) pendShake = 0.5; else flash[q.to] = 0.6; } }
      }
      for (const s in flash) { flash[s] -= ad; if (flash[s] <= 0) delete flash[s]; }
      shake = Math.max(0, shake - ad * 3.5); pendShake = Math.max(0, pendShake - ad * 2); bumpT = Math.max(0, bumpT - ad);
      const tsc = M ? M.sc : 0;
      dispSc += (tsc - dispSc) * Math.min(1, ad * 10);
      if (Math.abs(tsc - dispSc) < 1) dispSc = tsc;
      syncButtons();
      draw();
    }
    const stopLoop = U.loop(frame);

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align, base) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
    function sprite(v, blink, px, badge) {
      const kk = v + '|' + (blink ? 1 : 0) + '|' + px + '|' + (badge ? 1 : 0);
      let c = sprites.get(kk);
      if (c) return c;
      const dpr = DPR();
      c = document.createElement('canvas'); c.width = c.height = Math.max(1, Math.ceil(px * dpr));
      const g = c.getContext('2d'); g.scale(dpr, dpr);
      drawSlime(g, px, v, blink, badge);
      if (sprites.size > 120) sprites.clear();
      sprites.set(kk, c);
      return c;
    }
    function tray() {
      if (trayC) return trayC;
      const dpr = DPR(), bs = lay.bs, m = 8;
      const c = document.createElement('canvas'); c.width = c.height = Math.ceil((bs + m * 2) * dpr);
      const g = c.getContext('2d'); g.scale(dpr, dpr); g.translate(m, m);
      g.fillStyle = 'rgba(0,0,0,.45)'; rr(g, 2, 6, bs, bs, bs * 0.06); g.fill();
      const wd = g.createLinearGradient(0, 0, 0, bs); wd.addColorStop(0, '#8a5a32'); wd.addColorStop(1, '#5c3a1f');
      g.fillStyle = wd; rr(g, 0, 0, bs, bs, bs * 0.06); g.fill();
      g.strokeStyle = 'rgba(227,174,69,.55)'; g.lineWidth = 1.5; rr(g, 1, 1, bs - 2, bs - 2, bs * 0.06); g.stroke();
      g.save(); rr(g, 0, 0, bs, bs, bs * 0.06); g.clip();
      g.strokeStyle = 'rgba(40,20,8,.18)'; g.lineWidth = 1;
      for (let i = 0; i < 14; i++) { const y = (i + 0.5) * bs / 14; g.beginPath(); g.moveTo(0, y); g.bezierCurveTo(bs * 0.3, y + 4, bs * 0.6, y - 4, bs, y + 2); g.stroke(); }
      g.restore();
      const ip = lay.bp * 0.55;
      const jg = g.createLinearGradient(0, ip, 0, bs - ip); jg.addColorStop(0, '#1f5b52'); jg.addColorStop(1, '#123a35');
      g.fillStyle = jg; rr(g, ip, ip, bs - ip * 2, bs - ip * 2, bs * 0.04); g.fill();
      g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 2; g.stroke();
      for (let i = 0; i < lay.n * lay.n; i++) {
        const r = (i / lay.n) | 0, q = i % lay.n, x = lay.bp + q * (lay.cs + lay.gap), y = lay.bp + r * (lay.cs + lay.gap);
        const wg = g.createLinearGradient(0, y, 0, y + lay.cs); wg.addColorStop(0, 'rgba(0,0,0,.32)'); wg.addColorStop(1, 'rgba(255,255,255,.05)');
        g.fillStyle = wg; rr(g, x, y, lay.cs, lay.cs, lay.cs * 0.2); g.fill();
        g.strokeStyle = 'rgba(160,255,220,.07)'; g.lineWidth = 1; g.stroke();
      }
      return (trayC = c);
    }
    function drawTile(x, y, v, id, cs, extraSx, extraSy) {
      let sx = extraSx || 1, sy = extraSy || 1, oy = 0, al = 1;
      const w = Math.sin(vt * 2.6 + id * 1.7) * 0.022 * (v > 0 ? 1 : 0.2);
      sx += w; sy -= w;
      const f = fx.get(id);
      if (f) {
        if (f.grow != null) { const p = (vt - f.grow) / GROW; if (p < 0) return; if (p < 1) { const s = Math.max(0.05, easeBack(p)); sx *= s; sy *= s; } else f.grow = null; }
        if (f.pop != null) { const p = (vt - f.pop) / POP; if (p >= 0 && p < 1) { const k = Math.sin(p * Math.PI); sx *= 1 + 0.3 * k; sy *= 1 + 0.22 * k - 0.1 * Math.sin(p * Math.PI * 2); } else if (p >= 1) f.pop = null; }
        if (f.land != null) { const p = (vt - f.land) / LAND; if (p >= 0 && p < 1) { const k = Math.sin(p * Math.PI) * 0.14; if (f.d % 2) { sx *= 1 - k; sy *= 1 + k * 0.7; } else { sx *= 1 + k * 0.7; sy *= 1 - k; } } else if (p >= 1) f.land = null; }
        if (f.crack != null) { const p = (vt - f.crack) / 0.25; if (p >= 0 && p < 1) x += Math.sin(p * 40) * 3 * (1 - p); else if (p >= 1) f.crack = null; }
        if (f.fall != null) { const p = (vt - f.fall) / FALL; if (p < 1) { const e = p * p; oy = -(1 - e) * (y + cs * 1.2 - lay.by + 40); al = Math.min(1, 0.3 + p * 2); if (p > 0.85) { sy *= 0.85; sx *= 1.12; } } else f.fall = null; }
        if (f.grow == null && f.pop == null && f.land == null && f.crack == null && f.fall == null) fx.delete(id);
      }
      const blink = v > 0 && ((vt * 0.31 + id * 0.137) % 1) < 0.035;
      const spr = sprite(v, blink, Math.round(cs), true);
      ctx.save();
      if (al < 1) ctx.globalAlpha = al;
      ctx.translate(x + cs / 2, y + cs * 0.93 + oy);
      ctx.scale(sx, sy);
      ctx.drawImage(spr, -cs / 2, -cs * 0.93, cs, cs);
      ctx.restore();
    }
    function drawBoard(B) {
      const tr = tray(), m = 8;
      let ox = 0, oy = 0;
      if (shake > 0) { ox = (Math.random() - 0.5) * shake * 8; oy = (Math.random() - 0.5) * shake * 8; }
      if (bumpT > 0) { const k = Math.sin((bumpT / 0.16) * Math.PI) * 5; ox += DIRV[bumpD][0] * k; oy += DIRV[bumpD][1] * k; }
      ctx.save(); ctx.translate(ox, oy);
      ctx.drawImage(tr, lay.bx - m, lay.by - m, lay.bs + m * 2, lay.bs + m * 2);
      let emp = 0; for (const v of B.c) if (!v) emp++;
      if (B.alive && !B.done && emp <= 2 && tl >= 0 && st.ph === 'play') { ctx.strokeStyle = 'rgba(238,106,85,' + (0.35 + 0.3 * Math.sin(vt * 8)) + ')'; ctx.lineWidth = 4; rr(ctx, lay.bx - 3, lay.by - 3, lay.bs + 6, lay.bs + 6, lay.bs * 0.065); ctx.stroke(); }
      const cs = lay.cs;
      const sl = anim && vt - anim.t0 < SL ? (vt - anim.t0) / SL : -1;
      if (sl >= 0) {
        const e = easeOut(sl), d = anim.d, k = 1 + 0.1 * Math.sin(sl * Math.PI);
        for (const mv of anim.mv) {
          const a = cellXY(mv[0]), b = cellXY(mv[1]);
          const x = a[0] + (b[0] - a[0]) * e, y = a[1] + (b[1] - a[1]) * e, moving = mv[0] !== mv[1];
          drawTile(x, y, mv[2], mv[3], cs, moving ? (d % 2 ? k : 1 / k) : 1, moving ? (d % 2 ? 1 / k : k) : 1);
        }
      } else {
        anim = null;
        for (let i = 0; i < B.c.length; i++) { const v = B.c[i]; if (!v) continue; const [x, y] = cellXY(i); drawTile(x, y, v, B.id[i], cs); }
      }
      ctx.restore();
    }
    function cards() {
      if (!st || !lay || !lay.miniH) return [];
      const others = []; for (let s = 0; s < st.n; s++) if (s !== view) others.push(s);
      const k = others.length, gap = 6, cw = (lay.w - lay.pad * 2 - gap * (k - 1)) / k;
      return others.map((s, i) => ({ s, x: lay.pad + i * (cw + gap), y: lay.miniY, w: cw, h: lay.miniH }));
    }
    function drawMini(c, x, y, size, n, dead) {
      ctx.fillStyle = '#123a35'; rr(ctx, x, y, size, size, size * 0.08); ctx.fill();
      ctx.strokeStyle = '#6b4526'; ctx.lineWidth = 2; ctx.stroke();
      if (!c) return;
      const p = size * 0.05, g = size * 0.02, cs = (size - p * 2 - g * (n - 1)) / n;
      for (let i = 0; i < n * n; i++) {
        const v = c[i], r = (i / n) | 0, q = i % n, cx = x + p + q * (cs + g), cy = y + p + r * (cs + g);
        if (!v) { ctx.fillStyle = 'rgba(0,0,0,.25)'; rr(ctx, cx, cy, cs, cs, cs * 0.25); ctx.fill(); continue; }
        ctx.fillStyle = dead ? '#55505c' : v < 0 ? (v === -1 ? '#8b8592' : '#6e6875') : lvCol(v);
        rr(ctx, cx, cy, cs, cs, cs * (v < 0 ? 0.15 : 0.42)); ctx.fill();
        if (v > 0 && cs >= 11) txt(String(v), cx + cs / 2, cy + cs / 2 + 0.5, 'rgba(23,19,31,.8)', '700 ' + Math.round(cs * 0.55) + 'px ' + MONO);
      }
    }
    function drawCards() {
      for (const c of cards()) {
        const s = c.s, alive = aliveOf(s), done = BS[s] && BS[s].done, out = !alive && !done, fl = flash[s] || 0;
        ctx.fillStyle = fl > 0 ? 'rgba(238,106,85,' + (0.25 + fl * 0.5) + ')' : 'rgba(46,38,64,.85)';
        rr(ctx, c.x, c.y, c.w, c.h, 10); ctx.fill();
        ctx.strokeStyle = alive ? 'rgba(227,174,69,.35)' : 'rgba(255,255,255,.08)'; ctx.lineWidth = 1; ctx.stroke();
        const col = Pl(s).color || '#888', cells = cellsOf(s), pend = pendFor(s);
        if (lay.k === 1) {
          const size = c.h - 12;
          drawMini(cells, c.x + 6, c.y + 6, size, st.sz, out);
          const tx = c.x + size + 16, tw = c.w - size - 24;
          ctx.fillStyle = col; ctx.beginPath(); ctx.arc(tx + 5, c.y + 17, 5, 0, TAU); ctx.fill();
          txt(fitText(name(s), tw - 14, '700 13px ' + FONT), tx + 14, c.y + 17, '#f2e9d8', '700 13px ' + FONT, 'left');
          txt(fmt(scoreOf(s)) + '점', tx, c.y + 38, '#e3ae45', '700 17px ' + MONO, 'left');
          txt(out ? '탈락' : pend > 0 ? '받을 돌 ' + pend + '개' : '최고 ' + lvName(mxOf(s)) + ' Lv' + mxOf(s), tx, c.y + 57, out ? '#ee6a55' : pend > 0 ? '#ffb4a6' : '#ab9fb8', '600 12px ' + FONT, 'left');
        } else {
          ctx.fillStyle = col; ctx.beginPath(); ctx.arc(c.x + 10, c.y + 11, 4.5, 0, TAU); ctx.fill();
          txt(fitText(name(s), c.w - 24, '700 12px ' + FONT), c.x + 18, c.y + 11, '#f2e9d8', '700 12px ' + FONT, 'left');
          const size = Math.min(c.w - 12, c.h - 42);
          drawMini(cells, c.x + (c.w - size) / 2, c.y + 21, size, st.sz, out);
          const sy = c.y + c.h - 11;
          if (out) txt(fitText('탈락 · ' + fmt(scoreOf(s)), c.w - 6, '700 12px ' + MONO), c.x + c.w / 2, sy, '#ee6a55', '700 12px ' + MONO);
          else txt(fitText(fmt(scoreOf(s)) + (pend > 0 ? ' ⚠' + pend : ''), c.w - 6, '700 12px ' + MONO), c.x + c.w / 2, sy, pend > 0 ? '#ffb4a6' : '#e3ae45', '700 12px ' + MONO);
        }
        if (out) { ctx.fillStyle = 'rgba(23,19,31,.35)'; rr(ctx, c.x, c.y, c.w, c.h, 10); ctx.fill(); }
      }
    }
    function drawHud(B) {
      const y = lay.hudY, x0 = lay.bx, x1 = lay.bx + lay.bs;
      txt('점수', x0 + 2, y + 10, '#ab9fb8', '600 11px ' + FONT, 'left');
      txt(fmt(dispSc), x0 + 2, y + 30, '#f2e9d8', '700 22px ' + MONO, 'left');
      let clock = '', cc = '#f2e9d8';
      if (T() > 0) { const r = T() - Math.max(0, tl); clock = mmss(r); if (r <= 10 && tl >= 0) cc = '#ee6a55'; }
      else clock = mmss(Math.max(0, Math.min(tl, B && B.goalT >= 0 ? B.goalT : tl)));
      txt(T() > 0 ? '남은 시간' : (st.n === 1 ? '걸린 시간' : '시간'), lay.w / 2, y + 10, '#ab9fb8', '600 11px ' + FONT);
      txt(clock, lay.w / 2, y + 30, cc, '700 20px ' + MONO);
      const mx = B ? B.mx : 1, ss = 34;
      ctx.drawImage(sprite(mx, false, ss, false), x1 - ss, y + 6, ss, ss);
      txt('최고', x1 - ss - 4, y + 10, '#ab9fb8', '600 11px ' + FONT, 'right');
      txt(lvName(mx) + ' Lv' + mx, x1 - ss - 4, y + 30, lvCol(mx), '700 13px ' + FONT, 'right');
    }
    function drawRow(B) {
      const y = lay.rowY, h = lay.rowH, x0 = lay.bx, x1 = lay.bx + lay.bs, cy = y + h / 2;
      if (st.n === 1) {
        if (st.solo === 'goal') { // goal ladder 1..8
          const k = GOAL, gs = Math.min(28, (lay.bs - 8) / k), sx = lay.w / 2 - gs * k / 2;
          for (let v = 1; v <= k; v++) {
            ctx.globalAlpha = B && B.mx >= v ? 1 : 0.25;
            ctx.drawImage(sprite(v, false, Math.round(gs), false), sx + (v - 1) * gs, cy - gs / 2 - 1, gs, gs);
          }
          ctx.globalAlpha = 1;
          return;
        }
        const need = starNeed(st), sc = B ? B.sc : 0, segW = lay.bs / 3;
        need.forEach((v, i) => txt('★'.repeat(i + 1) + ' ' + fmt(v), x0 + segW * (i + 0.5), cy, sc >= v ? '#ffd457' : '#7d7190', '700 13px ' + MONO));
        return;
      }
      if (!B) return;
      const p = pendOf(B), sx = Math.sin(pendShake * 40) * pendShake * 6;
      if (p > 0 && B.alive) {
        const fuse = B.pendT >= 0 ? U.clamp((tl - B.pendT) / DROP_DELAY, 0, 1) : 0;
        ctx.fillStyle = 'rgba(238,106,85,.16)'; rr(ctx, x0 + sx, y + 2, lay.bs, h - 4, 8); ctx.fill();
        ctx.fillStyle = 'rgba(238,106,85,.45)'; rr(ctx, x0 + sx, y + 2, Math.max(16, lay.bs * fuse), h - 4, 8); ctx.fill();
        const ss = h - 6, show = Math.min(p, 5);
        for (let i = 0; i < show; i++) ctx.drawImage(sprite(-1, false, ss, false), x0 + 6 + sx + i * (ss * 0.8), y + 2, ss, ss);
        txt('돌 ' + p + '개가 곧 떨어져요', x1 - 8 + sx, cy, '#ffd0c6', '700 12px ' + FONT, 'right');
      } else {
        txt('보낸 돌 ' + B.sent + ' · 깬 돌 ' + B.broke, x0 + 2, cy, '#ab9fb8', '600 12px ' + FONT, 'left');
        txt(st.atk ? (st.atk === 2 ? 'Lv4' : 'Lv5') + '부터 공격!' : '방해 끔', x1 - 2, cy, '#7d7190', '600 12px ' + FONT, 'right');
      }
    }
    function drawOverlayText(B) {
      const cx = lay.w / 2, cy = lay.by + lay.bs / 2;
      if (st.ph === 'play' && tl < 0) { // countdown + tips
        ctx.fillStyle = 'rgba(23,19,31,.62)'; rr(ctx, lay.bx, lay.by, lay.bs, lay.bs, lay.bs * 0.06); ctx.fill();
        const n = Math.ceil(-tl);
        const tips = st.n === 1
          ? (st.solo === 'goal' ? ['왕관 슬라임(Lv8)을 만들면 성공!', '같은 슬라임 둘을 밀어 붙이면 합쳐져요', '큰 슬라임은 한쪽 구석에 모아 두세요'] : ['시간 안에 점수를 모아요', '큰 슬라임을 합칠수록 점수가 커요', '큰 슬라임은 한쪽 구석에 모아 두세요'])
          : ['같은 슬라임 둘을 밀어 붙이면 합쳐져요', (st.atk === 2 ? 'Lv4' : 'Lv5') + ' 이상을 만들면 상대에게 돌 슬라임!', st.atk ? '돌은 바로 옆에서 두 번 합치면 깨져요' : '막혀서 못 밀면 탈락이에요'];
        const tw = Math.min(lay.bs - 24, 320), th = 96, tx = cx - tw / 2, ty = lay.by + lay.bs * 0.56;
        if (n > 0) txt(String(n), cx, lay.by + lay.bs * 0.3, '#ffd457', Math.round(lay.bs * 0.22) + 'px ' + DISP);
        ctx.fillStyle = 'rgba(34,28,46,.94)'; rr(ctx, tx, ty, tw, th, 12); ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
        tips.forEach((t, i) => txt(fitText('· ' + t, tw - 20, '600 13px ' + FONT), tx + 12, ty + 21 + i * 27, '#f2e9d8', '600 13px ' + FONT, 'left'));
        return;
      }
      if (!B) return;
      if (!B.alive || B.done || (timeUp() && st.ph === 'play')) {
        ctx.fillStyle = B.done ? 'rgba(23,19,31,.3)' : 'rgba(23,19,31,.58)'; rr(ctx, lay.bx, lay.by, lay.bs, lay.bs, lay.bs * 0.06); ctx.fill();
        let a = '', b = '';
        if (B.done && B.goalT >= 0) { a = '왕관 슬라임 완성!'; b = mmss(B.goalT) + ' 걸렸어요'; }
        else if (B.done) return;
        else if (!B.alive) { a = '더 밀 수 없어요!'; b = st.n > 1 ? (st.ph === 'play' ? '탈락 — 남은 경기를 지켜봐요' : '탈락') : '판이 꽉 찼어요'; }
        else { a = '시간 끝!'; b = '결과를 모으는 중…'; }
        ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 8;
        txt(a, cx, cy - 12, B.done ? '#ffd457' : '#f2e9d8', Math.round(Math.min(30, lay.bs * 0.085)) + 'px ' + DISP);
        ctx.restore();
        txt(b, cx, cy + 22, '#d8cce4', '600 13px ' + FONT);
      }
    }
    function drawHint(B) {
      if (!st || st.ph !== 'play' || tl < 0 || !ffBtn.hidden) return;
      const y = lay.hintY + 14;
      let t = '';
      if (B && isMine(view) && B.alive && !B.done && !timeUp()) {
        t = '화면 어디서나 밀어서 모든 슬라임을 움직여요';
        if (fine) {
          t = '드래그하거나 방향키 · WASD로 밀어요';
          try { if (api.input && api.input.bindings) { const bb = api.input.bindings(); const k = (id) => { const x = bb.find((o) => o.id === id); return x && x.keys && x.keys[0] ? keyName(x.keys[0]) : '?'; }; t = '밀기: ' + k('up') + ' ' + k('left') + ' ' + k('down') + ' ' + k('right') + ' · 드래그도 돼요'; } } catch (e) {}
        } else if (moves >= 8) t = versus() ? '돌 슬라임 옆에서 두 번 합치면 깨져요' : '큰 슬라임은 한쪽 구석에 모아 두세요';
      } else if (!mine().length) t = 'AI 대전을 보는 중';
      if (t && y < lay.h - 6) txt(fitText(t, lay.w - 20, '600 12px ' + FONT), lay.w / 2, y, '#ab9fb8', '600 12px ' + FONT);
    }
    function drawFx() {
      for (const q of parts) { ctx.globalAlpha = Math.max(0, q.t / q.T); ctx.fillStyle = q.c; ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, TAU); ctx.fill(); }
      ctx.globalAlpha = 1;
      for (const q of shots) {
        if (q.t < 0) continue;
        const p = q.t / q.T, x = q.sx + (q.tx - q.sx) * p, y = q.sy + (q.ty - q.sy) * p - Math.sin(p * Math.PI) * 60, s = 18;
        ctx.drawImage(sprite(-1, false, s, false), x - s / 2, y - s / 2, s, s);
      }
      for (const f of floats) {
        const p = 1 - f.t / f.T;
        ctx.globalAlpha = Math.min(1, f.t * 3);
        const font = (f.big ? '800 17px ' : '700 14px ') + FONT;
        const tt = fitText(f.text, lay.w - 16, font), tw = ctx.measureText(tt).width;
        ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const yy = f.y - p * 28, xx = U.clamp(f.x, tw / 2 + 6, lay.w - tw / 2 - 6);
        ctx.strokeText(tt, xx, yy); ctx.fillStyle = f.col; ctx.fillText(tt, xx, yy);
      }
      ctx.globalAlpha = 1;
    }
    function draw() {
      cv.clear();
      const w = cv.w, h = cv.h;
      if (!bgG || bgW !== w || bgH !== h) { bgW = w; bgH = h; bgG = ctx.createRadialGradient(w / 2, h * 0.55, 20, w / 2, h * 0.55, Math.max(w, h) * 0.75); bgG.addColorStop(0, '#2a2238'); bgG.addColorStop(1, '#17131f'); }
      ctx.fillStyle = bgG; ctx.fillRect(0, 0, w, h);
      if (!st || !lay || !key) return;
      const B = BS[view];
      drawCards();
      if (st.n === 1 && lay.hudY > 40) {
        const y = Math.max(22, lay.hudY / 2);
        txt(st.solo === 'goal' ? '왕관 슬라임 만들기' : '점수 도전 · ' + mmss(timeOf(st)), lay.w / 2, y - 10, '#e3ae45', '19px ' + DISP);
        txt(best == null ? '첫 기록에 도전!' : '내 최고 기록 ' + (st.solo === 'goal' ? mmss(best) : fmt(best) + '점'), lay.w / 2, y + 14, '#ab9fb8', '600 12px ' + FONT);
      }
      drawHud(B);
      drawRow(B);
      if (B) drawBoard(B);
      drawOverlayText(B);
      drawHint(B);
      drawFx();
    }

    root._sl = { BS: () => BS, tl: () => tl, lay: () => lay, move: (d) => tryMove(d), remote: () => remote, view: () => view }; // test hook
    return {
      update(state) { st = state; if (st) ensureMatch(); },
      destroy() {
        stopLoop();
        if (offKeys) try { offKeys(); } catch (e) {}
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onCancel);
        cv.cv.removeEventListener('contextmenu', noCtx);
        ffBtn.remove(); styleEl.remove(); cv.destroy();
        delete root._sl;
      },
    };
  }

  L.register({
    id: 'slime', name: '슬라임 합체 대전', tag: '밀어 합치기 대전', cat: '아케이드',
    blurb: '밀어서 같은 슬라임끼리 합쳐 키워요. 크게 합칠수록 상대 판에 돌 슬라임이 떨어져요. 끝까지 버티면 승리!',
    tint: '#1f6a5a',
    icon: '<path d="M8 44c0-15 9-27 20-27s20 12 20 27c0 3-2 5-5 5H13c-3 0-5-2-5-5z" fill="currentColor" fill-opacity=".22" stroke="currentColor" stroke-width="3"/><path d="M28 17c-2-5 1-9 5-10" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="21" cy="34" r="3.6" fill="currentColor"/><circle cx="35" cy="34" r="3.6" fill="currentColor"/><path d="M24 41q4 3 8 0" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M17 26q2-3 5-3" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" opacity=".7"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'up', label: '위로 밀기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 밀기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 밀기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 밀기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
    ],
    options: [
      { id: 'size', label: '판 크기', choices: [{ v: 4, label: '4×4' }, { v: 5, label: '5×5 (넉넉)' }], def: 4 },
      { id: 'time', label: '시간', choices: [{ v: 120, label: '2분' }, { v: 180, label: '3분' }, { v: 300, label: '5분' }, { v: 0, label: '끝까지' }], def: 180 },
      { id: 'atk', label: '방해 슬라임', choices: [{ v: 1, label: '보통' }, { v: 2, label: '많이' }, { v: 0, label: '끄기' }], def: 1 },
      { id: 'solo', label: '혼자 할 때', choices: [{ v: 'goal', label: '왕관 만들기' }, { v: 'score', label: '점수 도전' }], def: 'goal' },
    ],
    quick: [
      '화면을 밀면 판 위 슬라임이 모두 그쪽으로 미끄러져요. 같은 슬라임 둘이 부딪히면 한 단계 큰 슬라임으로 합체!',
      '통통 슬라임(Lv5) 이상을 만들면 상대 판에 돌 슬라임이 떨어져요. 돌은 바로 옆에서 두 번 합체하면 깨져요.',
      '더 밀 수 없으면 탈락. 마지막까지 남거나, 시간이 끝났을 때 남은 사람 중 점수가 가장 높으면 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '각자 자기 판(4×4)에서 슬라임을 밀어 합치며 키워요. 모두 동시에, 쉬지 않고 진행돼요.',
        '여럿이면: 상대 판을 돌 슬라임으로 꽉 막히게 해서 마지막까지 살아남으면 승리! 시간이 먼저 끝나면 남은 사람 중 점수가 가장 높은 사람이 이겨요.',
        '혼자면(「혼자 할 때」 옵션): 「왕관 만들기」는 왕관 슬라임(Lv8)을 만들면 성공 — 1:40 안에 ★★★, 2:50 안에 ★★, 그보다 늦으면 ★. 「점수 도전」은 「시간」 옵션만큼(끝까지 = 3분) 점수를 모아요. 별 기준 점수는 판 위에 보여요(3분: 1,400 · 2,600 · 3,800).',
      ] },
      { h: '밀기와 합체', p: [
        '화면을 위·아래·왼쪽·오른쪽으로 밀면, 판 위 슬라임이 전부 그쪽 끝까지 미끄러져요.',
        '같은 크기 슬라임 둘이 부딪히면 한 단계 큰 슬라임 하나가 돼요. 한 번 합쳐진 슬라임은 그 밀기에서 또 합쳐지지 않아요.',
        '밀 때마다 빈칸 하나에 작은 슬라임(물방울, 가끔 아기)이 새로 생겨요. 아무것도 안 움직이는 방향으로는 밀 수 없어요.',
        '슬라임 단계: 1 물방울 → 2 아기 → 3 꼬마 → 4 말랑 → 5 통통 → 6 쫀득 → 7 탱글 → 8 왕관 → 9 별빛 → 10 보석 … 오른쪽 아래 숫자가 단계예요.',
      ] },
      { h: '점수', p: [
        '합체할 때마다 새로 생긴 슬라임 크기만큼 점수를 받아요: Lv2 = 4점, Lv3 = 8점, Lv4 = 16점 … 한 단계마다 두 배.',
        '그래서 큰 슬라임을 만들수록 점수가 훨씬 커져요.',
      ] },
      { h: '방해 슬라임 (여럿일 때)', p: [
        '통통(Lv5) 1개 · 쫀득(Lv6) 1개 · 탱글(Lv7) 2개 · 왕관(Lv8) 3개 · 별빛(Lv9) 이상 4개의 돌 슬라임을 보내요. 한 번에 3번 이상 합체하면 +1개.',
        '돌은 지금 점수가 가장 높은(살아 있는) 상대에게 날아가요.',
        '받은 돌은 판 위 빨간 줄에 잠깐(약 2.6초) 머문 뒤 빈칸에 떨어져요(한 번에 최대 3개). 그 전에 내가 돌을 보내면, 받을 돌이 그만큼 먼저 없어져요(막기).',
        '돌 슬라임은 다른 슬라임처럼 밀리지만 절대 합쳐지지 않아요. 바로 옆(위·아래·왼쪽·오른쪽) 칸에서 합체가 일어나면 금이 가고, 두 번째에 깨져서 사라져요.',
        '「방해 슬라임: 많이」는 말랑(Lv4)부터 보내요(Lv4 1개 · Lv5 2개 · Lv6 3개 · Lv7 4개 · Lv8 이상 5개, 한 번에 2번 합체해도 +1). 「끄기」는 돌 없이 점수·버티기만 겨뤄요.',
        '「시간: 끝까지」면 시간 제한 없이 한 명이 남을 때까지! 4분이 지나면 모두의 판에 돌 비가 내리기 시작하고(처음엔 8초에 하나), 시간이 갈수록 점점 빨라져요.',
      ] },
      { h: '조작', p: [
        '폰: 화면 아무 곳이나 손가락으로 밀어요(판 밖도 돼요). 한 번 밀 때 한 방향만 움직여요.',
        'PC: 마우스로 끌기, 또는 방향키 · WASD. 게임패드: 십자키 · 왼스틱. 키는 「⌨ 조작 설정」에서 바꿔요.',
        '내가 탈락해도 경기는 계속돼요. 위쪽 작은 판에서 친구들 판과 점수, 받을 돌(⚠)이 보여요. 혼자 AI와 할 땐 「빨리 보기」로 넘길 수 있어요.',
      ] },
      { h: '예시', p: [
        '한 줄에 [아기][아기][물방울][ ]가 있을 때 왼쪽으로 밀면 → [꼬마][물방울][ ][ ]. 아기 둘이 꼬마로 합쳐져 8점!',
        '내 판에 통통(Lv5)이 둘 있어 합쳐 쫀득(Lv6)을 만들면 → 상대에게 돌 1개. 마침 받을 돌이 2개 있었다면 1개를 막아서 1개만 떨어져요.',
      ] },
      { h: '팁 · 함께 하기', p: [
        '가장 큰 슬라임을 한쪽 구석에 두고, 그 옆으로 차례로 작은 슬라임을 줄 세우면 오래 버텨요.',
        '받을 돌이 보이면 서둘러 합체해서 막아요. 돌은 큰 합체 옆에 두면 금방 깨져요.',
        '한 폰에서는 한 명만 해요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로! AI 난이도는 자리마다 쉬움·보통·어려움(어려움은 빠르고 몇 수 앞을 봐요).',
      ] },
    ],
    init, actor: () => null, apply() { throw new Error('realtime game: no turn actions'); }, ai: () => null, result, mount,
    _t: { slide, canMove, newBoard, doMove, dropStones, setIncoming, pendOf, aiPick, aiDelay, evalC, atkOf, pickTarget, encode, decode, rainOf, init, finish, result, starsOf, starNeed, mkRng, GOAL, DROP_DELAY },
  });
})();
