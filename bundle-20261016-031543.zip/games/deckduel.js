/* 마법 카드 덱 쌓기 — 덱빌딩 마법사 대결 (2–4명, 혼자 하기는 보스전 + 별 3개).
   모두 같은 약한 시작 덱(마나 구슬 7 + 마력 화살 3)으로 시작해, 매 차례 5장을 뽑아 카드를 내고(마나·공격·방어막·뽑기·정리·별),
   마나로 가운데 시장의 마법 카드를 사서 버린 더미에 넣어요. 덱이 다 떨어지면 버린 더미를 섞어 새 덱으로 → 산 카드가 점점 나와요.
   4학파(불=공격, 물=뽑기·방어막, 숲=마나·정리·회복, 별=별 점수) + 연쇄(이번 차례 같은 학파 카드를 먼저 냈으면 추가 효과).
   이기는 법: 상대 마법사를 모두 쓰러뜨리기(생명 0) 또는, 누군가 별 목표에 닿은 바퀴가 끝날 때 ★이 가장 많기.
   State (JSON, small — 카드는 한 글자 id = String.fromCharCode(48 + 카드 번호)):
     { n 사람 수, N 싸우는 자리 수(혼자면 2: 0 = 나, 1 = 보스), mx 최대 생명, g 별 목표, bo 보스 종류(−1 = 없음), bi 보스 행동 순번,
       hp[], sh[] 방어막, st[] 별, d[] 덱(앞이 맨 위), h[] 손, c[] 버린 더미, cur 차례, r 바퀴, mn 마나, ch 이번 차례 낸 학파 비트,
       pl 이번 차례 낸 카드, pd 남은 정리 수, tp 다음 산 카드 덱 위로, mk 시장 5칸('_' = 빈칸), sp 남은 공급 더미, rs 섞기 씨앗,
       ph 'p' | 'x', w 승자, why, seq, last } */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- cards ---------- */
  const SCH = [
    { n: '불', ic: '🔥', col: '#ff7a45', dk: '#4a1a10', lt: '#ffb08a' },
    { n: '물', ic: '💧', col: '#4fb3ff', dk: '#10304d', lt: '#9fd6ff' },
    { n: '숲', ic: '🌿', col: '#62d16f', dk: '#163a1c', lt: '#a8eab0' },
    { n: '별', ic: '⭐', col: '#ffd34a', dk: '#43340c', lt: '#ffe79a' },
    { n: '기본', ic: '◆', col: '#c7b6e6', dk: '#2a2338', lt: '#e4dcf3' },
    { n: '저주', ic: '☠', col: '#9a8aa8', dk: '#1d1724', lt: '#cfc4da' },
  ];
  /* e: 효과 (m 마나, a 상대 하나 피해, A 모든 상대 피해, d 카드 뽑기, s 방어막, h 생명 회복, t 별, x 손 카드 정리, T 다음 산 카드 덱 위로)
     k: 연쇄 추가 효과, b: 한 번 쓰면 사라짐, q: 공급 더미 장수 (0 = 시장에 안 나옴) */
  const C = [
    { n: '마나 구슬', s: 4, c: 0, e: { m: 1 } },
    { n: '마력 화살', s: 4, c: 0, e: { a: 1 } },
    { n: '큰 마나 구슬', s: 4, c: 3, e: { m: 2 } },
    { n: '별 조각', s: 4, c: 4, e: { t: 1 } },
    { n: '가시 저주', s: 5, c: 0, e: {} },
    // 불 — 공격
    { n: '불똥', s: 0, c: 2, e: { a: 2 }, k: { a: 1 } },
    { n: '불씨 화로', s: 0, c: 3, e: { m: 1, a: 1 }, k: { d: 1 } },
    { n: '폭발 물약', s: 0, c: 2, e: { a: 4 }, b: 1 },
    { n: '불태우기', s: 0, c: 3, e: { a: 2, x: 1 } },
    { n: '화염구', s: 0, c: 4, e: { a: 4 }, k: { a: 2 } },
    { n: '불바다', s: 0, c: 5, e: { A: 3 }, k: { m: 1 } },
    { n: '불사조 깃털', s: 0, c: 6, e: { a: 3, h: 3 }, k: { a: 2 } },
    { n: '용의 숨결', s: 0, c: 7, e: { a: 6 }, k: { A: 2 } },
    // 물 — 뽑기·방어막
    { n: '물방울', s: 1, c: 1, e: { d: 1, s: 1 } },
    { n: '얼음 방패', s: 1, c: 2, e: { s: 3 }, k: { d: 1 } },
    { n: '파도', s: 1, c: 3, e: { d: 2 }, k: { s: 2 } },
    { n: '맑은 샘', s: 1, c: 4, e: { m: 2, d: 1 } },
    { n: '소용돌이', s: 1, c: 4, e: { a: 2, d: 1 }, k: { a: 2 } },
    { n: '거울 호수', s: 1, c: 5, e: { s: 5, d: 1 }, k: { h: 2 } },
    { n: '해일', s: 1, c: 6, e: { A: 2, d: 2 } },
    { n: '깊은 바다', s: 1, c: 7, e: { d: 3, m: 1 }, k: { s: 3 } },
    // 숲 — 마나·정리·회복
    { n: '새싹', s: 2, c: 1, e: { x: 1 }, k: { m: 1 } },
    { n: '약초', s: 2, c: 2, e: { h: 3 }, k: { h: 2 } },
    { n: '뿌리', s: 2, c: 2, e: { m: 1, x: 1 } },
    { n: '덩굴 채찍', s: 2, c: 3, e: { a: 2, m: 1 }, k: { a: 1 } },
    { n: '버섯 고리', s: 2, c: 3, e: { d: 1, m: 1 }, k: { m: 1 } },
    { n: '숲의 정령', s: 2, c: 4, e: { m: 2, x: 1 }, k: { d: 1 } },
    { n: '고목', s: 2, c: 5, e: { m: 3 }, k: { h: 2 } },
    { n: '거목의 축복', s: 2, c: 6, e: { m: 3, h: 3 }, k: { a: 3 } },
    // 별 — 별 점수
    { n: '별가루', s: 3, c: 2, e: { t: 1 }, k: { t: 1 } },
    { n: '별자리 지도', s: 3, c: 3, e: { t: 1, d: 1 } },
    { n: '소원 별똥', s: 3, c: 3, e: { t: 2, m: 2 }, b: 1 },
    { n: '유성', s: 3, c: 4, e: { t: 1, a: 3 } },
    { n: '별의 서고', s: 3, c: 4, e: { d: 2, T: 1 }, k: { t: 1 } },
    { n: '달빛', s: 3, c: 4, e: { t: 2 }, k: { t: 1 } },
    { n: '북극성', s: 3, c: 6, e: { t: 3, s: 3 }, k: { t: 1 } },
    { n: '은하수', s: 3, c: 7, e: { t: 4 }, k: { t: 1 } },
  ];
  C.forEach((K, i) => { K.id = i; K.ch = String.fromCharCode(48 + i); K.q = K.s < 4 ? (K.c <= 3 ? 3 : 2) : 0; K.pm = Object.keys(K.e).length === 1 && K.e.m > 0 && !K.k; });
  const ORB = 0, ARROW = 1, BIGORB = 2, STARBIT = 3, CURSE = 4;
  const FIX = [BIGORB, STARBIT];           // 시장 옆 상설 더미 (언제나 살 수 있음, 장수 무한)
  const NMK = 5, HAND = 5, RMAX = 30;
  const GOAL = { 30: 11, 40: 15, 50: 19 };      // 생명 → 별 목표
  const cid = (ch) => ch.charCodeAt(0) - 48;
  const KEYS = ['m', 'a', 'A', 'd', 's', 'h', 't', 'x', 'T'];

  /* 혼자 하기 보스: pat = 행동 차례 [종류, 값, 값2] — a 공격, s 방어막, c 저주 카드 값장 + 공격 값2, v 흡수(공격 + 회복), A 큰 공격
     매 5바퀴마다 공격 +1(분노). 별 기준: 이긴 바퀴 ≤ T[0] ★★★, ≤ T[1] ★★, 이기면 ★ */
  const BOSS = [
    { n: '돌 골렘', ic: '🗿', hp: 40, g: 12, pat: [['a', 2], ['s', 4], ['a', 3], ['c', 1, 2], ['a', 4]], T: [10, 13], d: '느리지만 단단해요' },
    { n: '서리 마녀', ic: '🧙', hp: 50, g: 14, pat: [['a', 3], ['c', 1, 2], ['s', 5], ['a', 4], ['v', 3]], T: [11, 14], d: '저주 카드를 섞어 넣고 생명을 빨아 가요' },
    { n: '그림자 용', ic: '🐉', hp: 60, g: 15, pat: [['a', 3], ['s', 5], ['c', 1, 2], ['a', 4], ['a', 3], ['A', 7]], T: [11, 14], d: '6번째마다 큰 불길을 뿜어요' },
  ];
  const rage = (s) => Math.floor((s.r - 1) / 5);
  function bossIntent(s) {
    const B = BOSS[s.bo], p = B.pat[s.bi % B.pat.length], R = rage(s);
    const k = p[0];
    if (k === 's') return { k, s: p[1] + R };
    if (k === 'c') return { k, c: p[1], a: p[2] + R };
    if (k === 'v') return { k, a: p[1] + R, h: p[1] + R };
    return { k, a: p[1] + R };
  }

  /* ---------- seeded rng (state carries the seed so every shuffle is reproducible) ---------- */
  function rnd(s) {
    let t = (s.rs = (s.rs + 0x6D2B79F5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  function shuf(s, str) {
    const a = str.split('');
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd(s) * (i + 1)); const x = a[i]; a[i] = a[j]; a[j] = x; }
    return a.join('');
  }

  /* ---------- rules ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(1, Math.min(4, (players || []).length || 2));
    const solo = n === 1;
    const mx = solo ? 40 : ([30, 40, 50].includes(opts.hp) ? opts.hp : 40);
    const bo = solo ? ([0, 1, 2].includes(opts.boss) ? opts.boss : 1) : -1;
    const N = solo ? 2 : n;
    const s = {
      n, N, mx, g: solo ? BOSS[bo].g : GOAL[mx] - Math.max(0, n - 2), bo, bi: 0,
      hp: Array(N).fill(mx), sh: Array(N).fill(0), st: Array(N).fill(0),
      d: Array(n).fill(''), h: Array(n).fill(''), c: Array(n).fill(''),
      cur: 0, r: 1, mn: 0, ch: 0, pl: '', pd: 0, tp: 0, mk: '', sp: '', rs: (Math.random() * 4294967296) >>> 0,
      ph: 'p', w: null, why: '', seq: 0, last: null,
      nm: (players || []).slice(0, n).map((q, i) => String((q && q.name) || (i + 1) + '번').slice(0, 8)),
    };
    if (solo) s.hp[1] = BOSS[bo].hp;
    let sup = '';
    C.forEach((K) => { for (let q = 0; q < K.q; q++) sup += K.ch; });
    sup = shuf(s, sup);
    s.mk = sup.slice(0, NMK); s.sp = sup.slice(NMK);
    for (let i = 0; i < n; i++) {
      s.d[i] = shuf(s, C[ORB].ch.repeat(7) + C[ARROW].ch.repeat(3));
      draw(s, i, HAND);
    }
    return s;
  }
  const alive = (s, i) => s.hp[i] > 0;
  /* 내가 때릴 수 있는 상대들 (혼자 하기면 보스 = 1번 자리) */
  function opps(s, p) { const r = []; for (let i = 0; i < s.N; i++) if (i !== p && alive(s, i)) r.push(i); return r; }
  function actor(s) { return s.ph === 'p' ? s.cur : null; }

  function draw(s, p, n) {
    let got = 0, sh = 0;
    for (let k = 0; k < n; k++) {
      if (!s.d[p].length) {
        if (!s.c[p].length) break;
        s.d[p] = shuf(s, s.c[p]); s.c[p] = ''; sh++;
      }
      s.h[p] += s.d[p][0]; s.d[p] = s.d[p].slice(1); got++;
    }
    return [got, sh];
  }
  function hit(s, t, n, ev) {
    if (n <= 0 || !alive(s, t)) return;
    const ab = Math.min(s.sh[t], n);
    s.sh[t] -= ab; s.hp[t] = Math.max(0, s.hp[t] - (n - ab));
    ev.dm.push([t, n - ab, ab]);
  }
  /* 카드 효과 (연쇄 포함) */
  function effOf(id, chainOn) {
    const K = C[id], e = Object.assign({}, K.e);
    if (chainOn && K.k) for (const k in K.k) e[k] = (e[k] || 0) + K.k[k];
    return e;
  }
  function playCard(s, p, id, g, ev) {
    const K = C[id];
    const chainOn = K.s < 4 && !!(s.ch & (1 << K.s)) && !!K.k;
    if (K.s < 4) s.ch |= 1 << K.s;
    const e = effOf(id, chainOn);
    if (chainOn) ev.ch = 1;
    const os = opps(s, p);
    if (!os.includes(g)) g = os[0];
    if (e.m) s.mn += e.m;
    if (e.a && g != null) hit(s, g, e.a, ev);
    if (e.A) for (const o of os) hit(s, o, e.A, ev);
    if (e.s) s.sh[p] += e.s;
    if (e.h) { const before = s.hp[p]; s.hp[p] = Math.min(s.mx, s.hp[p] + e.h); ev.hl = (ev.hl || 0) + s.hp[p] - before; }
    if (e.t) { s.st[p] += e.t; ev.t = (ev.t || 0) + e.t; }
    if (e.d) { const [got, sh] = draw(s, p, e.d); ev.dr = (ev.dr || 0) + got; if (sh) ev.sh = 1; }
    if (e.T) s.tp = 1;
    if (K.b) ev.burn = 1; else s.pl += K.ch;
    if (e.x) s.pd = Math.min(e.x, s.h[p].length);
  }
  /* 끝났는지 확인 (넉아웃·보스) — 끝나면 true */
  function checkKO(s) {
    if (s.bo >= 0) {
      if (!alive(s, 1)) { s.ph = 'x'; s.w = [0]; s.why = 'b'; return true; }
      if (!alive(s, 0)) { s.ph = 'x'; s.w = []; s.why = 'L'; return true; }
      if (s.st[0] >= s.g) { s.ph = 'x'; s.w = [0]; s.why = 'B'; return true; }
      return false;
    }
    const al = []; for (let i = 0; i < s.n; i++) if (alive(s, i)) al.push(i);
    if (al.length <= 1) { s.ph = 'x'; s.w = al; s.why = 'k'; return true; }
    return false;
  }
  function finishStars(s, why) {
    const al = []; for (let i = 0; i < s.n; i++) if (alive(s, i)) al.push(i);
    const best = Math.max(...al.map((i) => s.st[i]));
    let w = al.filter((i) => s.st[i] === best);
    const hb = Math.max(...w.map((i) => s.hp[i]));
    w = w.filter((i) => s.hp[i] === hb);
    s.ph = 'x'; s.w = w; s.why = why;
  }
  /* 시장 흐름: 한 바퀴가 끝날 때마다 맨 왼쪽 카드가 공급 더미 맨 아래로 빠지고, 나머지가 왼쪽으로 한 칸씩, 새 카드가 오른쪽 끝에 */
  function flow(s, ev) {
    const out = s.mk[0];
    const nx = s.sp.length ? s.sp[0] : '_';
    s.sp = s.sp.slice(1) + (out !== '_' ? out : '');
    s.mk = s.mk.slice(1) + nx;
    ev.fl = [out === '_' ? -1 : cid(out), nx === '_' ? -1 : cid(nx)];
  }
  function bossAct(s, ev) {
    const I = bossIntent(s);
    s.sh[1] = 0;                               // 보스 방어막은 보스가 다시 움직일 때 사라져요
    const bv = { k: I.k, dm: [] };
    if (I.k === 's') s.sh[1] += I.s;
    if (I.a) { const e2 = { dm: [] }; hit(s, 0, I.a, e2); bv.dm = e2.dm; }
    if (I.k === 'v') { const b0 = s.hp[1]; s.hp[1] = Math.min(BOSS[s.bo].hp, s.hp[1] + I.h); bv.hl = s.hp[1] - b0; }
    if (I.k === 'c') { for (let q = 0; q < I.c; q++) s.c[0] += C[CURSE].ch; bv.c = I.c; }
    s.bi++;
    ev.bv = bv;
  }

  function apply(s, seat, a) {
    if (s.ph !== 'p' || seat !== s.cur) throw new Error('not your turn');
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const p = seat;
    const ev = { id: ++s.seq, k: a.t, p, dm: [] };
    if (s.pd > 0 && a.t !== 'x') throw new Error('choose a card to clear first');
    if (a.t === 'x') {
      if (!s.pd) throw new Error('nothing to clear');
      if (a.i === -1) { s.pd = 0; ev.c = -1; }
      else {
        const i = a.i | 0;
        if (i < 0 || i >= s.h[p].length) throw new Error('bad card');
        ev.c = cid(s.h[p][i]); ev.i = i;
        s.h[p] = s.h[p].slice(0, i) + s.h[p].slice(i + 1);
        s.pd = Math.min(s.pd - 1, s.h[p].length);
      }
    } else if (a.t === 'p') {
      const i = a.i | 0;
      if (i < 0 || i >= s.h[p].length) throw new Error('bad card');
      const id = cid(s.h[p][i]);
      if (id === CURSE) throw new Error('curse cannot be played');
      s.h[p] = s.h[p].slice(0, i) + s.h[p].slice(i + 1);
      ev.c = id; ev.i = i; ev.g = a.g;
      playCard(s, p, id, a.g, ev);
      const os = opps(s, p); if (!os.includes(ev.g)) ev.g = ev.dm.length ? ev.dm[0][0] : -1;
    } else if (a.t === 'pa') {
      let cs = '', idx = [], rest = '';
      for (let i = 0; i < s.h[p].length; i++) { const ch = s.h[p][i]; if (C[cid(ch)].pm) { cs += ch; idx.push(i); } else rest += ch; }
      if (!cs) throw new Error('no mana cards');
      s.h[p] = rest;
      for (const ch of cs) playCard(s, p, cid(ch), -1, ev);
      ev.cs = cs; ev.ix = idx;
    } else if (a.t === 'b') {
      const k = a.k | 0;
      let id;
      if (k >= 0 && k < NMK) { if (s.mk[k] === '_' || !s.mk[k]) throw new Error('empty slot'); id = cid(s.mk[k]); }
      else if (k === NMK || k === NMK + 1) id = FIX[k - NMK];
      else throw new Error('bad slot');
      if (C[id].c > s.mn) throw new Error('not enough mana');
      s.mn -= C[id].c;
      if (k < NMK) {
        const nx = s.sp.length ? s.sp[0] : '_';
        s.sp = s.sp.slice(1);
        s.mk = s.mk.slice(0, k) + nx + s.mk.slice(k + 1);
        ev.nw = nx === '_' ? -1 : cid(nx);
      }
      if (s.tp) { s.d[p] = C[id].ch + s.d[p]; s.tp = 0; ev.top = 1; } else s.c[p] += C[id].ch;
      ev.c = id; ev.m = k;
    } else if (a.t === 'e') {
      s.c[p] += s.pl + s.h[p]; s.h[p] = ''; s.pl = '';
      s.mn = 0; s.ch = 0; s.tp = 0; s.pd = 0;
      const [, sh] = draw(s, p, HAND); if (sh) ev.sh = 1;
      if (s.bo >= 0) {
        bossAct(s, ev);
        if (!checkKO(s)) {
          s.r++;
          flow(s, ev);
          if (s.r > RMAX) { s.ph = 'x'; s.w = []; s.why = 'T'; }
          else s.sh[0] = 0;
        }
      } else {
        let nx = p;
        do nx = (nx + 1) % s.n; while (!alive(s, nx));
        if (nx <= p) {
          s.r++;
          flow(s, ev);
          let top = 0; for (let i = 0; i < s.n; i++) if (alive(s, i)) top = Math.max(top, s.st[i]);
          if (top >= s.g) { finishStars(s, 's'); s.last = ev; return s; }
          if (s.r > RMAX) { finishStars(s, 'r'); s.last = ev; return s; }
        }
        ev.nx = nx;
        s.sh[nx] = 0; s.cur = nx;
      }
    } else throw new Error('unknown action');
    if (s.ph === 'p') checkKO(s);
    s.last = ev;
    return s;
  }

  function result(s) {
    if (s.ph !== 'x') return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    if (s.bo >= 0) {
      const B = BOSS[s.bo];
      if (s.why === 'b' || s.why === 'B') {
        const rr = s.r, star = rr <= B.T[0] ? 3 : rr <= B.T[1] ? 2 : 1;
        return { winners: [0], title: (s.why === 'b' ? B.n + ' 격파!' : B.n + ' 봉인!') + ' 별 ' + star + '개',
          text: '★'.repeat(star) + '☆'.repeat(3 - star) + '  ' + rr + '바퀴 만에 ' + (s.why === 'b' ? '쓰러뜨렸어요' : '별 ' + s.g + '개로 봉인했어요') + '\n남은 생명 ' + s.hp[0] + ' · 별 기준 ' + B.T[0] + '바퀴 ★★★ / ' + B.T[1] + '바퀴 ★★' };
      }
      return { winners: [], title: s.why === 'T' ? '시간이 다 됐어요' : '쓰러졌어요…', text: '☆☆☆  ' + B.n + ' 생명 ' + s.hp[1] + ' 남음 · 내 별 ' + s.st[0] + '/' + s.g + '\n다음엔 덱을 조금 더 키워 봐요!' };
    }
    const order = [];
    for (let i = 0; i < s.n; i++) order.push(i);
    order.sort((a, b) => (s.hp[b] > 0) - (s.hp[a] > 0) || (s.w.includes(b) - s.w.includes(a)) || s.st[b] - s.st[a] || s.hp[b] - s.hp[a] || a - b);
    const line = (i) => (s.w.includes(i) ? '👑 ' : '') + nm(i) + '  ★' + s.st[i] + ' · ' + (s.hp[i] > 0 ? '♥' + s.hp[i] : '쓰러짐') + ' · 카드 ' + (s.d[i].length + s.h[i].length + s.c[i].length) + '장';
    const why = s.why === 'k' ? '마지막까지 버틴 마법사!' : s.why === 's' ? '별 ' + s.g + '개에 먼저 닿은 바퀴 — 별이 가장 많아요' : RMAX + '바퀴가 끝나 별로 판정';
    const title = s.w.length === 1 ? nm(s.w[0]) + ' 승리!' : s.w.length ? '공동 승리' : '무승부';
    return { winners: s.w.slice(), title, text: why + '\n' + order.map(line).join('\n') };
  }

  /* ---------- AI ---------- */
  const R0 = Math.random;
  function cardsOf(s, p) { return s.d[p] + s.h[p] + s.c[p] + (s.cur === p ? s.pl : ''); }
  /* 덱 한 벌의 카드 한 장 평균 효과 (연쇄 확률 포함) */
  function profile(str, nOpp) {
    const n = Math.max(1, str.length), sc = [0, 0, 0, 0, 0, 0], P = { m: 0, a: 0, d: 0, s: 0, h: 0, t: 0, x: 0 };
    for (const ch of str) sc[C[cid(ch)].s]++;
    for (const ch of str) {
      const K = C[cid(ch)];
      const pc = chainP(K, sc, n);
      addE(P, K.e, 1, nOpp); if (K.k) addE(P, K.k, pc, nOpp);
    }
    for (const k in P) P[k] /= n;
    P.n = n; P.sc = sc;
    return P;
  }
  function chainP(K, sc, n) {
    if (K.s >= 4 || !K.k) return 0;
    const f = Math.max(0, sc[K.s] - 1) / Math.max(1, n - 1);
    return 0.55 * (1 - Math.pow(1 - f, 4));
  }
  function addE(P, e, w, nOpp) {
    for (const k in e) {
      if (k === 'A') P.a += e.A * w * Math.max(1, nOpp) * 0.85;
      else if (k === 'T') continue;
      else P[k] = (P[k] || 0) + e[k] * w;
    }
  }
  /* 한 차례에 기대되는 양 (뽑기 효과 포함) */
  function perTurn(P) { const cards = Math.min(P.n, HAND / Math.max(0.35, 1 - P.d)); return { m: P.m * cards, a: P.a * cards, s: P.s * cards, h: P.h * cards, t: P.t * cards, cards }; }

  /* 지금 상황에서 각 효과의 값어치 (lv3: 판세를 읽어 공격 ↔ 별 ↔ 덱 키우기 비중을 바꿈) */
  function weights(s, p, lv) {
    const os = opps(s, p), nOpp = os.length;
    if (lv < 3) return { m: 1, a: 1, d: 1, s: 0.45, h: 0.45, t: 2, x: s.r <= 6 ? 0.7 : 0, rest: 8, nOpp };
    const my = perTurn(profile(cardsOf(s, p), nOpp));
    let oppHP = 0; for (const o of os) oppHP += s.hp[o] + s.sh[o] * 0.5;
    const solo = s.bo >= 0;
    const TK = oppHP / Math.max(0.3, my.a);
    const TS = (s.g - s.st[p]) / Math.max(0.12, my.t);
    // 상대가 나를 얼마나 빨리 이길까
    let threat = 0, oppTS = 99;
    if (solo) { const I = bossIntent(s); threat = (I.a || 0) + 1 + rage(s) * 0.5; }
    else for (const o of os) {
      const q = perTurn(profile(cardsOf(s, o), Math.max(1, nOpp)));
      threat += (q.a) / Math.max(1, nOpp);
      oppTS = Math.min(oppTS, (s.g - s.st[o]) / Math.max(0.12, q.t));
    }
    const TD = (s.hp[p] + s.sh[p]) / Math.max(0.5, threat);
    const rest = Math.max(1, Math.min(14, Math.min(TK, TS, TD * 1.2, oppTS * 1.1)));
    const S = 30;
    let wa = S / Math.max(8, oppHP) * (nOpp > 1 ? 0.75 : 1), wt = S / Math.max(3, s.g - s.st[p] + 2) * (solo ? 0.9 : 1);
    // 공격과 별 중 더 빨리 끝낼 수 있는 쪽에 힘을 실어요 (처음 3바퀴는 덱을 키우는 데 집중)
    if (s.r > 3) { if (TK < TS * 0.85) { wa *= 1.25; wt *= 0.7; } else if (TS < TK * 0.85) { wt *= 1.25; wa *= 0.7; } }
    if (oppTS < TS && oppTS < TK) wa *= 1.25;      // 상대 별이 너무 빨라요 → 때려서 끊기
    const danger = U.clamp(4 / Math.max(1, TD), 0.15, 1.6);
    const wm = rest >= 7 ? 1.1 : rest >= 4 ? 0.75 : 0.3;
    return { m: my.m >= 10 ? wm * 0.5 : wm, a: wa, d: 0, s: danger * 0.7, h: danger * 0.75, t: wt, x: rest >= 6 ? 0.9 : rest >= 4 ? 0.4 : 0, rest, nOpp };
  }
  function cardVal(id, W, P) {
    const K = C[id];
    if (id === CURSE) return -2;
    const one = (e, w) => { let v = 0; for (const k in e) {
      if (k === 'A') v += e.A * W.a * Math.max(1, W.nOpp) * 0.85;
      else if (k === 'd') v += e.d * (P ? P.avg : 1);
      else if (k === 'T') v += 0.3;
      else v += (W[k] || 0) * e[k];
    } return v * w; };
    let v = one(K.e, 1);
    if (K.k) v += one(K.k, P ? chainP(K, P.sc, P.n + 1) : 0.3);
    return v;
  }
  function deckAvg(s, p, W) {
    const str = cardsOf(s, p), P = profile(str, W.nOpp);
    P.avg = 1;
    let t = 0; for (const ch of str) t += cardVal(cid(ch), W, P);
    P.avg = Math.max(0.3, t / Math.max(1, str.length));
    return P;
  }
  /* 사면 좋아지는 정도 (덱 평균보다 얼마나 좋은지 × 앞으로 몇 번 뽑힐지) */
  function gainOf(id, W, P) {
    const K = C[id], v = cardVal(id, W, P);
    if (K.b) return v * 0.45;
    const draws = Math.max(0.6, Math.min(4, W.rest * HAND / (P.n + 1)));
    return (v - P.avg) * draws;
  }
  function buyOptions(s) {
    const o = [];
    for (let k = 0; k < NMK; k++) if (s.mk[k] && s.mk[k] !== '_') o.push([k, cid(s.mk[k])]);
    o.push([NMK, FIX[0]], [NMK + 1, FIX[1]]);
    return o;
  }
  function pickBuy(s, p, lv) {
    const mana = s.mn, opts = buyOptions(s).filter(([, id]) => C[id].c <= mana);
    if (!opts.length) return null;
    if (lv === 1) {
      if (R0() < 0.25) return null;
      const mk = opts.filter(([k]) => k < NMK);
      const pool = mk.length && R0() < 0.85 ? mk : opts;
      // 비싼 걸 조금 더 좋아해요
      let t = 0; const ws = pool.map(([, id]) => { const w = 1 + C[id].c; t += w; return w; });
      let x = R0() * t; for (let i = 0; i < pool.length; i++) { x -= ws[i]; if (x < 0) return pool[i][0]; }
      return pool[0][0];
    }
    const W = weights(s, p, lv), P = deckAvg(s, p, W);
    if (lv === 2) {
      // 학파 하나를 조금 더 좋아해요 (가장 많이 가진 학파)
      let fav = -1, fb = 0; for (let k = 0; k < 4; k++) if (P.sc[k] > fb) { fb = P.sc[k]; fav = k; }
      let best = null, bv = 0.05;
      const pos = [];
      for (const [k, id] of opts) {
        const g = gainOf(id, W, P) * (C[id].s === fav ? 1.1 : 1);
        if (g > 0.05) pos.push([k, g]);
        if (g > bv) { bv = g; best = k; }
      }
      // 보통: 가끔은 최선 대신 그럭저럭 좋은 카드를 골라요
      if (pos.length > 1 && R0() < 0.3) return pos[Math.floor(R0() * pos.length)][0];
      return best;
    }
    // lv3: 남은 마나로 살 수 있는 묶음(최대 3장) 중 가장 좋은 걸 고르고 그 첫 장을 사요
    const all = buyOptions(s).map(([k, id]) => [k, id, gainOf(id, W, P)]).filter((x) => x[2] > 0.05);
    let best = null, bv = 0;
    const rec = (start, left, sum, first, used) => {
      if (sum > bv) { bv = sum; best = first; }
      if (used >= 3) return;
      for (let j = start; j < all.length; j++) {
        const [k, id, g] = all[j];
        if (C[id].c > left) continue;
        // 상설 더미는 여러 장 살 수 있어요(시장 칸은 한 번)
        rec(k >= NMK ? j : j + 1, left - C[id].c, sum + g * (used ? 0.9 : 1), first == null ? k : first, used + 1);
      }
    };
    rec(0, mana, 0, null, 0);
    return best;
  }
  function pickTarget(s, p, lv, dmg) {
    const os = opps(s, p);
    if (os.length <= 1) return os[0];
    if (lv === 1) return os[Math.floor(R0() * os.length)];
    const eff = (o) => s.hp[o] + s.sh[o];
    const kill = os.filter((o) => eff(o) <= dmg);
    if (kill.length) return kill.sort((a, b) => s.st[b] - s.st[a])[0];
    if (lv === 2) return os.slice().sort((a, b) => eff(a) - eff(b))[0];
    const thr = (o) => (s.st[o] / s.g) * 2 + (1 - eff(o) / s.mx) * 0.8;
    return os.slice().sort((a, b) => thr(b) - thr(a))[0];
  }
  function trashPick(s, p, lv) {
    const hand = s.h[p];
    if (!hand.length) return -1;
    const ids = hand.split('').map(cid);
    const ci = ids.indexOf(CURSE); if (ci >= 0) return ci;
    if (lv === 1) return R0() < 0.5 && ids.includes(ARROW) ? ids.indexOf(ARROW) : -1;
    const all = cardsOf(s, p), P = profile(all, opps(s, p).length);
    const manaTurn = perTurn(P).m;
    if (ids.includes(ARROW) && (lv === 2 ? s.r <= 10 : all.length > 9 || P.a * 5 > 3)) return ids.indexOf(ARROW);
    const orbs = all.split('').filter((ch) => cid(ch) === ORB).length;
    if (ids.includes(ORB) && orbs > 3 && manaTurn - P.m * 1 >= (lv === 3 ? 6 : 7) && s.r <= (lv === 3 ? 12 : 8)) return ids.indexOf(ORB);
    return -1;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const p = seat;
    if (s.pd > 0) return { t: 'x', i: trashPick(s, p, lv) };
    const hand = s.h[p].split('').map(cid);
    const playable = hand.map((id, i) => [id, i]).filter(([id]) => id !== CURSE);
    if (lv === 1) {
      const np = playable.filter(([id]) => !C[id].pm);
      if (np.length && R0() < 0.9) { const [id, i] = np[Math.floor(R0() * np.length)]; return { t: 'p', i, g: pickTarget(s, p, 1, C[id].e.a || 0) }; }
      if (playable.some(([id]) => C[id].pm)) return { t: 'pa' };
      if (np.length) return { t: 'p', i: np[0][1], g: pickTarget(s, p, 1, 0) };
      const b = pickBuy(s, p, 1);
      return b != null ? { t: 'b', k: b } : { t: 'e' };
    }
    // 낼 카드 고르기: 뽑기 → (정리할 게 있으면) 정리 → 학파별로 연쇄 덜 중요한 것부터 → 마나 카드 한꺼번에
    const np = playable.filter(([id]) => !C[id].pm);
    if (np.length) {
      const W = { m: 1, a: 1, d: 1, s: 0.5, h: 0.5, t: 1.7, x: 0.5, nOpp: opps(s, p).length };
      const score = ([id]) => {
        const K = C[id];
        let sc = 0;
        if (K.e.d) sc += 100 + K.e.d * 10;
        if (K.e.x) sc += trashPick(s, p, lv) >= 0 ? 60 : -60;
        const chainOn = K.s < 4 && (s.ch & (1 << K.s));
        // 연쇄가 안 켜진 학파는 연쇄 보너스가 작은 카드부터 깔기
        if (!chainOn && K.k) sc -= valK(K, W);
        if (chainOn && K.k) sc += valK(K, W);
        if (lv === 3 && K.e.h && s.hp[p] >= s.mx - 1) sc -= 30;
        return sc;
      };
      np.sort((x, y) => score(y) - score(x));
      const [id, i] = np[0];
      const K = C[id];
      // lv3: 정리 카드를 낼 때 버릴 게 없고 다른 카드가 남았으면 나중에
      if (K.e.x && !K.e.a && np.length > 1 && trashPick(s, p, lv) < 0) { const alt = np[1]; return { t: 'p', i: alt[1], g: pickTarget(s, p, lv, dmgOf(alt[0], s)) }; }
      return { t: 'p', i, g: pickTarget(s, p, lv, dmgOf(id, s)) };
    }
    if (playable.some(([id]) => C[id].pm)) return { t: 'pa' };
    const b = pickBuy(s, p, lv);
    if (b != null) return { t: 'b', k: b };
    return { t: 'e' };
  }
  function valK(K, W) { let v = 0; for (const k in K.k) v += (k === 'A' ? 1.5 : (W[k] || 1)) * K.k[k]; return v; }
  function dmgOf(id, s) { const K = C[id]; const on = K.s < 4 && (s.ch & (1 << K.s)); return (K.e.a || 0) + (on && K.k ? K.k.a || 0 : 0); }
  function aiDelayFor(s, seat, lv) {
    if (s.ph !== 'p') return -1;
    const base = lv === 1 ? 1.15 : lv === 3 ? 0.85 : 1;
    const a = s.last && s.last.p === seat ? s.last.k : 'e';
    if (s.pd > 0) return 650 * base;
    if (a === 'e' || s.last == null) return 900 * base;          // 차례 시작 — 손을 볼 시간
    if (a === 'b') return 700 * base;
    return 520 * base;
  }

  /* ---------- text helpers ---------- */
  const TOK = { m: ['◆', 'mn'], a: ['⚔', 'at'], A: ['💥', 'at'], d: ['🃏+', 'dr'], s: ['🛡', 'sh'], h: ['♥+', 'hl'], t: ['★', 'st'], x: ['🗑', 'tr'], T: ['⤒', 'tp'] };
  function toks(e) { const r = []; for (const k of KEYS) if (e[k]) r.push([k === 'T' ? TOK.T[0] : TOK[k][0] + e[k], TOK[k][1]]); return r; }
  const DESC = {
    m: (v) => '마나 +' + v, a: (v) => '상대 하나에게 피해 ' + v, A: (v) => '모든 상대에게 피해 ' + v, d: (v) => '카드 ' + v + '장 더 뽑기',
    s: (v) => '방어막 +' + v, h: (v) => '내 생명 +' + v, t: (v) => '별 ★ +' + v, x: (v) => '손의 카드 ' + v + '장 정리(없애기) 가능', T: () => '이번 차례에 다음으로 사는 카드는 덱 맨 위로',
  };
  function ctoks(e) { return KEYS.filter((k) => e[k]).map((k) => TOK[k][0].replace('+', '') + '+' + e[k]).join(' '); }
  function descOf(e) { const r = []; for (const k of KEYS) if (e[k]) r.push(DESC[k](e[k])); return r.join(' · '); }

  /* ---------- view ---------- */
  const CSS = `
.dd{position:absolute;inset:0;display:flex;flex-direction:column;gap:6px;padding:6px 8px 8px;overflow:hidden;
  background:radial-gradient(120% 70% at 50% 45%,#2b2140 0%,#1a1424 60%,#120e19 100%);color:var(--ink);user-select:none;-webkit-user-select:none}
.dd *{box-sizing:border-box}
.dd-opps{display:grid;gap:6px;flex:none}
.dd-op{position:relative;min-height:54px;border-radius:12px;background:linear-gradient(180deg,#2a2238,#221c2e);border:1px solid rgba(255,255,255,.08);
  padding:5px 8px 6px;display:flex;flex-direction:column;gap:2px;min-width:0;cursor:pointer;transition:box-shadow .2s,transform .15s}
.dd-op.cur{box-shadow:0 0 0 2px var(--c),0 0 14px -2px var(--c)}
.dd-op.tg::after{content:'🎯';position:absolute;right:5px;top:3px;font-size:13px}
.dd-op.out{opacity:.38;filter:grayscale(.8)}
.dd-op .r1{display:flex;align-items:center;gap:5px;min-width:0;font-weight:700;font-size:13px;line-height:1.2}
.dd-op .r1 .nm{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dd-op .r2{display:flex;gap:7px;align-items:baseline;font-family:var(--f-mono);font-size:12.5px;white-space:nowrap;overflow:hidden}
.dd-op .r3{font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dd-hpb{height:4px;border-radius:3px;background:rgba(255,255,255,.1);overflow:hidden}
.dd-hpb i{display:block;height:100%;background:linear-gradient(90deg,#ee6a55,#ff9b6a);border-radius:3px;transition:width .35s}
.dd .hp{color:#ff8f7a}.dd .shd{color:#8fd0ff}.dd .stv{color:#ffd34a}
.dd-boss{flex-direction:row;align-items:center;gap:8px;min-height:62px}
.dd-boss .bic{font-size:30px;line-height:1;flex:none;filter:drop-shadow(0 2px 4px rgba(0,0,0,.6))}
.dd-boss .bmid{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.dd-boss .intent{flex:none;max-width:44%;text-align:center;border-radius:10px;padding:4px 7px;background:rgba(238,106,85,.16);border:1px solid rgba(238,106,85,.45);font-size:11.5px;line-height:1.25}
.dd-boss .intent b{display:block;font-family:var(--f-mono);font-size:14px;color:#ffb3a3}
.dd-mkt{display:grid;grid-template-columns:repeat(5,var(--mw));justify-content:space-between;flex:none}
.dd-fix{display:flex;gap:6px;flex:none;align-items:stretch}
.dd-fix .fx{flex:1;min-width:0;min-height:44px;border-radius:11px;border:1px dashed rgba(227,174,69,.45);background:rgba(227,174,69,.06);
  display:flex;align-items:center;gap:6px;padding:3px 8px;cursor:pointer;color:var(--ink);font:inherit;font-size:12.5px;text-align:left}
.dd-fix .fx.can{border-style:solid;background:rgba(227,174,69,.14);box-shadow:0 0 10px -4px var(--brass)}
.dd-fix .fx .cst{flex:none}
.dd-fix .fx span.t{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.2}
.dd-fix .fx span.t small{display:block;color:var(--muted);font-size:10.5px}
.dd-fix .sup{flex:none;width:46px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:10px;color:var(--muted);line-height:1.15;text-align:center}
.dd-fix .sup b{font-family:var(--f-mono);font-size:14px;color:var(--ink)}
.dd-table{position:relative;flex:1 1 auto;min-height:74px;border-radius:16px;border:2px solid #5a4422;
  background:radial-gradient(90% 90% at 50% 40%,#1f6a52 0%,#145040 60%,#0e3a2f 100%);box-shadow:inset 0 0 22px rgba(0,0,0,.55),0 2px 0 #2c1f0e;
  display:flex;flex-direction:column;padding:6px 8px;gap:4px;overflow:hidden}
.dd-table .th{display:flex;align-items:center;gap:8px;font-size:12px;color:#d9f0e4;min-height:20px}
.dd-table .th .who{font-weight:700;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dd-table .th .rd{margin-left:auto;font-family:var(--f-mono);opacity:.8;white-space:nowrap}
.dd-mana{position:absolute;right:10px;bottom:8px;width:58px;height:58px;display:flex;align-items:center;justify-content:center;flex-direction:column;z-index:2}
.dd-mana::before{content:'';position:absolute;inset:6px;transform:rotate(45deg);border-radius:8px;background:linear-gradient(135deg,#ffe08a,#e3ae45 55%,#9a6a14);box-shadow:0 3px 8px rgba(0,0,0,.5),inset 0 0 0 2px rgba(255,255,255,.25)}
.dd-mana b{position:relative;font-family:var(--f-mono);font-size:22px;color:#2a1e05;line-height:1}
.dd-mana small{position:relative;font-size:9px;color:#2a1e05;font-weight:700;margin-top:-1px}
.dd-mana.zero::before{filter:grayscale(.7) brightness(.6)}
.dd-played{position:relative;flex:1;min-height:0;display:flex;align-items:center;padding-right:64px}
.dd-played .dc{flex:none;margin-right:calc(var(--pov) * -1);box-shadow:-3px 2px 6px rgba(0,0,0,.45)}
.dd-played .empty{font-size:12px;color:rgba(217,240,228,.55);padding-left:4px}
.dd-hint{font-size:12px;color:#e9f6ee;min-height:17px;line-height:1.35;padding-right:64px;text-shadow:0 1px 2px rgba(0,0,0,.6)}
.dd-hint b{color:#ffe08a}
.dd-me{display:flex;align-items:center;gap:6px;flex:none;min-height:46px;border-radius:12px;background:linear-gradient(180deg,#2a2238,#221c2e);border:1px solid rgba(255,255,255,.08);padding:3px 4px 3px 8px}
.dd-me .info{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.dd-me .r0{display:flex;align-items:center;gap:5px;font-weight:700;font-size:12px;line-height:1.15;min-width:0}
.dd-me .r0 .nm{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dd-me .r1{display:flex;align-items:baseline;gap:8px;font-family:var(--f-mono);font-size:13.5px;white-space:nowrap;overflow:hidden;line-height:1.2}
.dd-me.cur{box-shadow:0 0 0 2px var(--c)}
.dd-piles{display:flex;gap:4px;flex:none}
.dd-pile{width:50px;min-height:44px;border-radius:10px;border:1px solid rgba(255,255,255,.14);background:#1b1625;color:var(--ink);cursor:pointer;
  display:flex;flex-direction:column;align-items:center;justify-content:center;font:inherit;font-size:10px;line-height:1.1;padding:2px;position:relative}
.dd-pile b{font-family:var(--f-mono);font-size:15px}
.dd-pile.deck{background:repeating-linear-gradient(45deg,#3a2a5a 0 6px,#33244f 6px 12px);border-color:#7a62a8}
.dd-hand{position:relative;flex:none;height:calc(var(--hh) + 10px)}
.dd-hand .dc{position:absolute;bottom:2px;transform-origin:50% 120%;transition:transform .16s ease,left .2s ease,filter .2s;cursor:pointer;box-shadow:0 4px 10px rgba(0,0,0,.55)}
.dd-hand .dc.can:hover{transform:translateY(-8px) rotate(var(--rot))!important}
.dd-hand.off .dc{filter:brightness(.78) saturate(.8);cursor:default}
.dd-hand .dc.sel{transform:translateY(-14px) rotate(0deg)!important;box-shadow:0 0 0 3px #ff7a5c,0 8px 16px rgba(0,0,0,.6);z-index:30}
.dd-hand .dc.kc{outline:3px solid var(--brass);outline-offset:2px}
.dd-hand.trash .dc{box-shadow:0 0 0 2px rgba(255,122,92,.75),0 4px 10px rgba(0,0,0,.55)}
.dd-hand .back{position:absolute;bottom:2px;border-radius:9px;background:repeating-linear-gradient(45deg,#3a2a5a 0 6px,#33244f 6px 12px);border:2px solid #7a62a8;box-shadow:0 4px 10px rgba(0,0,0,.5)}
.dd-hand .none{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:13px;text-align:center}
.dd-bar{display:flex;gap:6px;flex:none}
.dd-bar .btn{min-height:46px;padding:6px 10px;font-size:14px;flex:1;min-width:0;white-space:nowrap}
.dd-bar .btn.rd{flex:none;width:48px;padding:0;font-size:17px}
.dd-bar .btn.rd.on{background:var(--brass);color:var(--brass-ink)}
.dd-bar .btn.end{flex:1.25}
.dd-bar .btn.warn{background:var(--coral);color:#2b0c06}
/* card face */
.dc{--sc:#c7b6e6;--sd:#2a2338;width:var(--w,64px);height:var(--h,86px);border-radius:9px;position:relative;overflow:hidden;flex:none;
  background:linear-gradient(165deg,var(--sd) 0%,#17121f 88%);border:2px solid var(--sc);color:#f6efe2;display:flex;flex-direction:column;align-items:center;
  font-size:var(--fs,11px);line-height:1.15;padding:calc(var(--fs,11px)*.3) 3px 3px;text-align:center}
.dc::before{content:'';position:absolute;inset:2px;border-radius:6px;border:1px solid rgba(255,255,255,.12);pointer-events:none}
.dc .top{display:flex;width:100%;justify-content:space-between;align-items:center;height:calc(var(--fs,11px)*1.55)}
.dc .cst,.dd .cst{display:inline-flex;align-items:center;justify-content:center;min-width:calc(var(--fs,11px)*1.55);height:calc(var(--fs,11px)*1.55);border-radius:50%;
  background:radial-gradient(circle at 35% 30%,#ffe9a8,#e3ae45 60%,#946414);color:#2a1e05;font-family:var(--f-mono);font-weight:700;font-size:calc(var(--fs,11px)*1.02);box-shadow:0 1px 2px rgba(0,0,0,.5)}
.dc .ic{font-size:calc(var(--fs,11px)*1.05)}
.dc .nm{font-weight:700;margin-top:1px;min-height:2.3em;display:flex;align-items:center;justify-content:center;word-break:keep-all;letter-spacing:-.02em;color:var(--lt,#fff)}
.dc .ef{display:flex;flex-wrap:wrap;justify-content:center;gap:1px 4px;font-family:var(--f-mono);font-weight:700;font-size:calc(var(--fs,11px)*1.12);margin-top:auto}
.dc .ch{font-size:calc(var(--fs,11px)*.86);margin-top:2px;padding:1px 3px;border-radius:5px;background:rgba(255,255,255,.07);color:#cbbfda;white-space:nowrap;font-family:var(--f-mono)}
.dc .ch.on{background:rgba(255,211,74,.25);color:#ffe79a;box-shadow:0 0 6px rgba(255,211,74,.5)}
.dc .bn{font-size:calc(var(--fs,11px)*.82);margin-top:2px;background:#ee6a55;color:#2b0c06;border-radius:5px;padding:0 4px;font-weight:700;white-space:nowrap}
.dc.curse{background:linear-gradient(165deg,#2a2030,#120e18);filter:saturate(.6)}
.dc.mini .nm{min-height:0}
.tk.mn{color:#ffd770}.tk.at{color:#ff8f72}.tk.dr{color:#f2e9d8}.tk.sh{color:#8fd0ff}.tk.hl{color:#7dffb0}.tk.st{color:#ffd34a}.tk.tr{color:#ff9e9e}.tk.tp{color:#c8b6ff}
.dd-mkt .dc{cursor:pointer;transition:transform .15s,box-shadow .2s,opacity .2s}
.dd-mkt .dc.can{box-shadow:0 0 0 2px var(--brass),0 0 12px -2px var(--brass)}
.dd-mkt .dc.no{opacity:.78}
.dd-mkt .slot{width:var(--mw);height:var(--mh);border-radius:9px;border:2px dashed rgba(255,255,255,.12)}
.dd-mkt .dc.new{animation:ddFlip .45s ease-out}
@keyframes ddFlip{0%{transform:rotateY(90deg) scale(.9)}100%{transform:none}}
@keyframes ddDeal{0%{transform:translateY(34px) rotate(6deg);opacity:0}100%{opacity:1}}
.dd-hand .dc.deal{animation:ddDeal .32s ease-out backwards}
.dd-fxl{position:absolute;inset:0;pointer-events:none;z-index:12;overflow:hidden}
.dd-fly{position:absolute;left:0;top:0;transform-origin:0 0;will-change:transform,opacity;z-index:2}
.dd-pop{position:absolute;font-family:var(--f-mono);font-weight:700;font-size:20px;transform:translate(-50%,-50%);text-shadow:0 2px 4px rgba(0,0,0,.8);white-space:nowrap;animation:ddPop .9s ease-out forwards}
@keyframes ddPop{0%{opacity:0;transform:translate(-50%,-30%) scale(.6)}15%{opacity:1;transform:translate(-50%,-60%) scale(1.15)}100%{opacity:0;transform:translate(-50%,-160%) scale(1)}}
.dd-bolt{position:absolute;width:18px;height:18px;margin:-9px 0 0 -9px;border-radius:50%;background:radial-gradient(circle,#fff 0%,var(--c) 45%,transparent 72%);box-shadow:0 0 16px 6px var(--c)}
.dd-shake{animation:ddShake .35s}
@keyframes ddShake{0%,100%{transform:none}20%{transform:translateX(-5px)}40%{transform:translateX(5px)}60%{transform:translateX(-3px)}80%{transform:translateX(2px)}}
.dd-glow{animation:ddGlow .6s}
@keyframes ddGlow{0%{box-shadow:0 0 0 0 rgba(255,211,74,.9)}100%{box-shadow:0 0 0 14px rgba(255,211,74,0)}}
.dd-shuf{position:absolute;width:30px;height:40px;border-radius:5px;background:repeating-linear-gradient(45deg,#3a2a5a 0 5px,#33244f 5px 10px);border:1.5px solid #9a82c8}
.dd-read{position:absolute;inset:0;z-index:16;background:rgba(10,8,15,.74);display:flex;align-items:center;justify-content:center;padding:14px;animation:fade .15s}
.dd-read .box{width:min(330px,100%);max-height:100%;overflow-y:auto;background:var(--surface);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:14px;display:flex;flex-direction:column;gap:10px}
.dd-read .row1{display:flex;gap:12px;align-items:flex-start}
.dd-read .txt{flex:1;min-width:0;display:flex;flex-direction:column;gap:5px;font-size:13.5px;line-height:1.45}
.dd-read .txt h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:22px;line-height:1.1}
.dd-read .txt .sch{font-size:12px;color:var(--muted)}
.dd-read .txt .chn{background:rgba(255,211,74,.1);border-radius:8px;padding:5px 7px;font-size:12.5px}
.dd-read .btns{display:flex;gap:8px}
.dd-read .btns .btn{flex:1}
.dd-read .grid{display:flex;flex-wrap:wrap;gap:8px 6px}
.dd-read .gi{position:relative;cursor:pointer}
.dd-read .gi .x{position:absolute;right:-4px;top:-6px;background:var(--brass);color:#2a1e05;font-family:var(--f-mono);font-weight:700;font-size:11px;border-radius:9px;padding:1px 5px;z-index:2}
.dd-read h4{margin:4px 0 0;font-size:13px;color:var(--brass)}
.dd-read .muted{font-size:12px}
`;

  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'dd' });
    const oppsEl = h('div', { class: 'dd-opps' });
    const mktEl = h('div', { class: 'dd-mkt' });
    const fixEl = h('div', { class: 'dd-fix' });
    const tableEl = h('div', { class: 'dd-table' });
    const meEl = h('div', { class: 'dd-me' });
    const handEl = h('div', { class: 'dd-hand' });
    const barEl = h('div', { class: 'dd-bar' });
    const fxl = h('div', { class: 'dd-fxl' });
    wrap.append(oppsEl, mktEl, fixEl, tableEl, meEl, handEl, barEl, fxl);
    root.append(style, wrap);

    let st = null, dead = false, busy = false, readMode = false, reader = null, sel = -1, endWarn = 0, kc = -1;
    let tgt = -1, me = 0, dealN = 0, newSlot = -1, lastHuman = -1, logLine = '', animId = 0;
    const sent = { key: '' };
    const timers = new Set();
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms / sp()); timers.add(t); return t; };
    const nm = (i) => (st && st.bo >= 0 && i === 1 ? BOSS[st.bo].n : api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (st && st.bo >= 0 && i === 1 ? '#ee6a55' : api.players[i] ? api.players[i].color : '#e3ae45');
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }

    /* ----- sizes ----- */
    let W = 360, H = 588;
    function fit() {
      const r = root.getBoundingClientRect();
      W = Math.max(280, r.width); H = Math.max(400, r.height);
      const mw = Math.min(86, Math.floor((W - 16 - 4 * 5) / 5));
      let mh = Math.round(mw * 1.34);
      let hw = Math.min(88, Math.floor((W - 16) / 5) - 4), hh = Math.round(hw * 1.42);
      if (H < 560) { mh = Math.min(mh, 80); hh = Math.min(hh, 86); }
      if (H > 700) { hh = Math.min(Math.round(hw * 1.5), hh + 12); }
      wrap.style.setProperty('--mw', mw + 'px'); wrap.style.setProperty('--mh', mh + 'px');
      wrap.style.setProperty('--hw', hw + 'px'); wrap.style.setProperty('--hh', hh + 'px');
      wrap.dataset.mw = mw; wrap.dataset.mh = mh; wrap.dataset.hw = hw; wrap.dataset.hh = hh;
      if (st) render();
    }
    const ro = new ResizeObserver(() => fit());

    /* ----- seats ----- */
    function meSeat() {
      if (!st) return 0;
      if (st.bo >= 0) return 0;
      const mine = api.mySeats();
      if (api.online) return mine.length ? mine[0] : st.cur;
      if (!mine.length) return st.cur;
      if (mine.length === 1) return mine[0];
      const v = api.viewer();
      if (v >= 0) { lastHuman = v; return v; }
      if (mine.includes(st.cur)) return st.cur;
      return lastHuman >= 0 ? lastHuman : mine[0];
    }
    const handShown = (p) => api.mySeats().length === 0 || api.viewer() === p;
    const myTurn = () => st && st.ph === 'p' && st.cur === me && api.canAct(me) && handShown(me);
    const canDo = () => myTurn() && sent.key !== keyOf(st);
    const keyOf = (s) => s.seq + ':' + s.cur;

    function act(a) {
      if (!canDo()) return;
      sent.key = keyOf(st);
      sel = -1; endWarn = 0;
      api.act(a);
      // 거절되면 다시 누를 수 있게
      later(() => { if (st && sent.key === keyOf(st)) { sent.key = ''; render(); } }, 900 * sp());
    }

    /* ----- card face ----- */
    function face(id, w, hgt, extra) {
      const K = C[id], S = SCH[K.s];
      const fs = Math.max(8.5, Math.min(13, w / 64 * 10.6));
      const chainOn = extra && extra.chainOn;
      const el = h('div', { class: 'dc' + (K.s === 5 ? ' curse' : '') + (extra && extra.cls ? ' ' + extra.cls : ''), style: { '--sc': S.col, '--sd': S.dk, '--lt': S.lt, '--w': w + 'px', '--h': hgt + 'px', '--fs': fs + 'px' } },
        h('div', { class: 'top' }, K.c > 0 || K.s < 4 ? h('span', { class: 'cst', text: K.c }) : h('span'), h('span', { class: 'ic', text: S.ic })),
        h('div', { class: 'nm', text: K.n }),
        h('div', { class: 'ef' }, K.s === 5 ? h('span', { class: 'tk', text: '쓸모없음', style: { fontSize: '.8em', color: '#b8a8c8' } }) : toks(K.e).map(([t, c]) => h('span', { class: 'tk ' + c, text: t }))),
        K.k && hgt >= 70 ? h('div', { class: 'ch' + (chainOn ? ' on' : ''), text: '🔗' + ctoks(K.k) }) : null,
        K.b && hgt >= 70 ? h('div', { class: 'bn', text: '1회용' }) : null);
      el.dataset.id = id;
      return el;
    }

    /* ----- render ----- */
    function render() {
      if (!st || dead) return;
      me = meSeat();
      const s = st;
      const mw = +wrap.dataset.mw, mh = +wrap.dataset.mh, hw = +wrap.dataset.hw, hh = +wrap.dataset.hh;
      const mine = myTurn();
      const os = []; for (let k = 1; k < s.N; k++) os.push((me + k) % s.N);
      const liveOpps = opps(s, me);
      if (!liveOpps.includes(tgt)) tgt = liveOpps.length ? (liveOpps.includes((me + 1) % s.N) ? (me + 1) % s.N : liveOpps[0]) : -1;

      /* opponents / boss */
      oppsEl.innerHTML = '';
      oppsEl.style.gridTemplateColumns = 'repeat(' + os.length + ',minmax(0,1fr))';
      for (const i of os) {
        if (s.bo >= 0 && i === 1) { oppsEl.append(bossPanel(s)); continue; }
        const isT = liveOpps.length > 1 && i === tgt && mine;
        const el = h('div', { class: 'dd-op' + (s.cur === i && s.ph === 'p' ? ' cur' : '') + (isT ? ' tg' : '') + (alive(s, i) ? '' : ' out'), style: { '--c': col(i) }, 'data-seat': i, onclick: () => tapOpp(i) },
          h('div', { class: 'r1' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { class: 'nm', text: nm(i) })),
          h('div', { class: 'r2' }, h('span', { class: 'hp', text: '♥' + s.hp[i] }), s.sh[i] ? h('span', { class: 'shd', text: '🛡' + s.sh[i] }) : null, h('span', { class: 'stv', text: '★' + s.st[i] + (os.length <= 2 ? '/' + s.g : '') })),
          h('div', { class: 'dd-hpb' }, h('i', { style: { width: (100 * s.hp[i] / s.mx) + '%' } })),
          os.length <= 2 ? h('div', { class: 'r3', text: alive(s, i) ? '손 ' + s.h[i].length + ' · 카드 ' + (s.d[i].length + s.h[i].length + s.c[i].length + (s.cur === i ? s.pl.length : 0)) + '장' : '쓰러졌어요' }) : (!alive(s, i) ? h('div', { class: 'r3', text: '쓰러짐' }) : null));
        oppsEl.append(el);
      }

      /* market */
      mktEl.innerHTML = '';
      for (let k = 0; k < NMK; k++) {
        const ch = s.mk[k];
        if (!ch || ch === '_') { mktEl.append(h('div', { class: 'slot', 'data-slot': k })); continue; }
        const id = cid(ch);
        const can = mine && !s.pd && C[id].c <= s.mn;
        const el = face(id, mw, mh, { cls: (can ? 'can' : mine && !s.pd ? 'no' : '') + (k === newSlot ? ' new' : '') });
        el.dataset.slot = k;
        bindCard(el, () => openReader({ id, slot: k }), () => openReader({ id, slot: k }));
        mktEl.append(el);
      }
      newSlot = -1;
      fixEl.innerHTML = '';
      FIX.forEach((id, j) => {
        const K = C[id], can = mine && !s.pd && K.c <= s.mn;
        const b = h('button', { class: 'fx' + (can ? ' can' : ''), 'data-slot': NMK + j, onclick: () => openReader({ id, slot: NMK + j }) },
          h('span', { class: 'cst', text: K.c, style: { '--fs': '12px' } }),
          h('span', { class: 't' }, K.n, h('small', { text: toks(K.e).map((x) => x[0]).join(' ') + ' · 늘 있음' })));
        fixEl.append(b);
      });
      fixEl.append(h('div', { class: 'sup' }, h('b', { text: s.sp.length }), '남은 카드'));

      /* table */
      tableEl.innerHTML = '';
      const cur = s.cur;
      const th = h('div', { class: 'th' }, h('span', { class: 'dot', style: { '--c': col(cur) } }),
        h('span', { class: 'who', text: s.ph !== 'p' ? '게임 끝' : cur === me && api.canAct(me) ? '내 차례' : nm(cur) + ' 차례' }),
        h('span', { class: 'rd', text: s.r + '바퀴 · ★' + s.g + (s.bo >= 0 ? ' 봉인' : ' 승리') }));
      const played = h('div', { class: 'dd-played' });
      const pw = Math.max(40, Math.min(mw, Math.round((tableEl.clientHeight || 120) * 0.42 / 1.34 * 1.34)));
      const ph = Math.round(pw * 1.34);
      if (s.pl.length) {
        const n = s.pl.length, avail = W - 16 - 20 - 64 - pw;
        const ov = n > 1 ? Math.max(0, pw - avail / (n - 1)) : 0;
        played.style.setProperty('--pov', Math.min(pw * 0.72, ov) + 'px');
        for (let k = 0; k < n; k++) { const el = face(cid(s.pl[k]), pw, ph, { cls: 'mini' }); el.dataset.pi = k; bindCard(el, () => openReader({ id: cid(s.pl[k]) }), () => openReader({ id: cid(s.pl[k]) })); played.append(el); }
      } else played.append(h('div', { class: 'empty', text: s.ph === 'p' ? '이번 차례에 낸 카드가 여기 놓여요' : '' }));
      const mana = h('div', { class: 'dd-mana' + (s.mn ? '' : ' zero') }, h('b', { text: s.mn }), h('small', { text: '마나' }));
      tableEl.append(th, played, h('div', { class: 'dd-hint', html: hintHTML(s, mine) }), mana);

      /* me */
      meEl.innerHTML = '';
      meEl.className = 'dd-me' + (s.cur === me && s.ph === 'p' ? ' cur' : '');
      meEl.style.setProperty('--c', col(me));
      const total = s.d[me].length + s.h[me].length + s.c[me].length + (s.cur === me ? s.pl.length : 0);
      meEl.append(h('div', { class: 'info' },
        h('div', { class: 'r0' }, h('span', { class: 'dot', style: { '--c': col(me) } }), h('span', { class: 'nm', text: nm(me) + (s.bo >= 0 ? ' · 봉인 ★' + s.g : '') })),
        h('div', { class: 'r1' }, h('span', { class: 'hp', text: '♥' + s.hp[me] + '/' + s.mx }), h('span', { class: 'shd', text: '🛡' + s.sh[me] }), h('span', { class: 'stv', text: '★' + s.st[me] + '/' + s.g })),
        h('div', { class: 'dd-hpb' }, h('i', { style: { width: (100 * s.hp[me] / s.mx) + '%' } }))),
        h('div', { class: 'dd-piles' },
          h('button', { class: 'dd-pile deck', 'aria-label': '내 덱 보기', onclick: () => openDeck(me) }, h('b', { text: s.d[me].length }), '덱'),
          h('button', { class: 'dd-pile disc', 'aria-label': '버린 더미 보기', onclick: () => openDeck(me) }, h('b', { text: s.c[me].length }), '버림'),
          h('button', { class: 'dd-pile all', 'aria-label': '내 카드 전체', onclick: () => openDeck(me), style: { width: '44px' } }, h('b', { text: total }), '전체')));

      /* hand */
      renderHand(s, mine, hw, hh);

      /* bar */
      barEl.innerHTML = '';
      const rdBtn = h('button', { class: 'btn rd' + (readMode ? ' on' : ''), 'aria-label': '카드 읽기 모드', text: 'ⓘ', onclick() { readMode = !readMode; api.sfx('click'); if (readMode) api.toast('카드를 누르면 설명을 읽어요'); render(); } });
      if (mine && s.pd > 0) {
        barEl.append(rdBtn,
          h('button', { class: 'btn danger', text: sel >= 0 ? '🗑 이 카드 정리' : '🗑 카드를 고르세요', disabled: sel < 0 || !canDo(), onclick() { if (sel >= 0) act({ t: 'x', i: sel }); } }),
          h('button', { class: 'btn', text: '안 할래요', disabled: !canDo(), onclick() { act({ t: 'x', i: -1 }); } }));
        return;
      }
      const hand = s.h[me] || '';
      const nMana = handShown(me) ? hand.split('').filter((ch) => C[cid(ch)].pm).length : 0;
      const endB = h('button', { class: 'btn primary end' + (endWarn ? ' warn' : ''), text: endWarn ? '그래도 끝내기' : '턴 끝 ▶', disabled: !mine || !canDo(), onclick: tryEnd });
      barEl.append(rdBtn,
        h('button', { class: 'btn', text: '◆ 마나 모두' + (nMana ? ' (' + nMana + ')' : ''), disabled: !mine || !nMana || !canDo(), onclick() { act({ t: 'pa' }); } }),
        endB);
    }

    const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    function logOf(ev, s) {
      const who = esc(nm(ev.p)) + ': ';
      if (ev.k === 'p') return who + '<b>' + C[ev.c].n + '</b>' + (ev.ch ? ' 🔗' : '') + ev.dm.map(([t, n, ab]) => ' → ' + esc(nm(t)) + ' ' + (n ? '−' + n : '') + (ab ? ' 🛡' + ab : '')).join('') + (ev.t ? ' ★+' + ev.t : '');
      if (ev.k === 'pa') return who + '마나 카드 ' + ev.cs.length + '장';
      if (ev.k === 'b') return who + '<b>' + C[ev.c].n + '</b>을(를) 샀어요' + (ev.top ? ' (덱 위로)' : '');
      if (ev.k === 'x') return ev.c >= 0 ? who + '<b>' + C[ev.c].n + '</b> 정리' : '';
      return '';
    }
    function hintHTML(s, mine) {
      if (s.ph !== 'p') return '';
      if (!mine) {
        if (s.cur !== me || !api.canAct(s.cur)) {
          const p = api.players[s.cur];
          if (s.bo >= 0) return '';
          if (logLine && s.cur !== me) return (p && p.ai ? '🤖 ' : '') + logLine;
          return p && p.ai ? '🤖 ' + esc(nm(s.cur)) + '이(가) 카드를 고르고 있어요…' : esc(nm(s.cur)) + '의 차례를 기다려요';
        }
        return '';
      }
      if (s.pd > 0) return '🗑 <b>정리</b>: 없앨 카드를 골라요 (' + s.pd + '장까지, 안 해도 돼요)';
      const hand = s.h[me];
      const left = hand.split('').filter((ch) => cid(ch) !== CURSE).length;
      if (left) return '카드를 눌러 내요' + (readMode ? ' (지금은 <b>읽기 모드</b>)' : '') + (opps(s, me).length > 1 ? ' · 🎯 위에서 공격할 상대를 골라요' : '') + ' · 꾹 누르면 설명';
      const can = buyOptions(s).some(([, id]) => C[id].c <= s.mn);
      if (can) return '<b>◆' + s.mn + '</b>로 시장 카드를 살 수 있어요. 카드를 눌러 사요!';
      return '다 했으면 <b>턴 끝</b>! 새로 5장을 뽑아요.';
    }

    function renderHand(s, mine, hw, hh) {
      handEl.innerHTML = '';
      const show = handShown(me);
      const hand = s.h[me] || '';
      const n = hand.length;
      handEl.className = 'dd-hand' + (mine ? '' : ' off') + (mine && s.pd > 0 ? ' trash' : '');
      if (!n) { handEl.append(h('div', { class: 'none', text: s.ph === 'p' && s.cur === me ? '손이 비었어요 — 사거나 「턴 끝」' : '' })); return; }
      const avail = W - 16 - 14;
      const step = n > 1 ? Math.min(hw + 5, (avail - hw) / (n - 1)) : 0;
      const totalW = hw + step * (n - 1);
      const x0 = 7 + (avail - totalW) / 2;
      if (kc >= n) kc = n - 1;
      for (let i = 0; i < n; i++) {
        const off = i - (n - 1) / 2;
        const rot = n > 1 ? off * Math.min(3.2, 14 / n) : 0;
        const dy = Math.abs(off) * Math.abs(off) * (n > 5 ? 1.2 : 1.8);
        if (!show) {
          handEl.append(h('div', { class: 'back', style: { width: hw + 'px', height: hh + 'px', left: (x0 + i * step) + 'px', transform: 'translateY(' + dy + 'px) rotate(' + rot + 'deg)' } }));
          continue;
        }
        const id = cid(hand[i]);
        const chainOn = C[id].s < 4 && !!(s.ch & (1 << C[id].s)) && s.cur === me;
        const el = face(id, hw, hh, { chainOn, cls: (mine && id !== CURSE ? 'can' : '') + (sel === i ? ' sel' : '') + (kc === i ? ' kc' : '') + (i >= n - dealN ? ' deal' : '') });
        el.style.left = (x0 + i * step) + 'px';
        el.style.setProperty('--rot', rot + 'deg');
        el.style.transform = 'translateY(' + dy + 'px) rotate(' + rot + 'deg)';
        if (i >= n - dealN) el.style.animationDelay = ((i - (n - dealN)) * 70 / sp()) + 'ms';
        el.style.zIndex = 10 + i;
        el.dataset.hi = i;
        bindCard(el, () => tapHand(i), () => openReader({ id, hi: i }));
        handEl.append(el);
      }
      dealN = 0;
    }

    /* tap vs long-press */
    function bindCard(el, onTap, onLong) {
      let t = 0, sx = 0, sy = 0, fired = false;
      el.addEventListener('pointerdown', (e) => {
        if (e.button === 2) return;
        fired = false; sx = e.clientX; sy = e.clientY;
        clearTimeout(t); t = setTimeout(() => { fired = true; api.buzz(12); onLong(); }, 430);
      });
      const cancel = () => clearTimeout(t);
      el.addEventListener('pointermove', (e) => { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 12) cancel(); });
      el.addEventListener('pointerleave', cancel);
      el.addEventListener('pointercancel', cancel);
      el.addEventListener('pointerup', () => { cancel(); });
      el.addEventListener('click', (e) => { e.stopPropagation(); if (fired) { fired = false; return; } readMode ? onLong() : onTap(); });
      el.addEventListener('contextmenu', (e) => { e.preventDefault(); cancel(); fired = true; onLong(); });
    }

    function tapHand(i) {
      if (!st) return;
      const s = st;
      const id = cid(s.h[me][i]);
      if (!myTurn()) { openReader({ id, hi: i }); return; }
      if (s.pd > 0) { sel = sel === i ? -1 : i; api.sfx('click'); render(); return; }
      if (id === CURSE) { api.toast('가시 저주는 낼 수 없어요. 숲 카드로 정리해요'); api.buzz(30); return; }
      act({ t: 'p', i, g: tgt });
    }
    function tapOpp(i) {
      if (!st) return;
      const live = opps(st, me);
      if (live.length > 1 && myTurn() && live.includes(i) && tgt !== i) { tgt = i; api.sfx('click'); api.toast('🎯 ' + nm(i) + '을(를) 노려요'); render(); return; }
      openDeck(i);
    }
    function tryEnd() {
      if (!canDo()) return;
      const s = st;
      const left = s.h[me].split('').filter((ch) => cid(ch) !== CURSE).length;
      const canBuy = buyOptions(s).some(([, id]) => C[id].c <= s.mn);
      if ((left || canBuy) && !endWarn) {
        endWarn = 1; api.buzz(20);
        api.toast(left ? '아직 낼 카드가 ' + left + '장 있어요' : '◆' + s.mn + '로 살 수 있는 카드가 있어요');
        render(); later(() => { endWarn = 0; render(); }, 2600 * sp());
        return;
      }
      act({ t: 'e' });
    }

    /* ----- boss ----- */
    function intentText(s) {
      const I = bossIntent(s);
      if (I.k === 's') return ['방어막', '🛡' + I.s];
      if (I.k === 'c') return ['저주 ' + I.c + '장 + 공격', '☠' + I.c + ' ⚔' + I.a];
      if (I.k === 'v') return ['생명 흡수', '⚔' + I.a + ' ♥+' + I.h];
      if (I.k === 'A') return ['큰 불길!', '💥' + I.a];
      return ['공격', '⚔' + I.a];
    }
    function bossPanel(s) {
      const B = BOSS[s.bo], [it, iv] = intentText(s), R = rage(s);
      return h('div', { class: 'dd-op dd-boss' + (s.hp[1] > 0 ? '' : ' out'), 'data-seat': 1, style: { '--c': '#ee6a55' }, onclick: () => openBoss() },
        h('div', { class: 'bic', text: B.ic }),
        h('div', { class: 'bmid' },
          h('div', { class: 'r1' }, h('span', { class: 'nm', text: B.n }), R ? h('span', { text: '😡+' + R, style: { fontSize: '11px', color: '#ff9b8a' } }) : null),
          h('div', { class: 'r2' }, h('span', { class: 'hp', text: '♥' + s.hp[1] + '/' + B.hp }), s.sh[1] ? h('span', { class: 'shd', text: '🛡' + s.sh[1] }) : null),
          h('div', { class: 'dd-hpb' }, h('i', { style: { width: (100 * s.hp[1] / B.hp) + '%' } }))),
        h('div', { class: 'intent' }, '다음: ' + it, h('b', { text: iv })));
    }
    function openBoss() {
      const s = st, B = BOSS[s.bo];
      const pat = B.pat.map((p, j) => { const x = p[0] === 's' ? '🛡' + p[1] : p[0] === 'c' ? '☠' + p[1] + '+⚔' + p[2] : p[0] === 'v' ? '⚔' + p[1] + '♥+' + p[1] : p[0] === 'A' ? '💥' + p[1] : '⚔' + p[1]; return (j === s.bi % B.pat.length ? '▶' : '') + x; }).join(' → ');
      showBox([h('div', { class: 'txt' }, h('h3', { text: B.ic + ' ' + B.n }), h('div', { class: 'sch', text: B.d }),
        h('div', { text: '생명 ' + B.hp + ' — 0으로 만들면 승리. 또는 별 ★' + s.g + '개를 모으면 봉인!' }),
        h('div', { text: '행동 순서: ' + pat }),
        h('div', { class: 'muted', text: '5바퀴마다 화가 나서 공격·방어막 +1. 보스 방어막은 보스가 다시 움직일 때 사라져요. ☠ 가시 저주는 아무 쓸모없는 카드 — 숲 카드로 정리하세요.' }),
        h('div', { class: 'muted', text: '별 기준: ' + B.T[0] + '바퀴 안 ★★★ · ' + B.T[1] + '바퀴 안 ★★ · 이기면 ★' }))]);
    }

    /* ----- reader / sheets ----- */
    function closeReader() { if (reader) { reader.remove(); reader = null; } }
    function showBox(kids, btns) {
      closeReader();
      const box = h('div', { class: 'box' }, kids, h('div', { class: 'btns' }, btns || [], h('button', { class: 'btn', text: '닫기', onclick: closeReader })));
      reader = h('div', { class: 'dd-read', onclick(e) { if (e.target === reader) closeReader(); } }, box);
      wrap.append(reader);
      api.sfx('click');
    }
    function cardText(id) {
      const K = C[id], S = SCH[K.s];
      const kids = [h('h3', { text: K.n }), h('div', { class: 'sch', text: S.ic + ' ' + S.n + (K.s < 4 ? ' 학파 — ' + ['공격', '뽑기·방어막', '마나·정리·회복', '별 점수'][K.s] : K.s === 4 ? ' 카드' : '') + ' · 값 ◆' + K.c })];
      if (K.s === 5) kids.push(h('div', { text: '아무 효과도 없는 저주 카드예요. 손에 오면 자리만 차지해요. 「정리」로 없앨 수 있어요.' }));
      else kids.push(h('div', { html: '<b>낼 때:</b> ' + descOf(K.e) }));
      if (K.k) kids.push(h('div', { class: 'chn', html: '🔗 <b>연쇄</b> — 이번 차례에 ' + S.n + ' 카드를 먼저 냈다면 더: ' + descOf(K.k) }));
      if (K.b) kids.push(h('div', { class: 'muted', text: '1회용: 한 번 내면 덱에서 사라져요.' }));
      if (FIX.includes(id)) kids.push(h('div', { class: 'muted', text: '시장 옆 상설 더미 — 언제나 살 수 있어요.' }));
      return kids;
    }
    function openReader(o) {
      if (!st) return;
      const s = st, id = o.id, K = C[id];
      const big = face(id, 104, 140, {});
      const btns = [];
      if (o.slot != null) {
        const ok = myTurn() && !s.pd && K.c <= s.mn && canDo();
        const why = !myTurn() ? (s.ph === 'p' ? '내 차례에 살 수 있어요' : '') : s.pd ? '정리부터 끝내요' : K.c > s.mn ? '마나가 ' + (K.c - s.mn) + ' 모자라요' : '';
        btns.push(h('button', { class: 'btn primary', text: ok ? '사기 ◆' + K.c : why || '사기', disabled: !ok, onclick() { closeReader(); act({ t: 'b', k: o.slot }); } }));
      } else if (o.hi != null && myTurn() && !s.pd && id !== CURSE) {
        btns.push(h('button', { class: 'btn primary', text: '내기', disabled: !canDo(), onclick() { closeReader(); act({ t: 'p', i: o.hi, g: tgt }); } }));
      }
      showBox([h('div', { class: 'row1' }, big, h('div', { class: 'txt' }, cardText(id)))], btns);
    }
    function countMap(str) { const m = {}; for (const ch of str) m[ch] = (m[ch] || 0) + 1; return Object.keys(m).sort((a, b) => C[cid(a)].s - C[cid(b)].s || C[cid(a)].c - C[cid(b)].c).map((ch) => [cid(ch), m[ch]]); }
    function grid(str) {
      const g = h('div', { class: 'grid' });
      const w = Math.min(64, Math.floor((Math.min(330, W - 28) - 28 - 5 * 6) / 5));
      for (const [id, n] of countMap(str)) {
        const el = face(id, w, Math.round(w * 1.34), {});
        g.append(h('div', { class: 'gi', onclick: () => openReader({ id }) }, n > 1 ? h('span', { class: 'x', text: '×' + n }) : null, el));
      }
      return g;
    }
    function openDeck(p) {
      if (!st) return;
      const s = st;
      if (s.bo >= 0 && p === 1) return openBoss();
      const kids = [h('div', { class: 'txt' }, h('h3', { text: (p === me ? '내 카드' : nm(p) + '의 카드') }))];
      const all = cardsOf(s, p);
      if (p === me && handShown(p)) {
        kids.push(h('div', { class: 'muted', text: '모두 ' + all.length + '장 · 덱 ' + s.d[p].length + ' · 손 ' + s.h[p].length + ' · 버린 더미 ' + s.c[p].length + (s.cur === p && s.pl.length ? ' · 낸 카드 ' + s.pl.length : '') }));
        if (s.d[p].length) { kids.push(h('h4', { text: '덱 (뽑을 카드 — 순서는 비밀)' }), grid(s.d[p])); }
        if (s.c[p].length) { kids.push(h('h4', { text: '버린 더미 (덱이 떨어지면 섞어서 새 덱)' }), grid(s.c[p])); }
        kids.push(h('h4', { text: '전체' }), grid(all));
      } else {
        kids.push(h('div', { class: 'muted', text: '모두 ' + all.length + '장 (산 카드는 모두가 봤으니 공개돼요. 손에 든 카드는 비밀)' }), grid(all));
      }
      showBox(kids);
    }

    /* ----- effects ----- */
    const rectOf = (el) => { if (!el) return null; const r = el.getBoundingClientRect(), R = wrap.getBoundingClientRect(); return { x: r.left - R.left, y: r.top - R.top, w: r.width, h: r.height }; };
    const center = (r) => ({ x: r.x + r.w / 2, y: r.y + r.h / 2 });
    function seatEl(i) { return i === me ? meEl : oppsEl.querySelector('[data-seat="' + i + '"]'); }
    function fly(id, from, to, ms, opt) {
      if (!from || !to) return;
      const mw = +wrap.dataset.mw, mh = +wrap.dataset.mh;
      const el = face(id, mw, mh, {});
      el.classList.add('dd-fly');
      const s0 = from.w / mw, s1 = (to.w || mw * 0.5) / mw;
      el.style.transform = 'translate(' + from.x + 'px,' + from.y + 'px) scale(' + s0 + ')';
      el.style.transition = 'transform ' + ms / sp() + 'ms cubic-bezier(.3,.7,.3,1), opacity ' + ms / sp() + 'ms';
      fxl.append(el);
      requestAnimationFrame(() => requestAnimationFrame(() => {
        el.style.transform = 'translate(' + (to.x + (to.w ? 0 : -mw * s1 / 2)) + 'px,' + (to.y + (to.h ? 0 : -mh * s1 / 2)) + 'px) scale(' + s1 + ')' + (opt && opt.spin ? ' rotate(20deg)' : '');
        if (opt && opt.fade) el.style.opacity = '0';
      }));
      later(() => el.remove(), ms + 60);
    }
    function pop(at, text, color, delay) {
      if (!at) return;
      later(() => {
        const el = h('div', { class: 'dd-pop', text, style: { left: at.x + 'px', top: at.y + 'px', color } });
        fxl.append(el); later(() => el.remove(), 950);
      }, delay || 0);
    }
    function bolt(from, to, color, ms, delay) {
      if (!from || !to) return;
      later(() => {
        const el = h('div', { class: 'dd-bolt', style: { '--c': color, transform: 'translate(' + from.x + 'px,' + from.y + 'px)', transition: 'transform ' + ms / sp() + 'ms ease-in' } });
        fxl.append(el);
        requestAnimationFrame(() => requestAnimationFrame(() => { el.style.transform = 'translate(' + to.x + 'px,' + to.y + 'px)'; }));
        later(() => el.remove(), ms + 30);
      }, delay || 0);
    }
    function shake(el, delay) { if (!el) return; later(() => { el.classList.remove('dd-shake'); void el.offsetWidth; el.classList.add('dd-shake'); later(() => el.classList.remove('dd-shake'), 380); }, delay || 0); }
    function glow(el, delay) { if (!el) return; later(() => { el.classList.remove('dd-glow'); void el.offsetWidth; el.classList.add('dd-glow'); later(() => el.classList.remove('dd-glow'), 620); }, delay || 0); }
    function shuffleFx(p, delay) {
      const src = p === me ? rectOf(meEl.querySelector('.disc')) : rectOf(seatEl(p));
      const dst = p === me ? rectOf(meEl.querySelector('.deck')) : src;
      if (!src || !dst) return;
      later(() => {
        api.sfx('whoosh');
        for (let k = 0; k < 5; k++) {
          const el = h('div', { class: 'dd-shuf', style: { transform: 'translate(' + (src.x + src.w / 2 - 15) + 'px,' + (src.y + src.h / 2 - 20) + 'px) rotate(' + (k * 9 - 18) + 'deg)', transition: 'transform ' + 380 / sp() + 'ms ease-in-out ' + k * 45 / sp() + 'ms' } });
          fxl.append(el);
          requestAnimationFrame(() => requestAnimationFrame(() => { el.style.transform = 'translate(' + (dst.x + dst.w / 2 - 15 + (k % 2 ? 12 : -12)) + 'px,' + (dst.y + dst.h / 2 - 20 - 16) + 'px) rotate(' + (k % 2 ? 14 : -14) + 'deg)'; }));
          later(() => { el.style.transform = 'translate(' + (dst.x + dst.w / 2 - 15) + 'px,' + (dst.y + dst.h / 2 - 20) + 'px) rotate(0deg)'; el.style.opacity = '0'; el.style.transition = 'transform 200ms, opacity 260ms'; }, 420 + k * 45);
          later(() => el.remove(), 760 + k * 45);
        }
      }, delay || 0);
    }
    function damageFx(ev, fromR, t0) {
      let tEnd = t0;
      ev.dm.forEach(([t, n, ab], k) => {
        const tr = rectOf(seatEl(t));
        if (!tr) return;
        const d = t0 + k * 90;
        bolt(fromR, center(tr), n > 0 ? '#ff7a45' : '#8fd0ff', 260, d);
        later(() => { if (n > 0) { api.sfx('hit'); api.buzz(t === me && api.canAct(me) ? 35 : 0); } else api.sfx('thud'); }, d + 260);
        if (ab) pop({ x: center(tr).x - 26, y: center(tr).y }, '🛡−' + ab, '#8fd0ff', d + 260);
        if (n) { pop({ x: center(tr).x + (ab ? 22 : 0), y: center(tr).y }, '−' + n, '#ff6b55', d + 260); shake(seatEl(t), d + 260); }
        tEnd = Math.max(tEnd, d + 560);
      });
      return tEnd;
    }

    function animate(ev, prev, pre) {
      const s = st;
      let tEnd = 0;
      const p = ev.p;
      const tableR = rectOf(tableEl);
      const tc = tableR ? { x: tableR.x + tableR.w * 0.42, y: tableR.y + tableR.h * 0.5 } : null;
      const playedEls = tableEl.querySelectorAll('.dd-played .dc');
      const pR = p === me ? rectOf(meEl) : rectOf(seatEl(p));
      if (ev.k === 'p' || ev.k === 'pa') {
        api.sfx('card');
        const ids = ev.k === 'p' ? [ev.c] : ev.cs.split('').map(cid);
        const srcs = ev.k === 'p' ? [pre.hand[ev.i]] : ev.ix.map((i) => pre.hand[i]);
        const nNew = ev.k === 'p' ? (ev.burn ? 0 : 1) : ids.length;
        ids.forEach((id, k) => {
          const from = srcs[k] || (pR ? { x: pR.x + pR.w / 2 - 20, y: pR.y + pR.h / 2 - 27, w: 40, h: 54 } : null);
          const dstEl = ev.burn && ev.k === 'p' ? null : playedEls[playedEls.length - nNew + k];
          if (dstEl) { dstEl.style.visibility = 'hidden'; later(() => { dstEl.style.visibility = ''; }, 300 + k * 50); }
          const to = dstEl ? rectOf(dstEl) : tc ? { x: tc.x - 30, y: tc.y - 40, w: 60, h: 80 } : null;
          later(() => fly(id, from, to, 300, ev.burn ? { fade: 1, spin: 1 } : null), k * 50);
        });
        tEnd = 300 + ids.length * 50;
        if (ev.burn) later(() => api.sfx('whoosh'), 260);
        const fromR = tc;
        if (ev.ch) { pop({ x: tc.x, y: tc.y - 30 }, '🔗 연쇄!', '#ffe08a', 260); api.buzz(10); }
        if (ev.dm.length) tEnd = Math.max(tEnd, damageFx(ev, fromR, 280));
        const meR = rectOf(seatEl(p));
        if (ev.hl && meR) { pop({ x: center(meR).x - 30, y: center(meR).y }, '♥+' + ev.hl, '#7dffb0', 300); api.sfx('pop'); }
        if (ev.t && meR) { pop({ x: center(meR).x + 30, y: center(meR).y }, '★+' + ev.t, '#ffd34a', 320); later(() => api.sfx('pop'), 320); glow(seatEl(p), 320); }
        const dm = s.mn - (prev ? prev.mn : 0);
        const manaEl = tableEl.querySelector('.dd-mana');
        if (dm > 0 && manaEl) { const r = rectOf(manaEl); pop({ x: center(r).x, y: r.y }, '◆+' + dm, '#ffd770', 260); later(() => api.sfx('chip'), 260); }
        const ds = s.sh[p] - (prev ? prev.sh[p] : 0);
        if (ds > 0 && meR) pop({ x: center(meR).x, y: center(meR).y - 10 }, '🛡+' + ds, '#8fd0ff', 300);
        if (ev.sh) { shuffleFx(p, 200); tEnd = Math.max(tEnd, 900); }
        if (s.pd > 0 && p === me && api.canAct(me)) later(() => api.toast('🗑 정리할 카드를 골라요'), 300);
      } else if (ev.k === 'b') {
        api.sfx('chip');
        const from = pre.slot[ev.m];
        const to = p === me ? rectOf(meEl.querySelector(ev.top ? '.deck' : '.disc')) : pR;
        fly(ev.c, from, to, 380, { fade: p !== me });
        tEnd = 420;
        if (ev.top && p === me) later(() => api.toast('덱 맨 위에 놓았어요'), 300);
      } else if (ev.k === 'x') {
        if (ev.c >= 0) {
          const from = pre.hand[ev.i] || pR;
          fly(ev.c, from, from ? { x: from.x + 10, y: from.y - 70, w: (from.w || 60) * 0.6, h: 0 } : null, 420, { fade: 1, spin: 1 });
          later(() => api.sfx('whoosh'), 100);
          tEnd = 460;
        }
      } else if (ev.k === 'e') {
        // 낸 카드·손 → 버린 더미
        const discR = p === me ? rectOf(meEl.querySelector('.disc')) : pR;
        pre.played.forEach((r, k) => { if (r && pre.playedIds[k] != null) later(() => fly(pre.playedIds[k], r, discR, 300, { fade: 1 }), k * 30); });
        tEnd = 320 + pre.played.length * 30;
        let d = tEnd;
        if (ev.sh) { shuffleFx(p, d * 0.5); }
        if (ev.bv) {
          const bR = rectOf(seatEl(1)), mR = rectOf(seatEl(0));
          d += 120;
          later(() => { glow(seatEl(1)); api.sfx('thud'); }, d);
          if (ev.bv.dm && ev.bv.dm.length) d = damageFx({ dm: ev.bv.dm }, bR ? center(bR) : null, d + 200);
          if (ev.bv.k === 's' && bR) pop(center(bR), '🛡+' + s.sh[1], '#8fd0ff', d + 200);
          if (ev.bv.hl && bR) pop({ x: center(bR).x - 30, y: center(bR).y }, '♥+' + ev.bv.hl, '#7dffb0', d + 300);
          if (ev.bv.c && bR && mR) for (let q = 0; q < ev.bv.c; q++) later(() => fly(CURSE, { x: center(bR).x - 20, y: center(bR).y - 27, w: 40, h: 54 }, rectOf(meEl.querySelector('.disc')), 420, {}), d + 200 + q * 120);
          if (ev.bv.c) later(() => api.toast('☠ 가시 저주 ' + ev.bv.c + '장이 버린 더미에!'), d + 300);
          d += 650;
        }
        if (ev.fl) {
          const cards = mktEl.querySelectorAll('.dc,.slot');
          const shift = (+wrap.dataset.mw || 60) + 4;
          later(() => {
            cards.forEach((el, k) => {
              el.style.transition = 'none'; el.style.transform = 'translateX(' + shift + 'px)'; if (k === cards.length - 1) el.style.opacity = '0';
              requestAnimationFrame(() => requestAnimationFrame(() => { el.style.transition = 'transform ' + 320 / sp() + 'ms ease, opacity ' + 320 / sp() + 'ms'; el.style.transform = ''; el.style.opacity = ''; }));
            });
            if (ev.fl[0] >= 0 && pre.slot[0]) fly(ev.fl[0], pre.slot[0], { x: pre.slot[0].x - 40, y: pre.slot[0].y + 10, w: pre.slot[0].w * 0.6, h: 0 }, 360, { fade: 1 });
          }, Math.min(d, 400));
          d = Math.max(d, 760);
        }
        tEnd = Math.max(tEnd, d);
        if (p === me && handShown(me)) later(() => api.sfx('card'), 200);
      }
      return tEnd;
    }

    function snapshot() {
      const pre = { hand: [], slot: [], played: [], playedIds: [] };
      handEl.querySelectorAll('.dc').forEach((el) => { pre.hand[+el.dataset.hi] = rectOf(el); });
      mktEl.querySelectorAll('[data-slot]').forEach((el) => { pre.slot[+el.dataset.slot] = rectOf(el); });
      fixEl.querySelectorAll('[data-slot]').forEach((el) => { pre.slot[+el.dataset.slot] = rectOf(el); });
      tableEl.querySelectorAll('.dd-played .dc').forEach((el) => { pre.played.push(rectOf(el)); pre.playedIds.push(+el.dataset.id); });
      return pre;
    }

    /* ----- keyboard / pad ----- */
    let offIn = null;
    if (api.input && api.input.on) {
      offIn = api.input.on((type, id) => {
        if (type !== 'down' || !st || reader && id !== 'read') return;
        const n = (st.h[me] || '').length;
        if (id === 'left') { kc = n ? (kc <= 0 ? n - 1 : kc - 1) : -1; render(); }
        else if (id === 'right') { kc = n ? (kc + 1) % n : -1; render(); }
        else if (id === 'play') { if (kc >= 0 && kc < n) tapHand(kc); }
        else if (id === 'read') { if (reader) closeReader(); else if (kc >= 0 && kc < n && handShown(me)) openReader({ id: cid(st.h[me][kc]), hi: kc }); }
        else if (id === 'all') { if (myTurn() && !st.pd) act({ t: 'pa' }); }
        else if (id === 'end') { if (myTurn() && !st.pd) tryEnd(); }
      });
    }

    function update(s, prev) {
      if (dead) return;
      const first = !st;
      const ev = s.last;
      const isNew = prev && prev !== s && ev && (!prev.last || prev.last.id !== ev.id);
      const pre = isNew ? snapshot() : null;
      // 정리 선택 / 경고는 새 상태에서 초기화
      if (!prev || prev !== s) { sel = -1; endWarn = 0; }
      if (isNew && ev.k === 'b' && ev.m < NMK) newSlot = ev.m;
      if (isNew && ev.k === 'p' && ev.dr && ev.p === meSeat()) dealN = ev.dr;
      if (isNew) logLine = logOf(ev, s);
      st = s;
      if (first) { fit(); ro.observe(root); }
      // 차례를 끝내고 새로 뽑은 5장이 펼쳐지며 들어와요
      if (isNew && ev.k === 'e' && ev.p === meSeat() && handShown(ev.p)) dealN = s.h[ev.p].length;
      if (closeReaderOnUpdate(prev, s)) closeReader();
      fxl.innerHTML = '';
      render();
      if (isNew) {
        setBusy(true);
        const my = ++animId;
        const t = animate(ev, prev, pre);
        later(() => { if (my === animId) { setBusy(false); render(); } }, Math.max(120, t));
      }
    }
    function closeReaderOnUpdate(prev, s) { return reader && prev && prev !== s && s.cur !== (prev && prev.cur); }

    return {
      update,
      destroy() {
        dead = true;
        timers.forEach(clearTimeout); timers.clear();
        try { ro.disconnect(); } catch (e) {}
        if (offIn) try { offIn(); } catch (e) {}
        api.setBusy(false);
        style.remove(); wrap.remove();
      },
    };
  }

  /* ---------- 도감 (codex) — 카드·보스 표에서 자동 생성 ---------- */
  function cxCard(K) {
    const SC = SCH[K.s];
    let d = '비용 ◆' + K.c + ' · ' + (descOf(K.e) || '효과 없음');
    if (K.k) d += ' · 🔗연쇄: ' + descOf(K.k);
    if (K.b) d += ' · 1회용';
    if (K.q) d += ' · 공급 ' + K.q + '장';
    return { icon: SC.ic, name: K.n, tag: SC.n + (K.c ? ' ◆' + K.c : ''), desc: d };
  }
  const BOSS_ACT = (p) => p[0] === 'a' ? '공격 ' + p[1] : p[0] === 's' ? '방어막 +' + p[1] : p[0] === 'c' ? '저주 ' + p[1] + '장 + 공격 ' + p[2] : p[0] === 'v' ? '흡수 ' + p[1] + '(공격+회복)' : '큰 공격 ' + p[1];
  const CODEX = [
    { h: '학파 카드', p: ['시장에 나오는 학파 카드예요. 🔗연쇄는 이번 차례에 같은 학파 카드를 먼저 냈을 때 더 붙는 효과예요.'],
      rows: C.filter((K) => K.s < 4).sort((a, b) => a.s - b.s || a.c - b.c).map(cxCard) },
    { h: '기본 카드', p: ['시작 덱: 마나 구슬 ×7 + 마력 화살 ×3. 큰 마나 구슬·별 조각은 시장 옆 상설 더미에서 언제나 살 수 있어요.'],
      rows: C.filter((K) => K.s >= 4).map((K) => K.id === CURSE
        ? { icon: SCH[5].ic, name: K.n, tag: '저주', desc: '낼 수 없는 카드예요. 보스가 덱에 섞어 넣어요. 숲 카드의 🗑 정리로 없애요.' }
        : { icon: SCH[4].ic, name: K.n, tag: K.id === ORB || K.id === ARROW ? '시작 덱' : '상설 ◆' + K.c, desc: (K.c ? '비용 ◆' + K.c + ' · ' : '') + descOf(K.e) }) },
    { h: '보스', p: ['혼자 하기 보스예요. 행동 순서대로 반복하고, 5바퀴마다 화가 나서 공격·방어막이 1씩 세져요. 내 생명은 40.'],
      rows: BOSS.map((B, i) => ({ icon: B.ic, name: B.n, tag: ['쉬움', '보통', '어려움'][i],
        desc: '생명 ' + B.hp + ' · 봉인 별 ★' + B.g + ' · ' + B.d + ' · 행동: ' + B.pat.map(BOSS_ACT).join(' → ') + ' · ★★★ ' + B.T[0] + '바퀴 안, ★★ ' + B.T[1] + '바퀴 안' })) },
  ];

  L.register({
    id: 'deckduel', name: '마법 카드 덱 쌓기', tag: '덱빌딩 마법 대결', cat: '카드',
    blurb: '모두 똑같은 약한 덱으로 시작해 시장의 마법 카드를 사 모아 덱을 키워요. 상대 마법사의 생명을 0으로 만들거나 별을 가장 많이 모으면 승리!',
    tint: '#3b2466',
    icon: '<rect x="8" y="14" width="22" height="30" rx="3" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(-12 19 29)"/><rect x="18" y="10" width="22" height="30" rx="3" fill="currentColor" opacity=".35"/><rect x="18" y="10" width="22" height="30" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M29 17l2.2 4.6 5 .6-3.7 3.4 1 5-4.5-2.5-4.5 2.5 1-5-3.7-3.4 5-.6z" fill="currentColor"/><path d="M44 30l4 4-4 4-4-4z" fill="currentColor"/><path d="M42 44h8M46 40v8" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: true, aiDelay: 700,
    options: [
      { id: 'hp', label: '생명 · 게임 길이 (여럿이 할 때)', choices: [{ v: 30, label: '30 · 짧게 (★11)' }, { v: 40, label: '40 · 보통 (★15)' }, { v: 50, label: '50 · 길게 (★19)' }], def: 40 },
      { id: 'boss', label: '혼자 할 때 보스', choices: [{ v: 0, label: '🗿 돌 골렘 (쉬움)' }, { v: 1, label: '🧙 서리 마녀 (보통)' }, { v: 2, label: '🐉 그림자 용 (어려움)' }], def: 1 },
    ],
    controls: [
      { id: 'left', label: '손 카드 고르기 ←', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '손 카드 고르기 →', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'play', label: '고른 카드 내기', keys: ['Space', 'KeyW'], pad: ['a'] },
      { id: 'read', label: '카드 설명 보기/닫기', keys: ['KeyR'], pad: ['b'] },
      { id: 'all', label: '마나 카드 모두 내기', keys: ['KeyQ'], pad: ['x'] },
      { id: 'end', label: '턴 끝', keys: ['KeyE'], pad: ['y'] },
    ],
    quick: [
      '모두 똑같은 약한 덱(마나 구슬 7 + 마력 화살 3)으로 시작해요. 매 차례 5장을 뽑아요.',
      '카드를 내서 마나 ◆를 모으고, 그 마나로 가운데 시장의 마법 카드를 사서 내 덱을 강하게 만들어요.',
      '상대 마법사의 생명 ♥을 0으로 만들거나, 별 ★을 목표만큼 모은 바퀴가 끝날 때 별이 가장 많으면 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '마법사가 되어 내 카드 덱을 키우며 겨뤄요. 이기는 길은 두 가지예요.',
        '⚔ 공격: 상대 마법사를 모두 쓰러뜨리면(생명 0) 바로 승리. 3–4명일 때 쓰러진 마법사는 탈락이에요(모은 별도 소용없어요).',
        '★ 별: 누군가 별 목표에 닿으면 그 바퀴가 끝날 때(모두 같은 횟수를 한 뒤) 게임이 끝나고, 별이 가장 많은 사람이 승리(같으면 생명이 많은 쪽).',
        '별 목표는 생명 옵션에 따라: 생명 40 → ★15 (기본) · 30 → ★11 · 50 → ★19. 3명이면 1개, 4명이면 2개 적어요. 30바퀴가 지나면 별로 판정해요.',
        '혼자 하기: 보스와 싸워요. 보스를 쓰러뜨리거나 별을 모아 봉인하면 승리. 빨리 이길수록 별 ★ 1~3개.'] },
      { h: '차례에 할 일', p: [
        '① 손의 카드를 원하는 만큼 내요(누르면 바로 나가요). 카드마다 마나·공격·방어막·뽑기 같은 효과가 있어요.',
        '② 모은 마나 ◆로 시장 카드나 상설 더미(큰 마나 구슬 · 별 조각)를 사요. 몇 장이든 살 수 있어요. 마나는 다음 차례로 안 넘어가요.',
        '③ 「턴 끝」: 낸 카드와 남은 손 카드는 버린 더미로. 덱에서 새로 5장을 뽑아요.',
        '산 카드는 버린 더미로 가요. 덱이 다 떨어지면 버린 더미를 섞어 새 덱을 만들어요 → 그때부터 산 카드가 손에 들어와요!'] },
      { h: '카드 기호', p: [
        '◆ 마나 · ⚔ 상대 하나에게 피해 · 💥 모든 상대에게 피해 · 🃏 카드 더 뽑기 · 🛡 방어막 · ♥ 생명 회복 · ★ 별 · 🗑 정리 · ⤒ 산 카드를 덱 위로.',
        '🛡 방어막은 피해를 먼저 막아 주고, 내 다음 차례가 시작될 때 사라져요.',
        '🗑 정리: 손의 카드를 골라 영원히 없애요. 약한 카드(마력 화살·마나 구슬·저주)를 없애면 좋은 카드가 더 자주 나와요. 안 해도 돼요.',
        '「1회」 카드는 한 번 내면 사라지는 대신 효과가 커요.'] },
      { h: '네 학파와 연쇄 🔗', p: [
        '🔥 불 = 공격 · 💧 물 = 카드 뽑기·방어막 · 🌿 숲 = 마나·정리·회복 · ⭐ 별 = 별 점수.',
        '🔗 연쇄: 이번 차례에 같은 학파 카드를 먼저 냈다면 카드 아래쪽 연쇄 효과가 더 붙어요. 연쇄가 켜진 카드는 노랗게 빛나요.',
        '그래서 한 학파를 모으면 강해져요. 같은 학파 카드끼리 함께 내 보세요!'] },
      { h: '시장', p: [
        '가운데에 카드 5장이 깔려 있어요. 사면 그 자리에 공급 더미에서 새 카드가 채워져요.',
        '한 바퀴가 끝날 때마다 맨 왼쪽 카드가 빠지고 나머지가 한 칸씩 밀려요 — 시장이 계속 바뀌어요.',
        '큰 마나 구슬(◆3 → 마나 2)과 별 조각(◆4 → 별 1)은 언제나 살 수 있어요.'] },
      { h: '예시', p: [
        '손: 마나 구슬 ×4, 마력 화살. → 화살을 내면 상대 ♥ −1, 「마나 모두」로 ◆4.',
        '→ ◆4로 「화염구」(피해 4, 연쇄 +2)를 사요. 버린 더미로 가요.',
        '→ 몇 차례 뒤 덱을 섞으면 화염구가 손에 와요. 불똥(불)을 먼저 내고 화염구를 내면 연쇄로 피해 6!'] },
      { h: '혼자 하기 (보스전)', p: [
        '보스 위쪽 「다음:」에 보스가 할 행동이 미리 보여요. 큰 공격 전엔 방어막을 준비해요.',
        '내 생명 40. 보스는 내 차례가 끝날 때마다 움직이고, 5바퀴마다 화가 나서 강해져요. 30바퀴가 지나면 실패.',
        '돌 골렘(쉬움) · 서리 마녀(보통, 저주 카드) · 그림자 용(어려움, 큰 불길). 보스 패널을 누르면 행동 순서가 보여요.'] },
      { h: '조작', p: [
        '손 카드 누르기 = 내기 · 꾹 누르기(또는 ⓘ 읽기 모드) = 설명 읽기. 시장 카드를 누르면 설명과 「사기」 버튼이 떠요.',
        '「◆ 마나 모두」: 손의 마나 카드를 한 번에 내요. 3–4명이면 위쪽 상대를 눌러 공격할 상대 🎯를 골라요.',
        '덱·버림·전체 버튼으로 내 카드를 볼 수 있어요. 상대를 누르면 그 사람이 산 카드가 보여요.',
        'PC: ←/→ 카드 고르기, Space 내기, R 설명, Q 마나 모두, E 턴 끝.',
        '한 폰으로 여럿이 하면 이름이 뜰 때 폰을 넘겨 몰래 손을 봐요. AI 난이도는 자리마다 쉬움·보통·어려움(어려움은 덱 상태와 공격/별 타이밍을 따져요).'] },
    ],
    tutorial: [
      { sel: '.dd-hand', text: '내 손의 카드 5장이에요. 누르면 바로 내요. 꾹 누르면 설명을 읽을 수 있어요.' },
      { sel: '.dd-mana', text: '마나 구슬을 내면 마나 ◆가 모여요. 아래 「◆ 마나 모두」로 한 번에 낼 수 있어요.' },
      { sel: '.dd-mkt', text: '시장 카드를 누르고 「사기」 — 마나로 새 마법 카드를 사요. 산 카드는 버린 더미로 갔다가, 덱을 섞으면 손에 들어와요.' },
      { sel: '.dd-fix', text: '큰 마나 구슬·별 조각은 언제나 살 수 있어요. 살 게 마땅치 않을 때 좋아요.' },
      { sel: '.dd-opps', text: '⚔ 공격 카드는 상대 생명 ♥을 깎아요(🛡 방어막이 먼저 막아요). 상대를 쓰러뜨리거나 별 ★을 목표만큼 모으면 승리!' },
      { sel: '.dd-piles', text: '덱·버림·전체를 누르면 내 카드를 볼 수 있어요. 덱이 떨어지면 버린 더미를 섞어 새 덱이 돼요.' },
      { sel: '.dd-bar .end', text: '다 냈으면 「턴 끝」. 남은 카드는 버리고 새로 5장을 뽑아요.' },
    ],
    codex: CODEX,
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { C, BOSS },
  });
})();
