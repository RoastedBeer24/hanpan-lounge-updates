/* 열기구 레이스 — realtime hot-air balloon race (1–4 balloons).
   One big burner button: hold to heat the envelope (the balloon rises — with real lag), let go and it cools and sinks;
   the vent valve dumps hot air for a quick drop. There is no steering: the wind blows at different speeds/directions at
   different altitudes, so you pick your layer. Fly through the gate rings in order, reach the finish line.
   Host-authoritative fixed-step sim (1/60 s); guests publish burner/vent input, receive ~20 Hz snapshots and predict their
   own balloon. One person per phone: locally you fly seat 0 against AI balloons; friends play through online/LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const H = 1 / 60;                 // physics step
  const G = 80, DRAG = 1.25;        // lift per unit of heat above neutral, vertical air drag (1/s)
  const BURN = 0.9, COOL = 0.34, VENT = 1.0, NEUT = 0.5; // heat: burner gain, Newton cooling, vent dump, neutral heat
  const ENV_DY = 30, ENV_R = 15;    // envelope centre above the basket bottom, envelope radius (collisions)
  const CEIL = 340, CEIL_HARD = 385, VMAXY = 34, XREL = 0.9; // thin-air soft ceiling (basket), max climb, wind take-up (1/s)
  const PEN = 4, CAP_T = 240, AFTER_FIRST = 35, AFTER_HUMANS = 8, COUNT = 3, INTRO = 1.4, GHOST_T = 14, START_X = 40;
  const Y_LO = -16, Y_HI = 425;     // visible altitude range
  const WS = 1.2;                   // global wind scale
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const mix = (a, b, t) => a + (b - a) * t;
  const sm = (t) => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  const frac = (v) => v - Math.floor(v);
  const fmtT = (ms) => { const s = Math.max(0, ms) / 1000, m = Math.floor(s / 60), r = s - m * 60; return m + ':' + (r < 10 ? '0' : '') + r.toFixed(1); };
  function hash32(a, b) {
    let h = (Math.imul(a | 0, 0x9E3779B1) ^ Math.imul((b | 0) + 0x632BE5AB, 0x85EBCA77)) >>> 0;
    h ^= h >>> 16; h = Math.imul(h, 0x7feb352d) >>> 0; h ^= h >>> 15; h = Math.imul(h, 0x846ca68b) >>> 0; h ^= h >>> 16;
    return h >>> 0;
  }

  /* courses. gnd: terrain control points [x, height] (cosine-smoothed; < 0 = under the sea, whose surface is 0).
     zones: from x on, wind bands [[top altitude, speed (+ = toward the finish)], …] by envelope altitude.
     gates [x, low, high] (envelope altitude window), storms [x, y, r], birds [x, y, swingX, swingY, rate], therm [x, halfW, top, k] */
  const COURSES = [
    { id: 'meadow', name: '초원 아침', sub: '완만한 언덕과 세 갈래 바람. 첫 비행에 딱!', len: 2100,
      gnd: [[0, 18], [150, 22], [300, 40], [450, 28], [600, 55], [750, 35], [900, 24], [1050, 48], [1200, 70], [1350, 45], [1500, 30], [1650, 52], [1800, 36], [1950, 22], [2100, 18], [3000, 18]],
      zones: [{ x: 0, b: [[90, 9], [180, 25], [280, 14], [1e9, -8]] }, { x: 1100, b: [[90, 13], [190, 8], [290, 27], [1e9, 12]] }],
      gates: [[380, 60, 160], [760, 150, 250], [1150, 90, 190], [1500, 240, 340], [1850, 130, 230]],
      storms: [], birds: [[1660, 300, 50, 22, 0.5]], therm: [[980, 45, 300, 1]],
      pal: { sky: ['#86bfe6', '#cfe6f0', '#ffe3b8'], sun: [0.24, 0.3, 24, '#fff6d6'], far: [{ c: '#a7c6cf', par: 0.16, base: 70, amp: 50, ty: 'hill', p: 1.2 }, { c: '#80ad8f', par: 0.4, base: 42, amp: 36, ty: 'hill', p: 3.1 }], gnd: ['#82b85c', '#4a7838'], edge: '#b4dc84', deco: 'tree', bird: '#3a3040', cloud: 1 } },
    { id: 'snow', name: '눈 덮인 산맥', sub: '높은 봉우리를 넘고 골짜기 관문으로 내려가요', len: 2300,
      gnd: [[0, 30], [200, 40], [420, 90], [600, 230], [760, 110], [900, 40], [1050, 60], [1180, 150], [1300, 250], [1440, 120], [1560, 45], [1700, 70], [1850, 180], [1940, 210], [2050, 90], [2200, 30], [3100, 30]],
      zones: [{ x: 0, b: [[120, 6], [220, 16], [320, 30], [1e9, 20]] }, { x: 950, b: [[100, -10], [200, 22], [310, 14], [1e9, 26]] }, { x: 1600, b: [[110, 12], [230, 26], [330, 10], [1e9, -6]] }],
      gates: [[320, 110, 210], [900, 70, 170], [1300, 285, 375], [1620, 80, 180], [2000, 230, 330]],
      storms: [], birds: [[1100, 215, 70, 28, 0.45]], therm: [],
      pal: { sky: ['#5d8fd0', '#a9c9ea', '#eef4fa'], sun: [0.8, 0.18, 18, '#ffffff'], far: [{ c: '#bccfe2', par: 0.15, base: 150, amp: 130, ty: 'peak', p: 0.4 }, { c: '#8fa8c6', par: 0.38, base: 90, amp: 110, ty: 'peak', p: 2.2 }], gnd: ['#eef3f8', '#8e9cad'], edge: '#ffffff', deco: 'pine', bird: '#3a3040', cloud: 1 } },
    { id: 'storm', name: '천둥 구름', sub: '먹구름 속은 하강 기류! 번개를 피해 돌아가요', len: 2300,
      gnd: [[0, 20], [200, 30], [400, 18], [600, 45], [800, 25], [1000, 40], [1200, 22], [1400, 50], [1600, 30], [1800, 45], [2000, 25], [2200, 30], [2300, 22], [3100, 22]],
      zones: [{ x: 0, b: [[100, 10], [200, 28], [300, 16], [1e9, -10]] }, { x: 800, b: [[90, -6], [190, 18], [300, 30], [1e9, 14]] }, { x: 1600, b: [[110, 22], [220, 12], [320, 28], [1e9, 8]] }],
      gates: [[400, 60, 160], [900, 200, 300], [1300, 110, 210], [1750, 230, 330], [2120, 90, 190]],
      storms: [[620, 160, 55], [1150, 270, 60], [1500, 130, 50], [1950, 300, 55]], birds: [[1260, 340, 60, 25, 0.5]], therm: [],
      pal: { sky: ['#2b2840', '#4f4a66', '#8c8296'], sun: null, far: [{ c: '#423d56', par: 0.17, base: 60, amp: 40, ty: 'hill', p: 0.7 }, { c: '#36323f', par: 0.4, base: 40, amp: 30, ty: 'hill', p: 2.5 }], gnd: ['#56634c', '#2c3328'], edge: '#76845f', deco: 'dead', bird: '#1a1620', cloud: 0 } },
    { id: 'desert', name: '사막 협곡', sub: '절벽 같은 바위산과 아지랑이 열기류', len: 2400,
      gnd: [[0, 20], [250, 22], [300, 140], [480, 145], [530, 25], [800, 20], [850, 170], [1000, 172], [1050, 30], [1300, 25], [1350, 120], [1420, 125], [1470, 30], [1750, 25], [1800, 190], [1950, 190], [2000, 35], [2400, 25], [3200, 25]],
      zones: [{ x: 0, b: [[110, 28], [220, 12], [330, 24], [1e9, -8]] }, { x: 1200, b: [[120, 26], [230, -6], [330, 26], [1e9, 14]] }],
      gates: [[400, 180, 280], [680, 60, 160], [930, 205, 305], [1200, 60, 160], [1600, 180, 280], [2150, 70, 170]],
      storms: [], birds: [[1880, 290, 50, 28, 0.55]], therm: [[180, 40, 260, 1.2], [690, 45, 280, 1.2], [1190, 45, 260, 1.1], [1640, 45, 300, 1.2]],
      pal: { sky: ['#4f9ad6', '#a9d3ec', '#ffe1a8'], sun: [0.7, 0.16, 24, '#fffbe6'], far: [{ c: '#e8b58d', par: 0.16, base: 80, amp: 70, ty: 'mesa', p: 0.3 }, { c: '#cf8458', par: 0.4, base: 50, amp: 60, ty: 'mesa', p: 1.9 }], gnd: ['#e8a660', '#a65a2e'], edge: '#f7cb88', deco: 'cactus', bird: '#3a2a20', cloud: 0.7 } },
    { id: 'isle', name: '바닷가 섬', sub: '바다 위 낮은 바람은 거꾸로 불어요. 갈매기 조심!', len: 2400,
      gnd: [[0, 40], [150, 45], [260, -20], [600, -20], [680, 60], [760, 90], [840, 50], [920, -20], [1250, -20], [1320, 120], [1400, 150], [1480, 70], [1560, -20], [1900, -20], [1980, 40], [2100, 50], [2400, 45], [3200, 45]],
      zones: [{ x: 0, b: [[70, -12], [170, 24], [270, 14], [1e9, 30]] }, { x: 1200, b: [[80, 20], [180, -8], [290, 28], [1e9, 10]] }],
      gates: [[450, 40, 140], [780, 160, 260], [1100, 270, 370], [1420, 200, 300], [1750, 40, 140], [2150, 140, 240]],
      storms: [], birds: [[600, 120, 70, 20, 0.6], [1700, 230, 60, 25, 0.5]], therm: [],
      pal: { sky: ['#3fa6d8', '#9fdcef', '#e9fbff'], sun: [0.3, 0.2, 22, '#fffbe6'], far: [{ c: '#94cfd9', par: 0.15, base: 0, amp: 46, ty: 'isle', p: 0.9 }], gnd: ['#a4cc6a', '#6f8a46'], edge: '#efdca2', deco: 'palm', bird: '#ffffff', sea: ['#2aa3c4', '#0f5f80'], cloud: 1 } },
    { id: 'dusk', name: '노을 마을', sub: '굴뚝 열기류와 언덕 위 풍차 마을', len: 2300,
      gnd: [[0, 25], [200, 30], [400, 60], [550, 40], [700, 30], [900, 55], [1050, 110], [1200, 170], [1330, 100], [1450, 40], [1650, 60], [1800, 35], [2000, 50], [2150, 30], [2300, 28], [3100, 28]],
      zones: [{ x: 0, b: [[120, 14], [190, -6], [280, 26], [1e9, 16]] }, { x: 900, b: [[100, 24], [190, -6], [300, 20], [1e9, 10]] }, { x: 1700, b: [[90, 8], [190, 28], [300, 16], [1e9, -10]] }],
      gates: [[350, 230, 330], [750, 55, 150], [1150, 200, 300], [1550, 250, 350], [1950, 140, 240]],
      storms: [], birds: [[850, 260, 60, 30, 0.5], [1800, 120, 70, 25, 0.55]], therm: [[500, 35, 220, 1], [1500, 40, 240, 1]],
      pal: { sky: ['#3a2a5e', '#c4607a', '#ffc07a'], sun: [0.62, 0.66, 34, '#ffd27a'], far: [{ c: '#7a4a6e', par: 0.16, base: 60, amp: 45, ty: 'hill', p: 1.5 }, { c: '#563350', par: 0.4, base: 30, amp: 30, ty: 'town', p: 0.2 }], gnd: ['#6f7c4c', '#3d4430'], edge: '#a7b06e', deco: 'house', bird: '#2a1a2a', cloud: 0.8 } },
  ];

  const TER = {};
  function terrainOf(ci) { // terrain sampled every 4 units
    if (TER[ci]) return TER[ci];
    const C = COURSES[ci], Pt = C.gnd, n = Math.ceil((C.len + 900) / 4) + 2, a = new Float32Array(n);
    let k = 0;
    for (let i = 0; i < n; i++) {
      const x = i * 4;
      while (k < Pt.length - 2 && Pt[k + 1][0] <= x) k++;
      const p = Pt[k], q = Pt[k + 1] || p;
      const u = q[0] > p[0] ? clamp((x - p[0]) / (q[0] - p[0]), 0, 1) : 0;
      a[i] = p[1] + (q[1] - p[1]) * (1 - Math.cos(Math.PI * u)) / 2;
    }
    return (TER[ci] = a);
  }
  function groundRaw(W, x) {
    const a = W.ter; let f = x / 4; if (f < 0) f = 0;
    const i = Math.floor(f); if (i >= a.length - 1) return a[a.length - 1];
    return a[i] + (a[i + 1] - a[i]) * (f - i);
  }
  const ground = (W, x) => Math.max(0, groundRaw(W, x)); // the sea surface is 0
  const foot = (W, x) => Math.max(ground(W, x - 6), ground(W, x), ground(W, x + 6)); // basket footprint
  function floorAhead(W, x0, x1) { let m = 0; for (let x = x0 - 8; x <= x1; x += 8) m = Math.max(m, ground(W, x)); return Math.max(m, ground(W, x1 + 6)); }

  function bandWind(B, y, t, zi) {
    let i = 0; while (i < B.length - 1 && y > B[i][0]) i++;
    let v = B[i][1];
    const BW = 14;
    if (i < B.length - 1) { const d = B[i][0] - y; if (d < BW) v = mix(v, B[i + 1][1], sm((BW - d) / BW) * 0.5); }
    if (i > 0) { const d = y - B[i - 1][0]; if (d < BW) v = mix(v, B[i - 1][1], sm((BW - d) / BW) * 0.5); }
    return v * WS * (1 + 0.09 * Math.sin(t * 0.41 + i * 1.9 + zi * 2.3));
  }
  function zoneAt(C, x) { const Z = C.zones; let zi = 0; while (zi < Z.length - 1 && x >= Z[zi + 1].x) zi++; return zi; }
  /* wind (u/s, + = toward the finish) at x for the envelope altitude y */
  function windAt(W, x, y, t) {
    const Z = W.C.zones, zi = zoneAt(W.C, x), BL = 70;
    let v = bandWind(Z[zi].b, y, t, zi);
    if (zi < Z.length - 1) { const d = Z[zi + 1].x - x; if (d < BL) v = mix(v, bandWind(Z[zi + 1].b, y, t, zi + 1), sm((BL - d) / BL) * 0.5); }
    if (zi > 0) { const d = x - Z[zi].x; if (d < BL) v = mix(v, bandWind(Z[zi - 1].b, y, t, zi - 1), sm((BL - d) / BL) * 0.5); }
    return v;
  }
  /* storms (down-draft, wind dies) and thermals (free lift) at the envelope */
  function envAt(W, x, yc, out) {
    let ay = 0, wk = 1, inS = 0;
    for (const s of W.C.storms) {
      const dx = (x - s[0]) / s[2], dy = (yc - s[1]) / (s[2] * 0.62), d2 = dx * dx + dy * dy;
      if (d2 < 1) { ay -= 52 * (1 - d2 * 0.4); wk = Math.min(wk, 0.4); inS = 1; }
      else if (Math.abs(dx) < 0.7 && yc < s[1]) ay -= 18 * (1 - Math.abs(dx) / 0.7); // rain shaft below
    }
    for (const q of W.C.therm) {
      const dx = Math.abs(x - q[0]) / q[1];
      if (dx < 1 && yc < q[2]) ay += 24 * q[3] * Math.sqrt(1 - dx) * Math.min(1, (q[2] - yc) / 50);
    }
    out.ay = ay; out.wk = wk; out.s = inS; return out;
  }
  function birdPos(W, k, t, out) {
    const f = W.C.birds[k], p = k * 1.7 + f[0] * 0.01;
    out[0] = f[0] + f[2] * Math.sin(f[4] * t + p); out[1] = f[1] + f[3] * Math.sin(2 * f[4] * t + p);
    out[2] = f[2] * f[4] * Math.cos(f[4] * t + p);
    return out;
  }

  function newWorld(ci, n) {
    const C = COURSES[clamp(ci | 0, 0, COURSES.length - 1)];
    const W = { C, ci: clamp(ci | 0, 0, COURSES.length - 1), ter: terrainOf(clamp(ci | 0, 0, COURSES.length - 1)), t: 0, b: [] };
    for (let s = 0; s < n; s++) {
      const g = foot(W, START_X);
      W.b.push({ seat: s, x: START_X, y: g, vx: 0, vy: 0, h: 0.42, gr: 1, gi: 0, gm: 0, pen: 0, fin: 0, done: 0, bc: 0, bk: 0, wt: 0, burn: 0, vent: 0, st: 0 });
    }
    return W;
  }
  const EO = { ay: 0, wk: 1, s: 0 };
  /* one balloon, h seconds. inp = {b: burner 0/1, v: vent 0/1}. Pure & deterministic (shared by host, guest prediction, AI look-ahead) */
  function stepBalloon(W, b, inp, h, hooks) {
    const burn = !!(inp && inp.b) && !b.done, vent = !!(inp && inp.v) && !b.done;
    b.burn = burn ? 1 : 0; b.vent = vent ? 1 : 0;
    if (burn) b.h += BURN * h;
    b.h -= (COOL * b.h + (vent ? VENT : 0) + (b.done ? 0.2 : 0)) * h;
    b.h = clamp(b.h, 0, 1);
    const yc = b.y + ENV_DY;
    envAt(W, b.x, yc, EO);
    b.st = EO.s;
    let ay = G * (b.h - NEUT) - DRAG * b.vy + EO.ay;
    if (b.y > CEIL) ay -= (b.y - CEIL) * 1.0;
    b.vy = clamp(b.vy + ay * h, -VMAXY, VMAXY);
    const w = windAt(W, b.x, yc, W.t) * EO.wk;
    if (b.gr) b.vx += (w * 0.12 - b.vx) * Math.min(1, 5 * h);
    else b.vx += (w - b.vx) * Math.min(1, XREL * h);
    if (b.bc > 0) b.bc -= h;
    if (b.wt > 0) b.wt -= h;
    let nx = b.x + b.vx * h, ny = b.y + b.vy * h;
    if (ny > CEIL_HARD) { ny = CEIL_HARD; if (b.vy > 0) b.vy = 0; }
    if (nx < 0) { nx = 0; if (b.vx < 0) b.vx = 0; }
    const gN = foot(W, nx);
    if (gN > b.y + 2.5 && gN > ny) { // a slope or cliff higher than the basket: blocked sideways
      if (Math.abs(b.vx) > 3 && b.wt <= 0 && hooks && hooks.wall) hooks.wall(b);
      nx = b.x; b.vx = -b.vx * 0.15; b.wt = 0.6;
    }
    const g = foot(W, nx);
    b.gr = 0;
    if (ny <= g) {
      if (b.vy < -9 && hooks && hooks.land) hooks.land(b, -b.vy, groundRaw(W, nx) < 0);
      ny = g; if (b.vy < 0) b.vy = 0; b.gr = 1;
    }
    b.x = nx; b.y = ny;
  }
  const BP = [0, 0, 0];
  function stepWorld(W, inputs, hooks) {
    W.t += H;
    const B = W.b, C = W.C;
    for (const b of B) stepBalloon(W, b, inputs && inputs[b.seat], H, hooks);
    // envelopes bump softly (after the launch)
    if (W.t > GHOST_T) for (let i = 0; i < B.length; i++) {
      const a = B[i]; if (a.done || a.gr) continue;
      for (let j = i + 1; j < B.length; j++) {
        const c = B[j]; if (c.done || c.gr) continue;
        let dx = c.x - a.x, dy = c.y - a.y, d = Math.hypot(dx, dy);
        if (d >= ENV_R * 2) continue;
        if (d < 1e-4) { dx = 0; dy = 1; d = 1; }
        const nx = dx / d, ny = dy / d, ov = (ENV_R * 2 - d) * 0.5;
        a.x -= nx * ov; a.y -= ny * ov; c.x += nx * ov; c.y += ny * ov;
        if (a.x < 0) a.x = 0; if (c.x < 0) c.x = 0;
        const vn = (c.vx - a.vx) * nx + (c.vy - a.vy) * ny;
        if (vn < 0) {
          const jm = -1.5 * vn / 2;
          a.vx -= jm * nx; a.vy -= jm * ny; c.vx += jm * nx; c.vy += jm * ny;
          if (-vn > 5 && hooks && hooks.bump) hooks.bump(a, c, -vn);
        }
      }
    }
    // bird flocks
    for (let k = 0; k < C.birds.length; k++) {
      birdPos(W, k, W.t, BP);
      for (const b of B) {
        if (b.done || b.bc > 0) continue;
        if (Math.hypot(b.x - BP[0], b.y + ENV_DY - BP[1]) < ENV_R + 12) {
          b.vx = Math.min(b.vx, 0) - 9; b.vy -= 10; b.h = Math.max(0, b.h - 0.06); b.bc = 2.5; b.bk = (b.bk + 1) % 100;
          if (hooks && hooks.bird) hooks.bird(b, k);
        }
      }
    }
    // gates and the finish
    for (const b of B) {
      if (b.done) continue;
      while (b.gi < C.gates.length && b.x >= C.gates[b.gi][0]) {
        const g = C.gates[b.gi], yc = b.y + ENV_DY, ok = yc >= g[1] - 3 && yc <= g[2] + 3;
        if (!ok) { b.pen++; b.gm |= 1 << b.gi; }
        b.gi++;
        if (hooks && hooks.gate) hooks.gate(b, ok, b.gi - 1);
      }
      if (b.x >= C.len) {
        b.done = 1; b.fin = Math.round(W.t * 1000) + b.pen * PEN * 1000;
        if (hooks && hooks.finish) hooks.finish(b);
      }
    }
  }
  function ranking(W) {
    const a = W.b.slice();
    a.sort((p, q) => (p.done && q.done ? p.fin - q.fin || p.seat - q.seat : p.done ? -1 : q.done ? 1 : q.x - p.x || p.seat - q.seat));
    return a;
  }

  /* ----- AI ----- */
  const AIC = {
    1: { sinkB: 0, rate: 0.3, hor: 0.7, band: 14, look: 3.2, clear: 22, chg: 0.06, noise: 7, gk: 0.75, gpad: 0.5, near: false, vent: 0, gnoise: 0.3, replan: 1.6, fumble: 0.05 },
    2: { sinkB: 14, rate: 0.17, hor: 1.7, band: 9, look: 5, clear: 30, chg: 0.035, noise: 4, gk: 1.3, gpad: 2.0, near: false, vent: 40, gnoise: 0.08, replan: 0.9, fumble: 0 },
    3: { sinkB: 24, rate: 0.07, hor: 2.3, band: 5, look: 7.5, clear: 26, chg: 0.012, noise: 0.5, gk: 1.0, gpad: 0.7, near: true, vent: 18, gnoise: 0, replan: 0.8, fumble: 0 },
  };
  const GH = { seat: -1, x: 0, y: 0, vx: 0, vy: 0, h: 0, gr: 0, bc: 0, wt: 0, done: 0, burn: 0, vent: 0, st: 0 };
  const INB = { b: 1, v: 0 }, IN0 = { b: 0, v: 0 }, INV = { b: 0, v: 1 };
  /* envelope altitude after T seconds holding (burn) — coarse steps, no hooks */
  function predictYc(W, b, burn, T, dt) {
    GH.x = b.x; GH.y = b.y; GH.vx = b.vx; GH.vy = b.vy; GH.h = b.h; GH.gr = b.gr; GH.bc = 0; GH.wt = 1; GH.done = 0;
    const inp = burn ? INB : IN0, t0 = W.t;
    for (let t = 0; t < T - 1e-6; t += dt) { stepBalloon(W, GH, inp, dt, null); W.t += dt; }
    W.t = t0;
    return GH.y + ENV_DY;
  }
  function cruise(W, b, C, lv) {
    const yc = b.y + ENV_DY, vxe = Math.max(6, b.vx), look = Math.max(90, vxe * C.look);
    const floor = floorAhead(W, b.x, b.x + look) + ENV_DY + C.clear;
    const gate = W.C.gates[b.gi];
    let best = Math.max(yc, floor), bs = -1e9;
    for (let y = Math.max(floor, 40); y <= 375; y += 12) {
      let sc = 0;
      for (let k = 1; k <= 4; k++) sc += windAt(W, b.x + look * k / 4, y, W.t);
      sc /= 4;
      for (const s of W.C.storms) if (s[0] + s[2] > b.x - 10 && s[0] - s[2] < b.x + look * 1.2 && Math.abs(y - s[1]) < s[2] * 0.62 + 24) sc -= lv >= 2 ? 30 : 8;
      if (lv >= 2) for (const f of W.C.birds) if (f[0] + f[2] + 20 > b.x && f[0] - f[2] < b.x + look && Math.abs(y - f[1]) < f[3] + 28) sc -= lv >= 3 ? 10 : 5;
      if (gate && lv >= 2) {
        const reach = (gate[0] - b.x) / vxe, gc = (gate[1] + gate[2]) / 2;
        sc -= Math.abs(y - gc) * (lv >= 3 ? 0.05 : 0.025) * clamp(1.5 - reach / 10, 0, 1.5);
      }
      sc -= Math.abs(y - yc) * C.chg;
      sc += (Math.random() * 2 - 1) * C.noise;
      if (sc > bs) { bs = sc; best = y; }
    }
    return best;
  }
  /* where to cross the gate: lv1 the centre (± its own wobble), lv2/3 the best-wind height inside the window */
  function gateTarget(W, b, g, C, lv, mem) {
    const half = (g[2] - g[1]) / 2, gc = (g[1] + g[2]) / 2, yc = b.y + ENV_DY;
    if (lv <= 1) return gc + (mem.gn || 0);
    if (mem.gtI === b.gi && mem.gtT > W.t) return mem.gtY;
    const best = gateBest(W, g, Math.min(b.x + 40, g[0]), yc, lv);
    mem.gtI = b.gi; mem.gtT = W.t + 1; mem.gtY = best;
    return best;
  }
  function gateBest(W, g, xs, yc, lv) {
    const half = (g[2] - g[1]) / 2, lo = g[1] + half * (lv >= 3 ? 0.4 : 0.5), hi = g[2] - half * (lv >= 3 ? 0.4 : 0.5);
    let best = (g[1] + g[2]) / 2, bs = -1e9;
    for (let k = 0; k <= 4; k++) {
      const y = lo + (hi - lo) * k / 4;
      const sc = windAt(W, xs, y, W.t) + windAt(W, g[0], y, W.t) - Math.abs(y - yc) * (lv >= 3 ? 0.02 : 0.05);
      if (sc > bs) { bs = sc; best = y; }
    }
    return best;
  }
  /* lv3 look-ahead: fly a plan "cruise at altitude cy, then line up for the next gates" with the real physics for T s */
  const GR = { seat: -1, x: 0, y: 0, vx: 0, vy: 0, h: 0, gr: 0, bc: 0, wt: 1, done: 0, burn: 0, vent: 0, st: 0 };
  function rollout(W, b, cy, C, T) {
    GR.x = b.x; GR.y = b.y; GR.vx = b.vx; GR.vy = b.vy; GR.h = b.h; GR.gr = b.gr; GR.wt = 1;
    const t0 = W.t, dt = 0.15, gates = W.C.gates;
    let gi = b.gi, pen = 0, inG = false, gtY = null;
    for (let t = 0; t < T; t += dt) {
      const yc = GR.y + ENV_DY, g = gates[gi];
      let tgt = cy;
      if (g) {
        if (gtY == null) gtY = gateBest(W, g, g[0] - 40, yc, 3);
        const reach = (g[0] - GR.x) / Math.max(6, GR.vx), need = Math.abs(gtY - yc) / 17 + 1.3;
        if (inG || reach < need * C.gk + C.gpad) { inG = true; tgt = gtY; }
      }
      const a = G * (GR.h * 0.85 - NEUT) - DRAG * GR.vy, pred = yc + GR.vy * 1.6 + a * 0.75;
      const inp = pred < tgt - 5 ? INB : pred > tgt + 30 ? INV : IN0;
      const px = GR.x;
      stepBalloon(W, GR, inp, dt, null); W.t += dt;
      if (g && px < g[0] && GR.x >= g[0]) { const y2 = GR.y + ENV_DY; if (y2 < g[1] - 3 || y2 > g[2] + 3) pen++; gi++; inG = false; gtY = null; }
      if (GR.gr) pen += 0.02;
    }
    W.t = t0;
    return GR.x - pen * 120 + windAt(W, GR.x, GR.y + ENV_DY, t0 + T) * 2;
  }
  function planCruise(W, b, C) {
    const look = Math.max(90, Math.max(6, b.vx) * 3);
    const floor = floorAhead(W, b.x, b.x + look) + ENV_DY + 18;
    let best = b.y + ENV_DY, bs = -1e9;
    for (let y = Math.max(floor, 40); y <= 375; y += 18) {
      const sc = rollout(W, b, y, C, 12);
      if (sc > bs) { bs = sc; best = y; }
    }
    return best;
  }
  function aiThink(W, b, mem, lv, dt) {
    const inp = mem.inp || (mem.inp = { b: 0, v: 0 });
    if (b.done) { inp.b = 0; inp.v = 0; return inp; }
    mem.t = (mem.t || 0) - dt;
    if (mem.t > 0) return inp;
    const C = AIC[lv] || AIC[2];
    mem.t = C.rate * (0.7 + Math.random() * 0.6);
    const yc = b.y + ENV_DY, vxe = Math.max(6, b.vx);
    const gate = W.C.gates[b.gi];
    if (mem.gi !== b.gi) { mem.gi = b.gi; mem.gn = gate ? (Math.random() * 2 - 1) * C.gnoise * (gate[2] - gate[1]) / 2 : 0; }
    let tgt = null;
    if (gate) {
      const gt = gateTarget(W, b, gate, C, lv, mem);
      const need = Math.abs(gt - yc) / 17 + 1.3, reach = (gate[0] - b.x) / vxe;
      // once lined up for a gate, stay committed (a headwind on the way down must not make it give up and climb away)
      if (reach < need * C.gk + C.gpad || (mem.gm === b.gi && gate[0] - b.x < 260)) { tgt = Math.max(gt, floorAhead(W, b.x, gate[0] + 15) + ENV_DY + 10); mem.gm = b.gi; }
    }
    // not getting anywhere for a while (stuck in a headwind): give up on the gate approach and find a good layer first
    if (mem.bx == null || b.x > mem.bx + 25) { mem.bx = b.x; mem.bt = W.t; }
    if (W.t - mem.bt > 9) { mem.free = W.t + 4; mem.bt = W.t; mem.gm = -1; }
    if (mem.free > W.t) tgt = null;
    if (tgt == null) {
      if (!(mem.pt > W.t) || mem.cr == null) { mem.cr = lv >= 3 ? planCruise(W, b, C) : cruise(W, b, C, lv); mem.pt = W.t + C.replan * (0.8 + Math.random() * 0.4); }
      tgt = Math.max(mem.cr, floorAhead(W, b.x, b.x + Math.max(60, vxe * C.look * 0.6)) + ENV_DY + C.clear * 0.7);
    }
    tgt = Math.min(tgt, 380);
    mem.tgt = tgt;
    // short look-ahead holds the height, the long one (with the sink a coasting balloon always has) brakes a descent early
    const pS = predictYc(W, b, false, 0.7, 0.1), pOff = C.hor > 0.75 ? predictYc(W, b, false, C.hor, 0.1) : pS, bl = C.band + C.sinkB;
    let burn = inp.b;
    if (pS < tgt - C.band || pOff < tgt - bl) burn = 1;
    else if (pS > tgt - C.band * 0.3 && pOff > tgt - bl * 0.5) burn = 0;
    if (b.y < floorAhead(W, b.x, b.x + Math.max(25, b.vx * 1.6)) + 6) burn = 1; // terrain right ahead
    let vent = 0;
    if (C.vent && !burn && pOff > tgt + C.vent && b.vy > -14) vent = 1;
    if (C.fumble && Math.random() < C.fumble) burn = burn ? 0 : 1;
    inp.b = burn; inp.v = vent;
    return inp;
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    let co = +o.course;
    const picked = co >= 0 && co < COURSES.length;
    if (!picked) co = U.rand(COURSES.length);
    return { rid: 1 + U.rand(99999), n: players.length, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), co, rnd: picked ? 0 : 1, ph: 'count', fin: [], res: null };
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const C = COURSES[clamp(s.co | 0, 0, COURSES.length - 1)];
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + (r[1] > 0 ? fmtT(r[1]) + (r[2] ? ' (벌점 ' + r[2] + ')' : '') : '미도착 ' + (r[3] | 0) + '%'));
    const w = s.res[0][0];
    return { winners: [w], title: nm(w) + ' 1위!', text: C.name + (s.rnd ? ' (무작위)' : '') + '\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const HUD_H = 46, HUD_HL = 32, CTL_H = 108;

  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function rgbOf(hex) { const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return [200, 200, 200]; const n = parseInt(m[1], 16); return [n >> 16, (n >> 8) & 255, n & 255]; }
  function hexA(hex, a) { const c = rgbOf(hex); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function shade(hex, k) { const c = rgbOf(hex), f = (v) => Math.round(k >= 0 ? v + (255 - v) * k : v * (1 + k)); return 'rgb(' + f(c[0]) + ',' + f(c[1]) + ',' + f(c[2]) + ')'; }

  /* envelope sprite (local units: centre 0,0; top −16.5, mouth +17) */
  function envPath(g) { g.beginPath(); g.moveTo(-4.6, 17); g.bezierCurveTo(-9, 11, -15.5, 6, -15.5, -1); g.arc(0, -1, 15.5, Math.PI, 0); g.bezierCurveTo(15.5, 6, 9, 11, 4.6, 17); g.closePath(); }
  function envHW(y) { if (y < -1) return Math.sqrt(Math.max(0, 15.5 * 15.5 - (y + 1) * (y + 1))); const t = (y + 1) / 18; return 15.5 - 10.9 * Math.pow(t, 1.7); }
  function makeEnvelope(col, pat, k) {
    const c = document.createElement('canvas');
    c.width = Math.max(8, Math.ceil(34 * k)); c.height = Math.max(8, Math.ceil(38 * k));
    const g = c.getContext('2d');
    g.scale(c.width / 34, c.height / 38); g.translate(17, 18);
    const ivory = '#f6ecd6', dark = shade(col, -0.3), light = shade(col, 0.3);
    envPath(g); g.save(); g.clip();
    g.fillStyle = col; g.fillRect(-17, -18, 34, 38);
    const gore = (i, fill) => { // fill the i-th of 8 vertical gores
      const u0 = Math.sin((-1 + i / 4) * Math.PI / 2), u1 = Math.sin((-1 + (i + 1) / 4) * Math.PI / 2);
      g.beginPath();
      for (let y = -17; y <= 18; y += 1.5) g.lineTo(u0 * envHW(y) * 1.02, y);
      for (let y = 18; y >= -17; y -= 1.5) g.lineTo(u1 * envHW(y) * 1.02, y);
      g.closePath(); g.fillStyle = fill; g.fill();
    };
    if (pat === 0) { for (let i = 1; i < 8; i += 2) gore(i, ivory); }
    else if (pat === 1) {
      for (let i = 1; i < 8; i += 2) gore(i, dark);
      g.fillStyle = ivory; g.beginPath(); g.moveTo(-17, 1);
      for (let x = -17; x <= 17; x += 3.4) { g.lineTo(x + 1.7, -2.5); g.lineTo(x + 3.4, 1); }
      g.lineTo(17, 5); for (let x = 17; x >= -17; x -= 3.4) { g.lineTo(x - 1.7, 8.5); g.lineTo(x - 3.4, 5); } g.closePath(); g.fill();
    } else if (pat === 2) {
      g.fillStyle = ivory; g.fillRect(-17, -18, 34, 7.5);
      g.fillStyle = '#e3ae45'; g.fillRect(-17, -10.5, 34, 1.2);
      g.fillStyle = light; g.fillRect(-17, 2, 34, 7);
      g.fillStyle = dark; for (let x = -15; x <= 15; x += 5) { g.beginPath(); g.moveTo(x, 2.5); g.lineTo(x + 2.5, 5.5); g.lineTo(x, 8.5); g.lineTo(x - 2.5, 5.5); g.closePath(); g.fill(); }
    } else {
      for (let y = -18, k2 = 0; y < 20; y += 4.4, k2++) { g.fillStyle = k2 % 3 === 1 ? ivory : k2 % 3 === 2 ? dark : col; g.fillRect(-17, y, 34, 4.4); }
    }
    // gore seams
    g.strokeStyle = 'rgba(40,24,30,.28)'; g.lineWidth = 0.35;
    for (let i = 1; i < 8; i++) { const u = Math.sin((-1 + i / 4) * Math.PI / 2); g.beginPath(); for (let y = -17; y <= 18; y += 1.5) g.lineTo(u * envHW(y), y); g.stroke(); }
    // light & shade
    const hl = g.createRadialGradient(-6, -8, 1, -4, -4, 20); hl.addColorStop(0, 'rgba(255,255,255,.42)'); hl.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = hl; g.fillRect(-17, -18, 34, 38);
    const sh = g.createLinearGradient(-16, 0, 16, 0); sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(0.55, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(20,10,30,.38)');
    g.fillStyle = sh; g.fillRect(-17, -18, 34, 38);
    const bt = g.createLinearGradient(0, 4, 0, 18); bt.addColorStop(0, 'rgba(20,10,30,0)'); bt.addColorStop(1, 'rgba(20,10,30,.3)');
    g.fillStyle = bt; g.fillRect(-17, -18, 34, 38);
    g.restore();
    envPath(g); g.strokeStyle = 'rgba(30,18,26,.75)'; g.lineWidth = 0.7; g.stroke();
    g.fillStyle = '#3a2a22'; rrect(g, -4.8, 16.6, 9.6, 2.3, 0.8); g.fill();
    return c;
  }
  function makePuff(dark) {
    const c = document.createElement('canvas'); c.width = 128; c.height = 72;
    const g = c.getContext('2d');
    const blobs = [[40, 44, 24], [64, 34, 30], [90, 44, 22], [24, 52, 16], [106, 52, 15], [62, 52, 26]];
    for (const p of blobs) {
      const rg = g.createRadialGradient(p[0] - p[2] * 0.3, p[1] - p[2] * 0.4, p[2] * 0.1, p[0], p[1], p[2]);
      if (dark) { rg.addColorStop(0, 'rgba(120,112,140,1)'); rg.addColorStop(0.7, 'rgba(70,64,88,1)'); rg.addColorStop(1, 'rgba(50,46,64,0)'); }
      else { rg.addColorStop(0, 'rgba(255,255,255,1)'); rg.addColorStop(0.65, 'rgba(244,240,250,.95)'); rg.addColorStop(1, 'rgba(225,225,240,0)'); }
      g.fillStyle = rg; g.beginPath(); g.arc(p[0], p[1], p[2], 0, 7); g.fill();
    }
    return c;
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let st = null, key = null, W = null, phase = 'wait', cd = 0, acc = 0, lay = null, camX = 0, camInit = false;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const me = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const isMine = (s) => s >= 0 && s === me();
    const auto = () => !!(L.debug && L.debug.autoplay);
    let aiMem = [], inputs = {}, parts = [], floats = [], shake = 0, lastSfx = 0, hintT = 0, doneSent = false, firstFin = null, humansDoneAt = null;
    let banner = null, flash = 0, seen = [], sprites = [], puffW = null, puffD = null, skyC = null, skyKey = '';
    const locIn = { b: 0, v: 0 };
    const autoMem = { inp: { b: 0, v: 0 } }; // test autopilot (Lounge.debug.autoplay) for the seat on this phone
    // network
    let pubT = 0, hsQ = 0, inQ = 0, lastSig = '', inT = 0, snaps = [], lastQ = -1, rtt = 0.15;
    const sendT = {}, iqOf = {}, remIn = {};

    function curKey() { return st ? st.rid + '.' + st.co : null; }
    function startRace() {
      if (!(st.co >= 0)) { W = null; return; }
      W = newWorld(st.co, st.n);
      aiMem = W.b.map(() => ({ inp: { b: 0, v: 0 } }));
      seen = W.b.map(() => ({ gi: 0, pen: 0, bk: 0, done: 0 }));
      for (const k in autoMem) if (k !== 'inp') delete autoMem[k];
      inputs = {}; parts = []; floats = []; snaps = []; lastQ = -1; acc = 0; doneSent = false; firstFin = null; humansDoneAt = null; banner = null;
      phase = st.ph === 'race' ? 'race' : st.ph === 'done' ? 'done' : 'count';
      cd = phase === 'count' ? INTRO + COUNT : 0;
      camInit = false;
      if (me() >= 0) hintT = 7;
      layout();
    }

    /* ----- layout: the whole altitude range fits the height; the camera scrolls sideways -----
       landscape (the main layout): one thin HUD row, the scene uses the full height and width, the 내리기 pad sits at the
       left edge and the 버너 pad at the right edge (thumbs). Portrait (fallback when the phone can't rotate): the old layout
       with a control bar along the bottom. */
    function layout() {
      const w = cv.w, h = cv.h, land = w > h * 1.15, mine = me() >= 0;
      const top = land ? HUD_HL : HUD_H, ctl = mine && !land ? CTL_H : 0, bot = h - ctl - (land ? 2 : 0);
      const s = Math.max(0.3, (bot - top - 6) / (Y_HI - Y_LO));
      let PD = null, cl = 40, cr = w - 8;
      if (mine && land) {
        const pw = Math.round(clamp(w * 0.13, 92, 124)), ph = Math.round(clamp((h - top) * 0.58, 120, 200)), y = h - ph - 10;
        const burn = { x: w - 10 - pw, y, w: pw, h: ph };
        PD = { vent: { x: 44, y, w: pw, h: ph }, burn, gauge: { x: burn.x - 24, y: y + 10, w: 16, h: ph - 20 } };
        cl = 44 + pw + 6; cr = burn.x - 30;
      } else if (mine) {
        const y = h - ctl + 12, bh = ctl - 22;
        PD = { vent: { x: 10, y, w: 78, h: bh }, gauge: { x: 96, y, w: 18, h: bh }, burn: { x: 122, y, w: w - 132, h: bh } };
      }
      lay = { s, top, bot, ctl, land, P: PD, cl, cr, camL: land ? cl + (cr - cl) * 0.3 : w * 0.34, viewW: w / s };
      skyKey = '';
      sprites = [];
      if (W) {
        const k = s * cv.dpr;
        for (let i = 0; i < W.b.length; i++) sprites[i] = makeEnvelope(P(i).color || '#e3ae45', i % 4, k);
      }
    }
    cv.onresize = layout;
    const X = (x) => (x - camX) * lay.s, Y = (y) => lay.bot - (y - Y_LO) * lay.s;

    /* ----- input: hold anywhere = burner; the 내리기 (vent) pad bottom-left ----- */
    const ptrs = new Map(), keys = {};
    const pads = () => lay.P;
    function refresh() {
      let b = 0, v = 0;
      for (const p of ptrs.values()) { if (p === 'v') v = 1; else b = 1; }
      if (keys.b) b = 1; if (keys.v) v = 1;
      if (b && !locIn.b && phase === 'race') { sfx('whoosh', 140); api.buzz(8); }
      if (v && !locIn.v && phase === 'race') { sfx('pop', 140); api.buzz(6); }
      locIn.b = b; locIn.v = v;
    }
    function onDown(e) {
      if (me() < 0 || !W) return;
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      const p = cv.local(e), R = lay.P ? lay.P.vent : null;
      const inV = !!R && p.x <= R.x + R.w + 6 && p.y >= R.y - 10;
      ptrs.set(e.pointerId, inV ? 'v' : 'b');
      hintT = Math.min(hintT, 2);
      refresh();
    }
    function onUp(e) { if (ptrs.delete(e.pointerId)) refresh(); }
    // keyboard / gamepad (api.input, rebindable in 「⌨ 조작 설정」): hold = burner / valve, same as holding the pads
    const offIn = api.input ? api.input.on((type, id) => {
      if (id !== 'burn' && id !== 'vent') return;
      keys[id === 'burn' ? 'b' : 'v'] = type === 'down';
      if (me() < 0) return;
      if (type === 'down') hintT = Math.min(hintT, 2);
      refresh();
    }) : () => {};
    const releaseAll = () => { ptrs.clear(); keys.b = false; keys.v = false; refresh(); };
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    window.addEventListener('blur', releaseAll);

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 50)) return; lastSfx = t; api.sfx(n); }
    function puff(x, y, col, n, sp, kind) {
      for (let i = 0; i < n; i++) { const a = Math.random() * 7, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0.6 + Math.random() * 0.5, T: 1.1, c: col, k: kind || 0, r: Math.random() * 6 }); }
      if (parts.length > 240) parts.splice(0, parts.length - 240);
    }
    function addFloat(x, y, text, col, t) { floats.push({ x, y, text, col, t: t || 1.4, T: t || 1.4 }); }
    const hooks = {
      gate(b, ok, i) {
        const g = W.C.gates[i];
        if (ok) puff(g[0], (g[1] + g[2]) / 2, '#ffe08a', 10, 30, 1);
        if (!isMine(b.seat)) return;
        if (ok) { sfx('chip', 40); api.buzz(15); addFloat(b.x, b.y + 58, '통과!', '#9fe08a'); }
        else { sfx('thud', 40); api.buzz([30, 40, 30]); addFloat(b.x, b.y + 58, '놓침 +' + PEN + '초', '#ee6a55', 1.8); }
      },
      finish(b) {
        puff(b.x, b.y + ENV_DY, P(b.seat).color, 16, 40, 1);
        if (isMine(b.seat)) {
          const rk = W.b.filter((q) => q.done && q.fin < b.fin).length + 1;
          banner = { text: '도착! ' + rk + '위', sub: '기록 ' + fmtT(b.fin) + (b.pen ? ' (벌점 ' + b.pen + ')' : ''), t: 3.5 };
          api.sfx(rk === 1 ? 'win' : 'chip'); api.buzz(60);
        } else sfx('pop', 60);
        if (host() && st && st.ph === 'race') {
          const f = (st.fin || []).slice();
          if (!f.some((r) => r[0] === b.seat)) { f.push([b.seat, b.fin, b.pen]); api.setState(Object.assign({}, st, { fin: f })); }
        }
      },
      bird(b) {
        puff(b.x, b.y + ENV_DY + 8, '#f2e9d8', 9, 26, 2);
        if (isMine(b.seat)) { sfx('hit', 40); api.buzz(40); addFloat(b.x, b.y + 58, '새 떼와 쿵!', '#ffd0a0'); shake = Math.min(1, shake + 0.5); }
      },
      wall(b) { puff(b.x + 6, b.y + 3, '#c8b49a', 6, 18, 0); if (isMine(b.seat)) { sfx('thud', 80); api.buzz(20); addFloat(b.x, b.y + 58, '쿵! 더 높이', '#ffd0a0'); } },
      land(b, v, water) { puff(b.x, b.y + 1, water ? '#d8f4ff' : '#c8b49a', water ? 10 : 6, water ? 26 : 16, 0); if (isMine(b.seat)) { sfx(water ? 'pop' : 'thud', 80); api.buzz(15); } },
      bump(a, c) { if (isMine(a.seat) || isMine(c.seat)) { sfx('bounce', 80); api.buzz(12); } },
    };
    const guestHooks = { wall: hooks.wall, land: hooks.land };

    /* ----- host: race flow ----- */
    function hostFlow() {
      if (!host() || !st || !W) return;
      if (st.ph === 'count' && phase === 'race') { api.setState(Object.assign({}, st, { ph: 'race' })); return; }
      if (st.ph !== 'race' || doneSent) return;
      if (firstFin == null && W.b.some((b) => b.done)) firstFin = W.t;
      const humans = W.b.filter((b) => !P(b.seat).ai);
      if (humansDoneAt == null && humans.length && humans.every((b) => b.done)) humansDoneAt = W.t;
      const all = W.b.every((b) => b.done);
      const timeout = W.t > CAP_T || (firstFin != null && W.t - firstFin > AFTER_FIRST) || (humansDoneAt != null && W.t - humansDoneAt > AFTER_HUMANS);
      if (!all && !timeout) return;
      doneSent = true;
      const res = ranking(W).map((b) => [b.seat, b.done ? b.fin : 0, b.pen, Math.round(clamp(b.x / W.C.len, 0, 1) * 100)]);
      api.setState(Object.assign({}, st, { ph: 'done', res }));
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.b.length) || simHere(s) || !o || o.k !== key) continue;
        remIn[s] = { b: o.b ? 1 : 0, v: o.v ? 1 : 0 };
        if (fin(o.q)) iqOf[s] = o.q;
      }
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.c)) return;
      lastQ = hs.q;
      snaps.push({ at: now, c: hs.c }); if (snaps.length > 4) snaps.shift();
      if (fin(hs.t)) W.t = hs.t;
      hs.c.forEach((a, s) => {
        const b = W.b[s];
        if (!b || !Array.isArray(a)) return;
        const fl = a[5] | 0, sn = seen[s];
        b.gi = a[6] | 0; b.gm = a[7] | 0; b.pen = a[8] | 0; b.fin = +a[9] || 0; b.bk = a[10] | 0;
        const wasDone = b.done; b.done = fl & 8 ? 1 : 0;
        if (!isMine(s) || b.done) { b.burn = fl & 1; b.vent = fl & 2 ? 1 : 0; b.gr = fl & 4 ? 1 : 0; b.h = +a[4] || 0; }
        // replay the host's events
        if (sn) {
          while (sn.gi < b.gi) { const ok = !(b.gm & (1 << sn.gi)); sn.gi++; hooks.gate(b, ok, sn.gi - 1); }
          if (sn.bk !== b.bk) { sn.bk = b.bk; hooks.bird(b); }
          if (!wasDone && b.done && !sn.done) { sn.done = 1; hooks.finish(b); }
        }
        if (!isMine(s) || b.done) return;
        if (hs.iq && fin(hs.iq[s]) && sendT[hs.iq[s]]) { const sm2 = (now - sendT[hs.iq[s]]) / 1000; if (sm2 > 0 && sm2 < 2) rtt = rtt * 0.85 + sm2 * 0.15; }
        const lag = Math.min(0.25, rtt / 2);
        const tx = a[0] + a[2] * lag, ty = a[1] + a[3] * lag;
        if (Math.hypot(tx - b.x, ty - b.y) > 50) { b.x = tx; b.y = ty; b.vx = a[2]; b.vy = a[3]; b.h = +a[4] || 0; }
        else { b.x += (tx - b.x) * 0.25; b.y += (ty - b.y) * 0.25; b.vx += (a[2] - b.vx) * 0.4; b.vy += (a[3] - b.vy) * 0.3; b.h += ((+a[4] || 0) - b.h) * 0.12; }
      });
    }
    function interpOthers(now) {
      if (host() || !snaps.length || !W) return;
      const rt = now - 100;
      let A = null, B = snaps[snaps.length - 1], k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.25);
      W.b.forEach((b, s) => {
        if (isMine(s) && !b.done) return;
        const q = B.c[s], p = A ? A.c[s] : null;
        if (!Array.isArray(q)) return;
        if (p && Array.isArray(p)) { b.x = p[0] + (q[0] - p[0]) * k; b.y = p[1] + (q[1] - p[1]) * k; }
        else { b.x = q[0]; b.y = q[1]; }
        b.vx = q[2]; b.vy = q[3];
      });
    }
    function publish(rdt, now) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          const c = W.b.map((b) => [r1(b.x), r1(b.y), r1(b.vx), r1(b.vy), r2(b.h), (b.burn ? 1 : 0) | (b.vent ? 2 : 0) | (b.gr ? 4 : 0) | (b.done ? 8 : 0), b.gi, b.gm, b.pen, b.fin, b.bk]);
          api.net.hostSend({ k: key, q: hsQ, t: r2(W.t), c, iq: Object.assign({}, iqOf) });
        } else {
          const s = me();
          if (s < 0) return;
          const I = myInput();
          const sig = I.b + '|' + I.v;
          if (sig === lastSig && inT > 0) return;
          lastSig = sig; inT = 0.15;
          inQ = (inQ + 1) % 100000; sendT[inQ] = now; delete sendT[(inQ + 99900) % 100000];
          api.net.publish({ k: key, q: inQ, b: I.b, v: I.v });
        }
      } catch (e) {}
    }

    function myInput() { // the person on this phone (or the test autopilot)
      const s = me();
      if (s >= 0 && auto() && W) return aiThink(W, W.b[s], autoMem, 2, 0);
      return locIn;
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st || !W) return;
      const dt = rdt * SPD();
      if (phase === 'count') {
        const prevN = Math.ceil(cd); cd -= dt; const nowN = Math.ceil(cd);
        if (nowN !== prevN && nowN > 0 && nowN <= COUNT) api.sfx('tick');
        if (cd <= 0) { phase = 'race'; api.sfx('pop'); api.buzz(20); }
      }
      if (hintT > 0 && phase === 'race') hintT -= rdt;
      if (host()) {
        pollHost();
        if (phase === 'race' && st.ph !== 'done') {
          W.b.forEach((b, i) => {
            const p = api.players[i];
            if (!p) return;
            if (simHere(i)) {
              if (p.ai || !isMine(i)) inputs[i] = aiThink(W, b, aiMem[i], p.ai ? (p.lv || 2) : 2, dt);
              else if (auto()) inputs[i] = aiThink(W, b, autoMem, 2, dt);
              else inputs[i] = locIn;
            } else inputs[i] = remIn[i];
          });
          acc += Math.min(dt, 0.5);
          let n = 0;
          while (acc >= H && n < 60) { stepWorld(W, inputs, hooks); acc -= H; n++; }
          if (n >= 60) acc = 0;
        } else if (st.ph === 'done') { // drift on quietly behind the result sheet
          acc += Math.min(dt, 0.25); let n = 0;
          while (acc >= H && n < 30) { stepWorld(W, {}, null); acc -= H; n++; }
        }
        hostFlow();
      } else {
        pollGuest(now);
        if (phase === 'race' && st.ph === 'race') {
          W.t += dt;
          const s = me(), b = s >= 0 ? W.b[s] : null;
          if (b && !b.done) {
            if (auto()) aiThink(W, b, autoMem, 2, dt);
            let k = Math.min(dt, 0.1);
            while (k > 1e-6) { const hh = Math.min(H * 2, k); stepBalloon(W, b, myInput(), hh, guestHooks); k -= hh; }
          }
        }
        interpOthers(now);
      }
      // ambient particles: vent puffs
      for (const b of W.b) if (b.vent && Math.random() < dt * 14) parts.push({ x: b.x + (Math.random() - 0.5) * 6, y: b.y + ENV_DY + 16, vx: (Math.random() - 0.5) * 6, vy: 12 + Math.random() * 6, t: 0.7, T: 0.7, c: '#e8e2f0', k: 0, r: 0 });
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.96; p.vy = p.k === 2 ? p.vy * 0.95 - 10 * rdt : p.vy * 0.96; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      if (banner) { banner.t -= rdt; if (banner.t <= 0) banner = null; }
      shake = Math.max(0, shake - rdt * 2.5);
      flash = Math.max(0, flash - rdt * 4);
      publish(rdt, now);
    }

    /* ----- camera ----- */
    function focusBalloon() {
      const s = me();
      if (s >= 0 && W.b[s]) return W.b[s];
      const r = ranking(W);
      return r.find((b) => !b.done) || r[0];
    }
    function updateCam(rdt) {
      const b = focusBalloon(), vw = lay.viewW;
      const lead = lay.camL / lay.s; // world units between the screen's left edge and my balloon
      let tx = (b ? b.x : 0) - lead;
      tx = clamp(tx, Math.min(-20, START_X - lead), W.C.len + 420 - vw);
      if (!camInit) { camX = tx; camInit = true; } else camX += (tx - camX) * Math.min(1, rdt * 3.2);
    }

    /* ----- drawing ----- */
    function laneOff(b) {
      const g = ground(W, b.x);
      return (b.seat - (W.b.length - 1) / 2) * 30 * clamp(1 - (b.x - START_X) / 70, 0, 1) * clamp(1 - (b.y - g) / 50, 0, 1);
    }
    function buildSky() {
      const key2 = cv.w + 'x' + cv.h + ':' + W.ci + ':' + lay.ctl + ':' + lay.top;
      if (skyKey === key2 && skyC) return;
      skyKey = key2;
      const dpr = cv.dpr, c = skyC || document.createElement('canvas');
      c.width = Math.max(1, Math.round(cv.w * dpr)); c.height = Math.max(1, Math.round(cv.h * dpr));
      const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const pal = W.C.pal, gr = g.createLinearGradient(0, lay.top, 0, lay.bot);
      gr.addColorStop(0, pal.sky[0]); gr.addColorStop(0.55, pal.sky[1]); gr.addColorStop(1, pal.sky[2]);
      g.fillStyle = gr; g.fillRect(0, 0, cv.w, cv.h);
      if (W.C.id === 'storm' || W.C.id === 'dusk') { // a few early stars
        for (let i = 0; i < 40; i++) { const x = (hash32(i, 7) % 1000) / 1000 * cv.w, y = lay.top + (hash32(i, 8) % 1000) / 1000 * (lay.bot - lay.top) * 0.4; g.fillStyle = 'rgba(255,250,235,' + (0.15 + (i % 4) * 0.08) + ')'; g.fillRect(x, y, 1.3, 1.3); }
      }
      if (pal.sun) {
        const sx = cv.w * pal.sun[0], sy = lay.top + (lay.bot - lay.top) * pal.sun[1], r = pal.sun[2] * Math.max(0.8, lay.s);
        const rg = g.createRadialGradient(sx, sy, r * 0.5, sx, sy, r * 4.5); rg.addColorStop(0, hexA(pal.sun[3], 0.55)); rg.addColorStop(1, hexA(pal.sun[3], 0));
        g.fillStyle = rg; g.fillRect(0, 0, cv.w, cv.h);
        g.fillStyle = pal.sun[3]; g.beginPath(); g.arc(sx, sy, r, 0, 7); g.fill();
      }
      skyC = c;
      // ground gradient for this layout
      groundGrad = ctx.createLinearGradient(0, Y(200), 0, Y(Y_LO));
      groundGrad.addColorStop(0, pal.gnd[0]); groundGrad.addColorStop(1, pal.gnd[1]);
      seaGrad = pal.sea ? (() => { const s2 = ctx.createLinearGradient(0, Y(0), 0, Y(Y_LO)); s2.addColorStop(0, pal.sea[0]); s2.addColorStop(1, pal.sea[1]); return s2; })() : null;
      if (!puffW) { puffW = makePuff(false); puffD = makePuff(true); }
    }
    let groundGrad = null, seaGrad = null;
    function farY(Lr, xw) {
      const p = Lr.p || 0;
      let f;
      if (Lr.ty === 'peak') f = 0.7 * Math.pow(1 - Math.abs(Math.sin(xw * 0.006 + p)), 1.6) + 0.3 * (1 - Math.abs(Math.sin(xw * 0.017 + p * 2)));
      else if (Lr.ty === 'mesa') f = clamp((Math.sin(xw * 0.0055 + p) + 0.15) * 3, 0, 1) * 0.85 + 0.15 * clamp((Math.sin(xw * 0.021 + p * 3) + 0.3) * 3, 0, 1);
      else if (Lr.ty === 'isle') f = Math.max(0, Math.sin(xw * 0.004 + p) - 0.55) * 2.6 + Math.max(0, Math.sin(xw * 0.011 + p * 2) - 0.8) * 2;
      else if (Lr.ty === 'town') { const cell = Math.floor(xw / 16), hv = hash32(cell, 77); f = 0.3 + (hv % 100) / 160 + (hv % 23 === 0 ? 0.6 : 0); }
      else f = 0.5 + 0.3 * Math.sin(xw * 0.006 + p) + 0.14 * Math.sin(xw * 0.017 + p * 2) + 0.06 * Math.sin(xw * 0.041 + p * 3);
      return Lr.base + Lr.amp * f;
    }
    function drawFar() {
      const s = lay.s, w = cv.w;
      for (const Lr of W.C.pal.far) {
        ctx.beginPath(); ctx.moveTo(0, lay.bot);
        const step = Lr.ty === 'town' ? 4 : 8;
        for (let px = 0; px <= w + step; px += step) ctx.lineTo(px, Y(farY(Lr, camX * Lr.par + px / s)));
        ctx.lineTo(w + step, cv.h); ctx.lineTo(0, cv.h); ctx.closePath();
        ctx.fillStyle = Lr.c; ctx.fill();
      }
    }
    function drawTerrain(now) {
      const s = lay.s, w = cv.w, x0 = camX - 10, x1 = camX + lay.viewW + 10;
      ctx.beginPath(); ctx.moveTo(-2, cv.h);
      const step = 6 / s;
      for (let x = x0; x <= x1 + step; x += step) ctx.lineTo(X(x), Y(groundRaw(W, x)));
      ctx.lineTo(w + 2, cv.h); ctx.closePath();
      ctx.fillStyle = groundGrad; ctx.fill();
      ctx.beginPath();
      for (let x = x0; x <= x1 + step; x += step) { const g = groundRaw(W, x); x === x0 ? ctx.moveTo(X(x), Y(g)) : ctx.lineTo(X(x), Y(g)); }
      ctx.strokeStyle = W.C.pal.edge; ctx.lineWidth = Math.max(2, 3 * s); ctx.stroke();
      if (W.C.pal.sea) { // the sea
        ctx.fillStyle = seaGrad; ctx.globalAlpha = 0.92; ctx.fillRect(0, Y(0), w, cv.h - Y(0)); ctx.globalAlpha = 1;
        ctx.strokeStyle = 'rgba(230,250,255,.7)'; ctx.lineWidth = 1.5; ctx.beginPath();
        for (let px = 0; px <= w; px += 6) { const xw = camX + px / s, yy = Y(0) + Math.sin(xw * 0.08 + now / 400) * 1.5; px ? ctx.lineTo(px, yy) : ctx.moveTo(px, yy); }
        ctx.stroke();
      }
      // decorations every ~36 units
      const deco = W.C.pal.deco;
      for (let i = Math.floor(x0 / 36); i <= Math.ceil(x1 / 36); i++) {
        if (i < 0) continue;
        const hv = hash32(i, W.ci * 31 + 5);
        if (hv % 3 === 0) continue;
        const x = i * 36 + (hv >>> 4) % 22, g = groundRaw(W, x);
        if (g < 1.5 || Math.abs(groundRaw(W, x + 5) - groundRaw(W, x - 5)) > 9) continue;
        if (Math.abs(x - START_X) < 70 || Math.abs(x - W.C.len) < 30) continue;
        drawDeco(deco, X(x), Y(g), s, hv, now, x);
      }
      // wind socks every 300 units show the ground wind
      for (let i = Math.max(1, Math.floor(x0 / 300)); i <= Math.ceil(x1 / 300); i++) {
        const x = i * 300 + 130, g = groundRaw(W, x);
        if (g < 1 || x > W.C.len - 40) continue;
        const v = windAt(W, x, g + 16, W.t), px = X(x), py = Y(g);
        ctx.strokeStyle = '#5a4a3a'; ctx.lineWidth = Math.max(1, 1.4 * s); ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px, py - 18 * s); ctx.stroke();
        const len = clamp(Math.abs(v) / 25, 0.25, 1) * 11 * s, dir = v >= 0 ? 1 : -1, droop = (1 - clamp(Math.abs(v) / 25, 0, 1)) * 6 * s;
        ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.moveTo(px, py - 18 * s); ctx.lineTo(px + dir * len, py - 16.5 * s + droop + Math.sin(now / 120 + i) * s * 0.6); ctx.lineTo(px, py - 14 * s); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#f6ecd6'; ctx.beginPath(); ctx.moveTo(px + dir * len * 0.33, py - 17.5 * s + droop * 0.33); ctx.lineTo(px + dir * len * 0.55, py - 16.8 * s + droop * 0.55); ctx.lineTo(px + dir * len * 0.55, py - 15.2 * s + droop * 0.55); ctx.lineTo(px + dir * len * 0.33, py - 14.6 * s + droop * 0.33); ctx.closePath(); ctx.fill();
      }
      // launch field & landing target
      drawStartFinishGround(s);
    }
    function drawDeco(kind, px, py, s, hv, now, xw) {
      const k = s * (0.8 + (hv % 7) / 14);
      ctx.save(); ctx.translate(px, py);
      if (kind === 'tree') {
        ctx.fillStyle = '#6a4a2a'; ctx.fillRect(-1.2 * k, -8 * k, 2.4 * k, 8 * k);
        const cols = ['#4f8a3c', '#5e9c46', '#3f7a34'], c = cols[hv % 3];
        ctx.fillStyle = c; ctx.beginPath(); ctx.arc(0, -12 * k, 6 * k, 0, 7); ctx.arc(-4 * k, -9 * k, 4.5 * k, 0, 7); ctx.arc(4 * k, -9.5 * k, 4.5 * k, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,220,.18)'; ctx.beginPath(); ctx.arc(-2 * k, -14 * k, 3 * k, 0, 7); ctx.fill();
      } else if (kind === 'pine') {
        ctx.fillStyle = '#5a4030'; ctx.fillRect(-1 * k, -4 * k, 2 * k, 4 * k);
        for (let j = 0; j < 3; j++) { const yy = -4 * k - j * 5 * k, ww = (7 - j * 1.8) * k; ctx.fillStyle = '#2f5a48'; ctx.beginPath(); ctx.moveTo(-ww, yy); ctx.lineTo(0, yy - 8 * k); ctx.lineTo(ww, yy); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#f4f8fb'; ctx.beginPath(); ctx.moveTo(-ww * 0.45, yy - 4.4 * k); ctx.lineTo(0, yy - 8 * k); ctx.lineTo(ww * 0.45, yy - 4.4 * k); ctx.closePath(); ctx.fill(); }
      } else if (kind === 'dead') {
        ctx.strokeStyle = '#2a2420'; ctx.lineWidth = 1.6 * k; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -14 * k); ctx.moveTo(0, -8 * k); ctx.lineTo(-5 * k, -13 * k); ctx.moveTo(0, -10 * k); ctx.lineTo(4 * k, -15 * k); ctx.moveTo(-2.5 * k, -10.5 * k); ctx.lineTo(-3 * k, -15 * k); ctx.stroke(); ctx.lineCap = 'butt';
      } else if (kind === 'cactus') {
        if (hv % 4 === 0) { ctx.fillStyle = '#9a6a4a'; ctx.beginPath(); ctx.ellipse(0, -2 * k, 6 * k, 3.5 * k, 0, Math.PI, 0); ctx.fill(); }
        else {
          ctx.fillStyle = '#4f8a50'; rrect(ctx, -1.8 * k, -14 * k, 3.6 * k, 14 * k, 1.8 * k); ctx.fill();
          rrect(ctx, -6 * k, -10 * k, 2.6 * k, 6 * k, 1.3 * k); ctx.fill(); ctx.fillRect(-6 * k, -5.5 * k, 5 * k, 2 * k);
          rrect(ctx, 3.4 * k, -12 * k, 2.6 * k, 6 * k, 1.3 * k); ctx.fill(); ctx.fillRect(1 * k, -7.5 * k, 5 * k, 2 * k);
        }
      } else if (kind === 'palm') {
        ctx.strokeStyle = '#8a6a40'; ctx.lineWidth = 1.8 * k; ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(2 * k, -8 * k, 1 * k, -16 * k); ctx.stroke();
        ctx.fillStyle = '#3f8a4a';
        for (let j = 0; j < 5; j++) { const a = -Math.PI / 2 + (j - 2) * 0.62 + Math.sin(now / 700 + hv) * 0.06; ctx.save(); ctx.translate(1 * k, -16 * k); ctx.rotate(a); ctx.beginPath(); ctx.ellipse(5 * k, 0, 6 * k, 1.6 * k, 0.25, 0, 7); ctx.fill(); ctx.restore(); }
      } else if (kind === 'house') {
        if (hv % 5 === 0) { // windmill
          ctx.fillStyle = '#d8c8b0'; ctx.beginPath(); ctx.moveTo(-4 * k, 0); ctx.lineTo(-2.4 * k, -16 * k); ctx.lineTo(2.4 * k, -16 * k); ctx.lineTo(4 * k, 0); ctx.closePath(); ctx.fill();
          ctx.fillStyle = '#7a3a2a'; ctx.beginPath(); ctx.moveTo(-3 * k, -16 * k); ctx.lineTo(0, -19 * k); ctx.lineTo(3 * k, -16 * k); ctx.closePath(); ctx.fill();
          ctx.save(); ctx.translate(0, -16 * k); ctx.rotate(now / 900 + hv); ctx.fillStyle = '#f2e9d8';
          for (let j = 0; j < 4; j++) { ctx.rotate(Math.PI / 2); ctx.fillRect(-0.8 * k, 1 * k, 1.6 * k, 9 * k); }
          ctx.restore();
        } else {
          const ww = (5 + (hv % 3)) * k, hh = (6 + (hv % 4)) * k;
          ctx.fillStyle = ['#e0c8a8', '#d6b090', '#c8a88a'][hv % 3]; ctx.fillRect(-ww, -hh, ww * 2, hh);
          ctx.fillStyle = ['#8a3a30', '#5a3a50', '#7a4a2a'][(hv >> 3) % 3]; ctx.beginPath(); ctx.moveTo(-ww - 1.5 * k, -hh); ctx.lineTo(0, -hh - 6 * k); ctx.lineTo(ww + 1.5 * k, -hh); ctx.closePath(); ctx.fill();
          ctx.fillStyle = '#ffd27a'; ctx.fillRect(-ww * 0.5, -hh * 0.7, 2.4 * k, 2.4 * k); ctx.fillRect(ww * 0.25, -hh * 0.7, 2.4 * k, 2.4 * k);
          if (hv % 2) { ctx.fillStyle = '#5a4a40'; ctx.fillRect(ww * 0.4, -hh - 5 * k, 2 * k, 4 * k); }
        }
      }
      ctx.restore();
      void xw;
    }
    function drawStartFinishGround(s) {
      // launch banner
      const sx = X(START_X);
      if (sx > -80 && sx < cv.w + 80) {
        const g = groundRaw(W, START_X), py = Y(g);
        ctx.strokeStyle = '#5a4a3a'; ctx.lineWidth = Math.max(1.5, 2 * s);
        for (const d of [-62, 62]) { ctx.beginPath(); ctx.moveTo(sx + d * s, Y(groundRaw(W, START_X + d))); ctx.lineTo(sx + d * s, py - 26 * s); ctx.stroke(); }
        ctx.fillStyle = 'rgba(46,38,64,.9)'; rrect(ctx, sx - 30 * s, py - 32 * s, 60 * s, 11 * s, 3 * s); ctx.fill();
        ctx.font = '700 ' + Math.max(10, 8 * s) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText('출발', sx, py - 26.5 * s);
      }
      // landing target after the finish
      const tx = X(W.C.len + 160);
      if (tx > -60 && tx < cv.w + 60) {
        const py = Y(ground(W, W.C.len + 160));
        for (let r = 3; r >= 1; r--) { ctx.fillStyle = r % 2 ? '#ee6a55' : '#f6ecd6'; ctx.beginPath(); ctx.ellipse(tx, py + 1, r * 10 * s, r * 2.2 * s, 0, 0, 7); ctx.fill(); }
      }
    }
    function drawWind(now) { // drifting streaks: white = toward the finish, coral = backwards
      const s = lay.s, span = lay.viewW + 80, cx = camX + lay.viewW / 2;
      ctx.lineCap = 'round';
      for (let i = 0; i < 40; i++) {
        const hy = hash32(i, 41), hx = hash32(i, 42);
        const y = 14 + (hy % 1000) / 1000 * 366, v = windAt(W, cx, y, W.t);
        const p = (hx % 1000) / 1000 * span + v * W.t;
        const xw = camX - 40 + (((p - camX + 40) % span) + span) % span;
        if (xw < ground(W, xw) - 2) continue;
        if (y < groundRaw(W, xw) + 6) continue;
        const px = X(xw), py = Y(y), len = (6 + Math.abs(v) * 1.1) * s, dir = v >= 0 ? 1 : -1, a = 0.16 + 0.3 * clamp(Math.abs(v) / 30, 0, 1);
        ctx.strokeStyle = v >= 0 ? 'rgba(255,255,255,' + a + ')' : 'rgba(255,120,100,' + (a + 0.12) + ')';
        ctx.lineWidth = Math.max(1, 1.3 * s);
        ctx.beginPath(); ctx.moveTo(px - dir * len, py); ctx.lineTo(px, py); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(px - dir * 3 * s, py - 2 * s); ctx.lineTo(px, py); ctx.lineTo(px - dir * 3 * s, py + 2 * s); ctx.stroke();
      }
      ctx.lineCap = 'butt';
      void now;
    }
    function drawClouds() { // fair-weather clouds riding their layer
      const s = lay.s, span = lay.viewW + 300, k = W.C.pal.cloud;
      if (!k) return;
      ctx.globalAlpha = 0.5 * k;
      for (let i = 0; i < 7; i++) {
        const hy = hash32(i + W.ci * 13, 51), hx = hash32(i, 52), y = 60 + (hy % 1000) / 1000 * 320, sc = 0.7 + (hx % 100) / 160;
        const v = windAt(W, camX + lay.viewW / 2, y, W.t), p = (hx % 1000) / 1000 * span + v * W.t;
        const xw = camX - 150 + (((p - camX + 150) % span) + span) % span;
        const ww = 64 * sc * s, hh = 36 * sc * s;
        ctx.drawImage(puffW, X(xw) - ww / 2, Y(y) - hh / 2, ww, hh);
      }
      ctx.globalAlpha = 1;
    }
    function drawThermals(now) {
      const s = lay.s;
      for (const q of W.C.therm) {
        const px = X(q[0]), hw = q[1] * s;
        if (px + hw < 0 || px - hw > cv.w) continue;
        const gy = Y(ground(W, q[0])), ty = Y(q[2]);
        const gr = ctx.createLinearGradient(px - hw, 0, px + hw, 0);
        gr.addColorStop(0, 'rgba(255,190,110,0)'); gr.addColorStop(0.5, 'rgba(255,190,110,.16)'); gr.addColorStop(1, 'rgba(255,190,110,0)');
        ctx.fillStyle = gr; ctx.fillRect(px - hw, ty, hw * 2, gy - ty);
        ctx.strokeStyle = 'rgba(255,240,210,.35)'; ctx.lineWidth = Math.max(1, 1.2 * s);
        for (let j = 0; j < 4; j++) {
          const off = (j - 1.5) * hw * 0.45, ph = frac(now / 2400 + j * 0.27);
          const y0 = gy - (gy - ty) * ph, y1 = y0 - 26 * s;
          ctx.beginPath(); for (let u = 0; u <= 1.001; u += 0.2) { const yy = y0 + (y1 - y0) * u; const xx = px + off + Math.sin(u * 6 + now / 300 + j) * 2.5 * s; u ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); } ctx.stroke();
          ctx.beginPath(); ctx.moveTo(px + off - 3 * s, y1 + 4 * s); ctx.lineTo(px + off, y1); ctx.lineTo(px + off + 3 * s, y1 + 4 * s); ctx.stroke();
        }
      }
    }
    function stormFlash(k) { const s = W.C.storms[k], ph = frac((W.t + s[0] * 0.013) / 4.6); return W.t > 1 && ph < 0.07 ? 1 - ph / 0.07 : 0; }
    function drawStormsBack(now) {
      const s = lay.s;
      W.C.storms.forEach((q, k) => {
        const px = X(q[0]), r = q[2] * s;
        if (px + r * 1.5 < 0 || px - r * 1.5 > cv.w) return;
        // rain shaft
        const gy = Y(ground(W, q[0])), cy = Y(q[1]);
        ctx.strokeStyle = 'rgba(180,190,220,.28)'; ctx.lineWidth = 1;
        const wv = windAt(W, q[0], q[1] - 40, W.t) * 0.15;
        for (let j = 0; j < 14; j++) {
          const xx = px + ((hash32(j, k + 9) % 1000) / 1000 - 0.5) * r * 1.3, ph = frac(now / 520 + j * 0.37), yy = cy + (gy - cy) * ph;
          ctx.beginPath(); ctx.moveTo(xx + wv * ph * 40 * s, yy); ctx.lineTo(xx + wv * ph * 40 * s - wv * 3 * s, yy + 9 * s); ctx.stroke();
        }
        const f = stormFlash(k);
        if (f > 0) { // lightning bolt
          const sd = Math.floor((W.t + q[0] * 0.013) / 4.6);
          ctx.strokeStyle = 'rgba(255,250,210,' + f + ')'; ctx.lineWidth = 2.2; ctx.beginPath();
          let xx = px + ((hash32(sd, k) % 100) / 100 - 0.5) * r, yy = cy + r * 0.4; ctx.moveTo(xx, yy);
          while (yy < gy) { yy += 14 * s; xx += ((hash32(sd + Math.round(yy), k) % 100) / 100 - 0.5) * 18 * s; ctx.lineTo(xx, Math.min(yy, gy)); }
          ctx.stroke();
          if (px > 0 && px < cv.w) flash = Math.max(flash, f * 0.5);
        }
      });
    }
    function drawStormsFront() {
      const s = lay.s;
      W.C.storms.forEach((q, k) => {
        const px = X(q[0]), py = Y(q[1]), r = q[2] * s;
        if (px + r * 1.6 < 0 || px - r * 1.6 > cv.w) return;
        const f = stormFlash(k);
        ctx.globalAlpha = 0.86;
        ctx.drawImage(puffD, px - r * 1.35, py - r * 0.95, r * 2.7, r * 1.6);
        ctx.drawImage(puffD, px - r * 1.05, py - r * 0.55, r * 2.1, r * 1.2);
        if (f > 0) { ctx.globalAlpha = f * 0.6; ctx.drawImage(puffW, px - r * 1.1, py - r * 0.75, r * 2.2, r * 1.3); }
        ctx.globalAlpha = 1;
      });
    }
    function drawBirds(now) {
      const s = lay.s, col = W.C.pal.bird;
      for (let k = 0; k < W.C.birds.length; k++) {
        birdPos(W, k, W.t, BP);
        const cx = X(BP[0]), cy = Y(BP[1]), dir = BP[2] >= 0 ? 1 : -1;
        if (cx < -60 || cx > cv.w + 60) continue;
        ctx.strokeStyle = col; ctx.lineWidth = Math.max(1.4, 1.8 * s); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const form = [[0, 0], [-7, -4], [-7, 4], [-14, -8], [-14, 8]];
        form.forEach((o, i) => {
          const bx = cx + o[0] * dir * s, by = cy + o[1] * s + Math.sin(now / 300 + i) * 1.5 * s, fl = Math.sin(now / 70 + i * 1.3) * 3.2 * s, ww = 5 * s;
          ctx.beginPath(); ctx.moveTo(bx - ww, by - fl); ctx.quadraticCurveTo(bx - ww * 0.4, by - 1.5 * s, bx, by); ctx.quadraticCurveTo(bx + ww * 0.4, by - 1.5 * s, bx + ww, by - fl); ctx.stroke();
        });
        ctx.lineCap = 'butt';
      }
    }
    function drawGate(i, front, now, myb) {
      const g = W.C.gates[i], s = lay.s, px = X(g[0]);
      if (px < -30 || px > cv.w + 30) return;
      const y0 = Y(g[1]), y1 = Y(g[2]), cy = (y0 + y1) / 2, ry = (y0 - y1) / 2, rx = 7 * s;
      const passed = myb && myb.gi > i, missed = passed && (myb.gm & (1 << i)), next = myb && myb.gi === i;
      const col = missed ? '#ee6a55' : passed ? '#7fd36a' : '#e3ae45';
      ctx.save();
      if (!front) {
        ctx.globalAlpha = passed ? 0.35 : 0.75;
        ctx.strokeStyle = shade(col, -0.35); ctx.lineWidth = Math.max(2.5, 3.6 * s);
        ctx.beginPath(); ctx.ellipse(px, cy, rx, ry, 0, -Math.PI / 2, Math.PI / 2); ctx.stroke();
        // pennants at top and bottom fly with the local wind
        for (const e of [[g[2], y1], [g[1], y0]]) {
          const v = windAt(W, g[0], e[0], W.t), dir = v >= 0 ? 1 : -1, len = (5 + clamp(Math.abs(v), 0, 30) * 0.35) * s;
          ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(px, e[1]); ctx.lineTo(px + dir * len, e[1] + Math.sin(now / 110 + e[0]) * 1.2 * s - 3 * s); ctx.lineTo(px, e[1] - 6 * s); ctx.closePath(); ctx.fill();
        }
      } else {
        if (next) { ctx.shadowColor = 'rgba(255,224,138,.9)'; ctx.shadowBlur = 8 + 5 * Math.sin(now / 180); }
        ctx.globalAlpha = passed ? 0.45 : 1;
        ctx.strokeStyle = col; ctx.lineWidth = Math.max(3, 4.2 * s);
        ctx.beginPath(); ctx.ellipse(px, cy, rx, ry, 0, Math.PI / 2, Math.PI * 1.5); ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.strokeStyle = 'rgba(255,255,255,.45)'; ctx.lineWidth = Math.max(1, 1.2 * s);
        ctx.beginPath(); ctx.ellipse(px - 0.6 * s, cy, rx, ry, 0, Math.PI * 0.62, Math.PI * 1.38); ctx.stroke();
        // number badge
        ctx.globalAlpha = passed ? 0.6 : 1;
        const by = y1 - 13 * Math.max(0.8, s);
        ctx.fillStyle = 'rgba(23,19,31,.78)'; ctx.beginPath(); ctx.arc(px, by, 9, 0, 7); ctx.fill();
        ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = col; ctx.font = '700 11px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(missed ? '✕' : passed ? '✓' : String(i + 1), px, by + 0.5);
      }
      ctx.restore();
    }
    function drawFinish(now) {
      const s = lay.s, px = X(W.C.len);
      if (px < -40 || px > cv.w + 40) return;
      const gy = Y(ground(W, W.C.len)), ty = Y(392), w2 = 5 * s;
      ctx.globalAlpha = 0.55;
      for (let y = ty, k = 0; y < gy; y += 8 * s, k++) { ctx.fillStyle = k % 2 ? '#17131f' : '#f6ecd6'; ctx.fillRect(px - w2, y, w2, Math.min(8 * s, gy - y)); ctx.fillStyle = k % 2 ? '#f6ecd6' : '#17131f'; ctx.fillRect(px, y, w2, Math.min(8 * s, gy - y)); }
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#ee6a55'; rrect(ctx, px - 26, ty - 22, 52, 20, 6); ctx.fill();
      ctx.fillStyle = '#fff6e0'; ctx.font = '15px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('결승', px, ty - 11.5);
      void now;
    }
    function drawShadow(b) {
      const s = lay.s, g = ground(W, b.x), alt = b.y - g, a = 0.28 * clamp(1 - alt / 260, 0.15, 1);
      const px = X(b.x + laneOff(b)), py = Y(g);
      ctx.fillStyle = 'rgba(20,14,30,' + a + ')'; ctx.beginPath(); ctx.ellipse(px, py + 0.5, (8 + alt * 0.02) * s, 2.2 * s, 0, 0, 7); ctx.fill();
    }
    function drawBalloon(b, now) {
      const s = lay.s, cx = X(b.x + laneOff(b)), cy = Y(b.y + ENV_DY);
      if (cx < -40 * s || cx > cv.w + 40 * s) return;
      const w = windAt(W, b.x, b.y + ENV_DY, W.t);
      let tilt = clamp((w - b.vx) * 0.012, -0.16, 0.16) + Math.sin(now / 900 + b.seat * 2) * 0.025;
      if (b.bc > 1.6) tilt += Math.sin(now / 40) * 0.08 * (b.bc - 1.6);
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(tilt); ctx.scale(s, s);
      // ropes & basket
      ctx.strokeStyle = '#4a3428'; ctx.lineWidth = 0.6;
      ctx.beginPath(); ctx.moveTo(-4.4, 18.8); ctx.lineTo(-4, 23.2); ctx.moveTo(4.4, 18.8); ctx.lineTo(4, 23.2); ctx.moveTo(-1.6, 18.8); ctx.lineTo(-1.6, 23.2); ctx.moveTo(1.6, 18.8); ctx.lineTo(1.6, 23.2); ctx.stroke();
      ctx.fillStyle = '#a06e38'; rrect(ctx, -4.6, 23, 9.2, 7, 1.3); ctx.fill();
      ctx.strokeStyle = 'rgba(70,40,18,.55)'; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(-4.4, 25.4); ctx.lineTo(4.4, 25.4); ctx.moveTo(-4.4, 27.8); ctx.lineTo(4.4, 27.8); ctx.moveTo(-1.5, 23.4); ctx.lineTo(-1.5, 29.6); ctx.moveTo(1.5, 23.4); ctx.lineTo(1.5, 29.6); ctx.stroke();
      ctx.fillStyle = '#6a4220'; rrect(ctx, -5.1, 22.4, 10.2, 1.6, 0.7); ctx.fill();
      ctx.fillStyle = '#3c3a40'; ctx.fillRect(-1.8, 20.2, 3.6, 2);
      // envelope
      const spr = sprites[b.seat];
      if (spr) ctx.drawImage(spr, -17, -18, 34, 38);
      if (b.burn || b.h > 0.55) { // warm inner glow
        const k = b.burn ? 0.36 + Math.sin(now / 45) * 0.05 : (b.h - 0.55) * 0.35;
        ctx.globalCompositeOperation = 'lighter';
        const rg = ctx.createRadialGradient(0, 11, 1, 0, 4, 18); rg.addColorStop(0, 'rgba(255,170,70,' + k + ')'); rg.addColorStop(1, 'rgba(255,120,40,0)');
        ctx.fillStyle = rg; envPath(ctx); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
      }
      if (b.burn) { // the flame
        const fl = 0.85 + 0.25 * Math.sin(now / 37 + b.seat) + 0.12 * Math.sin(now / 13);
        const top = 20 - 10 * fl;
        ctx.fillStyle = 'rgba(255,140,40,.9)'; ctx.beginPath(); ctx.moveTo(-2.2, 20.6); ctx.quadraticCurveTo(-2.6, 16, 0, top); ctx.quadraticCurveTo(2.6, 16, 2.2, 20.6); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,240,170,.95)'; ctx.beginPath(); ctx.moveTo(-1.1, 20.6); ctx.quadraticCurveTo(-1.2, 17.5, 0, top + 3); ctx.quadraticCurveTo(1.2, 17.5, 1.1, 20.6); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }
    function drawTag(b) {
      const s = lay.s, cx = X(b.x + laneOff(b)), ty = Y(b.y + ENV_DY + 17) - 9;
      if (cx < -40 || cx > cv.w + 40) return;
      if (isMine(b.seat)) {
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.moveTo(cx, ty + 4); ctx.lineTo(cx - 5, ty - 5); ctx.lineTo(cx + 5, ty - 5); ctx.closePath(); ctx.fill();
        rrect(ctx, cx - 12, ty - 19, 24, 15, 7.5); ctx.fill();
        ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#17131f'; ctx.fillText('나', cx, ty - 11);
      } else {
        const t = name(b.seat);
        ctx.font = '700 10.5px ' + FONT; const tw = Math.min(90, ctx.measureText(t).width + 12);
        ctx.fillStyle = 'rgba(23,19,31,.62)'; rrect(ctx, cx - tw / 2, ty - 13, tw, 14, 7); ctx.fill();
        ctx.fillStyle = P(b.seat).color; ctx.beginPath(); ctx.arc(cx - tw / 2 + 6, ty - 6, 2.4, 0, 7); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, cx + 3, ty - 5.5, tw - 12);
      }
      void s;
    }
    const PG = { seat: -1, x: 0, y: 0, vx: 0, vy: 0, h: 0, gr: 0, bc: 0, wt: 1, done: 0, burn: 0, vent: 0, st: 0 };
    function drawPrediction(b) { // where I will be in the next 3 s if I keep doing what I am doing
      if (!b || b.done || phase !== 'race') return;
      PG.x = b.x; PG.y = b.y; PG.vx = b.vx; PG.vy = b.vy; PG.h = b.h; PG.gr = b.gr; PG.wt = 1;
      const inp = myInput(), t0 = W.t, dt = 0.1;
      ctx.fillStyle = inp.b ? 'rgba(255,214,140,.9)' : inp.v ? 'rgba(170,210,255,.9)' : 'rgba(255,255,255,.75)';
      for (let k = 1; k <= 30; k++) {
        stepBalloon(W, PG, inp, dt, null); W.t += dt;
        if (k % 3 === 0) { const a = 1 - k / 34; ctx.globalAlpha = a; ctx.beginPath(); ctx.arc(X(PG.x), Y(PG.y + ENV_DY), Math.max(1.6, 2.4 * lay.s * a + 0.6), 0, 7); ctx.fill(); }
      }
      W.t = t0; ctx.globalAlpha = 1;
    }
    function drawParts() {
      const s = lay.s;
      for (const p of parts) {
        const a = clamp(p.t / p.T, 0, 1);
        ctx.globalAlpha = a;
        if (p.k === 2) { ctx.save(); ctx.translate(X(p.x), Y(p.y)); ctx.rotate(p.r + p.t * 3); ctx.fillStyle = p.c; ctx.beginPath(); ctx.ellipse(0, 0, 3 * s, 1.1 * s, 0, 0, 7); ctx.fill(); ctx.restore(); }
        else if (p.k === 1) { ctx.fillStyle = p.c; ctx.fillRect(X(p.x) - 1.5 * s, Y(p.y) - 1.5 * s, 3 * s, 3 * s); }
        else { ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(X(p.x), Y(p.y), (2 + (1 - a) * 4) * s, 0, 7); ctx.fill(); }
      }
      ctx.globalAlpha = 1;
    }
    function txtO(t, x, y, col, font, align) {
      ctx.font = font; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 3.5; ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(t, x, y);
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    /* altimeter: wind at each height right where I am, the next gate window and everyone's altitude */
    function drawAltimeter(now) {
      const b = focusBalloon(), refX = b ? b.x : camX + lay.viewW / 2;
      const x0 = 6, w = 30, yT = Y(385), yB = Y(0);
      ctx.fillStyle = 'rgba(23,19,31,.55)'; rrect(ctx, x0, yT - 18, w, yB - yT + 24, 9); ctx.fill();
      for (let y = 0; y < 385; y += 10) {
        const v = windAt(W, refX, y + 5, W.t);
        ctx.fillStyle = v >= 0 ? 'rgba(160,225,255,' + (0.06 + 0.42 * clamp(v / 30, 0, 1)) + ')' : 'rgba(238,106,85,' + (0.2 + 0.5 * clamp(-v / 16, 0, 1)) + ')';
        ctx.fillRect(x0 + 3, Y(y + 10), w - 6, Y(y) - Y(y + 10) + 0.5);
      }
      // chevrons per band
      const Z = W.C.zones[zoneAt(W.C, refX)].b;
      let lo = 0;
      ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (const band of Z) {
        const hi = Math.min(band[0], 385), mid = (Math.max(lo, 0) + hi) / 2;
        lo = band[0];
        if (hi - mid < 6) continue;
        const v = windAt(W, refX, mid, W.t), n = Math.abs(v) < 11 ? 1 : Math.abs(v) < 21 ? 2 : 3, dir = v >= 0 ? 1 : -1, py = Y(mid), cx = x0 + w / 2;
        ctx.strokeStyle = v >= 0 ? '#f6ecd6' : '#ff8a74';
        for (let j = 0; j < n; j++) {
          const ox = cx + (j - (n - 1) / 2) * 6 * dir;
          ctx.beginPath(); ctx.moveTo(ox - 2.5 * dir, py - 4.5); ctx.lineTo(ox + 2 * dir, py); ctx.lineTo(ox - 2.5 * dir, py + 4.5); ctx.stroke();
        }
        if (lo > 385) break;
      }
      ctx.lineCap = 'butt';
      // next gate window
      if (b && W.C.gates[b.gi] && !b.done) {
        const g = W.C.gates[b.gi];
        ctx.fillStyle = 'rgba(227,174,69,.95)'; rrect(ctx, x0 + 0.5, Y(g[2]), 3.5, Y(g[1]) - Y(g[2]), 2); ctx.fill();
      }
      // everyone's altitude
      for (const q of W.b) {
        if (isMine(q.seat)) continue;
        ctx.fillStyle = P(q.seat).color; ctx.beginPath(); ctx.arc(x0 + w - 4, Y(q.y + ENV_DY), 3.2, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(23,19,31,.8)'; ctx.lineWidth = 1; ctx.stroke();
      }
      const mb = me() >= 0 ? W.b[me()] : null;
      if (mb) {
        const py = Y(mb.y + ENV_DY);
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.moveTo(x0 + w + 6, py); ctx.lineTo(x0 + w - 3, py - 6); ctx.lineTo(x0 + w - 3, py + 6); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#17131f'; ctx.lineWidth = 1; ctx.stroke();
      }
      ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText('바람', x0 + w / 2, yT - 9);
      void now;
    }
    function drawNextGateHint(now) { // arrow on the right edge when the next gate is still off screen
      const b = me() >= 0 ? W.b[me()] : null;
      if (!b || b.done) return;
      const g = W.C.gates[b.gi];
      if (!g || X(g[0]) < lay.cr - 6) return;
      const x = lay.cr, y1 = Y(g[2]), y0 = Y(g[1]), a = 0.7 + 0.3 * Math.sin(now / 200);
      ctx.globalAlpha = a; ctx.fillStyle = '#e3ae45'; rrect(ctx, x - 3, y1, 5, y0 - y1, 2.5); ctx.fill();
      const my2 = (y0 + y1) / 2;
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x - 14, my2 - 6); ctx.lineTo(x - 8, my2); ctx.lineTo(x - 14, my2 + 6); ctx.stroke(); ctx.lineCap = 'butt';
      txtO(String(b.gi + 1), x - 22, my2, '#ffe08a', '700 13px ' + MONO, 'center');
      ctx.globalAlpha = 1;
    }
    function drawTopHud() {
      const w = cv.w, HH = lay.top, land = lay.land;
      ctx.fillStyle = 'rgba(23,19,31,.8)'; ctx.fillRect(0, 0, w, HH);
      ctx.fillStyle = 'rgba(227,174,69,.35)'; ctx.fillRect(0, HH - 1, w, 1);
      const fc = (me() >= 0 ? W.b[me()] : null) || focusBalloon();
      // landscape: rank · progress bar · time · penalty/course all in one row
      let x0 = 18, x1 = w - 18, ry = 32, rowY = 13;
      if (land) {
        rowY = HH / 2; ry = HH / 2;
        ctx.font = '17px ' + DISP; const rkW = ctx.measureText('4위').width + 34;
        ctx.font = '700 12px ' + FONT; const rt = fc && fc.pen ? '벌점 +' + fc.pen * PEN + '초' : W.C.name, rtW = ctx.measureText(rt).width;
        x0 = 12 + rkW + 12; x1 = w - 12 - rtW - 16 - 62 - 22;
      }
      const C = W.C;
      const PX = (x) => x0 + clamp(x / C.len, 0, 1) * (x1 - x0);
      ctx.strokeStyle = 'rgba(242,233,216,.22)'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x0, ry); ctx.lineTo(x1, ry); ctx.stroke(); ctx.lineCap = 'butt';
      const mb = me() >= 0 ? W.b[me()] : null;
      C.gates.forEach((g, i) => {
        const passed = mb && mb.gi > i, missed = passed && (mb.gm & (1 << i));
        ctx.fillStyle = missed ? '#ee6a55' : passed ? '#7fd36a' : '#e3ae45';
        ctx.fillRect(PX(g[0]) - 1, ry - 6, 2, 12);
      });
      // finish flag
      ctx.fillStyle = '#f6ecd6'; ctx.fillRect(x1 - 1, ry - 9, 2, 14);
      ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.moveTo(x1 + 1, ry - 9); ctx.lineTo(x1 + 9, ry - 6); ctx.lineTo(x1 + 1, ry - 3); ctx.closePath(); ctx.fill();
      const order = W.b.slice().sort((a, b) => (isMine(a.seat) ? 1 : 0) - (isMine(b.seat) ? 1 : 0));
      for (const b of order) {
        const px = PX(b.x), mine = isMine(b.seat);
        ctx.fillStyle = P(b.seat).color; ctx.beginPath(); ctx.arc(px, ry, mine ? 6.5 : 4.8, 0, 7); ctx.fill();
        ctx.lineWidth = mine ? 2 : 1; ctx.strokeStyle = mine ? '#f6ecd6' : 'rgba(23,19,31,.9)'; ctx.stroke();
      }
      // rank · time · penalty
      const rk = ranking(W), focus = mb || focusBalloon(), pos = rk.indexOf(focus) + 1;
      ctx.textBaseline = 'middle';
      if (focus) {
        ctx.font = '17px ' + DISP; ctx.textAlign = 'left'; ctx.fillStyle = '#e3ae45';
        const rt = pos + '위'; ctx.fillText(rt, 12, rowY);
        const tw = ctx.measureText(rt).width;
        ctx.font = '700 11px ' + MONO; ctx.fillStyle = '#ab9fb8'; ctx.fillText('/' + W.b.length, 14 + tw, rowY + 1);
      }
      const tShow = focus && focus.done ? focus.fin : phase === 'race' || phase === 'done' ? W.t * 1000 : 0;
      ctx.font = '700 13px ' + MONO; ctx.fillStyle = '#f2e9d8';
      if (land) { ctx.textAlign = 'left'; ctx.fillText(fmtT(tShow), x1 + 22, rowY); } else { ctx.textAlign = 'center'; ctx.fillText(fmtT(tShow), w / 2, rowY); }
      ctx.textAlign = 'right';
      if (focus && focus.pen) { ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#ee6a55'; ctx.fillText('벌점 +' + focus.pen * PEN + '초', w - 12, rowY); }
      else { ctx.font = (land ? '700 12px ' : '700 11px ') + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText(C.name, w - 12, rowY); }
    }
    /* landscape: 내리기 pad at the left edge, heat gauge + 버너 pad at the right edge (see-through over the scene) */
    function drawSideControls(now) {
      const R = pads(), b = W.b[me()], inp = myInput(), fin2 = b && b.done;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      // vent pad
      let r = R.vent;
      ctx.fillStyle = inp.v ? 'rgba(95,134,184,.92)' : 'rgba(30,24,44,.62)'; rrect(ctx, r.x, r.y, r.w, r.h, 16); ctx.fill();
      ctx.strokeStyle = inp.v ? '#bfe0ff' : 'rgba(242,233,216,.32)'; ctx.lineWidth = 1.5; ctx.stroke();
      const vx = r.x + r.w / 2, vy = r.y + r.h * 0.3;
      ctx.strokeStyle = '#bfe0ff'; ctx.lineWidth = 2.6; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(vx, vy - 11); ctx.lineTo(vx, vy + 9); ctx.moveTo(vx - 7, vy + 2); ctx.lineTo(vx, vy + 9); ctx.lineTo(vx + 7, vy + 2); ctx.stroke(); ctx.lineCap = 'butt';
      txtO('내리기', vx, r.y + r.h * 0.6, '#f2e9d8', '19px ' + DISP);
      txtO('밸브', vx, r.y + r.h * 0.8, '#cfc3dc', '700 11px ' + FONT);
      // heat gauge
      r = R.gauge;
      ctx.fillStyle = 'rgba(23,19,31,.85)'; rrect(ctx, r.x, r.y, r.w, r.h, 8); ctx.fill(); ctx.strokeStyle = 'rgba(242,233,216,.3)'; ctx.lineWidth = 1; ctx.stroke();
      const hv = b ? b.h : 0, fh = (r.h - 6) * hv;
      const hg = ctx.createLinearGradient(0, r.y + r.h, 0, r.y); hg.addColorStop(0, '#5fa8e0'); hg.addColorStop(0.5, '#f0b44a'); hg.addColorStop(1, '#ff5a3a');
      ctx.fillStyle = hg; rrect(ctx, r.x + 3, r.y + r.h - 3 - fh, r.w - 6, Math.max(2, fh), 5); ctx.fill();
      const ny = r.y + 3 + (r.h - 6) * (1 - NEUT);
      ctx.fillStyle = '#f6ecd6'; ctx.fillRect(r.x - 2, ny - 1, r.w + 4, 2);
      txtO('열', r.x + r.w / 2, r.y - 9, '#f2e9d8', '700 11px ' + FONT);
      // burner pad
      r = R.burn;
      const on = inp.b && !fin2;
      const bg = ctx.createLinearGradient(0, r.y, 0, r.y + r.h);
      if (on) { bg.addColorStop(0, 'rgba(255,176,74,.95)'); bg.addColorStop(1, 'rgba(224,96,42,.95)'); } else { bg.addColorStop(0, 'rgba(90,58,44,.72)'); bg.addColorStop(1, 'rgba(58,38,32,.8)'); }
      ctx.fillStyle = bg; rrect(ctx, r.x, r.y, r.w, r.h, 18); ctx.fill();
      ctx.strokeStyle = on ? '#ffe7b0' : 'rgba(227,174,69,.7)'; ctx.lineWidth = 2; ctx.stroke();
      const fx = r.x + r.w / 2, fy = r.y + r.h * 0.36, fk = (on ? 1 + 0.12 * Math.sin(now / 50) : 0.85) * clamp(r.h / 170, 0.75, 1);
      ctx.save(); ctx.translate(fx, fy + 14 * fk); ctx.scale(fk, fk);
      ctx.fillStyle = on ? '#fff3c4' : '#e3ae45'; ctx.beginPath(); ctx.moveTo(-10, 0); ctx.quadraticCurveTo(-14, -14, 0, -30); ctx.quadraticCurveTo(-2, -18, 6, -14); ctx.quadraticCurveTo(13, -8, 10, 0); ctx.quadraticCurveTo(0, 6, -10, 0); ctx.fill();
      ctx.fillStyle = on ? '#ff8a3a' : '#7a4a2a'; ctx.beginPath(); ctx.moveTo(-5, -1); ctx.quadraticCurveTo(-6, -10, 0, -16); ctx.quadraticCurveTo(1, -8, 6, -6); ctx.quadraticCurveTo(6, 2, -5, -1); ctx.fill();
      ctx.restore();
      if (on) { ctx.font = '24px ' + DISP; ctx.fillStyle = '#2a140c'; ctx.fillText(fin2 ? '도착!' : '버너', fx, r.y + r.h * 0.64); }
      else txtO(fin2 ? '도착!' : '버너', fx, r.y + r.h * 0.64, '#f6ecd6', '24px ' + DISP);
      ctx.font = '700 11px ' + FONT; ctx.fillStyle = on ? '#4a2010' : '#e8dcc8'; ctx.fillText(fin2 ? '기다려요' : '누르고 있기', fx, r.y + r.h * 0.83, r.w - 8);
    }
    function drawControls(now) {
      if (lay.land) { if (lay.P) drawSideControls(now); return; }
      if (!lay.ctl) return;
      const h = cv.h, R = pads(), b = W.b[me()];
      const gr = ctx.createLinearGradient(0, h - lay.ctl, 0, h); gr.addColorStop(0, 'rgba(23,19,31,.88)'); gr.addColorStop(1, 'rgba(23,19,31,.98)');
      ctx.fillStyle = gr; ctx.fillRect(0, h - lay.ctl, cv.w, lay.ctl);
      ctx.fillStyle = 'rgba(227,174,69,.3)'; ctx.fillRect(0, h - lay.ctl, cv.w, 1);
      const inp = myInput(), fin2 = b && b.done;
      // vent pad
      let r = R.vent;
      ctx.fillStyle = inp.v ? '#5f86b8' : '#2e2640'; rrect(ctx, r.x, r.y, r.w, r.h, 14); ctx.fill();
      ctx.strokeStyle = inp.v ? '#bfe0ff' : 'rgba(242,233,216,.2)'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.strokeStyle = '#bfe0ff'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
      const vx = r.x + r.w / 2, vy = r.y + r.h * 0.36;
      ctx.beginPath(); ctx.moveTo(vx, vy - 9); ctx.lineTo(vx, vy + 7); ctx.moveTo(vx - 6, vy + 1); ctx.lineTo(vx, vy + 7); ctx.lineTo(vx + 6, vy + 1); ctx.stroke(); ctx.lineCap = 'butt';
      ctx.font = '17px ' + DISP; ctx.fillText('내리기', vx, r.y + r.h * 0.68);
      ctx.font = '700 10px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('밸브', vx, r.y + r.h * 0.87);
      // heat gauge
      r = R.gauge;
      ctx.fillStyle = '#17131f'; rrect(ctx, r.x, r.y, r.w, r.h, 8); ctx.fill(); ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.lineWidth = 1; ctx.stroke();
      const hv = b ? b.h : 0, fh = (r.h - 6) * hv;
      const hg = ctx.createLinearGradient(0, r.y + r.h, 0, r.y); hg.addColorStop(0, '#5fa8e0'); hg.addColorStop(0.5, '#f0b44a'); hg.addColorStop(1, '#ff5a3a');
      ctx.fillStyle = hg; rrect(ctx, r.x + 3, r.y + r.h - 3 - fh, r.w - 6, Math.max(2, fh), 5); ctx.fill();
      const ny = r.y + 3 + (r.h - 6) * (1 - NEUT);
      ctx.fillStyle = '#f6ecd6'; ctx.fillRect(r.x - 2, ny - 1, r.w + 4, 2);
      ctx.font = '700 9px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('열', r.x + r.w / 2, r.y - 6 < h - lay.ctl ? r.y + 8 : r.y - 6);
      // burner pad
      r = R.burn;
      const on = inp.b && !fin2;
      const bg = ctx.createLinearGradient(0, r.y, 0, r.y + r.h);
      if (on) { bg.addColorStop(0, '#ffb04a'); bg.addColorStop(1, '#e0602a'); } else { bg.addColorStop(0, '#5a3a2c'); bg.addColorStop(1, '#3a2620'); }
      ctx.fillStyle = bg; rrect(ctx, r.x, r.y, r.w, r.h, 16); ctx.fill();
      ctx.strokeStyle = on ? '#ffe7b0' : 'rgba(227,174,69,.55)'; ctx.lineWidth = 2; ctx.stroke();
      // flame icon
      const fx = r.x + Math.min(48, r.w * 0.22), fy = r.y + r.h / 2, fk = on ? 1 + 0.12 * Math.sin(now / 50) : 0.8;
      ctx.save(); ctx.translate(fx, fy + 12); ctx.scale(fk, fk);
      ctx.fillStyle = on ? '#fff3c4' : '#e3ae45'; ctx.beginPath(); ctx.moveTo(-10, 0); ctx.quadraticCurveTo(-14, -14, 0, -30); ctx.quadraticCurveTo(-2, -18, 6, -14); ctx.quadraticCurveTo(13, -8, 10, 0); ctx.quadraticCurveTo(0, 6, -10, 0); ctx.fill();
      ctx.fillStyle = on ? '#ff8a3a' : '#7a4a2a'; ctx.beginPath(); ctx.moveTo(-5, -1); ctx.quadraticCurveTo(-6, -10, 0, -16); ctx.quadraticCurveTo(1, -8, 6, -6); ctx.quadraticCurveTo(6, 2, -5, -1); ctx.fill();
      ctx.restore();
      const tx = fx + 26 + (r.x + r.w - fx - 26) / 2;
      ctx.fillStyle = on ? '#2a140c' : '#f6ecd6'; ctx.font = '26px ' + DISP; ctx.textAlign = 'center'; ctx.fillText(fin2 ? '도착!' : '버너', tx, fy - 8);
      ctx.font = '700 11px ' + FONT; ctx.fillStyle = on ? '#4a2010' : '#ab9fb8'; ctx.fillText(fin2 ? '결과를 기다려요' : '누르는 동안 올라가요', tx, fy + 16);
    }
    function drawOverlay(now) {
      const w = cv.w, mid = (lay.top + lay.bot) / 2;
      if (phase === 'count') {
        const C = W.C;
        // landscape: the first-flight tips ride inside this card (the hint box would hide the balloons on the ground)
        const tips = lay.land && me() >= 0, pw = Math.min(w - 40, tips ? 380 : 320), py = lay.top + (lay.land ? 8 : 30);
        ctx.fillStyle = 'rgba(23,19,31,.84)'; rrect(ctx, (w - pw) / 2, py, pw, tips ? 112 : 74, 14); ctx.fill();
        ctx.strokeStyle = 'rgba(227,174,69,.5)'; ctx.lineWidth = 1.5; ctx.stroke();
        txtO((st && st.rnd ? '무작위 · ' : '') + C.name, w / 2, py + 24, '#e3ae45', '22px ' + DISP);
        ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.fillText(C.sub, w / 2, py + 48, pw - 20);
        ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('관문 ' + C.gates.length + '개 · 결승까지 ' + Math.round(C.len / 100) * 100 + 'm', w / 2, py + 64, pw - 20);
        if (tips) {
          ctx.fillStyle = 'rgba(227,174,69,.3)'; ctx.fillRect((w - pw) / 2 + 14, py + 75, pw - 28, 1);
          ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText('오른쪽 「버너」를 꾹 → 천천히 올라가요 · 왼쪽 「내리기」', w / 2, py + 88, pw - 20);
          ctx.fillStyle = '#ffe08a'; ctx.fillText('높이마다 바람이 달라요. 바람 층을 골라 타세요!', w / 2, py + 104, pw - 20);
        }
        const n = Math.ceil(cd);
        if (n <= COUNT) {
          const k = frac(cd);
          ctx.globalAlpha = clamp(k * 2, 0, 1);
          txtO(String(n), w / 2, mid + (tips ? 34 : 10), '#f6ecd6', Math.round(64 + 20 * k) + 'px ' + DISP);
          ctx.globalAlpha = 1;
        }
      } else if (phase === 'race' && W.t < 1.0) {
        ctx.globalAlpha = clamp(1 - W.t, 0, 1);
        txtO('출발!', w / 2, mid + 10, '#e3ae45', '58px ' + DISP);
        ctx.globalAlpha = 1;
      }
      if (banner) {
        ctx.globalAlpha = clamp(banner.t * 2, 0, 1);
        txtO(banner.text, w / 2, lay.top + 70, '#e3ae45', '34px ' + DISP);
        txtO(banner.sub, w / 2, lay.top + 102, '#f6ecd6', '700 14px ' + FONT);
        ctx.globalAlpha = 1;
      } else if (me() >= 0 && W.b[me()].done && st && st.ph === 'race') {
        txtO('관전 중 · 다른 열기구를 기다려요', w / 2, lay.top + 20, '#f2e9d8', '700 12px ' + FONT);
      }
      if (me() >= 0 && hintT > 0 && (phase === 'race' || (phase === 'count' && !lay.land))) {
        ctx.globalAlpha = clamp(hintT, 0, 1);
        // landscape: under the HUD between the side pads (the pads already say what they do); portrait: above the bar
        const y = lay.land ? lay.top + 34 : lay.bot - 40, x0 = lay.land ? lay.cl + 4 : 48, bw = lay.land ? Math.min(420, lay.cr - lay.cl - 8) : w - 96, cx = x0 + bw / 2;
        ctx.fillStyle = 'rgba(23,19,31,.82)'; rrect(ctx, x0, y - 26, bw, 44, 12); ctx.fill();
        ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
        ctx.fillText(lay.land ? '오른쪽 「버너」를 꾹 → 천천히 올라가요' : '꾹 누르면 버너 → 천천히 올라가요', cx, y - 12, bw - 14);
        ctx.fillStyle = '#ffe08a'; ctx.fillText('높이마다 바람이 달라요. 바람 층을 골라 타세요!', cx, y + 6, bw - 14);
        ctx.globalAlpha = 1;
      }
    }
    function draw(now, rdt) {
      cv.clear();
      const w = cv.w, h = cv.h;
      if (!W || !lay) { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h); return; }
      updateCam(rdt);
      buildSky();
      ctx.drawImage(skyC, 0, 0, w, h);
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 6 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 6 : 0;
      ctx.save(); ctx.translate(sx, sy);
      drawFar();
      drawThermals(now);
      drawStormsBack(now);
      drawClouds();
      drawWind(now);
      const myb = me() >= 0 ? W.b[me()] : null;
      for (let i = 0; i < W.C.gates.length; i++) drawGate(i, false, now, myb || focusBalloon());
      drawFinish(now);
      drawTerrain(now);
      for (const b of W.b) drawShadow(b);
      drawPrediction(myb);
      const order = W.b.slice().sort((a, b) => (isMine(a.seat) ? 1 : 0) - (isMine(b.seat) ? 1 : 0));
      for (const b of order) drawBalloon(b, now);
      for (let i = 0; i < W.C.gates.length; i++) drawGate(i, true, now, myb || focusBalloon());
      drawBirds(now);
      drawStormsFront();
      drawParts();
      for (const b of order) drawTag(b);
      for (const f of floats) {
        ctx.globalAlpha = clamp(f.t * 2, 0, 1);
        txtO(f.text, clamp(X(f.x), lay.cl + 34, lay.cr - 34), Y(f.y) - (f.T - f.t) * 22, f.col, '700 14px ' + FONT);
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      if (flash > 0) { ctx.fillStyle = 'rgba(255,250,230,' + flash * 0.35 + ')'; ctx.fillRect(0, 0, w, h); }
      drawAltimeter(now);
      drawNextGateHint(now);
      drawTopHud();
      drawControls(now);
      drawOverlay(now);
    }

    let lastNow = performance.now();
    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now, Math.min(0.1, (now - lastNow) / 1000)); } catch (e) { console.error(e); }
      lastNow = now;
    });

    return {
      update(next) {
        if (!next) return;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; startRace(); }
        if (st.ph === 'race' && phase === 'count' && !host()) { phase = 'race'; cd = 0; }
        if (st.ph === 'done') { if (phase !== 'done') { phase = 'done'; releaseAll(); } }
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        window.removeEventListener('blur', releaseAll);
        cv.destroy();
      },
      _dbg: () => ({ W, st, phase, locIn, lay, camX, X, Y }),
    };
  }

  L.register({
    id: 'balloon', name: '열기구 레이스', tag: '실시간 바람 레이스', cat: '아케이드',
    blurb: '버너를 누르면 올라가고 떼면 내려가요. 높이마다 다른 바람을 골라 타고 관문 고리를 지나 결승까지! 코스 6개. 친구와는 온라인·LAN 방으로.',
    tint: '#245a7a',
    icon: '<path d="M28 5C17 5 10 12 10 21c0 8 7 14 12 20h12c5-6 12-12 12-20 0-9-7-16-18-16z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M28 5c-5 4-7 10-7 16s2 13 4 20M28 5c5 4 7 10 7 16s-2 13-4 20" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M23 41l1 5M33 41l-1 5" stroke="currentColor" stroke-width="2"/><rect x="22" y="45" width="12" height="7" rx="1.5" fill="currentColor"/><path d="M2 16h7M47 28h7M49 34h5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0, landscape: true,
    controls: [
      { id: 'burn', label: '버너 (누르고 있기)', keys: ['Space', 'ArrowUp'], pad: ['a', 'rt'] },
      { id: 'vent', label: '밸브 · 내리기 (누르고 있기)', keys: ['ArrowDown', 'KeyV'], pad: ['b', 'lt'] },
    ],
    options: [
      { id: 'course', label: '코스', choices: [{ v: -1, label: '무작위' }].concat(COURSES.map((c, i) => ({ v: i, label: c.name }))), def: -1 },
    ],
    quick: [
      '목표: 노란 관문 고리를 1번부터 차례로 지나 결승선에 가장 빨리 도착해요.',
      '할 일: 「버너」를 누르고 있으면 올라가고, 떼면 천천히 내려가요. 핸들은 없어요.',
      '이기는 법: 높이마다 바람이 달라요. 앞으로 세게 부는 바람 층을 골라 타요!',
    ],
    rules: [
      { h: '목표', p: [
        '열기구를 타고 노란 관문 고리를 1번부터 차례로 지나 결승선까지 가요.',
        '기록 = 걸린 시간 + 벌점. 기록이 빠른 사람이 1위예요.',
      ] },
      { h: '할 일 (조작)', p: [
        '버너: 누르고 있으면 불이 켜져 풍선 속 공기가 데워지고 올라가요. 떼면 공기가 식으면서 천천히 내려가요.',
        '내리기(밸브): 누르고 있으면 뜨거운 공기를 빼서 빨리 내려가요.',
        '가로 화면: 왼쪽 끝 「내리기」, 오른쪽 끝 「버너」를 엄지로 눌러요(버튼 말고 화면 아무 데나 눌러도 버너예요). 세로 화면: 아래쪽 버튼을 써요.',
        '열기구는 바로 반응하지 않아요. 공기가 데워지고 식는 데 시간이 걸려요. 그래서 미리 누르고 미리 떼는 게 요령! 같은 높이를 지키려면 톡톡 짧게 눌러요.',
        '「열」 막대: 흰 선보다 높으면 올라가고, 낮으면 내려가요. 내 열기구 앞의 점선은 지금처럼 계속하면 3초 동안 갈 길이에요.',
        'PC 키보드·게임패드: 스페이스·↑·Ⓐ·RT 버너, ↓·V·Ⓑ·LT 밸브(누르고 있기). 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '바람 읽기', p: [
        '높이마다 바람의 방향과 세기가 달라요. 가고 싶은 바람이 부는 높이로 올라가거나 내려가서 방향을 잡아요.',
        '왼쪽 「바람」 막대 = 지금 내 자리의 높이별 바람. 흰 화살표는 앞으로(결승 쪽), 빨간 화살표는 뒤로 부는 바람이고, 화살표가 많을수록 세요.',
        '바람 막대의 노란 줄은 다음 관문의 높이, 노란 삼각형은 내 높이, 색 점은 다른 열기구 높이예요.',
        '하늘의 줄무늬와 구름도 그 높이 바람을 따라 흘러가요. 코스 중간에 바람 층이 바뀌는 곳이 있어요.',
        '예시: 바람 막대 아래쪽에 빨간 화살표, 가운데에 흰 화살표 3개 → 버너를 눌러 가운데 높이까지 올라가서 그 바람을 타요.',
      ] },
      { h: '관문 · 벌점', p: [
        '관문은 위아래에 깃발이 달린 세로 고리예요. 고리 안 높이로 지나가면 「통과!」.',
        '고리를 벗어난 높이로 지나치면 「놓침」 — 기록에 벌점 ' + PEN + '초가 더해지고 다음 관문으로 넘어가요(되돌아가지 않아요).',
        '다음 관문이 화면 밖이면 오른쪽에 노란 표시로 그 높이를 알려 줘요.',
      ] },
      { h: '장애물', p: [
        '산·절벽: 바구니가 부딪히면 막혀요. 더 높이 올라가서 넘어가요.',
        '땅이나 바다에 내려앉으면 거의 못 움직여요. 버너로 다시 떠올라요.',
        '먹구름: 속에 들어가면 강하게 내려가고 바람도 약해져요. 아래 비 내리는 곳도 내려가는 바람이 불어요.',
        '새 떼: 부딪히면 뒤로 밀리고 덜컹 내려가요(2초 남짓 다시 안 부딪혀요).',
        '아지랑이 기둥(열기류): 그 안에서는 버너 없이도 쑥 올라가요.',
        '너무 높이 올라가면 공기가 희박해져서 더 오르기 힘들어요.',
        '다른 열기구와 부딪히면 서로 살짝 밀려나요. 출발하고 ' + GHOST_T + '초 동안은 그냥 겹쳐 지나가요.',
      ] },
      { h: '순위 · 끝', p: [
        '결승선을 지나면 도착. 처음 도착한 뒤 ' + AFTER_FIRST + '초가 지나거나(사람이 모두 도착하면 ' + AFTER_HUMANS + '초 뒤), 4분이 지나면 경기가 끝나요.',
        '도착하지 못한 열기구는 도착한 열기구 뒤로, 많이 간 순서대로 놓여요.',
        '예시: 1분 40초에 도착했는데 관문 1개를 놓쳤다면 기록은 1분 44초예요.',
      ] },
      { h: '코스 6개', p: [
        '설정의 「코스」에서 고르거나 무작위(기본)로 해요.',
        '초원 아침: 완만한 언덕, 첫 비행에 딱. 눈 덮인 산맥: 높은 봉우리와 골짜기 관문.',
        '천둥 구름: 먹구름 넷과 번개. 사막 협곡: 절벽 같은 바위산과 열기류.',
        '바닷가 섬: 바다 위 낮은 바람은 거꾸로, 갈매기 떼. 노을 마을: 굴뚝 열기류와 풍차 언덕.',
      ] },
      { h: '함께 하기', p: [
        '가로 화면용 게임이에요. 폰을 돌릴 수 없으면 「세로로 그냥 하기」로 세로 화면에서도 할 수 있어요.',
        '한 폰에서는 한 명만 조종해요. 혼자 하면 나머지 자리는 AI 열기구예요.',
        '친구와는 온라인·LAN 방으로 각자 폰에서 한 대씩. 계산은 호스트 폰이 해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 높이 조절이 서툴러 관문을 자주 놓치고, 어려움은 앞을 내다보고 가장 빠른 바람 층을 골라 타요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { COURSES, newWorld, stepWorld, stepBalloon, windAt, envAt, ground, groundRaw, aiThink, predictYc, ranking, birdPos, H, ENV_DY, PEN, CAP_T, AFTER_FIRST },
  });
})();
