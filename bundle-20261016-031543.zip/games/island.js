/* 무인도 7일 생존 — 반협력 생존 로그라이크(1–4인).
   판마다 섬 모양·구역(15종 중 9곳, 희귀 구역 포함)·날씨·오늘의 섬·밤 사건이 새로 정해져요.
   시작할 때 생존자(특성 12종)를 고르고, 낮엔 섬을 탐색(안개 걷기·숨은 장소·만남 사건),
   저녁엔 30가지 물건(업그레이드 포함)을 만들고, 밤엔 사건(선택지·연쇄 포함)을 견뎌요.
   유물 23종이 판 내내 효과를 줘요. 모두의 구조 신호가 목표에 닿으면 그날 밤 구조 성공,
   7일째 밤까지 못 채우거나 모두 쓰러지면 모두 실패. 성공하면 개인 점수 1등이 승리.
   기기에 기록(최고 기록·지난 판·해금)을 남겨요(선택, localStorage). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= data ======================= */
  const DAYS = 7, NS = 10, ABX = 2, CAPR = 9, COLD_D = 5;
  const RN = ['물', '음식', '나무', '재료'];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* perks (characters + relics) */
  const P_SHOREF = 1, P_FORESTW = 2, P_REST2 = 4, P_NOSICK = 8, P_NOBEAST = 16, P_NOCOLD = 32, P_NOHEAT = 64, P_NOFALL = 128,
    P_TREAS = 256, P_SUBX = 512, P_FIRE1 = 1024, P_BIGBAG = 2048, P_OMEN2 = 4096, P_SALVE = 8192, P_TOOLC = 16384,
    P_MORNF = 1 << 15, P_MORNW = 1 << 16, P_CAMPW = 1 << 17, P_EXPL = 1 << 18, P_SIG1 = 1 << 19, P_LAMP = 1 << 20,
    P_LUCK = 1 << 21, P_GOLD = 1 << 22, P_EAT2 = 1 << 23, P_EXTRA = 1 << 24, P_MORNWD = 1 << 25;

  /* tools (personal bits) */
  const T_SPEAR = 1, T_HARP = 2, T_NET = 4, T_AXE = 8, T_BIGAXE = 16, T_JUG = 32, T_SKIN = 64, T_ROPE = 128, T_HOOK = 256,
    T_TRAP = 512, T_BIGTRAP = 1024, T_TORCH = 2048, T_HAT = 4096;
  /* camp builds (shared bits) */
  const CB_RAIN = 1, CB_CIST = 2, CB_SMOK = 4, CB_FENCE = 8, CB_LOOK = 16, CB_SOS = 32, CB_BIGSOS = 64, CB_RAFT = 128;

  /* zones: kind index → data. g: S shore · F forest · W water · C rock */
  const KINDS = [
    { n: '해변 캠프', ic: '🏕', y: [0, 1, 0, 1], g: 'S', tip: '조개·표류물' },
    { n: '정글', ic: '🌳', y: [0, 1, 2, 0], g: 'F', tip: '나무·열매', sub: { n: '고대 신전', y: [0, 1, 0, 1], loot: 1 } },
    { n: '맑은 샘', ic: '💧', y: [3, 0, 0, 0], g: 'W', tip: '깨끗한 물', sub: { n: '따뜻한 온천', y: [0, 0, 0, 0], heal: 1 } },
    { n: '동굴', ic: '🕳', y: [1, 0, 0, 2], g: 'C', tr: 0.25, trn: '수정', tip: '물방울·돌', sub: { n: '지하 호수', y: [2, 0, 0, 1] } },
    { n: '절벽', ic: '⛰', y: [0, 2, 0, 2], g: 'C', fall: 0.3, tip: '새알·돌 · 미끄러워요', sub: { n: '바닷새 둥지', y: [0, 2, 0, 0] } },
    { n: '난파선', ic: '⚓', y: [0, 0, 1, 2], g: 'S', tr: 0.25, trn: '보물 상자', tip: '널빤지·쇠붙이 · 처음 가면 유물', sub: { n: '선장실', y: [0, 0, 1, 1], loot: 1 } },
    { n: '석호', ic: '🐠', y: [0, 2, 0, 0], g: 'S', tr: 0, trn: '진주', tip: '물고기 · 그물이면 진주', sub: { n: '산호초', y: [0, 1, 0, 1] } },
    { n: '야자수 숲', ic: '🌴', y: [1, 1, 1, 0], g: 'F', tip: '코코넛·나무', sub: { n: '코코넛 언덕', y: [1, 1, 0, 0] } },
    { n: '대나무 숲', ic: '🎋', y: [0, 0, 3, 0], g: 'F', tip: '곧은 나무', sub: { n: '죽순 밭', y: [0, 2, 0, 0] } },
    { n: '갯벌', ic: '🦀', y: [0, 2, 0, 1], g: 'S', tip: '조개·게', sub: { n: '굴 바위', y: [0, 1, 0, 1] } },
    { n: '습지', ic: '🐸', y: [2, 1, 0, 0], g: 'W', sick: 0.15, tip: '흙탕물·개구리 · 열병 조심', sub: { n: '약초 군락', y: [0, 0, 0, 0], heal: 1, cure: 1 } },
    { n: '화산 언덕', ic: '🌋', y: [0, 0, 0, 3], g: 'C', rare: 1, burn: 0.2, tr: 0.3, trn: '흑요석', tip: '희귀 · 돌이 많지만 뜨거워요', sub: { n: '흑요석 광맥', y: [0, 0, 0, 2] } },
    { n: '버려진 오두막', ic: '🏚', y: [0, 1, 1, 1], g: '', rare: 1, tip: '희귀 · 처음 가면 유물', sub: { n: '지하 창고', y: [1, 1, 0, 0], loot: 1 } },
    { n: '등대 폐허', ic: '🗼', y: [0, 0, 1, 2], g: 'C', rare: 1, tip: '희귀 · 처음 가면 신호 +1', sub: { n: '등대 꼭대기', y: [0, 0, 0, 0], sig: 2 } },
    { n: '폭포', ic: '🌊', y: [2, 0, 1, 0], g: 'W', tr: 0.15, trn: '금 조각', tip: '물·나무', sub: { n: '폭포 뒤 동굴', y: [0, 0, 0, 2], loot: 2 } },
  ];
  const isG = (kind, g) => KINDS[kind].g === g;
  const WATERK = [2, 7, 10, 14];

  /* survivors */
  const CH = [
    { n: '목수', ic: '🔨', pk: P_CAMPW, d: '캠프·신호 물건 나무 1 덜(나무 2개 이상 드는 것)', st: '나무 +2', r: [0, 0, 2, 0] },
    { n: '어부', ic: '🎣', pk: P_SHOREF, d: '물가(해변·석호·갯벌) 음식 +1', st: '그물', t: T_NET },
    { n: '의사', ic: '💉', pk: P_REST2 | P_NOSICK, d: '쉬기 ❤+2 · 열병·배탈에 안 걸려요', st: '물 +1', r: [1, 0, 0, 0] },
    { n: '탐험가', ic: '🧭', pk: P_EXTRA, d: '낮 일손 3번 · 대신 ❤ 최대 4', st: '없음', mh: 4 },
    { n: '군인', ic: '🎖', pk: P_NOBEAST, d: '❤ 최대 6 · 짐승에게 다치지 않아요', st: '창', t: T_SPEAR, mh: 6 },
    { n: '과학자', ic: '🔬', pk: P_TOOLC | P_SUBX, d: '도구 재료 1 덜 · 숨은 장소를 잘 찾아요', st: '재료 +2', r: [0, 0, 0, 2] },
    { n: '꼬마', ic: '🧒', pk: P_EXPL, d: '탐험 때 물자 +1·발견 +1점 · 짐은 7개까지', st: '음식 +1', r: [0, 1, 0, 0], cap: 7 },
    { n: '할머니', ic: '👵', pk: P_OMEN2 | P_SALVE, d: '징조를 이틀 앞까지 · 약 만들 때 1개 덜·더 잘 나아요', st: '물·음식 +1', r: [1, 1, 0, 0] },
    { n: '선장', ic: '⚓', pk: P_SIG1, d: '신호 물건마다 신호 +1 더', st: '없음', lock: 0 },
    { n: '보물 사냥꾼', ic: '💰', pk: P_TREAS, d: '보물 찾을 확률 +20%', st: '횃불', t: T_TORCH, lock: 1 },
    { n: '생존 전문가', ic: '🔥', pk: P_NOCOLD | P_NOHEAT, d: '추위·더위에 다치지 않아요', st: '물통', t: T_JUG, lock: 2 },
    { n: '요리사', ic: '🍳', pk: P_EAT2, d: '밤에 먹으면 배·물 칸이 2씩 차요', st: '음식 +2', r: [0, 2, 0, 0], lock: 3 },
  ];
  const NBASE = 8;
  /* relics (ids 0..22; 22 = event only) */
  const RL = [
    { n: '나침반', ic: '🧭', pk: P_EXPL, d: '탐험 때 물자 +1·발견 +1점' },
    { n: '낡은 지도', ic: '🗺', pk: P_SUBX, d: '숨은 장소를 찾을 확률 +25%' },
    { n: '부싯돌', ic: '⚡', pk: P_FIRE1, d: '불 피우기 때 불 +1 더' },
    { n: '큰 배낭', ic: '🎒', pk: P_BIGBAG, d: '짐 한도 +3' },
    { n: '행운의 조개', ic: '🐚', pk: P_TREAS, d: '보물 찾을 확률 +20%' },
    { n: '튼튼한 장화', ic: '🥾', pk: P_NOFALL, d: '미끄러짐·낙석·화상에 다치지 않아요' },
    { n: '낚싯바늘', ic: '🎣', pk: P_SHOREF, d: '물가 음식 +1' },
    { n: '쇠 냄비', ic: '🥘', pk: P_NOSICK, d: '열병·배탈에 안 걸려요' },
    { n: '털 담요', ic: '🧣', pk: P_NOCOLD, d: '불이 꺼진 밤에도 춥지 않아요' },
    { n: '망원경', ic: '🔭', pk: P_OMEN2, d: '징조를 이틀 앞까지 봐요' },
    { n: '하모니카', ic: '🎵', pk: P_REST2, d: '쉬기 ❤+2' },
    { n: '선장의 일지', ic: '📔', pk: P_SIG1, d: '신호 물건마다 신호 +1 더' },
    { n: '약초 도감', ic: '🌿', pk: P_SALVE, d: '약 만들 때 1개 덜 · ❤ +1 더' },
    { n: '주머니칼', ic: '🔪', pk: P_TOOLC, d: '도구 재료 1 덜' },
    { n: '말린 생선', ic: '🐟', pk: P_MORNF, d: '아침마다 음식 +1' },
    { n: '물 항아리', ic: '🏺', pk: P_MORNW, d: '아침마다 물 +1' },
    { n: '쇠 손도끼', ic: '🗡', pk: P_FORESTW, d: '숲 나무 +1' },
    { n: '네잎 클로버', ic: '🍀', pk: P_LUCK, d: '쓰러질 때 한 번 ❤2로 버텨요(쓰면 사라짐)' },
    { n: '금화 주머니', ic: '💰', pk: P_GOLD, d: '점수 +3', pt: 3 },
    { n: '앵무새', ic: '🐦', pk: P_NOBEAST, d: '짐승에게 다치지 않아요' },
    { n: '고래기름 등잔', ic: '🕯', pk: P_LAMP, d: '캠프 불이 밤에 줄지 않을 때가 많아요(50%)' },
    { n: '마른 장작', ic: '🌲', pk: P_MORNWD, d: '아침마다 나무 +1' },
    { n: '원숭이 친구', ic: '🐒', pk: P_MORNF, d: '아침마다 음식 +1 (열매를 가져와요)' },
  ];
  const RLDECK = 22;   // ids 0..21 are in the random deck
  const KITS = [-1, 13, 0, 4];   // start kits: 없음 · 주머니칼 · 나침반 · 행운의 조개
  /* weather · day modifiers */
  const WX = [
    { n: '맑음', ic: '☀', d: '거울 신호 +1' },
    { n: '흐림', ic: '⛅', d: '평범한 날씨' },
    { n: '비', ic: '🌧', d: '아침에 모두 물 +1 · 밤에 움막이 없으면 불 −1' },
    { n: '무더위', ic: '🥵', d: '샘·폭포 물 +1 · 밤에 물 2개 (물통·모자면 1개)' },
    { n: '강풍', ic: '💨', d: '신호 연 +1 · 절벽 더 미끄러움 · 밤에 움막 2 미만이면 불 −1' },
    { n: '안개', ic: '🌫', d: '연기·봉화 신호 −1 · 만남 사건이 잦아요' },
  ];
  const DM = [
    { n: '평범한 날', ic: '🏝', d: '특별한 일 없음' },
    { n: '썰물', ic: '🦀', d: '물가(해변·석호·갯벌) 음식 +1' },
    { n: '열매 철', ic: '🍈', d: '숲(정글·야자수·대나무) 음식 +1' },
    { n: '큰 파도', ic: '🌊', d: '해변·난파선 재료 +1' },
    { n: '철새', ic: '🐦', d: '절벽·갯벌 음식 +1' },
    { n: '기운찬 아침', ic: '💪', d: '아침에 모두 ❤+1' },
    { n: '맑은 시야', ic: '🔍', d: '숨은 장소를 찾을 확률 2배' },
    { n: '마른 바람', ic: '🔥', d: '불 피우기 때 불 +1 더' },
    { n: '느긋한 날', ic: '🍵', d: '쉬기 ❤ +1 더' },
    { n: '탐험 날씨', ic: '🗺', d: '탐험(안개 구역) 때 발견 +1점' },
  ];
  const CATS = [['☁', '날씨'], ['🐾', '짐승'], ['🌊', '바다'], ['⚠', '사고'], ['✨', '행운'], ['❓', '수수께끼']];
  const DK = ['배고픔', '목마름', '추위', '짐승', '날씨', '사고', '병'];
  const SV = ['불 켜진 밤', '움막·캠프가 막음', '나눔', '치료', '유물·도구가 막음'];
  const GOAL = { e: [13, 28, 43, 55], m: [16, 34, 51, 65], h: [19, 39, 58, 73] };

  /* recipes */
  const RC = [
    { id: 'fire', n: '불 피우기', ic: '🔥', tab: 0, c: [0, 0, 1, 0], pts: 1, d: '불 +2 (밤마다 1씩 타요, 최대 4)' },
    { id: 'hut', n: '움막 보강', ic: '⛺', tab: 0, c: [0, 0, 2, 1], pts: 2, d: '움막 +1 (최대 3) · 폭풍·추위를 막아요' },
    { id: 'rain', n: '빗물받이', ic: '☔', tab: 0, c: [0, 0, 1, 2], pts: 2, cb: CB_RAIN, d: '아침마다 모두 물 +1' },
    { id: 'cist', n: '저수조', ic: '🛢', tab: 0, c: [0, 0, 2, 2], pts: 2, cb: CB_CIST, req: CB_RAIN, up: 'rain', d: '빗물받이 강화: 아침마다 모두 물 +1 더' },
    { id: 'smokeh', n: '훈연대', ic: '🍖', tab: 0, c: [0, 1, 2, 1], pts: 2, cb: CB_SMOK, fire: 1, d: '아침마다 모두 음식 +1 (불이 켜져 있어야 지어요)' },
    { id: 'fence', n: '울타리', ic: '🚧', tab: 0, c: [0, 0, 3, 1], pts: 2, cb: CB_FENCE, d: '멧돼지·원숭이·들개 피해를 막아요' },
    { id: 'look', n: '망대', ic: '🗼', tab: 0, c: [0, 0, 2, 2], pts: 2, cb: CB_LOOK, d: '징조를 이틀 앞까지 · 짙은 안개 무사 · 지으면 안개 1곳이 걷혀요' },
    { id: 'smoke', n: '연기 신호', ic: '💨', tab: 1, c: [0, 0, 2, 0], pts: 1, sg: 1, fire: 1, d: '신호 +1 (불이 켜져 있어야 해요)' },
    { id: 'sos', n: 'SOS 글씨', ic: '🆘', tab: 1, c: [0, 0, 1, 3], pts: 2, sg: 2, cb: CB_SOS, d: '신호 +2 (한 번만)' },
    { id: 'bigsos', n: '큰 SOS', ic: '🔠', tab: 1, c: [0, 0, 2, 3], pts: 3, sg: 3, cb: CB_BIGSOS, req: CB_SOS, up: 'sos', d: 'SOS를 바위로 크게: 신호 +3 (한 번만)' },
    { id: 'beacon', n: '봉화', ic: '🏮', tab: 1, c: [0, 0, 3, 2], pts: 3, sg: 3, fire: 1, d: '신호 +3 (불이 켜져 있어야 해요)' },
    { id: 'raft', n: '뗏목', ic: '🛶', tab: 1, c: [0, 0, 4, 3], pts: 3, sg: 3, cb: CB_RAFT, d: '신호 +3 · 「지나가는 배」를 꼭 불러요 (한 번만)' },
    { id: 'kite', n: '신호 연', ic: '🎏', tab: 1, c: [0, 0, 2, 1], pts: 1, sg: 1, d: '신호 +1 · 강풍 부는 날엔 +2' },
    { id: 'mirror', n: '거울 신호', ic: '🔆', tab: 1, c: [0, 0, 0, 2], pts: 1, sg: 1, d: '신호 +1 · 맑은 날엔 +2' },
    { id: 'spear', n: '창', ic: '🔱', tab: 2, c: [0, 0, 1, 1], pts: 1, bit: T_SPEAR, d: '정글·석호 음식 +1 · 멧돼지 사냥 · 뱀 쫓기' },
    { id: 'harp', n: '작살', ic: '🔱', tab: 2, c: [0, 0, 1, 2], pts: 1, bit: T_HARP, req: T_SPEAR, up: 'spear', d: '창 강화: 물가 음식 +1 · 악어도 이겨요' },
    { id: 'net', n: '그물', ic: '🕸', tab: 2, c: [0, 0, 0, 2], pts: 1, bit: T_NET, d: '해변·석호·갯벌 음식 +1 · 석호 진주' },
    { id: 'axe', n: '돌도끼', ic: '⛏', tab: 2, c: [0, 0, 1, 2], pts: 1, bit: T_AXE, d: '숲(정글·야자수·대나무) 나무 +1' },
    { id: 'bigaxe', n: '큰 도끼', ic: '⚒', tab: 2, c: [0, 0, 2, 2], pts: 1, bit: T_BIGAXE, req: T_AXE, up: 'axe', d: '도끼 강화: 숲 나무 +1 더' },
    { id: 'jug', n: '물통', ic: '🍶', tab: 2, c: [0, 0, 2, 0], pts: 1, bit: T_JUG, d: '샘·야자수·폭포·습지 물 +1 · 더운 밤에도 물 1개' },
    { id: 'skin', n: '물주머니', ic: '🥤', tab: 2, c: [0, 1, 0, 2], pts: 1, bit: T_SKIN, req: T_JUG, up: 'jug', d: '물통 강화: 아침마다 물 +1' },
    { id: 'rope', n: '밧줄', ic: '➰', tab: 2, c: [0, 0, 2, 1], pts: 1, bit: T_ROPE, d: '절벽 안전·음식 +1 · 난파선 재료 +1 · 낙석 막기' },
    { id: 'hook', n: '갈고리 밧줄', ic: '🧗', tab: 2, c: [0, 0, 1, 2], pts: 1, bit: T_HOOK, req: T_ROPE, up: 'rope', d: '밧줄 강화: 숨은 장소 찾을 확률 +25% · 구덩이 안전' },
    { id: 'trap', n: '덫', ic: '🕳', tab: 2, c: [0, 1, 1, 1], pts: 1, bit: T_TRAP, d: '아침마다 음식 +1' },
    { id: 'bigtrap', n: '큰 덫', ic: '🕳', tab: 2, c: [0, 1, 2, 1], pts: 1, bit: T_BIGTRAP, req: T_TRAP, up: 'trap', d: '덫 강화: 아침마다 음식 +1 더' },
    { id: 'torch', n: '횃불', ic: '🔦', tab: 2, c: [0, 0, 1, 1], pts: 1, bit: T_TORCH, d: '동굴·폭포 재료 +1 · 동굴 숨은 장소 잘 찾음 · 박쥐 쫓기' },
    { id: 'hat', n: '야자 모자', ic: '👒', tab: 2, c: [0, 0, 1, 1], pts: 1, bit: T_HAT, d: '더운 날·밤에도 물 1개 · 화산 화상 막기' },
    { id: 'salve', n: '약초 연고', ic: '🌿', tab: 3, c: [1, 1, 0, 0], pts: 0, d: '❤ +2 · 열병이 나아요' },
    { id: 'tea', n: '약초차', ic: '🍵', tab: 3, c: [2, 0, 0, 0], pts: 0, fire: 1, d: '물 칸 가득 · ❤ +1 · 열병이 나아요 (불 필요)' },
    { id: 'soup', n: '모닥불 국', ic: '🍲', tab: 3, c: [1, 2, 0, 0], pts: 2, fire: 1, d: '살아 있는 모두 ❤ +1·배 칸 +1 (불 필요)' },
  ];
  const RCI = {}; RC.forEach((r, i) => { RCI[r.id] = i; });
  const TABS = [['🏕', '캠프'], ['📡', '신호'], ['🔧', '도구'], ['🌿', '약·음식']];

  /* ======================= helpers ======================= */
  const kindAt = (s, sl) => parseInt(s.m[sl], 36);
  const rvd = (s, sl) => (s.rv >> sl) & 1;
  const subOn = (s, sl) => (s.sf >> sl) & 1;
  const setc = (str, i, ch) => str.slice(0, i) + ch + str.slice(i + 1);
  const evAt = (s, i) => (i >= 0 && i < DAYS ? parseInt(s.ev[i], 36) : -1);
  const wxAt = (s, d) => +(s.w[clamp(d, 1, DAYS) - 1]);
  const dmAt = (s, d) => +(s.dm[clamp(d, 1, DAYS) - 1]);
  const tierOf = (d) => (d <= 2 ? 1 : d <= 5 ? 2 : 3);
  const aliveList = (s) => { const A = []; s.p.forEach((p, k) => { if (!p.o && p.c >= 0) A.push(k); }); return A; };
  const alive = (s) => s.p.filter((p) => !p.o).length;
  function perks(p) {
    let m = p.c >= 0 && CH[p.c] ? CH[p.c].pk : 0;
    for (let i = 0, x = p.x; x; i++, x >>>= 1) if (x & 1) m |= RL[i].pk;
    return m;
  }
  const has = (p, pk) => (perks(p) & pk) !== 0;
  const anyHas = (s, pk) => s.p.some((p) => !p.o && has(p, pk));
  const maxH = (p) => (p.c >= 0 && CH[p.c] && CH[p.c].mh) || 5;
  const capOf = (p) => ((p.c >= 0 && CH[p.c] && CH[p.c].cap) || CAPR) + (has(p, P_BIGBAG) ? 3 : 0);
  const relicN = (p) => { let c = 0; for (let x = p.x; x; x >>>= 1) c += x & 1; return c; };
  function addR(p, i, v) {
    const o = p.r[i], nv = Math.max(0, Math.min(capOf(p), o + v));
    p.r[i] = nv; return nv - o;
  }
  function addH(p, v) {
    if (p.o) return 0;
    const o = p.h, nv = Math.max(0, Math.min(maxH(p), o + v));
    p.h = nv; return nv - o;
  }
  function hurt(s, k, n, cause) { const d = -addH(s.p[k], -n); if (cause >= 0) s.dk[cause] += d; return d; }
  function heal(s, k, n) { const d = addH(s.p[k], n); if (d > 0) s.sv[3] += d; return d; }
  function gainRelic(s, k, id) {
    const p = s.p[k];
    if (id == null || id < 0) {
      if (!s.rl.length) { p.s[1] += 2; return -1; }
      id = parseInt(s.rl[0], 36); s.rl = s.rl.slice(1);
    } else s.rl = s.rl.split(id.toString(36)).join('');
    if ((p.x >> id) & 1) { p.s[1] += 2; return -1; }
    p.x |= 1 << id; p.s[1] += RL[id].pt || 1;
    return id;
  }
  /* layout from seed: 3×4 jittered grid; camp is bottom middle. Shared by rules (adjacency) and view (positions). */
  function rng(seed) { let a = seed | 0; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const GEO = {};
  function geo(sd) {
    if (GEO[sd]) return GEO[sd];
    const R = rng(sd), cells = [];
    for (let r = 0; r < 4; r++) for (let c = 0; c < 3; c++) if (!(r === 3 && c === 1)) cells.push([c, r]);
    for (let i = cells.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); [cells[i], cells[j]] = [cells[j], cells[i]]; }
    const all = [[1, 3]].concat(cells.slice(0, NS - 1));
    const rowOff = [0, 1, 2, 3].map(() => (R() - 0.5) * 0.36);
    const u = [], v = [], at = {};
    all.forEach(([c, r], i) => {
      at[c + ',' + r] = i;
      u.push((c + 0.5 + (i ? (R() - 0.5) * 0.3 + rowOff[r] : 0)) / 3);
      v.push((r + 0.5 + (i ? (R() - 0.5) * 0.26 : 0.1)) / 4);
    });
    const E = [], key = {};
    const link = (a, b) => { if (a == null || b == null || a === b) return; const kk = Math.min(a, b) + '-' + Math.max(a, b); if (key[kk]) return; key[kk] = 1; E.push([a, b]); };
    all.forEach(([c, r], i) => { link(i, at[(c + 1) + ',' + r]); link(i, at[c + ',' + (r + 1)]); });
    const diag = [];
    for (let r = 0; r < 3; r++) for (let c = 0; c < 2; c++) {
      const main = R() < 0.5, A = main ? [c + ',' + r, (c + 1) + ',' + (r + 1)] : [(c + 1) + ',' + r, c + ',' + (r + 1)];
      const B = main ? [(c + 1) + ',' + r, c + ',' + (r + 1)] : [c + ',' + r, (c + 1) + ',' + (r + 1)];
      const tl = at[c + ',' + r] != null, tr = at[(c + 1) + ',' + r] != null, bl = at[c + ',' + (r + 1)] != null, br = at[(c + 1) + ',' + (r + 1)] != null;
      const full = tl && tr && bl && br;
      link(at[A[0]], at[A[1]]);
      if (!full) diag.push(B);
    }
    const adj = () => { const a = all.map(() => []); for (const [x, y] of E) { a[x].push(y); a[y].push(x); } return a; };
    const conn = (a) => { const seen = [0], q = [0]; const S = { 0: 1 }; while (q.length) { const x = q.pop(); for (const y of a[x]) if (!S[y]) { S[y] = 1; seen.push(y); q.push(y); } } return seen.length === all.length; };
    let A = adj();
    for (const B of diag) { if (conn(A)) break; link(at[B[0]], at[B[1]]); A = adj(); }
    GEO[sd] = { u, v, adj: A, E };
    return GEO[sd];
  }
  const reach = (s, sl) => rvd(s, sl) || geo(s.sd).adj[sl].some((j) => rvd(s, j));

  /* yields */
  function kindYield(s, k, kind, sub) {
    const p = s.p[k], t = p.t, y = KINDS[kind].y.slice(), pk = perks(p), wx = wxAt(s, s.d), dm = dmAt(s, s.d);
    if (sub && KINDS[kind].sub) for (let i = 0; i < 4; i++) y[i] += KINDS[kind].sub.y[i];
    const shore = kind === 0 || kind === 6 || kind === 9, forest = isG(kind, 'F'), water = WATERK.indexOf(kind) >= 0;
    if (t & T_SPEAR && (kind === 1 || kind === 6)) y[1]++;
    if (t & T_HARP && shore) y[1]++;
    if (t & T_NET && shore) y[1]++;
    if (t & T_AXE && forest) y[2]++;
    if (t & T_BIGAXE && forest) y[2]++;
    if (t & T_JUG && water) y[0]++;
    if (t & T_ROPE && kind === 4) y[1]++;
    if (t & T_ROPE && kind === 5) y[3]++;
    if (t & T_TORCH && (kind === 3 || kind === 14)) y[3]++;
    if (pk & P_SHOREF && shore) y[1]++;
    if (pk & P_FORESTW && forest) y[2]++;
    if (wx === 3 && (kind === 2 || kind === 14)) y[0]++;
    if (dm === 1 && shore) y[1]++;
    if (dm === 2 && forest) y[1]++;
    if (dm === 3 && (kind === 0 || kind === 5)) y[3]++;
    if (dm === 4 && (kind === 4 || kind === 9)) y[1]++;
    return y;
  }
  const zoneYield = (s, k, sl) => kindYield(s, k, kindAt(s, sl), subOn(s, sl));
  function halfY(y) {
    let mi = 0; for (let i = 1; i < 4; i++) if (y[i] > y[mi]) mi = i;
    const o = y.map((v) => v >> 1); if (!o[mi]) o[mi] = 1;
    return o;
  }
  const gatherYield = (s, k, sl) => (+s.ab[sl] > 0 ? zoneYield(s, k, sl) : halfY(zoneYield(s, k, sl)));
  function treasureP(s, k, kind) {
    const p = s.p[k];
    let tp = kind === 6 ? (p.t & T_NET ? 0.25 : 0) : KINDS[kind].tr || 0;
    if (tp && has(p, P_TREAS)) tp += 0.2;
    return tp;
  }
  function subP(s, k, sl) {
    const kind = kindAt(s, sl);
    if (!KINDS[kind].sub || subOn(s, sl)) return 0;
    const p = s.p[k];
    let c = 0.25;
    if (has(p, P_SUBX)) c += 0.25;
    if (p.t & T_HOOK) c += 0.25;
    if (p.t & T_TORCH && (kind === 3 || kind === 14)) c += 0.2;
    if (dmAt(s, s.d) === 6) c *= 2;
    return Math.min(0.9, c);
  }
  function hazardP(s, k, kind) {   // [chance, cause]
    const p = s.p[k];
    if (KINDS[kind].fall && !(p.t & T_ROPE) && !has(p, P_NOFALL)) return [KINDS[kind].fall * (wxAt(s, s.d) === 4 ? 1.5 : 1), 5];
    if (KINDS[kind].burn && !(p.t & T_HAT) && !has(p, P_NOFALL)) return [KINDS[kind].burn, 5];
    if (KINDS[kind].sick && !has(p, P_NOSICK) && !p.k) return [KINDS[kind].sick, 6];
    return [0, 0];
  }
  const keep = (p) => Math.floor((p.r[0] + p.r[1] + p.r[2] + p.r[3]) / 3);
  const total = (p) => p.s[0] + p.s[1] + p.s[2] + p.s[3] + (p.o ? 0 : p.h + keep(p));
  function costOf(s, k, ri) {
    const R = RC[ri], p = s.p[k], c = R.c.slice();
    if (!p) return c;
    if ((R.tab === 0 || R.tab === 1) && has(p, P_CAMPW) && c[2] >= 2) c[2]--;
    if (R.tab === 2 && has(p, P_TOOLC) && c[3] > 0) c[3]--;
    if (R.tab === 3 && R.id !== 'soup' && has(p, P_SALVE)) { if (c[1] > 0) c[1]--; else if (c[0] > 0) c[0]--; }
    return c;
  }
  function sigAmt(s, k, ri) {
    const R = RC[ri]; if (!R.sg) return 0;
    let g = R.sg + (has(s.p[k], P_SIG1) ? 1 : 0);
    const wx = wxAt(s, s.d);
    if (R.id === 'kite' && wx === 4) g++;
    if (R.id === 'mirror' && wx === 0) g++;
    if ((R.id === 'smoke' || R.id === 'beacon') && wx === 5) g--;
    return Math.max(1, g);
  }
  function canMake(s, k, ri) {
    const p = s.p[k], R = RC[ri];
    if (!R) return '없는 물건이에요';
    const c = costOf(s, k, ri);
    for (let i = 0; i < 4; i++) if (p.r[i] < c[i]) return RN[i] + '이(가) 모자라요';
    if (R.bit && p.t & R.bit) return '이미 가지고 있어요';
    if (R.bit && R.req && !(p.t & R.req)) return '먼저 ' + RC[RCI[R.up]].n + '이(가) 있어야 해요';
    if (R.cb && s.cb & R.cb) return '이미 지었어요';
    if (R.cb && R.req && !(s.cb & R.req)) return '먼저 ' + RC[RCI[R.up]].n + '을(를) 지어야 해요';
    if (R.fire && s.fi < 1) return '불이 켜져 있어야 해요';
    if (R.sg && s.sg >= s.G) return '신호는 이미 충분해요';
    if (R.id === 'fire' && s.fi >= 4) return '불이 이미 활활 타요';
    if (R.id === 'hut' && s.sh >= 3) return '움막이 이미 튼튼해요';
    if (R.id === 'salve' && p.h >= maxH(p) && !p.k) return '아픈 데가 없어요';
    if (R.id === 'tea' && p.h >= maxH(p) && !p.k && p.b >= 3) return '지금은 필요 없어요';
    if (R.id === 'soup' && !s.p.some((q) => !q.o && (q.h < maxH(q) || q.a < 3))) return '모두 배부르고 건강해요';
    return '';
  }
  function giveTarget(s, k, ri) {
    let best = -1, bv = 1e9;
    for (let j = 1; j < s.n; j++) {
      const q = (k + j) % s.n, p = s.p[q];
      if (p.o) continue;
      const v = (ri === 0 ? p.b : p.a) * 2 + p.r[ri];
      if (v < bv) { bv = v; best = q; }
    }
    return best;
  }
  function revealSome(s, k, n) {   // reveal n reachable fog zones (+1 discovery each)
    let got = 0;
    for (let t = 0; t < n; t++) {
      const c = []; for (let sl = 1; sl < NS; sl++) if (!rvd(s, sl) && reach(s, sl)) c.push(sl);
      if (!c.length) break;
      const sl = c[Math.floor(Math.random() * c.length)];
      s.rv |= 1 << sl; if (k >= 0) s.p[k].s[0] += 1; got++;
    }
    return got;
  }
  function loseMost(p, n) {
    let lost = 0;
    for (let t = 0; t < n; t++) { let mi = 0; for (let i = 1; i < 4; i++) if (p.r[i] > p.r[mi]) mi = i; if (p.r[mi] <= 0) break; p.r[mi]--; lost++; }
    return lost;
  }

  /* ======================= events =======================
     t:0 night (automatic f, or options o chosen by the day's leader), t:1 day encounter (chosen by the visitor).
     chain:1 = only appears through another event. X = context (see ctx()). */
  const F_WARN = 1;
  const isBeast = (e) => EVS[e] && EVS[e].c === 1;
  const EVS = [
    /* 0 */ { t: 0, n: '폭풍', ic: '⛈', c: 0, tr: [2, 3], d: '움막이 2 미만이면 모두 ❤−1·움막 −1·불이 꺼져요. 움막 2 이상이면 불 −1만.',
      f(X) { const s = X.s; if (s.sh >= 2) { X.fire(-1); s.sv[1]++; } else { s.fi = 0; for (const k of X.A) X.hurt(k, 1, 4); X.hut(-1); } } },
    /* 1 */ { t: 0, n: '장대비', ic: '🌧', c: 0, tr: [1, 2], d: '모두 물 +1 (빗물받이가 있으면 +2). 움막이 없으면 불 −1.',
      f(X) { for (const k of X.A) X.res(k, 0, X.s.cb & CB_RAIN ? 2 : 1); if (X.s.sh < 1) X.fire(-1); } },
    /* 2 */ { t: 0, n: '열대야', ic: '🥵', c: 0, tr: [2, 3], d: '오늘 밤엔 물을 2개 마셔요. (물통·야자 모자가 있으면 1개)', f(X) { X.heat = 1; } },
    /* 3 */ { t: 0, n: '짙은 안개', ic: '🌫', c: 0, tr: [1, 3], d: '연기가 안 보여요. 신호 −1. (망대가 있으면 무사)',
      f(X) { if (X.s.cb & CB_LOOK) X.s.sv[1]++; else X.sig(-1); } },
    /* 4 */ { t: 0, n: '맑은 밤하늘', ic: '🌌', c: 4, tr: [1, 3], d: '불이 켜져 있으면 멀리서도 보여요. 신호 +1.', f(X) { if (X.lit) X.sig(1); } },
    /* 5 */ { t: 0, n: '멧돼지', ic: '🐗', c: 1, tr: [1, 3], d: '멧돼지가 캠프로 달려와요! 어떻게 할까요?', o: [
      { l: '창으로 사냥', r: '창 가진 사람마다 음식 +2·1점 · 30% 사냥꾼 1명 ❤−1',
        need(X) { return X.A.some((k) => X.s.p[k].t & T_SPEAR) ? '' : '창을 가진 사람이 없어요'; },
        f(X) { const H = X.A.filter((k) => X.s.p[k].t & T_SPEAR); for (const k of H) { X.res(k, 1, 2); X.pts(k, 1, 1); } if (!X.roll(0.7)) { const k = X.pick(H); if (!X.has(P_NOBEAST, k)) X.hurt(k, 1, 3); } } },
      { l: '불로 쫓기', r: '내 나무 −1 · 피해 없음', need(X) { return X.p.r[2] >= 1 ? '' : '나무가 없어요'; }, f(X) { X.res(X.k, 2, -1); X.s.sv[1]++; } },
      { l: '숨죽이기', r: '모두 음식 −1 (울타리가 있으면 무사)', f(X) { if (X.s.cb & CB_FENCE) { X.s.sv[1]++; return; } for (const k of X.A) if (!X.has(P_NOBEAST, k)) X.res(k, 1, -1); } }] },
    /* 6 */ { t: 0, n: '원숭이 도둑', ic: '🐒', c: 1, tr: [1, 2], d: '음식이 가장 많은 사람이 음식 −2 (불이 켜져 있으면 −1, 울타리면 무사).',
      f(X) { const s = X.s; if (s.cb & CB_FENCE) { s.sv[1]++; return; } let mx = 0; for (const k of X.A) mx = Math.max(mx, s.p[k].r[1]); if (!mx) return; const k = X.pick(X.A.filter((j) => s.p[j].r[1] === mx)); if (X.has(P_NOBEAST, k)) { s.sv[4]++; return; } X.res(k, 1, X.lit ? -1 : -2); X.hit(k); } },
    /* 7 */ { t: 0, n: '독뱀', ic: '🐍', c: 1, tr: [2, 3], d: '오늘 숲에 간 사람 중 1명 ❤−1. (창·장화가 있으면 무사)',
      f(X) { const s = X.s, c = X.A.filter((k) => s.p[k].z & ((1 << 1) | (1 << 7) | (1 << 8) | (1 << 10))); if (!c.length) return; const k = X.pick(c); X.hit(k); if (s.p[k].t & T_SPEAR || X.has(P_NOFALL | P_NOBEAST, k)) s.sv[4]++; else X.hurt(k, 1, 3); } },
    /* 8 */ { t: 0, n: '모기떼', ic: '🦟', c: 1, tr: [1, 3], d: '불이 꺼져 있으면 모두 ❤−1.', f(X) { if (X.lit) { X.s.sv[0]++; return; } for (const k of X.A) X.hurt(k, 1, 3); } },
    /* 9 */ { t: 0, n: '게떼', ic: '🦀', c: 2, tr: [1, 2], d: '모두 음식 +1. 해변이 다시 풍부해져요.', f(X) { for (const k of X.A) X.res(k, 1, 1); X.s.ab = setc(X.s.ab, 0, String(ABX)); } },
    /* 10 */ { t: 0, n: '상어 출몰', ic: '🦈', c: 2, tr: [2, 3], d: '내일은 해변·석호·갯벌에 못 가요.',
      f(X) { for (let sl = 0; sl < NS; sl++) { const kd = kindAt(X.s, sl); if (kd === 0 || kd === 6 || kd === 9) X.cl |= 1 << sl; } } },
    /* 11 */ { t: 0, n: '표류물', ic: '📦', c: 2, tr: [1, 2], d: '파도에 짐이 떠밀려 와요!', o: [
      { l: '헤엄쳐 건지기', r: '내 나무 +2·재료 +2 · 30% ❤−1', f(X) { X.res(X.k, 2, 2); X.res(X.k, 3, 2); if (!X.roll(0.7)) X.hurt(X.k, 1, 5); } },
      { l: '밀려올 때까지 기다리기', r: '모두 나무 +1 (안전)', f(X) { for (const k of X.A) X.res(k, 2, 1); } }] },
    /* 12 */ { t: 0, n: '거북이 알', ic: '🐢', c: 2, tr: [1, 2], d: '오늘 물가에 간 사람 음식 +2 (아무도 안 갔으면 모두 +1).',
      f(X) { const s = X.s, c = X.A.filter((k) => s.p[k].z & ((1 << 0) | (1 << 6) | (1 << 9))); if (c.length) for (const k of c) X.res(k, 1, 2); else for (const k of X.A) X.res(k, 1, 1); } },
    /* 13 */ { t: 0, n: '지나가는 배', ic: '🚢', c: 2, tr: [2, 3], d: '불이 켜져 있고 신호가 절반 이상이면 신호 +3. (뗏목이 있으면 꼭)',
      f(X) { const s = X.s; if ((X.lit && s.sg * 2 >= s.G) || s.cb & CB_RAFT) X.sig(3); } },
    /* 14 */ { t: 0, n: '열병', ic: '🤒', c: 3, tr: [2, 3], d: '목이 가장 마른 사람이 열병: 낮 일손 −1, 밤마다 ❤−1. 쉬기·약으로 나아요.',
      f(X) { const s = X.s, c = X.A.filter((k) => !s.p[k].k && !X.has(P_NOSICK, k)); if (!c.length) { s.sv[4]++; return; } let mn = 1e9; for (const k of c) mn = Math.min(mn, s.p[k].b * 3 + s.p[k].r[0]); const k = X.pick(c.filter((j) => s.p[j].b * 3 + s.p[j].r[0] === mn)); s.p[k].k = 1; X.sk = k; } },
    /* 15 */ { t: 0, n: '배탈', ic: '🤢', c: 3, tr: [1, 3], d: '무작위 1명 배 칸 −1. (쇠 냄비·의사는 무사)',
      f(X) { const c = X.A.filter((k) => !X.has(P_NOSICK, k)); if (!c.length) { X.s.sv[4]++; return; } const k = X.pick(c); X.s.p[k].a = Math.max(0, X.s.p[k].a - 1); X.hit(k); } },
    /* 16 */ { t: 0, n: '낙석', ic: '⛰', c: 3, tr: [2, 3], d: '오늘 동굴·절벽에 간 사람 ❤−1 (밧줄·장화면 무사). 내일은 동굴에 못 가요.',
      f(X) { const s = X.s; for (const k of X.A) if (s.p[k].z & ((1 << 3) | (1 << 4))) { X.hit(k); if (s.p[k].t & T_ROPE || X.has(P_NOFALL, k)) s.sv[4]++; else X.hurt(k, 1, 5); } for (let sl = 0; sl < NS; sl++) if (kindAt(s, sl) === 3) X.cl |= 1 << sl; } },
    /* 17 */ { t: 0, n: '별똥별', ic: '🌠', c: 4, tr: [1, 3], d: '소원을 빌었어요. 모두 ❤+1.', f(X) { for (const k of X.A) X.heal(k, 1); } },
    /* 18 */ { t: 0, n: '고요한 밤', ic: '🌙', c: 4, tr: [1, 2], d: '푹 잤어요. 움막이 있으면 모두 ❤+1.', f(X) { if (X.s.sh >= 1) for (const k of X.A) X.heal(k, 1); } },
    /* 19 */ { t: 0, n: '불똥', ic: '🎇', c: 3, tr: [2, 3], d: '불이 3 이상이면 불똥이 튀어 움막 −1·불 −1.',
      f(X) { if (X.s.fi >= 3) { X.hut(-1); X.fire(-1); } } },
    /* 20 */ { t: 0, n: '해일 경보', ic: '🌊', c: 2, tr: [3, 3], d: '바다가 이상하게 물러나요! 큰 파도가 올지도 몰라요.', o: [
      { l: '높은 곳으로 대피', r: '모두 무사 · 대신 불이 꺼져요', f(X) { X.s.fi = 0; X.s.sv[1]++; } },
      { l: '캠프 지키기', r: '50% 무사 · 50% 신호 −2·움막 −1·모두 ❤−1', f(X) { if (X.roll(0.5)) return; X.sig(-2); X.hut(-1); for (const k of X.A) X.hurt(k, 1, 4); } }] },
    /* 21 */ { t: 0, n: '들개 무리', ic: '🐺', c: 1, tr: [3, 3], d: '불이 꺼져 있으면 모두 ❤−1·음식 −1. 불이 켜져 있으면 음식 가장 많은 사람 음식 −1. (울타리면 무사)',
      f(X) { const s = X.s; if (s.cb & CB_FENCE) { s.sv[1]++; return; } if (X.lit) { let mx = 0; for (const k of X.A) mx = Math.max(mx, s.p[k].r[1]); if (mx) { const k = X.pick(X.A.filter((j) => s.p[j].r[1] === mx)); if (!X.has(P_NOBEAST, k)) X.res(k, 1, -1); } return; } for (const k of X.A) { if (X.has(P_NOBEAST, k)) { s.sv[4]++; continue; } X.hurt(k, 1, 3); X.res(k, 1, -1); } } },
    /* 22 */ { t: 0, n: '이상한 불빛', ic: '💫', c: 5, tr: [1, 2], d: '숲 너머에서 깜빡이는 불빛이 보여요.', o: [
      { l: '따라가 보기', r: '50% 내일 밤 「다른 생존자 캠프」 · 50% 길을 잃어 ❤−1', f(X) { if (X.roll(0.5)) X.next(26); else X.hurt(X.k, 1, 5); } },
      { l: '무시하기', r: '아무 일도 없어요', f() {} }] },
    /* 23 */ { t: 0, n: '고래 좌초', ic: '🐋', c: 2, tr: [2, 3], d: '커다란 고래가 해변에 올라왔어요.', o: [
      { l: '고기·기름 얻기', r: '모두 음식 +2 · 내 재료 +2', f(X) { for (const k of X.A) X.res(k, 1, 2); X.res(X.k, 3, 2); } },
      { l: '바다로 돌려보내기', r: '모두 ❤+1 · 신호 +1 (밤새 불을 크게 피워요)', f(X) { for (const k of X.A) X.heal(k, 1); X.sig(1); } }] },
    /* 24 */ { t: 0, n: '그믐밤', ic: '🌑', c: 0, tr: [3, 3], d: '칠흑 같은 밤. 불이 꺼져 있으면 모두 ❤−1 (담요 무사), 켜져 있으면 장작이 더 들어 불 −1.',
      f(X) { const s = X.s; if (X.lit) { X.fire(-1); return; } for (const k of X.A) { if (X.has(P_NOCOLD, k)) { s.sv[4]++; continue; } X.hurt(k, 1, 2); } } },
    /* 25 */ { t: 0, n: '유령선', ic: '👻', c: 5, tr: [2, 3], d: '안개 속에 낡은 배가 떠 있어요…', o: [
      { l: '헤엄쳐 가 보기', r: '40% 유물 · 60% ❤−1', f(X) { if (X.roll(0.4)) X.relic(X.k); else X.hurt(X.k, 1, 5); } },
      { l: '불을 흔들어 신호', r: '신호 +1 · 불 −1 (불이 켜져 있어야 해요)', need(X) { return X.lit ? '' : '불이 꺼져 있어요'; }, f(X) { X.sig(1); X.fire(-1); } },
      { l: '못 본 척', r: '아무 일도 없어요', f() {} }] },
    /* 26 */ { t: 0, chain: 1, n: '다른 생존자 캠프', ic: '🏕', c: 4, tr: [1, 3], d: '불빛의 주인은 다른 생존자들! 신호탄과 물건을 나눠 줬어요. 고른 사람 유물 · 신호 +2.',
      f(X) { X.relic(X.k); X.sig(2); } },
    /* 27 */ { t: 0, chain: 1, n: '보물 지도의 X', ic: '✖', c: 4, tr: [1, 3], d: '벽화가 가리킨 곳을 팠더니! 고른 사람 유물 +, 숨은 장소 1곳이 드러나요.',
      f(X) { X.relic(X.k); const s = X.s, c = []; for (let sl = 1; sl < NS; sl++) if (KINDS[kindAt(s, sl)].sub && !subOn(s, sl)) c.push(sl); if (c.length) { const sl = X.pick(c); s.sf |= 1 << sl; s.rv |= 1 << sl; } } },
    /* 28 */ { t: 0, chain: 1, n: '표류자의 보답', ic: '🙏', c: 4, tr: [1, 3], d: '도와준 표류자가 물고기와 물을 가져왔어요. 모두 음식 +1·물 +1, 신호 +1.',
      f(X) { for (const k of X.A) { X.res(k, 0, 1); X.res(k, 1, 1); } X.sig(1); } },
    /* 29 */ { t: 0, chain: 1, n: '표류자의 앙갚음', ic: '😠', c: 3, tr: [1, 3], d: '짐을 털린 표류자가 밤에 몰래 와서 가져갔어요. 짐이 가장 많은 사람 물자 −3.',
      f(X) { const s = X.s; let mx = -1, w = -1; for (const k of X.A) { const t = s.p[k].r.reduce((a, b) => a + b, 0); if (t > mx) { mx = t; w = k; } } if (w >= 0) { loseMost(s.p[w], 3); X.hit(w); } } },
    /* 30 */ { t: 0, n: '화산 진동', ic: '🌋', c: 3, tr: [2, 3], vol: 1, d: '땅이 흔들리고 재가 떨어져요. 움막이 없으면 모두 ❤−1. 내일은 화산 언덕에 못 가요.',
      f(X) { const s = X.s; if (s.sh < 1) for (const k of X.A) X.hurt(k, 1, 4); else s.sv[1]++; for (let sl = 0; sl < NS; sl++) if (kindAt(s, sl) === 11) X.cl |= 1 << sl; } },
    /* 31 */ { t: 0, n: '반딧불이', ic: '✨', c: 4, tr: [1, 2], d: '반딧불이를 따라가니 길이 보여요. 안개 구역 1곳이 걷혀요.', f(X) { revealSome(X.s, -1, 1); } },
    /* ---- day encounters ---- */
    /* 32 */ { t: 1, n: '표류자 발견', ic: '🧑', c: 5, tr: [1, 3], z: [0, 5, 6, 9], d: '모래밭에 지친 표류자가 쓰러져 있어요.', o: [
      { l: '도와주기', r: '물 −1·음식 −1 · 기여 +2점 · 오늘 밤 「표류자의 보답」', need(X) { return X.p.r[0] >= 1 && X.p.r[1] >= 1 ? '' : '물·음식이 1개씩 있어야 해요'; },
        f(X) { X.res(X.k, 0, -1); X.res(X.k, 1, -1); X.pts(X.k, 2, 2); X.s.sv[2]++; X.tonight(28); } },
      { l: '짐만 뒤지기', r: '재료 +2·나무 +1 · 50% 오늘 밤 「앙갚음」', f(X) { X.res(X.k, 3, 2); X.res(X.k, 2, 1); if (!X.roll(0.5)) X.tonight(29); } },
      { l: '못 본 척', r: '아무 일도 없어요', f() {} }] },
    /* 33 */ { t: 1, n: '동굴 벽화', ic: '🎨', c: 5, tr: [1, 3], z: [3, 1, 14], d: '바위벽에 섬 지도 같은 그림이 있어요.', o: [
      { l: '벽화 베끼기', r: '내일 밤 「보물 지도의 X」(유물·숨은 장소)', f(X) { X.next(27); } },
      { l: '벽 틈 파기', r: '재료 +2 · 30% 돌이 떨어져 ❤−1', f(X) { X.res(X.k, 3, 2); if (!X.roll(0.7)) { if (X.has(P_NOFALL)) X.s.sv[4]++; else X.hurt(X.k, 1, 5); } } }] },
    /* 34 */ { t: 1, n: '벌집', ic: '🍯', c: 1, tr: [1, 3], z: [1, 7, 8], d: '나무 위에 꿀이 가득한 벌집!', o: [
      { l: '연기로 따기', r: '나무 −1 · 음식 +3 (안전)', need(X) { return X.p.r[2] >= 1 ? '' : '나무가 없어요'; }, f(X) { X.res(X.k, 2, -1); X.res(X.k, 1, 3); } },
      { l: '맨손으로 따기', r: '음식 +3 · 50% 벌에 쏘여 ❤−1', f(X) { X.res(X.k, 1, 3); if (!X.roll(0.5)) { if (X.has(P_NOBEAST)) X.s.sv[4]++; else X.hurt(X.k, 1, 3); } } },
      { l: '지나가기', r: '아무 일도 없어요', f() {} }] },
    /* 35 */ { t: 1, n: '뱀과 마주침', ic: '🐍', c: 1, tr: [1, 3], z: [1, 8, 10], d: '발밑에서 뱀이 고개를 들어요!', o: [
      { l: '창으로 쫓기', r: '음식 +2 · 1점 (창 필요)', need(X) { return X.p.t & T_SPEAR ? '' : '창이 없어요'; }, f(X) { X.res(X.k, 1, 2); X.pts(X.k, 1, 1); } },
      { l: '천천히 물러나기', r: '가장 많은 물자 −1', f(X) { loseMost(X.p, 1); } },
      { l: '뛰어 도망', r: '40% 물려서 ❤−1', f(X) { if (!X.roll(0.6)) { if (X.has(P_NOBEAST)) X.s.sv[4]++; else X.hurt(X.k, 1, 3); } } }] },
    /* 36 */ { t: 1, n: '병 속 편지', ic: '🍾', c: 2, tr: [1, 3], z: [0, 6, 9], d: '파도에 병이 떠밀려 왔어요. 안에 지도가 들어 있어요!', o: [
      { l: '배 다니는 길 표시하기', r: '오늘 밤 「지나가는 배」 · 1점', f(X) { X.tonight(13); X.pts(X.k, 0, 1); } },
      { l: '병으로 거울 신호', r: '신호 +1', f(X) { X.sig(1); } }] },
    /* 37 */ { t: 1, n: '아기 원숭이', ic: '🐒', c: 1, tr: [1, 3], z: [1, 7], d: '배고픈 아기 원숭이가 졸졸 따라와요.', o: [
      { l: '음식 나눠 주기', r: '음식 −1 · 유물 「원숭이 친구」(아침마다 음식 +1)', need(X) { return X.p.r[1] >= 1 ? '' : '음식이 없어요'; }, f(X) { X.res(X.k, 1, -1); X.relic(X.k, 22); } },
      { l: '쫓아내기', r: '아무 일도 없어요', f() {} }] },
    /* 38 */ { t: 1, n: '해골과 일기', ic: '💀', c: 5, tr: [1, 3], z: [5, 12, 3], d: '오래전 이 섬에 왔던 사람의 흔적이에요.', o: [
      { l: '일기 읽기', r: '안개 구역 2곳이 걷혀요 (발견 +1점씩)', f(X) { revealSome(X.s, X.k, 2); } },
      { l: '주머니 뒤지기', r: '50% 유물 · 50% 열병', f(X) { if (X.roll(0.5)) X.relic(X.k); else if (X.has(P_NOSICK)) X.s.sv[4]++; else X.p.k = 1; } }] },
    /* 39 */ { t: 1, n: '깊은 구덩이', ic: '🕳', c: 3, tr: [2, 3], d: '바닥에 뭔가 반짝이는 구덩이!', o: [
      { l: '밧줄로 내려가기', r: '보물 +2점 · 50% 유물 (밧줄 필요)', need(X) { return X.p.t & T_ROPE ? '' : '밧줄이 없어요'; }, f(X) { X.pts(X.k, 1, 2); if (X.roll(0.5)) X.relic(X.k); } },
      { l: '뛰어내리기', r: '보물 +2점 · 50% ❤−1 (갈고리 밧줄이면 무사)', f(X) { X.pts(X.k, 1, 2); if (!(X.p.t & T_HOOK) && !X.roll(0.5)) { if (X.has(P_NOFALL)) X.s.sv[4]++; else X.hurt(X.k, 1, 5); } } },
      { l: '지나가기', r: '아무 일도 없어요', f() {} }] },
    /* 40 */ { t: 1, n: '소용돌이 속 상자', ic: '🌀', c: 2, tr: [1, 3], z: [0, 6, 9], d: '물살이 도는 곳에 상자가 걸려 있어요.', o: [
      { l: '헤엄쳐 가져오기', r: '60% 유물 · 40% ❤−1', f(X) { if (X.roll(0.6)) X.relic(X.k); else X.hurt(X.k, 1, 5); } },
      { l: '포기하기', r: '아무 일도 없어요', f() {} }] },
    /* 41 */ { t: 1, n: '이상한 버섯', ic: '🍄', c: 5, tr: [1, 3], z: [1, 8, 10], d: '처음 보는 알록달록한 버섯이에요.', o: [
      { l: '먹어 보기', r: '50% ❤+2 · 50% 배 칸 −2', f(X) { if (X.roll(0.5)) X.heal(X.k, 2); else X.p.a = Math.max(0, X.p.a - 2); } },
      { l: '모아 가기', r: '음식 +1', f(X) { X.res(X.k, 1, 1); } }] },
    /* 42 */ { t: 1, n: '앵무새', ic: '🐦', c: 1, tr: [1, 3], z: [1, 7, 14], d: '말하는 앵무새가 어깨에 앉았어요!', o: [
      { l: '길들이기', r: '음식 −1 · 유물 「앵무새」(짐승에게 안 다침)', need(X) { return X.p.r[1] >= 1 ? '' : '음식이 없어요'; }, f(X) { X.res(X.k, 1, -1); X.relic(X.k, 19); } },
      { l: '날려 보내기', r: '아무 일도 없어요', f() {} }] },
    /* 43 */ { t: 1, n: '화산 불씨', ic: '🔥', c: 3, tr: [1, 3], z: [11], d: '바위틈에서 뜨거운 불씨가 올라와요.', o: [
      { l: '불씨 가져가기', r: '캠프 불 +2 · 20% 화상 ❤−1', f(X) { X.fire(2); if (!X.roll(0.8)) { if (X.has(P_NOFALL) || X.p.t & T_HAT) X.s.sv[4]++; else X.hurt(X.k, 1, 5); } } },
      { l: '흑요석 캐기', r: '재료 +3 · 30% 화상 ❤−1', f(X) { X.res(X.k, 3, 3); if (!X.roll(0.7)) { if (X.has(P_NOFALL) || X.p.t & T_HAT) X.s.sv[4]++; else X.hurt(X.k, 1, 5); } } }] },
    /* 44 */ { t: 1, n: '커다란 소라', ic: '🐚', c: 2, tr: [1, 3], z: [0, 6, 9], d: '귀에 대면 파도 소리가 나는 소라예요.', o: [
      { l: '나팔처럼 불기', r: '신호 +1', f(X) { X.sig(1); } },
      { l: '목걸이 만들기', r: '보물 +2점', f(X) { X.pts(X.k, 1, 2); } }] },
    /* 45 */ { t: 1, n: '박쥐 떼', ic: '🦇', c: 1, tr: [1, 3], z: [3, 14], d: '어둠 속에서 박쥐 떼가 날아올라요!', o: [
      { l: '횃불로 쫓기', r: '보물 +2점 · 숨은 장소 발견 (횃불 필요)', need(X) { return X.p.t & T_TORCH ? '' : '횃불이 없어요'; }, f(X) { X.pts(X.k, 1, 2); X.findSub(X.p.l); } },
      { l: '엎드리기', r: '아무 일도 없어요', f() {} },
      { l: '뛰쳐나가기', r: '가장 많은 물자 −1', f(X) { loseMost(X.p, 1); } }] },
    /* 46 */ { t: 1, n: '쓰러진 나무', ic: '🌲', c: 0, tr: [1, 3], z: [1, 7, 8], d: '밤사이 큰 나무가 쓰러져 있어요.', o: [
      { l: '장작으로 쪼개기', r: '나무 +2', f(X) { X.res(X.k, 2, 2); } },
      { l: '다리로 놓기', r: '안개 구역 1곳이 걷혀요 (발견 +1점)', f(X) { revealSome(X.s, X.k, 1); } }] },
    /* 47 */ { t: 1, n: '떠밀려 온 가방', ic: '🧳', c: 2, tr: [1, 3], z: [0, 6, 9, 5], d: '파도에 가방이 떠밀려 왔어요.', o: [
      { l: '열어 보기', r: '40% 유물 · 60% 물 +2·음식 +1', f(X) { if (X.roll(0.4)) X.relic(X.k); else { X.res(X.k, 0, 2); X.res(X.k, 1, 1); } } }] },
    /* 48 */ { t: 1, n: '악어', ic: '🐊', c: 1, tr: [2, 3], z: [10, 6], d: '물가에서 악어가 입을 쩍 벌려요!', o: [
      { l: '맞서 싸우기', r: '창 60%(작살 100%) 음식 +3·2점 · 실패하면 ❤−2', need(X) { return X.p.t & T_SPEAR ? '' : '창이 없어요'; },
        f(X) { if (X.p.t & T_HARP || X.roll(0.6)) { X.ok = 1; X.res(X.k, 1, 3); X.pts(X.k, 1, 2); } else X.hurt(X.k, 2, 3); } },
      { l: '물자 던지고 도망', r: '음식 −2 (없으면 다른 물자)', f(X) { const f = Math.min(2, X.p.r[1]); X.res(X.k, 1, -f); loseMost(X.p, 2 - f); } }] },
    /* 49 */ { t: 1, n: '돌 석상', ic: '🗿', c: 5, tr: [1, 3], z: [1, 12, 13, 11], d: '이끼 낀 석상 앞에 제단이 있어요.', o: [
      { l: '제물 바치기', r: '물 −1·음식 −1 → 유물', need(X) { return X.p.r[0] >= 1 && X.p.r[1] >= 1 ? '' : '물·음식이 1개씩 있어야 해요'; }, f(X) { X.res(X.k, 0, -1); X.res(X.k, 1, -1); X.relic(X.k); } },
      { l: '그냥 지나가기', r: '아무 일도 없어요', f() {} }] },
    /* 50 */ { t: 1, n: '물방울 동굴', ic: '💧', c: 5, tr: [1, 3], z: [3, 14, 2], d: '안쪽 깊은 곳에서 물소리가 울려요.', o: [
      { l: '물 받기', r: '물 +2', f(X) { X.res(X.k, 0, 2); } },
      { l: '깊이 들어가기', r: '60% 숨은 장소 발견(+2점) · 40% 길을 잃어 ❤−1', f(X) { if (X.roll(0.6)) X.findSub(X.p.l); else X.hurt(X.k, 1, 5); } }] },
    /* 51 */ { t: 1, n: '등대 기록', ic: '📜', c: 2, tr: [1, 3], z: [13], d: '등대지기의 배 시간표가 남아 있어요.', o: [
      { l: '시간표 읽기', r: '오늘 밤 「지나가는 배」', f(X) { X.tonight(13); } },
      { l: '등을 고치기', r: '재료 −2 → 신호 +2', need(X) { return X.p.r[3] >= 2 ? '' : '재료가 2개 있어야 해요'; }, f(X) { X.res(X.k, 3, -2); X.sig(2); X.pts(X.k, 2, 2); } }] },
    /* 52 */ { t: 1, n: '큰 발자국', ic: '🐾', c: 1, tr: [2, 3], d: '커다란 짐승의 발자국이 캠프 쪽으로 나 있어요.', o: [
      { l: '따라가기', r: '50% 사냥 성공 음식 +3·1점 · 50% ❤−1', f(X) { if (X.roll(0.5) || X.has(P_NOBEAST)) { X.ok = 1; X.res(X.k, 1, 3); X.pts(X.k, 1, 1); } else X.hurt(X.k, 1, 3); } },
      { l: '캠프에 알리기', r: '오늘 밤 짐승 사건 피해 없음', f(X) { X.s.fl |= F_WARN; } }] },
    /* 53 */ { t: 1, n: '버려진 천막', ic: '⛺', c: 5, tr: [1, 3], z: [12, 5, 0, 13], d: '찢어진 천막과 천 조각이 남아 있어요.', o: [
      { l: '천 걷어 가기', r: '움막 +1 · 기여 +2점', need(X) { return X.s.sh < 3 ? '' : '움막이 이미 튼튼해요'; }, f(X) { X.hut(1); X.pts(X.k, 2, 2); } },
      { l: '안에서 쉬기', r: '❤ +2', f(X) { X.heal(X.k, 2); } }] },
  ];
  const NIGHTS = [], DAYEV = [];
  EVS.forEach((e, i) => { if (e.t === 0 && !e.chain) NIGHTS.push(i); if (e.t === 1) DAYEV.push(i); });
  /* goodness of a night event for planning (chains) */
  const EVG = EVS.map((e, i) => (i === 26 ? 5 : i === 27 ? 4 : i === 28 ? 4 : i === 29 ? -3 : i === 13 ? 2.5 : 0));

  function mkX(s, k, info) {
    const X = { s, k, p: s.p[k], A: aliveList(s), lit: s.fi >= 1, ok: -1, rl: -1, heat: 0, sk: -1, cl: 0, hits: info ? info.hit : [] };
    X.has = (pk, kk) => has(s.p[kk == null ? k : kk], pk);
    X.hurt = (kk, n, c) => hurt(s, kk, n, c);
    X.heal = (kk, n) => heal(s, kk, n);
    X.res = (kk, i, n) => addR(s.p[kk], i, n);
    X.pts = (kk, c, n) => { s.p[kk].s[c] += n; };
    X.relic = (kk, id) => { const r = gainRelic(s, kk, id); if (r >= 0) X.rl = r; return r; };
    X.sig = (n) => { s.sg = Math.max(0, s.sg + n); };
    X.fire = (n) => { s.fi = clamp(s.fi + n, 0, 4); };
    X.hut = (n) => { s.sh = clamp(s.sh + n, 0, 3); };
    X.roll = (pr) => { const r = Math.random() < pr; X.ok = r ? 1 : 0; return r; };
    X.pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
    X.next = (e) => { if (s.d < DAYS) { s.ev = setc(s.ev, s.d, e.toString(36)); s.co = k; } };
    X.tonight = (e) => { const cur = evAt(s, s.d - 1); if (!(EVS[cur] && EVS[cur].chain && EVG[cur] > EVG[e])) { s.ev = setc(s.ev, s.d - 1, e.toString(36)); s.co = k; } };
    X.hit = (kk) => { if (X.hits.indexOf(kk) < 0) X.hits.push(kk); };
    X.findSub = (sl) => { if (sl > 0 && KINDS[kindAt(s, sl)].sub && !subOn(s, sl)) { subLoot(s, k, sl, X); return true; } return false; };
    return X;
  }
  function subLoot(s, k, sl, X) {
    const sub = KINDS[kindAt(s, sl)].sub, p = s.p[k];
    s.sf |= 1 << sl; p.s[0] += 2;
    if (sub.loot === 1) { const r = gainRelic(s, k); if (X && r >= 0) X.rl = r; return r; }
    if (sub.loot === 2) p.s[1] += 2;
    if (sub.sig) s.sg += sub.sig;
    if (sub.heal) heal(s, k, 1);
    return -1;
  }
  const optNeed = (X, o) => (o.need ? o.need(X) : '');

  /* ======================= setup / flow ======================= */
  function wpick(arr, wf) { let t = 0; const w = arr.map((a) => { const v = Math.max(0, wf(a)); t += v; return v; }); let r = Math.random() * t; for (let i = 0; i < arr.length; i++) { r -= w[i]; if (r <= 0 && w[i] > 0) return arr[i]; } return arr[arr.length - 1]; }
  function genZones(df) {
    const common = U.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 14]), out = [];
    for (const r of U.shuffle([11, 12, 13])) if (out.length < 2 && Math.random() < 0.3) out.push(r);
    for (const c of common) if (out.length < NS - 1) out.push(c);
    if (out.indexOf(2) < 0 && out.indexOf(14) < 0) out[out.findIndex((k) => WATERK.indexOf(k) < 0 && !KINDS[k].rare)] = Math.random() < 0.6 ? 2 : 14;
    return U.shuffle(out);
  }
  function genWeather(df) {
    let w = '';
    for (let d = 1; d <= DAYS; d++) {
      const t = Math.min(3, tierOf(d) + (df === 'h' && d >= 3 ? 1 : 0) - (df === 'e' && d >= 3 ? 1 : 0));
      const W = d === 1 ? [3, 3, 0, 0, 0, 0] : t <= 1 ? [3, 3, 2, 1, 1, 1] : t === 2 ? [2, 2, 2, 2, 2, 1] : [1, 1, 2, 3, 3, 2];
      w += wpick([0, 1, 2, 3, 4, 5], (i) => W[i]);
    }
    return w;
  }
  function genMods() {
    let m = '0';
    const pool = U.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3]);
    for (let d = 2; d <= DAYS; d++) m += Math.random() < 0.2 ? '0' : pool[d];
    return m;
  }
  function genNights(df, kinds) {
    const used = {}, out = [];
    const hasVol = kinds.indexOf(11) >= 0;
    for (let d = 1; d <= DAYS; d++) {
      const t = tierOf(d);
      const cand = NIGHTS.filter((e) => !used[e] && EVS[e].tr[0] <= t && t <= EVS[e].tr[1] && (!EVS[e].vol || hasVol));
      const e = wpick(cand, (e) => (EVS[e].c === 4 ? (df === 'h' ? 0.35 : df === 'e' ? 1.8 : 1) : 1) * (EVS[e].o ? 1.3 : 1));
      used[e] = 1; out.push(e);
    }
    return out.map((e) => e.toString(36)).join('');
  }
  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(1, Math.min(4, players.length));
    const df = GOAL[opts.diff] ? opts.diff : 'm';
    const kinds = genZones(df);
    const base = U.shuffle([0, 1, 2, 3, 4, 5, 6, 7]);
    let dl = ''; for (let i = 0; i < n; i++) for (let j = 0; j < 3; j++) dl += base[(3 * i + j) % NBASE];
    const s = {
      n, df, G: GOAL[df][n - 1],
      nm: players.slice(0, n).map((q, k) => String((q && q.name) || k + 1 + '번').slice(0, 8)),
      d: 1, ph: 3, fp: 0, q: 0, cur: 0, ap: 0,
      sg: 0, fi: 2, sh: 0, cb: 0,
      sd: (Math.random() * 2147483647) | 0,
      m: '0' + kinds.map((k) => k.toString(36)).join(''), rv: 1, sf: 0, ab: '2222222222', cl: 0,
      ev: genNights(df, kinds), w: genWeather(df), dm: genMods(), fl: 0, us: 0,
      rl: U.shuffle(Array.from({ length: RLDECK }, (_, i) => i)).map((i) => i.toString(36)).join(''),
      pe: 0, co: -1, dl, dk: [0, 0, 0, 0, 0, 0, 0], sv: [0, 0, 0, 0, 0],
      p: Array.from({ length: n }, () => ({ c: -1, h: 5, a: 3, b: 3, r: [2, 2, 1, 1], t: 0, x: 0, s: [0, 0, 0, 0], k: 0, o: 0, z: 0, l: 0, u: 0 })),
      seq: 0, last: null, end: 0, rd: 0, fr: 0,
    };
    s.q = -1; nextTurn(s);
    return s;
  }
  function leadSeat(s) { for (let q = 0; q < s.n; q++) { const k = (s.fp + q) % s.n; if (!s.p[k].o) return k; } return 0; }
  function actor(s) { return s.end ? null : s.pe ? s.pe[0] : s.cur; }
  function dayAp(p) { return (has(p, P_EXTRA) ? 3 : 2) - (p.k ? 1 : 0); }
  function beginPhase(s, ph) { s.ph = ph; s.q = -1; return nextTurn(s); }
  function nextTurn(s) {
    for (let q = s.q + 1; q < s.n; q++) {
      const k = (s.fp + q) % s.n, p = s.p[k];
      if (p.o) continue;
      s.q = q; s.cur = k; s.ap = s.ph === 0 ? dayAp(p) : s.ph === 1 ? 2 : 1;
      return true;
    }
    return false;
  }
  const dealt = (s, k) => (s.dl ? s.dl.slice(k * 3, k * 3 + 3).split('').map(Number) : []);
  function pickOk(s, k, c) {
    if (!(c >= 0 && c < CH.length)) return false;
    if (s.p.some((q, j) => j !== k && q.c === c)) return false;
    return c >= NBASE || dealt(s, k).indexOf(c) >= 0;
  }
  function setupChar(s, k, c, kit) {
    const p = s.p[k], C = CH[c];
    p.c = c; p.h = maxH(p);
    if (C.r) for (let i = 0; i < 4; i++) p.r[i] += C.r[i];
    if (C.t) p.t |= C.t;
    if (kit > 0 && KITS[kit] >= 0) gainRelic(s, k, KITS[kit]);
  }
  function endEvening(s, last) {
    const e = evAt(s, s.d - 1);
    if (s.sg < s.G && EVS[e].o && !(s.fl & F_WARN && isBeast(e))) {
      s.ph = 2; s.q = -1; nextTurn(s);   // the day's leader decides
      return;
    }
    last.n = night(s, -1, -1);
  }

  /* night: rescue → event → weather → upkeep → faint → rescue / day-7 → morning */
  function snapP(s) { return s.p.map((p) => [p.h, p.r[0], p.r[1], p.r[2], p.r[3]]); }
  function diffP(s, sn) { return s.p.map((p, k) => { const a = [p.h - sn[k][0], p.r[0] - sn[k][1], p.r[1] - sn[k][2], p.r[2] - sn[k][3], p.r[3] - sn[k][4]]; return a.some((v) => v) ? a : 0; }); }
  function night(s, chooser, o) {
    const info = { d: s.d, e: evAt(s, s.d - 1), o, r: 0, E: 0, U: 0, M: 0, sg: 0, fi: 0, sh: 0, sk: -1, hit: [], fo: [], cl: 0, lit: 0, wn: 0, rl: -1, ok: -1, ch: chooser, lk: [] };
    const sg0 = s.sg, fi0 = s.fi, sh0 = s.sh;
    if (s.sg >= s.G) { s.end = 1; s.rd = s.d; info.r = 1; return info; }
    const e = info.e, E = EVS[e];
    const lead = chooser >= 0 ? chooser : E.chain && s.co >= 0 && !s.p[s.co].o ? s.co : leadSeat(s);
    const sn = snapP(s);
    const X = mkX(s, lead, info);
    if (s.fl & F_WARN && E.c === 1) { info.wn = 1; s.sv[4]++; }
    else if (E.o) { const oo = E.o[o >= 0 && o < E.o.length ? o : 0]; if (!optNeed(X, oo)) oo.f(X); }
    else E.f(X);
    s.fl &= ~F_WARN;
    info.rl = X.rl; info.ok = X.ok; info.sk = X.sk; info.cl = X.cl;
    const wx = wxAt(s, s.d);
    if (wx === 2 && s.sh < 1) s.fi = Math.max(0, s.fi - 1);
    if (wx === 4 && s.sh < 2) s.fi = Math.max(0, s.fi - 1);
    info.E = diffP(s, sn);
    // upkeep
    const sn2 = snapP(s), A = aliveList(s);
    const litN = s.fi >= 1; info.lit = litN ? 1 : 0;
    const burn = s.d >= COLD_D ? 2 : 1;   // escalation: later nights are colder
    if (litN) { if (anyHas(s, P_LAMP) && Math.random() < 0.5) info.lp = 1; else s.fi = Math.max(0, s.fi - burn); s.sv[0]++; }
    const heat = X.heat || wx === 3;
    for (const k of A) {
      const p = s.p[k];
      const nw = heat && !(p.t & (T_JUG | T_HAT)) && !has(p, P_NOHEAT) ? 2 : 1, up = has(p, P_EAT2) ? 2 : 1;
      if (p.r[0] >= nw) { p.r[0] -= nw; p.b = Math.min(3, p.b + up); } else { p.r[0] = 0; p.b = Math.max(0, p.b - 1); }
      if (p.r[1] >= 1) { p.r[1]--; p.a = Math.min(3, p.a + up); } else p.a = Math.max(0, p.a - 1);
      if (p.a <= 0) hurt(s, k, 1, 0);
      if (p.b <= 0) hurt(s, k, 1, 1);
      if (!litN && s.sh < 3) { if (has(p, P_NOCOLD)) s.sv[4]++; else hurt(s, k, 1, 2); }
      else if (litN && s.sh >= 2) heal(s, k, 1);
      if (p.k) hurt(s, k, 1, 6);
    }
    for (const k of A) {
      const p = s.p[k];
      if (p.h > 0) continue;
      if (has(p, P_LUCK)) { p.h = 2; p.x &= ~(1 << 17); s.sv[4]++; info.lk.push(k); continue; }
      p.o = 1; p.k = 0; info.fo.push(k);
    }
    info.U = diffP(s, sn2);
    info.sg = s.sg - sg0; info.fi = s.fi - fi0; info.sh = s.sh - sh0;
    if (!alive(s)) { s.end = 2; s.fr = 1; return info; }
    if (s.sg >= s.G) { s.end = 1; s.rd = s.d; info.r = 2; return info; }
    if (s.d >= DAYS) { s.end = 2; s.fr = 2; return info; }
    morning(s, info);
    return info;
  }
  function morning(s, info) {
    s.d++;
    s.fp = (s.fp + 1) % s.n;
    let ab = ''; for (let i = 0; i < NS; i++) ab += Math.min(ABX, +s.ab[i] + 1); s.ab = ab;
    s.cl = info.cl;
    const sn = snapP(s), wx = wxAt(s, s.d), dm = dmAt(s, s.d);
    s.p.forEach((p, k) => {
      p.z = 0; p.l = 0; p.u = 0;
      if (p.o) return;
      let w = 0, f = 0, wd = 0;
      if (s.cb & CB_RAIN) w++;
      if (s.cb & CB_CIST) w++;
      if (s.cb & CB_SMOK) f++;
      if (p.t & T_TRAP) f++;
      if (p.t & T_BIGTRAP) f++;
      if (p.t & T_SKIN) w++;
      const pk = perks(p);
      if (pk & P_MORNF) f++;
      if (pk & P_MORNW) w++;
      if (pk & P_MORNWD) wd++;
      if (wx === 2) w++;
      if (w) addR(p, 0, w);
      if (f) addR(p, 1, f);
      if (wd) addR(p, 2, wd);
      if (dm === 5) heal(s, k, 1);
    });
    info.M = diffP(s, sn);
    beginPhase(s, 0);
  }

  function pickEncounter(s, k, kind) {
    const t = tierOf(s.d);
    const c = DAYEV.filter((e) => !((s.us >> (e - DAYEV[0])) & 1) && EVS[e].tr[0] <= t && (!EVS[e].z || EVS[e].z.indexOf(kind) >= 0) &&
      !(e === 37 && (s.p[k].x >> 22) & 1) && !(e === 42 && (s.rl.indexOf((19).toString(36)) < 0)));
    if (!c.length) return -1;
    return c[Math.floor(Math.random() * c.length)];
  }

  function apply(s, seat, a) {
    if (s.end) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const p = s.p[seat];
    let last = null, adv = true;
    if (s.pe) {   // pending day encounter
      if (a.t !== 'ch') throw new Error('choose first');
      const e = s.pe[1], E = EVS[e], o = a.o | 0;
      if (a.o !== o || !E.o[o]) throw new Error('bad option');
      const X = mkX(s, seat, null);
      if (optNeed(X, E.o[o])) throw new Error('cannot: ' + optNeed(X, E.o[o]));
      const sn = snapP(s), c0 = [s.sg, s.fi, s.sh], pt0 = p.s[0] + p.s[1] + p.s[2] + p.s[3];
      E.o[o].f(X);
      if (p.h <= 0 && !p.o) { if (has(p, P_LUCK)) { p.h = 2; p.x &= ~(1 << 17); s.sv[4]++; } else { p.o = 1; p.k = 0; } }
      s.pe = 0;
      const g = diffP(s, sn)[seat] || 0;
      last = { k: 'c', s: seat, e, o, g, pt: p.s[0] + p.s[1] + p.s[2] + p.s[3] - pt0, ok: X.ok, rl: X.rl, cm: [s.sg - c0[0], s.fi - c0[1], s.sh - c0[2]] };
    } else if (s.ph === 3) {
      if (a.t !== 'pick') throw new Error('bad action');
      const c = a.c | 0, kit = a.kit | 0;
      if (a.c !== c || !pickOk(s, seat, c) || kit < 0 || kit >= KITS.length) throw new Error('bad pick');
      setupChar(s, seat, c, kit);
      last = { k: 'p', s: seat, c, kit };
      s.ap = 0;
    } else if (s.ph === 0) {
      if (a.t === 'go') {
        const sl = a.sl | 0;
        if (sl < 0 || sl >= NS || a.sl !== sl) throw new Error('bad slot');
        if ((s.cl >> sl) & 1) throw new Error('closed');
        if (!reach(s, sl)) throw new Error('too far');
        const kind = kindAt(s, sl), first = !rvd(s, sl), ab = +s.ab[sl];
        const sn = snapP(s), X = mkX(s, seat, null);
        const y = gatherYield(s, seat, sl);
        if (first && has(p, P_EXPL)) { let mi = 0; for (let i = 1; i < 4; i++) if (y[i] > y[mi]) mi = i; y[mi]++; }
        for (let i = 0; i < 4; i++) if (y[i]) addR(p, i, y[i]);
        s.ab = setc(s.ab, sl, String(Math.max(0, ab - 1)));
        let tr = 0, fd = 0, hz = 0, sb = 0, sg = 0;
        if (first) {
          s.rv |= 1 << sl; fd = 1;
          p.s[0] += 2 + (has(p, P_EXPL) ? 1 : 0) + (dmAt(s, s.d) === 9 ? 1 : 0);
          if (kind === 5 || kind === 12) X.relic(seat);
          if (kind === 13) { s.sg++; sg = 1; }
        } else if (Math.random() < subP(s, seat, sl)) { sb = 1; subLoot(s, seat, sl, X); }
        if (!sb && subOn(s, sl) && KINDS[kind].sub.heal) { heal(s, seat, 1); if (KINDS[kind].sub.cure) p.k = 0; }
        const tp = treasureP(s, seat, kind);
        if (tp && Math.random() < tp) { p.s[1] += 2; tr = 1; }
        const [hp, cause] = hazardP(s, seat, kind);
        if (hp && Math.random() < hp) {
          if (cause === 6) { p.k = 1; hz = 3; } else { hurt(s, seat, 1, cause); hz = KINDS[kind].burn ? 2 : 1; }
          if (p.h <= 0) { if (has(p, P_LUCK)) { p.h = 2; p.x &= ~(1 << 17); s.sv[4]++; } else { p.o = 1; p.k = 0; } }
        }
        p.z |= 1 << kind; p.l = sl;
        s.ap--;
        let en = -1;
        if (!p.o && !p.u) {
          const ec = (first ? 0.45 : 0.22) + (wxAt(s, s.d) === 5 ? 0.15 : 0);
          if (Math.random() < ec) { en = pickEncounter(s, seat, kind); if (en >= 0) { s.us |= 1 << (en - DAYEV[0]); p.u = 1; s.pe = [seat, en]; adv = false; } }
        }
        last = { k: 'g', s: seat, sl, g: diffP(s, sn)[seat] || 0, fd, tr, sb, hz, ab, rl: X.rl, sg, en };
      } else if (a.t === 'rest') {
        const dh = heal(s, seat, 1 + (has(p, P_REST2) ? 1 : 0) + (dmAt(s, s.d) === 8 ? 1 : 0)), cure = p.k; p.k = 0; p.l = 0;
        s.ap--;
        last = { k: 'r', s: seat, dh, cu: cure };
      } else if (a.t === 'end') { s.ap = 0; last = { k: 'e', s: seat }; }
      else throw new Error('bad action');
    } else if (s.ph === 1) {
      if (a.t === 'mk') {
        const ri = a.r | 0, why = canMake(s, seat, ri);
        if (a.r !== ri || why) throw new Error('cannot make: ' + why);
        const R = RC[ri], c = costOf(s, seat, ri);
        for (let i = 0; i < 4; i++) p.r[i] -= c[i];
        let sg = 0, xr = 0;
        if (R.bit) { p.t |= R.bit; p.s[3] += R.pts; }
        else if (R.id === 'salve') { heal(s, seat, 2 + (has(p, P_SALVE) ? 1 : 0)); p.k = 0; }
        else if (R.id === 'tea') { heal(s, seat, 1 + (has(p, P_SALVE) ? 1 : 0)); p.b = 3; p.k = 0; }
        else if (R.id === 'soup') { for (const k of aliveList(s)) { heal(s, k, 1); s.p[k].a = Math.min(3, s.p[k].a + 1); } p.s[2] += R.pts; }
        else {
          p.s[2] += R.pts;
          if (R.id === 'fire') s.fi = Math.min(4, s.fi + 2 + (has(p, P_FIRE1) ? 1 : 0) + (dmAt(s, s.d) === 7 ? 1 : 0));
          else if (R.id === 'hut') s.sh++;
          if (R.cb) s.cb |= R.cb;
          if (R.id === 'look') xr = revealSome(s, seat, 1);
          if (R.sg) { sg = sigAmt(s, seat, ri); s.sg += sg; }
        }
        s.ap--;
        last = { k: 'm', s: seat, r: ri, sg, xr };
      } else if (a.t === 'give') {
        const ri = a.k | 0;
        if ((ri !== 0 && ri !== 1) || a.k !== ri) throw new Error('bad give');
        if (p.r[ri] < 1) throw new Error('nothing to give');
        const to = giveTarget(s, seat, ri);
        if (to < 0) throw new Error('nobody');
        const q = s.p[to], pt = q.r[ri] === 0 ? 1 : 0;
        p.r[ri]--; addR(q, ri, 1);
        p.s[2] += pt; s.sv[2]++;
        s.ap--;
        last = { k: 'v', s: seat, to, ri, pt };
      } else if (a.t === 'end') { s.ap = 0; last = { k: 'e', s: seat }; }
      else throw new Error('bad action');
    } else if (s.ph === 2) {
      if (a.t !== 'ch') throw new Error('bad action');
      const e = evAt(s, s.d - 1), E = EVS[e], o = a.o | 0;
      if (a.o !== o || !E.o || !E.o[o]) throw new Error('bad option');
      const X = mkX(s, seat, null);
      if (optNeed(X, E.o[o])) throw new Error('cannot');
      last = { k: 'c', s: seat, e, o, nt: 1 };
      last.n = night(s, seat, o);
      adv = false;
    }
    if (adv && !s.end) {
      if (!alive(s)) { s.end = 2; s.fr = 1; }
      else if (s.ap <= 0 || p.o) {
        if (!nextTurn(s)) {
          if (s.ph === 3) { s.dl = ''; delete s.dl; beginPhase(s, 0); }
          else if (s.ph === 0) beginPhase(s, 1);
          else if (s.ph === 1) endEvening(s, last);
        }
      }
    }
    s.seq++; last.id = s.seq; s.last = last;
    return s;
  }

  function stars(s) {
    if (s.end !== 1) return 0;
    return s.rd <= 5 ? 3 : s.rd <= 6 ? 2 : 1;
  }
  function summary(s) {   // what hurt us most / what saved us most
    let wi = 0; for (let i = 1; i < s.dk.length; i++) if (s.dk[i] > s.dk[wi]) wi = i;
    let si = 0; for (let i = 1; i < s.sv.length; i++) if (s.sv[i] > s.sv[si]) si = i;
    return { worst: s.dk[wi] ? wi : -1, wv: s.dk[wi], best: s.sv[si] ? si : -1, bv: s.sv[si] };
  }
  function result(s) {
    if (!s.end) return null;
    const nm = (k) => (s.nm && s.nm[k]) || k + 1 + '번';
    const lines = s.p.map((p, k) => ({ k, v: total(p), o: p.o })).sort((a, b) => (a.o - b.o) || b.v - a.v);
    const sumTxt = lines.map((o) => nm(o.k) + ' ' + o.v + '점' + (o.o ? '(쓰러짐)' : '')).join(' · ');
    const sm = summary(s);
    const sl = (sm.worst >= 0 ? '가장 큰 위협: ' + DK[sm.worst] + ' ❤−' + sm.wv : '큰 위협 없이 버텼어요') + (sm.best >= 0 ? ' · 버팀목: ' + SV[sm.best] + ' ×' + sm.bv : '');
    if (s.end === 2) {
      const why = s.fr === 1 ? '모두 쓰러지고 말았어요.' : '7일째 밤까지 구조 신호가 모자랐어요 (' + s.sg + '/' + s.G + ').';
      return { winners: [], title: s.n === 1 ? '구조 실패…' : '모두 구조 실패…', text: why + '\n' + sl + (s.n > 1 ? '\n함께 구조되지 못하면 모두 져요. ' + sumTxt : '\n신호를 조금 더 일찍 모아 봐요!') };
    }
    if (s.n === 1) {
      const st = stars(s), p = s.p[0];
      return { winners: [0], title: '★★★'.slice(0, st) + '☆☆☆'.slice(0, 3 - st) + ' ' + s.rd + '일째 밤 구조!', text: '점수 ' + total(p) + '점 · 유물 ' + relicN(p) + '개\n' + sl + '\n(★★ 6일째 밤까지 · ★★★ 5일째 밤까지 구조)' };
    }
    const al = lines.filter((o) => !o.o), best = Math.max(...al.map((o) => o.v));
    const winners = al.filter((o) => o.v === best).map((o) => o.k);
    return { winners, title: (winners.length > 1 ? '공동 1등 · ' : '') + s.rd + '일째 밤 구조 성공!', text: sumTxt + '\n' + sl };
  }

  /* ======================= AI ======================= */
  const omenC = (s, d) => { const e = evAt(s, d - 1); return e >= 0 ? EVS[e].c : -1; };
  function urgency(s) {
    const rem = Math.max(0, s.G - s.sg), D = DAYS + 1 - s.d;
    return rem / Math.max(0.5, D * alive(s) * 1.1);
  }
  function morningIncome(s, p) {
    let w = 0, f = 0;
    if (s.cb & CB_RAIN) w++; if (s.cb & CB_CIST) w++; if (s.cb & CB_SMOK) f++;
    if (p.t & T_TRAP) f++; if (p.t & T_BIGTRAP) f++; if (p.t & T_SKIN) w++;
    const pk = perks(p); if (pk & P_MORNF) f++; if (pk & P_MORNW) w++;
    return [w, f];
  }
  function mvals(s, p, lv) {
    const NL = DAYS + 1 - s.d, om = omenC(s, s.d), inc = morningIncome(s, p);
    let heatN = 0; if (lv >= 3) for (let d = s.d; d <= DAYS; d++) if (wxAt(s, d) === 3 && !(p.t & (T_JUG | T_HAT))) heatN += 0.6;
    const nw = NL + heatN + (lv >= 3 && om === 0 ? 0.3 : 0) - p.r[0] - (p.b - 1) * 0.6 - inc[0] * (NL - 1);
    const nf = NL - p.r[1] - (p.a - 1) * 0.6 - inc[1] * (NL - 1);
    const v = [nw > 0 ? 1.5 + 0.35 * Math.min(3, nw) : 0.3, nf > 0 ? 1.4 + 0.3 * Math.min(3, nf) : 0.3, 1.0, 1.0];
    if (p.r[2] >= 6) v[2] = 0.6;
    if (p.r[3] >= 6) v[3] = 0.6;
    const cap = capOf(p);
    for (let i = 0; i < 4; i++) if (p.r[i] >= cap) v[i] = 0;
    return v;
  }
  function leader(s, k) { const me = total(s.p[k]); return s.p.every((q, j) => j === k || q.o || total(q) <= me); }
  const greed = (lv) => (lv === 1 ? 0.5 : lv === 2 ? 0.7 : 1.2);
  const hpCostOf = (p) => (p.h <= 1 ? 7 : p.h <= 2 ? 4 : 1.6);

  function slotValue(s, k, sl, lv, v, g) {
    const p = s.p[k];
    const encV = p.u ? 0 : 0.25;
    if (rvd(s, sl)) {
      const kind = kindAt(s, sl), y = gatherYield(s, k, sl), [hp] = hazardP(s, k, kind);
      let val = y.reduce((a, c, i) => a + c * v[i], 0) + treasureP(s, k, kind) * 2 * g + subP(s, k, sl) * (2 * g + ((KINDS[kind].sub && KINDS[kind].sub.loot === 1) ? 2.5 : 0.8)) - hp * hpCostOf(p) + encV;
      if (subOn(s, sl) && KINDS[kind].sub.heal && (p.h < maxH(p) - 1 || p.k)) val += p.k && KINDS[kind].sub.cure ? 4 : 1.6;
      if (lv >= 3 && (kind === 1 || kind === 7 || kind === 8) && omenC(s, s.d) === 1 && !(p.t & T_SPEAR)) val -= 0.25;
      return val;
    }
    const unk = []; for (let j = 1; j < NS; j++) if (!rvd(s, j)) unk.push(kindAt(s, j));
    let t = 0;
    for (const kind of unk) {
      const y = kindYield(s, k, kind, 0), [hp] = hazardP(s, k, kind);
      t += y.reduce((a, c, i) => a + c * v[i], 0) - hp * hpCostOf(p) + ((kind === 5 || kind === 12) ? 3.2 : kind === 13 ? 1.5 : treasureP(s, k, kind) * 2 * g);
    }
    let val = t / unk.length + (2 + (has(p, P_EXPL) ? 1.5 : 0)) * g + encV * 1.6 + (s.d <= 3 ? 0.5 : 0);
    if ((lv >= 2 && v[0] > 1 && ![2, 14].some((kd) => { const j = s.m.indexOf(kd.toString(36)); return j > 0 && rvd(s, j); }))) val += 0.8;
    if (lv === 1) val = val * 0.6 + Math.random() * 2;
    return val;
  }
  function dayOptions(s, k, lv) {
    const p = s.p[k], v = mvals(s, p, lv), g = greed(lv), out = [];
    for (let sl = 0; sl < NS; sl++) {
      if ((s.cl >> sl) & 1 || !reach(s, sl)) continue;
      out.push({ a: { t: 'go', sl }, v: slotValue(s, k, sl, lv, v, g) });
    }
    let rv = 0;
    const mh = maxH(p);
    if (p.h < mh) rv += p.h <= 1 ? 6 : p.h <= 2 ? 3.2 : p.h <= mh - 2 ? 1.1 : 0.3;
    if (has(p, P_REST2) || dmAt(s, s.d) === 8) rv *= 1.4;
    if (p.k) rv += lv === 1 ? 1.5 : 4.5;
    out.push({ a: { t: 'rest' }, v: rv });
    return out;
  }
  const TOOLU = { spear: 0.55, harp: 0.45, net: 0.55, axe: 0.6, bigaxe: 0.45, jug: 0.6, skin: 0.9, rope: 0.5, hook: 0.35, trap: 1.25, bigtrap: 1.1, torch: 0.35, hat: 0.3 };
  function eveOptions(s, k, lv) {
    const p = s.p[k], v = mvals(s, p, lv), g = greed(lv), om = lv >= 3 ? omenC(s, s.d) : -1, out = [];
    const D = DAYS + 1 - s.d, after = DAYS - s.d, Ug = urgency(s), A = alive(s);
    const lastDay = s.d === DAYS;
    let coop = lv === 1 ? 0.7 : 1.0;
    if (lv === 3) {
      let sum = 1; s.p.forEach((q) => { if (!q.o) sum += q.s[2]; });
      const over = A > 1 && p.s[2] / sum > 1 / A + 0.06;
      coop = Ug > 0.95 ? 1.3 : over ? 0.3 : Ug > 0.7 ? 0.8 : 0.42;
    }
    const cw = lastDay ? 0.1 : D <= 2 ? 0.35 : 0.55;
    const hasK = (kd) => { const j = s.m.indexOf(kd.toString(36)); return j > 0 && rvd(s, j); };
    for (let ri = 0; ri < RC.length; ri++) {
      if (canMake(s, k, ri)) continue;
      const R = RC[ri];
      let val = R.pts * g;
      switch (R.id) {
        case 'fire': val += s.fi === 0 ? 3 : s.fi === 1 ? 1.4 : s.fi === 2 ? 0.25 : -0.6; if (om === 1 && s.fi <= 1) val += 1.6; if (lastDay && s.sg < s.G && s.fi === 0 && p.r[2] >= 3) val += 3; break;
        case 'hut': val += (s.sh < 2 ? 1.5 : 0.45) * Math.min(1, D / 3) * (0.6 + 0.2 * A) * (lv === 1 ? 0.6 : 1); if (om === 0 && s.sh < 2) val += 1.4; if (lastDay) val -= 1; break;
        case 'rain': case 'cist': case 'smokeh': val += Math.max(0, after) * A * 0.35 - 0.3; break;
        case 'fence': val += (after >= 2 ? 0.25 * after : 0) * (0.5 + 0.25 * A) + (om === 1 ? 1.4 : 0) - 0.5; break;
        case 'look': val += (after >= 2 ? 0.8 : -0.5) + (s.rv !== (1 << NS) - 1 ? 0.4 : 0); break;
        case 'salve': val += p.k ? 4 : p.h <= 2 ? 2.6 : p.h <= 3 ? 0.6 : -0.5; break;
        case 'tea': val += (p.k ? 3.5 : 0) + (p.b <= 1 ? 1.2 : 0) + (p.h <= 2 ? 1.2 : -0.3); break;
        case 'soup': { let need = 0; s.p.forEach((q) => { if (!q.o) need += (q.h < maxH(q) ? (q.h <= 2 ? 1.6 : 0.6) : 0) + (q.a <= 1 ? 0.6 : 0); }); val += need * (lv === 1 ? 0.6 : coop) - 0.4; break; }
        default:
          if (R.sg) {
            const need = Math.max(0, s.G - s.sg), amt = sigAmt(s, k, ri), eff = Math.min(amt, need);
            val += eff * (0.5 + 2.4 * Ug) * coop;
            if (lastDay && need > 0) val += eff * 6 * (lv === 1 ? 0.5 : 1);
            if (R.id === 'raft') val += om === 2 ? 1 : 0.3;
            if (lv === 3 && s.n > 1 && s.sg + amt >= s.G) val += leader(s, k) ? 3 : lastDay ? 0 : s.d >= DAYS - 1 ? -1.5 : -5;
          } else if (R.bit) {
            let u = TOOLU[R.id] || 0.4;
            if (R.id === 'jug' && !hasK(2) && !hasK(14) && !hasK(7) && !hasK(10)) u *= 0.6;
            if (R.id === 'spear' && om === 1) u += 0.3;
            if (R.id === 'rope' && hasK(4)) u += 0.15;
            if (R.id === 'torch' && (hasK(3) || hasK(14))) u += 0.2;
            if (R.id === 'hat') for (let d = s.d + 1; d <= DAYS; d++) if (wxAt(s, d) === 3) u += 0.25;
            val += u * after * (lv === 1 ? 0.7 : 1) - (after <= 0 ? 1 : 0);
          }
      }
      const c = costOf(s, k, ri);
      let cost = 0;
      for (let i = 0; i < 4; i++) cost += c[i] * (i < 2 ? v[i] : cw * v[i]);
      out.push({ a: { t: 'mk', r: ri }, v: val - cost });
    }
    if (s.n > 1 && lv >= 2) {
      for (let ri = 0; ri < 2; ri++) {
        if (p.r[ri] < 1) continue;
        const to = giveTarget(s, k, ri); if (to < 0) continue;
        const q = s.p[to], meter = ri === 0 ? q.b : q.a;
        const theirNeed = q.r[ri] === 0 ? (meter <= 1 ? 3 : meter === 2 ? 1.1 : 0.2) : 0;
        const mine = p.r[ri] - (DAYS + 1 - s.d);
        out.push({ a: { t: 'give', k: ri }, v: theirNeed * coop + (q.r[ri] === 0 ? g : 0) - (mine >= 1 ? 0.3 : v[ri] + 1) });
      }
    }
    out.push({ a: { t: 'end' }, v: lv === 1 ? 0.2 : 0.35 });
    return out;
  }
  function packValue(s, k, lv) {
    let tot = 0;
    const t = JSON.parse(JSON.stringify(s)); t.ph = 1;
    for (let step = 0; step < 2; step++) {
      const o = eveOptions(t, k, lv).filter((x) => x.a.t === 'mk');
      let b = null; for (const x of o) if (x.v > 0.2 && (!b || x.v > b.v)) b = x;
      if (!b) break;
      tot += b.v;
      const R = RC[b.a.r], p = t.p[k], c = costOf(t, k, b.a.r);
      for (let i = 0; i < 4; i++) p.r[i] -= c[i];
      if (R.bit) p.t |= R.bit; else if (R.id === 'fire') t.fi = Math.min(4, t.fi + 2); else if (R.id === 'hut') t.sh++;
      if (R.cb) t.cb |= R.cb;
      if (R.sg) t.sg += sigAmt(t, k, b.a.r);
    }
    const p = t.p[k], v = mvals(t, p, lv);
    for (let i = 0; i < 4; i++) tot += Math.min(p.r[i], 6) * v[i] * (i < 2 ? 0.8 : 0.3);
    tot += keep(p) * 0.6 * greed(lv);
    return tot;
  }
  function expectStep(s, k, a) {
    const t = JSON.parse(JSON.stringify(s)), p = t.p[k];
    let bonus = 0;
    if (a.t === 'rest') { p.h = Math.min(maxH(p), p.h + 1 + (has(p, P_REST2) ? 1 : 0)); p.k = 0; }
    else {
      const sl = a.sl, cap = capOf(p);
      if (rvd(t, sl)) {
        const kind = kindAt(t, sl), y = gatherYield(t, k, sl), [hp] = hazardP(t, k, kind);
        for (let i = 0; i < 4; i++) p.r[i] = Math.min(cap, p.r[i] + y[i]);
        bonus = treasureP(t, k, kind) * 2 + subP(t, k, sl) * ((KINDS[kind].sub && KINDS[kind].sub.loot === 1) ? 4.5 : 2.5) - hp * hpCostOf(p) + (p.u ? 0 : 0.25);
        t.ab = setc(t.ab, sl, String(Math.max(0, +t.ab[sl] - 1)));
      } else {
        const unk = []; for (let j = 1; j < NS; j++) if (!rvd(t, j)) unk.push(kindAt(t, j));
        const acc = [0, 0, 0, 0];
        for (const kind of unk) { const y = kindYield(t, k, kind, 0), [hp] = hazardP(t, k, kind); for (let i = 0; i < 4; i++) acc[i] += y[i] / unk.length; bonus += (((kind === 5 || kind === 12) ? 3.2 : treasureP(t, k, kind) * 2) - hp * 1.5) / unk.length; }
        for (let i = 0; i < 4; i++) p.r[i] = Math.min(cap, p.r[i] + acc[i]);
        bonus += 2 + (t.d <= 2 ? 2 : t.d <= 4 ? 1 : 0) + (p.u ? 0 : 0.4);
        t.rv |= 1 << sl;
      }
    }
    return { t, bonus };
  }
  function plan3(s, k) {
    const lv = 3, g = greed(lv), first = dayOptions(s, k, lv);
    let best = null, bv = -1e9;
    for (const o of first) {
      const e1 = expectStep(s, k, o.a);
      let val = e1.bonus * g + (o.a.t === 'rest' ? o.v : 0);
      if (s.ap >= 2) {
        let b2 = -1e9;
        for (const o2 of dayOptions(e1.t, k, lv)) {
          const e2 = expectStep(e1.t, k, o2.a);
          b2 = Math.max(b2, e2.bonus * g + (o2.a.t === 'rest' ? o2.v : 0) + packValue(e2.t, k, lv));
        }
        val += b2;
      } else val += packValue(e1.t, k, lv);
      if (val > bv) { bv = val; best = o.a; }
    }
    return best;
  }
  /* state value for event choices (Monte Carlo over the option's random outcomes) */
  function sval(s, k, lv) {
    const p = s.p[k], g = greed(lv), v = mvals(s, p, lv);
    let t = 0;
    for (let i = 0; i < 4; i++) t += Math.min(p.r[i], 8) * v[i] * 0.9;
    if (p.o) t -= 40; else for (let h = 1; h <= p.h; h++) t += h <= 1 ? 7 : h <= 2 ? 4 : 2;
    t += (p.s[0] + p.s[1] + p.s[2] + p.s[3]) * g + relicN(p) * 1.5 - (p.k ? 4 : 0) + (p.a + p.b) * 0.7;
    const coop = lv === 1 ? 0.5 : 1;
    t += s.sg * (0.8 + 2 * urgency(s)) * coop + s.fi * 0.6 + s.sh * 1.1;
    s.p.forEach((q, j) => { if (j === k) return; if (q.o) t -= 12 * coop; else t += (q.h * 1.2 + (q.r[0] + q.r[1]) * 0.4 - (q.k ? 2 : 0)) * coop; });
    const tn = evAt(s, s.d - 1), tm = evAt(s, s.d);
    if (s.ph !== 2 && tn >= 0) t += EVG[tn];
    if (tm >= 0 && s.d < DAYS) t += EVG[tm] * 0.8;
    if (s.fl & F_WARN) t += 0.4;
    return t;
  }
  function choiceAI(s, seat, lv, E, night) {
    const opts = [];
    E.o.forEach((o, i) => { const X = mkX(JSON.parse(JSON.stringify(s)), seat, null); if (!optNeed(X, o)) opts.push(i); });
    if (!opts.length) return 0;
    if (lv === 1 && Math.random() < 0.35) return opts[Math.floor(Math.random() * opts.length)];
    const N = lv === 3 ? 10 : 6, noise = lv === 1 ? 2.5 : lv === 2 ? 0.9 : 0.1;
    let best = opts[0], bv = -1e9;
    for (const i of opts) {
      let acc = 0;
      for (let n = 0; n < N; n++) {
        const t = JSON.parse(JSON.stringify(s));
        if (night) { night(t, seat, i); if (t.end === 1) acc += 30; else if (t.end === 2) acc -= 30; }
        else { const X = mkX(t, seat, null); E.o[i].f(X); }
        acc += sval(t, seat, lv);
      }
      const val = acc / N + (Math.random() - 0.5) * noise;
      if (val > bv) { bv = val; best = i; }
    }
    return best;
  }
  const CHV = [3, 2.6, 2.9, 3.1, 3, 2.5, 2.3, 2.6, 3.5, 2.8, 3, 2.8];
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.end || seat !== actor(s)) return null;
    if (s.pe) return { t: 'ch', o: choiceAI(s, seat, lv, EVS[s.pe[1]], null) };
    if (s.ph === 2) return { t: 'ch', o: choiceAI(s, seat, lv, EVS[evAt(s, s.d - 1)], night) };
    if (s.ph === 3) {
      const c = dealt(s, seat).filter((c2) => pickOk(s, seat, c2));
      if (lv === 1) return { t: 'pick', c: c[Math.floor(Math.random() * c.length)] };
      let b = c[0]; for (const x of c) if (CHV[x] + (lv === 2 ? Math.random() * 0.6 : 0) > CHV[b]) b = x;
      return { t: 'pick', c: b };
    }
    if (lv === 3 && s.ph === 0 && (s.n === 1 || urgency(s) > 1.2)) { const a = plan3(s, seat); if (a) return a; }
    const opts = s.ph === 0 ? dayOptions(s, seat, lv) : eveOptions(s, seat, lv);
    const noise = lv === 1 ? 2.2 : lv === 2 ? 1.1 : 0.15;
    if (lv === 1 && Math.random() < 0.18) {
      const pool = opts.filter((o) => o.a.t !== 'end');
      if (pool.length) return pool[Math.floor(Math.random() * pool.length)].a;
    }
    let best = null, bv = -1e9;
    for (const o of opts) { const val = o.v + (Math.random() - 0.5) * noise; if (val > bv) { bv = val; best = o; } }
    return best ? best.a : { t: 'end' };
  }
  function aiDelayFor(s, seat, lv) { return (s.pe || s.ph === 2 ? 300 : 0) + (lv === 1 ? 780 : lv === 3 ? 480 : 620); }

  /* ======================= meta (this device only) ======================= */
  const MKEY = 'island.meta';
  const ACH = [
    { n: '첫 구조', d: '처음으로 구조되면' },
    { n: '유물 수집가', d: '한 판에 유물 3개를 모으면' },
    { n: '험난한 섬 정복', d: '「험난하게」에서 구조되면' },
    { n: '빠른 구조', d: '5일째 밤까지 구조되면' },
    { n: '섬 단골', d: '3판을 하면' },
    { n: '숨은 장소 탐험가', d: '숨은 장소를 모두 5곳 찾으면(누적)' },
    { n: '희귀한 땅', d: '희귀 구역을 발견하면' },
  ];
  const KITN = ['기본 짐', '주머니칼', '나침반', '행운의 조개'];
  function metaLoad() {
    let m = null;
    try { m = U.store ? U.store.get(MKEY, null) : null; } catch (e) { m = null; }
    if (!m || typeof m !== 'object') m = {};
    m.runs = m.runs | 0; m.wins = m.wins | 0; m.ach = m.ach | 0; m.subs = m.subs | 0;
    m.bd = m.bd | 0; m.bs = m.bs | 0;
    if (!Array.isArray(m.hist)) m.hist = [];
    return m;
  }
  function metaSave(m) { try { if (U.store) U.store.set(MKEY, m); } catch (e) { /* storage blocked */ } }
  // 판 밖 해금 없음(사용자 요청): 모든 생존자·시작 짐을 처음부터 고를 수 있어요
  const chOpen = () => true;
  const kitOpen = () => true;

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif';
  const DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const RICON = [
    [['M8 1.3C6 4.4 3.3 7.2 3.3 10.1a4.7 4.7 0 009.4 0C12.7 7.2 10 4.4 8 1.3z', '#4fa8e0'], ['M6.1 9.2c-.6 1.6.1 3 1.3 3.4-.2-1.1-.1-2.2.5-3.4z', '#d6f0ff']],
    [['M10 1.6a4.4 4.4 0 00-4.1 6l-3 2.9a1.7 1.7 0 102.4 2.4l2.9-3A4.4 4.4 0 1010 1.6z', '#cf6f34'], ['M3.4 11.2l1.3 1.3-1.1 1.1a.9.9 0 01-1.3-1.3z', '#f4e6cc'], ['M8.6 3.6a2.4 2.4 0 00-1.2 2.1', '#f2a66e']],
    [['M3.2 5h8.4a3 3 0 010 6H3.2a3 3 0 010-6z', '#9a6436'], ['M11.6 5.3a2.7 2.7 0 010 5.4 2.7 2.7 0 010-5.4z', '#e4b47a'], ['M11.6 7.1a.9.9 0 010 1.8.9.9 0 010-1.8z', '#9a6436']],
    [['M2.4 12.2 3.9 6.6 7.9 3.5l4.6 1.9 1.4 6-4.1 2.6z', '#a2a8b2'], ['M7.9 3.5 9.6 13.9 2.4 12.2z', '#7d838d']],
  ];
  const RCOL = ['#5bb3e6', '#e8913a', '#c08a52', '#b4bac4'];
  const riSvg = (i, sz) => '<svg class="is-ri" viewBox="0 0 16 16" width="' + (sz || 15) + '" height="' + (sz || 15) + '" aria-hidden="true">' +
    RICON[i].map(([d, f]) => (d.indexOf('a2.4 2.4') < 0 ? '<path d="' + d + '" fill="' + f + '"/>' : '<path d="' + d + '" fill="none" stroke="' + f + '" stroke-width="1.2" stroke-linecap="round"/>')).join('') + '</svg>';
  const P2D = {};
  function drawRI(x, i, cx, cy, sz) {
    x.save(); x.translate(cx - sz / 2, cy - sz / 2); x.scale(sz / 16, sz / 16);
    for (const [d, f] of RICON[i]) {
      const p = P2D[d] || (P2D[d] = new Path2D(d));
      if (d.indexOf('a2.4 2.4') >= 0) { x.strokeStyle = f; x.lineWidth = 1.2; x.lineCap = 'round'; x.stroke(p); } else { x.fillStyle = f; x.fill(p); }
    }
    x.restore();
  }
  const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const costHtml = (c, have) => c.map((v, i) => (v ? '<span class="cst' + (have && have[i] < v ? ' no' : '') + '">' + riSvg(i, 12) + v + '</span>' : '')).join('') || '<span class="cst">공짜</span>';
  const deltaHtml = (g, sz) => { if (!g) return ''; const o = []; if (g[0]) o.push('❤' + (g[0] > 0 ? '+' : '−') + Math.abs(g[0])); for (let i = 0; i < 4; i++) if (g[i + 1]) o.push(riSvg(i, sz || 12) + (g[i + 1] > 0 ? '+' : '−') + Math.abs(g[i + 1])); return o.join(' '); };
  function mkCanvas(w, h, dpr) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * dpr)); c.height = Math.max(1, Math.round(h * dpr)); const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); return [c, x]; }
  function rr(x, X, Y, W, H, R) { x.beginPath(); x.moveTo(X + R, Y); x.arcTo(X + W, Y, X + W, Y + H, R); x.arcTo(X + W, Y + H, X, Y + H, R); x.arcTo(X, Y + H, X, Y, R); x.arcTo(X, Y, X + W, Y, R); x.closePath(); }
  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16), f = (v) => Math.max(0, Math.min(255, v + amt));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  /* ---- little illustrations (canvas) ---- */
  function palm(x, px, py, s, lean) {
    x.strokeStyle = '#8a5a30'; x.lineWidth = s * 0.13; x.lineCap = 'round';
    x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + lean * s * 0.4, py - s * 0.5, px + lean * s * 0.25, py - s); x.stroke();
    const tx = px + lean * s * 0.25, ty = py - s;
    x.fillStyle = '#3f9a4a';
    for (let k = 0; k < 5; k++) {
      const a = -Math.PI / 2 + (k - 2) * 0.62;
      x.beginPath(); x.moveTo(tx, ty);
      x.quadraticCurveTo(tx + Math.cos(a - 0.3) * s * 0.55, ty + Math.sin(a - 0.3) * s * 0.55, tx + Math.cos(a) * s * 0.62, ty + Math.sin(a) * s * 0.62 + s * 0.2);
      x.quadraticCurveTo(tx + Math.cos(a + 0.3) * s * 0.3, ty + Math.sin(a + 0.3) * s * 0.3, tx, ty); x.fill();
    }
    x.fillStyle = '#6b4320'; x.beginPath(); x.arc(tx - s * 0.06, ty + s * 0.06, s * 0.07, 0, 7); x.arc(tx + s * 0.07, ty + s * 0.08, s * 0.07, 0, 7); x.fill();
  }
  function tree(x, px, py, s, c) {
    x.fillStyle = '#5a3a1e'; x.fillRect(px - s * 0.06, py - s * 0.3, s * 0.12, s * 0.3);
    x.fillStyle = c; x.beginPath(); x.arc(px, py - s * 0.5, s * 0.32, 0, 7); x.arc(px - s * 0.22, py - s * 0.36, s * 0.22, 0, 7); x.arc(px + s * 0.22, py - s * 0.36, s * 0.22, 0, 7); x.fill();
    x.fillStyle = 'rgba(255,255,255,.12)'; x.beginPath(); x.arc(px - s * 0.08, py - s * 0.6, s * 0.12, 0, 7); x.fill();
  }
  function rock(x, px, py, s, c) {
    x.fillStyle = c || '#8d8f96'; x.beginPath(); x.moveTo(px - s, py); x.lineTo(px - s * 0.7, py - s * 0.7); x.lineTo(px - s * 0.1, py - s); x.lineTo(px + s * 0.6, py - s * 0.75); x.lineTo(px + s, py); x.closePath(); x.fill();
    x.fillStyle = 'rgba(0,0,0,.18)'; x.beginPath(); x.moveTo(px - s * 0.1, py - s); x.lineTo(px + s * 0.6, py - s * 0.75); x.lineTo(px + s, py); x.lineTo(px + s * 0.1, py); x.closePath(); x.fill();
  }
  const TBASE = ['#e6cf94', '#2f6e3a', '#3f8a46', '#6f6b66', '#7d6a55', '#d8c08a', '#2aa6a8', '#b9c77a', '#4f8a3a', '#8a7a62', '#3d5a3a', '#4a3a36', '#7a8a4a', '#77736c', '#4a6a5a'];
  function drawTile(x, kind, cx, cy, r, sd) {
    const R = rng(sd);
    x.save();
    x.beginPath(); x.arc(cx, cy, r, 0, 7); x.clip();
    const g = x.createRadialGradient(cx - r * 0.3, cy - r * 0.4, r * 0.1, cx, cy, r * 1.1);
    g.addColorStop(0, shade(TBASE[kind], 18)); g.addColorStop(1, shade(TBASE[kind], -22));
    x.fillStyle = g; x.fillRect(cx - r, cy - r, r * 2, r * 2);
    const s = r;
    switch (kind) {
      case 0:
        x.fillStyle = '#4fb6c9'; x.beginPath(); x.ellipse(cx, cy + r * 0.95, r * 1.2, r * 0.45, 0, 0, 7); x.fill();
        x.strokeStyle = 'rgba(255,255,255,.7)'; x.lineWidth = 1.5; x.beginPath(); x.ellipse(cx, cy + r * 0.95, r * 1.2, r * 0.45, 0, Math.PI * 1.05, Math.PI * 1.95); x.stroke();
        palm(x, cx + r * 0.55, cy + r * 0.25, s * 0.7, -0.6);
        break;
      case 1: for (const [dx, dy, k] of [[-0.45, 0.1, 0.8], [0.4, 0.15, 0.85], [0, -0.15, 0.95], [-0.1, 0.55, 0.7], [0.45, 0.6, 0.6]]) tree(x, cx + dx * r, cy + dy * r + r * 0.3, s * k, k > 0.8 ? '#256b2f' : '#2f8a3a'); break;
      case 2:
        x.fillStyle = '#2f7aa8'; x.beginPath(); x.ellipse(cx, cy + r * 0.1, r * 0.6, r * 0.38, 0, 0, 7); x.fill();
        x.fillStyle = '#5fc0e8'; x.beginPath(); x.ellipse(cx - r * 0.05, cy + r * 0.05, r * 0.48, r * 0.27, 0, 0, 7); x.fill();
        x.strokeStyle = 'rgba(255,255,255,.75)'; x.lineWidth = 1.4; x.beginPath(); x.ellipse(cx, cy + r * 0.05, r * 0.22, r * 0.1, 0, 0, 7); x.stroke();
        rock(x, cx - r * 0.55, cy - r * 0.15, r * 0.28, '#7f8a8c'); rock(x, cx + r * 0.6, cy - r * 0.1, r * 0.22, '#6f7a7c');
        tree(x, cx + r * 0.1, cy - r * 0.3, s * 0.55, '#2f8a3a');
        break;
      case 3:
        rock(x, cx, cy + r * 0.55, r * 0.95, '#7a7670');
        x.fillStyle = '#1b1614'; x.beginPath(); x.moveTo(cx - r * 0.32, cy + r * 0.55); x.quadraticCurveTo(cx - r * 0.3, cy - r * 0.15, cx, cy - r * 0.2); x.quadraticCurveTo(cx + r * 0.3, cy - r * 0.15, cx + r * 0.32, cy + r * 0.55); x.closePath(); x.fill();
        x.fillStyle = '#b48cf0'; x.beginPath(); x.moveTo(cx + r * 0.12, cy + r * 0.5); x.lineTo(cx + r * 0.2, cy + r * 0.25); x.lineTo(cx + r * 0.27, cy + r * 0.5); x.fill();
        break;
      case 4:
        for (let k = 0; k < 4; k++) { x.fillStyle = shade('#8a7660', -k * 9); x.fillRect(cx - r + k * r * 0.22, cy - r * 0.6 + k * r * 0.38, r * 2, r * 0.42); }
        x.fillStyle = 'rgba(255,255,255,.18)'; for (let k = 0; k < 4; k++) x.fillRect(cx - r + k * r * 0.22, cy - r * 0.6 + k * r * 0.38, r * 2, 2);
        x.strokeStyle = '#f2e9d8'; x.lineWidth = 1.6; x.beginPath(); x.moveTo(cx - r * 0.4, cy - r * 0.7); x.quadraticCurveTo(cx - r * 0.3, cy - r * 0.8, cx - r * 0.2, cy - r * 0.7); x.quadraticCurveTo(cx - r * 0.1, cy - r * 0.8, cx, cy - r * 0.7); x.stroke();
        x.fillStyle = '#f6efe0'; x.beginPath(); x.ellipse(cx + r * 0.35, cy + r * 0.05, r * 0.09, r * 0.12, 0, 0, 7); x.ellipse(cx + r * 0.5, cy + r * 0.08, r * 0.08, r * 0.11, 0, 0, 7); x.fill();
        break;
      case 5:
        x.fillStyle = '#4aa8c0'; x.fillRect(cx - r, cy + r * 0.35, r * 2, r);
        x.fillStyle = '#6b4424'; x.beginPath(); x.moveTo(cx - r * 0.75, cy + r * 0.1); x.lineTo(cx + r * 0.5, cy - r * 0.25); x.lineTo(cx + r * 0.7, cy + r * 0.45); x.lineTo(cx - r * 0.5, cy + r * 0.62); x.closePath(); x.fill();
        x.strokeStyle = '#3e2512'; x.lineWidth = 1.2; for (let k = 1; k < 4; k++) { x.beginPath(); x.moveTo(cx - r * 0.7 + k * r * 0.3, cy + r * 0.05 - k * r * 0.09); x.lineTo(cx - r * 0.5 + k * r * 0.3, cy + r * 0.6 - k * r * 0.05); x.stroke(); }
        x.strokeStyle = '#5a3a1e'; x.lineWidth = r * 0.07; x.beginPath(); x.moveTo(cx - r * 0.05, cy - r * 0.05); x.lineTo(cx + r * 0.2, cy - r * 0.75); x.stroke();
        x.fillStyle = '#e8dcc0'; x.beginPath(); x.moveTo(cx + r * 0.2, cy - r * 0.72); x.lineTo(cx + r * 0.55, cy - r * 0.45); x.lineTo(cx + r * 0.1, cy - r * 0.38); x.closePath(); x.fill();
        break;
      case 6:
        x.fillStyle = '#e2d39a'; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.fill();
        x.fillStyle = '#29b3b5'; x.beginPath(); x.ellipse(cx, cy + r * 0.05, r * 0.72, r * 0.55, 0, 0, 7); x.fill();
        x.fillStyle = '#5ad4cf'; x.beginPath(); x.ellipse(cx - r * 0.1, cy, r * 0.45, r * 0.3, 0, 0, 7); x.fill();
        x.fillStyle = '#f08a4a'; for (const [dx, dy] of [[-0.2, 0.1], [0.25, -0.05]]) { x.beginPath(); x.ellipse(cx + dx * r, cy + dy * r, r * 0.1, r * 0.05, 0, 0, 7); x.moveTo(cx + dx * r + r * 0.09, cy + dy * r); x.lineTo(cx + dx * r + r * 0.17, cy + dy * r - r * 0.05); x.lineTo(cx + dx * r + r * 0.17, cy + dy * r + r * 0.05); x.fill(); }
        palm(x, cx - r * 0.7, cy - r * 0.2, s * 0.6, 0.5);
        break;
      case 7: palm(x, cx - r * 0.35, cy + r * 0.6, s * 0.95, 0.4); palm(x, cx + r * 0.35, cy + r * 0.7, s * 0.85, -0.5); palm(x, cx + r * 0.05, cy + r * 0.35, s * 0.6, 0.2); break;
      case 8:
        for (let k = 0; k < 7; k++) {
          const bx = cx - r * 0.75 + k * r * 0.25 + (R() - 0.5) * r * 0.08, top = cy - r * (0.5 + R() * 0.45);
          x.fillStyle = k % 2 ? '#8cc65a' : '#a4d66a'; x.fillRect(bx - r * 0.05, top, r * 0.1, r * 1.6);
          x.fillStyle = 'rgba(40,70,20,.55)'; for (let j = 1; j < 5; j++) x.fillRect(bx - r * 0.06, top + j * r * 0.28, r * 0.12, 2);
          x.fillStyle = '#5fa040'; x.beginPath(); x.ellipse(bx + r * 0.1, top + r * 0.1, r * 0.12, r * 0.035, -0.5, 0, 7); x.fill();
        }
        break;
      case 9:
        x.fillStyle = '#7da4ae'; for (const [dx, dy, a] of [[-0.35, -0.2, 0.3], [0.3, 0.1, 0.25], [-0.1, 0.45, 0.22]]) { x.beginPath(); x.ellipse(cx + dx * r, cy + dy * r, r * a * 1.4, r * a * 0.6, 0, 0, 7); x.fill(); }
        x.strokeStyle = '#f2e9d8'; x.lineWidth = 1.5; for (let k = 0; k < 5; k++) { const px = cx + (R() - 0.5) * r * 1.3, py = cy + (R() - 0.5) * r * 1.3; x.beginPath(); x.arc(px, py, r * 0.07, Math.PI, 0); x.stroke(); }
        x.fillStyle = '#d0563a'; x.beginPath(); x.ellipse(cx + r * 0.4, cy - r * 0.35, r * 0.1, r * 0.07, 0, 0, 7); x.fill();
        break;
      case 10:
        x.fillStyle = '#2f4a44'; for (const [dx, dy, a] of [[-0.3, 0, 0.42], [0.35, 0.3, 0.32]]) { x.beginPath(); x.ellipse(cx + dx * r, cy + dy * r, r * a, r * a * 0.6, 0, 0, 7); x.fill(); }
        x.fillStyle = '#4f8a4a'; for (const [dx, dy] of [[-0.35, 0.02], [0.3, 0.3], [-0.15, -0.1]]) { x.beginPath(); x.arc(cx + dx * r, cy + dy * r, r * 0.09, 0.3, 6); x.lineTo(cx + dx * r, cy + dy * r); x.fill(); }
        x.fillStyle = '#f08ab0'; x.beginPath(); x.arc(cx - r * 0.35, cy, r * 0.045, 0, 7); x.fill();
        x.strokeStyle = '#8aa040'; x.lineWidth = 1.5; for (let k = 0; k < 6; k++) { const bx = cx + r * (0.2 + k * 0.08), by = cy - r * 0.2; x.beginPath(); x.moveTo(bx, by + r * 0.25); x.lineTo(bx + (k % 2 ? 2 : -2), by - r * 0.25); x.stroke(); }
        break;
      case 11:
        x.fillStyle = '#2a2220'; x.beginPath(); x.moveTo(cx - r, cy + r * 0.8); x.lineTo(cx - r * 0.22, cy - r * 0.45); x.lineTo(cx + r * 0.22, cy - r * 0.45); x.lineTo(cx + r, cy + r * 0.8); x.closePath(); x.fill();
        x.fillStyle = '#ff7a2a'; x.beginPath(); x.ellipse(cx, cy - r * 0.45, r * 0.22, r * 0.07, 0, 0, 7); x.fill();
        x.strokeStyle = '#e05a1a'; x.lineWidth = 2; x.beginPath(); x.moveTo(cx - r * 0.05, cy - r * 0.42); x.quadraticCurveTo(cx - r * 0.2, cy, cx - r * 0.1, cy + r * 0.5); x.stroke();
        x.fillStyle = 'rgba(200,200,200,.5)'; x.beginPath(); x.arc(cx + r * 0.1, cy - r * 0.7, r * 0.18, 0, 7); x.arc(cx + r * 0.3, cy - r * 0.85, r * 0.13, 0, 7); x.fill();
        break;
      case 12:
        x.fillStyle = '#6b4a2a'; x.fillRect(cx - r * 0.45, cy - r * 0.1, r * 0.9, r * 0.55);
        x.fillStyle = '#a07a3a'; x.beginPath(); x.moveTo(cx - r * 0.6, cy - r * 0.05); x.lineTo(cx, cy - r * 0.55); x.lineTo(cx + r * 0.6, cy - r * 0.05); x.closePath(); x.fill();
        x.fillStyle = '#1e140c'; x.fillRect(cx - r * 0.12, cy + r * 0.1, r * 0.24, r * 0.35);
        x.strokeStyle = 'rgba(30,20,10,.6)'; x.lineWidth = 1.5; x.beginPath(); x.moveTo(cx + r * 0.2, cy - r * 0.35); x.lineTo(cx + r * 0.35, cy - r * 0.2); x.stroke();
        tree(x, cx - r * 0.65, cy + r * 0.6, s * 0.5, '#4f7a2a');
        break;
      case 13:
        rock(x, cx, cy + r * 0.85, r * 0.9, '#5a5650');
        x.fillStyle = '#efe6d6'; x.beginPath(); x.moveTo(cx - r * 0.22, cy + r * 0.45); x.lineTo(cx - r * 0.13, cy - r * 0.55); x.lineTo(cx + r * 0.13, cy - r * 0.55); x.lineTo(cx + r * 0.22, cy + r * 0.45); x.closePath(); x.fill();
        x.fillStyle = '#c0392b'; for (let k = 0; k < 3; k++) x.fillRect(cx - r * 0.2 + k * 0.02 * r, cy + r * (0.25 - k * 0.32), r * (0.4 - k * 0.04), r * 0.12);
        x.fillStyle = '#ffe9a0'; x.fillRect(cx - r * 0.12, cy - r * 0.72, r * 0.24, r * 0.17);
        x.fillStyle = '#3a3632'; x.beginPath(); x.moveTo(cx - r * 0.18, cy - r * 0.72); x.lineTo(cx, cy - r * 0.88); x.lineTo(cx + r * 0.18, cy - r * 0.72); x.fill();
        break;
      case 14:
        x.fillStyle = '#7a7670'; x.fillRect(cx - r, cy - r, r * 2, r * 0.75);
        x.fillStyle = '#5a5650'; x.fillRect(cx - r, cy - r * 0.3, r * 2, r * 0.08);
        x.fillStyle = '#7fc8e8'; x.fillRect(cx - r * 0.2, cy - r * 0.9, r * 0.4, r * 1.2);
        x.fillStyle = 'rgba(255,255,255,.6)'; for (let k = 0; k < 4; k++) x.fillRect(cx - r * 0.16 + k * r * 0.1, cy - r * 0.85, 1.5, r * 1.1);
        x.fillStyle = '#3f9ac0'; x.beginPath(); x.ellipse(cx, cy + r * 0.45, r * 0.6, r * 0.25, 0, 0, 7); x.fill();
        x.fillStyle = 'rgba(255,255,255,.8)'; x.beginPath(); x.ellipse(cx, cy + r * 0.32, r * 0.3, r * 0.08, 0, 0, 7); x.fill();
        break;
    }
    x.fillStyle = 'rgba(0,0,0,.07)';
    for (let k = 0; k < 16; k++) { x.beginPath(); x.arc(cx + (R() - 0.5) * r * 1.8, cy + (R() - 0.5) * r * 1.8, 0.6 + R() * 1.2, 0, 7); x.fill(); }
    x.restore();
    x.strokeStyle = KINDS[kind].rare ? 'rgba(230,180,70,.9)' : 'rgba(30,20,10,.55)'; x.lineWidth = KINDS[kind].rare ? 2.6 : 2; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.stroke();
    x.strokeStyle = 'rgba(255,240,200,.25)'; x.lineWidth = 1; x.beginPath(); x.arc(cx, cy, r - 2, Math.PI * 1.05, Math.PI * 1.7); x.stroke();
  }
  function fog(x, cx, cy, r, t, open) {
    x.save(); x.beginPath(); x.arc(cx, cy, r, 0, 7); x.clip();
    const g = x.createRadialGradient(cx, cy, r * 0.2, cx, cy, r);
    if (open) { g.addColorStop(0, '#5f6f62'); g.addColorStop(1, '#3a4a40'); } else { g.addColorStop(0, '#3a443e'); g.addColorStop(1, '#262e2a'); }
    x.fillStyle = g; x.fillRect(cx - r, cy - r, r * 2, r * 2);
    x.fillStyle = open ? 'rgba(230,236,232,.55)' : 'rgba(200,210,205,.25)';
    for (let k = 0; k < 6; k++) { const a = k * 1.05 + t * 0.0003, rr2 = r * (0.28 + (k % 3) * 0.07); x.beginPath(); x.arc(cx + Math.cos(a) * r * 0.42, cy + Math.sin(a) * r * 0.32, rr2, 0, 7); x.fill(); }
    x.restore();
    x.strokeStyle = open ? 'rgba(230,236,232,.6)' : 'rgba(230,236,232,.18)'; x.lineWidth = 2; x.setLineDash([4, 4]); x.beginPath(); x.arc(cx, cy, r, 0, 7); x.stroke(); x.setLineDash([]);
    if (open) { x.fillStyle = '#f2e9d8'; x.font = '700 ' + Math.round(r * 0.6) + 'px ' + DISP; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('?', cx, cy - r * 0.08); }
  }
  function pawn(x, cx, cy, s, color, o) {
    o = o || {};
    x.save(); x.translate(cx, cy);
    if (o.down) { x.rotate(Math.PI / 2); x.globalAlpha = 0.55; }
    x.fillStyle = 'rgba(0,0,0,.3)'; x.beginPath(); x.ellipse(0, s * 0.45, s * 0.42, s * 0.13, 0, 0, 7); x.fill();
    if (o.ring) { x.strokeStyle = o.ring; x.lineWidth = 2.5; x.beginPath(); x.ellipse(0, s * 0.43, s * 0.56, s * 0.19, 0, 0, 7); x.stroke(); }
    x.fillStyle = color; x.strokeStyle = 'rgba(20,10,10,.6)'; x.lineWidth = 1.3;
    x.beginPath(); x.moveTo(-s * 0.32, s * 0.42); x.quadraticCurveTo(-s * 0.35, -s * 0.06, 0, -s * 0.08); x.quadraticCurveTo(s * 0.35, -s * 0.06, s * 0.32, s * 0.42); x.closePath(); x.fill(); x.stroke();
    x.fillStyle = '#f1cfa6'; x.beginPath(); x.arc(0, -s * 0.24, s * 0.17, 0, 7); x.fill(); x.stroke();
    x.fillStyle = '#e8c86a'; x.beginPath(); x.ellipse(0, -s * 0.33, s * 0.32, s * 0.08, 0, 0, 7); x.fill();
    x.beginPath(); x.ellipse(0, -s * 0.38, s * 0.15, s * 0.11, 0, Math.PI, 0); x.fill();
    x.fillStyle = color; x.fillRect(-s * 0.15, -s * 0.38, s * 0.3, s * 0.04);
    x.restore();
    if (o.sick) { x.font = '700 ' + Math.round(s * 0.36) + 'px ' + FONT; x.textAlign = 'center'; x.fillText('🤒', cx + s * 0.38, cy - s * 0.45); }
  }
  function flame(x, cx, cy, s, t, k) {
    const f = 1 + 0.12 * Math.sin(t * 0.013 + k) + 0.08 * Math.sin(t * 0.031 + k * 2);
    x.save(); x.translate(cx, cy); x.scale(1, f);
    const g = x.createRadialGradient(0, -s * 0.2, s * 0.05, 0, -s * 0.2, s * 0.8);
    g.addColorStop(0, '#fff3a6'); g.addColorStop(0.45, '#ffb03a'); g.addColorStop(1, 'rgba(230,70,30,0)');
    x.fillStyle = g;
    x.beginPath(); x.moveTo(0, -s); x.bezierCurveTo(s * 0.6, -s * 0.3, s * 0.5, s * 0.25, 0, s * 0.25); x.bezierCurveTo(-s * 0.5, s * 0.25, -s * 0.6, -s * 0.3, 0, -s); x.fill();
    x.restore();
  }
  /* event card art: category scene + big emoji */
  const CATBG = [['#2a3046', '#5a6a8a'], ['#173a22', '#3f7a3a'], ['#0f3a5a', '#2f8ab0'], ['#3a2a1e', '#8a5a3a'], ['#2a1f4a', '#6a4aa0'], ['#2a1a3a', '#5a3a6a']];
  function eventArt(cv, e, w, h) {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    const x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0);
    const E = EVS[e], c = E.c, R = rng(e * 131 + 7), bg = CATBG[c];
    const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, bg[0]); g.addColorStop(1, bg[1]);
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    if (c === 4 || c === 0 || E.t === 0) { x.fillStyle = '#fff'; for (let k = 0; k < 26; k++) { x.globalAlpha = 0.2 + R() * 0.6; x.fillRect(R() * w, R() * h * 0.6, 1.5, 1.5); } x.globalAlpha = 1; }
    if (c === 2) { x.strokeStyle = 'rgba(200,240,255,.35)'; x.lineWidth = 2; for (let k = 0; k < 4; k++) { x.beginPath(); for (let i = 0; i <= 24; i++) x.lineTo(i * w / 24, h * (0.62 + k * 0.1) + Math.sin(i * 0.9 + k) * 3); x.stroke(); } }
    if (c === 1) { x.fillStyle = 'rgba(10,30,12,.6)'; for (let k = 0; k < 7; k++) { const bx = R() * w, bs = h * (0.35 + R() * 0.3); x.beginPath(); x.arc(bx, h, bs, Math.PI, 0); x.fill(); } }
    if (c === 3) { x.fillStyle = 'rgba(30,18,10,.55)'; x.beginPath(); x.moveTo(0, h); for (let i = 0; i <= 8; i++) x.lineTo(i * w / 8, h * (0.6 + R() * 0.25)); x.lineTo(w, h); x.fill(); }
    if (c === 5) { x.strokeStyle = 'rgba(220,190,255,.25)'; x.lineWidth = 2; for (let k = 0; k < 3; k++) { x.beginPath(); x.arc(w * (0.2 + k * 0.3), h * 0.5, h * (0.2 + k * 0.08), 0, 5); x.stroke(); } }
    if (c === 0) { x.fillStyle = 'rgba(20,24,36,.6)'; for (let k = 0; k < 5; k++) { x.beginPath(); x.ellipse(w * (0.1 + k * 0.22), h * 0.16, w * 0.16, h * 0.14, 0, 0, 7); x.fill(); } }
    const glow = x.createRadialGradient(w / 2, h * 0.52, 2, w / 2, h * 0.52, h * 0.55); glow.addColorStop(0, 'rgba(255,240,200,.35)'); glow.addColorStop(1, 'rgba(255,240,200,0)');
    x.fillStyle = glow; x.fillRect(0, 0, w, h);
    x.font = Math.round(h * 0.56) + 'px ' + FONT; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.shadowColor = 'rgba(0,0,0,.5)'; x.shadowBlur = 8; x.fillText(E.ic, w / 2, h * 0.54); x.shadowBlur = 0;
    x.fillStyle = 'rgba(0,0,0,.35)'; rr(x, 6, 6, 62, 20, 10); x.fill();
    x.fillStyle = '#f2e9d8'; x.font = '700 11px ' + FONT; x.textAlign = 'left'; x.fillText(CATS[c][0] + ' ' + (E.t ? '만남' : CATS[c][1]), 13, 16.5);
  }

  const CSS = `
.is-ui{position:absolute;inset:0;pointer-events:none;font-family:var(--f-body);color:var(--ink)}
.is-ui *{box-sizing:border-box}
.is-ri{display:inline-block;vertical-align:-2px;flex:none}
.is-chips{position:absolute;left:6px;right:6px;top:6px;display:flex;gap:5px;pointer-events:auto}
.is-chip{flex:1 1 0;min-width:0;height:48px;border-radius:12px;background:var(--surface);border:1.5px solid rgba(242,233,216,.1);padding:3px 5px 3px 9px;display:flex;flex-direction:column;justify-content:center;gap:3px;cursor:pointer;color:inherit;font:inherit;text-align:left;position:relative;overflow:hidden}
.is-chip::before{content:'';position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--pc)}
.is-chip.cur{border-color:var(--brass);background:var(--surface-2)}
.is-chip.out{opacity:.5}
.is-chip .r1{display:flex;align-items:center;gap:3px;font-size:12px;font-weight:700;min-width:0;line-height:15px}
.is-chip .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.is-chip .sc{font-family:var(--f-mono);font-size:11px;color:var(--brass);flex:none}
.is-chip .r2{display:flex;align-items:center;gap:3px;font-size:11px;font-family:var(--f-mono);line-height:13px;white-space:nowrap;overflow:hidden}
.is-mt{display:inline-flex;gap:1.5px;flex:none}.is-mt i{width:5px;height:9px;border-radius:2px;background:rgba(255,255,255,.14)}
.is-mt.f i.on{background:#e8913a}.is-mt.w i.on{background:#5bb3e6}.is-mt i.warn{background:#ee6a55}
.is-banner{position:absolute;left:6px;right:6px;top:60px;height:52px;border-radius:12px;background:linear-gradient(180deg,#2a2238,#221c2e);border:1px solid rgba(242,233,216,.1);padding:4px 8px;display:flex;flex-direction:column;justify-content:center;gap:3px;pointer-events:auto;cursor:pointer;overflow:hidden}
.is-b1,.is-b2{display:flex;align-items:center;gap:5px;min-width:0;white-space:nowrap}
.is-day{font-family:var(--f-display);font-size:15px;line-height:20px;flex:none}
.is-dots{display:flex;gap:3px;flex:none}.is-dots i{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.14)}
.is-dots i.past{background:#8a7a55}.is-dots i.now{background:var(--brass);box-shadow:0 0 0 2px rgba(227,174,69,.3)}
.is-dots i.cold{box-shadow:inset 0 -2px 0 rgba(140,190,255,.8)}
.is-omen{margin-left:auto;font-size:11px;font-weight:700;background:rgba(0,0,0,.28);border-radius:999px;padding:2px 7px;flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}
.is-st{font-size:12px;font-weight:700;font-family:var(--f-mono);flex:none}
.is-wx{font-size:13px;flex:none}
.is-sig{flex:1;min-width:40px;height:14px;border-radius:7px;background:rgba(0,0,0,.35);position:relative;overflow:hidden;box-shadow:inset 0 0 0 1px rgba(242,233,216,.12)}
.is-sig b{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#d2672f,#f2c14e);border-radius:7px;transition:width .5s}
.is-sig span{position:absolute;inset:0;text-align:center;font-size:10.5px;line-height:14px;font-family:var(--f-mono);font-weight:700;color:#fff;text-shadow:0 1px 2px #000}
.is-bottom{position:absolute;left:0;right:0;bottom:0;padding:6px 8px 8px;display:flex;flex-direction:column;gap:6px;pointer-events:auto;background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.92) 14px)}
.is-hint{font-size:12.5px;line-height:17px;min-height:17px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.is-hint b{color:var(--brass)}
.is-pack{display:flex;align-items:center;gap:5px;min-height:40px;padding:3px 6px;border-radius:12px;background:var(--surface);border:1px solid rgba(242,233,216,.1);overflow:hidden;cursor:pointer;color:inherit;font:inherit;width:100%;text-align:left}
.is-pack .who{font-size:11px;font-weight:700;max-width:62px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:none}
.is-res{display:inline-flex;align-items:center;gap:2px;font-family:var(--f-mono);font-weight:700;font-size:14px;padding:2px 4px;border-radius:8px;background:rgba(0,0,0,.22);flex:none}
.is-res.low{box-shadow:inset 0 0 0 1.5px #ee6a55}
.is-res.full{box-shadow:inset 0 0 0 1.5px #e3ae45}
.is-tools{display:flex;gap:1px;font-size:14px;margin-left:auto;flex:0 1 auto;min-width:0;overflow:hidden;white-space:nowrap}
.is-row{display:flex;gap:6px}
.is-row .btn{flex:1 1 0;min-width:0;min-height:46px;padding:4px 6px;font-size:14px;white-space:nowrap}
.is-row .btn.primary{flex:1.5 1 0}
.is-tabs{display:flex;gap:5px}
.is-tabs .btn{flex:1;min-width:0;min-height:44px;font-size:12.5px;padding:4px 4px;white-space:nowrap}
.is-tabs .btn.on{background:var(--brass);color:#2a1f18;border-color:var(--brass)}
.is-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px}
.is-card{min-height:52px;border-radius:10px;background:#f3e8d2;color:#2a1f18;border:0;padding:3px 3px 2px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;font:inherit;cursor:pointer;position:relative;outline:2px solid transparent;outline-offset:1px}
.is-card .t{font-size:11.5px;font-weight:700;line-height:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.is-card .t i{font-style:normal;margin-right:2px}
.is-card .c{display:flex;gap:3px;font-family:var(--f-mono);font-size:11px;font-weight:700;line-height:13px;justify-content:center;flex-wrap:wrap}
.is-card .cst{display:inline-flex;align-items:center;gap:1px}.is-card .cst.no{color:#c0392b}
.is-card.off{opacity:.42}
.is-card.sel{outline-color:var(--brass);background:#fff6df}
.is-card.up::before{content:'⬆';position:absolute;left:4px;top:1px;font-size:10px;color:#b5541c;font-weight:800}
.is-card.own{opacity:.55}.is-card.own::after{content:'✓';position:absolute;right:4px;top:1px;font-size:11px;color:#1c6650;font-weight:800}
.is-night{position:absolute;display:none;flex-direction:column;align-items:center;gap:4px;padding:10px 12px;border-radius:16px;background:rgba(14,18,38,.9);border:1px solid rgba(160,190,255,.25);box-shadow:0 10px 30px rgba(0,0,0,.45);pointer-events:auto;text-align:center;cursor:pointer;overflow-y:auto;z-index:3}
.is-night .ic{font-size:30px;line-height:34px}
.is-night .tt{font-family:var(--f-display);font-size:18px;line-height:22px}
.is-night .dd{font-size:12px;line-height:16px;color:#cfd6ee}
.is-night .fx{font-size:12px;line-height:17px;display:flex;flex-direction:column;gap:1px;max-width:100%}
.is-night .fx div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.is-night .mo{margin-top:2px;font-size:12px;line-height:16px;color:#ffe2a0;border-top:1px solid rgba(255,255,255,.12);padding-top:4px;width:100%}
.is-pop{position:absolute;left:8px;right:8px;top:58px;display:none;padding:10px 12px;border-radius:14px;background:var(--surface);border:1px solid rgba(227,174,69,.45);box-shadow:0 10px 30px rgba(0,0,0,.5);pointer-events:auto;font-size:12.5px;line-height:19px;z-index:6;cursor:pointer;max-height:calc(100% - 70px);overflow-y:auto}
.is-pop h4{margin:0 0 4px;font-family:var(--f-display);font-weight:400;font-size:16px}
.is-pop .ln{display:flex;flex-wrap:wrap;gap:3px 10px;align-items:center}
.is-pop .rl{display:block;font-size:12px;line-height:17px}
.is-spot{position:absolute;pointer-events:none}
.is-ev{position:absolute;display:none;flex-direction:column;border-radius:16px;background:#1f1a2b;border:1px solid rgba(227,174,69,.5);box-shadow:0 12px 36px rgba(0,0,0,.55);pointer-events:auto;overflow:hidden;z-index:4}
.is-ev canvas{display:block;width:100%;flex:none}
.is-ev .bd{padding:8px 10px 10px;display:flex;flex-direction:column;gap:6px;overflow-y:auto;min-height:0}
.is-ev .tt{font-family:var(--f-display);font-size:18px;line-height:22px}
.is-ev .dd{font-size:12.5px;line-height:17px;color:#d8cfe0}
.is-ev .opt{min-height:48px;border-radius:12px;border:1.5px solid rgba(227,174,69,.55);background:#2e2640;color:var(--ink);font:inherit;text-align:left;padding:5px 10px;display:flex;flex-direction:column;justify-content:center;gap:1px;cursor:pointer}
.is-ev .opt b{font-size:14px;line-height:18px}
.is-ev .opt span{font-size:11.5px;line-height:15px;color:#e8c98a}
.is-ev .opt:disabled{opacity:.45;cursor:default}
.is-ev .opt .no{color:#ee8a75}
.is-ev .wait{font-size:12.5px;text-align:center;color:var(--muted)}
.is-ov{position:absolute;left:6px;right:6px;top:6px;bottom:6px;display:none;flex-direction:column;gap:8px;padding:12px;border-radius:16px;background:rgba(26,21,36,.97);border:1px solid rgba(227,174,69,.4);box-shadow:0 12px 40px rgba(0,0,0,.55);pointer-events:auto;overflow-y:auto;z-index:5}
.is-ov h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:20px;line-height:24px}
.is-ov .sub{font-size:12.5px;line-height:17px;color:var(--muted);margin:0}
.is-chs{display:flex;flex-direction:column;gap:6px}
.is-ch{min-height:58px;border-radius:12px;border:1.5px solid rgba(242,233,216,.15);background:var(--surface-2);color:var(--ink);font:inherit;text-align:left;padding:6px 10px;display:flex;align-items:center;gap:10px;cursor:pointer}
.is-ch .i{font-size:26px;line-height:30px;flex:none;width:32px;text-align:center}
.is-ch .tx{display:flex;flex-direction:column;gap:1px;min-width:0}
.is-ch .tx b{font-size:14.5px;line-height:18px}
.is-ch .tx span{font-size:12px;line-height:16px;color:#d8cfe0}
.is-ch .tx em{font-style:normal;font-size:11.5px;line-height:15px;color:var(--brass)}
.is-ch.sel{border-color:var(--brass);background:#3a2f22}
.is-ch:disabled{opacity:.42;cursor:default}
.is-xg{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px}
.is-x{min-height:48px;border-radius:10px;border:1.5px solid rgba(242,233,216,.15);background:var(--surface-2);color:var(--ink);font:inherit;font-size:11.5px;font-weight:700;line-height:14px;padding:3px 2px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;cursor:pointer}
.is-x i{font-style:normal;font-size:18px;line-height:20px}
.is-x.lk{opacity:.5}.is-x.sel{border-color:var(--brass);background:#3a2f22}
.is-ov .stick{position:sticky;bottom:-12px;margin:0 -12px -12px;padding:8px 12px 12px;background:linear-gradient(180deg,rgba(26,21,36,0),rgba(26,21,36,.98) 10px)}
.is-kits{display:flex;gap:5px;flex-wrap:wrap}
.is-kits .btn{min-height:44px;font-size:12.5px;padding:4px 9px;flex:1 1 auto}
.is-kits .btn.on{background:var(--brass);color:#2a1f18;border-color:var(--brass)}
.is-lbl{font-size:12px;font-weight:700;color:var(--brass);margin-top:2px}
.is-sumg{display:flex;flex-direction:column;gap:3px;font-size:12.5px;line-height:17px}
.is-bar{display:flex;align-items:center;gap:6px}.is-bar i{display:block;height:9px;border-radius:5px;background:#ee6a55;flex:none}.is-bar.g i{background:#5fbf7a}
.is-bar span{flex:none;min-width:84px}
.is-rec{font-size:12px;line-height:17px;display:flex;flex-direction:column;gap:2px}
.is-ov .btn{min-height:46px}
`;

  const NIGHT_MS = 3000;
  const seatAng = (k, n) => Math.PI * (n === 1 ? 0.2 : 0.15 + 0.7 * k / (n - 1));
  const FXK = { 0: 'storm', 1: 'rain', 2: 'heat', 3: 'fog', 4: 'stars', 5: 'boar', 6: 'monkey', 7: 'snake', 8: 'bugs', 9: 'crab', 10: 'shark', 11: 'crate', 12: 'turtle', 13: 'ship', 14: 'sick', 15: 'sick', 16: 'rocks', 17: 'meteor', 18: 'calm', 19: 'spark', 20: 'wave', 21: 'dogs', 22: 'light', 23: 'whale', 24: 'dark', 25: 'ghost', 26: 'camps', 27: 'xmark', 28: 'crate', 29: 'thief', 30: 'quake', 31: 'fly' };

  function mount(root, api) {
    const h = L.h;
    const cv = U.canvas(root), ctx = cv.ctx;
    const style = h('style', { text: CSS });
    const ui = h('div', { class: 'is-ui' });
    root.append(style, ui);
    const chips = h('div', { class: 'is-chips' });
    const banner = h('div', { class: 'is-banner', role: 'button', 'aria-label': '날씨·징조 자세히', onclick: (e) => { e.stopPropagation(); api.sfx('click'); popSeat = popSeat === -2 ? -1 : -2; renderPop(); } });
    const bottom = h('div', { class: 'is-bottom' });
    const nightCard = h('div', { class: 'is-night', onclick: hideNight });
    const pop = h('div', { class: 'is-pop', onclick: () => { popSeat = -1; pop.style.display = 'none'; } });
    const evCard = h('div', { class: 'is-ev' });
    const ov = h('div', { class: 'is-ov' });
    const spScene = h('div', { class: 'is-spot is-scene' }), spCamp = h('div', { class: 'is-spot is-camp' });
    ui.append(spScene, spCamp, chips, banner, bottom, nightCard, evCard, ov, pop);

    let st = null, LY = null, statics = {}, sel = -1, tab = 0, selR = -1, popSeat = -1;
    let anim = null, busy = false, stopLoop = null, safety = 0, shownSeq = -1, waitSeq = -1, waitUntil = 0, frame = 0, nightHide = 0;
    let lastNight = null, nightView = null, floats = [], fxStart = 0, dawnT = -1e9, shake = 0;
    let pickC = -1, pickKit = 0, ovMode = '', sumHold = false, sumTimer = 0, recorded = '', sumShown = '', lastTut = false, unlockedNow = [], recShow = false;
    let meta = metaLoad();
    const anyLocal = api.players.some((p, i) => api.canAct(i));
    const col = (k) => (api.players[k] && api.players[k].color) || L.COLORS[k % L.COLORS.length];
    const pname = (k) => (api.players[k] && api.players[k].name) || (st && st.nm[k]) || (k + 1) + '번';
    const localCount = () => { let c = 0; for (let i = 0; i < (st ? st.n : 0); i++) if (api.canAct(i)) c++; return c; };
    const callName = (k) => (localCount() === 1 && api.canAct(k) ? '나' : pname(k));
    const setBusy = (v) => { if (busy !== v) { busy = v; api.setBusy(v); } };
    const myTurn = () => { const a = st && actor(st); return a != null && api.canAct(a); };
    const locked = () => st && st.seq === waitSeq && performance.now() < waitUntil;
    const canInput = () => st && !st.end && myTurn() && !locked() && !busy;
    const sp = () => L.debug.speed || 1;
    function viewSeat() {
      if (!st) return 0;
      const a = actor(st);
      if (a != null && api.canAct(a)) return a;
      for (let i = 0; i < st.n; i++) if (api.canAct(i)) return i;
      return a != null ? a : 0;
    }
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; sel = -1; selR = -1; api.buzz(10); api.act(a); render(); }
    const chIc = (k) => { const p = st.p[k]; return p && p.c >= 0 ? CH[p.c].ic : '❔'; };
    const relicIcons = (p) => { let o = ''; for (let i = 0; i < RL.length; i++) if ((p.x >> i) & 1) o += RL[i].ic; return o; };
    const toolIcons = (p) => RC.filter((r) => r.bit && p.t & r.bit && !RC.some((u) => u.req === r.bit && u.bit && p.t & u.bit)).map((r) => r.ic).join('');

    /* ---------- DOM renders ---------- */
    function meter(v, cls) { let o = '<span class="is-mt ' + cls + '">'; for (let i = 0; i < 3; i++) o += '<i class="' + (i < v ? 'on' : v === 0 && i === 0 ? 'warn' : '') + '"></i>'; return o + '</span>'; }
    function renderChips() {
      chips.innerHTML = '';
      const cur = actor(st);
      st.p.forEach((p, k) => {
        const b = h('button', { class: 'is-chip' + (k === cur ? ' cur' : '') + (p.o ? ' out' : ''), style: { '--pc': col(k) }, 'aria-label': pname(k) + ' 정보',
          onclick: (e) => { e.stopPropagation(); api.sfx('click'); popSeat = popSeat === k ? -1 : k; renderPop(); } });
        b.innerHTML = '<div class="r1"><span>' + chIc(k) + '</span><span class="nm">' + esc(pname(k)) + '</span><span class="sc">' + total(p) + '</span></div>' +
          '<div class="r2">' + (p.o ? '💤 쓰러짐' : '❤' + p.h + ' ' + meter(p.a, 'f') + meter(p.b, 'w') + (p.k ? '🤒' : '') + (p.x ? '<span style="color:#e3ae45">✦' + relicN(p) + '</span>' : '')) + '</div>';
        chips.append(b);
      });
    }
    function omenHtml(d) { const c = omenC(st, d); return c >= 0 ? CATS[c][0] + ' ' + CATS[c][1] : ''; }
    const seeFar = () => (st.cb & CB_LOOK) || anyHas(st, P_OMEN2);
    function renderPop() {
      if (popSeat === -1 || !st) { pop.style.display = 'none'; return; }
      if (popSeat === -2) {
        const d = st.d, W = WX[wxAt(st, d)], M = DM[dmAt(st, d)], W2 = d < DAYS ? WX[wxAt(st, d + 1)] : null;
        let o = '<h4>🏝 ' + d + '일째 · 섬 상황</h4>';
        o += '<div class="rl">' + W.ic + ' <b>오늘 날씨: ' + W.n + '</b> — ' + W.d + '</div>';
        o += '<div class="rl">' + M.ic + ' <b>오늘의 섬: ' + M.n + '</b> — ' + M.d + '</div>';
        if (W2) o += '<div class="rl">🔮 내일 날씨: ' + W2.ic + ' ' + W2.n + '</div>';
        if (!st.end && st.ph !== 3) o += '<div class="rl">🌙 오늘 밤 징조: <b>' + omenHtml(d) + '</b>' + (seeFar() && d < DAYS ? ' · 내일 밤: ' + omenHtml(d + 1) : '') + '</div>';
        o += '<div class="rl">🔥 불 ' + st.fi + '/4 · ⛺ 움막 ' + st.sh + '/3 · 📡 신호 ' + st.sg + '/' + st.G + (d >= COLD_D ? ' · 🥶 추운 밤(불이 2씩 타요)' : ' · ' + COLD_D + '일째부터 밤엔 불이 2씩 타요') + '</div>';
        const b = []; RC.forEach((R) => { if (R.cb && st.cb & R.cb) b.push(R.ic + R.n); });
        if (b.length) o += '<div class="rl">🏕 캠프: ' + b.join(' · ') + '</div>';
        let found = 0, subs = 0; for (let sl = 1; sl < NS; sl++) { if (rvd(st, sl)) found++; if (subOn(st, sl)) subs++; }
        o += '<div class="rl">🗺 발견한 구역 ' + found + '/' + (NS - 1) + ' · 숨은 장소 ' + subs + '곳</div>';
        if (lastNight) o += '<div class="rl" style="color:var(--brass)">📜 지난밤: ' + EVS[lastNight.info.e].ic + ' ' + EVS[lastNight.info.e].n + ' (다시 보기는 아래 버튼)</div>';
        pop.innerHTML = o + '<div class="ln" style="margin-top:6px">' + (lastNight ? '<button class="btn sm" data-ln="1" style="min-height:44px">📜 지난밤 결과 다시 보기</button>' : '') + '<span class="muted" style="font-size:11px">탭하면 닫혀요</span></div>';
        const bt = pop.querySelector('[data-ln]');
        if (bt) bt.onclick = (e) => { e.stopPropagation(); popSeat = -1; pop.style.display = 'none'; if (lastNight) showNight(lastNight, 4500, true); };
        pop.style.display = 'block';
        return;
      }
      if (!st.p[popSeat]) { pop.style.display = 'none'; return; }
      const p = st.p[popSeat], k = popSeat;
      const tools = RC.filter((r) => r.bit && p.t & r.bit).map((r) => r.ic + r.n).join(' ') || '없음';
      let rel = ''; for (let i = 0; i < RL.length; i++) if ((p.x >> i) & 1) rel += '<span class="rl">' + RL[i].ic + ' <b>' + RL[i].n + '</b> — ' + RL[i].d + '</span>';
      const C = p.c >= 0 ? CH[p.c] : null;
      pop.innerHTML = '<h4 style="color:' + col(k) + '">' + (C ? C.ic + ' ' : '') + esc(pname(k)) + (C ? ' · ' + C.n : '') + (p.o ? ' · 쓰러짐' : '') + '</h4>' +
        (C ? '<div class="rl" style="color:#d8cfe0">특성: ' + C.d + '</div>' : '') +
        '<div class="ln">❤ ' + p.h + '/' + maxH(p) + ' <span>배 ' + meter(p.a, 'f') + '</span><span>물 ' + meter(p.b, 'w') + '</span>' + (p.k ? ' 🤒 열병' : '') + ' · 짐 한도 ' + capOf(p) + '</div>' +
        '<div class="ln">짐: ' + [0, 1, 2, 3].map((i) => riSvg(i, 14) + RN[i] + ' ' + p.r[i]).join(' · ') + '</div>' +
        '<div class="ln">도구: ' + tools + '</div>' +
        (rel ? '<div style="margin-top:2px"><b>유물</b>' + rel + '</div>' : '<div class="ln muted">유물: 아직 없음</div>') +
        '<div class="ln" style="color:var(--brass)">점수 ' + total(p) + ' = 발견 ' + p.s[0] + ' + 보물·유물 ' + p.s[1] + ' + 기여 ' + p.s[2] + ' + 도구 ' + p.s[3] + ' + 체력 ' + (p.o ? 0 : p.h) + ' + 남은 물자 ' + (p.o ? 0 : keep(p)) + '</div>' +
        '<div class="ln muted" style="font-size:11px">탭하면 닫혀요 · 남은 물자는 3개마다 1점</div>';
      pop.style.display = 'block';
    }
    function renderBanner() {
      const nv = nightView, d = nv ? nv.d : Math.min(st.d, DAYS);
      const ph = nv ? 2 : st.end ? 2 : st.ph === 3 ? 0 : st.ph;
      const phI = ['☀', '🌅', '🌙'][ph], phN = ['낮', '저녁', '밤'][ph];
      let dots = '';
      for (let i = 1; i <= DAYS; i++) dots += '<i class="' + (i < d ? 'past' : i === d ? 'now' : '') + (i >= COLD_D ? ' cold' : '') + '"></i>';
      const om = !nv && !st.end && st.ph !== 3 ? omenHtml(st.d) : '';
      const sgW = Math.min(100, Math.round(st.sg / st.G * 100));
      const W = WX[wxAt(st, d)], M = DM[dmAt(st, d)];
      banner.innerHTML = '<div class="is-b1"><span class="is-day">' + phI + ' ' + d + '일째 ' + phN + '</span><span class="is-wx" title="' + W.n + '">' + W.ic + (dmAt(st, d) ? M.ic : '') + '</span><span class="is-dots">' + dots + '</span>' +
        (om ? '<span class="is-omen">징조 ' + om + (seeFar() && st.d < DAYS ? ' → ' + CATS[omenC(st, st.d + 1)][0] : '') + '</span>' : lastNight ? '<span class="is-omen">📜 지난밤</span>' : '') + '</div>' +
        '<div class="is-b2"><span class="is-st">🔥' + st.fi + '</span><span class="is-st">⛺' + st.sh + '</span>' +
        '<span class="is-st" style="font-family:var(--f-body)">신호</span><span class="is-sig"><b style="width:' + sgW + '%"></b><span>' + st.sg + ' / ' + st.G + '</span></span></div>';
    }
    function resRow(k) {
      const p = st.p[k], NL = DAYS + 1 - st.d, cap = capOf(p);
      let o = '<span class="who" style="color:' + col(k) + '">' + chIc(k) + ' ' + esc(callName(k)) + '</span>';
      for (let i = 0; i < 4; i++) o += '<span class="is-res' + (i < 2 && p.r[i] < 1 && NL > 0 && !p.o ? ' low' : p.r[i] >= cap ? ' full' : '') + '">' + riSvg(i, 16) + p.r[i] + '</span>';
      o += '<span class="is-tools">' + (p.k ? '🤒' : '') + toolIcons(p) + relicIcons(p) + '</span>';
      return o;
    }
    function yieldHtml(y) { return y.map((v, i) => (v ? riSvg(i, 13) + '+' + v : '')).filter(Boolean).join(' '); }
    function hintText() {
      if (!st) return '';
      if (st.end) return st.end === 1 ? '🚢 구조 성공!' : '구조선이 오지 않았어요…';
      if (nightView) return '🌙 밤이 지나가요… (카드를 탭하면 넘어가요)';
      const a = actor(st), mine = api.canAct(a), who = callName(a);
      if (st.pe) return mine ? '<b>' + EVS[st.pe[1]].ic + ' ' + EVS[st.pe[1]].n + '</b> — 어떻게 할지 고르세요' : esc(pname(a)) + '이(가) 만남 사건에서 고르는 중…';
      if (st.ph === 3) return mine ? (localCount() > 1 ? esc(who) + ' · ' : '') + '생존자를 골라요' : esc(pname(a)) + '이(가) 생존자를 고르는 중…';
      if (st.ph === 2) return mine ? '🌙 오늘 밤 일을 정해 주세요 (오늘의 대장)' : esc(pname(a)) + '이(가) 밤에 할 일을 정하는 중…';
      if (!mine) return '<span style="color:' + col(a) + '">' + esc(pname(a)) + '</span> ' + (st.ph === 0 ? '탐색 중…' : '캠프에서 만드는 중…') + (api.players[a] && api.players[a].ai ? ' 🤖' : '');
      const p = st.p[a];
      if (st.ph === 0) {
        if (sel >= 0) {
          if ((st.cl >> sel) & 1) return '오늘은 못 가는 곳이에요';
          if (!reach(st, sel)) return '너무 멀어요 — 길이 이어진 안개부터 탐험해요';
          if (!rvd(st, sel)) return '<b>안개 속</b> — 처음 가면 발견 +' + (2 + (has(p, P_EXPL) ? 1 : 0) + (dmAt(st, st.d) === 9 ? 1 : 0)) + '점! 한 번 더 탭하면 출발';
          const kind = kindAt(st, sel), y = gatherYield(st, a, sel), [hp] = hazardP(st, a, kind), tp = treasureP(st, a, kind), spP = subP(st, a, sel);
          const nm = KINDS[kind].n + (subOn(st, sel) ? '·' + KINDS[kind].sub.n : '');
          return '<b>' + nm + '</b> ' + yieldHtml(y) + (+st.ab[sel] ? '' : ' (바닥남)') + (tp ? ' · 보물 ' + Math.round(tp * 100) + '%' : '') + (spP ? ' · 숨은 곳 ' + Math.round(spP * 100) + '%' : '') + (hp ? ' · <span style="color:#ee6a55">위험 ' + Math.round(hp * 100) + '%</span>' : '');
        }
        return (localCount() > 1 ? esc(who) + ' · ' : '') + '갈 곳을 탭하세요 · 일손 <b>' + st.ap + '</b>' + (p.k ? ' (열병)' : '');
      }
      if (selR >= 0) { const R = RC[selR], why = canMake(st, a, selR), sg = sigAmt(st, a, selR); return '<b>' + R.ic + ' ' + R.n + '</b> ' + R.d + (sg ? ' (지금 +' + sg + ')' : '') + (why ? ' · <span style="color:#ee6a55">' + why + '</span>' : ' · 한 번 더 탭!'); }
      return (localCount() > 1 ? esc(who) + ' · ' : '') + '저녁: 만들 것을 고르세요 · 일손 <b>' + st.ap + '</b>' + (st.n > 1 ? ' · 주기 = 가장 필요한 사람에게' : '');
    }
    function slotRecipes(t, a) {   // one card per slot: upgrade replaces its base once the base is owned
      const p = st.p[a], out = [];
      RC.forEach((R, ri) => {
        if (R.tab !== t) return;
        if (R.up) return;
        const upI = RC.findIndex((u) => u.up === R.id);
        if (upI >= 0) { const baseOwn = R.bit ? p.t & R.bit : st.cb & R.cb; if (baseOwn) { out.push(upI); return; } }
        out.push(ri);
      });
      return out;
    }
    function render() {
      if (!st) return;
      renderChips(); renderBanner(); renderPop(); renderEv(); renderOv();
      bottom.innerHTML = '';
      const hint = h('div', { class: 'is-hint' }); hint.innerHTML = hintText();
      bottom.append(hint);
      const vs = viewSeat();
      if (st.ph !== 3 || st.p[vs].c >= 0) {
        const pk = h('button', { class: 'is-pack is-packrow', 'aria-label': '내 짐 자세히', onclick: (e) => { e.stopPropagation(); api.sfx('click'); popSeat = popSeat === vs ? -1 : vs; renderPop(); } });
        pk.innerHTML = resRow(vs); bottom.append(pk);
      }
      const a = actor(st), mine = a != null && api.canAct(a) && !st.end && !st.pe && (st.ph === 0 || st.ph === 1);
      if (mine && st.ph === 1) {
        const tabs = h('div', { class: 'is-tabs' });
        TABS.forEach(([ic, t], i) => tabs.append(h('button', { class: 'btn sm' + (tab === i ? ' on' : ''), text: ic + ' ' + t, onclick: () => { tab = i; selR = -1; api.sfx('click'); render(); } })));
        bottom.append(tabs);
        const grid = h('div', { class: 'is-grid' });
        const p = st.p[a];
        for (const ri of slotRecipes(tab, a)) {
          const R = RC[ri], why = canMake(st, a, ri), own = (R.bit && p.t & R.bit) || (R.cb && st.cb & R.cb), sg = R.sg ? sigAmt(st, a, ri) : 0;
          const c = h('button', { class: 'is-card' + (why ? ' off' : '') + (own ? ' own' : '') + (R.up ? ' up' : '') + (selR === ri ? ' sel' : ''), onclick: () => onCard(ri) });
          c.innerHTML = '<div class="t"><i>' + R.ic + '</i>' + R.n + '</div><div class="c">' + costHtml(costOf(st, a, ri), p.r) + (sg ? '<span style="color:#b5541c">📡+' + sg + '</span>' : '') + '</div>';
          grid.append(c);
        }
        bottom.append(grid);
      }
      if (mine) {
        const row = h('div', { class: 'is-row is-act' });
        const dis = !canInput();
        const p = st.p[a];
        if (st.ph === 0) {
          const rh = 1 + (has(p, P_REST2) ? 1 : 0) + (dmAt(st, st.d) === 8 ? 1 : 0);
          row.append(
            h('button', { class: 'btn sm ghost', text: p.k ? '😴 쉬기(열병 낫기)' : '😴 쉬기 ❤+' + rh, disabled: dis, onclick: () => { if (canInput()) send({ t: 'rest' }); } }),
            h('button', { class: 'btn sm ghost', text: '⏭ 그만', disabled: dis, onclick: () => { if (canInput()) send({ t: 'end' }); } }),
            h('button', { class: 'btn primary', text: sel >= 0 ? (rvd(st, sel) ? '여기로 가기' : '탐험하기') : '지도에서 고르기', disabled: dis || sel < 0 || ((st.cl >> sel) & 1) === 1 || !reach(st, sel), onclick: () => { if (canInput() && sel >= 0) go(sel); } }));
        } else {
          if (st.n > 1) {
            [[1, '🍖'], [0, '💧']].forEach(([ri, ic]) => {
              const to = giveTarget(st, a, ri);
              row.append(h('button', { class: 'btn sm ghost', text: ic + ' 주기', title: to >= 0 ? pname(to) + '에게 ' + RN[ri] + ' 1개' : '', 'aria-label': (to >= 0 ? pname(to) + '에게 ' : '') + RN[ri] + ' 나눠 주기', disabled: dis || p.r[ri] < 1 || to < 0, onclick: () => { if (canInput()) { api.sfx('pop'); send({ t: 'give', k: ri }); } } }));
            });
          }
          const ok = selR >= 0 && !canMake(st, a, selR);
          row.append(h('button', { class: 'btn sm ghost', text: '🌙 끝', 'aria-label': '저녁 끝내기', disabled: dis, onclick: () => { if (canInput()) send({ t: 'end' }); } }));
          row.append(h('button', { class: 'btn primary', text: '🔨 만들기', disabled: dis || !ok, onclick: () => { if (canInput() && ok) send({ t: 'mk', r: selR }); } }));
        }
        bottom.append(row);
      }
      requestAnimationFrame(layout);
    }
    function onCard(ri) {
      if (!canInput()) return;
      api.sfx('click');
      if (selR === ri && !canMake(st, actor(st), ri)) { send({ t: 'mk', r: ri }); return; }
      selR = ri; render();
    }
    function go(sl) {
      if ((st.cl >> sl) & 1) { api.toast('오늘은 못 가는 곳이에요 (지난밤 사건)'); return; }
      if (!reach(st, sl)) { api.toast('너무 멀어요! 길이 이어진 곳부터 가요'); return; }
      api.sfx('whoosh'); send({ t: 'go', sl });
    }

    /* ---------- event choice card ---------- */
    let evKey = '';
    function renderEv() {
      let e = -1, k = -1;
      if (st && !st.end && !nightView && !(anim && anim.k >= 0)) {
        if (st.pe) { e = st.pe[1]; k = st.pe[0]; }
        else if (st.ph === 2) { e = evAt(st, st.d - 1); k = st.cur; }
      }
      if (e < 0) { evCard.style.display = 'none'; evKey = ''; return; }
      const E = EVS[e], mine = api.canAct(k), key = e + ':' + k + ':' + st.seq + ':' + (mine ? 1 : 0) + ':' + (canInput() ? 1 : 0);
      evCard.style.display = 'flex';
      if (key === evKey) return;
      const fresh = evKey.split(':')[0] !== String(e);
      evKey = key;
      evCard.innerHTML = '';
      const art = h('canvas', { 'aria-hidden': 'true' });
      const bd = h('div', { class: 'bd' });
      const lead = st.ph === 2 ? ' · ' + esc(pname(k)) + '(오늘의 대장)이 정해요' : ' · ' + esc(pname(k));
      bd.innerHTML = '<div class="tt">' + E.ic + ' ' + E.n + '</div><div class="dd">' + E.d + '<span style="color:var(--muted)">' + lead + '</span></div>';
      const X = mkX(JSON.parse(JSON.stringify(st)), k, null);
      E.o.forEach((o, i) => {
        const why = optNeed(X, o);
        const b = h('button', { class: 'opt', disabled: !mine || !!why || !canInput(), onclick: () => { if (!canInput() || why) return; api.sfx('click'); send({ t: 'ch', o: i }); } });
        b.innerHTML = '<b>' + o.l + '</b><span>' + o.r + (why ? ' · <span class="no">' + why + '</span>' : '') + '</span>';
        bd.append(b);
      });
      if (!mine) bd.append(h('div', { class: 'wait', text: pname(k) + '이(가) 고르는 중…' + (api.players[k] && api.players[k].ai ? ' 🤖' : '') }));
      evCard.append(art, bd);
      requestAnimationFrame(() => { const w = evCard.clientWidth || 300; eventArt(art, e, w, Math.round(Math.min(96, Math.max(64, (LY ? LY.rect.h : 300) * 0.22)))); });
      if (fresh) { api.sfx(E.c === 4 ? 'win' : E.c === 1 || E.c === 3 ? 'thud' : 'card'); api.buzz(20); }
    }

    /* ---------- overlays: pick / summary / record ---------- */
    function recHtml() {
      const m = meta;
      let o = '<div class="is-rec"><div>판 수 <b>' + m.runs + '</b> · 구조 <b>' + m.wins + '</b>' + (m.bd ? ' · 가장 빠른 구조 <b>' + m.bd + '일째</b>' : '') + (m.bs ? ' · 최고 점수 <b>' + m.bs + '</b>' : '') + '</div>';
      if (m.hist.length) o += m.hist.slice(0, 6).map((r) => '<div>' + (r.w ? '🚢 ' + r.d + '일째 구조' : '💀 ' + (r.f === 1 ? r.d + '일째 쓰러짐' : '신호 부족')) + ' · ' + (CH[r.c] ? CH[r.c].ic + CH[r.c].n : '') + ' · ' + r.sc + '점 · ' + r.n + '명 · ' + ({ e: '느긋', m: '보통', h: '험난' }[r.df] || '') + '</div>').join('');
      else o += '<div class="muted">아직 기록이 없어요. 첫 항해를 시작해요!</div>';

      return o + '</div>';
    }
    function renderOv() {
      if (!st) return;
      let mode = '';
      const a = actor(st);
      if (recShow) mode = 'rec';
      else if (st.end && sumHold) mode = 'sum';
      else if (st.ph === 3 && !st.end && a != null && api.canAct(a) && !lastTut) mode = 'pick';
      if (mode !== ovMode || mode === 'pick') {
        ovMode = mode;
        ov.style.display = mode ? 'flex' : 'none';
        ov.innerHTML = '';
        if (mode === 'pick') buildPick(a);
        else if (mode === 'sum') buildSum();
        else if (mode === 'rec') {
          ov.append(h('h3', { text: '📜 내 무인도 기록' }), h('p', { class: 'sub', text: '이 기기에만 저장돼요.' }));
          const d = h('div'); d.innerHTML = recHtml(); ov.append(d);
          ov.append(h('button', { class: 'btn primary', text: '닫기', onclick: () => { recShow = false; api.sfx('click'); render(); } }));
        }
      }
    }
    function buildPick(k) {
      const opts = dealt(st, k).filter((c) => pickOk(st, k, c));
      if (pickC >= 0 && !pickOk(st, k, pickC)) pickC = -1;
      ov.append(h('h3', { text: (localCount() > 1 ? pname(k) + ' · ' : '') + '생존자를 고르세요' }),
        h('p', { class: 'sub', text: '각자 특성과 시작 짐이 달라요. 판마다 3명 중에서 골라요.' }));
      const list = h('div', { class: 'is-chs' });
      const card = (c, locked) => {
        const C = CH[c];
        const b = h('button', { class: 'is-ch' + (pickC === c ? ' sel' : '') + (c >= NBASE ? ' sm' : ''), disabled: !!locked || !canInput(), onclick: () => { if (!canInput()) return; api.sfx('tick'); if (pickC === c) confirmPick(); else { pickC = c; render(); } } });
        b.innerHTML = '<span class="i">' + (locked ? '🔒' : C.ic) + '</span><span class="tx"><b>' + C.n + '</b><span>' + (locked ? ACH[C.lock].d + ' 열려요' : C.d) + '</span>' + (locked ? '' : '<em>시작: ' + C.st + '</em>') + '</span>';
        return b;
      };
      opts.forEach((c) => list.append(card(c)));
      ov.append(list);
      ov.append(h('div', { class: 'is-lbl', text: '더 많은 생존자' }));
      const xg = h('div', { class: 'is-xg' });
      for (let c = NBASE; c < CH.length; c++) {
        const taken = st.p.some((q, j) => j !== k && q.c === c), open = chOpen(meta, c), C = CH[c];
        const b = h('button', { class: 'is-x' + (open ? '' : ' lk') + (pickC === c ? ' sel' : ''), disabled: taken || !canInput(), 'aria-label': C.n + (open ? '' : ' 잠김'),
          onclick: () => { if (!canInput()) return; api.sfx('tick'); if (!open) { api.toast('🔒 ' + C.n + ': ' + ACH[C.lock].d + ' 열려요'); return; } if (pickC === c) confirmPick(); else { pickC = c; render(); } } });
        b.innerHTML = '<i>' + (open ? C.ic : '🔒') + '</i>' + C.n;
        xg.append(b);
      }
      ov.append(xg);
      if (pickC >= NBASE) ov.append(h('p', { class: 'sub', text: CH[pickC].ic + ' ' + CH[pickC].n + ': ' + CH[pickC].d + ' · 시작: ' + CH[pickC].st }));
      ov.append(h('div', { class: 'is-lbl', text: '🎒 시작 짐' }));
      const kits = h('div', { class: 'is-kits' });
      KITN.forEach((nm, i) => {
        const open = kitOpen(meta, i), R = KITS[i] >= 0 ? RL[KITS[i]] : null;
        kits.append(h('button', { class: 'btn sm' + (pickKit === i ? ' on' : ''), disabled: !open || !canInput(), title: R ? R.d : '', text: (open ? '' : '🔒') + (R ? R.ic + ' ' : '🎒 ') + nm, onclick: () => { pickKit = i; api.sfx('click'); render(); } }));
      });
      ov.append(kits);
      const row = h('div', { class: 'is-row stick' });
      row.append(h('button', { class: 'btn sm ghost', text: '📜 기록', onclick: () => { recShow = true; api.sfx('click'); render(); } }),
        h('button', { class: 'btn primary', text: pickC >= 0 ? CH[pickC].ic + ' ' + CH[pickC].n + '(으)로 시작' : '생존자를 고르세요', disabled: pickC < 0 || !canInput(), onclick: confirmPick }));
      ov.append(row);
    }
    function confirmPick() {
      if (!canInput() || pickC < 0) return;
      const k = actor(st);
      if (!pickOk(st, k, pickC)) return;
      const kit = kitOpen(meta, pickKit) ? pickKit : 0;
      api.sfx('pop'); send({ t: 'pick', c: pickC, kit }); pickC = -1; pickKit = 0;
    }
    function buildSum() {
      const s = st, ok = s.end === 1;
      ov.append(h('h3', { text: ok ? '🚢 ' + s.rd + '일째 밤, 구조 성공!' : s.fr === 1 ? '💀 모두 쓰러졌어요' : '🌊 구조선이 오지 않았어요' }));
      ov.append(h('p', { class: 'sub', text: ok ? '함께 버텨 낸 ' + s.rd + '일의 기록이에요.' : s.fr === 2 ? '신호 ' + s.sg + '/' + s.G + ' — 조금만 더 모았으면!' : '섬은 쉽지 않았어요. 다음 섬에서 다시!' }));
      const mx = Math.max(1, ...s.dk, ...s.sv);
      const g1 = h('div', { class: 'is-sumg' });
      let any = 0;
      g1.innerHTML = '<b>😣 우리를 괴롭힌 것</b>' + s.dk.map((v, i) => (v ? (any = 1, '<div class="is-bar"><span>' + DK[i] + ' ❤−' + v + '</span><i style="width:' + Math.round(v / mx * 120) + 'px"></i></div>') : '')).join('') + (any ? '' : '<div class="muted">다친 사람이 거의 없었어요!</div>');
      const g2 = h('div', { class: 'is-sumg' });
      g2.innerHTML = '<b>🙌 우리를 살린 것</b>' + s.sv.map((v, i) => (v ? '<div class="is-bar g"><span>' + SV[i] + ' ×' + v + '</span><i style="width:' + Math.round(v / mx * 120) + 'px"></i></div>' : '')).join('');
      let found = 0, subs = 0; for (let sl = 1; sl < NS; sl++) { if (rvd(s, sl)) found++; if (subOn(s, sl)) subs++; }
      const g3 = h('div', { class: 'is-sumg' });
      g3.innerHTML = '<b>🗺 탐험</b><div>구역 ' + found + '/' + (NS - 1) + ' 발견 · 숨은 장소 ' + subs + '곳</div>' +
        s.p.map((p, k) => '<div><span style="color:' + col(k) + '">' + chIc(k) + ' ' + esc(pname(k)) + '</span> ' + total(p) + '점 ' + (relicIcons(p) || '') + (p.o ? ' 💤' : '') + '</div>').join('');
      ov.append(g1, g2, g3);
      if (unlockedNow.length) { const u = h('div', { class: 'is-sumg' }); u.innerHTML = '<b style="color:var(--brass)">🔓 새로 열렸어요!</b>' + unlockedNow.map((t) => '<div>' + t + '</div>').join(''); ov.append(u); }
      if (anyLocal) { const r = h('div', { class: 'is-sumg' }); r.innerHTML = '<b>📜 기록</b><div>판 수 ' + meta.runs + ' · 구조 ' + meta.wins + (meta.bd ? ' · 가장 빠른 구조 ' + meta.bd + '일째' : '') + (meta.bs ? ' · 최고 점수 ' + meta.bs : '') + '</div>'; ov.append(r); }
      ov.append(h('button', { class: 'btn primary', text: '결과 보기', onclick: () => { api.sfx('click'); releaseSum(); } }));
    }
    function releaseSum() { clearTimeout(sumTimer); sumHold = false; ovMode = ''; ov.style.display = 'none'; setBusy(false); render(); }
    function recordRun() {
      const key = st.sd + ':' + st.seq;
      if (recorded === key || !anyLocal) return;
      recorded = key;
      const before = meta.ach;
      let me = -1; for (let i = 0; i < st.n; i++) if (api.canAct(i)) { me = i; break; }
      if (me < 0) return;
      const p = st.p[me], win = st.end === 1;
      let subs = 0, rare = 0; for (let sl = 1; sl < NS; sl++) { if (subOn(st, sl)) subs++; if (rvd(st, sl) && KINDS[kindAt(st, sl)].rare) rare = 1; }
      meta.runs++; if (win) meta.wins++;
      meta.subs += subs;
      if (win && (!meta.bd || st.rd < meta.bd)) meta.bd = st.rd;
      meta.bs = Math.max(meta.bs, total(p));
      meta.hist.unshift({ w: win ? 1 : 0, d: win ? st.rd : st.d, f: st.fr, c: p.c, sc: total(p), n: st.n, df: st.df });
      meta.hist = meta.hist.slice(0, 8);
      if (win) meta.ach |= 1;
      if (st.p.some((q, i) => api.canAct(i) && relicN(q) >= 3)) meta.ach |= 2;
      if (win && st.df === 'h') meta.ach |= 4;
      if (win && st.rd <= 5) meta.ach |= 8;
      if (meta.runs >= 3) meta.ach |= 16;
      if (meta.subs >= 5) meta.ach |= 32;
      if (rare) meta.ach |= 64;
      unlockedNow = [];
      for (let i = 0; i < ACH.length; i++) if ((meta.ach >> i) & 1 && !((before >> i) & 1)) unlockedNow.push(i < 4 ? '새 생존자 ' + CH[NBASE + i].ic + ' ' + CH[NBASE + i].n : '시작 짐 「' + KITN[i - 3] + '」');
      metaSave(meta);
    }

    /* ---------- layout ---------- */
    function layout() {
      if (!st) return;
      const W = cv.w, H = cv.h, bh = bottom.offsetHeight || 120;
      const top = 116, sh = Math.max(80, H - top - bh - 2);
      const rect = { x: 6, y: top, w: W - 12, h: sh };
      const key = [W, H, rect.h, st.sd].join(',');
      if (!LY || LY.key !== key) {
        const G = geo(st.sd);
        let r = Math.max(20, Math.min(rect.w / 3 * 0.4, rect.h / 4 * 0.42, 54)), pos = null;
        for (let it = 0; it < 4; it++) {
          const padX = r * 1.1, padY = r * 1.05;
          pos = G.u.map((u, i) => ({ x: rect.x + padX + U.clamp((u * 3 - 0.5) / 2, -0.05, 1.05) * (rect.w - padX * 2), y: rect.y + padY + U.clamp((G.v[i] * 4 - 0.5) / 3, -0.02, 1.04) * (rect.h - padY * 2) }));
          let md = 1e9;
          for (let i = 0; i < NS; i++) for (let j = i + 1; j < NS; j++) md = Math.min(md, Math.hypot(pos[i].x - pos[j].x, pos[i].y - pos[j].y));
          const r2 = Math.max(18, Math.min(r, md / 2 - 3));
          if (Math.abs(r2 - r) < 0.5) break;
          r = r2;
        }
        for (const p of pos) { p.x = U.clamp(p.x, rect.x + r + 2, rect.x + rect.w - r - 2); p.y = U.clamp(p.y, rect.y + r + 2, rect.y + rect.h - r - 2); }
        LY = { key, rect, r, pos, E: G.E };
        statics = {};
      }
      Object.assign(spScene.style, { left: rect.x + 'px', top: rect.y + 'px', width: rect.w + 'px', height: rect.h + 'px' });
      const c0 = LY.pos[0];
      Object.assign(spCamp.style, { left: (c0.x - LY.r) + 'px', top: (c0.y - LY.r) + 'px', width: LY.r * 2 + 'px', height: LY.r * 2 + 'px' });
      const nw = Math.min(rect.w - 16, 340);
      Object.assign(nightCard.style, { left: (rect.x + (rect.w - nw) / 2) + 'px', width: nw + 'px', top: (rect.y + 6) + 'px', maxHeight: (rect.h - 10) + 'px' });
      const ew = Math.min(rect.w - 8, 360);
      Object.assign(evCard.style, { left: (rect.x + (rect.w - ew) / 2) + 'px', width: ew + 'px', top: (rect.y + 4) + 'px', maxHeight: (rect.h - 6) + 'px' });
      draw(performance.now());
    }
    cv.onresize = () => { LY = null; layout(); };

    /* ---------- static layers ---------- */
    function mapStatic() {
      const key = 'm' + st.rv + '.' + st.sf + st.m + LY.key;
      if (statics[key]) return statics[key];
      for (const k in statics) if (k[0] === 'm') delete statics[k];
      const { rect, r, pos, E } = LY, [c, x] = mkCanvas(cv.w, cv.h, cv.dpr), R = rng(st.sd);
      x.fillStyle = 'rgba(0,0,0,.4)'; rr(x, rect.x + 2, rect.y + 4, rect.w, rect.h, 16); x.fill();
      const sg = x.createLinearGradient(0, rect.y, 0, rect.y + rect.h); sg.addColorStop(0, '#1b7896'); sg.addColorStop(1, '#0f4c6a');
      x.fillStyle = sg; rr(x, rect.x, rect.y, rect.w, rect.h, 16); x.fill();
      x.save(); rr(x, rect.x, rect.y, rect.w, rect.h, 16); x.clip();
      x.strokeStyle = 'rgba(190,235,250,.13)'; x.lineWidth = 1.3;
      for (let k = 0; k < 30; k++) { const wx = rect.x + R() * rect.w, wy = rect.y + R() * rect.h, wl = r * (0.5 + R()); x.beginPath(); x.moveTo(wx, wy); x.quadraticCurveTo(wx + wl / 2, wy - 3, wx + wl, wy); x.stroke(); }
      const blob = (rad, fill) => {
        x.fillStyle = fill; x.beginPath();
        for (const p of pos) { x.moveTo(p.x + rad, p.y); x.arc(p.x, p.y, rad, 0, 7); }
        for (const [a, b] of E) { const A = pos[a], B = pos[b]; for (let t = 0.25; t < 0.8; t += 0.25) { const mx = A.x + (B.x - A.x) * t, my = A.y + (B.y - A.y) * t; x.moveTo(mx + rad * 0.85, my); x.arc(mx, my, rad * 0.85, 0, 7); } }
        x.fill();
      };
      blob(r * 1.75, 'rgba(120,215,220,.22)');
      blob(r * 1.45, '#e6d29a');
      blob(r * 1.25, '#d4bd80');
      x.save(); x.globalAlpha = 0.9; blob(r * 1.1, '#5d8f45'); x.restore();
      x.fillStyle = '#e6d29a'; x.beginPath(); x.ellipse(pos[0].x, pos[0].y + r * 0.35, r * 1.45, r * 0.9, 0, 0, 7); x.fill();
      x.fillStyle = 'rgba(0,0,0,.06)'; for (let k = 0; k < 140; k++) { const p = pos[k % NS]; x.beginPath(); x.arc(p.x + (R() - 0.5) * r * 2.6, p.y + (R() - 0.5) * r * 2.6, 0.7 + R(), 0, 7); x.fill(); }
      // trails between zones (only where one end is known)
      x.strokeStyle = 'rgba(110,80,40,.55)'; x.lineWidth = Math.max(2, r * 0.08); x.setLineDash([r * 0.12, r * 0.12]); x.lineCap = 'round';
      for (const [a, b] of E) { if (!rvd(st, a) && !rvd(st, b)) continue; const A = pos[a], B = pos[b]; x.beginPath(); x.moveTo(A.x, A.y); x.lineTo(B.x, B.y); x.stroke(); }
      x.setLineDash([]);
      for (let sl = 0; sl < NS; sl++) {
        const p = pos[sl];
        if (rvd(st, sl)) drawTile(x, kindAt(st, sl), p.x, p.y, r, st.sd + sl * 7);
      }
      x.restore();
      statics[key] = c;
      return c;
    }
    function campStatic(night) {
      const { rect } = LY, key = 'c' + (night ? 1 : 0) + LY.key;
      if (statics[key]) return statics[key];
      const [c, x] = mkCanvas(cv.w, cv.h, cv.dpr), W = rect.w, H = rect.h, X0 = rect.x, Y0 = rect.y, R = rng(st.sd + 3);
      x.fillStyle = 'rgba(0,0,0,.4)'; rr(x, X0 + 2, Y0 + 4, W, H, 16); x.fill();
      x.save(); rr(x, X0, Y0, W, H, 16); x.clip();
      const hz = Y0 + H * 0.5;
      const sky = x.createLinearGradient(0, Y0, 0, hz);
      if (night) { sky.addColorStop(0, '#0a0f26'); sky.addColorStop(1, '#1d2a52'); } else { sky.addColorStop(0, '#3b2f6b'); sky.addColorStop(0.55, '#d0607a'); sky.addColorStop(1, '#f6a65a'); }
      x.fillStyle = sky; x.fillRect(X0, Y0, W, hz - Y0);
      if (night) { x.fillStyle = '#fff'; for (let k = 0; k < 60; k++) { x.globalAlpha = 0.3 + R() * 0.7; x.fillRect(X0 + R() * W, Y0 + R() * (hz - Y0) * 0.95, 1.4, 1.4); } x.globalAlpha = 1;
        x.fillStyle = '#f4efd8'; x.beginPath(); x.arc(X0 + W * 0.82, Y0 + H * 0.14, H * 0.06, 0, 7); x.fill(); x.fillStyle = '#1d2a52'; x.beginPath(); x.arc(X0 + W * 0.82 + H * 0.025, Y0 + H * 0.13, H * 0.055, 0, 7); x.fill(); }
      else { const sg = x.createRadialGradient(X0 + W * 0.3, hz, 2, X0 + W * 0.3, hz, H * 0.2); sg.addColorStop(0, '#fff2b0'); sg.addColorStop(0.3, '#ffc768'); sg.addColorStop(1, 'rgba(255,170,90,0)'); x.fillStyle = sg; x.fillRect(X0, Y0, W, hz - Y0); x.fillStyle = '#ffe9a0'; x.beginPath(); x.arc(X0 + W * 0.3, hz, H * 0.07, Math.PI, 0); x.fill(); }
      const sea = x.createLinearGradient(0, hz, 0, Y0 + H * 0.68);
      if (night) { sea.addColorStop(0, '#16244a'); sea.addColorStop(1, '#0e1a36'); } else { sea.addColorStop(0, '#d47a6a'); sea.addColorStop(0.3, '#5a6a9a'); sea.addColorStop(1, '#2f5a7a'); }
      x.fillStyle = sea; x.fillRect(X0, hz, W, H * 0.2);
      x.strokeStyle = night ? 'rgba(180,200,255,.18)' : 'rgba(255,220,180,.35)'; x.lineWidth = 1.2;
      for (let k = 0; k < 14; k++) { const wx = X0 + R() * W, wy = hz + 3 + R() * H * 0.16; x.beginPath(); x.moveTo(wx, wy); x.lineTo(wx + 8 + R() * 18, wy); x.stroke(); }
      const sandY = Y0 + H * 0.66;
      x.fillStyle = night ? '#4a4258' : '#d9b77c';
      x.beginPath(); x.moveTo(X0, sandY + 4); x.quadraticCurveTo(X0 + W * 0.5, sandY - H * 0.05, X0 + W, sandY + 2); x.lineTo(X0 + W, Y0 + H); x.lineTo(X0, Y0 + H); x.closePath(); x.fill();
      x.strokeStyle = night ? 'rgba(200,210,255,.3)' : 'rgba(255,255,255,.55)'; x.lineWidth = 2; x.beginPath(); x.moveTo(X0, sandY + 4); x.quadraticCurveTo(X0 + W * 0.5, sandY - H * 0.05, X0 + W, sandY + 2); x.stroke();
      x.fillStyle = 'rgba(0,0,0,.07)'; for (let k = 0; k < 70; k++) { x.beginPath(); x.arc(X0 + R() * W, sandY + 6 + R() * (H * 0.34), 0.8 + R(), 0, 7); x.fill(); }
      palm(x, X0 + W * 0.06, Y0 + H * 0.78, H * 0.42, 0.5);
      palm(x, X0 + W * 0.96, Y0 + H * 0.8, H * 0.36, -0.6);
      x.restore();
      statics[key] = c;
      return c;
    }

    /* ---------- camp scene (evening / night) ---------- */
    function drawCamp(now, night) {
      const { rect } = LY, W = rect.w, H = rect.h, X0 = rect.x, Y0 = rect.y, nv = nightView, sv = nv ? nv.st : st;
      ctx.drawImage(campStatic(night), 0, 0, cv.w, cv.h);
      ctx.save(); rr(ctx, X0, Y0, W, H, 16); ctx.clip();
      if (shake > now) ctx.translate(Math.sin(now * 0.09) * 3, Math.cos(now * 0.07) * 2);
      const gy = Y0 + H * 0.84, s = Math.min(H * 0.22, W * 0.16);
      const tx = X0 + W * 0.8, th = s * (1.2 + 1.8 * Math.min(1, sv.sg / sv.G));
      ctx.strokeStyle = '#7a5530'; ctx.lineWidth = Math.max(2, s * 0.07);
      ctx.beginPath(); ctx.moveTo(tx - s * 0.35, gy); ctx.lineTo(tx, gy - th); ctx.lineTo(tx + s * 0.35, gy); ctx.stroke();
      for (let k = 1; k < 4; k++) { const yy = gy - th * k / 4, w2 = s * 0.35 * (1 - k / 4); ctx.beginPath(); ctx.moveTo(tx - w2, yy); ctx.lineTo(tx + w2, yy); ctx.stroke(); }
      ctx.fillStyle = '#e04848'; ctx.beginPath(); ctx.moveTo(tx, gy - th); ctx.lineTo(tx + s * 0.35, gy - th + s * 0.1 + Math.sin(now * 0.006) * 2); ctx.lineTo(tx, gy - th + s * 0.22); ctx.fill();
      if (sv.sg > 0) {
        if (sv.fi > 0) { const g = ctx.createRadialGradient(tx, gy - th, 1, tx, gy - th, s * 0.6); g.addColorStop(0, 'rgba(255,200,90,.55)'); g.addColorStop(1, 'rgba(255,150,60,0)'); ctx.fillStyle = g; ctx.fillRect(tx - s, gy - th - s, s * 2, s * 2); }
        ctx.fillStyle = 'rgba(220,220,230,.28)';
        for (let k = 0; k < 5; k++) { const ph = ((now * 0.0004 + k / 5) % 1); ctx.beginPath(); ctx.arc(tx + Math.sin(ph * 6 + k) * s * 0.2 + ph * s * 0.5, gy - th - ph * H * 0.35, s * (0.1 + ph * 0.25), 0, 7); ctx.fill(); }
      }
      if (sv.cb & CB_SOS) { ctx.fillStyle = night ? 'rgba(220,220,230,.5)' : '#8d8f96'; ctx.font = '700 ' + Math.round(s * (sv.cb & CB_BIGSOS ? 0.5 : 0.36)) + 'px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('SOS', X0 + W * 0.64, Y0 + H * 0.73); }
      if (sv.cb & CB_LOOK) { const lx = X0 + W * 0.93, ly = gy; ctx.strokeStyle = '#6b4a2a'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(lx - s * 0.2, ly); ctx.lineTo(lx - s * 0.08, ly - s * 1.5); ctx.moveTo(lx + s * 0.2, ly); ctx.lineTo(lx + s * 0.08, ly - s * 1.5); ctx.stroke(); ctx.fillStyle = '#8a5a30'; ctx.fillRect(lx - s * 0.2, ly - s * 1.6, s * 0.4, s * 0.12); }
      const hx = X0 + W * 0.22, lvl = sv.sh;
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(hx, gy + 2, s * 0.8, s * 0.14, 0, 0, 7); ctx.fill();
      if (lvl === 0) {
        ctx.strokeStyle = '#8a5a30'; ctx.lineWidth = Math.max(2, s * 0.06);
        ctx.beginPath(); ctx.moveTo(hx - s * 0.6, gy); ctx.lineTo(hx + s * 0.2, gy - s * 0.7); ctx.moveTo(hx - s * 0.2, gy); ctx.lineTo(hx + s * 0.4, gy - s * 0.55); ctx.stroke();
        ctx.fillStyle = '#4f8a3a'; ctx.beginPath(); ctx.moveTo(hx - s * 0.6, gy); ctx.lineTo(hx + s * 0.25, gy - s * 0.72); ctx.lineTo(hx + s * 0.35, gy - s * 0.6); ctx.lineTo(hx - s * 0.4, gy); ctx.fill();
      } else {
        const hw = s * (0.55 + lvl * 0.12), hh = s * (0.4 + lvl * 0.12);
        ctx.fillStyle = lvl >= 3 ? '#8a5a30' : '#a0703c'; ctx.fillRect(hx - hw, gy - hh, hw * 2, hh);
        ctx.strokeStyle = 'rgba(40,20,10,.5)'; ctx.lineWidth = 1; for (let k = 1; k < 5; k++) { ctx.beginPath(); ctx.moveTo(hx - hw + k * hw * 0.4, gy - hh); ctx.lineTo(hx - hw + k * hw * 0.4, gy); ctx.stroke(); }
        ctx.fillStyle = '#2a1a10'; ctx.beginPath(); ctx.moveTo(hx - hw * 0.25, gy); ctx.lineTo(hx - hw * 0.25, gy - hh * 0.65); ctx.quadraticCurveTo(hx, gy - hh * 0.85, hx + hw * 0.25, gy - hh * 0.65); ctx.lineTo(hx + hw * 0.25, gy); ctx.fill();
        if (night) { ctx.fillStyle = 'rgba(255,190,90,.35)'; ctx.fillRect(hx - hw * 0.22, gy - hh * 0.6, hw * 0.44, hh * 0.6); }
        ctx.fillStyle = lvl >= 2 ? '#c9a54a' : '#5f9a42';
        ctx.beginPath(); ctx.moveTo(hx - hw * 1.25, gy - hh + 2); ctx.lineTo(hx, gy - hh - s * (0.45 + lvl * 0.08)); ctx.lineTo(hx + hw * 1.25, gy - hh + 2); ctx.closePath(); ctx.fill();
      }
      if (sv.cb & CB_FENCE) { ctx.strokeStyle = '#7a5530'; ctx.lineWidth = Math.max(2, s * 0.05); for (let k = 0; k < 9; k++) { const fx2 = X0 + W * 0.03 + k * W * 0.035; ctx.beginPath(); ctx.moveTo(fx2, gy + s * 0.12); ctx.lineTo(fx2, gy - s * 0.32); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(X0 + W * 0.03, gy - s * 0.18); ctx.lineTo(X0 + W * 0.31, gy - s * 0.18); ctx.stroke(); }
      if (sv.cb & CB_RAIN) {
        const rx = hx + s * 0.95;
        ctx.fillStyle = '#6b4a2a'; ctx.fillRect(rx - s * 0.12, gy - s * 0.3, s * 0.24, s * 0.3);
        ctx.fillStyle = sv.cb & CB_CIST ? '#5a7aa0' : '#4f9a48'; ctx.beginPath(); ctx.moveTo(rx - s * 0.32, gy - s * 0.62); ctx.lineTo(rx + s * 0.32, gy - s * 0.62); ctx.lineTo(rx + s * 0.06, gy - s * 0.3); ctx.lineTo(rx - s * 0.06, gy - s * 0.3); ctx.fill();
      }
      if (sv.cb & CB_SMOK) { const mx = X0 + W * 0.38, my = gy; ctx.strokeStyle = '#5a3a1e'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(mx - s * 0.25, my); ctx.lineTo(mx - s * 0.25, my - s * 0.5); ctx.lineTo(mx + s * 0.25, my - s * 0.5); ctx.lineTo(mx + s * 0.25, my); ctx.stroke(); ctx.fillStyle = '#b0563a'; for (let k = 0; k < 3; k++) ctx.fillRect(mx - s * 0.18 + k * s * 0.14, my - s * 0.45, s * 0.08, s * 0.2); }
      if (sv.cb & CB_RAFT) {
        const fx = X0 + W * 0.62, fy = Y0 + H * 0.69;
        ctx.fillStyle = '#9a6a3a'; for (let k = 0; k < 5; k++) { rr(ctx, fx - s * 0.6 + k * s * 0.24, fy, s * 0.22, s * 0.16, 3); ctx.fill(); }
        ctx.strokeStyle = '#6b4320'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx, fy - s * 0.7); ctx.stroke();
        ctx.fillStyle = '#efe4c8'; ctx.beginPath(); ctx.moveTo(fx + 1, fy - s * 0.68); ctx.lineTo(fx + s * 0.38, fy - s * 0.3); ctx.lineTo(fx + 1, fy - s * 0.2); ctx.fill();
      }
      const fx = X0 + W * 0.5, fy = gy - s * 0.02;
      if (sv.fi > 0 || (nv && nv.lit)) {
        const glow = ctx.createRadialGradient(fx, fy - s * 0.2, 2, fx, fy - s * 0.2, s * (1.6 + sv.fi * 0.3));
        glow.addColorStop(0, 'rgba(255,170,70,' + (night ? 0.45 : 0.3) + ')'); glow.addColorStop(1, 'rgba(255,120,40,0)');
        ctx.fillStyle = glow; ctx.fillRect(fx - s * 3, fy - s * 3, s * 6, s * 4);
      }
      ctx.fillStyle = '#5a3a1e'; ctx.save(); ctx.translate(fx, fy); ctx.rotate(0.35); ctx.fillRect(-s * 0.4, -s * 0.05, s * 0.8, s * 0.1); ctx.rotate(-0.7); ctx.fillRect(-s * 0.4, -s * 0.05, s * 0.8, s * 0.1); ctx.restore();
      ctx.fillStyle = '#7d7a75'; for (let k = 0; k < 7; k++) { const a = Math.PI + k * Math.PI / 6; ctx.beginPath(); ctx.arc(fx + Math.cos(a) * s * 0.45, fy + 3 + Math.sin(a) * -s * 0.08, s * 0.07, 0, 7); ctx.fill(); }
      const fl = Math.max(sv.fi, nv && nv.lit ? 1 : 0);
      if (fl > 0) { flame(ctx, fx, fy, s * (0.35 + fl * 0.12), now, 0); flame(ctx, fx - s * 0.13, fy + 1, s * (0.22 + fl * 0.06), now, 2); flame(ctx, fx + s * 0.14, fy + 1, s * (0.2 + fl * 0.06), now, 4); }
      else { ctx.fillStyle = 'rgba(160,160,170,.35)'; ctx.beginPath(); ctx.arc(fx, fy - s * 0.3 - Math.sin(now * 0.002) * 3, s * 0.12, 0, 7); ctx.fill(); }
      const n = sv.p.length, ps = Math.max(14, s * 0.55);
      sv.p.forEach((p, k) => {
        const a = seatAng(k, n);
        const px = fx - Math.cos(a) * s * 1.15, py = fy + s * 0.15 + Math.sin(a) * s * 0.28;
        pawn(ctx, px, py, ps, col(k), { down: p.o, sick: p.k && !p.o, ring: !night && actor(st) === k && !st.end ? '#e3ae45' : null });
      });
      if (nv) nightFx(now);
      ctx.restore();
    }
    function walker(kind, xx, yy, s, now) {
      ctx.fillStyle = kind === 'crab' ? '#e0563a' : kind === 'turtle' ? '#3f7a4a' : kind === 'snake' ? '#3a6a2a' : kind === 'thief' ? '#141018' : '#2a1e18';
      if (kind === 'boar' || kind === 'dogs') { ctx.beginPath(); ctx.ellipse(xx, yy - s * 0.3, s * 0.5, s * 0.28, 0, 0, 7); ctx.fill(); ctx.beginPath(); ctx.moveTo(xx + s * 0.4, yy - s * 0.45); ctx.lineTo(xx + s * 0.75, yy - s * 0.25); ctx.lineTo(xx + s * 0.4, yy - s * 0.12); ctx.fill(); ctx.fillRect(xx - s * 0.35, yy - s * 0.1, s * 0.1, s * 0.2); ctx.fillRect(xx + s * 0.2, yy - s * 0.1, s * 0.1, s * 0.2); ctx.fillStyle = '#ffdc5a'; ctx.beginPath(); ctx.arc(xx + s * 0.55, yy - s * 0.35, 2.2, 0, 7); ctx.fill(); }
      else if (kind === 'monkey' || kind === 'thief') { ctx.beginPath(); ctx.arc(xx, yy - s * 0.4, s * 0.22, 0, 7); ctx.fill(); ctx.beginPath(); ctx.ellipse(xx, yy - s * 0.12, s * 0.2, s * 0.25, 0, 0, 7); ctx.fill(); if (kind === 'monkey') { ctx.strokeStyle = '#2a1e18'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(xx + s * 0.3, yy - s * 0.1, s * 0.25, -1, 1.5); ctx.stroke(); } ctx.fillStyle = '#cf6f34'; ctx.beginPath(); ctx.arc(xx - s * 0.25, yy - s * 0.2, s * 0.12, 0, 7); ctx.fill(); }
      else if (kind === 'snake') { ctx.strokeStyle = '#4a8a2a'; ctx.lineWidth = s * 0.1; ctx.lineCap = 'round'; ctx.beginPath(); for (let i = 0; i < 12; i++) ctx.lineTo(xx - i * s * 0.08, yy + Math.sin(i * 0.9 + now * 0.012) * s * 0.08); ctx.stroke(); }
      else if (kind === 'crab') { for (let k = 0; k < 5; k++) { const cx2 = xx - k * s * 0.3, cy2 = yy + (k % 2) * s * 0.15; ctx.beginPath(); ctx.ellipse(cx2, cy2, s * 0.13, s * 0.09, 0, 0, 7); ctx.fill(); ctx.fillRect(cx2 - s * 0.2, cy2 - s * 0.02, s * 0.4, s * 0.03); } }
      else { ctx.beginPath(); ctx.ellipse(xx, yy - s * 0.12, s * 0.35, s * 0.22, 0, Math.PI, 0); ctx.fill(); ctx.fillStyle = '#6aa05a'; ctx.beginPath(); ctx.arc(xx + s * 0.4, yy - s * 0.12, s * 0.1, 0, 7); ctx.fill(); }
    }
    function nightFx(now) {
      const { rect } = LY, W = rect.w, H = rect.h, X0 = rect.x, Y0 = rect.y;
      const e = nightView.e, t = ((now - fxStart) * sp()) / NIGHT_MS, s = Math.min(H * 0.22, W * 0.16);
      const gy = Y0 + H * 0.84, hz = Y0 + H * 0.5;
      ctx.save();
      if (nightView.r) {
        const sx = X0 + W * (1.1 - Math.min(1, t * 1.4) * 0.45), sy = hz + H * 0.06;
        ctx.fillStyle = 'rgba(255,250,200,.18)'; ctx.beginPath(); ctx.moveTo(sx - s * 0.3, sy - s * 0.3); ctx.lineTo(X0 + W * 0.45, gy); ctx.lineTo(X0 + W * 0.6, gy); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#e8e2d4'; ctx.beginPath(); ctx.moveTo(sx - s, sy); ctx.lineTo(sx + s, sy); ctx.lineTo(sx + s * 0.75, sy + s * 0.3); ctx.lineTo(sx - s * 0.8, sy + s * 0.3); ctx.fill();
        ctx.fillStyle = '#c0392b'; ctx.fillRect(sx - s * 0.3, sy - s * 0.4, s * 0.25, s * 0.4);
        ctx.fillStyle = '#ffe9a0'; for (let k = 0; k < 4; k++) ctx.fillRect(sx - s * 0.7 + k * s * 0.35, sy + s * 0.08, s * 0.1, s * 0.08);
        ctx.restore(); return;
      }
      const R = rng(e * 31 + 7), fx = nightView.wn ? 'calm' : FXK[e];
      switch (fx) {
        case 'storm': case 'rain': {
          ctx.strokeStyle = 'rgba(180,200,240,.5)'; ctx.lineWidth = 1.2;
          const nR = fx === 'storm' ? 70 : 45, sl = fx === 'storm' ? 0.45 : 0.15;
          for (let k = 0; k < nR; k++) { const xx = X0 + ((R() * W + now * 0.35 * (1 + sl)) % W), yy = Y0 + ((R() * H + now * 0.9) % H); ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx - sl * 14, yy + 14); ctx.stroke(); }
          if (fx === 'storm') { ctx.fillStyle = 'rgba(30,30,45,.55)'; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.ellipse(X0 + W * (0.1 + k * 0.22), Y0 + H * 0.08, W * 0.16, H * 0.07, 0, 0, 7); ctx.fill(); }
            if (Math.sin(now * 0.004) > 0.93) { ctx.fillStyle = 'rgba(230,235,255,.35)'; ctx.fillRect(X0, Y0, W, H); } }
          break;
        }
        case 'heat': { ctx.fillStyle = 'rgba(255,110,50,' + (0.14 + 0.05 * Math.sin(now * 0.004)) + ')'; ctx.fillRect(X0, Y0, W, H); ctx.strokeStyle = 'rgba(255,200,140,.35)'; ctx.lineWidth = 1.5; for (let k = 0; k < 6; k++) { ctx.beginPath(); for (let i = 0; i <= 20; i++) { const xx = X0 + W * (0.1 + k * 0.15), yy = Y0 + H * 0.2 + i * H * 0.03; ctx.lineTo(xx + Math.sin(i * 0.8 + now * 0.005 + k) * 4, yy); } ctx.stroke(); } break; }
        case 'fog': { for (let k = 0; k < 4; k++) { const yy = Y0 + H * (0.3 + k * 0.17), xx = X0 + ((now * 0.02 * (k + 1)) % (W * 1.6)) - W * 0.3; const g = ctx.createLinearGradient(xx - W * 0.6, 0, xx + W * 0.6, 0); g.addColorStop(0, 'rgba(220,225,235,0)'); g.addColorStop(0.5, 'rgba(220,225,235,.45)'); g.addColorStop(1, 'rgba(220,225,235,0)'); ctx.fillStyle = g; ctx.fillRect(X0, yy - H * 0.08, W, H * 0.16); } break; }
        case 'stars': case 'calm': case 'xmark': { ctx.fillStyle = '#fff'; for (let k = 0; k < 40; k++) { const tw = 0.5 + 0.5 * Math.sin(now * 0.006 + k * 1.7); ctx.globalAlpha = tw; ctx.fillRect(X0 + R() * W - 1, Y0 + R() * H * 0.45 - 1, 2.2, 2.2); } ctx.globalAlpha = 1;
          if (fx === 'calm') { const g = ctx.createRadialGradient(X0 + W * 0.82, Y0 + H * 0.14, 2, X0 + W * 0.82, Y0 + H * 0.14, H * 0.3); g.addColorStop(0, 'rgba(255,250,220,.5)'); g.addColorStop(1, 'rgba(255,250,220,0)'); ctx.fillStyle = g; ctx.fillRect(X0, Y0, W, H * 0.5); }
          if (fx === 'xmark') { const xx = X0 + W * 0.35, yy = gy - s * 0.1, a = 0.6 + 0.4 * Math.sin(now * 0.01); ctx.strokeStyle = 'rgba(255,210,90,' + a + ')'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(xx - 10, yy - 10); ctx.lineTo(xx + 10, yy + 10); ctx.moveTo(xx + 10, yy - 10); ctx.lineTo(xx - 10, yy + 10); ctx.stroke(); }
          break; }
        case 'boar': case 'monkey': case 'snake': case 'crab': case 'turtle': case 'dogs': case 'thief': {
          const dir = fx === 'monkey' || fx === 'thief' ? -1 : 1, xx = X0 + W * (dir < 0 ? 1 - t * 1.1 : t * 1.1 - 0.05), yy = gy + s * 0.25;
          walker(fx, xx, yy, s, now); if (fx === 'dogs') { walker('dogs', xx - s * 1.1, yy + s * 0.1, s * 0.8, now); walker('dogs', xx - s * 2, yy - s * 0.05, s * 0.75, now); }
          break;
        }
        case 'bugs': { ctx.fillStyle = 'rgba(30,30,30,.85)'; for (let k = 0; k < 40; k++) { const a = R() * 7, rd = s * (0.5 + R() * 1.4); ctx.fillRect(X0 + W * 0.5 + Math.cos(a + now * 0.003 * (k % 3 + 1)) * rd, gy - s * 0.5 + Math.sin(a * 1.3 + now * 0.004) * rd * 0.5, 2, 2); } break; }
        case 'shark': { const xx = X0 + W * (t * 1.2 - 0.1), yy = hz + H * 0.12; ctx.fillStyle = '#3a4a5a'; ctx.beginPath(); ctx.moveTo(xx - s * 0.25, yy); ctx.lineTo(xx + s * 0.05, yy - s * 0.4); ctx.lineTo(xx + s * 0.2, yy); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.beginPath(); ctx.moveTo(xx - s * 0.5, yy + 1); ctx.lineTo(xx + s * 0.3, yy + 1); ctx.stroke(); break; }
        case 'crate': { for (let k = 0; k < 3; k++) { const xx = X0 + W * (0.2 + k * 0.28), yy = hz + H * 0.08 + Math.min(1, t * 1.3) * H * 0.12 + Math.sin(now * 0.004 + k) * 2; ctx.fillStyle = '#9a6a3a'; ctx.fillRect(xx - s * 0.2, yy - s * 0.15, s * 0.4, s * 0.3); ctx.strokeStyle = '#5a3a1e'; ctx.lineWidth = 1.5; ctx.strokeRect(xx - s * 0.2, yy - s * 0.15, s * 0.4, s * 0.3); } break; }
        case 'ship': case 'ghost': { const xx = X0 + W * (0.05 + t * 0.9), yy = hz - 2; ctx.globalAlpha = fx === 'ghost' ? 0.45 + 0.2 * Math.sin(now * 0.005) : 1; ctx.fillStyle = fx === 'ghost' ? '#b8c8d8' : '#d8d4c8'; ctx.fillRect(xx - s * 0.5, yy - s * 0.12, s, s * 0.12); if (fx === 'ghost') { ctx.fillRect(xx - 1, yy - s * 0.6, 2, s * 0.5); ctx.beginPath(); ctx.moveTo(xx + 1, yy - s * 0.58); ctx.lineTo(xx + s * 0.3, yy - s * 0.3); ctx.lineTo(xx + 1, yy - s * 0.2); ctx.fill(); } else { ctx.fillStyle = '#ffe9a0'; for (let k = 0; k < 4; k++) ctx.fillRect(xx - s * 0.4 + k * s * 0.22, yy - s * 0.09, 3, 3); } ctx.globalAlpha = 1; if (fx === 'ship' && nightView.sg > 0) { ctx.fillStyle = 'rgba(255,240,170,.8)'; ctx.font = '700 ' + Math.round(s * 0.3) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.fillText('!', xx, yy - s * 0.3); } break; }
        case 'sick': { const k = nightView.sk >= 0 ? nightView.sk : (nightView.hit[0] != null ? nightView.hit[0] : -1); if (k >= 0) { const n = nightView.st.p.length, a = seatAng(k, n); const px = X0 + W * 0.5 - Math.cos(a) * s * 1.15, py = gy + s * 0.13 + Math.sin(a) * s * 0.28; ctx.fillStyle = 'rgba(255,90,70,' + (0.25 + 0.2 * Math.sin(now * 0.01)) + ')'; ctx.beginPath(); ctx.arc(px, py - s * 0.15, s * 0.55, 0, 7); ctx.fill(); } break; }
        case 'rocks': case 'quake': { ctx.fillStyle = fx === 'quake' ? 'rgba(90,80,80,.8)' : '#6f6b66'; for (let k = 0; k < (fx === 'quake' ? 30 : 6); k++) { const xx = X0 + W * (0.05 + R() * 0.9), yy = Y0 + ((t * 1.4 + R()) % 1) * H * 0.85; ctx.beginPath(); ctx.arc(xx, yy, fx === 'quake' ? 1.6 : s * (0.06 + R() * 0.06), 0, 7); ctx.fill(); } break; }
        case 'meteor': { const p = Math.min(1, t * 1.6), xx = X0 + W * (0.15 + p * 0.65), yy = Y0 + H * (0.08 + p * 0.22); const g = ctx.createLinearGradient(xx - W * 0.25, yy - H * 0.08, xx, yy); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(255,255,230,.95)'); ctx.strokeStyle = g; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(xx - W * 0.25, yy - H * 0.08); ctx.lineTo(xx, yy); ctx.stroke(); break; }
        case 'spark': case 'fly': { ctx.fillStyle = fx === 'spark' ? '#ffb03a' : '#e8ff8a'; for (let k = 0; k < 24; k++) { const ph = (R() + now * 0.0003 * (fx === 'spark' ? 2 : 0.6)) % 1, xx = X0 + W * (fx === 'spark' ? 0.5 + (R() - 0.5) * 0.3 : R()) + Math.sin(now * 0.003 + k) * 6, yy = fx === 'spark' ? gy - ph * H * 0.5 : Y0 + H * (0.3 + R() * 0.6) + Math.cos(now * 0.002 + k) * 5; ctx.globalAlpha = fx === 'spark' ? 1 - ph : 0.4 + 0.6 * Math.abs(Math.sin(now * 0.004 + k)); ctx.beginPath(); ctx.arc(xx, yy, 1.8, 0, 7); ctx.fill(); } ctx.globalAlpha = 1; break; }
        case 'wave': { const p = Math.sin(Math.min(1, t * 1.2) * Math.PI), yy = hz + H * 0.15 - p * H * 0.12; ctx.fillStyle = 'rgba(60,120,170,.75)'; ctx.beginPath(); ctx.moveTo(X0, Y0 + H); ctx.lineTo(X0, yy); for (let i = 0; i <= 20; i++) ctx.lineTo(X0 + i * W / 20, yy + Math.sin(i * 0.8 + now * 0.006) * 5); ctx.lineTo(X0 + W, hz + H * 0.2); ctx.lineTo(X0 + W, hz + H * 0.2); ctx.closePath(); ctx.globalAlpha = 0.6; ctx.fill(); ctx.globalAlpha = 1; break; }
        case 'light': case 'camps': { const n = fx === 'camps' ? 3 : 1; for (let k = 0; k < n; k++) { const xx = X0 + W * (0.25 + k * 0.22), yy = hz - H * 0.02, a = 0.5 + 0.5 * Math.sin(now * 0.008 + k * 2); const g = ctx.createRadialGradient(xx, yy, 1, xx, yy, s * 0.4); g.addColorStop(0, 'rgba(255,220,120,' + a + ')'); g.addColorStop(1, 'rgba(255,200,90,0)'); ctx.fillStyle = g; ctx.fillRect(xx - s * 0.4, yy - s * 0.4, s * 0.8, s * 0.8); } break; }
        case 'whale': { const xx = X0 + W * 0.3, yy = Y0 + H * 0.68; ctx.fillStyle = '#3a4a62'; ctx.beginPath(); ctx.ellipse(xx, yy, s * 0.9, s * 0.3, -0.05, 0, 7); ctx.fill(); ctx.beginPath(); ctx.moveTo(xx - s * 0.85, yy); ctx.lineTo(xx - s * 1.2, yy - s * 0.25); ctx.lineTo(xx - s * 1.15, yy + s * 0.2); ctx.fill(); ctx.fillStyle = 'rgba(200,230,255,.6)'; const ph = (now * 0.001) % 1; ctx.beginPath(); ctx.arc(xx + s * 0.4, yy - s * 0.4 - ph * s * 0.4, s * 0.06 + ph * 3, 0, 7); ctx.fill(); break; }
        case 'dark': { ctx.fillStyle = 'rgba(0,0,10,.45)'; ctx.fillRect(X0, Y0, W, H); break; }
      }
      ctx.restore();
    }

    /* ---------- map scene (day) ---------- */
    function weatherFx(now) {
      const { rect } = LY, wx = wxAt(st, st.d), R = rng(7);
      ctx.save(); rr(ctx, rect.x, rect.y, rect.w, rect.h, 16); ctx.clip();
      if (wx === 2) { ctx.strokeStyle = 'rgba(200,220,255,.35)'; ctx.lineWidth = 1; for (let k = 0; k < 40; k++) { const xx = rect.x + ((R() * rect.w + now * 0.1) % rect.w), yy = rect.y + ((R() * rect.h + now * 0.45) % rect.h); ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx - 3, yy + 9); ctx.stroke(); } ctx.fillStyle = 'rgba(30,40,70,.12)'; ctx.fillRect(rect.x, rect.y, rect.w, rect.h); }
      else if (wx === 5) { for (let k = 0; k < 3; k++) { const yy = rect.y + rect.h * (0.2 + k * 0.3), xx = rect.x + ((now * 0.012 * (k + 1)) % (rect.w * 1.6)) - rect.w * 0.3; const g = ctx.createLinearGradient(xx - rect.w * 0.5, 0, xx + rect.w * 0.5, 0); g.addColorStop(0, 'rgba(230,235,240,0)'); g.addColorStop(0.5, 'rgba(230,235,240,.22)'); g.addColorStop(1, 'rgba(230,235,240,0)'); ctx.fillStyle = g; ctx.fillRect(rect.x, yy - rect.h * 0.1, rect.w, rect.h * 0.2); } }
      else if (wx === 3) { ctx.fillStyle = 'rgba(255,150,60,' + (0.07 + 0.03 * Math.sin(now * 0.003)) + ')'; ctx.fillRect(rect.x, rect.y, rect.w, rect.h); }
      else if (wx === 4) { ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.lineWidth = 1.2; for (let k = 0; k < 9; k++) { const yy = rect.y + R() * rect.h, xx = rect.x + ((R() * rect.w + now * 0.5) % (rect.w + 60)) - 30; ctx.beginPath(); ctx.moveTo(xx, yy); ctx.quadraticCurveTo(xx + 15, yy - 4, xx + 34, yy); ctx.stroke(); } }
      else if (wx === 0) { const g = ctx.createRadialGradient(rect.x + rect.w * 0.9, rect.y, 4, rect.x + rect.w * 0.9, rect.y, rect.h * 0.5); g.addColorStop(0, 'rgba(255,240,180,.22)'); g.addColorStop(1, 'rgba(255,240,180,0)'); ctx.fillStyle = g; ctx.fillRect(rect.x, rect.y, rect.w, rect.h); }
      const dt = (now - dawnT) * sp();
      if (dt < 1400) {   // dawn: night lifts from the island
        const e = dt / 1400, g = ctx.createLinearGradient(0, rect.y, 0, rect.y + rect.h);
        g.addColorStop(0, 'rgba(10,15,38,' + (0.85 * (1 - e)) + ')'); g.addColorStop(1, 'rgba(255,170,90,' + (0.4 * (1 - e)) + ')');
        ctx.fillStyle = g; ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
      }
      ctx.restore();
    }
    function drawMap(now) {
      const { r, pos } = LY;
      ctx.drawImage(mapStatic(), 0, 0, cv.w, cv.h);
      const a = actor(st), mine = a != null && api.canAct(a) && !st.end && st.ph === 0 && !st.pe;
      for (let sl = 0; sl < NS; sl++) {
        const p = pos[sl], rv = rvd(st, sl), op = reach(st, sl);
        if (!rv) fog(ctx, p.x, p.y, r, now, op);
        if (sl === 0) flame(ctx, p.x - r * 0.42, p.y + r * 0.12, r * (0.16 + st.fi * 0.04), now, 1);
        if (!rv && !op) continue;
        const kind = kindAt(st, sl), nm = rv ? KINDS[kind].n : '안개';
        ctx.font = '700 ' + Math.max(10, Math.round(r * 0.26)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const tw = ctx.measureText(nm).width + (rv ? 22 : 12), ly = p.y + r * 0.7;
        ctx.fillStyle = 'rgba(20,16,28,.8)'; rr(ctx, p.x - tw / 2, ly - 8, tw, 16, 8); ctx.fill();
        ctx.fillStyle = rv && KINDS[kind].rare ? '#f2c14e' : '#f2e9d8'; ctx.fillText(nm, p.x - (rv ? 5 : 0), ly + 0.5);
        if (rv) { const ab = +st.ab[sl]; for (let i = 0; i < ABX; i++) { ctx.fillStyle = i < ab ? '#7fd88a' : 'rgba(255,255,255,.2)'; ctx.beginPath(); ctx.arc(p.x + tw / 2 - 12 + i * 5, ly + 0.5, 2.2, 0, 7); ctx.fill(); } }
        if (rv && subOn(st, sl)) { const bx = p.x + r * 0.7, by = p.y - r * 0.7, pulse = 1 + 0.08 * Math.sin(now * 0.005 + sl); ctx.fillStyle = '#2a1f18'; ctx.beginPath(); ctx.arc(bx, by, r * 0.24 * pulse, 0, 7); ctx.fill(); ctx.fillStyle = '#f2c14e'; ctx.font = '700 ' + Math.round(r * 0.3) + 'px ' + FONT; ctx.fillText('★', bx, by + 1); }
        if ((st.cl >> sl) & 1) {
          ctx.fillStyle = 'rgba(20,10,10,.5)'; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
          ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(p.x, p.y, r * 0.55, 0, 7); ctx.moveTo(p.x - r * 0.39, p.y - r * 0.39); ctx.lineTo(p.x + r * 0.39, p.y + r * 0.39); ctx.stroke();
        }
        if (mine && sl === sel) {
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3.5; ctx.setLineDash([7, 5]); ctx.lineDashOffset = -now * 0.02;
          ctx.beginPath(); ctx.arc(p.x, p.y, r + 4, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        }
      }
      const groups = {};
      st.p.forEach((p, k) => { if (p.o || p.c < 0) return; const sl = anim && anim.k === k ? -1 : p.l; if (sl < 0) return; (groups[sl] = groups[sl] || []).push(k); });
      const ps = Math.max(14, r * 0.52);
      for (const sl in groups) {
        const g = groups[sl], p = pos[sl];
        g.forEach((k, i) => {
          const ox = (i - (g.length - 1) / 2) * ps * 0.7, oy = sl === '0' ? r * 0.02 : r * 0.05;
          pawn(ctx, p.x + ox + (sl === '0' ? r * 0.2 : 0), p.y + oy, ps, col(k), { sick: st.p[k].k, ring: a === k ? '#e3ae45' : null });
        });
      }
      if (anim && anim.k >= 0) {
        const e = Math.min(1, (now - anim.t0) * sp() / anim.dur);
        const A = pos[anim.from], B = pos[anim.to], q = e < 0.5 ? 2 * e * e : 1 - Math.pow(-2 * e + 2, 2) / 2;
        const px = A.x + (B.x - A.x) * q, py = A.y + (B.y - A.y) * q - Math.sin(e * Math.PI) * r * 0.6 + r * 0.05;
        pawn(ctx, px, py, ps, col(anim.k), { ring: '#e3ae45' });
      }
      weatherFx(now);
    }

    function drawFloats(now) {
      floats = floats.filter((f) => (now - f.t0) * sp() < 1300);
      const md = campMode() ? 1 : 0;
      for (const f of floats) {
        const e = ((now - f.t0) * sp()) / 1300; if (e < 0 || f.mode !== md) continue;
        ctx.globalAlpha = Math.min(1, (1 - e) * 2);
        const y = f.y - e * 38;
        ctx.font = '800 ' + f.sz + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const tw = ctx.measureText(f.txt).width + (f.ri >= 0 ? f.sz + 2 : 0);
        ctx.fillStyle = 'rgba(15,12,20,.7)'; rr(ctx, f.x - tw / 2 - 6, y - f.sz * 0.7, tw + 12, f.sz * 1.4, f.sz * 0.7); ctx.fill();
        let x0 = f.x - tw / 2;
        if (f.ri >= 0) { drawRI(ctx, f.ri, x0 + f.sz / 2, y, f.sz); x0 += f.sz + 2; }
        ctx.fillStyle = f.c || '#fff'; ctx.textAlign = 'left'; ctx.fillText(f.txt, x0, y + 1);
        ctx.globalAlpha = 1;
      }
    }
    function campMode() {
      if (nightView) return true;
      if (anim && anim.k >= 0 && !anim.night) return false;
      return st.ph === 1 || st.ph === 2 || !!st.end;
    }
    function draw(now) {
      if (!st || !LY) return;
      cv.clear();
      if (campMode()) drawCamp(now, !!nightView || !!st.end || st.ph === 2);
      else drawMap(now);
      drawFloats(now);
    }

    /* ---------- night report ---------- */
    function nightHtml(info, sv) {
      const d = info.d;
      if (info.r) return '<div class="ic">🚢</div><div class="tt">' + d + '일째 밤 · 구조선 도착!</div><div class="dd">' + (info.r === 2 ? EVS[info.e].ic + ' ' + EVS[info.e].n + '까지 버텨 신호가 다 찼어요! ' : '') + '불빛과 연기를 보고 배가 왔어요. 모두 구조!</div>';
      const E = EVS[info.e];
      let fx = '';
      const nm = (k) => '<b style="color:' + col(k) + '">' + esc(pname(k)) + '</b>';
      sv.p.forEach((p, k) => {
        const ev = deltaHtml(info.E && info.E[k]), up = deltaHtml(info.U && info.U[k]), mo = deltaHtml(info.M && info.M[k]);
        const extra = (info.sk === k ? ' 🤒열병' : '') + (info.fo.indexOf(k) >= 0 ? ' 💤쓰러짐' : '') + (info.lk.indexOf(k) >= 0 ? ' 🍀클로버로 버팀' : '');
        if (!ev && !up && !extra && !mo) return;
        fx += '<div>' + nm(k) + ' ' + (ev ? ev + ' · ' : '') + (up ? '밤사이 ' + up : '') + extra + (mo ? ' · 아침 ' + mo : '') + '</div>';
      });
      const camp = [];
      if (info.wn) camp.push('🐾 미리 알린 덕에 무사!');
      if (info.ch >= 0 && E.o && info.o >= 0) camp.push(esc(pname(info.ch)) + ': 「' + E.o[info.o].l + '」' + (info.ok === 1 ? ' 성공!' : info.ok === 0 ? ' 실패…' : ''));
      if (info.rl >= 0) camp.push('유물 ' + RL[info.rl].ic + ' ' + RL[info.rl].n + '!');
      if (info.sg) camp.push('신호 ' + (info.sg > 0 ? '+' : '−') + Math.abs(info.sg));
      if (info.sh) camp.push('움막 ' + (info.sh > 0 ? '+' : '−') + Math.abs(info.sh));
      camp.push(info.lit ? (info.lp ? '🕯 등잔 덕에 불이 그대로' : '🔥 불이 밤새 탔어요') : '🔥 불이 꺼져 추웠어요');
      if (info.cl) camp.push('내일 못 가는 곳 있음');
      let mo = '';
      if (!sv.end) { const W = WX[wxAt(sv, sv.d)], M = DM[dmAt(sv, sv.d)]; mo = '<div class="mo">☀ ' + sv.d + '일째 아침 · ' + W.ic + ' ' + W.n + (dmAt(sv, sv.d) ? ' · ' + M.ic + ' ' + M.n : '') + (sv.d === COLD_D ? ' · 🥶 오늘부터 밤엔 불이 2씩 타요' : '') + '</div>'; }
      return '<div class="ic">' + E.ic + '</div><div class="tt">' + d + '일째 밤 · ' + E.n + '</div><div class="dd">' + E.d + '</div>' +
        '<div class="dd" style="color:#f2c14e">' + camp.join(' · ') + '</div><div class="fx">' + fx + '</div>' + mo +
        (sv.end === 2 ? '<div class="dd" style="color:#ee6a55">' + (sv.fr === 1 ? '모두 쓰러졌어요…' : '7일째 밤이 지났어요. 구조 신호가 모자라요…') + '</div>' : '');
    }
    function showNight(info, ms, again) {
      nightCard.innerHTML = nightHtml(info.info, info.st);
      nightCard.style.display = 'flex';
      clearTimeout(nightHide);
      if (again) nightHide = setTimeout(hideNight, ms);
    }
    function hideNight() { clearTimeout(nightHide); nightCard.style.display = 'none'; if (anim && anim.night) finishAnim(); }

    /* ---------- animation ---------- */
    function relicToast(who, id) { if (id >= 0) { api.toast(who + ': 유물 ' + RL[id].ic + ' ' + RL[id].n + '! — ' + RL[id].d); api.sfx('win'); api.buzz(30); } }
    function startAnim(next, prev) {
      const lm = next.last, now = performance.now();
      if (!lm) return;
      if (anim || nightView) {   // a new move arrived while an older animation still plays (online): close it first
        clearTimeout(safety);
        if (anim && anim.night) { nightView = null; nightCard.style.display = 'none'; dawnT = now; }
        anim = null;
      }
      const who = callName(lm.s);
      if (lm.k === 'p') {
        api.sfx('pop'); api.toast(who + ': ' + CH[lm.c].ic + ' ' + CH[lm.c].n + '(으)로 시작! ' + (lm.kit ? '· ' + KITN[lm.kit] : ''));
        if (next.ph === 0 && prev && prev.ph === 3) dawnT = now;
      } else if (lm.k === 'g') {
        const from = prev && prev.p[lm.s] ? prev.p[lm.s].l : 0;
        anim = { k: lm.s, from, to: lm.sl, t0: now, dur: 420, night: false };
        const P = LY.pos[lm.sl], items = [];
        if (lm.g) for (let i = 0; i < 4; i++) if (lm.g[i + 1] > 0) items.push(['+' + lm.g[i + 1], i, RCOL[i]]);
        const xs = items.length, gap = 50;
        items.forEach((it, j) => floats.push({ x: P.x + (j - (xs - 1) / 2) * gap, y: P.y - LY.r * 0.15, t0: now + (400 + j * 120) / sp(), txt: it[0], ri: it[1], c: it[2], sz: 14, mode: 0 }));
        let dl = 400 + xs * 120, dy = 22;
        const add = (txt, c) => { floats.push({ x: P.x, y: P.y - LY.r * 0.15 - dy, t0: now + dl / sp(), txt, ri: -1, c, sz: 13, mode: 0 }); dl += 160; dy += 20; };
        const kind = kindAt(next, lm.sl);
        if (lm.fd) add('발견!', '#f2c14e');
        if (lm.sb) add('★ ' + KINDS[kind].sub.n, '#f2c14e');
        if (lm.tr) add(KINDS[kind].trn + ' +2점', '#e3ae45');
        if (lm.rl >= 0) add(RL[lm.rl].ic + ' 유물!', '#f2c14e');
        if (lm.hz) add(lm.hz === 3 ? '🤒 열병' : '❤ −1', '#ee6a55');
        api.sfx('whoosh');
        setTimeout(() => {
          if (!st) return;
          const kn = KINDS[kind].n;
          api.sfx(lm.fd || lm.tr || lm.sb ? 'win' : 'pop'); api.buzz(12);
          if (lm.sb) api.toast(who + ': 숨은 장소 「' + KINDS[kind].sub.n + '」 발견! +2점 ★');
          else if (lm.fd) api.toast(who + ': ' + kn + ' 발견!' + (KINDS[kind].rare ? ' (희귀 구역)' : '') + (lm.sg ? ' 신호 +1' : ''));
          else if (lm.tr) api.toast(who + ': ' + KINDS[kind].trn + '을(를) 찾았어요! +2점 ✨');
          if (lm.rl >= 0) relicToast(who, lm.rl);
          if (lm.hz) { api.sfx('hit'); api.toast(who + ': ' + (lm.hz === 1 ? '미끄러졌어요! ❤−1' : lm.hz === 2 ? '앗 뜨거! 화상 ❤−1' : '흙탕물 때문에 열병에 걸렸어요 🤒')); }
        }, 380 / sp());
      } else if (lm.k === 'c') {
        const E = EVS[lm.e], o = E.o[lm.o];
        if (!lm.nt) {
          api.sfx(lm.ok === 0 ? 'hit' : lm.ok === 1 || lm.rl >= 0 ? 'win' : 'pop'); api.buzz(lm.ok === 0 ? 40 : 15);
          const g = lm.g ? [lm.g[0] ? '❤' + (lm.g[0] > 0 ? '+' : '') + lm.g[0] : '', ...[0, 1, 2, 3].map((i) => (lm.g[i + 1] ? RN[i] + (lm.g[i + 1] > 0 ? '+' : '') + lm.g[i + 1] : ''))].filter(Boolean).join(' ') : '';
          api.toast(who + ': 「' + o.l + '」' + (lm.ok === 1 ? ' 성공!' : lm.ok === 0 ? ' 실패…' : '') + (g ? ' ' + g : '') + (lm.pt ? ' +' + lm.pt + '점' : '') + (lm.cm[0] ? ' 신호' + (lm.cm[0] > 0 ? '+' : '') + lm.cm[0] : ''));
          if (lm.rl >= 0) setTimeout(() => relicToast(who, lm.rl), 500 / sp());
          if (prev && evAt(prev, prev.d - 1) !== evAt(next, next.d - 1)) setTimeout(() => api.toast('🌙 오늘 밤 사건이 바뀌었어요: ' + EVS[evAt(next, next.d - 1)].ic + ' ' + EVS[evAt(next, next.d - 1)].n), 900 / sp());
        }
      } else if (lm.k === 'm') {
        const R = RC[lm.r];
        api.sfx(R.sg ? 'win' : 'chip'); api.buzz(14);
        api.toast(who + ': ' + R.ic + ' ' + R.n + (lm.sg ? ' · 신호 +' + lm.sg : R.bit ? ' 완성' : '') + (R.pts ? ' (+' + R.pts + '점)' : '') + (lm.xr ? ' · 안개 1곳이 걷혔어요' : ''));
        const P = { x: LY.rect.x + LY.rect.w * (R.sg ? 0.8 : R.tab === 0 && R.id !== 'fire' ? 0.22 : 0.5), y: LY.rect.y + LY.rect.h * 0.55 };
        floats.push({ x: P.x, y: P.y, t0: now, txt: R.ic + ' ' + R.n, ri: -1, c: '#f2c14e', sz: 13, mode: 1 });
      } else if (lm.k === 'v') {
        api.sfx('pop'); api.toast(who + ' → ' + pname(lm.to) + ': ' + (lm.ri ? '음식' : '물') + ' 1개 나눔 🤝' + (lm.pt ? ' (+1점)' : ''));
      } else if (lm.k === 'r') {
        api.sfx('pop'); api.toast(who + ': 쉬기' + (lm.cu ? ' · 열병이 나았어요' : lm.dh ? ' ❤+' + lm.dh : ''));
      }
      if (lm.n) {
        const dl = lm.k === 'g' ? 600 : 350;
        const sv = next;
        nightView = { d: lm.n.d, e: lm.n.e, r: lm.n.r, lit: lm.n.lit, sk: lm.n.sk, hit: lm.n.hit, sg: lm.n.sg, wn: lm.n.wn, st: prev || next };
        lastNight = { info: lm.n, st: sv };
        fxStart = now + dl / sp();
        anim = anim || { k: -1, t0: now, dur: 0 };
        anim.night = true;
        setTimeout(() => {
          if (!st || !nightView) return;
          fxStart = performance.now();
          nightView.st = sv;
          showNight(lastNight, 0, false);
          const e = lm.n.e;
          if (lm.n.r) { api.sfx('win'); api.buzz(40); }
          else {
            const c = EVS[e].c;
            api.sfx(c === 4 ? 'pop' : c === 0 || c === 3 ? 'thud' : 'whoosh');
            if (e === 30) shake = performance.now() + 900 / sp();
            if (lm.n.rl >= 0) setTimeout(() => relicToast(pname(lm.n.ch >= 0 ? lm.n.ch : 0), lm.n.rl), 600 / sp());
            if (lm.n.fo.length) { api.sfx('lose'); api.buzz(60); }
          }
          render();
        }, dl / sp());
        clearTimeout(safety);
        safety = setTimeout(finishAnim, (dl + NIGHT_MS + 2500) / sp());
        anim.endAt = now + (dl + NIGHT_MS) / sp();
        setBusy(true);
        render();
        return;
      }
      if (anim) { anim.endAt = now + (anim.dur + 120) / sp(); setBusy(true); clearTimeout(safety); safety = setTimeout(finishAnim, (anim.dur + 2000) / sp()); }
    }
    function finishAnim() {
      clearTimeout(safety);
      const wasNight = anim && anim.night;
      anim = null;
      if (wasNight) {
        nightView = null; nightCard.style.display = 'none';
        if (st && !st.end) { api.sfx('tick'); dawnT = performance.now(); api.toast('☀ ' + st.d + '일째 아침 · ' + WX[wxAt(st, st.d)].ic + ' ' + WX[wxAt(st, st.d)].n + (dmAt(st, st.d) ? ' · ' + DM[dmAt(st, st.d)].ic + ' ' + DM[dmAt(st, st.d)].n : '')); }
      }
      if (st && st.end && !sumHold && sumShown !== st.sd + ':' + st.seq) { sumShown = st.sd + ':' + st.seq; recordRun(); sumHold = true; setBusy(true); clearTimeout(sumTimer); sumTimer = setTimeout(releaseSum, (anyLocal ? 25000 : 6000) / sp()); render(); return; }
      setBusy(false);
      render();
    }
    stopLoop = U.loop((dt, now) => {
      frame++;
      if (frame % 20 === 0) { const t = !!(root.parentNode && (root.closest ? (root.closest('.stage') || root.parentNode) : root.parentNode).querySelector('.tut-layer')); if (t !== lastTut) { lastTut = t; render(); } }
      if (anim && anim.endAt && now >= anim.endAt) finishAnim();
      const active = anim || floats.length || nightView || (now - dawnT) * sp() < 1500 || shake > now;
      if (!active && frame % 3) return;
      draw(now);
    });

    /* ---------- input ---------- */
    function onDown(ev) {
      if (popSeat !== -1) { popSeat = -1; renderPop(); }
      if (!st || !LY || st.ph !== 0 || st.pe || nightView || !canInput()) return;
      const p = cv.local(ev);
      let best = -1, bd = 1e9;
      LY.pos.forEach((q, i) => { const d = Math.hypot(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; best = i; } });
      if (best < 0 || bd > LY.r * 1.35) { if (sel >= 0) { sel = -1; render(); } return; }
      if ((st.cl >> best) & 1 || !reach(st, best)) { sel = best; render(); go(best); return; }
      if (sel === best) { go(best); return; }
      sel = best; api.sfx('tick'); render();
    }
    cv.cv.addEventListener('pointerdown', onDown);

    return {
      update(next, prev) {
        const first = !st;
        const fresh = prev && prev !== next && next.seq !== shownSeq && next.last && next.last.id === next.seq;
        const old = st;
        st = next;
        if (first) { requestAnimationFrame(layout); if (st.ph === 0) dawnT = performance.now(); }
        if (!LY || (old && old.sd !== next.sd)) { LY = null; layout(); }
        if (old && old.sd !== next.sd) { lastNight = null; nightView = null; anim = null; sumHold = false; recorded = ''; sumShown = ''; unlockedNow = []; meta = metaLoad(); }
        if (old && (old.ph !== next.ph || old.cur !== next.cur || old.d !== next.d || !!old.pe !== !!next.pe)) { sel = -1; selR = -1; tab = 0; }
        if (fresh) startAnim(next, prev);
        else if (next.end && !anim && !sumHold && sumShown !== next.sd + ':' + next.seq) finishAnim();
        shownSeq = next.seq;
        render();
      },
      destroy() {
        if (stopLoop) stopLoop(); stopLoop = null;
        clearTimeout(safety); clearTimeout(nightHide); clearTimeout(sumTimer); setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.destroy(); ui.remove(); style.remove();
      },
    };
  }

  /* ---------- 도감 (codex): generated from CH / KINDS / EVS / RL / RC / WX / DM ---------- */
  function islCodex() {
    const resTxt = (a, sep) => a.map((v, i) => (v ? RN[i] + ' ' + (sep || '') + v : '')).filter(Boolean).join(' · ');
    const pctx = (v) => Math.round(v * 100) + '%';
    const toolNm = (bit) => { const r = RC.find((x) => x.bit === bit); return r ? r.n : ''; };
    const startTxt = (C) => {
      const r = [2, 2, 1, 1].map((v, i) => v + ((C.r && C.r[i]) || 0));
      return '시작 짐: ' + resTxt(r) + (C.t ? ' · ' + toolNm(C.t) : '');
    };
    const ch = CH.map((C, i) => ({ icon: C.ic, name: C.n, tag: '❤ 최대 ' + (C.mh || 5) + ' · 짐 ' + (C.cap || CAPR) + '개' + (i >= NBASE ? ' · 늘 고를 수 있음' : ''), desc: C.d + '. ' + startTxt(C) + '.' }));
    const zn = KINDS.map((K, i) => {
      const bits = [];
      bits.push('물자: ' + (resTxt(K.y, '+') || '없음'));
      if (K.tr) bits.push('보물 「' + K.trn + '」 ' + pctx(K.tr));
      if (i === 6) bits.push('그물이 있으면 진주 25%');
      if (K.fall) bits.push('미끄러짐 ' + pctx(K.fall) + '(강풍 1.5배 · 밧줄·장화면 안전)');
      if (K.burn) bits.push('화상 ' + pctx(K.burn) + '(야자 모자·장화면 안전)');
      if (K.sick) bits.push('열병 ' + pctx(K.sick));
      let d = K.tip + '. ' + bits.join(' · ') + '.';
      if (K.sub) {
        const S = K.sub, ex = [];
        const y = resTxt(S.y, '+'); if (y) ex.push('물자 ' + y + ' 더');
        if (S.loot === 1) ex.push('찾으면 유물');
        if (S.loot === 2) ex.push('찾으면 보물 +2점');
        if (S.sig) ex.push('찾으면 신호 +' + S.sig);
        if (S.heal) ex.push('갈 때마다 ❤+1' + (S.cure ? '·열병이 나아요' : ''));
        d += ' ★ 숨은 장소 「' + S.n + '」: ' + ex.join(' · ') + '.';
      }
      return { icon: K.ic, name: K.n, tag: (i === 0 ? '시작 구역' : K.rare ? '희귀 · 30%' : '흔함') + (K.g === 'S' ? ' · 물가' : K.g === 'F' ? ' · 숲' : K.g === 'W' ? ' · 물' : K.g === 'C' ? ' · 바위' : ''), desc: d };
    });
    const D0 = [0, 1, 3, 6], D1 = [0, 2, 5, 7];
    const when = (e) => D0[e.tr[0]] + '~' + D1[e.tr[1]] + '일';
    const optTxt = (e) => (e.o ? ' 선택: ' + e.o.map((o) => '「' + o.l + '」 ' + o.r).join(' / ') : '');
    const ev = EVS.map((e) => {
      const night = e.t === 0;
      const tag = (night ? '🌙 밤' : '☀ 낮 만남') + ' · ' + CATS[e.c][1] + (e.chain ? ' · 이어지는 사건' : ' · ' + when(e));
      let d = e.d;
      if (!night) d += ' (' + (e.z ? e.z.map((z) => KINDS[z].n).join('·') : '어느 구역이든') + ')';
      if (e.vol) d += ' (화산 언덕이 있는 섬만)';
      return { icon: e.ic, name: e.n, tag, desc: d + optTxt(e) };
    });
    const rl = RL.map((R, i) => ({ icon: R.ic, name: R.n, tag: '+' + (R.pt || 1) + '점' + (i >= RLDECK ? ' · 사건으로만' : KITS.indexOf(i) > 0 ? ' · 시작 짐으로도' : ''), desc: R.d + '.' }));
    const tabN = (t) => TABS[t][0] + ' ' + TABS[t][1];
    const rc = RC.map((R) => {
      const ex = [];
      if (R.fire) ex.push('불 필요');
      if (R.up) ex.push(RC[RCI[R.up]].n + ' 강화');
      if (R.cb) ex.push('캠프에 한 번만');
      if (R.bit) ex.push('각자 1개');
      return { icon: R.ic, name: R.n, tag: tabN(R.tab) + ' · ' + (resTxt(R.c) || '공짜') + (R.pts ? ' · ' + R.pts + '점' : ''), desc: R.d + (ex.length ? ' (' + ex.join(' · ') + ')' : '') };
    });
    return [
      { h: '생존자', p: ['판 시작 때 기본 8명 중 무작위 3명을 받아 1명을 골라요. 아래 4명(선장~요리사)은 언제나 고를 수 있어요.', '시작 짐(물 2·음식 2·나무 1·재료 1)에 생존자 짐이 더해져요. 추가로 「시작 짐」(' + KITS.map((r, i) => (r >= 0 ? RL[r].n : '기본 짐')).join(' · ') + ') 중 하나를 골라요.'], rows: ch },
      { h: '구역', p: ['섬엔 해변 캠프 + 구역 9개(15종 중에서 뽑아요). 희귀 구역(화산·오두막·등대)은 각각 30% 확률로 최대 2곳 나와요.', '이미 아는 구역에 다시 가면 25% 확률로 숨은 장소 ★(+2점)를 찾아요. 찾은 뒤엔 물자가 더 나와요.'], rows: zn },
      { h: '사건', p: ['🌙 밤 사건은 날마다 한 장(같은 사건은 한 판에 한 번). 날이 갈수록 거센 사건이 나와요. ☀ 낮 만남은 구역에 갔을 때 가끔(하루 1번까지).', '「이어지는 사건」은 다른 사건의 선택으로만 나와요.'], rows: ev },
      { h: '유물', p: ['유물은 찾으면 그 판 내내 효과가 있어요. 찾는 곳: 난파선·오두막 첫 방문, 고대 신전·선장실·지하 창고, 사건. 이미 가진 유물이면 대신 +2점.'], rows: rl },
      { h: '만들기', p: ['저녁에 일손 2번으로 만들어요. 도구는 각자 것, 캠프·신호는 모두 함께 써요. 「강화」는 앞 물건이 있어야 만들어요.'], rows: rc },
      { h: '날씨·오늘의 섬', p: ['날마다 날씨 1개와 「오늘의 섬」 1개가 정해져요(1일째는 맑음·흐림만, 뒤로 갈수록 궂은 날씨가 잦아요).'],
        rows: WX.map((w) => ({ icon: w.ic, name: w.n, tag: '날씨', desc: w.d })).concat(DM.map((m) => ({ icon: m.ic, name: m.n, tag: '오늘의 섬', desc: m.d }))) },
    ];
  }

  L.register({
    id: 'island', name: '무인도 7일 생존', tag: '협력 반 · 로그라이크', cat: '보드',
    icon: '<path d="M4 44c6-6 14-9 24-9s18 3 24 9z" fill="currentColor"/><path d="M26 36c0-10 2-17 6-23" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M32 13c-6-4-13-3-17 1 6-1 11 0 17 3z" fill="currentColor"/><path d="M32 13c4-5 11-6 16-3-6 0-11 2-14 5z" fill="currentColor"/><path d="M32 13c1-6 6-9 11-9-4 2-7 6-9 10z" fill="currentColor" opacity=".8"/><circle cx="30" cy="17" r="2.2" fill="currentColor"/><path d="M42 34l2-8 2 8z" fill="currentColor" opacity=".75"/><path d="M2 50c4-2 8 2 12 0s8 2 12 0 8 2 12 0 8 2 12 0 8 2 12 0" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".7"/>',
    tint: '#1f5a4e',
    blurb: '판마다 새로 생기는 무인도! 생존자를 고르고, 안개 낀 섬을 탐험해 숨은 장소와 유물을 찾고, 저녁엔 불·움막·도구·구조 신호를 만들고, 밤엔 갈수록 거세지는 사건을 견뎌요. 7일 안에 함께 구조되면 점수 1등이 승리!',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 620,
    options: [
      { id: 'diff', label: '섬 난이도', choices: [{ v: 'e', label: '느긋하게' }, { v: 'm', label: '보통' }, { v: 'h', label: '험난하게' }], def: 'm' },
    ],
    quick: [
      '7일 안에 다 같이 구조 신호를 채우면 구조선이 와요. 못 채우거나 모두 쓰러지면 모두 져요!',
      '낮엔 섬을 탐험해 물자를 모으고(일손 2번), 저녁엔 불·움막·도구·신호를 만들어요(2번). 밤엔 사건이 터져요.',
      '판마다 섬·날씨·사건이 새로! 생존자 특성과 유물로 버티고, 구조되면 점수 1등이 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '배가 부서져 무인도에 떨어졌어요. 7일 동안 살아남으며 캠프의 「구조 신호」 막대를 목표까지 채우면, 그날 밤 구조선이 와서 모두 구조돼요.',
        '7일째 밤까지 신호를 못 채우거나 모두 쓰러지면 모두 실패! 그래서 서로 도와야 해요.',
        '하지만 1등은 한 명: 구조되면 개인 점수가 가장 높은 사람이 이겨요. 협력과 경쟁 사이에서 줄타기!'] },
      { h: '매 판이 새로운 섬 (로그라이크)', p: [
        '섬 모양, 9개 구역(15종 중에서 뽑아요 · 희귀 구역 3종 포함), 날마다의 날씨와 「오늘의 섬」, 밤 사건 순서가 판마다 무작위로 정해져요.',
        '시작하면 각자 생존자 3명 중 1명을 골라요(특성 12종). 예) 🧭 탐험가 = 낮 일손 3번 대신 ❤ 최대 4, 🔨 목수 = 캠프·신호 물건 나무 1 덜.',
        '유물 23종: 섬에서 찾으면 그 판 내내 효과가 있어요. 예) 🧭 나침반 = 탐험 때 물자 +1·발견 +1점, 🍀 네잎 클로버 = 쓰러질 때 한 번 버팀.',
        '날이 갈수록 어려워져요: 밤 사건이 점점 거세지고(1~2일 / 3~5일 / 6~7일), 5일째부터는 밤에 불이 2씩 타요.'] },
      { h: '하루의 흐름', p: [
        '☀ 낮: 차례대로 일손 2번. 구역을 탭하고 한 번 더 탭(또는 「여기로 가기」)하면 가서 물자를 주워요. 「😴 쉬기」는 ❤+1(열병도 나아요).',
        '🌅 저녁: 차례대로 일손 2번. 모은 물자로 물건을 만들거나, 「🍖 주기」「💧 주기」로 가장 필요한 사람에게 음식·물을 1개 나눠 줘요.',
        '🌙 밤: 사건 카드가 한 장 터지고, 모두 물 1개·음식 1개를 먹어요(저절로). 선택지가 있는 밤 사건은 「오늘의 대장」(그날 첫 차례인 사람)이 정해요.'] },
      { h: '섬 탐험', p: [
        '처음엔 해변 캠프만 보여요. 길(점선)로 이어진 안개 구역만 탐험할 수 있고, 처음 간 사람은 「발견 +2점」!',
        '구역 이름표 옆 초록 점(최대 2개)은 「풍부함」. 갈 때마다 1개 줄고 아침마다 1개 차요. 점이 없으면 반만 나와요.',
        '이미 아는 구역에 다시 가면 25% 확률로 「숨은 장소」★를 찾아요(+2점, 그 뒤로 물자가 더 나와요). 고대 신전·선장실·지하 창고에선 유물도!',
        '난파선·버려진 오두막은 처음 가면 유물, 등대 폐허는 처음 가면 신호 +1. 동굴(수정)·난파선(보물 상자)·석호(그물 있으면 진주)·화산(흑요석)·폭포(금 조각)에선 보물 +2점이 나올 수 있어요.',
        '위험: 절벽은 30% 미끄러짐(밧줄·장화면 안전), 화산은 20% 화상, 습지는 15% 열병. 구역을 한 번 탭하면 얻을 물자와 확률이 아래 줄에 보여요.'] },
      { h: '만남 사건 (낮)', p: [
        '구역에 가면 가끔 만남 사건 카드가 떠요(하루 1번까지). 선택지마다 얻는 것과 위험이 적혀 있어요.',
        '예) 🧑 표류자 발견 → 「도와주기」(물·음식 −1, +2점, 오늘 밤 「표류자의 보답」) 또는 「짐만 뒤지기」(재료 +2, 50% 오늘 밤 「앙갚음」).',
        '예) 🎨 동굴 벽화 → 「벽화 베끼기」를 고르면 다음 날 밤 「보물 지도의 X」(유물 + 숨은 장소)! 이렇게 이어지는 사건이 있어요.'] },
      { h: '날씨와 오늘의 섬', p: [
        '날씨 6종: ☀맑음(거울 신호 +1) · ⛅흐림 · 🌧비(아침 물 +1, 움막 없으면 불 −1) · 🥵무더위(밤에 물 2개) · 💨강풍(신호 연 +1, 절벽 더 미끄러움) · 🌫안개(연기·봉화 −1, 만남이 잦음).',
        '오늘의 섬 10종: 예) 🦀썰물 = 물가 음식 +1, 🔍맑은 시야 = 숨은 장소 찾을 확률 2배.',
        '위쪽 날짜 줄을 탭하면 오늘·내일 날씨, 오늘의 섬, 징조, 캠프 상황을 자세히 볼 수 있어요.'] },
      { h: '살아남기', p: [
        '❤ 체력 5(생존자마다 달라요). 이름표의 주황 칸 = 배, 파란 칸 = 물(각 3칸).',
        '밤마다 음식·물을 1개씩 먹으면 칸이 1 차요. 없으면 칸이 1 줄고, 칸이 0이면 그날 밤 ❤−1.',
        '불이 꺼진 밤엔 추워서 ❤−1(움막 3이면 괜찮아요). 불이 켜져 있고 움막이 2 이상이면 푹 쉬어서 ❤+1.',
        '❤가 0이 되면 쓰러져요. 쓰러진 사람은 더 못 움직이고 1등도 못 해요(같이 구조는 돼요).'] },
      { h: '만들기 (저녁, 30가지)', p: [
        '🏕 캠프: 🔥불 피우기 · ⛺움막 보강 · ☔빗물받이(아침 물 +1) → 🛢저수조 · 🍖훈연대(아침 음식 +1) · 🚧울타리(짐승 막기) · 🗼망대(징조 이틀 앞까지).',
        '📡 신호: 💨연기(+1, 불 필요) · 🆘SOS(+2) → 🔠큰 SOS(+3) · 🏮봉화(+3, 불 필요) · 🛶뗏목(+3, 「지나가는 배」를 꼭 불러요) · 🎏신호 연(+1, 강풍 +2) · 🔆거울(+1, 맑음 +2).',
        '🔧 도구(각자): 창→작살 · 그물 · 돌도끼→큰 도끼 · 물통→물주머니 · 밧줄→갈고리 밧줄 · 덫→큰 덫 · 횃불 · 야자 모자. ⬆ 표시는 업그레이드예요.',
        '🌿 약·음식: 약초 연고(❤+2) · 약초차(물 칸 가득·❤+1) · 모닥불 국(모두 ❤+1).',
        '카드를 한 번 탭하면 설명이 아래 줄에 나오고, 한 번 더 탭(또는 「🔨 만들기」)하면 만들어요.'] },
      { h: '밤 사건', p: [
        '날씨·짐승·바다·사고·행운·수수께끼 32종(연쇄로만 나오는 4종 포함). 아침에 위쪽 「징조」로 오늘 밤 사건의 종류를 미리 알 수 있어요.',
        '선택지가 있는 사건(멧돼지·표류물·해일 경보·이상한 불빛·고래 좌초·유령선)은 오늘의 대장이 골라요.',
        '밤 결과는 카드로 보여 주고, 날짜 줄을 탭해 「지난밤 결과 다시 보기」로 다시 볼 수 있어요.'] },
      { h: '점수·승리', p: [
        '점수 = 발견(+2) + 보물·유물(+2/+1) + 기여(만든 캠프·신호 물건, 나눔) + 도구(개당 1) + 남은 ❤ + 남은 물자 3개당 1점.',
        '구조 신호 목표(보통): 혼자 16 · 2명 34 · 3명 51 · 4명 65. 느긋하게·험난하게로 바꿀 수 있어요(험난하면 행운 사건도 줄어요).',
        '혼자 하기: 구조되면 ★, 6일째 밤까지 ★★, 5일째 밤까지 ★★★.',
        '판이 끝나면 「우리를 괴롭힌 것 / 살린 것」 요약이 나와요.'] },
      { h: '기록 (이 기기)', p: [
        '판 수·구조 횟수·가장 빠른 구조·최고 점수·지난 판 기록이 이 기기에만 저장돼요(생존자 고르는 화면의 「📜 기록」).',
        '생존자 12명과 시작 짐은 모두 처음부터 고를 수 있어요(판 밖에서 강해지는 요소는 없어요).'] },
      { h: '예시', p: [
        '2일째 낮, 내 짐이 물0·음식2·나무1·재료1. 오늘 밤 물이 없으면 물 칸이 줄어요! 길로 이어진 안개를 탐험해 샘을 찾으면 물 +3에 발견 +2점.',
        '저녁에 나무3·재료2가 있고 불이 켜져 있으면 🏮봉화로 신호 +3. 하지만 징조가 ☁ 날씨라면 움막 보강이 먼저일 수도 있어요.'] },
      { h: '조작', p: [
        '구역 탭 = 고르기(얻을 물자·확률이 아래 줄에), 같은 곳 한 번 더 탭 = 출발. 이름표·내 짐 줄을 탭하면 짐·도구·유물·점수를 자세히 봐요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움 AI는 징조·날씨를 읽고 하루를 미리 계획해요.'] },
    ],
    tutorial: [
      { text: '난파되어 무인도에 떨어졌어요! 판마다 섬 모양·구역·날씨·사건이 새로 정해져요. 먼저 각자 생존자를 고르세요 — 특성과 시작 짐이 달라요.' },
      { sel: '.is-banner', text: '위쪽 줄: 날짜·날씨·「징조」(오늘 밤 사건 종류), 🔥불·⛺움막·구조 신호 막대. 탭하면 자세히 볼 수 있어요.' },
      { sel: '.is-scene', text: '☀ 낮: 구역을 탭하고 한 번 더 탭하면 가서 물자를 주워요(일손 2번). 길로 이어진 안개만 탐험할 수 있고, 처음 가면 발견 +2점! 다시 가면 숨은 장소 ★를 찾기도 해요.' },
      { sel: '.is-bottom', text: '아래: 내 짐(물·음식·나무·재료)과 도구·유물. 밤마다 물 1·음식 1을 저절로 먹어요. 가끔 만남 사건 카드가 뜨면 선택지를 골라요.' },
      { sel: '.is-camp', text: '🌅 저녁엔 캠프에서 불·움막·도구·구조 신호를 만들어요. 5일째부터는 밤이 추워 불이 2씩 타요!' },
      { sel: '.is-chips', text: '이름표: 생존자, ❤체력, 주황 칸 = 배, 파란 칸 = 물, ✦유물 수, 점수. 탭하면 자세히! 함께 살아남되, 1등은 점수로!' },
    ],
    codex: islCodex(),
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { KINDS, RC, EVS, CH, RL, WX, DM, canMake, gatherYield, total, urgency, stars, night, giveTarget, keep, geo, reach, NIGHTS, DAYEV, summary, pickOk, dealt },
  });
})();
