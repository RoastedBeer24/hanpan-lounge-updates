/* 숲속 버섯 채집 — 동시 라운드 안개 숲 탐험 (1–4인, 한 폰 여럿·봇·온라인).
   8×11 숲 격자(숲 3가지 × 계절 4가지, 판마다 무작위 생성). 라운드마다 모두 「동시에」 계획을 내고, 다 내면 함께 움직여요.
   계획 = 지금 선 곳 버섯(도구·담기) + 갈 칸 + 도착한 곳 버섯(도구·담기). 걸음 4개(밤 3개)를 도구(1번에 1걸음)와 걷기(덤불·얼음 2걸음)에 나눠 써요.
   처리 순서: 선 곳 살펴보기·담기 → 다 같이 걷기(안개 걷힘·버섯 돋음) → 오두막 지나면 자동 요리·판매 → 도착한 곳 살펴보기·담기 → 숲의 사건.
   같은 버섯을 여럿이 담으면 모두 한 송이씩. 독버섯을 담으면 −3점, 기절해서(출발 전이면 못 걷고) 다음 라운드를 쉬어요.
   버섯은 전부 지어낸 44종 — 닮은꼴 식용/독버섯 21짝 + 외톨이 2종. 계절마다 나오는 짝이 달라요(판마다 계절 금빛 짝 + 4짝).
   다른 곳은 한 군데: 갓(그냥 보임) · 뒤집기(갓 아래·자루) · 냄새 · 문지르기(색 변화) · 자르기(속·밑동). 어떤 독버섯은 해 질 녘부터 빛나요.
   상태(JSON, 작게): m 지형, fg 안개('1' 걷힘), ms [[칸, 섞은 종 번호, 살펴본 비트(1 뒤집기·2 냄새·4 문지르기·8 자르기)]], pl 낸 계획(0 = 기절해서 쉼),
   ps/bk/sc/po/z 사람별, o 주문 [[보상, 종…]], sq 다람쥐, bo 멧돼지, last = {id, r, P:[사람별 결과], b, q, rd}(뷰는 last로 함께 애니메이션). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;

  /* ======================= 숲 격자 ======================= */
  const W = 8, H = 11, N = W * H, CAB = 10 * W + 3;
  const CAP = 5, POISON = 3, MAXM = 30;
  const xy = (t) => [t % W, (t / W) | 0];
  const N4 = [], N9 = [];
  for (let t = 0; t < N; t++) {
    const [x, y] = xy(t), a = [], b = [];
    [[0, -1], [1, 0], [0, 1], [-1, 0]].forEach(([dx, dy]) => { const X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < W && Y < H) a.push(Y * W + X); });
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < W && Y < H) b.push(Y * W + X); }
    N4.push(a); N9.push(b);
  }
  // '.' 풀밭 · 'b' 덤불(2걸음) · '=' 징검다리 · 'H' 오두막 → 지나감 / 'T' 나무 · 'r' 바위 · '~' 개울(겨울엔 언 개울: 2걸음) → 막힘
  const PASS0 = (c) => c === '.' || c === 'b' || c === '=' || c === 'H';
  const passS = (s, c) => PASS0(c) || (s.se === 3 && c === '~');
  const COST = (c) => (c === 'b' || c === '~' ? 2 : 1);
  const GROW = (c) => c === '.' || c === 'b';
  const THEMES = ['이끼 숲', '개울 숲', '자작나무 숲'];
  const SEASONS = ['봄', '여름', '가을', '겨울'], SEAS_IC = ['🌸', '🌻', '🍁', '❄️'];
  const GF = [1, 1.05, 1.22, 0.86];             // 계절별 버섯 돋는 정도
  const RAIN_NM = ['봄비', '소나기', '가을비', '햇살'];
  const PC = (x) => (x & 1) + ((x >> 1) & 1) + ((x >> 2) & 1) + ((x >> 3) & 1);

  function hr(a, b) {
    let h = Math.imul(a ^ 0x9e3779b9, 0x85ebca6b) ^ Math.imul((b | 0) + 0x632be5ab, 0xc2b2ae35);
    h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d); h ^= h >>> 12; h = Math.imul(h, 0x297a2d39); h ^= h >>> 15;
    return (h >>> 0) / 4294967296;
  }

  /* ======================= 버섯 도감 (모두 지어낸 종) =======================
     sh 갓: 0 둥근 · 1 고깔 · 2 납작 우산 · 3 나팔 · 4 구슬 · 5 종 · 6 공 · 7 원통 / pt 무늬: 0 없음 · 1 흰 점(pn) · 2 띠(pn) · 3 비늘 · 4 부채살(pn) · 5 얼룩(pn) · 6 솜털
     rim 가장자리: 0 매끈 · 1 물결 · 2 술 장식 / gt 갓 아래: 0 주름 · 1 스펀지 구멍 · 2 가시 / ring 고리 / sp 자루: 0 민 · 1 그물 · 2 점 · 3 줄
     sm 냄새 / rb 문지르면 / base 밑동: 0 밋밋 · 1 혹 · 2 컵 주머니 / fl 자른 속 / glow 밤에 빛남 / v 식용 값(0 = 독) */
  const SM = [['은은한 흙냄새', '#b59d74', '🌱'], ['꿀처럼 달콤한 냄새', '#f2be3c', '🍯'], ['고소한 아몬드 냄새', '#e2c294', '🥜'],
    ['썩은 달걀 냄새', '#9fb043', '🥚'], ['상큼한 오이 냄새', '#86cf7e', '🥒'], ['향긋한 꽃향기', '#f3a1c4', '🌸'], ['쓴 약 냄새', '#9a86cc', '💊'],
    ['레몬처럼 상큼한 냄새', '#efe14f', '🍋'], ['비린 생선 냄새', '#7ea2b8', '🐟'], ['시원한 솔향', '#58bd8c', '🌲'], ['찐 감자 냄새', '#d8bf84', '🥔'], ['코가 매운 냄새', '#e05e38', '🌶']];
  const RBN = ['색이 그대로예요', '파랗게 변해요', '빨갛게 변해요', '노랗게 변해요', '까맣게 변해요', '초록으로 변해요'];
  const RBC = ['', '#2f63d6', '#d3303a', '#f2c21c', '#1d1a1c', '#35a84a'];
  const FLN = ['하얀 속이 꽉 차 있어요', '속이 텅 빈 대롱이에요', '하얀 즙이 나와요', '주황 즙이 나와요', '노란 속이 꽉 차 있어요', '까만 속이에요'];
  const BASEN = ['밑동 밋밋', '밑동에 불룩한 혹', '밑동에 컵 모양 주머니'];
  const SHN = ['둥근 갓', '고깔 갓', '납작한 우산 갓', '나팔 갓', '구슬 갓', '종 모양 갓', '공 모양', '원통 갓'];
  const GTN = ['주름', '스펀지 구멍', '가시'];
  const SPN = ['민무늬', '그물무늬', '점무늬', '줄무늬'];
  const RIMN = ['매끈', '물결', '술 장식'];

  const SP = [];
  const DEF = { v: 0, sh: 0, c: '#999999', cn: '', pt: 0, pn: 0, rim: 0, gt: 0, gc: '#eeeeee', gn: '', ring: 0, sp: 0, sc: '#eeeeee', base: 0, sm: 0, rb: 0, fl: 0, glow: 0 };
  function sp(base, over) { SP.push(Object.assign({}, DEF, base, over)); return SP.length - 1; }
  const ACORN = sp({ nm: '도토리버섯', v: 1, c: '#8d5b33', cn: '밤색', gc: '#eadfc4', gn: '베이지', sc: '#efe4cc' }, {});
  const SNOWF = sp({ nm: '눈꽃버섯', v: 1, sh: 1, c: '#dfe7f2', cn: '은빛', pt: 4, pn: 3, gc: '#ffffff', gn: '하얀', sc: '#f1f4f8', sm: 9 }, {});
  const PAIRS = [];
  function pair(base, e, p, d, ss, extra) {
    PAIRS.push(Object.assign({ e: sp(base, Object.assign({ v: 2 }, e)), p: sp(base, Object.assign({}, p, { v: 0 })), d, ss }, extra || {}));
  }
  // d: 다른 곳(c 갓 · t 뒤집기 · n 냄새 · r 문지르기 · k 자르기) / ss: 계절(1 봄 · 2 여름 · 4 가을 · 8 겨울) / g: 독버섯이 밤에 빛남 / gold: 계절의 금빛 짝
  pair({ sh: 0, c: '#e8862b', cn: '주황', pt: 1, pn: 5, ring: 1, sc: '#f6ead2', sm: 1 }, { nm: '꿀방울버섯', gc: '#f2e2ae', gn: '크림색' }, { nm: '불씨방울버섯', gc: '#d9452f', gn: '빨간' }, 't', 7);
  pair({ sh: 1, c: '#9a6a3e', cn: '갈색', pt: 3, gc: '#d8c096', gn: '황토색', sp: 2, sc: '#dccaa6' }, { nm: '솔방울고깔', base: 0 }, { nm: '늪고깔', base: 2 }, 'k', 12);
  pair({ sh: 2, c: '#eeeae2', cn: '하얀', gc: '#f0cfd3', gn: '연분홍', sc: '#f5f1e8', sm: 2 }, { nm: '구름우산', ring: 0 }, { nm: '유령우산', ring: 1 }, 't', 6);
  pair({ sh: 4, c: '#8b57b9', cn: '보라', pt: 2, gt: 1, gc: '#dccdea', gn: '연보라', sc: '#e9e0f0' }, { nm: '보라구슬', v: 3, pn: 2 }, { nm: '쌍둥이구슬', pn: 3 }, 'c', 13);
  pair({ sh: 3, c: '#3d9c98', cn: '청록', rim: 1, gc: '#cde8e0', gn: '옥색', sc: '#e0eee8', sm: 4 }, { nm: '달빛나팔', sp: 0 }, { nm: '반딧나팔', sp: 1, glow: 1 }, 't', 6, { g: 1 });
  pair({ sh: 0, c: '#e0b134', cn: '금빛', pt: 4, pn: 5, gc: '#f4e5b0', gn: '노란', ring: 1, sc: '#f3e7c4', sm: 2 }, { nm: '금별버섯', v: 5, base: 1 }, { nm: '가짜금별버섯', base: 0 }, 'k', 4, { gold: 1 });
  pair({ sh: 2, c: '#cf5d4c', cn: '노을빛', pt: 4, pn: 9, gc: '#f0c6a4', gn: '살구색', sp: 2, sc: '#f0dcc8' }, { nm: '노을부채', gt: 1 }, { nm: '멍든부채', gt: 0 }, 't', 6);
  pair({ sh: 0, c: '#5e9944', cn: '이끼색', pt: 1, pn: 3, gc: '#e4eccf', gn: '연두', sc: '#eef0dc', sm: 4 }, { nm: '이끼모자', v: 3, rim: 0 }, { nm: '개구리모자', rim: 1 }, 'c', 3);
  pair({ sh: 5, c: '#f0a8bf', cn: '벚꽃빛', gc: '#fbe3ea', gn: '연분홍', ring: 1, sc: '#fbf3ee' }, { nm: '벚꽃종버섯', sm: 5 }, { nm: '시든종버섯', sm: 6 }, 'n', 1);
  pair({ sh: 1, c: '#f2c230', cn: '해바라기빛', pt: 4, pn: 7, rim: 2, gc: '#fff0b0', gn: '노란', sc: '#f7ecc8', sm: 1 }, { nm: '햇살왕관버섯', v: 5, rb: 3 }, { nm: '그늘왕관버섯', rb: 1 }, 'r', 1, { gold: 1 });
  pair({ sh: 3, c: '#d9c7a4', cn: '베이지', gc: '#f3ead8', gn: '상아색', sc: '#eadfca' }, { nm: '우유깔때기', fl: 2 }, { nm: '녹물깔때기', fl: 3 }, 'k', 6);
  pair({ sh: 0, c: '#e57fb8', cn: '분홍', pt: 6, gc: '#fde6f2', gn: '연분홍', sc: '#fbeef5' }, { nm: '솜사탕버섯', v: 5, sm: 7 }, { nm: '곰팡솜사탕', sm: 8 }, 'n', 2, { gold: 1 });
  pair({ sh: 6, c: '#efe6d2', cn: '상아색', pt: 5, pn: 4, gc: '#e8dcc0', gn: '연갈색', sc: '#efe6d2', sm: 10 }, { nm: '감자공버섯', fl: 0 }, { nm: '먹물공버섯', fl: 5 }, 'k', 14);
  pair({ sh: 0, c: '#eef2f8', cn: '눈빛', pt: 6, gc: '#e6eaf2', gn: '회백색', ring: 1, sc: '#f2f4f8' }, { nm: '눈모자버섯', v: 3, rb: 0 }, { nm: '서리모자버섯', rb: 4 }, 'r', 8);
  pair({ sh: 5, c: '#9fd6ef', cn: '하늘빛', pt: 2, pn: 2, gt: 2, gc: '#d6f0fb', gn: '하늘색', sc: '#e6f6fc', sm: 9 }, { nm: '얼음수정버섯', v: 5, fl: 1 }, { nm: '유리가시버섯', fl: 0, glow: 1 }, 'k', 8, { gold: 1, g: 1 });
  pair({ sh: 7, c: '#e9e1cf', cn: '상아색', pt: 3, gc: '#d8cfc0', gn: '잿빛', sp: 3, sc: '#efe8da' }, { nm: '솔잎원통버섯', sm: 9 }, { nm: '송진원통버섯', sm: 3 }, 'n', 12);
  pair({ sh: 0, c: '#7a4a2a', cn: '밤색', pt: 3, gt: 1, gc: '#e2c27a', gn: '겨자색', sp: 1, sc: '#d9bf94', sm: 2 }, { nm: '밤톨버섯', v: 3, rb: 0 }, { nm: '쓴밤톨버섯', rb: 2 }, 'r', 12);
  pair({ sh: 2, c: '#2f8f86', cn: '청록', pt: 1, gc: '#e8f2ea', gn: '하얀', sc: '#e8efe6', sm: 4 }, { nm: '청록점우산', pn: 3 }, { nm: '얼룩점우산', pn: 5 }, 'c', 2);
  pair({ sh: 1, c: '#8aa04a', cn: '연두', rim: 1, gc: '#efeacc', gn: '아이보리', sc: '#eae6c9', sm: 4 }, { nm: '고사리모자', sp: 3 }, { nm: '뱀고사리모자', sp: 2 }, 't', 1);
  pair({ sh: 2, c: '#b0662f', cn: '장작빛', pt: 4, pn: 5, gt: 1, rim: 1, gc: '#e7c690', gn: '연갈색', sc: '#d7b083' }, { nm: '장작부채버섯', v: 3, sm: 10 }, { nm: '숯부채버섯', sm: 11 }, 'n', 9);
  pair({ sh: 5, c: '#b9a6e0', cn: '라벤더빛', pt: 1, pn: 4, gc: '#f0eafa', gn: '연보라', sc: '#f5f2fb', sm: 5 }, { nm: '이슬종버섯', rb: 0 }, { nm: '독이슬종버섯', rb: 5 }, 'r', 3);
  const GOLDS = [9, 11, 5, 14];                 // 봄·여름·가을·겨울의 금빛 짝
  const PAIR_OF = SP.map(() => -1), REP = SP.map((_, i) => i);
  PAIRS.forEach((P, i) => { PAIR_OF[P.e] = i; PAIR_OF[P.p] = i; REP[P.p] = P.e; });

  const TOOLS = [
    { b: 1, d: 't', nm: '뒤집기', ic: '↻', col: '#e3ae45', how: '버섯을 위로 쓸어 올려 뒤집어요' },
    { b: 2, d: 'n', nm: '냄새', ic: '👃', col: '#f3a1c4', how: '버섯을 꾹 누르고 있으면 킁킁 냄새를 맡아요' },
    { b: 4, d: 'r', nm: '문지르기', ic: '✋', col: '#6aa8ff', how: '갓을 손가락으로 쓱쓱 문질러요' },
    { b: 8, d: 'k', nm: '자르기', ic: '🔪', col: '#9be37a', how: '자루를 옆으로 쓱 그어 잘라요' },
  ];
  const TB = { t: 1, n: 2, r: 4, k: 8 };
  const GL = { c: '갓', t: '갓 아래·자루', n: '냄새', r: '문지르면', k: '자르면', g: '밤' };
  const TOOLNM = { t: '뒤집기', n: '냄새 맡기', r: '문지르기', k: '자르기' };

  function capText(f) {
    const pat = f.pt === 1 ? '흰 점 ' + f.pn + '개' : f.pt === 2 ? '띠 ' + f.pn + '줄' : f.pt === 3 ? '비늘 무늬' : f.pt === 4 ? '부채살 줄무늬' : f.pt === 5 ? '얼룩 무늬' : f.pt === 6 ? '보송한 솜털' : '무늬 없음';
    return f.cn + ' ' + SHN[f.sh] + ', ' + pat + ', 가장자리 ' + RIMN[f.rim];
  }
  function groupText(f, g) {
    if (g === 'c') return capText(f);
    if (g === 't') return f.gn + ' ' + GTN[f.gt] + ' · 고리 ' + (f.ring ? '있음' : '없음') + ' · 자루 ' + SPN[f.sp];
    if (g === 'n') return SM[f.sm][0];
    if (g === 'r') return RBN[f.rb];
    if (g === 'k') return FLN[f.fl] + ' · ' + BASEN[f.base];
    if (g === 'g') return f.glow ? '해 질 녘부터 갓이 빛나요' : '빛나지 않아요';
    return '';
  }
  // 짝끼리 실제로 다른 부분만 짧게
  function diffText(f, d) {
    const o = SP[PAIRS[PAIR_OF[SP.indexOf(f)]].e] === f ? SP[PAIRS[PAIR_OF[SP.indexOf(f)]].p] : SP[PAIRS[PAIR_OF[SP.indexOf(f)]].e];
    if (d === 'c') return f.pn !== o.pn ? (f.pt === 1 ? '흰 점 ' + f.pn + '개' : '띠 ' + f.pn + '줄') : f.rim !== o.rim ? '가장자리 ' + RIMN[f.rim] : capText(f);
    if (d === 't') return f.gc !== o.gc ? '갓 아래 ' + f.gn : f.gt !== o.gt ? '갓 아래 ' + GTN[f.gt] : f.ring !== o.ring ? '고리 ' + (f.ring ? '있음' : '없음') : '자루 ' + SPN[f.sp];
    if (d === 'k') return f.fl !== o.fl ? FLN[f.fl] : BASEN[f.base];
    return groupText(f, d);
  }
  function tipOf(P) {
    const e = SP[P.e], p = SP[P.p];
    return GL[P.d] + ' — ' + e.nm + ': ' + diffText(e, P.d) + ' / ' + p.nm + ': ' + diffText(p, P.d) + (P.d === 'c' ? ' (크게 보면 바로 보여요)' : ' 「' + TOOLNM[P.d] + '」로 확인!') + (P.g ? ' 해 질 녘엔 ' + p.nm + '이(가) 빛나요.' : '');
  }

  /* ======================= 규칙 (순수 로직) ======================= */
  const PH = ['아침', '낮', '해 질 녘', '밤'];
  function phase(s) { const r = Math.min(s.r, s.D); return r >= s.D ? 3 : r > s.D - 3 ? 2 : r <= Math.ceil(s.D * 0.35) ? 0 : 1; }
  const stepsFor = (s) => (phase(s) === 3 ? 3 : 4);
  const hshT = (sd, t) => Math.floor(hr(sd, t * 3 + 1) * 64);
  const enc = (s, t, k) => (k + hshT(s.sd, t)) & 63;
  const dec = (s, m) => (m[1] - hshT(s.sd, m[0])) & 63;
  const mushIdx = (s, t) => { for (let i = 0; i < s.ms.length; i++) if (s.ms[i][0] === t) return i; return -1; };
  const bval = (bk) => bk.reduce((a, k) => a + SP[k].v, 0);
  const isFog = (s, t) => s.fg.charCodeAt(t) !== 49;

  function genMap(th) {
    const [cx, cy] = xy(CAB);
    const dens = [[0.21, 0.03, 0.1], [0.17, 0.03, 0.07], [0.13, 0.08, 0.05]][th];
    for (let tries = 0; tries < 80; tries++) {
      const a = new Array(N).fill('.');
      if (th === 1) { // 개울: 가운데쯤을 가로지르고, 징검다리 2곳
        let y = 4 + U.rand(2); const ys = [];
        for (let x = 0; x < W; x++) { if (x > 0 && Math.random() < 0.3) { const ny = U.clamp(y + (Math.random() < 0.5 ? -1 : 1), 3, 6); if (ny !== y) { a[ny * W + x] = '~'; } y = ny; } a[y * W + x] = '~'; ys.push(y); }
        const cols = [];
        for (let x = 0; x < W; x++) { let c = 0; for (let yy = 0; yy < H; yy++) if (a[yy * W + x] === '~') c++; if (c === 1) cols.push(x); }
        U.shuffle(cols);
        const pick = [];
        for (const x of cols) if (pick.every((p) => Math.abs(p - x) >= 3) && pick.length < 2) pick.push(x);
        pick.forEach((x) => { a[ys[x] * W + x] = '='; });
      }
      for (let t = 0; t < N; t++) {
        if (a[t] !== '.') continue;
        const [x, y] = xy(t);
        if (Math.abs(x - cx) <= 1 && y >= cy - 1) continue;
        const r = Math.random();
        if (r < dens[0]) a[t] = 'T'; else if (r < dens[0] + dens[1]) a[t] = 'r'; else if (r < dens[0] + dens[1] + dens[2]) a[t] = 'b';
      }
      a[CAB] = 'H';
      const seen = new Uint8Array(N), q = [CAB]; seen[CAB] = 1;
      while (q.length) { const u = q.pop(); for (const v of N4[u]) if (!seen[v] && PASS0(a[v])) { seen[v] = 1; q.push(v); } }
      let open = 0, deep = 0;
      for (let t = 0; t < N; t++) { if (PASS0(a[t]) && !seen[t]) a[t] = 'T'; if (seen[t]) { open++; if (t < 3 * W) deep++; } }
      if (open >= 54 && deep >= 9) return a.join('');
    }
    const a = new Array(N).fill('.'); a[CAB] = 'H'; return a.join('');
  }

  function pickSp(s, t, rich) {
    const d = H - 1 - ((t / W) | 0);
    const opts = [];
    if (!rich) opts.push([-1, d <= 3 ? 2.4 : d <= 6 ? 1.1 : 0.45]);
    s.pr.forEach((pi, j) => {
      const v = SP[PAIRS[pi].e].v;
      let w = j === 0 ? (d >= 6 ? 0.45 + (d - 6) * 0.2 : 0) : v >= 3 ? 0.5 + d * 0.07 : 1;
      if (rich) w = j === 0 ? 2.6 : v >= 3 ? 1.5 : 0.5;
      if (w > 0) opts.push([pi, w]);
    });
    let tot = 0; for (const o of opts) tot += o[1];
    let r = Math.random() * tot, k = opts[opts.length - 1][0];
    for (const o of opts) { r -= o[1]; if (r < 0) { k = o[0]; break; } }
    if (k < 0) return s.si;
    return Math.random() < 0.58 ? PAIRS[k].e : PAIRS[k].p;   // 식용이 조금 더 흔해요
  }
  const growChance = (s, t) => (0.21 + 0.045 * (H - 1 - ((t / W) | 0)) + (s.rain ? 0.12 : 0)) * GF[s.se];
  function addM(s, t, k) { s.ms.push([t, enc(s, t, k), 0]); }
  function reveal(s, fg, t, born) {
    for (const v of N9[t]) {
      if (fg[v] === '1') continue;
      fg[v] = '1';
      if (GROW(s.m[v]) && v !== CAB && s.ms.length < MAXM && mushIdx(s, v) < 0 && Math.random() < growChance(s, v)) { addM(s, v, pickSp(s, v)); born.push(v); }
    }
  }

  function genOrder(s, other) {
    const gold = PAIRS[s.pr[0]].e;
    const pool = [s.si].concat(s.pr.map((pi) => PAIRS[pi].e));
    for (let tries = 0; tries < 20; tries++) {
      const n = Math.random() < 0.5 ? 2 : 3, ks = [];
      while (ks.length < n) {
        const k = pool[U.rand(pool.length)];
        if (k === gold && ks.includes(k)) continue;
        if (k === s.si && ks.includes(k)) continue;
        ks.push(k);
      }
      ks.sort((a, b) => a - b);
      const rw = ks.reduce((a, k) => a + SP[k].v, 0) + (n === 2 ? 3 : 5);
      const o = [rw].concat(ks);
      if (!other || JSON.stringify(other) !== JSON.stringify(o)) return o;
    }
    const ks = [s.si, PAIRS[s.pr[1]].e].sort((a, b) => a - b);
    return [SP[s.si].v + SP[PAIRS[s.pr[1]].e].v + 3].concat(ks);
  }
  function canCook(bk, o) {
    const left = bk.slice();
    for (let i = 1; i < o.length; i++) { const j = left.indexOf(o[i]); if (j < 0) return false; left.splice(j, 1); }
    return true;
  }

  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const D = [8, 10, 13].includes(+opts.day) ? +opts.day : 10;
    const sv = opts.season == null || opts.season === 'rand' ? -1 : +opts.season;
    const se = sv >= 0 && sv <= 3 ? sv : U.rand(4);
    const th = U.rand(3);
    const gold = GOLDS[se];
    const pool = PAIRS.map((_, i) => i).filter((i) => !PAIRS[i].gold && (PAIRS[i].ss >> se) & 1);
    const s = {
      v: 2, n, nm: players.map((p) => p.name), sd: (Math.random() * 0x7fffffff) | 0, th, se, D, r: 1,
      gh: opts.hint === 'off' ? 0 : 1, pr: [gold].concat(U.shuffle(pool).slice(0, 4)), si: se === 3 ? SNOWF : ACORN,
      m: genMap(th), fg: '', ms: [],
      ps: players.map(() => CAB), bk: players.map(() => []), sc: players.map(() => 0), po: players.map(() => 0), z: players.map(() => 0), pl: players.map(() => null),
      o: [], sq: -1, sqt: 2 + U.rand(2), bo: -1, bl: 0, bt: 2 + U.rand(3), rn: 3 + U.rand(3), rain: 0,
      done: 0, fin: null, seq: 0, last: null,
    };
    if (s.rn > D - 2) s.rn = D - 2;
    const fg = new Array(N).fill('0');
    for (let t = 0; t < N; t++) { const [x, y] = xy(t), [cx, cy] = xy(CAB); if (Math.abs(x - cx) <= 2 && Math.abs(y - cy) <= 2) fg[t] = '1'; }
    s.fg = fg.join('');
    for (let t = 0; t < N; t++) if (s.fg[t] === '1' && GROW(s.m[t]) && Math.random() < 0.32 * GF[se]) addM(s, t, pickSp(s, t));
    s.o.push(genOrder(s)); s.o.push(genOrder(s, s.o[0]));
    return s;
  }
  // 모두 동시에: 아직 계획을 안 낸 사람 전부
  function actor(s) {
    if (s.done) return null;
    const a = [];
    for (let i = 0; i < s.n; i++) if (s.pl[i] == null) a.push(i);
    return a;
  }

  function sprout(s, rd, cnt) {
    const c = [];
    for (let t = 0; t < N; t++) if (!isFog(s, t) && GROW(s.m[t]) && mushIdx(s, t) < 0 && s.ps.indexOf(t) < 0 && t !== s.bo) c.push(t);
    for (let i = 0; i < cnt && c.length && s.ms.length < MAXM; i++) {   // 깊은 숲일수록 잘 돋아요
      let tot = 0; for (const t of c) tot += growChance(s, t);
      let r = Math.random() * tot, j = c.length - 1;
      for (let q = 0; q < c.length; q++) { r -= growChance(s, c[q]); if (r < 0) { j = q; break; } }
      const t = c.splice(j, 1)[0];
      addM(s, t, pickSp(s, t)); (rd.sp = rd.sp || []).push(t);
    }
  }
  function endRound(s, rd) {
    s.r++;
    if (s.r > s.D) { s.done = 1; s.fin = s.bk.map((b) => Math.floor(bval(b) / 2)); rd.end = 1; return; }
    // 멧돼지
    if (s.bo >= 0) {
      rd.bf = s.bo; rd.bp = [];
      for (let k = 0; k < 2; k++) {
        const c = N4[s.bo].filter((v) => PASS0(s.m[v]) && v !== CAB && s.ps.indexOf(v) < 0 && v !== rd.bf && v !== s.sq);
        if (!c.length) break;
        const v = c[U.rand(c.length)];
        s.bo = v; rd.bp.push(v);
        const mi = mushIdx(s, v);
        if (mi >= 0) { s.ms.splice(mi, 1); (rd.tr = rd.tr || []).push(v); }
      }
      if (--s.bl <= 0) { rd.bx = s.bo; s.bo = -1; }
    } else if (s.r === s.bt) {
      const c = [];
      for (let t = 0; t < N; t++) { const [x, y] = xy(t); if (PASS0(s.m[t]) && t !== CAB && s.ps.indexOf(t) < 0 && y <= 6 && (x === 0 || x === W - 1 || y === 0)) c.push(t); }
      if (c.length) { s.bo = c[U.rand(c.length)]; s.bl = 4; rd.ba = s.bo; }
    }
    // 비(겨울엔 햇살) · 새 버섯
    if (s.r === s.rn) { s.rain = 1; rd.rain = 1; sprout(s, rd, 4 + (s.n >= 3 ? 1 : 0)); }
    else sprout(s, rd, 2 + (s.n >= 3 ? 1 : 0) + (s.rain ? 1 : 0));
    // 다람쥐
    if (s.sq < 0 && s.r >= s.sqt) {
      const c = [];
      for (let t = 0; t < N; t++) {
        if (isFog(s, t) || !PASS0(s.m[t]) || t === CAB || t === s.bo || s.ps.indexOf(t) >= 0 || mushIdx(s, t) >= 0) continue;
        if (N9[t].some((v) => isFog(s, v))) c.push(t);
      }
      if (c.length) { s.sq = c[U.rand(c.length)]; rd.sq = s.sq; }
    }
    const ph = phase(s);
    if (ph !== phase(Object.assign({}, s, { r: s.r - 1 }))) rd.ph = ph;
  }
  function reach(s, from) {
    const d = new Array(N).fill(99), pv = new Array(N).fill(-1), done = new Uint8Array(N);
    d[from] = 0;
    for (;;) {
      let u = -1, b = 99;
      for (let i = 0; i < N; i++) if (!done[i] && d[i] < b) { b = d[i]; u = i; }
      if (u < 0) break;
      done[u] = 1;
      for (const v of N4[u]) {
        if (isFog(s, v) || !passS(s, s.m[v]) || v === s.bo) continue;
        const nd = d[u] + COST(s.m[v]);
        if (nd < d[v]) { d[v] = nd; pv[v] = u; }
      }
    }
    return { d, pv };
  }
  function pathTo(R, from, to) {
    const pa = [to];
    for (let u = to; u !== from;) { u = R.pv[u]; if (u < 0) return null; pa.unshift(u); }
    return pa;
  }
  function squirrel(s, fg, born) {
    const from = s.sq;
    s.sq = -1; s.sqt = s.r + 2 + U.rand(2);
    const c = [];
    let tot = 0;
    for (let t = 0; t < N; t++) if (fg[t] !== '1' && GROW(s.m[t])) { const w = 1 + (H - 1 - ((t / W) | 0)); c.push([t, w]); tot += w; }
    if (!c.length) for (let t = 0; t < N; t++) if (GROW(s.m[t]) && mushIdx(s, t) < 0 && s.ps.indexOf(t) < 0) { const w = 1 + (H - 1 - ((t / W) | 0)); c.push([t, w]); tot += w; }
    if (!c.length) return [from, -1];
    let r = Math.random() * tot, tg = c[c.length - 1][0];
    for (const q of c) { r -= q[1]; if (r < 0) { tg = q[0]; break; } }
    if (mushIdx(s, tg) < 0 && s.ms.length < MAXM) { addM(s, tg, pickSp(s, tg, true)); born.push(tg); }
    reveal(s, fg, tg, born);
    return [from, tg];
  }

  // 계획 = {o, p: 지금 선 곳 버섯(도구 비트·담기), to: 갈 칸(−1 제자리), o2, p2: 도착한 곳 버섯}. 모두 내면 한꺼번에 처리.
  function planCost(s, seat, a) {
    const me = s.ps[seat];
    const o = (a.o | 0) & 15, p = a.p ? 1 : 0, o2 = (a.o2 | 0) & 15, p2 = a.p2 ? 1 : 0;
    let to = a.to == null || a.to < 0 ? -1 : a.to | 0;
    if (to === me) to = -1;
    if (to >= N) return null;
    const mh = mushIdx(s, me), mt = to >= 0 ? mushIdx(s, to) : -1;
    if ((o || p) && mh < 0) return null;
    if ((o2 || p2) && mt < 0) return null;
    if (p + p2 > CAP - s.bk[seat].length) return null;
    const d = to >= 0 ? reach(s, me).d[to] : 0;
    const cost = (mh >= 0 ? PC(o & ~s.ms[mh][2]) : 0) + d + (mt >= 0 ? PC(o2 & ~s.ms[mt][2]) : 0);
    return { o, p, to, o2: to >= 0 ? o2 : 0, p2: to >= 0 ? p2 : 0, cost };
  }
  function apply(s, seat, a) {
    if (s.done || !a || seat < 0 || seat >= s.n || s.pl[seat] != null) throw new Error('not now');
    const c = planCost(s, seat, a);
    if (!c) throw new Error('bad plan');
    if (c.cost > stepsFor(s)) throw new Error('too far');
    s.pl[seat] = [c.o, c.p, c.to, c.o2, c.p2];
    for (let guard = 0; guard < 4 && !s.done && s.pl.every((x) => x != null); guard++) resolve(s);
    return s;
  }
  // 살펴보기 + 담기 (같은 버섯을 여럿이 담으면 모두 한 송이씩). key: 'a' 출발 전 · 'b' 도착 후
  function gather(s, P, who, key, faint) {
    const n = s.n;
    for (const [i, o] of who) {
      const mi = mushIdx(s, s.ps[i]);
      if (mi >= 0 && o) { const nw = o & ~s.ms[mi][2]; if (nw) P[i][key] = [s.ps[i], dec(s, s.ms[mi]), nw, 0]; }
    }
    for (const [i, o] of who) { const mi = mushIdx(s, s.ps[i]); if (mi >= 0) s.ms[mi][2] |= o; }
    const tiles = {};
    for (const [i, , p] of who) if (p) (tiles[s.ps[i]] = tiles[s.ps[i]] || []).push(i);
    for (const t in tiles) {
      const mi = mushIdx(s, +t); if (mi < 0) continue;
      const k = dec(s, s.ms[mi]);
      s.ms.splice(mi, 1);
      for (const i of tiles[t]) {
        const rec = P[i][key] || (P[i][key] = [+t, k, 0, 0]);
        if (SP[k].v > 0) { if (s.bk[i].length < CAP) { s.bk[i].push(k); rec[3] = 1; } }
        else { s.sc[i] -= POISON; s.po[i]++; rec[3] = 2; s.z[i] = 1; faint[i] = 1; }
      }
    }
    return n;
  }
  function resolve(s) {
    const n = s.n, P = [], faint = [];
    const pl = s.pl.map((x) => x || [0, 0, -1, 0, 0]);
    for (let i = 0; i < n; i++) P.push(s.pl[i] === 0 ? { z: 1 } : {});
    // 1) 지금 선 곳에서 살펴보기·담기
    gather(s, P, pl.map((x, i) => [i, x[0], x[1]]).filter((w) => s.pl[w[0]] !== 0), 'a', faint);
    // 2) 다 같이 걷기 (출발 전에 독버섯으로 기절하면 못 걸어요)
    const routes = pl.map((x, i) => (x[2] < 0 || faint[i] || s.pl[i] === 0 ? null : pathTo(reach(s, s.ps[i]), s.ps[i], x[2])));
    const fg = s.fg.split(''), born = [];
    let sqHit = false;
    for (let i = 0; i < n; i++) {
      const pa = routes[i];
      if (!pa) continue;
      s.ps[i] = pa[pa.length - 1]; P[i].pa = pa;
      for (const t of pa) reveal(s, fg, t, born);
      if (s.sq >= 0 && pa.indexOf(s.sq) > 0) sqHit = true;
    }
    const last = { id: ++s.seq, r: s.r, P };
    if (sqHit) last.q = squirrel(s, fg, born);
    s.fg = fg.join('');
    if (born.length) last.b = born;
    // 3) 오두막: 지나가거나 도착하면 자동으로 요리(비싼 주문부터) → 나머지 판매
    const used = {};
    const ord = s.o.map((o, i) => i).sort((a, b) => s.o[b][0] - s.o[a][0]);
    for (let i = 0; i < n; i++) {
      const visit = s.ps[i] === CAB || (P[i].pa && P[i].pa.indexOf(CAB) >= 0);
      if (!visit || !s.bk[i].length) continue;
      const bk = s.bk[i];
      let g = 0, c = 0;
      for (const oi of ord) { const o = s.o[oi]; if (canCook(bk, o)) { for (let j = 1; j < o.length; j++) bk.splice(bk.indexOf(o[j]), 1); g += o[0]; c++; used[oi] = 1; } }
      g += bval(bk); bk.length = 0;
      s.sc[i] += g; P[i].g = g; if (c) P[i].c = c;
    }
    Object.keys(used).forEach((oi) => { s.o[oi] = genOrder(s, s.o[1 - oi]); });
    // 4) 도착한 곳에서 살펴보기·담기
    gather(s, P, pl.map((x, i) => [i, x[3], x[4]]).filter((w) => P[w[0]].pa && !faint[w[0]]), 'b', faint);
    // 5) 숲의 사건
    const rd = {};
    endRound(s, rd);
    if (Object.keys(rd).length) last.rd = rd;
    // 독버섯을 담은 사람은 다음 라운드에 기절해서 쉬어요
    s.pl = s.pl.map((_, i) => (s.z[i] && !s.done ? 0 : null));
    s.z = s.z.map(() => 0);
    s.last = last;
  }

  const STARS = { 8: [6, 10, 14], 10: [7, 12, 16], 13: [10, 16, 21] };
  const starNeed = (s) => STARS[s.D] || STARS[10];
  const totals = (s) => s.sc.map((v, i) => v + (s.fin ? s.fin[i] : 0));
  function result(s) {
    if (!s.done) return null;
    const T = totals(s), nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const brk = (i) => '팔기·요리 ' + (s.sc[i] + s.po[i] * POISON) + (s.fin[i] ? ' + 바구니 반값 ' + s.fin[i] : '') + (s.po[i] ? ' − 독버섯 ' + s.po[i] + '번(−' + s.po[i] * POISON + ')' : '');
    if (s.n === 1) {
      const need = starNeed(s), st = need.filter((v) => T[0] >= v).length;
      return { winners: st ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요',
        text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + T[0] + '점 · ' + SEASONS[s.se] + ' 숲\n' + brk(0) + '\n별 기준 ' + need.join(' / ') + '점' };
    }
    const order = T.map((_, i) => i).sort((a, b) => T[b] - T[a] || a - b);
    const top = T[order[0]], winners = order.filter((i) => T[i] === top);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승',
      text: order.map((i) => (T.filter((v) => v > T[i]).length + 1) + '위  ' + nm(i) + '  ' + T[i] + '점\n    ' + brk(i)).join('\n') };
  }

  /* ======================= AI =======================
     AI는 도감을 알고, 이미 드러난 특징(갓, 살펴본 비트, 해 질 녘 빛)만으로 판단해요. 숨은 특징은 몰라요.
     쉬움: 아무 도구나 1~2번 써 보고, 가끔 잘못 보거나 그냥 담아요. 보통: 대개 맞는 도구를 쓰지만 가끔 헤매요.
     어려움: 어느 도구를 써야 할지 정확히 알고, 주문 재료를 노리며, 다른 사람이 서 있는 버섯은 양보해요. */
  function seenDiff(s, P, bits) { return P.d === 'c' || !!(bits & TB[P.d]) || (!!P.g && phase(s) >= 2); }
  function belief(s, seat, lv, m, bits) {
    const k = dec(s, m);
    if (PAIR_OF[k] < 0) return 1;
    const P = PAIRS[PAIR_OF[k]];
    if (!seenDiff(s, P, bits)) return 0;
    const truth = SP[k].v > 0 ? 1 : -1;
    const err = (P.d === 'c' ? [0, 0.28, 0.1, 0.02] : [0, 0.14, 0.05, 0])[lv] || 0;
    return hr(s.sd + seat * 7919, m[0] * 31 + bits * 5 + s.r) < err ? -truth : truth;
  }
  function toolSeq(s, seat, lv, m) {
    const P = PAIRS[PAIR_OF[dec(s, m)]], right = TB[P.d] || 0;
    const h = hr(s.sd + seat * 31, m[0] * 17 + s.r), h2 = hr(s.sd + seat * 37, m[0] * 19 + s.r);
    if (!right) return [];
    if (lv >= 3) return [right];
    const others = [1, 2, 4, 8].filter((b) => b !== right);
    const wrong = others[Math.floor(h2 * 3)];
    if (lv === 2) return h < 0.75 ? [right] : [wrong, right];
    const all = [1, 2, 4, 8], a = all[Math.floor(h * 4)];
    return h2 < 0.5 ? [a, right] : [a, all[(Math.floor(h * 4) + 1 + Math.floor(h2 * 6) % 3) % 4]];
  }
  function stepsLeftAfter(s) { let t = 0; for (let r = s.r + 1; r <= s.D; r++) t += r >= s.D ? 3 : 4; return t; }

  // 갈 곳 고르기(도착한 곳의 버섯은 그 라운드에 살펴보고 담을 수 있어요)
  function aiMove(s, seat, lv, st, R, nb, bv, bkList) {
    const me = s.ps[seat], d = R.d, dc = lv >= 2 ? reach(s, CAB).d : null;
    const future = st + stepsLeftAfter(s);
    const homeD = d[CAB];
    const margin = lv >= 2 ? 2 : 0;
    const cookable = lv === 3 && s.o.some((o) => canCook(bkList, o));
    let goal = -1;
    const wantHome = nb >= CAP || (bv > 0 && homeD + margin >= future) || (lv === 3 && nb && homeD <= 3 && (nb >= 4 || cookable));
    if (wantHome && homeD < 99) goal = CAB;
    if (goal < 0) {
      let best = 0;
      const noise = (t) => (lv === 1 ? 0.55 + hr(s.sd + seat * 17 + s.r, t) * 0.9 : lv === 2 ? 0.9 + hr(s.sd + seat * 17 + s.r, t) * 0.2 : 1);
      const ordWant = {};
      if (lv === 3) s.o.forEach((o) => { for (let i = 1; i < o.length; i++) if (!bkList.includes(o[i])) ordWant[o[i]] = (ordWant[o[i]] || 0) + 1.2; });
      for (const m of s.ms) {
        const t = m[0];
        if (t === me || d[t] >= 99 || nb >= CAP) continue;
        const b = belief(s, seat, lv, m, m[2]);
        if (b < 0) continue;
        const k = REP[dec(s, m)];
        let val = SP[k].v + (ordWant[k] || 0), cost = d[t] + 1;
        if (b === 0) { val *= lv === 1 ? 0.85 : 0.6; cost += lv === 3 ? 0.5 : 1; }
        if (dc && d[t] + dc[t] + (b === 0 ? 1 : 0) > future + (lv === 2 ? 2 : 0)) continue;   // 가져올 시간이 없으면 포기
        if (lv === 3) for (let j = 0; j < s.n; j++) if (j !== seat && s.ps[j] === t) val *= 0.5;
        const sc = val / cost * noise(t);
        if (sc > best) { best = sc; goal = t; }
      }
      if (lv >= 2 && s.sq >= 0 && d[s.sq] < 99 && nb < CAP) { const sc = 2.4 / (d[s.sq] + 1); if (sc > best) { best = sc; goal = s.sq; } }
      for (let t = 0; t < N; t++) {
        if (d[t] >= 99 || t === me || nb >= CAP) continue;
        let fogN = 0; for (const v of N9[t]) if (isFog(s, v)) fogN++;
        if (!fogN) continue;
        const depth = H - 1 - ((t / W) | 0);
        const sc = fogN * (0.16 + 0.018 * depth) / (d[t] + 1) * noise(t + 200);
        if (sc > best) { best = sc; goal = t; }
      }
      if (goal < 0 && bv > 0 && homeD < 99) goal = CAB;
    }
    if (goal < 0 || goal === me) return -1;
    const path = pathTo(R, me, goal);
    if (!path) return -1;
    let to = -1;
    for (let i = 1; i < path.length; i++) if (d[path[i]] <= st) to = path[i];
    return to;
  }
  // 한 버섯 살펴보기 결정: 남은 걸음 안에서 도구를 쓰고 담을지 정해요
  function aiLook(s, seat, lv, m, rem) {
    let bits = m[2], b = belief(s, seat, lv, m, bits), o = 0, used = 0;
    if (b === 0) {
      for (const t of toolSeq(s, seat, lv, m)) {
        if (used >= rem) break;
        if (bits & t) continue;
        o |= t; bits |= t; used++;
        b = belief(s, seat, lv, m, bits);
        if (b !== 0) break;
      }
    }
    const p = b > 0 || (b === 0 && lv === 1 && hr(s.sd + seat * 3, m[0] * 7 + 11) < 0.3) ? 1 : 0;
    return { o, p, used };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.done || s.pl[seat] != null) return null;
    const st = stepsFor(s), me = s.ps[seat], bk = s.bk[seat];
    const out = { o: 0, p: 0, to: -1, o2: 0, p2: 0 };
    let rem = st, nb = bk.length, bv = bval(bk);
    const bkList = bk.slice();
    const homeLeft = () => reach(s, me).d[CAB] >= rem + stepsLeftAfter(s) - 1;
    // 1) 지금 선 곳
    const mh = mushIdx(s, me);
    if (mh >= 0 && nb < CAP && !(lv >= 2 && nb > 0 && homeLeft())) {
      const r = aiLook(s, seat, lv, s.ms[mh], Math.min(rem, lv === 1 ? 2 : rem));
      out.o = r.o; out.p = r.p; rem -= r.used;
      if (r.p) { const k = REP[dec(s, s.ms[mh])]; nb++; bv += SP[k].v; bkList.push(k); }
    }
    // 2) 갈 곳 (지금 칸 버섯은 이미 처리했으니 다시 고르지 않아요)
    const R = reach(s, me);
    const to = aiMove(s, seat, lv, rem, R, nb, bv, bkList);
    out.to = to;
    if (to >= 0) {
      rem -= R.d[to];
      const mt = mushIdx(s, to);
      const urgent = lv >= 2 && nb > 0 && to !== CAB && reach(s, to).d[CAB] >= rem + stepsLeftAfter(s) - 1;
      if (mt >= 0 && nb < CAP && rem > 0 && !urgent) { const r = aiLook(s, seat, lv, s.ms[mt], rem); out.o2 = r.o; out.p2 = r.p; }
      else if (mt >= 0 && nb < CAP && lv >= 2 && belief(s, seat, lv, s.ms[mt], s.ms[mt][2]) > 0) out.p2 = 1;
    }
    return out;
  }
  function aiDelayFor(s, seat, lv) { return s.done || s.pl[seat] != null ? -1 : lv === 1 ? 1100 : lv === 3 ? 600 : 850; }

  /* ======================= 그리기 도우미 (뷰 전용) ======================= */
  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    const r = U.clamp((n >> 16) + amt, 0, 255), g = U.clamp(((n >> 8) & 255) + amt, 0, 255), b = U.clamp((n & 255) + amt, 0, 255);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }
  function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; }
  // 갓 모양 Path2D. y0 = 갓 아래 끝(자루 꼭대기).
  function capShape(f, cx, y0, S) {
    const p = new Path2D();
    let w, ch, top;
    const scallop = (x1, x2, yy, n, dep) => {
      const step = (x1 - x2) / n;
      for (let i = 0; i < n; i++) { const xa = x1 - step * i, xb = xa - step; p.quadraticCurveTo((xa + xb) / 2, yy + dep, xb, yy); }
    };
    if (f.sh === 4) { const R = S * 0.4; w = R * 2; ch = R * 1.7; top = y0 - ch; p.arc(cx, y0 - R * 0.85, R, 0, TAU); return { p, w, ch, top, cy: y0 - R * 0.85, R }; }
    if (f.sh === 6) { const R = S * 0.44; w = R * 2; ch = R * 1.62; top = y0 - ch; const cyy = y0 - R * 0.76; p.ellipse(cx, cyy, R, R * 0.86, 0, 0, TAU); return { p, w, ch, top, cy: cyy, R }; }
    if (f.sh === 3) {
      w = S * 0.95; ch = S * 0.42; top = y0 - ch - S * 0.06;
      const rr = S * 0.075;
      p.moveTo(cx - w / 2, y0 - ch);
      p.bezierCurveTo(cx - w * 0.3, y0 - ch * 0.62, cx - S * 0.11, y0 - ch * 0.3, cx - S * 0.085, y0);
      p.lineTo(cx + S * 0.085, y0);
      p.bezierCurveTo(cx + S * 0.11, y0 - ch * 0.3, cx + w * 0.3, y0 - ch * 0.62, cx + w / 2, y0 - ch);
      if (f.rim === 1) {
        const n = 8;
        for (let i = 0; i < n; i++) {
          const a2 = ((i + 1) / n) * Math.PI, am = ((i + 0.5) / n) * Math.PI;
          p.quadraticCurveTo(cx + Math.cos(am) * w / 2 * 1.04, y0 - ch + Math.sin(am) * rr + S * 0.035, cx + Math.cos(a2) * w / 2, y0 - ch + Math.sin(a2) * rr);
        }
      } else p.ellipse(cx, y0 - ch, w / 2, rr, 0, 0, Math.PI);
      p.closePath();
      return { p, w, ch, top, rr };
    }
    if (f.sh === 1) {
      w = S * 0.82; ch = S * 0.62; top = y0 - ch;
      p.moveTo(cx - w / 2, y0);
      p.bezierCurveTo(cx - w * 0.47, y0 - ch * 0.55, cx - w * 0.2, y0 - ch, cx, y0 - ch);
      p.bezierCurveTo(cx + w * 0.2, y0 - ch, cx + w * 0.47, y0 - ch * 0.55, cx + w / 2, y0);
    } else if (f.sh === 2) {
      w = S * 1.08; ch = S * 0.25; top = y0 - ch - S * 0.05;
      p.moveTo(cx - w / 2, y0);
      p.bezierCurveTo(cx - w / 2, y0 - ch * 0.9, cx - w * 0.2, y0 - ch, cx - S * 0.07, y0 - ch);
      p.quadraticCurveTo(cx, y0 - ch - S * 0.07, cx + S * 0.07, y0 - ch);
      p.bezierCurveTo(cx + w * 0.2, y0 - ch, cx + w / 2, y0 - ch * 0.9, cx + w / 2, y0);
    } else if (f.sh === 5) {
      w = S * 0.8; ch = S * 0.6; top = y0 - ch;
      p.moveTo(cx - w / 2, y0);
      p.bezierCurveTo(cx - w * 0.34, y0 - ch * 0.3, cx - w * 0.42, y0 - ch, cx, y0 - ch);
      p.bezierCurveTo(cx + w * 0.42, y0 - ch, cx + w * 0.34, y0 - ch * 0.3, cx + w / 2, y0);
    } else if (f.sh === 7) {
      w = S * 0.52; ch = S * 0.82; top = y0 - ch;
      p.moveTo(cx - w / 2, y0); p.lineTo(cx - w * 0.46, y0 - ch * 0.6);
      p.bezierCurveTo(cx - w * 0.44, y0 - ch * 1.04, cx + w * 0.44, y0 - ch * 1.04, cx + w * 0.46, y0 - ch * 0.6);
      p.lineTo(cx + w / 2, y0);
    } else {
      w = S; ch = S * 0.44; top = y0 - ch;
      p.moveTo(cx - w / 2, y0);
      p.bezierCurveTo(cx - w / 2, y0 - ch * 1.3, cx + w / 2, y0 - ch * 1.3, cx + w / 2, y0);
    }
    if (f.rim === 1) scallop(cx + w / 2, cx - w / 2, y0, f.sh === 7 ? 5 : 7, S * 0.075);
    else p.quadraticCurveTo(cx, y0 - S * 0.06, cx - w / 2, y0);
    p.closePath();
    return { p, w, ch, top };
  }
  const SPOTS = [[0, -0.72, 1], [-0.5, -0.42, 0.9], [0.48, -0.46, 0.9], [-0.18, -0.25, 0.7], [0.24, -0.88, 0.62], [0.72, -0.18, 0.6], [-0.7, -0.15, 0.6]];
  function drawCapPattern(ctx, f, C, cx, y0, S) {
    ctx.save(); ctx.clip(C.p);
    const g = ctx.createRadialGradient(cx - C.w * 0.18, C.top + (y0 - C.top) * 0.25, S * 0.05, cx, y0 - (y0 - C.top) * 0.3, C.w * 0.7);
    g.addColorStop(0, shade(f.c, 45)); g.addColorStop(0.55, f.c); g.addColorStop(1, shade(f.c, -40));
    ctx.fillStyle = g; ctx.fill(C.p);
    const capH = y0 - C.top;
    if (f.pt === 1) {
      ctx.fillStyle = '#fbf5e6';
      for (let i = 0; i < f.pn && i < SPOTS.length; i++) {
        const [px, py, sz] = SPOTS[i];
        ctx.beginPath(); ctx.ellipse(cx + px * C.w / 2 * 0.9, y0 + py * capH * 0.95, S * 0.07 * sz, S * 0.058 * sz, 0, 0, TAU); ctx.fill();
      }
    } else if (f.pt === 2) {
      ctx.strokeStyle = shade(f.c, 70); ctx.lineWidth = S * 0.065; ctx.lineCap = 'round';
      const cyy = C.cy != null ? C.cy : y0 - capH / 2, R = C.R || C.w / 2;
      for (let k = 1; k <= f.pn; k++) {
        const yy = cyy - R + (2 * R) * (k / (f.pn + 1)) * 0.9 + R * 0.05;
        ctx.beginPath(); ctx.ellipse(cx, yy, R * 1.05, R * 0.2, 0, 0.1, Math.PI - 0.1); ctx.stroke();
      }
    } else if (f.pt === 3) {
      ctx.strokeStyle = shade(f.c, -55); ctx.lineWidth = Math.max(1, S * 0.022);
      for (let r = 0; r < 4; r++) {
        const yy = y0 - capH * (0.18 + r * 0.2), half = C.w / 2 * (1 - r * 0.2), n = 5 - r;
        for (let i = 0; i < n; i++) {
          const xx = cx - half * 0.8 + (half * 1.6) * (n === 1 ? 0.5 : i / (n - 1));
          ctx.beginPath(); ctx.moveTo(xx - S * 0.04, yy - S * 0.03); ctx.lineTo(xx, yy + S * 0.02); ctx.lineTo(xx + S * 0.04, yy - S * 0.03); ctx.stroke();
        }
      }
    } else if (f.pt === 4) {
      ctx.strokeStyle = f.v >= 5 ? '#fff3b8' : shade(f.c, 60); ctx.lineWidth = Math.max(1, S * 0.03); ctx.lineCap = 'round';
      for (let i = 0; i < f.pn; i++) {
        const fx = -0.92 + 1.84 * (f.pn === 1 ? 0.5 : i / (f.pn - 1));
        ctx.beginPath(); ctx.moveTo(cx + fx * S * 0.04, C.top + capH * 0.06); ctx.quadraticCurveTo(cx + fx * C.w * 0.3, y0 - capH * 0.45, cx + fx * C.w / 2 * 0.95, y0); ctx.stroke();
      }
      if (f.c === '#e0b134' || f.c === '#f2c230') { ctx.fillStyle = '#fff6c8'; star(ctx, cx, C.top + capH * 0.22, S * 0.07); }
    } else if (f.pt === 5) {
      ctx.fillStyle = shade(f.c, -38);
      for (let i = 0; i < f.pn && i < SPOTS.length; i++) {
        const [px, py, sz] = SPOTS[i];
        ctx.beginPath(); ctx.ellipse(cx + px * C.w / 2 * 0.85, y0 + py * capH * 0.9, S * 0.1 * sz, S * 0.065 * sz, px, 0, TAU); ctx.fill();
      }
    } else if (f.pt === 6) {
      ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = Math.max(0.8, S * 0.014); ctx.lineCap = 'round';
      for (let i = 0; i < 34; i++) {
        const x = cx + (hr(i, 3) - 0.5) * C.w, y = C.top + hr(i, 5) * capH, a = hr(i, 7) * TAU, l = S * 0.04;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); ctx.stroke();
      }
    }
    if (f.sh === 2) { ctx.fillStyle = shade(f.c, -30); ctx.beginPath(); ctx.ellipse(cx, y0 - capH * 0.78, S * 0.09, S * 0.045, 0, 0, TAU); ctx.fill(); }
    if (f.sh === 3) { ctx.fillStyle = shade(f.c, -45); ctx.beginPath(); ctx.ellipse(cx, y0 - C.ch, C.w / 2 * 0.86, C.rr * 0.75, 0, 0, TAU); ctx.fill(); }
    ctx.restore();
    ctx.strokeStyle = 'rgba(30,18,10,.55)'; ctx.lineWidth = Math.max(1, S * 0.022); ctx.stroke(C.p);
    if (f.pt === 6) { ctx.save(); ctx.setLineDash([Math.max(1, S * 0.02), Math.max(1, S * 0.03)]); ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = Math.max(1.2, S * 0.045); ctx.stroke(C.p); ctx.restore(); }
  }
  function star(ctx, x, y, r) {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); }
    ctx.closePath(); ctx.fill();
  }
  const stemHOf = (f, S) => (f.sh === 4 ? S * 0.3 : f.sh === 6 ? S * 0.13 : f.sh === 1 ? S * 0.62 : f.sh === 7 ? S * 0.5 : f.sh === 5 ? S * 0.58 : S * 0.56);
  /* 버섯 옆모습. gy = 땅 높이, S = 갓 너비. o: {turn 0..1(낙엽 걷힘·갓 아래), dig 0..1(흙 걷힘·밑동), glow, icon(지도: 짝의 대표 갓), rub 0..1, rubPts, lift} */
  function drawMush(ctx, k, cx, gy0, S, o) {
    o = o || {};
    const look = o.icon ? SP[REP[k]] : SP[k], f = look;   // 지도 아이콘은 짝의 대표 모습(정보가 새지 않게)
    if (o.icon) { o.turn = 1; o.dig = 1; }
    const lift = o.lift || 0, gy = gy0 - lift;
    const stemH = stemHOf(f, S);
    const y0 = gy - stemH, sw = S * (f.sh === 1 || f.sh === 7 ? 0.15 : f.sh === 6 ? 0.2 : 0.17), baseH = S * 0.2;
    const turn = o.turn == null ? 1 : o.turn, dig = o.dig == null ? 1 : o.dig;
    ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(cx, gy0 + S * 0.02, S * 0.42, S * 0.08, 0, 0, TAU); ctx.fill();
    if (dig > 0.5 && !o.icon) { ctx.fillStyle = '#3b2716'; ctx.beginPath(); ctx.ellipse(cx, gy0, S * 0.3, S * 0.07, 0, 0, TAU); ctx.fill(); }
    // 자루
    const stem = new Path2D();
    stem.moveTo(cx - sw / 2, y0); stem.lineTo(cx + sw / 2, y0);
    stem.quadraticCurveTo(cx + sw * 0.62, (y0 + gy) / 2, cx + sw * 0.6, gy - S * 0.02);
    stem.quadraticCurveTo(cx, gy + S * 0.02, cx - sw * 0.6, gy - S * 0.02);
    stem.quadraticCurveTo(cx - sw * 0.62, (y0 + gy) / 2, cx - sw / 2, y0);
    const sg = ctx.createLinearGradient(cx - sw, 0, cx + sw, 0);
    sg.addColorStop(0, shade(f.sc, -30)); sg.addColorStop(0.45, f.sc); sg.addColorStop(1, shade(f.sc, -42));
    ctx.fillStyle = sg; ctx.fill(stem);
    ctx.save(); ctx.clip(stem);
    if (f.sp === 1) {
      ctx.strokeStyle = shade(f.sc, -75); ctx.lineWidth = Math.max(0.8, S * 0.014);
      for (let yy = y0 - sw; yy < gy + sw; yy += S * 0.07) { ctx.beginPath(); ctx.moveTo(cx - sw, yy); ctx.lineTo(cx + sw, yy + sw * 1.2); ctx.moveTo(cx + sw, yy); ctx.lineTo(cx - sw, yy + sw * 1.2); ctx.stroke(); }
    } else if (f.sp === 2) {
      ctx.fillStyle = shade(f.sc, -60);
      for (let yy = y0 + S * 0.08, r = 0; yy < gy; yy += S * 0.08, r++) for (let xx = -1; xx <= 1; xx += 2) { ctx.beginPath(); ctx.arc(cx + xx * sw * 0.22 + (r % 2 ? sw * 0.15 : 0), yy, Math.max(0.8, S * 0.014), 0, TAU); ctx.fill(); }
    } else if (f.sp === 3) {
      ctx.strokeStyle = shade(f.sc, -65); ctx.lineWidth = Math.max(0.9, S * 0.02);
      for (let yy = y0 + S * 0.06; yy < gy; yy += S * 0.075) { ctx.beginPath(); ctx.moveTo(cx - sw, yy); ctx.lineTo(cx - sw * 0.3, yy + S * 0.025); ctx.lineTo(cx + sw * 0.3, yy - S * 0.01); ctx.lineTo(cx + sw, yy + S * 0.02); ctx.stroke(); }
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(60,40,20,.45)'; ctx.lineWidth = Math.max(1, S * 0.016); ctx.stroke(stem);
    if (f.ring && f.sh !== 6) {
      const yr = y0 + (gy - y0) * 0.2;
      ctx.fillStyle = shade(f.sc, 12); ctx.strokeStyle = 'rgba(70,50,30,.6)';
      ctx.beginPath(); ctx.moveTo(cx - sw * 0.55, yr);
      ctx.quadraticCurveTo(cx - sw * 1.4, yr + S * 0.04, cx - sw * 1.35, yr + S * 0.1);
      for (let i = 0; i < 5; i++) { const x1 = cx - sw * 1.35 + (sw * 2.7) * (i / 5), x2 = cx - sw * 1.35 + (sw * 2.7) * ((i + 1) / 5); ctx.quadraticCurveTo((x1 + x2) / 2, yr + S * 0.135, x2, yr + S * 0.1); }
      ctx.quadraticCurveTo(cx + sw * 1.4, yr + S * 0.04, cx + sw * 0.55, yr); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
    if (f.base === 1) {
      const bg = ctx.createRadialGradient(cx - sw * 0.4, gy - S * 0.12, S * 0.02, cx, gy - S * 0.08, sw * 1.5);
      bg.addColorStop(0, shade(f.sc, 20)); bg.addColorStop(1, shade(f.sc, -40));
      ctx.fillStyle = bg; ctx.beginPath(); ctx.ellipse(cx, gy - S * 0.085, sw * 1.4, S * 0.11, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(60,40,20,.6)'; ctx.lineWidth = Math.max(1, S * 0.016); ctx.stroke();
    }
    if (f.base === 2) {
      ctx.fillStyle = 'rgba(236,228,206,.96)'; ctx.strokeStyle = '#a8996f'; ctx.lineWidth = Math.max(1, S * 0.016);
      ctx.beginPath(); ctx.moveTo(cx - sw * 1.25, gy);
      ctx.lineTo(cx - sw * 1.2, gy - S * 0.15);
      for (let i = 0; i < 6; i++) { const x = cx - sw * 1.2 + sw * 2.4 * ((i + 0.5) / 6); ctx.lineTo(x, gy - S * (i % 2 ? 0.15 : 0.11)); }
      ctx.lineTo(cx + sw * 1.2, gy - S * 0.15); ctx.lineTo(cx + sw * 1.25, gy);
      ctx.quadraticCurveTo(cx, gy + S * 0.04, cx - sw * 1.25, gy); ctx.fill(); ctx.stroke();
    }
    // 덮개: 흙(밑동) · 낙엽(자루)
    if (dig < 1) {
      const top = gy - (baseH + S * 0.03) * (1 - dig);
      ctx.fillStyle = '#5a3d22';
      ctx.beginPath(); ctx.moveTo(cx - S * 0.4, gy + S * 0.02); ctx.quadraticCurveTo(cx - S * 0.32, top, cx, top - S * 0.02); ctx.quadraticCurveTo(cx + S * 0.32, top, cx + S * 0.4, gy + S * 0.02); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#6e4c2c'; ctx.beginPath(); ctx.ellipse(cx - S * 0.1, top + S * 0.05, S * 0.1, S * 0.03, 0, 0, TAU); ctx.fill();
    }
    if (turn < 1 && f.sh !== 6) {
      const bot = gy - baseH * (dig < 1 ? 0.7 : 1), top = U.lerp(y0 + S * 0.02, bot, turn);
      if (bot - top > 1) {
        const lw = S * 0.34;
        ctx.fillStyle = '#4f6b2a';
        ctx.beginPath(); ctx.moveTo(cx - lw, bot + S * 0.03); ctx.quadraticCurveTo(cx - lw * 0.95, top, cx - sw * 0.2, top - S * 0.01);
        ctx.lineTo(cx + sw * 0.2, top - S * 0.01); ctx.quadraticCurveTo(cx + lw * 0.95, top, cx + lw, bot + S * 0.03); ctx.closePath(); ctx.fill();
        const LC = ['#b5682c', '#d39a3a', '#8a4a24', '#6f8a33', '#c4562e'];
        for (let i = 0; i < 7; i++) {
          const lx = cx + (hr(k + 5, i) - 0.5) * lw * 1.7, ly = U.lerp(top + S * 0.02, bot, hr(k + 9, i));
          ctx.fillStyle = LC[i % LC.length];
          ctx.beginPath(); ctx.ellipse(lx, ly, S * 0.085, S * 0.04, (hr(k, i) - 0.5) * 2.4, 0, TAU); ctx.fill();
        }
      }
    }
    // 갓
    const C = capShape(look, cx, y0, S);
    if (o.glow) { ctx.save(); ctx.shadowColor = '#9dffd0'; ctx.shadowBlur = S * 0.45; ctx.strokeStyle = 'rgba(190,255,220,.95)'; ctx.lineWidth = S * 0.06; ctx.stroke(C.p); ctx.restore(); }
    drawCapPattern(ctx, look, C, cx, y0, S);
    if (look.rim === 2 && look.sh !== 3 && look.sh !== 4 && look.sh !== 6) { // 술 장식
      ctx.fillStyle = shade(look.c, -15); ctx.strokeStyle = 'rgba(30,18,10,.45)'; ctx.lineWidth = Math.max(0.8, S * 0.012);
      const n = 9;
      for (let i = 0; i < n; i++) { const x = cx - C.w / 2 * 0.92 + C.w * 0.92 * (i / (n - 1)), l = S * (0.06 + (i % 2) * 0.03); ctx.beginPath(); ctx.moveTo(x - S * 0.025, y0 - S * 0.01); ctx.lineTo(x, y0 + l); ctx.lineTo(x + S * 0.025, y0 - S * 0.01); ctx.closePath(); ctx.fill(); ctx.stroke(); }
    }
    if (o.rub > 0 && !o.icon) { // 문지른 자국
      ctx.save(); ctx.clip(C.p);
      const ccy = C.cy != null ? C.cy : y0 - (y0 - C.top) * 0.5;
      const pts = o.rubPts && o.rubPts.length ? o.rubPts : [[-0.12, -0.05], [0.08, -0.1], [0.02, 0.04], [-0.04, -0.14]];
      const colr = f.rb ? RBC[f.rb] : '#ffffff', al = f.rb ? 0.8 : 0.35;
      for (const [px, py] of pts) {
        const x = cx + px * S, y = ccy + py * S, r = S * 0.11;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, rgba(colr, al * o.rub)); g.addColorStop(1, rgba(colr, 0));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    }
    if (turn > 0.5 && !o.icon && look.sh !== 3) { // 갓 아래 띠 (주름/구멍/가시)
      const round = look.sh === 4 || look.sh === 6;
      const rw = (round ? C.R * 0.8 : C.w / 2 * 0.92), ry = S * 0.06, yy = round ? C.cy + C.R * 0.72 : y0 - S * 0.012;
      ctx.save(); ctx.globalAlpha = Math.min(1, (turn - 0.5) * 2);
      ctx.fillStyle = f.gc; ctx.beginPath(); ctx.ellipse(cx, yy, rw, ry, 0, 0, TAU); ctx.fill();
      if (f.gt === 2) {
        ctx.fillStyle = shade(f.gc, -25);
        for (let i = -7; i <= 7; i++) { const x = cx + i * rw / 7.5; ctx.beginPath(); ctx.moveTo(x - S * 0.018, yy); ctx.lineTo(x, yy + ry * 1.9); ctx.lineTo(x + S * 0.018, yy); ctx.closePath(); ctx.fill(); }
      }
      ctx.beginPath(); ctx.ellipse(cx, yy, rw, ry, 0, 0, TAU); ctx.clip();
      ctx.strokeStyle = shade(f.gc, -45); ctx.fillStyle = shade(f.gc, -50); ctx.lineWidth = Math.max(0.8, S * 0.012);
      if (f.gt === 0) for (let i = -10; i <= 10; i++) { ctx.beginPath(); ctx.moveTo(cx + i * rw / 10, yy - ry); ctx.lineTo(cx + i * rw / 10 * 0.8, yy + ry); ctx.stroke(); }
      else if (f.gt === 1) for (let i = -9; i <= 9; i++) for (let j = -1; j <= 1; j++) { ctx.beginPath(); ctx.arc(cx + i * rw / 9 + (j % 2 ? rw / 18 : 0), yy + j * ry * 0.5, Math.max(0.7, S * 0.011), 0, TAU); ctx.fill(); }
      ctx.restore();
    }
    if (turn > 0.5 && !o.icon && look.sh === 3) {
      ctx.save(); ctx.clip(C.p); ctx.globalAlpha = Math.min(1, (turn - 0.5) * 2) * 0.9;
      ctx.strokeStyle = f.gc; ctx.lineWidth = Math.max(1, S * 0.02);
      for (let i = -6; i <= 6; i++) { ctx.beginPath(); ctx.moveTo(cx + i * S * 0.012, y0); ctx.lineTo(cx + i * C.w / 2 / 6 * 0.95, y0 - C.ch + C.rr * 0.9); ctx.stroke(); }
      ctx.restore();
    }
  }
  /* 갓 아래 모습(아래에서 본 원) */
  function drawUnder(ctx, k, cx, cy, r, shown) {
    const f = SP[k];
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(cx + 1.5, cy + 2.5, r, 0, TAU); ctx.fill();
    ctx.fillStyle = shown ? shade(f.c, -20) : '#3a3326'; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
    if (shown) {
      ctx.fillStyle = f.gc; ctx.beginPath(); ctx.arc(cx, cy, r * 0.9, 0, TAU); ctx.fill();
      if (f.gt === 0) {
        ctx.strokeStyle = shade(f.gc, -55); ctx.lineWidth = Math.max(0.8, r * 0.035);
        for (let i = 0; i < 40; i++) { const a = i / 40 * TAU, r0 = i % 2 ? r * 0.45 : r * 0.3; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); ctx.lineTo(cx + Math.cos(a) * r * 0.88, cy + Math.sin(a) * r * 0.88); ctx.stroke(); }
      } else if (f.gt === 1) {
        ctx.fillStyle = shade(f.gc, -60);
        for (let rr = r * 0.32; rr < r * 0.86; rr += r * 0.1) { const n = Math.round(rr * TAU / (r * 0.1)); for (let i = 0; i < n; i++) { const a = i / n * TAU + rr; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr, r * 0.03, 0, TAU); ctx.fill(); } }
      } else {
        ctx.fillStyle = shade(f.gc, -40);
        for (let rr = r * 0.32; rr < r * 0.86; rr += r * 0.12) { const n = Math.round(rr * TAU / (r * 0.13)); for (let i = 0; i < n; i++) { const a = i / n * TAU + rr * 2, x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr; ctx.beginPath(); ctx.moveTo(x - r * 0.03, y); ctx.lineTo(x, y + r * 0.08); ctx.lineTo(x + r * 0.03, y); ctx.closePath(); ctx.fill(); } }
      }
      ctx.fillStyle = f.sc; ctx.strokeStyle = 'rgba(60,40,20,.6)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(cx, cy, r * 0.2, 0, TAU); ctx.fill(); ctx.stroke();
      if (f.ring) { ctx.strokeStyle = shade(f.sc, -30); ctx.lineWidth = Math.max(1.2, r * 0.07); ctx.beginPath(); ctx.arc(cx, cy, r * 0.27, 0, TAU); ctx.stroke(); }
    } else {
      ctx.fillStyle = '#d8cdb4'; ctx.font = '700 ' + Math.round(r * 0.9) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('?', cx, cy + 1);
    }
    ctx.strokeStyle = 'rgba(242,233,216,.55)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke();
    ctx.restore();
  }
  /* 자른 자루 단면 */
  function drawSection(ctx, k, cx, cy, r, t) {
    const f = SP[k];
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(cx + 1.5, cy + 2.5, r, r * 0.8, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = shade(f.sc, -25); ctx.beginPath(); ctx.ellipse(cx, cy, r, r * 0.8, 0, 0, TAU); ctx.fill();
    const flesh = f.fl === 4 ? '#f2d35a' : f.fl === 5 ? '#2b2426' : '#fbf8f0';
    ctx.fillStyle = flesh; ctx.beginPath(); ctx.ellipse(cx, cy, r * 0.84, r * 0.66, 0, 0, TAU); ctx.fill();
    if (f.fl === 1) { ctx.fillStyle = '#3a2c20'; ctx.beginPath(); ctx.ellipse(cx, cy, r * 0.45, r * 0.34, 0, 0, TAU); ctx.fill(); }
    if (f.fl === 5) { ctx.fillStyle = 'rgba(120,110,120,.5)'; for (let i = 0; i < 9; i++) { ctx.beginPath(); ctx.arc(cx + (hr(i, 1) - 0.5) * r * 1.2, cy + (hr(i, 2) - 0.5) * r * 0.9, r * 0.06, 0, TAU); ctx.fill(); } }
    if (f.fl === 2 || f.fl === 3) {
      const mc = f.fl === 2 ? '#ffffff' : '#f08a2a';
      ctx.fillStyle = mc; ctx.strokeStyle = 'rgba(60,40,20,.35)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(cx, cy, r * 0.5, r * 0.36, 0, 0, TAU); ctx.globalAlpha = 0.55; ctx.fill(); ctx.globalAlpha = 1;
      const ph = ((t || 0) * 0.8) % 1;
      for (let i = 0; i < 3; i++) {
        const x = cx + (i - 1) * r * 0.42, y = cy + r * 0.62 + ((ph + i * 0.33) % 1) * r * 0.7, rr = r * 0.11;
        ctx.beginPath(); ctx.moveTo(x, y - rr * 1.6); ctx.quadraticCurveTo(x + rr, y, x, y + rr); ctx.quadraticCurveTo(x - rr, y, x, y - rr * 1.6); ctx.fill(); ctx.stroke();
      }
    }
    ctx.strokeStyle = 'rgba(242,233,216,.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(cx, cy, r, r * 0.8, 0, 0, TAU); ctx.stroke();
    ctx.restore();
  }
  function drawSmell(ctx, k, x, y, S, a, t) {
    const col = SM[SP[k].sm][1];
    ctx.save(); ctx.lineCap = 'round';
    for (let i = 0; i < 3; i++) {
      const ph = (t * 0.6 + i / 3) % 1, yy = y - ph * S * 0.7, xx = x + (i - 1) * S * 0.18;
      ctx.strokeStyle = rgba(col, 0.75 * a * (1 - ph)); ctx.lineWidth = Math.max(2, S * 0.05);
      ctx.beginPath(); ctx.moveTo(xx, yy);
      ctx.bezierCurveTo(xx + S * 0.08, yy - S * 0.08, xx - S * 0.08, yy - S * 0.16, xx, yy - S * 0.24); ctx.stroke();
    }
    ctx.restore();
  }
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }

  /* ======================= 계절 팔레트 ======================= */
  const SPAL = [
    { g: '#5f8c40', g2: '#6a984a', fleck: ['rgba(240,170,200,.55)', 'rgba(255,240,150,.5)', 'rgba(40,70,30,.3)'], t1: '#3e6d34', t2: '#4f8a3e', t3: '#f2b3c9', bu: '#6fa04a', berry: '#f7eef4', out: '#16220f', fog: '214,220,226', w1: '#4a8db0', w2: '#3a7898', obs: ['#3a5a2c', '#22351a'] },
    { g: '#3d6f2c', g2: '#467b34', fleck: ['rgba(30,60,20,.35)', 'rgba(120,170,70,.35)', 'rgba(250,240,170,.35)'], t1: '#1d4822', t2: '#2a632e', t3: '#3f8a3a', bu: '#4c8a34', berry: '#c23a3a', out: '#0e1b0b', fog: '206,216,214', w1: '#3a7896', w2: '#2c5f7a', obs: ['#2c4a24', '#18281a'] },
    { g: '#7d6a35', g2: '#88743c', fleck: ['rgba(214,110,40,.6)', 'rgba(232,180,60,.55)', 'rgba(150,50,30,.5)'], t1: '#8c3b1f', t2: '#c8642a', t3: '#e8a83c', bu: '#9b6b2c', berry: '#7a1f1f', out: '#1c140a', fog: '222,214,204', w1: '#4a7f90', w2: '#3a6676', obs: ['#4a3a22', '#2a2014'] },
    { g: '#dce5ec', g2: '#e7edf2', fleck: ['rgba(150,170,190,.35)', 'rgba(255,255,255,.8)', 'rgba(120,140,160,.25)'], t1: '#24493a', t2: '#2f5c48', t3: '#f5f9fc', bu: '#a9bcb2', berry: '#c23a3a', out: '#182030', fog: '170,184,206', w1: '#c4e2f2', w2: '#a8d2e8', obs: ['#3a4a5a', '#222c38'] },
  ];

  /* ======================= 뷰 ======================= */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, T = 44, mapW = W * 44, mapH = H * 44;
    let camX = 0, camY = 0, manual = false, topH = 40, botH = 170;
    let terr = null, terrKey = '', fogC = null, fogKey = '', dark = null;
    let anim = null, pending = false, busyT = 0, watchdog = 0, time = 0, shownKey = '';
    let lineA = '', reachD = null, reachFor = '', pathKey = '', pathC = null;
    let active = -1, handEl = null, handKey = '';
    const plan = { key: '', seat: -1, o: 0, p: 0, to: -1, o2: 0, p2: 0 };
    const fx = { poofs: [], floats: [], born: {}, bubbles: [], trail: null, boar: null, rain: 0, later: [], dizzy: {} };
    const sp8 = () => L.debug.speed || 1;
    const nameOf = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const colOf = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');

    /* ---------- DOM ---------- */
    const top = L.h('div', { class: 'hud top mu-top', style: { gap: '4px', padding: '6px 6px', flexWrap: 'wrap', justifyContent: 'center' } });
    const hud = L.h('div', { class: 'hud bottom mu-hud', style: { padding: '6px 6px 8px' } });
    const box = L.h('div', { class: 'panel mu-box', style: { width: '100%', maxWidth: '480px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px', padding: '8px' } });
    hud.append(box);
    root.append(top, hud);
    const info = L.h('div', { style: { fontSize: '13px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minHeight: '18px', display: 'flex', alignItems: 'center', gap: '6px' } });
    const rowB = L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0 } });
    const steps = L.h('div', { class: 'mu-steps', title: '걸음', style: { display: 'flex', alignItems: 'center', gap: '3px', flex: 'none', fontSize: '13px', color: 'var(--muted)' } });
    const bkCv = L.h('canvas', { class: 'mu-basket', title: '바구니', style: { width: '102px', height: '30px', flex: 'none' } });
    const guideBtn = L.h('button', { class: 'btn mu-guide-btn', style: { padding: '0 9px', flex: 'none', whiteSpace: 'nowrap', minHeight: '44px' }, text: '📖 도감', onclick: () => openGuide() });
    rowB.append(steps, bkCv, L.h('div', { style: { flex: '1 1 0', minWidth: 0 } }), guideBtn);
    const rowC = L.h('div', { class: 'mu-mush', style: { display: 'flex', gap: '6px', alignItems: 'stretch' } });
    const rowD = L.h('div', { style: { display: 'flex', gap: '6px', alignItems: 'stretch' } });
    const resetBtn = L.h('button', { class: 'btn', style: { flex: 'none', padding: '0 12px', minHeight: '44px', whiteSpace: 'nowrap' }, text: '↺ 다시', onclick: () => resetPlan() });
    const goBtn = L.h('button', { class: 'btn primary mu-go', style: { flex: '1 1 0', minWidth: 0, minHeight: '44px', padding: '0 8px', fontSize: '14px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, onclick: () => submitPlan() });
    const waitEl = L.h('div', { class: 'muted', style: { flex: '1 1 0', minHeight: '44px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', textAlign: 'center' } });
    rowD.append(resetBtn, goBtn, waitEl);
    box.append(info, rowB, rowC, rowD);

    function setCanvas(c, w, h) { const d = Math.min(window.devicePixelRatio || 1, 2.5); c.width = Math.round(w * d); c.height = Math.round(h * d); const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); return x; }
    const bkCtx = setCanvas(bkCv, 102, 30);
    // 버섯 카드(여기 · 갈 곳) — 미리 만들어 두고 다시 씀
    const cards = ['a', 'b'].map((slot) => {
      const cvs = L.h('canvas', { style: { width: '44px', height: '44px', display: 'block', flex: 'none', borderRadius: '8px' } });
      const t1 = L.h('span', { style: { fontSize: '11px', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } });
      const t2 = L.h('span', { style: { fontSize: '13px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } });
      const btn = L.h('button', { class: 'btn mu-card mu-card-' + slot, style: { flex: '1 1 0', minWidth: 0, minHeight: '54px', padding: '4px 6px', display: 'flex', alignItems: 'center', justifyContent: 'flex-start', gap: '6px', textAlign: 'left' }, onclick: () => openSlot(slot) },
        cvs, L.h('span', { style: { display: 'flex', flexDirection: 'column', minWidth: 0, lineHeight: 1.25 } }, t1, t2));
      return { slot, btn, t1, t2, ctx: setCanvas(cvs, 44, 44) };
    });
    rowC.append(cards[0].btn, cards[1].btn);

    /* ---------- 계획 ---------- */
    const multiLocal = () => !api.online && api.mySeats().length >= 2;
    const pendingMine = () => (st && !st.done ? api.mySeats().filter((i) => st.pl[i] == null) : []);
    function planSeat() {
      if (!st || st.done || anim) return -1;
      const pm = pendingMine();
      if (!pm.length) return -1;
      if (!multiLocal()) return pm[0];
      return pm.includes(active) ? active : -1;
    }
    function syncPlan() {
      const seat = planSeat();
      const key = st ? st.sd + ':' + st.r + ':' + seat : '';
      if (plan.key !== key) { plan.key = key; plan.seat = seat; plan.o = 0; plan.p = 0; plan.to = -1; plan.o2 = 0; plan.p2 = 0; }
      const rk = key + ':' + (st ? st.fg + st.bo : '');
      if (reachFor !== rk) { reachFor = rk; reachD = seat >= 0 ? reach(st, st.ps[seat]).d : null; }
    }
    const slotTile = (slot) => (plan.seat < 0 ? -1 : slot === 'a' ? st.ps[plan.seat] : plan.to);
    function slotMush(slot) { const t = slotTile(slot); if (t < 0) return null; const mi = mushIdx(st, t); return mi >= 0 ? st.ms[mi] : null; }
    const slotBits = (slot) => (slot === 'a' ? plan.o : plan.o2);
    const slotPick = (slot) => (slot === 'a' ? plan.p : plan.p2);
    const pickCount = () => plan.p + (plan.to >= 0 ? plan.p2 : 0);
    function stepsInfo() {
      const max = stepsFor(st), ma = slotMush('a'), mb = plan.to >= 0 ? slotMush('b') : null;
      const ta = ma ? PC(plan.o & ~ma[2]) : 0, tb = mb ? PC(plan.o2 & ~mb[2]) : 0, path = plan.to >= 0 && reachD ? reachD[plan.to] : 0;
      return { max, tools: ta + tb, ta, tb, path, left: max - ta - tb - path };
    }
    const locked = () => plan.to >= 0 && stepsInfo().tb > 0;
    function setDest(t) {
      if (locked()) { hintToast('갈 곳 버섯을 이미 살펴봐서 갈 곳은 그대로예요'); return false; }
      plan.to = t; plan.o2 = 0; plan.p2 = 0; manual = false;
      return true;
    }
    function resetPlan() { if (plan.seat < 0) return; plan.p = 0; plan.p2 = 0; if (!locked()) plan.to = -1; api.sfx('click'); renderHud(); }
    function togglePick(slot) {
      if (plan.seat < 0 || pending) return;
      const on = slotPick(slot);
      if (!on && st.bk[plan.seat].length + pickCount() >= CAP) { api.toast('바구니가 가득 찼어요'); return; }
      if (slot === 'a') plan.p = on ? 0 : 1; else plan.p2 = on ? 0 : 1;
      api.sfx(on ? 'click' : 'pop'); renderHud(); if (obs) renderObs();
    }
    function submitPlan() {
      const seat = planSeat();
      if (seat < 0 || pending || seat !== plan.seat) return;
      const a = { o: plan.o, p: plan.p, to: plan.to, o2: plan.to >= 0 ? plan.o2 : 0, p2: plan.to >= 0 ? plan.p2 : 0 };
      pending = true; api.sfx('chip'); api.buzz(10);
      closeObs();
      api.actAs(seat, a);
      setTimeout(() => { if (pending) { pending = false; renderHud(); } }, 2500);
      renderHud();
    }

    /* ---------- 레이아웃·카메라 ---------- */
    function layout() {
      topH = top.offsetHeight || 40;
      const aw = cv.w - 8, ah = cv.h - topH - 190;
      const nt = Math.floor(U.clamp(Math.min(aw / W, ah / H), 44, 64));
      if (nt !== T) { T = nt; terrKey = ''; fogKey = ''; }
      mapW = W * T; mapH = H * T;
    }
    function measure() { topH = top.offsetHeight || topH; botH = hud.offsetHeight || botH; }
    function viewRect() { return { x: 0, y: topH, w: cv.w, h: Math.max(60, cv.h - topH - botH) }; }
    function clampCam(cx, cy) {
      const v = viewRect();
      if (mapW <= v.w) cx = mapW / 2; else cx = U.clamp(cx, v.w / 2 - 4, mapW - v.w / 2 + 4);
      if (mapH <= v.h) cy = mapH / 2; else cy = U.clamp(cy, v.h / 2 - 6, mapH - v.h / 2 + 6);
      return [cx, cy];
    }
    function origin() { const v = viewRect(); return [v.x + v.w / 2 - camX, v.y + v.h / 2 - camY]; }
    const tc = (t) => { const [x, y] = xy(t); return [x * T + T / 2, y * T + T / 2]; };
    function tileAt(px, py) {
      const [ox, oy] = origin();
      const x = Math.floor((px - ox) / T), y = Math.floor((py - oy) / T);
      return x >= 0 && y >= 0 && x < W && y < H ? y * W + x : -1;
    }
    cv.onresize = () => { layout(); measure(); dark = null; if (obs) sizeObs(); };

    /* ---------- 지형 캐시 ---------- */
    function drawTree(c, cx, cy, t, P) {
      const sd = st.sd, se = st.se, th = st.th;
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(cx + T * 0.08, cy + T * 0.2, T * 0.46, T * 0.3, 0, 0, TAU); c.fill();
      if (se === 3 && th !== 2) { // 겨울 전나무
        c.fillStyle = '#4a3020'; c.fillRect(cx - T * 0.05, cy + T * 0.12, T * 0.1, T * 0.24);
        for (let i = 0; i < 3; i++) {
          const yb = cy + T * (0.18 - i * 0.18), hw = T * (0.4 - i * 0.1);
          c.fillStyle = i % 2 ? P.t2 : P.t1; c.beginPath(); c.moveTo(cx - hw, yb); c.lineTo(cx, yb - T * 0.3); c.lineTo(cx + hw, yb); c.closePath(); c.fill();
          c.fillStyle = 'rgba(250,252,255,.92)'; c.beginPath(); c.moveTo(cx - hw * 0.6, yb - T * 0.1); c.lineTo(cx, yb - T * 0.3); c.lineTo(cx + hw * 0.55, yb - T * 0.12); c.quadraticCurveTo(cx, yb - T * 0.06, cx - hw * 0.6, yb - T * 0.1); c.fill();
        }
        return;
      }
      if (th === 2) { c.fillStyle = '#ece8dc'; c.fillRect(cx - T * 0.06, cy - T * 0.12, T * 0.12, T * 0.48); c.fillStyle = '#2a2a2a'; c.fillRect(cx - T * 0.06, cy + T * 0.04, T * 0.07, T * 0.03); c.fillRect(cx - T * 0.01, cy + T * 0.2, T * 0.07, T * 0.025); }
      else { c.fillStyle = '#5a3b22'; c.fillRect(cx - T * 0.06, cy, T * 0.12, T * 0.36); }
      if (se === 3) { // 겨울 자작나무: 앙상한 가지 + 눈
        c.strokeStyle = '#d9d4c8'; c.lineWidth = Math.max(1, T * 0.03); c.lineCap = 'round';
        for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * 0.45, l = T * (0.26 + hr(sd, t * 7 + i) * 0.14), y = cy - T * 0.06; c.beginPath(); c.moveTo(cx, y); c.lineTo(cx + Math.cos(a) * l, y + Math.sin(a) * l); c.stroke(); c.fillStyle = '#fbfdff'; c.beginPath(); c.arc(cx + Math.cos(a) * l, y + Math.sin(a) * l, T * 0.04, 0, TAU); c.fill(); }
        return;
      }
      let cols = [P.t1, P.t2, P.t3];
      if (se === 0) cols = [P.t1, P.t2, P.t2];
      if (se === 2) { const h = hr(sd, t * 9); cols = h < 0.33 ? [P.t1, P.t1, P.t2] : h < 0.66 ? [P.t2, P.t2, P.t3] : [shade(P.t3, -30), P.t3, P.t3]; }
      if (th === 2) cols = cols.map((x) => (x.charAt(0) === '#' ? shade(x, 18) : x));
      const blobs = [[0, -0.12, 0.42, 0], [-0.14, -0.06, 0.3, 1], [0.13, -0.1, 0.28, 1], [0.02, -0.24, 0.26, 2], [-0.1, -0.2, 0.16, 2]];
      for (const [bx, by, br, ci] of blobs) {
        const j = hr(sd, t * 3 + bx * 10) * 0.06;
        c.fillStyle = cols[ci]; c.beginPath(); c.arc(cx + (bx + j) * T, cy + by * T, br * T, 0, TAU); c.fill();
      }
      if (se === 0) { // 벚꽃 송이
        for (let i = 0; i < 9; i++) { c.fillStyle = i % 3 ? P.t3 : '#fff2f6'; c.beginPath(); c.arc(cx + (hr(sd + 2, t * 11 + i) - 0.5) * T * 0.7, cy - T * 0.12 + (hr(sd + 3, t * 11 + i) - 0.5) * T * 0.5, T * 0.05, 0, TAU); c.fill(); }
      } else if (se === 1) { c.fillStyle = 'rgba(200,240,140,.25)'; c.beginPath(); c.arc(cx - T * 0.08, cy - T * 0.26, T * 0.12, 0, TAU); c.fill(); }
    }
    function buildTerrain() {
      const d = cv.dpr || 1;
      if (!terr) terr = document.createElement('canvas');
      terr.width = Math.round(mapW * d); terr.height = Math.round(mapH * d);
      const c = terr.getContext('2d'); c.setTransform(d, 0, 0, d, 0, 0);
      const P = SPAL[st.se], sd = st.sd, se = st.se;
      c.fillStyle = P.g; c.fillRect(0, 0, mapW, mapH);
      for (let t = 0; t < N; t++) {
        const [x, y] = xy(t), X = x * T, Y = y * T;
        c.fillStyle = hr(sd, t) < 0.5 ? P.g : P.g2; c.globalAlpha = 0.7; c.fillRect(X, Y, T, T); c.globalAlpha = 1;
        if (st.th === 0 && se !== 3 && hr(sd + 8, t) < 0.4) { c.fillStyle = 'rgba(30,70,30,.25)'; c.beginPath(); c.ellipse(X + T * hr(sd, t * 5), Y + T * hr(sd, t * 6), T * 0.3, T * 0.18, 0, 0, TAU); c.fill(); }
        for (let i = 0; i < 6; i++) {
          const lx = X + hr(sd + i, t * 11) * T, ly = Y + hr(sd + i, t * 13) * T;
          c.fillStyle = P.fleck[i % 3];
          c.beginPath(); c.ellipse(lx, ly, T * 0.05, T * 0.025, hr(sd, t * 7 + i) * 3, 0, TAU); c.fill();
        }
        if (st.m[t] !== '.' || hr(sd + 21, t) > 0.38) continue;
        const dx = X + T * (0.2 + hr(sd + 22, t) * 0.6), dy = Y + T * (0.2 + hr(sd + 23, t) * 0.6);
        if (se === 0) { const pc = ['#fff4f8', '#f8d24a', '#f3a1c4'][t % 3]; c.fillStyle = pc; for (let i = 0; i < 5; i++) { const a = i / 5 * TAU; c.beginPath(); c.arc(dx + Math.cos(a) * T * 0.04, dy + Math.sin(a) * T * 0.04, T * 0.03, 0, TAU); c.fill(); } c.fillStyle = '#f2b440'; c.beginPath(); c.arc(dx, dy, T * 0.022, 0, TAU); c.fill(); }
        else if (se === 1) { c.strokeStyle = 'rgba(25,60,20,.7)'; c.lineWidth = Math.max(1, T * 0.025); for (let i = -1; i <= 1; i++) { c.beginPath(); c.moveTo(dx + i * T * 0.03, dy + T * 0.05); c.quadraticCurveTo(dx + i * T * 0.06, dy - T * 0.02, dx + i * T * 0.08, dy - T * 0.07); c.stroke(); } }
        else if (se === 2) { for (let i = 0; i < 2; i++) { c.fillStyle = ['#d0612a', '#e8a83c', '#a8361f'][(t + i) % 3]; c.save(); c.translate(dx + i * T * 0.12, dy); c.rotate(hr(sd, t + i) * 3); c.beginPath(); c.ellipse(0, 0, T * 0.08, T * 0.04, 0, 0, TAU); c.fill(); c.strokeStyle = 'rgba(80,30,10,.5)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-T * 0.07, 0); c.lineTo(T * 0.07, 0); c.stroke(); c.restore(); } }
        else { c.fillStyle = 'rgba(255,255,255,.9)'; c.beginPath(); c.ellipse(dx, dy, T * 0.14, T * 0.05, 0, 0, TAU); c.fill(); c.strokeStyle = 'rgba(90,70,50,.6)'; c.lineWidth = 1; c.beginPath(); c.moveTo(dx - T * 0.1, dy - T * 0.06); c.lineTo(dx + T * 0.06, dy - T * 0.12); c.stroke(); }
      }
      // 오두막 앞 길
      const [hx, hy] = tc(CAB);
      const pg = c.createRadialGradient(hx, hy - T * 0.4, T * 0.3, hx, hy - T * 0.4, T * 2.2);
      const pathC = se === 3 ? '170,180,195' : '150,110,60';
      pg.addColorStop(0, 'rgba(' + pathC + ',.55)'); pg.addColorStop(1, 'rgba(' + pathC + ',0)');
      c.fillStyle = pg; c.fillRect(hx - T * 2.5, hy - T * 3, T * 5, T * 3.5);
      for (let t = 0; t < N; t++) {
        const ch = st.m[t], [cx, cy] = tc(t);
        if (ch === '~' || ch === '=') {
          const X = cx - T / 2, Y = cy - T / 2;
          const wg = c.createLinearGradient(X, Y, X, Y + T); wg.addColorStop(0, P.w1); wg.addColorStop(1, P.w2);
          c.fillStyle = wg; c.fillRect(X - 0.5, Y - 0.5, T + 1, T + 1);
          if (se === 3) { // 언 개울: 금 간 얼음
            c.strokeStyle = 'rgba(255,255,255,.85)'; c.lineWidth = 1.2;
            c.beginPath(); c.moveTo(X + T * 0.1, Y + T * 0.3); c.lineTo(X + T * 0.4, Y + T * 0.45); c.lineTo(X + T * 0.55, Y + T * 0.3); c.lineTo(X + T * 0.85, Y + T * 0.55); c.stroke();
            c.fillStyle = 'rgba(255,255,255,.4)'; c.beginPath(); c.ellipse(X + T * 0.3, Y + T * 0.7, T * 0.18, T * 0.05, -0.3, 0, TAU); c.fill();
          } else {
            c.strokeStyle = 'rgba(200,235,250,.35)'; c.lineWidth = 1.2;
            for (let i = 0; i < 3; i++) { const yy = Y + T * (0.25 + i * 0.25); c.beginPath(); c.moveTo(X + T * 0.15, yy); c.quadraticCurveTo(X + T * 0.4, yy - 3, X + T * 0.6, yy); c.stroke(); }
          }
          if (ch === '=') for (let i = 0; i < 3; i++) {
            const sx = X + T * (0.22 + i * 0.28), sy = cy + (i % 2 ? -T * 0.12 : T * 0.1);
            c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(sx + 1, sy + 2, T * 0.14, T * 0.1, 0, 0, TAU); c.fill();
            c.fillStyle = '#9a9a8c'; c.beginPath(); c.ellipse(sx, sy, T * 0.14, T * 0.1, 0, 0, TAU); c.fill();
            c.fillStyle = se === 3 ? 'rgba(255,255,255,.85)' : 'rgba(255,255,255,.25)'; c.beginPath(); c.ellipse(sx - T * 0.03, sy - T * 0.03, T * 0.08, T * 0.045, 0, 0, TAU); c.fill();
          }
        }
      }
      for (let t = 0; t < N; t++) {
        const ch = st.m[t], [cx, cy] = tc(t);
        if (ch === 'b') {
          for (let i = 0; i < 4; i++) {
            const bx = cx + (hr(sd, t * 5 + i) - 0.5) * T * 0.5, by = cy + (hr(sd + 1, t * 5 + i) - 0.5) * T * 0.4;
            c.fillStyle = i % 2 ? P.bu : shade(P.bu, -20); c.beginPath(); c.arc(bx, by, T * 0.22, 0, TAU); c.fill();
            if (se === 3) { c.fillStyle = 'rgba(255,255,255,.9)'; c.beginPath(); c.ellipse(bx, by - T * 0.12, T * 0.16, T * 0.07, 0, 0, TAU); c.fill(); }
          }
          c.fillStyle = P.berry;
          for (let i = 0; i < 4; i++) { c.beginPath(); c.arc(cx + (hr(sd + 3, t + i) - 0.5) * T * 0.6, cy + (hr(sd + 4, t + i) - 0.5) * T * 0.5, T * 0.035, 0, TAU); c.fill(); }
        } else if (ch === 'r') {
          c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(cx + 2, cy + T * 0.14, T * 0.36, T * 0.18, 0, 0, TAU); c.fill();
          c.fillStyle = '#8b8b80'; c.beginPath();
          c.moveTo(cx - T * 0.36, cy + T * 0.12); c.lineTo(cx - T * 0.28, cy - T * 0.16); c.lineTo(cx - T * 0.02, cy - T * 0.3); c.lineTo(cx + T * 0.26, cy - T * 0.18); c.lineTo(cx + T * 0.36, cy + T * 0.1); c.lineTo(cx + T * 0.1, cy + T * 0.2); c.closePath(); c.fill();
          c.fillStyle = se === 3 ? 'rgba(255,255,255,.95)' : 'rgba(255,255,255,.22)'; c.beginPath(); c.moveTo(cx - T * 0.27, cy - T * 0.13); c.lineTo(cx - T * 0.02, cy - T * 0.29); c.lineTo(cx + T * 0.25, cy - T * 0.17); c.quadraticCurveTo(cx, cy - T * 0.08, cx - T * 0.27, cy - T * 0.13); c.fill();
          if (se !== 3) { c.fillStyle = 'rgba(110,150,70,.6)'; c.beginPath(); c.ellipse(cx + T * 0.12, cy - T * 0.14, T * 0.1, T * 0.05, 0.3, 0, TAU); c.fill(); }
        } else if (ch === 'H') drawCabin(c, cx, cy, se);
      }
      for (let t = 0; t < N; t++) if (st.m[t] === 'T') { const [cx, cy] = tc(t); drawTree(c, cx, cy, t, P); }
      terrKey = st.sd + ':' + T;
    }
    function drawCabin(c, cx, cy, se) {
      const s = T;
      c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.ellipse(cx + 2, cy + s * 0.36, s * 0.5, s * 0.12, 0, 0, TAU); c.fill();
      c.fillStyle = '#8a5a34'; c.fillRect(cx - s * 0.38, cy - s * 0.08, s * 0.76, s * 0.44);
      c.strokeStyle = 'rgba(50,30,15,.6)'; c.lineWidth = 1;
      for (let i = 1; i < 4; i++) { c.beginPath(); c.moveTo(cx - s * 0.38, cy - s * 0.08 + i * s * 0.11); c.lineTo(cx + s * 0.38, cy - s * 0.08 + i * s * 0.11); c.stroke(); }
      c.fillStyle = '#7b2f2a'; c.beginPath(); c.moveTo(cx - s * 0.48, cy - s * 0.06); c.lineTo(cx, cy - s * 0.46); c.lineTo(cx + s * 0.48, cy - s * 0.06); c.closePath(); c.fill();
      c.fillStyle = '#5b211e'; c.fillRect(cx + s * 0.16, cy - s * 0.42, s * 0.1, s * 0.18);
      if (se === 3) { c.fillStyle = '#f8fbff'; c.beginPath(); c.moveTo(cx - s * 0.5, cy - s * 0.05); c.lineTo(cx, cy - s * 0.47); c.lineTo(cx + s * 0.5, cy - s * 0.05); c.lineTo(cx + s * 0.4, cy - s * 0.1); c.lineTo(cx, cy - s * 0.36); c.lineTo(cx - s * 0.4, cy - s * 0.1); c.closePath(); c.fill(); }
      c.fillStyle = '#ffd27a'; c.fillRect(cx - s * 0.28, cy + s * 0.02, s * 0.16, s * 0.13);
      c.fillStyle = '#4a2c16'; c.fillRect(cx + s * 0.05, cy + s * 0.06, s * 0.16, s * 0.3);
      if (se === 0) { c.fillStyle = '#c0533a'; c.fillRect(cx - s * 0.36, cy + s * 0.28, s * 0.1, s * 0.08); c.fillStyle = '#f3a1c4'; c.beginPath(); c.arc(cx - s * 0.31, cy + s * 0.26, s * 0.05, 0, TAU); c.fill(); }
      if (se === 2) { c.fillStyle = '#e07a20'; c.beginPath(); c.ellipse(cx - s * 0.3, cy + s * 0.32, s * 0.08, s * 0.06, 0, 0, TAU); c.fill(); c.fillStyle = '#3a6020'; c.fillRect(cx - s * 0.31, cy + s * 0.24, s * 0.02, s * 0.03); }
    }

    /* ---------- 안개 캐시 ---------- */
    function dispFog() {
      if (!anim) return st.fg;
      const el = time - anim.t0;
      let out = null;
      for (const t in anim.rev) if (anim.rev[t] > el) { if (!out) out = st.fg.split(''); out[t] = '0'; }
      return out ? out.join('') : st.fg;
    }
    function buildFog(f) {
      const d = cv.dpr || 1;
      if (!fogC) fogC = document.createElement('canvas');
      fogC.width = Math.round(mapW * d); fogC.height = Math.round(mapH * d);
      const c = fogC.getContext('2d'); c.setTransform(d, 0, 0, d, 0, 0);
      c.clearRect(0, 0, mapW, mapH);
      const fc = SPAL[st.se].fog;
      for (let t = 0; t < N; t++) {
        if (f[t] === '1') continue;
        const [cx, cy] = tc(t);
        c.fillStyle = 'rgba(' + fc + ',.97)'; c.fillRect(cx - T / 2 - 0.5, cy - T / 2 - 0.5, T + 1, T + 1);
        for (let i = 0; i < 3; i++) {
          const px = cx + (hr(st.sd + 40, t * 3 + i) - 0.5) * T * 0.7, py = cy + (hr(st.sd + 41, t * 3 + i) - 0.5) * T * 0.7, r = T * (0.5 + hr(st.sd + 42, t + i) * 0.3);
          const g = c.createRadialGradient(px, py, r * 0.2, px, py, r);
          g.addColorStop(0, st.se === 3 ? 'rgba(200,212,230,.9)' : 'rgba(244,246,248,.9)'); g.addColorStop(1, 'rgba(' + fc + ',0)');
          c.fillStyle = g; c.beginPath(); c.arc(px, py, r, 0, TAU); c.fill();
        }
      }
      fogKey = f + ':' + T;
    }

    /* ---------- 그리기 ---------- */
    function tokenPos(seat) {
      const pa = anim && anim.paths[seat];
      if (pa) {
        const k = U.clamp((time - anim.t0 - anim.walkAt) * anim.spd, 0, pa.length - 1);
        const i = Math.min(pa.length - 1, Math.floor(k)), j = Math.min(pa.length - 1, i + 1), f = k - i;
        const a = tc(pa[i]), b = tc(pa[j]);
        return [U.lerp(a[0], b[0], f), U.lerp(a[1], b[1], f) - Math.sin(f * Math.PI) * T * 0.14];
      }
      let p = tc(st.ps[seat]);
      const same = [];
      for (let i = 0; i < st.n; i++) if (!(anim && anim.paths[i]) && st.ps[i] === st.ps[seat]) same.push(i);
      if (same.length > 1) { const k = same.indexOf(seat), a = k / same.length * TAU - Math.PI / 2; p = [p[0] + Math.cos(a) * T * 0.2, p[1] + Math.sin(a) * T * 0.16]; }
      return p;
    }
    function drawForager(x, y, col, ring, seat) {
      const r = T * 0.2;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + 1, y + r * 0.95, r * 0.95, r * 0.4, 0, 0, TAU); ctx.fill();
      if (ring) { ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(x, y, r + 6, 0, TAU); ctx.stroke(); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, r + 6 + Math.sin(time * 4) * 1.2, 0, TAU); ctx.stroke(); }
      ctx.fillStyle = col; ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y + r * 0.2, r, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#f1d7b5'; ctx.beginPath(); ctx.arc(x, y - r * 0.15, r * 0.48, 0, TAU); ctx.fill();
      ctx.fillStyle = st.se === 3 ? '#c8423a' : '#7a5230'; ctx.beginPath(); ctx.ellipse(x, y - r * 0.42, r * 0.75, r * 0.18, 0, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(x - r * 0.42, y - r * 0.45); ctx.quadraticCurveTo(x, y - r * 1.25, x + r * 0.42, y - r * 0.45); ctx.fill();
      if (st.se === 3) { ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y - r * 0.98, r * 0.13, 0, TAU); ctx.fill(); }
      ctx.fillStyle = '#b8864a'; ctx.strokeStyle = '#5a3a1c'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(x + r * 0.55, y + r * 0.2); ctx.lineTo(x + r * 1.25, y + r * 0.2); ctx.lineTo(x + r * 1.1, y + r * 0.8); ctx.lineTo(x + r * 0.7, y + r * 0.8); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.arc(x + r * 0.9, y + r * 0.2, r * 0.3, Math.PI, TAU); ctx.stroke();
      const bk = st.bk[seat];
      for (let i = 0; i < bk.length; i++) { ctx.fillStyle = SP[bk[i]].c; ctx.beginPath(); ctx.arc(x + r * (0.7 + (i % 3) * 0.2), y + r * (0.12 - Math.floor(i / 3) * 0.16), r * 0.12, 0, TAU); ctx.fill(); }
      if (fx.dizzy[seat] > time || (!anim && !st.done && st.pl[seat] === 0)) { ctx.fillStyle = '#c6f27a'; for (let i = 0; i < 3; i++) { const a = time * 3 + i * TAU / 3; star(ctx, x + Math.cos(a) * r * 1.1, y - r * 1.05 + Math.sin(a) * r * 0.3, r * 0.22); } }
      if (!st.done && !anim && st.pl[seat] && st.n > 1) { // 계획 냈음
        ctx.fillStyle = '#2f6b45'; ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x - r * 0.9, y - r * 0.9, r * 0.42, 0, TAU); ctx.fill(); ctx.stroke();
        ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x - r * 1.08, y - r * 0.9); ctx.lineTo(x - r * 0.94, y - r * 0.75); ctx.lineTo(x - r * 0.7, y - r * 1.06); ctx.stroke();
      }
    }
    function drawSquirrel(x, y) {
      const s = T * 0.3, bob = Math.abs(Math.sin(time * 4)) * s * 0.15;
      y -= bob;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(x, y + s * 0.6 + bob, s * 0.7, s * 0.2, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#c0742e'; ctx.beginPath(); ctx.ellipse(x - s * 0.55, y - s * 0.2, s * 0.42, s * 0.7, -0.5, 0, TAU); ctx.fill();
      ctx.fillStyle = '#d68a40'; ctx.beginPath(); ctx.ellipse(x - s * 0.5, y - s * 0.3, s * 0.25, s * 0.5, -0.5, 0, TAU); ctx.fill();
      ctx.fillStyle = '#b06628'; ctx.beginPath(); ctx.ellipse(x, y + s * 0.15, s * 0.38, s * 0.45, 0, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.arc(x + s * 0.18, y - s * 0.35, s * 0.28, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(x + s * 0.1, y - s * 0.55); ctx.lineTo(x + s * 0.16, y - s * 0.82); ctx.lineTo(x + s * 0.28, y - s * 0.58); ctx.fill();
      ctx.fillStyle = '#f3dcb8'; ctx.beginPath(); ctx.ellipse(x + s * 0.08, y + s * 0.2, s * 0.18, s * 0.28, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#1a1210'; ctx.beginPath(); ctx.arc(x + s * 0.27, y - s * 0.4, s * 0.06, 0, TAU); ctx.fill();
      ctx.fillStyle = '#7a4a22'; ctx.beginPath(); ctx.ellipse(x + s * 0.3, y + s * 0.02, s * 0.1, s * 0.08, 0, 0, TAU); ctx.fill();
    }
    function drawBoar(x, y, a) {
      const s = T * 0.36;
      ctx.save(); ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + 2, y + s * 0.55, s * 1.05, s * 0.3, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#4a3426'; ctx.beginPath(); ctx.ellipse(x - s * 0.1, y, s * 0.95, s * 0.6, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#2c1d14'; ctx.lineWidth = 1.5;
      for (let i = -3; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(x + i * s * 0.2, y - s * 0.52); ctx.lineTo(x + i * s * 0.2 - s * 0.05, y - s * 0.72); ctx.stroke(); }
      ctx.fillStyle = '#5a4030'; ctx.beginPath(); ctx.ellipse(x + s * 0.75, y + s * 0.05, s * 0.42, s * 0.36, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#b08a78'; ctx.beginPath(); ctx.ellipse(x + s * 1.1, y + s * 0.12, s * 0.16, s * 0.14, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#f4eee0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + s * 0.95, y + s * 0.26); ctx.quadraticCurveTo(x + s * 1.05, y + s * 0.05, x + s * 0.9, y - s * 0.05); ctx.stroke();
      ctx.fillStyle = '#e8d070'; ctx.beginPath(); ctx.arc(x + s * 0.72, y - s * 0.08, s * 0.07, 0, TAU); ctx.fill();
      ctx.fillStyle = '#3a281c'; ctx.beginPath(); ctx.moveTo(x + s * 0.5, y - s * 0.25); ctx.lineTo(x + s * 0.55, y - s * 0.55); ctx.lineTo(x + s * 0.7, y - s * 0.28); ctx.fill();
      ctx.restore();
    }
    function boarPos() {
      if (fx.boar) {
        const B = fx.boar, pts = [B.from].concat(B.path), f = Math.min(pts.length - 1, B.t * (pts.length - 1));
        const i = Math.min(pts.length - 2, Math.floor(f)), a = tc(pts[Math.max(0, i)]), b = tc(pts[Math.min(pts.length - 1, i + 1)]), g = f - i;
        if (pts.length === 1) return a;
        return [U.lerp(a[0], b[0], g), U.lerp(a[1], b[1], g)];
      }
      return st.bo >= 0 ? tc(st.bo) : null;
    }
    function focusSeat() { const p = planSeat(); if (p >= 0) return p; const m = api.mySeats(); return m.length ? m[0] : 0; }
    function drawAmbient(v, ph) {
      const se = st.se, w = cv.w;
      if (se === 0) {
        for (let i = 0; i < 14; i++) { const x = (hr(11, i) * w + time * (18 + hr(12, i) * 14)) % w, y = v.y + ((hr(13, i) * v.h + time * (22 + hr(14, i) * 16)) % v.h); ctx.fillStyle = i % 3 ? 'rgba(246,190,210,.85)' : 'rgba(255,244,248,.85)'; ctx.beginPath(); ctx.ellipse(x, y, 3.2, 1.8, time * 2 + i, 0, TAU); ctx.fill(); }
      } else if (se === 1 && ph < 2) {
        for (let i = 0; i < 8; i++) { const x = (hr(21, i) * w + Math.sin(time * 0.6 + i) * 20 + time * 8) % w, y = v.y + ((hr(22, i) * v.h - time * 10) % v.h + v.h) % v.h; ctx.fillStyle = 'rgba(255,255,240,.6)'; ctx.beginPath(); ctx.arc(x, y, 1.6, 0, TAU); ctx.fill(); }
      } else if (se === 2) {
        for (let i = 0; i < 12; i++) { const x = (hr(31, i) * w + Math.sin(time + i) * 24) % w, y = v.y + ((hr(32, i) * v.h + time * (26 + hr(33, i) * 18)) % v.h); ctx.fillStyle = ['rgba(214,100,40,.9)', 'rgba(232,170,60,.9)', 'rgba(170,54,31,.9)'][i % 3]; ctx.beginPath(); ctx.ellipse(x, y, 4, 2, time * 1.6 + i, 0, TAU); ctx.fill(); }
      } else if (se === 3) {
        ctx.fillStyle = 'rgba(255,255,255,.85)';
        for (let i = 0; i < 36; i++) { const x = (hr(41, i) * w + Math.sin(time * 0.8 + i) * 12) % w, y = v.y + ((hr(42, i) * v.h + time * (18 + hr(43, i) * 22)) % v.h); ctx.beginPath(); ctx.arc(x, y, 1 + hr(44, i) * 1.6, 0, TAU); ctx.fill(); }
      }
      if (ph >= 2 && se !== 3) { // 반딧불
        const n = se === 1 ? 16 : 8;
        ctx.fillStyle = 'rgba(230,255,150,.85)';
        for (let i = 0; i < n; i++) { const x = (hr(st.sd, i) * w + Math.sin(time * 0.5 + i) * 30), y = v.y + hr(st.sd, i + 50) * v.h + Math.cos(time * 0.7 + i * 2) * 20; ctx.globalAlpha = 0.35 + 0.45 * Math.sin(time * 3 + i); ctx.beginPath(); ctx.arc(x, y, 1.9, 0, TAU); ctx.fill(); }
        ctx.globalAlpha = 1;
      }
    }
    function draw(dt) {
      if (!st) return;
      if (terrKey !== st.sd + ':' + T) buildTerrain();
      const df = dispFog();
      if (fogKey !== df + ':' + T) buildFog(df);
      const ph = phase(st), v = viewRect();
      const fs = focusSeat();
      if (!manual) {
        const p = tokenPos(fs), [tx, ty] = clampCam(p[0], p[1]), k = 1 - Math.exp(-dt * 6);
        camX += (tx - camX) * k; camY += (ty - camY) * k;
      } else { const [tx, ty] = clampCam(camX, camY); camX = tx; camY = ty; }
      cv.clear();
      ctx.fillStyle = SPAL[st.se].out; ctx.fillRect(0, 0, cv.w, cv.h);
      const [ox, oy] = origin();
      ctx.save(); ctx.translate(ox, oy);
      ctx.drawImage(terr, 0, 0, mapW, mapH);
      { const [hx, hy] = tc(CAB); for (let i = 0; i < 3; i++) { const f = (time * 0.35 + i / 3) % 1; ctx.fillStyle = 'rgba(220,220,225,' + (0.35 * (1 - f)) + ')'; ctx.beginPath(); ctx.arc(hx + T * 0.21 + Math.sin(f * 6 + i) * T * 0.06, hy - T * 0.45 - f * T * 0.6, T * (0.06 + f * 0.1), 0, TAU); ctx.fill(); } }
      // 갈 수 있는 칸 + 계획 경로
      const ps = planSeat();
      if (ps >= 0 && reachD && !pending && !obs && !locked()) {
        const si = stepsInfo(), budget = si.max - si.ta;
        for (let t = 0; t < N; t++) {
          if (t === st.ps[ps] || reachD[t] > budget) continue;
          const [cx, cy] = tc(t);
          ctx.fillStyle = 'rgba(227,174,69,.15)'; ctx.fillRect(cx - T / 2 + 2, cy - T / 2 + 2, T - 4, T - 4);
          ctx.strokeStyle = 'rgba(227,174,69,' + (0.5 + 0.25 * Math.sin(time * 3)) + ')'; ctx.lineWidth = 1.5;
          ctx.strokeRect(cx - T / 2 + 2.5, cy - T / 2 + 2.5, T - 5, T - 5);
        }
      }
      if (ps >= 0 && plan.to >= 0 && reachD) {
        const pk = reachFor + ':' + plan.to;
        if (pathKey !== pk) { pathKey = pk; pathC = pathTo(reach(st, st.ps[ps]), st.ps[ps], plan.to); }
        const pa = pathC;
        if (pa) {
          ctx.strokeStyle = 'rgba(255,226,140,.95)'; ctx.lineWidth = 3.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.setLineDash([2, 7]); ctx.lineDashOffset = -time * 14;
          ctx.beginPath(); pa.forEach((t, i) => { const [x, y] = tc(t); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }); ctx.stroke(); ctx.setLineDash([]);
          const [dx, dy] = tc(plan.to);
          ctx.fillStyle = 'rgba(255,214,110,.28)'; ctx.fillRect(dx - T / 2 + 2, dy - T / 2 + 2, T - 4, T - 4);
          ctx.strokeStyle = '#ffd36a'; ctx.lineWidth = 2.5; ctx.strokeRect(dx - T / 2 + 2, dy - T / 2 + 2, T - 4, T - 4);
        }
      }
      // 버섯
      for (const m of st.ms) {
        const t = m[0]; if (df[t] !== '1') continue;
        const k = dec(st, m), [cx, cy] = tc(t);
        let sc = 1; const b = fx.born[t]; if (b != null) { const a = (time - b) * 4; sc = a < 0 ? 0 : a >= 1 ? 1 : 1 + Math.sin(a * Math.PI) * 0.3 * (1 - a) - (1 - a) * 0.4; if (a >= 1.5) delete fx.born[t]; }
        if (sc <= 0) continue;
        drawMush(ctx, k, cx, cy + T * 0.3, T * 0.5 * sc, { icon: true, turn: m[2] & 1 ? 1 : 0, dig: m[2] & 8 ? 1 : 0 });
        if (m[2]) { let i = 0; for (const tl of TOOLS) if (m[2] & tl.b) { ctx.fillStyle = tl.col; ctx.strokeStyle = 'rgba(20,14,10,.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx + T * 0.36, cy - T * 0.36 + i * T * 0.13, T * 0.055, 0, TAU); ctx.fill(); ctx.stroke(); i++; } }
      }
      if (st.sq >= 0 && df[st.sq] === '1') { const [x, y] = tc(st.sq); drawSquirrel(x, y + T * 0.05); }
      for (let i = 0; i < st.n; i++) if (i !== ps) { const [x, y] = tokenPos(i); drawForager(x, y, colOf(i), false, i); }
      if (ps >= 0) { const [x, y] = tokenPos(ps); drawForager(x, y, colOf(ps), true, ps); }
      if (ps >= 0 && plan.to >= 0) { // 갈 곳 깃발
        const [dx0, dy0] = tc(plan.to), dx = dx0 + T * 0.3, dy = dy0 - T * 0.05, wv = Math.sin(time * 5) * T * 0.03;
        ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(dx, dy + T * 0.3); ctx.lineTo(dx, dy - T * 0.34); ctx.stroke();
        ctx.fillStyle = colOf(ps); ctx.beginPath(); ctx.moveTo(dx, dy - T * 0.34); ctx.quadraticCurveTo(dx + T * 0.14, dy - T * 0.3 + wv, dx + T * 0.28, dy - T * 0.24); ctx.lineTo(dx, dy - T * 0.12); ctx.closePath(); ctx.fill(); ctx.stroke();
      }
      ctx.drawImage(fogC, 0, 0, mapW, mapH);
      const bp = boarPos();
      if (bp) { const bt = st.bo; drawBoar(bp[0], bp[1] + T * 0.05, bt >= 0 && df[bt] !== '1' ? 0.75 : 1); }
      ctx.restore();
      // 어둠
      if (ph >= 2) {
        if (!dark || dark.width !== cv.cv.width || dark.height !== cv.cv.height) { dark = document.createElement('canvas'); dark.width = cv.cv.width; dark.height = cv.cv.height; }
        const d = dark.getContext('2d'), dp = cv.dpr || 1;
        d.setTransform(dp, 0, 0, dp, 0, 0);
        d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, cv.w, cv.h);
        d.fillStyle = ph === 2 ? 'rgba(46,18,60,.42)' : 'rgba(6,10,32,.66)'; d.fillRect(0, 0, cv.w, cv.h);
        d.globalCompositeOperation = 'destination-out';
        const hole = (x, y, r) => { const g = d.createRadialGradient(x, y, r * 0.15, x, y, r); g.addColorStop(0, 'rgba(0,0,0,.95)'); g.addColorStop(1, 'rgba(0,0,0,0)'); d.fillStyle = g; d.beginPath(); d.arc(x, y, r, 0, TAU); d.fill(); };
        for (let i = 0; i < st.n; i++) { const [x, y] = tokenPos(i); hole(ox + x, oy + y, T * (ph === 2 ? 2.1 : 1.7)); }
        { const [x, y] = tc(CAB); hole(ox + x, oy + y, T * 1.6); }
        d.globalCompositeOperation = 'source-over';
        ctx.drawImage(dark, 0, 0, cv.w, cv.h);
        if (ph === 2) { ctx.fillStyle = 'rgba(255,130,60,.07)'; ctx.fillRect(0, 0, cv.w, cv.h); }
        ctx.save(); ctx.translate(ox, oy);
        for (const m of st.ms) {
          const t = m[0]; if (df[t] !== '1') continue;
          const k = dec(st, m); if (!SP[k].glow) continue;
          const [cx, cy] = tc(t), pul = 0.75 + 0.25 * Math.sin(time * 2.4 + t);
          const g = ctx.createRadialGradient(cx, cy, 2, cx, cy, T * 0.6);
          g.addColorStop(0, 'rgba(170,255,210,' + 0.55 * pul + ')'); g.addColorStop(1, 'rgba(170,255,210,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, T * 0.6, 0, TAU); ctx.fill();
          drawMush(ctx, k, cx, cy + T * 0.3, T * 0.5, { icon: true, turn: m[2] & 1 ? 1 : 0, dig: m[2] & 8 ? 1 : 0, glow: true });
        }
        ctx.restore();
      }
      drawAmbient(v, ph);
      // 효과
      ctx.save(); ctx.translate(ox, oy);
      if (fx.trail) {
        const tr = fx.trail, a = (time - tr.t0) / 2.2;
        if (a >= 1) fx.trail = null;
        else {
          const [x1, y1] = tc(tr.from), [x2, y2] = tc(tr.to);
          ctx.strokeStyle = 'rgba(255,214,120,' + (0.9 * (1 - a)) + ')'; ctx.lineWidth = 3; ctx.setLineDash([2, 8]); ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.quadraticCurveTo((x1 + x2) / 2 + T, (y1 + y2) / 2 - T, x2, y2); ctx.stroke(); ctx.setLineDash([]);
          const q = Math.min(1, a * 1.6), qx = (1 - q) * (1 - q) * x1 + 2 * (1 - q) * q * ((x1 + x2) / 2 + T) + q * q * x2, qy = (1 - q) * (1 - q) * y1 + 2 * (1 - q) * q * ((y1 + y2) / 2 - T) + q * q * y2;
          drawSquirrel(qx, qy);
          ctx.strokeStyle = 'rgba(255,214,120,' + (1 - a) + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x2, y2, T * (0.45 + 0.1 * Math.sin(time * 8)), 0, TAU); ctx.stroke();
        }
      }
      for (let i = fx.poofs.length - 1; i >= 0; i--) {
        const p = fx.poofs[i], a = (time - p.t0) / 0.7;
        if (a >= 1) { fx.poofs.splice(i, 1); continue; }
        if (a < 0) continue;
        ctx.fillStyle = p.c.replace('A', String(0.6 * (1 - a)));
        for (let j = 0; j < 5; j++) { const an = j / 5 * TAU + p.t0; ctx.beginPath(); ctx.arc(p.x + Math.cos(an) * T * 0.35 * a, p.y + Math.sin(an) * T * 0.3 * a, T * (0.18 + 0.12 * a), 0, TAU); ctx.fill(); }
      }
      for (let i = fx.bubbles.length - 1; i >= 0; i--) {
        const B = fx.bubbles[i], a = (time - B.t0) / B.dur;
        if (a >= 1) { fx.bubbles.splice(i, 1); continue; }
        if (a < 0) continue;
        drawBubble(B, a, ox, oy, v);
      }
      for (let i = fx.floats.length - 1; i >= 0; i--) {
        const f = fx.floats[i], a = (time - f.t0) / 1.4;
        if (a >= 1) { fx.floats.splice(i, 1); continue; }
        if (a < 0) continue;
        ctx.font = '700 ' + Math.round(T * 0.34) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.globalAlpha = 1 - a * a; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,14,24,.85)'; ctx.strokeText(f.text, f.x, f.y - a * T * 0.8);
        ctx.fillStyle = f.c; ctx.fillText(f.text, f.x, f.y - a * T * 0.8); ctx.globalAlpha = 1;
      }
      ctx.restore();
      if (fx.rain > 0) {
        fx.rain -= dt;
        if (st.se === 3) { // 햇살
          const g = ctx.createLinearGradient(0, v.y, cv.w, v.y + v.h);
          g.addColorStop(0, 'rgba(255,230,150,' + 0.22 * Math.min(1, fx.rain) + ')'); g.addColorStop(1, 'rgba(255,230,150,0)');
          ctx.fillStyle = g; ctx.fillRect(0, v.y, cv.w, v.h);
        } else {
          ctx.strokeStyle = 'rgba(190,215,240,.55)'; ctx.lineWidth = 1.2;
          for (let i = 0; i < 70; i++) {
            const x = (hr(7, i) * cv.w + time * 60) % cv.w, y = v.y + ((hr(9, i) * v.h + time * 520 * (0.7 + hr(3, i) * 0.5)) % v.h);
            ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 3, y + 11); ctx.stroke();
          }
        }
      }
    }
    function drawBubble(B, a, ox, oy, v) {
      const [x, y] = tc(B.tile), R = T * 0.78;
      const bx = U.clamp(x + B.off * R * 1.1, R + 4 - ox, cv.w - R - 4 - ox), by = Math.max(y - T * 1.25, v.y + R + 4 - oy);
      const pop = Math.min(1, a * 6), al = a > 0.85 ? (1 - a) / 0.15 : 1;
      ctx.save(); ctx.globalAlpha = al; ctx.translate(bx, by); ctx.scale(pop, pop);
      ctx.fillStyle = 'rgba(242,233,216,.96)'; ctx.strokeStyle = B.col; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.save(); ctx.beginPath(); ctx.arc(0, 0, R - 3, 0, TAU); ctx.clip();
      ctx.fillStyle = SPAL[st.se].obs[0]; ctx.fillRect(-R, R * 0.35, R * 2, R);
      const pr = Math.min(1, Math.max(0, (a - 0.12) / 0.4)), o = B.o || 0;
      drawMush(ctx, B.k, 0, R * 0.45, R * 0.9, { turn: o & 1 ? pr : 0, dig: o & 8 ? pr : 0, rub: o & 4 ? pr : 0 });
      if (o & 2) drawSmell(ctx, B.k, 0, -R * 0.2, R, pr, time);
      ctx.restore();
      if (B.pk) { ctx.font = '700 ' + Math.round(R * 0.62) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = B.pk === 1 ? '#3aa35a' : '#d9452f'; ctx.fillText(B.pk === 1 ? '✓' : '✕', R * 0.62, -R * 0.55); }
      let i = 0; for (const tl of TOOLS) if (o & tl.b) { ctx.fillStyle = tl.col; ctx.strokeStyle = '#1b1426'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(-R * 0.75 + i * R * 0.34, R * 0.88, R * 0.15, 0, TAU); ctx.fill(); ctx.stroke(); i++; }
      ctx.restore();
    }

    /* ---------- HUD ---------- */
    function renderTop() {
      top.innerHTML = '';
      if (!st) return;
      const ph = phase(st), tight = (st.n >= 4 && cv.w < 420) || (st.n >= 3 && cv.w < 400);
      const icon = ['☀', '☀', '◐', '☾'][ph];
      top.append(L.h('span', { class: 'turn mu-day', title: SEASONS[st.se] + ' · ' + PH[ph], style: { padding: '3px 8px', fontSize: '12px', gap: '4px', borderColor: ph >= 2 ? '#8a6ad0' : '' } },
        L.h('b', { text: SEAS_IC[st.se] }), tight ? '' : SEASONS[st.se] + ' ',
        L.h('b', { text: icon, style: { color: ph >= 2 ? '#c9b6ff' : 'var(--brass)' } }), L.h('b', { class: 'mono', text: Math.min(st.r, st.D) + '/' + st.D })));
      for (let i = 0; i < st.n; i++) {
        const p = api.players[i], done = !st.done && st.pl[i] != null;
        top.append(L.h('span', { class: 'turn', style: { padding: '3px 7px 3px 6px', fontSize: '12px', gap: '4px', maxWidth: tight ? '70px' : st.n >= 4 ? '80px' : '112px', borderColor: done ? '#4fae6a' : '' } },
          L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
          L.h('span', { text: p.name, style: { overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0 } }),
          L.h('b', { class: 'mono', text: String(st.sc[i]), style: { flex: 'none' } }),
          !st.done && st.n > 1 ? L.h('span', { text: st.pl[i] === 0 ? '💫' : done ? '✓' : '…', style: { flex: 'none', color: done ? '#7fdc95' : 'var(--muted)', fontWeight: 700 } }) : null));
      }
    }
    function drawBasket(seat) {
      const c = bkCtx; c.clearRect(0, 0, 102, 30);
      const bk = seat >= 0 ? st.bk[seat] : [];
      for (let i = 0; i < CAP; i++) {
        const x = 1 + i * 20;
        c.fillStyle = i < bk.length ? 'rgba(227,174,69,.18)' : 'rgba(255,255,255,.06)'; c.strokeStyle = 'rgba(227,174,69,.4)'; c.lineWidth = 1;
        rrect(c, x + 0.5, 2.5, 18, 25, 5); c.fill(); c.stroke();
        if (i < bk.length) drawMush(c, bk[i], x + 9.5, 24, 14, {});
      }
      if (seat === plan.seat && seat >= 0) for (let j = 0; j < pickCount() && bk.length + j < CAP; j++) { const x = 1 + (bk.length + j) * 20; c.setLineDash([2, 2]); c.strokeStyle = '#e3ae45'; rrect(c, x + 0.5, 2.5, 18, 25, 5); c.stroke(); c.setLineDash([]); c.fillStyle = '#e3ae45'; c.font = '700 12px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('?', x + 9.5, 15); }
    }
    function rdText(rd) {
      if (!rd) return '';
      if (rd.end) return '밤이 깊었어요. 하루 끝!';
      const a = [];
      if (rd.rain) a.push(st.se === 3 ? '햇살에 눈이 녹아 버섯이 쑥쑥!' : RAIN_NM[st.se] + '가 와서 버섯이 쑥쑥!');
      if (rd.ba != null) a.push('멧돼지가 나타났어요!');
      if (rd.bx != null) a.push('멧돼지가 숲 밖으로 갔어요');
      if (rd.tr) a.push('멧돼지가 버섯을 짓밟았어요');
      if (rd.sq != null) a.push('다람쥐가 나타났어요');
      if (rd.ph === 2) a.push('해 질 녘 — 빛나는 버섯이 보여요');
      if (rd.ph === 3) a.push('밤 — 걸음이 3개로 줄어요');
      return a.join(' · ');
    }
    function sumText(Lr) {
      const parts = [];
      Lr.P.forEach((p, i) => {
        if (!p) return;
        const nm = nameOf(i);
        if (p.z) parts.push(nm + ' 💫쉼');
        for (const e of [p.a, p.b]) { if (!e) continue; if (e[3] === 1) parts.push(nm + ' 🧺' + SP[e[1]].nm); else if (e[3] === 2) parts.push(nm + ' ☠' + SP[e[1]].nm + ' −' + POISON); }
        if (p.g) parts.push(nm + (p.c ? ' 🍲' : ' 💰') + '+' + p.g);
      });
      const r = rdText(Lr.rd);
      return Lr.r + '라운드 · ' + (parts.length ? parts.join(' · ') : '모두 숲을 걸었어요') + (r ? ' · ' + r : '');
    }
    function orderLabel(o) {
      const cnt = {}; for (let i = 1; i < o.length; i++) cnt[o[i]] = (cnt[o[i]] || 0) + 1;
      return Object.keys(cnt).map((k) => SP[k].nm + (cnt[k] > 1 ? '×' + cnt[k] : '')).join(' + ');
    }
    function renderHud() {
      if (!st) return;
      syncPlan();
      renderTop();
      const ps = planSeat(), planning = ps >= 0 && !pending;
      const hs = ps >= 0 ? ps : focusSeat();
      // 걸음
      steps.innerHTML = '';
      if (!st.done) {
        steps.append(L.h('span', { text: '👣', style: { fontSize: '14px' } }));
        const si = planning ? stepsInfo() : { max: stepsFor(st), tools: 0, path: 0 };
        for (let i = 0; i < si.max; i++) {
          const kind = i < si.tools ? 'tool' : i < si.tools + si.path ? 'path' : 'free';
          steps.append(L.h('span', { style: { width: '12px', height: '12px', borderRadius: '50%', display: 'inline-block', boxSizing: 'border-box',
            background: kind === 'tool' ? '#b48ae8' : kind === 'path' ? 'var(--brass)' : 'transparent', border: '1.5px solid ' + (kind === 'tool' ? '#b48ae8' : 'var(--brass)'), opacity: planning || kind !== 'free' ? 1 : 0.6 } }));
        }
      }
      drawBasket(hs);
      // 버섯 카드 (여기 · 갈 곳)
      const full = planning && st.bk[ps].length >= CAP;
      let anyCard = false;
      for (const cd of cards) {
        const m = planning && (cd.slot === 'a' || plan.to >= 0) ? slotMush(cd.slot) : null;
        cd.btn.style.display = m ? 'flex' : 'none';
        if (!m) continue;
        anyCard = true;
        const k = dec(st, m), kb = m[2] | slotBits(cd.slot), c = cd.ctx;
        c.clearRect(0, 0, 44, 44); c.fillStyle = SPAL[st.se].obs[0]; rrect(c, 0, 0, 44, 44, 8); c.fill();
        drawMush(c, k, 22, 39, 26, { turn: kb & 1 ? 1 : 0, dig: kb & 8 ? 1 : 0, rub: kb & 4 ? 1 : 0 });
        const n = PC(kb), pk = slotPick(cd.slot);
        cd.t1.textContent = cd.slot === 'a' ? '📍 지금 선 곳' : '🚩 갈 곳';
        cd.t2.textContent = (pk ? '🧺 담기 ✓' : full && !pk ? '바구니 가득' : '🔍 살펴보기') + (PAIR_OF[k] >= 0 ? ' ' + n + '/4' : '');
        cd.btn.classList.toggle('primary', !!pk); cd.t1.style.color = pk ? 'rgba(30,20,10,.75)' : 'var(--muted)';
        cd.btn.style.borderColor = !pk && n === 0 && PAIR_OF[k] >= 0 ? 'var(--brass)' : '';
      }
      rowC.style.display = anyCard ? 'flex' : 'none';
      // 확정 줄
      const showPlan = planning;
      resetBtn.style.display = showPlan && (plan.p || plan.p2 || plan.to >= 0) ? '' : 'none';
      goBtn.style.display = showPlan ? '' : 'none';
      waitEl.style.display = showPlan ? 'none' : 'flex';
      if (showPlan) {
        const si = stepsInfo(), pc = pickCount();
        goBtn.textContent = '✓ 확정 · ' + (plan.to >= 0 ? (plan.to === CAB ? '오두막으로' : si.path + '걸음 이동') : '제자리') + (pc ? ' · 담기 ' + pc : '');
      } else {
        const done = st.pl.filter((x) => x != null).length;
        waitEl.textContent = st.done ? '하루가 끝났어요' : anim ? '모두 함께 움직여요…' : api.mySeats().some((i) => st.pl[i] === 0) && !pendingMine().length ? '💫 기절해서 이번 라운드는 쉬어요 (' + done + '/' + st.n + ')' : pending || (api.mySeats().length && !pendingMine().length) ? '✓ 계획 완료 · 다른 사람을 기다려요 (' + done + '/' + st.n + ')' : multiLocal() && pendingMine().length ? '다음 사람에게 폰을 넘겨요' : 'AI들이 계획 중… (' + done + '/' + st.n + ')';
      }
      // 안내 줄
      info.innerHTML = '';
      if (planning) {
        const who = multiLocal() ? nameOf(ps) : '내 계획';
        const ma = slotMush('a'), mb = plan.to >= 0 ? slotMush('b') : null, si = stepsInfo();
        const fresh = (m, b) => m && !b && !m[2] && PAIR_OF[dec(st, m)] >= 0;
        let t;
        if (full) t = '바구니가 가득! 오두막 쪽으로 가요';
        else if (fresh(ma, plan.o) && !plan.p && plan.to < 0) t = '선 곳 버섯을 살펴보고, 갈 곳도 골라요';
        else if (plan.to < 0) t = '빛나는 칸을 눌러 갈 곳을 골라요';
        else if (mb && !plan.o2 && !plan.p2 && si.left > 0) t = '갈 곳 버섯도 미리 살펴볼 수 있어요';
        else t = '좋아요! 「확정」을 눌러요';
        info.append(L.h('span', { class: 'dot', style: { '--c': colOf(ps), flex: 'none' } }), L.h('span', { text: who + ' · ' + t, style: { color: 'var(--brass)', overflow: 'hidden', textOverflow: 'ellipsis' } }));
      } else {
        info.append(L.h('span', { text: lineA || THEMES[st.th] + ' · ' + SEASONS[st.se] + ' · 모두 동시에 계획해요', class: lineA ? '' : 'muted', style: { overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: lineA ? 600 : 400 } }));
      }
      requestAnimationFrame(measure);
    }

    /* ---------- 한 폰 여럿: 넘겨주기 ---------- */
    function syncHand() {
      let want = -1;
      if (st && !st.done && !anim && multiLocal()) { const pm = pendingMine(); if (pm.length && !pm.includes(active)) want = pm[0]; }
      const key = want + ':' + (st ? st.sd + ':' + st.r : '');
      if (key === handKey) return;
      handKey = key;
      if (handEl) { handEl.remove(); handEl = null; }
      if (want < 0) return;
      closeObs();
      handEl = L.h('div', { class: 'overlay mu-hand', style: { zIndex: 16 } },
        L.h('div', { class: 'sheet', style: { alignItems: 'center', textAlign: 'center', gap: '10px', maxWidth: '320px' } },
          L.h('span', { class: 'dot', style: { '--c': colOf(want), width: '20px', height: '20px' } }),
          L.h('h2', { text: nameOf(want) }),
          L.h('div', { style: { color: 'var(--brass)', fontWeight: 700 }, text: SEAS_IC[st.se] + ' ' + st.r + '라운드 계획 차례' }),
          L.h('div', { class: 'muted', style: { fontSize: '13px', lineHeight: 1.45 }, text: '폰을 넘겨 주세요. 모두 계획을 마치면 다 같이 움직여요.' }),
          L.h('button', { class: 'btn primary', style: { minHeight: '48px', width: '100%' }, text: '계획 시작', onclick: () => { active = want; api.sfx('click'); handKey = ''; if (handEl) { handEl.remove(); handEl = null; } manual = false; renderHud(); } })));
      root.append(handEl);
    }

    /* ---------- 관찰 미니 게임 ---------- */
    let obsEl = null, obs = null, oCv = null, oCtx = null, oW = 300, oH = 200, obsParts = null;
    function knownBits() { if (!obs) return 0; const mi = mushIdx(st, obs.tile); const b = mi >= 0 ? st.ms[mi][2] : 0; return b | (obs.can ? slotBits(obs.slot) : 0); }
    function openSlot(slot) { const t = slotTile(slot); if (t >= 0 && mushIdx(st, t) >= 0) openObs(t); }
    function closeObs() { if (obsEl) { obsEl.remove(); obsEl = null; obs = null; renderHud(); } }
    function sizeObs() {
      if (!oCv) return;
      oW = Math.max(200, Math.round(oCv.parentNode ? oCv.parentNode.clientWidth : 300) || 300);
      oH = Math.round(U.clamp(cv.h * 0.3, 160, 290));
      oCv.style.height = oH + 'px';
      oCtx = setCanvas(oCv, oW, oH);
    }
    function openObs(tile) {
      const mi = mushIdx(st, tile);
      if (mi < 0) return;
      closeObs(); closeGuide();
      const seat = planSeat();
      const slot = seat >= 0 && !pending ? (st.ps[seat] === tile ? 'a' : plan.to === tile ? 'b' : '') : '';
      const can = !!slot;
      obs = { tile, slot, k: dec(st, st.ms[mi]), can, tool: 0, prog: 0, hold: false, rub: [], ptr: null, flash: {}, lastTick: 0 };
      api.sfx('card');
      const k = obs.k, pi = PAIR_OF[k];
      const head = L.h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap', gap: '8px' } },
        L.h('div', { style: { minWidth: 0 } }, L.h('span', { class: 'label', text: can ? (slot === 'a' ? '📍 지금 선 곳' : '🚩 갈 곳') + ' · 도구 1번에 걸음 1' : '구경하기' }), L.h('h2', { text: can ? '이 버섯은 뭘까?' : '버섯 구경', style: { margin: 0, fontSize: '24px' } })),
        L.h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: closeObs }));
      let pairLine;
      if (pi >= 0) {
        const P = PAIRS[pi];
        pairLine = L.h('div', { style: { fontSize: '12.5px', lineHeight: 1.45 } }, '닮은꼴: ',
          L.h('b', { text: SP[P.e].nm, style: { color: '#7fdc95' } }), ' (식용 ' + SP[P.e].v + '점) ↔ ', L.h('b', { text: SP[P.p].nm, style: { color: '#ff8a70' } }), ' (독 −' + POISON + ')',
          st.gh ? L.h('div', { style: { color: 'var(--brass)' }, text: '🔎 다른 곳: ' + GL[P.d] + (P.d === 'c' ? ' — 그림을 잘 보세요' : ' → 「' + TOOLS.find((x) => x.d === P.d).nm + '」') }) : null);
      } else pairLine = L.h('div', { style: { fontSize: '12.5px' } }, L.h('b', { text: SP[k].nm, style: { color: '#7fdc95' } }), ' — 닮은 독버섯이 없어요 (식용 ' + SP[k].v + '점)');
      const wrap = L.h('div', { style: { position: 'relative', width: '100%', borderRadius: '14px', overflow: 'hidden', touchAction: 'none' } });
      oCv = L.h('canvas', { class: 'mu-obs-cv', style: { width: '100%', display: 'block', touchAction: 'none', cursor: 'pointer' } });
      wrap.append(oCv);
      const instr = L.h('div', { style: { fontSize: '13px', fontWeight: 700, color: 'var(--brass)', minHeight: '18px', textAlign: 'center' } });
      const tools = L.h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '5px' } });
      const toolBtns = TOOLS.map((tl) => {
        const b = L.h('button', { class: 'btn mu-tool', style: { minHeight: '50px', padding: '2px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1px', fontSize: '12px', lineHeight: 1.15 }, onclick: () => selectTool(tl.b) });
        tools.append(b); return b;
      });
      const notes = L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '3px', fontSize: '12px', lineHeight: 1.35, background: 'var(--surface-2)', borderRadius: '10px', padding: '7px 9px' } });
      const bottom = L.h('div', { style: { display: 'flex', gap: '6px' } });
      const pickY = L.h('button', { class: 'btn', style: { flex: '1 1 0', minHeight: '46px', padding: '0 6px', whiteSpace: 'nowrap' }, onclick: () => { if (!slotPick(obs.slot)) togglePick(obs.slot); } });
      const pickN = L.h('button', { class: 'btn', style: { flex: '1 1 0', minHeight: '46px', padding: '0 6px', whiteSpace: 'nowrap' }, text: '✋ 두고 가기', onclick: () => { if (slotPick(obs.slot)) togglePick(obs.slot); } });
      const doneB = L.h('button', { class: 'btn primary', style: { flex: '1 1 0', minHeight: '46px', padding: '0 6px', whiteSpace: 'nowrap' }, text: can ? '지도로 ▸' : '닫기', onclick: closeObs });
      if (can) bottom.append(pickY, pickN, doneB); else bottom.append(doneB);
      obsParts = { instr, toolBtns, notes, pickY, pickN };
      const sh = L.h('div', { class: 'sheet', style: { gap: '7px', padding: '10px 12px', maxHeight: '100%', width: 'min(460px, 100%)' } }, head, pairLine, wrap, instr, tools, notes, bottom);
      obsEl = L.h('div', { class: 'overlay mu-obs', style: { padding: '8px', zIndex: 15 } }, sh);
      obsEl.addEventListener('click', (e) => { if (e.target === obsEl) closeObs(); });
      root.append(obsEl);
      sizeObs();
      // 손짓
      const lp = (e) => { const r = oCv.getBoundingClientRect(); return { x: (e.clientX - r.left) * oW / r.width, y: (e.clientY - r.top) * oH / r.height }; };
      oCv.addEventListener('pointerdown', (e) => {
        if (!obs) return;
        const p = lp(e);
        obs.ptr = { x: p.x, y: p.y, x0: p.x, y0: p.y, t0: performance.now(), moved: 0 };
        if (obs.tool === 2) obs.hold = true;
        try { oCv.setPointerCapture(e.pointerId); } catch (er) {}
      });
      oCv.addEventListener('pointermove', (e) => {
        if (!obs || !obs.ptr || !obs.tool) return;
        const p = lp(e), q = obs.ptr, dd = Math.hypot(p.x - q.x, p.y - q.y);
        q.moved += dd; q.x = p.x; q.y = p.y;
        const g = obsGeom();
        if (obs.tool === 1) obs.prog = Math.max(obs.prog, (q.y0 - p.y) / (oH * 0.32));
        else if (obs.tool === 4) {
          if (Math.abs(p.x - g.mx) < g.S * 0.7 && p.y < g.capY + g.S * 0.4) {
            obs.prog += dd / (oW * 1.4);
            if (obs.rub.length < 30 && dd > 3) obs.rub.push([(p.x - g.mx) / g.S, (p.y - g.capY) / g.S]);
            if (time - obs.lastTick > 0.09) { obs.lastTick = time; api.sfx('tick'); }
          }
        } else if (obs.tool === 8) {
          if (Math.abs(p.x - q.x0) > oW * 0.26 && Math.abs(p.y - q.y0) < oH * 0.3) obs.prog = 1;
        }
        if (obs.prog >= 1) completeTool(obs.tool);
      });
      const up = () => {
        if (!obs || !obs.ptr) return;
        const q = obs.ptr; obs.ptr = null; obs.hold = false;
        if (!obs.tool) { if (obs.can) api.toast('아래 도구를 골라 살펴봐요'); return; }
        if (q.moved < 10 && performance.now() - q.t0 < 400) { obs.prog += 0.34; api.sfx(obs.tool === 2 ? 'whoosh' : 'tick'); }
        if (obs.prog >= 1 || (obs.tool === 1 && obs.prog >= 0.55)) completeTool(obs.tool);
      };
      oCv.addEventListener('pointerup', up);
      oCv.addEventListener('pointercancel', () => { if (obs) { obs.ptr = null; obs.hold = false; } });
      renderObs();
      renderHud();
    }
    function obsGeom() {
      const S = Math.min(oW * 0.42, oH * 0.58), mx = oW * 0.38, gy = oH * 0.86;
      const f = SP[obs.k], stemH = stemHOf(f, S);
      return { S, mx, gy, stemH, capY: gy - stemH - S * 0.2 };
    }
    function selectTool(b) {
      if (!obs) return;
      const tl = TOOLS.find((x) => x.b === b);
      if (knownBits() & b) { api.toast(tl.ic + ' ' + GL[tl.d] + ': ' + groupText(SP[obs.k], tl.d)); return; }
      if (!obs.can) { api.toast('지금 선 곳이나 갈 곳 버섯만 살펴볼 수 있어요'); return; }
      const si = stepsInfo();
      if (si.left < 1 && !(obs.slot === 'a' && plan.to >= 0 && !locked() && si.max - si.tools >= 1)) { api.toast('걸음이 모자라요'); return; }
      if (obs.tool === b) { completeTool(b); return; }   // 한 번 더 누르면 바로
      obs.tool = b; obs.prog = 0; obs.rub = obs.rub || [];
      api.sfx('click');
      renderObs();
    }
    function completeTool(b) {
      if (!obs || !obs.can || (knownBits() & b)) return;
      if (obs.slot === 'a') plan.o |= b; else plan.o2 |= b;
      obs.tool = 0; obs.prog = 0; obs.hold = false; obs.flash[b] = time;
      const SFXS = { 1: ['card', 'bounce'], 2: ['whoosh', 'pop'], 4: ['roll', 'chip'], 8: ['hit', 'pop'] }[b];
      api.sfx(SFXS[0]); setTimeout(() => api.sfx(SFXS[1]), 140);
      api.buzz(15);
      if (stepsInfo().left < 0 && obs.slot === 'a') { plan.to = -1; plan.o2 = 0; plan.p2 = 0; api.toast('걸음이 모자라 가려던 곳을 지웠어요'); }
      renderObs(); renderHud();
    }
    function renderObs() {
      if (!obs || !obsParts) return;
      const kb = knownBits(), f = SP[obs.k], pi = PAIR_OF[obs.k], P = pi >= 0 ? PAIRS[pi] : null;
      const si = obs.can ? stepsInfo() : null;
      obsParts.instr.textContent = obs.tool ? TOOLS.find((x) => x.b === obs.tool).how + ' (톡톡 눌러도 돼요)' : obs.can ? (si.left > 0 ? '도구를 골라요 · 남은 걸음 ' + si.left : '남은 걸음이 없어요') : '지금 선 곳이나 갈 곳 버섯만 살펴볼 수 있어요';
      TOOLS.forEach((tl, i) => {
        const b = obsParts.toolBtns[i], known = !!(kb & tl.b);
        b.innerHTML = '';
        b.append(L.h('span', { text: tl.ic, style: { fontSize: '18px', lineHeight: 1 } }), L.h('span', { text: tl.nm, style: { fontWeight: 700 } }),
          L.h('span', { text: known ? '✓ 봤어요' : obs.can ? '걸음 1' : '—', style: { fontSize: '10.5px', color: known ? '#7fdc95' : 'var(--muted)' } }));
        b.classList.toggle('primary', obs.tool === tl.b);
        b.style.borderColor = known ? '#4fae6a' : '';
        b.disabled = !known && (!obs.can || (si && si.left < 1 && !(obs.slot === 'a' && plan.to >= 0 && !locked())));
      });
      const n = obsParts.notes; n.innerHTML = '';
      const groups = ['c', 't', 'n', 'r', 'k'];
      if (f.glow || (P && P.g)) groups.push('g');
      for (const g of groups) {
        const known = g === 'c' || (g === 'g' ? phase(st) >= 2 : !!(kb & TB[g]));
        const isDiff = P && st.gh && (P.d === g || (g === 'g' && P.g));
        const row = L.h('div', { style: { display: 'flex', gap: '6px', alignItems: 'baseline' } },
          L.h('span', { text: (g === 'c' ? '👁' : g === 'g' ? '🌙' : TOOLS.find((x) => x.d === g).ic) + ' ' + GL[g], style: { flex: 'none', width: '84px', color: isDiff ? 'var(--brass)' : 'var(--muted)', fontWeight: isDiff ? 700 : 400 } }),
          L.h('span', { text: known ? groupText(f, g) : '?', style: { flex: '1 1 0', minWidth: 0, fontWeight: known ? 600 : 400, color: known ? 'var(--ink)' : 'var(--muted)' } }));
        n.append(row);
        if (isDiff && g !== 'g') n.append(L.h('div', { style: { fontSize: '11px', color: 'var(--brass)', paddingLeft: '90px', marginTop: '-2px' }, text: '도감: ' + SP[P.e].nm + ' ' + diffText(SP[P.e], P.d) + ' / ' + SP[P.p].nm + ' ' + diffText(SP[P.p], P.d) }));
      }
      if (obs.can) {
        const pk = slotPick(obs.slot), full = !pk && st.bk[plan.seat].length + pickCount() >= CAP;
        obsParts.pickY.textContent = full ? '바구니 가득' : pk ? '🧺 담을래요 ✓' : '🧺 담기';
        obsParts.pickY.disabled = full;
        obsParts.pickY.classList.toggle('primary', !!pk);
        obsParts.pickN.style.borderColor = pk ? '' : 'var(--brass)'; obsParts.pickN.style.color = pk ? '' : 'var(--brass)';
      }
    }
    function drawObs(dt) {
      if (!obs || !oCtx) return;
      if (obs.tool === 2 && obs.hold) { obs.prog += dt * 1.5; if (obs.prog >= 1) completeTool(2); if (!obs) return; }
      const c = oCtx, w = oW, h = oH, k = obs.k, f = SP[k], ph = phase(st), kb = knownBits();
      const P = SPAL[st.se];
      const bg = c.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, P.obs[0]); bg.addColorStop(1, P.obs[1]);
      c.fillStyle = bg; c.fillRect(0, 0, w, h);
      c.fillStyle = 'rgba(255,240,200,.06)'; for (let i = 0; i < 3; i++) { c.beginPath(); c.moveTo(w * (0.15 + i * 0.25), 0); c.lineTo(w * (0.25 + i * 0.25), 0); c.lineTo(w * (0.05 + i * 0.3), h); c.lineTo(w * (-0.05 + i * 0.3), h); c.closePath(); c.fill(); }
      if (ph >= 2) { c.fillStyle = ph === 3 ? 'rgba(6,10,32,.45)' : 'rgba(46,18,60,.3)'; c.fillRect(0, 0, w, h); }
      const g = obsGeom(), S = g.S, mx = g.mx, gy = g.gy;
      c.fillStyle = st.se === 3 ? '#e8eef4' : '#4a3a24'; c.beginPath(); c.ellipse(mx, gy + S * 0.04, S * 1.1, S * 0.2, 0, 0, TAU); c.fill();
      c.fillStyle = st.se === 3 ? '#ffffff' : st.se === 2 ? '#8a5a2a' : '#5b7a36'; c.beginPath(); c.ellipse(mx, gy, S * 0.95, S * 0.13, 0, 0, TAU); c.fill();
      const tl = obs.tool, pr = U.clamp(obs.prog, 0, 1);
      const turn = kb & 1 ? 1 : tl === 1 ? Math.min(1, pr * 1.2) : 0;
      const dig = kb & 8 ? 1 : tl === 8 ? pr * 0.5 : 0;
      const rub = kb & 4 ? 1 : tl === 4 ? pr : 0;
      const ft = (b) => (obs.flash[b] != null ? U.clamp((time - obs.flash[b]) * 3, 0, 1) : 1);
      const lift = kb & 8 ? S * 0.12 * ft(8) : 0;
      c.save();
      if (tl === 1 && pr > 0) { c.translate(mx, gy); c.rotate(-pr * 0.4); c.translate(-mx, -gy); }
      drawMush(c, k, mx, gy, S, { turn, dig, rub, rubPts: obs.rub, lift, glow: !!f.glow && ph >= 2 });
      c.restore();
      const r = Math.min(w, h) * 0.15;
      const lab = (t, x, y) => { c.font = '600 11px "IBM Plex Sans KR", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'top'; c.fillStyle = 'rgba(242,233,216,.9)'; c.fillText(t, x, y); };
      if (kb & 1) { const a = ft(1); c.save(); c.globalAlpha = a; drawUnder(c, k, w - r - 10, r + 10, r * (0.6 + 0.4 * a), true); lab('갓 아래', w - r - 10, r * 2 + 13); c.restore(); }
      if (kb & 8) { const a = ft(8); c.save(); c.globalAlpha = a; drawSection(c, k, w - r - 10, h - r - 18, r * 0.9, time); lab('자른 면', w - r - 10, h - 16); c.restore(); }
      if (kb & 2 || (tl === 2 && pr > 0)) {
        drawSmell(c, k, mx, g.capY - S * 0.05, S, kb & 2 ? 1 : pr, time);
        if (kb & 2) { const sm = SM[f.sm]; c.font = '700 12px "IBM Plex Sans KR", sans-serif'; const tw = c.measureText(sm[2] + ' ' + sm[0]).width + 16; c.fillStyle = 'rgba(20,14,24,.78)'; rrect(c, 8, 8, tw, 24, 12); c.fill(); c.strokeStyle = sm[1]; c.lineWidth = 1.5; c.stroke(); c.fillStyle = '#f2e9d8'; c.textAlign = 'left'; c.textBaseline = 'middle'; c.fillText(sm[2] + ' ' + sm[0], 16, 20.5); }
      }
      if (kb & 4) { const t = '✋ ' + RBN[f.rb]; c.font = '700 12px "IBM Plex Sans KR", sans-serif'; const tw = c.measureText(t).width + 16, y = (kb & 2) ? 38 : 8; c.fillStyle = 'rgba(20,14,24,.78)'; rrect(c, 8, y, tw, 24, 12); c.fill(); c.strokeStyle = f.rb ? RBC[f.rb] : '#cccccc'; c.lineWidth = 1.5; c.stroke(); c.fillStyle = '#f2e9d8'; c.textAlign = 'left'; c.textBaseline = 'middle'; c.fillText(t, 16, y + 12.5); }
      // 도구 안내 그림
      if (tl) {
        c.save();
        const pulse = 0.5 + 0.5 * Math.sin(time * 6);
        if (tl === 1) { c.strokeStyle = 'rgba(227,174,69,' + (0.5 + pulse * 0.4) + ')'; c.lineWidth = 4; c.lineCap = 'round'; const x = mx + S * 0.75, y1 = gy - S * 0.2, y2 = gy - S * 0.2 - h * 0.25 - pulse * 6; c.beginPath(); c.moveTo(x, y1); c.lineTo(x, y2); c.moveTo(x - 9, y2 + 10); c.lineTo(x, y2); c.lineTo(x + 9, y2 + 10); c.stroke(); }
        if (tl === 2) { c.font = Math.round(26 + pulse * 4) + 'px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('👃', mx + S * 0.55, g.capY - S * 0.35); }
        if (tl === 4) { c.setLineDash([5, 5]); c.lineDashOffset = -time * 20; c.strokeStyle = 'rgba(106,168,255,.9)'; c.lineWidth = 2.5; c.beginPath(); c.ellipse(mx, g.capY + S * 0.05, S * 0.42, S * 0.2, 0, 0, TAU); c.stroke(); c.setLineDash([]); if (obs.ptr) { c.font = '24px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('✋', obs.ptr.x, obs.ptr.y); } }
        if (tl === 8) { const yy = gy - g.stemH * 0.45; c.setLineDash([6, 5]); c.strokeStyle = 'rgba(155,227,122,.95)'; c.lineWidth = 2.5; c.beginPath(); c.moveTo(mx - S * 0.6, yy); c.lineTo(mx + S * 0.6, yy); c.stroke(); c.setLineDash([]); const kx = obs.ptr ? obs.ptr.x : mx - S * 0.6 + ((time * 0.8) % 1) * S * 1.2; c.font = '22px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('🔪', kx, yy - 14); }
        // 진행 막대
        c.fillStyle = 'rgba(20,14,24,.7)'; rrect(c, w * 0.2, h - 10, w * 0.6, 6, 3); c.fill();
        c.fillStyle = TOOLS.find((x) => x.b === tl).col; rrect(c, w * 0.2, h - 10, w * 0.6 * pr, 6, 3); c.fill();
        c.restore();
      }
      for (const b in obs.flash) { const a = (time - obs.flash[b]) * 2; if (a < 1) { c.fillStyle = 'rgba(255,255,255,' + (0.35 * (1 - a)) + ')'; c.fillRect(0, 0, w, h); } }
    }

    /* ---------- 도감 ---------- */
    let guideEl = null;
    function closeGuide() { if (guideEl) { guideEl.remove(); guideEl = null; } }
    function guideCard(k, diffG) {
      const f = SP[k], c = L.h('canvas', { style: { width: '100%', maxWidth: '160px', height: '110px', display: 'block', margin: '0 auto' } });
      const x = setCanvas(c, 160, 110);
      const P = SPAL[st.se];
      const g = x.createLinearGradient(0, 0, 0, 110); g.addColorStop(0, P.obs[0]); g.addColorStop(1, P.obs[1]);
      x.fillStyle = g; x.fillRect(0, 0, 160, 110);
      x.fillStyle = st.se === 3 ? '#e8eef4' : '#4a3a24'; x.beginPath(); x.ellipse(58, 100, 50, 8, 0, 0, TAU); x.fill();
      drawMush(x, k, 56, 98, 62, { glow: !!f.glow, rub: f.rb ? 1 : 0 });
      drawUnder(x, k, 136, 22, 16, true);
      drawSection(x, k, 136, 76, 15, 0);
      x.fillStyle = 'rgba(242,233,216,.8)'; x.font = '600 9px "IBM Plex Sans KR", sans-serif'; x.textAlign = 'center'; x.textBaseline = 'top'; x.fillText('갓 아래', 136, 40); x.fillText('자른 면', 136, 92);
      const groups = ['c', 't', 'n', 'r', 'k'];
      if (f.glow) groups.push('g');
      return L.h('div', { style: { background: 'var(--surface-2)', borderRadius: '12px', padding: '8px', display: 'flex', flexDirection: 'column', gap: '4px', minWidth: 0 } },
        c,
        L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '4px', flexWrap: 'wrap' } },
          L.h('b', { text: f.nm, style: { fontSize: '13.5px' } }),
          L.h('span', { text: f.v ? '식용 ' + f.v + '점' : '독 −' + POISON, style: { fontSize: '11px', fontWeight: 700, padding: '2px 6px', borderRadius: '8px', background: f.v ? '#2f6b45' : '#8a2f2a', color: '#f2e9d8' } })),
        L.h('div', { style: { fontSize: '11px', lineHeight: 1.4 } }, groups.map((gk) => L.h('div', { style: { color: diffG === gk ? 'var(--brass)' : 'var(--ink)', fontWeight: diffG === gk ? 700 : 400 } }, L.h('span', { class: 'muted', text: GL[gk] + ' ' }), groupText(f, gk)))));
    }
    function openGuide() {
      if (!st) return;
      closeGuide(); closeObs();
      api.sfx('card');
      const sh = L.h('div', { class: 'sheet', style: { gap: '10px', padding: '14px', maxHeight: '100%' } });
      sh.append(L.h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        L.h('div', null, L.h('span', { class: 'label', text: SEAS_IC[st.se] + ' ' + SEASONS[st.se] + ' · ' + THEMES[st.th] + ' 도감' }), L.h('h2', { text: '이번 숲의 버섯', style: { margin: 0 } })),
        L.h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: closeGuide })));
      sh.append(L.h('div', { class: 'muted', style: { fontSize: '12px', lineHeight: 1.45 } }, '닮은꼴끼리 나란히 있어요. 갓은 그냥 보이고, ↻뒤집기 · 👃냄새 · ✋문지르기 · 🔪자르기로 나머지를 봐요. ※ 모두 지어낸 버섯이에요.'));
      sh.append(L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px', background: 'var(--surface-2)', borderRadius: '12px', padding: '8px 10px', fontSize: '12.5px' } },
        L.h('b', { text: '🍲 오두막 주문 (오두막에 들르면 저절로 요리해요)' }), st.o.map((o) => L.h('div', null, orderLabel(o) + ' → ', L.h('b', { class: 'mono', text: '+' + o[0] + '점' })))));
      st.pr.forEach((pi, j) => {
        const P = PAIRS[pi];
        sh.append(L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } },
          j === 0 ? L.h('div', { style: { fontSize: '12px', fontWeight: 700, color: '#ffd36a' }, text: '✨ ' + SEASONS[st.se] + '의 귀한 버섯 (깊은 숲에 있어요)' }) : null,
          L.h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' } }, guideCard(P.e, st.gh ? P.d : null), guideCard(P.p, st.gh ? P.d : null)),
          st.gh ? L.h('div', { style: { fontSize: '12px', color: 'var(--brass)', lineHeight: 1.4 } }, '🔎 ' + tipOf(P)) : L.h('div', { class: 'muted', style: { fontSize: '12px' }, text: '🔎 두 버섯이 어디가 다른지 직접 찾아보세요!' })));
      });
      sh.append(L.h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' } }, guideCard(st.si, null),
        L.h('div', { class: 'muted', style: { fontSize: '12px', lineHeight: 1.45, alignSelf: 'center' }, text: SP[st.si].nm + '은 닮은 독버섯이 없어요. 오두막 가까이에 많아요.' })));
      sh.append(L.h('button', { class: 'btn primary', text: '닫기', onclick: closeGuide }));
      guideEl = L.h('div', { class: 'overlay mu-guide', style: { padding: '10px', zIndex: 17 } }, sh);
      guideEl.addEventListener('click', (e) => { if (e.target === guideEl) closeGuide(); });
      root.append(guideEl);
    }

    /* ---------- 입력 ---------- */
    let pd = null;
    cv.cv.addEventListener('pointerdown', (e) => { const p = cv.local(e); pd = { x: p.x, y: p.y, cx: camX, cy: camY, moved: false }; });
    cv.cv.addEventListener('pointermove', (e) => {
      if (!pd) return;
      const p = cv.local(e), dx = p.x - pd.x, dy = p.y - pd.y;
      if (!pd.moved && Math.hypot(dx, dy) > 9) pd.moved = true;
      if (pd.moved) { manual = true; const [cx, cy] = clampCam(pd.cx - dx, pd.cy - dy); camX = cx; camY = cy; }
    });
    const upMap = (e) => { if (!pd) return; const moved = pd.moved; pd = null; if (!moved) { const p = cv.local(e); onTap(tileAt(p.x, p.y)); } };
    cv.cv.addEventListener('pointerup', upMap);
    cv.cv.addEventListener('pointercancel', () => { pd = null; });
    let lastToast = 0;
    function hintToast(t) { if (performance.now() - lastToast > 1800) { lastToast = performance.now(); api.toast(t); } }
    function onTap(t) {
      if (t < 0 || !st) return;
      const ps = planSeat();
      if (ps >= 0 && !pending) {
        const si = stepsInfo(), budget = si.max - si.ta;
        if (t === st.ps[ps]) { if (mushIdx(st, t) >= 0) openObs(t); else if (plan.to >= 0 && setDest(-1)) { api.sfx('click'); renderHud(); } return; }
        if (t === plan.to) { if (mushIdx(st, t) >= 0) openObs(t); else if (setDest(-1)) { api.sfx('click'); renderHud(); } return; }
        if (reachD && reachD[t] <= budget && !isFog(st, t)) { if (setDest(t)) { api.sfx('tick'); renderHud(); } return; }
      }
      if (!isFog(st, t) && mushIdx(st, t) >= 0) { openObs(t); return; }
      if (ps >= 0) {
        if (isFog(st, t)) hintToast('안개 속은 가까이 가야 보여요');
        else if (!passS(st, st.m[t])) hintToast(st.m[t] === '~' ? '개울은 징검다리로만 건너요' : '나무·바위는 못 지나가요');
        else if (t === st.bo) hintToast('멧돼지가 길을 막고 있어요');
        else hintToast('걸음이 모자라요');
      }
    }
    const onKey = (e) => { if (e.key === 'Escape' && (obsEl || guideEl)) { e.preventDefault(); if (obsEl) closeObs(); else closeGuide(); } };
    window.addEventListener('keydown', onKey);
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      if (id === 'guide') { guideEl ? closeGuide() : openGuide(); return; }
      const ps = planSeat();
      if (ps < 0 || pending) return;
      const toolB = { turn: 1, sniff: 2, rub: 4, cut: 8 }[id];
      const fslot = obs && obs.can ? obs.slot : plan.to >= 0 && slotMush('b') ? 'b' : 'a';
      if (toolB) { if (!slotMush(fslot)) return; if (!obsEl) openSlot(fslot); if (obs && obs.can) selectTool(toolB), obs && obs.tool === toolB && completeTool(toolB); return; }
      if (id === 'look') { if (obsEl) closeObs(); else openSlot(fslot); return; }
      if (id === 'pick') { if (slotMush(fslot)) togglePick(fslot); return; }
      if (id === 'go') { submitPlan(); return; }
      if (['up', 'down', 'left', 'right'].includes(id)) {
        const base = plan.to >= 0 ? plan.to : st.ps[ps];
        const [x, y] = xy(base), d = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] }[id], X = x + d[0], Y = y + d[1];
        if (X < 0 || Y < 0 || X >= W || Y >= H) return;
        const t = Y * W + X, si = stepsInfo();
        if (t === st.ps[ps]) { if (setDest(-1)) renderHud(); return; }
        if (reachD && reachD[t] <= si.max - si.ta && !isFog(st, t)) { if (setDest(t)) { api.sfx('tick'); renderHud(); } }
        else hintToast('그쪽으로는 못 가요');
      }
    }) : null;

    /* ---------- 라운드 처리 애니메이션 (모두 함께) ---------- */
    function setBusyFor(sec) {
      api.setBusy(true); busyT = sec;
      clearTimeout(watchdog);
      watchdog = setTimeout(() => { busyT = 0; if (anim) finishAnim(); api.setBusy(false); }, sec * 1000 + 2500);
    }
    function finishAnim() {
      const a = anim; anim = null;
      if (a && a.q && a.q[1] >= 0) { fx.trail = { from: a.q[0], to: a.q[1], t0: time }; api.sfx('bounce'); }
      busyT = 0.12;
      renderHud(); syncHand();
    }
    function later(at, fn) { fx.later.push({ at, fn }); }
    function startResolve(next, prev) {
      if (anim) { anim = null; fx.later.length = 0; }
      const Lr = next.last, sp = sp8(), t0 = time, spd = 4.5 * sp;
      const paths = {}, rev = {};
      let maxLen = 0;
      lineA = sumText(Lr);
      // 살펴보기·담기 말풍선 (key 'a' 출발 전 · 'b' 도착 후)
      function looks(key, at) {
        const onTile = {};
        let any = false;
        Lr.P.forEach((p, i) => { const e = p && p[key]; if (e) { (onTile[e[0]] = onTile[e[0]] || []).push(i); any = true; } });
        for (const t in onTile) {
          const list = onTile[t];
          list.forEach((i, j) => {
            const [tile, k, o, pk] = Lr.P[i][key], off = list.length > 1 ? j - (list.length - 1) / 2 : 0;
            fx.bubbles.push({ tile, k, o, pk, col: colOf(i), off, t0: at + j * 0.08 / sp, dur: 1.25 / sp });
            if (o) later(at + 0.1 / sp, () => api.sfx(o & 8 ? 'hit' : o & 1 ? 'card' : o & 4 ? 'roll' : 'whoosh'));
            if (pk) {
              const [cx, cy] = tc(tile);
              later(at + 0.5 / sp, () => {
                if (pk === 1) { api.sfx('pop'); fx.floats.push({ x: cx + off * T * 0.5, y: cy - T * 0.2, text: '🧺 ' + SP[k].nm, c: '#f2e9d8', t0: time }); if (api.canAct(i)) api.buzz(12); }
                else {
                  api.sfx('lose'); fx.poofs.push({ x: cx, y: cy, t0: time, c: 'rgba(150,220,90,A)' });
                  fx.floats.push({ x: cx, y: cy - T * 0.2, text: '독버섯! −' + POISON, c: '#ff8a70', t0: time });
                  fx.dizzy[i] = time + 2.2 / sp;
                  if (api.canAct(i)) api.buzz([40, 60, 40]);
                  api.toast('💫 ' + nameOf(i) + ': ' + SP[k].nm + '은(는) 독버섯! 기절해서 다음 라운드는 쉬어요');
                }
              });
            }
          });
        }
        return any;
      }
      const hasA = looks('a', t0);
      // 함께 걷기
      Lr.P.forEach((p, i) => { if (p && p.pa && p.pa.length > 1) { paths[i] = p.pa; maxLen = Math.max(maxLen, p.pa.length - 1); } });
      const wa = hasA ? 0.95 / sp : 0.1 / sp;
      if (prev && prev.fg) {
        for (const i in paths) paths[i].forEach((t, s) => { for (const v of N9[t]) if (prev.fg[v] !== '1') { const at = wa + s / spd; if (rev[v] == null || at < rev[v]) rev[v] = at; } });
        if (Lr.q && Lr.q[1] >= 0) for (const v of N9[Lr.q[1]]) if (prev.fg[v] !== '1' && rev[v] == null) rev[v] = wa + (maxLen + 1.2) / spd;
      }
      if (Lr.b) Lr.b.forEach((t) => { fx.born[t] = t0 + (rev[t] != null ? rev[t] : wa) + 0.05; });
      for (let s = 1; s <= maxLen; s++) later(t0 + wa + s / spd - 0.02, () => api.sfx('tick'));
      let endAt = wa + maxLen / spd + 0.08 / sp;
      // 오두막 정산
      Lr.P.forEach((p, i) => {
        if (!p || !p.g) return;
        const [cx, cy] = tc(CAB);
        later(t0 + endAt, () => {
          api.sfx('chip'); setTimeout(() => api.sfx(p.c ? 'win' : 'chip'), 120);
          fx.floats.push({ x: cx, y: cy - T * 0.5, text: (p.c ? '🍲 +' : '💰 +') + p.g, c: '#ffd36a', t0: time });
          if (p.c) api.toast('🍲 ' + nameOf(i) + ': 주문 요리 완성! +' + p.g);
        });
        endAt += 0.2 / sp;
      });
      // 도착한 곳에서 살펴보기·담기
      if (looks('b', t0 + endAt)) endAt += 1.05 / sp;
      // 숲의 사건
      const rd = Lr.rd;
      if (rd) {
        later(t0 + endAt, () => {
          if (rd.rain) { fx.rain = 3; api.sfx('whoosh'); api.toast(st.se === 3 ? '☀ 따뜻한 햇살! 눈이 녹으며 버섯이 쑥쑥' : '🌧 ' + RAIN_NM[st.se] + '가 와요! 버섯이 쑥쑥 돋아나요'); }
          if (rd.ba != null) { api.sfx('hit'); api.toast('🐗 멧돼지가 나타났어요! 길을 막아요'); }
          if (rd.bp && rd.bp.length) fx.boar = { from: rd.bf, path: rd.bp, t: 0 };
          if (rd.tr) rd.tr.forEach((t) => { const [cx, cy] = tc(t); fx.poofs.push({ x: cx, y: cy, t0: time + 0.3 / sp, c: 'rgba(120,90,60,A)' }); });
          if (rd.ph === 2) api.toast('🌇 해 질 녘이에요 — 어떤 버섯은 빛나요');
          if (rd.ph === 3) api.toast('🌙 밤이에요! 마지막 라운드, 걸음 3개');
          if (rd.sp && rd.sp.length) api.sfx('pop');
        });
        if (rd.sp) rd.sp.forEach((t) => { fx.born[t] = t0 + endAt + 0.15 / sp; });
        endAt += (rd.bp && rd.bp.length ? 0.6 : 0.25) / sp;
      }
      anim = { t0, walkAt: wa, spd, paths, rev, q: Lr.q, end: Math.max(endAt, 0.6 / sp) };
      setBusyFor(anim.end + 0.2);
    }

    let stopLoop = U.loop((dt) => {
      time += dt;
      for (let i = fx.later.length - 1; i >= 0; i--) if (time >= fx.later[i].at) { const f = fx.later[i].fn; fx.later.splice(i, 1); try { f(); } catch (e) { console.error(e); } }
      if (anim && time - anim.t0 >= anim.end) finishAnim();
      if (fx.boar) { fx.boar.t += dt * 1.6 * sp8(); if (fx.boar.t >= 1) fx.boar = null; }
      if (busyT > 0) { busyT -= dt; if (busyT <= 0 && !anim) { busyT = 0; clearTimeout(watchdog); api.setBusy(false); } }
      draw(dt);
      if (obs) drawObs(dt);
    });

    layout();
    root.__mu = { tap: (t) => onTap(t), openSlot: (sl) => openSlot(sl), plan, submit: () => submitPlan() };   // 시험용 손잡이
    return {
      update(next, prev) {
        const first = !st;
        st = next;
        pending = false;
        if (first || (prev && prev.sd !== next.sd)) {
          terrKey = ''; fogKey = ''; layout(); const p = tc(CAB); const c = clampCam(p[0], p[1]); camX = c[0]; camY = c[1];
          anim = null; lineA = ''; fx.born = {}; fx.later.length = 0; fx.bubbles.length = 0; active = -1; manual = false; closeObs();
        }
        const key = next.sd + ':' + (next.last ? next.last.id : 0);
        if (next.last && prev && prev !== next && key !== shownKey && prev.sd === next.sd) { manual = false; active = -1; closeObs(); startResolve(next, prev); }
        shownKey = key;
        if (obs && mushIdx(next, obs.tile) < 0) closeObs();
        syncPlan();
        renderHud();
        syncHand();
        if (obs) { obs.can = obs.can && planSeat() >= 0 && !pending; renderObs(); }
        if (next.done) { closeGuide(); closeObs(); if (handEl) { handEl.remove(); handEl = null; } }
      },
      destroy() {
        stopLoop(); clearTimeout(watchdog); if (offIn) offIn();
        window.removeEventListener('keydown', onKey);
        fx.later.length = 0;
        if (anim || busyT > 0) api.setBusy(false);
        closeGuide(); closeObs(); if (handEl) handEl.remove();
        cv.destroy(); hud.remove(); top.remove(); delete root.__mu;
      },
    };
  }

  /* ======================= 도감 (게임 밖에서도 열려요 — 버섯 표에서 만들어요. 게임 안 「📖 도감」은 이번 숲만 따로) ======================= */
  const SAFE_NOTE = '⚠ 이 숲과 버섯 44종은 모두 지어낸 거예요. 진짜 야생 버섯은 생김새·냄새·색 변화로도 절대 구별할 수 없어요. 함부로 따거나 먹으면 안 돼요.';
  const seasOf = (ss) => SEASONS.map((_, i) => i).filter((i) => (ss >> i) & 1);
  function codex(el) {
    const h = L.h;
    const note = (t, warn) => h('p', { class: 'note', style: { margin: 0, fontSize: '12.5px', lineHeight: 1.5, color: warn ? '#ffb4a6' : 'var(--muted)', fontWeight: warn ? 700 : 400 }, text: t });
    const row = (ic, name, tag, desc) => h('div', { class: 'cx-row' }, h('span', { class: 'cx-ic', text: ic }),
      h('div', { class: 'cx-tx' }, h('div', { class: 'cx-nm' }, h('b', { text: name }), tag ? h('span', { class: 'cx-tag', text: tag }) : null), desc ? h('div', { class: 'cx-d', text: desc }) : null));
    const card = (k, se, d) => {
      const f = SP[k], cw = 150, chh = 104, c = h('canvas', { style: { width: '100%', maxWidth: cw + 'px', height: 'auto', display: 'block', margin: '0 auto', borderRadius: '8px' } });
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      c.width = Math.round(cw * dpr); c.height = Math.round(chh * dpr);
      try {
        const x = c.getContext('2d'); x.scale(dpr, dpr);
        const P = SPAL[se], g = x.createLinearGradient(0, 0, 0, chh); g.addColorStop(0, P.obs[0]); g.addColorStop(1, P.obs[1]);
        x.fillStyle = g; x.fillRect(0, 0, cw, chh);
        x.fillStyle = se === 3 ? '#e8eef4' : '#4a3a24'; x.beginPath(); x.ellipse(54, 94, 46, 7, 0, 0, TAU); x.fill();
        drawMush(x, k, 52, 92, 56, { glow: !!f.glow, rub: f.rb ? 1 : 0 });
        drawUnder(x, k, 126, 20, 14, true);
        drawSection(x, k, 126, 68, 13, 0);
        x.fillStyle = 'rgba(242,233,216,.8)'; x.font = '600 9px "IBM Plex Sans KR", sans-serif'; x.textAlign = 'center'; x.textBaseline = 'top';
        x.fillText('갓 아래', 126, 36); x.fillText('자른 면', 126, 83);
      } catch (e) { /* 그림은 장식 */ }
      return h('div', { style: { background: 'var(--surface-2)', borderRadius: '12px', padding: '6px', display: 'flex', flexDirection: 'column', gap: '3px', minWidth: 0 } }, c,
        h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '4px', flexWrap: 'wrap' } },
          h('b', { text: f.nm, style: { fontSize: '13px', wordBreak: 'keep-all' } }),
          h('span', { text: f.v ? '식용 ' + f.v + '점' : '독 −' + POISON, style: { fontSize: '11px', fontWeight: 700, padding: '2px 6px', borderRadius: '8px', background: f.v ? '#2f6b45' : '#8a2f2a', color: '#f2e9d8' } })),
        d ? h('div', { style: { fontSize: '11.5px', lineHeight: 1.35, color: 'var(--brass)', fontWeight: 700 } }, h('span', { style: { color: 'var(--muted)', fontWeight: 400 }, text: GL[d] + ' ' }), diffText(f, d)) : null,
        f.glow ? h('div', { style: { fontSize: '11.5px', color: '#bfe8ff' }, text: '🌙 해 질 녘부터 갓이 빛나요' }) : null);
    };
    const pairBlock = (pi) => {
      const P = PAIRS[pi], ses = seasOf(P.ss), se0 = ses[0] || 0;
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: '5px', paddingTop: '4px' } },
        h('div', { style: { display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap', fontSize: '12.5px', fontWeight: 800, color: P.gold ? '#ffd36a' : 'var(--ink)' } },
          (P.gold ? '✨ 금빛 짝' : '닮은꼴 짝') + ' · ' + SP[P.e].nm + ' / ' + SP[P.p].nm,
          h('span', { class: 'cx-tag', text: ses.map((i) => SEAS_IC[i] + SEASONS[i]).join(' ') })),
        h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(2,minmax(0,1fr))', gap: '6px' } }, card(P.e, se0, P.d), card(P.p, se0, P.d)),
        h('div', { style: { fontSize: '12px', lineHeight: 1.45, color: 'var(--brass)' } }, '🔎 ' + tipOf(P)));
    };
    const tabs = [
      { h: '버섯', n: SP.length, build(p) {
        p.append(note(SAFE_NOTE, 1));
        p.append(note('닮은꼴 식용·독버섯 ' + PAIRS.length + '짝 + 외톨이 2종. 짝끼리는 딱 한 곳만 달라요(노란 글씨). 판마다 그 계절의 금빛 짝 1 + 다른 짝 4 + 외톨이 1이 나와요.'));
        const fb = h('div', { class: 'chips' }), list = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } });
        const filt = (se) => {
          [...fb.children].forEach((b, i) => b.classList.toggle('on', i === se + 1));
          list.textContent = '';
          const ids = PAIRS.map((_, i) => i).filter((i) => se < 0 || (PAIRS[i].ss >> se) & 1).sort((a, b) => (PAIRS[b].gold ? 1 : 0) - (PAIRS[a].gold ? 1 : 0));
          ids.forEach((i) => list.append(pairBlock(i)));
          const solo = [[ACORN, 7, '봄 · 여름 · 가을'], [SNOWF, 8, '겨울']].filter(([, ss]) => se < 0 || (ss >> se) & 1);
          if (solo.length) {
            list.append(h('div', { style: { fontSize: '12.5px', fontWeight: 800, paddingTop: '4px' }, text: '외톨이 버섯 — 닮은 독버섯이 없어요 (오두막 가까이에 많아요)' }));
            list.append(h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(2,minmax(0,1fr))', gap: '6px' } },
              ...solo.map(([k, ss, t]) => { const c = card(k, seasOf(ss)[0], null); c.append(h('div', { class: 'muted', style: { fontSize: '11.5px' }, text: t })); return c; })));
          }
        };
        ['전체'].concat(SEASONS.map((s, i) => SEAS_IC[i] + ' ' + s)).forEach((t, i) => fb.append(h('button', { class: 'btn sm', text: t, onclick: () => filt(i - 1) })));
        p.append(fb, list);
        filt(-1);
      } },
      { h: '관찰 도구', n: TOOLS.length + 2, build(p) {
        p.append(note('버섯 카드를 누르면 크게 보며 도구를 써요. 도구 하나에 걸음 1개. 한 번 살펴본 특징은 라운드가 끝나면 모두에게 보여요.'));
        const cnt = (d) => PAIRS.filter((P) => P.d === d);
        const by = (d) => { const a = cnt(d); return a.length + '짝: ' + a.map((P) => SP[P.e].nm + '/' + SP[P.p].nm).join(', '); };
        p.append(row('👁', '갓 보기', '걸음 0', '그냥 보여요: 색·모양·무늬(점·띠 개수)·가장자리. 이것으로 가려내는 짝 ' + by('c')));
        const SHOW = { t: '갓 아래(주름·스펀지 구멍·가시와 색), 자루 고리·무늬', n: '꿀·아몬드·썩은 달걀 같은 냄새 (' + SM.length + '가지)', r: '갓 색이 변하는지 (' + RBN.slice(1).map((t) => t.replace('변해요', '')).join('·') + ')', k: '자른 속(꽉 참·텅 빈 대롱·즙 색)과 밑동(혹·컵 주머니)' };
        TOOLS.forEach((T) => p.append(row(T.ic, T.nm, '걸음 1', T.how + ' → ' + SHOW[T.d] + '. 이것으로 가려내는 짝 ' + by(T.d))));
        const gl = PAIRS.filter((P) => P.g);
        p.append(row('🌙', '밤 빛', '해 질 녘부터', '어떤 독버섯은 해 질 녘(끝나기 3라운드 전)부터 갓이 빛나요: ' + gl.map((P) => SP[P.p].nm).join(' · ') + '.'));
        p.append(note('손짓이 어려우면 버섯을 톡톡 눌러도 되고, 도구 버튼을 한 번 더 눌러도 바로 돼요. 설정 「도감: 스스로 찾기」면 다른 곳 표시와 힌트가 숨겨져요.'));
        p.append(note(SAFE_NOTE, 1));
      } },
      { h: '계절', n: SEASONS.length, build(p) {
        p.append(note('계절은 기본 무작위예요. 계절마다 숲 모습과 나오는 버섯이 달라요. 숲 모양(' + THEMES.join(' · ') + ')도 판마다 무작위로 새로 만들어요.'));
        const EX = ['', '', '버섯이 가장 잘 돋아요.', '버섯이 적게 돋지만 개울이 얼어서 얼음 위로 걸을 수 있어요(2걸음).'];
        SEASONS.forEach((sn, se) => {
          const G = PAIRS[GOLDS[se]], pool = PAIRS.filter((P) => !P.gold && (P.ss >> se) & 1);
          p.append(row(SEAS_IC[se], sn, '돋는 정도 ×' + GF[se],
            '귀한 금빛 버섯(깊은 숲): ' + SP[G.e].nm + ' ' + SP[G.e].v + '점 (닮은 독: ' + SP[G.p].nm + '). 나올 수 있는 짝 ' + pool.length + '개 중 4개: ' +
            pool.map((P) => SP[P.e].nm).join(' · ') + '. 외톨이: ' + SP[se === 3 ? SNOWF : ACORN].nm + '. 숲의 사건: ' + RAIN_NM[se] + '. ' + EX[se]));
        });
      } },
      { h: '사건', n: 7, build(p) {
        p.append(note('라운드 끝(모두 움직이고 살펴본 뒤)에 숲의 사건이 일어나요.'));
        [['🌧', '비 (겨울엔 햇살)', '한 번 오면 버섯이 쑥쑥 돋고, 그 뒤로 더 잘 자라요. 라운드마다 새 버섯도 조금씩 돋아요. 계절마다 ' + RAIN_NM.join(' · ') + '.'],
          ['🐿', '다람쥐', '다람쥐 칸을 지나가면 깊은 숲의 귀한 버섯 자리를 알려 주고 안개를 걷어 줘요. 독버섯 짝일 수도 있어요!'],
          ['🐗', '멧돼지', '몇 라운드 동안 숲을 돌아다니며 길을 막고, 지나간 칸의 버섯을 짓밟아요.'],
          ['🌇', '해 질 녘', '끝나기 3라운드 전부터 숲이 어두워지고, 어떤 독버섯은 빛나기 시작해요.'],
          ['🌙', '밤', '마지막 라운드는 밤이라 걸음이 3개뿐이에요. 끝날 때 오두막에 못 가져온 바구니는 반값(내림).'],
          ['😵', '독버섯 담기', '버리고 −' + POISON + '점, 그 자리에서 기절해 다음 라운드를 쉬어요(출발 전에 담았다면 그 라운드에 걷지도 못해요).']]
          .forEach(([ic, n, t]) => p.append(row(ic, n, '', t)));
        p.append(row('🍲', '오두막 주문', '늘 2개', '오두막을 지나가거나 도착하면 저절로 정산: 주문 재료가 바구니에 다 있으면 요리(보너스!) → 남은 건 버섯 값만큼 팔아요. 바구니는 ' + CAP + '칸.'));
      } },
    ];
    const bar = h('div', { class: 'chips' }), pane = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
    const show = (k) => {
      pane.textContent = '';
      [...bar.children].forEach((b, i) => b.classList.toggle('on', i === k));
      tabs[k].build(pane);
      const sh = el.closest && el.closest('.sheet'); if (sh) sh.scrollTop = 0;
    };
    tabs.forEach((t, k) => bar.append(h('button', { class: 'btn sm', text: t.h + ' ' + t.n, onclick: () => show(k) })));
    el.append(bar, pane);
    show(0);
  }

  L.register({
    id: 'mushroom', name: '숲속 버섯 채집', tag: '탐험·관찰', cat: '보드',
    blurb: '사계절 안개 숲을 모두 동시에 걸으며 버섯을 모아요. 뒤집고·냄새 맡고·문지르고·잘라 보며 닮은꼴 독버섯을 가려내요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, aiDelay: 850, fixedOrder: true,
    tint: '#3b4a22',
    icon: '<path d="M8 30C8 16 18 8 28 8s20 8 20 22z" fill="currentColor"/><path d="M8 30q20 5 40 0" stroke="currentColor" stroke-width="2" fill="none" opacity=".6"/><path d="M22 31h12l2 15q-8 4-16 0z" fill="currentColor" opacity=".75"/><circle cx="20" cy="19" r="3.2" fill="#3b4a22"/><circle cx="33" cy="14" r="2.6" fill="#3b4a22"/><circle cx="38" cy="23" r="2.4" fill="#3b4a22"/><circle cx="27" cy="24" r="2" fill="#3b4a22"/><path d="M6 50q22-6 44 0" stroke="currentColor" stroke-width="3" stroke-linecap="round" fill="none" opacity=".5"/>',
    options: [
      { id: 'season', label: '계절', choices: [{ v: 'rand', label: '무작위' }, { v: 0, label: '🌸 봄' }, { v: 1, label: '🌻 여름' }, { v: 2, label: '🍁 가을' }, { v: 3, label: '❄️ 겨울' }], def: 'rand' },
      { id: 'day', label: '하루 길이', choices: [{ v: 8, label: '짧게 (8라운드)' }, { v: 10, label: '보통 (10라운드)' }, { v: 13, label: '길게 (13라운드)' }], def: 10 },
      { id: 'hint', label: '도감', choices: [{ v: 'on', label: '구별 포인트 보기' }, { v: 'off', label: '스스로 찾기' }], def: 'on' },
    ],
    quick: [
      '안개 숲에서 식용 버섯을 모아 오두막에 가져오면 점수! 하루가 끝날 때 점수가 높은 사람이 이겨요.',
      '라운드마다 모두 동시에 계획해요: 갈 곳 고르기 → 그곳(또는 선 곳) 버섯 살펴보기·담기 → 「✓ 확정」.',
      '닮은꼴 독버섯은 뒤집고·냄새 맡고·문지르고·잘라 봐서 가려내요(담으면 −3점). 오두막에 들르면 저절로 요리·판매!',
    ],
    rules: [
      { h: '목표', p: ['오두막에서 출발해 안개 낀 숲을 탐험하며 식용 버섯을 모아요.', '버섯은 오두막에 가져가야 점수가 돼요. 하루(보통 10라운드)가 끝날 때 점수가 가장 높은 사람이 이겨요.', '혼자 하면 점수에 따라 별 1~3개를 받아요(별 기준은 결과 화면에 나와요).'] },
      { h: '라운드 진행 — 모두 동시에', p: [
        '차례를 기다리지 않아요. 라운드마다 모두 함께 계획을 세우고 「✓ 확정」을 눌러요. 모두 확정하면 다 같이 움직여요.',
        '한 라운드에 걸음 4개(마지막 밤 라운드는 3개). 걸음은 걷기와 살펴보기 도구(1번에 1걸음)에 나눠 써요.',
        '걷기: 빛나는 칸을 누르면 그곳이 갈 곳(🚩)이 돼요. 한 칸에 1걸음, 덤불은 2걸음. 나무·바위·개울은 못 지나가요(징검다리로 건너요).',
        '버섯은 두 곳에서 다룰 수 있어요: 📍 지금 선 곳의 버섯(출발 전)과 🚩 갈 곳의 버섯(도착한 뒤). 아래 버섯 카드를 눌러 살펴보고 「🧺 담기」를 정해요.',
        '처리 순서: ① 선 곳 버섯 살펴보기·담기 → ② 다 같이 걷기(지나간 둘레 안개가 걷히고 버섯이 돋아요) → ③ 오두막 정산 → ④ 갈 곳 버섯 살펴보기·담기 → ⑤ 숲의 사건.'] },
      { h: '버섯 살펴보기 (관찰 미니 게임)', p: [
        '버섯 카드를 누르면 크게 보며 도구를 써요. 도구 하나에 걸음 1개.',
        '↻ 뒤집기: 위로 쓸어 올려요 → 갓 아래(주름·구멍·가시와 색), 자루 고리·무늬가 보여요.',
        '👃 냄새: 꾹 누르고 있어요 → 꿀·아몬드·썩은 달걀 같은 냄새를 알아요.',
        '✋ 문지르기: 갓을 쓱쓱 문질러요 → 파랗게·빨갛게 등 색이 변하는지 봐요.',
        '🔪 자르기: 자루를 옆으로 그어요 → 속(꽉 참·텅 빈 대롱·즙 색)과 밑동(혹·컵 주머니)이 보여요.',
        '손짓이 어려우면 버섯을 톡톡 눌러도 되고, 도구 버튼을 한 번 더 눌러도 바로 돼요.',
        '갈 곳 버섯을 살펴보면 그곳으로 가는 게 정해져요(갈 곳을 바꿀 수 없어요).',
        '한 번 살펴본 특징은 라운드가 끝나면 모두에게 보여요(지도의 버섯 옆 색 점).'] },
      { h: '버섯 구별하기', p: [
        '이번 숲에는 닮은꼴 짝 5쌍(식용 하나, 독 하나)과 외톨이 버섯 하나가 나와요. 「📖 도감」에서 모두 볼 수 있어요.',
        '짝끼리는 딱 한 곳이 달라요: 갓(그냥 보임) · 뒤집기 · 냄새 · 문지르기 · 자르기 중 하나.',
        '반딧나팔·유리가시버섯처럼 해 질 녘부터 빛나는 독버섯도 있어요.',
        '도감 옵션 「스스로 찾기」를 고르면 다른 곳 표시와 힌트가 숨겨져요.'] },
      { h: '담기와 독버섯', p: [
        '「🧺 담기」를 켜고 확정하면 그 버섯을 담아요(바구니 5칸). 담는 순간 무슨 버섯인지 밝혀져요.',
        '독버섯이면 버리고 −3점, 그 자리에서 기절해서 다음 라운드를 쉬어요(출발 전에 담았다면 그 라운드에 걷지도 못해요).',
        '같은 버섯을 여럿이 같은 라운드에 담으면 모두 한 송이씩 가져가요(다툼 없음).'] },
      { h: '오두막', p: [
        '걷다가 오두막을 지나가거나 도착하면 저절로 정산돼요: 걸린 주문 재료가 바구니에 다 있으면 요리(보너스!) → 남은 건 팔기(버섯 값만큼).',
        '주문은 늘 2개. 같은 라운드에 여럿이 같은 주문을 요리하면 모두 받아요. 요리한 주문은 새 주문으로 바뀌어요.',
        '버섯 값: 외톨이 버섯 1 · 대부분 2 · 몇몇 3 · 계절의 귀한 버섯 5점.'] },
      { h: '계절', p: [
        '🌸 봄 · 🌻 여름 · 🍁 가을 · ❄️ 겨울 — 계절마다 숲 모습과 나오는 버섯이 달라요(기본은 무작위).',
        '가을은 버섯이 잘 돋고, 겨울은 적게 돋지만 개울이 얼어서 얼음 위로 걸을 수 있어요(2걸음).',
        '계절마다 깊은 숲에 귀한 금빛 버섯(5점)이 있어요: 봄 햇살왕관 · 여름 솜사탕 · 가을 금별 · 겨울 얼음수정.'] },
      { h: '숲의 사건', p: [
        '🌧 비(겨울엔 햇살): 한 번 오면 버섯이 쑥쑥 돋고, 그 뒤로 더 잘 자라요. 라운드마다 새 버섯도 조금씩 돋아요.',
        '🐿 다람쥐: 다람쥐 칸을 지나가면 깊은 숲의 귀한 버섯 자리를 알려 주고 안개를 걷어 줘요(독버섯 짝일 수도 있어요!).',
        '🐗 멧돼지: 몇 라운드 동안 숲을 돌아다니며 길을 막고, 지나간 칸의 버섯을 짓밟아요.',
        '🌇 해 질 녘(끝나기 3라운드 전)부터 숲이 어두워지고, 🌙 마지막 라운드는 밤이라 걸음이 3개예요.'] },
      { h: '점수·승리', p: ['오두막 점수(팔기·요리) − 독버섯 벌점 + 마지막에 오두막에 못 가져온 바구니는 반값(내림).', '점수가 같으면 공동 우승이에요.'] },
      { h: '예시', p: [
        '3칸 떨어진 곳에 주황 둥근 갓 버섯이 보여요. 그 칸을 눌러 갈 곳(🚩)으로 정해요(3걸음).',
        '🚩 갈 곳 카드를 눌러 살펴보기 → 꿀방울(식용)과 불씨방울(독)은 갓 아래 색이 달라요. ↻뒤집기(1걸음) → 크림색! 꿀방울이네요.',
        '「🧺 담기」를 켜고 「✓ 확정」. 모두 확정하면 함께 걸어가고, 도착해서 쏙 담아요.',
        '바구니가 차거나 해가 지기 전에 오두막으로! 주문 「꿀방울×2 + 도토리 → +8」이 있으면 들르기만 해도 요리돼요.'] },
      { h: '한 폰에서 여럿이', p: ['한 폰으로 여럿이 하면 라운드마다 이름이 뜨는 사람이 차례로 계획을 세우고 폰을 넘겨요. 모두 확정하면 함께 움직여요.'] },
      { h: '조작', p: ['칸을 눌러 갈 곳 고르기, 지도를 끌어서 둘러보기. 다른 버섯을 누르면 크게 구경해요.', 'PC: 방향키 갈 곳 한 칸씩, O 살펴보기, T 뒤집기, N 냄새, R 문지르기, K 자르기, P 담기, E·Space 확정, G 도감.', 'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬운 AI는 아무 도구나 쓰고 가끔 잘못 알아봐요.'] },
      { h: '주의', p: ['이 숲과 버섯은 모두 지어낸 거예요. 진짜 야생 버섯은 생김새·냄새·색 변화로도 절대 구별할 수 없어요. 함부로 따거나 먹으면 안 돼요.'] },
    ],
    tutorial: [
      { sel: 'canvas', text: '안개 낀 숲이에요! 차례를 기다리지 않고, 라운드마다 모두 동시에 계획해요. 빛나는 칸을 누르면 그곳이 갈 곳이 돼요.' },
      { sel: '.mu-steps', text: '한 라운드에 걸음 4개(밤엔 3개). 한 칸에 1걸음(덤불 2걸음), 살펴보기 도구도 한 번에 1걸음이에요.' },
      { sel: '.mu-go', text: '계획이 끝나면 「✓ 확정」! 모두 확정하면 다 같이 움직이고, 지나간 둘레의 안개가 걷혀요.' },
      { sel: '.mu-guide-btn', text: '📖 도감에 이번 계절 숲의 버섯이 다 있어요. 식용과 독버섯이 닮은꼴 짝이에요.' },
      { sel: '.mu-hud', text: '지금 선 곳(📍)이나 갈 곳(🚩)에 버섯이 있으면 여기 카드가 떠요. 눌러서 뒤집고·냄새 맡고·문지르고·잘라 본 뒤, 식용이면 「🧺 담기」!' },
      { sel: '.mu-top', text: '위에는 계절·시간·점수, 그리고 계획을 마친 사람(✓)이 보여요. 오두막에 들르면 저절로 요리·판매돼요.' },
    ],
    controls: [
      { id: 'up', label: '갈 곳 위로', keys: ['ArrowUp'], pad: ['up'] },
      { id: 'down', label: '갈 곳 아래로', keys: ['ArrowDown'], pad: ['down'] },
      { id: 'left', label: '갈 곳 왼쪽', keys: ['ArrowLeft'], pad: ['left'] },
      { id: 'right', label: '갈 곳 오른쪽', keys: ['ArrowRight'], pad: ['right'] },
      { id: 'look', label: '살펴보기 열기/닫기', keys: ['KeyO'], pad: ['y'] },
      { id: 'turn', label: '뒤집기', keys: ['KeyT'], pad: ['lb'] },
      { id: 'sniff', label: '냄새 맡기', keys: ['KeyN'], pad: ['rb'] },
      { id: 'rub', label: '문지르기', keys: ['KeyR'], pad: ['lt'] },
      { id: 'cut', label: '자르기', keys: ['KeyK'], pad: ['rt'] },
      { id: 'pick', label: '담기 켜기/끄기', keys: ['KeyP'], pad: ['x'] },
      { id: 'go', label: '계획 확정', keys: ['KeyE', 'Space'], pad: ['a'] },
      { id: 'guide', label: '도감 열기', keys: ['KeyG'], pad: ['back'] },
    ],
    init, actor, apply, result, ai, aiDelayFor, mount, codex,
    _t: { SP, PAIRS, reach, dec, phase, totals, CAB, W, H, N, groupText, tipOf, starNeed },
  });
})();
