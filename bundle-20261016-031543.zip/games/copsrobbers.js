/* 도둑과 경찰 — 숨은 이동 추격전. 60개 역의 가상 도시(도보·버스·지하철 + 도둑 전용 배)에서 경찰 팀이 숨은 도둑을 쫓아요.
   도둑 위치는 상태에 가볍게 암호화(xe)되어 있고 도둑 화면(api.viewer() === 도둑)에서만 풀어서 그려요.
   공개 정보(이동 기록·공개 위치·경찰 위치)로 계산한 「가능한 위치」 분포(pd)는 apply가 매번 갱신해요 — 경찰 AI도 이것만 써요. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------------- map (fixed, generated from a constant seed) ---------------- */
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const COLS = 7, ROWS = 9, CELL = 100, MX = 48, MY = 48, GAP = 40;
  const REMOVED = ['0,6', '8,0', '8,6'];
  const RC = [], ID = {};
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
    if (REMOVED.includes(r + ',' + c)) continue;
    ID[r + ',' + c] = RC.length; RC.push([r, c]);
  }
  const N = RC.length; // 60
  const id = (r, c) => (ID[r + ',' + c] == null ? -1 : ID[r + ',' + c]);
  const rnd = prng(20261012);
  const PX = [], PY = [];
  RC.forEach(([r, c]) => {
    const jx = (rnd() - 0.5) * 46; let jy = (rnd() - 0.5) * 46;
    if (r === 4) jy = Math.min(jy, 8);
    if (r === 5) jy = Math.max(jy, -8);
    PX.push(Math.round(MX + c * CELL + jx)); PY.push(Math.round(MY + r * CELL + (r >= 5 ? GAP : 0) + jy));
  });
  const WW = MX * 2 + (COLS - 1) * CELL, WH = MY * 2 + (ROWS - 1) * CELL + GAP;
  const riverY = (x) => MY + 4.5 * CELL + GAP / 2 + 16 * Math.sin(x / 115 + 0.6);
  const RIVER_HW = 17;

  // transport types: 0 도보, 1 버스, 2 지하철, 3 배(도둑의 숨김 이동 전용)
  const EDGES = []; // [a, b, t]
  const has = (a, b, t) => EDGES.some((e) => e[2] === t && ((e[0] === a && e[1] === b) || (e[0] === b && e[1] === a)));
  const add = (a, b, t) => { if (a >= 0 && b >= 0 && a !== b && !has(a, b, t)) EDGES.push([a, b, t]); };
  const BRIDGES = [1, 3, 5];
  for (const [r, c] of RC) {
    add(id(r, c), id(r, c + 1), 0);
    if (r !== 4 || BRIDGES.includes(c)) add(id(r, c), id(r + 1, c), 0);
  }
  for (let r = 0; r < ROWS - 1; r++) for (let c = 0; c < COLS - 1; c++) {
    if (r === 4) continue;
    if (rnd() < 0.34) { if (rnd() < 0.5) add(id(r, c), id(r + 1, c + 1), 0); else add(id(r, c + 1), id(r + 1, c), 0); }
  }
  function connected(t) {
    const adj = Array.from({ length: N }, () => []);
    const nodes = new Set();
    EDGES.forEach(([a, b, tt]) => { if (tt === t) { adj[a].push(b); adj[b].push(a); nodes.add(a); nodes.add(b); } });
    if (!nodes.size) return true;
    const start = nodes.values().next().value, seen = new Set([start]), q = [start];
    while (q.length) { const x = q.pop(); for (const y of adj[x]) if (!seen.has(y)) { seen.add(y); q.push(y); } }
    return seen.size === nodes.size;
  }
  const degOf = (i, t) => EDGES.filter((e) => e[2] === t && (e[0] === i || e[1] === i)).length;
  function prune(t, p, minDeg) {
    const list = EDGES.filter((e) => e[2] === t);
    for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
    for (const e of list) {
      if (rnd() >= p) continue;
      if (degOf(e[0], t) <= minDeg || degOf(e[1], t) <= minDeg) continue;
      const k = EDGES.indexOf(e); EDGES.splice(k, 1);
      if (!connected(t)) EDGES.splice(k, 0, e);
    }
  }
  prune(0, 0.15, 2);
  // bus: staggered stops on even rows, a triangular mesh
  const BUS_ROWS = [0, 2, 4, 6, 8];
  const busCols = (ri) => (ri % 2 === 0 ? [0, 2, 4, 6] : [1, 3, 5]);
  BUS_ROWS.forEach((r, ri) => {
    const cs = busCols(ri).filter((c) => id(r, c) >= 0);
    for (let i = 0; i + 1 < cs.length; i++) add(id(r, cs[i]), id(r, cs[i + 1]), 1);
    if (ri + 1 < BUS_ROWS.length) for (const c of cs) { add(id(r, c), id(r + 2, c - 1), 1); add(id(r, c), id(r + 2, c + 1), 1); }
  });
  prune(1, 0.22, 2);
  // subway: two loops around a central hub
  const SUBS = [[1, 1], [1, 5], [4, 3], [7, 1], [7, 5], [4, 0], [4, 6]].map(([r, c]) => id(r, c));
  [[0, 1], [0, 2], [1, 2], [2, 3], [2, 4], [3, 4], [5, 0], [5, 3], [6, 1], [6, 4]].forEach(([a, b]) => add(SUBS[a], SUBS[b], 2));
  // ferry along the river (thief only, with a 숨김 이동 ticket)
  [[[5, 0], [4, 2]], [[4, 2], [5, 4]], [[5, 4], [4, 6]]].forEach(([a, b]) => add(id(a[0], a[1]), id(b[0], b[1]), 3));

  const ADJ = [0, 1, 2, 3].map(() => Array.from({ length: N }, () => []));
  EDGES.forEach(([a, b, t]) => { ADJ[t][a].push(b); ADJ[t][b].push(a); });
  const ALL = Array.from({ length: N }, (_, i) => [...new Set([...ADJ[0][i], ...ADJ[1][i], ...ADJ[2][i], ...ADJ[3][i]])]);
  const BUS = new Uint8Array(N), SUB = new Uint8Array(N), PIER = new Uint8Array(N);
  for (let i = 0; i < N; i++) { BUS[i] = ADJ[1][i].length ? 1 : 0; SUB[i] = ADJ[2][i].length ? 1 : 0; PIER[i] = ADJ[3][i].length ? 1 : 0; }
  const HUB = Array.from({ length: N }, (_, i) => BUS[i] + 2 * SUB[i]);
  function bfsAll(types) {
    const D = new Uint8Array(N * N).fill(99);
    for (let s = 0; s < N; s++) {
      D[s * N + s] = 0; const q = [s];
      for (let h = 0; h < q.length; h++) {
        const x = q[h];
        for (const t of types) for (const y of ADJ[t][x]) if (D[s * N + y] === 99) { D[s * N + y] = D[s * N + x] + 1; q.push(y); }
      }
    }
    return D;
  }
  const DP = bfsAll([0, 1, 2]);

  /* ---------------- rules data ---------------- */
  const TK = ['도보', '버스', '지하철', '숨김'];
  const TKC = ['#eadfc6', '#4fc07e', '#ee6a55', '#6fb0ee'];
  const LOGCH = 'wbsh';
  const REVEAL = [3, 8, 13, 18];
  const POL_T = [10, 7, 4];   // per police piece (2–4 players, 3 pieces)
  const POL_T5 = [7, 4, 3];   // per piece with 4 pieces (5 players) — balanced by AI simulation (thief ≈ 40–51%)
  const THIEF_T = [4, 3, 3, 5, 2]; // 도보, 버스, 지하철, 숨김, 2배
  const A64 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_';
  const MOD = 997;
  const enc = (s, p, i) => (p * 37 + s.k + i * 101) % MOD;
  function dec(s, i) { const e = s.xe[i]; for (let p = 0; p < N; p++) if (enc(s, p, i) === e) return p; return -1; }
  const xpos = (s) => dec(s, s.xe.length - 1);
  const isRev = (s, m) => REVEAL.includes(m) && m <= s.mx;
  const nPieces = (s) => s.pp.length;

  function pdGet(s) { const w = new Float64Array(N); for (let i = 0; i < N; i++) w[i] = A64.indexOf(s.pd[i]); return w; }
  function pdSet(s, w) {
    let mx = 0; for (let i = 0; i < N; i++) if (w[i] > mx) mx = w[i];
    let out = '';
    for (let i = 0; i < N; i++) out += w[i] > 0 && mx > 0 ? A64[Math.max(1, Math.round((w[i] / mx) * 63))] : '0';
    s.pd = out;
  }
  function spread(w, k, occ) {
    const nw = new Float64Array(N);
    for (let i = 0; i < N; i++) {
      if (!(w[i] > 0)) continue;
      const nb = (k < 3 ? ADJ[k][i] : ALL[i]).filter((j) => !occ.includes(j));
      for (const j of nb) nw[j] += w[i] / nb.length;
    }
    return nw;
  }

  function thiefMoves(s, onlyK) {
    const cur = xpos(s), out = [];
    for (let k = 0; k < 4; k++) {
      if (onlyK != null && k !== onlyK) continue;
      if (s.xt[k] <= 0) continue;
      for (const j of k < 3 ? ADJ[k][cur] : ALL[cur]) if (!s.pp.includes(j)) out.push({ to: j, k });
    }
    return out;
  }
  function policeMoves(s, q) {
    const out = [], at = s.pp[q];
    for (let k = 0; k < 3; k++) {
      if (s.pt[q][k] <= 0) continue;
      for (const j of ADJ[k][at]) if (!s.pp.some((p, o) => o !== q && p === j)) out.push({ p: q, to: j, k });
    }
    return out;
  }

  /* ---------------- core logic ---------------- */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const th = opts.role === 'rand' ? U.rand(n) : 0;
    const ps = []; for (let i = 0; i < n; i++) if (i !== th) ps.push(i);
    const P = n === 5 ? 4 : 3;
    const own = Array.from({ length: P }, (_, k) => ps[k % ps.length]).sort((a, b) => a - b);
    let pp = null;
    for (let tries = 0; tries < 200; tries++) { // spread the police out a little
      const c = U.shuffle(Array.from({ length: N }, (_, i) => i)).slice(0, P);
      pp = c;
      if (c.every((a, i) => c.every((b, j) => i === j || DP[a * N + b] >= 2))) break;
    }
    const cand = []; for (let i = 0; i < N; i++) if (!pp.includes(i) && pp.every((p) => DP[p * N + i] >= 2)) cand.push(i);
    const start = cand.length ? cand[U.rand(cand.length)] : [...Array(N).keys()].find((i) => !pp.includes(i));
    const s = { n, th, own, pp, pt: own.map(() => (P === 4 ? POL_T5 : POL_T).slice()), xt: THIEF_T.slice(), k: 1 + U.rand(800), xe: [], m: 0, mx: opts.len === 16 ? 16 : 22,
      ph: 'x', dbl: 0, mvd: '', lg: '', dm: [], rv: [], pd: '', seq: 0, last: null, win: null, why: '' };
    s.xe.push(enc(s, start, 0));
    const w = new Float64Array(N); for (let i = 0; i < N; i++) w[i] = pp.includes(i) ? 0 : 1;
    pdSet(s, w);
    return s;
  }

  function actor(s) {
    if (s.win) return null;
    if (s.ph === 'x') return s.th;
    const q = s.mvd.indexOf('0');
    return q < 0 ? null : s.own[q];
  }

  function autoSkip(s) {
    const sk = [];
    for (let q = 0; q < nPieces(s); q++) if (s.mvd[q] === '0' && !policeMoves(s, q).length) { s.mvd = s.mvd.slice(0, q) + '1' + s.mvd.slice(q + 1); sk.push(q); }
    return sk;
  }
  function endRound(s) {
    if (s.m >= s.mx) { s.win = 'x'; s.why = 'time'; s.ph = 'end'; return; }
    s.ph = 'x';
    if (!thiefMoves(s).length) { s.win = 'p'; s.why = 'stuck'; s.ph = 'end'; }
  }
  function startPolice(s) {
    s.ph = 'p'; s.mvd = '0'.repeat(nPieces(s));
    const sk = autoSkip(s);
    if (sk.length) s.last.sk = sk;
    if (s.mvd.indexOf('0') < 0) endRound(s);
  }

  function apply(s, seat, a) {
    if (s.win) throw new Error('game over');
    if (!a || typeof a.to !== 'number' || typeof a.k !== 'number') throw new Error('bad action');
    const to = a.to | 0, k = a.k | 0;
    if (to < 0 || to >= N) throw new Error('bad station');
    if (s.ph === 'x') {
      if (seat !== s.th) throw new Error('not thief');
      if (k < 0 || k > 3 || s.xt[k] <= 0) throw new Error('no ticket');
      const cur = xpos(s);
      if (!(k < 3 ? ADJ[k][cur] : ALL[cur]).includes(to)) throw new Error('not connected');
      if (s.pp.includes(to)) throw new Error('occupied');
      const dbl = !!a.d;
      if (dbl && (s.dbl || s.xt[4] <= 0 || s.m + 2 > s.mx)) throw new Error('no double');
      if (dbl) { s.xt[4]--; s.dm.push(s.m + 1); }
      s.xt[k]--; s.m++; s.lg += LOGCH[k];
      s.xe.push(enc(s, to, s.xe.length));
      let w = spread(pdGet(s), k, s.pp);
      const rev = isRev(s, s.m);
      if (rev) { s.rv.push([s.m, to]); w = new Float64Array(N); w[to] = 1; }
      pdSet(s, w);
      s.seq++;
      s.last = { id: s.seq, w: 'x', k, m: s.m, rv: rev ? to : -1, d: dbl ? 1 : s.dbl ? 2 : 0 };
      if (dbl) {
        s.dbl = 1;
        if (thiefMoves(s).length) return s;
      }
      s.dbl = 0;
      startPolice(s);
      return s;
    }
    if (s.ph !== 'p') throw new Error('bad phase');
    const q = a.p | 0;
    if (q < 0 || q >= nPieces(s) || s.own[q] !== seat || s.mvd[q] !== '0') throw new Error('not your piece');
    if (k < 0 || k > 2 || s.pt[q][k] <= 0) throw new Error('no ticket');
    const from = s.pp[q];
    if (!ADJ[k][from].includes(to)) throw new Error('not connected');
    if (s.pp.some((p, o) => o !== q && p === to)) throw new Error('occupied');
    s.pp[q] = to; s.pt[q][k]--; s.xt[k]++;
    s.mvd = s.mvd.slice(0, q) + '1' + s.mvd.slice(q + 1);
    s.seq++;
    s.last = { id: s.seq, w: 'p', q, f: from, t: to, k };
    if (to === xpos(s)) { s.win = 'p'; s.why = 'catch'; s.ph = 'end'; return s; }
    if (s.pd[to] !== '0') s.pd = s.pd.slice(0, to) + '0' + s.pd.slice(to + 1);
    const sk = autoSkip(s);
    if (sk.length) s.last.sk = sk;
    if (s.mvd.indexOf('0') < 0) endRound(s);
    return s;
  }

  function policeSeats(s) { return [...new Set(s.own)]; }
  function result(s) {
    if (!s.win) return null;
    const pos = xpos(s) + 1;
    if (s.win === 'p') {
      return { winners: policeSeats(s), title: '도둑 검거!',
        text: s.why === 'catch' ? `도둑 ${s.m}번째 이동 뒤 ${pos}번 역에서 붙잡았어요.` : `도둑이 ${pos}번 역에 갇혀 더 움직일 수 없어요.` };
    }
    return { winners: [s.th], title: '도둑 도주 성공', text: `${s.mx}번 이동하는 동안 잡히지 않았어요. 마지막 위치는 ${pos}번 역.` };
  }

  /* ---------------- AI ---------------- */
  function oneMoveReach(s) {
    const r = new Uint8Array(N);
    for (let q = 0; q < nPieces(s); q++) {
      const seen = new Set();
      for (let k = 0; k < 3; k++) if (s.pt[q][k] > 0) for (const j of ADJ[k][s.pp[q]]) seen.add(j);
      seen.forEach((j) => r[j]++);
    }
    return r;
  }
  function thiefScore(s, to, k, reach, amb, lv, w2) {
    const P = nPieces(s);
    let dmin = 99, dsum = 0;
    for (const p of s.pp) { const d = DP[p * N + to]; if (d < dmin) dmin = d; dsum += Math.min(d, 6); }
    const nextRev = isRev(s, s.m + 1) || w2;
    let sc = 7 * Math.min(dmin, 4) + (1.2 * dsum) / P;
    sc -= reach[to] * (nextRev ? 60 : 24);
    if (amb) sc += 2.6 * Math.log2(1 + amb[k]);
    const justRev = isRev(s, s.m) && !s.dbl;
    if (k === 3) sc -= justRev || nextRev ? 0.5 : lv === 3 ? 7 : 5;
    if (k === 2) sc -= s.xt[2] <= 1 ? 2 : 0.6;
    if (k === 1) sc -= 0.2;
    // escape routes from the destination that no police piece can reach next turn
    let exits = 0, open = 0;
    for (const j of ALL[to]) if (!s.pp.includes(j)) { open++; if (!reach[j]) exits++; }
    if (lv === 3) sc += 3 * Math.min(exits, 4) + 0.7 * HUB[to] - (open <= 2 ? 6 : 0);
    else sc += 1.5 * Math.min(exits, 3) - (open <= 1 ? 5 : 0);
    return sc;
  }
  function thiefAI(s, lv) {
    const opts = thiefMoves(s);
    if (!opts.length) return null;
    const reach = oneMoveReach(s);
    if (lv === 1) {
      let pool = opts.filter((o) => o.k < 3 || Math.random() < 0.12);
      if (!pool.length) pool = opts;
      const safe = pool.filter((o) => !reach[o.to]);
      if (safe.length && Math.random() < 0.7) pool = safe;
      const o = pool[U.rand(pool.length)];
      const dbl = !s.dbl && s.xt[4] > 0 && s.m + 2 <= s.mx && !safe.length && Math.random() < 0.5;
      return { to: o.to, k: o.k, d: dbl ? 1 : 0 };
    }
    const w = pdGet(s), amb = [0, 0, 0, 0];
    for (let k = 0; k < 4; k++) { const nw = spread(w, k, s.pp); let c = 0; for (let i = 0; i < N; i++) if (nw[i] > 0) c++; amb[k] = c; }
    const noise = lv === 3 ? 0.3 : 2;
    let best = null, bs = -1e9;
    for (const o of opts) { const sc = thiefScore(s, o.to, o.k, reach, amb, lv) + Math.random() * noise; if (sc > bs) { bs = sc; best = o; } }
    const canDbl = !s.dbl && s.xt[4] > 0 && s.m + 2 <= s.mx;
    const danger = reach[best.to] > 0;
    if (canDbl && (danger || (lv === 3 && isRev(s, s.m + 1) && Math.min(...s.pp.map((p) => DP[p * N + best.to])) <= 2))) {
      let bd = -1e9, b1 = null;
      for (const o of opts) {
        const t2 = { ...s, xt: s.xt.slice(), xe: s.xe.slice(), m: s.m + 1, dbl: 1 };
        t2.xt[o.k]--; t2.xt[4]--;
        t2.xe.push(enc(s, o.to, s.xe.length));
        for (const o2 of thiefMoves(t2)) {
          const sc = thiefScore(t2, o2.to, o2.k, reach, null, lv, isRev(s, s.m + 2)) - (isRev(s, s.m + 1) ? 6 : 0) + Math.random() * noise * 0.5;
          if (sc > bd) { bd = sc; b1 = o; }
        }
      }
      if (b1 && bd - 8 > bs) return { to: b1.to, k: b1.k, d: 1 };
    }
    return { to: best.to, k: best.k, d: 0 };
  }

  function policeAI(s, seat, lv) {
    // uses only public information: pd, police positions, tickets
    const mine = []; for (let q = 0; q < nPieces(s); q++) if (s.own[q] === seat && s.mvd[q] === '0') mine.push(q);
    if (!mine.length) return null;
    const w = pdGet(s); let tot = 0; for (let i = 0; i < N; i++) tot += w[i];
    const Pr = new Float64Array(N); for (let i = 0; i < N; i++) Pr[i] = tot ? w[i] / tot : 1 / N;
    const P1 = new Float64Array(N);
    for (let i = 0; i < N; i++) if (Pr[i] > 0) { const nb = ALL[i]; for (const j of nb) P1[j] += Pr[i] / nb.length; }
    const pieces = lv === 3 ? mine : [mine[0]];
    const all = []; pieces.forEach((q) => all.push(...policeMoves(s, q)));
    if (!all.length) return null;
    if (lv === 1) {
      if (Math.random() < 0.45) { const m = all[U.rand(all.length)]; return { p: m.p, to: m.to, k: m.k }; }
      let tgt = 0; for (let i = 1; i < N; i++) if (Pr[i] > Pr[tgt]) tgt = i;
      let best = all[0], bs = 1e9;
      for (const m of all) { const sc = DP[m.to * N + tgt] + Math.random() * 1.5 - (Pr[m.to] > 0 ? 0.5 : 0); if (sc < bs) { bs = sc; best = m; } }
      return { p: best.p, to: best.to, k: best.k };
    }
    let best = all[0], bs = -1e9;
    for (const m of all) {
      let sc = 400 * Pr[m.to];
      let ed = 0; for (let j = 0; j < N; j++) if (P1[j] > 0) ed += P1[j] * Math.min(DP[m.to * N + j], 6);
      sc -= 8 * ed;
      const left = s.pt[m.p][m.k];
      if (left <= 1) sc -= 3;
      if (m.k === 0) sc += 0.4;
      if (m.k === 2 && left <= 2) sc -= 1;
      if (lv === 3) {
        const pos = s.pp.slice(); pos[m.p] = m.to;
        let cov = 0;
        for (let j = 0; j < N; j++) if (P1[j] > 0) { for (const p of pos) if (DP[p * N + j] <= 1) { cov += P1[j]; break; } }
        sc += 70 * cov;
        let near = 0; for (let j = 0; j < N; j++) if (DP[m.to * N + j] <= 2) near += P1[j];
        if (near > 0.15) sc += 2.5 * HUB[m.to];
        for (let o = 0; o < pos.length; o++) if (o !== m.p && DP[pos[o] * N + m.to] <= 1) sc -= 4;
      } else sc += Math.random() * 1.5;
      if (sc > bs) { bs = sc; best = m; }
    }
    return { p: best.p, to: best.to, k: best.k };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.win) return null;
    if (s.ph === 'x') return seat === s.th ? thiefAI(s, lv) : null;
    return policeAI(s, seat, lv);
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 800 : lv === 3 ? 420 : 600; }

  /* ---------------- view ---------------- */
  const BLOCKS = []; // decorative city blocks / parks
  (function () {
    const r2 = prng(77);
    for (let r = 0; r < ROWS - 1; r++) for (let c = 0; c < COLS - 1; c++) {
      if (r === 4) continue;
      const x = MX + c * CELL + 22, y = MY + r * CELL + (r >= 5 ? GAP : 0) + 22;
      const park = r2() < 0.13;
      const split = r2() < 0.5;
      BLOCKS.push({ x, y, w: CELL - 44, h: CELL - 44, park, split });
    }
  })();
  const cellC = (r, c) => [MX + (c + 0.5) * CELL, MY + (r + 0.5) * CELL + (r >= 5 ? GAP : 0)];
  const DISTRICTS = [['솔빛동', ...cellC(0, 0)], ['청람시장', ...cellC(1, 3)], ['등대곶', ...cellC(0, 5)], ['은하강', 250, riverY(250) + 1], ['나루터', 560, riverY(560) + 1], ['느티공원', ...cellC(6, 1)], ['새벽항', ...cellC(7, 4)]];

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, cam = { x: WW / 2, y: WH / 2, z: 1 }, z0 = 1, userZoomed = false;
    let sel = -1, pend = null, useHid = false, useDbl = false;
    let heat = !!U.store.get('cr.heat', false);
    let anim = null, pulses = [], stopLoop = null, busyT = 0, waitSeq = -1, waitUntil = 0, dead = false;
    const ptrs = new Map(); let gest = null;

    /* --- HUD --- */
    const logHead = L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap' } });
    const logGrid = L.h('div', { style: { display: 'grid', gap: '3px', marginTop: '5px' } });
    const logPanel = L.h('div', { class: 'panel cr-log', style: { padding: '6px 8px', width: '100%', maxWidth: '420px', boxSizing: 'border-box' } }, logHead, logGrid);
    const top = L.h('div', { class: 'hud top', style: { padding: '6px 8px' } }, logPanel);
    const hint = L.h('div', { style: { fontSize: '12.5px', fontWeight: 700, lineHeight: 1.35, textAlign: 'center', minHeight: '17px' } });
    const btnRow = L.h('div', { style: { display: 'flex', gap: '6px', justifyContent: 'center', flexWrap: 'nowrap' } });
    const confirmRow = L.h('div', { style: { display: 'flex', gap: '6px', justifyContent: 'center', flexWrap: 'wrap' } });
    const botPanel = L.h('div', { class: 'panel cr-bot', style: { padding: '7px 8px', width: '100%', maxWidth: '420px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' } }, hint, confirmRow, btnRow);
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px' } }, botPanel);
    root.append(top, bot);
    const mkBtn = (text, onclick, extra) => L.h('button', Object.assign({ class: 'btn sm', style: { minHeight: '44px', flex: '1 1 0', padding: '4px 6px', fontSize: '12.5px', whiteSpace: 'nowrap' }, text, onclick }, extra || {}));
    const heatBtn = mkBtn('', () => { heat = !heat; U.store.set('cr.heat', heat); api.sfx('click'); renderHud(); draw(); }, { 'aria-label': '가능한 위치 표시', class: 'btn sm cr-heat' });
    const hidBtn = mkBtn('', () => { useHid = !useHid; pend = null; api.sfx('click'); renderHud(); draw(); });
    const dblBtn = mkBtn('', () => { useDbl = !useDbl; pend = null; api.sfx('click'); renderHud(); draw(); });
    const fitBtn = mkBtn('⤢ 전체', () => { fit(); userZoomed = false; draw(); api.sfx('click'); }, { 'aria-label': '지도 전체 보기', style: { minHeight: '44px', flex: '0 0 auto', padding: '4px 10px', fontSize: '12.5px' } });

    const name = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const color = (i) => (api.players[i] ? api.players[i].color : L.COLORS[i % 6]);
    const isThiefView = () => !!st && api.viewer() === st.th;
    const showTruth = () => !!st && (!!st.win || isThiefView());
    function myActor() { if (!st || st.win) return -1; const a = actor(st); return a != null && api.canAct(a) ? a : -1; }
    const locked = () => st && st.seq === waitSeq && performance.now() < waitUntil;

    function area() {
      const t = top.offsetHeight + 2, b = bot.offsetHeight + 2;
      return { y0: t, w: cv.w, h: Math.max(80, cv.h - t - b) };
    }
    function fit() { const a = area(); z0 = Math.min(a.w / WW, a.h / WH); cam = { x: WW / 2, y: WH / 2, z: z0 }; }
    function clampCam() {
      const a = area();
      cam.z = U.clamp(cam.z, z0, z0 * 4);
      const hw = a.w / 2 / cam.z, hh = a.h / 2 / cam.z;
      cam.x = hw * 2 >= WW ? WW / 2 : U.clamp(cam.x, hw, WW - hw);
      cam.y = hh * 2 >= WH ? WH / 2 : U.clamp(cam.y, hh, WH - hh);
    }
    function SP(x, y) { const a = area(); return [(x - cam.x) * cam.z + a.w / 2, (y - cam.y) * cam.z + a.y0 + a.h / 2]; }
    function WP(sx, sy) { const a = area(); return [(sx - a.w / 2) / cam.z + cam.x, (sy - a.y0 - a.h / 2) / cam.z + cam.y]; }
    const rad = () => U.clamp(10 * Math.sqrt(cam.z / z0) * Math.min(1.25, z0 / 0.45), 8.5, 18);
    function hitStation(x, y) {
      const r = rad(); let best = -1, bd = Math.max(22, r + 8) ** 2;
      for (let i = 0; i < N; i++) { const [sx, sy] = SP(PX[i], PY[i]); const d = (sx - x) ** 2 + (sy - y) ** 2; if (d < bd) { bd = d; best = i; } }
      return best;
    }

    /* --- selection / reach --- */
    function myPiecesUnmoved(seat) { const out = []; for (let q = 0; q < nPieces(st); q++) if (st.own[q] === seat && st.mvd[q] === '0') out.push(q); return out; }
    function reachMap() {
      const me = myActor(); const m = new Map();
      if (me < 0 || locked()) return m;
      if (st.ph === 'x') {
        if (!isThiefView()) return m;
        const list = useHid ? thiefMoves(st, 3) : thiefMoves(st).filter((o) => o.k < 3);
        list.forEach((o) => { if (!m.has(o.to)) m.set(o.to, []); m.get(o.to).push(o.k); });
        return m;
      }
      if (sel < 0) return m;
      policeMoves(st, sel).forEach((o) => { if (!m.has(o.to)) m.set(o.to, []); m.get(o.to).push(o.k); });
      return m;
    }
    function ensureSel() {
      const me = myActor();
      if (me < 0 || st.ph !== 'p') { sel = -1; return; }
      const mine = myPiecesUnmoved(me);
      if (!mine.includes(sel)) sel = mine.length ? mine[0] : -1;
    }

    function commit(k) {
      if (!pend || !st) return;
      const a = st.ph === 'x' ? { to: pend.to, k, d: useDbl ? 1 : 0 } : { p: sel, to: pend.to, k };
      pend = null;
      if (st.ph === 'x') { useDbl = false; useHid = false; }
      waitSeq = st.seq; waitUntil = performance.now() + 3000;
      api.buzz(15); api.sfx('click');
      api.act(a);
      renderHud(); draw();
    }

    function tap(x, y) {
      const me = myActor();
      if (me < 0 || locked() || anim) return;
      const sid = hitStation(x, y);
      if (sid < 0) { if (pend) { pend = null; renderHud(); draw(); } return; }
      if (st.ph === 'p') {
        const q = st.pp.indexOf(sid);
        if (q >= 0 && st.own[q] === me && st.mvd[q] === '0' && q !== sel) { sel = q; pend = null; api.sfx('tick'); api.buzz(8); renderHud(); draw(); return; }
      }
      const rm = reachMap();
      if (pend && pend.to === sid && pend.ks.length === 1) { commit(pend.ks[0]); return; }
      if (rm.has(sid)) { pend = { to: sid, ks: rm.get(sid).sort() }; api.sfx('tick'); api.buzz(8); }
      else { pend = null; if (st.ph === 'x' && !isThiefView()) {} else api.sfx('click'); }
      renderHud(); draw();
    }

    /* --- HUD rendering --- */
    function chip(label, n, col, dim) {
      return L.h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '3px', opacity: dim ? 0.45 : 1 } },
        L.h('span', { style: { width: '8px', height: '8px', borderRadius: '2px', background: col, flex: 'none' } }),
        L.h('span', { text: label }), L.h('span', { class: 'mono', style: { color: 'var(--brass)' }, text: String(n) }));
    }
    function renderLog() {
      logHead.innerHTML = '';
      logHead.append(L.h('span', { style: { fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '14px', color: 'var(--brass)' }, text: '도둑 기록' }),
        L.h('span', { class: 'mono', text: st.m + '/' + st.mx }),
        L.h('span', { style: { flex: 1 } }),
        chip('도', st.xt[0], TKC[0]), chip('버', st.xt[1], TKC[1]), chip('지', st.xt[2], TKC[2]), chip('숨', st.xt[3], TKC[3]),
        chip('2배', st.xt[4], 'var(--brass)'));
      logGrid.innerHTML = '';
      const per = Math.ceil(st.mx / 2);
      logGrid.style.gridTemplateColumns = `repeat(${per}, 1fr)`;
      const rvm = {}; st.rv.forEach(([m, p]) => { rvm[m] = p; });
      for (let m = 1; m <= st.mx; m++) {
        const ch = st.lg[m - 1];
        const k = ch ? LOGCH.indexOf(ch) : -1;
        const rev = REVEAL.includes(m);
        const isCur = !st.win && m === st.m + 1;
        const fresh = st.last && st.last.w === 'x' && st.last.m === m;
        const el = L.h('div', { style: {
          height: '22px', borderRadius: '5px', display: 'grid', placeItems: 'center', position: 'relative',
          fontFamily: 'var(--f-mono)', fontSize: '10.5px', fontWeight: 700,
          background: k >= 0 ? TKC[k] : 'rgba(255,255,255,.05)', color: k >= 0 ? '#1a1520' : 'var(--muted)',
          border: rev ? '1.5px solid var(--brass)' : isCur ? '1.5px dashed var(--ink)' : '1px solid rgba(255,255,255,.08)',
          transition: 'transform .2s', transform: fresh ? 'scale(1.12)' : '',
        } }, k >= 0 ? (rvm[m] != null ? String(rvm[m] + 1) : ['도', '버', '지', '?'][k]) : rev ? '◉' : String(m));
        if (st.dm.includes(m)) el.append(L.h('span', { style: { position: 'absolute', top: '-5px', right: '-3px', fontSize: '8px', background: 'var(--brass)', color: '#1a1520', borderRadius: '4px', padding: '0 2px', lineHeight: '10px' }, text: '2' }));
        if (fresh) setTimeout(() => { el.style.transform = ''; }, 260);
        logGrid.append(el);
      }
    }
    function renderHud() {
      if (!st) return;
      renderLog();
      ensureSel();
      const me = myActor();
      const nextRev = !st.win && isRev(st, st.m + 1);
      let txt = '', col = 'var(--ink)';
      if (st.win) txt = st.win === 'p' ? '경찰 승리 — 도둑이 지나온 길이 지도에 보여요' : '도둑 승리 — 도둑이 지나온 길이 지도에 보여요';
      else if (me >= 0 && st.ph === 'x') {
        if (!isThiefView()) txt = '도둑 차례';
        else if (st.dbl) { txt = '2배 이동 — 한 번 더 움직이세요'; col = 'var(--brass)'; }
        else txt = pend ? '아래에서 표를 골라 이동하세요' : '도둑 차례 — 갈 역을 누르세요' + (nextRev ? ' · 이번 이동은 공개!' : '');
        if (nextRev && st.dbl) txt += ' · 공개 이동';
      } else if (me >= 0 && st.ph === 'p') {
        const mine = myPiecesUnmoved(me);
        txt = pend ? '아래에서 표를 골라 이동하세요' : `경찰 ${sel + 1} 이동 — 갈 역을 누르세요` + (mine.length > 1 ? ' (다른 말 탭: 바꾸기)' : '');
      } else {
        const a = actor(st);
        txt = a == null ? '' : (st.ph === 'x' ? '도둑이 움직이는 중…' : `경찰 ${st.mvd.indexOf('0') + 1} 이동 중…`) + (nextRev && st.ph === 'x' ? ' 이번 이동은 공개돼요' : '');
        col = 'var(--muted)';
      }
      hint.textContent = txt; hint.style.color = col;
      // confirm row
      confirmRow.innerHTML = '';
      confirmRow.style.display = pend ? 'flex' : 'none';
      if (pend) {
        pend.ks.forEach((k) => {
          const left = st.ph === 'x' ? st.xt[k] : st.pt[sel][k];
          confirmRow.append(L.h('button', { class: 'btn primary sm', style: { minHeight: '44px', flex: '1 1 0', fontSize: '13px', whiteSpace: 'nowrap' },
            text: (useDbl && st.ph === 'x' ? '2배 · ' : '') + (k === 3 ? '숨김 이동' : TK[k] + '로') + ` ${pend.to + 1}번 (${left})`, onclick: () => commit(k) }));
        });
        confirmRow.append(L.h('button', { class: 'btn ghost sm', style: { minHeight: '44px', flex: '0 0 auto' }, text: '취소', onclick() { pend = null; api.sfx('click'); renderHud(); draw(); } }));
      }
      // buttons
      btnRow.innerHTML = '';
      btnRow.style.display = pend ? 'none' : 'flex';
      heatBtn.textContent = (heat ? '● ' : '○ ') + '가능 위치';
      heatBtn.classList.toggle('primary', heat);
      btnRow.append(heatBtn);
      if (me >= 0 && st.ph === 'x' && isThiefView()) {
        hidBtn.textContent = `숨김 ${st.xt[3]}`; hidBtn.classList.toggle('primary', useHid); hidBtn.disabled = st.xt[3] <= 0;
        const canD = !st.dbl && st.xt[4] > 0 && st.m + 2 <= st.mx;
        if (!canD) useDbl = false;
        dblBtn.textContent = `2배 ${st.xt[4]}`; dblBtn.classList.toggle('primary', useDbl); dblBtn.disabled = !canD;
        btnRow.append(hidBtn, dblBtn);
      } else if (st.ph === 'p' && !st.win) {
        const q = sel >= 0 && me >= 0 ? sel : st.mvd.indexOf('0');
        if (q >= 0) {
          const t = st.pt[q];
          btnRow.append(L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11.5px', fontWeight: 700, padding: '0 4px', flex: '1 1 auto', justifyContent: 'center', minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': color(st.own[q]) } }), L.h('span', { text: '경찰' + (q + 1) }),
            chip('도', t[0], TKC[0], !t[0]), chip('버', t[1], TKC[1], !t[1]), chip('지', t[2], TKC[2], !t[2])));
        }
      }
      btnRow.append(fitBtn);
    }

    /* --- drawing --- */
    function shade(hex, f) {
      const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
      if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
      return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
    }
    function piecePos(q) {
      if (anim && anim.who === 'p' && anim.q === q) return anim.pos;
      return [PX[st.pp[q]], PY[st.pp[q]]];
    }
    function drawTerrain(z) {
      // land
      ctx.fillStyle = '#211c2c'; ctx.fillRect(0, 0, WW, WH);
      const g = ctx.createRadialGradient(WW / 2, WH / 2, 50, WW / 2, WH / 2, WH * 0.75);
      g.addColorStop(0, 'rgba(227,174,69,.06)'); g.addColorStop(1, 'rgba(0,0,0,.25)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, WW, WH);
      for (const b of BLOCKS) {
        ctx.fillStyle = b.park ? 'rgba(80,150,95,.22)' : 'rgba(255,240,220,.045)';
        rr(b.x, b.y, b.w, b.h, 8); ctx.fill();
        if (!b.park && b.split) { ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.fillRect(b.x + b.w / 2 - 1.5, b.y + 4, 3, b.h - 8); }
        if (b.park) { ctx.fillStyle = 'rgba(95,180,110,.35)'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(b.x + 12 + i * 11, b.y + b.h / 2 + (i % 2 ? 6 : -6), 5, 0, 7); ctx.fill(); } }
      }
      // river
      ctx.beginPath();
      for (let x = -10; x <= WW + 10; x += 10) { const y = riverY(x) - RIVER_HW; x === -10 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); }
      for (let x = WW + 10; x >= -10; x -= 10) ctx.lineTo(x, riverY(x) + RIVER_HW);
      ctx.closePath();
      const rg = ctx.createLinearGradient(0, riverY(0) - RIVER_HW, 0, riverY(0) + RIVER_HW);
      rg.addColorStop(0, '#1f4a63'); rg.addColorStop(0.5, '#2a6585'); rg.addColorStop(1, '#1f4a63');
      ctx.fillStyle = rg; ctx.fill();
      ctx.strokeStyle = 'rgba(160,210,240,.18)'; ctx.lineWidth = 1.2 / z;
      for (let i = 0; i < 2; i++) { ctx.beginPath(); for (let x = 0; x <= WW; x += 10) { const y = riverY(x) + (i ? 6 : -6) + 2 * Math.sin(x / 18 + i); x ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.stroke(); }
      // bridges
      for (const c of BRIDGES) {
        const a = id(4, c), b = id(5, c); if (a < 0 || b < 0) continue;
        const mx = (PX[a] + PX[b]) / 2, my = riverY(mx);
        const ang = Math.atan2(PY[b] - PY[a], PX[b] - PX[a]);
        ctx.save(); ctx.translate(mx, my); ctx.rotate(ang);
        ctx.fillStyle = '#6b5233'; ctx.fillRect(-RIVER_HW - 8, -8, RIVER_HW * 2 + 16, 16);
        ctx.fillStyle = '#8a6a42'; ctx.fillRect(-RIVER_HW - 8, -8, RIVER_HW * 2 + 16, 3); ctx.fillRect(-RIVER_HW - 8, 5, RIVER_HW * 2 + 16, 3);
        ctx.restore();
      }
      // district labels
      ctx.fillStyle = 'rgba(242,233,216,.20)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = `400 ${Math.max(15, 11 / z)}px "Black Han Sans", sans-serif`;
      for (const [t, x, y] of DISTRICTS) ctx.fillText(t, x, y);
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function edgePath(a, b, t) {
      ctx.beginPath();
      if (t === 3) { // ferry: down to the water, along the river, up to the pier
        const xa = PX[a], xb = PX[b], dir = xb > xa ? 1 : -1;
        ctx.moveTo(xa, PY[a]); ctx.lineTo(xa + dir * 14, riverY(xa + dir * 14));
        for (let x = xa + dir * 24; dir > 0 ? x < xb - 14 : x > xb + 14; x += dir * 10) ctx.lineTo(x, riverY(x));
        ctx.lineTo(xb - dir * 14, riverY(xb - dir * 14)); ctx.lineTo(xb, PY[b]);
      } else { ctx.moveTo(PX[a], PY[a]); ctx.lineTo(PX[b], PY[b]); }
    }
    function drawEdges(z) {
      ctx.lineCap = 'round';
      const order = [2, 1, 0, 3];
      for (const t of order) {
        for (const [a, b, tt] of EDGES) {
          if (tt !== t) continue;
          edgePath(a, b, t);
          if (t === 0) { ctx.strokeStyle = 'rgba(234,223,198,.30)'; ctx.lineWidth = 2.2 / z; ctx.setLineDash([]); }
          else if (t === 1) { ctx.strokeStyle = 'rgba(79,192,126,.75)'; ctx.lineWidth = 3.6 / z; ctx.setLineDash([]); }
          else if (t === 2) { ctx.strokeStyle = 'rgba(238,106,85,.62)'; ctx.lineWidth = 6 / z; ctx.setLineDash([]); }
          else { ctx.strokeStyle = 'rgba(111,176,238,.9)'; ctx.lineWidth = 2.6 / z; ctx.setLineDash([7 / z, 5 / z]); }
          ctx.stroke();
        }
      }
      ctx.setLineDash([]);
    }
    function drawStation(i, r, dim) {
      const [x, y] = SP(PX[i], PY[i]);
      ctx.save();
      ctx.globalAlpha = dim ? 0.55 : 1;
      if (SUB[i]) { ctx.beginPath(); ctx.arc(x, y, r + 3.2, 0, 7); ctx.fillStyle = TKC[2]; ctx.fill(); }
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fillStyle = '#efe5d0'; ctx.fill();
      if (BUS[i]) { ctx.beginPath(); ctx.arc(x, y, r, Math.PI, 0); ctx.closePath(); ctx.fillStyle = '#5cc788'; ctx.fill(); }
      ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(20,15,25,.7)'; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke();
      if (PIER[i]) { ctx.beginPath(); ctx.arc(x + r * 0.85, y + r * 0.85, Math.max(3.2, r * 0.36), 0, 7); ctx.fillStyle = TKC[3]; ctx.fill(); ctx.strokeStyle = '#141019'; ctx.lineWidth = 1; ctx.stroke(); }
      ctx.fillStyle = '#1a1520'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = `700 ${Math.round(r * 0.98)}px "IBM Plex Mono", monospace`;
      ctx.fillText(String(i + 1), x, y + 0.5);
      ctx.restore();
    }
    function drawPolice(q, r, now) {
      const [wx, wy] = piecePos(q); const [x, y] = SP(wx, wy);
      const c = color(st.own[q]);
      const R = r * 1.25, lift = R * 0.55;
      const mine = myActor() === st.own[q] && st.ph === 'p';
      ctx.save();
      ctx.beginPath(); ctx.ellipse(x, y + 2, R * 0.9, R * 0.4, 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fill();
      if (mine && q === sel) { ctx.beginPath(); ctx.arc(x, y - lift, R + 5 + Math.sin(now / 160) * 1.5, 0, 7); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.stroke(); }
      const g = ctx.createRadialGradient(x - R * 0.35, y - lift - R * 0.4, R * 0.1, x, y - lift, R);
      g.addColorStop(0, shade(c, 0.45)); g.addColorStop(1, shade(c, -0.25));
      ctx.beginPath(); ctx.arc(x, y - lift, R, 0, 7); ctx.fillStyle = g; ctx.fill();
      ctx.lineWidth = 1.6; ctx.strokeStyle = 'rgba(15,10,20,.8)'; ctx.stroke();
      // badge star
      ctx.fillStyle = '#f6e3a6'; ctx.beginPath();
      for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + (k * Math.PI) / 5, rr2 = (k % 2 ? 0.26 : 0.6) * R; ctx.lineTo(x + Math.cos(a) * rr2, y - lift + Math.sin(a) * rr2); }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#1a1520'; ctx.font = `700 ${Math.round(R * 0.62)}px "IBM Plex Mono", monospace`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(q + 1), x, y - lift + 0.5);
      if (st.ph === 'p' && st.mvd[q] === '1' && !st.win) { ctx.fillStyle = 'rgba(20,15,25,.85)'; ctx.beginPath(); ctx.arc(x + R * 0.8, y - lift - R * 0.75, 6, 0, 7); ctx.fill(); ctx.fillStyle = '#9fd8a8'; ctx.font = '700 9px sans-serif'; ctx.fillText('✓', x + R * 0.8, y - lift - R * 0.75); }
      ctx.restore();
    }
    function drawThief(wx, wy, r, ghost) {
      const [x, y] = SP(wx, wy);
      const R = r * 1.3, lift = R * 0.55;
      ctx.save();
      ctx.globalAlpha = ghost ? 0.85 : 1;
      ctx.beginPath(); ctx.ellipse(x, y + 2, R * 0.9, R * 0.4, 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fill();
      ctx.beginPath(); ctx.arc(x, y - lift, R, 0, 7); ctx.fillStyle = '#17121e'; ctx.fill();
      ctx.lineWidth = 2.4; ctx.strokeStyle = '#ee6a55'; ctx.stroke();
      // mask
      ctx.fillStyle = '#ee6a55';
      ctx.beginPath(); ctx.ellipse(x, y - lift - R * 0.08, R * 0.78, R * 0.28, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#f2e9d8';
      ctx.beginPath(); ctx.ellipse(x - R * 0.32, y - lift - R * 0.08, R * 0.15, R * 0.11, 0, 0, 7); ctx.ellipse(x + R * 0.32, y - lift - R * 0.08, R * 0.15, R * 0.11, 0, 0, 7); ctx.fill();
      ctx.restore();
    }
    function draw() {
      if (!st || dead) return;
      const now = performance.now();
      const W = cv.w, H = cv.h, z = cam.z;
      cv.clear();
      ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, W, H);
      const a = area();
      ctx.save();
      ctx.translate(a.w / 2 - cam.x * z, a.y0 + a.h / 2 - cam.y * z); ctx.scale(z, z);
      ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 20;
      ctx.fillStyle = '#211c2c'; rr(0, 0, WW, WH, 18); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.save(); rr(0, 0, WW, WH, 18); ctx.clip();
      drawTerrain(z);
      drawEdges(z);
      // thief trail (thief view / game over)
      if (showTruth()) {
        const path = st.xe.map((_, i) => dec(st, i));
        ctx.strokeStyle = 'rgba(238,106,85,.85)'; ctx.lineWidth = 3 / z; ctx.setLineDash([6 / z, 5 / z]);
        ctx.beginPath(); path.forEach((p, i) => (i ? ctx.lineTo(PX[p], PY[p]) : ctx.moveTo(PX[p], PY[p]))); ctx.stroke(); ctx.setLineDash([]);
      }
      // reach edges
      const rm = reachMap();
      let from = -1;
      if (rm.size) from = st.ph === 'x' ? xpos(st) : st.pp[sel];
      if (from >= 0) {
        rm.forEach((ks, to) => ks.forEach((k) => {
          const t = k < 3 ? k : [0, 1, 2, 3].find((tt) => ADJ[tt][from].includes(to));
          edgePath(from, to, t); ctx.strokeStyle = k === 3 ? TKC[3] : TKC[k]; ctx.lineWidth = 5 / z; ctx.globalAlpha = 0.9; ctx.stroke(); ctx.globalAlpha = 1;
        }));
      }
      ctx.restore();
      ctx.restore();
      // stations
      const r = rad();
      // heatmap (screen space so it stays visible when zoomed out)
      if (heat && !st.win) {
        const w = pdGet(st); let mx = 0; for (let i = 0; i < N; i++) mx = Math.max(mx, w[i]);
        for (let i = 0; i < N; i++) {
          if (!(w[i] > 0)) continue;
          const f = w[i] / mx, R = r * 1.5 + 16 * f;
          const [x, y] = SP(PX[i], PY[i]);
          const g = ctx.createRadialGradient(x, y, r * 0.5, x, y, R);
          g.addColorStop(0, `rgba(238,106,85,${0.35 + 0.55 * f})`); g.addColorStop(1, 'rgba(238,106,85,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, R, 0, 7); ctx.fill();
        }
      }
      for (let i = 0; i < N; i++) drawStation(i, r, rm.size && !rm.has(i) && i !== from);
      // reach rings
      rm.forEach((ks, to) => {
        const [x, y] = SP(PX[to], PY[to]);
        ks.forEach((k, j) => { ctx.beginPath(); ctx.arc(x, y, r + 5 + j * 4 + Math.sin(now / 200) * 1.2, 0, 7); ctx.strokeStyle = TKC[k]; ctx.lineWidth = 3; ctx.stroke(); });
      });
      // reveals (public)
      st.rv.forEach(([m, p], i) => {
        const last = i === st.rv.length - 1;
        const [x, y] = SP(PX[p], PY[p]);
        ctx.save(); ctx.globalAlpha = last ? 1 : 0.45;
        ctx.setLineDash([4, 3]); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.arc(x, y, r + 9, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        const tag = m + '수';
        ctx.font = '700 10px "IBM Plex Mono", monospace'; const tw = ctx.measureText(tag).width + 8;
        ctx.fillStyle = '#e3ae45'; rr(x - tw / 2, y - r - 25, tw, 14, 5); ctx.fill();
        ctx.fillStyle = '#1a1520'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(tag, x, y - r - 18);
        ctx.restore();
      });
      // pending ghost
      if (pend) {
        const [x, y] = SP(PX[pend.to], PY[pend.to]);
        ctx.beginPath(); ctx.arc(x, y, r + 11, 0, 7); ctx.fillStyle = 'rgba(227,174,69,.25)'; ctx.fill();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.stroke();
      }
      // pieces
      for (let q = 0; q < nPieces(st); q++) drawPolice(q, r, now);
      if (showTruth()) {
        let p = xpos(st);
        let wx = PX[p], wy = PY[p];
        if (anim && anim.who === 'x') [wx, wy] = anim.pos;
        drawThief(wx, wy, r);
      }
      // pulses
      pulses = pulses.filter((p) => now - p.t0 < p.dur);
      for (const p of pulses) {
        const t = (now - p.t0) / p.dur; const [x, y] = SP(p.x, p.y);
        ctx.beginPath(); ctx.arc(x, y, r + 6 + t * 40, 0, 7); ctx.strokeStyle = p.col; ctx.globalAlpha = 1 - t; ctx.lineWidth = 3; ctx.stroke(); ctx.globalAlpha = 1;
      }
    }
    function needLoop() { return !!anim || pulses.length > 0 || reachMap().size > 0 || (myActor() >= 0 && st.ph === 'p'); }
    function kick() {
      if (stopLoop || dead) return;
      stopLoop = U.loop(() => {
        if (anim) {
          const t = Math.min(1, (performance.now() - anim.t0) / anim.dur);
          const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
          anim.pos = [U.lerp(PX[anim.a], PX[anim.b], e), U.lerp(PY[anim.a], PY[anim.b], e) - Math.sin(t * Math.PI) * 18];
          if (t >= 1) { const done = anim.done; anim = null; if (done) done(); }
        }
        draw();
        if (!needLoop()) { stopLoop(); stopLoop = null; draw(); }
      });
    }
    function setBusyFor(ms) {
      api.setBusy(true); clearTimeout(busyT);
      busyT = setTimeout(() => api.setBusy(false), ms);
    }

    /* --- update --- */
    function onEvent(s, prev) {
      const ev = s.last;
      if (!ev) return;
      const sp = L.debug.speed || 1;
      if (ev.w === 'p') {
        api.sfx('thud');
        const dur = 420 / sp;
        anim = { who: 'p', q: ev.q, a: ev.f, b: ev.t, t0: performance.now(), dur, pos: [PX[ev.f], PY[ev.f]] };
        setBusyFor(dur + 60);
        if (s.win === 'p') setTimeout(() => { if (dead) return; pulses.push({ x: PX[ev.t], y: PY[ev.t], t0: performance.now(), dur: 900, col: '#e3ae45' }); api.sfx('hit'); api.buzz(40); api.toast(`검거! ${ev.t + 1}번 역`); kick(); }, dur);
      } else {
        const truth = isThiefView();
        const n = s.xe.length - 1;
        if (truth) {
          const a = dec(s, n - 1), b = dec(s, n);
          const dur = 420 / sp;
          anim = { who: 'x', a, b, t0: performance.now(), dur, pos: [PX[a], PY[a]] };
          setBusyFor(dur + 60);
        } else setBusyFor(450 / sp);
        api.sfx(ev.k === 3 ? 'whoosh' : 'tick');
        if (ev.rv >= 0) {
          pulses.push({ x: PX[ev.rv], y: PY[ev.rv], t0: performance.now(), dur: 1200, col: '#e3ae45' });
          api.toast(`도둑 목격! ${ev.rv + 1}번 역`); api.buzz(25); api.sfx('pop');
        } else if (ev.d === 1) api.toast('도둑 2배 이동!');
        else if (ev.k === 3 && !truth) api.toast('도둑이 숨김 이동을 썼어요');
      }
      if (ev.sk && ev.sk.length) setTimeout(() => !dead && api.toast(ev.sk.map((q) => '경찰' + (q + 1)).join(', ') + ' 이동 불가 — 쉬어요'), 500 / sp);
      if (s.win === 'x') setTimeout(() => { if (dead) return; api.toast('도둑이 끝까지 도망쳤어요'); const p = xpos(s); pulses.push({ x: PX[p], y: PY[p], t0: performance.now(), dur: 1200, col: '#ee6a55' }); kick(); }, 300 / sp);
    }
    function update(s, prev) {
      const first = !st;
      st = s;
      if (first) fit();
      if (prev && prev !== s && prev.seq !== s.seq) { pend = null; useHid = false; }
      if (prev && prev !== s && s.last && (!prev.last || prev.last.id !== s.last.id)) onEvent(s, prev);
      if (prev == null && s.seq === 0) { /* fresh game */ sel = -1; pend = null; useDbl = false; useHid = false; }
      ensureSel();
      renderHud();
      if (!userZoomed) fit(); else clampCam();
      draw(); kick();
    }

    /* --- input --- */
    function onDown(e) {
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
      const p = cv.local(e); ptrs.set(e.pointerId, p);
      if (ptrs.size === 1) gest = { kind: 'pan', sx: p.x, sy: p.y, cx: cam.x, cy: cam.y, moved: false };
      else if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        const mid = [(a.x + b.x) / 2, (a.y + b.y) / 2];
        gest = { kind: 'pinch', d0: Math.hypot(a.x - b.x, a.y - b.y) || 1, z0: cam.z, wm: WP(mid[0], mid[1]), moved: true };
      }
    }
    function onMove(e) {
      if (!ptrs.has(e.pointerId) || !gest) return;
      const p = cv.local(e); ptrs.set(e.pointerId, p);
      if (gest.kind === 'pan' && ptrs.size === 1) {
        const dx = p.x - gest.sx, dy = p.y - gest.sy;
        if (!gest.moved && Math.hypot(dx, dy) > 9) gest.moved = true;
        if (gest.moved && cam.z > z0 * 1.01) { cam.x = gest.cx - dx / cam.z; cam.y = gest.cy - dy / cam.z; clampCam(); draw(); }
      } else if (gest.kind === 'pinch' && ptrs.size >= 2) {
        const [a, b] = [...ptrs.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        cam.z = U.clamp(gest.z0 * d / gest.d0, z0, z0 * 4);
        const mid = [(a.x + b.x) / 2, (a.y + b.y) / 2], ar = area();
        cam.x = gest.wm[0] - (mid[0] - ar.w / 2) / cam.z; cam.y = gest.wm[1] - (mid[1] - ar.y0 - ar.h / 2) / cam.z;
        userZoomed = cam.z > z0 * 1.01; clampCam(); draw();
      }
    }
    function onUp(e) {
      if (!ptrs.has(e.pointerId)) return;
      const p = cv.local(e); ptrs.delete(e.pointerId);
      if (gest && gest.kind === 'pan' && !gest.moved && ptrs.size === 0) tap(p.x, p.y);
      if (ptrs.size === 0) gest = null;
      else if (gest && gest.kind === 'pinch') { const [q] = [...ptrs.values()]; gest = { kind: 'pan', sx: q.x, sy: q.y, cx: cam.x, cy: cam.y, moved: true }; }
    }
    function onCancel(e) { ptrs.delete(e.pointerId); if (!ptrs.size) gest = null; }
    function onWheel(e) {
      e.preventDefault();
      const p = cv.local(e), wm = WP(p.x, p.y);
      cam.z = U.clamp(cam.z * Math.exp(-e.deltaY * 0.0015), z0, z0 * 4);
      const ar = area();
      cam.x = wm[0] - (p.x - ar.w / 2) / cam.z; cam.y = wm[1] - (p.y - ar.y0 - ar.h / 2) / cam.z;
      userZoomed = cam.z > z0 * 1.01; clampCam(); draw();
    }
    let lastTap = 0;
    function onDbl(e) { // double-tap zoom toggle
      const t = performance.now();
      if (t - lastTap < 280 && !pend) {
        const p = cv.local(e), wm = WP(p.x, p.y);
        if (cam.z > z0 * 1.4) { fit(); userZoomed = false; } else { cam.z = z0 * 2.2; cam.x = wm[0]; cam.y = wm[1]; userZoomed = true; clampCam(); }
        draw();
      }
      lastTap = t;
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.cv.addEventListener('wheel', onWheel, { passive: false });
    cv.cv.addEventListener('dblclick', onDbl);
    cv.cv._sp = (i) => SP(PX[i], PY[i]); // test hook: station → screen point
    cv.onresize = () => { if (!st) return; const zr = cam.z / z0; fit(); if (userZoomed) { cam.z = z0 * zr; clampCam(); } draw(); };

    return {
      update,
      destroy() {
        dead = true; if (stopLoop) stopLoop(); stopLoop = null; clearTimeout(busyT); api.setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onCancel);
        cv.cv.removeEventListener('wheel', onWheel); cv.cv.removeEventListener('dblclick', onDbl);
        top.remove(); bot.remove(); cv.destroy();
      },
    };
  }

  L.register({
    id: 'copsrobbers', name: '도둑과 경찰', tag: '숨은 추격', cat: '보드',
    blurb: '도둑은 몰래 도시를 누비고, 경찰 팀은 이동 기록만 보고 추리해 도둑이 선 역에 내려앉아야 해요.',
    minPlayers: 2, maxPlayers: 5, defaultPlayers: 3, hidden: true, aiDelay: 600,
    tint: '#23395e',
    icon: '<path d="M8 24c6-6 34-6 40 0-2 7-8 10-14 8l-6-4-6 4c-6 2-12-1-14-8z" fill="currentColor"/><circle cx="19" cy="25" r="3" fill="#23395e"/><circle cx="37" cy="25" r="3" fill="#23395e"/><path d="M10 44h6M22 44h6M34 44h6" stroke="currentColor" stroke-width="3" stroke-linecap="round" opacity=".6"/><circle cx="47" cy="44" r="4" fill="none" stroke="currentColor" stroke-width="3"/>',
    options: [
      { id: 'len', label: '도둑 생존', choices: [{ v: 22, label: '22번 이동' }, { v: 16, label: '16번 이동' }], def: 22 },
      { id: 'role', label: '도둑 역할', choices: [{ v: 'first', label: '1번 자리' }, { v: 'rand', label: '무작위' }], def: 'first' },
    ],
    quick: [
      '한 명은 숨은 도둑, 나머지는 경찰 팀이에요. 도둑의 역은 비밀이고, 탄 교통편만 기록에 남아요.',
      '내 차례: 표 한 장을 내고 선으로 이어진 옆 역으로 한 칸 가요(도보·버스·지하철).',
      '경찰이 도둑이 있는 역에 내려앉으면 경찰 승리, 도둑이 22번 이동을 버티면 도둑 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '한 명은 도둑, 나머지는 경찰 팀이에요. 경찰끼리는 한 팀으로 협력해요.',
        '경찰 승리: 경찰 말 하나가 도둑이 있는 역으로 이동하면 잡혀요. 도둑 차례에 갈 수 있는 역이 하나도 없어도 경찰 승리.',
        '도둑 승리: 정해진 이동 수(기본 22번, 설정 16번)를 다 채울 때까지 안 잡히면 이겨요.'] },
      { h: '준비', p: [
        '도시에는 역이 60개 있어요. 역의 숫자는 역 번호예요.',
        '도둑 역할은 설정에서 「1번 자리」 또는 「무작위」로 정해요.',
        '경찰 말은 3개(5명이면 4개)예요. 2명이면 경찰 한 사람이 3개를 모두, 3명이면 한 사람이 2개·다른 사람이 1개를 맡아요. 4–5명이면 한 사람이 1개씩.',
        '시작 위치는 무작위예요. 도둑은 경찰 바로 옆이 아닌 역에서 시작하고, 도둑 위치는 도둑만 알아요.'] },
      { h: '차례에 할 일', p: [
        '한 라운드 = ① 도둑이 1번 이동 → ② 경찰 말이 모두 한 번씩 이동.',
        '이동 = 표 한 장을 내고, 그 교통편 선을 따라 바로 옆 역으로 가요.',
        '경찰은 자리 순서대로 움직여요. 한 사람이 말을 여럿 맡으면 그 말들은 원하는 순서로 움직여요.',
        '역 하나에는 경찰 말이 하나만 설 수 있어요. 도둑은 경찰이 서 있는 역으로 갈 수 없어요.',
        '표가 없어 움직일 수 없는 경찰 말은 그 차례를 쉬어요.'] },
      { h: '교통편', p: [
        '도보: 가는 선. 가까운 역으로 가요. 역이 가장 많아요.',
        '버스: 초록 선. 윗부분이 초록인 역끼리 이어져요. 조금 멀리 가요.',
        '지하철: 빨간 굵은 선. 빨간 테두리 역끼리 이어져요. 아주 멀리 가요.',
        '배: 파란 점선(강을 따라). 도둑만 「숨김」 표로 탈 수 있어요.'] },
      { h: '표', p: [
        '경찰(말 하나당): 도보 10 · 버스 7 · 지하철 4장. 5명(말 4개)일 때는 도보 7 · 버스 4 · 지하철 3장.',
        '도둑: 도보 4 · 버스 3 · 지하철 3장 + 숨김 5장 + 2배 2장.',
        '경찰이 쓴 표는 도둑에게 넘어가요. 그래서 도둑은 표가 잘 떨어지지 않아요.',
        '남은 표는 모두에게 보여요(위 기록판의 도·버·지·숨·2배).'] },
      { h: '도둑 기록과 공개', p: [
        '도둑이 움직일 때마다 위 기록판에 탄 교통편이 한 칸씩 적혀요. 어느 역으로 갔는지는 비밀이에요.',
        '3 · 8 · 13 · 18번째 이동(기록판의 ◉ 칸) 뒤에는 도둑 위치가 모두에게 공개돼요. 그 칸에 역 번호가 적혀요.',
        '경찰은 「마지막 공개 위치 + 그 뒤 탄 교통편」으로 도둑이 있을 만한 역을 좁혀 가요.'] },
      { h: '특수 표 (도둑)', p: [
        '숨김: 어떤 교통편이든(배 포함) 탈 수 있고, 기록에는 「?」로만 남아요.',
        '2배: 연달아 두 번 움직여요(표는 각각 내요). 기록 두 칸이 채워지고, 그 사이 경찰은 움직이지 않아요. 한 판에 2장.'] },
      { h: '조작', p: [
        '내 말을 탭하면 갈 수 있는 역이 교통편 색 고리로 표시돼요.',
        '역을 탭한 뒤 아래 버튼(표 종류)을 눌러 확정해요. 그 역에 갈 표가 한 가지뿐이면 같은 역을 한 번 더 탭해도 돼요.',
        '도둑은 「숨김」 「2배」 버튼을 켠 뒤 역을 고르면 그 표를 써요.',
        '「가능 위치」를 켜면 지금까지의 기록으로 계산한, 도둑이 있을 수 있는 역이 붉게 빛나요(밝을수록 가능성 높음).',
        '두 손가락으로 확대/축소, 확대한 뒤 끌어서 이동, 두 번 탭하면 확대 전환, 「⤢ 전체」로 원래대로.',
        '한 폰으로 여럿이 하면 차례마다 폰을 넘기는 가림막이 나와요. 도둑 위치는 도둑 화면에서만 보여요.'] },
      { h: '예시', p: [
        '도둑 기록: 1 [버] · 2 [도] · 3 [지] ◉ → 3번째 이동 뒤 공개! 「42번 역」.',
        '4번째 이동 [도]: 경찰은 「42번 역에서 도보로 한 칸」인 역들을 의심해요.',
        '5번째 이동 [?](숨김): 교통편을 몰라서 후보가 확 늘어나요.',
        '경찰은 후보 역을 둘러싸며 다가가요. 도둑이 있는 역에 내려앉으면 경찰 승리!'] },
      { h: 'AI 난이도', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 경찰 AI는 공개된 정보만 써요.',
        '도둑 AI: 쉬움은 대충 피하고, 보통은 경찰과의 거리·기록의 모호함을 따지며, 어려움은 도망칠 길과 특별 표 타이밍까지 챙겨요.',
        '경찰 AI: 쉬움은 마지막 목격 위치로 대충 몰려가고, 보통은 가능한 위치 쪽으로 좁혀 가며, 어려움은 말끼리 포위망을 나누고 환승역을 막아요.'] },
    ],
    tutorial: [
      { text: '한 명은 숨은 도둑, 나머지는 경찰 팀이에요. 도둑이 어느 역에 있는지는 도둑만 알아요. 경찰은 단서로 추리해서 잡아야 해요!' },
      { text: '역은 선으로 이어져 있어요: 도보(가는 선) · 버스(초록 선) · 지하철(빨간 굵은 선). 강의 파란 점선은 배예요(도둑의 숨김 표 전용).' },
      { sel: '.cr-log', text: '위는 도둑 기록판이에요. 도둑이 움직일 때마다 탄 교통편이 한 칸씩 적혀요. 역은 비밀이에요. ◉ 칸(3·8·13·18번째)에서는 도둑 위치가 모두에게 공개돼요!' },
      { sel: '.cr-log', text: '기록판 오른쪽 위 숫자는 도둑의 남은 표예요(도·버·지·숨·2배). 경찰이 쓴 표는 도둑에게 넘어가요.' },
      { sel: '.cr-bot', text: '움직이기: 지도에서 내 말을 탭 → 색 고리가 뜬 역을 탭 → 여기 아래 표 버튼으로 확정. 표 한 장으로 선 한 칸을 가요.' },
      { sel: '.cr-heat', text: '「가능 위치」를 켜면 도둑이 있을 수 있는 역이 붉게 빛나요. 경찰일 때 큰 도움이 돼요.' },
      { sel: '.cr-bot', text: '도둑이라면 「숨김」(기록에 ? 로 남음)과 「2배」(연달아 두 번 이동)를 아껴 쓰세요. 경찰은 말마다 표 수가 정해져 있어요.' },
      { text: '경찰 말이 도둑의 역에 내려앉으면 경찰 승리, 도둑이 22번 이동을 버티면 도둑 승리! 지도는 두 손가락으로 확대할 수 있어요.' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { N, EDGES, ADJ, ALL, DP, REVEAL, dec, xpos, pdGet, thiefMoves, policeMoves, enc },
  });
})();
