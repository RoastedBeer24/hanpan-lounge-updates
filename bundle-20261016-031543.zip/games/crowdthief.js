/* 군중 속 도둑 — 실시간 비대칭 관찰 게임 (2–8명, 한 폰에 한 명, 빈자리는 AI).
   도둑 1명(6명 이상이면 2명)이 손님(NPC) 무리 속에 똑같은 모습으로 섞여 박물관·시장·기차역·파티장·도서관에서
   목표 물건을 몰래 훔치고(「훔치기」 꾹 1.8초 — 그동안 손을 뻗는 모습이 보임) 출구로 걸어 나가요.
   나머지는 경비원: 사람을 눌러 지목하고 「체포」(수갑은 팀 공용, 틀리면 수갑을 잃고 잠깐 멈춤), 「호루라기」로 모두를 멈춰 세워요.
   손님들은 시드 고정 난수로 구경·앉기·줄서기·화장실·돌아다니기·드나들기를 해요. 맵마다 기믹(해설 시간, 반짝 할인, 열차 도착, 건배, 절전).
   Network (flashlight.js pattern): the host (or the local phone) runs the pure world engine incl. AI; guests publish taps /
   stick / buttons and draw the host's snapshots. Round flow travels in the small coarse state via api.setState. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;
  const hyp = Math.hypot;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const wrapA = (a) => { a = (a + Math.PI) % TAU; if (a < 0) a += TAU; return a - Math.PI; };
  const mmss = (t) => { t = Math.max(0, Math.ceil(t)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  const NPMAX = 8;

  /* ---------- tuning (units = metres-ish, seconds) ----------
     Round 14 rebalance (human thieves felt hopeless): shorter steal, smaller guard no-steal zone, later theft alert,
     the thief freezes on the whistle automatically (like every guest), NPCs also reach/point at things (so a reaching hand
     is no longer a sure tell), plus thief tools (변장·따라가기·소란·공범·사진·앉기·줄 서기) and moderate guard tools
     (CCTV 다시 보기 with a cooldown, 2 checkpoints), wrong arrests cost more and handcuffs are fewer. */
  const WU = 15, HU = 21, NAVC = 0.5, GW = 30, GH = 42;
  const BR = 0.3;                                    // body radius
  const V_NPC = 1.05, V_TW = 1.1, V_RUN = 2.3, V_GUARD = 1.45, V_CHASE = 2.3, V_FOL = 1.38;
  const STEAL_T = 1.5, BLOCK_R = 1.6, REACH = 1.0;   // hold time, no stealing with a guard this close, distance to the viewing spot
  const WHIS_T = 2.6, WHIS_CD = 30, FREEZE_T = 4, CATCH_R = 0.7, WC_T = 3.5, CH_MAX = 8;
  const ALERT_D = 5;                                 // the guards notice an empty case this much later
  const DIS_T = 2.4, DIS_CD = 30;                    // disguise (rack / toilet): time, cooldown
  const NZ_N = 2, NZ_CD = 25, NZ_F = 3, NZ_T = 7;    // 소란: uses, cooldown, fuse, how long the crowd stays
  const CC_CD = 45, CC_WIN = 25, GT_N = 2, GT_T = 20; // guard CCTV cooldown / how old a theft may be; checkpoints per round, duration
  const BRIEF_T = 7, END_T = 7, SUB = 1 / 30;
  const isGk = (lk) => lk >= 1000 && lk < 2000, isKid = (lk) => lk >= 2000;

  function rng(seed) {
    let a = (seed >>> 0) || 1;
    return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ---------- looks ---------- */
  const SHIRT = ['#e8604c', '#4f9be0', '#e8c04e', '#4fc38f', '#a77be8', '#ef7fb0', '#8fca4a', '#f0a050', '#e9e2d0', '#5ad1d6', '#b5523c', '#7a8bd8'];
  const HAIR = ['#2a1f1a', '#5a3a22', '#8a5a2b', '#c9a15a', '#b9b4ad', '#1e2433'];
  const HAT = ['#2b2b33', '#c94f3d', '#efe6d2', '#3f66c0', '#3c7d4a'];
  const SKIN = ['#e9c39b', '#d9ab80', '#b98462', '#f1d4b4'];
  const NLOOK = 12 * 6 * 4 * 2;
  const lookOf = (lk) => { lk %= 1000; return { s: SHIRT[lk % 12], h: HAIR[((lk / 12) | 0) % 6], acc: ((lk / 72) | 0) % 4, hat: HAT[(lk * 7 + 3) % 5], pat: ((lk / 288) | 0) % 2, sk: SKIN[(lk * 5 + 1) % 4], s2: SHIRT[(lk * 7 + 5) % 12] }; };

  /* ---------- items ---------- */
  const IK = ['crown', 'mask', 'vase', 'gem', 'mirror', 'statue', 'coin', 'ring', 'bag', 'watch', 'perfume', 'necklace', 'camera', 'jar', 'trophy', 'book', 'map', 'teapot', 'globe', 'pen',
    'doll', 'robot', 'snowglobe', 'choco', 'fan', 'glasses', 'lipstick', 'pearl', 'coral', 'dolphin', 'shell'];

  /* ---------- maps (15 × 21) ---------- */
  function mkMap(def) {
    const M = { nm: def.nm, key: def.key, floor: def.floor, floor2: def.floor2, ob: [], it: [], lk: [], seats: [], qs: [], wc: null, ex: [], gp: [7.5, 15], deco: [], dr: [], ev: def.ev, npc: def.npc || 26, wt: def.wt, tip: def.tip, tl: def.tl || '열차' };
    const H = {
      DR(x, y, lab) { M.dr.push({ x, y }); M.deco.push({ x: x - 0.55, y: y - 0.32, w: 1.1, h: 0.64, k: 'rack', lab: lab || '' }); }, // disguise spot (coat rack)
      R(x, y, w, h, k, lab, col) { M.ob.push({ x, y, w, h, k, lab: lab || '', col: col || '' }); },
      D(x, y, w, h, k, lab) { M.deco.push({ x, y, w, h, k, lab: lab || '' }); },
      LK(x, y, a, item) { M.lk.push({ x, y, a, item: item == null ? -1 : item, sl: null }); return M.lk.length - 1; },
      IT(cx, cy, kind, name, side, caseK, cw, ch, off) {
        cw = cw || 1.2; ch = ch || 1.0;
        if (caseK !== null) H.R(cx - cw / 2, cy - ch / 2, cw, ch, caseK || 'case');
        const d = off || ((side === 'l' || side === 'r') ? cw / 2 : ch / 2) + 0.62;
        const dx = side === 'l' ? -1 : side === 'r' ? 1 : 0, dy = side === 'u' ? -1 : side === 'd' ? 1 : 0;
        const j = M.it.length;
        const li = H.LK(cx + dx * d, cy + dy * d, Math.atan2(-dy, -dx), j);
        M.it.push({ x: cx, y: cy, k: IK.indexOf(kind), nm: name, li });
      },
      BN(cx, cy, len, vert, sides) { // bench; people sit on its centre line
        const th = 0.46;
        if (vert) H.R(cx - th / 2, cy - len / 2, th, len, 'bench'); else H.R(cx - len / 2, cy - th / 2, len, th, 'bench');
        const n = Math.max(1, Math.round(len / 0.8));
        for (let i = 0; i < n; i++) {
          const o = -len / 2 + (i + 0.5) * len / n;
          for (const sd of sides === 'a' ? (vert ? 'lr' : 'ud') : sides) {
            const dx = sd === 'l' ? -1 : sd === 'r' ? 1 : 0, dy = sd === 'u' ? -1 : sd === 'd' ? 1 : 0;
            const sx = vert ? cx + dx * 0.12 : cx + o, sy = vert ? cy + o : cy + dy * 0.12;
            M.seats.push({ x: sx, y: sy, ax: sx + dx * 0.52, ay: sy + dy * 0.52, a: Math.atan2(dy, dx) });
          }
        }
      },
      TB(cx, cy, w, h, k, seats, item) { // table + chairs (not solid); seats = [[angle], …] or [[dx,dy,faceAngle]]
        H.R(cx - w / 2, cy - h / 2, w, h, k);
        for (const s of seats) {
          const x = cx + s[0], y = cy + s[1];
          M.seats.push({ x, y, ax: x, ay: y, a: s[2], chair: 1 });
        }
        if (item) H.IT(cx + (item.dx || 0), cy + (item.dy || 0), item.kind, item.nm, item.side, null, 0, 0, item.off);
      },
      Q(x0, y0, dx, dy, n, fa, ra) { const sl = []; for (let i = 0; i < n; i++) sl.push([x0 + dx * i, y0 + dy * i]); M.qs.push({ sl, fa, ra: ra == null ? fa : ra }); },
      WC(x, y, w, h, doorX, doorY) { H.R(x, y, w, h, 'room', '화장실'); M.wc = { x: doorX, y: doorY }; },
      EX(x, y, g) { M.ex.push({ x, y, g: g || 'm' }); },
      GP(x, y) { M.gp = [x, y]; },
    };
    def.f(H);
    // viewing slots: centre + two side slots (perpendicular to the facing), dropped if blocked
    for (const l of M.lk) {
      const px = -Math.sin(l.a), py = Math.cos(l.a);
      const cand = [[l.x, l.y], [l.x + px * 0.62, l.y + py * 0.62], [l.x - px * 0.62, l.y - py * 0.62]];
      l.sl = cand.filter((c, i) => i === 0 || !solidAt(M, c[0], c[1], 0.26));
    }
    return M;
  }
  function solidAt(M, x, y, inf) {
    if (x < inf || y < inf || x > WU - inf || y > HU - inf) return true;
    for (const o of M.ob) if (x > o.x - inf && x < o.x + o.w + inf && y > o.y - inf && y < o.y + o.h + inf) return true;
    return false;
  }
  const PI = Math.PI, UP = -PI / 2, DN = PI / 2;
  const MAPS = [
    mkMap({ nm: '별빛 박물관', key: 'museum', floor: '#3e3550', floor2: '#463c5a', npc: 26,
      tip: '「해설 시간」에는 한 전시품 앞으로 사람들이 몰려요',
      ev: { k: 'gat', at: 'item', lab: '해설 시간!', sub: '해설사 앞으로 손님들이 몰려요', every: 40, dur: 12, frac: 0.45, r: 1.7 },
      f(H) {
        H.D(4.4, 0.05, 1.7, 0.35, 'paint'); H.D(8.9, 0.05, 1.7, 0.35, 'paint');
        H.LK(5.25, 1.0, UP); H.LK(9.75, 1.0, UP);
        H.IT(3, 3.3, 'crown', '금관', 'd', 'case', 1.4, 1.0);
        H.IT(7.5, 3.3, 'mask', '황금 가면', 'd', 'case', 1.4, 1.0);
        H.IT(12, 3.3, 'vase', '청자 꽃병', 'd', 'case', 1.4, 1.0);
        H.IT(1.0, 10, 'gem', '푸른 보석', 'r', 'case', 1.0, 1.4);
        H.IT(14.0, 10, 'mirror', '은거울', 'l', 'case', 1.0, 1.4);
        H.IT(7.5, 9.4, 'statue', '작은 석상', 'd', 'ped', 1.6, 1.6);
        H.IT(4, 17.3, 'coin', '고대 동전', 'u', 'case', 1.4, 1.0);
        H.IT(10.3, 17.3, 'ring', '옥가락지', 'u', 'case', 1.4, 1.0);
        H.BN(7.5, 13.6, 2.6, false, 'a');
        H.BN(4.3, 10, 1.6, true, 'r');
        H.BN(10.7, 10, 1.6, true, 'l');
        H.R(12.1, 20.1, 2.6, 0.75, 'counter', '기념품');
        H.Q(13.4, 19.6, 0, -0.7, 5, DN);
        H.WC(0, 18.3, 1.7, 2.7, 2.1, 19.6);
        H.R(0.25, 0.3, 0.7, 0.7, 'plant'); H.R(14.05, 0.3, 0.7, 0.7, 'plant'); H.R(14.05, 14.5, 0.7, 0.7, 'plant');
        H.EX(7.5, 20.6); H.EX(14.6, 6.6);
        H.DR(1.0, 14.2, '외투');
        H.GP(12.4, 13.4);
      } }),
    mkMap({ nm: '골목 시장', key: 'market', floor: '#45372f', floor2: '#4f4036', npc: 28,
      tip: '「반짝 할인」 가게에 손님이 몰리면 몰래 훔치기 좋아요',
      ev: { k: 'gat', at: 'item', lab: '반짝 할인!', sub: '한 가게로 손님들이 몰려요', every: 38, dur: 12, frac: 0.5, r: 1.8 },
      f(H) {
        H.IT(1.1, 4, 'bag', '가죽 가방', 'r', 'stall', 1.6, 1.9);
        H.IT(1.1, 9.5, 'watch', '손목시계', 'r', 'stall', 1.6, 1.9);
        H.IT(1.1, 15, 'perfume', '장미 향수', 'r', 'stall', 1.6, 1.9);
        H.IT(13.9, 4, 'necklace', '진주 목걸이', 'l', 'stall', 1.6, 1.9);
        H.IT(13.9, 9.5, 'camera', '필름 카메라', 'l', 'stall', 1.6, 1.9);
        H.IT(13.9, 15, 'jar', '꿀단지', 'l', 'stall', 1.6, 1.9);
        H.IT(7.5, 4.0, 'teapot', '은 주전자', 'd', 'stall', 2.4, 1.2);
        H.IT(7.5, 15.4, 'ring', '금반지', 'u', 'stall', 2.4, 1.2);
        H.TB(7.5, 9.9, 1.7, 1.7, 'fountain', [[0, -1.1, UP], [1.1, 0, 0], [0, 1.1, DN], [-1.1, 0, PI]]);
        H.BN(4.6, 7.2, 1.6, true, 'l'); H.BN(10.4, 12.6, 1.6, true, 'r');
        H.R(5.9, 20.0, 3.2, 0.85, 'cart', '호떡');
        H.Q(7.5, 19.5, 0, -0.7, 4, DN);
        H.WC(13.3, 18.3, 1.7, 2.7, 12.9, 19.6);
        H.EX(7.5, 0.4); H.EX(0.4, 19.4); H.EX(14.6, 12.3);
        H.DR(3.4, 18.8, '옷 가게');
        H.GP(3.6, 12.3);
      } }),
    mkMap({ nm: '기차역 대합실', key: 'station', floor: '#3a3f4c', floor2: '#424857', npc: 28,
      wt: { look: 0.34, sit: 0.26, q: 0.1, wc: 0.04, wan: 0.12, exit: 0.14 },
      tip: '「열차 도착」 때 손님들이 우르르 드나들어요',
      ev: { k: 'wave', lab: '열차 도착!', sub: '손님들이 우르르 타고 내려요', every: 34, dur: 7, n: 7 },
      f(H) {
        H.R(0, 0, 15, 1.9, 'track');
        H.EX(2.5, 2.35, 't'); H.EX(7.5, 2.35, 't'); H.EX(12.5, 2.35, 't');
        H.R(5.8, 4.9, 3.4, 0.55, 'board', '출발 안내');
        H.LK(6.6, 6.05, UP); H.LK(8.4, 6.05, UP);
        H.IT(2.2, 5.2, 'bag', '여행 가방', 'd', 'cart', 1.4, 0.9);
        H.IT(12.8, 5.2, 'camera', '사진기', 'd', 'cart', 1.4, 0.9);
        H.IT(7.5, 10.7, 'jar', '도자기', 'd', 'ped', 0.9, 0.9);
        H.BN(4, 9, 3, false, 'a'); H.BN(11, 9, 3, false, 'a'); H.BN(4, 12.4, 3, false, 'a'); H.BN(11, 12.4, 3, false, 'a');
        H.IT(14.3, 15.2, 'watch', '손목시계', 'l', 'kiosk', 1.1, 1.5);
        H.IT(14.3, 17.8, 'perfume', '향수', 'l', 'kiosk', 1.1, 1.5);
        H.IT(0.8, 15.2, 'necklace', '목걸이', 'r', 'kiosk', 1.1, 1.5);
        H.IT(0.8, 17.8, 'book', '한정판 책', 'r', 'kiosk', 1.1, 1.5);
        H.IT(7.5, 16.4, 'trophy', '기념 트로피', 'u', 'case', 1.4, 1.0);
        H.R(3.6, 20.05, 1.2, 0.8, 'machine', '표');
        H.Q(4.2, 19.6, 0, -0.7, 4, DN);
        H.WC(13.3, 7.4, 1.7, 2.5, 12.9, 8.65);
        H.EX(7.5, 20.6); H.EX(0.4, 11);
        H.DR(11.9, 20.0, '코트');
        H.GP(10.6, 18.6);
      } }),
    mkMap({ nm: '한밤 파티장', key: 'party', floor: '#47362c', floor2: '#523f33', npc: 26,
      wt: { look: 0.32, sit: 0.24, q: 0.1, wc: 0.04, wan: 0.22, exit: 0.08 },
      tip: '「건배 타임」에는 모두 춤판으로 모여요 — 다른 곳은 텅 비어요',
      ev: { k: 'gat', at: [7.5, 10.4], lab: '건배 타임!', sub: '모두 가운데 춤판으로 모여요', every: 45, dur: 10, frac: 0.6, r: 2.3, dance: 1 },
      f(H) {
        H.D(4.6, 7.4, 5.8, 6.0, 'dance');
        H.R(3.5, 0.25, 8, 1.8, 'stage', '무대');
        H.IT(7.5, 1.5, 'trophy', '우승 트로피', 'd', null, 0, 0, 1.15);
        H.TB(2.6, 5.6, 1.4, 1.4, 'rtable', [[0, 1.05, DN], [-1.05, 0, PI], [0, -1.05, UP]], { kind: 'necklace', nm: '진주 목걸이', side: 'r', off: 1.3 });
        H.TB(12.4, 5.6, 1.4, 1.4, 'rtable', [[0, 1.05, DN], [1.05, 0, 0], [0, -1.05, UP]], { kind: 'perfume', nm: '향수병', side: 'l', off: 1.3 });
        H.TB(2.6, 15.4, 1.4, 1.4, 'rtable', [[0, 1.05, DN], [-1.05, 0, PI], [0, -1.05, UP]], { kind: 'ring', nm: '다이아 반지', side: 'r', off: 1.3 });
        H.TB(12.4, 15.4, 1.4, 1.4, 'rtable', [[0, 1.05, DN], [1.05, 0, 0], [0, -1.05, UP]], { kind: 'watch', nm: '금시계', side: 'l', off: 1.3 });
        H.R(5.9, 18.3, 3.2, 0.9, 'gtable', '선물');
        H.IT(6.7, 18.75, 'bag', '명품 가방', 'u', null, 0, 0, 1.05);
        H.IT(8.3, 18.75, 'camera', '카메라', 'u', null, 0, 0, 1.05);
        H.IT(0.8, 10.5, 'crown', '왕관 장식', 'r', 'ped', 0.9, 0.9);
        H.R(14.0, 8.6, 0.85, 3.6, 'bar', '음료');
        H.Q(13.45, 10.4, -0.7, 0, 4, 0);
        H.WC(13.3, 18.3, 1.7, 2.7, 12.9, 19.6);
        H.EX(7.5, 20.6); H.EX(0.4, 13.2);
        H.DR(1.2, 19.6, '외투');
        H.GP(10.6, 17.2);
      } }),
    mkMap({ nm: '조용한 도서관', key: 'library', floor: '#34433f', floor2: '#3b4b46', npc: 26,
      wt: { look: 0.36, sit: 0.36, q: 0.07, wc: 0.03, wan: 0.1, exit: 0.08 },
      tip: '「절전 시간」에는 한쪽이 어두워져요 — 경비원 눈에 잘 안 띄어요',
      ev: { k: 'dark', lab: '절전 시간', sub: '한쪽 불이 잠깐 꺼져요', every: 42, dur: 10 },
      f(H) {
        H.R(0.3, 0.3, 4, 0.8, 'shelf'); H.R(5.5, 0.3, 4, 0.8, 'shelf'); H.R(10.7, 0.3, 4, 0.8, 'shelf');
        H.LK(2.3, 1.75, UP); H.LK(7.5, 1.75, UP); H.LK(12.7, 1.75, UP);
        H.R(0.25, 3.6, 0.8, 3.6, 'shelf'); H.R(13.95, 3.6, 0.8, 3.6, 'shelf');
        H.LK(1.7, 5.4, PI); H.LK(13.3, 5.4, 0);
        H.IT(3.6, 4.4, 'mask', '하회탈', 'd', 'ped', 0.9, 0.9);
        H.IT(7.5, 4.4, 'book', '고서', 'd', 'ped', 0.9, 0.9);
        H.IT(11.4, 4.4, 'necklace', '옥 목걸이', 'd', 'ped', 0.9, 0.9);
        const T6 = [[-0.8, -0.98, DN], [0, -0.98, DN], [0.8, -0.98, DN], [-0.8, 0.98, UP], [0, 0.98, UP], [0.8, 0.98, UP]];
        H.TB(4.4, 8.6, 2.6, 1.2, 'ltable', T6); H.TB(10.6, 8.6, 2.6, 1.2, 'ltable', T6);
        H.TB(4.4, 13.3, 2.6, 1.2, 'ltable', T6); H.TB(10.6, 13.3, 2.6, 1.2, 'ltable', T6);
        H.IT(7.5, 10.9, 'map', '옛 지도', 'd', 'ped', 0.9, 0.9);
        H.IT(0.9, 10.9, 'globe', '지구본', 'r', 'ped', 0.9, 0.9);
        H.IT(14.1, 10.9, 'watch', '회중시계', 'l', 'ped', 0.9, 0.9);
        H.IT(2.6, 17.6, 'pen', '금 만년필', 'u', 'case', 1.2, 0.9);
        H.IT(12.2, 17.4, 'gem', '보석 책갈피', 'u', 'case', 1.2, 0.9);
        H.R(6.1, 20.05, 2.8, 0.8, 'counter', '반납');
        H.Q(7.5, 19.6, 0, -0.7, 4, DN);
        H.WC(13.3, 18.6, 1.7, 2.4, 12.9, 19.8);
        H.EX(0.4, 14.9); H.EX(14.6, 14.9);
        H.DR(1.0, 20.0, '외투');
        H.GP(7.5, 7.0);
      } }),
    mkMap({ nm: '놀이공원 광장', key: 'park', floor: '#3c4a3a', floor2: '#44533f', npc: 28,
      wt: { look: 0.36, sit: 0.18, q: 0.1, wc: 0.04, wan: 0.18, exit: 0.1 },
      tip: '「퍼레이드」 때 손님들이 길가로 몰려 구경해요 — 가게들이 텅 비어요',
      ev: { k: 'gat', at: [7.5, 10.5], par: 1, lab: '퍼레이드!', sub: '가운데 길가로 손님들이 몰려 구경해요', every: 44, dur: 13, frac: 0.55, r: 2.2 },
      f(H) {
        H.R(5.3, 1.4, 4.4, 3.4, 'ride', '회전목마');
        H.LK(7.5, 5.5, UP); H.LK(4.6, 3.1, 0); H.LK(10.4, 3.1, PI);
        H.IT(1.1, 3.6, 'doll', '곰 인형', 'r', 'stall', 1.6, 1.9);
        H.IT(13.9, 3.6, 'robot', '태엽 로봇', 'l', 'stall', 1.6, 1.9);
        H.IT(4.2, 7.0, 'glasses', '별 선글라스', 'd', 'case', 1.2, 0.9);
        H.IT(10.8, 7.0, 'fan', '꽃 부채', 'd', 'case', 1.2, 0.9);
        H.IT(1.1, 15.6, 'snowglobe', '스노볼', 'r', 'stall', 1.6, 1.9);
        H.IT(13.9, 15.6, 'choco', '초콜릿 상자', 'l', 'stall', 1.6, 1.9);
        H.IT(7.5, 15.5, 'trophy', '사격 경품', 'u', 'stall', 2.6, 1.2);
        H.BN(4.2, 13.6, 2.2, false, 'a'); H.BN(10.8, 13.6, 2.2, false, 'a');
        H.R(5.9, 20.05, 3.2, 0.85, 'cart', '솜사탕');
        H.Q(7.5, 19.55, 0, -0.7, 4, DN);
        H.WC(13.3, 18.3, 1.7, 2.7, 12.9, 19.6);
        H.R(0.2, 0.2, 0.7, 0.7, 'plant'); H.R(14.1, 0.2, 0.7, 0.7, 'plant');
        H.EX(0.4, 10.5); H.EX(14.6, 10.5); H.EX(3.2, 20.6);
        H.DR(1.3, 12.6, '머리띠');
        H.GP(7.5, 12.6);
      } }),
    mkMap({ nm: '공항 면세점', key: 'airport', floor: '#3b4250', floor2: '#454d5c', npc: 28, tl: '탑승',
      wt: { look: 0.38, sit: 0.24, q: 0.08, wc: 0.04, wan: 0.12, exit: 0.12 },
      tip: '「탑승 안내」 때 손님들이 우르르 탑승구로 드나들어요 — 새 얼굴이 많아져요',
      ev: { k: 'wave', lab: '탑승 안내!', sub: '손님들이 우르르 탑승구로 드나들어요', every: 36, dur: 7, n: 7 },
      f(H) {
        H.R(0, 0, 15, 1.4, 'glass');
        H.EX(3, 1.85, 't'); H.EX(12, 1.85, 't');
        H.R(6.0, 2.4, 3.0, 0.5, 'board', '출발');
        H.LK(6.8, 3.5, UP); H.LK(8.2, 3.5, UP);
        H.IT(1.0, 5.6, 'perfume', '명품 향수', 'r', 'shop', 1.2, 2.0);
        H.IT(14.0, 5.6, 'lipstick', '립스틱 세트', 'l', 'shop', 1.2, 2.0);
        H.IT(7.5, 6.3, 'choco', '초콜릿 상자', 'd', 'shop', 2.4, 1.0);
        H.IT(1.0, 11, 'glasses', '선글라스', 'r', 'shop', 1.2, 2.0);
        H.IT(14.0, 11, 'watch', '명품 시계', 'l', 'shop', 1.2, 2.0);
        H.IT(7.5, 15.4, 'necklace', '다이아 목걸이', 'u', 'case', 1.4, 1.0);
        H.BN(4.6, 9.6, 2.4, false, 'a'); H.BN(10.4, 9.6, 2.4, false, 'a'); H.BN(4.6, 12.4, 2.4, false, 'a'); H.BN(10.4, 12.4, 2.4, false, 'a');
        H.R(9.6, 20.05, 2.8, 0.8, 'counter', '환전');
        H.Q(11, 19.6, 0, -0.7, 4, DN);
        H.WC(0, 18.3, 1.7, 2.7, 2.1, 19.6);
        H.R(14.1, 1.7, 0.7, 0.7, 'plant'); H.R(0.2, 1.7, 0.7, 0.7, 'plant');
        H.EX(7.5, 20.6); H.EX(14.6, 16.6);
        H.DR(4.6, 18.8, '옷 매장');
        H.GP(7.5, 17.6);
      } }),
    mkMap({ nm: '바다 수족관', key: 'aqua', floor: '#2b3c4e', floor2: '#32465a', npc: 26,
      wt: { look: 0.48, sit: 0.18, q: 0.07, wc: 0.03, wan: 0.12, exit: 0.08 },
      tip: '「먹이 주기 쇼」 때 큰 수조 앞으로 손님들이 몰려요',
      ev: { k: 'gat', at: [7.5, 12.9], fp: [7.5, 9.3], lab: '먹이 주기 쇼!', sub: '큰 수조 앞으로 손님들이 몰려요', every: 40, dur: 12, frac: 0.5, r: 2.0 },
      f(H) {
        H.R(0.3, 0.3, 4.2, 1.0, 'tankw'); H.R(5.4, 0.3, 4.2, 1.0, 'tankw'); H.R(10.5, 0.3, 4.2, 1.0, 'tankw');
        H.LK(2.4, 1.95, UP); H.LK(7.5, 1.95, UP); H.LK(12.6, 1.95, UP);
        H.R(4.5, 7.6, 6, 3.4, 'tank');
        H.LK(5.6, 11.65, UP); H.LK(9.4, 11.65, UP); H.LK(7.5, 6.95, DN);
        H.IT(1.0, 5, 'pearl', '흑진주', 'r', 'case', 1.0, 1.4);
        H.IT(14.0, 5, 'coral', '산호 장식', 'l', 'case', 1.0, 1.4);
        H.IT(1.0, 14.6, 'shell', '소라 껍데기', 'r', 'case', 1.0, 1.4);
        H.IT(14.0, 14.6, 'dolphin', '유리 돌고래', 'l', 'case', 1.0, 1.4);
        H.IT(4.4, 17.3, 'snowglobe', '바다 스노볼', 'u', 'case', 1.3, 1.0);
        H.IT(10.6, 17.3, 'doll', '펭귄 인형', 'u', 'case', 1.3, 1.0);
        H.BN(2.7, 9.3, 1.8, true, 'r'); H.BN(12.3, 9.3, 1.8, true, 'l');
        H.R(6.1, 20.05, 2.8, 0.8, 'counter', '기념품');
        H.Q(7.5, 19.6, 0, -0.7, 4, DN);
        H.WC(13.3, 18.3, 1.7, 2.7, 12.9, 19.6);
        H.EX(0.4, 10.4); H.EX(14.6, 10.4); H.EX(3.4, 20.6);
        H.DR(1.6, 18.4, '우비');
        H.GP(7.5, 15.2);
      } }),
  ];
  const WT0 = { look: 0.46, sit: 0.18, q: 0.08, wc: 0.04, wan: 0.16, exit: 0.08, chat: 0.13, ask: 0.025, dr: 0.04 };

  /* ---------- navigation: coarse grid + cached distance fields ---------- */
  function navOf(M) {
    if (M.blk) return M;
    const blk = new Uint8Array(GW * GH);
    for (let gy = 0; gy < GH; gy++) for (let gx = 0; gx < GW; gx++) blk[gy * GW + gx] = solidAt(M, (gx + 0.5) * NAVC, (gy + 0.5) * NAVC, 0.2) ? 1 : 0;
    M.blk = blk; M.ff = new Map();
    M.free = [];
    for (let c = 0; c < GW * GH; c++) {
      if (blk[c]) continue;
      const x = c % GW, y = (c / GW) | 0;
      if (x < 1 || y < 1 || x > GW - 2 || y > GH - 2) continue;
      if (blk[c - 1] || blk[c + 1] || blk[c - GW] || blk[c + GW]) continue;
      M.free.push(c);
    }
    return M;
  }
  const cellOf = (x, y) => clamp((y / NAVC) | 0, 0, GH - 1) * GW + clamp((x / NAVC) | 0, 0, GW - 1);
  const cX = (c) => (c % GW + 0.5) * NAVC, cY = (c) => (((c / GW) | 0) + 0.5) * NAVC;
  function nearFree(M, c) {
    if (!M.blk[c]) return c;
    const x0 = c % GW, y0 = (c / GW) | 0;
    for (let r = 1; r < 8; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
      const x = x0 + dx, y = y0 + dy; if (x < 0 || y < 0 || x >= GW || y >= GH) continue;
      const n = y * GW + x; if (!M.blk[n]) return n;
    }
    return c;
  }
  const DIRS = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];
  function field(M, x, y) {
    const c0 = nearFree(M, cellOf(x, y));
    let f = M.ff.get(c0);
    if (f) return f;
    f = new Float32Array(GW * GH).fill(1e9);
    const hp = [], hd = [];
    const push = (c, d) => { hp.push(c); hd.push(d); let i = hp.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (hd[p] <= hd[i]) break; [hp[p], hp[i]] = [hp[i], hp[p]]; [hd[p], hd[i]] = [hd[i], hd[p]]; i = p; } };
    const pop = () => {
      const c = hp[0], d = hd[0], lc = hp.pop(), ld = hd.pop();
      if (hp.length) { hp[0] = lc; hd[0] = ld; let i = 0; for (;;) { const l = i * 2 + 1, r = l + 1; let m = i; if (l < hp.length && hd[l] < hd[m]) m = l; if (r < hp.length && hd[r] < hd[m]) m = r; if (m === i) break; [hp[m], hp[i]] = [hp[i], hp[m]]; [hd[m], hd[i]] = [hd[i], hd[m]]; i = m; } }
      return [c, d];
    };
    f[c0] = 0; push(c0, 0);
    while (hp.length) {
      const [c, d] = pop(); if (d > f[c]) continue;
      const x0 = c % GW, y0 = (c / GW) | 0;
      for (const [dx, dy, w] of DIRS) {
        const xx = x0 + dx, yy = y0 + dy; if (xx < 0 || yy < 0 || xx >= GW || yy >= GH) continue;
        const n = yy * GW + xx; if (M.blk[n]) continue;
        if (dx && dy && (M.blk[y0 * GW + xx] || M.blk[yy * GW + x0])) continue;
        const nd = d + w; if (nd < f[n]) { f[n] = nd; push(n, nd); }
      }
    }
    if (M.ff.size > 400) M.ff.delete(M.ff.keys().next().value);
    M.ff.set(c0, f);
    return f;
  }
  function losClear(M, x0, y0, x1, y1) {
    const d = hyp(x1 - x0, y1 - y0), n = Math.ceil(d / 0.22);
    for (let i = 1; i < n; i++) { const t = i / n; if (M.blk[cellOf(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)]) return false; }
    return true;
  }
  function waypoint(M, x, y, gx, gy, out) {
    if (losClear(M, x, y, gx, gy)) { out[0] = gx; out[1] = gy; return; }
    const f = field(M, gx, gy);
    let c = nearFree(M, cellOf(x, y));
    out[0] = cX(c); out[1] = cY(c);
    for (let k = 0; k < 7; k++) {
      const x0 = c % GW, y0 = (c / GW) | 0;
      let best = -1, bd = f[c];
      for (const [dx, dy] of DIRS) {
        const xx = x0 + dx, yy = y0 + dy; if (xx < 0 || yy < 0 || xx >= GW || yy >= GH) continue;
        const n = yy * GW + xx; if (M.blk[n]) continue;
        if (dx && dy && (M.blk[y0 * GW + xx] || M.blk[yy * GW + x0])) continue;
        if (f[n] < bd) { bd = f[n]; best = n; }
      }
      if (best < 0) break;
      if (k > 0 && !losClear(M, x, y, cX(best), cY(best))) break;
      c = best; out[0] = cX(c); out[1] = cY(c);
      if (f[c] === 0) { if (losClear(M, x, y, gx, gy)) { out[0] = gx; out[1] = gy; } break; }
    }
  }

  /* ---------- world ---------- */
  function mkPerson(W, i) {
    const R = W.R;
    return { i, kind: 0, seat: -1, x: 7.5, y: 10, vx: 0, vy: 0, a: R() * TAU, fa: null, lk: (R() * NLOOK) | 0, sp: 0.86 + R() * 0.28,
      st: 0, mode: 'do', goal: null, dw: 0, in: 0, gone: 0, rsp: 0, age: R() * 40, wp: [0, 0], wpT: 0, stT: 0, sx: 0, sy: 0,
      rd: 0.15 + R() * 0.55, fr: 0, stl: 0, ch: -1, chT: 0, wcd: 0, ccd: 0, caught: 0, ct: 0, wv: 0, run: 0,
      fol: -1, fside: R() < 0.5 ? 1 : -1, kid: 0, par: -1, hasKid: 0, acc: 0, accJ: -1, chg: 0, ptT: 0, dcd: 0, nzN: 0, ncd: 0, acU: 0, wmv: 0, whId: 0, gtw: 0 };
  }
  function newWorld(st) {
    const M = navOf(MAPS[st.mk] || MAPS[0]);
    const R = rng(st.sd);
    const np = st.np, n = np + st.cr, nk = st.cw === 's' ? 1 : st.cw === 'l' ? 3 : 2;
    const W = { M, R, t: 0, T: st.tm, np, n, pp: [], ps: [], it: M.it.map(() => 0), itT: M.it.map(() => -99), ns: 0, q: st.q, cf: st.cf, cf0: st.cf, tg: st.tg.slice(), th: st.th.slice(),
      lo: M.lk.map((l) => l.sl.map(() => -1)), so: M.seats.map(() => -1), qo: M.qs.map((q) => q.sl.map(() => -1)), gr: [null, null, null],
      ev: null, evT: 20 + R() * 8, evN: 0, wh: null, whN: 0, dark: null, nz: null, nzN: 0, gt: null, gu: GT_N, fx: [], fxN: 0, res: null,
      pt: Array(np).fill(0), sn: Array(np).fill(0), ca: Array(np).fill(0), wr: Array(np).fill(0), wt: Object.assign({}, WT0, M.wt || {}) };
    for (let i = 0; i < n; i++) W.pp.push(mkPerson(W, i));
    const idx = W.pp.map((p) => p.i);
    for (let i = idx.length - 1; i > 0; i--) { const j = (R() * (i + 1)) | 0; const t = idx[i]; idx[i] = idx[j]; idx[j] = t; }
    for (let s = 0; s < np; s++) W.ps[s] = idx[s];
    let gk = 0;
    for (let s = 0; s < np; s++) {
      const p = W.pp[W.ps[s]];
      p.seat = s;
      if (st.th.includes(s)) { p.kind = 1; p.nzN = NZ_N; p.ncd = 6; }
      else { p.kind = 2; p.lk = 1000 + s; p.wcd = 6; const a = gk++ * 2.1; p.x = M.gp[0] + Math.cos(a) * 0.55 * Math.min(1, gk - 1); p.y = M.gp[1] + Math.sin(a) * 0.55 * Math.min(1, gk - 1); p.a = UP; p.mode = 'idle'; }
    }
    // a few children walking with a grown-up (never a thief, never a suspect)
    for (let k = 0; k < nk; k++) {
      let par = -1;
      for (let t = 0; t < 30 && par < 0; t++) { const c = W.pp[(R() * n) | 0]; if (c.kind === 0 && !c.hasKid) par = c.i; }
      if (par < 0) break;
      W.pp[par].hasKid = 1;
      const q = mkPerson(W, W.pp.length); q.kid = 1; q.par = par; q.lk = 2000 + ((R() * NLOOK) | 0); W.pp.push(q);
    }
    W.n = W.pp.length;
    for (const p of W.pp) {
      if (p.kind === 2 || p.kid) continue;
      if (p.kind === 1) {
        let pt = null;
        for (let k = 0; k < 40 && !pt; k++) { const c = M.free[(R() * M.free.length) | 0]; if (hyp(cX(c) - M.gp[0], cY(c) - M.gp[1]) > 4.5) pt = [cX(c), cY(c)]; }
        pt = pt || [cX(M.free[0]), cY(M.free[0])];
        p.x = pt[0]; p.y = pt[1]; p.mode = 'idle'; p.st = 0;
        continue;
      }
      decide(W, p, true);
    }
    for (const p of W.pp) if (p.kid) { const q = W.pp[p.par]; p.x = q.x + 0.45; p.y = q.y + 0.2; pushOut(M, p); }
    for (let k = 0; k < 6; k++) separate(W, 1);
    return W;
  }
  function fx(W, type, a, b, c) { W.fx.push([++W.fxN, type, a | 0, b | 0, c | 0]); if (W.fx.length > 14) W.fx.shift(); }

  function freePt(W, near, minD, maxD) {
    const M = W.M;
    for (let k = 0; k < 40; k++) {
      const c = M.free[(W.R() * M.free.length) | 0], x = cX(c) + (W.R() - 0.5) * 0.3, y = cY(c) + (W.R() - 0.5) * 0.3;
      if (!near) return [x, y];
      const d = hyp(x - near[0], y - near[1]); if (d >= (minD || 0) && d <= (maxD || 99)) return [x, y];
    }
    const c = M.free[(W.R() * M.free.length) | 0]; return [cX(c), cY(c)];
  }
  function openExits(W) { const o = []; W.M.ex.forEach((e, i) => { if (!W.gt || W.gt.e !== i) o.push(e); }); return o.length ? o : W.M.ex; }
  function reserve(W, p, g) {
    if (!g) return;
    if (g.k === 'look') W.lo[g.li][g.si] = p.i;
    else if (g.k === 'sit') W.so[g.s] = p.i;
    else if (g.k === 'q') W.qo[g.q][g.si] = p.i;
    else if (g.k === 'chat' && W.gr[g.g]) W.gr[g.g].m[g.si] = p.i;
  }
  function release(W, p) {
    const g = p.goal; if (!g) return;
    if (g.k === 'look' && W.lo[g.li][g.si] === p.i) W.lo[g.li][g.si] = -1;
    else if (g.k === 'sit' && W.so[g.s] === p.i) W.so[g.s] = -1;
    else if (g.k === 'q' && W.qo[g.q][g.si] === p.i) W.qo[g.q][g.si] = -1;
    else if (g.k === 'chat' && W.gr[g.g] && W.gr[g.g].m[g.si] === p.i) W.gr[g.g].m[g.si] = -1;
  }
  function newLook(W, p) { p.lk = (W.R() * NLOOK) | 0; }
  function standUp(W, p) {
    if (p.st === 2 && p.goal && p.goal.k === 'sit') { p.x = p.goal.x; p.y = p.goal.y; }
    if (p.in) {
      p.in = 0; p.x = W.M.wc.x + (W.R() - 0.5) * 0.3; p.y = W.M.wc.y + (W.R() - 0.5) * 0.3;
      if (p.chg) { p.chg = 0; newLook(W, p); if (p.kind === 1) { p.dcd = DIS_CD; fx(W, 10, p.seat, 0, 0); } }
    }
  }
  function setGoal(W, p, g) {
    if (p.gone || p.caught) return;
    release(W, p); standUp(W, p);
    p.goal = g; p.mode = g ? 'go' : 'idle'; p.st = 0; p.stl = 0; p.wpT = 0; p.stT = 0; p.sx = p.x; p.sy = p.y;
    reserve(W, p, g);
  }
  const gLook = (W, li, si) => { const l = W.M.lk[li], s = l.sl[si]; return { k: 'look', li, si, x: s[0], y: s[1], a: l.a }; };
  const gSeat = (W, s) => { const S = W.M.seats[s]; return { k: 'sit', s, x: S.ax, y: S.ay, a: S.a, sx: S.x, sy: S.y }; };
  const gQ = (W, q, si) => { const Q = W.M.qs[q]; return { k: 'q', q, si, x: Q.sl[si][0], y: Q.sl[si][1], a: si === 0 ? Q.fa : Q.ra }; };
  const chatPos = (G, si) => { const a = G.r + si * TAU / 4; return [G.x + Math.cos(a) * 0.58, G.y + Math.sin(a) * 0.58, a + PI]; };
  const gChat = (W, g, si) => { const c = chatPos(W.gr[g], si); return { k: 'chat', g, si, x: c[0], y: c[1], a: c[2] }; };
  function chatSlot(W, g, self) {
    const G = W.gr[g]; if (!G) return -1;
    const c = [];
    for (let s = 0; s < 4; s++) { if (G.m[s] >= 0 && G.m[s] !== self) continue; const q = chatPos(G, s); if (!solidAt(W.M, q[0], q[1], 0.3)) c.push(s); }
    return c.length ? c[(W.R() * c.length) | 0] : -1;
  }
  function freeSlot(W, li) { const o = W.lo[li]; const c = []; for (let s = 0; s < o.length; s++) if (o[s] < 0) c.push(s); return c.length ? c[(W.R() * c.length) | 0] : -1; }
  function lookOpen(W, li) { const l = W.M.lk[li]; return l.item < 0 || !W.it[l.item]; }
  const guardsOf = (W) => W.pp.filter((q) => q.kind === 2 && !q.gone);

  /* NPC routine: pick what to do next (weighted, nearer things a bit more likely) */
  function decide(W, p, warm) {
    const M = W.M, R = W.R, wt = W.wt;
    if (W.ev && W.ev.k === 'gat' && W.ev.t > 3 && R() < 0.25) { gatherGoal(W, p); if (warm) jumpTo(W, p); return; }
    let r = R() * (wt.look + wt.sit + wt.q + wt.wc + wt.wan + wt.exit + wt.chat + wt.ask + (M.dr.length ? wt.dr : 0));
    let g = null;
    if ((r -= wt.look) < 0) {
      let best = -1, bs = -1;
      for (let li = 0; li < M.lk.length; li++) {
        if (!lookOpen(W, li) || freeSlot(W, li) < 0) continue;
        if (p.goal && p.goal.k === 'look' && p.goal.li === li) continue;
        const s = R() / (1 + hyp(M.lk[li].x - p.x, M.lk[li].y - p.y) / 6);
        if (s > bs) { bs = s; best = li; }
      }
      if (best >= 0) g = gLook(W, best, freeSlot(W, best));
    } else if ((r -= wt.sit) < 0) {
      const c = []; W.so.forEach((o, s) => { if (o < 0) c.push(s); });
      if (c.length) g = gSeat(W, c[(R() * c.length) | 0]);
    } else if ((r -= wt.q) < 0) {
      if (M.qs.length) {
        const q = (R() * M.qs.length) | 0, o = W.qo[q];
        let last = -1; for (let s = 0; s < o.length; s++) if (o[s] >= 0) last = s;
        if (last + 1 < o.length) g = gQ(W, q, last + 1);
      }
    } else if ((r -= wt.wc) < 0) {
      if (M.wc) g = { k: 'wc', x: M.wc.x, y: M.wc.y };
    } else if ((r -= wt.wan) < 0) {
      const pt = freePt(W, [p.x, p.y], 2, 9); g = { k: 'wan', x: pt[0], y: pt[1] };
    } else if ((r -= wt.chat) < 0) { // 대화 무리: join a chatting group or start one
      let best = -1, bd = 9;
      W.gr.forEach((G, gi) => { if (!G || G.t < 4) return; const d = hyp(G.x - p.x, G.y - p.y); if (d < bd && chatSlot(W, gi) >= 0) { bd = d; best = gi; } });
      if (best < 0) {
        const gi = W.gr.indexOf(null);
        if (gi >= 0) for (let k = 0; k < 12; k++) {
          const pt = freePt(W, warm ? null : [p.x, p.y], 1.5, 8);
          if (!solidAt(M, pt[0], pt[1], 0.95)) { W.gr[gi] = { x: pt[0], y: pt[1], r: R() * TAU, m: [-1, -1, -1, -1], t: 16 + R() * 18 }; best = gi; break; }
        }
      }
      if (best >= 0) { const si = chatSlot(W, best); if (si >= 0) g = gChat(W, best, si); }
    } else if ((r -= wt.ask) < 0) { // 길 묻기: walk up to a guard and ask the way
      const gs = guardsOf(W).filter((q) => q.ch < 0);
      if (gs.length && !warm && !p.hasKid) { const q = gs[(R() * gs.length) | 0]; g = { k: 'ask', gi: q.i, x: q.x, y: q.y }; }
    } else if ((r -= (M.dr.length ? wt.dr : 0)) < 0) { // try on a coat / hat at a rack (comes back looking different)
      const d = (R() * M.dr.length) | 0; g = { k: 'dr', d, x: M.dr[d].x + (R() - 0.5) * 0.3, y: M.dr[d].y + (R() - 0.5) * 0.2 };
    } else if (!warm && p.age > 45) {
      const ex = openExits(W), e = ex[(R() * ex.length) | 0]; g = { k: 'exit', x: e.x, y: e.y };
    }
    if (!g) { const pt = freePt(W, [p.x, p.y], 1.5, 8); g = { k: 'wan', x: pt[0], y: pt[1] }; }
    setGoal(W, p, g);
    if (warm) {
      if (g.k === 'ask' || g.k === 'dr') { const pt = freePt(W); p.x = pt[0]; p.y = pt[1]; }
      else if (R() < 0.7) jumpTo(W, p);
      else { const pt = freePt(W); p.x = pt[0]; p.y = pt[1]; }
    }
  }
  function jumpTo(W, p) { const g = p.goal; if (!g) return; p.x = g.x; p.y = g.y; arrive(W, p); p.dw *= 0.2 + W.R() * 0.8; }
  function gatherAt(W, p, cx, cy, r, fxp, fyp, dur, dn, par) {
    const R = W.R;
    let x = cx, y = cy;
    for (let k = 0; k < 12; k++) {
      let xx, yy;
      if (par) { xx = 1.3 + R() * (WU - 2.6); yy = cy + (R() < 0.5 ? -1 : 1) * (1.25 + R() * 0.9); }
      else { const a = R() * TAU, d = 0.7 + R() * (r - 0.7); xx = cx + Math.cos(a) * d; yy = cy + Math.sin(a) * d; }
      if (!solidAt(W.M, xx, yy, 0.32)) { x = xx; y = yy; break; }
    }
    const tx = par ? x : fxp, ty = par ? cy : fyp;
    setGoal(W, p, { k: 'gat', x, y, a: Math.atan2(ty - y, tx - x), u: W.t + dur, dn: dn ? 1 : 0 });
  }
  function gatherGoal(W, p) { const e = W.ev; gatherAt(W, p, e.x, e.y, e.r, e.fx, e.fy, e.t, e.dance, e.par); }
  function arrive(W, p) {
    const g = p.goal, R = W.R;
    p.mode = 'do'; p.vx = 0; p.vy = 0;
    if (p.acc === 1) { // a bribed guest: reaches into the case (looks exactly like a theft)
      const j = p.accJ, it = j >= 0 ? W.M.it[j] : null;
      p.st = 4; p.dw = STEAL_T + 0.4; if (it) p.fa = Math.atan2(it.y - p.y, it.x - p.x);
      return;
    }
    switch (g.k) {
      case 'look': { const u = R(); p.st = u < 0.22 ? 10 : 1; p.fa = g.a; p.dw = 3 + R() * 6; break; }
      case 'sit': p.st = 2; p.x = g.sx; p.y = g.sy; p.fa = g.a; p.a = g.a; p.dw = 8 + R() * 12; break;
      case 'q': p.st = 3; p.fa = g.a; p.dw = g.si === 0 ? 2.5 + R() * 2.5 : 99; break;
      case 'wc': p.in = 1; p.st = 6; if (p.kind === 1) { p.dw = WC_T; p.chg = p.dcd <= 0 ? 1 : 0; } else { p.dw = 4 + R() * 4; p.chg = R() < 0.35 ? 1 : 0; } break;
      case 'chat': p.st = 12; p.fa = g.a; p.dw = 6 + R() * 10; break;
      case 'ask': p.st = 13; p.dw = 2.5 + R() * 1.5; { const q = W.pp[g.gi]; if (q) p.fa = Math.atan2(q.y - p.y, q.x - p.x); } break;
      case 'dr': p.st = 14; p.fa = R() * TAU - PI; p.dw = DIS_T + (p.kind ? 0 : R() * 1.5); if (p.kind === 1) p.chg = p.dcd <= 0 ? 1 : 0; break;
      case 'exit':
        if (p.kind === 0) { p.gone = 1; p.rsp = p.wv ? 0.3 + R() * 1.6 : 2 + R() * 5; p.mode = 'gone'; release(W, p); p.goal = null; }
        else { p.mode = 'idle'; p.st = 0; }
        break;
      case 'gat': p.st = g.dn ? 7 : 1; p.fa = g.a; p.dw = Math.max(0.5, (g.u || W.t + 2) - W.t) + R() * 2; break;
      default: p.st = 0; p.fa = null; p.dw = 0.8 + R() * 2.6; if (p.kind) p.mode = 'idle';
    }
  }
  function respawn(W, p) {
    const M = W.M, R = W.R;
    let ex = openExits(W);
    if (p.wv) { const t = M.ex.filter((e) => e.g === 't'); if (t.length) ex = t; }
    const e = ex[(R() * ex.length) | 0];
    p.gone = 0; p.wv = 0; p.x = e.x + (R() - 0.5) * 0.4; p.y = e.y + (R() - 0.5) * 0.4; p.vx = 0; p.vy = 0;
    p.lk = (R() * NLOOK) | 0; p.sp = 0.86 + R() * 0.28; p.age = 0; p.rd = 0.15 + R() * 0.55; p.goal = null; p.acc = 0; p.accJ = -1; p.chg = 0; p.st = 0; p.fr = 0;
    decide(W, p, false);
  }

  /* ---------- movement ---------- */
  function steer(W, p, tx, ty, spd, h) {
    p.wpT -= h;
    if (p.wpT <= 0 || hyp(p.wp[0] - p.x, p.wp[1] - p.y) < 0.18) { waypoint(W.M, p.x, p.y, tx, ty, p.wp); p.wpT = 0.3; }
    let dx = p.wp[0] - p.x, dy = p.wp[1] - p.y; const d = hyp(dx, dy);
    if (d < 1e-4) { dx = 0; dy = 0; } else { dx /= d; dy /= d; }
    const dg = hyp(tx - p.x, ty - p.y);
    const s = spd * Math.min(1, 0.35 + dg / 0.6);
    accel(p, dx * s, dy * s, h);
  }
  function accel(p, tvx, tvy, h) {
    const k = Math.min(1, h * 7);
    p.vx += (tvx - p.vx) * k; p.vy += (tvy - p.vy) * k;
  }
  function integrate(W, p, h) {
    p.x += p.vx * h; p.y += p.vy * h;
    const sp = hyp(p.vx, p.vy);
    if (sp > 0.25) p.a += wrapA(Math.atan2(p.vy, p.vx) - p.a) * Math.min(1, h * 9);
    else if (p.fa != null) p.a += wrapA(p.fa - p.a) * Math.min(1, h * 6);
    if (p.st !== 2) pushOut(W.M, p);
  }
  function pushOut(M, p) {
    for (const o of M.ob) {
      const nx = clamp(p.x, o.x, o.x + o.w), ny = clamp(p.y, o.y, o.y + o.h);
      let dx = p.x - nx, dy = p.y - ny; const d = hyp(dx, dy);
      if (d >= BR) continue;
      if (d > 1e-5) { p.x = nx + dx / d * BR; p.y = ny + dy / d * BR; continue; }
      const l = p.x - o.x, r = o.x + o.w - p.x, t = p.y - o.y, b = o.y + o.h - p.y, m = Math.min(l, r, t, b);
      if (m === l) p.x = o.x - BR; else if (m === r) p.x = o.x + o.w + BR; else if (m === t) p.y = o.y - BR; else p.y = o.y + o.h + BR;
    }
    p.x = clamp(p.x, BR, WU - BR); p.y = clamp(p.y, BR, HU - BR);
  }
  const solidBody = (p) => !p.gone && !p.in && p.st !== 2 && !(p.caught && p.ct <= 0);
  function separate(W, h) {
    const pp = W.pp, n = pp.length, D = BR * 2;
    for (let i = 0; i < n; i++) {
      const a = pp[i]; if (!solidBody(a)) continue;
      for (let j = i + 1; j < n; j++) {
        const b = pp[j]; if (!solidBody(b)) continue;
        const DD = a.kid || b.kid ? D * 0.75 : D;
        const dx = b.x - a.x, dy = b.y - a.y; if (dx > DD || dx < -DD || dy > DD || dy < -DD) continue;
        const d = hyp(dx, dy); if (d >= DD) continue;
        const wa = a.mode === 'go' || a.ch >= 0 ? 1 : 0.3, wb = b.mode === 'go' || b.ch >= 0 ? 1 : 0.3, ov = (DD - d) * 0.5 * Math.min(1, h * 30);
        const ux = d > 1e-4 ? dx / d : 1, uy = d > 1e-4 ? dy / d : 0, s = wa + wb;
        a.x -= ux * ov * 2 * wa / s; a.y -= uy * ov * 2 * wa / s;
        b.x += ux * ov * 2 * wb / s; b.y += uy * ov * 2 * wb / s;
      }
    }
  }
  function whistleHold(W, p) { // NPCs stand still and turn to the whistle
    const w = W.wh; if (!w || p.in || p.gone || p.caught) return false;
    if (w.age < p.rd) return false;
    p.fa = Math.atan2(w.y - p.y, w.x - p.x);
    accel(p, 0, 0, 0.5);
    return true;
  }
  const FT = [0, 0];
  function followSpot(W, p, q) { // beside the leader (falls back to the other side / behind if blocked)
    const a = q.a, sd = p.fside, px = -Math.sin(a), py = Math.cos(a), off = p.kid ? 0.48 : 0.62;
    const c0x = q.x + px * off * sd - Math.cos(a) * 0.12, c0y = q.y + py * off * sd - Math.sin(a) * 0.12;
    if (!solidAt(W.M, c0x, c0y, 0.28)) { FT[0] = c0x; FT[1] = c0y; return; }
    const c1x = q.x - px * off * sd, c1y = q.y - py * off * sd;
    if (!solidAt(W.M, c1x, c1y, 0.28)) { p.fside = -sd; FT[0] = c1x; FT[1] = c1y; return; }
    FT[0] = q.x - Math.cos(a) * 0.7; FT[1] = q.y - Math.sin(a) * 0.7;
  }
  function followStep(W, p, q, h, vmax) { // walk at the leader's pace and copy what they look at
    followSpot(W, p, q);
    const d = hyp(FT[0] - p.x, FT[1] - p.y), qs = hyp(q.vx, q.vy);
    if (d > 1.2 && !losClear(W.M, p.x, p.y, FT[0], FT[1])) { steer(W, p, FT[0], FT[1], vmax, h); p.fa = null; return d; }
    let tvx = q.vx + (FT[0] - p.x) * 2.2, tvy = q.vy + (FT[1] - p.y) * 2.2;
    const v = hyp(tvx, tvy);
    if (v > vmax) { tvx *= vmax / v; tvy *= vmax / v; }
    if (v < 0.07) { tvx = 0; tvy = 0; }
    accel(p, tvx, tvy, h);
    p.fa = qs < 0.2 && d < 0.4 ? (q.st === 12 && q.goal && q.goal.k === 'chat' ? q.a : q.a) : null;
    return d;
  }
  function queueUp(W, p) { // step forward in a queue when the place ahead is free
    const g = p.goal;
    if (g && g.k === 'q' && g.si > 0 && p.st === 3 && W.qo[g.q][g.si - 1] < 0) {
      const n = gQ(W, g.q, g.si - 1); release(W, p); p.goal = n; reserve(W, p, n); p.mode = 'go'; p.st = 0; p.stT = 0; p.sx = p.x; p.sy = p.y;
      return true;
    }
    return false;
  }

  function goStep(W, p, spd, h) { // walk toward p.goal; arrive when there
    const g = p.goal, d = hyp(g.x - p.x, g.y - p.y);
    if (d < 0.1 || (d < 0.45 && p.stT > 0.8)) { p.x = g.x; p.y = g.y; arrive(W, p); return; }
    steer(W, p, g.x, g.y, spd, h);
    // stuck detection
    p.stT += h;
    if (p.stT > 1.4) {
      const mv = hyp(p.x - p.sx, p.y - p.sy);
      if (mv < 0.25) { p.wpT = 0; p.x += (W.R() - 0.5) * 0.12; p.y += (W.R() - 0.5) * 0.12; p.stuck = (p.stuck || 0) + 1; }
      else p.stuck = 0;
      p.sx = p.x; p.sy = p.y; p.stT = p.stT > 3 ? 0.9 : p.stT - 1.4 + 0.9;
      if (p.stuck > 3) { p.stuck = 0; if (p.kind === 0) { if (p.acc === 1) arrive(W, p); else decide(W, p, false); } else { p.x = clamp(p.x, BR, WU - BR); arrive(W, Object.assign(p, { goal: { k: 'pt', x: p.x, y: p.y } })); } }
    }
  }
  function kidStep(W, p, h) {
    const q = W.pp[p.par];
    if (q.gone) { p.gone = 1; return; }
    if (p.gone) { p.gone = 0; p.x = q.x + 0.35; p.y = q.y + 0.2; p.vx = 0; p.vy = 0; p.lk = 2000 + ((W.R() * NLOOK) | 0); p.a = q.a; }
    if (q.in) { accel(p, 0, 0, h); p.st = 0; return; } // waits by the door
    if (whistleHold(W, p)) return;
    followStep(W, p, q, h, 1.7);
    p.st = hyp(p.vx, p.vy) > 0.25 ? 0 : (q.st === 1 || q.st === 10 || q.st === 11 ? 1 : q.st === 7 ? 7 : 0);
    if (p.st === 0 && q.st === 2 && W.R() < h * 0.6) p.fa = W.R() * TAU - PI;
  }
  function npcStep(W, p, h) {
    if (p.kid) { kidStep(W, p, h); return; }
    if (p.gone) { p.rsp -= h; if (p.rsp <= 0) respawn(W, p); return; }
    p.age += h;
    if (p.fr > 0) { p.fr -= h; accel(p, 0, 0, h); return; }
    if (p.acc !== 1 && whistleHold(W, p)) return;
    if (p.mode === 'go') {
      const g = p.goal;
      if (g.k === 'ask') { // keep walking up to the (moving) guard
        const q = W.pp[g.gi], d = q ? hyp(q.x - p.x, q.y - p.y) : 99;
        if (!q || q.ch >= 0 || q.fr > 0 || p.stT > 8 && d > 3) { decide(W, p, false); return; }
        g.x = q.x + (p.x - q.x) / (d || 1) * 0.78; g.y = q.y + (p.y - q.y) / (d || 1) * 0.78;
        if (d < 0.95) { arrive(W, p); return; }
      }
      goStep(W, p, V_NPC * p.sp, h); return;
    }
    accel(p, 0, 0, h);
    const g = p.goal;
    if (queueUp(W, p)) return;
    if (g && g.k === 'q' && g.si > 0) return;
    if (g && g.k === 'look' && !lookOpen(W, g.li) && p.dw > 1.5 && p.acc !== 1) p.dw = 0.6 + W.R(); // the thing is gone — wander off soon
    if (g && g.k === 'chat' && (!W.gr[g.g] || W.gr[g.g].t <= 0) && p.dw > 1) p.dw = 0.3 + W.R() * 1.2;
    if (g && g.k === 'ask') { const q = W.pp[g.gi]; if (!q || hyp(q.x - p.x, q.y - p.y) > 1.8) p.dw = Math.min(p.dw, 0.3); else p.fa = Math.atan2(q.y - p.y, q.x - p.x); }
    if (p.st === 0 && W.R() < h * 0.4) p.fa = W.R() * TAU - PI;              // idle glance
    if (p.st === 7 && W.R() < h * 2) p.fa = (p.fa || 0) + (W.R() - 0.5) * 1.6; // dancing
    if (p.st === 1 && g && g.k === 'look' && W.R() < h * 0.09) { p.st = 11; p.ptT = 0.9 + W.R() * 1.1; } // point / lean in at the exhibit
    if (p.st === 11) { p.ptT -= h; if (p.ptT <= 0) p.st = 1; }
    p.dw -= h;
    if (p.dw <= 0) {
      if (p.acc === 1) { // the bribed guest pockets the decoy and strolls out with it
        const j = p.accJ;
        if (j >= 0 && !W.it[j]) { W.it[j] = 2; W.itT[j] = W.t; fx(W, 13, j, p.i, 0); }
        p.acc = 2; p.age = 99;
        const ex = openExits(W), e = ex[(W.R() * ex.length) | 0];
        setGoal(W, p, { k: 'exit', x: e.x, y: e.y }); p.sp = Math.max(p.sp, 1.1);
        return;
      }
      if (p.st === 14) newLook(W, p);
      decide(W, p, false);
    }
  }

  /* ---------- players ---------- */
  function snapGoal(W, p, x, y) { // a tap → walk there, or use the nearest exhibit / seat / toilet door / rack / chat group
    const M = W.M;
    if (p.kind === 1) {
      if (M.wc && hyp(x - M.wc.x, y - M.wc.y) < 0.9) return { k: 'wc', x: M.wc.x, y: M.wc.y };
      for (let d = 0; d < M.dr.length; d++) if (hyp(x - M.dr[d].x, y - M.dr[d].y) < 0.75) return { k: 'dr', d, x: M.dr[d].x, y: M.dr[d].y };
      let best = null, bd = 0.85;
      M.lk.forEach((l, li) => {
        const tx = l.item >= 0 ? M.it[l.item].x : l.x - Math.cos(l.a) * 0.6, ty = l.item >= 0 ? M.it[l.item].y : l.y - Math.sin(l.a) * 0.6;
        const d = Math.min(hyp(x - l.x, y - l.y), hyp(x - tx, y - ty));
        if (d < bd) {
          let si = -1, sd = 9;
          l.sl.forEach((s, k) => { const o = W.lo[li][k]; if (o >= 0 && o !== p.i) return; const dd = hyp(s[0] - x, s[1] - y); if (dd < sd) { sd = dd; si = k; } });
          if (si >= 0) { bd = d; best = gLook(W, li, si); }
        }
      });
      if (best) return best;
      M.seats.forEach((S, s) => { const d = Math.min(hyp(x - S.x, y - S.y), hyp(x - S.ax, y - S.ay)); if (d < bd && (W.so[s] < 0 || W.so[s] === p.i)) { bd = d; best = gSeat(W, s); } });
      if (best) return best;
      W.gr.forEach((G, gi) => { if (!G || G.t < 2) return; if (hyp(x - G.x, y - G.y) < 1.0) { const si = chatSlot(W, gi, p.i); if (si >= 0) best = gChat(W, gi, si); } });
      if (best) return best;
    }
    if (solidAt(M, x, y, 0.28)) { const c = nearFree(M, cellOf(x, y)); x = cX(c); y = cY(c); }
    return { k: 'pt', x: clamp(x, BR, WU - BR), y: clamp(y, BR, HU - BR) };
  }
  function thiefSpot(W, p) { // target item whose viewing spot I stand at (−1 if none)
    if (p.mode === 'go' || p.in || p.st === 2 || p.st === 14) return -1;
    for (const j of W.tg) {
      if (W.it[j]) continue;
      const l = W.M.lk[W.M.it[j].li];
      if (hyp(p.x - l.x, p.y - l.y) <= REACH) return j;
    }
    return -1;
  }
  function guardNear(W, x, y, r) { for (const q of W.pp) if (q.kind === 2 && !q.gone && hyp(q.x - x, q.y - y) < r) return true; return false; }
  const TALL = { shelf: 1, room: 1, board: 1, tank: 1, tankw: 1, glass: 1, ride: 1, stage: 1, track: 1 };
  function tallBlock(M, x0, y0, x1, y1) { // only tall things block the view (people see over benches and counters)
    for (const o of M.ob) {
      if (!TALL[o.k]) continue;
      let t0 = 0, t1 = 1; const dx = x1 - x0, dy = y1 - y0;
      const clip = (p, q) => { if (p === 0) return q >= 0; const r = q / p; if (p < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; } return true; };
      if (clip(-dx, x0 - o.x) && clip(dx, o.x + o.w - x0) && clip(-dy, y0 - o.y) && clip(dy, o.y + o.h - y0) && t0 <= t1) return true;
    }
    return false;
  }
  function eyesOn(W, x, y) { // guards who could see this spot right now (distance + no tall obstacle in between)
    let n = 0;
    for (const q of W.pp) if (q.kind === 2 && !q.gone && !(q.fr > 0) && hyp(q.x - x, q.y - y) < 6 && !tallBlock(W.M, q.x, q.y, x, y)) n++;
    return n;
  }
  function autoLook(W, p) { // standing next to an exhibit = looking at it (same pose as everybody else)
    if (p.mode === 'go' || p.st !== 0 || p.in) return;
    for (const l of W.M.lk) if (hyp(p.x - l.x, p.y - l.y) < 0.7) { p.st = 1; p.fa = l.a; return; }
  }
  const TACTS = ['fol', 'pho', 'sit', 'que', 'dis', 'noi', 'acc', 'unfol'];
  function thiefAct(W, p, a, arg) { // the thief's blending tools (validated here, on the host)
    const M = W.M, R = W.R;
    if (p.st === 4 || TACTS.indexOf(a) < 0) return;
    const no = (c) => fx(W, 15, p.seat, c, 0);
    switch (a) {
      case 'unfol': if (p.fol >= 0) { p.fol = -1; p.mode = 'idle'; } return;
      case 'fol': {
        if (p.fol >= 0 && arg == null) { p.fol = -1; p.mode = 'idle'; fx(W, 14, p.seat, 3, 0); return; }
        let b = -1, bd = 2.8;
        if (arg != null && W.pp[arg] && W.pp[arg].kind === 0) b = arg | 0;
        else for (const q of W.pp) if (q.kind === 0 && !q.kid && !q.gone && !q.in && q.acc !== 1) { const d = hyp(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; b = q.i; } }
        if (b < 0) { no(1); return; }
        setGoal(W, p, null); p.fol = b; p.mode = 'fol'; p.fside = R() < 0.5 ? 1 : -1;
        fx(W, 14, p.seat, 4, b);
        return;
      }
      case 'pho': {
        setGoal(W, p, null); p.fol = -1; p.vx *= 0.3; p.vy *= 0.3;
        let best = null, bd = 4.5;
        for (const l of M.lk) { const d = hyp(l.x - p.x, l.y - p.y); if (d < bd) { bd = d; best = l; } }
        if (best) { const tx = best.x + Math.cos(best.a) * 1.1, ty = best.y + Math.sin(best.a) * 1.1; p.fa = Math.atan2(ty - p.y, tx - p.x); }
        p.st = 10; p.dw = 3 + R() * 1.5; p.mode = 'idle';
        return;
      }
      case 'sit': {
        let b = -1, bd = 8;
        W.so.forEach((o, s) => { if (o < 0) { const S = M.seats[s], d = hyp(S.ax - p.x, S.ay - p.y); if (d < bd) { bd = d; b = s; } } });
        if (b < 0) { no(2); return; }
        p.fol = -1; setGoal(W, p, gSeat(W, b));
        return;
      }
      case 'que': {
        let b = null, bd = 14;
        M.qs.forEach((Q, q) => {
          const o = W.qo[q]; let last = -1; for (let s = 0; s < o.length; s++) if (o[s] >= 0 && o[s] !== p.i) last = s;
          if (last + 1 < o.length) { const sl = Q.sl[last + 1], d = hyp(sl[0] - p.x, sl[1] - p.y); if (d < bd) { bd = d; b = gQ(W, q, last + 1); } }
        });
        if (!b) { no(3); return; }
        p.fol = -1; setGoal(W, p, b);
        return;
      }
      case 'dis': { // walk to the nearest toilet door / coat rack and change there
        if (p.dcd > 0) { no(4); return; }
        let b = null, bd = 1e9;
        if (M.wc) { bd = hyp(M.wc.x - p.x, M.wc.y - p.y); b = { k: 'wc', x: M.wc.x, y: M.wc.y }; }
        M.dr.forEach((D, di) => { const d = hyp(D.x - p.x, D.y - p.y); if (d < bd) { bd = d; b = { k: 'dr', d: di, x: D.x, y: D.y }; } });
        if (!b) return;
        p.fol = -1; setGoal(W, p, b);
        return;
      }
      case 'noi': { // plant a noise maker: it goes off a few seconds later and draws the crowd there
        if (p.nzN <= 0 || p.ncd > 0 || W.nz) { no(5); return; }
        p.nzN--; p.ncd = NZ_CD; W.nzN++;
        W.nz = { x: p.x, y: p.y, f: NZ_F, t: 0, s: p.seat, k: (R() * 3) | 0, id: W.nzN };
        fx(W, 16, p.seat, 0, 0);
        return;
      }
      case 'acc': { // bribe the guest next to me: they fake a theft somewhere else and walk out with a decoy
        if (p.acU) { no(6); return; }
        let b = null, bd = 1.9;
        for (const q of W.pp) if (q.kind === 0 && !q.kid && !q.hasKid && !q.gone && !q.in && q.acc === 0 && !(q.goal && q.goal.k === 'exit')) { const d = hyp(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; b = q; } }
        if (!b) { no(7); return; }
        let c = [];
        M.it.forEach((it, j) => { if (W.it[j] || W.tg.includes(j)) return; const l = M.lk[it.li]; if (hyp(l.x - p.x, l.y - p.y) >= 4) c.push(j); });
        if (!c.length) M.it.forEach((it, j) => { if (!W.it[j] && !W.tg.includes(j)) c.push(j); });
        let j = c.length ? c[(R() * c.length) | 0] : -1, li = j >= 0 ? M.it[j].li : -1;
        if (li < 0) { const ls = []; M.lk.forEach((l, k) => { if (l.item < 0 && hyp(l.x - p.x, l.y - p.y) >= 3) ls.push(k); }); if (!ls.length) { no(8); return; } li = ls[(R() * ls.length) | 0]; }
        p.acU = 1; b.acc = 1; b.accJ = j; b.fr = 0; b.age = 0;
        setGoal(W, b, slotGoal(W, li, b)); b.sp = Math.max(b.sp, 1.0);
        fx(W, 17, p.seat, b.i, j);
        return;
      }
    }
  }
  function thiefStep(W, p, In, h) {
    if (p.gone) return;
    if (p.caught) { p.ct -= h; accel(p, 0, 0, h); if (p.ct <= 0) { p.gone = 1; release(W, p); } return; }
    if (p.fr > 0) p.fr -= h;
    if (p.dcd > 0) p.dcd -= h;
    if (p.ncd > 0) p.ncd -= h;
    const fresh = !!(In.tap || In.goal);
    if (p.in) { p.dw -= h; p.vx = 0; p.vy = 0; In.tap = null; In.goal = null; In.act = null; if (p.dw <= 0) { standUp(W, p); p.goal = null; p.mode = 'idle'; p.st = 0; } return; }
    const stick = hyp(In.ax || 0, In.ay || 0) > 0.15;
    if (In.act) { const a = In.act, g = In.arg; In.act = null; In.arg = null; thiefAct(W, p, a, g); }
    if (In.tap) { p.fol = -1; setGoal(W, p, snapGoal(W, p, In.tap[0], In.tap[1])); In.tap = null; }
    if (In.goal) { p.fol = -1; setGoal(W, p, In.goal); In.goal = null; }
    const base = In.spd || V_TW;
    p.run = In.rn ? 1 : 0;
    const spd = p.run ? V_RUN : base;
    // the whistle: like every guest, freeze and turn round — unless the player deliberately moves
    if (W.wh && !In.nofz) {
      if (p.whId !== W.whN) { p.whId = W.whN; p.wmv = 0; }
      if (fresh || stick) p.wmv = 1;
      if (!p.wmv && W.wh.age > 0.35 && !In.hold) {
        accel(p, 0, 0, h * 2);
        if (p.st === 0 || p.st === 10) p.fa = Math.atan2(W.wh.y - p.y, W.wh.x - p.x);
        integrate(W, p, h); return;
      }
    }
    // stealing
    const j = thiefSpot(W, p);
    if (In.hold && j >= 0 && !stick && !guardNear(W, p.x, p.y, BLOCK_R)) {
      p.st = 4; p.stl += h; accel(p, 0, 0, h);
      const it = W.M.it[j]; p.fa = Math.atan2(it.y - p.y, it.x - p.x);
      if (p.stl >= STEAL_T) {
        p.stl = 0; p.st = 1; W.it[j] = 1; W.itT[j] = W.t; W.ns++; W.sn[p.seat]++; W.pt[p.seat] += 1;
        fx(W, 1, j, p.seat, 0);
        if (W.ns === W.q) fx(W, 5, 0, 0, 0);
      }
      integrate(W, p, h); return;
    }
    if (p.st === 4) { p.st = 1; p.stl = 0; }
    p.stl = 0;
    if (In.stop) { accel(p, 0, 0, h); if ((p.st === 0 || p.st === 10) && W.wh) p.fa = Math.atan2(W.wh.y - p.y, W.wh.x - p.x); integrate(W, p, h); return; }
    if (p.goal && p.goal.k === 'chat' && !W.gr[p.goal.g] && p.st === 12) { p.goal = null; p.st = 0; }
    if (stick) {
      if (p.goal || p.st === 2) setGoal(W, p, null);
      p.fol = -1;
      const m = Math.min(1, hyp(In.ax, In.ay));
      const s = (p.run ? V_RUN : base) * (m < 0.95 ? m : 1);
      accel(p, In.ax / (hyp(In.ax, In.ay) || 1) * s, In.ay / (hyp(In.ax, In.ay) || 1) * s, h);
      p.st = 0; p.mode = 'idle'; p.fa = null;
    } else if (p.mode === 'go' && p.goal) {
      goStep(W, p, spd, h);
    } else if (p.fol >= 0) {
      const q = W.pp[p.fol];
      if (!q || q.gone || q.in || q.caught || q.kind !== 0 || q.acc === 1) { p.fol = -1; p.mode = 'idle'; fx(W, 14, p.seat, 0, 0); accel(p, 0, 0, h); }
      else if (q.mode !== 'go' && q.goal && q.goal.k === 'chat' && q.st === 12 && W.gr[q.goal.g] && chatSlot(W, q.goal.g, p.i) >= 0) {
        p.fol = -1; setGoal(W, p, gChat(W, q.goal.g, chatSlot(W, q.goal.g, p.i))); fx(W, 14, p.seat, 1, 0);
      } else if (q.st === 2) { // they sat down → take a free seat next to them, if any
        let b = -1, bd = 1.7;
        W.so.forEach((o, s) => { if (o < 0) { const S = W.M.seats[s], d = hyp(S.x - q.x, S.y - q.y); if (d < bd) { bd = d; b = s; } } });
        if (b >= 0) { p.fol = -1; setGoal(W, p, gSeat(W, b)); fx(W, 14, p.seat, 2, 0); }
        else followStep(W, p, q, h, V_FOL);
      } else {
        followStep(W, p, q, h, V_FOL);
        p.st = hyp(p.vx, p.vy) > 0.25 ? 0 : (q.st === 1 || q.st === 10 || q.st === 11 || q.st === 13 ? 1 : q.st === 7 ? 7 : 0);
      }
    } else {
      accel(p, 0, 0, h);
      if (p.st === 10 || p.st === 14) {
        p.dw -= h;
        if (p.dw <= 0) {
          if (p.st === 14 && p.chg) { p.chg = 0; newLook(W, p); p.dcd = DIS_CD; fx(W, 10, p.seat, 1, 0); }
          p.st = 0; p.goal = null; p.mode = 'idle';
        }
      } else if (p.goal && p.goal.k === 'q' && p.st === 3) {
        if (!queueUp(W, p) && p.goal.si === 0) { p.dw -= h; if (p.dw <= 0) { const pt = freePt(W, [p.x, p.y], 1.2, 2.6); setGoal(W, p, { k: 'pt', x: pt[0], y: pt[1] }); } }
      } else autoLook(W, p);
    }
    integrate(W, p, h);
    if (W.q && W.ns >= W.q) {
      let blocked = false;
      W.M.ex.forEach((e, ei) => {
        if (W.res || hyp(p.x - e.x, p.y - e.y) >= 0.75) return;
        if (W.gt && W.gt.e === ei) { blocked = true; return; }
        endRound(W, 't', 'esc', p.seat); fx(W, 7, p.i, p.seat, 0);
      });
      if (blocked && !p.gtw) { p.gtw = 1; fx(W, 15, p.seat, 9, 0); } else if (!blocked) p.gtw = 0;
    }
  }
  function startChase(W, g, ti) {
    const q = W.pp[ti];
    if (!q || q === g || q.kind === 2 || q.kid || q.gone || q.in || q.caught || W.cf <= 0 || g.fr > 0) return false;
    for (const o of W.pp) if (o !== g && o.kind === 2 && o.ch === ti) return false;
    g.ch = ti; g.chT = 0; g.goal = null; g.mode = 'idle';
    return true;
  }
  function useCctv(W, g) { // replay the most recent theft the guards know about (cooldown per guard)
    if (g.ccd > 0) return false;
    let j = -1, bt = -1;
    W.it.forEach((v, k) => { const age = W.t - W.itT[k]; if (v && age >= ALERT_D && age <= ALERT_D + CC_WIN && W.itT[k] > bt) { bt = W.itT[k]; j = k; } });
    if (j < 0) { fx(W, 15, g.seat, 10, 0); return false; }
    g.ccd = CC_CD;
    fx(W, 11, g.seat, j, Math.round((W.t - W.itT[j]) * 10));
    return j;
  }
  function useGate(W, g) { // 검문: close the exit nearest to me for a while
    if (W.gu <= 0) { fx(W, 15, g.seat, 11, 0); return false; }
    let b = -1, bd = 1e9;
    W.M.ex.forEach((e, i) => { const d = hyp(e.x - g.x, e.y - g.y); if (d < bd) { bd = d; b = i; } });
    if (b < 0) return false;
    W.gu--; W.gt = { e: b, t: GT_T };
    fx(W, 18, g.seat, b, 0);
    return true;
  }
  function guardStep(W, g, In, h) {
    if (g.wcd > 0) g.wcd -= h;
    if (g.ccd > 0) g.ccd -= h;
    if (g.fr > 0) { g.fr -= h; g.st = 8; accel(g, 0, 0, h); integrate(W, g, h); In.wh = 0; In.cc = 0; In.gt = 0; if (g.fr <= 0) g.st = 0; return; }
    if (In.wh) { In.wh = 0; if (g.wcd <= 0 && !W.wh) { W.whN++; W.wh = { t: WHIS_T, age: 0, g: g.i, x: g.x, y: g.y }; g.wcd = WHIS_CD; W.whLast = W.t; fx(W, 4, g.i, g.seat, 0); } }
    if (In.cc) { In.cc = 0; useCctv(W, g); }
    if (In.gt) { In.gt = 0; useGate(W, g); }
    if (In.arr != null) { const a = In.arr; In.arr = null; if (a < 0) { if (g.ch >= 0) { g.ch = -1; fx(W, 8, g.seat, 1, 0); } } else startChase(W, g, a); }
    if (In.tap) { g.ch = -1; const sg = snapGoal(W, g, In.tap[0], In.tap[1]); g.goal = sg; g.mode = 'go'; g.wpT = 0; g.stT = 0; g.sx = g.x; g.sy = g.y; In.tap = null; }
    if (In.goal) { g.goal = In.goal; g.mode = 'go'; g.wpT = 0; g.stT = 0; g.sx = g.x; g.sy = g.y; In.goal = null; }
    const stick = hyp(In.ax || 0, In.ay || 0) > 0.15;
    if (g.ch >= 0) {
      const q = W.pp[g.ch];
      g.chT += h;
      if (!q || q.gone || q.in || q.caught || W.cf <= 0) { g.ch = -1; fx(W, 8, g.seat, 0, 0); g.st = 0; }
      else if (g.chT > CH_MAX) { g.ch = -1; fx(W, 8, g.seat, 2, 0); g.st = 0; }
      else {
        g.st = 5;
        const d = hyp(q.x - g.x, q.y - g.y);
        if (d < CATCH_R) { resolveArrest(W, g, q); }
        else { steer(W, g, q.x, q.y, V_CHASE, h); integrate(W, g, h); return; }
      }
    }
    if (stick) {
      g.goal = null; g.mode = 'idle'; g.ch = -1;
      const m = hyp(In.ax, In.ay), s = V_GUARD * Math.min(1, m);
      accel(g, In.ax / m * s, In.ay / m * s, h); g.st = 0; g.fa = null;
    } else if (g.mode === 'go' && g.goal) {
      const G = g.goal, d = hyp(G.x - g.x, G.y - g.y);
      if (d < 0.12) { g.mode = 'idle'; g.goal = null; g.vx = 0; g.vy = 0; }
      else { steer(W, g, G.x, G.y, V_GUARD, h); g.stT += h; if (g.stT > 6) { g.mode = 'idle'; g.goal = null; } }
      g.st = 0;
    } else { accel(g, 0, 0, h); if (g.st !== 8) g.st = 0; }
    integrate(W, g, h);
  }
  function resolveArrest(W, g, q) {
    g.ch = -1; g.vx = 0; g.vy = 0; W.cf--;
    if (q.kind === 1) {
      q.caught = 1; q.ct = 1.8; q.st = 9; q.vx = 0; q.vy = 0; q.fol = -1; release(W, q); q.goal = null; q.mode = 'idle';
      W.pt[g.seat] += 3; W.ca[g.seat]++;
      fx(W, 2, g.seat, q.i, q.seat);
      if (W.th.every((s) => W.pp[W.ps[s]].caught)) endRound(W, 'g', 'caught', g.seat);
    } else {
      g.fr = FREEZE_T; g.st = 8; W.pt[g.seat] -= 2; W.wr[g.seat]++;
      if (q.kind === 0) { q.fr = 1.6; q.fa = Math.atan2(g.y - q.y, g.x - q.x); }
      fx(W, 3, g.seat, q.i, 0);
    }
  }
  function endRound(W, w, why, who) {
    if (W.res) return;
    W.res = { w, why, who: who == null ? -1 : who };
    for (let s = 0; s < W.np; s++) {
      const p = W.pp[W.ps[s]];
      if (w === 't' && p.kind === 1 && !p.caught) W.pt[s] += 3;
      if (w === 'g' && p.kind === 2) W.pt[s] += 2;
    }
  }

  /* ---------- map events ---------- */
  function eventStep(W, h) {
    const M = W.M, E = M.ev, R = W.R;
    if (W.wh) { W.wh.age += h; W.wh.t -= h; if (W.wh.t <= 0) W.wh = null; }
    if (W.gt) { W.gt.t -= h; if (W.gt.t <= 0) W.gt = null; }
    for (let gi = 0; gi < W.gr.length; gi++) { const G = W.gr[gi]; if (!G) continue; G.t -= h; if (G.t <= 0 && G.m.every((v) => v < 0)) W.gr[gi] = null; else if (G.t < -20) W.gr[gi] = null; }
    if (W.nz) { // 소란: fuse, then the crowd (and maybe a guard) drifts over to look
      const z = W.nz;
      if (z.f > 0) {
        z.f -= h;
        if (z.f <= 0) {
          z.t = NZ_T; fx(W, 12, Math.round(z.x * 10), Math.round(z.y * 10), z.k);
          for (const p of W.pp) {
            if (p.kind !== 0 || p.kid || p.gone || p.in || p.acc === 1 || (p.goal && (p.goal.k === 'exit' || p.goal.k === 'q'))) continue;
            const d = hyp(p.x - z.x, p.y - z.y);
            if (d < 7.5 && R() < (p.st === 2 ? 0.35 : 0.75)) gatherAt(W, p, z.x, z.y, 1.7, z.x, z.y, NZ_T - 1 + R() * 2, 0, 0);
          }
        }
      } else { z.t -= h; if (z.t <= 0) W.nz = null; }
    }
    if (W.ev) { W.ev.t -= h; if (W.ev.t <= 0) { W.ev = null; W.dark = null; } return; }
    if (!E || W.t < W.evT) return;
    W.evT = W.t + E.every + (R() - 0.5) * 8;
    W.evN++;
    if (E.k === 'gat') {
      let x, y, fxp, fyp, pi = -1;
      if (E.at === 'item') {
        const open = []; M.it.forEach((it, j) => { if (!W.it[j]) open.push(j); });
        if (!open.length) return;
        const j = open[(R() * open.length) | 0], l = M.lk[M.it[j].li];
        fxp = M.it[j].x; fyp = M.it[j].y; pi = j;
        // stand back from the case a little
        const dd = hyp(l.x - fxp, l.y - fyp) || 1;
        x = l.x + (l.x - fxp) / dd * 0.9; y = l.y + (l.y - fyp) / dd * 0.9;
      } else { x = E.at[0]; y = E.at[1]; fxp = E.fp ? E.fp[0] : x; fyp = E.fp ? E.fp[1] : y; }
      W.ev = { k: 'gat', x, y, fx: fxp, fy: fyp, r: E.r, t: E.dur, dance: E.dance ? 1 : 0, par: E.par ? 1 : 0, j: pi };
      for (const p of W.pp) {
        if (p.kind !== 0 || p.kid || p.gone || p.in || p.acc === 1 || (p.goal && (p.goal.k === 'exit' || (p.goal.k === 'q' && p.st === 3)))) continue;
        if (R() < E.frac) gatherGoal(W, p);
      }
      fx(W, 6, 1, pi, 0);
    } else if (E.k === 'wave') {
      W.ev = { k: 'wave', t: E.dur };
      const tex = M.ex.filter((e) => e.g === 't');
      let n = 0;
      for (const p of W.pp) {
        if (n >= E.n) break;
        if (p.kind !== 0 || p.kid || p.gone || p.in || p.st === 2 || p.acc === 1 || R() < 0.4) continue;
        const e = tex[(R() * tex.length) | 0]; p.wv = 1; setGoal(W, p, { k: 'exit', x: e.x, y: e.y }); n++;
      }
      for (const p of W.pp) if (p.kind === 0 && p.gone && !p.kid) { p.wv = 1; p.rsp = Math.min(p.rsp, 0.2 + R() * 1.5); }
      fx(W, 6, 2, 0, 0);
    } else if (E.k === 'dark') {
      const left = R() < 0.5;
      W.ev = { k: 'dark', t: E.dur };
      W.dark = { x: left ? 0 : WU / 2, y: 0, w: WU / 2, h: HU };
      fx(W, 6, 3, left ? 0 : 1, 0);
    }
  }

  /* ---------- world tick ---------- */
  function tickWorld(W, dt, inputs, ais) {
    if (W.res) return 0;
    W.acc = (W.acc || 0) + Math.min(dt, 1);
    let guard = 0;
    while (W.acc >= SUB && guard++ < 40) {
      W.acc -= SUB;
      stepWorld(W, SUB, inputs, ais);
      if (W.res) { W.acc = 0; break; }
    }
    return guard;
  }
  function stepWorld(W, h, inputs, ais) {
    W.t += h;
    if (!W.hist) W.hist = [];
    if (!W.hist.length || W.t - W.hist[W.hist.length - 1].t >= 0.5) { // short memory of where everybody stood (what the CCTV recorded)
      const n = W.pp.length, e = W.hist.length >= 20 ? W.hist.shift() : { x: new Float32Array(n), y: new Float32Array(n), lk: new Int32Array(n), st: new Uint8Array(n) };
      e.t = W.t; for (let i = 0; i < n; i++) { const p = W.pp[i]; e.x[i] = p.x; e.y[i] = p.y; e.lk[i] = p.gone || p.in ? -1 : p.lk; e.st[i] = p.st; }
      W.hist.push(e);
    }
    eventStep(W, h);
    for (const p of W.pp) {
      if (p.kind === 0) { npcStep(W, p, h); if (!p.gone && p.st !== 2 && !p.in) integrate(W, p, h); continue; }
      let In = inputs[p.seat];
      if (ais && ais[p.seat]) In = ais[p.seat](W, p, h) || In;
      if (!In) In = NOIN;
      if (p.kind === 1) thiefStep(W, p, In, h); else guardStep(W, p, In, h);
      if (W.res) return;
    }
    separate(W, h);
    for (const p of W.pp) if (solidBody(p) && p.st !== 2) pushOut(W.M, p);
    if (W.t >= W.T) endRound(W, 'g', 'time', -1);
  }
  const NOIN = { ax: 0, ay: 0 };

  /* ---------- AI: thief (imitates the crowd — imperfectly on 쉬움/보통) ---------- */
  const TC = [null,
    { spd: 1.36, run: 0.18, dw: [0.4, 1.4], crowd: 0, gR: BLOCK_R, pat: 0, decoy: 0, wc: 0, rx: [0.8, 1.6], ign: 0.55, loiter: 0.35, sit: 0, fol: 0, nz: 0, acc: 0, pho: 0 },
    { spd: 1.2, run: 0, dw: [1.2, 2.8], crowd: 1, gR: 2.2, pat: 7, decoy: 0.3, wc: 0.45, rx: [0.6, 1.1], ign: 0.12, loiter: 0.1, sit: 0.12, fol: 0.2, nz: 0.15, acc: 0.12, pho: 0.3 },
    { spd: 1.07, run: 0, dw: [2.2, 5], crowd: 1, gR: 2.9, pat: 9, decoy: 0.5, wc: 0.85, rx: [0.22, 0.5], ign: 0, loiter: 0, sit: 0.25, fol: 0.5, nz: 0.55, acc: 0.5, pho: 0.4 },
  ];
  const rr = (R, a) => a[0] + R() * (a[1] - a[0]);
  function crowdAt(W, x, y, r, self) {
    let n = 0;
    for (const q of W.pp) if (q !== self && q.kind !== 2 && !q.gone && !q.in && !q.caught && hyp(q.x - x, q.y - y) < r) n++;
    return n;
  }
  function guardCount(W, x, y, r) { let n = 0; for (const q of W.pp) if (q.kind === 2 && hyp(q.x - x, q.y - y) < r) n++; return n; }
  function slotGoal(W, li, p) {
    const s = freeSlot(W, li);
    if (s >= 0) return gLook(W, li, s);
    for (let k = 0; k < W.lo[li].length; k++) if (W.lo[li][k] === p.i) return gLook(W, li, k);
    const l = W.M.lk[li]; return { k: 'pt', x: l.x - Math.cos(l.a) * 0.5, y: l.y - Math.sin(l.a) * 0.5 };
  }
  const inDark = (W, q) => !!W.dark && q.x >= W.dark.x && q.x <= W.dark.x + W.dark.w;
  function aiThief(W, p, m, lv, h) {
    const C = TC[lv] || TC[2], R = W.R, M = W.M;
    const In = m.In || (m.In = { ax: 0, ay: 0, rn: 0, hold: 0, spd: C.spd, goal: null, stop: 0, nofz: 1, act: null, arg: null });
    In.hold = 0; In.stop = 0; In.spd = C.spd;
    if (p.caught || p.gone) return In;
    if (W.sn[p.seat] !== (m.sn || 0)) { m.sn = W.sn[p.seat]; m.s = 'after'; }
    if (p.in) { m.s = 'wcin'; return In; }
    if (m.s === 'wcin') m.s = 'pick';
    // the whistle: everybody freezes and turns — do the same (after a reaction time)
    if (W.wh) {
      if (m.wh !== W.wh) { m.wh = W.wh; m.rx = rr(R, C.rx); m.ign = R() < C.ign; }
      if (!m.ign && W.wh.age > m.rx) { In.stop = 1; return In; }
    }
    // being chased: hide in the toilet if it is close, otherwise keep calm (쉬움 runs)
    let ch = null; for (const g of W.pp) if (g.kind === 2 && g.ch === p.i) ch = g;
    if (ch) {
      const d = hyp(ch.x - p.x, ch.y - p.y);
      if (lv >= 2 && M.wc && hyp(p.x - M.wc.x, p.y - M.wc.y) < Math.min(3.5, d * 1.2) && !(p.goal && p.goal.k === 'wc')) { In.goal = { k: 'wc', x: M.wc.x, y: M.wc.y }; m.s = 'wc'; }
      In.rn = lv === 1 || d < 2 ? 1 : 0;
      if (lv === 1 && p.mode !== 'go') { const pt = freePt(W, [ch.x, ch.y], 5, 30); In.goal = { k: 'pt', x: pt[0], y: pt[1] }; }
      return In;
    }
    In.rn = m.run ? 1 : 0;
    // quota reached → walk out (an exit without a checkpoint)
    if (W.ns >= W.q) {
      const closed = W.gt && M.ex[W.gt.e];
      if (m.s !== 'esc' || p.mode !== 'go' || (closed && p.goal && hyp(p.goal.x - closed.x, p.goal.y - closed.y) < 0.5)) {
        m.s = 'esc';
        let best = null, bs = -1e9;
        for (const e of openExits(W)) {
          let gd = 99; for (const g of W.pp) if (g.kind === 2) gd = Math.min(gd, hyp(g.x - e.x, g.y - e.y));
          const sc = lv === 1 ? -hyp(e.x - p.x, e.y - p.y) : lv === 2 ? -hyp(e.x - p.x, e.y - p.y) + Math.min(gd, 4) * 2 : gd * 1.5 - hyp(e.x - p.x, e.y - p.y) * 0.5;
          if (sc > bs) { bs = sc; best = e; }
        }
        In.goal = { k: 'pt', x: best.x, y: best.y };
        m.run = lv === 1 && R() < 0.6;
      }
      return In;
    }
    switch (m.s) {
      case 'steal': {
        const j = thiefSpot(W, p);
        if (j < 0 || guardNear(W, p.x, p.y, lv === 3 ? 2.2 : BLOCK_R)) { m.s = 'at'; m.w = 0.8 + R() * 2; m.wait = m.wait || 0; break; }
        In.hold = 1; return In;
      }
      case 'fol': { // walking along with a guest who is heading to my target
        m.fT += h;
        const q = W.pp[p.fol];
        if (p.fol < 0 || !q) { m.s = 'pick'; break; }
        const j = thiefSpot(W, p);
        if (j === m.fj && hyp(p.vx, p.vy) < 0.2) { In.act = 'unfol'; m.s = 'at'; m.w = rr(R, C.dw); m.wait = 0; return In; }
        if (!q.goal || q.goal.k !== 'look' || q.goal.li !== M.it[m.fj].li || m.fT > 22 || W.it[m.fj]) { In.act = 'unfol'; m.s = 'pick'; return In; }
        return In;
      }
      case 'go': case 'decoy': case 'loiter': case 'wc':
        if (p.mode === 'go') return In;
        if (m.s === 'wc') { if (p.st === 14) return In; m.s = 'pick'; break; }
        m.s = m.s === 'go' ? 'at' : m.s + '_at'; m.w = m.s === 'loiter_at' ? 2 + R() * 2.5 : rr(R, C.dw) * (m.s === 'at' ? 1 : 1.3); m.wait = 0; m.run = 0;
        if (m.s !== 'at' && R() < C.pho) In.act = 'pho';
        return In;
      case 'at': {
        m.w -= h; m.wait += h;
        const j = thiefSpot(W, p);
        if (j < 0) { m.s = 'pick'; break; }
        const gR = lv === 1 ? BLOCK_R : C.gR;
        if (lv >= 2 && m.wait > 1.2 && guardNear(W, p.x, p.y, BLOCK_R) && R() < h * (lv === 3 ? 0.9 : 0.4)) { m.s = 'pick'; m.noTarget = 1; break; }
        const ok = !guardNear(W, p.x, p.y, m.wait > C.pat ? BLOCK_R + 0.1 : gR) && (crowdAt(W, p.x, p.y, 1.4, p) >= C.crowd || m.wait > C.pat) && !W.wh && (lv < 3 || !W.dark || inDark(W, p) || m.wait > 4);
        if (m.w <= 0 && ok) { m.s = 'steal'; In.hold = 1; return In; }
        if (m.wait > C.pat * 2 + 8) { m.s = 'pick'; m.noTarget = 1; }
        return In;
      }
      case 'decoy_at': case 'loiter_at':
        m.w -= h; if (m.w <= 0 && p.st !== 10) { m.s = 'pick'; m.noDecoy = 1; }
        return In;
      case 'after': {
        if (lv === 1) { m.s = 'pick'; m.noDecoy = 1; break; }
        if (p.dcd <= 0 && (M.wc || M.dr.length) && R() < C.wc && (lv === 3 || guardCount(W, p.x, p.y, 5) > 0)) { In.act = 'dis'; m.s = 'wc'; return In; }
        if (R() < C.sit) { const c = []; W.so.forEach((o, s) => { if (o < 0 && hyp(M.seats[s].x - p.x, M.seats[s].y - p.y) < 7) c.push(s); }); if (c.length) { In.goal = gSeat(W, c[(R() * c.length) | 0]); m.s = 'decoy'; return In; } }
        m.s = 'pick'; m.forceDecoy = 1; break;
      }
    }
    if (m.s && m.s !== 'pick') return In;
    // bribe a guest standing next to me (once): they fake a theft elsewhere
    if (!p.acU && C.acc && R() < C.acc && W.ns < W.q) {
      for (const q of W.pp) if (q.kind === 0 && !q.kid && !q.hasKid && !q.gone && !q.in && q.acc === 0 && hyp(q.x - p.x, q.y - p.y) < 1.8) { In.act = 'acc'; break; }
      if (In.act) return In;
    }
    // pick the next thing to do
    const open = W.tg.filter((j) => !W.it[j]);
    if (lv === 1 && R() < C.loiter) { const pt = freePt(W, [p.x, p.y], 1.5, 6); In.goal = { k: 'pt', x: pt[0], y: pt[1] }; m.s = 'loiter'; m.run = R() < C.run; return In; }
    const wantDecoy = m.forceDecoy || (!m.noDecoy && R() < C.decoy) || m.noTarget || !open.length;
    m.forceDecoy = 0; m.noDecoy = 0; m.noTarget = 0;
    if (wantDecoy) {
      let best = -1, bs = -1e9;
      M.lk.forEach((l, li) => {
        if (!lookOpen(W, li) || (l.item >= 0 && W.tg.includes(l.item) && open.length)) return;
        const d = hyp(l.x - p.x, l.y - p.y); if (d < 0.8) return;
        const sc = -d * 0.4 + R() * 3 + (lv === 3 ? crowdAt(W, l.x, l.y, 1.6, p) * 0.5 - guardCount(W, l.x, l.y, 3) : 0);
        if (sc > bs) { bs = sc; best = li; }
      });
      if (best >= 0) { In.goal = slotGoal(W, best, p); m.s = 'decoy'; m.run = R() < C.run; return In; }
    }
    let best = -1, bs = -1e9;
    for (const j of open) {
      const l = M.lk[M.it[j].li];
      let sc = -hyp(l.x - p.x, l.y - p.y) + R() * 2;
      if (lv >= 2) sc -= guardCount(W, l.x, l.y, C.gR + 1) * 4;
      if (lv === 3) sc += crowdAt(W, l.x, l.y, 1.6, p) * 1.2 + (W.ev && W.ev.j === j ? 5 : 0) + (W.dark && l.x >= W.dark.x && l.x <= W.dark.x + W.dark.w ? 4 : 0);
      if (sc > bs) { bs = sc; best = j; }
    }
    if (best < 0) { const pt = freePt(W, [p.x, p.y], 1.5, 6); In.goal = { k: 'pt', x: pt[0], y: pt[1] }; m.s = 'loiter'; return In; }
    const l = M.lk[M.it[best].li];
    // guards around my target and I'm far enough away → set off a noise here first
    if (C.nz && p.nzN > 0 && p.ncd <= 0 && !W.nz && hyp(l.x - p.x, l.y - p.y) > 4.5 && guardCount(W, l.x, l.y, C.gR + 2) > 0 && R() < C.nz) { In.act = 'noi'; m.s = 'pick'; return In; }
    // walk along with a guest who is heading there anyway
    if (C.fol && R() < C.fol) {
      let fb = -1, fd = 5;
      for (const q of W.pp) if (q.kind === 0 && !q.kid && q.mode === 'go' && q.goal && q.goal.k === 'look' && q.goal.li === M.it[best].li) { const d = hyp(q.x - p.x, q.y - p.y); if (d < fd) { fd = d; fb = q.i; } }
      if (fb >= 0) { In.act = 'fol'; In.arg = fb; m.s = 'fol'; m.fj = best; m.fT = 0; return In; }
    }
    In.goal = slotGoal(W, M.it[best].li, p); m.s = 'go'; m.run = R() < C.run;
    return In;
  }

  /* ---------- AI: guard (only uses what anybody can see on screen) ---------- */
  const GC = [null,
    { lag: 1, mem: 0.3, nt: 0.1, see: 2.0, run: 0.3, th: 1.4, wh: 0.9, loi: 0, thr: 2.3, mg: 0, tau: 22, hunch: 0.03, keep: 0, whU: 0.012, sh: 0, cc: 0, nzGo: 0.9, gate: 0 },
    { lag: 0.6, mem: 0.6, nt: 0.18, see: 2.4, run: 0.6, th: 1.9, wh: 1.8, loi: 0.08, thr: 2.8, mg: 0.6, tau: 40, hunch: 0.006, keep: 0.2, whU: 0.18, sh: 2.4, cc: 0.6, nzGo: 0.55, gate: 0.4 },
    { lag: 0, mem: 0.9, nt: 0.34, see: 3.5, run: 0.85, th: 2.5, wh: 2.6, loi: 0.15, thr: 3.7, mg: 1.1, tau: 65, hunch: 0, keep: 0.45, whU: 0.3, sh: 1.7, cc: 1, nzGo: 0.3, gate: 0.8 },
  ];
  function nearPoi(W, q) {
    const M = W.M;
    if (q.st >= 10 && q.st <= 14) return true; // taking photos, chatting, asking the way, trying on a coat
    for (const l of M.lk) if (hyp(q.x - l.x, q.y - l.y) < 1.1) return true;
    for (const S of M.seats) if (hyp(q.x - S.ax, q.y - S.ay) < 0.8) return true;
    for (const Q of M.qs) for (const s of Q.sl) if (hyp(q.x - s[0], q.y - s[1]) < 0.6) return true;
    if (M.wc && hyp(q.x - M.wc.x, q.y - M.wc.y) < 1) return true;
    for (const D of M.dr) if (hyp(q.x - D.x, q.y - D.y) < 1) return true;
    return crowdAt(W, q.x, q.y, 0.9, q) >= 1; // standing with somebody
  }
  const suspectable = (q) => !!q && q.kind !== 2 && !q.kid && !q.gone && !q.in && !q.caught;
  function observe(W, g, m, C, lv, dt) {
    const R = W.R, pp = W.pp;
    if (m.gk == null) { const G = pp.filter((o) => o.kind === 2).length; m.gk = (G <= 1 ? 1.5 : G === 2 ? 1.15 : 1) * (W.th.length > 1 ? 1.25 : 1); }
    const gk = m.gk;
    for (let i = 0; i < pp.length; i++) {
      const q = pp[i];
      if (q.kind === 2 || q.kid) continue;
      if (q.gone) { m.sus[i] = 0; m.lk[i] = -1; m.wasIn[i] = 0; continue; }
      if (q.lk !== m.lk[i]) { m.sus[i] = m.lk[i] >= 0 && m.wasIn[i] ? m.sus[i] * C.keep : 0; m.lk[i] = q.lk; m.still[i] = 0; }
      m.wasIn[i] = q.in || q.st === 14 ? 1 : 0;
      if (q.in || q.caught) continue;
      const sp = hyp(q.vx, q.vy);
      if (sp > 1.5) { m.sus[i] += C.run * dt * (sp > 2 ? 1.6 : 1); }
      if (W.wh && W.wh.age > 1.0 && sp > 0.4) { m.sus[i] += C.wh * dt; }
      if (q.st === 4 || q.st === 11) { // somebody reaching towards a case (guests point and lean in too)
        let d = 99; for (const o of pp) if (o.kind === 2 && !o.gone) d = Math.min(d, hyp(q.x - o.x, q.y - o.y));
        const df = d < 3 ? 1 : d < 6 ? 0.4 : 0.12;
        const cr = crowdAt(W, q.x, q.y, 1.3, q), cf = cr >= 2 ? 0.15 : cr === 1 ? 0.35 : 1;
        if (R() < 1 - Math.exp(-C.nt * gk * df * cf * (inDark(W, q) ? 0.4 : 1) * dt)) { m.sus[i] += C.see; m.seen = i; m.seenT = W.t; }
      }
      if (sp < 0.1 && (q.st === 0 || q.st === 1)) { m.still[i] += dt; if (m.still[i] > 4 && C.loi && !nearPoi(W, q)) { m.sus[i] += C.loi * dt; } } else m.still[i] = 0;
      m.sus[i] *= Math.exp(-dt / C.tau);
    }
    if (C.hunch && R() < C.hunch * dt * 4) { const i = (R() * pp.length) | 0; if (suspectable(pp[i])) { m.sus[i] += 1.3; } }
    for (let j = 0; j < W.it.length; j++) { // a case was found empty → who is standing around it now? (and, with the CCTV, who was there then)
      if (!W.it[j] || (m.dn >> j) & 1 || W.t - W.itT[j] < ALERT_D + C.lag) continue;
      m.dn |= 1 << j;
      const l = W.M.lk[W.M.it[j].li];
      let cam = null;
      if (C.cc && R() < C.cc) { for (const o of pp) if (o.kind === 2 && o.ccd <= 0 && W.ai && W.ai[o.seat] && !o.gone) { cam = o; break; } }
      if (cam && useCctv(W, cam) === false) cam = null;
      const f = (d) => (d >= 2.8 ? 0 : 1.1 - d / 2.8);
      for (const q of pp) {
        if (!suspectable(q)) continue;
        if (lv === 1 && R() < 0.25) continue;
        let v = f(hyp(q.x - l.x, q.y - l.y)) * 0.6;
        if (cam) {
          let md = 99, reach = 0;
          for (const e of W.hist || []) {
            if (e.t < W.itT[j] - 2.2 || e.t > W.itT[j] + 0.6 || e.lk[q.i] !== q.lk) continue;
            const d = hyp(e.x[q.i] - l.x, e.y[q.i] - l.y); if (d < md) md = d;
            if ((e.st[q.i] === 4 || e.st[q.i] === 11) && d < 1.4) reach = 1;
          }
          v = Math.max(v, C.mem * f(md)) + (reach ? 0.35 : 0);
        }
        if (v <= 0) continue;
        v *= C.th * gk * (inDark(W, q) ? 0.6 : 1);
        m.sus[q.i] += v;
      }
    }
    for (const e of W.fx) if (e[0] > m.fx && e[1] === 3) m.sus[e[3]] = 0;
    m.fx = W.fxN;
  }
  function aiGuard(W, g, m, lv, h) {
    const C = GC[lv] || GC[2], R = W.R, pp = W.pp, M = W.M;
    const In = m.In || (m.In = { ax: 0, ay: 0, arr: null, wh: 0, goal: null, tap: null, cc: 0, gt: 0 });
    // AI guards share one suspicion board (more guards = more eyes and legs, not more guesses)
    const T = W.team || (W.team = { lead: g.i });
    if (!T.sus) { const n = pp.length; T.sus = new Float32Array(n); T.lk = new Int32Array(n).fill(-1); T.still = new Float32Array(n); T.wasIn = new Uint8Array(n); T.fx = W.fxN; T.dn = 0; T.oT = 0; T.seen = -1; T.seenT = -9; }
    if (m.pT == null) m.pT = 0.5 + R() * 2;
    if (!pp[T.lead] || pp[T.lead].kind !== 2 || (T.seenBy !== undefined && T.lastLead < W.t - 1)) T.lead = g.i;
    if (T.lead === g.i) { T.lastLead = W.t; T.oT += h; if (T.oT >= 0.25) { observe(W, g, T, C, lv, T.oT); T.oT = 0; } }
    T.seenBy = 1;
    m = Object.assign(m, { sus: T.sus });
    if (g.fr > 0 || g.ch >= 0) return In;
    let b = -1, bv = 0, sv = 0, tv = 0;
    for (let i = 0; i < pp.length; i++) {
      if (!suspectable(pp[i])) continue;
      const v = m.sus[i];
      if (v > bv) { tv = sv; sv = bv; bv = v; b = i; } else if (v > sv) { tv = sv; sv = v; } else if (v > tv) tv = v;
    }
    if (W.th.length > 1 && W.th.some((s) => W.pp[W.ps[s]].caught) === false) sv = tv; // two thieves: the runner-up may be the other one
    const chased = (i) => pp.some((o) => o !== g && o.kind === 2 && o.ch === i);
    if (W.cf > 0) {
      if (lv === 3 && T.seen >= 0 && W.t - T.seenT < 2.5 && suspectable(pp[T.seen]) && !chased(T.seen)) { In.arr = T.seen; T.seen = -1; return In; }
      const need = C.thr * (W.ns >= W.q ? 0.8 : 1);
      if (b >= 0 && bv >= need && bv - sv >= C.mg && !chased(b)) { In.arr = b; return In; }
    }
    if (g.wcd <= 0 && !W.wh && W.t - (W.whLast || -99) > 14) {
      const amb = bv > C.thr * 0.35 && bv < C.thr;
      if (R() < (amb ? C.whU : C.whU * 0.12) * h) In.wh = 1;
    }
    // a noise somewhere: go and have a look (쉬움 always falls for it)
    if (W.nz && W.nz.f <= 0 && m.nzId !== W.nz.id) {
      m.nzId = W.nz.id;
      if (hyp(W.nz.x - g.x, W.nz.y - g.y) < 9 && R() < C.nzGo) { const pt = freePt(W, [W.nz.x, W.nz.y], 0.8, 2); In.goal = { k: 'pt', x: pt[0], y: pt[1] }; m.pT = 5 + R() * 2; return In; }
    }
    // all stolen: close an exit near me
    if (W.ns >= W.q && C.gate && W.gu > 0 && !W.gt && R() < C.gate * h) {
      let near = 99; for (const e of M.ex) near = Math.min(near, hyp(e.x - g.x, e.y - g.y));
      if (near < 3.5) In.gt = 1;
    }
    m.pT -= h;
    if (m.pT > 0) return In;
    m.pT = 2.5 + R() * 3.5;
    let tx, ty;
    if (W.ns >= W.q && lv >= 2) {
      const gs = pp.filter((o) => o.kind === 2), k = gs.indexOf(g), ex = M.ex.filter((e, i) => !W.gt || W.gt.e !== i), e = ex[(k + (m.exo || 0)) % ex.length];
      if (R() < 0.15) m.exo = (m.exo || 0) + 1;
      tx = e.x + (7.5 - e.x) * 0.15; ty = e.y + (10.5 - e.y) * 0.12;
    } else if (lv >= 2 && b >= 0 && bv > C.thr * 0.4) {
      const q = pp[b], d = hyp(g.x - q.x, g.y - q.y) || 1;
      tx = q.x + (g.x - q.x) / d * C.sh; ty = q.y + (g.y - q.y) / d * C.sh; m.pT = 1.2;
    } else if (lv === 1) {
      const pt = freePt(W, [g.x, g.y], 2, 10); tx = pt[0]; ty = pt[1];
    } else {
      let best = null, bs = -1e9;
      M.it.forEach((it, j) => {
        if (W.it[j]) return;
        const l = M.lk[it.li];
        let sc = crowdAt(W, l.x, l.y, 2, null) * (lv === 3 ? 1 : 0.5) + R() * 2.5 - hyp(l.x - g.x, l.y - g.y) * 0.08;
        for (const o of pp) if (o !== g && o.kind === 2 && hyp(o.x - l.x, o.y - l.y) < 3.5) sc -= 3;
        if (sc > bs) { bs = sc; best = l; }
      });
      if (!best) { const pt = freePt(W); tx = pt[0]; ty = pt[1]; }
      else { const a = best.a + PI + (R() - 0.5) * 1.6; tx = best.x + Math.cos(a) * 2.7; ty = best.y + Math.sin(a) * 2.7; }
    }
    if (solidAt(M, tx, ty, 0.3)) { const c = nearFree(M, cellOf(tx, ty)); tx = cX(c); ty = cY(c); }
    In.goal = { k: 'pt', x: clamp(tx, 0.5, WU - 0.5), y: clamp(ty, 0.5, HU - 0.5) };
    return In;
  }
  function aiFor(W, s, lv, mem) {
    const p = W.pp[W.ps[s]];
    if (!W.ai) W.ai = [];
    W.ai[s] = 1;
    return p.kind === 1 ? (w, q, h) => aiThief(w, q, mem, lv, h) : (w, q, h) => aiGuard(w, q, mem, lv, h);
  }

  /* ---------- coarse state (travels with api.setState) ---------- */
  function pickMap(mp, prev) {
    if (mp >= 0 && mp < MAPS.length) return mp;
    let k = Math.floor(Math.random() * MAPS.length);
    if (k === prev && MAPS.length > 1) k = (k + 1 + Math.floor(Math.random() * (MAPS.length - 1))) % MAPS.length;
    return k;
  }
  function nThieves(st) { const v = st.nto === 'auto' ? (st.np >= 6 ? 2 : 1) : +st.nto; return st.np >= 4 ? clamp(v, 1, 2) : 1; }
  function setupRound(st) {
    st.mk = pickMap(st.mp, st.mk);
    st.sd = 1 + U.rand(2147483000);
    const nth = nThieves(st), np = st.np;
    const th = [];
    if (st.who === 'p1' && st.rd === 1) th.push(0);
    while (th.length < nth) {
      const cand = [];
      for (let i = 0; i < np; i++) if (!th.includes(i) && !((st.td >> i) & 1) && !(st.who === 'guard' && i === 0)) cand.push(i);
      if (!cand.length) for (let i = 0; i < np; i++) if (!th.includes(i) && !(st.who === 'guard' && i === 0)) cand.push(i);
      if (!cand.length) break;
      th.push(cand[U.rand(cand.length)]);
    }
    st.th = th.sort((a, b) => a - b);
    const M = MAPS[st.mk], ids = M.it.map((_, j) => j);
    for (let i = ids.length - 1; i > 0; i--) { const j = U.rand(i + 1); const t = ids[i]; ids[i] = ids[j]; ids[j] = t; }
    st.tg = ids.slice(0, nth === 1 ? 4 : 6).sort((a, b) => a - b);
    st.q = nth === 1 ? 3 : 5;
    st.cf = nth + 1 + (np - nth >= 4 || np - nth === 1 ? 1 : 0); // shared handcuffs: thieves + 1 (+1 for a lone guard or 4+ guards)
    st.cr = st.cw === 's' ? 20 : st.cw === 'l' ? 34 : M.npc;
    st.rs = null;
    return st;
  }
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 2, NPMAX);
    const mp = typeof o.map === 'number' && o.map >= -1 && o.map < MAPS.length ? o.map : -1;
    let ai = 0; players.slice(0, np).forEach((p, i) => { if (p && p.ai) ai |= 1 << i; });
    const st = {
      rid: 1 + U.rand(99999), nm: players.slice(0, np).map((p) => String((p && p.name) || '').slice(0, 8)), np, ai,
      rounds: [1, 2, 3, 4].includes(+o.rounds) ? +o.rounds : 2, mp, tm: [120, 180, 240].includes(+o.time) ? +o.time : 180,
      cw: ['s', 'm', 'l'].includes(o.crowd) ? o.crowd : 'm', nto: [1, 2, '1', '2'].includes(o.nth) ? +o.nth : 'auto',
      who: ['rand', 'p1', 'guard'].includes(o.who) ? o.who : 'rand',
      rd: 1, td: 0, mk: -1, sc: Array(np).fill(0), tw: Array(np).fill(0), ph: 'brief', res: null, rs: null,
    };
    return setupRound(st);
  }
  function roundOver(st, W) {
    const n = Object.assign({}, st, { sc: st.sc.slice(), tw: st.tw.slice(), ph: 'end' });
    const pts = [];
    for (let s = 0; s < st.np; s++) { const v = clamp(Math.round(W.pt[s] || 0), -9, 30); pts.push(v); n.sc[s] = Math.max(0, n.sc[s] + v); }
    const w = W.res ? W.res.w : 'g';
    st.th.forEach((s) => { n.td |= 1 << s; if (w === 't') n.tw[s]++; });
    n.rs = { w, why: W.res ? W.res.why : 'time', who: W.res ? W.res.who : -1, pts, ns: W.ns, q: W.q, sn: W.sn.slice(), ca: W.ca.slice(), wr: W.wr.slice(), tb: st.th.map((s) => W.ps[s]) };
    return n;
  }
  function nextRound(st) {
    if (st.rd >= st.rounds) {
      const order = st.sc.map((v, i) => [i, v, st.tw[i]]).sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[0] - b[0]);
      return Object.assign({}, st, { ph: 'done', res: order });
    }
    return setupRound(Object.assign({}, st, { rd: st.rd + 1, ph: 'brief' }));
  }
  function startPlay(st) { return Object.assign({}, st, { ph: 'play' }); }
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res) || !st.res.length) return null;
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번';
    const top = st.res[0][1], winners = st.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = st.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '점' + (r[2] ? ' · 도둑 성공 ' + r[2] : ''));
    const head = (st.mp >= 0 ? MAPS[st.mp].nm : '맵 무작위') + ' · ' + st.rounds + '판';
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: head + '\n' + lines.join('\n') };
  }

  /* ---------- host snapshot ---------- */
  function snapshot(W, key, q) {
    const P = [];
    for (const p of W.pp) {
      if (p.gone) { P.push(-1, 0, 0, 0, 0); continue; }
      const a = ((p.a % TAU) + TAU) % TAU;
      P.push(Math.round(p.x * 10), Math.round(p.y * 10), Math.round(a * 10), p.st | (p.in ? 16 : 0) | (p.run || hyp(p.vx, p.vy) > 1.6 ? 32 : 0) | (p.caught ? 64 : 0) | (p.ch >= 0 ? 128 : 0), p.lk);
    }
    let it = 0, it2 = 0; W.it.forEach((v, j) => { if (v) it |= 1 << j; if (v === 2) it2 |= 1 << j; });
    const ev = W.ev ? [W.ev.k === 'gat' ? 1 : W.ev.k === 'wave' ? 2 : 3, Math.round(W.ev.t * 10), Math.round((W.ev.x || 0) * 10), Math.round((W.ev.y || 0) * 10), W.ev.j == null ? -1 : W.ev.j, W.ev.dance ? 1 : W.ev.par ? 2 : 0] : 0;
    const seats = [];
    for (let s = 0; s < W.np; s++) {
      const p = W.pp[W.ps[s]];
      if (p.kind === 1) seats.push(Math.round(p.stl * 10), p.fol, Math.max(0, Math.ceil(p.dcd)), Math.max(0, Math.ceil(p.ncd)) + 100 * p.nzN, (p.fr > 0 ? 1 : 0) | (p.acU ? 2 : 0));
      else seats.push(Math.max(0, Math.ceil(p.wcd)), p.ch, Math.max(0, Math.ceil(p.ccd)), 0, p.fr > 0 ? 1 : 0);
    }
    let iv = 0; W.it.forEach((v, j) => { if (v && W.t - W.itT[j] >= ALERT_D) iv |= 1 << j; });
    const nz = W.nz ? [Math.round(W.nz.x * 10), Math.round(W.nz.y * 10), W.nz.f > 0 ? 0 : 1, Math.round((W.nz.f > 0 ? W.nz.f : W.nz.t) * 10), W.nz.k, W.nz.id] : 0;
    const gt = W.gt ? [W.gt.e, Math.round(W.gt.t * 10)] : 0;
    return { k: key, q, t: Math.round(W.t * 10), P, it, it2, iv, ns: W.ns, cf: W.cf, gu: W.gu, ev, dk: W.dark ? (W.dark.x > 0 ? 2 : 1) : 0, wh: W.wh ? [W.wh.g, Math.round(W.wh.age * 10), Math.round(W.wh.x * 10), Math.round(W.wh.y * 10), W.whN] : 0, nz, gt, fx: W.fx.slice(-8), S: seats };
  }
  function applySnap(W, s) {
    if (!Array.isArray(s.P)) return;
    while (W.pp.length * 5 < s.P.length) { const p = mkPerson(W, W.pp.length); p.gone = 1; W.pp.push(p); }
    if (s.P.length !== W.pp.length * 5) return;
    W.t = (s.t | 0) / 10;
    for (let i = 0; i < W.pp.length; i++) {
      const p = W.pp[i], o = i * 5, x = s.P[o];
      if (x < 0) { p.gone = 1; continue; }
      const nx = x / 10, ny = s.P[o + 1] / 10;
      if (p.gone || !fin(p.nx)) { p.x = nx; p.y = ny; p.a = s.P[o + 2] / 10; }
      p.gone = 0; p.nx = nx; p.ny = ny; p.na = s.P[o + 2] / 10;
      const f = s.P[o + 3] | 0;
      p.st = f & 15; p.in = f & 16 ? 1 : 0; p.run = f & 32 ? 1 : 0; p.caught = f & 64 ? 1 : 0; p.chs = f & 128 ? 1 : 0; p.lk = s.P[o + 4] | 0;
      p.kid = isKid(p.lk) ? 1 : 0;
    }
    W.it = W.it.map((_, j) => ((s.it >> j) & 1) ? (((s.it2 >> j) & 1) ? 2 : 1) : 0);
    W.iv = W.it.map((_, j) => ((s.iv >> j) & 1));
    W.ns = s.ns | 0; W.cf = s.cf | 0; W.gu = s.gu | 0;
    if (Array.isArray(s.ev)) {
      const k = s.ev[0] === 1 ? 'gat' : s.ev[0] === 2 ? 'wave' : 'dark';
      W.ev = { k, t: s.ev[1] / 10, x: s.ev[2] / 10, y: s.ev[3] / 10, j: s.ev[4], dance: s.ev[5] === 1 ? 1 : 0, par: s.ev[5] === 2 ? 1 : 0 };
    } else W.ev = null;
    W.dark = s.dk ? { x: s.dk === 2 ? WU / 2 : 0, y: 0, w: WU / 2, h: HU } : null;
    W.wh = Array.isArray(s.wh) ? { g: s.wh[0], age: s.wh[1] / 10, x: s.wh[2] / 10, y: s.wh[3] / 10, t: WHIS_T - s.wh[1] / 10 } : null;
    if (W.wh) W.whN = s.wh[4] | 0;
    W.nz = Array.isArray(s.nz) ? { x: s.nz[0] / 10, y: s.nz[1] / 10, f: s.nz[2] ? 0 : s.nz[3] / 10, t: s.nz[2] ? s.nz[3] / 10 : 0, k: s.nz[4] | 0, id: s.nz[5] | 0 } : null;
    W.gt = Array.isArray(s.gt) ? { e: s.gt[0] | 0, t: s.gt[1] / 10 } : null;
    if (Array.isArray(s.S)) for (let k = 0; k < W.np; k++) {
      const p = W.pp[W.ps[k]]; if (!p) continue;
      const v = (i) => s.S[k * 5 + i] | 0;
      if (p.kind === 1) { p.stl = v(0) / 10; p.fol = v(1); p.dcd = v(2); p.ncd = v(3) % 100; p.nzN = (v(3) / 100) | 0; p.acU = v(4) & 2 ? 1 : 0; }
      else { p.wcd = v(0); p.ch = v(1); p.ccd = v(2); }
      p.fr = v(4) & 1 ? 1 : 0;
    }
  }
  const goneSeen = (W, j) => !!W.it[j] && (W.iv ? !!W.iv[j] : W.t - W.itT[j] >= ALERT_D); // what guards can see

  /* ======================= view ======================= */
  const HUD_H = 58, BOT_H = 112, MG = 0.5, ZOOM = 1.9;
  const CSS = `
.ct-b{position:absolute;border-radius:50%;border:2px solid rgba(242,233,216,.35);background:rgba(34,24,54,.92);color:#f2e9d8;
  font:700 15px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;
  touch-action:none;user-select:none;-webkit-user-select:none;z-index:3;padding:0;box-shadow:0 4px 14px rgba(0,0,0,.5);
  -webkit-tap-highlight-color:transparent;cursor:pointer;line-height:1.1;overflow:visible}
.ct-b span{white-space:nowrap}
.ct-b small{font-size:10px;font-weight:600;opacity:.85;white-space:nowrap}
.ct-b.sq{border-radius:16px}
.ct-b.on{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}
.ct-b.dim{opacity:.45}
.ct-b.hot{background:#ee6a55;color:#fff;border-color:#ffd9d2}
.ct-b.pulse{animation:ctp 1s ease-in-out infinite}
.ct-b:active{transform:scale(.95)}
@keyframes ctp{50%{box-shadow:0 0 0 7px rgba(227,174,69,.45),0 4px 14px rgba(0,0,0,.5)}}
.ct-act{width:80px;height:80px;right:8px;bottom:15px;font-size:16px;--p:0}
.ct-act::before{content:'';position:absolute;inset:-7px;border-radius:50%;pointer-events:none;
  background:conic-gradient(#ffe28a calc(var(--p) * 1turn),rgba(255,255,255,.08) 0);
  -webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 6px),#000 calc(100% - 5px));mask:radial-gradient(farthest-side,transparent calc(100% - 6px),#000 calc(100% - 5px))}
.ct-s2{width:62px;height:58px;right:96px;bottom:26px;font-size:14px}
.ct-s3{width:60px;height:58px;right:164px;bottom:26px;font-size:13px}
.ct-s4{width:58px;height:58px;right:230px;bottom:26px;font-size:13px}
.ct-zm{width:46px;height:46px;right:294px;bottom:32px;font-size:12px}
.ct-b .cd{position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:conic-gradient(rgba(12,8,22,.62) calc(var(--c,0) * 1turn),transparent 0)}
.ct-menu{position:absolute;left:10px;right:10px;z-index:4;display:grid;grid-template-columns:repeat(3,1fr);gap:6px;padding:8px;
  background:rgba(24,17,36,.95);border:1.5px solid rgba(227,174,69,.55);border-radius:16px;box-shadow:0 8px 28px rgba(0,0,0,.6);max-width:420px;margin:0 auto}
.ct-menu button{min-height:52px;border-radius:12px;border:1.5px solid rgba(242,233,216,.25);background:rgba(46,38,64,.96);color:#f2e9d8;
  font:700 13.5px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;touch-action:none;cursor:pointer;padding:2px}
.ct-menu button small{font-size:10px;font-weight:600;opacity:.8}
.ct-menu button.dim{opacity:.45}
.ct-menu button.on{background:#e3ae45;color:#2a1d05}
.ct-card{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(340px,calc(100% - 24px));z-index:5;box-sizing:border-box;max-height:calc(100% - 24px);overflow:auto;
  background:rgba(24,17,36,.95);border:2px solid rgba(227,174,69,.55);border-radius:18px;padding:14px 16px;color:#f2e9d8;
  font:14px/1.45 var(--f-body,system-ui);box-shadow:0 10px 40px rgba(0,0,0,.6);text-align:center;cursor:pointer}
.ct-card h3{margin:0 0 4px;font:24px var(--f-display,sans-serif);color:#e3ae45;letter-spacing:.5px}
.ct-card .rl{font-size:12.5px;color:#c9bfd8;margin:2px 0}
.ct-card .tl{display:grid;grid-template-columns:auto 1fr;gap:3px 8px;text-align:left;font-size:12.5px;margin:8px 0 2px;color:#e6dcef}
.ct-card .tl b{color:#e3ae45;white-space:nowrap}
.ct-card .tg{display:flex;flex-wrap:wrap;justify-content:center;gap:6px;margin:8px 0 4px}
.ct-card .tg span{display:flex;align-items:center;gap:3px;background:rgba(227,174,69,.15);border:1px solid rgba(227,174,69,.5);border-radius:10px;padding:2px 7px 2px 3px;font-size:12.5px}
.ct-card canvas{width:24px;height:24px}
.ct-card .ft{margin-top:8px;font:700 13px var(--f-mono,monospace);color:#bfe3ff}
.ct-card .pts{display:grid;grid-template-columns:1fr auto;gap:2px 10px;text-align:left;font-size:13px;margin-top:8px}
.ct-card .pts b{font-family:var(--f-mono,monospace);text-align:right}
`;
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function drawItem(c, k, x, y, s) { // s ≈ icon size in px
    const kind = IK[k] || 'gem', u = s / 2;
    c.save(); c.translate(x, y); c.lineJoin = 'round';
    const gold = '#f2c14e', dk = 'rgba(20,12,6,.55)';
    c.lineWidth = Math.max(1, s * 0.07); c.strokeStyle = dk;
    const circ = (cx, cy, r, f) => { c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.fillStyle = f; c.fill(); c.stroke(); };
    switch (kind) {
      case 'crown': c.beginPath(); c.moveTo(-u, u * 0.5); c.lineTo(-u, -u * 0.5); c.lineTo(-u * 0.5, 0); c.lineTo(0, -u * 0.7); c.lineTo(u * 0.5, 0); c.lineTo(u, -u * 0.5); c.lineTo(u, u * 0.5); c.closePath(); c.fillStyle = gold; c.fill(); c.stroke(); circ(0, u * 0.15, u * 0.16, '#e8604c'); break;
      case 'mask': c.beginPath(); c.ellipse(0, 0, u * 0.8, u, 0, 0, TAU); c.fillStyle = gold; c.fill(); c.stroke(); c.fillStyle = dk; c.beginPath(); c.ellipse(-u * 0.32, -u * 0.15, u * 0.2, u * 0.12, 0, 0, TAU); c.ellipse(u * 0.32, -u * 0.15, u * 0.2, u * 0.12, 0, 0, TAU); c.fill(); break;
      case 'vase': case 'jar': c.beginPath(); c.moveTo(-u * 0.3, -u); c.lineTo(u * 0.3, -u); c.quadraticCurveTo(u * 1.1, -u * 0.1, u * 0.4, u); c.lineTo(-u * 0.4, u); c.quadraticCurveTo(-u * 1.1, -u * 0.1, -u * 0.3, -u); c.fillStyle = kind === 'vase' ? '#8fd0b8' : '#d99a4e'; c.fill(); c.stroke(); break;
      case 'gem': c.beginPath(); c.moveTo(0, -u); c.lineTo(u * 0.85, -u * 0.2); c.lineTo(0, u); c.lineTo(-u * 0.85, -u * 0.2); c.closePath(); c.fillStyle = '#5ab4ff'; c.fill(); c.stroke(); c.fillStyle = 'rgba(255,255,255,.6)'; c.beginPath(); c.moveTo(0, -u); c.lineTo(u * 0.3, -u * 0.2); c.lineTo(-u * 0.3, -u * 0.2); c.fill(); break;
      case 'mirror': circ(0, -u * 0.2, u * 0.65, '#d8e2ea'); c.fillStyle = '#9aa3ad'; c.fillRect(-u * 0.12, u * 0.4, u * 0.24, u * 0.6); break;
      case 'statue': c.fillStyle = '#c8c0b4'; c.fillRect(-u * 0.6, u * 0.55, u * 1.2, u * 0.45); circ(0, -u * 0.55, u * 0.32, '#c8c0b4'); c.beginPath(); c.moveTo(-u * 0.45, u * 0.55); c.lineTo(-u * 0.3, -u * 0.2); c.lineTo(u * 0.3, -u * 0.2); c.lineTo(u * 0.45, u * 0.55); c.fill(); c.stroke(); break;
      case 'coin': circ(-u * 0.25, u * 0.15, u * 0.6, gold); circ(u * 0.3, -u * 0.2, u * 0.55, '#ffd979'); break;
      case 'ring': c.beginPath(); c.arc(0, u * 0.2, u * 0.6, 0, TAU); c.lineWidth = s * 0.16; c.strokeStyle = gold; c.stroke(); c.lineWidth = Math.max(1, s * 0.07); c.strokeStyle = dk; circ(0, -u * 0.5, u * 0.3, '#8ff0e0'); break;
      case 'bag': rrect(c, -u * 0.8, -u * 0.3, u * 1.6, u * 1.2, u * 0.2); c.fillStyle = '#a0522d'; c.fill(); c.stroke(); c.beginPath(); c.arc(0, -u * 0.3, u * 0.45, PI, 0); c.lineWidth = s * 0.1; c.strokeStyle = '#6b3519'; c.stroke(); break;
      case 'watch': c.fillStyle = '#6b4a2e'; c.fillRect(-u * 0.25, -u, u * 0.5, u * 2); circ(0, 0, u * 0.6, gold); c.strokeStyle = '#3a2a10'; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -u * 0.4); c.moveTo(0, 0); c.lineTo(u * 0.3, 0); c.stroke(); break;
      case 'perfume': rrect(c, -u * 0.6, -u * 0.3, u * 1.2, u * 1.3, u * 0.3); c.fillStyle = '#f07fb8'; c.fill(); c.stroke(); c.fillStyle = gold; c.fillRect(-u * 0.2, -u * 0.8, u * 0.4, u * 0.5); break;
      case 'necklace': c.beginPath(); c.arc(0, -u * 0.3, u * 0.75, 0.15, PI - 0.15); c.lineWidth = s * 0.09; c.strokeStyle = '#f5f0e6'; c.stroke(); c.lineWidth = Math.max(1, s * 0.07); c.strokeStyle = dk; circ(0, u * 0.5, u * 0.28, '#ee6a55'); break;
      case 'camera': rrect(c, -u, -u * 0.55, u * 2, u * 1.3, u * 0.2); c.fillStyle = '#3a3a44'; c.fill(); c.stroke(); circ(0, u * 0.1, u * 0.42, '#9fc6ff'); break;
      case 'trophy': c.fillStyle = gold; c.beginPath(); c.moveTo(-u * 0.7, -u); c.lineTo(u * 0.7, -u); c.quadraticCurveTo(u * 0.7, u * 0.1, 0, u * 0.25); c.quadraticCurveTo(-u * 0.7, u * 0.1, -u * 0.7, -u); c.fill(); c.stroke(); c.fillRect(-u * 0.12, u * 0.2, u * 0.24, u * 0.45); c.fillRect(-u * 0.5, u * 0.65, u, u * 0.3); break;
      case 'book': c.fillStyle = '#7b2d3b'; c.fillRect(-u * 0.75, -u, u * 1.5, u * 2); c.strokeRect(-u * 0.75, -u, u * 1.5, u * 2); c.fillStyle = gold; c.fillRect(-u * 0.45, -u * 0.5, u * 0.9, u * 0.2); break;
      case 'map': c.fillStyle = '#e8d8a8'; c.fillRect(-u, -u * 0.7, u * 2, u * 1.4); c.strokeRect(-u, -u * 0.7, u * 2, u * 1.4); c.strokeStyle = '#b5523c'; c.setLineDash([2, 2]); c.beginPath(); c.moveTo(-u * 0.6, u * 0.3); c.lineTo(u * 0.5, -u * 0.3); c.stroke(); c.setLineDash([]); break;
      case 'teapot': c.beginPath(); c.ellipse(0, u * 0.15, u * 0.7, u * 0.55, 0, 0, TAU); c.fillStyle = '#cfd6dc'; c.fill(); c.stroke(); c.beginPath(); c.moveTo(u * 0.6, 0); c.lineTo(u, -u * 0.45); c.lineWidth = s * 0.1; c.strokeStyle = '#cfd6dc'; c.stroke(); break;
      case 'globe': circ(0, -u * 0.15, u * 0.7, '#4f9be0'); c.fillStyle = '#4fc38f'; c.beginPath(); c.ellipse(-u * 0.2, -u * 0.3, u * 0.3, u * 0.2, 0.5, 0, TAU); c.fill(); c.fillStyle = '#8a5a2b'; c.fillRect(-u * 0.4, u * 0.65, u * 0.8, u * 0.3); break;
      case 'pen': c.rotate(-0.7); c.fillStyle = '#20202a'; c.fillRect(-u * 0.18, -u, u * 0.36, u * 1.5); c.fillStyle = gold; c.beginPath(); c.moveTo(-u * 0.18, u * 0.5); c.lineTo(u * 0.18, u * 0.5); c.lineTo(0, u); c.fill(); break;
      case 'doll': circ(-u * 0.5, -u * 0.6, u * 0.24, '#b07a4a'); circ(u * 0.5, -u * 0.6, u * 0.24, '#b07a4a'); circ(0, u * 0.45, u * 0.55, '#b07a4a'); circ(0, -u * 0.25, u * 0.48, '#c48b56'); c.fillStyle = '#2a1a10'; c.beginPath(); c.arc(-u * 0.17, -u * 0.32, u * 0.07, 0, TAU); c.arc(u * 0.17, -u * 0.32, u * 0.07, 0, TAU); c.fill(); break;
      case 'robot': c.fillStyle = '#9fb0c4'; c.fillRect(-u * 0.55, -u * 0.1, u * 1.1, u * 1.0); c.strokeRect(-u * 0.55, -u * 0.1, u * 1.1, u * 1.0); c.fillRect(-u * 0.4, -u * 0.75, u * 0.8, u * 0.6); c.strokeRect(-u * 0.4, -u * 0.75, u * 0.8, u * 0.6); c.fillStyle = '#ee6a55'; c.beginPath(); c.arc(0, -u * 0.95, u * 0.13, 0, TAU); c.fill(); c.fillStyle = '#ffe28a'; c.fillRect(-u * 0.25, -u * 0.55, u * 0.15, u * 0.15); c.fillRect(u * 0.1, -u * 0.55, u * 0.15, u * 0.15); break;
      case 'snowglobe': c.fillStyle = '#7a5434'; c.fillRect(-u * 0.6, u * 0.55, u * 1.2, u * 0.4); circ(0, -u * 0.05, u * 0.68, 'rgba(190,230,255,.85)'); c.fillStyle = '#3c7d4a'; c.beginPath(); c.moveTo(0, -u * 0.45); c.lineTo(u * 0.3, u * 0.3); c.lineTo(-u * 0.3, u * 0.3); c.fill(); break;
      case 'choco': rrect(c, -u * 0.85, -u * 0.6, u * 1.7, u * 1.2, u * 0.12); c.fillStyle = '#6b3a24'; c.fill(); c.stroke(); c.fillStyle = '#ee6a55'; c.fillRect(-u * 0.12, -u * 0.6, u * 0.24, u * 1.2); c.fillRect(-u * 0.85, -u * 0.1, u * 1.7, u * 0.2); break;
      case 'fan': c.beginPath(); c.moveTo(0, u * 0.7); c.arc(0, u * 0.7, u * 1.3, -PI * 0.85, -PI * 0.15); c.closePath(); c.fillStyle = '#ef7fb0'; c.fill(); c.stroke(); c.strokeStyle = 'rgba(255,255,255,.5)'; for (let i = 1; i < 5; i++) { const a = -PI * 0.85 + i * PI * 0.14; c.beginPath(); c.moveTo(0, u * 0.7); c.lineTo(Math.cos(a) * u * 1.25, u * 0.7 + Math.sin(a) * u * 1.25); c.stroke(); } break;
      case 'glasses': c.lineWidth = s * 0.1; c.strokeStyle = '#2b2b33'; c.fillStyle = '#e3ae45'; for (const sx of [-1, 1]) { c.beginPath(); c.arc(sx * u * 0.48, 0, u * 0.38, 0, TAU); c.fill(); c.stroke(); } c.beginPath(); c.moveTo(-u * 0.12, 0); c.lineTo(u * 0.12, 0); c.stroke(); break;
      case 'lipstick': c.fillStyle = '#2b2b33'; c.fillRect(-u * 0.3, 0, u * 0.6, u); c.strokeRect(-u * 0.3, 0, u * 0.6, u); c.fillStyle = gold; c.fillRect(-u * 0.26, -u * 0.25, u * 0.52, u * 0.3); c.fillStyle = '#d6304a'; c.beginPath(); c.moveTo(-u * 0.2, -u * 0.25); c.lineTo(-u * 0.2, -u * 0.8); c.lineTo(u * 0.2, -u); c.lineTo(u * 0.2, -u * 0.25); c.fill(); break;
      case 'pearl': circ(0, 0, u * 0.7, '#2c2f3a'); c.fillStyle = 'rgba(200,220,255,.75)'; c.beginPath(); c.arc(-u * 0.25, -u * 0.25, u * 0.2, 0, TAU); c.fill(); break;
      case 'coral': c.strokeStyle = '#ee6a55'; c.lineWidth = s * 0.14; c.lineCap = 'round'; c.beginPath(); c.moveTo(0, u); c.lineTo(0, -u * 0.2); c.lineTo(-u * 0.5, -u * 0.8); c.moveTo(0, -u * 0.1); c.lineTo(u * 0.55, -u * 0.7); c.moveTo(0, u * 0.3); c.lineTo(-u * 0.6, 0); c.stroke(); break;
      case 'dolphin': c.beginPath(); c.moveTo(-u, u * 0.3); c.quadraticCurveTo(-u * 0.2, -u * 1.0, u * 0.9, -u * 0.2); c.quadraticCurveTo(u * 0.2, -u * 0.1, -u * 0.2, u * 0.5); c.closePath(); c.fillStyle = '#8fd0f0'; c.fill(); c.stroke(); c.fillStyle = 'rgba(255,255,255,.55)'; c.beginPath(); c.arc(u * 0.45, -u * 0.35, u * 0.08, 0, TAU); c.fill(); break;
      case 'shell': c.beginPath(); c.moveTo(-u * 0.9, u * 0.5); c.quadraticCurveTo(-u * 0.6, -u, u * 0.9, -u * 0.6); c.quadraticCurveTo(u * 0.5, u * 0.3, -u * 0.9, u * 0.5); c.fillStyle = '#f0c7a0'; c.fill(); c.stroke(); c.strokeStyle = '#b5523c'; c.beginPath(); c.arc(-u * 0.1, -u * 0.05, u * 0.3, 0, PI * 1.5); c.stroke(); break;
    }
    c.restore();
  }
  function drawPerson(c, p, X, Y, s0, now, guardCol, lite) {
    const lk = p.lk, isG = isGk(lk), kid = isKid(lk);
    const look = isG ? null : lookOf(lk);
    const s = kid ? s0 * 0.7 : s0;
    const ph = now / 1000 + p.i * 0.37;
    let bob = 0;
    const spd = hyp(p.vx || 0, p.vy || 0), walking = spd > 0.3 && p.st !== 2;
    if (p.st === 7) bob = Math.sin(now / 160 + p.i) * 0.06 * s;
    if (walking) bob = Math.sin(now / 110 + p.i) * 0.025 * s;
    const sit = p.st === 2, k = sit ? 0.9 : 1;
    const skin = look ? look.sk : '#e9c39b';
    c.save(); c.translate(X, Y + bob);
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0.04 * s, 0.1 * s, 0.34 * s * k, 0.26 * s * k, 0, 0, TAU); c.fill();
    if (isG) { c.strokeStyle = 'rgba(159,180,255,.7)'; c.lineWidth = Math.max(1.5, s * 0.06); c.beginPath(); c.arc(0, 0, 0.38 * s, 0, TAU); c.stroke(); }
    c.rotate((p.a || 0) + (p.st === 14 ? Math.sin(now / 90 + p.i) * 0.25 : 0));
    const shirt = isG ? '#2d3f73' : look.s;
    if (walking && !lite) { // little stepping feet
      const w = Math.sin(now / (p.run ? 70 : 115) + p.i * 1.7) * 0.13 * s;
      c.fillStyle = 'rgba(25,18,30,.85)';
      c.beginPath(); c.ellipse(w, -0.1 * s, 0.09 * s, 0.055 * s, 0, 0, TAU); c.ellipse(-w, 0.1 * s, 0.09 * s, 0.055 * s, 0, 0, TAU); c.fill();
    }
    if (p.st === 4 || p.st === 11) { // reaching / pointing at a case — thieves AND curious guests do this
      c.strokeStyle = skin; c.lineWidth = Math.max(2, 0.1 * s); c.lineCap = 'round';
      c.beginPath(); c.moveTo(0.05 * s, 0.18 * s); c.lineTo(0.62 * s, 0.1 * s); c.stroke();
      c.fillStyle = skin; c.beginPath(); c.arc(0.64 * s, 0.1 * s, 0.07 * s, 0, TAU); c.fill();
    }
    if (p.st === 10) { // holding up a phone/camera
      c.strokeStyle = skin; c.lineWidth = Math.max(2, 0.09 * s); c.lineCap = 'round';
      c.beginPath(); c.moveTo(0.05 * s, 0.17 * s); c.lineTo(0.38 * s, 0.07 * s); c.moveTo(0.05 * s, -0.17 * s); c.lineTo(0.38 * s, -0.07 * s); c.stroke();
      c.fillStyle = '#20202a'; c.fillRect(0.36 * s, -0.12 * s, 0.1 * s, 0.24 * s);
    }
    c.fillStyle = shirt; c.strokeStyle = 'rgba(10,6,16,.55)'; c.lineWidth = Math.max(1, s * 0.04);
    c.beginPath(); c.ellipse(0, 0, 0.21 * s * k, 0.32 * s * k, 0, 0, TAU); c.fill();
    if (look && look.pat) { c.save(); c.clip(); c.fillStyle = look.s2; for (let i = -2; i <= 2; i++) c.fillRect(i * 0.12 * s - 0.03 * s, -0.4 * s, 0.06 * s, 0.8 * s); c.restore(); }
    c.stroke();
    if (isG) { c.fillStyle = guardCol || '#e3ae45'; c.beginPath(); c.ellipse(0, -0.22 * s, 0.09 * s, 0.07 * s, 0, 0, TAU); c.fill(); }
    if (look && (look.acc & 2) && !kid) { c.fillStyle = '#7a4a24'; c.fillRect(-0.3 * s, -0.13 * s, 0.13 * s, 0.26 * s); }
    const hr = 0.165 * s * k;
    c.fillStyle = skin; c.beginPath(); c.arc(0.05 * s, 0, hr, 0, TAU); c.fill();
    c.fillStyle = isG ? '#1b2647' : look.h; c.beginPath(); c.arc(-0.02 * s, 0, hr * 0.98, PI * 0.5, PI * 1.5); c.fill();
    c.beginPath(); c.arc(0, 0, hr, 0, TAU); c.stroke();
    if (isG) { c.fillStyle = '#1b2647'; c.beginPath(); c.arc(0, 0, hr * 1.12, 0, TAU); c.fill(); c.fillRect(0, -hr * 0.7, hr * 1.5, hr * 1.4); c.fillStyle = '#e3ae45'; c.beginPath(); c.arc(0.06 * s, 0, hr * 0.32, 0, TAU); c.fill(); }
    else if (look.acc & 1) { c.fillStyle = look.hat; c.beginPath(); c.arc(0, 0, hr * 1.25, 0, TAU); c.fill(); c.stroke(); c.fillStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.arc(-hr * 0.2, -hr * 0.2, hr * 0.6, 0, TAU); c.fill(); }
    c.restore();
    if (p.caught) { c.fillStyle = 'rgba(30,20,40,.5)'; c.beginPath(); c.arc(X, Y, 0.36 * s, 0, TAU); c.fill(); }
    if (lite || s0 < 9) return;
    // little speech / camera cues
    if (p.st === 10 && Math.sin(ph * 2.3) > 0.96) { c.fillStyle = 'rgba(255,255,240,.85)'; c.beginPath(); c.arc(X + Math.cos(p.a) * 0.55 * s, Y + Math.sin(p.a) * 0.55 * s, 0.22 * s, 0, TAU); c.fill(); }
    const bub = p.st === 12 ? (ph % 3.2 < 1.3 ? '…' : '') : p.st === 13 ? '?' : p.st === 14 ? '↻' : '';
    if (bub) {
      const bx = X + 0.28 * s0, by = Y - 0.62 * s0, r = 0.22 * s0;
      c.fillStyle = 'rgba(250,246,236,.92)'; c.beginPath(); c.ellipse(bx, by, r * 1.25, r, 0, 0, TAU); c.fill();
      c.beginPath(); c.moveTo(bx - r * 0.5, by + r * 0.6); c.lineTo(bx - r * 0.9, by + r * 1.3); c.lineTo(bx - r * 0.05, by + r * 0.8); c.fill();
      c.fillStyle = '#2a2236'; c.font = `700 ${Math.max(8, r * 1.3)}px sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(bub, bx, by - (bub === '…' ? r * 0.2 : 0));
    }
  }
  function buildBg(M, s, dpr) {
    const cw = (WU + MG * 2) * s, ch = (HU + MG * 2) * s;
    const cv = document.createElement('canvas'); cv.width = Math.round(cw * dpr); cv.height = Math.round(ch * dpr);
    const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const X = (x) => (x + MG) * s, Y = (y) => (y + MG) * s;
    c.fillStyle = '#1a1424'; c.fillRect(0, 0, cw, ch);
    c.fillStyle = M.floor; c.fillRect(X(0), Y(0), WU * s, HU * s);
    // floor pattern
    c.save(); c.beginPath(); c.rect(X(0), Y(0), WU * s, HU * s); c.clip();
    const fp = M.key;
    if (fp === 'museum' || fp === 'station' || fp === 'airport') {
      c.fillStyle = M.floor2; for (let y = 0; y < HU; y++) for (let x = 0; x < WU; x++) if ((x + y) % 2) c.fillRect(X(x), Y(y), s, s);
    } else if (fp === 'market') {
      c.strokeStyle = 'rgba(0,0,0,.18)'; c.lineWidth = 1; for (let y = 0; y < HU * 2; y++) for (let x = 0; x < WU * 2; x++) { c.beginPath(); c.arc(X(x / 2 + (y % 2) * 0.25 + 0.25), Y(y / 2 + 0.25), s * 0.22, 0, TAU); c.stroke(); }
    } else if (fp === 'party') {
      c.strokeStyle = 'rgba(0,0,0,.2)'; c.lineWidth = 1; for (let y = 0; y < HU * 3; y++) { c.beginPath(); c.moveTo(X(0), Y(y / 3)); c.lineTo(X(WU), Y(y / 3)); c.stroke(); for (let x = (y % 2) * 1.2; x < WU; x += 2.4) { c.beginPath(); c.moveTo(X(x), Y(y / 3)); c.lineTo(X(x), Y((y + 1) / 3)); c.stroke(); } }
    } else if (fp === 'park') {
      c.fillStyle = M.floor2; for (let y = 0; y < HU; y++) for (let x = 0; x < WU; x++) if ((x * 7 + y * 3) % 5 === 0) { c.beginPath(); c.arc(X(x + 0.5), Y(y + 0.5), s * 0.18, 0, TAU); c.fill(); }
      c.fillStyle = '#7d6a54'; c.fillRect(X(0), Y(9.3), WU * s, 2.4 * s); c.fillStyle = 'rgba(255,240,200,.18)'; for (let x = 0; x < WU; x += 1.2) c.fillRect(X(x), Y(10.45), 0.6 * s, 0.1 * s);
    } else if (fp === 'aqua') {
      c.strokeStyle = 'rgba(140,200,255,.08)'; c.lineWidth = Math.max(1, s * 0.08); for (let y = 0.5; y < HU; y += 1.4) { c.beginPath(); for (let x = 0; x <= WU; x += 0.5) c.lineTo(X(x), Y(y + Math.sin(x * 1.3 + y) * 0.18)); c.stroke(); }
    } else {
      c.fillStyle = M.floor2; for (let y = 0; y < HU; y += 2) c.fillRect(X(0), Y(y), WU * s, s);
    }
    c.restore();
    for (const d of M.deco) {
      if (d.k === 'dance') { const n = 6; for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) { c.fillStyle = (x + y) % 2 ? 'rgba(180,140,240,.22)' : 'rgba(240,127,184,.18)'; c.fillRect(X(d.x + x * d.w / n), Y(d.y + y * d.h / n), d.w / n * s, d.h / n * s); } }
      if (d.k === 'rack') { // coat / costume rack = a disguise spot
        const x = X(d.x), y = Y(d.y), w = d.w * s, h = d.h * s;
        c.fillStyle = 'rgba(227,174,69,.16)'; rrect(c, x - s * 0.1, y - s * 0.1, w + s * 0.2, h + s * 0.2, s * 0.2); c.fill();
        c.strokeStyle = '#c9a15a'; c.lineWidth = Math.max(1.5, s * 0.07); c.beginPath(); c.moveTo(x, y + h * 0.2); c.lineTo(x + w, y + h * 0.2); c.stroke();
        ['#e8604c', '#4f9be0', '#4fc38f', '#e8c04e', '#a77be8'].forEach((cl, i) => { c.fillStyle = cl; c.fillRect(x + w * (0.08 + i * 0.18), y + h * 0.25, w * 0.13, h * 0.65); });
        if (d.lab) { c.fillStyle = '#ffe9a8'; c.font = `700 ${Math.max(7, s * 0.28)}px "IBM Plex Sans KR",sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(d.lab, x + w / 2, y - s * 0.22); }
      }
      if (d.k === 'paint') { c.fillStyle = '#c9a15a'; c.fillRect(X(d.x), Y(d.y), d.w * s, d.h * s); c.fillStyle = '#4f7bd0'; c.fillRect(X(d.x + 0.1), Y(d.y + 0.07), (d.w - 0.2) * s, (d.h - 0.14) * s); }
    }
    // walls
    c.strokeStyle = '#8a7a9c'; c.lineWidth = Math.max(2, s * 0.14); c.strokeRect(X(0) - c.lineWidth / 2, Y(0) - c.lineWidth / 2, WU * s + c.lineWidth, HU * s + c.lineWidth);
    // exits
    for (const e of M.ex) {
      const horiz = e.y < 0.6 || e.y > HU - 0.6 || (e.g === 't');
      const w = horiz ? 1.6 : 0.7, h = horiz ? 0.7 : 1.6;
      const x0 = e.x - w / 2, y0 = e.g === 't' ? e.y - 0.45 : e.y < 1 ? -0.1 : e.y > HU - 1 ? HU - 0.6 : e.y - h / 2;
      const xx = e.x < 1 ? -0.1 : e.x > WU - 1 ? WU - 0.6 : x0;
      c.fillStyle = '#2f8a5f'; c.fillRect(X(xx), Y(y0), w * s, h * s);
      c.fillStyle = '#e8ffe9'; c.font = `700 ${Math.max(8, s * 0.36)}px "IBM Plex Sans KR",sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(e.g === 't' ? M.tl : '출구', X(xx + w / 2), Y(y0 + h / 2));
    }
    // seats (chairs)
    for (const S of M.seats) if (S.chair) { c.fillStyle = '#6a4630'; rrect(c, X(S.x) - s * 0.27, Y(S.y) - s * 0.27, s * 0.54, s * 0.54, s * 0.1); c.fill(); }
    const lab = (o, col) => { if (!o.lab) return; c.fillStyle = col || '#f2e9d8'; c.font = `700 ${Math.max(8, s * 0.36)}px "IBM Plex Sans KR",sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(o.lab, X(o.x + o.w / 2), Y(o.y + o.h / 2)); };
    const AW = ['#c94f3d', '#3f66c0', '#3c7d4a', '#c9a15a', '#8a4fc0', '#d0707a'];
    M.ob.forEach((o, oi) => {
      const x = X(o.x), y = Y(o.y), w = o.w * s, h = o.h * s;
      c.lineWidth = Math.max(1, s * 0.05); c.strokeStyle = 'rgba(0,0,0,.45)';
      switch (o.k) {
        case 'case': c.fillStyle = '#4a3122'; c.fillRect(x, y, w, h); c.fillStyle = 'rgba(170,220,235,.28)'; c.fillRect(x + s * 0.08, y + s * 0.08, w - s * 0.16, h - s * 0.16); c.strokeStyle = 'rgba(220,245,255,.6)'; c.strokeRect(x + s * 0.08, y + s * 0.08, w - s * 0.16, h - s * 0.16); break;
        case 'ped': c.fillStyle = '#7d7488'; c.fillRect(x, y, w, h); c.fillStyle = '#9d94a8'; c.fillRect(x + s * 0.1, y + s * 0.1, w - s * 0.2, h - s * 0.2); break;
        case 'stall': {
          c.fillStyle = '#7a5434'; c.fillRect(x, y, w, h);
          const col = AW[oi % AW.length], vert = o.h > o.w, n = 6;
          for (let i = 0; i < n; i++) { c.fillStyle = i % 2 ? col : '#efe6d2'; if (vert) c.fillRect(o.x < 7 ? x : x + w - s * 0.45, y + i * h / n, s * 0.45, h / n); else c.fillRect(x + i * w / n, y, w / n, s * 0.4); }
          break;
        }
        case 'cart': c.fillStyle = '#6b6f7a'; rrect(c, x, y, w, h, s * 0.12); c.fill(); c.stroke(); c.fillStyle = '#222'; c.beginPath(); c.arc(x + s * 0.2, y + h, s * 0.1, 0, TAU); c.arc(x + w - s * 0.2, y + h, s * 0.1, 0, TAU); c.fill(); lab(o, '#fff3cf'); break;
        case 'counter': case 'machine': case 'kiosk': case 'bar': case 'board':
          c.fillStyle = o.k === 'board' ? '#20242c' : o.k === 'machine' ? '#3f66c0' : o.k === 'bar' ? '#5a2a3a' : o.k === 'kiosk' ? '#5f4a33' : '#6e4b2e';
          rrect(c, x, y, w, h, s * 0.1); c.fill(); c.stroke();
          if (o.k === 'board') { c.fillStyle = '#ffb347'; for (let i = 0; i < 4; i++) c.fillRect(x + s * 0.2 + i * w / 4.4, y + h * 0.35, w / 6, h * 0.3); }
          else lab(o, '#fff3cf');
          break;
        case 'bench': c.fillStyle = '#8a6038'; rrect(c, x, y, w, h, s * 0.08); c.fill(); c.stroke(); break;
        case 'rtable': c.fillStyle = '#efe6d2'; c.beginPath(); c.arc(x + w / 2, y + h / 2, w / 2, 0, TAU); c.fill(); c.stroke(); break;
        case 'ltable': c.fillStyle = '#7a5434'; rrect(c, x, y, w, h, s * 0.1); c.fill(); c.stroke(); c.fillStyle = '#e8d8a8'; c.fillRect(x + w * 0.2, y + h * 0.3, s * 0.4, s * 0.3); c.fillRect(x + w * 0.65, y + h * 0.45, s * 0.35, s * 0.28); break;
        case 'gtable': c.fillStyle = '#b5523c'; rrect(c, x, y, w, h, s * 0.1); c.fill(); c.stroke(); c.fillStyle = '#f2c14e'; c.fillRect(x + w / 2 - s * 0.06, y, s * 0.12, h); break;
        case 'fountain': c.fillStyle = '#8d8394'; c.beginPath(); c.arc(x + w / 2, y + h / 2, w / 2, 0, TAU); c.fill(); c.fillStyle = '#4f9be0'; c.beginPath(); c.arc(x + w / 2, y + h / 2, w / 2 - s * 0.16, 0, TAU); c.fill(); c.fillStyle = '#bfe3ff'; c.beginPath(); c.arc(x + w / 2, y + h / 2, s * 0.15, 0, TAU); c.fill(); break;
        case 'shelf': {
          c.fillStyle = '#4a3122'; c.fillRect(x, y, w, h);
          const vert = o.h > o.w, n = Math.floor((vert ? o.h : o.w) / 0.22);
          for (let i = 0; i < n; i++) { c.fillStyle = AW[i % 6]; if (vert) c.fillRect(x + s * 0.08, y + i * 0.22 * s + s * 0.04, w - s * 0.16, s * 0.16); else c.fillRect(x + i * 0.22 * s + s * 0.04, y + s * 0.08, s * 0.16, h - s * 0.16); }
          break;
        }
        case 'plant': c.fillStyle = '#6a4630'; c.beginPath(); c.arc(x + w / 2, y + h / 2, w / 2, 0, TAU); c.fill(); c.fillStyle = '#3c7d4a'; for (let i = 0; i < 5; i++) { c.beginPath(); c.arc(x + w / 2 + Math.cos(i * 1.3) * w * 0.22, y + h / 2 + Math.sin(i * 1.3) * h * 0.22, w * 0.25, 0, TAU); c.fill(); } break;
        case 'stage': c.fillStyle = '#5a2a3a'; rrect(c, x, y, w, h, s * 0.15); c.fill(); c.stroke(); for (let i = 0; i < 7; i++) { c.fillStyle = ['#f2c14e', '#ee6a55', '#5ad1d6', '#b48cf0'][i % 4]; c.beginPath(); c.arc(x + (i + 0.5) * w / 7, y + s * 0.2, s * 0.09, 0, TAU); c.fill(); } break;
        case 'track': c.fillStyle = '#23262e'; c.fillRect(x, y, w, h); c.strokeStyle = '#8b8f99'; c.lineWidth = Math.max(1, s * 0.08); for (const ry of [0.55, 1.25]) { c.beginPath(); c.moveTo(x, Y(ry)); c.lineTo(x + w, Y(ry)); c.stroke(); } c.fillStyle = '#e3ae45'; c.fillRect(x, y + h - s * 0.08, w, s * 0.08); break;
        case 'ride': {
          const cx = x + w / 2, cy = y + h / 2, r = Math.min(w, h) / 2;
          for (let i = 0; i < 12; i++) { c.fillStyle = i % 2 ? '#ee6a55' : '#f2e9d8'; c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, r, i * TAU / 12, (i + 1) * TAU / 12); c.fill(); }
          c.strokeStyle = '#e3ae45'; c.lineWidth = Math.max(2, s * 0.1); c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.stroke();
          c.fillStyle = '#e3ae45'; c.beginPath(); c.arc(cx, cy, r * 0.22, 0, TAU); c.fill(); break;
        }
        case 'shop': c.fillStyle = '#e8e4dc'; rrect(c, x, y, w, h, s * 0.1); c.fill(); c.stroke(); { const vert = o.h > o.w, n = 4; for (let i = 0; i < n; i++) { c.fillStyle = AW[(oi + i) % 6]; if (vert) c.fillRect(x + s * 0.15, y + (i + 0.2) * h / n, w - s * 0.3, h / n * 0.55); else c.fillRect(x + (i + 0.2) * w / n, y + s * 0.15, w / n * 0.55, h - s * 0.3); } } break;
        case 'glass': c.fillStyle = '#1d2a3c'; c.fillRect(x, y, w, h); c.fillStyle = 'rgba(140,200,255,.25)'; for (let i = 0; i < 6; i++) c.fillRect(x + i * w / 6 + s * 0.1, y + s * 0.15, w / 6 - s * 0.2, h - s * 0.3); c.fillStyle = '#e8ecf2'; c.beginPath(); c.ellipse(x + w * 0.5, y + h * 0.5, s * 1.4, s * 0.25, 0, 0, TAU); c.fill(); c.fillRect(x + w * 0.5 - s * 0.2, y + h * 0.5 - s * 0.6, s * 0.4, s * 1.2); break;
        case 'tank': case 'tankw': c.fillStyle = '#2a4f73'; rrect(c, x, y, w, h, s * 0.15); c.fill(); c.fillStyle = '#3c78a8'; rrect(c, x + s * 0.12, y + s * 0.12, w - s * 0.24, h - s * 0.24, s * 0.1); c.fill(); c.fillStyle = 'rgba(255,255,255,.12)'; c.fillRect(x + s * 0.2, y + s * 0.18, w * 0.3, s * 0.12); c.fillStyle = '#d9a35a'; c.fillRect(x + s * 0.12, y + h - s * 0.32, w - s * 0.24, s * 0.2); c.strokeStyle = '#9fd0f0'; c.lineWidth = Math.max(1.5, s * 0.06); c.strokeRect(x, y, w, h); break;
        case 'room': c.fillStyle = '#2a2236'; c.fillRect(x, y, w, h); c.strokeStyle = '#8a7a9c'; c.lineWidth = Math.max(2, s * 0.1); c.strokeRect(x, y, w, h); lab(o, '#c9bfd8'); break;
        default: c.fillStyle = '#555'; c.fillRect(x, y, w, h);
      }
    });
    if (M.wc) { c.fillStyle = '#5bb3e6'; c.beginPath(); c.arc(X(M.wc.x), Y(M.wc.y), s * 0.22, 0, TAU); c.fill(); c.fillStyle = '#10202c'; c.font = `700 ${Math.max(7, s * 0.26)}px "IBM Plex Sans KR",sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('문', X(M.wc.x), Y(M.wc.y)); }
    return cv;
  }
  function itemIcon(k, px) {
    const cv = document.createElement('canvas'); cv.width = px * 2; cv.height = px * 2;
    const c = cv.getContext('2d'); c.scale(2, 2); drawItem(c, k, px / 2, px / 2, px * 0.8); return cv;
  }

  const NZL = ['쨍그랑!', '와르르!', '펑!'];
  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    let st = null, key = null, W = null, lay = null, ais = [], mem = [];
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st || auto()) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const COL = (s) => P(s).color || (L.COLORS && L.COLORS[s % 8]) || '#888';
    const myP = () => { const m = me(); return W && m >= 0 ? W.pp[W.ps[m]] : null; };
    const role = () => { const p = myP(); return !p ? 's' : p.kind === 1 ? 't' : 'g'; };
    const spect = () => { const p = myP(); return !p || (p.kind === 1 && (p.caught || p.gone)); };
    const curKey = () => (st ? st.rid + '.' + st.rd : null);

    /* ----- round start ----- */
    let floats = [], pings = [], rings = [], banner = null, phT = 0, lastFx = 0, lastIv = 0, sel = -1, selLk = -1, zoom = false, runOn = false, holding = false;
    let cardEl = null, cardKey = '', menuOn = false, accI = -1, cctv = null;
    const VH = 150; let vh = [], vhT = -1, ivT = [];
    function startRound() {
      key = curKey();
      W = newWorld(st);
      ais = []; mem = [];
      floats = []; pings = []; rings = []; banner = null; lastFx = W.fxN; lastIv = 0; sel = -1; runOn = false; holding = false; zoom = false; menuOn = false; accI = -1; cctv = null;
      vh = []; vhT = -1; ivT = [];
      for (const k in remIn) delete remIn[k];
      Object.assign(loc, { tap: null, ax: 0, ay: 0, rn: 0, hold: 0, arr: null, wh: 0, act: null, cc: 0, gt: 0 });
      lastQ = -1;
      setPhaseTimer();
      lay = null; layout();
    }
    function humansIn() { for (let s = 0; s < st.np; s++) if (!isAIseat(s)) return true; return false; }
    function setPhaseTimer() { phT = st.ph === 'brief' ? (humansIn() ? BRIEF_T : 1.2) : st.ph === 'end' ? (humansIn() ? END_T : 2.2) : 0; }

    /* ----- layout & camera ----- */
    const cam = { x: WU / 2, y: HU / 2 };
    let bgCv = null, bgKey = '';
    function ctrlOn() { return me() >= 0 && !spect() && st && st.ph === 'play'; }
    function layout() {
      const w = cv.w, h = cv.h, bot = me() >= 0 ? BOT_H : 10;
      const ah = h - HUD_H - bot;
      const ts = Math.max(6, Math.min((w - 8) / WU, ah / HU));
      lay = { w, h, bot, ts, ax: 0, ay: HUD_H, aw: w, ah, ox: (w - WU * ts) / 2, oy: HUD_H + (ah - HU * ts) / 2 };
      btnSig = ''; menuEl.style.bottom = (bot + 6) + 'px';
    }
    cv.onresize = () => { lay = null; if (st) layout(); };
    function view() { // world → screen transform for the main view
      if (!zoom) return { ox: lay.ox, oy: lay.oy, s: lay.ts };
      const s = lay.ts * ZOOM;
      let ox = lay.w / 2 - cam.x * s, oy = lay.ay + lay.ah / 2 - cam.y * s;
      ox = clamp(ox, lay.w - WU * s - 4, 4); oy = clamp(oy, lay.ay + lay.ah - HU * s - 4, lay.ay + 4);
      return { ox, oy, s };
    }
    function focus() {
      const p = myP();
      if (role() === 'g' && sel >= 0 && W.pp[sel] && !W.pp[sel].gone) return W.pp[sel];
      return p && !p.gone ? p : { x: WU / 2, y: HU / 2 };
    }

    /* ----- input ----- */
    const loc = { tap: null, ax: 0, ay: 0, rn: 0, hold: 0, arr: null, wh: 0, act: null, cc: 0, gt: 0 };
    const net = { tq: 0, tx: 0, ty: 0, aq: 0, at: -1, wq: 0, ac: 0, an: '', cq: 0, gq: 0 };
    const remIn = {};
    function walkTo(x, y) {
      if (!W || st.ph !== 'play' || spect()) return;
      x = clamp(x, BR, WU - BR); y = clamp(y, BR, HU - BR);
      if (host()) loc.tap = [x, y]; else { net.tq = (net.tq + 1) % 100000; net.tx = Math.round(x * 10); net.ty = Math.round(y * 10); pubT = 0; }
    }
    function arrest(i) { if (host()) loc.arr = i; else { net.aq = (net.aq + 1) % 100000; net.at = i; pubT = 0; } }
    function whistle() { if (host()) loc.wh = 1; else { net.wq = (net.wq + 1) % 100000; pubT = 0; } }
    function tAct(code) { if (host()) loc.act = code; else { net.ac = (net.ac + 1) % 100000; net.an = code; pubT = 0; } }
    function useCc() { if (host()) loc.cc = 1; else { net.cq = (net.cq + 1) % 100000; pubT = 0; } }
    function useGt() { if (host()) loc.gt = 1; else { net.gq = (net.gq + 1) % 100000; pubT = 0; } }
    const pickable = (q) => q && !q.gone && !q.in && !q.caught && q.lk < 1000;
    function tapAt(sx, sy) {
      if (!W || !lay || st.ph !== 'play' || spect()) return;
      if (menuOn) { menuOn = false; btnSig = ''; return; }
      if (cctv && sy >= cctv.y && sy <= cctv.y + cctv.h) { cctv = null; return; }
      const V = view(), x = (sx - V.ox) / V.s, y = (sy - V.oy) / V.s;
      if (sy < lay.ay || sy > lay.ay + lay.ah) return;
      if (x < -0.3 || y < -0.3 || x > WU + 0.3 || y > HU + 0.3) return;
      if (role() === 'g') {
        let best = -1, bd = Math.max(0.75, 22 / V.s);
        for (const q of W.pp) { if (!pickable(q)) continue; const d = hyp(q.x - x, q.y - y); if (d < bd) { bd = d; best = q.i; } }
        if (best >= 0) { sel = sel === best ? -1 : best; selLk = sel >= 0 ? W.pp[sel].lk : -1; api.sfx('tick'); api.buzz(8); btnSig = ''; return; }
      }
      walkTo(x, y);
      rings.push({ x, y, t: 0, c: '#f2e9d8' });
    }
    let ptr = null, dragT = 0;
    function onDown(e) {
      if (!lay) return;
      const p = cv.local(e);
      ptr = { id: e.pointerId, x: p.x, y: p.y, drag: false };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
    }
    function onMove(e) {
      if (!ptr || e.pointerId !== ptr.id) return;
      const p = cv.local(e);
      if (!ptr.drag && hyp(p.x - ptr.x, p.y - ptr.y) > 14 && !menuOn) ptr.drag = true;
      if (ptr.drag) { ptr.cx = p.x; ptr.cy = p.y; }
    }
    function onUp(e) {
      if (!ptr || e.pointerId !== ptr.id) return;
      const p = cv.local(e);
      if (!ptr.drag) tapAt(p.x, p.y);
      else if (W && st.ph === 'play' && !spect()) { const V = view(); walkTo((p.x - V.ox) / V.s, (p.y - V.oy) / V.s); }
      ptr = null;
    }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- buttons ----- */
    const mk = (cls, label, sub) => { const b = L.h('button', { class: 'ct-b ' + cls }); b.innerHTML = '<span></span><small></small><i class="cd"></i>'; b.firstChild.textContent = label; b.children[1].textContent = sub || ''; b.hidden = true; root.appendChild(b); return b; };
    const bAct = mk('ct-act', '훔치기', '꾹 누르기'), b2 = mk('ct-s2 sq', '행동', ''), b3 = mk('ct-s3 sq', '따라가기', ''), b4 = mk('ct-s4 sq', '변장', ''), bZm = mk('ct-zm', '확대', '');
    const BTNS = [bAct, b2, b3, b4, bZm];
    const setB = (b, cls, lab, sub, cd) => { b.firstChild.textContent = lab; b.children[1].textContent = sub; b.className = 'ct-b ' + cls; b.children[2].style.setProperty('--c', cd || 0); };
    // thief action menu
    const menuEl = L.h('div', { class: 'ct-menu' }); menuEl.hidden = true; root.appendChild(menuEl);
    const MI = [['pho', '사진 찍기'], ['sit', '앉기'], ['que', '줄 서기'], ['noi', '소란'], ['acc', '공범 매수'], ['run', '뛰기']];
    const mBtn = {};
    for (const [id, lab] of MI) {
      const b = L.h('button', {}); b.innerHTML = '<span></span><small></small>'; b.firstChild.textContent = lab;
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); menuPick(id); });
      menuEl.appendChild(b); mBtn[id] = b;
    }
    function menuPick(id) {
      const p = myP(); if (!p || p.kind !== 1 || !ctrlOn()) return;
      menuOn = false; btnSig = '';
      if (id === 'run') { runOn = !runOn; api.sfx('click'); if (runOn) api.toast('뛰면 경비원 눈에 잘 띄어요!'); return; }
      if (id === 'noi' && (p.nzN <= 0 || p.ncd > 0 || W.nz)) { api.toast(p.nzN <= 0 ? '소란은 한 판에 ' + NZ_N + '번까지예요' : W.nz ? '이미 소란이 진행 중이에요' : '소란은 ' + Math.ceil(p.ncd) + '초 뒤에'); return; }
      if (id === 'acc' && p.acU) { api.toast('공범은 한 판에 한 번만 매수해요'); return; }
      tAct(id); api.sfx('tick'); api.buzz(10);
    }
    function pressAct() {
      if (!W || st.ph !== 'play') return;
      const p = myP(); if (!p) return;
      if (p.kind === 2) {
        if (p.ch >= 0) { arrest(-1); api.sfx('click'); return; }
        if (sel < 0) { api.toast('먼저 수상한 사람을 눌러 지목해요'); return; }
        if (W.cf <= 0) { api.toast('수갑이 없어요'); return; }
        arrest(sel); api.sfx('whoosh'); api.buzz(15);
      }
    }
    function press(b) {
      const p = myP(); if (!p || !ctrlOn()) return;
      if (b === b2) {
        if (p.kind === 1) { menuOn = !menuOn; api.sfx('click'); }
        else if (p.wcd > 0) api.toast('호루라기는 ' + Math.ceil(p.wcd) + '초 뒤에'); else { whistle(); api.buzz(20); }
      } else if (b === b3) {
        if (p.kind === 1) { tAct('fol'); api.sfx('tick'); menuOn = false; }
        else if (p.ccd > 0) api.toast('CCTV는 ' + Math.ceil(p.ccd) + '초 뒤에'); else { useCc(); api.sfx('click'); }
      } else if (b === b4) {
        if (p.kind === 1) { if (p.dcd > 0) api.toast('변장은 ' + Math.ceil(p.dcd) + '초 뒤에 다시 할 수 있어요'); else { tAct('dis'); api.sfx('tick'); menuOn = false; api.toast('가까운 옷걸이·화장실로 가서 옷을 바꿔요'); } }
        else if (W.gu <= 0) api.toast('검문은 한 판에 ' + GT_N + '번까지예요'); else { useGt(); api.sfx('chip'); }
      } else if (b === bZm) { zoom = !zoom; const f = focus(); cam.x = f.x; cam.y = f.y; api.sfx('click'); }
      btnSig = '';
    }
    bAct.addEventListener('pointerdown', (e) => { e.preventDefault(); const p = myP(); if (p && p.kind === 1) { holding = true; menuOn = false; btnSig = ''; api.buzz(8); } else pressAct(); });
    const relHold = () => { holding = false; };
    bAct.addEventListener('pointerup', relHold); bAct.addEventListener('pointercancel', relHold); bAct.addEventListener('pointerleave', relHold);
    for (const b of [b2, b3, b4, bZm]) b.addEventListener('pointerdown', (e) => { e.preventDefault(); press(b); });
    window.addEventListener('blur', relHold);
    let offIn = null;
    if (api.input && api.input.on) offIn = api.input.on((type, id) => {
      if (type !== 'down') return;
      const p = myP(); if (!p) return;
      const T = p.kind === 1;
      if (id === 'act' && !T) pressAct();
      else if (id === 'whistle' && !T) press(b2);
      else if (id === 'menu' && T) press(b2);
      else if (id === 'follow' && T) press(b3);
      else if (id === 'cctv' && !T) press(b3);
      else if (id === 'disguise' && T) press(b4);
      else if (id === 'gate' && !T) press(b4);
      else if (id === 'zoom') press(bZm);
      else if (T && ['photo', 'sit', 'queue', 'noise', 'bribe', 'run'].includes(id)) menuPick({ photo: 'pho', sit: 'sit', queue: 'que', noise: 'noi', bribe: 'acc', run: 'run' }[id]);
    });
    let btnSig = '';
    function syncButtons() {
      const on = ctrlOn(), p = myP();
      if (!on) menuOn = false;
      let sig = on ? '1' : '0', A = null;
      if (on) {
        if (p.kind === 1) {
          const j = thiefSpot(W, p), gn = guardNear(W, p.x, p.y, BLOCK_R), eyes = eyesOn(W, p.x, p.y);
          const prog = clamp(p.stl / STEAL_T, 0, 1);
          A = [
            [j < 0 || gn ? 'dim' : holding ? 'on' : 'pulse', '훔치기', j < 0 ? '목표 앞에서' : gn ? '경비원 근처!' : eyes ? '보는 눈 ' + eyes : '지금 안전!', 0, prog],
            [menuOn ? 'sq on' : 'sq', '행동', menuOn ? '닫기 ▼' : '더보기 ▲', 0],
            [p.fol >= 0 ? 'sq on' : 'sq', '따라가기', p.fol >= 0 ? '따라가는 중' : '옆 손님', 0],
            [p.dcd > 0 ? 'sq dim' : 'sq', '변장', p.dcd > 0 ? Math.ceil(p.dcd) + '초' : '옷 바꾸기', p.dcd > 0 ? clamp(p.dcd / DIS_CD, 0, 1) : 0],
          ];
        } else {
          A = [
            p.ch >= 0 ? ['hot', '취소', '쫓는 중', 0, 0] : [sel >= 0 && W.cf > 0 && !(p.fr > 0) ? 'pulse' : 'dim', '체포', W.cf > 0 ? '수갑 ' + W.cf : '수갑 없음', 0, 0],
            [p.wcd > 0 ? 'sq dim' : 'sq', '삑!', p.wcd > 0 ? Math.ceil(p.wcd) + '초' : '호루라기', p.wcd > 0 ? clamp(p.wcd / WHIS_CD, 0, 1) : 0],
            [p.ccd > 0 ? 'sq dim' : recentTheft() ? 'sq pulse' : 'sq', 'CCTV', p.ccd > 0 ? Math.ceil(p.ccd) + '초' : '다시 보기', p.ccd > 0 ? clamp(p.ccd / CC_CD, 0, 1) : 0],
            [W.gu <= 0 ? 'sq dim' : W.gt ? 'sq on' : 'sq', '검문', W.gt ? Math.ceil(W.gt.t) + '초' : '남은 ' + W.gu, 0],
          ];
        }
        sig += JSON.stringify(A) + zoom + menuOn + (p.kind === 1 ? [p.nzN, Math.ceil(p.ncd), p.acU, runOn, W.nz ? 1 : 0].join() : '');
      }
      if (sig === btnSig) return;
      btnSig = sig;
      for (const b of BTNS) b.hidden = !on;
      menuEl.hidden = !(on && menuOn);
      if (!on) return;
      setB(bAct, 'ct-act ' + A[0][0], A[0][1], A[0][2], 0); bAct.style.setProperty('--p', A[0][4] || 0);
      setB(b2, 'ct-s2 ' + A[1][0], A[1][1], A[1][2], A[1][3]);
      setB(b3, 'ct-s3 ' + A[2][0], A[2][1], A[2][2], A[2][3]);
      setB(b4, 'ct-s4 ' + A[3][0], A[3][1], A[3][2], A[3][3]);
      setB(bZm, 'ct-zm' + (zoom ? ' on' : ''), zoom ? '전체' : '확대', '', 0);
      if (p.kind === 1 && menuOn) {
        const M = (id, sub, cls) => { mBtn[id].lastChild.textContent = sub; mBtn[id].className = cls || ''; };
        M('pho', '구경하는 척', ''); M('sit', '빈 의자로', ''); M('que', '줄 끝으로', '');
        M('noi', p.nzN <= 0 ? '다 썼어요' : p.ncd > 0 ? Math.ceil(p.ncd) + '초' : W.nz ? '진행 중' : '남은 ' + p.nzN, p.nzN <= 0 || p.ncd > 0 || W.nz ? 'dim' : '');
        M('acc', p.acU ? '썼어요' : '옆 손님 · 1번', p.acU ? 'dim' : '');
        M('run', runOn ? '켜짐 — 눈에 띄어요' : '빠르지만 수상해요', runOn ? 'on' : '');
      }
    }
    function recentTheft() { if (!W) return false; for (let j = 0; j < W.it.length; j++) if (goneSeen(W, j) && W.t - (ivT[j] == null ? -99 : ivT[j]) <= CC_WIN) return true; return false; }
    function readInput() {
      let ax = 0, ay = 0;
      if (api.input && ctrlOn()) { ax = api.input.axis('left', 'right'); ay = api.input.axis('up', 'down'); const m = hyp(ax, ay); if (m > 1) { ax /= m; ay /= m; } }
      if (ptr && ptr.drag && ctrlOn() && fin(ptr.cx)) { // drag = follow the finger
        dragT -= 1 / 60;
        if (dragT <= 0) { dragT = 0.12; const V = view(); walkTo((ptr.cx - V.ox) / V.s, (ptr.cy - V.oy) / V.s); }
      }
      const p = myP();
      const hold = holding || !!(api.input && api.input.held && api.input.held('act') && p && p.kind === 1);
      loc.ax = ax; loc.ay = ay; loc.rn = runOn ? 1 : 0; loc.hold = hold ? 1 : 0;
    }

    /* ----- host flow ----- */
    let lastQ = -1, pubT = 0, hsQ = 0, inT = 0, lastSig = '';
    function newRem() { return { tap: null, ax: 0, ay: 0, rn: 0, hold: 0, arr: null, wh: 0, act: null, cc: 0, gt: 0, ltq: null, laq: null, lwq: null, lac: null, lcq: null, lgq: null }; }
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.np) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remIn[s] || (remIn[s] = newRem());
        R.ax = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0; R.ay = fin(+o.ay) ? clamp(+o.ay, -1, 1) : 0;
        R.rn = o.rn ? 1 : 0; R.hold = o.hd ? 1 : 0;
        if (R.ltq !== null && o.tq !== R.ltq && fin(o.tx) && fin(o.ty)) R.tap = [clamp(o.tx / 10, 0, WU), clamp(o.ty / 10, 0, HU)];
        if (R.laq !== null && o.aq !== R.laq && fin(o.at)) R.arr = o.at | 0;
        if (R.lwq !== null && o.wq !== R.lwq) R.wh = 1;
        if (R.lac !== null && o.ac !== R.lac && TACTS.includes(o.an)) R.act = o.an;
        if (R.lcq !== null && o.cq !== R.lcq) R.cc = 1;
        if (R.lgq !== null && o.gq !== R.lgq) R.gt = 1;
        R.ltq = o.tq; R.laq = o.aq; R.lwq = o.wq; R.lac = o.ac; R.lcq = o.cq; R.lgq = o.gq;
      }
    }
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'brief') { phT -= dt; if (phT <= 0) { phT = 1e9; api.setState(startPlay(st)); } return; }
      if (st.ph === 'play' && W.res && !W.sent) { W.sent = 1; api.setState(roundOver(st, W)); return; }
      if (st.ph === 'end') { phT -= dt; if (phT <= 0) { phT = 1e9; api.setState(nextRound(st)); } }
    }
    function inputsFor() {
      const I = [];
      for (let s = 0; s < st.np; s++) {
        if (isAIseat(s)) { if (!ais[s]) ais[s] = aiFor(W, s, lvOf(s), mem[s] = {}); I[s] = null; }
        else { ais[s] = null; if (W.ai) W.ai[s] = 0; I[s] = localHuman(s) ? loc : (remIn[s] || (remIn[s] = newRem())); }
      }
      return I;
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ) return;
      lastQ = hs.q;
      try { applySnap(W, hs); } catch (er) { console.error(er); }
      if (Array.isArray(hs.fx)) W.fx = hs.fx;
    }
    function guestStep(rdt) {
      const k = 1 - Math.exp(-rdt * 10);
      for (const p of W.pp) {
        if (p.gone || !fin(p.nx)) continue;
        const ox = p.x, oy = p.y;
        p.x += (p.nx - p.x) * k; p.y += (p.ny - p.y) * k;
        p.vx = (p.x - ox) / Math.max(rdt, 1e-3); p.vy = (p.y - oy) / Math.max(rdt, 1e-3);
        if (fin(p.na)) p.a = wrapA(p.a + wrapA(p.na - p.a) * k);
      }
    }
    function publish(rdt) {
      if (!api.online || !W || !st) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0 || st.ph !== 'play') return;
          pubT = 1 / 12; hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(snapshot(W, key, hsQ));
        } else {
          if (me() < 0) return;
          const ax = Math.round(loc.ax * 100) / 100, ay = Math.round(loc.ay * 100) / 100;
          const o = { k: key, ax, ay, rn: loc.rn, hd: loc.hold, tq: net.tq, tx: net.tx, ty: net.ty, aq: net.aq, at: net.at, wq: net.wq, ac: net.ac, an: net.an, cq: net.cq, gq: net.gq };
          const sig = JSON.stringify(o);
          if (sig === lastSig && inT > 0) return;
          if (pubT > 0) return;
          lastSig = sig; inT = 0.3; pubT = 1 / 15;
          api.net.publish(o);
        }
      } catch (e) {}
    }
    /* what the cameras saw: a short local recording (both host and guests), used by the CCTV replay */
    function recHist() {
      if (!W || st.ph !== 'play' || (W.t - vhT < 0.25 && W.t >= vhT)) return;
      vhT = W.t;
      const n = W.pp.length;
      let e = vh.length >= VH ? vh.shift() : null;
      if (!e || e.x.length !== n) e = { x: new Float32Array(n), y: new Float32Array(n), a: new Float32Array(n), st: new Uint8Array(n), lk: new Int32Array(n), g: new Uint8Array(n) };
      e.t = W.t;
      for (let i = 0; i < n; i++) { const p = W.pp[i]; e.x[i] = p.x; e.y[i] = p.y; e.a[i] = p.a; e.st[i] = p.st; e.lk[i] = p.lk; e.g[i] = p.gone || p.in ? 1 : 0; }
      vh.push(e);
    }

    /* ----- events → feedback ----- */
    function addFloat(x, y, t, col, life) { floats.push({ x, y, t: 0, txt: t, col, life: life || 1.4 }); }
    function setBanner(t, sub, col, life) { banner = { t, sub: sub || '', col: col || '#e3ae45', life: life || 2.4, max: life || 2.4 }; }
    const NO = ['', '근처(3칸)에 따라갈 손님이 없어요', '빈 의자가 없어요', '설 수 있는 줄이 없어요', '변장은 조금 뒤에 다시 할 수 있어요', '소란은 지금 못 써요', '공범은 한 판에 한 번만 매수해요',
      '바로 옆(2칸 안)에 손님이 있어야 해요', '가짜로 훔칠 물건이 없어요', '검문 중인 출구예요! 다른 출구로 가요', '확인할 도난 장면이 없어요 (도난 알림 뒤 25초 안)', '검문을 다 썼어요'];
    const FOL = ['따라가던 손님이 사라졌어요', '대화 무리에 끼었어요', '옆자리에 앉았어요', '따라가기를 멈췄어요', '손님 옆에 붙어 같이 걸어요 · 바닥을 누르면 멈춰요'];
    function onFx(e) {
      const ty = e[1], a = e[2], b = e[3], c = e[4], m = me(), r = role(), M = W.M;
      switch (ty) {
        case 1:
          if (m === b) { api.sfx('chip'); api.buzz(30); setBanner('훔쳤다! ' + W.ns + '/' + W.q, M.it[a].nm + ' 챙김 — ' + ALERT_D + '초 뒤 들켜요. 자연스럽게 떠나요', '#7cc66a', 2.4); }
          else if (r === 't') addFloat(M.it[a].x, M.it[a].y - 0.6, '동료가 훔쳤어요!', '#7cc66a', 1.5);
          break;
        case 2: {
          const q = W.pp[b]; if (q) rings.push({ x: q.x, y: q.y, t: 0, c: '#ee6a55', big: 1 });
          if (m === c) { api.sfx('lose'); api.buzz(120); setBanner('잡혔어요…', '경비원에게 들켰어요', '#ee6a55', 2.6); }
          else if (m === a) { api.sfx('win'); api.buzz(60); setBanner('체포 성공!', name(c) + '이(가) 도둑이었어요! +3점', '#7cc66a', 2.6); }
          else { api.sfx(r === 't' ? 'lose' : 'win'); setBanner('도둑 체포!', name(a) + ' 경비원이 ' + name(c) + '을(를) 잡았어요', r === 't' ? '#ee6a55' : '#7cc66a', 2.4); }
          break;
        }
        case 3: {
          const q = W.pp[b], g = W.pp[W.ps[a]];
          if (q) addFloat(q.x, q.y - 0.55, '?!', '#ffe9a8', 1.4);
          if (g) addFloat(g.x, g.y - 0.6, '죄송합니다…', '#c9bfd8', 1.6);
          api.sfx('thud');
          if (m === a) { api.buzz(60); setBanner('엉뚱한 손님이에요!', '수갑 −1 · −2점 · ' + FREEZE_T + '초 동안 사과 중', '#ee6a55', 2.4); sel = -1; }
          else if (r === 't') addFloat(7.5, 1, '경비원이 헛짚었어요', '#7cc66a', 1.4);
          break;
        }
        case 4: {
          const g = W.pp[a]; if (g) { rings.push({ x: g.x, y: g.y, t: 0, c: '#bfe3ff', wh: 1 }); addFloat(g.x, g.y - 0.7, '삑!', '#bfe3ff', 1.2); }
          api.sfx('pop'); api.buzz(25);
          if (r === 't') setBanner('호루라기!', '손님들처럼 자동으로 멈춰 돌아봐요 — 움직이면 수상해요', '#bfe3ff', 2);
          break;
        }
        case 5:
          if (r === 't') { setBanner('다 훔쳤어요!', '초록 「출구」로 걸어서 나가면 성공 (화살표)', '#7cc66a', 3); api.sfx('win'); }
          else { setBanner('도둑이 다 훔쳤어요!', '출구로 나가기 전에 잡아요 · 「검문」으로 출구를 막아요', '#ee6a55', 3); api.sfx('tick'); api.buzz(40); }
          break;
        case 6: { const E = M.ev; if (E) { setBanner(E.lab, E.sub, '#ffe9a8', 2.6); api.sfx('click'); } break; }
        case 7: setBanner(r === 't' ? '탈출 성공!' : '도둑이 빠져나갔어요…', '', r === 't' ? '#7cc66a' : '#ee6a55', 2.5); break;
        case 8:
          if (m === a) api.toast(b === 1 ? '쫓기를 멈췄어요' : b === 2 ? '놓쳤어요 — 너무 오래 쫓았어요 (수갑은 그대로)' : '놓쳤어요 — 사라졌어요');
          else if (r === 't' && b === 2) addFloat(7.5, 1, '경비원이 쫓기를 포기했어요', '#7cc66a', 1.6);
          break;
        case 10: if (m === a) { api.toast('옷을 갈아입었어요! (' + DIS_CD + '초 뒤 다시)'); api.sfx('pop'); api.buzz(20); } break;
        case 11:
          if (m === a && W.M.it[b]) {
            const age = c / 10; cctv = { j: b, t0: W.t - age, start: performance.now(), x: 0, y: 0, w: 0, h: 0 };
            api.sfx('click'); api.toast('CCTV: 도난 순간을 돌려 봐요 (누르면 닫기)');
          } else if (r === 't') { setBanner('CCTV 확인 중!', '경비원이 도난 장면을 돌려 봐요 — 옷을 바꾸면 헷갈려요', '#ffb3a8', 2.4); api.sfx('tick'); }
          break;
        case 12: {
          const x = a / 10, y = b / 10;
          rings.push({ x, y, t: 0, c: '#ffe28a', big: 1 }); rings.push({ x, y, t: -0.25, c: '#ffe28a', big: 1 });
          addFloat(x, y - 0.6, NZL[c] || '쨍그랑!', '#ffe28a', 1.8);
          api.sfx('thud'); api.buzz(30);
          if (r === 't') setBanner('소란 발생!', '손님들이 소리 난 곳으로 몰려가요 — 지금이 기회!', '#7cc66a', 2.2);
          else setBanner(NZL[c] || '쨍그랑!', '무슨 소리지? 손님들이 몰려가요 — 미끼일 수도 있어요', '#ffe28a', 2.2);
          break;
        }
        case 13: if (r === 't' || spect()) { const it = M.it[a]; if (it) addFloat(it.x, it.y - 0.6, '공범이 챙겼어요', '#c9a7ff', 1.8); } break;
        case 14: if (m === a) { api.toast(FOL[b] || ''); if (b === 4) api.sfx('tick'); } break;
        case 15: if (m === a) { api.toast(NO[b] || '지금은 못 해요'); api.sfx('click'); } break;
        case 16: if (m === a) { api.toast('소란 장치를 놓았어요 — ' + NZ_F + '초 뒤 터져요. 얼른 떠나요!'); api.sfx('pop'); } break;
        case 17:
          if (m === a) { accI = b; const it = M.it[c]; setBanner('공범 매수!', it ? '그 손님이 ' + it.nm + '을(를) 가짜로 훔치러 가요' : '그 손님이 다른 곳에서 훔치는 척해요', '#c9a7ff', 2.4); api.sfx('chip'); }
          break;
        case 18: {
          const ex = M.ex[b];
          if (ex) rings.push({ x: ex.x, y: ex.y, t: 0, c: '#ee6a55', big: 1 });
          api.sfx('chip');
          setBanner('검문 시작!', '한 출구를 ' + GT_T + '초 동안 막아요' + (r === 't' ? ' — 다른 출구로!' : ''), r === 't' ? '#ee6a55' : '#bfe3ff', 2.2);
          break;
        }
      }
    }
    function checkAlerts() {
      for (const e of W.fx) if (e[0] > lastFx) { lastFx = e[0]; try { onFx(e); } catch (er) { console.error(er); } }
      let iv = 0; W.it.forEach((v, j) => { if (goneSeen(W, j)) iv |= 1 << j; });
      if (iv !== lastIv) {
        for (let j = 0; j < W.it.length; j++) if (((iv >> j) & 1) && !((lastIv >> j) & 1)) {
          const it = W.M.it[j]; pings.push({ x: it.x, y: it.y, t: 0 }); ivT[j] = W.t;
          if (role() !== 't') { setBanner('도난 발생!', it.nm + '이(가) 없어졌어요 — 「CCTV」로 돌려 봐요', '#ee6a55', 2.6); api.sfx('tick'); api.buzz(35); }
        }
        lastIv = iv;
      }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      if (curKey() !== key) startRound();
      if (!W || !lay) return;
      const dt = rdt * SPD();
      readInput();
      if (host()) {
        pollHost();
        if (st.ph === 'play' && !W.res) {
          const I = inputsFor();
          if (tickWorld(W, dt, I, ais) > 0) { loc.tap = null; loc.arr = null; loc.wh = 0; loc.act = null; loc.cc = 0; loc.gt = 0; } // one-shot inputs wait for a sim step
        }
        hostFlow(dt);
      } else {
        pollGuest();
        if (st.ph === 'play') guestStep(rdt);
      }
      recHist();
      if (st.ph === 'play') checkAlerts();
      if (sel >= 0) { const q = W.pp[sel]; if (!pickable(q) || q.lk !== selLk) { sel = -1; btnSig = ''; } }
      if (accI >= 0) { const q = W.pp[accI]; if (!q || q.gone) accI = -1; }
      const f = focus(), ck = 1 - Math.exp(-rdt * 6); cam.x += (f.x - cam.x) * ck; cam.y += (f.y - cam.y) * ck;
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t += rdt; if (floats[i].t > floats[i].life) floats.splice(i, 1); }
      for (let i = pings.length - 1; i >= 0; i--) { pings[i].t += rdt; if (pings[i].t > 3) pings.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t += rdt; if (rings[i].t > 1.2) rings.splice(i, 1); }
      if (banner) { banner.life -= rdt; if (banner.life <= 0) banner = null; }
      if (cctv && (now - cctv.start > 7600 || st.ph !== 'play' || role() !== 'g')) cctv = null;
      syncButtons();
      syncCard();
      publish(rdt);
      draw(now);
    }
    const stopLoop = U.loop(frame);

    /* ----- cards (role brief / round end) ----- */
    function syncCard() {
      let k = '';
      if (st.ph === 'brief') k = 'b' + key + role();
      else if (st.ph === 'end') k = 'e' + key;
      if (k === cardKey) { if (cardEl) { const f = cardEl.querySelector('.ft'); if (f && host()) f.textContent = st.ph === 'brief' ? Math.max(0, Math.ceil(phT)) + '초 뒤 시작 · 눌러서 닫기' : Math.max(0, Math.ceil(phT)) + '초 뒤 ' + (st.rd >= st.rounds ? '결과' : '다음 판'); } return; }
      cardKey = k;
      if (cardEl) { cardEl.remove(); cardEl = null; }
      if (!k) return;
      const el = L.h('div', { class: 'ct-card' });
      el.addEventListener('click', () => { el.remove(); if (cardEl === el) cardEl = null; });
      const add = (tag, cls, txt) => { const e = L.h(tag, { class: cls || '' }); e.textContent = txt; el.appendChild(e); return e; };
      const tl = (rows) => { const g = L.h('div', { class: 'tl' }); for (const [b, t] of rows) { const x = L.h('b'); x.textContent = b; const y = L.h('span'); y.textContent = t; g.appendChild(x); g.appendChild(y); } el.appendChild(g); };
      const M = MAPS[st.mk];
      if (st.ph === 'brief') {
        const r = role();
        add('div', 'rl', st.rd + '판 / ' + st.rounds + ' · ' + M.nm);
        if (r === 't') {
          add('h3', '', '당신은 도둑!');
          add('div', '', '손님처럼 굴며 금빛 목표 ' + st.tg.length + '개 중 ' + st.q + '개를 훔치고 출구로 걸어 나가요.');
          const tg = L.h('div', { class: 'tg' });
          for (const j of st.tg) { const sp = L.h('span'); sp.appendChild(itemIcon(M.it[j].k, 24)); sp.appendChild(document.createTextNode(M.it[j].nm)); tg.appendChild(sp); }
          el.appendChild(tg);
          tl([['훔치기', '목표 앞에서 꾹 ' + STEAL_T + '초 (경비원 빨간 원 밖에서)'], ['따라가기', '옆 손님에 붙어 같이 걸어요'], ['변장', '옷걸이·화장실에서 옷 바꾸기'], ['행동', '사진·앉기·줄 서기·소란·공범·뛰기']]);
          add('div', 'rl', '호루라기가 울리면 자동으로 멈춰요 · 물건이 없어진 건 ' + ALERT_D + '초 뒤에 들켜요');
          if (st.th.length > 1) add('div', 'rl', '동료 도둑: ' + st.th.filter((s) => s !== me()).map(name).join(', ') + ' (점선 금테)');
        } else if (r === 'g') {
          add('h3', '', '당신은 경비원');
          add('div', '', '손님 ' + st.cr + '명 속에 도둑 ' + st.th.length + '명이 숨어 있어요. 수상한 사람을 눌러 지목하고 「체포」!');
          tl([['수갑', st.cf + '개(모두 함께) · 틀리면 −1, −2점, ' + FREEZE_T + '초 멈춤'], ['삑!', '모두 멈춰 세워요 (' + WHIS_CD + '초마다)'], ['CCTV', '도난 순간 다시 보기 (' + CC_CD + '초마다)'], ['검문', '출구 하나를 ' + GT_T + '초 막기 (' + GT_N + '번)']]);
          add('div', 'rl', '힌트: 혼자 빠른 사람, 호루라기에 늦게 멈추는 사람, 도난 순간 손을 뻗은 사람');
        } else {
          add('h3', '', '도둑을 찾아라');
          add('div', '', '도둑 ' + st.th.length + '명 vs 경비원 ' + (st.np - st.th.length) + '명 · 구경 중 (도둑은 빨간 테)');
        }
        add('div', 'rl', '맵 기믹: ' + M.tip);
        add('div', 'ft', '');
      } else {
        const rs = st.rs || {};
        add('div', 'rl', st.rd + '판 결과 · ' + M.nm);
        add('h3', '', rs.w === 't' ? '도둑 승리!' : '경비원 승리!');
        add('div', '', rs.why === 'esc' ? '도둑이 물건 ' + rs.ns + '개를 들고 빠져나갔어요' : rs.why === 'caught' ? '도둑을 모두 잡았어요' : '시간 끝! 도둑이 다 못 훔쳤어요 (' + rs.ns + '/' + rs.q + ')');
        add('div', 'rl', '도둑은 ' + st.th.map(name).join(', ') + '이었어요 (지도에 빨간 테)');
        const pts = L.h('div', { class: 'pts' });
        for (let s = 0; s < st.np; s++) { pts.appendChild(document.createTextNode(name(s) + (st.th.includes(s) ? ' (도둑)' : ''))); const b = L.h('b'); b.textContent = ((rs.pts && rs.pts[s]) >= 0 ? '+' : '') + ((rs.pts && rs.pts[s]) || 0) + ' → ' + st.sc[s]; pts.appendChild(b); }
        el.appendChild(pts);
        add('div', 'ft', '');
      }
      root.appendChild(el); cardEl = el;
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, al, stroke) {
      ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle';
      if (stroke) { ctx.lineWidth = stroke; ctx.strokeStyle = 'rgba(12,8,22,.9)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y); }
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function drawAnim(M, X, Y, s, t) { // cheap moving bits: fish in the tanks, the carousel turning
      for (const o of M.ob) {
        if (o.k === 'tank' || o.k === 'tankw') {
          const n = o.k === 'tank' ? 6 : 3;
          for (let i = 0; i < n; i++) {
            const sp = 0.12 + (i % 3) * 0.05, u = ((t * sp + i * 0.37) % 1), dir = i % 2 ? 1 : -1;
            const fx0 = o.x + 0.35 + (dir > 0 ? u : 1 - u) * (o.w - 0.7), fy0 = o.y + 0.3 + ((i * 0.29) % 1) * (o.h - 0.75) + Math.sin(t * 2 + i) * 0.06;
            ctx.fillStyle = ['#ffb347', '#ffe28a', '#ef7fb0', '#5ad1d6'][i % 4];
            ctx.beginPath(); ctx.ellipse(X(fx0), Y(fy0), s * 0.16, s * 0.08, 0, 0, TAU); ctx.fill();
            ctx.beginPath(); ctx.moveTo(X(fx0 - dir * 0.14), Y(fy0)); ctx.lineTo(X(fx0 - dir * 0.26), Y(fy0 - 0.07)); ctx.lineTo(X(fx0 - dir * 0.26), Y(fy0 + 0.07)); ctx.fill();
          }
        } else if (o.k === 'ride') {
          const cx = o.x + o.w / 2, cy = o.y + o.h / 2, r = Math.min(o.w, o.h) / 2 * 0.68;
          for (let i = 0; i < 6; i++) { const a = t * 0.6 + i * TAU / 6; ctx.fillStyle = ['#f2c14e', '#5ad1d6', '#b48cf0'][i % 3]; ctx.beginPath(); ctx.ellipse(X(cx + Math.cos(a) * r), Y(cy + Math.sin(a) * r), s * 0.2, s * 0.12, a + PI / 2, 0, TAU); ctx.fill(); }
        }
      }
    }
    const order = [];
    function drawWorld(V, now, lite) {
      const M = W.M, s = V.s, r = role(), sp = spect() || st.ph === 'end';
      const bk = M.key + '|' + s.toFixed(2) + '|' + cv.dpr;
      if (!lite && (bk !== bgKey || !bgCv)) { bgKey = bk; bgCv = buildBg(M, s, Math.min(2, cv.dpr || 1)); }
      if (bgCv) ctx.drawImage(bgCv, V.ox - MG * s, V.oy - MG * s, (WU + MG * 2) * s, (HU + MG * 2) * s);
      const X = (x) => V.ox + x * s, Y = (y) => V.oy + y * s;
      const t = now / 1000;
      if (!lite) drawAnim(M, X, Y, s, t);
      // event: crowd point / train / parade
      if (W.ev && W.ev.k === 'gat' && !W.ev.par) { ctx.fillStyle = 'rgba(255,233,168,.12)'; ctx.beginPath(); ctx.arc(X(W.ev.x), Y(W.ev.y), (M.ev.r || 2) * s, 0, TAU); ctx.fill(); }
      if (W.ev && W.ev.par && M.ev) {
        const pr = 1 - W.ev.t / (M.ev.dur || 12), x0 = -3 + pr * (WU + 7);
        for (let k = 0; k < 3; k++) {
          const fx0 = x0 - k * 2.6, cy = W.ev.y;
          if (fx0 < -1.5 || fx0 > WU + 1.5) continue;
          ctx.fillStyle = ['#ee6a55', '#4f9be0', '#a77be8'][k]; rrect(ctx, X(fx0 - 0.9), Y(cy - 0.45), 1.8 * s, 0.9 * s, s * 0.25); ctx.fill();
          ctx.strokeStyle = '#f2c14e'; ctx.lineWidth = 2; ctx.stroke();
          for (let b = 0; b < 3; b++) { ctx.fillStyle = ['#ffe28a', '#ef7fb0', '#5ad1d6'][(b + k) % 3]; ctx.beginPath(); ctx.arc(X(fx0 - 0.5 + b * 0.5), Y(cy - 0.7 - Math.sin(t * 3 + b) * 0.08), s * 0.18, 0, TAU); ctx.fill(); }
        }
      }
      if (W.ev && W.ev.k === 'wave' && M.key === 'station') { ctx.fillStyle = '#5b6b8a'; rrect(ctx, X(0.3), Y(0.25), (WU - 0.6) * s, 1.4 * s, s * 0.3); ctx.fill(); ctx.fillStyle = '#bfe3ff'; for (let i = 0; i < 9; i++) ctx.fillRect(X(0.8 + i * 1.55), Y(0.55), s * 0.9, s * 0.5); }
      if (W.ev && W.ev.k === 'wave' && M.key !== 'station') for (const e of M.ex) if (e.g === 't') { ctx.fillStyle = `rgba(255,226,138,${0.35 + 0.3 * Math.sin(t * 6)})`; ctx.fillRect(X(e.x - 0.8), Y(e.y - 0.45), 1.6 * s, 0.7 * s); }
      // thief: no-steal zones around guards
      if (r === 't' && !sp && !lite) for (const q of W.pp) if (q.kind === 2 && !q.gone) { ctx.fillStyle = 'rgba(238,106,85,.1)'; ctx.strokeStyle = 'rgba(238,106,85,.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(X(q.x), Y(q.y), BLOCK_R * s, 0, TAU); ctx.fill(); ctx.stroke(); }
      // closed exit (checkpoint)
      if (W.gt && M.ex[W.gt.e]) {
        const e = M.ex[W.gt.e];
        ctx.fillStyle = 'rgba(238,106,85,.85)'; rrect(ctx, X(e.x) - s * 0.9, Y(e.y) - s * 0.42, s * 1.8, s * 0.84, s * 0.2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(2, s * 0.08); ctx.beginPath(); ctx.moveTo(X(e.x - 0.6), Y(e.y - 0.25)); ctx.lineTo(X(e.x + 0.6), Y(e.y + 0.25)); ctx.moveTo(X(e.x - 0.6), Y(e.y + 0.25)); ctx.lineTo(X(e.x + 0.6), Y(e.y - 0.25)); ctx.stroke();
        if (!lite) txt('검문 ' + Math.ceil(W.gt.t), X(clamp(e.x, 1.2, WU - 1.2)), Y(clamp(e.y, 0.6, HU - 0.6)) + (e.y > HU / 2 ? -s * 0.8 : s * 0.8), '#ffd9d2', `700 ${Math.max(10, s * 0.4)}px "IBM Plex Sans KR",sans-serif`, 'center', 3);
      }
      // items
      const showT = r === 't' || sp;
      M.it.forEach((it, j) => {
        const x = X(it.x), y = Y(it.y), tg = showT && st.tg.includes(j);
        const gone = r === 't' || sp ? W.it[j] : goneSeen(W, j);
        if (gone) {
          ctx.strokeStyle = 'rgba(238,106,85,.85)'; ctx.lineWidth = 2; ctx.setLineDash([3, 3]); ctx.strokeRect(x - s * 0.32, y - s * 0.32, s * 0.64, s * 0.64); ctx.setLineDash([]);
          if (s > 14 && !lite) txt(W.it[j] === 2 && showT ? '공범' : '도난', x, y, W.it[j] === 2 && showT ? '#d9c4ff' : '#ffb3a8', `700 ${Math.max(8, s * 0.3)}px "IBM Plex Sans KR",sans-serif`, 'center', 3);
          return;
        }
        if (tg) { const pu = 0.5 + 0.5 * Math.sin(t * 4); ctx.fillStyle = `rgba(242,193,78,${0.25 + pu * 0.25})`; ctx.beginPath(); ctx.arc(x, y, s * 0.55, 0, TAU); ctx.fill(); }
        drawItem(ctx, it.k, x, y, s * 0.62);
        if (tg) { ctx.strokeStyle = '#f2c14e'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, s * 0.5, 0, TAU); ctx.stroke(); }
        if (W.ev && W.ev.k === 'gat' && W.ev.j === j && s > 12) txt('★', x + s * 0.45, y - s * 0.45, '#ffe9a8', `700 ${s * 0.4}px sans-serif`, 'center', 2);
      });
      // exits glow once quota reached
      if (W.ns >= W.q) M.ex.forEach((e, ei) => { if (W.gt && W.gt.e === ei) return; ctx.strokeStyle = `rgba(124,198,106,${0.5 + 0.4 * Math.sin(t * 5)})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(X(e.x), Y(e.y), s * 0.8, 0, TAU); ctx.stroke(); });
      // noise maker (only the thieves see it ticking) / noise going off
      if (W.nz) {
        const z = W.nz;
        if (z.f > 0 && (r === 't' || sp)) {
          ctx.fillStyle = '#ffe28a'; ctx.beginPath(); ctx.arc(X(z.x), Y(z.y), s * 0.18, 0, TAU); ctx.fill();
          ctx.strokeStyle = 'rgba(255,226,138,.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X(z.x), Y(z.y), s * (0.3 + (t * 2 % 1) * 0.4), 0, TAU); ctx.stroke();
          if (!lite) txt(Math.ceil(z.f) + '', X(z.x), Y(z.y) - s * 0.5, '#ffe28a', `700 ${Math.max(10, s * 0.4)}px "IBM Plex Mono",monospace`, 'center', 3);
        } else if (z.f <= 0) { ctx.strokeStyle = `rgba(255,226,138,${0.25 + 0.2 * Math.sin(t * 8)})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X(z.x), Y(z.y), s * 1.7, 0, TAU); ctx.stroke(); }
      }
      // people (sorted by y)
      order.length = 0;
      for (const q of W.pp) if (!q.gone && !q.in) order.push(q);
      order.sort((a, b) => a.y - b.y);
      const m = myP(), tb = st.ph === 'end' && st.rs ? st.rs.tb || [] : null;
      for (const q of order) {
        const x = X(q.x), y = Y(q.y);
        const gc = isGk(q.lk) ? COL(q.lk - 1000) : null;
        drawPerson(ctx, q, x, y, s, now, gc, lite);
        if (lite) continue;
        let ring = null, dash = false, lab = '';
        if (q === m) { ring = '#f2c14e'; lab = '나'; }
        else if (r === 't' && q.kind === 1 && !sp) { ring = '#f2c14e'; dash = true; lab = '동료'; }
        else if (r === 't' && q.i === accI && !sp) { ring = '#c9a7ff'; dash = true; lab = '공범'; }
        if (tb && tb.includes(q.i)) { ring = '#ee6a55'; lab = '도둑'; }
        else if (sp && q.kind === 1 && st.ph === 'play') { ring = '#ee6a55'; dash = true; lab = s > 14 ? '도둑' : ''; }
        if (q.i === sel) { ring = '#ee6a55'; dash = true; lab = '지목'; }
        if (q.caught) lab = '체포!';
        if (ring) {
          ctx.strokeStyle = ring; ctx.lineWidth = 2.2; if (dash) ctx.setLineDash([4, 3]);
          ctx.beginPath(); ctx.arc(x, y, s * 0.48, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
        }
        if (lab) txt(lab, x, y - s * 0.72, ring || '#ffb3a8', `700 ${Math.max(10, s * 0.4)}px "IBM Plex Sans KR",sans-serif`, 'center', 3);
        if (isGk(q.lk) && (q.ch >= 0 || q.chs) && (q === m || sp)) {
          const tq = q.ch >= 0 ? W.pp[q.ch] : null;
          if (tq && !tq.gone) { ctx.strokeStyle = 'rgba(238,106,85,.7)'; ctx.lineWidth = 2; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(X(tq.x), Y(tq.y)); ctx.stroke(); ctx.setLineDash([]); }
        }
        if (isGk(q.lk) && q.st === 8) txt('…', x, y - s * 0.6, '#c9bfd8', `700 ${Math.max(10, s * 0.45)}px sans-serif`, 'center', 3);
      }
      if (lite) return;
      if (m && m.kind === 1 && !m.gone) {
        // following: a soft tether to the guest I walk with
        if (m.fol >= 0 && W.pp[m.fol] && !W.pp[m.fol].gone) { const q = W.pp[m.fol]; ctx.strokeStyle = 'rgba(242,193,78,.45)'; ctx.lineWidth = 2; ctx.setLineDash([2, 4]); ctx.beginPath(); ctx.moveTo(X(m.x), Y(m.y)); ctx.lineTo(X(q.x), Y(q.y)); ctx.stroke(); ctx.setLineDash([]); ctx.beginPath(); ctx.arc(X(q.x), Y(q.y), s * 0.44, 0, TAU); ctx.stroke(); }
        // own steal progress over my head
        if (m.stl > 0) { ctx.strokeStyle = '#ffe28a'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(X(m.x), Y(m.y), s * 0.62, -PI / 2, -PI / 2 + TAU * clamp(m.stl / STEAL_T, 0, 1)); ctx.stroke(); }
        // all stolen: an arrow to the nearest open exit
        if (W.ns >= W.q) {
          let be = null, bd = 1e9; M.ex.forEach((e, ei) => { if (W.gt && W.gt.e === ei) return; const d = hyp(e.x - m.x, e.y - m.y); if (d < bd) { bd = d; be = e; } });
          if (be && bd > 1.2) {
            const a = Math.atan2(be.y - m.y, be.x - m.x), ax = X(m.x) + Math.cos(a) * s * 0.95, ay = Y(m.y) + Math.sin(a) * s * 0.95;
            ctx.save(); ctx.translate(ax, ay); ctx.rotate(a); ctx.fillStyle = '#7cc66a'; ctx.strokeStyle = 'rgba(12,8,22,.8)'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(s * 0.4, 0); ctx.lineTo(-s * 0.1, -s * 0.28); ctx.lineTo(-s * 0.1, s * 0.28); ctx.closePath(); ctx.stroke(); ctx.fill(); ctx.restore();
          }
        }
      }
      for (const g of rings) {
        if (g.t < 0) continue;
        const k = g.t / 1.2;
        ctx.strokeStyle = g.c; ctx.globalAlpha = 1 - k; ctx.lineWidth = g.big ? 4 : 2;
        ctx.beginPath(); ctx.arc(X(g.x), Y(g.y), s * (g.wh ? 0.4 + k * 6 : g.big ? 0.5 + k * 2 : 0.15 + k * 0.5), 0, TAU); ctx.stroke(); ctx.globalAlpha = 1;
      }
      for (const p of pings) { const k = (p.t % 1); ctx.strokeStyle = `rgba(238,106,85,${(1 - k) * (1 - p.t / 3)})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(X(p.x), Y(p.y), s * (0.4 + k * 2.4), 0, TAU); ctx.stroke(); }
      if (W.dark) { ctx.fillStyle = 'rgba(6,4,14,.55)'; ctx.fillRect(X(W.dark.x), Y(0), W.dark.w * s, HU * s); }
      for (const f of floats) { const k = f.t / f.life; ctx.globalAlpha = k > 0.75 ? (1 - k) * 4 : 1; txt(f.txt, X(f.x), Y(f.y) - k * s * 0.8, f.col, `700 ${Math.max(12, s * 0.5)}px "IBM Plex Sans KR",sans-serif`, 'center', 3); ctx.globalAlpha = 1; }
    }
    const ghost = { i: 0, lk: 0, st: 0, a: 0, vx: 0, vy: 0, caught: 0 };
    function drawCctv(now) { // grainy replay of the seconds around the theft
      const C = cctv, it = W.M.it[C.j]; if (!it) { cctv = null; return; }
      const w = Math.min(lay.w - 20, 380), h = Math.round(Math.min(200, lay.ah * 0.36)), x0 = (lay.w - w) / 2, y0 = lay.ay + 8;
      C.x = x0; C.y = y0; C.w = w; C.h = h;
      const pt = C.t0 - 2.4 + ((now - C.start) / 1000) % 3.6;
      let a = null, b = null;
      for (let i = 0; i < vh.length; i++) { if (vh[i].t <= pt) a = vh[i]; else { b = vh[i]; break; } }
      if (!a) a = b; if (!b) b = a;
      ctx.save();
      rrect(ctx, x0, y0, w, h, 12); ctx.fillStyle = '#0d0b12'; ctx.fill(); ctx.clip();
      const s = w / 8, vw = w / s / 2, vhh = h / s / 2, ccx = clamp(it.x, vw - 0.3, WU - vw + 0.3), ccy = clamp(it.y, vhh - 0.3, HU - vhh + 0.3), ox = x0 + w / 2 - ccx * s, oy = y0 + h / 2 - ccy * s;
      if (bgCv) ctx.drawImage(bgCv, ox - MG * s, oy - MG * s, (WU + MG * 2) * s, (HU + MG * 2) * s);
      if (pt < C.t0 || !W.it[C.j]) drawItem(ctx, it.k, ox + it.x * s, oy + it.y * s, s * 0.62);
      if (a) {
        const k = b && b.t > a.t ? clamp((pt - a.t) / (b.t - a.t), 0, 1) : 0;
        const idx = [];
        for (let i = 0; i < a.x.length; i++) if (!a.g[i]) idx.push(i);
        idx.sort((i, j) => a.y[i] - a.y[j]);
        for (const i of idx) {
          const xx = b && !b.g[i] ? a.x[i] + (b.x[i] - a.x[i]) * k : a.x[i], yy = b && !b.g[i] ? a.y[i] + (b.y[i] - a.y[i]) * k : a.y[i];
          ghost.i = i; ghost.lk = a.lk[i]; ghost.st = a.st[i]; ghost.a = a.a[i]; ghost.vx = b ? (b.x[i] - a.x[i]) * 4 : 0; ghost.vy = b ? (b.y[i] - a.y[i]) * 4 : 0;
          drawPerson(ctx, ghost, ox + xx * s, oy + yy * s, s, now, isGk(ghost.lk) ? COL(ghost.lk - 1000) : null, false);
        }
      } else txt('녹화가 없어요', x0 + w / 2, y0 + h / 2, '#c9bfd8', '13px "IBM Plex Sans KR",sans-serif');
      ctx.strokeStyle = 'rgba(238,106,85,.8)'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.arc(ox + it.x * s, oy + it.y * s, s * 0.6, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      // CCTV look: tint, scanlines, a little grain
      ctx.fillStyle = 'rgba(70,110,90,.28)'; ctx.fillRect(x0, y0, w, h);
      ctx.fillStyle = 'rgba(0,0,0,.18)'; for (let y = y0; y < y0 + h; y += 3) ctx.fillRect(x0, y, w, 1);
      const gy = y0 + ((now / 7) % h); ctx.fillStyle = 'rgba(255,255,255,.06)'; ctx.fillRect(x0, gy, w, 6);
      ctx.restore();
      ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2; rrect(ctx, x0, y0, w, h, 12); ctx.stroke();
      const rel = pt - C.t0;
      if (Math.sin(now / 250) > 0) { ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.arc(x0 + 14, y0 + 14, 5, 0, TAU); ctx.fill(); }
      txt('CCTV · ' + it.nm, x0 + 24, y0 + 14, '#f2e9d8', '700 12px "IBM Plex Sans KR",sans-serif', 'left', 3);
      txt((rel < 0 ? '도난 ' + (-rel).toFixed(1) + '초 전' : '도난 순간 +' + rel.toFixed(1) + '초'), x0 + w - 10, y0 + 14, '#ffe9a8', '700 12px "IBM Plex Mono",monospace', 'right', 3);
      txt('누르면 닫기', x0 + w - 10, y0 + h - 12, '#c9bfd8', '11px "IBM Plex Sans KR",sans-serif', 'right', 3);
    }
    function hint() {
      const p = myP(), r = role();
      if (st.ph !== 'play') return '';
      if (r === 's') return me() >= 0 ? '잡혔어요 — 구경 중 (도둑은 빨간 테)' : '구경 중 · 빨간 점선 = 도둑';
      if (r === 't') {
        if (W.ns >= W.q) return W.gt ? '다 훔쳤어요! 검문 없는 출구로 걸어 나가요' : '다 훔쳤어요! 화살표 쪽 출구로 걸어 나가요';
        if (W.wh) return '호루라기! 자동으로 멈췄어요 — 움직이면 수상해요';
        if (p.in) return '화장실 안… ' + (p.dcd <= 0 ? '나오면 옷이 바뀌어요' : '');
        if (p.st === 14) return '옷 바꾸는 중… 움직이지 마세요';
        const j = thiefSpot(W, p);
        if (j >= 0) return guardNear(W, p.x, p.y, BLOCK_R) ? '경비원이 너무 가까워요 — 기다리거나 「소란」을 써요' : '지금 「훔치기」를 꾹 눌러요 (' + STEAL_T + '초)';
        if (runOn) return '뛰는 중 — 경비원 눈에 잘 띄어요!';
        if (p.fol >= 0) return '손님 옆에서 같이 걷는 중 · 목표 앞에서 멈추면 훔쳐요';
        return '금빛 목표 앞을 눌러 가요 · 「따라가기」로 손님 틈에 섞여요';
      }
      if (p.fr > 0) return '사과하는 중… 잠깐 못 움직여요';
      if (p.ch >= 0) return '달려가는 중! (「취소」로 멈춰요)';
      if (W.ns >= W.q) return '도둑이 다 훔쳤어요! 「검문」으로 출구를 막고 잡아요';
      if (W.cf <= 0) return '수갑이 없어요 — 시간을 버티면 승리';
      if (sel >= 0) return '「체포」를 누르면 달려가 잡아요 · 다시 누르면 지목 해제';
      if (recentTheft() && p.ccd <= 0) return '도난 발생! 「CCTV」로 그 순간을 돌려 봐요';
      return '수상한 사람을 눌러 지목 · 바닥을 누르면 이동';
    }
    function drawEye(x, y, n) { // how many guards can see me right now
      const col = n === 0 ? '#7cc66a' : n === 1 ? '#e3ae45' : '#ee6a55';
      ctx.fillStyle = 'rgba(12,8,22,.6)'; rrect(ctx, x, y - 12, 50, 24, 12); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x + 7, y); ctx.quadraticCurveTo(x + 17, y - 9, x + 27, y); ctx.quadraticCurveTo(x + 17, y + 9, x + 7, y); ctx.fillStyle = col; ctx.fill();
      ctx.fillStyle = '#17131f'; ctx.beginPath(); ctx.arc(x + 17, y, 3, 0, TAU); ctx.fill();
      txt(String(n), x + 38, y + 1, col, '700 14px "IBM Plex Mono",monospace');
    }
    function draw(now) {
      cv.clear();
      ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, lay.w, lay.h);
      if (!W) return;
      const V = view();
      ctx.save(); ctx.beginPath(); ctx.rect(0, lay.ay, lay.w, lay.ah); ctx.clip();
      drawWorld(V, now, false);
      if (cctv) drawCctv(now);
      // event banner over the map
      if (banner) {
        const k = banner.life / banner.max, a = Math.min(1, k * 4, (1 - k) * 8 + 0.2);
        ctx.globalAlpha = a;
        const y = lay.ay + (cctv ? cctv.h + 40 : 30), w = Math.min(lay.w - 24, 340);
        ctx.fillStyle = 'rgba(20,14,30,.88)'; rrect(ctx, lay.w / 2 - w / 2, y - 22, w, banner.sub ? 50 : 34, 14); ctx.fill();
        ctx.strokeStyle = banner.col; ctx.lineWidth = 1.5; ctx.stroke();
        txt(banner.t, lay.w / 2, y - 5, banner.col, '20px "Black Han Sans",sans-serif');
        if (banner.sub) { ctx.font = '12px "IBM Plex Sans KR",sans-serif'; let sb = banner.sub; while (ctx.measureText(sb).width > w - 16 && sb.length > 4) sb = sb.slice(0, -2); txt(sb === banner.sub ? sb : sb + '…', lay.w / 2, y + 16, '#f2e9d8', '12px "IBM Plex Sans KR",sans-serif'); }
        ctx.globalAlpha = 1;
      }
      ctx.restore();
      // inset zoom on the person a guard has picked (bottom-left of the map)
      if (role() === 'g' && sel >= 0 && !zoom && ctrlOn()) {
        const q = W.pp[sel], R = 42, cx = 10 + R, cy = lay.ay + lay.ah - 8 - R, s = lay.ts * 3.2;
        ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fillStyle = '#17131f'; ctx.fill(); ctx.clip();
        drawWorld({ ox: cx - q.x * s, oy: cy - q.y * s, s }, now, true);
        ctx.restore();
        ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
        txt('지목', cx, cy + R - 6, '#ffb3a8', '700 11px "IBM Plex Sans KR",sans-serif', 'center', 3);
      }
      // HUD
      const g = ctx.createLinearGradient(0, 0, 0, HUD_H); g.addColorStop(0, '#221a30'); g.addColorStop(1, '#1b1526');
      ctx.fillStyle = g; ctx.fillRect(0, 0, lay.w, HUD_H);
      ctx.fillStyle = 'rgba(227,174,69,.25)'; ctx.fillRect(0, HUD_H - 1, lay.w, 1);
      const r = role(), w = lay.w;
      const chip = r === 't' ? ['도둑', '#b5523c'] : r === 'g' ? ['경비원', '#2d3f73'] : ['구경', '#4a3f5c'];
      ctx.font = '700 13px "IBM Plex Sans KR",sans-serif'; const cw = ctx.measureText(chip[0]).width + 18;
      ctx.fillStyle = chip[1]; rrect(ctx, 8, 7, cw, 24, 12); ctx.fill();
      txt(chip[0], 8 + cw / 2, 19.5, '#fff', '700 13px "IBM Plex Sans KR",sans-serif');
      const mp = myP();
      if (r === 't' && st.ph === 'play' && mp && !mp.gone) drawEye(8 + cw + 6, 19, eyesOn(W, mp.x, mp.y));
      const left = st.ph === 'play' ? W.T - W.t : st.tm;
      txt(mmss(left), w / 2 + (r === 't' ? 14 : 0), 19, left < 30 && st.ph === 'play' ? '#ee6a55' : '#f2e9d8', '700 20px "IBM Plex Mono",monospace');
      txt('도난 ' + W.ns + '/' + W.q + '  수갑 ' + W.cf, w - 8, 19, '#e3ae45', '700 13px "IBM Plex Sans KR",sans-serif', 'right');
      let h = hint(); ctx.font = '12.5px "IBM Plex Sans KR",sans-serif';
      while (h && ctx.measureText(h).width > w - 16 && h.length > 4) h = h.slice(0, -2);
      if (h) txt(h, w / 2, 44, '#d8cfe6', '12.5px "IBM Plex Sans KR",sans-serif');
    }

    return {
      update(next) {
        const prevPh = st ? st.ph : null;
        st = next;
        if (curKey() !== key) startRound();
        else if (prevPh !== st.ph) setPhaseTimer();
        if (!lay) layout();
        if (prevPh !== st.ph) { lay = null; layout(); btnSig = ''; if (st.ph === 'play' && myP()) { api.sfx('whoosh'); api.buzz(20); } }
      },
      destroy() {
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', relHold);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        for (const b of BTNS) b.remove();
        menuEl.remove();
        if (cardEl) cardEl.remove();
        styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, loc, sel, act: tAct, press: (n) => press([bAct, b2, b3, b4, bZm][n]), menu: (id) => { menuOn = true; menuPick(id); }, cctv: () => cctv,
        tapPerson(i) { const V = view(), q = W.pp[i]; tapAt(V.ox + q.x * V.s, V.oy + q.y * V.s); } }),
    };
  }

  L.register({
    id: 'crowdthief', name: '군중 속 도둑', tag: '1 대 다 관찰 추리', cat: '파티',
    blurb: '도둑은 손님 무리 속에 똑같은 모습으로 섞여 몰래 물건을 훔치고(변장·따라가기·소란·공범), 경비원들은 움직임과 CCTV로 도둑을 찾아 체포해요. 연기력 대 관찰력! 맵 8곳(한 폰에 한 명, 빈자리는 AI).',
    tint: '#4a2a55',
    icon: '<circle cx="14" cy="22" r="6" fill="currentColor" opacity=".45"/><circle cx="42" cy="22" r="6" fill="currentColor" opacity=".45"/><path d="M5 46c1-9 5-14 9-14s8 5 9 14z" fill="currentColor" opacity=".45"/><path d="M33 46c1-9 5-14 9-14s8 5 9 14z" fill="currentColor" opacity=".45"/><circle cx="28" cy="19" r="7" fill="currentColor"/><path d="M19 23h18v-3H19z" fill="currentColor"/><rect x="21" y="16.5" width="14" height="4" rx="2" fill="#000" opacity=".5"/><path d="M17 48c1-11 6-17 11-17s10 6 11 17z" fill="currentColor"/>',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.nm }))), def: -1 },
      { id: 'rounds', label: '판 수', choices: [{ v: 1, label: '1판' }, { v: 2, label: '2판' }, { v: 3, label: '3판' }, { v: 4, label: '4판' }], def: 2 },
      { id: 'time', label: '한 판 시간', choices: [{ v: 120, label: '2분' }, { v: 180, label: '3분' }, { v: 240, label: '4분' }], def: 180 },
      { id: 'nth', label: '도둑 수', choices: [{ v: 'auto', label: '자동(6명↑ 2명)' }, { v: 1, label: '1명' }, { v: 2, label: '2명(4명↑)' }], def: 'auto' },
      { id: 'crowd', label: '손님 수', choices: [{ v: 's', label: '적게(20)' }, { v: 'm', label: '보통(26~28)' }, { v: 'l', label: '많이(34)' }], def: 'm' },
      { id: 'who', label: '도둑 정하기', choices: [{ v: 'rand', label: '무작위' }, { v: 'p1', label: '1번 자리 먼저' }, { v: 'guard', label: '1번은 경비원만' }], def: 'rand' },
    ],
    controls: [
      { id: 'up', label: '위로 걷기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 걷기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 걷기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 걷기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'act', label: '훔치기(꾹) / 체포', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'whistle', label: '경비원: 호루라기', keys: ['KeyQ', 'KeyL'], pad: ['x'] },
      { id: 'menu', label: '도둑: 행동 메뉴', keys: ['KeyR'], pad: ['x'] },
      { id: 'follow', label: '도둑: 따라가기', keys: ['KeyF'], pad: ['rb'] },
      { id: 'cctv', label: '경비원: CCTV', keys: ['KeyC'], pad: ['rb'] },
      { id: 'disguise', label: '도둑: 변장', keys: ['KeyE'], pad: ['lb'] },
      { id: 'gate', label: '경비원: 검문', keys: ['KeyG'], pad: ['lb'] },
      { id: 'photo', label: '도둑: 사진 찍기', keys: ['Digit1'], pad: [] },
      { id: 'sit', label: '도둑: 앉기', keys: ['Digit2'], pad: [] },
      { id: 'queue', label: '도둑: 줄 서기', keys: ['Digit3'], pad: [] },
      { id: 'noise', label: '도둑: 소란', keys: ['Digit4'], pad: ['rt'] },
      { id: 'bribe', label: '도둑: 공범 매수', keys: ['Digit5'], pad: ['lt'] },
      { id: 'run', label: '도둑: 뛰기 켬/끔', keys: ['ShiftLeft', 'KeyK'], pad: ['b'] },
      { id: 'zoom', label: '확대/전체 보기', keys: ['KeyZ'], pad: ['y'] },
    ],
    quick: [
      '도둑 1명(6명 이상이면 2명)이 똑같이 생긴 손님 무리 속에 섞여요. 나머지는 경비원!',
      '도둑: 손님처럼 굴며(따라가기·사진·앉기·변장) 금빛 목표 앞에서 「훔치기」 꾹 1.5초, 3개(도둑 2명이면 함께 5개)를 훔쳐 출구로 나가면 승리.',
      '경비원: 수상한 사람을 눌러 「체포」. CCTV·호루라기·검문을 써요. 도둑을 다 잡거나 시간을 버티면 승리. 틀리면 손해가 커요.',
    ],
    rules: [
      { h: '목표', p: [
        '박물관·시장·놀이공원 같은 곳에 손님(컴퓨터가 움직이는 사람)이 20~34명 있어요. 그중 1~2명이 진짜 사람(또는 AI) 도둑이에요.',
        '도둑은 손님과 똑같이 생겼어요. 손님처럼 행동하며 몰래 물건을 훔치고 빠져나가야 해요.',
        '경비원은 모자를 쓴 남색 제복이에요. 사람들의 움직임을 보고 도둑을 찾아 체포해요.',
        '내 폰에는 내 역할만 보여요(도둑은 목표 물건이 금빛으로). 그래서 친구와는 각자 폰으로 해요(온라인·LAN 방).',
      ] },
      { h: '손님들은 이렇게 움직여요', p: [
        '구경하기(가끔 손을 뻗어 가리켜요), 사진 찍기, 의자에 앉기, 줄 서기, 화장실, 옷걸이에서 옷 갈아입기, 서너 명이 모여 대화하기(말풍선), 경비원에게 길 묻기(?), 아이 데리고 다니기, 돌아다니기, 드나들기.',
        '손님은 절대 뛰지 않아요. 호루라기가 울리면 잠깐 뒤에 모두 멈춰서 경비원 쪽을 돌아봐요.',
        '아이(작은 사람)는 도둑이 될 수 없고 지목도 안 돼요.',
      ] },
      { h: '도둑이 할 일', p: [
        '바닥을 누르면 그곳으로 걸어가요(누른 채 끌면 손가락을 따라가요). 물건·의자·옷걸이·화장실 문·대화 무리를 누르면 거기서 구경·앉기·변장·대화를 해요.',
        '금빛 목표 앞에 서서 「훔치기」를 1.5초 꾹 누르면 훔쳐요. 손을 뻗는 모습이 보이지만, 손님들도 가끔 손을 뻗으니 그것만으로는 들키지 않아요.',
        '경비원이 가까이(내 화면의 빨간 원 안) 있으면 못 훔쳐요. 위쪽 눈 표시는 지금 나를 볼 수 있는 경비원 수예요(초록 0 = 안전).',
        '물건이 없어지면 5초 뒤에 경비원 화면에 「도난!」이 떠요. 그 전에 자연스럽게 다른 곳으로 가요.',
        '호루라기가 울리면 내 도둑도 손님처럼 자동으로 멈춰 돌아봐요. 그때 일부러 움직이면(누르기·끌기) 아주 수상해 보여요.',
        '목표를 다 훔치면 초록 화살표를 따라 「출구」로 걸어 나가면 성공! 검문 중인 출구(빨간 X)로는 못 나가요.',
      ] },
      { h: '도둑의 섞이기 도구', p: [
        '「따라가기」: 옆(3칸 안) 손님에게 붙어 같은 속도로 같이 걷고, 그 사람이 구경하면 나도 구경해요. 대화 무리에 들어가면 같이 끼고, 앉으면 옆자리에 앉아요. 바닥을 누르면 멈춰요.',
        '「변장」: 가장 가까운 옷걸이(알록달록한 옷걸이)나 화장실로 걸어가 옷을 바꿔요. 다시 하려면 30초 기다려요. 쫓기는 중에 화장실에 들어가면 경비원이 놓쳐요.',
        '「행동」 메뉴 — 사진 찍기(가까운 볼거리를 향해 폰을 들어요), 앉기(빈 의자로), 줄 서기(가까운 줄 끝으로): 손님과 똑같은 행동이에요.',
        '「소란」(한 판에 2번): 지금 자리에 장치를 놓으면 3초 뒤 「쨍그랑!」 — 근처 손님들이 그쪽으로 몰려가고 경비원도 보러 갈 수 있어요. 그 틈에 훔쳐요.',
        '「공범 매수」(한 판에 1번): 바로 옆 손님을 매수하면, 그 손님이 멀리 있는 다른 물건을 진짜 도둑처럼 손을 뻗어 챙기고 출구로 나가요. 경비원이 그 손님을 잡으면 틀린 체포!',
        '「뛰기」: 빠르지만 손님은 절대 뛰지 않아서 아주 눈에 띄어요.',
      ] },
      { h: '경비원이 할 일', p: [
        '사람을 누르면 「지목」(빨간 점선, 왼쪽 아래에 크게 보여요). 「체포」를 누르면 그 사람에게 달려가 붙잡아요. 8초 안에 못 잡으면 놓쳐요(수갑은 그대로).',
        '도둑이면 체포 성공(+3점)! 손님이면 「죄송합니다…」 — 수갑을 하나 잃고, 4초 동안 못 움직이고, −2점이에요.',
        '수갑은 경비원 모두가 함께 써요(도둑 수 + 1개, 경비원이 4명 이상이면 +1).',
        '「삑!」 호루라기(30초마다): 손님들은 모두 멈춰서 돌아봐요. 계속 움직이는 사람이 수상해요.',
        '「CCTV」(45초마다): 도난 알림이 뜬 뒤 25초 안에 누르면, 물건이 없어지기 2초 전부터 잠깐 뒤까지를 화면 위에 다시 보여줘요. 누가 손을 뻗었는지 보되, 손님들도 손을 뻗고 도둑은 옷을 바꿀 수 있어요.',
        '「검문」(한 판에 2번): 나와 가장 가까운 출구를 20초 동안 막아요. 도둑이 다 훔친 뒤에 쓰면 좋아요.',
        '경비원이 가까이 서 있으면 그 근처 물건은 못 훔쳐요. 지키는 것도 중요해요!',
      ] },
      { h: '승리·점수', p: [
        '도둑 승리: 목표 수만큼 훔치고 도둑 한 명이 출구로 나가면.',
        '경비원 승리: 도둑을 모두 잡거나, 시간(기본 3분)이 끝나면.',
        '점수: 도둑은 훔친 물건마다 +1, 탈출 성공 +3. 경비원은 도둑 체포 +3, 경비원 승리 +2, 틀린 체포 −2.',
        '예시) 도둑이 물건 3개를 훔치고 나가면 3+3 = 6점. 경비원이 도둑을 잡으면 그 경비원은 3+2 = 5점, 다른 경비원은 2점.',
        '판마다 아직 도둑을 안 해 본 사람 중에서 도둑을 정해요. 모든 판이 끝나고 합계가 가장 높은 사람이 우승!',
      ] },
      { h: '맵과 기믹', p: [
        '별빛 박물관: 「해설 시간」 — 한 전시품 앞에 손님들이 몰려요(★ 표시).',
        '골목 시장: 「반짝 할인」 — 한 가게에 손님이 몰려요.',
        '기차역 대합실: 「열차 도착」 — 손님들이 우르르 타고 내려요(새 얼굴이 많이 생겨요).',
        '한밤 파티장: 「건배 타임」 — 모두 가운데 춤판으로 모여 춤춰요. 다른 곳은 텅 비어요.',
        '조용한 도서관: 「절전 시간」 — 한쪽 불이 10초 꺼져요. 어두운 곳은 잘 안 보여요.',
        '놀이공원 광장: 「퍼레이드」 — 가운데 길로 행렬이 지나가고 손님들이 길가에 줄지어 구경해요.',
        '공항 면세점: 「탑승 안내」 — 손님들이 우르르 탑승구로 드나들어요.',
        '바다 수족관: 「먹이 주기 쇼」 — 큰 수조 앞으로 손님들이 몰려요.',
        '맵 기본값은 무작위예요(판마다 바뀌어요).',
      ] },
      { h: '조작', p: [
        '누르기 = 걷기(경비원은 사람을 누르면 지목). 누른 채 끌면 손가락을 따라 걸어요.',
        '도둑 버튼(오른쪽부터): 훔치기(꾹) · 행동(메뉴) · 따라가기 · 변장 · 확대. 경비원: 체포/취소 · 삑! · CCTV · 검문 · 확대.',
        'PC: 방향키·WASD 걷기, 스페이스 훔치기·체포, F 따라가기, E 변장, R 행동 메뉴, 1~5 사진·앉기·줄·소란·공범, Shift 뛰기 / Q 호루라기, C CCTV, G 검문, Z 확대. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '2~8명. 혼자 하면 나머지는 AI, 친구와는 온라인·LAN 방에서 각자 폰으로(빈자리는 AI).',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬운 AI 도둑은 너무 빨리 걷고 호루라기에 잘 안 멈춰요. 어려운 AI 도둑은 손님을 따라 걷고, 소란·공범·변장을 잘 써요.',
        '쉬운 AI 경비원은 엉뚱한 사람을 잘 잡고 소란에 잘 속아요. 어려운 AI 경비원은 CCTV를 꼬박꼬박 보고 다 훔친 뒤엔 출구를 검문해요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { init, newWorld, tickWorld, stepWorld, aiFor, roundOver, nextRound, startPlay, result, snapshot, applySnap, MAPS, thiefSpot, thiefAct, eyesOn, solidAt },
  });
})();
