/* 볼링 — 10프레임 텐핀. 결정적 고정 스텝 물리(공의 미끄럼·회전·오일 패턴, 핀 10개의 기울기·비행·충돌):
   apply가 끝까지 시뮬레이션하고, 뷰는 last.pre(서 있는 핀 마스크)+last.shot을 같은 함수로 재생한다.
   단위: 인치·초. x = 레인 가로(오른쪽 +), y = 파울라인에서 핀 쪽으로. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }

  /* ---------- lane geometry ---------- */
  const LW = 20.75, KB = 30, GD = 4.6;            // lane half width, kickback x, gutter ball offset beyond lane edge
  const HEAD = 720, DECK0 = HEAD - 8, DECKE = HEAD + 34.5, PITB = 800;
  const BR = 4.25, MB = 15, PR = 2.38, PH = 15, MP = 3.5, GR = 386;
  const DT = 1 / 480, MAXT = 9;
  const KF = 0.42, HMAX = 0.36;                     // forward roll at release, max side rotation (fraction of speed)
  const OIL0 = 440, OIL1 = 560, MUD = 0.19;        // oil ends between OIL0..OIL1, dry back end friction
  const SC = 0.17, GT = 42;                        // tilt: critical sin(angle) and gravity gain
  const KT0 = 0.06, KTU = 0.12;                  // tilt kick per in/s of impulse velocity (base / along the pin)
  const DOWN = 0.45;
  const UB = 0.28, UP = 0.3;                      // contact heights (fraction of pin height): ball centre, pin belly                               // |tilt| (sin) past which a pin counts as down
  const PINS = [[0, 0], [-6, 10.392], [6, 10.392], [-12, 20.785], [0, 20.785], [12, 20.785], [-18, 31.177], [-6, 31.177], [6, 31.177], [18, 31.177]];
  const FULL = 1023;
  const r1 = (v) => Math.round(v * 10) / 10, r3 = (v) => Math.round(v * 1000) / 1000;
  function muAt(x, y) {
    if (y >= OIL1) return MUD;
    const q = x / LW, oil = 0.008 + 0.022 * q * q; // house shot: more oil in the middle, drier outside
    if (y <= OIL0) return oil;
    const t = (y - OIL0) / (OIL1 - OIL0);
    return oil + (MUD - oil) * t;
  }

  /* ---------- deterministic simulation (+ − × ÷ √ only) ---------- */
  function Sim(mask, shot) {
    this.n = 0; this.done = false;
    // ball: position, velocity, rot = surface velocity of the contact point due to spin (slip = v + rot)
    const v = Math.sqrt(shot.vx * shot.vx + shot.vy * shot.vy);
    this.b = { x: shot.x, y: 0, vx: shot.vx, vy: shot.vy, rx: shot.h * HMAX * v, ry: -KF * shot.vy, g: 0, on: 1, roll: 0 };
    this.p = [];
    for (let i = 0; i < 10; i++) {
      const up = (mask >> i) & 1;
      this.p.push({ i, x: PINS[i][0], y: HEAD + PINS[i][1], vx: 0, vy: 0, z: 0, vz: 0, tx: 0, ty: 0, wx: 0, wy: 0, on: up, out: 0, fl: 0 });
    }
    this.hits = 0; this.pinHits = 0; this.wall = 0; this.firstHit = 0; this.hitX = null; this.calm = 0;
  }
  function segClosest(ax, ay, bx, by, cx, cy, dx, dy) {
    // closest points between segments AB and CD → [s, t]
    const d1x = bx - ax, d1y = by - ay, d2x = dx - cx, d2y = dy - cy, rx = ax - cx, ry = ay - cy;
    const a = d1x * d1x + d1y * d1y, e = d2x * d2x + d2y * d2y, f = d2x * rx + d2y * ry;
    let s, t;
    if (a < 1e-9 && e < 1e-9) return [0, 0];
    if (a < 1e-9) { s = 0; t = f / e; t = t < 0 ? 0 : t > 1 ? 1 : t; return [s, t]; }
    const c = d1x * rx + d1y * ry;
    if (e < 1e-9) { t = 0; s = -c / a; s = s < 0 ? 0 : s > 1 ? 1 : s; return [s, t]; }
    const bb = d1x * d2x + d1y * d2y, den = a * e - bb * bb;
    s = den > 1e-9 ? (bb * f - c * e) / den : 0;
    s = s < 0 ? 0 : s > 1 ? 1 : s;
    t = (bb * s + f) / e;
    if (t < 0) { t = 0; s = -c / a; s = s < 0 ? 0 : s > 1 ? 1 : s; }
    else if (t > 1) { t = 1; s = (bb - c) / a; s = s < 0 ? 0 : s > 1 ? 1 : s; }
    return [s, t];
  }
  function pinImpulse(q, u, jx, jy) {
    // impulse (already divided by nothing) applied at fraction u along the pin axis
    q.vx += jx / MP; q.vy += jy / MP;
    const k = (KT0 + KTU * u) / MP;
    q.wx += jx * k; q.wy += jy * k;
    const dv = Math.sqrt(jx * jx + jy * jy) / MP;
    if (dv > 120 && q.z === 0) { q.vz += (dv - 120) * 0.16; if (q.vz > 140) q.vz = 140; }
  }
  const pinInv = (u) => (1 + PH * u * (KT0 + KTU * u)) / MP;
  Sim.prototype.step = function () {
    const b = this.b, P = this.p;
    /* ball */
    if (b.on) {
      if (!b.g) {
        const mu = muAt(b.x, b.y);
        const sx = b.vx + b.rx, sy = b.vy + b.ry, s = Math.sqrt(sx * sx + sy * sy);
        const a = mu * GR * DT;
        if (s > 3.5 * a) {
          const ux = sx / s, uy = sy / s;
          b.vx -= ux * a; b.vy -= uy * a; b.rx -= 2.5 * ux * a; b.ry -= 2.5 * uy * a;
        } else {
          b.vx -= sx * 2 / 7; b.vy -= sy * 2 / 7; b.rx = -b.vx; b.ry = -b.vy;
          const sp = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
          if (sp > 0) { const f = (sp - 0.012 * GR * DT) / sp; b.vx *= f; b.vy *= f; b.rx = -b.vx; b.ry = -b.vy; }
        }
      }
      b.x += b.vx * DT; b.y += b.vy * DT;
      b.roll += Math.sqrt(b.vx * b.vx + b.vy * b.vy) * DT;
      if (!b.g && (b.x > LW + 0.6 || b.x < -LW - 0.6) && b.y < DECKE) {
        b.g = 1; b.x = b.x > 0 ? LW + GD : -LW - GD; b.vx = 0;
      }
      if (b.x + BR > KB) { b.x = KB - BR; if (b.vx > 0) b.vx = -b.vx * 0.4; }
      if (b.x - BR < -KB) { b.x = -KB + BR; if (b.vx < 0) b.vx = -b.vx * 0.4; }
      if (b.y > DECKE + 14) { b.on = 0; }
    }
    /* pins: tilt, flight, sliding */
    for (let k = 0; k < 10; k++) {
      const q = P[k];
      if (!q.on || q.out) continue;
      // tilt (vector t = sin(angle)·dir, w = dt/dt)
      let ts = Math.sqrt(q.tx * q.tx + q.ty * q.ty);
      if (q.fl) {
        // lying: only spin (tangential w) survives, decays with friction
        if (ts > 1e-9) { const ux = q.tx / ts, uy = q.ty / ts, wr = q.wx * ux + q.wy * uy; q.wx -= wr * ux; q.wy -= wr * uy; }
        const dmp = 1 - (q.z > 0 ? 0.4 : 3.2) * DT; q.wx *= dmp; q.wy *= dmp;
      } else if (ts > 1e-6 || q.wx !== 0 || q.wy !== 0) {
        if (ts > 1e-6) {
          const ux = q.tx / ts, uy = q.ty / ts, acc = GT * (ts - SC) * (q.z > 0 ? 0.35 : 1);
          q.wx += ux * acc * DT; q.wy += uy * acc * DT;
          if (ts < SC) { const dmp = 1 - 5 * DT; q.wx *= dmp; q.wy *= dmp; }
        }
        q.tx += q.wx * DT; q.ty += q.wy * DT;
        ts = Math.sqrt(q.tx * q.tx + q.ty * q.ty);
        if (ts >= 1) {
          const ux = q.tx / ts, uy = q.ty / ts; q.tx = ux; q.ty = uy;
          const wr = q.wx * ux + q.wy * uy; if (wr > 0) { q.wx -= wr * 1.25 * ux; q.wy -= wr * 1.25 * uy; }
          q.fl = 1; this.pinHits++;
        } else if (ts < 0.012 && q.wx * q.wx + q.wy * q.wy < 0.003) { q.tx = 0; q.ty = 0; q.wx = 0; q.wy = 0; }
      }
      // flight
      if (q.z > 0 || q.vz > 0) {
        q.vz -= GR * DT; q.z += q.vz * DT;
        if (q.z <= 0) {
          q.z = 0; q.vz = q.vz < -80 ? -q.vz * 0.22 : 0;
          if (q.y > DECKE || q.x > LW || q.x < -LW) { q.out = 1; continue; }
        }
      }
      if (q.z === 0) {
        const s = Math.sqrt(q.vx * q.vx + q.vy * q.vy);
        if (s > 0) { const mu = q.fl ? 0.32 : 0.45, ns = s - mu * GR * DT; const f = ns > 0 ? ns / s : 0; q.vx *= f; q.vy *= f; }
      }
      q.x += q.vx * DT; q.y += q.vy * DT;
      if (q.x + PR > KB) { q.x = KB - PR; if (q.vx > 0) { q.vx = -q.vx * 0.55; this.wall++; } }
      if (q.x - PR < -KB) { q.x = -KB + PR; if (q.vx < 0) { q.vx = -q.vx * 0.55; this.wall++; } }
      if (q.y > PITB) { q.y = PITB; if (q.vy > 0) q.vy = -q.vy * 0.15; }
      if (q.z === 0) {
        if (q.y > DECKE + 1) q.out = 1;
        else if (q.x > LW + 1.2 || q.x < -LW - 1.2) {
          // off the deck sideways: a fast pin carries over the gutter to the kickback (and may come back), a slow one drops in
          if ((q.x > 0 ? q.vx : -q.vx) > 60 && !q.gk) { q.gk = 1; q.vz = 34; q.z = 0.01; }
          else if (!q.gk || (q.x > 0 ? q.vx : -q.vx) >= 0) q.out = 1;
        }
      }
    }
    /* ball ↔ pins */
    if (b.on && !b.g) {
      for (let k = 0; k < 10; k++) {
        const q = P[k];
        if (!q.on || q.out || q.z > 10) continue;
        const txp = q.x + PH * q.tx, typ = q.y + PH * q.ty;
        const st = segClosest(q.x, q.y, txp, typ, b.x, b.y, b.x, b.y), u = st[0] < UB ? UB : st[0];
        const cx = q.x + (txp - q.x) * u, cy = q.y + (typ - q.y) * u;
        let nx = cx - b.x, ny = cy - b.y; const d2 = nx * nx + ny * ny, rr = BR + PR;
        if (d2 >= rr * rr || d2 < 1e-12) continue;
        const d = Math.sqrt(d2); nx /= d; ny /= d;
        const pvx = q.vx + PH * u * q.wx, pvy = q.vy + PH * u * q.wy;
        const vn = (pvx - b.vx) * nx + (pvy - b.vy) * ny;
        const wp = pinInv(u), wb = 1 / MB, pen = rr - d;
        if (vn < 0) {
          const j = -(1 + 0.5) * vn / (wp + wb);
          b.vx -= j * nx * wb; b.vy -= j * ny * wb;
          pinImpulse(q, u, j * nx, j * ny);
          if (!this.firstHit) { this.firstHit = 1; this.hitX = b.x; this.hitY = b.y; this.hitVx = b.vx + j * nx * wb; this.hitVy = b.vy + j * ny * wb; }
          this.hits++;
        }
        const cw = pen / (wp + wb) * 0.8;
        b.x -= nx * cw * wb; b.y -= ny * cw * wb; q.x += nx * cw / MP; q.y += ny * cw / MP;
      }
    }
    /* pin ↔ pin */
    for (let a = 0; a < 9; a++) {
      const A = P[a];
      if (!A.on || A.out) continue;
      const aqx = A.x + PH * A.tx, aqy = A.y + PH * A.ty;
      for (let c = a + 1; c < 10; c++) {
        const B = P[c];
        if (!B.on || B.out) continue;
        const dz = A.z - B.z; if (dz > 9 || dz < -9) continue;
        const bqx = B.x + PH * B.tx, bqy = B.y + PH * B.ty;
        // quick reject on bounding distance
        const mx = (A.x + aqx) / 2 - (B.x + bqx) / 2, my = (A.y + aqy) / 2 - (B.y + bqy) / 2;
        if (mx * mx + my * my > 400) continue;
        const st = segClosest(A.x, A.y, aqx, aqy, B.x, B.y, bqx, bqy), u = st[0] < UP ? UP : st[0], t = st[1] < UP ? UP : st[1];
        const px = A.x + (aqx - A.x) * u, py = A.y + (aqy - A.y) * u, qx = B.x + (bqx - B.x) * t, qy = B.y + (bqy - B.y) * t;
        let nx = qx - px, ny = qy - py; const d2 = nx * nx + ny * ny, rr = 2 * PR;
        if (d2 >= rr * rr || d2 < 1e-12) continue;
        const d = Math.sqrt(d2); nx /= d; ny /= d;
        const avx = A.vx + PH * u * A.wx, avy = A.vy + PH * u * A.wy, bvx = B.vx + PH * t * B.wx, bvy = B.vy + PH * t * B.wy;
        const vn = (bvx - avx) * nx + (bvy - avy) * ny;
        const wa = pinInv(u), wb = pinInv(t), pen = rr - d;
        if (vn < 0) {
          const j = -(1 + 0.62) * vn / (wa + wb);
          pinImpulse(A, u, -j * nx, -j * ny); pinImpulse(B, t, j * nx, j * ny);
          this.pinHits++;
        }
        const cw = pen / (wa + wb) * 0.8;
        A.x -= nx * cw / MP; A.y -= ny * cw / MP; B.x += nx * cw / MP; B.y += ny * cw / MP;
      }
    }
    this.n++;
    // end: ball gone and pins calm
    if (!b.on) {
      let busy = 0;
      for (let k = 0; k < 10; k++) {
        const q = P[k]; if (!q.on || q.out) continue;
        if (q.z > 0 || q.vx * q.vx + q.vy * q.vy > 4 || q.wx * q.wx + q.wy * q.wy > 0.004 || (!q.fl && q.tx * q.tx + q.ty * q.ty > 0.0002)) { busy = 1; break; }
      }
      this.calm = busy ? 0 : this.calm + 1;
      if (this.calm > 60) this.done = true;
    }
    if (this.n * DT > MAXT) this.done = true;
  };
  Sim.prototype.run = function () { while (!this.done) this.step(); return this; };
  Sim.prototype.isDown = function (q) { return q.out || q.fl || q.tx * q.tx + q.ty * q.ty > DOWN * DOWN; };
  Sim.prototype.standing = function () { let m = 0; for (const q of this.p) if (q.on && !this.isDown(q)) m |= 1 << q.i; return m; };
  function simulate(mask, shot) { return new Sim(mask, shot).run(); }
  // ball-only trace (for the AI line finder): x where the ball crosses y = yy (null if guttered before)
  function ballX(shot, yy) {
    const s = new Sim(0, shot);
    while (!s.done && s.b.on) { s.step(); if (s.b.g) return null; if (s.b.y >= yy) return s.b.x; }
    return null;
  }

  /* ---------- scoring ---------- */
  const mk = (n) => (n === 0 ? '-' : String(n));
  function frames(r) {
    const out = []; let i = 0, tot = 0;
    for (let f = 0; f < 10; f++) {
      if (i >= r.length) { out.push({ m: [], t: null }); continue; }
      if (f < 9) {
        if (r[i] === 10) {
          const ok = r[i + 2] != null; if (ok) tot += 10 + r[i + 1] + r[i + 2];
          out.push({ m: ['', 'X'], ix: [-1, i], t: ok ? tot : null, x: 1 }); i += 1;
        } else {
          const a = r[i], b = r[i + 1];
          const m = [mk(a), b == null ? '' : a + b === 10 ? '/' : mk(b)];
          let t = null;
          if (b != null) { if (a + b === 10) { if (r[i + 2] != null) { tot += 10 + r[i + 2]; t = tot; } } else { tot += a + b; t = tot; } }
          out.push({ m, ix: [i, i + 1], t, sp: b != null && a + b === 10 ? 1 : 0 }); i += 2;
        }
      } else {
        const a = r[i], b = r[i + 1], c = r[i + 2], m = [a === 10 ? 'X' : mk(a)];
        if (b != null) m.push(a === 10 ? (b === 10 ? 'X' : mk(b)) : a + b === 10 ? '/' : mk(b));
        if (c != null) m.push(a === 10 ? (b === 10 ? (c === 10 ? 'X' : mk(c)) : b + c === 10 ? '/' : mk(c)) : (c === 10 ? 'X' : mk(c)));
        const need = a === 10 || (b != null && a + b === 10) ? 3 : 2;
        const done = r.length - i >= need;
        if (done) tot += a + (b || 0) + (need === 3 ? c : 0);
        out.push({ m, ix: [i, i + 1, i + 2], t: done ? tot : null });
        i += need;
      }
    }
    return out;
  }
  function score(r) { const fr = frames(r); let t = 0; for (const f of fr) if (f.t != null) t = f.t; return t; }
  // best score still reachable (for the board's "max" hint)
  /* split: head pin down and the standing pins fall into ≥2 groups (neighbours in the rack, or a sleeper right behind) */
  function isSplit(mask) {
    if (mask & 1) return false;
    const up = []; for (let i = 0; i < 10; i++) if ((mask >> i) & 1) up.push(i);
    if (up.length < 2) return false;
    const adj = (a, b) => { const dx = PINS[a][0] - PINS[b][0], dy = PINS[a][1] - PINS[b][1], d = dx * dx + dy * dy; return d < 150 || (Math.abs(dx) < 0.1 && d < 440); };
    const seen = [up[0]], st = [up[0]];
    while (st.length) { const a = st.pop(); for (const b of up) if (!seen.includes(b) && adj(a, b)) { seen.push(b); st.push(b); } }
    return seen.length < up.length;
  }

  /* ---------- state ---------- */
  function init(players) {
    const n = players.length;
    return { n, nm: players.map((p) => String(p.name || '').slice(0, 10)),
      f: 0, c: 0, b: 0, pm: FULL, fr: 1, r: players.map(() => []), sl: players.map(() => 0), seq: 0, last: null, ph: 'p' };
  }
  function actor(s) { return s.ph === 'e' ? null : s.c; }
  function makeShot(a) {
    const x = U.clamp(+a.x, -17, 17), ang = U.clamp(+a.a, -0.2, 0.2), v = U.clamp(+a.v, 150, 420), h = U.clamp(+a.h, -1, 1);
    return { x: r1(x), vx: r1(Math.sin(ang) * v), vy: r1(Math.cos(ang) * v), h: r3(h) };
  }
  function apply(s, seat, a) {
    if (actor(s) !== seat) throw new Error('not your turn');
    if (!a || a.type !== 'roll') throw new Error('bad action');
    for (const k of ['x', 'a', 'v', 'h']) if (!isFinite(+a[k])) throw new Error('bad shot');
    const shot = makeShot(a), pre = s.pm;
    const sim = simulate(pre, shot);
    const after = sim.standing() & pre;
    let k = 0; for (let i = 0; i < 10; i++) if (((pre >> i) & 1) && !((after >> i) & 1)) k++;
    const r = s.r[seat];
    r.push(k);
    const ri = r.length - 1, fr = s.f, ball = s.b;
    const firstOfRack = s.b === 0 || !!s.fr;
    let ev = '';
    if (firstOfRack && after === 0) ev = 'X';
    else if (!firstOfRack && after === 0) ev = '/';
    else if (k === 0 && sim.b.g && !sim.hits) ev = 'G';
    if (firstOfRack && after !== 0 && isSplit(after)) { s.sl[seat] |= 1 << ri; if (!ev) ev = 'S'; }
    let end = false;
    s.fr = 0;
    if (s.f < 9) {
      if (s.b === 0 && after !== 0) { s.b = 1; s.pm = after; } else end = true;
    } else if (s.b === 0) { s.b = 1; s.pm = after === 0 ? FULL : after; s.fr = after === 0 ? 1 : 0; }
    else if (s.b === 1) {
      const first = r[ri - 1];
      if (first === 10 || after === 0) { s.b = 2; s.pm = after === 0 ? FULL : after; s.fr = after === 0 ? 1 : 0; } else end = true;
    } else end = true;
    if (end) {
      s.b = 0; s.pm = FULL; s.fr = 1; s.c++;
      if (s.c >= s.n) { s.c = 0; s.f++; if (s.f >= 10) s.ph = 'e'; }
    }
    s.seq++;
    s.last = { id: s.seq, seat, pre, shot, k, after, ev, f: fr, bl: ball };
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const tot = s.r.map(score), best = Math.max(...tot);
    const winners = tot.map((t, i) => (t === best ? i : -1)).filter((i) => i >= 0);
    const ord = tot.map((t, i) => i).sort((a, b) => tot[b] - tot[a] || a - b);
    const lines = ord.map((i) => (s.nm[i] || (i + 1) + '번') + ' · ' + tot[i] + '점' + (tot[i] === 300 ? ' (퍼펙트!)' : ''));
    return { winners, title: winners.length > 1 && s.n > 1 ? '공동 우승' : undefined, text: lines.join('\n') };
  }

  /* ---------- AI ---------- */
  const LVN = [ // noise σ per seat level (lv 1 쉬움 / 2 보통 / 3 어려움): angle(rad), speed(in/s), hook, position(in)
    { a: 0.012, v: 30, h: 0.22, x: 2.2 },
    { a: 0.0036, v: 12, h: 0.07, x: 0.7 },
    { a: 0.0016, v: 6, h: 0.03, x: 0.3 },
  ];
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 0.5;
  const lineCache = {};
  // find the angle that brings the ball across y=yy at x=tx (bisection; ball-only sim)
  function solveAngle(x0, v, h, tx, yy) {
    const key = [x0, v, h, tx, yy].join(',');
    if (lineCache[key] != null) return lineCache[key];
    let lo = -0.12, hi = 0.12, best = 0;
    for (let it = 0; it < 22; it++) {
      const m = (lo + hi) / 2, bx = ballX(makeShot({ x: x0, a: m, v, h }), yy);
      if (bx == null) { // guttered: steer toward the middle
        const s0 = makeShot({ x: x0, a: m, v, h });
        const tr = new Sim(0, s0); while (!tr.b.g && tr.b.on && !tr.done) tr.step();
        if (tr.b.x > 0) hi = m; else lo = m; best = m; continue;
      }
      best = m;
      if (bx > tx) hi = m; else lo = m;
    }
    return (lineCache[key] = best);
  }
  function aiPlan(s, seat) {
    const pm = s.pm;
    if (pm === FULL) {
      // hook into the 1-3 pocket from right of centre
      const x0 = 9, v = 305, h = 0.62;
      return { x: x0, a: solveAngle(x0, v, h, 2.7, HEAD), v, h };
    }
    // spare: straight-ish ball; try targets across the leave, keep the most robust
    const up = []; for (let i = 0; i < 10; i++) if ((pm >> i) & 1) up.push(i);
    let fy = 99, cx = 0; for (const i of up) if (PINS[i][1] < fy) fy = PINS[i][1];
    let lo = 99, hi2 = -99; for (const i of up) { lo = Math.min(lo, PINS[i][0]); hi2 = Math.max(hi2, PINS[i][0]); }
    cx = (lo + hi2) / 2;
    const v = 330, h = 0.08, yy = HEAD + fy;
    const t0 = Date.now(); let best = null;
    const cands = [];
    for (let d = -9; d <= 9; d += 1.5) cands.push(cx + d);
    for (const tx of cands) {
      if (tx > LW - 3 || tx < -LW + 3) continue;
      const x0 = U.clamp(-tx * 0.7, -14, 14);
      const a = solveAngle(r1(x0), v, h, r1(tx), yy);
      let sc = 0;
      for (const j of [0, -0.0025, 0.0025]) {
        const sim = simulate(pm, makeShot({ x: x0, a: a + j, v, h }));
        sc += pop(pm & ~sim.standing()) * (j ? 1 : 1.4);
      }
      if (!best || sc > best.sc) best = { sc, x: x0, a, v, h };
      if (Date.now() - t0 > 110) break;
    }
    return best || { x: 0, a: 0, v, h };
  }
  const pop = (m) => { let c = 0; while (m) { c += m & 1; m >>= 1; } return c; };
  function ai(s, seat, lv) {
    const p = aiPlan(s, seat), N = LVN[U.clamp((lv || 2) - 1, 0, 2)];
    return { type: 'roll', x: U.clamp(p.x + gauss() * N.x, -17, 17), a: p.a + gauss() * N.a, v: U.clamp(p.v + gauss() * N.v, 150, 420), h: U.clamp(p.h + gauss() * N.h, -1, 1) };
  }

  /* ---------- view ---------- */
  const AR = 180, KMH = 0.09144; // arrows 15 ft from the foul line; in/s → km/h
  const PROF = [[0, 1.0], [0.08, 1.55], [0.22, 2.25], [0.32, 2.38], [0.45, 2.0], [0.6, 1.15], [0.68, 0.92], [0.78, 1.1], [0.88, 1.22], [0.96, 0.95], [1, 0.5]];
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, sim = null, simAcc = 0, animLast = null, shownKey = '', dirty = true;
    let finTimer = 0, animTimer = 0, sentAt = 0, holdT = 0, hitSfx = 0, camY = -80, camX = 0, camZ = 0, flash = null;
    let drag = null, set = null, setSeat = -1, fast = false;
    const V = { top: 0, bot: 0, F: 500, camH: 40, hor: 0 };
    const board = L.h('div', { class: 'hud top bw-board', style: { padding: '6px 6px 0', display: 'block' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '8px 10px', flexWrap: 'nowrap', gap: '8px' } });
    root.append(board, bot);
    // invisible boxes over the ball / aim mark / pins for the first-play tutorial spotlight
    const spBall = tutSpot(root, 'bw-ball'), spAim = tutSpot(root, 'bw-aim'), spPins = tutSpot(root, 'bw-pins');
    const color = (i) => (api.players[i] ? api.players[i].color : '#fff');
    const nameOf = (i) => (api.players[i] ? api.players[i].name : '');

    /* ---- per-player throw settings (remembered on this phone) ---- */
    function loadSet(seat) {
      let v = null;
      try { v = U.store.get('bowling.set.' + nameOf(seat), null); } catch (e) {}
      if (!v || !isFinite(v.x) || !isFinite(v.t) || !isFinite(v.h)) v = { x: 9, t: 10.5, h: 0.5 };
      return { x: U.clamp(v.x, -17, 17), t: U.clamp(v.t, -LW + 1, LW - 1), h: U.clamp(v.h, -1, 1) };
    }
    function saveSet() { if (set && setSeat >= 0) try { U.store.set('bowling.set.' + nameOf(setSeat), set); } catch (e) {} }
    function mySet() {
      const a = st ? actor(st) : null;
      if (a == null) return null;
      if (setSeat !== a || !set) { setSeat = a; set = loadSet(a); }
      return set;
    }

    /* ---- projection ---- */
    function layout() {
      const bh = board.getBoundingClientRect().height || 70;
      V.top = bh + 4; V.bot = cv.h - 76;
      const areaH = Math.max(120, V.bot - V.top);
      V.F = Math.min(cv.w * 1.5, areaH * 1.6);
      V.hor = V.top + areaH * 0.06;
      V.camH = U.clamp(areaH * 0.66 * 80 / V.F, 18, 80);
      if (!sim) camZ = V.camH;
      dirty = true;
    }
    cv.onresize = layout;
    function P(x, y, z) { // world → screen (null if behind the camera)
      const d = y - camY; if (d < 4) return null;
      return [cv.w / 2 + V.F * (x - camX) / d, V.hor + V.F * (camZ - (z || 0)) / d, V.F / d];
    }
    function quad(ax, ay, bx, by, z0, z1, fill) { // floor quad x∈[ax,bx], y∈[ay,by] at height z0 (or wall if z1)
      const y0 = Math.max(ay, camY + 6); if (by <= y0) return;
      let p;
      if (z1 == null) p = [P(ax, y0, z0), P(bx, y0, z0), P(bx, by, z0), P(ax, by, z0)];
      else p = [P(ax, y0, z0), P(bx, by, z0), P(bx, by, z1), P(ax, y0, z1)];
      ctx.fillStyle = fill; ctx.beginPath(); p.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); ctx.fill();
    }

    /* ---- lane ---- */
    function drawLane(t) {
      const w = cv.w;
      // back wall / masking
      const sky = ctx.createLinearGradient(0, V.top, 0, V.hor + 40);
      sky.addColorStop(0, '#120e18'); sky.addColorStop(1, '#241a2e');
      ctx.fillStyle = sky; ctx.fillRect(0, 0, w, cv.h);
      // capping / neighbour lanes
      quad(-90, camY + 6, -KB - 1, PITB + 20, 0, null, '#3a2a1e');
      quad(KB + 1, camY + 6, 90, PITB + 20, 0, null, '#3a2a1e');
      // approach
      quad(-LW - 9, camY + 6, LW + 9, 0, 0, null, '#c99a63');
      // gutters
      quad(-KB, camY + 6, -LW, DECKE, 0, null, '#2a2430');
      quad(LW, camY + 6, KB, DECKE, 0, null, '#2a2430');
      // lane boards
      const BW = 2 * LW / 39;
      for (let k = 0; k < 39; k++) quad(-LW + k * BW, Math.max(0, camY + 6), -LW + (k + 1) * BW, DECK0, 0, null, k % 2 ? '#d8ad73' : '#e2b980');
      // oil sheen on the front 2/3
      const p0 = P(0, Math.max(10, camY + 30), 0), p1 = P(0, OIL1, 0);
      if (p0 && p1) {
        const g = ctx.createLinearGradient(0, p0[1], 0, p1[1]);
        g.addColorStop(0, 'rgba(255,255,255,.16)'); g.addColorStop(0.75, 'rgba(255,255,255,.08)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        quad(-LW * 0.75, Math.max(0, camY + 6), LW * 0.75, OIL1, 0, null, g);
      }
      // pin deck
      quad(-LW, DECK0, LW, DECKE, 0, null, '#edd0a0');
      // pit + curtain + masking unit
      quad(-KB, DECKE, KB, PITB + 20, -6, null, '#0e0b12');
      quad(-KB, PITB + 10, KB, PITB + 10.01, 0, 40, '#1a1422');
      // foul line, dots, arrows
      quad(-LW - 9, -0.6, LW + 9, 0.6, 0, null, '#2b1d14');
      ctx.fillStyle = '#5a3a20';
      for (const b of [3, 5, 8, 11, 14]) for (const s of [-1, 1]) { const q = P(s * (LW - b * BW + BW / 2), 84, 0); if (q) { ctx.beginPath(); ctx.ellipse(q[0], q[1], Math.max(1, q[2] * 0.4), Math.max(0.6, q[2] * 0.15), 0, 0, 7); ctx.fill(); } }
      ctx.fillStyle = '#6a4220';
      for (let b = 5; b <= 35; b += 5) {
        const x = -LW + (b - 0.5) * BW, a = P(x, AR, 0), l = P(x - BW * 0.5, AR - 9, 0), r = P(x + BW * 0.5, AR - 9, 0);
        if (a && l && r) { ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(l[0], l[1]); ctx.lineTo(r[0], r[1]); ctx.closePath(); ctx.fill(); }
      }
      // kickbacks
      quad(-KB, DECK0, -KB, PITB + 10, 0, 26, '#3b2450');
      quad(KB, DECK0, KB, PITB + 10, 0, 26, '#3b2450');
      // pin spots
      ctx.fillStyle = 'rgba(120,70,30,.35)';
      for (const p of PINS) { const q = P(p[0], HEAD + p[1], 0); if (q) { ctx.beginPath(); ctx.ellipse(q[0], q[1], q[2] * 1.2, q[2] * 0.3, 0, 0, 7); ctx.fill(); } }
      void t;
    }
    function drawMasking() {
      const a = P(-KB - 6, DECKE + 12, 24), b = P(KB + 6, DECKE + 12, 46);
      if (!a || !b) return;
      const g = ctx.createLinearGradient(0, b[1], 0, a[1]);
      g.addColorStop(0, '#3a2350'); g.addColorStop(1, '#22142e');
      ctx.fillStyle = g; ctx.fillRect(a[0], b[1], b[0] - a[0], a[1] - b[1]);
      ctx.fillStyle = '#e3ae45'; ctx.fillRect(a[0], a[1] - 2, b[0] - a[0], 2);
      const fs = Math.min(18, Math.max(6, (a[1] - b[1]) * 0.42));
      ctx.font = '400 ' + fs + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.fillText('한판 라운지', (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (b[0] - a[0]) * 0.8);
    }
    /* ---- pins & ball ---- */
    function drawPin(x, y, z, tx, ty, alpha) {
      const tz = Math.sqrt(Math.max(0, 1 - tx * tx - ty * ty));
      const b = P(x, y, z), tp = P(x + PH * tx, y + PH * ty, z + PH * tz);
      if (!b || !tp) return;
      // shadow
      ctx.globalAlpha = alpha * 0.35; ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(b[0] + tx * PH * b[2] * 0.5, b[1], b[2] * 2.6, b[2] * 0.9, 0, 0, 7); ctx.fill();
      ctx.globalAlpha = alpha;
      let ax = tp[0] - b[0], ay = tp[1] - b[1]; const al = Math.hypot(ax, ay) || 1; const nx = -ay / al, ny = ax / al;
      const left = [], right = [];
      for (const pr of PROF) {
        const u = pr[0], s = b[2] + (tp[2] - b[2]) * u, cx = b[0] + ax * u, cy = b[1] + ay * u;
        left.push([cx + nx * pr[1] * s, cy + ny * pr[1] * s]); right.push([cx - nx * pr[1] * s, cy - ny * pr[1] * s]);
      }
      const g = ctx.createLinearGradient(b[0] - nx * b[2] * 2.4, b[1] - ny * b[2] * 2.4, b[0] + nx * b[2] * 2.4, b[1] + ny * b[2] * 2.4);
      g.addColorStop(0, '#b9b0a4'); g.addColorStop(0.45, '#fffaf0'); g.addColorStop(1, '#d9d0c4');
      ctx.fillStyle = g; ctx.beginPath();
      left.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1])));
      for (let i = right.length - 1; i >= 0; i--) ctx.lineTo(right[i][0], right[i][1]);
      ctx.closePath(); ctx.fill();
      // neck stripes
      ctx.strokeStyle = '#d0372c'; ctx.lineWidth = Math.max(0.8, b[2] * 0.32);
      for (const u of [0.66, 0.72]) {
        const s = (b[2] + (tp[2] - b[2]) * u) * 1.0, cx = b[0] + ax * u, cy = b[1] + ay * u;
        ctx.beginPath(); ctx.moveTo(cx + nx * s, cy + ny * s); ctx.lineTo(cx - nx * s, cy - ny * s); ctx.stroke();
      }
      // head cap (visible when lying toward the camera)
      ctx.fillStyle = '#fffaf0'; ctx.beginPath(); ctx.arc(tp[0], tp[1], tp[2] * 0.75, 0, 7); ctx.fill();
      ctx.globalAlpha = 1;
    }
    function drawBall(x, y, z, roll, col, sunk) {
      const c = P(x, y, z + BR - (sunk ? 3 : 0)); if (!c) return;
      const r = BR * c[2];
      const s = P(x, y, sunk ? -3 : 0);
      if (s) { ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(s[0], s[1], r * 1.05, r * 0.35, 0, 0, 7); ctx.fill(); }
      const g = ctx.createRadialGradient(c[0] - r * 0.35, c[1] - r * 0.4, r * 0.1, c[0], c[1], r);
      g.addColorStop(0, shade(col, 0.45)); g.addColorStop(0.55, col); g.addColorStop(1, shade(col, -0.55));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(c[0], c[1], r, 0, 7); ctx.fill();
      // finger holes roll toward the pins
      const ph = (roll / BR) % (Math.PI * 2);
      const hy = Math.cos(ph), vis = Math.sin(ph);
      if (vis > -0.2) {
        ctx.fillStyle = 'rgba(15,10,20,.8)';
        const yy = c[1] - hy * r * 0.55;
        for (const [dx, dy, rr] of [[-0.22, 0, 0.13], [0.22, 0, 0.13], [0, 0.32, 0.16]]) {
          ctx.beginPath(); ctx.ellipse(c[0] + dx * r, yy + dy * r * hy, rr * r, rr * r * Math.max(0.2, Math.abs(vis)), 0, 0, 7); ctx.fill();
        }
      }
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(c[0], c[1], r, 0, 7); ctx.stroke();
    }
    function shade(hex, k) {
      const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
      if (k > 0) { r += (255 - r) * k; g += (255 - g) * k; b += (255 - b) * k; } else { r *= 1 + k; g *= 1 + k; b *= 1 + k; }
      return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
    }
    function drawScene(now) {
      cv.clear();
      if (!st) return;
      drawLane(now / 1000);
      const objs = [];
      if (sim) {
        for (const q of sim.p) {
          if (!q.on) continue;
          if (q.out && (q.y > PITB - 3 || q.y > DECKE + 2)) { objs.push({ y: q.y, f: () => drawPin(q.x, q.y, q.z - 8, q.tx, q.ty, 0.55) }); continue; }
          if (q.out) { objs.push({ y: q.y, f: () => drawPin(q.x, q.y, q.z - 3, q.tx, q.ty, 0.8) }); continue; }
          objs.push({ y: q.y, f: () => drawPin(q.x, q.y, q.z, q.tx, q.ty, 1) });
        }
        const b = sim.b;
        if (b.on || b.y < PITB) objs.push({ y: b.y, f: () => drawBall(b.x, b.y, b.on ? 0 : -8, b.roll, color(animLast.seat), b.g) });
      } else {
        const m = st.ph === 'e' ? 0 : st.pm;
        for (let i = 0; i < 10; i++) if ((m >> i) & 1) objs.push({ y: HEAD + PINS[i][1], f: ((i) => () => drawPin(PINS[i][0], HEAD + PINS[i][1], 0, 0, 0, 1))(i) });
        const a = actor(st);
        if (a != null) {
          const s = api.canAct(a) ? mySet() : null, bx = s ? s.x : 0;
          objs.push({ y: 6, f: () => drawBall(bx, 6, 0, 0, color(a), 0) });
        }
      }
      objs.sort((p, q) => q.y - p.y);
      // pins in the pit go behind the masking unit; everything on the deck in front
      for (const o of objs) o.f();
      drawMasking();
      drawRack();
      if (!sim && st && actor(st) != null && api.canAct(actor(st)) && !waitingNet()) drawGuide(now);
      placeSpots();
      if (flash) {
        const k = U.clamp((now - flash.t0) / 1100, 0, 1);
        if (k >= 1) flash = null; else {
          ctx.globalAlpha = k < 0.15 ? k / 0.15 : 1 - Math.max(0, (k - 0.6) / 0.4);
          const y = V.top + (V.bot - V.top) * 0.42, s = 1 + (1 - k) * 0.15;
          ctx.font = '400 ' + Math.round(42 * s) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, cv.w / 2, y);
          ctx.fillStyle = flash.c; ctx.fillText(flash.text, cv.w / 2, y);
          ctx.globalAlpha = 1;
        }
      }
    }

    function placeSpots() {
      const pl = P(-24, HEAD - 4, 0), pr = P(24, HEAD + 34, 0), pt = P(0, HEAD, 16);
      if (pl && pr && pt) spPins(pl[0] - 8, pt[1] - 8, pr[0] - pl[0] + 16, pl[1] - pt[1] + 14); else spPins(null);
      const s = canHuman() ? mySet() : null, b = s && P(s.x, 6, BR), tg = s && P(s.t, AR, 0);
      if (b) { const r = BR * b[2]; spBall(b[0] - r - 14, b[1] - r - 10, 2 * r + 28, 2 * r + 34); } else spBall(null);
      if (tg) spAim(tg[0] - 26, tg[1] - 22, 52, 40); else spAim(null);
    }
    // small rack diagram: which pins are still standing
    function drawRack() {
      let m = 0, pre = FULL;
      if (sim) { pre = animLast.pre; m = sim.standing() & pre; } else if (st.ph !== 'e') { m = st.pm; pre = st.pm; } else return;
      const x0 = cv.w - 44, y0 = V.top + 12, g = 9;
      ctx.fillStyle = 'rgba(23,19,31,.72)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x0 - 34, y0 - 8, 68, 50, 10) : ctx.rect(x0 - 34, y0 - 8, 68, 50); ctx.fill();
      for (let i = 0; i < 10; i++) {
        const x = x0 + PINS[i][0] / 6 * g * 0.62, y = y0 + 32 - PINS[i][1] / 10.392 * g;
        const up = (m >> i) & 1, was = (pre >> i) & 1;
        ctx.beginPath(); ctx.arc(x, y, 4, 0, 7);
        if (up) { ctx.fillStyle = '#f2e9d8'; ctx.fill(); }
        else { ctx.strokeStyle = was ? 'rgba(238,106,85,.8)' : 'rgba(171,159,184,.35)'; ctx.lineWidth = 1.3; ctx.stroke(); }
      }
    }
    /* ---- aim guide & swipe ---- */
    const ballScreen = () => { const s = mySet(); return s ? P(s.x, 6, BR) : null; };
    function swipeShot() {
      const s = mySet(); if (!s || !drag || drag.mode !== 'throw') return null;
      const pts = drag.pts, p0 = pts[0], pe = pts[pts.length - 1];
      const dx = pe.x - p0.x, dy = pe.y - p0.y, len = Math.hypot(dx, dy);
      if (dy > -70 || len < 70) return { cancel: true };
      // speed over the last 120 ms
      let k = pts.length - 1; while (k > 0 && pe.t - pts[k - 1].t < 120) k--;
      const q = pts[k], dt = Math.max(16, pe.t - q.t), spd = Math.hypot(pe.x - q.x, pe.y - q.y) / dt * 1000;
      const v = U.clamp(150 + (spd - 300) / 2100 * 270, 150, 420);
      // line: aim arrow + a little from the swipe's direction
      const dev = Math.atan2(dx, -dy) * 0.06;
      const base = Math.atan2(s.t - s.x, AR);
      // hook: the bow of the swipe (bulging right → curls left like a right-hander's hook)
      let bulge = 0;
      for (const p of pts) { const c = ((p.x - p0.x) * dy - (p.y - p0.y) * dx) / len; if (Math.abs(c) > Math.abs(bulge)) bulge = c; }
      const hk = U.clamp(s.h + U.clamp(-bulge / len * 3, -0.6, 0.6), -1, 1);
      return { x: s.x, a: U.clamp(base + dev, -0.2, 0.2), v, h: hk, kmh: v * KMH, dev, bulge: -bulge / len * 3 };
    }
    function drawGuide(now) {
      const s = mySet(); if (!s) return;
      const b = P(s.x, 6, 0), tg = P(s.t, AR, 0);
      if (!b || !tg) return;
      // position rail on the approach
      const l = P(-17, 6, 0), r = P(17, 6, 0);
      if (l && r) {
        ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 2; ctx.setLineDash([4, 6]);
        ctx.beginPath(); ctx.moveTo(l[0], l[1]); ctx.lineTo(r[0], r[1]); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(242,233,216,.8)'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
        ctx.fillText('◀ 위치 ▶', b[0], b[1] + BR * b[2] + 6);
      }
      const sw = drag && drag.mode === 'throw' ? swipeShot() : null;
      const ang = sw && !sw.cancel ? sw.a : Math.atan2(s.t - s.x, AR), hk = sw && !sw.cancel ? sw.h : s.h;
      // straight guide to the arrows, then a short bend showing the hook direction
      const ex = s.x + Math.tan(ang) * AR * 1.35, end = P(ex, AR * 1.35, 0);
      ctx.strokeStyle = 'rgba(255,248,230,.92)'; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.setLineDash([2, 8]);
      ctx.beginPath(); ctx.moveTo(b[0], b[1]); ctx.lineTo(end[0], end[1]); ctx.stroke(); ctx.setLineDash([]);
      // arrow head with hook curl
      const bend = -hk * 9, c1 = P(ex + Math.tan(ang) * 40, AR * 1.35 + 40, 0), c2 = P(ex + Math.tan(ang) * 70 + bend, AR * 1.35 + 70, 0);
      if (c1 && c2) {
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3.5;
        ctx.beginPath(); ctx.moveTo(end[0], end[1]); ctx.quadraticCurveTo(c1[0], c1[1], c2[0], c2[1]); ctx.stroke();
        const hx = c2[0] - c1[0], hy = c2[1] - c1[1], hl = Math.hypot(hx, hy) || 1, ux = hx / hl, uy = hy / hl;
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.moveTo(c2[0] + ux * 7, c2[1] + uy * 7); ctx.lineTo(c2[0] - uy * 6, c2[1] + ux * 6); ctx.lineTo(c2[0] + uy * 6, c2[1] - ux * 6); ctx.closePath(); ctx.fill();
      }
      // aim marker on the arrows
      ctx.fillStyle = drag && drag.mode === 'aim' ? '#e3ae45' : 'rgba(227,174,69,.85)';
      ctx.beginPath(); ctx.moveTo(tg[0], tg[1] - 10); ctx.lineTo(tg[0] - 8, tg[1] + 4); ctx.lineTo(tg[0] + 8, tg[1] + 4); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(23,19,31,.8)'; ctx.lineWidth = 1.5; ctx.stroke();
      // swipe trail + readout
      if (drag && drag.mode === 'throw' && drag.pts.length > 1) {
        ctx.strokeStyle = sw && sw.cancel ? 'rgba(238,106,85,.85)' : 'rgba(242,233,216,.7)'; ctx.lineWidth = 5; ctx.lineJoin = 'round';
        ctx.beginPath(); drag.pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.stroke();
      }
      if (drag && drag.mode === 'throw') {
        const bx = cv.w / 2, by = V.top + 30;
        ctx.fillStyle = 'rgba(23,19,31,.85)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx - 82, by - 18, 164, 36, 12) : ctx.rect(bx - 82, by - 18, 164, 36); ctx.fill();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        if (!sw || sw.cancel) { ctx.fillStyle = '#ee6a55'; ctx.font = '700 14px "IBM Plex Sans KR", sans-serif'; ctx.fillText('위로 쓸어 올리기 · 놓으면 취소', bx, by + 1); }
        else { ctx.fillStyle = '#f2e9d8'; ctx.font = '700 15px "IBM Plex Mono", monospace'; ctx.fillText(Math.round(sw.kmh) + ' km/h · 훅 ' + hookLabel(sw.h), bx, by + 1); }
      }
      void now;
    }
    const hookLabel = (h) => (Math.abs(h) < 0.08 ? '0' : (h > 0 ? '←' : '→') + Math.round(Math.abs(h) * 100));

    /* ---- input ---- */
    function waitingNet() { return sentAt && performance.now() - sentAt < 6000; }
    function canHuman() { return st && !sim && st.ph !== 'e' && actor(st) != null && api.canAct(actor(st)) && !waitingNet(); }
    function aimFromScreen(px) {
      // the arrows row: invert the projection at y = AR
      const s = mySet(), q = P(0, AR, 0); if (!q) return;
      s.t = U.clamp(camX + (px - cv.w / 2) / q[2], -LW + 1, LW - 1);
    }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (sim && !fast) { fast = true; renderBot(true); return; } // tap while the ball rolls: fast-forward
      if (!canHuman() || drag) return;
      const p = cv.local(ev), b = ballScreen(); if (!b) return;
      const s = mySet();
      const nearBall = p.y > b[1] - 60;
      drag = { id: ev.pointerId, x0: p.x, y0: p.y, mode: nearBall ? 'ball' : 'aim', sx: s.x, pts: [{ x: p.x, y: p.y, t: performance.now() }] };
      if (drag.mode === 'aim') { aimFromScreen(p.x); api.sfx('tick'); }
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      api.buzz(8); dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const p = cv.local(ev), s = mySet();
      if (drag.mode === 'ball') {
        const dx = p.x - drag.x0, dy = p.y - drag.y0;
        if (Math.hypot(dx, dy) > 12) { drag.mode = Math.abs(dx) > Math.abs(dy) * 1.1 ? 'pos' : 'throw'; if (drag.mode === 'throw') drag.pts = [drag.pts[0]]; }
      }
      if (drag.mode === 'pos') {
        const q = P(0, 6, 0), nx = U.clamp(Math.round((drag.sx + (p.x - drag.x0) / q[2]) * 2) / 2, -17, 17);
        if (nx !== s.x) { s.x = nx; api.sfx('tick'); }
      } else if (drag.mode === 'aim') aimFromScreen(p.x);
      else if (drag.mode === 'throw') { drag.pts.push({ x: p.x, y: p.y, t: performance.now() }); if (drag.pts.length > 80) drag.pts.splice(1, 1); }
      dirty = true;
    });
    function endDrag(ev, cancel) {
      if (!drag || drag.id !== ev.pointerId) return;
      const d = drag; let sw = null;
      if (d.mode === 'throw' && !cancel) { const p = cv.local(ev); d.pts.push({ x: p.x, y: p.y, t: performance.now() }); sw = swipeShot(); }
      drag = null; dirty = true;
      if (d.mode === 'pos' || d.mode === 'aim') { saveSet(); renderBot(true); return; }
      if (!sw || !canHuman()) return;
      if (sw.cancel) { if (d.pts.length > 3) { api.sfx('click'); api.toast('취소 — 공을 위로 쓸어 올려요'); } return; }
      saveSet();
      api.sfx('whoosh'); api.buzz(18);
      if (!api.isHost) sentAt = performance.now();
      api.act({ type: 'roll', x: sw.x, a: sw.a, v: sw.v, h: sw.h });
    }
    cv.cv.addEventListener('pointerup', (ev) => endDrag(ev, false));
    cv.cv.addEventListener('pointercancel', (ev) => endDrag(ev, true));

    /* ---- scoreboard ---- */
    let boardKey = '';
    function renderBoard() {
      if (!st) return;
      const cur = sim ? animLast.seat : actor(st), cf = sim ? animLast.f : st.f;
      const rows = st.r.map((r, i) => (sim && i === animLast.seat ? r.slice(0, r.length - 1) : r));
      const key = JSON.stringify([rows, cur, cf, st.ph]);
      if (key === boardKey) return;
      boardKey = key;
      board.innerHTML = '';
      const grid = L.h('div', { class: 'panel', style: { padding: '4px', display: 'grid', gridTemplateColumns: 'minmax(40px,1fr) repeat(9, minmax(0,25px)) minmax(0,35px) minmax(0,32px)', gap: '1px', fontFamily: 'var(--f-mono)', fontSize: '11px', lineHeight: 1 } });
      grid.append(L.h('div', { style: { color: 'var(--muted)', fontSize: '10px', padding: '2px' }, text: '' }));
      for (let f = 0; f < 10; f++) grid.append(L.h('div', { style: { textAlign: 'center', fontSize: '10px', padding: '2px 0', color: f === cf && st.ph !== 'e' ? 'var(--brass)' : 'var(--muted)', fontWeight: f === cf ? 700 : 400 }, text: String(f + 1) }));
      grid.append(L.h('div', { style: { textAlign: 'center', fontSize: '10px', padding: '2px 0', color: 'var(--muted)' }, text: '합' }));
      for (let i = 0; i < st.n; i++) {
        const fr = frames(rows[i]), on = cur === i && st.ph !== 'e';
        const bg = on ? 'color-mix(in srgb,' + color(i) + ' 22%, var(--surface-2))' : 'var(--surface-2)';
        grid.append(L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '3px', padding: '0 2px', minWidth: 0, background: bg, borderRadius: '4px 0 0 4px', fontFamily: 'var(--f-body)', fontWeight: 700, fontSize: '11px' } },
          L.h('span', { class: 'dot', style: { '--c': color(i), flex: 'none', width: '8px', height: '8px' } }),
          L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, text: nameOf(i) })));
        for (let f = 0; f < 10; f++) {
          const F = fr[f], ten = f === 9;
          const marks = F.m.length ? (ten ? F.m.concat(['', '', '']).slice(0, 3) : F.m) : (ten ? ['', '', ''] : ['', '']);
          const top = L.h('div', { style: { display: 'flex', justifyContent: 'flex-end', height: '12px' } }, marks.map((m, j) => {
            const split = m && F.ix && F.ix[j] >= 0 && (st.sl[i] >> F.ix[j]) & 1;
            return L.h('span', { style: { width: '11px', textAlign: 'center', borderLeft: '1px solid rgba(255,255,255,.12)', borderBottom: '1px solid rgba(255,255,255,.12)', color: m === 'X' ? '#ee6a55' : m === '/' ? '#5fd3a0' : 'var(--ink)', fontWeight: m === 'X' || m === '/' ? 700 : 500, fontSize: '10px', lineHeight: '12px' } },
              split ? L.h('span', { style: { display: 'inline-block', width: '10px', height: '10px', lineHeight: '9px', borderRadius: '50%', border: '1px solid #e3ae45' }, text: m }) : m);
          }));
          const hl = on && f === cf;
          grid.append(L.h('div', { style: { background: bg, outline: hl ? '1.5px solid var(--brass)' : 'none', outlineOffset: '-1.5px', display: 'flex', flexDirection: 'column', minWidth: 0 } },
            top, L.h('div', { style: { textAlign: 'center', fontSize: '11px', padding: '2px 0 3px', fontWeight: 600 }, text: F.t == null ? '' : String(F.t) })));
        }
        grid.append(L.h('div', { style: { background: bg, borderRadius: '0 4px 4px 0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '12px', color: 'var(--brass)' }, text: String(score(rows[i])) }));
      }
      // split marker legend is shown via a circle in the first mark box
      board.append(grid);
      layout();
    }
    let botKey = '';
    function renderBot(force) {
      if (!st) { bot.innerHTML = ''; return; }
      const a = sim ? animLast.seat : actor(st), mine = !sim && a != null && api.canAct(a) && st.ph !== 'e';
      const ballNo = sim ? animLast.bl : st.b, fno = sim ? animLast.f : st.f;
      const key = [a, mine, ballNo, fno, st.ph, !!sim, fast, waitingNet() ? 1 : 0].join('|');
      if (key === botKey && !force) { if (mine) syncSlider(); return; }
      botKey = key;
      bot.innerHTML = '';
      if (st.ph === 'e' || a == null) return;
      const info = L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0, flex: '1 1 auto', padding: '6px 10px' } },
        L.h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1, flex: 'none' } },
          L.h('span', { style: { fontFamily: 'var(--f-display)', fontSize: '19px', color: 'var(--brass)' }, text: (fno + 1) + 'F' }),
          L.h('span', { class: 'mono', style: { fontSize: '11px', marginTop: '3px' }, text: (ballNo + 1) + '구' })),
        L.h('div', { style: { display: 'flex', flexDirection: 'column', minWidth: 0, gap: '2px' } },
          L.h('span', { style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 700, fontSize: '13px' } },
            L.h('span', { class: 'dot', style: { '--c': color(a), display: 'inline-block', marginRight: '5px' } }), nameOf(a)),
          L.h('span', { class: 'muted', style: { fontSize: '11px', lineHeight: 1.25, whiteSpace: 'pre-line' },
            text: sim ? (fast ? '빨리 감는 중…' : '굴러가는 중… · 누르면 빨리 감기') : mine ? (waitingNet() ? '보내는 중…' : '공을 위로 쓸어 던지기\n좌우로 끌면 서는 위치') : api.players[a].ai ? '생각 중…' : '차례' })));
      bot.append(info);
      if (mine) {
        const s = mySet();
        const lab = L.h('span', { class: 'mono', style: { fontSize: '12px', fontWeight: 700, minWidth: '34px', textAlign: 'center' }, text: hookLabel(s.h) });
        const rng = L.h('input', { type: 'range', min: '-100', max: '100', step: '5', value: String(Math.round(-s.h * 100)), 'aria-label': '훅(회전)',
          style: { width: '100%', minWidth: 0, height: '28px', accentColor: '#e3ae45', margin: 0 } });
        rng.addEventListener('input', () => { const v = -(+rng.value) / 100; s.h = Math.abs(v) < 0.05 ? 0 : v; lab.textContent = hookLabel(s.h); dirty = true; });
        rng.addEventListener('change', () => { saveSet(); api.buzz(8); api.sfx('tick'); });
        slider = { rng, lab };
        bot.append(L.h('div', { class: 'panel bw-hook', style: { flex: '0 0 116px', display: 'flex', flexDirection: 'column', alignItems: 'stretch', gap: '1px', padding: '4px 8px', minHeight: '44px' } },
          L.h('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', color: 'var(--muted)', fontWeight: 700 } }, L.h('span', { text: '훅' }), lab), rng));
      } else slider = null;
    }
    let slider = null;
    function syncSlider() { if (slider && set) { slider.lab.textContent = hookLabel(set.h); } }

    /* ---- animation ---- */
    function startAnim(last) {
      clearTimeout(finTimer); clearTimeout(animTimer);
      sim = new Sim(last.pre, last.shot); simAcc = 0; animLast = last; holdT = 0; hitSfx = 0; fast = false;
      api.setBusy(true);
      const mine = sim, dur = new Sim(last.pre, last.shot).run().n * DT;
      animTimer = setTimeout(() => { if (sim === mine && !sim.done) { sim.run(); finishAnim(); } }, (dur / L.debug.speed) * 1000 + 3000);
      renderBoard(); renderBot();
    }
    function finishAnim() {
      clearTimeout(animTimer);
      const l = animLast, s = sim;
      announce(l);
      clearTimeout(finTimer);
      finTimer = setTimeout(() => {
        if (sim !== s) return;
        sim = null; animLast = null; camY = -80; camX = 0; camZ = V.camH;
        api.setBusy(false);
        renderBoard(); renderBot(); dirty = true;
      }, (fast ? 550 : 1100) / L.debug.speed);
    }
    function announce(l) {
      const nm = nameOf(l.seat);
      let t = '', c = '#f2e9d8';
      if (l.ev === 'X') { t = '스트라이크!'; c = '#ee6a55'; api.sfx('win'); api.buzz(40); }
      else if (l.ev === '/') { t = '스페어!'; c = '#5fd3a0'; api.sfx('pop'); api.buzz(25); }
      else if (l.ev === 'G') { t = '거터'; c = '#ab9fb8'; api.sfx('thud'); }
      else if (l.ev === 'S') { t = '스플릿'; c = '#e3ae45'; api.sfx('thud'); }
      else { t = l.k ? l.k + '핀' : '노 핀'; api.sfx(l.k ? 'hit' : 'thud'); }
      flash = { text: t, c, t0: performance.now() };
      void nm;
      if (st && st.ph === 'e' && l.id === st.last.id) { const sc = score(st.r[l.seat]); if (sc === 300) api.toast('퍼펙트 게임! 300점'); }
    }
    const stop = U.loop((dt, now) => {
      if (sim) {
        if (!sim.done) {
          simAcc += dt * L.debug.speed * (fast ? 3 : 1);
          let n = 0; const h0 = sim.hits, p0 = sim.pinHits;
          while (simAcc >= DT && !sim.done && n < 4000) { sim.step(); simAcc -= DT; n++; }
          if (sim.hits > h0 && !hitSfx) { hitSfx = 1; api.sfx('hit'); api.buzz(20); }
          else if (sim.pinHits > p0 && Math.random() < 0.5) api.sfx('chip');
          if (sim.done) finishAnim();
        }
        // camera: behind the ball, then a close look at the deck
        const b = sim.b;
        const ty = Math.min(b.y - 80, HEAD - 66), tx = b.on && b.y < HEAD ? b.x * 0.3 : camX;
        const k = Math.min(1, dt * (fast ? 16 : 6)), near = U.clamp((camY - 300) / (HEAD - 66 - 300), 0, 1);
        camY += (Math.max(-80, ty) - camY) * k; camX += (tx - camX) * k;
        camZ = V.camH + (V.camH * 0.95 - V.camH) * near;
        dirty = true;
      }
      if (flash || drag || (st && !sim && st.ph !== 'e')) dirty = true;
      if (dirty) { dirty = false; drawScene(now); }
    });

    layout();
    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        const key = next.last ? next.last.id + ':' + next.last.shot.vx + ':' + next.last.shot.vy : '';
        if (next.last && key !== shownKey && prev && prev !== next) { shownKey = key; startAnim(next.last); }
        else shownKey = key;
        if (!sim) { const a = actor(next); if (a !== setSeat) { set = null; setSeat = -1; } }
        renderBoard(); renderBot(); dirty = true;
      },
      destroy() { stop(); clearTimeout(finTimer); clearTimeout(animTimer); cv.destroy(); board.remove(); bot.remove(); [spBall, spAim, spPins].forEach((f) => f.el.remove()); api.setBusy(false); },
    };
  }

  L.register({
    id: 'bowling', name: '볼링', tag: '텐핀 볼링', cat: '스포츠',
    blurb: '10프레임 텐핀 볼링. 위치를 잡고 조준한 뒤 레인 위로 쓸어 올려 던져요. 스트라이크·스페어 보너스, 10프레임은 최대 3구. 총점이 가장 높으면 승리.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 900,
    tint: '#5a1f3c',
    icon: '<circle cx="21" cy="36" r="13" fill="currentColor"/><circle cx="16" cy="31" r="2.2" fill="#5a1f3c"/><circle cx="23" cy="29" r="2.2" fill="#5a1f3c"/><circle cx="19" cy="38" r="2.6" fill="#5a1f3c"/><path d="M41 8c-3 0-4 3-3 6l1 3c-3 4-4 9-3 16 1 6 2 11 5 15h4c3-4 4-9 5-15 1-7 0-12-3-16l1-3c1-3 0-6-3-6z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M38 17h10" stroke="currentColor" stroke-width="2.5"/>',
    quick: [
      '10프레임 동안 핀을 쓰러뜨려 총점이 가장 높은 사람이 이겨요.',
      '내 차례: 공을 좌우로 끌어 설 위치, 레인을 눌러 조준, 공을 위로 쓸어 올려 던져요. 한 프레임에 최대 2구.',
      '스트라이크(1구에 10핀)는 다음 2구, 스페어(2구로 10핀)는 다음 1구 점수를 보너스로 더 받아요.',
    ],
    rules: [
      { h: '목표', p: ['1–4명이 하는 텐핀 볼링, 10프레임이에요.', '10프레임 총점이 가장 높은 사람이 이기고, 같으면 공동 우승이에요.'] },
      { h: '차례에 할 일', p: ['① 한 프레임에 공을 최대 2번(2구) 던져요. 1구에 10핀을 다 쓰러뜨리면(스트라이크) 그 프레임은 바로 끝나요.',
        '② 모두가 1프레임씩 차례로 치고 다음 프레임으로 넘어가요.',
        '③ 10프레임에서 스트라이크나 스페어를 하면 1구를 더 던져 최대 3구까지 쳐요.',
        '오른쪽 위 작은 핀 그림이 지금 서 있는 핀이에요.'] },
      { h: '조작 (손가락)', p: ['① 서는 위치: 공을 누른 채 좌우로 끌어요(「◀ 위치 ▶」).',
        '② 조준: 레인 위(공보다 위쪽)를 누르거나 좌우로 끌면, 화살표 줄 위의 조준점이 옮겨져요. 점선이 공이 처음 굴러갈 방향이에요.',
        '③ 던지기: 공을 누르고 레인 위쪽으로 쭉 쓸어 올렸다 떼요. 빨리 쓸수록 공이 빨라요(km/h 표시). 쓸어 올린 방향으로 조금 더 기울어져요.',
        '④ 훅(휘기): 아래 「훅」 막대로 정해요. 왼쪽으로 밀면 ←(왼쪽으로 휨), 오른쪽으로 밀면 →(오른쪽으로 휨), 가운데 0은 똑바로. 쓸어 올리는 손가락을 둥글게 휘면 더 휘어요(오른쪽으로 불룩 → 왼쪽으로 휨). 노란 화살 끝이 휘는 방향이에요.',
        '아래로 내리거나 너무 짧게 쓸면 취소돼요. 위치·조준·훅은 사람마다 이 폰에 기억돼요.',
        '공이 굴러가는 동안 화면을 누르면 빨리 감기(AI 차례도).'] },
      { h: '점수 계산', p: ['보통 프레임: 쓰러뜨린 핀 수가 그대로 점수예요(예: 7핀 + 2핀 = 9점).',
        '스트라이크(X): 1구에 10핀. 10점 + 다음 2구에서 쓰러뜨린 핀 수.',
        '스페어(/): 2구에 걸쳐 10핀. 10점 + 다음 1구에서 쓰러뜨린 핀 수.',
        '그래서 스트라이크·스페어 프레임의 점수는 다음 공을 던진 뒤에 적혀요.',
        '최고점은 300점(12번 연속 스트라이크, 퍼펙트 게임)이에요.',
        '점수표 기호: X = 스트라이크, / = 스페어, - = 0핀, 동그라미 친 숫자 = 스플릿(헤드핀이 쓰러지고 떨어진 핀들이 남은 어려운 상태). 파울 규칙은 없어요.'] },
      { h: '예시 (점수 계산)', p: ['1프레임 스트라이크(X) → 2프레임 7핀, 2핀.',
        '→ 1프레임 = 10 + 7 + 2 = 19점. 2프레임 = 19 + 9 = 28점.',
        '1프레임 스페어(8핀, 2핀) → 2프레임 1구 5핀, 2구 3핀.',
        '→ 1프레임 = 10 + 5 = 15점. 2프레임 = 15 + 8 = 23점.',
        '연속 스트라이크 3번(터키) → 첫 프레임 = 10 + 10 + 10 = 30점.'] },
      { h: '물리', p: ['공은 처음에 미끄러지다가 구르며, 훅을 주면 휘어 들어가요.',
        '레인 앞쪽 약 2/3에는 오일이 발라져 있어 잘 안 휘고, 오일이 없는 뒤쪽에서 크게 휘어요.',
        '핀은 서로 부딪히고 날아가 옆벽에 튕기기도 해요. 많이 기울거나 핀 자리 밖으로 나가면 쓰러진 핀이에요.',
        '1번 핀과 3번 핀 사이(포켓)에 비스듬히 들어가야 스트라이크가 잘 나요. 정면으로 맞히면 스플릿이 나기 쉬워요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(라인·속도·훅의 정확도가 달라요). AI는 훅으로 포켓을 노리고, 남은 핀을 보고 스페어를 처리해요.'] },
    ],
    tutorial: [
      { sel: '.bw-pins', text: '10프레임 동안 이 핀 10개를 쓰러뜨려요. 한 프레임에 최대 2구, 총점이 가장 높으면 이겨요.' },
      { sel: '.bw-ball', text: '서는 위치: 공을 누른 채 좌우로 끌면 출발 위치가 바뀌어요.' },
      { sel: '.bw-aim', text: '조준: 레인 위를 누르거나 좌우로 끌면 화살표 줄 위의 조준점이 옮겨져요. 점선이 공이 처음 굴러갈 방향이에요.' },
      { sel: '.bw-hook', text: '훅: 이 막대로 공이 휘는 방향과 정도를 정해요(← 왼쪽으로 휨). 1번과 3번 핀 사이로 비스듬히 들어가면 스트라이크가 잘 나요.' },
      { sel: '.bw-ball', text: '던지기: 공을 누르고 위로 쭉 쓸어 올렸다 떼요. 빨리 쓸수록 공이 빨라요. 아래로 내리거나 너무 짧게 쓸면 취소!' },
      { sel: '.bw-board', text: '점수표예요. 스트라이크(X)는 10 + 다음 2구, 스페어(/)는 10 + 다음 1구를 더해요. 예: X 다음에 7, 2 → 첫 프레임 19점.' },
    ],
    init, actor, apply, ai, result, mount,
    _sim: { Sim, simulate, ballX, frames, score, isSplit, makeShot, aiPlan, solveAngle, PINS, HEAD, FULL },
  });
})();
