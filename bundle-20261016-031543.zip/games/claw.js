/* 인형 뽑기 — 오락실 크레인. 차례마다 집게를 옮겨 내리면, apply가 고정 스텝 물리(집기 → 들어 올리기 → 힘 빠짐 → 옮기기 → 놓기)를
   끝까지 계산하고 last={pre, shot}을 남긴다. 뷰는 같은 Sim을 재생한다(sim 안에서는 + − × ÷ √ 만 사용, Math.random 금지).
   사람마다 같은 인형 더미로 시작하는 자기 기계를 갖는다(공정). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- machine geometry (units ≈ cm) ---------- */
  const W = 100, D = 70, YTOP = 44, HX = 22, HZ = 20, HOMEX = 11, HOMEZ = 10, LEDGE = 24, GUARD = 8;
  const DT = 1 / 60, G = 520, LC = 26, SWD = 1.6, HUBR = 3, MAXN = 60 * 30;
  const r1 = (v) => Math.round(v * 10) / 10;
  // 16 yaw directions built from √ only (bit-identical everywhere)
  const C8 = Math.sqrt(2 + Math.sqrt(2)) / 2, S8 = Math.sqrt(2 - Math.sqrt(2)) / 2, H2 = Math.sqrt(0.5);
  const YAW = [[1, 0], [C8, S8], [H2, H2], [S8, C8], [0, 1], [-S8, C8], [-H2, H2], [-C8, S8], [-1, 0], [-C8, -S8], [-H2, -H2], [-S8, -C8], [0, -1], [S8, -C8], [H2, -H2], [C8, -S8]];
  const S3 = Math.sqrt(3) / 2;
  const PR2 = [[1, 0], [-1, 0]], PR3 = [[0, 1], [S3, -0.5], [-S3, -0.5]];

  /* ---------- prizes: parts [u, v, r, kind] kind 0 몸 · 1 머리(얼굴) · 2 고리(꼬리표, 집게 끝이 걸림) ---------- */
  const TYPES = [
    { nm: '곰 인형', m: 2.0, v: 3, col: '#b98250', f: 'bear', parts: [[-2.5, 0, 7.5, 0], [6.5, 0, 5.5, 1], [-13.5, 0, 2.4, 2]] },
    { nm: '토끼 인형', m: 1.4, v: 2, col: '#efe3d6', f: 'rabbit', parts: [[-2, 0, 6.5, 0], [5.5, 0, 5, 1], [-11.5, 0, 2.3, 2]] },
    { nm: '고래 쿠션', m: 2.0, v: 5, col: '#5f93d8', f: 'whale', parts: [[-7.5, 0, 6, 0], [0.5, 0, 8, 0], [8.5, 0, 6.5, 1]] },
    { nm: '병아리', m: 0.7, v: 1, col: '#f6d54a', f: 'chick', parts: [[0, 0, 5.5, 1], [-8.5, 0, 2.2, 2]] },
    { nm: '문어 인형', m: 1.5, v: 2, col: '#e57890', f: 'octo', parts: [[-3.5, 0, 5.5, 0], [3, 0, 6.5, 1], [-12, 0, 2.3, 2]] },
    { nm: '고양이 쿠션', m: 1.8, v: 3, col: '#a3a8b6', f: 'cat', parts: [[-3, 0, 7, 0], [5.5, 0, 5.6, 1], [-13.5, 0, 2.4, 2]] },
    { nm: '공룡 인형', m: 2.3, v: 4, col: '#6dbb6b', f: 'dino', parts: [[-1, 0, 7, 0], [7.5, 0, 4.6, 1], [-8.5, 0, 4, 0]] },
    { nm: '왕관 펭귄', m: 2.4, v: 8, col: '#34436e', f: 'peng', parts: [[-2, 0, 7, 0], [5, 0, 5.6, 1]] },
    { nm: '열쇠', m: 0.5, v: 0, col: '#e3ae45', f: 'key', parts: [[-3, 0, 2.6, 2], [1.5, 0, 1.9, 0], [4.8, 0, 1.9, 0]] },
    { nm: '캡슐', m: 1, v: 0, col: '#ee6a55', f: 'cap', parts: [[0, 0, 6, 0]] },
    { nm: '선물 상자', m: 1, v: 0, col: '#c0503f', f: 'box', parts: [[0, 0, 6, 0]] },
  ];
  const T_KEY = 8, T_CAP = 9, T_BOX = 10;
  // shift parts so the centre of mass (solid parts, weight r³) is the origin; ring height above floor
  TYPES.forEach((t) => {
    let su = 0, sv = 0, sw = 0;
    t.parts.forEach((p) => { if (p[3] !== 2) { const w = p[2] * p[2] * p[2]; su += p[0] * w; sv += p[1] * w; sw += w; } });
    su /= sw; sv /= sw;
    t.parts = t.parts.map((p) => [p[0] - su, p[1] - sv, p[2], p[3]]);
    let ext = 0; t.parts.forEach((p) => { ext = Math.max(ext, Math.sqrt(p[0] * p[0] + p[1] * p[1]) + p[2]); });
    t.ext = ext;
  });
  const capR = (v) => 5 + v * 0.55, capM = (v) => 0.5 + v * 0.28;
  const CAPCOL = ['#ee6a55', '#5fb3e8', '#7bd389', '#c69cf0', '#f0a04b', '#f27fb6'];

  /* ---------- machines ---------- */
  // np 집게 갈래 · S 쥐는 힘 · cf 들어 올린 뒤 남는 힘 비율 · Ro 벌린 반지름 · Lp 집게 길이(허브 아래)
  const MACH = [
    { nm: '기본 집게', np: 2, S: 3.4, cf: 0.62, Ro: 12, Lp: 11, tint: '#7a2f52', d: '두 갈래 집게. 머리 밑이나 꼬리표 고리를 노려요.' },
    { nm: '세 갈래 집게', np: 3, S: 3.6, cf: 0.6, Ro: 11, Lp: 10, tint: '#2f5a7a', d: '세 발로 감싸 쥐어요. 둥근 인형에 강하지만 힘은 조금 약해요.' },
    { nm: '밀어내기 판', np: 2, S: 3.5, cf: 0.6, Ro: 12, Lp: 11, tint: '#6a4a1f', d: '앞쪽 선반에 떨어뜨리면 밀판이 매번 앞으로 밀어 줘요. 선반 끝에서 떨어지면 내 것!' },
    { nm: '상자 열쇠', np: 2, S: 3.1, cf: 0.62, Ro: 12, Lp: 11, tint: '#3d5a2a', d: '작은 열쇠를 뽑으면 위의 선물 상자가 열려요(4~7점).' },
    { nm: '캡슐', np: 3, S: 3.5, cf: 0.62, Ro: 12, Lp: 11, tint: '#5a2f7a', d: '둥근 캡슐만 가득. 큰 캡슐일수록 점수가 높지만 무거워요. 굴러가요!' },
  ];
  const M_PUSH = 2, M_KEY = 3, M_CAP = 4;

  function tdef(e) { return TYPES[e[0]]; }
  function partsW(b, out) {
    // world parts of a body {t,x,z,yw,v}: [x, z, cy, r, kind]
    const t = TYPES[b.t], yw = YAW[b.yw & 15], c = yw[0], s = yw[1];
    out.length = 0;
    if (b.t === T_CAP) { const r = capR(b.v); out.push([b.x, b.z, r, r, 0]); return out; }
    for (let k = 0; k < t.parts.length; k++) {
      const p = t.parts[k], px = b.x + p[0] * c - p[1] * s, pz = b.z + p[0] * s + p[1] * c;
      out.push([px, pz, p[3] === 2 ? 2.6 : p[2], p[2], p[3]]);
    }
    return out;
  }
  function massOf(b) { return b.t === T_CAP ? capM(b.v) : TYPES[b.t].m; }
  function extOf(b) { return b.t === T_CAP ? capR(b.v) : TYPES[b.t].ext; }

  /* ---------- deterministic simulation ---------- */
  // cfg {mt, sm}; pile [[t,x,z,yw,v]...]; shot {x, z, k}
  function Sim(cfg, pile, shot) {
    const M = MACH[cfg.mt];
    this.M = M; this.mt = cfg.mt;
    this.S = M.S * cfg.sm; this.cf = M.cf * (0.8 + 0.06 * (shot.k | 0));
    this.B = pile.map((e) => ({ t: e[0], x: +e[1], z: +e[2], yw: e[3] | 0, v: e[4] | 0, st: 0, hb: 0, vx: 0, vz: 0, vy: 0, nx: 0, nz: 0 }));
    this.cx = shot.x; this.cz = shot.z; this.hy = YTOP; this.vy = 0; this.vxc = 0; this.vzc = 0;
    this.sx = 0; this.sz = 0; this.svx = 0; this.svz = 0;
    this.ph = 1; this.pt = 0; this.n = 0; this.done = false;
    this.rho = []; for (let k = 0; k < M.np; k++) this.rho.push(M.Ro);
    this.cl = 0; this.ci = -1; this.slip = 0; this.hook = 0; this.won = []; this.ev = []; this.pp = 0; this.pushed = cfg.mt !== M_PUSH;
    this.dem = 0; this.cap = 0; this.tmp = [];
  }
  const SP = Sim.prototype;
  SP.dirs = function () { return this.M.np === 3 ? PR3 : PR2; };
  SP.tipY = function (rho) { return this.hy - this.M.Lp + (this.M.Ro - rho) * 0.15; };
  SP.stopY = function () {
    const M = this.M, dirs = this.dirs();
    let y = M.Lp + 0.3;
    for (const b of this.B) {
      if (b.st !== 0) continue;
      const P = partsW(b, this.tmp);
      for (const p of P) {
        if (p[4] === 2) continue;
        const r = p[3], cy = p[2];
        let dx = p[0] - this.cx, dz = p[1] - this.cz, d = Math.sqrt(dx * dx + dz * dz);
        if (d < r + HUBR) { const top = d <= HUBR ? cy + r : cy + Math.sqrt(r * r - (d - HUBR) * (d - HUBR)); if (top + 0.2 > y) y = top + 0.2; }
        for (const q of dirs) {
          dx = p[0] - (this.cx + q[0] * M.Ro); dz = p[1] - (this.cz + q[1] * M.Ro); d = Math.sqrt(dx * dx + dz * dz);
          const rr = r + 0.8;
          if (d < rr) { const s = cy + Math.sqrt(rr * rr - d * d) + M.Lp; if (s > y) y = s; }
        }
      }
    }
    return y > YTOP - 2 ? YTOP - 2 : y;
  };
  // close: march each prong inward; first touch stops it. Returns per-prong contacts and hooks.
  SP.contacts = function () {
    const M = this.M, dirs = this.dirs(), hy = this.hy, cx = this.cx, cz = this.cz;
    const near = [];
    for (let i = 0; i < this.B.length; i++) {
      const b = this.B[i]; if (b.st !== 0) continue;
      const dx = b.x - cx, dz = b.z - cz, lim = M.Ro + extOf(b) + 2;
      if (dx * dx + dz * dz > lim * lim) continue;
      const P = partsW(b, []);
      for (const p of P) near.push([i, p]);
    }
    this.cts = []; this.hooks = [];
    const RMIN = 1.2;
    for (let k = 0; k < dirs.length; k++) {
      const q = dirs[k];
      let hit = null;
      for (let rho = M.Ro; rho >= RMIN - 1e-9 && !hit; rho -= 0.25) {
        const ty = this.tipY(rho);
        // curved finger: hinge (by the hub) → knuckle (bowed outward) → tip (curled in)
        const kr = rho + 2.5, ky = hy - M.Lp * 0.6;
        for (let si = 0; si < 2 && !hit; si++) {
          const pr = si === 0 ? rho : (rho + kr) * 0.5, py = si === 0 ? ty : (ty + ky) * 0.5;
          const px = cx + q[0] * pr, pz = cz + q[1] * pr;
          for (const np of near) {
            const p = np[1];
            const ex = px - p[0], ey = py - p[2], ez = pz - p[1], d2 = ex * ex + ey * ey + ez * ez;
            if (p[4] === 2) {
              if (si === 0 && d2 < 2.0 * 2.0 && this.hooks.indexOf(np[0]) < 0) this.hooks.push(np[0]);
              continue;
            }
            const rr = p[3] + 0.8;
            if (d2 < rr * rr) { hit = { k, i: np[0], rho, py, cy: p[2], r: p[3] }; break; }
          }
        }
      }
      if (hit) this.cts.push(hit);
      this.rho[k] = hit ? hit.rho : RMIN;
    }
  };
  SP.capOf = function (i, S, slip) {
    // holding capacity of body i under squeeze S after slipping `slip`
    const dirs = this.dirs();
    let n = 0, ux = 0, uz = 0, f = 0;
    for (const c of this.cts) {
      if (c.i !== i) continue;
      n++; ux -= dirs[c.k][0]; uz -= dirs[c.k][1];
      const sup = (c.cy - c.py) / c.r - slip / c.r;
      f += 0.35 + 1.6 * (sup > 0 ? sup : 0);
    }
    let cap = 0;
    if (n) { const bal = 1 - Math.sqrt(ux * ux + uz * uz) / n; cap = S / this.M.np * f * (bal > 0 ? bal : 0); }
    if (this.hooks.indexOf(i) >= 0) cap += this.M.S * 0.8;
    return cap;
  };
  SP.grab = function () {
    this.contacts();
    let best = -1, bc = 0;
    const touched = [];
    for (const c of this.cts) if (touched.indexOf(c.i) < 0) touched.push(c.i);
    for (const i of this.hooks) if (touched.indexOf(i) < 0) touched.push(i);
    for (const i of touched) { const c = this.capOf(i, this.S, 0); if (c > bc) { bc = c; best = i; } }
    if (best >= 0 && bc < massOf(this.B[best]) * 0.45) best = -1;
    this.ci = best;
    this.hook = best >= 0 && this.hooks.indexOf(best) >= 0 ? 1 : 0;
    // prongs that touched something else push it a little
    const dirs = this.dirs();
    for (const c of this.cts) {
      if (c.i === best) continue;
      const b = this.B[c.i], m = massOf(b);
      const amt = Math.min(4, (c.rho - 1.2) * 0.45) * (m < 1.2 ? 1 : 1.2 / m);
      b.nx -= dirs[c.k][0] * amt; b.nz -= dirs[c.k][1] * amt;
      this.rho[c.k] = c.rho - amt > 1.2 ? c.rho - amt : 1.2;
    }
    if (best >= 0) {
      const b = this.B[best];
      b.st = 1; b.rel = this.hy; b.ox = b.x - this.cx; b.oz = b.z - this.cz;
      const d = Math.sqrt(b.ox * b.ox + b.oz * b.oz);
      b.lev = this.hook ? 1 : 1 + 0.2 * (d > 8 ? 1 : d / 8);
      b.ox0 = b.ox; b.oz0 = b.oz;
      // lifting off-centre starts a swing
      this.svx -= b.ox * 0.9; this.svz -= b.oz * 0.9;
      this.ev.push([this.n, this.hook ? 'hook' : 'grab', best]);
    } else this.ev.push([this.n, this.cts.length ? 'bump' : 'miss', -1]);
  };
  SP.releaseCarried = function (why) {
    const b = this.B[this.ci];
    b.st = 2; b.x = this.cx + this.sx + b.ox; b.z = this.cz + this.sz + b.oz;
    b.vx = this.vxc + this.svx; b.vz = this.vzc + this.svz; b.vy = this.vy * 0.5;
    this.ev.push([this.n, why, this.ci]);
    this.ci = -1;
  };
  SP.inHole = function (x, z) { return this.mt !== M_PUSH && x < HX && z < HZ; };
  SP.resolve = function (mover) {
    // push overlapping prizes apart on the floor (top view), walls clamp
    const bs = [], ps = [];
    for (let i = 0; i < this.B.length; i++) { const b = this.B[i]; if (b.st === 0) { bs.push(i); ps.push(partsW(b, [])); } }
    for (let it = 0; it < 8; it++) {
      let moved = false;
      for (let a = 0; a < bs.length; a++) for (let c = a + 1; c < bs.length; c++) {
        const A = this.B[bs[a]], C = this.B[bs[c]];
        const ddx = A.x - C.x, ddz = A.z - C.z, lim = extOf(A) + extOf(C);
        if (ddx * ddx + ddz * ddz > lim * lim) continue;
        for (const p of ps[a]) {
          if (p[4] === 2) continue;
          for (const q of ps[c]) {
            if (q[4] === 2) continue;
            const ex = p[0] - q[0], ez = p[1] - q[1], rr = (p[3] + q[3]) * 0.82, d2 = ex * ex + ez * ez;
            if (d2 >= rr * rr) continue;
            const d = Math.sqrt(d2), nx = d > 1e-6 ? ex / d : 1, nz = d > 1e-6 ? ez / d : 0, ov = (rr - d) * 0.5;
            const wa = bs[a] === mover ? 0.75 : bs[c] === mover ? 0.25 : 0.5;
            A.x += nx * ov * wa * 2 * 0.5; A.z += nz * ov * wa * 2 * 0.5;
            C.x -= nx * ov * (1 - wa) * 2 * 0.5; C.z -= nz * ov * (1 - wa) * 2 * 0.5;
            moved = true;
          }
        }
      }
      for (let a = 0; a < bs.length; a++) { this.clampB(this.B[bs[a]]); ps[a] = partsW(this.B[bs[a]], ps[a]); }
      if (!moved) break;
    }
    // something nudged over the chute falls in
    for (const i of bs) { const b = this.B[i]; if (this.inHole(b.x, b.z)) { b.st = 4; b.hb = 0; b.vy = 0; b.vx = 0; b.vz = 0; this.win(i); } }
  };
  SP.clampB = function (b) {
    const P = partsW(b, this.tmp);
    let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
    for (const p of P) { if (p[0] - p[3] < x0) x0 = p[0] - p[3]; if (p[0] + p[3] > x1) x1 = p[0] + p[3]; if (p[1] - p[3] < z0) z0 = p[1] - p[3]; if (p[1] + p[3] > z1) z1 = p[1] + p[3]; }
    if (x0 < 0) b.x -= x0; else if (x1 > W) b.x -= x1 - W;
    const zmin = this.mt === M_PUSH ? -40 : 0;
    if (z0 < zmin) b.z -= z0 - zmin; else if (z1 > D) b.z -= z1 - D;
    // chute guard: a prize resting on the floor may not sit across the clear wall
    if (this.mt !== M_PUSH && b.st === 0 && b.x < HX + 2.5 && b.z < HZ + 2.5 && !(b.x < HX && b.z < HZ)) {
      const e = extOf(b) * 0.7;
      if (HX + e - b.x < HZ + e - b.z) b.x = HX + e; else b.z = HZ + e;
    }
  };
  SP.win = function (i) { this.won.push(i); this.ev.push([this.n, 'win', i]); };
  SP.moveAxis = function (pos, tgt, v) {
    const ACC = 80, VM = 34, d = tgt - pos, ad = d < 0 ? -d : d, sg = d < 0 ? -1 : 1;
    let want = Math.sqrt(2 * ACC * ad); if (want > VM) want = VM; want *= sg;
    let nv = v;
    if (nv < want) { nv += ACC * DT; if (nv > want) nv = want; } else if (nv > want) { nv -= ACC * DT; if (nv < want) nv = want; }
    if (ad < 0.06 && (nv < 1 && nv > -1)) return [tgt, 0, true];
    return [pos + nv * DT, nv, false];
  };
  SP.step = function () {
    if (this.done) return;
    const M = this.M;
    let ax = 0, az = 0, ay = 0;
    const pvx = this.vxc, pvz = this.vzc, pvy = this.vy;
    this.pt += DT;
    if (this.ph === 1) { // down
      if (this.n === 0) this.stop = this.stopY();
      this.hy -= 40 * DT;
      if (this.hy <= this.stop) { this.hy = this.stop; this.ph = 2; this.pt = 0; this.grab(); this.r0 = this.rho.slice(); }
    } else if (this.ph === 2) { // close (prongs animate in, bumped prizes slide)
      const e = this.pt / 0.5 > 1 ? 1 : this.pt / 0.5;
      for (const b of this.B) if (b.st === 0 && (b.nx || b.nz)) { b.x += b.nx * DT / 0.5; b.z += b.nz * DT / 0.5; }
      this.cl = e;
      if (e >= 1) {
        for (const b of this.B) if (b.nx || b.nz) { b.nx = 0; b.nz = 0; this.clampB(b); }
        this.resolve(-1);
        this.ph = 3; this.pt = 0;
      }
    } else if (this.ph === 3) { // up
      let v = this.vy + 120 * DT; if (v > 28) v = 28;
      this.hy += v * DT; this.vy = v;
      if (this.hy >= YTOP) { this.hy = YTOP; this.vy = 0; this.ph = 4; this.pt = 0; this.ev.push([this.n, 'top', this.ci]); }
    } else if (this.ph === 4) { // pause: power drops
      if (this.pt >= 0.45) { this.ph = 5; this.pt = 0; }
    } else if (this.ph === 5) { // carry home: z first, then x
      if (!this.zdone) { const r = this.moveAxis(this.cz, HOMEZ, this.vzc); this.cz = r[0]; this.vzc = r[1]; if (r[2]) this.zdone = 1; }
      else { const r = this.moveAxis(this.cx, HOMEX, this.vxc); this.cx = r[0]; this.vxc = r[1]; if (r[2]) { this.ph = 6; this.pt = 0; } }
    } else if (this.ph === 6) { // open
      if (this.ci >= 0) this.releaseCarried('open');
      if (this.pt >= 0.4) { this.ph = 7; this.pt = 0; }
    } else if (this.ph === 7) { // settle
      let busy = false;
      for (const b of this.B) if (b.st >= 2 && b.st <= 4) busy = true;
      if (!busy && !this.pushed) {
        if (this.pp === 0) { this.ledge = []; for (let i = 0; i < this.B.length; i++) { const b = this.B[i]; if (b.st === 0 && b.z < LEDGE) this.ledge.push(i); } if (this.ledge.length) this.ev.push([this.n, 'push', -1]); }
        this.pp += DT / 0.6;
        const dz = 4.5 * DT / 0.6;
        for (const i of this.ledge) this.B[i].z -= dz;
        if (this.pp >= 1) {
          this.pushed = true;
          this.resolve(-1);
          for (let i = 0; i < this.B.length; i++) { const b = this.B[i]; if (b.st === 0 && b.z < 1) { b.st = 4; b.vz = -6; b.vx = 0; b.vy = 0; b.hb = 0; this.win(i); } }
        }
        busy = true;
      }
      if (!busy) { if (this.pt > 0.3 || this.idle) { this.done = true; } this.idle = (this.idle || 0) + DT; }
      else { this.idle = 0; this.pt = 0; }
    }
    ax = (this.vxc - pvx) / DT; az = (this.vzc - pvz) / DT; ay = (this.vy - pvy) / DT;
    if (this.ph >= 3) {
      // claw sways on its cable
      const k = G / LC;
      const fx = -k * this.sx - ax - SWD * this.svx, fz = -k * this.sz - az - SWD * this.svz;
      this.svx += fx * DT; this.svz += fz * DT; this.sx += this.svx * DT; this.sz += this.svz * DT;
      if (this.ci >= 0) {
        const b = this.B[this.ci], m = massOf(b);
        if (this.ph === 3) { const e = (this.hy - b.rel) / 12 > 1 ? 1 : (this.hy - b.rel) / 12; b.ox = b.ox0 * (1 - 0.55 * e); b.oz = b.oz0 * (1 - 0.55 * e); }
        const hx = ax + fx, hz = az + fz, ah = Math.sqrt(hx * hx + hz * hz);
        const dem = m * (1 + ay / G + 0.9 * ah / G) * b.lev;
        const S = this.ph >= 4 ? this.S * this.cf : this.S;
        const cap = this.capOf(this.ci, S, this.slip);
        this.dem = dem; this.cap = cap;
        if (this.hook) {
          if (dem > cap) { this.hook = 0; this.hooks.length = 0; this.ev.push([this.n, 'unhook', this.ci]); }
        } else if (dem > cap) {
          if (this.slip === 0) this.ev.push([this.n, 'slip', this.ci]);
          this.slip += (4 + 40 * (dem - cap) / dem) * DT;
          let smax = 0;
          for (const c of this.cts) if (c.i === this.ci) { const v = c.r * (0.5 + (c.cy - c.py) / c.r); if (v > smax) smax = v; }
          if (this.slip >= smax || cap <= 0.01) this.releaseCarried('drop');
        }
        if (this.ci >= 0) { const b2 = this.B[this.ci]; b2.hb = this.hy - b2.rel - this.slip; if (b2.hb < 0) b2.hb = 0; }
      }
    }
    // falling / sliding prizes
    for (let i = 0; i < this.B.length; i++) {
      const b = this.B[i];
      if (b.st === 2) {
        b.vy -= G * DT; b.hb += b.vy * DT; b.x += b.vx * DT; b.z += b.vz * DT;
        if (b.x < 3) { b.x = 3; b.vx = -b.vx * 0.3; } else if (b.x > W - 3) { b.x = W - 3; b.vx = -b.vx * 0.3; }
        if (b.z < 3 && this.mt !== M_PUSH) { b.z = 3; b.vz = -b.vz * 0.3; } else if (b.z > D - 3) { b.z = D - 3; b.vz = -b.vz * 0.3; }
        if (b.hb <= 0) {
          if (this.inHole(b.x, b.z)) { b.st = 4; this.win(i); }
          else {
            b.hb = 0; b.vy = 0; b.st = 3;
            const kf = b.t === T_CAP ? 0.75 : 0.25; b.vx *= kf; b.vz *= kf;
            this.ev.push([this.n, 'land', i]);
          }
        }
      } else if (b.st === 3) {
        const sp = Math.sqrt(b.vx * b.vx + b.vz * b.vz), fr = b.t === T_CAP ? 22 : 120;
        if (sp < 0.6) {
          b.st = 0; b.vx = 0; b.vz = 0; b.yw = (b.yw + (b.t === T_CAP ? 0 : 3)) & 15;
          this.clampB(b); this.resolve(i);
        } else {
          const ns = sp - fr * DT, f = ns > 0 ? ns / sp : 0;
          b.vx *= f; b.vz *= f; b.x += b.vx * DT; b.z += b.vz * DT;
          if (this.mt !== M_PUSH && b.x < HX + 3 && b.z < HZ + 3) { // clear wall around the chute
            if (b.x - HX > b.z - HZ) { b.x = HX + 3; b.vx = -b.vx * 0.4; } else { b.z = HZ + 3; b.vz = -b.vz * 0.4; }
          }
          if (b.x < 3) { b.x = 3; b.vx = -b.vx * 0.4; } else if (b.x > W - 3) { b.x = W - 3; b.vx = -b.vx * 0.4; }
          if (b.z > D - 3) { b.z = D - 3; b.vz = -b.vz * 0.4; } else if (b.z < 3 && this.mt !== M_PUSH) { b.z = 3; b.vz = -b.vz * 0.4; }
        }
      } else if (b.st === 4) {
        b.vy -= G * DT; b.hb += b.vy * DT; b.z += b.vz * DT;
        if (b.hb < -30) b.st = 5;
      }
    }
    this.n++;
    if (this.n > MAXN && !this.done) this.finish();
  };
  SP.finish = function () {
    // safety net: settle everything instantly
    if (this.ci >= 0) this.releaseCarried('drop');
    for (let i = 0; i < this.B.length; i++) {
      const b = this.B[i];
      if (b.st === 2 || b.st === 3) { b.st = 0; b.hb = 0; this.clampB(b); }
      if (b.st === 4) b.st = 5;
    }
    this.done = true;
  };
  SP.run = function () { while (!this.done) this.step(); return this; };
  SP.pile = function () {
    const out = [];
    for (const b of this.B) if (b.st === 0) out.push([b.t, r1(b.x), r1(b.z), b.yw, b.v]);
    return out;
  };
  function simulate(cfg, pile, shot) { return new Sim(cfg, pile, shot).run(); }

  /* ---------- pile generation (init only, Math.random ok) ---------- */
  function fits(pile, e, mt) {
    const b = { t: e[0], x: e[1], z: e[2], yw: e[3], v: e[4] };
    const P = partsW(b, []);
    for (const p of P) {
      if (p[0] - p[3] < 1 || p[0] + p[3] > W - 1 || p[1] - p[3] < 1 || p[1] + p[3] > D - 1) return false;
      if (mt !== M_PUSH && p[0] - p[3] < HX + 5 && p[1] - p[3] < HZ + 5) return false;
    }
    for (const o of pile) {
      const Q = partsW({ t: o[0], x: o[1], z: o[2], yw: o[3], v: o[4] }, []);
      for (const p of P) for (const q of Q) {
        if (p[4] === 2 && q[4] === 2) continue;
        const dx = p[0] - q[0], dz = p[1] - q[1], rr = (p[3] + q[3]) * 0.85 + 0.5;
        if (dx * dx + dz * dz < rr * rr) return false;
      }
    }
    return true;
  }
  function place(pile, t, v, mt, z0, z1) {
    for (let a = 0; a < 400; a++) {
      const e = [t, r1(8 + Math.random() * (W - 16)), r1(z0 + Math.random() * (z1 - z0)), U.rand(16), v];
      if (fits(pile, e, mt)) { pile.push(e); return true; }
    }
    return false;
  }
  function makePile(mt) {
    const pile = [];
    if (mt === M_CAP) {
      const vals = U.shuffle([1, 1, 1, 2, 2, 2, 3, 3, 4, 5, 6]);
      for (const v of vals) place(pile, T_CAP, v, mt, 6, D - 6);
      return pile;
    }
    let types;
    if (mt === M_KEY) types = [T_KEY, T_KEY, T_KEY, 0, 1, 3, 4, 5, 6, 2];
    else {
      const pool = [0, 0, 1, 1, 3, 3, 4, 5, 5, 6, 2];
      types = U.shuffle(pool).slice(0, mt === M_PUSH ? 8 : 9).concat([7]);
    }
    if (mt === M_PUSH) {
      // a few prizes already wait on the front shelf
      for (const t of [3, 1, 4]) place(pile, t, TYPES[t].v, mt, 7, 15);
      for (const t of types) place(pile, t, TYPES[t].v, mt, LEDGE + 6, D - 5);
    } else for (const t of types) place(pile, t, TYPES[t].v, mt, 6, D - 5);
    return pile;
  }

  /* ---------- state ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const mo = opts.mach == null ? 'r' : String(opts.mach);
    const mt = mo === 'r' ? U.rand(MACH.length) : U.clamp(+mo | 0, 0, MACH.length - 1);
    const T = U.clamp(+(opts.tries || 7) | 0, 3, 12);
    const sm = { w: 0.85, n: 1, s: 1.2 }[opts.pow || 'n'] || 1;
    const pile = makePile(mt);
    return {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), mt, sm, T,
      cur: 0, u: players.map(() => 0), sc: players.map(() => 0), w: players.map(() => []),
      P: players.map(() => pile.map((e) => e.slice())),
      bx: mt === M_KEY ? U.shuffle([4, 5, 7]) : 0, seq: 0, last: null, ph: 'p',
    };
  }
  function actor(s) { return s.ph === 'e' ? null : s.cur; }
  function prizeValue(s, seat, e, wonSoFar) {
    if (e[0] === T_KEY) { const keys = wonSoFar.filter((w) => w[0] === T_BOX).length; return [T_BOX, s.bx ? (s.bx[keys] != null ? s.bx[keys] : 5) : 5]; }
    return [e[0], e[4]];
  }
  function apply(s, seat, a) {
    if (actor(s) !== seat) throw new Error('not your turn');
    if (!a || a.type !== 'drop') throw new Error('bad action');
    const x = +a.x, z = +a.z;
    if (!isFinite(x) || !isFinite(z)) throw new Error('bad aim');
    const shot = { x: r1(U.clamp(x, 4, W - 4)), z: r1(U.clamp(z, 4, D - 4)), k: U.rand(10) };
    const pre = s.P[seat];
    const sim = simulate({ mt: s.mt, sm: s.sm }, pre, shot);
    const got = [];
    for (const i of sim.won) {
      const wv = prizeValue(s, seat, pre[i], s.w[seat]);
      s.w[seat].push(wv); s.sc[seat] += wv[1]; got.push(wv);
    }
    s.P[seat] = sim.pile();
    s.u[seat]++;
    s.seq++;
    s.last = { id: s.seq, seat, pre, shot, got };
    if (s.u.every((u) => u >= s.T) || s.P.every((p, i) => s.u[i] >= s.T || !p.length)) s.ph = 'e';
    else {
      let c = s.cur;
      for (let t = 0; t < s.n; t++) { c = (c + 1) % s.n; if (s.u[c] < s.T && s.P[c].length) break; }
      s.cur = c;
    }
    return s;
  }
  // solo stars by machine (score targets)
  const STAR = [[4, 8, 13], [3, 6, 10], [6, 11, 16], [6, 13, 20], [4, 9, 14]];
  function starTargets(s) { return STAR[s.mt].map((v) => Math.max(1, Math.round(v * s.T / 7))); }
  function stars(s) { const T = starTargets(s); let k = 0; while (k < 3 && s.sc[0] >= T[k]) k++; return k; }
  function result(s) {
    if (s.ph !== 'e') return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    if (s.n === 1) {
      const st = stars(s), T = starTargets(s);
      return { winners: st > 0 ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요',
        text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + s.sc[0] + '점 (' + s.w[0].length + '개)\n' + MACH[s.mt].nm + ' · 별 기준 ' + T.join(' / ') + '점' };
    }
    const key = (i) => s.sc[i] * 100 + s.w[i].length;
    const best = Math.max(...s.sc.map((v, i) => key(i)));
    const winners = s.sc.map((v, i) => (key(i) === best ? i : -1)).filter((i) => i >= 0);
    const order = s.sc.map((v, i) => i).sort((a, b) => key(b) - key(a));
    return { winners, title: winners.length > 1 ? '공동 우승' : undefined,
      text: MACH[s.mt].nm + '\n' + order.map((i, r) => (r + 1) + '위 ' + nm(i) + ' · ' + s.sc[i] + '점 (' + s.w[i].length + '개)').join('\n') };
  }

  /* ---------- AI ---------- */
  function worth(s, seat, sim, pre) {
    let v = 0;
    for (const i of sim.won) v += prizeValue(s, seat, pre[i], s.w[seat])[1] + 0.3;
    return v;
  }
  function candidates(pile, lv) {
    const out = [];
    const add = (x, z) => { if (x >= 4 && x <= W - 4 && z >= 4 && z <= D - 4) out.push([r1(x), r1(z)]); };
    for (const e of pile) {
      const b = { t: e[0], x: e[1], z: e[2], yw: e[3], v: e[4] };
      const P = partsW(b, []);
      add(b.x, b.z);
      for (const p of P) {
        add(p[0], p[1]);
        if (lv >= 3) { add(p[0], p[1] + 2.5); add(p[0], p[1] - 2.5); add(p[0] + 2.5, p[1]); add(p[0] - 2.5, p[1]); }
        if (lv >= 3 && p[4] === 2) { const yw = YAW[b.yw & 15]; for (const o of [-3, -1.5, 1.5, 3]) add(p[0] + yw[0] * o, p[1] + yw[1] * o); add(p[0], p[1] + 1.2); add(p[0], p[1] - 1.2); add(p[0] + 1.2, p[1]); add(p[0] - 1.2, p[1]); }
      }
    }
    return out;
  }
  const ALV = { 1: { nz: 2.6, ks: [4], top: 0 }, 2: { nz: 2.2, ks: [5], top: 6 }, 3: { nz: 0.5, ks: [2, 5, 8], top: 10 } };
  function evalAim(s, seat, x, z, ks) {
    const pre = s.P[seat];
    let t = 0;
    for (const k of ks) {
      const sim = simulate({ mt: s.mt, sm: s.sm }, pre, { x, z, k });
      t += worth(s, seat, sim, pre);
      if (s.mt === M_PUSH) { // prizes moved onto the front shelf are worth something later
        const P = sim.pile();
        for (const e of P) if (e[2] < LEDGE) t += 0.35 * e[4] * (1 - e[2] / LEDGE);
      }
    }
    return t / ks.length;
  }
  function gauss() { return (Math.random() + Math.random() + Math.random() - 1.5) * 1.15; }
  function ai(s, seat, lv) {
    const K = ALV[lv] || ALV[2], pile = s.P[seat];
    if (!pile.length) return { type: 'drop', x: HOMEX + 20, z: HOMEZ + 20 };
    let bx, bz;
    if (lv === 1) {
      // beginner: goes for a prize it likes (often the shiny one) and aims at its middle
      const e = Math.random() < 0.5 ? pile.reduce((a, b) => (b[4] > a[4] ? b : a)) : pile[U.rand(pile.length)];
      const P = partsW({ t: e[0], x: e[1], z: e[2], yw: e[3], v: e[4] }, []);
      const hd = P.filter((q) => q[4] === 1), p = hd.length && Math.random() < 0.5 ? hd[0] : Math.random() < 0.3 ? P[U.rand(P.length)] : [e[1], e[2]];
      bx = p[0]; bz = p[1];
    } else {
      const t0 = Date.now(), budget = lv === 3 ? 260 : 120;
      const C = candidates(pile, lv), sc = [];
      for (const c of C) { if (Date.now() - t0 > budget * 0.6 && sc.length > 30) break; sc.push([c[0], c[1], evalAim(s, seat, c[0], c[1], [K.ks[0]])]); }
      sc.sort((a, b) => b[2] - a[2]);
      let best = sc[0];
      if (lv === 3) {
        // robust choice: average over luck and a little aim wobble
        let bv = -1;
        for (const c of sc.slice(0, K.top)) {
          if (Date.now() - t0 > budget) break;
          const v = evalAim(s, seat, c[0], c[1], K.ks) * 2 + evalAim(s, seat, c[0] + 0.6, c[1], [5]) + evalAim(s, seat, c[0], c[1] + 0.6, [5]) + evalAim(s, seat, c[0] - 0.6, c[1] - 0.6, [5]);
          if (v > bv) { bv = v; best = c; }
        }
      } else if (sc.length > 1 && Math.random() < 0.4) best = sc[U.rand(Math.min(K.top, sc.length))];
      bx = best[0]; bz = best[1];
    }
    return { type: 'drop', x: r1(U.clamp(bx + gauss() * K.nz, 4, W - 4)), z: r1(U.clamp(bz + gauss() * K.nz, 4, D - 4)) };
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 1000 : lv === 3 ? 550 : 750; }

  /* ---------- view ---------- */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    root.append(e);
    let key = '';
    const set = (x, y, w, h) => { const k = [x, y, w, h].map(Math.round).join(','); if (k === key) return; key = k; Object.assign(e.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' }); };
    set.el = e;
    return set;
  }
  function shade(hex, k) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    if (k > 0) { r += (255 - r) * k; g += (255 - g) * k; b += (255 - b) * k; } else { r *= 1 + k; g *= 1 + k; b *= 1 + k; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  const TIME_LIMIT = 20;
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
    let st = null, disp = 0, anim = null, tween = null, endT = 0, shelfW = [], fx = [], floats = [], dirty = true;
    let aim = { x: HOMEX, z: HOMEZ }, timer = -1, holdT = { x: 0, z: 0 }, sentShot = null, staticCv = null, staticKey = '';
    const held = { left: 0, right: 0, back: 0, front: 0 };
    const topH = 50, botH = 132, shelfH = 36, signH = 26;
    let V = null;

    /* DOM: chips on top, controls below */
    const top = L.h('div', { class: 'hud top cw-chips', style: { gap: '5px', padding: '6px 8px', flexWrap: 'nowrap' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 10px', flexDirection: 'column', gap: '6px' } });
    const hint = L.h('div', { class: 'muted', style: { fontSize: '12px', textAlign: 'center', minHeight: '16px', lineHeight: '16px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%' } });
    const btn = (lab, sub, dir) => {
      const b = L.h('button', { class: 'btn cw-arrow', style: { width: '54px', height: '48px', minWidth: '0', padding: '0', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', lineHeight: '1', touchAction: 'none', userSelect: 'none' } },
        L.h('span', { style: { fontSize: '18px' }, text: lab }), L.h('span', { style: { fontSize: '10px', opacity: 0.75, marginTop: '2px' }, text: sub }));
      const on = (e) => { e.preventDefault(); if (!canMove()) return; held[dir] = 1; b.classList.add('on'); b.style.background = 'var(--brass)'; b.style.color = '#2a1d10'; try { b.setPointerCapture(e.pointerId); } catch (er) {} };
      const off = () => { held[dir] = 0; b.style.background = ''; b.style.color = ''; };
      b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('lostpointercapture', off);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
      return b;
    };
    const bUp = btn('▲', '안쪽', 'back'), bDn = btn('▼', '앞쪽', 'front'), bL = btn('◀', '왼쪽', 'left'), bR = btn('▶', '오른쪽', 'right');
    const pad = L.h('div', { class: 'cw-pad', style: { display: 'grid', gridTemplateColumns: '54px 54px 54px', gridTemplateRows: '48px 48px', gap: '5px' } },
      L.h('div'), bUp, L.h('div'), bL, bDn, bR);
    const dropT = L.h('span', { style: { fontSize: '11px', opacity: 0.85, marginTop: '3px', fontFamily: 'var(--f-mono)' }, text: '' });
    const drop = L.h('button', { class: 'btn primary cw-drop', style: { width: '100px', height: '100px', borderRadius: '50%', padding: '0', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontSize: '19px', fontFamily: 'var(--f-display)', boxShadow: '0 5px 0 #7a5418, 0 8px 18px rgba(0,0,0,.45)' } },
      L.h('span', { text: '내리기' }), dropT);
    drop.addEventListener('click', () => doDrop());
    const ctl = L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '18px' } }, pad, drop);
    const wait = L.h('div', { class: 'panel', style: { display: 'none', alignItems: 'center', justifyContent: 'center', height: '100px', width: '100%', maxWidth: '340px', fontSize: '15px', fontWeight: 700, textAlign: 'center', padding: '0 12px', boxSizing: 'border-box' } });
    bot.append(hint, ctl, wait);
    root.append(top, bot);
    const spMini = tutSpot(root, 'cw-mini');

    const offIn = api.input && api.input.on ? api.input.on((type, id) => { if (type === 'down' && id === 'drop') doDrop(); }) : null;

    function myTurn() { return st && st.ph === 'p' && !anim && !tween && endT === 0 && api.canAct(st.cur); }
    function canMove() { return myTurn(); }
    function doDrop() {
      if (!myTurn()) return;
      sentShot = { x: r1(aim.x), z: r1(aim.z) };
      timer = -1; for (const k in held) held[k] = 0;
      api.sfx('click'); api.buzz(20);
      api.act({ type: 'drop', x: sentShot.x, z: sentShot.z });
    }

    /* ---- camera ---- */
    const CAM = [50, 230, -105], TGT = [50, 6, 40];
    let fy, fz;
    { const dy = TGT[1] - CAM[1], dz = TGT[2] - CAM[2], l = Math.hypot(dy, dz); fy = dy / l; fz = dz / l; }
    const P3 = [0, 0, 0];
    function proj(x, y, z) {
      const dx = x - CAM[0], dy = y - CAM[1], dz = z - CAM[2];
      const Z = dy * fy + dz * fz, Y = dy * fz - dz * fy;
      P3[0] = V.ox + dx / Z * V.F; P3[1] = V.oy - Y / Z * V.F; P3[2] = V.F / Z;
      return P3;
    }
    const BOXH = 58, RAIL = YTOP + 10;
    function layout() {
      const w = cv.w, h = cv.h;
      const y0 = topH + signH, y1 = h - botH - shelfH - 16;
      const pts = [];
      for (const x of [0, W]) for (const y of [0, BOXH]) for (const z of [0, D]) pts.push([x, y, z]);
      let a = 1e9, b = -1e9, c = 1e9, d = -1e9;
      for (const p of pts) {
        const dx = p[0] - CAM[0], dy = p[1] - CAM[1], dz = p[2] - CAM[2], Z = dy * fy + dz * fz, Y = dy * fz - dz * fy;
        const X = dx / Z, YY = -Y / Z; a = Math.min(a, X); b = Math.max(b, X); c = Math.min(c, YY); d = Math.max(d, YY);
      }
      const F = Math.min((w - 20) / (b - a), (y1 - y0) / (d - c));
      V = { F, ox: w / 2 - (a + b) / 2 * F, oy: (y0 + y1) / 2 - (c + d) / 2 * F, y0, y1, w, h };
      staticKey = ''; dirty = true;
      const mw = Math.round(Math.min(96, w * 0.24)), mh = Math.round(mw * D / W);
      V.mini = { x: 10, y: topH + 4, w: mw, h: mh };
      spMini(V.mini.x - 2, V.mini.y - 2, mw + 4, mh + 16);
    }
    cv.onresize = layout;

    /* ---- static cabinet ---- */
    function poly(g, pts) { g.beginPath(); pts.forEach((p, i) => { const q = proj(p[0], p[1], p[2]); if (i) g.lineTo(q[0], q[1]); else g.moveTo(q[0], q[1]); }); g.closePath(); }
    function buildStatic() {
      const key = [cv.w, cv.h, st ? st.mt : -1].join(',');
      if (key === staticKey && staticCv) return;
      staticKey = key;
      if (!staticCv) staticCv = document.createElement('canvas');
      staticCv.width = Math.round(cv.w * cv.dpr); staticCv.height = Math.round(cv.h * cv.dpr);
      const g = staticCv.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const mt = st ? st.mt : 0, M = MACH[mt];
      // parlor background
      const bg = g.createLinearGradient(0, 0, 0, cv.h); bg.addColorStop(0, '#1d1727'); bg.addColorStop(1, '#120e18');
      g.fillStyle = bg; g.fillRect(0, 0, cv.w, cv.h);
      // cabinet body behind the glass
      const fl = proj(0, 0, 0).slice(), fr = proj(W, 0, 0).slice(), tl = proj(0, BOXH, D).slice(), tr = proj(W, BOXH, D).slice();
      const tfl = proj(0, BOXH, 0).slice(), tfr = proj(W, BOXH, 0).slice();
      g.fillStyle = shade(M.tint, -0.35);
      g.beginPath(); g.moveTo(tfl[0] - 10, tfl[1] - 8); g.lineTo(tfr[0] + 10, tfr[1] - 8); g.lineTo(fr[0] + 12, fr[1] + 14); g.lineTo(fl[0] - 12, fl[1] + 14); g.closePath(); g.fill();
      // back wall
      poly(g, [[0, 0, D], [W, 0, D], [W, BOXH, D], [0, BOXH, D]]);
      const bw = g.createLinearGradient(0, tl[1], 0, proj(0, 0, D)[1]); bw.addColorStop(0, shade(M.tint, -0.15)); bw.addColorStop(1, shade(M.tint, -0.55));
      g.fillStyle = bw; g.fill();
      // little stars pattern on the back wall
      g.fillStyle = 'rgba(255,240,200,.08)';
      for (let i = 0; i < 18; i++) { const q = proj(6 + (i * 37) % 90, 30 + ((i * 23) % 50), D); g.beginPath(); g.arc(q[0], q[1], 2.2, 0, 7); g.fill(); }
      // side walls
      poly(g, [[0, 0, 0], [0, 0, D], [0, BOXH, D], [0, BOXH, 0]]); g.fillStyle = shade(M.tint, -0.45); g.fill();
      poly(g, [[W, 0, 0], [W, 0, D], [W, BOXH, D], [W, BOXH, 0]]); g.fillStyle = shade(M.tint, -0.5); g.fill();
      // floor (felt)
      poly(g, [[0, 0, 0], [W, 0, 0], [W, 0, D], [0, 0, D]]);
      const fg = g.createLinearGradient(0, proj(0, 0, D)[1], 0, fl[1]); fg.addColorStop(0, '#163f33'); fg.addColorStop(1, '#1f6a52');
      g.fillStyle = fg; g.fill();
      g.strokeStyle = 'rgba(255,255,255,.05)'; g.lineWidth = 1;
      for (let x = 10; x < W; x += 10) { g.beginPath(); let q = proj(x, 0, 0); g.moveTo(q[0], q[1]); q = proj(x, 0, D); g.lineTo(q[0], q[1]); g.stroke(); }
      for (let z = 10; z < D; z += 10) { g.beginPath(); let q = proj(0, 0, z); g.moveTo(q[0], q[1]); q = proj(W, 0, z); g.lineTo(q[0], q[1]); g.stroke(); }
      if (mt === M_PUSH) {
        // front shelf with its pusher rail
        poly(g, [[0, 0.1, 0], [W, 0.1, 0], [W, 0.1, LEDGE], [0, 0.1, LEDGE]]); g.fillStyle = 'rgba(227,174,69,.16)'; g.fill();
        g.strokeStyle = 'rgba(255,220,140,.55)'; g.lineWidth = 2;
        g.beginPath(); let q = proj(0, 0, 0.2); g.moveTo(q[0], q[1]); q = proj(W, 0, 0.2); g.lineTo(q[0], q[1]); g.stroke();
        g.setLineDash([5, 5]); g.beginPath(); q = proj(0, 0, LEDGE); g.moveTo(q[0], q[1]); q = proj(W, 0, LEDGE); g.lineTo(q[0], q[1]); g.stroke(); g.setLineDash([]);
        g.fillStyle = 'rgba(255,230,170,.75)'; g.font = '700 11px ' + FONT; g.textAlign = 'center';
        q = proj(W / 2 + 12, 0, LEDGE * 0.5); g.fillText('선반 끝에서 떨어지면 내 것', q[0], q[1] + 4);
      } else {
        // chute hole + clear guard wall
        poly(g, [[0, 0, 0], [HX, 0, 0], [HX, 0, HZ], [0, 0, HZ]]);
        g.fillStyle = '#07050a'; g.fill();
        poly(g, [[HX, 0, 0], [HX, GUARD, 0], [HX, GUARD, HZ], [HX, 0, HZ]]); g.fillStyle = 'rgba(200,230,255,.13)'; g.fill();
        poly(g, [[0, 0, HZ], [HX, 0, HZ], [HX, GUARD, HZ], [0, GUARD, HZ]]); g.fillStyle = 'rgba(200,230,255,.1)'; g.fill();
        g.strokeStyle = 'rgba(227,174,69,.9)'; g.lineWidth = 2;
        g.beginPath(); let q = proj(HX, GUARD, 0); g.moveTo(q[0], q[1]); q = proj(HX, GUARD, HZ); g.lineTo(q[0], q[1]); q = proj(0, GUARD, HZ); g.lineTo(q[0], q[1]); g.stroke();
        q = proj(HX / 2, 0, HZ / 2); g.fillStyle = 'rgba(255,230,170,.8)'; g.font = '700 11px ' + FONT; g.textAlign = 'center'; g.fillText('출구', q[0], q[1] + 4);
      }
      // gantry rails on top
      g.strokeStyle = 'rgba(190,190,205,.55)'; g.lineWidth = 3;
      for (const x of [1, W - 1]) { g.beginPath(); let q = proj(x, RAIL, 0); g.moveTo(q[0], q[1]); q = proj(x, RAIL, D); g.lineTo(q[0], q[1]); g.stroke(); }
      // glass box edges
      g.strokeStyle = 'rgba(220,235,255,.22)'; g.lineWidth = 1.5;
      g.beginPath(); let q0 = proj(0, BOXH, 0); g.moveTo(q0[0], q0[1]); q0 = proj(0, BOXH, D); g.lineTo(q0[0], q0[1]); q0 = proj(W, BOXH, D); g.lineTo(q0[0], q0[1]); q0 = proj(W, BOXH, 0); g.lineTo(q0[0], q0[1]); g.stroke();
      // brass base trim
      g.strokeStyle = '#e3ae45'; g.lineWidth = 3;
      g.beginPath(); g.moveTo(fl[0] - 12, fl[1] + 14); g.lineTo(fr[0] + 12, fr[1] + 14); g.stroke();
    }

    /* ---- drawing prizes ---- */
    function sphere(x, y, z, r, col, alpha) {
      const q = proj(x, y, z), R = r * q[2], sx = q[0], sy = q[1];
      const gr = ctx.createRadialGradient(sx - R * 0.35, sy - R * 0.4, R * 0.1, sx, sy, R);
      gr.addColorStop(0, shade(col, 0.45)); gr.addColorStop(0.55, col); gr.addColorStop(1, shade(col, -0.45));
      ctx.globalAlpha = alpha; ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(sx, sy, R, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
      return [sx, sy, R];
    }
    function face(f, c, col) {
      const sx = c[0], sy = c[1], R = c[2];
      const eye = (dx) => { ctx.fillStyle = '#1b1320'; ctx.beginPath(); ctx.arc(sx + dx * R, sy + 0.02 * R, Math.max(1, 0.12 * R), 0, 7); ctx.fill(); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(sx + dx * R + 0.04 * R, sy - 0.03 * R, Math.max(0.5, 0.04 * R), 0, 7); ctx.fill(); };
      if (f === 'bear' || f === 'cat' || f === 'rabbit' || f === 'peng' || f === 'dino' || f === 'octo' || f === 'chick' || f === 'whale') {
        if (f === 'bear') { ctx.fillStyle = shade(col, -0.2); for (const d of [-1, 1]) { ctx.beginPath(); ctx.arc(sx + d * 0.62 * R, sy - 0.7 * R, 0.3 * R, 0, 7); ctx.fill(); } ctx.fillStyle = shade(col, 0.35); ctx.beginPath(); ctx.ellipse(sx, sy + 0.3 * R, 0.3 * R, 0.22 * R, 0, 0, 7); ctx.fill(); }
        if (f === 'cat') { ctx.fillStyle = shade(col, -0.15); for (const d of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sx + d * 0.3 * R, sy - 0.8 * R); ctx.lineTo(sx + d * 0.85 * R, sy - 1.05 * R); ctx.lineTo(sx + d * 0.8 * R, sy - 0.4 * R); ctx.fill(); } }
        if (f === 'rabbit') { ctx.fillStyle = col; for (const d of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sx + d * 0.35 * R, sy - 1.05 * R, 0.2 * R, 0.55 * R, d * 0.15, 0, 7); ctx.fill(); ctx.fillStyle = '#f2a5b5'; ctx.beginPath(); ctx.ellipse(sx + d * 0.35 * R, sy - 1.05 * R, 0.09 * R, 0.38 * R, d * 0.15, 0, 7); ctx.fill(); ctx.fillStyle = col; } }
        if (f === 'peng') { ctx.fillStyle = '#f4ecdc'; ctx.beginPath(); ctx.ellipse(sx, sy + 0.2 * R, 0.6 * R, 0.55 * R, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#ffd34d'; ctx.beginPath(); ctx.moveTo(sx - 0.5 * R, sy - 0.75 * R); ctx.lineTo(sx - 0.45 * R, sy - 1.25 * R); ctx.lineTo(sx - 0.18 * R, sy - 0.95 * R); ctx.lineTo(sx, sy - 1.35 * R); ctx.lineTo(sx + 0.18 * R, sy - 0.95 * R); ctx.lineTo(sx + 0.45 * R, sy - 1.25 * R); ctx.lineTo(sx + 0.5 * R, sy - 0.75 * R); ctx.fill(); }
        if (f === 'dino') { ctx.fillStyle = shade(col, -0.25); for (const d of [-0.4, 0, 0.4]) { ctx.beginPath(); ctx.moveTo(sx + d * R - 0.15 * R, sy - 0.88 * R); ctx.lineTo(sx + d * R, sy - 1.2 * R); ctx.lineTo(sx + d * R + 0.15 * R, sy - 0.88 * R); ctx.fill(); } }
        eye(-0.3); eye(0.3);
        if (f === 'chick' || f === 'peng') { ctx.fillStyle = '#f08a2a'; ctx.beginPath(); ctx.moveTo(sx - 0.13 * R, sy + 0.2 * R); ctx.lineTo(sx + 0.13 * R, sy + 0.2 * R); ctx.lineTo(sx, sy + 0.42 * R); ctx.fill(); }
        else { ctx.fillStyle = 'rgba(240,120,140,.55)'; for (const d of [-1, 1]) { ctx.beginPath(); ctx.arc(sx + d * 0.48 * R, sy + 0.25 * R, 0.13 * R, 0, 7); ctx.fill(); } }
      }
    }
    function drawBody(b, X, Z, HB, alpha, tilt) {
      const t = TYPES[b.t], P = partsW({ t: b.t, x: X, z: Z, yw: b.yw, v: b.v }, []);
      const order = P.map((p, i) => i).sort((i, j) => P[j][1] - P[i][1]);
      for (const i of order) {
        const p = P[i];
        const lift = tilt ? (p[0] - X) * tilt[0] + (p[1] - Z) * tilt[1] : 0;
        const y = HB + p[2] + lift;
        if (p[4] === 2) {
          const q = proj(p[0], y, p[1]), R = p[3] * q[2];
          ctx.globalAlpha = alpha; ctx.strokeStyle = b.t === T_KEY ? '#e3ae45' : '#f4ecdc'; ctx.lineWidth = Math.max(1.2, R * 0.28);
          ctx.beginPath(); ctx.arc(q[0], q[1], R * 0.6, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
          continue;
        }
        if (b.t === T_CAP) {
          const col = CAPCOL[(b.v * 7 + ((b.x * 3) | 0)) % CAPCOL.length];
          const c = sphere(p[0], y, p[1], p[3], '#ece6f2', alpha);
          ctx.save(); ctx.beginPath(); ctx.arc(c[0], c[1], c[2], 0, 7); ctx.clip();
          ctx.globalAlpha = 0.85 * alpha; ctx.fillStyle = col; ctx.fillRect(c[0] - c[2], c[1] - c[2], c[2] * 2, c[2] * 1.02);
          ctx.globalAlpha = 0.5 * alpha; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(c[0] - c[2] * 0.35, c[1] - c[2] * 0.5, c[2] * 0.25, c[2] * 0.14, -0.5, 0, 7); ctx.fill();
          ctx.restore(); ctx.globalAlpha = alpha;
          ctx.fillStyle = 'rgba(30,20,40,.55)'; ctx.font = '700 ' + Math.max(8, c[2] * 0.8 | 0) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('?', c[0], c[1] + c[2] * 0.15); ctx.textBaseline = 'alphabetic'; ctx.globalAlpha = 1;
          continue;
        }
        const c = sphere(p[0], y, p[1], p[3], t.col, alpha);
        if (p[4] === 1) { ctx.globalAlpha = alpha; face(t.f, c, t.col); ctx.globalAlpha = 1; }
        else if (t.f === 'peng' || t.f === 'bear') { ctx.globalAlpha = alpha * 0.8; ctx.fillStyle = t.f === 'peng' ? '#f4ecdc' : shade(t.col, 0.3); ctx.beginPath(); ctx.arc(c[0], c[1] + c[2] * 0.15, c[2] * 0.5, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
      }
    }
    function shadow(x, z, r, a) {
      const q = proj(x, 0.05, z), R = r * q[2];
      ctx.fillStyle = 'rgba(0,0,0,' + a + ')'; ctx.beginPath(); ctx.ellipse(q[0], q[1], R, R * 0.55, 0, 0, 7); ctx.fill();
    }

    /* ---- claw ---- */
    function drawClaw(c) {
      const M = MACH[st.mt], dirs = M.np === 3 ? PR3 : PR2;
      const hx = c.x + c.sx, hz = c.z + c.sz;
      // gantry bar and trolley
      ctx.strokeStyle = 'rgba(200,200,215,.7)'; ctx.lineWidth = 4;
      let q = proj(0, RAIL, c.z); ctx.beginPath(); ctx.moveTo(q[0], q[1]); q = proj(W, RAIL, c.z); ctx.lineTo(q[0], q[1]); ctx.stroke();
      const T = proj(c.x, RAIL, c.z).slice();
      ctx.fillStyle = '#3a3346'; ctx.fillRect(T[0] - 9, T[1] - 5, 18, 10);
      // cable
      const Hh = proj(hx, c.y + 5, hz).slice();
      ctx.strokeStyle = '#cfc8d8'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(T[0], T[1]); ctx.lineTo(Hh[0], Hh[1]); ctx.stroke();
      // prongs: back ones first
      const order = dirs.map((d, i) => i).sort((i, j) => dirs[j][1] - dirs[i][1]);
      const drawProng = (k) => {
        const d = dirs[k], rho = c.rho[k];
        const hp = proj(hx + d[0] * 2.4, c.y, hz + d[1] * 2.4).slice();
        const kp = proj(hx + d[0] * (rho + 2.5), c.y - M.Lp * 0.6, hz + d[1] * (rho + 2.5)).slice();
        const ty = c.y - M.Lp + (M.Ro - rho) * 0.15;
        const tp = proj(hx + d[0] * rho, ty, hz + d[1] * rho).slice();
        const cp = proj(hx + d[0] * (rho - 1.6), ty + 0.8, hz + d[1] * (rho - 1.6)).slice();
        const lw = Math.max(2, 1.3 * tp[2]);
        for (const pass of [0, 1]) {
          ctx.strokeStyle = pass ? '#e9c46f' : '#5a3d12'; ctx.lineWidth = pass ? lw : lw + 2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          ctx.beginPath(); ctx.moveTo(hp[0], hp[1]); ctx.lineTo(kp[0], kp[1]); ctx.lineTo(tp[0], tp[1]); ctx.lineTo(cp[0], cp[1]); ctx.stroke();
        }
      };
      const back = order.filter((k) => dirs[k][1] > 0.1), front = order.filter((k) => dirs[k][1] <= 0.1);
      back.forEach(drawProng);
      // hub
      const hq = proj(hx, c.y + 2, hz), R = 3.6 * hq[2];
      const gr = ctx.createRadialGradient(hq[0] - R * 0.3, hq[1] - R * 0.4, R * 0.1, hq[0], hq[1], R);
      gr.addColorStop(0, '#fff2c4'); gr.addColorStop(0.5, '#e3ae45'); gr.addColorStop(1, '#7a5418');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(hq[0], hq[1], R, 0, 7); ctx.fill();
      return () => front.forEach(drawProng);
    }
    function lasers(x, z, a) {
      ctx.save(); ctx.globalAlpha = a; ctx.strokeStyle = '#ff5a6e'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]);
      let q = proj(0, 0.1, z); ctx.beginPath(); ctx.moveTo(q[0], q[1]); q = proj(W, 0.1, z); ctx.lineTo(q[0], q[1]); ctx.stroke();
      q = proj(x, 0.1, 0); ctx.beginPath(); ctx.moveTo(q[0], q[1]); q = proj(x, 0.1, D); ctx.lineTo(q[0], q[1]); ctx.stroke();
      ctx.setLineDash([]);
      // claw reach ring + centre dot on the floor
      const M = MACH[st.mt];
      ctx.strokeStyle = 'rgba(255,240,200,.8)'; ctx.lineWidth = 1.5; ctx.beginPath();
      for (let i = 0; i <= 24; i++) { const an = i / 24 * Math.PI * 2; q = proj(x + Math.cos(an) * M.Ro, 0.1, z + Math.sin(an) * M.Ro); if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }
      ctx.stroke();
      q = proj(x, 0.1, z); ctx.fillStyle = '#ff5a6e'; ctx.beginPath(); ctx.arc(q[0], q[1], 3.2, 0, 7); ctx.fill();
      ctx.restore();
    }

    /* ---- what to draw now ---- */
    function clawNow() {
      const M = MACH[st.mt];
      if (anim) {
        const s = anim.sim; let rho;
        if (s.ph === 2) rho = s.r0.map((r) => M.Ro - (M.Ro - r) * s.cl);
        else if (s.ph === 6) rho = s.rho.map((r) => r + (M.Ro - r) * Math.min(1, s.pt / 0.4));
        else if (s.ph >= 7 || s.ph === 1) rho = s.rho.map(() => M.Ro);
        else rho = s.rho.slice();
        if (s.ph === 4 || s.ph === 5) rho = rho.map((r) => r + 0.35);
        return { x: s.cx, z: s.cz, y: s.hy, sx: s.sx, sz: s.sz, rho };
      }
      const rho = Array(M.np).fill(M.Ro);
      if (tween) return { x: tween.x, z: tween.z, y: YTOP, sx: 0, sz: 0, rho };
      const mine = myTurn();
      return { x: mine ? aim.x : HOMEX, z: mine ? aim.z : HOMEZ, y: YTOP, sx: 0, sz: 0, rho };
    }
    function bodiesNow() {
      if (anim) return anim.sim.B;
      const P = (st.P[disp] || []);
      return P.map((e) => ({ t: e[0], x: e[1], z: e[2], yw: e[3], v: e[4], st: 0, hb: 0 }));
    }
    let tFrame = 0;
    function draw() {
      if (!V || !st) return;
      buildStatic();
      ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(staticCv, 0, 0); ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const M = MACH[st.mt], cl = clawNow(), B = bodiesNow();
      const simPh = anim ? anim.sim.ph : 0;
      // sign
      ctx.textAlign = 'center'; ctx.fillStyle = '#e3ae45'; ctx.font = '17px ' + DISP;
      const nm = api.players[disp] ? api.players[disp].name : '';
      ctx.fillText(M.nm + (st.n > 1 ? ' · ' + nm : ''), V.w / 2 + (V.mini.w + 10) / 2, topH + 18);
      // pusher plate
      if (st.mt === M_PUSH) {
        const pz = LEDGE + 1 - (anim && anim.sim.pp ? Math.min(1, anim.sim.pp) * 4.5 : 0);
        const a = proj(0, 0, pz).slice(), b = proj(W, 0, pz).slice(), c = proj(W, 4, pz).slice(), d = proj(0, 4, pz).slice();
        ctx.fillStyle = 'rgba(190,195,210,.55)'; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.fill();
      }
      // floor guide
      const showL = !anim || simPh <= 2;
      if (showL) lasers(cl.x + cl.sx, cl.z + cl.sz, anim ? 0.45 : 0.95);
      else { shadow(cl.x + cl.sx, cl.z + cl.sz, 4, 0.25); }
      // shadows of prizes
      for (const b of B) if (b.st !== 5 && b.st !== 4) { const pos = bodyPos(b); shadow(pos[0], pos[1], extOf(b) * 0.75, Math.max(0.08, 0.3 - pos[2] * 0.004)); }
      // prizes back → front, claw in between
      const items = [];
      B.forEach((b, i) => { if (b.st !== 5) items.push([bodyPos(b)[1], i]); });
      items.sort((a, b) => b[0] - a[0]);
      const cz = cl.z + cl.sz; let clawDone = false, frontProngs = null;
      const carried = anim && anim.sim.ci >= 0 ? anim.sim.ci : -1;
      for (const it of items) {
        if (!clawDone && it[0] < cz - 0.5 && it[1] !== carried) { frontProngs = drawClaw(cl); if (carried >= 0) drawOne(B[carried]); frontProngs(); clawDone = true; }
        if (it[1] === carried) continue;
        drawOne(B[it[1]]);
      }
      if (!clawDone) { frontProngs = drawClaw(cl); if (carried >= 0) drawOne(B[carried]); frontProngs(); }
      // glass shine
      const fl = proj(0, 0, 0).slice(), tfl = proj(0, BOXH, 0).slice();
      ctx.fillStyle = 'rgba(255,255,255,.035)';
      ctx.beginPath(); ctx.moveTo(fl[0] + 30, fl[1]); ctx.lineTo(fl[0] + 60, fl[1]); ctx.lineTo(tfl[0] + 110, tfl[1]); ctx.lineTo(tfl[0] + 80, tfl[1]); ctx.fill();
      drawMini(cl, B);
      drawShelf();
      drawFx();
    }
    function bodyPos(b) {
      if (anim && anim.sim.ci >= 0 && anim.sim.B[anim.sim.ci] === b) { const s = anim.sim; return [s.cx + s.sx + b.ox, s.cz + s.sz + b.oz, b.hb]; }
      return [b.x, b.z, b.hb || 0];
    }
    function drawOne(b) {
      const p = bodyPos(b);
      let tilt = null;
      if (anim && anim.sim.ci >= 0 && anim.sim.B[anim.sim.ci] === b) {
        // hanging prize: the side away from the claw sags
        const s = anim.sim, ox = b.ox0 || 0, oz = b.oz0 || 0, d = Math.hypot(ox, oz) || 1, k = Math.min(0.5, d / 14);
        tilt = [-ox / d * k + s.sx * 0.03, -oz / d * k + s.sz * 0.03];
        if (s.ph === 2) tilt = null;
      }
      const a = b.st === 4 ? Math.max(0, 1 + p[2] / 30) : 1;
      drawBody(b, p[0], p[1], p[2], a, tilt);
    }
    function drawMini(cl, B) {
      const m = V.mini, k = m.w / W;
      const X = (x) => m.x + x * k, Y = (z) => m.y + m.h - z * k;
      ctx.fillStyle = 'rgba(10,8,14,.82)'; ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5;
      ctx.fillRect(m.x, m.y, m.w, m.h); ctx.strokeRect(m.x, m.y, m.w, m.h);
      if (st.mt === M_PUSH) { ctx.fillStyle = 'rgba(227,174,69,.2)'; ctx.fillRect(m.x, Y(LEDGE), m.w, LEDGE * k); }
      else { ctx.fillStyle = '#000'; ctx.fillRect(m.x, Y(HZ), HX * k, HZ * k); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.strokeRect(m.x, Y(HZ), HX * k, HZ * k); }
      for (const b of B) {
        if (b.st === 5 || b.st === 4) continue;
        const p = bodyPos(b);
        const P = partsW({ t: b.t, x: p[0], z: p[1], yw: b.yw, v: b.v }, []);
        const col = b.t === T_CAP ? '#d8d0e4' : TYPES[b.t].col;
        for (const q of P) { ctx.fillStyle = q[4] === 2 ? '#f4ecdc' : col; ctx.beginPath(); ctx.arc(X(q[0]), Y(q[1]), Math.max(1.2, (q[4] === 2 ? 1.4 : q[3]) * k), 0, 7); ctx.fill(); }
      }
      const cx = X(cl.x + cl.sx), cy = Y(cl.z + cl.sz);
      ctx.strokeStyle = '#ff5a6e'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(m.x, cy); ctx.lineTo(m.x + m.w, cy); ctx.moveTo(cx, m.y); ctx.lineTo(cx, m.y + m.h); ctx.stroke();
      ctx.strokeStyle = '#ffe9a8'; ctx.beginPath(); ctx.arc(cx, cy, MACH[st.mt].Ro * k, 0, 7); ctx.stroke();
      ctx.fillStyle = 'rgba(242,233,216,.7)'; ctx.font = '10px ' + FONT; ctx.textAlign = 'left'; ctx.fillText('위에서 본 모습', m.x, m.y + m.h + 11);
    }
    function miniIcon(w, x, y, R) {
      const t = w[0];
      if (t === T_BOX) { ctx.fillStyle = '#c0503f'; ctx.fillRect(x - R, y - R * 0.8, R * 2, R * 1.7); ctx.fillStyle = '#ffd34d'; ctx.fillRect(x - R * 0.18, y - R * 0.8, R * 0.36, R * 1.7); ctx.fillRect(x - R, y - R * 0.1, R * 2, R * 0.3); return; }
      const col = t === T_CAP ? CAPCOL[w[1] % CAPCOL.length] : TYPES[t].col;
      const gr = ctx.createRadialGradient(x - R * 0.3, y - R * 0.4, R * 0.1, x, y, R); gr.addColorStop(0, shade(col, 0.45)); gr.addColorStop(1, shade(col, -0.35));
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, R, 0, 7); ctx.fill();
      if (t !== T_CAP && t !== T_KEY) face(TYPES[t].f, [x, y, R], col);
    }
    function drawShelf() {
      const y = V.h - botH - shelfH + 2, w = V.w;
      const g = ctx.createLinearGradient(0, y, 0, y + shelfH - 4); g.addColorStop(0, '#6b4424'); g.addColorStop(1, '#3d2614');
      ctx.fillStyle = g; ctx.fillRect(8, y + shelfH - 12, w - 16, 8);
      const list = anim ? shelfW : (st.w[disp] || []);
      ctx.textAlign = 'left'; ctx.font = '11px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.65)';
      if (!list.length) { ctx.fillText('내 선반 — 뽑은 인형이 여기 놓여요', 14, y + shelfH - 17); return; }
      const R = 9, gap = Math.min(22, (w - 90) / Math.max(1, list.length));
      list.forEach((it, i) => miniIcon(it, 22 + i * gap, y + shelfH - 12 - R + 1, R));
      const sum = list.reduce((a, b) => a + b[1], 0);
      ctx.textAlign = 'right'; ctx.font = '700 13px ' + FONT; ctx.fillStyle = '#e3ae45';
      ctx.fillText(sum + '점', w - 14, y + shelfH - 17);
    }
    function drawFx() {
      for (const p of fx) { ctx.fillStyle = p.c; ctx.globalAlpha = Math.max(0, 1 - p.t / 1.6); ctx.fillRect(p.x, p.y, 5, 3); }
      ctx.globalAlpha = 1;
      ctx.textAlign = 'center';
      for (const f of floats) {
        ctx.globalAlpha = Math.max(0, 1 - f.t / 1.4); ctx.font = '20px ' + DISP;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,14,26,.85)'; ctx.strokeText(f.s, f.x, f.y - f.t * 26); ctx.fillStyle = f.c; ctx.fillText(f.s, f.x, f.y - f.t * 26);
      }
      ctx.globalAlpha = 1;
    }
    function burst(x, y) {
      const C = ['#e3ae45', '#ee6a55', '#5fd3a0', '#7fb6ff', '#f4ecdc'];
      for (let i = 0; i < 46; i++) { const a = Math.random() * 6.28, v = 60 + Math.random() * 190; fx.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 140, c: C[i % 5], t: 0 }); }
    }
    function floatAt(x3, y3, z3, s, c) { const q = proj(x3, y3, z3); floats.push({ x: q[0], y: q[1], s, c: c || '#f4ecdc', t: 0 }); }

    /* ---- replay ---- */
    let evN = 0, gotN = 0;
    function startAnim(l) {
      disp = l.seat;
      shelfW = (st.w[l.seat] || []).slice(0, Math.max(0, (st.w[l.seat] || []).length - l.got.length));
      api.setBusy(true);
      anim = null; evN = 0; gotN = 0;
      const mine = sentShot && sentShot.x === l.shot.x && sentShot.z === l.shot.z;
      sentShot = null;
      if (mine) beginSim(l);
      else tween = { x: HOMEX, z: HOMEZ, l };
    }
    function beginSim(l) {
      tween = null;
      anim = { sim: new Sim({ mt: st.mt, sm: st.sm }, l.pre, l.shot), l, acc: 0 };
      api.sfx('whoosh');
    }
    function onEvent(e) {
      const s = anim.sim, b = e[2] >= 0 ? s.B[e[2]] : null, nm = b ? (b.t === T_CAP ? '캡슐' : TYPES[b.t].nm) : '';
      const at = b ? bodyPos(b) : [s.cx, s.cz, 0];
      if (e[1] === 'grab') { api.sfx('click'); api.buzz(15); floatAt(at[0], 16, at[1], '꽉!', '#ffe9a8'); }
      else if (e[1] === 'hook') { api.sfx('click'); api.buzz(25); floatAt(at[0], 16, at[1], '고리에 걸렸다!', '#7fe0b0'); }
      else if (e[1] === 'bump') { api.sfx('tick'); floatAt(s.cx, 12, s.cz, '헛손질', '#ab9fb8'); }
      else if (e[1] === 'miss') { api.sfx('tick'); floatAt(s.cx, 12, s.cz, '꽝!', '#ab9fb8'); }
      else if (e[1] === 'top' && s.ci >= 0) { api.sfx('tick'); }
      else if (e[1] === 'slip') { api.sfx('whoosh'); floatAt(at[0], at[2] + 20, at[1], '미끄러진다…', '#ffb36b'); }
      else if (e[1] === 'drop' || e[1] === 'unhook') { api.sfx('thud'); api.buzz(30); floatAt(at[0], at[2] + 14, at[1], '앗!', '#ee6a55'); }
      else if (e[1] === 'land') api.sfx('bounce');
      else if (e[1] === 'push') api.sfx('chip');
      else if (e[1] === 'win') {
        const got = anim.l.got[gotN++] || [b ? b.t : 0, 0];
        shelfW.push(got);
        api.sfx('win'); api.buzz(60);
        const q = proj(at[0], 10, at[1]); burst(q[0], q[1]);
        const label = got[0] === T_BOX ? '열쇠로 선물 상자 열기!' : nm + ' 획득!';
        floatAt(at[0], 20, at[1], '+' + got[1] + '점', '#e3ae45');
        api.toast(label + ' +' + got[1] + '점');
      }
    }
    function finishAnim() {
      anim = null; tween = null; endT = 0; api.setBusy(false);
      disp = st.ph === 'e' ? disp : st.cur;
      aim = { x: HOMEX, z: HOMEZ }; timer = -1;
      renderAll(); dirty = true;
    }

    /* ---- HUD ---- */
    let topKey = '', botKey = '';
    function renderTop() {
      const cur = anim || tween ? -1 : st.cur;
      const key = [st.sc.join(), st.u.join(), cur, disp, st.ph].join('|');
      if (key === topKey) return; topKey = key;
      top.innerHTML = '';
      for (let i = 0; i < st.n; i++) {
        const p = api.players[i], on = i === (anim || tween ? disp : st.cur) && st.ph === 'p';
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '4px 7px', display: 'flex', flexDirection: 'column', gap: '1px',
          borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color : 'none', opacity: on || st.ph !== 'p' ? 1 : 0.75 } },
        L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden' } },
          L.h('span', { class: 'dot', style: { '--c': p.color } }), L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' }, text: p.name })),
        L.h('div', { class: 'mono', style: { fontSize: '12px', display: 'flex', gap: '6px', whiteSpace: 'nowrap' } },
          L.h('span', { style: { color: 'var(--brass)' }, text: st.sc[i] + '점' }), L.h('span', { class: 'muted', text: '남은 ' + Math.max(0, st.T - st.u[i]) }))));
      }
    }
    function renderBot() {
      const mine = myTurn();
      let msg = '', w = '';
      if (st.ph === 'e') { msg = '게임 끝!'; w = '결과를 확인하세요'; }
      else if (anim || tween) { const p = api.players[disp]; msg = MACH[st.mt].d; w = p.name + ' 뽑는 중…'; }
      else if (mine) msg = timer < 0 ? '◀▶▲▼를 누르고 있으면 움직여요 · 빨간 점이 집게 위치' : '시간이 다 되면 그 자리에서 내려가요';
      else { const p = api.players[st.cur]; msg = MACH[st.mt].d; w = p.name + (p.ai ? ' 생각 중…' : ' 차례'); }
      const key = [mine, msg, w].join('|');
      if (key === botKey) return; botKey = key;
      hint.textContent = msg;
      ctl.style.display = mine ? 'flex' : 'none';
      wait.style.display = mine ? 'none' : 'flex';
      wait.textContent = w;
    }
    function renderAll() { if (!st) return; renderTop(); renderBot(); }

    /* ---- loop ---- */
    const stop = U.loop((dt) => {
      if (!st || !V) return;
      const sp = L.debug.speed || 1;
      if (tween) {
        const tgt = tween.l.shot, v = 42 * dt * sp;
        if (Math.abs(tween.x - tgt.x) > 0.01) tween.x += U.clamp(tgt.x - tween.x, -v, v);
        else if (Math.abs(tween.z - tgt.z) > 0.01) tween.z += U.clamp(tgt.z - tween.z, -v, v);
        else beginSim(tween.l);
        dirty = true;
      }
      if (anim) {
        const s = anim.sim;
        if (!s.done) {
          anim.acc += dt * sp;
          let n = 0;
          while (anim.acc >= DT && !s.done && n < 600) { s.step(); anim.acc -= DT; n++; while (evN < s.ev.length) onEvent(s.ev[evN++]); }
          if (s.done) endT = 0.75;
        } else if (endT > 0) { endT -= dt * sp; if (endT <= 0) { endT = 0; finishAnim(); } }
        dirty = true;
      }
      if (myTurn()) {
        let mx = (held.right ? 1 : 0) - (held.left ? 1 : 0), mz = (held.back ? 1 : 0) - (held.front ? 1 : 0);
        if (api.input && api.input.held) { mx += (api.input.held('right') ? 1 : 0) - (api.input.held('left') ? 1 : 0); mz += (api.input.held('back') ? 1 : 0) - (api.input.held('front') ? 1 : 0); }
        mx = U.clamp(mx, -1, 1); mz = U.clamp(mz, -1, 1);
        holdT.x = mx ? holdT.x + dt : 0; holdT.z = mz ? holdT.z + dt : 0;
        if (mx || mz) {
          if (timer < 0) { timer = TIME_LIMIT; renderBot(); }
          aim.x = U.clamp(aim.x + mx * (10 + 26 * Math.min(1, holdT.x / 0.6)) * dt, 4, W - 4);
          aim.z = U.clamp(aim.z + mz * (10 + 26 * Math.min(1, holdT.z / 0.6)) * dt, 4, D - 4);
          dirty = true;
        }
        if (timer >= 0) {
          timer -= dt;
          const t = Math.max(0, Math.ceil(timer));
          if (dropT.textContent !== t + '초') dropT.textContent = t + '초';
          if (timer <= 0) doDrop();
        } else if (dropT.textContent !== '20초') dropT.textContent = '20초';
      }
      if (fx.length) { for (const p of fx) { p.t += dt; p.vy += 420 * dt; p.x += p.vx * dt; p.y += p.vy * dt; } fx = fx.filter((p) => p.t < 1.6); dirty = true; }
      if (floats.length) { for (const f of floats) f.t += dt; floats = floats.filter((f) => f.t < 1.4); dirty = true; }
      tFrame += dt;
      if (dirty) { dirty = false; draw(); }
    });
    layout();

    return {
      update(next, prev) {
        const first = !st;
        st = next;
        if (next.last && prev && prev !== next && (!prev.last || prev.last.id !== next.last.id)) startAnim(next.last);
        else if (!anim && !tween) { disp = next.ph === 'e' && next.last ? next.last.seat : next.cur; }
        if (first) staticKey = '';
        renderAll(); dirty = true;
      },
      destroy() { stop(); if (offIn) offIn(); cv.destroy(); top.remove(); bot.remove(); spMini.el.remove(); api.setBusy(false); },
    };
  }

  L.register({
    id: 'claw', name: '인형 뽑기', tag: '크레인 · 물리', cat: '아케이드',
    blurb: '오락실 크레인으로 인형 뽑기. 집게를 좌우·앞뒤로 옮겨 내리면 물리로 집었다가 미끄러지기도 해요. 정해진 횟수 안에 점수 합이 높은 사람이 이겨요.',
    icon: '<rect x="10" y="6" width="36" height="4" rx="2" fill="currentColor"/><rect x="27" y="10" width="2" height="12" fill="currentColor"/><circle cx="28" cy="24" r="4" fill="currentColor"/><path d="M25 26 L18 34 L22 40" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M31 26 L38 34 L34 40" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="28" cy="44" r="7" fill="currentColor" opacity=".55"/><circle cx="23" cy="38" r="2.6" fill="currentColor" opacity=".55"/><circle cx="33" cy="38" r="2.6" fill="currentColor" opacity=".55"/>',
    tint: '#7a2f52',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 750,
    options: [
      { id: 'mach', label: '기계', choices: [{ v: 'r', label: '무작위' }].concat(MACH.map((m, k) => ({ v: String(k), label: m.nm }))), def: 'r' },
      { id: 'tries', label: '한 사람 횟수', choices: [{ v: '5', label: '5번' }, { v: '7', label: '7번' }, { v: '10', label: '10번' }], def: '7' },
      { id: 'pow', label: '집게 힘', choices: [{ v: 'w', label: '약하게' }, { v: 'n', label: '기계대로' }, { v: 's', label: '세게' }], def: 'n' },
    ],
    controls: [
      { id: 'left', label: '왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'back', label: '안쪽으로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'front', label: '앞쪽으로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'drop', label: '내리기', keys: ['Space', 'KeyX'], pad: ['a'] },
    ],
    quick: [
      '크레인 집게로 인형을 뽑아 출구에 넣으면 내 것! 정해진 횟수 안에 점수 합이 가장 높은 사람이 이겨요.',
      '내 차례: ◀▶로 좌우, ▲▼로 안쪽·앞쪽으로 옮긴 뒤 「내리기」. 바닥의 빨간 점 바로 위에 집게가 있어요.',
      '머리 밑이나 꼬리표 고리를 노리면 잘 잡혀요. 무거운 인형은 들어 올린 뒤 힘이 빠지면 미끄러지기 쉬워요.',
    ],
    rules: [
      { h: '목표', p: ['1~4명이 각자 자기 인형 뽑기 기계로 해요. 모두 똑같은 인형 더미로 시작해서 공평해요.',
        '한 사람씩 번갈아 한 번씩 뽑아요(기본 7번). 뽑은 인형 점수를 모두 더해 가장 높은 사람이 이기고, 같으면 개수가 많은 사람이 이겨요.',
        '혼자 하면 점수로 ★을 받아요(별 기준은 결과 화면에 나와요).'] },
      { h: '차례에 할 일', p: ['① ◀ ▶ 버튼을 누르고 있으면 집게가 좌우로, ▲(안쪽) ▼(앞쪽)를 누르고 있으면 앞뒤로 움직여요. 오래 누를수록 빨라져요.',
        '② 바닥의 빨간 점선 두 줄이 만나는 빨간 점이 집게 바로 아래예요. 노란 원은 집게 발이 닿는 범위예요. 왼쪽 위 작은 지도(위에서 본 모습)도 같이 보세요.',
        '③ 「내리기」를 누르면 집게가 내려가 쥐고, 올라간 뒤 왼쪽 앞 출구까지 옮겨서 놓아요.',
        '④ 처음 움직인 뒤 20초가 지나면 그 자리에서 저절로 내려가요.'] },
      { h: '잘 뽑는 요령', p: ['집게는 인형 위에 얹히면 거기서 멈춰요. 집게 발이 인형 아래쪽을 감싸야 잘 잡혀요.',
        '작은 머리, 꼬리, 꼬리표 고리를 노리면 잘 잡혀요. 고리에 집게 끝이 걸리면 아주 튼튼해요.',
        '두 갈래 집게는 좌우로 오므려요. 인형이 앞뒤로 누워 있을 때 머리를 노리기 좋아요.',
        '들어 올린 뒤 꼭대기에서 힘이 조금 빠져요(판마다 조금씩 달라요). 옮기는 중에 흔들리면 미끄러질 수 있어요. 떨어진 곳이 출구면 행운!'] },
      { h: '점수', p: ['병아리 1 · 토끼 인형·문어 인형 2 · 곰 인형·고양이 쿠션 3 · 공룡 인형 4 · 고래 쿠션 5 · 왕관 펭귄 8점.',
        '캡슐은 열어 봐야 알아요(1~6점, 큰 캡슐일수록 높아요). 열쇠를 뽑으면 선물 상자를 열어 4~7점.'] },
      { h: '기계 5가지', p: MACH.map((m) => m.nm + ': ' + m.d).concat(['기본은 「무작위」. 집게 힘 옵션으로 더 약하게·세게 할 수 있어요.']) },
      { h: '예시', p: ['곰 인형이 앞뒤로 누워 있어요. 집게를 곰 머리 바로 위에 맞추고 내리기 → 두 발이 머리 아래를 감싸 「꽉!」 → 출구에 떨어지면 +3점.',
        '곰의 큰 몸통 한가운데를 노리면 집게가 몸통 위에 얹혀 발이 아래까지 못 내려가요 → 「미끄러진다…」 하고 놓치기 쉬워요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(노리는 곳과 조준 정확도가 달라요).'] },
    ],
    tutorial: [
      { sel: '.cw-mini', text: '위에서 본 작은 지도예요. 빨간 십자가 집게 위치, 검은 칸이 출구예요.' },
      { sel: '.cw-pad', text: '◀▶는 좌우, ▲▼는 안쪽·앞쪽. 누르고 있으면 움직여요. 바닥의 빨간 점 바로 위에 집게가 있어요.' },
      { sel: '.cw-drop', text: '자리를 잡았으면 「내리기」! 머리 밑이나 꼬리표 고리를 노리면 잘 잡혀요.' },
      { sel: '.cw-chips', text: '정해진 횟수 안에 뽑은 인형 점수 합이 가장 높으면 이겨요. 남은 횟수는 여기서 봐요.' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _sim: { Sim, simulate, MACH, TYPES, makePile, partsW, YAW },
  });
})();
