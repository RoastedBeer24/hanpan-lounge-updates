/* 승부차기 — 2인 승부차기(5번씩 번갈아, 조기 결정, 이후 서든데스 짝). 차는 사람·막는 사람이 매 킥마다 바뀐다.
   키커(스와이프: 9구역 · 파워 · 감아차기)와 골키퍼(스와이프: 6방향 다이빙)는 동시에 비공개로 고른다(배열 actor).
   두 선택이 모이면(+선택 사항: 골키퍼 반응 탭) apply가 실행 오차를 뽑아 공 도착점을 정하고 골키퍼 손닿는 범위와
   비교해 골 / 선방 / 골대 / 크로스바 위 / 빗나감을 정한다. 뷰는 state.last만으로 같은 궤적·다이빙을 재생한다.
   좌표(m): x = 화면 오른쪽 +, y = 위, z = 골라인에서 키커 쪽 +. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }
  const DEG = Math.PI / 180;

  /* ---------- geometry & tuning ---------- */
  const GW = 3.66, GH = 2.44, PR = 0.06, BR = 0.11, SPOT = 11;
  const ZX = [-2.95, 0, 2.95], ZY = [0.38, 1.22, 2.02]; // zone centres: z = row*3 + col (row 0 = low)
  const ZN = ['왼쪽 아래', '가운데 아래', '오른쪽 아래', '왼쪽 가운데', '정중앙', '오른쪽 가운데', '왼쪽 위', '가운데 위', '오른쪽 위'];
  // dives d: 0 L-low, 1 L-high, 2 C-low, 3 C-high, 4 R-low, 5 R-high (screen left/right)
  const DV = [
    { n: '왼쪽 아래', cx: -1.9, cy: 0.45, rx: 1.25, ry: 0.6, hx: -2.75, hy: 0.38, th: -80 },
    { n: '왼쪽 위', cx: -1.85, cy: 1.55, rx: 1.12, ry: 0.72, hx: -2.6, hy: 1.98, th: -52 },
    { n: '가운데 아래', cx: 0, cy: 0.55, rx: 0.95, ry: 0.72, hx: 0, hy: 0.45, th: 0 },
    { n: '가운데 위', cx: 0, cy: 1.5, rx: 0.9, ry: 0.95, hx: 0, hy: 2.3, th: 0 },
    { n: '오른쪽 아래', cx: 1.9, cy: 0.45, rx: 1.25, ry: 0.6, hx: 2.75, hy: 0.38, th: 80 },
    { n: '오른쪽 위', cx: 1.85, cy: 1.55, rx: 1.12, ry: 0.72, hx: 2.6, hy: 1.98, th: 52 },
  ];
  const SIG_H = 0.25, SIG = { 1: 0.42, 2: 0.3, 3: 0.2 }; // placement error (m) at normal power
  const RB0 = 0.12;                                       // keeper reach bonus when the reaction tap is off
  const AIMS = { 1: [430, 80], 2: [320, 60], 3: [235, 40] };
  const RUN = 1.05;                                       // run-up seconds (view)
  const r2 = (v) => Math.round(v * 100) / 100;
  function gauss() { let u = 0, v = 0; while (u === 0) u = Math.random(); while (v === 0) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  const speedOf = (pw) => 16 + 13 * pw;
  function rbFrom(ms) { if (typeof ms !== 'number' || ms < 100) return 0; return U.clamp(0.3 * (1 - (ms - 150) / 400), 0, 0.3); }
  /* hidden choices travel in the state lightly scrambled (the view never shows them) */
  const enc = (o) => { const t = JSON.stringify(o); let r = ''; for (let i = 0; i < t.length; i++) r += String.fromCharCode(t.charCodeAt(i) ^ 7); return r.split('').reverse().join(''); };
  const dec = (s) => { const t = s.split('').reverse().join(''); let r = ''; for (let i = 0; i < t.length; i++) r += String.fromCharCode(t.charCodeAt(i) ^ 7); return JSON.parse(r); };

  /* ---------- rules ---------- */
  function init(players, opts) {
    return { n: 2, nm: players.map((p) => String(p.name || '').slice(0, 10)), ai: players.map((p) => (p.ai ? 1 : 0)), lv: players.map((p) => p.lv || 0),
      fs: Math.random() < 0.5 ? 0 : 1, h: ['', ''], ph: 'c', kc: null, gc: null, ro: opts && opts.react === 'off' ? 0 : 1,
      zh: ['', ''], dh: ['', ''], w: -1, seq: 0, last: null };
  }
  const goals = (str) => { let g = 0; for (const c of str) if (c === 'o') g++; return g; };
  function kicker(s) { return (s.h[0].length + s.h[1].length) % 2 === 0 ? s.fs : 1 - s.fs; }
  function decided(s) {
    const a = s.fs, b = 1 - s.fs, ga = goals(s.h[a]), gb = goals(s.h[b]), ka = s.h[a].length, kb = s.h[b].length;
    if (ka <= 5 && kb <= 5) {
      if (ga + (5 - ka) < gb) return b;
      if (gb + (5 - kb) < ga) return a;
      return -1;
    }
    if (ka === kb && ga !== gb) return ga > gb ? a : b;
    return -1;
  }
  function actor(s) {
    if (s.ph === 'e') return null;
    const k = kicker(s), g = 1 - k;
    if (s.ph === 'r') return g;
    const o = [];
    if (s.kc == null) o.push(k);
    if (s.gc == null) o.push(g);
    return o;
  }
  /* placement → outcome. Returns the event object stored in state.last */
  function resolve(s, rb) {
    const k = kicker(s), g = 1 - k, kc = dec(s.kc), gc = dec(s.gc);
    const sig = (s.ai[k] ? SIG[s.lv[k]] || SIG[2] : SIG_H) * (0.7 + 0.45 * kc.pw) * (1 + 0.35 * Math.abs(kc.cv));
    let x = ZX[kc.z % 3] + gauss() * sig;
    let y = ZY[Math.floor(kc.z / 3)] + gauss() * sig * 0.75 + Math.max(0, kc.pw - 1) * 2.6;
    y = Math.max(BR, y);
    x = r2(x); y = r2(y);
    const v = speedOf(kc.pw), T = SPOT / v, ax = Math.abs(x);
    let r, hb = 0, c = 0;
    const clean = ax <= GW - BR && y <= GH - BR;
    const frame = ax < GW + 2 * PR + BR && y < GH + 2 * PR + BR;
    if (clean) r = 'G';
    else if (frame) {
      hb = y > GH - BR && ax <= GW ? 1 : 0;
      r = ax <= GW + PR && y <= GH + PR ? 'I' : 'P';
    } else r = y > GH + PR && y - GH > ax - GW ? 'O' : 'W';
    if (r === 'G' || r === 'I') {
      const D = DV[gc.d];
      const f = (0.86 + Math.random() * 0.24) * (1 + rb + U.clamp((T - 0.4) * 1.2, 0, 0.35) - Math.abs(kc.cv) * 0.08);
      const q = ((x - D.cx) / (D.rx * f)) ** 2 + ((y - D.cy) / (D.ry * f)) ** 2;
      if (q <= 1) { r = 'S'; c = q < 0.3 && v < 27 ? 1 : 0; hb = 0; }
    }
    return { k, g, z: kc.z, x, y, v: Math.round(v * 10) / 10, pw: r2(kc.pw), cv: r2(kc.cv), d: gc.d, r, hb, c };
  }
  function finish(s, ev, ms) {
    s.seq++;
    const scored = ev.r === 'G' || ev.r === 'I';
    s.h[ev.k] += scored ? 'o' : 'x';
    s.zh[ev.k] = (s.zh[ev.k] + ev.z).slice(-12);
    s.dh[ev.g] = (s.dh[ev.g] + ev.d).slice(-12);
    s.kc = null; s.gc = null; s.ph = 'c';
    const w = decided(s);
    if (w >= 0) { s.w = w; s.ph = 'e'; }
    s.last = Object.assign({ id: s.seq, ms: ms == null ? null : Math.round(ms), sd: s.h[ev.k].length > 5 ? 1 : 0, w }, ev);
    return s;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const ac = actor(s), acts = ac == null ? [] : Array.isArray(ac) ? ac : [ac];
    if (!acts.includes(seat)) throw new Error('not your turn');
    const k = kicker(s), g = 1 - k;
    if (a.type === 'react') {
      if (s.ph !== 'r' || seat !== g) throw new Error('bad react');
      const ms = typeof a.ms === 'number' && isFinite(a.ms) ? U.clamp(a.ms, -1, 3000) : 3000;
      return finish(s, resolve(s, rbFrom(ms)), ms);
    }
    if (s.ph !== 'c') throw new Error('not choosing');
    if (a.type === 'kick') {
      if (seat !== k || s.kc != null) throw new Error('bad kick');
      const z = a.z, pw = a.pw, cv = a.cv;
      if (!Number.isInteger(z) || z < 0 || z > 8 || typeof pw !== 'number' || !isFinite(pw) || typeof cv !== 'number' || !isFinite(cv)) throw new Error('bad kick');
      s.kc = enc({ z, pw: r2(U.clamp(pw, 0.2, 1.3)), cv: r2(U.clamp(cv, -1, 1)) });
    } else if (a.type === 'dive') {
      if (seat !== g || s.gc != null) throw new Error('bad dive');
      if (!Number.isInteger(a.d) || a.d < 0 || a.d > 5) throw new Error('bad dive');
      s.gc = enc({ d: a.d });
    } else throw new Error('bad action');
    if (s.kc != null && s.gc != null) {
      if (s.ro && !s.ai[g]) { s.ph = 'r'; s.seq++; return s; }
      let rb = RB0, ms = null;
      if (s.ro) { const p = AIMS[s.lv[g]] || AIMS[2]; ms = p[0] + gauss() * p[1]; rb = rbFrom(ms); }
      return finish(s, resolve(s, rb), ms);
    }
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const w = s.w, o = 1 - w, gw = goals(s.h[w]), go = goals(s.h[o]);
    const sd = s.h[0].length > 5 || s.h[1].length > 5;
    const fmt = (str) => str.replace(/o/g, '●').replace(/x/g, '×');
    return { winners: [w], title: (s.nm[w] || (w + 1) + '번') + ' 승리', text: gw + ' : ' + go + (sd ? ' (서든데스)' : '') + '\n' +
      (s.nm[0] || '1번') + '  ' + fmt(s.h[0]) + '\n' + (s.nm[1] || '2번') + '  ' + fmt(s.h[1]) };
  }

  /* ---------- AI ---------- */
  function pickW(w) { let t = 0; for (const x of w) t += x; let r = Math.random() * t; for (let i = 0; i < w.length; i++) { r -= w[i]; if (r <= 0) return i; } return w.length - 1; }
  function aiKick(s, seat, lv) {
    let W;
    if (lv === 1) W = [1, 1.2, 1, 1, 1.6, 1, 0.9, 1, 0.9];
    else if (lv === 3) W = [1.9, 0.35, 1.9, 0.8, 0.25, 0.8, 1.35, 0.3, 1.35];
    else W = [1.6, 0.6, 1.6, 1, 0.45, 1, 1.1, 0.4, 1.1];
    if (lv === 3) {
      // read the keeper: shoot where they dive less, and do not repeat the last side every time
      const dh = s.dh[1 - seat]; let l = 1, r = 1, c = 0.6;
      for (const ch of dh) { const d = +ch; if (d <= 1) l++; else if (d >= 4) r++; else c++; }
      const tot = l + r + c, col = [1.6 - l / tot * 1.6, 1.6 - c / tot * 1.6, 1.6 - r / tot * 1.6];
      const last = s.zh[seat].slice(-1);
      for (let z = 0; z < 9; z++) { W[z] *= 0.3 + col[z % 3]; if (last !== '' && (+last) % 3 === z % 3) W[z] *= 0.65; }
      // the shot can wait too: a centre chip against a keeper who always dives
      if (c / tot < 0.12 && dh.length >= 3) W[4] += 0.6;
    }
    const z = pickW(W);
    let pw = lv === 1 ? 0.45 + Math.random() * 0.75 : lv === 3 ? 0.8 + Math.random() * 0.2 : 0.7 + Math.random() * 0.35;
    if (lv === 3 && z >= 6) pw = Math.min(pw, 0.95);
    let cv = lv === 1 ? 0 : (Math.random() - 0.5) * (lv === 3 ? 0.5 : 0.4);
    if (lv === 3 && z % 3 !== 1) cv = Math.abs(cv) * (z % 3 === 0 ? -1 : 1);
    return { type: 'kick', z, pw: r2(pw), cv: r2(cv) };
  }
  function aiDive(s, seat, lv) {
    if (lv === 1) return { type: 'dive', d: U.rand(6) };
    if (lv === 2) {
      const side = Math.random();
      if (side < 0.18) return { type: 'dive', d: Math.random() < 0.5 ? 2 : 3 };
      return { type: 'dive', d: (side < 0.59 ? 0 : 4) + (Math.random() < 0.5 ? 0 : 1) };
    }
    // 어려움: read the kicker's history (recent kicks weigh more)
    const zh = s.zh[1 - seat];
    const col = [1.3, 0.55, 1.3], row = [1, 1];
    for (let i = 0; i < zh.length; i++) {
      const z = +zh[i], wgt = 0.6 + 0.4 * (i + 1) / zh.length;
      col[z % 3] += 1.4 * wgt;
      row[Math.floor(z / 3) === 0 ? 0 : 1] += wgt;
    }
    // kickers that just went one way often switch
    const last = zh.slice(-1);
    if (last !== '' && Math.random() < 0.35) col[(+last) % 3] *= 0.6;
    const c = pickW(col.map((x) => x * x)), hi = Math.random() < row[1] / (row[0] + row[1]) ? 1 : 0;
    return { type: 'dive', d: c * 2 + hi };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'r') { const p = AIMS[lv] || AIMS[2]; return { type: 'react', ms: Math.round(p[0] + gauss() * p[1]) }; }
    if (s.ph !== 'c') return null;
    const k = kicker(s);
    if (seat === k && s.kc == null) return aiKick(s, seat, lv);
    if (seat === 1 - k && s.gc == null) return aiDive(s, seat, lv);
    return null;
  }
  function aiDelayFor(s, seat, lv) { return s.ph === 'r' ? 900 : (lv === 1 ? 1100 : lv === 3 ? 600 : 850) + U.rand(500); }

  /* ---------- deterministic replay paths (view) ---------- */
  function flight(l) {
    const T = SPOT / l.v;
    const hump = l.z >= 6 ? 0.25 : 0.5 * (1.2 - Math.min(1, l.pw));
    const pre = (t) => { const u = t / T; return [l.x * u + l.cv * 1.2 * Math.sin(Math.PI * u), BR + (l.y - BR) * u + hump * 4 * u * (1 - u), SPOT * (1 - u)]; };
    const a = pre(T - 0.002), b = pre(T);
    const vin = [(b[0] - a[0]) / 0.002, (b[1] - a[1]) / 0.002, (b[2] - a[2]) / 0.002];
    const pts = [];
    const p = b.slice();
    let v = vin.slice();
    const sx = Math.sign(l.x) || 1, dv = DV[l.d];
    if (l.r === 'G' || l.r === 'I') { v = [l.r === 'I' ? -sx * 3 : v[0] * 0.5, v[1] * 0.4, v[2] * 0.6]; }
    else if (l.r === 'S') {
      if (l.c) v = [0, 0, 0];
      else { const away = dv.cx === 0 ? (l.x >= 0 ? 1 : -1) : Math.sign(dv.cx); v = [away * 4.5, 3 + (l.y > 1.2 ? 1.5 : 0), 6.5]; }
    } else if (l.r === 'P') {
      if (l.hb) v = l.y > GH + PR ? [v[0] * 0.3, 4, -3] : [v[0] * 0.3, -3, 8];
      else v = [sx * 4, 1.5, 8.5];
    }
    // secondary motion: gravity, ground bounce, net catch
    const DT = 1 / 240;
    let caught = 0;
    for (let i = 0; i < 1.6 / DT; i++) {
      if (!(l.r === 'S' && l.c)) {
        v[1] -= 9.81 * DT;
        p[0] += v[0] * DT; p[1] += v[1] * DT; p[2] += v[2] * DT;
        if (p[1] < BR) { p[1] = BR; v[1] = -v[1] * 0.4; v[0] *= 0.85; v[2] *= 0.85; }
        if ((l.r === 'G' || l.r === 'I') && !caught) {
          const nz = -1.0 - (1 - Math.min(1, p[1] / GH)) * 1.0 + 0.15;
          if (p[2] < nz) { p[2] = nz; caught = 1; v = [v[0] * 0.25, Math.min(v[1], 0) * 0.3, 0.6]; }
          if (Math.abs(p[0]) > GW - BR) { p[0] = Math.sign(p[0]) * (GW - BR); v[0] *= -0.3; }
        }
        if (caught) { v[2] *= 0.9; if (p[2] > -0.6) v[2] = 0; }
      }
      if (i % 4 === 0) pts.push([p[0], p[1], p[2]]);
    }
    return { T, pre, post: pts, at(t) { if (t <= T) return pre(Math.max(0, t)); const i = Math.min(pts.length - 1, Math.floor((t - T) * 60)); return pts[i]; } };
  }
  function keeperPose(l, fl, t) {
    // returns {cx, cy, th, k} at time t since strike; k = dive progress
    const D = DV[l.d];
    let hx = D.hx, hy = D.hy;
    if (l.r === 'S') { hx = l.x; hy = l.y; }
    const Dd = l.r === 'S' ? Math.max(0.2, Math.min(0.5, fl.T)) : 0.5;
    let k = U.clamp((t + 0.04) / Dd, 0, 1);
    k = k * k * (3 - 2 * k);
    return { hx, hy, th: D.th, k, d: l.d };
  }
  const EVT = { G: ['골!', '#5fd3a0'], I: ['골대 맞고 골!', '#5fd3a0'], S: ['선방!', '#5bb3e6'], P: ['골대!', '#e3ae45'], O: ['크로스바 위로…', '#ab9fb8'], W: ['빗나갔어요', '#ab9fb8'] };

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = L.h('div', { class: 'hud top pk-top', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px', alignItems: 'stretch' } });
    root.append(top);
    // invisible boxes over the goal / ball for the first-play tutorial spotlight
    const spGoal = tutSpot(root, 'pk-goal'), spBall = tutSpot(root, 'pk-ball');
    let st = null, time = 0, anim = null, flash = null, hudKey = '', overlayEl = null, revealed = -1, revKey = '';
    let ptr = null, sent = {}, hintFlash = 0, cueAt = 0, reactSent = -1, reactTimer = 0, endTimer = 0;
    const tries = {};
    const V = { W: 1, H: 1, F: 600, hy: 100, Cy: 3, Cz: SPOT + 11, topH: 84 };
    const color = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const crowd = []; { let sd = 11; const rnd = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
      for (let i = 0; i < 520; i++) crowd.push({ x: -26 + rnd() * 52, y: 0.6 + rnd() * 9, c: ['#4a3556', '#2f2740', '#56402f', '#334058', '#5e4a2a', '#6a2f3a'][Math.floor(rnd() * 6)], k: 0.75 + rnd() * 0.5, ph: rnd() * 6 }); }

    function layout() {
      const W = cv.w, H = cv.h;
      V.W = W; V.H = H;
      V.F = Math.min(W * 0.86 * V.Cz / (2 * (GW + 0.4)), H * 2.4);
      // goal top just under the status pill, penalty spot ~170px above the bottom edge
      const A = V.topH + 58, B = H - U.clamp(H * 0.24, 130, 190), dS = V.Cz - SPOT;
      V.Cy = U.clamp(((B - A) / V.F - (GH + 0.1) / V.Cz) / (1 / dS - 1 / V.Cz), 1.2, 7);
      V.hy = A + V.F * (GH + 0.1 - V.Cy) / V.Cz;
    }
    function P(x, y, z) { const d = V.Cz - z; if (d < 0.3) return null; return [V.W / 2 + V.F * x / d, V.hy - V.F * (y - V.Cy) / d, V.F / d]; }
    function poly(pts, fill, stroke, lw) {
      ctx.beginPath(); let ok = 0;
      for (const q of pts) { const s = P(q[0], q[1], q[2]); if (!s) continue; ok++ ? ctx.lineTo(s[0], s[1]) : ctx.moveTo(s[0], s[1]); }
      if (ok < 3) return; ctx.closePath();
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
    }
    function line3(pts, wm, col) {
      ctx.strokeStyle = col; ctx.lineCap = 'round';
      for (let i = 0; i + 1 < pts.length; i++) {
        const a = P(...pts[i]), b = P(...pts[i + 1]); if (!a || !b) continue;
        ctx.lineWidth = Math.max(0.7, wm * (a[2] + b[2]) / 2);
        ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
      }
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }

    /* ---- scene ---- */
    function drawBackdrop() {
      const W = V.W, H = V.H;
      const bg = ctx.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, '#0d0a14'); bg.addColorStop(1, '#1a1424');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      // stands
      poly([[-40, 0, -9], [40, 0, -9], [40, 14, -16], [-40, 14, -16]], '#1c1527');
      for (const c of crowd) {
        const z = -9 - c.y * 0.75, q = P(c.x, c.y + Math.sin(time * 3 + c.ph) * 0.03 * (flash && flash.t > 0 ? 6 : 1), z); if (!q) continue;
        ctx.fillStyle = c.c; ctx.beginPath(); ctx.arc(q[0], q[1], Math.max(1, 0.22 * c.k * q[2]), 0, 7); ctx.fill();
      }
      // floodlight glow
      const lg = ctx.createRadialGradient(W / 2, 0, 0, W / 2, 0, W);
      lg.addColorStop(0, 'rgba(255,236,190,.12)'); lg.addColorStop(1, 'rgba(255,236,190,0)');
      ctx.fillStyle = lg; ctx.fillRect(0, 0, W, H * 0.6);
    }
    function drawPitch() {
      // grass with mowing stripes (bands across the field)
      for (let i = -3; i < 12; i++) {
        const z0 = 30 - i * 3.2, z1 = z0 - 3.2;
        poly([[-40, 0, Math.min(z0, V.Cz - 0.5)], [40, 0, Math.min(z0, V.Cz - 0.5)], [40, 0, z1], [-40, 0, z1]], i % 2 ? '#1f6b45' : '#237a4f');
      }
      poly([[-40, 0, -3.2], [40, 0, -3.2], [40, 0, -9], [-40, 0, -9]], '#1a5a3a');
      // ad boards
      poly([[-30, 0, -6], [30, 0, -6], [30, 0.9, -6], [-30, 0.9, -6]], '#3b2450');
      poly([[-30, 0.84, -5.99], [30, 0.84, -5.99], [30, 0.9, -5.99], [-30, 0.9, -5.99]], '#e3ae45');
      for (const bx of [-16, -8, 0, 8, 16]) {
        const q = P(bx, 0.42, -5.98); if (!q) continue;
        ctx.font = '400 ' + Math.max(6, Math.round(0.5 * q[2])) + 'px "Black Han Sans", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(242,233,216,.8)';
        ctx.fillText(bx % 16 === 0 ? '한판 라운지' : '승부차기', q[0], q[1]);
      }
      const LC = 'rgba(245,240,228,.85)', LW = 0.07;
      line3([[-30, 0, 0], [30, 0, 0]], LW, LC);
      line3([[-9.16, 0, 0], [-9.16, 0, 5.5], [9.16, 0, 5.5], [9.16, 0, 0]], LW, LC);
      line3([[-20.16, 0, 0], [-20.16, 0, 16.5], [20.16, 0, 16.5], [20.16, 0, 0]], LW, LC);
      const arc = []; const a0 = Math.acos(5.5 / 9.15);
      for (let i = 0; i <= 24; i++) { const t = -a0 + (2 * a0) * i / 24; arc.push([9.15 * Math.sin(t), 0, SPOT + 9.15 * Math.cos(t)]); }
      line3(arc, LW, LC);
      const sp = P(0, 0, SPOT); if (sp) { ctx.fillStyle = LC; ctx.beginPath(); ctx.ellipse(sp[0], sp[1], 0.14 * sp[2], 0.05 * sp[2], 0, 0, 7); ctx.fill(); }
    }
    /* net as a grid; dent pushes points back where the ball hits */
    function netPt(x, y, side, dent) {
      // back plane: bottom at z=-2, top at z=-1 (y = GH)
      let z = -2 + (y / GH) * 1.0;
      if (side) z = side;
      if (dent) { const dx = x - dent[0], dy = y - dent[1], f = Math.exp(-(dx * dx + dy * dy) / 0.35); z -= f * dent[2]; }
      return [x, y, z];
    }
    function drawNet(dent) {
      ctx.strokeStyle = 'rgba(240,236,228,.32)'; ctx.lineWidth = 1;
      const nx = 24, ny = 8;
      for (let i = 0; i <= nx; i++) { // back verticals
        const x = -GW + 2 * GW * i / nx; ctx.beginPath(); let f = 0;
        for (let j = 0; j <= ny; j++) { const q = P(...netPt(x, GH * j / ny, 0, dent)); if (!q) continue; f++ ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }
        ctx.stroke();
      }
      for (let j = 0; j <= ny; j++) {
        const y = GH * j / ny; ctx.beginPath(); let f = 0;
        for (let i = 0; i <= nx; i++) { const q = P(...netPt(-GW + 2 * GW * i / nx, y, 0, dent)); if (!q) continue; f++ ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }
        ctx.stroke();
      }
      // roof and sides
      for (let i = 0; i <= nx; i += 2) { const x = -GW + 2 * GW * i / nx; line3([[x, GH, 0], netPt(x, GH, 0, dent)], 0.012, 'rgba(240,236,228,.28)'); }
      for (const sx of [-GW, GW]) for (let j = 0; j <= ny; j += 2) { const y = GH * j / ny; line3([[sx, y, 0], netPt(sx, y, 0, null)], 0.012, 'rgba(240,236,228,.25)'); }
      for (const sx of [-GW, GW]) line3([[sx, 0, 0], [sx, 0, -2], [sx, GH, -1], [sx, GH, 0]], 0.03, 'rgba(240,236,228,.45)');
    }
    function drawFrame() {
      const a = P(-GW - PR, 0, 0), b = P(-GW - PR, GH + PR, 0), c = P(GW + PR, GH + PR, 0), d = P(GW + PR, 0, 0);
      if (!a || !b || !c || !d) return;
      const w = Math.max(3, 2 * PR * a[2]);
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = w + 2;
      ctx.beginPath(); ctx.moveTo(a[0] + 2, a[1]); ctx.lineTo(b[0] + 2, b[1] + 2); ctx.lineTo(c[0] + 2, c[1] + 2); ctx.lineTo(d[0] + 2, d[1]); ctx.stroke();
      ctx.strokeStyle = '#f6f2ea'; ctx.lineWidth = w;
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.stroke();
    }
    function drawZones(hl, alpha) {
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) {
        const z = r * 3 + c;
        const x0 = -GW + c * (2 * GW / 3), x1 = x0 + 2 * GW / 3, y0 = r * GH / 3, y1 = y0 + GH / 3;
        const on = z === hl;
        poly([[x0 + 0.05, y0 + 0.04, 0.02], [x1 - 0.05, y0 + 0.04, 0.02], [x1 - 0.05, y1 - 0.04, 0.02], [x0 + 0.05, y1 - 0.04, 0.02]],
          on ? 'rgba(227,174,69,' + (0.42 * alpha) + ')' : 'rgba(242,233,216,' + (0.06 * alpha) + ')', on ? 'rgba(227,174,69,' + alpha + ')' : 'rgba(242,233,216,' + (0.28 * alpha) + ')', on ? 2 : 1);
      }
    }
    /* keeper: hips at (cx, cy) rotated by th; arms interpolate from ready to stretched */
    function drawKeeper(seat, pose, alpha) {
      const col = color(seat);
      let cx, cy, th, armUp, crouch = 0;
      const sway = Math.sin(time * 5) * 0.06;
      if (!pose) { cx = sway; cy = 0.95; th = 0; armUp = 0; }
      else {
        const k = pose.k, D = DV[pose.d], side = D.cx !== 0;
        const thE = D.th * DEG, ux = Math.sin(thE), uy = Math.cos(thE);
        let ex, ey;
        if (pose.d === 2) { ex = pose.hx; ey = 0.62; crouch = 1; }
        else { ex = pose.hx - ux * 1.12; ey = pose.hy - uy * 1.12; }
        if (side) ey = Math.max(0.25, ey);
        cx = U.lerp(sway, ex, k); cy = U.lerp(0.95, Math.max(ey, side ? 0.25 : 0.5), k); th = thE * k; armUp = k; crouch *= k;
      }
      const z = 0.3;
      const rot = (lx, ly) => [cx + lx * Math.cos(th) + ly * Math.sin(th), cy - lx * Math.sin(th) + ly * Math.cos(th)];
      const S = (lx, ly) => { const w = rot(lx, ly); return P(w[0], w[1], z); };
      const sh = P(cx, 0, z);
      ctx.globalAlpha = alpha;
      if (sh) { ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(sh[0], sh[1], 0.5 * sh[2], 0.1 * sh[2], 0, 0, 7); ctx.fill(); }
      const seg = (a, b, w, c) => { const p = S(...a), q = S(...b); if (!p || !q) return; ctx.strokeStyle = c; ctx.lineWidth = w * p[2]; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke(); };
      const kneeOut = 0.12 + crouch * 0.18;
      // legs
      seg([-0.11, 0], [-kneeOut, -0.45 + crouch * 0.1], 0.15, '#2a2233'); seg([-kneeOut, -0.45 + crouch * 0.1], [-0.14 - crouch * 0.1, -0.92 + crouch * 0.3], 0.13, '#2a2233');
      seg([0.11, 0], [kneeOut, -0.45 + crouch * 0.1], 0.15, '#2a2233'); seg([kneeOut, -0.45 + crouch * 0.1], [0.14 + crouch * 0.1, -0.92 + crouch * 0.3], 0.13, '#2a2233');
      // torso
      seg([0, 0.02], [0, 0.55], 0.36, col);
      // arms: ready (out & down) → stretched (overhead)
      const ra = [U.lerp(0.5, 0.2, armUp), U.lerp(0.25, 1.1, armUp)], la = [U.lerp(-0.5, -0.2, armUp), U.lerp(0.25, 1.1, armUp)];
      if (crouch > 0.5) { ra[0] = 0.55; ra[1] = 0.05; la[0] = -0.55; la[1] = 0.05; }
      seg([0.16, 0.5], ra, 0.11, col); seg([-0.16, 0.5], la, 0.11, col);
      for (const hnd of [ra, la]) { const p = S(...hnd); if (p) { ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(p[0], p[1], 0.085 * p[2], 0, 7); ctx.fill(); } }
      const hd = S(0, 0.74); if (hd) { ctx.fillStyle = '#c99a72'; ctx.beginPath(); ctx.arc(hd[0], hd[1], 0.12 * hd[2], 0, 7); ctx.fill(); ctx.fillStyle = '#2b1d14'; ctx.beginPath(); ctx.arc(hd[0], hd[1] - 0.03 * hd[2], 0.12 * hd[2], Math.PI, 0); ctx.fill(); }
      ctx.globalAlpha = 1;
    }
    /* kicker seen from behind; run (0..1) and kick (0..1) progress */
    function drawKicker(seat, run, kick, alpha) {
      const e = run * run * (3 - 2 * run);
      const x = U.lerp(-1.25, -0.45, e), z = U.lerp(12.6, 11.3, e);
      const f = P(x, 0, z); if (!f) return;
      const s = f[2], col = color(seat);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(f[0], f[1], 0.35 * s, 0.08 * s, 0, 0, 7); ctx.fill();
      const ph = run < 1 ? run * 9 : 0, sw = Math.sin(ph * Math.PI) * 0.18 * (run < 1 ? 1 : 0);
      const X = (dx) => f[0] + dx * s, Y = (dy) => f[1] - dy * s;
      ctx.lineCap = 'round';
      // legs (right leg kicks)
      const kickA = kick > 0 ? Math.sin(Math.min(1, kick) * Math.PI) : 0;
      ctx.strokeStyle = '#e8e2d4'; ctx.lineWidth = 0.13 * s;
      ctx.beginPath(); ctx.moveTo(X(-0.1), Y(0.9)); ctx.lineTo(X(-0.12 + sw), Y(0.05)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(X(0.1), Y(0.9)); ctx.lineTo(X(0.12 - sw + kickA * 0.2), Y(0.05 + kickA * 0.35)); ctx.stroke();
      ctx.strokeStyle = '#18121f'; ctx.lineWidth = 0.15 * s;
      ctx.beginPath(); ctx.moveTo(X(-0.12 + sw), Y(0.12)); ctx.lineTo(X(-0.12 + sw), Y(0.02)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(X(0.12 - sw + kickA * 0.2), Y(0.12 + kickA * 0.35)); ctx.lineTo(X(0.12 - sw + kickA * 0.24), Y(0.02 + kickA * 0.35)); ctx.stroke();
      // shorts + jersey
      ctx.fillStyle = '#1d1828'; rr(X(-0.2), Y(1.02), 0.4 * s, 0.24 * s, 0.05 * s); ctx.fill();
      ctx.fillStyle = col; rr(X(-0.23), Y(1.55), 0.46 * s, 0.56 * s, 0.1 * s); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 0.1 * s;
      ctx.beginPath(); ctx.moveTo(X(-0.22), Y(1.45)); ctx.lineTo(X(-0.36 - sw * 0.5), Y(1.05)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(X(0.22), Y(1.45)); ctx.lineTo(X(0.36 + sw * 0.5 + kickA * 0.15), Y(1.12 + kickA * 0.2)); ctx.stroke();
      ctx.fillStyle = 'rgba(23,19,31,.75)'; ctx.font = '700 ' + Math.max(8, Math.round(0.24 * s)) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(seat + 7 + (st ? st.h[seat].length % 3 : 0)), X(0), Y(1.28));
      ctx.fillStyle = '#b98a63'; ctx.beginPath(); ctx.arc(X(0), Y(1.68), 0.12 * s, 0, 7); ctx.fill();
      ctx.fillStyle = '#231710'; ctx.beginPath(); ctx.arc(X(0), Y(1.7), 0.122 * s, 0, 7); ctx.fill();
      ctx.globalAlpha = 1;
    }
    function drawBall(p, rot) {
      const c = P(p[0], p[1], p[2]); if (!c) return null;
      const r = Math.max(2.5, BR * c[2]);
      const sh = P(p[0], 0, p[2]);
      if (sh) { ctx.fillStyle = 'rgba(0,0,0,' + U.clamp(0.4 - p[1] * 0.08, 0.06, 0.4) + ')'; ctx.beginPath(); ctx.ellipse(sh[0], sh[1], r * 1.1, r * 0.35, 0, 0, 7); ctx.fill(); }
      const g = ctx.createRadialGradient(c[0] - r * 0.35, c[1] - r * 0.4, r * 0.1, c[0], c[1], r);
      g.addColorStop(0, '#ffffff'); g.addColorStop(0.7, '#e9e3d6'); g.addColorStop(1, '#9d968a');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(c[0], c[1], r, 0, 7); ctx.fill();
      ctx.save(); ctx.beginPath(); ctx.arc(c[0], c[1], r, 0, 7); ctx.clip();
      ctx.fillStyle = '#3b2450';
      for (let i = 0; i < 5; i++) {
        const a = rot + i * 2 * Math.PI / 5, px = c[0] + Math.cos(a) * r * 0.62, py = c[1] + Math.sin(a) * r * 0.62 * 0.9;
        ctx.beginPath(); ctx.arc(px, py, r * 0.22, 0, 7); ctx.fill();
      }
      ctx.beginPath(); ctx.arc(c[0] + Math.cos(rot * 0.7) * r * 0.1, c[1], r * 0.26, 0, 7); ctx.fill();
      ctx.restore();
      return c;
    }

    /* ---- state helpers ---- */
    const kk = () => (st ? kicker(st) : 0);
    function myPending() {
      if (!st || st.ph !== 'c' || anim) return -1;
      const list = actor(st) || [];
      const mine = list.filter((x) => api.canAct(x) && sent[x] !== st.seq + ':' + x);
      if (!mine.length) return -1;
      if (multi()) return mine[0] === revealed ? mine[0] : -1;
      return mine[0];
    }
    const multi = () => !api.online && api.mySeats().length >= 2;

    /* ---- kicker swipe → kick ---- */
    function ballScreen() { return P(0, BR, SPOT); }
    function goalRect() { const a = P(-GW, GH, 0), b = P(GW, 0, 0); return { x0: a[0], y0: a[1], x1: b[0], y1: b[1] }; }
    const REF_MS = 170;
    function swipeInfo(g) {
      if (!g) return null;
      const b = ballScreen(), gr = goalRect();
      const dx = g.x - g.sx, dy = g.y - g.sy, len = Math.hypot(dx, dy);
      if (len < 26 || dy > -14) return { cancel: true };
      const gcY = (gr.y0 + gr.y1) / 2, ext = (b[1] - gcY) / 120; // ~120px swipe reaches the goal centre
      const tx = b[0] + dx * ext, ty = b[1] + dy * ext;
      const col = tx < (gr.x0 + (gr.x1 - gr.x0) / 3) ? 0 : tx > (gr.x0 + 2 * (gr.x1 - gr.x0) / 3) ? 2 : 1;
      const hgt = U.clamp((gr.y1 - ty) / (gr.y1 - gr.y0), 0, 1.2);
      const row = hgt < 1 / 3 ? 0 : hgt < 2 / 3 ? 1 : 2;
      // power: average swipe speed since the finger started moving
      const el = Math.max(30, (g.lastT - (g.moveT || g.t0)));
      const pw = U.clamp((len / 120) / (el / REF_MS), 0.2, 1.3);
      // curve: biggest sideways bulge of the path relative to its chord
      let dev = 0; const ux = dx / len, uy = dy / len;
      for (const h of g.hist) { const px = h.x - g.sx, py = h.y - g.sy, along = px * ux + py * uy; if (along < 0 || along > len) continue; const perp = px * uy - py * ux; if (Math.abs(perp) > Math.abs(dev)) dev = perp; }
      const rel = dev / len, cvv = Math.abs(rel) < 0.07 ? 0 : U.clamp((Math.abs(rel) - 0.07) / 0.25, 0, 1) * Math.sign(rel);
      return { z: row * 3 + col, tx, ty, pw, cv: Math.round(-cvv * 100) / 100 };
    }
    /* ---- keeper swipe → dive ---- */
    function diveOf(g) {
      if (!g) return null;
      const dx = g.x - g.sx, dy = g.y - g.sy, len = Math.hypot(dx, dy);
      if (len < 34) return { cancel: true };
      if (Math.abs(dx) < len * 0.42) return { d: dy < 0 ? 3 : 2 };
      const hi = dy < -len * 0.18 ? 1 : 0;
      return { d: (dx < 0 ? 0 : 4) + hi };
    }

    /* ---- drawing frame ---- */
    function draw() {
      cv.clear();
      if (!st) return;
      drawBackdrop(); drawPitch();
      const now = performance.now(), sp = L.debug.speed;
      let ballP = [0, BR, SPOT], rot = 0, kpose = null, runP = 0, kickP = 0, kAlpha = 1, dent = null, l = anim && anim.l;
      const k = anim ? anim.k : kk(), g = 1 - k;
      if (anim) {
        const tr = (now - anim.t0) * sp / 1000;
        runP = Math.min(1, tr / RUN);
        if (l && anim.strike != null) {
          const t = (now - anim.strike) * sp / 1000;
          kickP = Math.min(1, t / 0.18 + 0.5);
          ballP = anim.fl.at(t); rot = t * 14;
          kpose = keeperPose(l, anim.fl, t);
          if (t > anim.fl.T && (l.r === 'S' && l.c)) { const hp = kpose; ballP = [hp.hx * 0.92, Math.max(0.6, hp.hy - 0.1), 0.45]; }
          if ((l.r === 'G' || l.r === 'I') && t > anim.fl.T) dent = [ballP[0], ballP[1], Math.min(0.5, (t - anim.fl.T) * 3) * Math.max(0, 1 - (t - anim.fl.T - 0.3) * 1.2)];
          kAlpha = t > 0.25 ? 0.45 : 1;
        } else if (tr >= RUN) kickP = 0.42;
        else kickP = 0;
      }
      drawNet(dent);
      const human = myPending();
      const isKick = human >= 0 && human === k, isKeep = human >= 0 && human === g;
      const sw = isKick && ptr ? swipeInfo(ptr) : null;
      // aim zones: shown for the kicker choosing
      if (isKick) drawZones(sw && !sw.cancel ? sw.z : -1, ptr ? 1 : 0.6);
      const ballBehind = ballP[2] < 0;
      if (ballBehind) drawBall(ballP, rot);
      drawFrame();
      // keeper (ghost of the chosen dive while swiping)
      const dv = isKeep && ptr ? diveOf(ptr) : null;
      drawKeeper(g, kpose, 1);
      if (dv && !dv.cancel) { const D = DV[dv.d]; drawKeeper(g, { k: 0.85, d: dv.d, hx: D.hx, hy: D.hy, th: D.th }, 0.4); }
      if (!ballBehind && ballP[2] < 0.6) drawBall(ballP, rot);
      // kicker & ball near the spot
      if (!ballBehind && ballP[2] >= 0.6) drawBall(ballP, rot);
      if (st.ph !== 'e' || anim) drawKicker(k, runP, kickP, anim ? kAlpha : human === k ? 0.55 : 0.9);
      if (!anim && st.ph === 'r' && api.canAct(g)) hintPill('키커가 차는 순간 "지금!"이 뜨면 바로 탭!', '#e3ae45');
      if (anim && !anim.l && st.ph === 'r' && api.canAct(g) && !cueAt) hintPill('"지금!"이 뜨면 바로 탭!', '#e3ae45');
      // cue for the reaction tap
      if (anim && !anim.l && runP >= 1 && st.ph === 'r') drawCue();
      if (isKick) drawKickUI(sw);
      if (isKeep) drawKeepUI(dv);
      drawFlash();
      drawStatus(human);
      { const r = goalRect(), b = ballScreen(); spGoal(r.x0 - 8, r.y0 - 8, r.x1 - r.x0 + 16, r.y1 - r.y0 + 16); if (b) { const q = BR * b[2] + 22; spBall(b[0] - q, b[1] - q, 2 * q, 2 * q); } else spBall(null); }
    }
    function drawCue() {
      const g = 1 - kk();
      if (!api.canAct(g)) return;
      const b = P(0, 1.2, 0);
      const pulse = 1 + 0.12 * Math.sin(time * 20);
      ctx.font = '400 ' + Math.round(64 * pulse) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText('지금!', V.W / 2, b[1]);
      ctx.fillStyle = '#ee6a55'; ctx.fillText('지금!', V.W / 2, b[1]);
    }
    function hintPill(text, col) {
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const hw = ctx.measureText(text).width + 24;
      ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(V.W / 2 - hw / 2, V.H - 30, hw, 24, 12); ctx.fill();
      ctx.fillStyle = col || '#ab9fb8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(text, V.W / 2, V.H - 17.5);
    }
    function drawKickUI(sw) {
      const b = ballScreen(); if (!b) return;
      const a = kk(), first = (tries['k' + a] || 0) < 2;
      if (sw && !sw.cancel) {
        // reticle at the aimed zone + swipe trail
        const zx = ZX[sw.z % 3], zy = ZY[Math.floor(sw.z / 3)], q = P(zx, zy, 0);
        if (q) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(q[0], q[1], 14, 0, 7); ctx.stroke(); ctx.beginPath(); ctx.moveTo(q[0] - 20, q[1]); ctx.lineTo(q[0] - 8, q[1]); ctx.moveTo(q[0] + 8, q[1]); ctx.lineTo(q[0] + 20, q[1]); ctx.moveTo(q[0], q[1] - 20); ctx.lineTo(q[0], q[1] - 8); ctx.moveTo(q[0], q[1] + 8); ctx.lineTo(q[0], q[1] + 20); ctx.stroke(); }
        ctx.strokeStyle = 'rgba(242,233,216,.55)'; ctx.lineWidth = 5; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(ptr.hist[0].x, ptr.hist[0].y); for (const h of ptr.hist) ctx.lineTo(h.x, h.y); ctx.stroke();
      }
      // power gauge
      const gx = Math.min(V.W - 24, b[0] + 70), gy1 = b[1] + 10, gh = 110, gy0 = gy1 - gh;
      ctx.fillStyle = 'rgba(23,19,31,.75)'; rr(gx - 7, gy0, 14, gh, 7); ctx.fill();
      const yOf = (p) => gy1 - gh * (p - 0.2) / 1.1;
      ctx.fillStyle = 'rgba(95,211,160,.8)'; ctx.fillRect(gx - 7, yOf(1.0), 14, yOf(0.72) - yOf(1.0));
      ctx.fillStyle = 'rgba(238,106,85,.55)'; ctx.fillRect(gx - 7, gy0, 14, yOf(1.05) - gy0);
      if (sw && !sw.cancel) { ctx.fillStyle = sw.pw > 1.05 ? '#ee6a55' : sw.pw >= 0.72 ? '#5fd3a0' : '#e3ae45'; const fy = yOf(sw.pw); rr(gx - 4, fy, 8, gy1 - fy, 4); ctx.fill(); }
      ctx.strokeStyle = 'rgba(242,233,216,.4)'; ctx.lineWidth = 1; rr(gx - 7, gy0, 14, gh, 7); ctx.stroke();
      ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ab9fb8';
      ctx.fillText('파워', gx, gy1 + 10);
      if (!ptr) {
        ctx.strokeStyle = 'rgba(227,174,69,' + (0.4 + 0.3 * Math.sin(time * 4)) + ')'; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
        for (let i = 0; i < 2; i++) { const yy = b[1] - 16 - i * 9 + Math.sin(time * 4) * 2; ctx.beginPath(); ctx.moveTo(b[0] - 8, yy); ctx.lineTo(b[0], yy - 6); ctx.lineTo(b[0] + 8, yy); ctx.stroke(); }
        if (first) { // ghost finger flicking toward a corner
          const t = (time % 1.8) / 1.8, e = Math.min(1, t / 0.5), ex = b[0] + 46 * e, ey = b[1] - 110 * e;
          ctx.globalAlpha = t < 0.8 ? 0.85 : Math.max(0, 1 - (t - 0.8) / 0.2);
          ctx.fillStyle = 'rgba(255,248,230,.9)'; ctx.beginPath(); ctx.arc(ex, ey, 11, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
        }
      }
      let t, c = '#ab9fb8';
      if (!ptr) { t = hintFlash > 0 ? '공에서 시작해 골문 쪽으로 쓸어 올리세요' : '공을 노릴 곳으로 쓸어 차기 · 빠르게 = 세게'; if (hintFlash > 0) c = '#ee6a55'; }
      else if (!sw || sw.cancel) { t = '여기서 놓으면 취소'; c = '#ee6a55'; }
      else { t = ZN[sw.z] + ' · 파워 ' + Math.round(sw.pw * 100) + '%' + (sw.cv ? ' · 감아차기' : ''); c = sw.pw > 1.05 ? '#ee6a55' : sw.pw >= 0.72 ? '#5fd3a0' : '#e3ae45'; }
      hintPill(t, c);
    }
    function drawKeepUI(dv) {
      const g = 1 - kk(), first = (tries['g' + g] || 0) < 2;
      if (!ptr) {
        // six arrows around the keeper
        const c = P(0, 1.1, 0.3); if (!c) return;
        const s = c[2];
        ctx.strokeStyle = 'rgba(227,174,69,' + (0.45 + 0.3 * Math.sin(time * 4)) + ')'; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const arrows = [[-1.6, -0.5], [-1.6, 0.6], [1.6, -0.5], [1.6, 0.6], [0, 1.6], [0, -1.05]];
        for (const [ax, ay] of arrows) {
          const x0 = c[0] + ax * s * 0.65, y0 = c[1] - ay * s * 0.65, x1 = c[0] + ax * s, y1 = c[1] - ay * s;
          const an = Math.atan2(y1 - y0, x1 - x0);
          ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1);
          ctx.moveTo(x1 - 8 * Math.cos(an - 0.5), y1 - 8 * Math.sin(an - 0.5)); ctx.lineTo(x1, y1); ctx.lineTo(x1 - 8 * Math.cos(an + 0.5), y1 - 8 * Math.sin(an + 0.5)); ctx.stroke();
        }
        if (first) {
          const t = (time % 1.8) / 1.8, e = Math.min(1, t / 0.5);
          ctx.globalAlpha = t < 0.8 ? 0.85 : Math.max(0, 1 - (t - 0.8) / 0.2);
          ctx.fillStyle = 'rgba(255,248,230,.9)'; ctx.beginPath(); ctx.arc(V.W / 2 - 90 * e, V.H * 0.62 - 40 * e, 11, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
        }
        hintPill(hintFlash > 0 ? '화면 아무 데서나 다이빙할 쪽으로 쓸어 주세요' : '다이빙할 쪽으로 쓸기 (6방향)', hintFlash > 0 ? '#ee6a55' : '#ab9fb8');
        return;
      }
      ctx.strokeStyle = 'rgba(242,233,216,.55)'; ctx.lineWidth = 5; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(ptr.sx, ptr.sy); ctx.lineTo(ptr.x, ptr.y); ctx.stroke();
      if (!dv || dv.cancel) hintPill('여기서 놓으면 취소', '#ee6a55');
      else hintPill(DV[dv.d].n + '(으)로 다이빙 · 놓으면 확정', '#5fd3a0');
    }
    function drawFlash() {
      if (!flash) return;
      const k = (performance.now() - flash.t0) / (1400 / Math.sqrt(L.debug.speed));
      if (k >= 1) { flash = null; return; }
      ctx.globalAlpha = k < 0.1 ? k / 0.1 : 1 - Math.max(0, (k - 0.7) / 0.3);
      const gb = P(0, 0, 0), y = (gb ? gb[1] : V.H * 0.45) + 64, sc = 1 + (1 - Math.min(1, k * 4)) * 0.2;
      ctx.font = '400 ' + Math.round(42 * sc) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, V.W / 2, y);
      ctx.fillStyle = flash.c; ctx.fillText(flash.text, V.W / 2, y);
      if (flash.sub) { ctx.font = '700 14px "IBM Plex Sans KR", sans-serif'; ctx.lineWidth = 4; ctx.strokeText(flash.sub, V.W / 2, y + 36); ctx.fillStyle = '#f2e9d8'; ctx.fillText(flash.sub, V.W / 2, y + 36); }
      ctx.globalAlpha = 1;
    }
    function drawStatus(human) {
      const s = anim && anim.hud ? anim.hud : st;
      if (!s || s.ph === 'e' && !anim) return;
      const k = anim ? anim.k : kicker(s), n = s.h[k].length + 1;
      let t = n > 5 ? '서든데스 ' + (n - 5) + '라운드' : n + '번째 키커';
      t += ' · ' + (api.players[k] ? api.players[k].name : '') + ' 슛';
      let sub = '';
      if (!anim && s.ph === 'c') {
        const g = 1 - k;
        const kd = s.kc != null, gd = s.gc != null;
        if (human < 0) sub = '키커 ' + (kd ? '준비 완료' : '고르는 중') + ' · 골키퍼 ' + (gd ? '준비 완료' : '고르는 중');
        else if (human === k && gd) sub = '골키퍼 준비 완료';
        else if (human === g && kd) sub = '키커 준비 완료';
      } else if (!anim && s.ph === 'r') sub = '골키퍼 반응 중…';
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const tw = Math.max(ctx.measureText(t).width, sub ? ctx.measureText(sub).width : 0) + 24;
      const y0 = V.topH + 4, hh = sub ? 40 : 24;
      ctx.fillStyle = 'rgba(18,14,24,.78)'; rr(V.W / 2 - tw / 2, y0, tw, hh, 12); ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
      ctx.fillText(t, V.W / 2, y0 + 12.5);
      if (sub) { ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText(sub, V.W / 2, y0 + 28); }
    }

    /* ---- HUD ---- */
    function renderTop() {
      const s = anim && anim.hud ? anim.hud : st;
      if (!s) return;
      const k = anim ? anim.k : kicker(s);
      const key = JSON.stringify([s.h, k, s.ph]);
      if (key === hudKey) return;
      hudKey = key;
      top.innerHTML = '';
      for (const i of [s.fs, 1 - s.fs]) {
        const p = api.players[i] || { name: '', color: '#fff' }, kick = s.ph !== 'e' && i === k;
        const str = s.h[i], dots = [];
        for (let j = 0; j < 5; j++) {
          const c = str[j];
          dots.push(L.h('span', { style: { width: '13px', height: '13px', borderRadius: '50%', flex: 'none', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', lineHeight: 1, color: 'var(--coral)', fontWeight: 700,
            background: c === 'o' ? p.color : 'transparent', border: '1.5px solid ' + (c ? 'rgba(242,233,216,.6)' : 'rgba(242,233,216,.25)') }, text: c === 'x' ? '×' : '' }));
        }
        const sd = str.slice(5);
        if (sd) dots.push(L.h('span', { class: 'mono', style: { fontSize: '11px', color: 'var(--brass)', marginLeft: '3px', whiteSpace: 'nowrap', overflow: 'hidden' }, text: sd.replace(/o/g, '●').replace(/x/g, '×').slice(-4) }));
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '6px 8px', display: 'flex', flexDirection: 'column', gap: '4px', borderColor: kick ? p.color : '', boxShadow: kick ? '0 0 0 1px ' + p.color + ' inset' : '' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
            L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto', minWidth: 0 }, text: p.name }),
            s.ph !== 'e' ? L.h('span', { class: 'tag', style: { flex: 'none', color: kick ? 'var(--brass)' : 'var(--muted)' }, text: kick ? '키커' : 'GK' }) : null),
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
            L.h('div', { class: 'mono', style: { fontSize: '26px', fontWeight: 600, lineHeight: 1 }, text: String(goals(str)) }),
            L.h('div', { style: { display: 'flex', gap: '3px', alignItems: 'center', minWidth: 0, flexWrap: 'nowrap' } }, dots))));
      }
      requestAnimationFrame(() => { const h = top.getBoundingClientRect().height; if (h && Math.abs(h + 4 - V.topH) > 1) { V.topH = h + 4; layout(); } });
    }

    /* ---- hand-over screen for two people on one phone ---- */
    function syncOverlay() {
      const want = (() => {
        if (!st || !multi() || st.ph !== 'c' || anim) return -1;
        const list = (actor(st) || []).filter((x) => api.canAct(x) && sent[x] !== st.seq + ':' + x);
        if (!list.length) return -1;
        return list[0] === revealed ? -1 : list[0];
      })();
      const key = want + ':' + (st ? st.seq : 0);
      if (key === revKey) return;
      revKey = key;
      if (overlayEl) { overlayEl.remove(); overlayEl = null; }
      if (want < 0) return;
      const p = api.players[want], role = want === kicker(st) ? '키커 · 차기' : '골키퍼 · 막기';
      overlayEl = L.h('div', { class: 'overlay pk-hand' },
        L.h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px', textAlign: 'center' } },
          L.h('span', { class: 'dot', style: { '--c': p.color, width: '18px', height: '18px' } }),
          L.h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '34px' }, text: p.name }),
          L.h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: role }),
          L.h('div', { class: 'muted', text: '다른 사람은 보지 마세요' }),
          L.h('button', { class: 'btn primary', text: '준비됐어요', onclick: () => { revealed = want; api.sfx('click'); syncOverlay(); } })));
      root.append(overlayEl);
    }

    /* ---- animation control ---- */
    function startRun(k, l, prevSt) {
      clearTimeout(endTimer);
      anim = { k, l: null, t0: performance.now(), strike: null, fl: null, hud: prevSt || st, flashed: false };
      if (l) setResult(l);
      hudKey = ''; renderTop();
    }
    function setResult(l) {
      anim.l = l; anim.fl = flight(l);
      api.setBusy(true);
      const runLeft = Math.max(0, anim.t0 + RUN * 1000 / L.debug.speed - performance.now());
      anim.strike = performance.now() + runLeft;
    }
    function endAnim() {
      clearTimeout(endTimer);
      anim = null; hudKey = ''; renderTop(); api.setBusy(false); syncOverlay();
    }
    function onFrameAnim() {
      if (!anim) return;
      const now = performance.now(), sp = L.debug.speed;
      // reaction cue on the keeper's device
      if (!anim.l && st && st.ph === 'r' && (now - anim.t0) * sp / 1000 >= RUN) {
        const g = 1 - kicker(st);
        if (api.canAct(g) && reactSent !== st.seq) {
          if (!cueAt) { cueAt = now; api.sfx('tick'); api.buzz(20); clearTimeout(reactTimer); const sq = st.seq; reactTimer = setTimeout(() => { if (st && st.seq === sq && reactSent !== sq) sendReact(3000); }, 1600); }
        }
      }
      if (anim.l && anim.strike != null && now >= anim.strike) {
        const t = (now - anim.strike) * sp / 1000;
        if (!anim.kicked) { anim.kicked = true; api.sfx('thud'); api.buzz(15); }
        if (!anim.flashed && t >= anim.fl.T) {
          anim.flashed = true;
          const l = anim.l, e = EVT[l.r];
          let text = e[0];
          if (l.r === 'S' && l.c) text = '캐치!';
          if (l.r === 'P' && l.hb) text = '크로스바!';
          anim.hud = st; hudKey = ''; renderTop();
          const a = goals(st.h[st.fs]), b = goals(st.h[1 - st.fs]);
          flash = { text, c: e[1], sub: a + ' : ' + b, t0: performance.now(), t: 1 };
          if (l.r === 'G' || l.r === 'I') { api.sfx('pop'); api.buzz(30); } else if (l.r === 'S') { api.sfx('hit'); api.buzz(25); } else if (l.r === 'P') api.sfx('hit'); else api.sfx('lose');
          if (l.ms != null && api.canAct(l.g) && st.ro) { const m = l.ms; api.toast(m < 100 ? '반응: 너무 일찍 움직였어요' : '반응 ' + m + 'ms' + (m < 230 ? ' · 번개 같아요!' : m < 330 ? ' · 좋아요' : '')); }
          const me = anim;
          endTimer = setTimeout(() => { if (anim === me) endAnim(); }, 1500 / L.debug.speed);
        }
      }
    }
    function sendReact(ms) {
      if (!st || st.ph !== 'r' || reactSent === st.seq) return;
      reactSent = st.seq; clearTimeout(reactTimer);
      api.actAs(1 - kicker(st), { type: 'react', ms: Math.round(ms) });
    }

    const stopLoop = U.loop((dt) => {
      time += dt;
      if (hintFlash > 0) hintFlash -= dt;
      onFrameAnim();
      draw();
    });

    /* ---- input ---- */
    const el = cv.cv;
    function onDown(ev) {
      if (!ev.isPrimary || !st) return;
      const p = cv.local(ev);
      // reaction tap
      if (st.ph === 'r' && anim && !anim.l && api.canAct(1 - kicker(st)) && reactSent !== st.seq) {
        const now = performance.now();
        if (!cueAt) { sendReact(-1); api.toast('너무 일찍!'); } else sendReact(now - cueAt);
        api.buzz(12); ev.preventDefault(); return;
      }
      const h = myPending();
      if (h < 0) return;
      const isKick = h === kicker(st);
      if (isKick) {
        const b = ballScreen();
        if (!b || Math.hypot(p.x - b[0], p.y - b[1]) > 70 && p.y < b[1] - 40) { hintFlash = 1.6; api.sfx('click'); return; }
      }
      try { el.setPointerCapture(ev.pointerId); } catch (e) {}
      const t = performance.now();
      ptr = { id: ev.pointerId, seat: h, sx: p.x, sy: p.y, x: p.x, y: p.y, t0: t, lastT: t, moveT: 0, hist: [{ x: p.x, y: p.y }] };
      api.sfx('tick'); api.buzz(8);
      ev.preventDefault();
    }
    function onMove(ev) {
      if (!ptr || ev.pointerId !== ptr.id) return;
      const p = cv.local(ev), t = performance.now();
      ptr.x = p.x; ptr.y = p.y; ptr.lastT = t;
      if (!ptr.moveT && Math.hypot(p.x - ptr.sx, p.y - ptr.sy) > 10) ptr.moveT = t;
      ptr.hist.push({ x: p.x, y: p.y }); if (ptr.hist.length > 80) ptr.hist.shift();
    }
    function onUp(ev) {
      if (!ptr || ev.pointerId !== ptr.id) return;
      const g = ptr; ptr = null;
      if (ev.type === 'pointercancel' || !st) return;
      const p = cv.local(ev); g.x = p.x; g.y = p.y; g.lastT = performance.now(); g.hist.push({ x: p.x, y: p.y });
      const seat = g.seat;
      if (myPending() !== seat) return;
      if (seat === kicker(st)) {
        const sw = swipeInfo(g);
        if (!sw || sw.cancel) { if (g.hist.length < 4) hintFlash = 1.6; api.sfx('click'); return; }
        tries['k' + seat] = (tries['k' + seat] || 0) + 1;
        sent[seat] = st.seq + ':' + seat;
        api.buzz(18); api.sfx('whoosh');
        api.actAs(seat, { type: 'kick', z: sw.z, pw: Math.round(sw.pw * 100) / 100, cv: sw.cv });
      } else {
        const dv = diveOf(g);
        if (!dv || dv.cancel) { if (g.hist.length < 4) hintFlash = 1.6; api.sfx('click'); return; }
        tries['g' + seat] = (tries['g' + seat] || 0) + 1;
        sent[seat] = st.seq + ':' + seat;
        api.buzz(18); api.sfx('whoosh');
        api.actAs(seat, { type: 'dive', d: dv.d });
      }
      syncOverlay();
    }
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);
    cv.onresize = layout;
    layout();

    root._pk = { ball: () => ballScreen(), goal: () => goalRect() };
    return {
      update(next, prev) {
        st = next;
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          if (anim && !anim.l && anim.k === l.k) setResult(l);          // run-up already playing (reaction phase)
          else { if (anim) endAnim(); startRun(l.k, l, prev); }
          cueAt = 0;
        } else if (next.ph === 'r' && prev && prev !== next && prev.ph !== 'r') {
          cueAt = 0; reactSent = -1;
          startRun(kicker(next), null, prev);
        } else if (!prev && next.ph === 'r') { cueAt = 0; startRun(kicker(next), null, null); }
        if (next.ph === 'c' && (!prev || prev.seq !== next.seq) && l && (!prev || !prev.last || prev.last.id !== l.id)) revealed = -1;
        if (!prev && !anim) revealed = -1;
        if (myPending() < 0) ptr = null;
        hudKey = ''; renderTop();
        syncOverlay();
      },
      destroy() {
        stopLoop(); clearTimeout(endTimer); clearTimeout(reactTimer);
        el.removeEventListener('pointerdown', onDown); el.removeEventListener('pointermove', onMove);
        el.removeEventListener('pointerup', onUp); el.removeEventListener('pointercancel', onUp);
        if (overlayEl) overlayEl.remove();
        cv.destroy(); top.remove(); spGoal.el.remove(); spBall.el.remove();
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'penalty', name: '승부차기', tag: '페널티 킥 대결', cat: '스포츠',
    blurb: '번갈아 키커와 골키퍼가 되어 5번씩 차요. 키커는 쓸어서 노릴 곳·세기·감기를, 골키퍼는 다이빙 방향을 몰래 골라요. 동점이면 서든데스.',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, hidden: false, aiDelay: 850, aiDelayFor,
    tint: '#1e5a3c',
    icon: '<path d="M6 40V12h44v28" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linejoin="round"/><path d="M12 18h32M12 24h32M12 30h32M18 12v28M28 12v28M38 12v28" stroke="currentColor" stroke-width="1.2" opacity=".45"/><circle cx="40" cy="44" r="7" fill="currentColor"/><circle cx="40" cy="44" r="2.6" fill="#1e5a3c"/><path d="M2 50h52" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>',
    options: [
      { id: 'react', label: '골키퍼 반응 탭', choices: [{ v: 'on', label: '켜기' }, { v: 'off', label: '끄기' }], def: 'on' },
    ],
    quick: [
      '번갈아 한 번은 키커(차는 사람), 한 번은 골키퍼가 돼요. 5번씩 차서 골이 많은 사람이 이겨요.',
      '키커: 공에서 노릴 곳으로 쓸어 올려 차요. 골키퍼: 다이빙할 쪽으로 쓸어요. 둘 다 동시에 몰래 골라요.',
      '5번씩 찬 뒤 동점이면 서든데스: 한 번씩 차서 한쪽만 넣으면 끝!',
    ],
    rules: [
      { h: '목표', p: ['2명이 하는 승부차기예요. 각자 5번씩 차서 골을 더 많이 넣은 사람이 이겨요.'] },
      { h: '차례에 할 일', p: ['① 동전 던지기로 먼저 찰 사람을 정해요.',
        '② 한 사람이 찰 때 다른 사람은 골키퍼예요. 킥마다 역할이 바뀌어요(위 이름표에 「키커」/「GK」 표시).',
        '③ 키커와 골키퍼가 동시에 몰래 골라요. 서로의 선택은 안 보여요(온라인은 각자 폰에서).',
        '④ 둘 다 고르면 공을 차고 결과가 나와요.',
        '한 폰에서 둘이 할 때는 「다른 사람은 보지 마세요」 화면이 나오면 폰을 넘기고 「준비됐어요」를 눌러요.'] },
      { h: '조작 — 키커 (손가락)', p: ['① 공에서 손가락을 대고 노릴 곳으로 쓸어 올려요.',
        '② 쓸어 올린 방향과 길이로 골문 9칸 중 하나를 노려요(노란 칸으로 보여요).',
        '③ 빠르게 쓸수록 세게 차요. 파워 막대의 초록 구간이 적당해요. 너무 세면(빨강) 공이 떠서, 높은 칸은 크로스바를 넘어가기 쉬워요. 약하게 차면 정확하지만 골키퍼가 반응하기 쉬워요.',
        '④ 휘어지게(둥글게) 쓸면 감아차기: 공이 휘어서 골키퍼가 잡기 조금 어렵지만, 살짝 덜 정확해요.'] },
      { h: '조작 — 골키퍼 (손가락)', p: ['① 화면 아무 데서나 다이빙할 쪽으로 쓸어요: 왼쪽 아래 · 왼쪽 위 · 가운데 아래 · 가운데 위 · 오른쪽 아래 · 오른쪽 위.',
        '② 공이 다이빙한 쪽 손닿는 범위로 오면 막아요. 느린 공일수록 막기 쉬워요.',
        '③ 반응 탭(옵션, 기본 켜기): 키커가 차기 직전 「지금!」이 뜨면 빨리 화면을 탭하세요. 빠를수록 손이 조금 더 멀리 닿아요. 너무 일찍 누르면 효과가 없어요.'] },
      { h: '점수·승리', p: ['5번씩 차서 골이 많은 사람이 이겨요.',
        '남은 킥을 다 넣어도 따라잡을 수 없으면 그 자리에서 끝나요.',
        '5번씩 찬 뒤 동점이면 서든데스: 한 번씩 짝지어 차서, 한쪽만 넣으면 그 라운드에서 승부가 나요.',
        '구석일수록 막기 어렵지만 골대에 맞거나 빗나갈 수 있어요. 골대를 맞고 안으로 들어가면 골이에요.'] },
      { h: '예시', p: ['나는 키커: 오른쪽 위 칸으로 빠르게 쓸어 올림. 상대 골키퍼는 왼쪽 아래로 다이빙 → 골!',
        '다음엔 내가 골키퍼: 가운데 위로 쓸었는데 공이 오른쪽 아래로 → 골을 먹음.',
        '3번씩 찼을 때 나 3골, 상대 1골이고 상대 남은 킥이 2번이면 → 상대가 다 넣어도 3:3까지라 아직 계속. 다음에 내가 넣어 4:1이 되면 따라잡을 수 없으니 바로 승리!'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움 키커는 구석을 정확히 노리고, 어려움 골키퍼는 상대가 자주 차는 쪽을 읽어요.'] },
    ],
    tutorial: [
      { sel: '.pk-top', text: '승부차기! 번갈아 한 번은 키커, 한 번은 골키퍼(GK)가 돼요. 5번씩 차서 골이 많은 사람이 이겨요. 지금 내 역할은 위 이름표에 보여요.' },
      { sel: '.pk-ball', text: '키커일 때: 공에서 손가락을 대고 노릴 곳으로 쓸어 올려요. 방향과 길이로 골문 9칸 중 하나(노란 칸)를 노리고, 빠르게 쓸수록 세게 차요.' },
      { sel: '.pk-goal', text: '구석일수록 막기 어렵지만 빗나가기 쉬워요. 너무 세면 공이 떠서 크로스바를 넘어가요. 둥글게 쓸면 감아차기!' },
      { sel: '.pk-goal', text: '골키퍼일 때: 화면 아무 데서나 다이빙할 쪽으로 쓸어요(왼쪽·가운데·오른쪽 × 아래·위). 공이 손닿는 곳으로 오면 막아요.' },
      { sel: '.pk-goal', text: '키커와 골키퍼는 동시에 몰래 골라요. 골키퍼는 공을 차기 직전 「지금!」이 뜨면 빨리 탭하세요. 손이 더 멀리 닿아요!' },
    ],
    init, actor, apply, ai, result, mount,
    _t: { decided, kicker, resolve, flight, rbFrom, enc, dec, DV, ZX, ZY, aiKick, aiDive, goals },
  });
})();
