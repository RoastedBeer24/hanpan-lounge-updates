/* 물길 잇기 레이스 — realtime pipe-laying race (1–4) + solo stage mode with stars.
   Everyone gets the same 7×9 board (same seed) and the same order of pipe pieces. Tap an empty cell to drop the next
   piece there (pieces are not rotated — the classic rule); tap a placed dry piece to swap it (hands tied 0.8 s).
   After a countdown water leaves the source and runs along the pipes, cell by cell; every wet cell scores. When the
   water reaches an open end it leaks and that board is over; reaching the pond / drain gives a bonus and ends it too.
   Each device simulates its own board (host/local also the AI boards). Guests publish their score row + a 63-char board
   string; the host relays all rows + the clock and ends the match with setState (cooking.js / tiltmaze.js pattern). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;

  /* ======================= rules data ======================= */
  const GW = 7, GH = 9, NC = GW * GH;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];      // sides / directions: 0 N, 1 E, 2 S, 3 W
  const OPP = (d) => (d + 2) & 3;
  // pieces: 1 ─  2 │  3 └(N,E)  4 ┌(E,S)  5 ┐(S,W)  6 ┘(W,N)  7 ┼ cross  8 저수조 ─  9 저수조 │   (bit d = opening on side d)
  const MASK = [0, 10, 5, 3, 6, 12, 9, 15, 10, 5];
  const K_ROCK = 1, K_FLOWER = 2, K_SRC = 3, K_DRAIN = 4;
  const SPEEDS = [{ fill: 3.0, cd: 24 }, { fill: 2.3, cd: 18 }, { fill: 1.75, cd: 14 }];   // 느긋 · 보통 · 빠르게
  const FAST_T = 0.16, TANK_X = 4, REP_T = 0.8, READY = 3.5;
  const PTS = 10, LOOP_B = 50, FLOWER_B = 30, DRAIN_B = 100;
  const WT = [[0, 3, 3, 2.4, 2.4, 2.4, 2.4, 1.1, 0.45, 0.45], [0, 3, 3, 2.4, 2.4, 2.4, 2.4, 1.4, 0.3, 0.3]];
  const MAPN = ['정원 물길', '도시 배관'];
  const hasOpen = (p, d) => (MASK[p] >> d) & 1;
  const axisBit = (s) => (s & 1 ? 1 : 2);
  function exitOf(p, s) { if (p === 7) return OPP(s); const m = MASK[p] & ~(1 << s); return m & 1 ? 0 : m & 2 ? 1 : m & 4 ? 2 : 3; }
  function canEnter(p, f, s) { return !!p && !!hasOpen(p, s) && (p === 7 ? !(f & axisBit(s)) : !f); }
  const cx = (c) => c % GW, cy = (c) => (c / GW) | 0;
  function nb(c, d) { const x = cx(c) + DX[d], y = cy(c) + DY[d]; return x < 0 || y < 0 || x >= GW || y >= GH ? -1 : y * GW + x; }
  const man = (a, b) => Math.abs(cx(a) - cx(b)) + Math.abs(cy(a) - cy(b));
  function mkRng(seed) {
    let a = (seed >>> 0) || 0x9e3779b9;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function hrand(seed, i) {   // random access: i-th number of a seed (the piece order is the same on every board)
    let t = (Math.imul((seed >>> 0) ^ 0x5bd1e995, 0x27d4eb2d) + Math.imul(i + 1, 0x9E3779B1)) >>> 0;
    t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); t = (t ^ (t >>> 14)) >>> 0;
    t = Math.imul(t ^ (t >>> 13), 0x85ebca6b) >>> 0; return ((t ^ (t >>> 16)) >>> 0) / 4294967296;
  }
  function pieceAt(D, i) {
    const w = D.wt; let tot = 0; for (let p = 1; p <= 9; p++) tot += w[p];
    let r = hrand(D.sd, i) * tot;
    for (let p = 1; p <= 9; p++) { r -= w[p]; if (r < 0) return p; }
    return 1;
  }

  /* solo stages (fixed seed → same board and same piece order every time). par = points for ★★ / ★★★ */
  const STAGES = [
    { n: '첫 물길', tip: '물이 나오는 쪽에 맞는 조각을 이어 놓아요. 연못까지 이으면 성공!', mp: 0, sp: 0, rocks: 0, flowers: 2, fixed: 0, dmin: 4, sd: 1303 },
    { n: '꽃밭 물 주기', tip: '물길이 꽃밭 칸을 지나가면 꽃이 피고 +30점!', mp: 0, sp: 0, rocks: 1, flowers: 7, fixed: 0, dmin: 5, sd: 2409 },
    { n: '돌 피하기', tip: '돌이 있는 칸에는 관을 못 놓아요. 돌아갈 길을 미리 봐 둬요.', mp: 0, sp: 1, rocks: 7, flowers: 3, fixed: 0, dmin: 5, sd: 3818 },
    { n: '십자 고리', tip: '십자 관은 물이 두 번 지날 수 있어요. 두 번째로 지나면 고리 보너스 +50!', mp: 0, sp: 1, rocks: 2, flowers: 3, fixed: 1, dmin: 5, sd: 4421, wt: [0, 3, 3, 2.4, 2.4, 2.4, 2.4, 3.2, 0.3, 0.3] },
    { n: '저수조', tip: '저수조는 물이 차는 데 4배 오래 걸려요. 급할 때 시간을 벌어 줘요.', mp: 0, sp: 1, rocks: 3, flowers: 4, fixed: 0, dmin: 6, sd: 6137, wt: [0, 3, 3, 2.4, 2.4, 2.4, 2.4, 1, 1.4, 1.4] },
    { n: '도시 배관', tip: '녹슨 고정 관은 바꿀 수 없어요. 잘 이으면 공짜 길이에요!', mp: 1, sp: 1, rocks: 4, flowers: 2, fixed: 3, dmin: 5, sd: 7041 },
    { n: '골목길', tip: '벽돌 벽이 많아요. 막다른 골목에 갇히지 않게!', mp: 1, sp: 1, rocks: 9, flowers: 2, fixed: 1, dmin: 6, sd: 8044 },
    { n: '빠른 물살', tip: '물이 빨라요. 먼저 몇 칸 이어 두고 시작해요.', mp: 0, sp: 2, rocks: 3, flowers: 4, fixed: 0, dmin: 5, sd: 9556 },
    { n: '먼 하수구', tip: '하수구가 멀리 있어요. 물이 새기 전에 끝까지 가요.', mp: 1, sp: 1, rocks: 4, flowers: 2, fixed: 2, dmin: 9, sd: 10559 },
    { n: '고정 관 미로', tip: '고정 관이 잔뜩! 바꿀 수 없으니 길을 맞춰 이어요.', mp: 1, sp: 1, rocks: 3, flowers: 2, fixed: 6, dmin: 6, sd: 11160 },
    { n: '가뭄 정원', tip: '물살이 빠르고 꽃밭이 흩어져 있어요. 욕심은 적당히!', mp: 0, sp: 2, rocks: 6, flowers: 6, fixed: 0, dmin: 6, sd: 13779, wt: [0, 3, 3, 2.4, 2.4, 2.4, 2.4, 1.1, 0.25, 0.25] },
    { n: '최종 시험', tip: '빠른 물살·벽·고정 관 총출동. 배운 걸 다 써 봐요!', mp: 1, sp: 2, rocks: 7, flowers: 3, fixed: 3, dmin: 8, sd: 14681 },
  ];
  const STAR_PAR = [[210, 300], [290, 420], [210, 300], [250, 350], [160, 220], [280, 400], [300, 430], [170, 250], [270, 380], [160, 220], [160, 220], [160, 220]];   // ★★ ≈ 60 %, ★★★ ≈ 85 % of the best AI score on that stage
  const RAND_PAR = [[230, 330], [230, 320], [220, 310]];   // 무작위 판 (속도별)

  function genBoard(P) {
    const sp = SPEEDS[P.sp] || SPEEDS[1];
    for (let att = 0; att < 80; att++) {
      const r = mkRng(((P.sd >>> 0) + att * 7919) >>> 0), ri = (n) => Math.floor(r() * n);
      const k = new Uint8Array(NC), g0 = new Uint8Array(NC);
      const src = ri(NC), dirs = [0, 1, 2, 3].filter((d) => nb(src, d) >= 0 && nb(nb(src, d), d) >= 0);
      if (!dirs.length) continue;
      const sdir = dirs[ri(dirs.length)], sf = nb(src, sdir);
      const cand = [];
      for (let c = 0; c < NC; c++) {
        if (c === src || c === sf || man(c, src) < (P.dmin | 0)) continue;
        for (let d = 0; d < 4; d++) { const f = nb(c, d); if (f >= 0 && f !== src && f !== sf) cand.push([c, d, f]); }
      }
      if (!cand.length) continue;
      const [drain, ddir, df] = cand[ri(cand.length)];
      k[src] = K_SRC; k[drain] = K_DRAIN;
      const free = (far) => { const a = []; for (let c = 0; c < NC; c++) if (!k[c] && !g0[c] && c !== sf && c !== df && (!far || (man(c, sf) > 1 && man(c, df) > 1))) a.push(c); return a; };
      for (let i = 0; i < (P.rocks | 0); i++) { const f = free(false); if (f.length) k[f[ri(f.length)]] = K_ROCK; }
      for (let i = 0; i < (P.fixed | 0); i++) { const f = free(true); if (f.length) g0[f[ri(f.length)]] = 1 + ri(7); }
      for (let i = 0; i < (P.flowers | 0); i++) { const f = free(false); if (f.length) k[f[ri(f.length)]] = K_FLOWER; }
      // the open area around the source must reach the drain's front cell and be roomy
      const seen = new Uint8Array(NC), q = [sf]; seen[sf] = 1; let n = 0, ok = false;
      while (q.length) {
        const c = q.pop(); n++; if (c === df) ok = true;
        for (let d = 0; d < 4; d++) { const m = nb(c, d); if (m < 0 || seen[m] || g0[m] || (k[m] !== 0 && k[m] !== K_FLOWER)) continue; seen[m] = 1; q.push(m); }
      }
      if (!ok || n < 22) continue;
      return { sd: P.sd >>> 0, mp: P.mp | 0, sp: P.sp | 0, k, g0, src, sdir, sf, drain, ddir, df, fill: sp.fill, cd: sp.cd, wt: P.wt || WT[P.mp | 0] };
    }
    return genBoard(Object.assign({}, P, { rocks: 0, fixed: 0, dmin: 4, sd: (P.sd >>> 0) + 1 }));
  }
  function paramsOf(st) {
    if (st.stg >= 0 && st.stg < STAGES.length) return STAGES[st.stg];
    const r = mkRng((st.sd ^ 0x2545F491) >>> 0), mp = st.mp === 1 ? 1 : 0;
    return mp === 0 ? { sd: st.sd, mp, sp: st.sp, rocks: 3 + Math.floor(r() * 3), flowers: 5, fixed: Math.floor(r() * 2), dmin: 5 }
      : { sd: st.sd, mp, sp: st.sp, rocks: 5 + Math.floor(r() * 3), flowers: 2, fixed: 2 + Math.floor(r() * 2), dmin: 5 };
  }
  const DEFS = {};
  function defOf(st) { const k = st.sd + '.' + st.stg + '.' + st.mp + '.' + st.sp; return DEFS[k] || (DEFS[k] = genBoard(paramsOf(st))); }

  /* ======================= board simulation (one per player) ======================= */
  function newBoard(D) {
    return { D, g: Uint8Array.from(D.g0), fl: new Uint8Array(NC), qi: 0, t: 0, cdEnd: D.cd, ph: 0, hc: -1, hs: 0, hp: 0,
      fast: 0, sc: 0, ln: 0, lp: 0, fw: 0, lock: 0, lk: null, ev: [], ver: 1 };
  }
  const fillT = (B, c) => (B.fast ? FAST_T : B.D.fill * (B.g[c] >= 8 ? TANK_X : 1));
  function leak(B, c, d) { B.ph = 2; B.lk = { c, d }; B.ver++; B.ev.push({ k: 'leak', c, d }); return false; }
  function enter(B, from, e) {   // water leaves `from` through side e
    const D = B.D, n = nb(from, e), s = OPP(e);
    if (n < 0) return leak(B, from, e);
    if (n === D.drain) {
      if (s !== D.ddir) return leak(B, from, e);
      B.sc += DRAIN_B; B.ph = 3; B.ver++; B.ev.push({ k: 'drain', c: n }); return false;
    }
    if (n === D.src || D.k[n] === K_ROCK || !canEnter(B.g[n], B.fl[n], s)) return leak(B, from, e);
    B.hc = n; B.hs = s; B.hp = 0; B.ev.push({ k: 'enter', c: n }); return true;
  }
  function complete(B) {
    const c = B.hc, p = B.g[c], s = B.hs, was = B.fl[c];
    B.fl[c] |= p === 7 ? axisBit(s) : 3;
    const pts = B.fast ? PTS * 2 : PTS;
    B.sc += pts; B.ln++; B.ver++;
    B.ev.push({ k: 'fill', c, pts });
    if (p === 7 && was) { B.sc += LOOP_B; B.lp++; B.ev.push({ k: 'loop', c }); }
    if (B.D.k[c] === K_FLOWER && !was) { B.sc += FLOWER_B; B.fw++; B.ev.push({ k: 'flower', c }); }
    enter(B, c, exitOf(p, s));
  }
  function stepB(B, dt) {
    B.t += dt;
    if (B.ph >= 2) return; if (B.lock > 0) B.lock = Math.max(0, B.lock - dt);
    let rem = dt;
    if (B.ph === 0) {
      if (B.t < B.cdEnd) return;
      rem = B.t - B.cdEnd; B.ph = 1; B.ev.push({ k: 'flow' });
      if (!enter(B, B.D.src, B.D.sdir)) return;
    }
    let guard = 0;
    while (B.ph === 1 && rem > 0 && guard++ < 80) {
      const T = fillT(B, B.hc), need = (1 - B.hp) * T;
      if (rem < need) { B.hp += rem / T; break; }
      rem -= need; B.hp = 1;
      complete(B);
    }
  }
  function canPlace(B, c) {   // '' = ok, else a reason code
    const D = B.D;
    if (B.ph >= 2) return 'over';
    if (c < 0 || c >= NC) return 'out';
    const k = D.k[c];
    if (k === K_ROCK) return 'rock';
    if (k === K_SRC || k === K_DRAIN) return 'block';
    if (D.g0[c]) return 'fixed';
    if (B.fl[c] || (B.ph === 1 && B.hc === c)) return 'wet';
    if (B.lock > 0) return 'busy';
    return '';
  }
  function placeB(B, c) {
    const why = canPlace(B, c);
    if (why) return why;
    const p = pieceAt(B.D, B.qi), old = B.g[c];
    B.g[c] = p; B.qi++; B.ver++;
    if (old) { B.lock = REP_T; B.ev.push({ k: 'rep', c, old, p }); return 'rep'; }
    B.ev.push({ k: 'put', c, p });
    return 'put';
  }
  function goB(B) { if (B.ph !== 0) return false; B.cdEnd = B.t; B.ev.push({ k: 'go' }); return true; }
  function fastB(B) { if (B.ph !== 1 || B.fast) return false; B.fast = 1; B.ev.push({ k: 'fast' }); return true; }

  /* where does the water go from here? (used by the hint marker and the AI) */
  const TMP = new Uint8Array(NC);
  function trace(B, g) {
    const D = B.D, fl = B.fl;
    let len = 0, bon = 0, time = 0, from, e;
    TMP.set(fl);
    const fT = (c) => D.fill * (g[c] >= 8 ? TANK_X : 1);
    if (B.ph === 0) { time = Math.max(0, B.cdEnd - B.t); from = D.src; e = D.sdir; }
    else if (B.ph === 1) {
      const c = B.hc, p = g[c], was = TMP[c];
      len = 1; time = (1 - B.hp) * (B.fast ? FAST_T : fT(c));
      if (p === 7 && was) bon += LOOP_B;
      if (D.k[c] === K_FLOWER && !was) bon += FLOWER_B;
      TMP[c] |= p === 7 ? axisBit(B.hs) : 3;
      from = c; e = exitOf(p, B.hs);
    } else return { st: 'over', len: 0, bon: 0, time: 0, c: -1, s: 0, bc: -1, lc: -1, ld: 0 };
    for (let guard = 0; guard < 140; guard++) {
      const n = nb(from, e), s = OPP(e);
      if (n < 0) return { st: 'dead', len, bon, time, c: -1, s, bc: -1, lc: from, ld: e };
      if (n === D.drain) return s === D.ddir ? { st: 'drain', len, bon, time, c: n, s, bc: -1, lc: from, ld: e } : { st: 'dead', len, bon, time, c: -1, s, bc: -1, lc: from, ld: e };
      const k = D.k[n];
      if (k === K_ROCK || n === D.src) return { st: 'dead', len, bon, time, c: -1, s, bc: -1, lc: from, ld: e };
      const p = g[n];
      if (!p) return { st: 'open', len, bon, time, c: n, s, bc: -1, lc: from, ld: e };
      if (!canEnter(p, TMP[n], s)) {
        const rep = !D.g0[n] && !fl[n] && !(B.ph === 1 && n === B.hc);
        return { st: 'dead', len, bon, time, c: -1, s, bc: rep ? n : -1, lc: from, ld: e };
      }
      const was = TMP[n];
      len++; time += B.fast ? FAST_T : fT(n);
      if (p === 7 && was) bon += LOOP_B;
      if (k === K_FLOWER && !was) bon += FLOWER_B;
      TMP[n] |= p === 7 ? axisBit(s) : 3;
      from = n; e = exitOf(p, s);
    }
    return { st: 'dead', len, bon, time, c: -1, s: 0, bc: -1, lc: from, ld: e };
  }

  /* ======================= AI ======================= */
  const SEEN = new Uint16Array(NC); let stamp = 1;
  const QQ = new Int16Array(NC);
  const DIST = new Uint8Array(NC);
  function space(B, g, c0) {   // empty cells reachable from c0, can the drain still be reached, and how far (in cells)
    const D = B.D;
    if (++stamp > 65000) { SEEN.fill(0); stamp = 1; }
    let h = 0, t = 0, n = 0, dr = c0 === D.df, dd = c0 === D.df ? 0 : 99;
    QQ[t++] = c0; SEEN[c0] = stamp; DIST[c0] = 0;
    while (h < t) {
      const c = QQ[h++]; n++;
      for (let d = 0; d < 4; d++) {
        const m = nb(c, d); if (m < 0 || SEEN[m] === stamp) continue;
        if (m === D.df && !dr) {
          if (!g[m] || (hasOpen(g[m], OPP(D.ddir)) && hasOpen(g[m], OPP(d)) && !B.fl[m])) { dr = true; dd = DIST[c] + 1; }
        }
        if (g[m] || (D.k[m] !== 0 && D.k[m] !== K_FLOWER)) continue;
        SEEN[m] = stamp; DIST[m] = DIST[c] + 1; QQ[t++] = m;
      }
    }
    return { n, dr, dd };
  }
  const AIP = [null, { depth: 1, cb: 40, pw: 3, cl: 0, rp: 12, tk: 1.4, lb: 10, fx: 0, hd: 0, hl: 99, nz: 25, oops: 0.12, rep: true }, { depth: 2, cb: 110, pw: 3.5, cl: 2, rp: 3, tk: 0.95, lb: 10, fx: 40, hd: 8, hl: 12, nz: 24, oops: 0, rep: true }, { depth: 4, cb: 160, pw: 3, cl: 3, rp: 1.5, tk: 0.65, lb: 10, fx: 50, hd: 10, hl: 14, nz: 14, oops: 0, rep: true }];
  function evalV(B, g, P) {
    const r = trace(B, g);
    const v = r.len * (PTS + P.lb) + r.bon;
    if (r.st === 'drain') return v + DRAIN_B + r.len * PTS * 0.8 + P.cb;
    if (r.st === 'open') return openV(B, g, P, r, r.c, r.time, v);
    if (r.st === 'dead' && r.bc >= 0 && P.rep && r.time > REP_T + 0.4) {   // a wrong dry piece in the way: it can still be swapped
      const old = g[r.bc]; g[r.bc] = 0;
      const val = openV(B, g, P, r, r.bc, r.time - REP_T, v) - 15;
      g[r.bc] = old;
      return val;
    }
    return v - 170;
  }
  function openV(B, g, P, r, c, time, v) {
    const sp = space(B, g, c), f = flex(B, g, c, r.s);
    const home = sp.dr ? P.hd * sp.dd * U.clamp((B.ln + r.len - P.hl) / 10, 0, 1) : 0;   // later on: head for the drain
    const roomT = sp.dr ? 60 + P.pw * Math.min(sp.n, 24) : 2 * Math.min(sp.n, 24) - 70;
    const nearT = sp.dr ? (DRAIN_B + P.cb + 8 * (B.ln + r.len)) * 0.55 * Math.pow(0.7, sp.dd) : -1e9;   // the drain is just ahead
    const ok = 1 - Math.pow(1 - f, Math.max(0, time - 0.3) / P.tk);   // chance a fitting piece shows up before the water gets here
    return ok * (v + Math.max(roomT, nearT) + P.cl * sp.n + P.fx * f - home) + (1 - ok) * (v - 170);
  }
  function flex(B, g, c, s) {   // chance that a random next piece fits here and leads on
    const D = B.D, w = D.wt;
    let ok = 0, tot = 0;
    for (let p = 1; p <= 9; p++) {
      tot += w[p];
      if (!hasOpen(p, s)) continue;
      const e = exitOf(p, s), n = nb(c, e);
      if (n < 0) continue;
      if (n === D.drain ? OPP(e) === D.ddir : (g[n] ? canEnter(g[n], B.fl[n], OPP(e)) : (D.k[n] === 0 || D.k[n] === K_FLOWER))) ok += w[p];
    }
    return ok / tot;
  }
  function cands(B, g, r, p, P, top) {
    const D = B.D, out = [];
    const fc = r.st === 'open' ? r.c : r.bc;
    if (r.st === 'open' && hasOpen(p, r.s)) out.push(r.c);
    if (r.st === 'dead' && r.bc >= 0 && P.rep && hasOpen(p, r.s)) out.push(r.bc);
    const far = [], junk = [];
    for (let c = 0; c < NC; c++) {
      if (c === fc || (D.k[c] !== 0 && D.k[c] !== K_FLOWER)) continue;
      const d = fc >= 0 ? man(c, fc) : 9;
      if (g[c]) { if (top && P.rep && d >= 3 && !D.g0[c] && !B.fl[c] && !(B.ph === 1 && c === B.hc) && g[c] === B.g[c]) junk.push(c); continue; }
      if (d <= 2 && P.depth > 1) out.push(c);
      else if (top) far.push(c);
    }
    if (top) {   // out-of-the-way dump cells (far from the flow and the drain, not on flowers) and old junk to swap
      far.sort((a, b) => dumpKey(B, b, fc) - dumpKey(B, a, fc));
      for (let i = 0; i < Math.min(2, far.length); i++) out.push(far[i]);
      junk.sort((a, b) => dumpKey(B, b, fc) - dumpKey(B, a, fc));
      for (let i = 0; i < Math.min(3, junk.length); i++) out.push(junk[i]);
    }
    if (!out.length) for (let c = 0; c < NC; c++) if (!g[c] && c !== fc && (D.k[c] === 0 || D.k[c] === K_FLOWER)) { out.push(c); break; }
    return out;
  }
  function dumpKey(B, c, fc) {
    const D = B.D;
    let k = (fc >= 0 ? man(c, fc) : 0) + man(c, D.df) * 0.6;
    if (D.k[c] === K_FLOWER) k -= 3;
    const x = cx(c), y = cy(c); if (x === 0 || y === 0 || x === GW - 1 || y === GH - 1) k += 1.5;
    return k;
  }
  function search(B, g, qi, depth, P, top, rnd) {
    const r = trace(B, g), p = pieceAt(B.D, qi);
    if (r.st === 'drain') return { v: evalV(B, g, P) + 30, c: -1 };
    const cs = cands(B, g, r, p, P, top), repPen = top ? (r.time < B.D.fill * 1.6 ? 40 : P.rp) : 12;
    let best = -1e9, bc = -1;
    for (const c of cs) {
      const old = g[c]; g[c] = p;
      let v = depth > 1 ? search(B, g, qi + 1, depth - 1, P, false).v : evalV(B, g, P);
      if (old) v -= repPen;
      if (rnd) v += (rnd() - 0.5) * P.nz;   // a little personality: AIs of the same level don't play identically
      g[c] = old;
      if (v > best) { best = v; bc = c; }
    }
    if (bc < 0) return { v: evalV(B, g, P), c: -1 };
    return { v: best, c: bc };
  }
  function aiInit(lv, seed) { return { lv: U.clamp(lv | 0, 1, 3), r: mkRng(seed), t: 0.6, ft: -1 }; }
  function aiThink(B, A, dt) {
    if (B.ph >= 2) return;
    A.t -= dt; if (A.t > 0) return;
    const lv = A.lv, P = AIP[lv];
    A.t = (lv === 1 ? 1.3 : lv === 2 ? 0.85 : 0.55) * (0.8 + A.r() * 0.45);
    if (B.lock > 0) return;
    const g = Uint8Array.from(B.g), r = trace(B, g);
    if (r.st === 'drain') {   // the path is finished: open the tap / speed it up for double points
      if (B.ph === 0 && lv >= 2) { goB(B); return; }
      if (B.ph === 1 && (lv >= 2 || A.r() < 0.4)) fastB(B);
      return;
    }
    if (P.oops && A.r() < P.oops) {   // beginner slip: drops the piece somewhere random
      const e = []; for (let c = 0; c < NC; c++) if (!canPlace(B, c) && !B.g[c]) e.push(c);
      if (e.length) { placeB(B, e[Math.floor(A.r() * e.length)]); return; }
    }
    const res = search(B, g, B.qi, P.depth, P, true, A.r);
    if (res.c >= 0 && !canPlace(B, res.c)) placeB(B, res.c);
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    const mpo = o.map === 0 || o.map === 1 ? o.map : -1;
    return {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      mpo, mp: mpo >= 0 ? mpo : U.rand(2), sp: [0, 1, 2].includes(o.speed) ? o.speed : 1,
      ph: n === 1 ? 'pick' : 'play', sd: 1 + U.rand(2147483646), stg: -1, res: null,
    };
  }
  function startStage(s, id, rnd) {
    const r = rnd || Math.random;
    if (id >= 0 && id < STAGES.length) { const S = STAGES[id]; return Object.assign({}, s, { ph: 'play', stg: id, sd: S.sd, mp: S.mp, sp: S.sp }); }
    return Object.assign({}, s, { ph: 'play', stg: 1000, sd: 1 + Math.floor(r() * 2147483646), mp: s.mpo >= 0 ? s.mpo : Math.floor(r() * 2) });
  }
  function finish(s, rows) {   // rows: [seat, score, length, f (0 still flowing, 1 leaked, 2 reached the drain), flowers, loops]
    const res = rows.slice().sort((a, b) => b[1] - a[1] || b[3] - a[3] || b[2] - a[2] || a[0] - b[0]);
    return Object.assign({}, s, { ph: 'done', res });
  }
  const parOf = (s) => (s.stg >= 0 && s.stg < STAGES.length ? STAR_PAR[s.stg] : RAND_PAR[s.sp] || RAND_PAR[1]);
  function starsOf(s, sc, f) { if (f !== 2) return 0; const p = parOf(s); return 1 + (sc >= p[0] ? 1 : 0) + (sc >= p[1] ? 1 : 0); }
  const goalName = (mp) => (mp === 1 ? '하수구' : '연못');
  const boardName = (s) => (s.stg >= 0 && s.stg < STAGES.length ? (s.stg + 1) + '. ' + STAGES[s.stg].n : (s.n === 1 ? '무작위 판 · ' : '') + MAPN[s.mp === 1 ? 1 : 0]);
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const extra = (r) => (r[4] ? ' · 꽃 ' + r[4] : '') + (r[5] ? ' · 고리 ' + r[5] : '');
    if (s.n === 1) {
      const r = s.res[0], n = starsOf(s, r[1], r[3]), p = parOf(s);
      return { winners: n > 0 ? [r[0]] : [], title: n ? '별 ' + n + '개!' : '물이 샜어요',
        text: boardName(s) + '\n' + '★'.repeat(n) + '☆'.repeat(3 - n) + '  ' + r[1] + '점\n길이 ' + r[2] + '칸' + extra(r) + (r[3] === 2 ? ' · ' + goalName(s.mp) + ' 도착' : '') +
          '\n별 기준: ★ ' + goalName(s.mp) + ' 도착 · ★★ ' + p[0] + '점 · ★★★ ' + p[1] + '점' };
    }
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '점 · ' + r[2] + '칸' + (r[3] === 2 ? ' · 도착' : r[3] === 1 ? ' · 새서 끝' : '') + extra(r));
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: boardName(s) + '\n' + lines.join('\n') };
  }
  // compact board string for rivals' thumbnails: '.' empty, a–i dry piece, A–I wet piece, x / y cross wet on one axis
  function encB(B) {
    let o = '';
    for (let c = 0; c < NC; c++) {
      const p = B.g[c], f = B.fl[c];
      if (!p) o += '.';
      else if (p === 7 && (f === 1 || f === 2)) o += f === 1 ? 'x' : 'y';
      else o += String.fromCharCode((f ? 65 : 97) + p - 1);
    }
    return o;
  }
  function decB(str, g, fl) {
    for (let c = 0; c < NC; c++) {
      const ch = (str && str[c]) || '.';
      if (ch === '.') { g[c] = 0; fl[c] = 0; }
      else if (ch === 'x' || ch === 'y') { g[c] = 7; fl[c] = ch === 'x' ? 1 : 2; }
      else { const k = ch.charCodeAt(0); if (k >= 97 && k <= 105) { g[c] = k - 96; fl[c] = 0; } else if (k >= 65 && k <= 73) { g[c] = k - 64; fl[c] = 3; } else { g[c] = 0; fl[c] = 0; } }
    }
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const TH = [
    { bgA: '#3b7036', bgB: '#427a3c', tuft: 'rgba(150,210,110,.35)', frame: '#6b4a2b', frameHi: '#8d6539', frameLo: '#3e2915',
      rim: '#5e2f1a', body: '#c46d3c', hi: '#f0a877', ch: '#33201a', fxRim: '#34363c', fxBody: '#7c7f88', fxHi: '#b6b9c2',
      rock: '#8e8a86', rockHi: '#c2bdb6', rockLo: '#57534f', mini: '#3f7a3a' },
    { bgA: '#5b5862', bgB: '#625f69', tuft: 'rgba(0,0,0,.18)', frame: '#2c2f37', frameHi: '#4a4e5a', frameLo: '#16181d',
      rim: '#2f3a45', body: '#8ea2b6', hi: '#d6e2ee', ch: '#1b1f25', fxRim: '#4a2716', fxBody: '#a35d33', fxHi: '#d89462',
      rock: '#9a4a36', rockHi: '#c26a52', rockLo: '#5e2a1e', mini: '#5f5c66' },
  ];
  const WAT = '#2d8fe8', WAT_HI = '#a9e0ff';
  const SP = [[0.5, 0], [1, 0.5], [0.5, 1], [0, 0.5]];
  const PATHS = {};
  function pathOf(s, e) {
    const k = s * 4 + e; if (PATHS[k]) return PATHS[k];
    const a = SP[s], b = SP[e], out = [];
    if (e === OPP(s)) { for (let i = 0; i <= 8; i++) out.push([a[0] + (b[0] - a[0]) * i / 8, a[1] + (b[1] - a[1]) * i / 8]); }
    else {
      const ccx = s === 1 || e === 1 ? 1 : 0, ccy = s === 2 || e === 2 ? 1 : 0;
      const a0 = Math.atan2(a[1] - ccy, a[0] - ccx), a1 = Math.atan2(b[1] - ccy, b[0] - ccx);
      let d = a1 - a0; while (d > Math.PI) d -= TAU; while (d < -Math.PI) d += TAU;
      for (let i = 0; i <= 8; i++) { const t = a0 + d * i / 8; out.push([ccx + 0.5 * Math.cos(t), ccy + 0.5 * Math.sin(t)]); }
    }
    return (PATHS[k] = out);
  }
  function sidesOf(p) { const o = []; for (let d = 0; d < 4; d++) if (hasOpen(p, d)) o.push(d); return o; }
  function axesOf(p) { // [[s, e, wetBit]]
    if (p === 7) return [[3, 1, 1], [0, 2, 2]];
    const s = sidesOf(p); return [[s[0], s[1], 3]];
  }
  function strokeRange(g, pts, x, y, ts, u0, u1, col, w, cap) {
    if (u1 <= u0) return;
    const n = pts.length - 1, f0 = u0 * n, f1 = u1 * n;
    const at = (f) => { const i = Math.min(n - 1, Math.floor(f)), t = f - i; return [x + (pts[i][0] + (pts[i + 1][0] - pts[i][0]) * t) * ts, y + (pts[i][1] + (pts[i + 1][1] - pts[i][1]) * t) * ts]; };
    g.beginPath();
    let q = at(f0); g.moveTo(q[0], q[1]);
    for (let i = Math.floor(f0) + 1; i < f1; i++) g.lineTo(x + pts[i][0] * ts, y + pts[i][1] * ts);
    q = at(f1); g.lineTo(q[0], q[1]);
    g.strokeStyle = col; g.lineWidth = w; g.lineCap = cap || 'butt'; g.lineJoin = 'round'; g.stroke();
  }
  function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
  function circ(g, x, y, r) { g.beginPath(); g.arc(x, y, Math.max(0.01, r), 0, TAU); }
  function flange(g, s, x, y, ts, pw) {
    const d = ts * 0.075, w = pw * 1.18;
    if (s === 0) g.fillRect(x + ts / 2 - w / 2, y, w, d);
    else if (s === 2) g.fillRect(x + ts / 2 - w / 2, y + ts - d, w, d);
    else if (s === 3) g.fillRect(x, y + ts / 2 - w / 2, d, w);
    else g.fillRect(x + ts - d, y + ts / 2 - w / 2, d, w);
  }
  /* one pipe tile; f = wet bits (1 = E–W axis, 2 = N–S axis, 3 = all) */
  function drawPipe(g, p, x, y, ts, T, fixed, f, alpha) {
    const pw = ts * 0.46, cw = ts * 0.18;
    const rim = fixed ? T.fxRim : T.rim, body = fixed ? T.fxBody : T.body, hi = fixed ? T.fxHi : T.hi;
    if (alpha != null) g.globalAlpha = alpha;
    axesOf(p).forEach(([s, e, bit], k) => {
      const pts = pathOf(s, e);
      if (k === 1) { g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(x + ts / 2 - pw * 0.66, y + ts / 2 - pw * 0.42, pw * 1.32, pw * 1.05); }   // bridge shadow
      strokeRange(g, pts, x + ts * 0.035, y + ts * 0.06, ts, 0, 1, 'rgba(0,0,0,.3)', pw);
      strokeRange(g, pts, x, y, ts, 0, 1, rim, pw);
      strokeRange(g, pts, x, y, ts, 0, 1, body, pw * 0.74);
      strokeRange(g, pts, x - pw * 0.13, y - pw * 0.13, ts, 0.08, 0.92, hi, pw * 0.13);
      strokeRange(g, pts, x, y, ts, 0, 1, T.ch, cw);
      if (f & bit) { strokeRange(g, pts, x, y, ts, 0, 1, WAT, cw * 0.92); strokeRange(g, pts, x - cw * 0.12, y - cw * 0.12, ts, 0.1, 0.9, WAT_HI, cw * 0.18); }
      g.fillStyle = rim; flange(g, s, x, y, ts, pw); flange(g, e, x, y, ts, pw);
    });
    if (p >= 8) { // tank basin in the middle
      const r = ts * 0.3, c0 = x + ts / 2, c1 = y + ts / 2;
      g.fillStyle = 'rgba(0,0,0,.3)'; rr(g, c0 - r + 2, c1 - r + 3, r * 2, r * 2, r * 0.45); g.fill();
      g.fillStyle = rim; rr(g, c0 - r, c1 - r, r * 2, r * 2, r * 0.45); g.fill();
      g.fillStyle = body; rr(g, c0 - r * 0.86, c1 - r * 0.86, r * 1.72, r * 1.72, r * 0.38); g.fill();
      g.fillStyle = T.ch; rr(g, c0 - r * 0.62, c1 - r * 0.62, r * 1.24, r * 1.24, r * 0.3); g.fill();
      if (f) { g.fillStyle = WAT; rr(g, c0 - r * 0.6, c1 - r * 0.6, r * 1.2, r * 1.2, r * 0.28); g.fill(); g.fillStyle = 'rgba(169,224,255,.55)'; rr(g, c0 - r * 0.45, c1 - r * 0.48, r * 0.5, r * 0.16, 2); g.fill(); }
      g.strokeStyle = hi; g.lineWidth = 1; rr(g, c0 - r * 0.86, c1 - r * 0.86, r * 1.72, r * 1.72, r * 0.38); g.stroke();
    }
    if (fixed) { // bolts
      g.fillStyle = hi;
      for (const [u, v] of [[0.14, 0.14], [0.86, 0.14], [0.14, 0.86], [0.86, 0.86]]) { circ(g, x + u * ts, y + v * ts, ts * 0.045); g.fill(); }
    }
    if (alpha != null) g.globalAlpha = 1;
  }
  /* water still running through a cell (entry side s, progress u 0..1) */
  function drawWaterPart(g, p, s, x, y, ts, u, now) {
    const cw = ts * 0.18, e = exitOf(p, s), pts = pathOf(s, e);
    const head = (u0, u1) => {
      strokeRange(g, pts, x, y, ts, u0, u1, WAT, cw * 0.92, 'round');
      const n = pts.length - 1, f = Math.min(n - 1e-6, u1 * n), i = Math.floor(f), t = f - i;
      const hx = x + (pts[i][0] + (pts[i + 1][0] - pts[i][0]) * t) * ts, hy = y + (pts[i][1] + (pts[i + 1][1] - pts[i][1]) * t) * ts;
      g.fillStyle = 'rgba(200,240,255,' + (0.55 + 0.3 * Math.sin(now / 90)) + ')'; circ(g, hx, hy, cw * 0.32); g.fill();
    };
    if (p < 8) { head(0, Math.max(0.02, u)); return; }
    const r = ts * 0.3, c0 = x + ts / 2, c1 = y + ts / 2;
    strokeRange(g, pts, x, y, ts, 0, Math.min(0.3, u / 0.15 * 0.3), WAT, cw * 0.92);
    if (u > 0.15) { const k = Math.sqrt(U.clamp((u - 0.15) / 0.7, 0, 1)); g.fillStyle = WAT; rr(g, c0 - r * 0.6 * k, c1 - r * 0.6 * k, r * 1.2 * k, r * 1.2 * k, r * 0.28 * k); g.fill(); }
    if (u > 0.85) head(0.7, 0.7 + (u - 0.85) / 0.15 * 0.3);
  }
  /* small picture of a board (picker thumbnails and rivals' chips) */
  function drawMini(g, D, gg, ff, x, y, cs) {
    const T = TH[D.mp];
    g.fillStyle = T.frameLo; g.fillRect(x - 1, y - 1, cs * GW + 2, cs * GH + 2);
    g.fillStyle = T.mini; g.fillRect(x, y, cs * GW, cs * GH);
    for (let c = 0; c < NC; c++) {
      const X = x + cx(c) * cs, Y = y + cy(c) * cs, k = D.k[c];
      if (k === K_ROCK) { g.fillStyle = T.rockLo; g.fillRect(X + cs * 0.1, Y + cs * 0.1, cs * 0.8, cs * 0.8); }
      else if (k === K_FLOWER) { g.fillStyle = (ff && ff[c]) ? '#ff8fc0' : '#8a6a3a'; g.fillRect(X, Y, cs * 0.34, cs * 0.34); }
      else if (k === K_SRC || k === K_DRAIN) {
        g.fillStyle = k === K_SRC ? '#7fd0ff' : '#14335a'; g.fillRect(X + cs * 0.1, Y + cs * 0.1, cs * 0.8, cs * 0.8);
        const d = k === K_SRC ? D.sdir : D.ddir; g.fillRect(X + cs * (0.35 + DX[d] * 0.4), Y + cs * (0.35 + DY[d] * 0.4), cs * 0.3, cs * 0.3);
      }
      const p = gg[c]; if (!p) continue;
      for (const [s, e, bit] of axesOf(p)) {
        g.strokeStyle = ff && (ff[c] & bit) ? '#59b8ff' : (D.g0[c] ? T.fxBody : T.body);
        g.lineWidth = Math.max(1, cs * 0.34); g.lineCap = 'butt'; g.lineJoin = 'miter';
        g.beginPath(); g.moveTo(X + SP[s][0] * cs, Y + SP[s][1] * cs); g.lineTo(X + cs / 2, Y + cs / 2); g.lineTo(X + SP[e][0] * cs, Y + SP[e][1] * cs); g.stroke();
      }
    }
  }
  const CSS = `
.pp-go{position:absolute;z-index:3;height:50px;border-radius:14px;border:1.5px solid rgba(227,174,69,.75);background:linear-gradient(#3a2f52,#2a2140);
  color:#f2e9d8;font:700 14px var(--f-body,sans-serif);display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.1;
  touch-action:manipulation;-webkit-user-select:none;user-select:none;cursor:pointer;box-shadow:0 3px 10px rgba(0,0,0,.4);padding:0 6px;white-space:nowrap;overflow:hidden}
.pp-go small{font:600 10.5px var(--f-body,sans-serif);color:#c9bcd6;margin-top:3px}
.pp-go.arm{background:linear-gradient(#f0c060,#c8902a);color:#1b1424;border-color:#ffe08a}
.pp-go.arm small{color:#3a2a10}
.pp-go:disabled{opacity:.5;cursor:default}
.pp-go[hidden]{display:none}
.pp-go:active:not(:disabled){transform:translateY(1px)}
.pp-pick{position:absolute;inset:0;z-index:4;overflow-y:auto;background:rgba(18,14,24,.96);padding:12px 12px 24px;-webkit-overflow-scrolling:touch;touch-action:pan-y}
.pp-pick h3{margin:2px 0 2px;font:400 20px var(--f-display,sans-serif);color:var(--ink,#f2e9d8)}
.pp-pick .sub{color:var(--muted,#ab9fb8);font:500 12px var(--f-body,sans-serif);margin:0 0 10px;line-height:1.4}
.pp-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.pp-st{position:relative;display:flex;flex-direction:column;align-items:center;gap:2px;padding:7px 3px 6px;border-radius:12px;background:#2e2640;
  border:1.5px solid rgba(255,255,255,.06);color:var(--ink,#f2e9d8);font:600 11px var(--f-body,sans-serif);cursor:pointer;min-height:44px}
.pp-st:active{transform:translateY(1px)}
.pp-st.next{border-color:#e3ae45;box-shadow:0 0 0 2px rgba(227,174,69,.25)}
.pp-st canvas{border-radius:4px;display:block}
.pp-st .nm{line-height:1.15;text-align:center;word-break:keep-all;min-height:2.3em;display:flex;align-items:center}
.pp-st .stars{color:#ffd24a;letter-spacing:1px;font-size:11px;line-height:1}
.pp-st .stars i{color:rgba(242,233,216,.22);font-style:normal}
.pp-st .bt{font:500 10px var(--f-mono,monospace);color:var(--muted,#ab9fb8)}
.pp-st .no{position:absolute;left:5px;top:3px;font:700 11px var(--f-mono,monospace);color:#e3ae45;text-shadow:0 1px 2px #000}
.pp-rand{display:block;width:100%;margin-top:12px}
`;
  const KEYN = { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Space: '스페이스', Enter: 'Enter' };
  const WHY = { rock: '돌·벽에는 못 놓아요', block: '여기는 못 놓아요', fixed: '고정 관은 못 바꿔요', wet: '물이 찬 관은 못 바꿔요', busy: '바꿔 끼우는 중…' };

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const DPR = () => Math.min(2.5, cv.dpr || 1);
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    let st = null;
    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    const isBot = (s) => { const p = api.players[s]; return !!p && (!!p.ai || (auto() && isMine(s))); };

    let key = null, D = null, KS = [], AIs = [], view = 0, lay = null, tl = -READY;
    let parts = [], floats = [], ripples = [], puff = [], shake = 0, endWait = 0, endSeen = false, hostT = 0, pickRid = -1, pick = null;
    let statC = null, statK = '', pipeC = null, pipeK = '', trc = null, cursor = -1, hover = -1, kbUsed = false, armT = 0, armWhat = '';
    let warnT = 0, bestNew = false, saved = false, pubT = 0, lastSig = '', heartT = 0, kbRep = 0, kbDir = '';
    const remote = {}, lastSc = {}, vg = new Uint8Array(NC), vf = new Uint8Array(NC), mg = new Uint8Array(NC), mf = new Uint8Array(NC);

    /* ----- DOM: the 물 틀기 / 빨리 흘리기 button ----- */
    const goBtn = L.h('button', { class: 'pp-go', type: 'button' });
    goBtn.hidden = true;
    goBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
    goBtn.addEventListener('click', () => { pressGo(false); goBtn.blur(); });   // keep Space for 「놓기」, not for this button
    root.appendChild(goBtn);
    let goLbl = '';

    const curKey = () => (st && st.ph !== 'pick' ? st.rid + '.' + st.sd + '.' + st.stg + '.' + st.mp + '.' + st.sp : null);
    function ensureMatch() {
      if (!st || st.ph === 'pick') return;
      const k = curKey();
      if (k === key) return;
      key = k; D = defOf(st); KS = []; AIs = [];
      for (let s = 0; s < st.n; s++) makeBoard(s);
      const m = mine(), fst = KS.findIndex(Boolean);
      view = m.length ? m[0] : (fst >= 0 ? fst : 0);
      parts = []; floats = []; ripples = []; puff = []; shake = 0; endWait = 0; endSeen = false; bestNew = false; saved = false; armT = 0;
      for (const x in remote) delete remote[x];
      for (const x in lastSc) delete lastSc[x];
      tl = st.ph === 'done' ? 9999 : -READY;
      cursor = D.sf; kbUsed = false; statC = null; pipeK = ''; layout();
    }
    function makeBoard(s) {
      if (!simHere(s)) { KS[s] = null; AIs[s] = null; return; }
      KS[s] = newBoard(D);
      const p = api.players[s];
      AIs[s] = isBot(s) ? aiInit(p && p.ai ? (p.lv || 2) : 2, ((st.sd ^ Math.imul(s + 1, 0x9E3779B1)) >>> 0) + st.rid) : null;
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h, n = st ? st.n : 1;
      const hudH = 36, stripH = n > 1 ? 48 : 24, barH = 66;
      const top = hudH + stripH + 8, bottom = h - barH - 4;
      const ts = Math.max(18, Math.floor(Math.min((w - 16) / GW, (bottom - top) / GH)));
      const gw = ts * GW, gh = ts * GH, spare = bottom - top - gh, hintH = spare >= 28 ? 24 : 0;
      const oy = Math.round(top + Math.max(0, (spare - hintH) * 0.45));
      lay = { w, h, hudH, stripH, barH, ts, gw, gh, ox: Math.round((w - gw) / 2), oy, hintH, hintY: oy + gh + 8 + hintH / 2, barY: h - barH, q1: 52, q2: 36 };
      lay.qw = 10 + lay.q1 + 8 + 3 * (lay.q2 + 4);
      const bw = Math.max(110, w - lay.qw - 14);
      goBtn.style.left = (w - bw - 10) + 'px'; goBtn.style.width = bw + 'px'; goBtn.style.bottom = Math.round((barH - 50) / 2) + 'px';
      statC = null; pipeK = '';
    }
    cv.onresize = layout;

    /* ----- static board layer (grass / concrete, rocks, flower beds, source and drain bases) ----- */
    function staticLayer() {
      const sk = key + '|' + lay.ts + '|' + DPR();
      if (statC && statK === sk) return statC;
      const ts = lay.ts, m = 8, d = DPR();
      const c = document.createElement('canvas'); c.width = Math.ceil((lay.gw + m * 2) * d); c.height = Math.ceil((lay.gh + m * 2) * d);
      const g = c.getContext('2d'); g.scale(d, d);
      const T = TH[D.mp], rnd = mkRng(D.sd + 77);
      g.fillStyle = T.frame; rr(g, 0, 0, lay.gw + m * 2, lay.gh + m * 2, 12); g.fill();
      g.strokeStyle = T.frameHi; g.lineWidth = 2; rr(g, 1, 1, lay.gw + m * 2 - 2, lay.gh + m * 2 - 2, 11); g.stroke();
      g.fillStyle = T.frameLo; g.fillRect(m - 2, m - 2, lay.gw + 4, lay.gh + 4);
      for (let cc = 0; cc < NC; cc++) {
        const x = m + cx(cc) * ts, y = m + cy(cc) * ts;
        g.fillStyle = (cx(cc) + cy(cc)) & 1 ? T.bgA : T.bgB; g.fillRect(x, y, ts, ts);
        if (D.mp === 0) { // grass tufts
          g.strokeStyle = T.tuft; g.lineWidth = 1;
          for (let i = 0; i < 4; i++) { const px = x + 3 + rnd() * (ts - 6), py = y + 5 + rnd() * (ts - 8); g.beginPath(); g.moveTo(px, py); g.lineTo(px - 1.5, py - 3.5); g.moveTo(px, py); g.lineTo(px + 1.5, py - 3); g.stroke(); }
        } else { // concrete slab joints + stains
          g.strokeStyle = 'rgba(0,0,0,.22)'; g.lineWidth = 1; g.strokeRect(x + 0.5, y + 0.5, ts - 1, ts - 1);
          if (rnd() < 0.3) { g.fillStyle = 'rgba(0,0,0,.08)'; circ(g, x + ts * (0.2 + rnd() * 0.6), y + ts * (0.2 + rnd() * 0.6), ts * (0.1 + rnd() * 0.12)); g.fill(); }
        }
        const k = D.k[cc];
        if (k === K_ROCK) {
          if (D.mp === 0) {
            for (const [u, v, r] of [[0.38, 0.55, 0.28], [0.66, 0.4, 0.22], [0.64, 0.72, 0.16]]) {
              g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(x + u * ts + 2, y + v * ts + 3, r * ts, r * ts * 0.8, 0, 0, TAU); g.fill();
              g.fillStyle = T.rockLo; g.beginPath(); g.ellipse(x + u * ts, y + v * ts, r * ts, r * ts * 0.8, 0, 0, TAU); g.fill();
              g.fillStyle = T.rock; g.beginPath(); g.ellipse(x + u * ts - 1, y + v * ts - 1.5, r * ts * 0.88, r * ts * 0.66, 0, 0, TAU); g.fill();
              g.fillStyle = T.rockHi; g.beginPath(); g.ellipse(x + (u - r * 0.35) * ts, y + (v - r * 0.35) * ts, r * ts * 0.35, r * ts * 0.2, -0.5, 0, TAU); g.fill();
            }
          } else {
            g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x + 4, y + 6, ts - 6, ts - 7);
            g.fillStyle = T.rockLo; g.fillRect(x + 2, y + 2, ts - 4, ts - 4);
            const bh = (ts - 4) / 4, bw = (ts - 4) / 2;
            for (let r = 0; r < 4; r++) for (let q = -1; q < 3; q++) {
              const bx = x + 2 + (q + (r & 1 ? 0.5 : 0)) * bw;
              const x0 = Math.max(x + 3, bx + 1), x1 = Math.min(x + ts - 3, bx + bw - 1); if (x1 <= x0) continue;
              g.fillStyle = (r + q) & 1 ? T.rock : T.rockHi; g.fillRect(x0, y + 2 + r * bh + 1, x1 - x0, bh - 2);
            }
          }
        } else if (k === K_FLOWER) { // flower bed / planter corners (they bloom when water passes)
          for (const [u, v] of [[0.16, 0.16], [0.84, 0.16], [0.16, 0.84], [0.84, 0.84]]) {
            if (D.mp === 0) { g.fillStyle = '#4e321c'; circ(g, x + u * ts, y + v * ts, ts * 0.13); g.fill(); g.fillStyle = '#6e4c2a'; circ(g, x + u * ts - 1, y + v * ts - 1, ts * 0.09); g.fill(); }
            else { g.fillStyle = '#3e2414'; g.fillRect(x + u * ts - ts * 0.13, y + v * ts - ts * 0.13, ts * 0.26, ts * 0.26); g.fillStyle = '#6e4a2a'; g.fillRect(x + u * ts - ts * 0.1, y + v * ts - ts * 0.1, ts * 0.2, ts * 0.2); }
            g.strokeStyle = '#8fd05a'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(x + u * ts, y + v * ts + 2); g.lineTo(x + u * ts, y + v * ts - ts * 0.08); g.stroke();
            g.fillStyle = '#8fd05a'; g.beginPath(); g.ellipse(x + u * ts + 2, y + v * ts - ts * 0.06, 2.2, 1.2, -0.5, 0, TAU); g.fill();
          }
        }
      }
      // drain: pond (garden) / sewer grate (city), with its inlet stub
      {
        const x = m + cx(D.drain) * ts, y = m + cy(D.drain) * ts, c0 = x + ts / 2, c1 = y + ts / 2;
        strokeStub(g, D.ddir, x, y, ts, T);
        if (D.mp === 0) {
          g.fillStyle = '#2a5a2a'; g.beginPath(); g.ellipse(c0, c1 + 1, ts * 0.42, ts * 0.36, 0, 0, TAU); g.fill();
          g.fillStyle = '#1d5a8a'; g.beginPath(); g.ellipse(c0, c1, ts * 0.37, ts * 0.31, 0, 0, TAU); g.fill();
          g.fillStyle = '#3a86c2'; g.beginPath(); g.ellipse(c0 - ts * 0.06, c1 - ts * 0.05, ts * 0.24, ts * 0.17, 0, 0, TAU); g.fill();
          g.fillStyle = '#5fae4a'; g.beginPath(); g.moveTo(c0 + ts * 0.12, c1 + ts * 0.08); g.arc(c0 + ts * 0.12, c1 + ts * 0.08, ts * 0.12, 0.4, TAU - 0.2); g.closePath(); g.fill();
          g.fillStyle = '#ff9ac8'; circ(g, c0 - ts * 0.16, c1 + ts * 0.1, ts * 0.05); g.fill();
        } else {
          g.fillStyle = '#23262c'; circ(g, c0, c1, ts * 0.36); g.fill();
          g.strokeStyle = '#6b7280'; g.lineWidth = 2; circ(g, c0, c1, ts * 0.36); g.stroke();
          g.strokeStyle = '#4a505a'; g.lineWidth = 2.2;
          for (let i = -2; i <= 2; i++) { const yy = c1 + i * ts * 0.12, hw = Math.sqrt(Math.max(0, (ts * 0.3) ** 2 - (i * ts * 0.12) ** 2)); g.beginPath(); g.moveTo(c0 - hw, yy); g.lineTo(c0 + hw, yy); g.stroke(); }
        }
      }
      // source tank base (the water level is drawn live)
      {
        const x = m + cx(D.src) * ts, y = m + cy(D.src) * ts, c0 = x + ts / 2, c1 = y + ts / 2;
        strokeStub(g, D.sdir, x, y, ts, T);
        g.fillStyle = 'rgba(0,0,0,.35)'; circ(g, c0 + 2, c1 + 3, ts * 0.4); g.fill();
        g.fillStyle = D.mp === 0 ? '#7a6a58' : '#5b6672'; circ(g, c0, c1, ts * 0.4); g.fill();
        g.fillStyle = D.mp === 0 ? '#b09a7e' : '#8b98a6'; circ(g, c0, c1, ts * 0.34); g.fill();
        g.fillStyle = '#1c2430'; circ(g, c0, c1, ts * 0.27); g.fill();
      }
      statC = c; statK = sk;
      return c;
    }
    function strokeStub(g, d, x, y, ts, T) { // short pipe from the centre to side d
      const pts = [[0.5, 0.5], SP[d]], pw = ts * 0.46;
      strokeRange(g, pts, x + 1, y + 2, ts, 0, 1, 'rgba(0,0,0,.3)', pw);
      strokeRange(g, pts, x, y, ts, 0, 1, T.rim, pw);
      strokeRange(g, pts, x, y, ts, 0, 1, T.body, pw * 0.74);
      strokeRange(g, pts, x, y, ts, 0, 1, T.ch, ts * 0.18);
      g.fillStyle = T.rim; flange(g, d, x, y, ts, pw);
    }

    /* ----- pipes layer (redrawn only when a piece is placed or a cell gets wet) ----- */
    function viewArrays() { // g / fl of the board on screen (own simulation or a rival's published string)
      const B = KS[view];
      if (B) return { g: B.g, fl: B.fl, sig: 'L' + view + '.' + B.ver };
      const r = remote[view];
      decB(r ? r.b : '', vg, vf);
      return { g: vg, fl: vf, sig: 'R' + view + '.' + (r ? r.b : '') };
    }
    function pipeLayer(A) {
      const sk = key + '|' + lay.ts + '|' + DPR() + '|' + A.sig;
      if (pipeC && pipeK === sk) return pipeC;
      const ts = lay.ts, d = DPR(), T = TH[D.mp];
      const c = pipeC || document.createElement('canvas');
      c.width = Math.ceil(lay.gw * d); c.height = Math.ceil(lay.gh * d);
      const g = c.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, lay.gw, lay.gh);
      for (let cc = 0; cc < NC; cc++) { const p = A.g[cc]; if (p) drawPipe(g, p, cx(cc) * ts, cy(cc) * ts, ts, T, !!D.g0[cc], A.fl[cc]); }
      for (let cc = 0; cc < NC; cc++) if (D.k[cc] === K_FLOWER && A.fl[cc]) bloom(g, cx(cc) * ts, cy(cc) * ts, ts, cc);
      pipeC = c; pipeK = sk;
      return c;
    }
    function bloom(g, x, y, ts, seed) {
      const cols = ['#ff7fae', '#ffd24a', '#c99bff', '#ff9a6a'];
      [[0.16, 0.16], [0.84, 0.16], [0.16, 0.84], [0.84, 0.84]].forEach(([u, v], i) => {
        const X0 = x + u * ts, Y0 = y + v * ts, r = ts * 0.075;
        g.fillStyle = cols[(seed + i) % 4];
        for (let k = 0; k < 5; k++) { const a = k / 5 * TAU; circ(g, X0 + Math.cos(a) * r, Y0 + Math.sin(a) * r, r * 0.75); g.fill(); }
        g.fillStyle = '#fff3b0'; circ(g, X0, Y0, r * 0.55); g.fill();
      });
    }

    /* ----- solo stage picker ----- */
    function bests() { try { return JSON.parse(localStorage.getItem('lounge.pipes.best') || '{}') || {}; } catch (e) { return {}; } }
    function saveBest(id, sc, stars) {
      if (!(id >= 0 && id < STAGES.length)) return false;
      const b = bests(), o = Array.isArray(b[id]) ? b[id] : [0, 0]; if (o[0] >= sc && o[1] >= stars) return false;
      b[id] = [Math.max(o[0], sc), Math.max(o[1], stars)];
      try { localStorage.setItem('lounge.pipes.best', JSON.stringify(b)); } catch (e) {}
      return sc > o[0];
    }
    function thumb(Dd, wpx) {
      const hpx = Math.round(wpx * GH / GW), c = L.h('canvas'), d = Math.min(2, window.devicePixelRatio || 1);
      c.width = Math.round(wpx * d); c.height = Math.round(hpx * d); c.style.width = wpx + 'px'; c.style.height = hpx + 'px';
      const g = c.getContext('2d'); g.scale(d, d);
      drawMini(g, Dd, Dd.g0, null, 1, 1, (wpx - 2) / GW);
      return c;
    }
    function buildPicker() {
      if (pick) return;
      const canPick = host() && mine().length > 0 && !auto();
      const B = bests(), bs = (i) => (Array.isArray(B[i]) ? B[i] : [0, 0]);
      let next = STAGES.findIndex((_, i) => !(bs(i)[1] > 0));
      if (next < 0) next = STAGES.findIndex((_, i) => bs(i)[1] < 3);
      const grid = L.h('div', { class: 'pp-grid' }), wpx = Math.max(34, Math.min(52, Math.floor(((lay ? lay.w : 360) - 48) / 4) - 20));
      const go = (id) => { if (!canPick || !st || st.ph !== 'pick') return; api.sfx('click'); api.buzz(15); api.setState(startStage(st, id)); };
      let nextEl = null;
      STAGES.forEach((S, i) => {
        const b0 = bs(i), n = U.clamp(b0[1] | 0, 0, 3);
        const stars = L.h('div', { class: 'stars' }); stars.innerHTML = '★'.repeat(n) + '<i>' + '★'.repeat(3 - n) + '</i>';
        const b = L.h('button', { class: 'pp-st' + (i === next ? ' next' : ''), type: 'button', 'aria-label': (i + 1) + '번 ' + S.n, disabled: !canPick },
          L.h('span', { class: 'no', text: String(i + 1) }), thumb(genBoard(S), wpx), L.h('span', { class: 'nm', text: S.n }), stars,
          L.h('span', { class: 'bt', text: b0[0] > 0 ? b0[0] + '점' : '기록 없음' }));
        b.onclick = () => go(i);
        if (i === next) nextEl = b;
        grid.append(b);
      });
      const rnd = L.h('button', { class: 'btn pp-rand', type: 'button', text: '무작위 판 · 매번 새로 만들어요', disabled: !canPick });
      rnd.onclick = () => go(1000);
      const el = L.h('div', { class: 'pp-pick' }, L.h('h3', { text: '스테이지 고르기' }),
        L.h('p', { class: 'sub', text: canPick ? '연못·하수구까지 이으면 ★, 점수가 높으면 ★★·★★★. 금테 칸이 다음 도전이에요.' : '고르는 중…' }), grid, rnd);
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el };
      if (nextEl) setTimeout(() => { try { nextEl.scrollIntoView({ block: 'nearest' }); } catch (e) {} }, 30);
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } }
    function hostPickFlow(rdt) {
      if (!host() || !st || st.ph !== 'pick') return;
      if (pickRid !== st.rid) { pickRid = st.rid; hostT = 0; }
      if (!mine().length || auto()) { hostT += rdt * SPD(); if (hostT > 1.2) { hostT = -1e9; api.setState(startStage(st, auto() ? 0 : U.rand(STAGES.length))); } }
    }

    /* ----- input ----- */
    const myB = () => { const m = mine()[0]; return m != null ? KS[m] : null; };
    const canCtl = () => !!st && st.ph === 'play' && isMine(view) && !auto() && !!KS[view] && tl >= 0 && KS[view].ph < 2;
    function cellAt(p) {
      if (!lay) return -1;
      const fx = (p.x - lay.ox) / lay.ts, fy = (p.y - lay.oy) / lay.ts;
      if (fx < 0 || fy < 0 || fx >= GW || fy >= GH) return -1;
      return (fy | 0) * GW + (fx | 0);
    }
    function pop(c, text, col, big) { floats.push({ x: cx(c) + 0.5, y: cy(c) + 0.2, text, col: col || '#fff3c0', t: 1.2, T: 1.2, big: !!big }); if (floats.length > 10) floats.shift(); }
    function tryPlace(c) {
      if (!canCtl() || c < 0) return;
      const r = placeB(KS[view], c);
      if (r === 'put' || r === 'rep' || r === 'over' || r === 'out') return;
      sfxG('tick', 80); api.buzz(12);
      if (r !== 'busy' || !floats.some((q) => q.why)) { pop(c, WHY[r] || '못 놓아요', '#ffc0b0'); floats[floats.length - 1].why = 1; }
      ripples.push({ c, t: 0.3, T: 0.3, col: '#ff6a55' });
    }
    function chipAt(p) {
      if (!st || st.n < 2 || p.y < lay.hudH || p.y > lay.hudH + lay.stripH) return -1;
      const cw = (lay.w - 12) / st.n, i = Math.floor((p.x - 6) / cw);
      return i >= 0 && i < st.n ? i : -1;
    }
    const canWatch = () => { const M = myB(); return !M || M.ph >= 2 || auto(); };
    function setView(s) {
      if (s === view) return;
      if (!(KS[s] || remote[s])) { api.toast('아직 그 판 정보가 없어요'); return; }
      view = s; pipeK = ''; api.sfx('click');
    }
    function onDown(e) {
      if (!st || !lay) return;
      const p = cv.local(e);
      e.preventDefault();
      if (st.ph === 'play' && tl < -0.2 && st.n === 1 && !api.online) { tl = -0.01; return; }   // solo: tap skips the tip
      const ch = chipAt(p);
      if (ch >= 0) {
        if (canWatch() || ch === mine()[0]) setView(ch);
        else api.toast('내 물길이 끝나면 다른 판을 볼 수 있어요');
        return;
      }
      const c = cellAt(p);
      if (c >= 0) { if (e.pointerType === 'mouse') { hover = c; kbUsed = false; } tryPlace(c); }
    }
    function onMove(e) { if (!lay || e.pointerType !== 'mouse') return; const c = cellAt(cv.local(e)); if (c !== hover) { hover = c; if (c >= 0) kbUsed = false; } }
    function onLeave() { hover = -1; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerleave', onLeave);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);

    function pressGo(direct) {
      const B = KS[view];
      if (!canCtl() || !B) return;
      const what = B.ph === 0 ? 'go' : (B.ph === 1 && !B.fast ? 'fast' : '');
      if (!what) return;
      if (!direct && !(armT > 0 && armWhat === what)) { armT = 2.2; armWhat = what; api.sfx('click'); api.buzz(8); return; }
      armT = 0;
      if (what === 'go') goB(B); else fastB(B);
    }
    function syncBtn() {
      const B = KS[view], show = !!B && isMine(view) && !auto() && !!st && st.ph === 'play';
      let lbl;
      if (!show) lbl = 'hide';
      else if (B.ph === 0) lbl = armT > 0 && armWhat === 'go' ? 'go-arm' : 'go';
      else if (B.ph === 1) lbl = B.fast ? 'fast-on' : armT > 0 && armWhat === 'fast' ? 'fast-arm' : 'fast';
      else lbl = B.ph === 3 ? 'done-ok' : 'done-leak';
      if (show && tl < 0) lbl += '-wait';
      if (lbl === goLbl) return;
      goLbl = lbl;
      goBtn.hidden = lbl === 'hide';
      goBtn.classList.toggle('arm', lbl.indexOf('-arm') >= 0);
      goBtn.disabled = lbl.indexOf('wait') >= 0 || lbl === 'fast-on' || lbl.indexOf('done') === 0;
      const H = {
        go: '물 틀기 ▶<small>지금 바로 흘려요</small>', 'go-arm': '한 번 더 누르면<small>물이 나와요</small>',
        fast: '빨리 흘리기 ⏩<small>남은 칸 점수 ×2</small>', 'fast-arm': '한 번 더 누르면<small>빨라져요 · 되돌릴 수 없음</small>',
        'fast-on': '빨리 흐르는 중 ⏩<small>칸마다 20점</small>', 'done-ok': '도착!<small>잘했어요</small>', 'done-leak': '물이 샜어요<small>여기까지</small>',
      };
      goBtn.innerHTML = H[lbl.replace('-wait', '')] || H.go;
    }

    /* keyboard / gamepad: arrows move a cursor, 놓기 drops the next piece there, 물 틀기·빨리 = the button (no confirm) */
    const KDIR = { up: 0, right: 1, down: 2, left: 3 };
    function moveCursor(d) {
      if (cursor < 0) cursor = D ? D.sf : 0;
      const n = nb(cursor, d); if (n >= 0) cursor = n;
      kbUsed = true;
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !st || !D) return;
      if (id in KDIR) { if (!kbUsed) { kbUsed = true; hover = -1; if (trc && trc.c >= 0) { cursor = trc.c; return; } } moveCursor(KDIR[id]); kbDir = id; kbRep = 0.32; return; }
      if (id === 'place') { if (!kbUsed) { kbUsed = true; if (trc && trc.c >= 0) cursor = trc.c; return; } tryPlace(cursor); return; }
      if (id === 'fast') { pressGo(true); return; }
      if (id === 'jump') { kbUsed = true; hover = -1; const t = trc; if (t && (t.c >= 0 || t.bc >= 0)) cursor = t.c >= 0 ? t.c : t.bc; api.sfx('tick'); return; }
      if (id === 'view') {
        if (!canWatch()) { api.toast('내 물길이 끝나면 다른 판을 볼 수 있어요'); return; }
        const idx = []; for (let s = 0; s < st.n; s++) if (KS[s] || remote[s]) idx.push(s);
        if (idx.length > 1) setView(idx[(idx.indexOf(view) + 1) % idx.length]);
      }
    }) : () => {};
    function kbTick(rdt) {
      if (!api.input || !kbDir) return;
      if (!api.input.held(kbDir)) { kbDir = ''; return; }
      kbRep -= rdt; if (kbRep <= 0) { kbRep = 0.11; moveCursor(KDIR[kbDir]); }
    }

    /* ----- effects ----- */
    const lastSfx = {};
    function sfxG(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 50)) return; lastSfx[n] = t; api.sfx(n); }
    function burst(x, y, cols, n, sp, life, kind) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: life, T: life, c: cols[i % cols.length], k: kind || 'dot', r: 0.04 + Math.random() * 0.05 }); }
      if (parts.length > 220) parts.splice(0, parts.length - 220);
    }
    function onEvents(B) {
      const me = isMine(view);
      for (const e of B.ev) {
        switch (e.k) {
          case 'put': sfxG('click', 40); if (me) api.buzz(8); ripples.push({ c: e.c, t: 0.28, T: 0.28, col: '#ffe08a' }); burst(cx(e.c) + 0.5, cy(e.c) + 0.5, ['#d9c7a0', '#9a8a70'], 5, 1.2, 0.3); break;
          case 'rep': sfxG('thud', 60); if (me) api.buzz(22); puff.push({ c: e.c, p: e.old, t: 0.45, T: 0.45 }); burst(cx(e.c) + 0.5, cy(e.c) + 0.5, ['#cfc6b8', '#8a8070'], 10, 2, 0.45); pop(e.c, '교체!', '#ffd0a0'); break;
          case 'go': sfxG('pop', 80); break;
          case 'flow': sfxG('whoosh', 80); if (me) api.buzz(25); pop(D.src, '물이 나와요!', '#bfe8ff', true); shake = 0.3; break;
          case 'fill': if (B.fast) sfxG('tick', 70); break;
          case 'flower': sfxG('chip', 60); if (me) api.buzz(12); burst(cx(e.c) + 0.5, cy(e.c) + 0.5, ['#ff7fae', '#ffd24a', '#c99bff', '#fff'], 14, 2.2, 0.7, 'petal'); pop(e.c, '꽃 +30', '#ffb0d8'); break;
          case 'loop': sfxG('pop', 60); if (me) api.buzz([15, 30, 15]); burst(cx(e.c) + 0.5, cy(e.c) + 0.5, ['#9fe8ff', '#ffe08a'], 12, 2.4, 0.6); pop(e.c, '고리 +50', '#ffe08a', true); break;
          case 'fast': sfxG('whoosh', 80); if (me) api.buzz(20); break;
          case 'leak': {
            sfxG('lose', 200); if (me) api.buzz([40, 40, 80]); shake = 0.7; B.lkT = B.t;
            const ex = cx(e.c) + 0.5 + DX[e.d] * 0.5, ey = cy(e.c) + 0.5 + DY[e.d] * 0.5;
            floats.push({ x: ex, y: ey - 0.3, text: '물이 새요!', col: '#ffb0a0', t: 1.8, T: 1.8, big: true });
            break;
          }
          case 'drain': sfxG('win', 200); if (me) api.buzz([20, 30, 50]); burst(cx(e.c) + 0.5, cy(e.c) + 0.5, ['#9fe8ff', '#2d8fe8', '#ffffff', '#ffe08a'], 26, 2.8, 0.9); pop(e.c, goalName(D.mp) + ' 도착 +100', '#ffe08a', true); break;
        }
      }
      B.ev.length = 0;
    }
    function leakSpray(lk, rdt) { // water keeps spurting from the open end
      if (!lk || Math.random() > rdt * 30) return;
      const d = lk.d, ex = cx(lk.c) + 0.5 + DX[d] * 0.5, ey = cy(lk.c) + 0.5 + DY[d] * 0.5;
      const a = Math.atan2(DY[d], DX[d]) + (Math.random() - 0.5) * 1.1, v = 1.4 + Math.random() * 1.6;
      parts.push({ x: ex, y: ey, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0.5, T: 0.5, c: Math.random() < 0.5 ? '#7fd0ff' : '#d8f2ff', k: 'drop', r: 0.05 });
    }
    const leakOf = (s) => { const B = KS[s]; if (B) return B.lk; const r = remote[s]; return r && r.f === 1 && r.x >= 0 ? { c: r.x >> 2, d: r.x & 3 } : null; };

    /* ----- online: rows = [score, length, f, boardString, leak, fast, headCell, flowers, loops] ----- */
    function rowOfB(B) { return [B.sc, B.ln, B.ph === 2 ? 1 : B.ph === 3 ? 2 : 0, encB(B), B.lk ? B.lk.c * 4 + B.lk.d : -1, B.fast, B.ph === 1 ? B.hc : -1, B.fw, B.lp]; }
    function rowOf(s) {
      if (st && st.ph === 'done' && Array.isArray(st.res)) {
        const r = st.res.find((x) => x[0] === s);
        if (r) { const B = KS[s], o = remote[s]; return [r[1], r[2], r[3], B ? encB(B) : o ? o.b : '', B && B.lk ? B.lk.c * 4 + B.lk.d : o ? o.x : -1, 0, -1, r[4], r[5]]; }
      }
      const B = KS[s]; if (B) return rowOfB(B);
      const o = remote[s]; return o ? [o.sc, o.ln, o.f, o.b, o.x, o.fa, o.hc, o.fw, o.lp] : [0, 0, 0, '', -1, 0, -1, 0, 0];
    }
    function takeRow(s, a) {
      if (!Array.isArray(a)) return;
      const o = remote[s] || (remote[s] = { at: tl, b: '' });
      const b = typeof a[3] === 'string' ? a[3].slice(0, NC) : '';
      if (o.b !== b || o.f !== (a[2] | 0)) o.at = tl;
      Object.assign(o, { sc: a[0] | 0, ln: a[1] | 0, f: a[2] | 0, b, x: a[4] == null ? -1 : a[4] | 0, fa: a[5] | 0, hc: a[6] == null ? -1 : a[6] | 0, fw: a[7] | 0, lp: a[8] | 0 });
    }
    function pollNet() {
      if (!api.online || !key) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) { const s = +k, o = rem[k]; if (!(s >= 0 && s < st.n) || KS[s] || !o || o.k !== key) continue; takeRow(s, o.r); }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== key) return;
        if (typeof hs.t === 'number' && isFinite(hs.t) && st.ph === 'play') { const d = hs.t - tl; if (Math.abs(d) > 0.6) tl = hs.t; else tl += d * 0.05; }
        if (Array.isArray(hs.r)) hs.r.forEach((a, s) => { if (!KS[s]) takeRow(s, a); });
      }
    }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 0.3;
          const r = []; for (let i = 0; i < st.n; i++) r.push(rowOf(i));
          api.net.hostSend({ k: key, t: Math.round(tl * 100) / 100, r });
        } else {
          const B = myB(); if (!B) return;
          heartT -= rdt;
          if (pubT > 0) return;
          const row = rowOfB(B), sig = row.join('|');
          if (sig === lastSig && heartT > 0) return;
          lastSig = sig; pubT = 0.3; heartT = 1.5;
          api.net.publish({ k: key, r: row });
        }
      } catch (e) {}
    }
    const fOf = (s) => { const B = KS[s]; if (B) return B.ph >= 2 ? (B.ph === 2 ? 1 : 2) : 0; const o = remote[s]; return o ? o.f : 0; };
    function hostEnd(rdt) {
      if (!host() || !st || st.ph !== 'play' || !D || tl < 0) return;
      let ready = true, stale = true;
      for (let s = 0; s < st.n; s++) if (!fOf(s)) { ready = false; if (KS[s] || !remote[s] || tl - remote[s].at < 25) stale = false; }
      const cap = D.cd + NC * D.fill * 2.5 + 40;
      if (!ready && !stale && tl < cap) { endWait = 0; return; }
      endWait += rdt;
      if (endWait > (st.n === 1 ? 1.1 : 1.5)) {
        const rows = []; for (let s = 0; s < st.n; s++) { const r = rowOf(s); rows.push([s, r[0], r[1], fOf(s), r[7], r[8]]); }
        endWait = -1e9;
        api.setState(finish(st, rows));
      }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) { draw(now); return; }
      const dt = rdt * SPD();
      if (st.ph === 'pick') { if (!pick) buildPicker(); hostPickFlow(rdt); syncBtn(); draw(now); return; }
      if (pick) dropPicker();
      ensureMatch();
      if (key && D) {
        const was = tl;
        if (st.ph === 'play') tl += dt;
        pollNet();
        if (was < 0 && tl < 0 && Math.ceil(-was) !== Math.ceil(-tl)) api.sfx('tick');
        if (was < 0 && tl >= 0 && mine().length) { api.sfx('pop'); api.buzz(20); }
        const target = Math.max(0, tl);
        kbTick(rdt);
        for (let s = 0; s < st.n; s++) {
          if (!KS[s] && simHere(s) && st.ph === 'play') makeBoard(s);   // a seat taken over by the host's AI starts here
          const B = KS[s]; if (!B) continue;
          const A = AIs[s], pc = B.ph === 0 ? B.cdEnd - B.t : 99;
          let n = 0;
          while (B.t < target - 1e-6 && n < 240) { const h = Math.min(1 / 30, target - B.t); if (A) aiThink(B, A, h); stepB(B, h); n++; }
          if (isMine(s) && B.ph === 0) { const nc = B.cdEnd - B.t; if (Math.ceil(nc) !== Math.ceil(pc) && nc > 0 && nc <= 3) api.sfx('tick'); }
          if (s !== view) B.ev.length = 0;
        }
        for (let s = 0; s < st.n; s++) { const sc = rowOf(s)[0]; if (lastSc[s] != null && sc - lastSc[s] >= 30 && s !== view) floats.push({ hud: s, text: '+' + (sc - lastSc[s]), col: '#ffe08a', t: 1.1, T: 1.1 }); lastSc[s] = sc; }
        const B = KS[view];
        if (B) { onEvents(B); trc = trace(B, B.g); } else trc = null;
        const M = myB();
        if (M && M.ph >= 2 && !endSeen && !auto()) {
          endSeen = true;
          if (st.n === 1 && !saved && st.stg >= 0 && st.stg < STAGES.length) { saved = true; bestNew = saveBest(st.stg, M.sc, starsOf(st, M.sc, M.ph === 3 ? 2 : 1)); }
        }
        if (B && B.ph === 1 && trc && trc.st === 'dead' && trc.time < 1.6 && isMine(view)) { warnT -= rdt; if (warnT <= 0) { warnT = 0.45; api.sfx('tick'); } } else warnT = 0;
        hostEnd(rdt);
        leakSpray(leakOf(view), rdt);
      }
      if (armT > 0) armT -= rdt;
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; if (q.k === 'drop') q.vy += 4 * rdt; q.vx *= 0.97; q.vy *= 0.97; if (q.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = ripples.length - 1; i >= 0; i--) { ripples[i].t -= rdt; if (ripples[i].t <= 0) ripples.splice(i, 1); }
      for (let i = puff.length - 1; i >= 0; i--) { puff[i].t -= rdt; if (puff[i].t <= 0) puff.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 2.2);
      publish(rdt);
      syncBtn();
      draw(now);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align, base) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    function wrap(t, maxW, font) {
      ctx.font = font; const out = []; let line = '';
      for (const wd of t.split(' ')) { const tryL = line ? line + ' ' + wd : wd; if (ctx.measureText(tryL).width > maxW && line) { out.push(line); line = wd; } else line = tryL; }
      if (line) out.push(line); return out;
    }
    function panel(x, y, w, h) { ctx.fillStyle = 'rgba(18,12,24,.92)'; rr(ctx, x, y, w, h, 14); ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.stroke(); }
    const X = (c) => lay.ox + cx(c) * lay.ts, Y = (c) => lay.oy + cy(c) * lay.ts;
    function drawSource(B, now) {
      const ts = lay.ts, c0 = X(D.src) + ts / 2, c1 = Y(D.src) + ts / 2;
      let lvl = 1;
      if (!B) { const r = remote[view]; lvl = r && (r.f || r.hc >= 0 || r.ln) ? 1 : U.clamp(tl / D.cd, 0, 1); }
      else if (B.ph === 0) lvl = U.clamp(B.t / Math.max(0.01, B.cdEnd), 0, 1);
      const r = ts * 0.27, wob = Math.sin(now / 250) * 1.2, top = c1 + r - lvl * 2 * r - wob;
      ctx.save(); circ(ctx, c0, c1, r); ctx.clip();
      ctx.fillStyle = WAT; ctx.fillRect(c0 - r, top, r * 2, c1 + r - top + 2);
      ctx.fillStyle = 'rgba(169,224,255,.7)'; ctx.fillRect(c0 - r, top, r * 2, 1.5);
      ctx.restore();
      if (B && B.ph === 0 && tl >= 0) { // countdown ring + seconds
        const left = Math.max(0, B.cdEnd - B.t);
        ctx.beginPath(); ctx.arc(c0, c1, ts * 0.44, -Math.PI / 2, -Math.PI / 2 + TAU * lvl); ctx.strokeStyle = left < 4 ? '#ff8a6a' : '#7fd0ff'; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.stroke();
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,8,14,.6)'; ctx.font = '800 ' + Math.round(ts * 0.32) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.strokeText(String(Math.ceil(left)), c0, c1 + 0.5);
        txt(String(Math.ceil(left)), c0, c1 + 0.5, '#fff', '800 ' + Math.round(ts * 0.32) + 'px ' + MONO);
      }
      if (lvl >= 1 && (!B || B.ph > 0)) strokeRange(ctx, [[0.5, 0.5], SP[D.sdir]], X(D.src), Y(D.src), ts, 0.5, 1, WAT, ts * 0.18);
    }
    function drawBoard(now) {
      const ts = lay.ts, B = KS[view], A = viewArrays(), T = TH[D.mp];
      const sh = shake > 0 ? (Math.random() - 0.5) * shake * 5 : 0;
      ctx.save(); ctx.translate(sh, 0);
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, lay.ox - 6, lay.oy - 3, lay.gw + 12, lay.gh + 12, 12); ctx.fill();
      ctx.drawImage(staticLayer(), lay.ox - 8, lay.oy - 8, lay.gw + 16, lay.gh + 16);
      drawSource(B, now);
      ctx.drawImage(pipeLayer(A), lay.ox, lay.oy, lay.gw, lay.gh);
      for (const q of puff) { // swapped-out pieces flying off
        const f = q.t / q.T; ctx.save(); ctx.translate(X(q.c) + ts / 2, Y(q.c) + ts / 2 - (1 - f) * ts * 0.6); ctx.rotate((1 - f) * 0.8); ctx.scale(0.6 + 0.4 * f, 0.6 + 0.4 * f);
        drawPipe(ctx, q.p, -ts / 2, -ts / 2, ts, T, false, 0, f * 0.9); ctx.restore();
      }
      if (B && B.ph === 1) drawWaterPart(ctx, B.g[B.hc], B.hs, X(B.hc), Y(B.hc), ts, B.hp, now);
      else if (!B) { const r = remote[view]; if (r && r.hc >= 0 && !r.f) { ctx.strokeStyle = 'rgba(169,224,255,.85)'; ctx.lineWidth = 2; rr(ctx, X(r.hc) + 2, Y(r.hc) + 2, ts - 4, ts - 4, 6); ctx.stroke(); } }
      if ((B && B.ph === 3) || (!B && remote[view] && remote[view].f === 2)) strokeRange(ctx, [SP[D.ddir], [0.5, 0.5]], X(D.drain), Y(D.drain), ts, 0, 0.55, WAT, ts * 0.18);
      const lk = leakOf(view);
      if (lk) {
        const age = B && B.lkT != null ? U.clamp((B.t - B.lkT) / 1.2, 0, 1) : 1;
        const ex = X(lk.c) + ts / 2 + DX[lk.d] * ts * 0.5, ey = Y(lk.c) + ts / 2 + DY[lk.d] * ts * 0.5;
        const px = ex + DX[lk.d] * ts * 0.3, py = ey + DY[lk.d] * ts * 0.3;
        ctx.save(); rr(ctx, lay.ox - 8, lay.oy - 8, lay.gw + 16, lay.gh + 16, 12); ctx.clip();
        ctx.fillStyle = 'rgba(45,143,232,.5)'; ctx.beginPath(); ctx.ellipse(px, py, ts * 0.75 * age + 2, ts * 0.52 * age + 2, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(169,224,255,.4)'; ctx.beginPath(); ctx.ellipse(px - ts * 0.18 * age, py - ts * 0.12 * age, ts * 0.3 * age + 1, ts * 0.14 * age + 1, 0, 0, TAU); ctx.fill();
        ctx.restore();
        const bl = 0.5 + 0.5 * Math.sin(now / 120);
        ctx.fillStyle = 'rgba(255,90,70,' + (0.5 + 0.4 * bl) + ')'; circ(ctx, ex, ey, ts * 0.12); ctx.fill();
      }
      if (B && trc && B.ph < 2 && isMine(view) && tl >= 0 && !auto()) drawMarker(now);
      for (const q of ripples) { const f = 1 - q.t / q.T; ctx.strokeStyle = q.col; ctx.globalAlpha = 1 - f; ctx.lineWidth = 3; rr(ctx, X(q.c) + 2 - f * 4, Y(q.c) + 2 - f * 4, ts - 4 + f * 8, ts - 4 + f * 8, 8); ctx.stroke(); ctx.globalAlpha = 1; }
      if (canCtl()) { // PC: hover / keyboard cursor with a ghost of the next piece
        const cc = kbUsed ? cursor : hover;
        if (cc >= 0) {
          const ok = !canPlace(B, cc);
          if (ok) { ctx.fillStyle = 'rgba(20,14,24,.35)'; ctx.fillRect(X(cc), Y(cc), ts, ts); drawPipe(ctx, pieceAt(D, B.qi), X(cc), Y(cc), ts, T, false, 0, 0.6); }
          ctx.strokeStyle = ok ? (B.g[cc] ? '#ffb04a' : '#9dffb0') : '#ff7a6a'; ctx.lineWidth = 2.5; ctx.setLineDash([5, 4]); rr(ctx, X(cc) + 2, Y(cc) + 2, ts - 4, ts - 4, 7); ctx.stroke(); ctx.setLineDash([]);
        }
      }
      ctx.restore();
      for (const q of parts) {
        const f = q.t / q.T, x = lay.ox + q.x * ts, y = lay.oy + q.y * ts;
        ctx.globalAlpha = Math.min(1, f * 1.6); ctx.fillStyle = q.c;
        if (q.k === 'petal') { ctx.beginPath(); ctx.ellipse(x, y, q.r * ts * 1.4, q.r * ts * 0.7, q.t * 8, 0, TAU); ctx.fill(); }
        else { circ(ctx, x, y, q.r * ts); ctx.fill(); }
      }
      ctx.globalAlpha = 1;
      for (const q of floats) {
        if (q.hud != null) continue;
        const f = q.t / q.T, x = lay.ox + q.x * ts, y = Math.max(lay.oy + 6, lay.oy + q.y * ts - (1 - f) * ts * 0.7);
        ctx.globalAlpha = Math.min(1, f * 2.2);
        const font = (q.big ? '800 15px ' : '700 12px ') + FONT;
        ctx.font = font; const tw = ctx.measureText(q.text).width;
        const xx = U.clamp(x, tw / 2 + 8, lay.w - tw / 2 - 8);
        ctx.fillStyle = 'rgba(15,10,20,.75)'; rr(ctx, xx - tw / 2 - 6, y - 11, tw + 12, 22, 9); ctx.fill();
        txt(q.text, xx, y + 0.5, q.col, font);
      }
      ctx.globalAlpha = 1;
    }
    function drawMarker(now) {
      const ts = lay.ts, t = trc, pulse = 0.5 + 0.5 * Math.sin(now / 160);
      if (t.st === 'open') {
        const c = t.c, x = X(c), y = Y(c), urgent = t.time < D.fill * 0.9;
        const col = urgent ? '255,110,80' : '255,214,90';
        ctx.strokeStyle = 'rgba(' + col + ',' + (0.55 + 0.4 * pulse) + ')'; ctx.lineWidth = 3; rr(ctx, x + 3, y + 3, ts - 6, ts - 6, 9); ctx.stroke();
        const s = t.s, ax = x + ts / 2 + DX[s] * ts * 0.34, ay = y + ts / 2 + DY[s] * ts * 0.34, a = Math.atan2(-DY[s], -DX[s]), k = ts * 0.13;
        ctx.fillStyle = 'rgba(' + col + ',.95)'; ctx.beginPath(); ctx.moveTo(ax + Math.cos(a) * k, ay + Math.sin(a) * k); ctx.lineTo(ax + Math.cos(a + 2.4) * k, ay + Math.sin(a + 2.4) * k); ctx.lineTo(ax + Math.cos(a - 2.4) * k, ay + Math.sin(a - 2.4) * k); ctx.closePath(); ctx.fill();
        const left = U.clamp(t.time / (D.fill * 3), 0, 1), rx = x + ts - 10, ry = y + 10;
        ctx.beginPath(); ctx.arc(rx, ry, 6, 0, TAU); ctx.fillStyle = 'rgba(20,14,24,.65)'; ctx.fill();
        ctx.beginPath(); ctx.arc(rx, ry, 5, -Math.PI / 2, -Math.PI / 2 + TAU * left); ctx.strokeStyle = 'rgba(' + col + ',1)'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.stroke();
      } else if (t.st === 'dead') {
        if (t.bc >= 0) { const x = X(t.bc), y = Y(t.bc); ctx.strokeStyle = 'rgba(255,90,70,' + (0.5 + 0.45 * pulse) + ')'; ctx.lineWidth = 3; ctx.setLineDash([6, 4]); rr(ctx, x + 3, y + 3, ts - 6, ts - 6, 9); ctx.stroke(); ctx.setLineDash([]); }
        const ex = X(t.lc) + ts / 2 + DX[t.ld] * ts * 0.5, ey = Y(t.lc) + ts / 2 + DY[t.ld] * ts * 0.5;
        ctx.fillStyle = 'rgba(255,90,70,' + (0.45 + 0.5 * pulse) + ')'; circ(ctx, ex, ey, ts * 0.14); ctx.fill();
        txt('!', ex, ey + 0.5, '#fff', '900 ' + Math.round(ts * 0.22) + 'px ' + FONT);
      } else if (t.st === 'drain') {
        const x = X(D.drain), y = Y(D.drain);
        ctx.strokeStyle = 'rgba(157,255,176,' + (0.45 + 0.4 * pulse) + ')'; ctx.lineWidth = 3; rr(ctx, x + 3, y + 3, ts - 6, ts - 6, 9); ctx.stroke();
      }
    }
    function drawHud() {
      const w = lay.w, H = lay.hudH;
      ctx.fillStyle = 'rgba(14,10,20,.6)'; ctx.fillRect(0, 0, w, H);
      const r = rowOf(view), B = KS[view];
      txt(isMine(view) ? '내 점수' : fitText(name(view), 70, '700 10px ' + FONT), 10, 10, '#ab9fb8', '700 10px ' + FONT, 'left');
      txt(String(r[0]), 10, 25, '#ffe08a', '800 18px ' + MONO, 'left');
      ctx.font = '800 18px ' + MONO; const sw = ctx.measureText(String(r[0])).width;
      let s = '', col = '#bfe8ff';
      if (tl < 0) { s = '준비'; col = '#e3ae45'; }
      else if (B) {
        if (B.ph === 0) { s = '물 나오기까지 ' + Math.ceil(Math.max(0, B.cdEnd - B.t)) + '초'; col = B.cdEnd - B.t < 4 ? '#ff9a7a' : '#bfe8ff'; }
        else if (B.ph === 1) { s = B.fast ? '⏩ 빨리 흐르는 중' : '물이 흐르는 중'; col = B.fast ? '#ffe08a' : '#bfe8ff'; }
        else if (B.ph === 3) { s = goalName(D.mp) + ' 도착!'; col = '#9dffb0'; }
        else { s = '물이 샜어요'; col = '#ff9a7a'; }
      } else { const f = r[2]; s = f === 2 ? '도착!' : f === 1 ? '물이 샜어요' : '흐르는 중'; col = f === 2 ? '#9dffb0' : f === 1 ? '#ff9a7a' : '#bfe8ff'; }
      ctx.font = '700 12px ' + FONT; const pw = ctx.measureText(s).width + 18;
      const mid = fitText('길이 ' + r[1] + (r[7] ? ' · 꽃 ' + r[7] : '') + (r[8] ? ' · 고리 ' + r[8] : ''), w - pw - 32 - sw, '600 11px ' + FONT);
      txt(mid, 18 + sw, 25, '#d8cce4', '600 11px ' + FONT, 'left');
      ctx.fillStyle = 'rgba(46,38,64,.95)'; rr(ctx, w - pw - 8, 6, pw, 24, 12); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1.2; ctx.stroke();
      txt(s, w - 8 - pw / 2, 18.5, col, '700 12px ' + FONT);
    }
    function drawStrip() {
      const y0 = lay.hudH, H = lay.stripH, w = lay.w;
      if (st.n === 1) { // star targets
        const p = parOf(st), B = KS[view], sc = B ? B.sc : 0, done = !!B && B.ph === 3;
        const items = [['★', goalName(D.mp) + ' 도착', done], ['★★', p[0] + '점', done && sc >= p[0]], ['★★★', p[1] + '점', done && sc >= p[1]]];
        const cw = (w - 20) / 3;
        items.forEach(([s2, t2, on], i) => txt(s2 + ' ' + t2, 10 + cw * i + cw / 2, y0 + H / 2, on ? '#ffd24a' : '#8a7f98', '700 11px ' + FONT));
        return;
      }
      const cw = (w - 12) / st.n, rows = [];
      for (let s = 0; s < st.n; s++) rows.push(rowOf(s));
      const rank = rows.map((r, s) => s).sort((a, b) => rows[b][0] - rows[a][0] || a - b);
      for (let s = 0; s < st.n; s++) {
        const r = rows[s], x = 6 + cw * s, sel = s === view, P = Pl(s);
        ctx.fillStyle = sel ? 'rgba(227,174,69,.2)' : 'rgba(46,38,64,.85)'; rr(ctx, x + 2, y0 + 3, cw - 4, H - 6, 9); ctx.fill();
        if (sel) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.stroke(); }
        ctx.fillStyle = P.color || '#888'; rr(ctx, x + 2, y0 + 3, 4, H - 6, 2); ctx.fill();
        const cs = Math.min(3.8, (H - 14) / GH), mw = cs * GW;
        if (KS[s]) drawMini(ctx, D, KS[s].g, KS[s].fl, x + 10, y0 + 7, cs);
        else { decB(r[3], mg, mf); drawMini(ctx, D, mg, mf, x + 10, y0 + 7, cs); }
        const tx0 = x + 14 + mw, tw = cw - (tx0 - x) - 4;
        txt(fitText((rank.indexOf(s) + 1) + '. ' + name(s), tw, '700 10px ' + FONT), tx0, y0 + 15, '#f2e9d8', '700 10px ' + FONT, 'left');
        txt(String(r[0]), tx0, y0 + 32, '#ffe08a', '800 13px ' + MONO, 'left');
        ctx.font = '800 13px ' + MONO; const nw = ctx.measureText(String(r[0])).width;
        if (r[2]) txt(r[2] === 2 ? '✓' : '✗', tx0 + nw + 5, y0 + 32, r[2] === 2 ? '#9dffb0' : '#ff9a7a', '800 12px ' + FONT, 'left');
        else if (r[5]) txt('⏩', tx0 + nw + 4, y0 + 32, '#ffe08a', '700 10px ' + FONT, 'left');
      }
      for (const q of floats) {
        if (q.hud == null) continue;
        const f = q.t / q.T, x = 6 + cw * q.hud + cw - 8, y = y0 + 30 - (1 - f) * 8;
        ctx.globalAlpha = Math.min(1, f * 2); ctx.font = '800 11px ' + MONO; const tw = ctx.measureText(q.text).width;
        ctx.fillStyle = 'rgba(20,14,24,.9)'; rr(ctx, x - tw - 8, y - 9, tw + 8, 18, 9); ctx.fill();
        txt(q.text, x - 4, y + 0.5, q.col, '800 11px ' + MONO, 'right'); ctx.globalAlpha = 1;
      }
    }
    function drawQueue() {
      const B = KS[view], T = TH[D.mp], y0 = lay.barY;
      ctx.fillStyle = 'rgba(14,10,20,.55)'; ctx.fillRect(0, y0, lay.w, lay.barH);
      if (!B) { txt(fitText(name(view) + '의 판을 보는 중', lay.w - 24, '600 12px ' + FONT), 12, y0 + lay.barH / 2, '#ab9fb8', '600 12px ' + FONT, 'left'); return; }
      const q1 = lay.q1, q2 = lay.q2, x1 = 10, y1 = y0 + (lay.barH - q1) / 2 + 5;
      ctx.fillStyle = '#2e2640'; rr(ctx, x1, y1, q1, q1, 10); ctx.fill();
      ctx.strokeStyle = B.lock > 0 ? '#ff9a6a' : '#e3ae45'; ctx.lineWidth = 2; ctx.stroke();
      const pad = q1 * 0.1;
      drawPipe(ctx, pieceAt(D, B.qi), x1 + pad, y1 + pad, q1 - pad * 2, T, false, 0, B.ph >= 2 ? 0.35 : 1);
      ctx.fillStyle = '#e3ae45'; rr(ctx, x1 + q1 / 2 - 15, y1 - 8, 30, 14, 7); ctx.fill();
      txt('다음', x1 + q1 / 2, y1 - 1, '#1b1424', '800 10px ' + FONT);
      if (B.lock > 0) { const f = B.lock / REP_T; ctx.fillStyle = 'rgba(20,14,24,.65)'; rr(ctx, x1, y1, q1, q1 * f, 10); ctx.fill(); }
      for (let i = 0; i < 3; i++) {
        const x = x1 + q1 + 8 + i * (q2 + 4), y = y1 + (q1 - q2) / 2 + 4, pp = q2 * 0.1;
        ctx.fillStyle = 'rgba(46,38,64,.8)'; rr(ctx, x, y, q2, q2, 7); ctx.fill();
        drawPipe(ctx, pieceAt(D, B.qi + 1 + i), x + pp, y + pp, q2 - pp * 2, T, false, 0, 0.85 - i * 0.15);
      }
    }
    function drawHint() {
      if (!lay.hintH) return;
      const B = KS[view];
      if (!isMine(view) && mine().length && st.ph === 'play') { txt(fitText(name(view) + '의 판을 보는 중 · 위 칸을 눌러 바꿔요', lay.w - 20, '600 12px ' + FONT), lay.w / 2, lay.hintY, '#c9bcd6', '600 12px ' + FONT); return; }
      if (!B || !isMine(view) || auto() || tl < 0 || B.ph >= 2) return;
      let s = '';
      const t = trc, gn = goalName(D.mp);
      if (t && t.st === 'dead') s = t.bc >= 0 ? '길이 막혔어요! 빨간 칸을 눌러 바꿔 끼워요' : '이대로면 물이 새요! 길을 바꿔요';
      else if (B.ph === 0) s = B.qi < 2 ? '빈 칸을 누르면 「다음」 조각이 놓여요 · 노란 칸부터!' : t && t.st === 'drain' ? goalName(D.mp) + '까지 이어졌어요! 「물 틀기」로 바로 시작' : '물이 나오기 전에 길게 이어 둬요';
      else if (t && t.st === 'open') s = t.time < D.fill * 0.9 ? '서둘러요! 노란 칸에 맞는 조각을' : '노란 칸에 맞는 조각을 놓아요 · ' + gn + '까지!';
      else if (t && t.st === 'drain') s = B.fast ? '물이 ' + gn + '까지 달려가요!' : gn + '까지 이어졌어요! 빨리 흘리면 남은 칸 ×2';
      txt(fitText(s, lay.w - 20, '600 12px ' + FONT), lay.w / 2, lay.hintY, t && t.st === 'dead' ? '#ffb0a0' : '#d8cce4', '600 12px ' + FONT);
    }
    function controlTip() {
      if (kbUsed || (window.matchMedia && window.matchMedia('(pointer:fine)').matches)) {
        const b = (api.input && api.input.bindings) ? api.input.bindings() : [];
        const kn = (id) => { const x = b.find((o) => o.id === id); return x && x.keys[0] ? (KEYN[x.keys[0]] || x.keys[0].replace(/^Key/, '')) : '?'; };
        return '마우스로 칸을 누르거나, 방향키로 칸을 고르고 ' + kn('place') + '로 놓아요. ' + kn('fast') + ' = 물 틀기·빨리 흘리기';
      }
      return '빈 칸을 톡 누르면 「다음」 조각이 놓여요(돌리기 없음). 놓인 조각을 누르면 바꿔 끼워요.';
    }
    function drawReady() {
      const w = Math.min(lay.w - 28, 340), x = (lay.w - w) / 2;
      const S = st.stg >= 0 && st.stg < STAGES.length ? STAGES[st.stg] : null;
      const tip = S ? S.tip : (st.n > 1 ? '모두 같은 판, 같은 조각 순서! 물이 새기 전에 더 길게 이어요.' : '처음 보는 판! 물이 나오는 쪽부터 길을 그려 봐요.');
      const tipFont = '600 13px ' + FONT, ctlFont = '500 12px ' + FONT;
      const tipL = wrap(tip, w - 32, tipFont), ctlL = wrap(controlTip(), w - 32, ctlFont);
      const goalL = wrap('지나간 칸 10점 · 꽃 +30 · 고리 +50 · ' + goalName(D.mp) + ' +100', w - 32, ctlFont);
      const h = 76 + tipL.length * 18 + 8 + ctlL.length * 16 + 6 + goalL.length * 16;
      const y = lay.oy + Math.max(10, (lay.gh - h) * 0.35);
      panel(x, y, w, h);
      txt(S ? '스테이지 ' + (st.stg + 1) : MAPN[D.mp], lay.w / 2, y + 18, '#e3ae45', '700 12px ' + FONT);
      txt(fitText(S ? S.n : (st.n > 1 ? '물길 잇기 레이스' : '무작위 판'), w - 80, '400 22px ' + DISP), lay.w / 2, y + 42, '#f2e9d8', '400 22px ' + DISP);
      let yy = y + 66;
      tipL.forEach((l) => { txt(l, lay.w / 2, yy, '#f2e9d8', tipFont); yy += 18; });
      yy += 8; ctlL.forEach((l) => { txt(l, lay.w / 2, yy, '#c9bcd6', ctlFont); yy += 16; });
      yy += 6; goalL.forEach((l) => { txt(l, lay.w / 2, yy, '#bfe8ff', ctlFont); yy += 16; });
      txt(String(Math.max(1, Math.ceil(-tl))), x + w - 22, y + 20, '#ffd24a', '800 22px ' + MONO);
      if (st.n === 1 && !api.online) { ctx.fillStyle = 'rgba(18,12,24,.8)'; rr(ctx, lay.w / 2 - 62, y + h + 6, 124, 22, 11); ctx.fill(); txt('톡 눌러 바로 시작', lay.w / 2, y + h + 17, '#d8cce4', '600 11px ' + FONT); }
    }
    function drawDone() {
      const B = KS[view];
      if (!B || B.ph < 2 || !isMine(view) || auto()) return;
      if (B.lkT != null && B.t - B.lkT < 0.9) return;
      const multi = st.n > 1 && st.ph === 'play';
      const w = Math.min(lay.w - 36, 310), hh = multi ? 90 : 72, x = (lay.w - w) / 2, y = lay.oy + lay.ts * 0.5;
      panel(x, y, w, hh);
      const ok = B.ph === 3;
      txt(ok ? goalName(D.mp) + '까지 도착!' : '물이 샜어요', lay.w / 2, y + 24, ok ? '#9dffb0' : '#ffb0a0', '400 22px ' + DISP);
      txt(B.sc + '점 · 길이 ' + B.ln + '칸' + (bestNew ? ' · 최고 기록!' : ''), lay.w / 2, y + 50, '#f2e9d8', '700 14px ' + FONT);
      if (multi) txt(fitText('다른 사람을 기다리는 중… 위 칸을 누르면 그 판을 봐요', w - 16, '600 11px ' + FONT), lay.w / 2, y + 72, '#c9bcd6', '600 11px ' + FONT);
    }
    function draw(now) {
      const w = cv.w, h = cv.h;
      if (!lay || lay.w !== w || lay.h !== h) layout();
      cv.clear();
      if (!lay.bg) { lay.bg = ctx.createRadialGradient(w / 2, h * 0.45, 20, w / 2, h * 0.45, Math.max(w, h) * 0.75); lay.bg.addColorStop(0, '#231d33'); lay.bg.addColorStop(1, '#120e18'); }
      ctx.fillStyle = lay.bg; ctx.fillRect(0, 0, w, h);
      if (!st || st.ph === 'pick') return;
      if (!key || !D) { txt('준비 중…', w / 2, h / 2, '#ab9fb8', '600 14px ' + FONT); return; }
      drawBoard(now);
      drawHud();
      drawStrip();
      drawQueue();
      drawHint();
      if (tl < 0 && st.ph === 'play') drawReady();
      else drawDone();
    }

    const stop = U.loop(frame);
    root._pp = { lay: () => lay, B: () => KS[view], KS: () => KS, tl: () => tl, trc: () => trc, view: () => view, cell: (c) => ({ x: X(c) + lay.ts / 2, y: Y(c) + lay.ts / 2 }) }; // test hook
    return {
      update(state) {
        st = state;
        if (!st) return;
        if (st.ph === 'pick') { key = null; KS = []; D = null; }
        else if (pick) dropPicker();
        if (st.ph === 'done' && key === curKey()) tl = Math.max(tl, 0);
        if (lay && lay.stripH !== (st.n > 1 ? 48 : 24)) layout();
      },
      destroy() {
        stop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerleave', onLeave);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        dropPicker();
        goBtn.remove();
        cv.destroy(); styleEl.remove();
      },
    };
  }

  L.register({
    id: 'pipes', name: '물길 잇기 레이스', tag: '실시간 배관 퍼즐', cat: '아케이드',
    blurb: '물이 차오르기 전에 파이프 조각을 이어 물길을 만들어요! 모두 같은 판, 같은 조각 순서로 누가 더 길게 잇나 겨뤄요. 혼자 하면 스테이지 12개.',
    tint: '#1d5566',
    icon: '<path d="M6 20h18a10 10 0 0 1 10 10v20" fill="none" stroke="currentColor" stroke-width="8"/><rect x="3" y="13" width="6" height="14" rx="1.5" fill="currentColor"/><rect x="27" y="46" width="14" height="6" rx="1.5" fill="currentColor"/><path d="M44 6c4 6 7 10 7 13a7 7 0 0 1-14 0c0-3 3-7 7-13z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'up', label: '커서 위로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '커서 아래로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '커서 왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '커서 오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'place', label: '조각 놓기 (커서 칸)', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'jump', label: '커서를 이을 칸으로', keys: ['KeyQ', 'KeyE'], pad: ['y'] },
      { id: 'fast', label: '물 틀기 · 빨리 흘리기', keys: ['KeyF', 'KeyK'], pad: ['x', 'rb'] },
      { id: 'view', label: '다른 사람 판 보기 (내 판이 끝난 뒤)', keys: ['KeyV'], pad: ['lb'] },
    ],
    options: [
      { id: 'map', label: '판', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '정원' }, { v: 1, label: '도시' }], def: -1 },
      { id: 'speed', label: '물 속도', choices: [{ v: 0, label: '느긋하게' }, { v: 1, label: '보통' }, { v: 2, label: '빠르게' }], def: 1 },
    ],
    quick: [
      '수원지 물통이 다 차면 물이 흘러나와요. 그 전에 파이프 조각을 이어 물길을 만들어요.',
      '빈 칸을 톡 누르면 「다음」 조각이 그 자리에 놓여요(돌리기 없음). 놓인 조각을 누르면 바꿔 끼워요.',
      '물이 지나간 칸마다 점수! 물이 새면 끝. 연못·하수구까지 이으면 +100. 점수가 가장 높으면 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '모두 똑같은 판에서, 똑같은 순서로 나오는 파이프 조각으로 각자 물길을 만들어요.',
        '모두의 물이 끝났을 때(새거나 연못·하수구에 닿을 때) 점수가 가장 높은 사람이 승리!',
        '혼자 하면 스테이지 12개(+무작위 판)에서 별을 모아요.',
      ] },
      { h: '하는 법', p: [
        '판 아래 「다음」 칸에 지금 놓을 조각이, 옆에 그다음 3개가 보여요.',
        '빈 칸을 누르면 「다음」 조각이 그대로 놓여요. 조각은 돌릴 수 없어요. 안 맞는 조각은 나중에 쓸 자리나 방해 안 되는 구석에 놓아요.',
        '이미 놓은 조각(물이 아직 안 찬 것)을 누르면 새 조각으로 바꿔 끼워요. 대신 0.8초 동안 손이 묶여요.',
        '수원지 물통의 숫자가 0이 되면 물이 흘러나와 한 칸씩 채워요(보통 속도에서 한 칸에 약 2.3초).',
        '노란 칸 = 다음에 이어야 할 칸이에요. 화살표는 물이 들어올 쪽, 오른쪽 위 작은 고리는 물이 닿기까지 남은 시간이에요.',
        '물이 관 끝에서 빈 칸·돌·벽·판 밖·안 맞는 조각으로 나가면 새 버리고, 내 판은 거기서 끝나요.',
      ] },
      { h: '조각', p: [
        '곧은 관(─ │)과 굽은 관(4방향)이 가장 많이 나와요.',
        '십자 관: 물이 가로로 한 번, 세로로 한 번 지나갈 수 있어요. 두 번째로 지나가면 고리 보너스 +50.',
        '저수조: 가운데 물통이 있어 물이 차는 데 4배 오래 걸려요. 시간을 벌어 줘요.',
        '고정 관(볼트 달린 회색·녹슨 관): 처음부터 판에 있어요. 바꿀 수 없지만 이어 쓰면 공짜 길이에요.',
      ] },
      { h: '점수 · 승리', p: [
        '물이 지나간 칸 하나에 10점. 꽃밭 칸(네 귀퉁이 새싹)을 지나면 꽃이 피고 +30, 십자 관 고리 +50.',
        '연못(정원)·하수구(도시)에 이으면 +100점, 거기서 물길이 끝나요. 짧은 관이 나온 입구 쪽으로 들어가야 해요.',
        '「물 틀기」: 물이 나오기 전에 누르면 바로 흘려요. 「빨리 흘리기」: 물이 아주 빨라지고, 그 뒤로 채우는 칸은 20점. 되돌릴 수 없으니 길을 다 이었을 때 눌러요. 둘 다 두 번 눌러 확인해요.',
        '모두의 물길이 끝나면 점수 순위! 점수가 같으면 공동 우승.',
      ] },
      { h: '판 · 옵션', p: [
        '정원 물길: 잔디밭에 돌, 꽃밭이 많고 끝은 연못. 도시 배관: 벽돌 벽, 고정 관이 많고 끝은 하수구.',
        '옵션 「판」: 무작위·정원·도시. 「물 속도」: 느긋하게(물 나오기까지 24초, 한 칸 3초)·보통(18초, 2.3초)·빠르게(14초, 1.75초).',
      ] },
      { h: '혼자 하기 (스테이지)', p: [
        '스테이지 12개는 판과 조각 순서가 늘 같아요. 해 볼수록 잘하게 돼요.',
        '연못·하수구까지 이으면 ★, 기준 점수를 넘기면 ★★·★★★(위쪽에 기준 점수가 보여요). 물이 새면 별이 없어요.',
        '「무작위 판」은 매번 새 판이에요.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 해요. 혼자 하면 나머지 자리는 AI예요(각자 자기 판).',
        '친구와는 온라인·LAN 방으로: 각자 폰에서 자기 판을 하고, 위쪽 칸에서 서로의 판과 점수가 보여요. 내 물길이 끝나면 그 칸을 눌러 다른 사람 판을 크게 볼 수 있어요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 느리고 가끔 엉뚱한 칸에 놓아요. 어려움은 빠르고 3수 앞을 봐요.',
      ] },
      { h: 'PC 조작', p: [
        '마우스로 칸을 누르면 놓여요(올려 두면 놓일 모양이 미리 보여요).',
        '키보드·게임패드: 방향키·WASD·왼스틱 = 커서 이동, 스페이스·J·Ⓐ = 놓기, Q·E·Ⓨ = 커서를 이을 칸으로, F·K·Ⓧ = 물 틀기·빨리 흘리기(바로 실행), V·LB = 다른 판 보기. 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '예시', p: [
        '수원지가 오른쪽(→)으로 물을 내보내요. 「다음」이 ─ 이면 수원지 오른쪽 노란 칸을 톡! ─ 가 놓이고 노란 칸이 한 칸 오른쪽으로 옮겨요.',
        '다음이 │ 라서 지금은 안 맞으면, 나중에 아래로 꺾을 자리의 아랫칸에 미리 놓아 둬요.',
        '다음이 ┐ 이면 노란 칸에 놓아 아래로 꺾어요. 그 아래에 아까 놓은 │ 가 있으니 바로 이어져요!',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { space, flex, search, evalV, cands, AIP, GW, GH, NC, MASK, STAGES, STAR_PAR, RAND_PAR, SPEEDS, genBoard, paramsOf, defOf, newBoard, stepB, placeB, canPlace, goB, fastB, trace, aiInit, aiThink, pieceAt, exitOf, encB, decB, init, startStage, finish, result, starsOf },
  });
})();
