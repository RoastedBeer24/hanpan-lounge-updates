/* 서핑 대회 — realtime surf contest heat (1–4 players).
   Every surfer rides their own copy of the same set of waves at the same time (fair heat, like cooking.js kitchens).
   Side view of the wave face (seen from the beach): the curl peels to the right, the surfer carves up/down the face,
   launches airs off the lip (flip / spin / grab), rides tubes when the lip throws over. Contest scoring: five judges
   per ride (drop high + low, average the middle three), best two rides count.
   Each surfer is simulated on the device that owns it (no lag); the host runs the AI surfers, keeps the heat clock and
   collects scores. One person per phone; friends play through online/LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const wrapPi = (a) => { a = (a + Math.PI) % TAU; if (a < 0) a += TAU; return a - Math.PI; };

  /* ======================= data ======================= */
  // physics is in "face units" (pocket height = 1) and seconds.
  const TYPES = [
    { n: '아침 해변', sub: '부드러운 비치 브레이크 · 처음이면 여기', vp: 1.45, push: 1.4, G: 3.0, bar: 0.16, fast: 0.15, dur: [14, 19], sz: 0.34,
      sky: ['#7fb6e0', '#bcd9ea', '#f7dcc2'], sun: [0.24, 0.17, '#fff3d6'], far: ['#4f9cbc', '#2f7c9c'],
      face: ['#0b4561', '#16708d', '#2fa3b3', '#8fdcd3'], flat: ['#2a85a3', '#195a76'], foam: '#f5fbfb', land: '#5d7d6a', glow: 'rgba(255,246,220,' },
    { n: '큰 파도', sub: '높고 빠른 파도 · 속도 싸움', vp: 1.85, push: 1.85, G: 3.5, bar: 0.24, fast: 0.3, dur: [15, 20], sz: 0.25,
      sky: ['#414f5f', '#6f828e', '#9fadb0'], sun: null, far: ['#2b5566', '#1b3d4c'],
      face: ['#071f2b', '#0f4352', '#24727a', '#6fb7ad'], flat: ['#1f4c5b', '#10303d'], foam: '#eef5f3', land: '#2f3b40', glow: 'rgba(220,240,240,' },
    { n: '노을 리프', sub: '튜브가 자주 생기는 리프', vp: 1.65, push: 1.6, G: 3.2, bar: 0.48, fast: 0.2, dur: [13, 18], sz: 0.29,
      sky: ['#2f2552', '#9a4c78', '#f4a35c'], sun: [0.72, 0.6, '#ffd08a'], far: ['#6a4a6e', '#3a2f55'],
      face: ['#122a48', '#1c5370', '#378a90', '#f0b07c'], flat: ['#2b4568', '#182943'], foam: '#fff2e6', land: '#2a2038', glow: 'rgba(255,200,140,' },
  ];
  const MUL = [1, 1.32, 0.82, 1.12, 1.9];   // curl speed per section kind: normal, fast, slow, barrel, collapse
  const SH = 2.4, W_TURN = 3.4, TH_MAX = 1.3, CD = 0.11, PUMP = 0.3, LAUNCH = 1.45, AIRB = 1.12, GA = 4.6;
  const ROT_W = 10, SPIN_T = 0.5, CB_T = 1.0, VMAX = 4.2, RK = 18, PAD = 3.0, WIPE_T = 1.3, STEP = 1 / 60;
  const STAR = [8, 11.5, 14.5];

  function mulberry(a) {
    return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function hash01() { let x = 0x811c9dc5; for (let i = 0; i < arguments.length; i++) { x = Math.imul(x ^ (arguments[i] | 0), 16777619); x ^= x >>> 13; } return mulberry(x)(); }

  /* the i-th wave of a heat: same for every surfer (seeded) */
  function waveAt(sd, bt, i) {
    const TY = TYPES[bt], r = mulberry((sd ^ Math.imul(i + 1, 0x9E3779B1)) + bt * 7919);
    const dur = TY.dur[0] + r() * (TY.dur[1] - TY.dur[0]);
    const sec = [];
    let t = 1.6 + r() * 1.2;
    while (t < dur - 1.6) {
      const len = 2.2 + r() * 2.4, q = r();
      let k = 0, tl = 0;
      if (q < TY.bar) { k = 3; tl = 0.5 + r() * 0.4; }
      else if (q < TY.bar + TY.fast) k = 1;
      else if (q < TY.bar + TY.fast + 0.15) k = 2;
      const e = Math.min(dur, t + len);
      sec.push([t, e, k, tl]);
      if (k === 3) { sec.push([e, e + 0.6, 4, 0]); t += 0.6; }
      t += len + 0.4 + r() * 1.0;
    }
    return { dur, hs: 0.92 + r() * 0.16, sec };
  }
  function secAt(W, t) { if (!W) return null; for (const s of W.sec) if (t >= s[0] && t < s[1]) return s; return null; }

  /* ======================= surfer sim ======================= */
  function newSurfer(seat, sd, bt, T) {
    return {
      seat, sd, bt, T, t: 0, mode: 'paddle', mt: 2.0, ride: 0, W: null, wt: -9, sk: 0,
      C: -0.45, vpc: TYPES[bt].vp, TLc: 0, rise: 0,
      X: 0, y: 0, v: 0, th: 0, om: 0,
      vx: 0, vy: 0, off: 0, sp: -1, spQ: 0, spN: 0, gT: 0, grab: false, pk: 0, airT: 0, fdir: 0,
      raw: 0, pock: 0, mp: [], man: [], cnt: {}, tk: { st: -1, low: 0, apex: 0, apexH: 1, apexV: 0, apexD: 0, tTop: 0 },
      inT: false, wasT: false, tubeT: 0, flT: 0, fin: true, spinBuf: 0, wx: 0, wy: 0, why: '',
      rides: [], ev: [], inp: { u: 0, spin: 0, cut: 0, grab: false }, cb: -1, cb0: 0, cbX0: 0, cbMin: 0, cbV: 0, cbG: 0,
    };
  }
  function Hof(S, d) {
    const r = S.rise * (S.W ? S.W.hs : 1);
    if (d >= 0) { const q = d / SH; return r * (0.3 + 0.7 / (1 + q * q)); }
    return r * (1 - 0.2 * Math.min(1, -d / 1.6));
  }
  function tubeCeil(S, d, Hd) { const TL = S.TLc; if (TL < 0.08 || d < 0 || d >= TL) return 9; return Hd * (0.2 + 0.8 * Math.sqrt(d / TL)); }
  function waveTick(S, h) {
    S.wt += h;
    const s = secAt(S.W, S.wt), k = s ? s[2] : 0;
    S.sk = k;
    const tv = TYPES[S.bt].vp * MUL[k];
    S.vpc += (tv - S.vpc) * Math.min(1, h * (k === 4 ? 6 : 2.5));
    const tt = k === 3 ? s[3] : 0;
    S.TLc += (tt - S.TLc) * Math.min(1, h * (tt > S.TLc ? 2.2 : 5));
    if (S.TLc < 0.01) S.TLc = 0;
    S.C += S.vpc * h;
  }
  const base10 = (raw) => (raw <= 0.02 ? 0 : 10 * (1 - Math.exp(-raw / RK)));
  function judges(sd, seat, n, raw) {
    const b = base10(raw), j = [];
    for (let k = 0; k < 5; k++) j.push(raw <= 0.02 ? 0 : clamp(Math.round((b + (hash01(sd, seat, n, k, 77) - 0.5) * 0.9 * Math.min(1, b / 3)) * 10) / 10, 0, 10));
    let hi = 0, lo = 0;
    for (let k = 1; k < 5; k++) { if (j[k] > j[hi]) hi = k; if (j[k] < j[lo]) lo = k; }
    if (hi === lo) lo = (hi + 1) % 5;
    let sum = 0; for (let k = 0; k < 5; k++) if (k !== hi && k !== lo) sum += j[k];
    return { j, hi, lo, sc: Math.round(sum / 3 * 100) / 100 };
  }
  function best2(rides) { const a = rides.slice().sort((x, y) => y - x); return [a[0] || 0, a[1] || 0]; }
  function man(S, name, pts, key) {
    const c = S.cnt[key] || 0;
    pts *= Math.max(0.35, 1 - 0.2 * c);
    S.cnt[key] = c + 1;
    S.mp.push(pts);
    S.raw = rawOf(S);
    S.man.push([name, pts]);
    if (S.man.length > 12) { S.man.sort((a, b) => b[1] - a[1]); S.man.length = 8; }
    S.ev.push({ k: 'man', n: name, p: pts });
  }
  // judges look at the best few maneuvers of a ride; the rest only add a little
  const MW = [1, 0.8, 0.6];
  function rawOf(S) { const a = S.mp.slice().sort((x, y) => y - x); let r = S.pock; for (let i = 0; i < a.length; i++) r += a[i] * (i < 3 ? MW[i] : 0.12); return r; }
  function endRide(S, wiped, why) {
    if (S.fin) return;
    S.fin = true;
    const raw = S.raw * (wiped ? 0.85 : 1);
    const J = judges(S.sd, S.seat, S.rides.length, raw);
    S.rides.push(Math.round(J.sc * 100));
    const best = S.man.slice().sort((a, b) => b[1] - a[1]).slice(0, 2).map((m) => m[0]);
    S.ev.push({ k: 'ride', sc: J.sc, j: J.j, hi: J.hi, lo: J.lo, n: S.rides.length, why, wiped: !!wiped, best });
  }
  function wipe(S, why) {
    S.cb = -1; S.mode = 'wipe'; S.mt = WIPE_T; S.wx = S.X; S.wy = S.y; S.why = why; S.inT = false; S.grab = false;
    S.ev.push({ k: 'wipe', why });
    endRide(S, 1, why);
  }
  function newWave(S) {
    S.W = waveAt(S.sd, S.bt, S.ride);
    S.ride++;
    S.wt = -S.mt; S.C = S.X - 0.45; S.vpc = TYPES[S.bt].vp; S.TLc = 0; S.sk = 0;
    S.ev.push({ k: 'wave', n: S.ride });
  }
  function startRide(S) {
    S.mode = 'ride'; S.rise = 1; S.y = 0.6; S.v = 1.75; S.th = -0.6; S.om = 0; S.X = S.C + 0.45; S.cb = -1; S.cbG = 0;
    S.raw = 0; S.pock = 0; S.mp = []; S.man = []; S.cnt = {}; S.fin = false; S.inT = false; S.wasT = false; S.tubeT = 0; S.flT = 0;
    S.tk = { st: -1, low: 0.6, apex: 0, apexH: 1, apexV: 0, apexD: 0, tTop: 0 };
    S.ev.push({ k: 'go' });
  }
  // cutback: an automatic arc back toward the whitewater, then a rebound to continue down the line
  function startCut(S) {
    if (S.mode !== 'ride' || S.cb >= 0 || S.inT || S.v < 1.0 || S.y > Hof(S, S.X - S.C) * 0.95) return;
    S.cb = 0; S.cb0 = clamp(S.th, -0.8, 0.9); S.cbX0 = S.X; S.cbMin = S.X; S.cbV = S.v; S.flT = 0;
    S.ev.push({ k: 'cut' });
  }
  function endCut(S, d) {
    S.cb = -1; S.cbG = 0.45;
    const depth = clamp((S.cbX0 - S.cbMin) / 0.5, 0, 1), near = Math.exp(-Math.max(0, d) / 0.5);
    const pts = (1.5 + 2.5 * depth) * (1 + 0.9 * near) * (0.7 + 0.3 * clamp(S.cbV / 2.2, 0, 1));
    S.tk = { st: -1, low: S.y, apex: 0, apexH: 1, apexV: 0, apexD: 0, tTop: 0 };
    man(S, d < 0.45 ? '라운드하우스 컷백' : '컷백', pts, 'cb');
  }
  function startSpin(S) { if (S.sp < 0) { S.sp = 0; S.ev.push({ k: 'spin' }); } else if (S.spQ < 1) S.spQ = 1; }
  function stepS(S, h) {
    S.t += h;
    if (S.mode === 'done') return;
    if (S.t >= S.T - 1e-9) {
      if (S.mode === 'ride' || S.mode === 'air') endRide(S, 0, '경기 끝');
      S.mode = 'done'; S.inT = false; S.ev.push({ k: 'end' });
      return;
    }
    if (S.inp.spin) { S.inp.spin = 0; if (S.mode === 'air') startSpin(S); else startCut(S); } // one button: 컷백 on the face, 스핀 in the air
    if (S.inp.cut) { S.inp.cut = 0; startCut(S); }
    if (S.mode === 'paddle') stepPaddle(S, h);
    else if (S.mode === 'ride') stepRide(S, h);
    else if (S.mode === 'air') stepAir(S, h);
    else if (S.mode === 'wipe') { S.mt -= h; if (S.W) waveTick(S, h); S.wy = Math.max(-0.05, S.wy - h * 0.8); if (S.mt <= 0) { S.mode = 'paddle'; S.mt = PAD; S.X = S.wx; } }
  }
  function stepPaddle(S, h) {
    S.mt -= h;
    if (S.mt > PAD - 1.0) { S.rise = Math.max(0, S.rise - h * 1.1); if (S.W) waveTick(S, h); }
    else if (S.mt > 0.9) { S.rise = 0; S.W = null; }
    else {
      if (!S.W) newWave(S);
      waveTick(S, h);
      S.rise = clamp(1 - S.mt / 0.9, 0, 1);
      S.X = S.C + 0.45;
    }
    S.y = S.W && S.mt <= 0.9 ? 0.6 * S.rise : 0;
    if (S.mt <= 0) startRide(S);
  }
  function stepRide(S, h) {
    waveTick(S, h);
    const TY = TYPES[S.bt];
    let d = S.X - S.C, Hd = Hof(S, d);
    const u = clamp(S.inp.u || 0, -1, 1);
    let th;
    if (S.cb >= 0) { // scripted arc: up and over toward the curl, then back down the line
      S.cb += h / CB_T;
      const q = Math.min(1, S.cb);
      th = S.cb0 + (Math.PI * 0.85 - S.cb0) * Math.sin(Math.PI * q) + (-0.45 - S.cb0) * q;
    } else {
      th = clamp(S.th + u * W_TURN * h, -TH_MAX, TH_MAX);
      if (S.y <= 0.002 && th < 0) th -= th * Math.min(1, 9 * h);
    }
    if (S.cbG > 0) S.cbG -= h;
    const dth = th - S.th;
    S.th = th; S.om = dth / h;
    const p = Math.exp(-Math.max(0, d));
    const yr = clamp(S.y / Math.max(0.05, Hd), 0, 1);
    let a = -TY.G * Math.sin(th) * (0.6 + 0.4 * p) + TY.push * p * (0.45 + 0.55 * yr) - CD * S.v * S.v + PUMP * Math.abs(S.om) * (0.12 + 0.88 * p);
    if (S.y <= 0.002) a -= 0.6 * S.v;
    S.v = clamp(S.v + a * h, S.cb >= 0 ? 0.9 : 0.3, VMAX);
    S.X += S.v * Math.cos(th) * h;
    S.y += S.v * Math.sin(th) * h;
    if (S.y < 0) S.y = 0;
    d = S.X - S.C; Hd = Hof(S, d);
    if (S.cb >= 0) {
      S.cbMin = Math.min(S.cbMin, S.X);
      if (S.y > Hd - 0.02) S.y = Math.max(0, Hd - 0.02);
      if (S.cb >= 1) endCut(S, d);
    }
    // tube: the thrown lip is a ceiling; inside you score, the whitewater behind you closes in
    const ceil = tubeCeil(S, d, Hd);
    const inTube = ceil < 9 && S.y < ceil + 0.25;
    if (inTube) {
      if (S.y > ceil - 0.03) S.y = Math.max(0, ceil - 0.03);
      if (!S.inT) { S.inT = true; S.tubeT = 0; S.ev.push({ k: 'tubeIn' }); }
      S.tubeT += h;
    } else if (S.inT) {
      S.inT = false; S.wasT = d < 0;
      const ok = d >= 0; // d < 0: the whitewater swallowed the surfer inside (handled just below)
      if (ok && S.tubeT >= 0.3) man(S, S.tubeT > 1.2 ? '딥 튜브' : '튜브 라이딩', 2.5 + 5 * Math.min(2, S.tubeT), 'tube');
      if (ok) S.ev.push({ k: 'tubeOut', t: S.tubeT });
    }
    // lip: launch an air, or float along it
    if (S.cb < 0 && !inTube && S.y >= Hd - 0.001) {
      const vy = S.v * Math.sin(th);
      if (vy > LAUNCH && Hd > 0.35) { launch(S); return; }
      S.y = Hd; S.flT += h;
      if (S.th > 0.05) S.th = Math.max(0.05, S.th - 2.5 * h);
    } else if (S.flT > 0) {
      if (S.flT > 0.45) man(S, '플로터', 1.2 + 2 * Math.min(1, S.flT), 'fl');
      S.flT = 0;
    }
    if (d < (S.cb >= 0 || S.cbG > 0 ? -0.25 : -0.1)) { S.cb = -1; wipe(S, S.wasT ? '튜브가 닫혔어요' : '하얀 물살에 잡혔어요'); return; }
    if (d > 0.3) S.wasT = false;
    if (S.wt >= S.W.dur) { endRide(S, 0, '킥아웃'); S.mode = 'paddle'; S.mt = PAD; S.inT = false; return; }
    if (d > 4.2) { endRide(S, 0, '파도를 빠져나왔어요'); S.mode = 'paddle'; S.mt = PAD; return; }
    if (d >= 0 && d < 0.7) { S.pock += 0.15 * h; S.raw += 0.15 * h; }
    if (S.cb < 0) detect(S, d, Hd);
  }
  function detect(S, d, Hd) {
    const tk = S.tk, th = S.th;
    if (tk.st === 1 && S.y >= tk.apex) { tk.apex = S.y; tk.apexH = Hd; tk.apexV = S.v; tk.apexD = d; }
    if (tk.st === -1) tk.low = Math.min(tk.low, S.y);
    if (th > 0.3) {
      tk.tTop = S.wt;
      if (tk.st !== 1) {
        if (tk.st === -1 && tk.low < 0.35 && S.v > 1.0) man(S, '바텀 턴', 0.2 + 0.4 * clamp(S.v / 2.8, 0, 1.2), 'bt');
        tk.st = 1; tk.apex = S.y; tk.apexH = Hd; tk.apexV = S.v; tk.apexD = d;
      }
    } else if (th < -0.25) {
      if (tk.st === 1) {
        const rel = tk.apex / Math.max(0.2, tk.apexH);
        if (rel > 0.5) {
          let pts = (1.0 + 2.0 * clamp((rel - 0.5) / 0.45, 0, 1)) * (0.7 + 0.4 * clamp(tk.apexV / 2.2, 0, 1)) * (1 + 0.5 * Math.exp(-Math.max(0, tk.apexD)));
          let n = '탑 턴', key = 'tt';
          if (rel >= 0.93) { pts += 0.8; n = '리엔트리'; key = 're'; }
          else if (S.wt - tk.tTop < 0.2 && tk.apexV > 1.9) { pts *= 1.25; n = '스냅'; key = 'sn'; }
          man(S, n, pts, key);
        }
      }
      if (tk.st !== -1) { tk.st = -1; tk.low = S.y; }
    }
  }
  function launch(S) {
    S.mode = 'air';
    S.vx = Math.max(S.v * Math.cos(S.th), S.vpc * 0.85);
    S.vy = S.v * Math.sin(S.th) * AIRB;
    S.off = 0; S.sp = -1; S.spQ = 0; S.spN = 0; S.gT = 0; S.grab = false; S.pk = 0; S.airT = 0; S.fdir = 0; S.flT = 0;
    S.tk.st = 0;
    S.ev.push({ k: 'launch' });
  }
  function stepAir(S, h) {
    waveTick(S, h);
    S.airT += h;
    const u = clamp(S.inp.u || 0, -1, 1);
    S.grab = !!S.inp.grab;
    if (S.grab) S.gT += h;
    if (Math.abs(u) > 0.05) { S.off += u * ROT_W * (S.grab ? 0.6 : 1) * h; if (!S.fdir) S.fdir = u > 0 ? 1 : -1; }
    else { const k = Math.round(S.off / TAU) * TAU, e = S.off - k; if (Math.abs(e) < 1.1) S.off -= Math.sign(e) * Math.min(Math.abs(e), 3.2 * h); }
    if (S.sp >= 0) { S.sp += h / SPIN_T; if (S.sp >= 1) { S.spN++; if (S.spQ > 0) { S.spQ--; S.sp -= 1; } else S.sp = -1; } }
    S.vy -= GA * h; S.vx -= S.vx * 0.05 * h;
    S.X += S.vx * h; S.y += S.vy * h;
    const d = S.X - S.C, Hd = Hof(S, d);
    S.pk = Math.max(S.pk, S.y - Hd);
    if (S.vy < 0 && S.y <= Hd) land(S, d, Hd);
  }
  function land(S, d, Hd) {
    const vdir = Math.atan2(S.vy, S.vx), thL = clamp(vdir, -TH_MAX, 0.2);
    const err = wrapPi(vdir + S.off - thL);
    let fail = null;
    if (Math.abs(err) > 0.8) fail = '착지 실패!';
    else if (S.sp > 0.22 && S.sp < 0.8) fail = '스핀을 못 끝냈어요';
    else if (d < -0.15) fail = '하얀 물살에 떨어졌어요';
    if (fail) { S.y = Math.max(0, Math.min(S.y, Hd)); wipe(S, fail); return; }
    const spins = S.spN + (S.sp >= 0.8 ? 1 : 0);
    const flips = Math.floor((Math.abs(S.off) + 0.9) / TAU);
    const parts = [];
    let pts = 0.6 + 4 * Math.min(0.8, S.pk), kinds = 0;
    if (flips) { pts += 4 * flips; parts.push((flips > 1 ? flips + '회 ' : '') + (S.fdir > 0 ? '백플립' : '프런트 플립')); kinds++; }
    if (spins) { pts += 2.5 * spins; parts.push(spins * 360 + ' 스핀'); kinds++; }
    if (S.gT >= 0.2) { pts += 0.8 + 1.5 * Math.min(1, S.gT); parts.push('그랩'); kinds++; }
    if (kinds > 1) pts *= 1 + 0.3 * (kinds - 1);
    let name = parts.length ? parts.join(' + ') : '에어';
    const key = 'a' + (flips ? 'f' : '') + (spins ? 's' : '') + (S.gT >= 0.2 ? 'g' : '');
    let clean = false;
    if (S.grab) { pts *= 0.5; name += ' (흔들 착지)'; }
    else if (Math.abs(err) < 0.2) { pts *= 1.15; clean = true; }
    S.mode = 'ride'; S.th = thL; S.om = 0;
    S.v = clamp(Math.hypot(S.vx, S.vy) * 0.8, 1.2, VMAX);
    S.y = Math.max(0, Math.min(S.y, Hd - 0.01));
    S.sp = -1; S.spQ = 0; S.grab = false;
    S.tk = { st: -1, low: S.y, apex: 0, apexH: 1, apexV: 0, apexD: 0, tTop: 0 };
    S.ev.push({ k: 'land', clean });
    man(S, name, pts, key);
  }

  /* ======================= AI ======================= */
  const AIP = { // index = lv
    air: [0, 0.16, 0.45, 0.72], flips: [0, 0, 1, 2], spin: [0, 0.25, 0.45, 0.7], grab: [0, 0.55, 0.6, 0.7],
    rel: [0, 0.6, 0.3, 0.12], react: [0, 0.17, 0.07, 0.02], tube: [0, 0.1, 0.5, 0.9], hi: [0, 0.66, 0.8, 0.9], k: [0, 2.4, 3.5, 4.5],
    grabEnd: [0, 0.04, 0.14, 0.12], flipP: [0, 0, 0.6, 0.85], ant: [0, 0.18, 0.24, 0.26], oops: [0, 0.3, 0.08, 0], look: [0, 0, 0.4, 0.8], dz: [0, 0.15, 0.3, 0.4], cutD: [0, 99, 1.8, 1.4],
  };
  function airLeft(S) { const Hd = Hof(S, S.X - S.C), dy = S.y - Hd; return (S.vy + Math.sqrt(Math.max(0, S.vy * S.vy + 2 * GA * Math.max(0, dy)))) / GA; }
  function aiThink(S, M, lv, h) {
    lv = clamp(lv | 0, 1, 3);
    const inp = S.inp;
    M.rt = (M.rt || 0) - h;
    if (S.mode === 'air') {
      if (!M.a0) {
        M.a0 = true;
        const ta = airLeft(S);
        let fl = 0;
        for (let n = AIP.flips[lv]; n >= 1; n--) if ((n * TAU - 0.4) / ROT_W + 0.12 <= ta) { fl = n; break; }
        M.fl = fl && Math.random() < AIP.flipP[lv] ? fl : 0;
        M.dir = Math.random() < 0.5 ? 1 : -1;
        M.rel = 0.35 + (Math.random() * 2 - 1) * AIP.rel[lv];
        M.sp = ta > SPIN_T + 0.12 && Math.random() < AIP.spin[lv] && (lv === 3 || !M.fl);
        M.gr = Math.random() < AIP.grab[lv] && (!M.fl || lv === 3);
        M.ge = AIP.grabEnd[lv] + (lv === 1 ? Math.random() * 0.25 - 0.1 : 0);
        if (M.sp) inp.spin = 1;
        M.oops = Math.random() < AIP.oops[lv] ? { t0: Math.random() * 0.25, t1: 0.25 + Math.random() * 0.4, u: Math.random() < 0.5 ? 1 : -1 } : null;
      }
      const tr = airLeft(S);
      const flipping = M.fl > 0 && Math.abs(S.off) < M.fl * TAU - M.rel;
      inp.u = flipping ? M.dir : 0;
      if (M.oops && S.airT > M.oops.t0 && S.airT < M.oops.t1) inp.u = M.oops.u; // beginner wobble in the air
      inp.grab = !!M.gr && !flipping && tr > M.ge && S.airT > 0.08;
      return;
    }
    M.a0 = false; inp.grab = false;
    if (S.mode !== 'ride') { inp.u = 0; return; }
    if (S.cb >= 0) { inp.u = 0; return; }
    M.ct = (M.ct || 0) - h;
    if (M.rt > 0) return;
    M.rt = AIP.react[lv];
    const d = S.X - S.C, Hd = Math.max(0.2, Hof(S, d)), yr = S.y / Hd;
    const tube = S.TLc > 0.3 && d < S.TLc + 0.4 && d > -0.05;
    if (!tube) M.tg = null;
    else if (M.tg == null) M.tg = Math.random() < AIP.tube[lv];
    // reading the wave: a barrel about to collapse or a fast section means "run"
    const sec = secAt(S.W, S.wt + AIP.look[lv]), soon = sec && (sec[2] === 4 || sec[2] === 1);
    const hx = S.v * Math.cos(S.th), danger = d < AIP.dz[lv] + Math.max(0, S.vpc - hx) * 0.35 || (soon && d < 0.6);
    if (!tube && !danger && M.ct <= 0 && d > AIP.cutD[lv] && yr > 0.3 && yr < 0.85 && S.th > -0.3 && S.v > 1.4) { inp.cut = 1; M.ct = 2.5; M.goal = 'low'; M.lo = 0.2; return; }
    let thd;
    if (danger) { // speed run: stay mid-low, shallow angles, small quick pumps
      M.goal = 'low'; M.lo = 0.2;
      thd = yr > 0.45 ? -0.5 : yr < 0.12 ? 0.3 : (Math.sin(S.t * 7) > 0 ? 0.35 : -0.35);
    } else if (tube && M.tg) {
      thd = clamp((0.3 - yr) * 2.5, -0.5, 0.5);
      if (d > S.TLc * 0.55) thd = 0.7;
    } else {
      if (M.lo == null) { M.goal = 'low'; M.lo = 0.2; }
      if (M.goal === 'low' && (yr < M.lo || (S.y < 0.02))) {
        M.goal = 'high';
        M.air = d > 0.3 && d < 2.2 && S.v > 2.0 && Math.random() < AIP.air[lv];
        M.hi = Math.min(0.95, AIP.hi[lv] + (Math.random() - 0.5) * 0.16);
      } else if (M.goal === 'high' && ((!M.air && (S.y + Math.max(0, S.v * Math.sin(S.th)) * AIP.ant[lv]) / Hd > M.hi) || (M.air && S.th < 0.3 && yr > 0.6) || S.v < 0.9)) {
        M.goal = 'low'; M.lo = 0.08 + Math.random() * 0.22;
      }
      thd = M.goal === 'high' ? (M.air ? 1.25 : 0.95) : (d > 1.1 ? -1.2 : -0.9);
      if (d > 1.5) thd = clamp(thd * 1.3, -1.25, 1.25);
      if (lv === 1) thd += Math.sin(S.t * 2.3 + S.seat) * 0.25;
    }
    inp.u = clamp((thd - S.th) * AIP.k[lv], -1, 1);
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    const bt = [0, 1, 2].includes(o.beach) ? o.beach : Math.floor(Math.random() * 3);
    return {
      rid: 1 + U.rand(99999), n: players.length, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      T: [60, 90, 120].includes(o.time) ? o.time : 90, bt, sd: 1 + U.rand(2147483646), ph: 'play', res: null,
    };
  }
  function finish(s, rows) { // rows: [seat, total100, best100, second100, rides]
    const res = rows.slice().sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[0] - b[0]);
    return Object.assign({}, s, { ph: 'done', res });
  }
  const f2 = (v) => (v / 100).toFixed(2);
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const head = (TYPES[s.bt] ? TYPES[s.bt].n : '') + ' · ' + (s.T >= 120 ? '2분' : s.T + '초') + ' 경기';
    if (s.n === 1) {
      const r = s.res[0], st = STAR.filter((v) => r[1] / 100 >= v).length;
      return { winners: st > 0 ? [r[0]] : [], title: st ? '별 ' + st + '개!' : '아쉬워요', text: head + '\n' + '★'.repeat(st) + '☆'.repeat(3 - st) + '  합계 ' + f2(r[1]) + '점\n베스트 2 : ' + f2(r[2]) + ' + ' + f2(r[3]) + ' · 탄 파도 ' + r[4] + '개' };
    }
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top && r[2] === s.res[0][2]).map((r) => r[0]);
    const rank = (r) => 1 + s.res.filter((q) => q[1] > r[1] || (q[1] === r[1] && q[2] > r[2])).length;
    const lines = s.res.map((r) => rank(r) + '위  ' + nm(r[0]) + '  ' + f2(r[1]) + '점 (' + f2(r[2]) + ' + ' + f2(r[3]) + ')');
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: head + '\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  function rrect(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    let st = null, key = null, tl = -3, endWait = 0, endSeen = false;
    let KS = [], mem = [], view = 0, lay = null, sky = null, skyKey = '';
    let camX = 0, camInit = false, parts = [], floats = [], trail = [], trailT = 0, flash = null, sprayAcc = 0, lipAcc = 0, curlAcc = 0;
    let shake = 0, lastBeep = 0, coach = 0;
    const remote = {}, chipPop = {}, lastN = {};
    let pubT = 0, lastSig = '';
    const ptrs = new Map();
    const btnFlash = { spin: 0 };

    const curKey = () => (st ? st.rid + '.' + st.bt + '.' + st.sd : null);
    function ensureMatch() {
      if (!st) return;
      const k = curKey();
      if (k === key) return;
      key = k;
      KS = []; mem = [];
      for (let s = 0; s < st.n; s++) { KS[s] = simHere(s) ? newSurfer(s, st.sd, st.bt, st.T) : null; mem[s] = {}; }
      const m = mine(), fst = KS.findIndex(Boolean);
      view = m.length ? m[0] : (fst >= 0 ? fst : 0);
      parts = []; floats = []; trail = []; flash = null; endWait = 0; endSeen = false; camInit = false; coach = 0;
      for (const x in remote) delete remote[x];
      for (const x in chipPop) delete chipPop[x];
      for (const x in lastN) delete lastN[x];
      tl = st.ph === 'done' ? st.T : -3;
      sky = null; layout();
    }

    /* ----- layout ----- */
    /* landscape (main layout): one thin row of name chips, the wave uses the whole width (you see much further down the
       line), 위로 + 컷백/스핀 at the left edge and 아래로 + 그랩 at the right edge for the thumbs.
       Portrait (fallback when the phone can't rotate): chips + info row on top, a button bar along the bottom. */
    function layout() {
      const w = cv.w, h = cv.h, land = w > h * 1.15;
      if (land) {
        const hudH = 36, rowH = 28, hintH = 22, ctl = mine().length > 0;
        const colW = ctl ? Math.round(clamp(w * 0.14, 96, 132)) : 0, pl = ctl ? colW + 16 : 0, pr = ctl ? w - colW - 16 : w;
        const top = hudH, bot = h - hintH, playH = Math.max(120, bot - top);
        const S = Math.max(60, Math.min(playH / 1.95, (pr - pl) * 0.55));
        const lipY = top + S * 0.78, ty = lipY + S;
        let btn = null;
        if (ctl) {
          const y0 = top + 8, colH = h - 8 - y0, ah = Math.round(clamp((colH - 8) * 0.36, 56, 96)), dy = y0 + ah + 8, dh = h - 8 - dy;
          btn = {
            spin: { x: 8, y: y0, w: colW, h: ah }, L: { x: 8, y: dy, w: colW, h: dh },
            grab: { x: w - 8 - colW, y: y0, w: colW, h: ah }, R: { x: w - 8 - colW, y: dy, w: colW, h: dh },
          };
        }
        lay = { w, h, land, hudH, rowH, top, bot, hintH, S, lipY, ty, bar: null, btn, pl, pr, pw: pr - pl, cx: (pl + pr) / 2 };
        sky = null;
        return;
      }
      const hudH = 44, rowH = 28, barH = Math.round(clamp(h * 0.11, 70, 88)), hintH = 24;
      const top = hudH + rowH, bot = h - barH - hintH, playH = Math.max(120, bot - top);
      const S = Math.max(60, Math.min(playH * 0.43, w * 0.62));
      const lipY = top + playH * 0.36, ty = lipY + S;
      const bar = { y: h - barH, h: barH };
      const avail = w - 16, gap = 6, side = Math.round(avail * 0.3), mid = Math.floor((avail - 2 * side - 3 * gap) / 2);
      const by = bar.y + 6, bh = barH - 12;
      const btn = {
        L: { x: 8, y: by, w: side, h: bh },
        spin: { x: 8 + side + gap, y: by, w: mid, h: bh },
        grab: { x: 8 + side + gap * 2 + mid, y: by, w: mid, h: bh },
        R: { x: w - 8 - side, y: by, w: side, h: bh },
      };
      lay = { w, h, land: false, hudH, rowH, top, bot, hintH, S, lipY, ty, bar, btn, pl: 0, pr: w, pw: w, cx: w / 2 };
      sky = null;
    }
    cv.onresize = layout;

    /* ----- cached background: sky, sun, clouds, far sea, headland ----- */
    function skyLayer(TY) {
      const d = Math.min(2, cv.dpr || 1), k = TY.n + '|' + lay.w + 'x' + lay.h + '|' + d;
      if (sky && skyKey === k) return sky;
      const c = document.createElement('canvas');
      c.width = Math.ceil(lay.w * d); c.height = Math.ceil(lay.ty * d + 2);
      const g = c.getContext('2d'); g.scale(d, d);
      const w = lay.w, hz = lay.lipY - lay.S * 0.32;
      const sg = g.createLinearGradient(0, 0, 0, hz);
      sg.addColorStop(0, TY.sky[0]); sg.addColorStop(0.6, TY.sky[1]); sg.addColorStop(1, TY.sky[2]);
      g.fillStyle = sg; g.fillRect(0, 0, w, hz + 1);
      if (TY.sun) {
        const sx = w * TY.sun[0], sy = hz * TY.sun[1] + (TY.sun[1] > 0.5 ? hz * 0.25 : 0), R = Math.min(w, hz) * 0.5;
        const rg = g.createRadialGradient(sx, sy, 2, sx, sy, R);
        rg.addColorStop(0, 'rgba(255,250,235,.95)'); rg.addColorStop(0.08, TY.sun[2]); rg.addColorStop(0.2, 'rgba(255,230,190,.35)'); rg.addColorStop(1, 'rgba(255,230,190,0)');
        g.fillStyle = rg; g.fillRect(0, 0, w, hz + 1);
      }
      const r = mulberry(7 + TY.n.length * 31);
      for (let i = 0; i < 7; i++) { // soft clouds
        const cx = r() * w, cy = hz * (0.12 + r() * 0.55), cw = w * (0.18 + r() * 0.25);
        g.fillStyle = TY.sun ? 'rgba(255,255,255,' + (0.18 + r() * 0.2) + ')' : 'rgba(40,52,62,' + (0.25 + r() * 0.25) + ')';
        for (let j = 0; j < 4; j++) { g.beginPath(); g.ellipse(cx + (j - 1.5) * cw * 0.28, cy + (j % 2) * 4, cw * 0.3, cw * 0.11, 0, 0, TAU); g.fill(); }
      }
      // headland on the right, low dunes on the left
      g.fillStyle = TY.land;
      g.beginPath(); g.moveTo(w * 0.62, hz + 1); g.quadraticCurveTo(w * 0.78, hz - lay.S * 0.2, w * 0.9, hz - lay.S * 0.16); g.lineTo(w + 2, hz - lay.S * 0.22); g.lineTo(w + 2, hz + 1); g.fill();
      g.globalAlpha = 0.7; g.beginPath(); g.moveTo(-2, hz + 1); g.quadraticCurveTo(w * 0.12, hz - lay.S * 0.07, w * 0.3, hz + 1); g.fill(); g.globalAlpha = 1;
      // far sea behind the wave
      const fg = g.createLinearGradient(0, hz, 0, lay.ty);
      fg.addColorStop(0, TY.far[0]); fg.addColorStop(1, TY.far[1]);
      g.fillStyle = fg; g.fillRect(0, hz, w, lay.ty - hz + 2);
      g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1;
      for (let i = 0; i < 9; i++) { const y = hz + 3 + i * i * 2.2; if (y > lay.ty) break; g.beginPath(); g.moveTo(r() * w * 0.4, y); g.lineTo(w * (0.5 + r() * 0.5), y); g.stroke(); }
      if (TY.sun) { // sun glitter on the far sea
        const sx = w * TY.sun[0];
        g.fillStyle = TY.glow + '.35)';
        for (let i = 0; i < 16; i++) { const y = hz + 2 + r() * (lay.ty - hz) * 0.6; g.fillRect(sx - 30 + r() * 60 - (y - hz) * 0.2, y, 6 + r() * 16, 1.5); }
      }
      sky = c; skyKey = k;
      return c;
    }

    /* ----- input ----- */
    const canCtl = () => isMine(view) && !auto() && !!KS[view] && tl >= 0 && tl < (st ? st.T : 0);
    const inR = (b, x, y) => x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h;
    function myK() { const m = mine()[0]; return m != null ? KS[m] : null; }
    function pressSpin() {
      const K = myK(); if (!K) return;
      K.inp.spin = 1; btnFlash.spin = 0.25;
      if (K.mode === 'air') api.buzz(8);
    }
    function onDown(e) {
      if (!st || !lay) return;
      const p = cv.local(e);
      e.preventDefault();
      if (p.y < lay.hudH) { // tap a name chip to watch that surfer (spectating only)
        if (!mine().length && key) { const n = st.n, cw = (lay.w - 12 - (n - 1) * 6) / n, i = Math.floor((p.x - 6) / (cw + 6)); if (i >= 0 && i < n && KS[i] && i !== view) { view = i; camInit = false; trail = []; flash = null; api.sfx('click'); } }
        return;
      }
      if (!canCtl()) return;
      let z = null; // a button, else the left half = 위로 / the right half = 아래로
      if (lay.btn) for (const k of ['L', 'spin', 'grab', 'R']) if (inR(lay.btn[k], p.x, p.y)) z = k;
      if (!z) z = p.x < lay.cx ? 'L' : 'R';
      ptrs.set(e.pointerId, { z, x0: p.x, y0: p.y, t0: performance.now(), drag: false, u: 0, sw: false });
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
      if (z === 'spin') pressSpin();
      api.buzz(z === 'grab' ? 10 : 6);
    }
    function onMove(e) {
      const P = ptrs.get(e.pointerId);
      if (!P || (P.z !== 'L' && P.z !== 'R')) return;
      const p = cv.local(e), dx = p.x - P.x0, dy = p.y - P.y0;
      if (!P.sw && Math.abs(dx) > 48 && Math.abs(dx) > 1.6 * Math.abs(dy) && performance.now() - P.t0 < 320) { P.sw = true; pressSpin(); return; }
      if (!P.drag && Math.abs(dy) > 22 && Math.abs(dy) > Math.abs(dx)) P.drag = true;
      if (P.drag) P.u = clamp(-dy / 70, -1, 1);
    }
    function onUp(e) { ptrs.delete(e.pointerId); }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);
    let offIn = null;
    try { offIn = api.input && api.input.on((type, id) => { if (type === 'down' && id === 'spin' && canCtl()) pressSpin(); if (type === 'down' && id === 'cut' && canCtl()) { const K = myK(); if (K) { K.inp.cut = 1; btnFlash.spin = 0.25; } } }); } catch (e) { offIn = null; }
    function held() {
      let up = false, dn = false, gr = false, u = 0;
      for (const P of ptrs.values()) {
        if (P.z === 'grab') gr = true;
        else if (P.z === 'L' || P.z === 'R') { const v = P.sw ? 0 : P.drag ? P.u : (P.z === 'L' ? 1 : -1); u += v; if (v > 0.2) up = true; if (v < -0.2) dn = true; }
      }
      let ax = 0;
      try { if (api.input) { ax = api.input.axis('down', 'up'); if (api.input.held('grab')) gr = true; } } catch (e) { ax = 0; }
      u += ax; if (ax > 0.2) up = true; if (ax < -0.2) dn = true;
      return { u: clamp(u, -1, 1), up, dn, gr };
    }
    function readInput() {
      const K = myK();
      if (!K || auto()) return;
      if (!canCtl()) { K.inp.u = 0; K.inp.grab = false; return; }
      const H = held();
      K.inp.u = H.u; K.inp.grab = H.gr;
    }

    /* ----- online ----- */
    function rowOf(s) { // {r: rides x100, c: live raw x10, m: mode code}
      const K = KS[s];
      if (K) return { r: K.rides, c: K.mode === 'ride' || K.mode === 'air' ? Math.round(K.raw * 10) : 0, m: modeCode(K) };
      return remote[s] || { r: [], c: 0, m: 0 };
    }
    const modeCode = (K) => ({ paddle: 0, ride: 1, air: 2, wipe: 3, done: 4 }[K.mode] || 0);
    const cleanR = (a) => (Array.isArray(a) ? a.slice(0, 40).map((v) => clamp(v | 0, 0, 1000)) : []);
    function pollNet() {
      if (!api.online || !key) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) { const s = +k, o = rem[k]; if (!(s >= 0 && s < st.n) || KS[s] || !o || o.k !== key) continue; remote[s] = { r: cleanR(o.r), c: o.c | 0, m: o.m | 0, f: o.f | 0 }; }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== key) return;
        if (typeof hs.t === 'number' && isFinite(hs.t) && st.ph === 'play') { const d = hs.t - tl; if (Math.abs(d) > 0.6) tl = hs.t; else tl += d * 0.05; }
        if (Array.isArray(hs.s)) hs.s.forEach((a, s) => { if (KS[s] || !a) return; remote[s] = { r: cleanR(a[0]), c: a[1] | 0, m: a[2] | 0, f: 0 }; });
      }
    }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 0.25;
          const s = []; for (let i = 0; i < st.n; i++) { const r = rowOf(i); s.push([r.r, r.c, r.m]); }
          api.net.hostSend({ k: key, t: Math.round(tl * 100) / 100, s });
        } else {
          const K = myK(); if (!K) return;
          const r = rowOf(K.seat), f = K.mode === 'done' ? 1 : 0, sig = r.r.join(',') + '|' + r.c + '|' + r.m + '|' + f;
          if (sig === lastSig && pubT > 0) return;
          lastSig = sig; pubT = 0.5;
          api.net.publish({ k: key, r: r.r, c: r.c, m: r.m, f });
        }
      } catch (e) {}
    }
    function hostEnd(rdt) {
      if (!host() || !st || st.ph !== 'play' || tl < st.T) return;
      endWait += rdt;
      let ready = true;
      for (let s = 0; s < st.n; s++) { if (KS[s]) { if (KS[s].mode !== 'done') ready = false; } else if (api.online && !(remote[s] && remote[s].f)) ready = false; }
      if ((ready && endWait > 1.6) || endWait > 5) {
        const rows = [];
        for (let s = 0; s < st.n; s++) { const r = rowOf(s), b = best2(r.r); rows.push([s, b[0] + b[1], b[0], b[1], r.r.length]); }
        endWait = -1e9;
        api.setState(finish(st, rows));
      }
    }

    /* ----- effects ----- */
    const lastSfx = {};
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function part(x, y, vx, vy, r, life, c, k) { if (parts.length > 280) parts.shift(); parts.push({ x, y, vx, vy, r, t: life, T: life, c, k: k || 0 }); }
    function splash(x, y, n, sp) { for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI, v = sp * (0.4 + Math.random()); part(x + (Math.random() - 0.5) * 0.1, y, Math.cos(a) * v, Math.sin(a) * v * 1.3, 0.02 + Math.random() * 0.04, 0.5 + Math.random() * 0.4, 0); } }
    function onEvents(K, me) {
      for (const e of K.ev) {
        switch (e.k) {
          case 'go': sfx('whoosh'); if (me) api.buzz(15); trail = []; break;
          case 'wave': sfx('roll', 200); break;
          case 'launch': sfx('whoosh'); splash(K.X, K.y, 10, 1.4); if (me) api.buzz(12); break;
          case 'spin': sfx('tick'); break;
          case 'cut': sfx('whoosh', 150); if (me) api.buzz(12); break;
          case 'land': sfx(e.clean ? 'bounce' : 'thud'); splash(K.X, K.y, 16, 1.6); shake = 0.25; if (me) api.buzz(e.clean ? 20 : 30); break;
          case 'man': {
            if (e.p < 0.5) break;
            while (floats.filter((f) => f.fol).length >= 3) floats.splice(floats.findIndex((f) => f.fol), 1);
            const big = e.p >= 4, used = floats.filter((f) => f.fol).map((f) => f.slot || 0); let slot = 0;
            while (used.includes(slot)) slot++;
            floats.push({ x: K.X, y: K.y + 0.32, text: e.n, sub: '+' + e.p.toFixed(1), t: big ? 1.6 : 1.1, T: big ? 1.6 : 1.1, big, fol: 1, slot });
            if (big) sfx('chip', 80); else if (e.p >= 1) sfx('tick', 80);
            break;
          }
          case 'tubeIn': sfx('whoosh', 200); floats.push({ x: K.X, y: K.y + 0.35, text: '튜브!', sub: '', t: 1.0, T: 1.0, big: true, fol: 1 }); if (me) api.buzz([10, 30, 10]); break;
          case 'tubeOut': if (e.t >= 0.3) { sfx('win', 200); splash(K.X, K.y, 14, 1.8); } break;
          case 'wipe': sfx('lose', 150); splash(K.X, Math.max(0, K.y), 26, 2.2); shake = 0.7; floats.push({ x: K.X, y: Math.max(0.2, K.y) + 0.35, text: e.why, sub: '', t: 1.4, T: 1.4, big: false, bad: true }); if (me) api.buzz([40, 40, 60]); trail = []; break;
          case 'ride':
            flash = { t: 0, j: e.j, hi: e.hi, lo: e.lo, sc: e.sc, n: e.n, why: e.why, wiped: e.wiped, best: e.best, seat: K.seat };
            if (e.sc >= 6) sfx('win', 100); else sfx('chip', 100);
            break;
          case 'end': break;
        }
      }
      K.ev.length = 0;
    }
    function ambient(K, rdt) {
      if (!K.W && K.rise <= 0) return;
      // lip spray blown back by the offshore wind and the explosion where the curl lands
      lipAcc += rdt * 20 * K.rise;
      while (lipAcc > 1) { lipAcc--; const d = 0.05 + Math.random() * 1.3, hh = Hof(K, d); if (hh > 0.3) part(K.C + d, hh, K.vpc * 0.75 - 0.2, 0.35 + Math.random() * 0.5, 0.012 + Math.random() * 0.02, 0.6 + Math.random() * 0.4, 1); }
      curlAcc += rdt * 26 * K.rise;
      while (curlAcc > 1) { curlAcc--; const h0 = Hof(K, 0); part(K.C - Math.random() * 0.15, Math.random() * h0 * 0.9, K.vpc + (Math.random() - 0.5) * 0.5, 0.4 + Math.random() * 1.3, 0.03 + Math.random() * 0.05, 0.5 + Math.random() * 0.3, 2); }
      if (K.mode === 'ride') {
        sprayAcc += rdt * Math.abs(K.om) * K.v * 9;
        if (K.y <= 0.002) sprayAcc += rdt * K.v * 2;
        while (sprayAcc > 1) {
          sprayAcc--;
          const c = Math.cos(K.th), s = Math.sin(K.th), turnUp = K.om > 0;
          part(K.X - c * 0.12, K.y - s * 0.12, K.v * c * 0.45 + (Math.random() - 0.5) * 0.6, (turnUp ? 0.6 : 1.1) + Math.random() * 1.3, 0.012 + Math.random() * 0.03, 0.45 + Math.random() * 0.3, 0);
        }
        trailT -= rdt;
        if (trailT <= 0) { trailT = 0.03; trail.push(K.X, K.y); if (trail.length > 60) trail.splice(0, 2); }
      } else if (K.mode !== 'air') { if (trail.length) trail.splice(0, 2); }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      const dt = rdt * SPD();
      ensureMatch();
      if (!key || !lay) { draw(now, rdt); return; }
      const was = tl;
      if (st.ph === 'play') tl += dt;
      pollNet();
      if (was < 0) { const a = Math.ceil(-was), b = Math.ceil(-tl); if (tl < 0 && a !== b) api.sfx('tick'); if (tl >= 0) { api.sfx('pop'); api.buzz(20); } }
      if (was >= st.T - 5 && was < st.T && Math.ceil(st.T - was) !== Math.ceil(st.T - tl) && tl < st.T) api.sfx('tick');
      if (tl >= st.T && !endSeen) { endSeen = true; api.sfx('whoosh'); api.buzz([30, 40, 30]); }
      readInput();
      const target = clamp(tl, 0, st.T);
      KS.forEach((K, s) => {
        if (!K) return;
        const p = api.players[s], bot = p && (p.ai || (auto() && isMine(s)));
        let n = 0;
        while (K.t < target - 1e-6 && n < 300) { const h = Math.min(STEP, target - K.t); if (bot) aiThink(K, mem[s], p.ai ? (p.lv || 2) : 2, h); stepS(K, h); n++; }
        if (s !== view) { for (const e of K.ev) if (e.k === 'ride') chipPop[s] = { v: e.sc, t: 1.6 }; K.ev.length = 0; }
      });
      for (const s in remote) { const r = remote[s], n = r.r.length; if (lastN[s] != null && n > lastN[s]) chipPop[s] = { v: r.r[n - 1] / 100, t: 1.6 }; lastN[s] = n; }
      hostEnd(rdt);
      const K = KS[view];
      if (K) {
        onEvents(K, isMine(view));
        if (tl >= 0) ambient(K, rdt);
        if (canCtl() && K.mode === 'ride' && K.v < 1.3 && Math.hypot(K.X - K.C, 0) < 0.4) { lastBeep -= rdt; if (lastBeep <= 0) { lastBeep = 0.6; sfx('tick'); } }
      }
      for (let i = parts.length - 1; i >= 0; i--) {
        const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt;
        if (q.k === 1) { q.vy -= 0.6 * rdt; } else { q.vy -= 3.6 * rdt; q.vx *= 1 - 0.6 * rdt; }
        if (q.t <= 0 || (q.y < -0.15 && q.vy < 0)) parts.splice(i, 1);
      }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (const s in chipPop) { chipPop[s].t -= rdt; if (chipPop[s].t <= 0) delete chipPop[s]; }
      if (flash) { flash.t += rdt; if (flash.t > 3.6) flash = null; }
      btnFlash.spin = Math.max(0, btnFlash.spin - rdt);
      shake = Math.max(0, shake - rdt * 2);
      if (canCtl()) coach += rdt;
      publish(rdt);
      draw(now, rdt);
    }

    /* ----- drawing helpers ----- */
    function txt(t, x, y, col, font, align, base) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    const SX = (x) => lay.cx + (x - camX) * lay.S;
    const SY = (y) => lay.ty - y * lay.S;
    const COLS = 96, cD = new Float32Array(COLS + 1), cH = new Float32Array(COLS + 1), cXs = new Float32Array(COLS + 1);

    function drawWater(K, TY, now) {
      const w = lay.w, S = lay.S, ty = lay.ty, ts = now / 1000;
      // flat water toward the beach
      const fg = ctx.createLinearGradient(0, ty, 0, lay.h);
      fg.addColorStop(0, TY.flat[0]); fg.addColorStop(1, TY.flat[1]);
      ctx.fillStyle = fg; ctx.fillRect(0, ty - 1, w, lay.h - ty + 1);
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 7; i++) { // old foam lines drifting to the shore
        const f = ((i / 7 + ts * 0.05) % 1), y = ty + 6 + f * f * (lay.h - ty);
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.16 * (1 - f) + 0.04) + ')';
        ctx.beginPath();
        for (let x = 0; x <= w + 8; x += 16) { const wx = camX + (x - lay.cx) / S; const yy = y + Math.sin(wx * 3 + i * 1.7) * (2 + f * 4); if (x === 0) ctx.moveTo(x, yy); else ctx.lineTo(x, yy); }
        ctx.stroke();
      }
      if (!K) return;
      // wave face
      const step = w / COLS;
      for (let i = 0; i <= COLS; i++) { const x = i * step, d = camX + (x - lay.cx) / S - K.C; cXs[i] = x; cD[i] = d; cH[i] = Hof(K, d); }
      if (K.rise <= 0.001) return;
      ctx.beginPath(); ctx.moveTo(-2, ty + 1);
      for (let i = 0; i <= COLS; i++) ctx.lineTo(cXs[i], ty - cH[i] * S);
      ctx.lineTo(w + 2, ty + 1); ctx.closePath();
      const gg = ctx.createLinearGradient(0, ty, 0, ty - S * 1.08);
      gg.addColorStop(0, TY.face[0]); gg.addColorStop(0.35, TY.face[1]); gg.addColorStop(0.78, TY.face[2]); gg.addColorStop(1, TY.face[3]);
      ctx.fillStyle = gg; ctx.fill();
      ctx.save(); ctx.clip();
      if (TY.sun) { // sunlit band on the face
        const gx = w * TY.sun[0], rg = ctx.createRadialGradient(gx, ty - S * 0.75, 4, gx, ty - S * 0.55, S * 0.9);
        rg.addColorStop(0, TY.glow + '.32)'); rg.addColorStop(1, TY.glow + '0)');
        ctx.fillStyle = rg; ctx.fillRect(0, ty - S * 1.2, w, S * 1.3);
      }
      // translucent lip glow
      const lg = ctx.createLinearGradient(0, ty - S, 0, ty - S * 0.7);
      lg.addColorStop(0, 'rgba(210,255,245,.22)'); lg.addColorStop(1, 'rgba(210,255,245,0)');
      ctx.fillStyle = lg; ctx.fillRect(0, ty - S * 1.1, w, S * 0.45);
      // water texture streaks anchored to the world (they scroll by → speed)
      const gx = 0.22, x0 = camX - lay.cx / S, k0 = Math.floor(x0 / gx) - 1, k1 = Math.ceil((camX + (w - lay.cx) / S) / gx) + 1;
      ctx.strokeStyle = 'rgba(255,255,255,.13)'; ctx.lineWidth = 1.3; ctx.beginPath();
      for (let k = k0; k <= k1; k++) {
        for (let r = 0; r < 6; r++) {
          const hsh = hash01(k, r, 3), wx = k * gx + hsh * gx, d = wx - K.C;
          if (d < 0.03) continue;
          const f = 0.12 + r * 0.14 + 0.03 * Math.sin(ts * 1.3 + k + r), hh = Hof(K, d), y = ty - f * hh * S, x = SX(wx), len = (0.06 + hash01(k, r, 9) * 0.1) * S;
          ctx.moveTo(x, y); ctx.lineTo(x + len, y - len * 0.04);
        }
      }
      ctx.stroke();
      // pocket: the face is steepest and darkest right next to the curl
      const pcx = SX(K.C);
      if (pcx > -S && pcx < w + S) {
        const pg = ctx.createLinearGradient(pcx - S * 0.25, 0, pcx + S * 0.9, 0);
        pg.addColorStop(0, 'rgba(0,18,30,.32)'); pg.addColorStop(0.2, 'rgba(0,18,30,.3)'); pg.addColorStop(1, 'rgba(0,18,30,0)');
        ctx.fillStyle = pg; ctx.fillRect(pcx - S * 0.25, ty - S * 1.2, S * 1.15, S * 1.3);
      }
      // translucent band just under the lip
      ctx.lineJoin = 'round';
      ctx.beginPath(); let lb = false;
      for (let i = 0; i <= COLS; i++) { if (cD[i] < 0) continue; const y = ty - cH[i] * S + S * 0.06; if (!lb) { ctx.moveTo(cXs[i], y); lb = true; } else ctx.lineTo(cXs[i], y); }
      ctx.strokeStyle = 'rgba(200,255,240,.11)'; ctx.lineWidth = S * 0.12; ctx.stroke();
      ctx.strokeStyle = 'rgba(230,255,250,.14)'; ctx.lineWidth = S * 0.05; ctx.stroke();
      // tube shadow
      if (K.TLc > 0.06) {
        const cx0 = SX(K.C), H0 = Hof(K, 0);
        const tg = ctx.createLinearGradient(cx0, 0, SX(K.C + K.TLc), 0);
        tg.addColorStop(0, 'rgba(2,14,26,.5)'); tg.addColorStop(0.7, 'rgba(2,14,26,.3)'); tg.addColorStop(1, 'rgba(2,14,26,0)');
        ctx.fillStyle = tg;
        ctx.beginPath(); ctx.moveTo(cx0, ty + 1);
        for (let i = 0; i <= 12; i++) { const d = K.TLc * i / 12, hh = Hof(K, d); ctx.lineTo(SX(K.C + d), ty - tubeCeil(K, Math.min(d, K.TLc - 1e-4), hh) * S); }
        ctx.lineTo(SX(K.C + K.TLc), ty + 1); ctx.closePath(); ctx.fill();
        void H0;
      }
      ctx.restore();
      // lip edge
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 2;
      ctx.beginPath(); let st0 = false;
      for (let i = 0; i <= COLS; i++) { if (cD[i] < 0) continue; const y = ty - cH[i] * S; if (!st0) { ctx.moveTo(cXs[i], y); st0 = true; } else ctx.lineTo(cXs[i], y); }
      ctx.stroke();
    }
    function drawCurtainFoam(K, TY, now) {
      if (K.rise <= 0.001) return;
      const S = lay.S, ty = lay.ty, ts = now / 1000, cx0 = SX(K.C), H0 = Hof(K, 0);
      // thrown lip (barrel curtain)
      if (K.TLc > 0.06) {
        ctx.save(); ctx.lineCap = 'round';
        ctx.beginPath();
        for (let i = 0; i <= 14; i++) { const d = K.TLc * i / 14, hh = Hof(K, d), y = ty - tubeCeil(K, Math.min(d, K.TLc - 1e-4), hh) * S; if (!i) ctx.moveTo(SX(K.C + d), y); else ctx.lineTo(SX(K.C + d), y); }
        ctx.strokeStyle = 'rgba(150,225,220,.55)'; ctx.lineWidth = Math.max(6, S * 0.1); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2; ctx.stroke();
        ctx.restore();
      }
      if (cx0 < lay.pl - S * 0.3) { // whitewater is off screen to the left: a soft glow warns it is coming
        const a = clamp(1 - (lay.pl - cx0 - S * 0.3) / (S * 1.2), 0, 1) * 0.5;
        if (a > 0.02) { const x0 = lay.pl, g = ctx.createLinearGradient(x0, 0, x0 + 30, 0); g.addColorStop(0, 'rgba(255,255,255,' + a + ')'); g.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = g; ctx.fillRect(x0, ty - S * H0, 30, S * H0); }
        return;
      }
      // whitewater mass behind the curl
      ctx.beginPath(); ctx.moveTo(-4, ty + 3);
      for (let i = 0; i <= COLS; i++) { if (cD[i] >= 0) break; ctx.lineTo(cXs[i], ty - cH[i] * S * (1.02 + 0.04 * Math.sin(cD[i] * 9 + ts * 3))); }
      ctx.lineTo(cx0 + S * 0.05, ty - H0 * S * 1.02);
      ctx.lineTo(cx0 - S * 0.18, ty + 3); ctx.closePath();
      const fg = ctx.createLinearGradient(0, ty - S, 0, ty);
      fg.addColorStop(0, TY.foam); fg.addColorStop(1, 'rgba(200,228,232,.95)');
      ctx.fillStyle = fg; ctx.fill();
      // puffy blobs along the front and top
      ctx.fillStyle = TY.foam;
      for (let i = 0; i < 9; i++) {
        const f = i / 8, x = cx0 + S * (0.05 - 0.23 * f), y = ty - H0 * S * (1 - f) * 1.0, r = S * (0.06 + 0.035 * Math.sin(ts * 5 + i * 1.9));
        ctx.beginPath(); ctx.arc(x, y, Math.max(2, r), 0, TAU); ctx.fill();
      }
      for (let i = 1; i < 10; i++) {
        const dd = -((i * 0.17 + ts * 0.22) % 1.7), x = cx0 + dd * S; if (x < -S * 0.2) continue;
        const y = ty - Hof(K, dd) * S * 1.02, r = S * (0.07 + 0.03 * Math.sin(ts * 4 + i));
        ctx.beginPath(); ctx.arc(x, y, Math.max(2, r), 0, TAU); ctx.fill();
      }
      ctx.fillStyle = 'rgba(160,200,210,.35)';
      for (let i = 0; i < 6; i++) { const x = cx0 - S * (0.25 + i * 0.22), y = ty - S * H0 * (0.35 + 0.2 * Math.sin(ts * 2 + i)); ctx.beginPath(); ctx.arc(x, y, S * 0.05, 0, TAU); ctx.fill(); }
      const mg = ctx.createRadialGradient(cx0, ty - H0 * S, 2, cx0, ty - H0 * S, S * 0.6);
      mg.addColorStop(0, 'rgba(255,255,255,.45)'); mg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = mg; ctx.fillRect(cx0 - S * 0.6, ty - H0 * S - S * 0.6, S * 1.2, S * 1.2);
    }
    function drawSurfer(x, y, ang, sc, col, pose, now) {
      ctx.save(); ctx.translate(x, y);
      if (pose.flip) ctx.scale(-1, 1);
      if (pose.tumble != null) ctx.rotate(pose.tumble);
      ctx.rotate(-ang);
      if (pose.spin != null) { const c = Math.cos(pose.spin * TAU); ctx.scale((c < 0 ? -1 : 1) * Math.max(0.14, Math.abs(c)), 1); }
      const Lb = sc * 1.05, Tb = Math.max(2, sc * 0.075);
      // board
      ctx.beginPath(); ctx.moveTo(-Lb * 0.36, Tb * 0.6); ctx.lineTo(-Lb * 0.44, Tb * 2.6); ctx.lineTo(-Lb * 0.3, Tb * 0.6); ctx.fillStyle = '#2a2a30'; ctx.fill();
      ctx.beginPath(); ctx.ellipse(0, 0, Lb / 2, Tb, 0, 0, TAU); ctx.fillStyle = '#f6f0e2'; ctx.fill();
      ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(30,20,30,.35)'; ctx.stroke();
      ctx.beginPath(); ctx.ellipse(Lb * 0.02, 0, Lb * 0.42, Tb * 0.38, 0, 0, TAU); ctx.fillStyle = col; ctx.fill();
      const lw = Math.max(2, sc * 0.085), skin = '#e3b08a', suit = '#1c2433';
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      if (pose.lie) { // paddling on the board
        const ph = now / 1000 * 5;
        ctx.strokeStyle = suit; ctx.lineWidth = lw;
        ctx.beginPath(); ctx.moveTo(-Lb * 0.32, -Tb); ctx.lineTo(-Lb * 0.05, -Tb * 1.4); ctx.stroke();
        ctx.strokeStyle = col; ctx.lineWidth = lw * 1.5;
        ctx.beginPath(); ctx.moveTo(-Lb * 0.05, -Tb * 1.4); ctx.lineTo(Lb * 0.16, -Tb * 1.6); ctx.stroke();
        ctx.strokeStyle = skin; ctx.lineWidth = lw * 0.8;
        ctx.beginPath(); ctx.moveTo(Lb * 0.14, -Tb * 1.5); ctx.lineTo(Lb * 0.14 + Math.cos(ph) * sc * 0.18, -Tb * 1.5 + Math.sin(ph) * sc * 0.16 + sc * 0.08); ctx.stroke();
        ctx.beginPath(); ctx.arc(Lb * 0.24, -Tb * 2.2, sc * 0.075, 0, TAU); ctx.fillStyle = skin; ctx.fill();
        ctx.beginPath(); ctx.arc(Lb * 0.23, -Tb * 2.5, sc * 0.07, Math.PI, TAU); ctx.fillStyle = '#2b1d18'; ctx.fill();
        ctx.restore(); return;
      }
      ctx.rotate(ang * 0.55 + (pose.lean || 0));
      const cr = pose.crouch || 0, hip = sc * (0.44 - 0.12 * cr), sh = sc * (0.8 - 0.2 * cr), fy = -Tb;
      const g = pose.grab;
      // legs
      ctx.strokeStyle = suit; ctx.lineWidth = lw;
      ctx.beginPath(); ctx.moveTo(-sc * 0.17, fy); ctx.lineTo(-sc * 0.06 + sc * 0.06 * cr, fy - hip * 0.5); ctx.lineTo(0, -hip); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(sc * 0.17, fy); ctx.lineTo(sc * 0.16 + sc * 0.05 * cr, fy - hip * 0.52); ctx.lineTo(sc * 0.02, -hip); ctx.stroke();
      // torso (vest in seat colour)
      ctx.strokeStyle = col; ctx.lineWidth = lw * 1.6;
      ctx.beginPath(); ctx.moveTo(0, -hip); ctx.lineTo(sc * 0.06, -sh); ctx.stroke();
      // arms
      ctx.strokeStyle = skin; ctx.lineWidth = lw * 0.75;
      if (g) {
        ctx.beginPath(); ctx.moveTo(sc * 0.06, -sh + sc * 0.04); ctx.lineTo(sc * 0.2, -hip * 0.6); ctx.lineTo(sc * 0.24, fy - Tb * 0.5); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(sc * 0.05, -sh + sc * 0.04); ctx.lineTo(-sc * 0.22, -sh - sc * 0.12); ctx.stroke();
      } else {
        const wv = Math.sin(now / 260) * 0.03 * sc;
        ctx.beginPath(); ctx.moveTo(sc * 0.06, -sh + sc * 0.04); ctx.lineTo(sc * 0.2, -sh + sc * 0.12); ctx.lineTo(sc * 0.33, -sh + sc * 0.06 + wv); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(sc * 0.05, -sh + sc * 0.04); ctx.lineTo(-sc * 0.14, -sh + sc * 0.1); ctx.lineTo(-sc * 0.3, -sh + sc * 0.02 - wv); ctx.stroke();
      }
      // head
      const hx = sc * 0.08, hy = -sh - sc * 0.1;
      ctx.beginPath(); ctx.arc(hx, hy, sc * 0.08, 0, TAU); ctx.fillStyle = skin; ctx.fill();
      ctx.beginPath(); ctx.arc(hx - sc * 0.01, hy - sc * 0.015, sc * 0.08, Math.PI * 0.95, Math.PI * 2.05); ctx.fillStyle = '#2b1d18'; ctx.fill();
      ctx.restore();
    }
    function drawSurferOf(K, s, now) {
      const TY = TYPES[K.bt], sc = TY.sz * lay.S, col = Pl(s).color;
      if (K.mode === 'paddle' || K.mode === 'done') {
        const bob = Math.sin(now / 400) * 2;
        drawSurfer(SX(K.X), SY(K.y) + 4 + bob, 0, sc, col, { lie: true }, now);
        return;
      }
      if (K.mode === 'wipe') {
        const f = 1 - K.mt / WIPE_T;
        ctx.globalAlpha = clamp(1.4 - f * 1.2, 0.25, 1);
        drawSurfer(SX(K.wx), SY(Math.max(0, K.wy)) + f * 10, 0, sc, col, { tumble: f * 9 + K.seat, crouch: 1 }, now);
        ctx.globalAlpha = 1;
        return;
      }
      if (K.mode === 'air') {
        const vdir = Math.atan2(K.vy, K.vx);
        drawSurfer(SX(K.X), SY(K.y), vdir + K.off, sc, col, { spin: K.sp >= 0 ? K.sp : null, grab: K.grab, crouch: K.grab ? 0.9 : 0.5 }, now);
        return;
      }
      const back = Math.cos(K.th) < 0; // cutting back: mirror the surfer instead of drawing him upside down
      drawSurfer(SX(K.X), SY(K.y), back ? Math.PI - K.th : K.th, sc, col, { flip: back, crouch: clamp(0.3 + Math.abs(K.om) * 0.18 + (K.inT ? 0.5 : 0), 0, 1), lean: clamp(-K.om * 0.06, -0.25, 0.25) }, now);
    }
    function drawTrail(K) {
      if (trail.length < 4) return;
      ctx.lineCap = 'round';
      const n = trail.length / 2;
      for (let i = 1; i < n; i++) {
        const a = i / n;
        ctx.strokeStyle = 'rgba(255,255,255,' + (a * 0.55) + ')'; ctx.lineWidth = 1 + a * 3;
        ctx.beginPath(); ctx.moveTo(SX(trail[i * 2 - 2]), SY(trail[i * 2 - 1])); ctx.lineTo(SX(trail[i * 2]), SY(trail[i * 2 + 1])); ctx.stroke();
      }
      void K;
    }
    function drawParts(TY) {
      const S = lay.S;
      for (const q of parts) {
        const a = clamp(q.t / q.T, 0, 1), x = SX(q.x), y = SY(q.y);
        if (x < -10 || x > lay.w + 10) continue;
        ctx.globalAlpha = q.k === 2 ? a * 0.8 : a * 0.9;
        ctx.fillStyle = q.k === 1 ? 'rgba(255,255,255,.8)' : TY.foam;
        ctx.beginPath(); ctx.arc(x, y, Math.max(1, q.r * S * (q.k === 2 ? 1.4 - a * 0.4 : 1)), 0, TAU); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
    function drawFloats() {
      for (const f of floats) {
        const a = clamp(f.t / f.T * 2.2, 0, 1), rise = (1 - f.t / f.T) * 34;
        const Kv = KS[view], fx = f.fol && Kv ? (Kv.mode === 'wipe' ? Kv.wx : Kv.X) : f.x;
        const x = clamp(SX(fx), lay.pl + 70, lay.pr - 70), y = Math.max(lay.top + (lay.land ? lay.rowH + 18 : 22), SY(f.y) - rise - (f.slot || 0) * 36);
        ctx.globalAlpha = a;
        const font = (f.big ? '800 17px ' : '700 14px ') + FONT;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,20,30,.55)'; ctx.font = font; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const t = fitText(f.text, lay.pw - 30, font);
        ctx.strokeText(t, x, y); txt(t, x, y, f.bad ? '#ffb4a4' : f.big ? '#ffe08a' : '#ffffff', font);
        if (f.sub) { ctx.font = '700 13px ' + MONO; ctx.strokeText(f.sub, x, y + 17); txt(f.sub, x, y + 17, '#bff3d0', '700 13px ' + MONO); }
        ctx.globalAlpha = 1;
      }
    }
    function totalOf(s) { const r = rowOf(s), b = best2(r.r); return (b[0] + b[1]) / 100; }
    function drawHud() {
      const w = lay.w, n = st.n;
      ctx.fillStyle = 'rgba(14,10,22,.78)'; ctx.fillRect(0, 0, w, lay.hudH);
      const cw = (w - 12 - (n - 1) * 6) / n;
      let lead = -1, lv = -1; for (let s = 0; s < n; s++) { const t = totalOf(s); if (t > lv + 1e-9) { lv = t; lead = s; } }
      for (let s = 0; s < n; s++) {
        const x = 6 + s * (cw + 6), y = 4, hh = lay.hudH - 8, r = rowOf(s);
        rrect(ctx, x, y, cw, hh, 9); ctx.fillStyle = s === view ? 'rgba(227,174,69,.2)' : 'rgba(255,255,255,.06)'; ctx.fill();
        if (s === view) { ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(227,174,69,.85)'; ctx.stroke(); }
        if (lay.land) { // one line: dot, name ... total
          const my = y + hh / 2, tot = totalOf(s).toFixed(2), tF = '700 14px ' + MONO;
          ctx.beginPath(); ctx.arc(x + 10, my, 4.5, 0, TAU); ctx.fillStyle = Pl(s).color; ctx.fill();
          ctx.font = tF; const tw = ctx.measureText(tot).width;
          const nmF = '700 11px ' + FONT;
          txt(fitText(name(s), cw - 30 - tw, nmF), x + 18, my + 0.5, '#f2e9d8', nmF, 'left');
          txt(tot, x + cw - 8, my + 1, lead === s && lv > 0 ? '#ffd774' : '#f2e9d8', tF, 'right');
          const md = r.m;
          if ((md === 1 || md === 2 || md === 3) && cw > 120 && !(chipPop[s] && chipPop[s].v > 0)) txt(md === 3 ? '×' : '●', x + cw - 14 - tw, my + 1, md === 3 ? '#ff9a8a' : '#7fe0d0', '700 10px ' + FONT, 'right');
          const cp = chipPop[s];
          if (cp && cp.v > 0) { const a = clamp(cp.t, 0, 1); ctx.globalAlpha = a; rrect(ctx, x + cw - 48, y + 4, 44, hh - 8, (hh - 8) / 2); ctx.fillStyle = '#e3ae45'; ctx.fill(); txt(cp.v.toFixed(2), x + cw - 26, my + 1, '#1a1020', '800 12px ' + MONO); ctx.globalAlpha = 1; }
          continue;
        }
        ctx.beginPath(); ctx.arc(x + 10, y + 11, 4.5, 0, TAU); ctx.fillStyle = Pl(s).color; ctx.fill();
        const nmF = '700 11px ' + FONT;
        txt(fitText(name(s), cw - 24, nmF), x + 18, y + 11, '#f2e9d8', nmF, 'left');
        const tot = totalOf(s).toFixed(2);
        txt(tot, x + 8, y + hh - 9, lead === s && lv > 0 ? '#ffd774' : '#f2e9d8', '700 14px ' + MONO, 'left');
        const md = r.m;
        const tag = md === 1 || md === 2 ? '●' : md === 3 ? '×' : '';
        if (tag && cw > 70) txt(tag, x + cw - 9, y + hh - 9, md === 3 ? '#ff9a8a' : '#7fe0d0', '700 11px ' + FONT, 'right');
        const cp = chipPop[s];
        if (cp && cp.v > 0) { const a = clamp(cp.t, 0, 1); ctx.globalAlpha = a; rrect(ctx, x + cw - 44, y + hh - 19, 40, 17, 8.5); ctx.fillStyle = '#e3ae45'; ctx.fill(); txt(cp.v.toFixed(2), x + cw - 24, y + hh - 10, '#1a1020', '800 11px ' + MONO); ctx.globalAlpha = 1; }
      }
      // second row: wave number, live ride score, clock
      // (landscape: these two pills float over the sky between the side buttons)
      const K = KS[view], ry = lay.hudH + 4, rh = lay.rowH - 6, xl = lay.pl + 6, xr = lay.pr - 6;
      const left = Math.max(0, Math.ceil(st.T - Math.max(0, tl)));
      const clock = Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
      rrect(ctx, xr - 64, ry, 64, rh, rh / 2); ctx.fillStyle = left <= 10 && tl < st.T ? 'rgba(238,106,85,.9)' : 'rgba(14,10,22,.7)'; ctx.fill();
      txt(clock, xr - 32, ry + rh / 2 + 1, '#f2e9d8', '700 14px ' + MONO);
      const TY = TYPES[st.bt];
      let info = TY.n;
      if (K) {
        const rides = K.rides.length;
        if (K.mode === 'ride' || K.mode === 'air') info = rides + 1 + '번째 파도 · 지금 ' + base10(K.raw).toFixed(1);
        else if (rides) { const b = best2(K.rides); info = '베스트 ' + (b[0] / 100).toFixed(2) + (rides > 1 ? ' + ' + (b[1] / 100).toFixed(2) : ''); }
      }
      const iF = '700 12px ' + FONT, it = fitText(info, xr - xl - 92, iF);
      ctx.font = iF; const iw = ctx.measureText(it).width + 20;
      rrect(ctx, xl, ry, iw, rh, rh / 2); ctx.fillStyle = 'rgba(14,10,22,.62)'; ctx.fill();
      txt(it, xl + 10, ry + rh / 2 + 1, '#f2e9d8', iF, 'left');
    }
    function drawFlash() {
      if (!flash) return;
      const w = lay.w, t = flash.t, a = clamp(Math.min(t * 5, (3.6 - t) * 3), 0, 1);
      const pw = Math.min(lay.pw - 16, 360), ph = 112, px = lay.cx - pw / 2, py = lay.top + (lay.land ? lay.rowH + 2 : 6);
      ctx.globalAlpha = a;
      rrect(ctx, px, py, pw, ph, 14); ctx.fillStyle = 'rgba(20,14,30,.88)'; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.stroke();
      const who = !isMine(flash.seat) ? name(flash.seat) + ' · ' : '';
      const tf = '700 12px ' + FONT;
      txt(fitText(who + flash.n + '번째 파도 · ' + flash.why + (flash.wiped ? ' (−15%)' : ''), pw - 24, tf), px + 12, py + 15, flash.wiped ? '#ffb4a4' : '#cfc3dc', tf, 'left');
      const bw = Math.min(46, (pw - 120) / 5 - 6), bx = px + 12;
      for (let k = 0; k < 5; k++) {
        const show = t > 0.15 + k * 0.12, x = bx + k * (bw + 6), y = py + 32;
        rrect(ctx, x, y, bw, 40, 8);
        const drop = (k === flash.hi || k === flash.lo) && t > 1.0;
        ctx.fillStyle = show ? (drop ? 'rgba(255,255,255,.08)' : '#f2e9d8') : 'rgba(255,255,255,.12)'; ctx.fill();
        if (show) {
          txt(flash.j[k].toFixed(1), x + bw / 2, y + 21, drop ? 'rgba(242,233,216,.45)' : '#1a1020', '800 15px ' + MONO);
          if (drop) { ctx.strokeStyle = 'rgba(238,106,85,.85)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + 6, y + 30); ctx.lineTo(x + bw - 6, y + 12); ctx.stroke(); }
        }
        txt('심판' + (k + 1), x + bw / 2, y + 50, '#ab9fb8', '600 9px ' + FONT);
      }
      if (t > 1.1) {
        const rx = px + pw - 14;
        txt(flash.sc.toFixed(2), rx, py + 52, flash.sc >= 8 ? '#ffd774' : '#f2e9d8', '400 30px ' + DISP, 'right');
        txt('점', rx, py + 74, '#ab9fb8', '600 10px ' + FONT, 'right');
      }
      const bf = '600 11px ' + FONT, bt = flash.best && flash.best.length ? '좋았던 기술: ' + flash.best.join(', ') : (flash.wiped ? '' : '기술이 없었어요');
      if (bt) txt(fitText(bt, pw - 24, bf), px + 12, py + ph - 14, '#bff3d0', bf, 'left');
      ctx.globalAlpha = 1;
    }
    function btnDraw(b, label, sub, on, enabled, glyph) {
      if (lay.land && !on) { rrect(ctx, b.x, b.y, b.w, b.h, 14); ctx.fillStyle = 'rgba(14,10,22,.5)'; ctx.fill(); } // readable over the water
      rrect(ctx, b.x, b.y, b.w, b.h, 14);
      ctx.fillStyle = on ? 'rgba(227,174,69,.9)' : enabled ? 'rgba(242,233,216,.14)' : 'rgba(242,233,216,.06)'; ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = on ? '#ffe2a0' : 'rgba(242,233,216,.28)'; ctx.stroke();
      const c = on ? '#1a1020' : enabled ? '#f2e9d8' : 'rgba(242,233,216,.45)';
      if (glyph) txt(glyph, b.x + b.w / 2, b.y + b.h / 2 - 8, c, '800 22px ' + FONT);
      txt(label, b.x + b.w / 2, b.y + b.h / 2 + (glyph ? 14 : -2), c, '700 13px ' + FONT);
      if (sub && !glyph) txt(sub, b.x + b.w / 2, b.y + b.h / 2 + 15, c, '600 10px ' + FONT);
    }
    function drawControls(K) {
      if (lay.bar) { ctx.fillStyle = 'rgba(14,10,22,.55)'; ctx.fillRect(0, lay.bar.y, lay.w, lay.bar.h); }
      const H = held(), air = K.mode === 'air';
      btnDraw(lay.btn.L, air ? '↺ 돌기' : '위로', null, H.up, true, air ? null : '▲');
      btnDraw(lay.btn.R, air ? '↻ 돌기' : '아래로', null, H.dn, true, air ? null : '▼');
      btnDraw(lay.btn.spin, air ? '스핀' : '컷백', air ? '공중에서' : '물살 쪽으로', btnFlash.spin > 0 || (K.sp >= 0 && air) || K.cb >= 0, air || K.mode === 'ride', null);
      btnDraw(lay.btn.grab, '그랩', '누르고 있기', H.gr, air || K.mode === 'ride', null);
    }
    function hintFor(K) {
      if (!K) return '';
      if (!mine().length) return 'AI 경기 관전 중 · 위 이름을 누르면 다른 선수를 봐요';
      if (!isMine(view)) return '';
      if (tl < 0) return '곧 시작! 왼쪽 = 위로 · 오른쪽 = 아래로';
      if (tl >= st.T) return '경기 끝! 점수를 모으는 중…';
      const d = K.X - K.C;
      switch (K.mode) {
        case 'paddle': return K.rides.length ? '다음 파도를 기다려요' : '파도가 와요! 왼쪽 = 위로 · 오른쪽 = 아래로';
        case 'wipe': return '넘어졌어요! 다음 파도를 타요';
        case 'air': return '공중! 돌기 · 스핀 · 그랩 → 보드를 나란히 착지';
        case 'ride':
          if (K.cb >= 0) return '컷백! 물살 쪽으로 돌았다가 다시 달려요';
          if (K.inT) return '튜브 안! 하얀 물살보다 먼저 빠져나와요';
          if (d < 0.25) return '하얀 물살이 쫓아와요! 아래로 내려가 속도를 내요';
          if (K.v < 1.4) return '느려요! 위아래로 번갈아 타며 펌핑해요';
          if (d > 1.6) return '포켓에서 멀어요! 컷백으로 물살 쪽으로 돌아가요';
          if (coach < 14) return '꼭대기를 빠르게 치고 오르면 날아올라요';
          return '포켓 가까이서 탈수록 점수가 높아요';
        default: return '';
      }
    }
    function draw(now, rdt) {
      cv.clear();
      if (!lay) layout();
      const w = lay.w, h = lay.h;
      if (!st) { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h); return; }
      const TY = TYPES[st.bt] || TYPES[0], K = KS[view];
      // camera
      if (K) {
        const X = K.mode === 'wipe' ? K.wx : K.X, d = X - K.C;
        const fs = clamp(0.33 + 0.1 * d, 0.33, 0.5), pw = lay.pw, tgt = X + (0.5 - fs) * pw / lay.S;
        if (!camInit || Math.abs(tgt - camX) > 3) { camX = tgt; camInit = true; } else camX += (tgt - camX) * Math.min(1, (rdt || 0.016) * SPD() * 5);
        const sx = (X - camX) * lay.S / pw; // keep the surfer on screen (between the side buttons) whatever the smoothing
        if (sx > 0.3) camX = X - 0.3 * pw / lay.S; else if (sx < -0.36) camX = X + 0.36 * pw / lay.S;
      }
      ctx.save();
      if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 6, (Math.random() - 0.5) * shake * 6);
      ctx.drawImage(skyLayer(TY), 0, 0, w, lay.ty + 2 / Math.min(2, cv.dpr || 1));
      drawWater(K, TY, now);
      if (K) {
        drawTrail(K);
        const inside = K.mode === 'ride' && K.inT;
        if (inside) drawSurferOf(K, view, now);
        drawCurtainFoam(K, TY, now);
        if (!inside) drawSurferOf(K, view, now);
        drawParts(TY);
      }
      ctx.restore();
      drawFloats();
      drawHud();
      drawFlash();
      // countdown / end
      const cx = lay.cx, rowT = lay.land ? lay.rowH : 0, cy0 = lay.top + rowT + (lay.ty - lay.top - rowT) * 0.35;
      if (tl < 0) {
        const n = Math.ceil(-tl);
        txt(String(n), cx, cy0, '#ffe08a', '400 64px ' + DISP);
        txt(fitText(TY.n + ' · ' + TY.sub, lay.pw - 16, '700 13px ' + FONT), cx, cy0 + 50, '#f2e9d8', '700 13px ' + FONT);
      } else if (tl < 0.7 && st.ph === 'play') {
        ctx.globalAlpha = 1 - tl / 0.7; txt('경기 시작!', cx, cy0, '#ffe08a', '400 42px ' + DISP); ctx.globalAlpha = 1;
      } else if (tl >= st.T) {
        const ey = lay.land ? cy0 + 20 : lay.top + 153;
        rrect(ctx, cx - 90, ey - 23, 180, 46, 23); ctx.fillStyle = 'rgba(20,14,30,.85)'; ctx.fill();
        txt('경기 끝!', cx, ey, '#ffe08a', '400 24px ' + DISP);
      }
      // hint + controls
      const hint = hintFor(K);
      if (hint) {
        const hf = '600 12px ' + FONT, ht = fitText(hint, lay.pw - 16, hf), hy = lay.bot + lay.hintH / 2;
        if (lay.land) { ctx.font = hf; const tw = ctx.measureText(ht).width + 20; rrect(ctx, cx - tw / 2, hy - 10, tw, 20, 10); ctx.fillStyle = 'rgba(14,10,22,.55)'; ctx.fill(); }
        txt(ht, cx, hy, '#f2e9d8', hf);
      }
      if (K && isMine(view) && lay.btn && (lay.bar || lay.land)) drawControls(K);
      else if (lay.bar) { ctx.fillStyle = 'rgba(14,10,22,.55)'; ctx.fillRect(0, lay.bar.y, w, lay.bar.h); txt(TY.n + ' · 심판 5명 · 베스트 2 합산', w / 2, lay.bar.y + lay.bar.h / 2, '#ab9fb8', '600 12px ' + FONT); }
    }

    const stop = U.loop(frame);
    root._sf = { lay: () => lay, K: () => KS[view], KS: () => KS, tl: () => tl }; // test hook
    return {
      update(state) {
        st = state;
        if (!st) return;
        if (st.ph === 'done' && key === curKey()) tl = Math.max(tl, st.T);
      },
      destroy() {
        stop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        try { if (offIn) offIn(); } catch (e) {}
        ptrs.clear();
        cv.destroy();
      },
    };
  }

  L.register({
    id: 'surf', name: '서핑 대회', tag: '실시간 서핑 경기', cat: '스포츠',
    blurb: '부서지는 파도 위를 오르내리며 속도를 내고, 꼭대기에서 날아올라 기술을 펼쳐요. 심판 5명이 매긴 점수 중 베스트 2 합산으로 승부!',
    tint: '#14566a',
    icon: '<path d="M5 41c6-15 17-24 30-24 9 0 14 6 14 12 0 5-4 8-8 8-4 0-6-3-5-6" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M4 49c6-3 10-3 16 0s10 3 16 0 10-3 16 0" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><ellipse cx="23" cy="34" rx="12" ry="3" transform="rotate(-24 23 34)" fill="currentColor"/><circle cx="25" cy="18" r="3.5" fill="currentColor"/><path d="M25 22l-2 9" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0, landscape: true,
    options: [
      { id: 'time', label: '경기 시간', choices: [{ v: 60, label: '60초' }, { v: 90, label: '90초' }, { v: 120, label: '2분' }], def: 90 },
      { id: 'beach', label: '해변', choices: [{ v: 0, label: '아침 해변' }, { v: 1, label: '큰 파도' }, { v: 2, label: '노을 리프' }, { v: -1, label: '무작위' }], def: -1 },
    ],
    controls: [
      { id: 'up', label: '위로 (공중: ↺ 돌기)', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 (공중: ↻ 돌기)', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'spin', label: '스핀', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'cut', label: '컷백', keys: ['KeyL', 'KeyC'], pad: ['b'] },
      { id: 'grab', label: '그랩 (누르고 있기)', keys: ['KeyK', 'ShiftLeft'], pad: ['x', 'rt'] },
    ],
    quick: [
      '목표: 정해진 시간 동안 파도를 여러 번 타고, 가장 잘 탄 파도 2개의 점수 합계로 겨뤄요.',
      '할 일: 왼쪽 = 위로, 오른쪽 = 아래로 보드를 틀어 파도 면을 오르내리며 속도를 내요.',
      '이기는 법: 하얀 물살 가까이에서 턴·에어·튜브 같은 기술을 하고, 넘어지지 않게 착지해요.',
    ],
    rules: [
      { h: '목표', p: [
        '경기 시간(기본 90초) 동안 파도를 여러 번 타요. 파도 하나를 다 타면 심판 5명이 0~10점을 매겨요.',
        '가장 높은 점수와 가장 낮은 점수는 빼고, 나머지 3명의 평균이 그 파도의 점수예요.',
        '내 파도 중 가장 잘 탄 2개의 합계(최대 20점)가 가장 높은 사람이 우승! 혼자 하면 합계로 별 0~3개(8 / 11.5 / 14.5점).',
        '모두 똑같은 순서의 파도를 각자 동시에 타요. 맨 위 줄에 모두의 점수가 실시간으로 보여요.',
      ] },
      { h: '할 일 (조작)', p: [
        '가로 화면: 왼쪽 끝 큰 버튼 ▲ = 위로, 오른쪽 끝 큰 버튼 ▼ = 아래로. 그 위의 작은 버튼은 왼쪽 「컷백/스핀」, 오른쪽 「그랩」이에요. 버튼 말고 화면 왼쪽 절반·오른쪽 절반을 눌러도 위로·아래로예요.',
        '세로 화면: 아래쪽 버튼 줄(▲ 위로 · 컷백 · 그랩 · ▼ 아래로)을 써요.',
        '누르고 있는 동안 보드가 계속 돌아가요. 손가락을 위아래로 끌어서 조금씩 틀 수도 있어요.',
        '파도는 왼쪽부터 하얗게 부서지며 오른쪽으로 쫓아와요. 하얀 물살에 잡히면 넘어져요.',
        '내려갈 때 속도가 붙고 올라갈 때 줄어요. 위아래로 번갈아 틀면(펌핑) 속도가 붙어요. 하얀 물살 바로 옆 「포켓」이 가장 힘이 좋아요.',
        'PC 키보드·게임패드: ↑/↓ 위·아래, 스페이스 컷백/스핀, L 컷백, K 그랩. 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '기술', p: [
        '탑 턴: 꼭대기 근처까지 올라갔다가 돌아 내려오기. 빠르고 날카로우면 스냅, 꼭대기를 치고 돌면 리엔트리.',
        '바텀 턴: 아래까지 내려갔다가 힘차게 위로 꺾기.',
        '컷백: 「컷백」 버튼(또는 옆으로 휙 밀기) → 하얀 물살 쪽으로 크게 돌았다가 다시 앞으로 달려요. 포켓에서 멀어졌을 때 돌아가는 기술. 물살 바로 옆까지 돌아오면 라운드하우스 컷백.',
        '에어: 빠르게 꼭대기를 치고 오르면 공중으로 날아요. 천천히 닿으면 꼭대기를 타고 미끄러져요(플로터).',
        '공중에서: ▲/▼를 누르고 있으면 몸이 돌아요(한 바퀴 = 플립). 왼쪽 위 버튼은 공중에서 「스핀」(360 스핀)이 되고, 「그랩」은 누르는 동안 보드를 잡아요.',
        '튜브: 파도 끝이 말려 넘어오는 구간이 있어요. 그 아래 어두운 곳에 들어가 버티다 빠져나오면 큰 점수. 튜브가 닫히면 넘어져요.',
      ] },
      { h: '착지 · 넘어짐', p: [
        '착지할 때 보드가 날아가는 방향과 나란해야 해요. 손을 떼면 보드가 저절로 맞춰져요.',
        '스핀이 반쯤 돈 채로 떨어지면 넘어져요. 그랩을 쥔 채 착지하면 흔들려서 그 기술 점수가 반이에요.',
        '넘어지면 그 파도 점수가 15% 깎이고 파도가 끝나요. 잠시 뒤 다음 파도를 타요. 파도 끝까지 가면 자연스럽게 빠져나와요(킥아웃).',
      ] },
      { h: '점수 · 승리', p: [
        '높이 오를수록, 빠를수록, 하얀 물살(포켓) 가까이일수록 기술 점수가 커요. 여러 기술을 섞은 에어는 보너스.',
        '같은 기술만 반복하면 점점 점수가 줄어요. 심판은 한 파도에서 가장 좋은 기술 몇 개를 주로 봐요.',
        '예시: 파도 점수가 6.5 · 8.2 · 4.0이면 베스트 2개 8.2 + 6.5 = 14.7점이에요.',
      ] },
      { h: '해변 3곳', p: [
        '아침 해변: 부드럽고 느린 파도, 처음이면 여기. 큰 파도: 높고 빨라서 속도를 계속 내야 해요. 노을 리프: 튜브가 자주 생겨요. 무작위도 있어요.',
      ] },
      { h: '함께 하기', p: [
        '가로 화면용 게임이에요. 폰을 돌릴 수 없으면 「세로로 그냥 하기」로 세로 화면에서도 할 수 있어요.',
        '한 폰에서는 한 명만 서핑해요. 나머지 자리는 AI 서퍼예요. 친구와는 온라인·LAN 방으로 각자 폰에서 해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 기술이 적고 착지가 서툴러요. 어려움은 튜브를 노리고 두 바퀴 플립도 해요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { TYPES, waveAt, newSurfer, stepS, aiThink, Hof, judges, best2, finish, base10, STEP },
  });
})();
