/* 종이비행기 날리기 — 접는 방식(다트형·글라이더형·곡예형)을 고르고 뒤로 끌었다 놓아 던진다.
   비행은 양력·항력·실속·바람·상승기류가 있는 2D 활공 모델을 고정 스텝으로 apply에서 끝까지 계산하고,
   뷰는 last(조건·접기·초기 속도)로 같은 시뮬레이션을 재생한다. 시뮬 안에서는 + − × ÷ √ 와 정수 해시만 쓴다(결정적). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const GR = 9.81, DT = 0.01, MAXK = 2600, KF = 1.25;
  const r1 = (v) => Math.round(v * 10) / 10, r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* ---------- 접는 방식 ---------- */
  // vt: 균형 속도(m/s), ld: 양항비, c: 양력 상한 계수(클수록 세게 던지면 들림/공중제비), vmin~vmax: 던지기 속도
  const FOLDS = [
    { id: 'dart', name: '다트형', vt: 9.6, ld: 4.6, c: 0.55, vmin: 4, vmax: 17, bars: [5, 2, 1], tip: '빠르고 곧게 · 바람에 강해요' },
    { id: 'glide', name: '글라이더형', vt: 5.0, ld: 7.2, c: 1.3, vmin: 3, vmax: 10.5, bars: [2, 5, 3], tip: '오래 떠 있어요 · 상승기류를 잘 타요' },
    { id: 'stunt', name: '곡예형', vt: 5.3, ld: 5.8, c: 30, vmin: 3, vmax: 14.5, bars: [3, 3, 5], tip: '세게 던지면 공중제비 · 높이 솟아요' },
  ];
  FOLDS.forEach((F) => { F.iv = 1 / (F.vt * F.vt); F.c1 = 1 + 1 / F.c; F.ic = 1 / F.c; F.ild = 1 / F.ld; });
  const BARN = ['속도', '활공', '상승'];

  /* ---------- 스테이지 (m, y 위쪽, 던지는 손 x=0) ---------- */
  // boxes: [x0, x1, y0, y1, tag]  zones: [cx, 반폭, y0, y1, 바람x, 바람y]  (종 모양으로 가운데가 가장 셈)
  const STAGES = [
    { id: 'class', name: '교실', goal: '멀리 · 칠판 맞히기', span: 3.7, start: [0, 1.55], end: 16, ga: 0, gv: 0.05, wr: 0,
      boxes: [[3.0, 4.3, 0, 0.76, 'desk'], [5.6, 6.9, 0, 0.76, 'desk'], [8.6, 9.9, 0, 0.76, 'desk'], [11.2, 12.5, 0, 0.76, 'desk'], [13.4, 14.9, 0, 1.08, 'lect'],
        [16, 60, 0, 30, 'wall'], [-30, 60, 3.3, 30, 'ceil'], [-30, -1.6, 0, 30, 'back']],
      zones: [[7.2, 1.15, 0.4, 3.3, 0, -2.3], [12.0, 0.75, 0, 2.7, 0, 1.7]] },
    { id: 'field', name: '운동장', goal: '과녁 맞히기', span: 7.5, start: [0, 1.6], end: 46, ga: 0.9, gv: 0.3, wr: 3,
      boxes: [], zones: [] },
    { id: 'roof', name: '옥상', goal: '멀리 · 옥상에 착륙', span: 18, start: [0, 10.6], end: 120, ga: 0.6, gv: 0.35, wr: 1.5,
      boxes: [[-30, 0.5, 0, 9, 'b0'], [6, 19, 0, 7.5, 'b1'], [24, 37, 0, 6.5, 'b2'], [42, 55, 0, 5.5, 'b3'], [60, 73, 0, 4.5, 'b4'], [78, 91, 0, 3.5, 'b5'], [96, 150, 0, 2.5, 'b6']],
      zones: [[21.5, 4, 0, 20, 0, 1.0], [39.5, 4, 0, 20, 0, 1.1], [57.5, 4, 0, 20, 0, 1.0], [75.5, 4, 0, 18, 0, 1.1], [93.5, 4, 0, 18, 0, 1.0]] },
    { id: 'river', name: '강변 다리', goal: '고리 통과', span: 11, start: [0, 8.2], end: 62, ga: 0.7, gv: 0.3, wr: 2, bank: 47,
      boxes: [[-30, 0.6, 6.1, 6.7, 'bridge'], [-7, -5.6, 0, 6.1, 'pier'], [47, 120, 0, 1.1, 'bank']], zones: [] },
  ];
  const RR = 1.05; // 고리 반지름(m)

  /* ---------- 결정적 난기류: 정수 해시 + 부드러운 보간 ---------- */
  function hsh(a, b) {
    let h = Math.imul(a ^ 0x9e3779b9, 0x85ebca6b) ^ Math.imul((b + 0x632be5ab) | 0, 0xc2b2ae35);
    h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d); h ^= h >>> 12; h = Math.imul(h, 0x297a2d39); h ^= h >>> 15;
    return ((h >>> 0) % 20001) / 10000 - 1;
  }
  function noise(sd, u) {
    const k = Math.floor(u), f = u - k, s = f * f * (3 - 2 * f), a = hsh(sd, k);
    return a + (hsh(sd, k + 1) - a) * s;
  }
  /* 바람(공기의 속도) at (x, y, step k) → [wx, wy] */
  function air(S, cd, x, y, k, out) {
    const t = k * DT;
    let wx = cd.w + S.ga * noise(cd.g, t * 1.2), wy = S.gv * noise(cd.g + 977, t * 1.7);
    const Z = S.zones;
    for (let i = 0; i < Z.length; i++) {
      const z = Z[i], dx = (x - z[0]) / z[1];
      if (dx <= -1 || dx >= 1 || y <= z[2] || y >= z[3]) continue;
      let b = 1 - dx * dx; b *= b;
      let fd = (y - z[2]) / 0.7; if (fd > 1) fd = 1;
      const f2 = (z[3] - y) / 3; if (f2 < fd) fd = f2;
      wx += z[4] * b * fd; wy += z[5] * b * fd;
    }
    out[0] = wx; out[1] = wy;
  }

  /* ---------- 비행 시뮬레이션 ---------- */
  function Flight(si, cd, f, v) {
    this.si = si; this.S = STAGES[si]; this.F = FOLDS[f]; this.cd = cd;
    this.x = this.S.start[0]; this.y = this.S.start[1]; this.vx = +v[0]; this.vy = +v[1];
    this.k = 0; this.done = false; this.crash = false; this.board = false; this.rings = 0; this.land = ''; this.hits = 0;
    this.maxY = this.y; this.ax = this.vx; this.ay = this.vy; this.w = [0, 0]; this.stall = false; this.rot = 0; this.loops = 0;
  }
  Flight.prototype.step = function () {
    if (this.done) return;
    const S = this.S, F = this.F, W = this.w;
    air(S, this.cd, this.x, this.y, this.k, W);
    let vx = this.vx, vy = this.vy;
    const ax = vx - W[0], ay = vy - W[1], s2 = ax * ax + ay * ay, s = Math.sqrt(s2);
    let fx = 0, fy = -GR;
    if (this.crash) { fx -= KF * s * ax; fy -= KF * s * ay; }
    else if (s > 1e-6) {
      const q = s2 * F.iv;
      let lg = q * F.c1 / (1 + q * F.ic);
      this.stall = q < 0.36;
      if (q < 0.36) lg *= 0.45 + 0.55 * q / 0.36; // 실속: 너무 느리면 양력이 뚝 떨어진다
      const qq = q < 0.04 ? 0.04 : q;
      const dg = (0.5 * q + 0.5 * lg * lg / qq) * F.ild * (this.stall ? 1.5 : 1);
      const ux = ax / s, uy = ay / s;
      fx += GR * (-lg * uy - dg * ux); fy += GR * (lg * ux - dg * uy);
    }
    vx += fx * DT; vy += fy * DT;
    const px = this.x, py = this.y;
    let x = px + vx * DT, y = py + vy * DT;
    // 공중제비: 비행 방향이 시계 반대로 한 바퀴(2π) 돌면 1회 (속도가 2 m/s 아래로 떨어지면 다시 셈)
    if (!this.crash && s > 2) {
      const pax = this.ax, pay = this.ay, cr = pax * ay - pay * ax, dn = Math.sqrt(pax * pax + pay * pay) * s + pax * ax + pay * ay;
      if (dn > 1e-6) { let d = 2 * cr / dn; if (d > 0.5) d = 0.5; else if (d < -0.5) d = -0.5; this.rot += d; }
      if (this.rot < -1) this.rot = -1;
      if (this.rot >= 6.2832) { this.loops++; this.rot -= 6.2832; }
    } else this.rot = 0;
    this.ax = ax; this.ay = ay;
    // 고리 통과 (강변)
    const rg = this.cd.rg;
    if (rg) for (let i = 0; i < rg.length; i++) {
      const r = rg[i];
      if ((px - r[0]) * (x - r[0]) <= 0 && px !== x && !(this.rings & (1 << i))) {
        const yy = py + (y - py) * (r[0] - px) / (x - px), dd = yy - r[1];
        if (dd <= RR && dd >= -RR) this.rings |= 1 << i;
      }
    }
    // 장애물
    const B = S.boxes;
    for (let i = 0; i < B.length; i++) {
      const b = B[i];
      if (x <= b[0] || x >= b[1] || y <= b[2] || y >= b[3]) continue;
      if (py >= b[3]) { // 위에서 → 그 위에 착륙
        y = b[3]; this.land = b[4]; this.done = true; vx = 0; vy = 0; break;
      }
      if (py <= b[2]) { y = b[2] - 0.005; vy = vy > 0 ? -vy * 0.25 : vy; vx *= 0.6; this.hits++; continue; } // 아래에서(천장) → 튕김
      // 옆면 → 부딪혀 팔랑팔랑 떨어짐
      if (px <= b[0]) { x = b[0] - 0.005; vx = vx > 0 ? -vx * 0.2 : vx; }
      else { x = b[1] + 0.005; vx = vx < 0 ? -vx * 0.2 : vx; }
      vy *= 0.3;
      if (b[4] === 'wall' && y > 1.0 && y < 2.55) this.board = true;
      this.crash = true; this.hits++;
    }
    if (!this.done && y <= 0) { y = 0; this.land = 'g'; this.done = true; vx = 0; vy = 0; }
    this.x = x; this.y = y; this.vx = vx; this.vy = vy;
    if (y > this.maxY) this.maxY = y;
    this.k++;
    if (!this.done && this.k >= MAXK) { this.done = true; this.land = 'air'; }
  };
  Flight.prototype.run = function () { while (!this.done) this.step(); return this; };
  function shotVec(f, ang, p) {
    const F = FOLDS[f], sp = F.vmin + clamp(p, 0, 1) * (F.vmax - F.vmin);
    return [r2(Math.cos(ang) * sp), r2(Math.sin(ang) * sp)];
  }
  function throwSim(si, cd, f, ang, p) { return new Flight(si, cd, f, shotVec(f, ang, p)).run(); }

  /* ---------- 점수 ---------- */
  const FIELD_RINGS = [[0.75, 100], [1.75, 70], [3, 45], [5, 25], [8, 10]];
  const LOOP_PT = 20;
  function scoreOf(si, cd, r) {
    const o = baseScore(si, cd, r), lp = Math.min(2, r.loops || 0);
    o.lp = lp; o.pt += lp * LOOP_PT;
    return o;
  }
  function baseScore(si, cd, r) {
    const S = STAGES[si], x = r.x;
    if (si === 0) {
      const d = clamp(x, 0, S.end);
      return { pt: Math.round(d * 5) + (r.board ? 20 : 0), ev: r.board ? 'board' : '', d };
    }
    if (si === 1) {
      const e = Math.abs(x - cd.t);
      for (const q of FIELD_RINGS) if (e <= q[0]) return { pt: q[1], ev: q[1] === 100 ? 'bull' : '', d: x };
      return { pt: 0, ev: '', d: x };
    }
    if (si === 2) {
      const d = x > 0 ? x : 0, roof = r.land && r.land[0] === 'b' && r.land !== 'b0';
      return { pt: Math.round(d * (roof ? 0.8 : 0.4)), ev: roof ? 'roof' : r.land === 'air' ? 'air' : 'street', d };
    }
    let n = 0; for (let i = 0; i < 4; i++) if (r.rings & (1 << i)) n++;
    const bank = r.land === 'bank' || (r.land === 'air' && x >= S.bank);
    return { pt: n * 20 + (bank ? 20 : 0), ev: bank ? 'bank' : '', d: x, n };
  }

  /* ---------- 라운드 조건 ---------- */
  function newCond(si) {
    const S = STAGES[si], cd = { w: r1((Math.random() * 2 - 1) * S.wr), g: 1 + Math.floor(Math.random() * 99999) };
    if (si === 1) cd.t = r1(13 + Math.random() * 18);
    if (si === 3) {
      const base = [10, 19, 28.5, 38.5];
      cd.rg = base.map((b) => {
        const x = r1(b + (Math.random() * 2 - 1) * 2.2);
        return [x, r1(clamp(7.8 - x * 0.12 + (Math.random() * 2 - 1) * 1.9, 1.6, 9.5))];
      });
    }
    return cd;
  }

  /* ---------- 게임 상태 ---------- */
  const DEG = Math.PI / 180, ANG_MIN = -30 * DEG, ANG_MAX = 75 * DEG;
  const total = (row) => row.reduce((a, b) => a + b, 0);
  function stageSeq(opt, R) {
    if (opt !== 'rnd' && opt != null && opt !== '' && STAGES[+opt]) return Array(R).fill(+opt);
    const out = [];
    while (out.length < R) {
      const b = U.shuffle([0, 1, 2, 3]);
      if (out.length && b[0] === out[out.length - 1]) b.push(b.shift());
      out.push(...b);
    }
    return out.slice(0, R);
  }
  function init(players, opts) {
    opts = opts || {};
    const R = [3, 4, 5].indexOf(+opts.rd) >= 0 ? +opts.rd : 3;
    const sg = stageSeq(opts.stage == null ? 'rnd' : opts.stage, R);
    return { n: players.length, nm: players.map((p) => String(p.name || '').slice(0, 10)), R, sg, r: 0, o: players.map((_, i) => i), i: 0,
      sc: players.map(() => []), lx: players.map(() => null), cd: newCond(sg[0]), seq: 0, last: null, ph: 'p' };
  }
  function actor(s) { return s.ph === 'p' ? s.o[s.i] : null; }
  function apply(s, seat, a) {
    if (actor(s) !== seat) throw new Error('not your turn');
    if (!a || a.type !== 'throw') throw new Error('bad action');
    const f = +a.f, ang = +a.a, p = +a.p;
    if (!(f === 0 || f === 1 || f === 2) || !isFinite(ang) || !isFinite(p)) throw new Error('bad throw');
    const si = s.sg[s.r], v = shotVec(f, clamp(ang, ANG_MIN, ANG_MAX), clamp(p, 0, 1));
    const fl = new Flight(si, s.cd, f, v).run(), sc = scoreOf(si, s.cd, fl);
    s.sc[seat].push(sc.pt);
    s.lx[seat] = r1(fl.x);
    s.seq++;
    s.last = { id: s.seq, s: seat, r: s.r, si, cd: s.cd, f, v, x: r1(fl.x), pt: sc.pt, ev: sc.ev, lp: sc.lp, n: sc.n || 0 };
    s.i++;
    if (s.i >= s.n) {
      s.r++;
      if (s.r >= s.R) s.ph = 'e';
      else {
        // 다음 라운드는 합계가 낮은 사람부터 (선두가 마지막)
        s.o = s.o.slice().sort((x, y) => total(s.sc[x]) - total(s.sc[y]) || x - y);
        s.i = 0; s.lx = s.lx.map(() => null); s.cd = newCond(s.sg[s.r]);
      }
    }
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const tot = s.sc.map(total), best = Math.max(...tot);
    const winners = tot.map((t, i) => (t === best ? i : -1)).filter((i) => i >= 0);
    const order = tot.map((_, i) => i).sort((a, b) => tot[b] - tot[a] || a - b);
    const lines = order.map((i) => ((s.nm && s.nm[i]) || (i + 1) + '번') + ' · ' + tot[i] + '점 (' + s.sc[i].join(' + ') + ')');
    return { winners, title: winners.length > 1 ? '공동 우승' : undefined, text: s.sg.map((g) => STAGES[g].name).join(' → ') + '\n' + lines.join('\n') };
  }

  /* ---------- AI: 같은 시뮬레이션으로 후보를 시험해 보고, 난이도만큼 손이 떨린다 ---------- */
  const ALV = {
    1: { da: 9, dp: 0.13, nA: 0.12, nP: 0.16, rob: 0, anyFold: 0.6, ms: 80 },
    2: { da: 6, dp: 0.08, nA: 0.05, nP: 0.065, rob: 0, anyFold: 0.12, ms: 130 },
    3: { da: 4, dp: 0.06, nA: 0.015, nP: 0.018, rob: 1, anyFold: 0, ms: 160 },
  };
  function evalShot(si, cd, f, a, p) {
    const r = throwSim(si, cd, f, a, p), sc = scoreOf(si, cd, r);
    return sc.pt + (si === 1 ? 4 / (1 + Math.abs(r.x - cd.t)) : r.x * 0.01);
  }
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) * 1.414;
  function ai(s, seat, lv) {
    const K = ALV[lv] || ALV[2], si = s.sg[s.r], cd = s.cd, t0 = Date.now();
    let folds = [0, 1, 2];
    if (Math.random() < K.anyFold) folds = [U.rand(3)]; // 쉬움: 아무 접기나 고르기도 한다
    const C = [];
    outer: for (const f of folds) for (let ad = -22; ad <= 62; ad += K.da) for (let p = 0.1; p <= 1.0001; p += K.dp) {
      if (Date.now() - t0 > K.ms && C.length > 30) break outer;
      const a = ad * DEG;
      C.push({ f, a, p, v: evalShot(si, cd, f, a, p) });
    }
    C.sort((x, y) => y.v - x.v);
    let best = C[0];
    if (lv >= 2) {
      // 위쪽 후보 주변을 더 촘촘히
      const top = C.slice(0, 5);
      for (const c of top) for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
        if (Date.now() - t0 > K.ms + 40) break;
        const a = c.a + i * K.da * 0.4 * DEG, p = clamp(c.p + j * K.dp * 0.4, 0.05, 1), v = evalShot(si, cd, c.f, a, p);
        if (v > best.v) best = { f: c.f, a, p, v };
        if (!(i || j)) continue;
        C.push({ f: c.f, a, p, v });
      }
    }
    if (K.rob) {
      // 어려움: 손떨림에도 잘 되는 샷(주변 평균)을 고른다
      C.sort((x, y) => y.v - x.v);
      let rb = null;
      for (const c of [best].concat(C.slice(0, 10))) {
        if (Date.now() - t0 > K.ms + 90) break;
        let v = c.v * 2, n = 2;
        for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { v += evalShot(si, cd, c.f, c.a + d[0] * 0.02, clamp(c.p + d[1] * 0.025, 0.02, 1)); n++; }
        v /= n;
        if (!rb || v > rb.v) rb = { f: c.f, a: c.a, p: c.p, v };
      }
      if (rb) best = rb;
    }
    return { type: 'throw', f: best.f, a: clamp(best.a + gauss() * K.nA, ANG_MIN, ANG_MAX), p: clamp(best.p * (1 + gauss() * K.nP), 0.02, 1) };
  }

  /* ---------- 뷰 ---------- */
  const RATE = [1.0, 1.3, 2.1, 1.5]; // 다시보기 배속 (옥상은 비행이 길어서 빠르게)
  const SURF = [0, 0, 9, 6.7]; // 던지는 사람이 선 바닥 높이
  const MM = [[-1.8, 16.6], [-2, 44], [-3, 122], [-2, 60]]; // 미니맵 범위
  const STAT_COL = ['#ee6a55', '#5fd3a0', '#5bb3e6'];
  const PSH = [
    { far: [[16, 0], [-13, -5], [-10, -1]], near: [[16, 0], [-14, 5.5], [-10, -1]], keel: [[16, 0], [-10, -1], [-12, 3.5]] },
    { far: [[13, 0], [-9, -10], [-6, -1]], near: [[13, 0], [-10, 9], [-6, -1]], keel: [[13, 0], [-6, -1], [-8, 3.5]] },
    { far: [[14, 0], [-10, -7.5], [-7, -1]], near: [[14, 0], [-11, 7.5], [-7, -1]], keel: [[14, 0], [-7, -1], [-9, 3.5]], tip: [[-11, 7.5], [-12.5, 10.5], [-8.5, 7]] },
  ];
  function rgb(c) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim());
    const n = m ? parseInt(m[1], 16) : 0xcccccc;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function mix(c, d, t) {
    const a = rgb(c), b = rgb(d);
    return 'rgb(' + Math.round(a[0] + (b[0] - a[0]) * t) + ',' + Math.round(a[1] + (b[1] - a[1]) * t) + ',' + Math.round(a[2] + (b[2] - a[2]) * t) + ')';
  }
  function surfAt(si, x) {
    let y = 0;
    for (const b of STAGES[si].boxes) if (b[2] <= 0.001 && x >= b[0] && x <= b[1] && b[3] > y && b[4] !== 'wall' && b[4] !== 'back') y = b[3];
    return y;
  }
  const vh = (si) => [0.13, 0.3, 0.25, 0.3][si]; // 배경 실루엣용 의사난수

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, G = null, k = 40, dirty = true, tNow = 0;
    let anim = null, sum = null, sumEl = null, sumTimer = 0, safeTimer = 0;
    let drag = null, sentAt = 0, shownId = -1, lastTick = -1, wasCancel = false;
    const cam = { x: 0, y: 0, z: 1, si: -1 };
    const fold = {}, prevShot = {}, flags = {}, trails = {};
    const floats = [], sparks = [], parts = [];
    let pref = 0;
    try { pref = clamp(+U.store.get('paperplane.fold', 0) || 0, 0, 2); } catch (e) {}
    const top = L.h('div', { class: 'hud top', style: { gap: '6px', padding: '8px 10px', flexWrap: 'nowrap' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '8px 10px', flexWrap: 'nowrap', gap: '6px' } });
    root.append(top, bot);

    let topKey = '', botKey = '';
    function layout() {
      const w = cv.w, h = cv.h;
      // landscape: slim score row, then stage pills + mini map on one row, the scene uses the width,
      // a floor strip at the bottom holds the fold buttons (right) — the thrower stands at the left
      G = w > h * 1.25
        ? { w, h, land: true, stripY: 42, mmY: 41, mmH: 24, gTop: 72, groundY: h - 66, mx0: 12, mx1: w - 12 }
        : { w, h, land: false, stripY: 60, mmY: 84, mmH: 40, gTop: 130, groundY: h - 96, mx0: 12, mx1: w - 12 };
      dirty = true; topKey = ''; botKey = '';
      parts.forEach((p) => { p.px = null; p.cx = null; });
      if (st) { renderTop(); renderBot(); }
    }
    cv.onresize = layout; layout();
    const SX = (x) => (x - cam.x) * k, SY = (y) => G.groundY - (y - cam.y) * k;
    const kBase = (si) => (G.groundY - G.gTop - 6) / STAGES[si].span;
    const ARW = () => clamp(Math.min(G.w * 0.3, (G.groundY - G.gTop) * 0.55), 70, 110); // aim arrow length at 100%
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const pname = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const foldOf = (seat) => (fold[seat] != null ? fold[seat] : pref);
    function disp() {
      if (anim) return anim.L;
      if (sum) return sum.L;
      if (!st) return { si: 0, r: 0, cd: { w: 0, g: 1 } };
      if (st.ph === 'p') return { si: st.sg[st.r], r: st.r, cd: st.cd };
      return st.last || { si: st.sg[0], r: 0, cd: st.cd };
    }
    // the thrower stands this far from the left edge — leaves room behind the plane to pull back
    const baseX = () => -(G.w * (G.land ? 0.25 : 0.34)) / k;

    /* ---- HUD ---- */
    function renderTop() {
      if (!st) { top.innerHTML = ''; return; }
      const cur = anim ? anim.L.s : actor(st), D = disp();
      const key = [cur, st.sc.map((r) => r.join(',')).join('/'), D.r, st.ph, G.land].join('|');
      if (key === topKey) return;
      topKey = key;
      top.innerHTML = '';
      top.style.padding = G.land ? '4px 8px' : '8px 10px';
      for (let i = 0; i < st.n; i++) {
        const p = api.players[i] || { name: '?', color: '#888' }, on = cur === i && st.ph === 'p';
        const rp = st.sc[i][D.r];
        const shown = anim && anim.L.s === i ? null : rp; // 날고 있는 동안은 점수를 숨긴다
        const tot = total(st.sc[i]) - (anim && anim.L.s === i ? anim.L.pt : 0);
        if (G.land) { // one line: ● 이름  123점 +40
          top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, maxWidth: '230px', padding: '4px 9px', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden',
            borderColor: on || (anim && anim.L.s === i) ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color : 'none', opacity: on || (anim && anim.L.s === i) || st.ph !== 'p' ? 1 : 0.78 } },
          L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
          L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 700, flex: '1 1 auto', minWidth: 0 }, text: p.name }),
          L.h('span', { class: 'mono', style: { fontWeight: 700, flex: 'none' }, text: tot + '점' }),
          L.h('span', { class: 'mono muted', style: { flex: 'none' }, text: shown != null ? '+' + shown : '' })));
          continue;
        }
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '5px 8px', display: 'flex', flexDirection: 'column', gap: '1px',
          borderColor: on || (anim && anim.L.s === i) ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color : 'none', opacity: on || (anim && anim.L.s === i) || st.ph !== 'p' ? 1 : 0.78 } },
        L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden' } },
          L.h('span', { class: 'dot', style: { '--c': p.color } }), L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' }, text: p.name })),
        L.h('div', { class: 'mono', style: { fontSize: '12px', display: 'flex', gap: '6px', whiteSpace: 'nowrap', overflow: 'hidden' } },
          L.h('span', { style: { fontWeight: 700 }, text: tot + '점' }),
          L.h('span', { class: 'muted', text: shown != null ? '+' + shown : '' }))));
      }
    }
    function canHuman() { return !!st && !anim && !sum && st.ph === 'p' && actor(st) != null && api.canAct(actor(st)) && !(sentAt && performance.now() - sentAt < 5000); }
    function renderBot() {
      if (!st) { bot.innerHTML = ''; return; }
      const a = actor(st), mine = canHuman();
      let msg = '';
      if (anim) msg = pname(anim.L.s) + ' · ' + FOLDS[anim.L.f].name + (anim.landed ? '' : ' 비행 중 · 탭하면 빨리');
      else if (sum) msg = '라운드 결과';
      else if (st.ph === 'p' && a != null) msg = api.players[a] && api.players[a].ai ? pname(a) + ' 생각 중…' : pname(a) + ' 차례';
      const sel = mine ? foldOf(a) : -1;
      const key = [mine, sel, msg, a, G.land].join('|');
      if (key === botKey) return;
      botKey = key;
      bot.innerHTML = '';
      const wide = G.land;
      bot.removeAttribute('data-tut');
      Object.assign(bot.style, wide ? { padding: '0 8px 5px', justifyContent: mine ? 'flex-start' : 'center', alignItems: 'flex-end' } : { padding: '8px 10px', justifyContent: 'center', alignItems: 'center' });
      if (mine) {
        const row = wide ? L.h('div', { 'data-tut': 'fold', style: { display: 'flex', gap: '6px', flex: '0 1 auto', minWidth: 0 } }) : bot;
        if (wide) bot.append(row); else bot.setAttribute('data-tut', 'fold');
        FOLDS.forEach((F, i) => {
          const on = i === sel;
          const bars = F.bars.map((v, j) => L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '4px', fontSize: wide ? '9px' : '10px', fontWeight: 600, lineHeight: 1, opacity: 0.95 } },
            L.h('span', { style: { width: wide ? '20px' : '22px', flex: 'none', textAlign: 'left' }, text: BARN[j] }),
            L.h('span', { style: { flex: '1 1 auto', height: wide ? '4px' : '5px', borderRadius: '3px', background: on ? 'rgba(40,24,6,.25)' : 'rgba(242,233,216,.14)', position: 'relative', overflow: 'hidden' } },
              L.h('span', { style: { position: 'absolute', left: 0, top: 0, bottom: 0, width: (v * 20) + '%', borderRadius: '3px', background: on ? 'rgba(40,24,6,.75)' : STAT_COL[j] } }))));
          row.append(L.h('button', { class: 'btn' + (on ? ' primary' : ''), 'aria-pressed': on ? 'true' : 'false', 'aria-label': F.name + ' 고르기',
            style: wide ? { flex: '0 1 128px', width: '128px', minWidth: '96px', minHeight: '56px', padding: '4px 8px', flexDirection: 'column', alignItems: 'stretch', gap: '2px', borderRadius: '12px' }
              : { flex: '1 1 0', minWidth: 0, minHeight: '64px', padding: '6px 7px', flexDirection: 'column', alignItems: 'stretch', gap: '4px', borderRadius: '12px' },
            onclick() { fold[a] = i; pref = i; U.store.set('paperplane.fold', i); api.sfx('click'); api.buzz(8); botKey = ''; renderBot(); dirty = true; } },
          L.h('span', { style: { fontSize: '13px', fontWeight: 800, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', textAlign: 'center' }, text: F.name }), bars));
        });
      } else {
        bot.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', fontWeight: 700, minWidth: 0, flex: '1 1 auto', minHeight: '44px', padding: '6px 12px', maxWidth: wide ? '380px' : '', pointerEvents: wide ? 'none' : '' } },
          a != null || anim ? L.h('span', { class: 'dot', style: { '--c': col(anim ? anim.L.s : a) } }) : null,
          L.h('span', { style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: msg })));
      }
    }

    /* ---- 라운드 결과 ---- */
    function showSummary(L0) {
      sum = { L: L0 };
      const R = L0.r, order = st.sc.map((_, i) => i).sort((x, y) => total(st.sc[y]) - total(st.sc[x]) || x - y);
      const rows = order.map((i, n) => L.h('tr', null,
        L.h('td', { class: 'mono', style: { padding: '6px 4px', color: 'var(--muted)', fontSize: '13px' }, text: String(n + 1) }),
        L.h('td', { style: { padding: '6px 4px', fontWeight: 700, fontSize: '14px', maxWidth: '120px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } },
          L.h('span', { class: 'dot', style: { '--c': col(i), display: 'inline-block', marginRight: '6px' } }), pname(i)),
        L.h('td', { class: 'mono', style: { padding: '6px 4px', textAlign: 'right', color: '#5fd3a0', fontSize: '14px' }, text: '+' + (st.sc[i][R] != null ? st.sc[i][R] : 0) }),
        L.h('td', { class: 'mono', style: { padding: '6px 4px', textAlign: 'right', fontWeight: 700, fontSize: '15px' }, text: total(st.sc[i]) + '점' })));
      const nx = st.ph === 'p' ? STAGES[st.sg[st.r]] : null;
      sumEl = L.h('div', { class: 'overlay', style: { zIndex: 15, alignItems: 'flex-end', background: 'rgba(10,8,15,.45)', backdropFilter: 'none' }, onclick() { closeSummary(); } },
        L.h('div', { class: 'sheet', style: { gap: '10px', padding: '16px' } },
          L.h('span', { class: 'label', text: '라운드 결과 · ' + (R + 1) + '/' + st.R }),
          L.h('h2', { style: { fontSize: '24px' }, text: STAGES[L0.si].name + ' 끝' }),
          L.h('table', { style: { width: '100%', borderCollapse: 'collapse' } }, rows),
          nx ? L.h('p', { style: { margin: 0, fontSize: '14px', fontWeight: 700 } }, '다음 · ', L.h('span', { style: { color: 'var(--brass)' }, text: nx.name }), ' — ' + nx.goal) : null,
          L.h('p', { class: 'muted', style: { margin: 0, fontSize: '12px' }, text: '탭하면 계속' })));
      root.append(sumEl);
      api.setBusy(true);
      clearTimeout(sumTimer);
      sumTimer = setTimeout(closeSummary, 3200 / L.debug.speed);
      renderBot();
    }
    function closeSummary() {
      if (!sum) return;
      clearTimeout(sumTimer);
      sum = null;
      if (sumEl) { sumEl.remove(); sumEl = null; }
      if (!anim) api.setBusy(false);
      renderTop(); renderBot(); dirty = true;
    }

    /* ---- 다시보기 ---- */
    function startReplay(L0, next) {
      if (sum) closeSummary();
      if (anim) finishReplay();
      const fl = new Flight(L0.si, L0.cd, L0.f, L0.v);
      anim = { L: L0, fl, acc: 0, trail: [[fl.x, fl.y]], landed: false, hold: 0, ff: 1, rings: 0, loops: 0, hits: 0, crashed: false,
        endRound: next.ph === 'e' || next.r !== L0.r };
      api.setBusy(true); api.sfx('whoosh'); api.buzz(12);
      const n = new Flight(L0.si, L0.cd, L0.f, L0.v).run().k;
      clearTimeout(safeTimer);
      const me = anim;
      safeTimer = setTimeout(() => { if (anim === me) { while (!me.fl.done) me.fl.step(); if (!me.landed) land(); finishReplay(); } }, (n * DT / RATE[L0.si] / L.debug.speed) * 1000 + 4500);
      renderTop(); renderBot(); dirty = true;
    }
    function landText(L0) {
      if (L0.si === 0) return Math.max(0, L0.x).toFixed(1) + 'm' + (L0.ev === 'board' ? ' · 칠판 명중!' : '');
      if (L0.si === 1) { const e = Math.abs(L0.x - L0.cd.t); return L0.ev === 'bull' ? '정중앙!' : '과녁에서 ' + e.toFixed(1) + 'm'; }
      if (L0.si === 2) return Math.max(0, L0.x).toFixed(1) + 'm · ' + (L0.ev === 'roof' ? '옥상 착륙' : L0.ev === 'air' ? '하늘 멀리' : '길에 떨어짐');
      return '고리 ' + L0.n + '개' + (L0.ev === 'bank' ? ' · 건너편 도착!' : '');
    }
    function land() {
      const A = anim, L0 = A.L, f = A.fl;
      A.landed = true; A.trail.push([f.x, f.y]);
      (flags[L0.r] = flags[L0.r] || {})[L0.s] = L0.x;
      floats.push({ x: f.x, y: f.y, text: L0.pt + '점', c: '#f2e9d8', t: 0, big: 1 });
      api.toast(pname(L0.s) + ' · ' + landText(L0) + ' · ' + L0.pt + '점');
      api.sfx(L0.pt >= 80 ? 'win' : L0.pt >= 40 ? 'pop' : 'thud'); api.buzz(L0.pt >= 80 ? 30 : 15);
      if (L0.ev === 'bull' || L0.ev === 'board' || L0.ev === 'bank') burst(f.x, f.y + 0.2, col(L0.s));
      renderBot();
    }
    function finishReplay() {
      clearTimeout(safeTimer);
      const A = anim; if (!A) return;
      anim = null;
      const tr = A.trail, stp = Math.max(1, Math.ceil(tr.length / 160)), out = [];
      for (let i = 0; i < tr.length; i += stp) out.push(tr[i]);
      out.push(tr[tr.length - 1]);
      (trails[A.L.r] = trails[A.L.r] || {})[A.L.s] = out;
      if (A.endRound && st && st.ph === 'p') showSummary(A.L);
      else api.setBusy(false);
      renderTop(); renderBot(); dirty = true;
    }
    function burst(x, y, c) {
      for (let i = 0; i < 16; i++) { const a = i / 16 * Math.PI * 2; sparks.push({ x, y, vx: Math.cos(a) * (0.6 + (i % 3) * 0.35), vy: Math.sin(a) * (0.6 + (i % 3) * 0.35), t: 0, c: i % 2 ? '#e3ae45' : c }); }
    }

    /* ---- 그리기: 공통 ---- */
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function poly(P) { ctx.beginPath(); P.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); }
    function drawPlane(x, y, ang, f, c, a) {
      const S = PSH[f], s = 1.05;
      ctx.save(); ctx.globalAlpha = a == null ? 1 : a;
      ctx.translate(x, y); ctx.rotate(-ang); ctx.scale(s, s);
      ctx.lineJoin = 'round';
      ctx.fillStyle = mix(c, '#000000', 0.32); poly(S.far); ctx.fill();
      ctx.fillStyle = mix(c, '#000000', 0.45); poly(S.keel); ctx.fill();
      ctx.fillStyle = mix(c, '#ffffff', 0.45); poly(S.near); ctx.fill();
      // 접힌 자국 음영
      ctx.fillStyle = 'rgba(0,0,0,.12)'; poly([S.near[0], [S.near[1][0] * 0.55 + S.near[0][0] * 0.45 - 2, S.near[1][1] * 0.5], S.near[2]]); ctx.fill();
      if (S.tip) { ctx.fillStyle = mix(c, '#ffffff', 0.25); poly(S.tip); ctx.fill(); }
      ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 0.9;
      ctx.beginPath(); ctx.moveTo(S.near[0][0], S.near[0][1]); ctx.lineTo(S.near[2][0], S.near[2][1]); ctx.stroke();
      ctx.strokeStyle = 'rgba(30,20,30,.35)'; ctx.lineWidth = 0.7; poly(S.near); ctx.stroke();
      ctx.restore();
    }
    function drawKid(si, c, ang, pull) {
      const sf = SURF[si], hy = STAGES[si].start[1], fx = -0.42;
      const X0 = SX(fx), Yf = SY(sf), m = k;
      const hip = [X0, Yf - 0.86 * m], sh = [X0 + 0.04 * m, Yf - 1.36 * m];
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = '#2b2236'; ctx.lineWidth = Math.max(2, 0.13 * m);
      ctx.beginPath(); ctx.moveTo(X0 - 0.13 * m, Yf); ctx.lineTo(hip[0], hip[1]); ctx.lineTo(X0 + 0.14 * m, Yf); ctx.stroke();
      ctx.strokeStyle = c; ctx.lineWidth = Math.max(3, 0.27 * m);
      ctx.beginPath(); ctx.moveTo(hip[0], hip[1] - 0.05 * m); ctx.lineTo(sh[0], sh[1] + 0.04 * m); ctx.stroke();
      // 뒤쪽 팔
      ctx.strokeStyle = mix(c, '#000000', 0.3); ctx.lineWidth = Math.max(2, 0.09 * m);
      ctx.beginPath(); ctx.moveTo(sh[0], sh[1]); ctx.lineTo(sh[0] - 0.22 * m, sh[1] + 0.42 * m); ctx.stroke();
      // 머리
      ctx.fillStyle = '#f0cda8'; ctx.beginPath(); ctx.arc(sh[0] + 0.03 * m, sh[1] - 0.2 * m, Math.max(3, 0.12 * m), 0, 7); ctx.fill();
      ctx.fillStyle = '#3a2a24'; ctx.beginPath(); ctx.arc(sh[0] + 0.01 * m, sh[1] - 0.24 * m, Math.max(3, 0.12 * m), Math.PI * 0.95, Math.PI * 2.1); ctx.fill();
      // 던지는 팔 → 손
      const hx = SX(0) - Math.cos(ang) * pull, hyy = SY(hy) + Math.sin(ang) * pull;
      ctx.strokeStyle = mix(c, '#ffffff', 0.15); ctx.lineWidth = Math.max(2, 0.1 * m);
      ctx.beginPath(); ctx.moveTo(sh[0], sh[1]); ctx.lineTo((sh[0] + hx) / 2 - 0.05 * m, (sh[1] + hyy) / 2 + 0.06 * m); ctx.lineTo(hx, hyy); ctx.stroke();
      return [hx, hyy];
    }
    function drawFlag(si, x, seat, idx, alpha) {
      const gx = SX(x), gy = SY(surfAt(si, x));
      if (gx < -40 || gx > G.w + 40) return;
      const c = col(seat), hgt = 30;
      ctx.globalAlpha = alpha;
      ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(gx, gy - hgt - idx * 12); ctx.stroke();
      const ty = gy - hgt - idx * 12;
      ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(gx, ty); ctx.lineTo(gx + 16, ty + 5); ctx.lineTo(gx, ty + 10); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(gx, gy, 5, 2, 0, 0, 7); ctx.fill();
      ctx.globalAlpha = 1;
    }
    function hoop(r, passed, front) {
      const x = SX(r[0]), y = SY(r[1]), ry = RR * k, rx = Math.max(4, ry * 0.32);
      ctx.lineWidth = Math.max(3, ry * 0.16);
      ctx.strokeStyle = passed ? '#f4c64e' : '#ee6a55';
      ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, front ? -Math.PI / 2 : Math.PI / 2, front ? Math.PI / 2 : Math.PI * 1.5); ctx.stroke();
      if (front) { ctx.strokeStyle = 'rgba(255,255,255,.45)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.ellipse(x, y, rx - 1, ry - 1, 0, -Math.PI / 2, 0); ctx.stroke(); }
    }

    /* ---- 그리기: 스테이지 ---- */
    function skyGrad(c0, c1) { const g = ctx.createLinearGradient(0, 0, 0, G.groundY); g.addColorStop(0, c0); g.addColorStop(1, c1); return g; }
    function silhouettes(par, seed, base, hmin, hmax, wmin, wmax, color, step) {
      // 시차(parallax) 배경: 정수 해시로 고정된 모양
      const off = cam.x * k * par, W = G.w;
      ctx.fillStyle = color;
      const i0 = Math.floor((off - 60) / step), i1 = Math.ceil((off + W + 60) / step);
      for (let i = i0; i <= i1; i++) {
        const hh = hmin + (hsh(seed, i) * 0.5 + 0.5) * (hmax - hmin), ww = wmin + (hsh(seed + 1, i) * 0.5 + 0.5) * (wmax - wmin);
        const x = i * step - off;
        ctx.fillRect(x, base - hh, ww, hh + 2);
      }
    }
    function drawClass(t) {
      const w = G.w, gy = SY(0);
      ctx.fillStyle = '#e9dcc0'; ctx.fillRect(0, 0, w, gy);
      // 창문 (옆 벽)
      for (let wx = -3.2; wx < 16; wx += 4.4) {
        const x0 = SX(wx), x1 = SX(wx + 2.6); if (x1 < 0 || x0 > w) continue;
        const y0 = SY(2.75), y1 = SY(1.15);
        const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, '#8fcdf0'); g.addColorStop(1, '#d7f0f7');
        ctx.fillStyle = '#b9a785'; ctx.fillRect(x0 - 5, y0 - 5, x1 - x0 + 10, y1 - y0 + 10);
        ctx.fillStyle = g; ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
        ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.moveTo(x0 + (x1 - x0) * 0.15, y1); ctx.lineTo(x0 + (x1 - x0) * 0.45, y0); ctx.lineTo(x0 + (x1 - x0) * 0.55, y0); ctx.lineTo(x0 + (x1 - x0) * 0.25, y1); ctx.fill();
        ctx.fillStyle = '#b9a785'; ctx.fillRect((x0 + x1) / 2 - 2, y0, 4, y1 - y0); ctx.fillRect(x0, (y0 + y1) / 2 - 2, x1 - x0, 4);
      }
      // 게시판·시계
      const bx = SX(10.2);
      if (bx > -200 && bx < w + 50) {
        ctx.fillStyle = '#c4935c'; ctx.fillRect(bx, SY(2.6), 1.5 * k, 0.9 * k);
        ctx.fillStyle = '#f2e9d8'; ctx.fillRect(bx + 0.15 * k, SY(2.45), 0.45 * k, 0.32 * k); ctx.fillStyle = '#9fd0ea'; ctx.fillRect(bx + 0.8 * k, SY(2.5), 0.5 * k, 0.4 * k);
      }
      // 벽 아래 판넬
      ctx.fillStyle = '#8a6a48'; ctx.fillRect(0, SY(0.9), w, gy - SY(0.9));
      ctx.fillStyle = '#6e5236'; ctx.fillRect(0, SY(0.9) - 3, w, 3);
      // 천장
      ctx.fillStyle = '#cfc2a4'; ctx.fillRect(0, 0, w, SY(3.3));
      ctx.fillStyle = '#a99a78'; ctx.fillRect(0, SY(3.3) - 3, w, 3);
      for (let x = Math.floor(cam.x); x < cam.x + w / k + 1; x += 2) { ctx.fillStyle = '#f7f1e2'; ctx.fillRect(SX(x + 0.4), SY(3.3), 0.9 * k, 0.05 * k); }
      // 선풍기 (아래로 바람)
      const fz = STAGES[0].zones[0], fxp = SX(fz[0]);
      if (fxp > -150 && fxp < w + 150) {
        ctx.strokeStyle = '#6b5a48'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(fxp, SY(3.3)); ctx.lineTo(fxp, SY(3.0)); ctx.stroke();
        ctx.fillStyle = '#5a4a3a'; rr(fxp - 0.12 * k, SY(3.02), 0.24 * k, 0.12 * k, 4); ctx.fill();
        const bw = Math.abs(Math.cos(t * 14)) * 0.75 * k + 4;
        ctx.fillStyle = 'rgba(90,74,58,.75)'; ctx.beginPath(); ctx.ellipse(fxp, SY(2.92), bw, 0.04 * k + 1.5, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(80,120,170,.35)'; ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
          const yy = 2.6 - (((t * 1.4 + j / 3) % 1) * 1.9), xx = fz[0] + (i - 1) * 0.55, s = 0.12 * k;
          ctx.beginPath(); ctx.moveTo(SX(xx) - s, SY(yy) - s * 0.6); ctx.lineTo(SX(xx), SY(yy)); ctx.lineTo(SX(xx) + s, SY(yy) - s * 0.6); ctx.stroke();
        }
      }
      // 온풍기 (위로 바람)
      const hz = STAGES[0].zones[1], hxp = SX(hz[0]);
      if (hxp > -150 && hxp < w + 150) {
        ctx.fillStyle = '#b8b2a8'; rr(SX(hz[0] - 0.4), SY(0.55), 0.8 * k, 0.55 * k, 5); ctx.fill();
        ctx.fillStyle = '#8f887c'; for (let i = 0; i < 6; i++) ctx.fillRect(SX(hz[0] - 0.33 + i * 0.12), SY(0.48), 0.05 * k, 0.4 * k);
        ctx.fillStyle = '#e8774f'; ctx.fillRect(SX(hz[0] - 0.3), SY(0.53), 0.6 * k, 0.04 * k);
        ctx.strokeStyle = 'rgba(238,106,85,.35)'; ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) {
          ctx.beginPath();
          for (let y = 0.6; y < 2.6; y += 0.08) { const xx = hz[0] + (i - 1) * 0.3 + Math.sin(y * 7 - t * 5 + i) * 0.06; y === 0.6 ? ctx.moveTo(SX(xx), SY(y)) : ctx.lineTo(SX(xx), SY(y)); }
          ctx.stroke();
        }
      }
      // 바닥
      ctx.fillStyle = '#9b6b40'; ctx.fillRect(0, gy, w, G.h - gy);
      ctx.fillStyle = 'rgba(0,0,0,.12)'; for (let y = gy + 10; y < G.h; y += 14) ctx.fillRect(0, y, w, 1.5);
      ctx.fillStyle = '#7d5530'; ctx.fillRect(0, gy, w, 3);
      // 거리 표시 테이프
      ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      for (let x = 0; x <= 16; x++) {
        const sx = SX(x); if (sx < -20 || sx > w + 20) continue;
        ctx.fillStyle = x % 2 ? 'rgba(255,240,200,.45)' : '#f2e9d8'; ctx.fillRect(sx - 1, gy + 2, 2, x % 2 ? 6 : 10);
        if (x % 2 === 0 && x > 0) { ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.textBaseline = 'bottom'; ctx.fillText(x + 'm', sx, gy - 4); ctx.textBaseline = 'top'; }
      }
      // 책상·의자·교탁
      for (const b of STAGES[0].boxes) {
        if (b[4] !== 'desk' && b[4] !== 'lect') continue;
        const x0 = SX(b[0]), x1 = SX(b[1]); if (x1 < -10 || x0 > w + 10) continue;
        if (b[4] === 'desk') {
          // 의자
          ctx.strokeStyle = '#5b6b7a'; ctx.lineWidth = Math.max(2, 0.04 * k);
          const cx = SX(b[0] - 0.45);
          ctx.beginPath(); ctx.moveTo(cx - 0.18 * k, gy); ctx.lineTo(cx - 0.18 * k, SY(0.45)); ctx.lineTo(cx + 0.2 * k, SY(0.45)); ctx.lineTo(cx + 0.2 * k, gy); ctx.moveTo(cx - 0.18 * k, SY(0.45)); ctx.lineTo(cx - 0.24 * k, SY(0.85)); ctx.stroke();
          ctx.fillStyle = '#c98b52'; ctx.fillRect(cx - 0.2 * k, SY(0.47), 0.42 * k, 0.04 * k + 1);
          ctx.strokeStyle = '#5b6b7a'; ctx.beginPath(); ctx.moveTo(x0 + 0.08 * k, gy); ctx.lineTo(x0 + 0.08 * k, SY(0.72)); ctx.moveTo(x1 - 0.08 * k, gy); ctx.lineTo(x1 - 0.08 * k, SY(0.72)); ctx.stroke();
          ctx.fillStyle = '#7e8b96'; ctx.fillRect(x0 + 0.1 * k, SY(0.6), x1 - x0 - 0.2 * k, 0.1 * k);
          ctx.fillStyle = '#d7a466'; ctx.fillRect(x0, SY(b[3]), x1 - x0, 0.06 * k + 1);
          ctx.fillStyle = '#a8763e'; ctx.fillRect(x0, SY(b[3]) + 0.06 * k, x1 - x0, 2);
        } else {
          ctx.fillStyle = '#8a5a30'; ctx.fillRect(x0, SY(b[3]), x1 - x0, gy - SY(b[3]));
          ctx.fillStyle = '#a8703e'; ctx.fillRect(x0, SY(b[3]), x1 - x0, 0.07 * k);
          ctx.fillStyle = 'rgba(0,0,0,.15)'; ctx.fillRect(x0 + 0.15 * k, SY(0.85), x1 - x0 - 0.3 * k, 0.5 * k);
        }
      }
      // 앞 벽과 칠판
      const ex = SX(16);
      if (ex < w + 10) {
        ctx.fillStyle = '#cdbd99'; ctx.fillRect(ex, 0, w - ex + 10, gy);
        ctx.fillStyle = '#b3a37f'; ctx.fillRect(ex, 0, 4, gy);
        ctx.fillStyle = '#6e5236'; ctx.fillRect(ex - 0.1 * k, SY(2.62), 0.1 * k + 2, (2.62 - 0.95) * k);
        ctx.fillStyle = '#25543f'; ctx.fillRect(ex - 0.07 * k, SY(2.55), 0.07 * k + 2, (2.55 - 1.0) * k);
        ctx.fillStyle = '#8a6a48'; ctx.fillRect(ex - 0.16 * k, SY(1.0), 0.16 * k, 0.04 * k + 2);
        ctx.fillStyle = '#25543f'; rr(ex + 6, SY(2.5), Math.min(0.9 * k, w - ex), 1.4 * k, 4); ctx.fill();
        ctx.fillStyle = 'rgba(242,233,216,.8)'; ctx.font = '700 ' + Math.max(11, Math.round(0.22 * k)) + 'px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText('칠판', ex + 12, SY(1.85));
      }
    }
    function drawField(t, cd) {
      const w = G.w, gy = SY(0);
      ctx.fillStyle = skyGrad('#6fb9e8', '#d4ecf5'); ctx.fillRect(0, 0, w, gy);
      // 구름
      ctx.fillStyle = 'rgba(255,255,255,.75)';
      for (let i = -1; i < 5; i++) { const x = ((i * 170 - cam.x * k * 0.08 + t * 6) % (w + 340) + w + 340) % (w + 340) - 170, y = G.gTop + 30 + (i % 3) * 34; ctx.beginPath(); ctx.ellipse(x, y, 46, 13, 0, 0, 7); ctx.ellipse(x + 26, y - 9, 28, 13, 0, 0, 7); ctx.fill(); }
      // 학교 건물(먼 배경)
      const off = cam.x * k * 0.25, bx = 60 - off;
      ctx.fillStyle = '#c9b8a0'; ctx.fillRect(bx, gy - 120, 420, 120);
      ctx.fillStyle = '#b3a088'; ctx.fillRect(bx, gy - 126, 420, 8);
      ctx.fillStyle = '#8fb6cf'; for (let r = 0; r < 3; r++) for (let c = 0; c < 12; c++) ctx.fillRect(bx + 14 + c * 34, gy - 108 + r * 34, 20, 18);
      ctx.fillStyle = '#d9cbb3'; ctx.fillRect(bx + 190, gy - 150, 40, 30);
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(bx + 210, gy - 136, 9, 0, 7); ctx.fill();
      silhouettes(0.45, 31, gy, 24, 46, 26, 40, '#4f8a4a', 46);
      // 철망 울타리
      ctx.strokeStyle = 'rgba(80,90,100,.35)'; ctx.lineWidth = 1;
      const fo = (cam.x * k * 0.7) % 12;
      for (let x = -fo; x < w; x += 12) { ctx.beginPath(); ctx.moveTo(x, gy - 34); ctx.lineTo(x + 12, gy); ctx.moveTo(x + 12, gy - 34); ctx.lineTo(x, gy); ctx.stroke(); }
      ctx.fillStyle = 'rgba(80,90,100,.6)'; ctx.fillRect(0, gy - 36, w, 2);
      // 땅
      ctx.fillStyle = '#c89a62'; ctx.fillRect(0, gy, w, G.h - gy);
      ctx.fillStyle = '#7fae55'; ctx.fillRect(0, gy - 3, w, 6);
      ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.fillRect(0, gy + 18, w, 2); ctx.fillRect(0, gy + 44, w, 2);
      // 과녁
      const tx = SX(cd.t), ty = gy + 10;
      if (tx > -9 * k && tx < w + 9 * k) {
        for (let i = FIELD_RINGS.length - 1; i >= 0; i--) {
          const r = FIELD_RINGS[i][0] * k;
          ctx.fillStyle = i % 2 ? '#f2e9d8' : '#e0574a'; ctx.beginPath(); ctx.ellipse(tx, ty, r, Math.max(3, r * 0.09), 0, 0, 7); ctx.fill();
        }
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.ellipse(tx, ty, FIELD_RINGS[0][0] * k * 0.5, Math.max(2, FIELD_RINGS[0][0] * k * 0.045), 0, 0, 7); ctx.fill();
        ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(tx, ty - 60); ctx.stroke();
        ctx.fillStyle = '#e0574a'; ctx.beginPath(); ctx.moveTo(tx, ty - 60); ctx.lineTo(tx + 20, ty - 53); ctx.lineTo(tx, ty - 46); ctx.fill();
        ctx.font = '700 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillStyle = '#2b2236';
        ctx.fillText(cd.t.toFixed(1) + 'm', tx, ty - 63);
      }
      // 거리 고깔
      ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      for (let x = 5; x <= 45; x += 5) {
        const sx = SX(x); if (sx < -20 || sx > w + 20) continue;
        ctx.fillStyle = '#f08a3c'; ctx.beginPath(); ctx.moveTo(sx - 6, gy + 2); ctx.lineTo(sx, gy - 14); ctx.lineTo(sx + 6, gy + 2); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.fillRect(sx - 3, gy - 7, 6, 2);
        ctx.fillStyle = '#5a3a20'; ctx.textBaseline = 'bottom'; ctx.fillText(x + 'm', sx, gy - 16); ctx.textBaseline = 'top';
      }
    }
    let winPat = null;
    function windowPattern() {
      if (winPat) return winPat;
      const c = document.createElement('canvas'); c.width = 14; c.height = 18;
      const g = c.getContext('2d'); g.fillStyle = 'rgba(255,214,140,.55)'; g.fillRect(4, 4, 7, 9); g.fillStyle = 'rgba(30,25,45,.35)'; g.fillRect(4, 4, 7, 2);
      winPat = ctx.createPattern(c, 'repeat');
      return winPat;
    }
    const FAC = ['#7d5a6e', '#6a5f7e', '#8a6552', '#5d6a7a', '#7a6a58', '#66586f', '#5f7064'];
    function drawRoof(t) {
      const w = G.w, gy = SY(0), S = STAGES[2];
      ctx.fillStyle = skyGrad('#3e3a72', '#f4a46c'); ctx.fillRect(0, 0, w, gy);
      ctx.fillStyle = 'rgba(255,214,150,.9)'; ctx.beginPath(); ctx.arc(w * 0.78 - cam.x * k * 0.03, Math.min(SY(4) - 30, G.gTop + (G.groundY - G.gTop) * 0.62), 26, 0, 7); ctx.fill();
      silhouettes(0.15, 71, SY(0) - 4, 40, 110, 40, 70, 'rgba(90,70,120,.55)', 64);
      silhouettes(0.35, 91, SY(0) - 2, 30, 80, 34, 60, 'rgba(70,56,100,.75)', 56);
      // 상승기류
      for (const z of S.zones) {
        const cx = SX(z[0]); if (cx < -z[1] * k - 20 || cx > w + z[1] * k + 20) continue;
        const H = (z[3] * 0.85) * k, gb = SY(surfAt(2, z[0]));
        ctx.save(); ctx.translate(cx, gb); ctx.scale(z[1] * k / H, 1);
        const g = ctx.createRadialGradient(0, 0, 0, 0, 0, H);
        g.addColorStop(0, 'rgba(255,190,120,.2)'); g.addColorStop(0.6, 'rgba(255,190,120,.08)'); g.addColorStop(1, 'rgba(255,190,120,0)');
        ctx.fillStyle = g; ctx.fillRect(-H, -H, 2 * H, H); ctx.restore();
        ctx.strokeStyle = 'rgba(255,230,190,.4)'; ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) for (let j = 0; j < 4; j++) {
          const yy = surfAt(2, z[0]) + 1 + ((t * 0.5 + j / 4) % 1) * (z[3] * 0.75), xx = z[0] + (i - 1) * z[1] * 0.45, s = 7;
          ctx.beginPath(); ctx.moveTo(SX(xx) - s, SY(yy) + s * 0.6); ctx.lineTo(SX(xx), SY(yy)); ctx.lineTo(SX(xx) + s, SY(yy) + s * 0.6); ctx.stroke();
        }
      }
      // 도로
      ctx.fillStyle = '#34303d'; ctx.fillRect(0, gy, w, G.h - gy);
      ctx.fillStyle = '#5a5363'; ctx.fillRect(0, gy, w, 4);
      ctx.fillStyle = '#e3ae45'; const lo = (cam.x * k) % 40; for (let x = -lo; x < w; x += 40) ctx.fillRect(x, gy + 24, 20, 3);
      // 건물
      const pat = windowPattern();
      S.boxes.forEach((b, i) => {
        const x0 = SX(Math.max(b[0], cam.x - 2)), x1 = SX(b[1]); if (x1 < -5 || SX(b[0]) > w + 5) return;
        const yt = SY(b[3]);
        ctx.fillStyle = FAC[i % FAC.length]; ctx.fillRect(x0, yt, x1 - x0, gy - yt);
        ctx.save(); ctx.translate(SX(b[0]), yt); ctx.fillStyle = pat; ctx.fillRect(x0 - SX(b[0]) + 2, 8, x1 - x0 - 4, gy - yt - 14); ctx.restore();
        ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fillRect(x1 - 6, yt, 6, gy - yt);
        ctx.fillStyle = mix(FAC[i % FAC.length], '#ffffff', 0.25); ctx.fillRect(x0, yt - 4, x1 - x0, 5);
        // 옥상 소품(실외기·물탱크)
        if (i > 0) {
          const px = b[0] + (b[1] - b[0]) * 0.7;
          ctx.fillStyle = '#8f8a9a'; ctx.fillRect(SX(px), yt - 0.7 * k, 0.9 * k, 0.7 * k);
          ctx.fillStyle = '#6f6a7a'; ctx.beginPath(); ctx.arc(SX(px + 0.45), yt - 0.35 * k, 0.22 * k, 0, 7); ctx.fill();
        }
        ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = 'rgba(242,233,216,.75)';
        if (i > 0) ctx.fillText(Math.round(b[0]) + 'm', Math.max(x0 + 16, SX(b[0]) + 16), yt + 3);
      });
      // 난간
      ctx.strokeStyle = '#cfc6d8'; ctx.lineWidth = 1.5;
      const ry = SY(9.9), r0 = SX(-3), r1 = SX(0.45);
      ctx.beginPath(); ctx.moveTo(r0, ry); ctx.lineTo(r1, ry); ctx.stroke();
      for (let x = -3; x <= 0.45; x += 0.5) { ctx.beginPath(); ctx.moveTo(SX(x), ry); ctx.lineTo(SX(x), SY(9)); ctx.stroke(); }
    }
    function drawRiver(t, cd, passed) {
      const w = G.w, gy = SY(0), S = STAGES[3];
      ctx.fillStyle = skyGrad('#86c3ea', '#e2f1f4'); ctx.fillRect(0, 0, w, gy);
      silhouettes(0.12, 13, gy - 4, 40, 80, 120, 200, '#9db8c4', 150);
      silhouettes(0.3, 17, gy - 2, 30, 90, 26, 46, '#7d97a8', 40);
      // 물
      const g = ctx.createLinearGradient(0, gy, 0, G.h); g.addColorStop(0, '#3d86bf'); g.addColorStop(1, '#1f5583');
      ctx.fillStyle = g; ctx.fillRect(0, gy, w, G.h - gy);
      ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1.5;
      for (let r = 0; r < 4; r++) {
        const y = gy + 6 + r * 13, o = ((cam.x * k + t * 20 * (r % 2 ? 1 : -1)) % 60 + 60) % 60;
        for (let x = -o; x < w; x += 60) { ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 8, y - 3, x + 16, y); ctx.stroke(); }
      }
      // 건너편 강둑
      const bk = SX(S.bank);
      if (bk < w + 20) {
        ctx.fillStyle = '#6aa04d'; ctx.beginPath(); ctx.moveTo(bk - 0.9 * k, G.h); ctx.lineTo(bk - 0.9 * k, gy + 2); ctx.lineTo(bk, SY(1.1)); ctx.lineTo(w + 10, SY(1.1)); ctx.lineTo(w + 10, G.h); ctx.fill();
        ctx.fillStyle = '#8bbf5e'; ctx.fillRect(bk, SY(1.1) - 2, w - bk + 10, 4);
        for (let x = S.bank + 3; x < S.bank + 40; x += 6.5) { const sx = SX(x); if (sx > w + 30) break; ctx.fillStyle = '#5d4030'; ctx.fillRect(sx - 2, SY(2.6), 4, 1.5 * k); ctx.fillStyle = '#3f7f45'; ctx.beginPath(); ctx.arc(sx, SY(3.0), 0.9 * k, 0, 7); ctx.fill(); }
        ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
        ctx.fillText('건너편 +20', bk + 8, SY(1.1) - 6);
      }
      // 다리
      ctx.fillStyle = '#8d8a96'; ctx.fillRect(SX(-7), SY(6.1), SX(-5.6) - SX(-7), gy - SY(6.1));
      ctx.fillStyle = '#a7a3b0'; ctx.fillRect(SX(-30), SY(6.7), SX(0.6) - SX(-30), 0.6 * k);
      ctx.fillStyle = '#77737f'; ctx.fillRect(SX(-30), SY(6.1) - 3, SX(0.6) - SX(-30), 3);
      ctx.strokeStyle = '#d24b3c'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(SX(-30), SY(7.65)); ctx.lineTo(SX(0.55), SY(7.65)); ctx.stroke();
      for (let x = -12; x <= 0.55; x += 0.6) { ctx.beginPath(); ctx.moveTo(SX(x), SY(7.65)); ctx.lineTo(SX(x), SY(6.7)); ctx.stroke(); }
      // 고리 뒤쪽 반
      if (cd.rg) cd.rg.forEach((r, i) => hoop(r, passed & (1 << i), false));
    }

    /* ---- 미니맵·상단 표시 ---- */
    function drawStrip(D) {
      const S = STAGES[D.si], y = G.stripY, w = G.w;
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textBaseline = 'middle';
      const rd = st ? (D.r + 1) + '/' + st.R + ' ' : '';
      let left = rd + S.name + ' · ' + S.goal;
      const ws = D.cd.w, wtxt = Math.abs(ws) < 0.15 ? '바람 없음' : (ws > 0 ? '뒷바람 → ' : '맞바람 ← ') + Math.abs(ws).toFixed(1) + 'm/s';
      const showWind = D.si !== 0;
      const wwid = showWind ? ctx.measureText(wtxt).width + 20 : 0;
      // landscape: the mini map sits between the two pills, so keep at least ~200px for it
      if (ctx.measureText(left).width + 20 > w - 24 - wwid - 6 - (G.land ? 216 : 0)) left = rd + S.name;
      const lw = ctx.measureText(left).width + 20;
      G.mx0 = G.land ? 12 + lw + 8 : 12; G.mx1 = G.land ? w - 12 - (showWind ? wwid + 8 : 0) : w - 12;
      ctx.fillStyle = 'rgba(23,19,31,.8)'; rr(12, y, lw, 22, 11); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.fillText(left, 22, y + 11.5);
      if (showWind) {
        ctx.fillStyle = 'rgba(23,19,31,.8)'; rr(w - 12 - wwid, y, wwid, 22, 11); ctx.fill();
        ctx.fillStyle = Math.abs(ws) < 0.15 ? '#ab9fb8' : ws > 0 ? '#5fd3a0' : '#ee8a75'; ctx.textAlign = 'right'; ctx.fillText(wtxt, w - 22, y + 11.5);
      }
    }
    function drawMini(D, passed) {
      const S = STAGES[D.si], x0 = G.mx0, x1 = G.mx1, y0 = G.mmY, hh = G.mmH, rg = MM[D.si];
      ctx.fillStyle = 'rgba(23,19,31,.78)'; rr(x0, y0, x1 - x0, hh, 10); ctx.fill();
      const mk = (x1 - x0 - 16) / (rg[1] - rg[0]), top = D.si === 0 ? 3.4 : D.si === 2 ? 14 : D.si === 3 ? 10 : 8;
      const vk = Math.min(mk * 1.6, (hh - 10) / top);
      const MX = (x) => x0 + 8 + (x - rg[0]) * mk, MY = (y) => y0 + hh - 5 - y * vk;
      ctx.save(); rr(x0, y0, x1 - x0, hh, 10); ctx.clip();
      ctx.fillStyle = D.si === 3 ? 'rgba(61,134,191,.7)' : 'rgba(242,233,216,.25)'; ctx.fillRect(x0, MY(0), x1 - x0, 5);
      ctx.fillStyle = 'rgba(242,233,216,.32)';
      for (const b of S.boxes) { if (b[4] === 'ceil') { ctx.fillRect(x0, y0, x1 - x0, MY(b[2]) - y0); continue; } ctx.fillRect(MX(Math.max(b[0], rg[0] - 1)), MY(b[3]), (Math.min(b[1], rg[1] + 1) - Math.max(b[0], rg[0] - 1)) * mk, (b[3] - b[2]) * vk); }
      if (D.si === 2) { ctx.fillStyle = 'rgba(255,190,120,.28)'; for (const z of S.zones) ctx.fillRect(MX(z[0] - z[1] * 0.6), y0, z[1] * 1.2 * mk, hh); }
      if (D.si === 0) { ctx.fillStyle = 'rgba(91,179,230,.45)'; const z = S.zones[0]; ctx.fillRect(MX(z[0] - 0.6), y0, 1.2 * mk, hh); ctx.fillStyle = 'rgba(238,106,85,.45)'; const z2 = S.zones[1]; ctx.fillRect(MX(z2[0] - 0.4), y0, 0.8 * mk, hh); }
      if (D.si === 1) { ctx.fillStyle = '#e0574a'; ctx.fillRect(MX(D.cd.t - 1.75), MY(0) - 1, 3.5 * mk, 4); ctx.fillStyle = '#f2e9d8'; ctx.fillRect(MX(D.cd.t) - 1, MY(0) - 8, 2, 8); }
      if (D.si === 3 && D.cd.rg) D.cd.rg.forEach((r, i) => { ctx.strokeStyle = passed & (1 << i) ? '#f4c64e' : '#ee6a55'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(MX(r[0]), MY(r[1]), 2, Math.max(3, RR * vk), 0, 0, 7); ctx.stroke(); });
      // 이번 라운드 깃발
      const fr = flags[D.r] || {};
      for (const s in fr) { if (anim && anim.L.s === +s && !anim.landed) continue; ctx.fillStyle = col(+s); ctx.fillRect(MX(fr[s]) - 1.5, MY(surfAt(D.si, fr[s])) - 9, 3, 9); }
      // 비행 중
      if (anim) {
        ctx.strokeStyle = col(anim.L.s); ctx.lineWidth = 1.5; ctx.beginPath();
        const tr = anim.trail, stp = Math.max(1, Math.floor(tr.length / 80));
        for (let i = 0; i < tr.length; i += stp) i ? ctx.lineTo(MX(tr[i][0]), MY(tr[i][1])) : ctx.moveTo(MX(tr[i][0]), MY(tr[i][1]));
        ctx.lineTo(MX(anim.fl.x), MY(anim.fl.y)); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(MX(anim.fl.x), MY(anim.fl.y), 2.5, 0, 7); ctx.fill();
      }
      // 화면에 보이는 범위
      ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1;
      ctx.strokeRect(MX(cam.x), y0 + 2, (G.w / k) * mk, hh - 4);
      ctx.restore();
    }

    /* ---- 조준 ---- */
    const CANCEL = 22;
    /* 누른 점에서 (ux, uy) 방향으로 휴대폰 화면 끝까지 거리(px) — 손가락은 HUD·앱 머리줄 위로도 끌 수 있다 */
    function screenRoom(x, y, ux, uy) {
      const r = cv.cv.getBoundingClientRect(), x0 = -r.left, y0 = -r.top, x1 = (window.innerWidth || G.w) - r.left, y1 = (window.innerHeight || G.h) - r.top;
      let t = 1e9;
      if (ux > 1e-6) t = Math.min(t, (x1 - x) / ux); else if (ux < -1e-6) t = Math.min(t, (x0 - x) / ux);
      if (uy > 1e-6) t = Math.min(t, (y1 - y) / uy); else if (uy < -1e-6) t = Math.min(t, (y0 - y) / uy);
      return Math.max(0, t);
    }
    /* 100% = 짧은 화면 변의 약 0.36배만큼 끌기. 그 방향으로 화면 끝이 더 가까우면 끝 바로 앞에서 100%가 되도록 눈금을 줄이고,
       손가락을 화면 끝에 대고 있으면 계속 당겨진다(edgePull) */
    function aimInfo() {
      if (!drag) return null;
      const dx = drag.dx, dy = drag.dy, len = Math.hypot(dx, dy);
      if (len < CANCEL) return { cancel: true };
      let maxPx = clamp(Math.min(window.innerWidth || G.w, window.innerHeight || G.h) * 0.36, 120, 180);
      maxPx = clamp(screenRoom(drag.ox, drag.oy, dx / len, dy / len) - CANCEL, 56, maxPx);
      const a = clamp(Math.atan2(dy, -dx), ANG_MIN, ANG_MAX); // 앞으로 당기면 끝 각도로
      return { a, p: Math.round(clamp((len - CANCEL + 6) / maxPx, 0.02, 1) * 100) / 100 };
    }
    /* 화면 끝에 손가락을 댄 채 그쪽으로 당기고 있으면 시작점이 같은 선을 따라 뒤로 밀려 세기가 계속 오른다(각도는 그대로) */
    function edgePull(dt) {
      if (!drag || !drag.started || drag.cx == null) return;
      const len = Math.hypot(drag.dx, drag.dy);
      if (len < CANCEL) return;
      const ux = drag.dx / len, uy = drag.dy / len, Wn = window.innerWidth || G.w, Hn = window.innerHeight || G.h, E = 18;
      if (!((ux < -0.3 && drag.cx < E) || (ux > 0.3 && drag.cx > Wn - E) || (uy < -0.3 && drag.cy < E) || (uy > 0.3 && drag.cy > Hn - E))) return;
      const info = aimInfo();
      if (!info || info.cancel || info.p >= 1) return;
      const d = 150 * dt;
      drag.ox -= ux * d; drag.oy -= uy * d; drag.dx += ux * d; drag.dy += uy * d;
      aimFeedback(); dirty = true;
    }

    /* ---- 메인 그리기 ---- */
    function draw() {
      cv.clear();
      if (!G) return;
      const D = disp(), si = D.si, S = STAGES[si], t = tNow / 1000;
      // k (배율) is set by camUpdate (zoom)
      const passed = anim ? anim.fl.rings : 0;
      if (si === 0) drawClass(t); else if (si === 1) drawField(t, D.cd); else if (si === 2) drawRoof(t); else drawRiver(t, D.cd, passed);
      // 이번 라운드 다른 사람 궤적·깃발
      const tr0 = trails[D.r] || {}, fr = flags[D.r] || {};
      ctx.setLineDash([2, 6]); ctx.lineCap = 'round';
      for (const s in tr0) {
        if (anim && anim.L.s === +s) continue;
        const P = tr0[s]; ctx.strokeStyle = col(+s); ctx.globalAlpha = 0.4; ctx.lineWidth = 2; ctx.beginPath();
        P.forEach((q, i) => (i ? ctx.lineTo(SX(q[0]), SY(q[1])) : ctx.moveTo(SX(q[0]), SY(q[1])))); ctx.stroke();
      }
      ctx.globalAlpha = 1; ctx.setLineDash([]);
      let fi = 0;
      for (const s in fr) { if (anim && anim.L.s === +s && !anim.landed) continue; drawFlag(si, fr[s], +s, fi++ % 3, 1); }
      // 던지는 사람
      const a0 = anim ? anim.L.s : st && st.ph === 'p' ? actor(st) : null;
      const ai2 = aimInfo();
      const aimA = ai2 && !ai2.cancel ? ai2.a : 0.25, pull = ai2 && !ai2.cancel ? ai2.p * 18 : 0;
      const kidC = a0 != null ? col(a0) : '#e3ae45';
      const hand = drawKid(si, kidC, anim ? 0.3 : aimA, pull);
      // 날고 있는 비행기
      if (anim) {
        const A = anim, f = A.fl, c = col(A.L.s);
        ctx.setLineDash([3, 6]); ctx.strokeStyle = c; ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.beginPath();
        const tr = A.trail, i0 = Math.max(0, tr.length - 600);
        for (let i = i0; i < tr.length; i++) i > i0 ? ctx.lineTo(SX(tr[i][0]), SY(tr[i][1])) : ctx.moveTo(SX(tr[i][0]), SY(tr[i][1]));
        ctx.lineTo(SX(f.x), SY(f.y)); ctx.stroke(); ctx.setLineDash([]);
        const sg = surfAt(si, f.x), hgt = f.y - sg;
        if (hgt < 4 && !A.landed) { ctx.fillStyle = 'rgba(0,0,0,' + (0.25 * (1 - hgt / 4)).toFixed(3) + ')'; ctx.beginPath(); ctx.ellipse(SX(f.x), SY(sg), 12, 3, 0, 0, 7); ctx.fill(); }
        let ang = Math.atan2(f.ay, f.ax);
        if (A.landed) ang = f.crash ? -0.6 : -0.08;
        else if (f.crash) ang = Math.sin(t * 9) * 0.9 - 0.9;
        drawPlane(SX(f.x), SY(f.y), ang, A.L.f, c);
      } else if (a0 != null && st.ph === 'p' && !sum) {
        drawPlane(hand[0], hand[1], aimA, foldOf(a0), kidC);
      }
      // 고리 앞쪽 반
      if (si === 3 && D.cd.rg) D.cd.rg.forEach((r, i) => hoop(r, passed & (1 << i), true));
      // 바람 입자
      drawParticles(si, D.cd);
      // 떠오르는 글자·불꽃
      for (const s of sparks) {
        ctx.globalAlpha = 1 - s.t; ctx.fillStyle = s.c;
        const x = SX(s.x) + s.vx * s.t * 50, y = SY(s.y) - s.vy * s.t * 50 + s.t * s.t * 20;
        ctx.fillRect(x - 2, y - 2, 4, 4);
      }
      ctx.globalAlpha = 1;
      for (const fl of floats) {
        ctx.globalAlpha = Math.min(1, 2.2 - fl.t * 2);
        ctx.font = (fl.big ? '800 20px' : '800 15px') + ' "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        const x = clamp(SX(fl.x), 50, G.w - 50), y = SY(fl.y) - 22 - fl.t * 26;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(23,19,31,.8)'; ctx.strokeText(fl.text, x, y);
        ctx.fillStyle = fl.c; ctx.fillText(fl.text, x, y);
      }
      ctx.globalAlpha = 1;
      // 조준선 (처음 방향만 보여 줌)
      if (drag && a0 != null && !anim) {
        ctx.strokeStyle = ai2 && ai2.cancel ? 'rgba(238,106,85,.9)' : 'rgba(255,255,255,.35)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.arc(drag.ox, drag.oy, CANCEL, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      const ps = a0 != null ? prevShot[a0] : null;
      if (a0 != null && !anim && !sum && canHuman() && ps && (!ai2 || !ai2.cancel)) {
        const L2 = 30 + ps.p * ARW(), dx = Math.cos(ps.a), dy = -Math.sin(ps.a);
        ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 2; ctx.setLineDash([2, 5]);
        ctx.beginPath(); ctx.moveTo(SX(0) + dx * 16, SY(S.start[1]) + dy * 16); ctx.lineTo(SX(0) + dx * L2, SY(S.start[1]) + dy * L2); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(242,233,216,.55)'; ctx.font = '600 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText('지난번', SX(0) + dx * L2 + 5, SY(S.start[1]) + dy * L2);
      }
      if (ai2 && !ai2.cancel && a0 != null && !anim) {
        const L2 = 30 + ai2.p * ARW(), dx = Math.cos(ai2.a), dy = -Math.sin(ai2.a), hx = hand[0], hy = hand[1];
        const pc = ai2.p < 0.5 ? '#5fd3a0' : ai2.p < 0.8 ? '#e3ae45' : '#ee6a55';
        ctx.strokeStyle = 'rgba(23,19,31,.5)'; ctx.lineWidth = 6; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(hx + dx * 18, hy + dy * 18); ctx.lineTo(hx + dx * L2, hy + dy * L2); ctx.stroke();
        ctx.strokeStyle = pc; ctx.lineWidth = 3; ctx.setLineDash([6, 5]);
        ctx.beginPath(); ctx.moveTo(hx + dx * 18, hy + dy * 18); ctx.lineTo(hx + dx * L2, hy + dy * L2); ctx.stroke(); ctx.setLineDash([]);
        const ex = hx + dx * L2, ey = hy + dy * L2, nx = -dy, ny = dx;
        ctx.fillStyle = pc; ctx.beginPath(); ctx.moveTo(ex + dx * 10, ey + dy * 10); ctx.lineTo(ex + nx * 7, ey + ny * 7); ctx.lineTo(ex - nx * 7, ey - ny * 7); ctx.closePath(); ctx.fill();
      }
      // 큰 숫자 표시 / 안내
      if (ai2 && a0 != null && !anim && drag && drag.started) {
        const bx = G.w - 84, by = G.gTop + 28;
        ctx.fillStyle = 'rgba(23,19,31,.85)'; rr(bx - 72, by - 22, 144, 44, 12); ctx.fill();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        if (ai2.cancel) { ctx.fillStyle = '#ee6a55'; ctx.font = '700 15px "IBM Plex Sans KR", sans-serif'; ctx.fillText('놓으면 취소', bx, by + 1); }
        else {
          ctx.fillStyle = '#f2e9d8'; ctx.font = '700 20px "IBM Plex Mono", monospace';
          ctx.fillText(Math.round(ai2.a / DEG) + '°', bx - 34, by - 2);
          ctx.fillText(Math.round(ai2.p * 100) + '%', bx + 30, by - 2);
          ctx.fillStyle = '#ab9fb8'; ctx.font = '600 10px "IBM Plex Sans KR", sans-serif';
          ctx.fillText('각도', bx - 34, by + 15); ctx.fillText('세기', bx + 30, by + 15);
        }
      } else if (!anim && !sum && canHuman() && !drag) {
        const F = FOLDS[foldOf(actor(st))];
        const l1 = '아무 데나 뒤로 끌었다 놓아 던지기', l2 = F.name + ' · ' + F.tip;
        ctx.font = '700 13px "IBM Plex Sans KR", sans-serif';
        const w1 = Math.max(ctx.measureText(l1).width, (ctx.font = '500 11px "IBM Plex Sans KR", sans-serif', ctx.measureText(l2).width)) + 24;
        const bx = G.w / 2, by = G.gTop + 26;
        ctx.fillStyle = 'rgba(23,19,31,.78)'; rr(bx - w1 / 2, by - 18, w1, 40, 12); ctx.fill();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#f2e9d8'; ctx.font = '700 13px "IBM Plex Sans KR", sans-serif'; ctx.fillText(l1, bx, by - 5);
        ctx.fillStyle = '#ab9fb8'; ctx.font = '500 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText(l2, bx, by + 11);
      }
      drawStrip(D);
      drawMini(D, passed);
    }
    function drawParticles(si, cd) {
      if (si === 0) return;
      if (!parts.length) for (let i = 0; i < 22; i++) parts.push({ x: hsh(5, i), y: hsh(6, i) * 0.5 + 0.5, z: 0.6 + (hsh(7, i) * 0.5 + 0.5) * 0.6 });
      const sw = Math.abs(cd.w) + 0.4, c = si === 1 ? 'rgba(120,160,70,.55)' : si === 2 ? 'rgba(255,230,200,.45)' : 'rgba(255,255,255,.55)';
      ctx.strokeStyle = c; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
      for (const p of parts) {
        const x = p.px, y = p.py; if (x == null) continue;
        const len = Math.min(26, sw * 4 * p.z) * (cd.w >= 0 ? 1 : -1);
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - len, y + Math.sin(tNow / 300 + p.x * 9) * 1.5); ctx.stroke();
      }
    }
    function stepParticles(dt, si, cd) {
      if (si === 0) return;
      const sp = (cd.w + (cd.w >= 0 ? 0.3 : -0.3)) * k * 0.9;
      for (const p of parts) {
        if (p.px == null) { p.px = (p.x * 0.5 + 0.5) * G.w; p.py = G.gTop + p.y * (G.groundY - G.gTop - 10); }
        p.px += sp * p.z * dt * L.debug.speed + (p.cx != null ? (p.cx - cam.x) * k * p.z : 0);
        p.cx = cam.x;
        p.py += Math.sin(tNow / 700 + p.x * 20) * 0.15;
        if (p.px > G.w + 30) p.px -= G.w + 60; else if (p.px < -30) p.px += G.w + 60;
      }
    }

    /* ---- 입력: 새총처럼 뒤로 끌었다 놓기 ---- */
    function onDown(ev) {
      if (anim) { anim.ff = 5; return; } // 다시보기 빨리 감기
      if (!canHuman() || drag) return;
      const p = cv.local(ev);
      if (p.y < G.mmY + G.mmH) return;
      drag = { id: ev.pointerId, ox: p.x, oy: p.y, dx: 0, dy: 0, started: false, cx: ev.clientX, cy: ev.clientY };
      lastTick = -1; wasCancel = true;
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      api.buzz(8); dirty = true;
    }
    function onMove(ev) {
      if (!drag || drag.id !== ev.pointerId) return;
      const p = cv.local(ev);
      drag.dx = p.x - drag.ox; drag.dy = p.y - drag.oy; drag.cx = ev.clientX; drag.cy = ev.clientY;
      if (Math.hypot(drag.dx, drag.dy) > CANCEL) drag.started = true;
      aimFeedback();
      dirty = true;
    }
    function aimFeedback() {
      const info = aimInfo();
      if (info && drag.started) {
        if (!!info.cancel !== wasCancel) { wasCancel = !!info.cancel; api.buzz(info.cancel ? 20 : 8); }
        const tk = info.cancel ? -1 : Math.floor(info.p * 10);
        if (tk !== lastTick && tk >= 0) api.sfx('tick');
        lastTick = tk;
      }
    }
    function onUp(ev) {
      if (!drag || drag.id !== ev.pointerId) return;
      const info = aimInfo(), d0 = drag; drag = null; dirty = true;
      if (!canHuman() || !info) return;
      if (info.cancel) { if (d0.started) { api.sfx('click'); api.toast('취소'); } return; }
      const a = actor(st);
      api.buzz(15);
      if (!api.isHost) sentAt = performance.now();
      api.act({ type: 'throw', f: foldOf(a), a: Math.round(info.a * 1000) / 1000, p: info.p });
      renderBot();
    }
    function onCancel(ev) { if (drag && drag.id === ev.pointerId) { drag = null; dirty = true; } }
    const el = cv.cv;
    el.addEventListener('pointerdown', onDown); el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp); el.addEventListener('pointercancel', onCancel);

    /* ---- 루프 ---- */
    /* 카메라: 조준할 때는 던지는 사람 쪽으로 당겨(확대) 손·비행기·화살표가 크고 잘 보이게, 던지면 부드럽게 넓게 빠지며 비행기를
       따라가고, 끝나면 다시 조준 화면으로 돌아온다. 옥상·다리처럼 높은 곳은 확대할 때 시점도 위로 올린다. */
    const KAIM = 24; // 조준할 때 배율(px/m) — 장면이 18px/m보다 작게 보이면(옥상·다리 등) 사람이 너무 작지 않게 이만큼 확대
    function aimCam(si) {
      const kb = kBase(si), z = kb < 18 ? clamp(KAIM / kb, 1, 2.2) : 1, kk = kb * z, S = STAGES[si];
      const hyT = G.gTop + (G.groundY - G.gTop) * 0.58; // 손이 장면 높이의 58% 쯤에 오게
      return { z, y: z > 1.001 ? Math.max(0, S.start[1] - (G.groundY - hyT) / kk) : 0 }; // 확대 안 하면 스테이지 전체가 들어온다
    }
    function camUpdate(dt) {
      const D = disp(), si = D.si, S = STAGES[si];
      const aiming = !anim && !sum, A = aimCam(si);
      if (cam.si !== si) { cam.si = si; cam.z = A.z; cam.y = A.y; k = kBase(si) * cam.z; cam.x = baseX(); parts.forEach((p) => { p.px = null; p.cx = null; }); }
      const zt = aiming ? A.z : anim && !anim.landed ? 1 : cam.z;
      cam.z += (zt - cam.z) * (1 - Math.pow(aiming ? 0.03 : 0.004, dt));
      if (Math.abs(cam.z - zt) < 0.002) cam.z = zt;
      k = kBase(si) * cam.z;
      if (anim && !anim.landed) {
        const f = anim.fl;
        cam.x = Math.max(cam.x, Math.max(baseX(), f.x - G.w * 0.45 / k));
        if (f.x - G.w * 0.2 / k < cam.x) cam.x = Math.max(baseX(), f.x - G.w * 0.2 / k); // 뒤로 돌아오면 따라감
        const ty = si === 0 ? 0 : Math.max(0, f.y - S.span * 0.78);
        cam.y += (ty - cam.y) * (1 - Math.pow(0.002, dt));
      } else if (aiming) {
        const a = 1 - Math.pow(0.03, dt);
        cam.x += (baseX() - cam.x) * a; cam.y += (A.y - cam.y) * a;
        if (Math.abs(cam.x - baseX()) > 0.002 || Math.abs(cam.y - A.y) > 0.002) dirty = true;
      }
    }
    const stop = U.loop((dt, now) => {
      tNow = now;
      if (anim && !anim.landed) {
        const A = anim, f = A.fl;
        A.acc += dt * L.debug.speed * RATE[A.L.si] * A.ff;
        let n = 0;
        while (A.acc >= DT && !f.done && n < 5000) {
          f.step(); A.acc -= DT; n++;
          if (f.k % 3 === 0 && A.trail.length < 1200) A.trail.push([f.x, f.y]);
          if (f.rings !== A.rings) {
            const nw = f.rings & ~A.rings; A.rings = f.rings;
            A.L.cd.rg.forEach((r, i) => { if (nw & (1 << i)) { floats.push({ x: r[0], y: r[1] + RR, text: '+20', c: '#f4c64e', t: 0 }); burst(r[0], r[1], '#f4c64e'); } });
            api.sfx('pop'); api.buzz(15);
          }
          if (f.loops !== A.loops) { A.loops = f.loops; if (A.loops <= 2) { floats.push({ x: f.x, y: f.y + 0.5, text: '공중제비! +20', c: '#b48cf0', t: 0 }); api.sfx('win'); api.buzz(20); } }
          if (f.hits > A.hits) { A.hits = f.hits; api.sfx('bounce'); }
        }
        if (f.done) land();
        dirty = true;
      } else if (anim && anim.landed) {
        anim.hold += dt * L.debug.speed * Math.min(anim.ff, 2);
        if (anim.hold > 1.15) finishReplay();
        dirty = true;
      }
      if (G) camUpdate(dt);
      if (drag) edgePull(dt);
      if (sparks.length) { for (const s of sparks) s.t += dt * 1.5 * L.debug.speed; for (let i = sparks.length - 1; i >= 0; i--) if (sparks[i].t >= 1) sparks.splice(i, 1); dirty = true; }
      if (floats.length) { for (const s of floats) s.t += dt * L.debug.speed * 0.9; for (let i = floats.length - 1; i >= 0; i--) if (floats[i].t >= 1.1) floats.splice(i, 1); dirty = true; }
      const D = disp();
      if (G) stepParticles(dt, D.si, D.cd);
      dirty = true; // 바람 입자·선풍기·물결이 늘 움직인다
      if (dirty && G) { dirty = false; draw(); }
    });

    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        const L0 = next.last;
        if (L0 && L0.id !== shownId && prev && prev !== next) {
          shownId = L0.id;
          const sp = Math.hypot(L0.v[0], L0.v[1]), F = FOLDS[L0.f];
          prevShot[L0.s] = { a: Math.atan2(L0.v[1], L0.v[0]), p: clamp((sp - F.vmin) / (F.vmax - F.vmin), 0, 1) };
          if (api.players[L0.s] && !api.canAct(L0.s)) fold[L0.s] = L0.f;
          startReplay(L0, next);
        } else if (L0) shownId = L0.id;
        if (next.ph === 'p') {
          const fr = (flags[next.r] = flags[next.r] || {});
          next.lx.forEach((x, i) => { if (x != null && !(anim && anim.L.s === i && anim.L.r === next.r && !anim.landed)) fr[i] = x; });
        }
        renderTop(); renderBot(); dirty = true;
      },
      destroy() {
        stop(); clearTimeout(sumTimer); clearTimeout(safeTimer);
        el.removeEventListener('pointerdown', onDown); el.removeEventListener('pointermove', onMove);
        el.removeEventListener('pointerup', onUp); el.removeEventListener('pointercancel', onCancel);
        cv.destroy(); top.remove(); bot.remove(); if (sumEl) sumEl.remove();
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'paperplane', name: '종이비행기 날리기', tag: '접고 날리기', cat: '스포츠',
    blurb: '다트형·글라이더형·곡예형 중 접는 방식을 고르고, 뒤로 끌었다 놓아 던져요. 교실·운동장·옥상·강변 다리에서 스테이지마다 다른 목표로 점수를 모아요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 700,
    tint: '#244a6b',
    icon: '<path d="M6 30L50 10L32 48L26 33Z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M26 33L50 10" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M26 33L24 42" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M6 50C10 47 14 44 18 39" fill="none" stroke="currentColor" stroke-width="2.4" stroke-dasharray="1 5" stroke-linecap="round"/>',
    options: [
      { id: 'stage', label: '스테이지', choices: [{ v: 'rnd', label: '무작위' }, { v: 0, label: '교실' }, { v: 1, label: '운동장' }, { v: 2, label: '옥상' }, { v: 3, label: '강변 다리' }], def: 'rnd' },
      { id: 'rd', label: '라운드', choices: [{ v: 3, label: '3판' }, { v: 4, label: '4판' }, { v: 5, label: '5판' }], def: 3 },
    ],
    landscape: true,
    quick: [
      '목표: 라운드마다 종이비행기를 한 번씩 날려 점수를 모으고, 합계가 가장 높으면 승리',
      '내 차례: 접는 방식(다트·글라이더·곡예)을 고르고 → 화면을 뒤로 끌었다 놓아 던지기',
      '이기는 법: 스테이지 목표(멀리·과녁·옥상·고리)를 노리고, 바람을 읽고, 공중제비로 +20',
    ],
    tutorial: [
      { text: '종이비행기 날리기예요! 차례마다 한 번 던지고, 스테이지 목표에 맞을수록 점수가 커요.' },
      { text: '먼저 접는 방식을 골라요. 다트형은 빠르고 곧게, 글라이더형은 오래 떠 있고, 곡예형은 세게 던지면 공중제비를 돌아요.', sel: '[data-tut="fold"]' },
      { text: '던지기: 화면 아무 데나 누르고, 날리고 싶은 쪽의 반대(뒤·아래)로 끌었다 놓아요. 새총처럼요! 많이 끌수록 세게 날아가요.' },
      { text: '화면 끝 때문에 더 못 끌겠으면 손가락을 끝에 대고 잠깐 있으면 세기가 100%까지 올라가요. 점선 원 안으로 돌아와 놓으면 취소예요.' },
      { text: '위쪽 띠에 스테이지 목표와 바람, 작은 지도에 코스 전체가 보여요. 날아가는 동안 화면을 누르면 빨리 감기!' },
    ],
    rules: [
      { h: '목표', p: ['1–4명이 종이비행기를 번갈아 한 번씩 날려요. 모두 한 번씩 던지면 한 라운드예요.', '라운드(3·4·5판, 기본 3판)마다 스테이지가 바뀌고, 스테이지마다 점수 받는 방법이 달라요.'] },
      { h: '차례에 할 일', p: ['① 아래 버튼에서 접는 방식을 골라요(한 번 고르면 다음에도 그대로).', '② 화면을 뒤로 끌었다 놓아 던져요. 던지면 끝, 다음 사람 차례예요.'] },
      { h: '점수·승리', p: ['모든 라운드 점수를 더해 가장 높은 사람이 이겨요. 같으면 공동 우승.', '1라운드는 자리 순서, 그다음부터는 합계가 낮은 사람부터 던져요(선두가 마지막).'] },
      { h: '접는 방식', p: ['다트형: 빠르고 곧게 날아가요. 세게 던질 수 있고 바람에 강해요.', '글라이더형: 느리지만 아주 오래 떠 있어요. 상승기류를 잘 타지만 맞바람에 약해요.', '곡예형: 세게 던지면 공중제비(한 바퀴)를 돌아요. 높이 솟았다가 출렁이며 날아가요.', '버튼의 막대는 속도·활공·상승 힘이에요.'] },
      { h: '조작 (던지기)', p: ['화면 아무 데나 누르고 던질 방향의 반대쪽으로 끌었다 놓아요. 새총과 같아요. 앞 위로 날리려면 뒤 아래(왼쪽 아래)로 끌어요.', '많이 끌수록 세게 던지고, 각도와 세기(%)가 화면 위에 나와요. 화살표는 처음 날아갈 방향만 보여 줘요.', '화면 끝 때문에 더 못 끌 때는: 끝까지 끌면 100%가 되도록 눈금이 저절로 맞춰지고, 손가락을 화면 끝에 대고 있으면 세기가 계속 올라가요.', '조준할 때는 화면이 던지는 사람 쪽으로 가까이 다가가고(높은 곳에서는 시점도 위로), 던지면 넓게 빠지며 비행기를 따라가요.', '누른 자리의 점선 원 안으로 되돌아와 놓으면 취소돼요. 흐린 점선은 내 지난번 던지기예요.', '던진 뒤에는 조종할 수 없어요. 날아가는 동안 화면을 탭하면 빨리 감기.', '가로 화면에서 가장 크게 보이지만, 세로로 해도 돼요.'] },
      { h: '스테이지와 점수', p: ['교실: 멀리 갈수록 1m에 5점(16m 끝까지 80점). 앞 벽 칠판에 맞히면 +20점. 천장에 닿으면 튕기고, 선풍기 아래는 바람이 내리누르고 온풍기 위는 떠올라요.',
        '운동장: 땅에 그린 과녁에 내려앉히기. 가운데 100 · 70 · 45 · 25 · 10점(가운데에서 0.75 · 1.75 · 3 · 5 · 8m 안). 바람이 불어요.',
        '옥상: 멀리 날려 다른 건물 옥상에 내리면 1m에 0.8점, 길에 떨어지면 절반(0.4점). 건물 사이 상승기류(주황빛)가 비행기를 띄워 줘요. 건물 옆면에 부딪히면 떨어져요.',
        '강변 다리: 강 위 고리 4개를 하나 지날 때마다 20점, 건너편 강둑에 내리면 +20점.',
        '공중제비 보너스: 어느 스테이지든 한 바퀴 돌 때마다 +20점(한 번 던질 때 최대 2번).',
        '바람과 고리·과녁 위치는 라운드마다 바뀌고, 같은 라운드에서는 모두 같은 조건이에요. 위쪽 띠에 바람, 작은 지도에 전체 모습과 깃발이 보여요.'] },
      { h: '예시', p: ['운동장에서 과녁이 20m에 있고 뒷바람(→)이 조금 불면: 다트형을 낮게(10~20°) 55~60% 쯤으로 던지면 과녁 근처에 내려요.', '옥상에서는 글라이더형을 세게(90% 이상) 던져 주황빛 상승기류를 타면 100m 넘게 먼 옥상까지 갈 수 있어요.', '곡예형을 아주 세게 던지면 공중제비를 돌아 +20점이 더해져요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(접기 선택과 던지기 정확도가 달라요).'] },
    ],
    init, actor, apply, ai, result, mount,
    aiDelayFor() { return 700; },
    _sim: { FOLDS, STAGES, Flight, throwSim, scoreOf, newCond, shotVec, air, ai },
  });
})();
