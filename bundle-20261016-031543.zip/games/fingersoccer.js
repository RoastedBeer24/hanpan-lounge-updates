/* 손가락 축구 — 2인 턴제 플릭 축구. 팀마다 디스크 5개 + 공 1개. 결정적 고정 스텝 물리(구름 마찰, 질량별 반발 충돌,
   레일·골대 반사): apply가 끝까지 시뮬레이션하고 last={id,pre,shot}을 남기며, 뷰는 같은 Sim으로 재생한다.
   단위: 테이블 위 cm. x = 가로(0..W), y = 세로(0 = 위쪽 골라인, H = 아래쪽 골라인). 0번 팀은 아래에서 위로 공격. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }
  /* The first-play tutorial opens right away, maybe while an AI moves first: then the steps about my own controls
     had nothing to point at. If it was watched to the end like that, replay just those steps (sels) the first time
     my controls are up. Call the returned tick(mine) every frame. */
  function tutCatchUp(root, api, id, sels) {
    let missed = false, last = false, done = false;
    return (mine) => {
      if (done) return;
      const card = root.querySelector('.tut-layer .tut-card');
      if (card) {
        const m = /(\d+)\s*\/\s*(\d+)/.exec((card.querySelector('.label') || {}).textContent || '');
        last = !!m && m[1] === m[2];
        if (!mine) missed = true;
        return;
      }
      if (!missed) { if (mine) done = true; return; }
      if (!last) { done = true; return; }   // skipped: don't bring it back
      if (!mine) return;
      done = true;
      setTimeout(() => {
        const def = L.games[id], full = def && def.tutorial;
        if (!full || root.querySelector('.tut-layer')) return;
        def.tutorial = full.filter((s) => sels.includes(s.sel));
        try { api.tutorial(); } finally { def.tutorial = full; }
      }, 400);
    };
  }

  /* ---------- pitch ---------- */
  const W = 64, H = 100, GW = 9, GD = 6, RD = 3.2, RB = 2.0, MD = 3, MB = 1;
  const GX0 = W / 2 - GW, GX1 = W / 2 + GW, CC = 9;
  const DT = 1 / 240, VMAX = 190, MAXT = 20, VSTOP = 1.2;
  const FR = { d: [90, 0.8], b: [40, 0.8] };       // rolling resistance: constant decel + speed damping
  const E_DB = 0.85, E_DD = 0.8, E_RD = 0.6, E_RB = 0.72, E_NET = 0.2, TF = 0.94;
  const NB = 11, BALL = 10;
  const r1 = (v) => Math.round(v * 10) / 10, r4 = (v) => Math.round(v * 10000) / 10000;
  // walls: [ax, ay, bx, by, thickness, kind] kind 0 rail, 1 goal frame (post), 2 net
  const WALLS = [];
  function wall(ax, ay, bx, by, th, k) { const dx = bx - ax, dy = by - ay; WALLS.push({ ax, ay, bx, by, dx, dy, l2: dx * dx + dy * dy, th, k }); }
  wall(0, 0, GX0, 0, 0, 0); wall(GX1, 0, W, 0, 0, 0); wall(0, H, GX0, H, 0, 0); wall(GX1, H, W, H, 0, 0);
  wall(0, 0, 0, H, 0, 0); wall(W, 0, W, H, 0, 0);
  for (const s of [-1, 1]) {
    const y0 = s < 0 ? 0 : H, yb = y0 + s * GD;
    wall(GX0, y0, GX0, yb, 0.6, 1); wall(GX1, y0, GX1, yb, 0.6, 1); wall(GX0, yb, GX1, yb, 0.3, 2);
  }
  const FORMS = {
    '2-2': [[32, 95], [19, 80], [45, 80], [21, 63], [43, 63]],
    '1-2-1': [[32, 95], [32, 83], [14, 72], [50, 72], [32, 63]],
    '3-1': [[32, 95], [13, 79], [32, 82], [51, 79], [32, 63]],
  };

  /* ---------- deterministic simulation (+ − × ÷ √ only) ---------- */
  function Sim(pre, shot) {
    this.x = new Float64Array(NB); this.y = new Float64Array(NB); this.vx = new Float64Array(NB); this.vy = new Float64Array(NB);
    for (let i = 0; i < NB; i++) { this.x[i] = +pre[i][0]; this.y[i] = +pre[i][1]; }
    this.vx[shot.i] = +shot.vx; this.vy[shot.i] = +shot.vy;
    this.goal = -1; this.gT = 0; this.steps = 0; this.done = false; this.hits = 0; this.hitV = 0; this.rails = 0; this.ballHit = false;
  }
  const rad = (i) => (i === BALL ? RB : RD), mass = (i) => (i === BALL ? MB : MD);
  Sim.prototype.step = function () {
    const x = this.x, y = this.y, vx = this.vx, vy = this.vy;
    for (let i = 0; i < NB; i++) {
      const sx = vx[i], sy = vy[i];
      if (sx === 0 && sy === 0) continue;
      const v = Math.sqrt(sx * sx + sy * sy), f = i === BALL ? FR.b : FR.d;
      let ns = (v - f[0] * DT) * (1 - f[1] * DT);
      if (ns < VSTOP) { vx[i] = 0; vy[i] = 0; continue; }
      const k = ns / v; vx[i] = sx * k; vy[i] = sy * k;
      x[i] += vx[i] * DT; y[i] += vy[i] * DT;
    }
    // body–body: rewind to the contact instant, exchange the mass-weighted normal impulse, advance again
    for (let i = 0; i < NB - 1; i++) {
      for (let j = i + 1; j < NB; j++) {
        if (vx[i] === 0 && vy[i] === 0 && vx[j] === 0 && vy[j] === 0) continue;
        const D = rad(i) + rad(j), D2 = D * D;
        let dx = x[j] - x[i], dy = y[j] - y[i];
        if (dx > D || dx < -D || dy > D || dy < -D) continue;
        const d2 = dx * dx + dy * dy;
        if (d2 >= D2) continue;
        const wx = vx[j] - vx[i], wy = vy[j] - vy[i], dw = dx * wx + dy * wy;
        if (dw < 0) {
          const ww = wx * wx + wy * wy;
          let tau = 0;
          if (ww > 1e-12) { const disc = dw * dw - ww * (d2 - D2); tau = (Math.sqrt(disc) + dw) / ww; if (tau > DT) tau = DT; if (tau < 0) tau = 0; }
          x[i] -= vx[i] * tau; y[i] -= vy[i] * tau; x[j] -= vx[j] * tau; y[j] -= vy[j] * tau;
          dx = x[j] - x[i]; dy = y[j] - y[i];
          let l = Math.sqrt(dx * dx + dy * dy); if (l < 1e-9) l = 1e-9;
          const nx = dx / l, ny = dy / l, rel = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny;
          if (rel > 0) {
            const mi = mass(i), mj = mass(j), e = j === BALL ? E_DB : E_DD, jm = rel * (1 + e) / (1 / mi + 1 / mj);
            vx[i] -= jm / mi * nx; vy[i] -= jm / mi * ny; vx[j] += jm / mj * nx; vy[j] += jm / mj * ny;
            this.hits++; if (rel > this.hitV) this.hitV = rel;
            if (j === BALL) this.ballHit = true;
          }
          x[i] += vx[i] * tau; y[i] += vy[i] * tau; x[j] += vx[j] * tau; y[j] += vy[j] * tau;
        }
        dx = x[j] - x[i]; dy = y[j] - y[i];
        const e2 = dx * dx + dy * dy;
        if (e2 < D2) {
          const l = Math.sqrt(e2);
          if (l > 1e-9) {
            const mi = mass(i), mj = mass(j), p = (D - l) + 1e-6, nx = dx / l, ny = dy / l, a = mj / (mi + mj), b = mi / (mi + mj);
            x[i] -= nx * p * a; y[i] -= ny * p * a; x[j] += nx * p * b; y[j] += ny * p * b;
          }
        }
      }
    }
    // rails, posts, nets
    for (let i = 0; i < NB; i++) {
      const r = rad(i);
      let px = x[i], py = y[i];
      if (px > r + 0.7 && px < W - r - 0.7 && py > r + 0.7 && py < H - r - 0.7) continue;
      for (let k = 0; k < WALLS.length; k++) {
        const s = WALLS[k], rr = r + s.th;
        let t = ((px - s.ax) * s.dx + (py - s.ay) * s.dy) / s.l2;
        if (t < 0) t = 0; else if (t > 1) t = 1;
        const qx = s.ax + s.dx * t, qy = s.ay + s.dy * t, ex = px - qx, ey = py - qy, d2 = ex * ex + ey * ey;
        if (d2 >= rr * rr || d2 < 1e-12) continue;
        const d = Math.sqrt(d2), nx = ex / d, ny = ey / d, vn = vx[i] * nx + vy[i] * ny;
        if (vn < 0) {
          const e = s.k === 2 ? E_NET : i === BALL ? E_RB : E_RD, tx = vx[i] - vn * nx, ty = vy[i] - vn * ny, tf = s.k === 2 ? 0.6 : TF;
          vx[i] = tx * tf - e * vn * nx; vy[i] = ty * tf - e * vn * ny;
          if (s.k !== 2 && -vn > 15) this.rails++;
        }
        px = qx + nx * rr; py = qy + ny * rr; x[i] = px; y[i] = py;
      }
    }
    // goal: the whole ball across the goal line between the posts
    if (this.goal < 0) {
      const bx = x[BALL], by = y[BALL];
      if (bx > GX0 && bx < GX1) {
        if (by + RB < 0) this.goal = 0;          // top goal → team 0 scores
        else if (by - RB > H) this.goal = 1;     // bottom goal → team 1 scores
      }
    }
    if (this.goal >= 0) this.gT++;
    this.steps++;
    let still = true;
    for (let i = 0; i < NB; i++) if (vx[i] !== 0 || vy[i] !== 0) { still = false; break; }
    if (still || this.steps > MAXT / DT || this.gT > 1.2 / DT) {
      for (let i = 0; i < NB; i++) { vx[i] = 0; vy[i] = 0; }
      this.done = true;
    }
  };
  Sim.prototype.run = function () { while (!this.done) this.step(); return this; };
  Sim.prototype.pos = function () {
    const out = [];
    for (let i = 0; i < NB; i++) {
      let px = this.x[i], py = this.y[i];
      // a disc that came to rest inside a goal is put back just in front of the goal line
      if (i !== BALL) { if (py < RD) py = Math.max(py, RD + 0.1); if (py > H - RD) py = Math.min(py, H - RD - 0.1); }
      out.push([r1(px), r1(py)]);
    }
    return out;
  };
  function simulate(pre, shot) { return new Sim(pre, shot).run(); }

  /* ---------- state ---------- */
  // p: 0..4 team 0 discs, 5..9 team 1 discs, 10 ball. Team 0 = seat 0 (bottom, attacks the top goal).
  function kickoff(form) {
    const f = FORMS[form] || FORMS['2-2'], p = [];
    for (const q of f) p.push([q[0], q[1]]);
    for (const q of f) p.push([W - q[0], H - q[1]]);
    p.push([W / 2, H / 2]);
    return p;
  }
  function init(players, opts) {
    const o = opts || {};
    const form = FORMS[o.form] ? o.form : '2-2';
    const k = Math.random() < 0.5 ? 0 : 1;
    return { nm: players.map((p) => String(p.name || '').slice(0, 10)), to: [3, 5].includes(+o.to) ? +o.to : 3, fm: form, ag: o.aim === 1 || o.aim === 'on' ? 1 : 0,
      p: kickoff(form), g: [0, 0], t: k, ko: 1, n: 0, ph: 'p', seq: 0, last: null };
  }
  function actor(s) { return s.ph === 'p' ? s.t : null; }
  function apply(s, seat, a) {
    if (s.ph !== 'p' || s.t !== seat) throw new Error('not your turn');
    if (!a || a.type !== 'flick') throw new Error('bad action');
    const di = a.i | 0, ang = +a.a, pw = +a.p;
    if (di < 0 || di > 4 || a.i !== di || !isFinite(ang) || !isFinite(pw) || pw <= 0) throw new Error('bad flick');
    const i = seat * 5 + di, v = U.clamp(pw, 0.03, 1) * VMAX;
    const pre = s.p.map((q) => q.slice());
    const shot = { i, vx: r4(Math.cos(ang) * v), vy: r4(Math.sin(ang) * v) };
    const sm = simulate(pre, shot);
    s.seq++; s.n++;
    const g = sm.goal;
    s.last = { id: s.seq, s: seat, pre, shot, g };
    if (g >= 0) {
      s.g[g]++;
      if (s.g[g] >= s.to) { s.ph = 'e'; s.p = sm.pos(); return s; }
      s.p = kickoff(s.fm); s.t = 1 - g; s.ko = 1;     // the conceding team kicks off
    } else {
      s.p = sm.pos(); s.t = 1 - seat; s.ko = 0;
    }
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const w = s.g[0] > s.g[1] ? 0 : 1;
    return { winners: [w], text: (s.nm[0] || '1번') + ' ' + s.g[0] + ' : ' + s.g[1] + ' ' + (s.nm[1] || '2번') + '\n' + s.to + '골 선취' };
  }

  /* ---------- AI ---------- */
  const LVA = { 1: { n: 26, a: 0.06, p: 0.14, ms: 90 }, 2: { n: 90, a: 0.025, p: 0.07, ms: 150 }, 3: { n: 260, a: 0.01, p: 0.035, ms: 240 } };
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 0.5;
  const myGoalY = (t) => (t === 0 ? H : 0), oppGoalY = (t) => (t === 0 ? 0 : H);
  function evalPos(p, t, goal) {
    if (goal === t) return 1000;
    if (goal === 1 - t) return -1000;
    const b = p[BALL], gy = oppGoalY(t), my = myGoalY(t);
    const dOpp = Math.hypot(b[0] - W / 2, b[1] - gy), dMy = Math.hypot(b[0] - W / 2, b[1] - my);
    let v = (dMy - dOpp) * 0.6;
    // threat: an opponent disc sitting behind the ball (relative to my goal) with a clear-ish line
    const tx = W / 2 - b[0], ty = my - b[1], tl = Math.hypot(tx, ty) || 1, ux = tx / tl, uy = ty / tl;
    for (let k = 0; k < 5; k++) {
      const q = p[(1 - t) * 5 + k], ex = b[0] - q[0], ey = b[1] - q[1], d = Math.hypot(ex, ey);
      if (d > 40) continue;
      const al = (ex * ux + ey * uy) / (d || 1);
      if (al > 0.6) v -= (40 - d) * 0.9 * (al - 0.4) * (tl < 55 ? 1.6 : 1);
    }
    // my chance next turn: my disc behind the ball toward their goal
    const sx = W / 2 - b[0], sy = gy - b[1], sl = Math.hypot(sx, sy) || 1, vx = sx / sl, vy = sy / sl;
    let best = 0;
    for (let k = 0; k < 5; k++) {
      const q = p[t * 5 + k], ex = b[0] - q[0], ey = b[1] - q[1], d = Math.hypot(ex, ey);
      if (d > 40) continue;
      const al = (ex * vx + ey * vy) / (d || 1);
      if (al > 0.6) best = Math.max(best, (40 - d) * (al - 0.4) * (sl < 55 ? 1.4 : 0.8));
    }
    v += best * 0.5;
    // defenders between the ball and my goal mouth
    for (let k = 0; k < 5; k++) {
      const q = p[t * 5 + k];
      const along = (q[0] - b[0]) * ux + (q[1] - b[1]) * uy, off = Math.abs((q[0] - b[0]) * uy - (q[1] - b[1]) * ux);
      if (along > 0 && along < tl && off < 7) { v += 6; break; }
    }
    // keeper near the goal mouth
    const gk = p[t * 5];
    v -= Math.hypot(gk[0] - W / 2, gk[1] - (t === 0 ? H - 5 : 5)) * 0.15;
    return v;
  }
  function candidates(s, t) {
    const p = s.p, b = p[BALL], out = [];
    const gy = oppGoalY(t);
    const targets = [[W / 2, gy], [W / 2 - 5.5, gy], [W / 2 + 5.5, gy], [W / 2 - 12, gy + (t === 0 ? 24 : -24)], [W / 2 + 12, gy + (t === 0 ? 24 : -24)], [2, b[1] + (t === 0 ? -30 : 30)], [W - 2, b[1] + (t === 0 ? -30 : 30)], [b[0], gy]];
    for (let k = 0; k < 5; k++) {
      const q = p[t * 5 + k];
      for (const tg of targets) {
        const dx = tg[0] - b[0], dy = tg[1] - b[1], l = Math.hypot(dx, dy) || 1;
        const cx = b[0] - dx / l * (RD + RB), cy = b[1] - dy / l * (RD + RB);
        const ang = Math.atan2(cy - q[1], cx - q[0]), dist = Math.hypot(cx - q[0], cy - q[1]);
        const need = Math.sqrt(2 * FR.d[0] * dist + 900) / VMAX;
        for (const m of [1.15, 1.6, 2.4, 5]) out.push({ i: k, a: ang, p: U.clamp(need * m, 0.12, 1) });
      }
      // positional moves: drop back toward goal / block the line
      const my = myGoalY(t), bx = (b[0] + W / 2) / 2, by = (b[1] + my) / 2;
      const ang = Math.atan2(by - q[1], bx - q[0]), dist = Math.hypot(bx - q[0], by - q[1]);
      out.push({ i: k, a: ang, p: U.clamp(Math.sqrt(2 * FR.d[0] * dist * 1.25) / VMAX, 0.05, 1) });
    }
    for (let k = 0; k < 12; k++) out.push({ i: U.rand(5), a: Math.random() * Math.PI * 2, p: 0.2 + Math.random() * 0.8 });
    return out;
  }
  function ai(s, seat, lv) {
    const P = LVA[lv] || LVA[2], t = seat, t0 = Date.now();
    let cs = candidates(s, t);
    if (cs.length > P.n) cs = U.shuffle(cs).slice(0, P.n);
    const ev = (c, da, dp) => {
      const i = t * 5 + c.i, v = U.clamp(c.p + dp, 0.03, 1) * VMAX, a = c.a + da;
      const sm = simulate(s.p, { i, vx: Math.cos(a) * v, vy: Math.sin(a) * v });
      return evalPos(sm.goal >= 0 ? kickoff(s.fm) : sm.pos(), t, sm.goal);
    };
    const sc = [];
    for (const c of cs) { if (Date.now() - t0 > P.ms && sc.length > 6) break; sc.push({ c, v: ev(c, 0, 0) }); }
    sc.sort((a, b) => b.v - a.v);
    let pick = sc[0];
    if (lv >= 3) {
      let best = null;
      for (const z of sc.slice(0, 6)) {
        if (Date.now() - t0 > P.ms + 50) break;
        const r = (z.v * 2 + ev(z.c, P.a * 1.5, 0) + ev(z.c, -P.a * 1.5, 0)) / 4;
        if (!best || r > best.v) best = { c: z.c, v: r };
      }
      if (best) pick = best;
    } else if (lv <= 1 && sc.length > 3 && Math.random() < 0.3) pick = sc[1 + U.rand(Math.min(5, sc.length - 1))];
    const c = pick.c;
    return { type: 'flick', i: c.i, a: c.a + gauss() * P.a, p: U.clamp(c.p * (1 + gauss() * P.p), 0.05, 1) };
  }

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, sim = null, simAcc = 0, animLast = null, shownKey = '', dirty = true;
    let finTimer = 0, animTimer = 0, sentAt = 0, flash = null, lastHits = 0, lastRails = 0, sel = {}, drag = null, lastTick = -1, wasCancel = true, snapT = 0;
    let G = { k: 4, ox: 0, oy: 0 }, grass = null, fast = false;
    const top = L.h('div', { class: 'hud top fs-top', style: { padding: '6px 8px 0' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px' } });
    root.append(top, bot);
    // invisible boxes over my disc / the ball / the goal I attack for the first-play tutorial spotlight
    const spDisc = tutSpot(root, 'fs-disc'), spBall = tutSpot(root, 'fs-ball'), spGoal = tutSpot(root, 'fs-goal');
    const tutTick = tutCatchUp(root, api, 'fingersoccer', ['.fs-disc']);
    const color = (i) => (api.players[i] ? api.players[i].color : '#fff');
    const nameOf = (i) => (api.players[i] ? api.players[i].name : '');

    function layout() {
      const th = top.getBoundingClientRect().height || 50, bh = bot.getBoundingClientRect().height || 50;
      const y0 = th + 8, y1 = cv.h - bh - 8, M = 4;
      const k = Math.max(1, Math.min((cv.w - 24) / (W + M * 2), (y1 - y0) / (H + 2 * GD + M * 2)));
      G = { k, ox: (cv.w - W * k) / 2, oy: (y0 + y1) / 2 - H * k / 2 };
      dirty = true;
    }
    cv.onresize = layout;
    const TX = (x) => G.ox + x * G.k, TY = (y) => G.oy + y * G.k;

    function makeGrass() {
      const c = document.createElement('canvas'); c.width = 64; c.height = 64;
      const g = c.getContext('2d'), im = g.createImageData(64, 64);
      for (let i = 0; i < im.data.length; i += 4) { const n = Math.random(); const v = n < 0.5 ? 0 : 255; im.data[i] = v; im.data[i + 1] = v; im.data[i + 2] = v; im.data[i + 3] = Math.floor(Math.abs(n - 0.5) * 26); }
      g.putImageData(im, 0, 0);
      return ctx.createPattern(c, 'repeat');
    }
    function drawPitch() {
      const k = G.k;
      ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, cv.w, cv.h);
      // wood frame
      const fx = TX(0) - 9, fy = TY(-GD) - 9, fw = W * k + 18, fh = (H + 2 * GD) * k + 18;
      ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fillRect(fx + 3, fy + 6, fw, fh);
      const wg = ctx.createLinearGradient(fx, 0, fx + fw, 0);
      wg.addColorStop(0, '#6b3d1d'); wg.addColorStop(0.5, '#9a5e31'); wg.addColorStop(1, '#6b3d1d');
      ctx.fillStyle = wg; ctx.fillRect(fx, fy, fw, fh);
      // felt pitch with mowing stripes
      ctx.fillStyle = '#1c6650'; ctx.fillRect(TX(0), TY(-GD), W * k, (H + 2 * GD) * k);
      for (let i = 0; i < 10; i++) { ctx.fillStyle = i % 2 ? '#1f6e56' : '#1a5f4a'; ctx.fillRect(TX(0), TY(i * H / 10), W * k, H / 10 * k + 0.5); }
      if (!grass) grass = makeGrass();
      ctx.fillStyle = grass; ctx.fillRect(TX(0), TY(-GD), W * k, (H + 2 * GD) * k);
      // behind the goal lines: dark
      ctx.fillStyle = '#123f33'; ctx.fillRect(TX(0), TY(-GD), W * k, GD * k); ctx.fillRect(TX(0), TY(H), W * k, GD * k);
      // markings
      ctx.strokeStyle = 'rgba(242,233,216,.8)'; ctx.lineWidth = Math.max(1.5, 0.35 * k);
      ctx.strokeRect(TX(0), TY(0), W * k, H * k);
      ctx.beginPath(); ctx.moveTo(TX(0), TY(H / 2)); ctx.lineTo(TX(W), TY(H / 2)); ctx.stroke();
      ctx.beginPath(); ctx.arc(TX(W / 2), TY(H / 2), CC * k, 0, 7); ctx.stroke();
      ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.beginPath(); ctx.arc(TX(W / 2), TY(H / 2), 0.6 * k, 0, 7); ctx.fill();
      for (const s of [-1, 1]) {
        const y0 = s < 0 ? 0 : H;
        ctx.strokeRect(TX(W / 2 - 20), TY(y0) + (s < 0 ? 0 : -16 * k), 40 * k, 16 * k);
        ctx.strokeRect(TX(W / 2 - 11), TY(y0) + (s < 0 ? 0 : -6 * k), 22 * k, 6 * k);
        ctx.beginPath(); ctx.arc(TX(W / 2), TY(y0 - s * 11), 0.5 * k, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.arc(TX(W / 2), TY(y0 - s * 11), 8 * k, s < 0 ? 0.2 * Math.PI : 1.2 * Math.PI, s < 0 ? 0.8 * Math.PI : 1.8 * Math.PI); ctx.stroke();
      }
      // goals: net + frame
      for (const s of [-1, 1]) {
        const y0 = s < 0 ? 0 : H, yb = y0 + s * GD, t = s < 0 ? 0 : 1, col = color(1 - t);
        ctx.fillStyle = 'rgba(10,8,15,.55)'; ctx.fillRect(TX(GX0), Math.min(TY(y0), TY(yb)), (GX1 - GX0) * k, GD * k);
        ctx.strokeStyle = 'rgba(242,233,216,.28)'; ctx.lineWidth = 1;
        for (let x = GX0 + 1.5; x < GX1; x += 1.5) { ctx.beginPath(); ctx.moveTo(TX(x), TY(y0)); ctx.lineTo(TX(x), TY(yb)); ctx.stroke(); }
        for (let d = 1.5; d < GD; d += 1.5) { ctx.beginPath(); ctx.moveTo(TX(GX0), TY(y0 + s * d)); ctx.lineTo(TX(GX1), TY(y0 + s * d)); ctx.stroke(); }
        ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = Math.max(2, 1.1 * k); ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(TX(GX0), TY(y0)); ctx.lineTo(TX(GX0), TY(yb)); ctx.lineTo(TX(GX1), TY(yb)); ctx.lineTo(TX(GX1), TY(y0)); ctx.stroke();
        ctx.fillStyle = col; ctx.globalAlpha = 0.9;
        for (const x of [GX0, GX1]) { ctx.beginPath(); ctx.arc(TX(x), TY(y0), 0.75 * k + 1, 0, 7); ctx.fill(); }
        ctx.globalAlpha = 1;
      }
    }
    function shade(hex, f) {
      const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
      if (f > 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
      return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
    }
    function drawDisc(x, y, t, num, alpha, hl) {
      const k = G.k, px = TX(x), py = TY(y), r = RD * k, col = color(t);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(px + r * 0.12, py + r * 0.28, r * 1.02, r * 0.95, 0, 0, 7); ctx.fill();
      ctx.fillStyle = shade(col, -0.45); ctx.beginPath(); ctx.arc(px, py + r * 0.12, r, 0, 7); ctx.fill();
      const g = ctx.createRadialGradient(px - r * 0.35, py - r * 0.4, r * 0.1, px, py, r);
      g.addColorStop(0, shade(col, 0.35)); g.addColorStop(0.7, col); g.addColorStop(1, shade(col, -0.25));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.45)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(px, py, r * 0.72, 0, 7); ctx.stroke();
      ctx.fillStyle = 'rgba(23,19,31,.85)'; ctx.font = '700 ' + Math.round(r * 0.95) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(num === 0 ? 'G' : String(num), px, py + 0.5);
      if (hl) { ctx.strokeStyle = hl; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(px, py, r + 4, 0, 7); ctx.stroke(); }
      ctx.globalAlpha = 1;
    }
    function drawBall(x, y, roll, alpha) {
      const k = G.k, px = TX(x), py = TY(y), r = RB * k;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(px + r * 0.2, py + r * 0.35, r, r * 0.85, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#f7f1e3'; ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill();
      ctx.save(); ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.clip();
      ctx.fillStyle = '#2a2430';
      for (let i = 0; i < 5; i++) { const a = roll + i * 1.2566; ctx.beginPath(); ctx.arc(px + Math.cos(a) * r * 0.62, py + Math.sin(a) * r * 0.62, r * 0.26, 0, 7); ctx.fill(); }
      ctx.beginPath(); ctx.arc(px, py, r * 0.24, 0, 7); ctx.fill();
      ctx.restore();
      const g = ctx.createRadialGradient(px - r * 0.35, py - r * 0.4, 0, px, py, r);
      g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(0.5, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,.3)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill();
      ctx.globalAlpha = 1;
    }
    let roll = 0;
    const CANCEL = 18;
    /* distance from (x, y) (canvas px) along unit (ux, uy) to the edge of the phone screen — the finger can keep pulling
       over the HUD bars and the app header, but not past the glass */
    function screenRoom(x, y, ux, uy) {
      const r = cv.cv.getBoundingClientRect(), x0 = -r.left, y0 = -r.top, x1 = (window.innerWidth || cv.w) - r.left, y1 = (window.innerHeight || cv.h) - r.top;
      let t = 1e9;
      if (ux > 1e-6) t = Math.min(t, (x1 - x) / ux); else if (ux < -1e-6) t = Math.min(t, (x0 - x) / ux);
      if (uy > 1e-6) t = Math.min(t, (y1 - y) / uy); else if (uy < -1e-6) t = Math.min(t, (y0 - y) / uy);
      return Math.max(0, t);
    }
    function aimInfo() {
      if (!drag || !drag.vec) return null;
      const l = Math.hypot(drag.vec[0], drag.vec[1]);
      // full power needs ~h·0.2 of pull; a disc near the screen edge shrinks the scale so 100% comes just before the edge
      let maxPx = Math.min(150, Math.max(100, cv.h * 0.2));
      if (l > 1) maxPx = U.clamp(screenRoom(drag.ox, drag.oy, drag.vec[0] / l, drag.vec[1] / l) - CANCEL, 56, maxPx);
      if (l < CANCEL) return { cancel: true };
      return { ang: Math.atan2(-drag.vec[1], -drag.vec[0]), p: Math.round(Math.min(1, (l - CANCEL + 4) / maxPx) * 100) / 100 };
    }
    function placeSpots(a, mine) {
      const k = G.k, me = api.mySeats ? api.mySeats() : [], t = me.length ? me[0] : 0;
      const gy = t === 0 ? TY(-GD) : TY(H);   // seat 0 (bottom) attacks the top goal
      spGoal(TX(GX0) - 8, gy - 6, (GX1 - GX0) * k + 16, GD * k + 12);
      if (sim) { spBall(null); spDisc(null); return; }
      const b = st.p[BALL];
      spBall(TX(b[0]) - RB * k - 12, TY(b[1]) - RB * k - 12, RB * k * 2 + 24, RB * k * 2 + 24);
      if (mine) {
        let j = sel[a];   // nothing picked yet: point at my disc nearest the ball
        if (j == null) { let bd = 1e9; for (let i = 0; i < 5; i++) { const q = st.p[a * 5 + i], d = Math.hypot(q[0] - b[0], q[1] - b[1]); if (d < bd) { bd = d; j = i; } } }
        const q = st.p[a * 5 + j], r = RD * k + 12; spDisc(TX(q[0]) - r, TY(q[1]) - r, 2 * r, 2 * r);
      } else spDisc(null);
    }
    function draw(now) {
      cv.clear();
      if (!st) return;
      drawPitch();
      const pos = sim ? null : st.p;
      const a = actor(st), mine = !sim && a != null && api.canAct(a) && !waitingNet();
      for (let i = 0; i < 10; i++) {
        const t = i < 5 ? 0 : 1, x = sim ? sim.x[i] : pos[i][0], y = sim ? sim.y[i] : pos[i][1];
        let hl = null;
        if (mine && t === a) hl = sel[a] === i % 5 ? '#e3ae45' : 'rgba(242,233,216,.35)';
        if (sim && i === animLast.shot.i) hl = 'rgba(242,233,216,.7)';
        drawDisc(x, y, t, i % 5, 1, hl);
      }
      drawBall(sim ? sim.x[BALL] : pos[BALL][0], sim ? sim.y[BALL] : pos[BALL][1], roll, 1);
      placeSpots(a, mine);
      // aim
      if (mine && sel[a] != null) {
        const q = st.p[a * 5 + sel[a]], px = TX(q[0]), py = TY(q[1]), r = RD * G.k;
        const info = aimInfo();
        if (drag) {
          ctx.strokeStyle = info && info.cancel ? 'rgba(238,106,85,.9)' : 'rgba(242,233,216,.35)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 4]);
          ctx.beginPath(); ctx.arc(px, py, Math.max(CANCEL, r + 2), 0, 7); ctx.stroke(); ctx.setLineDash([]);
        }
        if (info && !info.cancel) {
          const dx = Math.cos(info.ang), dy = Math.sin(info.ang), len = r + 14 + info.p * 70;
          if (st.ag) drawGuide(a * 5 + sel[a], dx, dy);
          // pull band
          ctx.strokeStyle = 'rgba(23,19,31,.55)'; ctx.lineWidth = 3; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + drag.vec[0], py + drag.vec[1]); ctx.stroke();
          // direction arrow (initial direction only)
          const ex = px + dx * len, ey = py + dy * len;
          ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 3;
          ctx.beginPath(); ctx.moveTo(px + dx * (r + 5), py + dy * (r + 5)); ctx.lineTo(ex, ey); ctx.stroke();
          ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(ex + dx * 9, ey + dy * 9); ctx.lineTo(ex - dy * 7, ey + dx * 7); ctx.lineTo(ex + dy * 7, ey - dx * 7); ctx.closePath(); ctx.fill();
          // power ring
          const rr = r + 10;
          ctx.lineWidth = 6; ctx.lineCap = 'butt';
          ctx.strokeStyle = 'rgba(23,19,31,.6)'; ctx.beginPath(); ctx.arc(px, py, rr, 0, 7); ctx.stroke();
          ctx.strokeStyle = info.p < 0.45 ? '#5fd3a0' : info.p < 0.8 ? '#e3ae45' : '#ee6a55';
          ctx.beginPath(); ctx.arc(px, py, rr, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * info.p); ctx.stroke();
          readout(Math.round(info.p * 100) + '%', '#f2e9d8', py);
        } else if (info && info.cancel && drag.started) readout('놓으면 취소', '#ee6a55', py);
      }
      if (flash) {
        const k = U.clamp((now - flash.t0) / 1300, 0, 1);
        if (k >= 1) flash = null;
        else {
          ctx.globalAlpha = k < 0.12 ? k / 0.12 : 1 - Math.max(0, (k - 0.65) / 0.35);
          const s = 1 + (1 - k) * 0.2;
          ctx.font = '400 ' + Math.round(46 * s) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 7; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, cv.w / 2, TY(H / 2));
          ctx.fillStyle = flash.c; ctx.fillText(flash.text, cv.w / 2, TY(H / 2));
          ctx.globalAlpha = 1;
        }
      }
    }
    /* straight aim line from the flicked disc to the first thing it would touch (no bounces, no power):
       ghost disc at the contact, and for the ball a short stub of the direction it gets knocked */
    function castRay(i, dx, dy) {
      const p = st.p, ox = p[i][0], oy = p[i][1];
      let tmin = 1e9, hit = -1;
      for (let j = 0; j < NB; j++) {
        if (j === i) continue;
        const rr = RD + rad(j), fx = ox - p[j][0], fy = oy - p[j][1];
        const b = fx * dx + fy * dy, c = fx * fx + fy * fy - rr * rr, disc = b * b - c;
        if (disc < 0) continue;
        const t = -b - Math.sqrt(disc);
        if (t > 0 && t < tmin) { tmin = t; hit = j; }
      }
      let tw = 1e9;
      if (dx > 1e-6) tw = Math.min(tw, (W - RD - ox) / dx); else if (dx < -1e-6) tw = Math.min(tw, (RD - ox) / dx);
      if (dy > 1e-6) tw = Math.min(tw, (H - RD - oy) / dy); else if (dy < -1e-6) tw = Math.min(tw, (RD - oy) / dy);
      if (tw < tmin) return { t: Math.max(0, tw), hit: -1, x: ox + dx * Math.max(0, tw), y: oy + dy * Math.max(0, tw) };
      return { t: tmin, hit, x: ox + dx * tmin, y: oy + dy * tmin };
    }
    function drawGuide(i, dx, dy) {
      const q = st.p[i], rc = castRay(i, dx, dy), k = G.k;
      if (rc.t < RD * 0.5) return;
      ctx.save(); ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(242,233,216,.7)'; ctx.lineWidth = 1.6; ctx.setLineDash([2, 6]);
      ctx.beginPath(); ctx.moveTo(TX(q[0] + dx * RD), TY(q[1] + dy * RD)); ctx.lineTo(TX(rc.x), TY(rc.y)); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = 'rgba(242,233,216,.8)'; ctx.lineWidth = 1.3; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.arc(TX(rc.x), TY(rc.y), RD * k, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      if (rc.hit === BALL) {
        const b = st.p[BALL]; let nx = b[0] - rc.x, ny = b[1] - rc.y; const l = Math.hypot(nx, ny) || 1; nx /= l; ny /= l;
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(TX(b[0] + nx * RB), TY(b[1] + ny * RB)); ctx.lineTo(TX(b[0] + nx * 11), TY(b[1] + ny * 11)); ctx.stroke();
      } else if (rc.hit >= 0) {
        const o = st.p[rc.hit];
        ctx.strokeStyle = 'rgba(242,233,216,.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(TX(o[0]), TY(o[1]), RD * k + 3, 0, 7); ctx.stroke();
      }
      ctx.restore();
    }
    function readout(text, c, fingerY) {
      const by = fingerY > cv.h / 2 ? TY(H * 0.18) : TY(H * 0.82), bx = cv.w / 2;
      ctx.fillStyle = 'rgba(23,19,31,.7)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx - 60, by - 17, 120, 34, 12) : ctx.rect(bx - 60, by - 17, 120, 34); ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = c; ctx.font = text.length > 5 ? '700 15px "IBM Plex Sans KR", sans-serif' : '700 22px "IBM Plex Mono", monospace';
      ctx.fillText(text, bx, by + 1);
    }

    /* ---- HUD ---- */
    let topKey = '', botKey = '';
    function renderTop() {
      if (!st) return;
      const g = sim && animLast.g >= 0 && !animDone ? st.g.map((v, i) => (i === animLast.g ? v - 1 : v)) : st.g;
      const cur = sim ? animLast.s : actor(st);
      const key = JSON.stringify([g, cur, st.ph]);
      if (key === topKey) return;
      topKey = key; top.innerHTML = '';
      const side = (t) => L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0, flex: '1 1 0', justifyContent: t ? 'flex-start' : 'flex-end', opacity: cur === t || st.ph === 'e' ? 1 : 0.7 } },
        t ? L.h('span', { class: 'mono', style: { fontSize: '24px', fontWeight: 700, color: 'var(--ink)' }, text: String(g[t]) }) : null,
        L.h('span', { class: 'dot', style: { '--c': color(t), flex: 'none', boxShadow: cur === t ? '0 0 0 3px color-mix(in srgb,' + color(t) + ' 35%, transparent)' : 'none' } }),
        L.h('span', { style: { fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0 }, text: nameOf(t) }),
        !t ? L.h('span', { class: 'mono', style: { fontSize: '24px', fontWeight: 700, color: 'var(--ink)' }, text: String(g[t]) }) : null);
      top.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '5px 10px', width: '100%' } },
        side(0), L.h('span', { class: 'muted', style: { fontSize: '11px', flex: 'none', textAlign: 'center', lineHeight: 1.1 }, html: st.to + '골<br>선취' }), side(1)));
      layout();
    }
    function renderBot() {
      if (!st) return;
      const a = sim ? animLast.s : actor(st), mine = !sim && st.ph === 'p' && a != null && api.canAct(a) && !waitingNet();
      const key = [a, mine, !!sim, fast, st.ph, st.ko, sel[a]].join('|');
      if (key === botKey) return;
      botKey = key; bot.innerHTML = '';
      if (st.ph === 'e' || a == null) { layout(); return; }
      const dir = a === 0 ? '↑ 위쪽 골' : '↓ 아래쪽 골';
      const msg = sim ? (fast ? '빨리 감는 중…' : '굴러가는 중… · 화면을 누르면 빨리 감기') : mine ? (sel[a] == null ? '내 디스크를 누르고 뒤로 끌었다 놓기' : '뒤로 끌었다 놓기 · 빈 곳에서 끌어도 돼요') : api.players[a].ai ? '생각 중…' : '차례';
      bot.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 10px', minWidth: 0, width: '100%', minHeight: '44px' } },
        L.h('span', { class: 'dot', style: { '--c': color(a), flex: 'none' } }),
        L.h('div', { style: { display: 'flex', flexDirection: 'column', minWidth: 0, gap: '1px' } },
          L.h('span', { style: { fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }, nameOf(a), L.h('span', { class: 'muted', style: { fontWeight: 500, fontSize: '11px', marginLeft: '6px' }, text: dir + (st.ko && !sim ? ' · 킥오프' : '') })),
          L.h('span', { class: 'muted', style: { fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: msg }))));
      layout();
    }

    /* ---- input ---- */
    function waitingNet() { return sentAt && performance.now() - sentAt < 6000; }
    function canHuman() { return st && !sim && st.ph === 'p' && api.canAct(actor(st)) && !waitingNet(); }
    function pickDisc(p, a) {
      let best = -1, bd = 1e9;
      for (let k = 0; k < 5; k++) { const q = st.p[a * 5 + k], d = Math.hypot(TX(q[0]) - p.x, TY(q[1]) - p.y); if (d < bd) { bd = d; best = k; } }
      return bd < Math.max(30, RD * G.k + 16) ? best : -1;
    }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (sim && !fast) { fast = true; renderBot(true); return; } // tap while the discs roll: fast-forward
      if (!canHuman() || drag) return;
      const a = actor(st), p = cv.local(ev);
      const k = pickDisc(p, a);
      if (k >= 0) { if (sel[a] !== k) { sel[a] = k; api.sfx('tick'); } }
      else if (sel[a] == null) return;
      const q = st.p[a * 5 + sel[a]];
      drag = { id: ev.pointerId, ox: TX(q[0]), oy: TY(q[1]), vec: [p.x - TX(q[0]), p.y - TY(q[1])], started: false, free: k < 0 };
      if (drag.free) { drag.ox = p.x; drag.oy = p.y; drag.vec = [0, 0]; }
      lastTick = -1; wasCancel = true;
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      api.buzz(8); renderBot(); dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const p = cv.local(ev);
      drag.vec = [p.x - drag.ox, p.y - drag.oy];
      if (Math.hypot(drag.vec[0], drag.vec[1]) > CANCEL + 4) drag.started = true;
      const info = aimInfo();
      if (info && drag.started) {
        if (!!info.cancel !== wasCancel) { wasCancel = !!info.cancel; api.buzz(info.cancel ? 20 : 8); }
        const tk = info.cancel ? -1 : Math.floor(info.p * 10);
        if (tk !== lastTick && tk >= 0) api.sfx('tick');
        lastTick = tk;
      }
      dirty = true;
    });
    cv.cv.addEventListener('pointerup', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const info = aimInfo(), d0 = drag; drag = null; dirty = true;
      if (!canHuman() || !info || !d0.started) return;
      if (info.cancel) { api.sfx('click'); api.toast('취소'); return; }
      const a = actor(st);
      api.sfx('hit'); api.buzz(15);
      if (!api.isHost) sentAt = performance.now();
      api.act({ type: 'flick', i: sel[a], a: info.ang, p: info.p });
    });
    cv.cv.addEventListener('pointercancel', (ev) => { if (drag && drag.id === ev.pointerId) { drag = null; dirty = true; } });

    /* ---- animation ---- */
    let animDone = false;
    function startAnim(last) {
      clearTimeout(finTimer); clearTimeout(animTimer);
      sim = new Sim(last.pre, last.shot); animLast = last; simAcc = 0; lastHits = 0; lastRails = 0; animDone = false; fast = false;
      api.setBusy(true);
      const mine = sim, dur = new Sim(last.pre, last.shot).run().steps * DT;
      animTimer = setTimeout(() => { if (sim === mine && !sim.done) { sim.run(); finishAnim(); } }, (dur / L.debug.speed) * 1000 + 3000);
      renderTop(); renderBot();
    }
    function finishAnim() {
      clearTimeout(animTimer);
      const l = animLast, s = sim;
      animDone = true;
      if (l.g >= 0) {
        const own = l.g !== l.s;
        flash = { text: own ? '자책골' : '골!', c: own ? '#ab9fb8' : color(l.g), t0: performance.now() };
        api.sfx(own ? 'lose' : 'win'); api.buzz(40);
        if (st.ph !== 'e') api.toast(nameOf(1 - l.g) + ' 킥오프');
      }
      renderTop();
      clearTimeout(finTimer);
      finTimer = setTimeout(() => {
        if (sim !== s) return;
        sim = null; animLast = null; snapT = performance.now();
        api.setBusy(false);
        renderTop(); renderBot(); dirty = true;
      }, (l.g >= 0 ? 1300 : 250) / L.debug.speed);
    }
    const stop = U.loop((dt, now) => {
      { const a = st ? actor(st) : null; tutTick(!!(st && !sim && a != null && api.canAct(a) && !waitingNet())); }
      if (sim) {
        if (!sim.done) {
          simAcc += dt * L.debug.speed * (fast ? 4 : 1);
          let n = 0;
          const bx = sim.x[BALL], by = sim.y[BALL];
          while (simAcc >= DT && !sim.done && n < 4000) { sim.step(); simAcc -= DT; n++; }
          roll += Math.hypot(sim.x[BALL] - bx, sim.y[BALL] - by) / RB * 0.5;
          if (sim.hits > lastHits) { lastHits = sim.hits; api.sfx(sim.hitV > 60 ? 'hit' : 'chip'); api.buzz(sim.hitV > 60 ? 18 : 8); sim.hitV = 0; }
          if (sim.rails > lastRails) { lastRails = sim.rails; api.sfx('bounce'); }
          if (sim.done) finishAnim();
        }
        dirty = true;
      }
      if (flash || drag) dirty = true;
      if (dirty) { dirty = false; draw(now); }
    });

    layout();
    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        const key = next.last ? next.last.id + ':' + next.last.shot.vx + ':' + next.last.shot.vy : '';
        if (next.last && key !== shownKey && prev && prev !== next) { shownKey = key; startAnim(next.last); }
        else shownKey = key;
        const a = actor(next);
        if (a != null && sel[a] != null && !next.p[a * 5 + sel[a]]) delete sel[a];
        renderTop(); renderBot(); dirty = true;
      },
      destroy() { stop(); clearTimeout(finTimer); clearTimeout(animTimer); cv.destroy(); top.remove(); bot.remove(); [spDisc, spBall, spGoal].forEach((f) => f.el.remove()); api.setBusy(false); },
    };
  }

  L.register({
    id: 'fingersoccer', name: '손가락 축구', tag: '플릭 축구', cat: '스포츠',
    blurb: '내 디스크 하나를 새총처럼 튕겨 공을 상대 골에 넣어요. 한 번 튕기면 차례가 넘어가고, 먼저 정한 골 수를 넣으면 승리.',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, hidden: false, aiDelay: 650,
    tint: '#1d5a3c',
    icon: '<rect x="6" y="8" width="44" height="40" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M6 28h44" stroke="currentColor" stroke-width="2"/><circle cx="28" cy="28" r="6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="18" cy="38" r="5" fill="currentColor"/><circle cx="38" cy="17" r="5" fill="currentColor" opacity=".55"/><circle cx="25" cy="31" r="2.6" fill="currentColor"/><path d="M14 43l-4 4" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    options: [
      { id: 'to', label: '승리 골', choices: [{ v: 3, label: '3골' }, { v: 5, label: '5골' }], def: 3 },
      { id: 'form', label: '포메이션', choices: [{ v: '2-2', label: '2-2' }, { v: '1-2-1', label: '1-2-1' }, { v: '3-1', label: '3-1' }], def: '2-2' },
      { id: 'aim', label: '조준선', choices: [{ v: 0, label: '끔' }, { v: 1, label: '켬' }], def: 0 },
    ],
    quick: [
      '2명이 번갈아 하는 판 축구예요. 먼저 정한 골 수(3골 또는 5골)를 넣으면 이겨요.',
      '내 차례: 내 디스크 하나를 누른 채 뒤로 끌었다 놓아 한 번 튕겨요(새총처럼).',
      '디스크로 공을 쳐서 상대 골에 넣어요. 모든 게 멈추면 상대 차례예요.',
    ],
    rules: [
      { h: '목표', p: ['2명이 번갈아 하는 턴제 축구예요. 팀마다 디스크 5개(G는 골키퍼)와 공 1개로 해요.',
        '아래 팀(1번 자리)은 위쪽 골, 위 팀(2번 자리)은 아래쪽 골에 넣어야 해요.',
        '먼저 정한 골 수(3골·5골)를 넣으면 이겨요.'] },
      { h: '차례에 할 일', p: ['① 내 디스크 하나를 골라 한 번 튕겨요. (공을 직접 튕길 수는 없어요. 디스크로 공을 쳐야 해요.)',
        '② 모든 디스크와 공이 멈추면 상대 차례예요.',
        '③ 골이 나면 모두 포메이션 자리로 돌아가고, 실점한 팀이 킥오프(먼저 튕기기)를 해요. 첫 킥오프는 무작위예요.'] },
      { h: '조작 (손가락)', p: ['① 내 디스크를 누르세요. 고른 디스크에 노란 테가 생겨요. 다른 내 디스크를 누르면 바꿀 수 있어요.',
        '② 누른 채로 가고 싶은 방향의 반대쪽으로 끄세요. 새총과 같아요: 아래로 끌면 위로 날아가요.',
        '③ 많이 끌수록 세요. 디스크 둘레의 링과 화면의 %가 세기, 흰 화살표가 처음 나가는 방향이에요.',
        '④ 손가락을 떼면 튕겨요. 디스크 위(점선 원 안)로 되돌아와 떼면 취소예요.',
        '디스크에서 먼 빈 곳을 눌러 끌어도 고른 디스크가 튕겨져요. 디스크가 화면 가장자리에 붙어 있어도 괜찮아요: 화면 끝까지 끌면 100%가 되도록 눈금이 저절로 맞춰지고, 넉넉하게 끌고 싶으면 가운데 빈 곳을 눌러 끌면 돼요.',
        '조준선은 기본으로 안 보여요. 설정의 「조준선」 옵션을 켜면 디스크가 처음 닿는 곳까지 점선이 이어지고(흰 점선 원 = 닿는 자리), 공에 닿으면 공이 튕겨 나갈 방향이 노란 선으로 짧게 보여요. 그 뒤의 경로는 안 보여 줘요.',
        '디스크가 굴러가는 동안 화면을 누르면 빨리 감기. 두 사람이 폰 하나를 번갈아 잡고 해도 돼요.'] },
      { h: '점수·승리', p: ['공 전체가 골대 사이의 골라인을 완전히 넘어야 골이에요. 걸쳐 있으면 아직 골이 아니에요.',
        '자기 골에 들어가도 상대 득점(자책골)이에요.',
        '먼저 정한 골 수를 넣은 사람이 이겨요.'] },
      { h: '특수 규칙', p: ['골 안에서 멈춘 디스크는 골라인 바로 앞으로 돌아와요.',
        '포메이션(2-2 · 1-2-1 · 3-1)은 설정에서 골라요. 골이 날 때마다 이 자리로 돌아가요.'] },
      { h: '예시', p: ['내 3번 디스크를 공 바로 아래에서 위로 튕김 → 디스크가 공을 맞혀 공이 위쪽 골로 쭉 → 공 전체가 골라인을 넘음 → 골! 1:0.',
        '→ 실점한 상대가 킥오프를 해요.',
        '공을 세게 쳤는데 옆벽(레일)을 맞고 내 골 쪽으로 굴러 들어가면 자책골이라 상대 점수예요. 내 골 앞은 골키퍼(G)로 지키세요.'] },
      { h: '물리', p: ['공은 디스크보다 가벼워(약 1/3) 맞으면 빠르게 튀어 나가고, 디스크끼리는 묵직하게 부딪혀요.',
        '바닥 마찰로 점점 느려지고, 옆벽(레일)과 골대에 맞으면 튕겨 나와요. 골망에 들어간 공은 거의 튀지 않아요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 슛·패스·걷어내기 후보를 더 많이 시뮬레이션하고 더 정확하게 튕겨요.'] },
    ],
    tutorial: [
      { sel: '.fs-top', text: '2명이 번갈아 하는 판 축구예요. 먼저 정한 골 수(기본 3골)를 넣으면 이겨요. 위에 점수가 나와요.' },
      { sel: '.fs-goal', text: '내 팀(아래쪽)은 이 골에 넣어야 해요. 공 전체가 골라인을 넘으면 골! 내 골에 들어가면 상대 점수(자책골)예요.' },
      { sel: '.fs-disc', text: '내 차례엔 내 디스크 하나를 한 번 튕겨요. 디스크를 누르면 노란 테로 골라져요. 다른 내 디스크를 누르면 바꿔요.' },
      { sel: '.fs-disc', text: '튕기기: 디스크를 누른 채 가고 싶은 쪽의 반대로 끌었다 떼요(새총). 많이 끌수록 세요(%로 보여요). 디스크 위로 돌아와 떼면 취소!' },
      { sel: '.fs-ball', text: '공은 직접 못 튕겨요. 디스크로 공을 쳐서 골에 넣으세요. 공은 가벼워서 맞으면 쭉 튀어 나가요. 모두 멈추면 상대 차례예요.' },
      { text: '처음엔 조준선이 없어요. 어려우면 설정의 「조준선」 옵션을 켜 보세요(디스크가 처음 닿는 곳까지 점선). 그럼 킥오프!' },
    ],
    init, actor, apply, ai, result, mount,
    _sim: { Sim, simulate, kickoff, evalPos, W, H, GX0, GX1, RB, RD, BALL, FORMS },
  });
})();
