/* 폭탄 해체반 — asymmetric co-op (people only, one phone each: online / LAN room).
   One player (해체 담당) sees the bomb; everyone else reads the 해체 설명서 on their own phone and talks them
   through it. The host generates the bomb from a seed and validates every defuser action through apply()
   (strikes, solved modules). The countdown is host-authoritative: state carries t0/ts on the host clock,
   guests extrapolate from the moment they received the state. Roles rotate every round. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const clock = { now: () => Date.now() };

  /* ======================= tables (original design) ======================= */
  const WC = 'RBYKW';
  const WNAME = { R: '빨강', B: '파랑', Y: '노랑', K: '검정', W: '흰색' };
  const WCOL = { R: '#d8432f', B: '#2f6fd6', Y: '#f0c419', K: '#1d1a1f', W: '#eeeae2' };
  const LAMPS = ['전원', '냉각', '통신', '경보', '예비'];
  const SER_L = 'ABCDEFGHJKLMNPQRSTUVWXZ', SER_A = SER_L + '0123456789';
  const VOW = 'AEIOU';
  const BTN_C = 'RBYW', BTN_L = ['발사', '정지', '해제', '대기'];
  const STRIP_D = { R: 3, B: 5, Y: 0, W: 7 };
  const KINDS = ['w', 'b', 's', 'p', 'm', 'o', 'v', 'n'];
  const KNAME = { w: '전선 자르기', b: '큰 버튼', s: '기호 순서', p: '비밀번호 다이얼', m: '미로', o: '모스 신호', v: '계기판 밸브', n: '숫자 기억' };
  const DIFF = { 1: { n: 4, name: '쉬움' }, 2: { n: 5, name: '보통' }, 3: { n: 6, name: '어려움' } };
  const WORDS = ['고양이', '무지개', '도서관', '비행기', '자전거', '바나나', '냉장고', '소방차', '운동장', '오징어', '거북이', '다람쥐', '코끼리', '원숭이', '피아노', '지우개', '사다리', '주전자', '선풍기', '우체국', '컴퓨터', '호랑이', '부엉이', '앵무새', '눈사람', '고구마', '옥수수', '비빔밥', '떡볶이', '망원경', '나침반'];
  const MORSE = { A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..' };
  const MWORDS = ['BEAN', 'BEAM', 'CAKE', 'DUSK', 'FERN', 'GLOW', 'HAZE', 'JADE', 'LIME', 'LAMP', 'MIST', 'MINT'];
  const FREQS = ['60.15', '60.40', '60.85', '61.10', '61.45', '61.90', '62.20', '62.55', '62.80', '63.25', '63.60', '63.95'];
  const MFREQ = [7, 2, 10, 0, 5, 11, 3, 8, 1, 9, 4, 6]; // word i → FREQS index
  const FACE = [{ n: '흰색', c: '#eeeae2', base: 0 }, { n: '노랑', c: '#f0c419', base: 2 }, { n: '검정', c: '#24212a', base: 4 }];
  const MZ = 6, NGLY = 24;

  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const ri = (r, n) => Math.floor(r() * n);
  function shuf(r, a) { for (let i = a.length - 1; i > 0; i--) { const j = ri(r, i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; }

  /* symbol columns: 5 columns × 7 glyphs, fixed for everyone */
  const COLS = (() => { const r = prng(4242), out = []; for (let c = 0; c < 5; c++) out.push(shuf(r, Array.from({ length: NGLY }, (_, i) => i)).slice(0, 7)); return out; })();
  /* mazes: 6 fixed 6×6 perfect mazes; cell bits N1 E2 S4 W8 = open */
  const MKR = [[1, 23], [10, 24], [14, 33], [5, 19], [28, 8], [30, 17]];
  const MAZES = (() => {
    const out = [];
    for (let z = 0; z < 6; z++) {
      const r = prng(1000 + z * 77), cells = Array(MZ * MZ).fill(0), seen = Array(MZ * MZ).fill(false), stack = [0];
      seen[0] = true;
      while (stack.length) {
        const c = stack[stack.length - 1], x = c % MZ, y = (c / MZ) | 0, nb = [];
        if (y > 0 && !seen[c - MZ]) nb.push([c - MZ, 1, 4]);
        if (x < MZ - 1 && !seen[c + 1]) nb.push([c + 1, 2, 8]);
        if (y < MZ - 1 && !seen[c + MZ]) nb.push([c + MZ, 4, 1]);
        if (x > 0 && !seen[c - 1]) nb.push([c - 1, 8, 2]);
        if (!nb.length) { stack.pop(); continue; }
        const [n, b1, b2] = nb[ri(r, nb.length)];
        cells[c] |= b1; cells[n] |= b2; seen[n] = true; stack.push(n);
      }
      // a couple of extra openings so there is more than one way round
      for (let k = 0; k < 3; k++) { const c = ri(r, MZ * (MZ - 1)); if (!(cells[c] & 4)) { cells[c] |= 4; cells[c + MZ] |= 1; } }
      out.push(cells);
    }
    return out;
  })();
  const DIRS = [[0, -1, 1], [1, 0, 2], [0, 1, 4], [-1, 0, 8]]; // up right down left
  function mzDist(z, a, b) {
    const d = Array(MZ * MZ).fill(-1), q = [a]; d[a] = 0;
    while (q.length) { const c = q.shift(); if (c === b) return d[c]; for (const [dx, dy, bit] of DIRS) { if (!(MAZES[z][c] & bit)) continue; const n = c + dx + dy * MZ; if (d[n] < 0) { d[n] = d[c] + 1; q.push(n); } } }
    return -1;
  }
  function mzPath(z, a, b) { // list of directions from a to b (for tests / solver)
    const prev = Array(MZ * MZ).fill(-2), q = [a]; prev[a] = -1;
    while (q.length) { const c = q.shift(); if (c === b) break; DIRS.forEach(([dx, dy, bit], di) => { if (!(MAZES[z][c] & bit)) return; const n = c + dx + dy * MZ; if (prev[n] === -2) { prev[n] = c * 4 + di; q.push(n); } }); }
    const out = []; let c = b;
    while (c !== a) { const p = prev[c]; out.unshift(p & 3); c = p >> 2; }
    return out;
  }

  /* ======================= edgework & modules ======================= */
  const lastDigit = (e) => +e.s[5];
  const hasVowel = (e) => [...e.s].some((c) => VOW.includes(c));
  const lit = (e, name) => e.i.some((x) => LAMPS[x[0]] === name && x[1]);
  const litCount = (e) => e.i.filter((x) => x[1]).length;
  function genEdge(r) {
    let s;
    do { s = ''; for (let i = 0; i < 5; i++) s += SER_A[ri(r, SER_A.length)]; } while ((s.match(/[A-Z]/g) || []).length < 2);
    s += ri(r, 10);
    const ks = shuf(r, [0, 1, 2, 3, 4]).slice(0, 2).sort((a, b) => a - b);
    return { s, b: ri(r, 5), i: ks.map((k) => [k, r() < 0.5 ? 1 : 0]) };
  }
  function wireSol(c, e) {
    const n = c.length, cnt = (x) => c.split(x).length - 1;
    if (n === 3) { if (!cnt('K')) return 1; if (lastDigit(e) % 2 === 0) return c.indexOf('K'); return 2; }
    if (n === 4) { if (cnt('Y') === 1) return c.indexOf('Y'); if (e.b >= 2 && cnt('B')) return c.lastIndexOf('B'); if (c[0] === 'W') return 1; return 0; }
    if (n === 5) { if (!cnt('R') && lit(e, '경보')) return 3; for (const x of WC) if (cnt(x) >= 3) return c.lastIndexOf(x); if (c[4] === 'K') return 2; return 0; }
    if (!cnt('W')) return 2; if (hasVowel(e)) return c.indexOf('W'); if (cnt('B') > cnt('Y')) return 5; return 3;
  }
  /* big button: −1 = short press, otherwise the seconds digit to release on */
  function btnSol(m, e) {
    let tap;
    if (BTN_L[m.l] === '해제' && e.b >= 1) tap = true;
    else if (m.c === 'Y') tap = false;
    else if (m.c === 'R' && lastDigit(e) % 2 === 1) tap = true;
    else if (litCount(e) === 2) tap = true;
    else tap = false;
    return tap ? -1 : STRIP_D[m.s];
  }
  function symCol(y) { return COLS.findIndex((col) => y.every((g) => col.includes(g))); }
  function symOrder(y) { const col = COLS[symCol(y)]; return y.map((g, i) => i).sort((a, b) => col.indexOf(y[a]) - col.indexOf(y[b])); }
  function pwMatches(d) { return WORDS.map((w, i) => i).filter((i) => [...WORDS[i]].every((ch, k) => d[k].includes(ch))); }
  function valveSol(m, e) { return (FACE[m.f].base + e.b + (m.n >= 50 ? 1 : 0) + litCount(e)) % 5; }
  function memNew(r) {
    let d = '', l = '';
    for (let k = 0; k < 3; k++) { d += 1 + ri(r, 4); l += shuf(r, ['1', '2', '3', '4']).join(''); }
    return { d, l, s: 0, h: '' };
  }
  function memTarget(m) { // position index 0..3 to press at the current stage
    const st = m.s, d = +m.d[st], lab = m.l.slice(st * 4, st * 4 + 4);
    const P = (p) => p - 1, B = (x) => lab.indexOf(String(x)), hp = (k) => +m.h[k * 2], hl = (k) => +m.h[k * 2 + 1];
    if (st === 0) return [P(2), B(4), P(4), B(1)][d - 1];
    if (st === 1) return [B(hl(0)), P(1), P(hp(0)), B(2)][d - 1];
    return [P(hp(1)), B(hl(0)), B(3), P(3)][d - 1];
  }
  function genModule(k, r) {
    if (k === 'w') { const n = 3 + ri(r, 4); let c = ''; for (let i = 0; i < n; i++) c += WC[ri(r, 5)]; return { k, c, x: 0 }; }
    if (k === 'b') return { k, c: BTN_C[ri(r, 4)], l: ri(r, 4), s: BTN_C[ri(r, 4)] };
    if (k === 's') {
      for (;;) { const c = ri(r, 5), y = shuf(r, COLS[c].slice()).slice(0, 4); if (COLS.filter((col) => y.every((g) => col.includes(g))).length === 1) return { k, y, p: 0 }; }
    }
    if (k === 'p') {
      for (let tries = 0; ; tries++) {
        const w = ri(r, WORDS.length), d = [];
        for (let pos = 0; pos < 3; pos++) {
          const pool = shuf(r, [...new Set(WORDS.map((x) => x[pos]).filter((ch) => ch !== WORDS[w][pos]))]);
          d.push(shuf(r, [WORDS[w][pos]].concat(pool.slice(0, 4))).join(''));
        }
        const mt = pwMatches(d);
        if (mt.length === 1 && mt[0] === w) return { k, w, d };
      }
    }
    if (k === 'm') { const z = ri(r, 6); for (;;) { const p = ri(r, 36), g = ri(r, 36); if (p !== g && mzDist(z, p, g) >= 5 && !MKR[z].includes(p) && !MKR[z].includes(g)) return { k, z, p, g }; } }
    if (k === 'o') return { k, w: ri(r, MWORDS.length) };
    if (k === 'v') return { k, f: ri(r, 3), n: ri(r, 100) };
    return Object.assign({ k: 'n' }, memNew(r));
  }
  function genBomb(sd, dif) {
    const r = prng(sd), n = (DIFF[dif] || DIFF[2]).n;
    const kinds = shuf(r, KINDS.slice()).slice(0, n);
    return { e: genEdge(r), M: kinds.map((k) => genModule(k, r)) };
  }
  /* the correct next action for module m (tests / debugging; the view never uses it) */
  function solveStep(s, mi) {
    const m = s.M[mi], e = s.e;
    if (!m || m.ok) return null;
    if (m.k === 'w') return { t: 'cut', m: mi, i: wireSol(m.c, e) };
    if (m.k === 'b') { const d = btnSol(m, e); return d < 0 ? { t: 'tap', m: mi } : { t: 'rel', m: mi, digit: d }; }
    if (m.k === 's') return { t: 'sym', m: mi, i: symOrder(m.y)[m.p] };
    if (m.k === 'p') return { t: 'pw', m: mi, v: [...WORDS[m.w]].map((ch, k) => m.d[k].indexOf(ch)) };
    if (m.k === 'm') return { t: 'mv', m: mi, d: mzPath(m.z, m.p, m.g)[0] };
    if (m.k === 'o') return { t: 'tx', m: mi, f: MFREQ[m.w] };
    if (m.k === 'v') return { t: 'vl', m: mi, v: valveSol(m, e) };
    return { t: 'mem', m: mi, i: memTarget(m) };
  }

  /* ======================= state ======================= */
  const remain = (s, now) => (s.ph === 'run' ? s.lim - (now - s.t0) / 1000 : s.lim);
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    const hm = players.map((p, i) => (p && p.ai ? -1 : i)).filter((i) => i >= 0);
    const lim = o.time === 180 ? 180 : 300, dif = [1, 2, 3].includes(o.dif) ? o.dif : 2;
    const s = { n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), hm, lim, dif,
      rds: o.rounds === 1 ? 1 : Math.max(1, hm.length), rd: 0, st0: hm.length ? U.rand(hm.length) : 0, df: -1, ph: 'brief',
      sd: 0, e: null, M: [], x: 0, t0: 0, ts: clock.now(), rs: '', dfs: [], last: null, seq: 0 };
    if (hm.length < 2) { s.ph = 'x'; return s; }
    return newRound(s, 0);
  }
  function newRound(s, rd) {
    s.rd = rd;
    s.df = s.hm[(s.st0 + rd) % s.hm.length];
    s.sd = 1 + U.rand(2147483646);
    const b = genBomb(s.sd, s.dif);
    s.e = b.e; s.M = b.M; s.x = 0; s.t0 = 0; s.ph = 'brief'; s.ts = clock.now();
    s.seq++; s.last = { id: s.seq, k: 'new' };
    return s;
  }
  function endRound(s, out, now) {
    s.rs += out; s.dfs.push(s.df);
    s.t0 = s.t0 || now; s.left = out === 'B' ? 0 : Math.max(0, Math.round(remain(s, now)));
    s.ph = s.rs.length >= s.rds ? 'done' : 'end';
    s.seq++; s.last = { id: s.seq, k: out === 'W' ? 'win' : out === 'B' ? 'boom' : 'left' };
    return s;
  }
  function strike(s, mi, now) {
    s.x++;
    s.seq++; s.last = { id: s.seq, k: 'strike', m: mi };
    if (s.x >= 3) endRound(s, 'B', now);
    return s;
  }
  function solved(s, mi, now) {
    s.M[mi].ok = 1;
    s.seq++; s.last = { id: s.seq, k: 'ok', m: mi };
    if (s.M.every((m) => m.ok)) endRound(s, 'W', now);
    return s;
  }
  function actor(s) {
    if (!s) return null;
    if (s.ph === 'brief' || s.ph === 'run') return s.df;
    if (s.ph === 'end') return s.hm.slice();
    return null;
  }
  function apply(s, seat, a) {
    const now = clock.now();
    if (!a || typeof a !== 'object') throw new Error('bad action');
    s.ts = now;
    if (s.ph === 'end') {
      if (a.t !== 'next' || !s.hm.includes(seat)) throw new Error('bad action');
      return newRound(s, s.rd + 1);
    }
    if (seat !== s.df) throw new Error('not the defuser');
    if (s.ph === 'brief') {
      if (a.t !== 'go') throw new Error('bad action');
      s.ph = 'run'; s.t0 = now; s.seq++; s.last = { id: s.seq, k: 'go' };
      return s;
    }
    if (s.ph !== 'run') throw new Error('bad phase');
    if (remain(s, now) <= 0) return endRound(s, 'B', now);
    const mi = a.m | 0, m = s.M[mi];
    if (!m || m.ok) throw new Error('bad module');
    const e = s.e;
    switch (a.t) {
      case 'cut': {
        const i = a.i | 0;
        if (m.k !== 'w' || i < 0 || i >= m.c.length || (m.x >> i) & 1) throw new Error('bad wire');
        m.x |= 1 << i;
        return i === wireSol(m.c, e) ? solved(s, mi, now) : strike(s, mi, now);
      }
      case 'tap': case 'rel': {
        if (m.k !== 'b') throw new Error('bad module');
        const d = btnSol(m, e);
        if (a.t === 'tap') return d < 0 ? solved(s, mi, now) : strike(s, mi, now);
        if (d < 0) return strike(s, mi, now);
        const hr = Math.ceil(remain(s, now));
        let r = a.r | 0;
        if (!(typeof a.r === 'number') || Math.abs(r - hr) > 3) r = hr; // latency tolerance, otherwise the host's clock
        return r % 10 === d ? solved(s, mi, now) : strike(s, mi, now);
      }
      case 'sym': {
        const i = a.i | 0, ord = symOrder(m.y);
        if (m.k !== 's' || i < 0 || i > 3 || ord.slice(0, m.p).includes(i)) throw new Error('bad key');
        if (ord[m.p] === i) { m.p++; if (m.p >= 4) return solved(s, mi, now); s.seq++; s.last = { id: s.seq, k: 'step', m: mi }; return s; }
        return strike(s, mi, now);
      }
      case 'pw': {
        if (m.k !== 'p' || !Array.isArray(a.v) || a.v.length !== 3) throw new Error('bad dial');
        const w = a.v.map((v, k) => m.d[k][((v | 0) % 5 + 5) % 5]).join('');
        return w === WORDS[m.w] ? solved(s, mi, now) : strike(s, mi, now);
      }
      case 'mv': {
        const d = a.d | 0;
        if (m.k !== 'm' || d < 0 || d > 3) throw new Error('bad move');
        const [dx, dy, bit] = DIRS[d], x = m.p % MZ, y = (m.p / MZ) | 0;
        if (x + dx < 0 || x + dx >= MZ || y + dy < 0 || y + dy >= MZ || !(MAZES[m.z][m.p] & bit)) return strike(s, mi, now);
        m.p += dx + dy * MZ;
        if (m.p === m.g) return solved(s, mi, now);
        s.seq++; s.last = { id: s.seq, k: 'step', m: mi };
        return s;
      }
      case 'tx': {
        const f = a.f | 0;
        if (m.k !== 'o' || f < 0 || f >= FREQS.length) throw new Error('bad freq');
        return f === MFREQ[m.w] ? solved(s, mi, now) : strike(s, mi, now);
      }
      case 'vl': {
        const v = a.v | 0;
        if (m.k !== 'v' || v < 0 || v > 4) throw new Error('bad valve');
        return v === valveSol(m, e) ? solved(s, mi, now) : strike(s, mi, now);
      }
      case 'mem': {
        const i = a.i | 0;
        if (m.k !== 'n' || i < 0 || i > 3) throw new Error('bad key');
        if (i === memTarget(m)) {
          m.h += String(i + 1) + m.l[m.s * 4 + i]; m.s++;
          if (m.s >= 3) return solved(s, mi, now);
          s.seq++; s.last = { id: s.seq, k: 'step', m: mi };
          return s;
        }
        Object.assign(m, memNew(prng(U.rand(2147483646) + 1)));
        return strike(s, mi, now);
      }
    }
    throw new Error('bad action');
  }
  /* host-only clock: explode at zero; a defuser who left (seat now AI) hands over / abandons the round */
  function tick(s, now, isAi) {
    isAi = isAi || (() => false);
    if (s.ph === 'run' && remain(s, now) <= 0) return endRound(s, 'B', now);
    if ((s.ph === 'brief' || s.ph === 'run') && isAi(s.df)) {
      if (s.ph === 'brief') { const nx = s.hm.find((i) => !isAi(i)); if (nx != null && s.hm.filter((i) => !isAi(i)).length >= 2) { s.df = nx; s.ts = now; s.seq++; s.last = { id: s.seq, k: 'new' }; return s; } }
      return endRound(s, 'L', now);
    }
    return null;
  }
  function result(s) {
    if (!s) return null;
    if (s.ph === 'x') return { winners: [], title: '폭탄 해체반은 사람끼리 해요', text: '각자 폰으로 2명 이상이 온라인 방이나 LAN 방에 들어와야 해요.\n(AI는 설명서를 읽거나 폭탄을 볼 수 없어요.)' };
    if (s.ph !== 'done') return null;
    const w = s.rs.split('W').length - 1, tot = s.rs.length;
    const lines = s.rs.split('').map((o, k) => (k + 1) + '번 폭탄 · ' + (s.nm[s.dfs[k]] || '?') + ' — ' + (o === 'W' ? '해체 성공' : o === 'B' ? '폭발' : '중단'));
    const team = w * 2 >= tot && w > 0;
    return { winners: team ? s.hm.slice() : [], title: team ? (w === tot ? '완벽한 해체반!' : '해체반 승리') + ' ' + w + '/' + tot : '해체 실패 ' + w + '/' + tot,
      text: lines.join('\n') + '\n' + (team ? '절반 이상 해체해서 모두의 승리예요.' : '절반 이상 해체해야 팀 승리예요.') };
  }

  /* ======================= art helpers ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else c.rect(x, y, w, h); }
  /* 24 original glyphs in a unit box (−1..1) */
  const GLY = [
    (g) => { g.beginPath(); g.arc(0, 0, 0.8, 0.7, Math.PI * 2 - 0.7); g.arc(0.38, 0, 0.62, -1.0, 1.0, true); g.closePath(); g.stroke(); },
    (g) => { g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, r = k % 2 ? 0.36 : 0.88; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.closePath(); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(-0.9, 0); g.quadraticCurveTo(0, -0.85, 0.9, 0); g.quadraticCurveTo(0, 0.85, -0.9, 0); g.stroke(); g.beginPath(); g.arc(0, 0, 0.24, 0, 7); g.fill(); },
    (g) => { g.beginPath(); for (let a = 0; a < Math.PI * 4.2; a += 0.15) { const r = 0.06 + a * 0.062; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(0, 0.9); g.lineTo(0, -0.85); g.moveTo(-0.62, -0.7); g.quadraticCurveTo(-0.62, 0.05, 0, 0.1); g.quadraticCurveTo(0.62, 0.05, 0.62, -0.7); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(0.3, -0.85); g.lineTo(0.3, 0.3); g.arc(-0.06, 0.3, 0.36, 0, Math.PI); g.stroke(); g.beginPath(); g.arc(-0.42, -0.55, 0.13, 0, 7); g.fill(); },
    (g) => { g.beginPath(); g.moveTo(0, -0.9); g.bezierCurveTo(0.75, 0, 0.6, 0.85, 0, 0.85); g.bezierCurveTo(-0.6, 0.85, -0.75, 0, 0, -0.9); g.stroke(); },
    (g) => { g.beginPath(); g.arc(-0.5, 0, 0.3, 0, 7); g.moveTo(-0.2, 0); g.lineTo(0.88, 0); g.moveTo(0.55, 0); g.lineTo(0.55, 0.32); g.moveTo(0.82, 0); g.lineTo(0.82, 0.24); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(-0.8, 0.5); g.lineTo(-0.8, -0.5); g.lineTo(-0.4, -0.02); g.lineTo(0, -0.72); g.lineTo(0.4, -0.02); g.lineTo(0.8, -0.5); g.lineTo(0.8, 0.5); g.closePath(); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(0.22, -0.9); g.lineTo(-0.45, 0.1); g.lineTo(0.05, 0.1); g.lineTo(-0.2, 0.9); g.lineTo(0.5, -0.18); g.lineTo(0, -0.18); g.closePath(); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(0, 0.8); g.bezierCurveTo(-1.1, 0, -0.6, -0.95, 0, -0.4); g.bezierCurveTo(0.6, -0.95, 1.1, 0, 0, 0.8); g.stroke(); g.beginPath(); g.moveTo(0, -0.4); g.lineTo(-0.12, -0.1); g.lineTo(0.1, 0.12); g.lineTo(-0.05, 0.4); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(0, -0.85); g.lineTo(0.62, 0.25); g.lineTo(0, -0.05); g.lineTo(-0.62, 0.25); g.closePath(); g.stroke(); g.beginPath(); g.moveTo(-0.5, 0.62); g.lineTo(0.5, 0.62); g.stroke(); },
    (g) => { g.beginPath(); g.arc(0, 0, 0.34, 0, 7); g.stroke(); g.beginPath(); for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; g.moveTo(Math.cos(a) * 0.55, Math.sin(a) * 0.55); g.lineTo(Math.cos(a) * 0.88, Math.sin(a) * 0.88); } g.stroke(); },
    (g) => { for (const y0 of [-0.38, 0.38]) { g.beginPath(); for (let x = -0.9; x <= 0.9; x += 0.05) g.lineTo(x, y0 + Math.sin(x * 5) * 0.2); g.stroke(); } },
    (g) => { g.beginPath(); g.arc(0, 0, 0.78, 0, 7); g.moveTo(-0.45, -0.45); g.lineTo(0.45, 0.45); g.moveTo(0.45, -0.45); g.lineTo(-0.45, 0.45); g.stroke(); },
    (g) => { g.beginPath(); g.rect(-0.75, -0.75, 1.5, 1.5); g.moveTo(0, -0.5); g.lineTo(0.5, 0); g.lineTo(0, 0.5); g.lineTo(-0.5, 0); g.closePath(); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(0, -0.9); g.lineTo(0.58, 0); g.lineTo(0, 0.9); g.lineTo(-0.58, 0); g.closePath(); g.moveTo(-0.9, 0); g.lineTo(0.9, 0); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(0, -0.9); g.lineTo(0.48, -0.2); g.lineTo(-0.48, -0.2); g.closePath(); g.moveTo(0, -0.45); g.lineTo(0.7, 0.45); g.lineTo(-0.7, 0.45); g.closePath(); g.moveTo(0, 0.45); g.lineTo(0, 0.9); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(-0.7, 0.85); g.lineTo(-0.7, -0.1); g.lineTo(0, -0.8); g.lineTo(0.7, -0.1); g.lineTo(0.7, 0.85); g.closePath(); g.moveTo(-0.2, 0.85); g.lineTo(-0.2, 0.3); g.lineTo(0.2, 0.3); g.lineTo(0.2, 0.85); g.stroke(); },
    (g) => { g.beginPath(); g.arc(0, -0.68, 0.18, 0, 7); g.moveTo(0, -0.5); g.lineTo(0, 0.82); g.moveTo(-0.35, -0.25); g.lineTo(0.35, -0.25); g.moveTo(-0.7, 0.3); g.quadraticCurveTo(-0.6, 0.85, 0, 0.82); g.quadraticCurveTo(0.6, 0.85, 0.7, 0.3); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(-0.6, -0.85); g.lineTo(0.6, -0.85); g.lineTo(-0.6, 0.85); g.lineTo(0.6, 0.85); g.closePath(); g.stroke(); },
    (g) => { g.beginPath(); g.moveTo(-0.7, 0); g.quadraticCurveTo(0, -0.7, 0.55, 0); g.quadraticCurveTo(0, 0.7, -0.7, 0); g.moveTo(0.55, 0); g.lineTo(0.9, -0.4); g.lineTo(0.9, 0.4); g.closePath(); g.stroke(); g.beginPath(); g.arc(-0.35, -0.08, 0.08, 0, 7); g.fill(); },
    (g) => { g.beginPath(); g.moveTo(-0.7, 0.55); g.quadraticCurveTo(-0.5, 0.4, -0.5, -0.1); g.quadraticCurveTo(-0.5, -0.8, 0, -0.8); g.quadraticCurveTo(0.5, -0.8, 0.5, -0.1); g.quadraticCurveTo(0.5, 0.4, 0.7, 0.55); g.closePath(); g.stroke(); g.beginPath(); g.arc(0, 0.75, 0.13, 0, 7); g.fill(); },
    (g) => { g.beginPath(); for (let t = 0; t <= Math.PI * 2 + 0.1; t += 0.1) { const d = 1 + Math.sin(t) * Math.sin(t); g.lineTo(0.88 * Math.cos(t) / d, 0.88 * Math.sin(t) * Math.cos(t) / d); } g.stroke(); },
  ];
  function glyph(g, id, x, y, r, col, lw) {
    g.save(); g.translate(x, y); g.scale(r, r);
    g.strokeStyle = col; g.fillStyle = col; g.lineWidth = (lw || 2.6) / r; g.lineCap = 'round'; g.lineJoin = 'round';
    (GLY[id] || GLY[0])(g); g.restore();
  }

  /* ======================= sound ======================= */
  const Snd = {
    ac: null,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    tick(hi) { const ac = this.ctx(); if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain(); o.type = 'square'; o.frequency.setValueAtTime(hi ? 1500 : 1050, t); g.gain.setValueAtTime(0.05, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05); o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 0.06); },
    noise(dur, vol, f0, f1) {
      const ac = this.ctx(); if (!ac) return; const t = ac.currentTime, n = Math.floor(ac.sampleRate * dur), b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2);
      const src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain(); src.buffer = b; f.type = 'lowpass'; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + dur);
      g.gain.setValueAtTime(vol, t); src.connect(f).connect(g).connect(ac.destination); src.start(t);
    },
    boom() { this.noise(2.2, 0.9, 1800, 60); const ac = this.ctx(); if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain(); o.frequency.setValueAtTime(70, t); o.frequency.exponentialRampToValueAtTime(28, t + 1); g.gain.setValueAtTime(0.6, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.2); o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 1.3); },
    zap() { this.noise(0.35, 0.35, 5000, 400); },
    chime(notes) { const ac = this.ctx(); if (!ac) return; notes.forEach((f, k) => { const t = ac.currentTime + k * 0.09, o = ac.createOscillator(), g = ac.createGain(); o.type = 'triangle'; o.frequency.setValueAtTime(f, t); g.gain.setValueAtTime(0.14, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35); o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 0.4); }); },
    close() { try { this.ac && this.ac.close(); } catch (e) {} this.ac = null; },
  };

  /* ======================= view ======================= */
  const CSS = `
.bm-man{word-break:keep-all;overflow-wrap:anywhere;position:absolute;inset:0;z-index:4;display:flex;flex-direction:column;background:#17131f;user-select:none;-webkit-user-select:none}
.bm-hud{display:flex;align-items:center;gap:10px;padding:8px 12px;background:#221c2e;border-bottom:1px solid rgba(242,233,216,.08);flex:none}
.bm-hud .tm{font-family:var(--f-mono,monospace);font-size:26px;font-weight:700;color:#ff5a43;background:#0d0a0a;border-radius:8px;padding:2px 10px;letter-spacing:.04em;min-width:86px;text-align:center;text-shadow:0 0 8px rgba(255,80,60,.6)}
.bm-hud .tm.calm{color:#ab9fb8;text-shadow:none}
.bm-hud .info{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;font-size:12.5px;color:#ab9fb8;line-height:1.25}
.bm-hud .info b{color:#f2e9d8;font-weight:700;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bm-hud .xs{display:flex;gap:4px}
.bm-hud .xs i{width:20px;height:20px;border-radius:5px;background:#2e2640;display:grid;place-items:center;font-style:normal;font-weight:800;color:#433a55;font-size:14px}
.bm-hud .xs i.on{background:#7a1f18;color:#ff7a62;box-shadow:0 0 8px rgba(255,90,60,.6)}
.bm-tabs{display:flex;gap:6px;overflow-x:auto;padding:8px 10px;flex:none;scrollbar-width:none;background:#1b1625}
.bm-tabs::-webkit-scrollbar{display:none}
.bm-tabs button{flex:none;min-height:40px;padding:0 12px;border-radius:20px;border:1.5px solid rgba(242,233,216,.14);background:#2e2640;color:#f2e9d8;font:600 13.5px var(--f-body,sans-serif);touch-action:manipulation}
.bm-tabs button.on{background:#e3ae45;color:#241b0c;border-color:#e3ae45}
.bm-page{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:12px 12px 28px;touch-action:pan-y}
.bm-paper{background:#efe6d2;color:#2a2018;border-radius:6px;padding:16px 14px 18px;box-shadow:0 6px 18px rgba(0,0,0,.4);position:relative;font-size:14.5px;line-height:1.5;background-image:repeating-linear-gradient(0deg,rgba(80,60,30,.05) 0 1px,transparent 1px 26px)}
.bm-paper h2{margin:0 0 2px;font-family:var(--f-display,sans-serif);font-weight:400;font-size:24px;color:#1f1712}
.bm-paper .stamp{position:absolute;top:12px;right:12px;border:2px solid #b8352a;color:#b8352a;font:800 11px var(--f-mono,monospace);padding:2px 6px;transform:rotate(6deg);border-radius:3px;opacity:.85}
.bm-paper h3{margin:14px 0 6px;font-size:15px;font-weight:800;color:#5a2a1c;border-bottom:1.5px solid rgba(90,42,28,.25);padding-bottom:2px}
.bm-paper p{margin:6px 0}
.bm-paper .look{background:rgba(90,60,30,.08);border-left:3px solid #8a6a3a;padding:6px 8px;border-radius:2px;font-size:13.5px}
.bm-paper ol,.bm-paper ul{margin:4px 0;padding-left:20px}
.bm-paper li{margin:3px 0}
.bm-paper table{border-collapse:collapse;width:100%;margin:6px 0;font-size:13.5px}
.bm-paper td,.bm-paper th{border:1px solid rgba(60,40,20,.3);padding:5px 6px;text-align:left;vertical-align:top}
.bm-paper th{background:rgba(90,60,30,.12);font-weight:800}
.bm-paper .sw{display:inline-block;width:12px;height:12px;border-radius:3px;border:1px solid rgba(0,0,0,.4);vertical-align:-1px;margin-right:3px}
.bm-paper canvas{display:block;max-width:100%;margin:6px auto}
.bm-paper .mono{font-family:var(--f-mono,monospace)}
.bm-paper .grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.bm-paper .btn{color:#f2e9d8}
.bm-paper .nw{white-space:nowrap;font-weight:700}
.bm-paper .tip{font-size:12.5px;color:#6b5a48}
.bm-end{position:absolute;left:12px;right:12px;bottom:calc(14px + env(safe-area-inset-bottom));z-index:8;background:rgba(34,28,46,.97);border:1px solid rgba(242,233,216,.12);border-radius:16px;padding:14px;display:flex;flex-direction:column;gap:10px;box-shadow:0 12px 30px rgba(0,0,0,.5)}
.bm-end h3{margin:0;font-family:var(--f-display,sans-serif);font-weight:400;font-size:26px}
.bm-end p{margin:0;color:#ab9fb8;font-size:13.5px;line-height:1.4}
.bm-block{word-break:keep-all;overflow-wrap:anywhere;position:absolute;inset:0;z-index:9;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center;background:radial-gradient(circle at 50% 40%,#2c2139,#141019)}
.bm-block h3{margin:0;font-family:var(--f-display,sans-serif);font-weight:400;font-size:26px;color:#f2e9d8}
.bm-block p{margin:0;color:#ab9fb8;line-height:1.5;font-size:14px;max-width:320px}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const fx = U.canvas(root), fctx = fx.ctx;
    fx.cv.style.pointerEvents = 'none'; fx.cv.style.zIndex = '6';
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let st = null, recv = { at: 0, ts: 0 }, lastId = -1, roundKey = '';
    let cur = 0, hits = [], hold = null, armed = null, pend = 0, flash = { t: 0, col: '' }, shake = 0, parts = [], banner = null;
    let ui = {}; // per-module local UI state (dial positions, knob, freq)
    let lastSec = -1, busyT = 0, boomT = 0, winT = 0, manual = null, endEl = null, blockEl = null, pageIx = 0;
    const isDef = () => !!st && st.df >= 0 && api.canAct(st.df);
    const nm = (i) => (st && st.nm[i]) || (api.players[i] ? api.players[i].name : '?');

    function remainNow() {
      if (!st || st.ph !== 'run') return st ? (st.ph === 'brief' ? st.lim : (st.left != null ? st.left : 0)) : 0;
      const el = api.isHost ? clock.now() - st.t0 : (st.ts - st.t0) + (performance.now() - recv.at);
      return st.lim - el / 1000;
    }
    const shownSecs = () => Math.max(0, Math.ceil(remainNow()));
    const fmt = (s) => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');

    /* ----- input ----- */
    function act(a) {
      if (!st) return;
      if (!api.isHost) { if (pend && performance.now() - pend < 1500) return; pend = performance.now(); }
      api.act(a);
    }
    const locked = () => !api.isHost && pend && performance.now() - pend < 1500;
    function onDown(e) {
      if (!st || !isDef()) return;
      e.preventDefault();
      Snd.ctx();
      const p = cv.local(e);
      const h = hits.slice().reverse().find((q) => p.x >= q.x && p.x <= q.x + q.w && p.y >= q.y && p.y <= q.y + q.h);
      if (!h) return;
      if (h.hold) { hold = { id: e.pointerId, t: performance.now(), m: h.m }; try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {} api.buzz(15); api.sfx('click'); return; }
      if (locked()) return;
      h.press = performance.now(); pressFx = { key: h.key, t: performance.now() };
      h.on();
    }
    let pressFx = null;
    function onUp(e) {
      if (!hold || e.pointerId !== hold.id) return;
      const dur = (performance.now() - hold.t) / 1000, m = hold.m;
      hold = null;
      if (!st || st.ph !== 'run' || !st.M[m] || st.M[m].ok) return;
      if (dur < 0.45) act({ t: 'tap', m });
      else act({ t: 'rel', m, r: shownSecs() });
      api.sfx('click');
    }
    function onCancel(e) { if (hold && e.pointerId === hold.id) hold = null; }
    cv.cv.addEventListener('pointerdown', onDown);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onCancel);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- module UI state ----- */
    function uiOf(mi) {
      const m = st.M[mi];
      if (!ui[mi]) ui[mi] = { pw: [0, 0, 0], f: 0, v: 0 };
      void m;
      return ui[mi];
    }

    /* ======================= defuser canvas ======================= */
    function layout() {
      const W = cv.w, H = cv.h;
      const top = { x: 8, y: 8, w: W - 16, h: 102 };
      const tabsH = 58, tabs = { x: 8, y: H - tabsH - 8, w: W - 16, h: tabsH };
      const mod = { x: 8, y: top.y + top.h + 8, w: W - 16, h: tabs.y - 8 - (top.y + top.h + 8) };
      return { top, tabs, mod };
    }
    function hit(x, y, w, h, on, extra) { const o = Object.assign({ x, y, w, h, on, key: x + ',' + y }, extra || {}); hits.push(o); return o; }
    function pressed(x, y) { return pressFx && pressFx.key === x + ',' + y && performance.now() - pressFx.t < 140; }
    function txt(g, t, x, y, col, font, al, bl) { g.font = font; g.fillStyle = col; g.textAlign = al || 'center'; g.textBaseline = bl || 'middle'; g.fillText(t, x, y); }
    function btn(x, y, w, h, label, on, opt) {
      opt = opt || {};
      const pr = pressed(x, y);
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rrect(ctx, x, y + 3, w, h, 10); ctx.fill();
      const gr = ctx.createLinearGradient(0, y, 0, y + h); gr.addColorStop(0, opt.c1 || '#5b5560'); gr.addColorStop(1, opt.c2 || '#38333d');
      ctx.fillStyle = gr; rrect(ctx, x, y + (pr ? 2 : 0), w, h, 10); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1; ctx.stroke();
      txt(ctx, label, x + w / 2, y + h / 2 + (pr ? 2 : 0), opt.ink || '#f2e9d8', opt.font || '700 16px ' + FONT);
      ctx.restore();
      if (on) hit(x, y, w, h, on);
    }
    function screw(x, y) { ctx.fillStyle = '#8b8790'; ctx.beginPath(); ctx.arc(x, y, 4, 0, 7); ctx.fill(); ctx.strokeStyle = '#4a464e'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x - 2.6, y - 1.5); ctx.lineTo(x + 2.6, y + 1.5); ctx.stroke(); }
    function drawBomb(now) {
      const W = cv.w, H = cv.h, Lr = layout();
      hits = [];
      // casing
      ctx.fillStyle = '#16121b'; ctx.fillRect(0, 0, W, H);
      const cg = ctx.createLinearGradient(0, 0, 0, H); cg.addColorStop(0, '#3b4034'); cg.addColorStop(1, '#262a22');
      ctx.fillStyle = cg; rrect(ctx, 2, 2, W - 4, H - 4, 14); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 2; ctx.stroke();
      ctx.save(); ctx.globalAlpha = 0.06; ctx.fillStyle = '#000';
      for (let y = 6; y < H; y += 5) ctx.fillRect(0, y, W, 1);
      ctx.restore();
      drawTop(Lr.top, now);
      drawTabs(Lr.tabs);
      const m = st.M[cur];
      drawModule(Lr.mod, m, cur, now);
      if (st.ph === 'brief') {
        hits = [];
        const M = Lr.mod;
        ctx.fillStyle = 'rgba(16,12,20,.82)'; rrect(ctx, M.x, M.y, M.w, M.h, 14); ctx.fill();
        txt(ctx, '해체 담당은 당신!', M.x + M.w / 2, M.y + M.h * 0.24, '#e3ae45', '28px ' + DISP);
        const lines = ['동료들은 설명서만 볼 수 있어요.', '보이는 것을 말로 설명하고,', '동료의 지시대로 해체하세요.', '모듈 ' + st.M.length + '개 · 경고 3번이면 폭발'];
        lines.forEach((t, k) => txt(ctx, t, M.x + M.w / 2, M.y + M.h * 0.24 + 40 + k * 24, '#f2e9d8', '500 15px ' + FONT));
        const bw = Math.min(260, M.w - 40), bh = 58;
        btn(M.x + (M.w - bw) / 2, M.y + M.h - bh - 24, bw, bh, '타이머 시작', () => { api.buzz(30); act({ t: 'go' }); }, { c1: '#c2412f', c2: '#8a2416', font: '22px ' + DISP });
      }
    }
    function drawTop(T, now) {
      // timer LCD
      const tw = Math.min(150, T.w * 0.42), th = 54;
      ctx.fillStyle = '#0b0909'; rrect(ctx, T.x + 6, T.y + 4, tw, th, 8); ctx.fill();
      ctx.strokeStyle = '#555'; ctx.lineWidth = 2; ctx.stroke();
      const secs = shownSecs();
      const low = st.ph === 'run' && secs <= 30;
      const blink = low && Math.floor(now / 250) % 2 === 0;
      txt(ctx, '8:88', T.x + 6 + tw / 2, T.y + 4 + th / 2 + 2, 'rgba(255,60,40,.08)', '700 40px ' + MONO);
      ctx.save(); ctx.shadowColor = '#ff3a22'; ctx.shadowBlur = 10;
      txt(ctx, fmt(secs), T.x + 6 + tw / 2, T.y + 4 + th / 2 + 2, blink ? '#ff9a7a' : '#ff4b30', '700 40px ' + MONO);
      ctx.restore();
      // strikes
      const sx = T.x + tw + 18;
      txt(ctx, '경고', sx, T.y + 12, '#c8c2b0', '700 11px ' + FONT, 'left');
      for (let k = 0; k < 3; k++) {
        const x = sx + k * 28, y = T.y + 22, on = k < st.x;
        ctx.fillStyle = on ? '#6a1a12' : '#1d1b1e'; rrect(ctx, x, y, 24, 28, 5); ctx.fill();
        if (on) { ctx.save(); ctx.shadowColor = '#ff4b30'; ctx.shadowBlur = 8; }
        txt(ctx, '✕', x + 12, y + 15, on ? '#ff6a4a' : '#3a363c', '800 18px ' + FONT);
        if (on) ctx.restore();
      }
      // solved count
      const solvedN = st.M.filter((m) => m.ok).length;
      const rx = T.x + T.w - 6;
      txt(ctx, solvedN + '/' + st.M.length, rx, T.y + 36, '#9fe0a8', '700 18px ' + MONO, 'right');
      txt(ctx, '해체', rx, T.y + 14, '#c8c2b0', '700 11px ' + FONT, 'right');
      // edgework row
      const y2 = T.y + 66;
      // serial sticker
      ctx.fillStyle = '#ece6d6'; rrect(ctx, T.x + 6, y2, 112, 32, 4); ctx.fill();
      txt(ctx, 'SERIAL', T.x + 12, y2 + 9, '#7a6a55', '700 8px ' + MONO, 'left');
      txt(ctx, st.e.s, T.x + 62, y2 + 21, '#1a1410', '700 16px ' + MONO);
      // batteries
      let bx = T.x + 128;
      const bn = st.e.b;
      if (!bn) { txt(ctx, '배터리 없음', bx, y2 + 16, '#8f8a80', '600 11px ' + FONT, 'left'); bx += 70; }
      for (let k = 0; k < bn; k++) {
        ctx.fillStyle = '#2b5fa8'; rrect(ctx, bx, y2 + 4, 13, 26, 3); ctx.fill();
        ctx.fillStyle = '#c9c4b8'; ctx.fillRect(bx + 4, y2 + 1, 5, 3);
        ctx.fillStyle = '#e8b13b'; ctx.fillRect(bx, y2 + 20, 13, 3);
        bx += 17;
      }
      bx = Math.max(bx + 6, T.x + 128 + 4 * 17 + 6);
      // lamps
      const lw2 = Math.max(54, (T.x + T.w - bx - 6) / 2 - 4);
      st.e.i.forEach(([k, on], j) => {
        const x = bx + j * (lw2 + 6);
        ctx.fillStyle = '#1e1c20'; rrect(ctx, x, y2, lw2, 32, 6); ctx.fill();
        ctx.save(); if (on) { ctx.shadowColor = '#ffe27a'; ctx.shadowBlur = 10; }
        ctx.fillStyle = on ? '#ffe27a' : '#3d3a35'; ctx.beginPath(); ctx.arc(x + 12, y2 + 16, 6, 0, 7); ctx.fill(); ctx.restore();
        txt(ctx, LAMPS[k], x + 22, y2 + 16, on ? '#f2e9d8' : '#8f8a80', '700 13px ' + FONT, 'left');
      });
    }
    function drawTabs(T) {
      const n = st.M.length, gap = 6, w = (T.w - gap * (n - 1)) / n;
      st.M.forEach((m, k) => {
        const x = T.x + k * (w + gap), sel = k === cur;
        ctx.fillStyle = sel ? '#5a5f4c' : '#2a2d25'; rrect(ctx, x, T.y, w, T.h, 10); ctx.fill();
        ctx.strokeStyle = sel ? '#e3ae45' : 'rgba(0,0,0,.4)'; ctx.lineWidth = sel ? 2 : 1; ctx.stroke();
        tabIcon(m.k, x + w / 2, T.y + T.h / 2 + 4, sel);
        ctx.save(); if (m.ok) { ctx.shadowColor = '#5fe08a'; ctx.shadowBlur = 8; }
        ctx.fillStyle = m.ok ? '#5fe08a' : '#3a2220'; ctx.beginPath(); ctx.arc(x + w - 10, T.y + 10, 5, 0, 7); ctx.fill(); ctx.restore();
        txt(ctx, String(k + 1), x + 9, T.y + 11, '#c8c2b0', '700 11px ' + MONO, 'left');
        hit(x, T.y, w, T.h, () => { if (cur !== k) { cur = k; armed = null; api.sfx('click'); api.buzz(8); } });
      });
    }
    function tabIcon(k, x, y, sel) {
      const c = sel ? '#f2e9d8' : '#b9b3a3';
      ctx.save(); ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 2.4; ctx.lineCap = 'round';
      if (k === 'w') { ['#d8432f', '#2f6fd6', '#f0c419'].forEach((col, i) => { ctx.strokeStyle = col; ctx.beginPath(); ctx.moveTo(x - 13, y - 8 + i * 8); ctx.quadraticCurveTo(x, y - 4 + i * 8, x + 13, y - 8 + i * 8); ctx.stroke(); }); }
      else if (k === 'b') { ctx.fillStyle = '#c2412f'; ctx.beginPath(); ctx.arc(x, y, 11, 0, 7); ctx.fill(); }
      else if (k === 's') glyph(ctx, 1, x, y, 12, c, 2.2);
      else if (k === 'p') txt(ctx, '가', x, y + 1, c, '800 18px ' + FONT);
      else if (k === 'm') { for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) { ctx.beginPath(); ctx.arc(x - 9 + i * 9, y - 9 + j * 9, 1.8, 0, 7); ctx.fill(); } ctx.strokeStyle = '#5fe08a'; ctx.beginPath(); ctx.arc(x - 9, y - 9, 4.5, 0, 7); ctx.stroke(); }
      else if (k === 'o') { ctx.fillStyle = '#ffcc4d'; ctx.beginPath(); ctx.arc(x - 8, y, 4, 0, 7); ctx.fill(); ctx.fillRect(x - 1, y - 2.5, 13, 5); }
      else if (k === 'v') { ctx.beginPath(); ctx.arc(x, y + 5, 12, Math.PI, 0); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x, y + 5); ctx.lineTo(x + 7, y - 4); ctx.stroke(); }
      else txt(ctx, '#', x, y + 1, c, '800 20px ' + MONO);
      ctx.restore();
    }
    function panel(M, m) {
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rrect(ctx, M.x, M.y + 3, M.w, M.h, 14); ctx.fill();
      const g = ctx.createLinearGradient(M.x, M.y, M.x + M.w, M.y + M.h); g.addColorStop(0, '#6d6f68'); g.addColorStop(1, '#45473f');
      ctx.fillStyle = g; rrect(ctx, M.x, M.y, M.w, M.h, 14); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.14)'; ctx.lineWidth = 1.5; ctx.stroke();
      screw(M.x + 12, M.y + 12); screw(M.x + M.w - 12, M.y + M.h - 12); screw(M.x + 12, M.y + M.h - 12);
      // status LED
      const lx = M.x + M.w - 18, ly = M.y + 18, sflash = flash.t > 0 && flash.m === cur && flash.col === 'r';
      ctx.fillStyle = '#1a1a1a'; ctx.beginPath(); ctx.arc(lx, ly, 10, 0, 7); ctx.fill();
      ctx.save(); if (m.ok || sflash) { ctx.shadowColor = m.ok ? '#5fe08a' : '#ff4b30'; ctx.shadowBlur = 14; }
      ctx.fillStyle = m.ok ? '#5fe08a' : sflash ? '#ff4b30' : '#3b2724'; ctx.beginPath(); ctx.arc(lx, ly, 7, 0, 7); ctx.fill(); ctx.restore();
      txt(ctx, '모듈 ' + (cur + 1), M.x + 26, M.y + 18, 'rgba(20,18,16,.55)', '700 12px ' + MONO, 'left');
    }
    function drawModule(M, m, mi, now) {
      panel(M, m);
      const I = { x: M.x + 16, y: M.y + 36, w: M.w - 32, h: M.h - 52 };
      const live = st.ph === 'run' && !m.ok;
      const f = { w: drawWires, b: drawButton, s: drawSymbols, p: drawPassword, m: drawMaze, o: drawMorse, v: drawValve, n: drawMemory }[m.k];
      f(I, m, mi, live, now);
      if (m.ok) {
        ctx.fillStyle = 'rgba(20,40,24,.35)'; rrect(ctx, M.x, M.y, M.w, M.h, 14); ctx.fill();
        ctx.save(); ctx.translate(M.x + M.w / 2, M.y + M.h / 2); ctx.rotate(-0.12);
        ctx.strokeStyle = '#5fe08a'; ctx.lineWidth = 4; rrect(ctx, -84, -26, 168, 52, 8); ctx.stroke();
        txt(ctx, '해체 완료', 0, 2, '#5fe08a', '30px ' + DISP);
        ctx.restore();
      }
    }
    /* --- wires --- */
    function drawWires(I, m, mi, live) {
      const n = m.c.length, x0 = I.x + 18, x1 = I.x + I.w - 18, top = I.y + 20, gap = (I.h - 40) / (n - 1 || 1);
      ctx.fillStyle = '#2b2a28'; rrect(ctx, x0 - 14, top - 18, 22, I.h - 4, 6); ctx.fill(); rrect(ctx, x1 - 8, top - 18, 22, I.h - 4, 6); ctx.fill();
      for (let i = 0; i < n; i++) {
        const y = top + i * gap, col = WCOL[m.c[i]], cut = (m.x >> i) & 1, isArm = armed && armed.m === mi && armed.i === i && performance.now() - armed.t < 2500;
        ctx.fillStyle = '#c9b78a'; ctx.beginPath(); ctx.arc(x0, y, 6, 0, 7); ctx.arc(x1, y, 6, 0, 7); ctx.fill();
        const sag = 10 + (i % 3) * 5, mid = (x0 + x1) / 2;
        const path = (a, b) => { ctx.beginPath(); ctx.moveTo(a, y + (a === x0 ? 0 : sag * 0.6)); ctx.quadraticCurveTo((a + b) / 2, y + sag, b, y + (b === x1 ? 0 : sag * 0.6)); };
        const stroke = (lw, c) => { ctx.lineWidth = lw; ctx.strokeStyle = c; ctx.lineCap = 'round'; ctx.stroke(); };
        if (isArm) { ctx.save(); ctx.shadowColor = '#fff3b0'; ctx.shadowBlur = 16; path(x0, x1); stroke(18, 'rgba(255,243,176,.55)'); ctx.restore(); }
        if (cut) { path(x0, mid - 14); stroke(13, 'rgba(0,0,0,.4)'); stroke(10, col); path(mid + 14, x1); stroke(13, 'rgba(0,0,0,.4)'); stroke(10, col);
          ctx.fillStyle = '#c98a48'; ctx.beginPath(); ctx.arc(mid - 14, y + sag * 0.8, 3, 0, 7); ctx.arc(mid + 14, y + sag * 0.8, 3, 0, 7); ctx.fill(); }
        else { path(x0, x1); stroke(13, 'rgba(0,0,0,.45)'); stroke(10, col); ctx.save(); ctx.globalAlpha = 0.35; path(x0, x1); stroke(3, '#fff'); ctx.restore(); }
        if (isArm) txt(ctx, '한 번 더 누르면 잘라요', mid, y - 14, '#fff3b0', '700 13px ' + FONT);
        if (live && !cut) hit(x0, y - gap / 2, x1 - x0, gap, () => {
          if (armed && armed.m === mi && armed.i === i && performance.now() - armed.t < 2500) { armed = null; api.buzz(25); Snd.noise(0.08, 0.3, 4000, 1500); act({ t: 'cut', m: mi, i }); }
          else { armed = { m: mi, i, t: performance.now() }; api.sfx('click'); api.buzz(8); }
        });
      }
    }
    /* --- big button --- */
    function drawButton(I, m, mi, live, now) {
      const r = Math.min(I.w * 0.32, I.h * 0.34), cx = I.x + I.w * 0.42, cy = I.y + I.h * 0.5;
      const down = hold && hold.m === mi;
      ctx.fillStyle = '#26241f'; ctx.beginPath(); ctx.arc(cx, cy + 4, r + 14, 0, 7); ctx.fill();
      const col = { R: '#c8392a', B: '#2d62c4', Y: '#e6b81c', W: '#e8e3d8' }[m.c];
      ctx.save(); ctx.translate(0, down ? 4 : 0);
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.arc(cx, cy + 6, r, 0, 7); ctx.fill();
      const g = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.35, r * 0.1, cx, cy, r);
      g.addColorStop(0, '#fff'); g.addColorStop(0.08, col); g.addColorStop(1, shade(col, -0.35));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fill();
      txt(ctx, BTN_L[m.l], cx, cy + 2, m.c === 'W' || m.c === 'Y' ? '#1d1712' : '#fbf6ea', Math.round(r * 0.42) + 'px ' + DISP);
      ctx.restore();
      // strip
      const sx = I.x + I.w * 0.84, sw = 24, sh = I.h * 0.62, sy = cy - sh / 2;
      ctx.fillStyle = '#151414'; rrect(ctx, sx - 4, sy - 4, sw + 8, sh + 8, 8); ctx.fill();
      const litS = down && (performance.now() - hold.t) / 1000 >= 0.45;
      ctx.save(); if (litS) { ctx.shadowColor = WCOL[m.s]; ctx.shadowBlur = 18; }
      ctx.fillStyle = litS ? (m.s === 'W' ? '#fffaf0' : WCOL[m.s]) : '#2c2a29'; rrect(ctx, sx, sy, sw, sh, 6); ctx.fill(); ctx.restore();
      if (live) hit(cx - r, cy - r, r * 2, r * 2, null, { hold: true, m: mi });
      void now;
    }
    /* --- symbols --- */
    function drawSymbols(I, m, mi, live) {
      const s = Math.min(I.w, I.h) * 0.4, gap = s * 0.14, ox = I.x + (I.w - (s * 2 + gap)) / 2, oy = I.y + (I.h - (s * 2 + gap)) / 2 + 6;
      const ord = symOrder(m.y), done = ord.slice(0, m.p);
      m.y.forEach((gid, i) => {
        const x = ox + (i % 2) * (s + gap), y = oy + Math.floor(i / 2) * (s + gap), on = done.includes(i), pr = pressed(x, y);
        ctx.fillStyle = 'rgba(0,0,0,.45)'; rrect(ctx, x, y + 4, s, s, 10); ctx.fill();
        ctx.fillStyle = on ? '#dfe9d6' : '#e9e2cf'; rrect(ctx, x, y + (pr ? 3 : 0), s, s, 10); ctx.fill();
        ctx.fillStyle = '#1a1a1a'; ctx.beginPath(); ctx.arc(x + s / 2, y + 12 + (pr ? 3 : 0), 5, 0, 7); ctx.fill();
        if (on) { ctx.save(); ctx.shadowColor = '#5fe08a'; ctx.shadowBlur = 8; ctx.fillStyle = '#5fe08a'; ctx.beginPath(); ctx.arc(x + s / 2, y + 12 + (pr ? 3 : 0), 4, 0, 7); ctx.fill(); ctx.restore(); }
        glyph(ctx, gid, x + s / 2, y + s / 2 + 8 + (pr ? 3 : 0), s * 0.3, '#1e1914', Math.max(2.5, s * 0.04));
        if (live && !on) hit(x, y, s, s, () => { api.buzz(12); api.sfx('click'); act({ t: 'sym', m: mi, i }); });
      });
    }
    /* --- password dials --- */
    function drawPassword(I, m, mi, live) {
      const u = uiOf(mi), cw = Math.min(78, I.w * 0.24), gap = Math.min(14, I.w * 0.04), tot = cw * 3 + gap * 2, ox = I.x + (I.w - tot) / 2;
      const ah = 46, dh = Math.min(88, I.h - ah * 2 - 90), oy = I.y + Math.max(4, (I.h - (ah * 2 + dh + 70)) / 2);
      for (let k = 0; k < 3; k++) {
        const x = ox + k * (cw + gap);
        btn(x, oy, cw, ah, '▲', live ? () => { u.pw[k] = (u.pw[k] + 4) % 5; api.sfx('tick'); api.buzz(6); } : null);
        ctx.fillStyle = '#0f1a12'; rrect(ctx, x, oy + ah + 8, cw, dh, 8); ctx.fill();
        ctx.strokeStyle = '#2a3a2c'; ctx.lineWidth = 2; ctx.stroke();
        ctx.save(); ctx.shadowColor = '#7dff9a'; ctx.shadowBlur = 8;
        txt(ctx, m.d[k][u.pw[k]], x + cw / 2, oy + ah + 8 + dh / 2 + 2, '#9dffb2', '800 ' + Math.round(Math.min(40, cw * 0.55)) + 'px ' + FONT);
        ctx.restore();
        btn(x, oy + ah + dh + 16, cw, ah, '▼', live ? () => { u.pw[k] = (u.pw[k] + 1) % 5; api.sfx('tick'); api.buzz(6); } : null);
      }
      const bw = Math.min(200, I.w * 0.6);
      btn(I.x + (I.w - bw) / 2, oy + ah * 2 + dh + 30, bw, 48, '확인', live ? () => { api.buzz(15); act({ t: 'pw', m: mi, v: u.pw.slice() }); } : null, { c1: '#3f6b48', c2: '#28452f' });
    }
    /* --- maze --- */
    function drawMaze(I, m, mi, live) {
      const ab = 46, padT = ab + 28, padB = ab + 12, padL = ab + 26, padR = ab + 12;
      const c = Math.floor(Math.min((I.w - padL - padR) / MZ, (I.h - padT - padB) / MZ, 52)), G = c * MZ;
      const gx = I.x + padL + (I.w - padL - padR - G) / 2, gy = I.y + padT + (I.h - padT - padB - G) / 2;
      ctx.fillStyle = '#121512'; rrect(ctx, gx - 6, gy - 6, G + 12, G + 12, 8); ctx.fill();
      for (let i = 0; i < MZ; i++) {
        txt(ctx, 'ABCDEF'[i], gx + c * i + c / 2, gy - 15, '#d9d4c2', '700 11px ' + MONO);
        txt(ctx, String(i + 1), gx - 15, gy + c * i + c / 2, '#d9d4c2', '700 11px ' + MONO);
      }
      for (let k = 0; k < MZ * MZ; k++) {
        const x = gx + (k % MZ) * c + c / 2, y = gy + Math.floor(k / MZ) * c + c / 2;
        ctx.fillStyle = '#4a5a4a'; ctx.beginPath(); ctx.arc(x, y, 2.4, 0, 7); ctx.fill();
        if (MKR[m.z].includes(k)) { ctx.strokeStyle = '#5fe08a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, c * 0.36, 0, 7); ctx.stroke(); }
        if (k === m.g) { ctx.fillStyle = '#ff4b30'; ctx.beginPath(); ctx.moveTo(x, y - c * 0.3); ctx.lineTo(x + c * 0.28, y + c * 0.22); ctx.lineTo(x - c * 0.28, y + c * 0.22); ctx.closePath(); ctx.fill(); }
        if (k === m.p) { ctx.fillStyle = '#f5f2ea'; ctx.fillRect(x - c * 0.22, y - c * 0.22, c * 0.44, c * 0.44); }
      }
      const mv = (d) => () => { api.buzz(8); api.sfx('tick'); act({ t: 'mv', m: mi, d }); };
      const cx = gx + G / 2, cy = gy + G / 2;
      btn(cx - 40, gy - 26 - ab, 80, ab, '▲', live ? mv(0) : null);
      btn(cx - 40, gy + G + 10, 80, ab, '▼', live ? mv(2) : null);
      btn(gx - 24 - ab, cy - 40, ab, 80, '◀', live ? mv(3) : null);
      btn(gx + G + 10, cy - 40, ab, 80, '▶', live ? mv(1) : null);
    }
    /* --- morse light --- */
    function morseOn(w, t) { // blink schedule: unit 0.3 s, word gap 7 units + 3
      const U2 = 0.3, seq = [];
      for (const ch of MWORDS[w]) { const code = MORSE[ch]; for (let i = 0; i < code.length; i++) { seq.push([1, code[i] === '.' ? 1 : 3]); seq.push([0, i === code.length - 1 ? 3 : 1]); } }
      seq[seq.length - 1] = [0, 10];
      const tot = seq.reduce((a, b) => a + b[1], 0) * U2;
      let x = ((t % tot) + tot) % tot;
      for (const [on, d] of seq) { if (x < d * U2) return !!on; x -= d * U2; }
      return false;
    }
    function drawMorse(I, m, mi, live, now) {
      const u = uiOf(mi), on = morseOn(m.w, now / 1000);
      const lx = I.x + I.w / 2, ly = I.y + I.h * 0.2, r = Math.min(30, I.h * 0.09);
      ctx.fillStyle = '#1b1915'; ctx.beginPath(); ctx.arc(lx, ly, r + 10, 0, 7); ctx.fill();
      ctx.save(); if (on) { ctx.shadowColor = '#ffcc4d'; ctx.shadowBlur = 30; }
      ctx.fillStyle = on ? '#ffd766' : '#4d4330'; ctx.beginPath(); ctx.arc(lx, ly, r, 0, 7); ctx.fill(); ctx.restore();
      // frequency panel
      const py = I.y + I.h * 0.42, ph = 64, bw = 54, pw = Math.min(I.w - bw * 2 - 20, 210), px = I.x + (I.w - pw) / 2;
      ctx.fillStyle = '#0c0f13'; rrect(ctx, px, py, pw, ph, 8); ctx.fill();
      // scale ticks
      ctx.strokeStyle = 'rgba(120,200,255,.35)'; ctx.lineWidth = 1;
      for (let k = 0; k < 24; k++) { const x = px + 10 + k * (pw - 20) / 23; ctx.beginPath(); ctx.moveTo(x, py + 6); ctx.lineTo(x, py + (k % 2 ? 11 : 15)); ctx.stroke(); }
      const nx = px + 10 + (u.f / (FREQS.length - 1)) * (pw - 20);
      ctx.strokeStyle = '#ff5a43'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(nx, py + 4); ctx.lineTo(nx, py + 20); ctx.stroke();
      ctx.save(); ctx.shadowColor = '#78c8ff'; ctx.shadowBlur = 8;
      txt(ctx, FREQS[u.f] + ' MHz', px + pw / 2, py + 42, '#a8dcff', '700 22px ' + MONO); ctx.restore();
      btn(px - bw - 8, py + 4, bw, ph - 8, '◀', live ? () => { u.f = Math.max(0, u.f - 1); api.sfx('tick'); api.buzz(6); } : null);
      btn(px + pw + 8, py + 4, bw, ph - 8, '▶', live ? () => { u.f = Math.min(FREQS.length - 1, u.f + 1); api.sfx('tick'); api.buzz(6); } : null);
      const sw = Math.min(200, I.w * 0.6);
      btn(I.x + (I.w - sw) / 2, Math.min(I.y + I.h - 52, py + ph + 30), sw, 50, '송신', live ? () => { api.buzz(15); act({ t: 'tx', m: mi, f: u.f }); } : null, { c1: '#3f5f7b', c2: '#283f52' });
    }
    /* --- valve gauge --- */
    function drawValve(I, m, mi, live) {
      const u = uiOf(mi), F = FACE[m.f];
      const gr = Math.min(I.w * 0.27, I.h * 0.2), gx = I.x + I.w / 2, gy = I.y + gr + 10;
      ctx.fillStyle = '#2a2a28'; ctx.beginPath(); ctx.arc(gx, gy, gr + 8, 0, 7); ctx.fill();
      ctx.fillStyle = F.c; ctx.beginPath(); ctx.arc(gx, gy, gr, 0, 7); ctx.fill();
      const ink = m.f === 2 ? '#e8e3d8' : '#1d1712';
      const a0 = Math.PI * 0.8, a1 = Math.PI * 2.2;
      ctx.strokeStyle = ink; ctx.lineWidth = 1.5;
      for (let k = 0; k <= 10; k++) { const a = a0 + (a1 - a0) * k / 10; ctx.beginPath(); ctx.moveTo(gx + Math.cos(a) * gr * 0.78, gy + Math.sin(a) * gr * 0.78); ctx.lineTo(gx + Math.cos(a) * gr * 0.92, gy + Math.sin(a) * gr * 0.92); ctx.stroke(); }
      const na = a0 + (a1 - a0) * m.n / 99;
      ctx.strokeStyle = '#c8392a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(gx + Math.cos(na) * gr * 0.82, gy + Math.sin(na) * gr * 0.82); ctx.stroke();
      ctx.fillStyle = '#333'; ctx.beginPath(); ctx.arc(gx, gy, 5, 0, 7); ctx.fill();
      ctx.fillStyle = '#0b0d0b'; rrect(ctx, gx - 26, gy + gr * 0.36, 52, 26, 5); ctx.fill();
      txt(ctx, String(m.n).padStart(2, '0'), gx, gy + gr * 0.36 + 14, '#9dffb2', '700 18px ' + MONO);
      // valve knob 0..4
      const ky = gy + gr + 34, kr = Math.min(48, (I.y + I.h - ky - 64) * 0.55), kx = gx, kcy = ky + kr + 6;
      for (let k = 0; k <= 4; k++) { const a = Math.PI * (1.15 + k * 0.175); txt(ctx, String(k), kx + Math.cos(a) * (kr + 14), kcy + Math.sin(a) * (kr + 14), k === u.v ? '#ffe27a' : '#d9d4c2', '700 14px ' + MONO); }
      ctx.fillStyle = '#8a2a1e'; ctx.beginPath(); ctx.arc(kx, kcy, kr, 0, 7); ctx.fill();
      ctx.strokeStyle = '#5a170f'; ctx.lineWidth = 3; ctx.stroke();
      const ka = Math.PI * (1.15 + u.v * 0.175);
      ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(kx - Math.cos(ka) * kr * 0.5, kcy - Math.sin(ka) * kr * 0.5); ctx.lineTo(kx + Math.cos(ka) * kr * 0.8, kcy + Math.sin(ka) * kr * 0.8); ctx.stroke();
      const by = kcy + 4, bw = 50;
      btn(I.x + 2, by - 24, bw, 48, '◀', live ? () => { u.v = Math.max(0, u.v - 1); api.sfx('tick'); api.buzz(6); } : null);
      btn(I.x + I.w - bw - 2, by - 24, bw, 48, '▶', live ? () => { u.v = Math.min(4, u.v + 1); api.sfx('tick'); api.buzz(6); } : null);
      const lw = Math.min(180, I.w * 0.55);
      btn(I.x + (I.w - lw) / 2, Math.min(I.y + I.h - 48, kcy + kr + 12), lw, 46, '고정', live ? () => { api.buzz(15); act({ t: 'vl', m: mi, v: u.v }); } : null, { c1: '#7a5a2a', c2: '#4f3a1a' });
    }
    /* --- memory --- */
    function drawMemory(I, m, mi, live) {
      const st2 = Math.min(m.s, 2), dw = Math.min(I.w * 0.55, 180), dh = Math.min(I.h * 0.34, 120), dx = I.x + (I.w - dw) / 2 - 16, dy = I.y + 6;
      ctx.fillStyle = '#0d1a1f'; rrect(ctx, dx, dy, dw, dh, 10); ctx.fill(); ctx.strokeStyle = '#2b4450'; ctx.lineWidth = 2; ctx.stroke();
      ctx.save(); ctx.shadowColor = '#6fe3ff'; ctx.shadowBlur = 12;
      txt(ctx, m.ok ? '–' : m.d[st2], dx + dw / 2, dy + dh / 2 + 4, '#a8efff', Math.round(dh * 0.62) + 'px ' + DISP); ctx.restore();
      for (let k = 0; k < 3; k++) { const on = k < m.s; const y = dy + 12 + k * (dh - 24) / 2; ctx.save(); if (on) { ctx.shadowColor = '#5fe08a'; ctx.shadowBlur = 8; } ctx.fillStyle = on ? '#5fe08a' : '#2a2a28'; rrect(ctx, dx + dw + 14, y - 6, 26, 12, 4); ctx.fill(); ctx.restore(); }
      const bw = Math.min(70, (I.w - 30) / 4), gap = (I.w - bw * 4) / 5, by = dy + dh + 22, bh = Math.min(110, I.y + I.h - by - 4);
      const lab = m.l.slice(st2 * 4, st2 * 4 + 4);
      for (let k = 0; k < 4; k++) {
        const x = I.x + gap + k * (bw + gap);
        btn(x, by, bw, bh, lab[k], live ? () => { api.buzz(12); act({ t: 'mem', m: mi, i: k }); } : null, { c1: '#d8d0bb', c2: '#b0a68c', ink: '#1d1712', font: '32px ' + DISP });
      }
    }
    function shade(hex, k) {
      const mm = /^#?([0-9a-f]{6})$/i.exec(hex); if (!mm) return hex;
      const n = parseInt(mm[1], 16), f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
      return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
    }

    /* ======================= manual (experts) ======================= */
    function mkCanvas(w, h, drawFn) {
      const dpr = Math.min(2, window.devicePixelRatio || 1), c = L.h('canvas', { style: { width: w + 'px', height: h + 'px' } });
      c.width = Math.round(w * dpr); c.height = Math.round(h * dpr);
      const g = c.getContext('2d'); g.scale(dpr, dpr); drawFn(g); return c;
    }
    function sw(col) { return L.h('span', { class: 'sw', style: { background: WCOL[col] } }); }
    function pages() {
      const P = [];
      const sec = (h, ...kids) => [L.h('h3', { text: h }), ...kids];
      const p = (t) => L.h('p', { text: t });
      const look = (t) => L.h('p', { class: 'look', text: '생김새 — ' + t });
      const tbl = (head, rows) => L.h('table', null, head ? L.h('tr', null, head.map((x) => L.h('th', { text: x }))) : null, rows.map((r) => L.h('tr', null, r.map((x) => L.h('td', null, x)))));
      const ol = (items) => L.h('ol', null, items.map((x) => L.h('li', null, x)));
      P.push(['기본', '해체 설명서', [
        p('이 설명서는 폭탄을 보지 못하는 사람을 위한 것이에요. 해체 담당에게 무엇이 보이는지 묻고, 아래 규칙대로 지시해 주세요.'),
        ...sec('진행', ol(['폭탄에는 모듈이 4~6개 있어요. 모듈마다 오른쪽 위 불빛이 초록이 되면 해체 완료.', '모든 모듈을 해체하면 성공! 경고가 3번 쌓이거나 시간이 다 되면 폭발해요.', '해체 담당은 아래 탭으로 모듈을 오가요. 어떤 모듈인지는 ‘생김새’로 알아보세요.'])),
        ...sec('폭탄 겉면 정보', tbl(['항목', '설명'], [
          [L.h('span', { class: 'nw', text: '시리얼 번호' }), '흰 스티커의 6자리. 마지막 글자는 항상 숫자예요. 모음은 A·E·I·O·U.'],
          [L.h('span', { class: 'nw', text: '배터리' }), '파란 원통 0~4개.'],
          [L.h('span', { class: 'nw', text: '램프' }), '이름표가 붙은 램프 2개(전원·냉각·통신·경보·예비 중). 켜짐/꺼짐을 꼭 물어보세요. 폭탄에 없는 램프는 꺼진 것으로 봐요.'],
          [L.h('span', { class: 'nw', text: '타이머' }), '분:초. ‘초의 일의 자리’는 맨 오른쪽 숫자예요.'],
        ])),
        L.h('p', { class: 'tip', text: '팁: 시작하자마자 시리얼·배터리·램프를 먼저 받아 적어 두면 빨라요.' }),
      ]]);
      P.push(['전선', KNAME.w, [
        look('색 전선 3~6개가 왼쪽·오른쪽 단자 사이에 걸려 있어요.'),
        p('전선은 위에서부터 1번이에요. 전선 개수에 맞는 표를 위에서부터 읽어 처음으로 맞는 줄대로 하나만 자르세요.'),
        L.h('p', null, '색: ', sw('R'), '빨강 ', sw('B'), '파랑 ', sw('Y'), '노랑 ', sw('K'), '검정 ', sw('W'), '흰색'),
        ...sec('3개', tbl(null, [['검정이 없으면', '2번'], ['시리얼 마지막 숫자가 짝수면', '첫 번째 검정'], ['그 밖에는', '3번(마지막)']])),
        ...sec('4개', tbl(null, [['노랑이 딱 1개면', '그 노랑'], ['배터리 2개 이상이고 파랑이 있으면', '마지막 파랑'], ['1번이 흰색이면', '2번'], ['그 밖에는', '1번']])),
        ...sec('5개', tbl(null, [['빨강이 없고 ‘경보’ 램프가 켜져 있으면', '4번'], ['같은 색이 3개 이상이면', '그 색의 마지막 전선'], ['5번이 검정이면', '3번'], ['그 밖에는', '1번']])),
        ...sec('6개', tbl(null, [['흰색이 없으면', '3번'], ['시리얼에 모음이 있으면', '첫 번째 흰색'], ['파랑이 노랑보다 많으면', '6번'], ['그 밖에는', '4번']])),
        p('틀린 전선을 자르면 경고 1개. 정답 전선은 그래도 잘라야 해요. (전선은 두 번 눌러야 잘려요.)'),
      ]]);
      P.push(['버튼', KNAME.b, [
        look('글자가 쓰인 커다란 둥근 버튼 하나와, 오른쪽에 세로 불빛 띠.'),
        ...sec('1. 짧게? 길게?', p('위에서부터 처음 맞는 줄을 따르세요.'), tbl(null, [
          ['글자가 ‘해제’이고 배터리가 1개 이상', '짧게'], ['버튼이 노랑', '길게'], ['버튼이 빨강이고 시리얼 마지막 숫자가 홀수', '짧게'], ['램프 2개가 모두 켜짐', '짧게'], ['그 밖에는', '길게']])),
        ...sec('2. 길게 누를 때', p('누르고 있으면 띠에 불이 들어와요. 띠 색을 물어보고, 타이머의 ‘초’ 일의 자리가 아래 숫자일 때 손을 떼게 하세요.'),
          tbl(['띠 색', '뗄 때'], [[L.h('span', null, sw('R'), '빨강'), '…3'], [L.h('span', null, sw('B'), '파랑'), '…5'], [L.h('span', null, sw('Y'), '노랑'), '…0'], [L.h('span', null, sw('W'), '흰색'), '…7']])),
        p('짧게 = 눌렀다 바로 떼기. 틀리면 경고 1개.'),
      ]]);
      P.push(['기호', KNAME.s, [
        look('기호가 그려진 정사각 버튼 4개(2×2).'),
        p('네 기호가 모두 들어 있는 세로줄은 딱 하나예요. 그 줄에서 위에 있는 기호부터 차례로 누르게 하세요. 순서가 틀리면 경고 1개.'),
        mkCanvas(330, 7 * 44 + 26, (g) => {
          const cw = 330 / 5;
          COLS.forEach((col, ci) => {
            g.fillStyle = 'rgba(90,60,30,.12)'; g.fillRect(ci * cw + 3, 0, cw - 6, 7 * 44 + 26);
            g.font = '800 13px ' + FONT; g.fillStyle = '#5a2a1c'; g.textAlign = 'center'; g.fillText('가나다라마'[ci] + '줄', ci * cw + cw / 2, 15);
            col.forEach((gid, k) => glyph(g, gid, ci * cw + cw / 2, 26 + k * 44 + 20, 15, '#2a2018', 2.4));
          });
        }),
      ]]);
      P.push(['다이얼', KNAME.p, [
        look('글자 다이얼 3칸(위아래 화살표)과 ‘확인’ 버튼.'),
        p('다이얼마다 글자 5개가 돌아가요. 아래 단어 중 세 다이얼로 만들 수 있는 단어는 딱 하나예요. 맞춘 뒤 ‘확인’. 틀리면 경고 1개.'),
        L.h('p', { class: 'tip', text: '팁: 첫째 칸 글자 5개를 모두 불러 달라고 하면 후보가 확 줄어요.' }),
        L.h('div', { class: 'grid2', style: { gridTemplateColumns: 'repeat(4,1fr)', fontWeight: 700, fontSize: '15px' } }, WORDS.slice().sort().map((w) => L.h('span', { text: w }))),
      ]]);
      P.push(['미로', KNAME.m, [
        look('6×6 점판. 초록 고리 2개, 흰 네모(현재 위치), 빨간 세모(목표). 가장자리에 A~F, 1~6 좌표.'),
        p('초록 고리의 위치로 아래 지도 중 하나를 찾고, 흰 네모를 빨간 세모까지 화살표로 안내하세요. 벽(굵은 선)이나 바깥으로 가려 하면 경고 1개(제자리). 벽은 해체 담당 화면에 보이지 않아요.'),
        L.h('div', { class: 'grid2' }, MAZES.map((cells, z) => mkCanvas(156, 166, (g) => drawMazeMap(g, z, 156)))),
      ]]);
      P.push(['모스', KNAME.o, [
        look('깜빡이는 노란 불빛, 주파수 표시와 ◀ ▶, ‘송신’ 버튼.'),
        p('불빛이 영어 단어를 모스 부호로 되풀이해요. 짧은 빛 = 점(·), 긴 빛 = 선(−). 글자 사이엔 조금 쉬고, 단어가 끝나면 길게 쉬어요. 단어를 찾아 표의 주파수로 맞추고 송신. 틀리면 경고 1개.'),
        L.h('div', { class: 'grid2' },
          tbl(['단어', '주파수'], MWORDS.map((w, i) => [w, FREQS[MFREQ[i]] + ' MHz']).slice(0, 6)),
          tbl(['단어', '주파수'], MWORDS.map((w, i) => [w, FREQS[MFREQ[i]] + ' MHz']).slice(6))),
        ...sec('모스 부호표', L.h('div', { class: 'grid2 mono', style: { gridTemplateColumns: 'repeat(3,1fr)', gap: '2px 8px', fontSize: '14px' } },
          Object.keys(MORSE).map((ch) => L.h('span', null, L.h('b', { text: ch + ' ' }), MORSE[ch].replace(/\./g, '·').replace(/-/g, '−'))))),
      ]]);
      P.push(['밸브', KNAME.v, [
        look('바늘 계기판(바탕색과 두 자리 숫자)과 0~4 눈금의 빨간 밸브, ‘고정’ 버튼.'),
        p('아래 점수를 모두 더한 뒤 5로 나눈 나머지 눈금에 밸브를 맞추고 ‘고정’. 틀리면 경고 1개.'),
        tbl(['항목', '점수'], [
          ['계기판 바탕색', '흰색 0 · 노랑 2 · 검정 4'], ['배터리', '개수만큼'], ['계기판 숫자가 50 이상', '+1'], ['켜진 램프', '개수만큼'],
        ]),
        L.h('p', { class: 'tip', text: '예: 노랑(2) + 배터리 3 + 숫자 72(+1) + 켜진 램프 1 = 7 → 5로 나눈 나머지 2 → 눈금 2' }),
      ]]);
      P.push(['기억', KNAME.n, [
        look('큰 숫자 화면, 숫자가 쓰인 버튼 4개, 단계 불빛 3개.'),
        p('‘위치’는 왼쪽부터 1~4번째 버튼, ‘숫자’는 버튼에 쓰인 숫자예요. 화면 숫자를 보고 단계마다 하나씩 누르게 하세요. 누를 때마다 무엇을 눌렀는지(위치와 숫자) 적어 두세요.'),
        ...sec('1단계', tbl(['화면', '누를 것'], [['1', '2번째 위치'], ['2', '숫자 4'], ['3', '4번째 위치'], ['4', '숫자 1']])),
        ...sec('2단계', tbl(['화면', '누를 것'], [['1', '1단계에서 누른 숫자'], ['2', '1번째 위치'], ['3', '1단계와 같은 위치'], ['4', '숫자 2']])),
        ...sec('3단계', tbl(['화면', '누를 것'], [['1', '2단계와 같은 위치'], ['2', '1단계에서 누른 숫자'], ['3', '숫자 3'], ['4', '3번째 위치']])),
        p('틀리면 경고 1개, 그리고 숫자가 모두 바뀐 채 1단계부터 다시 해요.'),
      ]]);
      return P;
    }
    function drawMazeMap(g, z, size) {
      const pad = 18, c = (size - pad - 6) / MZ, ox = pad, oy = pad + 6;
      g.fillStyle = '#fbf5e6'; g.fillRect(ox, oy, c * MZ, c * MZ);
      g.font = '700 10px ' + MONO; g.fillStyle = '#5a2a1c'; g.textAlign = 'center'; g.textBaseline = 'middle';
      for (let i = 0; i < MZ; i++) { g.fillText('ABCDEF'[i], ox + c * i + c / 2, oy - 8); g.fillText(String(i + 1), ox - 9, oy + c * i + c / 2); }
      g.fillText('지도 ' + (z + 1), size - 26, 7);
      for (let k = 0; k < MZ * MZ; k++) {
        const x = ox + (k % MZ) * c, y = oy + Math.floor(k / MZ) * c;
        g.fillStyle = '#b5a88c'; g.beginPath(); g.arc(x + c / 2, y + c / 2, 1.6, 0, 7); g.fill();
        if (MKR[z].includes(k)) { g.strokeStyle = '#2f8a4a'; g.lineWidth = 2.4; g.beginPath(); g.arc(x + c / 2, y + c / 2, c * 0.34, 0, 7); g.stroke(); }
        g.strokeStyle = '#2a2018'; g.lineWidth = 2.6; g.lineCap = 'round';
        const v = MAZES[z][k];
        g.beginPath();
        if (!(v & 1)) { g.moveTo(x, y); g.lineTo(x + c, y); }
        if (!(v & 2)) { g.moveTo(x + c, y); g.lineTo(x + c, y + c); }
        if (!(v & 4)) { g.moveTo(x, y + c); g.lineTo(x + c, y + c); }
        if (!(v & 8)) { g.moveTo(x, y); g.lineTo(x, y + c); }
        g.stroke();
      }
    }
    function buildManual() {
      if (manual) return;
      const P = pages();
      const hud = L.h('div', { class: 'bm-hud' });
      const tm = L.h('div', { class: 'tm' }), info = L.h('div', { class: 'info' }), xs = L.h('div', { class: 'xs' }, [0, 1, 2].map(() => L.h('i', { text: '✕' })));
      hud.append(tm, info, xs);
      const tabs = L.h('div', { class: 'bm-tabs' });
      const page = L.h('div', { class: 'bm-page' });
      const btns = P.map((pp, k) => L.h('button', { text: pp[0], onclick() { show(k); api.sfx('click'); } }));
      tabs.append(...btns);
      function show(k) {
        pageIx = k;
        btns.forEach((b, j) => b.classList.toggle('on', j === k));
        page.innerHTML = '';
        page.append(L.h('div', { class: 'bm-paper' }, L.h('span', { class: 'stamp', text: '기밀' }), L.h('span', { class: 'label', style: { color: '#8a6a3a' }, text: '해체 설명서 · ' + (k + 1) + '/' + P.length }), L.h('h2', { text: P[k][1] }), ...P[k][2],
          L.h('div', { style: { display: 'flex', justifyContent: 'space-between', marginTop: '14px', gap: '8px' } },
            k > 0 ? L.h('button', { class: 'btn sm', text: '‹ ' + P[k - 1][0], onclick() { show(k - 1); } }) : L.h('span'),
            k < P.length - 1 ? L.h('button', { class: 'btn sm', text: P[k + 1][0] + ' ›', onclick() { show(k + 1); } }) : L.h('span'))));
        page.scrollTop = 0;
        try { btns[k].scrollIntoView({ inline: 'nearest', block: 'nearest' }); } catch (e) {}
      }
      const el = L.h('div', { class: 'bm-man' }, hud, tabs, page);
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      manual = { el, tm, info, xs, show, page };
      show(pageIx);
    }
    function dropManual() { if (manual) { manual.el.remove(); manual = null; } }
    function hudUpdate() {
      if (!manual || !st) return;
      const secs = shownSecs();
      manual.tm.textContent = fmt(secs);
      manual.tm.classList.toggle('calm', st.ph !== 'run');
      const solvedN = st.M.filter((m) => m.ok).length;
      const sig = st.ph + '|' + st.df + '|' + solvedN + '|' + st.rd;
      if (manual.sig !== sig) {
        manual.sig = sig;
        manual.info.innerHTML = '';
        manual.info.append(L.h('b', { text: '해체 담당: ' + nm(st.df) }),
          L.h('span', { text: st.ph === 'brief' ? '시작을 기다리는 중 · 설명서를 미리 펴 두세요' : st.ph === 'run' ? '해체 ' + solvedN + '/' + st.M.length + ' · ' + (st.rd + 1) + '/' + st.rds + '번째 폭탄' : '라운드 끝' }));
      }
      [...manual.xs.children].forEach((x, k) => x.classList.toggle('on', k < st.x));
    }

    /* ----- round end panel ----- */
    function syncEnd() {
      const want = st && st.ph === 'end' && (performance.now() - boomT > 2200 / SPD() || !boomT);
      if (!want) { if (endEl) { endEl.remove(); endEl = null; } return; }
      const sig = st.rd + '|' + st.rs;
      if (endEl && endEl.sig === sig) return;
      if (endEl) endEl.remove();
      const out = st.rs[st.rs.length - 1], nx = st.hm[(st.st0 + st.rd + 1) % st.hm.length];
      const mine = api.mySeats().some((s) => st.hm.includes(s));
      endEl = L.h('div', { class: 'bm-end' },
        L.h('span', { class: 'label', text: (st.rd + 1) + '/' + st.rds + '번째 폭탄' }),
        L.h('h3', { text: out === 'W' ? '해체 성공!' : out === 'B' ? '쾅! 폭발했어요' : '중단됐어요', style: { color: out === 'W' ? '#5fe08a' : '#ff6a4a' } }),
        L.h('p', { text: (out === 'W' ? '남은 시간 ' + fmt(st.left || 0) + ' · 경고 ' + st.x + '번. ' : out === 'B' ? (st.x >= 3 ? '경고 3번' : '시간 초과') + '. ' : '해체 담당이 나갔어요. ') + '다음 해체 담당은 ' + nm(nx) + '님이에요.' }),
        mine ? L.h('button', { class: 'btn primary block', text: '다음 폭탄', onclick() { api.sfx('click'); act({ t: 'next' }); } }) : null);
      endEl.sig = sig;
      endEl.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(endEl);
    }

    /* ----- FX ----- */
    function spark(x, y, n, cols, spd) { for (let k = 0; k < n; k++) { const a = Math.random() * Math.PI * 2, v = (0.3 + Math.random()) * (spd || 260); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, life: 0.5 + Math.random() * 0.7, t: 0, c: cols[k % cols.length], r: 1.5 + Math.random() * 2.5 }); } }
    function onEvent(prev) {
      const ev = st.last;
      if (!ev || ev.id === lastId) return;
      const first = lastId < 0; lastId = ev.id;
      if (first && ev.k !== 'go') return;
      const W = cv.w, H = cv.h, Lr = layout(), mx = Lr.mod.x + Lr.mod.w / 2, my = Lr.mod.y + Lr.mod.h / 2;
      if (ev.k === 'strike') {
        flash = { t: 0.6, col: 'r', m: ev.m }; shake = 0.4; Snd.zap(); api.buzz([90, 40, 90]);
        spark(isDef() ? mx : W / 2, isDef() ? my : 60, 36, ['#ffd27a', '#ff6a3a', '#fff'], 320);
        banner = { t: 1.2, text: '경고 ' + st.x + '/3', col: '#ff6a4a' };
      } else if (ev.k === 'ok') {
        Snd.chime([660, 880, 1320]); api.buzz(30);
        if (isDef()) { spark(Lr.mod.x + Lr.mod.w - 18, Lr.mod.y + 18, 24, ['#5fe08a', '#d6ffd9'], 200); setTimeout(() => { if (!st || st.ph !== 'run') return; const nx = st.M.findIndex((m, k) => !m.ok && k > cur); const any = nx >= 0 ? nx : st.M.findIndex((m) => !m.ok); if (any >= 0) { cur = any; armed = null; } }, 700 / SPD()); }
        else banner = { t: 1.2, text: '모듈 해체!', col: '#5fe08a' };
      } else if (ev.k === 'step') { api.sfx('pop'); }
      else if (ev.k === 'go') { api.sfx('pop'); api.buzz(40); banner = { t: 1.1, text: '타이머 시작!', col: '#e3ae45' }; }
      else if (ev.k === 'boom') {
        boomT = performance.now(); shake = 1.6; Snd.boom(); api.buzz([300, 80, 400]);
        flash = { t: 1.2, col: 'w' };
        for (let k = 0; k < 4; k++) spark(W / 2 + (Math.random() - 0.5) * 80, H / 2 + (Math.random() - 0.5) * 80, 60, ['#fff3b0', '#ffb347', '#ff5a1f', '#6b5b4d', '#2b2420'], 520);
        banner = { t: 2.4, text: '쾅!', col: '#ffb347', big: 1 };
        holdBusy(2400);
      } else if (ev.k === 'win') {
        winT = performance.now(); Snd.chime([523, 659, 784, 1046, 1318]); api.buzz([40, 40, 80]);
        for (let k = 0; k < 120; k++) parts.push({ x: Math.random() * W, y: -20 - Math.random() * H * 0.4, vx: (Math.random() - 0.5) * 60, vy: 120 + Math.random() * 160, life: 2.6, t: 0, c: ['#5fe08a', '#e3ae45', '#5bb3e6', '#f2e9d8', '#ee6a55'][k % 5], r: 3 + Math.random() * 2, cf: 1, rot: Math.random() * 6 });
        banner = { t: 2.4, text: '해체 성공!', col: '#5fe08a', big: 1 };
        holdBusy(2000);
      } else if (ev.k === 'left') { banner = { t: 1.8, text: '해체 담당이 나갔어요', col: '#ab9fb8' }; }
      void prev;
    }
    function holdBusy(ms) { if (st && st.ph === 'done') { api.setBusy(true); busyT = performance.now() + ms / SPD(); } }
    function drawFx(dt) {
      fx.clear();
      const W = fx.w, H = fx.h;
      if (flash.t > 0) {
        flash.t -= dt;
        fctx.fillStyle = flash.col === 'w' ? 'rgba(255,245,220,' + Math.min(1, flash.t) + ')' : 'rgba(255,40,20,' + Math.min(0.35, flash.t * 0.6) + ')';
        fctx.fillRect(0, 0, W, H);
      }
      if (boomT && performance.now() - boomT < 2600 / SPD()) {
        const k = (performance.now() - boomT) / 1000 * SPD();
        const r = Math.min(Math.max(W, H), 60 + k * 900);
        const g = fctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, r);
        g.addColorStop(0, 'rgba(255,240,180,' + Math.max(0, 0.9 - k * 0.4) + ')'); g.addColorStop(0.35, 'rgba(255,140,40,' + Math.max(0, 0.8 - k * 0.35) + ')'); g.addColorStop(1, 'rgba(40,20,10,' + Math.max(0, 0.7 - k * 0.2) + ')');
        fctx.fillStyle = g; fctx.fillRect(0, 0, W, H);
      }
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.t += dt;
        if (p.t > p.life) { parts.splice(i, 1); continue; }
        p.x += p.vx * dt; p.y += p.vy * dt; p.vy += (p.cf ? 20 : 380) * dt;
        fctx.globalAlpha = Math.max(0, 1 - p.t / p.life);
        fctx.fillStyle = p.c;
        if (p.cf) { fctx.save(); fctx.translate(p.x, p.y); fctx.rotate(p.rot + p.t * 6); fctx.fillRect(-p.r, -p.r / 2, p.r * 2, p.r); fctx.restore(); }
        else { fctx.beginPath(); fctx.arc(p.x, p.y, p.r, 0, 7); fctx.fill(); }
      }
      fctx.globalAlpha = 1;
      if (banner && banner.t > 0) {
        banner.t -= dt;
        const a = Math.min(1, banner.t * 3), sz = banner.big ? 64 : 30;
        fctx.save(); fctx.globalAlpha = a; fctx.font = sz + 'px ' + DISP; fctx.textAlign = 'center'; fctx.textBaseline = 'middle';
        const y = banner.big ? H * 0.42 : H * 0.3, bw2 = fctx.measureText(banner.text).width + 40;
        fctx.fillStyle = 'rgba(16,12,22,.72)'; rrect(fctx, W / 2 - bw2 / 2, y - sz * 0.75, bw2, sz * 1.5, 16); fctx.fill();
        fctx.lineWidth = 6; fctx.strokeStyle = 'rgba(10,8,16,.85)';
        fctx.strokeText(banner.text, W / 2, y); fctx.fillStyle = banner.col; fctx.fillText(banner.text, W / 2, y); fctx.restore();
      }
    }

    /* ----- local (one phone): explain ----- */
    function syncBlock() {
      if (api.online || blockEl) return;
      blockEl = L.h('div', { class: 'bm-block' },
        L.h('h3', { text: '폭탄 해체반은 각자 폰이 필요해요' }),
        L.h('p', { text: '해체 담당만 폭탄을 보고, 나머지는 자기 폰으로 설명서를 봐야 하는 게임이라 한 폰으로는 할 수 없어요.' }),
        L.h('p', { text: '홈에서 ‘온라인 방 만들기’나 ‘LAN 방 만들기’로 방을 열고, 친구들이 각자 폰으로 들어오면 시작하세요.' }),
        L.h('button', { class: 'btn', text: '설명서 미리 읽어 보기', onclick() { blockEl.remove(); blockEl = 'seen'; buildManual(); if (manual) { manual.tm.textContent = '연습'; manual.info.innerHTML = ''; manual.info.append(L.h('b', { text: '설명서 미리 보기' }), L.h('span', { text: '실제 게임은 온라인/LAN 방에서 해요' })); manual.sig = 'preview'; } } }),
        L.h('p', { class: 'note', style: { fontSize: '12.5px' }, text: '왼쪽 위 ‹ 버튼으로 나갈 수 있어요.' }));
      blockEl.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(blockEl);
    }

    /* ----- loop ----- */
    const hostTimer = setInterval(() => {
      if (!st || !api.isHost || !api.online) return;
      let nx = null;
      try { nx = tick(U.clone(st), clock.now(), (i) => !!(api.players[i] && api.players[i].ai)); } catch (e) { console.error(e); }
      if (nx) api.setState(nx);
    }, 200);
    const stop = U.loop((rdt, now) => {
      if (!st) return;
      const dt = rdt * SPD();
      if (busyT && performance.now() > busyT) { busyT = 0; api.setBusy(false); }
      if (!api.online) { cv.clear(); ctx.fillStyle = '#16121b'; ctx.fillRect(0, 0, cv.w, cv.h); if (manual && manual.sig !== 'preview') hudUpdate(); drawFx(dt); return; }
      const run = st.ph === 'run';
      // ticking (twice a second in the last 30 s)
      const secs = shownSecs();
      const q = run ? Math.floor(remainNow() * (secs <= 30 ? 2 : 1)) : -1;
      if (q !== lastSec) { if (run && lastSec >= 0 && q < lastSec) Snd.tick(secs <= 30); lastSec = q; }
      const def = isDef() && st.ph !== 'x';
      if (def) dropManual(); else if (st.ph !== 'x') buildManual();
      cv.clear();
      ctx.save();
      if (shake > 0) { shake = Math.max(0, shake - dt * 2); ctx.translate((Math.random() - 0.5) * shake * 16, (Math.random() - 0.5) * shake * 16); }
      if (def) drawBomb(now);
      else { ctx.fillStyle = '#16121b'; ctx.fillRect(0, 0, cv.w, cv.h); }
      ctx.restore();
      hudUpdate();
      syncEnd();
      drawFx(dt);
    });
    return {
      update(next, prev) {
        if (!next) return;
        const was = st;
        st = next;
        if (st.ts !== recv.ts) recv = { ts: st.ts, at: performance.now() };
        pend = 0;
        const rk = st.rd + '.' + st.sd;
        if (rk !== roundKey) { roundKey = rk; ui = {}; cur = 0; armed = null; hold = null; lastSec = -1; boomT = 0; winT = 0; if (was) { parts = []; } }
        if (cur >= st.M.length) cur = 0;
        syncBlock();
        onEvent(prev);
        if (st.ph === 'done' && was && was.ph === 'done') { /* re-render */ }
      },
      destroy() {
        stop(); clearInterval(hostTimer);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('contextmenu', noCtx);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onCancel);
        api.setBusy(false);
        dropManual(); if (endEl) endEl.remove(); if (blockEl && blockEl.remove) blockEl.remove();
        styleEl.remove(); cv.destroy(); fx.destroy(); Snd.close();
      },
      _dbg: () => ({ st, cur, setCur: (k) => { cur = k; }, shownSecs, ui, manual: () => manual, showPage: (k) => manual && manual.show(k) }),
    };
  }

  L.register({
    id: 'bomb', name: '폭탄 해체반', tag: '협동 해체', cat: '파티', noAI: true,
    blurb: '한 명만 폭탄을 보고, 나머지는 각자 폰의 해체 설명서를 보며 말로 해체를 이끌어요. 경고 3번이나 시간이 다 되면 쾅! 각자 폰이 필요해요(온라인·LAN 방).',
    tint: '#5a2a1e',
    icon: '<circle cx="24" cy="34" r="15" fill="currentColor"/><rect x="20" y="15" width="9" height="7" rx="2" fill="currentColor"/><path d="M25 16c2-6 8-8 13-5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M42 6l2 4M48 10l-4 2M46 4l-2 4" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><path d="M16 30a9 9 0 016-6" fill="none" stroke="#5a2a1e" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 3, hidden: false, aiDelay: 650,
    options: [
      { id: 'time', label: '제한 시간', choices: [{ v: 180, label: '3분' }, { v: 300, label: '5분' }], def: 300 },
      { id: 'dif', label: '난이도 (모듈 수)', choices: [{ v: 1, label: '쉬움 · 4개' }, { v: 2, label: '보통 · 5개' }, { v: 3, label: '어려움 · 6개' }], def: 2 },
      { id: 'rounds', label: '판 수', choices: [{ v: 0, label: '모두 한 번씩 해체' }, { v: 1, label: '1판' }], def: 0 },
    ],
    quick: [
      '협동 게임: 해체 담당 1명만 폭탄을 보고, 나머지는 각자 폰의 해체 설명서만 봐요(각자 폰 필요 · 온라인/LAN 방).',
      '해체 담당은 보이는 것을 말로 설명하고, 설명서 담당은 규칙을 찾아 무엇을 자르고 누를지 알려 줘요.',
      '모듈을 모두 풀면 해체 성공! 경고 3번이나 시간 0이면 쾅. 폭탄을 절반 이상 해체하면 모두의 승리예요.',
    ],
    rules: [
      { h: '목표', p: [
        '모두 한 팀인 협동 게임이에요.',
        '해체 담당 한 명만 폭탄을 봐요. 나머지(설명서 담당)는 각자 폰에 뜨는 해체 설명서만 볼 수 있어요. 서로의 화면은 보면 안 돼요!',
        '말로 주고받으며 폭탄의 모듈을 모두 해체하면 성공이에요.'] },
      { h: '준비', p: [
        '각자 폰이 필요해요: 온라인 방이나 LAN 방에서 2~6명. 한 폰으로 시작하면 설명서만 미리 읽어 볼 수 있어요.',
        '설정에서 제한 시간(3분 · 5분), 난이도(모듈 4 · 5 · 6개), 판 수(모두 한 번씩 · 1판)를 골라요.',
        '판마다 해체 담당이 돌아가요. 처음엔 설명서를 미리 훑어보면 좋아요.'] },
      { h: '할 일 — 해체 담당', p: [
        '① 준비되면 「타이머 시작」을 눌러요. 그때부터 시간이 흘러요.',
        '② 폭탄 겉면(시리얼 번호 · 배터리 · 램프)과 지금 모듈 모양을 말로 설명해요.',
        '③ 동료가 알려 주는 대로 자르고 · 누르고 · 돌려요.',
        '아래 탭으로 모듈을 오가요. 해체한 모듈은 초록 불이 켜져요.'] },
      { h: '할 일 — 설명서 담당', p: [
        '① 먼저 시리얼 번호 · 배터리 수 · 램프 켜짐/꺼짐을 물어봐요. 정답이 이것에 따라 달라져요.',
        '② 해체 담당이 말하는 모듈의 설명서 쪽을 찾아 규칙을 따라가요.',
        '③ 「무엇을 · 몇 번째를 · 언제」 하라고 정확히 알려 줘요.'] },
      { h: '점수·승리', p: [
        '모듈을 모두 해체하면 그 폭탄은 해체 성공!',
        '틀린 조작은 경고 1개. 경고가 3번 쌓이거나 타이머가 0이 되면 폭발해요.',
        '「모두 한 번씩 해체」(기본): 사람 수만큼 폭탄을 풀어요. 절반 이상 해체하면 모두의 승리예요.',
        '「1판」: 그 폭탄 하나를 해체하면 승리.'] },
      { h: '폭탄과 모듈', p: [
        '모듈 4~6개(난이도에 따라)가 다음 중에서 무작위로 나와요: 전선 자르기 · 큰 버튼 · 기호 순서 · 비밀번호 다이얼 · 미로 · 모스 신호 · 계기판 밸브 · 숫자 기억.',
        '모듈마다 자세한 규칙은 설명서에 있어요.'] },
      { h: '조작 (해체 담당)', p: [
        '전선은 실수 방지를 위해 같은 전선을 두 번 눌러야 잘려요.',
        '큰 버튼은 짧게 누르거나, 꾹 누르고 있다가 알맞은 때에 떼요.'] },
      { h: '특수 규칙', p: [
        '사람끼리만 하는 게임이라 AI 자리는 건너뛰어요.',
        '해체 담당이 나가면 그 판은 중단돼요.'] },
      { h: '예시', p: [
        '해체 담당: 「시리얼 끝자리 7, 배터리 2개, 전선은 빨강 · 파랑 · 파랑 · 흰색 4개야.」',
        '설명서 담당: (전선 자르기 쪽을 보고) 「4개일 때… 노란 전선이 딱 1개는 아니고, 배터리가 2개 이상에 파란 전선이 있으니 마지막 파란 전선을 잘라!」',
        '해체 담당이 그 전선을 두 번 눌러 자르면 초록 불 → 다음 모듈로!'] },
    ],
    init, actor, apply, result, mount,
    ai: () => null,
    aiDelayFor: () => -1,
    _t: { clock, genBomb, genModule, genEdge, wireSol, btnSol, symCol, symOrder, pwMatches, valveSol, memTarget, memNew, solveStep, tick, remain, mzDist, mzPath, MAZES, MKR, COLS, WORDS, MWORDS, MFREQ, FREQS, MORSE, KINDS, prng, init, actor, apply, result, newRound },
  });
})();
