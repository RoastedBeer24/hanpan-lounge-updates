/* 야구 타격 대결 — 홈런 더비식 타격 대결. 타자마다 정해진 공 수(10/15) 또는 3아웃까지 친다.
   투수(기계 또는 PvP에서 상대)가 공 종류·코스를 정하면, 타자 기기가 공이 홈플레이트에 도착하는 순간과 탭한 순간의
   차이(e, ms; 음수 = 이름)와 겨냥(땅볼/라이너/뜬공)을 보낸다. apply가 이를 검증해 타구 속도·발사각·방향을 정하고
   결정적 비행 시뮬레이션(중력+공기 저항, 펜스·관중석·바운드)으로 결과를 낸다. 뷰는 last.bb로 같은 비행을 재생한다.
   좌표(m): 홈플레이트 원점, x = 3루(왼쪽) −/1루(오른쪽) +, y = 투수·외야 쪽, z = 위. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }
  const DEG = Math.PI / 180;

  /* ---------- pitches ---------- */
  const PT = [
    { n: '직구', v: [142, 150], bx: 0.03, bz: -0.08, c: '#f2e9d8' },
    { n: '커브', v: [106, 116], bx: -0.18, bz: 0.95, c: '#9fc6ff' },
    { n: '슬라이더', v: [124, 132], bx: 0.42, bz: 0.28, c: '#ffd27a' },
    { n: '체인지업', v: [114, 122], bx: -0.2, bz: 0.4, c: '#ffb0a0' },
  ];
  const ZX = [-0.17, 0, 0.17], ZZ = [0.95, 0.75, 0.55]; // zone cells: c = row*3 + col (row 0 = high)
  const ZN = ['몸쪽 높게', '가운데 높게', '바깥쪽 높게', '몸쪽', '한가운데', '바깥쪽', '몸쪽 낮게', '가운데 낮게', '바깥쪽 낮게'];
  const MOUND = 18.44, REL = { x: 0.45, y: 17.2, z: 1.85 };
  function pitchT(pc) { return (REL.y / (pc.v / 3.6)) * 1.06; }
  /* ball position along the pitch, u = 0 (release) … 1 (front of the plate) */
  function pitchPos(pc, u) {
    const P = PT[pc.t];
    const ex = pc.x, ez = pc.z;
    const sx = ex - P.bx, sz = ez + P.bz;            // where it would go without break
    const x = REL.x + (sx - REL.x) * u + P.bx * u * u;
    const z = REL.z + (sz - REL.z) * u - P.bz * u * u - 0.1 * u * (1 - u) * 0;
    return [x, REL.y * (1 - u), z];
  }

  /* ---------- batted-ball flight ---------- */
  const KD = 0.0045, GR = 9.81, FDT = 1 / 120, FH = 3;
  const fenceR = (ph) => 98 + 17 * Math.cos(2 * U.clamp(ph, -45 * DEG, 45 * DEG));
  /* bb = [exit km/h, launch deg, spray deg (−: left/pull)] → path sampled at 30 Hz + outcome */
  function fly(bb) {
    const v = bb[0] / 3.6, la = bb[1] * DEG, ph = bb[2] * DEG;
    const fx = Math.sin(ph), fy = Math.cos(ph), R = fenceR(ph);
    let x = 0, y = 0.3, z = 0.9, vh = v * Math.cos(la), vz = v * Math.sin(la), r = 0.3, t = 0;
    let land = -1, hr = 0, wall = 0, apex = z, landT = -1, bounces = 0, inSt = 0;
    const pts = [[x, y, z]];
    let n = 0;
    while (t < 9) {
      const s = Math.sqrt(vh * vh + vz * vz);
      vh -= KD * s * vh * FDT; vz -= (GR + KD * s * vz) * FDT;
      const r0 = r;
      r += vh * FDT; z += vz * FDT; t += FDT;
      if (z > apex) apex = z;
      if (!hr && !wall && r0 < R && r >= R) {
        if (z >= FH) hr = 1;
        else { wall = 1; r = R - 0.2; vh = -vh * 0.3; if (land < 0) land = R; }
      }
      if (hr) { // stands rise behind the fence
        const zs = FH + (r - R) * 0.55;
        if (z <= zs) { z = zs; land = r; landT = t; inSt = 1; }
      }
      if (!inSt && z <= 0.037) {
        z = 0.037;
        if (land < 0) { land = r; landT = t; }
        if (vz < 0) { vz = -vz * 0.38; vh *= 0.72; bounces++; }
        if (Math.abs(vz) < 0.6) { vz = 0; vh *= Math.pow(0.35, FDT); }
      }
      x = fx * r; y = fy * r;
      if (++n % 4 === 0) pts.push([Math.round(x * 100) / 100, Math.round(y * 100) / 100, Math.round(z * 100) / 100]);
      if (inSt || (land >= 0 && Math.abs(vh) < 0.5 && vz === 0)) break;
    }
    pts.push([Math.round(x * 100) / 100, Math.round(y * 100) / 100, Math.round(z * 100) / 100]);
    return { pts, land: land < 0 ? r : land, rest: r, hr, wall, apex, landT: landT < 0 ? t : landT, t, R };
  }
  /* outcome codes: H home run, 3 triple, 2 double, 1 single, G ground out, F fly out, L liner out, f foul, S swinging strike, K called strike */
  const OUTS = { G: 1, F: 1, L: 1, S: 1, K: 1 };
  function classify(bb, f) {
    if (Math.abs(bb[2]) > 45) return 'f';
    if (f.hr) return 'H';
    const la = bb[1];
    if (la < 10) return f.rest < 40 ? 'G' : f.rest > 85 ? '2' : '1';
    if (f.wall) return '2';
    if (la < 25) return f.land < 28 ? 'L' : f.land < 70 ? '1' : f.land < 92 ? '2' : '3';
    return f.land < 85 ? 'F' : f.land < 100 ? '2' : '3';
  }
  /* distance shown/scored: where a fly ball first lands (or the stands), how far a grounder rolled */
  function distOf(bb, f) { return Math.round(bb[1] < 10 ? Math.max(f.land, f.rest) : f.land); }
  function points(sc, code, d) {
    if (sc === 'hr') return code === 'H' ? (d < 115 ? 1 : d < 130 ? 2 : 3) : 0;
    if (sc === 'hit') return code === 'H' ? 4 : code === '3' ? 3 : code === '2' ? 2 : code === '1' ? 1 : 0;
    return /[H321]/.test(code) ? d : 0;
  }
  /* swing → contact */
  const WIN = 110;
  function contact(pc, e, aim) {
    const ae = Math.abs(e);
    const q = U.clamp(1 - Math.pow(ae / WIN, 1.5), 0, 1);
    const off = Math.hypot(pc.x / 0.3, (pc.z - 0.75) / 0.35);
    const qq = q * (1 - 0.12 * Math.min(1, off));
    const ev = 78 + 92 * qq + (pc.v - 130) * 0.12;
    const base = aim < 0 ? 3 : aim > 0 ? 31 : 15;
    let la = base + (pc.z - 0.75) * 14 + (aim > 0 ? (1 - q) * 38 : aim < 0 ? -(1 - q) * 8 : (1 - q) * (e < 0 ? -14 : 12));
    const sp = e * 0.5 + (pc.x < -0.1 ? -5 : pc.x > 0.1 ? 5 : 0);
    return { q, ev, la, sp };
  }
  function grade(e) {
    if (e == null) return '';
    const a = Math.abs(e);
    if (a > WIN) return e < 0 ? '너무 빨라요' : '너무 늦어요';
    if (a <= 18) return '완벽한 타이밍!';
    if (a <= 40) return '좋은 타이밍';
    return e < 0 ? '조금 빨라요' : '조금 늦어요';
  }
  /* the same verdict with how far off the swing was (shown to the batter) */
  function gradeMs(e) {
    const g = grade(e);
    if (!g || Math.abs(e) <= 18) return g;
    return g + ' · ' + Math.round(Math.abs(e)) + 'ms ' + (e < 0 ? '빠름' : '늦음');
  }

  /* ---------- rules ---------- */
  const r1 = (v) => Math.round(v * 10) / 10, r3 = (v) => Math.round(v * 1000) / 1000;
  function cpuPitch() {
    const r = Math.random(), t = r < 0.42 ? 0 : r < 0.62 ? 1 : r < 0.82 ? 2 : 3, P = PT[t];
    const c = U.rand(9);
    return { t, c, x: r3(ZX[c % 3] + (Math.random() - 0.5) * 0.08), z: r3(ZZ[Math.floor(c / 3)] + (Math.random() - 0.5) * 0.08), v: r1(P.v[0] + Math.random() * (P.v[1] - P.v[0])) };
  }
  function makePitch(t, c, jit) {
    const P = PT[t];
    return { t, c, x: r3(ZX[c % 3] + (Math.random() - 0.5) * jit), z: r3(ZZ[Math.floor(c / 3)] + (Math.random() - 0.5) * jit), v: r1(P.v[0] + Math.random() * (P.v[1] - P.v[0])) };
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const fmt = opts.fmt === '15' ? '15' : opts.fmt === 'out' ? 'out' : '10';
    const s = { n, nm: players.map((p) => String(p.name || '').slice(0, 10)), ai: players.map((p) => (p.ai ? 1 : 0)), lv: players.map((p) => p.lv || 0),
      md: fmt === 'out' ? 'o' : 'p', N: fmt === '15' ? 15 : 10, sc: ['hr', 'hit', 'dist'].includes(opts.sc) ? opts.sc : 'hr',
      pv: opts.pit === 'pvp' && n === 2 ? 1 : 0, b: 0, u: 0, o: 0, pts: players.map(() => 0), lg: players.map(() => ''),
      tb: null, ph: 'sw', pc: null, pn: 0, seq: 0, last: null };
    nextPitch(s);
    return s;
  }
  const pitcherOf = (s) => (s.pv ? 1 - batterOf(s) : -1);
  function batterOf(s) { return s.tb ? s.tb.set[s.tb.i] : s.b; }
  function nextPitch(s) {
    s.pn++;
    if (s.pv) { s.ph = 'pp'; s.pc = null; }
    else { s.ph = 'sw'; s.pc = cpuPitch(); }
  }
  function actor(s) {
    if (s.ph === 'e') return null;
    return s.ph === 'pp' ? pitcherOf(s) : batterOf(s);
  }
  function turnLimit(s) { return s.tb ? { p: 3 } : s.md === 'o' ? { o: 3, p: 30 } : { p: s.N }; }
  function endTurn(s) {
    s.u = 0; s.o = 0;
    if (s.tb) {
      s.tb.i++;
      if (s.tb.i >= s.tb.set.length) {
        const best = Math.max(...s.tb.set.map((i) => s.tb.p[i]));
        const tied = s.tb.set.filter((i) => s.tb.p[i] === best);
        s.tb.r++;
        if (tied.length === 1 || s.tb.r >= 5) { s.tb.w = tied; s.ph = 'e'; return; }
        s.tb.set = tied; s.tb.i = 0; tied.forEach((i) => { s.tb.p[i] = 0; });
      }
      return;
    }
    s.b++;
    if (s.b >= s.n) {
      const best = Math.max(...s.pts), tied = [];
      s.pts.forEach((v, i) => { if (v === best) tied.push(i); });
      if (s.n > 1 && tied.length > 1) { s.tb = { set: tied, i: 0, r: 0, p: s.pts.map(() => 0) }; }
      else { s.ph = 'e'; }
    }
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (actor(s) !== seat) throw new Error('not your turn');
    if (s.ph === 'pp') {
      if (a.type !== 'pitch' || !Number.isInteger(a.t) || a.t < 0 || a.t > 3 || !Number.isInteger(a.c) || a.c < 0 || a.c > 8) throw new Error('bad pitch');
      s.pc = makePitch(a.t, a.c, 0.06);
      s.ph = 'sw'; s.seq++;
      return s;
    }
    if (a.type !== 'sw') throw new Error('bad swing');
    const e = a.e == null ? null : Number(a.e);
    if (e != null && (!isFinite(e) || e < -1500 || e > 1500)) throw new Error('bad timing');
    const aim = a.a === -1 || a.a === 1 ? a.a : 0;
    const pc = s.pc, bat = seat;
    let code, bb = null, f = null, pts = 0, d = 0;
    if (e == null) code = 'K';
    else if (Math.abs(e) > WIN) code = 'S';
    else {
      const c = contact(pc, e, aim);
      bb = [r1(c.ev + (Math.random() - 0.5) * 4), r1(c.la + (Math.random() - 0.5) * 4), r1(c.sp + (Math.random() - 0.5) * 4)];
      f = fly(bb);
      code = classify(bb, f);
      d = distOf(bb, f);
      pts = points(s.sc, code, d);
    }
    s.seq++;
    s.u++;
    if (OUTS[code]) s.o++;
    if (s.tb) s.tb.p[bat] += pts; else s.pts[bat] += pts;
    s.lg[bat] = (s.lg[bat] + code).slice(-16);
    s.last = { id: s.seq, s: bat, pn: s.pn, pc, e: e == null ? null : Math.round(e), a: aim, code, bb, pts, d, tb: s.tb ? 1 : 0 };
    const lim = turnLimit(s);
    if ((lim.o && s.o >= lim.o) || s.u >= lim.p) endTurn(s);
    if (s.ph !== 'e') nextPitch(s);
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const sc = s.pts, best = Math.max(...sc);
    const unit = s.sc === 'dist' ? 'm' : '점';
    let winners = s.tb ? s.tb.w.slice() : sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    const ord = sc.map((v, i) => i).sort((a, b) => sc[b] - sc[a] || a - b);
    const hrs = (i) => (s.lg[i].match(/H/g) || []).length;
    const lines = ord.map((i) => (s.nm[i] || (i + 1) + '번') + ' · ' + sc[i] + unit + (s.tb && s.tb.p[i] != null && s.tb.set.concat(s.tb.w).includes(i) ? ' (연장 ' + s.tb.p[i] + unit + ')' : ''));
    if (s.n === 1) return { winners: [0], title: sc[0] + unit, text: s.sc === 'hr' ? '홈런 ' + hrs(0) + '개' : '' };
    return { winners, title: winners.length > 1 ? '공동 우승' : undefined, text: (s.tb ? (winners.length > 1 ? '연장 타격에서도 끝까지 동점이었어요.\n' : '동점이라 연장 타격(3구)으로 가렸어요.\n') : '') + lines.join('\n') };
  }

  /* ---------- AI ---------- */
  function gauss() { let u = 0, v = 0; while (u === 0) u = Math.random(); while (v === 0) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  const AI_SD = { 1: 58, 2: 34, 3: 19 };
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'pp') {
      // pitcher: 쉬움 = 가운데 위주, 어려움 = 구석 + 구종 섞기
      let t = U.rand(4), c;
      if (lv === 1) c = Math.random() < 0.5 ? 4 : U.rand(9);
      else if (lv === 3) { const prev = s.last && s.last.pc ? s.last.pc.t : -1; if (t === prev) t = (t + 1 + U.rand(3)) % 4; c = [0, 2, 6, 8, 6, 8, 3, 5][U.rand(8)]; }
      else c = U.rand(9);
      return { type: 'pitch', t, c };
    }
    if (s.ph !== 'sw') return null;
    let e = gauss() * AI_SD[lv];
    if (lv === 1 && s.pc && s.pc.t !== 0 && Math.random() < 0.3) e -= 70; // fooled by the slow ball
    if (lv === 2 && s.pc && s.pc.t !== 0 && Math.random() < 0.12) e -= 50;
    if (lv === 1 && Math.random() < 0.06) return { type: 'sw', e: null, a: 0 };
    const r = Math.random();
    let a;
    if (s.sc === 'hit') a = lv === 3 ? (r < 0.7 ? 0 : 1) : lv === 2 ? (r < 0.6 ? 0 : r < 0.85 ? 1 : -1) : U.rand(3) - 1;
    else a = lv === 3 ? (r < 0.85 ? 1 : 0) : lv === 2 ? (r < 0.6 ? 1 : 0) : U.rand(3) - 1;
    return { type: 'sw', e: Math.round(e), a };
  }
  function aiDelayFor(s, seat, lv) { return s.ph === 'pp' ? 700 : 450; }

  /* ---------- view ---------- */
  const RES = { H: ['홈런!', '#e3ae45'], 3: ['3루타!', '#5fd3a0'], 2: ['2루타!', '#5fd3a0'], 1: ['안타', '#5fd3a0'], G: ['땅볼 아웃', '#ab9fb8'], F: ['뜬공 아웃', '#ab9fb8'], L: ['직선타 아웃', '#ab9fb8'], f: ['파울', '#ab9fb8'], S: ['헛스윙', '#ee6a55'], K: ['스트라이크', '#ee6a55'] };
  const WU = 1.15; // wind-up seconds (game time)
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = L.h('div', { class: 'hud top bt-top', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px', alignItems: 'stretch' } });
    const bottom = L.h('div', { class: 'hud bottom', style: { padding: '8px 10px 12px', flexDirection: 'column', gap: '6px' } });
    root.append(top, bottom);
    // invisible boxes over the strike zone / pitcher for the first-play tutorial spotlight
    const spZone = tutSpot(root, 'bt-zone'), spPitcher = tutSpot(root, 'bt-pitcher');
    let st = null, time = 0, anim = null, flash = null, hudKey = '', botKey = '', overlayEl = null, gate = '', hand = '', autoT = 0;
    let aim = 0, pick = { t: 0, c: 4 }, waitSeq = -1, pan = 0, toastT = 0, ffSeat = -1;
    try { const v = +localStorage.getItem('lounge.batting.aim'); if (v === -1 || v === 0 || v === 1) aim = v; } catch (e) {}
    const V = { W: 1, H: 1, topH: 84, botH: 0 };
    const cam = { x: 0, y: -4.4, z: 1.3, yaw: 0, F: 700, hy: 300 };
    const color = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const crowd = []; { let sd = 5; const rnd = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
      for (let i = 0; i < 900; i++) crowd.push({ a: (-50 + rnd() * 100) * DEG, d: 4 + rnd() * 30, c: ['#4a3556', '#2f2740', '#56402f', '#334058', '#5e4a2a', '#6a2f3a'][Math.floor(rnd() * 6)], k: 0.8 + rnd() * 0.5 }); }

    const HOME = { x: -0.1, y: -8.6, z: 2.3 };
    function homeF() { return Math.min(V.W * 2.15, (V.H - V.topH) * 1.4); }
    function homeCam() { cam.x = HOME.x; cam.y = HOME.y; cam.z = HOME.z; cam.yaw = 0; cam.F = homeF(); cam.hy = V.topH + (V.H - V.topH - V.botH) * 0.3; pan = 0; }
    function layout() { V.W = cv.w; V.H = cv.h; if (!anim || !anim.fly) homeCam(); }
    function P(x, y, z) {
      const fx = Math.sin(cam.yaw), fy = Math.cos(cam.yaw);
      const dx = x - cam.x, dy = y - cam.y, dep = dx * fx + dy * fy;
      if (dep < 0.25) return null;
      const rg = dx * fy - dy * fx;
      return [V.W / 2 + cam.F * rg / dep, cam.hy + pan - cam.F * (z - cam.z) / dep, cam.F / dep];
    }
    function depthOf(x, y) { return (x - cam.x) * Math.sin(cam.yaw) + (y - cam.y) * Math.cos(cam.yaw); }
    function poly(pts, fill, stroke, lw) {
      const NEAR = 0.3, out = [];
      for (let i = 0; i < pts.length; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length], da = depthOf(a[0], a[1]), db = depthOf(b[0], b[1]);
        if (da >= NEAR) out.push(a);
        if ((da >= NEAR) !== (db >= NEAR)) { const t = (NEAR - da) / (db - da); out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]); }
      }
      if (out.length < 3) return;
      ctx.beginPath(); let k = 0;
      for (const q of out) { const s = P(q[0], q[1], q[2]); if (!s) continue; k++ ? ctx.lineTo(s[0], s[1]) : ctx.moveTo(s[0], s[1]); }
      ctx.closePath();
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
    }
    function line3(pts, wm, col) {
      ctx.strokeStyle = col; ctx.lineCap = 'round';
      for (let i = 0; i + 1 < pts.length; i++) {
        let a = pts[i], b = pts[i + 1], da = depthOf(a[0], a[1]), db = depthOf(b[0], b[1]);
        if (da < 0.3 && db < 0.3) continue;
        if (da < 0.3) { const t = (0.3 - da) / (db - da); a = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
        else if (db < 0.3) { const t = (0.3 - db) / (da - db); b = [b[0] + (a[0] - b[0]) * t, b[1] + (a[1] - b[1]) * t, b[2] + (a[2] - b[2]) * t]; }
        const p = P(...a), q = P(...b); if (!p || !q) continue;
        ctx.lineWidth = U.clamp(wm * (p[2] + q[2]) / 2, 0.7, 10);
        ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); ctx.stroke();
      }
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    const fanPts = (r0, r1, a0, a1, n) => { const o = []; for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n; o.push([r1 * Math.sin(a), r1 * Math.cos(a), 0]); } for (let i = n; i >= 0; i--) { const a = a0 + (a1 - a0) * i / n; o.push([r0 * Math.sin(a), r0 * Math.cos(a), 0]); } return o; };

    /* ---- field ---- */
    function drawField() {
      const W = V.W, H = V.H;
      const sky = ctx.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, '#0b0912'); sky.addColorStop(0.5, '#1b1530'); sky.addColorStop(1, '#221a33');
      ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
      // light towers glow
      for (const a of [-40, 40]) { const q = P(150 * Math.sin(a * DEG), 150 * Math.cos(a * DEG), 38); if (q) { const g = ctx.createRadialGradient(q[0], q[1], 0, q[0], q[1], 60); g.addColorStop(0, 'rgba(255,240,200,.5)'); g.addColorStop(1, 'rgba(255,240,200,0)'); ctx.fillStyle = g; ctx.fillRect(q[0] - 60, q[1] - 60, 120, 120); } }
      // ground beyond (foul territory)
      poly([[-200, -30, 0], [200, -30, 0], [200, 200, 0], [-200, 200, 0]], '#174a33');
      // outfield grass fan with stripes
      const A0 = -45 * DEG, A1 = 45 * DEG, N = 18;
      const fence = []; for (let i = 0; i <= N; i++) { const a = A0 + (A1 - A0) * i / N, R = fenceR(a); fence.push([R * Math.sin(a), R * Math.cos(a)]); }
      poly([[0, 0, 0]].concat(fence.map((p) => [p[0], p[1], 0])), '#1f6b45');
      for (let k = 0; k < 10; k += 2) { const a = A0 + (A1 - A0) * k / 10, b = A0 + (A1 - A0) * (k + 1) / 10; poly([[0, 0, 0], [fenceR(a) * Math.sin(a), fenceR(a) * Math.cos(a), 0], [fenceR(b) * Math.sin(b), fenceR(b) * Math.cos(b), 0]], 'rgba(255,255,255,.035)'); }
      // warning track
      for (let i = 0; i < N; i++) { const a = fence[i], b = fence[i + 1], s = 0.95; poly([[a[0], a[1], 0], [b[0], b[1], 0], [b[0] * s, b[1] * s, 0], [a[0] * s, a[1] * s, 0]], '#8a5a3a'); }
      // infield dirt + grass
      poly(fanPts(0, 29, A0, A1, 16).slice(0, 17).concat([[0, 0, 0]]), '#a8703f');
      poly([[0, 1.5, 0], [17.6, 19.4, 0], [0, 37.3, 0], [-17.6, 19.4, 0]], '#1f6b45');
      const mound = []; for (let i = 0; i < 16; i++) { const t = i / 16 * Math.PI * 2; mound.push([2.7 * Math.cos(t), MOUND + 2.7 * Math.sin(t), 0]); }
      poly(mound, '#b47a46');
      const homeC = []; for (let i = 0; i < 16; i++) { const t = i / 16 * Math.PI * 2; homeC.push([4 * Math.cos(t), 4 * Math.sin(t), 0]); }
      poly(homeC, '#a8703f');
      // lines
      const LC = 'rgba(250,245,232,.9)';
      line3([[0, 0, 0], [fence[0][0], fence[0][1], 0]], 0.08, LC); line3([[0, 0, 0], [fence[N][0], fence[N][1], 0]], 0.08, LC);
      line3([[-1.2, -0.9, 0], [-1.2, 0.9, 0]], 0.06, LC); line3([[1.2, -0.9, 0], [1.2, 0.9, 0]], 0.06, LC);
      for (const b of [[19.4, 19.4], [0, 38.8], [-19.4, 19.4]]) poly([[b[0] - 0.2, b[1] - 0.2, 0.02], [b[0] + 0.2, b[1] - 0.2, 0.02], [b[0] + 0.2, b[1] + 0.2, 0.02], [b[0] - 0.2, b[1] + 0.2, 0.02]], '#f6f2ea');
      poly([[0, MOUND - 0.1, 0.25], [0.3, MOUND - 0.1, 0.25], [0.3, MOUND, 0.25], [0, MOUND, 0.25]], '#f6f2ea');
      poly([[-0.22, 0, 0.01], [0.22, 0, 0.01], [0.22, 0.22, 0.01], [0, 0.43, 0.01], [-0.22, 0.22, 0.01]], '#f6f2ea');
      // stands + crowd behind the fence
      for (let i = 0; i < N; i++) {
        const a = fence[i], b = fence[i + 1], k = 1.4;
        poly([[a[0], a[1], FH], [b[0], b[1], FH], [b[0] * k, b[1] * k, FH + (k - 1) * fenceR(0) * 0.55], [a[0] * k, a[1] * k, FH + (k - 1) * fenceR(0) * 0.55]], i % 2 ? '#241b30' : '#271d34');
      }
      for (const c of crowd) {
        const R = fenceR(c.a), r = R + c.d, q = P(r * Math.sin(c.a), r * Math.cos(c.a), FH + c.d * 0.55 + 0.6);
        if (!q || q[2] > 120) continue;
        ctx.fillStyle = c.c; ctx.beginPath(); ctx.arc(q[0], q[1], Math.max(0.8, 0.35 * c.k * q[2]), 0, 7); ctx.fill();
      }
      // fence wall + yellow top + distance marks
      for (let i = 0; i < N; i++) { const a = fence[i], b = fence[i + 1]; poly([[a[0], a[1], 0], [b[0], b[1], 0], [b[0], b[1], FH], [a[0], a[1], FH]], '#173d2c', 'rgba(0,0,0,.25)', 1); }
      line3(fence.map((p) => [p[0], p[1], FH]), 0.18, '#e3ae45');
      for (const ad of [-45, -22, 0, 22, 45]) {
        if (ad === 0 && cam.y < 0) continue; // seen from home plate the centre mark sits right on the pitcher's head
        const a = ad * DEG, R = fenceR(a), q = P(R * Math.sin(a) * 0.995, R * Math.cos(a) * 0.995, FH * 0.62);
        if (!q || q[2] < 1.2) continue;
        ctx.font = '600 ' + Math.max(7, Math.min(28, Math.round(1.5 * q[2]))) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(242,233,216,.85)';
        ctx.fillText(String(Math.round(R)), q[0], q[1]);
      }
    }
    function ballAt(p, r0) {
      const q = P(p[0], p[1], p[2]); if (!q) return null;
      const r = Math.max(r0 || 1.8, 0.037 * q[2]);
      const sh = P(p[0], p[1], 0);
      if (sh && p[2] < 30) { ctx.fillStyle = 'rgba(0,0,0,' + U.clamp(0.35 - p[2] * 0.02, 0.05, 0.35) + ')'; ctx.beginPath(); ctx.ellipse(sh[0], sh[1], r * 1.1, r * 0.35, 0, 0, 7); ctx.fill(); }
      const g = ctx.createRadialGradient(q[0] - r * 0.3, q[1] - r * 0.35, r * 0.1, q[0], q[1], r);
      g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#bdb5a6');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q[0], q[1], r, 0, 7); ctx.fill();
      if (r > 5) { ctx.strokeStyle = '#c8453a'; ctx.lineWidth = Math.max(1, r * 0.12); ctx.beginPath(); ctx.arc(q[0] - r * 0.9, q[1], r * 0.75, -0.9, 0.9); ctx.stroke(); ctx.beginPath(); ctx.arc(q[0] + r * 0.9, q[1], r * 0.75, Math.PI - 0.9, Math.PI + 0.9); ctx.stroke(); }
      return q;
    }
    /* pitcher facing the camera; u = wind-up progress 0..1 (1 = release), f = follow-through 0..1 */
    function drawPitcher(u, f, col) {
      const b = P(0, MOUND, 0.25); if (!b) { spPitcher(null); return; }
      const s = b[2];
      spPitcher(b[0] - 1.2 * s - 8, b[1] - 2.3 * s - 8, 2.4 * s + 16, 2.4 * s + 16);
      const X = (dx) => b[0] + dx * s, Y = (dz) => b[1] - dz * s;
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      const lift = u < 0.55 ? Math.sin(u / 0.55 * Math.PI / 2) : Math.max(0, 1 - (u - 0.55) / 0.3);
      const stride = u > 0.55 ? Math.min(1, (u - 0.55) / 0.35) : 0;
      const lean = stride * 0.25 + f * 0.25;
      const hip = [X(0), Y(0.95 - lean * 0.2)];
      ctx.strokeStyle = '#e8e2d4'; ctx.lineWidth = Math.max(2, 0.15 * s);
      // legs
      ctx.beginPath(); ctx.moveTo(hip[0], hip[1]); ctx.lineTo(X(0.15 - stride * 0.05), Y(0)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(hip[0], hip[1]); ctx.lineTo(X(-0.2 - stride * 0.1 + lift * 0.1), Y(0.5 * lift - 0.0 + (1 - lift) * 0)); ctx.lineTo(X(-0.2 - stride * 0.25), Y(lift * 0.45)); ctx.stroke();
      // torso
      ctx.strokeStyle = col; ctx.lineWidth = Math.max(4, 0.36 * s);
      const sh = [X(lean * 0.1), Y(1.5 - lean * 0.35)];
      ctx.beginPath(); ctx.moveTo(hip[0], hip[1]); ctx.lineTo(sh[0], sh[1]); ctx.stroke();
      // throwing arm (screen right): back & up during wind-up, whips forward at release
      ctx.lineWidth = Math.max(2, 0.11 * s);
      let ax, az;
      if (u < 0.55) { ax = 0.25; az = 1.2; }
      else if (u < 1) { const k = (u - 0.55) / 0.45; ax = 0.25 + 0.35 * Math.sin(k * Math.PI * 0.9); az = 1.2 + 0.75 * k; }
      else { ax = 0.15 - f * 0.4; az = 1.9 - f * 1.0; }
      ctx.beginPath(); ctx.moveTo(sh[0] + 0.15 * s, sh[1]); ctx.lineTo(X(ax + lean * 0.1), Y(az - lean * 0.2)); ctx.stroke();
      // glove arm
      ctx.beginPath(); ctx.moveTo(sh[0] - 0.15 * s, sh[1]); ctx.lineTo(X(-0.3 + stride * 0.05), Y(1.25 - stride * 0.2)); ctx.stroke();
      ctx.fillStyle = '#5a3a20'; ctx.beginPath(); ctx.arc(X(-0.3 + stride * 0.05), Y(1.25 - stride * 0.2), Math.max(2, 0.1 * s), 0, 7); ctx.fill();
      // head + cap
      ctx.fillStyle = '#c99a72'; ctx.beginPath(); ctx.arc(sh[0], sh[1] - 0.2 * s, Math.max(2, 0.12 * s), 0, 7); ctx.fill();
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(sh[0], sh[1] - 0.24 * s, Math.max(2, 0.125 * s), Math.PI, 0); ctx.fill();
      // ball in hand before release
      if (u < 1) { const hb = [X(ax + lean * 0.1), Y(az - lean * 0.2)]; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(hb[0], hb[1], Math.max(1.5, 0.04 * s), 0, 7); ctx.fill(); }
    }
    /* batter (right-handed, left of the plate), seen from behind; sw = swing progress −1 (no swing) … 0..1 */
    function drawBatter(seat, sw) {
      const b = P(-0.85, 0.1, 0); if (!b) return;
      const s = b[2], col = color(seat);
      const X = (dx) => b[0] + dx * s, Y = (dz) => b[1] - dz * s;
      ctx.lineCap = 'round';
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(X(0), Y(0), 0.45 * s, 0.1 * s, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#e8e2d4'; ctx.lineWidth = 0.15 * s;
      ctx.beginPath(); ctx.moveTo(X(-0.12), Y(0.95)); ctx.lineTo(X(-0.25), Y(0.02)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(X(0.12), Y(0.95)); ctx.lineTo(X(0.28 + (sw > 0 ? 0.08 : 0)), Y(0.02)); ctx.stroke();
      ctx.fillStyle = col; rr(X(-0.24), Y(1.55), 0.48 * s, 0.62 * s, 0.1 * s); ctx.fill();
      ctx.fillStyle = 'rgba(23,19,31,.7)'; ctx.font = '700 ' + Math.max(8, Math.round(0.26 * s)) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(seat + 1), X(0), Y(1.25));
      // helmet
      ctx.fillStyle = '#1d1828'; ctx.beginPath(); ctx.arc(X(0), Y(1.72), 0.15 * s, 0, 7); ctx.fill();
      // hands + bat
      let ang, hx, hz;
      if (sw < 0) { ang = -2.35 + Math.sin(time * 3) * 0.06; hx = 0.25; hz = 1.45; }
      else { const k = Math.min(1, sw), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; ang = -2.35 + e * 3.6; hx = 0.25 + Math.sin(e * Math.PI) * 0.35; hz = 1.45 - Math.sin(e * Math.PI) * 0.4; }
      const L0 = 0.86, bx = hx + Math.cos(ang) * L0, bz = hz - Math.sin(ang) * L0 * 0.6;
      ctx.strokeStyle = col; ctx.lineWidth = 0.1 * s; ctx.beginPath(); ctx.moveTo(X(0.18), Y(1.45)); ctx.lineTo(X(hx), Y(hz)); ctx.stroke();
      ctx.strokeStyle = '#d9b07a'; ctx.lineWidth = 0.07 * s; ctx.beginPath(); ctx.moveTo(X(hx), Y(hz)); ctx.lineTo(X(bx), Y(bz)); ctx.stroke();
      ctx.lineWidth = 0.1 * s; ctx.beginPath(); ctx.moveTo(X(hx + (bx - hx) * 0.55), Y(hz + (bz - hz) * 0.55)); ctx.lineTo(X(bx), Y(bz)); ctx.stroke();
    }
    function drawZone(alpha, hlCell) {
      const a = P(-0.22, 0.2, 1.05), b = P(0.22, 0.2, 0.45); if (!a || !b) { spZone(null); return; }
      spZone(a[0] - 26, a[1] - 26, b[0] - a[0] + 52, b[1] - a[1] + 52);
      ctx.strokeStyle = 'rgba(242,233,216,' + 0.5 * alpha + ')'; ctx.lineWidth = 1.5;
      ctx.strokeRect(a[0], a[1], b[0] - a[0], b[1] - a[1]);
      ctx.strokeStyle = 'rgba(242,233,216,' + 0.16 * alpha + ')'; ctx.lineWidth = 1;
      for (let i = 1; i < 3; i++) { const x = a[0] + (b[0] - a[0]) * i / 3, y = a[1] + (b[1] - a[1]) * i / 3; ctx.beginPath(); ctx.moveTo(x, a[1]); ctx.lineTo(x, b[1]); ctx.moveTo(a[0], y); ctx.lineTo(b[0], y); ctx.stroke(); }
      if (hlCell != null && hlCell >= 0) { const c = hlCell % 3, r = Math.floor(hlCell / 3), w = (b[0] - a[0]) / 3, h = (b[1] - a[1]) / 3; ctx.fillStyle = 'rgba(227,174,69,.3)'; ctx.fillRect(a[0] + c * w, a[1] + r * h, w, h); }
    }

    /* ---- helpers ---- */
    const multi = () => !api.online && api.mySeats().length >= 2;
    const localPvP = () => !!st && st.pv && multi() && api.canAct(pitcherOf(st)) && api.canAct(batterOf(st));
    function liveMine() { // this device bats right now
      if (!st || st.ph !== 'sw' || waitSeq === st.seq) return false;
      return api.canAct(batterOf(st));
    }
    function pitchMine() { return !!st && st.ph === 'pp' && api.canAct(pitcherOf(st)) && waitSeq !== st.seq; }
    const gs = () => L.debug.speed;

    /* ---- animation ---- */
    // anim: {pc, s, t0, live, sent, e, a, l, swingT(game s), fly, flyT0, done}
    function startPitch(live) {
      if (!st || !st.pc) return;
      ffSeat = -1;
      anim = { pc: st.pc, s: batterOf(st), pn: st.pn, t0: performance.now(), live, sent: false, e: null, a: aim, l: null, swingT: null, flyF: null, ended: false, flashed: false, hud: st, caught: false };
      api.setBusy(true);
      api.sfx('tick');
    }
    function startReplay(l, prev) {
      anim = { pc: l.pc, s: l.s, pn: l.pn, t0: performance.now(), live: false, sent: true, e: l.e, a: l.a, l: null, swingT: null, flyF: null, ended: false, flashed: false, hud: prev || st, caught: false };
      if (ffSeat !== l.s) ffSeat = -1; else anim.k = 3; // keep fast-forwarding the rest of that batter's turn
      attach(l);
      api.setBusy(true);
    }
    function attach(l) {
      anim.l = l; anim.e = l.e;
      const T = pitchT(anim.pc);
      if (l.e != null) anim.swingT = WU + T + l.e / 1000;
      if (l.bb) { anim.flyF = fly(l.bb); anim.flyT0 = Math.max(anim.swingT, WU + T * 0.98); }
    }
    /* animation clock (game seconds). Replays of other batters can be fast-forwarded by a tap (anim.k = 3);
       a live at-bat always runs on the real clock so the swing timing stays exact. */
    function tau() { return anim ? (anim.tb || 0) + (performance.now() - anim.t0) * gs() * (anim.k || 1) / 1000 : 0; }
    function fastForward() {
      if (!anim || anim.live || anim.k > 1) return;
      anim.tb = tau(); anim.t0 = performance.now(); anim.k = 3;
      api.sfx('tick');
    }
    function finishAnim() {
      if (!anim) return;
      anim = null; homeCam(); flash = flash && flash.keep ? flash : flash;
      hudKey = ''; renderTop(); renderBottom();
      api.setBusy(false);
      armAuto();
    }
    function sendSwing(e, a) {
      if (!anim || anim.sent || !st) return;
      anim.sent = true; anim.e = e; anim.a = a;
      if (e != null) anim.swingT = WU + pitchT(anim.pc) + e / 1000;
      waitSeq = st.seq;
      api.act({ type: 'sw', e: e == null ? null : Math.round(e), a });
    }
    function showResult() {
      const l = anim.l; if (!l || anim.flashed) return;
      anim.flashed = true;
      const r = RES[l.code];
      let sub = '';
      const unit = st.sc === 'dist' ? 'm' : '점';
      if (l.bb) sub = l.d + 'm' + (l.pts ? ' · +' + l.pts + unit : '');
      const g = api.canAct(l.s) ? gradeMs(l.e) : grade(l.e);
      flash = { text: r[0], c: r[1], sub, g, t0: performance.now(), pt: PT[l.pc.t].n + ' ' + Math.round(l.pc.v) + 'km/h' };
      if (l.code === 'H') { api.sfx('win'); api.buzz(40); } else if (/[123]/.test(l.code)) { api.sfx('pop'); api.buzz(20); } else if (l.code === 'S' || l.code === 'K') api.sfx('thud'); else api.sfx('lose');
      anim.hud = st; hudKey = ''; renderTop();
    }
    function step(dt) {
      if (!anim) return;
      const t = tau(), T = pitchT(anim.pc), arrive = WU + T;
      if (!anim.relSnd && t >= WU) { anim.relSnd = true; api.sfx('whoosh'); }
      // live: auto "take" when the ball has passed
      if (anim.live && !anim.sent && t > arrive + 0.28) sendSwing(null, aim);
      if (anim.swingT != null && !anim.batSnd && t >= anim.swingT) { anim.batSnd = true; if (anim.l ? anim.l.bb : false) { api.sfx('hit'); api.buzz(25); } else api.sfx('whoosh'); }
      if (!anim.l) return;
      if (!anim.flyF) {
        if (!anim.caught && t >= arrive) { anim.caught = true; api.sfx('thud'); }
        if (t >= arrive + 0.15) showResult();
        if (t >= arrive + 0.95 && !anim.ended) { anim.ended = true; setTimeout(finishAnim, 0); }
        return;
      }
      const F = anim.flyF, ft = warp(F, t - anim.flyT0);
      if (ft > 0) {
        if (!anim.landSnd && ft >= F.landT) { anim.landSnd = true; if (anim.l.code !== 'H') api.sfx('bounce'); }
        if (ft >= Math.min(F.landT + 0.1, F.t)) showResult();
        if (ft >= F.t && t - anim.flyT0 >= unwarp(F, F.t) + 0.9 && !anim.ended) { anim.ended = true; setTimeout(finishAnim, 0); }
        // chase camera: glides from behind the plate to a spot behind the ball, looking along its path
        const p = flyPos(F, ft), ph = U.clamp(anim.l.bb[2], -50, 50) * DEG, fx = Math.sin(ph), fy = Math.cos(ph);
        const k = U.clamp(ft / 0.7, 0, 1), ke = k * k * (3 - 2 * k);
        const back = 15, dist = p[0] * fx + p[1] * fy;
        const tx = fx * Math.max(HOME.y, dist - back), ty = fy * Math.max(HOME.y, dist - back), tz = Math.max(1.8, p[2] * 0.8 + 1.6);
        const fol = 1 - Math.pow(0.004, dt * gs() * (anim.k || 1));
        cam.x += (U.lerp(HOME.x, tx, ke) - cam.x) * fol; cam.y += (U.lerp(HOME.y, ty, ke) - cam.y) * fol;
        cam.z += (U.lerp(HOME.z, tz, ke) - cam.z) * fol; cam.yaw += (ph * ke - cam.yaw) * fol;
        cam.F += (U.lerp(homeF(), Math.min(V.W * 1.25, V.H * 0.8), ke) - cam.F) * fol;
        cam.hy += (V.topH + (V.H - V.topH) * U.lerp(0.3, 0.42, ke) - cam.hy) * fol;
      }
    }
    /* replay clock: the flight runs 1.3× real time and the roll after landing 3× so turns stay snappy */
    function warp(F, rt) { const a = rt * 1.3; return a <= F.landT ? a : F.landT + (a - F.landT) * 3; }
    function unwarp(F, ft) { return (ft <= F.landT ? ft : F.landT + (ft - F.landT) / 3) / 1.3; }
    function flyPos(F, ft) { const i = ft * 30, a = Math.min(F.pts.length - 1, Math.floor(i)), b = Math.min(F.pts.length - 1, a + 1), f = i - Math.floor(i); const A = F.pts[a], B = F.pts[b]; return [A[0] + (B[0] - A[0]) * f, A[1] + (B[1] - A[1]) * f, A[2] + (B[2] - A[2]) * f]; }

    /* ---- draw ---- */
    function draw() {
      cv.clear();
      if (!st) return;
      drawField();
      const s = anim && anim.hud ? anim.hud : st;
      const bat = anim ? anim.s : batterOf(st);
      const pcol = st.pv ? color(1 - bat) : '#7f8aa6';
      const t = tau();
      const T = anim ? pitchT(anim.pc) : 0, arrive = WU + T;
      const flying = anim && anim.flyF && t > anim.flyT0;
      // pitcher
      let u = 0, f = 0;
      if (anim) { u = Math.min(1, t / WU); f = t > WU ? Math.min(1, (t - WU) / 0.4) : 0; }
      if (st.ph === 'e' && !anim) return drawTexts();
      drawPitcher(u, f, pcol);
      if (!flying || cam.y < 4) {
        const swing = anim && anim.swingT != null ? (t - anim.swingT + 0.09) / 0.26 : -1;
        const showZone = !anim || t < arrive + 0.2;
        if (showZone) drawZone(liveMine() || (anim && anim.live) ? 1 : 0.5, null);
        // ball during the pitch (before the batter: draw ball after zone)
        if (anim && t >= WU && (!anim.flyF || t < anim.flyT0)) {
          const uu = (t - WU) / T;
          let bp;
          if (uu <= 1.0) bp = pitchPos(anim.pc, Math.max(0, uu));
          else { const k = Math.min(1, (uu - 1) * T / 0.12); bp = pitchPos(anim.pc, 1); bp = [bp[0], bp[1] - 1.0 * k, bp[2] - 0.05 * k]; }
          // timing ring (shrinks onto the ball as it arrives)
          if (uu < 1 && uu > 0.05) {
            const pl = P(anim.pc.x, 0.2, anim.pc.z);
            if (pl) { const rad = 6 + 70 * (1 - uu); ctx.strokeStyle = 'rgba(227,174,69,' + (0.15 + 0.4 * uu) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(pl[0], pl[1], rad, 0, 7); ctx.stroke(); }
          }
          if (uu < 1.1) {
            ballAt(bp, 2);
          }
        }
        if (!flying || depthOf(-0.85, 0.1) > 3.5) drawBatter(bat, swing);
        if (anim && anim.flyF && t >= anim.flyT0 && !flying) ballAt(flyPos(anim.flyF, t - anim.flyT0), 2);
      }
      if (flying) {
        const F = anim.flyF, ft = warp(F, t - anim.flyT0);
        // trail
        ctx.strokeStyle = 'rgba(255,240,200,.3)'; ctx.lineWidth = 2; ctx.beginPath(); let k = 0;
        for (let tt = Math.max(0, ft - 0.45); tt <= ft; tt += 1 / 30) { const w = flyPos(F, tt); if (depthOf(w[0], w[1]) < 2) { k = 0; continue; } const q = P(...w); if (!q) continue; k++ ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }
        ctx.stroke();
        const p = flyPos(F, ft);
        const qg = P(...p);
        if (qg) { const g = ctx.createRadialGradient(qg[0], qg[1], 0, qg[0], qg[1], 16); g.addColorStop(0, 'rgba(255,240,200,.55)'); g.addColorStop(1, 'rgba(255,240,200,0)'); ctx.fillStyle = g; ctx.fillRect(qg[0] - 16, qg[1] - 16, 32, 32); }
        const q = ballAt(p, 4);
        if (q && ft >= F.landT && anim.l) {
          ctx.font = '700 13px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
          ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(anim.l.d + 'm', q[0], q[1] - 10); ctx.fillStyle = '#f2e9d8'; ctx.fillText(anim.l.d + 'm', q[0], q[1] - 10);
        }
      }
      drawTexts();
    }
    function drawTexts() {
      drawFlash();
      // hint pill
      let hint = null, col = '#ab9fb8';
      const y = V.H - V.botH - 30;
      if (anim && anim.live && !anim.sent) {
        const t = tau();
        if (t < WU) hint = '투구 준비… 공이 오면 탭!';
        else hint = '지금 오는 공을 탭해서 치기!';
        col = '#e3ae45';
      } else if (!anim && liveMine() && gate === 'wait') { hint = '화면을 탭하면 투구가 시작돼요'; col = '#e3ae45'; }
      else if (!anim && st && st.ph === 'pp' && !pitchMine()) hint = '투수가 공을 고르는 중…';
      else if (anim && !anim.live && !api.canAct(anim.s)) hint = anim.k > 1 ? '빨리 보는 중 ▶▶' : '탭하면 빨리 보기';
      if (hint) {
        ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
        const hw = ctx.measureText(hint).width + 24;
        ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(V.W / 2 - hw / 2, y, hw, 24, 12); ctx.fill();
        ctx.fillStyle = col; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(hint, V.W / 2, y + 12.5);
      }
      drawStatus();
    }
    function drawFlash() {
      if (!flash) return;
      const k = (performance.now() - flash.t0) / (1700 / Math.sqrt(gs()));
      if (k >= 1) { flash = null; return; }
      ctx.globalAlpha = k < 0.08 ? k / 0.08 : 1 - Math.max(0, (k - 0.75) / 0.25);
      const y = V.topH + 120, sc = 1 + (1 - Math.min(1, k * 4)) * 0.2;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (flash.g) { ctx.font = '700 16px "IBM Plex Sans KR", sans-serif'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.g, V.W / 2, y - 40); ctx.fillStyle = flash.g.startsWith('완벽') ? '#e3ae45' : '#f2e9d8'; ctx.fillText(flash.g, V.W / 2, y - 40); }
      ctx.font = '400 ' + Math.round(44 * sc) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
      ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, V.W / 2, y);
      ctx.fillStyle = flash.c; ctx.fillText(flash.text, V.W / 2, y);
      ctx.font = '700 13px "IBM Plex Sans KR", sans-serif'; ctx.lineWidth = 4;
      const sub = (flash.sub ? flash.sub + ' · ' : '') + flash.pt;
      ctx.strokeText(sub, V.W / 2, y + 36); ctx.fillStyle = '#f2e9d8'; ctx.fillText(sub, V.W / 2, y + 36);
      ctx.globalAlpha = 1;
    }
    function drawStatus() {
      const s = anim && anim.hud ? anim.hud : st;
      if (!s || s.ph === 'e') return;
      const b = anim ? anim.s : batterOf(s);
      let t;
      const p = api.players[b];
      if (s.tb) t = '연장 타격 ' + (s.tb.r + 1) + '라운드 · ' + (p ? p.name : '') + ' · ' + (s.u + 1) + '/3구';
      else if (s.md === 'o') t = (p ? p.name : '') + ' 타석 · ' + s.o + '아웃';
      else t = (p ? p.name : '') + ' 타석 · ' + Math.min(s.N, s.u + 1) + '/' + s.N + '구';
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const tw = ctx.measureText(t).width + 22, x0 = V.W / 2 - tw / 2, y0 = V.topH + 4;
      ctx.fillStyle = 'rgba(18,14,24,.78)'; rr(x0, y0, tw, 24, 12); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, V.W / 2, y0 + 12.5);
    }

    /* ---- HUD ---- */
    function renderTop() {
      const s = anim && anim.hud ? anim.hud : st;
      if (!s) return;
      const cur = s.ph === 'e' ? -1 : anim ? anim.s : batterOf(s);
      const key = JSON.stringify([s.pts, s.tb, cur, s.u, s.o, s.ph, s.b]);
      if (key === hudKey) return;
      hudKey = key;
      top.innerHTML = '';
      const unit = s.sc === 'dist' ? 'm' : '';
      for (let i = 0; i < s.n; i++) {
        const p = api.players[i] || { name: '', color: '#fff' }, on = cur === i;
        let sub;
        const done = s.tb ? false : i < s.b || s.ph === 'e';
        if (s.tb && s.tb.set.includes(i)) sub = '연장 ' + s.tb.p[i] + unit;
        else if (on && s.md === 'o' && !s.tb) sub = '●'.repeat(s.o) + '○'.repeat(Math.max(0, 3 - s.o)) + ' 아웃';
        else if (on && !s.tb) sub = '남은 공 ' + (s.N - s.u);
        else sub = done ? '홈런 ' + (s.lg[i].match(/H/g) || []).length : '대기';
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '6px 8px', display: 'flex', flexDirection: 'column', gap: '3px', opacity: on || cur < 0 ? 1 : 0.7, borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color + ' inset' : '' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
            L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, text: p.name })),
          L.h('div', { class: 'mono', style: { fontSize: s.n > 3 ? '20px' : '24px', fontWeight: 600, lineHeight: 1, whiteSpace: 'nowrap' }, text: s.pts[i] + unit }),
          L.h('div', { style: { fontSize: '11px', color: on ? 'var(--brass)' : 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', lineHeight: 1.1 }, text: sub })));
      }
      requestAnimationFrame(() => { const h = top.getBoundingClientRect().height; if (h && Math.abs(h + 4 - V.topH) > 1) { V.topH = h + 4; layout(); } });
    }
    function renderBottom() {
      const mode = !st || st.ph === 'e' ? 'none' : pitchMine() && !overlayEl ? 'pitch' : liveMine() && !overlayEl ? 'bat' : 'none';
      const key = mode + ':' + aim + ':' + pick.t + ':' + pick.c;
      if (key === botKey) return;
      botKey = key;
      bottom.innerHTML = '';
      if (mode === 'bat') {
        const lab = [['땅볼', -1], ['라이너', 0], ['뜬공', 1]];
        bottom.append(L.h('div', { class: 'panel bt-aim', style: { display: 'flex', gap: '6px', alignItems: 'center', padding: '6px' } },
          L.h('span', { class: 'label', style: { padding: '0 4px', whiteSpace: 'nowrap' }, text: '겨냥' }),
          lab.map(([n, v]) => L.h('button', { class: 'btn sm' + (aim === v ? ' primary' : ''), style: { minHeight: '44px', minWidth: '64px' }, text: n,
            onclick: (e) => { e.stopPropagation(); aim = v; try { localStorage.setItem('lounge.batting.aim', String(v)); } catch (x) {} api.sfx('click'); api.buzz(8); renderBottom(); } }))));
      } else if (mode === 'pitch') {
        const grid = L.h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(3, 44px)', gridTemplateRows: 'repeat(3, 44px)', gap: '3px', flex: 'none' } },
          ZN.map((n, c) => L.h('button', { 'aria-label': n, style: { border: '1px solid var(--line)', borderRadius: '8px', background: pick.c === c ? 'var(--brass)' : 'var(--surface-2)', cursor: 'pointer' },
            onclick: () => { pick.c = c; api.sfx('tick'); renderBottom(); } })));
        const types = L.h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '5px', flex: '1 1 auto', minWidth: 0 } },
          PT.map((p, t) => L.h('button', { class: 'btn sm' + (pick.t === t ? ' primary' : ''), style: { minHeight: '44px', padding: '4px 6px', flexDirection: 'column', gap: 0 }, onclick: () => { pick.t = t; api.sfx('tick'); renderBottom(); } },
            L.h('span', { text: p.n }), L.h('span', { style: { fontSize: '10px', opacity: 0.75, fontWeight: 600 }, text: p.v[0] + '–' + p.v[1] }))));
        bottom.append(L.h('div', { class: 'panel', style: { display: 'flex', flexDirection: 'column', gap: '8px', padding: '10px', width: '100%', maxWidth: '420px', boxSizing: 'border-box' } },
          L.h('div', { style: { display: 'flex', gap: '10px', alignItems: 'center' } }, types, grid),
          L.h('button', { class: 'btn primary block', text: PT[pick.t].n + ' · ' + ZN[pick.c] + ' 던지기', onclick: () => {
            if (!pitchMine()) return; waitSeq = st.seq; api.buzz(15); api.sfx('whoosh');
            api.actAs(pitcherOf(st), { type: 'pitch', t: pick.t, c: pick.c }); } })));
      }
      requestAnimationFrame(() => { V.botH = mode === 'none' ? 0 : bottom.getBoundingClientRect().height; });
    }

    /* ---- hand-over (two people on one phone, PvP) + start gate ---- */
    function syncOverlay() {
      let want = null;
      if (st && st.ph !== 'e' && !anim && multi()) {
        if (pitchMine() && hand !== 'p' + st.pn) want = { seat: pitcherOf(st), role: '투수 · 공 고르기', key: 'p' + st.pn, warn: '타자는 보지 마세요' };
        else if (localPvP() && liveMine() && hand !== 'b' + st.pn) want = { seat: batterOf(st), role: '타자 · 타석에 서기', key: 'b' + st.pn, warn: '폰을 타자에게 넘겨주세요' };
      }
      const k = want ? want.key : '';
      if (overlayEl && overlayEl._k === k) return;
      if (overlayEl) { overlayEl.remove(); overlayEl = null; }
      if (!want) return;
      const p = api.players[want.seat];
      overlayEl = L.h('div', { class: 'overlay bt-hand' },
        L.h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px', textAlign: 'center' } },
          L.h('span', { class: 'dot', style: { '--c': p.color, width: '18px', height: '18px' } }),
          L.h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '34px' }, text: p.name }),
          L.h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: want.role }),
          L.h('div', { class: 'muted', text: want.warn }),
          L.h('button', { class: 'btn primary', text: '준비됐어요', onclick: () => { hand = want.key; api.sfx('click'); overlayEl.remove(); overlayEl = null; botKey = ''; renderBottom(); armAuto(); } })));
      overlayEl._k = k;
      root.append(overlayEl);
      botKey = ''; renderBottom();
    }
    let turnSeen = '';
    function armAuto() {
      clearTimeout(autoT);
      if (!st || anim || !liveMine() || overlayEl) return;
      // first pitch of each human turn waits for a tap; later pitches start on their own
      const tk = (st.tb ? 't' + st.tb.r : 'r') + ':' + batterOf(st);
      if (turnSeen !== tk && st.u === 0 && !localPvP()) { gate = 'wait'; turnSeen = tk; return; }
      if (gate === 'wait') return;
      const sq = st.seq;
      autoT = setTimeout(() => { if (st && st.seq === sq && !anim && liveMine() && !overlayEl) startPitch(true); }, 900 / gs());
    }

    const stopLoop = U.loop((dt) => { time += dt; step(dt); draw(); });

    /* ---- input: tap anywhere to swing ---- */
    const el = cv.cv;
    function onDown(ev) {
      if (!ev.isPrimary || !st) return;
      if (!anim && liveMine() && gate === 'wait') { gate = 'go'; api.sfx('click'); startPitch(true); ev.preventDefault(); return; }
      if (anim && !anim.live) { ffSeat = anim.s; fastForward(); ev.preventDefault(); return; }
      if (!anim || !anim.live || anim.sent) return;
      const t = tau();
      if (t < WU + 0.05) { if (performance.now() - toastT > 900) { toastT = performance.now(); api.toast('아직이에요 · 공이 날아올 때 탭!'); } return; }
      const e = (t - (WU + pitchT(anim.pc))) * 1000;
      api.buzz(12);
      sendSwing(e, aim);
      ev.preventDefault();
    }
    el.addEventListener('pointerdown', onDown);
    cv.onresize = layout;
    layout();

    root._bt = { live: () => !!(anim && anim.live && !anim.sent), left: () => (anim ? (WU + pitchT(anim.pc) - tau()) * 1000 / gs() : null) };
    return {
      update(next, prev) {
        st = next;
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          if (anim && anim.live && anim.pn === l.pn && !anim.l) attach(l);
          else { if (anim) { anim = null; api.setBusy(false); } startReplay(l, prev); }
        }
        if (!anim) homeCam();
        hudKey = ''; renderTop(); botKey = ''; renderBottom();
        syncOverlay();
        armAuto();
      },
      destroy() {
        stopLoop(); clearTimeout(autoT);
        el.removeEventListener('pointerdown', onDown);
        if (overlayEl) overlayEl.remove();
        cv.destroy(); top.remove(); bottom.remove(); spZone.el.remove(); spPitcher.el.remove();
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'batting', name: '야구 타격 대결', tag: '홈런 더비', cat: '스포츠',
    blurb: '날아오는 공에 맞춰 탭해서 쳐요. 정해진 공 수(또는 3아웃) 동안 홈런·안타·비거리로 점수를 모아 가장 높은 사람이 이겨요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 450, aiDelayFor,
    tint: '#21405e',
    icon: '<circle cx="40" cy="16" r="7" fill="currentColor"/><path d="M33.5 13.5c2.5 1 2.5 4 0 5M46.5 13.5c-2.5 1-2.5 4 0 5" fill="none" stroke="#21405e" stroke-width="1.6"/><path d="M8 48L36 26" stroke="currentColor" stroke-width="6" stroke-linecap="round"/><path d="M8 48l6-5" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/><path d="M22 52h26" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" opacity=".55"/>',
    options: [
      { id: 'fmt', label: '타석', choices: [{ v: '10', label: '공 10개' }, { v: '15', label: '공 15개' }, { v: 'out', label: '아웃제 (3아웃)' }], def: '10' },
      { id: 'sc', label: '점수', choices: [{ v: 'hr', label: '홈런 (비거리)' }, { v: 'hit', label: '안타 구역' }, { v: 'dist', label: '총 비거리' }], def: 'hr' },
      { id: 'pit', label: '투수', choices: [{ v: 'cpu', label: '기계 투수' }, { v: 'pvp', label: '상대가 던지기 (2명)' }], def: 'cpu' },
    ],
    quick: [
      '한 사람씩 타석에 서서 정해진 공 수(또는 3아웃)만큼 쳐요. 점수가 가장 높은 사람이 이겨요.',
      '내 차례: 공이 홈플레이트에 오는 순간(노란 고리가 공 위로 작아질 때) 화면 아무 데나 탭!',
      '기본 점수는 홈런만: 115m 미만 1점, 115~130m 2점, 130m 이상 3점. 아래 버튼으로 땅볼·라이너·뜬공을 골라요.',
    ],
    rules: [
      { h: '목표', p: ['홈런 더비예요. 날아오는 공을 쳐서 점수를 모아요. 가장 높은 사람이 이겨요.'] },
      { h: '차례에 할 일', p: ['① 한 사람씩 타석에 서서 끝까지 친 다음 다음 사람 차례예요.',
        '② 공 10개 / 15개: 정해진 공을 다 받으면 끝(치지 않은 공도 1개로 세요).',
        '③ 아웃제(3아웃): 3아웃이 되면 끝(파울은 아웃이 아니에요, 최대 30구).',
        '타석의 첫 공은 화면을 탭하면 시작되고, 그다음부터는 자동으로 던져요.',
        '다른 사람의 타석은 화면을 탭하면 빨리 볼 수 있어요(그 타석이 끝날 때까지).'] },
      { h: '조작 (손가락)', p: ['① 투수가 와인드업한 뒤 공을 던져요.',
        '② 공이 스트라이크 존(홈플레이트 위 네모)에 오는 순간 화면 아무 데나 탭해요. 노란 고리가 공 위로 줄어드는 순간이 딱 맞는 타이밍이에요.',
        '③ 타이밍이 정확할수록 세게 맞아요(「완벽한 타이밍!」). 빗나가면 몇 ms 빨랐는지/늦었는지 알려 줘요.',
        '④ 일찍 치면 왼쪽(당겨치기), 늦게 치면 오른쪽(밀어치기)으로 가요. 너무 빗나가면 파울이나 헛스윙이에요.',
        '⑤ 아래 「겨냥」 버튼으로 발사각을 골라요: 땅볼(낮게) · 라이너(곧게) · 뜬공(높이). 뜬공이 홈런을 노리기 좋지만, 타이밍이 어긋나면 높이 떠서 잡혀요. 높은 공은 조금 더 뜨고 낮은 공은 덜 떠요.'] },
      { h: '구종 (투수가 던지는 공)', p: ['직구: 빨라요.', '커브: 느리고 크게 떨어져요.', '슬라이더: 옆으로 휘어요.', '체인지업: 직구처럼 보이지만 느려요. 느린 공은 기다렸다 쳐야 해요.'] },
      { h: '아웃', p: ['아웃제에서 아웃이 되는 경우: 헛스윙 · 치지 않은 공 · 땅볼 아웃(40m 안에서 멈춘 땅볼) · 뜬공 아웃(뜬공이 85m 전에 떨어지면) · 직선타 아웃(28m 안에 떨어진 직선타).',
        '펜스는 좌우 폴 98m, 가운데 115m, 높이 3m예요. 파울 라인 밖은 파울이에요.'] },
      { h: '점수·승리 (설정에서 골라요)', p: ['홈런 (비거리, 기본): 홈런만 점수. 115m 미만 1점, 115~130m 2점, 130m 이상 3점.',
        '안타 구역: 단타 1점(내야를 빠져나간 땅볼·70m 전에 떨어진 직선타), 2루타 2점(더 깊은 타구·펜스 맞은 공·85m 넘게 날아간 뜬공), 3루타 3점(가운데 펜스 앞 아주 깊은 곳), 홈런 4점.',
        '총 비거리: 아웃·파울이 아닌 타구의 비거리(m)를 모두 더해요.',
        '동점이면 동점인 사람끼리 3구씩 연장 타격을 해서 가려요(최대 5라운드, 그래도 같으면 공동 우승).'] },
      { h: '투수', p: ['기본은 기계 투수가 구종과 코스를 섞어 던져요.',
        '상대가 던지기(2명일 때만): 상대가 구종과 코스(9칸)를 몰래 골라 던져요. 한 폰에서 둘이 할 때는 「타자는 보지 마세요」 화면에서 폰을 넘겨요. 3명 이상이면 기계 투수로 해요.'] },
      { h: '예시', p: ['「홈런 (비거리)」, 공 10개: 뜬공으로 겨냥하고 직구를 완벽한 타이밍에 탭 → 122m 홈런 = 2점.',
        '다음 공은 커브인데 너무 일찍 탭 → 왼쪽 파울(0점). 그다음 체인지업을 늦게 탭 → 오른쪽으로 날아가 108m 홈런 = 1점.',
        '10개를 다 치고 합계 9점, 상대 7점 → 내가 승리!'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 타이밍이 정확하고 느린 공에 덜 속아요.'] },
    ],
    tutorial: [
      { sel: '.bt-top', text: '홈런 더비! 한 사람씩 타석에 서서 정해진 공 수만큼 쳐요. 위에 각자 점수가 나와요. 점수가 가장 높으면 이겨요.' },
      { sel: '.bt-pitcher', text: '투수가 와인드업한 뒤 공을 던져요. 직구·커브·슬라이더·체인지업이 섞여 와요. 느린 공은 기다렸다 쳐야 해요.' },
      { sel: '.bt-zone', text: '공이 이 스트라이크 존에 오는 순간 화면 아무 데나 탭! 노란 고리가 공 위로 작아지는 순간이 딱 맞는 타이밍이에요.' },
      { sel: '.bt-zone', text: '일찍 치면 왼쪽, 늦게 치면 오른쪽으로 가요. 너무 빗나가면 파울이나 헛스윙. 몇 ms 빨랐는지/늦었는지 알려 줘요.' },
      { sel: '.bt-aim', text: '「겨냥」으로 공을 띄울 높이를 골라요: 땅볼 · 라이너 · 뜬공. 홈런은 뜬공이 좋지만 타이밍이 어긋나면 잡혀요.' },
      { text: '기본 점수는 홈런만! 115m 미만 1점, 115~130m 2점, 130m 이상 3점. 준비되면 화면을 탭해서 첫 공을 받아요.' },
    ],
    init, actor, apply, ai, result, mount,
    _t: { fly, classify, points, distOf, contact, pitchPos, pitchT, cpuPitch, grade, fenceR, OUTS },
  });
})();
