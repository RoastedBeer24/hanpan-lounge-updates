/* 화성 기지 건설 — 자원망 엔진 빌딩 (1–4인, 턴제, 한 폰 돌려하기 가능)
   솔(화성의 하루)마다: 보급선 화물(모듈 카드 줄)에서 뱀 순서로 2장씩 골라 내 기지(6×6)에 연결해 짓기(또는 분해해 자재).
   모두 고르면 정산: 사건 → 전기 배분 → 물 → 산소·식량 생산 → 주민 소비 → 부족하면 주민이 떠나고, 넉넉하면 이주민이 와요.
   끝 점수 = 주민×3 + 연구 + 돔 공원 + 통신탑 + 남은 자원/5. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ======================= 규칙 데이터 ======================= */
  const W = 6, N = 36;
  const NB = [];
  for (let i = 0; i < N; i++) {
    const x = i % W, y = (i / W) | 0, l = [];
    if (y > 0) l.push(i - W); if (x < W - 1) l.push(i + 1); if (y < W - 1) l.push(i + W); if (x > 0) l.push(i - 1);
    NB.push(l);
  }
  const NB8 = [];
  for (let i = 0; i < N; i++) {
    const x = i % W, y = (i / W) | 0, l = [];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < W && yy < W) l.push(yy * W + xx); }
    NB8.push(l);
  }
  const cellName = (i) => 'ABCDEF'[i % W] + (((i / W) | 0) + 1);

  /* 지형: . 평지, c 크레이터, i 얼음, o 광맥, l 용암동굴 */
  const TER = { '.': '평지', c: '크레이터', i: '얼음', o: '광맥', l: '용암동굴' };
  const TERD = {
    '.': '보통 땅이에요.',
    c: '모듈을 지으려면 자재 +2(메우기). 대신 운석이 떨어져도 안전해요.',
    i: '물 채굴기를 지으면 물이 2배(💧4).',
    o: '광산을 지으면 자재가 2배(🔩4).',
    l: '거주 모듈 침대 +1. 이 칸의 모듈은 운석·플레어에 안전해요.',
  };

  /* 모듈: 코드 → 이름, 비용, 짧은 설명, 끝 점수 설명, 그림 색 */
  const MOD = {
    Q: { nm: '착륙선 본부', c: 0, d: '⚡+2 · O₂+3 · 🌱+3 · 🔩+2 · 침대 3', col: '#e3ae45' },
    S: { nm: '태양광', c: 1, d: '⚡+2 · 태양광끼리 붙으면 +1', col: '#4f7fd6' },
    R: { nm: '소형 원자로', c: 4, d: '⚡+4 (폭풍 무관) · 붙은 거주 모듈 침대 −1', col: '#7fcf5a' },
    B: { nm: '축전지', c: 2, d: '⚡+1 · 모래폭풍 때 ⚡+3', col: '#46c2c9' },
    W: { nm: '물 채굴기', c: 2, d: '⚡1 → 💧+3 (얼음 위 💧+6)', col: '#5fb4f0' },
    O: { nm: '산소 생성기', c: 2, d: '⚡1 💧1 → O₂+4 · 온실 옆 +1', col: '#9ee6ff' },
    G: { nm: '온실', c: 2, d: '⚡1 💧1 → 🌱+4 · 온실끼리 붙으면 +1', col: '#6ccf5f' },
    H: { nm: '거주 모듈', c: 2, d: '침대 4 (용암동굴 5) · 주민 1명과 함께 와요', col: '#f2e9d8' },
    M: { nm: '광산', c: 2, d: '⚡1 → 🔩+2 (광맥 위 🔩+4)', col: '#c98a4a' },
    Y: { nm: '재활용기', c: 3, d: '⚡1 → O₂+1 🌱+1 💧+1', col: '#a7d36a' },
    F: { nm: '3D 공장', c: 3, d: '⚡1 → 🔩+1 · 붙은 광산마다 🔩+1', col: '#d98b5f' },
    L: { nm: '연구소', c: 4, d: '⚡1 → 솔마다 연구 ★+1', col: '#b48cf0' },
    D: { nm: '방어막', c: 3, d: '⚡1 → 둘레 3×3 칸을 운석·플레어에서 지켜요', col: '#7cc8ff' },
    P: { nm: '돔 공원', c: 3, d: '끝 점수: 붙은 거주 모듈마다 ★+2', col: '#8fe08a' },
    T: { nm: '저장 탱크', c: 1, d: 'O₂·🌱·💧 저장 한도 +6 · 산소 누출 막음', col: '#c7c2b8' },
    C: { nm: '통신탑', c: 2, d: '끝 점수: 기지의 모듈 종류마다 ★+1 (여러 개여도 한 번)', col: '#f0c75a' },
    A: { nm: '착륙장', c: 2, d: '솔마다 🔩+1 · 보급선 사건 때 🔩+2 더', col: '#e8a23c' },
    '#': { nm: '통로', c: 1, d: '모듈을 잇는 길', col: '#9a8f86' },
  };
  const CARDS = 'SRBWOGHMYFLDPTCA';
  const CW = { S: 11, R: 3, B: 4, W: 8, O: 9, G: 9, H: 10, M: 6, Y: 4, F: 3, L: 5, D: 3, P: 4, T: 4, C: 3, A: 3 };
  const PRIO = 'WOGYMFLD';     // 전기가 모자랄 때 켜는 순서(앞일수록 먼저)
  const CONS = { W: 1, O: 1, G: 1, Y: 1, M: 1, F: 1, L: 1, D: 1 };

  /* 사건 */
  const EV = {
    c: { nm: '맑은 날', ic: '☀', d: '아무 일도 없어요.' },
    d: { nm: '모래폭풍', ic: '🌪', d: '태양광 전기가 절반(내림). 축전지는 ⚡+3.' },
    D: { nm: '거대 모래폭풍', ic: '🌪', d: '태양광 전기가 0! 축전지는 ⚡+3.' },
    m: { nm: '운석', ic: '☄', d: '표시된 칸 1곳에 운석! 그 칸 모듈이 부서져요.' },
    M: { nm: '유성우', ic: '☄', d: '표시된 칸 2곳에 운석! 그 칸 모듈이 부서져요.' },
    f: { nm: '태양 플레어', ic: '☢', d: '보호 안 된 거주 모듈마다 주민 −1 (용암동굴·방어막은 안전).' },
    s: { nm: '보급선 도착', ic: '🚀', d: '자재 🔩+3 (착륙장마다 +2 더).' },
    n: { nm: '이주 신청', ic: '👥', d: '이번 밤엔 이주민이 최대 4명까지 와요 (보통 2명).' },
    i: { nm: '얼음 혜성', ic: '❄', d: '물 채굴기 생산이 2배.' },
    h: { nm: '풍년', ic: '🌿', d: '켜진 온실마다 식량 🌱+2.' },
    q: { nm: '화성 지진', ic: '〰', d: '수리비로 자재 🔩−2.' },
    w: { nm: '먼지 회오리', ic: '🌀', d: '태양광이 깨끗해져요! 태양광마다 ⚡+1.' },
    k: { nm: '추운 밤', ic: '🥶', d: '난방: 주민 3명마다 전기 ⚡1을 먼저 써요.' },
    g: { nm: '연구 의뢰', ic: '🔬', d: '켜진 연구소마다 연구 ★+2.' },
    l: { nm: '산소 누출', ic: '💨', d: '산소 O₂−3 (저장 탱크가 있으면 −1만).' },
    x: { nm: '원자로 점검', ic: '⚙', d: '원자로가 이번 솔엔 꺼져요.' },
  };
  const EVW = { d: 3, D: 1, m: 3, M: 1, f: 2, s: 3, n: 2, i: 2, h: 2, q: 2, w: 2, k: 2, g: 2, l: 2, x: 1, c: 1 };
  const EV_ONCE = 'DMfxl';

  const START = { o: 4, f: 4, w: 3, m: 7, p: 2 };
  const CAP0 = 10, CAPT = 6, MCAP = 30, GROW = 2;
  const STARS = { 6: [28, 38, 48], 8: [38, 50, 62], 10: [48, 64, 78] };

  /* ======================= 경제 계산 ======================= */
  /* g: 모듈 문자열(36), t: 지형, ev: 이번 사건 코드, rs: [o,f,w,m,pop,rp]
     반환: 칸 상태(st: 0 없음/통로, 1 켜짐, 2 전기 없음, 3 끊김, 4 물 없음), 생산량 등 */
  const E = { con: new Uint8Array(N), st: new Uint8Array(N), q: new Int16Array(N), sh: new Uint8Array(N) };
  function econ(t, g, hq, ev, rs) {
    const con = E.con, st = E.st, q = E.q;
    con.fill(0); st.fill(0);
    let sp = 0; q[sp++] = hq; con[hq] = 1;
    while (sp) { const k = q[--sp]; for (const j of NB[k]) if (!con[j] && g[j] !== '.') { con[j] = 1; q[sp++] = j; } }
    let pw = 0, pu = 0, o = 0, f = 0, wp = 0, wu = 0, m = 0, r = 0, beds = 0, cap = CAP0, nS = 0, nA = 0, nT = 0, nL = 0;
    const storm = ev === 'd' || ev === 'D';
    for (let i = 0; i < N; i++) {
      const c = g[i];
      if (c === '.') continue;
      if (!con[i]) { if (c !== '#') st[i] = 3; continue; }
      if (c === 'Q') { pw += 2; o += 3; f += 3; m += 2; beds += 3; st[i] = 1; }
      else if (c === 'S') {
        let v = 2; for (const j of NB[i]) if (g[j] === 'S' && con[j]) { v = 3; break; }
        if (ev === 'd') v = v >> 1; else if (ev === 'D') v = 0;
        if (ev === 'w') v += 1;
        pw += v; nS++; st[i] = 1;
      } else if (c === 'R') { if (ev !== 'x') { pw += 4; st[i] = 1; } else st[i] = 2; }
      else if (c === 'B') { pw += storm ? 3 : 1; st[i] = 1; }
      else if (c === 'H') {
        let b = t[i] === 'l' ? 5 : 4;
        for (const j of NB[i]) if (g[j] === 'R' && con[j]) { b--; break; }
        beds += b; st[i] = 1;
      } else if (c === 'T') { cap += CAPT; nT++; st[i] = 1; }
      else if (c === 'A') { m += 1; nA++; st[i] = 1; }
      else if (c === 'P' || c === 'C') st[i] = 1;
    }
    if (ev === 'k') pu += Math.ceil(rs[4] / 3);
    // 전기 배분: 정해진 순서대로
    for (let k = 0; k < PRIO.length; k++) {
      const ty = PRIO[k];
      for (let i = 0; i < N; i++) {
        if (g[i] !== ty || !con[i]) continue;
        if (pw - pu >= CONS[ty]) { pu += CONS[ty]; st[i] = 1; } else st[i] = 2;
      }
    }
    // 물: 채굴 → 산소 생성기 → 온실 순서로 씀
    for (let i = 0; i < N; i++) if (g[i] === 'W' && st[i] === 1) { let v = t[i] === 'i' ? 6 : 3; if (ev === 'i') v *= 2; wp += v; }
    let avail = rs[2] + wp;
    for (let i = 0; i < N; i++) if (g[i] === 'Y' && st[i] === 1) { o += 1; f += 1; wp += 1; avail += 1; }
    for (let i = 0; i < N; i++) if (g[i] === 'O' && st[i] === 1) {
      if (avail >= 1) { avail--; wu++; let v = 4; for (const j of NB[i]) if (g[j] === 'G' && con[j]) { v = 5; break; } o += v; } else st[i] = 4;
    }
    for (let i = 0; i < N; i++) if (g[i] === 'G' && st[i] === 1) {
      if (avail >= 1) { avail--; wu++; let v = 4; for (const j of NB[i]) if (g[j] === 'G' && con[j]) { v = 5; break; } if (ev === 'h') v += 2; f += v; } else st[i] = 4;
    }
    for (let i = 0; i < N; i++) {
      if (st[i] !== 1) continue;
      const c = g[i];
      if (c === 'M') m += t[i] === 'o' ? 4 : 2;
      else if (c === 'F') { m += 1; for (const j of NB[i]) if (g[j] === 'M' && con[j]) m += 1; }
      else if (c === 'L') { nL++; r += 1; }
    }
    if (ev === 'g') r += 2 * nL;
    return { pw, pu, o, f, wp, wu, m, r, beds, cap, nS, nA, nT, nL };
  }
  /* 방어막: 켜진 D 둘레 3×3 + 크레이터·용암동굴 */
  function shielded(t, g, i) {
    if (t[i] === 'c' || t[i] === 'l') return true;
    for (const j of NB8[i]) if (g[j] === 'D' && E.st[j] === 1) return true;
    return false;
  }

  /* 한 사람 정산 (rs 바꿈). 반환: 보고 [dO, dF, dW, dM, dPop, dR, 떠난 주민, 부서진 칸들(문자열)] */
  function settle(t, hq, g, rs, ev, mc) {
    const r0 = rs.slice();
    let lost = 0, broke = '';
    let e = econ(t, g, hq, ev, rs);
    // 1. 운석
    if (mc && mc.length) {
      const hit = [];
      for (const c of mc) if (g[c] !== '.' && g[c] !== 'Q' && !shielded(t, g, c)) hit.push(c);
      if (hit.length) {
        const a = g.split(''); for (const c of hit) { a[c] = '.'; broke += cellName(c); }
        g = a.join('');
        rs[3] += hit.length;   // 잔해에서 자재 1씩
        e = econ(t, g, hq, ev, rs);
      }
    }
    // 2. 플레어(정산 전에 확인 — 방어막은 켜져 있어야 함)
    if (ev === 'f') {
      let k = 0; for (let i = 0; i < N; i++) if (g[i] === 'H' && E.con[i] && !shielded(t, g, i)) k++;
      const d = Math.min(k, rs[4] - 1); if (d > 0) { rs[4] -= d; lost += d; }
    }
    // 3. 침대 넘친 주민
    if (rs[4] > e.beds) { lost += rs[4] - e.beds; rs[4] = Math.max(1, e.beds); }
    // 4. 생산
    rs[0] += e.o; rs[1] += e.f; rs[2] += e.wp - e.wu; rs[3] += e.m; rs[5] += e.r;
    // 5. 사건
    if (ev === 's') rs[3] += 3 + 2 * e.nA;
    else if (ev === 'q') rs[3] = Math.max(0, rs[3] - 2);
    else if (ev === 'l') rs[0] = Math.max(0, rs[0] - (e.nT ? 1 : 3));
    // 6. 소비
    rs[0] -= rs[4]; rs[1] -= rs[4];
    const short = Math.max(0, -rs[0], -rs[1]);
    if (rs[0] < 0) rs[0] = 0; if (rs[1] < 0) rs[1] = 0;
    if (short) { const d = Math.min(short, rs[4] - 1); rs[4] -= d; lost += d; }
    // 7. 이주민
    if (!short) {
      const arr = Math.max(0, Math.min(e.beds - rs[4], rs[0], rs[1], ev === 'n' ? GROW * 2 : GROW));
      rs[4] += arr;
    }
    // 8. 저장 한도
    rs[0] = Math.min(rs[0], e.cap); rs[1] = Math.min(rs[1], e.cap); rs[2] = Math.max(0, Math.min(rs[2], e.cap)); rs[3] = Math.min(rs[3], MCAP);
    return { g, rep: [rs[0] - r0[0], rs[1] - r0[1], rs[2] - r0[2], rs[3] - r0[3], rs[4] - r0[4], rs[5] - r0[5], lost, broke], short };
  }

  /* 끝 점수 */
  function scoreOf(s, p) {
    const g = s.g[p], rs = s.rs[p];
    econ(s.t, g, s.hq, 'c', rs);
    const con = E.con;
    let park = 0, div = 0, nC = 0, types = 0, seen = '';
    for (let i = 0; i < N; i++) {
      const c = g[i];
      if (!con[i] || c === '.') continue;
      if (c === 'P') for (const j of NB[i]) if (g[j] === 'H' && con[j]) park += 2;
      if (c === 'C') nC++;
      if (c !== '#' && c !== 'Q' && seen.indexOf(c) < 0) { seen += c; types++; }
    }
    div = nC ? types : 0;
    const pop = rs[4] * 3, res = Math.floor((rs[0] + rs[1] + rs[2] + rs[3]) / 5);
    return { pop, rp: rs[5], park, div, res, tot: pop + rs[5] + park + div + res };
  }

  /* ======================= 게임 진행 ======================= */
  function pickW(w, rnd) { let tt = 0; for (const k in w) tt += w[k]; let r = rnd() * tt; for (const k in w) { r -= w[k]; if (r < 0) return k; } return Object.keys(w)[0]; }
  function order(s, r) {
    const n = s.n; if (n === 1) return [0, 0];
    const st = r % n, a = []; for (let k = 0; k < n; k++) a.push((st + k) % n);
    return a.concat(a.slice().reverse());
  }
  const mkSize = (n) => (n === 1 ? 4 : 2 * n + 1);
  function newMarket(n) {
    let out = '';
    for (let k = 0; k < mkSize(n); k++) {
      let c = pickW(CW, Math.random);
      if (out.split(c).length > 2 && Math.random() < 0.7) c = pickW(CW, Math.random);   // 같은 카드 3장 이상은 드물게
      out += c;
    }
    // 생명 유지 카드가 하나도 없으면 하나 넣기
    if (!/[OGWH]/.test(out)) out = out.slice(0, -1) + 'OGWH'[Math.floor(Math.random() * 4)];
    return out.split('').sort((a, b) => CARDS.indexOf(a) - CARDS.indexOf(b)).join('');
  }
  function meteorCells(s, ev) {
    const k = ev === 'm' ? 1 : ev === 'M' ? 2 : 0, out = [];
    while (out.length < k) { const c = Math.floor(Math.random() * N); if (c !== s.hq && out.indexOf(c) < 0) out.push(c); }
    return out;
  }
  function genEvents(R) {
    let out = 'c', used = '';
    while (out.length < R) {
      const w = Object.assign({}, EVW);
      for (const c of used) if (EV_ONCE.indexOf(c) >= 0) delete w[c];
      delete w[out[out.length - 1]];
      if ((out.match(/[dD]/g) || []).length >= 2) { delete w.d; delete w.D; }
      if ((out.match(/[mM]/g) || []).length >= 2) { delete w.m; delete w.M; }
      if (out.length === 1) { delete w.D; delete w.M; delete w.f; }   // 둘째 솔은 순하게
      const c = pickW(w, Math.random);
      out += c; used += c;
    }
    return out;
  }
  function genTerrain() {
    for (let tries = 0; tries < 50; tries++) {
      const t = Array(N).fill('.');
      const hq = [14, 15, 20, 21][Math.floor(Math.random() * 4)];
      const free = []; for (let i = 0; i < N; i++) if (i !== hq) free.push(i);
      U.shuffle(free);
      const put = (ch, k, far) => { let n = 0; for (let j = 0; j < free.length && n < k; j++) { const c = free[j]; if (t[c] !== '.') continue; if (NB[hq].indexOf(c) >= 0 && ch !== 'c' && far) continue; if (ch === 'c' && NB[hq].indexOf(c) >= 0) continue; t[c] = ch; n++; } };
      put('c', 4); put('i', 4, true); put('o', 4, true); put('l', 3, true);
      // 본부 둘레에 크레이터가 아닌 칸이 2칸 이상
      if (NB[hq].filter((j) => t[j] !== 'c').length < 3) continue;
      return { t: t.join(''), hq };
    }
    return { t: '.'.repeat(N), hq: 14 };
  }

  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(1, Math.min(4, players.length));
    const R = [6, 8, 10].indexOf(+opts.sols) >= 0 ? +opts.sols : 8;
    const tr = genTerrain();
    const g0 = '.'.repeat(tr.hq) + 'Q' + '.'.repeat(N - tr.hq - 1);
    const s = {
      v: 1, n, R, r: 0, k: 0,
      nm: players.slice(0, n).map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 12)),
      t: tr.t, hq: tr.hq,
      g: Array(n).fill(g0),
      rs: Array.from({ length: n }, () => [START.o, START.f, START.w, START.m, START.p, 0]),
      lo: Array(n).fill(0),
      ev: genEvents(R),
      mk: newMarket(n),
      mc: [], mn: [],
      seq: 0, last: null, done: 0, gid: Math.floor(Math.random() * 1e6),
    };
    s.mc = meteorCells(s, s.ev[0]);
    s.mn = R > 1 ? meteorCells(s, s.ev[1]) : [];
    return s;
  }
  function actor(s) { return s.done ? null : order(s, s.r)[s.k]; }

  /* 네트워크(본부에서 이어진 칸) */
  function connected(g, hq) {
    const con = new Uint8Array(N), q = [hq]; con[hq] = 1;
    while (q.length) { const k = q.pop(); for (const j of NB[k]) if (!con[j] && g[j] !== '.') { con[j] = 1; q.push(j); } }
    return con;
  }
  function frontier(g, hq) {   // 지금 지을 수 있는 빈 칸(이어진 칸 옆)
    const con = connected(g, hq), out = [];
    for (let i = 0; i < N; i++) if (g[i] === '.' && NB[i].some((j) => con[j])) out.push(i);
    return out;
  }
  const costAt = (t, code, i) => MOD[code].c + (t[i] === 'c' ? 2 : 0);
  function setCh(g, i, ch) { return g.slice(0, i) + ch + g.slice(i + 1); }

  /* 행동 검사 + 적용(한 사람 기지만). 반환 {g, m} 또는 throw */
  function build(s, seat, a) {
    let g = s.g[seat], m = s.rs[seat][3];
    const code = s.mk[a.i];
    if (!code) throw new Error('bad card');
    const c = a.c == null ? -1 : a.c;
    if (c !== -1) {
      if (!(c >= 0 && c < N && (c | 0) === c) || g[c] !== '.') throw new Error('bad corridor');
      if (frontier(g, s.hq).indexOf(c) < 0) throw new Error('corridor not connected');
      if (m < 1 && a.t !== 'x') throw new Error('no material');
      g = setCh(g, c, '#'); m -= 1;
    }
    if (a.t === 'x') { m += 2; if (m < 0) throw new Error('no material'); return { g, m }; }
    const at = a.at;
    if (!(at >= 0 && at < N && (at | 0) === at) || g[at] !== '.') throw new Error('bad cell');
    if (frontier(g, s.hq).indexOf(at) < 0) throw new Error('not connected');
    const cost = costAt(s.t, code, at);
    if (cost > m) throw new Error('too expensive');
    m -= cost; g = setCh(g, at, code);
    return { g, m };
  }

  function apply(s, seat, a) {
    if (s.done) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a || typeof a !== 'object' || (a.t !== 'b' && a.t !== 'x')) throw new Error('bad action');
    if (!(a.i >= 0 && a.i < s.mk.length && (a.i | 0) === a.i)) throw new Error('bad card');
    const code = s.mk[a.i];
    const r = build(s, seat, a);
    const popBefore = s.rs[seat][4];
    s.g[seat] = r.g; s.rs[seat][3] = r.m;
    if (a.t === 'b' && code === 'H') {   // 거주 모듈은 주민 1명과 함께
      const e = econ(s.t, s.g[seat], s.hq, 'c', s.rs[seat]);
      s.rs[seat][4] = Math.min(e.beds, popBefore + 1);
    }
    s.mk = s.mk.slice(0, a.i) + s.mk.slice(a.i + 1);
    s.last = { id: ++s.seq, seat, k: a.t, m: code, at: a.t === 'b' ? a.at : -1, c: a.c == null ? -1 : a.c };
    s.k++;
    if (s.k >= order(s, s.r).length) {
      // 솔 끝: 모두 정산
      const ev = s.ev[s.r], rep = [];
      for (let p = 0; p < s.n; p++) {
        const res = settle(s.t, s.hq, s.g[p], s.rs[p], ev, s.mc);
        s.g[p] = res.g; s.lo[p] += res.rep[6]; rep.push(res.rep);
      }
      s.last.sol = { r: s.r, e: ev, mc: s.mc.slice(), d: rep };
      s.r++; s.k = 0;
      if (s.r >= s.R) { s.done = 1; s.mk = ''; s.mc = []; s.mn = []; }
      else { s.mk = newMarket(s.n); s.mc = s.mn; s.mn = s.r + 1 < s.R ? meteorCells(s, s.ev[s.r + 1]) : []; }
    }
    return s;
  }

  function result(s) {
    if (!s || !s.done) return null;
    const T = s.g.map((g, i) => scoreOf(s, i));
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const brk = (t, i) => '주민 ' + s.rs[i][4] + '명(' + t.pop + ') · 연구 ' + t.rp + (t.park ? ' · 공원 ' + t.park : '') + (t.div ? ' · 통신탑 ' + t.div : '') + ' · 자원 ' + t.res;
    if (s.n === 1) {
      const t = T[0], need = STARS[s.R] || STARS[8], st = need.filter((v) => t.tot >= v).length;
      return { winners: st > 0 ? [0] : [], title: st ? '별 ' + st + '개!' : '아쉬워요',
        text: '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + t.tot + '점\n' + brk(t, 0) + '\n별 기준 ' + need.join(' / ') + '점' };
    }
    const key = (i) => T[i].tot * 1000 + s.rs[i][4] * 10;
    const ord = T.map((t, i) => i).sort((a, b) => key(b) - key(a) || a - b);
    const top = key(ord[0]), winners = ord.filter((i) => key(i) === top);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 승리!' : '공동 승리',
      text: ord.map((i) => (T.filter((t, j) => key(j) > key(i)).length + 1) + '위  ' + nm(i) + '  ' + T[i].tot + '점\n    ' + brk(T[i], i)).join('\n') };
  }

  /* ======================= AI ======================= */
  const AIW = {
    1: { hz: 1, sp: 0.5, pS: 0.35, kap: 2.5, mat: 0.3, noise: 3, rand: 0.3, cor: 0, ev: 0, deny: 0 },
    2: { hz: 1, sp: 0.5, pS: 0.6, kap: 2, mat: 0.4, noise: 1.2, rand: 0, cor: 1, ev: 1, deny: 0 },
    3: { hz: 2, sp: 0.5, pS: 1.3, kap: 1.4, mat: 0.25, noise: 0.1, rand: 0, cor: 2, ev: 2, deny: 0.2 },
  };
  /* 이 기지를 지금 상태로 끝까지 돌렸을 때의 점수 + 앞날 가치 */
  const clampN = (v, a, b) => (v < a ? a : v > b ? b : v);
  function picksLeftOf(s, p) {
    const ord = order(s, s.r); let k = 0;
    for (let j = s.k + 1; j < ord.length; j++) if (ord[j] === p) k++;
    return k + (s.R - s.r - 1) * 2;
  }
  /* AI용 계획 가치: 주민 목표 T까지 키우려면 모듈이 몇 개 더 필요한지 어림해서, (늘어날 주민 점수 − 필요한 모듈 수 × 비용) 중 가장 좋은 값 */
  function planValue(t, g, hq, pop, picks, after, mats, W8) {
    const e = econ(t, g, hq, 'c', [0, 0, 0, 0, pop, 0]);
    const con = E.con;
    let oP = 3, fP = 3, need = 0, wNeed = 0;
    for (let i = 0; i < N; i++) {
      if (!con[i]) continue;
      const c = g[i];
      if (CONS[c]) need += CONS[c];
      if (c === 'O') { wNeed++; oP += 4; for (const j of NB[i]) if (g[j] === 'G') { oP++; break; } }
      else if (c === 'G') { wNeed++; fP += 4; for (const j of NB[i]) if (g[j] === 'G') { fP++; break; } }
      else if (c === 'Y') { oP++; fP++; }
    }
    const wHave = e.wp + (e.wp ? 0 : 0.5);
    const reach = pop + GROW * after;
    let best = -1e9;
    for (let T = Math.max(1, pop - 6); T <= pop + 14; T++) {
      const nO = Math.ceil(Math.max(0, T - oP) / 4.3), nG = Math.ceil(Math.max(0, T - fP) / 4.3), nH = Math.ceil(Math.max(0, T - e.beds) / 4);
      const wd = wNeed + nO + nG - wHave, nW = wd > 0 ? Math.ceil(wd / 3) : 0;
      const pd = need + nO + nG + nW - e.pw, nS = pd > 0 ? Math.ceil(pd / 2.2) : 0;
      const tot = nO + nG + nH + nW + nS;
      if (tot > picks) { if (T > pop) break; }
      const cost = tot * 2;
      if (cost > mats + 2 * Math.max(0, picks - tot)) { if (T > pop) break; }
      const v = 3 * ((T > reach ? reach : T) - pop) - W8.kap * tot - (tot > picks ? 6 * (tot - picks) : 0);
      if (v > best) best = v;
    }
    return best;
  }
  function evalBase(s, p, g, rs0, W8) {
    const r0 = s.r, left = s.R - r0, hz = Math.min(left, W8.hz);
    const rs = rs0.slice();
    let gg = g, shortPen = 0;
    for (let r = r0; r < r0 + hz; r++) {
      let ev = 'c', mc = null;
      if (W8.ev >= 1 && r === r0) { ev = s.ev[r]; mc = s.mc; }
      else if (W8.ev >= 2 && r === r0 + 1) { ev = s.ev[r]; mc = s.mn; }
      const res = settle(s.t, s.hq, gg, rs, ev, mc);
      gg = res.g;
      shortPen += res.short;
    }
    const after = left - hz;
    const e = econ(s.t, gg, s.hq, 'c', rs);
    const tmp = { t: s.t, hq: s.hq, g: [gg], rs: [rs] };
    const sc = scoreOf(tmp, 0);
    let v = sc.tot - sc.res + (rs[0] + rs[1] + rs[2]) * 0.12 - shortPen * W8.sp;
    v += e.r * after;
    // 앞날: 남은 솔 동안 주민을 얼마나 더 늘릴 수 있나(필요한 모듈 수까지 따져서)
    const pl = picksLeftOf(s, p);
    const mat = rs[3] + e.m * Math.max(0, after);
    if (after > 0) v += W8.pS * planValue(s.t, gg, s.hq, rs[4], pl, after, mat, W8);
    else { const pv = planValue(s.t, gg, s.hq, rs[4], 0, 0, 0, W8); if (pv < 0) v += pv * 0.3; }
    // 자재: 남은 픽 동안 지을 수 있는 힘
    v += Math.min(mat, pl * 2.2) * W8.mat + mat * 0.2 * (pl ? 0.3 : 1);
    return v;
  }
  function allMoves(s, seat, W8) {
    const g0 = s.g[seat], rs0 = s.rs[seat], m0 = rs0[3];
    const fr = frontier(g0, s.hq), con = connected(g0, s.hq);
    const moves = [], seen = {};
    const corOpts = [-1], recOf = {};
    if (W8.cor && m0 >= 1) {
      for (const c of fr) {
        // 새 칸을 열거나(좋은 지형), 끊긴 모듈을 다시 잇는 통로만
        const opens = NB[c].some((j) => g0[j] === '.' && !NB[j].some((k) => con[k]) && (W8.cor >= 2 || s.t[j] !== '.'));
        const recon = NB[c].some((j) => g0[j] !== '.' && !con[j]);
        if (opens || recon) { corOpts.push(c); recOf[c] = recon; }
      }
    }
    for (let i = 0; i < s.mk.length; i++) {
      const code = s.mk[i];
      if (seen[code]) continue; seen[code] = 1;
      moves.push({ t: 'x', i, c: -1 });
      for (const c of corOpts) {
        const g1 = c >= 0 ? setCh(g0, c, '#') : g0, m1 = m0 - (c >= 0 ? 1 : 0);
        const f1 = c >= 0 ? frontier(g1, s.hq) : fr;
        for (const at of f1) {
          if (c >= 0 && !recOf[c] && fr.indexOf(at) >= 0) continue;   // 통로 없이도 되는 칸은 통로 없이
          if (costAt(s.t, code, at) > m1) continue;
          moves.push({ t: 'b', i, at, c });
        }
      }
    }
    return moves;
  }
  function moveValue(s, seat, mv, W8) {
    const code = s.mk[mv.i];
    const r = build(s, seat, mv);
    const rs = s.rs[seat].slice(); rs[3] = r.m;
    if (mv.t === 'b' && code === 'H') { const e = econ(s.t, r.g, s.hq, 'c', rs); rs[4] = Math.min(e.beds, rs[4] + 1); }
    return evalBase(s, seat, r.g, rs, W8);
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const W8 = AIW[lv] || AIW[2];
    const moves = allMoves(s, seat, W8);
    if (!moves.length) return { t: 'x', i: 0, c: -1 };
    const strip = (m) => (m.t === 'x' ? { t: 'x', i: m.i, c: m.c } : { t: 'b', i: m.i, at: m.at, c: m.c });
    if (W8.rand && Math.random() < W8.rand) {
      const b = moves.filter((m) => m.t === 'b');
      const pool = b.length ? b : moves;
      return strip(pool[Math.floor(Math.random() * pool.length)]);
    }
    // 다음 사람이 가져가면 아픈 카드(어려움)
    let deny = null;
    if (W8.deny && s.n > 1) {
      const ord = order(s, s.r), nx = ord[s.k + 1];
      if (nx != null && nx !== seat) {
        deny = {};
        const W2 = AIW[2], base = evalBase(s, nx, s.g[nx], s.rs[nx], W2);
        const seen = {};
        for (let i = 0; i < s.mk.length; i++) {
          const code = s.mk[i]; if (seen[code] != null) continue;
          let best = 0;
          for (const at of frontier(s.g[nx], s.hq)) {
            if (costAt(s.t, code, at) > s.rs[nx][3]) continue;
            const v = moveValue(s, nx, { t: 'b', i, at, c: -1 }, W2) - base;
            if (v > best) best = v;
          }
          seen[code] = best;
        }
        for (const k in seen) deny[k] = seen[k];
      }
    }
    let best = moves[0], bv = -1e9;
    let top2 = 0;
    if (deny) { const vals = Object.values(deny).sort((a, b) => b - a); top2 = vals[1] || 0; }
    for (const mv of moves) {
      let v = moveValue(s, seat, mv, W8) + (Math.random() - 0.5) * 2 * W8.noise;
      if (deny) v += Math.max(0, (deny[s.mk[mv.i]] || 0) - top2) * W8.deny;
      if (v > bv) { bv = v; best = mv; }
    }
    return strip(best);
  }
  function aiDelayFor(s, seat, lv) { return lv >= 3 ? 550 : lv <= 1 ? 900 : 700; }

  /* ======================= 소리 ======================= */
  const Snd = {
    ac: null, nb: null,
    on() { try { return U.store.get('sound', true) !== false; } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    tone(f, d, type, vol, f2, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
        o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.1, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + d + 0.03);
      } catch (e) {}
    },
    noise(d, type, f0, f1, vol, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        if (!this.nb) { const n = ac.sampleRate, b = ac.createBuffer(1, n, ac.sampleRate), x = b.getChannelData(0); for (let i = 0; i < n; i++) x[i] = Math.random() * 2 - 1; this.nb = b; }
        const t = ac.currentTime + (delay || 0), src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.nb; src.loop = true; f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + d); f.Q.value = 0.8;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.3, d * 0.3)); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + d + 0.05);
      } catch (e) {}
    },
    pick() { this.tone(1200, 0.05, 'triangle', 0.05, 1500); },
    place() { this.tone(140, 0.16, 'sine', 0.2, 70); this.noise(0.25, 'lowpass', 1800, 300, 0.08); this.tone(900, 0.08, 'triangle', 0.04, 1400, 0.12); },
    tube() { this.tone(420, 0.06, 'square', 0.04, 300); this.tone(320, 0.07, 'square', 0.035, 240, 0.07); },
    scrap() { for (let k = 0; k < 4; k++) this.tone(700 - k * 90, 0.04, 'square', 0.035, 0, k * 0.05); },
    meteor(delay) { this.noise(0.6, 'bandpass', 3000, 300, 0.12, delay || 0); this.tone(90, 0.45, 'sine', 0.3, 35, (delay || 0) + 0.5); this.noise(0.5, 'lowpass', 900, 120, 0.25, (delay || 0) + 0.5); },
    storm() { this.noise(1.6, 'bandpass', 500, 1400, 0.09); this.noise(1.4, 'lowpass', 300, 900, 0.07, 0.3); },
    good() { [660, 880, 1046].forEach((f, i) => this.tone(f, 0.16, 'triangle', 0.06, 0, i * 0.07)); },
    grow() { this.tone(520, 0.12, 'sine', 0.07, 780); this.tone(780, 0.14, 'sine', 0.06, 1170, 0.1); },
    alarm() { for (let k = 0; k < 3; k++) { this.tone(880, 0.1, 'square', 0.05, 0, k * 0.22); this.tone(620, 0.1, 'square', 0.05, 0, k * 0.22 + 0.11); } },
    blip() { this.tone(980, 0.03, 'square', 0.03); },
  };

  /* ======================= 그림 ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,monospace';
  const fr = (k) => { const x = Math.sin(k * 12.9898 + 4.1414) * 43758.5453; return x - Math.floor(x); };
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  function circ(ctx, x, y, r, col) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); }

  /* 화성 땅 칸 */
  function drawGround(ctx, ter, x, y, s, seed) {
    const g = ctx.createLinearGradient(x, y, x + s * 0.4, y + s);
    g.addColorStop(0, '#bb5a2e'); g.addColorStop(1, '#93401f');
    ctx.fillStyle = g; ctx.fillRect(x, y, s, s);
    // 모래 물결
    ctx.strokeStyle = 'rgba(255,190,140,.16)'; ctx.lineWidth = Math.max(1, s * 0.025);
    for (let k = 0; k < 3; k++) {
      const yy = y + s * (0.2 + k * 0.3 + fr(seed + k) * 0.08);
      ctx.beginPath(); ctx.moveTo(x + s * 0.05, yy); ctx.quadraticCurveTo(x + s * 0.5, yy - s * 0.08, x + s * 0.95, yy + s * 0.02); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(60,20,8,.25)';
    for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(x + s * fr(seed * 3 + k), y + s * fr(seed * 7 + k * 5), s * 0.02 + s * 0.02 * fr(seed + k * 9), 0, 7); ctx.fill(); }
    const cx = x + s / 2, cy = y + s / 2;
    if (ter === 'c') {
      const rg = ctx.createRadialGradient(cx + s * 0.06, cy + s * 0.06, s * 0.05, cx, cy, s * 0.4);
      rg.addColorStop(0, '#4a1a0c'); rg.addColorStop(0.75, '#6e2a14'); rg.addColorStop(1, 'rgba(110,42,20,0)');
      ctx.fillStyle = rg; ctx.beginPath(); ctx.arc(cx, cy, s * 0.4, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(255,170,120,.55)'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.arc(cx, cy, s * 0.36, Math.PI * 0.95, Math.PI * 1.7); ctx.stroke();
      ctx.strokeStyle = 'rgba(40,10,4,.6)'; ctx.beginPath(); ctx.arc(cx, cy, s * 0.36, Math.PI * 1.95, Math.PI * 2.7); ctx.stroke();
    } else if (ter === 'i') {
      ctx.fillStyle = 'rgba(225,240,250,.92)'; ctx.beginPath();
      for (let k = 0; k < 7; k++) { const a = k / 7 * Math.PI * 2, r = s * (0.28 + fr(seed + k * 3) * 0.12); const px = cx + Math.cos(a) * r, py = cy + Math.sin(a) * r * 0.85; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#8fbcd6'; ctx.lineWidth = Math.max(1, s * 0.025);
      ctx.beginPath(); ctx.moveTo(cx - s * 0.18, cy - s * 0.05); ctx.lineTo(cx, cy + s * 0.04); ctx.lineTo(cx + s * 0.16, cy - s * 0.1); ctx.moveTo(cx, cy + s * 0.04); ctx.lineTo(cx + s * 0.04, cy + s * 0.2); ctx.stroke();
      circ(ctx, cx - s * 0.12, cy - s * 0.14, s * 0.035, '#fff');
    } else if (ter === 'o') {
      [[-0.15, 0.05, 0.17], [0.13, -0.08, 0.14], [0.1, 0.17, 0.11]].forEach((r) => {
        ctx.fillStyle = '#4a3530'; ctx.beginPath(); ctx.ellipse(cx + r[0] * s, cy + r[1] * s, r[2] * s, r[2] * s * 0.8, 0.4, 0, 7); ctx.fill();
        ctx.fillStyle = '#6b514a'; ctx.beginPath(); ctx.ellipse(cx + r[0] * s - r[2] * s * 0.25, cy + r[1] * s - r[2] * s * 0.25, r[2] * s * 0.5, r[2] * s * 0.35, 0.4, 0, 7); ctx.fill();
      });
      [[-0.18, 0.02], [-0.1, 0.1], [0.15, -0.1], [0.08, 0.15], [0.17, -0.03]].forEach((p, k) => circ(ctx, cx + p[0] * s, cy + p[1] * s, s * 0.028, k % 2 ? '#7fe0d0' : '#ffd36b'));
    } else if (ter === 'l') {
      ctx.fillStyle = '#5a2414'; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.04, s * 0.36, s * 0.26, 0, 0, 7); ctx.fill();
      const rg = ctx.createRadialGradient(cx, cy + s * 0.08, 1, cx, cy + s * 0.06, s * 0.26);
      rg.addColorStop(0, '#ff7a2a'); rg.addColorStop(0.35, '#3a0f06'); rg.addColorStop(1, '#120503');
      ctx.fillStyle = rg; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.07, s * 0.27, s * 0.17, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(255,170,120,.45)'; ctx.lineWidth = s * 0.04; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.04, s * 0.34, s * 0.24, 0, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke();
    }
  }

  /* 모듈 그림 (cx, cy 중심, s = 칸 크기) */
  function dome(ctx, cx, cy, r, c0, c1, rim) {
    const g = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, r * 0.1, cx, cy, r);
    g.addColorStop(0, c0); g.addColorStop(1, c1);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fill();
    ctx.strokeStyle = rim; ctx.lineWidth = Math.max(1, r * 0.12); ctx.stroke();
  }
  function plate(ctx, cx, cy, s) {
    ctx.fillStyle = 'rgba(30,10,4,.4)'; rr(ctx, cx - s * 0.4 + s * 0.04, cy - s * 0.4 + s * 0.06, s * 0.8, s * 0.8, s * 0.14); ctx.fill();
    const g = ctx.createLinearGradient(cx, cy - s * 0.4, cx, cy + s * 0.4);
    g.addColorStop(0, '#8d847c'); g.addColorStop(1, '#5e5650');
    ctx.fillStyle = g; rr(ctx, cx - s * 0.4, cy - s * 0.4, s * 0.8, s * 0.8, s * 0.14); ctx.fill();
    ctx.strokeStyle = 'rgba(255,240,220,.25)'; ctx.lineWidth = 1; rr(ctx, cx - s * 0.36, cy - s * 0.36, s * 0.72, s * 0.72, s * 0.11); ctx.stroke();
  }
  function drawModule(ctx, code, cx, cy, s, on, tm) {
    const u = s;
    tm = tm || 0;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    switch (code) {
      case 'Q': {
        ctx.fillStyle = 'rgba(30,10,4,.45)'; ctx.beginPath(); ctx.arc(cx + u * 0.05, cy + u * 0.07, u * 0.44, 0, 7); ctx.fill();
        ctx.strokeStyle = '#3d3a37'; ctx.lineWidth = u * 0.07;
        for (let k = 0; k < 3; k++) { const a = k * 2.094 + 0.5; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * u * 0.46, cy + Math.sin(a) * u * 0.46); ctx.stroke(); circ(ctx, cx + Math.cos(a) * u * 0.46, cy + Math.sin(a) * u * 0.46, u * 0.06, '#8d847c'); }
        ctx.fillStyle = '#c99a3f'; ctx.beginPath();
        for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2 + 0.39; const px = cx + Math.cos(a) * u * 0.36, py = cy + Math.sin(a) * u * 0.36; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
        ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#7a5a20'; ctx.lineWidth = u * 0.03; ctx.stroke();
        dome(ctx, cx, cy, u * 0.24, '#fffaf0', '#cfc6b8', '#8d847c');
        const glow = 0.6 + 0.4 * Math.sin(tm * 0.004);
        circ(ctx, cx, cy, u * 0.09, 'rgba(255,200,90,' + (0.5 + glow * 0.4).toFixed(2) + ')');
        circ(ctx, cx + u * 0.28, cy - u * 0.28, u * 0.035, glow > 0.7 ? '#ff5a4a' : '#7a2a20');
        break;
      }
      case 'H': {
        plate(ctx, cx, cy, u * 0.95);
        dome(ctx, cx, cy, u * 0.31, '#fffaf0', '#d6cdbf', '#9a8f86');
        const wc = on ? '#ffcf6b' : '#5a4e44';
        [[-0.13, -0.05], [0.13, -0.05], [0, 0.13]].forEach((p) => { ctx.fillStyle = wc; rr(ctx, cx + p[0] * u - u * 0.045, cy + p[1] * u - u * 0.035, u * 0.09, u * 0.07, u * 0.02); ctx.fill(); });
        ctx.fillStyle = '#7a6e64'; rr(ctx, cx - u * 0.06, cy + u * 0.24, u * 0.12, u * 0.1, u * 0.02); ctx.fill();
        break;
      }
      case 'S': {
        ctx.fillStyle = 'rgba(30,10,4,.4)'; ctx.save(); ctx.translate(cx + u * 0.05, cy + u * 0.07); ctx.rotate(-0.12); ctx.fillRect(-u * 0.38, -u * 0.32, u * 0.76, u * 0.64); ctx.restore();
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.12);
        ctx.fillStyle = '#c9ccd2'; ctx.fillRect(-u * 0.39, -u * 0.33, u * 0.78, u * 0.66);
        const g = ctx.createLinearGradient(-u * 0.35, -u * 0.3, u * 0.35, u * 0.3);
        g.addColorStop(0, on ? '#3b6cc4' : '#2a3a5a'); g.addColorStop(0.5, on ? '#1f3f86' : '#1d2740'); g.addColorStop(1, on ? '#4f86e0' : '#2a3a5a');
        ctx.fillStyle = g; ctx.fillRect(-u * 0.35, -u * 0.29, u * 0.7, u * 0.58);
        ctx.strokeStyle = 'rgba(160,200,255,.45)'; ctx.lineWidth = Math.max(1, u * 0.018);
        ctx.beginPath(); for (let k = 1; k < 4; k++) { ctx.moveTo(-u * 0.35 + k * u * 0.175, -u * 0.29); ctx.lineTo(-u * 0.35 + k * u * 0.175, u * 0.29); } ctx.moveTo(-u * 0.35, 0); ctx.lineTo(u * 0.35, 0); ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.beginPath(); ctx.moveTo(-u * 0.35, -u * 0.29); ctx.lineTo(-u * 0.1, -u * 0.29); ctx.lineTo(-u * 0.35, u * 0.0); ctx.fill();
        ctx.restore();
        break;
      }
      case 'R': {
        plate(ctx, cx, cy, u * 0.95);
        if (on) { const g = ctx.createRadialGradient(cx, cy, u * 0.1, cx, cy, u * 0.42); g.addColorStop(0, 'rgba(140,255,120,.55)'); g.addColorStop(1, 'rgba(140,255,120,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, u * 0.42, 0, 7); ctx.fill(); }
        dome(ctx, cx, cy, u * 0.27, '#c8ced3', '#7a8288', '#4b5156');
        circ(ctx, cx, cy, u * 0.17, '#f0c419');
        ctx.fillStyle = '#2a2a2a';
        for (let k = 0; k < 3; k++) { const a = k * 2.094 - Math.PI / 2; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, u * 0.15, a - 0.5, a + 0.5); ctx.closePath(); ctx.fill(); }
        circ(ctx, cx, cy, u * 0.04, '#f0c419'); circ(ctx, cx, cy, u * 0.025, '#2a2a2a');
        break;
      }
      case 'B': {
        plate(ctx, cx, cy, u * 0.95);
        for (let k = 0; k < 3; k++) {
          const x = cx - u * 0.27 + k * u * 0.19;
          ctx.fillStyle = '#2b343c'; rr(ctx, x, cy - u * 0.24, u * 0.16, u * 0.48, u * 0.03); ctx.fill();
          ctx.fillStyle = on ? '#46c2c9' : '#2d5558'; rr(ctx, x + u * 0.03, cy + u * 0.2 - u * 0.36 * (0.5 + 0.17 * k), u * 0.1, u * 0.36 * (0.5 + 0.17 * k), u * 0.02); ctx.fill();
          ctx.fillStyle = '#9aa3aa'; ctx.fillRect(x + u * 0.05, cy - u * 0.28, u * 0.06, u * 0.04);
        }
        break;
      }
      case 'W': {
        plate(ctx, cx, cy, u * 0.95);
        dome(ctx, cx + u * 0.1, cy + u * 0.08, u * 0.19, on ? '#c6ecff' : '#7b8d96', on ? '#3c93d6' : '#3d5363', '#2c5b80');
        ctx.strokeStyle = '#3d3a37'; ctx.lineWidth = u * 0.05;
        ctx.beginPath(); ctx.moveTo(cx - u * 0.28, cy + u * 0.25); ctx.lineTo(cx - u * 0.17, cy - u * 0.3); ctx.lineTo(cx - u * 0.06, cy + u * 0.25); ctx.stroke();
        ctx.lineWidth = u * 0.025; ctx.beginPath(); ctx.moveTo(cx - u * 0.25, cy + u * 0.08); ctx.lineTo(cx - u * 0.09, cy + u * 0.08); ctx.moveTo(cx - u * 0.22, cy - u * 0.08); ctx.lineTo(cx - u * 0.12, cy - u * 0.08); ctx.stroke();
        circ(ctx, cx + u * 0.04, cy + u * 0.01, u * 0.05, 'rgba(255,255,255,.7)');
        break;
      }
      case 'O': {
        plate(ctx, cx, cy, u * 0.95);
        dome(ctx, cx, cy, u * 0.27, on ? '#effbff' : '#9aa7ad', on ? '#8fd2ea' : '#5d6e75', '#4c7f92');
        ctx.fillStyle = on ? '#14506a' : '#2d3c42'; ctx.font = '700 ' + Math.round(u * 0.2) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('O₂', cx, cy + u * 0.01);
        if (on) { circ(ctx, cx + u * 0.27, cy - u * 0.24, u * 0.05, 'rgba(200,245,255,.8)'); circ(ctx, cx + u * 0.33, cy - u * 0.33, u * 0.03, 'rgba(200,245,255,.6)'); }
        break;
      }
      case 'G': {
        plate(ctx, cx, cy, u * 0.95);
        ctx.fillStyle = on ? 'rgba(170,255,150,.25)' : 'rgba(120,140,110,.25)'; ctx.beginPath(); ctx.arc(cx, cy, u * 0.33, 0, 7); ctx.fill();
        const lc = on ? ['#2f8a34', '#4fb84a', '#7fd65f'] : ['#3f5a3c', '#506b4b', '#5c7356'];
        [[-0.12, -0.08, 0.1, 0], [0.1, -0.1, 0.09, 1], [-0.05, 0.12, 0.1, 2], [0.14, 0.1, 0.08, 1], [0, -0.01, 0.07, 2]].forEach((p) => circ(ctx, cx + p[0] * u, cy + p[1] * u, p[2] * u, lc[p[3]]));
        ctx.strokeStyle = on ? 'rgba(220,255,220,.8)' : 'rgba(180,190,180,.6)'; ctx.lineWidth = Math.max(1, u * 0.03);
        ctx.beginPath(); ctx.arc(cx, cy, u * 0.33, 0, 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx - u * 0.33, cy); ctx.lineTo(cx + u * 0.33, cy); ctx.moveTo(cx, cy - u * 0.33); ctx.lineTo(cx, cy + u * 0.33); ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(cx - u * 0.13, cy - u * 0.17, u * 0.1, u * 0.05, -0.6, 0, 7); ctx.fill();
        break;
      }
      case 'M': {
        ctx.fillStyle = 'rgba(30,10,4,.35)'; ctx.beginPath(); ctx.ellipse(cx + u * 0.05, cy + u * 0.25, u * 0.36, u * 0.12, 0, 0, 7); ctx.fill();
        circ(ctx, cx + u * 0.16, cy + u * 0.18, u * 0.14, '#9a6a3a'); circ(ctx, cx + u * 0.24, cy + u * 0.12, u * 0.08, on ? '#e0b04a' : '#8a7040'); circ(ctx, cx + u * 0.08, cy + u * 0.13, u * 0.05, on ? '#ffd36b' : '#8a7040');
        ctx.strokeStyle = '#6a4a2c'; ctx.lineWidth = u * 0.05;
        ctx.beginPath(); ctx.moveTo(cx - u * 0.3, cy + u * 0.28); ctx.lineTo(cx - u * 0.12, cy - u * 0.34); ctx.lineTo(cx + u * 0.04, cy + u * 0.28); ctx.stroke();
        ctx.lineWidth = u * 0.025; ctx.beginPath(); ctx.moveTo(cx - u * 0.25, cy + u * 0.1); ctx.lineTo(cx, cy + u * 0.1); ctx.moveTo(cx - u * 0.2, cy - u * 0.08); ctx.lineTo(cx - u * 0.05, cy - u * 0.08); ctx.stroke();
        ctx.strokeStyle = '#c9ccd2'; ctx.lineWidth = u * 0.04; ctx.beginPath(); ctx.moveTo(cx - u * 0.12, cy - u * 0.2); ctx.lineTo(cx - u * 0.12, cy + u * 0.3); ctx.stroke();
        circ(ctx, cx - u * 0.12, cy - u * 0.34, u * 0.04, on ? '#ffcf6b' : '#5a4e44');
        break;
      }
      case 'Y': {
        plate(ctx, cx, cy, u * 0.95);
        dome(ctx, cx, cy, u * 0.26, '#c9d4b8', '#7d8c6a', '#55613f');
        ctx.strokeStyle = on ? '#3d8a2a' : '#4d5a44'; ctx.lineWidth = u * 0.055;
        for (let k = 0; k < 3; k++) {
          const a0 = k * 2.094 + tm * (on ? 0.0008 : 0), a1 = a0 + 1.5;
          ctx.beginPath(); ctx.arc(cx, cy, u * 0.15, a0, a1); ctx.stroke();
          const ax = cx + Math.cos(a1) * u * 0.15, ay = cy + Math.sin(a1) * u * 0.15;
          ctx.fillStyle = ctx.strokeStyle; ctx.beginPath(); ctx.moveTo(ax + Math.cos(a1 - 1.2) * u * 0.08, ay + Math.sin(a1 - 1.2) * u * 0.08); ctx.lineTo(ax + Math.cos(a1 + 1.57) * u * 0.07, ay + Math.sin(a1 + 1.57) * u * 0.07); ctx.lineTo(ax - Math.cos(a1 - 0.4) * u * 0.06, ay - Math.sin(a1 - 0.4) * u * 0.06); ctx.fill();
        }
        break;
      }
      case 'F': {
        plate(ctx, cx, cy, u * 0.95);
        ctx.fillStyle = '#a8673f'; rr(ctx, cx - u * 0.28, cy - u * 0.18, u * 0.56, u * 0.42, u * 0.05); ctx.fill();
        ctx.fillStyle = '#7a4a2c'; ctx.fillRect(cx - u * 0.28, cy - u * 0.18, u * 0.56, u * 0.08);
        ctx.fillStyle = '#5a5350'; ctx.fillRect(cx + u * 0.12, cy - u * 0.36, u * 0.1, u * 0.2);
        if (on) { circ(ctx, cx + u * 0.2, cy - u * 0.4, u * 0.06, 'rgba(230,220,210,.55)'); circ(ctx, cx + u * 0.28, cy - u * 0.44, u * 0.045, 'rgba(230,220,210,.35)'); }
        const gc = on ? '#ffd36b' : '#7a6e64';
        ctx.fillStyle = gc; ctx.beginPath();
        for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2 + (on ? tm * 0.001 : 0), r = k % 2 ? u * 0.09 : u * 0.12; const px = cx - u * 0.06 + Math.cos(a) * r, py = cy + u * 0.05 + Math.sin(a) * r; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
        ctx.closePath(); ctx.fill(); circ(ctx, cx - u * 0.06, cy + u * 0.05, u * 0.04, '#7a4a2c');
        break;
      }
      case 'L': {
        plate(ctx, cx, cy, u * 0.95);
        dome(ctx, cx - u * 0.04, cy + u * 0.06, u * 0.24, on ? '#efe4ff' : '#a49cb2', on ? '#a98be0' : '#5f566e', '#5d4a86');
        ctx.strokeStyle = '#d8d4e0'; ctx.lineWidth = u * 0.04;
        ctx.beginPath(); ctx.moveTo(cx + u * 0.14, cy - u * 0.08); ctx.lineTo(cx + u * 0.24, cy - u * 0.22); ctx.stroke();
        ctx.fillStyle = '#e8e4ee'; ctx.beginPath(); ctx.ellipse(cx + u * 0.25, cy - u * 0.25, u * 0.12, u * 0.06, -0.7, 0, 7); ctx.fill();
        if (on) { ctx.fillStyle = '#ffe07a'; ctx.font = '700 ' + Math.round(u * 0.18) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('★', cx - u * 0.04, cy + u * 0.07); }
        break;
      }
      case 'D': {
        plate(ctx, cx, cy, u * 0.95);
        circ(ctx, cx, cy, u * 0.2, '#2f4e6a');
        if (on) { const g = ctx.createRadialGradient(cx, cy, 1, cx, cy, u * 0.2); g.addColorStop(0, '#ffffff'); g.addColorStop(0.4, '#7cc8ff'); g.addColorStop(1, 'rgba(124,200,255,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, u * 0.2, 0, 7); ctx.fill(); }
        else circ(ctx, cx, cy, u * 0.08, '#4a5a68');
        ctx.strokeStyle = '#9aa3aa'; ctx.lineWidth = u * 0.035;
        for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + Math.PI / 4; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * u * 0.2, cy + Math.sin(a) * u * 0.2); ctx.lineTo(cx + Math.cos(a) * u * 0.33, cy + Math.sin(a) * u * 0.33); ctx.stroke(); }
        break;
      }
      case 'P': {
        ctx.fillStyle = 'rgba(30,10,4,.4)'; ctx.beginPath(); ctx.arc(cx + u * 0.04, cy + u * 0.06, u * 0.42, 0, 7); ctx.fill();
        ctx.fillStyle = '#7a6e64'; ctx.beginPath(); ctx.arc(cx, cy, u * 0.42, 0, 7); ctx.fill();
        ctx.fillStyle = on ? '#5fae4e' : '#56704c'; ctx.beginPath(); ctx.arc(cx, cy, u * 0.37, 0, 7); ctx.fill();
        ctx.fillStyle = on ? '#4fa6e0' : '#4d6878'; ctx.beginPath(); ctx.ellipse(cx + u * 0.1, cy + u * 0.12, u * 0.13, u * 0.08, 0.3, 0, 7); ctx.fill();
        [[-0.15, -0.1, 0.1], [0.05, -0.18, 0.08], [-0.2, 0.12, 0.07]].forEach((p) => { circ(ctx, cx + p[0] * u, cy + p[1] * u, p[2] * u, on ? '#2d7a33' : '#3d5a3a'); circ(ctx, cx + p[0] * u - p[2] * u * 0.3, cy + p[1] * u - p[2] * u * 0.3, p[2] * u * 0.45, on ? '#6cc85a' : '#4f6a49'); });
        ctx.fillStyle = 'rgba(255,255,255,.28)'; ctx.beginPath(); ctx.ellipse(cx - u * 0.15, cy - u * 0.22, u * 0.14, u * 0.06, -0.6, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(230,245,255,.6)'; ctx.lineWidth = Math.max(1, u * 0.025); ctx.beginPath(); ctx.arc(cx, cy, u * 0.37, 0, 7); ctx.stroke();
        break;
      }
      case 'T': {
        plate(ctx, cx, cy, u * 0.95);
        [-0.15, 0.15].forEach((dx) => { dome(ctx, cx + dx * u, cy, u * 0.15, '#f4f1ea', '#a39d92', '#6d675e'); ctx.strokeStyle = 'rgba(80,70,60,.5)'; ctx.lineWidth = Math.max(1, u * 0.02); ctx.beginPath(); ctx.arc(cx + dx * u, cy, u * 0.09, 0, 7); ctx.stroke(); });
        break;
      }
      case 'C': {
        ctx.fillStyle = 'rgba(30,10,4,.35)'; ctx.beginPath(); ctx.ellipse(cx + u * 0.06, cy + u * 0.3, u * 0.25, u * 0.08, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = '#b8b2a8'; ctx.lineWidth = u * 0.035;
        ctx.beginPath(); ctx.moveTo(cx - u * 0.18, cy + u * 0.32); ctx.lineTo(cx, cy - u * 0.3); ctx.lineTo(cx + u * 0.18, cy + u * 0.32);
        ctx.moveTo(cx - u * 0.13, cy + u * 0.15); ctx.lineTo(cx + u * 0.08, cy + u * 0.0); ctx.moveTo(cx + u * 0.13, cy + u * 0.15); ctx.lineTo(cx - u * 0.08, cy + u * 0.0);
        ctx.moveTo(cx - u * 0.06, cy - u * 0.1); ctx.lineTo(cx + u * 0.06, cy - u * 0.1); ctx.stroke();
        ctx.fillStyle = '#e8e4dc'; ctx.beginPath(); ctx.ellipse(cx + u * 0.15, cy - u * 0.16, u * 0.12, u * 0.07, -0.5, 0, 7); ctx.fill();
        circ(ctx, cx, cy - u * 0.33, u * 0.05, on && Math.sin(tm * 0.006) > 0 ? '#ff4a3a' : '#7a2a20');
        break;
      }
      case 'A': {
        ctx.fillStyle = 'rgba(30,10,4,.35)'; ctx.beginPath(); ctx.arc(cx + u * 0.04, cy + u * 0.06, u * 0.41, 0, 7); ctx.fill();
        ctx.fillStyle = '#5a5550'; ctx.beginPath();
        for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; const px = cx + Math.cos(a) * u * 0.41, py = cy + Math.sin(a) * u * 0.41; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#f0c419'; ctx.lineWidth = u * 0.04; ctx.beginPath(); ctx.arc(cx, cy, u * 0.25, 0, 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx - u * 0.1, cy + u * 0.06); ctx.lineTo(cx, cy - u * 0.08); ctx.lineTo(cx + u * 0.1, cy + u * 0.06); ctx.stroke();
        for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; circ(ctx, cx + Math.cos(a) * u * 0.35, cy + Math.sin(a) * u * 0.35, u * 0.03, on && ((tm / 300 | 0) % 6) === k ? '#fff2a0' : '#b08a20'); }
        break;
      }
      case '#': {
        const g = ctx.createRadialGradient(cx - u * 0.05, cy - u * 0.05, 1, cx, cy, u * 0.17);
        g.addColorStop(0, '#d2c9c0'); g.addColorStop(1, '#8a8077');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, u * 0.17, 0, 7); ctx.fill();
        ctx.strokeStyle = '#5e5650'; ctx.lineWidth = Math.max(1, u * 0.025); ctx.stroke();
        circ(ctx, cx, cy, u * 0.05, on ? '#ffcf6b' : '#6a5f55');
        break;
      }
    }
  }
  /* 칸 사이 연결 통로(이웃한 두 칸이 모두 지어져 있으면) */
  function drawLinks(ctx, g, ox, oy, cs) {
    ctx.lineCap = 'butt';
    for (let i = 0; i < N; i++) {
      if (g[i] === '.') continue;
      const x = i % W, y = (i / W) | 0;
      for (const d of [1, W]) {
        const j = i + d;
        if (d === 1 && x === W - 1) continue;
        if (j >= N || g[j] === '.') continue;
        const ax = ox + (x + 0.5) * cs, ay = oy + (y + 0.5) * cs, bx = ox + ((j % W) + 0.5) * cs, by = oy + (((j / W) | 0) + 0.5) * cs;
        ctx.strokeStyle = '#4e4741'; ctx.lineWidth = cs * 0.24; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        ctx.strokeStyle = '#a49b92'; ctx.lineWidth = cs * 0.17; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,245,230,.35)'; ctx.lineWidth = cs * 0.04; ctx.beginPath(); ctx.moveTo(ax, ay - cs * 0.04 * (d === 1 ? 1 : 0)); ctx.lineTo(bx, by - cs * 0.04 * (d === 1 ? 1 : 0)); ctx.stroke();
      }
    }
  }
  const THUMB = { '.': null, c: '#5e2412', i: '#d8e8f0', o: '#4a3530', l: '#1a0a06' };

  /* 놓을 칸에서 이 모듈이 내는 것(배지 글자) */
  function cellGain(t, g, code, i) {
    const nbH = (ch) => NB[i].some((j) => g[j] === ch);
    switch (code) {
      case 'S': return '⚡' + (nbH('S') ? 3 : 2);
      case 'R': return '⚡4';
      case 'B': return '⚡1';
      case 'W': return '💧' + (t[i] === 'i' ? 6 : 3);
      case 'O': return 'O₂' + (nbH('G') ? 5 : 4);
      case 'G': return '🌱' + (nbH('G') ? 5 : 4);
      case 'H': return '🛏' + ((t[i] === 'l' ? 5 : 4) - (nbH('R') ? 1 : 0));
      case 'M': return '🔩' + (t[i] === 'o' ? 4 : 2);
      case 'F': return '🔩' + (1 + NB[i].filter((j) => g[j] === 'M').length);
      case 'L': return '★1';
      case 'D': return '🛡';
      case 'P': return '★' + 2 * NB[i].filter((j) => g[j] === 'H').length;
      case 'T': return '📦+6';
      case 'C': { let seen = ''; for (const c of g + code) if (c !== '.' && c !== '#' && c !== 'Q' && seen.indexOf(c) < 0) seen += c; return '★' + seen.length; }
      case 'A': return '🔩1';
    }
    return '';
  }

  /* ======================= 화면 ======================= */
  const CSS = `
.mb{position:absolute;inset:0;display:flex;flex-direction:column;gap:5px;padding:6px 8px 8px;box-sizing:border-box;background:radial-gradient(120% 60% at 50% 40%,#3a1a14 0%,#17131f 78%)}
.mb button{font:inherit;color:inherit}
.mb-pl{display:flex;gap:5px;flex:none}
.mb-chip{flex:1 1 0;min-width:0;height:44px;display:flex;align-items:center;gap:5px;padding:3px 6px 3px 4px;border-radius:11px;border:1px solid var(--line);border-left:4px solid var(--c);background:var(--surface);cursor:pointer;touch-action:manipulation;text-align:left}
.mb-chip .th{position:relative;width:30px;height:30px;flex:none}
.mb-chip canvas{width:30px;height:30px;display:block;border-radius:5px}
.mb-chip .pp{position:absolute;right:-3px;bottom:-3px;min-width:15px;height:15px;padding:0 3px;box-sizing:border-box;border-radius:8px;background:#f2e9d8;color:#2a1d05;font:700 10px/15px var(--f-mono);text-align:center}
.mb-chip .tx{display:flex;flex-direction:column;min-width:0;flex:1 1 auto;line-height:1.15}
.mb-chip .nm{font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mb-chip .sc{font-family:var(--f-mono);font-size:11.5px;color:var(--brass);white-space:nowrap;overflow:hidden}
.mb-chip.view{border-color:var(--brass);background:var(--surface-2)}
.mb-chip.act{animation:mbp 1.3s ease-in-out infinite}
.mb-chip.flash{animation:mbf .9s ease-out}
@keyframes mbp{0%,100%{box-shadow:0 0 0 1px rgba(227,174,69,.25)}50%{box-shadow:0 0 0 3px rgba(227,174,69,.75)}}
@keyframes mbf{0%{background:#7a3a22}100%{background:var(--surface)}}
.mb-ev{flex:none;height:44px;display:flex;align-items:center;gap:8px;padding:3px 8px;border-radius:11px;border:1px solid #6e3a26;background:linear-gradient(90deg,#3a1f1a,#2a1b24);cursor:pointer;touch-action:manipulation;text-align:left}
.mb-ev .sol{font-family:var(--f-display);font-size:16px;color:var(--brass);flex:none;line-height:1}
.mb-ev .sol small{display:block;font-family:var(--f-mono);font-size:10px;color:var(--muted)}
.mb-ev .ic{font-size:22px;flex:none;width:26px;text-align:center}
.mb-ev .tx{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;line-height:1.2}
.mb-ev .t1{font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mb-ev .t2{font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mb-ev .ord{display:flex;flex-direction:column;align-items:flex-end;gap:3px;flex:none}
.mb-ev .ord .nx{font-size:10.5px;color:var(--muted);white-space:nowrap}
.mb-ev .dots{display:flex;gap:3px}
.mb-ev .dots i{width:8px;height:8px;border-radius:50%;display:block;background:var(--c);opacity:.35}
.mb-ev .dots i.now{opacity:1;box-shadow:0 0 0 2px rgba(255,255,255,.8)}
.mb-ev .dots i.done{opacity:.12}
.mb-ev.storm{background:linear-gradient(90deg,#5a3418,#3a2418)}
.mb-ev.hit{background:linear-gradient(90deg,#5a1f1a,#3a1820)}
.mb-res{flex:none;display:grid;grid-template-columns:1.1fr 1fr 1fr 1fr 1fr 1.1fr;gap:3px;padding:0;border:0;background:none;cursor:pointer;touch-action:manipulation}
.mb-r{min-width:0;height:46px;border-radius:9px;background:#1d1726;border:1px solid var(--line);display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.1}
.mb-r .a{font-size:13.5px;font-weight:700;font-family:var(--f-mono);white-space:nowrap}
.mb-r .a span{font-family:var(--f-body);font-size:11.5px;margin-right:2px}
.mb-r .b{font-size:11px;font-family:var(--f-mono);white-space:nowrap;color:var(--muted)}
.mb-r .b.up{color:#8fe08a}.mb-r .b.dn{color:#ff7a66}.mb-r .b.pv{color:var(--brass);font-weight:700}
.mb-r.warn{border-color:#ee6a55;background:#3a1a1e}
.mb-r.pop{animation:mbpop .7s ease-out}
@keyframes mbpop{0%{transform:scale(1.15);background:#4a3a1a}100%{transform:none}}
.mb-board{position:relative;flex:1 1 auto;min-height:120px}
.mb-back{position:absolute;left:2px;top:2px;z-index:2;min-height:44px !important;padding:6px 10px !important}
.mb-hint{flex:none;font-size:12.5px;line-height:17px;min-height:17px;color:var(--muted);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mb-hint.me{color:var(--brass)}
.mb-mk{flex:none;display:flex;gap:5px;overflow-x:auto;overflow-y:hidden;touch-action:pan-x;scrollbar-width:none;padding:4px 1px 1px;scroll-behavior:smooth}
.mb-mk::-webkit-scrollbar{display:none}
.mb-card{flex:0 0 auto;width:60px;height:62px;border-radius:11px;border:1px solid #7a5a3a;background:linear-gradient(#3a2a26,#261b20);display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding:0 2px 3px;position:relative;cursor:pointer;touch-action:pan-x;transition:transform .12s}
.mb-card canvas{position:absolute;left:50%;top:3px;transform:translateX(-50%);width:38px;height:38px}
.mb-card .n{font-size:10.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;position:relative}
.mb-card .c{position:absolute;right:2px;top:2px;font:700 10.5px var(--f-mono);background:rgba(23,19,31,.88);color:var(--brass);border-radius:6px;padding:0 3px}
.mb-card.sel{border-color:var(--brass);transform:translateY(-4px);box-shadow:0 5px 12px rgba(0,0,0,.45);background:linear-gradient(#5a3a26,#3a2420)}
.mb-card.poor .c{color:#ff7a66}
.mb-card[disabled]{cursor:default}
.mb-card.new{animation:mbin .5s ease-out}
@keyframes mbin{0%{transform:translateY(-14px);opacity:0}100%{transform:none;opacity:1}}
.mb-empty{flex:1;height:62px;display:flex;align-items:center;justify-content:center;font-size:12px;color:var(--muted);border:1px dashed var(--line);border-radius:11px}
.mb-act{display:flex;gap:5px;flex:none}
.mb-act .btn{min-height:44px;padding:6px 8px;font-size:13.5px}
.mb-act .cor{flex:0 0 auto;min-width:74px}
.mb-act .scr{flex:0 0 auto;min-width:76px}
.mb-act .un{flex:0 0 auto;min-width:48px;font-size:18px}
.mb-act .ok{flex:1 1 auto;min-width:0}
.mb-act .on{background:#5a3a1a;border-color:var(--brass)}
.mb-ov .sheet{gap:10px;touch-action:pan-y;overscroll-behavior:contain}
.mb-ov h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:21px}
.mb-ov p{margin:0;line-height:1.5;font-size:14px}
.mb-ov .row2{display:flex;align-items:center;gap:10px}
.mb-ov table{border-collapse:collapse;width:100%;font-size:13px}
.mb-ov td{padding:4px 2px;border-bottom:1px solid var(--line);vertical-align:top}
.mb-ov td:first-child{white-space:nowrap}
.mb-ov td.n{font-family:var(--f-mono);text-align:right;color:var(--brass);font-weight:700;white-space:nowrap}
.mb-ov canvas{flex:none}
@media (max-height:700px){.mb{gap:4px;padding:5px 7px 7px}.mb-r{height:42px}.mb-card{height:58px}.mb-card canvas{width:34px;height:34px}}
`;

  function mount(root, api) {
    const h = L.h;
    const styleEl = h('style', { text: CSS });
    const wrap = h('div', { class: 'mb' });
    const plRow = h('div', { class: 'mb-pl' });
    const evBtn = h('button', { class: 'mb-ev', 'aria-label': '이번 솔 사건 자세히' });
    const resBtn = h('button', { class: 'mb-res', 'aria-label': '기지 정산표 보기' });
    const board = h('div', { class: 'mb-board' });
    const hint = h('div', { class: 'mb-hint' });
    const mkRow = h('div', { class: 'mb-mk' });
    const actRow = h('div', { class: 'mb-act' });
    const corBtn = h('button', { class: 'btn cor', 'aria-label': '통로 깔기 (자재 1)' });
    const scrBtn = h('button', { class: 'btn scr', 'aria-label': '카드를 분해해 자재 2 얻기' });
    const unBtn = h('button', { class: 'btn un', text: '↶', 'aria-label': '되돌리기' });
    const okBtn = h('button', { class: 'btn primary ok', text: '확정' });
    actRow.append(corBtn, scrBtn, unBtn, okBtn);
    wrap.append(plRow, evBtn, resBtn, board, hint, mkRow, actRow);
    root.append(styleEl, wrap);
    const cv = U.canvas(board);
    const ctx = cv.ctx;
    const backBtn = h('button', { class: 'btn sm mb-back', text: '← 내 기지', hidden: true });
    board.append(backBtn);
    const resCells = [];
    ['⚡', 'O₂', '🌱', '💧', '🔩', '👤'].forEach((ic, k) => {
      const a = h('div', { class: 'a' }), b = h('div', { class: 'b' });
      const c = h('div', { class: 'mb-r' }, a, b);
      resCells.push({ c, a, b, ic, k });
      resBtn.append(c);
    });

    let st = null, gameKey = '', shownId = -1, manual = null, followSeat = 0, pending = false, pendT = 0;
    let sel = { i: -1, at: -1, c: -1, x: 0, cor: 0 };
    let geo = null, hover = -1, opts = null;
    let anim = null, stopLoop = null, watchdog = 0, lastFrame = 0;
    let terrLayer = null, terrKey = '';
    const parts = [];   // 먼지 입자
    let cards = [], mkKey = '';

    const clearSel = () => { sel = { i: -1, at: -1, c: -1, x: 0, cor: 0 }; };
    const myTurn = () => { if (!st) return false; const a = actor(st); return a != null && api.canAct(a) && !pending; };
    const pname = (i) => (api.players[i] ? api.players[i].name : st.nm[i]);
    function viewSeat() {
      if (!st) return 0;
      if (manual != null && manual < st.n) return manual;
      const a = actor(st), mine = api.mySeats();
      if (a != null && api.canAct(a)) return a;
      if (mine.length === 1) return mine[0];
      return Math.min(followSeat, st.n - 1);
    }

    /* ---------- 미리보기 계산 ---------- */
    function previewBase(seat) {   // 고른 것을 반영한 {g, rs}
      let g = st.g[seat];
      const rs = st.rs[seat].slice();
      if (!(myTurn() && seat === actor(st) && sel.i >= 0)) return { g, rs, on: false };
      const code = st.mk[sel.i];
      if (sel.c >= 0) { g = setCh(g, sel.c, '#'); rs[3] -= 1; }
      if (sel.x) rs[3] += 2;
      else if (sel.at >= 0) {
        g = setCh(g, sel.at, code); rs[3] -= costAt(st.t, code, sel.at);
        if (code === 'H') { const e = econ(st.t, g, st.hq, 'c', rs); rs[4] = Math.min(e.beds, rs[4] + 1); }
      }
      return { g, rs, on: sel.c >= 0 || sel.x || sel.at >= 0 };
    }
    function forecast(g, rs) {   // 이번 솔 끝 예상
      const rs2 = rs.slice();
      const res = settle(st.t, st.hq, g, rs2, st.ev[st.r], st.mc);
      const e = econ(st.t, res.g, st.hq, st.ev[st.r], rs);
      return { rs: rs2, rep: res.rep, short: res.short, e: Object.assign({}, e) };
    }
    function statusOf(g, rs) { econ(st.t, g, st.hq, st.done ? 'c' : st.ev[st.r], rs); return Array.from(E.st); }
    function computeOpts() {
      opts = null;
      if (!st || st.done || !myTurn() || sel.i < 0) return;
      const seat = actor(st), code = st.mk[sel.i];
      let g = st.g[seat], m = st.rs[seat][3];
      if (sel.c >= 0) { g = setCh(g, sel.c, '#'); m -= 1; }
      const legal = {}, poor = {};
      if (sel.cor) {
        for (const c of frontier(st.g[seat], st.hq)) legal[c] = '통로';
      } else if (!sel.x) {
        for (const c of frontier(g, st.hq)) {
          if (costAt(st.t, code, c) > m) poor[c] = 1;
          else legal[c] = cellGain(st.t, g, code, c);
        }
      }
      opts = { seat, code, legal, poor };
    }

    /* ---------- 사람 칩 ---------- */
    function thumb(c, seat) {
      const d = Math.min(2, window.devicePixelRatio || 1), S = 30;
      if (c.width !== S * d) { c.width = S * d; c.height = S * d; }
      const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0);
      x.fillStyle = '#93401f'; x.fillRect(0, 0, S, S);
      const g = st.g[seat], cs = S / W;
      for (let i = 0; i < N; i++) {
        const px = (i % W) * cs, py = ((i / W) | 0) * cs;
        const tc = THUMB[st.t[i]]; if (tc) { x.fillStyle = tc; x.fillRect(px + 0.5, py + 0.5, cs - 1, cs - 1); }
        if (g[i] !== '.') { x.fillStyle = MOD[g[i]].col; x.fillRect(px + 0.8, py + 0.8, cs - 1.6, cs - 1.6); }
      }
    }
    function renderChips() {
      if (plRow.children.length !== st.n) {
        plRow.innerHTML = '';
        for (let i = 0; i < st.n; i++) {
          const b = h('button', { class: 'mb-chip', style: { '--c': api.players[i] ? api.players[i].color : '#888' }, onclick() { onChip(i); } },
            h('span', { class: 'th' }, h('canvas'), h('span', { class: 'pp' })), h('span', { class: 'tx' }, h('span', { class: 'nm' }), h('span', { class: 'sc' })));
          plRow.append(b);
        }
      }
      const a = actor(st), v = viewSeat();
      for (let i = 0; i < st.n; i++) {
        const b = plRow.children[i], sc = scoreOf(st, i);
        thumb(b.querySelector('canvas'), i);
        b.querySelector('.nm').textContent = pname(i);
        b.querySelector('.sc').textContent = st.n >= 3 ? '★' + sc.tot : '👤' + st.rs[i][4] + ' ★' + sc.tot + (st.n === 1 ? ' / 별 ' + (STARS[st.R] || STARS[8]).join('·') : '');
        const pp = b.querySelector('.pp'); pp.textContent = st.rs[i][4]; pp.hidden = st.n < 3;
        b.classList.toggle('view', i === v && st.n > 1);
        b.classList.toggle('act', i === a);
        b.setAttribute('aria-label', pname(i) + ' 주민 ' + st.rs[i][4] + '명 ' + sc.tot + '점' + (st.n > 1 ? ' · 기지 보기' : ''));
      }
    }
    function onChip(i) {
      if (st.n === 1) { openScore(); return; }
      Snd.blip();
      const m = manual; manual = null; const auto = viewSeat(); manual = m;
      if (manual === i || i === auto) manual = null; else manual = i;
      if (manual != null && manual !== auto) api.toast(pname(i) + '의 기지');
      renderAll();
    }

    /* ---------- 사건 줄 ---------- */
    function renderEvent() {
      evBtn.innerHTML = '';
      evBtn.classList.remove('storm', 'hit');
      if (st.done) {
        evBtn.append(h('span', { class: 'sol', text: '끝' }), h('span', { class: 'ic', text: '🏁' }),
          h('span', { class: 'tx' }, h('span', { class: 't1', text: st.R + '솔이 모두 지났어요' }), h('span', { class: 't2', text: '점수를 세어 볼까요?' })));
        return;
      }
      const ec = st.ev[st.r], ev = EV[ec];
      if (ec === 'd' || ec === 'D') evBtn.classList.add('storm');
      if (ec === 'm' || ec === 'M' || ec === 'f') evBtn.classList.add('hit');
      const ord = order(st, st.r);
      const dots = h('span', { class: 'dots' });
      ord.forEach((p, k) => dots.append(h('i', { class: k < st.k ? 'done' : k === st.k ? 'now' : '', style: { '--c': api.players[p] ? api.players[p].color : '#888' } })));
      const nx = st.r + 1 < st.R ? EV[st.ev[st.r + 1]] : null;
      evBtn.append(h('span', { class: 'sol' }, '솔 ' + (st.r + 1), h('small', { text: '/ ' + st.R })),
        h('span', { class: 'ic', text: ev.ic }),
        h('span', { class: 'tx' }, h('span', { class: 't1', text: '오늘 밤: ' + ev.nm }), h('span', { class: 't2', text: ev.d })),
        h('span', { class: 'ord' }, h('span', { class: 'nx', text: nx ? '다음 ' + nx.ic + ' ' + nx.nm : '마지막 솔' }), dots));
    }

    /* ---------- 자원 줄 ---------- */
    let lastRes = null;
    function renderRes() {
      const v = viewSeat(), isMe = myTurn() && v === actor(st);
      const base = { g: st.g[v], rs: st.rs[v].slice() };
      const pv = isMe ? previewBase(v) : { on: false };
      if (st.done) {
        const rs = st.rs[v], e = econ(st.t, st.g[v], st.hq, 'c', rs);
        const vals = [e.pw - e.pu >= 0 ? e.pu + '/' + e.pw : e.pu + '/' + e.pw, rs[0], rs[1], rs[2], rs[3], rs[4] + '/' + e.beds];
        resCells.forEach((r, k) => { r.a.innerHTML = ''; r.a.append(h('span', { text: r.ic }), String(vals[k])); r.b.textContent = k === 0 ? '전기' : ''; r.b.className = 'b'; r.c.classList.remove('warn'); });
        return;
      }
      const f0 = forecast(base.g, base.rs);
      const f1 = pv.on ? forecast(pv.g, pv.rs) : null;
      const cur = pv.on ? pv.rs : base.rs;
      const show = (k) => {
        // k: 1 O₂, 2 🌱, 3 💧, 4 🔩 → rs 인덱스 k-1
        const now = cur[k - 1], d0 = f0.rs[k - 1] - base.rs[k - 1], d1 = f1 ? f1.rs[k - 1] - cur[k - 1] : null;
        return { now, d0, d1 };
      };
      lastRes = { f0, f1 };
      for (const r of resCells) {
        r.a.innerHTML = ''; r.b.className = 'b'; r.c.classList.remove('warn');
        if (r.k === 0) {
          const e0 = f0.e, e1 = f1 ? f1.e : null, e = e1 || e0;
          r.a.append(h('span', { text: '⚡' }), e.pu + '/' + e.pw);
          const off = (f1 ? statusOf(pv.g, pv.rs) : statusOf(base.g, base.rs)).filter((x) => x === 2).length;
          r.b.textContent = off ? '꺼짐 ' + off : '여유 ' + (e.pw - e.pu);
          if (off) { r.b.classList.add('dn'); r.c.classList.add('warn'); } else r.b.classList.add('up');
          if (e1 && (e1.pw !== e0.pw || e1.pu !== e0.pu)) r.b.classList.add('pv');
        } else if (r.k === 5) {
          const rs = cur, e = econ(st.t, pv.on ? pv.g : base.g, st.hq, 'c', rs);
          r.a.append(h('span', { text: '👤' }), rs[4] + '/' + e.beds);
          const d0 = f0.rs[4] - base.rs[4], d1 = f1 ? f1.rs[4] - pv.rs[4] : null;
          const d = d1 != null ? d1 : d0;
          r.b.textContent = (d1 != null && d1 !== d0 ? (d0 >= 0 ? '+' : '') + d0 + '→' : '') + (d > 0 ? '+' + d : d < 0 ? '−' + (-d) : '±0');
          r.b.classList.add(d1 != null && d1 !== d0 ? 'pv' : d > 0 ? 'up' : d < 0 ? 'dn' : 'b');
          if (d < 0) r.c.classList.add('warn');
        } else {
          const { now, d0, d1 } = show(r.k);
          const chg = pv.on && now !== base.rs[r.k - 1];
          r.a.append(h('span', { text: r.ic }), chg ? h('b', { style: { color: 'var(--brass)' }, text: String(now) }) : String(now));
          const d = d1 != null ? d1 : d0;
          const fmt = (x) => (x > 0 ? '+' + x : x < 0 ? '−' + (-x) : '±0');
          r.b.textContent = d1 != null && d1 !== d0 ? fmt(d0) + '→' + fmt(d1) : fmt(d);
          if (d1 != null && d1 !== d0) r.b.classList.add('pv'); else r.b.classList.add(d > 0 ? 'up' : d < 0 ? 'dn' : 'b');
          const fin = (f1 || f0).rs[r.k - 1];
          if ((r.k === 1 || r.k === 2) && ((f1 || f0).short > 0 || fin === 0)) r.c.classList.add('warn');
        }
      }
    }

    /* ---------- 시장 ---------- */
    function cardCanvas(code, sz) {
      const c = document.createElement('canvas'), d = Math.min(2.5, window.devicePixelRatio || 1);
      c.width = Math.round(sz * d); c.height = Math.round(sz * d);
      const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0);
      drawModule(x, code, sz / 2, sz / 2, sz * 0.98, true, 0);
      return c;
    }
    function renderMarket() {
      const key = st.gid + ':' + st.r + ':' + st.mk + ':' + st.done;
      if (key !== mkKey) {
        const fresh = !mkKey || mkKey.split(':')[1] !== String(st.r);
        mkKey = key; mkRow.innerHTML = ''; cards = [];
        if (!st.mk.length) mkRow.append(h('div', { class: 'mb-empty', text: st.done ? '모든 솔이 끝났어요' : '화물 정리 중…' }));
        for (let i = 0; i < st.mk.length; i++) {
          const code = st.mk[i];
          const b = h('button', { class: 'mb-card' + (fresh ? ' new' : ''), onclick() { onCard(i); } },
            cardCanvas(code, 38), h('span', { class: 'c', text: '🔩' + MOD[code].c }), h('span', { class: 'n', text: MOD[code].nm }));
          if (fresh) b.style.animationDelay = (i * 40) + 'ms';
          mkRow.append(b); cards.push(b);
        }
      }
      const mine = myTurn() && !anim;
      const seat = actor(st);
      const m = seat != null ? st.rs[seat][3] : 0;
      cards.forEach((b, i) => {
        const code = st.mk[i];
        b.classList.toggle('sel', sel.i === i);
        b.classList.toggle('poor', MOD[code].c > m);
        b.disabled = !mine;
        b.setAttribute('aria-label', MOD[code].nm + ' 자재 ' + MOD[code].c + ' · ' + MOD[code].d);
        b.title = MOD[code].nm + ' (🔩' + MOD[code].c + ') ' + MOD[code].d;
      });
    }
    function onCard(i) {
      if (!myTurn() || anim) return;
      if (sel.i === i && !sel.cor) { openModule(st.mk[i]); return; }
      Snd.pick(); api.buzz(8);
      const keepC = sel.c;
      sel = { i, at: -1, c: keepC, x: 0, cor: 0 };
      manual = null;
      computeOpts();
      // 고른 카드가 보이게
      const b = cards[i]; if (b && b.scrollIntoView) try { b.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e) {}
      renderAll();
    }

    /* ---------- 버튼 ---------- */
    function renderAct() {
      const mine = myTurn() && !anim;
      actRow.style.display = api.mySeats().length ? '' : 'none';
      const seat = actor(st);
      const m = seat != null ? st.rs[seat][3] : 0;
      corBtn.textContent = sel.c >= 0 ? '통로 ✓' : '🛤 통로 1';
      corBtn.classList.toggle('on', !!sel.cor || sel.c >= 0);
      corBtn.disabled = !mine || sel.i < 0 || (m < 1 && sel.c < 0 && !sel.x);
      scrBtn.textContent = sel.x ? '분해 ✓' : '♻ 분해 +2';
      scrBtn.classList.toggle('on', !!sel.x);
      scrBtn.disabled = !mine || sel.i < 0;
      unBtn.disabled = !mine || sel.i < 0;
      let ready = false, txt = '확정';
      if (mine && sel.i >= 0) {
        const code = st.mk[sel.i];
        if (sel.x) { ready = true; txt = '분해 확정 🔩+2'; }
        else if (sel.at >= 0) { ready = true; txt = MOD[code].nm + ' 짓기'; }
        else txt = '칸을 고르세요';
      }
      okBtn.disabled = !ready;
      okBtn.textContent = txt;
    }
    corBtn.onclick = () => {
      if (!myTurn() || anim || sel.i < 0) return;
      api.buzz(8); Snd.blip();
      if (sel.c >= 0) { sel.c = -1; sel.cor = 0; if (sel.at >= 0 && !frontier(st.g[actor(st)], st.hq).includes(sel.at)) sel.at = -1; }
      else if (sel.cor) sel.cor = 0;
      else { sel.cor = 1; api.toast('통로를 놓을 칸을 톡 — 자재 1'); }
      computeOpts(); renderAll();
    };
    scrBtn.onclick = () => {
      if (!myTurn() || anim || sel.i < 0) return;
      api.buzz(8); Snd.blip();
      sel.x = sel.x ? 0 : 1; sel.cor = 0;
      if (sel.x) sel.at = -1;
      computeOpts(); renderAll();
    };
    unBtn.onclick = () => {
      if (!myTurn() || anim) return;
      Snd.blip();
      if (sel.x) sel.x = 0;
      else if (sel.at >= 0) sel.at = -1;
      else if (sel.cor) sel.cor = 0;
      else if (sel.c >= 0) sel.c = -1;
      else clearSel();
      computeOpts(); renderAll();
    };
    okBtn.onclick = () => {
      if (!myTurn() || anim || sel.i < 0) return;
      let a;
      if (sel.x) a = { t: 'x', i: sel.i, c: sel.c };
      else if (sel.at >= 0) a = { t: 'b', i: sel.i, at: sel.at, c: sel.c };
      else return;
      api.buzz(15);
      pending = true; clearTimeout(pendT);
      pendT = setTimeout(() => { pending = false; renderAll(); }, 4000);
      clearSel(); renderAll();
      api.act(a);
    };
    backBtn.onclick = () => { manual = null; Snd.blip(); renderAll(); };

    /* ---------- 힌트 ---------- */
    function lastText(l) {
      if (!l) return '';
      const nm = pname(l.seat);
      if (l.k === 'x') return nm + ': ' + MOD[l.m].nm + ' 분해 🔩+2' + (l.c >= 0 ? ' · 통로' : '');
      return nm + ': ' + MOD[l.m].nm + ' 지음' + (l.c >= 0 ? ' (+통로)' : '');
    }
    function renderHint() {
      let t = '', me = false;
      const a = actor(st);
      if (st.done) t = '기지 완성! 점수를 세어 볼까요?';
      else if (anim && anim.sol) t = '솔 ' + (anim.sol.r + 1) + ' 밤 · 정산 중…';
      else if (myTurn() && !anim) {
        me = true;
        const v = viewSeat();
        const who = api.mySeats().length > 1 ? pname(a) + ' 차례 · ' : '';
        if (v !== a) t = '다른 기지를 보는 중 · 「← 내 기지」';
        else if (sel.i < 0) t = who + '아래 화물에서 모듈을 고르세요 (' + (2 - order(st, st.r).slice(0, st.k).filter((p) => p === a).length) + '장 중 ' + (order(st, st.r).slice(0, st.k).filter((p) => p === a).length + 1) + '번째)';
        else {
          const code = st.mk[sel.i];
          if (sel.cor) t = '통로 놓을 칸 톡 (빛나는 칸, 🔩1)';
          else if (sel.x) t = MOD[code].nm + ' 분해 → 🔩+2 · 「분해 확정」';
          else if (sel.at < 0) t = MOD[code].nm + ': ' + MOD[code].d;
          else t = cellName(sel.at) + '에 ' + MOD[code].nm + ' · 위 자원 줄에서 바뀌는 값 확인 → 짓기';
        }
      } else if (pending) t = '보내는 중…';
      else {
        const lt = lastText(st.last);
        t = (lt ? lt + ' · ' : '') + (a != null ? (api.players[a] && api.players[a].ai ? pname(a) + ' 고르는 중…' : pname(a) + ' 차례') : '');
      }
      hint.textContent = t;
      hint.classList.toggle('me', me);
    }

    /* ---------- 판 그리기 ---------- */
    function layout() {
      const Wd = cv.w, Ht = cv.h;
      const side = Math.max(60, Math.min(Wd - 2, Ht - 2));
      const fw = Math.max(4, Math.round(side * 0.022));
      const cs = (side - 2 * fw) / W;
      const extra = Ht - side, ph = extra >= 70 ? Math.min(extra - 8, 96) : 0;
      geo = { x0: Math.round((Wd - side) / 2), y0: Math.round((Ht - side - (ph ? ph + 8 : 0)) / 2), side, fw, cs, ph };
      geo.ox = geo.x0 + fw; geo.oy = geo.y0 + fw;
      terrKey = '';
    }
    cv.onresize = () => { layout(); draw(performance.now()); };
    function terrain() {
      const d = Math.min(2.5, window.devicePixelRatio || 1);
      const key = st.gid + ':' + cv.w + 'x' + cv.h + ':' + d;
      if (key === terrKey && terrLayer) return terrLayer;
      terrKey = key;
      const c = terrLayer || document.createElement('canvas');
      c.width = Math.max(1, Math.round(cv.w * d)); c.height = Math.max(1, Math.round(cv.h * d));
      const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, cv.w, cv.h);
      const { x0, y0, side, fw, cs, ox, oy } = geo;
      x.fillStyle = 'rgba(0,0,0,.45)'; rr(x, x0 + 2, y0 + 5, side, side, fw * 2); x.fill();
      const fg = x.createLinearGradient(x0, y0, x0, y0 + side); fg.addColorStop(0, '#6e3a26'); fg.addColorStop(1, '#3a1d14');
      x.fillStyle = fg; rr(x, x0, y0, side, side, fw * 2); x.fill();
      for (let i = 0; i < N; i++) drawGround(x, st.t[i], ox + (i % W) * cs, oy + ((i / W) | 0) * cs, cs + 0.5, i * 7 + 3);
      // 격자 선
      x.strokeStyle = 'rgba(40,12,4,.35)'; x.lineWidth = 1;
      x.beginPath(); for (let k = 1; k < W; k++) { x.moveTo(ox + k * cs, oy); x.lineTo(ox + k * cs, oy + cs * W); x.moveTo(ox, oy + k * cs); x.lineTo(ox + cs * W, oy + k * cs); } x.stroke();
      // 칸 이름(작게)
      x.fillStyle = 'rgba(255,220,190,.35)'; x.font = '600 ' + Math.max(8, Math.round(cs * 0.16)) + 'px ' + MONO; x.textAlign = 'left'; x.textBaseline = 'top';
      for (let i = 0; i < N; i++) x.fillText(cellName(i), ox + (i % W) * cs + 2, oy + ((i / W) | 0) * cs + 1);
      terrLayer = c;
      return c;
    }
    function badge(x, y, txt, kind) {
      ctx.font = '700 ' + Math.max(10, Math.round(geo.cs * 0.2)) + 'px ' + FONT;
      const w = ctx.measureText(txt).width + 8, hh = Math.max(15, geo.cs * 0.27);
      ctx.fillStyle = kind === 1 ? '#e3ae45' : kind === 2 ? 'rgba(120,30,25,.9)' : 'rgba(23,19,31,.85)';
      rr(ctx, x - w / 2, y - hh / 2, w, hh, hh / 2); ctx.fill();
      ctx.fillStyle = kind === 1 ? '#2a1d05' : '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, x, y + 1);
    }
    function cellXY(i) { return [geo.ox + (i % W) * geo.cs, geo.oy + ((i / W) | 0) * geo.cs]; }
    function draw(now) {
      cv.clear();
      if (!st || !geo) return;
      now = now || performance.now();
      ctx.drawImage(terrain(), 0, 0, cv.w, cv.h);
      const seat = viewSeat(), cs = geo.cs;
      const isMe = myTurn() && seat === actor(st) && !anim;
      let g = st.g[seat], rs = st.rs[seat];
      let pv = null;
      if (anim && anim.pg && anim.pg[seat] != null && !(anim.sol && (now - anim.t0) / anim.dur > 0.5)) g = anim.pg[seat];   // 정산 애니: 운석 맞기 전 모습
      if (isMe && sel.i >= 0) { pv = previewBase(seat); g = pv.g; rs = pv.rs; }
      const stat = statusOf(g, rs), con = Array.from(E.con);
      // 방어막 범위
      for (let i = 0; i < N; i++) if (g[i] === 'D' && stat[i] === 1) {
        const [x, y] = cellXY(i);
        ctx.fillStyle = 'rgba(124,200,255,.13)'; rr(ctx, x - cs + 3, y - cs + 3, cs * 3 - 6, cs * 3 - 6, cs * 0.4); ctx.fill();
        ctx.strokeStyle = 'rgba(160,220,255,.5)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]);
      }
      drawLinks(ctx, g, geo.ox, geo.oy, cs);
      const A = anim;
      for (let i = 0; i < N; i++) {
        const c = g[i]; if (c === '.') continue;
        let [x, y] = cellXY(i);
        let sc = 1, al = 1;
        if (A && A.place && A.place.seat === seat && (A.place.at === i || A.place.c === i)) {
          const e = U.clamp((now - A.t0) / (A.place.dur), 0, 1);
          const k = A.place.c === i ? Math.min(1, e * 2) : U.clamp(e * 1.6 - 0.25, 0, 1);
          if (k <= 0) continue;
          sc = 1.5 - 0.5 * (1 - Math.pow(1 - k, 3)); al = Math.min(1, k * 1.5);
          y -= (1 - k) * cs * 0.6;
        }
        const isPv = pv && (i === sel.at || i === sel.c);
        ctx.save(); ctx.globalAlpha = al * (isPv ? 0.85 : 1);
        if (sc !== 1) { ctx.translate(x + cs / 2, y + cs / 2); ctx.scale(sc, sc); ctx.translate(-(x + cs / 2), -(y + cs / 2)); }
        const on = stat[i] === 1 || c === '#';
        // 켜진 돔 불빛
        if (on && 'QHGLP'.indexOf(c) >= 0) {
          const gl = ctx.createRadialGradient(x + cs / 2, y + cs / 2, cs * 0.1, x + cs / 2, y + cs / 2, cs * 0.62);
          gl.addColorStop(0, c === 'G' || c === 'P' ? 'rgba(150,255,140,.28)' : c === 'L' ? 'rgba(190,150,255,.28)' : 'rgba(255,200,110,.3)'); gl.addColorStop(1, 'rgba(255,200,110,0)');
          ctx.fillStyle = gl; ctx.fillRect(x - cs * 0.15, y - cs * 0.15, cs * 1.3, cs * 1.3);
        }
        drawModule(ctx, c, x + cs / 2, y + cs / 2, cs * 0.92, c === '#' ? !!con[i] : on, now);
        ctx.restore();
        if (isPv) { ctx.setLineDash([5, 4]); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; rr(ctx, x + 2, y + 2, cs - 4, cs - 4, cs * 0.14); ctx.stroke(); ctx.setLineDash([]); }
        if (c !== '#' && c !== 'Q' && stat[i] >= 2) {
          ctx.fillStyle = 'rgba(15,8,12,.42)'; rr(ctx, x + 2, y + 2, cs - 4, cs - 4, cs * 0.14); ctx.fill();
          badge(x + cs / 2, y + cs * 0.78, stat[i] === 2 ? '⚡없음' : stat[i] === 3 ? '끊김' : '💧없음', 2);
        }
      }
      // 운석 표적
      if (!st.done && st.mc.length && !(A && A.sol)) {
        for (const c of st.mc) {
          const [x, y] = cellXY(c), pul = 0.5 + 0.5 * Math.sin(now * 0.006);
          ctx.strokeStyle = 'rgba(255,90,60,' + (0.55 + pul * 0.4).toFixed(2) + ')'; ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.arc(x + cs / 2, y + cs / 2, cs * 0.38, 0, 7); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(x + cs * 0.5, y + cs * 0.04); ctx.lineTo(x + cs * 0.5, y + cs * 0.24); ctx.moveTo(x + cs * 0.5, y + cs * 0.76); ctx.lineTo(x + cs * 0.5, y + cs * 0.96);
          ctx.moveTo(x + cs * 0.04, y + cs * 0.5); ctx.lineTo(x + cs * 0.24, y + cs * 0.5); ctx.moveTo(x + cs * 0.76, y + cs * 0.5); ctx.lineTo(x + cs * 0.96, y + cs * 0.5); ctx.stroke();
          const safe = st.t[c] === 'c' || st.t[c] === 'l';
          badge(x + cs * 0.5, y + cs * 0.16, safe ? '☄안전' : '☄', safe ? 0 : 2);
        }
      }
      // 고르기 표시
      if (isMe && opts && sel.i >= 0 && !sel.x) {
        if (sel.cor || sel.at < 0) {
          for (const k in opts.legal) {
            const i = +k, [x, y] = cellXY(i);
            ctx.fillStyle = sel.cor ? 'rgba(200,190,180,.18)' : 'rgba(255,230,160,.16)'; rr(ctx, x + 2, y + 2, cs - 4, cs - 4, cs * 0.14); ctx.fill();
            ctx.strokeStyle = i === hover ? '#fff4c8' : sel.cor ? 'rgba(220,210,200,.75)' : 'rgba(227,174,69,.85)'; ctx.lineWidth = i === hover ? 3 : 2;
            rr(ctx, x + 3, y + 3, cs - 6, cs - 6, cs * 0.12); ctx.stroke();
            if (!sel.cor) badge(x + cs / 2, y + cs * 0.55, opts.legal[k] + (st.t[i] === 'c' ? ' 🔩+2' : ''), 0);
          }
          if (!sel.cor) for (const k in opts.poor) { const [x, y] = cellXY(+k); badge(x + cs / 2, y + cs * 0.55, '🔩부족', 2); }
        }
      }
      // 아래 안내판(화면이 길 때)
      if (geo.ph) drawPanel(seat, isMe);
      // 먼지 폭풍 / 정산 효과
      drawFx(now, seat);
      // 이름표
      if (st.n > 1) {
        const p = api.players[seat], label = pname(seat) + '의 기지';
        ctx.font = '700 12px ' + FONT; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
        const w = ctx.measureText(label).width + 14, y = Math.max(10, geo.y0 + 12);
        ctx.fillStyle = 'rgba(23,19,31,.8)'; rr(ctx, geo.x0 + geo.side - w - 3, y - 10, w, 20, 8); ctx.fill();
        ctx.fillStyle = p ? p.color : '#f2e9d8'; ctx.fillText(label, geo.x0 + geo.side - 10, y + 1);
      }
      backBtn.hidden = !(myTurn() && seat !== actor(st));
    }

    /* 판 아래 안내판: 고른 모듈 설명 또는 지형 안내 */
    const panCache = {};
    function miniTile(ter, sz) {
      const k = ter + sz; if (panCache[k]) return panCache[k];
      const c = document.createElement('canvas'), d = Math.min(2.5, window.devicePixelRatio || 1);
      c.width = Math.round(sz * d); c.height = Math.round(sz * d);
      const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); drawGround(x, ter, 0, 0, sz, 5);
      return (panCache[k] = c);
    }
    function wrapText(txt, x, y, maxW, lh, maxL) {
      let line = '', n = 0;
      for (const ch of txt) {
        if (ctx.measureText(line + ch).width > maxW && line) { ctx.fillText(line, x, y + n * lh); n++; line = ch.trim() ? ch : ''; if (n >= maxL) return; }
        else line += ch;
      }
      if (line && n < maxL) ctx.fillText(line, x, y + n * lh);
    }
    function drawPanel(seat, isMe) {
      const x = geo.x0, y = geo.y0 + geo.side + 8, w = geo.side, hh = geo.ph;
      ctx.fillStyle = 'rgba(29,23,38,.92)'; rr(ctx, x, y, w, hh, 12); ctx.fill();
      ctx.strokeStyle = 'rgba(242,233,216,.13)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      if (isMe && sel.i >= 0) {
        const code = st.mk[sel.i], m = MOD[code], isz = Math.min(hh - 16, 56);
        drawModule(ctx, code, x + 10 + isz / 2, y + hh / 2, isz, true, 0);
        const tx = x + 20 + isz, tw = w - (tx - x) - 10;
        ctx.fillStyle = '#e3ae45'; ctx.font = '700 15px ' + FONT; ctx.fillText(m.nm + '  🔩' + m.c, tx, y + 9);
        ctx.fillStyle = '#f2e9d8'; ctx.font = '500 13px ' + FONT; wrapText(m.d, tx, y + 31, tw, 18, 2);
        let sub = sel.x ? '분해하면 🔩+2' : sel.cor ? '통로 놓을 칸을 톡 (🔩1)' : sel.at >= 0 ? cellName(sel.at) + ' · ' + TER[st.t[sel.at]] + (st.t[sel.at] !== '.' ? ' — ' + TERD[st.t[sel.at]] : '') : '빛나는 칸을 톡 · 카드를 한 번 더 누르면 자세히';
        ctx.fillStyle = '#ab9fb8'; ctx.font = '500 12px ' + FONT; wrapText(sub, tx, y + Math.min(hh - 22, 70), tw, 16, 1);
        return;
      }
      const items = [['i', '얼음', '물 채굴기 💧2배'], ['o', '광맥', '광산 🔩2배'], ['l', '용암동굴', '침대+1 · 운석 안전'], ['c', '크레이터', '🔩+2 · 운석 안전']];
      const cw = (w - 16) / 2, rh = (hh - 12) / 2, tsz = Math.min(rh - 6, 30);
      items.forEach((it, k) => {
        const cx = x + 8 + (k % 2) * cw, cy = y + 6 + ((k / 2) | 0) * rh;
        ctx.drawImage(miniTile(it[0], tsz), cx, cy + (rh - tsz) / 2, tsz, tsz);
        ctx.fillStyle = '#f2e9d8'; ctx.font = '700 12.5px ' + FONT; ctx.textBaseline = 'middle'; ctx.fillText(it[1], cx + tsz + 6, cy + rh / 2 - 8);
        ctx.fillStyle = '#ab9fb8'; ctx.font = '500 11.5px ' + FONT; ctx.fillText(it[2], cx + tsz + 6, cy + rh / 2 + 8);
      });
    }

    /* 먼지·운석·폭발 */
    function stormLevel() {
      if (anim && anim.sol) return anim.sol.e === 'D' ? 2 : anim.sol.e === 'd' ? 1 : 0;
      if (!st || st.done) return 0;
      const e = st.ev[st.r]; return e === 'D' ? 1.2 : e === 'd' ? 0.6 : 0;
    }
    function drawFx(now, seat) {
      const lvl = stormLevel();
      const dt = Math.min(0.05, (now - (lastFrame || now)) / 1000); lastFrame = now;
      const want = Math.round(lvl * 40);
      while (parts.length < want) parts.push({ x: Math.random() * cv.w, y: Math.random() * cv.h, v: 40 + Math.random() * 90, r: 0.6 + Math.random() * 2.2, a: 0.15 + Math.random() * 0.35 });
      if (parts.length > want) parts.length = want;
      if (lvl > 0) {
        ctx.fillStyle = 'rgba(210,120,60,' + (0.06 * lvl).toFixed(3) + ')'; ctx.fillRect(geo.x0, geo.y0, geo.side, geo.side);
        for (const p of parts) {
          p.x += p.v * dt * (1 + lvl) * L.debug.speed; p.y += Math.sin((p.x + now * 0.05) * 0.02) * 0.4;
          if (p.x > cv.w + 4) { p.x = -4; p.y = Math.random() * cv.h; }
          ctx.fillStyle = 'rgba(240,170,110,' + p.a.toFixed(2) + ')'; ctx.fillRect(p.x, p.y, p.r * 2.5, p.r);
        }
      }
      const A = anim;
      if (!A || !A.sol) return;
      const t = (now - A.t0) / A.dur;   // 0..1 전체
      const cs = geo.cs;
      // 운석: 0.05–0.45 떨어짐, 0.45–0.7 폭발
      A.sol.mc.forEach((c, k) => {
        const [x, y] = cellXY(c), tx = x + cs / 2, ty = y + cs / 2;
        const t0 = 0.05 + k * 0.12, t1 = t0 + 0.35;
        if (t < t1 && t > t0) {
          const e = (t - t0) / (t1 - t0), sx = tx - cs * 3 * (1 - e), sy = ty - cs * 5 * (1 - e);
          const gr = ctx.createLinearGradient(sx, sy, sx - cs * 1.2, sy - cs * 2);
          gr.addColorStop(0, 'rgba(255,230,160,.95)'); gr.addColorStop(1, 'rgba(255,120,40,0)');
          ctx.strokeStyle = gr; ctx.lineWidth = cs * 0.14; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx - cs * 1.2, sy - cs * 2); ctx.stroke();
          circ(ctx, sx, sy, cs * 0.1, '#fff2c0');
        } else if (t >= t1 && t < t1 + 0.3) {
          const e = (t - t1) / 0.3;
          const gr = ctx.createRadialGradient(tx, ty, 1, tx, ty, cs * (0.3 + e * 0.9));
          gr.addColorStop(0, 'rgba(255,250,220,' + (1 - e).toFixed(2) + ')'); gr.addColorStop(0.4, 'rgba(255,140,50,' + (0.8 * (1 - e)).toFixed(2) + ')'); gr.addColorStop(1, 'rgba(120,40,20,0)');
          ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(tx, ty, cs * (0.3 + e * 0.9), 0, 7); ctx.fill();
          for (let q = 0; q < 8; q++) { const a = q * 0.785 + k, d = cs * (0.2 + e * 0.8); circ(ctx, tx + Math.cos(a) * d, ty + Math.sin(a) * d - e * cs * 0.3, cs * 0.05 * (1 - e), '#7a3a1e'); }
        }
      });
      // 플레어: 붉은 번쩍임
      if (A.sol.e === 'f' && t < 0.5) { ctx.fillStyle = 'rgba(255,220,120,' + (0.25 * Math.sin(t * Math.PI * 2) ** 2).toFixed(3) + ')'; ctx.fillRect(geo.x0, geo.y0, geo.side, geo.side); }
      // 정산 카드
      if (t > 0.55) {
        const d = A.sol.d[seat]; if (!d) return;
        const e = Math.min(1, (t - 0.55) / 0.12), fade = t > 0.93 ? Math.max(0, 1 - (t - 0.93) / 0.07) : 1;
        ctx.save(); ctx.globalAlpha = e * fade;
        const bw = Math.min(geo.side - 20, 270), bh = 74, bx = geo.x0 + (geo.side - bw) / 2, by = geo.y0 + geo.side / 2 - bh / 2 + (1 - e) * 16;
        ctx.fillStyle = 'rgba(23,19,31,.9)'; rr(ctx, bx, by, bw, bh, 14); ctx.fill();
        ctx.strokeStyle = d[6] ? '#ee6a55' : '#e3ae45'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#e3ae45'; ctx.font = '400 17px "Black Han Sans",' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('솔 ' + (A.sol.r + 1) + ' 정산 · ' + EV[A.sol.e].ic + ' ' + EV[A.sol.e].nm, bx + bw / 2, by + 20);
        const f = (x) => (x > 0 ? '+' + x : x < 0 ? '−' + (-x) : '±0');
        ctx.font = '700 13px ' + FONT; ctx.fillStyle = '#f2e9d8';
        ctx.fillText('O₂ ' + f(d[0]) + '  🌱 ' + f(d[1]) + '  💧 ' + f(d[2]) + '  🔩 ' + f(d[3]), bx + bw / 2, by + 43);
        ctx.fillStyle = d[6] ? '#ff8a76' : d[4] > 0 ? '#8fe08a' : '#ab9fb8';
        ctx.fillText('👤 ' + f(d[4]) + (d[6] ? ' (떠남 ' + d[6] + ')' : '') + (d[5] ? '  ★연구 +' + d[5] : '') + (d[7] ? '  💥부서짐 ' + d[7].length / 2 : ''), bx + bw / 2, by + 61);
        ctx.restore();
      }
    }

    /* ---------- 판 누르기 ---------- */
    function cellAt(p) {
      if (!geo) return -1;
      const x = Math.floor((p.x - geo.ox) / geo.cs), y = Math.floor((p.y - geo.oy) / geo.cs);
      if (x < 0 || y < 0 || x >= W || y >= W) return -1;
      return y * W + x;
    }
    function onTap(ev) {
      if (!st || anim) return;
      const i = cellAt(cv.local(ev));
      if (i < 0) return;
      const seat = viewSeat();
      if (!myTurn() || seat !== actor(st)) { openCell(seat, i); return; }
      if (sel.i < 0) { if (st.g[seat][i] !== '.' || st.t[i] !== '.') openCell(seat, i); else { api.toast('먼저 아래 화물에서 모듈을 고르세요'); api.buzz(20); } return; }
      if (sel.x) { api.toast('분해를 고른 상태예요 — 「분해 ✓」을 다시 누르면 취소'); return; }
      computeOpts();
      if (sel.cor) {
        if (opts && opts.legal[i] != null) {
          sel.c = i; sel.cor = 0; Snd.tube(); api.buzz(8);
          if (sel.at === i) sel.at = -1;
        } else { api.buzz(25); api.toast(st.g[seat][i] !== '.' ? '빈 칸에만 깔 수 있어요' : '기지와 이어진 칸 옆에만 깔 수 있어요'); }
      } else if (i === sel.at) { sel.at = -1; Snd.blip(); }
      else if (i === sel.c) { sel.c = -1; if (sel.at >= 0) { computeOpts(); if (!opts || opts.legal[sel.at] == null) sel.at = -1; } Snd.blip(); }
      else if (opts && opts.legal[i] != null) { sel.at = i; Snd.place(); api.buzz(10); }
      else if (opts && opts.poor[i]) { api.buzz(25); api.toast('자재가 모자라요' + (st.t[i] === 'c' ? ' (크레이터는 🔩+2)' : '')); }
      else if (st.g[seat][i] !== '.') { openCell(seat, i); return; }
      else { api.buzz(25); api.toast('본부와 이어진 칸 옆에만 지을 수 있어요 — 멀면 「🛤 통로」'); }
      computeOpts(); renderAll();
    }
    cv.cv.addEventListener('click', onTap);
    function onMove(ev) {
      if (!st || !myTurn() || sel.i < 0) { if (hover !== -1) { hover = -1; if (!anim) draw(); } return; }
      const i = cellAt(cv.local(ev));
      if (i !== hover) { hover = i; if (!anim) draw(); }
    }
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerleave', () => { if (hover !== -1) { hover = -1; if (!anim) draw(); } });

    /* ---------- 팝업 ---------- */
    let ov = null;
    function closeOv() { if (ov) { ov.remove(); ov = null; } }
    function popup(title, body) {
      closeOv();
      const sheet = h('div', { class: 'sheet' },
        h('div', { class: 'row2', style: { justifyContent: 'space-between' } }, h('h3', { text: title }), h('button', { class: 'btn sm', text: '닫기', onclick: closeOv })), body);
      ov = h('div', { class: 'overlay mb-ov', onclick(e) { if (e.target === ov) closeOv(); } }, sheet);
      root.append(ov);
      Snd.blip();
    }
    const col = (...k) => h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } }, ...k);
    function openModule(code) {
      const m = MOD[code];
      popup(m.nm, col(
        h('div', { class: 'row2' }, cardCanvas(code, 56), h('p', null, h('b', { text: '자재 🔩' + m.c }), h('br'), m.d)),
        h('p', { class: 'muted', text: '전기가 모자라면 물 채굴기 → 산소 생성기 → 온실 → 재활용기 → 광산 → 공장 → 연구소 → 방어막 순서로 켜져요. 크레이터에 지으면 🔩+2.' })));
    }
    function openCell(seat, i) {
      const c = st.g[seat][i], tr = st.t[i];
      const st2 = statusOf(st.g[seat], st.rs[seat]);
      const lines = [h('p', null, h('b', { text: cellName(i) + ' · ' + TER[tr] }), ' — ' + TERD[tr])];
      if (c !== '.') lines.push(h('div', { class: 'row2' }, cardCanvas(c, 48), h('p', null, h('b', { text: MOD[c].nm }), h('br'), MOD[c].d, h('br'),
        h('span', { style: { color: st2[i] === 1 || c === '#' || c === 'Q' ? '#8fe08a' : '#ff8a76' }, text: c === '#' ? '' : st2[i] === 1 ? '● 일하는 중' : st2[i] === 2 ? '● 전기가 없어 꺼짐' : st2[i] === 3 ? '● 본부와 끊김 — 통로로 이어 주세요' : '● 물이 없어 멈춤' }))));
      if (st.mc.indexOf(i) >= 0) lines.push(h('p', { style: { color: '#ff8a76', fontWeight: 700 }, text: '☄ 오늘 밤 이 칸에 운석이 떨어져요!' + (tr === 'c' || tr === 'l' ? ' (지형 덕분에 안전)' : '') }));
      popup(c !== '.' ? MOD[c].nm : TER[tr], col(...lines));
    }
    function openEvent() {
      if (st.done) { openScore(); return; }
      const ec = st.ev[st.r], ev = EV[ec];
      const nx = st.r + 1 < st.R ? st.ev[st.r + 1] : null;
      const tb = h('table');
      tb.append(h('tr', null, h('td', { text: '오늘 밤' }), h('td', null, h('b', { text: ev.ic + ' ' + ev.nm }), h('br'), ev.d + (st.mc.length ? ' 표시된 칸: ' + st.mc.map(cellName).join(', ') : ''))));
      if (nx) tb.append(h('tr', null, h('td', { text: '다음 솔' }), h('td', null, h('b', { text: EV[nx].ic + ' ' + EV[nx].nm }), h('br'), EV[nx].d + (st.mn.length ? ' 예상 칸: ' + st.mn.map(cellName).join(', ') : ''))));
      const ord = order(st, st.r).map((p, k) => (k === st.k ? '▶' : '') + pname(p)).join(' → ');
      popup('솔 ' + (st.r + 1) + ' / ' + st.R, col(tb,
        st.n > 1 ? h('p', null, h('b', { text: '고르는 순서 (뱀 순서)' }), h('br'), ord) : h('p', { text: '혼자 할 때는 화물 4장 중 2장을 골라요.' }),
        h('p', { class: 'muted', text: '모두 2장씩 고르면 밤이 와요: 사건 → 전기 배분 → 물 → 산소·식량 생산 → 주민이 O₂·🌱 1씩 소비 → 모자라면 주민이 떠나고, 남으면 빈 침대에 이주민(솔마다 최대 2명).' })));
    }
    function openRes() {
      const v = viewSeat(), pv = myTurn() && v === actor(st) ? previewBase(v) : { g: st.g[v], rs: st.rs[v], on: false };
      const g = pv.on ? pv.g : st.g[v], rs = pv.on ? pv.rs : st.rs[v];
      const ec = st.done ? 'c' : st.ev[st.r];
      const e = Object.assign({}, econ(st.t, g, st.hq, ec, rs));
      const stt = Array.from(E.st);
      const off = { 2: 0, 3: 0, 4: 0 }; stt.forEach((x) => { if (off[x] != null) off[x]++; });
      const f = st.done ? null : forecast(g, rs);
      const tb = h('table');
      const row = (a, b, c) => tb.append(h('tr', null, h('td', { text: a }), h('td', { style: { color: 'var(--muted)' }, text: b }), h('td', { class: 'n', text: c })));
      row('⚡ 전기', '만듦 ' + e.pw + ' · 씀 ' + e.pu + (off[2] ? ' · 꺼짐 ' + off[2] : ''), (e.pw - e.pu >= 0 ? '여유 ' : '') + (e.pw - e.pu));
      row('💧 물', '저장 ' + rs[2] + ' +채굴 ' + e.wp + ' −사용 ' + e.wu, f ? '→ ' + f.rs[2] : '');
      row('O₂ 산소', '저장 ' + rs[0] + ' +생산 ' + e.o + ' −주민 ' + rs[4], f ? '→ ' + f.rs[0] : '');
      row('🌱 식량', '저장 ' + rs[1] + ' +생산 ' + e.f + ' −주민 ' + rs[4], f ? '→ ' + f.rs[1] : '');
      row('🔩 자재', '저장 ' + rs[3] + ' +수입 ' + e.m, f ? '→ ' + f.rs[3] : '');
      row('👤 주민', rs[4] + '명 · 침대 ' + e.beds, f ? '→ ' + f.rs[4] : '');
      row('📦 저장 한도', 'O₂·🌱·💧 각각', String(e.cap));
      const sc = scoreOf({ t: st.t, hq: st.hq, g: [g], rs: [rs] }, 0);
      popup(pname(v) + ' 기지 정산표', col(
        h('p', { class: 'muted', text: st.done ? '최종 상태예요.' : '「→」는 오늘 밤 정산 뒤 예상 값' + (pv.on ? ' (지금 고른 것 포함)' : '') + '. 사건: ' + EV[ec].ic + ' ' + EV[ec].nm }),
        tb,
        (off[3] || off[4]) ? h('p', { style: { color: '#ff8a76' }, text: (off[3] ? '끊긴 모듈 ' + off[3] + '개 (통로로 이어 주세요) ' : '') + (off[4] ? '물이 없어 멈춘 모듈 ' + off[4] + '개' : '') }) : null,
        h('p', null, h('b', { text: '지금 점수 ' + sc.tot }), ' = 주민 ' + sc.pop + ' + 연구 ' + sc.rp + ' + 공원 ' + sc.park + ' + 통신탑 ' + sc.div + ' + 자원 ' + sc.res)));
    }
    function openScore() {
      const tb = h('table');
      for (let i = 0; i < st.n; i++) {
        const sc = scoreOf(st, i);
        tb.append(h('tr', null, h('td', null, h('span', { class: 'dot', style: { '--c': api.players[i] ? api.players[i].color : '#888', marginRight: '6px' } }), pname(i)),
          h('td', { style: { color: 'var(--muted)' }, text: '주민 ' + st.rs[i][4] + ' · 연구 ' + sc.rp + (sc.park ? ' · 공원 ' + sc.park : '') + (sc.div ? ' · 탑 ' + sc.div : '') }), h('td', { class: 'n', text: sc.tot + '점' })));
      }
      popup('점수', col(tb, st.n === 1 ? h('p', { class: 'muted', text: '별 기준: ' + (STARS[st.R] || STARS[8]).join(' / ') + '점' }) : null,
        h('p', { class: 'muted', text: '주민 1명 3점 · 연구 ★ 1점 · 돔 공원(붙은 거주 모듈마다 2점) · 통신탑(모듈 종류마다 1점) · 남은 자원 5개당 1점' })));
    }
    evBtn.onclick = openEvent;
    resBtn.onclick = openRes;

    /* ---------- 애니메이션 ---------- */
    function loopOn() {
      if (stopLoop) return;
      stopLoop = U.loop((dt, now) => {
        if (anim && now - anim.t0 >= anim.dur) { endAnim(); return; }
        if (!anim && stormLevel() <= 0) { stopLoop(); stopLoop = null; draw(now); return; }
        if (!anim && now - lastDraw < 33) return;
        lastDraw = now; draw(now);
      });
    }
    let lastDraw = 0, queue = [];
    function startAnim(a) {
      anim = a; anim.t0 = performance.now();
      api.setBusy(true);
      clearTimeout(watchdog); watchdog = setTimeout(endAnim, anim.dur + 2000);
      if (a.sol) {
        if (a.sol.mc.length) a.sol.mc.forEach((c, k) => Snd.meteor(0.05 + k * 0.18));
        if (a.sol.e === 'd' || a.sol.e === 'D') Snd.storm();
      }
      loopOn();
      renderAll();
    }
    function endAnim() {
      clearTimeout(watchdog);
      const was = anim; anim = null;
      if (was && was.after) was.after();
      if (queue.length) { startAnim(queue.shift()); return; }
      if (was) api.setBusy(false);
      renderAll();
      if (stormLevel() > 0) loopOn();
    }
    function solFeedback(l) {
      const mine = api.mySeats();
      const who = mine.length ? mine : [viewSeat()];
      const d = l.sol.d;
      let lost = 0, grew = 0, broke = 0;
      who.forEach((p) => { if (d[p]) { lost += d[p][6]; if (d[p][4] > 0) grew += d[p][4]; broke += d[p][7].length / 2; } });
      if (lost) { Snd.alarm(); api.buzz([30, 60, 30]); api.toast('⚠ 산소·식량이 모자라 주민 ' + lost + '명이 떠났어요'); }
      else if (grew) { Snd.grow(); api.toast('👤 이주민 ' + grew + '명이 왔어요!'); }
      else Snd.good();
      if (broke) api.toast('💥 운석에 모듈 ' + broke + '개가 부서졌어요');
    }

    function renderAll() {
      if (!st) return;
      computeOpts();
      renderChips(); renderEvent(); renderRes(); renderMarket(); renderAct(); renderHint();
      if (!anim) draw(performance.now());
      if (stormLevel() > 0) loopOn();
    }

    return {
      update(next, prev) {
        const key = next.gid + ':' + next.R;
        const fresh = key !== gameKey;
        if (fresh) { gameKey = key; clearSel(); manual = null; shownId = -1; mkKey = ''; plRow.innerHTML = ''; followSeat = 0; terrKey = ''; }
        const old = st;
        st = next;
        pending = false; clearTimeout(pendT);
        if (!geo || fresh) layout();
        const l = st.last;
        const isNew = l && l.id !== shownId;
        const a = actor(st);
        if (a != null && api.canAct(a) && (!old || actor(old) !== a)) manual = null;
        if (isNew) {
          clearSel();
          shownId = l.id;
          if (!(a != null && api.canAct(a))) followSeat = l.seat;
          if (prev && old && !fresh) {
            const sp = L.debug.speed || 1;
            // 놓기 애니
            const vs = viewSeat();
            if (l.k === 'b') Snd.place(); else Snd.scrap();
            if (l.c >= 0) setTimeout(() => Snd.tube(), 120);
            const el = plRow.children[l.seat]; if (el && l.seat !== vs) { el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
            if (l.sol) {
              // 정산 전 모습: 이번 행동까지 반영한 이전 기지
              const pg = old.g.map((g, p) => {
                if (p !== l.seat) return g;
                let x = g; if (l.c >= 0) x = setCh(x, l.c, '#'); if (l.k === 'b' && l.at >= 0) x = setCh(x, l.at, l.m); return x;
              });
              if (l.k === 'b' || l.c >= 0) queue.push({ place: { seat: l.seat, at: l.at, c: l.c, dur: 520 / sp }, pg, dur: 520 / sp });
              queue.push({ sol: l.sol, pg, dur: (l.sol.mc.length ? 2600 : 2000) / sp, after: () => solFeedback(l) });
              if (!anim) startAnim(queue.shift());
            } else if (l.seat === vs && (l.k === 'b' || l.c >= 0)) {
              queue.push({ place: { seat: l.seat, at: l.at, c: l.c, dur: 520 / sp }, dur: 520 / sp });
              if (!anim) startAnim(queue.shift());
            }
            if (st.r !== old.r && !st.done) { const nx = EV[st.ev[st.r]]; setTimeout(() => { if (st && !st.done) api.toast('솔 ' + (st.r + 1) + ' · 새 화물이 왔어요! 오늘 밤: ' + nx.ic + ' ' + nx.nm); }, l.sol ? ((l.sol.mc.length ? 2600 : 2000) + 500) / sp : 0); }
          }
        }
        renderAll();
      },
      destroy() {
        if (stopLoop) stopLoop();
        clearTimeout(watchdog); clearTimeout(pendT);
        queue = [];
        if (anim) { anim = null; api.setBusy(false); }
        closeOv();
        cv.destroy(); wrap.remove(); styleEl.remove();
      },
    };
  }

  const DEF = {
    id: 'marsbase', name: '화성 기지 건설', tag: '기지 엔진 빌딩', cat: '보드',
    blurb: '보급선 화물에서 모듈을 뱀 순서로 골라 내 화성 기지에 이어 지어요. 전기·물·산소·식량 균형을 지키며 주민을 늘리세요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false,
    tint: '#7a2e1c',
    icon: '<path d="M4 46C14 40 22 42 30 44S46 46 52 42V52H4Z" fill="currentColor" opacity=".45"/><path d="M14 40A10 10 0 0 1 34 40Z" fill="currentColor"/><rect x="34" y="34" width="14" height="6" rx="1.5" fill="currentColor" opacity=".8"/><path d="M34 37H30" stroke="currentColor" stroke-width="3"/><path d="M36 30L46 22" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><rect x="38" y="16" width="14" height="8" rx="1.5" transform="rotate(-20 45 20)" fill="currentColor" opacity=".7"/><circle cx="14" cy="12" r="5" fill="currentColor" opacity=".55"/><circle cx="24" cy="36" r="2" fill="currentColor" opacity=".35"/><path d="M8 22L13 26M10 18l2-1" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".6"/>',
    options: [
      { id: 'sols', label: '기간', def: '8', choices: [{ v: '6', label: '6솔 (짧게)' }, { v: '8', label: '8솔' }, { v: '10', label: '10솔 (길게)' }] },
    ],
    quick: [
      '화성에 내 기지(6×6)를 지어 주민을 가장 많이 늘리고 점수를 가장 많이 모으면 이겨요.',
      '솔(하루)마다 보급선 화물에서 모듈 카드를 뱀 순서로 2장 골라, 기지와 이어진 칸에 짓거나 분해해 자재로 바꿔요.',
      '밤마다 정산: 전기·물로 산소·식량을 만들고 주민이 1씩 먹어요. 모자라면 주민이 떠나고, 남으면 이주민이 와요.',
    ],
    rules: [
      { h: '목표', p: ['각자 자기 화성 기지(6×6칸)를 지어요. 땅 모양(크레이터·얼음·광맥·용암동굴)은 모두 똑같아요.', '정해진 솔(기본 8솔)이 지나면 점수가 가장 높은 사람이 이겨요. 혼자 하면 점수로 별 1~3개!'] },
      { h: '솔 하나의 흐름', p: [
        '① 보급선 화물이 와요: 모듈 카드가 (사람 수 × 2 + 1)장 깔려요. 혼자면 4장.',
        '② 뱀 순서로 한 장씩 골라요: 1→2→3→3→2→1. 모두 2장씩. 시작하는 사람은 솔마다 바뀌어요. 남은 카드는 버려요.',
        '③ 고른 카드는 「짓기」(자재를 내고 기지에 놓기) 또는 「분해」(🔩자재 +2) 중 하나.',
        '④ 모두 고르면 밤: 사건이 일어나고 정산해요.'] },
      { h: '짓기 규칙', p: [
        '모듈은 빈 칸 중, 본부와 이어진 칸(상하좌우)의 옆에만 지어요. 카드 오른쪽 위 숫자가 자재(🔩) 값이에요.',
        '🛤 통로: 짓기·분해할 때 통로 1칸(🔩1)을 먼저 깔 수 있어요. 멀리 있는 얼음·광맥까지 길을 내거나, 운석에 끊긴 모듈을 다시 이어요.',
        '본부와 끊긴 모듈은 일하지 않아요(점수도 없음).',
        '지형: 얼음 = 물 채굴기 2배, 광맥 = 광산 2배, 용암동굴 = 거주 모듈 침대 +1이고 운석·플레어에 안전, 크레이터 = 짓는 데 🔩+2 더 들지만 운석에 안전.'] },
      { h: '밤 정산 (순서대로)', p: [
        '1. 사건(운석은 표시된 칸에 떨어져 그 칸 모듈이 부서져요 — 잔해에서 🔩+1).',
        '2. 전기 배분: 전기가 모자라면 물 채굴기 → 산소 생성기 → 온실 → 재활용기 → 광산 → 공장 → 연구소 → 방어막 순서로 켜고, 나머지는 꺼져요.',
        '3. 물: 채굴한 물 + 저장된 물로 산소 생성기·온실이 1씩 써요. 물이 없으면 멈춰요.',
        '4. 생산: 산소·식량·자재·연구가 쌓여요. 저장 한도는 O₂·🌱·💧 각 10 (저장 탱크마다 +6).',
        '5. 소비: 주민 1명이 O₂ 1, 🌱 1을 써요. 모자란 만큼 주민이 떠나요(최소 1명은 남음).',
        '6. 이주: 모자람이 없으면, 남은 O₂·남은 🌱·빈 침대 중 가장 작은 수만큼 이주민이 와요(솔마다 최대 2명).'] },
      { h: '자원 줄 읽기', p: ['위쪽 줄은 지금 저장량과 「오늘 밤 정산 뒤 바뀔 양」이에요. 카드를 골라 칸에 놓아 보면 「+1→+5」처럼 바뀌는 값이 금색으로 보여요.', '⚡는 「쓰는 전기/만드는 전기」, 👤는 「주민/침대」. 빨간 칸은 위험 신호! 누르면 자세한 정산표가 나와요.'] },
      { h: '모듈 16가지', p: [
        '태양광(🔩1) ⚡+2, 태양광끼리 붙으면 +1 · 소형 원자로(🔩4) ⚡+4, 폭풍 무관, 붙은 거주 모듈 침대 −1 · 축전지(🔩2) ⚡+1, 모래폭풍 때 ⚡+3',
        '물 채굴기(🔩2) ⚡1 → 💧+3 · 산소 생성기(🔩2) ⚡1·💧1 → O₂+4, 온실 옆 +1 · 온실(🔩2) ⚡1·💧1 → 🌱+4, 온실끼리 붙으면 +1',
        '거주 모듈(🔩2) 침대 4, 주민 1명과 함께 와요 · 재활용기(🔩3) ⚡1 → O₂·🌱·💧 +1씩',
        '광산(🔩2) ⚡1 → 🔩+2 · 3D 공장(🔩3) ⚡1 → 🔩+1, 붙은 광산마다 +1 · 착륙장(🔩2) 솔마다 🔩+1, 보급선 사건 때 +2 더',
        '연구소(🔩4) ⚡1 → 솔마다 ★+1 · 방어막(🔩3) ⚡1, 둘레 3×3 칸을 운석·플레어에서 지킴 · 저장 탱크(🔩1) 저장 한도 +6, 산소 누출 줄임',
        '돔 공원(🔩3) 끝에 붙은 거주 모듈마다 ★+2 · 통신탑(🔩2) 끝에 기지의 모듈 종류마다 ★+1 (통신탑이 여러 개여도 한 번만)',
        '착륙선 본부(처음부터): ⚡+2, O₂+3, 🌱+3, 🔩+2, 침대 3.'] },
      { h: '사건 16가지', p: [
        '그날 밤 사건과 다음 솔 사건은 미리 보여요(운석 칸도 표시). 대비하세요!',
        '맑은 날 · 모래폭풍(태양광 절반) · 거대 모래폭풍(태양광 0) · 운석(1칸) · 유성우(2칸) · 태양 플레어(보호 안 된 거주 모듈마다 주민 −1) · 보급선 도착(🔩+3) · 이주 신청(이주민 최대 4명) · 얼음 혜성(물 2배) · 풍년(온실 🌱+2) · 화성 지진(🔩−2) · 먼지 회오리(태양광 +1) · 추운 밤(주민 3명마다 ⚡1) · 연구 의뢰(연구소 ★+2) · 산소 누출(O₂−3) · 원자로 점검(원자로 꺼짐)'] },
      { h: '점수', p: ['주민 1명 = 3점, 연구 ★ = 1점, 돔 공원·통신탑 점수, 남은 자원(O₂+🌱+💧+🔩) 5개당 1점.', '같으면 주민이 많은 사람이 이겨요. 혼자 하면 6솔 28/38/48 · 8솔 38/50/62 · 10솔 48/64/78점에서 별 1/2/3개.'] },
      { h: '조작', p: ['아래 화물 카드 톡 → 빛나는 칸 톡(숫자 = 그 칸에서 내는 양) → 「짓기」.', '「🛤 통로」를 누르고 칸을 톡하면 통로(🔩1)를 먼저 깔아요. 「♻ 분해」는 카드를 자재 2로 바꿔요. 「↶」는 한 단계 되돌리기.', '고른 카드를 한 번 더 누르면 설명, 칸을 누르면 지형·모듈 정보, 위 사건 줄·자원 줄을 누르면 자세히 볼 수 있어요. 이름 칸을 누르면 다른 사람 기지를 봐요.'] },
      { h: '예시', p: [
        '본부만 있을 때 주민은 2명, 본부가 O₂ 3·🌱 3을 만들어요. 첫 밤에 1명이 더 와서 3명이 돼요.',
        '산소 생성기·온실·물 채굴기를 지으면 전기 3이 필요한데 본부는 ⚡2뿐 → 태양광 하나를 더 지어요. 이제 O₂·🌱가 4씩 남으니 거주 모듈을 지어 침대를 늘리면 솔마다 2명씩 이주민이 와요!'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.', '쉬움: 가끔 엉뚱하게 지어요. 보통: 지금 기지에 필요한 것을 지어요. 어려움: 다음 솔 사건과 운석 칸까지 대비하고, 다음 사람이 노리는 카드를 먼저 가져가기도 해요.'] },
    ],
    tutorial: [
      { sel: '.mb-mk', text: '보급선 화물이에요. 내 차례에 카드 하나를 골라요. 모두 뱀 순서로 2장씩 고르고, 남은 카드는 버려져요.' },
      { sel: '.mb-board', text: '내 기지예요. 카드를 고르면 지을 수 있는 칸이 빛나고, 칸마다 그 자리에서 내는 양(예: O₂5)이 보여요. 본부와 이어진 칸 옆에만 지을 수 있어요.' },
      { sel: '.mb-res', text: '자원 줄: ⚡전기(씀/만듦), O₂, 🌱, 💧, 🔩자재, 👤주민/침대. 아래 숫자는 오늘 밤 정산 뒤 바뀌는 양. 칸에 놓아 보면 금색으로 미리 보여요.' },
      { sel: '.mb-ev', text: '오늘 밤 사건과 다음 사건이에요. 운석은 판에 빨간 표적으로 표시돼요. 오른쪽 점은 고르는 순서!' },
      { sel: '.mb-act', text: '「🛤 통로」는 멀리 길을 내요(🔩1). 「♻ 분해」는 카드를 🔩2로 바꿔요. 「짓기」로 확정!' },
      { sel: '.mb-pl', text: '이름 칸에는 기지 미리보기·주민·점수가 있어요. 누르면 그 사람 기지를 볼 수 있어요.' },
    ],
    aiDelay: 700,
    init, actor, apply, ai, aiDelayFor, result, mount,
  };
  DEF._t = { planValue, econ, settle, scoreOf, frontier, connected, allMoves, AIW, MOD, EV, order, build, evalBase, STARS, CW, genEvents };
  L.register(DEF);
})();
