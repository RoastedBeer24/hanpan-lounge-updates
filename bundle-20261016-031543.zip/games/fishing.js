/* 낚시 대결 — 한 사람씩 번갈아 캐스팅한다. 호수 화면에서 위로 밀어 던질 곳(거리·방향)을 정하고,
   찌가 쑥 들어가는 순간 탭해 챔질, 눌러서 감고 떼서 풀며 줄 장력을 지켜 물고기를 끌어낸다.
   물고기(어종·무게)와 입질 시각·물고기의 힘 쓰기는 상태 안의 시드 + 던진 곳(구역) + 시간대로 정해진다.
   낚는 기기는 {x, y, h(챔질 ms), f(감기 누름/뗌 틱 목록)}만 보내고, apply는 같은 계산으로 승부를 다시 돌려 무게를 매긴다.
   다른 기기는 같은 기록으로 다시보기를 재생한다. 장력 계산은 + − × ÷ 만 써서 기기마다 결과가 같다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const sm = (x) => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };

  /* ---------- seeded rng ---------- */
  function mb(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const lcg = (F) => { F.rs = (F.rs * 48271) % 2147483647; return F.rs / 2147483647; };

  /* ---------- lake (m): angler at (0,0), x right, y away from the angler ---------- */
  const MAXD = 42, MINY = 3;
  const hw = (y) => { const u = (y - 28) / 28; return 16 + 12 * (1 - u * u); };
  const far = (x) => 50 - 10 * (x / 30) * (x / 30);
  function inWater(x, y) { return y >= 2 && y <= far(x) && Math.abs(x) <= hw(y); }
  /* where a cast record really lands (clamped into the water, within reach) */
  function landAt(x, y) {
    if (!isFinite(x) || !isFinite(y)) { x = 0; y = 10; }
    if (y < MINY) { if (y <= 0.1) { x = 0; y = MINY; } else { x = x * MINY / y; y = MINY; } }
    if (Math.abs(x) > y * 1.8) x = Math.sign(x) * y * 1.8;
    const d = Math.sqrt(x * x + y * y);
    if (d > MAXD) { x = x * MAXD / d; y = y * MAXD / d; }
    if (!inWater(x, y)) {
      const ax = x * MINY / y, ay = MINY;
      let lo = 0, hi = 1;
      for (let i = 0; i < 24; i++) { const m = (lo + hi) / 2; if (inWater(ax + (x - ax) * m, ay + (y - ay) * m)) lo = m; else hi = m; }
      x = ax + (x - ax) * lo; y = ay + (y - ay) * lo;
    }
    return { x: Math.round(x * 10) / 10 + 0, y: Math.round(y * 10) / 10 + 0 };
  }
  const SPOTS = { R: [-12, 44, 7], W1: [-14, 22, 7.5], W2: [13, 32, 6.5] };
  const near = (x, y, s) => (x - s[0]) * (x - s[0]) + (y - s[1]) * (y - s[1]) < s[2] * s[2];
  function zoneOf(x, y) {
    if (near(x, y, SPOTS.R)) return 'R';
    if (near(x, y, SPOTS.W1) || near(x, y, SPOTS.W2)) return 'W';
    if (y < 12 || Math.abs(x) > hw(y) - 4 || y > far(x) - 3) return 'S';
    return 'D';
  }
  const ZN = { S: '얕은 물가', W: '수초 · 연잎', D: '깊은 곳', R: '바위 여울' };
  const ZI = { S: 1, W: 2, D: 3, R: 4 };

  /* ---------- species: zone weights, time-of-day multipliers [새벽, 낮, 저녁, 밤], kg range, pull strength, bite window ---------- */
  const TOD = ['새벽', '낮', '저녁', '밤'];
  const SP = [
    { n: '피라미', z: { S: 30, W: 8 }, t: [1, 1.2, 1, 0.5], lo: 0.02, hi: 0.08, str: 0.1, win: 0.55, r: 0 },
    { n: '붕어', z: { S: 30, W: 25, D: 10 }, t: [1.2, 1, 1.2, 0.8], lo: 0.15, hi: 1.2, str: 0.3, win: 0.65, r: 0 },
    { n: '블루길', z: { S: 15, W: 20 }, t: [0.8, 1.4, 1, 0.5], lo: 0.08, hi: 0.4, str: 0.25, win: 0.55, r: 0 },
    { n: '배스', z: { W: 25, S: 8, R: 10, D: 6 }, t: [1.8, 0.8, 1.8, 0.6], lo: 0.4, hi: 3.2, str: 0.6, win: 0.45, r: 1 },
    { n: '가물치', z: { W: 12 }, t: [0.8, 1.5, 1, 0.7], lo: 1, hi: 7, str: 0.85, win: 0.45, r: 1 },
    { n: '잉어', z: { D: 30, W: 6 }, t: [1.2, 0.9, 1.2, 1], lo: 1.5, hi: 9, str: 0.7, win: 0.7, r: 1 },
    { n: '메기', z: { D: 14, S: 4 }, t: [1.2, 0.4, 1, 3], lo: 1, hi: 12, str: 0.8, win: 0.75, r: 1 },
    { n: '송어', z: { R: 35, D: 5 }, t: [1.4, 1, 1.1, 0.5], lo: 0.4, hi: 3, str: 0.55, win: 0.42, r: 1 },
    { n: '쏘가리', z: { R: 12 }, t: [1, 0.8, 1.3, 1.2], lo: 0.3, hi: 2.2, str: 0.65, win: 0.4, r: 2 },
    { n: '황금 잉어', z: { D: 1.2, W: 0.4 }, t: [1.5, 0.7, 1, 1.5], lo: 3, hi: 11, str: 0.95, win: 0.4, r: 3 },
    { n: '낡은 장화', z: { S: 3, D: 3, W: 2, R: 1 }, t: [1, 1, 1, 1], lo: 0, hi: 0, str: 0.05, win: 0.9, r: -1 },
  ];
  const BOOT = 10, GOLD = 9;
  const RAR = { '-1': '꽝', 0: '흔함', 1: '보통', 2: '희귀', 3: '전설' };
  function fishOf(sd, zone, td) {
    const R = mb(((sd ^ Math.imul(ZI[zone] * 977 + td * 131 + 7, 2654435761)) >>> 0) || 1);
    let tot = 0;
    const w = SP.map((f) => { const v = (f.z[zone] || 0) * f.t[td]; tot += v; return v; });
    let u = R() * tot, sp = 0;
    for (; sp < SP.length - 1; sp++) { u -= w[sp]; if (u < 0 && w[sp] > 0) break; }
    if (w[sp] <= 0) sp = 0;
    const f = SP[sp], q = R();
    const g = sp === BOOT ? 0 : Math.round((f.lo + (f.hi - f.lo) * Math.pow(q, 2.2)) * 1000);
    const size = sp === BOOT ? 0.5 : q; // 0..1 within the species, scales the fight a little
    return { sp, g, str: clamp(f.str + 0.12 * (size - 0.5), 0.05, 1), win: f.win, S0: 4 + 9 * f.str + 3 * size };
  }
  /* bite schedule: fake nibbles first, then the real dive at tb (seconds after the bobber lands) */
  function biteOf(sd) {
    const R = mb((Math.imul(sd, 7) + 3) >>> 0 || 1);
    const tb = 1.8 + 3.4 * R(), k = Math.floor(R() * 3), nib = [];
    for (let i = 0; i < k; i++) { const t = 0.7 + R() * Math.max(0, tb - 1.3); if (t < tb - 0.55) nib.push(Math.round(t * 100) / 100); }
    nib.sort((a, b) => a - b);
    return { tb: Math.round(tb * 100) / 100, nib };
  }
  const NIBD = 0.2; // a nibble twitch lasts this long (s)
  /* hook verdict: h = ms after landing (−1 = never tapped) */
  function hookOf(b, win, h) {
    if (h < 0) return { ok: 0, why: 'l' };
    const t = h / 1000;
    if (t < b.tb) return { ok: 0, why: 'e' };
    if (t > b.tb + win) return { ok: 0, why: 'l' };
    return { ok: 1, q: 1 - (t - b.tb) / win };
  }

  /* ---------- the fight (30 Hz), shared by live play, apply, AI and replay ---------- */
  const FDT = 1 / 30, FMAX = 1200, MAXTG = 150, TGREEN = [0.35, 0.85], TRED = 0.9;
  function newFight(fish, sd, D0, q) {
    const F = { k: 0, D: D0, D0, T: 0.25, p: 0.2, st: fish.S0, S0: fish.S0, str: fish.str, slack: 0, slackMax: 1.3 + 0.9 * q,
      rs: ((sd ^ 0x5bd1e995) >>> 0) % 2147483646 + 1, nb: 0, bs: -1, be: -1, ba: 0, dir: 1, out: null };
    F.nb = Math.round((0.8 + 1.4 * lcg(F)) / FDT);
    return F;
  }
  function pullOf(F) {
    let env = 0;
    if (F.k >= F.bs && F.k < F.be) { const u = (F.k - F.bs) / (F.be - F.bs); env = u < 0.2 ? sm(u / 0.2) : u > 0.75 ? sm((1 - u) / 0.25) : 1; }
    const fat = 0.5 + 0.5 * F.st / F.S0;
    return (0.22 + 0.3 * F.str + F.ba * env) * fat;
  }
  function fstep(F, hold) {
    if (F.out) return;
    if (F.k >= F.nb && F.k >= F.be) { // a new burst begins
      F.bs = F.k; F.be = F.k + Math.round((0.5 + 1.0 * lcg(F)) / FDT);
      F.ba = (0.4 + 0.45 * lcg(F)) * (0.6 + 0.6 * F.str);
      F.dir = lcg(F) < 0.5 ? -1 : 1;
      F.nb = F.be + Math.round((1.0 + 2.4 * lcg(F) * (1.25 - F.str)) / FDT);
    }
    const p = pullOf(F);
    F.p = p;
    const target = hold ? 0.3 + 0.85 * p : 0.5 * p;
    F.T += (target - F.T) * FDT / 0.16;
    if (hold) F.D -= (3.4 - 2.4 * p) * FDT; else F.D += p * p * 2.2 * FDT;
    const green = F.T >= TGREEN[0] && F.T <= TGREEN[1];
    F.st = Math.max(0, F.st - FDT * (green ? 1 : 0.35));
    if (F.T < 0.12) F.slack += FDT; else F.slack = Math.max(0, F.slack - 2 * FDT);
    F.k++;
    if (F.T >= 1) F.out = 'S';
    else if (F.D >= 60) F.out = 'S';
    else if (F.slack >= F.slackMax) F.out = 'E';
    else if (F.D <= 1.2) F.out = 'L';
    else if (F.k >= FMAX) F.out = 'E';
  }
  /* toggles f: ascending ticks; the hold state flips right before that tick is simulated */
  function fight(F, f, cb) {
    let i = 0, hold = false;
    while (!F.out) {
      while (i < f.length && f[i] <= F.k) { hold = !hold; i++; }
      fstep(F, hold);
      if (cb) cb(F, hold);
    }
    return F;
  }
  /* full outcome of one cast record */
  function judge(sd, td, a) {
    const p = landAt(a.x / 10, a.y / 10), z = zoneOf(p.x, p.y), fish = fishOf(sd, z, td), b = biteOf(sd);
    const D0 = Math.max(5, Math.sqrt(p.x * p.x + p.y * p.y));
    const hk = hookOf(b, fish.win, a.h);
    const res = { x: p.x, y: p.y, z, fish, b, D0, hk, out: null, k: 0 };
    if (!hk.ok) { res.out = hk.why; return res; }
    const F = fight(newFight(fish, sd, D0, hk.q), a.f);
    res.out = F.out; res.k = F.k;
    return res;
  }
  const OUTN = { L: '낚았다!', S: '줄이 끊어졌어요', E: '놓쳤어요', e: '너무 빨랐어요', l: '너무 늦었어요' };
  const MISSC = { e: 0, l: 1, S: 2, E: 3 };

  /* f <-> compact string (base36 deltas) for the state's replay record */
  const encF = (f) => { let p = 0; return f.map((v) => { const d = v - p; p = v; return d.toString(36); }).join('.'); };
  const decF = (s) => { if (!s) return []; let p = 0; return s.split('.').map((d) => (p += parseInt(d, 36))); };

  /* ---------- rules / state ---------- */
  function rnd(s) { s.rs = (s.rs * 48271) % 2147483647; return s.rs / 2147483647; }
  function nextCast(s) { s.sd = 1 + Math.floor(rnd(s) * 2147483000); }
  function init(players, opts) {
    const n = players.length;
    const N = opts && +opts.casts === 8 ? 8 : 5;
    const s = { n, N, md: opts && opts.win === 'big' ? 'b' : 'w', r: 0, i: 0, ord: players.map((p, i) => i),
      rs: 1 + Math.floor(Math.random() * 2147483640), sd: 1, td: 0, c: players.map(() => []),
      nm: players.map((p) => String(p.name || '').slice(0, 10)), seq: 0, last: null, ph: 'p' };
    s.td = Math.floor(rnd(s) * 4);
    nextCast(s);
    return s;
  }
  function actor(s) { return s.ph === 'e' ? null : s.ord[s.i]; }
  function validRec(a) {
    if (!a || a.type !== 'cast' || !Number.isInteger(a.x) || !Number.isInteger(a.y) || !Number.isInteger(a.h) || !Array.isArray(a.f)) return false;
    if (Math.abs(a.x) > 1000 || a.y < -100 || a.y > 1000 || a.h < -1 || a.h > 30000 || a.f.length > MAXTG) return false;
    let p = -1;
    for (const v of a.f) { if (!Number.isInteger(v) || v < 0 || v > FMAX || v <= p) return false; p = v; }
    return true;
  }
  const total = (s, p) => s.c[p].reduce((t, c) => t + (c[0] >= 0 ? c[1] : 0), 0);
  const biggest = (s, p) => s.c[p].reduce((t, c) => Math.max(t, c[0] >= 0 ? c[1] : 0), 0);
  const caught = (s, p) => s.c[p].filter((c) => c[0] >= 0 && c[0] !== BOOT).length;
  function apply(s, seat, a) {
    if (s.ph !== 'p' || actor(s) !== seat) throw new Error('not your turn');
    if (!validRec(a)) throw new Error('bad cast record');
    const res = judge(s.sd, s.td, a);
    const got = res.out === 'L';
    s.c[seat].push(got ? [res.fish.sp, res.fish.g] : [-1, MISSC[res.out]]);
    s.seq++;
    s.last = { id: s.seq, s: seat, sd: s.sd, td: s.td, x: Math.round(res.x * 10), y: Math.round(res.y * 10), h: a.h, f: encF(a.f.filter((v) => v < Math.max(1, res.k))),
      o: res.out, sp: got ? res.fish.sp : -1, g: got ? res.fish.g : 0 };
    s.i++;
    if (s.i >= s.n) {
      s.i = 0; s.r++;
      if (s.r >= s.N) s.ph = 'e';
      else { s.td = (s.td + 1) % 4; s.ord = s.ord.slice(1).concat(s.ord[0]); }
    }
    nextCast(s);
    return s;
  }
  function keyOf(s, p) { return s.md === 'b' ? [biggest(s, p), total(s, p)] : [total(s, p), biggest(s, p)]; }
  function rankOrder(s) { return s.c.map((v, i) => i).sort((a, b) => { const A = keyOf(s, a), B = keyOf(s, b); return B[0] - A[0] || B[1] - A[1] || a - b; }); }
  function winners(s) {
    if (s.ph !== 'e') return null;
    const rk = rankOrder(s), k0 = keyOf(s, rk[0]);
    return rk.filter((i) => { const k = keyOf(s, i); return k[0] === k0[0] && k[1] === k0[1]; }).sort((a, b) => a - b);
  }
  const kg = (g) => (g / 1000).toFixed(g >= 10000 ? 1 : 2) + 'kg';
  function result(s) {
    const w = winners(s);
    if (!w) return null;
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const lines = rankOrder(s).map((i, k) => {
      const big = s.c[i].filter((c) => c[0] >= 0 && c[0] !== BOOT).sort((a, b) => b[1] - a[1])[0];
      return (s.n > 1 ? (k + 1) + '위 ' : '') + nm(i) + ' · ' + (s.md === 'b' ? '최대 ' + (big ? kg(big[1]) : '없음') + ' (총 ' + kg(total(s, i)) + ')' : kg(total(s, i)) + ' (' + caught(s, i) + '마리' + (big ? ', 최대 ' + SP[big[0]].n + ' ' + kg(big[1]) : '') + ')');
    });
    const gold = s.c.some((r) => r.some((c) => c[0] === GOLD));
    const zero = w.every((i) => total(s, i) === 0);
    return { winners: zero && s.n > 1 ? [] : w,
      title: s.n === 1 ? kg(total(s, 0)) + (s.md === 'b' ? '' : ' · ' + caught(s, 0) + '마리') : zero ? '모두 빈손' : w.length > 1 ? '공동 우승' : undefined,
      text: (s.md === 'b' ? '가장 큰 한 마리 승부' : '총 무게 승부') + ' · ' + s.N + '번 던지기\n' + lines.join('\n') + (gold ? '\n황금 잉어가 나왔어요!' : '') };
  }

  /* ---------- AI: casting choice, hook reaction and tension control by level ---------- */
  const EV = {}; // expected grams per (zone, time of day), from the species table (no peeking at the seed)
  for (const z of ['S', 'W', 'D', 'R']) {
    EV[z] = TOD.map((t, td) => {
      let tot = 0, e = 0;
      SP.forEach((f, i) => { const w = (f.z[z] || 0) * f.t[td]; tot += w; if (i !== BOOT) e += w * (f.lo + (f.hi - f.lo) / 3.2) * (1 - 0.35 * f.str); });
      return e / tot;
    });
  }
  const ZSPOT = { S: [[0, 8], [-14, 10], [12, 9]], W: [[-14, 22], [13, 32]], D: [[3, 28], [-3, 36], [8, 22]], R: [[-12, 44]] };
  const LVF = {
    1: { pick: 0, sc: 4, re: 0.3, rs: 0.13, fool: 0.14, dl: 7, hi: 0.86, lo: 0.42, nz: 0.05, ant: 0.25 },
    2: { pick: 0.65, sc: 2.5, re: 0.2, rs: 0.07, fool: 0.04, dl: 5, hi: 0.8, lo: 0.42, nz: 0.035, ant: 0.75 },
    3: { pick: 1, sc: 1.5, re: 0.15, rs: 0.04, fool: 0, dl: 3, hi: 0.76, lo: 0.4, nz: 0.02, ant: 0.9 },
  };
  function gauss(R) { let u = 0, v = 0; while (u === 0) u = R(); while (v === 0) v = R(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  function aiPlay(s, lv, R) {
    const P = LVF[lv] || LVF[2];
    // 1) where to cast
    let x, y;
    if (R() < P.pick) {
      const zs = ['S', 'W', 'D', 'R'].sort((a, b) => EV[b][s.td] - EV[a][s.td]);
      const z = lv >= 3 || R() < 0.6 ? zs[0] : zs[1];
      const c = ZSPOT[z][Math.floor(R() * ZSPOT[z].length)];
      x = c[0] + gauss(R) * P.sc; y = c[1] + gauss(R) * P.sc;
    } else { const d = 6 + R() * 34, an = (R() - 0.5) * 1.6; x = d * Math.sin(an); y = d * Math.cos(an); }
    const p = landAt(x, y);
    const z = zoneOf(p.x, p.y), fish = fishOf(s.sd, z, s.td), b = biteOf(s.sd);
    // 2) hook: reacts to the dive; a beginner may strike at a nibble
    let h;
    if (b.nib.length && R() < P.fool) h = Math.round((b.nib[0] + 0.12 + R() * 0.1) * 1000);
    else h = Math.round((b.tb + Math.max(0.06, P.re + gauss(R) * P.rs)) * 1000);
    const rec = { type: 'cast', x: Math.round(p.x * 10), y: Math.round(p.y * 10), h, f: [] };
    const hk = hookOf(b, fish.win, h);
    if (!hk.ok) return rec;
    // 3) fight: watches the tension gauge with a reaction delay and some misjudgement
    const D0 = Math.max(5, Math.sqrt(p.x * p.x + p.y * p.y));
    const F = newFight(fish, s.sd, D0, hk.q), hist = [];
    let hold = false, nz = 0, dodge = -1, seen = -1;
    const hi = P.hi + gauss(R) * 0.02;
    while (!F.out) {
      hist.push(F.T);
      if (F.k % 8 === 0) nz = gauss(R) * P.nz;
      const Tp = hist[Math.max(0, hist.length - 1 - P.dl)] + nz;
      // the yellow "!" shows ~9 ticks before a burst; notice it (after the reaction delay) and maybe let go early
      if (F.k >= F.be && F.nb - F.k > 0 && F.nb - F.k <= 9 - P.dl && seen !== F.nb) { seen = F.nb; if (R() < P.ant) dodge = F.nb; }
      const dodging = dodge >= 0 && (F.k <= dodge || (F.bs === dodge && F.k < F.be - 4));
      if (dodge >= 0 && !dodging) dodge = -1;
      let want = hold;
      if (dodging) want = Tp < 0.2;
      else if (hold && Tp > hi) want = false;
      else if (!hold && Tp < P.lo) want = true;
      if (want !== hold && rec.f.length < MAXTG) { hold = want; rec.f.push(F.k); }
      fstep(F, hold);
    }
    return rec;
  }
  function ai(s, seat, lv) { return aiPlay(s, lv, mb(1 + Math.floor(Math.random() * 2147483000))); }

  /* ================================= view ================================= */
  const SPC = [ // body, belly, pattern, aspect
    ['#9fb7c6', '#eef2f0', 'pink', 0.24], ['#8a7a3a', '#d9c98a', 'scale', 0.42], ['#4f6a6a', '#e8a050', 'bars', 0.52],
    ['#5f7a3a', '#d8dcb0', 'band', 0.32], ['#3f4a32', '#a8a888', 'blot', 0.22], ['#7a6a40', '#e0cf98', 'scale', 0.36],
    ['#4a4038', '#8a8070', 'whisk', 0.25], ['#7a8a8a', '#e8d8d0', 'spot', 0.3], ['#9a8a50', '#e0d0a0', 'leop', 0.34],
    ['#e8a826', '#ffe08a', 'gold', 0.36], ['#3a3a3a', '#5a4a3a', 'boot', 0.5],
  ];
  const TODC = [ // sky top, sky bottom, water deep, water shallow, light
    ['#2b2a4a', '#d99a9a', '#2a4a62', '#4f7f8a', 'rgba(255,210,200,.10)'],
    ['#5a9ad0', '#cfe6ef', '#1f6b7a', '#3fa0a0', 'rgba(255,255,230,.08)'],
    ['#3a2448', '#f0a060', '#2a3a5a', '#7a6a6a', 'rgba(255,170,90,.12)'],
    ['#0a0c1c', '#1c2240', '#0c1a2c', '#1c3448', 'rgba(170,190,255,.05)'],
  ];
  function drawFish(ctx, x, y, len, sp, ang, alpha) {
    const c = SPC[sp] || SPC[0], h = len * c[3];
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang || 0); if (alpha != null) ctx.globalAlpha = alpha;
    if (c[2] === 'boot') {
      ctx.fillStyle = '#3d3a36'; ctx.strokeStyle = '#1c1a18'; ctx.lineWidth = Math.max(1, len * 0.03);
      ctx.beginPath(); ctx.moveTo(-len * 0.15, -len * 0.45); ctx.lineTo(len * 0.12, -len * 0.45); ctx.lineTo(len * 0.12, len * 0.05);
      ctx.quadraticCurveTo(len * 0.45, len * 0.08, len * 0.45, len * 0.22); ctx.lineTo(-len * 0.18, len * 0.22); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#5a5248'; ctx.fillRect(-len * 0.17, -len * 0.47, len * 0.31, len * 0.08);
      ctx.fillStyle = '#4a7a3a'; ctx.beginPath(); ctx.ellipse(len * 0.2, len * 0.0, len * 0.08, len * 0.03, 0.6, 0, 7); ctx.fill();
      ctx.restore(); return;
    }
    // tail
    ctx.fillStyle = c[0];
    ctx.beginPath(); ctx.moveTo(-len * 0.38, 0); ctx.lineTo(-len * 0.56, -h * 0.55); ctx.quadraticCurveTo(-len * 0.5, 0, -len * 0.56, h * 0.55); ctx.closePath(); ctx.fill();
    // fins
    ctx.beginPath(); ctx.moveTo(-len * 0.1, -h * 0.42); ctx.quadraticCurveTo(len * 0.02, -h * 0.85, len * 0.12, -h * 0.4); ctx.closePath(); ctx.fill();
    // body
    const g = ctx.createLinearGradient(0, -h / 2, 0, h / 2);
    g.addColorStop(0, c[0]); g.addColorStop(0.55, c[0]); g.addColorStop(1, c[1]);
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, len * 0.44, h / 2, 0, 0, 7); ctx.fill();
    ctx.save(); ctx.clip();
    if (c[2] === 'scale' || c[2] === 'gold') {
      ctx.strokeStyle = c[2] === 'gold' ? 'rgba(255,250,200,.55)' : 'rgba(0,0,0,.16)'; ctx.lineWidth = Math.max(0.6, len * 0.012);
      const s = Math.max(3, len * 0.07);
      for (let i = -6; i < 7; i++) for (let j = -3; j < 4; j++) { ctx.beginPath(); ctx.arc(i * s + (j % 2) * s / 2, j * s * 0.8, s * 0.55, -1.2, 1.2); ctx.stroke(); }
    } else if (c[2] === 'bars') { ctx.fillStyle = 'rgba(20,30,40,.3)'; for (let i = -3; i <= 3; i++) ctx.fillRect(i * len * 0.11, -h / 2, len * 0.05, h); }
    else if (c[2] === 'band') { ctx.fillStyle = 'rgba(30,40,20,.5)'; ctx.beginPath(); ctx.moveTo(-len * 0.4, 0); for (let i = 0; i <= 8; i++) ctx.lineTo(-len * 0.4 + i * len * 0.1, (i % 2 ? -1 : 1) * h * 0.08); ctx.lineTo(len * 0.4, h * 0.1); ctx.lineTo(-len * 0.4, h * 0.12); ctx.fill(); }
    else if (c[2] === 'blot' || c[2] === 'leop') { ctx.fillStyle = c[2] === 'blot' ? 'rgba(20,24,16,.45)' : 'rgba(60,40,10,.5)'; for (let i = 0; i < 14; i++) { ctx.beginPath(); ctx.ellipse(-len * 0.35 + (i * 0.37 % 1) * len * 0.7, -h * 0.3 + ((i * 0.61) % 1) * h * 0.55, len * 0.035, h * 0.09, 0, 0, 7); ctx.fill(); } }
    else if (c[2] === 'spot') { ctx.fillStyle = 'rgba(30,30,30,.45)'; for (let i = 0; i < 18; i++) ctx.fillRect(-len * 0.35 + (i * 0.41 % 1) * len * 0.7, -h * 0.4 + ((i * 0.73) % 1) * h * 0.45, len * 0.02, len * 0.02); ctx.fillStyle = 'rgba(230,110,140,.45)'; ctx.fillRect(-len * 0.4, -h * 0.05, len * 0.8, h * 0.12); }
    else if (c[2] === 'pink') { ctx.fillStyle = 'rgba(230,120,150,.45)'; for (let i = -3; i <= 3; i++) ctx.fillRect(i * len * 0.1, -h * 0.1, len * 0.03, h * 0.5); }
    if (c[2] === 'gold') { const sh = ctx.createLinearGradient(-len * 0.4, -h, len * 0.4, h); sh.addColorStop(0, 'rgba(255,255,255,0)'); sh.addColorStop(0.5, 'rgba(255,255,255,.45)'); sh.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = sh; ctx.fillRect(-len, -h, len * 2, h * 2); }
    ctx.restore();
    ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = Math.max(0.8, len * 0.015); ctx.beginPath(); ctx.ellipse(0, 0, len * 0.44, h / 2, 0, 0, 7); ctx.stroke();
    // gill + eye
    ctx.beginPath(); ctx.arc(len * 0.24, 0, h * 0.38, -1, 1); ctx.stroke();
    ctx.fillStyle = '#f5f0e0'; ctx.beginPath(); ctx.arc(len * 0.32, -h * 0.1, Math.max(1.2, len * 0.04), 0, 7); ctx.fill();
    ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(len * 0.33, -h * 0.1, Math.max(0.7, len * 0.022), 0, 7); ctx.fill();
    if (c[2] === 'whisk' || sp === 5 || sp === GOLD) {
      ctx.strokeStyle = 'rgba(30,25,20,.75)'; ctx.lineWidth = Math.max(0.7, len * 0.01);
      const wl = c[2] === 'whisk' ? 0.32 : 0.08;
      ctx.beginPath(); ctx.moveTo(len * 0.42, h * 0.05); ctx.quadraticCurveTo(len * (0.45 + wl), h * 0.2, len * (0.42 + wl), h * 0.55); ctx.moveTo(len * 0.42, h * 0.08); ctx.quadraticCurveTo(len * (0.5 + wl * 0.6), -h * 0.1, len * (0.45 + wl), h * 0.35); ctx.stroke();
    }
    ctx.restore();
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = L.h('div', { class: 'hud top fi-top', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px', alignItems: 'stretch' } });
    const creelBtn = L.h('button', { class: 'btn sm fi-creel', style: { position: 'absolute', left: '10px', bottom: '10px', minHeight: '44px', zIndex: 3, display: 'flex', alignItems: 'center', gap: '6px' }, onclick: (e) => { e.stopPropagation(); openCreel(); } });
    root.append(top, creelBtn);
    // invisible boxes over the lake / casting spot / tension gauge spot for the first-play tutorial spotlight
    const spLake = tutSpot(root, 'fi-lake'), spCast = tutSpot(root, 'fi-cast'), spGauge = tutSpot(root, 'fi-gauge');
    let st = null, G = null, time = 0, anim = null, myPend = null, pops = [], drops = [], waitTimer = 0, hintFlash = 0, creel = null;
    const ptrs = new Set();
    const color = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const pname = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || '');
    const sp = () => L.debug.speed || 1;
    let dex = {}; try { dex = U.store.get('fishing.dex', {}) || {}; } catch (e) { dex = {}; }

    function layout() {
      const W = cv.w, H = cv.h, topH = G ? G.topH : 74;
      const nearY = H - Math.round(clamp(H * 0.17, 104, 140)), farY = topH + 62;
      G = { W, H, topH, nearY, farY, cx: W / 2 };
      spLake(4, farY - 14, W - 8, nearY - farY - 30);
      spCast(W / 2 - 80, nearY - 74, 160, Math.min(H - 4, nearY + 60) - (nearY - 74));
      { const y1 = farY + 70, gh = Math.max(110, nearY - y1 - 30); spGauge(W - 50, y1 - 30, 40, gh + 58); }   // where the gauge shows while reeling
    }
    const TN = 52 / 82;
    const tn = (y) => (y / (y + 30)) / TN;
    const SY = (y) => G.nearY - tn(y) * (G.nearY - G.farY);
    const SC = (y) => { const t = clamp(tn(y), -0.3, 1.05); return G.W / 44 + (G.W / 70 - G.W / 44) * t; };
    const SX = (x, y) => G.cx + x * SC(y);
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function humanTurn() { if (!st || st.ph === 'e') return false; const a = actor(st); return a != null && api.canAct(a); }
    const rodTip = () => ({ x: G.cx + 46, y: G.nearY + 6 });

    /* ---------- scene ---------- */
    let lakePoly = null, lakeKey = '';
    function lakePath() {
      const key = G.W + 'x' + G.H + ':' + G.topH;
      if (key !== lakeKey) {
        lakeKey = key; const pts = [];
        let ym = 2; { let lo = 2, hi = 50; for (let i = 0; i < 30; i++) { const m = (lo + hi) / 2; if (far(hw(m)) > m) lo = m; else hi = m; } ym = lo; }
        for (let y = 2; y <= ym; y += 1) pts.push([-hw(y), y]);
        const xm = hw(ym);
        for (let x = -xm; x <= xm; x += 1) pts.push([x, far(x)]);
        for (let y = ym; y >= 2; y -= 1) pts.push([hw(y), y]);
        lakePoly = pts;
      }
      ctx.beginPath();
      lakePoly.forEach((p, i) => { const w = 0.7 + 0.5 * Math.sin(i * 0.45) + 0.3 * Math.sin(i * 1.1), cx = p[0], cy = p[1] - 25, l = Math.sqrt(cx * cx + cy * cy) || 1, x = p[0] + cx / l * w, y = Math.max(0.6, p[1] + (cy / l) * w); const X = SX(x, y), Y = SY(y); if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); });
      ctx.closePath();
    }
    function blob(x, y, r, n, ph) { ctx.beginPath(); for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2, rr2 = r * (0.82 + 0.18 * Math.sin(a * 3 + ph)); const X = SX(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2), Y = SY(y + Math.sin(a) * rr2); if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); } ctx.closePath(); }
    function drawScene(td, showZones) {
      const { W, H } = G, C = TODC[td];
      // sky + far bank
      const skyH = SY(52) + 6;
      const sky = ctx.createLinearGradient(0, 0, 0, skyH);
      sky.addColorStop(0, C[0]); sky.addColorStop(1, C[1]);
      ctx.fillStyle = sky; ctx.fillRect(0, 0, W, skyH);
      if (td === 3) { ctx.fillStyle = 'rgba(240,240,255,.7)'; for (let i = 0; i < 30; i++) ctx.fillRect((i * 97.3) % W, (i * 37.1) % Math.max(1, skyH - 10), 1.3, 1.3); ctx.fillStyle = '#f2ecd0'; ctx.beginPath(); ctx.arc(W * 0.62, Math.max(G.topH + 26, skyH - 40), 11, 0, 7); ctx.fill(); }
      else if (td !== 1) { const sg = ctx.createRadialGradient(W * (td === 0 ? 0.25 : 0.75), skyH, 0, W * (td === 0 ? 0.25 : 0.75), skyH, W * 0.5); sg.addColorStop(0, 'rgba(255,200,140,.55)'); sg.addColorStop(1, 'rgba(255,200,140,0)'); ctx.fillStyle = sg; ctx.fillRect(0, 0, W, skyH); }
      // land
      const land = ctx.createLinearGradient(0, skyH - 20, 0, H);
      land.addColorStop(0, td === 3 ? '#14201a' : '#2f4a2c'); land.addColorStop(1, td === 3 ? '#0c140f' : '#1f3320');
      ctx.fillStyle = land; ctx.fillRect(0, skyH - 22, W, H - skyH + 22);
      // tree line
      ctx.fillStyle = td === 3 ? '#0a120d' : '#1c3120';
      ctx.beginPath(); ctx.moveTo(0, skyH);
      for (let x = 0; x <= W + 8; x += 8) ctx.lineTo(x, skyH - 14 - 9 * Math.abs(Math.sin(x * 0.07)) - 6 * Math.abs(Math.sin(x * 0.19 + 1)));
      ctx.lineTo(W, skyH + 4); ctx.lineTo(0, skyH + 4); ctx.closePath(); ctx.fill();
      // stream inlet near the rocks
      ctx.strokeStyle = TODC[td][3]; ctx.lineWidth = 7; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(SX(-14, 47), SY(47)); ctx.quadraticCurveTo(SX(-22, 54), SY(56), SX(-30, 60), SY(60)); ctx.stroke();
      // water
      ctx.save(); lakePath();
      ctx.fillStyle = '#6b5a3a'; ctx.lineWidth = 6; ctx.strokeStyle = td === 3 ? '#2a2418' : '#7a6844'; ctx.stroke();
      const wg = ctx.createLinearGradient(0, SY(50), 0, G.nearY);
      wg.addColorStop(0, C[3]); wg.addColorStop(0.5, C[2]); wg.addColorStop(1, C[3]);
      ctx.fillStyle = wg; ctx.fill();
      ctx.clip();
      // deep centre
      const dg = ctx.createRadialGradient(SX(2, 30), SY(30), 0, SX(2, 30), SY(30), W * 0.36);
      dg.addColorStop(0, 'rgba(0,10,25,.35)'); dg.addColorStop(1, 'rgba(0,10,25,0)');
      ctx.fillStyle = dg; ctx.fillRect(0, 0, W, H);
      // shimmer lines
      ctx.strokeStyle = C[4].replace(/[\d.]+\)$/, '0.22)'); ctx.lineWidth = 1;
      for (let i = 0; i < 16; i++) { const y = 4 + i * 3.1, x = ((i * 7.3 + time * (0.6 + (i % 3) * 0.2)) % 40) - 20; ctx.beginPath(); ctx.moveTo(SX(x - 2, y), SY(y)); ctx.lineTo(SX(x + 2, y), SY(y)); ctx.stroke(); }
      if (td === 3) { ctx.fillStyle = 'rgba(240,236,208,.18)'; ctx.fillRect(W * 0.76, SY(50), 6, G.nearY - SY(50)); }
      // weed bed (W1)
      ctx.fillStyle = 'rgba(40,90,40,.55)'; blob(SPOTS.W1[0], SPOTS.W1[1], SPOTS.W1[2] * 0.9, 18, 1); ctx.fill();
      ctx.strokeStyle = 'rgba(120,170,80,.75)'; ctx.lineWidth = 1.5;
      for (let i = 0; i < 26; i++) { const a = i * 2.4, r = SPOTS.W1[2] * 0.85 * Math.sqrt((i * 0.37) % 1), x = SPOTS.W1[0] + Math.cos(a) * r, y = SPOTS.W1[1] + Math.sin(a) * r; const X = SX(x, y), Y = SY(y), sw = Math.sin(time * 1.5 + i) * 2; ctx.beginPath(); ctx.moveTo(X, Y); ctx.quadraticCurveTo(X + sw, Y - 6, X + sw * 1.6, Y - 11); ctx.stroke(); }
      // lily pads (W2)
      for (let i = 0; i < 11; i++) { const a = i * 2.1, r = SPOTS.W2[2] * 0.8 * Math.sqrt((i * 0.53) % 1), x = SPOTS.W2[0] + Math.cos(a) * r, y = SPOTS.W2[1] + Math.sin(a) * r, X = SX(x, y), Y = SY(y), s = SC(y) * 1.4;
        ctx.fillStyle = i % 3 ? '#3f7a3a' : '#4f8a42'; ctx.beginPath(); ctx.ellipse(X, Y, s, s * 0.5, 0, 0.35 + i, 0.35 + i + 5.6); ctx.lineTo(X, Y); ctx.fill();
        if (i % 4 === 0) { ctx.fillStyle = '#f2b8c8'; ctx.beginPath(); ctx.arc(X + 1, Y - 1, Math.max(1.5, s * 0.25), 0, 7); ctx.fill(); } }
      // rocks (R)
      for (let i = 0; i < 9; i++) { const a = i * 2.7, r = SPOTS.R[2] * 0.75 * Math.sqrt((i * 0.61) % 1), x = SPOTS.R[0] + Math.cos(a) * r, y = SPOTS.R[1] + Math.sin(a) * r, X = SX(x, y), Y = SY(y), s = SC(y) * (0.7 + (i % 3) * 0.3);
        ctx.fillStyle = td === 3 ? '#3a3e46' : '#7a7a80'; ctx.beginPath(); ctx.ellipse(X, Y, s, s * 0.6, 0, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.ellipse(X - s * 0.25, Y - s * 0.2, s * 0.4, s * 0.2, 0, 0, 7); ctx.fill(); }
      ctx.strokeStyle = 'rgba(255,255,255,.25)'; for (let i = 0; i < 4; i++) { const ph = (time * 0.8 + i * 0.25) % 1; ctx.beginPath(); ctx.ellipse(SX(-12, 46), SY(46), 6 + ph * 22, (6 + ph * 22) * 0.35, 0, 0, 7); ctx.globalAlpha = 1 - ph; ctx.stroke(); } ctx.globalAlpha = 1;
      if (showZones) {
        ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(242,233,216,.55)';
        ctx.fillText('수초', SX(-14, 22), SY(22)); ctx.fillText('연잎', SX(13, 32), SY(32)); ctx.fillText('바위 여울', SX(-12, 44), SY(44) + 12); ctx.fillText('깊은 곳', SX(3, 30), SY(30)); ctx.fillText('얕은 물가', SX(0, 7), SY(7));
      }
      ctx.restore();
      // near shore: grass + reeds + angler
      const sh = ctx.createLinearGradient(0, G.nearY, 0, H);
      sh.addColorStop(0, td === 3 ? '#1a2a1c' : '#3d5a30'); sh.addColorStop(1, td === 3 ? '#0e170f' : '#24361e');
      ctx.fillStyle = sh; ctx.beginPath(); ctx.moveTo(0, G.nearY + 14);
      for (let x = 0; x <= W; x += 12) ctx.lineTo(x, G.nearY + 6 + 4 * Math.sin(x * 0.05));
      ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = td === 3 ? '#26402a' : '#6a8a40'; ctx.lineWidth = 2;
      for (let i = 0; i < 14; i++) { const x = (i * 53.7) % W, sw = Math.sin(time * 1.2 + i) * 3; if (Math.abs(x - G.cx) < 60) continue; ctx.beginPath(); ctx.moveTo(x, G.nearY + 20); ctx.quadraticCurveTo(x + sw, G.nearY, x + sw * 1.5, G.nearY - 14); ctx.stroke(); }
      if (td === 3) { ctx.fillStyle = 'rgba(220,255,140,.8)'; for (let i = 0; i < 7; i++) { const x = (i * 71 + Math.sin(time * 0.7 + i) * 20) % W, y = G.nearY - 30 + Math.sin(time * 1.1 + i * 2) * 14; ctx.globalAlpha = 0.4 + 0.4 * Math.sin(time * 3 + i); ctx.beginPath(); ctx.arc(x, y, 1.6, 0, 7); ctx.fill(); } ctx.globalAlpha = 1; }
    }
    function drawAngler(col, bend, reel) {
      const x = G.cx, y = G.nearY + 40, t = rodTip();
      // rod
      ctx.strokeStyle = '#2a2018'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
      const mx = (x + 12 + t.x) / 2 + bend * 4, my = (y - 4 + t.y) / 2 - 10 + bend * 14;
      ctx.beginPath(); ctx.moveTo(x + 12, y - 4); ctx.quadraticCurveTo(mx, my, t.x, t.y + bend * 10); ctx.stroke();
      ctx.strokeStyle = '#c9a060'; ctx.lineWidth = 1.4; ctx.stroke();
      // body (seen from behind)
      ctx.fillStyle = col; rr(x - 18, y - 6, 36, 40, 12); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(x - 2, y - 6, 4, 40);
      ctx.fillStyle = '#e8c9a0'; ctx.beginPath(); ctx.arc(x, y - 14, 10, 0, 7); ctx.fill();
      ctx.fillStyle = '#c8a050'; ctx.beginPath(); ctx.ellipse(x, y - 19, 17, 5, 0, 0, 7); ctx.fill(); ctx.beginPath(); ctx.ellipse(x, y - 23, 9, 6, 0, Math.PI, 0); ctx.fill();
      // reel
      ctx.save(); ctx.translate(x + 16, y + 4); ctx.rotate(reel);
      ctx.fillStyle = '#8c8798'; ctx.beginPath(); ctx.arc(0, 0, 6, 0, 7); ctx.fill(); ctx.strokeStyle = '#2a2530'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(8, 0); ctx.stroke();
      ctx.restore();
    }
    function bobber(X, Y, dip, s) {
      s = s || 1;
      ctx.save(); ctx.translate(X, Y);
      ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(0, 2, 7 * s, 2.5 * s, 0, 0, 7); ctx.stroke();
      const sink = clamp(dip, 0, 1) * 9 * s;
      ctx.beginPath(); ctx.rect(-10 * s, -20 * s, 20 * s, 21 * s); ctx.clip();
      ctx.translate(0, sink);
      ctx.fillStyle = '#f2ecdc'; ctx.beginPath(); ctx.ellipse(0, -2 * s, 4.2 * s, 4.6 * s, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#e0412e'; ctx.beginPath(); ctx.ellipse(0, -4.5 * s, 4.2 * s, 3.4 * s, 0, Math.PI, 0); ctx.fill();
      ctx.strokeStyle = '#e0412e'; ctx.lineWidth = 1.6 * s; ctx.beginPath(); ctx.moveTo(0, -7 * s); ctx.lineTo(0, -15 * s); ctx.stroke();
      ctx.restore();
    }
    function hint(text, col, y) {
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const w = ctx.measureText(text).width + 26, x = G.W / 2;
      ctx.fillStyle = 'rgba(18,14,24,.85)'; rr(x - w / 2, y - 13, w, 26, 13); ctx.fill();
      ctx.fillStyle = col || '#f2e9d8'; ctx.fillText(text, x, y + 0.5);
    }
    function pop(text, col, life) { pops = [{ text, col, t: 0, life: (life || 1.2) / Math.sqrt(sp()) }]; }
    function drawPops(dt) {
      for (const p of pops) p.t += dt;
      pops = pops.filter((p) => p.t < p.life);
      for (const p of pops) {
        const a = p.t < 0.1 ? p.t / 0.1 : p.t > p.life - 0.25 ? Math.max(0, (p.life - p.t) / 0.25) : 1;
        ctx.save(); ctx.globalAlpha = a; ctx.font = '400 30px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const y = G.farY + 70 - Math.min(1, p.t / 0.2) * 6;
        ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(18,14,24,.85)'; ctx.strokeText(p.text, G.W / 2, y);
        ctx.fillStyle = p.col; ctx.fillText(p.text, G.W / 2, y); ctx.restore();
      }
    }
    function drawInfo(s, td) {
      const x0 = 10, y0 = G.topH + 4, seat = anim ? anim.seat : actor(s);
      const nth = seat != null ? Math.min(s.N, s.c[seat].length + 1) : s.N;
      const t1 = TOD[td] + ' · ' + nth + '/' + s.N + '번째';
      const t2 = s.md === 'b' ? '가장 큰 한 마리 승부' : '총 무게 승부';
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const tw = Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width * 0.92) + 22;
      ctx.fillStyle = 'rgba(18,14,24,.8)'; rr(x0, y0, tw, 44, 12); ctx.fill();
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t1, x0 + 11, y0 + 14);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText(t2, x0 + 11, y0 + 31);
    }
    function zoneHint(z, td) {
      const ws = SP.map((f, i) => [i, (f.z[z] || 0) * f.t[td]]).filter((v) => v[1] > 0 && v[0] !== BOOT).sort((a, b) => b[1] - a[1]).slice(0, 3);
      return ws.map((v) => (dex[v[0]] ? SP[v[0]].n : '???')).join('·');
    }
    function drawGauge(F) {
      const x = G.W - 30, y1 = G.farY + 70, h = Math.max(110, G.nearY - y1 - 30);
      ctx.fillStyle = 'rgba(18,14,24,.82)'; rr(x - 16, y1 - 26, 32, h + 50, 14); ctx.fill();
      const Y = (v) => y1 + h * (1 - v);
      ctx.fillStyle = 'rgba(95,211,160,.35)'; ctx.fillRect(x - 7, Y(TGREEN[1]), 14, Y(TGREEN[0]) - Y(TGREEN[1]));
      ctx.fillStyle = 'rgba(238,106,85,.55)'; ctx.fillRect(x - 7, Y(1), 14, Y(TRED) - Y(1));
      ctx.strokeStyle = 'rgba(242,233,216,.3)'; ctx.lineWidth = 1; ctx.strokeRect(x - 7, y1, 14, h);
      const T = clamp(F.T, 0, 1), col = T >= TRED ? '#ee6a55' : T > TGREEN[1] ? '#e3ae45' : T >= TGREEN[0] ? '#5fd3a0' : '#8fb3cf';
      ctx.fillStyle = col; ctx.fillRect(x - 5, Y(T), 10, Y(0) - Y(T));
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(x - 12, Y(T)); ctx.lineTo(x - 7, Y(T) - 4); ctx.lineTo(x - 7, Y(T) + 4); ctx.closePath(); ctx.fill();
      ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ab9fb8';
      ctx.fillText('장력', x, y1 - 14);
      ctx.font = '600 10px "IBM Plex Mono", monospace'; ctx.fillText(Math.max(0, F.D).toFixed(1) + 'm', x, y1 + h + 12);
      if (F.slack > 0.3) { ctx.fillStyle = '#8fb3cf'; ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.fillText('느슨', x, Y(0) - 10); }
    }

    /* ---------- HUD (DOM) ---------- */
    let hudKey = '';
    function renderTop(s, cur) {
      if (!s) return;
      const key = JSON.stringify([s.c, cur, s.ph]);
      if (key === hudKey) return;
      hudKey = key;
      top.innerHTML = '';
      for (let i = 0; i < s.n; i++) {
        const p = api.players[i] || { name: s.nm[i], color: '#fff' }, on = cur === i;
        const big = s.md === 'b' ? biggest(s, i) : total(s, i);
        const chips = s.c[i].slice(s.n > 3 ? -4 : -6).map((c) => L.h('span', { class: 'mono', style: { fontSize: '10px', fontWeight: 700, padding: '0 3px', borderRadius: '4px', lineHeight: '14px',
          background: c[0] >= 0 && c[0] !== BOOT ? (SP[c[0]].r >= 2 ? '#e3ae45' : 'var(--surface-2)') : 'transparent', color: c[0] >= 0 && SP[c[0]].r >= 2 ? '#2a1d05' : c[0] >= 0 ? 'var(--ink)' : 'var(--muted)',
          border: c[0] < 0 || c[0] === BOOT ? '1px solid rgba(242,233,216,.2)' : '0' }, text: c[0] >= 0 ? SP[c[0]].n.replace('황금 잉어', '황금').slice(0, c[0] === BOOT ? 2 : 3) : c[1] === 2 ? '끊김' : '✕' }));
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '6px 8px', display: 'flex', flexDirection: 'column', gap: '3px', opacity: on || cur == null ? 1 : 0.68, borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color + ' inset' : '' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
            L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, text: p.name })),
          L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '3px' } },
            L.h('span', { class: 'mono', style: { fontSize: s.n > 3 ? '16px' : '20px', fontWeight: 600, lineHeight: 1 }, text: (big / 1000).toFixed(2) }),
            L.h('span', { class: 'muted', style: { fontSize: '10px', fontWeight: 700 }, text: s.md === 'b' ? 'kg 최대' : 'kg' })),
          L.h('div', { style: { display: 'flex', gap: '2px', minHeight: '14px', overflow: 'hidden' } }, chips)));
      }
      const n = s.c.reduce((t, r) => t + r.filter((c) => c[0] >= 0).length, 0);
      creelBtn.innerHTML = ''; creelBtn.append('어망 ', L.h('span', { class: 'mono', text: String(n) }));
      requestAnimationFrame(() => { const h = top.getBoundingClientRect().height; if (h && G && Math.abs(h + 4 - G.topH) > 1) { G.topH = h + 4; layout(); } });
    }
    /* collection sheet: everyone's catch + this lake's species guide */
    function fishCanvas(sp2, w, h) {
      const c = L.h('canvas', { style: { width: w + 'px', height: h + 'px', flex: 'none' } }), d = Math.min(2, window.devicePixelRatio || 1);
      c.width = w * d; c.height = h * d; const x = c.getContext('2d'); x.scale(d, d);
      drawFish(x, w / 2, h / 2, w * 0.82, sp2, sp2 === BOOT ? 0 : -0.08);
      return c;
    }
    function openCreel() {
      if (!st || creel) return;
      api.sfx('click');
      const s = st, seen = {};
      s.c.forEach((r) => r.forEach((c) => { if (c[0] >= 0) seen[c[0]] = 1; }));
      const lists = s.c.map((r, i) => {
        const fish = r.map((c, k) => [c, k]).filter((v) => v[0][0] >= 0).sort((a, b) => b[0][1] - a[0][1]);
        return L.h('section', { style: { display: 'flex', flexDirection: 'column', gap: '4px' } },
          L.h('div', { class: 'row', style: { gap: '6px', fontWeight: 700 } }, L.h('span', { class: 'dot', style: { '--c': color(i) } }), pname(i),
            L.h('span', { class: 'mono muted', style: { marginLeft: 'auto', fontSize: '12px' }, text: kg(total(s, i)) })),
          fish.length ? fish.map(([c]) => L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '2px 6px', borderRadius: '8px', background: 'var(--surface-2)' } },
            fishCanvas(c[0], 64, 30), L.h('span', { style: { fontWeight: 700, fontSize: '13px' }, text: SP[c[0]].n }),
            L.h('span', { class: 'label', style: { color: SP[c[0]].r >= 2 ? 'var(--brass)' : 'var(--muted)' }, text: RAR[SP[c[0]].r] }),
            L.h('span', { class: 'mono', style: { marginLeft: 'auto', fontSize: '12px' }, text: c[0] === BOOT ? '0점' : kg(c[1]) })))
            : L.h('p', { class: 'muted', style: { margin: 0, fontSize: '12px' }, text: r.length ? '아직 빈 어망' : '아직 안 던졌어요' }));
      });
      const guide = L.h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(92px, 1fr))', gap: '6px' } },
        SP.map((f, i) => { const k = seen[i] || dex[i]; return L.h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '4px', borderRadius: '8px', background: 'var(--surface-2)', opacity: k ? 1 : 0.55 } },
          k ? fishCanvas(i, 70, 32) : L.h('div', { class: 'mono muted', style: { height: '32px', lineHeight: '32px' }, text: '?' }),
          L.h('span', { style: { fontSize: '11px', fontWeight: 700 }, text: k ? f.n : '???' }),
          L.h('span', { class: 'label', style: { fontSize: '10px', color: f.r >= 2 ? 'var(--brass)' : 'var(--muted)' }, text: RAR[f.r] + (seen[i] ? ' · 이번 판' : '') })); }));
      const close = () => { if (creel) { creel.remove(); creel = null; } };
      creel = L.h('div', { class: 'overlay', style: { zIndex: 6 }, onclick: (e) => { if (e.target === creel) close(); } },
        L.h('div', { class: 'sheet', style: { maxHeight: '86%', overflowY: 'auto' } },
          L.h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } }, L.h('h2', { text: '어망' }), L.h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
          lists, L.h('span', { class: 'label', text: '어종 도감 (이 폰에서 낚은 어종은 계속 기억해요)' }), guide,
          L.h('button', { class: 'btn block', text: '닫기', onclick: close })));
      root.append(creel);
    }

    /* ---------- turn animation: live play and replay share one driver ---------- */
    function startLive() {
      const seat = actor(st);
      anim = { mode: 'live', ph: 'aim', seat, sd: st.sd, td: st.td, t: 0, snap: st, seq: st.seq, aim: null, rec: { type: 'cast', x: 0, y: 0, h: -1, f: [] }, hold: false };
    }
    function prep(a, x, y) { // shared setup once the cast point is known
      const p = landAt(x, y);
      a.x = p.x; a.y = p.y; a.z = zoneOf(p.x, p.y); a.fish = fishOf(a.sd, a.z, a.td); a.b = biteOf(a.sd);
      a.D0 = Math.max(5, Math.sqrt(p.x * p.x + p.y * p.y));
    }
    function startReplay(l, prev) {
      const a = { mode: 'replay', ph: 'cast', seat: l.s, sd: l.sd, td: l.td, t: 0, snap: prev || st, last: l };
      prep(a, l.x / 10, l.y / 10);
      a.hk = hookOf(a.b, a.fish.win, l.h);
      a.h = l.h; a.f = decF(l.f);
      if (a.hk.ok) { a.F = newFight(a.fish, a.sd, a.D0, a.hk.q); a.fi = 0; a.fhold = false; }
      a.res = { out: l.o, sp: l.sp, g: l.g };
      anim = a;
      api.setBusy(true);
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim === a) endAnim(); }, 90000);
    }
    function endAnim() {
      anim = null; clearTimeout(waitTimer); ptrs.clear();
      hudKey = ''; renderTop(st, st ? actor(st) : null);
      api.setBusy(false);
    }
    function toCard(a) {
      a.ph = 'card'; a.ct = 0;
      const r = a.res, got = r.out === 'L';
      if (got) {
        api.sfx(SP[r.sp].r >= 2 ? 'win' : 'pop'); api.buzz(r.sp === GOLD ? [30, 40, 60] : 30);
        const snap = a.snap, prevMine = snap && snap.c[a.seat] ? snap.c[a.seat].some((c) => c[0] === r.sp) : true;
        a.newSp = !prevMine && r.sp !== BOOT;
        if (api.canAct(a.seat) && r.sp !== BOOT && !dex[r.sp]) { dex[r.sp] = 1; try { U.store.set('fishing.dex', dex); } catch (e) {} a.dexNew = true; }
      } else { api.sfx('lose'); api.buzz(r.out === 'S' ? 40 : 15); }
      hudKey = ''; renderTop(a.snap, a.seat);
    }
    function finishLive(a, out) {
      a.res = { out, sp: out === 'L' ? a.fish.sp : -1, g: out === 'L' ? a.fish.g : 0 };
      myPend = { seq: st.seq, seat: a.seat };
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { if (anim === a && !a.ack) endAnim(); }, 8000);
      api.act(a.rec);
      toCard(a);
    }
    function dipAt(a, t) { // bobber dip amount at time t after landing (0 calm, 1 fully under)
      const b = a.b;
      if (t >= b.tb) { const u = (t - b.tb) / a.fish.win; return u < 1 ? 1 : Math.max(0, 1 - (u - 1) * 3) * 0.6; }
      for (const n of b.nib) if (t >= n && t < n + NIBD) return 0.45 * Math.sin((t - n) / NIBD * Math.PI);
      return 0.06 * Math.sin(t * 3.1);
    }
    function splash(x, y, n, big) { for (let i = 0; i < n; i++) { const an = Math.random() * 7, s = (big ? 50 : 25) + Math.random() * (big ? 90 : 40); drops.push({ x, y, vx: Math.cos(an) * s, vy: -Math.abs(Math.sin(an)) * s - 20, t: 0, life: 0.4 + Math.random() * 0.3 }); } }
    function stepAnim(dt) {
      const a = anim, k = dt * sp() * (a.ff ? 5 : 1);
      if (a.ph === 'aim') return;
      if (a.ph === 'cast') {
        a.t += k;
        if (a.t >= 0.75) { a.ph = 'wait'; a.t = 0; api.sfx('thud'); splash(SX(a.x, a.y), SY(a.y), 10, false); }
        return;
      }
      if (a.ph === 'wait') {
        const pt = a.t;
        a.t += k * (a.mode === 'replay' ? 1.6 : 1);
        const t = a.t, b = a.b;
        for (const n of b.nib) if (pt < n && t >= n) { api.sfx('tick'); if (a.mode === 'live') api.buzz(6); }
        if (pt < b.tb && t >= b.tb) { api.sfx('bounce'); api.buzz(25); splash(SX(a.x, a.y), SY(a.y), 8, false); }
        if (a.mode === 'live') {
          if (t > b.tb + a.fish.win + 0.25) { a.rec.h = -1; pop('너무 늦었어요', '#ee6a55'); finishLive(a, 'l'); }
        } else if (t * 1000 >= (a.h >= 0 ? a.h : (b.tb + a.fish.win + 0.25) * 1000)) {
          if (a.hk.ok) { a.ph = 'fight'; a.acc = 0; api.sfx('whoosh'); pop(a.hk.q > 0.65 ? '완벽한 챔질!' : '챔질!', '#5fd3a0', 0.9); }
          else { pop(OUTN[a.hk.why], '#ee6a55'); toCard(a); }
        }
        return;
      }
      if (a.ph === 'fight') {
        const F = a.F;
        a.acc += k * (a.mode === 'replay' ? 1.5 : 1) / FDT;
        while (a.acc >= 1 && !F.out) {
          a.acc -= 1;
          if (a.mode === 'live') {
            const hold = ptrs.size > 0;
            if (hold !== a.hold && a.rec.f.length < MAXTG) { a.hold = hold; a.rec.f.push(F.k); }
            fstep(F, a.hold);
          } else {
            while (a.fi < a.f.length && a.f[a.fi] <= F.k) { a.fhold = !a.fhold; a.fi++; }
            a.hold = a.fhold; fstep(F, a.hold);
          }
          if (F.k === F.bs + 1) { splash(fishPos(a).x, fishPos(a).y, 6, true); api.sfx('roll'); if (a.mode === 'live') api.buzz(12); }
          if (F.T >= TRED && a.mode === 'live' && F.k % 6 === 0) api.buzz(8);
        }
        if (F.out) {
          const fp = fishPos(a);
          if (F.out === 'L') { splash(fp.x, fp.y, 14, true); pop(OUTN.L, '#5fd3a0'); }
          else pop(OUTN[F.out], '#ee6a55');
          if (a.mode === 'live') finishLive(a, F.out); else toCard(a);
        }
        return;
      }
      if (a.ph === 'card') {
        a.ct += dt * Math.sqrt(sp());
        if (a.ct > (a.res.out === 'L' ? 2.6 : 1.6) && (a.mode === 'replay' || a.ack)) endAnim();
      }
    }
    function fishPos(a) { // the fish under water, along the line from the bobber to the angler
      const F = a.F, f = clamp(F.D / a.D0, 0, 1.3), x = a.x * f, y = Math.max(1, a.y * f);
      let side = 0;
      if (F.k >= F.bs && F.k < F.be + 20) side = F.dir * Math.min(1, (F.k - F.bs) / 15) * Math.max(0, 1 - Math.max(0, F.k - F.be) / 20);
      const X = x + side * 3.5, Y = y;
      return { x: SX(X, Y), y: SY(Y), lx: X, ly: Y };
    }

    let reelAng = 0, creelHidden = false;
    const stopLoop = U.loop((dt) => {
      time += dt;
      if (!G || !st) return;
      if (hintFlash > 0) hintFlash -= dt;
      if (!anim && humanTurn() && !(myPend && myPend.seq === st.seq)) startLive();
      if (anim) stepAnim(dt);
      // the creel sheet would cover the lake mid-cast and leave the fight running: hide its button while I'm fishing
      const busyHands = !!anim && anim.mode === 'live' && (anim.ph === 'cast' || anim.ph === 'wait' || anim.ph === 'fight');
      if (busyHands !== creelHidden) { creelHidden = busyHands; creelBtn.style.display = busyHands ? 'none' : 'flex'; }
      for (const d of drops) { d.t += dt; d.vy += 300 * dt; d.x += d.vx * dt; d.y += d.vy * dt; }
      drops = drops.filter((d) => d.t < d.life);
      draw(dt);
    });

    function draw(dt) {
      cv.clear();
      const s = st, a = anim, td = a ? a.td : s.ph === 'e' ? s.td : s.td;
      drawScene(td, a && a.mode === 'live' && a.ph === 'aim');
      const seat = a ? a.seat : actor(s), col = seat != null ? color(seat) : '#e3ae45';
      const tip = rodTip();
      let bend = 0;
      // line + bobber / fish
      if (a && a.ph !== 'aim' && a.x != null) {
        const bx = SX(a.x, a.y), by = SY(a.y);
        if (a.ph === 'cast') {
          const u = clamp(a.t / 0.75, 0, 1), x = tip.x + (bx - tip.x) * u, y = tip.y + (by - tip.y) * u - Math.sin(u * Math.PI) * 90;
          ctx.strokeStyle = 'rgba(242,233,216,.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(tip.x, tip.y); ctx.quadraticCurveTo((tip.x + x) / 2, Math.min(tip.y, y) - 20, x, y); ctx.stroke();
          bobber(x, y, 0, 0.9 + 0.4 * Math.sin(u * Math.PI));
        } else if (a.ph === 'wait' || (a.ph === 'card' && !a.F)) {
          const dip = a.ph === 'wait' ? dipAt(a, a.t) : 0;
          ctx.strokeStyle = 'rgba(242,233,216,.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(tip.x, tip.y); ctx.quadraticCurveTo((tip.x + bx) / 2, (tip.y + by) / 2 + 20, bx, by - 14 + dip * 9); ctx.stroke();
          if (a.ph === 'wait' && a.t >= a.b.tb && a.t < a.b.tb + a.fish.win) { ctx.strokeStyle = 'rgba(255,255,255,' + (0.6 - ((a.t - a.b.tb) % 0.3)) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(bx, by, 10 + ((a.t - a.b.tb) % 0.3) * 60, 4 + ((a.t - a.b.tb) % 0.3) * 20, 0, 0, 7); ctx.stroke(); }
          bobber(bx, by, dip, 1);
          if (a.mode === 'live' && a.ph === 'wait') { ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.fillText(ZN[a.z], bx, by + 16); }
        } else if (a.F) {
          const F = a.F, fp = fishPos(a), len = clamp(20 + (a.fish.g / 1000) * 6, 18, 70) * SC(fp.ly) / 8;
          bend = clamp(F.T, 0, 1.1);
          if (a.ph === 'fight' || F.out === 'L') {
            const ang = Math.atan2(tip.y - fp.y, tip.x - fp.x) + Math.PI;
            if (F.out !== 'L') drawFish(ctx, fp.x, fp.y, len, a.fish.sp, ang + Math.PI, 0.5 + 0.2 * Math.sin(time * 9));
            const T = clamp(F.T, 0, 1.1), sag = Math.max(0, 0.4 - T) * 40;
            ctx.strokeStyle = T >= TRED ? '#ee6a55' : 'rgba(242,233,216,.75)'; ctx.lineWidth = T >= TRED ? 1.6 : 1.1;
            ctx.beginPath(); ctx.moveTo(tip.x, tip.y + bend * 10); ctx.quadraticCurveTo((tip.x + fp.x) / 2, (tip.y + fp.y) / 2 + sag, fp.x, fp.y); ctx.stroke();
            ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(fp.x, fp.y, 6 + Math.sin(time * 12) * 2, 2.5, 0, 0, 7); ctx.stroke();
            const warn = !F.out && F.nb - F.k > 0 && F.nb - F.k < 10 && F.k >= F.be;
            if (warn || (F.k >= F.bs && F.k < F.be)) { ctx.font = '400 22px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(18,14,24,.8)'; ctx.strokeText('!', fp.x, fp.y - 18); ctx.fillStyle = warn ? '#e3ae45' : '#ee6a55'; ctx.fillText('!', fp.x, fp.y - 18); }
          }
          if (a.ph === 'fight') drawGauge(F);
        }
      }
      reelAng += dt * (a && a.ph === 'fight' && a.hold ? 18 : 0);
      drawAngler(col, bend, reelAng);
      ctx.fillStyle = 'rgba(245,250,255,.85)';
      for (const d of drops) { ctx.globalAlpha = 1 - d.t / d.life; ctx.beginPath(); ctx.arc(d.x, d.y, 1.8, 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
      // aim preview
      if (a && a.mode === 'live' && a.ph === 'aim' && a.aim) {
        const p = a.aim, X = SX(p.x, p.y), Y = SY(p.y), ok = !a.aim.cancel;
        ctx.setLineDash([4, 5]); ctx.strokeStyle = ok ? 'rgba(242,233,216,.7)' : 'rgba(238,106,85,.6)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(tip.x, tip.y); ctx.quadraticCurveTo((tip.x + X) / 2, Math.min(tip.y, Y) - 60, X, Y); ctx.stroke(); ctx.setLineDash([]);
        if (ok) {
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(X, Y, 14, 6, 0, 0, 7); ctx.stroke();
          ctx.beginPath(); ctx.ellipse(X, Y, 4, 2, 0, 0, 7); ctx.fillStyle = '#e3ae45'; ctx.fill();
          const z = zoneOf(p.x, p.y), t1 = ZN[z] + ' · ' + Math.round(Math.sqrt(p.x * p.x + p.y * p.y)) + 'm', t2 = zoneHint(z, a.td);
          ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
          const w = Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width * 0.95) + 20, bx = clamp(X - w / 2, 6, G.W - w - 6), by = Y > G.farY + 80 ? Y - 58 : Y + 14;
          ctx.fillStyle = 'rgba(18,14,24,.85)'; rr(bx, by, w, 40, 10); ctx.fill();
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t1, bx + w / 2, by + 13);
          ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText(t2, bx + w / 2, by + 28);
        }
      }
      // HUD
      drawInfo(a ? a.snap : s, td);
      const live = a && a.mode === 'live';
      const hy = G.nearY - 18;
      if (live && a.ph === 'aim') {
        if (!a.aim) {
          hint(hintFlash > 0 ? '조금 더 길게 밀어 올리세요' : '화면을 위로 밀어 던질 곳 정하기 · 놓으면 캐스팅', hintFlash > 0 ? '#ee6a55' : '#f2e9d8', G.nearY - 18);
          const yy = G.nearY - 50 - ((time * 40) % 30);
          ctx.strokeStyle = 'rgba(227,174,69,' + (0.35 + 0.3 * Math.sin(time * 4)) + ')'; ctx.lineWidth = 2.5;
          for (let i = 0; i < 2; i++) { const y = yy - i * 10; ctx.beginPath(); ctx.moveTo(G.cx - 9, y + 7); ctx.lineTo(G.cx, y); ctx.lineTo(G.cx + 9, y + 7); ctx.stroke(); }
        } else hint(a.aim.cancel ? '여기서 놓으면 취소' : '놓으면 캐스팅!', a.aim.cancel ? '#ee6a55' : '#5fd3a0', G.nearY - 18);
      } else if (live && a.ph === 'wait') {
        hint(hintFlash > 0 ? '너무 빨라요!' : '찌가 쑥 들어가면 탭! · 살짝 까딱이는 건 속임수', hintFlash > 0 ? '#ee6a55' : '#f2e9d8', hy);
      } else if (live && a.ph === 'fight') {
        const T = a.F.T, warn = a.F.nb - a.F.k > 0 && a.F.nb - a.F.k < 10 && a.F.k >= a.F.be;
        hint(T >= TRED - 0.04 ? '떼세요! 줄이 끊어져요' : warn ? '물고기가 힘을 써요!' : a.F.slack > 0.5 ? '줄이 느슨해요 · 눌러서 감기' : a.hold ? '감는 중 · 초록 칸 유지' : '꾹 누르면 감기 · 빨간색 가까우면 떼기',
          T >= TRED - 0.04 ? '#ee6a55' : warn ? '#e3ae45' : '#f2e9d8', hy);
      } else if (a && a.mode === 'replay' && a.ph !== 'card') {
        hint(pname(a.seat) + ' 낚시 중 · 탭하면 빨리 보기', '#ab9fb8', hy);
      } else if (!a && s.ph !== 'e') {
        const p = api.players[seat];
        if (p && !api.canAct(seat)) hint(p.name + (p.ai ? ' 채비 중…' : ' 차례'), '#ab9fb8', hy);
      }
      drawPops(dt);
      if (a && a.ph === 'card') drawCard(a);
    }
    function drawCard(a) {
      const r = a.res, got = r.out === 'L', W = Math.min(G.W - 40, 300), H = got ? 190 : 96, x = (G.W - W) / 2, y = Math.max(G.topH + 60, (G.H - H) / 2 - 30);
      const k = Math.min(1, a.ct / 0.18);
      ctx.save(); ctx.globalAlpha = k; ctx.translate(G.W / 2, y + H / 2); ctx.scale(0.92 + 0.08 * k, 0.92 + 0.08 * k); ctx.translate(-G.W / 2, -(y + H / 2));
      ctx.fillStyle = 'rgba(23,19,31,.94)'; rr(x, y, W, H, 16); ctx.fill();
      const rare = got && SP[r.sp].r >= 2;
      ctx.strokeStyle = rare ? '#e3ae45' : color(a.seat); ctx.lineWidth = 2; ctx.stroke();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (got) {
        const f = SP[r.sp];
        ctx.fillStyle = '#ab9fb8'; ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.fillText(pname(a.seat) + ' · ' + ZN[a.z] + ' · ' + TOD[a.td], G.W / 2, y + 18);
        if (r.sp === GOLD) { const gl = ctx.createRadialGradient(G.W / 2, y + 76, 0, G.W / 2, y + 76, 110); gl.addColorStop(0, 'rgba(255,220,120,.35)'); gl.addColorStop(1, 'rgba(255,220,120,0)'); ctx.fillStyle = gl; ctx.fillRect(x, y, W, H); }
        drawFish(ctx, G.W / 2, y + 76, Math.min(W - 60, 90 + Math.min(1, r.g / 6000) * 110), r.sp, r.sp === BOOT ? 0 : -0.06 + Math.sin(a.ct * 6) * 0.04 * Math.max(0, 1 - a.ct));
        ctx.font = '400 26px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = rare ? '#e3ae45' : '#f2e9d8'; ctx.fillText(f.n, G.W / 2, y + 128);
        ctx.font = '600 15px "IBM Plex Mono", monospace'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(r.sp === BOOT ? '점수 없음' : kg(r.g), G.W / 2, y + 154);
        const tag = RAR[f.r] + (a.dexNew ? ' · 도감 등록!' : a.newSp ? ' · 새 어종' : '');
        ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = f.r >= 2 ? '#e3ae45' : a.dexNew ? '#5fd3a0' : '#ab9fb8'; ctx.fillText(tag, G.W / 2, y + 176);
      } else {
        ctx.font = '400 24px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ee6a55'; ctx.fillText(OUTN[r.out] || '놓쳤어요', G.W / 2, y + 38);
        ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ab9fb8';
        const why = { e: '찌가 쑥 들어간 다음에 탭해야 해요', l: '찌가 들어가면 바로 탭!', S: '빨간색에 닿기 전에 손을 떼세요', E: '줄이 오래 느슨하면 바늘이 빠져요' }[r.out] || '';
        ctx.fillText(pname(a.seat) + ' · ' + why, G.W / 2, y + 68);
      }
      ctx.restore();
    }

    /* ---------- input ---------- */
    const el = cv.cv;
    let drag = null;
    function aimFrom(d) {
      const dx = d.x - d.sx, dy = d.y - d.sy, len = Math.sqrt(dx * dx + dy * dy);
      const reach = Math.max(160, (G.nearY - G.farY) * 1.05);
      const dist = clamp(len / reach, 0, 1) * MAXD, ang = clamp(Math.atan2(dx, -dy), -1.05, 1.05);
      const p = landAt(dist * Math.sin(ang), dist * Math.cos(ang));
      return { x: p.x, y: p.y, cancel: len < 28 || dy > -10 };
    }
    function onDown(ev) {
      if (!G || !st) return;
      if (creel) return;
      const p = cv.local(ev);
      try { el.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
      const a = anim;
      if (!a) return;
      if (a.mode === 'replay') { if (a.ph === 'card') { if (a.ct > 0.3) endAnim(); } else a.ff = true; return; }
      if (a.ph === 'aim') { drag = { id: ev.pointerId, sx: p.x, sy: p.y, x: p.x, y: p.y }; a.aim = aimFrom(drag); api.buzz(6); return; }
      if (a.ph === 'wait') {
        if (a.rec.h >= 0) return;
        const h = Math.round(a.t * 1000);
        a.rec.h = h;
        const hk = hookOf(a.b, a.fish.win, h);
        if (!hk.ok) { hintFlash = 1; pop(OUTN[hk.why], '#ee6a55'); api.buzz(30); finishLive(a, hk.why); return; }
        a.hk = hk; a.F = newFight(a.fish, a.sd, a.D0, hk.q); a.ph = 'fight'; a.acc = 0;
        ptrs.add(ev.pointerId); // keeping the finger down starts reeling right away
        api.sfx('whoosh'); api.buzz(25); pop(hk.q > 0.65 ? '완벽한 챔질!' : '챔질!', '#5fd3a0', 0.9);
        return;
      }
      if (a.ph === 'fight') { ptrs.add(ev.pointerId); api.buzz(5); return; }
      if (a.ph === 'card' && a.ct > 0.4 && a.ack) endAnim();
    }
    function onMove(ev) {
      if (!drag || ev.pointerId !== drag.id || !anim || anim.ph !== 'aim') return;
      const p = cv.local(ev); drag.x = p.x; drag.y = p.y;
      const prev = anim.aim; anim.aim = aimFrom(drag);
      if (prev && prev.cancel !== anim.aim.cancel) api.buzz(5);
    }
    function onUp(ev) {
      ptrs.delete(ev.pointerId);
      if (!drag || ev.pointerId !== drag.id) return;
      const d = drag; drag = null;
      const a = anim;
      if (!a || a.mode !== 'live' || a.ph !== 'aim') return;
      const aim = aimFrom(d); a.aim = null;
      if (ev.type === 'pointercancel' || aim.cancel) { if (Math.hypot(d.x - d.sx, d.y - d.sy) < 12) hintFlash = 1.2; api.sfx('click'); return; }
      a.rec.x = Math.round(aim.x * 10); a.rec.y = Math.round(aim.y * 10);
      prep(a, aim.x, aim.y);
      a.ph = 'cast'; a.t = 0;
      api.setBusy(true); api.sfx('whoosh'); api.buzz(14);
    }
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);
    el.addEventListener('lostpointercapture', onUp);
    cv.onresize = () => layout();
    layout();

    return {
      _dbg: () => ({ anim, G, st, SX, SY }),
      update(next, prev) {
        st = next;
        const l = next.last;
        if (l && prev && prev !== next && (!prev.last || prev.last.id !== l.id)) {
          if (myPend && l.id === myPend.seq + 1 && l.s === myPend.seat && anim && anim.mode === 'live') {
            anim.ack = true; myPend = null; clearTimeout(waitTimer);
            waitTimer = setTimeout(() => { if (anim && anim.ack) endAnim(); }, 6000);
          } else {
            anim = null; myPend = null;
            startReplay(l, prev);
          }
        } else if (anim && anim.mode === 'live' && anim.ph === 'aim' && (!humanTurn() || anim.seq !== next.seq)) {
          anim = null;
        }
        if (creel && next.ph === 'e') { creel.remove(); creel = null; }
        hudKey = ''; renderTop(anim && anim.ph !== 'card' ? anim.snap : anim && anim.ph === 'card' && anim.mode === 'replay' ? next : anim ? anim.snap : next, anim ? anim.seat : actor(next));
      },
      destroy() {
        stopLoop(); clearTimeout(waitTimer);
        el.removeEventListener('pointerdown', onDown); el.removeEventListener('pointermove', onMove);
        el.removeEventListener('pointerup', onUp); el.removeEventListener('pointercancel', onUp); el.removeEventListener('lostpointercapture', onUp);
        if (creel) creel.remove();
        cv.destroy(); top.remove(); creelBtn.remove(); [spLake, spCast, spGauge].forEach((f) => f.el.remove());
        api.setBusy(false);
      },
    };
  }

  L.register({
    id: 'fishing', name: '낚시 대결', tag: '찌낚시 · 손맛', cat: '스포츠',
    blurb: '위로 밀어 던질 곳을 고르고, 찌가 쑥 들어가면 탭해 챔질! 눌러서 감고 장력이 빨개지기 전에 떼며 물고기를 끌어내요. 정해진 횟수를 던져 총 무게(또는 가장 큰 한 마리)로 겨뤄요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 500,
    tint: '#1d4a5a',
    icon: '<path d="M12 6C26 10 38 20 44 40" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M44 40v6" stroke="currentColor" stroke-width="1.5"/><ellipse cx="44" cy="49" rx="3" ry="4" fill="currentColor"/><path d="M8 46c6-6 14-6 20 0-6 6-14 6-20 0z" fill="currentColor"/><path d="M8 46l-5-4v8z" fill="currentColor"/><path d="M32 52c4 2 10 2 14 0" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" opacity=".6"/>',
    options: [
      { id: 'casts', label: '던지기 횟수', choices: [{ v: 5, label: '5번씩' }, { v: 8, label: '8번씩' }], def: 5 },
      { id: 'win', label: '승부', choices: [{ v: 'total', label: '총 무게' }, { v: 'big', label: '가장 큰 한 마리' }], def: 'total' },
    ],
    quick: [
      '한 사람씩 번갈아 낚싯대를 던져요. 정해진 횟수(5번 또는 8번)를 던진 뒤 총 무게가 가장 무거운 사람이 이겨요.',
      '내 차례: 위로 밀어 던지고 → 찌가 쑥 들어가면 탭(챔질) → 꾹 눌러 감고, 장력이 빨개지면 떼요.',
      '줄이 너무 팽팽하면 끊어지고, 너무 느슨하면 바늘이 빠져요. 오른쪽 장력 막대를 초록 칸에!',
    ],
    rules: [
      { h: '목표', p: ['연못에서 물고기를 낚아 무게로 겨뤄요.',
        '총 무게(기본): 낚은 물고기 무게를 모두 더해 가장 무거운 사람이 이겨요(같으면 가장 큰 한 마리로).',
        '가장 큰 한 마리(옵션): 제일 무거운 한 마리로 겨뤄요(같으면 총 무게로). 그래도 같으면 공동 우승.'] },
      { h: '차례에 할 일', p: ['① 한 사람씩 번갈아 한 번씩 던져요. 모두 5번(또는 8번) 던지면 끝.',
        '② 한 번 던질 때: 던지기 → 입질 기다리기 → 챔질(탭) → 끌어내기. 낚든 놓치든 다음 사람 차례예요.',
        '시간대는 한 바퀴마다 새벽 → 낮 → 저녁 → 밤으로 바뀌고, 시간대마다 잘 무는 물고기가 달라요(메기는 밤, 배스는 새벽·저녁).'] },
      { h: '조작 ① 던지기', p: ['① 화면에 손가락을 대고 위로 밀어 올리세요.',
        '② 미는 길이가 거리(최대 42m), 기울기가 방향이에요.',
        '③ 떨어질 곳과 구역 이름, 그 구역에 사는 어종이 미리 보여요(낚아 본 어종만 이름이 보여요).',
        '④ 손가락을 떼면 던져요. 처음 자리로 돌아와 떼면 취소.'] },
      { h: '조작 ② 챔질', p: ['찌가 살짝 까딱이는 건 입질 흉내예요. 아직 누르지 마세요.',
        '찌가 쑥 들어가서 물결이 퍼질 때 화면을 탭하세요.',
        '그 전에 탭하면 너무 빨라서, 찌가 다시 떠오르면 너무 늦어서 놓쳐요.',
        '찌가 들어가자마자 빨리 탭할수록 바늘이 단단히 걸려서, 줄이 느슨해도 더 오래 버텨요.'] },
      { h: '조작 ③ 끌어내기', p: ['화면을 누르고 있으면 릴을 감아 물고기가 다가오고, 떼면 줄이 풀려요.',
        '오른쪽 장력 막대를 초록 칸에 두면 물고기가 빨리 지쳐요.',
        '물고기는 가끔 힘을 써요(물고기 위 「!」). 노란 「!」가 뜨면 곧 당겨요. 그때는 손을 떼서 줄을 풀어 주세요.',
        '장력이 맨 위 빨간색 끝에 닿으면 줄이 끊어져요 — 빨개지면 손을 떼세요.',
        '줄이 너무 오래 느슨하면(장력 막대가 바닥) 바늘이 빠져 놓쳐요. 물고기가 너무 멀리(60m) 달아나도 줄이 끊어져요. 40초 안에 못 끌어내도 놓쳐요.'] },
      { h: '구역과 물고기', p: ['얕은 물가: 붕어·피라미·블루길.', '수초·연잎: 배스·가물치·붕어.', '깊은 곳: 잉어·메기. 아주 드물게 황금 잉어가 나와요.', '바위 여울: 송어·쏘가리.',
        '가끔 낡은 장화도 걸려요(점수 없음).'] },
      { h: '예시', p: ['저녁에 수초 쪽으로 30m 던짐 → 찌가 두 번 까딱(기다림) → 쑥 들어감 → 바로 탭! 배스가 걸렸어요.',
        '→ 꾹 눌러 감다가 장력이 노랗게 올라가면 잠깐 떼고, 초록 칸으로 내려오면 다시 감기.',
        '→ 노란 「!」가 뜸 → 손을 떼서 버팀 → 물고기가 지치면 다시 감아서 끌어냄. 1.2kg 배스 획득!'] },
      { h: '공정성·다시보기', p: ['어종·무게·입질·물고기의 힘 쓰기는 판 안의 시드와 던진 구역·시간대로 정해져서 모든 기기에서 똑같아요. 낚는 기기는 던진 곳·챔질 시각·누름/뗌 기록만 보내고, 결과는 같은 계산으로 다시 정해요.',
        '다른 사람의 낚시는 다시보기로 보여 줘요. 탭하면 빨리 감아요. 왼쪽 아래 「어망」에서 모두의 물고기와 어종 도감을 볼 수 있어요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(던질 곳 고르기, 챔질 반응, 장력 다루는 솜씨가 달라요).'] },
    ],
    tutorial: [
      { sel: '.fi-lake', text: '연못에서 물고기를 낚아요. 한 사람씩 번갈아 던지고, 정해진 횟수를 던진 뒤 총 무게가 가장 무거운 사람이 이겨요.' },
      { sel: '.fi-cast', text: '① 던지기: 화면에 손가락을 대고 위로 밀어 올려요. 미는 길이 = 거리, 기울기 = 방향. 떨어질 곳과 사는 어종이 미리 보여요. 떼면 던져요.' },
      { sel: '.fi-lake', text: '구역마다 물고기가 달라요: 얕은 물가 · 수초 · 깊은 곳 · 바위 여울. 깊은 곳엔 큰 잉어·메기, 아주 드물게 황금 잉어도!' },
      { sel: '.fi-lake', text: '② 챔질: 찌가 살짝 까딱이는 건 속임수예요. 찌가 쑥 들어가서 물결이 퍼질 때 바로 탭! 빨리 탭할수록 단단히 걸려요.' },
      { sel: '.fi-gauge', text: '③ 끌어내기: 꾹 누르면 감고, 떼면 풀려요. 이때 여기에 장력 막대가 나와요. 초록 칸을 지키고, 빨개지면 바로 손을 떼세요(줄이 끊어져요)!' },
      { sel: '.fi-creel', text: '「어망」을 누르면 낚은 물고기와 어종 도감을 볼 수 있어요. 그럼 던져 볼까요?' },
    ],
    init, actor, apply, ai, result, mount,
    aiDelayFor() { return 500; },
    _t: { SP, TOD, landAt, zoneOf, inWater, fishOf, biteOf, hookOf, newFight, fstep, fight, judge, encF, decF, aiPlay, LVF, EV, total, biggest, winners, mb, FMAX, MAXTG, BOOT, GOLD },
  });
})();
