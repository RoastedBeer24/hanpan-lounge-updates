/* 조각 영역 차지 — 1~5칸 조각 21개를 꼭짓점끼리만 이어 붙이며 판을 차지하는 배치 전략. 20×20(4색, 모서리 시작) / 듀오 14×14(판 안쪽 시작점 (5,5)·(10,10)), 자리별 AI. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------------- pieces: the 21 free polyominoes of size 1–5 ---------------- */
  const PIECES = [
    [[0, 0]],                                   // 0  1칸
    [[0, 0], [1, 0]],                           // 1  2칸
    [[0, 0], [1, 0], [2, 0]],                   // 2  3칸 일자
    [[0, 0], [1, 0], [0, 1]],                   // 3  3칸 꺾임
    [[0, 0], [1, 0], [2, 0], [3, 0]],           // 4  4칸 일자
    [[0, 0], [1, 0], [0, 1], [1, 1]],           // 5  네모
    [[0, 0], [1, 0], [2, 0], [1, 1]],           // 6  ㅗ
    [[0, 0], [0, 1], [0, 2], [1, 2]],           // 7  ㄴ
    [[1, 0], [2, 0], [0, 1], [1, 1]],           // 8  번개
    [[1, 0], [2, 0], [0, 1], [1, 1], [1, 2]],   // 9  5칸들…
    [[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]],   // 10
    [[0, 0], [0, 1], [0, 2], [0, 3], [1, 3]],   // 11
    [[0, 0], [0, 1], [1, 1], [1, 2], [1, 3]],   // 12
    [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2]],   // 13
    [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2]],   // 14
    [[0, 0], [2, 0], [0, 1], [1, 1], [2, 1]],   // 15
    [[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]],   // 16
    [[0, 0], [0, 1], [1, 1], [1, 2], [2, 2]],   // 17
    [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]],   // 18
    [[1, 0], [0, 1], [1, 1], [1, 2], [1, 3]],   // 19
    [[0, 0], [1, 0], [1, 1], [1, 2], [2, 2]],   // 20
  ];
  const NP = PIECES.length;           // 21
  const ALL = (1 << NP) - 1;
  const SIZE = PIECES.map((c) => c.length);
  const TOTAL = SIZE.reduce((a, b) => a + b, 0); // 89
  const UNDO_MAX = 5;

  /* every distinct orientation (rotations × mirror), normalised to the top-left */
  function normCells(cells) {
    const mx = Math.min(...cells.map((c) => c[0])), my = Math.min(...cells.map((c) => c[1]));
    return cells.map(([x, y]) => [x - mx, y - my]).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  }
  const keyOf = (cells) => cells.map((c) => c.join(',')).join(';');
  const ORI = [], ORIS = [];
  PIECES.forEach((base, p) => {
    const list = [], seen = new Set();
    for (let f = 0; f < 2; f++) {
      let cur = base.map(([x, y]) => (f ? [-x, y] : [x, y]));
      for (let r = 0; r < 4; r++) {
        const n = normCells(cur), k = keyOf(n);
        if (!seen.has(k)) {
          seen.add(k);
          const w = Math.max(...n.map((c) => c[0])) + 1, h = Math.max(...n.map((c) => c[1])) + 1;
          list.push(ORI.length);
          ORI.push({ p, c: n, w, h, k });
        }
        cur = cur.map(([x, y]) => [-y, x]); // 90° clockwise
      }
    }
    ORIS.push(list);
  });
  const NO = ORI.length; // 91
  function findOri(p, cells) { const k = keyOf(normCells(cells)); return ORIS[p].find((o) => ORI[o].k === k); }
  const ROT = ORI.map((o) => findOri(o.p, o.c.map(([x, y]) => [-y, x])));
  const FLIP = ORI.map((o) => findOri(o.p, o.c.map(([x, y]) => [-x, y])));

  /* ---------------- board engine (padded board, border = 255) ---------------- */
  const GEO = {};
  function geo(B) {
    if (GEO[B]) return GEO[B];
    const W = B + 2;
    const off = ORI.map((o) => Int16Array.from(o.c.map(([x, y]) => y * W + x)));
    // colour starting corners, clockwise from bottom-left
    const BL = [0, B - 1], TL = [0, 0], TR = [B - 1, 0], BR = [B - 1, B - 1];
    return (GEO[B] = { B, W, off, corners: { 4: [BL, TL, TR, BR], 3: [BL, TL, TR] } });
  }
  // duo (14×14, one colour each): the original inner starting points (5,5) and (10,10), 0-based (4,4) and (9,9)
  const DUO_START = [[4, 4], [9, 9]];
  const isDuo = (s) => s.nc === 2;
  const pid = (W, x, y) => (y + 1) * W + x + 1;
  function boardOf(s) {
    const g = geo(s.v), W = g.W, bd = new Uint8Array(W * W).fill(255);
    for (let y = 0; y < s.v; y++) for (let x = 0; x < s.v; x++) { const ch = s.b.charCodeAt(y * s.v + x); bd[pid(W, x, y)] = ch === 46 ? 0 : ch - 47; }
    return bd;
  }
  function boardStr(bd, B) {
    const W = B + 2; let o = '';
    for (let y = 0; y < B; y++) for (let x = 0; x < B; x++) { const v = bd[pid(W, x, y)]; o += v ? String(v - 1) : '.'; }
    return o;
  }
  const startOf = (s, k) => (isDuo(s) ? DUO_START[k] : geo(s.v).corners[s.nc][k]);
  const startWord = (s) => (isDuo(s) ? '시작점' : '시작 모서리');
  const owner = (s, k) => k % s.n;
  const isFirst = (s, k) => s.r[k] === ALL;
  const pack = (o, x, y) => (o << 10) | (y << 5) | x;
  const unO = (m) => m >> 10, unY = (m) => (m >> 5) & 31, unX = (m) => m & 31;
  function remSquares(r) { let t = 0; for (let p = 0; p < NP; p++) if (r & (1 << p)) t += SIZE[p]; return t; }

  /* forbidden cells for colour value v: occupied, border, or edge-adjacent to v */
  function forb(bd, W, v, F) {
    for (let i = 0; i < bd.length; i++) {
      if (bd[i]) { F[i] = 1; continue; }
      F[i] = bd[i - 1] === v || bd[i + 1] === v || bd[i - W] === v || bd[i + W] === v ? 1 : 0;
    }
    return F;
  }
  const diagOwn = (bd, W, i, v) => bd[i - W - 1] === v || bd[i - W + 1] === v || bd[i + W - 1] === v || bd[i + W + 1] === v;
  function cellCorner(bd, W, i, v) {
    return bd[i] === 0 && bd[i - 1] !== v && bd[i + 1] !== v && bd[i - W] !== v && bd[i + W] !== v && diagOwn(bd, W, i, v);
  }
  /* corner cells (padded ids) where colour k may start a new piece */
  function cornersOf(bd, B, k, F) {
    const W = B + 2, v = k + 1, out = [];
    for (let y = 0; y < B; y++) for (let x = 0; x < B; x++) { const i = pid(W, x, y); if (!F[i] && diagOwn(bd, W, i, v)) out.push(i); }
    return out;
  }
  /* all legal placements of colour k: {n, mv: packed (o,x,y), cn: corner cell each move was found from} */
  const STAMP = new Int32Array(NO << 10); let stampGen = 1;
  const FBUF = new Uint8Array(22 * 22);
  function gen(bd, B, k, rem, first, start, early) {
    const g = geo(B), W = g.W, F = forb(bd, W, k + 1, FBUF.subarray(0, W * W));
    const cs = first ? [] : cornersOf(bd, B, k, F);
    if (first && start != null && !F[start]) cs.push(start);
    if (++stampGen > 2e9) { STAMP.fill(0); stampGen = 1; }
    const mv = [], cn = [];
    for (const c of cs) {
      const cx = (c % W) - 1, cy = ((c / W) | 0) - 1;
      for (let p = 0; p < NP; p++) {
        if (!(rem & (1 << p))) continue;
        for (const o of ORIS[p]) {
          const O = ORI[o], off = g.off[o];
          for (let q = 0; q < O.c.length; q++) {
            const x = cx - O.c[q][0], y = cy - O.c[q][1];
            if (x < 0 || y < 0 || x + O.w > B || y + O.h > B) continue;
            const key = (o << 10) | (y << 5) | x;
            if (STAMP[key] === stampGen) continue;
            const base = pid(W, x, y);
            let ok = true;
            for (let j = 0; j < off.length; j++) if (F[base + off[j]]) { ok = false; break; }
            if (!ok) continue;
            STAMP[key] = stampGen;
            mv.push(key); cn.push(c);
            if (early) return { n: 1, mv, cn };
          }
        }
      }
    }
    return { n: mv.length, mv, cn };
  }
  function movesFor(s, bd, k, early) {
    const [x, y] = startOf(s, k);
    return gen(bd, s.v, k, s.r[k], isFirst(s, k), pid(geo(s.v).W, x, y), early);
  }
  const hasMove = (s, bd, k) => movesFor(s, bd, k, true).n > 0;

  /* why a placement is not allowed ('' = fine) */
  function reason(s, bd, k, o, x, y) {
    const O = ORI[o], B = s.v, W = B + 2, v = k + 1;
    if (!O) return '알 수 없는 조각이에요';
    if (!(s.r[k] & (1 << O.p))) return '이미 놓은 조각이에요';
    if (x < 0 || y < 0 || x + O.w > B || y + O.h > B) return '판 밖으로 나가요';
    const base = pid(W, x, y), off = geo(B).off[o];
    let corner = false;
    for (const d of off) if (bd[base + d]) return '다른 조각과 겹쳐요';
    for (const d of off) { const i = base + d; if (bd[i - 1] === v || bd[i + 1] === v || bd[i - W] === v || bd[i + W] === v) return '같은 색 조각과 변이 맞닿아요'; }
    if (isFirst(s, k)) {
      const [sx, sy] = startOf(s, k), si = pid(W, sx, sy);
      for (const d of off) if (base + d === si) return '';
      return '첫 조각은 ' + startWord(s) + ' 칸을 덮어야 해요';
    }
    for (const d of off) if (diagOwn(bd, W, base + d, v)) corner = true;
    return corner ? '' : '같은 색 조각과 꼭짓점으로 이어져야 해요';
  }

  /* ---------------- state ---------------- */
  function init(players, opts) {
    opts = opts || {};
    const n = U.clamp(players.length, 2, 4);
    const v = n === 2 && opts.bd === 20 ? 20 : n === 2 ? 14 : 20;
    const nc = n === 2 && v === 20 ? 4 : n;
    const hum = players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0);
    return {
      v, n, nc, b: '.'.repeat(v * v), r: Array(nc).fill(ALL), m: Array(nc).fill(0), d: Array(nc).fill(0), c: 0, seq: 0,
      nm: players.map((p, i) => String(p.name || (i + 1) + '번').slice(0, 10)),
      h: hum.length === 1 ? hum[0] : -1, u: [], last: null, ev: null, st: null,
    };
  }
  function actor(s) { return s.st ? null : owner(s, s.c); }
  function advance(s, bd) {
    const live = [];
    for (let k = 0; k < s.nc; k++) if (!s.d[k]) live.push(k);
    if (!live.length) { s.st = { r: 'end' }; return; }
    // nobody can place any more → the game ends right away
    const can = live.filter((k) => hasMove(s, bd, k));
    if (!can.length) { live.forEach((k) => { s.d[k] = 1; }); s.st = { r: 'end' }; return; }
    for (let i = 1; i <= s.nc; i++) { const k = (s.c + i) % s.nc; if (!s.d[k]) { s.c = k; break; } }
    if (s.h >= 0 && !live.some((k) => owner(s, k) === s.h)) s.u = [];
  }
  function apply(s, seat, a) {
    if (s.st) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a) throw new Error('bad action');
    const k = s.c;
    if (a.t === 'u') {
      if (seat !== s.h || !s.u.length) throw new Error('nothing to undo');
      const e = s.u.pop(), bd = boardOf(s), W = s.v + 2;
      for (let i = e.mv.length - 1; i >= 0; i--) {
        const q = e.mv[i], kk = q >> 17, o = (q >> 10) & 127, y = (q >> 5) & 31, x = q & 31;
        const base = pid(W, x, y);
        for (const d of geo(s.v).off[o]) bd[base + d] = 0;
        s.r[kk] |= 1 << ORI[o].p;
      }
      s.b = boardStr(bd, s.v); s.c = e.c; s.d = e.d.split('').map(Number); s.m = e.m.split('').map(Number);
      s.seq++; s.last = null; s.ev = { id: s.seq, k: 'u' };
      return s;
    }
    const bd = boardOf(s);
    if (a.t === 'p') {
      const o = a.o | 0, x = a.x | 0, y = a.y | 0;
      if (!(o >= 0 && o < NO)) throw new Error('bad piece');
      const why = reason(s, bd, k, o, x, y);
      if (why) throw new Error(why);
      if (seat === s.h) pushUndo(s);
      const W = s.v + 2, base = pid(W, x, y);
      for (const d of geo(s.v).off[o]) bd[base + d] = k + 1;
      const p = ORI[o].p;
      s.r[k] &= ~(1 << p);
      s.m[k] = p === 0 ? 1 : 0;
      if (s.u.length) s.u[s.u.length - 1].mv.push((k << 17) | pack(o, x, y));
      s.b = boardStr(bd, s.v);
      s.seq++;
      s.last = { id: s.seq, k, o, x, y };
      s.ev = null;
      if (!s.r[k]) { s.d[k] = 2; s.ev = { id: s.seq, k: 'a', c: k }; }
    } else if (a.t === 's') {
      if (hasMove(s, bd, k)) throw new Error('can still place');
      if (seat === s.h) pushUndo(s);
      s.d[k] = 1;
      s.seq++;
      s.last = { id: s.seq, k, ps: 1 };
      s.ev = { id: s.seq, k: 'p', c: k };
    } else throw new Error('bad action');
    advance(s, bd);
    if (s.st) s.u = [];
    while (JSON.stringify(s).length > 2400 && s.u.length) s.u.shift();
    return s;
  }
  function pushUndo(s) {
    s.u.push({ c: s.c, d: s.d.join(''), m: s.m.join(''), mv: [] });
    if (s.u.length > UNDO_MAX) s.u.shift();
  }
  /* per-seat score: −1 per remaining square, +15 for placing all 21, +5 more if the last one was the 1-square piece */
  function colorScore(s, k) { return s.r[k] ? -remSquares(s.r[k]) : 15 + (s.m[k] ? 5 : 0); }
  function scores(s) { const t = Array(s.n).fill(0); for (let k = 0; k < s.nc; k++) t[owner(s, k)] += colorScore(s, k); return t; }
  function result(s) {
    if (!s.st) return null;
    const sc = scores(s), best = Math.max(...sc);
    const winners = sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    const order = sc.map((v, i) => i).sort((a, b) => sc[b] - sc[a]);
    const lines = order.map((i) => {
      const ks = []; for (let k = 0; k < s.nc; k++) if (owner(s, k) === i) ks.push(k);
      const left = ks.reduce((t, k) => t + remSquares(s.r[k]), 0);
      const bonus = ks.filter((k) => !s.r[k]).map((k) => (s.m[k] ? '+20' : '+15'));
      return s.nm[i] + ' · ' + (sc[i] > 0 ? '+' : '') + sc[i] + '점 (남은 ' + left + '칸' + (bonus.length ? ', 다 놓음 ' + bonus.join(' ') : '') + ')';
    });
    return { winners, title: winners.length > 1 ? '공동 1위' : undefined, text: lines.join('\n') };
  }

  /* ---------------- AI ---------------- */
  const REG = new Int32Array(22 * 22); let regGen = 1;
  /* quick features of one placement: size, own corner delta, enemy/ally corners covered */
  function quick(s, bd, k, m) {
    const W = s.v + 2, v = k + 1, o = unO(m), base = pid(W, unX(m), unY(m)), off = geo(s.v).off[o];
    regGen++;
    const reg = [];
    for (const d of off) {
      const c = base + d;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const i = c + dy * W + dx; if (bd[i] !== 255 && REG[i] !== regGen) { REG[i] = regGen; reg.push(i); } }
    }
    let before = 0, after = 0, hurt = 0, help = 0;
    for (const i of reg) if (cellCorner(bd, W, i, v)) before++;
    for (const d of off) {
      const c = base + d;
      for (let j = 0; j < s.nc; j++) if (j !== k && !s.d[j] && cellCorner(bd, W, c, j + 1)) { if (owner(s, j) === owner(s, k)) help++; else hurt++; }
    }
    for (const d of off) bd[base + d] = v;
    for (const i of reg) if (cellCorner(bd, W, i, v)) after++;
    for (const d of off) bd[base + d] = 0;
    return { sz: off.length, dc: after - before, hurt, help, p: ORI[o].p };
  }
  function placedCount(s, k) { return TOTAL - remSquares(s.r[k]); }
  function centerGain(s, m) {
    const O = ORI[unO(m)], cx = unX(m) + O.w / 2, cy = unY(m) + O.h / 2, h = s.v / 2;
    return h - Math.max(Math.abs(cx - h), Math.abs(cy - h));
  }
  function greedyScore(s, bd, k, m, noise) {
    const f = quick(s, bd, k, m);
    const early = placedCount(s, k) < 22;
    let sc = f.sz * 1.0 + f.dc * 0.55 + f.hurt * 0.5 - f.help * 0.4;
    if (early) sc += centerGain(s, m) * 0.12;
    if (isDuo(s) && isFirst(s, k)) sc += duoOpening(s, k, m, f);
    if (f.p === 0 && s.r[k] !== 1) sc -= 1.2; // keep the single square for the end
    return sc + Math.random() * (noise || 0);
  }
  /* duo opening (first piece around the inner starting point): a big, bushy piece that reaches out toward the
     opponent's side (the middle of the board) and opens corners there, not one that hugs the own back corner */
  function duoOpening(s, k, m, f) {
    const O = ORI[unO(m)], [ox, oy] = DUO_START[1 - k], [sx, sy] = DUO_START[k];
    const cx = unX(m) + (O.w - 1) / 2, cy = unY(m) + (O.h - 1) / 2;
    const d0 = Math.max(Math.abs(sx - ox), Math.abs(sy - oy)), d1 = Math.max(Math.abs(cx - ox), Math.abs(cy - oy));
    let sc = (d0 - d1) * 0.9 + f.sz * 0.6 + f.dc * 0.25;
    if (f.p === 10) sc -= 2.5;             // the long 5-straight is wasted as an opener
    if (Math.min(O.w, O.h) < 2) sc -= 0.8; // flat pieces open few useful corners
    return sc;
  }
  /* territory: multi-source BFS (8-neighbourhood) from each colour's corners through cells it may use */
  const DIST = [0, 1, 2, 3].map(() => new Int8Array(22 * 22)), FQ = new Int16Array(22 * 22), FF = new Uint8Array(22 * 22);
  function evalBoard(s, bd, me) {
    const B = s.v, W = B + 2, N = W * W, D8 = [-W - 1, -W, -W + 1, -1, 1, W - 1, W, W + 1];
    const val = Array(s.nc).fill(0);
    for (let k = 0; k < s.nc; k++) {
      const dist = DIST[k]; dist.fill(-1);
      const r = s.r[k];
      val[k] = r ? -remSquares(r) : 15 + (s.m[k] ? 5 : 0);
      if (s.d[k] || !r) continue;
      const F = forb(bd, W, k + 1, FF.subarray(0, N));
      let h = 0, t = 0, corners = 0;
      if (isFirst(s, k)) { const [sx, sy] = startOf(s, k), i = pid(W, sx, sy); if (!F[i]) { dist[i] = 0; FQ[t++] = i; corners = 3; } }
      else for (let y = 0; y < B; y++) for (let x = 0; x < B; x++) { const i = pid(W, x, y); if (!F[i] && diagOwn(bd, W, i, k + 1)) { dist[i] = 0; FQ[t++] = i; corners++; } }
      while (h < t) {
        const c = FQ[h++]; if (dist[c] >= 5) continue;
        for (const d of D8) { const nx = c + d; if (!F[nx] && dist[nx] < 0) { dist[nx] = dist[c] + 1; FQ[t++] = nx; } }
      }
      val[k] += Math.min(corners, 18) * 0.32 + (corners ? 0 : -4);
    }
    // a cell belongs to the colour that reaches it strictly first
    const terr = Array(s.nc).fill(0);
    for (let i = 0; i < N; i++) {
      let best = 99, who = -1;
      for (let k = 0; k < s.nc; k++) { const d = DIST[k][i]; if (d < 0) continue; if (d < best) { best = d; who = k; } else if (d === best) who = -2; }
      if (who >= 0) terr[who]++;
    }
    let ally = 0, enemy = 0, na = 0, ne = 0;
    for (let k = 0; k < s.nc; k++) {
      const v = val[k] + terr[k] * 0.09;
      if (owner(s, k) === owner(s, me)) { ally += v; na++; } else { enemy += v; ne++; }
    }
    return ally - enemy * (na / ne) * 0.85;
  }
  function placeOn(bd, s, k, m, v) { const W = s.v + 2, base = pid(W, unX(m), unY(m)); for (const d of geo(s.v).off[unO(m)]) bd[base + d] = v; }
  /* temporarily apply a placement to the light state used by evalBoard */
  function withMove(s, bd, k, m, fn) {
    const p = ORI[unO(m)].p, r0 = s.r[k], m0 = s.m[k];
    placeOn(bd, s, k, m, k + 1); s.r[k] &= ~(1 << p); s.m[k] = p === 0 ? 1 : 0;
    const out = fn();
    placeOn(bd, s, k, m, 0); s.r[k] = r0; s.m[k] = m0;
    return out;
  }
  const HP = { k: 28, r: 3, a: 0.3, g: 0.15, tr: 240, t: 330 };
  function act(m) { return { t: 'p', o: unO(m), x: unX(m), y: unY(m) }; }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const k = s.c, bd = boardOf(s);
    const M = movesFor(s, bd, k);
    if (!M.n) return { t: 's' };
    if (lv === 1) { // random placement, big pieces favoured
      const w = M.mv.map((m) => Math.pow(SIZE[ORI[unO(m)].p], 2.2));
      let tot = w.reduce((a, b) => a + b, 0), x = Math.random() * tot;
      for (let i = 0; i < M.n; i++) { x -= w[i]; if (x <= 0) return act(M.mv[i]); }
      return act(M.mv[M.n - 1]);
    }
    if (lv === 2) {
      let best = M.mv[0], bs = -1e9;
      for (const m of M.mv) { const v = greedyScore(s, bd, k, m, 0.6); if (v > bs) { bs = v; best = m; } }
      return act(best);
    }
    // 어려움: greedy shortlist → board evaluation (territory, corner mobility, blocking) → next enemy's greedy reply
    const t0 = Date.now();
    const sc = M.mv.map((m) => ({ m, g: greedyScore(s, bd, k, m, 0.05) })).sort((a, b) => b.g - a.g);
    const top = sc.slice(0, HP.k);
    let nk = -1;
    for (let i = 1; i < s.nc; i++) { const j = (k + i) % s.nc; if (!s.d[j]) { nk = j; break; } }
    const enemyNext = nk >= 0 && owner(s, nk) !== owner(s, k);
    let best = top[0].m, bs = -1e9;
    for (const c of top) {
      const v = withMove(s, bd, k, c.m, () => {
        let e = evalBoard(s, bd, k);
        if (enemyNext && Date.now() - t0 < HP.tr) {
          const R = movesFor(s, bd, nk);
          if (R.n) {
            // the next enemy answers with the reply (among its greedy favourites) that hurts us most
            const step = R.n > 900 ? 3 : R.n > 400 ? 2 : 1, rs = [];
            for (let i = 0; i < R.n; i += step) rs.push({ m: R.mv[i], g: greedyScore(s, bd, nk, R.mv[i], 0) });
            rs.sort((a, b) => b.g - a.g);
            let worst = 1e9;
            for (const r of rs.slice(0, HP.r)) { const v2 = withMove(s, bd, nk, r.m, () => evalBoard(s, bd, k)); if (v2 < worst) worst = v2; }
            e = e * HP.a + worst * (1 - HP.a);
          }
        }
        return e;
      });
      const tot = v + c.g * HP.g - (ORI[unO(c.m)].p === 0 && s.r[k] !== 1 ? 2 : 0);
      if (tot > bs) { bs = tot; best = c.m; }
      if (Date.now() - t0 > HP.t) break;
    }
    return act(best);
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 650 : lv === 3 ? 260 : 420; }

  /* ---------------- view ---------------- */
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif';
  const CNAME = ['빨강', '파랑', '노랑', '초록'];
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  function rr(x, a, b, w, h, r) { x.beginPath(); if (x.roundRect) x.roundRect(a, b, w, h, r); else x.rect(a, b, w, h); }
  /* one enamel tile */
  function tile(ctx, x, y, s, col, alpha) {
    const g = Math.max(0.6, s * 0.05), r = Math.max(1.5, s * 0.16);
    ctx.save(); if (alpha != null) ctx.globalAlpha = alpha;
    ctx.fillStyle = shade(col, -0.45); rr(ctx, x + g, y + g, s - g * 2, s - g * 2, r); ctx.fill();
    const gr = ctx.createLinearGradient(x, y, x + s, y + s);
    gr.addColorStop(0, shade(col, 0.32)); gr.addColorStop(0.55, col); gr.addColorStop(1, shade(col, -0.18));
    ctx.fillStyle = gr; rr(ctx, x + g, y + g, s - g * 2, s - g * 2 - Math.max(1, s * 0.08), r); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.28)'; rr(ctx, x + s * 0.22, y + s * 0.2, s * 0.32, s * 0.12, s * 0.06); ctx.fill();
    ctx.restore();
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, bd = null, G = null, M = null, valid = new Set(), fits = new Set(), byCorner = new Map(), pieceOK = new Set();
    let selP = -1, gh = null, anchor = -1, cyc = { c: -1, i: 0 }, busy = false, anim = null, stopLoop = null, animTimer = 0;
    let waitSeq = -1, waitUntil = 0, view = { z: 1, ox: 0, oy: 0 }, ptrs = new Map(), bdrag = null, pinch = null, td = null;
    let showHint = U.store.get('blockclaim.hint', true);
    const BS = { minHeight: '44px', flex: '1 1 0', minWidth: 0, padding: '4px 2px', fontSize: '14px', whiteSpace: 'nowrap' };

    const top = L.h('div', { class: 'hud top bc-top', style: { gap: '5px', padding: '6px 8px', flexWrap: 'nowrap' } });
    const hint = L.h('div', { class: 'bc-hint', style: { position: 'absolute', left: '10px', right: '10px', height: '20px', lineHeight: '20px', textAlign: 'center', fontSize: '12.5px', fontWeight: 700, color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', pointerEvents: 'none' } });
    const tray = L.h('div', { class: 'bc-tray', 'aria-label': '내 조각', style: { position: 'absolute', left: '0', right: '0', height: '62px', display: 'flex', alignItems: 'center', gap: '6px', padding: '0 10px', overflowX: 'auto', overflowY: 'hidden', touchAction: 'pan-x', scrollbarWidth: 'none', WebkitOverflowScrolling: 'touch' } });
    const passBox = L.h('div', { class: 'panel', style: { position: 'absolute', left: '10px', right: '10px', display: 'none', alignItems: 'center', gap: '10px', padding: '8px 10px', zIndex: 3 } });
    const passMsg = L.h('div', { style: { flex: '1 1 auto', minWidth: 0, fontSize: '13px', fontWeight: 700, lineHeight: 1.3 } });
    const passBtn = L.h('button', { class: 'btn primary', style: { minHeight: '44px', flex: 'none' }, text: '차례 넘기기', onclick: onPass });
    passBox.append(passMsg, passBtn);
    const rotBtn = L.h('button', { class: 'btn sm ghost bc-rot', style: BS, text: '↻', 'aria-label': '조각 돌리기', onclick: () => turnPiece(ROT) });
    const flipBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '⇋', 'aria-label': '조각 뒤집기', onclick: () => turnPiece(FLIP) });
    const zoomBtn = L.h('button', { class: 'btn sm ghost', style: BS, 'aria-label': '판 확대', onclick: toggleZoom });
    const hintBtn = L.h('button', { class: 'btn sm ghost bc-spots', style: Object.assign({}, BS, { flex: '1.5 1 0', fontSize: '12.5px' }), onclick: toggleHint });
    const undoBtn = L.h('button', { class: 'btn sm ghost', style: BS, text: '↶', 'aria-label': '한 수 무르기', onclick: onUndo });
    const okBtn = L.h('button', { class: 'btn primary bc-ok', style: Object.assign({}, BS, { flex: '1.7 1 0' }), text: '놓기', onclick: commit });
    const bot = L.h('div', { class: 'hud bottom bc-bot', style: { gap: '5px', flexWrap: 'nowrap', padding: '8px 10px' } }, rotBtn, flipBtn, zoomBtn, hintBtn, undoBtn, okBtn);
    root.append(top, hint, tray, passBox, bot);
    // invisible boxes over canvas areas (board, my colour's start cell), for the first-play tutorial
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' });
    const spBoard = spot('bc-board'), spStart = spot('bc-start');
    function placeSpots() {
      place(spBoard, G.bx, G.by, G.size, G.size);
      let k = 0; for (let i = 0; i < st.nc; i++) if (api.canAct(owner(st, i))) { k = i; break; }
      const [x, y] = startOf(st, k), c = cs();
      place(spStart, cellX(x) - c, cellY(y) - c, c * 3, c * 3);
    }
    const vis = (el, on, disp) => { el.style.display = on ? (disp || '') : 'none'; };

    const colorOf = (k) => (st && st.nc === st.n && api.players[k] ? api.players[k].color : L.COLORS[k]);
    const name = (i) => (api.players[i] ? api.players[i].name : st.nm[i]);
    const cname = (k) => (st.nc === st.n ? name(k) : name(owner(st, k)) + '(' + CNAME[k] + ')');
    function myTurn() { return !!st && !st.st && api.canAct(owner(st, st.c)); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function canInput() { return myTurn() && !locked() && !anim; }
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }
    function canUndo() { return !api.online && !!st && !st.st && st.h >= 0 && owner(st, st.c) === st.h && api.canAct(st.h) && st.u.length > 0 && !anim && !locked(); }
    function hintLabel() { hintBtn.textContent = (showHint ? '● ' : '○ ') + '가능한 자리'; hintBtn.setAttribute('aria-pressed', String(showHint)); }
    function zoomLabel() { zoomBtn.textContent = view.z > 1.01 ? '⊖' : '⊕'; zoomBtn.setAttribute('aria-label', view.z > 1.01 ? '판 축소' : '판 확대'); }
    hintLabel(); zoomLabel();

    /* ----- layout ----- */
    function layout() {
      const W = cv.w, H = cv.h, topH = 52, botH = 60, trayH = 62, hintH = 22;
      const B = st ? st.v : 20;
      const availH = H - topH - botH - trayH - hintH - 10;
      const fr = 7;
      const cs = Math.max(8, Math.floor(Math.min(W - 12 - fr * 2, availH - fr * 2, 660) / B));
      const size = cs * B;
      const bx = Math.round((W - size) / 2), by = Math.round(topH + fr + Math.max(0, (availH - size - fr * 2) / 2));
      G = { cs0: cs, size, bx, by, fr };
      hint.style.top = Math.round(by + size + fr + 3) + 'px';
      tray.style.bottom = botH + 'px';
      passBox.style.bottom = (botH + 4) + 'px';
      clampView();
    }
    const cs = () => G.cs0 * view.z;
    function clampView() { if (!G) return; const ext = G.size * view.z - G.size; view.ox = U.clamp(view.ox, 0, ext); view.oy = U.clamp(view.oy, 0, ext); }
    const cellX = (x) => G.bx - view.ox + x * cs();
    const cellY = (y) => G.by - view.oy + y * cs();
    function cellAt(px, py) {
      if (px < G.bx || py < G.by || px >= G.bx + G.size || py >= G.by + G.size) return null;
      const x = Math.floor((px - G.bx + view.ox) / cs()), y = Math.floor((py - G.by + view.oy) / cs());
      return x >= 0 && y >= 0 && x < st.v && y < st.v ? [x, y] : null;
    }
    cv.onresize = () => { layout(); draw(); };

    /* ----- legal-move cache for the colour to move ----- */
    function refreshMoves() {
      valid = new Set(); fits = new Set(); byCorner = new Map(); pieceOK = new Set(); M = null;
      if (!st || st.st) return;
      M = movesFor(st, bd, st.c);
      for (let i = 0; i < M.n; i++) {
        const m = M.mv[i], p = ORI[unO(m)].p;
        valid.add(m); pieceOK.add(p);
        const c = M.cn[i];
        if (!byCorner.has(c)) byCorner.set(c, new Set());
        byCorner.get(c).add(p);
      }
    }
    function ghValid() { return !!gh && valid.has(pack(gh.o, gh.x, gh.y)); }
    function ghReason() { return gh ? reason(st, bd, st.c, gh.o, gh.x, gh.y) : ''; }
    function clampGh() {
      if (!gh) return;
      const O = ORI[gh.o];
      gh.x = U.clamp(gh.x, 0, st.v - O.w); gh.y = U.clamp(gh.y, 0, st.v - O.h);
    }
    /* valid placements of piece p covering cell (x, y); current orientation first */
    function fitsAt(p, x, y, pref) {
      const out = [];
      const oris = ORIS[p].slice().sort((a, b) => (a === pref ? -1 : b === pref ? 1 : 0));
      for (const o of oris) for (const [dx, dy] of ORI[o].c) { const ox = x - dx, oy = y - dy; if (ox >= 0 && oy >= 0 && valid.has(pack(o, ox, oy))) out.push({ o, x: ox, y: oy }); }
      return out;
    }
    function autoPlace(p, o) {
      // nearest valid spot (current orientation preferred) to where the ghost was, else to the board centre
      const cx = gh ? gh.x + ORI[gh.o].w / 2 : st.v / 2, cy = gh ? gh.y + ORI[gh.o].h / 2 : st.v / 2;
      let best = null, bd2 = 1e9, ac = -1;
      const W = st.v + 2;
      for (let i = 0; M && i < M.n; i++) {
        const m = M.mv[i], mo = unO(m); if (ORI[mo].p !== p) continue;
        const d = Math.hypot(unX(m) + ORI[mo].w / 2 - cx, unY(m) + ORI[mo].h / 2 - cy) + (mo === o ? 0 : 3);
        if (d < bd2) { bd2 = d; best = { o: mo, x: unX(m), y: unY(m) }; const c = M.cn[i]; ac = ((((c / W) | 0) - 1) << 5) | ((c % W) - 1); }
      }
      // remember the corner it was fitted to, so turning the piece keeps it on that corner
      if (best) { gh = best; anchor = ac; cyc = { c: -1, i: 0 }; return true; }
      gh = { o, x: Math.floor((st.v - ORI[o].w) / 2), y: Math.floor((st.v - ORI[o].h) / 2) };
      anchor = -1;
      return false;
    }
    function selectPiece(p, auto) {
      if (selP === p && gh) return;
      selP = p;
      const o = ORIS[p][0];
      if (auto) { if (!autoPlace(p, o)) api.toast('이 조각은 지금 놓을 자리가 없어요'); }
      else gh = { o, x: 0, y: 0 };
      api.sfx('click'); api.buzz(8);
    }
    function deselect() { selP = -1; gh = null; anchor = -1; cyc = { c: -1, i: 0 }; }
    function turnPiece(T) {
      if (!canInput() || !gh) return;
      const O = ORI[gh.o], no = T[gh.o], N = ORI[no];
      if (no === gh.o) { api.sfx('tick'); return; }
      let done = false;
      if (anchor >= 0) {
        const ax = anchor % 32, ay = anchor >> 5;
        const f = fitsAt(selP, ax, ay, no).filter((q) => q.o === no);
        if (f.length) { gh = f[0]; done = true; }
      }
      if (!done) {
        const cx = gh.x + (O.w - 1) / 2, cy = gh.y + (O.h - 1) / 2;
        gh = { o: no, x: Math.round(cx - (N.w - 1) / 2), y: Math.round(cy - (N.h - 1) / 2) };
        clampGh();
      }
      api.sfx('tick'); api.buzz(8);
      renderTray(); updateHud(); draw();
    }
    function tapCell(x, y) {
      if (!gh || selP < 0) return;
      const key = (y << 5) | x;
      const f = fitsAt(selP, x, y, gh.o);
      if (f.length) {
        cyc = cyc.c === key ? { c: key, i: (cyc.i + 1) % f.length } : { c: key, i: 0 };
        gh = f[cyc.i]; anchor = key;
        api.sfx('tick'); api.buzz(6);
      } else {
        const O = ORI[gh.o];
        gh = { o: gh.o, x: x - Math.floor(O.w / 2), y: y - Math.floor(O.h / 2) };
        clampGh(); anchor = -1; cyc = { c: -1, i: 0 };
        api.sfx('click');
      }
      ensureVisible(); renderTray(); updateHud(); draw();
    }
    function commit() {
      if (!canInput() || !gh) return;
      if (!ghValid()) { api.toast(ghReason() || '놓을 수 없어요'); api.buzz(30); return; }
      const a = { t: 'p', o: gh.o, x: gh.x, y: gh.y };
      deselect(); api.buzz(15);
      send(a);
      renderTray(); updateHud(); draw();
    }
    function onPass() { if (!canInput() || (M && M.n)) return; api.sfx('click'); api.buzz(15); send({ t: 's' }); updateHud(); }
    function onUndo() { if (!canUndo()) return; deselect(); api.sfx('click'); api.buzz(15); send({ t: 'u' }); }
    function toggleHint() { showHint = !showHint; U.store.set('blockclaim.hint', showHint); hintLabel(); api.sfx('click'); api.buzz(8); draw(); }
    function toggleZoom() {
      if (!G) return;
      const z = view.z > 1.01 ? 1 : 2;
      // zoom around the ghost, else around the colour's latest pieces / start corner
      let fx = st.v / 2, fy = st.v / 2;
      if (gh) { fx = gh.x + ORI[gh.o].w / 2; fy = gh.y + ORI[gh.o].h / 2; }
      else if (st) { const [sx, sy] = startOf(st, st.c); const ls = st.last && !st.last.ps && st.last.k === st.c ? st.last : null; fx = ls ? ls.x : sx; fy = ls ? ls.y : sy; }
      view.z = z;
      view.ox = fx * cs() - G.size / 2; view.oy = fy * cs() - G.size / 2;
      clampView(); zoomLabel(); api.sfx('click'); api.buzz(8); draw();
    }
    function ensureVisible() {
      if (!gh || view.z <= 1.01) return;
      const O = ORI[gh.o], c = cs(), m = c * 0.5;
      const x0 = gh.x * c, y0 = gh.y * c, x1 = (gh.x + O.w) * c, y1 = (gh.y + O.h) * c;
      if (x0 - view.ox < m) view.ox = x0 - m; if (x1 - view.ox > G.size - m) view.ox = x1 - G.size + m;
      if (y0 - view.oy < m) view.oy = y0 - m; if (y1 - view.oy > G.size - m) view.oy = y1 - G.size + m;
      clampView();
    }

    /* ----- drawing ----- */
    function draw() {
      cv.clear();
      if (!st || !G) return;
      placeSpots();
      const { bx, by, size, fr } = G, c = cs(), B = st.v, W = B + 2;
      // walnut frame + slate bed
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 14; ctx.shadowOffsetY = 5;
      const fg = ctx.createLinearGradient(bx, by, bx + size, by + size);
      fg.addColorStop(0, '#6e4527'); fg.addColorStop(1, '#3a2213');
      ctx.fillStyle = fg; rr(ctx, bx - fr, by - fr, size + fr * 2, size + fr * 2, 10); ctx.fill();
      ctx.restore();
      ctx.fillStyle = 'rgba(255,225,180,.18)'; rr(ctx, bx - fr + 1.5, by - fr + 1.5, size + fr * 2 - 3, 2, 1); ctx.fill();
      ctx.save();
      ctx.beginPath(); ctx.rect(bx, by, size, size); ctx.clip();
      ctx.fillStyle = '#1d1826'; ctx.fillRect(bx, by, size, size);
      // cells
      const x0 = Math.max(0, Math.floor(view.ox / c)), y0 = Math.max(0, Math.floor(view.oy / c));
      const x1 = Math.min(B, Math.ceil((view.ox + size) / c)), y1 = Math.min(B, Math.ceil((view.oy + size) / c));
      const ins = Math.max(0.8, c * 0.06);
      for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
        const px = cellX(x), py = cellY(y);
        ctx.fillStyle = (x + y) & 1 ? '#2e2740' : '#2b2439';
        ctx.fillRect(px + ins, py + ins, c - ins * 2, c - ins * 2);
      }
      // starting cells (corners, or the duo's inner starting points): tinted cell + ring until that colour has placed
      for (let k = 0; k < st.nc; k++) {
        if (!isFirst(st, k)) continue;
        const [sx, sy] = startOf(st, k), qx = cellX(sx), qy = cellY(sy), px = qx + c / 2, py = qy + c / 2;
        ctx.fillStyle = colorOf(k); ctx.globalAlpha = 0.32;
        ctx.fillRect(qx + ins, qy + ins, c - ins * 2, c - ins * 2);
        ctx.globalAlpha = 1;
        ctx.strokeStyle = colorOf(k); ctx.lineWidth = Math.max(1.5, c * 0.1);
        ctx.beginPath(); ctx.arc(px, py, c * 0.32, 0, 7); ctx.stroke();
        ctx.fillStyle = colorOf(k); ctx.beginPath(); ctx.arc(px, py, c * 0.12, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(242,233,216,.85)'; ctx.lineWidth = Math.max(1, c * 0.05);
        ctx.strokeRect(qx + ins, qy + ins, c - ins * 2, c - ins * 2);
      }
      // placed pieces
      const an = anim && performance.now() < anim.t0 + anim.dur ? anim : null;
      const lastSet = new Set();
      if (st.last && !st.last.ps) { const base = pid(W, st.last.x, st.last.y); for (const d of geo(B).off[st.last.o]) lastSet.add(base + d); }
      for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
        const v = bd[pid(W, x, y)];
        if (!v) continue;
        if (an && lastSet.has(pid(W, x, y))) continue;
        tile(ctx, cellX(x), cellY(y), c, colorOf(v - 1));
      }
      // latest piece: drop-in animation, then a brass outline
      if (lastSet.size) {
        const k = st.last.k;
        let e = 1;
        if (an) e = U.clamp((performance.now() - an.t0) / an.dur, 0, 1);
        const sc = 1 + (1 - e) * 0.35, al = 0.25 + 0.75 * e;
        const O = ORI[st.last.o], mx = cellX(st.last.x) + O.w * c / 2, my = cellY(st.last.y) + O.h * c / 2;
        ctx.save(); ctx.translate(mx, my); ctx.scale(sc, sc); ctx.translate(-mx, -my);
        for (const [dx, dy] of O.c) tile(ctx, cellX(st.last.x + dx), cellY(st.last.y + dy), c, colorOf(k), an ? al : 1);
        ctx.restore();
        if (!an) outline(st.last.o, st.last.x, st.last.y, 'rgba(227,174,69,.95)', Math.max(1.5, c * 0.09));
      }
      // hints: corners where something fits
      const mine = canInput();
      if (mine && showHint && M) {
        for (const [ci, ps] of byCorner) {
          const x = (ci % W) - 1, y = ((ci / W) | 0) - 1;
          const strong = selP < 0 || ps.has(selP);
          const px = cellX(x) + c / 2, py = cellY(y) + c / 2;
          ctx.fillStyle = colorOf(st.c); ctx.globalAlpha = strong ? 0.85 : 0.25;
          ctx.beginPath(); ctx.arc(px, py, c * (strong ? 0.2 : 0.13), 0, 7); ctx.fill();
          if (strong) { ctx.strokeStyle = 'rgba(242,233,216,.9)'; ctx.lineWidth = 1.2; ctx.stroke(); }
          ctx.globalAlpha = 1;
        }
      }
      // ghost piece
      if (mine && gh) {
        const ok = ghValid(), O = ORI[gh.o];
        for (const [dx, dy] of O.c) {
          const px = cellX(gh.x + dx), py = cellY(gh.y + dy);
          if (ok) tile(ctx, px, py, c, colorOf(st.c), 0.78);
          else {
            ctx.fillStyle = 'rgba(238,106,85,.55)'; ctx.fillRect(px + 1, py + 1, c - 2, c - 2);
            ctx.strokeStyle = 'rgba(255,190,175,.7)'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(px + 2, py + c - 2); ctx.lineTo(px + c - 2, py + 2); ctx.stroke();
          }
        }
        outline(gh.o, gh.x, gh.y, ok ? '#f2e9d8' : '#ffb4a6', Math.max(2, c * 0.1));
      }
      ctx.restore();
      if (view.z > 1.01) { // minimap-ish indicator of the visible part
        const s = 34, mx = bx + size - s - 4, my = by + 4, f = s / (G.size * view.z);
        ctx.fillStyle = 'rgba(16,12,22,.7)'; ctx.fillRect(mx, my, s, s);
        ctx.strokeStyle = 'rgba(242,233,216,.8)'; ctx.lineWidth = 1; ctx.strokeRect(mx + view.ox * f, my + view.oy * f, G.size * f, G.size * f);
      }
    }
    /* outline around the union of a piece's cells */
    function outline(o, x, y, col, lw) {
      const O = ORI[o], c = cs(), set = new Set(O.c.map(([a, b]) => a + ',' + b));
      ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.lineCap = 'round'; ctx.beginPath();
      for (const [dx, dy] of O.c) {
        const px = cellX(x + dx), py = cellY(y + dy);
        if (!set.has(dx + ',' + (dy - 1))) { ctx.moveTo(px, py); ctx.lineTo(px + c, py); }
        if (!set.has(dx + ',' + (dy + 1))) { ctx.moveTo(px, py + c); ctx.lineTo(px + c, py + c); }
        if (!set.has((dx - 1) + ',' + dy)) { ctx.moveTo(px, py); ctx.lineTo(px, py + c); }
        if (!set.has((dx + 1) + ',' + dy)) { ctx.moveTo(px + c, py); ctx.lineTo(px + c, py + c); }
      }
      ctx.stroke(); ctx.restore();
    }

    /* ----- tray (DOM, horizontally scrollable) ----- */
    let traySig = '';
    function trayColor() {
      if (!st) return 0;
      if (myTurn()) return st.c;
      // show the next colour of a person on this phone, else the colour to move
      for (let i = 0; i < st.nc; i++) { const k = (st.c + i) % st.nc; if (!st.d[k] && api.canAct(owner(st, k))) return k; }
      return st.c;
    }
    function drawMini(cvs, p, o, col, dim) {
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5), S = 50;
      if (cvs.width !== S * dpr) { cvs.width = S * dpr; cvs.height = S * dpr; }
      const x = cvs.getContext('2d');
      x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, S, S);
      const O = ORI[o], s = Math.min(9.4, (S - 8) / Math.max(O.w, O.h));
      const ox = (S - O.w * s) / 2, oy = (S - O.h * s) / 2;
      for (const [dx, dy] of O.c) tile(x, ox + dx * s, oy + dy * s, s, col, dim ? 0.35 : 1);
    }
    function renderTray(force) {
      if (!st) return;
      const k = trayColor(), mine = canInput();
      const sig = [k, st.r[k], selP, gh ? gh.o : -1, mine, [...pieceOK].join('.'), st.d[k], st.seq].join('|');
      if (sig === traySig && !force) return;
      traySig = sig;
      tray.innerHTML = '';
      const order = [];
      for (let p = NP - 1; p >= 0; p--) if (st.r[k] & (1 << p)) order.push(p);
      order.sort((a, b) => SIZE[b] - SIZE[a]);
      if (!order.length) { tray.append(L.h('div', { class: 'muted', style: { fontSize: '13px', fontWeight: 700, padding: '0 6px' }, text: '조각을 모두 놓았어요!' })); return; }
      for (const p of order) {
        const on = p === selP, dim = mine && !pieceOK.has(p);
        const c = L.h('canvas', { style: { width: '50px', height: '50px', display: 'block', pointerEvents: 'none' } });
        const b = L.h('button', { type: 'button', 'aria-label': SIZE[p] + '칸 조각' + (on ? ' (선택됨)' : ''), 'data-p': p,
          style: { flex: 'none', width: '56px', height: '56px', padding: '2px', borderRadius: '12px', border: on ? '2px solid var(--brass)' : '1px solid rgba(242,233,216,.14)', background: on ? 'rgba(227,174,69,.16)' : 'rgba(34,28,46,.85)', touchAction: 'pan-x', cursor: 'pointer', opacity: mine || !myTurn() ? 1 : 0.6 } }, c);
        drawMini(c, p, on && gh ? gh.o : ORIS[p][0], colorOf(k), dim);
        b.addEventListener('pointerdown', (e) => trayDown(e, p, b));
        b.addEventListener('pointermove', trayMove);
        b.addEventListener('pointerup', trayUp);
        b.addEventListener('pointercancel', () => { td = null; });
        tray.append(b);
      }
      const sel = tray.querySelector('[data-p="' + selP + '"]');
      if (sel && force !== 'noscroll') try { sel.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e) {}
    }
    function trayDown(e, p, el) { if (!canInput()) return; td = { p, id: e.pointerId, x0: e.clientX, y0: e.clientY, drag: false, el, touch: e.pointerType !== 'mouse' }; }
    function trayMove(e) {
      if (!td || e.pointerId !== td.id || !canInput()) return;
      const dx = e.clientX - td.x0, dy = e.clientY - td.y0;
      if (!td.drag && dy < -10 && Math.abs(dy) > Math.abs(dx) * 1.1) {
        td.drag = true;
        try { td.el.setPointerCapture(e.pointerId); } catch (err) {}
        if (selP !== td.p) { selectPiece(td.p, false); } else api.buzz(8);
      }
      if (td.drag) { followFinger(e.clientX, e.clientY, td.touch); draw(); updateHud(); }
    }
    function trayUp(e) {
      if (!td || e.pointerId !== td.id) return;
      const t = td; td = null;
      if (!canInput()) return;
      if (t.drag) { api.sfx('tick'); api.buzz(10); anchor = -1; renderTray(); updateHud(); draw(); return; }
      // a tap: pick the piece, or turn it when it is already picked
      if (selP === t.p && gh) { turnPiece(ROT); return; }
      selectPiece(t.p, true); ensureVisible();
      renderTray('noscroll'); updateHud(); draw();
    }
    function followFinger(clx, cly, touch) {
      const r = cv.cv.getBoundingClientRect(), c = cs();
      const x = clx - r.left, y = cly - r.top - (touch ? Math.max(48, c * 2.6) : 0);
      const O = ORI[gh.o];
      const fx = (x - G.bx + view.ox) / c, fy = (y - G.by + view.oy) / c;
      gh = { o: gh.o, x: Math.round(fx - O.w / 2), y: Math.round(fy - O.h / 2) };
      clampGh();
    }

    /* ----- board gestures: drag moves the ghost (relative), tap snaps it, pinch zooms, drag pans when nothing is picked ----- */
    function onDown(e) {
      if (!st || !G) return;
      const p = cv.local(e);
      ptrs.set(e.pointerId, p);
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
      if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        pinch = { d0: Math.hypot(a.x - b.x, a.y - b.y) || 1, z0: view.z, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2, ox0: view.ox, oy0: view.oy };
        if (bdrag && bdrag.gx != null && gh) { gh.x = bdrag.gx; gh.y = bdrag.gy; }
        bdrag = null; return;
      }
      if (ptrs.size > 2) return;
      const inBoard = p.x >= G.bx - G.fr && p.y >= G.by - G.fr && p.x <= G.bx + G.size + G.fr && p.y <= G.by + G.size + G.fr;
      if (!inBoard) return;
      bdrag = { id: e.pointerId, x0: p.x, y0: p.y, moved: false, ox0: view.ox, oy0: view.oy, gx: gh ? gh.x : null, gy: gh ? gh.y : null, ghost: !!gh && canInput() };
    }
    function onMove(e) {
      if (!ptrs.has(e.pointerId)) return;
      const p = cv.local(e);
      ptrs.set(e.pointerId, p);
      if (pinch && ptrs.size >= 2) {
        const [a, b] = [...ptrs.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y), mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        const z = U.clamp(pinch.z0 * d / pinch.d0, 1, 3);
        const ux = (pinch.mx - G.bx + pinch.ox0) / (G.cs0 * pinch.z0), uy = (pinch.my - G.by + pinch.oy0) / (G.cs0 * pinch.z0);
        view.z = z; view.ox = ux * G.cs0 * z - (mx - G.bx); view.oy = uy * G.cs0 * z - (my - G.by);
        clampView(); zoomLabel(); draw(); return;
      }
      if (!bdrag || e.pointerId !== bdrag.id) return;
      const dx = p.x - bdrag.x0, dy = p.y - bdrag.y0;
      if (!bdrag.moved && Math.hypot(dx, dy) > 7) bdrag.moved = true;
      if (!bdrag.moved) return;
      if (bdrag.ghost && gh && canInput()) {
        const c = cs(), nx = bdrag.gx + Math.round(dx / c), ny = bdrag.gy + Math.round(dy / c);
        if (nx !== gh.x || ny !== gh.y) { gh = { o: gh.o, x: nx, y: ny }; clampGh(); anchor = -1; api.sfx('tick'); ensureVisible(); updateHud(); draw(); }
      } else if (view.z > 1.01) { view.ox = bdrag.ox0 - dx; view.oy = bdrag.oy0 - dy; clampView(); draw(); }
    }
    function onUp(e) {
      const p = cv.local(e);
      ptrs.delete(e.pointerId);
      if (pinch) { if (ptrs.size < 2) pinch = null; return; }
      if (!bdrag || e.pointerId !== bdrag.id) return;
      const d = bdrag; bdrag = null;
      if (d.moved) { if (d.ghost) api.buzz(6); return; }
      if (!canInput()) return;
      const cell = cellAt(p.x, p.y);
      if (!cell) return;
      if (gh) { tapCell(cell[0], cell[1]); return; }
      // nothing picked: tapping a hint corner picks the biggest piece that fits there
      const W = st.v + 2, ci = pid(W, cell[0], cell[1]);
      if (byCorner.has(ci)) {
        const ps = [...byCorner.get(ci)].sort((a, b) => SIZE[b] - SIZE[a] || b - a);
        selP = ps[0]; gh = { o: ORIS[selP][0], x: 0, y: 0 }; cyc = { c: -1, i: 0 };
        api.sfx('click'); api.buzz(8);
        tapCell(cell[0], cell[1]);
        return;
      }
      api.toast('아래에서 조각을 고르세요');
    }
    function onCancel(e) { ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch = null; bdrag = null; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    // test hooks → client coords of a cell centre / a tray piece
    L.games.blockclaim._pt = (x, y) => { if (!G) return null; const r = cv.cv.getBoundingClientRect(); return [r.left + cellX(x) + cs() / 2, r.top + cellY(y) + cs() / 2]; };
    L.games.blockclaim._tray = (p) => { const b = tray.querySelector('[data-p="' + p + '"]'); if (!b) return null; const r = b.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; };
    L.games.blockclaim._ghost = () => (gh ? { o: gh.o, x: gh.x, y: gh.y, ok: ghValid() } : null);

    /* ----- HUD ----- */
    let chipSig = '';
    function renderChips() {
      const sc = scores(st);
      const sig = sc.join(',') + '|' + st.c + '|' + st.d.join('') + '|' + !!st.st + '|' + st.r.join(',');
      if (sig === chipSig) return;
      chipSig = sig;
      top.innerHTML = '';
      const many = st.n >= 3;
      for (let i = 0; i < st.n; i++) {
        const ks = []; for (let k = 0; k < st.nc; k++) if (owner(st, k) === i) ks.push(k);
        const cur = !st.st && owner(st, st.c) === i;
        const dots = ks.map((k) => L.h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '3px', flex: 'none' } },
          L.h('span', { class: 'dot', style: { '--c': colorOf(k), opacity: st.d[k] === 1 ? 0.35 : 1, boxShadow: !st.st && st.c === k ? '0 0 0 2px var(--surface-2), 0 0 0 3.5px var(--brass)' : 'none' } }),
          L.h('span', { class: 'mono', style: { fontSize: '12px', fontWeight: 700, color: st.r[k] ? 'var(--ink)' : 'var(--brass)' }, text: st.r[k] ? String(remSquares(st.r[k])) : '✓' })));
        top.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '6px', padding: many ? '4px 6px' : '5px 9px', flex: '1 1 0', minWidth: 0, minHeight: '40px', borderColor: cur ? 'var(--brass)' : '', boxShadow: cur ? '0 0 0 1px var(--brass)' : 'none', justifyContent: many ? 'center' : 'flex-start' } },
          many ? null : L.h('span', { style: { fontSize: '12px', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0, flex: '1 1 auto' }, text: name(i) }),
          dots));
      }
    }
    function updateHud() {
      if (!st) return;
      renderChips();
      const mine = myTurn(), inp = canInput();
      const noMoves = mine && M && M.n === 0;
      const solo = !api.online && st.h >= 0 && api.canAct(st.h) && !st.st;
      vis(rotBtn, mine && !noMoves); vis(flipBtn, mine && !noMoves); vis(okBtn, mine && !noMoves);
      vis(undoBtn, solo && (mine || st.u.length > 0)); undoBtn.disabled = !canUndo();
      vis(hintBtn, !st.st); vis(zoomBtn, true);
      rotBtn.disabled = flipBtn.disabled = !gh || !inp;
      okBtn.disabled = !gh || !inp || !ghValid();
      vis(passBox, noMoves && !st.st, 'flex');
      if (noMoves) passMsg.textContent = (st.nc !== st.n ? CNAME[st.c] + ' — ' : '') + '놓을 수 있는 자리가 없어요. 이 색은 여기서 끝나요.';
      passBtn.disabled = !inp;
      let h = '', bad = false;
      if (st.st) h = '';
      else if (mine) {
        const tag = st.nc !== st.n ? CNAME[st.c] + ' · ' : '';
        if (noMoves) h = tag + '넘기기를 눌러 주세요';
        else if (!gh) h = tag + (isFirst(st, st.c) ? '첫 조각은 표시된 ' + (isDuo(st) ? '시작점을' : '시작 모서리를') + ' 덮어야 해요' : '조각을 탭하거나 위로 끌어 판에 올리세요');
        else if (ghValid()) h = tag + '「놓기」로 확정 · 판을 끌면 조각이 움직여요';
        else { h = '✕ ' + ghReason(); bad = true; }
      } else h = cname(st.c) + (api.players[owner(st, st.c)] && api.players[owner(st, st.c)].ai ? ' 생각 중…' : ' 차례');
      hint.textContent = h;
      hint.style.color = bad ? 'var(--coral)' : 'var(--muted)';
    }

    function finishAnim() {
      clearTimeout(animTimer);
      if (stopLoop) { stopLoop(); stopLoop = null; }
      anim = null;
      if (busy) { busy = false; api.setBusy(false); }
    }
    function startAnim() {
      const dur = 230 / (L.debug.speed || 1);
      anim = { t0: performance.now(), dur };
      busy = true; api.setBusy(true);
      animTimer = setTimeout(() => { if (anim) { finishAnim(); draw(); updateHud(); renderTray(); } }, dur + 600);
      stopLoop = U.loop((dt, now) => {
        if (!anim) return;
        if (now >= anim.t0 + anim.dur) { finishAnim(); draw(); updateHud(); renderTray(); return; }
        draw();
      });
    }

    return {
      update(next, prev) {
        const fresh = prev && prev !== next && prev.seq !== next.seq;
        const reset = !prev || prev.v !== next.v || prev.nc !== next.nc || next.seq < prev.seq || (next.seq === 0 && prev !== next);
        st = next; bd = boardOf(st);
        if (reset) { layout(); view = { z: 1, ox: 0, oy: 0 }; zoomLabel(); chipSig = ''; traySig = ''; }
        if (reset || fresh) { finishAnim(); deselect(); }
        if (reset || (prev && prev !== next)) refreshMoves();
        if (fresh) {
          const ev = next.ev && next.ev.id === next.seq ? next.ev : null;
          if (ev && ev.k === 'u') { api.sfx('whoosh'); api.toast('한 수 물렀어요'); }
          else if (next.last && next.last.id === next.seq) {
            if (next.last.ps) { api.sfx('lose'); api.toast(cname(next.last.k) + ' — 놓을 자리가 없어 끝'); }
            else { startAnim(); api.sfx('thud'); api.buzz(10); }
          }
          if (ev && ev.k === 'a') { api.sfx('win'); api.toast(cname(ev.c) + ' — 조각을 모두 놓았어요! +' + (next.m[ev.c] ? 20 : 15)); }
        }
        renderTray(); updateHud(); draw();
      },
      destroy() {
        finishAnim();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onCancel);
        cv.destroy(); top.remove(); hint.remove(); tray.remove(); passBox.remove(); bot.remove();
      },
    };
  }

  L.register({
    id: 'blockclaim', name: '조각 영역 차지', tag: '조각 배치 전략', cat: '보드',
    blurb: '1~5칸짜리 조각 21개를 판에 놓아요. 내 색끼리는 꼭짓점으로만 이어지고 변은 닿으면 안 돼요. 남은 칸이 가장 적은 사람이 이겨요.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 4, hidden: false, aiDelay: 420,
    tint: '#33406e',
    icon: '<rect x="8" y="8" width="9" height="9" rx="2" fill="currentColor"/><rect x="17" y="8" width="9" height="9" rx="2" fill="currentColor"/><rect x="8" y="17" width="9" height="9" rx="2" fill="currentColor"/><rect x="26" y="26" width="9" height="9" rx="2" fill="currentColor" opacity=".6"/><rect x="35" y="26" width="9" height="9" rx="2" fill="currentColor" opacity=".6"/><rect x="35" y="35" width="9" height="9" rx="2" fill="currentColor" opacity=".6"/><rect x="35" y="17" width="9" height="9" rx="2" fill="currentColor" opacity=".6"/><rect x="17" y="35" width="9" height="9" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><rect x="4" y="4" width="48" height="48" rx="5" fill="none" stroke="currentColor" stroke-width="2" opacity=".4"/>',
    options: [
      { id: 'bd', label: '2명일 때 판', choices: [{ v: 14, label: '듀오 14×14' }, { v: 20, label: '20×20 (2색씩)' }], def: 14 },
    ],
    quick: [
      '1~5칸짜리 조각 21개를 판에 최대한 많이 놓아요. 끝났을 때 남은 칸이 가장 적은(점수가 높은) 사람이 이겨요.',
      '내 차례: 조각 하나를 놓아요. 첫 조각은 내 시작 칸을 덮고, 그다음부턴 내 조각과 꼭짓점(대각선)으로 이어야 해요.',
      '내 색 조각끼리 변(옆면)이 닿으면 안 돼요! 다른 색과는 닿아도 괜찮아요.',
    ],
    rules: [
      { h: '목표', p: [
        '색마다 1~5칸짜리 조각 21개(모두 89칸)를 가져요. 1칸 1개 · 2칸 1개 · 3칸 2개 · 4칸 5개 · 5칸 12개.',
        '판에 조각을 최대한 많이 놓아서, 끝났을 때 손에 남은 칸이 가장 적은 사람이 이겨요.'] },
      { h: '판과 시작 칸', p: [
        '3~4명: 20×20 판, 각자 한 색. 판 모서리 하나씩이 각 색의 시작 모서리예요(3명이면 모서리 하나는 비어요).',
        '2명(기본): 듀오 14×14 판, 한 색씩. 시작 칸은 모서리가 아니라 판 안쪽 두 곳이에요: 1번은 왼쪽 위에서 다섯째 줄 다섯째 칸 (5,5), 2번은 열째 줄 열째 칸 (10,10). 판에 색 칸과 동그라미로 표시돼요.',
        '2명 옵션: 20×20 판에서 각자 두 색씩(1번: 빨강·노랑, 2번: 파랑·초록).'] },
      { h: '차례에 할 일', p: [
        '색 순서대로 돌아가며 조각 하나를 놓아요. 조각은 돌리거나 뒤집어도 돼요.',
        '첫 조각: 그 색의 시작 칸(시작 모서리 / 시작점)을 덮어야 해요.',
        '그다음부터: 같은 색 조각과 꼭짓점(대각선 모서리)으로 하나 이상 닿아야 해요.',
        '금지: 같은 색 조각과 변(옆면)이 닿으면 안 돼요. 겹치거나 판 밖으로 나가도 안 돼요.',
        '다른 색 조각과는 변이 닿아도 괜찮아요. 상대가 이어 갈 꼭짓점을 막는 것도 작전이에요.'] },
      { h: '넘기기와 끝', p: [
        '놓을 수 있는 조각이 하나도 없는 색은 차례를 넘기고, 그 색은 그 판에서 끝나요(놓을 자리는 다시 생기지 않아요).',
        '아무 색도 더 놓을 수 없으면 게임이 끝나요.'] },
      { h: '점수 · 승리', p: [
        '남은 조각의 칸 하나마다 −1점.',
        '21개를 모두 놓으면 +15점, 마지막으로 놓은 조각이 1칸짜리였다면 +5점 더(+20점).',
        '두 색을 맡으면 두 색 점수를 더해요. 점수가 가장 높은 사람이 이겨요(같으면 공동 1위).'] },
      { h: '조작', p: [
        '아래 조각 줄은 옆으로 밀어 넘겨요. 조각을 탭하면 놓을 수 있는 가까운 자리에 반투명 조각이 나타나요. 조각을 위로 끌어 판에 바로 올릴 수도 있어요.',
        '판을 끌면 조각이 따라 움직이고(손가락에 가려지지 않게 떨어져서), 칸을 탭하면 그 칸을 덮는 맞는 자리로 붙어요. 같은 칸을 다시 탭하면 다른 맞는 모양으로 바뀌어요.',
        '↻ 돌리기 · ⇋ 뒤집기(선택한 조각을 한 번 더 탭해도 돌아가요). 놓을 수 있으면 조각이 내 색으로, 안 되면 빨갛게 보이고 이유가 나와요. 「놓기」로 확정.',
        '「가능한 자리」를 켜면 지금 이어 붙일 수 있는 꼭짓점이 점으로 보여요(고른 조각이 맞는 곳은 진하게). 조각을 안 골랐을 때 점을 탭하면 거기 맞는 가장 큰 조각이 골라져요.',
        '⊕로 확대(두 손가락으로 벌려도 돼요). 확대 중에 조각을 안 골랐으면 판을 끌어 둘러봐요.',
        '놓을 자리가 없으면 자동으로 알려 주고, 「차례 넘기기」로 넘겨요.',
        '위 칩의 숫자는 색마다 남은 칸 수예요. ↶ 무르기: 이 폰에서 사람 1명 대 AI일 때 내 직전 수와 그 뒤 AI 수를 되돌려요(최대 5번).'] },
      { h: '예시', p: [
        '내 빨간 조각의 오른쪽 아래 모서리 바로 대각선 칸에 새 빨간 조각을 놓는다 → OK(꼭짓점으로 이어짐).',
        '새 빨간 조각이 기존 빨간 조각 옆면에 딱 붙는다 → 안 돼요(빨갛게 표시).',
        '판이 끝났을 때 3칸 조각 하나와 1칸 조각 하나가 남았다 → −4점.',
        '요령: 큰 5칸 조각을 초반에 먼저 쓰세요. 나중엔 빈틈이 좁아져서 큰 조각이 안 들어가요.'] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움.',
        '쉬움: 큰 조각을 좋아하지만 자리는 아무렇게나. 보통: 조각 크기·새로 생기는 꼭짓점·상대 꼭짓점 막기를 따져요. 어려움: 판 위 영역과 꼭짓점 이동력을 평가하고 다음 상대의 응수까지 내다봐요.'] },
    ],
    tutorial: [
      { sel: '.bc-start', text: '여기가 내 색의 시작 칸이에요. 내 첫 조각은 꼭 이 칸을 덮어야 해요.' },
      { sel: '.bc-tray', text: '내 조각 21개(1~5칸)예요. 옆으로 밀어 넘기고, 탭하면 판에 반투명으로 올라가요. 위로 끌어 판에 바로 올려도 돼요.' },
      { sel: '.bc-board', text: '가장 중요한 규칙! 두 번째 조각부터는 내 조각과 꼭짓점(대각선)으로 닿아야 하고, 옆면(변)이 닿으면 안 돼요. 다른 색과는 닿아도 괜찮아요.' },
      { sel: '.bc-board', text: '판을 끌면 조각이 따라오고, 칸을 탭하면 거기 맞춰 붙어요. 내 색으로 보이면 놓을 수 있고, 빨가면 안 되는 자리예요(이유는 아래에 나와요).' },
      { sel: '.bc-rot', text: '↻로 돌리고 ⇋로 뒤집어요. 마음에 들면 오른쪽 「놓기」로 확정!' },
      { sel: '.bc-spots', text: '어디에 놓을지 모르겠으면 「가능한 자리」를 켜 보세요. 이어 붙일 수 있는 꼭짓점이 점으로 보여요.' },
      { sel: '.bc-top', text: '위 칩 숫자는 색마다 남은 칸이에요. 끝났을 때 적게 남을수록 이겨요(1칸당 −1점, 다 놓으면 +15점). 큰 조각부터 쓰는 게 요령! 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { HP, PIECES, ORI, ORIS, ROT, FLIP, NO, SIZE, TOTAL, ALL, boardOf, movesFor, reason, scores, colorScore, remSquares, hasMove, pack, startOf, DUO_START },
  });
})();
