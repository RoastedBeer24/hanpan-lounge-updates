/* 마법 물약 추리 — 솥 안에 숨은 '금지된 물약' 재료 3개(약초 1 · 광물 1 · 마법 생물 1)를 먼저 맞히는 추리 게임.
   재료는 종류마다 6개(보통) 또는 8개(옵션 '재료 많이', 상태 m). 정답 3장을 뺀 나머지를 똑같이 나눠 주고, 남는 몇 장은 선반에 공개해요.
   내 차례: 줄마다 1개씩 골라 시험 → 다음 사람부터 돌아가며 그중 하나라도 가진 첫 사람이 나에게만 1장 보여줘요.
   모두는 '누가' 보여줬는지만 알아요. 정답 선언은 한 번: 맞히면 승리, 틀리면 탈락(카드 보여주기는 계속).
   상태: h 패(문자열, 'a'+카드번호), sh 공개 재료, x 정답, t 차례, ph 'b'(시험 고르기)/'s'(보여주기)/'v'(결과 보기)/'e'(끝),
   c 지금 시험 조합, r 보여줄 사람, k 보여준 카드, o 탈락, lg 시험 기록(6글자씩: 시험자·재료3·보여준 사람·보여준 카드),
   dl 틀린 선언(4글자씩), w 승자, why 'ok'/'last'/'cap'. 추리 엔진 know()는 AI와 추리 노트가 같이 써요. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- ingredients ---------- */
  const CAP = 150;
  const CATS = ['약초', '광물', '마법 생물'];
  const CAT_COL = ['#5fb36b', '#5aa2d0', '#d8687c'];
  /* master list: 8 per category [name, color, art]. 보통 uses the first 6 of each, 재료 많이 all 8 */
  const ING = [
    ['달빛꽃', '#b9d0ff', 0], ['불꽃고추', '#e8452f', 1], ['얼음잎', '#7fe3e8', 2], ['꿈버섯', '#a66be0', 3], ['울음뿌리', '#c08a58', 4], ['행운풀', '#58c25e', 5], ['종소리꽃', '#e8eef8', 18], ['가시덩굴', '#5a8a3a', 19],
    ['루비', '#e0304e', 6], ['사파이어', '#3f6fe0', 7], ['에메랄드', '#2fbf7a', 8], ['자수정', '#9b5fe0', 9], ['황금가루', '#f0c040', 10], ['월장석', '#d8e4f0', 11], ['흑요석', '#5a4a78', 20], ['호박석', '#e09a2a', 21],
    ['용 비늘', '#e0662a', 12], ['유니콘 뿔', '#f3c9e0', 13], ['불새 깃털', '#ff9a2a', 14], ['박쥐 날개', '#7a55a0', 15], ['두꺼비', '#7aa83a', 16], ['거미줄', '#c8ccd8', 17], ['달팽이 집', '#c9a070', 22], ['여우 꼬리', '#ff8a3a', 23],
  ];
  /* card i in a game with m per category → master index */
  const mid = (m, i) => ((i / m) | 0) * 8 + (i % m);
  const ingOf = (m, i) => ING[mid(m, i)];
  const cc = (i) => String.fromCharCode(97 + i);
  const ci = (c) => c.charCodeAt(0) - 97;
  const catOf = (i, m) => (i / m) | 0;
  const bits = (m) => { let k = 0; while (m) { m &= m - 1; k++; } return k; };
  const single = (m) => m !== 0 && (m & (m - 1)) === 0;
  /* 이/가 after a name (Hangul final consonant, digits read in Korean) */
  function josaGa(name) {
    const c = String(name || '').trim().slice(-1);
    if (!c) return '가';
    const code = c.charCodeAt(0);
    if (code >= 0xac00 && code <= 0xd7a3) return (code - 0xac00) % 28 ? '이' : '가';
    if (c >= '0' && c <= '9') return '013678'.includes(c) ? '이' : '가';
    if (/[lmnLMN]/.test(c)) return '이';
    return '가';
  }
  const comboName = (m, str) => str.split('').map((c) => ingOf(m, ci(c))[0]).join(' + ');

  /* ---------- rules ---------- */
  function init(players, opts) {
    const n = players.length;
    const m = opts && opts.size === 'l' ? 8 : 6, NC = m * 3;
    const x = [U.rand(m), m + U.rand(m), 2 * m + U.rand(m)];
    const rest = U.shuffle([...Array(NC).keys()].filter((i) => !x.includes(i)));
    const per = Math.floor((NC - 3) / n), extra = NC - 3 - per * n;
    const srt = (a) => a.sort((p, q) => p - q).map(cc).join('');
    const h = [];
    for (let p = 0; p < n; p++) h.push(srt(rest.slice(extra + p * per, extra + (p + 1) * per)));
    return {
      n, m, nm: players.map((p, i) => String(p.name || '플레이어 ' + (i + 1)).slice(0, 10)), g: Math.random().toString(36).slice(2, 7),
      h, sh: srt(rest.slice(0, extra)), x: x.map(cc).join(''), t: U.rand(n), ph: 'b', c: '', r: -1, k: '',
      o: players.map(() => 0), lg: '', dl: '', w: -1, why: '', seq: 1, last: { id: 1, k: 'start' },
    };
  }
  function actor(s) { return s.ph === 'e' ? null : s.ph === 's' ? s.r : s.t; }
  const active = (s) => { const a = []; for (let i = 0; i < s.n; i++) if (!s.o[i]) a.push(i); return a; };
  function combo(c, m) {
    if (!Array.isArray(c) || c.length !== 3) throw new Error('bad combo');
    return c.map((v, k) => { v = v | 0; if (v < 0 || v >= m * 3 || catOf(v, m) !== k) throw new Error('bad combo'); return cc(v); }).join('');
  }
  /* first player after the brewer (going around, eliminated players too) who holds any card of the combo */
  function responder(s, b, c) {
    for (let j = 1; j < s.n; j++) { const p = (b + j) % s.n; for (const ch of c) if (s.h[p].includes(ch)) return p; }
    return -1;
  }
  function nextTurn(s) {
    s.c = ''; s.r = -1; s.k = '';
    if (s.lg.length / 6 >= CAP) { s.ph = 'e'; s.w = -1; s.why = 'cap'; return; }
    for (let j = 1; j <= s.n; j++) { const p = (s.t + j) % s.n; if (!s.o[p]) { s.t = p; break; } }
    s.ph = 'b';
  }
  function apply(s, seat, a) {
    if (!a || s.ph === 'e') throw new Error('game over');
    if (s.ph === 's') {
      if (seat !== s.r || a.t !== 'show') throw new Error('not your move');
      const k = cc(a.k | 0);
      if (!s.c.includes(k) || !s.h[seat].includes(k)) throw new Error('cannot show that');
      s.k = k; s.ph = 'v'; s.lg += s.t + s.c + s.r + k;
      s.last = { id: ++s.seq, k: 'show', b: s.t, r: s.r };
      return s;
    }
    if (seat !== s.t) throw new Error('not your turn');
    if (a.t === 'dec') {
      const c = combo(a.c, s.m);
      if (c === s.x) { s.w = seat; s.ph = 'e'; s.why = 'ok'; s.last = { id: ++s.seq, k: 'win', s: seat, c }; return s; }
      s.o[seat] = 1; s.dl += seat + c;
      const act = active(s);
      s.last = { id: ++s.seq, k: 'miss', s: seat, c };
      if (act.length === 1) { s.w = act[0]; s.ph = 'e'; s.why = 'last'; s.c = ''; s.r = -1; s.k = ''; return s; }
      nextTurn(s);
      return s;
    }
    if (s.ph === 'b' && a.t === 'test') {
      const c = combo(a.c, s.m);
      const r = responder(s, seat, c);
      s.c = c; s.r = r; s.k = '';
      if (r < 0) { s.ph = 'v'; s.lg += seat + c + '--'; } else s.ph = 's';
      s.last = { id: ++s.seq, k: 'test', b: seat, r };
      return s;
    }
    if (s.ph === 'v' && a.t === 'end') { nextTurn(s); s.last = { id: ++s.seq, k: 'end' }; return s; }
    throw new Error('bad action');
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const rec = '금지된 물약: ' + comboName(s.m, s.x);
    if (s.w < 0) return { winners: [], title: '무승부', text: CAP + '번 시험까지 아무도 못 맞혔어요. ' + rec };
    if (s.why === 'last') return { winners: [s.w], title: s.nm[s.w] + ' 승리', text: '다른 사람이 모두 틀려서 혼자 남았어요. ' + rec };
    return { winners: [s.w], title: s.nm[s.w] + ' 정답!', text: rec };
  }
  /* parsed test log */
  function logOf(s) {
    const out = [];
    for (let i = 0; i + 6 <= s.lg.length; i += 6) {
      const e = s.lg.slice(i, i + 6);
      out.push({ b: +e[0], c: e.slice(1, 4), r: e[4] === '-' ? -1 : +e[4], k: e[5] === '-' ? '' : e[5] });
    }
    return out;
  }
  /* players between the brewer and the responder (they had none of the three) */
  function passersOf(n, b, r) { const a = []; for (let j = 1; j < n; j++) { const p = (b + j) % n; if (p === r) break; a.push(p); } return a; }

  /* ---------- deduction engine ----------
     P[card] = bitmask of where the card may be: bit p = player p, bit n = the cauldron (솥). 0 = public shelf card.
     lvl 0: beginner (own hand, cards shown to me, "nobody showed" on my own tests)
     lvl 1: + passes, "someone showed one of these", hand counts, one-per-category (the notebook uses this)
     lvl 2: + what-if checks (try each place, drop the ones that lead to a contradiction) */
  function know(s, me, lvl) {
    const n = s.n, CB = 1 << n, ALL = (1 << (n + 1)) - 1, M = s.m, NC = M * 3;
    const P = new Array(NC);
    const shelf = s.sh.split('').map(ci);
    for (let i = 0; i < NC; i++) P[i] = ALL & ~(me >= 0 ? 1 << me : 0);
    for (const i of shelf) P[i] = 0;
    if (me >= 0) for (const c of s.h[me]) P[ci(c)] = 1 << me;
    const log = logOf(s), clauses = [];
    for (const e of log) {
      const cs = e.c.split('').map(ci);
      if (e.r >= 0 && e.b === me) P[ci(e.k)] = 1 << e.r;
      if (lvl === 0) {
        if (e.b === me && e.r < 0) for (const i of cs) if (P[i] && P[i] !== 1 << me) P[i] = CB;
        continue;
      }
      for (const p of passersOf(n, e.b, e.r)) for (const i of cs) if (P[i]) P[i] &= ~(1 << p);
      if (e.r >= 0 && e.b !== me && e.r !== me) clauses.push([e.r, cs]);
    }
    const cnt = s.h.map((x) => x.length);
    let ok = true;
    if (lvl === 0) {
      for (let k = 0; k < 3; k++) {
        const known = [], cand = [];
        for (let i = k * M; i < k * M + M; i++) { if (P[i] === CB) known.push(i); if (P[i] & CB) cand.push(i); }
        if (known.length) { for (let i = k * M; i < k * M + M; i++) if (P[i] !== CB) P[i] &= ~CB; }
        else if (cand.length === 1) P[cand[0]] = CB;
      }
    } else {
      ok = prop(P, clauses, cnt, n, M);
      if (ok && lvl >= 2) {
        for (let round = 0; round < 3; round++) {
          let ch = false;
          for (let i = 0; i < NC; i++) {
            if (!P[i] || single(P[i])) continue;
            for (let b = 0; b <= n; b++) {
              const bit = 1 << b;
              if (!(P[i] & bit)) continue;
              const Q = P.slice(); Q[i] = bit;
              if (!prop(Q, clauses, cnt, n, M)) { P[i] &= ~bit; ch = true; }
            }
          }
          if (!ch) break;
          if (!prop(P, clauses, cnt, n, M)) { ok = false; break; }
        }
      }
    }
    return { P, n, CB, ok, me, clauses, cnt, M };
  }
  function prop(P, clauses, cnt, n, M) {
    const CB = 1 << n, NC = M * 3;
    for (let guard = 0; guard < 60; guard++) {
      let ch = false;
      for (let p = 0; p <= n; p++) {
        const bit = 1 << p;
        const groups = p < n ? [[0, NC]] : [[0, M], [M, 2 * M], [2 * M, NC]];
        for (const [a, z] of groups) {
          const need = p < n ? cnt[p] : 1;
          let known = 0, poss = 0;
          for (let i = a; i < z; i++) { if (P[i] === bit) known++; if (P[i] & bit) poss++; }
          if (known > need || poss < need) return false;
          if (known === need) { for (let i = a; i < z; i++) if ((P[i] & bit) && P[i] !== bit) { P[i] &= ~bit; ch = true; if (!P[i]) return false; } }
          else if (poss === need) { for (let i = a; i < z; i++) if ((P[i] & bit) && P[i] !== bit) { P[i] = bit; ch = true; } }
        }
      }
      for (const [r, cs] of clauses) {
        const bit = 1 << r;
        if (cs.some((i) => P[i] === bit)) continue;
        const cand = cs.filter((i) => P[i] & bit);
        if (!cand.length) return false;
        if (cand.length === 1) { P[cand[0]] = bit; ch = true; }
      }
      if (!ch) return true;
    }
    return true;
  }
  function solvedOf(K) {
    const out = [], cand = [[], [], []];
    for (let i = 0; i < K.M * 3; i++) if (K.P[i] & K.CB) cand[catOf(i, K.M)].push(i);
    for (let k = 0; k < 3; k++) { const a = cand[k].find((i) => K.P[i] === K.CB); out.push(a == null ? (cand[k].length === 1 ? cand[k][0] : -1) : a); }
    return { sol: out.every((v) => v >= 0) ? out : null, cand, pick: out };
  }

  /* ---------- AI ---------- */
  function showChoices(s, me) { return s.c.split('').filter((c) => s.h[me].includes(c)).map(ci); }
  function shownBefore(s, me, b) { const set = new Set(); for (const e of logOf(s)) if (e.r === me && e.b === b && e.k) set.add(ci(e.k)); return set; }
  function chooseShow(s, me, lv) {
    const M = showChoices(s, me);
    if (M.length === 1 || lv === 1) return M[U.rand(M.length)];
    const prev = shownBefore(s, me, s.t);
    const again = M.filter((i) => prev.has(i));
    if (again.length) return again[U.rand(again.length)];
    if (lv >= 3) {
      // reveal the card that already "travels" the most (shown to others before) — keeps fresh cards secret
      const cnt = {};
      for (const e of logOf(s)) if (e.r === me && e.k) cnt[ci(e.k)] = (cnt[ci(e.k)] || 0) + 1;
      let best = -1, bv = -1;
      for (const i of M) { const v = (cnt[i] || 0) + Math.random() * 0.5; if (v > bv) { bv = v; best = i; } }
      return best;
    }
    return M[U.rand(M.length)];
  }
  function cls(K, i) {
    const p = K.P[i], me = K.me;
    if (p === 0) return 'blank';                          // shelf card — nobody can show it
    if (me >= 0 && p === 1 << me) return 'blank';          // my own card
    if (p === K.CB) return 'blank';                       // solved answer — nobody can show it
    if (p & K.CB) return 'unk';
    return single(p) ? 'known' : 'part';
  }
  function chooseTest(s, me, lv, K) {
    const M = K.M;
    if (lv === 1) {
      return [0, 1, 2].map((k) => {
        const ids = []; for (let j = 0; j < M; j++) ids.push(k * M + j);
        const good = ids.filter((i) => cls(K, i) === 'unk');
        if (good.length && Math.random() < 0.7) return good[U.rand(good.length)];
        return ids[U.rand(M)];
      });
    }
    if (lv === 2) {
      return [0, 1, 2].map((k) => {
        const ids = []; for (let j = 0; j < M; j++) ids.push(k * M + j);
        const unk = ids.filter((i) => cls(K, i) === 'unk');
        if (unk.length && !ids.some((i) => K.P[i] === K.CB)) return unk[U.rand(unk.length)];
        const bl = ids.filter((i) => cls(K, i) === 'blank');
        if (bl.length) return bl[U.rand(bl.length)];
        return unk.length ? unk[U.rand(unk.length)] : ids[U.rand(M)];
      });
    }
    // lv 3: sample worlds consistent with what I know, pick the test with the least expected uncertainty about the cauldron
    return bestTest(s, me, K);
  }
  function sampleWorlds(K, maxN, ms) {
    const out = [], t0 = Date.now();
    const idx = [];
    const M = K.M, NC = M * 3;
    for (let i = 0; i < NC; i++) if (K.P[i] && !single(K.P[i])) idx.push(i);
    for (let tries = 0; out.length < maxN && tries < maxN * 3 && Date.now() - t0 < ms; tries++) {
      let P = K.P.slice(), ok = true;
      U.shuffle(idx);
      for (const i of idx) {
        if (single(P[i])) continue;
        const opts = [];
        for (let b = 0; b <= K.n; b++) if (P[i] & (1 << b)) opts.push(1 << b);
        let done = false;
        U.shuffle(opts);
        for (const bit of opts) { const Q = P.slice(); Q[i] = bit; if (prop(Q, K.clauses, K.cnt, K.n, M)) { P = Q; done = true; break; } }
        if (!done) { ok = false; break; }
      }
      if (!ok) continue;
      const loc = P.map((m) => (m ? Math.log2(m) | 0 : -1));
      let key = 0;
      for (let i = 0; i < NC; i++) if (loc[i] === K.n) key = key * M + (i % M);
      out.push({ loc, key });
    }
    return out;
  }
  function bestTest(s, me, K) {
    const W = sampleWorlds(K, 140, 60);
    if (!W.length) return chooseTest(s, me, 2, K);
    const n = s.n;
    let best = null, bv = 1e9;
    const ent = (m, tot) => { let e = 0; for (const v of m.values()) { const p = v / tot; e -= p * Math.log(p); } return e; };
    const M = s.m;
    for (let a = 0; a < M; a++) for (let b = M; b < 2 * M; b++) for (let d = 2 * M; d < 3 * M; d++) {
      const groups = new Map();
      for (const w of W) {
        let okey = -1, ms = null;
        for (let j = 1; j < n; j++) {
          const p = (me + j) % n;
          const m = [];
          if (w.loc[a] === p) m.push(a); if (w.loc[b] === p) m.push(b); if (w.loc[d] === p) m.push(d);
          if (m.length) { okey = p; ms = m; break; }
        }
        const add = (k, wt) => { let g = groups.get(k); if (!g) { g = { t: 0, m: new Map() }; groups.set(k, g); } g.t += wt; g.m.set(w.key, (g.m.get(w.key) || 0) + wt); };
        if (okey < 0) add(-1, 1);
        else for (const c of ms) add(okey * 32 + c, 1 / ms.length);
      }
      let e = 0;
      for (const g of groups.values()) e += (g.t / W.length) * ent(g.m, g.t);
      e += Math.random() * 1e-3;
      if (e < bv) { bv = e; best = [a, b, d]; }
    }
    return best;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 's') return { t: 'show', k: chooseShow(s, seat, lv) };
    const K = know(s, seat, lv === 1 ? 0 : lv === 2 ? 1 : 2);
    const so = solvedOf(K);
    if (so.sol) return { t: 'dec', c: so.sol };
    if (lv === 1) {
      const prod = so.cand[0].length * so.cand[1].length * so.cand[2].length;
      if (prod > 0 && ((prod <= 2 && Math.random() < 0.5) || (prod <= 4 && Math.random() < 0.15))) {
        return { t: 'dec', c: so.cand.map((a) => a[U.rand(a.length)]) };
      }
    }
    if (s.ph === 'v') return { t: 'end' };
    return { t: 'test', c: chooseTest(s, seat, lv, K) };
  }
  function aiDelayFor(s, seat, lv) {
    const base = s.ph === 's' ? 750 : s.ph === 'v' ? 900 : 1100;
    return base * (lv === 1 ? 1.25 : lv === 3 ? 0.85 : 1);
  }

  /* ---------- ingredient art (drawn once, cached as images) ---------- */
  let ART = null;
  function drawIcon(g, i) {
    g.lineJoin = 'round'; g.lineCap = 'round';
    g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 3; g.shadowOffsetY = 2;
    const P = (pts) => { g.beginPath(); g.moveTo(pts[0], pts[1]); for (let k = 2; k < pts.length; k += 2) g.lineTo(pts[k], pts[k + 1]); g.closePath(); };
    const lg = (y0, y1, a, b) => { const q = g.createLinearGradient(0, y0, 0, y1); q.addColorStop(0, a); q.addColorStop(1, b); return q; };
    const circ = (x, y, r) => { g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); };
    switch (i) {
      case 0: // moon flower
        g.strokeStyle = '#3f8a4a'; g.lineWidth = 3; g.beginPath(); g.moveTo(32, 60); g.quadraticCurveTo(28, 46, 32, 34); g.stroke();
        for (let k = 0; k < 5; k++) { const a = -Math.PI / 2 + k * Math.PI * 2 / 5; g.save(); g.translate(32 + Math.cos(a) * 10, 26 + Math.sin(a) * 10); g.rotate(a + Math.PI / 2); g.beginPath(); g.ellipse(0, 0, 7.5, 11, 0, 0, Math.PI * 2); g.fillStyle = lg(-11, 11, '#e9f0ff', '#8fb0f0'); g.fill(); g.restore(); }
        g.shadowBlur = 0; circ(32, 26, 6); g.fillStyle = '#ffe27a'; g.fill(); break;
      case 1: // fire chili
        g.beginPath(); g.moveTo(26, 16); g.bezierCurveTo(8, 30, 22, 58, 50, 58); g.bezierCurveTo(34, 50, 34, 30, 38, 18); g.closePath();
        g.fillStyle = lg(14, 58, '#ff7a4a', '#b8161c'); g.fill();
        g.shadowBlur = 0; g.fillStyle = '#4fa54a'; g.beginPath(); g.ellipse(32, 16, 8, 4, -0.2, 0, Math.PI * 2); g.fill();
        g.strokeStyle = '#3f8a3a'; g.lineWidth = 3; g.beginPath(); g.moveTo(32, 14); g.quadraticCurveTo(34, 6, 42, 5); g.stroke();
        g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 2; g.beginPath(); g.moveTo(24, 26); g.quadraticCurveTo(20, 38, 30, 48); g.stroke(); break;
      case 2: // ice leaf
        g.beginPath(); g.moveTo(12, 54); g.quadraticCurveTo(8, 14, 54, 10); g.quadraticCurveTo(54, 50, 12, 54); g.closePath();
        g.fillStyle = lg(10, 54, '#c8fbff', '#36a8c0'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 2; g.beginPath(); g.moveTo(14, 52); g.lineTo(46, 18); g.stroke();
        g.fillStyle = '#fff'; for (const [x, y] of [[24, 24], [40, 40], [30, 34]]) { circ(x, y, 1.8); g.fill(); } break;
      case 3: // dream mushroom
        g.fillStyle = lg(30, 58, '#f6ead2', '#c9b48e'); g.beginPath(); g.moveTo(26, 32); g.lineTo(38, 32); g.lineTo(40, 58); g.lineTo(24, 58); g.closePath(); g.fill();
        g.beginPath(); g.moveTo(8, 36); g.bezierCurveTo(8, 6, 56, 6, 56, 36); g.closePath(); g.fillStyle = lg(8, 36, '#c890ff', '#6a2fb0'); g.fill();
        g.shadowBlur = 0; g.fillStyle = '#f4e8ff'; for (const [x, y, r] of [[22, 24, 3.5], [36, 16, 3], [44, 28, 3.5], [30, 30, 2.2]]) { circ(x, y, r); g.fill(); } break;
      case 4: // crying root
        g.fillStyle = '#4fa54a'; for (const a of [-0.6, 0, 0.6]) { g.save(); g.translate(32, 18); g.rotate(a); g.beginPath(); g.ellipse(0, -7, 4, 9, 0, 0, Math.PI * 2); g.fill(); g.restore(); }
        g.strokeStyle = '#8a5a30'; g.lineWidth = 3.5; g.beginPath(); g.moveTo(27, 48); g.lineTo(22, 60); g.moveTo(37, 48); g.lineTo(42, 60); g.stroke();
        g.beginPath(); g.ellipse(32, 36, 13, 16, 0, 0, Math.PI * 2); g.fillStyle = lg(20, 52, '#e2b07c', '#a26a3a'); g.fill();
        g.shadowBlur = 0; g.fillStyle = '#3a2210'; circ(27, 33, 2); g.fill(); circ(37, 33, 2); g.fill();
        g.beginPath(); g.ellipse(32, 42, 2.5, 3.5, 0, 0, Math.PI * 2); g.fill();
        g.fillStyle = '#7fd8ff'; g.beginPath(); g.ellipse(26, 38, 1.4, 2.4, 0, 0, Math.PI * 2); g.fill(); break;
      case 5: // lucky clover
        g.strokeStyle = '#3f8a3a'; g.lineWidth = 3; g.beginPath(); g.moveTo(32, 32); g.quadraticCurveTo(36, 48, 30, 60); g.stroke();
        g.fillStyle = lg(10, 50, '#8ee07a', '#2f8a3a');
        for (let k = 0; k < 4; k++) { const a = Math.PI / 4 + k * Math.PI / 2; for (const d of [-0.42, 0.42]) { circ(32 + Math.cos(a + d) * 11, 28 + Math.sin(a + d) * 11, 7); g.fill(); } }
        g.shadowBlur = 0; g.fillStyle = 'rgba(255,255,255,.35)'; circ(32, 28, 3); g.fill(); break;
      case 6: // ruby
        P([20, 14, 44, 14, 56, 28, 32, 58, 8, 28]); g.fillStyle = lg(14, 58, '#ff7088', '#8a0a22'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = 'rgba(255,220,230,.7)'; g.lineWidth = 1.5; g.beginPath();
        g.moveTo(8, 28); g.lineTo(56, 28); g.moveTo(20, 14); g.lineTo(26, 28); g.lineTo(32, 58); g.lineTo(38, 28); g.lineTo(44, 14); g.stroke(); break;
      case 7: // sapphire
        circ(32, 32, 22); g.fillStyle = (() => { const q = g.createRadialGradient(26, 24, 2, 32, 32, 22); q.addColorStop(0, '#a8c4ff'); q.addColorStop(1, '#1a3a9a'); return q; })(); g.fill();
        g.shadowBlur = 0; g.strokeStyle = 'rgba(220,235,255,.6)'; g.lineWidth = 1.5;
        P([32, 18, 44, 26, 44, 38, 32, 46, 20, 38, 20, 26]); g.stroke();
        g.beginPath(); for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3 - Math.PI / 2; g.moveTo(32 + Math.cos(a) * 14, 32 + Math.sin(a) * 14); g.lineTo(32 + Math.cos(a) * 22, 32 + Math.sin(a) * 22); } g.stroke(); break;
      case 8: // emerald
        P([20, 10, 44, 10, 52, 18, 52, 46, 44, 54, 20, 54, 12, 46, 12, 18]); g.fillStyle = lg(10, 54, '#7ff0b8', '#0d7a48'); g.fill();
        g.shadowBlur = 0; g.fillStyle = 'rgba(200,255,225,.35)'; P([24, 20, 40, 20, 42, 24, 42, 40, 40, 44, 24, 44, 22, 40, 22, 24]); g.fill();
        g.strokeStyle = 'rgba(220,255,235,.6)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(20, 10); g.lineTo(24, 20); g.moveTo(44, 10); g.lineTo(40, 20); g.moveTo(20, 54); g.lineTo(24, 44); g.moveTo(44, 54); g.lineTo(40, 44); g.stroke(); break;
      case 9: // amethyst cluster
        for (const [x, w, top, c1] of [[20, 9, 22, '#b88af0'], [44, 9, 18, '#a070e8'], [32, 11, 6, '#c9a2ff']]) {
          P([x - w, 58, x - w, top + 12, x, top, x + w, top + 12, x + w, 58]); g.fillStyle = lg(top, 58, c1, '#4a1f8a'); g.fill();
          g.save(); g.shadowBlur = 0; g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x, top); g.lineTo(x, 58); g.stroke(); g.restore();
        }
        break;
      case 10: // gold dust
        g.beginPath(); g.moveTo(6, 54); g.quadraticCurveTo(32, 12, 58, 54); g.closePath(); g.fillStyle = lg(22, 54, '#ffe48a', '#b8860b'); g.fill();
        g.shadowBlur = 0; g.fillStyle = '#fff6c8';
        for (const [x, y, r] of [[18, 16, 4], [48, 12, 3], [40, 26, 2.5], [26, 40, 2]]) { g.beginPath(); g.moveTo(x, y - r * 2); g.lineTo(x + r * 0.5, y - r * 0.5); g.lineTo(x + r * 2, y); g.lineTo(x + r * 0.5, y + r * 0.5); g.lineTo(x, y + r * 2); g.lineTo(x - r * 0.5, y + r * 0.5); g.lineTo(x - r * 2, y); g.lineTo(x - r * 0.5, y - r * 0.5); g.closePath(); g.fill(); }
        break;
      case 11: // moonstone
        g.shadowColor = 'rgba(170,200,255,.8)'; g.shadowBlur = 10; g.shadowOffsetY = 0;
        circ(32, 32, 20); g.fillStyle = (() => { const q = g.createRadialGradient(26, 24, 2, 32, 32, 22); q.addColorStop(0, '#ffffff'); q.addColorStop(1, '#8aa0c8'); return q; })(); g.fill();
        g.shadowBlur = 0; g.fillStyle = 'rgba(80,100,150,.45)'; g.beginPath(); g.arc(32, 32, 14, -1.2, 1.9); g.arc(36, 30, 11, 1.7, -1.0, true); g.closePath(); g.fill(); break;
      case 12: // dragon scale
        g.beginPath(); g.moveTo(32, 6); g.quadraticCurveTo(58, 18, 52, 38); g.quadraticCurveTo(44, 56, 32, 60); g.quadraticCurveTo(20, 56, 12, 38); g.quadraticCurveTo(6, 18, 32, 6); g.closePath();
        g.fillStyle = lg(6, 60, '#ffa04a', '#a02a10'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = 'rgba(255,220,160,.65)'; g.lineWidth = 2;
        for (const y of [20, 32, 44]) { g.beginPath(); g.arc(32, y - 12, 18 - (y - 20) * 0.25, 0.5, Math.PI - 0.5); g.stroke(); } break;
      case 13: // unicorn horn
        P([22, 60, 42, 60, 33, 4]); g.fillStyle = lg(4, 60, '#ffffff', '#e8cfe0'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = '#f08ac0'; g.lineWidth = 2.2; g.beginPath();
        for (let k = 0; k < 5; k++) { const y = 54 - k * 10, w = (y - 4) / 56 * 10; g.moveTo(32 - w, y); g.lineTo(32 + w, y - 6); } g.stroke(); break;
      case 14: // phoenix feather
        g.beginPath(); g.moveTo(14, 58); g.bezierCurveTo(4, 30, 30, 6, 50, 4); g.bezierCurveTo(56, 26, 36, 50, 14, 58); g.closePath();
        g.fillStyle = lg(4, 58, '#ffe25a', '#e0401a'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = '#fff2c8'; g.lineWidth = 2; g.beginPath(); g.moveTo(10, 62); g.quadraticCurveTo(26, 34, 48, 6); g.stroke();
        g.strokeStyle = 'rgba(160,30,10,.5)'; g.lineWidth = 1.2; g.beginPath(); for (let k = 0; k < 4; k++) { const t = 0.3 + k * 0.15; const x = 10 + 38 * t, y = 62 - 56 * t; g.moveTo(x, y); g.lineTo(x + 8, y + 6); } g.stroke(); break;
      case 15: // bat wing
        g.beginPath(); g.moveTo(6, 20); g.lineTo(58, 12); g.quadraticCurveTo(54, 30, 58, 44); g.quadraticCurveTo(46, 38, 40, 50); g.quadraticCurveTo(32, 40, 22, 50); g.quadraticCurveTo(18, 36, 6, 40); g.closePath();
        g.fillStyle = lg(12, 50, '#9a70c8', '#3a2058'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = '#2a1640'; g.lineWidth = 2; g.beginPath(); g.moveTo(6, 20); g.lineTo(58, 12); g.moveTo(14, 18); g.lineTo(22, 48); g.moveTo(30, 16); g.lineTo(40, 48); g.moveTo(44, 14); g.lineTo(56, 42); g.stroke(); break;
      case 16: // toad
        g.fillStyle = lg(26, 56, '#a6d860', '#4a7a1a'); g.beginPath(); g.ellipse(32, 42, 24, 15, 0, 0, Math.PI * 2); g.fill();
        circ(20, 28, 8); g.fill(); circ(44, 28, 8); g.fill();
        g.shadowBlur = 0; g.fillStyle = '#ffe680'; circ(20, 27, 5); g.fill(); circ(44, 27, 5); g.fill();
        g.fillStyle = '#1a1a10'; g.fillRect(17, 26, 6, 2.4); g.fillRect(41, 26, 6, 2.4);
        g.strokeStyle = '#2f5010'; g.lineWidth = 2; g.beginPath(); g.moveTo(20, 44); g.quadraticCurveTo(32, 50, 44, 44); g.stroke();
        g.fillStyle = 'rgba(40,70,10,.5)'; for (const [x, y] of [[14, 44], [50, 46], [30, 36]]) { circ(x, y, 2); g.fill(); } break;
      case 17: // spider web
        g.shadowBlur = 0; g.strokeStyle = '#dfe4f0'; g.lineWidth = 1.6; g.beginPath();
        for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; g.moveTo(32, 32); g.lineTo(32 + Math.cos(a) * 26, 32 + Math.sin(a) * 26); } g.stroke();
        for (const r of [8, 15, 22]) { g.beginPath(); for (let k = 0; k <= 8; k++) { const a = k * Math.PI / 4; const x = 32 + Math.cos(a) * r, y = 32 + Math.sin(a) * r; if (!k) g.moveTo(x, y); else g.quadraticCurveTo(32 + Math.cos(a - Math.PI / 8) * r * 0.8, 32 + Math.sin(a - Math.PI / 8) * r * 0.8, x, y); } g.stroke(); }
        g.fillStyle = '#2a2030'; circ(42, 40, 4); g.fill(); g.strokeStyle = '#2a2030'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(42, 36); g.lineTo(42, 20); g.stroke(); break;
      case 18: // bell flower
        g.strokeStyle = '#3f8a4a'; g.lineWidth = 3; g.beginPath(); g.moveTo(14, 60); g.quadraticCurveTo(14, 12, 50, 10); g.stroke();
        for (const [x, y] of [[22, 22], [34, 14], [47, 16]]) {
          g.strokeStyle = '#3f8a4a'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x, y - 4); g.lineTo(x, y + 4); g.stroke();
          g.beginPath(); g.moveTo(x - 7, y + 18); g.quadraticCurveTo(x - 7, y + 3, x, y + 3); g.quadraticCurveTo(x + 7, y + 3, x + 7, y + 18);
          g.quadraticCurveTo(x + 4, y + 15, x + 2, y + 18); g.quadraticCurveTo(x, y + 15, x - 2, y + 18); g.quadraticCurveTo(x - 4, y + 15, x - 7, y + 18); g.closePath();
          g.fillStyle = lg(y + 3, y + 18, '#ffffff', '#c8d4ec'); g.fill();
        }
        break;
      case 19: // thorny vine
        g.strokeStyle = '#3a6a2a'; g.lineWidth = 5; g.beginPath(); g.moveTo(8, 56); g.bezierCurveTo(30, 52, 10, 30, 30, 26); g.bezierCurveTo(50, 22, 36, 8, 56, 8); g.stroke();
        g.shadowBlur = 0; g.fillStyle = '#a8d070';
        for (const [x, y, a] of [[14, 52, -1.4], [22, 40, 0.6], [26, 28, -1.2], [40, 22, 0.8], [46, 12, -1.0]]) { g.save(); g.translate(x, y); g.rotate(a); P([-3, 0, 3, 0, 0, -7]); g.fill(); g.restore(); }
        g.fillStyle = '#d8304a'; circ(36, 40, 5); g.fill(); g.fillStyle = 'rgba(255,255,255,.6)'; circ(34.5, 38.5, 1.5); g.fill(); break;
      case 20: // obsidian shard
        P([30, 4, 48, 20, 52, 46, 34, 60, 14, 48, 12, 22]); g.fillStyle = lg(4, 60, '#6a5a88', '#120e1a'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = 'rgba(200,180,255,.55)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(30, 4); g.lineTo(32, 30); g.lineTo(52, 46); g.moveTo(32, 30); g.lineTo(14, 48); g.moveTo(32, 30); g.lineTo(12, 22); g.stroke();
        g.fillStyle = 'rgba(255,255,255,.35)'; P([22, 16, 28, 10, 26, 28]); g.fill(); break;
      case 21: // amber with a tiny bug
        g.beginPath(); g.moveTo(32, 8); g.bezierCurveTo(54, 10, 58, 40, 44, 54); g.bezierCurveTo(30, 62, 8, 52, 10, 32); g.bezierCurveTo(12, 16, 20, 8, 32, 8); g.closePath();
        g.fillStyle = (() => { const q = g.createRadialGradient(26, 24, 2, 32, 34, 28); q.addColorStop(0, '#ffe08a'); q.addColorStop(1, '#b0600a'); return q; })(); g.fill();
        g.shadowBlur = 0; g.fillStyle = 'rgba(60,30,5,.75)'; g.beginPath(); g.ellipse(33, 36, 4, 6, 0.4, 0, Math.PI * 2); g.fill();
        g.strokeStyle = 'rgba(60,30,5,.75)'; g.lineWidth = 1.2; g.beginPath(); for (const d of [-1, 1]) { g.moveTo(33, 34); g.lineTo(33 + d * 8, 30); g.moveTo(33, 38); g.lineTo(33 + d * 8, 42); } g.stroke();
        g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.ellipse(22, 20, 5, 3, -0.6, 0, Math.PI * 2); g.fill(); break;
      case 22: // snail shell
        circ(32, 32, 22); g.fillStyle = lg(10, 54, '#ecc890', '#8a5a28'); g.fill();
        g.shadowBlur = 0; g.strokeStyle = '#5a3a18'; g.lineWidth = 2.4; g.beginPath();
        for (let k = 0; k <= 60; k++) { const a = k * 0.32, r = 2 + k * 0.32; const x = 32 + Math.cos(a) * r, y = 32 + Math.sin(a) * r; if (!k) g.moveTo(x, y); else g.lineTo(x, y); } g.stroke(); break;
      case 23: // fox tail
        g.beginPath(); g.moveTo(10, 58); g.bezierCurveTo(4, 30, 26, 10, 50, 6); g.bezierCurveTo(60, 18, 50, 40, 30, 50); g.bezierCurveTo(22, 54, 16, 58, 10, 58); g.closePath();
        g.fillStyle = lg(6, 58, '#ffb060', '#c8501a'); g.fill();
        g.shadowBlur = 0; g.fillStyle = '#fff6ea'; g.beginPath(); g.moveTo(38, 9); g.bezierCurveTo(46, 6, 54, 8, 56, 14); g.bezierCurveTo(54, 22, 46, 24, 40, 22); g.bezierCurveTo(42, 16, 40, 12, 38, 9); g.closePath(); g.fill();
        g.strokeStyle = 'rgba(120,40,10,.45)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(16, 50); g.quadraticCurveTo(22, 30, 38, 18); g.stroke(); break;
    }
    g.shadowColor = 'transparent';
  }
  function art() {
    if (ART) return ART;
    ART = [];
    for (let i = 0; i < ING.length; i++) {
      const c = document.createElement('canvas'); c.width = c.height = 128;
      const g = c.getContext('2d'); g.scale(2, 2); drawIcon(g, ING[i][2]);
      let url = '';
      try { url = c.toDataURL('image/png'); } catch (e) { url = ''; }
      ART.push({ cv: c, url });
    }
    return ART;
  }

  /* ---------- view ---------- */
  const CSS = `
.pt-wrap{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(130% 70% at 50% 0%,#2c2040 0%,#17131f 70%)}
.pt-strip{display:flex;gap:4px;padding:6px 8px 4px;flex:none}
.pt-chip{flex:1 1 0;min-width:0;height:44px;border-radius:10px;background:#221c2e;border:1px solid var(--line);display:flex;flex-direction:column;justify-content:center;padding:2px 6px;position:relative;overflow:hidden;transition:border-color .2s,box-shadow .2s}
.pt-chip .nm{font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:4px;line-height:1.25}
.pt-chip .nm .t{overflow:hidden;text-overflow:ellipsis}
.pt-chip .sub{font-size:11px;color:var(--muted);display:flex;gap:4px;align-items:center;white-space:nowrap;line-height:1.3}
.pt-chip.cur{border-color:var(--c);box-shadow:0 0 0 1px var(--c) inset,0 0 14px -4px var(--c)}
.pt-chip.out{opacity:.5}.pt-chip.out .nm .t{text-decoration:line-through}
.pt-strip.tight .pt-chip{padding:2px 4px}.pt-strip.tight .pt-cc{display:none}.pt-strip.tight .pt-tag{font-size:9.5px;padding:0 3px}.pt-strip.tight .sub{gap:3px}
.pt-cc{display:inline-block;width:8px;height:11px;border-radius:2px;border:1.5px solid var(--muted);flex:none}
.pt-tag{font-size:10px;font-weight:700;padding:0 4px;border-radius:5px;background:rgba(255,255,255,.08);color:var(--muted);overflow:hidden;text-overflow:ellipsis}
.pt-tag.show{background:var(--brass);color:var(--brass-ink)}.pt-tag.brew{background:#2f6a52;color:#dff5ea}.pt-tag.wait{background:#5a3f8a;color:#efe2ff}.pt-tag.out{background:#5a2a2a;color:#ffd0c8}
.pt-scene{position:relative;flex:1 1 auto;min-height:92px;overflow:hidden}
.pt-wrap.cmp .pt-scene{min-height:26px}.pt-wrap.cmp .pt-strip{padding:3px 8px 2px}.pt-wrap.cmp .pt-chip{height:36px}
.pt-wrap.cmp .pt-bh{height:35px}.pt-wrap.cmp .pt-bh .lbl{display:none}.pt-wrap.cmp .pt-bh .pt-seg{margin-right:auto}
.pt-wrap.cmp .pt-ch{height:14px;line-height:14px}.pt-wrap.cmp .pt-col{gap:2px}.pt-wrap.cmp .pt-grid{gap:3px}
.pt-wrap.cmp .pt-bar{padding:2px 8px 4px;gap:3px}.pt-wrap.cmp .pt-hint{font-size:12px;line-height:1.2}
.pt-wrap.cmp .pt-cap{bottom:2px;min-height:24px;padding:1px 8px}.pt-wrap.cmp .pt-shelf{display:none}
.pt-cap{position:absolute;left:8px;right:8px;bottom:4px;display:flex;align-items:center;justify-content:center;gap:4px;flex-wrap:wrap;font-size:12.5px;line-height:1.25;text-align:center;background:rgba(23,19,31,.8);border:1px solid var(--line);border-radius:10px;padding:3px 8px;min-height:26px;z-index:2}
.pt-cap img{width:20px;height:20px;vertical-align:middle}
.pt-cap b{font-weight:700}
.pt-shelf{position:absolute;left:8px;top:6px;display:flex;align-items:center;gap:2px;font-size:10.5px;color:var(--muted);background:rgba(23,19,31,.7);border-radius:8px;padding:2px 6px;z-index:2}
.pt-shelf img{width:22px;height:22px}
.pt-board{position:relative;flex:none;padding:0 8px}
.pt-bh{display:flex;align-items:center;gap:6px;height:38px}
.pt-bh .lbl{font-family:var(--f-display);font-size:16px;color:var(--brass);margin-right:auto;white-space:nowrap}
.pt-seg{display:flex;border:1px solid var(--line);border-radius:10px;overflow:hidden;flex:none}
.pt-seg button{appearance:none;border:0;background:transparent;min-height:34px;padding:0 10px;font-size:12.5px;font-weight:700;color:var(--muted);cursor:pointer}
.pt-seg button.on{background:var(--surface-2);color:var(--ink)}
.pt-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:4px}
.pt-col{display:flex;flex-direction:column;gap:3px;min-width:0}
.pt-ch{font-size:11px;font-weight:700;text-align:center;height:18px;line-height:18px;white-space:nowrap;overflow:hidden;color:var(--cc)}
.pt-ch span{color:var(--muted);font-weight:500}
.pt-cell{appearance:none;height:var(--cellh,44px);border-radius:9px;background:linear-gradient(#2e2640,#261f36);border:1px solid var(--line);display:flex;align-items:center;gap:3px;padding:0 3px 0 2px;position:relative;cursor:pointer;touch-action:manipulation;text-align:left;color:var(--ink);min-width:0;transition:transform .08s}
.pt-cell:active{transform:scale(.96)}
.pt-cell img{width:32px;height:32px;flex:none}
.pt-cell .tx{min-width:0;display:flex;flex-direction:column;line-height:1.15}
.pt-cell .n{font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pt-cell .st{font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:3px}
.pt-cell .st i{width:7px;height:7px;border-radius:50%;flex:none;background:var(--c)}
.pt-cell.dead img,.pt-cell.dead .n{opacity:.42}
.pt-cell.mine{background:linear-gradient(#3a3020,#2a2418)}
.pt-cell.mine .st{color:var(--brass)}
.pt-cell.mx .n{text-decoration:line-through;opacity:.6}.pt-cell.mx .st{color:#ee9a8a}
.pt-cell.mq{background:linear-gradient(#34305a,#2a2648)}.pt-cell.mq .st{color:#c9b8ff}
.pt-cell.ans{border-color:#ffd76a;background:linear-gradient(#5a4614,#33280c)}.pt-cell.ans .st{color:#ffe08a;font-weight:700}
.pt-cell.fresh{outline:2px dashed var(--brass);outline-offset:-3px;animation:ptPulse 1s ease-in-out 3}
.pt-cell.fresh img,.pt-cell.fresh .n{opacity:1}
@keyframes ptPulse{50%{background:#5a4614}}
.pt-cell.sel{border-color:var(--brass);box-shadow:0 0 0 2px var(--brass) inset,0 0 12px -2px var(--brass)}
.pt-cell.sel::after{content:'✓';position:absolute;right:3px;top:1px;font-size:11px;font-weight:800;color:var(--brass)}
.pt-bar{flex:none;padding:6px 8px 8px;display:flex;flex-direction:column;gap:6px}
.pt-hint{font-size:12.5px;text-align:center;color:var(--ink);min-height:34px;line-height:1.35;display:flex;align-items:center;justify-content:center}
.pt-hint.mine{color:var(--brass);font-weight:700}
.pt-wrap.cmp .pt-hint{min-height:29px}
.pt-wrap.sh .pt-strip{padding:4px 8px 2px}.pt-wrap.sh .pt-chip{height:40px}.pt-wrap.sh .pt-bh{height:36px}
.pt-wrap.sh .pt-bar{padding:3px 8px 6px;gap:4px}.pt-wrap.sh .pt-hint{font-size:12px;min-height:31px;line-height:1.28}
.pt-help{appearance:none;flex:none;width:34px;height:34px;border-radius:50%;border:1px solid var(--brass);background:transparent;color:var(--brass);font-weight:800;font-size:16px;cursor:pointer;display:grid;place-items:center;position:relative}
.pt-help::before{content:'';position:absolute;inset:-5px}
.pt-leg{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px;overflow-y:auto;touch-action:pan-y;max-height:60vh}
.pt-leg li{display:flex;align-items:center;gap:10px;font-size:13px;line-height:1.4}
.pt-leg .pt-cell{width:118px;flex:none;cursor:default;--cellh:44px}
.pt-leg .pt-cell:active{transform:none}
.pt-btns{display:flex;gap:6px}.pt-btns .btn{flex:1;min-width:0;padding:8px 8px}
.pt-pop{position:absolute;left:4px;right:4px;top:0;bottom:0;z-index:5;background:rgba(20,16,30,.96);border:1px solid var(--line);border-radius:14px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:10px;text-align:center}
.pt-pop .q{font-size:14px;line-height:1.4}
.pt-pop .cards{display:flex;gap:10px;justify-content:center}
.pt-card{appearance:none;width:84px;height:112px;border-radius:12px;border:2px solid #d9c9a0;background:linear-gradient(#f7eed8,#e3d3ae);color:#2a1d05;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;position:relative;box-shadow:0 6px 14px rgba(0,0,0,.45);padding:12px 4px 4px;overflow:hidden;cursor:pointer;flex:none}
.pt-card::before{content:'';position:absolute;left:0;right:0;top:0;height:9px;background:var(--cc)}
.pt-card img{width:60%;height:auto;aspect-ratio:1}
.pt-card .n{font-size:13px;font-weight:700;white-space:nowrap}
.pt-card .k{font-size:10px;color:#6a5a3a}
.pt-card .rec{position:absolute;left:0;right:0;bottom:0;font-size:10px;font-weight:700;background:var(--brass);color:var(--brass-ink)}
.pt-card.small{width:64px;height:86px;padding-top:10px}.pt-card.small .n{font-size:11.5px}
.pt-back{width:34px;height:46px;border-radius:6px;border:2px solid #d9c9a0;background:repeating-linear-gradient(45deg,#4a2a6a 0 5px,#3a1f58 5px 10px);box-shadow:0 4px 10px rgba(0,0,0,.5)}
.pt-fly{position:absolute;z-index:9;pointer-events:none;left:0;top:0;will-change:transform}
.pt-side{position:absolute;right:8px;top:6px;z-index:3;display:flex;flex-direction:column;align-items:center;gap:2px;animation:ptIn .35s ease-out}
.pt-side .who{font-size:11px;font-weight:700;background:rgba(23,19,31,.85);border-radius:6px;padding:0 6px}
.pt-none{position:absolute;right:8px;top:8px;z-index:3;background:rgba(23,19,31,.88);border:1px solid var(--brass);color:var(--brass);border-radius:10px;padding:4px 8px;font-size:12px;font-weight:700;max-width:46%}
.pt-secret{position:absolute;left:0;right:0;top:8px;display:flex;justify-content:center;gap:8px;z-index:3;animation:ptUp .7s ease-out}
.pt-list{overflow-y:auto;touch-action:pan-y;max-height:58vh;display:flex;flex-direction:column;gap:6px;margin:0;padding:0;list-style:none}
.pt-list li{background:var(--surface-2);border-radius:10px;padding:6px 8px;font-size:12.5px;line-height:1.4}
.pt-list img{width:18px;height:18px;vertical-align:-4px}
@keyframes ptIn{from{transform:translateY(-8px) scale(.9);opacity:0}to{transform:none;opacity:1}}
@keyframes ptUp{from{transform:translateY(40px) scale(.7);opacity:0}to{transform:none;opacity:1}}
`;

  function mount(root, api) {
    const A = art();
    const h = L.h;
    const spd = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'pt-wrap' });
    const strip = h('div', { class: 'pt-strip' });
    const scene = h('div', { class: 'pt-scene' });
    const board = h('div', { class: 'pt-board' });
    const bar = h('div', { class: 'pt-bar' });
    wrap.append(strip, scene, board, bar);
    root.append(style, wrap);
    const cv = U.canvas(scene), ctx = cv.ctx;
    const capEl = h('div', { class: 'pt-cap' });
    const shelfEl = h('div', { class: 'pt-shelf' });
    const sideEl = h('div', { style: { display: 'contents' } });
    scene.append(shelfEl, sideEl, capEl);

    let st = null, lastId = -1, gid = '', busyT = 0, busy = false, sentSeq = -1;
    let mode = 'pick';                       // 'pick' | 'memo'
    let sel = {};                            // seat -> [i,i,i]
    let memo = {};                           // seat -> array(18) 0 none / 1 ✗ / 2 ?
    let liq = [90, 63, 160], liqT = [90, 63, 160], liqHold = 0, splash = 0, reveal = 0;
    const flies = [];
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    function busyFor(ms) { clearTimeout(busyT); setBusy(true); busyT = setTimeout(() => setBusy(false), ms / spd()); }

    /* ---------- geometry for the scene ---------- */
    let bg = null, G = null;
    function layout() {
      const W = cv.w, H = cv.h;
      const R = U.clamp(Math.min(W * 0.17, (H - 46) / 1.9), 22, 84);
      const rimY = H - 38 - R * 1.3;
      G = { W, H, R, cx: W / 2, rimY };
      bg = document.createElement('canvas'); bg.width = Math.max(1, Math.round(W * cv.dpr)); bg.height = Math.max(1, Math.round(H * cv.dpr));
      const g = bg.getContext('2d'); g.scale(cv.dpr, cv.dpr);
      // wall
      const wg = g.createLinearGradient(0, 0, 0, H); wg.addColorStop(0, '#2a1f3c'); wg.addColorStop(1, '#1a1426'); g.fillStyle = wg; g.fillRect(0, 0, W, H);
      g.strokeStyle = 'rgba(255,255,255,.035)'; g.lineWidth = 1;
      for (let y = 0, row = 0; y < H; y += 16, row++) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); for (let x = (row % 2) * 22; x < W; x += 44) { g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + 16); g.stroke(); } }
      // glow behind cauldron
      const gl = g.createRadialGradient(G.cx, rimY + R * 0.4, 4, G.cx, rimY + R * 0.4, R * 2.6); gl.addColorStop(0, 'rgba(255,150,60,.22)'); gl.addColorStop(1, 'rgba(255,150,60,0)'); g.fillStyle = gl; g.fillRect(0, 0, W, H);
      // shelf with bottles on the right
      const sy = Math.max(30, H * 0.36);
      const bx0 = W * 0.62;
      const bottles = [['#6fd0b0', 10, 22], ['#e07aa0', 8, 30], ['#f0c060', 11, 18], ['#8a9cf0', 7, 26]];
      let bx = bx0 + 16;
      for (const [c, w, hh] of bottles) {
        if (bx + w > W - 6) break;
        g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(bx - w, sy - hh, w * 2, hh);
        g.fillStyle = c; g.globalAlpha = 0.55; g.fillRect(bx - w + 2, sy - hh * 0.55, w * 2 - 4, hh * 0.55 - 1); g.globalAlpha = 1;
        g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(bx - 3, sy - hh - 7, 6, 7);
        g.fillStyle = '#8a5a30'; g.fillRect(bx - 3.5, sy - hh - 10, 7, 4);
        bx += w * 2 + 12;
      }
      g.fillStyle = '#5a3a20'; g.fillRect(bx0, sy, W - bx0, 6); g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(bx0, sy + 6, W - bx0, 4);
      // floor
      const fy = rimY + R * 1.02;
      const fg = g.createLinearGradient(0, fy, 0, H); fg.addColorStop(0, '#2a2030'); fg.addColorStop(1, '#151019'); g.fillStyle = fg; g.fillRect(0, fy, W, H - fy);
      // cauldron legs + body
      g.fillStyle = '#121014';
      if (H >= 84) for (const dx of [-0.62, 0.62]) { g.beginPath(); g.moveTo(G.cx + dx * R - 5, fy - 10); g.lineTo(G.cx + dx * R * 1.12, fy + 4); g.lineTo(G.cx + dx * R + 5, fy - 10); g.closePath(); g.fill(); }
    }
    cv.onresize = () => { layout(); };
    layout();

    function drawPot(g, now) {
      const { cx, rimY, R } = G;
      const t = now / 1000;
      // fire
      const fy = rimY + R * 0.98;
      for (let k = 0; k < 5; k++) {
        const x = cx + (k - 2) * R * 0.22, fl = R * (0.32 + 0.12 * Math.sin(t * 9 + k * 1.7));
        const q = g.createLinearGradient(0, fy - fl, 0, fy + 4); q.addColorStop(0, 'rgba(255,220,90,0)'); q.addColorStop(0.5, 'rgba(255,150,40,.85)'); q.addColorStop(1, 'rgba(220,60,20,.9)');
        g.fillStyle = q; g.beginPath(); g.moveTo(x - R * 0.1, fy + 4); g.quadraticCurveTo(x - R * 0.08, fy - fl * 0.5, x + Math.sin(t * 7 + k) * 3, fy - fl); g.quadraticCurveTo(x + R * 0.08, fy - fl * 0.5, x + R * 0.1, fy + 4); g.closePath(); g.fill();
      }
      // body
      g.beginPath(); g.moveTo(cx - R * 0.98, rimY); g.bezierCurveTo(cx - R * 1.22, rimY + R * 1.28, cx + R * 1.22, rimY + R * 1.28, cx + R * 0.98, rimY); g.closePath();
      const bq = g.createRadialGradient(cx - R * 0.35, rimY + R * 0.3, R * 0.1, cx, rimY + R * 0.4, R * 1.2); bq.addColorStop(0, '#4a4452'); bq.addColorStop(0.6, '#1d1a22'); bq.addColorStop(1, '#0c0a0e');
      g.fillStyle = bq; g.fill();
      // rune band
      g.strokeStyle = 'rgba(227,174,69,.35)'; g.lineWidth = 1.5; g.beginPath(); g.ellipse(cx, rimY + R * 0.42, R * 1.02, R * 0.16, 0, 0.15, Math.PI - 0.15); g.stroke();
      // liquid
      const lc = `rgb(${liq[0] | 0},${liq[1] | 0},${liq[2] | 0})`;
      g.save();
      g.shadowColor = lc; g.shadowBlur = 16 + splash * 20;
      g.beginPath(); g.ellipse(cx, rimY + 1, R * 0.9, R * 0.2, 0, 0, Math.PI * 2);
      const lq = g.createRadialGradient(cx, rimY, 2, cx, rimY, R * 0.9); lq.addColorStop(0, '#fff'); lq.addColorStop(0.08, lc); lq.addColorStop(1, `rgb(${liq[0] * 0.45 | 0},${liq[1] * 0.45 | 0},${liq[2] * 0.45 | 0})`);
      g.fillStyle = lq; g.fill(); g.restore();
      // rim
      g.strokeStyle = '#3a3440'; g.lineWidth = Math.max(4, R * 0.12); g.beginPath(); g.ellipse(cx, rimY, R * 0.98, R * 0.24, 0, 0, Math.PI * 2); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1.5; g.beginPath(); g.ellipse(cx, rimY - 1.5, R * 0.98, R * 0.24, 0, Math.PI * 1.05, Math.PI * 1.6); g.stroke();
      // bubbles
      for (let k = 0; k < 9; k++) {
        const ph = (t * (0.55 + (k % 3) * 0.17) + k * 0.37) % 1;
        const bx = cx + Math.sin(k * 12.9) * R * 0.62;
        const by = rimY - ph * R * (0.35 + splash * 0.6);
        const br = (2 + (k % 3) * 1.5) * (1 - ph * 0.4) * (R / 50);
        g.globalAlpha = 1 - ph;
        g.strokeStyle = `rgb(${Math.min(255, liq[0] + 90) | 0},${Math.min(255, liq[1] + 90) | 0},${Math.min(255, liq[2] + 90) | 0})`; g.lineWidth = 1.4;
        g.beginPath(); g.arc(bx, by, br, 0, Math.PI * 2); g.stroke();
      }
      // steam
      for (let k = 0; k < 4; k++) {
        const ph = (t * 0.22 + k * 0.25) % 1;
        g.globalAlpha = 0.07 * (1 - ph);
        g.fillStyle = '#e8e0f0';
        g.beginPath(); g.arc(cx + Math.sin(t + k * 2) * R * 0.3, rimY - R * 0.2 - ph * R * 1.3, R * (0.18 + ph * 0.3), 0, Math.PI * 2); g.fill();
      }
      g.globalAlpha = 1;
    }
    function frame(dt, now) {
      if (!G) return;
      // liquid color eases toward the target; tested colors fade back to the house brew
      if (liqHold > 0) liqHold -= dt * spd(); else liqT = [90, 63, 160];
      for (let k = 0; k < 3; k++) liq[k] += (liqT[k] - liq[k]) * Math.min(1, dt * 3 * spd());
      splash = Math.max(0, splash - dt * 1.4 * spd());
      ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(bg, 0, 0); ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      if (G.H >= 84) drawPot(ctx, now);
      // flying things (DOM) are animated here too
      for (let k = flies.length - 1; k >= 0; k--) {
        const f = flies[k];
        f.t += dt * spd() / f.dur;
        const e = Math.min(1, f.t), q = e < 0.5 ? 2 * e * e : 1 - Math.pow(-2 * e + 2, 2) / 2;
        const x = f.x0 + (f.x1 - f.x0) * q, y = f.y0 + (f.y1 - f.y0) * q - Math.sin(e * Math.PI) * f.arc;
        const sc = f.s0 + (f.s1 - f.s0) * q;
        f.el.style.transform = `translate(${x}px,${y}px) translate(-50%,-50%) scale(${sc})`;
        f.el.style.opacity = e > 0.85 && f.fade ? String((1 - e) / 0.15) : '1';
        if (e >= 1) { f.el.remove(); flies.splice(k, 1); if (f.done) f.done(); }
      }
    }
    const stopLoop = U.loop(frame);

    /* ---------- helpers ---------- */
    const pName = (i) => (api.players[i] && api.players[i].name) || (st ? st.nm[i] : '');
    const pGa = (i) => { const n = pName(i); return n + josaGa(n); };
    const pCol = (i) => (api.players[i] && api.players[i].color) || '#e3ae45';
    const Mm = () => (st && st.m) || 6;
    const iname = (i) => ingOf(Mm(), i)[0];
    const img = (i, cls) => h('img', { src: A[mid(Mm(), i)].url, alt: iname(i), class: cls || null, draggable: 'false' });
    const viewer = () => api.viewer();
    const mySel = (v) => (sel[v] || (sel[v] = [-1, -1, -1]));
    const myMemo = (v) => (memo[v] || (memo[v] = new Array(24).fill(0)));
    function rel(el) { const r0 = root.getBoundingClientRect(), r = el.getBoundingClientRect(); return { x: r.left - r0.left + r.width / 2, y: r.top - r0.top + r.height / 2 }; }
    function fly(el, from, to, opts) {
      el.classList.add('pt-fly'); root.append(el);
      const f = Object.assign({ el, x0: from.x, y0: from.y, x1: to.x, y1: to.y, t: 0, dur: 0.6, arc: 30, s0: 1, s1: 1, fade: false }, opts || {});
      el.style.transform = `translate(${from.x}px,${from.y}px) translate(-50%,-50%)`;
      flies.push(f);
    }
    function potXY() { const r0 = root.getBoundingClientRect(), r = scene.getBoundingClientRect(); return { x: r.left - r0.left + G.cx, y: r.top - r0.top + G.rimY }; }
    function chipEl(i) { return strip.children[i] || strip; }
    function toast(t) { api.toast(t); }
    function cardEl(i, small, extra) {
      return h('div', { class: 'pt-card' + (small ? ' small' : ''), style: { '--cc': CAT_COL[catOf(i, Mm())] } },
        img(i), h('div', { class: 'n', text: iname(i) }), h('div', { class: 'k', text: CATS[catOf(i, Mm())] }), extra || null);
    }
    /* the test being shown: the current one (ph s/v) or the last logged one */
    function focusTest() {
      if (!st) return null;
      if (st.ph === 's' || st.ph === 'v') return { b: st.t, c: st.c, r: st.r, k: st.k, live: true };
      const lg = logOf(st);
      return lg.length ? Object.assign(lg[lg.length - 1], { live: false }) : null;
    }

    /* ---------- rendering ---------- */
    function renderStrip() {
      strip.innerHTML = '';
      const f = focusTest();
      const pass = f ? passersOf(st.n, f.b, f.r) : [];
      const act = actor(st), tight = st.n >= 5;
      strip.classList.toggle('tight', tight);
      for (let i = 0; i < st.n; i++) {
        let tag = null;
        if (st.o[i]) tag = h('span', { class: 'pt-tag out', text: '탈락' });
        else if (f && f.b === i && f.live) tag = h('span', { class: 'pt-tag brew', text: '시험' });
        if (f && f.r === i) tag = h('span', { class: 'pt-tag ' + (st.ph === 's' ? 'wait' : 'show'), text: st.ph === 's' ? (tight ? '고름' : '고르는 중') : '보여줌' });
        else if (f && pass.includes(i) && !tag) tag = h('span', { class: 'pt-tag', text: '없음' });
        if (!tag && st.ph === 'b' && st.t === i) tag = h('span', { class: 'pt-tag brew', text: '차례' });
        const chip = h('div', { class: 'pt-chip' + (act === i ? ' cur' : '') + (st.o[i] ? ' out' : ''), style: { '--c': pCol(i) } },
          h('div', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': pCol(i) } }), h('span', { class: 't', text: pName(i) })),
          h('div', { class: 'sub' }, h('span', { class: 'pt-cc' }), h('b', { class: 'mono', text: String(st.h[i].length) }), tag));
        strip.append(chip);
      }
    }
    function renderScene() {
      // shelf (public cards)
      shelfEl.innerHTML = '';
      if (st.sh && st.ph !== 'e') { shelfEl.append(h('span', { text: '공개' })); for (const c of st.sh) shelfEl.append(img(ci(c))); shelfEl.hidden = false; }
      else shelfEl.hidden = true;
      // caption
      capEl.innerHTML = '';
      const f = focusTest();
      const v = viewer();
      if (st.ph === 'e') {
        capEl.append(h('span', { text: '금지된 물약: ' }), ...st.x.split('').map((c) => img(ci(c))), h('b', { text: comboName(Mm(), st.x) }));
      } else if (!f) {
        capEl.append(h('span', { text: '솥 안의 금지된 물약 재료 3개를 맞혀 보세요' }));
      } else {
        capEl.append(h('b', { text: pName(f.b) }), h('span', { text: f.live ? '시험' : '지난 시험' }), ...f.c.split('').map((c) => img(ci(c))), h('span', { text: '→' }),
          f.r < 0 ? h('b', { style: { color: 'var(--brass)' }, text: '아무도 없음!' })
            : h('span', null, h('b', { text: pName(f.r) }), st.ph === 's' && f.live ? ' 고르는 중' : (v >= 0 && (v === f.b || v === f.r) && f.k ? ' → ' + iname(ci(f.k)) : ' 1장 보여줌')));
      }
      // side: the shown card for the brewer / nobody badge / final secret
      sideEl.innerHTML = '';
      if (wrap.classList.contains('cmp')) return; // short screen with the big notebook: caption + highlighted cell instead
      if (st.ph === 'e') {
        const box = h('div', { class: 'pt-secret' }, ...st.x.split('').map((c) => cardEl(ci(c), true)));
        sideEl.append(box);
      } else if (st.ph === 'v' && f) {
        if (f.r < 0) sideEl.append(h('div', { class: 'pt-none', text: '아무도 못 보여줬어요' }));
        else if (v === st.t && st.k) sideEl.append(h('div', { class: 'pt-side' }, cardEl(ci(st.k), true), h('div', { class: 'who', text: pGa(st.r) + ' 보여줌' })));
      }
    }
    function cellInfo(K, i, v) {
      const p = K.P[i];
      if (p === 0) return { st: '공개 재료', cls: 'dead' };
      if (v >= 0 && p === 1 << v) return { st: '내 것', cls: 'mine dead' };
      if (p === K.CB) return { st: '★ 솥 정답', cls: 'ans' };
      if (single(p)) { const o = Math.log2(p) | 0; return { st: pName(o), dot: pCol(o), cls: 'dead' }; }
      if (!(p & K.CB)) return { st: '솥엔 없음', cls: 'dead' };
      const m = v >= 0 ? myMemo(v)[i] : 0;
      if (m === 1) return { st: '✗ 내 메모', cls: 'mx', unk: true };
      if (m === 2) return { st: '? 의심', cls: 'mq', unk: true };
      return { st: '모름', cls: '', unk: true };
    }
    let K = null;
    function renderBoard() {
      board.innerHTML = '';
      const v = viewer();
      K = know(st, v, 1);
      const so = solvedOf(K);
      const s3 = v >= 0 ? mySel(v) : [-1, -1, -1];
      const head = h('div', { class: 'pt-bh' }, h('span', { class: 'lbl', text: v >= 0 ? '추리 노트' : '공개 노트' }));
      if (v >= 0) {
        head.append(h('div', { class: 'pt-seg' },
          h('button', { class: 'pt-mpick' + (mode === 'pick' ? ' on' : ''), text: '고르기', onclick() { mode = 'pick'; api.sfx('click'); renderBoard(); renderBar(); } }),
          h('button', { class: 'pt-mmemo' + (mode === 'memo' ? ' on' : ''), text: '메모', onclick() { mode = 'memo'; api.sfx('click'); renderBoard(); renderBar(); } })));
      }
      head.append(h('button', { class: 'btn sm pt-log', text: '기록', onclick: showLog }),
        h('button', { class: 'pt-help', text: '?', 'aria-label': '노트 표시 설명', title: '노트 표시 설명', onclick: legend }));
      board.append(head);
      const grid = h('div', { class: 'pt-grid' });
      for (let k = 0; k < 3; k++) {
        const col = h('div', { class: 'pt-col', style: { '--cc': CAT_COL[k] } });
        col.append(h('div', { class: 'pt-ch' }, CATS[k] + ' ', h('span', { text: '후보 ' + so.cand[k].length })));
        for (let j = 0; j < st.m; j++) {
          const i = k * st.m + j;
          const inf = cellInfo(K, i, v);
          const fresh = st.ph === 'v' && v === st.t && st.k && ci(st.k) === i;
          const cell = h('button', { class: 'pt-cell ' + inf.cls + (s3[k] === i ? ' sel' : '') + (fresh ? ' fresh' : ''), 'aria-label': iname(i) + ', ' + inf.st, onclick: () => tapCell(i, inf) },
            img(i), h('div', { class: 'tx' }, h('span', { class: 'n', text: iname(i) }), h('span', { class: 'st' }, inf.dot ? h('i', { style: { '--c': inf.dot } }) : null, inf.st)));
          col.append(cell);
        }
        grid.append(col);
      }
      board.append(grid);
      // responder: choose a card to show
      if (st.ph === 's' && v === st.r && api.canAct(st.r)) {
        const M = showChoices(st, v), prev = shownBefore(st, v, st.t);
        const pop = h('div', { class: 'pt-pop' },
          h('div', { class: 'q' }, h('b', { text: pName(st.t) }), '의 시험 재료 중 내가 가진 게 있어요.', h('br'), '몰래 보여줄 재료 1장을 고르세요.'),
          h('div', { class: 'cards' }, ...M.map((i) => {
            const c = cardEl(i, false, prev.has(i) ? h('div', { class: 'rec', text: '전에 보여줌' }) : null);
            c.setAttribute('role', 'button'); c.setAttribute('aria-label', iname(i) + ' 보여주기');
            c.addEventListener('click', () => doAct({ t: 'show', k: i }));
            return c;
          })),
          h('div', { class: 'muted', style: { fontSize: '12px' }, text: M.length > 1 ? '이미 보여준 재료를 또 보여주면 새 정보를 덜 줘요' : '이 재료 하나뿐이라 이걸 보여줘야 해요' }));
        board.append(pop);
      }
    }
    function renderBar() {
      bar.innerHTML = '';
      const v = viewer();
      const hint = h('div', { class: 'pt-hint' });
      const btns = h('div', { class: 'pt-btns' });
      const so = K ? solvedOf(K) : { sol: null };
      const s3 = v >= 0 ? mySel(v) : [-1, -1, -1];
      const n3 = s3.filter((x) => x >= 0).length;
      const mine = v >= 0 && api.canAct(v) && actor(st) === v;
      const seated = v >= 0 && !st.o[v] && st.ph !== 'e';
      const solved = so.sol ? '★ 3개를 다 알아냈어요! 「정답 선언」을 누르면 이겨요' : '';
      if (st.ph === 'e') {
        hint.textContent = st.w >= 0 ? pGa(st.w) + (st.why === 'ok' ? ' 금지된 물약을 맞혔어요!' : ' 끝까지 남았어요!') : '아무도 못 맞혔어요';
      } else if (mine && st.ph === 'b') {
        hint.classList.add('mine');
        hint.textContent = solved
          || (mode === 'memo' ? '메모 중: 「모름」 재료를 탭할 때마다 ✗ → ? → 지우기. 시험하려면 「고르기」를 누르세요'
            : n3 === 0 ? '내 차례! 약초·광물·마법 생물 칸에서 재료를 1개씩 탭해 골라요 (「모름」 재료가 좋아요)'
              : n3 < 3 ? '좋아요, ' + n3 + '/3 골랐어요. 아직 안 고른 칸에서도 1개 골라 주세요'
                : '3개 다 골랐어요! 「시험 끓이기」를 누르면 다음 사람부터 확인해요');
      } else if (mine && st.ph === 'v') {
        hint.classList.add('mine');
        hint.textContent = solved
          || (st.r < 0 ? '아무도 못 보여줬어요! 고른 것 중 내 카드·공개 카드가 아닌 건 솥 정답! 「턴 끝내기」'
            : pGa(st.r) + ' 「' + iname(ci(st.k)) + '」 카드를 보여줬어요 → 솥에 없어요. 「턴 끝내기」를 누르세요');
      } else if (st.ph === 's') {
        if (mine) { hint.classList.add('mine'); hint.textContent = pName(st.t) + '의 시험 재료 중 내 카드가 있어요. 몰래 보여줄 1장을 탭하세요'; }
        else hint.textContent = pGa(st.r) + ' ' + pName(st.t) + '에게 몰래 보여줄 카드를 고르는 중…';
      } else if (st.ph === 'v') {
        hint.textContent = st.r < 0 ? '아무도 못 보여줬어요 — ' + pGa(st.t) + ' 결과를 보는 중'
          : v === st.r ? '내가 보여준 카드는 ' + pName(st.t) + '만 봤어요. 다른 사람은 무슨 카드인지 몰라요'
            : pName(st.t) + '만 카드를 봤어요. 나는 「' + pGa(st.r) + ' 셋 중 1장을 가졌다」만 알아요';
      } else {
        hint.textContent = solved && seated ? '정답은 이미 알아요! 내 차례가 오면 「정답 선언」'
          : pName(st.t) + ' 차례 — 누가 카드를 보여주는지 지켜보세요';
      }
      if (v >= 0 && st.o[v] && st.ph !== 'e') hint.textContent = '탈락했어요 — 남의 시험에 내 카드가 걸리면 계속 보여줘요';
      if (seated) {
        const canB = mine && st.ph === 'b', canV = mine && st.ph === 'v', wait = sentSeq === st.seq;
        btns.append(h('button', { class: 'btn pt-dec', text: '정답 선언', disabled: !(canB || canV) || wait, onclick: declare }),
          canV ? h('button', { class: 'btn primary pt-end', text: '턴 끝내기', disabled: wait, onclick: () => doAct({ t: 'end' }) })
            : h('button', { class: 'btn primary pt-brew', text: '시험 끓이기', disabled: !canB || n3 < 3 || wait, onclick: brew }));
      }
      bar.append(hint);
      if (btns.children.length) bar.append(btns);
    }
    function render() { if (!st) return; sizeCells(); renderStrip(); renderScene(); renderBoard(); renderBar(); }

    /* ---------- input ---------- */
    function doAct(a) {
      if (!st || sentSeq === st.seq || busy) return;
      sentSeq = st.seq; api.sfx('click'); api.buzz(12);
      api.act(a);
      if (st && sentSeq === st.seq) renderBar();
    }
    function tapCell(i, inf) {
      const v = viewer();
      if (v < 0) { toast('지금은 공개 정보만 보여요'); return; }
      if (mode === 'memo') {
        if (!inf.unk) { toast('자동으로 알아낸 재료예요'); return; }
        const m = myMemo(v); m[i] = (m[i] + 1) % 3; api.sfx('tick');
      } else {
        const s3 = mySel(v), k = catOf(i, Mm());
        s3[k] = s3[k] === i ? -1 : i; api.sfx('click');
      }
      renderBoard(); renderBar();
    }
    function brew() {
      const v = viewer(); const s3 = mySel(v);
      if (s3.some((x) => x < 0)) { toast('줄마다 하나씩 골라 주세요'); return; }
      const c = s3.slice();
      sel[v] = [-1, -1, -1];
      doAct({ t: 'test', c });
    }
    function declare() {
      const v = viewer(); if (v < 0) return;
      const so = solvedOf(know(st, v, 1));
      let s3 = mySel(v);
      if (so.sol && s3.some((x) => x < 0)) { sel[v] = so.sol.slice(); s3 = sel[v]; renderBoard(); }
      if (s3.some((x) => x < 0)) { toast('정답이라고 생각하는 재료를 줄마다 하나씩 골라 주세요'); mode = 'pick'; renderBoard(); return; }
      const sure = so.sol && so.sol.every((x, k) => x === s3[k]);
      const ov = h('div', { class: 'overlay', style: { zIndex: 30 } });
      const close = () => ov.remove();
      ov.append(h('div', { class: 'sheet', style: { gap: '12px' } },
        h('h2', { text: '정답 선언' }),
        h('div', { style: { display: 'flex', gap: '8px', justifyContent: 'center' } }, ...s3.map((i) => cardEl(i, true))),
        h('p', { style: { margin: 0, fontSize: '14px', color: sure ? 'var(--ok)' : 'var(--coral)' }, text: sure ? '노트로 보면 확실해요! 맞히면 바로 승리.' : '아직 확실하지 않아요. 틀리면 탈락해요(카드 보여주기는 계속).' }),
        h('div', { class: 'row', style: { display: 'flex', gap: '8px', justifyContent: 'flex-end' } },
          h('button', { class: 'btn ghost', text: '취소', onclick: close }),
          h('button', { class: 'btn ' + (sure ? 'primary' : 'danger'), text: '선언하기', onclick() { close(); doAct({ t: 'dec', c: s3.slice() }); } }))));
      ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
      root.append(ov);
    }
    function showLog() {
      api.sfx('click');
      const v = viewer();
      const lg = logOf(st);
      const items = [];
      for (let j = lg.length - 1; j >= 0; j--) {
        const e = lg[j], pass = passersOf(st.n, e.b, e.r);
        const li = h('li', null, h('b', { class: 'mono', text: (j + 1) + '. ' }), h('b', { text: pName(e.b) }), ' 시험 ',
          ...e.c.split('').map((c) => img(ci(c))), ' ' + comboName(Mm(), e.c), h('br'),
          e.r < 0 ? h('span', { style: { color: 'var(--brass)' }, text: '→ 아무도 없음' }) : h('span', null, '→ ', h('b', { text: pName(e.r) }), ' 보여줌' + ((v === e.b || v === e.r) && e.k ? ' (' + iname(ci(e.k)) + ')' : '')),
          pass.length ? h('span', { class: 'muted', text: ' · 없음: ' + pass.map(pName).join(', ') }) : null);
        items.push(li);
      }
      for (let j = 0; j + 4 <= st.dl.length; j += 4) {
        items.unshift(h('li', { style: { borderLeft: '3px solid var(--coral)' } }, h('b', { text: pName(+st.dl[j]) }), ' 선언 실패: ' + comboName(Mm(), st.dl.slice(j + 1, j + 4))));
      }
      if (!items.length) items.push(h('li', { class: 'muted', text: '아직 시험이 없어요' }));
      const ov = h('div', { class: 'overlay', style: { zIndex: 30 } });
      const close = () => ov.remove();
      ov.append(h('div', { class: 'sheet', style: { gap: '10px' } },
        h('div', { style: { display: 'flex', alignItems: 'center' } }, h('h2', { style: { fontSize: '22px', marginRight: 'auto' }, text: '시험 기록' }), h('span', { class: 'muted', style: { fontSize: '12px' }, text: '최근 것이 위' })),
        h('ul', { class: 'pt-list' }, ...items),
        h('button', { class: 'btn block', text: '닫기', onclick: close })));
      ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
      root.append(ov);
    }

    /* 「?」 — what each notebook mark means, drawn with real (inert) note cells */
    function legend() {
      api.sfx('click');
      const M = Mm(), v = viewer();
      const other = st ? [...Array(st.n).keys()].find((i) => i !== v) : 1;
      const sample = (i, cls, stx, dot) => h('div', { class: 'pt-cell ' + cls, 'aria-hidden': 'true' },
        img(i), h('div', { class: 'tx' }, h('span', { class: 'n', text: iname(i) }), h('span', { class: 'st' }, dot ? h('i', { style: { '--c': dot } }) : null, stx)));
      const row = (cell, text) => h('li', null, cell, h('span', { text }));
      const ov = h('div', { class: 'overlay', style: { zIndex: 30 } });
      const close = () => ov.remove();
      ov.append(h('div', { class: 'sheet', style: { gap: '10px' } },
        h('h2', { style: { fontSize: '22px' }, text: '노트 표시 읽는 법' }),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: '재료 이름 아래 작은 글씨가 지금까지 알아낸 것이에요. 노트가 자동으로 적어 줘요.' }),
        h('ul', { class: 'pt-leg' },
          row(sample(0, '', '모름'), '아직 몰라요. 솥에 있을 수 있는 후보예요. 시험할 때 이걸 고르세요!'),
          row(sample(1, 'mine dead', '내 것'), '내 카드예요. 내가 가졌으니 솥에 없어요.'),
          row(sample(M, 'dead', pName(other), pCol(other)), '그 사람이 가진 카드(보여줬거나 추리로 알아냄). 솥에 없어요.'),
          row(sample(M + 1, 'dead', '솥엔 없음'), '누가 가졌는지는 몰라도 솥에 없는 건 확실해요.'),
          row(sample(M + 2, 'dead', '공개 재료'), '선반에 공개된 카드예요. 솥에 없어요.'),
          row(sample(2 * M, 'ans', '★ 솥 정답'), '솥에 있는 게 확실해요! ★ 3개가 모이면 정답 선언.'),
          row(sample(2 * M + 1, 'mx', '✗ 내 메모'), '내가 「메모」로 단 표시: 아닐 것 같음.'),
          row(sample(2 * M + 2, 'mq', '? 의심'), '내가 「메모」로 단 표시: 수상함. (메모는 자동 추리와 상관없어요)'),
          row(sample(3, 'sel', '모름'), '✓ 테두리 = 지금 고른 재료(시험·선언에 써요). 다시 탭하면 취소.'),
          row(sample(4, 'fresh', pName(other), pCol(other)), '점선으로 깜빡임 = 방금 나에게 보여준 카드.')),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: '흐린 칸은 후보에서 빠진 재료예요. 칸 제목의 「후보 N」이 1이 되면 그 종류의 정답이 정해진 거예요.' }),
        h('button', { class: 'btn block', text: '닫기', onclick: close })));
      ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
      root.append(ov);
    }

    /* ---------- events / animation from state ---------- */
    function mixColor(cstr) {
      const cs = cstr.split('').map((c) => ingOf(Mm(), ci(c))[1]);
      const rgb = cs.map((hx) => [1, 3, 5].map((o) => parseInt(hx.slice(o, o + 2), 16)));
      return [0, 1, 2].map((k) => rgb.reduce((a, r) => a + r[k], 0) / rgb.length);
    }
    function animate(prev) {
      const e = st.last;
      if (!e) return;
      if (e.k === 'test') {
        const from = rel(chipEl(e.b)), to = potXY(), cstr = st.c;
        cstr.split('').forEach((c, j) => {
          const el = img(ci(c)); el.style.width = el.style.height = '40px';
          fly(el, { x: from.x + (j - 1) * 16, y: from.y }, { x: to.x + (j - 1) * 10, y: to.y }, { dur: 0.55 + j * 0.08, arc: 50, s0: 0.9, s1: 0.5, fade: true,
            done: j === 2 ? () => { liqT = mixColor(cstr); liqHold = 3; splash = 1; api.sfx('pop'); } : null });
        });
        api.sfx('whoosh');
        if (e.r < 0) setTimeout(() => { if (st && st.last && st.last.id === e.id) { toast('아무도 못 보여줬어요!'); } }, 700 / spd());
        busyFor(800);
      } else if (e.k === 'show') {
        const from = rel(chipEl(e.r)), to = rel(chipEl(e.b));
        fly(h('div', { class: 'pt-back' }), from, to, { dur: 0.55, arc: 26, s0: 1, s1: 0.8, fade: true, done: () => api.sfx('card') });
        const v = viewer();
        if (v === e.b) api.buzz(20);
        busyFor(650);
      } else if (e.k === 'miss') {
        toast(pName(e.s) + ' 선언 실패 — 탈락!');
        api.sfx('lose'); api.buzz(40);
        busyFor(900);
      } else if (e.k === 'win') {
        liqT = [255, 210, 90]; liqHold = 5; splash = 1.5;
        toast(pName(e.s) + ' 정답!'); api.sfx('chip');
        busyFor(1400);
      }
      void prev;
    }

    function update(state, prev) {
      st = state;
      if (!st) return;
      if (st.g !== gid) { gid = st.g; sel = {}; memo = {}; lastId = st.last ? st.last.id : -1; mode = 'pick'; render(); return; }
      if (st.seq !== sentSeq) sentSeq = -1;
      const id = st.last ? st.last.id : -1;
      const isNew = prev && prev !== state && id !== lastId;
      lastId = id;
      render();
      if (isNew) animate(prev);
    }
    // taller screens: bigger note cells
    let lastSz = '';
    function sizeCells() {
      const H = root.getBoundingClientRect().height, big = !!st && st.m === 8;
      const cell = big ? (H > 760 ? 46 : 44) : (H > 700 ? 50 : H > 600 ? 46 : 44);
      const cmp = big && H < 680, sh = !cmp && H < 640;
      const key = cell + '/' + cmp + '/' + sh;
      if (key === lastSz) return;
      lastSz = key;
      wrap.style.setProperty('--cellh', cell + 'px');
      wrap.classList.toggle('cmp', cmp);
      wrap.classList.toggle('sh', sh);
    }
    const ro = new ResizeObserver(sizeCells);
    ro.observe(root);

    return {
      update,
      destroy() {
        stopLoop(); ro.disconnect(); clearTimeout(busyT); if (busy) api.setBusy(false);
        flies.forEach((f) => f.el.remove()); flies.length = 0;
        cv.destroy(); wrap.remove(); style.remove();
        root.querySelectorAll('.pt-fly').forEach((e) => e.remove());
      },
    };
  }

  const ICON = '<path d="M9 24h38l-3 15c-1.5 7-7 10-16 10S13.5 46 12 39z" fill="currentColor"/>' +
    '<rect x="6" y="20" width="44" height="6" rx="3" fill="currentColor"/>' +
    '<rect x="15" y="48" width="5" height="5" rx="1" fill="currentColor"/><rect x="36" y="48" width="5" height="5" rx="1" fill="currentColor"/>' +
    '<circle cx="18" cy="13" r="3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="26" cy="8" r="2" fill="currentColor"/>' +
    '<path d="M31 10a5 5 0 1 1 7 4.6c-1.5.7-2 1.6-2 3.4" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>' +
    '<circle cx="36" cy="21.5" r="0.1" fill="currentColor"/>';

  L.register({
    id: 'potion', name: '마법 물약 추리', tag: '추리 · 숨긴 카드', cat: '보드', hidden: true,
    icon: ICON, tint: '#40266a',
    blurb: '솥에 숨은 금지된 물약 재료 3개(약초·광물·마법 생물)를 맞혀요. 재료를 시험해 보면 가진 사람이 나에게만 몰래 1장 보여줘요.',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, aiDelay: 1000,
    options: [
      { id: 'size', label: '재료 수', choices: [{ v: 'n', label: '보통 (종류마다 6개)' }, { v: 'l', label: '재료 많이 (종류마다 8개)' }], def: 'n' },
    ],
    quick: [
      '솥에 숨은 재료 3장(약초 1 · 광물 1 · 마법 생물 1)이 무엇인지 가장 먼저 맞히면 이겨요.',
      '내 차례: 칸마다 재료 1개씩 골라 「시험 끓이기」 → 그중 하나를 가진 사람이 나에게만 몰래 1장 보여줘요.',
      '보여준 카드는 솥에 없어요. 후보를 지워 3개가 확실해지면 「정답 선언」(한 번뿐, 틀리면 탈락).',
    ],
    rules: [
      { h: '목표', p: [
        '솥 안에 「금지된 물약」 재료 카드 3장이 숨어 있어요: 약초 1장, 광물 1장, 마법 생물 1장.',
        '이 3장이 무엇인지 가장 먼저 맞히는 사람이 이겨요.',
        '재료는 3종류예요: 약초(초록) · 광물(파랑) · 마법 생물(빨강). 종류마다 6개씩, 모두 18개.'] },
      { h: '준비 (자동으로 해 줘요)', p: [
        '① 종류마다 1장씩 몰래 뽑아 솥에 넣어요. 아무도 몰라요.',
        '② 남은 카드를 섞어 모두에게 똑같이 나눠 줘요. 내 카드는 노트에 「내 것」(금색 칸)으로 보여요. 내가 가진 재료는 당연히 솥에 없어요.',
        '③ 똑같이 나누고 남는 카드는 솥 그림 왼쪽 위 「공개」 선반에 올려 모두가 봐요. 공개 카드도 솥에 없어요.',
        '한 사람 카드 수(보통): 2명 7장(공개 1) · 3명 5장 · 4명 3장(공개 3) · 5명 3장 · 6명 2장(공개 3).'] },
      { h: '내 차례 ① 시험하기', p: [
        '① 아래 노트에서 약초 칸 · 광물 칸 · 마법 생물 칸마다 재료를 1개씩 탭해 모두 3개를 골라요. 고른 재료엔 ✓ 표시가 붙어요(다시 탭하면 취소).',
        '② 「시험 끓이기」를 누르면 3개가 솥으로 날아가요.',
        '③ 내 다음 사람부터 차례대로 확인해요. 3개 중 하나도 없는 사람은 「없음」으로 통과해요.',
        '④ 하나라도 가진 첫 사람이 그중 1장을 나에게만 몰래 보여주고, 확인은 거기서 끝나요. (여러 장 가졌으면 무엇을 보여줄지는 그 사람이 골라요.)',
        '⑤ 결과를 보고 「턴 끝내기」를 누르면 다음 사람 차례예요. 바로 「정답 선언」을 해도 돼요.',
        '내 카드를 섞어서 시험해도 돼요. 내 카드는 아무도 보여줄 수 없으니, 나머지 재료만 콕 집어 떠볼 수 있어요.'] },
      { h: '내 차례 ② 다른 사람이 몰래 보여 주기', p: [
        '남이 시험한 재료 중 내 카드가 있으면, 내 차례가 아니어도 화면에 카드가 떠요. 보여줄 1장을 탭하세요.',
        '그 카드는 시험한 사람만 봐요. 나머지 사람들은 「누가 보여줬는지」만 알고, 무슨 카드인지는 몰라요.',
        '같은 사람에게 전에 보여준 카드(「전에 보여줌」 표시)를 또 보여주면 새 정보를 덜 줘서 유리해요.',
        '한 폰으로 여럿이 할 때는 차례마다 가림막이 떠요. 보여줄 사람에게 폰을 넘겨 주세요.'] },
      { h: '추리 노트 읽는 법', p: [
        '노트는 알아낸 것을 자동으로 적어 줘요. 재료 이름 아래 작은 글씨를 보세요.',
        '「모름」 — 아직 몰라요. 솥에 있을 수 있는 후보예요. 시험할 땐 이걸 고르세요.',
        '「내 것」(금색 칸) — 내 카드. 솥에 없어요.',
        '사람 이름(색 점) — 그 사람이 가진 카드. 나에게 보여줬거나 추리로 알아냈어요. 솥에 없어요.',
        '「솥엔 없음」 — 누가 가졌는지는 몰라도 솥에 없는 건 확실해요.',
        '「공개 재료」 — 선반에 공개된 카드. 솥에 없어요.',
        '「★ 솥 정답」(금빛 칸) — 솥에 있는 게 확실해요!',
        '「✗ 내 메모」 「? 의심」 — 「메모」를 누른 뒤 「모름」 재료를 탭해 내가 직접 다는 표시예요(탭할 때마다 ✗ → ? → 지우기).',
        '흐린 칸 = 후보에서 빠진 재료. 칸 제목의 「후보 N」이 1이 되면 그 종류의 정답이 정해진 거예요.',
        '점선으로 깜빡이는 칸 = 방금 나에게 보여준 카드.',
        '게임 중에 노트 위 「?」를 누르면 이 설명을 그림과 함께 볼 수 있어요. 「기록」에는 지난 시험이 모두 있어요.'] },
      { h: '정답 선언', p: [
        '언제: 내 차례에 시험 대신, 또는 시험 결과를 본 뒤에 「정답 선언」을 눌러요.',
        '칸마다 1개씩 고른 3개가 내 답이에요. 노트에 ★ 3개가 다 떴다면 덜 고른 칸은 ★ 재료로 자동으로 채워져요.',
        '맞히면: 솥 속 3장이 공개되고 바로 승리!',
        '틀리면: 탈락이에요. 더는 시험·선언을 못 하지만, 남의 시험에 내 카드가 걸리면 계속 보여줘야 해요.',
        '선언은 한 게임에 한 번뿐이에요. ★가 3개일 때 하는 게 가장 안전해요.',
        '다른 사람이 모두 탈락하면 혼자 남은 사람이 이겨요. ' + CAP + '번 시험까지 아무도 못 맞히면 무승부.'] },
      { h: '작전 팁', p: [
        '보여준 카드 = 솥에 없음. 이렇게 후보를 하나씩 지우는 게 기본이에요.',
        '「없음」으로 통과한 사람은 그 3개를 하나도 안 가졌다는 뜻이에요. 노트가 자동으로 반영해요.',
        '아무도 못 보여주면 대박! 고른 3개 중 내 카드·공개 카드가 아닌 건 전부 솥 정답이에요.',
        '내 카드 2장 + 모르는 재료 1장으로 시험하면, 그 1장이 누구에게 있는지(또는 솥에 있는지) 정확히 알 수 있어요.',
        '남의 시험도 지켜보세요. 누가 보여줬는지만 알아도 노트가 추리해 줘요.'] },
      { h: '예시', p: [
        '내가 [루비 · 달빛꽃 · 용 비늘]로 시험 → AI 1은 셋 다 없어서 「없음」 통과 → AI 2가 한 장을 나에게 몰래 보여줌: 「루비」.',
        '→ 나는 알아요: 루비는 AI 2 것(솥에 없음). 또 AI 1은 달빛꽃·용 비늘을 안 가졌어요.',
        '→ 다른 사람들은 「AI 2가 셋 중 1장을 가졌다」만 알아요.',
        '다음 차례에 [사파이어 · 달빛꽃 · 용 비늘]로 시험 → 아무도 못 보여줌!',
        '→ 셋 다 내 카드도 공개 카드도 아니니 모두 솥 정답이에요. 노트에 ★ 3개 → 「정답 선언」으로 승리!'] },
      { h: '재료 많이 옵션', p: [
        '설정의 「재료 수」에서 「재료 많이」를 고르면 종류마다 8개, 모두 24개가 돼요(종소리꽃 · 가시덩굴 · 흑요석 · 호박석 · 달팽이 집 · 여우 꼬리 추가).',
        '후보가 많아서 판이 길고 추리가 더 깊어요. 익숙해지면 도전해 보세요.',
        '한 사람 카드 수(재료 많이): 2명 10장(공개 1) · 3명 7장 · 4명 5장(공개 1) · 5명 4장(공개 1) · 6명 3장(공개 3).'] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움: 보여준 카드만 기억하고, 가끔 성급하게 선언했다가 탈락해요.',
        '보통: 노트처럼 추리해요.',
        '어려움: 남의 시험까지 깊이 따져 보고, 정보가 가장 많이 나오는 조합으로 떠봐요. 보여줄 카드도 아껴요.'] },
    ],
    tutorial: [
      { sel: '.pt-scene', text: '이 솥 안에 재료 카드 3장이 숨어 있어요: 약초 1 · 광물 1 · 마법 생물 1. 이 3장을 가장 먼저 맞히면 이겨요!' },
      { sel: '.pt-grid', text: '아래는 내 추리 노트예요. 세로 칸 하나가 한 종류(약초 · 광물 · 마법 생물)예요. 재료 이름 아래에 지금 아는 것이 적혀요.' },
      { sel: '.pt-cell.mine', text: '「내 것」은 내가 가진 카드예요. 내 손에 있으니 솥에는 없어요. 「모름」인 재료가 솥에 있을 수 있는 후보예요.' },
      { sel: '.pt-col', text: '내 차례엔 칸마다 재료를 1개씩 탭해 모두 3개를 골라요. 「모름」 재료를 고를수록 많이 알아내요.' },
      { sel: '.pt-brew', text: '3개를 고르면 「시험 끓이기」! 내 다음 사람부터 확인해서, 그중 하나라도 가진 첫 사람이 나에게만 1장을 몰래 보여줘요.' },
      { sel: '.pt-strip', text: '위 이름표에 「없음」(셋 다 없음) · 「보여줌」이 떠요. 다른 사람들은 누가 보여줬는지만 알고, 무슨 카드인지는 몰라요.' },
      { sel: '.pt-help', text: '보여준 카드는 노트에 그 사람 이름으로 자동으로 적혀요(= 솥에 없음). 표시가 헷갈리면 「?」를 눌러 보세요.' },
      { sel: '.pt-dec', text: '노트에 「★ 솥 정답」이 3개 모이면 「정답 선언」! 맞히면 승리, 틀리면 탈락이에요. 선언은 한 번뿐!' },
      { sel: '.pt-hint', text: '막히면 이 안내 줄을 보세요. 지금 할 일을 알려 줘요. 그럼 시작해 볼까요?' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { know, solvedOf, logOf, passersOf, responder, ING, CAP, cc, ci, chooseTest, chooseShow },
  });
})();
