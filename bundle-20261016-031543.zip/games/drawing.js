/* 그림 맞히기 — draw-and-guess party game (humans only).
   Online: the drawer's phone publishes its whole drawing as compact base64 strokes through api.net.publish
   (latest-wins presence); everyone else renders api.net.remote()[drawer]. Guesses are typed actions from
   array actors; the host validates them. Timers (pick / draw / reveal) are advanced by the host's view
   through api.setState(tick(...)), because only the host may change state and no seat "owns" a timeout.
   Local (one phone): the drawer peeks at the word behind a curtain, draws, others guess aloud and the
   drawer taps who got it. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- word lists (everyday, drawable, no brands / characters) ---------- */
  const CATS = [
    { id: 'animal', name: '동물', w: '고양이 강아지 토끼 호랑이 사자 코끼리 기린 원숭이 펭귄 거북이 뱀 개구리 상어 고래 돌고래 문어 오징어 게 나비 벌 개미 거미 달팽이 부엉이 독수리 오리 닭 병아리 돼지 소 말 양 염소 쥐 다람쥐 너구리 여우 늑대 곰 판다 캥거루 코알라 하마 악어 낙타 얼룩말 사슴 박쥐 공작 홍학 앵무새 해파리 불가사리 고슴도치' },
    { id: 'food', name: '음식', w: '김밥 라면 떡볶이 피자 햄버거 치킨 핫도그 샌드위치 케이크 아이스크림 도넛 쿠키 식빵 계란후라이 삶은달걀 밥 김치 만두 국수 짜장면 비빔밥 초밥 스테이크 소시지 감자튀김 팝콘 사탕 초콜릿 솜사탕 와플 팬케이크 샐러드 수프 카레 우유 주스 커피 떡 붕어빵 호떡 꼬치 젤리 푸딩 주먹밥 김치찌개 삼겹살' },
    { id: 'fruit', name: '과일·채소', w: '사과 바나나 딸기 포도 수박 참외 복숭아 배 귤 레몬 파인애플 체리 키위 망고 감 밤 코코넛 블루베리 석류 아보카도 토마토 당근 감자 고구마 양파 마늘 오이 호박 가지 양배추 배추 브로콜리 옥수수 버섯 고추 파프리카 시금치 콩나물 무 대파 완두콩 연근 땅콩 멜론' },
    { id: 'thing', name: '사물', w: '의자 책상 침대 시계 거울 우산 열쇠 자물쇠 가위 안경 컵 숟가락 젓가락 포크 냄비 프라이팬 전화기 텔레비전 컴퓨터 카메라 전구 양초 선풍기 냉장고 세탁기 청소기 다리미 칫솔 치약 수건 비누 베개 이불 가방 지갑 풍선 연필 망치 사다리 바구니 상자 리모컨 휴지 액자 빗자루 쓰레기통 저울' },
    { id: 'ride', name: '탈것', w: '자동차 버스 택시 트럭 기차 지하철 비행기 헬리콥터 돛단배 잠수함 자전거 오토바이 킥보드 스케이트보드 로켓 열기구 소방차 구급차 경찰차 굴착기 지게차 트랙터 유모차 마차 썰매 케이블카 롤러코스터 카누 뗏목 우주선 낙하산 캠핑카 견인차 덤프트럭 레미콘 인력거 모노레일 휠체어 유람선 세발자전거 행글라이더 크레인' },
    { id: 'job', name: '직업', w: '의사 간호사 경찰관 소방관 요리사 선생님 가수 화가 농부 어부 집배원 미용사 버스기사 조종사 우주비행사 과학자 마술사 광대 사진작가 제빵사 기자 판사 군인 목수 정원사 수의사 치과의사 약사 배우 축구선수 야구선수 발레리나 피아니스트 지휘자 탐정 택배기사 환경미화원 승무원 경비원 프로그래머 건축가 디자이너 바리스타 잠수부' },
    { id: 'place', name: '장소', w: '학교 병원 공원 놀이터 도서관 박물관 동물원 수족관 놀이공원 영화관 식당 카페 빵집 시장 마트 은행 우체국 경찰서 소방서 공항 기차역 버스정류장 항구 바다 산 섬 사막 정글 동굴 성 등대 다리 터널 캠핑장 수영장 목욕탕 미용실 주유소 아파트 화장실 부엌 운동장 엘리베이터 피라미드' },
    { id: 'sport', name: '스포츠', w: '축구 야구 농구 배구 테니스 탁구 배드민턴 골프 볼링 수영 스키 스노보드 스케이트 피겨스케이팅 아이스하키 권투 태권도 유도 씨름 레슬링 펜싱 양궁 사격 역도 마라톤 줄넘기 훌라후프 서핑 다이빙 승마 사이클 클라이밍 낚시 당구 다트 체조 럭비 핸드볼 컬링 스카이다이빙 줄다리기 요가 달리기 등산' },
    { id: 'nature', name: '자연·날씨', w: '해 달 별 구름 비 눈 무지개 번개 바람 태풍 회오리바람 안개 우박 눈사람 고드름 화산 폭포 호수 파도 나무 꽃 나뭇잎 단풍잎 장미 해바라기 튤립 선인장 잔디 바위 모래성 조개 별똥별 오로라 은하수 노을 일출 빙하 연못 소나무 벚꽃 민들레 행성 지구 강' },
    { id: 'verb', name: '행동', w: '달리다 걷다 점프하다 수영하다 자다 먹다 마시다 웃다 울다 노래하다 춤추다 읽다 쓰다 요리하다 청소하다 박수치다 손흔들다 하품하다 재채기하다 낚시하다 운전하다 던지다 차다 잡다 밀다 당기다 줍다 숨다 기도하다 생각하다 화내다 놀라다 넘어지다 기어가다 날다 미끄러지다 양치하다 세수하다 샤워하다 사진찍다 전화하다 포옹하다 줄서다 낮잠자다' },
    { id: 'music', name: '악기', w: '피아노 기타 바이올린 첼로 드럼 트럼펫 플루트 하모니카 탬버린 실로폰 리코더 색소폰 트롬본 하프 아코디언 우쿨렐레 캐스터네츠 트라이앵글 북 장구 꽹과리 징 가야금 거문고 해금 대금 단소 피리 마라카스 오카리나 호른 튜바 클라리넷 오보에 콘트라베이스 심벌즈 팀파니 오르간 마림바 칼림바 봉고 메트로놈 소고' },
    { id: 'body', name: '신체', w: '눈 코 입 귀 머리 머리카락 눈썹 속눈썹 이마 볼 턱 이빨 혀 목 어깨 팔 팔꿈치 손 손가락 손톱 엄지 가슴 배 배꼽 허리 엉덩이 다리 무릎 발 발가락 발뒤꿈치 뼈 심장 뇌 폐 근육 콧수염 수염 보조개 주먹 입술 콧구멍' },
    { id: 'wear', name: '옷·패션', w: '모자 티셔츠 셔츠 바지 청바지 반바지 치마 원피스 코트 패딩 조끼 넥타이 나비넥타이 양말 장갑 목도리 스카프 운동화 구두 샌들 장화 슬리퍼 하이힐 벨트 선글라스 귀걸이 목걸이 반지 팔찌 손목시계 배낭 우비 수영복 잠옷 앞치마 왕관 머리띠 리본 단추 지퍼 비니 한복 턱시도' },
    { id: 'school', name: '학교', w: '칠판 분필 교과서 공책 지우개 필통 자 각도기 컴퍼스 크레파스 물감 붓 풀 책가방 실내화 급식 교실 사물함 출석부 시험지 성적표 졸업장 졸업식 입학식 운동회 소풍 지구본 현미경 과학실 음악실 체육복 칠판지우개 교장선생님 학생 시간표 방학 숙제 받아쓰기 계단 연필깎이 스케치북 돋보기 실험복' },
  ].map((c) => Object.assign(c, { words: c.w.split(' ') }));

  const PICK_MS = 20000, REVEAL_MS = 5000, CHOICES = 3, FEED_MAX = 5, GUESS_MAX = 12;
  const STATE_MAX = 1000; // worst-case UTF-8 bytes of the state (checked by tests)
  const GUEST_INK = 3500; // drawing budget in bytes, lowered online so the host's presence slot (state+lobby+drawing) stays < 4096
  const clock = { now: () => Date.now() };

  /* ---------- word obfuscation (keeps the answer out of plain sight in the shared state) ---------- */
  function prng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function keyOf(s) { return (s.g ^ Math.imul(s.ti + 1, 0x9E3779B1)) >>> 0; }
  function enc(str, key) {
    const r = prng(key); let bin = '';
    for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i) ^ ((r() * 65536) | 0); bin += String.fromCharCode(c >> 8, c & 255); }
    return btoa(bin);
  }
  function dec(b64, key) {
    try {
      const bin = atob(b64 || ''), r = prng(key); let out = '';
      for (let i = 0; i + 1 < bin.length; i += 2) out += String.fromCharCode(((bin.charCodeAt(i) << 8) | bin.charCodeAt(i + 1)) ^ ((r() * 65536) | 0));
      return out;
    } catch (e) { return ''; }
  }

  /* ---------- guess checking ---------- */
  function norm(t) { return String(t || '').normalize('NFC').replace(/[\s.,!?~'"`·\-_()]/g, '').toLowerCase(); }
  function answers(word, ci) {
    const a = [norm(word)];
    if (CATS[ci] && CATS[ci].id === 'verb' && word.endsWith('다')) {
      const stem = word.slice(0, -1);
      a.push(norm(stem + '기'));
      if (word.endsWith('하다')) a.push(norm(word.slice(0, -2)));
    }
    return a;
  }
  function jamo(s) {
    const out = [];
    for (const ch of s) {
      const c = ch.charCodeAt(0);
      if (c >= 0xAC00 && c <= 0xD7A3) { const i = c - 0xAC00; out.push('c' + Math.floor(i / 588), 'v' + Math.floor((i % 588) / 28)); if (i % 28) out.push('j' + (i % 28)); }
      else out.push(ch);
    }
    return out;
  }
  function lev(a, b) {
    const m = a.length, n = b.length; let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[n];
  }
  /* "아깝다" — one jamo off, or (for words of 3+ syllables) one syllable off */
  function isClose(guess, word) {
    const g = norm(guess), w = norm(word);
    if (!g || g === w) return false;
    if (lev(jamo(g), jamo(w)) <= 1) return true;
    return [...w].length >= 3 && lev([...g], [...w]) <= 1;
  }

  /* ---------- rules / state ---------- */
  function seatsFill(n, v) { return Array.from({ length: n }, () => v); }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, now = clock.now();
    const hm = players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0);
    const ci = CATS.findIndex((c) => c.id === opts.cat);
    const rd = [1, 2, 3].includes(opts.rounds) ? opts.rounds : 2;
    const lim = [60, 80, 100].includes(opts.time) ? opts.time : 80;
    const s = { n, nm: players.map((p) => String(p.name || '').slice(0, 10)), hm, k: ci, rd, lim, g: Math.floor(Math.random() * 2e9), ti: 0, tt: rd * hm.length, ph: 'pick', dr: -1,
      sc: seatsFill(n, 0), gp: seatsFill(n, -1), fd: [], u: '', ch: null, cc: null, w: null, wc: -1, pt: 0, hi: 0, rv: null, why: null,
      t0: now, ts: now, seq: 0, last: null };
    if (hm.length < 2) { s.ph = 'x'; s.tt = 0; return s; }
    return setupPick(s, now);
  }
  function usedSet(s) { const set = new Set(); for (let i = 0; i + 1 < s.u.length; i += 2) set.add(parseInt(s.u.slice(i, i + 2), 36)); return set; }
  function chooseWords(s) {
    const used = usedSet(s);
    const usedStr = new Set([...used].map((id) => CATS[id >> 6] && CATS[id >> 6].words[id & 63]));
    const pool = (ci) => CATS[ci].words.map((w, wi) => ({ ci, wi, w })).filter((x) => !used.has((x.ci << 6) | x.wi) && !usedStr.has(x.w));
    const out = [];
    if (s.k >= 0) {
      let p = pool(s.k);
      if (p.length < CHOICES) p = CATS[s.k].words.map((w, wi) => ({ ci: s.k, wi, w }));
      U.shuffle(p); out.push(...p.slice(0, CHOICES));
    } else {
      const cats = U.shuffle(CATS.map((_, i) => i));
      for (const ci of cats) {
        if (out.length >= CHOICES) break;
        let p = pool(ci).filter((x) => !out.some((o) => o.w === x.w)); if (!p.length) p = CATS[ci].words.map((w, wi) => ({ ci, wi, w })).filter((x) => !out.some((o) => o.w === x.w));
        if (p.length) out.push(p[U.rand(p.length)]);
      }
    }
    return out;
  }
  function setupPick(s, now) {
    s.dr = s.hm[s.ti % s.hm.length];
    const ws = chooseWords(s), key = keyOf(s);
    s.ch = ws.map((x) => enc(x.w, key)); s.cc = ws.map((x) => x.ci);
    ws.forEach((x) => { s.u += ((x.ci << 6) | x.wi).toString(36).padStart(2, '0'); });
    s.ph = 'pick'; s.gp = seatsFill(s.n, -1); s.fd = []; s.w = null; s.wc = -1; s.pt = 0; s.hi = 0; s.rv = null; s.why = null;
    s.t0 = now; s.ts = now; s.seq++; s.last = { id: s.seq, k: 'turn', s: s.dr };
    return s;
  }
  function doPick(s, i, now) {
    const key = keyOf(s), word = dec(s.ch[i], key);
    s.w = enc(word, key); s.wc = s.cc[i]; s.pt = word.length; s.hi = U.rand(word.length);
    s.ch = null; s.cc = null; s.ph = 'draw'; s.t0 = now; s.ts = now;
    s.seq++; s.last = { id: s.seq, k: 'pick', s: s.dr };
    return s;
  }
  function guessers(s) { return s.hm.filter((i) => i !== s.dr); }
  function reveal(s, why, now) {
    s.ph = 'reveal'; s.rv = dec(s.w, keyOf(s)); s.why = why; s.t0 = now; s.ts = now;
    s.seq++; s.last = { id: s.seq, k: 'rev' };
    return s;
  }
  function nextTurn(s, now) {
    s.ti++;
    if (s.ti >= s.tt) { s.ph = 'end'; s.ch = null; s.cc = null; s.ts = now; s.seq++; s.last = { id: s.seq, k: 'end' }; return s; }
    return setupPick(s, now);
  }
  function guessPts(s, now) {
    const el = U.clamp(now - s.t0, 0, s.lim * 1000);
    return Math.max(3, Math.round(10 - (7 * el) / (s.lim * 1000)));
  }
  function score(s, seat, now) {
    const p = guessPts(s, now);
    s.gp[seat] = p; s.sc[seat] += p; // the drawer never scores: everyone draws equally often, only guessing counts
    pushFeed(s, [seat, 1, '']);
    s.seq++; s.last = { id: s.seq, k: 'ok', s: seat, p };
    if (guessers(s).every((i) => s.gp[i] >= 0)) reveal(s, 'all', now);
  }
  function pushFeed(s, e) { s.fd.push(e); while (s.fd.length > FEED_MAX) s.fd.shift(); }

  function actor(s) {
    if (s.ph === 'pick') return s.dr;
    if (s.ph === 'draw') return [s.dr].concat(guessers(s).filter((i) => s.gp[i] < 0));
    return null;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (a.type === 'ping') return null; // no-op (see primeGuest in the view); core ignores a null result
    const now = clock.now();
    if (a.type === 'pick') {
      if (s.ph !== 'pick' || seat !== s.dr) throw new Error('not picking');
      const i = a.i | 0; if (i < 0 || i >= s.ch.length) throw new Error('bad choice');
      return doPick(s, i, now);
    }
    if (s.ph !== 'draw') throw new Error('not drawing');
    if (a.type === 'guess') {
      if (seat === s.dr || !s.hm.includes(seat) || s.gp[seat] >= 0) throw new Error('cannot guess');
      const t = String(a.t || '').replace(/\s+/g, ' ').trim().slice(0, GUESS_MAX);
      if (!norm(t)) throw new Error('empty');
      const word = dec(s.w, keyOf(s));
      if (answers(word, s.wc).includes(norm(t))) score(s, seat, now);
      else {
        const near = isClose(t, word);
        pushFeed(s, [seat, near ? 2 : 0, t]);
        s.seq++; s.last = { id: s.seq, k: near ? 'near' : 'no', s: seat };
      }
    } else if (a.type === 'award') {
      if (seat !== s.dr) throw new Error('only drawer awards');
      const t = a.s | 0;
      if (t === s.dr || !s.hm.includes(t) || s.gp[t] >= 0) throw new Error('bad award');
      score(s, t, now);
    } else if (a.type === 'end') {
      if (seat !== s.dr) throw new Error('only drawer ends');
      reveal(s, guessers(s).some((i) => s.gp[i] >= 0) ? 'end' : 'none', now);
    } else throw new Error('bad action');
    s.ts = now;
    return s;
  }
  /* host-only clock: returns a new state when time moved the game on, else null.
     ctx = {online, isAi(seat)} — seats whose player left (now AI) are skipped. */
  function tick(s, now, ctx) {
    const isAi = (ctx && ctx.isAi) || (() => false);
    if (s.ph === 'pick') {
      if (isAi(s.dr)) return nextTurn(s, now);
      if (ctx && ctx.online && now - s.t0 >= PICK_MS) return doPick(s, 0, now);
    } else if (s.ph === 'draw') {
      if (isAi(s.dr)) return reveal(s, 'left', now);
      if (now - s.t0 >= s.lim * 1000) return reveal(s, 'time', now);
      if (guessers(s).every((i) => s.gp[i] >= 0 || isAi(i))) return reveal(s, 'all', now);
    } else if (s.ph === 'reveal') {
      if (now - s.t0 >= REVEAL_MS) return nextTurn(s, now);
    }
    return null;
  }
  function result(s) {
    if (s.ph === 'x') return { winners: [], title: '그림 맞히기는 사람끼리만 할 수 있어요', text: 'AI는 그림을 그리거나 맞힐 수 없어요.\n설정에서 2명 이상을 ‘사람’으로 정해 주세요.' };
    if (s.ph !== 'end') return null;
    const best = Math.max(...s.hm.map((i) => s.sc[i]));
    const order = s.hm.slice().sort((a, b) => s.sc[b] - s.sc[a]);
    const winners = best > 0 ? s.hm.filter((i) => s.sc[i] === best) : []; // nobody guessed anything: a draw
    const rank = (i) => 1 + s.hm.filter((j) => s.sc[j] > s.sc[i]).length; // ties share a place
    const lines = order.map((i) => rank(i) + '위 ' + s.nm[i] + ' ' + s.sc[i] + '점');
    const each = s.hm.length ? s.tt / s.hm.length : 0;
    const head = '모두 ' + each + '번씩 그렸고, 맞힌 점수로만 순위를 정해요.';
    return { winners, text: head + '\n' + lines.join('\n') };
  }

  /* ---------- stroke encoding: 0–255 grid, RDP-simplified, one base64 string per stroke ---------- */
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const COLORS = ['#26221f', '#e0453a', '#f39a2b', '#f2cd2e', '#3a9d4c', '#2f6fd6', '#8a4fc9', '#8b5a32'];
  const COLOR_NAMES = ['검정', '빨강', '주황', '노랑', '초록', '파랑', '보라', '갈색'];
  const ERASER = 8;
  const SIZES = [0.011, 0.024, 0.048]; // fraction of paper width
  const PAPER_ASPECT = 1.1; // height / width, identical on every device so drawings line up
  function rdp(p, eps) {
    const n = p.length / 2;
    if (n < 3) return p.slice();
    const keep = new Uint8Array(n); keep[0] = keep[n - 1] = 1;
    const stack = [[0, n - 1]];
    while (stack.length) {
      const [a, b] = stack.pop();
      const ax = p[2 * a], ay = p[2 * a + 1], bx = p[2 * b], by = p[2 * b + 1];
      const dx = bx - ax, dy = by - ay, len = Math.hypot(dx, dy);
      let md = -1, mi = -1;
      for (let i = a + 1; i < b; i++) {
        const d = len < 1e-9 ? Math.hypot(p[2 * i] - ax, p[2 * i + 1] - ay) : Math.abs(dy * p[2 * i] - dx * p[2 * i + 1] + bx * ay - by * ax) / len;
        if (d > md) { md = d; mi = i; }
      }
      if (md > eps) { keep[mi] = 1; stack.push([a, mi], [mi, b]); }
    }
    const out = [];
    for (let i = 0; i < n; i++) if (keep[i]) out.push(p[2 * i], p[2 * i + 1]);
    return out;
  }
  /* normalized float points [x,y,...] (0..1) → simplified 0–255 ints */
  function quant(fp) {
    const q = [];
    for (let i = 0; i < fp.length; i += 2) {
      const x = U.clamp(Math.round(fp[i] * 255), 0, 255), y = U.clamp(Math.round(fp[i + 1] * 255), 0, 255);
      if (q.length && q[q.length - 2] === x && q[q.length - 1] === y) continue;
      q.push(x, y);
    }
    return rdp(q, 0.9);
  }
  function encStroke(st) { let bin = ''; for (const v of st.p) bin += String.fromCharCode(v); return B64[st.c * 3 + st.s] + btoa(bin); }
  function decStroke(str) {
    if (typeof str !== 'string' || str.length < 2) return null;
    const h = B64.indexOf(str[0]); if (h < 0 || h >= 27) return null;
    let bin; try { bin = atob(str.slice(1)); } catch (e) { return null; }
    if (bin.length < 2) return null;
    const p = []; for (let i = 0; i + 1 < bin.length; i += 2) p.push(bin.charCodeAt(i), bin.charCodeAt(i + 1));
    return { c: Math.floor(h / 3), s: h % 3, p };
  }
  function drawingSize(k, list) { return JSON.stringify({ k, d: list }).length; }
  function utf8Len(str) { let n = 0; for (const ch of str) { const c = ch.codePointAt(0); n += c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4; } return n; }
  /* same ink for everyone: what still fits next to the host's state + lobby in one 4 KiB presence slot */
  function inkBudgetFor(lobbyBytes) { return Math.max(1200, Math.min(GUEST_INK, 4096 - STATE_MAX - (lobbyBytes | 0) - 300)); }

  /* ---------- view ---------- */
  const CSS = `
.dr-top{position:absolute;left:0;right:0;top:0;z-index:3;padding:8px 10px 0;display:flex;flex-direction:column;gap:6px;pointer-events:none}
.dr-top>*{pointer-events:auto}
.dr-scores{display:flex;gap:5px;overflow-x:auto;scrollbar-width:none;padding-bottom:1px}
.dr-scores::-webkit-scrollbar{display:none}
.dr-chip{display:inline-flex;align-items:center;gap:5px;flex:none;padding:3px 9px 3px 7px;border-radius:999px;background:var(--surface);border:1px solid var(--line);font-size:12px;font-weight:700;white-space:nowrap;max-width:130px}
.dr-chip .nm{overflow:hidden;text-overflow:ellipsis}
.dr-chip b{font-family:var(--f-mono);font-weight:600;color:var(--brass)}
.dr-chip.drawer{border-color:var(--brass);background:#3a2e1c}
.dr-chip.ok{border-color:#5fd3a0;background:#1d4031}
.dr-chip .pen{font-size:11px;color:var(--brass)}
.dr-wrow{display:flex;gap:8px;align-items:stretch}
.dr-wbox{flex:1;min-width:0;display:flex;align-items:center;gap:8px;background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:4px 6px 4px 10px;min-height:44px}
.dr-wbox .lbl{font-size:11px;color:var(--muted);white-space:nowrap;line-height:1.15}
.dr-wbox .wd{font-family:var(--f-display);font-size:23px;line-height:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.dr-wbox .wd.pat{letter-spacing:.14em;color:var(--ink)}
.dr-wbox .wd.me{color:var(--brass)}
.dr-wbox .grow{flex:1}
.dr-peek{appearance:none;border:1px dashed var(--brass);background:transparent;color:var(--brass);border-radius:10px;font-weight:700;font-size:12px;padding:0 10px;min-height:36px;white-space:nowrap;cursor:pointer;user-select:none;-webkit-user-select:none;touch-action:none}
.dr-peek.on{background:var(--brass);color:var(--brass-ink)}
.dr-timer{flex:none;min-width:62px;display:grid;place-items:center;border-radius:12px;background:var(--surface);border:1px solid var(--line);font-family:var(--f-mono);font-weight:600;font-size:19px}
.dr-timer.low{border-color:var(--coral);color:var(--coral)}
.dr-bar{height:3px;border-radius:2px;background:rgba(242,233,216,.1);overflow:hidden}
.dr-bar i{display:block;height:100%;width:100%;background:var(--brass);transform-origin:left center}
.dr-bar.low i{background:var(--coral)}
.dr-bottom{position:absolute;left:0;right:0;bottom:0;z-index:3;padding:6px 10px calc(8px + env(safe-area-inset-bottom,0px));display:flex;flex-direction:column;gap:6px}
.dr-bottom:empty{padding:0}
.dr-row{display:flex;gap:6px;align-items:center}
.dr-colors .sw{flex:1 1 0;min-width:0;height:42px;border-radius:12px;border:2px solid transparent;background:var(--surface);display:grid;place-items:center;cursor:pointer;padding:0;touch-action:manipulation}
.dr-colors .sw i{width:24px;height:24px;border-radius:50%;background:var(--c);box-shadow:inset 0 -2px 0 rgba(0,0,0,.25),0 0 0 1.5px rgba(255,255,255,.18)}
.dr-colors .sw.on{border-color:var(--brass);background:var(--surface-2)}
.dr-colors .sw.on i{transform:scale(1.15)}
.dr-tools .tb{flex:1 1 0;min-width:40px;max-width:58px;height:44px;border-radius:12px;border:2px solid transparent;background:var(--surface);color:var(--ink);display:grid;place-items:center;cursor:pointer;padding:0;touch-action:manipulation;font-weight:700;font-size:12px}
.dr-tools .tb.on{border-color:var(--brass);background:var(--surface-2)}
.dr-tools .tb.arm{border-color:var(--coral);color:var(--coral);background:#3a1d1c}
.dr-tools .tb:active,.dr-colors .sw:active{transform:scale(.94)}
.dr-tools .tb svg{width:24px;height:24px}
.dr-tools .dotsz{border-radius:50%;background:var(--ink)}
.dr-ink{display:flex;align-items:center;gap:8px;font-size:11px;color:var(--muted);font-family:var(--f-mono);white-space:nowrap}
.dr-ink .tr{flex:1;height:7px;border-radius:4px;background:rgba(242,233,216,.12);overflow:hidden}
.dr-ink .tr i{display:block;height:100%;background:#5fd3a0;transition:width .15s}
.dr-ink.mid .tr i{background:var(--brass)} .dr-ink.hi .tr i{background:var(--coral)}
.dr-award{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;align-items:center}
.dr-award::-webkit-scrollbar{display:none}
.dr-award .lab{font-size:11px;color:var(--muted);flex:none;line-height:1.15}
.dr-award .btn{flex:none;min-height:44px;padding:6px 12px;font-size:14px}
.dr-award .btn.got{background:#1d4031;border-color:#5fd3a0;color:#bff0d8}
.dr-award .btn.arm{background:var(--brass);color:var(--brass-ink)}
.dr-feed{display:flex;flex-direction:column;gap:2px;font-size:13px;line-height:1.35;min-height:0}
.dr-feed div{height:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--muted)}
.dr-feed div b{color:var(--ink);font-weight:700}
.dr-feed .ok{color:#7fe0b2} .dr-feed .ok b{color:#7fe0b2}
.dr-feed .near{color:var(--brass)}
.dr-guess{display:flex;gap:6px}
.dr-guess input{flex:1;min-width:0;height:46px;border-radius:12px;border:1px solid var(--line);background:var(--bg);padding:0 14px;font-size:16px;outline:none;color:var(--ink)}
.dr-guess input:focus{border-color:var(--brass)}
.dr-guess .btn{min-width:72px}
.dr-done{display:flex;align-items:center;justify-content:center;gap:8px;min-height:46px;border-radius:12px;background:#1d4031;border:1px solid #5fd3a0;color:#bff0d8;font-weight:700;font-size:14px;padding:0 12px;text-align:center}
.dr-mid{position:absolute;left:0;right:0;z-index:4;display:flex;align-items:center;justify-content:center;padding:10px 16px;pointer-events:none}
.dr-mid>*{pointer-events:auto}
.dr-card{background:var(--surface);border:1px solid var(--line);border-radius:18px;padding:16px;width:min(340px,100%);display:flex;flex-direction:column;gap:10px;box-shadow:0 18px 40px rgba(0,0,0,.45);animation:fade .18s ease-out}
.dr-card h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:24px;line-height:1.15;text-wrap:balance}
.dr-card p{margin:0}
.dr-card .big{font-family:var(--f-display);font-size:40px;line-height:1.05;color:var(--brass);word-break:keep-all}
.dr-card .note{font-size:12px;color:var(--muted)}
.dr-card.small{width:auto;padding:10px 16px;flex-direction:row;align-items:center;gap:10px;border-radius:999px}
.dr-choice{display:flex;flex-direction:column;align-items:flex-start;gap:2px;width:100%;min-height:58px;border-radius:14px;border:1px solid var(--line);background:var(--surface-2);padding:8px 14px;cursor:pointer;text-align:left;color:var(--ink)}
.dr-choice:active{transform:scale(.97)}
.dr-choice .c{font-size:11px;color:var(--muted)}
.dr-choice .w{font-family:var(--f-display);font-size:24px;line-height:1.1}
.dr-gains{display:flex;flex-wrap:wrap;gap:6px}
.dr-gains>span{display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:700;background:var(--surface-2);border-radius:999px;padding:3px 10px 3px 7px}
.dr-gains b{font-family:var(--f-mono);color:#7fe0b2}
.dr-curtain{word-break:keep-all;overflow-wrap:anywhere;position:absolute;inset:0;z-index:6;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:24px;text-align:center;background:radial-gradient(120% 80% at 50% 30%,#2d2240,#130f1a);animation:fade .18s}
.dr-curtain .big{font-family:var(--f-display);font-size:38px;line-height:1.1}
.dr-curtain .btn{min-width:200px;min-height:54px;font-size:17px}
`;
  const ICONS = {
    eraser: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M4 15l9-9 7 7-7 7H8z"/><path d="M9 10l7 7M8 20h12"/></svg>',
    undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 7L4 12l5 5"/><path d="M4 12h10a6 6 0 010 12h-2" transform="translate(0 -5)"/></svg>',
    clear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/></svg>',
  };

  function mount(root, api) {
    const h = L.h;
    const styleEl = h('style', { text: CSS });
    root.append(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = h('div', { class: 'dr-top' }), mid = h('div', { class: 'dr-mid' }), bottom = h('div', { class: 'dr-bottom' });
    root.append(top, mid, bottom);

    let st = null, turnKey = '', lastSeq = -1;
    let recv = { ts: 0, at: 0 };
    let P = { x: 0, y: 0, w: 1, h: 1 }; // paper rect (CSS px)
    let bgCv = null, inkCv = null, tmpCv = null, dirty = true;
    // drawing state (this device)
    let strokes = [], encs = [], live = null, undoClear = null, tool = { c: 0, s: 1, er: false };
    let budget = Infinity, inkOutWarned = false, pubTimer = 0, lastPub = 0;
    // remote drawing
    let remoteSig = '', remoteStrokes = [];
    let curtainOpen = -1; // local: turn index whose words were revealed
    let peekOn = false, lastSec = -1, hintShown = false, botSig = '', midSig = '', topSig = '';
    const armed = {}; // two-tap confirms
    const tm = [];

    const mySeat = () => { const m = api.mySeats(); return api.online ? (m.length ? m[0] : -1) : -1; };
    const local = () => !api.online;
    const iDraw = () => !!st && st.dr >= 0 && api.canAct(st.dr);
    const name = (i) => (api.players[i] ? api.players[i].name : '?');
    const color = (i) => (api.players[i] ? api.players[i].color : '#999');
    const word = () => (st && st.w ? dec(st.w, keyOf(st)) : '');
    const elapsed = () => (st ? st.ts - st.t0 + (performance.now() - recv.at) : 0);
    const phaseMs = () => (!st ? 0 : st.ph === 'draw' ? st.lim * 1000 : st.ph === 'pick' ? (api.online ? PICK_MS : 0) : st.ph === 'reveal' ? REVEAL_MS : 0);
    const remaining = () => Math.max(0, phaseMs() - elapsed());
    const hintOpen = () => st && st.ph === 'draw' && elapsed() >= st.lim * 500 && st.pt >= 2;

    /* ----- layout & paper ----- */
    function layout() {
      const tH = top.offsetHeight, bH = bottom.offsetHeight;
      const ax = 12, ay = tH + 16, aw = cv.w - 24, ah = Math.max(60, cv.h - tH - bH - 26);
      let w = Math.min(aw, ah / PAPER_ASPECT); const hh = w * PAPER_ASPECT;
      w = Math.floor(w);
      const np = { x: Math.round(ax + (aw - w) / 2), y: Math.round(ay + (ah - hh) / 2), w, h: Math.floor(w * PAPER_ASPECT) };
      mid.style.top = tH + 'px'; mid.style.bottom = bH + 'px';
      if (np.x === P.x && np.y === P.y && np.w === P.w && np.h === P.h && bgCv) return;
      P = np;
      buildBg(); rebuildInk();
    }
    function mkCanvas(w, hh) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * cv.dpr)); c.height = Math.max(1, Math.round(hh * cv.dpr)); const g = c.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0); return c; }
    function buildBg() {
      bgCv = mkCanvas(cv.w, cv.h);
      const g = bgCv.getContext('2d');
      const grd = g.createRadialGradient(cv.w / 2, cv.h * 0.45, 20, cv.w / 2, cv.h * 0.45, Math.max(cv.w, cv.h) * 0.75);
      grd.addColorStop(0, '#2c2139'); grd.addColorStop(1, '#141019');
      g.fillStyle = grd; g.fillRect(0, 0, cv.w, cv.h);
      // faint parlor wallpaper diamonds
      g.strokeStyle = 'rgba(227,174,69,.05)'; g.lineWidth = 1;
      for (let x = -cv.h; x < cv.w + cv.h; x += 26) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x + cv.h, cv.h); g.moveTo(x, cv.h); g.lineTo(x + cv.h, 0); g.stroke(); }
      const { x, y, w, h: hh } = P;
      // under-sheets + shadow
      g.fillStyle = 'rgba(0,0,0,.4)'; rr(g, x + 3, y + 9, w, hh, 8); g.fill();
      g.fillStyle = '#d9cfba'; rr(g, x + 4, y + 5, w - 2, hh, 7); g.fill();
      g.fillStyle = '#e8dfca'; rr(g, x + 2, y + 2.5, w - 1, hh, 7); g.fill();
      // paper
      const pg = g.createLinearGradient(x, y, x, y + hh);
      pg.addColorStop(0, '#fdfaf1'); pg.addColorStop(1, '#f6efdf');
      g.fillStyle = pg; rr(g, x, y, w, hh, 7); g.fill();
      // grain
      const r = prng(1234);
      for (let i = 0; i < (w * hh) / 90; i++) { g.fillStyle = r() < 0.5 ? 'rgba(120,96,60,.06)' : 'rgba(255,255,255,.5)'; g.fillRect(x + r() * w, y + 14 + r() * (hh - 16), 1.2, 1.2); }
      // spiral binding
      const holes = Math.max(6, Math.floor(w / 26)), gap = w / holes;
      for (let i = 0; i < holes; i++) {
        const cx = x + gap * (i + 0.5);
        g.fillStyle = '#3a2f45'; g.beginPath(); g.ellipse(cx, y + 9, 3.2, 3.2, 0, 0, 7); g.fill();
        g.strokeStyle = '#a8a0ae'; g.lineWidth = 2.4; g.lineCap = 'round';
        g.beginPath(); g.moveTo(cx - 1, y + 9); g.bezierCurveTo(cx - 2, y - 6, cx + 6, y - 6, cx + 4, y + 2); g.stroke();
        g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 0.9;
        g.beginPath(); g.moveTo(cx - 0.6, y + 6); g.bezierCurveTo(cx - 1.4, y - 4, cx + 4.5, y - 4.5, cx + 3.6, y + 0.5); g.stroke();
      }
      dirty = true;
    }
    function rr(g, x, y, w, hh, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, hh, r); else g.rect(x, y, w, hh); }
    function strokeOn(g, st1, live1) {
      const pts = st1.p, w = P.w, hh = P.h;
      const sx = live1 ? w : w / 255, sy = live1 ? hh : hh / 255;
      const erase = st1.c === ERASER;
      g.globalCompositeOperation = erase ? 'destination-out' : 'source-over';
      g.strokeStyle = g.fillStyle = erase ? '#000' : COLORS[st1.c] || COLORS[0];
      const lw = Math.max(1.2, SIZES[st1.s] * w * (erase ? 2.4 : 1));
      g.lineWidth = lw; g.lineCap = 'round'; g.lineJoin = 'round';
      const n = pts.length / 2;
      if (n === 1) { g.beginPath(); g.arc(pts[0] * sx, pts[1] * sy, lw / 2, 0, 7); g.fill(); }
      else {
        g.beginPath(); g.moveTo(pts[0] * sx, pts[1] * sy);
        for (let i = 1; i < n - 1; i++) {
          const x1 = pts[2 * i] * sx, y1 = pts[2 * i + 1] * sy, x2 = pts[2 * i + 2] * sx, y2 = pts[2 * i + 3] * sy;
          g.quadraticCurveTo(x1, y1, (x1 + x2) / 2, (y1 + y2) / 2);
        }
        g.lineTo(pts[2 * n - 2] * sx, pts[2 * n - 1] * sy); g.stroke();
      }
      g.globalCompositeOperation = 'source-over';
    }
    function shownStrokes() { return iDraw() || local() ? strokes : remoteStrokes; }
    function rebuildInk() {
      inkCv = mkCanvas(P.w, P.h); tmpCv = mkCanvas(P.w, P.h);
      const g = inkCv.getContext('2d');
      shownStrokes().forEach((s1) => strokeOn(g, s1, false));
      dirty = true;
    }
    function frame() {
      if (!dirty || !bgCv) return;
      dirty = false;
      cv.clear();
      ctx.drawImage(bgCv, 0, 0, cv.w, cv.h);
      let src = inkCv;
      if (live && live.p.length) {
        const g = tmpCv.getContext('2d');
        g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, tmpCv.width, tmpCv.height); g.drawImage(inkCv, 0, 0);
        g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
        strokeOn(g, live, true);
        src = tmpCv;
      }
      if (src) ctx.drawImage(src, P.x, P.y, P.w, P.h);
    }

    /* ----- drawing input ----- */
    const canDrawNow = () => !!st && st.ph === 'draw' && iDraw();
    function toPaper(e) { const p = cv.local(e); return { x: (p.x - P.x) / P.w, y: (p.y - P.y) / P.h, inside: p.x >= P.x - 8 && p.x <= P.x + P.w + 8 && p.y >= P.y - 8 && p.y <= P.y + P.h + 8 }; }
    const encLen = (fp) => encStroke({ c: 0, s: 0, p: quant(fp) }).length;
    function fits(fp) { return !Number.isFinite(budget) || drawingSize(turnKey, encs) + encLen(fp) + 3 <= budget; }
    function inkFull() { return Number.isFinite(budget) && drawingSize(turnKey, encs) + 12 > budget; }
    function onDown(e) {
      if (!canDrawNow() || live) return; // first pointer wins: palms / second fingers are ignored
      if (e.pointerType === 'touch' && (e.width > 70 || e.height > 70)) return;
      const p = toPaper(e); if (!p.inside) return;
      e.preventDefault();
      if (inkFull()) { inkWarn(); return; }
      live = { id: e.pointerId, c: tool.er ? ERASER : tool.c, s: tool.s, p: [U.clamp(p.x, 0, 1), U.clamp(p.y, 0, 1)] };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
      dirty = true; schedulePub();
    }
    function onMove(e) {
      if (!live || e.pointerId !== live.id) return;
      e.preventDefault();
      const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
      for (const ev of (evs.length ? evs : [e])) {
        const p = toPaper(ev);
        const x = U.clamp(p.x, 0, 1), y = U.clamp(p.y, 0, 1);
        const n = live.p.length;
        if (Math.hypot(x - live.p[n - 2], (y - live.p[n - 1]) * PAPER_ASPECT) < 0.0035) continue;
        const next = live.p.concat([x, y]);
        if (Number.isFinite(budget) && (next.length % 16 === 0 || next.length > 40) && !fits(next)) { endStroke(); inkWarn(); return; }
        live.p = next;
      }
      dirty = true; schedulePub();
    }
    function onUp(e) { if (live && e.pointerId === live.id) endStroke(); }
    function endStroke() {
      if (!live) return;
      const s1 = { c: live.c, s: live.s, p: quant(live.p) };
      live = null;
      if (s1.p.length >= 2) {
        let e1 = encStroke(s1);
        if (Number.isFinite(budget) && drawingSize(turnKey, encs.concat([e1])) > budget) { // trim the tail until it fits
          while (s1.p.length > 2 && drawingSize(turnKey, encs.concat([e1])) > budget) { s1.p.length -= 2; e1 = encStroke(s1); }
          if (drawingSize(turnKey, encs.concat([e1])) > budget) { dirty = true; updInk(); return; }
        }
        strokes.push(s1); encs.push(e1); undoClear = null;
        strokeOn(inkCv.getContext('2d'), s1, false);
      }
      dirty = true; updInk(); publish();
    }
    function inkWarn() { if (!inkOutWarned) { inkOutWarned = true; api.toast('잉크가 다 떨어졌어요 · 되돌리기나 지우기로 되찾아요'); api.buzz(30); setTimeout(() => { inkOutWarned = false; }, 2500); } }
    function undo() {
      if (live) return;
      if (!strokes.length && undoClear) { strokes = undoClear.s; encs = undoClear.e; undoClear = null; api.toast('다시 살렸어요'); }
      else if (strokes.length) { strokes.pop(); encs.pop(); }
      else return;
      api.sfx('click'); api.buzz(8); rebuildInk(); updInk(); publish();
    }
    function clearAll() {
      if (!strokes.length) return;
      undoClear = { s: strokes, e: encs }; strokes = []; encs = [];
      api.sfx('whoosh'); api.buzz(15); api.toast('모두 지웠어요 · 되돌리기로 살릴 수 있어요'); rebuildInk(); updInk(); publish();
    }
    function schedulePub() { if (!api.online || pubTimer) return; const wait = Math.max(0, 180 - (performance.now() - lastPub)); pubTimer = setTimeout(() => { pubTimer = 0; publish(); }, wait); }
    function publish() {
      if (!api.online || !st || !iDraw()) return;
      lastPub = performance.now();
      const list = encs.slice();
      if (live && live.p.length >= 2) { const q = quant(live.p); const e1 = encStroke({ c: live.c, s: live.s, p: q }); if (drawingSize(turnKey, list.concat([e1])) <= budget) list.push(e1); }
      api.net.publish({ k: turnKey, d: list });
    }
    const listen = (el, ev, f, o) => { el.addEventListener(ev, f, o); tm.push(() => el.removeEventListener(ev, f, o)); };
    listen(cv.cv, 'pointerdown', onDown);
    listen(cv.cv, 'pointermove', onMove);
    listen(cv.cv, 'pointerup', onUp);
    listen(cv.cv, 'pointercancel', onUp);
    listen(cv.cv, 'touchmove', (e) => { if (canDrawNow()) e.preventDefault(); }, { passive: false });
    listen(cv.cv, 'contextmenu', (e) => e.preventDefault());

    /* ----- remote drawing (other devices) ----- */
    function pollRemote() {
      if (!api.online || !st || st.dr < 0 || iDraw() || st.ph === 'x') return;
      let r = null; try { r = (api.net.remote() || {})[st.dr]; } catch (e) { r = null; }
      if (!r || r.k !== turnKey || !Array.isArray(r.d)) return;
      const sig = r.d.length + ':' + r.d.join('|');
      if (sig === remoteSig) return;
      remoteSig = sig;
      remoteStrokes = r.d.slice(0, 600).map(decStroke).filter(Boolean);
      rebuildInk();
    }

    /* ----- HUD: scores, word / hint, timer ----- */
    const scoresEl = h('div', { class: 'dr-scores' });
    const wbox = h('div', { class: 'dr-wbox' });
    const timerEl = h('div', { class: 'dr-timer', text: '' });
    const barI = h('i'), bar = h('div', { class: 'dr-bar' }, barI);
    top.append(scoresEl, h('div', { class: 'dr-wrow' }, wbox, timerEl), bar);
    function renderScores() {
      scoresEl.innerHTML = '';
      if (!st || st.ph === 'x') return;
      st.hm.forEach((i) => {
        const cls = 'dr-chip' + (i === st.dr && st.ph !== 'end' ? ' drawer' : '') + (st.gp[i] >= 0 && st.ph !== 'end' ? ' ok' : '');
        scoresEl.append(h('span', { class: cls }, h('span', { class: 'dot', style: { '--c': color(i) } }),
          i === st.dr && st.ph !== 'end' ? h('span', { class: 'pen', text: '✎' }) : null,
          h('span', { class: 'nm', text: name(i) }), h('b', { text: st.sc[i] })));
      });
    }
    function patternText(open) {
      const w = open ? word() : '';
      let s1 = '';
      for (let i = 0; i < st.pt; i++) s1 += open && i === st.hi ? w[i] : '○';
      return s1;
    }
    function renderWord() {
      if (!st) return;
      const sig = [st.ph, turnKey, iDraw(), peekOn, hintOpen(), st.gp[mySeat()] >= 0].join('|');
      if (sig === topSig) return;
      topSig = sig;
      wbox.innerHTML = '';
      const catName = st.wc >= 0 && CATS[st.wc] ? CATS[st.wc].name : '';
      const me = mySeat();
      if (st.ph === 'x') { wbox.append(h('span', { class: 'lbl', text: '사람 2명 이상이 필요해요' })); return; }
      if (st.ph === 'pick') { wbox.append(h('span', { class: 'lbl', text: (st.ti + 1) + ' / ' + st.tt + '번째 그림' }), h('span', { class: 'wd', style: { fontSize: '17px' }, text: name(st.dr) + ' 차례' })); return; }
      if (st.ph === 'reveal' || st.ph === 'end') { wbox.append(h('span', { class: 'lbl', text: '정답' }), h('span', { class: 'wd me', text: st.rv || '' })); return; }
      // draw phase
      if (iDraw() && !local()) { wbox.append(h('span', { class: 'lbl', html: '제시어<br>' + catName }), h('span', { class: 'wd me', text: word() })); return; }
      if (me >= 0 && st.gp[me] >= 0) { wbox.append(h('span', { class: 'lbl', html: '정답!<br>' + catName }), h('span', { class: 'wd me', text: word() })); return; }
      wbox.append(h('span', { class: 'lbl', html: catName + '<br>' + st.pt + '글자' }),
        h('span', { class: 'wd pat' + (peekOn ? ' me' : ''), text: peekOn ? word() : patternText(hintOpen()) }));
      if (local()) {
        wbox.append(h('span', { class: 'grow' }));
        const pk = h('button', { class: 'dr-peek' + (peekOn ? ' on' : ''), text: peekOn ? '제시어 보는 중' : '꾹 눌러 제시어' });
        const on = (e) => { e.preventDefault(); peekOn = true; renderWord(); };
        const off = () => { if (peekOn) { peekOn = false; renderWord(); } };
        pk.addEventListener('pointerdown', on); pk.addEventListener('pointerup', off); pk.addEventListener('pointerleave', off); pk.addEventListener('pointercancel', off);
        pk.addEventListener('contextmenu', (e) => e.preventDefault());
        wbox.append(pk);
      }
    }
    function renderTimer() {
      if (!st) return;
      const total = phaseMs();
      if (!total || st.ph === 'x' || st.ph === 'end') { timerEl.textContent = st.ph === 'pick' ? '—' : '·'; bar.style.visibility = 'hidden'; timerEl.classList.remove('low'); return; }
      const rem = remaining(), sec = Math.ceil(rem / 1000);
      timerEl.textContent = st.ph === 'draw' ? Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0') : sec + '초';
      const low = st.ph === 'draw' && sec <= 10;
      timerEl.classList.toggle('low', low); bar.classList.toggle('low', low);
      bar.style.visibility = 'visible'; barI.style.transform = 'scaleX(' + (rem / total).toFixed(4) + ')';
      if (st.ph === 'draw' && sec !== lastSec) { if (low && sec > 0 && lastSec !== -1) api.sfx('tick'); lastSec = sec; }
    }

    /* ----- bottom: tools / guess / awards / feed ----- */
    const feedEl = h('div', { class: 'dr-feed' });
    let guessInput = null, inkEl = null;
    function renderFeed() {
      feedEl.innerHTML = '';
      if (!st || !st.fd) return;
      const me = mySeat();
      const n = iDraw() ? 2 : 3;
      feedEl.style.height = n * 18 + 'px';
      st.fd.slice(-n).forEach(([s1, k, t]) => {
        if (k === 1) feedEl.append(h('div', { class: 'ok' }, h('b', { text: name(s1) }), ' 정답!'));
        else if (k === 2) feedEl.append(h('div', { class: 'near' }, h('b', { text: name(s1) }), s1 === me ? ': ' + t + ' — 아깝다!' : ' 아깝다!'));
        else feedEl.append(h('div', null, h('b', { text: name(s1) }), ': ' + t + '?'));
      });
      if (!st.fd.length && st.ph === 'draw') feedEl.append(h('div', { text: iDraw() ? '맞히는 사람의 답이 여기 떠요' : '정답을 입력해 보세요' }));
    }
    function updInk() {
      if (!inkEl) return;
      const used = drawingSize(turnKey, encs), f = U.clamp(used / budget, 0, 1);
      inkEl.querySelector('i').style.width = (100 - f * 100).toFixed(1) + '%';
      inkEl.className = 'dr-ink' + (f > 0.85 ? ' hi' : f > 0.6 ? ' mid' : '');
      inkEl.querySelector('span').textContent = '잉크 ' + Math.round(100 - f * 100) + '%';
    }
    function arm(key, el, label, fn) {
      if (armed[key]) { clearTimeout(armed[key]); delete armed[key]; fn(); return; }
      Object.keys(armed).forEach((k) => { clearTimeout(armed[k]); delete armed[k]; });
      el.classList.add('arm'); const old = el.innerHTML; el.textContent = label; api.buzz(10);
      armed[key] = setTimeout(() => { delete armed[key]; if (el.isConnected) { el.classList.remove('arm'); el.innerHTML = old; } }, 2600);
    }
    function toolBtn(cls, html, label, fn) { return h('button', { class: 'tb ' + cls, html, 'aria-label': label, title: label, onclick: fn }); }
    function renderBottom() {
      const me = mySeat();
      const role = !st ? '' : st.ph !== 'draw' ? 'none' : iDraw() ? (local() ? 'drawL' : 'drawO') : me >= 0 && st.hm.includes(me) ? (st.gp[me] >= 0 ? 'done' : 'guess') : 'watch';
      const sig = role + '|' + turnKey + '|' + (role === 'drawL' ? st.gp.join(',') : '');
      if (sig === botSig) { renderFeed(); return; }
      const keepFocus = guessInput && document.activeElement === guessInput && role === 'guess';
      const keepVal = guessInput ? guessInput.value : '';
      botSig = sig; bottom.innerHTML = ''; inkEl = null;
      if (role !== 'guess') guessInput = null;
      if (role === 'drawO' || role === 'drawL') {
        if (role === 'drawO') bottom.append(feedEl);
        const colors = h('div', { class: 'dr-row dr-colors' }, COLORS.map((c, i) => h('button', {
          class: 'sw' + (!tool.er && tool.c === i ? ' on' : ''), 'aria-label': COLOR_NAMES[i], style: { '--c': c },
          onclick() { tool.c = i; tool.er = false; api.sfx('click'); refreshTools(); },
        }, h('i'))));
        const sizes = SIZES.map((_, i) => toolBtn('sz' + (tool.s === i ? ' on' : ''), '', ['가는 펜', '보통 펜', '굵은 펜'][i], () => { tool.s = i; api.sfx('click'); refreshTools(); }));
        sizes.forEach((b, i) => b.append(h('span', { class: 'dotsz', style: { width: [5, 10, 17][i] + 'px', height: [5, 10, 17][i] + 'px' } })));
        const er = toolBtn('er' + (tool.er ? ' on' : ''), ICONS.eraser, '지우개', () => { tool.er = !tool.er; api.sfx('click'); refreshTools(); });
        const un = toolBtn('', ICONS.undo, '되돌리기', undo);
        const cl = toolBtn('', ICONS.clear, '모두 지우기', () => { if (strokes.length) arm('clear', cl, '정말?', clearAll); });
        const tools = h('div', { class: 'dr-row dr-tools' }, sizes, er, un, cl);
        if (!local()) { inkEl = h('div', { class: 'dr-ink' }, h('span', { text: '잉크' }), h('div', { class: 'tr' }, h('i'))); bottom.append(inkEl); }
        bottom.append(colors, tools);
        if (role === 'drawL') {
          const row = h('div', { class: 'dr-award' }, h('span', { class: 'lab', html: '맞힌<br>사람' }));
          guessers(st).forEach((i) => {
            const got = st.gp[i] >= 0;
            const b = h('button', { class: 'btn' + (got ? ' got' : ''), disabled: got ? true : null }, h('span', { class: 'dot', style: { '--c': color(i) } }), got ? name(i) + ' +' + st.gp[i] : name(i));
            if (!got) b.onclick = () => arm('aw' + i, b, name(i) + ' 정답?', () => api.actAs(st.dr, { type: 'award', s: i }));
            row.append(b);
          });
          const any = guessers(st).some((i) => st.gp[i] >= 0);
          const endB = h('button', { class: 'btn ghost', text: any ? '여기서 끝내기' : '아무도 못 맞힘' });
          endB.onclick = () => arm('end', endB, '한 번 더 누르면 끝', () => api.actAs(st.dr, { type: 'end' }));
          row.append(endB);
          bottom.append(row);
        }
        updInk();
      } else if (role === 'guess') {
        bottom.append(feedEl);
        if (!guessInput) {
          guessInput = h('input', { id: 'dr-guess', type: 'text', maxlength: GUESS_MAX, placeholder: '정답 입력', autocomplete: 'off', autocorrect: 'off', autocapitalize: 'off', spellcheck: 'false', enterkeyhint: 'send', 'aria-label': '정답 입력' });
          guessInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); send(); } });
        }
        guessInput.value = keepVal;
        const sendB = h('button', { class: 'btn primary', text: '보내기', onpointerdown: (e) => e.preventDefault(), onclick: send });
        bottom.append(h('div', { class: 'dr-guess' }, guessInput, sendB));
        if (keepFocus) guessInput.focus();
      } else if (role === 'done') {
        bottom.append(feedEl, h('div', { class: 'dr-done', text: '정답! +' + st.gp[me] + '점 · 다른 사람을 기다리는 중' }));
      } else if (role === 'watch') {
        bottom.append(feedEl);
      }
      renderFeed();
    }
    function refreshTools() { botSig = ''; renderBottom(); }
    let lastSend = 0;
    function send() {
      if (!guessInput) return;
      const t = guessInput.value.replace(/\s+/g, ' ').trim();
      if (!t) { guessInput.focus(); return; }
      if (performance.now() - lastSend < 250) return;
      lastSend = performance.now();
      api.act({ type: 'guess', t: t.slice(0, GUESS_MAX) });
      guessInput.value = ''; api.buzz(8);
    }

    /* ----- middle cards: curtain, choices, waiting, reveal ----- */
    function renderMid() {
      if (!st) return;
      const sig = [st.ph, turnKey, iDraw(), curtainOpen === st.ti].join('|');
      if (sig === midSig) return;
      midSig = sig; mid.innerHTML = ''; mid.style.alignItems = '';
      root.querySelectorAll('.dr-curtain').forEach((e) => e.remove());
      if (st.ph === 'x') {
        mid.append(h('div', { class: 'dr-card' }, h('h3', { text: '그림 맞히기는 사람끼리만 할 수 있어요' }),
          h('p', { class: 'note', text: 'AI는 그림을 그리거나 맞힐 수 없어요. 설정에서 2명 이상을 ‘사람’으로 정해 주세요.' })));
        return;
      }
      if (st.ph === 'pick') {
        if (!iDraw()) { mid.append(h('div', { class: 'dr-card small' }, h('span', { class: 'dot', style: { '--c': color(st.dr) } }), h('span', { text: name(st.dr) + '님이 제시어를 고르는 중…' }))); return; }
        if (local() && curtainOpen !== st.ti) {
          const c = h('div', { class: 'dr-curtain' },
            h('span', { class: 'label', text: (st.ti + 1) + ' / ' + st.tt + '번째 그림' }),
            h('span', { class: 'dot', style: { '--c': color(st.dr), width: '20px', height: '20px' } }),
            h('div', { class: 'big', text: name(st.dr) }),
            h('p', { class: 'muted', style: { margin: 0 }, text: '그릴 차례예요. 폰을 받아서 혼자만 보세요.' }),
            h('button', { class: 'btn primary', text: '제시어 보기', onclick() { curtainOpen = st.ti; api.sfx('card'); api.buzz(12); renderMid(); } }),
            h('p', { class: 'note', style: { margin: 0 }, text: '나머지 사람은 화면을 보지 마세요' }),
            h('p', { class: 'note', style: { margin: '6px 0 0', maxWidth: '300px', textAlign: 'center' }, text: '맞히는 사람은 그림을 보고 말로 외쳐요. 맞힌 사람이 나오면 그린 사람이 아래 이름 버튼을 두 번 눌러 점수를 줘요.' }));
          root.append(c);
          return;
        }
        const key = keyOf(st);
        mid.append(h('div', { class: 'dr-card' },
          h('h3', { text: '무엇을 그릴까요?' }),
          st.ch.map((e, i) => h('button', { class: 'dr-choice', onclick() { api.sfx('pop'); api.buzz(15); api.actAs(st.dr, { type: 'pick', i }); } },
            h('span', { class: 'c', text: CATS[st.cc[i]] ? CATS[st.cc[i]].name : '' }), h('span', { class: 'w', text: dec(e, key) }))),
          h('p', { class: 'note', text: (local() ? '고르면 바로 ' + st.lim + '초가 시작돼요. 다른 사람은 말로 맞히고, 맞힌 사람은 아래에서 눌러 주세요.' : '고르면 바로 ' + st.lim + '초가 시작돼요. 20초 안에 안 고르면 첫 번째로 정해져요.') + ' 글자·숫자는 쓰지 말고 그림으로만!' })));
        return;
      }
      if (st.ph === 'reveal') {
        const why = { time: '시간 종료', all: '모두 맞혔어요!', end: '그린 사람이 끝냈어요', none: '아무도 못 맞혔어요', left: '그리던 사람이 나갔어요' }[st.why] || '';
        const gains = h('div', { class: 'dr-gains' });
        guessers(st).filter((i) => st.gp[i] >= 0).sort((a, b) => st.gp[b] - st.gp[a]).forEach((i) => gains.append(h('span', null, h('span', { class: 'dot', style: { '--c': color(i) } }), name(i), h('b', { text: '+' + st.gp[i] }))));
        const last = st.ti + 1 >= st.tt;
        const nextName = last ? '' : name(st.hm[(st.ti + 1) % st.hm.length]);
        mid.style.alignItems = 'flex-end';
        mid.append(h('div', { class: 'dr-card' },
          h('span', { class: 'label', text: why }),
          h('div', { class: 'big', text: st.rv || '' }),
          gains.childNodes.length ? gains : h('p', { class: 'note', text: '이번엔 점수를 얻은 사람이 없어요' }),
          h('p', { class: 'note', text: last ? '마지막 그림이었어요. 곧 결과가 나와요.' : '다음은 ' + nextName + '님이 그려요.' }),
          api.isHost && (local() || mySeat() >= 0) ? h('button', { class: 'btn primary block', text: last ? '결과 보기' : '다음 그림', onclick() { if (st.ph === 'reveal') { api.sfx('click'); api.setState(nextTurn(U.clone(st), clock.now())); } } }) : null));
      }
    }

    /* ----- events (sounds, toasts) ----- */
    function onEvent(prev) {
      const l = st.last;
      if (!l || l.id === lastSeq) return;
      const first = lastSeq === -1; lastSeq = l.id;
      if (first || !prev) return;
      const me = mySeat();
      if (l.k === 'ok') {
        if (l.s === me) { api.sfx('win'); api.buzz([20, 40, 20]); }
        else { api.sfx('pop'); api.buzz(12); }
        if (local() || l.s !== me) api.toast(name(l.s) + ' 정답! +' + l.p);
        else api.toast('정답! +' + l.p + '점');
      } else if (l.k === 'near' && l.s === me) { api.sfx('bounce'); api.buzz(15); }
      else if (l.k === 'no' && l.s === me) api.sfx('click');
      else if (l.k === 'rev') { api.sfx('whoosh'); }
      else if (l.k === 'pick') { api.sfx('card'); if (iDraw()) api.buzz(15); }
      else if (l.k === 'turn' && iDraw() && !local()) { api.buzz([15, 60, 15]); api.sfx('tick'); }
    }

    /* ----- loop & host clock ----- */
    let pollT = 0;
    const stop = U.loop((dt) => {
      if (!st) return;
      pollT += dt;
      if (pollT > 0.1) { pollT = 0; pollRemote(); if (hintOpen() !== hintShown) { hintShown = hintOpen(); renderWord(); } }
      renderTimer();
      frame();
    });
    const hostTimer = setInterval(() => {
      if (!st || !api.isHost) return;
      const ctx2 = { online: api.online, isAi: (i) => !!(api.players[i] && api.players[i].ai) };
      let nx = null;
      try { nx = tick(U.clone(st), clock.now(), ctx2); } catch (e) { console.error(e); }
      if (nx) api.setState(nx);
    }, 250);
    const ro = new ResizeObserver(() => layout()); ro.observe(top); ro.observe(bottom);
    cv.onresize = () => { bgCv = null; layout(); };

    /* core drops the very first action a guest sends in a room (its act counter is only recorded),
       so a guest sends one harmless no-op as soon as it is allowed to act. */
    let primed = false;
    function primeGuest() {
      if (primed || api.isHost || !api.online || !st) return;
      const a = actor(st), list = a == null ? [] : Array.isArray(a) ? a : [a];
      if (!list.some((x) => api.canAct(x))) return;
      primed = true; api.act({ type: 'ping' });
    }
    function newTurn() {
      strokes = []; encs = []; live = null; undoClear = null; remoteSig = ''; remoteStrokes = [];
      peekOn = false; lastSec = -1; hintShown = false;
      let lob = 0; try { lob = L.net && L.net.lobby ? utf8Len(JSON.stringify(L.net.lobby)) : 0; } catch (e) { lob = 0; }
      budget = api.online ? inkBudgetFor(lob) : Infinity;
      if (api.online && st && !iDraw()) api.net.publish(null);
      if (inkCv) rebuildInk();
    }

    return {
      update(next, prev) {
        const was = st;
        st = next;
        if (st.ts !== recv.ts) recv = { ts: st.ts, at: performance.now() };
        const key = st.g.toString(36) + '.' + st.ti;
        if (key !== turnKey) { turnKey = key; newTurn(); }
        if (was && was.ph === 'draw' && st.ph !== 'draw' && live) endStroke();
        if (was && was.ph === 'pick' && st.ph === 'draw' && iDraw()) publish();
        renderScores(); renderWord(); renderBottom(); renderMid(); renderTimer();
        layout();
        onEvent(prev);
        primeGuest();
        dirty = true;
      },
      destroy() {
        stop(); clearInterval(hostTimer); clearTimeout(pubTimer); ro.disconnect();
        Object.keys(armed).forEach((k) => clearTimeout(armed[k]));
        tm.forEach((f) => f());
        cv.destroy(); top.remove(); mid.remove(); bottom.remove(); styleEl.remove();
        root.querySelectorAll('.dr-curtain').forEach((e) => e.remove());
      },
    };
  }

  const def = {
    id: 'drawing', name: '그림 맞히기', tag: '그리고 맞히기', cat: '파티', noAI: true,
    blurb: '돌아가며 한 명이 제시어를 그리고 나머지가 맞혀요. 점수는 맞힌 사람만, 빨리 맞힐수록 커요. 사람끼리만 할 수 있어요(사람 2명 이상, AI 자리는 구경만 해요).',
    quick: [
      '한 명이 제시어를 그림으로 그리고, 나머지가 무엇인지 맞혀요. 모두 돌아가며 그려요.',
      '그릴 차례: 제시어 3개 중 하나를 골라 제한 시간 안에 그려요(글자·숫자 금지). 맞힐 차례: 보고 맞혀요.',
      '맞힌 사람만 점수(빨리 맞힐수록 10점 → 3점). 끝났을 때 점수 1등이 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '돌아가며 한 명이 그리고, 나머지가 맞혀요. 맞혀서 점수를 가장 많이 모으면 이겨요.',
        '사람끼리만 하는 게임이에요(사람 2명 이상). AI는 그리거나 맞히지 못해서 AI 자리는 건너뛰어요.',
        '둘이서(1:1)도 할 수 있어요. 번갈아 그리고 맞혀요.'] },
      { h: '준비', p: [
        '설정에서 분야(기본 전체 랜덤 · 14분야), 라운드(각자 그리는 횟수 1·2·3번), 제한 시간(60·80·100초)을 골라요.',
        '한 폰으로 할 때는 폰 하나를 가운데 두고 그릴 사람에게 넘겨요. 온라인이면 각자 자기 폰으로 해요.'] },
      { h: '차례에 할 일 — 그리는 사람', p: [
        '① (한 폰) 「제시어 보기」를 눌러요. 다른 사람은 화면을 보지 마세요.',
        '② 제시어 3개 중 하나를 골라요. 고르는 순간 제한 시간이 시작돼요(온라인에서 20초 안에 안 고르면 첫 번째로 정해져요).',
        '③ 그림으로만 그려요. 글자나 숫자는 쓰면 안 돼요.',
        '④ (한 폰) 누가 맞히면 아래 「맞힌 사람」 줄에서 그 사람 이름을 두 번 눌러 점수를 줘요.'] },
      { h: '차례에 할 일 — 맞히는 사람', p: [
        '한 폰: 그림을 보고 말로 외쳐요.',
        '온라인: 아래 칸에 정답을 써서 「보내기」. 몇 번이든 보낼 수 있어요. 띄어쓰기는 무시해요.',
        '틀린 답은 모두에게 보이고, 거의 맞으면 「아깝다!」가 떠요(무슨 답인지는 본인만 봐요).',
        '행동 분야는 「달리다」 「달리기」처럼 써도 정답이에요.'] },
      { h: '힌트', p: [
        '맞히는 사람에게는 분야와 글자 수(○○○)가 보여요.',
        '시간이 절반 지나면 한 글자를 공개해요.'] },
      { h: '점수·승리', p: [
        '맞힌 사람만 점수를 받아요. 바로 맞히면 10점, 시간이 갈수록 줄어 마지막엔 3점.',
        '그린 사람은 점수가 없어요(모두 똑같이 돌아가며 그리니까 공평해요). 그래도 잘 그려야 다들 맞히겠죠?',
        '모두 맞히거나 시간이 끝나면 정답을 공개하고, 다음 사람이 그려요.',
        '모두가 정해진 횟수만큼 그리면 끝! 점수가 가장 높은 사람이 이겨요. 같으면 공동 우승, 모두 0점이면 무승부예요.'] },
      { h: '특수 규칙', p: [
        '한 폰: 그리는 중에 제시어를 다시 보려면 위의 「꾹 눌러 제시어」를 누르고 있으세요.',
        '한 폰: 아무도 못 맞히면 「아무도 못 맞힘」을 누르거나 시간이 끝나길 기다려요. 누가 맞힌 뒤엔 「여기서 끝내기」로 넘어가요.',
        '온라인: 그림 크기에 한도가 있어요. 아래 잉크 막대가 다 닳으면 되돌리기나 지우기로 잉크를 되찾아요.'] },
      { h: '조작 (그리기 도구)', p: [
        '색 8가지, 펜 굵기 3가지, 지우개, 되돌리기, 모두 지우기(두 번 눌러 확인 · 되돌리기로 살릴 수 있어요).',
        '한 손가락으로 그려요. 다른 손가락이나 손바닥은 무시해요.'] },
      { h: '예시', p: [
        '민지가 「기린」을 골라 목이 긴 동물을 그려요. 맞히는 사람 화면엔 「동물 · ○○」.',
        '10초 만에 준호가 「기린!」 → 준호 +9점쯤. 40초쯤 지나 지아가 맞히면 점수가 더 적어요.',
        '민지는 점수가 없지만, 다음엔 준호가 그리고 민지가 맞힐 차례예요.'] },
    ],
    options: [
      { id: 'cat', label: '분야', choices: [{ v: 'all', label: '전체 랜덤' }].concat(CATS.map((c) => ({ v: c.id, label: c.name }))), def: 'all' },
      { id: 'rounds', label: '라운드 (각자 그리는 횟수)', choices: [{ v: 1, label: '1번씩' }, { v: 2, label: '2번씩' }, { v: 3, label: '3번씩' }], def: 2 },
      { id: 'time', label: '제한 시간', choices: [{ v: 60, label: '60초' }, { v: 80, label: '80초' }, { v: 100, label: '100초' }], def: 80 },
    ],
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, hidden: false, aiDelay: 650,
    init, actor, apply, result, mount,
    ai: () => null,
    aiDelayFor: () => -1,
    _t: { CATS, tick, nextTurn, enc, dec, keyOf, norm, answers, isClose, quant, rdp, encStroke, decStroke, drawingSize, inkBudgetFor, utf8Len, clock, STATE_MAX, GUEST_INK, PICK_MS, REVEAL_MS },
  };
  L.register(def);
})();
