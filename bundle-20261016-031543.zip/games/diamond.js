/* 다이아몬드 게임 — Chinese checkers on the 121-hole star board: steps, jump chains, camp rules, per-seat AI. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------------- board geometry (cube coords q+r+s=0) ---------------- */
  const CQ = [], CR = [], CS = [];
  const IDX = new Int16Array(17 * 17).fill(-1);
  for (let r = -8; r <= 8; r++) for (let q = -8; q <= 8; q++) {
    const s = -q - r;
    if (s < -8 || s > 8) continue;
    const t1 = q >= -4 && r >= -4 && s >= -4, t2 = q <= 4 && r <= 4 && s <= 4;
    if (!t1 && !t2) continue;
    IDX[(q + 8) * 17 + (r + 8)] = CQ.length;
    CQ.push(q); CR.push(r); CS.push(s);
  }
  const NC = CQ.length; // 121
  const at = (q, r) => (q < -8 || q > 8 || r < -8 || r > 8 ? -1 : IDX[(q + 8) * 17 + (r + 8)]);
  const DIRS = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];
  const NB = new Int16Array(NC * 6).fill(-1);
  for (let i = 0; i < NC; i++) DIRS.forEach(([dq, dr], d) => { NB[i * 6 + d] = at(CQ[i] + dq, CR[i] + dr); });
  const coord = (i, ax) => (ax === 0 ? CQ[i] : ax === 1 ? CR[i] : CS[i]);
  // camps in angular order: q+, s-, r+, q-, s+, r-  (opposite camp = k+3)
  const CAMPS = [[0, 1], [2, -1], [1, 1], [0, -1], [2, 1], [1, -1]]; // [axis, sign]
  const CAMP = new Int8Array(NC).fill(-1);
  const Z10 = [], Z15 = [], COST = [], DIST = [];
  for (let k = 0; k < 6; k++) {
    const [ax, sg] = CAMPS[k];
    const z10 = [], z15 = [], cost = new Float32Array(NC), dist = new Int8Array(NC);
    for (let i = 0; i < NC; i++) {
      const v = sg * coord(i, ax);
      const o = [0, 1, 2].filter((a) => a !== ax).map((a) => sg * coord(i, a));
      if (v > 4) { CAMP[i] = k; z10.push(i); }
      if (v >= 4 && o[0] >= -4 && o[1] >= -4) z15.push(i);
      dist[i] = 8 - v;
      const lat = Math.abs(o[0] - o[1]);
      cost[i] = (8 - v) + (v > 4 ? 0 : Math.max(0, lat - 4) * 0.45);
    }
    Z10.push(z10); Z15.push(z15); COST.push(cost); DIST.push(dist);
  }
  const SEAT_CAMPS = { 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 3, 4], 6: [0, 1, 2, 3, 4, 5] };
  const TURN_CAP = 150; // turns per player before the progress tie-break
  const UNDO_MAX = 6;

  /* ---------------- rules helpers ---------------- */
  const home = (s, seat) => s.cp[seat];
  const tgt = (s, seat) => (s.cp[seat] + 3) % 6;
  const zone = (s, k) => (s.m === 15 ? Z15[k] : Z10[k]);
  function toArr(b) { const a = new Int8Array(NC); for (let i = 0; i < NC; i++) a[i] = b.charCodeAt(i) === 46 ? -1 : b.charCodeAt(i) - 48; return a; }
  function toStr(a) { let s = ''; for (let i = 0; i < NC; i++) s += a[i] < 0 ? '.' : String(a[i]); return s; }
  function neutralFn(hk, tk) { return (c) => CAMP[c] >= 0 && CAMP[c] !== hk && CAMP[c] !== tk; }

  /* all destinations of the marble at f → count written into `out`. `jp` receives the jump-parent tree
     (-2 = not reached by jumping, -1 = origin). nc: 0 = foreign camps may be passed through while jumping but
     a move can't end there, 1 = never land in them, 2 = no restriction. */
  const JP = new Int16Array(NC), QU = new Int16Array(NC), SEEN = new Uint8Array(NC);
  function dests(a, f, hk, tk, nc, out, jp) {
    jp = jp || JP; jp.fill(-2); jp[f] = -1; SEEN.fill(0);
    const neu = nc === 2 ? null : neutralFn(hk, tk);
    let n = 0;
    for (let d = 0; d < 6; d++) {
      const c = NB[f * 6 + d];
      if (c >= 0 && a[c] < 0 && !(neu && neu(c))) { SEEN[c] = 1; out[n++] = c; }
    }
    let h = 0, tl = 0; QU[tl++] = f;
    while (h < tl) {
      const c = QU[h++];
      for (let d = 0; d < 6; d++) {
        const o = NB[c * 6 + d];
        if (o < 0 || o === f || a[o] < 0) continue;
        const l = NB[o * 6 + d];
        if (l < 0 || l === f || a[l] >= 0 || jp[l] !== -2) continue;
        const bad = neu && neu(l);
        if (bad && nc === 1) continue;
        jp[l] = c; QU[tl++] = l;
        if (!bad && !SEEN[l]) { SEEN[l] = 1; out[n++] = l; }
      }
    }
    return n;
  }
  function adj(x, y) { for (let d = 0; d < 6; d++) if (NB[x * 6 + d] === y) return true; return false; }
  function pathFor(f, t, jp) { if (adj(f, t)) return [f, t]; const p = []; let c = t; while (c !== -1) { p.push(c); c = jp[c]; } return p.reverse(); }

  function marbles(a, seat) { const p = []; for (let i = 0; i < NC; i++) if (a[i] === seat) p.push(i); return p; }
  function hasMove(a, s, seat) {
    const out = new Int16Array(NC), hk = home(s, seat), tk = tgt(s, seat);
    for (const f of marbles(a, seat)) if (dests(a, f, hk, tk, s.o.nc, out) > 0) return true;
    return false;
  }
  function finished(a, s, seat) {
    const z = zone(s, tgt(s, seat));
    let mine = 0;
    for (const c of z) { if (a[c] < 0) return false; if (a[c] === seat) mine++; else if (!s.o.as) return false; }
    return mine > 0;
  }
  function costSum(a, s, seat) { const cs = COST[tgt(s, seat)]; let t = 0; for (let i = 0; i < NC; i++) if (a[i] === seat) t += cs[i]; return t; }
  function minCost(s) { const z = zone(s, 0); let t = 0; for (const c of z) t += DIST[0][c]; return t; }
  function startCost(s, seat) { const cs = COST[tgt(s, seat)]; let t = 0; for (const c of zone(s, home(s, seat))) t += cs[c]; return t; }
  function progress(s, seat, a) { a = a || toArr(s.b); const st = startCost(s, seat), mn = minCost(s); return U.clamp((st - costSum(a, s, seat)) / (st - mn), 0, 1); }
  function inTarget(s, seat) { let k = 0; for (const c of zone(s, tgt(s, seat))) if (s.b[c] === String(seat)) k++; return k; }

  /* ---------------- state ---------------- */
  const FIVE_MSG = '다이아몬드 게임은 2·3·4·6명으로 할 수 있어요. 5명은 진영이 고르게 나뉘지 않아 할 수 없어요. 인원을 바꿔 다시 시작해 주세요.';
  function init(players, opts) {
    opts = opts || {};
    if (players.length === 5) return { n: 5, five: 1, nm: players.map((p) => String(p.name || '').slice(0, 10)), st: { r: 'five' }, b: '', fin: [], t: 0, tc: 0, seq: 0, last: null, u: [], ev: null, cp: [], m: 10, o: {} };
    const n = U.clamp(players.length, 2, 6);
    const m = opts.mc === 15 && n === 2 ? 15 : 10;
    const s = { n, cp: SEAT_CAMPS[n].slice(), m, o: { nc: opts.nc != null ? opts.nc : 0, as: opts.as != null ? opts.as : 1, rk: n > 2 && opts.rk ? 1 : 0 },
      nm: players.map((p, i) => String(p.name || (i + 1) + '번').slice(0, 10)), b: '', t: 0, tc: 0, fin: [], seq: 0, last: null, u: [], ev: null, st: null };
    const a = new Int8Array(NC).fill(-1);
    for (let i = 0; i < n; i++) for (const c of zone(s, s.cp[i])) a[c] = i;
    s.b = toStr(a);
    const hum = players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0);
    s.h = hum.length === 1 ? hum[0] : -1;
    return s;
  }
  function actor(s) { return s.st ? null : s.t; }
  const active = (s, i) => !s.fin.includes(i);

  function rankList(s, a) {
    a = a || toArr(s.b);
    const rest = [];
    for (let i = 0; i < s.n; i++) if (!s.fin.includes(i)) rest.push(i);
    rest.sort((x, y) => costSum(a, s, x) - costSum(a, s, y));
    return s.fin.concat(rest);
  }
  function advance(s, a) {
    // who finished with this move (mover first, then everybody in turn order)
    for (let k = 0; k < s.n; k++) {
      const i = (s.t + k) % s.n;
      if (active(s, i) && finished(a, s, i)) { s.fin.push(i); s.ev = { id: s.seq, k: 'f', s: i, r: s.fin.length }; }
    }
    const left = [];
    for (let i = 0; i < s.n; i++) if (active(s, i)) left.push(i);
    if (s.fin.length && (!s.o.rk || left.length <= 1)) { s.st = { r: 'win' }; return; }
    if (s.tc >= TURN_CAP * s.n) { s.st = { r: 'cap' }; return; }
    let skipped = [];
    for (let k = 1; k <= s.n; k++) {
      const i = (s.t + k) % s.n;
      if (!active(s, i)) continue;
      if (hasMove(a, s, i)) { s.t = i; if (skipped.length) s.ev = { id: s.seq, k: 'p', s: skipped[0] }; return; }
      skipped.push(i);
    }
    s.st = { r: 'stuck' };
  }

  function validPath(a, s, seat, p) {
    if (!Array.isArray(p) || p.length < 2 || p.length > 40) return false;
    const f = p[0];
    const neu = s.o.nc === 2 ? null : neutralFn(home(s, seat), tgt(s, seat));
    const nbDir = (x, y) => { for (let d = 0; d < 6; d++) if (NB[x * 6 + d] === y) return d; return -1; };
    if (p.length === 2 && nbDir(p[0], p[1]) >= 0) return a[p[1]] < 0 && !(neu && neu(p[1]));
    const seen = new Set([f]);
    for (let i = 1; i < p.length; i++) {
      const x = p[i - 1], y = p[i];
      if (!(y >= 0 && y < NC) || seen.has(y) || a[y] >= 0) return false;
      let ok = false;
      for (let d = 0; d < 6; d++) { const o = NB[x * 6 + d]; if (o >= 0 && o !== f && a[o] >= 0 && NB[o * 6 + d] === y) ok = true; }
      if (!ok) return false;
      if (s.o.nc === 1 && neu(y)) return false;
      seen.add(y);
    }
    return !(neu && neu(p[p.length - 1]));
  }

  function apply(s, seat, act) {
    if (s.st) throw new Error('game over');
    if (seat !== s.t) throw new Error('not your turn');
    if (!act) throw new Error('bad action');
    if (act.type === 'undo') {
      if (seat !== s.h || !s.u || !s.u.length) throw new Error('nothing to undo');
      const u = s.u.pop();
      s.b = u.b; s.t = u.t; s.tc = u.tc; s.fin = u.f; s.last = null;
      s.seq++; s.ev = { id: s.seq, k: 'u', s: seat };
      return s;
    }
    if (act.type !== 'move') throw new Error('bad action');
    const a = toArr(s.b);
    const p = (act.p || []).map((x) => x | 0);
    const f = p[0];
    if (!(f >= 0 && f < NC) || a[f] !== seat) throw new Error('not your marble');
    const t = p[p.length - 1];
    const out = new Int16Array(NC), par = new Int16Array(NC);
    const n = dests(a, f, home(s, seat), tgt(s, seat), s.o.nc, out, par);
    let ok = false;
    for (let i = 0; i < n; i++) if (out[i] === t) ok = true;
    if (!ok) throw new Error('illegal move');
    const path = validPath(a, s, seat, p) ? p : pathFor(f, t, par);
    if (seat === s.h) { s.u.push({ b: s.b, t: s.t, tc: s.tc, f: s.fin.slice() }); if (s.u.length > UNDO_MAX) s.u.shift(); }
    a[f] = -1; a[t] = seat;
    s.b = toStr(a);
    s.seq++; s.tc++;
    s.last = { id: s.seq, s: seat, p: path };
    s.ev = null;
    advance(s, a);
    if (s.st) s.u = [];
    while (JSON.stringify(s).length > 2450 && s.u.length) s.u.shift();
    return s;
  }

  function result(s) {
    if (!s.st) return null;
    if (s.five) return { winners: [], title: '5명은 할 수 없어요', text: FIVE_MSG };
    const rk = rankList(s);
    const a = toArr(s.b);
    const lines = rk.map((i, r) => (r + 1) + '위 ' + s.nm[i] + (s.fin.includes(i) ? ' · 도착' : ' · ' + Math.round(progress(s, i, a) * 100) + '%'));
    const title = s.st.r === 'cap' ? '수 제한 — 진행도로 판정' : s.st.r === 'stuck' ? '더 둘 수 없음 — 진행도로 판정' : null;
    const r = { winners: [rk[0]], text: lines.join('\n') };
    if (title) r.title = title;
    return r;
  }

  /* ---------------- AI ---------------- */
  function evalSeat(a, s, seat, pos) {
    const cs = COST[tgt(s, seat)], ds = DIST[tgt(s, seat)];
    let sum = 0, mx = 0, n = 0;
    for (const c of pos) { const v = cs[c]; sum += v; if (ds[c] > mx) mx = ds[c]; n++; }
    const avg = sum / n;
    let strag = 0, coh = 0;
    for (const c of pos) {
      const over = ds[c] - avg - 3;
      if (over > 0) strag += over * over;
      if (ds[c] > 4) for (let d = 0; d < 6; d++) { const o = NB[c * 6 + d]; if (o >= 0 && a[o] >= 0) { coh += 0.12; break; } }
    }
    return -sum - 0.35 * strag + coh;
  }
  function genMoves(a, s, seat, pos) {
    const res = [], out = new Int16Array(NC), hk = home(s, seat), tk = tgt(s, seat), cs = COST[tk];
    for (const f of pos) {
      const n = dests(a, f, hk, tk, s.o.nc, out);
      for (let i = 0; i < n; i++) res.push({ f, t: out[i], g: cs[f] - cs[out[i]] });
    }
    return res;
  }
  function doMove(a, pos, m, seat) { a[m.f] = -1; a[m.t] = seat; pos[pos.indexOf(m.f)] = m.t; }
  function undoMove(a, pos, m, seat) { a[m.t] = -1; a[m.f] = seat; pos[pos.indexOf(m.t)] = m.f; }
  function nextActive(s, seat) { for (let k = 1; k < s.n; k++) { const i = (seat + k) % s.n; if (active(s, i)) return i; } return seat; }

  function ai(s, seat, lv) {
    lv = lv || 2;
    const a = toArr(s.b);
    const pos = marbles(a, seat);
    const moves = genMoves(a, s, seat, pos);
    if (!moves.length) return null;
    let best = null;
    const winNow = (m) => { doMove(a, pos, m, seat); const w = finished(a, s, seat); undoMove(a, pos, m, seat); return w; };
    for (const m of moves) if (winNow(m)) return mk(m);
    if (lv === 1) {
      if (Math.random() < 0.2) {
        const ok = moves.filter((m) => m.g >= 0);
        best = (ok.length ? ok : moves)[U.rand(ok.length || moves.length)];
      } else {
        const ds = DIST[tgt(s, seat)];
        let bs = -1e9;
        for (const m of moves) { const sc = m.g * (1 + ds[m.f] * 0.04) + Math.random() * 2.6; if (sc > bs) { bs = sc; best = m; } }
      }
      return mk(best);
    }
    if (lv === 2) {
      let bs = -1e9;
      for (const m of moves) {
        doMove(a, pos, m, seat);
        const e1 = evalSeat(a, s, seat, pos);
        let e2 = e1;
        const fol = genMoves(a, s, seat, pos);
        fol.sort((x, y) => y.g - x.g);
        for (let i = 0; i < Math.min(6, fol.length); i++) {
          doMove(a, pos, fol[i], seat); const e = evalSeat(a, s, seat, pos); undoMove(a, pos, fol[i], seat);
          if (e > e2) e2 = e;
        }
        undoMove(a, pos, m, seat);
        const sc = e1 * 0.55 + e2 * 0.45 + Math.random() * 0.35;
        if (sc > bs) { bs = sc; best = m; }
      }
      return mk(best);
    }
    // 어려움: my move -> next player's reply -> my best follow-up
    const opp = nextActive(s, seat), two = opp !== seat && s.n - s.fin.length === 2;
    const opos = marbles(a, opp);
    const root = beam(a, s, seat, pos, moves, 14);
    let bs = -1e9;
    const t0 = Date.now();
    for (const m of root) {
      doMove(a, pos, m, seat);
      if (finished(a, s, seat)) { undoMove(a, pos, m, seat); return mk(m); }
      let worst = 1e9;
      if (opp !== seat) {
        const om = beam(a, s, opp, opos, genMoves(a, s, opp, opos), two ? 8 : 4);
        let replies = om;
        if (!two && om.length) { // a non-final opponent plays its own best move
          let bo = -1e9, pick = om[0];
          for (const r of om) { doMove(a, opos, r, opp); const e = evalSeat(a, s, opp, opos); undoMove(a, opos, r, opp); if (e > bo) { bo = e; pick = r; } }
          replies = [pick];
        }
        if (!replies.length) replies = [null];
        for (const r of replies) {
          if (r) doMove(a, opos, r, opp);
          let v = followUp(a, s, seat, pos);
          if (two) v -= 0.6 * evalSeat(a, s, opp, opos);
          if (r) undoMove(a, opos, r, opp);
          if (v < worst) worst = v;
          if (worst < bs) break;
        }
      } else worst = followUp(a, s, seat, pos);
      undoMove(a, pos, m, seat);
      const sc = worst + Math.random() * 0.02;
      if (sc > bs) { bs = sc; best = m; }
      if (Date.now() - t0 > 450) break;
    }
    return mk(best || moves[0]);
  }
  function followUp(a, s, seat, pos) {
    let best = evalSeat(a, s, seat, pos) - 1.5;
    const ms = genMoves(a, s, seat, pos);
    for (const m of ms) {
      doMove(a, pos, m, seat);
      const e = finished(a, s, seat) ? 1e6 : evalSeat(a, s, seat, pos);
      undoMove(a, pos, m, seat);
      if (e > best) best = e;
    }
    return best;
  }
  function beam(a, s, seat, pos, moves, k) {
    const sc = moves.map((m) => { doMove(a, pos, m, seat); const e = evalSeat(a, s, seat, pos); undoMove(a, pos, m, seat); return { m, e }; });
    sc.sort((x, y) => y.e - x.e);
    return sc.slice(0, k).map((x) => x.m);
  }
  function mk(m) { return { type: 'move', p: [m.f, m.t] }; }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 650 : lv === 3 ? 220 : 400; }

  /* ---------------- view ---------------- */
  const SQ3 = Math.sqrt(3);
  const px = (i) => [SQ3 * (CQ[i] + CR[i] / 2), 1.5 * CR[i]];
  function tipAngle(k) { const z = Z10[k]; let best = z[0], bv = -1; for (const c of z) { const v = DIST[(k + 3) % 6][c]; if (v > bv) { bv = v; best = c; } } const [x, y] = px(best); return Math.atan2(y, x); }
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }

  function mount(root, api) {
    const cv = U.canvas(root);
    let ctx = cv.ctx; // swapped to an offscreen context while the static board layer is (re)built
    let bLayer = null, bKey = '';
    let st = null, sel = -1, dmap = null, press = -1, anim = null, stopLoop = null, animTimer = 0, busy = false;
    let rot = 0, rotTarget = 0, rotLoop = null, viewSeat = 0, waitSeq = -1, waitUntil = 0, G = null, pdown = null;

    const top = L.h('div', { class: 'hud top dm-top', style: { gap: '5px', padding: '6px 8px', flexWrap: 'nowrap' } });
    const hint = L.h('div', { class: 'muted dm-hint', style: { flex: '1 1 auto', minWidth: 0, fontSize: '12.5px', fontWeight: 700, lineHeight: 1.3, textAlign: 'left' } });
    const undoBtn = L.h('button', { class: 'btn sm ghost', style: { minHeight: '44px', flex: 'none', padding: '6px 12px' }, text: '↶ 무르기', 'aria-label': '한 수 무르기', onclick: onUndo });
    const bot = L.h('div', { class: 'hud bottom', style: { gap: '8px', padding: '8px 12px', flexWrap: 'nowrap', justifyContent: 'space-between' } }, hint, undoBtn);
    root.append(top, bot);
    // invisible boxes over canvas areas (whole star, bottom camp = mine, top camp = goal), for the first-play tutorial
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const spBoard = spot('dm-board'), spHome = spot('dm-home'), spGoal = spot('dm-goal');
    function placeSpots() {
      const box = () => ({ x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 });
      const all = box(), camps = [0, 1, 2, 3, 4, 5].map(box);
      for (let i = 0; i < NC; i++) {
        const [x, y] = P(i);
        for (const b of CAMP[i] >= 0 ? [all, camps[CAMP[i]]] : [all]) { b.x0 = Math.min(b.x0, x); b.y0 = Math.min(b.y0, y); b.x1 = Math.max(b.x1, x); b.y1 = Math.max(b.y1, y); }
      }
      const cy = (b) => b.y0 + b.y1, r = G.sp * 0.5;
      const sorted = camps.slice().sort((a, b) => cy(a) - cy(b));
      const put = (d, b) => Object.assign(d.style, { left: Math.round(b.x0 - r) + 'px', top: Math.round(b.y0 - r) + 'px', width: Math.round(b.x1 - b.x0 + 2 * r) + 'px', height: Math.round(b.y1 - b.y0 + 2 * r) + 'px' });
      put(spBoard, all); put(spGoal, sorted[0]); put(spHome, sorted[5]);
    }

    const name = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const color = (i) => (api.players[i] ? api.players[i].color : L.COLORS[i]);
    function myTurn() { return !!st && !st.st && api.canAct(st.t); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function sendAct(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }
    function chooseView() {
      const mine = []; for (let i = 0; i < st.n; i++) if (api.canAct(i)) mine.push(i);
      if (mine.length === 1) return mine[0];
      if (mine.length > 1) return mine.includes(st.t) ? st.t : (mine.includes(viewSeat) ? viewSeat : mine[0]);
      return 0;
    }
    function setView(seat, instant) {
      viewSeat = seat;
      let target = Math.PI / 2 - tipAngle(st.cp[seat]);
      while (target - rot > Math.PI) target -= Math.PI * 2;
      while (target - rot < -Math.PI) target += Math.PI * 2;
      rotTarget = target;
      if (instant || Math.abs(target - rot) < 1e-3) { rot = target; return; }
      if (!rotLoop) rotLoop = U.loop((dt) => {
        const d = rotTarget - rot;
        rot += d * Math.min(1, dt * 7 * L.debug.speed);
        if (Math.abs(rotTarget - rot) < 0.002) { rot = rotTarget; rotLoop(); rotLoop = null; }
        draw();
      });
    }

    function layout() {
      const W = cv.w, H = cv.h, topH = 46, botH = 60;
      const availH = H - topH - botH - 6, availW = W - 12;
      const sc = Math.max(6, Math.min(availW / (2 * 10.392 * 14 / 12 + 0.6), availH / (28 + 0.6)));
      G = { cx: W / 2, cy: topH + 2 + availH / 2 + 2, sc, sp: sc * SQ3 };
    }
    function P(i) {
      const [x, y] = px(i), c = Math.cos(rot), s = Math.sin(rot);
      return [G.cx + (x * c - y * s) * G.sc, G.cy + (x * s + y * c) * G.sc];
    }
    function PU(x, y) { const c = Math.cos(rot), s = Math.sin(rot); return [G.cx + (x * c - y * s) * G.sc, G.cy + (x * s + y * c) * G.sc]; }
    function hit(x, y) {
      let best = -1, bd = (G.sp * 0.62) ** 2;
      for (let i = 0; i < NC; i++) { const [px2, py2] = P(i); const d = (px2 - x) ** 2 + (py2 - y) ** 2; if (d < bd) { bd = d; best = i; } }
      return best;
    }
    /* holes sit only ~24 px apart on a small phone: a tap that misses every hole still counts for the nearest
       glowing destination (or, with nothing chosen yet, the nearest own marble) within about one hole spacing */
    function nearest(x, y, ok, rad) {
      let best = -1, bd = (G.sp * rad) ** 2;
      for (let i = 0; i < NC; i++) { if (!ok(i)) continue; const [px2, py2] = P(i); const d = (px2 - x) ** 2 + (py2 - y) ** 2; if (d < bd) { bd = d; best = i; } }
      return best;
    }
    const isDest = (i) => !!(dmap && dmap.has(i));
    const isMine = (i) => !!st && st.b[i] === String(st.t);
    function pick(x, y) {
      const c = hit(x, y);
      if (c >= 0 && (isDest(c) || isMine(c))) return c;
      const d = nearest(x, y, isDest, 0.95);
      if (d >= 0) return d;
      const m = nearest(x, y, isMine, 0.9);
      return m >= 0 ? m : c;
    }
    function pickDest(x, y) { const c = hit(x, y); return c >= 0 && isDest(c) ? c : nearest(x, y, isDest, 0.95); }

    function campTri(k, pad) {
      const z = Z10[k], other = (k + 3) % 6;
      let tip = z[0];
      for (const c of z) if (DIST[other][c] > DIST[other][tip]) tip = c;
      const base = z.filter((c) => DIST[other][c] === 13);
      let e1 = base[0], e2 = base[0];
      const [ax] = CAMPS[k], oa = [0, 1, 2].find((a) => a !== ax);
      for (const c of base) { if (coord(c, oa) < coord(e1, oa)) e1 = c; if (coord(c, oa) > coord(e2, oa)) e2 = c; }
      const pts = [tip, e1, e2].map(px);
      const gx = (pts[0][0] + pts[1][0] + pts[2][0]) / 3, gy = (pts[0][1] + pts[1][1] + pts[2][1]) / 3;
      const R = Math.hypot(pts[0][0] - gx, pts[0][1] - gy), f = (R + pad) / R;
      return pts.map(([x, y]) => PU(gx + (x - gx) * f, gy + (y - gy) * f));
    }
    function poly(pts) { ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.closePath(); }

    function drawBoard() {
      // wooden star: union of two big triangles
      const star = [];
      for (let k = 0; k < 6; k++) { // tips (±8,∓4,∓4 perms) and concave corners (±4,∓4,0 perms)
        const cs = [[8, -4], [-4, 8], [-4, -4], [-8, 4], [4, -8], [4, 4], [4, -4], [-4, 4], [0, 4], [0, -4], [4, 0], [-4, 0]];
        if (k) break;
        for (const [q, r] of cs) { const x = SQ3 * (q + r / 2), y = 1.5 * r; star.push([Math.atan2(y, x), x * 14 / 12, y * 14 / 12]); }
      }
      star.sort((u, v) => u[0] - v[0]);
      const sp = star.map(([, x, y]) => PU(x, y));
      ctx.save();
      ctx.lineJoin = 'round';
      poly(sp);
      ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 18; ctx.shadowOffsetY = 6;
      ctx.lineWidth = G.sc * 0.9; ctx.strokeStyle = '#6b4526'; ctx.stroke();
      const wood = ctx.createRadialGradient(G.cx - G.sc * 3, G.cy - G.sc * 4, G.sc, G.cx, G.cy, G.sc * 14);
      wood.addColorStop(0, '#c99a5b'); wood.addColorStop(0.6, '#a87640'); wood.addColorStop(1, '#7d5129');
      ctx.fillStyle = wood; ctx.fill();
      ctx.shadowColor = 'transparent';
      ctx.lineWidth = Math.max(1, G.sc * 0.12); ctx.strokeStyle = 'rgba(255,230,190,.25)'; ctx.stroke();
      ctx.clip();
      // grain
      ctx.globalAlpha = 0.07; ctx.strokeStyle = '#3a2210'; ctx.lineWidth = 1;
      for (let i = -14; i <= 14; i++) { ctx.beginPath(); const y = G.cy + i * G.sc * 0.95; ctx.moveTo(0, y); ctx.bezierCurveTo(cv.w * 0.3, y + 6 * Math.sin(i), cv.w * 0.7, y - 6 * Math.cos(i), cv.w, y + 3); ctx.stroke(); }
      ctx.globalAlpha = 1;
      ctx.restore();
      // camps tinted by owner / target
      for (let k = 0; k < 6; k++) {
        const own = st.cp.indexOf(k), tg = st.cp.indexOf((k + 3) % 6);
        const pts = campTri(k, G.sp > 0 ? 0.95 * SQ3 : 1);
        ctx.save(); ctx.lineJoin = 'round';
        if (own >= 0) { poly(pts); ctx.globalAlpha = 0.28; ctx.fillStyle = color(own); ctx.fill(); ctx.globalAlpha = 0.55; ctx.lineWidth = Math.max(1.5, G.sc * 0.14); ctx.strokeStyle = color(own); ctx.stroke(); }
        else if (tg >= 0) { poly(pts); ctx.globalAlpha = 0.6; ctx.setLineDash([G.sc * 0.5, G.sc * 0.4]); ctx.lineWidth = Math.max(1.5, G.sc * 0.14); ctx.strokeStyle = color(tg); ctx.stroke(); }
        ctx.restore();
      }
      // my target camp: brass outline
      const me = st && api.canAct(viewSeat) ? viewSeat : -1;
      if (me >= 0 && !st.st) {
        const pts = campTri(tgt(st, me), 1.25 * SQ3);
        ctx.save(); ctx.lineJoin = 'round'; poly(pts); ctx.setLineDash([G.sc * 0.6, G.sc * 0.45]); ctx.lineWidth = Math.max(1.5, G.sc * 0.13); ctx.strokeStyle = 'rgba(242,233,216,.55)'; ctx.stroke(); ctx.restore();
      }
      // holes
      const hr = G.sp * 0.27;
      for (let i = 0; i < NC; i++) {
        const [x, y] = P(i);
        const g = ctx.createRadialGradient(x, y - hr * 0.3, hr * 0.1, x, y, hr);
        g.addColorStop(0, '#2a170a'); g.addColorStop(0.75, '#4a2c14'); g.addColorStop(1, 'rgba(255,225,180,.35)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, hr, 0, Math.PI * 2); ctx.fill();
      }
    }
    function marble(x, y, col, r, lift) {
      lift = lift || 0;
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,' + (0.35 - lift * 0.15) + ')';
      ctx.beginPath(); ctx.ellipse(x + r * 0.12 + lift * r * 0.3, y + r * 0.28 + lift * r * 0.9, r * (0.95 - lift * 0.15), r * (0.7 - lift * 0.1), 0, 0, Math.PI * 2); ctx.fill();
      const yy = y - lift * r * 1.1, rr = r * (1 + lift * 0.18);
      const g = ctx.createRadialGradient(x - rr * 0.35, yy - rr * 0.4, rr * 0.08, x, yy, rr);
      g.addColorStop(0, shade(col, 0.7)); g.addColorStop(0.35, shade(col, 0.12)); g.addColorStop(0.85, shade(col, -0.35)); g.addColorStop(1, shade(col, -0.55));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, yy, rr, 0, Math.PI * 2); ctx.fill();
      // inner glow (glass)
      const g2 = ctx.createRadialGradient(x + rr * 0.3, yy + rr * 0.35, 0, x + rr * 0.3, yy + rr * 0.35, rr * 0.7);
      g2.addColorStop(0, 'rgba(255,255,255,.28)'); g2.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g2; ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.85)';
      ctx.beginPath(); ctx.ellipse(x - rr * 0.34, yy - rr * 0.42, rr * 0.26, rr * 0.15, -0.6, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
    function drawPath(p, col, alpha, w) {
      if (!p || p.length < 2) return;
      ctx.save(); ctx.globalAlpha = alpha; ctx.strokeStyle = col; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath(); p.forEach((c, i) => { const [x, y] = P(c); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.stroke();
      ctx.fillStyle = col;
      for (let i = 1; i < p.length - 1; i++) { const [x, y] = P(p[i]); ctx.beginPath(); ctx.arc(x, y, w * 1.3, 0, Math.PI * 2); ctx.fill(); }
      ctx.restore();
    }

    function boardLayer() {
      // the wooden star, camps and 121 holes don't change between moves: draw them once into an offscreen canvas
      const me = st && api.canAct(viewSeat) && !st.st ? viewSeat : -1;
      const key = cv.cv.width + 'x' + cv.cv.height + '|' + rot.toFixed(5) + '|' + me + '|' + st.cp.join(',') + '|' + st.n;
      if (rotLoop) { drawBoard(); return; } // turning: draw directly, no cache churn
      if (!bLayer) bLayer = document.createElement('canvas');
      if (key !== bKey) {
        bKey = key;
        if (bLayer.width !== cv.cv.width || bLayer.height !== cv.cv.height) { bLayer.width = cv.cv.width; bLayer.height = cv.cv.height; }
        const main = ctx, bc = bLayer.getContext('2d');
        bc.setTransform(1, 0, 0, 1, 0, 0); bc.clearRect(0, 0, bLayer.width, bLayer.height); bc.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
        ctx = bc;
        try { drawBoard(); } finally { ctx = main; }
      }
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(bLayer, 0, 0); ctx.restore();
    }

    function draw() {
      if (!st) return;
      layout();
      placeSpots();
      cv.clear();
      boardLayer();
      const b = anim ? anim.base : st.b;
      const r = G.sp * 0.4;
      // last move trail
      if (!anim && st.last && st.last.p) {
        drawPath(st.last.p, color(st.last.s), 0.45, Math.max(2, G.sc * 0.18));
        const [x, y] = P(st.last.p[0]);
        ctx.save(); ctx.strokeStyle = color(st.last.s); ctx.globalAlpha = 0.7; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, G.sp * 0.3, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
      }
      for (let i = 0; i < NC; i++) {
        const ch = b[i]; if (ch === '.') continue;
        const [x, y] = P(i);
        marble(x, y, color(+ch), r, sel === i ? 0.25 : 0);
      }
      if (sel >= 0) {
        const [x, y] = P(sel);
        ctx.save(); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y - r * 0.27, r * 1.38, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
      }
      if (dmap) {
        const col = color(st.t);
        if (press >= 0 && dmap.has(press)) drawPath(dmap.get(press), '#f2e9d8', 0.9, Math.max(2.5, G.sc * 0.2));
        for (const [t, p] of dmap) {
          const [x, y] = P(t), on = t === press;
          ctx.save();
          ctx.fillStyle = col; ctx.globalAlpha = on ? 0.95 : 0.5;
          ctx.beginPath(); ctx.arc(x, y, on ? r * 0.95 : r * 0.62, 0, Math.PI * 2); ctx.fill();
          ctx.globalAlpha = 1; ctx.strokeStyle = on ? '#fff' : 'rgba(242,233,216,.85)'; ctx.lineWidth = on ? 2.5 : 1.5; ctx.stroke();
          ctx.restore();
        }
      }
      if (anim) {
        const k = anim.k, hops = anim.p.length - 1, seg = Math.min(hops - 1, Math.floor(k * hops)), u = k * hops - seg;
        const [x1, y1] = P(anim.p[seg]), [x2, y2] = P(anim.p[seg + 1]);
        const e = u < 1 ? u * u * (3 - 2 * u) : 1;
        drawPath(anim.p.slice(0, seg + 2), color(anim.s), 0.35, Math.max(2, G.sc * 0.16));
        marble(x1 + (x2 - x1) * e, y1 + (y2 - y1) * e, color(anim.s), r, Math.sin(Math.PI * u) * (anim.jump ? 0.75 : 0.35));
      }
    }

    function finishAnim() {
      clearTimeout(animTimer);
      if (stopLoop) { stopLoop(); stopLoop = null; }
      anim = null;
      if (busy) { busy = false; api.setBusy(false); }
    }
    function startAnim(next) {
      const p = next.last.p;
      const base = next.b.split(''); base[p[p.length - 1]] = '.';
      const hops = p.length - 1, jump = !(hops === 1 && NB.slice(p[0] * 6, p[0] * 6 + 6).includes(p[1]));
      const dur = (jump ? 210 : 170) * hops / L.debug.speed;
      anim = { p, s: next.last.s, base: base.join(''), k: 0, t0: performance.now(), dur, jump, hop: 0 };
      busy = true; api.setBusy(true);
      animTimer = setTimeout(() => { if (anim) { finishAnim(); draw(); } }, dur + 700);
      stopLoop = U.loop((dt, now) => {
        if (!anim) return;
        anim.k = U.clamp((now - anim.t0) / anim.dur, 0, 1);
        const hop = Math.floor(anim.k * hops);
        if (hop > anim.hop) { anim.hop = hop; api.sfx(hop >= hops ? 'pop' : 'tick'); }
        if (anim.k >= 1) { finishAnim(); api.buzz(12); draw(); updateHud(); return; }
        draw();
      });
    }

    function computeDests(c) {
      const a = toArr(st.b), out = new Int16Array(NC), par = new Int16Array(NC);
      const n = dests(a, c, home(st, st.t), tgt(st, st.t), st.o.nc, out, par);
      const m = new Map();
      for (let i = 0; i < n; i++) m.set(out[i], pathFor(c, out[i], par));
      return m;
    }
    function canInput() { return myTurn() && !locked() && !anim; }
    function onDown(e) {
      if (!st || !G) return;
      const { x, y } = cv.local(e);
      const c = canInput() ? pick(x, y) : hit(x, y);
      pdown = { c, x, y };
      if (!canInput()) return;
      if (c >= 0 && dmap && dmap.has(c)) { press = c; api.sfx('tick'); draw(); return; }
      if (c >= 0 && st.b[c] === String(st.t)) {
        if (sel === c) { sel = -1; dmap = null; api.sfx('click'); draw(); updateHud(); return; }
        sel = c; dmap = computeDests(c); press = -1;
        api.sfx('click'); api.buzz(10);
        if (!dmap.size) api.toast('이 구슬은 갈 곳이 없어요');
        draw(); updateHud(); return;
      }
    }
    function onMove(e) {
      if (press < 0 || !G) return;
      const { x, y } = cv.local(e);
      const c = pickDest(x, y);
      if (c !== press) { press = c; if (press >= 0) api.sfx('tick'); draw(); }
    }
    function onUp(e) {
      if (!st || !G) return;
      const { x, y } = cv.local(e);
      const c = press >= 0 ? pickDest(x, y) : hit(x, y);
      if (press >= 0 && c === press && canInput() && dmap && dmap.has(c)) {
        const p = dmap.get(c);
        sel = -1; dmap = null; press = -1;
        api.buzz(15);
        sendAct({ type: 'move', p });
        draw(); updateHud(); return;
      }
      if (press >= 0) { press = -1; draw(); return; }
      if (pdown && (c < 0 || (st.b[c] === '.' && !(dmap && dmap.has(c)))) && sel >= 0 && Math.hypot(x - pdown.x, y - pdown.y) < 12) { sel = -1; dmap = null; draw(); updateHud(); }
      pdown = null;
    }
    function onCancel() { press = -1; pdown = null; draw(); }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.onresize = () => draw();
    L.games.diamond._pt = (c) => { if (!G) return null; const r = cv.cv.getBoundingClientRect(), q = P(c); return [r.left + q[0], r.top + q[1]]; }; // test hook

    function canUndo() { return !api.online && !!st && !st.st && st.h >= 0 && api.canAct(st.h) && st.t === st.h && st.u && st.u.length > 0 && !anim && !locked(); }
    function onUndo() { if (!canUndo()) return; sel = -1; dmap = null; press = -1; api.sfx('click'); api.buzz(15); sendAct({ type: 'undo' }); }

    let topSig = '';
    function updateHud() {
      if (!st) return;
      const sig = st.b + '|' + st.t + '|' + st.fin.join(',') + '|' + !!st.st;
      if (sig !== topSig) {
        topSig = sig;
        top.innerHTML = '';
        const many = st.n >= 4;
        for (let i = 0; i < st.n; i++) {
          const rank = st.fin.indexOf(i), cur = !st.st && st.t === i;
          top.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '5px', padding: many ? '4px 6px' : '5px 9px', flex: '1 1 0', minWidth: 0, maxWidth: '170px', borderColor: cur ? 'var(--brass)' : '', boxShadow: cur ? '0 0 0 1px var(--brass)' : 'none', opacity: rank >= 0 && !st.st ? 0.7 : 1 } },
            L.h('span', { class: 'dot', style: { '--c': color(i), flex: 'none' } }),
            many ? null : L.h('span', { style: { fontSize: '12px', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0, flex: '1 1 auto' }, text: name(i) }),
            L.h('span', { class: 'mono', style: { fontSize: '12px', fontWeight: 700, color: rank >= 0 ? 'var(--brass)' : 'var(--ink)', flex: 'none', marginLeft: many ? '0' : 'auto' }, text: rank >= 0 ? (rank + 1) + '위' : inTarget(st, i) + '/' + st.m })));
        }
      }
      const mine = myTurn();
      if (mine && !anim) hint.textContent = sel < 0 ? '움직일 구슬을 탭하세요' : (dmap && dmap.size ? '빛나는 구멍을 탭해 이동 · 꾹 누르면 경로' : '다른 구슬을 골라 보세요');
      else if (st.st) hint.textContent = '';
      else hint.textContent = '';
      hint.style.visibility = hint.textContent ? 'visible' : 'hidden';
      const solo = !api.online && st.h >= 0 && api.canAct(st.h) && !st.st;
      undoBtn.style.display = solo ? '' : 'none';
      undoBtn.disabled = !canUndo();
      bot.style.display = solo || hint.textContent ? '' : 'none';
    }

    return {
      update(next, prev) {
        if (next && next.five) { st = null; cv.clear(); return; } // 5 players are not supported; the core shows the message
        const fresh = prev && prev !== next && prev.seq !== next.seq;
        st = next;
        if (!prev) { finishAnim(); sel = -1; dmap = null; setView(chooseView(), true); }
        if (fresh) {
          finishAnim();
          sel = -1; dmap = null; press = -1;
          if (next.last && next.last.id === next.seq && prev.seq === next.seq - 1) startAnim(next);
          const ev = next.ev && next.ev.id === next.seq ? next.ev : null;
          if (ev) {
            if (ev.k === 'u') { api.sfx('whoosh'); api.toast('한 수 물렀어요'); }
            else if (ev.k === 'f') { api.sfx('win'); api.buzz(30); if (!next.st) api.toast(name(ev.s) + ' ' + ev.r + '위 도착!'); }
            else if (ev.k === 'p') api.toast(name(ev.s) + ' — 둘 수 있는 수가 없어 건너뜀');
          }
        } else if (prev && prev !== next && prev.seq === next.seq) { /* same */ }
        if (next.st) { sel = -1; dmap = null; }
        const v = chooseView();
        if (v !== viewSeat || !prev) setView(v, !prev);
        updateHud();
        draw();
      },
      destroy() {
        finishAnim();
        if (rotLoop) { rotLoop(); rotLoop = null; }
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onCancel);
        cv.destroy(); top.remove(); bot.remove();
      },
    };
  }

  L.register({
    id: 'diamond', name: '다이아몬드 게임', tag: '전략 레이스', cat: '보드',
    blurb: '별 모양 판에서 내 구슬 10개를 맞은편 진영으로 먼저 모두 옮기면 이겨요. 한 칸씩 걷거나, 구슬을 뛰어넘어 연속 점프! (2·3·4·6명)',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 2, hidden: false, aiDelay: 400,
    tint: '#6a2a55',
    icon: '<polygon points="28,4 48.8,40 7.2,40" fill="currentColor" opacity=".35"/><polygon points="28,52 48.8,16 7.2,16" fill="currentColor" opacity=".35"/><circle cx="28" cy="12" r="4" fill="currentColor"/><circle cx="24" cy="19" r="4" fill="currentColor"/><circle cx="32" cy="19" r="4" fill="currentColor"/><circle cx="28" cy="44" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="16" cy="34" r="4" fill="currentColor" opacity=".75"/><circle cx="40" cy="34" r="4" fill="currentColor" opacity=".75"/>',
    options: [
      { id: 'nc', label: '남의 진영', choices: [{ v: 0, label: '지나가기만 허용' }, { v: 1, label: '들어가기 금지' }, { v: 2, label: '제한 없음' }], def: 0 },
      { id: 'as', label: '진영 막기 방지', choices: [{ v: 1, label: '켬' }, { v: 0, label: '끔' }], def: 1 },
      { id: 'mc', label: '구슬 수', choices: [{ v: 10, label: '10개' }, { v: 15, label: '15개 (2명일 때)' }], def: 10 },
      { id: 'rk', label: '끝내기', choices: [{ v: 0, label: '1등 나오면 끝' }, { v: 1, label: '순위 끝까지 (3명 이상)' }], def: 0 },
    ],
    quick: [
      '내 진영(아래 삼각형)의 구슬을 맞은편 진영(위 점선 삼각형)으로 모두 먼저 옮기면 이겨요.',
      '내 차례: 구슬 하나를 탭 → 표시된 구멍을 탭. 옆 칸으로 한 칸 걷거나, 옆 구슬을 뛰어넘어요(점프는 연속 가능!).',
      '구슬은 잡히지 않아요. 남의 구슬도 징검다리로 쓰세요.',
    ],
    rules: [
      { h: '목표', p: [
        '별 모양 판(구멍 121개)의 꼭짓점 삼각형 6개가 진영이에요. 내 구슬은 내 진영에서 출발해 정반대 진영으로 가요.',
        '맞은편 진영을 내 구슬로 먼저 가득 채우면 이겨요.',
        '판은 내 진영이 아래로 오게 돌아가요. 점선 테두리가 내 도착 진영이에요.',
        '2명: 마주 보는 두 진영. 3명: 한 칸씩 건너뛴 진영(도착 진영은 비어 있어요). 4명: 마주 보는 두 쌍. 6명: 모든 진영. 5명은 진영이 고르게 안 나뉘어 할 수 없어요.'] },
      { h: '차례에 할 일', p: [
        '구슬 하나를 움직여요. 둘 중 하나:',
        '① 걷기: 바로 옆 빈 구멍으로 한 칸.',
        '② 점프: 바로 옆 구슬(누구 색이든) 하나를 뛰어넘어 그 너머 빈 구멍에 내려앉기. 내려앉은 곳에서 또 뛰어넘을 수 있으면 계속 이어 가도 되고, 원하는 곳에서 멈춰도 돼요.',
        '걷기와 점프는 한 차례에 섞을 수 없어요. 구슬은 잡히지 않아요.',
        '움직일 수 있는 구슬이 없으면 차례를 건너뛰어요.'] },
      { h: '승패', p: [
        '도착 진영을 먼저 채운 사람이 1등이에요.',
        `한 사람당 ${TURN_CAP}수가 넘도록 안 끝나면, 도착 순 → 도착 진영까지 남은 거리(진행도) 순으로 순위를 정해요.`] },
      { h: '특수 규칙 (옵션)', p: [
        '남의 진영 — 지나가기만 허용(기본): 내 진영·도착 진영이 아닌 진영은 점프 중에 지나갈 수만 있고 멈출 수는 없어요. / 들어가기 금지: 점프 중에도 내려앉을 수 없어요. / 제한 없음: 어디든 멈춰요.',
        '진영 막기 방지(기본 켬): 도착 진영 구멍이 다 찼고 그중 내 구슬이 하나라도 있으면, 남의 구슬이 눌러앉아 있어도 이긴 것으로 쳐요. 끄면 내 구슬로만 채워야 해요.',
        '구슬 수: 10개(기본) 또는 15개. 15개는 2명일 때만, 진영 삼각형 + 바로 앞줄 5칸이 진영이 돼요.',
        '끝내기: 1등 나오면 끝(기본, 나머지는 진행도 순) / 순위 끝까지(3명 이상, 도착한 사람은 빠지고 한 명 남을 때까지).'] },
      { h: '조작', p: [
        '내 구슬을 탭하면 갈 수 있는 구멍이 모두 표시돼요(점프 연쇄로 닿는 곳 포함). 표시된 구멍을 탭하면 이동. 표시된 구멍 근처만 눌러도 돼요.',
        '구멍을 누르고 있으면 지나갈 경로가 그려져요. 누른 채 다른 구멍으로 밀면 경로가 바뀌고, 표시 밖으로 빼면 취소.',
        '위쪽 칩에 각자 도착한 구슬 수가 보여요.',
        '↶ 무르기: 이 폰에서 사람 1명 대 AI일 때, 내 직전 수와 그 뒤 AI 수를 함께 되돌려요(최대 6번).'] },
      { h: '예시', p: [
        '내 구슬 앞에 구슬 하나 → 그 너머가 비어 있으면 점프! 내려앉은 곳 앞에 또 구슬이 있고 그 너머가 비었으면 한 번 더 점프 — 한 차례에 판을 가로질러요.',
        '그래서 구슬을 띄엄띄엄 줄 세워 두면 「점프 사다리」가 돼요. 뒤처진 구슬도 챙기세요. 마지막 한 개가 늦으면 져요.'] },
      { h: 'AI 난이도', p: ['자리마다 쉬움·보통·어려움. 쉬움은 앞으로 많이 가는 수를 대충 고르고, 보통은 다음 수까지 내다보며, 어려움은 상대 응수까지 읽고 구슬을 뭉쳐 점프 길을 만들며 뒤처진 구슬을 챙겨요.'] },
    ],
    tutorial: [
      { sel: '.dm-home', text: '아래 삼각형이 내 진영이에요. 여기 있는 내 구슬을 전부...' },
      { sel: '.dm-goal', text: '...맞은편 진영(점선 테두리)으로 먼저 다 옮기면 이겨요!' },
      { sel: '.dm-board', text: '내 구슬을 탭하면 갈 수 있는 구멍이 표시돼요. 표시된 구멍을 탭하면 이동! 옆 칸으로 한 칸 걷거나, 옆 구슬을 뛰어넘을 수 있어요.' },
      { sel: '.dm-board', text: '점프는 연속으로 이어져요. 내 구슬이든 남의 구슬이든 징검다리로 쓰세요. 구슬은 잡히지 않아요.' },
      { sel: '.dm-hint', text: '여기에 지금 할 일이 보여요. 실수했으면 「↶ 무르기」(AI전). 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { NC, NB, CAMP, Z10, Z15, dests, toArr, toStr, finished, pathFor, COST, rankList, progress, TURN_CAP },
  });
})();
