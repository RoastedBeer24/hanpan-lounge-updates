/* 벽 세우기 미로 — 9×9 판, 벽 20개(2명 10개씩·4명 5개씩), 한 칸 이동·점프·대각 점프, 길 완전 차단 금지, 자리별 AI. */
(function () {
  const L = window.Lounge, U = L.util;
  const N = 9, NC = 81, NGG = 64;
  const DD = [-9, 1, 9, -1]; // up right down left ; blocked bit = 1 << d
  const TURN_CAP = 100; // turns per player before the distance tie-break
  const UNDO_MAX = 5;
  // sides: 0 bottom (heads up), 1 left (heads right), 2 top (heads down), 3 right (heads left) — clockwise turn order
  const START = [8 * 9 + 4, 4 * 9 + 0, 0 * 9 + 4, 4 * 9 + 8];
  const SIDE_NAME = ['아래', '왼쪽', '위', '오른쪽'];
  const GOAL_NAME = ['맨 위 줄', '맨 오른쪽 줄', '맨 아래 줄', '맨 왼쪽 줄'];
  const isGoal = (side, c) => (side === 0 ? c < 9 : side === 1 ? c % 9 === 8 : side === 2 ? c >= 72 : c % 9 === 0);
  const COLS = 'abcdefghi';
  const cellName = (c) => COLS[c % 9] + (9 - ((c / 9) | 0));

  /* ---------------- board engine ---------------- */
  const BASE = new Uint8Array(NC);
  for (let c = 0; c < NC; c++) { const x = c % 9, y = (c / 9) | 0; BASE[c] = (y === 0 ? 1 : 0) | (x === 8 ? 2 : 0) | (y === 8 ? 4 : 0) | (x === 0 ? 8 : 0); }
  function wallBits(blk, g, o, on) {
    const gx = g % 8, gy = (g / 8) | 0, a = gy * 9 + gx;
    if (o === 1) { // horizontal: between rows gy / gy+1 over columns gx, gx+1
      if (on) { blk[a] |= 4; blk[a + 1] |= 4; blk[a + 9] |= 1; blk[a + 10] |= 1; } else { blk[a] &= ~4; blk[a + 1] &= ~4; blk[a + 9] &= ~1; blk[a + 10] &= ~1; }
    } else { // vertical: between columns gx / gx+1 over rows gy, gy+1
      if (on) { blk[a] |= 2; blk[a + 9] |= 2; blk[a + 1] |= 8; blk[a + 10] |= 8; } else { blk[a] &= ~2; blk[a + 9] &= ~2; blk[a + 1] &= ~8; blk[a + 10] &= ~8; }
    }
  }
  function Eng(s) {
    const blk = new Uint8Array(BASE), Wa = new Int8Array(NGG);
    for (let g = 0; g < NGG; g++) { const o = s.W.charCodeAt(g) - 48; if (o) { Wa[g] = o; wallBits(blk, g, o, true); } }
    return { blk, Wa, pos: s.p.slice(), sd: s.sd.slice(), wl: s.wl.slice(), n: s.n };
  }
  const QU = new Int16Array(NC), DS = new Int8Array(NC);
  /* shortest distance (ignoring pawns) from `from` to the goal edge of `side`; −1 if cut off */
  function distTo(blk, from, side) {
    if (isGoal(side, from)) return 0;
    DS.fill(-1); DS[from] = 0;
    let h = 0, t = 0; QU[t++] = from;
    while (h < t) {
      const c = QU[h++], b = blk[c];
      for (let d = 0; d < 4; d++) {
        if (b & (1 << d)) continue;
        const n = c + DD[d];
        if (DS[n] >= 0) continue;
        DS[n] = DS[c] + 1;
        if (isGoal(side, n)) return DS[n];
        QU[t++] = n;
      }
    }
    return -1;
  }
  /* distance-to-goal for every cell (multi-source BFS from the goal edge) */
  function field(blk, side, out) {
    out = out || new Int8Array(NC);
    out.fill(-1);
    let h = 0, t = 0;
    for (let c = 0; c < NC; c++) if (isGoal(side, c)) { out[c] = 0; QU[t++] = c; }
    while (h < t) {
      const c = QU[h++], b = blk[c];
      for (let d = 0; d < 4; d++) { if (b & (1 << d)) continue; const n = c + DD[d]; if (out[n] < 0) { out[n] = out[c] + 1; QU[t++] = n; } }
    }
    return out;
  }
  /* distance from a cell to every cell */
  function fromField(blk, from, out) {
    out = out || new Int8Array(NC);
    out.fill(-1); out[from] = 0;
    let h = 0, t = 0; QU[t++] = from;
    while (h < t) {
      const c = QU[h++], b = blk[c];
      for (let d = 0; d < 4; d++) { if (b & (1 << d)) continue; const n = c + DD[d]; if (out[n] < 0) { out[n] = out[c] + 1; QU[t++] = n; } }
    }
    return out;
  }
  /* one shortest path (list of cells) from the pawn to its goal, following the distance field */
  function shortestPath(blk, from, side) {
    const F = field(blk, side);
    if (F[from] < 0) return null;
    const p = [from];
    let c = from;
    while (F[c] > 0) {
      let nx = -1;
      for (let d = 0; d < 4; d++) { if (blk[c] & (1 << d)) continue; const n = c + DD[d]; if (F[n] === F[c] - 1) { nx = n; break; } }
      if (nx < 0) break;
      p.push(nx); c = nx;
    }
    return p;
  }
  function pawnMoves(blk, pos, i) {
    const c = pos[i], out = [];
    const occ = (x) => pos.indexOf(x) >= 0;
    for (let d = 0; d < 4; d++) {
      if (blk[c] & (1 << d)) continue;
      const nb = c + DD[d];
      if (!occ(nb)) { out.push(nb); continue; }
      // a pawn is next to me: jump straight over it, or diagonally when a wall / the edge / another pawn is behind it
      if (!(blk[nb] & (1 << d)) && !occ(nb + DD[d])) { out.push(nb + DD[d]); continue; }
      for (const p of [(d + 1) % 4, (d + 3) % 4]) {
        if (blk[nb] & (1 << p)) continue;
        const m = nb + DD[p];
        if (!occ(m) && out.indexOf(m) < 0) out.push(m);
      }
    }
    return out;
  }
  /* '' if the wall may be placed, otherwise the reason (Korean) */
  function wallReason(E, g, o) {
    if (!(g >= 0 && g < NGG) || (o !== 1 && o !== 2)) return '놓을 수 없는 자리예요';
    const Wa = E.Wa;
    if (Wa[g]) return Wa[g] === o ? '다른 벽과 겹쳐요' : '다른 벽과 교차해요';
    const gx = g % 8, gy = (g / 8) | 0;
    if (o === 1 && ((gx > 0 && Wa[g - 1] === 1) || (gx < 7 && Wa[g + 1] === 1))) return '다른 벽과 겹쳐요';
    if (o === 2 && ((gy > 0 && Wa[g - 8] === 2) || (gy < 7 && Wa[g + 8] === 2))) return '다른 벽과 겹쳐요';
    wallBits(E.blk, g, o, true);
    let ok = true;
    for (let i = 0; i < E.n && ok; i++) if (distTo(E.blk, E.pos[i], E.sd[i]) < 0) ok = false;
    wallBits(E.blk, g, o, false);
    return ok ? '' : '길을 완전히 막을 수 없어요';
  }
  function overlapFree(E, g, o) {
    const Wa = E.Wa;
    if (Wa[g]) return false;
    const gx = g % 8, gy = (g / 8) | 0;
    if (o === 1) return !((gx > 0 && Wa[g - 1] === 1) || (gx < 7 && Wa[g + 1] === 1));
    return !((gy > 0 && Wa[g - 8] === 2) || (gy < 7 && Wa[g + 8] === 2));
  }
  function anyWall(E) {
    for (let g = 0; g < NGG; g++) for (let o = 1; o <= 2; o++) if (!wallReason(E, g, o)) return true;
    return false;
  }
  function canMove(E, i) { return pawnMoves(E.blk, E.pos, i).length > 0 || (E.wl[i] > 0 && anyWall(E)); }
  function dists(E) { const d = []; for (let i = 0; i < E.n; i++) d.push(distTo(E.blk, E.pos[i], E.sd[i])); return d; }

  /* ---------------- state ---------------- */
  function init(players) {
    const n = U.clamp(players.length, 2, 4);
    const sd = n === 2 ? [0, 2] : n === 3 ? [0, 1, 2] : [0, 1, 2, 3];
    const per = n === 2 ? 10 : n === 4 ? 5 : 6;
    const hum = players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0);
    return {
      n, sd, p: sd.map((k) => START[k]), wl: sd.map(() => per), W: '0'.repeat(NGG), t: 0, tc: 0, seq: 0,
      nm: players.map((p, i) => String(p.name || (i + 1) + '번').slice(0, 10)),
      h: hum.length === 1 && players.length > 1 ? hum[0] : -1, u: [], last: null, ev: null, st: null,
    };
  }
  function actor(s) { return s.st ? null : s.t; }
  function advance(s) {
    s.tc++;
    if (s.tc >= TURN_CAP * s.n) { s.st = { w: -1, r: 'cap' }; return; }
    const E = Eng(s);
    const skipped = [];
    for (let k = 1; k <= s.n; k++) {
      const i = (s.t + k) % s.n;
      if (canMove(E, i)) { s.t = i; if (skipped.length) s.ev = { id: s.seq, k: 'p', s: skipped[0] }; return; }
      skipped.push(i);
    }
    s.st = { w: -1, r: 'stuck' };
  }
  function snap(s) { return { p: s.p.slice(), wl: s.wl.slice(), W: s.W, t: s.t, tc: s.tc }; }
  function apply(s, seat, a) {
    if (s.st) throw new Error('game over');
    if (seat !== s.t) throw new Error('not your turn');
    if (!a) throw new Error('bad action');
    if (a.t === 'u') {
      if (seat !== s.h || !s.u.length) throw new Error('nothing to undo');
      const u = s.u.pop();
      s.p = u.p; s.wl = u.wl; s.W = u.W; s.t = u.t; s.tc = u.tc; s.last = null;
      s.seq++; s.ev = { id: s.seq, k: 'u' };
      return s;
    }
    const E = Eng(s);
    if (a.t === 'm') {
      const c = a.c | 0;
      if (pawnMoves(E.blk, E.pos, seat).indexOf(c) < 0) throw new Error('illegal move');
      if (seat === s.h) { s.u.push(snap(s)); if (s.u.length > UNDO_MAX) s.u.shift(); }
      const f = s.p[seat];
      s.p[seat] = c;
      s.seq++;
      s.last = { id: s.seq, s: seat, k: 'm', f, c };
      s.ev = null;
      if (isGoal(s.sd[seat], c)) { s.st = { w: seat }; s.u = []; return s; }
    } else if (a.t === 'w') {
      const g = a.g | 0, o = a.o | 0;
      if (s.wl[seat] <= 0) throw new Error('no walls left');
      const r = wallReason(E, g, o);
      if (r) throw new Error(r);
      if (seat === s.h) { s.u.push(snap(s)); if (s.u.length > UNDO_MAX) s.u.shift(); }
      s.W = s.W.slice(0, g) + o + s.W.slice(g + 1);
      s.wl[seat]--;
      s.seq++;
      s.last = { id: s.seq, s: seat, k: 'w', g, o };
      s.ev = null;
    } else throw new Error('bad action');
    advance(s);
    if (s.st) s.u = [];
    return s;
  }
  function result(s) {
    if (!s.st) return null;
    const d = dists(Eng(s));
    const lines = s.nm.map((nm, i) => nm + ' · ' + (d[i] === 0 ? '도착' : '남은 길 ' + d[i] + '칸') + ' · 벽 ' + s.wl[i] + '개 남음');
    if (s.st.w >= 0) return { winners: [s.st.w], text: s.nm[s.st.w] + '이(가) 맞은편 끝줄에 먼저 닿았어요.\n' + lines.join('\n') };
    const mn = Math.min(...d.filter((x) => x >= 0));
    const win = d.map((x, i) => (x === mn ? i : -1)).filter((i) => i >= 0);
    return { winners: win, title: s.st.r === 'cap' ? '수 제한 — 남은 길로 판정' : '더 둘 수 없음 — 남은 길로 판정', text: lines.join('\n') };
  }

  /* ---------------- AI ---------------- */
  const FA = new Int8Array(NC), FB = new Int8Array(NC);
  /* walls that cut some shortest path of player i (keys g*3+o) */
  function cutWalls(E, i, set) {
    const F = field(E.blk, E.sd[i], FA), S = fromField(E.blk, E.pos[i], FB);
    const D = F[E.pos[i]];
    if (D <= 0) return set;
    for (let a = 0; a < NC; a++) {
      if (S[a] < 0 || S[a] >= D) continue;
      for (let d = 0; d < 4; d++) {
        if (E.blk[a] & (1 << d)) continue;
        const b = a + DD[d];
        if (S[a] + 1 + F[b] !== D) continue;
        const ax = a % 9, ay = (a / 9) | 0, bx = b % 9, by = (b / 9) | 0;
        if (ay === by) { // horizontal step → vertical wall
          const gx = Math.min(ax, bx);
          for (const gy of [ay - 1, ay]) if (gy >= 0 && gy < 8) set.add((gy * 8 + gx) * 3 + 2);
        } else {
          const gy = Math.min(ay, by);
          for (const gx of [ax - 1, ax]) if (gx >= 0 && gx < 8) set.add((gy * 8 + gx) * 3 + 1);
        }
      }
    }
    return set;
  }
  /* place wall temporarily, return new distances or null if illegal */
  function tryWall(E, g, o) {
    if (!overlapFree(E, g, o)) return null;
    wallBits(E.blk, g, o, true);
    const d = [];
    for (let i = 0; i < E.n; i++) { const x = distTo(E.blk, E.pos[i], E.sd[i]); if (x < 0) { wallBits(E.blk, g, o, false); return null; } d.push(x); }
    wallBits(E.blk, g, o, false);
    return d;
  }
  function stepMove(E, seat, noise) {
    const F = field(E.blk, E.sd[seat]);
    const ms = pawnMoves(E.blk, E.pos, seat);
    let best = ms[0], bv = Infinity;
    for (const m of ms) {
      const v = (isGoal(E.sd[seat], m) ? -100 : F[m]) + Math.random() * (noise || 0.01);
      if (v < bv) { bv = v; best = m; }
    }
    return best;
  }
  function leaderOf(d, seat, n) {
    let ld = -1;
    for (let k = 1; k < n; k++) { const i = (seat + k) % n; if (ld < 0 || d[i] < d[ld]) ld = i; }
    return ld;
  }
  /* 보통: greedy wall that lengthens the leading opponent's path most */
  function bestWall(E, seat, d0, targetOnly) {
    const ld = leaderOf(d0, seat, E.n);
    const set = new Set();
    if (targetOnly) cutWalls(E, ld, set);
    else for (let i = 0; i < E.n; i++) if (i !== seat) cutWalls(E, i, set);
    let best = null, bg = -Infinity;
    for (const key of set) {
      const g = (key / 3) | 0, o = key % 3;
      const d = tryWall(E, g, o);
      if (!d) continue;
      let gain = -(d[seat] - d0[seat]) * 1.05;
      for (let i = 0; i < E.n; i++) if (i !== seat) gain += (d[i] - d0[i]) * (i === ld ? 1 : 0.45);
      gain += Math.random() * 0.05;
      if (gain > bg) { bg = gain; best = { g, o, gain, d }; }
    }
    return best;
  }
  function aiNormal(E, seat) {
    const d0 = dists(E);
    const ld = leaderOf(d0, seat, E.n);
    if (E.wl[seat] > 0) {
      const w = bestWall(E, seat, d0, false);
      const behind = d0[ld] < d0[seat] || (d0[ld] === d0[seat] && E.n > 2 && ld < seat);
      if (w && ((behind && w.gain >= 1) || w.gain >= 3 || (d0[ld] <= 2 && w.gain >= 1))) return { t: 'w', g: w.g, o: w.o };
    }
    return { t: 'm', c: stepMove(E, seat) };
  }
  function aiEasy(E, seat) {
    if (E.wl[seat] > 0 && Math.random() < 0.22) {
      for (let k = 0; k < 60; k++) {
        const g = U.rand(NGG), o = 1 + U.rand(2);
        if (!wallReason(E, g, o)) return { t: 'w', g, o };
      }
    }
    return { t: 'm', c: stepMove(E, seat, 0.3) };
  }

  /* 어려움 (2 players): alpha-beta on path difference with wall-budget awareness */
  const WINV = 10000;
  function evalPos(E, me, op) {
    const dm = distTo(E.blk, E.pos[me], E.sd[me]), dO = distTo(E.blk, E.pos[op], E.sd[op]);
    const wm = E.wl[me], wo = E.wl[op];
    // pure race once the other side has no walls left (side to move wins ties)
    if (wo === 0 && dm <= dO) return 1000 + (dO - dm) * 10 + wm;
    if (wm === 0 && dO < dm) return -1000 - (dm - dO) * 10 - wo;
    // walls are worth more while the opponent still has a long way to go
    const wv = 0.45 + Math.min(dO, 8) * 0.06, wvo = 0.45 + Math.min(dm, 8) * 0.06;
    return (dO - dm) + 0.5 + wv * Math.min(wm, 6) - wvo * Math.min(wo, 6);
  }
  function genMoves(E, me, op, limit) {
    const res = [];
    const F = field(E.blk, E.sd[me]);
    for (const c of pawnMoves(E.blk, E.pos, me)) res.push({ k: 'm', c, sc: isGoal(E.sd[me], c) ? 1e6 : 10 - F[c] * 1.0 });
    if (E.wl[me] > 0) {
      const dm = distTo(E.blk, E.pos[me], E.sd[me]), dO = distTo(E.blk, E.pos[op], E.sd[op]);
      const set = cutWalls(E, op, new Set());
      const ws = [];
      for (const key of set) {
        const g = (key / 3) | 0, o = key % 3;
        const d = tryWall(E, g, o);
        if (!d) continue;
        const gain = (d[op] - dO) - (d[me] - dm);
        if (gain < 1) continue;
        ws.push({ k: 'w', g, o, sc: 10 + gain * 1.5 - 0.9 });
      }
      ws.sort((a, b) => b.sc - a.sc);
      for (const w of ws.slice(0, limit)) res.push(w);
    }
    res.sort((a, b) => b.sc - a.sc);
    return res;
  }
  function doM(E, me, m) { if (m.k === 'm') { m.f = E.pos[me]; E.pos[me] = m.c; } else { E.Wa[m.g] = m.o; wallBits(E.blk, m.g, m.o, true); E.wl[me]--; } }
  function undoM(E, me, m) { if (m.k === 'm') E.pos[me] = m.f; else { E.Wa[m.g] = 0; wallBits(E.blk, m.g, m.o, false); E.wl[me]++; } }
  function negamax(E, me, op, depth, alpha, beta, ply, T) {
    if (T.stop || ((++T.nodes & 63) === 0 && Date.now() > T.end)) { T.stop = true; return 0; }
    if (depth <= 0) return evalPos(E, me, op);
    const ms = genMoves(E, me, op, ply === 0 ? 40 : depth >= 2 ? 10 : 7);
    if (ply === 0 && T.pv) { const i = ms.findIndex((m) => m.k === T.pv.k && m.c === T.pv.c && m.g === T.pv.g && m.o === T.pv.o); if (i > 0) ms.unshift(ms.splice(i, 1)[0]); }
    if (!ms.length) return -evalPos(E, op, me);
    let best = -Infinity;
    for (const m of ms) {
      let v;
      if (m.k === 'm' && isGoal(E.sd[me], m.c)) v = WINV - ply;
      else { doM(E, me, m); v = -negamax(E, op, me, depth - 1, -beta, -alpha, ply + 1, T); undoM(E, me, m); }
      if (T.stop) return best === -Infinity ? 0 : best;
      if (v > best) { best = v; if (ply === 0) T.best = m; }
      if (v > alpha) alpha = v;
      if (alpha >= beta) break;
    }
    return best;
  }
  function aiHard2(E, seat, ms) {
    const op = 1 - seat;
    // immediate win
    for (const c of pawnMoves(E.blk, E.pos, seat)) if (isGoal(E.sd[seat], c)) return { t: 'm', c };
    const T = { end: Date.now() + ms, nodes: 0, stop: false, best: null, pv: null };
    let best = null;
    for (let d = 1; d <= 4; d++) {
      T.best = null; T.stop = false;
      negamax(E, seat, op, d, -Infinity, Infinity, 0, T);
      if (T.stop) break;
      if (T.best) { best = T.best; T.pv = best; }
    }
    if (!best) return aiNormal(E, seat);
    return best.k === 'm' ? { t: 'm', c: best.c } : { t: 'w', g: best.g, o: best.o };
  }
  /* 어려움 (3–4 players): greedy candidates, each checked against the leader's best reply */
  function eval4(E, seat) {
    const d = dists(E);
    let mn = Infinity;
    for (let i = 0; i < E.n; i++) if (i !== seat) mn = Math.min(mn, d[i] + (i < seat ? 0 : 0.5));
    return (mn - d[seat]) + 0.5 * Math.min(E.wl[seat], 4) + Math.min(mn, 8) * 0.03 * E.wl[seat];
  }
  function aiHard4(E, seat, ms) {
    for (const c of pawnMoves(E.blk, E.pos, seat)) if (isGoal(E.sd[seat], c)) return { t: 'm', c };
    const t0 = Date.now();
    const d0 = dists(E);
    const cands = [];
    for (const c of pawnMoves(E.blk, E.pos, seat)) cands.push({ k: 'm', c });
    if (E.wl[seat] > 0) {
      const set = new Set();
      for (let i = 0; i < E.n; i++) if (i !== seat) cutWalls(E, i, set);
      const ws = [];
      for (const key of set) {
        const g = (key / 3) | 0, o = key % 3, d = tryWall(E, g, o);
        if (!d) continue;
        let gain = -(d[seat] - d0[seat]);
        const ld = leaderOf(d0, seat, E.n);
        for (let i = 0; i < E.n; i++) if (i !== seat) gain += (d[i] - d0[i]) * (i === ld ? 1 : 0.5);
        if (gain >= 1) ws.push({ k: 'w', g, o, gain });
      }
      ws.sort((a, b) => b.gain - a.gain);
      cands.push(...ws.slice(0, 14));
    }
    let best = null, bv = -Infinity;
    for (const m of cands) {
      doM(E, seat, m);
      const dn = dists(E);
      const ld = leaderOf(dn, seat, E.n);
      // leader replies with its own best wall against me, if it has one
      let v = eval4(E, seat);
      if (E.wl[ld] > 0 && Date.now() - t0 < ms) {
        const set = cutWalls(E, seat, new Set());
        let worst = 0;
        for (const key of set) {
          const g = (key / 3) | 0, o = key % 3, d = tryWall(E, g, o);
          if (!d) continue;
          const hurt = (d[seat] - dn[seat]) - (d[ld] - dn[ld]);
          if (hurt > worst) worst = hurt;
        }
        v -= worst * 0.7;
      }
      undoM(E, seat, m);
      v += Math.random() * 0.03;
      if (v > bv) { bv = v; best = m; }
    }
    if (!best) return aiNormal(E, seat);
    return best.k === 'm' ? { t: 'm', c: best.c } : { t: 'w', g: best.g, o: best.o };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const E = Eng(s);
    let a;
    if (lv === 1) a = aiEasy(E, seat);
    else if (lv === 3) a = s.n === 2 ? aiHard2(E, seat, 330) : aiHard4(E, seat, 300);
    else a = aiNormal(E, seat);
    if (a.t === 'm' && a.c == null) {
      // no pawn move (boxed in by pawns): any legal wall
      for (let g = 0; g < NGG; g++) for (let o = 1; o <= 2; o++) if (!wallReason(E, g, o)) return { t: 'w', g, o };
    }
    return a;
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 700 : lv === 3 ? 150 : 400; }

  /* ---------------- view ---------------- */
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace';
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  function rr(x, a, b, w, h, r) { x.beginPath(); if (x.roundRect) x.roundRect(a, b, w, h, r); else x.rect(a, b, w, h); }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, E = null, G = null, busy = false, anim = null, stopLoop = null, animTimer = 0;
    let mode = 'm', sel = false, tgt = -1, gw = null, drag = null, waitSeq = -1, waitUntil = 0, legal = [];
    let showPath = U.store.get('wallmaze.path', true);
    const BS = { minHeight: '44px', flex: '1 1 0', minWidth: 0, padding: '6px 4px', fontSize: '13px', whiteSpace: 'nowrap' };

    const top = L.h('div', { class: 'hud top wm-top', style: { gap: '5px', padding: '6px 8px', flexWrap: 'nowrap' } });
    const chips = L.h('div', { style: { display: 'flex', gap: '5px', flex: '1 1 auto', minWidth: 0 } });
    const pathBtn = L.h('button', { class: 'btn sm ghost wm-path', style: { minHeight: '40px', minWidth: '44px', padding: '4px 8px', flex: 'none', fontSize: '12px' }, onclick() { showPath = !showPath; U.store.set('wallmaze.path', showPath); api.sfx('click'); api.buzz(8); pathLabel(); renderChips(true); draw(); } });
    top.append(chips, pathBtn);
    const modeMove = L.h('button', { class: '', text: '말 이동', onclick: () => setMode('m') });
    const modeWall = L.h('button', { class: '', text: '벽', onclick: () => setMode('w') });
    const seg = L.h('div', { class: 'seg wm-mode', style: { flex: '1.5 1 0', minWidth: 0, display: 'flex', height: '44px' } }, modeMove, modeWall);
    [modeMove, modeWall].forEach((b) => Object.assign(b.style, { flex: '1 1 0', minWidth: 0, padding: '4px 2px', fontSize: '13px', whiteSpace: 'nowrap' }));
    const rotBtn = L.h('button', { class: 'btn sm ghost wm-rot', style: Object.assign({}, BS, { flex: '0 0 48px' }), text: '↻', 'aria-label': '벽 돌리기', onclick() { rotate(); } });
    const undoBtn = L.h('button', { class: 'btn sm ghost', style: Object.assign({}, BS, { flex: '0 0 52px' }), text: '↶', 'aria-label': '한 수 무르기', onclick: onUndo });
    const okBtn = L.h('button', { class: 'btn primary wm-ok', style: Object.assign({}, BS, { flex: '1.4 1 0', fontSize: '14px' }), text: '확정', onclick: () => commit() });
    const bot = L.h('div', { class: 'hud bottom', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 10px' } }, seg, rotBtn, undoBtn, okBtn);
    const hint = L.h('div', { class: 'wm-hint', style: { position: 'absolute', left: '12px', right: '12px', textAlign: 'center', fontSize: '12.5px', fontWeight: 700, color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', pointerEvents: 'none' } });
    root.append(top, bot, hint);
    // invisible boxes over canvas areas (board, my pawn, my goal row), for the first-play tutorial
    const spot = (cls) => { const d = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } }); root.append(d); return d; };
    const place = (d, x, y, w, h) => Object.assign(d.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' });
    const spBoard = spot('wm-board'), spPawn = spot('wm-pawn'), spGoal = spot('wm-goal');
    function placeSpots() {
      const p = G.p;
      place(spBoard, G.bx, G.by, p * 9, p * 9);
      let me = st.t; for (let i = 0; i < st.n; i++) if (api.canAct(i)) { me = i; break; }
      const c = st.p[me], sd = st.sd[me];
      if (c >= 0) place(spPawn, G.bx + (c % 9) * p, G.by + ((c / 9) | 0) * p, p, p);
      if (sd === 0) place(spGoal, G.bx, G.by, p * 9, p); else if (sd === 2) place(spGoal, G.bx, G.by + p * 8, p * 9, p);
      else if (sd === 1) place(spGoal, G.bx + p * 8, G.by, p, p * 9); else place(spGoal, G.bx, G.by, p, p * 9);
    }
    function pathLabel() { pathBtn.textContent = (showPath ? '● ' : '○ ') + '길'; pathBtn.setAttribute('aria-pressed', String(showPath)); pathBtn.setAttribute('aria-label', '최단 길 표시'); }
    pathLabel();
    const vis = (el, on) => { el.style.display = on ? '' : 'none'; };
    const color = (i) => (api.players[i] ? api.players[i].color : L.COLORS[i]);
    const name = (i) => (api.players[i] ? api.players[i].name : st.nm[i]);

    function myTurn() { return !!st && !st.st && api.canAct(st.t); }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function canInput() { return myTurn() && !locked() && !anim; }
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }
    function canUndo() { return !api.online && !!st && !st.st && st.h >= 0 && st.t === st.h && api.canAct(st.h) && st.u.length > 0 && !anim && !locked(); }
    function onUndo() { if (!canUndo()) return; clearInput(); api.sfx('click'); api.buzz(15); send({ t: 'u' }); }
    function clearInput() { sel = false; tgt = -1; drag = null; }

    function setMode(m) {
      if (!st || !myTurn()) return;
      if (m === 'w' && st.wl[st.t] <= 0) { api.toast('남은 벽이 없어요'); api.buzz(20); return; }
      mode = m; tgt = -1; sel = false;
      if (m === 'w' && !gw) gw = defaultGhost();
      api.sfx('click'); api.buzz(8);
      updateHud(); draw();
    }
    function defaultGhost() {
      const d = dists(E), ld = leaderOf(d, st.t, st.n);
      const c = st.p[ld], x = c % 9, y = (c / 9) | 0, side = st.sd[ld];
      const cl = (v) => U.clamp(v, 0, 7);
      if (side === 0) return { g: cl(y - 1) * 8 + cl(x), o: 1 };
      if (side === 2) return { g: cl(y) * 8 + cl(x), o: 1 };
      if (side === 1) return { g: cl(y) * 8 + cl(x), o: 2 };
      return { g: cl(y) * 8 + cl(x - 1), o: 2 };
    }
    function rotate() {
      if (!canInput() || mode !== 'w' || !gw) return;
      gw = { g: gw.g, o: 3 - gw.o };
      api.sfx('tick'); api.buzz(8); updateHud(); draw();
    }
    function ghostReason() { if (!gw || !E) return ''; if (st.wl[st.t] <= 0) return '남은 벽이 없어요'; return wallReason(E, gw.g, gw.o); }
    function commit() {
      if (!canInput()) return;
      if (mode === 'm') {
        if (tgt < 0 || legal.indexOf(tgt) < 0) return;
        const c = tgt; clearInput(); api.buzz(12);
        send({ t: 'm', c });
      } else {
        if (!gw) return;
        const r = ghostReason();
        if (r) { api.toast(r); api.buzz(30); return; }
        const a = { t: 'w', g: gw.g, o: gw.o };
        gw = null; clearInput(); api.buzz(15);
        send(a);
      }
      updateHud(); draw();
    }

    /* layout */
    function layout() {
      const W = cv.w, H = cv.h, topH = 54, botH = 62, hintH = 22;
      const size = Math.max(180, Math.min(W - 26, H - topH - botH - hintH - 12, 620));
      const p = size / 9.3;
      const bx = Math.round((W - p * 9) / 2), by = Math.round(topH + Math.max(4, (H - topH - botH - hintH - size) / 2) + p * 0.15);
      G = { size, p, bx, by };
      hint.style.top = Math.round(by + p * 9 + p * 0.15 + 6) + 'px';
    }
    cv.onresize = () => { layout(); draw(); };
    layout();
    const cellXY = (c) => [G.bx + (c % 9) * G.p + G.p / 2, G.by + ((c / 9) | 0) * G.p + G.p / 2];
    function cellAt(x, y) {
      const cx = Math.floor((x - G.bx) / G.p), cy = Math.floor((y - G.by) / G.p);
      if (cx < 0 || cy < 0 || cx > 8 || cy > 8) return -1;
      return cy * 9 + cx;
    }
    function grooveAt(x, y) {
      const gx = U.clamp(Math.round((x - G.bx) / G.p) - 1, 0, 7), gy = U.clamp(Math.round((y - G.by) / G.p) - 1, 0, 7);
      return gy * 8 + gx;
    }
    const gCenter = (g) => [G.bx + ((g % 8) + 1) * G.p, G.by + (((g / 8) | 0) + 1) * G.p];
    function wallRect(g, o) {
      const [cx, cy] = gCenter(g), p = G.p, len = p * 1.86, th = Math.max(4, p * 0.2);
      return o === 1 ? [cx - len / 2, cy - th / 2, len, th] : [cx - th / 2, cy - len / 2, th, len];
    }

    function drawBoard() {
      const { bx, by, p } = G, S = p * 9;
      // walnut frame
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 6;
      const fr = ctx.createLinearGradient(bx, by, bx + S, by + S);
      fr.addColorStop(0, '#6e4527'); fr.addColorStop(1, '#3f2614');
      ctx.fillStyle = fr; rr(ctx, bx - p * 0.32, by - p * 0.32, S + p * 0.64, S + p * 0.64, 12); ctx.fill();
      ctx.restore();
      // goal edges in owner colours
      for (let i = 0; i < st.n; i++) {
        const side = st.sd[i], c = color(i), t = p * 0.14;
        ctx.fillStyle = c; ctx.globalAlpha = 0.85;
        if (side === 0) rr(ctx, bx, by - p * 0.27, S, t, 3);
        else if (side === 2) rr(ctx, bx, by + S + p * 0.13, S, t, 3);
        else if (side === 1) rr(ctx, bx + S + p * 0.13, by, t, S, 3);
        else rr(ctx, bx - p * 0.27, by, t, S, 3);
        ctx.fill(); ctx.globalAlpha = 1;
      }
      // groove bed
      ctx.fillStyle = '#2a1a0e'; rr(ctx, bx, by, S, S, 6); ctx.fill();
      // tiles
      const ins = p * 0.09;
      for (let c = 0; c < NC; c++) {
        const x = bx + (c % 9) * p + ins, y = by + ((c / 9) | 0) * p + ins, w = p - ins * 2;
        const g = ctx.createLinearGradient(x, y, x + w, y + w);
        const goalOf = st.sd.findIndex((sd) => isGoal(sd, c));
        g.addColorStop(0, '#d9b27a'); g.addColorStop(1, '#b98a52');
        ctx.fillStyle = g; rr(ctx, x, y, w, w, Math.max(2, p * 0.1)); ctx.fill();
        ctx.strokeStyle = 'rgba(255,240,210,.25)'; ctx.lineWidth = 1; ctx.stroke();
        if (goalOf >= 0) { ctx.fillStyle = color(goalOf); ctx.globalAlpha = 0.16; ctx.fill(); ctx.globalAlpha = 1; }
      }
    }
    function drawWall(g, o, fill, alpha, outline) {
      const [x, y, w, h] = wallRect(g, o);
      ctx.save(); ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, x + 1.5, y + 2.5, w, h, 3); ctx.fill();
      const gr = o === 1 ? ctx.createLinearGradient(x, y, x, y + h) : ctx.createLinearGradient(x, y, x + w, y);
      gr.addColorStop(0, shade(fill, 0.35)); gr.addColorStop(1, shade(fill, -0.25));
      ctx.fillStyle = gr; rr(ctx, x, y, w, h, 3); ctx.fill();
      if (outline) { ctx.strokeStyle = outline; ctx.lineWidth = 2; ctx.stroke(); }
      ctx.restore();
    }
    function pawn(x, y, col, r, alpha, glow) {
      ctx.save(); if (alpha != null) ctx.globalAlpha = alpha;
      if (glow) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, r * 1.32, 0, 7); ctx.stroke(); }
      ctx.fillStyle = 'rgba(30,15,0,.4)'; ctx.beginPath(); ctx.ellipse(x + r * 0.12, y + r * 0.3, r, r * 0.8, 0, 0, 7); ctx.fill();
      const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.45, r * 0.1, x, y, r);
      g.addColorStop(0, shade(col, 0.6)); g.addColorStop(0.5, col); g.addColorStop(1, shade(col, -0.45));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      ctx.strokeStyle = shade(col, -0.55); ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = shade(col, 0.75); ctx.beginPath(); ctx.arc(x - r * 0.08, y - r * 0.12, r * 0.42, 0, 7); ctx.fill();
      ctx.restore();
    }

    function draw() {
      cv.clear();
      if (!st || !G) return;
      placeSpots();
      drawBoard();
      const p = G.p;
      // last move markers
      if (st.last && !anim) {
        if (st.last.k === 'm') { const [x, y] = cellXY(st.last.f); ctx.strokeStyle = color(st.last.s); ctx.globalAlpha = 0.6; ctx.lineWidth = 2; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.arc(x, y, p * 0.3, 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; }
      }
      // shortest paths
      if (showPath) {
        for (let i = 0; i < st.n; i++) {
          const path = shortestPath(E.blk, anim && anim.k === 'm' && anim.s === i ? anim.f : st.p[i], st.sd[i]);
          if (!path || path.length < 2) continue;
          const off = (i - (st.n - 1) / 2) * p * 0.07;
          ctx.save(); ctx.strokeStyle = color(i); ctx.globalAlpha = 0.75; ctx.lineWidth = Math.max(2, p * 0.07); ctx.setLineDash([p * 0.16, p * 0.12]); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          ctx.beginPath(); path.forEach((c, k) => { const [x, y] = cellXY(c); k ? ctx.lineTo(x + off, y + off) : ctx.moveTo(x + off, y + off); }); ctx.stroke();
          ctx.setLineDash([]);
          const [ex, ey] = cellXY(path[path.length - 1]); ctx.fillStyle = color(i); ctx.beginPath(); ctx.arc(ex + off, ey + off, p * 0.09, 0, 7); ctx.fill();
          ctx.restore();
        }
      }
      // placed walls
      for (let g = 0; g < NGG; g++) {
        const o = E.Wa[g];
        if (!o) continue;
        let al = 1;
        if (anim && anim.k === 'w' && anim.g === g) al = anim.e;
        const isLast = st.last && st.last.k === 'w' && st.last.g === g && !anim;
        drawWall(g, o, '#efe0bf', al, isLast ? color(st.last.s) : null);
      }
      // legal moves
      const mine = canInput();
      if (mine && mode === 'm') { // legal moves are always shown on my turn — tap a dot to preview, tap again to move
        for (const c of legal) {
          const [x, y] = cellXY(c);
          ctx.fillStyle = color(st.t); ctx.globalAlpha = c === tgt ? 0.25 : sel ? 0.7 : 0.5;
          ctx.beginPath(); ctx.arc(x, y, p * 0.17, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          ctx.strokeStyle = 'rgba(242,233,216,.9)'; ctx.lineWidth = 1.5; ctx.stroke();
        }
      }
      // pawns
      for (let i = 0; i < st.n; i++) {
        let [x, y] = cellXY(st.p[i]);
        if (anim && anim.k === 'm' && anim.s === i) {
          const [x0, y0] = cellXY(anim.f), e = anim.e;
          x = x0 + (x - x0) * e; y = y0 + (y - y0) * e - Math.sin(Math.PI * e) * p * (anim.jump ? 0.45 : 0.15);
        }
        pawn(x, y, color(i), p * 0.33, 1, !st.st && st.t === i && (mine ? sel || mode === 'm' : true));
      }
      if (mine && mode === 'm' && tgt >= 0) { const [x, y] = cellXY(tgt); pawn(x, y, color(st.t), p * 0.33, 0.55); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, p * 0.42, 0, 7); ctx.stroke(); }
      // ghost wall
      if (mine && mode === 'w' && gw) {
        const bad = ghostReason();
        drawWall(gw.g, gw.o, bad ? '#ee6a55' : '#5fd3a0', 0.85, bad ? '#ffb4a6' : '#d9ffe9');
        const [cx, cy] = gCenter(gw.g);
        ctx.fillStyle = 'rgba(16,12,22,.85)'; ctx.beginPath(); ctx.arc(cx, cy, Math.max(7, p * 0.2), 0, 7); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.font = '700 ' + Math.round(Math.max(10, p * 0.3)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('↻', cx, cy + 0.5);
      }
    }

    let chipSig = '';
    function renderChips(force) {
      if (!st) return;
      const d = dists(E);
      const sig = d.join(',') + '|' + st.wl.join(',') + '|' + st.t + '|' + !!st.st + '|' + showPath;
      if (sig === chipSig && !force) return;
      chipSig = sig;
      chips.innerHTML = '';
      const many = st.n >= 3;
      for (let i = 0; i < st.n; i++) {
        const cur = !st.st && st.t === i;
        chips.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '5px', padding: many ? '4px 6px' : '5px 9px', flex: '1 1 0', minWidth: 0, borderColor: cur ? 'var(--brass)' : '', boxShadow: cur ? '0 0 0 1px var(--brass)' : 'none', minHeight: '40px' } },
          L.h('span', { class: 'dot', style: { '--c': color(i), flex: 'none' } }),
          many ? null : L.h('span', { style: { fontSize: '12px', fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0, flex: '1 1 auto' }, text: name(i) }),
          L.h('span', { class: 'mono', style: { fontSize: '11.5px', fontWeight: 600, flex: 'none', marginLeft: many ? '0' : 'auto', lineHeight: 1.15, textAlign: 'right' } },
            L.h('span', { style: { color: 'var(--ink)' }, text: '▮' + st.wl[i] }),
            showPath ? L.h('span', { style: { color: 'var(--muted)', marginLeft: '5px' }, text: '→' + d[i] }) : null)));
      }
    }
    function updateHud() {
      if (!st) return;
      renderChips();
      const mine = myTurn();
      vis(seg, mine); vis(okBtn, mine);
      vis(rotBtn, mine && mode === 'w');
      const solo = !api.online && st.h >= 0 && api.canAct(st.h) && !st.st;
      vis(undoBtn, solo); undoBtn.disabled = !canUndo();
      modeMove.className = mode === 'm' ? 'on' : ''; modeWall.className = mode === 'w' ? 'on' : '';
      modeWall.textContent = '벽 ' + (st.wl[st.t] != null ? st.wl[st.t] : '') + '개';
      modeWall.disabled = !mine || st.wl[st.t] <= 0;
      modeWall.style.opacity = st.wl[st.t] <= 0 ? '.4' : '';
      let h = '', bad = false;
      if (st.st) h = st.st.w >= 0 ? name(st.st.w) + ' 도착!' : '판정 종료';
      else if (mine) {
        if (mode === 'm') {
          okBtn.textContent = tgt >= 0 ? '이동 · ' + cellName(tgt) : '이동';
          okBtn.disabled = tgt < 0 || !canInput();
          h = tgt >= 0 ? '같은 칸 한 번 더 탭 또는 「이동」으로 확정' : '점 찍힌 칸을 탭해 이동 · 목표: ' + GOAL_NAME[st.sd[st.t]];
        } else {
          const r = ghostReason();
          okBtn.textContent = '벽 세우기';
          okBtn.disabled = !gw || !!r || !canInput();
          if (r) { h = '✕ ' + r; bad = true; } else h = '판 위를 끌어 위치 조정 · 벽 가운데 탭하면 회전';
        }
      } else h = name(st.t) + (api.players[st.t] && api.players[st.t].ai ? ' 생각 중…' : ' 차례');
      hint.textContent = h;
      hint.style.color = bad ? 'var(--coral)' : 'var(--muted)';
    }

    /* input */
    function onDown(e) {
      if (!st || !G || !canInput()) return;
      const { x, y } = cv.local(e);
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) {}
      if (mode === 'w') {
        let onGhost = false;
        if (gw) { const [cx, cy] = gCenter(gw.g); onGhost = Math.hypot(x - cx, y - cy) < G.p * 0.6; }
        drag = { id: e.pointerId, x0: x, y0: y, moved: false, onGhost, touch: e.pointerType === 'touch' };
        return;
      }
      const c = cellAt(x, y);
      drag = { id: e.pointerId, x0: x, y0: y, moved: false, c };
    }
    function onMove(e) {
      if (!drag || e.pointerId !== drag.id || !canInput()) return;
      const { x, y } = cv.local(e);
      if (!drag.moved && Math.hypot(x - drag.x0, y - drag.y0) > 8) drag.moved = true;
      if (!drag.moved || mode !== 'w') return;
      const lift = drag.touch ? G.p * 0.9 : 0;
      const g = grooveAt(x, y - lift);
      if (!gw || g !== gw.g) { gw = { g, o: gw ? gw.o : 1 }; api.sfx('tick'); updateHud(); draw(); }
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag; drag = null;
      if (!canInput()) return;
      const { x, y } = cv.local(e);
      if (mode === 'w') {
        if (d.moved) { api.buzz(6); return; }
        if (d.onGhost) { rotate(); return; }
        if (x < G.bx - G.p * 0.4 || y < G.by - G.p * 0.4 || x > G.bx + G.p * 9.4 || y > G.by + G.p * 9.4) return;
        gw = { g: grooveAt(x, y), o: gw ? gw.o : 1 }; api.sfx('tick'); api.buzz(6); updateHud(); draw();
        return;
      }
      if (d.moved && cellAt(x, y) !== d.c) return;
      const c = cellAt(x, y);
      if (c < 0) { if (sel || tgt >= 0) { clearInput(); updateHud(); draw(); } return; }
      if (c === st.p[st.t]) { sel = !sel || tgt >= 0; tgt = -1; api.sfx('click'); api.buzz(8); updateHud(); draw(); return; }
      if (legal.indexOf(c) >= 0) {
        if (tgt === c) { commit(); return; }
        tgt = c; sel = true; api.sfx('tick'); api.buzz(6); updateHud(); draw(); return;
      }
      if (sel || tgt >= 0) { tgt = -1; api.sfx('click'); updateHud(); draw(); }
    }
    function onCancel() { drag = null; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    L.games.wallmaze._pt = (kind, v) => { // test hook → client coords of a cell centre or groove intersection
      if (!G) return null;
      const r = cv.cv.getBoundingClientRect(), q = kind === 'g' ? gCenter(v) : cellXY(v);
      return [r.left + q[0], r.top + q[1]];
    };

    function finishAnim() {
      clearTimeout(animTimer);
      if (stopLoop) { stopLoop(); stopLoop = null; }
      anim = null;
      if (busy) { busy = false; api.setBusy(false); }
    }
    function startAnim(last) {
      const dur = (last.k === 'm' ? 200 : 240) / (L.debug.speed || 1);
      const jump = last.k === 'm' && Math.abs((last.f % 9) - (last.c % 9)) + Math.abs(((last.f / 9) | 0) - ((last.c / 9) | 0)) > 1;
      anim = Object.assign({}, last, { t0: performance.now(), dur, e: 0, jump });
      busy = true; api.setBusy(true);
      animTimer = setTimeout(() => { if (anim) { finishAnim(); draw(); } }, dur + 600);
      stopLoop = U.loop((dt, now) => {
        if (!anim) return;
        const k = U.clamp((now - anim.t0) / anim.dur, 0, 1);
        anim.e = 1 - Math.pow(1 - k, 3);
        if (k >= 1) { finishAnim(); draw(); updateHud(); return; }
        draw();
      });
    }

    return {
      update(next, prev) {
        const fresh = prev && prev !== next && prev.seq !== next.seq;
        st = next; E = Eng(st);
        legal = !st.st ? pawnMoves(E.blk, E.pos, st.t) : [];
        if (!prev || fresh) {
          finishAnim(); clearInput();
          if (gw && wallReason(E, gw.g, gw.o) === '다른 벽과 겹쳐요' && E.Wa[gw.g]) gw = null;
          if (mode === 'w' && st.wl[st.t] <= 0) mode = 'm';
        }
        if (fresh) {
          const ev = next.ev && next.ev.id === next.seq ? next.ev : null;
          if (ev && ev.k === 'u') { api.sfx('whoosh'); api.toast('한 수 물렀어요'); }
          else if (next.last && next.last.id === next.seq) {
            startAnim(next.last);
            if (next.last.k === 'w') { api.sfx('thud'); api.buzz(12); } else { api.sfx('tick'); api.buzz(6); }
            if (next.st && next.st.w >= 0) api.toast(name(next.st.w) + ' 도착!');
          }
          if (next.ev && next.ev.k === 'p' && next.ev.id === next.seq) api.toast(name(next.ev.s) + ' — 둘 수 있는 수가 없어 건너뜀');
        }
        updateHud(); draw();
      },
      destroy() {
        finishAnim();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onCancel);
        cv.destroy(); top.remove(); bot.remove(); hint.remove();
      },
    };
  }

  L.register({
    id: 'wallmaze', name: '벽 세우기 미로', tag: '길막기 전략', cat: '보드',
    blurb: '9×9 판에서 내 말을 맞은편 끝줄까지 먼저 보내면 이겨요. 차례마다 한 칸 움직이거나 벽을 세워 상대의 길을 돌아가게 만드세요. 길을 완전히 막는 벽은 안 돼요.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 400,
    tint: '#4a3a1c',
    icon: '<rect x="6" y="6" width="44" height="44" rx="4" fill="none" stroke="currentColor" stroke-width="2.5" opacity=".55"/><rect x="10" y="24" width="22" height="5" rx="1.5" fill="currentColor"/><rect x="34" y="12" width="5" height="22" rx="1.5" fill="currentColor"/><circle cx="20" cy="40" r="5.5" fill="currentColor"/><circle cx="28" cy="15" r="5.5" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M20 33v-2M44 44h-4" stroke="currentColor" stroke-width="2" opacity=".5"/>',
    quick: [
      '내 말을 맞은편 끝줄(테두리 색 띠) 어느 칸이든 먼저 보내면 이겨요.',
      '내 차례: 말을 상하좌우로 한 칸 옮기거나, 벽 하나를 세워 상대가 돌아가게 만들어요(둘 중 하나).',
      '벽으로 길을 완전히 막는 건 금지! 빙 돌아가더라도 길은 꼭 하나 남아야 해요.',
    ],
    rules: [
      { h: '목표', p: [
        '9×9 판. 각자 자기 변 가운데 칸에서 출발해, 맞은편 끝줄 어느 칸이든 먼저 닿으면 이겨요.',
        '판 테두리의 색 띠가 각자 도착해야 할 끝줄이에요.',
        '2명: 아래·위에서 마주 보고 시작, 벽 10개씩. 3명: 아래·왼쪽·위, 벽 6개씩. 4명: 네 변, 벽 5개씩.'] },
      { h: '차례에 할 일', p: [
        '둘 중 하나를 해요.',
        '① 말 이동: 상하좌우로 한 칸(대각선은 안 돼요). 벽이 가로막은 쪽으로는 못 가요.',
        '② 벽 세우기: 칸 두 개 길이의 벽을 칸 사이 홈에 가로나 세로로 세워요. 말은 벽을 넘어 지나갈 수 없어요.',
        '벽을 다 쓰면 말만 움직여요. 둘 수 있는 수가 하나도 없으면 그 차례는 건너뛰어요.'] },
      { h: '벽 규칙', p: [
        '벽은 다른 벽과 겹치거나 한가운데에서 십자(+)로 교차할 수 없어요.',
        '어떤 벽도 누군가의 도착 줄까지 가는 길을 완전히 막아서는 안 돼요(나 자신 포함). 빙 돌아가더라도 길이 하나는 남아야 해요.',
        '한 번 세운 벽은 끝까지 그대로예요.'] },
      { h: '특수 규칙: 점프', p: [
        '바로 옆 칸에 다른 말이 있으면 그 말을 뛰어넘어 그 너머 칸으로 갈 수 있어요.',
        '그 말 뒤에 벽이나 판 끝(또는 다른 말)이 있어 똑바로 못 넘으면, 그 말의 왼쪽·오른쪽 대각선 칸으로 갈 수 있어요(그쪽도 벽이 없을 때).',
        '말 두 개를 한꺼번에 넘을 수는 없어요.'] },
      { h: '승패', p: [
        '누군가 도착 줄에 닿으면 바로 끝나요.',
        `한 사람당 ${TURN_CAP}수가 넘도록 안 끝나면, 남은 길이 가장 짧은 사람이 이겨요.`] },
      { h: '조작', p: [
        '아래 「말 이동」 / 「벽」으로 할 일을 골라요.',
        '말 이동: 갈 수 있는 칸에 점이 찍혀 있어요. 점 칸을 탭하면 미리보기, 같은 칸을 한 번 더 탭하거나 확정 버튼(「이동」)을 누르면 끝.',
        '벽: 판 위를 끌면 반투명 벽이 홈에 맞춰 따라와요(손가락 조금 위). 판을 탭하면 그 자리로 옮기고, 벽 가운데 ↻를 탭하거나 ↻ 버튼을 누르면 가로·세로가 바뀌어요. 「벽 세우기」로 확정.',
        '놓을 수 없는 자리면 벽이 빨갛게 보이고 이유가 나와요(겹침·교차·길을 완전히 막음).',
        '「길」을 켜면 각자의 최단 길이 점선으로, 위 칩에 남은 칸 수(→)가 보여요. ▮ 숫자는 남은 벽이에요.',
        '↶ 무르기: 이 폰에서 사람 1명 대 AI일 때, 내 직전 수와 그 뒤 AI 수를 함께 되돌려요(최대 5번).'] },
      { h: '예시', p: [
        '상대가 나보다 2칸 앞서 있다 → 상대 바로 앞에 가로 벽을 세우면 상대는 옆으로 돌아가야 해서 몇 칸 늘어나요.',
        '벽은 아껴 쓰세요. 벽을 다 쓰면 상대가 마음대로 벽을 세워도 막을 방법이 없어요.',
        '상대 말이 바로 앞 칸에 있다 → 뛰어넘어 한 번에 두 칸 전진!'] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움.',
        '쉬움: 최단 길로 걷다가 가끔 아무 데나 벽을 세워요. 보통: 서로의 남은 길을 비교해 상대 길을 가장 많이 늘리는 벽을 골라요. 어려움: 2명일 때 몇 수 앞을 읽고(알파-베타), 남은 벽 수까지 따져 아낄 때와 쓸 때를 가려요.'] },
    ],
    tutorial: [
      { sel: '.wm-pawn', text: '이게 내 말이에요. 목표는...' },
      { sel: '.wm-goal', text: '...맞은편 끝줄(이 색 띠) 어느 칸이든 먼저 닿는 것! 상대도 반대쪽으로 달려요.' },
      { sel: '.wm-mode', text: '차례마다 둘 중 하나: 「말 이동」으로 한 칸 걷기, 또는 「벽」으로 벽 하나 세우기.' },
      { sel: '.wm-board', text: '말 이동: 갈 수 있는 칸에 점이 찍혀 있어요. 점을 탭하면 미리보기, 한 번 더 탭하면 이동! 바로 앞에 상대 말이 있으면 뛰어넘을 수도 있어요.' },
      { sel: '.wm-board', text: '벽: 「벽」을 고르고 판 위를 끌면 벽(칸 2개 길이)이 칸 사이 홈에 맞춰 따라와요. 상대가 빙 돌아가게 만드세요!' },
      { sel: '.wm-mode', text: '「벽」을 고르면 옆에 ↻ 버튼이 생겨요. ↻로 벽을 가로↔세로로 돌려요. 길을 완전히 막는 벽이나 겹치는 벽은 빨갛게 보이고 세울 수 없어요.' },
      { sel: '.wm-ok', text: '이 버튼으로 확정해요(「이동」/「벽 세우기」).' },
      { sel: '.wm-top', text: '위 칩: ▮ 숫자는 남은 벽, 「길」을 켜면 남은 칸 수(→)와 최단 길이 보여요. 벽은 아껴 쓰세요. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { Eng, pawnMoves, wallReason, distTo, dists, shortestPath, isGoal, START, TURN_CAP },
  });
})();
