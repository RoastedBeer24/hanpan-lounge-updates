/* 테니스 랠리 — realtime tennis seen from behind your own baseline (pseudo-3D perspective, portrait).
   2 players = singles, 3 = 2 vs 1 (the pair hits into the singles court, the solo player into the doubles court),
   4 = doubles (seats 0·2 vs 1·3). One person per phone; friends play via online / LAN rooms.
   Controls (feel > realism): your player runs to the ball by itself (◀ ▶ / ← → nudge it), you only swipe —
   up = topspin drive, down = slice, tap = lob; swipe angle = aim, swipe speed = power/depth. Serve: tap to toss, swipe.
   The swipe is a queued shot: the racket meets the ball when it arrives; swiping just before contact = "완벽!".
   Physics in real metres (gravity, drag, Magnus spin, surface-dependent bounce, net and tape), slowed to TS of real time.
   Online: host-authoritative. The host simulates every player (AI + remote humans from their published inputs),
   the ball and the umpire, and streams it; guests publish {move axis, shot command} and render the stream with
   local ball prediction (and predict their own hits for responsiveness). Score/phase lives in the core state. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- world (metres). x across (+x = team 0's right), y along: team 0 near (y < 0), team 1 far (y > 0) ---------- */
  const HL = 11.885, WS = 4.115, WD = 5.485, SL = 6.40, NETC = 0.914, NETP = 1.07, NETX = 6.4, BR = 0.033;
  const G = 9.81, KD = 0.0185, KL = 0.0072, SUB = 1 / 240, TS = 0.82;
  const ZK = 0.82;   // screen height of 1 m of altitude, in ground metres at that depth
  const REACH = 1.5, ZTOP = 2.8, FY = 18.5, FX = 11, HSPD = 5.8, HREACT = 0.08, ACC = 18;
  const SURF = {
    h: { e: 0.76, f: 0.70, name: '하드' },
    c: { e: 0.81, f: 0.60, name: '클레이' },
    g: { e: 0.66, f: 0.82, name: '잔디' },
  };
  const MODE = { tb: '타이브레이크', s4: '짧은 세트', s6: '정식 세트' };
  const C = { OUT: 1, NET: 2, WIN: 3, ACE: 4, FAULT: 5, DF: 6, LET: 7, SELF: 8 };
  /* AI levels (api.players[seat].lv: 1 쉬움 / 2 보통 / 3 어려움) */
  const DIFF = {
    1: { spd: 4.6, react: 0.3, pos: 0.32, whiff: 0.05, read: 0.25, aim: [0.05, 0.45], pw: [0.3, 0.66], ex: 0.9, ey: 0.7, ev: 0.55, big: 0.1,
      slice: 0.3, lob: 0.12, smash: 0.3, sp1: [0.3, 0.6], sp2: [0.2, 0.42], sx: 0.6, sy: 0.45, sv: 0.45, slow: 1.4 },
    2: { spd: 5.4, react: 0.19, pos: 0.14, whiff: 0.02, read: 0.6, aim: [0.35, 0.8], pw: [0.5, 0.86], ex: 0.6, ey: 0.4, ev: 0.33, big: 0.05,
      slice: 0.25, lob: 0.25, smash: 0.7, sp1: [0.55, 0.88], sp2: [0.32, 0.58], sx: 0.42, sy: 0.32, sv: 0.32, slow: 1 },
    3: { spd: 6.3, react: 0.1, pos: 0.05, whiff: 0.006, read: 0.92, aim: [0.5, 0.88], pw: [0.78, 0.98], ex: 0.24, ey: 0.2, ev: 0.16, big: 0.02,
      slice: 0.2, lob: 0.4, smash: 0.95, sp1: [0.78, 1.0], sp2: [0.45, 0.68], sx: 0.3, sy: 0.24, sv: 0.22, slow: 0.8 },
  };
  const LV_KO = { 1: '쉬움', 2: '보통', 3: '어려움' };
  /* human timing grades: 0 perfect, 1 good, 2 early, 3 late → [aim σ, depth σ, pace ×, launch-angle σ (m/s)] */
  const GN = [[0.15, 0.15, 1.05, 0.15], [0.45, 0.35, 1, 0.4], [0.9, 0.7, 0.9, 0.7], [0.7, 0.5, 0.92, 0.6]];
  const KIND_KO = ['탑스핀', '슬라이스', '로브', '서브', '스매시'];

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r2 = (v) => Math.round(v * 100) / 100;
  const r1 = (v) => Math.round(v * 10) / 10;
  const teamOf = (s) => s % 2;
  const fw = (t) => (t === 0 ? 1 : -1);            // a team's forward direction along y
  const sideY = (y) => (y < 0 ? 0 : 1);             // whose half a point is on
  const netH = (x) => NETC + (NETP - NETC) * Math.min(1, Math.abs(x) / NETX);
  const rnd = (r) => r[0] + Math.random() * (r[1] - r[0]);
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * Math.random()); }
  function teamsOf(np) { return np >= 4 ? [[0, 2], [1, 3]] : np === 3 ? [[0, 2], [1]] : [[0], [1]]; }
  function orderOf(np) { return np >= 4 ? [0, 1, 2, 3] : np === 3 ? [0, 1, 2, 1] : [0, 1]; }

  /* ---------- scoring (pure) ---------- */
  function server(st) {
    const o = orderOf(st.np);
    if (st.tb) { const n = st.p[0] + st.p[1]; return o[(st.tk + Math.floor((n + 1) / 2)) % o.length]; }
    return o[st.sk % o.length];
  }
  const courtSide = (st) => (st.p[0] + st.p[1]) % 2;   // 0 = deuce (right), 1 = ad (left)
  function receiver(st) { const m = teamsOf(st.np)[1 - teamOf(server(st))]; return m[courtSide(st) % m.length]; }
  function point(st, w, c, info) {
    const n = JSON.parse(JSON.stringify(st)), i = info || {};
    n.seq = (st.seq | 0) + 1; n.f = 0;
    n.ev = { c, w, s: fin(i.s) ? i.s : -1, k: i.k | 0, r: i.r | 0, nt: i.nt ? 1 : 0 };
    if (fin(i.x) && fin(i.y)) { n.ev.x = r1(i.x); n.ev.y = r1(i.y); }
    if (c === C.ACE) n.ac[w]++;
    if (c === C.WIN) n.wn[w]++;
    if (c === C.DF) n.df[1 - w]++;
    n.ru = Math.max(n.ru | 0, i.r | 0);
    n.p[w]++;
    if (n.tb) {
      if (n.p[w] >= 7 && n.p[w] - n.p[1 - w] >= 2) {
        n.ev.tp = n.p.slice();
        if (n.md !== 'tb') n.g[w]++;
        n.ph = 'done'; n.w = w; n.ev.gm = 2;
      }
    } else if (n.p[w] >= 4 && n.p[w] - n.p[1 - w] >= 2) {
      n.g[w]++; n.ev.gm = 1; n.ev.bk = teamOf(server(st)) !== w ? 1 : 0;
      n.p = [0, 0]; n.sk++;
      const tg = n.md === 's6' ? 6 : 4;
      if (n.g[w] >= tg && n.g[w] - n.g[1 - w] >= 2) { n.ph = 'done'; n.w = w; n.ev.gm = 2; }
      else if (n.g[0] === tg && n.g[1] === tg) { n.tb = 1; n.tk = n.sk; }
    }
    return n;
  }
  function fault(st, info) {
    const srv = server(st), i = info || {};
    if (st.f) return point(st, 1 - teamOf(srv), C.DF, Object.assign({}, i, { s: srv }));
    const n = JSON.parse(JSON.stringify(st));
    n.seq = (st.seq | 0) + 1; n.f = 1;
    n.ev = { c: C.FAULT, w: -1, s: srv, k: i.k | 0, r: 1, nt: i.nt ? 1 : 0 };
    if (fin(i.x) && fin(i.y)) { n.ev.x = r1(i.x); n.ev.y = r1(i.y); }
    return n;
  }
  function let_(st) {
    const n = JSON.parse(JSON.stringify(st));
    n.seq = (st.seq | 0) + 1;
    n.ev = { c: C.LET, w: -1, s: server(st), k: 0, r: 1, nt: 1 };
    return n;
  }
  const PTS = ['0', '15', '30', '40'];
  function ptText(st, t) {
    if (st.tb) return String(st.p[t]);
    const a = st.p[t], b = st.p[1 - t];
    if (a >= 3 && b >= 3) return a > b ? 'AD' : '40';
    return PTS[Math.min(3, a)];
  }
  /* who could win the match / break serve on the next point */
  function pressure(st) {
    if (!st || st.ph === 'done') return null;
    for (const t of [0, 1]) if (point(st, t, C.WIN).ph === 'done') return { t, txt: '매치 포인트' };
    if (!st.tb) { const o = 1 - teamOf(server(st)); if (point(st, o, C.WIN).g[o] > st.g[o]) return { t: o, txt: '브레이크 포인트' }; }
    return null;
  }

  /* ---------- ball flight. returns an event mask: 1 bounce, 2 net tape, 4 into the net, 8 dead ---------- */
  function stepBall(b, h, sf) {
    let ev = 0;
    const s = b.s || 0, vh = Math.hypot(b.vx, b.vy), v = Math.hypot(vh, b.vz);
    let ax = -KD * v * b.vx, ay = -KD * v * b.vy, az = -G - KD * v * b.vz;
    if (s !== 0 && vh > 0.2) { const m = KL * s * v; ax += m * b.vz * b.vx / vh; ay += m * b.vz * b.vy / vh; az -= m * vh; } // Magnus: topspin dives
    b.vx += ax * h; b.vy += ay * h; b.vz += az * h;
    const px = b.x, py = b.y, pz = b.z;
    b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h;
    if ((py < 0) !== (b.y < 0) && py !== b.y) {
      const k = py / (py - b.y), xc = px + (b.x - px) * k, zc = pz + (b.z - pz) * k, nh = netH(xc);
      if (Math.abs(xc) <= NETX + BR && zc < nh + BR && zc > -0.1) {
        if (zc < nh - BR * 0.5) { // into the mesh: drops on the hitter's side
          b.x = xc; b.y = py < 0 ? -0.05 : 0.05; b.z = Math.max(BR, zc);
          b.vy = -b.vy * 0.08; b.vx *= 0.25; b.vz = Math.min(0, b.vz) * 0.2; b.s = 0; ev |= 4;
        } else { // clips the tape and carries on, slowed and popped up
          b.vy *= 0.45; b.vx *= 0.8; b.vz = Math.abs(b.vz) * 0.25 + 0.9; b.z = nh + BR + 0.005; b.s = s * 0.3; ev |= 2;
        }
      }
    }
    if (b.z < BR) {
      if (b.vz < -0.25) {
        const spd = -b.vz, sp = b.s || 0;
        const e = clamp(sf.e + 0.05 * sp - 0.004 * Math.max(0, spd - 8), 0.45, 0.9);
        const fr = clamp(sf.f + 0.07 * sp - 0.01 * Math.max(0, spd - 5), 0.4, 0.95);
        b.z = BR; b.vz = spd * e; b.vx *= fr; b.vy *= fr; b.s = sp * 0.35; b.lb = spd; ev |= 1;
      } else { b.z = BR; b.vz = 0; const k = Math.max(0, 1 - 3 * h); b.vx *= k; b.vy *= k; b.s = 0; }
    }
    if (Math.abs(b.y) > FY || Math.abs(b.x) > FX || (b.vz === 0 && b.z <= BR && Math.hypot(b.vx, b.vy) < 0.35)) ev |= 8;
    return ev;
  }
  /* fly a copy until it first lands / hits the net / dies → {x, y, t, net(0|1|2), k(1 land, 2 net, 3 dead)} */
  const FB = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, s: 0, lb: 0 }, FO = { x: 0, y: 0, t: 0, net: 0, k: 0 };
  function flyTo(b0, sf) {
    FB.x = b0.x; FB.y = b0.y; FB.z = b0.z; FB.vx = b0.vx; FB.vy = b0.vy; FB.vz = b0.vz; FB.s = b0.s;
    let net = 0;
    for (let t = SUB; t < 4; t += SUB) {
      const e = stepBall(FB, SUB, sf);
      if (e & 2) net = 1;
      if (e & 4) { FO.x = FB.x; FO.y = FB.y; FO.t = t; FO.net = 2; FO.k = 2; return FO; }
      if (e & 1) { FO.x = FB.x; FO.y = FB.y; FO.t = t; FO.net = net; FO.k = 1; return FO; }
      if (e & 8) break;
    }
    FO.x = FB.x; FO.y = FB.y; FO.t = 4; FO.net = net; FO.k = 3; return FO;
  }
  /* choose the launch elevation so the ball lands at (tx, ty) with horizontal pace V and spin s. Mutates b. */
  const TB = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, s: 0 };
  function aimBall(b, tx, ty, V, s, sf, lob) {
    const dx = tx - b.x, dy = ty - b.y, dist = Math.hypot(dx, dy) || 1, ux = dx / dist, uy = dy / dist;
    const cost = (vz) => {
      TB.x = b.x; TB.y = b.y; TB.z = b.z; TB.vx = ux * V; TB.vy = uy * V; TB.vz = vz; TB.s = s;
      const r = flyTo(TB, sf);
      let e = Math.abs((r.x - b.x) * ux + (r.y - b.y) * uy - dist);
      if (r.k === 2) e += 40; else if (r.net) e += 3;
      if (r.k === 3) e += 25;
      return e + (lob ? -vz * 0.03 : Math.abs(vz) * 0.004);
    };
    const lo = lob ? 2 : -10, hi = lob ? 20 : 12, N = 30;
    let best = 0, be = 1e9;
    for (let i = 0; i <= N; i++) { const vz = lo + (hi - lo) * i / N, e = cost(vz); if (e < be) { be = e; best = vz; } }
    let step = (hi - lo) / N;
    for (let r = 0; r < 2; r++) {
      step /= 4; const c0 = best;
      for (let j = -3; j <= 3; j++) { if (!j) continue; const vz = c0 + j * step, e = cost(vz); if (e < be) { be = e; best = vz; } }
    }
    b.vx = ux * V; b.vy = uy * V; b.vz = best; b.s = s;
    return be - (lob ? -best * 0.03 : Math.abs(best) * 0.004);
  }
  /* shot shapes from power p (0…1, a little above 1 = over-hit) */
  function shotOf(k, p) {
    if (k === 1) return { d: 5.0 + p * 6.0, v: 15 + p * 9, sp: -0.7 };
    if (k === 2) return { d: 9.2 + p * 1.8, v: 8.4 + p * 2.2, sp: 0.45 };
    return { d: 5.2 + p * 6.0, v: 15 + p * 17, sp: 1.15 - 0.55 * Math.min(1, p) };
  }
  const serveOf = (p) => ({ d: 2.7 + p * 3.35, v: 19 + p * 20, sp: 0.95 - 0.7 * Math.min(1, p) });

  /* ---------- umpire (pure) R = {ph:'srv'|'fly'|'dead', srv, rcv, ht, sv, nb, net, hits, toss, box} ---------- */
  function canHit(R, team, b) {
    return R.ph === 'fly' && R.ht !== team && (R.sv ? R.nb === 1 : R.nb <= 1) && sideY(b.y) === team && Math.abs(b.y) > 0.15;
  }
  function refBounce(R, x, y, hw) {
    if (R.ph !== 'fly') return null;
    const H = R.ht, O = 1 - H, side = sideY(y);
    if (R.sv) {
      if (R.nb === 0) {
        R.nb = 1;
        const bx = R.box, inBox = x >= bx[0] - BR && x <= bx[1] + BR && y >= bx[2] - BR && y <= bx[3] + BR;
        if (!inBox) return { c: C.FAULT, x, y };
        if (R.net) return { c: C.LET, x, y };
        return null;
      }
      return { w: H, c: C.ACE };
    }
    R.nb++;
    if (R.nb === 1) {
      if (side === H) return { w: O, c: R.net ? C.NET : C.SELF, x, y };
      if (Math.abs(x) > hw[side] + BR || Math.abs(y) > HL + BR) return { w: O, c: C.OUT, x, y };
      return null;
    }
    return { w: H, c: C.WIN };
  }
  function refDead(R) {
    const H = R.ht, O = 1 - H;
    if (R.sv) return R.nb ? { w: H, c: C.ACE } : { c: C.FAULT };
    if (R.nb >= 1) return { w: H, c: C.WIN };
    return { w: O, c: R.net ? C.NET : C.OUT };
  }

  /* ---------- world ---------- */
  function newWorld(st) {
    const np = st.np, teams = teamsOf(np), sf = SURF[st.sf] || SURF.h;
    const W = { np, teams, sf, hw: [teams[0].length > 1 ? WD : WS, teams[1].length > 1 ? WD : WS], t: 0,
      b: { x: 0, y: -12, z: 1, vx: 0, vy: 0, vz: 0, s: 0, lb: 0 }, pl: [], R: null, hn: [], rally: 0, lh: -1, lv: 0,
      tk: [-1, -1], force: [-1, -1], plan: [], planT: -1, pb: null, sd: 0 };
    for (let s = 0; s < np; s++) {
      const t = teamOf(s);
      W.pl.push({ team: t, x: 0, y: -fw(t) * 12.5, vx: 0, vy: 0, tx: 0, ty: 0, fx: 0, fy: 0, max: HSPD, cmd: null, cool: 0,
        sw: 0, swK: 0, swS: 1, run: 0, vol: false, half: 1, role: 0, lock: false });
      W.hn.push(0);
    }
    resetPoint(W, st, true);
    return W;
  }
  /* formation for the next serve; snap = teleport (first point) */
  function resetPoint(W, st, snap) {
    const srv = server(st), sd = courtSide(st), rcv = receiver(st), T = teamOf(srv), O = 1 - T, fO = fw(O), sg = sd === 0 ? 1 : -1;
    W.sd = sd;
    for (let s = 0; s < W.np; s++) {
      const p = W.pl[s], f = fw(p.team), dbl = W.teams[p.team].length > 1;
      let x, y, role = 0;
      if (s === srv) { x = f * sg * (dbl ? 2.2 : 0.8); y = -f * (HL + 0.3); }
      else if (p.team === T) { x = -f * sg * 2.6; y = -f * 3.8; role = 1; }
      else if (s === rcv) { x = f * sg * (dbl ? 3.3 : 2.9); y = -f * (HL + 0.6); }
      else { x = -f * sg * 2.6; y = -f * 6.2; role = 1; }
      p.fx = x; p.fy = y; p.tx = x; p.ty = y; p.half = x < 0 ? -1 : 1; p.role = role;
      p.cmd = null; p.cool = 0; p.vol = false; p.lock = false;
      if (snap) { p.x = x; p.y = y; p.vx = 0; p.vy = 0; }
    }
    const bx1 = fO * sg * WS, by1 = -fO * SL;
    W.R = { ph: 'srv', srv, rcv, ht: T, sv: 1, nb: 0, net: 0, hits: 0, toss: 0,
      box: [Math.min(0, bx1), Math.max(0, bx1), Math.min(0, by1), Math.max(0, by1)] };
    W.rally = 0; W.lh = -1; W.tk = [-1, -1]; W.force = [-1, -1]; W.plan = []; W.planT = -1; W.pb = null;
    holdBall(W);
  }
  function holdBall(W) {
    const p = W.pl[W.R.srv], f = fw(p.team), b = W.b;
    b.x = p.x - 0.28 * f; b.y = p.y + 0.15 * f; b.z = 0.95; b.vx = 0; b.vy = 0; b.vz = 0; b.s = 0;
  }
  function toss(W, s) {
    const R = W.R;
    if (R.ph !== 'srv' || R.srv !== s || R.toss) return false;
    const p = W.pl[s], f = fw(p.team), b = W.b;
    R.toss = 1; p.lock = true; p.vx = 0; p.vy = 0;
    b.x = p.x + 0.22 * f; b.y = p.y + 0.42 * f; b.z = 1.55; b.vx = 0; b.vy = 0; b.vz = 5.2; b.s = 0;
    return true;
  }
  function movePlayers(W, h) {
    for (const p of W.pl) {
      if (p.cool > 0) p.cool -= h;
      if (p.sw > 0) { p.sw += h; if (p.sw > 0.45) p.sw = 0; }
      if (p.lock) { p.vx = 0; p.vy = 0; continue; }
      const dx = p.tx - p.x, dy = p.ty - p.y, d = Math.hypot(dx, dy);
      const want = Math.min(p.max, d * 5), wx = d > 1e-4 ? dx / d * want : 0, wy = d > 1e-4 ? dy / d * want : 0;
      let ax = wx - p.vx, ay = wy - p.vy; const a = Math.hypot(ax, ay), am = ACC * h;
      if (a > am) { ax *= am / a; ay *= am / a; }
      p.vx += ax; p.vy += ay; p.x += p.vx * h; p.y += p.vy * h;
      p.run += Math.hypot(p.vx, p.vy) * h;
      p.y = p.team === 0 ? clamp(p.y, -FY + 1, -0.6) : clamp(p.y, 0.6, FY - 1);
      p.x = clamp(p.x, -FX + 1, FX - 1);
    }
  }
  /* advance dt (game seconds). ctl: {live, hooks, allow(seat)} */
  function simulate(W, dt, ctl) {
    if (!(dt > 0)) return;
    const n = Math.min(240, Math.max(1, Math.ceil(dt / SUB))), h = dt / n, R = W.R, hk = ctl.hooks || {};
    for (let i = 0; i < n; i++) {
      W.t += h;
      movePlayers(W, h);
      if (R.ph === 'srv') {
        if (!R.toss) { holdBall(W); continue; }
        const b = W.b; b.vz -= G * h; b.z += b.vz * h;
        const sp = W.pl[R.srv], c = sp.cmd;
        if (c && c.k === 3 && b.vz < 0 && b.z <= 2.85 && (!ctl.allow || ctl.allow(R.srv))) { serveHit(W, R.srv, c, ctl); continue; }
        if (b.vz < 0 && b.z < 1.25) { R.toss = 0; sp.lock = false; holdBall(W); if (hk.toss) hk.toss(0); }
        continue;
      }
      const e = stepBall(W.b, h, W.sf);
      if (e) handleEv(W, e, ctl);
      if (R.ph === 'fly') tryHits(W, ctl);
    }
  }
  function handleEv(W, e, ctl) {
    const R = W.R, b = W.b, hk = ctl.hooks || {};
    if (e & 6) { if (R.ph === 'fly') R.net = 1; if (hk.net) hk.net(e & 2 ? 1 : 0); }
    if (e & 1) {
      if (hk.bounce) hk.bounce(b.x, b.y, b.lb);
      if (ctl.live && R.ph === 'fly') { const r = refBounce(R, b.x, b.y, W.hw); if (r) endPoint(W, r, ctl); }
    }
    if ((e & 8) && R.ph === 'fly') { if (ctl.live) endPoint(W, refDead(R), ctl); else R.ph = 'dead'; }
  }
  function endPoint(W, r, ctl) {
    W.R.ph = 'dead';
    r.net = W.R.net; r.rally = W.rally;
    if (ctl.hooks && ctl.hooks.point) ctl.hooks.point(r);
  }
  function tryHits(W, ctl) {
    const b = W.b, R = W.R;
    for (let s = 0; s < W.np; s++) {
      const p = W.pl[s], c = p.cmd;
      if (!c || c.k === 3 || p.cool > 0) continue;
      if (c.hc !== R.hits) { if (c.hc < R.hits) p.cmd = null; continue; }
      if (!canHit(R, p.team, b) || (R.sv && s !== R.rcv)) continue;
      if (R.nb === 0 && !p.vol) continue;              // planned to let it bounce first
      const fr = (b.y - p.y) * fw(p.team), lat = b.x - p.x;
      if (fr > 0.6 || fr < -1.0 || Math.abs(lat) > REACH || b.z > ZTOP || b.z < 0.04) continue;
      if (ctl.allow && !ctl.allow(s)) continue;
      hitBall(W, s, c, ctl);
      return;
    }
  }
  function hitBall(W, s, c, ctl) {
    const R = W.R, p = W.pl[s], b = W.b, f = fw(p.team);
    R.ht = p.team; R.sv = 0; R.nb = 0; R.net = 0; R.hits++;
    let k = c.k, V = c.v, sp = c.sp, smash = 0;
    if (k === 0 && b.z > 1.95) { smash = 1; V *= 1.15; sp = 0.2; }
    else if (k !== 2 && b.z < 0.35) V *= 0.86;
    // contact quality: a stretched reach, hitting on the run or a heavy incoming ball make the shot worse (for everyone)
    const stretch = clamp((Math.abs(b.x - p.x) - 0.95) / 0.55, 0, 1), run = clamp(Math.hypot(p.vx, p.vy) / 6, 0, 1);
    const pl = W.plan[s], late = pl ? clamp((0.3 - pl.slack) / 0.5, 0, 1) : 0, pace = clamp((Math.hypot(b.vx, b.vy) - 12) / 10, 0, 1);
    const q = 1.1 * stretch + 0.4 * run + 0.7 * late + 0.45 * pace;
    V *= 1 - 0.12 * stretch;
    const tx = c.a * f + (q > 0 ? gauss() * 0.45 * q : 0), ty = c.d * f;
    let e = aimBall(b, tx, ty, V, sp, W.sf, k === 2);
    for (let i = 0; i < 2 && e > 0.8 && k !== 2; i++) { V *= 0.86; e = aimBall(b, tx, ty, V, sp, W.sf, false); } // take pace off what can't land
    b.vz += (c.ve || 0) + (q > 0 ? gauss() * 0.25 * q : 0);
    p.cmd = null; p.cool = 0.3; p.sw = 1e-3; p.swK = smash ? 4 : k; p.swS = (b.x - p.x) * f >= 0 ? 1 : -1;
    afterHit(W, s, ctl, { k: p.swK, g: c.g | 0, serve: 0 });
  }
  function serveHit(W, s, c, ctl) {
    const R = W.R, p = W.pl[s], b = W.b, f = fw(p.team);
    R.ph = 'fly'; R.ht = p.team; R.sv = 1; R.nb = 0; R.net = 0; R.hits = 1; R.toss = 0;
    p.lock = false;
    aimBall(b, c.a * f, c.d * f, c.v, c.sp, W.sf, false);
    b.vz += c.ve || 0;
    p.cmd = null; p.cool = 0.3; p.sw = 1e-3; p.swK = 3; p.swS = 1;
    afterHit(W, s, ctl, { k: 3, g: c.g | 0, serve: 1 });
  }
  function afterHit(W, s, ctl, info) {
    const b = W.b;
    W.hn[s] = (W.hn[s] + 1) % 1000; W.rally++; W.lh = s; W.hT = W.t;
    W.lv = Math.hypot(b.vx, b.vy, b.vz);
    W.tk = [-1, -1]; W.force = [-1, -1]; W.plan = []; W.planT = -1; W.pb = null;
    info.v = W.lv;
    if (ctl.hooks && ctl.hooks.hit) ctl.hooks.hit(s, info);
  }

  /* ---------- prediction + positioning (AI and the human's auto-run share this) ---------- */
  const PN = 400;
  const PS = { n: 0, t: new Float32Array(PN), x: new Float32Array(PN), y: new Float32Array(PN), z: new Float32Array(PN),
    vz: new Float32Array(PN), nb: new Int8Array(PN), out: 0, bx: NaN, by: NaN };
  const PB = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, s: 0, lb: 0 };
  const PR = { ph: 'fly', ht: 0, sv: 0, nb: 0, net: 0, hits: 0, box: null };
  function predict(W, team) {
    const b = W.b, R = W.R;
    PB.x = b.x; PB.y = b.y; PB.z = b.z; PB.vx = b.vx; PB.vy = b.vy; PB.vz = b.vz; PB.s = b.s;
    PR.ph = R.ph; PR.ht = R.ht; PR.sv = R.sv; PR.nb = R.nb; PR.net = R.net; PR.hits = R.hits; PR.box = R.box;
    PS.n = 0; PS.out = 0; PS.bx = NaN; PS.by = NaN;
    if (R.ph !== 'fly') return PS;
    for (let i = 1; i <= 720 && PS.n < PN; i++) {
      const e = stepBall(PB, SUB, W.sf);
      if (e & 6) PR.net = 1;
      if (e & 1) {
        if (sideY(PB.y) === team && PS.bx !== PS.bx) { PS.bx = PB.x; PS.by = PB.y; }
        const r = refBounce(PR, PB.x, PB.y, W.hw);
        if (r) { if (r.c === C.OUT || r.c === C.FAULT) PS.out = 1; break; }
      }
      if (e & 8) break;
      if (i & 1) continue;
      if (canHit(PR, team, PB) && PB.z < ZTOP && PB.z > 0.05) {
        const k = PS.n++;
        PS.t[k] = i * SUB; PS.x[k] = PB.x; PS.y[k] = PB.y; PS.z[k] = PB.z; PS.vz[k] = PB.vz; PS.nb[k] = PR.nb;
      }
    }
    return PS;
  }
  /* best place for seat s to meet the predicted ball (uses PS from predict) */
  function planFor(W, s, spd, react) {
    const p = W.pl[s], f = fw(p.team), R = W.R;
    if (R.sv && s !== R.rcv) return null;
    const netMan = Math.abs(p.y) < 8;
    let best = null, bc = 1e9;
    for (let i = 0; i < PS.n; i++) {
      const t = PS.t[i], x = PS.x[i], y = PS.y[i], z = PS.z[i], pre = PS.nb[i] === 0;
      const off = clamp(x - p.x, -0.85, 0.85), bx = x - off, by = y - f * 0.45;
      const d = Math.hypot(bx - p.x, by - p.y), need = react + d / spd + (d > 0.3 ? 0.12 : 0), slack = t - need;
      let c = d * 0.06;
      if (pre) c += netMan ? (z > 2.3 ? 1 : -0.4) : 3;
      else if (PS.vz[i] > 0) c += 0.3;
      if (z < 0.4) c += (0.4 - z) * 6; else if (z > 1.6) c += (z - 1.6) * (pre ? 0.8 : 2);
      const back = Math.abs(y) - (HL + 1.2); if (back > 0) c += back * 0.9;
      if (slack < 0) c += 40 - slack * 25;
      if (c < bc) { bc = c; best = { t, x: bx, y: by, cx: x, cy: y, cz: z, pre, slack, cost: c }; }
    }
    if (best) { best.out = PS.out; best.at = W.t; }
    return best;
  }
  /* plans for the receiving team; picks who takes the ball (doubles) */
  function refreshPlans(W, reactOf) {
    const R = W.R;
    if (R.ph !== 'fly') return;
    const team = 1 - R.ht;
    predict(W, team);
    W.pb = PS.bx === PS.bx ? { x: PS.bx, y: PS.by, out: PS.out } : null;
    let bs = -1, bc = 1e9;
    for (const s of W.teams[team]) {
      const pl = planFor(W, s, W.pl[s].max, reactOf ? reactOf(s) : 0);
      W.plan[s] = pl;
      if (pl && pl.cost < bc) { bc = pl.cost; bs = s; }
    }
    for (const s of W.teams[R.ht]) W.plan[s] = null;
    W.tk[team] = W.force[team] >= 0 ? W.force[team] : bs;
    W.planT = W.t;
  }
  const humanReact = (W) => Math.max(0, HREACT - (W.t - (W.hT || 0)));
  function home(W, s) {
    const p = W.pl[s], f = fw(p.team), bx = clamp(W.b.x, -WD, WD);
    if (W.teams[p.team].length < 2) return { x: bx * 0.3, y: -f * (HL + 0.7) };
    if (p.role === 1) return { x: p.half * 2.3 + bx * 0.3, y: -f * 3.8 };
    return { x: p.half * 2.6 + bx * 0.25, y: -f * (HL + 0.5) };
  }

  /* ---------- AI ---------- */
  function aiShot(W, s, D, pl) {
    const p = W.pl[s], f = fw(p.team), O = 1 - p.team, hwT = W.hw[O];
    let ox = 0, onet = 0;
    for (const o of W.teams[O]) { ox += W.pl[o].x * f; if (Math.abs(W.pl[o].y) < 7) onet = 1; }
    ox /= W.teams[O].length;
    const stretch = pl.slack < 0.12 ? 1 : 0, r = Math.random();
    let k = 0, pw = rnd(D.pw);
    if (pl.cz > 1.95 && Math.abs(pl.cy) < 8 && r < D.smash) { k = 0; pw = 0.85; }
    else if (onet && r < D.lob) k = 2;
    else if (stretch || pl.cz < 0.35) k = Math.random() < 0.7 ? 1 : 2;
    else if (Math.random() < D.slice) k = 1;
    let side = ox > 0.5 ? -1 : ox < -0.5 ? 1 : (Math.random() < 0.5 ? -1 : 1);
    if (Math.random() < 0.18) side = -side;
    const sh = shotOf(k, pw), m = 1 + stretch * 0.5 + (k === 2 ? 0.3 : 0);
    let a = side * hwT * rnd(D.aim) + gauss() * D.ex * m, d = sh.d + gauss() * D.ey * m, ve = gauss() * D.ev * (k === 2 ? 0.6 : 1) * m;
    if (Math.random() < D.big * m * m) {            // an unforced error: long, wide or into the net
      const e = Math.random();
      if (e < 0.4) d = HL + 0.35 + Math.random() * 1.2;
      else if (e < 0.75) a = (a < 0 ? -1 : 1) * (hwT + 0.25 + Math.random());
      else { d = 3.5; ve = -0.9 - Math.random() * 0.6; }
    }
    return { k, a: r2(a), d: r2(d), v: r2(sh.v), sp: r2(sh.sp), ve: r2(ve), g: 1, hc: W.R.hits };
  }
  function aiServe(W, D, second) {
    const sg = W.sd === 0 ? -1 : 1, pw = second ? rnd(D.sp2) : rnd(D.sp1), r = Math.random();
    const lat = r < 0.4 ? 0.5 : r < 0.75 ? WS - 0.6 : WS * 0.5;      // T / wide / body
    const sh = serveOf(pw);
    return { k: 3, a: r2(sg * lat + gauss() * D.sx), d: r2(sh.d + gauss() * D.sy), v: r2(sh.v), sp: r2(second ? sh.sp + 0.3 : sh.sp), ve: r2(gauss() * D.sv), g: 1, hc: 0 };
  }
  /* m: per-seat memory. second: second serve? */
  function aiThink(W, s, m, D, dt, second, hooks) {
    const p = W.pl[s], R = W.R;
    p.max = D.spd;
    if (R.ph === 'srv') {
      p.vol = false;
      if (R.srv !== s) { p.tx = p.fx; p.ty = p.fy; m.sv = null; return; }
      if (!m.sv) m.sv = { w: (0.4 + Math.random() * 0.55) * D.slow };
      if (R.toss || p.cmd) return;
      m.sv.w -= dt;
      if (m.sv.w <= 0) { m.sv = null; p.cmd = aiServe(W, D, second); if (toss(W, s) && hooks && hooks.toss) hooks.toss(1); }
      return;
    }
    m.sv = null;
    if (R.ph !== 'fly') return;
    if (R.ht === p.team) { m.hc = -1; const h = home(W, s); p.tx = h.x; p.ty = h.y; p.vol = false; return; }
    if (m.hc !== R.hits) { m.hc = R.hits; m.react = D.react * (0.7 + Math.random() * 0.6); m.err = gauss() * D.pos; m.whiff = Math.random() < D.whiff; m.shot = 0; }
    if (m.react > 0) { m.react -= dt; return; }
    const pl = W.plan[s];
    if (!pl || W.tk[p.team] !== s) { const h = home(W, s); p.tx = h.x; p.ty = h.y; p.vol = false; return; }
    p.tx = pl.x + m.err; p.ty = pl.y; p.vol = pl.pre;
    if (!m.shot && !m.whiff) {
      if (pl.out && pl.pre && Math.random() < D.read) { m.shot = 1; return; }  // reads a long ball and lets it go
      if (pl.slack > -0.35) { m.shot = 1; p.cmd = aiShot(W, s, D, pl); }
    }
  }
  /* the human's auto-run: chases the planned contact point, ◀ ▶ nudges it */
  function assist(W, s, m, ax, dt) {
    const p = W.pl[s], R = W.R, f = fw(p.team);
    p.max = HSPD;
    if (R.ph === 'srv') {
      p.vol = false; m.off = 0;
      if (R.srv === s) {
        if (ax && !R.toss) {
          const lim = (W.teams[p.team].length > 1 ? WD : WS) - 0.3, sg = W.sd === 0 ? 1 : -1;
          let lat = p.tx * f + ax * dt * 3.2;
          lat = sg > 0 ? clamp(lat, 0.3, lim) : clamp(lat, -lim, -0.3);
          p.tx = lat * f;
        }
        p.ty = p.fy;
      } else {
        if (ax) p.tx = clamp(p.tx + ax * f * dt * 3.2, p.fx - 2.5, p.fx + 2.5);
        p.ty = p.fy;
      }
      return;
    }
    if (R.ph !== 'fly') return;
    const pl = W.plan[s];
    if (R.ht !== p.team && W.t - (W.hT || 0) < HREACT) return;          // a beat to read the shot
    if (R.ht !== p.team && pl && W.tk[p.team] === s) {
      if (ax) m.off = clamp((m.off || 0) + ax * f * dt * 4, -1.5, 1.5); else m.off = (m.off || 0) * Math.max(0, 1 - dt * 1.5);
      p.tx = pl.x + m.off; p.ty = pl.y; p.vol = pl.pre && !pl.out; m.free = 0;   // never volleys a ball that is going out
      return;
    }
    m.off = 0; p.vol = false;
    if (ax) { m.free = 0.8; p.tx = p.x + ax * f * 2.5; p.ty = p.y; return; }
    if (m.free > 0) { m.free -= dt; p.tx = p.x; p.ty = p.y; return; }
    const h = home(W, s); p.tx = h.x; p.ty = h.y;
  }
  /* build a human shot command (noise from the timing grade is baked in on the hitter's own device) */
  function humanCmd(W, s, k, aN, pw, g) {
    const p = W.pl[s], n = GN[g] || GN[1];
    if (k === 3) {
      const sg = W.sd === 0 ? -1 : 1, sh = serveOf(pw), ia = sg * WS / 2 + aN * WS / 2;
      return { k: 3, a: r2(ia + gauss() * n[0] * 0.6), d: r2(sh.d + gauss() * n[1] * 0.6), v: r2(sh.v * n[2]), sp: r2(sh.sp), ve: r2(gauss() * n[3] * 0.7), g, hc: 0, ia, id: sh.d };
    }
    const hwT = W.hw[1 - p.team], sh = shotOf(k, pw), ia = aN * hwT * 0.95;
    let a = ia + gauss() * n[0];
    if (g === 3) a += (aN >= 0 ? 1 : -1) * 0.8;
    return { k, a: r2(a), d: r2(sh.d + gauss() * n[1]), v: r2(sh.v * n[2]), sp: r2(sh.sp), ve: r2(gauss() * n[3] * (k === 2 ? 0.6 : 1)), g, hc: W.R.hits, ia, id: sh.d };
  }

  /* ---------- pure game interface ---------- */
  function init(players, opts) {
    const o = opts || {}, np = clamp((players && players.length) | 0, 2, 4);
    const md = o.len === 'tb' || o.len === 's6' ? o.len : 's4';
    const sk = U.rand(2);
    return {
      rid: 1 + U.rand(99999), n: players.slice(0, np).map((p) => String((p && p.name) || '').slice(0, 10)), np, md,
      sf: ['h', 'c', 'g'].includes(o.sf) ? o.sf : 'hcg'[U.rand(3)],
      g: [0, 0], p: [0, 0], tb: md === 'tb' ? 1 : 0, sk, tk: sk, f: 0, seq: 1, ev: null, ph: 'play', w: -1,
      ac: [0, 0], wn: [0, 0], df: [0, 0], ru: 0,
    };
  }
  function teamName(st, t, max) {
    const m = teamsOf(st.np)[t].map((s) => (st.n && st.n[s]) || (s + 1) + '번');
    const per = m.length > 1 ? Math.max(3, Math.floor((max || 12) / 2)) : (max || 12);
    return m.map((x) => (x.length > per ? x.slice(0, per - 1) + '…' : x)).join('·');
  }
  function result(st) {
    if (!st || st.ph !== 'done' || !(st.w === 0 || st.w === 1)) return null;
    const w = st.w, l = 1 - w;
    let sc;
    if (st.md === 'tb') sc = '타이브레이크 ' + st.p[w] + ' : ' + st.p[l];
    else sc = '게임 ' + st.g[w] + ' : ' + st.g[l] + (st.tb && st.ev && st.ev.tp ? ' (타이브레이크 ' + Math.max(st.ev.tp[0], st.ev.tp[1]) + ':' + Math.min(st.ev.tp[0], st.ev.tp[1]) + ')' : '');
    const stat = (t) => teamName(st, t, 10) + ' — 에이스 ' + st.ac[t] + ' · 위너 ' + st.wn[t] + ' · 더블 폴트 ' + st.df[t];
    return { winners: teamsOf(st.np)[w], title: teamName(st, w, 12) + ' 승리!', text: sc + '\n' + stat(0) + '\n' + stat(1) + '\n최장 랠리 ' + (st.ru | 0) + '번' };
  }

  /* ---------- small synth for the racket "pok" and the crowd (respects the app's sound switch) ---------- */
  const Snd = {
    ac: null, nb: null, cb: null,
    ctx() {
      let on = true; try { on = U.store.get('sound', true) !== false; } catch (e) {}
      if (!on) return null;
      try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; }
    },
    noise(ac) {
      if (!this.nb) { const n = Math.floor(ac.sampleRate * 0.25), b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this.nb = b; }
      return this.nb;
    },
    pok(vol, pitch) {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime, src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.noise(ac); f.type = 'bandpass'; f.frequency.value = 1700 * (pitch || 1); f.Q.value = 1.3;
        g.gain.setValueAtTime(0.55 * vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + 0.09);
        const o = ac.createOscillator(), g2 = ac.createGain(); o.type = 'triangle';
        o.frequency.setValueAtTime(430 * (pitch || 1), t); o.frequency.exponentialRampToValueAtTime(170, t + 0.06);
        g2.gain.setValueAtTime(0.32 * vol, t); g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.08);
        o.connect(g2).connect(ac.destination); o.start(t); o.stop(t + 0.1);
      } catch (e) {}
    },
    clap(dur, vol) {
      const ac = this.ctx(); if (!ac) return;
      try {
        if (!this.cb) {
          const sr = ac.sampleRate, n = Math.floor(sr * 2.2), b = ac.createBuffer(1, n, sr), d = b.getChannelData(0), len = Math.floor(sr * 0.014);
          for (let c = 0; c < 520; c++) { const st0 = Math.floor(Math.random() * (n - len)), amp = 0.15 + Math.random() * 0.4; for (let j = 0; j < len; j++) d[st0 + j] += (Math.random() * 2 - 1) * amp * Math.exp(-j / (len / 4)); }
          this.cb = b;
        }
        const t = ac.currentTime, src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.cb; f.type = 'bandpass'; f.frequency.value = 1500; f.Q.value = 0.6;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.4 * vol, t + 0.12); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + dur + 0.05);
      } catch (e) {}
    },
  };

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    let st = null, key = null, W = null, vph = 'wait', vt = 0, flip = false, viewT = 0, busy = false;
    let banner = null, cam = null, bg = null, shake = 0, pendingPt = null, srvWait = 0, hintN = 0, kbUsed = false, hintFlash = null;
    const mem = [{}, {}, {}, {}], fx = [], marks = [], trail = [], spark = [];
    const name = (s) => (st && st.n && st.n[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const aiCtl = (s) => host() && (P(s).ai || (auto() && localHuman(s)));
    const mine = (s) => s >= 0 && s === me() && !auto();

    /* ----- camera: behind the viewer's baseline; a TV-like angle, steeper only when it fits much bigger ----- */
    const CAMS = [[20, 22], [18, 26], [16, 30]];   // preferred first; steeper ones only when they fit much bigger
    function setCam() {
      const w = cv.w, h = cv.h, top = 62, bot = 70, aw = w - 10, ah = Math.max(120, h - top - bot);
      const list = (L.debug && L.debug.tcam) ? [L.debug.tcam] : CAMS, all = [];
      for (const [CY, CZ] of list) {
        const th = Math.atan2(CZ, CY), c = Math.cos(th), s = Math.sin(th);
        const pr = (x, y, z) => { const ry = y + CY, rz = -CZ, D = ry * c - rz * s; return { x: x / D, y: -(ry * s + rz * c) / D - z * ZK / D }; };
        const pts = [pr(-6.8, -13.6, 0), pr(6.8, -13.6, 0), pr(0, 13.4, 2.2), pr(-6.8, 13.4, 0), pr(6.8, 13.4, 0)];
        let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
        for (const q of pts) { x0 = Math.min(x0, q.x); x1 = Math.max(x1, q.x); y0 = Math.min(y0, q.y); y1 = Math.max(y1, q.y); }
        const F = Math.min(aw / (x1 - x0), ah / (y1 - y0));
        all.push({ CY, CZ, c, s, F, X0: w / 2, Y0: h - bot - F * y1 });   // court sits low; spare room goes to the stands
      }
      const maxF = Math.max(...all.map((a) => a.F));
      cam = all.find((a) => a.F >= maxF * 0.86) || all[0];
    }
    const T1 = { x: 0, y: 0, k: 1 }, T2 = { x: 0, y: 0, k: 1 };
    /* ground in true perspective; heights stand upright (pseudo-3D billboard) so players and ball height read well */
    function proj(x, y, z, o) {
      const vx = flip ? -x : x, vy = flip ? -y : y, ry = vy + cam.CY, rz = -cam.CZ;
      const D = Math.max(0.5, ry * cam.c - rz * cam.s);
      o.k = cam.F / D; o.x = cam.X0 + cam.F * vx / D; o.y = cam.Y0 - cam.F * (ry * cam.s + rz * cam.c) / D - z * ZK * o.k;
      return o;
    }
    const pj = (x, y, z) => proj(x, y, z, { x: 0, y: 0, k: 1 });
    const viewY = (y) => (flip ? -y : y);

    function layout() {
      flip = viewT === 1;
      setCam();
      buildBg();
    }

    /* ----- static layer: stadium, crowd, court, lines ----- */
    const CROWD = ['#c9a27a', '#6b5a8a', '#a34d4d', '#d8c9a8', '#4d6b8a', '#8a7a4d', '#3d3550', '#b07a9a', '#e3ae45', '#5a8a6b'];
    let crowdPts = [];
    function buildBg() {
      const keepFlip = flip;
      flip = false;              // scenery is drawn in view space (the court is symmetric)
      try { buildBg2(); } finally { flip = keepFlip; }
    }
    function buildBg2() {
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(cv.w * cv.dpr)); c.height = Math.max(1, Math.round(cv.h * cv.dpr));
      const g = c.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const sfc = st ? st.sf : 'h';
      const COL = sfc === 'c' ? { out: '#9c4a2a', court: '#b95b33', line: '#f6efe4' } : sfc === 'g' ? { out: '#356f30', court: '#438a3a', line: '#f4f4ea' } : { out: '#2f6a52', court: '#2b5c8e', line: '#f4f1e8' };
      // sky / night
      const sk = g.createLinearGradient(0, 0, 0, cv.h * 0.4);
      sk.addColorStop(0, '#120e19'); sk.addColorStop(1, '#2a2038');
      g.fillStyle = sk; g.fillRect(0, 0, cv.w, cv.h);
      const poly = (pts, fill) => { g.beginPath(); pts.forEach((p, i) => { const q = pj(p[0], p[1], p[2]); if (i) g.lineTo(q.x, q.y); else g.moveTo(q.x, q.y); }); g.closePath(); g.fillStyle = fill; g.fill(); };
      // ground (whole lower area), then the stands rising behind the far fence and along the sides
      const hz = pj(0, FY, 0);
      g.fillStyle = COL.out; g.fillRect(0, hz.y - 2, cv.w, cv.h);
      for (const sx of [-1, 1]) {
        poly([[sx * FX, -16, 0], [sx * FX, FY, 0], [sx * (FX + 9), FY + 1, 7], [sx * (FX + 9), -16, 7]], '#241c30');
        poly([[sx * FX, -16, 0], [sx * FX, FY, 0], [sx * FX, FY, 1.2], [sx * FX, -16, 1.2]], '#16352b');
      }
      poly([[-FX - 9, FY, 1.2], [FX + 9, FY, 1.2], [FX + 12, FY + 10, 9], [-FX - 12, FY + 10, 9]], '#2a2136');
      poly([[-FX, FY, 0], [FX, FY, 0], [FX, FY, 1.25], [-FX, FY, 1.25]], '#173a30');
      // ad boards (plain colour blocks)
      for (let i = 0; i < 8; i++) { const x0 = -FX + 0.4 + i * 2.75; poly([[x0, FY - 0.02, 0.2], [x0 + 2.3, FY - 0.02, 0.2], [x0 + 2.3, FY - 0.02, 1.0], [x0, FY - 0.02, 1.0]], i % 2 ? '#1f4a3d' : '#5a2d3a'); }
      // crowd
      crowdPts = [];
      g.save();
      let seed = 7; const rr0 = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      for (let r = 0; r < 7; r++) for (let x = -15; x <= 15; x += 0.62) crowdPts.push([x + (rr0() - 0.5) * 0.3, FY + 1 + r * 1.3, 1.75 + r * 0.95, rr0()]);
      for (const sx of [-1, 1]) for (let r = 0; r < 5; r++) for (let y = -13; y <= FY; y += 0.7) crowdPts.push([sx * (FX + 0.9 + r * 1.3), y + (rr0() - 0.5) * 0.3, 1.7 + r * 0.95, rr0()]);
      for (const q of crowdPts) {
        const o = pj(q[0], q[1], q[2]); if (o.y < -10 || o.y > cv.h + 10 || o.x < -10 || o.x > cv.w + 10) continue;
        const rr = Math.max(0.9, 0.24 * o.k);
        g.fillStyle = CROWD[Math.floor(q[3] * CROWD.length)]; g.globalAlpha = 0.55;
        g.beginPath(); g.ellipse(o.x, o.y + rr * 1.4, rr * 1.35, rr, 0, 0, 7); g.fill();
        g.globalAlpha = 0.7; g.fillStyle = q[3] > 0.5 ? '#d9b48f' : '#8a6248';
        g.beginPath(); g.arc(o.x, o.y, rr * 0.75, 0, 7); g.fill();
      }
      g.restore();
      // floodlight glows
      for (const sx of [-1, 1]) {
        const o = pj(sx * 13, FY + 8, 13), rg = g.createRadialGradient(o.x, o.y, 1, o.x, o.y, cv.w * 0.45);
        rg.addColorStop(0, 'rgba(255,240,200,.32)'); rg.addColorStop(1, 'rgba(255,240,200,0)');
        g.fillStyle = rg; g.fillRect(0, 0, cv.w, cv.h);
      }
      // court surface
      if (sfc === 'h') poly([[-WD - 1.3, -HL - 3, 0], [WD + 1.3, -HL - 3, 0], [WD + 1.3, HL + 3, 0], [-WD - 1.3, HL + 3, 0]], COL.court);
      else if (sfc === 'c') {
        poly([[-FX, -16, 0], [FX, -16, 0], [FX, FY, 0], [-FX, FY, 0]], COL.court);
        g.globalAlpha = 0.07; g.fillStyle = '#fff';
        for (let i = 0; i < 500; i++) { const o = pj((rr0() - 0.5) * 20, (rr0() - 0.5) * 34, 0); g.fillRect(o.x, o.y, 1, 1); }
        g.globalAlpha = 1;
      } else {
        for (let y = -16, i = 0; y < FY; y += 2, i++) poly([[-FX, y, 0], [FX, y, 0], [FX, y + 2, 0], [-FX, y + 2, 0]], i % 2 ? '#3f8436' : '#4a9240');
        g.globalAlpha = 0.22; g.fillStyle = '#9c8a5a'; // worn grass behind the baselines
        for (const sy of [-1, 1]) poly([[-2.2, sy * (HL - 0.6), 0], [2.2, sy * (HL - 0.6), 0], [2.8, sy * (HL + 2.2), 0], [-2.8, sy * (HL + 2.2), 0]], '#9c8a5a');
        g.globalAlpha = 1;
      }
      // lines (real widths, a touch thicker so they read on a phone)
      const ln = (x0, y0, x1, y1, w) => { const v = x0 === x1; const hw = w / 2; poly(v ? [[x0 - hw, y0, 0], [x0 + hw, y0, 0], [x1 + hw, y1, 0], [x1 - hw, y1, 0]] : [[x0, y0 - hw, 0], [x0, y0 + hw, 0], [x1, y1 + hw, 0], [x1, y1 - hw, 0]], COL.line); };
      for (const sy of [-1, 1]) {
        ln(-WD, sy * HL, WD, sy * HL, 0.13);
        ln(-WS, sy * SL, WS, sy * SL, 0.08);
        ln(0, sy * HL, 0, sy * (HL - 0.25), 0.08);
      }
      for (const sx of [-1, 1]) { ln(sx * WD, -HL, sx * WD, HL, 0.08); ln(sx * WS, -HL, sx * WS, HL, 0.08); }
      ln(0, -SL, 0, SL, 0.08);
      // umpire chair beside the net (screen left)
      const ux = -(NETX + 1.1);
      const a = pj(ux, 0, 0), b = pj(ux, 0, 2.3), k = a.k;
      g.strokeStyle = '#3a3143'; g.lineWidth = Math.max(1.5, 0.08 * k);
      g.beginPath(); g.moveTo(a.x - 0.35 * k, a.y); g.lineTo(b.x - 0.3 * k, b.y); g.moveTo(a.x + 0.35 * k, a.y); g.lineTo(b.x + 0.3 * k, b.y); g.stroke();
      g.fillStyle = '#4a3f55'; g.fillRect(b.x - 0.4 * k, b.y - 0.1 * k, 0.8 * k, 0.16 * k);
      g.fillStyle = '#e8e0cf'; g.beginPath(); g.ellipse(b.x, b.y - 0.45 * k, 0.2 * k, 0.32 * k, 0, 0, 7); g.fill();
      g.fillStyle = '#d6b08a'; g.beginPath(); g.arc(b.x, b.y - 0.88 * k, 0.12 * k, 0, 7); g.fill();
      g.fillStyle = '#20202a'; g.beginPath(); g.arc(b.x, b.y - 0.93 * k, 0.12 * k, Math.PI, 0); g.fill();
      bg = c;
    }

    /* ----- input: swipes on the court, ◀ ▶ buttons, keyboard / pad ----- */
    let swp = null, btnAx = 0, cmdN = 0, myCmd = null, tossN = 0, charge = null;
    function onDown(e) {
      if (me() < 0 || auto()) return;
      const pt = cv.local(e), t = performance.now();
      swp = { id: e.pointerId, x0: pt.x, y0: pt.y, t0: t, pts: [{ x: pt.x, y: pt.y, t }] };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      e.preventDefault();
    }
    function onMove(e) {
      if (!swp || e.pointerId !== swp.id) return;
      const pt = cv.local(e); swp.pts.push({ x: pt.x, y: pt.y, t: performance.now() }); if (swp.pts.length > 24) swp.pts.shift();
    }
    function onUp(e) {
      if (!swp || e.pointerId !== swp.id) return;
      const pt = cv.local(e), t = performance.now(), s0 = swp; swp = null;
      s0.pts.push({ x: pt.x, y: pt.y, t });
      const dx = pt.x - s0.x0, dy = pt.y - s0.y0, dist = Math.hypot(dx, dy), dur = (t - s0.t0) / 1000;
      if (dist < 16 && dur < 0.5) { input('tap', { x: s0.x0 }); return; }
      if (dist < 26) return;
      let q = s0.pts[0];
      for (const p of s0.pts) if (t - p.t <= 110) { q = p; break; }
      const sd = Math.hypot(pt.x - q.x, pt.y - q.y), st2 = Math.max(0.016, (t - q.t) / 1000);
      const vn = (sd / st2) / Math.max(420, cv.h);
      const pw = vn <= 2.9 ? clamp((vn - 0.3) / 2.6, 0.08, 1) : 1 + Math.min(0.15, (vn - 2.9) * 0.05);   // only very fast flicks over-hit
      const aN = clamp(Math.atan2(dx, Math.abs(dy)) / 0.87, -1.4, 1.4);
      input('swipe', { k: dy < 0 ? 0 : 1, aN, pw });
    }
    function onCancel(e) { if (swp && e.pointerId === swp.id) swp = null; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.cv.addEventListener('contextmenu', noCtx);
    const btns = [];
    function mkBtn(txt, dir, side) {
      const b = L.h('button', { class: 'btn', type: 'button', 'aria-label': dir < 0 ? '왼쪽으로' : '오른쪽으로', text: txt,
        style: { position: 'absolute', bottom: '10px', [side]: '10px', width: '58px', height: '58px', borderRadius: '50%', padding: '0', fontSize: '22px', zIndex: '3', touchAction: 'none', opacity: '.9', background: 'rgba(46,38,64,.88)' } });
      const on = (e) => { btnAx = dir; b.style.background = 'var(--brass)'; b.style.color = '#2a1d05'; try { b.setPointerCapture(e.pointerId); } catch (er) {} e.preventDefault(); };
      const off = () => { if (btnAx === dir) btnAx = 0; b.style.background = 'rgba(46,38,64,.88)'; b.style.color = ''; };
      b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('lostpointercapture', off);
      b.addEventListener('contextmenu', noCtx);
      root.appendChild(b); btns.push(b);
      return b;
    }
    mkBtn('◀', -1, 'left'); mkBtn('▶', 1, 'right');
    function showBtns() { const v = me() >= 0 && !auto(); btns.forEach((b) => { b.style.display = v ? '' : 'none'; }); }
    const axis = () => clamp(btnAx + (api.input ? api.input.axis('left', 'right') : 0), -1, 1);
    const moveAxis = () => (charge && W && W.R.ph === 'fly' ? btnAx : axis());   // while a shot key is held, ← → aim instead of moving
    const offIn = api.input ? api.input.on((type, id) => {
      kbUsed = true;
      if (id === 'left' || id === 'right' || me() < 0 || auto()) return;
      const k = id === 'slice' ? 1 : id === 'lob' ? 2 : 0;
      if (type === 'down') {
        charge = { id, k, t0: performance.now(), last: 0 };
        if (W && W.R.ph === 'srv' && W.R.srv === me() && k === 0 && vph === 'play') tossReq();
        else if (W && W.R.ph === 'fly') commitCharge(false);
      } else if (charge && charge.id === id) { commitCharge(true); charge = null; }
    }) : null;
    function chargePw() { return clamp(0.3 + ((performance.now() - charge.t0) / 1000) / 0.75 * 0.68, 0.3, 0.98); }
    function commitCharge(final) {
      if (!charge || !W) return;
      const aN = axis() * 0.85;
      if (W.R.ph === 'srv') { if (final && charge.k === 0) input('swipe', { k: 0, aN, pw: chargePw(), kb: 1 }); return; }
      input('swipe', { k: charge.k, aN, pw: chargePw(), kb: 1, quiet: !final });
    }
    function tossReq() {
      const s = me(); if (s < 0 || !W || vph !== 'play') return;
      const R = W.R; if (R.ph !== 'srv' || R.srv !== s || R.toss) return;
      srvWait = 0;
      if (host()) { if (toss(W, s)) hooks.toss(1); }
      else { tossN = (tossN + 1) % 1000; toss(W, s); pubT = 0; }
    }
    function serveGrade() {
      const R = W.R, b = W.b;
      if (!R.toss) return 1;
      if (b.vz < 0 && b.z <= 2.85) return b.z > 2.5 ? 0 : 3;
      const A = -G / 2, B = b.vz, Cc = b.z - 2.85, disc = B * B - 4 * A * Cc;
      const tr = disc > 0 ? (-B - Math.sqrt(disc)) / (2 * A) : 0;
      return tr <= 0.24 ? 0 : 1;
    }
    function rallyGrade(s) {
      const pl = W.plan[s];
      if (!pl) return 1;
      const tc = pl.t - (W.t - pl.at);
      if (tc < -0.06) return 3;
      return tc <= 0.32 ? 0 : tc <= 0.95 ? 1 : 2;
    }
    function input(kind, a) {
      const s = me(); if (s < 0 || !W || auto()) return;
      if (vph !== 'play') return;
      const R = W.R, p = W.pl[s];
      if (R.ph === 'srv') {
        if (R.srv !== s) { flash(name(R.srv) + ' 서브를 기다려요'); return; }
        if (kind === 'tap') { if (!R.toss) tossReq(); return; }
        const g = serveGrade();
        if (!R.toss) tossReq();
        setCmd(humanCmd(W, s, 3, a.aN, a.pw, g));
        return;
      }
      if (R.ph !== 'fly' || R.ht === p.team) { if (!a.quiet) flash('공이 넘어오면 쳐요'); return; }
      if (R.sv && s !== R.rcv) { flash(name(R.rcv) + '이(가) 받아요'); return; }
      let k = a.k, aN = a.aN, pw = a.pw;
      if (kind === 'tap') { k = 2; aN = clamp((a.x - cv.w / 2) / (cv.w / 2), -1, 1) * 0.8; pw = 0.6; }
      const c = humanCmd(W, s, k, aN, pw, a.quiet ? 1 : rallyGrade(s));
      setCmd(c, a.quiet);
    }
    function setCmd(c, quiet) {
      const s = me(); if (s < 0) return;
      cmdN = (cmdN + 1) % 100000; c.n = cmdN;
      myCmd = c;
      W.pl[s].cmd = c;
      if (c.k !== 3) W.force[teamOf(s)] = s;
      pubT = 0;
      if (!quiet) { api.buzz(8); }
    }
    let flashT = 0;
    function flash(t) { hintFlash = t; flashT = 1.6; }

    /* ----- feedback ----- */
    let lastB = 0;
    const hooks = {
      hit(s, info) {
        const b = W.b, big = info.v > 30 || info.k === 4;
        Snd.pok(big ? 1 : 0.75, info.k === 1 ? 0.8 : info.k === 2 ? 1.15 : 1);
        if (!Snd.ac) api.sfx(big ? 'hit' : 'pop');
        if (mine(s)) api.buzz(big ? 22 : 12);
        fx.push({ t: 0, life: 0.35, ring: 1, x: b.x, y: b.y, z: b.z, col: P(s).color, big });
        for (let i = 0; i < (big ? 9 : 5); i++) fx.push({ t: 0, life: 0.3 + Math.random() * 0.2, sp: 1, x: b.x, y: b.y, z: b.z, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 3, vz: Math.random() * 3, col: i % 2 ? '#f2f08a' : P(s).color });
        if (info.k === 3 || info.k === 4) fx.push({ t: 0, life: 1.1, txt: Math.round(info.v * 3.6) + ' km/h', x: W.pl[s].x, y: W.pl[s].y, z: 2.6, col: '#f2e9d8', sm: 1 });
        if (mine(s) && info.g === 0) fx.push({ t: 0, life: 0.8, txt: '완벽!', x: W.pl[s].x, y: W.pl[s].y, z: 2.3, col: '#e3ae45' });
        else if (mine(s) && info.g === 2 && info.k !== 3) fx.push({ t: 0, life: 0.8, txt: '일찍!', x: W.pl[s].x, y: W.pl[s].y, z: 2.3, col: '#ab9fb8' });
        else if (mine(s) && info.g === 3) fx.push({ t: 0, life: 0.8, txt: '늦었어요', x: W.pl[s].x, y: W.pl[s].y, z: 2.3, col: '#ee6a55' });
        if (info.k === 4) fx.push({ t: 0, life: 0.8, txt: '스매시!', x: W.pl[s].x, y: W.pl[s].y, z: 2.9, col: P(s).color });
        if (big) shake = Math.max(shake, info.k === 4 ? 0.7 : 0.35);
        if (mine(s)) myCmd = null;
        trail.length = 0;
      },
      bounce(x, y, spd) {
        const t = performance.now();
        if (spd > 1 && t - lastB > 45) { lastB = t; api.sfx('bounce'); }
        if (spd > 1.5) {
          marks.push({ x, y, t: 0, life: st && st.sf === 'c' ? 99 : 1.4 });
          if (marks.length > 14) marks.shift();
          if (st && st.sf === 'c') for (let i = 0; i < 4; i++) fx.push({ t: 0, life: 0.5, dust: 1, x, y, z: 0.05, vx: (Math.random() - 0.5) * 1.2, vy: (Math.random() - 0.5) * 1.2, vz: 0.6 + Math.random(), col: '#d98a5f' });
        }
      },
      net(cord) { api.sfx(cord ? 'chip' : 'thud'); if (!cord) shake = Math.max(shake, 0.2); },
      point(r) { pendingPt = r; },
      toss() { api.sfx('whoosh'); },
    };

    function decide(r) {
      if (!st || st.ph === 'done' || !host()) return;
      const info = { s: W.lh, k: Math.round(W.lv * 3.6), r: r.rally | 0, x: r.x, y: r.y, nt: r.net };
      let n;
      if (r.c === C.LET) n = let_(st);
      else if (r.c === C.FAULT) n = fault(st, info);
      else n = point(st, r.w, r.c, info);
      api.setState(n);
    }

    /* ----- phases: 'ready' (walk to places) → 'play' → (point) 'over' → 'ready' … 'done' ----- */
    function onNewKey(next, first) {
      const ev = next.ev;
      if (first || !W || next.seq === 1) {   // new match (also a rematch)
        if (busy) { busy = false; api.setBusy(false); }
        W = newWorld(next); vph = 'ready'; vt = 1.5; myCmd = null; charge = null; marks.length = 0; fx.length = 0;
        banner = { t: name(server(next)) + ' 서브', sub: MODE[next.md] + ' · ' + (SURF[next.sf] || SURF.h).name + ' 코트', col: P(server(next)).color, life: 1.5 };
        return;
      }
      W.R.ph = 'dead';
      myCmd = null; charge = null;
      vph = 'over'; vt = ev && (ev.c === C.FAULT || ev.c === C.LET) ? 0.95 : 1.4;
      if (next.ph === 'done') { busy = true; api.setBusy(true); vt = 1.8; }
      banner = evBanner(next);
      feedback(next);
    }
    function evBanner(n) {
      const ev = n.ev; if (!ev) return null;
      let t = '', col = '#f2e9d8';
      switch (ev.c) {
        case C.OUT: t = '아웃!'; col = '#ee6a55'; break;
        case C.NET: t = '네트!'; break;
        case C.WIN: t = ev.r <= 2 ? '서브 득점!' : '위너!'; col = '#e3ae45'; break;
        case C.ACE: t = '에이스!'; col = '#e3ae45'; break;
        case C.FAULT: t = ev.nt ? '네트 — 폴트' : '폴트'; col = '#ee6a55'; break;
        case C.DF: t = '더블 폴트'; col = '#ee6a55'; break;
        case C.LET: t = '렛 — 다시 서브'; break;
        case C.SELF: t = '실수!'; break;
      }
      let sub = '';
      if (ev.c === C.FAULT) sub = '세컨드 서브';
      else if (ev.c === C.LET) sub = '네트에 스치고 들어갔어요';
      else if (ev.w === 0 || ev.w === 1) {
        if (ev.gm === 2) sub = teamName(n, ev.w, 10) + ' 승리!';
        else if (ev.gm === 1) sub = (ev.bk ? '브레이크! ' : '') + '게임 ' + teamName(n, ev.w, 8) + ' · ' + n.g[vt0()] + ' : ' + n.g[1 - vt0()];
        else sub = callText(n, ev.w);
      }
      return { t, sub, col, life: vt + 0.6, w: ev.w };
    }
    const vt0 = () => (viewT === 1 ? 1 : 0);
    function callText(n, w) {
      if (n.tb) return '타이브레이크 ' + n.p[vt0()] + ' : ' + n.p[1 - vt0()];
      const a = n.p[0], b = n.p[1];
      if (a >= 3 && b >= 3) return a === b ? '듀스' : '어드밴티지 ' + teamName(n, a > b ? 0 : 1, 10);
      return teamName(n, w, 8) + ' 득점 · ' + ptText(n, vt0()) + ' : ' + ptText(n, 1 - vt0());
    }
    function feedback(n) {
      const ev = n.ev; if (!ev) return;
      const meT = me() >= 0 ? teamOf(me()) : -1;
      if (ev.w === 0 || ev.w === 1) {
        if (meT < 0) api.sfx('chip');
        else if (meT === ev.w) { api.sfx('chip'); api.buzz(20); } else { api.sfx('thud'); api.buzz(35); }
        const loud = ev.c === C.ACE || ev.c === C.WIN || ev.gm || ev.r >= 8;
        Snd.clap(loud ? 1.6 : 0.9, loud ? 1 : 0.45);
        if (loud) for (let i = 0; i < 16; i++) { const c = crowdPts[Math.floor(Math.random() * crowdPts.length)]; if (c) spark.push({ d: Math.random() * 1.2, t: 0, q: flip ? [-c[0], -c[1], c[2]] : c }); }
      } else api.sfx('tick');
      if (fin(ev.x) && fin(ev.y) && (ev.c === C.OUT || ev.c === C.FAULT)) marks.push({ x: ev.x, y: ev.y, t: 0, life: 2.4, out: 1 });
    }
    function startPlay() {
      vph = 'play'; srvWait = 0;
      for (const p of W.pl) { if (Math.hypot(p.x - p.fx, p.y - p.fy) > 0.4) { p.x = p.fx; p.y = p.fy; } p.vx = 0; p.vy = 0; }
      W.pl.forEach((p) => { p.tx = p.fx; p.ty = p.fy; });
      mem.forEach((m) => { m.sv = null; m.hc = -1; });
    }

    /* ----- online ----- */
    const curKey = () => (st ? st.rid + '.' + st.seq : null);
    let pubT = 0, q = 0, snap = null, lastQ = -1, pred = null;
    const remAx = [0, 0, 0, 0], remCn = [null, null, null, null], remTn = [null, null, null, null], seenH = [0, 0, 0, 0], remWait = [0, 0, 0, 0];
    function sane(c) {
      if (!c || typeof c !== 'object') return null;
      const k = c.k | 0; if (k < 0 || k > 3) return null;
      if (![c.a, c.d, c.v, c.sp].every(fin)) return null;
      return { k, a: clamp(c.a, -9, 9), d: clamp(c.d, 0, 16), v: clamp(c.v, 5, 45), sp: clamp(c.sp, -1.5, 1.5), ve: fin(c.ve) ? clamp(c.ve, -3, 3) : 0, g: clamp(c.g | 0, 0, 3), hc: c.hc | 0, n: c.n };
    }
    function pollNet(now) {
      if (!api.online) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) {
          const s = +k, o = rem[k];
          if (!(s >= 0 && s < W.np) || P(s).ai || localHuman(s) || !o || typeof o !== 'object') continue;
          if (o.k !== curKey()) { remAx[s] = 0; continue; }
          remAx[s] = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0;
          const R = W.R;
          if (o.tn !== remTn[s]) { if (remTn[s] != null && vph === 'play' && R.ph === 'srv' && R.srv === s && toss(W, s)) hooks.toss(1); remTn[s] = o.tn; }
          if (o.c && o.c.n !== remCn[s]) {
            remCn[s] = o.c.n;
            const c = sane(o.c);
            if (!c) continue;
            if (c.k === 3) { if (vph === 'play' && R.ph === 'srv' && R.srv === s) { if (!R.toss && toss(W, s)) hooks.toss(1); W.pl[s].cmd = c; } }
            else if (R.ph === 'fly' && c.hc === R.hits && R.ht !== teamOf(s)) { W.pl[s].cmd = c; W.force[teamOf(s)] = s; }
          }
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== curKey() || hs.q === lastQ) return;
        lastQ = hs.q;
        if (Array.isArray(hs.b) && hs.b.length >= 7 && hs.b.every(fin)) snap = { b: hs.b, at: now };
        if (Array.isArray(hs.p)) for (let s = 0; s < W.np; s++) {
          const x = hs.p[s * 2], y = hs.p[s * 2 + 1], p = W.pl[s];
          if (!fin(x) || !fin(y)) continue;
          if (fin(p.nx) && p.nat) { const dt = (now - p.nat) / 1000; if (dt > 0.01 && dt < 0.5) { p.nvx = (x - p.nx) / dt; p.nvy = (y - p.ny) / dt; } }
          p.nx = x; p.ny = y; p.nat = now;
          p.rdy = !!(hs.c & (1 << s));
        }
        if (Array.isArray(hs.r) && hs.r.length >= 7 && !(pred && now < pred.until)) {
          const R = W.R, ph = ['srv', 'fly', 'dead'][hs.r[0] | 0] || 'dead';
          if (vph === 'play' || vph === 'ready') { R.ph = ph; R.ht = hs.r[1] | 0; R.sv = hs.r[2] | 0; R.nb = hs.r[3] | 0; R.net = hs.r[4] | 0; R.hits = hs.r[5] | 0; R.toss = hs.r[6] | 0; }
        }
        if (Array.isArray(hs.h)) for (let s = 0; s < W.np; s++) {
          const v = hs.h[s] | 0;
          if (v !== seenH[s]) {
            seenH[s] = v;
            if (pred && pred.s === s) { pred = null; continue; }      // my own predicted hit, now confirmed
            const p = W.pl[s]; p.sw = 1e-3; p.swK = W.b.z > 2.2 ? (W.R.sv ? 3 : 4) : 0; p.swS = (W.b.x - p.x) * fw(p.team) >= 0 ? 1 : -1;
            const b = snap ? snap.b : null, v2 = b ? Math.hypot(b[3], b[4], b[5]) : 20;
            const sv = W.R.sv && W.R.hits <= 1;
            hooks.hit(s, { k: sv ? 3 : p.swK, v: v2, g: 1, serve: sv ? 1 : 0 });
          }
        }
      }
    }
    function guestPlayers(rdt, now) {
      for (const p of W.pl) {
        if (!fin(p.nx)) continue;
        const age = Math.min(0.1, (now - p.nat) / 1000);
        const tx = p.nx + (p.nvx || 0) * age, ty = p.ny + (p.nvy || 0) * age, k = 1 - Math.exp(-rdt * 14);
        const ox = p.x, oy = p.y;
        if (Math.hypot(tx - p.x, ty - p.y) > 3) { p.x = tx; p.y = ty; } else { p.x += (tx - p.x) * k; p.y += (ty - p.y) * k; }
        const d = Math.hypot(p.x - ox, p.y - oy); p.run += d;
        p.vx = p.nvx || 0; p.vy = p.nvy || 0;
        if (p.sw > 0) { p.sw += rdt * SPD() * TS; if (p.sw > 0.45) p.sw = 0; }
        if (p.cool > 0) p.cool -= rdt * SPD() * TS;
      }
    }
    function reconcile(rdt, now) {
      if (!snap) return;
      if (pred) { if (now < pred.until) return; pred = null; }
      const b = snap.b, R = W.R;
      const t = { x: b[0], y: b[1], z: b[2], vx: b[3], vy: b[4], vz: b[5], s: b[6], lb: 0 };
      const age = Math.min(0.15, (now - snap.at) / 1000 + 0.03) * SPD() * TS;
      if (R.ph === 'fly' || R.ph === 'dead') for (let a = 0; a < age; a += SUB * 2) stepBall(t, SUB * 2, W.sf);
      else if (R.toss) { t.z += t.vz * age - G * age * age / 2; t.vz -= G * age; }
      const d = Math.hypot(t.x - W.b.x, t.y - W.b.y, t.z - W.b.z), k = 1 - Math.exp(-rdt * 18);
      if (d > 0.8 || R.ph === 'srv') Object.assign(W.b, t);
      else { W.b.x += (t.x - W.b.x) * k; W.b.y += (t.y - W.b.y) * k; W.b.z += (t.z - W.b.z) * k; W.b.vx = t.vx; W.b.vy = t.vy; W.b.vz = t.vz; W.b.s = t.s; }
    }
    function publish(rdt) {
      if (!api.online) return;
      pubT -= rdt; if (pubT > 0) return; pubT = 1 / 30;
      try {
        q = (q + 1) % 1000;
        const k = curKey();
        if (api.isHost) {
          const b = W.b, p = [], R = W.R; let cm = 0;
          for (let s = 0; s < W.np; s++) { p.push(r2(W.pl[s].x), r2(W.pl[s].y)); if (W.pl[s].cmd) cm |= 1 << s; }
          api.net.hostSend({ k, q, b: [r2(b.x), r2(b.y), r2(b.z), r2(b.vx), r2(b.vy), r2(b.vz), r2(b.s || 0)], p, c: cm,
            r: [['srv', 'fly', 'dead'].indexOf(R.ph), R.ht, R.sv, R.nb, R.net, R.hits, R.toss], h: W.hn.slice() });
        } else {
          const s = me(); if (s < 0) return;
          const o = { k, q, ax: r1(moveAxis()), tn: tossN };
          if (myCmd) o.c = { k: myCmd.k, a: myCmd.a, d: myCmd.d, v: myCmd.v, sp: myCmd.sp, ve: myCmd.ve, g: myCmd.g, hc: myCmd.hc, n: myCmd.n };
          api.net.publish(o);
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    const reactOf = (s) => { if (!aiCtl(s)) return humanReact(W); const m = mem[s]; return m.hc === W.R.hits ? Math.max(0, m.react || 0) : DIFF[lvOf(s)].react; };
    function frame(rdt, now) {
      if (!st || !W) return;
      const pdt = rdt * SPD(), gdt = pdt * TS;
      const guest = api.online && !api.isHost;
      pollNet(now);
      if (vph === 'over' || vph === 'ready') {
        vt -= pdt;
        if (vph === 'over' && vt <= 0) {
          if (st.ph === 'done') { vph = 'done'; if (busy) { busy = false; api.setBusy(false); } }
          else { resetPoint(W, st, false); vph = 'ready'; vt = 1.0; myCmd = null; }
        } else if (vph === 'ready' && vt <= 0) startPlay();
      }
      if (flashT > 0) flashT -= rdt;
      if (guest) {
        guestPlayers(rdt, now);
        if (W.R.ph === 'fly' || W.R.ph === 'dead' || W.R.toss) {
          const s = me();
          if (s >= 0 && W.R.ph === 'fly') { if (W.planT < 0 || W.t - W.planT > 0.08) refreshPlans(W, null); W.pl[s].vol = !!(W.plan[s] && W.plan[s].pre && !W.plan[s].out); }
          // local ball (+ my own predicted hit)
          const hs0 = s >= 0 ? W.hn[s] : 0;
          simulateGuest(gdt, s);
          if (s >= 0 && W.hn[s] !== hs0) pred = { s, until: now + 450 };
          reconcile(rdt, now);
        } else { reconcile(rdt, now); }
        W.t += gdt;
      } else {
        const R = W.R;
        if (vph === 'play') {
          if (R.ph === 'fly' && (W.planT < 0 || W.t - W.planT > 0.08)) refreshPlans(W, reactOf);
          for (let s = 0; s < W.np; s++) {
            if (aiCtl(s)) aiThink(W, s, mem[s], DIFF[P(s).ai ? lvOf(s) : 2], gdt, !!st.f, hooks);
            else assist(W, s, mem[s], localHuman(s) ? moveAxis() : remAx[s], gdt);
          }
          // serve clock: a human server who never serves gets an automatic one
          if (R.ph === 'srv' && !aiCtl(R.srv) && !R.toss) {
            srvWait += pdt;
            const lim = 20;
            if (srvWait > lim) { srvWait = 0; W.pl[R.srv].cmd = humanCmd(W, R.srv, 3, 0, 0.45, 1); if (toss(W, R.srv)) hooks.toss(1); flash('시간이 지나 자동으로 서브했어요'); }
          } else srvWait = 0;
        } else if (vph === 'ready') {
          for (const p of W.pl) { p.tx = p.fx; p.ty = p.fy; p.max = 8; }
        } else {
          for (const p of W.pl) { p.tx = p.x + p.vx * 0.15; p.ty = p.y + p.vy * 0.15; }
        }
        pendingPt = null;
        simulate(W, Math.min(gdt, 0.2), { live: vph === 'play', hooks });
        if (pendingPt) { const r = pendingPt; pendingPt = null; decide(r); }
      }
      if (W.R.ph === 'fly' || W.R.ph === 'dead') { trail.push(W.b.x, W.b.y, W.b.z); if (trail.length > 21) trail.splice(0, 3); } else trail.length = 0;
      for (let i = fx.length - 1; i >= 0; i--) {
        const f = fx[i]; f.t += pdt;
        if (f.sp || f.dust) { f.x += f.vx * pdt; f.y += f.vy * pdt; f.z = Math.max(0, f.z + f.vz * pdt); f.vz -= 6 * pdt; }
        if (f.t >= f.life) fx.splice(i, 1);
      }
      for (let i = marks.length - 1; i >= 0; i--) { marks[i].t += pdt; if (marks[i].t > marks[i].life) marks.splice(i, 1); }
      for (let i = spark.length - 1; i >= 0; i--) { const s = spark[i]; if (s.d > 0) s.d -= pdt; else { s.t += pdt; if (s.t > 0.18) spark.splice(i, 1); } }
      if (banner) { banner.life -= pdt; if (banner.life <= 0) banner = null; }
      shake = Math.max(0, shake - rdt * 2.5);
      if (charge && W.R.ph === 'fly' && now - (charge.last || 0) > 120) { charge.last = now; commitCharge(false); }
      publish(rdt);
    }
    /* guest: ball flies locally; my own swing is predicted (the host confirms it) */
    function simulateGuest(gdt, s) {
      const n = Math.min(240, Math.max(1, Math.ceil(gdt / SUB))), h = gdt / n, R = W.R, ctl = { live: false, hooks: { bounce: hooks.bounce, net: hooks.net, hit: hooks.hit }, allow: (x) => x === s };
      for (let i = 0; i < n; i++) {
        if (R.ph === 'srv') { if (R.toss) { W.b.vz -= G * h; W.b.z += W.b.vz * h; } continue; }
        const e = stepBall(W.b, h, W.sf);
        if (e) handleEv(W, e, ctl);
        if (R.ph === 'fly' && s >= 0 && vph === 'play' && !(pred && performance.now() < pred.until)) tryHits(W, ctl);
      }
    }

    /* ----- drawing ----- */
    const SKIN = ['#e0b48c', '#c98e62', '#f0c9a2', '#8a5a3c'], HAIR = ['#2a1d14', '#5a3a1f', '#1a1a22', '#a0703a'];
    function drawPlayer(s) {
      const p = W.pl[s], col = P(s).color || '#ccc', near = p.team === viewT;
      const o = proj(p.x, p.y, 0, T1), top = proj(p.x, p.y, 1.8, T2);
      const k = o.k * 1.3, u = (o.y - top.y) / 1.8 * 1.3, fx0 = o.x, fy0 = o.y;   // sprites drawn a bit larger than life so they read on a phone
      if (k < 2) return;
      const spd = Math.hypot(p.vx, p.vy), ph = p.run * 3.1, stride = Math.min(1, spd / 4) * Math.sin(ph);
      const R = W.R, serving = R.ph === 'srv' && R.srv === s, tossing = serving && R.toss;
      const hand = near ? 1 : -1;                 // screen side of the right hand
      const crouch = (p.cmd || p.rdy) && !serving ? 0.08 : 0;
      // shadow + seat ring
      ctx.save(); ctx.globalAlpha = 0.3; ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(fx0 + 0.15 * k, fy0 + 0.04 * u, 0.42 * k, 0.16 * k, 0, 0, 7); ctx.fill(); ctx.restore();
      if (mine(s)) { ctx.strokeStyle = hexA(col, 0.85); ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(fx0, fy0, 0.55 * k, 0.2 * k, 0, 0, 7); ctx.stroke(); }
      const hipY = fy0 - (0.88 - crouch) * u;
      // legs
      ctx.lineCap = 'round'; ctx.strokeStyle = SKIN[s % 4]; ctx.lineWidth = Math.max(2, 0.12 * k);
      for (const sd of [-1, 1]) {
        const lift = Math.max(0, stride * sd) * 0.14 * u;
        ctx.beginPath(); ctx.moveTo(fx0 + sd * 0.1 * k, hipY); ctx.lineTo(fx0 + sd * (0.16 + Math.abs(stride) * 0.06) * k, fy0 - lift - 0.06 * u); ctx.stroke();
      }
      ctx.fillStyle = '#f4f1e8';
      for (const sd of [-1, 1]) { const lift = Math.max(0, stride * sd) * 0.14 * u; ctx.beginPath(); ctx.ellipse(fx0 + sd * (0.17 + Math.abs(stride) * 0.06) * k, fy0 - lift - 0.04 * u, 0.09 * k, 0.05 * k + 1, 0, 0, 7); ctx.fill(); }
      // shorts + shirt
      ctx.fillStyle = s % 2 ? '#e9e4d8' : '#2a2338';
      rr(ctx, fx0 - 0.2 * k, hipY - 0.06 * u, 0.4 * k, 0.24 * u, 0.05 * k); ctx.fill();
      const sh = ctx.createLinearGradient(fx0 - 0.25 * k, 0, fx0 + 0.25 * k, 0);
      sh.addColorStop(0, shade(col, -0.25)); sh.addColorStop(0.5, shade(col, 0.12)); sh.addColorStop(1, shade(col, -0.3));
      ctx.fillStyle = sh; rr(ctx, fx0 - 0.23 * k, hipY - 0.58 * u, 0.46 * k, 0.56 * u, 0.12 * k); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.fillRect(fx0 - 0.23 * k, hipY - 0.36 * u, 0.46 * k, Math.max(1, 0.04 * u));
      const shY = hipY - 0.52 * u, headY = hipY - 0.74 * u, hr = Math.max(2, 0.13 * (k + u) / 2);
      // racket arm pose
      let hx, hy, ang;
      const swing = p.sw > 0 ? clamp(p.sw / 0.26, 0, 1) : -1;
      const side = hand * (p.swS || 1);
      if (tossing || (serving && swing < 0)) {
        hx = fx0 + hand * 0.3 * k; hy = shY - (tossing ? 0.12 : -0.2) * u; ang = tossing ? -Math.PI / 2 + hand * 0.45 : -Math.PI * 0.3;   // trophy pose while the ball is up
        // toss arm up
        ctx.strokeStyle = SKIN[s % 4]; ctx.lineWidth = Math.max(1.5, 0.08 * k);
        ctx.beginPath(); ctx.moveTo(fx0 - hand * 0.2 * k, shY); ctx.lineTo(fx0 - hand * 0.25 * k, tossing ? shY - 0.55 * u : shY + 0.25 * u); ctx.stroke();
      } else if (swing >= 0 && (p.swK === 3 || p.swK === 4)) {
        const a = -Math.PI * 0.55 + swing * Math.PI * 1.25;   // over the top and down across
        hx = fx0 + hand * (0.25 - swing * 0.5) * k; hy = shY - (0.45 - swing * 0.8) * u; ang = a * hand;
      } else if (swing >= 0) {
        const lowToHigh = p.swK === 1 ? -1 : 1;               // slice comes down, topspin goes up
        hx = fx0 + side * (0.55 - swing * 1.0) * k; hy = shY + (0.3 - swing * 0.45 * lowToHigh - (lowToHigh < 0 ? 0.3 : 0)) * u;
        ang = (side > 0 ? 0 : Math.PI) - side * swing * 2.2 * (near ? 1 : -1) - Math.PI / 2 * swing;
      } else if (p.cmd || p.rdy) {
        hx = fx0 + side * 0.6 * k; hy = shY + 0.28 * u; ang = side > 0 ? 0.3 : Math.PI - 0.3;
      } else {
        hx = fx0 + hand * 0.3 * k; hy = shY + 0.38 * u; ang = -Math.PI / 2 + hand * 0.25;
      }
      const drawRacket = () => {
        ctx.strokeStyle = SKIN[s % 4]; ctx.lineWidth = Math.max(1.5, 0.08 * k);
        ctx.beginPath(); ctx.moveTo(fx0 + hand * 0.2 * k, shY); ctx.lineTo(hx, hy); ctx.stroke();
        const L1 = 0.26 * k, cx = hx + Math.cos(ang) * (L1 + 0.17 * k), cy = hy + Math.sin(ang) * (L1 + 0.17 * k);
        ctx.strokeStyle = '#2a2430'; ctx.lineWidth = Math.max(1.2, 0.045 * k);
        ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx + Math.cos(ang) * L1, hy + Math.sin(ang) * L1); ctx.stroke();
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang);
        ctx.beginPath(); ctx.ellipse(0, 0, 0.18 * k, 0.13 * k, 0, 0, 7);
        ctx.fillStyle = 'rgba(240,236,220,.28)'; ctx.fill();
        ctx.strokeStyle = shade(col, -0.35); ctx.lineWidth = Math.max(1.2, 0.04 * k); ctx.stroke();
        ctx.restore();
      };
      const racketBehind = !near && swing < 0;
      if (racketBehind) drawRacket();
      // off arm
      if (!(tossing || serving)) {
        ctx.strokeStyle = SKIN[s % 4]; ctx.lineWidth = Math.max(1.5, 0.08 * k);
        ctx.beginPath(); ctx.moveTo(fx0 - hand * 0.2 * k, shY); ctx.lineTo(fx0 - hand * 0.3 * k, shY + 0.32 * u); ctx.stroke();
      }
      // head (back of the head for my side, face for the far side)
      ctx.fillStyle = near ? HAIR[s % 4] : SKIN[s % 4];
      ctx.beginPath(); ctx.arc(fx0, headY, hr, 0, 7); ctx.fill();
      if (!near) { ctx.fillStyle = HAIR[s % 4]; ctx.beginPath(); ctx.arc(fx0, headY - hr * 0.15, hr, Math.PI, 0); ctx.fill(); }
      ctx.fillStyle = col; ctx.fillRect(fx0 - hr, headY - hr * 0.45, hr * 2, Math.max(1, hr * 0.32)); // headband
      if (!racketBehind) drawRacket();
      if (mine(s)) {
        ctx.fillStyle = hexA(col, 0.95);
        ctx.beginPath(); ctx.moveTo(fx0, headY - hr - 6); ctx.lineTo(fx0 - 6, headY - hr - 14); ctx.lineTo(fx0 + 6, headY - hr - 14); ctx.closePath(); ctx.fill();
      }
    }
    function drawNet() {
      const n = 14;
      ctx.beginPath();
      for (let i = 0; i <= n; i++) { const x = -NETX + (2 * NETX) * i / n, o = proj(x, 0, netH(x), T1); if (i) ctx.lineTo(o.x, o.y); else ctx.moveTo(o.x, o.y); }
      for (let i = n; i >= 0; i--) { const x = -NETX + (2 * NETX) * i / n, o = proj(x, 0, 0, T1); ctx.lineTo(o.x, o.y); }
      ctx.closePath(); ctx.fillStyle = 'rgba(14,12,20,.5)'; ctx.fill();
      ctx.strokeStyle = 'rgba(230,226,215,.16)'; ctx.lineWidth = 1; ctx.beginPath();
      for (let x = -NETX; x <= NETX + 1e-6; x += 0.4) { const a = proj(x, 0, 0, T1), b = proj(x, 0, netH(x), T2); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
      for (let z = 0.2; z < NETC; z += 0.22) { const a = proj(-NETX, 0, z, T1), b = proj(NETX, 0, z, T2); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
      ctx.stroke();
      ctx.strokeStyle = '#f4f1e8'; ctx.lineWidth = Math.max(2, 0.07 * proj(0, 0, NETC, T1).k); ctx.beginPath();
      for (let i = 0; i <= n; i++) { const x = -NETX + (2 * NETX) * i / n, o = proj(x, 0, netH(x), T1); if (i) ctx.lineTo(o.x, o.y); else ctx.moveTo(o.x, o.y); }
      ctx.stroke();
      for (const sx of [-1, 1]) {
        const a = proj(sx * (NETX + 0.05), 0, 0, T1), b = proj(sx * (NETX + 0.05), 0, NETP + 0.05, T2);
        ctx.strokeStyle = '#1f3a32'; ctx.lineWidth = Math.max(2.5, 0.1 * a.k); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      }
    }
    function drawBallShadow() {
      const b = W.b, o = proj(b.x, b.y, 0, T1), hgt = Math.max(0, b.z);
      const r = Math.max(2.5, 0.09 * o.k) * (1 + hgt * 0.15);
      ctx.save(); ctx.globalAlpha = clamp(0.5 - hgt * 0.08, 0.15, 0.5); ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(o.x, o.y, r * 1.2, r * 0.6, 0, 0, 7); ctx.fill(); ctx.restore();
    }
    function drawBall() {
      const b = W.b;
      for (let i = 0; i + 2 < trail.length; i += 3) {
        const o = proj(trail[i], trail[i + 1], trail[i + 2], T1), a = (i / 3 + 1) / (trail.length / 3);
        ctx.beginPath(); ctx.arc(o.x, o.y, Math.max(1.5, 0.07 * o.k) * a, 0, 7); ctx.fillStyle = 'rgba(225,245,120,' + (0.22 * a) + ')'; ctx.fill();
      }
      const o = proj(b.x, b.y, b.z, T1), r = Math.max(3, 0.09 * o.k);
      ctx.beginPath(); ctx.arc(o.x, o.y, r * 1.9, 0, 7); ctx.fillStyle = 'rgba(230,255,120,.16)'; ctx.fill();
      const g = ctx.createRadialGradient(o.x - r * 0.35, o.y - r * 0.4, 0.5, o.x, o.y, r);
      g.addColorStop(0, '#fbffc8'); g.addColorStop(1, '#c9e23a');
      ctx.beginPath(); ctx.arc(o.x, o.y, r, 0, 7); ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(60,70,10,.55)'; ctx.lineWidth = 1; ctx.stroke();
    }
    function drawMarks() {
      for (const m of marks) {
        const o = proj(m.x, m.y, 0, T1), a = m.life > 50 ? 0.55 : clamp(1 - m.t / m.life, 0, 1);
        ctx.save(); ctx.globalAlpha = a;
        if (m.out) {
          const pulse = 1 + 0.15 * Math.sin(m.t * 12);
          ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(o.x, o.y, 0.5 * o.k * pulse, 0.22 * o.k * pulse, 0, 0, 7); ctx.stroke();
          ctx.font = '700 12px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#ee6a55';
          ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,8,16,.8)'; ctx.strokeText('아웃', o.x, o.y - 0.4 * o.k - 4); ctx.fillText('아웃', o.x, o.y - 0.4 * o.k - 4);
        } else {
          ctx.fillStyle = st && st.sf === 'c' ? 'rgba(120,50,25,.75)' : 'rgba(255,255,255,.5)';
          ctx.beginPath(); ctx.ellipse(o.x, o.y, 0.16 * o.k, 0.07 * o.k, 0, 0, 7); ctx.fill();
        }
        ctx.restore();
      }
    }
    /* my queued shot: where it is meant to land (+ how sure) and the predicted bounce of the incoming ball */
    function drawAim() {
      const s = me(); if (s < 0 || auto() || vph !== 'play') return;
      const p = W.pl[s], f = fw(p.team);
      if (W.pb && W.R.ph === 'fly' && W.R.ht !== p.team) {
        const o = proj(W.pb.x, W.pb.y, 0, T1);
        ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.ellipse(o.x, o.y, 0.35 * o.k, 0.15 * o.k, 0, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      const c = myCmd;
      if (!c || !fin(c.ia)) return;
      const tx = c.ia * f, ty = c.id * f, o = proj(tx, ty, 0, T1);
      const n = GN[c.g] || GN[1], hw = W.hw[1 - p.team];
      const sgB = W.sd === 0 ? -1 : 1;
      const out = c.k === 3 ? !(c.ia * sgB >= -0.05 && c.ia * sgB <= WS + 0.05 && c.id <= SL + 0.03) : (Math.abs(c.ia) > hw + 0.05 || c.id > HL + 0.03);
      const colr = out ? '#ee6a55' : '#e3ae45';
      ctx.save();
      ctx.strokeStyle = colr; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(o.x, o.y, Math.max(6, (n[0] + 0.25) * o.k), Math.max(3, (n[1] + 0.2) * o.k * 0.45), 0, 0, 7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(o.x - 5, o.y); ctx.lineTo(o.x + 5, o.y); ctx.moveTo(o.x, o.y - 4); ctx.lineTo(o.x, o.y + 4); ctx.stroke();
      ctx.font = '700 11px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      const lab = (KIND_KO[c.k] || '') + (out ? ' · 아웃 위험' : '');
      ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,8,16,.85)'; ctx.strokeText(lab, o.x, o.y - Math.max(5, n[1] * o.k * 0.45) - 3);
      ctx.fillStyle = colr; ctx.fillText(lab, o.x, o.y - Math.max(5, n[1] * o.k * 0.45) - 3);
      ctx.restore();
    }
    function drawFx() {
      for (const f of fx) {
        const o = proj(f.x, f.y, f.z, T1), a = 1 - f.t / f.life;
        if (f.ring) { ctx.beginPath(); ctx.arc(o.x, o.y, 4 + (f.t / f.life) * (f.big ? 30 : 18), 0, 7); ctx.strokeStyle = hexA(f.col, 0.8 * a); ctx.lineWidth = f.big ? 3 : 2; ctx.stroke(); }
        else if (f.sp || f.dust) { ctx.beginPath(); ctx.arc(o.x, o.y, f.dust ? Math.max(1.5, 0.08 * o.k) : 2, 0, 7); ctx.fillStyle = f.col.charAt(0) === '#' ? hexA(f.col, a) : f.col; ctx.fill(); }
        else if (f.txt) {
          ctx.save(); ctx.globalAlpha = clamp(a * 1.5, 0, 1);
          ctx.font = (f.sm ? '700 12px "IBM Plex Mono", ui-monospace, monospace' : '18px "Black Han Sans", sans-serif'); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          const y = o.y - (f.t / f.life) * 16;
          ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,8,16,.85)'; ctx.strokeText(f.txt, o.x, y); ctx.fillStyle = f.col; ctx.fillText(f.txt, o.x, y);
          ctx.restore();
        }
      }
      for (const s of spark) {
        if (s.d > 0 || !s.q) continue;
        const o = proj(s.q[0], s.q[1], s.q[2] + 0.4, T1);
        ctx.fillStyle = 'rgba(255,255,240,' + (1 - s.t / 0.18) + ')'; ctx.beginPath(); ctx.arc(o.x, o.y, 2.2, 0, 7); ctx.fill();
      }
    }
    function drawScore() {
      if (!st) return;
      const pad = 8, w = Math.min(200, Math.round(cv.w * 0.54)), rh = 22, h = rh * 2 + 8;
      const srvT = teamOf(server(st));
      ctx.save();
      rr(ctx, pad, pad, w, h, 10); ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.35)'; ctx.lineWidth = 1; ctx.stroke();
      const rows = [1 - viewT, viewT];
      rows.forEach((t, i) => {
        const y = pad + 4 + i * rh + rh / 2;
        if (srvT === t && st.ph !== 'done') { ctx.beginPath(); ctx.arc(pad + 10, y, 4, 0, 7); ctx.fillStyle = '#d6ec58'; ctx.fill(); }
        const mem2 = teamsOf(st.np)[t];
        mem2.forEach((s2, j) => { ctx.beginPath(); ctx.arc(pad + 22 + j * 9, y, 3.5, 0, 7); ctx.fillStyle = P(s2).color; ctx.fill(); });
        ctx.font = '600 12px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
        const nx = pad + 22 + mem2.length * 9, maxW = w - (nx - pad) - 62;
        let nm = teamName(st, t, 12);
        if (mem2.length === 1 && P(mem2[0]).ai) nm += ' ' + LV_KO[lvOf(mem2[0])];
        while (nm.length > 1 && ctx.measureText(nm).width > maxW) nm = nm.slice(0, -2) + '…';
        ctx.fillText(nm, nx, y + 1);
        ctx.font = '700 14px "IBM Plex Mono", ui-monospace, monospace'; ctx.textAlign = 'center';
        ctx.fillStyle = '#e3ae45'; ctx.fillText(String(st.g[t]), pad + w - 44, y + 1);
        rr(ctx, pad + w - 30, y - 9, 24, 18, 5); ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.fillText(ptText(st, t), pad + w - 18, y + 1);
      });
      // status chips (top right)
      const chips = [MODE[st.md] + ' · ' + (SURF[st.sf] || SURF.h).name];
      if (st.tb && st.md !== 'tb') chips.push('타이브레이크');
      if (st.f && st.ph !== 'done') chips.push('세컨드 서브');
      const pr = pressureCache();
      if (pr) chips.push(pr.txt);
      ctx.font = '600 11px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      chips.forEach((t, i) => {
        const tw = ctx.measureText(t).width + 14, x1 = cv.w - pad, y = pad + 9 + i * 20;
        rr(ctx, x1 - tw, y - 9, tw, 18, 9);
        const hot = pr && t === pr.txt;
        ctx.fillStyle = hot ? hexA(P(teamsOf(st.np)[pr.t][0]).color, 0.9) : 'rgba(23,19,31,.8)'; ctx.fill();
        ctx.fillStyle = hot ? '#17131f' : '#ab9fb8'; ctx.fillText(t, x1 - 7, y + 1);
      });
      ctx.restore();
    }
    let prC = { k: null, v: null };
    function pressureCache() { const k = curKey(); if (prC.k !== k) { prC = { k, v: pressure(st) }; } return prC.v; }
    function centerText(lines, cy) {
      const cx = cv.w / 2;
      for (const ln of lines) {
        ctx.font = ln.f; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(10,8,16,.85)'; ctx.strokeText(ln.t, cx, cy + ln.y);
        ctx.fillStyle = ln.c || '#f2e9d8'; ctx.fillText(ln.t, cx, cy + ln.y);
      }
    }
    function hintText() {
      const s = me(); if (s < 0 || auto() || !W) return null;
      if (flashT > 0 && hintFlash) return hintFlash;
      if (vph !== 'play') return null;
      const R = W.R, p = W.pl[s];
      if (R.ph === 'srv') {
        if (R.srv === s) {
          if (kbUsed) return R.toss ? '떼면 서브!' : 'J(스페이스)를 누르면 토스 → 떼면 서브';
          return R.toss ? '지금 위로 쓸어 서브!' : '탭해서 토스 → 위로 쓸어 서브 · ◀ ▶ 위치';
        }
        return s === R.rcv ? name(R.srv) + ' 서브 — 튀면 쳐요' : name(R.srv) + ' 서브';
      }
      if (R.ph === 'fly' && R.ht !== p.team && W.tk[p.team] === s && !myCmd && !p.cmd) {
        if (kbUsed) return 'J 탑스핀 · K 슬라이스 · L 로브 (← → 방향)';
        return hintN < 5 ? '↑ 쓸면 탑스핀 · ↓ 슬라이스 · 탭 로브' : '쓸어서 쳐요!';
      }
      return null;
    }
    let lastHint = null;
    function draw() {
      if (!cam || !W) return;
      cv.clear();
      ctx.save();
      if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 6, (Math.random() - 0.5) * shake * 6);
      if (bg) ctx.drawImage(bg, 0, 0, cv.w, cv.h);
      drawMarks();
      drawAim();
      drawBallShadow();
      // depth sort: far → near (players, ball, net)
      const items = [];
      for (let s = 0; s < W.np; s++) items.push({ d: viewY(W.pl[s].y) + 0.01, s });
      items.push({ d: viewY(W.b.y), ball: 1 });
      items.push({ d: 0, net: 1 });
      items.sort((a, b) => b.d - a.d);
      for (const it of items) { if (it.net) drawNet(); else if (it.ball) drawBall(); else drawPlayer(it.s); }
      drawFx();
      ctx.restore();
      drawScore();
      // banner over the net
      if (banner && st) {
        const cy = proj(0, 0, 1.2, T1).y, fz = Math.round(clamp(cv.w * 0.11, 30, 52));
        const a = clamp(banner.life * 3, 0, 1);
        ctx.save(); ctx.globalAlpha = a;
        centerText([{ t: banner.t, f: fz + 'px "Black Han Sans", sans-serif', y: -fz * 0.25, c: banner.col },
          { t: banner.sub || '', f: '700 ' + Math.round(fz * 0.34) + 'px "IBM Plex Sans KR", sans-serif', y: fz * 0.5 }], cy);
        ctx.restore();
      }
      // hint pill between the ◀ ▶ buttons
      const ht = hintText();
      if (ht !== lastHint) { if (lastHint && /쓸면 탑스핀/.test(lastHint) && !ht) hintN++; lastHint = ht; }
      if (ht) {
        ctx.save(); ctx.font = '600 12.5px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const maxW = cv.w - 150, lines = wrap(ht, maxW), lh = 16, hh = lines.length * lh + 12, w = Math.min(maxW, Math.max(...lines.map((l) => ctx.measureText(l).width))) + 22;
        const y = cv.h - 39;
        rr(ctx, cv.w / 2 - w / 2, y - hh / 2, w, hh, 14); ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.fill();
        ctx.strokeStyle = 'rgba(227,174,69,.3)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = '#f2e9d8'; lines.forEach((l, i) => ctx.fillText(l, cv.w / 2, y - (lines.length - 1) * lh / 2 + i * lh + 1));
        ctx.restore();
      }
    }
    function wrap(t, maxW) {
      if (ctx.measureText(t).width <= maxW) return [t];
      const words = t.split(' '), out = []; let cur = '';
      for (const w of words) { const n = cur ? cur + ' ' + w : w; if (ctx.measureText(n).width > maxW && cur) { out.push(cur); cur = w; } else cur = n; }
      if (cur) out.push(cur);
      return out.slice(0, 3);
    }

    const stopLoop = U.loop((rdt, now) => {
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); } catch (e) { console.error(e); }
      try { draw(); } catch (e) { console.error(e); }
    });
    cv.onresize = layout;

    return {
      update(next) {
        if (!next) return;
        const first = !st;
        const prevSf = st && st.sf;
        st = next;
        const m = me(), nt = m >= 0 ? teamOf(m) : 0;
        if (first || nt !== viewT || prevSf !== st.sf) { viewT = nt; layout(); }
        showBtns();
        const k = curKey();
        if (k !== key) { key = k; onNewKey(next, first); }
      },
      destroy() {
        stopLoop();
        if (busy) { busy = false; try { api.setBusy(false); } catch (e) {} }
        if (offIn) offIn();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onCancel);
        cv.cv.removeEventListener('contextmenu', noCtx);
        btns.forEach((b) => b.remove());
        cv.destroy();
      },
      _dbg: () => ({ W, vph, st, cam, myCmd, input, flip, pred, layout }),
    };
  }

  /* ---------- drawing helpers ---------- */
  function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'tennis', name: '테니스 랠리', tag: '실시간 스포츠', cat: '스포츠',
    blurb: '선수는 알아서 공을 쫓아가요 — 화면을 쓸어서 치기만 하면 돼요. 정식 테니스 점수(15·30·40·듀스), 단식·복식. 혼자면 AI와, 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#2a4f7a',
    icon: '<ellipse cx="22" cy="22" rx="12" ry="15" transform="rotate(-40 22 22)" fill="none" stroke="currentColor" stroke-width="3.5"/><path d="M15 14l14 14M12 21l11 11M20 11l11 11" stroke="currentColor" stroke-width="1.6" opacity=".55"/><path d="M31 32l13 13" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><circle cx="43" cy="15" r="7" fill="currentColor"/><path d="M37 12c4 3 8 3 12 0M37 18c4-3 8-3 12 0" stroke="#2a4f7a" stroke-width="1.6" fill="none"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'len', label: '경기 길이', choices: [{ v: 'tb', label: '타이브레이크' }, { v: 's4', label: '짧은 세트(4게임)' }, { v: 's6', label: '정식 세트(6게임)' }], def: 'tb' },
      { id: 'sf', label: '코트', choices: [{ v: 'rand', label: '무작위' }, { v: 'h', label: '하드' }, { v: 'c', label: '클레이' }, { v: 'g', label: '잔디' }], def: 'rand' },
    ],
    controls: [
      { id: 'left', label: '왼쪽으로 이동 · 왼쪽 겨냥', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 이동 · 오른쪽 겨냥', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'drive', label: '탑스핀 · 서브 (길게 누를수록 세게)', keys: ['KeyJ', 'Space'], pad: ['a', 'rt'] },
      { id: 'slice', label: '슬라이스', keys: ['KeyK'], pad: ['x', 'lt'] },
      { id: 'lob', label: '로브', keys: ['KeyL'], pad: ['y'] },
    ],
    quick: [
      '선수는 알아서 공을 쫓아가요. 공이 내 쪽으로 오면 화면을 쓸어서 쳐요.',
      '위로 쓸면 탑스핀, 아래로 쓸면 슬라이스, 톡 탭하면 로브. 쓰는 방향이 겨냥이에요.',
      '공을 상대 코트 안에 넣어 점수를 따요. 기본은 타이브레이크 한 판 — 7점 먼저(2점 차) 따면 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '테니스 경기예요. 공을 네트 너머 상대 코트 안에 넣고, 상대가 못 받아 넘기면 내 점수예요.',
        '내 코트는 화면에서 항상 아래쪽이에요.',
        '경기 길이(설정): 타이브레이크 한 판(기본) / 짧은 세트(4게임) / 정식 세트(6게임).',
      ] },
      { h: '조작 (터치)', p: [
        '달리기는 자동: 선수는 공을 향해 알아서 달려가요. ◀ ▶ 버튼으로 위치를 조금씩 옮길 수 있어요.',
        '치기: 공이 내 쪽으로 오면 화면 아무 데나 쓸어요. 위로 쓸면 탑스핀(빠르고 묵직), 아래로 쓸면 슬라이스(느리고 낮게 깔려요), 톡 탭하면 로브(높이 넘겨요).',
        '겨냥: 쓰는 방향이 곧 겨냥이에요. 비스듬히 쓸수록 옆줄 쪽으로 가요. 빠르게 쓸수록 세고 깊게 날아가요. 너무 세면 아웃!',
        '노란 표시가 공이 떨어질 곳이에요(빨간색이면 아웃 위험).',
        '타이밍: 공이 오기 직전에 쓸면 「완벽!」 — 더 빠르고 정확해요. 너무 일찍 쓸면 약해지고 흔들리며, 늦으면 옆으로 빗나가요. 공이 닿기 전이면 다시 쓸어서 바꿀 수 있어요.',
        '서브: 화면을 탭해 공을 띄우고, 공이 꼭대기에 있을 때 위로 쓸어요. 쓰는 방향으로 박스 안쪽(가운데)이나 바깥쪽을 노려요. 서브 전에 ◀ ▶로 서는 자리를 옮길 수 있어요.',
        'PC: ← → 이동, J(스페이스) 탑스핀·서브, K 슬라이스, L 로브. 길게 누를수록 세게, 누른 채 ← → 로 방향. 서브는 J를 누르면 토스, 떼면 서브. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '점수 · 승리', p: [
        '한 게임: 0 → 15 → 30 → 40 → 게임. 40:40은 듀스 — 다음 한 점을 따면 어드밴티지, 이어서 한 점 더 따면 게임이에요(어드밴티지에서 잃으면 다시 듀스).',
        '타이브레이크: 1, 2, 3… 으로 세고 7점을 먼저 따되 2점 차가 나야 이겨요.',
        '짧은 세트는 4게임, 정식 세트는 6게임을 먼저 따면 이겨요. 세트는 2게임 차가 나야 끝나고, 4:4(정식은 6:6)이면 타이브레이크로 정해요.',
      ] },
      { h: '서브 규칙', p: [
        '한 게임은 같은 사람이 계속 서브하고, 게임마다 상대와 번갈아요(복식은 네 명이 차례로). 타이브레이크는 첫 1점 뒤 2점마다 바뀌어요.',
        '오른쪽(듀스)과 왼쪽(애드)에서 번갈아, 대각선 맞은편 서비스 박스에 넣어야 해요.',
        '박스 밖에 떨어지거나 네트에 걸리면 폴트 — 한 번 더 넣을 수 있어요. 두 번 연속 폴트(더블 폴트)면 상대 득점. 네트에 스치고 박스에 들어가면 렛(다시 서브).',
        '서브는 꼭 한 번 튄 뒤에 받아야 해요(복식은 정해진 받는 사람만).',
        '서브를 20초 넘게 안 하면 자동으로 약하게 서브해요.',
      ] },
      { h: '랠리 규칙', p: [
        '상대 코트 안에 떨어지게 넘기면 돼요. 선에 닿아도 인이에요.',
        '내 쪽에서 두 번 튀기 전에 쳐야 해요. 튀기 전에 바로 치는 발리도 돼요.',
        '아웃(코트 밖), 네트, 두 번 튐이면 상대 득점.',
        '복식은 바깥 복도까지 코트예요. 3명이면 2 대 1: 혼자인 사람은 넓은 복식 코트로, 두 명 팀은 좁은 단식 코트 안으로 쳐야 해요.',
      ] },
      { h: '팁', p: [
        '세게보다 정확하게! 노란 표시가 선 안쪽에 있는지 보고 쳐요.',
        '공이 오기 직전에 쓸어야 「완벽!」이 떠요. 조금 기다렸다 쓸어 보세요.',
        '상대가 네트 앞에 붙으면 로브(톡)로 머리 위를 넘겨요. 깊이 물러나 있으면 슬라이스로 짧게 떨어뜨려요.',
      ] },
      { h: '예시', p: [
        '한 게임: 내가 1점(15:0) → 1점(30:0) → 상대 1점(30:15) → 내가 1점(40:15) → 한 점 더 따면 게임!',
        '40:40 듀스라면: 내가 1점(어드밴티지) → 상대 1점(다시 듀스) → 내가 2점 연속 → 게임.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지는 AI예요. 친구와는 온라인·LAN 방에서 각자 폰으로 해요(2~4명). 4명이면 1·3번 대 2·4번 복식이에요.',
        '화면은 늘 내 코트가 아래예요. 그래서 실제 경기의 코트 바꾸기(홀수 게임마다)는 생략해요 — 바람·햇빛이 없어서 결과는 같아요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(달리기 속도, 반응, 코스 공략, 실수가 달라요).',
        '코트: 하드(보통), 클레이(공이 느리고 높게 튀어요), 잔디(빠르고 낮게 깔려요). 기본은 무작위예요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { server, receiver, courtSide, point, fault, let_, ptText, pressure, stepBall, flyTo, aimBall, shotOf, serveOf, canHit, refBounce, refDead,
      newWorld, resetPoint, toss, simulate, predict, planFor, refreshPlans, aiThink, assist, humanCmd, home, humanReact, DIFF, C, HL, WS, WD, SL, TS, SURF, teamsOf },
  });
})();
