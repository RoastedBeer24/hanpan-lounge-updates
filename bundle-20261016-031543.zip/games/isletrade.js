/* 개척섬 교역 — 육각 섬에 마을을 세우고, 주사위가 나온 땅에서 자원을 받아 길·마을·도시를 짓는 교역 게임.
   (독자 설계: 자원 5종 나무·흙·솜·쌀·철, 판마다 새 섬 모양, 계절(제철 +1), 바다 무역선, 가뭄 표지(숫자에 놓음),
    의뢰 카드(자원 납품 → 점수), 교역왕(다른 사람과 교환 3번 이상 · 가장 많이)) */
(function () {
  const L = window.Lounge, U = L.util;

  /* ======================= data ======================= */
  const RN = ['나무', '흙', '솜', '쌀', '철'];
  const TN = ['숲', '진흙밭', '목화밭', '논', '철광산'];
  const TCOL = ['#2f6d36', '#a4552f', '#cfc6a6', '#c9a33a', '#5f6b7c'];
  const SN = ['봄', '여름', '가을', '겨울'], SE = ['🌸', '☀️', '🍂', '❄️'];
  const SR = [2, 3, 0, 4];               // 제철 자원: 봄 솜 · 여름 쌀 · 가을 나무 · 겨울 철
  const COST = { r: [1, 1, 0, 0, 0], s: [1, 1, 1, 1, 0], c: [0, 0, 0, 2, 3] };
  const LIM = { r: 15, s: 5, c: 4 };
  const BNM = { r: '길', s: '마을', c: '도시' };
  // 의뢰 카드: 자원을 바치면 점수
  const ORD = [
    { nm: '등대 수리', c: [1, 2, 0, 0, 2], v: 1 },
    { nm: '축제 준비', c: [1, 0, 2, 2, 0], v: 1 },
    { nm: '고깃배 건조', c: [3, 0, 2, 0, 0], v: 1 },
    { nm: '곡물 창고', c: [1, 1, 0, 3, 0], v: 1 },
    { nm: '대장간', c: [1, 1, 0, 0, 3], v: 1 },
    { nm: '목화 시장', c: [0, 0, 3, 2, 0], v: 1 },
    { nm: '돌다리', c: [0, 3, 0, 0, 2], v: 1 },
    { nm: '섬 학교', c: [2, 1, 1, 1, 0], v: 1 },
    { nm: '종탑', c: [0, 3, 2, 0, 3], v: 2 },
    { nm: '큰 잔치', c: [2, 0, 3, 3, 0], v: 2 },
    { nm: '조선소', c: [3, 2, 0, 0, 3], v: 2 },
    { nm: '왕실 선물', c: [2, 0, 2, 2, 2], v: 2 },
    { nm: '천문대', c: [0, 2, 2, 2, 2], v: 2 },
    { nm: '항구 확장', c: [3, 2, 1, 0, 2], v: 2 },
  ];
  const TOK = [2, 3, 3, 4, 4, 5, 5, 6, 6, 8, 8, 9, 9, 10, 10, 11, 11, 12];
  const TILES = [0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4];
  const pips = (n) => (n ? 6 - Math.abs(7 - n) : 0);

  /* ======================= geometry (radius-3 hex grid, pointy top) ======================= */
  const SQ3 = Math.sqrt(3);
  const HX = [], HI = {};
  for (let r = -3; r <= 3; r++) for (let q = -3; q <= 3; q++) {
    if (Math.abs(q + r) > 3) continue;
    HI[q + ',' + r] = HX.length;
    HX.push({ q, r, x: SQ3 * (q + r / 2), y: 1.5 * r, d: Math.max(Math.abs(q), Math.abs(r), Math.abs(q + r)) });
  }
  const NH = HX.length;
  const DIRS = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];
  const HN = HX.map((o) => DIRS.map(([a, b]) => HI[(o.q + a) + ',' + (o.r + b)]).filter((i) => i != null));
  const VX = [], VH = [], HV = [], VE = [], EV = [], EH = [], VK = {}, EK = {};
  HX.forEach((o, hi) => {
    const vs = [];
    for (let i = 0; i < 6; i++) {
      const a = Math.PI / 180 * (60 * i - 30), x = o.x + Math.cos(a), y = o.y + Math.sin(a);
      const k = Math.round(x * 100) + ',' + Math.round(y * 100);
      let v = VK[k];
      if (v == null) { v = VK[k] = VX.length; VX.push({ x, y }); VH.push([]); VE.push([]); }
      VH[v].push(hi); vs.push(v);
    }
    HV.push(vs);
    for (let i = 0; i < 6; i++) {
      const a = vs[i], b = vs[(i + 1) % 6], k = Math.min(a, b) + '-' + Math.max(a, b);
      let e = EK[k];
      if (e == null) { e = EK[k] = EV.length; EV.push([a, b]); EH.push([]); VE[a].push(e); VE[b].push(e); }
      EH[e].push(hi);
    }
  });
  const NV = VX.length, NE = EV.length;
  const VN = VX.map((_, v) => VE[v].map((e) => (EV[e][0] === v ? EV[e][1] : EV[e][0])));

  /* ======================= board helpers ======================= */
  const isLand = (s, h) => s.mp[h] !== '.';
  const isRes = (s, h) => s.mp[h] >= '0' && s.mp[h] <= '4';
  const landV = (s, v) => VH[v].some((h) => isLand(s, h));
  const landE = (s, e) => EH[e].some((h) => isLand(s, h));
  const numOf = (s, h) => parseInt(s.nu[h], 36) || 0;
  function own(s, v) { const c = s.b.charCodeAt(v); if (c === 46) return -1; return c >= 97 ? c - 97 : c - 65; }
  const isCity = (s, v) => { const c = s.b.charCodeAt(v); return c >= 65 && c < 97; };
  const rOwn = (s, e) => (s.rd[e] === '.' ? -1 : +s.rd[e]);
  const setCh = (str, i, ch) => str.slice(0, i) + ch + str.slice(i + 1);
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  const canPay = (h, c) => c.every((x, i) => h[i] >= x);
  const pay = (h, c) => { for (let i = 0; i < 5; i++) h[i] -= c[i]; };
  const def = (c, h) => { let d = 0; for (let i = 0; i < 5; i++) d += Math.max(0, c[i] - h[i]); return d; };
  const seasonRes = (s) => SR[s.rnd % 4];

  function cnt(s, p) {
    let a = 0, c = 0, r = 0;
    const sc = 97 + p, cc = 65 + p, rc = String(p);
    for (let v = 0; v < NV; v++) { const k = s.b.charCodeAt(v); if (k === sc) a++; else if (k === cc) c++; }
    for (let e = 0; e < NE; e++) if (s.rd[e] === rc) r++;
    return { s: a, c, r };
  }
  function vp(s, p) { const c = cnt(s, p); return c.s + 2 * c.c + s.p[p].o + (s.ld === p ? 2 : 0); }

  function canSettle(s, p, v, setup) {
    if (v < 0 || v >= NV || s.b[v] !== '.' || !landV(s, v)) return false;
    if (VN[v].some((u) => s.b[u] !== '.')) return false;
    if (setup) return true;
    return VE[v].some((e) => rOwn(s, e) === p);
  }
  function settleSpots(s, p, setup) { const r = []; for (let v = 0; v < NV; v++) if (canSettle(s, p, v, setup)) r.push(v); return r; }
  function canRoad(s, p, e) {
    if (e < 0 || e >= NE || s.rd[e] !== '.' || !landE(s, e)) return false;
    return EV[e].some((v) => {
      const o = own(s, v);
      if (o === p) return true;
      if (o >= 0) return false;
      return VE[v].some((f) => f !== e && rOwn(s, f) === p);
    });
  }
  function roadSpots(s, p) { const r = []; for (let e = 0; e < NE; e++) if (canRoad(s, p, e)) r.push(e); return r; }
  function citySpots(s, p) { const r = []; for (let v = 0; v < NV; v++) if (s.b.charCodeAt(v) === 97 + p) r.push(v); return r; }
  function setupRoads(s) { return s.lv < 0 ? [] : VE[s.lv].filter((e) => s.rd[e] === '.' && landE(s, e)); }

  function rates(s, p) {
    const base = s.n === 2 ? 3 : 4, r = [base, base, base, base, base];
    for (const [e, t] of s.hb) {
      if (!EV[e].some((v) => own(s, v) === p)) continue;
      if (t === 5) for (let i = 0; i < 5; i++) r[i] = Math.min(r[i], 3);
      else r[t] = Math.min(r[t], 2);
    }
    r[s.sh] = Math.min(r[s.sh], 2);
    return r;
  }
  function prodP(s, p) {
    const r = [0, 0, 0, 0, 0];
    for (let h = 0; h < NH; h++) {
      if (!isRes(s, h)) continue;
      const n = numOf(s, h); if (n === s.dn) continue;
      for (const v of HV[h]) if (own(s, v) === p) r[+s.mp[h]] += pips(n) * (isCity(s, v) ? 2 : 1);
    }
    return r;
  }

  /* ======================= board generation ======================= */
  function genBoard(shape) {
    let land;
    if (shape === 'round') land = HX.map((o, i) => (o.d <= 2 ? i : -1)).filter((i) => i >= 0);
    else {
      const set = new Set([HI['0,0']]);
      while (set.size < 19) {
        const cand = [];
        for (let i = 0; i < NH; i++) {
          if (set.has(i)) continue;
          const k = HN[i].filter((j) => set.has(j)).length;
          if (k) cand.push([i, k * k + (shape === 'long' ? (Math.abs(HX[i].r) <= 1 ? 6 : 0) : 0)]);
        }
        let t = Math.random() * cand.reduce((a, c) => a + c[1], 0);
        for (const [i, w] of cand) { t -= w; if (t <= 0) { set.add(i); break; } }
        if (t > 0) set.add(cand[cand.length - 1][0]);
      }
      land = [...set];
    }
    const tiles = U.shuffle(TILES.concat(['v']));
    const mp = Array(NH).fill('.');
    land.forEach((h, i) => { mp[h] = String(tiles[i]); });
    const prodH = land.filter((h) => mp[h] !== 'v');
    let best = null;
    for (let tr = 0; tr < 600; tr++) {
      const tk = U.shuffle(TOK.slice());
      const nu = Array(NH).fill(0);
      prodH.forEach((h, i) => { nu[h] = tk[i]; });
      let ok = true;
      for (const h of prodH) {
        for (const j of HN[h]) {
          if (!nu[j]) continue;
          if (nu[j] === nu[h] || ((nu[h] === 6 || nu[h] === 8) && (nu[j] === 6 || nu[j] === 8))) { ok = false; break; }
        }
        if (!ok) break;
      }
      if (ok) {
        for (let r = 0; r < 5 && ok; r++) {
          const hs = prodH.filter((h) => +mp[h] === r);
          const avg = hs.reduce((a, h) => a + pips(nu[h]), 0) / hs.length;
          if (avg < 2.3 || avg > 4.2) ok = false;
        }
      }
      best = nu;
      if (ok) break;
    }
    // harbors on coastal edges
    const coast = [];
    for (let e = 0; e < NE; e++) {
      const lh = EH[e].filter((h) => mp[h] !== '.');
      if (lh.length !== 1) continue;
      const a = VX[EV[e][0]], b = VX[EV[e][1]];
      coast.push([e, Math.atan2((a.y + b.y) / 2, (a.x + b.x) / 2)]);
    }
    coast.sort((x, y) => x[1] - y[1]);
    const hb = [], used = new Set();
    const types = U.shuffle([5, 5].concat(U.shuffle([0, 1, 2, 3, 4]).slice(0, 4)));
    const step = coast.length / 6, off = Math.random() * step;
    for (let k = 0; k < 6; k++) {
      let idx = Math.floor(off + k * step) % coast.length;
      for (let tries = 0; tries < coast.length; tries++) {
        const e = coast[(idx + tries) % coast.length][0];
        const vs = EV[e];
        if (vs.some((v) => used.has(v) || VN[v].some((u) => used.has(u)))) continue;
        vs.forEach((v) => used.add(v));
        hb.push([e, types[k]]); break;
      }
    }
    return { mp: mp.join(''), nu: best.map((n) => n.toString(36)).join(''), hb };
  }

  /* ======================= logic ======================= */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    let shape = opts.map || 'rand';
    if (shape === 'rand') shape = ['round', 'wild', 'long'][U.rand(3)];
    const bd = genBoard(shape);
    const dk = U.shuffle(ORD.map((_, i) => i));
    const mk = dk.splice(0, 3);
    return {
      n, tg: +opts.goal || 10, nm: players.map((p) => String(p.name || '').slice(0, 8)),
      mp: bd.mp, nu: bd.nu, hb: bd.hb, b: '.'.repeat(NV), rd: '.'.repeat(NE),
      p: players.map(() => ({ h: [0, 0, 0, 0, 0], o: 0, oc: 0, x: 0 })),
      cur: 0, ph: 'S', so: 0, sp: 0, lv: -1, dn: 0, rnd: 0, sh: U.rand(5), tc: 0, tr: null,
      dk: dk.map((i) => i.toString(36)).join(''), mk, ld: -1, tn: 0, w: null, last: { id: 0 }, lg: '',
    };
  }
  const setupSeat = (s) => (s.so < s.n ? s.so : 2 * s.n - 1 - s.so);
  function actor(s) {
    if (s.ph === 'E') return null;
    if (s.ph === 'S') return setupSeat(s);
    if (s.ph === 'T') return s.tr.q.length ? s.tr.q[0] : s.tr.f;
    return s.cur;
  }
  const nmOf = (s, p) => s.nm[p] || (p + 1) + '번';
  function chkWin(s, p) { if (s.ph !== 'E' && vp(s, p) >= s.tg) { s.ph = 'E'; s.w = [p]; s.tr = null; } }
  function nextTurn(s) {
    s.tc = 0; s.tr = null; s.tn++;
    s.cur = (s.cur + 1) % s.n;
    if (s.cur === 0) { s.rnd++; s.sh = U.rand(5); }
    s.ph = 'R';
    chkWin(s, s.cur);
    if (s.ph !== 'E' && s.rnd >= 60) { // 안전 장치: 아주 길어지면 점수 높은 사람
      const v = s.p.map((_, i) => vp(s, i)), m = Math.max(...v);
      s.ph = 'E'; s.w = v.map((x, i) => (x === m ? i : -1)).filter((i) => i >= 0);
    }
  }
  function produce(s, n) {
    const g = {};
    if (n === s.dn) return [];
    const sr = seasonRes(s);
    for (let h = 0; h < NH; h++) {
      if (!isRes(s, h) || numOf(s, h) !== n) continue;
      const r = +s.mp[h];
      for (const v of HV[h]) {
        const o = own(s, v); if (o < 0) continue;
        const k = (isCity(s, v) ? 2 : 1) + (r === sr ? 1 : 0);
        s.p[o].h[r] += k;
        g[o * 5 + r] = (g[o * 5 + r] || 0) + k;
      }
    }
    return Object.keys(g).map((k) => [Math.floor(k / 5), k % 5, g[k]]);
  }
  function bump(s, o) { s.last = Object.assign({ id: (s.last.id || 0) + 1 }, o); }
  function trustArr(a) {
    if (!Array.isArray(a) || a.length !== 5) throw new Error('bad arr');
    return a.map((x) => { x = x | 0; if (x < 0 || x > 19) throw new Error('bad n'); return x; });
  }
  function updLeader(s) {
    let best = s.ld >= 0 ? s.p[s.ld].x : 2;
    for (let i = 0; i < s.n; i++) if (s.p[i].x > best && s.p[i].x >= 3) { best = s.p[i].x; s.ld = i; }
  }

  function apply(s, seat, a) {
    const t = a && a.t;
    if (s.ph === 'E') throw new Error('over');
    if (s.ph === 'S') {
      if (seat !== setupSeat(s)) throw new Error('not turn');
      if (s.sp === 0) {
        if (t !== 'set') throw new Error('need settle');
        const v = a.v | 0;
        if (!canSettle(s, seat, v, true)) throw new Error('bad spot');
        s.b = setCh(s.b, v, String.fromCharCode(97 + seat)); s.lv = v; s.sp = 1;
        const g = [];
        if (s.so >= s.n) for (const h of VH[v]) if (isRes(s, h)) { s.p[seat].h[+s.mp[h]]++; g.push([seat, +s.mp[h], 1]); }
        bump(s, { k: 'b', s: seat, b: 's', i: v, g });
        s.lg = nmOf(s, seat) + ' 마을' + (g.length ? ' · 첫 자원 ' + g.length + '장' : '');
      } else {
        if (t !== 'road') throw new Error('need road');
        const e = a.e | 0;
        if (!setupRoads(s).includes(e)) throw new Error('bad road');
        s.rd = setCh(s.rd, e, String(seat)); s.sp = 0; s.lv = -1; s.so++;
        bump(s, { k: 'b', s: seat, b: 'r', i: e });
        if (s.so >= 2 * s.n) { s.ph = 'R'; s.cur = 0; s.lg = '준비 끝! ' + nmOf(s, 0) + '부터 주사위'; }
      }
      return s;
    }
    if (seat !== actor(s)) throw new Error('not turn');
    const P = s.p[seat];
    if (s.ph === 'R') {
      if (t !== 'roll') throw new Error('roll first');
      const d = [1 + U.rand(6), 1 + U.rand(6)], n = d[0] + d[1];
      if (n === 7) {
        const lost = [];
        s.p.forEach((q, i) => {
          let tot = sum(q.h); if (tot < 9) return;
          let k = Math.floor(tot / 2); lost.push([i, k]);
          while (k-- > 0) { let m = 0; for (let r = 1; r < 5; r++) if (q.h[r] > q.h[m]) m = r; q.h[m]--; }
        });
        bump(s, { k: 'roll', s: seat, d, g: [], l: lost });
        s.ph = 'D';
        s.lg = '7 — 폭풍! ' + (lost.length ? lost.map(([i, k]) => nmOf(s, i) + ' ' + k + '장').join(', ') + ' 잃음' : '가뭄 표지를 옮겨요');
      } else {
        const g = produce(s, n);
        bump(s, { k: 'roll', s: seat, d, g });
        s.ph = 'M';
        s.lg = nmOf(s, seat) + ' 주사위 ' + n + (n === s.dn ? ' · 가뭄이라 생산 없음' : '');
      }
      return s;
    }
    if (s.ph === 'D') {
      if (t !== 'dr') throw new Error('drought');
      const n = a.n | 0;
      if (n < 2 || n > 12 || n === 7 || n === s.dn) throw new Error('bad num');
      s.dn = n; s.ph = 'M';
      bump(s, { k: 'dr', s: seat, n });
      s.lg = nmOf(s, seat) + ': 가뭄 → ' + n + '번 땅';
      return s;
    }
    if (s.ph === 'T') {
      const tr = s.tr;
      if (tr.q.length) {
        if (t === 'ok') { if (!canPay(P.h, tr.w)) throw new Error('cannot'); tr.r[seat] = 1; }
        else if (t === 'no') tr.r[seat] = 2;
        else if (t === 'ct') {
          const g = trustArr(a.g), w = trustArr(a.w);
          if (!sum(g) || !sum(w) || g.some((x, i) => x && w[i]) || !canPay(P.h, g)) throw new Error('bad counter');
          tr.r[seat] = 3; tr.c[seat] = [g, w];
        } else throw new Error('respond');
        tr.q.shift();
        if (!tr.q.length) {
          // 한 사람에게만 제안했고 그 사람이 수락하면 바로 성사
          if (tr.to >= 0 && tr.r[tr.to] === 1) doTrade(s, tr.to);
          else if (!tr.r.some((x) => x === 1 || x === 3)) {
            s.tr = null; s.ph = 'M'; s.lg = '아무도 교환을 받지 않았어요';
            bump(s, { k: 'tx', s: tr.f, fail: 1 });
          }
        }
        return s;
      }
      if (seat !== tr.f) throw new Error('not proposer');
      if (t === 'cx') { s.tr = null; s.ph = 'M'; s.lg = nmOf(s, seat) + ' 교환 취소'; bump(s, { k: 'tx', s: seat, fail: 1 }); return s; }
      if (t === 'tk') { doTrade(s, a.s | 0); return s; }
      throw new Error('resolve');
    }
    if (s.ph !== 'M') throw new Error('phase');
    if (t === 'end') { bump(s, { k: 'end', s: seat }); nextTurn(s); return s; }
    if (t === 'b') {
      const k = a.k, i = a.i | 0, c = cnt(s, seat);
      if (!COST[k]) throw new Error('kind');
      if (!canPay(P.h, COST[k])) throw new Error('no res');
      if (k === 'r') { if (c.r >= LIM.r || !canRoad(s, seat, i)) throw new Error('bad road'); s.rd = setCh(s.rd, i, String(seat)); }
      else if (k === 's') { if (c.s >= LIM.s || !canSettle(s, seat, i, false)) throw new Error('bad settle'); s.b = setCh(s.b, i, String.fromCharCode(97 + seat)); }
      else { if (c.c >= LIM.c || s.b.charCodeAt(i) !== 97 + seat) throw new Error('bad city'); s.b = setCh(s.b, i, String.fromCharCode(65 + seat)); }
      pay(P.h, COST[k]);
      bump(s, { k: 'b', s: seat, b: k, i });
      s.lg = nmOf(s, seat) + ' ' + BNM[k] + ' 지음';
      chkWin(s, seat);
      return s;
    }
    if (t === 'od') {
      const k = a.k | 0, o = s.mk[k];
      if (o == null || o < 0) throw new Error('no order');
      if (!canPay(P.h, ORD[o].c)) throw new Error('no res');
      pay(P.h, ORD[o].c); P.o += ORD[o].v; P.oc++;
      s.mk[k] = s.dk.length ? parseInt(s.dk[0], 36) : -1; s.dk = s.dk.slice(1);
      bump(s, { k: 'od', s: seat, o });
      s.lg = nmOf(s, seat) + ' 의뢰 「' + ORD[o].nm + '」 +' + ORD[o].v + '점';
      chkWin(s, seat);
      return s;
    }
    if (t === 'bank') {
      const g = a.g | 0, w = a.w | 0, n = Math.max(1, a.n | 0), r = rates(s, seat)[g];
      if (g === w || g < 0 || g > 4 || w < 0 || w > 4 || P.h[g] < r * n) throw new Error('bank');
      P.h[g] -= r * n; P.h[w] += n;
      bump(s, { k: 'bank', s: seat, g, w, n, r });
      s.lg = nmOf(s, seat) + ' 은행: ' + RN[g] + ' ' + r * n + ' → ' + RN[w] + ' ' + n;
      return s;
    }
    if (t === 'of') {
      if (s.tc >= 3) throw new Error('limit');
      const g = trustArr(a.g), w = trustArr(a.w), to = a.to == null ? -1 : a.to | 0;
      if (!sum(g) || !sum(w) || g.some((x, i) => x && w[i]) || !canPay(P.h, g)) throw new Error('bad offer');
      if (to === seat || to >= s.n || to < -1) throw new Error('bad target');
      const q = [];
      if (to >= 0) q.push(to); else for (let k = 1; k < s.n; k++) q.push((seat + k) % s.n);
      s.tr = { f: seat, g, w, to, q, r: Array(s.n).fill(0), c: {} };
      s.tc++; s.ph = 'T';
      bump(s, { k: 'of', s: seat });
      s.lg = nmOf(s, seat) + ' 교환 제안';
      return s;
    }
    throw new Error('unknown');
  }
  function doTrade(s, o) {
    const tr = s.tr, f = tr.f;
    if (o === f || !(tr.r[o] === 1 || tr.r[o] === 3)) throw new Error('not accepted');
    let give, get; // from proposer's view
    if (tr.r[o] === 1) { give = tr.g; get = tr.w; } else { give = tr.c[o][1]; get = tr.c[o][0]; }
    const A = s.p[f].h, B = s.p[o].h;
    if (!canPay(A, give) || !canPay(B, get)) throw new Error('cannot pay');
    for (let i = 0; i < 5; i++) { A[i] += get[i] - give[i]; B[i] += give[i] - get[i]; }
    s.p[f].x++; s.p[o].x++;
    const old = s.ld; updLeader(s);
    s.tr = null; s.ph = 'M';
    bump(s, { k: 'tx', s: f, o, ld: s.ld !== old ? s.ld : -1, give, get });
    s.lg = nmOf(s, f) + ' ↔ ' + nmOf(s, o) + ' 교환 성사';
    chkWin(s, f);
  }
  function result(s) {
    if (s.ph !== 'E') return null;
    const v = s.p.map((_, i) => vp(s, i));
    return {
      winners: s.w || [],
      title: s.w && s.w.length === 1 ? nmOf(s, s.w[0]) + ' 개척 성공!' : '개척 끝',
      text: v.map((x, i) => nmOf(s, i) + ' ' + x + '점').join(' · '),
    };
  }

  /* ======================= AI ======================= */
  function vVal(s, v, p, lv) {
    let sc = 0;
    const have = p != null ? prodP(s, p) : null, seen = {};
    for (const h of VH[v]) {
      if (!isRes(s, h)) continue;
      const r = +s.mp[h], n = numOf(s, h);
      let w = pips(n) * (n === s.dn ? 0.3 : 1);
      if (have && lv >= 2 && !have[r] && !seen[r]) w += lv === 3 ? 2.5 : 1.5;
      if (lv === 3 && (r === 4 || r === 3)) w *= 1.12;
      seen[r] = 1; sc += w;
    }
    if (lv === 3 && p != null) for (const [e, t] of s.hb) if (EV[e].includes(v)) {
      const pr = prodP(s, p);
      sc += t === 5 ? 1.5 : pr[t] >= 4 ? 3 : 1;
    }
    return sc;
  }
  function pickBest(list, f, lv) {
    if (!list.length) return -1;
    const sc = list.map((x) => [x, f(x) + (lv === 1 ? Math.random() * 6 : lv === 2 ? Math.random() * 1.5 : Math.random() * 0.2)]);
    sc.sort((a, b) => b[1] - a[1]);
    if (lv === 1 && Math.random() < 0.3) return sc[Math.min(sc.length - 1, U.rand(6))][0];
    return sc[0][0];
  }
  function goals(s, p, lv) {
    const c = cnt(s, p), G = [], spots = settleSpots(s, p, false), prod = prodP(s, p), h = s.p[p].h;
    const eff = (cost) => { let d = 0; for (let i = 0; i < 5; i++) d += Math.max(0, cost[i] - h[i]) * (prod[i] > 0 ? 1 : 1.6); return d; };
    if (c.c < LIM.c && c.s > 0) G.push({ k: 'c', cost: COST.c, w: 2.3 });
    if (c.s < LIM.s && spots.length) G.push({ k: 's', cost: COST.s, w: 2.5 });
    if (c.s < LIM.s && !spots.length && c.r < LIM.r) G.push({ k: 'r', cost: COST.r, w: 1.7 });
    s.mk.forEach((o, i) => { if (o >= 0) G.push({ k: 'o', i, cost: ORD[o].c, w: ORD[o].v === 2 ? 2.0 : 1.0 }); });
    G.forEach((g) => { g.sc = g.w - 0.55 * eff(g.cost); });
    G.sort((a, b) => b.sc - a.sc);
    return G;
  }
  // 어려움은 내가 잘 못 만드는 자원을 더 귀하게 여김
  function wts(s, p, lv) { if (lv < 3) return null; const pr = prodP(s, p); return pr.map((x) => (x >= 5 ? 0.75 : x > 0 ? 1 : 1.45)); }
  const wdef = (c, h, w) => { let d = 0; for (let i = 0; i < 5; i++) d += Math.max(0, c[i] - h[i]) * (w ? w[i] : 1); return d; };
  function hscore(G, h, w) {
    const d1 = G[0] ? wdef(G[0].cost, h, w) : 0, d2 = G[1] ? wdef(G[1].cost, h, w) : 0, t = sum(h);
    return -3 * d1 - d2 + 0.15 * t - (t > 8 ? 0.35 * (t - 8) : 0);
  }
  function roadToward(s, p) {
    const dist = new Array(NV).fill(-1), first = new Array(NV).fill(-1), qu = [];
    for (let v = 0; v < NV; v++) {
      const o = own(s, v);
      if (o === p || (o < 0 && VE[v].some((e) => rOwn(s, e) === p))) { dist[v] = 0; qu.push(v); }
    }
    for (let qi = 0; qi < qu.length; qi++) {
      const v = qu[qi];
      if (dist[v] >= 4) continue;
      for (const e of VE[v]) {
        if (s.rd[e] !== '.' || !landE(s, e)) continue;
        const u = EV[e][0] === v ? EV[e][1] : EV[e][0];
        if (dist[u] >= 0) continue;
        const o = own(s, u); if (o >= 0 && o !== p) continue;
        dist[u] = dist[v] + 1; first[u] = dist[v] === 0 ? e : first[v]; qu.push(u);
      }
    }
    let best = -1, bs = -1;
    for (let v = 0; v < NV; v++) {
      if (dist[v] < 1 || !canSettle(s, p, v, true)) continue;
      const sc = vVal(s, v, p, 2) / dist[v];
      if (sc > bs) { bs = sc; best = v; }
    }
    if (best >= 0 && canRoad(s, p, first[best])) return first[best];
    return -1;
  }
  function aiMain(s, p, lv) {
    const P = s.p[p], h = P.h, c = cnt(s, p), G = goals(s, p, lv);
    if (lv === 1 && Math.random() < 0.12) return { t: 'end' };
    if (c.c < LIM.c && c.s > 0 && canPay(h, COST.c)) return { t: 'b', k: 'c', i: pickBest(citySpots(s, p), (v) => vVal(s, v), lv) };
    const spots = settleSpots(s, p, false);
    if (spots.length && c.s < LIM.s && canPay(h, COST.s)) return { t: 'b', k: 's', i: pickBest(spots, (v) => vVal(s, v, p, lv), lv) };
    for (let i = 0; i < 3; i++) {
      const o = s.mk[i]; if (o < 0 || !canPay(h, ORD[o].c)) continue;
      if (lv === 1 ? Math.random() < 0.7 : (G[0] && G[0].k === 'o' && G[0].i === i) ||
        (() => { const hh = h.slice(); pay(hh, ORD[o].c); return !G[0] || def(G[0].cost, hh) - def(G[0].cost, h) <= ORD[o].v; })())
        return { t: 'od', k: i };
    }
    if (canPay(h, COST.r) && c.r < LIM.r && c.s < LIM.s) {
      const want = !spots.length || (lv >= 2 && spots.length < 2 && c.r < 4 + c.s * 2) || (lv === 1 && Math.random() < 0.3);
      if (want) { const e = roadToward(s, p); if (e >= 0) return { t: 'b', k: 'r', i: e }; }
    }
    const g1 = G[0];
    if (!g1) return { t: 'end' };
    const need = g1.cost.slice();
    if (lv === 3 && G[1]) for (let i = 0; i < 5; i++) need[i] = Math.max(need[i], Math.min(G[1].cost[i], 1));
    const miss = [0, 1, 2, 3, 4].filter((i) => g1.cost[i] > h[i]).sort((a, b) => (g1.cost[b] - h[b]) - (g1.cost[a] - h[a]));
    if (!miss.length) return aiBeforeEnd(s, p, lv, G);
    const rt = rates(s, p);
    const surplus = [0, 1, 2, 3, 4].filter((i) => h[i] - need[i] > 0).sort((a, b) => (h[b] - need[b]) - (h[a] - need[a]));
    // 은행/항구
    for (const x of surplus) {
      if (h[x] - need[x] >= rt[x] + (lv === 1 ? 1 : 0)) return { t: 'bank', g: x, w: miss[0], n: 1 };
    }
    // 다른 사람과 흥정
    const lim = lv === 1 ? (Math.random() < 0.4 ? 1 : 0) : lv === 2 ? 2 : 3;
    const d = def(g1.cost, h);
    if (s.tc < lim && d <= 3 && surplus.length) {
      const g = [0, 0, 0, 0, 0], w = [0, 0, 0, 0, 0];
      const x = surplus[s.tc % surplus.length];
      w[miss[s.tc % miss.length]] = 1;
      g[x] = 1;
      if (lv === 3 && s.tc >= 1 && h[x] - need[x] >= 2) g[x] = 2;
      if (lv === 1 && Math.random() < 0.3) { const y = [0, 1, 2, 3, 4].filter((i) => h[i] > 0 && !w[i]); if (y.length) { g.fill(0); g[y[U.rand(y.length)]] = 1; } }
      return { t: 'of', g, w, to: -1 };
    }
    return aiBeforeEnd(s, p, lv, G);
  }
  // 어려움: 폭풍(7)에 대비해 손패를 8장 이하로 줄이고 끝냄
  function aiBeforeEnd(s, p, lv, G) {
    const h = s.p[p].h;
    if (lv < 3 || sum(h) < 9) return { t: 'end' };
    const c = cnt(s, p);
    if (canPay(h, COST.r) && c.r < LIM.r) { const e = roadToward(s, p); if (e >= 0) return { t: 'b', k: 'r', i: e }; }
    const rt = rates(s, p), need = G[0] ? G[0].cost : [1, 1, 1, 1, 1];
    let x = -1;
    for (let i = 0; i < 5; i++) if (h[i] >= rt[i] && (x < 0 || h[i] - need[i] > h[x] - need[x])) x = i;
    if (x < 0) return { t: 'end' };
    let y = -1;
    for (let i = 0; i < 5; i++) if (i !== x && (y < 0 || need[i] - h[i] > need[y] - h[y])) y = i;
    return { t: 'bank', g: x, w: y, n: 1 };
  }
  function aiRespond(s, p, lv) {
    const tr = s.tr, h = s.p[p].h, G = goals(s, p, lv);
    const W = wts(s, p, lv), b = hscore(G, h, W), vf = vp(s, tr.f), me = vp(s, p);
    const danger = vf >= s.tg - (lv === 3 ? 2 : 1);
    if (canPay(h, tr.w)) {
      const hh = h.slice(); for (let i = 0; i < 5; i++) hh[i] += tr.g[i] - tr.w[i];
      const a = hscore(G, hh, W);
      if (lv === 1) { if ((a > b - 1 && Math.random() < 0.8) || Math.random() < 0.15) return { t: 'ok' }; return { t: 'no' }; }
      if (!danger && a > b + (lv === 3 ? (vf >= me + 2 ? 0.6 : 0.01) : 0.01)) return { t: 'ok' };
    }
    if (lv === 1 || danger || (lv === 2 && Math.random() < 0.5)) return { t: 'no' };
    // 역제안: 상대가 내놓은 것 중 내가 필요한 것 1장 ↔ 내 남는 것 1장
    const g1 = G[0]; if (!g1) return { t: 'no' };
    const y = [0, 1, 2, 3, 4].find((i) => tr.g[i] > 0 && g1.cost[i] > h[i]);
    if (y == null) return { t: 'no' };
    const xs = [0, 1, 2, 3, 4].filter((i) => i !== y && h[i] - g1.cost[i] > 0).sort((a, c) => (h[c] - g1.cost[c]) - (h[a] - g1.cost[a]));
    if (!xs.length) return { t: 'no' };
    const g = [0, 0, 0, 0, 0], w = [0, 0, 0, 0, 0]; g[xs[0]] = 1; w[y] = 1;
    if (g.every((v, i) => v === tr.w[i]) && w.every((v, i) => v === tr.g[i])) return { t: 'no' };
    return { t: 'ct', g, w };
  }
  function aiResolve(s, p, lv) {
    const tr = s.tr, h = s.p[p].h, G = goals(s, p, lv), W = wts(s, p, lv), base = hscore(G, h, W);
    let best = -1, bs = -1e9;
    for (let o = 0; o < s.n; o++) {
      if (!(tr.r[o] === 1 || tr.r[o] === 3)) continue;
      if (lv === 3 && vp(s, o) >= s.tg - 2) continue;
      const give = tr.r[o] === 1 ? tr.g : tr.c[o][1], get = tr.r[o] === 1 ? tr.w : tr.c[o][0];
      if (!canPay(h, give)) continue;
      const hh = h.slice(); for (let i = 0; i < 5; i++) hh[i] += get[i] - give[i];
      const sc = hscore(G, hh, W) - (lv >= 2 ? vp(s, o) * 0.05 : 0);
      if (sc > bs) { bs = sc; best = o; }
    }
    if (best >= 0 && (lv === 1 || tr.r[best] === 1 || bs > base)) return { t: 'tk', s: best };
    return { t: 'cx' };
  }
  function aiDrought(s, p, lv) {
    const opts = [2, 3, 4, 5, 6, 8, 9, 10, 11, 12].filter((n) => n !== s.dn);
    if (lv === 1) return opts[U.rand(opts.length)];
    const vps = s.p.map((_, i) => vp(s, i)), top = Math.max(...vps);
    let best = opts[0], bs = -1e9;
    for (const n of opts) {
      const imp = Array(s.n).fill(0);
      for (let h = 0; h < NH; h++) {
        if (!isRes(s, h) || numOf(s, h) !== n) continue;
        for (const v of HV[h]) { const o = own(s, v); if (o >= 0) imp[o] += pips(n) * (isCity(s, v) ? 2 : 1); }
      }
      let sc = 0;
      imp.forEach((x, i) => { sc += i === p ? -2 * x : x * (1 + (lv === 3 ? (vps[i] === top ? 1.2 : 0) + vps[i] / 6 : 0)); });
      sc += Math.random() * 0.5;
      if (sc > bs) { bs = sc; best = n; }
    }
    return best;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'S') {
      if (s.sp === 0) return { t: 'set', v: pickBest(settleSpots(s, seat, true), (v) => vVal(s, v, seat, lv), lv) };
      const rs = setupRoads(s);
      if (lv === 1) return { t: 'road', e: rs[U.rand(rs.length)] };
      // 다음 마을 자리 쪽으로
      let be = rs[0], bs = -1;
      for (const e of rs) {
        const u = EV[e][0] === s.lv ? EV[e][1] : EV[e][0];
        let sc = Math.random() * 0.3;
        for (const w of VN[u]) if (w !== s.lv && canSettle(s, seat, w, true)) sc = Math.max(sc, vVal(s, w, seat, lv));
        if (sc > bs) { bs = sc; be = e; }
      }
      return { t: 'road', e: be };
    }
    if (s.ph === 'R') return { t: 'roll' };
    if (s.ph === 'D') return { t: 'dr', n: aiDrought(s, seat, lv) };
    if (s.ph === 'T') return s.tr.q.length ? aiRespond(s, seat, lv) : aiResolve(s, seat, lv);
    if (s.ph === 'M') return aiMain(s, seat, lv);
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    const f = lv === 1 ? 1.25 : lv === 3 ? 0.85 : 1;
    if (s.ph === 'T') return 650 * f;
    if (s.ph === 'R') return 550 * f;
    if (s.ph === 'S') return 650 * f;
    return 750 * f;
  }

  /* ======================= icons ======================= */
  const circ = (x, y, r) => 'M' + (x - r) + ' ' + y + 'a' + r + ' ' + r + ' 0 1 0 ' + 2 * r + ' 0a' + r + ' ' + r + ' 0 1 0 ' + -2 * r + ' 0';
  const RI = [
    [['M10 1.5L3.5 10.5h3L3 15.5h14l-3.5-5h3z', '#46a34c'], ['M9 15h2v4H9z', '#7a4a24']],
    [['M2 5h16v11H2z', '#c4643c'], ['M2 10h16v1H2zM6.5 5h1v5h-1zM12.5 5h1v5h-1zM9.5 11h1v5h-1z', '#7d3618']],
    [[circ(6.5, 9, 3.8) + circ(13.5, 9, 3.8) + circ(10, 5.8, 4), '#f8f4ea'], ['M6 12.5h8L10 18.5z', '#7a5a34']],
    [['M9.4 6h1.2v12.5H9.4z', '#8c6d1c'], [circ(7, 5.5, 2) + circ(13, 5.5, 2) + circ(7, 10, 2) + circ(13, 10, 2) + circ(10, 2.8, 2), '#efcb4c']],
    [['M2.5 16l3.2-8h8.6l3.2 8z', '#8fa2b8'], ['M5.7 8h8.6l-.9 2.4H6.6z', '#dbe4ee']],
  ];
  const icoSvg = (r, sz) => '<svg viewBox="0 0 20 20" width="' + (sz || 18) + '" height="' + (sz || 18) + '" aria-hidden="true">' + RI[r].map(([d, f]) => '<path d="' + d + '" fill="' + f + '"/>').join('') + '</svg>';
  let RP = null;
  function icoCanvas(ctx, r, x, y, size) {
    if (!RP) RP = RI.map((parts) => parts.map(([d, f]) => [new Path2D(d), f]));
    ctx.save(); ctx.translate(x - size / 2, y - size / 2); ctx.scale(size / 20, size / 20);
    for (const [p, f] of RP[r]) { ctx.fillStyle = f; ctx.fill(p); }
    ctx.restore();
  }

  /* ======================= view ======================= */
  const CSS = `
.it{position:absolute;inset:0;display:flex;flex-direction:column;overflow:hidden;color:var(--ink);background:linear-gradient(180deg,#1b1626,#141020)}
.it-pl{display:grid;gap:4px;padding:6px 6px 0;flex:none}
.it-p{position:relative;border-radius:10px;background:var(--surface-2);padding:3px 6px;min-width:0;border:2px solid transparent;height:46px;box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;gap:1px}
.it-p.on{border-color:var(--c);box-shadow:0 0 10px -3px var(--c)}
.it-p .nm{font-size:12px;font-weight:700;display:flex;gap:4px;align-items:center;white-space:nowrap;overflow:hidden;min-width:0}
.it-p .nm span:last-child{overflow:hidden;text-overflow:ellipsis}
.it-p .sc{font-family:var(--f-mono);font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;display:flex;gap:6px}
.it-p .sc b{color:var(--brass);font-weight:700}
.it-p .gn{position:absolute;right:3px;top:2px;font-family:var(--f-mono);font-size:12px;font-weight:700;color:#8ee08a;animation:itUp 1.6s ease-out forwards;pointer-events:none}
.it-p .cr{position:absolute;right:4px;bottom:3px;font-size:11px}
@keyframes itUp{0%{opacity:0;transform:translateY(6px)}15%{opacity:1;transform:none}80%{opacity:1}100%{opacity:0;transform:translateY(-6px)}}
.it-info{display:flex;gap:4px;padding:5px 6px 0;flex:none;min-width:0}
.it-pill{flex:1 1 0;min-width:0;height:28px;border-radius:14px;background:rgba(255,255,255,.07);display:flex;align-items:center;justify-content:center;gap:3px;font-size:11.5px;font-weight:700;white-space:nowrap;overflow:hidden;padding:0 6px}
.it-pill span{overflow:hidden;text-overflow:ellipsis}
.it-pill.dr{color:#f0c27a}
.it-board{flex:1 1 auto;position:relative;min-height:0;margin:5px 6px 0;border-radius:14px;overflow:hidden;box-shadow:inset 0 0 0 2px rgba(0,0,0,.45);background:#0f2b3a}
.it-zoom{position:absolute;right:6px;top:6px;display:flex;flex-direction:column;gap:6px;z-index:2}
.it-zoom button{width:44px;height:44px;border-radius:12px;border:0;background:rgba(18,14,28,.72);color:var(--ink);font-size:22px;font-weight:700;cursor:pointer;touch-action:manipulation}
.it-log{position:absolute;left:8px;top:8px;right:58px;font-size:12px;font-weight:700;pointer-events:none;display:flex;justify-content:flex-start}
.it-log span{background:rgba(12,10,20,.72);padding:4px 10px;border-radius:999px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.it-dice{position:absolute;left:50%;top:44%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;gap:6px;z-index:3;pointer-events:none;transition:opacity .25s}
.it-dice .row{display:flex;gap:10px}
.it-die{width:46px;height:46px;border-radius:10px;background:#f6ecd9;box-shadow:0 4px 0 #b9a27c,0 8px 14px rgba(0,0,0,.5);display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(3,1fr);padding:6px;box-sizing:border-box}
.it-die i{width:8px;height:8px;border-radius:50%;background:#2a1f18;place-self:center;visibility:hidden}
.it-die i.on{visibility:visible}
.it-die.spin{animation:itSpin .18s linear infinite}
@keyframes itSpin{0%{transform:rotate(0) translateY(0)}50%{transform:rotate(12deg) translateY(-6px)}100%{transform:rotate(0) translateY(0)}}
.it-dice .tot{background:rgba(12,10,20,.85);border-radius:12px;padding:4px 10px;font-weight:700;font-size:13px;display:flex;flex-direction:column;gap:2px;align-items:center;max-width:300px}
.it-dice .tot b{font-family:var(--f-mono);font-size:20px;color:var(--brass)}
.it-dice .gl{display:flex;align-items:center;gap:3px;font-size:12px;white-space:nowrap}
.it-dice .gl svg{vertical-align:middle}
.it-hand{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:4px;padding:6px 6px 0;flex:none}
.it-r{height:48px;border-radius:10px;background:#f3e8d2;color:#2a1f18;display:flex;align-items:center;justify-content:center;gap:4px;position:relative;min-width:0}
.it-r .n{font-family:var(--f-mono);font-weight:700;font-size:18px}
.it-r .t{position:absolute;left:0;right:0;bottom:1px;text-align:center;font-size:10px;font-weight:700;color:#6b5a48}
.it-r.zero{opacity:.45}
.it-r.flash{animation:itFl .9s}
@keyframes itFl{0%,60%{box-shadow:0 0 0 3px #8ee08a}100%{box-shadow:none}}
.it-hide{grid-column:1/-1;height:48px;border-radius:10px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;font-size:12.5px;color:var(--muted);text-align:center;padding:0 8px}
.it-bar{flex:none;display:flex;gap:6px;padding:6px;min-height:58px;align-items:center;box-sizing:border-box}
.it-bar .btn{flex:1 1 0;min-width:0;padding:0 4px;font-size:14px;white-space:nowrap}
.it-bar .btn.wide{flex:2 1 0}
.it-hint{flex:1;font-size:13px;text-align:center;color:var(--muted);min-width:0;line-height:1.25}
.it-ov{position:absolute;inset:0;z-index:15;background:rgba(10,8,15,.6);display:flex;align-items:flex-end;justify-content:center}
.it-sh{background:var(--surface);border-radius:18px 18px 0 0;width:100%;max-width:460px;max-height:100%;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:9px;box-sizing:border-box;border-top:1px solid var(--line)}
.it-sh h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:21px;flex:1;min-width:0}
.it-hd{display:flex;align-items:center;gap:6px}
.it-hd .x{width:44px;height:44px;border:0;background:transparent;color:var(--ink);font-size:20px;cursor:pointer}
.it-lb{font-size:12px;color:var(--muted);font-weight:700}
.it-chips{display:flex;flex-wrap:wrap;gap:6px}
.it-chips .btn{flex:1 1 auto;min-height:44px;padding:0 8px;font-size:13px}
.it-chips .btn.on{background:var(--brass);color:var(--brass-ink);border-color:transparent}
.it-stp{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:4px}
.it-sc{display:flex;flex-direction:column;align-items:center;gap:2px;background:rgba(255,255,255,.05);border-radius:10px;padding:3px 2px}
.it-sc button{width:100%;height:44px;border-radius:9px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-size:20px;font-weight:700;cursor:pointer;touch-action:manipulation}
.it-sc button:disabled{opacity:.3}
.it-sc .v{display:flex;align-items:center;gap:3px;font-family:var(--f-mono);font-weight:700;font-size:16px;height:22px}
.it-sc .hv{font-size:10px;color:var(--muted);height:12px}
.it-sc.g .v{color:#f0a08f}.it-sc.w .v{color:#9fe09a}
.it-row{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.05);border-radius:12px;padding:6px 8px;min-height:44px}
.it-row .nm{font-weight:700;font-size:14px;min-width:0}
.it-row .cs{display:flex;gap:2px;align-items:center;flex-wrap:wrap;font-family:var(--f-mono);font-size:13px;flex:1;min-width:0}
.it-row .btn{flex:none;min-width:72px}
.it-cost{display:inline-flex;align-items:center;gap:1px;margin-right:4px}
.it-big{display:flex;align-items:center;justify-content:center;gap:8px;font-size:14px;flex-wrap:wrap}
.it-nums{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:6px}
.it-nums .btn{min-height:54px;flex-direction:column;gap:2px;padding:2px;font-family:var(--f-mono);font-size:17px}
.it-nums .btn.on{background:var(--brass);color:var(--brass-ink)}
.it-nums .dots{display:flex;gap:2px;height:8px}
.it-nums .dots i{width:7px;height:7px;border-radius:50%;background:var(--c)}
.it-act{display:flex;gap:6px}
.it-act .btn{flex:1;min-width:0}
.it-note{font-size:12px;color:var(--muted);line-height:1.35}
`;

  function mount(root, api) {
    const h = L.h, sp = () => L.debug.speed || 1;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'it' });
    const plEl = h('div', { class: 'it-pl' });
    const infoEl = h('div', { class: 'it-info' });
    const boardEl = h('div', { class: 'it-board' });
    const handEl = h('div', { class: 'it-hand' });
    const barEl = h('div', { class: 'it-bar' });
    wrap.append(plEl, infoEl, boardEl, handEl, barEl);
    root.append(style, wrap);
    const cv = U.canvas(boardEl);
    const logEl = h('div', { class: 'it-log' });
    const diceEl = h('div', { class: 'it-dice', style: { opacity: 0 } });
    const zoomEl = h('div', { class: 'it-zoom' },
      h('button', { 'aria-label': '확대', text: '+', onclick() { setZoom(view.z * 1.4); } }),
      h('button', { 'aria-label': '축소', text: '−', onclick() { setZoom(view.z / 1.4); } }));
    boardEl.append(logEl, diceEl, zoomEl);
    let st = null, dead = false, busy = false, ovEl = null, uiKey = '', lastSeen = -1;
    let ui = {};
    const view = { z: 1, ox: 0, oy: 0 };
    const timers = new Set();
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms / sp()); timers.add(t); return t; };
    const nm = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    const multi = () => !api.online && api.mySeats().length >= 2;
    function ctrl() {
      if (!st) return -1;
      const a = actor(st);
      if (a == null || !api.canAct(a)) return -1;
      if (multi() && api.viewer() !== a) return -1;
      return a;
    }
    function act(a) { ui = {}; closeOv(); api.sfx('click'); api.act(a); }
    const costHtml = (c, mul) => c.map((x, i) => (x ? '<span class="it-cost">' + icoSvg(i, 16) + (x * (mul || 1)) + '</span>' : '')).join('');

    /* ---------- board transform ---------- */
    let bbox = null;
    function calcBox() {
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      for (let i = 0; i < NH; i++) if (isLand(st, i)) {
        x0 = Math.min(x0, HX[i].x - 1.75); x1 = Math.max(x1, HX[i].x + 1.75);
        y0 = Math.min(y0, HX[i].y - 1.75); y1 = Math.max(y1, HX[i].y + 1.75);
      }
      bbox = { x0, y0, x1, y1, mx: (x0 + x1) / 2, my: (y0 + y1) / 2 };
    }
    function sc() { if (!bbox) return 20; return Math.min(cv.w / (bbox.x1 - bbox.x0), cv.h / (bbox.y1 - bbox.y0)) * view.z; }
    const SX = (x) => (x - bbox.mx) * sc() + cv.w / 2 + view.ox;
    const SY = (y) => (y - bbox.my) * sc() + cv.h / 2 + view.oy;
    function clampPan() {
      if (!bbox) return;
      const s = sc(), bw = (bbox.x1 - bbox.x0) * s, bh = (bbox.y1 - bbox.y0) * s;
      const mx = Math.max(0, (bw - cv.w) / 2 + 20), my = Math.max(0, (bh - cv.h) / 2 + 20);
      view.ox = U.clamp(view.ox, -mx, mx); view.oy = U.clamp(view.oy, -my, my);
    }
    function setZoom(z) { view.z = U.clamp(z, 1, 3); if (view.z === 1) { view.ox = 0; view.oy = 0; } clampPan(); api.sfx('tick'); dirty(); }

    /* ---------- drawing ---------- */
    let stc = null, stcKey = '', need = true, raf = 0, hl = null;
    function dirty() { need = true; if (!raf) raf = requestAnimationFrame(frame); }
    function frame(t) {
      raf = 0;
      if (dead) return;
      draw(t);
      if (ui.place || (hl && t < hl.until)) raf = requestAnimationFrame(frame);
    }
    function hexPath(ctx, x, y, r) {
      ctx.beginPath();
      for (let i = 0; i < 6; i++) { const a = Math.PI / 180 * (60 * i - 30); ctx[i ? 'lineTo' : 'moveTo'](x + Math.cos(a) * r, y + Math.sin(a) * r); }
      ctx.closePath();
    }
    function drawStatic() {
      const key = [cv.w, cv.h, cv.dpr, view.z, view.ox, view.oy, st.mp, st.nu, st.dn].join('|');
      if (key === stcKey && stc) return;
      stcKey = key;
      if (!stc) stc = document.createElement('canvas');
      stc.width = cv.cv.width; stc.height = cv.cv.height;
      const c = stc.getContext('2d');
      c.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const W = cv.w, H = cv.h, s = sc();
      // sea
      const g = c.createRadialGradient(W / 2, H / 2, 10, W / 2, H / 2, Math.max(W, H) * 0.7);
      g.addColorStop(0, '#1d5568'); g.addColorStop(1, '#0c2433');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.strokeStyle = 'rgba(255,255,255,.05)'; c.lineWidth = 1.2;
      for (let y = 10; y < H; y += 22) {
        c.beginPath();
        for (let x = 0; x <= W; x += 12) c.lineTo(x, y + Math.sin((x + y * 3) / 18) * 2.5);
        c.stroke();
      }
      // shore glow
      for (let i = 0; i < NH; i++) if (isLand(st, i)) {
        hexPath(c, SX(HX[i].x), SY(HX[i].y), s * 1.12);
        c.fillStyle = 'rgba(232,214,160,.55)'; c.fill();
      }
      for (let i = 0; i < NH; i++) {
        if (!isLand(st, i)) continue;
        const x = SX(HX[i].x), y = SY(HX[i].y), t = st.mp[i];
        hexPath(c, x, y, s * 0.98);
        if (t === 'v') {
          c.fillStyle = '#3b2424'; c.fill();
          c.fillStyle = '#5a3030'; c.beginPath(); c.moveTo(x - s * 0.55, y + s * 0.45); c.lineTo(x - s * 0.12, y - s * 0.35); c.lineTo(x + s * 0.12, y - s * 0.35); c.lineTo(x + s * 0.55, y + s * 0.45); c.fill();
          c.fillStyle = '#ff7a3c'; c.beginPath(); c.ellipse(x, y - s * 0.35, s * 0.13, s * 0.05, 0, 0, 7); c.fill();
          c.fillStyle = 'rgba(200,190,190,.35)';
          [[0.05, -0.55, 0.12], [-0.08, -0.72, 0.1], [0.1, -0.82, 0.08]].forEach(([a, b, r]) => { c.beginPath(); c.arc(x + a * s, y + b * s, r * s, 0, 7); c.fill(); });
          continue;
        }
        const r = +t;
        const gg = c.createLinearGradient(x, y - s, x, y + s);
        gg.addColorStop(0, shade(TCOL[r], 18)); gg.addColorStop(1, shade(TCOL[r], -14));
        c.fillStyle = gg; c.fill();
        c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = Math.max(1, s * 0.04); c.stroke();
        // motifs
        const ms = s * 0.34;
        icoCanvas(c, r, x - s * 0.42, y - s * 0.42, ms);
        icoCanvas(c, r, x + s * 0.42, y - s * 0.42, ms);
        icoCanvas(c, r, x, y - s * 0.62, ms);
        const n = numOf(st, i), dry = n === st.dn;
        if (dry) {
          hexPath(c, x, y, s * 0.98); c.fillStyle = 'rgba(120,80,30,.55)'; c.fill();
          c.strokeStyle = 'rgba(60,30,10,.8)'; c.lineWidth = Math.max(1, s * 0.03);
          c.beginPath(); c.moveTo(x - s * 0.6, y - s * 0.1); c.lineTo(x - s * 0.3, y + s * 0.05); c.lineTo(x - s * 0.35, y + s * 0.35); c.moveTo(x - s * 0.3, y + s * 0.05); c.lineTo(x, y - s * 0.05); c.stroke();
        }
        // token
        const tr = s * 0.3, ty = y + s * 0.12;
        c.beginPath(); c.arc(x, ty + 1.5, tr, 0, 7); c.fillStyle = 'rgba(0,0,0,.35)'; c.fill();
        c.beginPath(); c.arc(x, ty, tr, 0, 7); c.fillStyle = dry ? '#bfa98a' : '#f6ecd9'; c.fill();
        c.fillStyle = dry ? '#6a4a2a' : (n === 6 || n === 8) ? '#c0392b' : '#2a1f18';
        c.font = '700 ' + Math.round(tr * 1.05) + 'px "IBM Plex Mono",monospace'; c.textAlign = 'center'; c.textBaseline = 'middle';
        c.fillText(String(n), x, ty - tr * 0.12);
        const pp = pips(n);
        for (let k = 0; k < pp; k++) { c.beginPath(); c.arc(x + (k - (pp - 1) / 2) * tr * 0.22, ty + tr * 0.55, Math.max(1, tr * 0.07), 0, 7); c.fill(); }
        if (dry) { c.font = '700 ' + Math.round(tr * 0.5) + 'px "IBM Plex Sans KR",sans-serif'; c.fillStyle = '#ffd99a'; c.fillText('가뭄', x, ty - tr * 1.35); }
      }
      // harbors
      for (const [e, t] of st.hb) {
        const lh = EH[e].find((i) => isLand(st, i)); if (lh == null) continue;
        const a = VX[EV[e][0]], b = VX[EV[e][1]], mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        let dx = mx - HX[lh].x, dy = my - HX[lh].y; const dl = Math.hypot(dx, dy); dx /= dl; dy /= dl;
        const px = mx + dx * 0.62, py = my + dy * 0.62;
        c.strokeStyle = '#8a6a44'; c.lineWidth = Math.max(2, s * 0.08); c.lineCap = 'round';
        c.beginPath(); c.moveTo(SX(a.x), SY(a.y)); c.lineTo(SX(px), SY(py)); c.lineTo(SX(b.x), SY(b.y)); c.stroke();
        const R = s * 0.3;
        c.beginPath(); c.arc(SX(px), SY(py), R, 0, 7); c.fillStyle = '#f6ecd9'; c.fill(); c.strokeStyle = '#8a6a44'; c.lineWidth = 2; c.stroke();
        c.fillStyle = '#2a1f18'; c.textAlign = 'center'; c.textBaseline = 'middle';
        if (t === 5) { c.font = '700 ' + Math.round(R * 0.75) + 'px "IBM Plex Mono",monospace'; c.fillText('3:1', SX(px), SY(py)); }
        else { icoCanvas(c, t, SX(px), SY(py) - R * 0.25, R * 1.0); c.font = '700 ' + Math.round(R * 0.55) + 'px "IBM Plex Mono",monospace'; c.fillText('2:1', SX(px), SY(py) + R * 0.5); }
      }
    }
    function shade(hex, amt) {
      const n = parseInt(hex.slice(1), 16);
      const f = (v) => U.clamp(v + amt, 0, 255);
      return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
    }
    function house(c, x, y, s, color, city) {
      c.save(); c.translate(x, y);
      c.beginPath();
      if (!city) { const w = s * 0.2, hh = s * 0.17; c.moveTo(-w, hh); c.lineTo(-w, -hh * 0.2); c.lineTo(0, -hh * 1.15); c.lineTo(w, -hh * 0.2); c.lineTo(w, hh); }
      else { const w = s * 0.3, hh = s * 0.2; c.moveTo(-w, hh); c.lineTo(-w, -hh * 0.3); c.lineTo(-w * 0.35, -hh * 0.3); c.lineTo(-w * 0.35, -hh * 1.3); c.lineTo(w * 0.05, -hh * 1.8); c.lineTo(w * 0.45, -hh * 1.3); c.lineTo(w * 0.45, -hh * 0.6); c.lineTo(w, -hh * 0.6); c.lineTo(w, hh); }
      c.closePath();
      c.fillStyle = color; c.fill(); c.strokeStyle = '#120d18'; c.lineWidth = Math.max(1.5, s * 0.045); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(-s * 0.05, -s * 0.02, s * 0.08, s * 0.08);
      c.restore();
    }
    function draw(t) {
      if (!st || !bbox) return;
      const c = cv.ctx, s = sc();
      cv.clear();
      drawStatic();
      c.drawImage(stc, 0, 0, cv.w, cv.h);
      now = t || performance.now();
      if (hl && now < hl.until) {
        const a = Math.min(1, (hl.until - now) / 500);
        for (let i = 0; i < NH; i++) if (isRes(st, i) && numOf(st, i) === hl.n) {
          hexPath(c, SX(HX[i].x), SY(HX[i].y), s * 0.94);
          c.strokeStyle = hl.n === st.dn ? 'rgba(240,160,80,' + a + ')' : 'rgba(255,224,130,' + a + ')'; c.lineWidth = Math.max(3, s * 0.1); c.stroke();
        }
      }
      // roads
      for (let e = 0; e < NE; e++) {
        const o = rOwn(st, e); if (o < 0) continue;
        drawRoad(c, e, col(o), s);
      }
      for (let v = 0; v < NV; v++) {
        const o = own(st, v); if (o < 0) continue;
        house(c, SX(VX[v].x), SY(VX[v].y), s, col(o), isCity(st, v));
      }
      // placement candidates
      if (ui.place) {
        const pul = 0.5 + 0.5 * Math.sin(now / 180);
        const me = ctrl(), pc = me >= 0 ? col(me) : '#e3ae45';
        for (const id of ui.place.cand) {
          const sel = id === ui.place.sel;
          if (ui.place.k === 'r' || ui.place.k === 'R') {
            const [a, b] = EV[id];
            c.strokeStyle = sel ? '#ffe08a' : 'rgba(255,224,138,' + (0.35 + pul * 0.45) + ')';
            c.lineWidth = Math.max(4, s * (sel ? 0.2 : 0.13)); c.lineCap = 'round';
            c.beginPath(); c.moveTo(SX(U.lerp(VX[a].x, VX[b].x, 0.2)), SY(U.lerp(VX[a].y, VX[b].y, 0.2))); c.lineTo(SX(U.lerp(VX[a].x, VX[b].x, 0.8)), SY(U.lerp(VX[a].y, VX[b].y, 0.8))); c.stroke();
            if (sel) drawRoad(c, id, pc, s);
          } else {
            const x = SX(VX[id].x), y = SY(VX[id].y);
            c.beginPath(); c.arc(x, y, s * (0.17 + pul * 0.05), 0, 7);
            c.fillStyle = sel ? '#ffe08a' : 'rgba(255,224,138,.28)'; c.fill();
            c.strokeStyle = '#ffe08a'; c.lineWidth = 2; c.stroke();
            if (sel) house(c, x, y, s, pc, ui.place.k === 'c');
          }
        }
      }
    }
    let now = 0;
    function drawRoad(c, e, color, s) {
      const [a, b] = EV[e];
      const x0 = SX(U.lerp(VX[a].x, VX[b].x, 0.16)), y0 = SY(U.lerp(VX[a].y, VX[b].y, 0.16));
      const x1 = SX(U.lerp(VX[a].x, VX[b].x, 0.84)), y1 = SY(U.lerp(VX[a].y, VX[b].y, 0.84));
      c.lineCap = 'round';
      c.strokeStyle = '#120d18'; c.lineWidth = Math.max(4, s * 0.17); c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke();
      c.strokeStyle = color; c.lineWidth = Math.max(2.5, s * 0.11); c.stroke();
    }
    cv.onresize = () => { clampPan(); dirty(); };

    /* ---------- pointer: pan / pinch / tap ---------- */
    const ptrs = new Map();
    let drag = null, pinch = null;
    function pd(e) {
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      const p = cv.local(e); ptrs.set(e.pointerId, p);
      if (ptrs.size === 1) drag = { x: p.x, y: p.y, ox: view.ox, oy: view.oy, moved: false };
      else if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, z: view.z }; if (drag) drag.moved = true; }
    }
    function pm(e) {
      if (!ptrs.has(e.pointerId)) return;
      const p = cv.local(e); ptrs.set(e.pointerId, p);
      if (pinch && ptrs.size >= 2) {
        const [a, b] = [...ptrs.values()];
        view.z = U.clamp(pinch.z * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d, 1, 3);
        if (view.z === 1) { view.ox = 0; view.oy = 0; }
        clampPan(); dirty(); return;
      }
      if (!drag) return;
      const dx = p.x - drag.x, dy = p.y - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) > 9) drag.moved = true;
      if (drag.moved && view.z > 1) { view.ox = drag.ox + dx; view.oy = drag.oy + dy; clampPan(); dirty(); }
    }
    function pu(e) {
      if (!ptrs.has(e.pointerId)) return;
      const p = cv.local(e);
      if (drag && !drag.moved && ptrs.size === 1 && e.type === 'pointerup') tap(p.x, p.y);
      ptrs.delete(e.pointerId);
      if (ptrs.size < 2) pinch = null;
      if (!ptrs.size) drag = null;
    }
    function wheel(e) { e.preventDefault(); setZoom(view.z * (e.deltaY < 0 ? 1.15 : 1 / 1.15)); }
    cv.cv.addEventListener('pointerdown', pd); cv.cv.addEventListener('pointermove', pm);
    cv.cv.addEventListener('pointerup', pu); cv.cv.addEventListener('pointercancel', pu);
    cv.cv.addEventListener('wheel', wheel, { passive: false });
    function tap(x, y) {
      if (!ui.place) return;
      const s = sc();
      let best = -1, bd = Math.max(30, s * 0.55);
      for (const id of ui.place.cand) {
        let px, py;
        if (ui.place.k === 'r' || ui.place.k === 'R') { const [a, b] = EV[id]; px = SX((VX[a].x + VX[b].x) / 2); py = SY((VX[a].y + VX[b].y) / 2); }
        else { px = SX(VX[id].x); py = SY(VX[id].y); }
        const d = Math.hypot(px - x, py - y);
        if (d < bd) { bd = d; best = id; }
      }
      if (best >= 0) { ui.place.sel = best; api.sfx('tick'); renderBar(); dirty(); }
    }

    /* ---------- DOM parts ---------- */
    function renderPl() {
      plEl.innerHTML = '';
      plEl.style.gridTemplateColumns = 'repeat(' + st.n + ',minmax(0,1fr))';
      const a = actor(st);
      for (let i = 0; i < st.n; i++) {
        const c = cnt(st, i);
        const el = h('div', { class: 'it-p' + (a === i ? ' on' : ''), style: { '--c': col(i) } },
          h('div', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { text: nm(i) })),
          h('div', { class: 'sc' }, h('span', { html: '<b>★' + vp(st, i) + '</b>' }), h('span', { text: '패' + sum(st.p[i].h) }),
            st.n <= 3 ? h('span', { text: '🤝' + st.p[i].x }) : null));
        if (st.ld === i) el.append(h('span', { class: 'cr', title: '교역왕', text: '👑' }));
        el.dataset.s = i;
        void c;
        plEl.append(el);
      }
    }
    function renderInfo() {
      infoEl.innerHTML = '';
      const sr = seasonRes(st);
      infoEl.append(
        h('div', { class: 'it-pill', title: '제철 땅은 건물마다 1장 더' }, h('span', { text: SE[st.rnd % 4] + ' ' + SN[st.rnd % 4] + ' 제철' }), h('span', { html: icoSvg(sr, 16) })),
        h('div', { class: 'it-pill', title: '무역선이 찾는 자원은 은행에서 2:1' }, h('span', { text: '⛵ 무역선' }), h('span', { html: icoSvg(st.sh, 16) }), h('span', { text: '2:1' })),
        h('div', { class: 'it-pill dr' }, h('span', { text: st.dn ? '가뭄 ' + st.dn : '가뭄 없음' })));
    }
    function renderHand() {
      handEl.innerHTML = '';
      const v = api.viewer();
      if (v < 0 || !st.p[v]) {
        handEl.append(h('div', { class: 'it-hide', text: api.mySeats().length ? '손패는 내 차례에 보여요 (다른 사람 손패는 장 수만 보여요)' : '구경 중 · 손패는 숨겨져 있어요' }));
        return;
      }
      st.p[v].h.forEach((n, r) => {
        handEl.append(h('div', { class: 'it-r' + (n ? '' : ' zero'), 'data-r': r }, h('span', { html: icoSvg(r, 22) }), h('span', { class: 'n', text: n }), h('span', { class: 't', text: RN[r] })));
      });
    }
    function btn(text, on, cls, dis) { const b = h('button', { class: 'btn ' + (cls || ''), text, onclick: on }); if (dis) b.disabled = true; return b; }
    function renderBar() {
      barEl.innerHTML = '';
      if (st.ph === 'E') { barEl.append(h('div', { class: 'it-hint', text: '게임 끝!' })); return; }
      const me = ctrl(), a = actor(st);
      if (ui.place && me >= 0) {
        const pl = ui.place;
        const lab = pl.k === 'S' ? '마을' : pl.k === 'R' ? '길' : BNM[pl.k];
        if (pl.sel < 0) barEl.append(h('div', { class: 'it-hint', text: '빛나는 자리를 눌러 ' + lab + ' 자리를 골라요' + (pl.cand.length ? '' : ' (자리 없음)') }));
        if (!pl.setup) barEl.append(btn('취소', () => { ui = {}; renderAll(); }));
        if (pl.sel >= 0) barEl.append(btn('여기에 ' + lab + ' 짓기', () => {
          const sel = pl.sel;
          if (pl.k === 'S') act({ t: 'set', v: sel }); else if (pl.k === 'R') act({ t: 'road', e: sel }); else act({ t: 'b', k: pl.k, i: sel });
        }, 'primary wide'));
        return;
      }
      if (me < 0) {
        let txt = nm(a) + ' 차례';
        if (st.ph === 'T') txt = st.tr.q.length ? nm(st.tr.q[0]) + '이(가) 교환 제안을 보는 중…' : nm(st.tr.f) + '이(가) 교환 상대를 고르는 중…';
        else if (st.ph === 'S') txt = nm(a) + ' 첫 ' + (st.sp ? '길' : '마을') + ' 놓는 중';
        else if (st.ph === 'R') txt = nm(a) + ' 주사위 차례';
        else if (st.ph === 'D') txt = nm(a) + '이(가) 가뭄 표지를 옮기는 중';
        barEl.append(h('div', { class: 'it-hint', text: txt }), btn('의뢰', () => openOrders()));
        return;
      }
      if (st.ph === 'R') {
        barEl.append(btn('의뢰', () => openOrders()), btn('🎲 주사위 굴리기', () => act({ t: 'roll' }), 'primary wide'));
        return;
      }
      if (st.ph === 'M') {
        barEl.append(btn('짓기', () => openBuild()), btn('교환', () => openTrade()), btn('의뢰', () => openOrders()), btn('차례 끝', () => act({ t: 'end' }), 'primary'));
        return;
      }
      barEl.append(h('div', { class: 'it-hint', text: st.ph === 'T' ? '교환 응답 중' : '고르는 중' }));
    }

    /* ---------- sheets ---------- */
    function closeOv() { if (ovEl) { ovEl.remove(); ovEl = null; } }
    function sheet(title, body, closable) {
      closeOv();
      const sh = h('div', { class: 'it-sh' },
        h('div', { class: 'it-hd' }, h('h3', { text: title }), closable ? h('button', { class: 'x', 'aria-label': '닫기', text: '✕', onclick() { ui = {}; closeOv(); renderAll(); } }) : null),
        ...body);
      ovEl = h('div', { class: 'it-ov' }, sh);
      if (closable) ovEl.addEventListener('click', (e) => { if (e.target === ovEl) { ui = {}; closeOv(); renderAll(); } });
      wrap.append(ovEl);
      return sh;
    }
    function openOrders() { ui = { mode: 'orders' }; renderOv(); }
    function openBuild() { ui = { mode: 'build' }; renderOv(); }
    function openTrade() { ui = { mode: 'trade', to: -1, g: [0, 0, 0, 0, 0], w: [0, 0, 0, 0, 0], bg: -1, bw: -1, bn: 1 }; renderOv(); }
    function myHand(me) { return me >= 0 ? st.p[me].h : [0, 0, 0, 0, 0]; }
    function renderOv() {
      const me = ctrl();
      if (ui.mode === 'orders') {
        const can = me >= 0 && st.ph === 'M' && st.cur === me;
        const rows = st.mk.map((o, k) => {
          if (o < 0) return h('div', { class: 'it-row' }, h('span', { class: 'nm muted', text: '(의뢰 없음)' }));
          const ok = can && canPay(myHand(me), ORD[o].c);
          return h('div', { class: 'it-row' },
            h('div', { style: { minWidth: 0, flex: 1 } }, h('div', { class: 'nm', text: ORD[o].nm + ' · ★' + ORD[o].v }), h('div', { class: 'cs', html: costHtml(ORD[o].c) })),
            can ? btn('납품', () => act({ t: 'od', k }), ok ? 'primary' : '', !ok) : null);
        });
        sheet('의뢰 게시판', [h('div', { class: 'it-note', text: '자원을 바치면 점수를 받아요(★1 = 5장, ★2 = 8장). 남은 의뢰 ' + st.dk.length + '장.' }), ...rows,
          h('div', { class: 'it-note', text: st.p.map((p, i) => nm(i) + ' 의뢰 ' + p.oc + '개').join(' · ') })], true);
        return;
      }
      if (ui.mode === 'build') {
        const c = cnt(st, me), hd = myHand(me);
        const rows = ['r', 's', 'c'].map((k) => {
          const left = LIM[k] - c[k];
          const cand = k === 'r' ? roadSpots(st, me) : k === 's' ? settleSpots(st, me, false) : citySpots(st, me);
          const pay0 = canPay(hd, COST[k]);
          const ok = pay0 && left > 0 && cand.length > 0;
          const why = !left ? '다 썼어요' : !cand.length ? (k === 's' ? '길을 먼저 이어요' : k === 'c' ? '마을이 있어야' : '자리 없음') : !pay0 ? '자원 부족' : '';
          return h('div', { class: 'it-row' },
            h('div', { style: { minWidth: 0, flex: 1 } }, h('div', { class: 'nm', text: BNM[k] + (k === 's' ? ' ★1' : k === 'c' ? ' ★2' : '') + ' · 남은 ' + left }),
              h('div', { class: 'cs', html: costHtml(COST[k]) + (why ? '<span class="muted" style="font-family:var(--f-body);font-size:11.5px">' + why + '</span>' : '') })),
            btn('짓기', () => { ui = { place: { k, cand, sel: -1 } }; closeOv(); renderAll(); dirty(); }, ok ? 'primary' : '', !ok));
        });
        sheet('짓기', [...rows, h('div', { class: 'it-note', text: '마을은 내 길 끝에, 다른 건물과 한 칸 떨어져야 해요. 도시는 내 마을을 바꿔 지어요(생산 2배).' })], true);
        return;
      }
      if (ui.mode === 'trade' || ui.mode === 'counter') { renderTrade(me); return; }
      // derived (mandatory) sheets
      if (me < 0) { closeOv(); return; }
      if (st.ph === 'D') {
        const sel = ui.dn || 0;
        const nums = [2, 3, 4, 5, 6, 8, 9, 10, 11, 12].map((n) => {
          const who = new Set();
          for (let i = 0; i < NH; i++) if (isRes(st, i) && numOf(st, i) === n) for (const v of HV[i]) { const o = own(st, v); if (o >= 0) who.add(o); }
          const b = h('button', { class: 'btn' + (sel === n ? ' on' : ''), onclick() { ui.dn = n; api.sfx('tick'); renderOv(); } },
            h('span', { text: n }), h('span', { class: 'dots' }, ...[...who].map((o) => h('i', { style: { '--c': col(o) } }))));
          if (n === st.dn) b.disabled = true;
          return b;
        });
        sheet('🌪 폭풍! 가뭄 표지 옮기기', [
          h('div', { class: 'it-note', text: '고른 숫자의 땅은 다음 7이 나올 때까지 자원이 안 나와요. 점은 그 숫자 땅에 건물이 있는 사람이에요.' }),
          h('div', { class: 'it-nums' }, ...nums),
          h('div', { class: 'it-act' }, btn(sel ? sel + '번 땅에 가뭄' : '숫자를 골라요', () => act({ t: 'dr', n: sel }), 'primary', !sel))], false);
        return;
      }
      if (st.ph === 'T' && st.tr.q.length && st.tr.q[0] === me) {
        const tr = st.tr, hd = myHand(me), ok = canPay(hd, tr.w);
        sheet(nm(tr.f) + '의 교환 제안', [
          h('div', { class: 'it-row' }, h('span', { class: 'nm', text: '받을 것' }), h('div', { class: 'cs', html: costHtml(tr.g) })),
          h('div', { class: 'it-row' }, h('span', { class: 'nm', text: '줄 것' }), h('div', { class: 'cs', html: costHtml(tr.w) + (ok ? '' : '<span class="muted" style="font-family:var(--f-body);font-size:12px">모자라요</span>') })),
          h('div', { class: 'it-note', html: '내 손: ' + costHtml(hd) }),
          h('div', { class: 'it-act' },
            btn('거절', () => act({ t: 'no' })),
            btn('역제안', () => { ui = { mode: 'counter', to: tr.f, g: tr.w.map((x, i) => Math.min(x, hd[i])), w: tr.g.slice(), bg: -1, bw: -1, bn: 1 }; renderOv(); }),
            btn('수락', () => act({ t: 'ok' }), 'primary', !ok))], false);
        return;
      }
      if (st.ph === 'T' && !st.tr.q.length && st.tr.f === me) {
        const tr = st.tr, hd = myHand(me);
        const rows = [];
        for (let o = 0; o < st.n; o++) {
          if (o === me || !tr.r[o]) continue;
          const r = tr.r[o];
          let txt = r === 1 ? '✓ 수락' : r === 2 ? '✗ 거절' : '↺ 역제안';
          let html = '';
          if (r === 3) html = '받기 ' + costHtml(tr.c[o][0]) + ' · 주기 ' + costHtml(tr.c[o][1]);
          const can = r === 1 || (r === 3 && canPay(hd, tr.c[o][1]));
          rows.push(h('div', { class: 'it-row' },
            h('div', { style: { minWidth: 0, flex: 1 } }, h('div', { class: 'nm', html: '<span class="dot" style="--c:' + col(o) + '"></span> ' + nm(o) + ' · ' + txt }), html ? h('div', { class: 'cs', html }) : null),
            r !== 2 ? btn('교환', () => act({ t: 'tk', s: o }), can ? 'primary' : '', !can) : null));
        }
        sheet('교환 응답', [
          h('div', { class: 'it-note', html: '내 제안: 주기 ' + costHtml(tr.g) + ' · 받기 ' + costHtml(tr.w) }),
          ...rows, h('div', { class: 'it-act' }, btn('그만두기', () => act({ t: 'cx' })))], false);
        return;
      }
      closeOv();
    }
    function renderTrade(me) {
      const T = ui, hd = myHand(me), counter = T.mode === 'counter';
      const body = [];
      if (!counter) {
        const ch = [h('button', { class: 'btn' + (T.to === -1 ? ' on' : ''), text: '모두에게', onclick() { T.to = -1; renderOv(); } })];
        for (let i = 0; i < st.n; i++) if (i !== me) ch.push(h('button', { class: 'btn' + (T.to === i ? ' on' : ''), onclick() { T.to = i; renderOv(); } }, h('span', { class: 'dot', style: { '--c': col(i) } }), nm(i)));
        ch.push(h('button', { class: 'btn' + (T.to === 'bank' ? ' on' : ''), text: '🏦 은행·항구', onclick() { T.to = 'bank'; renderOv(); } }));
        body.push(h('div', { class: 'it-chips' }, ...ch));
      } else body.push(h('div', { class: 'it-note', text: nm(T.to) + '에게 내 조건을 다시 보내요.' }));
      if (T.to === 'bank') {
        const rt = rates(st, me);
        body.push(h('div', { class: 'it-lb', text: '줄 자원 (비율)' }));
        body.push(h('div', { class: 'it-stp' }, ...[0, 1, 2, 3, 4].map((r) => {
          const b = h('button', { class: 'btn' + (T.bg === r ? ' on' : ''), style: { flexDirection: 'column', gap: '0', minHeight: '54px', padding: '2px', background: T.bg === r ? 'var(--brass)' : '' }, onclick() { T.bg = r; if (T.bw === r) T.bw = -1; T.bn = 1; renderOv(); } },
            h('span', { html: icoSvg(r, 20) }), h('span', { class: 'mono', style: { fontSize: '12px' }, text: rt[r] + ':1 (' + hd[r] + ')' }));
          if (hd[r] < rt[r]) b.disabled = true;
          return b;
        })));
        body.push(h('div', { class: 'it-lb', text: '받을 자원' }));
        body.push(h('div', { class: 'it-stp' }, ...[0, 1, 2, 3, 4].map((r) => {
          const b = h('button', { class: 'btn', style: { minHeight: '48px', padding: '2px', background: T.bw === r ? 'var(--brass)' : '' }, onclick() { T.bw = r; renderOv(); } }, h('span', { html: icoSvg(r, 22) }));
          if (r === T.bg) b.disabled = true;
          return b;
        })));
        const max = T.bg >= 0 ? Math.floor(hd[T.bg] / rt[T.bg]) : 0;
        T.bn = U.clamp(T.bn, 1, Math.max(1, max));
        const ok = T.bg >= 0 && T.bw >= 0 && max >= 1;
        body.push(h('div', { class: 'it-act' },
          btn('−', () => { T.bn--; renderOv(); }, '', T.bn <= 1), h('div', { class: 'it-big', style: { flex: 1 }, html: ok ? costHtml([0, 1, 2, 3, 4].map((i) => (i === T.bg ? rt[T.bg] * T.bn : 0))) + ' → ' + costHtml([0, 1, 2, 3, 4].map((i) => (i === T.bw ? T.bn : 0))) : '<span class="muted">줄 것과 받을 것을 골라요</span>' }),
          btn('+', () => { T.bn++; renderOv(); }, '', T.bn >= max)));
        body.push(h('div', { class: 'it-act' }, btn('은행과 교환', () => act({ t: 'bank', g: T.bg, w: T.bw, n: T.bn }), 'primary', !ok)));
        body.push(h('div', { class: 'it-note', text: '기본 ' + (st.n === 2 ? '3' : '4') + ':1 · 3:1 항구 · 2:1 전용 항구(내 건물이 닿아 있을 때) · ⛵무역선 자원 2:1' }));
        sheet('교환하기', body, true);
        return;
      }
      const col5 = (arr, kind) => h('div', { class: 'it-stp' }, ...[0, 1, 2, 3, 4].map((r) => {
        const other = kind === 'g' ? T.w : T.g;
        const up = h('button', { 'aria-label': RN[r] + ' 하나 더', text: '+', onclick() { arr[r]++; other[r] = 0; api.sfx('tick'); renderOv(); } });
        const dn = h('button', { 'aria-label': RN[r] + ' 하나 빼기', text: '−', onclick() { arr[r]--; api.sfx('tick'); renderOv(); } });
        if (kind === 'g' ? arr[r] >= hd[r] : arr[r] >= 9) up.disabled = true;
        if (arr[r] <= 0) dn.disabled = true;
        return h('div', { class: 'it-sc ' + kind }, up, h('div', { class: 'v', html: icoSvg(r, 18) + arr[r] }), dn, kind === 'g' ? h('div', { class: 'hv', text: '내 ' + hd[r] }) : null);
      }));
      body.push(h('div', { class: 'it-lb', text: '내가 줄 것' }), col5(T.g, 'g'), h('div', { class: 'it-lb', text: '내가 받을 것' }), col5(T.w, 'w'));
      const ok = sum(T.g) > 0 && sum(T.w) > 0 && canPay(hd, T.g);
      if (counter) body.push(h('div', { class: 'it-act' }, btn('돌아가기', () => { ui = {}; renderOv(); }), btn('역제안 보내기', () => act({ t: 'ct', g: T.g, w: T.w }), 'primary', !ok)));
      else body.push(h('div', { class: 'it-act' }, btn('제안하기 (' + (3 - st.tc) + '번 남음)', () => act({ t: 'of', g: T.g, w: T.w, to: T.to }), 'primary', !ok || st.tc >= 3)));
      sheet(counter ? '역제안' : '교환하기', body, !counter);
    }

    /* ---------- dice / events ---------- */
    const PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };
    function dieEl(v) { const d = h('div', { class: 'it-die' }); for (let i = 0; i < 9; i++) d.append(h('i', { class: PIPS[v].includes(i) ? 'on' : '' })); return d; }
    function showRoll(ls) {
      setBusy(true);
      api.sfx('roll');
      const d1 = dieEl(1 + U.rand(6)), d2 = dieEl(1 + U.rand(6));
      d1.classList.add('spin'); d2.classList.add('spin');
      diceEl.innerHTML = ''; diceEl.append(h('div', { class: 'row' }, d1, d2)); diceEl.style.opacity = 1;
      const face = (d) => { const v = 1 + U.rand(6); [...d.children].forEach((p, i) => p.classList.toggle('on', PIPS[v].includes(i))); };
      for (let k = 1; k < 6; k++) later(() => { face(d1); face(d2); }, k * 100);
      later(() => {
        diceEl.innerHTML = '';
        const n = ls.d[0] + ls.d[1];
        const tot = h('div', { class: 'tot' }, h('b', { text: n === 7 ? '7 · 폭풍!' : String(n) }));
        if (n === 7) (ls.l || []).forEach(([i, c]) => tot.append(h('div', { class: 'gl', text: nm(i) + ' ' + c + '장 잃음' })));
        else if (n === st.dn) tot.append(h('div', { class: 'gl', text: '가뭄 — 생산 없음' }));
        else {
          const by = {};
          (ls.g || []).forEach(([p, r, c]) => { (by[p] = by[p] || []).push(icoSvg(r, 16) + c); });
          const keys = Object.keys(by);
          if (!keys.length) tot.append(h('div', { class: 'gl', text: '아무도 못 받았어요' }));
          keys.forEach((p) => tot.append(h('div', { class: 'gl', html: '<span class="dot" style="--c:' + col(+p) + '"></span>' + escapeHtml(nm(+p)) + ' ' + by[p].join(' ') })));
        }
        diceEl.append(h('div', { class: 'row' }, dieEl(ls.d[0]), dieEl(ls.d[1])), tot);
        hl = { n, until: performance.now() + 1600 / sp() }; dirty();
        api.sfx(n === 7 ? 'thud' : 'chip');
        if (n === 7) api.buzz(40);
        gains(ls.g || []);
        later(() => { diceEl.style.opacity = 0; setBusy(false); }, 1100);
      }, 600);
    }
    function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
    function gains(g) {
      const by = {};
      g.forEach(([p, , c]) => { by[p] = (by[p] || 0) + c; });
      Object.keys(by).forEach((p) => { const el = plEl.querySelector('[data-s="' + p + '"]'); if (el) el.append(h('span', { class: 'gn', text: '+' + by[p] })); });
      const v = api.viewer();
      g.forEach(([p, r]) => { if (+p === v) { const el = handEl.querySelector('[data-r="' + r + '"]'); if (el) el.classList.add('flash'); } });
    }
    function onEvent(ls, prev) {
      if (!ls || !ls.id) return;
      if (ls.k === 'roll') { showRoll(ls); return; }
      if (ls.k === 'b') { api.sfx(ls.b === 'r' ? 'tick' : 'thud'); if (ls.g && ls.g.length) gains(ls.g); }
      if (ls.k === 'od') { api.sfx('win'); api.toast(nm(ls.s) + ' 의뢰 「' + ORD[ls.o].nm + '」 ★' + ORD[ls.o].v); }
      if (ls.k === 'tx' && !ls.fail) {
        api.sfx('chip'); api.toast(nm(ls.s) + ' ↔ ' + nm(ls.o) + ' 교환 성사!');
        if (ls.ld >= 0) later(() => api.toast('👑 ' + nm(ls.ld) + ' 교역왕! (+2점)'), 1300);
      }
      if (ls.k === 'tx' && ls.fail && api.canAct(ls.s)) api.toast('교환이 성사되지 않았어요');
      if (ls.k === 'of') { api.sfx('pop'); if (api.canAct(st.tr ? st.tr.q[0] : -1) && !multi()) api.buzz(20); }
      if (ls.k === 'dr') api.sfx('whoosh');
      if (ls.k === 'bank') api.sfx('chip');
      void prev;
    }

    function setupPlacement() {
      const me = ctrl();
      if (me >= 0 && st.ph === 'S') {
        const k = st.sp === 0 ? 'S' : 'R';
        if (!ui.place || ui.place.k !== k) ui = { place: { k, setup: true, cand: st.sp === 0 ? settleSpots(st, me, true) : setupRoads(st), sel: -1 } };
      }
    }
    function renderAll() {
      renderPl(); renderInfo(); renderHand();
      setupPlacement();
      renderBar(); renderOv();
      logEl.innerHTML = '';
      if (st.lg) logEl.append(h('span', { text: st.lg }));
      dirty();
    }

    return {
      update(s, prev) {
        const first = !st || !prev || prev.mp !== s.mp;
        st = s;
        if (first) { calcBox(); view.z = 1; view.ox = 0; view.oy = 0; stcKey = ''; }
        const key = [s.ph, s.cur, s.so, s.sp, s.tr ? s.tr.q.join('.') + ':' + s.tr.f : '', api.viewer()].join('|');
        if (key !== uiKey) {
          const keepPlace = ui.place && !ui.place.setup && s.ph === 'M';
          if (!keepPlace) ui = {};
          uiKey = key;
        } else if (ui.place && !ui.place.setup) {
          // 자원이 바뀌었을 수 있음 — 후보 다시 계산
          const me = ctrl();
          if (me < 0) ui = {};
        }
        renderAll();
        if (s.last && s.last.id !== lastSeen) {
          const was = lastSeen; lastSeen = s.last.id;
          if (was >= 0) onEvent(s.last, prev);
        }
      },
      destroy() {
        dead = true;
        timers.forEach(clearTimeout); timers.clear();
        if (raf) cancelAnimationFrame(raf);
        if (busy) api.setBusy(false);
        cv.cv.removeEventListener('wheel', wheel);
        cv.destroy(); wrap.remove(); style.remove();
      },
    };
  }

  /* ======================= register ======================= */
  L.register({
    id: 'isletrade', name: '개척섬 교역', tag: '자원 · 교환 · 개척', cat: '보드',
    blurb: '육각 섬에 마을을 세우고, 주사위가 나온 땅에서 자원을 받아 길·마을·도시를 지어요. 모자란 자원은 서로 흥정해 바꿔요!',
    tint: '#1f5a63',
    icon: '<path d="M28 5l17 10v20L28 45 11 35V15z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M20 31l8-7 8 7v9H20z" fill="currentColor"/><path d="M15 22h6M35 22h6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="12" cy="50" r="4" fill="currentColor"/><circle cx="44" cy="50" r="4" fill="currentColor"/><path d="M18 50h20" stroke="currentColor" stroke-width="2.5" stroke-dasharray="3 3"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 3, hidden: true, aiDelay: 700,
    options: [
      { id: 'map', label: '섬 모양', choices: [{ v: 'rand', label: '무작위' }, { v: 'round', label: '둥근 섬' }, { v: 'wild', label: '들쭉날쭉 섬' }, { v: 'long', label: '긴 섬' }], def: 'rand' },
      { id: 'goal', label: '목표 점수', choices: [{ v: 8, label: '8점 (짧게)' }, { v: 10, label: '10점' }, { v: 12, label: '12점 (길게)' }], def: 10 },
    ],
    quick: [
      '마을·도시·의뢰 카드로 10점을 먼저 모으면 승리!',
      '내 차례: 주사위 → (교환) → 짓기 → 「차례 끝」',
      '주사위 합과 같은 숫자 땅 모서리에 내 마을이 있으면 그 자원을 받아요.',
    ],
    rules: [
      { h: '목표', p: [
        '섬에 길·마을·도시를 지어 점수를 모아요. 목표 점수(기본 10점)에 먼저 닿는 사람이 이겨요.',
        '점수: 마을 1점 · 도시 2점 · 의뢰 카드 1~2점 · 교역왕 2점.'] },
      { h: '섬과 자원', p: [
        '섬은 판마다 새로 만들어져요. 땅 5종에서 자원이 나와요: 숲 → 나무, 진흙밭 → 흙, 목화밭 → 솜, 논 → 쌀, 철광산 → 철. 화산에선 아무것도 안 나와요.',
        '땅마다 숫자(2~12)가 있어요. 6·8(빨간 숫자)이 가장 잘 나오고, 2·12는 드물어요. 숫자 밑 점이 많을수록 잘 나와요.'] },
      { h: '시작', p: [
        '돌아가며 마을 1개 + 그 옆 길 1개를 놓고, 거꾸로 한 번 더 놓아요(마지막 사람이 연달아 2번).',
        '두 번째 마을 옆 땅의 자원을 1장씩 받고 시작해요.'] },
      { h: '차례에 할 일', p: [
        '① 주사위 2개를 굴려요. 합과 같은 숫자 땅 모서리에 건물이 있으면 모두가 자원을 받아요 (마을 1장, 도시 2장).',
        '② 교환: 다른 사람에게 제안하거나 은행·항구와 바꿔요.',
        '③ 짓기·의뢰: 자원을 내고 짓거나 의뢰를 끝내요. 순서는 자유, 여러 번 해도 돼요.',
        '④ 「차례 끝」을 누르면 다음 사람 차례.'] },
      { h: '짓는 값', p: [
        '길: 나무 1 + 흙 1 — 내 길이나 건물에 이어서 놓아요.',
        '마을: 나무 1 + 흙 1 + 솜 1 + 쌀 1 — 내 길 끝에, 다른 건물과 한 칸 이상 떨어져서.',
        '도시: 쌀 2 + 철 3 — 내 마을을 도시로 바꿔요. 자원을 2장씩 받아요.',
        '남은 개수: 길 15 · 마을 5 · 도시 4.'] },
      { h: '교환과 흥정', p: [
        '「교환」에서 줄 것과 받을 것을 −/+로 정하고 모두에게 또는 한 사람에게 제안해요(차례마다 3번까지).',
        '받은 사람은 수락 · 거절 · 역제안(조건 바꿔 보내기)을 골라요. 여러 명이 수락하면 제안한 사람이 상대를 골라요.',
        '은행은 같은 자원 4장 → 원하는 자원 1장. 항구에 내 건물이 닿아 있으면 3:1(아무 자원) 또는 2:1(그 자원)로 바꿔요.',
        '2명이 할 때는 은행이 3:1이에요.'] },
      { h: '이 섬만의 규칙', p: [
        '🌸 계절: 한 바퀴마다 봄 → 여름 → 가을 → 겨울. 제철 땅(봄 솜 · 여름 쌀 · 가을 나무 · 겨울 철)은 건물마다 1장 더 줘요.',
        '⛵ 무역선: 한 바퀴마다 무역선이 와서 자원 하나를 찾아요. 그 자원은 누구나 은행에서 2:1로 바꿀 수 있어요.',
        '🌪 7이 나오면 폭풍: 손패가 9장 이상인 사람은 절반을 잃어요(많은 것부터 자동). 굴린 사람은 가뭄 표지를 숫자 하나에 옮겨요 — 그 숫자 땅은 다음 7까지 자원이 안 나와요.',
        '📜 의뢰 카드: 게시판의 의뢰 3장 중 하나에 자원을 바치면 1점(5장) 또는 2점(8장). 끝낸 의뢰 자리엔 새 의뢰가 와요.',
        '👑 교역왕: 다른 사람과 교환을 3번 이상 하고 가장 많이 한 사람이 2점. 더 많이 한 사람이 나오면 넘어가요.'] },
      { h: '예시', p: [
        '내 마을이 6번 숲과 9번 논 사이에 있어요. 주사위 4+2=6 → 나무 1장! 가을이면 제철이라 2장.',
        '마을을 지으려는데 솜이 없어요 → 「교환」에서 흙 1을 주고 솜 1을 받는 제안을 모두에게. 철수가 수락하면 바로 바꿔요.',
        '철이 5장 남아요 → 은행에서 철 4장 = 쌀 1장. 무역선이 철을 찾는 계절이면 철 2장 = 쌀 1장!'] },
      { h: '조작', p: [
        '「짓기」에서 고른 뒤 판에서 빛나는 자리를 누르고 「여기에 짓기」.',
        '판은 +/− 버튼, 두 손가락 벌리기, 마우스 휠로 확대하고 끌어서 움직여요.',
        '한 폰으로 여럿이 하면 이름이 뜰 때 폰을 넘겨요 — 교환 제안을 받은 사람에게도 폰이 가요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 어려움은 흥정을 잘하고 1등에게는 잘 안 바꿔 줘요.'] },
    ],
    tutorial: [
      { sel: '.it-board', text: '육각 땅마다 숫자가 있어요. 주사위 합이 그 숫자면, 그 땅 모서리에 건물이 있는 사람이 자원을 받아요.' },
      { sel: '.it-bar', text: '처음엔 마을 1개와 길 1개를 두 번 놓아요. 빛나는 자리를 누르고 「여기에 짓기」! 숫자 6·8 근처가 좋아요.' },
      { sel: '.it-hand', text: '아래는 내 자원이에요: 나무·흙·솜·쌀·철. 다른 사람 손패는 장 수만 보여요.' },
      { sel: '.it-info', text: '계절마다 제철 땅은 1장 더! ⛵무역선이 찾는 자원은 은행에서 2:1. 가뭄 숫자 땅은 쉬어요.' },
      { sel: '.it-pl', text: '★는 점수예요. 모자란 자원은 「교환」으로 흥정해요 — 교환을 가장 많이 하면 교역왕 2점!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { genBoard, vp, cnt, rates, settleSpots, roadSpots, NV, NE, NH, ORD },
  });
})();
