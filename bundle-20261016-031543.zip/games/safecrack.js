/* 금고 털기 — simultaneous-round safe-cracking race (1–4 thieves).
   Every thief has their OWN safe of the same type (same number of wheels / dial numbers, different secret combination),
   so every clue is public (nothing to hide on a shared phone). Each round all thieves secretly pick one action:
     t = try a combination (each wheel answers with a click: 철컥 exact / 딸깍딸깍 close / 딸깍 near / … far),
     l = stethoscope on one wheel (silent: click + which way to turn), d = drill one wheel (exact digit, LOUD),
     r = throw a pebble (lure a guard to another thief's safe), h = hide in the shadows.
   Then everything resolves at once: guards walk (or run to a pebble), anyone not hiding where a guard stops is caught
   (action lost, alarm +2), clues are given, the shared alarm rises. First to open wins; alarm full → police → most
   progress wins.
   State (JSON, small): { n, sf, W, N, K, am, al, r, ph 'c'|'e', w[], why, ky, sc[] (scrambled combos), h[][] (history
   strings), lt[] / dt[] / rt[] (tools left), nz[] (noise made), gp[] / gd[] (guards), ch[] (scrambled choice | null),
   seq, last }
   history entry: 't'+nums+fbs | 'l'+wheel+num+fb+dir | 'd'+wheel+num | 'h' | 'r'+target | 'x'+action (caught)
   last = { id, r, g0:[[p,d]...], lu (lured seat or -1), c:[caught seats], o:[opened seats], al0, a:'chars per seat' } */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- safes ---------- */
  const SAFES = [
    { id: 'shop', n: '구멍가게 금고', W: 3, N: 20, b: [2, 5], bud: 7, gu: 1, loot: 0, d: '3칸 · 숫자 0–19 · 처음 하기 좋아요' },
    { id: 'bank', n: '은행 금고', W: 3, N: 30, b: [2, 6], bud: 8, gu: 1, loot: 1, d: '3칸 · 숫자 0–29 · 기본' },
    { id: 'rust', n: '녹슨 금고', W: 3, N: 24, b: [3], bud: 9, gu: 1, loot: 0, d: '3칸 · 0–23 · 녹슬어서 딸깍 소리가 한 가지뿐' },
    { id: 'jewel', n: '보석상 금고', W: 4, N: 30, b: [2, 6], bud: 8, gu: 1, loot: 2, d: '4칸 · 숫자 0–29' },
    { id: 'museum', n: '박물관 금고', W: 4, N: 30, b: [2, 6], bud: 9, gu: 2, loot: 3, d: '4칸 · 0–29 · 경비가 둘' },
    { id: 'palace', n: '왕궁 금고', W: 5, N: 40, b: [3, 8], bud: 10, gu: 2, loot: 4, d: '5칸 · 0–39 · 경비 둘 · 가장 어려워요' },
  ];
  const RMAX = 20, TURN = 0.25, CAUGHT = 2, NOISE = { t: 1, l: 0, d: 3, r: 1, h: 0 };
  const TOOLS = { l: 2, d: 1, r: 1 };
  const FBN = ['철컥!', '딸깍딸깍', '딸깍', '…'];

  const ch = (v) => String.fromCharCode(48 + v);
  const num = (c) => c.charCodeAt(0) - 48;
  const dist = (a, b, N) => { const d = Math.abs(a - b) % N; return Math.min(d, N - d); };
  /* click strength: 0 exact, 1 close (strong), 2 near (weak), 3 nothing */
  function fbOf(S, d) { if (d === 0) return 0; if (d <= S.b[0]) return 1; if (S.b.length > 1 && d <= S.b[1]) return 2; return 3; }
  /* which way to turn from v to reach c (shorter way): '+' bigger numbers, '-' smaller, '=' right here */
  function dirOf(v, c, N) { const dd = ((c - v) % N + N) % N; return dd === 0 ? '=' : dd <= N / 2 ? '+' : '-'; }
  const vaultPos = (i) => 2 + 2 * i;

  /* secret combos — lightly scrambled so a peek at the raw state is not a giveaway */
  function encC(s, i, arr) { return arr.map((v, w) => ch((v + s.ky * (i + 1) + 7 * w) % s.N)).join(''); }
  function decC(s, i) { const t = s.sc[i]; const out = []; for (let w = 0; w < s.W; w++) out.push((((num(t[w]) - s.ky * (i + 1) - 7 * w) % s.N) + s.N) % s.N); return out; }
  /* chosen actions — same idea */
  const ACH = 'tldrh';
  function encA(s, i, a) {
    const raw = a.t + (a.t === 't' ? a.v.map(ch).join('') : a.t === 'l' ? ch(a.w) + ch(a.v) : a.t === 'd' ? ch(a.w) : a.t === 'r' ? ch(a.s) : '');
    let o = ''; for (let q = 0; q < raw.length; q++) o += String.fromCharCode(48 + ((raw.charCodeAt(q) - 48 + 11 * i + 5 * s.r + 3 * q) % 75));
    return o;
  }
  function decA(s, i) {
    const x = s.ch[i]; if (x == null) return null;
    let raw = ''; for (let q = 0; q < x.length; q++) raw += String.fromCharCode(48 + ((((x.charCodeAt(q) - 48 - 11 * i - 5 * s.r - 3 * q) % 75) + 75) % 75));
    const t = raw[0], a = { t };
    if (t === 't') a.v = [...raw.slice(1)].map(num);
    else if (t === 'l') { a.w = num(raw[1]); a.v = num(raw[2]); }
    else if (t === 'd') a.w = num(raw[1]);
    else if (t === 'r') a.s = num(raw[1]);
    return a;
  }

  /* ---------- rules ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(1, Math.min(4, players.length));
    let sf = SAFES.findIndex((x) => x.id === opts.safe);
    if (sf < 0) sf = opts.safe === 'rnd' ? Math.floor(Math.random() * SAFES.length) : 1;
    const S = SAFES[sf];
    const s = {
      n, sf, W: S.W, N: S.N, K: 2 * n + 3, am: S.bud * n, al: 0, r: 0, ph: 'c', w: null, why: '',
      ky: 1 + Math.floor(Math.random() * (S.N - 1)), sc: [], h: [], lt: [], dt: [], rt: [], nz: [],
      gp: [], gd: [], ch: Array(n).fill(null), zz: Array(n).fill(0), seq: 0, last: null, hl: opts.help === 'off' ? 0 : 1,
    };
    for (let i = 0; i < n; i++) {
      const c = []; for (let w = 0; w < S.W; w++) c.push(Math.floor(Math.random() * S.N));
      s.sc.push(encC(s, i, c)); s.h.push([]); s.lt.push(TOOLS.l); s.dt.push(TOOLS.d); s.rt.push(n > 1 ? TOOLS.r : 0); s.nz.push(0);
    }
    if (S.gu >= 2) { s.gp = [0, s.K - 1]; s.gd = [1, -1]; } else { s.gp = [0]; s.gd = [1]; }
    return s;
  }
  function actor(s) {
    if (s.ph !== 'c') return null;
    const r = []; for (let i = 0; i < s.n; i++) if (s.ch[i] == null) r.push(i);
    return r;
  }
  /* one guard step: usually keeps walking, sometimes turns around; bounces at the corridor ends */
  function gstep(p, d, turn, K) { if (turn) d = -d; if (p + d < 0 || p + d >= K) d = -d; return [p + d, d]; }
  /* chance that a patrolling guard stops at this seat's safe this round (pebbles not counted) */
  function danger(s, seat) {
    const v = vaultPos(seat); let safe = 1;
    for (let g = 0; g < s.gp.length; g++) {
      let p = 0;
      const a = gstep(s.gp[g], s.gd[g], false, s.K), b = gstep(s.gp[g], s.gd[g], true, s.K);
      if (a[0] === v) p += 1 - TURN; if (b[0] === v) p += TURN;
      safe *= 1 - p;
    }
    return Math.round((1 - safe) * 100) / 100;
  }
  function validate(s, seat, a) {
    if (!a || typeof a !== 'object' || !ACH.includes(a.t) || typeof a.t !== 'string' || a.t.length !== 1) throw new Error('bad action');
    if (s.zz[seat]) return { t: 'h' };   // caught last round: must stay hidden this round
    const okN = (v) => Number.isInteger(v) && v >= 0 && v < s.N, okW = (w) => Number.isInteger(w) && w >= 0 && w < s.W;
    if (a.t === 't') { if (!Array.isArray(a.v) || a.v.length !== s.W || !a.v.every(okN)) throw new Error('bad combo'); return { t: 't', v: a.v.slice() }; }
    if (a.t === 'l') { if (s.lt[seat] <= 0) throw new Error('no stethoscope'); if (!okW(a.w) || !okN(a.v)) throw new Error('bad listen'); return { t: 'l', w: a.w, v: a.v }; }
    if (a.t === 'd') { if (s.dt[seat] <= 0) throw new Error('no drill'); if (!okW(a.w)) throw new Error('bad drill'); return { t: 'd', w: a.w }; }
    if (a.t === 'r') { if (s.rt[seat] <= 0) throw new Error('no pebble'); if (!Number.isInteger(a.s) || a.s < 0 || a.s >= s.n || a.s === seat) throw new Error('bad target'); return { t: 'r', s: a.s }; }
    return { t: 'h' };
  }
  function apply(s, seat, a) {
    if (s.ph !== 'c') throw new Error('not choosing');
    if (!(seat >= 0 && seat < s.n)) throw new Error('bad seat');
    if (s.ch[seat] != null) throw new Error('already chose');
    s.ch[seat] = encA(s, seat, validate(s, seat, a));
    if (s.ch.every((x) => x != null)) resolve(s);
    return s;
  }
  function resolve(s) {
    const S = SAFES[s.sf], n = s.n, A = [];
    for (let i = 0; i < n; i++) A.push(decA(s, i));
    const g0 = s.gp.map((p, g) => [p, s.gd[g]]), al0 = s.al;
    // pebbles: one lured safe (random among throws); the nearest guard runs there, the others patrol
    const lures = []; for (let i = 0; i < n; i++) if (A[i].t === 'r') lures.push(A[i].s);
    const lu = lures.length ? lures[Math.floor(Math.random() * lures.length)] : -1;
    let gl = -1;
    if (lu >= 0) { const v = vaultPos(lu); let best = 1e9; s.gp.forEach((p, g) => { const d = Math.abs(p - v); if (d < best) { best = d; gl = g; } }); }
    for (let g = 0; g < s.gp.length; g++) {
      if (g === gl) { const v = vaultPos(lu); if (v !== s.gp[g]) s.gd[g] = v > s.gp[g] ? 1 : -1; s.gp[g] = v; continue; }
      const nx = gstep(s.gp[g], s.gd[g], Math.random() < TURN, s.K); s.gp[g] = nx[0]; s.gd[g] = nx[1];
    }
    const caught = [], opened = []; let ac = '';
    for (let i = 0; i < n; i++) {
      const a = A[i]; ac += a.t;
      const exposed = a.t === 't' || a.t === 'l' || a.t === 'd';
      if (exposed && s.gp.includes(vaultPos(i))) {
        caught.push(i); s.h[i].push('x' + a.t); s.al += CAUGHT; s.nz[i] += CAUGHT; continue;
      }
      if (s.zz[i]) { s.h[i].push('z'); continue; }
      const c = decC(s, i);
      s.al += NOISE[a.t]; s.nz[i] += NOISE[a.t];
      if (a.t === 't') {
        const f = a.v.map((v, w) => fbOf(S, dist(v, c[w], s.N)));
        s.h[i].push('t' + a.v.map(ch).join('') + f.join(''));
        if (f.every((x) => x === 0)) opened.push(i);
      } else if (a.t === 'l') {
        s.lt[i]--;
        s.h[i].push('l' + a.w + ch(a.v) + fbOf(S, dist(a.v, c[a.w], s.N)) + dirOf(a.v, c[a.w], s.N));
      } else if (a.t === 'd') { s.dt[i]--; s.h[i].push('d' + a.w + ch(c[a.w])); }
      else if (a.t === 'r') { s.rt[i]--; s.h[i].push('r' + a.s); }
      else s.h[i].push('h');
    }
    s.al = Math.min(s.al, s.am + 9);
    s.last = { id: ++s.seq, r: s.r, g0, lu, c: caught, o: opened, al0, a: ac };
    s.ch = Array(n).fill(null); s.r++;
    s.zz = Array(n).fill(0); caught.forEach((i) => { s.zz[i] = 1; });
    if (opened.length) {
      const q = Math.min(...opened.map((i) => s.nz[i]));
      s.w = opened.filter((i) => s.nz[i] === q); s.ph = 'e'; s.why = 'open';
    } else if (s.al >= s.am || s.r >= RMAX) {
      s.ph = 'e'; s.why = s.al >= s.am ? 'police' : 'dawn';
      if (n === 1) s.w = [];
      else {
        const sc = []; for (let i = 0; i < n; i++) sc.push(progress(s, i));
        const best = Math.min(...sc.map((x) => x.left));
        const top = sc.filter((x) => x.left === best).map((x) => x.known);
        const bk = Math.max(...top);
        s.w = []; for (let i = 0; i < n; i++) if (sc[i].left === best && sc[i].known === bk) s.w.push(i);
      }
    }
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const S = SAFES[s.sf], w = s.w || [];
    if (s.why === 'open') {
      if (s.n === 1) {
        const f = s.al / s.am, st = f <= 0.65 ? 3 : f <= 0.85 ? 2 : 1;
        return { winners: w.slice(), title: '금고 열기 성공! ' + '★'.repeat(st) + '☆'.repeat(3 - st), text: S.n + ' · ' + s.r + '라운드 · 경보 ' + s.al + '/' + s.am };
      }
      return { winners: w.slice(), text: (w.length > 1 ? '같은 라운드에 함께 열었어요' : s.r + '라운드 만에 금고를 열었어요') + ' · ' + S.n };
    }
    const why = s.why === 'police' ? '경보가 가득 차 경찰이 왔어요' : '날이 밝아 철수했어요';
    if (s.n === 1) { const p = progress(s, 0); return { winners: [], title: '실패…', text: why + ' · ' + S.W + '칸 중 ' + p.known + '칸 알아냈어요' }; }
    if (!w.length) return { winners: [], title: '무승부', text: why };
    return { winners: w.slice(), text: why + ' · 가장 많이 알아낸 도둑이 이겨요 (' + progress(s, w[0]).known + '/' + S.W + '칸)' };
  }

  /* ---------- deduction (shared by the AI, the end score and the view's helper) ---------- */
  /* candidate numbers for each wheel of seat i (from its history); opt.mem = only use the last k clue entries (easy AI) */
  function cands(s, i, mem) {
    const S = SAFES[s.sf], N = s.N, W = s.W, ok = [];
    for (let w = 0; w < W; w++) ok.push(Array(N).fill(true));
    const hs = s.h[i];
    let used = 0;
    for (let q = hs.length - 1; q >= 0; q--) {
      const e = hs[q], t = e[0];
      if (t === 't') {
        const keepAll = !mem || used < mem; used++;
        for (let w = 0; w < W; w++) {
          const v = num(e[1 + w]), f = +e[1 + W + w];
          if (!keepAll && f !== 0) continue;
          for (let c = 0; c < N; c++) if (ok[w][c] && fbOf(S, dist(v, c, N)) !== f) ok[w][c] = false;
        }
      } else if (t === 'l') {
        const w = +e[1], v = num(e[2]), f = +e[3], dr = e[4];
        for (let c = 0; c < N; c++) if (ok[w][c] && (fbOf(S, dist(v, c, N)) !== f || dirOf(v, c, N) !== dr)) ok[w][c] = false;
      } else if (t === 'd') {
        const w = +e[1], v = num(e[2]);
        for (let c = 0; c < N; c++) ok[w][c] = c === v;
      }
    }
    return ok.map((a) => { const r = []; a.forEach((x, c) => { if (x) r.push(c); }); return r; });
  }
  function progress(s, i) {
    const C = cands(s, i);
    let known = 0, left = 0;
    C.forEach((c) => { if (c.length === 1) known++; left += Math.log(Math.max(1, c.length)); });
    return { known, left: Math.round(left * 100) / 100, C };
  }

  /* ---------- AI ---------- */
  /* best probe for one wheel: the number whose click splits the candidates most (ties: a candidate itself) */
  function bestProbe(S, N, C, withDir) {
    if (C.length === 1) return C[0];
    let best = -1, bv = 1e9;
    const inC = new Set(C), cnt = new Map();
    for (let x = 0; x < N; x++) {
      cnt.clear();
      for (const c of C) { const k = fbOf(S, dist(x, c, N)) * 3 + (withDir ? '+-='.indexOf(dirOf(x, c, N)) : 0); cnt.set(k, (cnt.get(k) || 0) + 1); }
      let e = 0; cnt.forEach((m) => { e += m * m; });
      const sc = e - (inC.has(x) ? 0.5 : 0) + Math.random() * 0.01;
      if (sc < bv) { bv = sc; best = x; }
    }
    return best;
  }
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  function nearest(c, l, N) { let b = c[0], bd = 1e9; for (const x of c) { const d = dist(x, l, N) + Math.random() * 0.5; if (d < bd) { bd = d; b = x; } } return b; }
  function lastTry(s, i) {
    for (let q = s.h[i].length - 1; q >= 0; q--) { const e = s.h[i][q]; if (e[0] === 't') return [...e.slice(1, 1 + s.W)].map(num); }
    return null;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph !== 'c' || s.ch[seat] != null) return null;
    const S = SAFES[s.sf], N = s.N, W = s.W;
    if (s.zz[seat]) return { t: 'h' };
    const C = cands(s, seat), dz = danger(s, seat), R = Math.random();
    const prod = C.reduce((p, c) => p * c.length, 1);
    const unk = []; C.forEach((c, w) => { if (c.length > 1) unk.push(w); });
    // the others' progress (all public)
    let threat = 0, threatSeat = -1;
    for (let j = 0; j < s.n; j++) {
      if (j === seat) continue;
      const pj = cands(s, j).reduce((p, c) => p * c.length, 1);
      const t = pj === 1 ? 1 : pj === 2 ? 0.5 : pj <= 4 ? 0.2 : 0;
      if (t > threat) { threat = t; threatSeat = j; }
    }
    const roundsLeft = Math.max(0, (s.am - s.al) / s.n);
    const est = Math.max(0, ...C.map((c) => (c.length <= 1 ? 0 : Math.ceil(Math.log(c.length) / Math.log(lv >= 3 ? 3.2 : 2.6)))));

    /* 1) the guard (being caught costs this round AND the next, so hiding pays from about 50 % danger) */
    let hide = false;
    if (lv <= 1) hide = dz >= 0.7 ? R < 0.5 : false;
    else if (lv === 2) hide = dz >= 0.7 ? R < 0.85 : dz >= 0.4 ? R < 0.5 : false;
    else {
      hide = dz >= 0.45;
      if (hide && threat >= 1 && prod <= 2) hide = false;        // desperate: the rival opens next round
      if (hide && R < 0.08) hide = false;                         // a misjudged gamble now and then
      // about to open while a rival still holds a pebble: sometimes duck for a round to waste it
      if (!hide && prod === 1 && threat < 1 && s.r >= 1) {
        let peb = false; for (let j = 0; j < s.n; j++) if (j !== seat && s.rt[j] > 0) peb = true;
        if (peb && Math.random() < 0.3) hide = true;
      }
    }
    /* 2) a pebble at the rival who is about to open (throwing it hides us too) */
    if (s.rt[seat] > 0 && threatSeat >= 0 && prod > 1) {
      const R2 = Math.random();
      const want = lv >= 3 ? (threat >= 1 ? 0.9 : threat >= 0.5 && hide ? 0.8 : 0) : lv === 2 ? (threat >= 1 ? 0.45 : 0) : 0.05;
      if (R2 < want) return { t: 'r', s: lv <= 1 ? pick([...Array(s.n).keys()].filter((j) => j !== seat)) : threatSeat };
    }
    if (hide) return { t: 'h' };
    /* 3) tools */
    const sizes = C.map((c) => c.length).sort((x, y) => y - x);
    const rnds = (c) => (c <= 1 ? 0 : c <= 2 ? 1 : Math.ceil(Math.log(c) / Math.log(3)));
    if (s.dt[seat] > 0 && unk.length) {
      let use = false;
      if (lv >= 3) use = (est > roundsLeft - 0.5 && rnds(sizes[1] || 1) < est) || (s.r >= 1 && rnds(sizes[0]) >= rnds(sizes[1] || 1) + 2);
      else if (lv === 2) use = (est > roundsLeft && R < 0.6) || (threat >= 1 && R < 0.4);
      else use = R < 0.07;
      if (use) { let bw = unk[0]; unk.forEach((w) => { if (C[w].length > C[bw].length) bw = w; }); return { t: 'd', w: lv <= 1 ? pick(unk) : bw }; }
    }
    if (s.lt[seat] > 0 && unk.length) {
      let bw = unk[0]; unk.forEach((w) => { if (C[w].length > C[bw].length) bw = w; });
      const c = C[bw].length, second = unk.length > 1 ? sizes[1] : 1;
      const use = lv >= 3 ? c >= 6 && rnds(second) === 0 && threat < 1 : lv === 2 ? unk.length === 1 && c >= 3 && R < 0.3 : R < 0.08;
      if (use) return { t: 'l', w: bw, v: lv >= 3 ? bestProbe(S, N, C[bw], true) : pick(C[bw]) };
    }
    /* 4) try a combination */
    let v;
    if (lv >= 3) v = C.map((c) => bestProbe(S, N, c, false));
    else if (lv === 2) {
      // a fair human-like player: mostly nudges the dial from the last try, sometimes loses track of an older clue
      const M = Math.random() < 0.25 ? cands(s, seat, 3) : C, lt = lastTry(s, seat);
      v = M.map((c, w) => (lt && Math.random() < 0.4 ? nearest(c, lt[w], N) : pick(c)));
    }
    else {
      const M = cands(s, seat, 2), lt = lastTry(s, seat);
      v = M.map((c, w) => (Math.random() < 0.22 && lt ? (lt[w] + (Math.random() < 0.5 ? 1 : -1) * (1 + Math.floor(Math.random() * 3)) + N) % N : pick(c.length ? c : [0])));
    }
    return { t: 't', v };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph !== 'c' || s.ch[seat] != null) return -1;
    const base = lv >= 3 ? 1000 : lv <= 1 ? 1700 : 1300;
    return base + Math.random() * 900;
  }

  /* ---------- sound (own tiny synth; follows the app's sound switch) ---------- */
  const Snd = {
    ac: null, nb: null,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    tone(f, d, type, vol, f2, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
        o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
        if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.1, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + d + 0.03);
      } catch (e) {}
    },
    noise(d, type, f0, f1, vol, delay) {
      const ac = this.ctx(); if (!ac) return;
      try {
        if (!this.nb) { const n = ac.sampleRate * 1.2, b = ac.createBuffer(1, n, ac.sampleRate), x = b.getChannelData(0); for (let i = 0; i < n; i++) x[i] = Math.random() * 2 - 1; this.nb = b; }
        const t = ac.currentTime + (delay || 0), src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.nb; f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + d); f.Q.value = 1.2;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + d + 0.05);
      } catch (e) {}
    },
    tick() { this.noise(0.025, 'bandpass', 4200, 3600, 0.09); },
    clk(k) {
      if (k === 0) { this.tone(150, 0.3, 'sine', 0.3, 60); this.noise(0.14, 'lowpass', 2200, 180, 0.32); this.tone(1250, 0.07, 'square', 0.04, 0, 0.02); }
      else if (k === 1) { this.noise(0.045, 'bandpass', 3400, 2800, 0.4); this.noise(0.045, 'bandpass', 3100, 2500, 0.36, 0.1); }
      else if (k === 2) this.noise(0.04, 'bandpass', 2600, 2200, 0.16);
      else this.noise(0.2, 'lowpass', 380, 200, 0.03);
    },
    drill() { this.tone(170, 0.9, 'sawtooth', 0.05, 240); this.noise(0.9, 'bandpass', 2400, 3600, 0.14); },
    steth() { this.tone(72, 0.13, 'sine', 0.3); this.tone(66, 0.13, 'sine', 0.24, 0, 0.2); },
    whistle() { this.tone(2300, 0.16, 'sine', 0.12, 2800); this.tone(2800, 0.32, 'sine', 0.12, 2000, 0.18); },
    siren() { for (let q = 0; q < 2; q++) { this.tone(620, 0.36, 'sawtooth', 0.035, 960, q * 0.72); this.tone(960, 0.36, 'sawtooth', 0.035, 620, q * 0.72 + 0.36); } },
    open() { this.tone(110, 0.45, 'sine', 0.28, 50); this.noise(0.35, 'lowpass', 900, 90, 0.26); [0, 4, 7, 12, 16].forEach((s, i) => this.tone(523 * Math.pow(2, s / 12), 0.45, 'triangle', 0.07, 0, 0.4 + i * 0.08)); },
    coins() { for (let q = 0; q < 7; q++) this.tone(2300 + Math.random() * 1800, 0.12, 'sine', 0.04, 0, 0.9 + q * 0.07 + Math.random() * 0.03); },
    pebble() { this.noise(0.05, 'bandpass', 1900, 1300, 0.22); this.noise(0.05, 'bandpass', 1500, 1000, 0.16, 0.13); },
    sel() { this.tone(880, 0.05, 'triangle', 0.05); },
    step() { this.noise(0.07, 'lowpass', 520, 180, 0.09); },
  };

  /* ---------- drawing helpers ---------- */
  const FONT = '"IBM Plex Sans KR", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif';
  const DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const MONO = '"IBM Plex Mono", ui-monospace, monospace';
  const FBC = ['#ffd45a', '#ff8a3d', '#d9b57a', '#6f6585'];
  const FBS = ['철컥', '딸깍딸깍', '딸깍', '…'];
  const LOOT = ['동전 자루', '금괴', '보석', '황금 유물', '왕관'];
  function rr(ctx, x, y, w, hh, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + hh, r); ctx.arcTo(x + w, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function legendParts(S) {
    const out = [['철컥', '정답', FBC[0]]];
    if (S.b.length > 1) out.push(['딸깍딸깍', '±' + S.b[0], FBC[1]], ['딸깍', '±' + S.b[1], FBC[2]]);
    else out.push(['딸깍', '±' + S.b[0], FBC[1]]);
    out.push(['…', '더 멀어요', '#a99fbb']);
    return out;
  }
  /* feedback index → display (rusty safes have only one click) */
  const fbCol = (S, f) => (S.b.length === 1 && f === 1 ? FBC[1] : FBC[f]);
  const fbWord = (S, f) => (S.b.length === 1 && f === 1 ? '딸깍' : FBS[f]);

  const CSS = `
.sc-bot{position:absolute;left:0;right:0;bottom:0;display:flex;flex-direction:column;gap:8px;padding:8px 10px 10px;z-index:3}
.sc-tools{display:flex;gap:6px}
.sc-tools .btn{flex:1;min-width:0;min-height:48px;padding:2px 4px;font-size:13px;gap:0;flex-direction:column;line-height:1.1;background:#2b2333}
.sc-tools .btn b{font-size:15px;font-weight:400;line-height:1.1}
.sc-tools .btn small{font-family:var(--f-mono);font-size:10.5px;color:var(--muted);font-weight:700}
.sc-tools .btn.on{background:#5a4416;border-color:var(--brass);color:#ffe7b0;box-shadow:0 0 0 2px rgba(227,174,69,.35)}
.sc-tools .btn.on small{color:#ffe7b0}
.sc-tools .btn:disabled{opacity:.36}
.sc-go{min-height:52px;font-size:16px;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sc-go.warn{background:var(--coral);color:#2b0c06}
.sc-go.ready{animation:scPulse 1.1s ease-in-out infinite}
.sc-go:disabled{opacity:.55;animation:none}
@keyframes scPulse{0%,100%{box-shadow:0 0 0 0 rgba(227,174,69,.5)}50%{box-shadow:0 0 0 7px rgba(227,174,69,0)}}
.sc-side{position:absolute;z-index:2;width:46px;height:46px;min-height:46px;border-radius:50%;padding:0;font-size:17px;background:rgba(30,25,38,.85)}
.sc-side:disabled{opacity:.3}
.sc-log{position:absolute;z-index:2;min-height:44px;padding:0 10px;font-size:13px;background:rgba(30,25,38,.85)}
.sc-spot{position:absolute;pointer-events:none;border-radius:14px}
.sc-ov{position:absolute;inset:0;z-index:15;background:rgba(10,8,15,.8);display:flex;align-items:flex-end;justify-content:center;padding:10px;animation:fade .15s ease-out}
.sc-sheet{background:var(--surface);border:1px solid var(--line);border-radius:18px;width:min(440px,100%);max-height:100%;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px}
.sc-sheet>*{flex:none}
.sc-sheet h3{font-family:var(--f-display);font-weight:400;font-size:21px;margin:0}
.sc-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.sc-x{min-width:44px;min-height:44px;border-radius:12px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);font-size:18px;cursor:pointer}
.sc-tabs{display:flex;gap:6px;flex-wrap:wrap}
.sc-tabs .btn{min-height:44px;padding:0 12px;font-size:14px}
.sc-tabs .btn.on{border-color:var(--brass);background:#4a3b1a}
.sc-row{display:flex;align-items:center;gap:6px;padding:7px 9px;border-radius:10px;background:var(--surface-2);font-size:13.5px;flex-wrap:wrap;min-height:40px}
.sc-r{font-family:var(--f-mono);color:var(--muted);font-size:12px;min-width:28px}
.sc-n{font-family:var(--f-mono);font-weight:700;font-size:15px;padding:1px 6px 0;border-radius:7px;background:#14101c;border-bottom:3px solid var(--c);color:var(--ink)}
.sc-w{font-size:11px;color:var(--c);font-weight:700}
.sc-note{font-size:12px;color:var(--muted);line-height:1.5;margin:0 2px}
.sc-cand{font-family:var(--f-mono);font-size:12.5px;line-height:1.6;background:#1a1522;border-radius:10px;padding:6px 9px;color:#d9cfe6;word-break:break-all}
`;

  /* ---------- view ---------- */
  function mount(root, api) {
    const h = L.h;
    root.appendChild(h('style', { text: CSS }));
    const cv = U.canvas(root), ctx = cv.ctx;
    const spot = (c) => h('div', { class: 'sc-spot ' + c });
    const spCorr = spot('sc-corr'), spAlarm = spot('sc-alarm'), spSlots = spot('sc-slots'), spDial = spot('sc-dialbox');
    const toolBtn = {}, tools = h('div', { class: 'sc-tools' });
    [['l', '🩺', '청진기'], ['d', '🔩', '드릴'], ['r', '🌑', '돌멩이'], ['h', '🙈', '숨기']].forEach(([k, ic, nm]) => {
      const b = h('button', { class: 'btn', type: 'button' }, h('b', { text: ic }), h('span', { text: nm }), h('small', { text: '' }));
      b.onclick = () => setMode(mode === k ? 't' : k);
      toolBtn[k] = b; tools.append(b);
    });
    const goBtn = h('button', { class: 'btn primary sc-go', type: 'button', text: '🔓 이 번호로 시도' });
    goBtn.onclick = () => commit();
    const bot = h('div', { class: 'sc-bot' }, tools, goBtn);
    const leftBtn = h('button', { class: 'btn sc-side', type: 'button', text: '◀', 'aria-label': '다이얼 한 칸 작게' });
    const rightBtn = h('button', { class: 'btn sc-side', type: 'button', text: '▶', 'aria-label': '다이얼 한 칸 크게' });
    const logBtn = h('button', { class: 'btn sc-log', type: 'button', text: '📜 기록' });
    leftBtn.onclick = () => nudge(-1); rightBtn.onclick = () => nudge(1); logBtn.onclick = () => openLog(persp());
    root.append(spCorr, spAlarm, spSlots, spDial, leftBtn, rightBtn, logBtn, bot);

    let st = null, dead = false, anim = null, seenId = -1, busy = false, logEl = null, logSeat = -1;
    let mode = 't', lureT = -1, viewSeat = -1, theta = 0, thetaT = 0, drag = null, shownAl = 0, lastIn = -1;
    let shake = 0, flash = 0, flashCol = '238,80,60', banner = null, stunKey = '';
    const dialV = {}, selW = {}, sent = {}, parts = [], timers = new Set(), bubbles = {};
    const Lay = { W: 0, H: 0, bg: null, bgKey: '' };
    const spd = () => L.debug.speed || 1;
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms); timers.add(t); return t; };
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    const SF = () => SAFES[st.sf];

    /* ---- whose safe is on screen / who is choosing ---- */
    function pending() {
      if (!st || st.ph !== 'c' || anim) return [];
      const r = [];
      for (let i = 0; i < st.n; i++) if (api.canAct(i) && st.ch[i] == null && sent[i] !== st.r) r.push(i);
      return r;
    }
    function inputSeat() { const p = pending(); return p.length ? p[0] : -1; }
    function persp() {
      if (anim) return anim.seat;
      const s = inputSeat(); if (s >= 0) return s;
      if (st && viewSeat >= 0 && viewSeat < st.n) return viewSeat;
      const m = api.mySeats(); return m.length ? m[0] : 0;
    }
    function vals(seat) {
      if (!api.canAct(seat)) { const e = lastTryOf(seat); return e ? e.v : Array(st.W).fill(0); }
      if (!dialV[seat]) {
        const e = lastTryOf(seat); dialV[seat] = e ? e.v.slice() : Array(st.W).fill(0);
      }
      return dialV[seat];
    }
    const sel = (seat) => Math.max(0, Math.min(st.W - 1, selW[seat] || 0));
    function lastTryOf(seat) {
      const hs = st.h[seat];
      for (let q = hs.length - 1; q >= 0; q--) if (hs[q][0] === 't') return parseT(hs[q]);
      return null;
    }
    function parseT(e) { const W = st.W, v = [], f = []; for (let w = 0; w < W; w++) { v.push(num(e[1 + w])); f.push(+e[1 + W + w]); } return { v, f }; }
    /* the most recent clue for each wheel of a seat: {f, d?, drill?} */
    function lastClues(seat) {
      const out = Array(st.W).fill(null), hs = st.h[seat];
      for (let q = hs.length - 1; q >= 0; q--) {
        const e = hs[q];
        if (e[0] === 't') { const p = parseT(e); for (let w = 0; w < st.W; w++) if (!out[w]) out[w] = { f: p.f[w], v: p.v[w] }; }
        else if (e[0] === 'l') { const w = +e[1]; if (!out[w]) out[w] = { f: +e[3], v: num(e[2]), d: e[4] }; }
        else if (e[0] === 'd') { const w = +e[1]; if (!out[w]) out[w] = { f: 0, v: num(e[2]), drill: 1 }; }
      }
      return out;
    }
    /* every mark left on one wheel's dial: [{v, f, d?, drill?}] */
    function marks(seat, w) {
      const out = [];
      for (const e of st.h[seat]) {
        if (e[0] === 't') out.push({ v: num(e[1 + w]), f: +e[1 + st.W + w] });
        else if (e[0] === 'l' && +e[1] === w) out.push({ v: num(e[2]), f: +e[3], d: e[4] });
        else if (e[0] === 'd' && +e[1] === w) out.push({ v: num(e[2]), f: 0, drill: 1 });
      }
      return out;
    }
    let pcSeq = -1, pc = {};
    function prog(i) {
      if (pcSeq !== st.seq) { pcSeq = st.seq; pc = {}; }
      if (!pc[i]) pc[i] = progress(st, i);
      return pc[i];
    }
    const candsOf = (seat) => prog(seat).C;

    /* ---- actions ---- */
    function setMode(m) {
      const seat = inputSeat(); if (seat < 0 || st.zz[seat]) return;
      if ((m === 'l' && st.lt[seat] <= 0) || (m === 'd' && st.dt[seat] <= 0) || (m === 'r' && st.rt[seat] <= 0)) { api.toast('이 도구는 다 썼어요'); api.buzz(25); return; }
      mode = m; Snd.sel(); api.buzz(8);
      if (m === 'r' && (lureT < 0 || lureT === seat || lureT >= st.n)) lureT = defaultLure(seat);
      refresh();
    }
    function defaultLure(seat) {
      let best = -1, bl = 1e9;
      for (let j = 0; j < st.n; j++) { if (j === seat) continue; const p = prog(j); if (p.left < bl) { bl = p.left; best = j; } }
      return best;
    }
    function actionFor(seat) {
      if (st.zz[seat]) return { t: 'h' };
      const v = vals(seat), w = sel(seat);
      if (mode === 'l') return { t: 'l', w, v: v[w] };
      if (mode === 'd') return { t: 'd', w };
      if (mode === 'r') return { t: 'r', s: lureT };
      if (mode === 'h') return { t: 'h' };
      return { t: 't', v: v.slice() };
    }
    function commit() {
      const seat = inputSeat(); if (seat < 0 || drag) return;
      const a = actionFor(seat), r = st.r;
      sent[seat] = r; api.buzz(14); api.sfx('click');
      mode = 't';
      api.actAs(seat, a);
      later(() => { if (st && st.r === r && st.ph === 'c' && st.ch[seat] == null && sent[seat] === r) { delete sent[seat]; refresh(); } }, 2500);
      refresh();
    }
    const stepA = () => (Math.PI * 2) / st.N;
    function aimTheta(v) { const tgt = v * stepA(); let d = (tgt - thetaT) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; thetaT += d; }
    function detent() { Snd.tick(); api.buzz(4); }
    function nudge(d) {
      const seat = inputSeat(); if (seat < 0 || st.zz[seat] || drag) return;
      const w = sel(seat), v = vals(seat);
      v[w] = (v[w] + d + st.N) % st.N; thetaT += d * stepA(); detent(); refresh();
    }
    function selectWheel(w) {
      const seat = persp();
      if (!st || w < 0 || w >= st.W || anim) return;
      selW[seat] = w; aimTheta(vals(seat)[w]); Snd.sel(); refresh();
    }

    /* ---- layout ---- */
    function layout() {
      if (!st) return;
      const W = cv.w, H = cv.h; Lay.W = W; Lay.H = H;
      const botH = bot.offsetHeight || 118;
      Lay.botY = H - botH;
      Lay.CH = Math.round(Math.max(108, Math.min(150, H * 0.2)));
      Lay.floorY = Lay.CH - 20;
      Lay.infoY = Lay.CH + 15;
      Lay.slotY = Lay.CH + 31; Lay.slotH = H < 600 ? 54 : 60;
      const top = Lay.slotY + Lay.slotH + 8, bottom = Lay.botY - 18;
      Lay.legY = Lay.botY - 9;
      const area = bottom - top;
      const D = Math.max(140, Math.min(W - 116, area - 4, 330));
      Lay.R = D / 2; Lay.cx = W / 2; Lay.cy = top + area / 2;
      Lay.doorX = 6; Lay.doorY = Lay.slotY - 9; Lay.doorW = W - 12; Lay.doorH = Lay.botY + 6 - Lay.doorY;
      const n = st.W, gap = 6, sw = Math.min(78, (W - 28 - (n - 1) * gap) / n);
      Lay.sw = sw; Lay.sg = gap; Lay.sx = (W - (n * sw + (n - 1) * gap)) / 2;
      // corridor: K spots across the width
      Lay.cpad = 8; Lay.cs = (W - 2 * Lay.cpad) / st.K;
      Lay.vd = Math.min(46, Lay.cs * 1.55, Lay.floorY - 52);
      const place = (el, x, y, w, hh) => { el.style.left = Math.round(x) + 'px'; el.style.top = Math.round(y) + 'px'; if (w != null) { el.style.width = Math.round(w) + 'px'; el.style.height = Math.round(hh) + 'px'; } };
      const sideY = Lay.cy + Lay.R * 0.5 - 23, sideX = Math.max(10, Lay.cx - Lay.R - 58);
      place(leftBtn, sideX, sideY); place(rightBtn, W - sideX - 46, sideY);
      logBtn.style.right = '14px'; logBtn.style.top = Math.round(top - 2) + 'px';
      place(spCorr, 2, 2, W - 4, Lay.CH - 2);
      place(spAlarm, 4, 2, W - 8, 30);
      place(spSlots, Lay.sx - 5, Lay.slotY - 4, n * sw + (n - 1) * gap + 10, Lay.slotH + 8);
      place(spDial, Lay.cx - Lay.R - 6, Lay.cy - Lay.R - 6, D + 12, D + 12);
      const key = W + 'x' + H + ':' + cv.dpr + ':' + st.K + ':' + st.n + ':' + Math.round(D) + ':' + botH;
      if (key !== Lay.bgKey) { Lay.bgKey = key; buildBg(); }
    }
    const spotX = (p) => Lay.cpad + (p + 0.5) * Lay.cs;

    /* ---- cached background: corridor wall + floor, the steel door ---- */
    function buildBg() {
      const dpr = cv.dpr, W = Lay.W, H = Lay.H;
      const c = document.createElement('canvas'); c.width = Math.ceil(W * dpr); c.height = Math.ceil(H * dpr);
      const b = c.getContext('2d'); b.scale(dpr, dpr);
      const g = b.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#1a1424'); g.addColorStop(1, '#100c16');
      b.fillStyle = g; b.fillRect(0, 0, W, H);
      // corridor wall (bricks) and floor
      const wy = 32, fy = Lay.floorY;
      const wg = b.createLinearGradient(0, wy, 0, fy); wg.addColorStop(0, '#231a2e'); wg.addColorStop(1, '#2d2238');
      b.fillStyle = wg; b.fillRect(0, wy, W, fy - wy);
      b.strokeStyle = 'rgba(0,0,0,0.28)'; b.lineWidth = 1;
      for (let y = wy, row = 0; y < fy; y += 11, row++) {
        b.beginPath(); b.moveTo(0, y + 0.5); b.lineTo(W, y + 0.5); b.stroke();
        for (let x = (row % 2) * 13; x < W; x += 26) { b.beginPath(); b.moveTo(x + 0.5, y); b.lineTo(x + 0.5, Math.min(fy, y + 11)); b.stroke(); }
      }
      // wall lamps
      for (let x = Lay.cpad + Lay.cs; x < W; x += Lay.cs * 2) {
        const lg = b.createRadialGradient(x, wy + 6, 1, x, wy + 6, 26); lg.addColorStop(0, 'rgba(255,214,140,0.16)'); lg.addColorStop(1, 'rgba(255,214,140,0)');
        b.fillStyle = lg; b.beginPath(); b.arc(x, wy + 6, 26, 0, 7); b.fill();
      }
      const fg = b.createLinearGradient(0, fy, 0, Lay.CH); fg.addColorStop(0, '#3a2d26'); fg.addColorStop(1, '#241b17');
      b.fillStyle = fg; b.fillRect(0, fy, W, Lay.CH - fy);
      b.strokeStyle = 'rgba(0,0,0,0.3)';
      for (let x = 0; x < W; x += 34) { b.beginPath(); b.moveTo(x + 0.5, fy); b.lineTo(x + 0.5, Lay.CH); b.stroke(); }
      b.fillStyle = 'rgba(227,174,69,0.35)'; b.fillRect(0, fy, W, 1.5);
      b.fillStyle = 'rgba(0,0,0,0.5)'; b.fillRect(0, Lay.CH, W, 2);
      // the steel door
      const x = Lay.doorX, y = Lay.doorY, w = Lay.doorW, hh = Lay.doorH;
      b.save();
      b.shadowColor = 'rgba(0,0,0,0.6)'; b.shadowBlur = 14; b.shadowOffsetY = 4;
      const dg = b.createLinearGradient(x, y, x + w, y + hh); dg.addColorStop(0, '#565a66'); dg.addColorStop(0.45, '#3e424c'); dg.addColorStop(1, '#2a2d35');
      b.fillStyle = dg; rr(b, x, y, w, hh, 16); b.fill();
      b.restore();
      // brushed lines
      b.save(); rr(b, x, y, w, hh, 16); b.clip();
      let seed = 11; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      for (let q = 0; q < 70; q++) { b.strokeStyle = 'rgba(255,255,255,' + (0.015 + rnd() * 0.025).toFixed(3) + ')'; const yy = y + rnd() * hh; b.beginPath(); b.moveTo(x, yy); b.lineTo(x + w, yy + (rnd() - 0.5) * 4); b.stroke(); }
      b.restore();
      b.strokeStyle = 'rgba(227,174,69,0.55)'; b.lineWidth = 2; rr(b, x + 5, y + 5, w - 10, hh - 10, 12); b.stroke();
      b.strokeStyle = 'rgba(0,0,0,0.45)'; b.lineWidth = 1; rr(b, x + 8, y + 8, w - 16, hh - 16, 10); b.stroke();
      // rivets
      const rv = (rx, ry) => { const rg = b.createRadialGradient(rx - 1, ry - 1, 0.5, rx, ry, 3.4); rg.addColorStop(0, '#c9ccd4'); rg.addColorStop(1, '#4a4d57'); b.fillStyle = rg; b.beginPath(); b.arc(rx, ry, 3, 0, 7); b.fill(); };
      for (let q = 0; q <= 8; q++) { rv(x + 14 + (w - 28) * q / 8, y + 14); }
      for (let q = 1; q < 6; q++) { rv(x + 14, y + 14 + (hh - 28) * q / 6); rv(x + w - 14, y + 14 + (hh - 28) * q / 6); }
      // hinges on the left edge
      for (const f of [0.18, 0.5, 0.82]) { const hy = y + hh * f; b.fillStyle = '#23262d'; rr(b, x - 4, hy - 16, 10, 32, 3); b.fill(); b.fillStyle = 'rgba(227,174,69,0.5)'; b.fillRect(x - 3, hy - 1, 8, 2); }
      // dial recess
      const cx = Lay.cx, cy = Lay.cy, R = Lay.R;
      const rg2 = b.createRadialGradient(cx, cy, R * 0.9, cx, cy, R + 16); rg2.addColorStop(0, 'rgba(0,0,0,0.55)'); rg2.addColorStop(1, 'rgba(0,0,0,0)');
      b.fillStyle = rg2; b.beginPath(); b.arc(cx, cy, R + 16, 0, 7); b.fill();
      Lay.bg = c;
    }

    /* ---- input: dial drag, slots, corridor ---- */
    function slotAt(x) { for (let w = 0; w < st.W; w++) { const sx = Lay.sx + w * (Lay.sw + Lay.sg); if (x >= sx - Lay.sg / 2 && x < sx + Lay.sw + Lay.sg / 2) return w; } return -1; }
    function vaultAt(x) { const p = (x - Lay.cpad) / Lay.cs - 0.5; return Math.max(0, Math.min(st.n - 1, Math.round((p - 2) / 2))); }
    function tapCorr(x) {
      const seat = vaultAt(x), me = inputSeat();
      if (me >= 0 && mode === 'r') {
        if (seat === me) { api.toast('내 금고에는 못 던져요'); return; }
        lureT = seat; Snd.sel(); api.buzz(8); refresh(); return;
      }
      if (me >= 0) { openLog(seat); return; }
      viewSeat = seat; Snd.sel();
      const v = vals(seat); aimTheta(v[sel(seat)]);
      api.toast(nm(seat) + '의 금고를 보는 중');
      refresh();
    }
    function onDown(ev) {
      if (!st || logEl) return;
      const p = cv.local(ev);
      if (p.y < Lay.CH) { tapCorr(p.x); return; }
      if (p.y >= Lay.slotY - 4 && p.y < Lay.slotY + Lay.slotH + 4) { const w = slotAt(p.x); if (w >= 0) selectWheel(w); return; }
      const seat = inputSeat(); if (seat < 0 || st.zz[seat] || mode === 'r' || mode === 'h') return;
      const dx = p.x - Lay.cx, dy = p.y - Lay.cy, d2 = dx * dx + dy * dy;
      if (d2 > (Lay.R + 26) * (Lay.R + 26)) return;
      ev.preventDefault();
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      theta = thetaT;
      drag = { a: Math.atan2(dy, dx), seat, w: sel(seat), det: Math.round(theta / stepA()), far: d2 > (Lay.R * 0.2) * (Lay.R * 0.2) };
    }
    function onMove(ev) {
      if (!drag) return;
      const p = cv.local(ev), dx = p.x - Lay.cx, dy = p.y - Lay.cy;
      if (dx * dx + dy * dy < (Lay.R * 0.14) * (Lay.R * 0.14)) return;   // too close to the middle: angle is jumpy
      const a = Math.atan2(dy, dx); let d = a - drag.a;
      if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2;
      drag.a = a; theta += d; thetaT = theta;
      const det = Math.round(theta / stepA());
      if (det !== drag.det) {
        drag.det = det; const v = vals(drag.seat); v[drag.w] = ((det % st.N) + st.N) % st.N; detent();
      }
    }
    function onUp() { if (!drag) return; thetaT = Math.round(theta / stepA()) * stepA(); drag = null; refresh(); }
    function onWheel(ev) {
      if (!st || logEl) return;
      const p = cv.local(ev), dx = p.x - Lay.cx, dy = p.y - Lay.cy;
      if (dx * dx + dy * dy > (Lay.R + 26) * (Lay.R + 26)) return;
      ev.preventDefault(); nudge(ev.deltaY > 0 ? 1 : -1);
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('wheel', onWheel, { passive: false });

    /* ---- history sheet ---- */
    function openLog(seat) {
      if (!st) return;
      if (logEl) { logEl.remove(); logEl = null; }
      api.sfx('click');
      logSeat = seat;
      const S = SF();
      const close = () => { if (logEl) { logEl.remove(); logEl = null; } };
      const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
      const tabs = h('div', { class: 'sc-tabs' });
      const render = () => {
        body.innerHTML = ''; tabs.innerHTML = '';
        if (st.n > 1) for (let i = 0; i < st.n; i++) {
          const b = h('button', { class: 'btn' + (i === logSeat ? ' on' : ''), type: 'button' }, h('span', { class: 'dot', style: { '--c': col(i) } }), nm(i));
          b.onclick = () => { logSeat = i; api.sfx('click'); render(); };
          tabs.append(b);
        }
        const hs = st.h[logSeat];
        const p = prog(logSeat);
        body.append(h('div', { class: 'sc-note', text: S.n + ' · ' + S.W + '칸 중 ' + p.known + '칸 확정 · 청진기 ' + st.lt[logSeat] + ' · 드릴 ' + st.dt[logSeat] + (st.n > 1 ? ' · 돌멩이 ' + st.rt[logSeat] : '') }));
        if (st.hl || st.ph === 'e') {
          const box = h('div', { class: 'sc-cand' });
          p.C.forEach((c, w) => { box.append(h('div', { text: (w + 1) + '칸: ' + (c.length === 1 ? '✓ ' + c[0] : c.length > 14 ? c.length + '개 남음' : c.join(' · ')) })); });
          body.append(h('div', { class: 'sc-note', text: '가능한 숫자' }), box);
        }
        if (!hs.length) body.append(h('div', { class: 'sc-note', text: '아직 기록이 없어요.' }));
        for (let q = hs.length - 1; q >= 0; q--) {
          const e = hs[q], row = h('div', { class: 'sc-row' }, h('span', { class: 'sc-r', text: 'R' + (q + 1) }));
          if (e[0] === 't') {
            const t = parseT(e); row.append(h('span', { text: '🔓' }));
            t.v.forEach((v, w) => row.append(h('span', { style: { display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: '1px' } },
              h('span', { class: 'sc-n', text: String(v).padStart(2, '0'), style: { '--c': fbCol(S, t.f[w]) } }), h('span', { class: 'sc-w', text: fbWord(S, t.f[w]), style: { '--c': fbCol(S, t.f[w]) } }))));
          } else if (e[0] === 'l') {
            const f = +e[3], dr = e[4];
            row.append(h('span', { text: '🩺 ' + (+e[1] + 1) + '칸' }), h('span', { class: 'sc-n', text: String(num(e[2])).padStart(2, '0'), style: { '--c': fbCol(S, f) } }),
              h('span', { class: 'sc-w', style: { '--c': fbCol(S, f) }, text: fbWord(S, f) + (dr === '=' ? '' : dr === '+' ? ' · 더 큰 쪽 ▶' : ' · ◀ 더 작은 쪽') }));
          } else if (e[0] === 'd') row.append(h('span', { text: '🔩 드릴: ' + (+e[1] + 1) + '칸 =' }), h('span', { class: 'sc-n', text: String(num(e[2])).padStart(2, '0'), style: { '--c': FBC[0] } }));
          else if (e[0] === 'r') row.append(h('span', { text: '🌑 ' + nm(+e[1]) + ' 금고로 돌멩이' }));
          else if (e[0] === 'x') row.append(h('span', { text: '🚨 들켰어요 (행동 무효 · 경보 +2)', style: { color: '#ff8f7a' } }));
          else if (e[0] === 'z') row.append(h('span', { text: '😵 붙잡혔다 풀려나 숨어 있었어요', style: { color: 'var(--muted)' } }));
          else row.append(h('span', { text: '🙈 숨어 있었어요', style: { color: 'var(--muted)' } }));
          body.append(row);
        }
      };
      render();
      logEl = h('div', { class: 'sc-ov' }, h('div', { class: 'sc-sheet' },
        h('div', { class: 'sc-head' }, h('h3', { text: '📜 금고 기록' }), h('button', { class: 'sc-x', type: 'button', 'aria-label': '기록 닫기', text: '✕', onclick: close })),
        tabs,
        h('div', { class: 'sc-note', html: legendParts(S).map((x) => '<b style="color:' + x[2] + '">' + x[0] + '</b> ' + x[1]).join(' · ') }),
        body));
      logEl.addEventListener('click', (e) => { if (e.target === logEl) close(); });
      root.append(logEl);
    }
    function onKeyEsc(e) { if (e.key === 'Escape' && logEl) { e.preventDefault(); e.stopPropagation(); logEl.remove(); logEl = null; } }
    addEventListener('keydown', onKeyEsc, true);

    /* ---- keyboard / pad (rebindable) ---- */
    const offInput = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || dead || !st) return;
      if (id === 'log') { if (logEl) { logEl.remove(); logEl = null; } else openLog(persp()); return; }
      if (logEl) return;
      if (id === 'left') nudge(-1);
      else if (id === 'right') nudge(1);
      else if (id === 'prev') selectWheel((sel(persp()) + st.W - 1) % st.W);
      else if (id === 'next') selectWheel((sel(persp()) + 1) % st.W);
      else if (id === 'go') commit();
      else if (id === 'hide') setMode(mode === 'h' ? 't' : 'h');
    }) : null;

    /* ---- buttons / labels ---- */
    function refresh() {
      if (!st) return;
      const seat = inputSeat(), can = seat >= 0, z = can && !!st.zz[seat];
      if (seat !== lastIn) {
        if (seat >= 0 && lastIn >= 0 && api.mySeats().length > 1) { api.toast(nm(seat) + ' 차례 — 다이얼을 맞춰요'); }
        lastIn = seat; if (seat >= 0) { mode = 't'; aimTheta(vals(seat)[sel(seat)]); }
      }
      const left = { l: can ? st.lt[seat] : 0, d: can ? st.dt[seat] : 0, r: can ? st.rt[seat] : 0 };
      toolBtn.r.style.display = st.n > 1 ? '' : 'none';
      ['l', 'd', 'r'].forEach((k) => {
        const b = toolBtn[k]; b.disabled = !can || z || left[k] <= 0; b.classList.toggle('on', can && mode === k);
        b.lastChild.textContent = can ? '×' + left[k] : '';
      });
      toolBtn.h.disabled = !can || z; toolBtn.h.classList.toggle('on', can && (mode === 'h' || z));
      toolBtn.h.lastChild.textContent = can ? '경보 0' : '';
      toolBtn.l.lastChild.textContent = can ? '×' + left.l + ' · 조용' : '';
      toolBtn.d.lastChild.textContent = can ? '×' + left.d + ' · 경보3' : '';
      const sideOk = can && !z && (mode === 't' || mode === 'l');
      leftBtn.disabled = rightBtn.disabled = !sideOk;
      leftBtn.style.visibility = rightBtn.style.visibility = st.ph === 'e' && st.why === 'open' ? 'hidden' : '';
      logBtn.style.visibility = st.ph === 'e' && st.why === 'open' && st.w.includes(persp()) ? 'hidden' : '';
      let txt = '', warn = false;
      const dz = can ? danger(st, seat) : 0;
      if (!can) txt = anim ? '결과 보는 중…' : st.ph === 'e' ? '판이 끝났어요' : api.mySeats().length ? '✓ 준비 완료 · 다른 도둑을 기다려요' : '구경 중';
      else if (z) txt = '😵 이번 라운드는 숨어 있어요';
      else if (mode === 'l') txt = '🩺 ' + (sel(seat) + 1) + '칸을 ' + vals(seat)[sel(seat)] + '에서 듣기';
      else if (mode === 'd') txt = '🔩 ' + (sel(seat) + 1) + '칸 드릴로 뚫기';
      else if (mode === 'r') txt = '🌑 ' + nm(lureT) + ' 금고로 던지기';
      else if (mode === 'h') txt = '🙈 숨어 있기';
      else { txt = '🔓 ' + vals(seat).map((v) => String(v).padStart(2, '0')).join('·') + ' 시도'; warn = dz >= 0.5; }
      if (can && (mode === 'l' || mode === 'd')) warn = dz >= 0.5;
      goBtn.textContent = (warn ? '⚠ ' : '') + txt;
      goBtn.disabled = !can;
      goBtn.classList.toggle('warn', can && warn);
      goBtn.classList.toggle('ready', can && !warn);
      // a caught thief on this phone sits the round out by itself
      if (z) {
        const key = seat + ':' + st.r;
        if (stunKey !== key) { stunKey = key; api.toast(nm(seat) + ' · 들켜서 이번 라운드는 숨어 있어요'); later(() => { if (inputSeat() === seat && st.zz[seat]) { sent[seat] = st.r; api.actAs(seat, { t: 'h' }); refresh(); } }, 1100 / spd()); }
      }
    }

    /* ---- particles ---- */
    function spawn(p) { if (parts.length > 220) parts.shift(); p.t = 0; p.max = p.life; parts.push(p); }
    function floatText(x, y, text, color, big, slow) { spawn({ x, y, vx: 0, vy: slow ? -12 : -30, life: slow ? 1.0 : 1.3, col: color, text, big }); }

    /* ---- the reveal (from state.last, so online guests see the same) ---- */
    function startAnim(last) {
      const prevSeat = persp();
      const seat = last.o.length && !last.o.includes(prevSeat) && !api.mySeats().includes(prevSeat) ? last.o[0] : prevSeat;
      const e = st.h[seat][last.r] || 'h', S = SF();
      if (e[0] === 't') dialV[seat] = parseT(e).v;
      let t = 1.0;
      const fb = e[0] === 't' ? t + st.W * 0.42 + 0.2 : e[0] === 'l' ? t + 1.1 : e[0] === 'd' ? t + 1.3 : t + 0.5;
      const opened = last.o.length > 0, end = st.ph === 'e';
      const dur = fb + (opened ? (last.o.includes(seat) ? 3.0 : 1.6) : end ? 1.8 : 0.25);
      anim = { last, t: 0, seat, e, fb, dur, fired: {}, al0: last.al0, msg: last.lu >= 0 ? '돌멩이가 날아가요!' : '모두 공개! 경비가 움직여요…', S };
      shownAl = last.al0;
      if (logEl) { logEl.remove(); logEl = null; }
      drag = null; mode = 't';
      for (const k in bubbles) delete bubbles[k];
      setBusy(true); refresh();
    }
    const ease = (x) => (x < 0 ? 0 : x > 1 ? 1 : 1 - (1 - x) * (1 - x));
    function bubbleFor(i, last) {
      const e = st.h[i][last.r] || 'h', k = e[0];
      let txt = '', c2 = '#f2e9d8';
      if (k === 't') { const p = parseT(e); const ex = p.f.filter((x) => x === 0).length; txt = last.o.includes(i) ? '열림!' : ex ? '철컥×' + ex : '딸깍'; c2 = ex ? FBC[0] : FBC[2]; }
      else if (k === 'l') txt = '🩺'; else if (k === 'd') txt = '🔩'; else if (k === 'r') txt = '🌑'; else if (k === 'z') txt = '😵'; else txt = '🙈';
      bubbles[i] = { text: txt, col: c2, t: 0 };
    }
    function once(k) { if (anim.fired[k]) return false; anim.fired[k] = 1; return true; }
    function stepAnim(dt) {
      if (!anim) return;
      const a = anim, last = a.last, S = a.S, me = a.seat;
      a.t += dt * spd();
      const t = a.t;
      if (t > 0.05 && once('go')) {
        // footsteps / pebble
        if (last.lu >= 0) Snd.pebble(); else Snd.step();
        later(() => Snd.step(), 260 / spd()); later(() => Snd.step(), 520 / spd());
      }
      if (t > 0.85 && once('caught')) {
        for (const i of last.c) {
          bubbles[i] = { text: '들켰다!', col: '#ff6b5a', t: 0 };
          if (i === me) { flash = 1; flashCol = '238,80,60'; shake = 9; api.buzz(80); }
        }
        if (last.c.length) Snd.whistle();
        for (let i = 0; i < st.n; i++) if (!last.c.includes(i) && i !== me && !last.o.includes(i)) bubbleFor(i, last);
      }
      const e = a.e, k = e[0];
      if (last.c.includes(me) && t > 1.0 && once('cmsg')) { a.msg = '🚨 들켰어요! 이번 행동은 무효, 다음 라운드는 숨어 있어야 해요'; floatText(Lay.cx, Lay.cy - 10, '들켰다!', '#ff6b5a', true); }
      if (k === 't') {
        const p = parseT(e);
        for (let w = 0; w < st.W; w++) {
          const t0 = 1.0 + w * 0.42;
          if (t > t0 && once('spin' + w)) { selW[me] = w; aimTheta(p.v[w]); }
          if (t > t0 + 0.28 && once('clk' + w)) {
            const f = p.f[w]; Snd.clk(f); if (me === inputSeatMine()) api.buzz(f === 0 ? 45 : f === 1 ? 18 : f === 2 ? 8 : 0);
            const sx = Lay.sx + w * (Lay.sw + Lay.sg) + Lay.sw / 2;
            if (f === 0) { for (let q = 0; q < 12; q++) spawn({ x: sx, y: Lay.slotY + Lay.slotH / 2, vx: (Math.random() - 0.5) * 140, vy: (Math.random() - 0.5) * 120, life: 0.5, col: FBC[0], r: 2.4 }); shake = Math.max(shake, 3); }
          }
        }
        if (t > 1.0 && once('msg')) {
          const cnt = [0, 0, 0, 0]; p.f.forEach((f) => cnt[f]++);
          a.msg = last.o.includes(me) ? '모든 칸이 철컥! 금고가 열려요!' : [0, 1, 2, 3].filter((f) => cnt[f]).map((f) => fbWord(S, f) + ' ' + cnt[f]).join(' · ');
        }
      } else if (k === 'l') {
        const w = +e[1], v = num(e[2]), f = +e[3], dr = e[4];
        if (t > 1.0 && once('l1')) { selW[me] = w; aimTheta(v); Snd.steth(); }
        if (t > 1.5 && once('l2')) {
          Snd.clk(f);
          a.msg = '🩺 ' + (w + 1) + '칸 ' + v + ': ' + fbWord(S, f) + (dr === '=' ? ' — 바로 여기!' : dr === '+' ? ' · 더 큰 숫자 쪽이에요 ▶' : ' · ◀ 더 작은 숫자 쪽이에요');
          floatText(Lay.cx, Lay.cy - Lay.R * 0.55, dr === '=' ? '여기!' : dr === '+' ? '더 큰 쪽 ▶' : '◀ 더 작은 쪽', fbCol(S, f), true);
        }
      } else if (k === 'd') {
        const w = +e[1], v = num(e[2]);
        if (t > 1.0 && once('d1')) { selW[me] = w; Snd.drill(); shake = 5; a.msg = '🔩 드르르륵… ' + (w + 1) + '칸을 뚫는 중'; }
        if (t > 1.0 && t < 1.9) { const sx = Lay.sx + w * (Lay.sw + Lay.sg) + Lay.sw / 2; if (Math.random() < 0.7) spawn({ x: sx + (Math.random() - 0.5) * 10, y: Lay.slotY + Lay.slotH * 0.6, vx: (Math.random() - 0.5) * 160, vy: -40 - Math.random() * 120, life: 0.45, col: Math.random() < 0.5 ? '#ffd45a' : '#ff8a3d', r: 1.8, g: 1 }); shake = Math.max(shake, 2); }
        if (t > 1.9 && once('d2')) { aimTheta(v); Snd.clk(0); a.msg = '🔩 ' + (w + 1) + '칸의 숫자는 ' + v + '!'; if (dialV[me]) dialV[me][w] = v; }
      } else if (t > 1.0 && once('o1') && !last.c.includes(me)) {
        a.msg = k === 'r' ? '🌑 돌멩이를 던졌어요 — 경비가 ' + nm(last.lu) + ' 금고로!' : k === 'z' ? '😵 숨어서 한 라운드를 보냈어요' : '🙈 숨어서 경비가 지나가길 기다렸어요';
      }
      // alarm meter
      shownAl = last.al0 + (st.al - last.al0) * ease((t - 0.9) / Math.max(0.3, a.fb - 0.9));
      if (t > a.fb && once('end')) {
        for (let i = 0; i < st.n; i++) if (!last.c.includes(i) && (i === me || last.o.includes(i))) bubbleFor(i, last);
        if (last.o.length) {
          if (last.o.includes(me)) { Snd.open(); Snd.coins(); api.buzz(60); }
          else { Snd.clk(0); }
          const names = last.o.map(nm).join(', ');
          banner = { text: last.o.includes(me) && api.canAct(me) && last.o.length === 1 ? '금고를 열었어요!' : names + ' 금고 열림!', col: '#ffd45a', t: 0 };
        } else if (st.ph === 'e') {
          Snd.siren(); flashCol = '90,120,255'; flash = 0.8; api.buzz(50);
          banner = { text: st.why === 'police' ? '🚨 경찰 출동!' : '🌅 날이 밝았어요', col: st.why === 'police' ? '#ff6b5a' : '#ffd9a0', t: 0 };
        } else if (st.al >= st.am * 0.75 && last.al0 < st.am * 0.75) { api.toast('경보가 얼마 안 남았어요!'); }
      }
      if (st.ph === 'e' && st.why === 'police' && t > a.fb) { const ph = Math.floor((t - a.fb) * 5) % 2; flashCol = ph ? '90,120,255' : '238,80,60'; flash = Math.max(flash, 0.35); }
      if (t >= a.dur) {
        anim = null; setBusy(false);
        if (st.ph === 'e' && st.why === 'open' && st.w.length && !api.mySeats().length) viewSeat = st.w[0];
        // convenience: a drilled number goes straight onto the dial
        for (const i of api.mySeats()) { const hs = st.h[i], e2 = hs[hs.length - 1]; if (e2 && e2[0] === 'd' && dialV[i]) dialV[i][+e2[1]] = num(e2[2]); }
        refresh();
        const s2 = inputSeat(); if (s2 >= 0) aimTheta(vals(s2)[sel(s2)]);
      }
    }
    function inputSeatMine() { const m = api.mySeats(); return m.length === 1 ? m[0] : anim ? anim.seat : -1; }

    /* ---- render ---- */
    function fitText(text, maxW, size, weight, family) {
      let s = size; ctx.font = weight + ' ' + s + 'px ' + family;
      while (s > 9 && ctx.measureText(text).width > maxW) { s -= 1; ctx.font = weight + ' ' + s + 'px ' + family; }
      return s;
    }
    function guardPos(g, t) {
      const last = anim ? anim.last : null, p1 = st.gp[g];
      if (!last || !last.g0 || !last.g0[g]) return { x: spotX(p1), d: st.gd[g], walk: 0 };
      const p0 = last.g0[g][0];
      const lured = last.lu >= 0 && p1 === vaultPos(last.lu) && Math.abs(p1 - p0) !== 1;
      const f = lured ? ease((t - 0.45) / 0.45) : ease((t - 0.1) / 0.75);
      const moving = f > 0 && f < 1;
      return { x: spotX(p0) + (spotX(p1) - spotX(p0)) * f, d: f > 0 ? st.gd[g] : last.g0[g][1], walk: moving ? (lured ? 2 : 1) : 0 };
    }
    function drawGuard(x, d, walk, now) {
      const fy = Lay.floorY, s = Math.max(0.75, Math.min(1.1, (Lay.floorY - 40) / 60));
      // flashlight cone on the floor ahead
      ctx.save();
      const cg = ctx.createLinearGradient(x, fy - 24 * s, x + d * Lay.cs * 1.2, fy);
      cg.addColorStop(0, 'rgba(255,236,160,0.45)'); cg.addColorStop(1, 'rgba(255,236,160,0.04)');
      ctx.fillStyle = cg; ctx.beginPath(); ctx.moveTo(x + d * 8 * s, fy - 22 * s);
      ctx.lineTo(x + d * Lay.cs * 1.25, fy - 30 * s); ctx.lineTo(x + d * Lay.cs * 1.25, fy + 6); ctx.closePath(); ctx.fill();
      ctx.restore();
      ctx.save(); ctx.translate(x, fy); ctx.scale(s, s);
      const bob = walk ? Math.abs(Math.sin(now / (walk > 1 ? 60 : 110))) * 2.2 : 0, leg = walk ? Math.sin(now / (walk > 1 ? 60 : 110)) * 5 : 0;
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(0, 0, 11, 3, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#1b2236'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-2, -14 - bob); ctx.lineTo(-3 + leg, -1); ctx.moveTo(2, -14 - bob); ctx.lineTo(3 - leg, -1); ctx.stroke();
      ctx.fillStyle = '#2c3a63'; rr(ctx, -7, -32 - bob, 14, 19, 4); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.fillRect(-1, -29 - bob, 2, 2); ctx.fillRect(-4, -28 - bob, 2, 2);
      ctx.fillStyle = '#f0d0a8'; ctx.beginPath(); ctx.arc(0, -37 - bob, 5.5, 0, 7); ctx.fill();
      ctx.fillStyle = '#1b2236'; ctx.fillRect(-6.5, -44 - bob, 13, 4.5); ctx.fillRect(d > 0 ? 0 : -9, -40.5 - bob, 9, 2);
      ctx.strokeStyle = '#2c3a63'; ctx.lineWidth = 3.4; ctx.beginPath(); ctx.moveTo(d * 4, -27 - bob); ctx.lineTo(d * 9, -22 - bob); ctx.stroke();
      ctx.fillStyle = '#ffe9a0'; ctx.shadowColor = '#ffe9a0'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(d * 10, -22 - bob, 2.4, 0, 7); ctx.fill();
      ctx.restore();
    }
    function drawCorridor(now) {
      const W = Lay.W, t = anim ? anim.t : 99, last = anim ? anim.last : null;
      // alarm meter
      const al = anim ? shownAl : st.al, am = st.am, f = Math.min(1, al / am);
      const bx = 44, bw = W - bx - 70, by = 9, bh = 14;
      const lampOn = f >= 0.75 ? (Math.sin(now / 120) > 0) : false;
      ctx.save(); ctx.fillStyle = lampOn ? '#ff4a3a' : f >= 0.5 ? '#c4552f' : '#6a3a34';
      if (lampOn) { ctx.shadowColor = '#ff4a3a'; ctx.shadowBlur = 16; }
      ctx.beginPath(); ctx.arc(22, by + bh / 2, 9, Math.PI, 0); ctx.lineTo(31, by + bh + 2); ctx.lineTo(13, by + bh + 2); ctx.closePath(); ctx.fill(); ctx.restore();
      ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, bx, by, bw, bh, 7); ctx.fill();
      const seg = Math.min(am, 40), sw = bw / seg;
      for (let q = 0; q < seg; q++) {
        const lit = (q + 1) / seg <= f + 1e-6, part = !lit && q / seg < f;
        if (!lit && !part) continue;
        const hue = q / seg;
        ctx.fillStyle = hue < 0.5 ? '#e3ae45' : hue < 0.75 ? '#f08a3a' : '#ee4a3a';
        ctx.globalAlpha = part ? 0.5 : 1;
        rr(ctx, bx + q * sw + 1, by + 2, Math.max(1, sw - 2), bh - 4, 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = 'rgba(242,233,216,0.2)'; ctx.lineWidth = 1; rr(ctx, bx + 0.5, by + 0.5, bw - 1, bh - 1, 7); ctx.stroke();
      ctx.font = '700 12px ' + MONO; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = f >= 0.75 ? '#ff8f7a' : '#f2e9d8';
      ctx.fillText(Math.round(al) + '/' + am, bx + bw + 6, by + bh / 2 + 0.5);
      ctx.textAlign = 'right'; ctx.fillStyle = '#ab9fb8'; ctx.font = '700 11px ' + MONO;
      ctx.fillText('R' + Math.min(st.r + (st.ph === 'c' ? 1 : 0), RMAX), W - 6, by + bh / 2 + 0.5);
      // vaults
      const vd = Lay.vd, fy = Lay.floorY;
      for (let i = 0; i < st.n; i++) {
        const x = spotX(vaultPos(i)), y = fy - vd - 2, isP = i === persp();
        const opened = st.ph === 'e' && st.why === 'open' && st.w.includes(i) && (!anim || t > anim.fb);
        ctx.save();
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x - vd / 2 + 3, y + 3, vd, vd);
        const vg = ctx.createLinearGradient(x - vd / 2, y, x + vd / 2, y + vd); vg.addColorStop(0, '#6a6e7a'); vg.addColorStop(1, '#353842');
        ctx.fillStyle = vg; rr(ctx, x - vd / 2, y, vd, vd, 5); ctx.fill();
        ctx.lineWidth = isP ? 2.5 : 1.5; ctx.strokeStyle = isP ? '#e3ae45' : col(i); rr(ctx, x - vd / 2, y, vd, vd, 5); ctx.stroke();
        if (opened) {
          ctx.fillStyle = '#1a1208'; rr(ctx, x - vd / 2 + 4, y + 4, vd - 8, vd - 8, 3); ctx.fill();
          ctx.shadowColor = '#ffd45a'; ctx.shadowBlur = 14; ctx.fillStyle = '#ffd45a';
          for (let q = 0; q < 3; q++) { ctx.fillRect(x - vd * 0.28 + q * vd * 0.19, y + vd * 0.58, vd * 0.16, vd * 0.14); }
          ctx.fillRect(x - vd * 0.18, y + vd * 0.44, vd * 0.16, vd * 0.14); ctx.fillRect(x + 0.02 * vd, y + vd * 0.44, vd * 0.16, vd * 0.14);
          ctx.shadowBlur = 0;
        } else {
          // mini dial + progress pips
          ctx.fillStyle = '#23262d'; ctx.beginPath(); ctx.arc(x, y + vd * 0.42, vd * 0.22, 0, 7); ctx.fill();
          ctx.strokeStyle = 'rgba(227,174,69,0.7)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(x, y + vd * 0.42, vd * 0.22, 0, 7); ctx.stroke();
          const C = prog(i).C, pw = Math.min(7, (vd - 8) / st.W - 2);
          for (let w = 0; w < st.W; w++) {
            ctx.fillStyle = C[w].length === 1 ? '#ffd45a' : 'rgba(242,233,216,0.22)';
            ctx.beginPath(); ctx.arc(x - ((st.W - 1) * (pw + 2)) / 2 + w * (pw + 2), y + vd * 0.82, pw / 2, 0, 7); ctx.fill();
          }
        }
        ctx.restore();
        // name
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        fitText(nm(i), Lay.cs * 2 - 8, 11, '700', FONT); ctx.fillStyle = isP ? '#f2e9d8' : '#cfc3dc';
        ctx.fillText(nm(i), x, fy + 10);
        ctx.fillStyle = col(i); ctx.beginPath(); ctx.arc(x - Math.min(Lay.cs - 6, ctx.measureText(nm(i)).width / 2 + 6), fy + 10, 3, 0, 7); ctx.fill();
        // status badge: choosing / ready / danger / pebble target
        const by2 = y - 9;
        if (!anim && st.ph === 'c') {
          const ready = st.ch[i] != null || (api.canAct(i) && sent[i] === st.r);
          ctx.fillStyle = ready ? '#e3ae45' : 'rgba(46,38,64,0.95)'; ctx.strokeStyle = ready ? '#fff1c8' : 'rgba(200,182,255,0.45)'; ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.arc(x + vd / 2 - 2, y + 2, 7.5, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = ready ? '#2a1d05' : '#d9cfe6'; ctx.font = '700 10px ' + FONT;
          ctx.fillText(ready ? '✓' : '·'.repeat(1 + Math.floor(now / 400) % 3), x + vd / 2 - 2, y + 2 + (ready ? 0.5 : -1));
          const dz = danger(st, i);
          if (dz > 0) {
            const txt = '⚠' + Math.round(dz * 100) + '%'; ctx.font = '700 10.5px ' + MONO;
            const tw = ctx.measureText(txt).width + 8;
            ctx.fillStyle = dz >= 0.5 ? 'rgba(238,74,58,0.92)' : 'rgba(196,120,40,0.9)'; rr(ctx, x - tw / 2, by2 - 8, tw, 15, 7); ctx.fill();
            ctx.fillStyle = '#fff4e6'; ctx.fillText(txt, x, by2 - 0.5);
          }
          const me = inputSeat();
          if (me >= 0 && mode === 'r' && i === lureT) {
            ctx.save(); ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2; ctx.setLineDash([4, 4]); ctx.lineDashOffset = -now / 50;
            rr(ctx, x - vd / 2 - 5, y - 5, vd + 10, vd + 10, 8); ctx.stroke(); ctx.restore();
            ctx.font = '15px ' + FONT; ctx.fillText('🌑', x + vd / 2 + 4, y - 4);
          }
        }
        const bb = bubbles[i];
        if (bb && anim) {
          const a2 = Math.min(1, bb.t * 5);
          ctx.save(); ctx.globalAlpha = a2; ctx.font = '700 11px ' + FONT;
          const tw = ctx.measureText(bb.text).width + 10;
          ctx.fillStyle = 'rgba(16,12,23,0.9)'; rr(ctx, x - tw / 2, by2 - 9 - (1 - a2) * 6, tw, 17, 8); ctx.fill();
          ctx.fillStyle = bb.col; ctx.fillText(bb.text, x, by2 - 0.5 - (1 - a2) * 6); ctx.restore();
        }
        if (anim && last.c.includes(i) && t > 0.85) {
          const p = Math.max(0, 1 - (t - 0.85) / 1.2);
          ctx.save(); ctx.strokeStyle = 'rgba(255,90,70,' + (0.4 + 0.6 * p).toFixed(2) + ')'; ctx.lineWidth = 3; rr(ctx, x - vd / 2 - 3, y - 3, vd + 6, vd + 6, 7); ctx.stroke(); ctx.restore();
        }
      }
      // pebble arc
      if (anim && last.lu >= 0 && t > 0.05 && t < 0.5) {
        const f = (t - 0.05) / 0.45, tx = spotX(vaultPos(last.lu));
        for (let i = 0; i < st.n; i++) {
          if (last.a[i] !== 'r') continue;
          const sx = spotX(vaultPos(i)), x = sx + (tx - sx) * f, y = Lay.floorY - Lay.vd - 6 - Math.sin(f * Math.PI) * 26;
          ctx.fillStyle = '#9a8f86'; ctx.beginPath(); ctx.arc(x, y, 3.2, 0, 7); ctx.fill();
        }
      }
      // guards
      for (let g = 0; g < st.gp.length; g++) { const q = guardPos(g, t); drawGuard(q.x, q.d, q.walk, now); }
    }
    function drawSlots(now) {
      const seat = persp(), S = SF(), v = vals(seat), cw = sel(seat), C = candsOf(seat), cl = lastClues(seat);
      const can = inputSeat() === seat && !anim;
      const t = anim ? anim.t : 99, ae = anim && anim.e[0] === 't' ? parseT(anim.e) : null;
      for (let w = 0; w < st.W; w++) {
        const x = Lay.sx + w * (Lay.sw + Lay.sg), y = Lay.slotY, sw = Lay.sw, sh = Lay.slotH, on = w === cw;
        // feedback being revealed right now?
        let clue = cl[w];
        if (anim && anim.e[0] === 't' && ae) { const t0 = 1.0 + w * 0.42 + 0.28; clue = t >= t0 ? { f: ae.f[w], v: ae.v[w] } : (anim.fired.end ? clue : prevClue(seat, w)); }
        if (anim && anim.e[0] === 'd' && +anim.e[1] === w && t < 1.9) clue = prevClue(seat, w);
        const known = C[w].length === 1 && (!anim || t > anim.fb);
        ctx.save();
        ctx.fillStyle = '#121016'; rr(ctx, x, y, sw, sh, 9); ctx.fill();
        const ig = ctx.createLinearGradient(0, y, 0, y + sh); ig.addColorStop(0, 'rgba(255,255,255,0.06)'); ig.addColorStop(0.5, 'rgba(255,255,255,0)'); ig.addColorStop(1, 'rgba(0,0,0,0.3)');
        ctx.fillStyle = ig; rr(ctx, x, y, sw, sh, 9); ctx.fill();
        if (clue) { ctx.fillStyle = fbCol(S, clue.f); ctx.globalAlpha = 0.9; rr(ctx, x + 4, y + 3, sw - 8, 4, 2); ctx.fill(); ctx.globalAlpha = 1; }
        ctx.lineWidth = on ? 2.5 : 1; ctx.strokeStyle = on ? '#e3ae45' : known ? 'rgba(255,212,90,0.6)' : 'rgba(242,233,216,0.18)';
        if (on && can) { ctx.shadowColor = '#e3ae45'; ctx.shadowBlur = 10; }
        rr(ctx, x + 0.5, y + 0.5, sw - 1, sh - 1, 9); ctx.stroke(); ctx.shadowBlur = 0;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const wide = sw >= 70;
        ctx.fillStyle = '#ab9fb8'; ctx.font = '700 ' + (wide ? 10 : 9) + 'px ' + FONT; ctx.fillText((w + 1) + '칸', x + (wide ? 15 : 13), y + (wide ? 14 : 12));
        const big = Math.round(Math.min(sh * (wide ? 0.42 : 0.37), sw * (wide ? 0.36 : 0.33)));
        ctx.font = '700 ' + big + 'px ' + MONO; ctx.fillStyle = known ? '#ffd45a' : '#f2e9d8';
        ctx.fillText(String(v[w]).padStart(2, '0'), x + sw / 2 + (wide ? 6 : 0), y + sh * (wide ? 0.44 : 0.5));
        // bottom line: candidates (helper) or the last click (during the reveal: the click just heard)
        let bt = '', bc = '#ab9fb8';
        if (anim && t <= anim.fb) { if (ae && t >= 1.28 + w * 0.42) { bt = fbWord(S, ae.f[w]); bc = fbCol(S, ae.f[w]); } }
        else if (known) { bt = '✓ 확정'; bc = '#ffd45a'; }
        else if (st.hl) { bt = '후보 ' + C[w].length; bc = C[w].length <= 3 ? '#9fe0a8' : '#ab9fb8'; }
        else if (clue) { bt = fbWord(S, clue.f); bc = fbCol(S, clue.f); }
        if (bt) { fitText(bt, sw - 6, 11, '700', FONT); ctx.fillStyle = bc; ctx.fillText(bt, x + sw / 2, y + sh - (wide ? 10 : 8)); }
        ctx.restore();
      }
    }
    function prevClue(seat, w) {
      const hs = st.h[seat], keep = hs.slice(0, anim ? anim.last.r : hs.length);
      for (let q = keep.length - 1; q >= 0; q--) {
        const e = keep[q];
        if (e[0] === 't') return { f: +e[1 + st.W + w], v: num(e[1 + w]) };
        if (e[0] === 'l' && +e[1] === w) return { f: +e[3], v: num(e[2]) };
        if (e[0] === 'd' && +e[1] === w) return { f: 0, v: num(e[2]) };
      }
      return null;
    }
    function drawDial(now) {
      const seat = persp(), S = SF(), cx = Lay.cx, cy = Lay.cy, R = Lay.R, N = st.N, w = sel(seat);
      const can = inputSeat() === seat && !anim, z = !!st.zz[seat] && can;
      const dim = !anim && (!can || mode === 'r' || mode === 'h' || z);
      const C = candsOf(seat)[w], cset = new Set(C), mk = marks(seat, w);
      const showCand = st.hl && (!anim || anim.t > anim.fb);
      ctx.save();
      // bezel
      const bz = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R); bz.addColorStop(0, '#d9b45a'); bz.addColorStop(0.5, '#8a6a2c'); bz.addColorStop(1, '#4a3714');
      ctx.fillStyle = bz; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.fill();
      // rotating face
      const fr = R - 6;
      const fg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 0.1, cx, cy, fr); fg.addColorStop(0, '#2e2a33'); fg.addColorStop(1, '#141117');
      ctx.fillStyle = fg; ctx.beginPath(); ctx.arc(cx, cy, fr, 0, 7); ctx.fill();
      const stp = (Math.PI * 2) / N;
      const spacing = (fr - 18) * stp, every = spacing >= 16 ? 1 : spacing >= 8.5 ? 2 : 5;
      const fsz = Math.max(9, Math.min(15, spacing * (every === 1 ? 0.62 : 0.9), R * 0.11));
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let k = 0; k < N; k++) {
        const ang = -Math.PI / 2 - k * stp + theta, ca = Math.cos(ang), sa = Math.sin(ang);
        const isC = cset.has(k), lab = k % every === 0;
        const alpha = showCand && !isC ? 0.25 : 1;
        ctx.strokeStyle = 'rgba(242,233,216,' + (0.75 * alpha).toFixed(2) + ')'; ctx.lineWidth = lab ? 2 : 1.2;
        const r0 = fr - 1, r1 = fr - (lab ? 9 : 6);
        ctx.beginPath(); ctx.moveTo(cx + ca * r0, cy + sa * r0); ctx.lineTo(cx + ca * r1, cy + sa * r1); ctx.stroke();
        if (showCand && isC && C.length < N) {
          ctx.fillStyle = C.length === 1 ? '#ffd45a' : 'rgba(159,224,168,0.9)';
          ctx.beginPath(); ctx.arc(cx + ca * (fr - 13), cy + sa * (fr - 13), C.length === 1 ? 3.6 : 2.3, 0, 7); ctx.fill();
        }
        if (lab) {
          const rl = fr - 13 - fsz * 0.75;
          ctx.font = '700 ' + fsz + 'px ' + MONO;
          ctx.fillStyle = showCand && C.length === 1 && isC ? '#ffd45a' : 'rgba(242,233,216,' + alpha.toFixed(2) + ')';
          ctx.fillText(String(k), cx + ca * rl, cy + sa * rl);
        }
      }
      // marks left by earlier clues (pins on the rim, they turn with the face)
      for (const m of mk) {
        const ang = -Math.PI / 2 - m.v * stp + theta, ca = Math.cos(ang), sa = Math.sin(ang), rp = fr - 3;
        ctx.fillStyle = fbCol(S, m.f); ctx.strokeStyle = '#120e16'; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(cx + ca * rp, cy + sa * rp, m.drill ? 4.5 : 3.6, 0, 7); ctx.fill(); ctx.stroke();
        if (m.d && m.d !== '=') {
          const tang = m.d === '+' ? -1 : 1;  // bigger numbers sit counter-clockwise on the face
          const tx = -sa * tang, ty = ca * tang;
          ctx.strokeStyle = fbCol(S, m.f); ctx.lineWidth = 2; ctx.beginPath();
          ctx.moveTo(cx + ca * rp + tx * 4, cy + sa * rp + ty * 4); ctx.lineTo(cx + ca * rp + tx * 11, cy + sa * rp + ty * 11); ctx.stroke();
        }
      }
      // knob
      const kr = R * 0.43;
      ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 3;
      const kg = ctx.createRadialGradient(cx - kr * 0.4, cy - kr * 0.5, kr * 0.1, cx, cy, kr); kg.addColorStop(0, '#8b8f99'); kg.addColorStop(0.6, '#4a4e58'); kg.addColorStop(1, '#2a2d34');
      ctx.fillStyle = kg; ctx.beginPath(); ctx.arc(cx, cy, kr, 0, 7); ctx.fill();
      ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
      // grip ridges (turn with the face)
      ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 2;
      for (let q = 0; q < 24; q++) { const ang = theta + q * Math.PI / 12; ctx.beginPath(); ctx.moveTo(cx + Math.cos(ang) * kr * 0.86, cy + Math.sin(ang) * kr * 0.86); ctx.lineTo(cx + Math.cos(ang) * kr, cy + Math.sin(ang) * kr); ctx.stroke(); }
      ctx.fillStyle = '#1b1820'; ctx.beginPath(); ctx.arc(cx, cy, kr * 0.74, 0, 7); ctx.fill();
      // big number in the middle
      const cur = (((Math.round(theta / stp)) % N) + N) % N;
      const known = showCand && C.length === 1 && C[0] === cur;
      ctx.font = '700 ' + Math.round(kr * 0.62) + 'px ' + MONO; ctx.fillStyle = known ? '#ffd45a' : '#f2e9d8';
      ctx.fillText(String(cur).padStart(2, '0'), cx, cy - kr * 0.06);
      ctx.font = '700 ' + Math.max(10, Math.round(kr * 0.2)) + 'px ' + FONT; ctx.fillStyle = '#e3ae45';
      ctx.fillText((w + 1) + '칸', cx, cy + kr * 0.45);
      // fixed index notch at the top
      ctx.fillStyle = '#ffe7a8'; ctx.strokeStyle = '#2a1d05'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(cx - 8, cy - R - 3); ctx.lineTo(cx + 8, cy - R - 3); ctx.lineTo(cx, cy - R + 10); ctx.closePath(); ctx.fill(); ctx.stroke();
      if (dim) { ctx.fillStyle = 'rgba(16,12,22,0.5)'; ctx.beginPath(); ctx.arc(cx, cy, R + 1, 0, 7); ctx.fill(); }
      // stethoscope / drill props during the reveal
      if (anim && anim.e[0] === 'l' && anim.t > 0.95 && anim.t < anim.dur) {
        const a2 = -Math.PI / 4, px = cx + Math.cos(a2) * R * 0.9, py = cy + Math.sin(a2) * R * 0.9;
        ctx.strokeStyle = '#c9ccd4'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(px, py); ctx.quadraticCurveTo(px + 30, py - 40, px + 10, py - 70); ctx.stroke();
        ctx.fillStyle = '#d6d9e0'; ctx.beginPath(); ctx.arc(px, py, 9, 0, 7); ctx.fill(); ctx.fillStyle = '#7d828c'; ctx.beginPath(); ctx.arc(px, py, 5, 0, 7); ctx.fill();
        const pulse = (Math.sin(now / 90) + 1) / 2;
        ctx.strokeStyle = 'rgba(159,224,168,' + (0.3 + pulse * 0.5).toFixed(2) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py, 14 + pulse * 6, 0, 7); ctx.stroke();
      }
      if (z) {
        ctx.fillStyle = 'rgba(16,12,22,0.55)'; ctx.beginPath(); ctx.arc(cx, cy, R + 1, 0, 7); ctx.fill();
        ctx.font = '700 15px ' + FONT; ctx.fillStyle = '#ff9a86'; ctx.fillText('들켜서 숨어 있는 중', cx, cy);
      }
      ctx.restore();
    }
    function drawLoot(x, y, w, hh, kind, now) {
      ctx.save();
      const bar = (bx, by, s) => {
        ctx.fillStyle = '#b8862a'; ctx.beginPath(); ctx.moveTo(bx - s, by); ctx.lineTo(bx + s, by); ctx.lineTo(bx + s * 0.75, by - s * 0.5); ctx.lineTo(bx - s * 0.75, by - s * 0.5); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#ffd45a'; ctx.beginPath(); ctx.moveTo(bx - s * 0.75, by - s * 0.5); ctx.lineTo(bx + s * 0.75, by - s * 0.5); ctx.lineTo(bx + s * 0.6, by - s * 0.62); ctx.lineTo(bx - s * 0.6, by - s * 0.62); ctx.closePath(); ctx.fill();
      };
      const gem = (gx, gy, s, c) => {
        ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(gx - s, gy - s * 0.3); ctx.lineTo(gx - s * 0.5, gy - s * 0.8); ctx.lineTo(gx + s * 0.5, gy - s * 0.8); ctx.lineTo(gx + s, gy - s * 0.3); ctx.lineTo(gx, gy + s); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.beginPath(); ctx.moveTo(gx - s * 0.5, gy - s * 0.8); ctx.lineTo(gx, gy - s * 0.3); ctx.lineTo(gx - s, gy - s * 0.3); ctx.closePath(); ctx.fill();
      };
      const coin = (cx2, cy2, s) => { ctx.fillStyle = '#b8862a'; ctx.beginPath(); ctx.ellipse(cx2, cy2 + 1.5, s, s * 0.45, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#ffd45a'; ctx.beginPath(); ctx.ellipse(cx2, cy2, s, s * 0.45, 0, 0, 7); ctx.fill(); };
      const s = Math.min(w, hh) / 9, mx = x + w / 2, by = y + hh * 0.78;
      ctx.shadowColor = '#ffd45a'; ctx.shadowBlur = 18;
      if (kind === 0) { for (let q = 0; q < 26; q++) { const r = q < 10 ? 0 : q < 17 ? 1 : q < 22 ? 2 : 3; const k2 = q - [0, 10, 17, 22][r]; coin(mx - s * 3.4 + r * s * 0.9 + k2 * s * 0.85, by - r * s * 0.55, s * 0.55); } }
      else if (kind === 1 || kind === 4) { for (let r = 0; r < 4; r++) for (let q = 0; q < 4 - r; q++) bar(mx - (3 - r) * s * 1.05 + q * s * 2.1, by - r * s * 0.68, s); }
      else if (kind === 2) { const cs = ['#7fd4ff', '#ff6b8a', '#9fe0a8', '#c8b6ff', '#ffd45a']; for (let q = 0; q < 9; q++) gem(mx - s * 3.2 + (q % 5) * s * 1.6, by - Math.floor(q / 5) * s * 1.3 - (q % 2) * s * 0.3, s * 0.7, cs[q % 5]); }
      else if (kind === 3) {
        ctx.fillStyle = '#e8b84a'; ctx.beginPath(); ctx.moveTo(mx - s * 1.2, by); ctx.quadraticCurveTo(mx - s * 2.2, by - s * 2.2, mx - s * 0.6, by - s * 3.6); ctx.lineTo(mx + s * 0.6, by - s * 3.6); ctx.quadraticCurveTo(mx + s * 2.2, by - s * 2.2, mx + s * 1.2, by); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#ff6b8a'; ctx.beginPath(); ctx.arc(mx, by - s * 2, s * 0.4, 0, 7); ctx.fill();
        gem(mx - s * 3, by - s * 0.2, s * 0.7, '#7fd4ff'); gem(mx + s * 3, by - s * 0.2, s * 0.7, '#9fe0a8');
      }
      if (kind === 4) {
        const cy2 = by - s * 3.4; ctx.fillStyle = '#ffd45a';
        ctx.beginPath(); ctx.moveTo(mx - s * 2, cy2); ctx.lineTo(mx - s * 2.2, cy2 - s * 1.8); ctx.lineTo(mx - s, cy2 - s * 0.9); ctx.lineTo(mx, cy2 - s * 2.2); ctx.lineTo(mx + s, cy2 - s * 0.9); ctx.lineTo(mx + s * 2.2, cy2 - s * 1.8); ctx.lineTo(mx + s * 2, cy2); ctx.closePath(); ctx.fill();
        gem(mx, cy2 - s * 0.5, s * 0.4, '#ff6b8a');
      }
      ctx.restore();
      // twinkles
      for (let q = 0; q < 6; q++) {
        const tw = (Math.sin(now / 300 + q * 1.7) + 1) / 2, sx = x + w * (0.15 + ((q * 37) % 70) / 100), sy = y + hh * (0.25 + ((q * 23) % 50) / 100);
        ctx.fillStyle = 'rgba(255,248,220,' + (tw * 0.9).toFixed(2) + ')'; ctx.beginPath();
        ctx.moveTo(sx, sy - 5 * tw); ctx.lineTo(sx + 1.4, sy); ctx.lineTo(sx, sy + 5 * tw); ctx.lineTo(sx - 1.4, sy); ctx.closePath(); ctx.fill();
      }
    }
    /* door swing: 0 = shut, 1 = wide open (the door narrows toward its left hinge) */
    function doorOpenness() {
      const seat = persp();
      const won = st.ph === 'e' && st.why === 'open' && st.w.includes(seat);
      const op = (anim ? anim.last.o : st.w || []).includes(seat) && st.why === 'open';
      if (anim) { if (!op) return 0; return ease((anim.t - anim.fb - 0.2) / 1.3); }
      return won ? 1 : 0;
    }
    function draw(now) {
      const W = cv.w, H = cv.h;
      if (!st) return;
      if (W !== Lay.W || H !== Lay.H) layout();
      cv.clear();
      ctx.save();
      if (shake > 0.3) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
      const op = doorOpenness();
      if (Lay.bg) {
        if (op <= 0) ctx.drawImage(Lay.bg, 0, 0, W, H);
        else {
          // everything but the door, then the vault interior, then the swinging door
          ctx.drawImage(Lay.bg, 0, 0, Lay.bg.width, Math.ceil(Lay.doorY * cv.dpr), 0, 0, W, Lay.doorY);
          ctx.fillStyle = '#100c16'; ctx.fillRect(0, Lay.doorY, W, H - Lay.doorY);
        }
      }
      drawCorridor(now);
      // info line
      const seat = persp(), S = SF(), can = inputSeat() >= 0;
      let msg = '', mc = '#d9cfe6';
      if (anim) { msg = anim.msg || '…'; mc = '#f2e9d8'; }
      else if (st.ph === 'e') { msg = st.why === 'open' ? (st.w.length ? st.w.map(nm).join(', ') + ' — ' + LOOT[S.loot] + ' 획득!' : '') : st.why === 'police' ? '🚨 경찰이 왔어요' : '🌅 날이 밝았어요'; mc = '#ffd45a'; }
      else if (can) {
        const me = inputSeat(), dz = danger(st, me), who = api.mySeats().length > 1 ? nm(me) + ' · ' : '';
        if (st.zz[me]) { msg = who + '들켜서 이번 라운드는 숨어 있어야 해요'; mc = '#ff9a86'; }
        else if (mode === 'l') { msg = who + '청진기: 고른 칸을 이 숫자에서 조용히 들어요'; mc = '#9fe0a8'; }
        else if (mode === 'd') { msg = who + '드릴: 고른 칸 숫자를 바로 알아내요 (경보 +3)'; mc = '#ffb36b'; }
        else if (mode === 'r') { msg = who + '위쪽 금고를 눌러 돌멩이 던질 곳을 골라요'; mc = '#ffb36b'; }
        else if (mode === 'h') { msg = who + '그림자에 숨어 이번 라운드를 쉬어요'; }
        else if (dz >= 0.5) { msg = who + '⚠ 경비가 올 확률 ' + Math.round(dz * 100) + '% — 숨는 게 안전해요'; mc = '#ff8f7a'; }
        else if (dz > 0) { msg = who + '경비가 올 확률 ' + Math.round(dz * 100) + '% · 칸을 고르고 다이얼을 돌려요'; mc = '#ffcf8a'; }
        else msg = who + '칸을 고르고 다이얼을 돌려 숫자를 맞춰요';
      } else if (api.mySeats().length && api.mySeats().every((i) => st.ch[i] != null || sent[i] === st.r)) msg = '준비 완료 · 다른 도둑을 기다려요';
      else msg = nm(seat) + '의 금고' + (st.n > 1 ? ' · 위쪽 금고를 누르면 바꿔 봐요' : '');
      if (msg) { ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(msg, W - 20, 14, '700', FONT); ctx.fillStyle = mc; ctx.fillText(msg, W / 2, Lay.infoY); }
      // the door (slots + dial), swinging open when this safe was cracked
      if (op > 0) {
        const ix = Lay.doorX + 10, iy = Lay.doorY + 10, iw = Lay.doorW - 20, ih = Lay.doorH - 20;
        const ig = ctx.createLinearGradient(0, iy, 0, iy + ih); ig.addColorStop(0, '#2a1f12'); ig.addColorStop(1, '#120c06');
        ctx.fillStyle = ig; rr(ctx, ix, iy, iw, ih, 10); ctx.fill();
        ctx.strokeStyle = 'rgba(227,174,69,0.4)'; ctx.lineWidth = 2; for (let q = 1; q < 3; q++) { ctx.beginPath(); ctx.moveTo(ix + 8, iy + ih * q / 3); ctx.lineTo(ix + iw - 8, iy + ih * q / 3); ctx.stroke(); }
        ctx.globalAlpha = Math.min(1, op * 1.5); drawLoot(ix, iy + ih * 0.2, iw, ih * 0.75, S.loot, now); ctx.globalAlpha = 1;
        const sx = Math.max(0.04, Math.cos(op * Math.PI * 0.46));
        ctx.save(); ctx.translate(Lay.doorX, 0); ctx.scale(sx, 1); ctx.translate(-Lay.doorX, 0);
        if (Lay.bg) ctx.drawImage(Lay.bg, 0, Math.floor(Lay.doorY * cv.dpr), Lay.bg.width, Lay.bg.height - Math.floor(Lay.doorY * cv.dpr), 0, Lay.doorY, W, H - Lay.doorY);
        drawSlots(now); drawDial(now);
        ctx.fillStyle = 'rgba(0,0,0,' + (0.55 * (1 - sx)).toFixed(2) + ')'; ctx.fillRect(Lay.doorX, Lay.doorY, Lay.doorW, Lay.doorH);
        ctx.restore();
      } else { drawSlots(now); drawDial(now); }
      // legend
      if (op <= 0) {
        const parts2 = legendParts(S); ctx.font = '700 11px ' + FONT; ctx.textBaseline = 'middle';
        const segs = parts2.map((p) => [p[0] + ' ' + p[1], p[2]]);
        let tot = 0; segs.forEach((sg, i) => { tot += ctx.measureText(sg[0]).width + (i ? 12 : 0); });
        let x = W / 2 - tot / 2; ctx.textAlign = 'left';
        segs.forEach((sg, i) => { if (i) { ctx.fillStyle = 'rgba(242,233,216,0.3)'; ctx.fillText('·', x + 3, Lay.legY); x += 12; } ctx.fillStyle = sg[1]; ctx.fillText(sg[0], x, Lay.legY); x += ctx.measureText(sg[0]).width; });
      }
      // particles
      for (const p of parts) {
        const f = 1 - p.t / p.max;
        if (p.text) {
          ctx.save(); ctx.globalAlpha = Math.min(1, f * 2); ctx.fillStyle = p.col; ctx.font = '700 ' + (p.big ? 19 : 13) + 'px ' + (p.big ? DISP : FONT);
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.strokeStyle = 'rgba(16,12,23,0.9)'; ctx.lineWidth = 4; ctx.strokeText(p.text, p.x, p.y); ctx.fillText(p.text, p.x, p.y); ctx.restore();
        } else { ctx.globalAlpha = Math.max(0, f); ctx.fillStyle = p.col; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * (0.5 + f * 0.5), 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
      }
      // banner
      if (banner) {
        const a2 = Math.min(1, banner.t * 4) * Math.min(1, Math.max(0, 2.6 - banner.t) * 2);
        if (a2 > 0) {
          ctx.save(); ctx.globalAlpha = a2; const y = doorOpenness() > 0 ? Lay.doorY + 44 : Lay.cy;
          fitText(banner.text, W - 40, 28, '400', DISP);
          const tw = ctx.measureText(banner.text).width + 28;
          ctx.fillStyle = 'rgba(16,12,23,0.88)'; rr(ctx, W / 2 - tw / 2, y - 22, tw, 44, 14); ctx.fill();
          ctx.strokeStyle = banner.col; ctx.lineWidth = 2; rr(ctx, W / 2 - tw / 2, y - 22, tw, 44, 14); ctx.stroke();
          ctx.fillStyle = banner.col; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(banner.text, W / 2, y + 1); ctx.restore();
        }
      }
      ctx.restore();
      if (flash > 0.02) { ctx.fillStyle = 'rgba(' + flashCol + ',' + (flash * 0.3).toFixed(3) + ')'; ctx.fillRect(0, 0, W, H); }
    }

    /* ---- main loop ---- */
    const stop = U.loop((dt, now) => {
      if (dead) return;
      dt = Math.min(dt, 0.1);
      stepAnim(dt);
      if (!drag && !anim && st) {
        // keep the dial face on the shown wheel's number (seat / wheel changes, other devices…)
        const s2 = persp(), v2 = vals(s2)[sel(s2)], cur = ((Math.round(thetaT / stepA()) % st.N) + st.N) % st.N;
        if (cur !== v2) aimTheta(v2);
      }
      if (!drag) theta += (thetaT - theta) * Math.min(1, dt * 14 * Math.max(1, Math.min(4, spd())));
      shake *= Math.pow(0.02, dt); flash *= Math.pow(0.05, dt);
      if (banner) { banner.t += dt * Math.min(spd(), 3); if (banner.t > 2.7) banner = null; }
      for (const k in bubbles) bubbles[k].t += dt;
      for (let q = parts.length - 1; q >= 0; q--) { const p = parts[q]; p.t += dt; if (p.t >= p.max) { parts.splice(q, 1); continue; } p.x += p.vx * dt; p.y += p.vy * dt; if (p.g) p.vy += 420 * dt; else if (!p.text) { p.vx *= 0.95; p.vy *= 0.95; } }
      draw(now);
    });

    function update(next, prev) {
      const first = !st;
      st = next;
      if (first) layout();
      if (prev && prev !== next && next.last && next.last.id !== seenId) { seenId = next.last.id; startAnim(next.last); }
      else if (next.last) seenId = next.last.id;
      if (first) { const s = persp(); theta = thetaT = vals(s)[sel(s)] * stepA(); }
      layout(); refresh();
    }
    cv.onresize = () => { layout(); };

    return {
      update,
      destroy() {
        dead = true; stop();
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('wheel', onWheel);
        removeEventListener('keydown', onKeyEsc, true);
        if (offInput) offInput();
        timers.forEach(clearTimeout); timers.clear();
        if (busy) api.setBusy(false);
        cv.destroy(); root.innerHTML = '';
      },
    };
  }

  L.register({
    id: 'safecrack', name: '금고 털기', tag: '다이얼 추리 경주', cat: '보드',
    blurb: '괴도가 되어 다이얼을 돌려 금고 비밀번호를 찾아요. 딸깍 소리로 얼마나 가까운지 알 수 있어요 — 경비를 피해 가장 먼저 여는 도둑이 승리!',
    tint: '#3a4252',
    icon: '<rect x="6" y="8" width="44" height="40" rx="5" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="12" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="4" fill="currentColor"/><path d="M28 13v5M28 38v5M13 28h5M38 28h5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><rect x="2" y="16" width="5" height="8" rx="1.5" fill="currentColor"/><rect x="2" y="32" width="5" height="8" rx="1.5" fill="currentColor"/><path d="M12 48v4M44 48v4" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, aiDelay: 1300,
    options: [
      { id: 'safe', label: '금고', choices: SAFES.map((x) => ({ v: x.id, label: x.n })).concat([{ v: 'rnd', label: '무작위' }]), def: 'bank' },
      { id: 'help', label: '추리 도우미', choices: [{ v: 'on', label: '가능한 숫자 표시' }, { v: 'off', label: '끔 (직접 추리)' }], def: 'on' },
    ],
    quick: [
      '도둑마다 자기 금고가 있어요. 다이얼을 돌려 칸마다 숫자를 맞춰 「시도」 — 가장 먼저 여는 도둑이 이겨요.',
      '시도하면 칸마다 소리가 나요: 철컥 = 정답, 딸깍딸깍 = 아주 가까움, 딸깍 = 가까움, … = 멀어요.',
      '경비가 올 것 같으면(⚠%) 숨으세요. 시도할 때마다 경보가 올라 가득 차면 경찰이 와요.',
    ],
    rules: [
      { h: '목표', p: [
        '괴도가 되어 금고를 여는 경주예요. 금고 비밀번호(칸마다 숫자 하나)를 알아내 가장 먼저 연 도둑이 이겨요.',
        '도둑마다 자기 금고가 따로 있고 비밀번호도 다 달라요. 그래서 모든 기록은 서로 다 보여요.',
        '혼자 하면: 경찰이 오기 전에 열면 성공! 경보를 적게 울릴수록 별(★)이 많아요.'] },
      { h: '한 라운드', p: [
        '① 모두 동시에 할 일을 하나 골라요: 시도 · 청진기 · 드릴 · 돌멩이 · 숨기.',
        '② 모두 고르면 한꺼번에 공개! 경비가 걸어가고, 금고마다 딸깍 소리가 나요.',
        '③ 누군가 금고를 열면 끝. 아니면 다음 라운드.'] },
      { h: '다이얼 돌리기', p: [
        '위쪽 칸(1칸, 2칸…)을 눌러 고르고, 가운데 다이얼을 손가락으로 빙글 돌려 숫자를 맞춰요. 딸깍딸깍 걸리는 느낌이 나요.',
        '◀ ▶ 버튼으로 한 칸씩 돌려도 돼요. 시계 방향으로 돌리면 숫자가 커져요.',
        '모든 칸을 맞췄으면 「시도」!'] },
      { h: '딸깍 소리 읽기', p: [
        '시도하면 칸마다 소리가 나요. 다이얼은 동그래서 0 옆이 맨 끝 숫자예요(은행 금고: 0 옆에 29).',
        '철컥 = 그 칸 정답. 딸깍딸깍 = 아주 가까움. 딸깍 = 가까움. … = 멀어요.',
        '얼마나 가까운지는 금고마다 달라요. 다이얼 아래 줄에 늘 적혀 있어요 (예: 딸깍딸깍 ±2 = 2칸 안쪽).',
        '다이얼 테두리에 지난 시도가 색 점으로 남아요. 「추리 도우미」가 켜져 있으면 아직 가능한 숫자에 초록 점이 찍혀요.'] },
      { h: '예시 (은행 금고: 딸깍딸깍 ±2 · 딸깍 ±6)', p: [
        '1칸에 10을 넣었더니 「딸깍딸깍」 → 정답은 8·9·11·12 중 하나.',
        '다음에 11을 넣었더니 「딸깍딸깍」 → 9·12 중 하나 (8은 11에서 3칸이라 「딸깍」이었을 거예요).',
        '이렇게 칸마다 따로 좁혀 가요. 모든 칸을 한 번에 시도하니 여러 칸을 같이 풀 수 있어요.'] },
      { h: '도구', p: [
        '🩺 청진기 (2번): 고른 칸 하나를 지금 다이얼 숫자에서 조용히 들어요. 딸깍 소리 + 「더 큰 쪽 / 더 작은 쪽」까지 알려 줘요. 경보 0.',
        '🔩 드릴 (1번): 고른 칸의 숫자를 바로 알아내요. 대신 시끄러워서 경보 +3.',
        '🌑 돌멩이 (1번, 2명 이상): 다른 도둑 금고 쪽으로 돌을 던져 경비를 그리로 불러요. 그 도둑이 숨지 않았으면 들켜요. 던질 때 나는 숨어 있어서 안전해요.',
        '🙈 숨기: 이번 라운드는 아무것도 안 하고 그림자에 숨어요. 경보 0.'] },
      { h: '경비와 경보', p: [
        '경비는 복도를 한 칸씩 걸어 다녀요. 보통 가던 방향으로 가지만 4번에 1번쯤 뒤돌아요. 금고 위 ⚠% = 이번에 경비가 내 금고 앞에 설 확률.',
        '경비가 선 금고에서 시도·청진기·드릴을 하면 들켜요: 그 행동은 무효, 경보 +2, 다음 라운드는 숨어 있어야 해요.',
        '경보는 시도 +1, 드릴 +3, 돌멩이 +1, 들킴 +2만큼 올라요(모두 함께 쓰는 경보). 가득 차면 경찰 출동으로 끝!',
        '경찰이 오면(또는 20라운드가 지나 날이 밝으면) 비밀번호를 가장 많이 알아낸 도둑이 이겨요.',
        '같은 라운드에 여럿이 열면 경보를 덜 울린 도둑이 이겨요.'] },
      { h: '금고 6가지', p: SAFES.map((x) => x.n + ': ' + x.d + ' · 경보 ' + x.bud + '×인원') },
      { h: '여럿이 할 때', p: [
        '한 폰에서 여럿이 하면 차례로 자기 금고 다이얼을 맞추고 「시도」를 눌러요. 고른 행동은 공개 전까지 안 보여요.',
        '위쪽 복도의 금고를 누르면 그 도둑의 기록을 볼 수 있어요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 어려움은 단서를 똑똑하게 좁히고 도구도 잘 쓰지만, 가끔 경비를 얕보다 들켜요.'] },
      { h: 'PC 조작', p: [
        '마우스로 다이얼을 끌어 돌리거나 휠을 굴려요. ← → (A D) = 한 칸씩, ↑ ↓ (W S) = 칸 바꾸기.',
        'Enter·스페이스 = 결정, H = 숨기, L = 기록.'] },
    ],
    tutorial: [
      { sel: '.sc-dialbox', text: '가운데 다이얼을 손가락으로 빙글 돌려 숫자를 맞춰요. 맨 위 ▼ 표시에 온 숫자가 지금 숫자예요. ◀ ▶로 한 칸씩도 돼요.' },
      { sel: '.sc-slots', text: '금고는 여러 칸이에요. 칸을 눌러 고른 뒤 다이얼을 돌려요. 모든 칸이 정답이면 금고가 열려요!' },
      { sel: '.sc-go', text: '「시도」를 누르면 칸마다 소리가 나요. 철컥 = 정답, 딸깍딸깍 = 아주 가까움, 딸깍 = 가까움, … = 멀어요.' },
      { sel: '.sc-corr', text: '복도에 도둑마다 금고가 있고 경비가 돌아다녀요. 내 금고 위에 ⚠%가 크면 「숨기」! 들키면 그 라운드는 무효고 다음 라운드도 쉬어요.' },
      { sel: '.sc-tools', text: '청진기는 조용히 한 칸의 방향까지, 드릴은 한 칸의 숫자를 바로 알려 줘요(시끄러움). 돌멩이로 경비를 다른 도둑에게 보낼 수도 있어요.' },
      { sel: '.sc-alarm', text: '시도할 때마다 경보가 올라요. 가득 차면 경찰이 와서 끝 — 그때는 가장 많이 알아낸 도둑이 이겨요.' },
    ],
    controls: [
      { id: 'left', label: '다이얼 한 칸 작게', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '다이얼 한 칸 크게', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'prev', label: '이전 칸', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'lb'] },
      { id: 'next', label: '다음 칸', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'rb'] },
      { id: 'go', label: '결정', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'hide', label: '숨기', keys: ['KeyH'], pad: ['b'] },
      { id: 'log', label: '기록 보기', keys: ['KeyL'], pad: ['y'] },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { SAFES, cands, danger, decC, decA, encA, fbOf, dist, dirOf, gstep, progress, bestProbe, vaultPos },
  });
})();
