/* 우주 쓰레기 청소선 — realtime orbital junk-collecting race (1–4, one person per phone).
   Top-down: Earth in the middle, everything orbits it in the same direction (real central gravity).
   Thrust forward → the orbit grows (and you get slower); thrust backward → it shrinks (and you get faster).
   Controls stay simple: tap a piece of junk / the station / a ship → the autopilot flies there (dives lower to catch up,
   climbs to wait), or hold 감속/가속 for manual burns along the flight path. The predicted orbit is drawn as an ellipse.
   Catch junk with the net (5 slots), deliver at a recycling station for points (same-type ×2, all three types +30).
   Big junk splits into 3 pieces. Hard bumps between ships spill half the cargo. Hazards: debris shower band, solar flare.
   Host-authoritative: host/local runs the world (fixed 1/120 s sub-steps) incl. AI ships; guests publish {m, tg, n} and
   render 20 Hz snapshots (hostSend) with gravity extrapolation. Coarse phases via setState: count → play → done. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;

  /* ======================= constants ======================= */
  const MU = 202500, SUB = 1 / 120, CAP = 5;
  const SHIP_R = 5, NET_R = 8, DOCK_R = 16, RMAX = 162, JMAX = 30;
  const A_MAN = 7, A_AUTO = 18;   // manual burns are gentle: 1 s of thrust moves the far side of the orbit ~60
  const VAL = [10, 20, 30];
  const TNAME = ['금속', '패널', '위성'], TCH = 'mps';
  const TCOL = ['#c9d2de', '#5cb8ff', '#ffc84a', '#ff9a66'];
  const COUNT_T = 3.2, TIP_T = 7;
  const r1 = (v) => Math.round(v * 10) / 10, r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = (x, y) => Math.sqrt(x * x + y * y);
  const fin = (v) => typeof v === 'number' && isFinite(v);
  function wrapA(a) { a = (a + Math.PI) % TAU; if (a < 0) a += TAU; return a - Math.PI; }
  function mkRng(seed) {
    let a = (seed >>> 0) || 0x9e3779b9;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ======================= maps (orbits) =======================
     RE: Earth radius, sr: start radius, st: stations [{r (periapsis), ph (angle), e}], jb: junk altitude band,
     jn: small junk kept around, big: big junk kept around, hz: [min,max] s between hazards, hk: hazard kinds (0 debris, 1 flare),
     moon: {r, R, mu}, neb: background nebula colours, star: points per minute for ★/★★/★★★ (solo) */
  const MAPS = [
    { nm: '저궤도 청소', sub: '처음 하기 좋아요 · 정거장 1곳', RE: 40, sr: 100, st: [{ r: 96, ph: 0.6 }], jb: [62, 150], jn: 16, big: 2,
      hz: [30, 42], hk: [0, 1], neb: ['#1b2f6b', '#3a1e5c'], star: [125, 200, 260] },
    { nm: '쌍둥이 정거장', sub: '안쪽·바깥쪽 정거장 2곳', RE: 40, sr: 104, st: [{ r: 70, ph: 0 }, { r: 140, ph: Math.PI }], jb: [60, 152], jn: 16, big: 2,
      hz: [30, 42], hk: [0, 1], neb: ['#163d5c', '#2c1f55'], star: [105, 170, 225] },
    { nm: '쓰레기 고리', sub: '바깥 고리에 쓰레기가 잔뜩 · 정거장은 안쪽', RE: 40, sr: 96, st: [{ r: 68, ph: 2.2 }], jb: [120, 152], jn: 20, big: 3,
      hz: [24, 34], hk: [0, 0, 1], ring: 1, neb: ['#3d2a14', '#1d2350'], star: [80, 130, 175] },
    { nm: '달 그림자', sub: '달 근처는 달에 끌려가요', RE: 36, sr: 92, st: [{ r: 84, ph: 1.4 }], jb: [58, 150], jn: 16, big: 2,
      hz: [32, 44], hk: [0, 1], moon: { r: 143, R: 11, mu: 0.02 }, neb: ['#25264a', '#14334a'], star: [110, 175, 230] },
    { nm: '타원 정거장', sub: '정거장이 길쭉한 궤도로 돌아요', RE: 40, sr: 100, st: [{ r: 64, ph: -0.4, e: 0.38 }], jb: [62, 152], jn: 17, big: 2,
      hz: [30, 42], hk: [0, 1], neb: ['#41203f', '#1a2d5e'], star: [80, 130, 170] },
    { nm: '태양 폭풍', sub: '플레어가 자주! 지구 그림자로 숨어요', RE: 44, sr: 104, st: [{ r: 102, ph: 3.6 }], jb: [66, 152], jn: 18, big: 2,
      hz: [15, 21], hk: [1, 1, 0], aurora: 1, neb: ['#4a2a12', '#2a1640'], star: [120, 195, 255] },
  ];

  /* ======================= physics helpers ======================= */
  const G = { gx: 0, gy: 0, ax: 0, ay: 0 };
  function grav(W, x, y, o) {
    const q = x * x + y * y, r = Math.sqrt(q) || 1, f = -MU / (q * r);
    o.gx = x * f; o.gy = y * f;
    const m = W.mo;
    if (m) { const dx = m.x - x, dy = m.y - y, d2 = dx * dx + dy * dy + 64, d = Math.sqrt(d2), g = m.mu / (d2 * d); o.gx += dx * g; o.gy += dy * g; }
  }
  function orbitOf(x, y, vx, vy) {
    const r = hyp(x, y) || 1, v2 = vx * vx + vy * vy, rv = x * vx + y * vy;
    const ex = ((v2 - MU / r) * x - rv * vx) / MU, ey = ((v2 - MU / r) * y - rv * vy) / MU, e = hyp(ex, ey);
    const en = v2 / 2 - MU / r;
    if (en >= -1e-6 || e >= 0.995) return { a: Infinity, e, ex, ey, rp: r, ra: Infinity };
    const a = -MU / (2 * en);
    return { a, e, ex, ey, rp: a * (1 - e), ra: a * (1 + e) };
  }
  const omega = (r) => Math.sqrt(MU / (r * r * r));
  function body(x, y, vx, vy) { return { x, y, vx, vy, ox: 0, oy: 0 }; }
  function circ(r, a, e) { const v = Math.sqrt(MU * (1 + (e || 0)) / r); return body(Math.cos(a) * r, Math.sin(a) * r, -Math.sin(a) * v, Math.cos(a) * v); }

  /* ======================= world ======================= */
  function pickType(rnd) { const r = rnd(); return r < 0.5 ? 0 : r < 0.8 ? 1 : 2; }
  function spawnJunk(W, big) {
    const M = W.M;
    for (let tries = 0; tries < 14; tries++) {
      const r = M.jb[0] + Math.random() * (M.jb[1] - M.jb[0]), a = Math.random() * TAU;
      const x = Math.cos(a) * r, y = Math.sin(a) * r;
      let bad = false;
      for (const s of W.sh) if (hyp(s.x - x, s.y - y) < 38) { bad = true; break; }
      for (const t of W.ST) if (hyp(t.x - x, t.y - y) < 26) bad = true;
      if (W.mo && hyp(W.mo.x - x, W.mo.y - y) < W.mo.R + 16) bad = true;
      if (bad) continue;
      const vc = Math.sqrt(MU / r), tx = -Math.sin(a), ty = Math.cos(a), rx = Math.cos(a), ry = Math.sin(a);
      let vt = vc * (1 + (Math.random() - 0.5) * 0.1), vr = (Math.random() - 0.5) * 5;
      const o = orbitOf(x, y, tx * vt + rx * vr, ty * vt + ry * vr);
      if (o.rp < W.RE + 14 || o.ra > RMAX - 4) { vt = vc; vr = 0; }
      const j = body(x, y, tx * vt + rx * vr, ty * vt + ry * vr);
      j.id = W.idc++; j.k = big ? 3 : pickType(Math.random); j.nc = 0;
      W.J.push(j);
      return j;
    }
    return null;
  }
  function newWorld(st) {
    const M = MAPS[st.mp] || MAPS[0];
    const W = { M, RE: M.RE, t: 0, dur: st.dur, hzOn: st.hz ? 1 : 0, sh: [], J: [], ST: [], mo: null, hz: null, hzId: 0,
      nextHz: 24 + Math.random() * 10, spT: 1, idc: 1, fx: [], fq: 0, np: st.np };
    for (let i = 0; i < st.np; i++) {
      const s = circ(M.sr, -Math.PI / 2 + i * TAU / st.np);
      Object.assign(s, { c: '', st: 0, iv: 0, th: 0, ta: 0, sc: 0, dl: 0, pc: 0 });
      W.sh.push(s);
    }
    for (const q of M.st) { const t = circ(q.r, q.ph, q.e); W.ST.push(t); }
    if (M.moon) { const m = circ(M.moon.r, 0.9); m.R = M.moon.R; m.mu = M.moon.mu * MU; W.mo = m; }
    for (let i = 0; i < M.jn; i++) spawnJunk(W, 0);
    for (let i = 0; i < M.big; i++) spawnJunk(W, 1);
    return W;
  }
  function fx(W, k, x, y, a, b, c) {
    W.fq++;
    W.fx.push([W.fq, k, r1(x), r1(y), a | 0, b | 0, c | 0]);
    if (W.fx.length > 14) W.fx.splice(0, W.fx.length - 14);
  }
  function objOf(W, tg) {
    if (!tg) return null;
    if (tg[0] === 'j') { for (const j of W.J) if (j.id === tg[1]) return j; return null; }
    if (tg[0] === 's') return W.ST[tg[1]] || null;
    if (tg[0] === 'p') return W.sh[tg[1]] || null;
    return null;
  }
  function validTg(tg, np, self) {
    if (!Array.isArray(tg) || tg.length < 2 || !fin(+tg[1])) return null;
    const k = tg[0], v = +tg[1];
    if (k === 'a') return ['a', clamp(v, 40, RMAX)];
    if (k === 'j') return ['j', v | 0];
    if (k === 's' && v >= 0 && v < 3) return ['s', v | 0];
    if (k === 'p' && v >= 0 && v < np && v !== self) return ['p', v | 0];
    return null;
  }

  /* autopilot: object far away → change altitude to fix the phase (lower = faster), close → match & approach */
  function steer(W, s, c, o) {
    o.ax = 0; o.ay = 0;
    const tg = c.tg, amax = c.amax || A_AUTO;
    const r = hyp(s.x, s.y) || 1, rx = s.x / r, ry = s.y / r, tx = -ry, ty = rx;
    let rd = -1, q = null, dvx = 0, dvy = 0, gain = 1.7, ffx = 0, ffy = 0;
    if (tg[0] === 'a') rd = tg[1];
    else { q = objOf(W, tg); if (!q || q === s) return; }
    const vt = s.vx * tx + s.vy * ty, vr0 = s.vx * rx + s.vy * ry, vc = Math.sqrt(MU / r);
    const low = r < W.RE + 22 && (vt < vc * 0.93 || vr0 < -4);
    if (low) rd = W.RE + 32;        // emergency: climb back to a safe circular orbit first
    else if (q) {
      const dx = q.x - s.x, dy = q.y - s.y, d = hyp(dx, dy) || 1, rq = hyp(q.x, q.y);
      if (d < 44 && (Math.abs(rq - r) < 18 || (tg[0] === 's' && d < 40))) {
        const sp = Math.min(tg[0] === 'p' ? 30 : 24, 5 + d);
        dvx = q.vx + dx / d * sp - s.vx; dvy = q.vy + dy / d * sp - s.vy; gain = 2.4;
        // relative gravity feed-forward (keeps up with a target on a slightly different orbit)
        grav(W, q.x, q.y, o); ffx = o.gx; ffy = o.gy; grav(W, s.x, s.y, o); ffx -= o.gx; ffy -= o.gy;
      } else {
        // catch up from behind (dive lower = faster) or wait higher (slower)? pick the quicker one, keep the choice
        let dp = wrapA(Math.atan2(q.y, q.x) - Math.atan2(s.y, s.x));
        const key = tg[0] + tg[1];
        if (c.pk !== key || Math.abs(dp) < 0.35) {
          const ahead = dp >= 0 ? dp : dp + TAU, behind = TAU - ahead;
          const lo = Math.max(W.RE + 18, rq - 42), hi = Math.min(RMAX - 10, rq + 42), wq = omega(rq);
          const tA = ahead / Math.max(1e-3, omega(lo) - wq), tB = behind / Math.max(1e-3, wq - omega(hi));
          c.pk = key; c.pd = tA <= tB * 1.1 ? 1 : -1;
        }
        if (c.pd > 0 && dp < -0.35) dp += TAU; else if (c.pd < 0 && dp > 0.35) dp -= TAU;
        rd = rq - clamp(dp * 32, -42, 42);
      }
    }
    if (rd >= 0) {
      rd = clamp(rd, W.RE + 16, RMAX - 10);
      const vrd = clamp((rd - r) * 0.75, -14, 14);
      dvx = tx * vc + rx * vrd - s.vx; dvy = ty * vc + ry * vrd - s.vy;
      if (!q && !low && Math.abs(rd - r) < 2.5 && dvx * dvx + dvy * dvy < 0.6) return;
    }
    let ax = dvx * gain + ffx, ay = dvy * gain + ffy;
    const a = hyp(ax, ay);
    if (a < 0.4) return;
    if (a > amax) { ax *= amax / a; ay *= amax / a; }
    o.ax = ax; o.ay = ay;
  }

  function spill(W, i, n) {
    const s = W.sh[i];
    n = Math.min(n, s.c.length);
    for (let k = 0; k < n; k++) {
      const ch = s.c[s.c.length - 1]; s.c = s.c.slice(0, -1);
      const a = Math.random() * TAU, sp = 6 + Math.random() * 5;
      const j = body(s.x + Math.cos(a) * 7, s.y + Math.sin(a) * 7, s.vx + Math.cos(a) * sp, s.vy + Math.sin(a) * sp);
      j.id = W.idc++; j.k = Math.max(0, TCH.indexOf(ch)); j.nc = 1.0;
      W.J.push(j);
    }
    return n;
  }
  function deliverPts(c) {
    let base = 0; const has = [0, 0, 0];
    for (const ch of c) { const k = TCH.indexOf(ch); if (k >= 0) { base += VAL[k]; has[k]++; } }
    let combo = 0, pts = base;
    if (c.length >= 3 && (has[0] === c.length || has[1] === c.length || has[2] === c.length)) { pts *= 2; combo |= 1; }
    if (has[0] && has[1] && has[2]) { pts += 30; combo |= 2; }
    return { pts, combo };
  }

  const NOC = { m: 0, tg: null, amax: A_AUTO };
  function stepWorld(W, h, C, live, auth) {
    const RE = W.RE;
    for (let i = 0; i < W.sh.length; i++) {
      const s = W.sh[i], c = C[i] || NOC;
      let ax = 0, ay = 0;
      if (auth) {
        s.th = 0;
        if (live && s.st <= 0) {
          if (c.m) {
            // manual burn along the flight path; a safety stop keeps the orbit inside the arena
            const v = hyp(s.vx, s.vy) || 1, o = c.m > 0 ? orbitOf(s.x, s.y, s.vx, s.vy) : null;
            if (!o || o.ra < RMAX + 6) { ax = s.vx / v * c.m * A_MAN; ay = s.vy / v * c.m * A_MAN; }
          }
          else if (c.tg) { steer(W, s, c, G); ax = G.ax; ay = G.ay; }
          if (ax * ax + ay * ay > 9) { s.th = 1; s.ta = Math.atan2(ay, ax); }
        }
      }
      grav(W, s.x, s.y, G);
      s.vx += (G.gx + ax) * h; s.vy += (G.gy + ay) * h;
      s.x += s.vx * h; s.y += s.vy * h;
      if (s.st > 0) s.st -= h;
      if (s.iv > 0) s.iv -= h;
      if (auth) bounds(W, s, i);
    }
    for (let j = W.J.length - 1; j >= 0; j--) {
      const q = W.J[j];
      grav(W, q.x, q.y, G);
      q.vx += G.gx * h; q.vy += G.gy * h; q.x += q.vx * h; q.y += q.vy * h;
      if (q.nc > 0) q.nc -= h;
      if (!auth) continue;
      const r = hyp(q.x, q.y);
      if (r < RE + 3) { fx(W, 8, q.x, q.y, -1, q.k, 0); W.J.splice(j, 1); continue; }
      if (r > RMAX + 24) { W.J.splice(j, 1); continue; }
      if (W.mo && hyp(W.mo.x - q.x, W.mo.y - q.y) < W.mo.R + 2) { fx(W, 8, q.x, q.y, -2, q.k, 0); W.J.splice(j, 1); }
    }
    for (const t of W.ST) {
      const m = W.mo; W.mo = null; grav(W, t.x, t.y, G); W.mo = m;
      t.vx += G.gx * h; t.vy += G.gy * h; t.x += t.vx * h; t.y += t.vy * h;
    }
    if (W.mo) {
      const m = W.mo; W.mo = null; grav(W, m.x, m.y, G); W.mo = m;
      m.vx += G.gx * h; m.vy += G.gy * h; m.x += m.vx * h; m.y += m.vy * h;
    }
    if (live && auth) { catches(W, C); collisions(W, C); docks(W, C); }
  }
  function bounds(W, s, i) {
    const r = hyp(s.x, s.y) || 1, nx = s.x / r, ny = s.y / r, vr = s.vx * nx + s.vy * ny;
    const lo = W.RE + 5;
    if (r < lo) {
      s.x = nx * lo; s.y = ny * lo;
      if (vr < 0) { s.vx -= nx * vr * 1.5; s.vy -= ny * vr * 1.5; }
      if (s.iv <= 0) {
        let lost = 0;
        if (s.c.length) { s.c = s.c.slice(0, -1); lost = 1; }
        s.st = Math.max(s.st, 0.8); s.iv = 1.6;
        fx(W, 8, s.x, s.y, i, lost, 1);
      }
    } else if (r > RMAX) {
      s.x = nx * RMAX; s.y = ny * RMAX;
      if (vr > 0) { s.vx -= nx * vr * 1.5; s.vy -= ny * vr * 1.5; }
    }
    const m = W.mo;
    if (m) {
      const dx = s.x - m.x, dy = s.y - m.y, d = hyp(dx, dy) || 1, mr = m.R + SHIP_R;
      if (d < mr) {
        const ux = dx / d, uy = dy / d, rel = (s.vx - m.vx) * ux + (s.vy - m.vy) * uy;
        s.x = m.x + ux * mr; s.y = m.y + uy * mr;
        if (rel < 0) { s.vx -= ux * rel * 1.6; s.vy -= uy * rel * 1.6; if (rel < -8 && s.iv <= 0) { s.st = Math.max(s.st, 0.6); s.iv = 1; fx(W, 4, s.x, s.y, i, -1, 0); } }
      }
    }
  }
  function catches(W, C) {
    for (let i = 0; i < W.sh.length; i++) {
      const s = W.sh[i];
      if (s.st > 0) continue;
      for (let j = W.J.length - 1; j >= 0; j--) {
        const q = W.J[j];
        if (q.nc > 0) continue;
        const big = q.k === 3, rr = NET_R + (big ? 6 : 2.5), dx = q.x - s.x, dy = q.y - s.y;
        if (dx * dx + dy * dy > rr * rr) continue;
        if (big) { split(W, j, i, C); continue; }
        if (s.c.length >= CAP) continue;
        s.c += TCH[q.k]; s.pc++;
        W.J.splice(j, 1);
        fx(W, 1, q.x, q.y, i, q.k, q.id);
        clearTg(W, C, 'j', q.id);
      }
    }
  }
  // a finished/vanished target → hold the current altitude (circularise) instead of drifting on a lopsided orbit
  function holdTg(W, s) { return ['a', Math.round(clamp(hyp(s.x, s.y), W.RE + 16, RMAX - 10))]; }
  function clearTg(W, C, k, v) { C.forEach((c, i) => { if (c && c.tg && c.tg[0] === k && c.tg[1] === v && W.sh[i]) c.tg = holdTg(W, W.sh[i]); }); }
  function split(W, j, i, C) {
    const q = W.J[j], s = W.sh[i];
    W.J.splice(j, 1);
    clearTg(W, C, 'j', q.id);
    const ks = U.shuffle([2, Math.random() < 0.5 ? 0 : 1, Math.random() < 0.6 ? 0 : 1]);
    let got = -1;
    if (s.c.length < CAP) { got = ks.pop(); s.c += TCH[got]; s.pc++; }
    const base = Math.random() * TAU;
    ks.forEach((k, n) => {
      const a = base + n * Math.PI + 0.6, sp = 7 + Math.random() * 3;
      const p = body(q.x + Math.cos(a) * 6, q.y + Math.sin(a) * 6, q.vx + Math.cos(a) * sp, q.vy + Math.sin(a) * sp);
      p.id = W.idc++; p.k = k; p.nc = 0.7;
      W.J.push(p);
    });
    fx(W, 2, q.x, q.y, i, got + 1, 0);
  }
  function collisions(W, C) {
    const S = W.sh, m = SHIP_R * 2;
    for (let i = 0; i < S.length; i++) for (let j = i + 1; j < S.length; j++) {
      const a = S[i], b = S[j], dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy;
      if (d2 >= m * m) continue;
      const d = Math.sqrt(d2) || 0.01, nx = d2 ? dx / d : 1, ny = d2 ? dy / d : 0;
      const rel = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
      const ov = (m - d) / 2 + 0.05;
      a.x -= nx * ov; a.y -= ny * ov; b.x += nx * ov; b.y += ny * ov;
      if (rel >= 0) continue;
      const imp = rel * 0.9;
      a.vx += nx * imp; a.vy += ny * imp; b.vx -= nx * imp; b.vy -= ny * imp;
      const hard = rel < -6;
      let la = 0, lb = 0;
      if (hard) {
        if (a.iv <= 0) { la = spill(W, i, Math.ceil(a.c.length / 2)); a.st = 1.0; a.iv = 2.2; }
        if (b.iv <= 0) { lb = spill(W, j, Math.ceil(b.c.length / 2)); b.st = 1.0; b.iv = 2.2; }
        clearTg(W, C, 'p', i); clearTg(W, C, 'p', j);
      }
      fx(W, 4, (a.x + b.x) / 2, (a.y + b.y) / 2, i, j, hard ? 1 + la * 8 + lb * 64 : 0);
    }
  }
  function docks(W, C) {
    for (let i = 0; i < W.sh.length; i++) {
      const s = W.sh[i];
      if (!s.c.length || s.st > 0) continue;
      for (let k = 0; k < W.ST.length; k++) {
        const t = W.ST[k];
        if (hyp(t.x - s.x, t.y - s.y) > DOCK_R) continue;
        const r = deliverPts(s.c);
        s.sc += r.pts; s.dl++; s.c = '';
        fx(W, 3, t.x, t.y, i, r.pts, r.combo);
        if (C[i] && C[i].tg && C[i].tg[0] === 's') C[i].tg = holdTg(W, s);
        break;
      }
    }
  }
  function inShadow(W, x, y, a) {
    const sx = Math.cos(a), sy = Math.sin(a);
    return x * sx + y * sy < 0 && Math.abs(x * sy - y * sx) < W.RE * 1.08;
  }
  function hazards(W, dt) {
    if (!W.hzOn) return;
    const z = W.hz;
    if (!z) {
      W.nextHz -= dt;
      if (W.nextHz <= 0 && W.dur - W.t > 12) {
        const hk = W.M.hk, k = hk[Math.floor(Math.random() * hk.length)];
        W.hzId++;
        if (k === 0) {
          const s = W.sh[Math.floor(Math.random() * W.sh.length)];
          const r = clamp(hyp(s.x, s.y) + (Math.random() - 0.5) * 16, W.RE + 26, RMAX - 16);
          W.hz = { k: 0, p: 0, t: 3.5, r, w: 13, hit: 0, id: W.hzId };
        } else W.hz = { k: 1, p: 0, t: 3.8, a: Math.random() * TAU, hit: 0, id: W.hzId };
        fx(W, 9, 0, 0, k, 0, 0);
      }
      return;
    }
    z.t -= dt;
    if (z.p === 0) {
      if (z.t > 0) return;
      z.p = 1; z.t = z.k === 0 ? 3.2 : 0.9;
      if (z.k === 1) {
        fx(W, 6, Math.cos(z.a) * 150, Math.sin(z.a) * 150, 0, 0, 0);
        W.sh.forEach((s, i) => { if (!inShadow(W, s.x, s.y, z.a) && s.iv <= 0) { s.st = Math.max(s.st, 2.2); s.iv = 2.6; fx(W, 10, s.x, s.y, i, 0, 0); } });
      } else fx(W, 7, 0, 0, 0, 0, 0);
      return;
    }
    if (z.k === 0) {
      W.sh.forEach((s, i) => {
        if (z.hit & (1 << i) || s.iv > 0) return;
        if (Math.abs(hyp(s.x, s.y) - z.r) > z.w) return;
        z.hit |= 1 << i;
        const n = spill(W, i, Math.ceil(s.c.length / 2));
        s.st = Math.max(s.st, 1.2); s.iv = 2;
        fx(W, 5, s.x, s.y, i, n, 0);
      });
    }
    if (z.t <= 0) { W.hz = null; W.nextHz = W.M.hz[0] + Math.random() * (W.M.hz[1] - W.M.hz[0]); }
  }
  function spawns(W, dt) {
    W.spT -= dt;
    if (W.spT > 0) return;
    W.spT = 1.1;
    let sm = 0, bg = 0;
    for (const j of W.J) { if (j.k === 3) bg++; else sm++; }
    if (bg < W.M.big && Math.random() < 0.35) spawnJunk(W, 1);
    else if (sm < W.M.jn && W.J.length < JMAX) spawnJunk(W, 0);
  }
  function tickWorld(W, dt, C, live, auth) {
    const n = Math.max(1, Math.ceil(dt / SUB - 1e-6)), h = dt / n;
    for (let k = 0; k < n; k++) stepWorld(W, h, C, live, auth);
    if (live && auth) { W.t += dt; hazards(W, dt); spawns(W, dt); }
  }

  /* ======================= AI ======================= */
  const AIP = {
    1: { amax: 14, think: 1.7, react: 1.0, noise: 0.6, dodge: 0, ram: 0, combo: 0, rand: 0.3, early: 0, steal: 0 },
    2: { amax: 17, think: 0.9, react: 0.45, noise: 0.3, dodge: 0.6, ram: 0.2, combo: 0.6, rand: 0, early: 1, steal: 0.5 },
    3: { amax: 22, think: 0.3, react: 0.1, noise: 0.03, dodge: 1, ram: 0.7, combo: 1, rand: 0, early: 2, steal: 1, clu: 1 },
  };
  function eta(s, q) {
    const dx = q.x - s.x, dy = q.y - s.y, d = hyp(dx, dy);
    if (d < 44) return d / 20;
    const r1_ = hyp(s.x, s.y), r2_ = hyp(q.x, q.y);
    let dp = wrapA(Math.atan2(q.y, q.x) - Math.atan2(s.y, s.x)); if (dp < -2.2) dp += TAU;
    return 1.2 + Math.abs(r2_ - r1_) / 11 + Math.abs(dp) / 0.42;
  }
  function comboMul(c, k) {
    if (!c.length) return 1;
    const has = [0, 0, 0]; for (const ch of c) has[TCH.indexOf(ch)]++;
    const kinds = (has[0] ? 1 : 0) + (has[1] ? 1 : 0) + (has[2] ? 1 : 0);
    if (kinds === 1) return has[k] ? 1.5 : c.length === 1 ? 1.05 : 0.8;
    if (kinds === 2) return has[k] ? 0.9 : 1.6;
    return 1;
  }
  function bestStation(W, s) {
    let bi = 0, be = 1e9;
    W.ST.forEach((t, i) => { const e = eta(s, t); if (e < be) { be = e; bi = i; } });
    return { i: bi, e: be };
  }
  function bestJunk(W, i, D, skipId) {
    const s = W.sh[i];
    let best = null, bv = -1;
    for (const q of W.J) {
      if (q.nc > 0.3 || q.id === skipId) continue;
      if (q.k !== 3 && s.c.length >= CAP) continue;
      if (hyp(q.x, q.y) < W.RE + 13) continue;
      const e = eta(s, q);
      let v = q.k === 3 ? 48 : VAL[q.k];
      if (q.k !== 3 && D.combo) v *= 1 + (comboMul(s.c, q.k) - 1) * D.combo;
      if (D.steal) for (let o = 0; o < W.sh.length; o++) {
        if (o === i || W.sh[o].c.length >= CAP) continue;
        if (eta(W.sh[o], q) < e * 0.6) { v *= 1 - 0.5 * D.steal; break; }
      }
      if (W.hz && W.hz.k === 0 && D.dodge && Math.abs(hyp(q.x, q.y) - W.hz.r) < W.hz.w + 4) v *= 0.4;
      if (D.clu) { let nb = 0; for (const o of W.J) if (o !== q && Math.abs(o.x - q.x) < 32 && Math.abs(o.y - q.y) < 32) nb++; v *= 1 + D.clu * 0.18 * Math.min(3, nb); }
      let sc = v / (e + 1.5);
      sc *= 1 + (Math.random() - 0.5) * 2 * D.noise;
      if (sc > bv) { bv = sc; best = q; }
    }
    return best;
  }
  function aiThink(W, i, mem, lv, dt, c) {
    const D = AIP[lv] || AIP[2], s = W.sh[i];
    c.m = 0; c.amax = D.amax;
    mem.t = (mem.t || 0) - dt;
    if (c.tg && c.tg[0] !== 'a' && !objOf(W, c.tg)) { c.tg = null; mem.t = Math.min(mem.t, D.react * Math.random()); }
    if (c.tg && c.tg[0] === 'a' && !mem.dz) c.tg = null;   // AI: a finished target means "decide again"
    const z = W.hz;
    // hazard: debris band → step out of the band (rolled once per hazard)
    if (z && z.k === 0 && mem.hz !== z.id) { mem.hz = z.id; mem.dodge = Math.random() < D.dodge; }
    if (z && z.k === 0 && mem.dodge) {
      const r = hyp(s.x, s.y);
      if (Math.abs(r - z.r) < z.w + 8) {
        const lo = z.r - z.w - 14, hi = z.r + z.w + 14;
        const goLo = lo > W.RE + 16 && (r < z.r || hi > RMAX - 10);
        c.tg = ['a', goLo ? lo : hi]; mem.t = 0.6; mem.dz = 1;
        return;
      }
    }
    if (mem.dz && !(z && z.k === 0)) { mem.dz = 0; c.tg = null; mem.t = 0; }
    if (mem.dz) return;
    if (mem.t > 0 && c.tg) return;
    mem.t = D.think * (0.7 + Math.random() * 0.6);
    const n = s.c.length, left = W.dur - W.t, bs = bestStation(W, s);
    if (c.tg && c.tg[0] === 's' && n > 0) return;
    if (n >= CAP || (n > 0 && left < bs.e + (D.early ? 4 : 1.5)) ||
        (D.early >= 1 && n >= 3 && bs.e < 3.5) || (D.early >= 2 && n >= 4 && bs.e < 6)) { c.tg = ['s', bs.i]; return; }
    if (D.ram && n === 0 && s.iv <= 0) {
      for (let o = 0; o < W.sh.length; o++) {
        const t = W.sh[o];
        if (o === i || t.c.length < 3 || t.iv > 0) continue;
        if (hyp(t.x - s.x, t.y - s.y) < 70 && Math.random() < D.ram) { c.tg = ['p', o]; mem.t = 2.5; return; }
      }
    }
    if (c.tg && c.tg[0] === 'p' && mem.t > 0) return;
    let q = bestJunk(W, i, D, -1);
    if (D.rand && Math.random() < D.rand && W.J.length) q = W.J[Math.floor(Math.random() * W.J.length)];
    c.tg = q ? ['j', q.id] : n ? ['s', bs.i] : null;
  }

  /* ======================= coarse state ======================= */
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 1, 4);
    const mo = typeof o.map === 'number' && o.map >= -1 && o.map < MAPS.length ? o.map : -1;
    const dur = [120, 180, 240].includes(+o.time) ? +o.time : 180;
    return { rid: 1 + U.rand(99999), nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), np, mo,
      mp: mo >= 0 ? mo : U.rand(MAPS.length), dur, hz: o.hz === 0 ? 0 : 1, ph: 'count', res: null };
  }
  function finish(st, W) {
    const res = W.sh.map((s, i) => [i, s.sc | 0, s.dl | 0, s.pc | 0]).sort((a, b) => b[1] - a[1] || b[3] - a[3] || a[0] - b[0]);
    return Object.assign({}, st, { ph: 'done', res });
  }
  function starsOf(st, score) {
    const M = MAPS[st.mp] || MAPS[0], f = st.dur / 60;
    return M.star.reduce((n, v) => n + (score >= v * f ? 1 : 0), 0);
  }
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res) || !st.res.length) return null;
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번', M = MAPS[st.mp] || MAPS[0];
    const lines = st.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '점 · 배달 ' + r[2] + '번');
    if (st.np === 1) {
      const sc = st.res[0][1], n = starsOf(st, sc), f = st.dur / 60;
      const need = M.star.map((v) => Math.round(v * f));
      return { winners: n > 0 ? [0] : [], title: '청소 점수 ' + sc + '점',
        text: M.nm + ' · ' + Math.round(st.dur / 60) + '분\n' + '★★★'.slice(0, n) + '☆☆☆'.slice(0, 3 - n) +
          (n === 3 ? ' 우주 청소의 달인!' : n === 2 ? ' 아주 잘했어요' : n === 1 ? ' 좋아요!' : ' 다음엔 더 많이!') +
          '\n별 기준: ★ ' + need[0] + ' · ★★ ' + need[1] + ' · ★★★ ' + need[2] + '점\n배달 ' + st.res[0][2] + '번 · 잡은 쓰레기 ' + st.res[0][3] + '개' };
    }
    const top = st.res[0][1], winners = st.res.filter((r) => r[1] === top).map((r) => r[0]);
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: M.nm + '\n' + lines.join('\n') };
  }

  /* ======================= net encoding ======================= */
  function encodeWorld(W, key, q) {
    const S = [];
    for (const s of W.sh) S.push(r1(s.x), r1(s.y), r1(s.vx), r1(s.vy), s.c, (s.th ? 1 : 0) | (s.st > 0 ? 2 : 0) | (s.iv > 0 ? 4 : 0), Math.round(s.ta * 10), s.sc, s.dl, s.pc);
    const J = [];
    for (const j of W.J) J.push(j.id, r1(j.x), r1(j.y), r1(j.vx), r1(j.vy), j.k + (j.nc > 0 ? 4 : 0));
    const T = [];
    for (const t of W.ST) T.push(r1(t.x), r1(t.y), r1(t.vx), r1(t.vy));
    const o = { k: key, q, t: r1(W.t), S, J, T, fx: W.fx.slice(-10) };
    if (W.mo) o.M = [r1(W.mo.x), r1(W.mo.y), r1(W.mo.vx), r1(W.mo.vy)];
    if (W.hz) o.H = [W.hz.k, W.hz.p, r1(W.hz.t), W.hz.k ? r2(W.hz.a) : r1(W.hz.r), W.hz.id];
    return o;
  }
  function snapTo(b, x, y, vx, vy) {
    if (!fin(x) || !fin(y)) return;
    const dx = b.x + b.ox - x, dy = b.y + b.oy - y;
    if (dx * dx + dy * dy < 40 * 40) { b.ox = dx; b.oy = dy; } else { b.ox = 0; b.oy = 0; }
    b.x = x; b.y = y; b.vx = fin(vx) ? vx : 0; b.vy = fin(vy) ? vy : 0;
  }
  function applySnap(W, hs) {
    if (fin(hs.t)) W.t = hs.t;
    const S = Array.isArray(hs.S) ? hs.S : [];
    W.sh.forEach((s, i) => {
      const o = i * 10;
      if (S.length < o + 10) return;
      snapTo(s, +S[o], +S[o + 1], +S[o + 2], +S[o + 3]);
      s.c = typeof S[o + 4] === 'string' ? S[o + 4].replace(/[^mps]/g, '').slice(0, CAP) : '';
      const fl = S[o + 5] | 0;
      s.th = fl & 1; s.st = fl & 2 ? Math.max(s.st, 0.15) : 0; s.iv = fl & 4 ? Math.max(s.iv, 0.15) : 0;
      s.ta = (+S[o + 6] || 0) / 10; s.sc = S[o + 7] | 0; s.dl = S[o + 8] | 0; s.pc = S[o + 9] | 0;
    });
    const old = {};
    for (const j of W.J) old[j.id] = j;
    const J = Array.isArray(hs.J) ? hs.J : [], out = [];
    for (let i = 0; i + 5 < J.length; i += 6) {
      const id = J[i] | 0, x = +J[i + 1], y = +J[i + 2];
      if (!fin(x) || !fin(y)) continue;
      let j = old[id];
      if (j) snapTo(j, x, y, +J[i + 3], +J[i + 4]);
      else { j = body(x, y, +J[i + 3] || 0, +J[i + 4] || 0); j.id = id; }
      const kk = J[i + 5] | 0; j.k = kk & 3; j.nc = kk & 4 ? 0.2 : 0;
      out.push(j);
    }
    W.J = out;
    const T = Array.isArray(hs.T) ? hs.T : [];
    W.ST.forEach((t, i) => { if (T.length >= i * 4 + 4) snapTo(t, +T[i * 4], +T[i * 4 + 1], +T[i * 4 + 2], +T[i * 4 + 3]); });
    if (W.mo && Array.isArray(hs.M)) snapTo(W.mo, +hs.M[0], +hs.M[1], +hs.M[2], +hs.M[3]);
    if (Array.isArray(hs.H)) {
      const H = hs.H;
      W.hz = { k: H[0] ? 1 : 0, p: H[1] ? 1 : 0, t: +H[2] || 0, r: H[0] ? 0 : +H[3] || 100, a: H[0] ? +H[3] || 0 : 0, w: 13, id: H[4] | 0, hit: 0 };
    } else W.hz = null;
    if (Array.isArray(hs.fx)) W.fx = hs.fx.filter((e) => Array.isArray(e) && e.length >= 7);
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const HUDH = 46, BARH = 118;
  const ICON = {
    tgt: '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="12" cy="12" r="3" fill="currentColor"/><path d="M12 1v4M12 19v4M1 12h4M19 12h4" stroke="currentColor" stroke-width="2.2"/></svg>',
    home: '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M5 9a8 8 0 0 1 13-3" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M19 2v5h-5" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M19 15a8 8 0 0 1-13 3" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M5 22v-5h5" fill="none" stroke="currentColor" stroke-width="2.4"/></svg>',
  };
  const CSS = `
.jk-bar{position:absolute;left:0;right:0;bottom:0;padding:0 8px 10px;display:flex;flex-direction:column;gap:6px;z-index:3;pointer-events:none}
.jk-hint{align-self:center;font:600 12.5px var(--f-body,system-ui);color:#f2e9d8;background:rgba(10,14,32,.8);border:1px solid rgba(242,233,216,.18);
  border-radius:999px;padding:5px 12px;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:16px;line-height:16px}
.jk-hint.warn{border-color:#ee6a55;color:#ffd2c8}
.jk-row{display:flex;gap:6px;pointer-events:auto}
.jk-b{flex:1 1 0;min-width:0;height:66px;border-radius:16px;border:2px solid rgba(242,233,216,.26);background:rgba(22,28,58,.9);color:#f2e9d8;
  font:700 13px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;touch-action:none;
  user-select:none;-webkit-user-select:none;cursor:pointer;padding:0;-webkit-tap-highlight-color:transparent;box-shadow:0 4px 12px rgba(0,0,0,.35)}
.jk-b b{font-size:20px;line-height:1;font-family:var(--f-mono,monospace)}
.jk-b small{font-size:11px;font-weight:700;opacity:.85;line-height:1}
.jk-b.hold{background:rgba(40,26,52,.92)}
.jk-b.on{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}
.jk-b.sel{border-color:#5fd3a0;box-shadow:0 0 0 2px rgba(95,211,160,.35),0 4px 12px rgba(0,0,0,.35)}
.jk-b.pulse{animation:jkp 1s ease-in-out infinite}
@keyframes jkp{50%{box-shadow:0 0 0 7px rgba(227,174,69,.5),0 4px 12px rgba(0,0,0,.35)}}
.jk-b:disabled{opacity:.45}
`;
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(255,255,255,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function fmtT(t) { t = Math.max(0, Math.ceil(t)); const m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s; }

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    const COL = (s) => P(s).color || ['#ee6a55', '#5bb3e6', '#7cc66a', '#e3ae45'][s % 4];
    let st = null, key = null, W = null, phase = 'wait', cd = 0, tipOn = false, lay = null;
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const ctrlOn = () => me() >= 0 && !auto();
    const curKey = () => (st ? String(st.rid) : null);
    const loc = { m: 0, tg: null, amax: A_AUTO };
    let netN = 0;
    const setTg = (tg) => { loc.tg = tg; netN = (netN + 1) % 100000; };
    let aiC = [], mem = [], remC = {}, C = [];
    let parts = [], floats = [], rings = [], flashT = 0, shake = 0, lastFx = 0, pingT = 0, pingAt = null, fullTold = false;

    /* ---------- DOM controls ---------- */
    const bar = L.h('div', { class: 'jk-bar' });
    const hint = L.h('div', { class: 'jk-hint', text: '' });
    const row = L.h('div', { class: 'jk-row' });
    const mk = (cls, big, small, html) => { const b = L.h('button', { class: 'jk-b ' + cls, type: 'button' }); if (html) b.innerHTML = html; else b.append(L.h('b', { text: big })); b.append(L.h('small', { text: small })); return b; };
    const bRetro = mk('hold', '◀', '감속'), bJunk = mk('', '', '쓰레기', ICON.tgt), bHome = mk('', '', '배달', ICON.home), bPro = mk('hold', '▶', '가속');
    row.append(bRetro, bJunk, bHome, bPro);
    bar.append(hint, row);
    root.append(bar);
    const held = { pro: false, retro: false };
    function holdBtn(b, k) {
      const dn = (e) => { e.preventDefault(); e.stopPropagation(); held[k] = true; try { b.setPointerCapture(e.pointerId); } catch (er) {} };
      const up = (e) => { if (e) e.stopPropagation(); held[k] = false; };
      b.addEventListener('pointerdown', dn); b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
    }
    holdBtn(bRetro, 'retro'); holdBtn(bPro, 'pro');
    bJunk.addEventListener('click', (e) => { e.stopPropagation(); pickJunk(); });
    bHome.addEventListener('click', (e) => { e.stopPropagation(); goHome(); });
    function canCtl() { return W && st && me() >= 0 && phase !== 'done'; }
    function pickJunk() {
      if (!canCtl()) return;
      const m = me(), cur = loc.tg && loc.tg[0] === 'j' ? loc.tg[1] : -1;
      const q = bestJunk(W, m, { combo: 1, steal: 0, noise: 0, dodge: 0 }, cur);
      if (!q) { api.toast('잡을 쓰레기가 없어요'); return; }
      setTg(['j', q.id]); api.sfx('click'); api.buzz(10); pingAt = { x: q.x, y: q.y }; pingT = 0.6;
    }
    function goHome() {
      if (!canCtl()) return;
      const m = me(), s = W.sh[m];
      if (!s.c.length) api.toast('짐칸이 비었어요 · 그래도 정거장으로 가요');
      const b = bestStation(W, s);
      setTg(['s', b.i]); api.sfx('click'); api.buzz(10); pingAt = { x: W.ST[b.i].x, y: W.ST[b.i].y }; pingT = 0.6;
    }
    function goAlt(r) {
      if (!canCtl()) return;
      setTg(['a', Math.round(clamp(r, W.RE + 14, RMAX - 10))]);
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !canCtl()) return;
      if (id === 'junk') pickJunk();
      else if (id === 'home') goHome();
      else if (id === 'stop') { setTg(null); api.sfx('tick'); }
      else if (id === 'up' || id === 'down') {
        const s = W.sh[me()], r = loc.tg && loc.tg[0] === 'a' ? loc.tg[1] : hyp(s.x, s.y);
        goAlt(r + (id === 'up' ? 12 : -12)); api.sfx('tick');
      } else if (id === 'ram') {
        const m = me(), s = W.sh[m]; let bj = -1, bd = 1e9;
        W.sh.forEach((o, j) => { if (j === m) return; const d = hyp(o.x - s.x, o.y - s.y); if (d < bd) { bd = d; bj = j; } });
        if (bj >= 0) { setTg(['p', bj]); api.sfx('click'); }
      }
    }) : null;
    function readInput() {
      const k = api.input;
      const pro = held.pro || !!(k && k.held('pro')), retro = held.retro || !!(k && k.held('retro'));
      const m = canCtl() && phase === 'play' ? (pro ? 1 : 0) - (retro ? 1 : 0) : 0;
      if (m && loc.tg) setTg(null);
      loc.m = m;
      bPro.classList.toggle('on', pro); bRetro.classList.toggle('on', retro);
    }

    /* ---------- canvas pointer: tap a target / tap empty orbit = go to that altitude (drag to adjust) ---------- */
    let drag = null;
    function toWorld(p) { return { x: (p.x - lay.cx) / lay.k, y: (p.y - lay.cy) / lay.k }; }
    function onDown(e) {
      if (!canCtl() || !lay) return;
      const p = cv.local(e);
      if (p.y < HUDH || p.y > cv.h - lay.bot) return;
      const w = toWorld(p), m = me();
      let best = null, bd = 1e9;
      const tryO = (o, tg, lim) => { const d = hyp(o.x + (o.ox || 0) - w.x, o.y + (o.oy || 0) - w.y) * lay.k; if (d < lim && d < bd) { bd = d; best = { tg, o }; } };
      for (const j of W.J) tryO(j, ['j', j.id], 26);
      W.ST.forEach((t, i) => tryO(t, ['s', i], 30));
      W.sh.forEach((o, i) => { if (i !== m) tryO(o, ['p', i], 22); });
      if (best) {
        setTg(best.tg); api.sfx('click'); api.buzz(10); pingAt = { x: best.o.x, y: best.o.y }; pingT = 0.6;
        return;
      }
      const r = hyp(w.x, w.y);
      if (r < W.RE + 2) { api.toast('지구 말고 궤도(바깥쪽)를 눌러요'); return; }
      if (r > RMAX + 14) return;
      goAlt(r); api.sfx('tick');
      drag = { id: e.pointerId };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
    }
    function onMove(e) {
      if (!drag || drag.id !== e.pointerId || !canCtl()) return;
      const w = toWorld(cv.local(e));
      goAlt(hyp(w.x, w.y));
    }
    function onUp(e) { if (drag && drag.id === e.pointerId) drag = null; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    const releaseAll = () => { held.pro = held.retro = false; drag = null; };
    window.addEventListener('blur', releaseAll);

    /* ---------- start / layout ---------- */
    function startGame() {
      key = curKey();
      W = newWorld(st);
      if (!host()) W.J = [];
      aiC = []; mem = []; C = []; remC = {};
      for (let i = 0; i < st.np; i++) { aiC.push({ m: 0, tg: null, amax: A_AUTO }); mem.push({ t: Math.random() * 0.5 }); }
      loc.m = 0; loc.tg = null; netN = 0; lastFx = 0; lastQ = -1;
      parts = []; floats = []; rings = []; flashT = 0; shake = 0; fullTold = false;
      phase = st.ph === 'play' ? 'play' : st.ph === 'done' ? 'done' : 'count';
      let first = false;
      try { first = ctrlOn() && !U.store.get('junk.tips', false); if (first) U.store.set('junk.tips', true); } catch (e) {}
      tipOn = first;
      cd = first ? TIP_T : COUNT_T;
      layout();
    }
    let bgCv = null, bgKey = '', earthCv = null, earthKey = '', jSpr = [], sprKey = '';
    function layout() {
      const w = cv.w, h = cv.h, bot = ctrlOn() ? BARH : 10;
      const fh = h - HUDH - bot - 6, fw = w - 8;
      const k = Math.max(0.5, Math.min(fw, fh) / (2 * RMAX + 14));
      lay = { w, h, bot, k, cx: w / 2, cy: HUDH + 3 + fh / 2, fh };
      bar.style.display = ctrlOn() && phase !== 'done' ? '' : 'none';
    }
    cv.onresize = () => { layout(); };

    /* ---------- fx events → effects ---------- */
    function sfx(n, gap) { const t = performance.now(); sfx.l = sfx.l || {}; if (t - (sfx.l[n] || 0) < (gap || 60)) return; sfx.l[n] = t; api.sfx(n); }
    function addFloat(x, y, text, c, big, life) { floats.push({ x, y, text, c: c || '#fff', big: !!big, t: 0, life: life || 1.3 }); if (floats.length > 24) floats.shift(); }
    function burst(x, y, c, n, sp) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = (0.3 + Math.random()) * (sp || 30); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, life: 0.4 + Math.random() * 0.5, c }); }
      if (parts.length > 260) parts.splice(0, parts.length - 260);
    }
    function onFx(e) {
      const k = e[1], x = e[2], y = e[3], a = e[4], b = e[5], c = e[6], m = me();
      switch (k) {
        case 1: sfx('pop', 50); burst(x, y, TCOL[b], 8, 26); rings.push({ x, y, t: 0, life: 0.35, r0: 3, r1: 12, c: TCOL[b] });
          if (a === m) { addFloat(x, y - 6, '+' + TNAME[b], TCOL[b]); api.buzz(12); if (loc.tg && loc.tg[0] === 'j' && loc.tg[1] === c) loc.tg = holdTg(W, W.sh[m]); }
          break;
        case 2: sfx('thud', 80); burst(x, y, '#ffd0a8', 18, 40); rings.push({ x, y, t: 0, life: 0.5, r0: 4, r1: 20, c: '#ff9a66' });
          addFloat(x, y - 8, '쪼개졌다!', '#ffb98a', false); if (a === m) { api.buzz(20); shake = Math.max(shake, 0.2); }
          break;
        case 3: {
          const mine = a === m;
          sfx(mine ? 'win' : 'chip', 80);
          burst(x, y, COL(a), 26, 46); rings.push({ x, y, t: 0, life: 0.7, r0: 6, r1: 34, c: '#ffe08a' });
          addFloat(x, y - 10, '+' + b, mine ? '#ffe08a' : COL(a), true, 1.7);
          if (c & 1) addFloat(x, y + 10, '같은 종류 ×2!', '#9ff0c8', false, 1.8);
          if (c & 2) addFloat(x, y + (c & 1 ? 24 : 10), '세 종류 세트 +30!', '#9fd8ff', false, 1.8);
          if (mine) { api.buzz(35); if (loc.tg && loc.tg[0] === 's') loc.tg = holdTg(W, W.sh[m]); fullTold = false; }
          break;
        }
        case 4: {
          const hard = c > 0, la = (c - 1) & 7, lb = ((c - 1) >> 3) & 7;
          sfx(hard ? 'hit' : 'bounce', 80);
          rings.push({ x, y, t: 0, life: 0.4, r0: 3, r1: hard ? 18 : 10, c: '#ffffff' });
          if (hard) {
            burst(x, y, '#ffd27a', 14, 40);
            if (a === m || b === m) {
              api.buzz(45); shake = Math.max(shake, 0.4);
              const lost = a === m ? la : lb;
              addFloat(x, y - 10, lost ? '쿵! 짐 ' + lost + '개를 흘렸어요' : '쿵!', '#ffb0a0', false, 1.6);
              if (loc.tg && loc.tg[0] === 'p') loc.tg = holdTg(W, W.sh[m]);
            } else addFloat(x, y - 10, '쿵!', '#fff');
          }
          break;
        }
        case 5: sfx('hit', 80); burst(x, y, '#ff6a55', 14, 34);
          addFloat(x, y - 10, b ? '파편에 맞아 ' + b + '개 흘림' : '파편에 맞았다!', '#ff9a8a', false, 1.6);
          if (a === m) { api.buzz(40); shake = Math.max(shake, 0.35); }
          break;
        case 6: sfx('whoosh', 200); flashT = 0.8; if (m >= 0) api.buzz(30); break;
        case 7: sfx('whoosh', 200); break;
        case 8: burst(x, y, '#ff9a4a', a >= 0 ? 14 : 6, 22);
          if (a >= 0) { sfx('thud', 120); addFloat(x, y - 8, b ? '대기권! 1개가 타 버렸어요' : '대기권! 튕겨 나왔어요', '#ffb070', false, 1.6); if (a === m) api.buzz(30); }
          else if (a === -2) addFloat(x, y - 6, '달에 쾅', '#ccc', false, 0.9);
          break;
        case 9: sfx('tick', 100); setTimeout(() => sfx('tick', 50), 160); break;
        case 10: burst(x, y, '#fff6a0', 10, 30); addFloat(x, y - 10, '⚡ 고장!', '#fff2a0', false, 1.4); if (a === m) api.buzz(30); break;
      }
    }
    function processFx() {
      if (!W) return;
      for (const e of W.fx) if (e[0] > lastFx) { lastFx = e[0]; try { onFx(e); } catch (er) { console.error(er); } }
    }

    /* ---------- host / guest flow ---------- */
    function hostFlow() {
      if (!host() || !st || !W) return;
      if (st.ph === 'count' && phase === 'play') { api.setState(Object.assign({}, st, { ph: 'play' })); return; }
      if (st.ph === 'play' && phase === 'play' && W.t >= W.dur && !W.sent) { W.sent = 1; api.setState(finish(st, W)); }
    }
    let pubT = 0, hsQ = 0, inQ = 0, lastQ = -1, lastSig = '', inT = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const kk in rem) {
        const s = +kk, o = rem[kk];
        if (!(s >= 0 && s < W.sh.length) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remC[s] || (remC[s] = { m: 0, tg: null, amax: A_AUTO, seen: -1 });
        R.m = o.m === 1 ? 1 : o.m === -1 ? -1 : 0;
        const n = o.n | 0;
        if (n !== R.seen) { R.seen = n; R.tg = o.tg == null ? null : validTg(o.tg, W.sh.length, s); }
      }
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.S)) return;
      lastQ = hs.q;
      applySnap(W, hs);
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20; hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(encodeWorld(W, key, hsQ));
        } else {
          if (me() < 0) return;
          const sig = loc.m + '|' + netN;
          if (sig === lastSig && inT > 0) return;
          if (pubT > 0 && sig === lastSig) return;
          lastSig = sig; inT = 0.3; pubT = 1 / 30; inQ = (inQ + 1) % 100000;
          api.net.publish({ k: key, q: inQ, m: loc.m, tg: loc.tg, n: netN });
        }
      } catch (e) {}
    }
    function controls() {
      for (let s = 0; s < W.sh.length; s++) {
        if (isAIseat(s)) C[s] = aiC[s];
        else if (localHuman(s)) C[s] = loc;
        else C[s] = remC[s] || (remC[s] = { m: 0, tg: null, amax: A_AUTO, seen: -1 });
      }
    }

    /* ---------- main loop ---------- */
    function frame(rdt) {
      if (!st) return;
      if (curKey() !== key) startGame();
      if (!W) return;
      const dt = Math.min(0.5, rdt * SPD());
      if (phase === 'count') {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0 && b <= 3) sfx('tick', 40);
        if (cd <= 0 && host()) { phase = 'play'; tipOn = false; sfx('pop'); api.buzz(16); }
      }
      if (phase === 'count' && !host() && st.ph === 'play') { phase = 'play'; tipOn = false; sfx('pop'); }
      if (st.ph === 'done' && phase !== 'done') { phase = 'done'; layout(); }
      readInput();
      if (host()) {
        pollHost();
        if (phase !== 'done') {
          controls();
          const live = phase === 'play';
          if (live) for (let s = 0; s < W.sh.length; s++) if (isAIseat(s)) aiThink(W, s, mem[s], P(s).ai ? lvOf(s) : 2, dt, aiC[s]);
          tickWorld(W, dt, C, live, true);
        }
        hostFlow();
      } else {
        pollGuest();
        if (phase !== 'done') tickWorld(W, dt, [], false, false);
      }
      // my target vanished (someone else took it)?
      if (loc.tg && loc.tg[0] !== 'a' && !objOf(W, loc.tg) && (host() || W.J.length) && me() >= 0) { loc.tg = holdTg(W, W.sh[me()]); }
      processFx();
      publish(rdt);
      const kd = Math.exp(-rdt * 9);
      const dec = (b) => { b.ox *= kd; b.oy *= kd; };
      if (!host()) { W.sh.forEach(dec); W.J.forEach(dec); W.ST.forEach(dec); if (W.mo) dec(W.mo); }
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t += rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.96; p.vy *= 0.96; if (p.t > p.life) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { const f = floats[i]; f.t += rdt; if (f.t > f.life) floats.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { const r = rings[i]; r.t += rdt; if (r.t > r.life) rings.splice(i, 1); }
      if (flashT > 0) flashT -= rdt;
      if (shake > 0) shake -= rdt;
      if (pingT > 0) pingT -= rdt;
    }

    /* ---------- drawing: cached layers ---------- */
    function buildBg() {
      const w = cv.w, h = cv.h, dpr = cv.dpr, M = W.M;
      bgKey = w + 'x' + h + '|' + dpr + '|' + st.mp + '|' + lay.k.toFixed(3);
      bgCv = document.createElement('canvas'); bgCv.width = Math.round(w * dpr); bgCv.height = Math.round(h * dpr);
      const c = bgCv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
      const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#070816'); g.addColorStop(1, '#0d0b1f');
      c.fillStyle = g; c.fillRect(0, 0, w, h);
      const rnd = mkRng(77 + st.mp * 13);
      for (let i = 0; i < 2; i++) {
        const x = w * (0.15 + rnd() * 0.7), y = h * (0.15 + rnd() * 0.7), r = Math.max(w, h) * (0.35 + rnd() * 0.25);
        const ng = c.createRadialGradient(x, y, 0, x, y, r); ng.addColorStop(0, hexA(M.neb[i], 0.45)); ng.addColorStop(1, hexA(M.neb[i], 0));
        c.fillStyle = ng; c.fillRect(0, 0, w, h);
      }
      for (let i = 0; i < 240; i++) {
        const x = rnd() * w, y = rnd() * h, s = rnd(), r = s < 0.85 ? 0.6 : s < 0.97 ? 1 : 1.6;
        c.fillStyle = 'rgba(' + (220 + rnd() * 35 | 0) + ',' + (220 + rnd() * 35 | 0) + ',255,' + (0.35 + rnd() * 0.6).toFixed(2) + ')';
        c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
      }
      const { cx, cy, k } = lay;
      // field edge + altitude guides
      c.strokeStyle = 'rgba(160,190,255,.07)'; c.lineWidth = 1;
      for (let r = 60; r <= 150; r += 30) { c.beginPath(); c.arc(cx, cy, r * k, 0, TAU); c.stroke(); }
      c.setLineDash([3, 6]); c.strokeStyle = 'rgba(160,190,255,.18)';
      c.beginPath(); c.arc(cx, cy, RMAX * k, 0, TAU); c.stroke();
      c.setLineDash([]);
      if (M.ring) {
        const rg = c.createRadialGradient(cx, cy, M.jb[0] * k, cx, cy, M.jb[1] * k);
        rg.addColorStop(0, 'rgba(255,190,120,0)'); rg.addColorStop(0.5, 'rgba(255,190,120,.07)'); rg.addColorStop(1, 'rgba(255,190,120,0)');
        c.fillStyle = rg; c.beginPath(); c.arc(cx, cy, M.jb[1] * k, 0, TAU); c.arc(cx, cy, M.jb[0] * k, 0, TAU, true); c.fill();
      }
    }
    function buildEarth() {
      const RE = W.RE * lay.k, dpr = cv.dpr, S = Math.ceil(RE * 2 + 4);
      earthKey = RE.toFixed(2) + '|' + dpr + '|' + st.mp;
      earthCv = document.createElement('canvas'); earthCv.width = Math.round(S * dpr); earthCv.height = Math.round(S * dpr);
      const c = earthCv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
      const o = S / 2;
      c.save(); c.beginPath(); c.arc(o, o, RE, 0, TAU); c.clip();
      const og = c.createRadialGradient(o - RE * 0.3, o - RE * 0.3, RE * 0.1, o, o, RE);
      og.addColorStop(0, '#3f9be8'); og.addColorStop(0.7, '#1c5fb4'); og.addColorStop(1, '#0e3478');
      c.fillStyle = og; c.fillRect(0, 0, S, S);
      const rnd = mkRng(4242);
      const land = ['#4f9a4a', '#6aa851', '#8f8a52', '#3d7d3f'];
      for (let i = 0; i < 9; i++) {
        const bx = o + (rnd() - 0.5) * RE * 1.8, by = o + (rnd() - 0.5) * RE * 1.6;
        c.fillStyle = land[i % 4];
        for (let j = 0; j < 7; j++) { c.beginPath(); c.arc(bx + (rnd() - 0.5) * RE * 0.55, by + (rnd() - 0.5) * RE * 0.45, RE * (0.08 + rnd() * 0.14), 0, TAU); c.fill(); }
      }
      c.fillStyle = 'rgba(240,248,255,.85)';
      c.beginPath(); c.ellipse(o, o - RE * 0.93, RE * 0.5, RE * 0.14, 0, 0, TAU); c.fill();
      c.beginPath(); c.ellipse(o, o + RE * 0.95, RE * 0.45, RE * 0.12, 0, 0, TAU); c.fill();
      c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineCap = 'round';
      for (let i = 0; i < 8; i++) {
        c.lineWidth = RE * (0.04 + rnd() * 0.05);
        const y = o + (rnd() - 0.5) * RE * 1.6, x = o + (rnd() - 0.5) * RE * 1.6, l = RE * (0.25 + rnd() * 0.4);
        c.beginPath(); c.moveTo(x - l / 2, y); c.quadraticCurveTo(x, y - RE * 0.08, x + l / 2, y); c.stroke();
      }
      c.restore();
    }
    function buildSprites() {
      const dpr = cv.dpr, sc = clamp(lay.k * 1.05, 0.9, 1.4);
      sprKey = dpr + '|' + sc.toFixed(2);
      jSpr = [0, 1, 2, 3].map((k) => {
        const r = (k === 3 ? 8.5 : 4.6) * sc, S = Math.ceil(r * 4.4);
        const cnv = document.createElement('canvas'); cnv.width = Math.round(S * dpr); cnv.height = Math.round(S * dpr);
        const c = cnv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.translate(S / 2, S / 2);
        const g = c.createRadialGradient(0, 0, 0, 0, 0, r * 2.1); g.addColorStop(0, hexA(TCOL[k], 0.5)); g.addColorStop(1, hexA(TCOL[k], 0));
        c.fillStyle = g; c.beginPath(); c.arc(0, 0, r * 2.1, 0, TAU); c.fill();
        c.lineJoin = 'round';
        if (k === 0) {
          c.fillStyle = '#aeb7c4'; c.strokeStyle = '#4c5563'; c.lineWidth = 1;
          c.beginPath(); const pts = [[1, 0], [0.4, 0.8], [-0.5, 0.9], [-1, 0.1], [-0.6, -0.8], [0.3, -0.9]];
          pts.forEach((p, i) => (i ? c.lineTo(p[0] * r, p[1] * r) : c.moveTo(p[0] * r, p[1] * r))); c.closePath(); c.fill(); c.stroke();
          c.strokeStyle = '#eef3f8'; c.beginPath(); c.moveTo(-0.4 * r, -0.4 * r); c.lineTo(0.5 * r, -0.3 * r); c.stroke();
        } else if (k === 1) {
          c.fillStyle = '#1d4fa0'; c.strokeStyle = '#d9b24a'; c.lineWidth = 1;
          c.fillRect(-r * 1.15, -r * 0.7, r * 2.3, r * 1.4); c.strokeRect(-r * 1.15, -r * 0.7, r * 2.3, r * 1.4);
          c.strokeStyle = 'rgba(160,210,255,.8)'; c.lineWidth = 0.7; c.beginPath();
          for (let i = -1; i <= 1; i++) { c.moveTo(i * r * 0.55, -r * 0.7); c.lineTo(i * r * 0.55, r * 0.7); }
          c.moveTo(-r * 1.15, 0); c.lineTo(r * 1.15, 0); c.stroke();
        } else if (k === 2) {
          c.fillStyle = '#3d7fe0'; c.fillRect(-r * 1.5, -r * 0.35, r * 0.8, r * 0.7); c.fillRect(r * 0.7, -r * 0.35, r * 0.8, r * 0.7);
          c.fillStyle = '#ffcc4d'; c.strokeStyle = '#7a5410'; c.lineWidth = 1;
          c.fillRect(-r * 0.6, -r * 0.6, r * 1.2, r * 1.2); c.strokeRect(-r * 0.6, -r * 0.6, r * 1.2, r * 1.2);
          c.strokeStyle = '#fff'; c.beginPath(); c.moveTo(0, -r * 0.6); c.lineTo(0, -r * 1.1); c.stroke();
          c.fillStyle = '#fff'; c.beginPath(); c.arc(0, -r * 1.15, r * 0.18, 0, TAU); c.fill();
        } else {
          c.fillStyle = '#e9e4da'; c.strokeStyle = '#6b5a48'; c.lineWidth = 1.2;
          rr(c, -r * 1.1, -r * 0.55, r * 2.0, r * 1.1, r * 0.3); c.fill(); c.stroke();
          c.fillStyle = '#e0623e'; c.fillRect(-r * 0.5, -r * 0.55, r * 0.25, r * 1.1); c.fillRect(r * 0.15, -r * 0.55, r * 0.25, r * 1.1);
          c.fillStyle = '#4a4a55'; c.beginPath(); c.moveTo(r * 0.9, -r * 0.35); c.lineTo(r * 1.35, -r * 0.6); c.lineTo(r * 1.35, r * 0.6); c.lineTo(r * 0.9, r * 0.35); c.closePath(); c.fill();
        }
        return { cnv, S };
      });
    }

    /* ---------- drawing ---------- */
    const X = (x) => lay.cx + x * lay.k, Y = (y) => lay.cy + y * lay.k;
    function drawEarth(now) {
      const RE = W.RE * lay.k, cx = lay.cx, cy = lay.cy, M = W.M;
      // atmosphere glow
      const ag = ctx.createRadialGradient(cx, cy, RE * 0.9, cx, cy, RE * 1.35);
      ag.addColorStop(0, 'rgba(120,190,255,.55)'); ag.addColorStop(1, 'rgba(120,190,255,0)');
      ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(cx, cy, RE * 1.35, 0, TAU); ctx.fill();
      if (M.aurora) {
        ctx.strokeStyle = 'rgba(120,255,180,' + (0.25 + 0.15 * Math.sin(now / 400)).toFixed(2) + ')'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(cx, cy, RE * 1.12, -2.2, -0.9); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy, RE * 1.12, 0.9, 2.2); ctx.stroke();
      }
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(now / 9000);
      const S = earthCv.width / cv.dpr; ctx.drawImage(earthCv, -S / 2, -S / 2, S, S);
      ctx.restore();
      // day/night shading (sun toward upper-left, or the flare's sun)
      const sa = W.hz && W.hz.k === 1 ? W.hz.a : -2.4, sx = Math.cos(sa), sy = Math.sin(sa);
      const sg = ctx.createLinearGradient(cx + sx * RE, cy + sy * RE, cx - sx * RE, cy - sy * RE);
      sg.addColorStop(0, 'rgba(255,255,230,.12)'); sg.addColorStop(0.45, 'rgba(0,0,20,0)'); sg.addColorStop(0.62, 'rgba(0,0,20,.45)'); sg.addColorStop(1, 'rgba(0,0,20,.8)');
      ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(cx, cy, RE, 0, TAU); ctx.fill();
      // atmosphere danger line
      ctx.strokeStyle = 'rgba(255,120,80,.22)'; ctx.setLineDash([2, 5]); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(cx, cy, (W.RE + 5) * lay.k, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    }
    function drawHazard(now) {
      const z = W.hz; if (!z) return;
      const { cx, cy, k } = lay;
      if (z.k === 0) {
        const r0 = (z.r - z.w) * k, r1_ = (z.r + z.w) * k;
        const pul = 0.5 + 0.5 * Math.sin(now / (z.p ? 90 : 160));
        ctx.fillStyle = z.p ? 'rgba(255,80,60,' + (0.16 + 0.08 * pul).toFixed(3) + ')' : 'rgba(255,90,70,' + (0.07 + 0.08 * pul).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(cx, cy, r1_, 0, TAU); ctx.arc(cx, cy, r0, 0, TAU, true); ctx.fill();
        ctx.strokeStyle = 'rgba(255,110,90,.7)'; ctx.setLineDash([6, 5]); ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.arc(cx, cy, r0, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy, r1_, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
        if (z.p) {
          ctx.strokeStyle = 'rgba(255,220,200,.85)'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
          const tt = now / 1000;
          ctx.beginPath();
          for (let i = 0; i < 46; i++) {
            const rr_ = (z.r + (((i * 37) % 23) / 23 - 0.5) * 2 * z.w * 0.9) * k, a = i * 2.39996 - tt * 1.9;
            ctx.moveTo(cx + Math.cos(a) * rr_, cy + Math.sin(a) * rr_); ctx.lineTo(cx + Math.cos(a + 0.09) * rr_, cy + Math.sin(a + 0.09) * rr_);
          }
          ctx.stroke(); ctx.lineCap = 'butt';
        }
      } else {
        const sx = Math.cos(z.a), sy = Math.sin(z.a), R = W.RE * k, far = Math.max(cv.w, cv.h);
        const ex = cx + sx * far * 0.75, ey = cy + sy * far * 0.75;
        const g = ctx.createRadialGradient(ex, ey, 0, ex, ey, far * 0.8);
        const pul = 0.5 + 0.5 * Math.sin(now / 120);
        g.addColorStop(0, 'rgba(255,230,120,' + (z.p ? 0.6 : 0.25 + 0.15 * pul).toFixed(3) + ')'); g.addColorStop(1, 'rgba(255,200,80,0)');
        ctx.fillStyle = g; ctx.fillRect(0, HUDH, cv.w, cv.h - HUDH);
        // shadow (safe zone) behind Earth
        const px = -sy, py = sx, L2 = RMAX * k + 10;
        ctx.fillStyle = 'rgba(10,14,40,.45)'; ctx.strokeStyle = 'rgba(160,200,255,.65)'; ctx.setLineDash([5, 4]); ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.moveTo(cx + px * R, cy + py * R); ctx.lineTo(cx + px * R - sx * L2, cy + py * R - sy * L2);
        ctx.lineTo(cx - px * R - sx * L2, cy - py * R - sy * L2); ctx.lineTo(cx - px * R, cy - py * R); ctx.closePath();
        ctx.fill(); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(200,225,255,.9)'; ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('그림자 = 안전', cx - sx * (R + 34), cy - sy * (R + 34));
        // sun marker at the edge
        const sr = Math.min((RMAX + 4) * k, cv.w / 2 - 14);
        ctx.fillStyle = '#ffe27a'; ctx.beginPath(); ctx.arc(cx + sx * sr, clamp(cy + sy * sr, HUDH + 46, cv.h - lay.bot - 14), 9 + pul * 2, 0, TAU); ctx.fill();
      }
    }
    function drawStation(t, i, now) {
      const x = X(t.x + t.ox), y = Y(t.y + t.oy), k = lay.k, s = clamp(k, 0.9, 1.4);
      const pul = 0.5 + 0.5 * Math.sin(now / 300 + i);
      ctx.strokeStyle = 'rgba(227,174,69,' + (0.35 + 0.3 * pul).toFixed(2) + ')'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.arc(x, y, DOCK_R * k, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      const g = ctx.createRadialGradient(x, y, 0, x, y, DOCK_R * k); g.addColorStop(0, 'rgba(227,174,69,.22)'); g.addColorStop(1, 'rgba(227,174,69,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, DOCK_R * k, 0, TAU); ctx.fill();
      ctx.save(); ctx.translate(x, y); ctx.rotate(now / 2400 + i);
      ctx.fillStyle = '#2a63b8'; ctx.strokeStyle = '#d9b24a'; ctx.lineWidth = 1;
      ctx.fillRect(-15 * s, -3.5 * s, 9 * s, 7 * s); ctx.strokeRect(-15 * s, -3.5 * s, 9 * s, 7 * s);
      ctx.fillRect(6 * s, -3.5 * s, 9 * s, 7 * s); ctx.strokeRect(6 * s, -3.5 * s, 9 * s, 7 * s);
      ctx.fillStyle = '#d8d2c4'; ctx.fillRect(-6 * s, -1.2 * s, 12 * s, 2.4 * s);
      ctx.fillStyle = '#e3ae45'; ctx.strokeStyle = '#5a3d0a'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.arc(0, 0, 5.5 * s, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = '#2a1d05'; ctx.lineWidth = 1.3;
      for (let a = 0; a < 3; a++) { ctx.beginPath(); ctx.arc(0, 0, 3 * s, a * 2.094 + 0.3, a * 2.094 + 1.6); ctx.stroke(); }
      ctx.restore();
    }
    function stationLabel(t) {
      const x = X(t.x + t.ox), y = Y(t.y + t.oy) + DOCK_R * lay.k + 2;
      ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillStyle = 'rgba(8,10,24,.55)'; rr(ctx, x - 18, y - 1, 36, 13, 4); ctx.fill();
      ctx.fillStyle = 'rgba(255,224,150,.95)'; ctx.fillText('재활용', x, y);
    }
    function drawJunk(now) {
      for (const j of W.J) {
        const sp = jSpr[j.k], x = X(j.x + j.ox), y = Y(j.y + j.oy);
        if (j.nc > 0 && Math.floor(now / 80) % 2) continue;
        ctx.save(); ctx.translate(x, y); ctx.rotate(now / 1000 * (((j.id * 7) % 5) - 2) * 0.6 + j.id);
        ctx.drawImage(sp.cnv, -sp.S / 2, -sp.S / 2, sp.S, sp.S);
        ctx.restore();
        if (j.k === 3) {
          ctx.strokeStyle = 'rgba(255,154,102,' + (0.4 + 0.3 * Math.sin(now / 200 + j.id)).toFixed(2) + ')'; ctx.lineWidth = 1.2; ctx.setLineDash([3, 3]);
          ctx.beginPath(); ctx.arc(x, y, 13 * clamp(lay.k, 0.9, 1.4), 0, TAU); ctx.stroke(); ctx.setLineDash([]);
        }
      }
    }
    function drawOrbit(s, col, alpha, dashOff, warnLow) {
      const o = orbitOf(s.x, s.y, s.vx, s.vy), k = lay.k;
      ctx.save();
      ctx.lineWidth = 1.6; ctx.setLineDash([5, 5]); ctx.lineDashOffset = dashOff;
      if (o.a < 600) {
        const cxo = X(-o.a * o.ex), cyo = Y(-o.a * o.ey), b = o.a * Math.sqrt(Math.max(0, 1 - o.e * o.e));
        const low = o.rp < W.RE + 5;
        ctx.strokeStyle = hexA(low && warnLow ? '#ff6a55' : col, alpha);
        ctx.beginPath(); ctx.ellipse(cxo, cyo, o.a * k, b * k, Math.atan2(o.ey, o.ex), 0, TAU); ctx.stroke();
        if (warnLow && o.e > 0.05) {
          const ux = o.ex / o.e, uy = o.ey / o.e;
          const mark = (r, sign, txt, c) => {
            const px = X(ux * r * sign), py = Y(uy * r * sign);
            ctx.setLineDash([]); ctx.fillStyle = c; ctx.beginPath(); ctx.arc(px, py, 3, 0, TAU); ctx.fill();
            ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillStyle = 'rgba(8,10,24,.75)'; const w = ctx.measureText(txt).width + 8; rr(ctx, px - w / 2, py - 17, w, 14, 5); ctx.fill();
            ctx.fillStyle = c; ctx.fillText(txt, px, py - 10);
          };
          const near = (r, sign) => hyp(ux * r * sign - s.x, uy * r * sign - s.y) * k < 22;
          if (o.ra < RMAX + 30 && !near(o.ra, -1)) mark(o.ra, -1, '높은 곳', '#bfe3ff');
          if (!near(o.rp, 1)) mark(o.rp, 1, low ? '대기권!' : '낮은 곳', low ? '#ff8a75' : '#ffd27a');
        }
      } else {
        // leaving the arena: integrate a short path
        ctx.strokeStyle = hexA('#ff6a55', alpha);
        let x = s.x, y = s.y, vx = s.vx, vy = s.vy;
        ctx.beginPath(); ctx.moveTo(X(x), Y(y));
        for (let i = 0; i < 40 && hyp(x, y) < RMAX + 8; i++) { grav(W, x, y, G); vx += G.gx * 0.05; vy += G.gy * 0.05; x += vx * 0.05; y += vy * 0.05; ctx.lineTo(X(x), Y(y)); }
        ctx.stroke();
      }
      ctx.restore();
    }
    function drawShip(s, i, now) {
      const x = X(s.x + s.ox), y = Y(s.y + s.oy), col = COL(i), m = me();
      const R = clamp(SHIP_R * lay.k * 1.35, 7, 10), hd = Math.atan2(s.vy, s.vx);
      if (s.iv > 0 && Math.floor(now / 90) % 2) ctx.globalAlpha = 0.45;
      if (i === m) {
        const g = ctx.createRadialGradient(x, y, 0, x, y, R * 2.6); g.addColorStop(0, hexA(col, 0.4)); g.addColorStop(1, hexA(col, 0));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, R * 2.6, 0, TAU); ctx.fill();
      }
      if (s.th) {
        const fa = s.ta + Math.PI, fl = R * (1.3 + Math.random() * 0.6);
        ctx.save(); ctx.translate(x, y); ctx.rotate(fa);
        const g = ctx.createLinearGradient(R * 0.4, 0, R * 0.4 + fl, 0); g.addColorStop(0, 'rgba(255,240,200,.95)'); g.addColorStop(0.4, 'rgba(255,150,60,.8)'); g.addColorStop(1, 'rgba(255,80,40,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(R * 0.4, -R * 0.35); ctx.lineTo(R * 0.4 + fl, 0); ctx.lineTo(R * 0.4, R * 0.35); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
      ctx.save(); ctx.translate(x, y); ctx.rotate(hd + (s.st > 0 ? now / 60 : 0));
      // cargo net behind
      const n = s.c.length;
      ctx.strokeStyle = 'rgba(230,230,240,.55)'; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(-R * 0.6, -R * 0.4); ctx.lineTo(-R * 1.5, 0); ctx.lineTo(-R * 0.6, R * 0.4); ctx.stroke();
      if (n) {
        ctx.fillStyle = 'rgba(200,210,230,.18)'; ctx.beginPath(); ctx.arc(-R * 1.75, 0, R * 0.65, 0, TAU); ctx.fill(); ctx.stroke();
        for (let q = 0; q < n; q++) { const a = q * 2.4; ctx.fillStyle = TCOL[TCH.indexOf(s.c[q])]; ctx.beginPath(); ctx.arc(-R * 1.75 + Math.cos(a) * R * 0.32 * (q ? 1 : 0), Math.sin(a) * R * 0.32 * (q ? 1 : 0), R * 0.24, 0, TAU); ctx.fill(); }
      }
      // body
      ctx.fillStyle = col; ctx.strokeStyle = 'rgba(10,10,20,.85)'; ctx.lineWidth = 1.3;
      ctx.beginPath(); ctx.moveTo(R * 1.05, 0); ctx.lineTo(-R * 0.75, -R * 0.75); ctx.lineTo(-R * 0.45, 0); ctx.lineTo(-R * 0.75, R * 0.75); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#eaf6ff'; ctx.beginPath(); ctx.arc(R * 0.2, 0, R * 0.22, 0, TAU); ctx.fill();
      // claw
      const open = n < CAP ? 0.55 : 0.15;
      ctx.strokeStyle = '#e8e2d2'; ctx.lineWidth = 1.4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(R * 0.6, -R * 0.3); ctx.lineTo(R * 1.4, -R * open - R * 0.2); ctx.moveTo(R * 0.6, R * 0.3); ctx.lineTo(R * 1.4, R * open + R * 0.2); ctx.stroke();
      ctx.lineCap = 'butt';
      ctx.restore();
      ctx.globalAlpha = 1;
      if (s.st > 0) { ctx.fillStyle = '#fff3a0'; ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillText('⚡', x + R, y - R); }
      if (i === m || st.np > 1) {
        const lbl = i === m ? '나' : name(i);
        ctx.font = '700 10px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        const w = Math.min(64, ctx.measureText(lbl).width + 8);
        ctx.fillStyle = 'rgba(8,10,24,.6)'; rr(ctx, x - w / 2, y - R - 17, w, 13, 4); ctx.fill();
        ctx.fillStyle = i === m ? '#fff' : hexA(col, 0.95);
        ctx.save(); ctx.beginPath(); ctx.rect(x - w / 2, y - R - 18, w, 15); ctx.clip(); ctx.fillText(lbl, x, y - R - 5); ctx.restore();
      }
    }
    function drawTarget(now) {
      const m = me(); if (m < 0 || !loc.tg) return;
      const s = W.sh[m], col = COL(m);
      if (loc.tg[0] === 'a') {
        ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2; ctx.setLineDash([2, 6]); ctx.lineDashOffset = -now / 60;
        ctx.beginPath(); ctx.arc(lay.cx, lay.cy, loc.tg[1] * lay.k, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
        return;
      }
      const q = objOf(W, loc.tg); if (!q) return;
      const x = X(q.x + q.ox), y = Y(q.y + q.oy), rr_ = 12 + 2 * Math.sin(now / 150);
      if (loc.tg[0] !== 's') drawOrbit(q, '#ffffff', 0.25, 0, false);
      ctx.strokeStyle = hexA(col, 0.5); ctx.lineWidth = 1; ctx.setLineDash([2, 4]);
      ctx.beginPath(); ctx.moveTo(X(s.x + s.ox), Y(s.y + s.oy)); ctx.lineTo(x, y); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2;
      for (let a = 0; a < 4; a++) {
        const b = a * Math.PI / 2 + now / 700;
        ctx.beginPath(); ctx.arc(x, y, rr_, b - 0.4, b + 0.4); ctx.stroke();
      }
    }
    function drawHud(now) {
      const n = st.np, pad = 6, gap = 5, cw = (cv.w - pad * 2 - gap * (n - 1)) / n, m = me();
      for (let i = 0; i < n; i++) {
        const s = W.sh[i], x = pad + i * (cw + gap), y = 4, col = COL(i);
        ctx.fillStyle = 'rgba(18,15,34,.86)'; rr(ctx, x, y, cw, HUDH - 8, 9); ctx.fill();
        ctx.strokeStyle = i === m ? col : 'rgba(242,233,216,.14)'; ctx.lineWidth = i === m ? 2 : 1; rr(ctx, x, y, cw, HUDH - 8, 9); ctx.stroke();
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x + 10, y + 11, 4, 0, TAU); ctx.fill();
        ctx.font = '700 14px ' + MONO; ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ffe08a';
        const scT = String(s.sc); ctx.fillText(scT, x + cw - 6, y + 12);
        const sw = ctx.measureText(scT).width;
        ctx.font = '700 11px ' + FONT; ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8';
        let nm = i === m ? '나' : name(i); const maxW = cw - 24 - sw - 6;
        if (ctx.measureText(nm).width > maxW) { while (nm.length > 1 && ctx.measureText(nm + '…').width > maxW) nm = nm.slice(0, -1); nm += '…'; }
        ctx.fillText(nm, x + 17, y + 12);
        const pw = Math.min(10, (cw - 16 - 4 * 3) / CAP), py = y + 23;
        for (let q = 0; q < CAP; q++) {
          const px = x + 8 + q * (pw + 3), ch = s.c[q];
          if (ch) { ctx.fillStyle = TCOL[TCH.indexOf(ch)]; rr(ctx, px, py, pw, 9, 2); ctx.fill(); }
          else { ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.lineWidth = 1; rr(ctx, px + 0.5, py + 0.5, pw - 1, 8, 2); ctx.stroke(); }
        }
        if (s.c.length >= CAP) { ctx.fillStyle = '#ffd27a'; ctx.font = '700 9px ' + FONT; ctx.textAlign = 'right'; ctx.fillText(cw > 84 ? '가득' : '', x + cw - 5, py + 5); }
        if (s.st > 0) { ctx.font = '700 11px ' + FONT; ctx.textAlign = 'right'; ctx.fillStyle = '#fff3a0'; ctx.fillText('⚡', x + cw - 5, py + 5); }
      }
      // timer (top-left of the field) + map name (top-right)
      const left = W.dur - W.t, ty = HUDH + 4;
      const urgent = phase === 'play' && left <= 10;
      ctx.font = '700 15px ' + MONO; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      const tt = phase === 'count' ? fmtT(W.dur) : fmtT(left), tw = ctx.measureText(tt).width + 16;
      ctx.fillStyle = 'rgba(12,12,28,.72)'; rr(ctx, 8, ty, tw, 24, 8); ctx.fill();
      ctx.fillStyle = urgent ? (Math.floor(now / 250) % 2 ? '#ff7a66' : '#ffd0c8') : '#f2e9d8'; ctx.fillText(tt, 16, ty + 12);
      ctx.font = '600 10.5px ' + FONT; ctx.textAlign = 'right'; ctx.fillStyle = 'rgba(242,233,216,.6)';
      ctx.fillText(W.M.nm, cv.w - 10, ty + 12);
    }
    function drawBanner(now) {
      const z = W.hz;
      let txt = null, col = '#ffb0a0';
      if (z && z.p === 0) {
        txt = z.k === 0 ? '⚠ 파편 소나기! 빨간 띠를 피해요 ' + Math.ceil(z.t) : '☀ 태양 플레어! 지구 그림자로 ' + Math.ceil(z.t);
        col = z.k === 0 ? '#ffb0a0' : '#ffe48a';
      } else if (z && z.p === 1 && z.k === 0) txt = '⚠ 파편 소나기 중!';
      if (!txt) return;
      ctx.font = '700 13px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const w = Math.min(cv.w - 16, ctx.measureText(txt).width + 24), y = HUDH + 44;
      ctx.fillStyle = 'rgba(30,10,14,.85)'; rr(ctx, cv.w / 2 - w / 2, y - 14, w, 28, 14); ctx.fill();
      ctx.strokeStyle = col; ctx.lineWidth = 1.5; rr(ctx, cv.w / 2 - w / 2, y - 14, w, 28, 14); ctx.stroke();
      ctx.fillStyle = col; ctx.fillText(txt, cv.w / 2, y + 0.5);
      void now;
    }
    function drawCount() {
      if (phase !== 'count') return;
      const cx = lay.cx, cy = lay.cy;
      if (tipOn && cd > 3) {
        const w = Math.min(cv.w - 24, 340), h = 150, x = cx - w / 2, y = cy - h / 2;
        ctx.fillStyle = 'rgba(14,12,30,.94)'; rr(ctx, x, y, w, h, 14); ctx.fill();
        ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; rr(ctx, x, y, w, h, 14); ctx.stroke();
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#e3ae45'; ctx.font = '15px ' + DISP; ctx.fillText('청소선 조종 팁', x + 14, y + 20);
        const lines = ['쓰레기를 누르면 자동으로 날아가 그물로 잡아요', '짐칸 5칸이 차면 「배달」 → 정거장에 닿으면 점수', '가속하면 궤도가 높아지고 느려져요 · 낮을수록 빨라요', '같은 종류만 3개+ ×2, 세 종류 모두 +30점'];
        ctx.font = '600 12px ' + FONT;
        lines.forEach((t, i) => {
          ctx.fillStyle = TCOL[i % 3]; ctx.beginPath(); ctx.arc(x + 18, y + 48 + i * 25, 3, 0, TAU); ctx.fill();
          ctx.fillStyle = '#f2e9d8';
          let s = t; const maxW = w - 40;
          if (ctx.measureText(s).width > maxW) { while (s.length > 2 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); s += '…'; }
          ctx.fillText(s, x + 28, y + 48 + i * 25);
        });
        return;
      }
      const n = Math.max(1, Math.ceil(Math.min(cd, 3)));
      ctx.font = '54px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillText(String(n), cx + 2, cy + 2);
      ctx.fillStyle = '#ffe08a'; ctx.fillText(String(n), cx, cy);
    }
    function draw(now) {
      cv.clear();
      if (!st || !W || !lay) return;
      if (!bgCv || bgKey !== cv.w + 'x' + cv.h + '|' + cv.dpr + '|' + st.mp + '|' + lay.k.toFixed(3)) buildBg();
      if (!earthCv || earthKey !== (W.RE * lay.k).toFixed(2) + '|' + cv.dpr + '|' + st.mp) buildEarth();
      const sc = clamp(lay.k * 1.05, 0.9, 1.4);
      if (!jSpr.length || sprKey !== cv.dpr + '|' + sc.toFixed(2)) buildSprites();
      ctx.drawImage(bgCv, 0, 0, cv.w, cv.h);
      const sh = shake > 0 ? shake * 6 : 0;
      ctx.save(); ctx.beginPath(); ctx.rect(0, HUDH, cv.w, cv.h - HUDH - (ctrlOn() && phase !== 'done' ? lay.bot - 40 : 0)); ctx.clip();
      if (sh) ctx.translate((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);
      drawHazard(now);
      drawEarth(now);
      if (W.mo) {
        const mo = W.mo, x = X(mo.x + mo.ox), y = Y(mo.y + mo.oy), R = mo.R * lay.k;
        const g = ctx.createRadialGradient(x - R * 0.3, y - R * 0.3, R * 0.1, x, y, R);
        g.addColorStop(0, '#e9e6de'); g.addColorStop(1, '#8a877f');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, R, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(90,88,82,.55)';
        [[0.3, -0.2, 0.25], [-0.35, 0.3, 0.2], [0.1, 0.45, 0.14]].forEach((c) => { ctx.beginPath(); ctx.arc(x + c[0] * R, y + c[1] * R, c[2] * R, 0, TAU); ctx.fill(); });
        ctx.strokeStyle = 'rgba(220,220,255,.12)'; ctx.setLineDash([2, 5]); ctx.beginPath(); ctx.arc(x, y, R * 2.6, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      }
      W.ST.forEach((t, i) => drawStation(t, i, now));
      drawJunk(now);
      const m = me();
      if (m >= 0) { const s = W.sh[m]; drawOrbit({ x: s.x + s.ox, y: s.y + s.oy, vx: s.vx, vy: s.vy }, '#bfe3ff', 0.8, -now / 40, true); drawTarget(now); }
      W.sh.forEach((s, i) => { if (i !== m) drawShip(s, i, now); });
      if (m >= 0) drawShip(W.sh[m], m, now);
      W.ST.forEach(stationLabel);
      for (const r of rings) {
        const f = r.t / r.life, rad = (r.r0 + (r.r1 - r.r0) * f) * lay.k;
        ctx.strokeStyle = hexA(r.c, (1 - f) * 0.9); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X(r.x), Y(r.y), rad, 0, TAU); ctx.stroke();
      }
      for (const p of parts) { ctx.globalAlpha = Math.max(0, 1 - p.t / p.life); ctx.fillStyle = p.c; ctx.fillRect(X(p.x) - 1.2, Y(p.y) - 1.2, 2.4, 2.4); }
      ctx.globalAlpha = 1;
      if (pingAt && pingT > 0) { ctx.strokeStyle = 'rgba(255,255,255,' + (pingT / 0.6).toFixed(2) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X(pingAt.x), Y(pingAt.y), (1 - pingT / 0.6) * 26 + 6, 0, TAU); ctx.stroke(); }
      for (const f of floats) {
        const a = Math.max(0, 1 - f.t / f.life), x = clamp(X(f.x), 60, cv.w - 60), y = clamp(Y(f.y) - f.t * 22, HUDH + 40, cv.h - lay.bot - 10);
        ctx.globalAlpha = a; ctx.font = (f.big ? '20px ' + DISP : '700 12px ' + FONT); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.strokeText(f.text, x, y); ctx.fillStyle = f.c; ctx.fillText(f.text, x, y);
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      if (flashT > 0) { ctx.fillStyle = 'rgba(255,245,200,' + (flashT / 0.8 * 0.55).toFixed(3) + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
      drawHud(now);
      drawBanner(now);
      drawCount();
    }

    /* ---------- hint line + buttons ---------- */
    let hintTxt = '', hintWarn = false, hintT = 0;
    function syncUi(rdt) {
      hintT -= rdt; if (hintT > 0) return; hintT = 0.12;
      const show = ctrlOn() && phase !== 'done';
      bar.style.display = show ? '' : 'none';
      if (!show || !W) return;
      const m = me(), s = W.sh[m], z = W.hz;
      let t = '', warn = false;
      if (phase === 'count') t = '곧 출발! 쓰레기를 눌러 목표를 정해요';
      else if (z && z.p === 0) { warn = true; t = z.k === 0 ? '⚠ 빨간 띠(파편)를 피해요! 고도를 바꿔요' : '☀ 플레어! 지구 뒤 어두운 그림자로'; }
      else if (s.st > 0) { warn = true; t = '⚡ 잠깐 고장! 곧 다시 움직여요'; }
      else if (s.c.length >= CAP && !(loc.tg && loc.tg[0] === 's')) { warn = true; t = '짐칸 가득! 「배달」을 눌러 정거장으로'; }
      else if (loc.m) t = loc.m > 0 ? '가속 중 → 반대편 궤도가 높아져요' : '감속 중 → 반대편 궤도가 낮아져요';
      else if (loc.tg) {
        const k = loc.tg[0];
        if (k === 'j') { const q = objOf(W, loc.tg); t = q ? '목표: ' + (q.k === 3 ? '큰 쓰레기(부딪히면 쪼개짐)' : TNAME[q.k] + ' 조각') + ' · 자동 비행 중' : ''; }
        else if (k === 's') t = '정거장으로 배달 가는 중 · 짐 ' + s.c.length + '개';
        else if (k === 'p') t = name(loc.tg[1]) + ' 배를 쫓는 중 · 세게 부딪히면 둘 다 짐을 흘려요';
        else t = Math.abs(hyp(s.x, s.y) - loc.tg[1]) < 4 ? '이 고도에서 궤도 유지 중' : (loc.tg[1] > hyp(s.x, s.y) ? '높은 궤도로 올라가는 중 (느려져요)' : '낮은 궤도로 내려가는 중 (빨라져요)');
      } else t = '쓰레기를 누르면 자동으로 날아가요 · 빈 곳 = 그 고도로';
      if (t !== hintTxt) { hintTxt = t; hint.textContent = t; }
      if (warn !== hintWarn) { hintWarn = warn; hint.classList.toggle('warn', warn); }
      if (s.c.length >= CAP && !fullTold && phase === 'play') { fullTold = true; api.sfx('chip'); }
      bJunk.classList.toggle('sel', !!(loc.tg && loc.tg[0] === 'j'));
      bHome.classList.toggle('sel', !!(loc.tg && loc.tg[0] === 's'));
      bHome.classList.toggle('pulse', s.c.length >= CAP && !(loc.tg && loc.tg[0] === 's'));
    }

    let lastDraw = 0;
    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt); syncUi(rdt); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
      lastDraw = now;
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (curKey() !== key) { startGame(); return; }
        if (prev && prev.ph !== next.ph) {
          if (next.ph === 'play' && phase === 'count') { phase = 'play'; tipOn = false; sfx('pop'); }
          if (next.ph === 'done') {
            phase = 'done'; layout();
            const m = me();
            if (m >= 0 && Array.isArray(next.res) && next.res.length) api.sfx(next.res[0][0] === m || next.np === 1 ? 'win' : 'lose');
          }
        }
      },
      destroy() {
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        bar.remove(); styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, lay, loc, phase, C }),
    };
  }

  L.register({
    id: 'junk', name: '우주 쓰레기 청소선', tag: '실시간 궤도 청소 경쟁', cat: '아케이드',
    blurb: '지구 궤도를 도는 청소선으로 우주 쓰레기를 그물에 모아 재활용 정거장에 배달! 앞으로 가속하면 궤도가 높아지고 느려져요. 1~4명(한 폰에 한 명).',
    tint: '#1d2f66',
    icon: '<circle cx="28" cy="28" r="9" fill="currentColor"/><ellipse cx="28" cy="28" rx="23" ry="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="4 3" transform="rotate(-25 28 28)"/><path d="M44 12l6 3-3 6-6-3z" fill="currentColor"/><path d="M50 12l3-3M50 18l4 1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><rect x="6" y="38" width="6" height="4" fill="currentColor" transform="rotate(20 9 40)"/><circle cx="17" cy="47" r="2" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'map', label: '궤도', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.nm }))), def: -1 },
      { id: 'time', label: '시간', choices: [{ v: 120, label: '2분' }, { v: 180, label: '3분' }, { v: 240, label: '4분' }], def: 180 },
      { id: 'hz', label: '우주 위험', choices: [{ v: 1, label: '켬' }, { v: 0, label: '끔' }], def: 1 },
    ],
    controls: [
      { id: 'retro', label: '감속 (뒤로 분사, 꾹)', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-', 'lt'] },
      { id: 'pro', label: '가속 (앞으로 분사, 꾹)', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+', 'rt'] },
      { id: 'junk', label: '좋은 쓰레기 자동 목표 (또 누르면 다음)', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'home', label: '정거장으로 배달', keys: ['KeyE', 'KeyK'], pad: ['x'] },
      { id: 'up', label: '목표 고도 올리기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '목표 고도 내리기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'ram', label: '가장 가까운 배 쫓기', keys: ['KeyR'], pad: ['y'] },
      { id: 'stop', label: '자동 조종 끄기', keys: ['KeyQ'], pad: ['b'] },
    ],
    quick: [
      '지구를 도는 청소선으로 우주 쓰레기를 그물에 담아(5칸) 재활용 정거장에 배달하면 점수!',
      '쓰레기를 누르면 자동 조종으로 날아가요. 짐이 차면 「배달」. ◀감속·가속▶으로 직접 조종도 돼요.',
      '시간(기본 3분)이 끝났을 때 점수가 가장 높으면 승리. 같은 종류 ×2, 세 종류 세트 +30!',
    ],
    rules: [
      { h: '목표', p: [
        '지구 둘레를 도는 청소선을 몰고 떠다니는 우주 쓰레기를 모아요.',
        '그물(짐칸)에는 5개까지 담겨요. 재활용 정거장(금색 점선 동그라미)에 닿으면 짐을 모두 내리고 점수를 받아요.',
        '정해진 시간이 끝났을 때 점수가 가장 높은 사람이 승리! 시간 안에 배달하지 못한 짐은 점수가 아니에요.',
      ] },
      { h: '궤도 원리 (아주 쉽게)', p: [
        '모든 것이 지구 둘레를 같은 방향으로 빙빙 돌아요. 가만히 있어도 계속 돌아요.',
        '지구에 가까운 낮은 궤도일수록 빨리 돌고, 높은 궤도일수록 천천히 돌아요.',
        '앞으로 가속하면 → 반대편 궤도가 높아지고 결국 느려져요. 뒤로 감속하면 → 궤도가 낮아지고 빨라져요.',
        '내 배 둘레의 점선이 지금 궤도예요. 「높은 곳」「낮은 곳」 표시가 궤도의 가장 높은·낮은 점이에요. 점선이 빨개지면 대기권에 닿으니 조심!',
      ] },
      { h: '조작', p: [
        '쓰레기·정거장·다른 배를 누르면 자동 조종이 그쪽으로 날아가요. 앞서 있는 목표는 낮게 내려가 따라잡고, 뒤에 있는 목표는 높이 올라가 기다려요.',
        '빈 우주를 누르면 그 높이(고도)로 가서 궤도를 유지해요. 누른 채 끌면 높이를 바꿔요.',
        '목표를 잡거나 배달을 마치면(또는 남이 먼저 가져가면) 그 자리 높이에서 동그란 궤도를 유지하며 기다려요.',
        '「쓰레기」 버튼: 지금 가기 좋은 쓰레기를 골라 줘요(또 누르면 다음 후보). 「배달」 버튼: 가장 빨리 갈 수 있는 정거장으로.',
        '◀ 감속 / 가속 ▶ 를 꾹 누르면 나아가는 방향 앞·뒤로 직접 분사해요. 점선 궤도가 바뀌는 걸 보며 궤도 원리를 느껴 보세요. 직접 분사하면 자동 조종은 꺼져요(경기장 밖으로 날아갈 만큼은 가속되지 않아요).',
        'PC: ←·A 감속, →·D 가속, 스페이스·J 쓰레기, E·K 배달, ↑↓·W·S 목표 고도, R 가까운 배 쫓기, Q 자동 조종 끄기. 마우스로 눌러 목표도 돼요. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '쓰레기와 점수', p: [
        '금속 조각(회색) 10점 · 태양광 패널(파랑) 20점 · 위성 부품(금색) 30점.',
        '큰 쓰레기(주황, 점선 동그라미): 그물로 건드리면 3조각으로 쪼개져요. 한 조각은 바로 내 그물로, 두 조각은 둥둥 날아가요(위성 부품 1개 포함).',
        '분류 보너스: 한 번에 같은 종류만 3개 이상 배달하면 ×2! 세 종류가 모두 있으면 +30점.',
      ] },
      { h: '부딪힘 · 우주 위험', p: [
        '다른 배와 세게 부딪히면 둘 다 짐의 절반을 흘려요(잠깐 고장, 그 뒤 2초 동안은 무적). 짐이 없을 땐 들이받아도 잃을 게 없어요!',
        '대기권(지구 바로 위 빨간 점선)에 닿으면 튕겨 나오고 짐 1개가 타 버려요.',
        '파편 소나기: 빨간 띠가 깜빡이면 3초 뒤 파편이 쏟아져요. 띠 안에 있으면 짐 절반을 흘려요 → 고도를 바꿔 피해요.',
        '태양 플레어: 해가 뜬 쪽에서 강한 빛이 와요. 지구 뒤 어두운 그림자 안에 있지 않으면 2초 동안 고장(분사·그물 꺼짐).',
        '설정 「우주 위험」을 끄면 위험이 나오지 않아요.',
      ] },
      { h: '예시', p: [
        '그물에 금속 3개 → 배달하면 30점 ×2 = 60점.',
        '금속 1 + 패널 1 + 위성 1 → 60점 + 세트 30 = 90점.',
        '위성 5개를 모아 배달하면 150 ×2 = 300점! 하지만 오래 모으다 부딪히면 절반을 흘려요.',
      ] },
      { h: '궤도(맵) 6곳', p: [
        '저궤도 청소: 기본 맵. 정거장 1곳.',
        '쌍둥이 정거장: 안쪽·바깥쪽에 정거장이 하나씩, 반대편에 있어요.',
        '쓰레기 고리: 바깥 고리에 쓰레기가 잔뜩, 정거장은 안쪽 — 오르내리기가 중요해요.',
        '달 그림자: 바깥을 도는 달이 가까운 배를 끌어당겨요. 달에 부딪히면 튕겨요.',
        '타원 정거장: 정거장이 길쭉한 궤도로 돌아서 높이가 계속 바뀌어요.',
        '태양 폭풍: 플레어가 자주 와요. 그림자 타이밍을 노려요.',
      ] },
      { h: '함께 하기 · 혼자 하기', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지 자리는 AI 청소선이에요. 친구와는 온라인·LAN 방에서 각자 폰으로(1~4명).',
        '혼자(1명)면 점수로 별을 받아요(★ 기준은 결과 화면에 나와요).',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 아무거나 줍고 늦게 반응, 어려움은 분류 보너스를 노리고 파편을 피하고 짐 많은 배를 들이받아요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { MAPS, init, newWorld, tickWorld, stepWorld, aiThink, steer, orbitOf, deliverPts, encodeWorld, applySnap, finish, result, starsOf, AIP, MU, RMAX, CAP },
  });
})();
