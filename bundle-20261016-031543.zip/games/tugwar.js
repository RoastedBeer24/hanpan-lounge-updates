/* 줄다리기 리듬전 — realtime rhythm tug-of-war (2–6, two teams).
   Everyone taps to a shared beat (BPM rises during a bout). On-beat taps pull hard (Perfect / Good), off-beat or
   extra taps barely pull and tire you. Team pull = sum of members. When the whole team keeps a streak going they
   do a big synchronized "영차!" pull. Drag the rope's centre marker past your line; best of 3 bouts.
   Host-authoritative rope (fixed step 1/120 s). Every phone plays the beat locally from the shared bout clock
   (guests estimate it from host snapshots) and judges its own taps; guests publish their judged taps
   [seq, beat, grade], the host applies them. One person per phone (the rest of a local game are AI).
   Teams are always equal: only even player counts (2·4·6) can start; an odd count ends at once with a notice. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure) ======================= */
  const H = 1 / 120;
  const B0 = 84, RATE = 1.0, BMAX = 150;           // BPM starts at 84 and rises 1 BPM/s up to 150
  const TC = (BMAX - B0) / RATE, PC = (B0 * TC + RATE * TC * TC / 2) / 60;
  const PW = 0.06, GW = 0.13;                       // Perfect / Good half-windows (s)
  const PULL = { P: 1, G: 0.6, M: 0.12, S: 0 };
  const FAT = { P: -0.02, G: -0.01, M: 0.07, S: 0.16 };
  const K = 1.6, DAMP = 2.2, YC = 2.4, LINE0 = 8, SHRINK_AT = 40, SHRINK = 0.22, LINE_MIN = 1.5;
  const COUNT = 3, END_T = 3.6;
  const TEAM = [{ n: '청팀', c: '#5bb3e6', d: '#1f4f72' }, { n: '홍팀', c: '#ee6a55', d: '#7a2a20' }];
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); }
  const bpmAt = (t) => Math.min(BMAX, B0 + RATE * Math.max(0, t));
  function phi(t) { if (t <= 0) return B0 * t / 60; if (t <= TC) return (B0 * t + RATE * t * t / 2) / 60; return PC + BMAX * (t - TC) / 60; }
  function beatT(p) { // inverse of phi
    if (p <= 0) return p * 60 / B0;
    if (p <= PC) return (-B0 + Math.sqrt(B0 * B0 + 2 * RATE * 60 * p)) / RATE;
    return TC + (p - PC) * 60 / BMAX;
  }
  /* grade a tap at bout time t for a seat whose last scored beat is lb */
  function judge(t, lb) {
    const k = Math.max(1, Math.round(phi(t))), off = t - beatT(k);
    if (Math.abs(off) > GW) return { k, c: 'M', off };
    if (lb === k) return { k, c: 'S', off };
    return { k, c: Math.abs(off) <= PW ? 'P' : 'G', off };
  }
  function newBout(n, tm) {
    const sz = [0, 0]; for (let i = 0; i < n; i++) sz[+tm[i]]++;
    const hs = []; for (let i = 0; i < n; i++) hs.push({ fat: 0, stk: 0, lb: 0, pl: 0, last: '', cnt: { P: 0, G: 0, M: 0, S: 0 } });
    return { n, tm, sz, t: 0, x: 0, v: 0, line: LINE0, hs, ty: [0, 0], yt: [-9, -9], ev: [], evId: 0, win: -1 };
  }
  function pushEv(R, type, a, hooks) { R.evId = (R.evId + 1) % 100000; R.ev.push([R.evId, type, a]); if (R.ev.length > 4) R.ev.shift(); if (hooks && hooks.ev) hooks.ev(type, a); }
  /* apply one graded tap (c) of seat i on beat k */
  function applyCat(R, i, c, k, hooks) {
    const h = R.hs[i]; if (!h || R.win >= 0 || !(c in PULL)) return false;
    const team = +R.tm[i], dir = team ? 1 : -1;
    if (c === 'P' || c === 'G') { if (k <= h.lb) return false; h.stk = h.lb === k - 1 ? h.stk + 1 : 1; h.lb = k; }
    else h.stk = 0;
    h.fat = clamp(h.fat + FAT[c], 0, 1);
    const p = PULL[c] * (1 - 0.6 * h.fat);
    R.v += dir * p * K; h.pl = Math.max(h.pl, PULL[c]); h.last = c; h.cnt[c]++;
    if (hooks && hooks.tap) hooks.tap(i, c);
    // whole-team streak → 영차!
    const mem = []; for (let j = 0; j < R.n; j++) if (+R.tm[j] === team) mem.push(R.hs[j].stk);
    const lvl = Math.floor(Math.min(...mem) / 8);
    if (lvl > R.ty[team]) { R.ty[team] = lvl; R.v += dir * YC * R.sz[team]; R.yt[team] = R.t; pushEv(R, 'yc', team, hooks); }
    else if (lvl < R.ty[team]) R.ty[team] = lvl;
    return true;
  }
  /* rem[i] = seat i taps on another phone (its taps arrive late, so its streak decays later) */
  function stepBout(R, dt, hooks, rem) {
    R.t += dt;
    const ph = phi(R.t);
    R.hs.forEach((h, i) => {
      h.fat = Math.max(0, h.fat - 0.18 * dt);
      h.pl = Math.max(0, h.pl - 3 * dt);
      if (h.stk && ph > h.lb + (rem && rem[i] ? 2.6 : 1.6)) h.stk = 0;
    });
    for (let t = 0; t < 2; t++) { const mem = R.hs.filter((_, j) => +R.tm[j] === t).map((h) => h.stk); if (Math.floor(Math.min(...mem) / 8) < R.ty[t]) R.ty[t] = Math.floor(Math.min(...mem) / 8); }
    R.v *= Math.exp(-DAMP * dt);
    R.x += R.v * dt;
    R.line = R.t > SHRINK_AT ? Math.max(LINE_MIN, LINE0 - (R.t - SHRINK_AT) * SHRINK) : LINE0;
    if (R.win < 0 && (R.x <= -R.line || R.x >= R.line)) { R.win = R.x < 0 ? 0 : 1; pushEv(R, 'win', R.win, hooks); }
  }
  /* AI: aims each beat with gaussian timing error by level */
  const AIC = { 1: { sd: 0.085, skip: 0.12, spam: 0.07 }, 2: { sd: 0.045, skip: 0.04, spam: 0.015 }, 3: { sd: 0.022, skip: 0.01, spam: 0 } };
  function aiStep(R, i, mem, lv, hooks) {
    const C = AIC[lv] || AIC[2], h = R.hs[i];
    if (R.win >= 0) return;
    if (mem.k == null) { mem.k = Math.max(1, Math.ceil(phi(R.t) + 0.3)); mem.nt = beatT(mem.k) + gauss() * C.sd; mem.sk = Math.random() < C.skip; }
    if (mem.sp != null && R.t >= mem.sp) { mem.sp = null; const j = judge(R.t, h.lb); applyCat(R, i, j.c, j.k, hooks); }
    if (R.t < mem.nt) return;
    if (!mem.sk) { const j = judge(R.t, h.lb); applyCat(R, i, j.c, j.k, hooks); if (Math.random() < C.spam) mem.sp = R.t + 0.06 + Math.random() * 0.06; }
    mem.k++; mem.nt = beatT(mem.k) + gauss() * C.sd; mem.sk = Math.random() < C.skip * (h.fat > 0.4 ? 2 : 1);
  }

  /* ======================= coarse state ======================= */
  function teamsFor(n, mode) {
    let s = '';
    for (let i = 0; i < n; i++) s += mode === 'half' ? (i < Math.ceil(n / 2) ? '0' : '1') : String(i % 2);
    return s;
  }
  const ODD_MSG = '줄다리기는 짝수 인원(2·4·6명)만 할 수 있어요. 두 팀 인원이 항상 같아야 해요. 인원을 한 명 늘리거나 줄여서 다시 시작해 주세요.';
  function init(players, opts) {
    const o = opts || {}, n = players.length, mode = ['alt', 'half', 'pick'].includes(o.team) ? o.team : 'alt';
    const odd = n % 2 === 1 || n < 2;
    const s = { rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), ai: players.map((p) => (p && p.ai ? 1 : 0)),
      mode, tm: mode === 'pick' && !odd ? players.map((p) => (p && p.ai ? '?' : '-')).join('') : teamsFor(n, mode),
      ph: odd ? 'odd' : mode === 'pick' ? 'pick' : 'count', bo: [0, 0], rd: 1, fin: -1, pat: U.rand(3), res: null };
    if (s.ph === 'pick' && !s.tm.includes('-')) { s.tm = fillAI(s.tm); s.ph = 'count'; }
    return s;
  }
  const cap = (n) => n / 2; // each team holds exactly half the players
  function fillAI(tm) { // AI seats join the smaller team (so both teams end up the same size)
    const a = tm.split('');
    const cnt = [a.filter((x) => x === '0').length, a.filter((x) => x === '1').length];
    for (let i = 0; i < a.length; i++) if (a[i] === '?') { const t = cnt[0] <= cnt[1] ? 0 : 1; a[i] = String(t); cnt[t]++; }
    return a.join('');
  }
  function actor(s) {
    if (!s || s.ph !== 'pick') return null;
    const a = []; for (let i = 0; i < s.n; i++) if (s.tm[i] === '-') a.push(i);
    return a.length ? a : null;
  }
  function apply(s, seat, a) {
    if (!a || a.t !== 'team' || s.ph !== 'pick' || s.tm[seat] !== '-' || (a.side !== 0 && a.side !== 1)) throw new Error('bad action');
    if (s.tm.split('').filter((x) => x === String(a.side)).length >= cap(s.n)) throw new Error('team full');
    let tm = s.tm.slice(0, seat) + a.side + s.tm.slice(seat + 1);
    if (!tm.includes('-')) {
      tm = fillAI(tm);
      if (tm.split('').filter((x) => x === '0').length !== cap(s.n)) throw new Error('unequal teams');
      s.ph = 'count';
    }
    s.tm = tm;
    return s;
  }
  function endBout(s, w) {
    const n = Object.assign({}, s, { bo: s.bo.slice(), ph: 'end', fin: w });
    n.bo[w]++;
    return n;
  }
  function nextBout(s) {
    if (s.bo[0] >= 2 || s.bo[1] >= 2) return Object.assign({}, s, { ph: 'done', res: s.bo[0] > s.bo[1] ? 0 : 1 });
    return Object.assign({}, s, { ph: 'count', rd: s.rd + 1, fin: -1, pat: (s.pat + 1) % 3 });
  }
  function result(s) {
    if (s && s.ph === 'odd') return { winners: [], title: '짝수 인원만 할 수 있어요', text: ODD_MSG };
    if (!s || s.ph !== 'done' || (s.res !== 0 && s.res !== 1)) return null;
    const w = s.res, winners = []; for (let i = 0; i < s.n; i++) if (+s.tm[i] === w) winners.push(i);
    const names = (t) => { const a = []; for (let i = 0; i < s.n; i++) if (+s.tm[i] === t) a.push(s.nm[i] || (i + 1) + '번'); return a.join(', '); };
    return { winners, title: TEAM[w].n + ' 승리!', text: TEAM[0].n + ' ' + s.bo[0] + ' : ' + s.bo[1] + ' ' + TEAM[1].n + '\n' + TEAM[0].n + ': ' + names(0) + '\n' + TEAM[1].n + ': ' + names(1) };
  }

  /* ======================= drums (WebAudio) ======================= */
  const PATS = [ // per half-beat over 4 beats: k kick, s snare, h hat, c clap
    ['k', 'h', 's', 'h', 'k', 'k', 's', 'h'],
    ['k', 'h', 'h', 'k', 's', 'h', 'k', 'h'],
    ['k', 'h', 's', 'k', 'k', 'h', 's', 'c'],
  ];
  const Drum = {
    ac: null,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    noiseBuf: null,
    nb(ac) { if (!this.noiseBuf) { const n = ac.sampleRate * 0.3, b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this.noiseBuf = b; } return this.noiseBuf; },
    hit(type, at, acc) {
      const ac = this.ac; if (!ac) return;
      const t = Math.max(ac.currentTime, at);
      if (type === 'k') {
        const o = ac.createOscillator(), g = ac.createGain(); o.frequency.setValueAtTime(130, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.16);
        g.gain.setValueAtTime(acc ? 0.85 : 0.6, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22); o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 0.24);
      } else {
        const src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain(); src.buffer = this.nb(ac);
        f.type = type === 'h' ? 'highpass' : 'bandpass'; f.frequency.setValueAtTime(type === 'h' ? 7000 : type === 'c' ? 1500 : 1900, t);
        const d = type === 'h' ? 0.035 : 0.13, v = type === 'h' ? 0.1 : type === 'c' ? 0.3 : 0.32;
        g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d); src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + d + 0.02);
      }
    },
    close() { try { this.ac && this.ac.close(); } catch (e) {} this.ac = null; this.noiseBuf = null; },
  };

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const GR = { P: ['퍼펙트!', '#ffe27a'], G: ['좋아요', '#8fe3a8'], M: ['박자 밖', '#ab9fb8'], S: ['너무 많이!', '#ee6a55'] };
  const CSS = `
.tw-pick{position:absolute;left:0;right:0;bottom:0;z-index:8;padding:14px 12px calc(14px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.97) 14%);display:flex;flex-direction:column;gap:10px}
.tw-pick h3{margin:0;font-family:var(--f-display,sans-serif);font-weight:400;font-size:22px;color:#f2e9d8;display:flex;align-items:center;gap:8px}
.tw-pick .sub{font-size:13px;color:#ab9fb8;line-height:1.4}
.tw-pick .two{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.tw-pick .two button{min-height:76px;border-radius:14px;border:2px solid rgba(255,255,255,.15);color:#fff;font:22px var(--f-display,sans-serif);touch-action:manipulation}
.tw-pick .two button small{display:block;font:600 12px var(--f-body,sans-serif);opacity:.85;margin-top:2px}
.tw-pick .two button:active{transform:scale(.97)}
.tw-tip{position:absolute;left:50%;transform:translate(-50%,6px);z-index:7;width:max-content;max-width:calc(100% - 28px);box-sizing:border-box;padding:10px 14px;border-radius:14px;background:rgba(23,19,31,.97);border:1px solid rgba(227,174,69,.55);box-shadow:0 6px 20px rgba(0,0,0,.35);color:#f2e9d8;font:600 13px/1.45 "IBM Plex Sans KR",system-ui,sans-serif;text-align:center;word-break:keep-all;pointer-events:none;opacity:0;transition:opacity .4s,transform .4s}
.tw-tip.on{opacity:1;transform:translate(-50%,0)}
.tw-tip b{display:block;color:#e3ae45;font-weight:800;margin-bottom:2px}
`;
  /* first-play tip card: shown once per device (localStorage), fades by itself and never blocks taps */
  function firstTip(root, id, title, lines, top, ms) {
    try { if (localStorage.getItem('lounge.tip.' + id)) return null; localStorage.setItem('lounge.tip.' + id, '1'); } catch (e) { /* storage blocked: just show it */ }
    const el = L.h('div', { class: 'tw-tip', role: 'status', style: { top: top + 'px' } },
      L.h('b', { text: title }), lines.map((t) => L.h('div', { text: t })));
    root.appendChild(el);
    requestAnimationFrame(() => el.classList.add('on'));
    let gone = false;
    const hide = () => { if (gone) return; gone = true; el.classList.remove('on'); setTimeout(() => el.remove(), 450); };
    const tm = setTimeout(hide, ms || 6000);
    return { hide, remove() { clearTimeout(tm); gone = true; el.remove(); } };
  }
  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1); // one person per phone
    const isMine = (s) => mine().includes(s);
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; return !!p.ai || !!p.local; };
    let st = null, key = null, R = null, phase = 'wait', cd = 0, endT = 0, acc = 0, pick = null, pickSig = '';
    let zones = [], field = { x: 0, y: 0, w: 1, h: 1 }, aiMem = [], fb = {}, banner = null, shownEv = -1, flashT = [0, 0];
    let tip = null;
    let pubT = 0, hsQ = 0, lastQ = -1, snaps = [], clockBase = null, tapSeq = 0, myTaps = [], lastEvG = 0;
    const remSeen = {};
    let drumStep = 0, lastBeatK = 0;
    const fbOf = (s) => fb[s] || (fb[s] = { txt: '', col: '#fff', t: 0, pulse: 0 });

    function curKey() { return st ? st.rid + '.' + st.rd : null; }
    function startBout() {
      R = newBout(st.n, st.tm);
      aiMem = R.hs.map(() => ({}));
      phase = st.ph === 'run' ? 'run' : 'count'; cd = COUNT; endT = END_T; acc = 0;
      snaps = []; lastQ = -1; clockBase = null; myTaps = []; banner = null; shownEv = -1; drumStep = 0; lastBeatK = 0;
      for (const k in fb) { fb[k].txt = ''; fb[k].t = 0; }
      layout();
      // first bout on this device: say how to play during the countdown (once per device)
      if (!tip && st.rd === 1 && phase === 'count' && zones.length) tip = firstTip(root, 'tugwar', '처음이라면 이렇게!', ['드럼 박자에 맞춰 아래 내 구역을 한 번씩 톡!', '고리가 가운데 원에 겹칠 때가 박자 · 연타는 금물'], Math.round(field.h + 34), 6500);
    }

    /* ----- layout: field on top, tap zones below ----- */
    function layout() {
      const W = cv.w, Hh = cv.h, m = st && st.ph === 'odd' ? [] : mine().filter((s) => st && st.tm[s] !== '-');
      zones = [];
      if (!m.length) { field = { x: 0, y: 0, w: W, h: Hh }; return; }
      const fh = Math.round(Math.min(Hh * 0.44, 330));
      field = { x: 0, y: 0, w: W, h: fh };
      const zy = fh, zh = Hh - fh;
      zones.push({ seat: m[0], x: 4, y: zy + 4, w: W - 8, h: zh - 8 });
    }
    cv.onresize = () => { if (st) layout(); };

    /* ----- bout clock on this phone ----- */
    function boutT() { return R ? R.t : 0; }
    function guestClock(now) { // estimate the host's bout time from the fastest snapshot
      if (!snaps.length || clockBase == null) return R ? R.t : 0;
      const latest = snaps[snaps.length - 1];
      const est = clockBase + now / 1000 * SPD();
      return Math.min(est, latest.t + (now - latest.at) / 1000 * SPD() + 0.5);
    }

    /* ----- input ----- */
    function tapSeat(seat) {
      if (!st || !R || !isMine(seat)) return;
      const f = fbOf(seat); f.pulse = 1;
      Drum.ctx();
      if (st.ph !== 'run' || phase !== 'run' || R.win >= 0) { if (st.ph === 'count') { f.txt = '아직이에요!'; f.col = '#ab9fb8'; f.t = 0.6; } return; }
      const h = R.hs[seat], j = judge(boutT(), h.lb);
      if (host()) applyCat(R, seat, j.c, j.k, hooks);
      else { // guest: judge locally, remember for streak/spam display and send
        if (j.c === 'P' || j.c === 'G') { h.lb = j.k; h.stk++; } else h.stk = 0;
        tapSeq = (tapSeq + 1) % 100000; myTaps.push([tapSeq, j.k, j.c]); if (myTaps.length > 8) myTaps.shift();
        hooks.tap(seat, j.c); pubT = 0;
      }
    }
    function onDown(e) {
      e.preventDefault();
      const p = cv.local(e);
      const z = zones.find((q) => p.x >= q.x && p.x <= q.x + q.w && p.y >= q.y && p.y <= q.y + q.h);
      if (z) tapSeat(z.seat);
    }
    // keyboard / gamepad (api.input, rebindable in 「⌨ 조작 설정」): one tap per press, holding does not repeat
    const offIn = api.input ? api.input.on((type, id) => { if (type !== 'down' || id !== 'pull') return; const m = mine(); if (!m.length || pick) return; tapSeat(m[0]); }) : () => {};
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('contextmenu', noCtx);

    const hooks = {
      tap(i, c) {
        if (!isMine(i)) return;
        const f = fbOf(i); f.txt = GR[c][0]; f.col = GR[c][1]; f.t = 0.5;
        if (c === 'P') api.buzz(12); else if (c === 'S') api.buzz(40); else if (c === 'G') api.buzz(6);
      },
      ev(type, a) {
        if (type === 'yc') { flashT[a] = 1; api.sfx('whoosh'); if (mine().some((s) => +st.tm[s] === a)) api.buzz([30, 30, 60]); }
        if (type === 'win') { api.sfx('win'); api.buzz(60); }
      },
    };

    /* ----- team picker ----- */
    function pickerSeat() { if (!st) return -1; const m = mine().filter((s) => st.tm[s] === '-'); return m.length ? m[0] : -1; }
    function syncPicker() {
      if (!st || st.ph !== 'pick') { if (pick) { pick.remove(); pick = null; } pickSig = ''; return; }
      const seat = pickerSeat(), sig = st.tm + '|' + seat;
      if (pick && sig === pickSig) return;
      pickSig = sig; if (pick) pick.remove();
      const who = (t) => { const a = []; for (let i = 0; i < st.n; i++) if (st.tm[i] === String(t)) a.push(st.nm[i]); return a.length ? a.join(', ') : '아직 없음'; };
      const waiting = []; for (let i = 0; i < st.n; i++) if (st.tm[i] === '-' && !isMine(i)) waiting.push(st.nm[i]);
      const full = (t) => st.tm.split('').filter((x) => x === String(t)).length >= cap(st.n);
      const b = (t) => L.h('button', { style: { background: TEAM[t].d, borderColor: TEAM[t].c, opacity: full(t) ? 0.45 : 1 }, disabled: seat < 0 || full(t), onclick() {
        if (seat < 0) return;
        if (full(t)) { api.toast('그 팀은 이미 꽉 찼어요'); return; }
        api.sfx('click'); api.buzz(12);
        api.actAs(seat, { t: 'team', side: t });
      } }, TEAM[t].n + (t ? ' (오른쪽)' : ' (왼쪽)'), L.h('small', { text: (full(t) ? '꽉 참 · ' : '') + who(t) }));
      pick = L.h('div', { class: 'tw-pick' },
        seat >= 0 ? L.h('h3', null, L.h('span', { class: 'dot', style: { '--c': api.players[seat].color, width: '14px', height: '14px' } }), st.nm[seat] + ' · 팀 고르기') : L.h('h3', { text: '팀 고르기' }),
        L.h('div', { class: 'sub', text: seat >= 0 ? '어느 쪽에서 줄을 당길까요? 한 팀은 ' + cap(st.n) + '명까지 — 두 팀 인원은 항상 같아요. AI는 남은 자리를 채워요.' : '다른 사람이 고르는 중… (' + waiting.join(', ') + ')' }),
        L.h('div', { class: 'two' }, b(0), b(1)));
      pick.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(pick);
    }

    /* ----- host flow ----- */
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'count' && phase === 'run') { api.setState(Object.assign({}, st, { ph: 'run' })); return; }
      if (st.ph === 'run' && R && R.win >= 0) { api.setState(endBout(st, R.win)); return; }
      if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextBout(st)); } }
    }
    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !R) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem) return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < R.n) || simHere(s) || !o || o.k !== key || !Array.isArray(o.taps)) continue;
        const seen = remSeen[s] || (remSeen[s] = { q: -1 });
        for (const tp of o.taps) {
          if (!Array.isArray(tp) || !(tp[0] > seen.q)) continue;
          seen.q = tp[0];
          if (st.ph === 'run' && typeof tp[2] === 'string') applyCat(R, s, tp[2], tp[1] | 0, hooks);
        }
      }
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !R) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || hs.k !== key || hs.q === lastQ) return;
      lastQ = hs.q;
      snaps.push({ at: now, t: +hs.t || 0, x: +hs.x || 0 }); if (snaps.length > 6) snaps.shift();
      const base = (+hs.t || 0) - now / 1000 * SPD();
      if (clockBase == null || base > clockBase || base < clockBase - 0.6) clockBase = base; // fastest arrival wins; resync on big drift
      R.line = +hs.ln || R.line; R.v = +hs.v || 0;
      if (Array.isArray(hs.f)) hs.f.forEach((v, i) => { if (R.hs[i]) R.hs[i].fat = (v | 0) / 100; });
      if (Array.isArray(hs.s)) hs.s.forEach((v, i) => { if (R.hs[i] && !isMine(i)) R.hs[i].stk = v | 0; });
      if (Array.isArray(hs.p)) hs.p.forEach((v, i) => { if (R.hs[i] && !isMine(i)) R.hs[i].pl = Math.max(R.hs[i].pl, (v | 0) / 10); });
      if (Array.isArray(hs.ev)) for (const e of hs.ev) if (Array.isArray(e) && e[0] > lastEvG) { lastEvG = e[0]; R.ev.push(e); if (R.ev.length > 4) R.ev.shift(); hooks.ev(e[1], e[2]); }
    }
    function interpX(now) {
      if (snaps.length < 2) return snaps.length ? snaps[0].x : 0;
      const rt = now - 100;
      let A = snaps[snaps.length - 2], B = snaps[snaps.length - 1];
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      const k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.3);
      return A.x + (B.x - A.x) * k;
    }
    function publish(rdt) {
      if (!api.online || !R) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 1 / 16;
          hsQ = (hsQ + 1) % 100000;
          api.net.hostSend({ k: key, q: hsQ, t: Math.round(R.t * 1000) / 1000, x: Math.round(R.x * 100) / 100, v: Math.round(R.v * 100) / 100, ln: Math.round(R.line * 100) / 100,
            f: R.hs.map((h) => Math.round(h.fat * 100)), s: R.hs.map((h) => h.stk), p: R.hs.map((h) => Math.round(h.pl * 10)), ev: R.ev.slice(-3) });
        } else {
          if (pubT > 0 && pubT > -0.5) return;
          pubT = 1;
          api.net.publish({ k: key, taps: myTaps.slice() });
        }
      } catch (e) {}
    }

    /* ----- drums: schedule half-beats slightly ahead on this phone's bout clock ----- */
    function drums() {
      if (!R || phase !== 'run' || st.ph !== 'run' || R.win >= 0) return;
      const ac = Drum.ctx(); if (!ac) return;
      const t = boutT(), pat = PATS[st.pat % PATS.length];
      if (drumStep === 0) drumStep = Math.max(2, Math.ceil(phi(t) * 2));
      while (beatT(drumStep / 2) - t < 0.12) {
        const bt = beatT(drumStep / 2), dtA = (bt - t) / SPD();
        if (dtA > -0.05) {
          const step = drumStep % 8, k = drumStep / 2;
          Drum.hit(pat[step], ac.currentTime + dtA, Number.isInteger(k) && k % 8 === 0);
          if (pat[step] !== 'h' && step % 2 === 1) Drum.hit('h', ac.currentTime + dtA);
          if (step % 2 === 0 && pat[step] !== 'h') Drum.hit('h', ac.currentTime + dtA);
        }
        drumStep++;
      }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      const dt = rdt * SPD();
      syncPicker();
      if (R && phase === 'count' && (st.ph === 'count' || st.ph === 'run')) {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0) api.sfx('tick');
        if (cd <= 0 && (host() || st.ph === 'run')) { phase = 'run'; api.sfx('pop'); api.buzz(25); }
      }
      if (host()) {
        pollHost();
        if (R && phase === 'run' && st.ph === 'run' && R.win < 0) {
          acc += Math.min(dt, 0.5);
          const rem = R.hs.map((_, i) => !simHere(i));
          let n = 0;
          while (acc >= H && n < 480 && R.win < 0) {
            R.hs.forEach((h, i) => { const p = api.players[i]; if (p && simHere(i) && (p.ai || (L.debug && L.debug.autoplay))) aiStep(R, i, aiMem[i], p.ai ? (p.lv || 2) : 3, hooks); });
            stepBout(R, H, hooks, rem); acc -= H; n++;
          }
        }
        hostFlow(dt);
      } else if (R) {
        pollGuest(now);
        if (phase === 'run' && st.ph === 'run') { R.t = Math.max(R.t, guestClock(now)); }
        R.x = interpX(now);
        R.hs.forEach((h) => { h.pl = Math.max(0, h.pl - 3 * dt); });
        const ph = phi(R.t); for (const s of mine()) { const h = R.hs[s]; if (h && h.stk && ph > h.lb + 1.6) h.stk = 0; }
      }
      drums();
      for (const k in fb) { const f = fb[k]; if (f.t > 0) f.t -= rdt; if (f.pulse > 0) f.pulse = Math.max(0, f.pulse - rdt * 5); }
      flashT = flashT.map((v) => Math.max(0, v - rdt * 1.2));
      if (R && R.ev.length) { const e = R.ev[R.ev.length - 1]; if (e[0] !== shownEv) { shownEv = e[0]; if (e[1] === 'yc') banner = { text: '영차!', col: TEAM[e[2]].c, age: 0, side: e[2] }; } }
      if (banner) { banner.age += rdt; if (banner.age > 1.4) banner = null; }
      publish(rdt);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, al) { ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,8,16,.85)'; ctx.strokeText(t, x, y); ctx.fillStyle = col; ctx.fillText(t, x, y); }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else ctx.rect(x, y, w, h); }
    function draw(now) {
      cv.clear();
      const W = cv.w, Hh = cv.h;
      ctx.fillStyle = '#120e19'; ctx.fillRect(0, 0, W, Hh);
      if (!st || !R) return;
      drawField(now);
      for (const z of zones) drawZone(z, now);
    }
    function drawField(now) {
      const F = field, W = F.w, cx = F.x + W / 2;
      // sky / ground
      const g = ctx.createLinearGradient(0, F.y, 0, F.y + F.h);
      g.addColorStop(0, '#2c2139'); g.addColorStop(0.45, '#3b2b3c'); g.addColorStop(0.46, '#6b5236'); g.addColorStop(1, '#4a3826');
      ctx.fillStyle = g; ctx.fillRect(F.x, F.y, W, F.h);
      ctx.fillStyle = 'rgba(0,0,0,.08)'; for (let k = 0; k < 40; k++) { const x = (k * 97) % W, y = F.y + F.h * 0.5 + ((k * 53) % Math.max(1, F.h * 0.48)); ctx.fillRect(x, y, 3, 2); }
      const ground = F.y + F.h * 0.72, sc = (W * 0.42) / LINE0; // world unit → px
      const xPx = (u) => cx + u * sc;
      // win lines
      for (const s of [-1, 1]) {
        const lx = xPx(s * R.line), team = s < 0 ? 0 : 1;
        ctx.strokeStyle = TEAM[team].c; ctx.lineWidth = 4; ctx.setLineDash([8, 6]);
        ctx.beginPath(); ctx.moveTo(lx, F.y + F.h * 0.48); ctx.lineTo(lx, F.y + F.h - 6); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = TEAM[team].c; ctx.beginPath(); ctx.moveTo(lx, F.y + F.h * 0.48); ctx.lineTo(lx + s * -16, F.y + F.h * 0.48 + 7); ctx.lineTo(lx, F.y + F.h * 0.48 + 14); ctx.fill();
      }
      ctx.strokeStyle = 'rgba(242,233,216,.4)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx, F.y + F.h * 0.5); ctx.lineTo(cx, F.y + F.h - 6); ctx.stroke();
      // rope
      const rx = R.x, ry = ground - 16;
      ctx.strokeStyle = '#c9a66b'; ctx.lineWidth = 6; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(4, ry + 2); ctx.quadraticCurveTo(W / 2, ry + 6 - Math.min(5, Math.abs(R.v) * 2), W - 4, ry + 2); ctx.stroke();
      ctx.strokeStyle = 'rgba(90,60,30,.6)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 5]); ctx.lineDashOffset = -rx * sc;
      ctx.beginPath(); ctx.moveTo(4, ry + 2); ctx.quadraticCurveTo(W / 2, ry + 6, W - 4, ry + 2); ctx.stroke(); ctx.setLineDash([]);
      // centre marker ribbon
      const mx = xPx(rx);
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.moveTo(mx, ry); ctx.lineTo(mx - 9, ry + 26); ctx.lineTo(mx + 9, ry + 26); ctx.fill();
      ctx.fillStyle = '#fff3c4'; ctx.fillRect(mx - 2, ry - 4, 4, 10);
      // teams
      for (let t = 0; t < 2; t++) {
        const mem = []; for (let i = 0; i < R.n; i++) if (+st.tm[i] === t) mem.push(i);
        const dir = t ? 1 : -1;
        mem.forEach((i, k) => {
          const h = R.hs[i], base = mx + dir * (W * 0.12 + k * Math.min(40, W * 0.3 / Math.max(1, mem.length)));
          const lean = 0.35 + h.pl * 0.35 + (flashT[t] > 0 ? 0.3 : 0);
          person(base, ground + 6, dir, lean, api.players[i] ? api.players[i].color : '#ccc', TEAM[t].c, h.fat, now, i);
        });
      }
      // HUD: score, BPM, bout
      txt(TEAM[0].n + ' ' + st.bo[0], 12, F.y + 20, TEAM[0].c, '22px ' + DISP, 'left');
      txt(st.bo[1] + ' ' + TEAM[1].n, W - 12, F.y + 20, TEAM[1].c, '22px ' + DISP, 'right');
      txt(st.rd + '판 · 3판 2선승', cx, F.y + 16, '#ab9fb8', '600 12px ' + FONT);
      if (phase === 'run' && st.ph === 'run') txt('♩ ' + Math.round(bpmAt(R.t)) + ' BPM', cx, F.y + 36, '#f2e9d8', '700 14px ' + MONO);
      // beat lane: dots converge to the centre on each beat
      const ly = F.y + F.h * 0.38, ph = phi(R.t);
      ctx.fillStyle = 'rgba(0,0,0,.3)'; rr(16, ly - 12, W - 32, 24, 12); ctx.fill();
      const on = st.ph === 'run' && phase === 'run';
      if (on) {
        for (let k = Math.ceil(ph - 0.05); k < ph + 3; k++) {
          if (k < 1) continue;
          const d = k - ph, off = d * (W * 0.42) / 3, big = k % 8 === 0;
          ctx.fillStyle = big ? '#e3ae45' : '#f2e9d8'; ctx.globalAlpha = clamp(1.2 - d / 3, 0.2, 1);
          for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(cx + s * off, ly, big ? 7 : 5, 0, 7); ctx.fill(); }
          ctx.globalAlpha = 1;
        }
        const pulse = Math.max(0, 1 - (ph - Math.floor(ph)) * 4);
        ctx.strokeStyle = 'rgba(255,226,122,' + (0.4 + pulse * 0.6) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, ly, 10 + pulse * 4, 0, 7); ctx.stroke();
      } else { ctx.strokeStyle = 'rgba(255,226,122,.4)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, ly, 10, 0, 7); ctx.stroke(); }
      // countdown / bout end / banner
      if (phase === 'count' && st.ph !== 'pick') txt(String(Math.max(1, Math.ceil(cd))), cx, F.y + Math.max(58, F.h * 0.25), '#f2e9d8', '44px ' + DISP);
      if (st.ph === 'pick') txt('팀을 고르는 중', cx, F.y + F.h * 0.6, '#f2e9d8', '24px ' + DISP);
      if (st.ph === 'odd') { txt('짝수 인원만 할 수 있어요', cx, F.y + F.h * 0.3, '#e3ae45', '24px ' + DISP); txt('줄다리기는 2·4·6명으로 해요', cx, F.y + F.h * 0.3 + 30, '#f2e9d8', '600 14px ' + FONT); }
      if (st.ph === 'end' || st.ph === 'done') { const w = st.fin >= 0 ? st.fin : st.res; if (w === 0 || w === 1) txt(TEAM[w].n + ' 승리!', cx, F.y + Math.max(58, F.h * 0.25), TEAM[w].c, '40px ' + DISP); } // above the pullers, not over them
      if (banner) { const a = Math.min(1, (1.4 - banner.age) * 3); ctx.globalAlpha = a; txt(banner.text, banner.side ? cx + W * 0.22 : cx - W * 0.22, F.y + F.h * 0.6 - banner.age * 20, banner.col, Math.round(44 + banner.age * 10) + 'px ' + DISP); ctx.globalAlpha = 1; }
      if (!zones.length && st.ph !== 'pick' && st.ph !== 'odd') txt('AI끼리 줄다리기 중', cx, F.y + F.h - 18, '#ab9fb8', '600 13px ' + FONT);
    }
    function person(x, gy, dir, lean, col, band, fat, now, i) {
      // dir: −1 pulls left (faces left), +1 pulls right
      const s = Math.min(1, field.h / 300) * 1.1;
      ctx.save(); ctx.translate(x, gy); ctx.scale(s, s);
      const ang = dir * lean; // lean back away from the rope centre
      ctx.strokeStyle = '#2a2018'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      // legs
      ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(dir * -6, 0); ctx.lineTo(0, -18); ctx.lineTo(dir * 8, 0); ctx.stroke();
      ctx.save(); ctx.translate(0, -18); ctx.rotate(ang);
      ctx.fillStyle = band; rr(-6, -26, 12, 26, 5); ctx.fill();
      // arms to the rope (towards the centre: −dir)
      ctx.strokeStyle = '#e7c9a0'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(0, -20); ctx.lineTo(-dir * 16, -8); ctx.stroke();
      // head + headband
      ctx.fillStyle = '#e7c9a0'; ctx.beginPath(); ctx.arc(0, -34, 8, 0, 7); ctx.fill();
      ctx.fillStyle = col; ctx.fillRect(-8.5, -38, 17, 4);
      if (fat > 0.45) { ctx.fillStyle = 'rgba(160,210,255,.9)'; ctx.beginPath(); ctx.arc(dir * 9, -40 + Math.sin(now / 150 + i) * 2, 2.2, 0, 7); ctx.fill(); }
      ctx.restore(); ctx.restore();
    }
    function drawZone(z, now) {
      const s = z.seat, t = +st.tm[s], T = TEAM[t], h = R.hs[s], f = fbOf(s), P = api.players[s] || {};
      ctx.save();
      const g = ctx.createLinearGradient(0, z.y, 0, z.y + z.h); g.addColorStop(0, T.d); g.addColorStop(1, '#1a1424');
      ctx.fillStyle = g; rr(z.x, z.y, z.w, z.h, 16); ctx.fill();
      ctx.strokeStyle = f.pulse > 0 ? T.c : 'rgba(255,255,255,.12)'; ctx.lineWidth = 2 + f.pulse * 2; ctx.stroke();
      const cx = z.x + z.w / 2, cy = z.y + z.h * 0.55, Rr = Math.max(18, Math.min(z.w, z.h) * 0.2);
      // name + team + streak
      ctx.fillStyle = P.color || '#ccc'; ctx.beginPath(); ctx.arc(z.x + 16, z.y + 18, 6, 0, 7); ctx.fill();
      ctx.font = '700 14px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
      let label = (st.nm[s] || '') + ' · ' + T.n; const maxW = z.w - 40 - (h.stk >= 2 ? 64 : 0);
      while (label.length > 2 && ctx.measureText(label).width > maxW) label = label.slice(0, -2) + '…';
      ctx.fillText(label, z.x + 28, z.y + 18);
      if (h.stk >= 2) txt(h.stk + ' 연속', z.x + z.w - 12, z.y + 18, h.stk >= 8 ? '#ffe27a' : '#f2e9d8', '700 14px ' + MONO, 'right');
      // fatigue bar
      const bw = Math.min(z.w - 64, 160), bx = cx - bw / 2 + 8, by = z.y + z.h - 18;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(bx, by - 4, bw, 8, 4); ctx.fill();
      ctx.fillStyle = h.fat > 0.5 ? '#ee6a55' : '#8fe3a8'; rr(bx, by - 4, bw * (1 - h.fat), 8, 4); ctx.fill();
      { ctx.font = '600 11px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = '#ab9fb8'; ctx.fillText('힘', bx - 14, by); }
      // target ring + approaching ring
      const run = st.ph === 'run' && phase === 'run' && R.win < 0;
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(242,233,216,.85)'; ctx.beginPath(); ctx.arc(cx, cy, Rr, 0, 7); ctx.stroke();
      ctx.fillStyle = 'rgba(242,233,216,' + (0.08 + f.pulse * 0.25) + ')'; ctx.beginPath(); ctx.arc(cx, cy, Rr, 0, 7); ctx.fill();
      if (run) {
        const ph = phi(R.t), nk = Math.max(1, Math.ceil(ph - 0.15)), d = nk - ph;
        if (d < 1) { const rr2 = Rr * (1 + Math.max(0, d) * 1.6); ctx.strokeStyle = nk % 8 === 0 ? '#e3ae45' : T.c; ctx.lineWidth = 5; ctx.globalAlpha = clamp(1.2 - d, 0.3, 1); ctx.beginPath(); ctx.arc(cx, cy, rr2, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
        const near = Math.abs(ph - Math.round(ph)) * 60 / bpmAt(R.t);
        if (near < 0.06) { ctx.fillStyle = 'rgba(255,226,122,.25)'; ctx.beginPath(); ctx.arc(cx, cy, Rr, 0, 7); ctx.fill(); }
      }
      if (flashT[t] > 0) { ctx.globalAlpha = flashT[t]; ctx.fillStyle = T.c; rr(z.x, z.y, z.w, z.h, 16); ctx.fill(); ctx.globalAlpha = 1; }
      if (f.t > 0 && f.txt) { ctx.globalAlpha = Math.min(1, f.t * 4); txt(f.txt, cx, cy - Rr - 22, f.col, '700 ' + (z.w < 200 ? 15 : 18) + 'px ' + FONT); ctx.globalAlpha = 1; }
      txt(run ? '탭!' : phase === 'count' && st.ph !== 'pick' ? String(Math.max(1, Math.ceil(cd))) : '', cx, cy + 1, '#f2e9d8', Math.round(Rr * 0.7) + 'px ' + DISP);
      if (run && R.t < 6 && z.h > 160) { ctx.globalAlpha = Math.min(1, 6 - R.t); txt('고리가 겹칠 때 한 번씩 탭', cx, z.y + 42, '#ab9fb8', '600 12px ' + FONT); ctx.globalAlpha = 1; }
      ctx.restore();
    }

    const stopLoop = U.loop((rdt, now) => {
      if (!st) return;
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next, prev) {
        if (!next) return;
        const was = st; st = next;
        void prev;
        const k = curKey();
        if (st.ph === 'pick' || st.ph === 'odd') { if (!R || key !== k) { key = k; R = newBout(st.n, st.tm.replace(/[-?]/g, '0')); phase = 'wait'; } layout(); syncPicker(); return; }
        if (k !== key || phase === 'wait') { key = k; startBout(); }
        if (was && was.tm !== st.tm) layout();
        if (st.ph === 'run' && phase === 'count' && !host()) { phase = 'run'; cd = 0; }
        if (st.ph === 'end' && (!was || was.ph !== 'end')) { endT = END_T; if (!host() && R) R.win = st.fin; const mineWin = mine().some((s) => +st.tm[s] === st.fin); api.sfx(mineWin ? 'win' : 'chip'); }
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        if (pick) pick.remove(); if (tip) tip.remove(); styleEl.remove(); cv.destroy(); Drum.close();
      },
      _dbg: () => ({ R, st, phase, zones, field, tapSeat, fb }),
    };
  }

  L.register({
    id: 'tugwar', name: '줄다리기 리듬전', tag: '박자 줄다리기', cat: '파티',
    blurb: '두 팀이 박자에 맞춰 화면을 두드려 줄을 당겨요. 팀 전원이 연속으로 맞히면 “영차!” 3판 2선승. 짝수 인원(2·4·6명)만 — 두 팀은 늘 같은 인원. 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#6a4a1c',
    icon: '<path d="M4 30h48" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M28 24l-4 12h8z" fill="currentColor"/><circle cx="10" cy="14" r="4" fill="currentColor"/><path d="M10 18l-4 12M8 24l8 6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="46" cy="14" r="4" fill="currentColor"/><path d="M46 18l4 12M48 24l-8 6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M14 44h4M24 44h2M30 44h2M38 44h4" stroke="currentColor" stroke-width="4" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'pull', label: '당기기 (박자 탭)', keys: ['Space', 'Enter'], pad: ['a', 'rb'] },
    ],
    options: [
      { id: 'team', label: '팀 나누기', choices: [{ v: 'alt', label: '번갈아 (1·3·5 vs 2·4·6)' }, { v: 'half', label: '앞·뒤 반반' }, { v: 'pick', label: '각자 고르기 (팀당 절반까지)' }], def: 'alt' },
    ],
    quick: [
      '청팀(왼쪽)과 홍팀(오른쪽)이 줄을 당겨요. 줄 가운데 금색 표시를 우리 팀 선(점선) 너머로 끌어오면 그 판 승리.',
      '아래 내 구역을 드럼 박자에 맞춰 한 번씩 톡! 줄어드는 고리가 가운데 원에 겹칠 때가 박자예요.',
      '3판 2선승. 팀 전원이 8박 연속으로 맞히면 「영차!」로 크게 당겨요.',
    ],
    rules: [
      { h: '목표', p: [
        '청팀(왼쪽)과 홍팀(오른쪽)이 줄을 당겨요. 줄 가운데 금색 표시를 우리 팀 선(점선) 너머로 끌어오면 그 판 승리예요.',
        '3판 2선승: 먼저 2판을 이긴 팀이 우승.',
        '인원은 짝수(2·4·6명)만 가능해요. 두 팀 인원은 항상 같아요(1:1, 2:2, 3:3). 홀수 인원으로 시작하면 게임이 열리지 않아요.',
      ] },
      { h: '조작 (터치)', p: [
        '화면 위쪽은 줄다리기 마당, 아래쪽 큰 칸이 내 구역이에요.',
        '드럼 박자에 맞춰 내 구역 아무 데나 한 번씩 톡! 바깥에서 줄어드는 고리가 가운데 원에 겹칠 때가 박자예요.',
        '한 박자에 한 번만 쳐요. 두 번 이상 치면 「너무 많이!」로 힘이 크게 빠져요.',
        'PC 키보드·게임패드: 스페이스·Enter·Ⓐ·RB로 탭(한 번 누를 때마다 한 번). 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '판정 · 힘', p: [
        '퍼펙트(박자 ±0.06초)는 가장 세게, 좋아요(±0.13초)는 조금 약하게 당겨요. 박자 밖의 탭은 거의 당기지 못하고 힘이 빠져요.',
        '힘(내 구역 아래 막대)이 빠지면 당기는 힘도 약해져요. 박자에 맞추면 천천히 회복돼요.',
        '팀 전체 당기는 힘 = 팀원들 힘의 합.',
        '박자는 판이 진행될수록 빨라져요(84 → 150 BPM).',
      ] },
      { h: '영차! · 특수 규칙', p: [
        '영차!: 팀원 모두가 8박 연속으로 맞히면 다 같이 크게 한 번 당겨요(16박, 24박…마다 또). 한 명이라도 놓치면 처음부터. 내 구역 오른쪽 위에 연속 횟수가 보여요.',
        '40초가 지나면 양쪽 선이 조금씩 가운데로 다가와요. 끝까지 버티기만 할 수는 없어요!',
      ] },
      { h: '팁', p: [
        '빨리 치는 게 아니라 정확히 치는 게임이에요. 드럼 소리를 듣고 박자에 맞춰요.',
        '박자를 놓쳤다고 마구 치지 마세요. 다음 박자를 기다리는 게 이득이에요.',
        '내 구역의 「○ 연속」 숫자가 8에 가까워지면 특히 집중! 팀 전원이 8박을 채우면 영차예요.',
      ] },
      { h: '예시', p: [
        '2:2 경기, 우리 팀 둘 다 8박 연속 퍼펙트·좋아요 → 「영차!」 → 줄이 우리 쪽으로 쑥!',
        '→ 그런데 내가 한 박자에 두 번 쳐서 「너무 많이!」 → 내 힘이 줄고 연속이 끊겨, 영차는 다시 8박을 모아야 해요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지 자리는 AI예요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로 해요.',
        '온라인·LAN: 박자는 각 폰에서 직접 울리고, 판정도 각 폰에서 해서 인터넷이 조금 느려도 공정해요. 줄은 호스트 폰이 계산해요.',
        '팀 나누기: 번갈아 / 앞·뒤 반반 / 각자 고르기(한 팀은 인원의 절반까지만 — 꽉 찬 팀은 고를 수 없고, 남은 자리는 AI가 채워요).',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 박자가 들쭉날쭉하고 가끔 연타해 지치고, 어려움은 거의 퍼펙트로 쳐요.',
      ] },
    ],
    init, actor, apply,
    ai: () => null,
    result, mount,
    _t: { H, B0, BMAX, PW, GW, PULL, LINE0, phi, beatT, bpmAt, judge, newBout, applyCat, stepBout, aiStep, teamsFor, fillAI, init, actor, apply, endBout, nextBout, result },
  });
})();
