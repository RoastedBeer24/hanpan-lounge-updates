/* 로켓 착륙 — realtime lander score attack (1–4).
   Everyone flies their own lander over the SAME terrain at the same time (other landers are ghosts, no collisions).
   Each round is a different planet (gravity / wind / caves / updrafts / thick air); land softly on a pad —
   smaller and farther pads are worth more. Crash = 0 for that round. Solo = mission mode with stars.
   Each device simulates its own lander (host/local also simulates the AI landers). Positions/results are shared
   (cooking/pinball pattern: guests publish {k,d:[x,y,a,t,e,p]}, host sends {k,L:[rows]}); the host advances rounds
   with setState (ph 'play' → 'sum' → next round … → 'done').
   Physics: fixed 120 Hz steps, y up (metres). Terrain = height field on a 2 m grid + optional rock slabs (cave roofs). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2, DEG = 180 / Math.PI;

  /* ======================= constants ======================= */
  const HZ = 120, DT = 1 / HZ, GDX = 2, WW = 240, NG = WW / GDX + 1;
  const VL = 3.0, HL = 1.6, AL = 12 / DEG;          // landing limits: vertical m/s, horizontal m/s, tilt
  const ROT = 1.9, SPOOL = 0.12, TLIM = 120;          // rotation rad/s, engine spool s, round time limit s
  const FX = 1.55, FY = 1.8;                          // feet at (±FX, −FY) from the body centre
  const HULL = [[-1.3, -0.95], [1.3, -0.95], [-1.2, 0.55], [1.2, 0.55], [-0.6, 1.35], [0.6, 1.35], [0, 1.55]];
  const PADC = { 1: '#8fe0a0', 2: '#6fd0ff', 3: '#ffc84a', 5: '#ff6ad0' };
  const HUDH = 46;
  const fmt = (n) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  function mkRng(seed) {
    let a = (seed >>> 0) || 0x9e3779b9;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function noise1(r, len, amp) {
    const n = Math.ceil(WW / len) + 3, v = [];
    for (let i = 0; i < n; i++) v.push(r() * 2 - 1);
    return (x) => { const f = Math.max(0, x) / len, i = Math.floor(f), t = f - i, k = (1 - Math.cos(t * Math.PI)) / 2; return (v[i] * (1 - k) + v[i + 1] * k) * amp; };
  }
  const mix32 = (x) => { x ^= x >>> 16; x = Math.imul(x, 0x7feb352d); x ^= x >>> 15; x = Math.imul(x, 0x846ca68b); x ^= x >>> 16; return x >>> 0; };
  const sstep = (t) => { t = U.clamp(t, 0, 1); return t * t * (3 - 2 * t); };

  /* ======================= terrain helpers ======================= */
  function each(W, f) { for (let i = 0; i < NG; i++) W.G[i] = f(i * GDX, W.G[i]); }
  function bump(W, xc, rad, h) { each(W, (x, y) => { const d = Math.abs(x - xc) / rad; return d < 1 ? y + h * (0.5 + 0.5 * Math.cos(d * Math.PI)) : y; }); }
  function mesa(W, xa, xb, h, sl) {
    const a = Math.min(xa, xb), b = Math.max(xa, xb);
    each(W, (x, y) => { const f = x < a ? sstep((x - (a - sl)) / sl) : x > b ? sstep(((b + sl) - x) / sl) : 1; return y + h * f; });
  }
  function crater(W, xc, rad, dep, rim) {
    each(W, (x, y) => {
      const d = Math.abs(x - xc) / rad;
      if (d < 1) return y - dep * (1 - d * d) + rim * d * d * d * d;
      if (d < 1.6) { const k = 1 - (d - 1) / 0.6; return y + rim * k * k; }
      return y;
    });
  }
  function pad(W, xc, wd, m, lvl) {
    const i0 = Math.max(1, Math.floor((xc - wd / 2) / GDX) - 1), i1 = Math.min(NG - 2, Math.ceil((xc + wd / 2) / GDX) + 1);
    let y = 0;
    if (lvl === 'max') { y = -1e9; for (let i = i0; i <= i1; i++) y = Math.max(y, W.G[i]); }
    else if (typeof lvl === 'number') y = lvl;
    else { for (let i = i0; i <= i1; i++) y += W.G[i]; y /= (i1 - i0 + 1); }
    for (let i = i0; i <= i1; i++) { W.G[i] = y; W.lava[i] = 0; }
    W.pads.push({ x0: xc - wd / 2, x1: xc + wd / 2, y, m, sl: -1 });
  }
  function slab(W, xa, xb, bot, top) {
    const a = Math.min(xa, xb), b = Math.max(xa, xb);
    const i0 = Math.max(0, Math.round(a / GDX)), i1 = Math.min(NG - 1, Math.round(b / GDX));
    const S = { i0, i1, x0: i0 * GDX, x1: i1 * GDX, bot: new Float32Array(i1 - i0 + 1), top: new Float32Array(i1 - i0 + 1) };
    for (let i = i0; i <= i1; i++) { const x = i * GDX; S.bot[i - i0] = bot(x, W.G[i]); S.top[i - i0] = Math.max(S.bot[i - i0] + 4, top(x, S.bot[i - i0])); }
    W.slabs.push(S);
    return S;
  }
  function lavaLake(W, xc, rad, dep) {
    bump(W, xc, rad, -dep);
    let lo = 1e9; const i0 = Math.max(0, Math.floor((xc - rad) / GDX)), i1 = Math.min(NG - 1, Math.ceil((xc + rad) / GDX));
    for (let i = i0; i <= i1; i++) lo = Math.min(lo, W.G[i]);
    const lvl = lo + dep * 0.45;
    for (let i = i0; i <= i1; i++) if (W.G[i] <= lvl) { W.G[i] = lvl; W.lava[i] = 1; }
  }

  /* ======================= planets (original designs) ======================= */
  const STAGES = [
    {
      n: '달 크레이터', g: 1.62, T: 4.4, fuel: 24, alt: 70, vx0: 4, short: '달',
      sub: '중력 약함 · 바람 없음', tip: '처음엔 천천히! 내려가는 속도를 초록 안에 두세요.',
      sky: ['#04050c', '#161a2a'], gnd: ['#a8a59c', '#4a4842'], edge: '#e4e0d4', far: '#23252f', star: 1, orb: { x: 0.8, y: 0.2, r: 22, c: '#4f8fe0', c2: '#e8f0ff' },
      gen(W, r, X) {
        const n1 = noise1(r, 44, 15), n2 = noise1(r, 12, 3.5);
        each(W, (x) => 24 + n1(x) + n2(x));
        for (let k = 0; k < 3; k++) crater(W, X(0.18 + 0.26 * k + r() * 0.1), 9 + r() * 8, 6 + r() * 5, 2.5 + r() * 2);
        bump(W, X(0.88), 11, 12);
        pad(W, X(0.29 + r() * 0.03), 14, 1); pad(W, X(0.5 + r() * 0.03), 9, 2); pad(W, X(0.7 + r() * 0.02), 6.6, 3); pad(W, X(0.88), 4.8, 5, 'max');
      },
    },
    {
      n: '화성 바람 협곡', g: 3.71, T: 9.0, fuel: 20, alt: 75, vx0: 3, short: '화성',
      sub: '중력 보통 · 옆바람', tip: '바람이 밀어요. 바람 반대쪽으로 살짝 기울여 버티세요.',
      sky: ['#3a160c', '#c0704a'], gnd: ['#c06a40', '#5a2412'], edge: '#f0a070', far: '#8a4028', star: 0, orb: { x: 0.22, y: 0.16, r: 9, c: '#f6e8c8', c2: '#fff6e0' }, dust: 1,
      gen(W, r, X) {
        const n1 = noise1(r, 30, 4), n2 = noise1(r, 8, 1.2);
        each(W, (x) => 10 + n1(x) + n2(x));
        mesa(W, X(0.21), X(0.37), 24 + r() * 4, 4);
        mesa(W, X(0.63), X(0.73), 32 + r() * 4, 4);
        mesa(W, X(0.76), X(0.815), 30, 4); mesa(W, X(0.915), X(0.97), 30, 4);
        pad(W, X(0.29), 14, 1); pad(W, X(0.5 + r() * 0.02), 9, 2); pad(W, X(0.68), 6.6, 3); pad(W, X(0.865), 4.8, 5);
        W.wind = { b: (r() < 0.5 ? -1 : 1) * (5 + r() * 3), p1: r() * TAU, p2: r() * TAU };
      },
    },
    {
      n: '얼음 위성 동굴', g: 1.31, T: 3.6, fuel: 26, alt: 40, vx0: 3, short: '얼음',
      sub: '중력 약함 · 얼음 동굴', tip: '천장 구멍으로 들어가 동굴 안쪽 패드를 노려요. 천장에 닿으면 추락!',
      sky: ['#020610', '#0c2034'], gnd: ['#cfeaf6', '#3a6a88'], edge: '#ffffff', far: '#15304a', star: 1, slab: ['#a8d4ea', '#2c5674'], orb: { x: 0.75, y: 0.15, r: 30, c: '#d8b070', c2: '#fff0c8' }, ice: 1,
      gen(W, r, X) {
        const n1 = noise1(r, 40, 4), n2 = noise1(r, 9, 1.2);
        each(W, (x) => 10 + n1(x) + n2(x));
        pad(W, X(0.24), 14, 1); pad(W, X(0.5), 6.6, 3); pad(W, X(0.9), 4.8, 5);
        const nb = noise1(r, 16, 2.2), nt = noise1(r, 22, 3.5);
        slab(W, X(0.4), X(0.6), (x, g) => g + 23 + nb(x), (x, b) => b + 12 + nt(x));
        const S2 = slab(W, X(0.67), X(1.0), (x, g) => g + 23 + nb(x), (x, b) => b + 12 + nt(x));
        // ×2 pad on the roof top
        const xc = X(0.81), wd = 9, a = Math.max(S2.i0, Math.floor((xc - wd / 2) / GDX) - 1), b = Math.min(S2.i1, Math.ceil((xc + wd / 2) / GDX) + 1);
        let top = -1e9; for (let i = a; i <= b; i++) top = Math.max(top, S2.top[i - S2.i0]);
        for (let i = a; i <= b; i++) S2.top[i - S2.i0] = top;
        W.pads.push({ x0: xc - wd / 2, x1: xc + wd / 2, y: top, m: 2, sl: 1 });
        W.icicles = [];
        for (const S of W.slabs) for (let x = S.x0 + 2; x < S.x1 - 2; x += 1.6 + r() * 2.4) W.icicles.push([x, 0.4 + r() * 0.7]);
      },
    },
    {
      n: '소행성 바위밭', g: 0.62, T: 2.2, fuel: 30, alt: 45, vx0: 5, short: '소행성',
      sub: '중력 아주 약함 · 뾰족 바위', tip: '중력이 약해 잘 안 멈춰요. 미리미리 속도를 줄이세요.',
      sky: ['#030305', '#100c18'], gnd: ['#7a6e62', '#2a2420'], edge: '#b8a48e', far: '#1c1822', star: 1, orb: { x: 0.18, y: 0.24, r: 40, c: '#c06a3a', c2: '#ffd0a0' },
      gen(W, r, X) {
        const n1 = noise1(r, 26, 12), n2 = noise1(r, 7, 4.5), n3 = noise1(r, 3, 1.2);
        each(W, (x) => 18 + n1(x) + n2(x) + n3(x));
        bump(W, X(0.3), 18, -6);
        bump(W, X(0.68), 7, 16); bump(W, X(0.87), 6, 24);
        pad(W, X(0.3), 12, 1); pad(W, X(0.5 + r() * 0.02), 8, 2); pad(W, X(0.68), 6.2, 3, 'max'); pad(W, X(0.87), 4.6, 5, 'max');
      },
    },
    {
      n: '안개 위성', g: 1.35, T: 3.6, fuel: 24, alt: 65, vx0: 4, short: '안개',
      sub: '공기 짙음 · 안개', tip: '공기가 짙어 천천히 떨어져요. 대신 앞이 잘 안 보여요.',
      sky: ['#2c2618', '#8a7a52'], gnd: ['#8a7448', '#3a2e18'], edge: '#d0b880', far: '#5a4c30', star: 0, fog: '#b8a274', drag: 0.012,
      gen(W, r, X) {
        const n1 = noise1(r, 55, 9), n2 = noise1(r, 14, 2.5);
        each(W, (x) => 16 + n1(x) + n2(x));
        mesa(W, X(0.6), X(1.2), 15, 5);
        bump(W, X(0.9), 9, 10);
        pad(W, X(0.28), 14, 1); pad(W, X(0.47 + r() * 0.02), 9, 2); pad(W, X(0.72), 6.6, 3); pad(W, X(0.9), 4.8, 5, 'max');
      },
    },
    {
      n: '화산 행성', g: 2.4, T: 6.0, fuel: 22, alt: 70, vx0: 3, short: '화산',
      sub: '중력 보통 · 뜨거운 바람 기둥', tip: '분화구 위 열기둥이 위로 밀어 올려요. 용암에 닿으면 끝!',
      sky: ['#140406', '#561608'], gnd: ['#3e2e2a', '#140c0c'], edge: '#8a6458', far: '#2e0e08', star: 1, lava: '#ff6a1a', orb: { x: 0.7, y: 0.18, r: 14, c: '#ff9a4a', c2: '#ffe0a0' },
      gen(W, r, X) {
        const n1 = noise1(r, 40, 13), n2 = noise1(r, 10, 2.5);
        each(W, (x) => 22 + n1(x) + n2(x));
        lavaLake(W, X(0.38), 10, 10); lavaLake(W, X(0.59), 9, 9); lavaLake(W, X(0.79), 7, 8);
        bump(W, X(0.9), 9, 10);
        pad(W, X(0.25), 14, 1); pad(W, X(0.48), 9, 2); pad(W, X(0.69), 6.6, 3); pad(W, X(0.9), 4.8, 5, 'max');
        W.vents = [{ x: X(0.63), a: 2.1, per: 4.6, ph: r() * TAU }, { x: X(0.84), a: 2.3, per: 5.4, ph: r() * TAU }];
      },
    },
  ];

  function genWorld(si, seed) {
    const S = STAGES[si], r = mkRng(seed);
    const flip = r() < 0.5;
    const W = { si, S, seed, g: S.g, T: S.T, fuel: S.fuel, cd: S.drag || 0, G: new Float32Array(NG), lava: new Uint8Array(NG),
      slabs: [], pads: [], vents: [], wind: null, flip, icicles: null, grid: null };
    const X = (u) => (flip ? WW - u * WW : u * WW);
    S.gen(W, r, X);
    // edge walls
    for (let i = 0; i < NG; i++) { const x = i * GDX, e = Math.min(x, WW - x); if (e < 14) W.G[i] += (14 - e) * (14 - e) * 0.45; }
    let hi = -1e9, lo = 1e9;
    for (let i = 0; i < NG; i++) { const x = i * GDX, e = Math.min(x, WW - x); lo = Math.min(lo, W.G[i]); if (e >= 14) hi = Math.max(hi, W.G[i]); }
    for (const s of W.slabs) for (let k = 0; k < s.top.length; k++) { const x = (s.i0 + k) * GDX; if (Math.min(x, WW - x) >= 14) hi = Math.max(hi, s.top[k]); }
    W.ymin = lo; W.yhi = hi;
    const sx = X(0.06);
    W.start = { x: sx, y: Math.max(hi, gAt(W, sx) + 20) + S.alt, vx: (flip ? -1 : 1) * S.vx0 };
    W.yTop = W.start.y + 45;
    W.pads.sort((a, b) => a.m - b.m);
    W.lavaRuns = [];
    for (let i = 0; i < NG; i++) if (W.lava[i]) { let j = i; while (j + 1 < NG && W.lava[j + 1]) j++; W.lavaRuns.push([i, j]); i = j; }
    // decoration (seeded, view only)
    const rd = mkRng(seed ^ 0x2f6b1d);
    W.rocks = [];
    for (let k = 0; k < 46; k++) {
      const x = 4 + rd() * (WW - 8);
      if (W.pads.some((p) => x > p.x0 - 3 && x < p.x1 + 3)) continue;
      if (W.lava[Math.round(x / GDX)]) continue;
      W.rocks.push([x, 0.25 + rd() * rd() * 1.3]);
    }
    const nf = noise1(rd, 30, 1), nf2 = noise1(rd, 9, 0.3);
    W.far = []; for (let x = 0; x <= WW; x += 3) W.far.push(0.5 + nf(x) * 0.6 + nf2(x));
    return W;
  }

  /* ======================= queries ======================= */
  function gAt(W, x) {
    const f = U.clamp(x / GDX, 0, NG - 1.0001), i = Math.floor(f), t = f - i;
    return W.G[i] * (1 - t) + W.G[i + 1] * t;
  }
  function slabAt(s, arr, x) {
    const f = U.clamp(x / GDX - s.i0, 0, arr.length - 1.0001), i = Math.floor(f), t = f - i;
    return arr[i] * (1 - t) + arr[i + 1] * t;
  }
  function solidAt(W, x, y) {   // 0 free, 1 ground, 2 lava, 3 rock slab
    if (x < 0 || x > WW) return 0;
    if (y < gAt(W, x)) return W.lava[Math.round(x / GDX)] ? 2 : 1;
    for (const s of W.slabs) {
      if (x < s.x0 || x > s.x1) continue;
      if (y > slabAt(s, s.bot, x) && y < slabAt(s, s.top, x)) return 3;
    }
    return 0;
  }
  function surfBelow(W, x, y) {
    let h = gAt(W, x);
    for (const s of W.slabs) {
      if (x < s.x0 || x > s.x1) continue;
      const t = slabAt(s, s.top, x);
      if (t <= y + 0.7 && t > h) h = t;
    }
    return h;
  }
  function windAt(W, t, alt) {
    const w = W.wind;
    if (!w) return 0;
    return w.b * (0.72 + 0.3 * Math.sin(0.31 * t + w.p1) + 0.2 * Math.sin(1.07 * t + w.p2)) * U.clamp(0.3 + alt / 40, 0.3, 1);
  }
  function ventPulse(v, t) { const s = Math.sin(TAU * t / v.per + v.ph); return s > 0 ? s * s : 0; }
  function ventAt(W, x, alt, t) {
    let a = 0;
    for (const v of W.vents) { const d = (x - v.x) / 6; if (d > -3 && d < 3) a += v.a * ventPulse(v, t) * Math.exp(-d * d) * U.clamp(1 - alt / 55, 0, 1); }
    return a;
  }
  const EA = { ax: 0, ay: 0 };
  function extAcc(W, Ld, out) {
    let ax = 0, ay = 0;
    if (W.wind || W.vents.length) {
      const alt = Ld.y - FY - surfBelow(W, Ld.x, Ld.y);
      if (W.wind) ax += 0.1 * (windAt(W, Ld.t, alt) - Ld.vx);
      if (W.vents.length) ay += ventAt(W, Ld.x, alt, Ld.t);
    }
    if (W.cd) { const v = Math.hypot(Ld.vx, Ld.vy); ax -= W.cd * v * Ld.vx; ay -= W.cd * v * Ld.vy; }
    out.ax = ax; out.ay = ay;
    return out;
  }

  /* ======================= lander simulation ======================= */
  function newLander(W) {
    const s = W.start;
    return { x: s.x, y: s.y, vx: s.vx, vy: 0, a: 0, w: 0, thr: 0, fuel: W.fuel, t: 0, e: -1, pts: 0, why: '', pad: -1, bd: null, sd: 0, ft: 0, tvy: 0, tvx: 0,
      inp: { th: 0, rot: 0, tgt: null, lvl: true }, ai: null, acc: 0 };
  }
  function finishL(Ld, e, pts, why) { Ld.e = e; Ld.pts = pts; Ld.why = why; Ld.thr = 0; Ld.ft = Ld.t; }
  function stepL(W, Ld) {
    if (Ld.e >= 0) return;
    const I = Ld.inp, dt = DT;
    let want = I.th;
    if (want > 0 && want < 1) { Ld.sd += want; if (Ld.sd >= 1) { Ld.sd -= 1; want = 1; } else want = 0; }
    if (Ld.fuel <= 0) want = 0;
    Ld.thr += U.clamp((want ? 1 : 0) - Ld.thr, -dt / SPOOL, dt / SPOOL);
    let wt = 0;
    if (I.tgt != null) wt = U.clamp((I.tgt - Ld.a) * 12, -ROT, ROT);
    else if (I.rot) wt = U.clamp(I.rot, -1, 1) * ROT;
    else if (I.lvl) wt = U.clamp(-Ld.a * 6, -ROT, ROT);
    Ld.w += (wt - Ld.w) * Math.min(1, dt / 0.07);
    Ld.a = U.clamp(Ld.a + Ld.w * dt, -1.6, 1.6);
    const T = W.T * Ld.thr;
    extAcc(W, Ld, EA);
    Ld.vx += (T * Math.sin(Ld.a) + EA.ax) * dt;
    Ld.vy += (T * Math.cos(Ld.a) - W.g + EA.ay) * dt;
    Ld.x += Ld.vx * dt; Ld.y += Ld.vy * dt;
    Ld.fuel = Math.max(0, Ld.fuel - Ld.thr * dt);
    Ld.t += dt;
    collide(W, Ld);
    if (Ld.e < 0) {
      if (Ld.x < 0.5 || Ld.x > WW - 0.5 || Ld.y > W.yTop) finishL(Ld, 1, 0, '궤도를 벗어났어요');
      else if (Ld.t > TLIM) finishL(Ld, 1, 0, '시간 초과');
    }
  }
  function collide(W, Ld) {
    const c = Math.cos(Ld.a), s = Math.sin(Ld.a);
    for (const p of HULL) {
      const k = solidAt(W, Ld.x + p[0] * c + p[1] * s, Ld.y - p[0] * s + p[1] * c);
      if (k) { Ld.tvy = Ld.vy; Ld.tvx = Ld.vx; finishL(Ld, 0, 0, k === 2 ? '용암에 빠졌어요' : k === 3 ? '바위에 부딪혔어요' : '몸통이 땅에 부딪혔어요'); return; }
    }
    const fx0 = Ld.x - FX * c - FY * s, fy0 = Ld.y + FX * s - FY * c;
    const fx1 = Ld.x + FX * c - FY * s, fy1 = Ld.y - FX * s - FY * c;
    const k0 = solidAt(W, fx0, fy0), k1 = solidAt(W, fx1, fy1);
    if (!k0 && !k1) return;
    Ld.tvy = Ld.vy; Ld.tvx = Ld.vx;
    if (k0 === 2 || k1 === 2) return finishL(Ld, 0, 0, '용암에 빠졌어요');
    if (Ld.vy < -VL) return finishL(Ld, 0, 0, '너무 빨리 내려왔어요 (↓' + (-Ld.vy).toFixed(1) + ')');
    if (Math.abs(Ld.vx) > HL) return finishL(Ld, 0, 0, '옆으로 너무 빨랐어요 (' + Math.abs(Ld.vx).toFixed(1) + ')');
    if (Math.abs(Ld.a) > AL) return finishL(Ld, 0, 0, '너무 기울었어요 (' + Math.round(Math.abs(Ld.a) * DEG) + '°)');
    const s0 = surfBelow(W, fx0, fy0 + 0.6), s1 = surfBelow(W, fx1, fy1 + 0.6);
    if (Math.abs(s1 - s0) > 0.8) return finishL(Ld, 0, 0, '비탈에서 넘어졌어요');
    // settle
    const sy = (s0 + s1) / 2;
    Ld.a = -Math.atan2(s1 - s0, fx1 - fx0);   // rest flat on the surface (right side higher → lean left)
    Ld.y = sy + FY; Ld.w = 0;
    const vy = Ld.vy;
    Ld.vx = 0; Ld.vy = 0;
    let pi = -1;
    W.pads.forEach((p, i) => { if (Ld.x >= p.x0 && Ld.x <= p.x1 && Math.abs(p.y - sy) < 0.6) pi = i; });
    if (pi < 0) { Ld.bd = null; Ld.pad = -1; return finishL(Ld, 2, 30, '안전 착륙 (패드 밖)'); }
    const p = W.pads[pi], half = (p.x1 - p.x0) / 2, off = Math.abs(Ld.x - (p.x0 + p.x1) / 2);
    const soft = Math.round(50 * U.clamp(1 - (-vy) / VL, 0, 1)), ctr = Math.round(50 * U.clamp(1 - off / half, 0, 1)), fuel = Math.round(100 * Ld.fuel / W.fuel);
    Ld.bd = [100 * p.m, soft, ctr, fuel]; Ld.pad = pi;
    finishL(Ld, 10 + p.m, 100 * p.m + soft + ctr + fuel, '×' + p.m + ' 패드 착륙!');
  }
  // stars for solo: ★ safe landing, ★★ on a pad, ★★★ on a pad with 320+ points
  const starsOf = (e, pts) => (e >= 10 ? (pts >= 320 ? 3 : 2) : e === 2 ? 1 : 0);

  /* ======================= AI pilot ======================= */
  const AIP = {
    1: { hz: 8, kp: 0.9, tilt: 0.5, vmax: 7, ab: 0.3, tr: 1.4, vt: 1.8, vd: 6, noise: 0.6, comp: 0, skip: 0.12, sloppy: 0.2, ctr: 3, vxok: 1.5, off: 0.55, pick: { 1: 55, 2: 35, 3: 10 } },
    2: { hz: 12, kp: 1.3, tilt: 0.7, vmax: 11, ab: 0.45, tr: 1.1, vt: 1.5, vd: 9, noise: 0.22, comp: 0.6, skip: 0, ctr: 1.0, vxok: 0.8, off: 0.3, pick: { 1: 12, 2: 28, 3: 50, 5: 10 } },
    3: { hz: 24, kp: 1.8, tilt: 0.9, vmax: 16, ab: 0.6, tr: 0.8, vt: 1.0, vd: 14, noise: 0, comp: 1, skip: 0, ctr: 0.5, vxok: 0.5, off: 0.04, pick: { 3: 20, 5: 80 } },
  };
  function gridOf(W) {
    if (W.grid) return W.grid;
    const C = 2, y0 = Math.floor(W.ymin) - 2, nx = Math.floor(WW / C) + 1, ny = Math.ceil((W.yTop + 6 - y0) / C) + 1;
    const free = new Uint8Array(nx * ny), near = new Uint8Array(nx * ny);
    const DX = [-3.4, -1.7, 0, 1.7, 3.4], DY = [-2.9, -1.2, 0.5, 2.2];
    for (let j = 0; j < ny; j++) {
      const y = y0 + j * C;
      for (let i = 0; i < nx; i++) {
        const x = i * C;
        let ok = x > 4 && x < WW - 4;
        if (ok) { outer: for (const dx of DX) for (const dy of DY) if (solidAt(W, x + dx, y + dy)) { ok = false; break outer; } }
        free[j * nx + i] = ok ? 1 : 0;
      }
    }
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      if (!free[j * nx + i]) continue;
      let n = 0;
      for (let b = -2; b <= 2; b++) for (let a = -2; a <= 2; a++) { const I = i + a, J = j + b; if (I < 0 || J < 0 || I >= nx || J >= ny || !free[J * nx + I]) n++; }
      near[j * nx + i] = n;
    }
    return (W.grid = { C, y0, nx, ny, free, near });
  }
  function cellOf(G, x, y) { return [U.clamp(Math.round(x / G.C), 0, G.nx - 1), U.clamp(Math.round((y - G.y0) / G.C), 0, G.ny - 1)]; }
  function nearestFree(G, i, j) {
    if (G.free[j * G.nx + i]) return [i, j];
    for (let r = 1; r < 12; r++) for (let b = -r; b <= r; b++) for (let a = -r; a <= r; a++) {
      const I = i + a, J = j + b;
      if (I >= 0 && J >= 0 && I < G.nx && J < G.ny && G.free[J * G.nx + I]) return [I, J];
    }
    return null;
  }
  function los(G, ax, ay, bx, by) {
    const d = Math.hypot(bx - ax, by - ay), n = Math.max(1, Math.ceil(d / 0.7));
    for (let k = 0; k <= n; k++) {
      const t = k / n, c = cellOf(G, ax + (bx - ax) * t, ay + (by - ay) * t);
      if (!G.free[c[1] * G.nx + c[0]]) return false;
    }
    return true;
  }
  function planPath(W, sx, sy, gx, gy) {
    const G = gridOf(W), nx = G.nx;
    const s = nearestFree(G, ...cellOf(G, sx, sy)), g = nearestFree(G, ...cellOf(G, gx, gy));
    if (!s || !g) return null;
    const N = nx * G.ny, gs = new Float32Array(N).fill(1e9), came = new Int32Array(N).fill(-1), done = new Uint8Array(N);
    const hk = [], hv = [];
    const push = (k, v) => { hk.push(k); hv.push(v); let i = hk.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (hv[p] <= hv[i]) break; [hk[p], hk[i]] = [hk[i], hk[p]]; [hv[p], hv[i]] = [hv[i], hv[p]]; i = p; } };
    const pop = () => {
      const k = hk[0], lk = hk.pop(), lv = hv.pop();
      if (hk.length) { hk[0] = lk; hv[0] = lv; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < hk.length && hv[l] < hv[m]) m = l; if (r < hk.length && hv[r] < hv[m]) m = r; if (m === i) break; [hk[m], hk[i]] = [hk[i], hk[m]]; [hv[m], hv[i]] = [hv[i], hv[m]]; i = m; } }
      return k;
    };
    const si = s[1] * nx + s[0], gi = g[1] * nx + g[0];
    const hh = (k) => Math.hypot((k % nx) - g[0], ((k / nx) | 0) - g[1]);
    gs[si] = 0; push(si, hh(si));
    const NB = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];
    let found = false, it = 0;
    while (hk.length && it++ < 40000) {
      const k = pop();
      if (done[k]) continue;
      done[k] = 1;
      if (k === gi) { found = true; break; }
      const i = k % nx, j = (k / nx) | 0;
      for (const d of NB) {
        const I = i + d[0], J = j + d[1];
        if (I < 0 || J < 0 || I >= nx || J >= G.ny) continue;
        const q = J * nx + I;
        if (!G.free[q] || done[q]) continue;
        if (d[0] && d[1] && (!G.free[j * nx + I] || !G.free[J * nx + i])) continue;
        const c = gs[k] + d[2] * (1 + G.near[q] * 0.18);
        if (c < gs[q]) { gs[q] = c; came[q] = k; push(q, c + hh(q)); }
      }
    }
    if (!found) return null;
    const cells = [];
    for (let k = gi; k >= 0; k = came[k]) { cells.push([(k % nx) * G.C, G.y0 + ((k / nx) | 0) * G.C]); if (k === si) break; }
    cells.reverse();
    cells[cells.length - 1] = [gx, gy];
    // string pulling
    const out = [];
    let cx = sx, cy = sy, i = 0;
    while (i < cells.length - 1) {
      let j = cells.length - 1;
      while (j > i + 1 && !los(G, cx, cy, cells[j][0], cells[j][1])) j--;
      out.push(cells[j]); cx = cells[j][0]; cy = cells[j][1]; i = j;
    }
    if (!out.length) out.push([gx, gy]);
    return out;
  }
  function pathLen(path, x, y) { let l = 0, px = x, py = y; for (const p of path) { l += Math.hypot(p[0] - px, p[1] - py); px = p[0]; py = p[1]; } return l; }
  function padGoal(p) { return [(p.x0 + p.x1) / 2, p.y + FY + 4]; }
  function setPath(A, Ld, path) {
    A.path = path; A.wi = 0; A.px = Ld.x; A.py = Ld.y;
    A.rem = new Array(path.length).fill(0);
    for (let i = path.length - 2; i >= 0; i--) A.rem[i] = A.rem[i + 1] + Math.hypot(path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1]);
  }
  function aiInit(W, Ld, lv, seed, force) {
    const P = AIP[lv] || AIP[2], r = mkRng(mix32(seed >>> 0));
    const C = [];
    W.pads.forEach((p, i) => { const g = padGoal(p), path = planPath(W, Ld.x, Ld.y, g[0], g[1]); if (path) C.push({ i, p, path, len: pathLen(path, Ld.x, Ld.y) }); });
    // pad choice by level: 쉬움 = wide, close pads · 보통 = mostly ×3 · 어려움 = goes for ×5
    let pick = null;
    if (C.length) {
      const wt = P.pick, tot = C.reduce((t, c) => t + (wt[c.p.m] || 0), 0);
      let x = r() * tot;
      for (const c of C) { x -= wt[c.p.m] || 0; if (x <= 0 && (wt[c.p.m] || 0) > 0) { pick = c; break; } }
      if (!pick) pick = C.reduce((b, c) => (!b || c.len < b.len ? c : b), null);
    }
    if (force != null) pick = C.find((c) => c.p.m === force) || pick;
    const A = { lv, P, r, cd: r() * 0.1, mode: 0, pad: null, tx: Ld.x, planB: false, vt: (P.vt + (P.sloppy && r() < P.sloppy ? 0.9 : 0)) / Math.max(1, Math.sqrt(W.g / 1.62) * 0.9), path: [[Ld.x, Ld.y - 10]], wi: 0, rem: [0], px: Ld.x, py: Ld.y, nvx: 0, nvy: 0 };
    if (pick) {
      A.pad = pick.p; setPath(A, Ld, pick.path);
      const half = (pick.p.x1 - pick.p.x0) / 2;
      A.tx = (pick.p.x0 + pick.p.x1) / 2 + (r() * 2 - 1) * P.off * Math.max(0, half - 0.3);
    }
    Ld.ai = A;
    return A;
  }
  const EA2 = { ax: 0, ay: 0 };
  function ceilAbove(W, x, y) {   // free space above the body top (∞ if open sky)
    let c = 1e9;
    for (const s of W.slabs) { if (x < s.x0 || x > s.x1) continue; const b = slabAt(s, s.bot, x); if (b > y && b - y < c) c = b - y; }
    return c;
  }
  // speed that still lets us stop within `d` metres at decel `a`, after `tr` seconds of reaction
  const stopV = (d, a, tr) => Math.max(0, a * (-tr + Math.sqrt(tr * tr + 2 * Math.max(0, d) / a)));
  function aiThink(W, Ld) {
    const A = Ld.ai;
    if (!A || Ld.e >= 0) return;
    A.cd -= DT;
    if (A.cd > 0) return;
    const P = A.P, r = A.r;
    A.cd += 1 / (P.hz * Math.max(1, Math.sqrt(W.g / 1.62)));
    if (P.skip && r() < P.skip) return;
    const g = W.g, T = W.T;
    if (P.noise) { A.nvx = A.nvx * 0.5 + (r() + r() + r() - 1.5) * P.noise; A.nvy = A.nvy * 0.5 + (r() + r() + r() - 1.5) * P.noise; }
    const vx = Ld.vx + A.nvx, vy = Ld.vy + A.nvy;
    extAcc(W, Ld, EA2);
    const ex = EA2.ax * P.comp, ey = EA2.ay * P.comp;
    // running out of fuel → closest pad (보통·어려움)
    if (A.lv >= 2 && !A.planB && A.mode === 0 && Ld.fuel < W.fuel * 0.22) {
      A.planB = true;
      let best = null;
      for (const p of W.pads) { const g2 = padGoal(p), path = planPath(W, Ld.x, Ld.y, g2[0], g2[1]); if (!path) continue; const d = pathLen(path, Ld.x, Ld.y); if (!best || d < best.d) best = { p, d, g2, path }; }
      const cur = A.rem[A.wi] + Math.hypot(A.path[A.wi][0] - Ld.x, A.path[A.wi][1] - Ld.y);
      if (best && best.p !== A.pad && best.d < cur * 0.7) { A.pad = best.p; setPath(A, Ld, best.path); A.tx = best.g2[0]; }
    }
    const pad = A.pad, foot = Ld.y - FY;
    const below = foot - surfBelow(W, Ld.x, Ld.y - FY), above = ceilAbove(W, Ld.x, Ld.y + 1.55);
    const ah = P.ab * T * Math.sin(Math.min(P.tilt, 0.8)) * 0.8, av = P.ab * (T - g), acap = Math.max(0.25, Math.min(ah, av));
    let dvx = 0, dvy = 0, cap = P.tilt;
    if (A.mode === 0) {
      while (A.wi < A.path.length - 1) {
        const p = A.path[A.wi], q = A.path[A.wi + 1], sx = p[0] - A.px, sy = p[1] - A.py, sl = sx * sx + sy * sy;
        const past = sl > 1 && ((Ld.x - A.px) * sx + (Ld.y - A.py) * sy) / sl > 0.97;
        if (Math.hypot(p[0] - Ld.x, p[1] - Ld.y) < 4 || past) { A.px = p[0]; A.py = p[1]; A.wi++; } else if (los(gridOf(W), Ld.x, Ld.y, q[0], q[1])) { A.px = Ld.x; A.py = Ld.y; A.wi++; } else break;
      }
      const p = A.path[A.wi], dx = p[0] - Ld.x, dy = p[1] - Ld.y, d = Math.hypot(dx, dy) || 1e-3;
      const last = A.wi === A.path.length - 1;
      let spd = last ? stopV(d, acap * 0.7, P.tr) : stopV(d + A.rem[A.wi], acap, P.tr);
      if (!last) { // slow down for sharp corners
        const q = A.path[A.wi + 1], ux = dx / d, uy = dy / d, qx = q[0] - p[0], qy = q[1] - p[1], ql = Math.hypot(qx, qy) || 1;
        const cs = (ux * qx + uy * qy) / ql;
        if (cs < 0.8) spd = Math.min(spd, stopV(d, acap * 0.6, P.tr) + 0.6 + 4 * Math.max(0, cs));
      }
      spd = Math.min(spd, P.vmax);
      dvx = dx / d * spd; dvy = dy / d * spd;
      if (last && -dy > Math.abs(dx) && Math.abs(dx) > 2.5) dvy = Math.max(dvy, -2);   // line up before a steep final drop
      const sx = p[0] - A.px, sy = p[1] - A.py, sl = sx * sx + sy * sy;
      if (sl > 1) { const t = U.clamp(((Ld.x - A.px) * sx + (Ld.y - A.py) * sy) / sl, 0, 1); dvx += U.clamp((A.px + sx * t - Ld.x) * 0.6, -3, 3); dvy += U.clamp((A.py + sy * t - Ld.y) * 0.6, -3, 3); }
      if (last && (pad ? Math.abs(dx) < 3 && Math.abs(dy) < 8 && Math.abs(vx) < 2 : d < 4)) A.mode = 1;
      // never dive into what is below / bump what is above
      dvy = Math.max(dvy, -stopV(below - 3, av, P.tr) - 0.3);
      if (below < 3 && dvy < 0.8) dvy = 0.8;
      if (above < 4) dvy = Math.min(dvy, -0.6); else if (above < 9) dvy = Math.min(dvy, 0);
    }
    if (A.mode === 1) {
      const h = pad ? foot - pad.y : below;
      const tx = pad ? A.tx : Ld.x, dx = tx - Ld.x;
      dvx = U.clamp(dx * 0.55, -2.5, 2.5);
      const ready = Math.abs(dx) < P.ctr && Math.abs(vx) < P.vxok;
      if (ready || h > 5.5) dvy = -Math.max(A.vt, Math.min(P.vd, stopV(h - 0.4, av, 0.4)));
      else dvy = U.clamp((4.5 - h) * 0.8, -1, 1);
      if (!ready && below < 2.5) dvy = Math.max(dvy, 1);
      cap = Math.min(P.tilt, 0.1 + Math.max(0, h - 1) * 0.15);
    }
    const kp = P.kp * Math.max(1, Math.sqrt(g / 1.62) * 0.8);
    const Fx0 = (dvx - vx) * kp - ex, Fy = U.clamp((dvy - vy) * kp + g - ey, -99, T * 0.98);
    let duty = 0, tgt = 0;
    if (Fy > 0.05) {
      const mx = Math.sqrt(Math.max(0, T * T - Fy * Fy)), Fx = U.clamp(Fx0, -mx, mx);
      tgt = U.clamp(Math.atan2(Fx, Fy), -cap, cap);
      duty = U.clamp(Fy / Math.cos(tgt) / T, 0, 1);
      if (Math.abs(tgt - Ld.a) > 0.4 && vy > -4) duty *= 0.4;
    } else tgt = U.clamp(Math.atan2(Fx0, 0.8), -cap, cap) * 0.5;
    Ld.inp.th = duty; Ld.inp.tgt = tgt; Ld.inp.rot = 0;
  }
  function runAI(si, seed, lv, aiSeed) {   // headless helper (tests)
    const W = genWorld(si, seed), Ld = newLander(W);
    aiInit(W, Ld, lv, aiSeed == null ? seed : aiSeed);
    while (Ld.e < 0) { aiThink(W, Ld); stepL(W, Ld); }
    return { W, Ld };
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    const R = [3, 4, 5].includes(o.rounds) ? o.rounds : 4;
    let sg;
    if (o.stage >= 0 && o.stage < STAGES.length) sg = new Array(R).fill(o.stage);
    else {
      const first = U.rand(2) ? 0 : 4;   // start on an easy planet (달 / 안개)
      const rest = U.shuffle([0, 1, 2, 3, 4, 5].filter((x) => x !== first));
      sg = [first].concat(rest).slice(0, R);
    }
    return { rid: 1 + U.rand(99999), n: players.length, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), R, sg, sd: 1 + U.rand(2147483646), r: 0, ph: 'play', sc: [] };
  }
  const roundSeed = (s) => ((s.sd + s.r * 7919 + 1) >>> 0);
  function totals(s) { const t = new Array(s.n).fill(0); (s.sc || []).forEach((row) => row.forEach((c, i) => { if (c) t[i] += c[0] | 0; })); return t; }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.sc) || !s.sc.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const tot = totals(s);
    const rl = (i) => s.sc.map((row) => { const c = row[i] || [0, 0]; return c[1] >= 10 ? '×' + (c[1] - 10) : c[1] === 2 ? '착' : '✕'; }).join(' ');
    if (s.n === 1) {
      const st = s.sc.reduce((a, row) => a + starsOf(row[0][1], row[0][0]), 0), mx = s.sc.length * 3;
      const lines = s.sc.map((row, k) => (k + 1) + '판 ' + STAGES[s.sg[k]].short + '  ' + '★'.repeat(starsOf(row[0][1], row[0][0])) + '☆'.repeat(3 - starsOf(row[0][1], row[0][0])) + '  ' + fmt(row[0][0]) + '점');
      return { winners: st > 0 ? [0] : [], title: '★ ' + st + ' / ' + mx, text: lines.join('\n') + '\n총점 ' + fmt(tot[0]) + '점' + (st === mx ? '\n모든 별을 모았어요! 완벽한 비행사!' : '') };
    }
    const order = tot.map((v, i) => [i, v]).sort((a, b) => b[1] - a[1] || a[0] - b[0]);
    const top = order[0][1], winners = order.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = order.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + fmt(r[1]) + '점  (' + rl(r[0]) + ')');
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: lines.join('\n') + '\n×N = 그 패드에 착륙 · 착 = 패드 밖 착륙 · ✕ = 추락' };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `
.ld-b{position:absolute;z-index:3;touch-action:none;-webkit-user-select:none;user-select:none;cursor:pointer;
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;padding:0;
  border-radius:50%;border:2px solid rgba(227,174,69,.75);color:var(--ink,#f2e9d8);
  background:radial-gradient(circle at 50% 30%,#40355a,#211a2e 70%);font:700 15px var(--f-body,sans-serif);
  box-shadow:0 3px 0 #0b0810,0 6px 14px rgba(0,0,0,.5)}
.ld-b[hidden]{display:none}
.ld-b.on{transform:translateY(2px);box-shadow:0 1px 0 #0b0810;background:radial-gradient(circle at 50% 30%,#f3c868,#b8862a 75%);color:#1a1208}
.ld-b .ar{font-size:26px;line-height:1}
.ld-b .sm{font-size:11px;font-weight:600;opacity:.85;line-height:1.1}
.ld-thr{border-width:3px;font:400 20px var(--f-display,sans-serif)}
.ld-thr .sm{font-family:var(--f-body,sans-serif)}
.ld-as{border-radius:14px;font:600 12px var(--f-body,sans-serif);line-height:1.2;background:rgba(34,28,46,.92)}
.ld-as.off{border-color:rgba(171,159,184,.5);color:var(--muted,#ab9fb8)}
.ld-ff{border-radius:22px;font:700 14px var(--f-body,sans-serif);background:rgba(23,19,31,.85)}
`;
  const KEYN = { Space: '스페이스', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Enter: 'Enter', ShiftLeft: 'Shift' };
  const keyName = (c) => KEYN[c] || String(c || '').replace(/^Key/, '').replace(/^Digit/, '');
  const r1 = (v) => Math.round(v * 10) / 10, r2 = (v) => Math.round(v * 100) / 100;

  function rr(g, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    const fine = (() => { try { return matchMedia('(pointer:fine)').matches || !!window.LOUNGE_DESKTOP; } catch (e) { return false; } })();

    let st = null, key = null, W = null, LS = [], view = 0, lay = null, cdT = 0, cd0 = 0, rt = 0, lastCd = -1;
    let rings = [], parts = [], floats = [], shake = 0, flash = 0, ff = 1, endWait = 0, sumT = 0, pubT = 0, myFinT = -1, warnT = 0, frameN = 0;
    let cam = { x: WW / 2, y: 60, s: 2 }, camInit = false, mapC = null, mapKey = '', stars = null, thrOn = false;
    const remote = {}, heard = {}, ghost = {};
    let assist = true;
    try { const v = localStorage.getItem('lounge.lander.assist'); if (v === '0') assist = false; } catch (e) {}
    const curKey = () => (st ? st.rid + '.' + st.r : null);

    /* ----- round setup ----- */
    function ensureRound() {
      if (!st) return;
      const k = curKey();
      if (k === key) return;
      key = k;
      W = genWorld(st.sg[st.r], roundSeed(st));
      LS = [];
      for (let s = 0; s < st.n; s++) {
        if (!simHere(s)) { LS[s] = null; continue; }
        const Ld = newLander(W), p = api.players[s];
        if (p && p.ai) aiInit(W, Ld, p.lv || 2, (roundSeed(st) ^ (s * 7919 + 13)) >>> 0);
        Ld.inp.lvl = assist;
        LS[s] = Ld;
      }
      for (const x in remote) delete remote[x];
      for (const x in ghost) delete ghost[x];
      for (const x in heard) delete heard[x];
      const m = mine(), fst = LS.findIndex(Boolean);
      view = m.length ? m[0] : (fst >= 0 ? fst : 0);
      cd0 = cdT = st.ph === 'play' ? (st.r === 0 ? 4.2 : 3.4) : 0;
      lastCd = -1; rt = 0; parts = []; floats = []; rings = []; endWait = 0; sumT = 0; ff = 1; myFinT = -1; shake = 0; flash = 0; camInit = false; thrOn = false;
      ptrs.clear(); thrPtr = null;
      mapKey = '';
      if (st.ph !== 'play') LS.forEach((Ld) => { if (Ld) finishL(Ld, 1, 0, ''); });
      layout();
    }

    /* ----- layout ----- */
    const showCtl = () => !!(mine().length && !auto());
    function layout() {
      const w = cv.w, h = cv.h;
      const ctl = showCtl() ? (h < 620 ? 106 : 118) : 0;
      lay = { w, h, chipY: 4, chipH: 30, mapY: 38, mapH: 34, top: 76, bot: h - ctl, ctl };
      mapKey = '';
      placeButtons();
    }
    cv.onresize = layout;

    /* ----- DOM controls ----- */
    const mk = (cls, html, aria) => { const b = L.h('button', { class: 'ld-b ' + cls, type: 'button', 'aria-label': aria }); b.innerHTML = html; root.appendChild(b); return b; };
    const bL = mk('ld-rl', '<span class="ar">↺</span><span class="sm">왼쪽</span>', '왼쪽으로 기울이기');
    const bR = mk('ld-rr', '<span class="ar">↻</span><span class="sm">오른쪽</span>', '오른쪽으로 기울이기');
    const bT = mk('ld-thr', '<span>추진</span><span class="sm">누르고 있기</span>', '엔진 추진');
    const bA = mk('ld-as', '', '자동 수평 켜고 끄기');
    const bF = mk('ld-ff', '▶▶ 빨리 보기', '빨리 보기');
    const ptrs = new Map();
    let thrPtr = null;
    function syncAssist() { bA.innerHTML = '자동 수평<br>' + (assist ? '켬' : '끔'); bA.classList.toggle('off', !assist); }
    syncAssist();
    function press(btn, kind) {
      btn.addEventListener('pointerdown', (e) => {
        e.preventDefault(); e.stopPropagation();
        try { btn.setPointerCapture(e.pointerId); } catch (er) {}
        ptrs.set(e.pointerId, { k: kind, x0: e.clientX, dx: 0 });
        if (kind === 'T') thrPtr = e.pointerId;
        btn.classList.add('on'); api.buzz(8);
      });
      btn.addEventListener('pointermove', (e) => { const q = ptrs.get(e.pointerId); if (q) q.dx = e.clientX - q.x0; });
      const up = (e) => {
        const q = ptrs.get(e.pointerId);
        if (!q) return;
        ptrs.delete(e.pointerId);
        if (thrPtr === e.pointerId) thrPtr = null;
        if (![...ptrs.values()].some((o) => o.k === kind)) btn.classList.remove('on');
      };
      btn.addEventListener('pointerup', up); btn.addEventListener('pointercancel', up); btn.addEventListener('lostpointercapture', up);
      btn.addEventListener('contextmenu', (e) => e.preventDefault());
    }
    press(bL, 'L'); press(bR, 'R'); press(bT, 'T');
    function toggleAssist() {
      assist = !assist; syncAssist(); api.sfx('click');
      try { localStorage.setItem('lounge.lander.assist', assist ? '1' : '0'); } catch (e) {}
      api.toast(assist ? '자동 수평 켬: 손을 떼면 똑바로 서요' : '자동 수평 끔: 기울기가 그대로 유지돼요');
    }
    bA.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); toggleAssist(); });
    bF.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); ff = ff > 1 ? 1 : 5; api.sfx('click'); btnSig = ''; });
    function placeButtons() {
      if (!lay) return;
      const w = lay.w, y0 = lay.bot, H = lay.ctl;
      const tS = Math.min(100, H - 14), rS = Math.min(66, H - 30);
      const set = (b, x, y, ww, hh) => { b.style.left = Math.round(x) + 'px'; b.style.top = Math.round(y) + 'px'; b.style.width = Math.round(ww) + 'px'; b.style.height = Math.round(hh) + 'px'; };
      set(bL, 10, y0 + (H - rS) / 2 + 4, rS, rS);
      set(bR, 10 + rS + 10, y0 + (H - rS) / 2 + 4, rS, rS);
      set(bT, w - tS - 10, y0 + (H - tS) / 2 + 3, tS, tS);
      const ax = 10 + 2 * rS + 20, aw = Math.max(64, Math.min(96, w - tS - 20 - ax - 8));
      set(bA, ax + (w - tS - 10 - ax - aw) / 2, y0 + (H - 48) / 2 + 4, aw, 48);
      set(bF, w / 2 - 75, (H ? y0 + (H - 46) / 2 : lay.h - 60), 150, 46);
      btnSig = '';
    }
    let btnSig = '';
    function syncButtons() {
      const M = myL();
      const ctl = showCtl() && st && st.ph === 'play';
      const fly = !!(ctl && M && M.e < 0);
      const anyAI = LS.some((Ld, s) => Ld && Ld.e < 0 && !isMine(s));
      const showF = !!(st && st.ph === 'play' && cdT <= 0 && anyAI && (!M || M.e >= 0) && !LS.some((Ld, s) => !Ld && !(remote[s] && remote[s].e >= 0)));
      const sig = (showCtl() ? 1 : 0) + '|' + (fly ? 1 : 0) + '|' + (showF ? 1 : 0) + '|' + ff;
      if (sig === btnSig) return;
      btnSig = sig;
      bL.hidden = bR.hidden = bT.hidden = bA.hidden = !fly;
      bF.hidden = !showF;
      bF.textContent = ff > 1 ? '▶ 보통 속도' : '▶▶ 빨리 보기';
    }
    function fuelRing() {
      const M = myL();
      if (!M || !W) return;
      const f = Math.round(100 * M.fuel / W.fuel);
      if (bT._f === f) return;
      bT._f = f;
      const col = f > 30 ? '#e3ae45' : f > 12 ? '#ff9a3a' : '#ff4a3a';
      bT.style.borderColor = col;
      bT.style.boxShadow = `0 3px 0 #0b0810,0 6px 14px rgba(0,0,0,.5),inset 0 0 0 4px rgba(0,0,0,.25)`;
      bT.style.backgroundImage = `radial-gradient(circle at 50% 30%,rgba(64,53,90,1),rgba(33,26,46,1) 66%,transparent 67%),conic-gradient(${col} ${f * 3.6}deg,rgba(255,255,255,.08) 0)`;
    }

    /* ----- input ----- */
    function myL() { const m = mine()[0]; return m != null ? LS[m] : null; }
    const offKeys = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'level') { if (showCtl()) toggleAssist(); }
      else if (id === 'thrust') { const M = myL(); if (M && M.e < 0) api.buzz(8); }
    }) : null;
    function applyInput() {
      const M = myL();
      if (!M) return;
      if (auto()) { if (!M.ai) aiInit(W, M, 3, (roundSeed(st) ^ (99 + mine()[0] * 31)) >>> 0); return; }
      const I = M.inp;
      if (M.e >= 0 || cdT > 0) { I.th = 0; I.rot = 0; I.tgt = null; return; }
      let th = false, rot = 0, tgt = null;
      for (const q of ptrs.values()) {
        if (q.k === 'T') { th = true; if (Math.abs(q.dx) > 12) tgt = U.clamp((q.dx - Math.sign(q.dx) * 12) / Math.max(50, lay.w * 0.16), -1, 1) * 0.8; }
        else if (q.k === 'L') rot -= 1; else if (q.k === 'R') rot += 1;
      }
      const inp = api.input;
      if (inp && inp.held) { if (inp.held('thrust')) th = true; const ax = inp.axis ? inp.axis('rotL', 'rotR') : 0; if (Math.abs(ax) > 0.15) rot += ax; }
      I.th = th ? 1 : 0; I.rot = U.clamp(rot, -1, 1); I.tgt = rot ? null : tgt; I.lvl = assist;
      if (th && !thrOn && M.fuel > 0) api.buzz(10);
      if (th && M.fuel <= 0 && !thrOn) api.toast('연료가 다 떨어졌어요!');
      thrOn = th;
    }
    function onDown(e) {
      if (!lay || !st) return;
      const p = cv.local(e);
      if (p.y < lay.mapY + lay.mapH + 2) { e.preventDefault(); tapChip(p.y < lay.mapY ? p.x : -1); }
    }
    function tapChip(x) {
      if (!st) return;
      const M = myL();
      if (M && M.e < 0 && st.ph === 'play') return;
      const n = st.n, cw = (lay.w - 8 - (n - 1) * 4) / n;
      let s = x < 0 ? -1 : Math.floor((x - 4) / (cw + 4));
      const can = (i) => !!(LS[i] || remote[i]);
      if (s < 0 || s >= n || !can(s)) {
        const idx = []; for (let i = 0; i < n; i++) if (can(i)) idx.push(i);
        if (idx.length < 2) return;
        s = idx[(idx.indexOf(view) + 1) % idx.length];
      }
      if (s === view) return;
      view = s; myFinT = -9; api.sfx('click');
    }
    cv.cv.addEventListener('pointerdown', onDown);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- effects ----- */
    function burst(x, y, col, n, sp, life, grav, up) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * TAU, v = sp * (0.25 + Math.random());
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v + (up || 0), t: life * (0.6 + Math.random() * 0.6), T: life, c: col, g: grav == null ? 1 : grav, sz: 0.12 + Math.random() * 0.25 });
      }
      if (parts.length > 320) parts.splice(0, parts.length - 320);
    }
    function explode(x, y, me) {
      burst(x, y, '#fff3c0', 26, 9, 0.5, 0.2);
      burst(x, y, '#ff9a3a', 40, 7, 1.0, 0.4, 2);
      burst(x, y, '#ff4a2a', 26, 5, 1.3, 0.6, 1);
      burst(x, y, '#8a8a90', 22, 6, 2.2, 1, 4);   // debris
      for (let i = 0; i < 10; i++) parts.push({ x: x + (Math.random() - 0.5) * 2, y: y + Math.random(), vx: (Math.random() - 0.5) * 2, vy: 1 + Math.random() * 2, t: 2.6, T: 2.6, c: 'smoke', g: -0.05, sz: 1 + Math.random() * 1.2 });
      rings.push({ x, y, t: 0 });
      if (me) { shake = 1; flash = 1; }
    }
    function pop(x, y, text, col, big) { floats.push({ x, y, text, col: col || '#fff3c0', t: 1.8, T: 1.8, big: !!big }); if (floats.length > 10) floats.shift(); }
    function onFinish(Ld, s) {
      const me = isMine(s), viewed = s === view;
      if (Ld.e === 0) {
        if (viewed || me) explode(Ld.x, Ld.y, me || viewed);
        if (me || (viewed && !mine().length)) { api.sfx('thud'); setTimeout(() => api.sfx('lose'), 180); api.buzz([60, 40, 90]); }
      } else if (Ld.e >= 2) {
        if (viewed || me) { burst(Ld.x, Ld.y - FY, 'rgba(220,210,190,.8)', 18, 3, 0.9, 0.1, 0.5); pop(Ld.x, Ld.y + 3, '+' + Ld.pts, Ld.e >= 10 ? PADC[Ld.e - 10] : '#e8e0d0', true); }
        if (me || (viewed && !mine().length)) { api.sfx(Ld.e >= 10 ? 'win' : 'pop'); api.buzz([20, 30, 20]); }
      } else if (me) { api.sfx('lose'); }
      if (me) myFinT = 0;
    }

    /* ----- online ----- */
    function rowOf(s) {
      const Ld = LS[s];
      if (Ld) return [r1(Ld.x), r1(Ld.y), r2(Ld.a), Ld.thr > 0.3 ? 1 : 0, Ld.e, Ld.pts];
      const g = remote[s];
      return g ? [g.x, g.y, g.a, g.t, g.e, g.p] : null;
    }
    function takeRow(s, d) {
      if (!Array.isArray(d) || d.length < 6) return;
      const o = remote[s], v = { x: +d[0] || 0, y: +d[1] || 0, a: +d[2] || 0, t: d[3] ? 1 : 0, e: d[4] | 0, p: Math.max(0, d[5] | 0) };
      if (v.e < -1 || v.e > 15) v.e = -1;
      if (!o || o.x !== v.x || o.y !== v.y || o.e !== v.e) heard[s] = performance.now();
      if (o && o.e < 0 && v.e === 0 && (s === view)) explode(v.x, v.y, false);
      if (o && o.e < 0 && v.e >= 2 && s === view) pop(v.x, v.y + 3, '+' + v.p, '#e8e0d0', true);
      remote[s] = v;
      if (!ghost[s]) ghost[s] = { x: v.x, y: v.y, a: v.a };
    }
    function pollNet() {
      if (!api.online || !key) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) { const s = +k, o = rem[k]; if (s >= 0 && s < st.n && !LS[s] && o && o.k === key) takeRow(s, o.d); }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== key || !Array.isArray(hs.L)) return;
        hs.L.forEach((d, s) => { if (!LS[s] && d) takeRow(s, d); });
      }
    }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      if (pubT > 0) return;
      try {
        if (api.isHost) {
          pubT = 0.1;
          const Lr = []; for (let i = 0; i < st.n; i++) Lr.push(rowOf(i));
          api.net.hostSend({ k: key, L: Lr });
        } else {
          const m = mine()[0], Ld = m != null ? LS[m] : null;
          if (!Ld) return;
          pubT = Ld.e >= 0 ? 0.5 : 0.1;
          api.net.publish({ k: key, d: rowOf(m) });
        }
      } catch (e) {}
    }
    function finishedSeat(s, now, localDone) {
      const Ld = LS[s];
      if (Ld) return Ld.e >= 0 && rt - Ld.ft > 1.3;
      const g = remote[s];
      if (g && g.e >= 0) return true;
      const p = api.players[s];
      if (p && p.ai) return true;   // a guest left mid-round and an AI took over
      return localDone && (!heard[s] || now - heard[s] > 15000);
    }
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'play') {
        if (cdT > 0) return;
        const now = performance.now();
        let localDone = true;
        for (let s = 0; s < st.n; s++) if (LS[s] && (LS[s].e < 0 || rt - LS[s].ft <= 1.3)) localDone = false;
        let all = true;
        for (let s = 0; s < st.n; s++) if (!finishedSeat(s, now, localDone)) all = false;
        if (rt > TLIM + 10) all = true;
        if (!all) { endWait = 0; return; }
        endWait += dt;
        if (endWait < 0.5) return;
        endWait = -1e9;
        const row = [];
        for (let s = 0; s < st.n; s++) { const d = rowOf(s); row.push(d && d[4] >= 0 ? [d[5] | 0, d[4] | 0] : [0, 1]); }
        const last = st.r + 1 >= st.R;
        api.setState(Object.assign({}, st, { sc: (st.sc || []).concat([row]), ph: last ? 'done' : 'sum' }));
      } else if (st.ph === 'sum') {
        sumT += dt;
        if (sumT > 4.2) { sumT = -1e9; api.setState(Object.assign({}, st, { r: st.r + 1, ph: 'play' })); }
      }
    }

    /* ----- main loop ----- */
    function frame(rdt) {
      frameN++;
      rdt = Math.min(rdt, 0.1);
      if (st) ensureRound();
      if (!st || !W) { draw(); return; }
      const dt = rdt * SPD();
      if (st.ph === 'play') {
        if (cdT > 0) {
          cdT -= dt;
          const c = Math.ceil(cdT);
          if (c !== lastCd && c <= 3 && c >= 1) { lastCd = c; api.sfx('tick'); }
          if (cdT <= 0) { api.sfx('whoosh'); if (myL()) api.buzz(30); }
        } else {
          rt += dt;
          applyInput();
          LS.forEach((Ld, s) => {
            if (!Ld || Ld.e >= 0) return;
            const k = !isMine(s) || auto() ? ff : 1;
            Ld.acc = Math.min(Ld.acc + dt * k, 0.5);
            let n = 0;
            while (Ld.acc >= DT && n++ < 200) {
              Ld.acc -= DT;
              if (Ld.ai) aiThink(W, Ld);
              stepL(W, Ld);
              if (Ld.e >= 0) { Ld.ft = rt; onFinish(Ld, s); break; }
            }
          });
        }
      }
      pollNet();
      // ghosts glide toward their latest reported position
      for (const s in remote) {
        const g = ghost[s], v = remote[s];
        if (!g) continue;
        const k = Math.min(1, rdt * 10);
        g.x += (v.x - g.x) * k; g.y += (v.y - g.y) * k; g.a += (v.a - g.a) * k;
      }
      // after my landing/crash, watch someone still flying
      if (myFinT >= 0) {
        myFinT += rdt;
        if (myFinT > 2.6) {
          myFinT = -9;
          for (let s = 0; s < st.n; s++) { if (s === view) continue; const Ld = LS[s]; if ((Ld && Ld.e < 0) || (!Ld && remote[s] && remote[s].e < 0)) { view = s; break; } }
        }
      }
      if (!mine().length && LS[view] && LS[view].e >= 0 && rt - LS[view].ft > 2.6) {
        for (let s = 0; s < st.n; s++) { const Ld = LS[s]; if ((Ld && Ld.e < 0) || (!Ld && remote[s] && remote[s].e < 0)) { view = s; break; } }
      }
      hostFlow(dt);
      publish(rdt);
      // warning beep when about to touch down too fast
      const V = LS[view];
      if (V && V.e < 0 && isMine(view) && cdT <= 0) {
        const alt = V.y - FY - surfBelow(W, V.x, V.y);
        warnT -= rdt;
        if (alt < 14 && (V.vy < -VL || Math.abs(V.vx) > HL) && warnT <= 0) { warnT = 0.4; api.sfx('tick'); }
      }
      for (let i = parts.length - 1; i >= 0; i--) {
        const q = parts[i]; q.t -= rdt;
        if (q.t <= 0) { parts.splice(i, 1); continue; }
        q.vy -= W.g * q.g * rdt * 2; q.x += q.vx * rdt; q.y += q.vy * rdt;
        if (q.c !== 'smoke' && q.y < gAt(W, q.x)) { q.y = gAt(W, q.x); q.vy = Math.abs(q.vy) * 0.3; q.vx *= 0.6; }
        if (q.c === 'smoke') { q.vx *= 0.98; q.sz += rdt * 0.8; }
      }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t += rdt; if (rings[i].t > 0.7) rings.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 2.2); flash = Math.max(0, flash - rdt * 3);
      syncButtons(); fuelRing();
      updCam(rdt);
      draw();
    }

    /* ----- camera ----- */
    function viewPos() {
      const Ld = LS[view];
      if (Ld) return { x: Ld.x, y: Ld.y, a: Ld.a };
      const g = ghost[view];
      return g ? { x: g.x, y: g.y, a: g.a } : { x: W.start.x, y: W.start.y, a: 0 };
    }
    function updCam(rdt) {
      if (!lay || !W) return;
      const vw = lay.w, vh = lay.bot - lay.top - HUDH;
      const sMin = Math.max(vw / 170, vh / 210), sMax = Math.min(vh / 30, vw / 24);
      let tx, ty, ts;
      if (st.ph === 'play' && cdT > 1.0) {
        // overview of the whole field while counting down
        ts = Math.min(vw / (WW + 8), vh / (W.yhi - W.ymin + 40));
        tx = WW / 2; ty = (W.ymin + W.start.y) / 2;
        ts = Math.min(ts, vh / (W.start.y - W.ymin + 16));
        ty = W.ymin - 6 + vh / ts / 2;
      } else {
        const p = viewPos(), alt = Math.max(0, p.y - FY - surfBelow(W, p.x, p.y));
        ts = U.clamp(vh / (alt * 1.7 + 26), sMin, sMax);
        const Hm = vh / ts;
        tx = p.x; ty = p.y - Math.min(alt, Hm * 0.6) * 0.5;
        const Wm = vw / ts;
        tx = U.clamp(tx, Wm / 2 - 4, WW - Wm / 2 + 4);
        if (Wm > WW + 8) tx = WW / 2;
      }
      if (!camInit) { cam.x = tx; cam.y = ty; cam.s = ts; camInit = true; return; }
      const k = Math.min(1, rdt * 3.2), ks = Math.min(1, rdt * 2.2);
      cam.s += (ts - cam.s) * ks;
      cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k;
    }

    /* ----- drawing ----- */
    const sx = (x) => (x - cam.x) * cam.s + lay.w / 2 + shk.x;
    const sy = (y) => (lay.top + HUDH + lay.bot) / 2 - (y - cam.y) * cam.s + shk.y;
    const shk = { x: 0, y: 0 };
    function txt(t, x, y, col, font, al, bl) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = al || 'center'; ctx.textBaseline = bl || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }

    function drawSky() {
      const S = W.S, top = lay.top, bot = lay.bot, w = lay.w;
      const gr = ctx.createLinearGradient(0, top, 0, bot);
      gr.addColorStop(0, S.sky[0]); gr.addColorStop(1, S.sky[1]);
      ctx.fillStyle = gr; ctx.fillRect(0, top, w, bot - top);
      if (S.star) {
        if (!stars) { stars = []; const r = mkRng(77); for (let i = 0; i < 90; i++) stars.push([r(), r(), r()]); }
        const ox = cam.x * cam.s * 0.04, oy = cam.y * cam.s * 0.03;
        for (const q of stars) {
          const x = ((q[0] * w * 1.2 - ox) % w + w) % w, y = top + ((q[1] * (bot - top) * 1.3 + oy) % (bot - top) + (bot - top)) % (bot - top);
          ctx.globalAlpha = 0.3 + q[2] * 0.6 * (0.8 + 0.2 * Math.sin(frameN * 0.03 + q[2] * 20));
          ctx.fillStyle = '#fff'; ctx.fillRect(x, y, q[2] > 0.8 ? 2 : 1.2, q[2] > 0.8 ? 2 : 1.2);
        }
        ctx.globalAlpha = 1;
      }
      if (S.orb) {
        const o = S.orb, x = w * o.x - cam.x * cam.s * 0.02, y = top + (bot - top) * o.y, r = o.r;
        const g2 = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
        g2.addColorStop(0, o.c2); g2.addColorStop(1, o.c);
        ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        ctx.globalAlpha = 0.18; ctx.fillStyle = o.c; ctx.beginPath(); ctx.arc(x, y, r * 1.5, 0, TAU); ctx.fill(); ctx.globalAlpha = 1;
      }
      // far ridge (parallax)
      const base = (top + bot) / 2 + ((W.ymin + 18 - cam.y) * -cam.s) * 0.35, amp = (bot - top) * 0.22;
      ctx.fillStyle = S.far; ctx.beginPath(); ctx.moveTo(0, bot);
      const n = W.far.length, off = cam.x / WW * 0.35;
      for (let px = 0; px <= w + 8; px += 8) { const u = (px / w) * 0.6 + off, f = U.clamp(u * (n - 1), 0, n - 1.001), i = Math.floor(f), t = f - i; ctx.lineTo(px, base - (W.far[i] * (1 - t) + W.far[i + 1] * t) * amp); }
      ctx.lineTo(w, bot); ctx.closePath(); ctx.fill();
    }
    function drawTerrain(t) {
      const S = W.S, top = lay.top, bot = lay.bot;
      const x0 = cam.x - (lay.w / 2 + 20) / cam.s, x1 = cam.x + (lay.w / 2 + 20) / cam.s;
      const i0 = U.clamp(Math.floor(x0 / GDX) - 1, 0, NG - 1), i1 = U.clamp(Math.ceil(x1 / GDX) + 1, 0, NG - 1);
      // slabs (cave roofs) behind the ground; dark cave wall behind the hollow
      for (const s of W.slabs) {
        const a = Math.max(i0, s.i0), b = Math.min(i1, s.i1);
        if (a > b) continue;
        const gk = ctx.createLinearGradient(0, sy(slabAt(s, s.bot, (a + b) / 2 * GDX)), 0, sy(gAt(W, (a + b) / 2 * GDX)));
        gk.addColorStop(0, '#06101c'); gk.addColorStop(1, '#14304a');
        ctx.fillStyle = gk; ctx.beginPath();
        for (let i = a; i <= b; i++) { const X = sx(i * GDX), Y = sy(s.bot[i - s.i0]); if (i === a) ctx.moveTo(X, Y); else ctx.lineTo(X, Y); }
        ctx.lineTo(sx(b * GDX), bot + 10); ctx.lineTo(sx(a * GDX), bot + 10); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(160,220,255,.05)';
        for (let i = a; i < b; i += 3) { const X = sx(i * GDX), Y = sy((s.bot[i - s.i0] + gAt(W, i * GDX)) / 2 + Math.sin(i) * 4); ctx.beginPath(); ctx.arc(X, Y, (1.5 + (i % 5) * 0.6) * cam.s, 0, TAU); ctx.fill(); }
        const gr = ctx.createLinearGradient(0, sy(slabAt(s, s.top, (a + b) / 2 * GDX)), 0, sy(slabAt(s, s.bot, (a + b) / 2 * GDX)));
        gr.addColorStop(0, S.slab[0]); gr.addColorStop(1, S.slab[1]);
        ctx.fillStyle = gr; ctx.beginPath();
        for (let i = a; i <= b; i++) { const X = sx(i * GDX), Y = sy(s.top[i - s.i0]); if (i === a) ctx.moveTo(X, Y); else ctx.lineTo(X, Y); }
        for (let i = b; i >= a; i--) ctx.lineTo(sx(i * GDX), sy(s.bot[i - s.i0]));
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = S.edge; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.8;
        ctx.beginPath(); for (let i = a; i <= b; i++) { const X = sx(i * GDX), Y = sy(s.top[i - s.i0]); if (i === a) ctx.moveTo(X, Y); else ctx.lineTo(X, Y); } ctx.stroke();
        ctx.strokeStyle = 'rgba(200,240,255,.5)';
        ctx.beginPath(); for (let i = a; i <= b; i++) { const X = sx(i * GDX), Y = sy(s.bot[i - s.i0]); if (i === a) ctx.moveTo(X, Y); else ctx.lineTo(X, Y); } ctx.stroke();
        ctx.globalAlpha = 1;
      }
      if (W.icicles && cam.s > 3) {
        ctx.fillStyle = 'rgba(220,245,255,.75)';
        for (const q of W.icicles) {
          if (q[0] < x0 || q[0] > x1) continue;
          const s = W.slabs.find((z) => q[0] >= z.x0 && q[0] <= z.x1); if (!s) continue;
          const yb = slabAt(s, s.bot, q[0]), X = sx(q[0]), Y = sy(yb);
          ctx.beginPath(); ctx.moveTo(X - 0.35 * cam.s, Y - 1); ctx.lineTo(X + 0.35 * cam.s, Y - 1); ctx.lineTo(X, Y + q[1] * cam.s); ctx.closePath(); ctx.fill();
        }
      }
      // ground
      let hiY = 1e9; for (let i = i0; i <= i1; i++) hiY = Math.min(hiY, sy(W.G[i]));
      const gr = ctx.createLinearGradient(0, Math.max(top, hiY), 0, bot + 40);
      gr.addColorStop(0, S.gnd[0]); gr.addColorStop(1, S.gnd[1]);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(sx(i0 * GDX), bot + 10);
      for (let i = i0; i <= i1; i++) ctx.lineTo(sx(i * GDX), sy(W.G[i]));
      ctx.lineTo(sx(i1 * GDX), bot + 10); ctx.closePath(); ctx.fill();
      // strata lines for a crafted look
      ctx.save(); ctx.clip();
      ctx.strokeStyle = 'rgba(0,0,0,.12)'; ctx.lineWidth = 1;
      for (let k = 1; k <= 4; k++) {
        ctx.beginPath();
        for (let i = i0; i <= i1; i++) { const X = sx(i * GDX), Y = sy(W.G[i] - k * 4 - Math.sin(i * 0.7 + k) * 0.8); if (i === i0) ctx.moveTo(X, Y); else ctx.lineTo(X, Y); }
        ctx.stroke();
      }
      ctx.restore();
      ctx.strokeStyle = S.edge; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.beginPath();
      for (let i = i0; i <= i1; i++) { const X = sx(i * GDX), Y = sy(W.G[i]); if (i === i0) ctx.moveTo(X, Y); else ctx.lineTo(X, Y); }
      ctx.stroke();
      // lava lakes: glowing surface + heat haze
      if (S.lava) {
        for (const run of W.lavaRuns) {
          if (run[1] < i0 || run[0] > i1) continue;
          const xa = sx(run[0] * GDX - 1), xb = sx(run[1] * GDX + 1), Y = sy(W.G[run[0]]), gl = 0.8 + 0.2 * Math.sin(t * 2.6 + run[0]);
          const hz = Math.max(18, 5 * cam.s), gh = ctx.createLinearGradient(0, Y - hz, 0, Y);
          gh.addColorStop(0, 'rgba(255,120,30,0)'); gh.addColorStop(1, 'rgba(255,120,30,' + (0.35 * gl).toFixed(2) + ')');
          ctx.fillStyle = gh; ctx.fillRect(xa, Y - hz, xb - xa, hz);
          const dp = Math.max(6, 2.2 * cam.s), gb = ctx.createLinearGradient(0, Y, 0, Y + dp);
          gb.addColorStop(0, 'rgb(255,' + Math.round(170 + 50 * gl) + ',70)'); gb.addColorStop(0.35, '#ff5a14'); gb.addColorStop(1, 'rgba(150,30,8,0)');
          ctx.fillStyle = gb; ctx.fillRect(xa, Y - 1, xb - xa, dp + 1);
          ctx.fillStyle = 'rgba(255,240,180,.8)';
          for (let k = 0; k < 4; k++) { const f = ((t * 0.3 + k * 0.27 + run[0] * 0.13) % 1), px = xa + (xb - xa) * ((k * 0.31 + run[0] * 0.17) % 1); ctx.fillRect(px, Y - 1 - f * 2 * cam.s, 2, 2); }
        }
      }
      // rocks
      if (cam.s > 3.5) {
        ctx.fillStyle = S.gnd[1];
        for (const q of W.rocks) {
          if (q[0] < x0 || q[0] > x1) continue;
          const X = sx(q[0]), Y = sy(gAt(W, q[0])), r = q[1] * cam.s;
          ctx.beginPath(); ctx.ellipse(X, Y, r * 1.3, r, 0, Math.PI, 0); ctx.fill();
          ctx.strokeStyle = S.edge; ctx.globalAlpha = 0.4; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(X, Y, r * 1.3, r, 0, Math.PI * 1.1, Math.PI * 1.6); ctx.stroke(); ctx.globalAlpha = 1;
        }
      }
      // vents: heat column (pulses) + embers
      for (const v of W.vents) {
        if (v.x < x0 - 10 || v.x > x1 + 10) continue;
        const pu = ventPulse(v, rt), X = sx(v.x), Y = sy(gAt(W, v.x)), Hh = 50 * cam.s, Wd = 6 * cam.s;
        ctx.save(); ctx.translate(X, Y - Hh * 0.42); ctx.scale(1, Hh * 0.5 / Wd);
        const gc = ctx.createRadialGradient(0, 0, 0, 0, 0, Wd);
        gc.addColorStop(0, 'rgba(255,130,50,' + (0.06 + 0.26 * pu).toFixed(2) + ')'); gc.addColorStop(1, 'rgba(255,130,50,0)');
        ctx.fillStyle = gc; ctx.beginPath(); ctx.arc(0, 0, Wd, 0, TAU); ctx.fill(); ctx.restore();
        ctx.fillStyle = '#ffd08a';
        for (let k = 0; k < 10; k++) {
          const f = ((rt * (0.25 + pu * 0.6) + k / 10) % 1), yy = Y - f * Hh * 0.9, xx = X + Math.sin(f * 7 + k * 1.7) * Wd * (0.4 + f);
          ctx.globalAlpha = (1 - f) * (0.25 + 0.65 * pu); ctx.fillRect(xx - 1.5, yy - 1.5, 3, 3);
        }
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#2a1410'; ctx.beginPath(); ctx.moveTo(X - 3 * cam.s, Y + 1); ctx.lineTo(X - 1 * cam.s, Y - 1.6 * cam.s); ctx.lineTo(X + 1 * cam.s, Y - 1.6 * cam.s); ctx.lineTo(X + 3 * cam.s, Y + 1); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,150,60,' + (0.4 + 0.6 * pu).toFixed(2) + ')'; ctx.fillRect(X - 1 * cam.s, Y - 1.7 * cam.s, 2 * cam.s, Math.max(2, 0.3 * cam.s));
      }
    }
    function drawPads(t) {
      for (const p of W.pads) {
        const X0 = sx(p.x0), X1 = sx(p.x1), Y = sy(p.y), th = Math.max(3, 0.5 * cam.s), col = PADC[p.m];
        if (X1 < -60 || X0 > lay.w + 60) continue;
        ctx.fillStyle = '#5a5866'; ctx.fillRect(X0, Y - th * 0.2, X1 - X0, th);
        ctx.fillStyle = '#c8c4d0'; ctx.fillRect(X0, Y - th * 0.2, X1 - X0, th * 0.35);
        // hazard stripes
        if (cam.s > 4) { ctx.fillStyle = 'rgba(0,0,0,.35)'; for (let x = X0 + 2; x < X1 - 2; x += 8) ctx.fillRect(x, Y + th * 0.3, 4, th * 0.4); }
        const bl = (Math.sin(t * 5 + p.m) > 0) ? 1 : 0.35;
        ctx.globalAlpha = bl; ctx.fillStyle = col;
        const lr = Math.max(2, 0.35 * cam.s);
        ctx.beginPath(); ctx.arc(X0 + lr, Y - th * 0.2 - lr, lr, 0, TAU); ctx.arc(X1 - lr, Y - th * 0.2 - lr, lr, 0, TAU); ctx.fill();
        ctx.globalAlpha = 1;
        // sign
        const lab = '×' + p.m, fs = U.clamp(cam.s * 1.6, 11, 17), font = '800 ' + fs + 'px ' + MONO;
        ctx.font = font;
        const tw = ctx.measureText(lab).width + 10, bx = (X0 + X1) / 2, by = Y - U.clamp(3.4 * cam.s, 16, 44);
        ctx.fillStyle = 'rgba(14,10,20,.78)'; rr(ctx, bx - tw / 2, by - fs / 2 - 3, tw, fs + 6, 5); ctx.fill();
        ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.stroke();
        txt(lab, bx, by + 0.5, col, font);
      }
    }
    function drawLander(x, y, a, thr, col, alpha, kk, me, t) {
      const X = sx(x), Y = sy(y), k = cam.s * kk;
      ctx.save(); ctx.translate(X, Y); ctx.rotate(a); ctx.scale(k, k); ctx.globalAlpha = alpha;
      // flame
      if (thr > 0.04) {
        const fl = (1.1 + 2.6 * thr) * (0.85 + 0.3 * Math.sin(t * 47 + x) * Math.sin(t * 31));
        const g = ctx.createLinearGradient(0, 1.3, 0, 1.3 + fl);
        g.addColorStop(0, 'rgba(255,255,230,.95)'); g.addColorStop(0.35, 'rgba(255,190,80,.85)'); g.addColorStop(1, 'rgba(255,90,30,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-0.42, 1.3); ctx.quadraticCurveTo(0, 1.3 + fl * 1.2, 0.42, 1.3); ctx.closePath(); ctx.fill();
      }
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      // legs
      ctx.strokeStyle = '#b9b3a6'; ctx.lineWidth = 0.18;
      ctx.beginPath(); ctx.moveTo(-0.95, 0.55); ctx.lineTo(-FX, FY); ctx.moveTo(0.95, 0.55); ctx.lineTo(FX, FY); ctx.moveTo(-1.1, 0.9); ctx.lineTo(-0.55, 0.95); ctx.moveTo(1.1, 0.9); ctx.lineTo(0.55, 0.95); ctx.stroke();
      ctx.strokeStyle = '#e8e2d4'; ctx.lineWidth = 0.22; ctx.beginPath(); ctx.moveTo(-FX - 0.35, FY); ctx.lineTo(-FX + 0.35, FY); ctx.moveTo(FX - 0.35, FY); ctx.lineTo(FX + 0.35, FY); ctx.stroke();
      // engine bell
      ctx.fillStyle = '#4a4650'; ctx.beginPath(); ctx.moveTo(-0.3, 0.9); ctx.lineTo(0.3, 0.9); ctx.lineTo(0.48, 1.35); ctx.lineTo(-0.48, 1.35); ctx.closePath(); ctx.fill();
      // descent stage (gold foil)
      ctx.fillStyle = '#d6a440'; ctx.beginPath(); ctx.moveTo(-1.3, 0.0); ctx.lineTo(1.3, 0.0); ctx.lineTo(1.15, 0.95); ctx.lineTo(-1.15, 0.95); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(120,70,10,.45)'; ctx.fillRect(-1.2, 0.45, 2.4, 0.12);
      // cabin
      ctx.fillStyle = '#ece6d8'; ctx.beginPath(); ctx.moveTo(-1.15, 0.05); ctx.lineTo(-1.2, -0.75); ctx.quadraticCurveTo(-1.0, -1.55, 0, -1.55); ctx.quadraticCurveTo(1.0, -1.55, 1.2, -0.75); ctx.lineTo(1.15, 0.05); ctx.closePath(); ctx.fill();
      ctx.fillStyle = col; ctx.fillRect(-1.18, -0.42, 2.36, 0.32);
      ctx.fillStyle = '#1c2a44'; ctx.beginPath(); ctx.moveTo(-0.55, -0.62); ctx.lineTo(-0.38, -1.15); ctx.lineTo(0.38, -1.15); ctx.lineTo(0.55, -0.62); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(160,210,255,.55)'; ctx.beginPath(); ctx.moveTo(-0.3, -0.75); ctx.lineTo(-0.2, -1.05); ctx.lineTo(0.05, -1.05); ctx.lineTo(-0.1, -0.75); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#8a8478'; ctx.lineWidth = 0.08; ctx.beginPath(); ctx.moveTo(0.5, -1.45); ctx.lineTo(0.75, -2.0); ctx.stroke();
      if (me) { ctx.fillStyle = Math.sin(t * 6) > 0 ? '#ff5a4a' : '#5a1a14'; ctx.beginPath(); ctx.arc(0.75, -2.02, 0.1, 0, TAU); ctx.fill(); }
      ctx.restore();
    }
    function drawTraj(Ld) {
      // short prediction: current throttle and tilt held for 2 s
      let x = Ld.x, y = Ld.y, vx = Ld.vx, vy = Ld.vy;
      const T = W.T * (Ld.thr > 0.5 && Ld.fuel > 0 ? 1 : 0), h = 1 / 30, P = { x: 0, y: 0, vx: 0, vy: 0, t: Ld.t };
      let hit = null;
      ctx.fillStyle = 'rgba(255,255,255,.75)';
      for (let k = 1; k <= 60; k++) {
        P.x = x; P.y = y; P.vx = vx; P.vy = vy; P.t = Ld.t + k * h;
        extAcc(W, P, EA2);
        vx += (T * Math.sin(Ld.a) + EA2.ax) * h; vy += (T * Math.cos(Ld.a) - W.g + EA2.ay) * h;
        x += vx * h; y += vy * h;
        if (solidAt(W, x, y - FY)) { hit = { x, y: y - FY, ok: vy >= -VL && Math.abs(vx) <= HL }; break; }
        if (k % 6 === 0) { ctx.globalAlpha = 0.75 * (1 - k / 66); ctx.beginPath(); ctx.arc(sx(x), sy(y - FY * 0.5), 2.2, 0, TAU); ctx.fill(); }
      }
      ctx.globalAlpha = 1;
      if (hit) {
        const X = sx(hit.x), Y = sy(hit.y), c = hit.ok ? '#7dff9a' : '#ff5a4a';
        ctx.strokeStyle = c; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(X - 6, Y - 6); ctx.lineTo(X + 6, Y + 6); ctx.moveTo(X + 6, Y - 6); ctx.lineTo(X - 6, Y + 6); ctx.stroke();
      }
    }
    function drawParts() {
      for (const g of rings) {
        const X = sx(g.x), Y = sy(g.y), k = g.t / 0.7, R = (1 + k * 9) * cam.s;
        const gg = ctx.createRadialGradient(X, Y, 0, X, Y, R);
        gg.addColorStop(0, 'rgba(255,240,200,' + (0.9 * (1 - k)).toFixed(2) + ')'); gg.addColorStop(0.5, 'rgba(255,140,40,' + (0.5 * (1 - k)).toFixed(2) + ')'); gg.addColorStop(1, 'rgba(255,80,20,0)');
        ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(X, Y, R, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,230,190,' + (0.6 * (1 - k)).toFixed(2) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X, Y, R * 1.2, 0, TAU); ctx.stroke();
      }
      for (const q of parts) {
        const a = Math.max(0, q.t / q.T), X = sx(q.x), Y = sy(q.y);
        if (q.c === 'smoke') { ctx.globalAlpha = a * 0.2; ctx.fillStyle = '#5a5258'; ctx.beginPath(); ctx.arc(X, Y, q.sz * cam.s, 0, TAU); ctx.fill(); continue; }
        ctx.globalAlpha = Math.min(1, a * 1.4); ctx.fillStyle = q.c;
        const z = Math.max(1.5, q.sz * cam.s);
        ctx.fillRect(X - z / 2, Y - z / 2, z, z);
      }
      ctx.globalAlpha = 1;
    }
    function drawFloats() {
      for (const f of floats) {
        const k = 1 - f.t / f.T, X = sx(f.x), Y = sy(f.y) - k * 30;
        ctx.globalAlpha = Math.min(1, f.t / f.T * 2.5);
        const font = '800 ' + (f.big ? 22 : 15) + 'px ' + DISP;
        ctx.font = font; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,6,14,.85)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.strokeText(f.text, X, Y); txt(f.text, X, Y, f.col, font);
      }
      ctx.globalAlpha = 1;
    }
    function drawWorld(t) {
      ctx.save();
      ctx.beginPath(); ctx.rect(0, lay.top, lay.w, lay.bot - lay.top); ctx.clip();
      shk.x = shake > 0 ? (Math.random() - 0.5) * 14 * shake : 0; shk.y = shake > 0 ? (Math.random() - 0.5) * 14 * shake : 0;
      drawSky();
      drawTerrain(t);
      drawPads(t);
      const kk = U.clamp(20 / (3.4 * cam.s), 1, 2.8);
      // others first (ghosts), then the viewed lander on top
      for (let s = 0; s < st.n; s++) {
        if (s === view) continue;
        const Ld = LS[s], g = ghost[s], rm = remote[s];
        let x, y, a, th, e;
        if (Ld) { x = Ld.x; y = Ld.y; a = Ld.a; th = Ld.thr; e = Ld.e; }
        else if (g && rm) { x = g.x; y = g.y; a = g.a; th = rm.t; e = rm.e; }
        else continue;
        if (e === 0 || e === 1 && !Ld) continue;
        if (e === 1) continue;
        drawLander(x, y, a, th, Pl(s).color, 0.42, kk, false, t);
        if (cam.s > 3) { const font = '600 11px ' + FONT; txt(fitText(name(s), 80, font), sx(x), sy(y + 2.6 * kk) - 4, 'rgba(242,233,216,.7)', font); }
      }
      const V = LS[view], vg = ghost[view], vr = remote[view];
      if (V && V.e < 0 && isMine(view) && cdT <= 0) drawTraj(V);
      if (V && V.e !== 0 && V.e !== 1) drawLander(V.x, V.y, V.a, V.thr, Pl(view).color, 1, kk, isMine(view), t);
      else if (!V && vg && vr && vr.e !== 0 && vr.e !== 1) drawLander(vg.x, vg.y, vg.a, vr.t, Pl(view).color, 1, kk, false, t);
      // touchdown dust while thrusting near the ground
      if (V && V.e < 0 && V.thr > 0.3) {
        const alt = V.y - FY - surfBelow(W, V.x, V.y);
        if (alt < 9 && Math.random() < V.thr * 0.6) { const gx = V.x + (Math.random() - 0.5) * 2, gy = surfBelow(W, gx, V.y); parts.push({ x: gx, y: gy + 0.2, vx: (Math.random() < 0.5 ? -1 : 1) * (2 + Math.random() * 4), vy: 0.3 + Math.random(), t: 0.8, T: 0.8, c: 'rgba(210,200,180,.7)', g: 0.05, sz: 0.25 }); }
      }
      drawParts();
      drawFloats();
      if (W.S.fog) {
        const p = viewPos(), X = sx(p.x), Y = sy(p.y), r0 = Math.max(50, 14 * cam.s), r1 = Math.max(150, 42 * cam.s);
        const g = ctx.createRadialGradient(X, Y, r0, X, Y, r1);
        g.addColorStop(0, 'rgba(184,162,116,0)'); g.addColorStop(1, 'rgba(184,162,116,.82)');
        ctx.fillStyle = g; ctx.fillRect(0, lay.top, lay.w, lay.bot - lay.top);
      }
      if (W.S.dust && W.wind) {
        const wv = windAt(W, rt, 30);
        ctx.strokeStyle = 'rgba(255,220,180,.22)'; ctx.lineWidth = 1;
        for (let k = 0; k < 18; k++) {
          const yy = lay.top + ((k * 53.7) % (lay.bot - lay.top)), xx = ((k * 97.3 + rt * wv * 30) % (lay.w + 40) + lay.w + 40) % (lay.w + 40) - 20;
          ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx - Math.sign(wv) * (8 + Math.abs(wv) * 2), yy); ctx.stroke();
        }
      }
      if (flash > 0) { ctx.fillStyle = 'rgba(255,230,190,' + (flash * 0.45).toFixed(2) + ')'; ctx.fillRect(0, lay.top, lay.w, lay.bot - lay.top); }
      // off-screen pad arrows
      const used = [[], []];
      if (!(st.ph === 'play' && cdT > 1)) for (const p of W.pads.slice().sort((a, b) => b.y - a.y)) {
        const cx = sx((p.x0 + p.x1) / 2);
        if (cx > -4 && cx < lay.w + 4) continue;
        const left = cx < 0, X = left ? 14 : lay.w - 14, col = PADC[p.m];
        let Y = U.clamp(sy(p.y), lay.top + HUDH + 92, lay.bot - 20);
        const u = used[left ? 0 : 1];
        for (let k = 0; k < 4; k++) for (const q of u) if (Math.abs(q - Y) < 26) Y = q + 26;
        if (Y > lay.bot - 14) Y = lay.bot - 14 - 26 * u.length;
        u.push(Y);
        ctx.fillStyle = 'rgba(14,10,20,.7)'; rr(ctx, X - 13, Y - 11, 26, 22, 6); ctx.fill();
        ctx.fillStyle = col; ctx.beginPath();
        if (left) { ctx.moveTo(X - 11, Y); ctx.lineTo(X - 5, Y - 5); ctx.lineTo(X - 5, Y + 5); } else { ctx.moveTo(X + 11, Y); ctx.lineTo(X + 5, Y - 5); ctx.lineTo(X + 5, Y + 5); }
        ctx.fill();
        txt('×' + p.m, X + (left ? 3 : -3), Y + 0.5, col, '700 10px ' + MONO);
      }
      ctx.restore();
    }

    function drawChips() {
      const n = st.n, w = lay.w, cw = (w - 8 - (n - 1) * 4) / n, y = lay.chipY, h = lay.chipH;
      const tot = totals(st);
      for (let s = 0; s < n; s++) {
        const x = 4 + s * (cw + 4), Ld = LS[s], rm = remote[s];
        const e = Ld ? Ld.e : rm ? rm.e : -1, p = Ld ? Ld.pts : rm ? rm.p : 0;
        const done = st.ph !== 'play' || (st.sc && st.sc.length > st.r);
        const sc = tot[s] + (!done && e >= 2 ? p : 0);
        ctx.fillStyle = s === view ? 'rgba(227,174,69,.2)' : 'rgba(34,28,46,.9)';
        rr(ctx, x, y, cw, h, 8); ctx.fill();
        ctx.strokeStyle = s === view ? '#e3ae45' : 'rgba(255,255,255,.08)'; ctx.lineWidth = s === view ? 1.5 : 1; ctx.stroke();
        ctx.fillStyle = Pl(s).color; ctx.beginPath(); ctx.arc(x + 9, y + h / 2, 4.5, 0, TAU); ctx.fill();
        let ic = '', ic2 = '#ab9fb8';
        if (st.ph === 'play' && !done) {
          if (e < 0) { ic = '•'; ic2 = Math.sin(performance.now() / 160) > 0 ? '#f2e9d8' : '#6a5f78'; } else if (e === 0) { ic = '✕'; ic2 = '#ff6a55'; } else if (e === 1) { ic = '—'; } else { ic = '✓'; ic2 = e >= 10 ? PADC[e - 10] : '#d8d0c0'; }
        }
        const right = x + cw - 6, scW = 0;
        const scT = fmt(sc), font = '700 12px ' + MONO;
        ctx.font = font; const sw = ctx.measureText(scT).width;
        txt(scT, right - (ic ? 13 : 0), y + h / 2 + 0.5, '#f2e9d8', font, 'right');
        if (ic) txt(ic, right, y + h / 2 + 0.5, ic2, '700 11px ' + FONT, 'right');
        const nmW = cw - 18 - sw - (ic ? 16 : 0) - 6 - scW;
        if (nmW > 14) txt(fitText(name(s), nmW, '600 11px ' + FONT), x + 16, y + h / 2 + 0.5, isMine(s) ? '#ffe7b0' : '#d8cfe0', '600 11px ' + FONT, 'left');
      }
    }
    function drawMap() {
      const x = 4, y = lay.mapY, w = lay.w - 8, h = lay.mapH;
      const k = W.seed + '.' + w + '.' + (cv.dpr || 1);
      if (mapKey !== k) {
        mapKey = k;
        const d = Math.min(2.5, cv.dpr || 1);
        mapC = document.createElement('canvas'); mapC.width = Math.ceil(w * d); mapC.height = Math.ceil(h * d);
        const g = mapC.getContext('2d'); g.scale(d, d);
        g.fillStyle = 'rgba(14,10,20,.85)'; rr(g, 0, 0, w, h, 8); g.fill();
        const y0 = W.ymin - 3, y1 = W.yTop, mx = (X) => 6 + X / WW * (w - 12), my = (Y) => h - 3 - (Y - y0) / (y1 - y0) * (h - 6);
        g.save(); rr(g, 0, 0, w, h, 8); g.clip();
        for (const s of W.slabs) { g.fillStyle = W.S.slab[1]; g.beginPath(); for (let i = s.i0; i <= s.i1; i++) g.lineTo(mx(i * GDX), my(s.top[i - s.i0])); for (let i = s.i1; i >= s.i0; i--) g.lineTo(mx(i * GDX), my(s.bot[i - s.i0])); g.closePath(); g.fill(); }
        g.fillStyle = W.S.gnd[1]; g.strokeStyle = W.S.edge; g.lineWidth = 1;
        g.beginPath(); g.moveTo(mx(0), h); for (let i = 0; i < NG; i++) g.lineTo(mx(i * GDX), my(W.G[i])); g.lineTo(mx(WW), h); g.closePath(); g.fill();
        g.beginPath(); for (let i = 0; i < NG; i++) g.lineTo(mx(i * GDX), my(W.G[i])); g.stroke();
        if (W.S.lava) { g.fillStyle = '#ff6a1a'; for (let i = 0; i < NG; i++) if (W.lava[i]) g.fillRect(mx(i * GDX) - 1, my(W.G[i]) - 1, 3, 2); }
        for (const p of W.pads) { g.fillStyle = PADC[p.m]; g.fillRect(mx(p.x0), my(p.y) - 2, Math.max(3, mx(p.x1) - mx(p.x0)), 3); }
        g.restore();
        g.strokeStyle = 'rgba(227,174,69,.35)'; g.lineWidth = 1; rr(g, 0.5, 0.5, w - 1, h - 1, 8); g.stroke();
        mapC._mx = mx; mapC._my = my;
      }
      ctx.drawImage(mapC, x, y, w, h);
      const mx = mapC._mx, my = mapC._my;
      for (let s = 0; s < st.n; s++) {
        const Ld = LS[s], g = ghost[s], rm = remote[s];
        let px, py, e;
        if (Ld) { px = Ld.x; py = Ld.y; e = Ld.e; } else if (g && rm) { px = g.x; py = g.y; e = rm.e; } else continue;
        if (e === 0 || e === 1) continue;
        ctx.fillStyle = Pl(s).color; ctx.strokeStyle = '#0e0a14'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(x + mx(px), y + U.clamp(my(py), 3, h - 3), s === view ? 3.6 : 2.6, 0, TAU); ctx.fill(); ctx.stroke();
      }
      // view window
      const vx0 = cam.x - lay.w / 2 / cam.s, vx1 = cam.x + lay.w / 2 / cam.s;
      ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1;
      ctx.strokeRect(x + mx(Math.max(0, vx0)), y + 1.5, Math.max(4, mx(Math.min(WW, vx1)) - mx(Math.max(0, vx0))), h - 3);
      // round label
      const lab = (st.r + 1) + '/' + st.R + ' ' + W.S.n, font = '700 11px ' + FONT;
      ctx.font = font; const lw = ctx.measureText(lab).width + 12;
      ctx.fillStyle = 'rgba(14,10,20,.72)'; rr(ctx, x + 4, y + 3, lw, 16, 6); ctx.fill();
      txt(lab, x + 10, y + 11.5, '#e3ae45', font, 'left');
    }
    function gauge(x, y, w, label, val, txtv, lim) {
      const a = Math.abs(val), col = a <= lim * 0.7 ? '#7dde8a' : a <= lim ? '#ffc84a' : '#ff5a4a';
      txt(label, x, y, '#ab9fb8', '600 11px ' + FONT, 'left');
      txt(txtv, x + 25, y, col, '700 12px ' + MONO, 'left');
      const bx = x + 70, bw = Math.max(16, w - 74);
      ctx.fillStyle = 'rgba(255,255,255,.1)'; rr(ctx, bx, y - 3.5, bw, 7, 3.5); ctx.fill();
      ctx.fillStyle = col; rr(ctx, bx, y - 3.5, Math.max(4, bw * Math.min(1, a / (lim * 1.6))), 7, 3.5); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.fillRect(bx + bw / 1.6 - 0.75, y - 5.5, 1.5, 11);
    }
    function drawHud() {
      const V = LS[view];
      if (!V || st.ph !== 'play') return;
      const x = 4, y = lay.top + 3, w = lay.w - 8, h = HUDH - 6, c = (w - 12) / 3;
      ctx.fillStyle = 'rgba(14,10,20,.72)'; rr(ctx, x, y, w, h, 9); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.28)'; ctx.lineWidth = 1; ctx.stroke();
      const alt = Math.max(0, V.y - FY - surfBelow(W, V.x, V.y));
      const live = V.e < 0;
      const vy = live ? V.vy : V.tvy, vx = live ? V.vx : V.tvx;
      const y1 = y + 11.5, y2 = y + h - 11, x0 = x + 7;
      txt('고도', x0, y1, '#ab9fb8', '600 11px ' + FONT, 'left');
      txt(alt < 100 ? alt.toFixed(1) + 'm' : Math.round(alt) + 'm', x0 + 25, y1, '#f2e9d8', '700 12px ' + MONO, 'left');
      gauge(x0 + c + 3, y1, c, '수직', vy < 0 ? vy : 0, (vy < 0 ? '↓' : '↑') + Math.abs(vy).toFixed(1), VL);
      gauge(x0 + 2 * c + 6, y1, c, '수평', vx, (vx < 0 ? '←' : '→') + Math.abs(vx).toFixed(1), HL);
      gauge(x0, y2, c, '각도', V.a, Math.round(Math.abs(V.a) * DEG) + '°', AL);
      const f = V.fuel / W.fuel, fc = f > 0.3 ? '#e3ae45' : f > 0.12 ? '#ff9a3a' : '#ff4a3a';
      const fx = x0 + c + 3, fw = 2 * c - 40;
      txt('연료', fx, y2, '#ab9fb8', '600 11px ' + FONT, 'left');
      ctx.fillStyle = 'rgba(255,255,255,.1)'; rr(ctx, fx + 27, y2 - 4, fw - 27, 8, 4); ctx.fill();
      ctx.fillStyle = fc; rr(ctx, fx + 27, y2 - 4, Math.max(4, (fw - 27) * f), 8, 4); ctx.fill();
      txt(Math.round(f * 100) + '%', x + w - 7, y2, fc, '700 12px ' + MONO, 'right');
      // wind / updraft / time
      let rx = lay.w - 6, ry = lay.top + HUDH + 4;
      const chip = (t2, col) => { const font = '700 12px ' + FONT; ctx.font = font; const tw = ctx.measureText(t2).width + 16; ctx.fillStyle = 'rgba(14,10,20,.66)'; rr(ctx, rx - tw, ry, tw, 24, 8); ctx.fill(); txt(t2, rx - tw / 2, ry + 12.5, col, font); ry += 28; };
      if (cdT > 0) return;
      if (W.wind) { const wv = windAt(W, V.t, alt); chip('바람 ' + (wv < 0 ? '←' : '→') + ' ' + Math.abs(wv).toFixed(1), '#ffd0a0'); }
      if (W.vents.length) { const up = ventAt(W, V.x, alt, V.t); if (up > 0.3) chip('열기둥 ↑', '#ffb070'); }
      const left = TLIM - V.t;
      if (live && left < 20) chip('남은 시간 ' + Math.ceil(left) + '초', '#ff8a6a');
      if (live && V.fuel <= 0) chip('연료 없음!', '#ff5a4a');
    }
    function drawCountdown() {
      if (st.ph !== 'play' || cdT <= 0) return;
      const w = lay.w, cy = lay.top + (lay.bot - lay.top) * 0.42;
      const S = W.S, solo = st.n === 1;
      const lines = [S.sub, S.tip];
      if (st.r === 0 && showCtl()) {
        if (fine) {
          const b = (api.input && api.input.bindings) ? api.input.bindings() : [];
          const kn = (id) => { const o = b.find((q) => q.id === id); return o && o.keys && o.keys[0] ? keyName(o.keys[0]) : '?'; };
          lines.push('조작: ' + kn('thrust') + ' 추진 · ' + kn('rotL') + ' ' + kn('rotR') + ' 기울이기');
        } else lines.push('조작: 오른쪽 「추진」 누르고 있기 · 왼쪽 ↺↻ 기울이기');
      }
      if (solo) lines.push('★ 안전 착륙 · ★★ 패드 · ★★★ 패드 320점 이상');
      const font = '500 12px ' + FONT, bw = Math.min(w - 24, 340);
      const wrapped = [];
      for (const l of lines) {
        ctx.font = font;
        if (ctx.measureText(l).width <= bw - 24) { wrapped.push(l); continue; }
        const words = l.split(' '); let cur = '';
        for (const wd of words) { const t2 = cur ? cur + ' ' + wd : wd; if (ctx.measureText(t2).width > bw - 24 && cur) { wrapped.push(cur); cur = wd; } else cur = t2; }
        if (cur) wrapped.push(cur);
      }
      const bh = 70 + wrapped.length * 18, bx = (w - bw) / 2, by = cy - bh / 2 - 30;
      ctx.fillStyle = 'rgba(14,10,20,.82)'; rr(ctx, bx, by, bw, bh, 14); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
      txt((st.r + 1) + ' / ' + st.R + '판', w / 2, by + 16, '#e3ae45', '700 12px ' + FONT);
      txt(S.n, w / 2, by + 40, '#f2e9d8', '400 24px ' + DISP);
      wrapped.forEach((l, i) => txt(l, w / 2, by + 66 + i * 18, i === 0 ? '#ffd9a0' : '#d8cfe0', font));
      const c = Math.ceil(cdT);
      if (c <= 3) {
        const f = cdT - Math.floor(cdT), sc = 1 + f * 0.4;
        ctx.save(); ctx.globalAlpha = Math.min(1, 0.4 + f); ctx.translate(w / 2, by + bh + 42); ctx.scale(sc, sc);
        ctx.font = '400 46px ' + DISP; ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(10,6,14,.85)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.strokeText(String(c), 0, 0); ctx.fillStyle = '#ffe7b0'; ctx.fillText(String(c), 0, 0);
        ctx.restore();
      }
    }
    function resultText(e, p) { return e >= 10 ? '×' + (e - 10) + ' 착륙 +' + p : e === 2 ? '패드 밖 착륙 +' + p : e === 0 ? '추락' : '실패'; }
    function drawMyResult() {
      const s = mine()[0] != null ? mine()[0] : view, Ld = LS[s];
      if (!Ld || Ld.e < 0 || st.ph !== 'play' || view !== s) return;
      const w = lay.w, bw = Math.min(w - 32, 300), bx = (w - bw) / 2, by = lay.top + HUDH + (lay.bot - lay.top - HUDH) * 0.1;
      const good = Ld.e >= 2, bh = Ld.bd ? 104 : 70;
      ctx.fillStyle = 'rgba(14,10,20,.84)'; rr(ctx, bx, by, bw, bh, 14); ctx.fill();
      ctx.strokeStyle = good ? (Ld.e >= 10 ? PADC[Ld.e - 10] : '#d8d0c0') : '#ff6a55'; ctx.lineWidth = 2; ctx.stroke();
      txt(Ld.e === 0 ? '추락!' : Ld.e === 1 ? Ld.why : good ? (Ld.e >= 10 ? '착륙 성공!' : '안전 착륙') : '', w / 2, by + 22, good ? '#ffe7b0' : '#ff8a70', '400 22px ' + DISP);
      txt(Ld.e === 0 ? Ld.why + ' · 0점' : Ld.e === 1 ? '0점' : Ld.why + '  +' + Ld.pts + '점', w / 2, by + 48, '#d8cfe0', '600 12px ' + FONT);
      if (Ld.bd) {
        const lab = ['패드', '부드러움', '가운데', '연료'];
        const cw = (bw - 16) / 4;
        Ld.bd.forEach((v, i) => { txt(lab[i], bx + 8 + cw * (i + 0.5), by + 72, '#ab9fb8', '600 10px ' + FONT); txt('+' + v, bx + 8 + cw * (i + 0.5), by + 89, '#f2e9d8', '700 13px ' + MONO); });
      }
      if (st.n === 1) {
        const k = starsOf(Ld.e, Ld.pts);
        txt('★'.repeat(k) + '☆'.repeat(3 - k), w / 2, by + bh + 18, '#ffd34d', '400 24px ' + DISP);
      } else if (rt - Ld.ft > 1.2) txt('다른 사람을 기다려요… (위 점수판을 눌러 구경)', w / 2, by + bh + 16, 'rgba(242,233,216,.75)', '600 11px ' + FONT);
    }
    function drawSummary() {
      if (st.ph !== 'sum' || !st.sc || !st.sc[st.r]) return;
      const row = st.sc[st.r], tot = totals(st), n = st.n, w = lay.w;
      const order = row.map((c, i) => [i, c]).sort((a, b) => b[1][0] - a[1][0] || a[0] - b[0]);
      const bw = Math.min(w - 24, 340), bh = 58 + n * 30 + 26, bx = (w - bw) / 2, by = lay.top + Math.max(10, (lay.bot - lay.top - bh) * 0.35);
      ctx.fillStyle = 'rgba(14,10,20,.9)'; rr(ctx, bx, by, bw, bh, 14); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.stroke();
      txt((st.r + 1) + '판 결과 · ' + W.S.n, w / 2, by + 24, '#f2e9d8', '400 19px ' + DISP);
      order.forEach((o, k) => {
        const s = o[0], c = o[1], y = by + 56 + k * 30;
        ctx.fillStyle = Pl(s).color; ctx.beginPath(); ctx.arc(bx + 18, y, 5, 0, TAU); ctx.fill();
        txt(fitText(name(s), bw * 0.3, '600 13px ' + FONT), bx + 30, y + 0.5, isMine(s) ? '#ffe7b0' : '#f2e9d8', '600 13px ' + FONT, 'left');
        const col = c[1] >= 10 ? PADC[c[1] - 10] : c[1] === 2 ? '#d8d0c0' : '#ff7a65';
        txt(n === 1 ? '★'.repeat(starsOf(c[1], c[0])) + '☆'.repeat(3 - starsOf(c[1], c[0])) + ' ' + resultText(c[1], c[0]) : resultText(c[1], c[0]), bx + bw * 0.42, y + 0.5, col, '600 12px ' + FONT, 'left');
        txt(fmt(tot[s]), bx + bw - 12, y + 0.5, '#e3ae45', '700 13px ' + MONO, 'right');
      });
      const nx = W && st.sg[st.r + 1] != null ? STAGES[st.sg[st.r + 1]].n : '';
      txt('다음: ' + nx + ' ' + '·'.repeat(1 + (Math.floor(frameN / 20) % 3)), w / 2, by + bh - 16, '#ab9fb8', '600 11px ' + FONT);
    }
    function drawPanel() {
      if (!lay.ctl) return;
      const y = lay.bot, h = lay.ctl, w = lay.w;
      const g = ctx.createLinearGradient(0, y, 0, y + h);
      g.addColorStop(0, '#241c30'); g.addColorStop(1, '#15101c');
      ctx.fillStyle = g; ctx.fillRect(0, y, w, h);
      ctx.fillStyle = 'rgba(227,174,69,.55)'; ctx.fillRect(0, y, w, 1.5);
      const M = myL();
      if (st.ph === 'play' && M && M.e >= 0 && bF.hidden) txt(M.e >= 2 ? '착륙 완료 · 다른 사람을 기다려요' : '다음 판에 다시 도전!', w / 2, y + h / 2, '#ab9fb8', '600 13px ' + FONT);
      else if (st.ph !== 'play') txt(st.ph === 'sum' ? '다음 판 준비 중…' : '끝!', w / 2, y + h / 2, '#ab9fb8', '600 13px ' + FONT);
    }
    function draw() {
      const w = cv.w, h = cv.h, t = performance.now() / 1000;
      ctx.fillStyle = '#120e18'; ctx.fillRect(0, 0, w, h);
      if (!st || !lay || !W) { if (lay) txt('준비 중…', w / 2, h / 2, '#ab9fb8', '600 14px ' + FONT); return; }
      drawWorld(t);
      drawChips();
      drawMap();
      drawHud();
      drawCountdown();
      drawMyResult();
      drawSummary();
      drawPanel();
      const M = myL();
      if (M && M.e < 0 && st.ph === 'play' && cdT <= 0 && st.r === 0 && rt < 7 && !auto()) {
        const msg = '추진을 톡톡 눌러 내려가는 속도를 줄여요 · 막대가 초록이면 안전', font = '600 12px ' + FONT;
        const tw = Math.min(lay.w - 16, (ctx.font = font, ctx.measureText(msg).width) + 24), y = lay.bot - 24;
        ctx.globalAlpha = Math.min(1, (7 - rt) * 1.5); ctx.fillStyle = 'rgba(16,12,22,.85)'; rr(ctx, (lay.w - tw) / 2, y - 14, tw, 28, 14); ctx.fill();
        ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1; ctx.stroke();
        txt(fitText(msg, tw - 16, font), lay.w / 2, y, '#f2e9d8', font); ctx.globalAlpha = 1;
      }
      if (!LS[view] && !ghost[view] && st.ph === 'play') {
        txt(name(view) + ' 님은 자기 폰에서 날고 있어요', w / 2, lay.top + HUDH + 30, '#d8cfe0', '600 12px ' + FONT);
      } else if (!isMine(view) && st.ph === 'play' && cdT <= 0 && !(mine().length && myL() && myL().e < 0)) {
        txt('관전 중: ' + name(view) + ' · 점수판을 눌러 바꾸기', 8, lay.top + HUDH + 14, 'rgba(242,233,216,.85)', '600 11px ' + FONT, 'left');
      }
    }

    const stop = U.loop(frame);
    layout();
    root._ld = { W: () => W, LS: () => LS, view: () => view, cam: () => cam, lay: () => lay, cd: () => cdT, rt: () => rt };   // test hook
    return {
      update(state) {
        const prevPh = st && st.ph;
        st = state;
        if (!st) return;
        if (st.ph === 'sum' && prevPh !== 'sum') { sumT = 0; api.sfx('chip'); }
        btnSig = '';
      },
      destroy() {
        stop();
        if (offKeys) try { offKeys(); } catch (e) {}
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('contextmenu', noCtx);
        [bL, bR, bT, bA, bF].forEach((b) => b.remove());
        cv.destroy(); styleEl.remove();
      },
    };
  }

  L.register({
    id: 'lander', name: '로켓 착륙', tag: '실시간 착륙 점수 대결', cat: '아케이드',
    blurb: '모두 같은 땅 위로 동시에 내려가요! 추진과 기울이기로 속도를 줄여 패드에 사뿐히. 작고 먼 패드일수록 점수가 커요. 행성 6곳.',
    tint: '#1d3a5e',
    icon: '<path d="M28 6c6 4 8 10 8 16v8H20v-8c0-6 2-12 8-16z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="28" cy="18" r="3" fill="currentColor"/><path d="M20 30l-6 9M36 30l6 9" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M24 33l4 8 4-8" fill="currentColor"/><path d="M4 50h48" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M20 46h16" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'stage', label: '행성', choices: [{ v: -1, label: '매 판 무작위' }].concat(STAGES.map((S, i) => ({ v: i, label: S.n }))), def: -1 },
      { id: 'rounds', label: '판 수', choices: [{ v: 3, label: '3판' }, { v: 4, label: '4판' }, { v: 5, label: '5판' }], def: 4 },
    ],
    controls: [
      { id: 'thrust', label: '추진 (누르고 있기)', keys: ['Space', 'ArrowUp', 'KeyW'], pad: ['a', 'rt', 'up'] },
      { id: 'rotL', label: '왼쪽으로 기울이기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'rotR', label: '오른쪽으로 기울이기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'level', label: '자동 수평 켜기/끄기', keys: ['KeyE'], pad: ['y'] },
    ],
    quick: [
      '모두 같은 땅 위로 동시에 내려가요. 착륙 패드에 사뿐히 내리면 점수! 부서지면 그 판은 0점.',
      '「추진」을 누르고 있으면 엔진이 위로 밀어요. ↺↻로 기울이면 그쪽으로 움직여요.',
      '작고 먼 패드일수록 점수가 커요(×1~×5). 여러 판 점수를 더해 가장 높으면 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '판마다 다른 행성에 착륙선을 내려요. 모두 같은 땅, 같은 출발 위치에서 동시에 출발해요(다른 사람 착륙선은 반투명, 부딪히지 않아요).',
        '패드(평평한 금속판)에 사뿐히 내리면 점수. 너무 빠르거나 기울어서 닿으면 부서지고 그 판은 0점.',
        '정해진 판(기본 4판)을 다 하면 점수를 모두 더해 가장 높은 사람이 승리!',
      ] },
      { h: '조작', p: [
        '추진: 오른쪽 큰 「추진」 버튼을 누르고 있는 동안 엔진이 켜져요. 착륙선이 향한 쪽(위)으로 밀어 줘요.',
        '기울이기: 왼쪽 ↺ ↻ 버튼. 오른쪽으로 기울이고 추진하면 오른쪽으로 가요. 추진 버튼을 누른 채 좌우로 밀어도 기울어요(한 손 조작).',
        '자동 수평(기본 켬): 기울이기 버튼에서 손을 떼면 저절로 똑바로 서요. 끄면 기울기가 그대로 유지돼요.',
        'PC: 스페이스·↑·W = 추진, ←·A / →·D = 기울이기, E = 자동 수평. 「⌨ 조작 설정」에서 키·게임패드를 바꿔요.',
      ] },
      { h: '착륙 조건 (왼쪽 위 계기판)', p: [
        '수직 속도 3.0 이하, 수평 속도 1.6 이하, 기울기 12° 이하로 땅에 닿아야 해요.',
        '계기판 막대가 초록이면 안전, 노랑은 아슬아슬, 빨강이면 그대로 닿으면 부서져요. 흰 눈금이 한계예요.',
        '앞으로 2초 동안 갈 길이 점으로 보여요. 땅에 닿는 곳의 ✕가 초록이면 이대로 안전, 빨강이면 위험해요.',
        '연료가 떨어지면 엔진이 꺼져요. 120초 안에 착륙하지 못해도 0점이에요.',
      ] },
      { h: '점수', p: [
        '패드 점수 = 100 × 배수(×1·×2·×3·×5). 넓고 가까운 패드는 ×1, 좁고 멀거나 어려운 곳일수록 ×5.',
        '보너스: 부드러움(최대 50) + 가운데 착륙(최대 50) + 남은 연료(최대 100).',
        '패드 밖 평평한 곳에 무사히 내리면 30점. 추락·시간 초과는 0점.',
      ] },
      { h: '행성 6곳', p: [
        '달 크레이터: 중력이 약하고 바람이 없어요. 연습에 좋아요.',
        '화성 바람 협곡: 중력이 세고 옆바람이 불어요. ×5는 좁은 협곡 바닥.',
        '얼음 위성 동굴: 얼음 천장 아래 동굴. 천장 구멍으로 들어가 안쪽 패드를 노려요.',
        '소행성 바위밭: 중력이 아주 약해요. 한번 움직이면 잘 안 멈춰요. 높은 패드는 뾰족 바위 위.',
        '안개 위성: 공기가 짙어 천천히 떨어지지만 안개로 앞이 잘 안 보여요(위 지도를 보세요).',
        '화산 행성: 용암에 닿으면 끝. 분화구의 열기둥이 주기적으로 위로 밀어 올려요.',
        '설정 「행성」에서 매 판 무작위(판마다 다른 행성) 또는 한 행성만 고를 수 있어요. 땅 모양은 판마다 새로 만들어져요.',
      ] },
      { h: '예시', p: [
        '출발! 옆으로 흘러가는 속도가 있어요 → 반대쪽으로 살짝 기울이고 추진해 멈춰요.',
        '→ ×3 패드 위까지 기울여 이동 → 똑바로 세우고(자동 수평) 추진을 톡톡 눌러 수직 속도를 초록으로.',
        '→ 수직 1.2로 패드 가운데에 사뿐 = 300 + 부드러움 30 + 가운데 45 + 연료 40 = 415점!',
      ] },
      { h: '혼자 하기 (미션)', p: [
        '혼자 하면 판마다 별을 받아요: ★ 무사히 착륙, ★★ 패드에 착륙, ★★★ 패드에서 320점 이상.',
        '모든 판의 별을 모으는 게 목표예요. 별 개수와 총점은 결과 화면에 나와요.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 조종해요. 나머지 자리는 AI 비행사예요. 친구와는 온라인·LAN 방으로 각자 폰에서 함께 날아요.',
        '위 점수판에 모두의 상태(▲ 비행 중, ✓ 착륙, ✕ 추락)와 점수가 보여요. 내가 끝나면 점수판을 눌러 다른 사람을 구경해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 쉬운 패드를 고르고 가끔 부서지고, 어려움은 높은 패드를 연료를 아껴 노려요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { STAGES, genWorld, newLander, stepL, aiInit, aiThink, runAI, gridOf, planPath, solidAt, surfBelow, gAt, starsOf, totals, init, result, VL, HL, AL, DT, WW },
  });
})();
