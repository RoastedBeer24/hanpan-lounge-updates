/* 구슬치기 — 2~4인 턴제 구슬 튕기기. 흙마당 위 유리구슬, 놀이 3가지(구멍 넣기 · 삼각 따먹기 · 맞히기).
   결정적 고정 스텝 물리: 미끄러짐→구름(굴림 마찰·흙 저항), 같은 질량 유리구슬 충돌(따라가기·멈춤이 저절로 생김),
   구멍 가장자리 비탈과 '빠지는 속도' 판정. apply가 끝까지 시뮬레이션하고 last={id,pre,shot}을 남기며 뷰는 같은 Sim으로 재생한다.
   단위: 마당 위 cm. x = 가로(0..W), y = 세로(0 = 먼 쪽, H = 내 쪽). 출발선은 아래쪽. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }

  /* ---------- yard ---------- */
  const W = 36, H = 58, R = 1.0, LINE_Y = 51, LSY = 53.2, XMIN = R + 0.6, XMAX = W - R - 0.6;
  const HOLES = [[18, 40], [7, 26], [18, 12], [29, 26]], ROUTE = [0, 1, 2, 3, 0], RH = 1.5, RF = 2.8;
  const HOLE_NM = ['①', '②', '③', '④'];
  const TRI_C = [18, 19], TRI_S = 20, RACK_SP = 3.3;
  const TRI = [[TRI_C[0], TRI_C[1] - TRI_S / Math.sqrt(3)], [TRI_C[0] - TRI_S / 2, TRI_C[1] + TRI_S / (2 * Math.sqrt(3))], [TRI_C[0] + TRI_S / 2, TRI_C[1] + TRI_S / (2 * Math.sqrt(3))]];
  const DT = 1 / 240, VMAX = 146, MAXT = 14, VSTOP = 0.9;
  const MU = 260, AROLL = 52, DAMP = 0.55, SLOPE = 26, BOWL = 150, CAPK = 12.5, E_MM = 0.93, E_ST = 0.5;
  const ROUNDS = { h: 30, t: 30, c: 10 };
  const MODES = { hole: 'h', tri: 't', hit: 'c' }, MODE_NM = { h: '구멍 넣기', t: '삼각 따먹기', c: '맞히기' };
  const r2 = (v) => Math.round(v * 100) / 100, r4 = (v) => Math.round(v * 10000) / 10000;

  function triDist(px, py) {   // 0 inside, else distance to the triangle
    let inside = true, best = 1e9;
    for (let k = 0; k < 3; k++) {
      const a = TRI[k], b = TRI[(k + 1) % 3], c = TRI[(k + 2) % 3];
      const ex = b[0] - a[0], ey = b[1] - a[1];
      const side = (ex * (py - a[1]) - ey * (px - a[0])), sideC = (ex * (c[1] - a[1]) - ey * (c[0] - a[0]));
      if (side * sideC < 0) inside = false;
      let t = ((px - a[0]) * ex + (py - a[1]) * ey) / (ex * ex + ey * ey); if (t < 0) t = 0; else if (t > 1) t = 1;
      const qx = a[0] + ex * t - px, qy = a[1] + ey * t - py, d = Math.sqrt(qx * qx + qy * qy);
      if (d < best) best = d;
    }
    return inside ? 0 : best;
  }

  /* ---------- deterministic simulation (+ − × ÷ √ only) ---------- */
  // bodies 0..n-1 = players' shooters, n.. = pot marbles (삼각). env = {md, sn}
  function Sim(env, pre, shot) {
    const n = pre.m.length, K = pre.p ? pre.p.length : 0, NB = n + K;
    this.n = n; this.NB = NB; this.md = env.md; this.sn = env.sn || [];
    this.x = new Float64Array(NB); this.y = new Float64Array(NB); this.vx = new Float64Array(NB); this.vy = new Float64Array(NB);
    this.rx = new Float64Array(NB); this.ry = new Float64Array(NB);
    this.on = new Int8Array(NB); this.hl = new Int8Array(NB).fill(-1); this.ig = new Int8Array(NB).fill(-1); this.inH = new Int8Array(NB).fill(-1);
    this.gone = new Int8Array(NB); this.ex = new Float64Array(NB); this.ey = new Float64Array(NB);
    this.present = new Int8Array(NB);
    for (let i = 0; i < n; i++) {
      const q = pre.m[i], hk = pre.h ? pre.h[i] : -1;
      if (i === shot.i) {
        this.present[i] = 1; this.on[i] = 1;
        if (q) { this.x[i] = +q[0]; this.y[i] = +q[1]; } else { this.x[i] = +shot.x; this.y[i] = LSY; }
        if (hk >= 0) { this.ig[i] = hk; this.inH[i] = hk; }
      } else if (q) {
        this.present[i] = 1; this.x[i] = +q[0]; this.y[i] = +q[1];
        if (hk >= 0) this.hl[i] = hk; else this.on[i] = 1;
      }
    }
    for (let k = 0; k < K; k++) { const i = n + k; this.present[i] = 1; this.on[i] = 1; this.x[i] = +pre.p[k][0]; this.y[i] = +pre.p[k][1]; }
    this.si = shot.i; this.vx[shot.i] = +shot.vx; this.vy[shot.i] = +shot.vy;
    this.hits = 0;      // bitmask of bodies the shooter touched directly
    this.caps = [];     // [body, hole] captures in order
    this.clinks = 0; this.clinkV = 0; this.drops = 0; this.lips = 0; this.stoneHits = 0; this.outs = 0;
    this.steps = 0; this.done = false;
  }
  Sim.prototype.step = function () {
    const x = this.x, y = this.y, vx = this.vx, vy = this.vy, rx = this.rx, ry = this.ry, on = this.on, NB = this.NB;
    const holes = this.md === 'h';
    for (let i = 0; i < NB; i++) {
      if (!on[i]) continue;
      let sx = vx[i], sy = vy[i], qx = rx[i], qy = ry[i];
      if (sx === 0 && sy === 0 && qx === 0 && qy === 0) continue;
      if (holes) {   // dirt slopes down around each hole, steeper inside the cup
        for (let k = 0; k < 4; k++) {
          const dx = HOLES[k][0] - x[i], dy = HOLES[k][1] - y[i], d2 = dx * dx + dy * dy;
          if (d2 >= RF * RF || d2 < 1e-8) continue;
          const d = Math.sqrt(d2), a = (d < RH ? BOWL : SLOPE * (RF - d) / (RF - RH)) * DT / d;
          sx += dx * a; sy += dy * a; qx += dx * a; qy += dy * a;
        }
      }
      const ux = sx - qx, uy = sy - qy, u2 = ux * ux + uy * uy;
      if (u2 > 0.25) {   // sliding: friction slows the slip and spins the marble up until it rolls (v → (5v + 2·roll)/7)
        const u = Math.sqrt(u2), f = MU * DT;
        if (f * 3.5 >= u) { const ax = (5 * sx + 2 * qx) / 7, ay = (5 * sy + 2 * qy) / 7; sx = ax; sy = ay; qx = ax; qy = ay; }
        else { const nx = ux / u, ny = uy / u; sx -= nx * f; sy -= ny * f; qx += nx * f * 2.5; qy += ny * f * 2.5; }
        if (sx * sx + sy * sy < VSTOP * VSTOP && qx * qx + qy * qy < VSTOP * VSTOP) { sx = sy = qx = qy = 0; }
      } else {          // rolling: dirt resistance + a little damping
        const v = Math.sqrt(sx * sx + sy * sy);
        const ns = (v - AROLL * DT) * (1 - DAMP * DT);
        if (ns < VSTOP) { sx = sy = qx = qy = 0; } else { const k = ns / v; sx *= k; sy *= k; qx = sx; qy = sy; }
      }
      vx[i] = sx; vy[i] = sy; rx[i] = qx; ry[i] = qy;
      x[i] += sx * DT; y[i] += sy * DT;
      if (holes) {
        for (let k = 0; k < 4; k++) {
          const dx = HOLES[k][0] - x[i], dy = HOLES[k][1] - y[i], d2 = dx * dx + dy * dy;
          if (d2 < RH * RH) {
            if (this.ig[i] === k || this.inH[i] === k) continue;
            this.inH[i] = k;
            // falls in if it can't jump the gap: v < (chord − r)·√(g / 2r)
            const v = Math.sqrt(sx * sx + sy * sy);
            let off = 0;
            if (v > 1e-6) { off = (dx * sy - dy * sx) / v; if (off < 0) off = -off; }
            const ch = off < RH ? 2 * Math.sqrt(RH * RH - off * off) : 0, vcap = ch > R ? (ch - R) * CAPK : 0;
            if (v < vcap) { this.capture(i, k); break; }
            vx[i] *= 0.82; vy[i] *= 0.82; rx[i] *= 0.82; ry[i] *= 0.82; this.lips++;
          } else {
            if (this.inH[i] === k) this.inH[i] = -1;
            if (this.ig[i] === k) this.ig[i] = -1;
          }
        }
        if (!on[i]) continue;
      }
      if (x[i] < 0 || x[i] > W || y[i] < 0 || y[i] > H) {
        this.ex[i] = x[i]; this.ey[i] = y[i]; this.gone[i] = 1; on[i] = 0; this.outs++;
        vx[i] = vy[i] = rx[i] = ry[i] = 0;
      }
    }
    // marble–marble: rewind to contact, equal-mass impulse on the velocity (spin stays → follow/stop happen by friction)
    const D = 2 * R, D2 = D * D;
    for (let i = 0; i < NB - 1; i++) {
      if (!on[i]) continue;
      for (let j = i + 1; j < NB; j++) {
        if (!on[j]) continue;
        if (vx[i] === 0 && vy[i] === 0 && vx[j] === 0 && vy[j] === 0) continue;
        let dx = x[j] - x[i], dy = y[j] - y[i];
        if (dx > D || dx < -D || dy > D || dy < -D) continue;
        const d2 = dx * dx + dy * dy;
        if (d2 >= D2) continue;
        const wx = vx[j] - vx[i], wy = vy[j] - vy[i], dw = dx * wx + dy * wy;
        if (dw < 0) {
          const ww = wx * wx + wy * wy;
          let tau = 0;
          if (ww > 1e-12) { const disc = dw * dw - ww * (d2 - D2); tau = (Math.sqrt(disc > 0 ? disc : 0) + dw) / ww; if (tau > DT) tau = DT; if (tau < 0) tau = 0; }
          x[i] -= vx[i] * tau; y[i] -= vy[i] * tau; x[j] -= vx[j] * tau; y[j] -= vy[j] * tau;
          dx = x[j] - x[i]; dy = y[j] - y[i];
          let l = Math.sqrt(dx * dx + dy * dy); if (l < 1e-9) l = 1e-9;
          const nx = dx / l, ny = dy / l, rel = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny;
          if (rel > 0) {
            const jm = rel * (1 + E_MM) / 2;
            vx[i] -= jm * nx; vy[i] -= jm * ny; vx[j] += jm * nx; vy[j] += jm * ny;
            this.clinks++; if (rel > this.clinkV) this.clinkV = rel;
            if (i === this.si) this.hits |= 1 << j; else if (j === this.si) this.hits |= 1 << i;
          }
          x[i] += vx[i] * tau; y[i] += vy[i] * tau; x[j] += vx[j] * tau; y[j] += vy[j] * tau;
        }
        dx = x[j] - x[i]; dy = y[j] - y[i];
        const e2 = dx * dx + dy * dy;
        if (e2 < D2) {
          const l = Math.sqrt(e2);
          if (l > 1e-9) { const p = (D - l) / 2 + 1e-6, nx = dx / l, ny = dy / l; x[i] -= nx * p; y[i] -= ny * p; x[j] += nx * p; y[j] += ny * p; }
        }
      }
    }
    // stones (맞히기): heavy, fixed
    const sn = this.sn;
    if (sn.length) {
      for (let i = 0; i < NB; i++) {
        if (!on[i]) continue;
        for (let k = 0; k < sn.length; k++) {
          const s = sn[k], rr = R + s[2], ex = x[i] - s[0], ey = y[i] - s[1], d2 = ex * ex + ey * ey;
          if (d2 >= rr * rr || d2 < 1e-12) continue;
          const d = Math.sqrt(d2), nx = ex / d, ny = ey / d, vn = vx[i] * nx + vy[i] * ny;
          if (vn < 0) {
            const tx = vx[i] - vn * nx, ty = vy[i] - vn * ny;
            vx[i] = tx * 0.9 - E_ST * vn * nx; vy[i] = ty * 0.9 - E_ST * vn * ny;
            if (-vn > 8) this.stoneHits++;
          }
          x[i] = s[0] + nx * rr; y[i] = s[1] + ny * rr;
        }
      }
    }
    this.steps++;
    let still = true;
    for (let i = 0; i < NB; i++) if (on[i] && (vx[i] !== 0 || vy[i] !== 0 || rx[i] !== 0 || ry[i] !== 0)) { still = false; break; }
    if (still || this.steps > MAXT / DT) {
      for (let i = 0; i < NB; i++) { vx[i] = vy[i] = rx[i] = ry[i] = 0; }
      if (holes) {   // anything resting in a cup falls in
        for (let i = 0; i < NB; i++) {
          if (!on[i]) continue;
          for (let k = 0; k < 4; k++) {
            const dx = HOLES[k][0] - x[i], dy = HOLES[k][1] - y[i];
            if (dx * dx + dy * dy < RH * RH) { this.capture(i, k); break; }
          }
        }
      }
      this.done = true;
    }
  };
  Sim.prototype.capture = function (i, k) {
    this.x[i] = HOLES[k][0]; this.y[i] = HOLES[k][1];
    this.vx[i] = this.vy[i] = this.rx[i] = this.ry[i] = 0;
    this.on[i] = 0; this.hl[i] = k; this.ig[i] = -1; this.inH[i] = -1;
    this.caps.push([i, k]); this.drops++;
  };
  Sim.prototype.run = function () { while (!this.done) this.step(); return this; };
  function simulate(env, pre, shot) { return new Sim(env, pre, shot).run(); }

  /* straight roll on open dirt: distance for each power (AI + aim preview) */
  let RT = null;
  function rollDist(p) {
    let s = p * VMAX, q = 0, d = 0;
    for (let n = 0; n < MAXT / DT; n++) {
      const u = s - q;
      if (u > 0.5) { const f = MU * DT; if (f * 3.5 >= u) { s = q = (5 * s + 2 * q) / 7; } else { s -= f; q += f * 2.5; } }
      else { const ns = (s - AROLL * DT) * (1 - DAMP * DT); if (ns < VSTOP) break; s = q = ns; }
      d += s * DT;
    }
    return d;
  }
  function table() {
    if (RT) return RT;
    RT = [];
    for (let i = 0; i <= 100; i++) RT.push(rollDist(i / 100));
    return RT;
  }
  function distFor(p) { const t = table(), f = U.clamp(p, 0, 1) * 100, i = Math.min(99, Math.floor(f)); return t[i] + (t[i + 1] - t[i]) * (f - i); }
  function powerFor(d) {
    const t = table();
    if (d <= 0) return 0.02;
    for (let i = 1; i <= 100; i++) if (t[i] >= d) return (i - 1 + (d - t[i - 1]) / (t[i] - t[i - 1] || 1)) / 100;
    return 1;
  }

  /* ---------- state ---------- */
  function rack(cnt) {
    const rows = cnt <= 10 ? 4 : 5, sp = RACK_SP, rh = sp * Math.sqrt(3) / 2, out = [];
    const apexY = TRI_C[1] - (rows - 1) * rh * 2 / 3;
    for (let r = 0; r < rows; r++) for (let c = 0; c <= r; c++) out.push([r2(TRI_C[0] + (c - r / 2) * sp), r2(apexY + r * rh)]);
    return out;
  }
  function makeStones() {
    const out = [];
    for (let tries = 0; out.length < 3 && tries < 200; tries++) {
      const rad = r2(1.4 + Math.random() * 0.9), x = r2(5 + Math.random() * (W - 10)), y = r2(9 + Math.random() * 32);
      if (out.some((s) => Math.hypot(s[0] - x, s[1] - y) < s[2] + rad + 7)) continue;
      out.push([x, y, rad]);
    }
    return out;
  }
  function init(players, opts) {
    const o = opts || {}, n = U.clamp(players.length | 0, 2, 4), md = MODES[o.mode] || 'h';
    const f = U.rand(n);
    const s = { md, n, nm: players.slice(0, n).map((p) => String(p.name || '').slice(0, 10)), m: Array(n).fill(null),
      lx: Array.from({ length: n }, (_, i) => r2(W * (i + 1) / (n + 1))), o: Array(n).fill(0), g: Array(n).fill(md === 'c' ? 5 : 0),
      t: f, f, x: 0, rd: 1, ag: o.aim === 0 || o.aim === 'off' ? 0 : 1, ph: 'p', seq: 0, last: null };
    if (md === 'h') { s.h = Array(n).fill(-1); s.pg = Array(n).fill(0); }
    if (md === 't') s.p = rack(n <= 2 ? 10 : 15);
    if (md === 'c') s.sn = makeStones();
    return s;
  }
  const alive = (s) => { const a = []; for (let i = 0; i < s.n; i++) if (!s.o[i]) a.push(i); return a; };
  function actor(s) { return s.ph === 'p' ? s.t : null; }
  const ord = (s, i) => (i - s.f + s.n) % s.n;
  function freeSpot(s, x, y, skip, extra, ok) {
    const occ = [];
    for (let i = 0; i < s.n; i++) if (i !== skip && s.m[i] && !(s.h && s.h[i] >= 0)) occ.push([s.m[i][0], s.m[i][1], R]);
    if (s.p) for (const q of s.p) occ.push([q[0], q[1], R]);
    if (s.sn) for (const q of s.sn) occ.push(q);
    if (s.md === 'h') for (const q of HOLES) occ.push([q[0], q[1], RH + 0.4]);
    if (extra) for (const q of extra) occ.push(q);
    for (let c = 0; c < 12; c++) {
      const cnt = c === 0 ? 1 : c * 8;
      for (let k = 0; k < cnt; k++) {
        const a = k / cnt * Math.PI * 2, px = x + Math.cos(a) * c * 1.15, py = y + Math.sin(a) * c * 1.15;
        if (px < R + 0.3 || px > W - R - 0.3 || py < R + 0.3 || py > H - R - 0.3) continue;
        if (ok && !ok(px, py)) continue;
        if (occ.every((q) => (q[0] - px) * (q[0] - px) + (q[1] - py) * (q[1] - py) >= (R + q[2] + 0.06) * (R + q[2] + 0.06))) return [r2(px), r2(py)];
      }
    }
    return [r2(U.clamp(x, R + 0.3, W - R - 0.3)), r2(U.clamp(y, R + 0.3, H - R - 0.3))];
  }
  function lineX(s, i, x) {   // a free spot on the start line near x
    let px = U.clamp(+x, XMIN, XMAX);
    const occ = [];
    for (let j = 0; j < s.n; j++) if (j !== i && s.m[j] && !(s.h && s.h[j] >= 0)) occ.push(s.m[j]);
    if (s.p) for (const q of s.p) occ.push(q);
    for (let c = 0; c < 30; c++) {
      for (const sg of c ? [1, -1] : [1]) {
        const tx = px + sg * c * 0.7;
        if (tx < XMIN || tx > XMAX) continue;
        if (occ.every((q) => (q[0] - tx) * (q[0] - tx) + (q[1] - LSY) * (q[1] - LSY) >= 4 * R * R + 0.1)) return r2(tx);
      }
    }
    return r2(px);
  }
  const preOf = (s) => ({ m: s.m.map((q) => (q ? q.slice() : null)), h: s.h ? s.h.slice() : undefined, p: s.p ? s.p.map((q) => q.slice()) : undefined });
  const envOf = (s) => ({ md: s.md, sn: s.sn });

  function apply(s, seat, a) {
    if (s.ph !== 'p' || s.t !== seat) throw new Error('not your turn');
    if (!a || a.type !== 'shot') throw new Error('bad action');
    const ang = +a.a, pw = +a.p;
    if (!isFinite(ang) || !isFinite(pw) || pw <= 0) throw new Error('bad shot');
    const i = seat, v = U.clamp(pw, 0.02, 1) * VMAX;
    const pre = preOf(s), shot = { i, vx: r4(Math.cos(ang) * v), vy: r4(Math.sin(ang) * v) };
    if (!s.m[i]) { shot.x = lineX(s, i, isFinite(+a.x) ? +a.x : s.lx[i]); s.lx[i] = shot.x; }
    const sm = simulate(envOf(s), pre, shot);
    s.seq++;
    const n = s.n, msg = [];
    let extra = false, big = '';
    // positions back into the state
    const outs = [];
    for (let b = 0; b < n; b++) {
      if (!sm.present[b]) continue;
      if (sm.gone[b]) { outs.push(b); continue; }
      s.m[b] = [r2(sm.x[b]), r2(sm.y[b])];
      if (s.h) s.h[b] = sm.hl[b];
    }
    let potGone = 0;
    if (s.p) {
      const pot = [];
      for (let k = 0; k < s.p.length; k++) { const b = n + k; if (sm.gone[b]) potGone++; else pot.push([r2(sm.x[b]), r2(sm.y[b])]); }
      s.p = pot;
    }
    for (const b of outs) {   // went off the yard: put back just inside where it left
      s.m[b] = null; if (s.h) s.h[b] = -1;
      s.m[b] = freeSpot(s, U.clamp(sm.ex[b], R + 0.4, W - R - 0.4), U.clamp(sm.ey[b], R + 0.4, H - R - 0.4), b);
    }
    const hitList = [];
    for (let b = 0; b < n; b++) if (b !== i && (sm.hits >> b) & 1 && !s.o[b]) hitList.push(b);
    if (s.md === 'h') {
      const dok = s.pg[i] >= 5;
      let sank = false;
      for (const [b, k] of sm.caps) {
        if (b >= n || s.o[b] || s.pg[b] >= 5 || ROUTE[s.pg[b]] !== k) continue;
        s.pg[b]++;
        if (b === i) { sank = true; msg.push(HOLE_NM[k] + ' 구멍 쏙!'); if (s.pg[i] >= 5) big = '독구슬!'; }
        else msg.push(s.nm[b] + ' 구슬이 ' + HOLE_NM[k] + '에 들어감');
      }
      const killed = [];
      if (dok) for (const b of hitList) { s.o[b] = 1; s.m[b] = null; s.h[b] = -1; s.g[i]++; killed.push(b); }
      if (killed.length) { big = '잡았다!'; msg.push(killed.map((b) => s.nm[b]).join('·') + ' 잡힘'); }
      if (outs.includes(i)) msg.push('밖으로 나감');
      extra = sank || killed.length > 0;
    } else if (s.md === 't') {
      let took = potGone;
      const keep = [];
      for (const q of s.p) { if (triDist(q[0], q[1]) >= R) took++; else keep.push(q); }
      s.p = keep; s.g[i] += took;
      let pen = false;
      if (s.m[i] && triDist(s.m[i][0], s.m[i][1]) === 0) {
        pen = true; s.m[i] = null;
        if (s.g[i] > 0) { s.g[i]--; s.p.push(freeSpot(s, TRI_C[0], TRI_C[1], -1, null, (px, py) => triDist(px, py) === 0)); msg.push('삼각형 안에 멈춤 · 1개 반납'); }
        else msg.push('삼각형 안에 멈춤 · 출발선으로');
      }
      if (took) msg.unshift(took + '개 땄어요');
      big = pen ? (s.g[i] < 0 ? '' : '벌칙!') : took ? '+' + took : '';
      extra = took > 0 && !pen && s.p.length > 0;
    } else {
      let got = 0;
      for (const b of hitList) {
        if (s.g[b] <= 0) continue;
        s.g[b]--; s.g[i]++; got++;
        if (s.g[b] === 0) { s.o[b] = 1; s.m[b] = null; msg.push(s.nm[b] + ' 구슬 다 잃음'); }
      }
      if (got) { msg.unshift('맞혔다! +' + got); big = '맞혔다!'; }
      else if (outs.includes(i)) msg.push('밖으로 나감');
      extra = got > 0 && s.x < 2;
    }
    if (extra) msg.push('한 번 더');
    s.last = { id: s.seq, s: i, pre, shot, msg: msg.join(' · ').slice(0, 70), big };
    // end?
    const al = alive(s);
    if ((s.md !== 't' && al.length <= 1) || (s.md === 't' && s.p.length === 0)) { s.ph = 'e'; return s; }
    if (extra && !s.o[i]) { s.x++; return s; }
    s.x = 0;
    let nx = i;
    for (let k = 1; k <= n; k++) { const c = (i + k) % n; if (!s.o[c]) { nx = c; break; } }
    if (ord(s, nx) <= ord(s, i)) s.rd++;
    s.t = nx;
    if (s.rd > ROUNDS[s.md]) s.ph = 'e';
    return s;
  }
  function score(s, i) {
    if (s.md === 'h') return (s.o[i] ? -1000 : 0) + s.pg[i] * 100 + s.g[i];
    return s.g[i];
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    let best = -1e9;
    for (let i = 0; i < s.n; i++) best = Math.max(best, score(s, i));
    const winners = [];
    for (let i = 0; i < s.n; i++) if (score(s, i) === best) winners.push(i);
    const lines = [];
    for (let i = 0; i < s.n; i++) {
      if (s.md === 'h') lines.push(s.nm[i] + ': ' + (s.o[i] ? '잡힘' : s.pg[i] >= 5 ? '독구슬' : '구멍 ' + s.pg[i] + '/5') + (s.g[i] ? ' · ' + s.g[i] + '명 잡음' : ''));
      else lines.push(s.nm[i] + ': 구슬 ' + s.g[i] + '개');
    }
    const cap = s.rd > ROUNDS[s.md] ? ' (' + ROUNDS[s.md] + '라운드 끝)' : '';
    return { winners, title: winners.length > 1 ? '공동 우승' : undefined, text: MODE_NM[s.md] + cap + '\n' + lines.join('\n') };
  }

  /* ---------- AI ---------- */
  const LVA = { 1: { n: 22, a: 0.075, p: 0.14, ms: 70, pick: 0.35 }, 2: { n: 70, a: 0.04, p: 0.08, ms: 150, pick: 0 }, 3: { n: 180, a: 0.022, p: 0.045, ms: 260, pick: 0 } };
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 0.5;
  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  function posOf(s, i) { return s.m[i] ? s.m[i] : null; }
  function evalState(s2, t) {
    let v0 = 0;
    if (s2.md !== 'h' && s2.last && s2.last.s === t && /밖으로/.test(s2.last.msg)) v0 = -6;
    if (s2.ph === 'e') {
      const r = result(s2);
      if (r && r.winners.includes(t)) return 1e5;
    }
    if (s2.o[t]) return -1e5;
    const me = posOf(s2, t), mine = s2.ph === 'p' && s2.t === t;
    let v = v0;
    if (s2.md === 'h') {
      v += s2.pg[t] * 100 + s2.g[t] * 160 + (mine ? 25 : 0);
      for (let j = 0; j < s2.n; j++) if (j !== t && !s2.o[j]) v -= s2.pg[j] * 12;
      if (s2.pg[t] < 5) {
        const T = HOLES[ROUTE[s2.pg[t]]], P = me || [s2.lx[t], LSY];
        v -= dist(P, T) * 2.2;
        if (me && s2.h[t] < 0) for (let j = 0; j < s2.n; j++) {
          if (j === t || s2.o[j] || s2.pg[j] < 5 || !s2.m[j]) continue;
          const d = dist(me, s2.m[j]); v -= Math.max(0, 26 - d) * 1.6;
        }
      } else {
        let nd = 60;
        for (let j = 0; j < s2.n; j++) if (j !== t && !s2.o[j] && s2.m[j] && s2.h[j] < 0) nd = Math.min(nd, dist(me || [s2.lx[t], LSY], s2.m[j]));
        v -= nd * (mine ? 1.2 : 0.5);
      }
    } else if (s2.md === 't') {
      v += s2.g[t] * 30 + (mine ? 14 : 0);
      for (let j = 0; j < s2.n; j++) if (j !== t) v -= s2.g[j] * 6;
      if (me && s2.p.length) {
        let nd = 99; for (const q of s2.p) nd = Math.min(nd, dist(me, q));
        v += Math.max(0, 14 - nd) * 0.5;
      } else if (!me) v -= 3;
    } else {
      v += s2.g[t] * 30 + (mine ? 16 : 0);
      for (let j = 0; j < s2.n; j++) if (j !== t) v -= s2.g[j] * 8;
      if (me) for (let j = 0; j < s2.n; j++) {
        if (j === t || s2.o[j] || !s2.m[j]) continue;
        const d = dist(me, s2.m[j]);
        v += mine ? Math.max(0, 20 - d) * 0.3 : -Math.max(0, 30 - d) * 0.7;
      }
    }
    return v;
  }
  function candidates(s, t, lv) {
    const out = [], me = s.m[t];
    const from = (xs) => (me ? [[me[0], me[1], null]] : xs.map((x) => { const lx = U.clamp(x, XMIN, XMAX); return [lx, LSY, lx]; }));
    const push = (S, T, extraD, das) => {
      const d = dist(S, T), ang = Math.atan2(T[1] - S[1], T[0] - S[0]);
      for (const da of das) for (const e of extraD) out.push({ x: S[2], a: ang + da, p: U.clamp(powerFor(d + e), 0.03, 1) });
    };
    if (s.md === 'h') {
      if (s.pg[t] < 5) {
        const T = HOLES[ROUTE[s.pg[t]]];
        const das = lv >= 3 ? [0, 0.012, -0.012, 0.025, -0.025] : [0, 0.015, -0.015];
        for (const S of from([T[0], T[0] - 4, T[0] + 4])) push(S, T, [0.6, 1.5, 2.6, 4, 6], das);
      } else {
        for (let j = 0; j < s.n; j++) {
          if (j === t || s.o[j] || !s.m[j] || s.h[j] >= 0) continue;
          for (const S of from([s.m[j][0], s.m[j][0] - 5, s.m[j][0] + 5])) {
            const d = dist(S, s.m[j]);
            push(S, s.m[j], [3, 10, 22], [0, R * 0.5 / Math.max(d, 1), -R * 0.5 / Math.max(d, 1)]);
          }
        }
      }
    } else if (s.md === 't') {
      for (const P of s.p) {
        const dirs = [];
        let ux = P[0] - TRI_C[0], uy = P[1] - TRI_C[1], l = Math.hypot(ux, uy);
        if (l > 0.5) dirs.push([ux / l, uy / l]);
        for (let k = 0; k < 3; k++) {   // outward normal of each edge
          const a = TRI[k], b = TRI[(k + 1) % 3], ex = b[0] - a[0], ey = b[1] - a[1], el = Math.hypot(ex, ey);
          let nx = ey / el, ny = -ex / el;
          if ((a[0] - TRI_C[0]) * nx + (a[1] - TRI_C[1]) * ny < 0) { nx = -nx; ny = -ny; }
          dirs.push([nx, ny]);
        }
        for (const u of dirs) {
          const G = [P[0] - u[0] * 2 * R, P[1] - u[1] * 2 * R];
          let xs = [G[0]];
          if (!me && u[1] < -0.25) { const tt = (G[1] - LSY) / u[1], ex = G[0] - u[0] * tt; xs = ex > XMIN + 1 && ex < XMAX - 1 ? [ex, W / 2] : [W / 2, G[0]]; }
          else if (!me) xs = [W / 2, G[0]];
          for (const S of from(xs)) {
            const d = dist(S, G), cx = (G[0] - S[0]) / (d || 1), cy = (G[1] - S[1]) / (d || 1), cs = cx * u[0] + cy * u[1];
            if (cs < 0.25) continue;
            const need = 12 / (cs * cs + 0.15);
            push(S, G, [need * 0.55, need, need * 1.6], [0]);
          }
        }
      }
    } else {
      for (let j = 0; j < s.n; j++) {
        if (j === t || s.o[j] || !s.m[j]) continue;
        for (const S of from([s.m[j][0], s.m[j][0] - 6, s.m[j][0] + 6])) {
          const d = dist(S, s.m[j]), c = R * 0.6 / Math.max(d, 1);
          push(S, s.m[j], [3, 10, 22], [0, c, -c]);
        }
      }
    }
    const rn = s.md === 'c' ? 12 : 6;
    for (let k = 0; k < rn; k++) out.push({ x: me ? null : r2(XMIN + Math.random() * (XMAX - XMIN)), a: -Math.PI / 2 + (Math.random() - 0.5) * (me ? 2 * Math.PI : 2.4), p: 0.12 + Math.random() * 0.55 });
    return out;
  }
  function act(c, da, dp) {
    const o = { type: 'shot', a: c.a + da, p: U.clamp(c.p * (1 + dp), 0.03, 1) };
    if (c.x != null) o.x = c.x;
    return o;
  }
  function ai(s, seat, lv) {
    const P = LVA[lv] || LVA[2], t0 = Date.now();
    let cs = candidates(s, seat, lv);
    if (cs.length > P.n) cs = U.shuffle(cs).slice(0, P.n);
    const ev = (c, da, dp) => { try { return evalState(apply(U.clone(s), seat, act(c, da, dp)), seat); } catch (e) { return -1e6; } };
    const sc = [];
    for (const c of cs) { if (Date.now() - t0 > P.ms && sc.length > 5) break; sc.push({ c, v: ev(c, 0, 0) }); }
    sc.sort((a, b) => b.v - a.v);
    let pick = sc[0];
    if (lv >= 3) {
      let best = null;
      for (const z of sc.slice(0, 6)) {
        if (Date.now() - t0 > P.ms + 60) break;
        const r = (z.v * 2 + ev(z.c, P.a * 1.5, 0) + ev(z.c, -P.a * 1.5, 0) + ev(z.c, 0, P.p * 1.5) + ev(z.c, 0, -P.p * 1.5)) / 6;
        if (!best || r > best.v) best = { c: z.c, v: r };
      }
      if (best) pick = best;
    } else if (P.pick && sc.length > 3 && Math.random() < P.pick) pick = sc[1 + U.rand(Math.min(5, sc.length - 1))];
    return act(pick.c, gauss() * P.a, gauss() * P.p);
  }

  /* ---------- view ---------- */
  const POT_VANES = ['#e64a3c', '#2f8fe0', '#f2c230', '#38b56a', '#9b59d0', '#ff8a3d', '#19b3b3', '#e85aa0'];
  function rgb(hex) { const n = parseInt(String(hex).replace('#', '').slice(0, 6), 16) || 0; return [n >> 16, (n >> 8) & 255, n & 255]; }
  function shade(hex, f, al) {
    let [r, g, b] = rgb(hex);
    if (f > 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return 'rgba(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ',' + (al == null ? 1 : al) + ')';
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, sim = null, simAcc = 0, animLast = null, animPrev = null, shownKey = '', dirty = true, fast = false, animDone = false;
    let finTimer = 0, animTimer = 0, sentAt = 0, flash = null, lastClinks = 0, lastDrops = 0, lastStone = 0, lastOuts = 0;
    let drag = null, place = null, lastTick = -1, wasCancel = true, myLineX = {}, roll = [], bg = null, sprites = {};
    let G = { k: 8, ox: 0, oy: 0 };
    const top = L.h('div', { class: 'hud top mb-top', style: { padding: '6px 8px 0' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px' } });
    root.append(top, bot);
    const spMe = tutSpot(root, 'mb-me'), spGoal = tutSpot(root, 'mb-goal'), spLine = tutSpot(root, 'mb-line');
    const color = (i) => (api.players[i] ? api.players[i].color : '#e3ae45');
    const nameOf = (i) => (api.players[i] ? api.players[i].name : (st && st.nm[i]) || '');

    const M = 1.6;
    function layout() {
      const th = top.getBoundingClientRect().height || 52, bh = bot.getBoundingClientRect().height || 56;
      const y0 = th + 6, y1 = cv.h - bh - 6;
      const k = Math.max(2, Math.min((cv.w - 10) / (W + M * 2), (y1 - y0) / (H + M * 2)));
      G = { k, ox: (cv.w - W * k) / 2, oy: (y0 + y1) / 2 - H * k / 2 };
      bg = null; sprites = {}; dirty = true;
    }
    cv.onresize = layout;
    const TX = (x) => G.ox + x * G.k, TY = (y) => G.oy + y * G.k;

    /* -- static yard layer -- */
    function scratch(g, pts, close, col, w) {   // hand-drawn line scratched in the dirt (deterministic wobble)
      g.lineCap = 'round'; g.lineJoin = 'round';
      for (let pass = 0; pass < 2; pass++) {
        g.strokeStyle = pass ? col : 'rgba(40,24,12,.45)'; g.lineWidth = pass ? w : w + 1.6;
        g.beginPath();
        const P = close ? pts.concat([pts[0]]) : pts;
        for (let s = 0; s < P.length - 1; s++) {
          const a = P[s], b = P[s + 1], seg = Math.max(2, Math.round(Math.hypot(b[0] - a[0], b[1] - a[1]) / 2.5));
          for (let k = 0; k <= seg; k++) {
            const t = k / seg, wob = Math.sin((s * 7 + k) * 1.9) * 0.12 + Math.sin((s * 3 + k) * 4.3) * 0.06;
            const nx = -(b[1] - a[1]), ny = b[0] - a[0], nl = Math.hypot(nx, ny) || 1;
            const x = a[0] + (b[0] - a[0]) * t + nx / nl * wob, y = a[1] + (b[1] - a[1]) * t + ny / nl * wob;
            const px = TX(x) - G.ox + M * G.k, py = TY(y) - G.oy + M * G.k;
            if (k === 0 && s === 0) g.moveTo(px, py); else g.lineTo(px, py);
          }
        }
        g.stroke();
      }
    }
    function makeBg() {
      const k = G.k, dpr = cv.dpr || 1, bw = (W + 2 * M) * k, bh = (H + 2 * M) * k;
      const c = document.createElement('canvas'); c.width = Math.ceil(bw * dpr); c.height = Math.ceil(bh * dpr);
      const g = c.getContext('2d'); g.scale(dpr, dpr);
      const LX = (x) => (x + M) * k, LY = (y) => (y + M) * k;
      // grass verge
      g.fillStyle = '#2c3a22'; g.fillRect(0, 0, bw, bh);
      let seed = 7; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      for (let i = 0; i < 260; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(120,150,70,.35)' : 'rgba(20,30,14,.4)'; const x = rnd() * bw, y = rnd() * bh; g.fillRect(x, y, 1.2, 2 + rnd() * 3); }
      // dirt
      const dg = g.createRadialGradient(LX(W * 0.4), LY(H * 0.35), k * 4, LX(W / 2), LY(H / 2), k * H * 0.75);
      dg.addColorStop(0, '#a77a4f'); dg.addColorStop(0.6, '#8d6440'); dg.addColorStop(1, '#6d4a2e');
      g.fillStyle = dg;
      g.beginPath(); g.roundRect ? g.roundRect(LX(-0.6), LY(-0.6), (W + 1.2) * k, (H + 1.2) * k, k * 1.6) : g.rect(LX(-0.6), LY(-0.6), (W + 1.2) * k, (H + 1.2) * k); g.fill();
      g.save(); g.clip();
      for (let i = 0; i < 1400; i++) {   // speckles
        const x = rnd() * bw, y = rnd() * bh, r = rnd() * 1.1 + 0.3;
        g.fillStyle = rnd() < 0.55 ? 'rgba(50,30,15,' + (0.12 + rnd() * 0.2) + ')' : 'rgba(230,200,150,' + (0.08 + rnd() * 0.15) + ')';
        g.fillRect(x, y, r, r);
      }
      for (let i = 0; i < 46; i++) {     // pebbles
        const x = rnd() * bw, y = rnd() * bh, r = (0.12 + rnd() * 0.22) * k;
        g.fillStyle = 'rgba(30,18,8,.35)'; g.beginPath(); g.ellipse(x + r * 0.3, y + r * 0.4, r, r * 0.8, 0, 0, 7); g.fill();
        g.fillStyle = ['#b49a7c', '#9a8068', '#c9b292', '#7d6a58'][i % 4]; g.beginPath(); g.ellipse(x, y, r, r * 0.8, rnd() * 3, 0, 7); g.fill();
      }
      for (let i = 0; i < 9; i++) {      // faint scuffs
        const x = rnd() * bw, y = rnd() * bh; g.strokeStyle = 'rgba(60,38,20,.18)'; g.lineWidth = 1;
        g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + rnd() * 30 - 15, y + rnd() * 20, x + rnd() * 50 - 25, y + rnd() * 30); g.stroke();
      }
      g.restore();
      const lw = Math.max(1.5, 0.22 * k), col = 'rgba(240,220,185,.75)';
      scratch(g, [[0, 0], [W, 0], [W, H], [0, H]], true, 'rgba(240,220,185,.45)', lw * 0.8);
      scratch(g, [[0.4, LINE_Y], [W - 0.4, LINE_Y]], false, col, lw);
      g.fillStyle = 'rgba(240,220,185,.55)'; g.font = '700 ' + Math.max(10, Math.round(k * 1.15)) + 'px "IBM Plex Sans KR", sans-serif';
      g.textAlign = 'left'; g.textBaseline = 'top'; g.fillText('출발선', LX(0.8), LY(LINE_Y + 0.5));
      if (st && st.md === 'h') {
        g.setLineDash([k * 0.5, k * 0.9]); g.strokeStyle = 'rgba(240,220,185,.22)'; g.lineWidth = Math.max(1, 0.18 * k);
        for (let r = 0; r < 4; r++) {
          const a = HOLES[ROUTE[r]], b = HOLES[ROUTE[r + 1]], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy);
          const sx = a[0] + dx / l * (RF + 0.4), sy = a[1] + dy / l * (RF + 0.4), ex = b[0] - dx / l * (RF + 0.6), ey = b[1] - dy / l * (RF + 0.6);
          g.beginPath(); g.moveTo(LX(sx), LY(sy)); g.lineTo(LX(ex), LY(ey)); g.stroke();
          const ux = dx / l, uy = dy / l, ah = 0.9 * k;
          g.setLineDash([]); g.beginPath(); g.moveTo(LX(ex) - ux * ah - uy * ah * 0.6, LY(ey) - uy * ah + ux * ah * 0.6); g.lineTo(LX(ex), LY(ey)); g.lineTo(LX(ex) - ux * ah + uy * ah * 0.6, LY(ey) - uy * ah - ux * ah * 0.6); g.stroke();
          g.setLineDash([k * 0.5, k * 0.9]);
        }
        g.setLineDash([]);
        HOLES.forEach((q, i) => {
          const x = LX(q[0]), y = LY(q[1]);
          const fg = g.createRadialGradient(x, y, RH * k * 0.8, x, y, RF * k);
          fg.addColorStop(0, 'rgba(60,36,18,.55)'); fg.addColorStop(1, 'rgba(60,36,18,0)');
          g.fillStyle = fg; g.beginPath(); g.arc(x, y, RF * k, 0, 7); g.fill();
          const hg = g.createRadialGradient(x - RH * k * 0.25, y - RH * k * 0.3, RH * k * 0.1, x, y, RH * k);
          hg.addColorStop(0, '#0d0704'); hg.addColorStop(0.75, '#22140a'); hg.addColorStop(1, '#4a2e17');
          g.fillStyle = hg; g.beginPath(); g.arc(x, y, RH * k, 0, 7); g.fill();
          g.strokeStyle = 'rgba(205,160,110,.55)'; g.lineWidth = Math.max(1, 0.18 * k);
          g.beginPath(); g.arc(x, y, RH * k * 0.92, 0.1 * Math.PI, 0.75 * Math.PI); g.stroke();   // lit far wall
          g.strokeStyle = 'rgba(30,16,6,.6)'; g.beginPath(); g.arc(x, y, RH * k, 1.1 * Math.PI, 1.8 * Math.PI); g.stroke();
          const tx = x + (RH + 1.7) * k * (q[0] < W / 2 - 1 ? 1 : q[0] > W / 2 + 1 ? -1 : 1), ty = y - (RH + 1.1) * k;
          g.fillStyle = 'rgba(23,19,31,.62)'; g.beginPath(); g.arc(tx, ty, Math.max(9, 1.2 * k), 0, 7); g.fill();
          g.fillStyle = '#f2e9d8'; g.font = '700 ' + Math.max(11, Math.round(1.45 * k)) + 'px "IBM Plex Mono", monospace'; g.textAlign = 'center'; g.textBaseline = 'middle';
          g.fillText(String(i + 1), tx, ty + 0.5);
        });
      }
      if (st && st.md === 't') {
        const tg = g.createLinearGradient(0, LY(TRI[0][1]), 0, LY(TRI[1][1]));
        tg.addColorStop(0, 'rgba(70,44,22,.18)'); tg.addColorStop(1, 'rgba(70,44,22,.3)');
        g.fillStyle = tg; g.beginPath(); g.moveTo(LX(TRI[0][0]), LY(TRI[0][1])); g.lineTo(LX(TRI[1][0]), LY(TRI[1][1])); g.lineTo(LX(TRI[2][0]), LY(TRI[2][1])); g.closePath(); g.fill();
        scratch(g, TRI, true, col, lw * 1.1);
      }
      if (st && st.sn) for (const s of st.sn) {
        const x = LX(s[0]), y = LY(s[1]), r = s[2] * k;
        g.fillStyle = 'rgba(25,14,6,.45)'; g.beginPath(); g.ellipse(x + r * 0.25, y + r * 0.35, r * 1.05, r * 0.9, 0, 0, 7); g.fill();
        const sg = g.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
        sg.addColorStop(0, '#d8d2c6'); sg.addColorStop(0.6, '#9a938a'); sg.addColorStop(1, '#5c5650');
        g.fillStyle = sg; g.beginPath();
        for (let a = 0; a < 9; a++) { const t = a / 9 * Math.PI * 2, rr = r * (0.9 + 0.1 * Math.sin(a * 2.7 + s[0])); a ? g.lineTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr * 0.92) : g.moveTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr * 0.92); }
        g.closePath(); g.fill();
      }
      return { c, bw, bh };
    }

    /* -- glass marble sprites: body+vane (rotates as it rolls) and a fixed highlight layer -- */
    function sprite(key, body, vane, clear) {
      const pk = key + '|' + G.k;
      if (sprites[pk]) return sprites[pk];
      const dpr = cv.dpr || 1, rp = R * G.k, S = Math.ceil(rp * 2 * dpr) + 4, c0 = S / 2, rr = rp * dpr;
      const mk = () => { const c = document.createElement('canvas'); c.width = S; c.height = S; return c; };
      const a = mk(), g = a.getContext('2d');
      const bg1 = g.createRadialGradient(c0 - rr * 0.3, c0 - rr * 0.35, rr * 0.05, c0, c0, rr);
      if (clear) { bg1.addColorStop(0, 'rgba(235,248,252,.55)'); bg1.addColorStop(0.7, 'rgba(170,215,230,.35)'); bg1.addColorStop(1, 'rgba(60,110,130,.7)'); }
      else { bg1.addColorStop(0, shade(body, 0.5)); bg1.addColorStop(0.55, shade(body, 0.05)); bg1.addColorStop(1, shade(body, -0.6)); }
      g.fillStyle = bg1; g.beginPath(); g.arc(c0, c0, rr, 0, 7); g.fill();
      g.save(); g.beginPath(); g.arc(c0, c0, rr * 0.96, 0, 7); g.clip();
      g.fillStyle = vane; g.globalAlpha = clear ? 0.95 : 0.6;     // cat's-eye vane: two twisted petals
      for (const sg of [1, -1]) {
        g.beginPath(); g.moveTo(c0, c0);
        g.bezierCurveTo(c0 + sg * rr * 0.2, c0 - sg * rr * 0.9, c0 + sg * rr * 0.75, c0 - sg * rr * 0.55, c0 + sg * rr * 0.55, c0 + sg * rr * 0.05);
        g.bezierCurveTo(c0 + sg * rr * 0.4, c0 + sg * rr * 0.25, c0 + sg * rr * 0.15, c0 + sg * rr * 0.1, c0, c0);
        g.fill();
      }
      g.restore();
      const b = mk(), h = b.getContext('2d');
      const dk = h.createRadialGradient(c0 - rr * 0.15, c0 - rr * 0.2, rr * 0.5, c0, c0, rr);
      dk.addColorStop(0, 'rgba(0,0,0,0)'); dk.addColorStop(1, 'rgba(0,0,0,.38)');
      h.fillStyle = dk; h.beginPath(); h.arc(c0, c0, rr, 0, 7); h.fill();
      h.save(); h.beginPath(); h.arc(c0, c0, rr, 0, 7); h.clip();
      const rf = h.createRadialGradient(c0 + rr * 0.42, c0 + rr * 0.48, 0, c0 + rr * 0.42, c0 + rr * 0.48, rr * 0.62);   // light focused through the glass
      rf.addColorStop(0, clear ? 'rgba(255,255,250,.75)' : shade(body, 0.75, 0.85)); rf.addColorStop(1, 'rgba(255,255,255,0)');
      h.fillStyle = rf; h.fillRect(0, 0, S, S);
      h.restore();
      h.fillStyle = 'rgba(255,255,255,.92)';
      h.beginPath(); h.ellipse(c0 - rr * 0.36, c0 - rr * 0.42, rr * 0.3, rr * 0.17, -0.7, 0, 7); h.fill();
      h.fillStyle = 'rgba(255,255,255,.7)'; h.beginPath(); h.arc(c0 + rr * 0.18, c0 - rr * 0.55, rr * 0.07, 0, 7); h.fill();
      h.strokeStyle = 'rgba(255,255,255,.28)'; h.lineWidth = Math.max(0.8, rr * 0.06); h.beginPath(); h.arc(c0, c0, rr - h.lineWidth / 2, 0, 7); h.stroke();
      return (sprites[pk] = { a, b, S: S / dpr });
    }
    function drawShadow(px, py, rp, tint) {
      ctx.fillStyle = 'rgba(30,16,6,.42)'; ctx.beginPath(); ctx.ellipse(px + rp * 0.38, py + rp * 0.5, rp * 1.02, rp * 0.82, 0.5, 0, 7); ctx.fill();
      ctx.fillStyle = tint; ctx.beginPath(); ctx.ellipse(px + rp * 0.62, py + rp * 0.78, rp * 0.36, rp * 0.26, 0.5, 0, 7); ctx.fill();
    }
    function drawMarble(px, py, sp, ang, alpha) {
      const s = sp.S;
      ctx.globalAlpha = alpha;
      ctx.save(); ctx.translate(px, py); ctx.rotate(ang); ctx.drawImage(sp.a, -s / 2, -s / 2, s, s); ctx.restore();
      ctx.drawImage(sp.b, px - s / 2, py - s / 2, s, s);
      ctx.globalAlpha = 1;
    }
    const shooterSprite = (i) => sprite('s' + color(i), color(i), 'rgba(255,250,235,.9)', false);
    const potSprite = (k) => sprite('p' + (k % POT_VANES.length), '#cfe6ee', POT_VANES[k % POT_VANES.length], true);

    /* -- positions for drawing -- */
    function bodies() {   // [{x, y, i (body), sh: shooter seat or -1, hole, alpha}]
      const out = [];
      if (sim) {
        for (let b = 0; b < sim.NB; b++) {
          if (!sim.present[b] || sim.gone[b]) continue;
          out.push({ x: sim.x[b], y: sim.y[b], b, sh: b < sim.n ? b : -1, hole: sim.hl[b], pot: b - sim.n });
        }
        return out;
      }
      for (let i = 0; i < st.n; i++) if (st.m[i]) out.push({ x: st.m[i][0], y: st.m[i][1], b: i, sh: i, hole: st.h ? st.h[i] : -1, pot: -1 });
      if (st.p) st.p.forEach((q, k) => out.push({ x: q[0], y: q[1], b: st.n + k, sh: -1, hole: -1, pot: k }));
      return out;
    }
    function myLine(a) { return myLineX[a] != null ? myLineX[a] : st.lx[a]; }
    function shooterPos(a) {
      if (st.m[a]) return st.m[a];
      return [myLine(a), LSY];
    }

    function draw(now) {
      cv.clear();
      if (!st) return;
      ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, cv.w, cv.h);
      if (!bg) bg = makeBg();
      ctx.drawImage(bg.c, G.ox - M * G.k, G.oy - M * G.k, bg.bw, bg.bh);
      const k = G.k, rp = R * k;
      const a = actor(st), mine = !sim && a != null && api.canAct(a) && !waitingNet();
      const pulse = 0.5 + 0.5 * Math.sin(now / 260);
      // target hole for the player to move
      const who = sim ? animLast.s : a;
      if (st.md === 'h' && who != null && !st.o[who] && st.pg[who] < 5 && st.ph === 'p') {
        const q = HOLES[ROUTE[st.pg[who]]];
        ctx.strokeStyle = shade(color(who), 0.2, 0.55 + 0.4 * pulse); ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(TX(q[0]), TY(q[1]), RH * k + 3 + pulse * 2, 0, 7); ctx.stroke();
      }
      // start strip while my marble waits on the line
      if (mine && !st.m[a]) {
        ctx.fillStyle = 'rgba(227,174,69,' + (0.08 + 0.06 * pulse) + ')';
        ctx.fillRect(TX(0), TY(LINE_Y), W * k, (H - LINE_Y) * k);
      }
      const list = bodies();
      // marbles in holes first (sunk), then shadows, then marbles
      for (const o of list) {
        if (o.hole < 0) continue;
        const sp = o.sh >= 0 ? shooterSprite(o.sh) : potSprite(o.pot);
        ctx.save(); ctx.beginPath(); ctx.arc(TX(HOLES[o.hole][0]), TY(HOLES[o.hole][1]), RH * k * 0.95, 0, 7); ctx.clip();
        const jx = (o.sh % 2 ? 0.35 : -0.35) * rp, jy = (o.sh > 1 ? 0.3 : -0.3) * rp;
        drawMarble(TX(o.x) + jx, TY(o.y) + jy + rp * 0.25, sp, (roll[o.b] || o.b * 1.7), 0.75);
        ctx.fillStyle = 'rgba(10,5,2,.3)'; ctx.beginPath(); ctx.arc(TX(o.x) + jx, TY(o.y) + jy + rp * 0.25, rp, 0, 7); ctx.fill();
        ctx.restore();
      }
      for (const o of list) if (o.hole < 0) drawShadow(TX(o.x), TY(o.y), rp, o.sh >= 0 ? shade(color(o.sh), 0.3, 0.35) : 'rgba(255,250,220,.22)');
      if (!sim) for (let i = 0; i < st.n; i++) {   // marbles still waiting behind the start line
        if (st.m[i] || st.o[i]) continue;
        const x = i === a ? myLine(i) : st.lx[i];
        if (i !== a && a != null && !st.m[a] && Math.abs(x - myLine(a)) < 2.6) continue;
        drawShadow(TX(x), TY(LSY), rp, 'rgba(0,0,0,0)');
        drawMarble(TX(x), TY(LSY), shooterSprite(i), i * 1.7, i === a ? 1 : 0.5);
      }
      for (const o of list) {
        if (o.hole >= 0) continue;
        const sp = o.sh >= 0 ? shooterSprite(o.sh) : potSprite(o.pot);
        drawMarble(TX(o.x), TY(o.y), sp, roll[o.b] != null ? roll[o.b] : o.b * 1.7, 1);
        if (o.sh >= 0 && st.md === 'h' && st.pg[o.sh] >= 5) {   // 독구슬: a coral halo
          ctx.strokeStyle = 'rgba(238,106,85,' + (0.55 + 0.35 * pulse) + ')'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(TX(o.x), TY(o.y), rp + 3.5, 0, 7); ctx.stroke();
        }
      }
      // whose marble
      if (who != null && !st.o[who] && st.ph === 'p') {
        const q = sim ? [sim.x[who], sim.y[who]] : shooterPos(who);
        if (!(sim && sim.gone[who])) {
          ctx.strokeStyle = mine ? 'rgba(227,174,69,.95)' : 'rgba(242,233,216,.55)'; ctx.lineWidth = 2;
          ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.arc(TX(q[0]), TY(q[1]), rp + 6 + (mine && !drag ? pulse * 2 : 0), 0, 7); ctx.stroke(); ctx.setLineDash([]);
        }
      }
      placeSpots(a, mine);
      if (mine) drawAim(a);
      if (place) {
        ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.font = '700 13px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        ctx.fillText('◀ 자리 옮기기 ▶', TX(myLine(a)), TY(LINE_Y) - 4);
      }
      if (flash) {
        const f = U.clamp((now - flash.t0) / 1300, 0, 1);
        if (f >= 1) flash = null;
        else {
          ctx.globalAlpha = f < 0.12 ? f / 0.12 : 1 - Math.max(0, (f - 0.65) / 0.35);
          const s = 1 + (1 - f) * 0.2;
          ctx.font = '400 ' + Math.round(42 * s) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 7; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(flash.text, cv.w / 2, TY(H * 0.45));
          ctx.fillStyle = flash.c; ctx.fillText(flash.text, cv.w / 2, TY(H * 0.45));
          ctx.globalAlpha = 1;
        }
      }
    }
    function placeSpots(a, mine) {
      const k = G.k;
      spLine(TX(0), TY(LINE_Y) - 4, W * k, (H - LINE_Y) * k + 8);
      if (st.md === 'h') {
        const me = api.mySeats ? api.mySeats() : [], t = a != null && mine ? a : me.length ? me[0] : 0;
        const q = HOLES[ROUTE[Math.min(4, st.pg[t] || 0)]], r = (RH + 1.5) * k;
        spGoal(TX(q[0]) - r, TY(q[1]) - r, 2 * r, 2 * r);
      } else if (st.md === 't') {
        spGoal(TX(TRI[1][0]) - 6, TY(TRI[0][1]) - 6, TRI_S * k + 12, (TRI[1][1] - TRI[0][1]) * k + 12);
      } else spGoal(TX(0), TY(0), W * k, LINE_Y * k);
      if (mine && !sim) { const q = shooterPos(a), r = R * k + 14; spMe(TX(q[0]) - r, TY(q[1]) - r, 2 * r, 2 * r); } else spMe(null);
    }

    /* -- aiming -- */
    const CANCEL = 16;
    function screenRoom(x, y, ux, uy) {
      const r = cv.cv.getBoundingClientRect(), x0 = -r.left, y0 = -r.top, x1 = (window.innerWidth || cv.w) - r.left, y1 = (window.innerHeight || cv.h) - r.top;
      let t = 1e9;
      if (ux > 1e-6) t = Math.min(t, (x1 - x) / ux); else if (ux < -1e-6) t = Math.min(t, (x0 - x) / ux);
      if (uy > 1e-6) t = Math.min(t, (y1 - y) / uy); else if (uy < -1e-6) t = Math.min(t, (y0 - y) / uy);
      return Math.max(0, t);
    }
    function aimInfo() {
      if (!drag) return null;
      const l = Math.hypot(drag.vec[0], drag.vec[1]);
      let maxPx = Math.min(180, Math.max(110, cv.h * 0.24));
      if (l > 1) maxPx = U.clamp(screenRoom(drag.ox, drag.oy, drag.vec[0] / l, drag.vec[1] / l) - CANCEL, 60, maxPx);
      if (l < CANCEL) return { cancel: true };
      return { ang: Math.atan2(-drag.vec[1], -drag.vec[0]), p: Math.round(U.clamp((l - CANCEL + 3) / maxPx, 0.02, 1) * 100) / 100 };
    }
    function castRay(a, S, dx, dy, maxD) {   // first marble / stone / edge along the straight line
      let tmin = maxD, hit = null;
      for (const o of bodies()) {
        if (o.b === a || o.hole >= 0) continue;
        const fx = S[0] - o.x, fy = S[1] - o.y, b = fx * dx + fy * dy, c = fx * fx + fy * fy - 4 * R * R, disc = b * b - c;
        if (disc < 0) continue;
        const t = -b - Math.sqrt(disc);
        if (t > 0.01 && t < tmin) { tmin = t; hit = o; }
      }
      if (st.sn) for (const q of st.sn) {
        const fx = S[0] - q[0], fy = S[1] - q[1], rr = R + q[2], b = fx * dx + fy * dy, c = fx * fx + fy * fy - rr * rr, disc = b * b - c;
        if (disc < 0) continue;
        const t = -b - Math.sqrt(disc);
        if (t > 0.01 && t < tmin) { tmin = t; hit = { stone: q }; }
      }
      return { t: tmin, hit };
    }
    function drawAim(a) {
      const info = aimInfo(), S = shooterPos(a), px = TX(S[0]), py = TY(S[1]), rp = R * G.k;
      if (!drag) return;
      if (info.cancel) {
        if (drag.started) readout('놓으면 취소', '#ee6a55', drag.oy);
        ctx.strokeStyle = 'rgba(238,106,85,.8)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.arc(drag.ox, drag.oy, CANCEL, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        return;
      }
      const dx = Math.cos(info.ang), dy = Math.sin(info.ang);
      // where I started pulling (come back here to cancel)
      ctx.strokeStyle = 'rgba(242,233,216,.3)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.arc(drag.ox, drag.oy, CANCEL, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      if (st.ag) {
        const roll0 = distFor(info.p), rc = castRay(a, S, dx, dy, roll0);
        ctx.strokeStyle = 'rgba(242,233,216,.75)'; ctx.lineWidth = 1.6; ctx.setLineDash([2, 5]); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(px + dx * rp, py + dy * rp); ctx.lineTo(TX(S[0] + dx * rc.t), TY(S[1] + dy * rc.t)); ctx.stroke(); ctx.setLineDash([]);
        const ex = TX(S[0] + dx * rc.t), ey = TY(S[1] + dy * rc.t);
        if (rc.hit && rc.hit.b != null) {
          ctx.strokeStyle = 'rgba(242,233,216,.85)'; ctx.lineWidth = 1.3; ctx.setLineDash([3, 3]);
          ctx.beginPath(); ctx.arc(ex, ey, rp, 0, 7); ctx.stroke(); ctx.setLineDash([]);
          let nx = rc.hit.x - (S[0] + dx * rc.t), ny = rc.hit.y - (S[1] + dy * rc.t); const l = Math.hypot(nx, ny) || 1; nx /= l; ny /= l;
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.moveTo(TX(rc.hit.x + nx * R), TY(rc.hit.y + ny * R)); ctx.lineTo(TX(rc.hit.x + nx * 5), TY(rc.hit.y + ny * 5)); ctx.stroke();
        } else if (!rc.hit) {   // where it would stop on open dirt
          ctx.strokeStyle = 'rgba(242,233,216,.9)'; ctx.lineWidth = 2;
          const c = 4;
          ctx.beginPath(); ctx.moveTo(ex - c, ey - c); ctx.lineTo(ex + c, ey + c); ctx.moveTo(ex + c, ey - c); ctx.lineTo(ex - c, ey + c); ctx.stroke();
        }
      }
      const len = rp + 12 + info.p * 60, ex = px + dx * len, ey = py + dy * len;
      ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(px + dx * (rp + 4), py + dy * (rp + 4)); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(ex + dx * 8, ey + dy * 8); ctx.lineTo(ex - dy * 6, ey + dx * 6); ctx.lineTo(ex + dy * 6, ey - dx * 6); ctx.closePath(); ctx.fill();
      const rr = rp + 9;
      ctx.lineWidth = 5; ctx.lineCap = 'butt';
      ctx.strokeStyle = 'rgba(23,19,31,.6)'; ctx.beginPath(); ctx.arc(px, py, rr, 0, 7); ctx.stroke();
      ctx.strokeStyle = info.p < 0.35 ? '#5fd3a0' : info.p < 0.7 ? '#e3ae45' : '#ee6a55';
      ctx.beginPath(); ctx.arc(px, py, rr, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * info.p); ctx.stroke();
      readout(Math.round(info.p * 100) + '%', '#f2e9d8', py);
    }
    function readout(text, c, fingerY) {
      const by = fingerY > cv.h / 2 ? TY(H * 0.12) : TY(H * 0.62), bx = cv.w / 2;
      ctx.fillStyle = 'rgba(23,19,31,.72)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx - 60, by - 17, 120, 34, 12) : ctx.rect(bx - 60, by - 17, 120, 34); ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = c; ctx.font = text.length > 5 ? '700 15px "IBM Plex Sans KR", sans-serif' : '700 22px "IBM Plex Mono", monospace';
      ctx.fillText(text, bx, by + 1);
    }

    /* -- HUD -- */
    let topKey = '', botKey = '';
    function pips(i) {
      const box = L.h('span', { style: { display: 'inline-flex', gap: '2px', alignItems: 'center' } });
      for (let k = 0; k < 5; k++) box.append(L.h('span', { style: { width: '7px', height: '7px', borderRadius: '50%', background: k < st.pg[i] ? color(i) : 'rgba(242,233,216,.18)', boxShadow: k < st.pg[i] ? '0 0 0 1px rgba(255,255,255,.35) inset' : 'none' } }));
      return box;
    }
    const glyph = (c) => L.h('span', { style: { width: '10px', height: '10px', borderRadius: '50%', flex: 'none', display: 'inline-block', background: 'radial-gradient(circle at 35% 32%, #fff 0 14%, ' + c + ' 40%, ' + shade(c, -0.5) + ' 100%)' } });
    function renderTop() {
      if (!st) return;
      const shown = sim && !animDone && animPrev ? animPrev : st;
      const cur = sim ? animLast.s : actor(st);
      const key = JSON.stringify([shown.g, shown.pg, shown.o, cur, st.ph, shown.p ? shown.p.length : 0, st.rd]);
      if (key === topKey) return;
      topKey = key; top.innerHTML = '';
      const row = L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'stretch', gap: '4px', padding: '4px', width: '100%' } });
      for (let i = 0; i < st.n; i++) {
        const on = cur === i && st.ph === 'p', out = shown.o[i];
        let val;
        if (st.md === 'h') val = out ? L.h('span', { class: 'muted', style: { fontSize: '11px' }, text: '잡힘' })
          : shown.pg[i] >= 5 ? L.h('span', { style: { fontSize: '11px', fontWeight: 700, color: '#ee6a55' }, text: '독구슬' + (shown.g[i] ? ' ·' + shown.g[i] : '') }) : pips(i);
        else val = L.h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '3px' } }, glyph(st.md === 't' ? '#9fd3e3' : color(i)),
          L.h('span', { class: 'mono', style: { fontSize: '15px', fontWeight: 700 }, text: (out ? '0' : String(shown.g[i])) }));
        row.append(L.h('div', { style: { flex: '1 1 0', minWidth: 0, display: 'flex', flexDirection: 'column', gap: '2px', padding: '3px 6px', borderRadius: '10px',
          background: on ? 'rgba(227,174,69,.14)' : 'transparent', boxShadow: on ? 'inset 0 0 0 1.5px rgba(227,174,69,.75)' : 'none', opacity: out ? 0.45 : 1 } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', minWidth: 0 } },
            L.h('span', { class: 'dot', style: { '--c': color(i), flex: 'none' } }),
            L.h('span', { style: { fontWeight: 700, fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0, textDecoration: out ? 'line-through' : 'none' }, text: nameOf(i) })),
          val));
      }
      top.append(row);
      layout();
    }
    function sideInfo(a) {
      if (st.md === 'h') return a != null && st.pg[a] >= 5 ? '독구슬' : a != null ? '목표 ' + HOLE_NM[ROUTE[st.pg[a]]] : '';
      if (st.md === 't') return '남은 ' + st.p.length + '개';
      return Math.min(st.rd, ROUNDS.c) + '/' + ROUNDS.c + '판';
    }
    function hint(a, mine) {
      if (sim) return fast ? '빨리 감는 중…' : '굴러가는 중… · 화면을 누르면 빨리 감기';
      if (!mine) return api.players[a] && api.players[a].ai ? '생각 중…' : '차례 기다리는 중';
      const base = !st.m[a] ? '띠에서 자리 옮기기 · 위에서 뒤로 끌어 쏘기' : '아무 데나 누르고 뒤로 끌었다 놓기';
      if (st.md === 'h') return (st.pg[a] >= 5 ? '독구슬! 남의 구슬 맞히기' : HOLE_NM[ROUTE[st.pg[a]]] + ' 구멍에 넣기') + ' · ' + base;
      if (st.md === 't') return '삼각형 밖으로 쳐내기 · ' + base;
      return '남의 구슬 맞히기 · ' + base;
    }
    function renderBot() {
      if (!st) return;
      const a = sim ? animLast.s : actor(st), mine = !sim && st.ph === 'p' && a != null && api.canAct(a) && !waitingNet();
      const key = [a, mine, !!sim, fast, st.ph, st.x, st.m[a] ? 1 : 0, sideInfo(a), st.md === 'h' && a != null ? st.pg[a] : 0].join('|');
      if (key === botKey) return;
      botKey = key; bot.innerHTML = '';
      if (st.ph === 'e' || a == null) { layout(); return; }
      bot.append(L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 10px', minWidth: 0, width: '100%', minHeight: '44px' } },
        L.h('span', { class: 'dot', style: { '--c': color(a), flex: 'none' } }),
        L.h('div', { style: { display: 'flex', flexDirection: 'column', minWidth: 0, gap: '1px', flex: '1 1 auto' } },
          L.h('span', { style: { fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }, nameOf(a),
            st.x && !sim ? L.h('span', { style: { color: 'var(--brass)', fontSize: '11px', marginLeft: '6px' }, text: '한 번 더!' }) : null),
          L.h('span', { class: 'muted', style: { fontSize: '12px', lineHeight: 1.25, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }, text: hint(a, mine) })),
        L.h('span', { class: 'mono', style: { flex: 'none', fontSize: '12px', fontWeight: 700, color: 'var(--brass)', whiteSpace: 'nowrap' }, text: sideInfo(a) })));
      layout();
    }

    /* -- input -- */
    function waitingNet() { return sentAt && performance.now() - sentAt < 6000; }
    function canHuman() { return st && !sim && st.ph === 'p' && api.canAct(actor(st)) && !waitingNet(); }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (sim && !fast) { fast = true; renderBot(); return; }
      if (!canHuman() || drag || place) return;
      const a = actor(st), p = cv.local(ev);
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      if (!st.m[a] && p.y >= TY(LINE_Y) - 6 && p.y <= TY(H) + 26) {   // slide my marble along the start line
        place = { id: ev.pointerId };
        myLineX[a] = U.clamp((p.x - G.ox) / G.k, XMIN, XMAX);
        api.sfx('tick'); renderBot(); dirty = true; return;
      }
      drag = { id: ev.pointerId, ox: p.x, oy: p.y, vec: [0, 0], started: false };
      lastTick = -1; wasCancel = true;
      api.buzz(8); dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (place && place.id === ev.pointerId) {
        const p = cv.local(ev), a = actor(st);
        myLineX[a] = U.clamp((p.x - G.ox) / G.k, XMIN, XMAX); dirty = true; return;
      }
      if (!drag || drag.id !== ev.pointerId) return;
      const p = cv.local(ev);
      drag.vec = [p.x - drag.ox, p.y - drag.oy];
      if (Math.hypot(drag.vec[0], drag.vec[1]) > CANCEL + 4) drag.started = true;
      const info = aimInfo();
      if (info && drag.started) {
        if (!!info.cancel !== wasCancel) { wasCancel = !!info.cancel; api.buzz(info.cancel ? 20 : 8); }
        const tk = info.cancel ? -1 : Math.floor(info.p * 10);
        if (tk !== lastTick && tk >= 0) api.sfx('tick');
        lastTick = tk;
      }
      dirty = true;
    });
    function up(ev) {
      if (place && place.id === ev.pointerId) { place = null; api.sfx('click'); dirty = true; return; }
      if (!drag || drag.id !== ev.pointerId) return;
      const info = aimInfo(), d0 = drag; drag = null; dirty = true;
      if (ev.type === 'pointercancel' || !canHuman() || !info || !d0.started) return;
      if (info.cancel) { api.sfx('click'); api.toast('취소'); return; }
      const a = actor(st), act = { type: 'shot', a: info.ang, p: info.p };
      if (!st.m[a]) act.x = r2(myLine(a));
      api.sfx('tick'); api.buzz(12);
      if (!api.isHost) sentAt = performance.now();
      api.act(act);
    }
    cv.cv.addEventListener('pointerup', up);
    cv.cv.addEventListener('pointercancel', up);

    /* -- animation -- */
    function startAnim(last, prevState) {
      clearTimeout(finTimer); clearTimeout(animTimer);
      sim = new Sim(envOf(st), last.pre, last.shot); animLast = last; animPrev = prevState || st;
      simAcc = 0; lastClinks = 0; lastDrops = 0; lastStone = 0; lastOuts = 0; animDone = false; fast = false;
      roll = [];
      for (let b = 0; b < sim.NB; b++) roll[b] = b * 1.7;
      api.setBusy(true);
      const mine = sim, dur = new Sim(envOf(st), last.pre, last.shot).run().steps * DT;
      animTimer = setTimeout(() => { if (sim === mine && !sim.done) { sim.run(); finishAnim(); } }, (dur / L.debug.speed) * 1000 + 3000);
      renderTop(); renderBot();
    }
    function finishAnim() {
      clearTimeout(animTimer);
      const l = animLast, s = sim;
      animDone = true;
      if (l.big) {
        const bad = l.big === '벌칙!';
        flash = { text: l.big, c: bad ? '#ab9fb8' : l.big === '독구슬!' || l.big === '잡았다!' ? '#ee6a55' : '#e3ae45', t0: performance.now() };
        api.sfx(bad ? 'lose' : 'win'); api.buzz(30);
      }
      if (l.msg) api.toast(l.msg);
      renderTop();
      finTimer = setTimeout(() => {
        if (sim !== s) return;
        sim = null; animLast = null; animPrev = null; roll = [];
        api.setBusy(false);
        renderTop(); renderBot(); dirty = true;
      }, (l.big ? 900 : 250) / L.debug.speed);
    }
    let tutSeen = false, tutMissed = false;
    const stop = U.loop((dt, now) => {
      // first-play tutorial shown during someone else's turn: replay the control steps when my turn comes
      if (st && !tutSeen) {
        const mine = !sim && st.ph === 'p' && api.canAct(actor(st)) && !waitingNet();
        if (root.querySelector('.tut-layer')) { if (!mine) tutMissed = true; }
        else if (mine) {
          tutSeen = true;
          if (tutMissed) setTimeout(() => { if (!root.querySelector('.tut-layer')) api.tutorial(TUT.filter((s) => s.sel === '.mb-me' || s.sel === '.mb-line')); }, 400);
        }
      }
      if (sim) {
        if (!sim.done) {
          simAcc += dt * L.debug.speed * (fast ? 4 : 1);
          let n = 0;
          const ox = Array.from(sim.x), oy = Array.from(sim.y);
          while (simAcc >= DT && !sim.done && n < 4000) { sim.step(); simAcc -= DT; n++; }
          for (let b = 0; b < sim.NB; b++) {
            const dx = sim.x[b] - ox[b], dy = sim.y[b] - oy[b];
            if (dx || dy) roll[b] = (roll[b] || 0) + (dx >= 0 ? 1 : -1) * Math.hypot(dx, dy) / R;
          }
          if (sim.clinks > lastClinks) { lastClinks = sim.clinks; api.sfx(sim.clinkV > 40 ? 'hit' : 'chip'); api.buzz(sim.clinkV > 40 ? 14 : 6); sim.clinkV = 0; }
          if (sim.drops > lastDrops) { lastDrops = sim.drops; api.sfx('pop'); api.buzz(20); }
          if (sim.stoneHits > lastStone) { lastStone = sim.stoneHits; api.sfx('thud'); }
          if (sim.outs > lastOuts) { lastOuts = sim.outs; api.sfx('whoosh'); }
          if (sim.done) finishAnim();
        }
        dirty = true;
      }
      if (flash || drag || place) dirty = true;
      if (!sim && st && st.ph === 'p') dirty = true;   // pulsing target ring
      if (dirty) { dirty = false; draw(now); }
    });

    layout();
    return {
      update(next, prev) {
        const old = st;
        st = next;
        if (prev !== next) sentAt = 0;
        if (!old || (old.md !== next.md) || JSON.stringify(old.sn) !== JSON.stringify(next.sn)) bg = null;
        const key = next.last ? next.last.id + ':' + next.last.shot.vx + ':' + next.last.shot.vy : '';
        if (next.last && key !== shownKey && prev && prev !== next) { shownKey = key; startAnim(next.last, prev); }
        else shownKey = key;
        renderTop(); renderBot(); dirty = true;
      },
      destroy() { stop(); clearTimeout(finTimer); clearTimeout(animTimer); cv.destroy(); top.remove(); bot.remove(); [spMe, spGoal, spLine].forEach((f) => f.el.remove()); api.setBusy(false); },
    };
  }

  const TUT = [
    { sel: '.mb-top', text: '구슬치기예요! 위에 사람마다 점수가 나와요. 구멍 넣기는 넣은 구멍 수(점 5개), 따먹기·맞히기는 가진 구슬 수예요.' },
    { sel: '.mb-goal', text: '여기가 목표예요. 구멍 넣기는 ①→②→③→④→① 순서로 구멍에 넣어요. 따먹기는 삼각형 속 구슬을 쳐내고, 맞히기는 남의 구슬을 맞혀요.' },
    { sel: '.mb-line', text: '처음엔 내 구슬이 출발선 뒤(이 띠)에 있어요. 띠를 누른 채 옆으로 밀면 쏠 자리를 옮길 수 있어요.' },
    { sel: '.mb-me', text: '쏘기: 띠 위쪽 아무 데나 누르고, 가고 싶은 쪽의 반대로 끌었다 떼요(새총). 많이 끌수록 세요(%). 누른 곳으로 되돌아와 떼면 취소!' },
    { text: '흰 점선은 굴러갈 길, ×는 멈출 곳이에요(다른 구슬이 없을 때). 구멍엔 천천히 굴러가야 쏙 빠져요. 너무 빠르면 건너뛰어요!' },
  ];

  L.register({
    id: 'marbles', name: '구슬치기', tag: '구슬 튕기기', cat: '스포츠',
    blurb: '흙마당에서 유리구슬을 손가락으로 튕겨요. 구멍 넣기·삼각 따먹기·맞히기 3가지 놀이로 구슬을 따요.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 700,
    tint: '#5a3a1e',
    icon: '<circle cx="28" cy="28" r="13" fill="none" stroke="currentColor" stroke-width="3"/><path d="M21 24c4-6 10-6 13 0-4 3-9 3-13 0z" fill="currentColor"/><circle cx="23" cy="22" r="2.4" fill="currentColor" opacity=".7"/><circle cx="11" cy="45" r="5" fill="currentColor" opacity=".6"/><circle cx="45" cy="44" r="6" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="46" cy="12" r="4" fill="currentColor" opacity=".45"/>',
    options: [
      { id: 'mode', label: '놀이', choices: [{ v: 'hole', label: '구멍 넣기' }, { v: 'tri', label: '삼각 따먹기' }, { v: 'hit', label: '맞히기' }], def: 'hole' },
      { id: 'aim', label: '조준선', choices: [{ v: 1, label: '켬' }, { v: 0, label: '끔' }], def: 1 },
    ],
    quick: [
      '흙마당에서 유리구슬을 손가락으로 튕기는 옛날 놀이예요. 놀이는 3가지(설정에서 골라요).',
      '내 차례: 화면을 누르고 뒤로 끌었다 놓으면 내 구슬이 반대쪽으로 굴러가요(새총처럼).',
      '구멍 넣기: 구멍 ①→②→③→④→①에 차례로 넣으면 독구슬! 독구슬로 남의 구슬을 맞히면 잡아요. 끝까지 남으면 승리.',
      '삼각 따먹기·맞히기: 구슬을 가장 많이 딴 사람이 이겨요.',
    ],
    rules: [
      { h: '목표', p: ['2~4명이 번갈아 자기 구슬을 한 번씩 튕겨요. 놀이(설정의 「놀이」)마다 이기는 방법이 달라요.',
        '구멍 넣기: 마지막까지 살아남기. 삼각 따먹기·맞히기: 구슬을 가장 많이 가지기.'] },
      { h: '조작', p: ['① 처음엔 내 구슬이 출발선 뒤(아래 띠)에서 기다려요. 띠를 누른 채 옆으로 밀면 자리를 옮겨요.',
        '② 띠 위쪽 아무 데나 누르고, 가고 싶은 쪽의 반대로 끌었다 떼면 튕겨요(새총). 많이 끌수록 세요(%와 구슬 둘레 링).',
        '③ 처음 누른 곳 가까이로 되돌아와 떼면 취소예요. 화면 끝까지 끌면 100%가 되도록 눈금이 맞춰져요.',
        '④ 조준선(켬): 흰 점선이 구를 길, ×가 멈출 곳(빈 땅일 때), 다른 구슬에 닿으면 노란 선이 그 구슬이 튈 방향이에요.',
        '구슬이 구르는 동안 화면을 누르면 빨리 감기. 한 폰을 돌려 가며 해도 돼요.'] },
      { h: '① 구멍 넣기', p: ['마당에 구멍 4개가 있어요. ①→②→③→④를 돌고 다시 ①에 넣으면(모두 5번) 내 구슬이 「독구슬」이 돼요.',
        '목표 구멍에 넣으면 그 자리에서 한 번 더 쳐요. 다른 구멍에 빠지면 그냥 거기서 다음에 쳐요.',
        '독구슬로 남의 구슬을 맞히면 그 사람은 잡혀서 탈락! 잡으면 한 번 더 쳐요. 마지막 한 명이 남으면 이겨요.',
        '구멍 속 구슬은 맞힐 수 없어요(숨기 가능). 독구슬이 되기 전에는 남의 구슬을 맞혀도 밀려날 뿐이에요.',
        '30라운드가 지나면 넣은 구멍이 많은 사람(같으면 잡은 수)이 이겨요.'] },
      { h: '② 삼각 따먹기', p: ['삼각형 안에 구슬이 모여 있어요(2명 10개, 3~4명 15개).',
        '내 구슬로 쳐서 삼각형 밖으로 완전히 내보낸 구슬은 내 것! 하나라도 따면 한 번 더 쳐요.',
        '내 구슬이 삼각형 안에 멈추면 벌칙: 딴 구슬 1개를 삼각형에 돌려놓고 출발선으로 돌아가요.',
        '삼각형이 비면 끝, 구슬을 가장 많이 딴 사람이 이겨요.'] },
      { h: '③ 맞히기', p: ['모두 구슬 5개씩 가지고 시작해요. 마당엔 돌멩이가 몇 개 있어 숨을 수 있어요.',
        '내 구슬로 남의 구슬을 맞히면 그 사람 구슬 1개를 가져와요. 맞히면 한 번 더(한 차례 최대 3번).',
        '구슬이 0개가 되면 탈락. 10판(모두 한 번씩 = 1판)이 지나거나 한 명만 남으면 끝, 가장 많은 사람이 이겨요.'] },
      { h: '공통', p: ['마당 밖으로 나간 구슬은 나간 자리 바로 안쪽에 놓여요.',
        '흙바닥이라 구슬은 점점 느려져요. 구멍은 천천히 굴러가야 빠지고, 빠르면 건너뛰어요(구멍 가장자리는 살짝 비탈져서 가까이 가면 빨려 들어가요).',
        '같은 무게 유리구슬끼리 정면으로 맞으면 맞힌 구슬은 거의 서고 맞은 구슬이 쭉 나가요. 비스듬히 맞히면 둘 다 갈라져요.',
        '첫 차례는 무작위예요. AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
      { h: '예시', p: ['구멍 넣기: 출발선에서 ①로 살살 굴림 → 쏙! 한 번 더 → ②로 쳤는데 지나침 → 차례 넘어감. 다음 차례에 거기서 ②로.',
        '따먹기: 삼각형 모서리 구슬을 비스듬히 쳐서 2개가 선 밖으로 → +2, 한 번 더! 그런데 내 구슬이 삼각형 안에 서면 1개 반납.',
        '맞히기: 상대 구슬을 맞힘 → 상대 5→4개, 나 5→6개, 한 번 더!'] },
    ],
    tutorial: TUT,
    init, actor, apply, ai, result, mount,
    _sim: { Sim, simulate, rollDist, powerFor, distFor, triDist, HOLES, ROUTE, TRI, W, H, R, LSY, rack, evalState },
  });
})();
