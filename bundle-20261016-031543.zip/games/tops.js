/* 팽이 싸움 (tops) — 실시간 팽이 대결, 2–4명.
   라운드마다: 팽이 고르기 → 발사(뒤로 당겨 조준 + 「발사!」에 맞춰 손 떼기) → 회전 대결(오목한 경기장).
   팽이는 경기장 가운데로 미끄러져 내려가고, 부딪히면 회전끼리 튕겨 나가요. 장외 또는 회전이 멈추면 탈락.
   호스트(또는 혼자 하는 폰)가 고정 스텝으로 물리를 돌리고, 온라인 게스트는 20 Hz 스냅숏을 받아 그려요(sumo.js 방식). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= constants ======================= */
  const H = 1 / 120;                                  // physics step
  const CTRL = 50, STEER = 110, DASH = 88, DASH_CD = 3, DASH_COST = 5, DASH_T = 0.35, VCAP = 175;
  const E_REST = 0.5, CLASH = 52, SPIN_HIT = 5, PAIR_GAP = 0.14;
  const SUDDEN = 45, CAP_T = 100, END_T = 2.6, GRACE = 3.5;
  const PRE = 1.0, GO = 4.0, WIN = 0.6, PERF = 0.07, WAIT_REMOTE = 2.2;
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const wrapA = (a) => { a = (a + Math.PI) % (Math.PI * 2); if (a < 0) a += Math.PI * 2; return a - Math.PI; };

  // 팽이 4종: st = [공격, 방어, 지구력, 속도] (1–5)
  // r 반지름, m 무게, atk 때리는 힘, def 회전 손실 저항, dec 초당 회전 감소, vt 스스로 달리려는 속도, curl 휘어 도는 정도,
  // mu 빠를 때 감속, ctl 조작 힘, dash 돌진 힘
  const TYPES = [
    { id: 'a', nm: '공격형', sub: '빠르게 돌아다니며 세게 들이받아요', st: [5, 2, 2, 5], r: 13, m: 1.0, atk: 1.6, def: 1.0, dec: 1.5, vt: 70, curl: 1.1, mu: 0.6, ctl: 1.3, dash: 1.15 },
    { id: 'd', nm: '방어형', sub: '무겁고 단단해서 잘 안 밀려요', st: [2, 5, 3, 2], r: 14.5, m: 1.8, atk: 0.8, def: 1.8, dec: 1.5, vt: 24, curl: 0.8, mu: 1.2, ctl: 0.85, dash: 0.9 },
    { id: 's', nm: '지구력형', sub: '가운데서 아주 오래 돌아요', st: [1, 2, 5, 3], r: 13.5, m: 1.0, atk: 0.6, def: 1.45, dec: 0.75, vt: 12, curl: 0.5, mu: 0.8, ctl: 1.0, dash: 0.95 },
    { id: 'b', nm: '균형형', sub: '뭐든 적당히 잘해요', st: [3, 3, 3, 3], r: 13, m: 1.2, atk: 1.2, def: 1.2, dec: 1.0, vt: 45, curl: 0.9, mu: 0.7, ctl: 1.1, dash: 1.05 },
  ];
  const STAT_NM = ['공격', '방어', '지구력', '속도'];
  const beats = (x, y) => (x === 0 && y === 2) || (x === 2 && y === 1) || (x === 1 && y === 0); // 공격>지구력>방어>공격
  const COLORS = ['#ee6a55', '#e3ae45', '#4fa8e8', '#5cc97e', '#b07cf0', '#f07cb8'];
  const COLOR_NM = ['코랄', '황동', '하늘', '초록', '보라', '분홍'];

  // shape: c 원, o 팔각(모서리 넷 뚫림), s 캡슐(웅덩이 둘). G 가운데로 끌리는 힘, esc 이 속도보다 빠르게 테두리에 닿으면 장외
  const ARENAS = [
    { id: 'dish', name: '나무 접시', sub: '기본 경기장 · 테두리 높이 보통', shape: 'c', R: 100, G: 1.2, esc: 65,
      pal: { b0: '#e0aa6c', b1: '#a8693a', b2: '#5e3418', rim0: '#f0c060', rim1: '#7a5418', line: 'rgba(60,28,8,.32)', bg: '#1a1210' } },
    { id: 'deep', name: '깊은 사발', sub: '가운데로 세게 끌려요 · 장외는 잘 안 나요', shape: 'c', R: 92, G: 2.2, esc: 100,
      pal: { b0: '#8cc0e4', b1: '#2f5f8f', b2: '#10223a', rim0: '#f2e9d8', rim1: '#8a93a2', line: 'rgba(255,255,255,.13)', bg: '#0c1220' } },
    { id: 'oct', name: '팔각 링', sub: '평평한 편 · 네 곳이 뚫려 있어 장외 조심', shape: 'o', R: 106, G: 0.8, esc: 70, gw: 16,
      pal: { b0: '#cfd4da', b1: '#7d858f', b2: '#3e444d', rim0: '#ee6a55', rim1: '#6a2418', line: 'rgba(0,0,0,.2)', bg: '#141018' } },
    { id: 'twin', name: '쌍둥이 웅덩이', sub: '웅덩이 둘 사이에 언덕 · 건너가며 싸워요', shape: 's', hw: 44, R: 76, G: 1.5, esc: 80,
      pal: { b0: '#98dcbc', b1: '#2f8a68', b2: '#143e2e', rim0: '#e3ae45', rim1: '#6b4b16', line: 'rgba(0,0,0,.2)', bg: '#0c1612' } },
  ];

  /* ======================= arena geometry ======================= */
  const RI = { d: 0, nx: 0, ny: 0, gap: false };
  function rimInfo(A, x, y) { // d = distance from the point to the rim (inside > 0), n = outward normal
    if (A.shape === 'c') {
      const r = Math.hypot(x, y) || 1e-6;
      RI.d = A.R - r; RI.nx = x / r; RI.ny = y / r; RI.gap = false;
    } else if (A.shape === 'o') {
      let bk = 0, bv = -1e9;
      for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4, v = x * Math.cos(a) + y * Math.sin(a); if (v > bv) { bv = v; bk = k; } }
      const a = bk * Math.PI / 4, nx = Math.cos(a), ny = Math.sin(a);
      RI.d = A.R * Math.cos(Math.PI / 8) - bv; RI.nx = nx; RI.ny = ny;
      RI.gap = bk % 2 === 1 && Math.abs(-x * ny + y * nx) < A.gw;
    } else {
      const cx = clamp(x, -A.hw, A.hw), dx = x - cx, r = Math.hypot(dx, y) || 1e-6;
      RI.d = A.R - r; RI.nx = dx / r; RI.ny = y / r; RI.gap = false;
    }
    return RI;
  }
  const homeX = (A, x) => (A.shape === 's' ? (x < 0 ? -A.hw : A.hw) : 0);
  function arenaBox(A) { return A.shape === 's' ? { w: (A.hw + A.R) * 2, h: A.R * 2 } : { w: A.R * 2, h: A.R * 2 }; }
  function spawnOf(A, n, i) {
    if (A.shape === 's') { // two wells (with 3 players the lone well rotates with the start spots each round)
      const p = [[-1, 1], [1, -1], [1, 1], [-1, -1]][i % 4];
      return { x: p[0] * A.hw, y: p[1] * A.R * 0.66 };
    }
    const th = Math.PI / 2 + i * 2 * Math.PI / n, R = (A.shape === 'o' ? A.R * Math.cos(Math.PI / 8) : A.R) * 0.72;
    return { x: r1(Math.cos(th) * R), y: r1(Math.sin(th) * R) };
  }
  function defaultAim(A, sp) { return Math.abs(sp.x) < 1 ? Math.atan2(-sp.y, 0) : Math.atan2(-sp.y, homeX(A, sp.x) - sp.x); }
  function qualityOf(err) { return err <= PERF ? 1 : Math.max(0.55, 1 - (err - PERF) * 0.8); }
  const launchSpeed = (p) => 30 + 60 * clamp(p, 0.1, 1);

  /* ======================= physics ======================= */
  const slotOf = (n, i, rot) => (i + (rot | 0)) % n; // start spots rotate every round
  const rotOf = (s) => ((s.rid | 0) + (s.rd | 0)) % 12; // first spot set is random per match
  function newWorld(ar, n, tp, ln, rot) {
    const A = ARENAS[ar] || ARENAS[0], tops = [];
    for (let i = 0; i < n; i++) {
      const sp = spawnOf(A, n, slotOf(n, i, rot)), l = (ln && Array.isArray(ln[i])) ? ln[i] : [defaultAim(A, sp), 0.6, 0.55];
      const a = fin(+l[0]) ? +l[0] : defaultAim(A, sp), v = launchSpeed(fin(+l[1]) ? +l[1] : 0.6), q = clamp(fin(+l[2]) ? +l[2] : 0.55, 0.5, 1);
      tops.push({ s: i, t: clamp((tp && tp[i]) | 0, 0, 3), x: sp.x, y: sp.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, sp: 100 * q, q,
        al: 1, f: 0, fr: '', cd: 0.8, dt: 0, ld: null, by: -1, byT: 99 });
    }
    return { A, t: 0, tops, pc: {} };
  }
  const sud = (W) => (W.t > SUDDEN ? 1 + (W.t - SUDDEN) / 8 : 1);

  function nearestFoe(W, T) {
    let best = null, bd = 1e9;
    for (const o of W.tops) { if (o === T || !o.al) continue; const d = Math.hypot(o.x - T.x, o.y - T.y); if (d < bd) { bd = d; best = o; } }
    return best;
  }
  function tryDash(W, T, ix, iy, hooks) {
    if (T.cd > 0 || T.sp < 6) { if (hooks && hooks.nodash) hooks.nodash(T); return; }
    let dx = ix, dy = iy, m = Math.hypot(dx, dy);
    if (m < 0.2) { // no stick: toward the nearest top, else forward, else home
      const o = nearestFoe(W, T);
      if (o) { dx = o.x - T.x; dy = o.y - T.y; } else { dx = T.vx; dy = T.vy; }
      m = Math.hypot(dx, dy);
      if (m < 1e-3) { dx = homeX(W.A, T.x) - T.x; dy = -T.y; m = Math.hypot(dx, dy) || 1; }
    }
    const ty = TYPES[T.t], k = DASH * ty.dash / m;
    T.vx += dx * k; T.vy += dy * k;
    const v = Math.hypot(T.vx, T.vy); if (v > VCAP) { T.vx *= VCAP / v; T.vy *= VCAP / v; }
    T.sp -= DASH_COST; T.cd = DASH_CD; T.dt = DASH_T;
    if (hooks && hooks.dash) hooks.dash(T);
  }
  function knockOut(T, fr, hooks, W) {
    T.al = 0; T.fr = fr; T.f = 1e-3; T.ot = W ? W.t : 0;
    if (fr === 'o') { // keep flying outward so the fall reads clearly
      const ri = rimInfo({ shape: 'c', R: 1 }, T.x, T.y), vr = T.vx * ri.nx + T.vy * ri.ny;
      if (vr < 45) { T.vx += ri.nx * (45 - vr); T.vy += ri.ny * (45 - vr); }
    }
    if (hooks && hooks.out) hooks.out(T, fr, T.byT < 2.5 ? T.by : -1);
  }
  function stepTop(W, T, inp, h, hooks) {
    if (!T.al) {
      if (T.f > 0) {
        T.f += h;
        if (T.fr === 'o') { T.x += T.vx * h; T.y += T.vy * h; }
        else { T.vx *= 1 - Math.min(1, 4 * h); T.vy *= 1 - Math.min(1, 4 * h); T.x += T.vx * h; T.y += T.vy * h; }
      }
      return;
    }
    const ty = TYPES[T.t], A = W.A, wf = T.sp / 100;
    let ax = -A.G * (T.x - homeX(A, T.x)), ay = -A.G * T.y;
    const v = Math.hypot(T.vx, T.vy);
    let ix = 0, iy = 0;
    if (inp) { ix = clamp(+inp.x || 0, -1, 1); iy = clamp(+inp.y || 0, -1, 1); const m = Math.hypot(ix, iy); if (m > 1) { ix /= m; iy /= m; } }
    if (v > 0.5) { // the spinning tip drives the top along (toward its own cruising speed) and curls its path; the stick steers that drive
      let ux = T.vx / v, uy = T.vy / v;
      const tgt = ty.vt * (0.25 + 0.75 * wf);
      const al = (tgt - v) * (v > tgt ? ty.mu : 0.9);
      ax += ux * al; ay += uy * al;
      const tr = ty.curl * wf * v * (1 - 0.7 * Math.min(1, Math.hypot(ix, iy)));
      ax += -uy * tr; ay += ux * tr;
      if (ix || iy) { // turn the velocity toward the stick (keeps speed): steering, not raw thrust
        const side = (-uy * ix + ux * iy);
        ax += -uy * side * STEER * ty.ctl * Math.min(v, 70) / 70 * wf; ay += ux * side * STEER * ty.ctl * Math.min(v, 70) / 70 * wf;
      }
    }
    if (wf < 0.25) { const j = (0.25 - wf) * 150; ax += Math.cos(W.t * 7.3 + T.s * 2.1) * j; ay += Math.sin(W.t * 6.1 + T.s * 1.3) * j; } // wobbling
    if (inp) {
      ax += ix * CTRL * ty.ctl; ay += iy * CTRL * ty.ctl;
      if (inp.d != null) {
        if (T.ld == null) T.ld = inp.d;
        else if (inp.d !== T.ld) { T.ld = inp.d; tryDash(W, T, ix, iy, hooks); }
      }
    }
    T.vx += ax * h; T.vy += ay * h;
    T.x += T.vx * h; T.y += T.vy * h;
    if (T.cd > 0) T.cd -= h;
    if (T.dt > 0) T.dt -= h;
    T.byT += h;
    T.sp -= h * ty.dec * sud(W) * (1 + v / 250);
    const ri = rimInfo(A, T.x, T.y), rr = ty.r;
    if (ri.gap) { if (ri.d < 0) { knockOut(T, 'o', hooks, W); return; } }
    else if (ri.d < rr) {
      const vr = T.vx * ri.nx + T.vy * ri.ny;
      if (vr > A.esc * (W.t < GRACE ? (W.t < 2 ? 9 : 1 + (GRACE - W.t) * 0.5) : 1)) { knockOut(T, 'o', hooks, W); return; } // the first clash right after launch rarely rings anyone out
      T.x -= ri.nx * (rr - ri.d); T.y -= ri.ny * (rr - ri.d);
      if (vr > 0) {
        T.vx -= 1.5 * vr * ri.nx; T.vy -= 1.5 * vr * ri.ny;
        T.sp -= vr * 0.03;
        if (vr > 25 && hooks && hooks.rim) hooks.rim(T, vr);
      }
    }
    if (T.sp <= 0) { T.sp = 0; knockOut(T, 's', hooks, W); }
  }
  function collide(W, hooks) {
    const ts = W.tops, n = ts.length;
    for (let i = 0; i < n; i++) {
      const a = ts[i]; if (!a.al) continue;
      for (let j = i + 1; j < n; j++) {
        const b = ts[j]; if (!b.al) continue;
        const TA = TYPES[a.t], TB = TYPES[b.t];
        const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy), rs = TA.r + TB.r;
        if (d >= rs || d < 1e-6) continue;
        const nx = dx / d, ny = dy / d, ma = TA.m, mb = TB.m, ov = rs - d;
        a.x -= nx * ov * mb / (ma + mb); a.y -= ny * ov * mb / (ma + mb);
        b.x += nx * ov * ma / (ma + mb); b.y += ny * ov * ma / (ma + mb);
        const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        if (vn < 0) {
          const jj = -(1 + E_REST) * vn / (1 / ma + 1 / mb);
          a.vx -= nx * jj / ma; a.vy -= ny * jj / ma; b.vx += nx * jj / mb; b.vy += ny * jj / mb;
        }
        const key = i * 8 + j, last = W.pc[key] == null ? -9 : W.pc[key];
        if (W.t - last < PAIR_GAP) continue;
        W.pc[key] = W.t;
        // spin clash: both tops spin the same way, so at the contact their edges rub in opposite directions → they burst apart
        const imp = clamp(-vn, 0, 220), wa = a.sp / 100, wb = b.sp / 100, sk = 0.15 + Math.min(1.4, imp / 70);
        const hitA = CLASH * TA.atk * (0.3 + 0.7 * wa) * sk * (a.dt > 0 ? 1.45 : 1);
        const hitB = CLASH * TB.atk * (0.3 + 0.7 * wb) * sk * (b.dt > 0 ? 1.45 : 1);
        const tx = -ny, ty = nx;
        b.vx += (nx + tx * 0.3) * hitA / mb; b.vy += (ny + ty * 0.3) * hitA / mb;
        a.vx -= (nx + tx * 0.3) * hitB / ma; a.vy -= (ny + ty * 0.3) * hitB / ma;
        for (const q of [a, b]) { const v = Math.hypot(q.vx, q.vy); if (v > VCAP) { q.vx *= VCAP / v; q.vy *= VCAP / v; } }
        const dmg = Math.min(1.5, 0.08 + imp / 70); // grinding barely hurts, real hits do
        a.sp -= SPIN_HIT * (hitB / CLASH) * dmg / TA.def;
        b.sp -= SPIN_HIT * (hitA / CLASH) * dmg / TB.def;
        if (a.sp <= 0 && b.sp <= 0 && a.sp !== b.sp) { if (a.sp > b.sp) a.sp = 0.5; else b.sp = 0.5; } // a clash that empties both: the one with more left keeps spinning a moment
        a.by = b.s; a.byT = 0; b.by = a.s; b.byT = 0;
        if (hooks && hooks.clash) hooks.clash(a, b, imp + (hitA + hitB) * 0.35, (a.x + b.x) / 2, (a.y + b.y) / 2);
        for (const q of [a, b]) if (q.al && q.sp <= 0) { q.sp = 0; knockOut(q, 's', hooks, W); }
      }
    }
  }
  function stepWorld(W, inputs, hooks) {
    W.t += H;
    for (const T of W.tops) stepTop(W, T, inputs ? inputs[T.s] : null, H, hooks);
    collide(W, hooks);
  }

  /* round decided? → {w: seat or -1 (draw)} or null. Several tops out at once: the one that went out last wins. */
  function roundWinner(W) {
    const alive = W.tops.filter((T) => T.al);
    if (alive.length === 1) return { w: alive[0].s };
    if (!alive.length) {
      const last = Math.max(...W.tops.map((T) => T.ot || 0)), top = W.tops.filter((T) => (T.ot || 0) > last - H / 2);
      return { w: top.length === 1 ? top[0].s : -1 };
    }
    if (W.t > CAP_T) { alive.sort((a, b) => b.sp - a.sp); return { w: alive[0].sp - alive[1].sp > 0.5 ? alive[0].s : -1 }; }
    return null;
  }

  /* ======================= AI ======================= */
  function norm(x, y) { const m = Math.hypot(x, y) || 1; return { x: x / m, y: y / m, m }; }
  function aiThink(W, T, mem, lv, dt, rnd) {
    rnd = rnd || Math.random;
    const o = mem.o || (mem.o = { x: 0, y: 0, d: 0 });
    mem.t = (mem.t || 0) - dt;
    if (mem.t > 0 || !T.al) return o;
    mem.t = lv >= 3 ? 0.07 : lv === 2 ? 0.15 : 0.3 + rnd() * 0.25;
    const A = W.A, ty = TYPES[T.t], hx = homeX(A, T.x);
    const ri = rimInfo(A, T.x, T.y), rd = ri.d - ty.r, vr = T.vx * ri.nx + T.vy * ri.ny;
    const toHome = norm(hx - T.x, -T.y);
    let x = 0, y = 0, dash = null;
    // choose a target
    let tgt = null, best = -1e9;
    for (const e of W.tops) {
      if (e === T || !e.al) continue;
      const d = Math.hypot(e.x - T.x, e.y - T.y);
      let sc = -d * 0.02;
      if (lv >= 3) { const er = rimInfo(A, e.x, e.y).d; sc += (1 - er / A.R) * 2 + (1 - e.sp / 100) + (beats(T.t, e.t) ? 0.6 : 0); }
      if (sc > best) { best = sc; tgt = e; }
    }
    const low = T.sp < (lv >= 3 ? 22 : 12);
    // attack/balance hunt; defense also hunts when it is losing the spin race; stamina only survives
    const hunt = !low && (T.t === 0 || T.t === 3 || (T.t === 1 && tgt && tgt.sp > T.sp + (lv >= 3 ? 5 : 15)));
    const rimSafe = (ux, uy, dist, margin) => rimInfo(A, T.x + ux * dist, T.y + uy * dist).d > margin;
    if (lv === 1) { // beginner: wanders, dashes on a whim, often forgets about the rim
      if (rnd() < 0.25) { const a = rnd() * 6.283; mem.wx = Math.cos(a) * 0.6; mem.wy = Math.sin(a) * 0.6; }
      x = mem.wx || 0; y = mem.wy || 0;
      if (rd < 14 && rnd() < 0.5) { x = toHome.x; y = toHome.y; }
      if (tgt && T.cd <= 0 && T.sp > 10 && rnd() < 0.12) { const a = Math.atan2(tgt.y - T.y, tgt.x - T.x) + (rnd() * 2 - 1) * 0.8; dash = { x: Math.cos(a), y: Math.sin(a) }; }
    } else {
      if (hunt && tgt) {
        let px = tgt.x, py = tgt.y;
        if (lv >= 3) { // get on the inner side of the target, then hit it outward
          const th = homeX(A, tgt.x), od = norm(tgt.x - th, tgt.y), back = ty.r + TYPES[tgt.t].r + 6;
          if (od.m > 8) { px = tgt.x - od.x * back; py = tgt.y - od.y * back; if (Math.hypot(px - T.x, py - T.y) < 10) { px = tgt.x; py = tgt.y; } }
        }
        const d = norm(px - T.x, py - T.y); x = d.x * 0.85; y = d.y * 0.85;
      } else {
        const dh = Math.hypot(hx - T.x, T.y);
        if (dh > 12) { const k = Math.min(1, dh / 40); x = toHome.x * k; y = toHome.y * k; }
        if (lv >= 3 && tgt) { // dodge a fast incoming top
          const d = norm(tgt.x - T.x, tgt.y - T.y), closing = (tgt.vx - T.vx) * -d.x + (tgt.vy - T.vy) * -d.y;
          if (d.m < 48 && closing > 35) {
            let px = -d.y, py = d.x; if (px * toHome.x + py * toHome.y < 0) { px = -px; py = -py; }
            x = px; y = py;
            if (T.t === 2 && d.m < 28 && T.cd <= 0 && T.sp > 20 && rimSafe(px, py, 45, 25)) dash = { x: px, y: py };
          }
        }
      }
      if (rd < (lv >= 3 ? 34 : 26) || (lv >= 3 && vr > 45 && rd < 55)) { x = toHome.x; y = toHome.y; }
      if (!dash && tgt && T.cd <= 0 && !low && T.sp > 15) {
        const d = norm(tgt.x - T.x, tgt.y - T.y);
        if (d.m < (lv >= 3 ? 60 : 45)) {
          const outward = (tgt.x - homeX(A, tgt.x)) * d.x + tgt.y * d.y > 0;   // hitting it pushes it toward the rim
          const safe = rimSafe(d.x, d.y, lv >= 3 ? 50 : 35, lv >= 3 ? 25 : 10);
          if (hunt && outward && safe && (lv >= 3 || rnd() < 0.45)) dash = { x: d.x, y: d.y };
          else if (!hunt && lv >= 3 && T.t === 1 && outward && safe && d.m < 35) dash = { x: d.x, y: d.y };
        }
      }
    }
    if (lv === 1) { x *= 0.7; y *= 0.7; }
    const m = Math.hypot(x, y); if (m > 1) { x /= m; y /= m; }
    if (dash) { x = dash.x; y = dash.y; o.d = (o.d + 1) % 1000; }
    o.x = r2(x); o.y = r2(y);
    return o;
  }
  function aiLaunch(A, n, seat, type, lv, rnd, rot) {
    rnd = rnd || Math.random;
    const sp = spawnOf(A, n, slotOf(n, seat, rot)), base = defaultAim(A, sp);
    let err, da, p;
    if (lv <= 1) { err = (rnd() * 2 - 1) * 0.5; da = (rnd() * 2 - 1) * 0.7; p = 0.3 + rnd() * 0.7; }
    else if (lv === 2) { err = (rnd() * 2 - 1) * 0.22; da = (rnd() * 2 - 1) * 0.3; p = 0.5 + rnd() * 0.3; }
    else { err = (rnd() * 2 - 1) * 0.07; da = (type === 0 ? 0.35 : type === 3 ? 0.2 : 0) + (rnd() * 2 - 1) * 0.08; p = [0.85, 0.5, 0.35, 0.65][type] + (rnd() * 2 - 1) * 0.05; }
    return [r2(base + da), r2(p), r2(qualityOf(Math.abs(err)))];
  }
  function aiPick(lv, rnd) {
    rnd = rnd || Math.random;
    if (lv === 2) { const r = rnd() * 4.4; return r < 1 ? 0 : r < 2 ? 1 : r < 3 ? 2 : 3; }
    return Math.floor(rnd() * 4) % 4;
  }
  function counterPick(tp, seat, rnd) { // 어려움 AI: 상성이 가장 좋은 팽이
    rnd = rnd || Math.random;
    let best = -1e9, pick = 3;
    for (let x = 0; x < 4; x++) {
      let sc = (x === 3 ? 0.2 : 0) + rnd() * 0.1;
      tp.forEach((y, i) => { if (i !== seat) sc += beats(x, y) ? 1 : beats(y, x) ? -1 : 0; });
      if (sc > best) { best = sc; pick = x; }
    }
    return pick;
  }

  /* ======================= pure game interface ======================= */
  function hexRGB(hex) { const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return null; const n = parseInt(m[1], 16); return [n >> 16, (n >> 8) & 255, n & 255]; }
  function assignColors(players) {
    const used = new Set();
    return players.map((p, i) => {
      const c = hexRGB(p && p.color);
      let best = -1, bd = 1e12;
      COLORS.forEach((k, j) => {
        if (used.has(j)) return;
        const q = hexRGB(k), d = c ? (c[0] - q[0]) ** 2 + (c[1] - q[1]) ** 2 + (c[2] - q[2]) ** 2 : Math.abs(j - i);
        if (d < bd) { bd = d; best = j; }
      });
      if (best < 0) best = i % COLORS.length;
      used.add(best);
      return best;
    });
  }
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    const ao = fin(o.arena) && o.arena >= 0 && o.arena < ARENAS.length ? o.arena : -1;
    return {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      b: o.rounds === 5 ? 5 : 3, ao, ar: ao >= 0 ? ao : U.rand(ARENAS.length), rd: 1, ph: 'pick',
      wins: Array(n).fill(0), tp: players.map((p) => (p && p.ai ? aiPick(p.lv || 2) : 3)), cl: assignColors(players),
      rdy: players.map((p) => (p && p.ai ? 1 : 0)), ln: null, rw: -1, res: null,
    };
  }
  function startLaunch(s, lvs, rnd) {
    const tp = s.tp.slice(), seen = s.tp.slice(); // all 어려움 AIs counter the same snapshot (no seat-order advantage)
    (lvs || []).forEach((lv, i) => { if (lv === 3) tp[i] = counterPick(seen, i, rnd); });
    return Object.assign({}, s, { ph: 'launch', tp, ln: null });
  }
  function startPlay(s, ln) { return Object.assign({}, s, { ph: 'play', ln: ln.map((l) => [r2(l[0]), r2(l[1]), r2(l[2])]) }); }
  function roundOver(s, winner) {
    const n = Object.assign({}, s, { wins: (s.wins || []).slice(), ph: 'end', rw: winner });
    if (winner >= 0) n.wins[winner] = (n.wins[winner] | 0) + 1;
    return n;
  }
  function nextRound(s, lvs, rnd) {
    rnd = rnd || Math.random;
    const need = Math.floor(s.b / 2) + 1, mx = Math.max(...s.wins);
    if (mx >= need || s.rd >= s.b * 2 + 1) {
      const order = s.wins.map((v, i) => [i, v]).sort((a, b) => b[1] - a[1] || a[0] - b[0]);
      return Object.assign({}, s, { ph: 'done', res: order });
    }
    let ar = s.ar;
    if (s.ao < 0) { ar = Math.floor(rnd() * (ARENAS.length - 1)); if (ar >= s.ar) ar++; }
    const tp = s.tp.slice(), rdy = s.rdy.map(() => 0);
    (lvs || []).forEach((lv, i) => {
      if (!lv) return;
      rdy[i] = 1;
      if (lv === 1 || (lv === 2 && rnd() < 0.3)) tp[i] = aiPick(lv, rnd);
    });
    return Object.assign({}, s, { rd: s.rd + 1, ph: 'pick', ar, tp, rdy, ln: null, rw: -1 });
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + ' (' + TYPES[s.tp[r[0]] | 0].nm + ')  ' + r[1] + '승');
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승',
      text: (s.ao >= 0 ? ARENAS[s.ao].name : '무작위 경기장') + ' · ' + (s.b === 5 ? '5판 3선승' : '3판 2선승') + '\n' + lines.join('\n') };
  }

  /* ======================= drawing helpers ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) { const c = hexRGB(hex); return c ? 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')' : hex; }
  const shadeCache = {};
  function shade(hex, k) {
    const key = hex + k; if (shadeCache[key]) return shadeCache[key];
    const c = hexRGB(hex); if (!c) return hex;
    const f = (v) => Math.round(k >= 0 ? v + (255 - v) * k : v * (1 + k));
    return (shadeCache[key] = 'rgb(' + f(c[0]) + ',' + f(c[1]) + ',' + f(c[2]) + ')');
  }
  /* one top seen from above, centred at 0,0, radius R (px), rotated by ang */
  function topArt(g, type, col, R, ang) {
    const dark = shade(col, -0.5), light = shade(col, 0.4);
    g.beginPath(); g.arc(0, 0, R * 0.97, 0, 7); g.fillStyle = '#8d939c'; g.fill();
    g.save(); g.rotate(ang);
    g.lineJoin = 'round';
    if (type === 0) { // 공격형: three swept blades
      g.beginPath(); g.arc(0, 0, R * 0.62, 0, 7); g.fillStyle = dark; g.fill();
      g.fillStyle = col; g.strokeStyle = dark; g.lineWidth = Math.max(1, R * 0.07);
      for (let k = 0; k < 3; k++) {
        g.rotate(2.0944);
        g.beginPath(); g.moveTo(R * 0.15, -R * 0.52); g.quadraticCurveTo(R * 0.98, -R * 0.62, R * 1.03, -R * 0.02);
        g.lineTo(R * 0.6, R * 0.3); g.quadraticCurveTo(R * 0.44, -R * 0.06, R * 0.15, -R * 0.52); g.closePath(); g.fill(); g.stroke();
      }
    } else if (type === 1) { // 방어형: heavy ring with six bumpers
      g.beginPath(); g.arc(0, 0, R * 0.86, 0, 7); g.fillStyle = col; g.fill(); g.lineWidth = R * 0.08; g.strokeStyle = dark; g.stroke();
      g.fillStyle = light; g.lineWidth = R * 0.06;
      for (let k = 0; k < 6; k++) { const a = k * 1.0472; g.beginPath(); g.arc(Math.cos(a) * R * 0.82, Math.sin(a) * R * 0.82, R * 0.2, 0, 7); g.fill(); g.stroke(); }
      g.beginPath(); g.arc(0, 0, R * 0.58, 0, 7); g.fillStyle = dark; g.fill();
    } else if (type === 2) { // 지구력형: wide thin disc with fine ridges
      g.beginPath(); g.arc(0, 0, R, 0, 7); g.fillStyle = col; g.fill(); g.strokeStyle = dark; g.lineWidth = R * 0.05; g.stroke();
      g.beginPath();
      for (let k = 0; k < 12; k++) { const a = k * 0.5236; g.moveTo(Math.cos(a) * R * 0.66, Math.sin(a) * R * 0.66); g.lineTo(Math.cos(a + 0.16) * R * 0.97, Math.sin(a + 0.16) * R * 0.97); }
      g.strokeStyle = light; g.lineWidth = R * 0.07; g.stroke();
      g.beginPath(); g.arc(0, 0, R * 0.5, 0, 7); g.fillStyle = dark; g.fill();
    } else { // 균형형: four rounded lobes
      g.fillStyle = col; g.strokeStyle = dark; g.lineWidth = R * 0.07;
      for (let k = 0; k < 4; k++) { const a = k * 1.5708 + 0.785; g.beginPath(); g.arc(Math.cos(a) * R * 0.52, Math.sin(a) * R * 0.52, R * 0.45, 0, 7); g.fill(); g.stroke(); }
      g.beginPath(); g.arc(0, 0, R * 0.6, 0, 7); g.fillStyle = shade(col, -0.25); g.fill();
    }
    // hub with a brass mark that shows the rotation
    g.beginPath(); g.arc(0, 0, R * 0.3, 0, 7); g.fillStyle = '#f2e9d8'; g.fill(); g.lineWidth = R * 0.05; g.strokeStyle = 'rgba(23,19,31,.55)'; g.stroke();
    g.beginPath(); g.moveTo(0, 0); g.lineTo(R * 0.24, 0); g.strokeStyle = '#c4892a'; g.lineWidth = R * 0.11; g.lineCap = 'round'; g.stroke();
    g.restore();
    // gloss (does not rotate)
    g.beginPath(); g.arc(0, 0, R * 0.8, -2.7, -1.5); g.strokeStyle = 'rgba(255,255,255,.32)'; g.lineWidth = R * 0.12; g.lineCap = 'round'; g.stroke();
  }
  function arenaPath(g, A, inset) {
    g.beginPath();
    if (A.shape === 'c') g.arc(0, 0, A.R - inset, 0, Math.PI * 2);
    else if (A.shape === 'o') {
      const R = A.R - inset / Math.cos(Math.PI / 8);
      for (let k = 0; k < 8; k++) { const a = Math.PI / 8 + k * Math.PI / 4; if (k) g.lineTo(Math.cos(a) * R, Math.sin(a) * R); else g.moveTo(Math.cos(a) * R, Math.sin(a) * R); }
      g.closePath();
    } else { const R = A.R - inset; g.arc(-A.hw, 0, R, Math.PI / 2, Math.PI * 1.5); g.arc(A.hw, 0, R, -Math.PI / 2, Math.PI / 2); g.closePath(); }
  }
  function lcg(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  /* static arena art in world units (g already transformed: origin = arena centre, 1 unit = 1 world unit) */
  function drawArenaArt(g, A) {
    const p = A.pal;
    // drop shadow + outer lip
    g.save(); g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = 16; g.shadowOffsetY = 5; arenaPath(g, A, -10); g.fillStyle = p.rim1; g.fill(); g.restore();
    const lg = g.createLinearGradient(0, -A.R - 10, 0, A.R + 10); lg.addColorStop(0, p.rim0); lg.addColorStop(1, p.rim1);
    arenaPath(g, A, -10); g.fillStyle = lg; g.fill();
    arenaPath(g, A, -10); g.lineWidth = 1.2; g.strokeStyle = 'rgba(0,0,0,.45)'; g.stroke();
    arenaPath(g, A, -8.5); g.lineWidth = 0.8; g.strokeStyle = 'rgba(255,255,255,.28)'; g.stroke();
    // bowl surface (light centre → dark edge sells the concave dish)
    const wells = A.shape === 's' ? [-A.hw, A.hw] : [0];
    arenaPath(g, A, 0); g.fillStyle = p.b2; g.fill();
    g.save(); arenaPath(g, A, 0); g.clip();
    const reach = A.shape === 'o' ? A.R * 1.05 : A.R;
    for (const cx of wells) {
      g.save();
      if (A.shape === 's') { g.beginPath(); g.rect(cx < 0 ? -A.hw - A.R - 2 : 0, -A.R - 2, A.hw + A.R + 2, A.R * 2 + 4); g.clip(); } // each well shades its own half
      const rg = g.createRadialGradient(cx - reach * 0.18, -reach * 0.22, 2, cx, 0, reach * (A.shape === 's' ? 1.15 : 1));
      rg.addColorStop(0, p.b0); rg.addColorStop(0.62, p.b1); rg.addColorStop(1, p.b2);
      g.fillStyle = rg; g.fillRect(cx - reach * 1.2, -reach * 1.2, reach * 2.4, reach * 2.4);
      g.restore();
    }
    if (A.shape === 's') { // ridge between the wells
      const rg = g.createLinearGradient(-14, 0, 14, 0); rg.addColorStop(0, 'rgba(0,0,0,0)'); rg.addColorStop(0.5, 'rgba(255,255,255,.18)'); rg.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = rg; g.fillRect(-14, -A.R, 28, A.R * 2);
    }
    // grain / grooves
    const rnd = lcg(A.id.length * 977 + A.R);
    g.strokeStyle = p.line; g.lineWidth = 0.7;
    if (A.id === 'dish') { for (let r = 9; r < A.R; r += 5 + rnd() * 6) { g.beginPath(); g.ellipse(rnd() * 2 - 1, rnd() * 2 - 1, r, r * (0.96 + rnd() * 0.06), rnd() * 3, 0, 7); g.stroke(); } }
    else if (A.shape === 's') { for (const cx of wells) for (let r = 14; r < A.R; r += 14) { g.beginPath(); g.arc(cx, 0, r, 0, 7); g.stroke(); } }
    else { for (let k = 1; k <= 3; k++) { arenaPath(g, A, A.R * (1 - k * 0.24)); g.stroke(); } }
    if (A.id === 'oct') { // brushed steel lines + rivets
      g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 0.6;
      for (let y = -A.R; y < A.R; y += 3) { g.beginPath(); g.moveTo(-A.R, y + rnd()); g.lineTo(A.R, y + rnd()); g.stroke(); }
    }
    if (A.id === 'deep') { // glaze sparkle
      for (let i = 0; i < 40; i++) { const a = rnd() * 7, r = rnd() * A.R * 0.95; g.fillStyle = 'rgba(255,255,255,' + (0.05 + rnd() * 0.12) + ')'; g.fillRect(Math.cos(a) * r, Math.sin(a) * r, 0.8, 0.8); }
    }
    // inner shadow along the rim
    g.lineWidth = 12; g.strokeStyle = 'rgba(0,0,0,.3)'; arenaPath(g, A, -5); g.stroke();
    g.lineWidth = 4; g.strokeStyle = 'rgba(0,0,0,.25)'; arenaPath(g, A, -1.5); g.stroke();
    g.restore();
    // centre marks
    for (const cx of wells) { g.beginPath(); g.arc(cx, 0, 3, 0, 7); g.fillStyle = 'rgba(255,255,255,.18)'; g.fill(); g.beginPath(); g.arc(cx, 0, 7, 0, 7); g.lineWidth = 0.7; g.strokeStyle = 'rgba(255,255,255,.14)'; g.stroke(); }
    // rim highlight
    g.save(); g.lineWidth = 2; g.strokeStyle = 'rgba(255,255,255,.35)'; g.setLineDash([]);
    if (A.shape === 'c') { g.beginPath(); g.arc(0, 0, A.R + 5, -2.7, -1.2); g.stroke(); }
    g.restore();
    if (A.id === 'oct') { // rivets on the rim + exit chutes
      g.fillStyle = 'rgba(255,230,220,.55)';
      for (let k = 0; k < 8; k++) { const a = Math.PI / 8 + k * Math.PI / 4, R = A.R + 5; g.beginPath(); g.arc(Math.cos(a) * R, Math.sin(a) * R, 1.3, 0, 7); g.fill(); }
      const ap = A.R * Math.cos(Math.PI / 8);
      for (let k = 1; k < 8; k += 2) {
        const a = k * Math.PI / 4;
        g.save(); g.rotate(a);
        g.fillStyle = '#0d0a12'; g.fillRect(ap - 0.5, -A.gw, 14, A.gw * 2);
        g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1; g.strokeRect(ap - 0.5, -A.gw, 14, A.gw * 2);
        g.strokeStyle = 'rgba(238,106,85,.75)'; g.lineWidth = 1.6; g.lineCap = 'round';
        g.beginPath(); g.moveTo(ap + 3, -5); g.lineTo(ap + 9, 0); g.lineTo(ap + 3, 5); g.stroke();
        g.fillStyle = 'rgba(238,106,85,.9)'; g.fillRect(ap - 1.5, -A.gw - 1.5, 3, 3); g.fillRect(ap - 1.5, A.gw - 1.5, 3, 3);
        g.restore();
      }
    }
  }

  /* ======================= view ======================= */
  const CSS = `
.tp-pick{position:absolute;left:0;right:0;bottom:0;z-index:8;padding:10px 12px calc(10px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.95) 14px);display:flex;flex-direction:column;gap:7px;user-select:none;-webkit-user-select:none}
.tp-head{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;padding-top:6px}
.tp-head h3{margin:0;font-family:var(--f-display,"Black Han Sans"),sans-serif;font-weight:400;font-size:21px;color:var(--ink,#f2e9d8)}
.tp-ar{font-size:12px;color:var(--muted,#ab9fb8)}
.tp-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.tp-card{appearance:none;display:grid;grid-template-columns:44px 1fr;gap:7px;align-items:center;text-align:left;border:1.5px solid rgba(242,233,216,.14);background:rgba(46,38,64,.94);color:var(--ink,#f2e9d8);border-radius:12px;padding:6px 8px;min-height:66px;cursor:pointer;touch-action:manipulation;font:inherit}
.tp-card:active{transform:scale(.97)}
.tp-card.on{border-color:var(--brass,#e3ae45);background:rgba(227,174,69,.2)}
.tp-card canvas{width:44px;height:44px;display:block}
.tp-card b{font-size:13px;display:block;margin-bottom:2px;font-weight:700}
.tp-stat{display:grid;grid-template-columns:31px 1fr;align-items:center;font-size:9.5px;color:var(--muted,#ab9fb8);line-height:11px;white-space:nowrap}
.tp-pips{display:flex;gap:2px}
.tp-pips i{width:9px;height:5px;border-radius:2px;background:rgba(242,233,216,.16)}
.tp-pips i.on{background:var(--brass,#e3ae45)}
.tp-desc{font-size:12px;color:var(--ink,#f2e9d8);min-height:32px;line-height:1.35;word-break:keep-all}
.tp-desc em{font-style:normal;color:var(--brass,#e3ae45);font-weight:700}
.tp-sw{display:grid;grid-template-columns:repeat(6,1fr);gap:6px}
.tp-c{appearance:none;min-height:44px;border-radius:12px;border:2px solid rgba(242,233,216,.18);background:var(--c);cursor:pointer;touch-action:manipulation;position:relative;padding:0}
.tp-c.on{border-color:#f2e9d8;box-shadow:0 0 0 2px var(--brass,#e3ae45)}
.tp-c:disabled{opacity:.22;cursor:default}
.tp-c.on::after{content:'✓';position:absolute;inset:0;display:grid;place-items:center;color:#17131f;font-weight:900;font-size:16px}
.tp-foot{display:flex;align-items:center;gap:8px}
.tp-st{flex:1;font-size:12px;color:var(--muted,#ab9fb8);line-height:1.3;word-break:keep-all}
.tp-foot .btn{min-height:48px;min-width:128px}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1); // one person per phone
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const lvOf = (s) => (P(s).ai ? (P(s).lv || 2) : 2);
    let st = null, key = null, phKey = '', W = null, lay = null, tgtLay = null, bg = null, bgKey = '', bgGrad = null;
    let phT = 0, endT = 0, acc = 0, pickT = 0, hostT = 0;
    let launched = {}, aim = {}, pull = null, lastLaunchMsg = null, earlyT = 0, myLabel = null;
    let aiMem = [], inputs = {}, parts = [], floats = [], rings = [], shake = 0, lastSfx = 0, hintT = 0, hintKind = '';
    const vis = []; // per seat: {ang, w, prec}
    const locIn = {}; // seat -> {x, y, d}
    let pubT = 0, hsQ = 0, inQ = 0, lastSig = '', inT = 0, snaps = [], lastQ = -1, lastBm = -1, lastEvQ = -1, pickSent = '', pickSendT = 0;
    const remIn = {};
    let pick = null, guestPend = null;
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const colOf = (s) => COLORS[(st && st.cl && st.cl[s]) | 0] || P(s).color || '#e3ae45';

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h;
      const A = ARENAS[st ? st.ar : 0] || ARENAS[0], B = arenaBox(A);
      const top = 80;
      let bot = 16;
      if (pick && pick.el.isConnected) bot = pick.el.offsetHeight + 4;
      else if (mine().length && st && (st.ph === 'launch' || st.ph === 'play' || st.ph === 'end')) bot = 134;
      const s = Math.max(0.4, Math.min((w - 22) / (B.w + 22), (h - top - bot) / (B.h + 22)));
      tgtLay = { s, cx: w / 2, cy: top + (h - top - bot) / 2 };
      if (!lay) lay = Object.assign({}, tgtLay);
      bgGrad = null;
    }
    cv.onresize = () => { layout(); lay = Object.assign({}, tgtLay); };
    const X = (x) => lay.cx + x * lay.s, Y = (y) => lay.cy + y * lay.s;
    function ensureBg() {
      if (!st || !tgtLay) return;
      const A = ARENAS[st.ar] || ARENAS[0], B = arenaBox(A), dpr = Math.min(2, cv.dpr || 1), s = tgtLay.s;
      const k = A.id + '|' + s.toFixed(3) + '|' + dpr;
      if (k === bgKey && bg) return;
      bgKey = k;
      const m = 24, bw = (B.w + m * 2) * s, bh = (B.h + m * 2) * s;
      bg = bg || document.createElement('canvas');
      bg.width = Math.ceil(bw * dpr); bg.height = Math.ceil(bh * dpr);
      const g = bg.getContext('2d');
      g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, bg.width, bg.height);
      g.setTransform(s * dpr, 0, 0, s * dpr, bw * dpr / 2, bh * dpr / 2);
      drawArenaArt(g, A);
      bg.wu = B.w + m * 2; bg.hu = B.h + m * 2;
    }

    /* ----- round / phase changes ----- */
    function enterPhase(ph, prevPh) {
      phT = 0;
      if (ph === 'pick') {
        W = newWorld(st.ar, st.n, st.tp, null, rotOf(st)); W.preview = 1;
        launched = {}; aim = {}; pull = null; lastLaunchMsg = null; myLabel = null; pickT = 0; hostT = 0; guestPend = null;
        parts = []; floats = []; rings = [];
      } else if (ph === 'launch') {
        if (!W || !W.preview) { W = newWorld(st.ar, st.n, st.tp, null, rotOf(st)); W.preview = 1; }
        launched = {}; pull = null; lastLaunchMsg = null; myLabel = null; earlyT = 0;
        for (const s of mine()) { const sp = spawnOf(W.A, st.n, slotOf(st.n, s, rotOf(st))); aim[s] = { a: defaultAim(W.A, sp), p: 0.6 }; }
        if (mine().length && (st.rd === 1 || !hintKind)) { hintT = 99; hintKind = 'launch'; }
        api.sfx('click');
      } else if (ph === 'play') {
        W = newWorld(st.ar, st.n, st.tp, st.ln, rotOf(st));
        aiMem = W.tops.map(() => ({})); inputs = {}; snaps = []; lastQ = -1; acc = 0; pull = null;
        for (const s of mine()) locIn[s] = { x: 0, y: 0, d: (locIn[s] && locIn[s].d) || 0 };
        W.tops.forEach((T) => {
          const q = T.q, lb = q >= 1 ? '퍼펙트!' : q >= 0.88 ? '좋아요' : q >= 0.7 ? '' : '약해요';
          if (lb) floats.push({ x: T.x, y: T.y, text: lb, col: q >= 1 ? '#ffe08a' : '#f2e9d8', t: 1.3 });
          rings.push({ x: T.x, y: T.y, r0: 6, r1: 26, t: 0.4, T: 0.4, col: colOf(T.s) });
        });
        api.sfx('whoosh'); api.buzz(25); shake = 0.4;
        if (mine().length && st.rd === 1) { hintT = 5; hintKind = 'play'; } else if (hintKind === 'launch') hintT = 0;
      } else if (ph === 'end') {
        endT = END_T;
        if (st.rw >= 0 && isMine(st.rw)) { api.sfx('win'); api.buzz(60); } else if (mine().length) api.sfx(st.rw >= 0 ? 'lose' : 'chip'); else api.sfx('chip');
      }
      void prevPh;
      layout();
    }

    /* ----- picker (DOM) ----- */
    function curPick(seat) {
      const base = { tp: st.tp[seat] | 0, cl: st.cl[seat] | 0, r: st.rdy[seat] ? 1 : 0 };
      return guestPend ? Object.assign(base, guestPend) : base;
    }
    function takenBy(cl, seat) { return st.cl.some((c, i) => i !== seat && c === cl); }
    function choose(patch) {
      const seat = mine()[0]; if (seat == null || !st || st.ph !== 'pick') return;
      const cur = curPick(seat), nx = Object.assign({}, cur, patch);
      if (patch.cl != null && takenBy(patch.cl, seat)) { api.buzz(8); return; }
      api.sfx('click'); api.buzz(10);
      if (host()) {
        const ns = Object.assign({}, st, { tp: st.tp.slice(), cl: st.cl.slice(), rdy: st.rdy.slice() });
        ns.tp[seat] = nx.tp; ns.cl[seat] = nx.cl; ns.rdy[seat] = nx.r;
        api.setState(ns);
      } else { guestPend = nx; pickSent = ''; syncPicker(); }
    }
    function buildPicker() {
      const seat = mine()[0];
      if (pick || seat == null || !st) return;
      const ar = L.h('span', { class: 'tp-ar' });
      const grid = L.h('div', { class: 'tp-grid' });
      const cards = TYPES.map((T, i) => {
        const c = L.h('canvas', { width: 88, height: 88 });
        const stats = T.st.map((v, k) => L.h('div', { class: 'tp-stat' }, L.h('span', { text: STAT_NM[k] }),
          L.h('span', { class: 'tp-pips' }, ...[0, 1, 2, 3, 4].map((j) => L.h('i', { class: j < v ? 'on' : '' })))));
        const btn = L.h('button', { class: 'tp-card', type: 'button', 'aria-label': T.nm, onclick() { choose({ tp: i }); } }, c, L.h('div', {}, L.h('b', { text: T.nm }), ...stats));
        grid.append(btn);
        return { btn, c, col: '' };
      });
      const desc = L.h('div', { class: 'tp-desc' });
      const sw = L.h('div', { class: 'tp-sw' });
      const sws = COLORS.map((col, i) => { const b = L.h('button', { class: 'tp-c', type: 'button', style: { '--c': col }, 'aria-label': COLOR_NM[i] + ' 색', onclick() { choose({ cl: i }); } }); sw.append(b); return b; });
      const stEl = L.h('span', { class: 'tp-st' });
      const go = L.h('button', { class: 'btn primary', type: 'button', onclick() { const c = curPick(mine()[0]); choose({ r: c.r ? 0 : 1 }); } });
      const el = L.h('div', { class: 'tp-pick' }, L.h('div', { class: 'tp-head' }, L.h('h3', { text: '팽이 고르기' }), ar), grid, desc, sw, L.h('div', { class: 'tp-foot' }, stEl, go));
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el, ar, cards, desc, sws, stEl, go };
      syncPicker();
      layout();
    }
    function syncPicker() {
      if (!pick || !st) return;
      const seat = mine()[0]; if (seat == null) return;
      const c = curPick(seat), col = COLORS[c.cl] || '#e3ae45', A = ARENAS[st.ar] || ARENAS[0];
      pick.ar.textContent = '라운드 ' + st.rd + ' · ' + A.name;
      pick.cards.forEach((k, i) => {
        k.btn.classList.toggle('on', i === c.tp);
        if (k.col !== col) { k.col = col; const g = k.c.getContext('2d'); g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, 88, 88); g.translate(44, 44); topArt(g, i, col, 38, -0.4); }
      });
      const T = TYPES[c.tp], strong = TYPES.find((_, j) => beats(c.tp, j)), weak = TYPES.find((_, j) => beats(j, c.tp));
      pick.desc.innerHTML = '';
      pick.desc.append(L.h('em', { text: T.nm }), ' · ' + T.sub + (strong ? ' · ' + strong.nm + '에 강하고 ' + weak.nm + '에 약해요' : ' · 상성 없이 무난해요'));
      pick.sws.forEach((b, i) => { b.classList.toggle('on', i === c.cl); b.disabled = takenBy(i, seat); });
      pick.go.textContent = c.r ? '준비 취소' : api.online ? '준비 완료' : '시작!';
      pick.go.classList.toggle('primary', !c.r);
      syncPickStatus();
    }
    function autoPickT() { return st.rd === 1 ? (api.online ? 45 : 0) : 12; }
    function syncPickStatus() {
      if (!pick || !st) return;
      const seat = mine()[0], c = curPick(seat), at = autoPickT(), left = Math.max(0, Math.ceil(at - pickT));
      let t = '';
      if (api.online) {
        let ready = 0, all = 0;
        for (let i = 0; i < st.n; i++) { if (P(i).ai) continue; all++; if (st.rdy[i] || (i === seat && c.r)) ready++; }
        t = c.r ? '다른 사람 기다리는 중 (준비 ' + ready + '/' + all + ')' : '팽이와 색을 고르고 준비해요';
      } else t = '팽이와 색을 고르고 「시작!」을 눌러요';
      if (at) t += ' · ' + left + '초 뒤 자동 시작';
      if (pick.stEl.textContent !== t) pick.stEl.textContent = t;
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; layout(); } }

    /* ----- input ----- */
    const ptrs = new Map();
    const STICK_R = 46;
    function dashBtn() { const r = 38; return { x: cv.w - r - 22, y: cv.h - r - 30, r }; }
    function refresh() {
      for (const s of mine()) {
        const I = locIn[s] || (locIn[s] = { x: 0, y: 0, d: 0 });
        I.x = 0; I.y = 0;
        for (const p of ptrs.values()) {
          if (p.kind !== 'stick') continue;
          const dx = p.x - p.ax, dy = p.y - p.ay, d = Math.hypot(dx, dy);
          if (d > 6) { const m = Math.min(1, d / STICK_R); I.x = r2(dx / d * m); I.y = r2(dy / d * m); }
        }
        if (api.input && st && st.ph === 'play') {
          const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down');
          if (kx || ky) { const m = Math.hypot(kx, ky), k = m > 1 ? 1 / m : 1; I.x = r2(kx * k); I.y = r2(ky * k); }
        }
      }
    }
    function pressDash() {
      const s = mine()[0]; if (s == null || !W || !st || st.ph !== 'play') return;
      const I = locIn[s] || (locIn[s] = { x: 0, y: 0, d: 0 }), T = W.tops[s];
      if (!T || !T.al) return;
      I.d = (I.d + 1) % 1000;
      api.buzz(T.cd > 0.05 ? 5 : 18);
      pubT = 0; inT = 0;
      hintT = Math.min(hintT, 1);
    }
    function launchNow(seat, viaKey) {
      if (!st || st.ph !== 'launch' || launched[seat] || !aim[seat]) return;
      const tr = phT - GO;
      if (tr < -WIN) { earlyT = 1.4; api.buzz(8); api.sfx('tick'); return; }
      const q = qualityOf(Math.abs(tr));
      launched[seat] = [r2(aim[seat].a), r2(aim[seat].p), r2(q)];
      myLabel = { text: q >= 1 ? '퍼펙트!' : q >= 0.88 ? '좋아요!' : q >= 0.7 ? '괜찮아요' : tr < 0 ? '빨랐어요' : '늦었어요', q, t: 0 };
      api.sfx(q >= 1 ? 'win' : 'whoosh'); api.buzz(q >= 1 ? [20, 30, 25] : 20);
      if (q >= 1) shake = 0.3;
      if (!host()) { lastLaunchMsg = launched[seat]; pubT = 0; }
      hintT = Math.min(hintT, 0.6);
      void viaKey;
    }
    function onDown(e) {
      const seat = mine()[0];
      if (seat == null || !st || !W) return;
      const p = cv.local(e);
      if (st.ph === 'launch') {
        if (launched[seat]) return;
        e.preventDefault();
        try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
        pull = { id: e.pointerId, sx: p.x, sy: p.y, x: p.x, y: p.y, moved: false };
        api.buzz(6);
        return;
      }
      if (st.ph !== 'play') return;
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      hintT = Math.min(hintT, 1.2);
      if (p.x > cv.w / 2) { pressDash(); ptrs.set(e.pointerId, { kind: 'dash', x: p.x, y: p.y }); refresh(); return; }
      for (const [id, q] of ptrs) if (q.kind === 'stick') ptrs.delete(id);
      ptrs.set(e.pointerId, { kind: 'stick', ax: p.x, ay: p.y, x: p.x, y: p.y });
      refresh();
    }
    const pullFull = () => Math.max(70, Math.min(cv.w, cv.h) * 0.26);
    function onMove(e) {
      const p = cv.local(e);
      if (pull && pull.id === e.pointerId) {
        pull.x = p.x; pull.y = p.y;
        const dx = pull.sx - p.x, dy = pull.sy - p.y, d = Math.hypot(dx, dy), seat = mine()[0];
        if (d > 12) pull.moved = true;
        if (d > 12 && seat != null && aim[seat]) { aim[seat].a = Math.atan2(dy, dx); aim[seat].p = clamp(d / pullFull(), 0.1, 1); }
        return;
      }
      const q = ptrs.get(e.pointerId);
      if (!q) return;
      q.x = p.x; q.y = p.y;
      if (q.kind === 'stick') { const d = Math.hypot(q.x - q.ax, q.y - q.ay); if (d > STICK_R * 1.3) { const k = STICK_R * 1.3 / d; q.ax = q.x - (q.x - q.ax) * k; q.ay = q.y - (q.y - q.ay) * k; } }
      refresh();
    }
    function onUp(e) {
      if (pull && pull.id === e.pointerId) {
        const d = Math.hypot(pull.x - pull.sx, pull.y - pull.sy), was = pull.moved;
        pull = null;
        const seat = mine()[0];
        if (seat == null) return;
        if (was && d < 12) { api.buzz(5); return; } // dragged back to the start = cancel
        launchNow(seat, false);
        return;
      }
      if (ptrs.delete(e.pointerId)) refresh();
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (!st) return;
      const seat = mine()[0]; if (seat == null) return;
      if (st.ph === 'pick' && type === 'down' && pick) {
        const c = curPick(seat);
        if (id === 'left' || id === 'right') choose({ tp: (c.tp + (id === 'left' ? 3 : 1)) % 4 });
        else if (id === 'up' || id === 'down') { let k = c.cl; for (let i = 0; i < COLORS.length; i++) { k = (k + (id === 'up' ? COLORS.length - 1 : 1)) % COLORS.length; if (!takenBy(k, seat)) break; } choose({ cl: k }); }
        else if (id === 'act') choose({ r: c.r ? 0 : 1 });
      } else if (st.ph === 'launch') { if (id === 'act' && type === 'down') launchNow(seat, true); }
      else if (st.ph === 'play') { if (id === 'act') { if (type === 'down') pressDash(); } else refresh(); }
    }) : null;
    const releaseAll = () => { ptrs.clear(); pull = null; refresh(); };
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    window.addEventListener('blur', releaseAll);

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 50)) return; lastSfx = t; api.sfx(n); }
    function sparks(x, y, n, sp, col) {
      for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = sp * (0.4 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0.3 + Math.random() * 0.3, c: col || (Math.random() < 0.5 ? '#fff3cf' : '#ffd36a') }); }
      if (parts.length > 260) parts.splice(0, parts.length - 260);
    }
    const hooks = {
      clash(a, b, v, x, y) {
        sparks(x, y, v > 110 ? 16 : v > 50 ? 9 : 4, 50 + v * 0.7);
        if (v > 60) rings.push({ x, y, r0: 4, r1: 10 + v * 0.12, t: 0.25, T: 0.25, col: '#fff3cf' });
        if (v > 25) sfx(v > 120 ? 'thud' : 'hit', 70);
        if (isMine(a.s) || isMine(b.s)) api.buzz(v > 120 ? 30 : 10);
        if (v > 120) shake = Math.min(1, shake + 0.45);
        if (v > 160) floats.push({ x, y, text: '쾅!', col: '#ffd36a', t: 0.8 });
      },
      rim(T, v) { sparks(T.x, T.y, 4, 40, '#f2e9d8'); if (v > 45) sfx('bounce', 80); if (isMine(T.s)) api.buzz(8); },
      dash(T) { rings.push({ x: T.x, y: T.y, r0: 8, r1: 22, t: 0.3, T: 0.3, col: colOf(T.s) }); if (isMine(T.s)) sfx('whoosh', 40); },
      out(T, fr, by) { onOut(T.s, fr, by); },
    };
    function onOut(seat, fr, by) {
      const T = W && W.tops[seat];
      if (isMine(seat)) { api.sfx('lose'); api.buzz(90); shake = 1; }
      else if (by >= 0 && isMine(by)) { api.sfx('win'); api.buzz(40); }
      else sfx('thud', 40);
      const text = fr === 'o' ? (by >= 0 ? name(by) + ' → ' + name(seat) + ' 장외!' : name(seat) + ' 장외!') : name(seat) + ' 회전 멈춤';
      if (T) { floats.push({ x: T.x, y: T.y, text, col: colOf(by >= 0 && fr === 'o' ? by : seat), t: 1.8 }); sparks(T.x, T.y, 10, 70, colOf(seat)); }
    }

    /* ----- host flow ----- */
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'pick') {
        pollPicks();
        pickT += dt;
        const humans = []; for (let i = 0; i < st.n; i++) if (!P(i).ai) humans.push(i);
        const allReady = humans.every((i) => st.rdy[i]);
        const at = !humans.length || (auto() && !api.online) ? 1.2 : autoPickT();
        if ((allReady && humans.length) || (at && pickT >= at)) { pickT = -1e9; api.setState(startLaunch(st, st.tp.map((_, i) => (P(i).ai ? (P(i).lv || 2) : 0)))); }
        return;
      }
      if (st.ph === 'launch') {
        pollLaunches();
        if (phT < GO + WIN + 0.05) return;
        let all = true;
        for (let i = 0; i < st.n; i++) if (!P(i).ai && !launched[i]) all = false;
        if (all || phT >= GO + WAIT_REMOTE) {
          const A = ARENAS[st.ar];
          const ln = [];
          for (let i = 0; i < st.n; i++) {
            if (launched[i] && !P(i).ai) ln.push(launched[i]);
            else if (P(i).ai) ln.push(aiLaunch(A, st.n, i, st.tp[i], lvOf(i), null, rotOf(st)));
            else { const sp = spawnOf(A, st.n, slotOf(st.n, i, rotOf(st))); ln.push([r2(defaultAim(A, sp)), 0.6, 0.55]); }
          }
          phT = -1e9;
          api.setState(startPlay(st, ln));
        }
        return;
      }
      if (st.ph === 'play' && W && !W.preview) {
        const r = roundWinner(W); // time's up (CAP_T) → most spin wins
        if (r) api.setState(roundOver(st, r.w));
      } else if (st.ph === 'end') {
        endT -= dt;
        if (endT <= 0) { endT = 1e9; api.setState(nextRound(st, st.tp.map((_, i) => (P(i).ai ? (P(i).lv || 2) : 0)))); }
      }
    }
    function remote() { let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; } return rem && typeof rem === 'object' ? rem : null; }
    function pollPicks() {
      if (!api.online || !api.isHost) return;
      const rem = remote(); if (!rem) return;
      let ns = null;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.n) || simHere(s) || !o || o.k !== key || !Array.isArray(o.P)) continue;
        const cur = ns || st, tp = clamp(o.P[0] | 0, 0, 3), r = o.P[2] ? 1 : 0;
        let cl = clamp(o.P[1] | 0, 0, COLORS.length - 1);
        if (cur.cl.some((c, i) => i !== s && c === cl)) cl = cur.cl[s];
        if (cur.tp[s] !== tp || cur.cl[s] !== cl || cur.rdy[s] !== r) {
          if (!ns) ns = Object.assign({}, st, { tp: st.tp.slice(), cl: st.cl.slice(), rdy: st.rdy.slice() });
          ns.tp[s] = tp; ns.cl[s] = cl; ns.rdy[s] = r;
        }
      }
      if (ns) api.setState(ns);
    }
    function pollLaunches() {
      if (!api.online || !api.isHost) return;
      const rem = remote(); if (!rem) return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.n) || simHere(s) || launched[s] || !o || o.k !== key || !Array.isArray(o.L)) continue;
        const a = +o.L[0], p = +o.L[1], q = +o.L[2];
        if (fin(a) && fin(p) && fin(q)) launched[s] = [r2(a), r2(clamp(p, 0.1, 1)), r2(clamp(q, 0.55, 1))];
      }
    }
    function pollInputs() {
      if (!api.online || !api.isHost || !W) return;
      const rem = remote(); if (!rem) return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.tops.length) || simHere(s) || !o || o.k !== key || !fin(o.x)) continue;
        remIn[s] = { x: clamp(+o.x || 0, -1, 1), y: clamp(+o.y || 0, -1, 1), d: o.d | 0 };
      }
    }

    /* ----- online: guest ----- */
    function pollGuest(now) {
      if (!api.online || api.isHost || !W || W.preview) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.c)) return;
      lastQ = hs.q;
      snaps.push({ at: now, c: hs.c }); if (snaps.length > 4) snaps.shift();
      if (fin(hs.t)) W.t = hs.t;
      if (Array.isArray(hs.bm) && hs.bm[0] !== lastBm) {
        const first = lastBm === -1; lastBm = hs.bm[0];
        if (!first) { const v = +hs.bm[1] || 0; hooks.clash({ s: -1 }, { s: -1 }, v, +hs.bm[2] || 0, +hs.bm[3] || 0); if (hs.bm[4] >= 0 && hs.bm[5] >= 0 && (isMine(hs.bm[4]) || isMine(hs.bm[5]))) api.buzz(v > 120 ? 30 : 10); }
      }
      if (Array.isArray(hs.ev) && hs.ev[0] !== lastEvQ) {
        const first = lastEvQ === -1; lastEvQ = hs.ev[0];
        const T = W.tops[hs.ev[1] | 0];
        if (!first && T) hooks.dash(T);
      }
      hs.c.forEach((a, s) => {
        const T = W.tops[s];
        if (!T || !Array.isArray(a)) return;
        const fl = a[5] | 0, al = !!(fl & 1);
        T.sp = +a[4] || 0; T.cd = +a[6] || 0; T.dt = fl & 8 ? 0.1 : 0;
        if (T.al && !al) { T.al = 0; T.fr = fl & 2 ? 'o' : 's'; T.f = 1e-3; onOut(s, T.fr, fin(a[7]) ? a[7] : -1); }
      });
    }
    function interpOthers(now) {
      if (host() || !snaps.length || !W || W.preview) return;
      const rt = now - 100;
      let A = null, B = snaps[snaps.length - 1], k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.25);
      W.tops.forEach((T, s) => {
        const b = B.c[s], a = A ? A.c[s] : null;
        if (!Array.isArray(b)) return;
        if (a && Array.isArray(a)) { T.x = a[0] + (b[0] - a[0]) * k; T.y = a[1] + (b[1] - a[1]) * k; }
        else { T.x = b[0]; T.y = b[1]; }
        T.vx = b[2]; T.vy = b[3];
      });
    }
    let lastBump = [0, 0, 0, 0, -1, -1], lastEv = [0, -1];
    const hostHooks = Object.assign({}, hooks, {
      clash(a, b, v, x, y) { hooks.clash(a, b, v, x, y); lastBump = [(lastBump[0] + 1) % 1000, Math.round(v), r1(x), r1(y), a.s, b.s]; },
      dash(T) { hooks.dash(T); lastEv = [(lastEv[0] + 1) % 1000, T.s]; },
    });
    function publish(rdt, now) {
      if (!api.online || !st) return;
      pubT -= rdt; inT -= rdt; pickSendT -= rdt;
      try {
        if (api.isHost) {
          if (!W || W.preview || (st.ph !== 'play' && st.ph !== 'end') || pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          const c = W.tops.map((T) => [r1(T.x), r1(T.y), Math.round(T.vx), Math.round(T.vy), r1(Math.max(0, T.sp)), (T.al ? 1 : 0) | (T.fr === 'o' ? 2 : 0) | (T.fr === 's' ? 4 : 0) | (T.dt > 0 ? 8 : 0), r1(Math.max(0, T.cd)), T.al ? -1 : (T.byT < 2.5 ? T.by : -1)]);
          api.net.hostSend({ k: key, q: hsQ, t: r2(W.t), c, bm: lastBump, ev: lastEv });
          return;
        }
        const s = mine()[0];
        if (s == null) return;
        if (st.ph === 'pick') {
          if (!guestPend) return;
          const sig = key + '|' + guestPend.tp + '|' + guestPend.cl + '|' + guestPend.r;
          if (sig === pickSent && pickSendT > 0) return;
          pickSent = sig; pickSendT = 1;
          api.net.publish({ k: key, P: [guestPend.tp, guestPend.cl, guestPend.r] });
        } else if (st.ph === 'launch') {
          if (!lastLaunchMsg || pubT > 0) return;
          pubT = 0.5;
          api.net.publish({ k: key, L: lastLaunchMsg });
        } else if (st.ph === 'play') {
          const I = locIn[s]; if (!I) return;
          const sig = I.x + '|' + I.y + '|' + I.d;
          if (sig === lastSig && inT > 0) return;
          lastSig = sig; inT = 0.15;
          inQ = (inQ + 1) % 100000;
          api.net.publish({ k: key, q: inQ, x: I.x, y: I.y, d: I.d });
        }
      } catch (e) {}
      void now;
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      const dt = rdt * SPD();
      phT += dt;
      if (mine().length) refresh();
      if (st.ph === 'pick') { if (!pick && mine().length) buildPicker(); if (pick) { pickT += host() ? 0 : dt; syncPickStatus(); } }
      else if (pick) dropPicker();
      if (st.ph === 'launch') {
        for (const s of mine()) {
          const a = aim[s]; if (!a || launched[s]) continue;
          if (api.input) { // keyboard / pad: ←→ turn the aim, ↑↓ power
            const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down');
            if (kx) a.a = wrapA(a.a + kx * 1.8 * rdt);
            if (ky) a.p = clamp(a.p - ky * 0.9 * rdt, 0.1, 1);
          }
          if (auto() && phT >= GO) { const l = aiLaunch(W.A, st.n, s, st.tp[s], 3, null, rotOf(st)); a.a = l[0]; a.p = l[1]; launchNow(s, true); }
          else if (phT >= GO + WIN) { // too late: the launcher fires by itself, weakly
            launched[s] = [r2(a.a), r2(a.p), 0.55];
            myLabel = { text: '늦었어요', q: 0.55, t: 0 };
            api.sfx('whoosh'); api.buzz(15);
            if (!host()) { lastLaunchMsg = launched[s]; pubT = 0; }
          }
        }
        const n = Math.ceil(GO - phT), pn = Math.ceil(GO - (phT - dt));
        if (phT < GO && phT > PRE && n !== pn && n > 0) { api.sfx('tick'); }
        if (phT >= GO && phT - dt < GO) { api.sfx('pop'); api.buzz(25); }
      }
      if (earlyT > 0) earlyT -= rdt;
      if (myLabel) myLabel.t += rdt;
      if (hintT > 0 && hintT < 90) hintT -= rdt;
      if (host()) {
        if (W && !W.preview && st.ph === 'play') {
          pollInputs();
          W.tops.forEach((T, i) => {
            const p = api.players[i];
            if (!p) return;
            if (simHere(i)) inputs[i] = (p.ai || !isMine(i) || auto()) ? aiThink(W, T, aiMem[i] || (aiMem[i] = {}), lvOf(i), dt) : locIn[i];
            else inputs[i] = remIn[i];
          });
          acc += Math.min(dt, 0.25);
          let n = 0;
          while (acc >= H && n < 80) { stepWorld(W, inputs, hostHooks); acc -= H; n++; }
        } else if (W && !W.preview && st.ph === 'end') {
          acc += Math.min(dt, 0.25); let n = 0;
          while (acc >= H && n < 80) { stepWorld(W, null, null); acc -= H; n++; }
        }
        hostFlow(dt);
      } else if (W && !W.preview) {
        pollGuest(now);
        interpOthers(now);
        if (auto() && st.ph === 'play') for (const s of mine()) { const o = aiThink(W, W.tops[s], aiMem[s] || (aiMem[s] = {}), 2, dt); locIn[s] = { x: o.x, y: o.y, d: o.d }; } // test autoplay
      }
      // visual spin
      if (W) W.tops.forEach((T) => {
        const v = vis[T.s] || (vis[T.s] = { ang: T.s * 1.3, w: 0, prec: T.s });
        const wf = T.sp / 100, target = T.al ? (W.preview ? 5 : 7 + 24 * wf) : 0;
        v.w += (target - v.w) * Math.min(1, rdt * (T.al ? 4 : 2));
        v.ang = (v.ang + v.w * rdt * Math.min(SPD(), 2)) % (Math.PI * 200);
        v.prec += (2 + 9 * clamp((0.3 - wf) / 0.3, 0, 1)) * rdt;
      });
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.9; p.vy *= 0.9; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t -= rdt; if (rings[i].t <= 0) rings.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 3);
      if (tgtLay && lay) { const k = Math.min(1, rdt * 8); lay.s += (tgtLay.s - lay.s) * k; lay.cx += (tgtLay.cx - lay.cx) * k; lay.cy += (tgtLay.cy - lay.cy) * k; }
      publish(rdt, now);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align) {
      ctx.font = font; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y);
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function drawTop(T, now) {
      const ty = TYPES[T.t], R = ty.r * lay.s, px = X(T.x), py = Y(T.y), col = colOf(T.s), v = vis[T.s] || { ang: 0, w: 0, prec: 0 };
      const wf = T.sp / 100;
      let alpha = 1, scl = 1, tilt = 0, grey = 0;
      if (!T.al) {
        if (T.fr === 'o') { const k = clamp(T.f / 0.75, 0, 1); scl = 1 - 0.65 * k; alpha = 1 - k; tilt = 0.3 * k; if (alpha <= 0.02) return; }
        else { tilt = 0.12 + 0.4 * clamp(T.f / 0.45, 0, 1); grey = clamp(T.f / 0.45, 0, 1); alpha = (1 - 0.35 * grey) * clamp((3 - T.f) / 1.5, 0, 1); if (alpha <= 0.02) return; }
      } else if (!W.preview) tilt = 0.03 + 0.32 * clamp((0.3 - wf) / 0.3, 0, 1);
      const cp = Math.cos(v.prec), sp = Math.sin(v.prec);
      // shadow
      ctx.globalAlpha = 0.38 * alpha;
      ctx.beginPath(); ctx.ellipse(px + 2.5 + cp * tilt * R * 0.8, py + 3.5 + sp * tilt * R * 0.8, R * scl, R * scl * 0.92, 0, 0, 7); ctx.fillStyle = '#000'; ctx.fill();
      ctx.save();
      ctx.translate(px - cp * tilt * R * 0.25, py - sp * tilt * R * 0.25);
      if (tilt > 0.005) { ctx.rotate(v.prec); ctx.scale(1 - tilt, 1); ctx.rotate(-v.prec); }
      if (scl !== 1) ctx.scale(scl, scl);
      // motion blur: fading copies a little behind in the rotation
      if (T.al && wf > 0.12 && !W.preview) {
        const d = Math.min(0.5, v.w * 0.017);
        ctx.globalAlpha = alpha * 0.25; topArt(ctx, T.t, col, R, v.ang - d * 2);
        ctx.globalAlpha = alpha * 0.45; topArt(ctx, T.t, col, R, v.ang - d);
      }
      ctx.globalAlpha = alpha; topArt(ctx, T.t, col, R, v.ang);
      if (grey > 0) { ctx.globalAlpha = 0.5 * grey; ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.fillStyle = '#2a2433'; ctx.fill(); }
      // speed stripes
      if (T.al && wf > 0.2 && !W.preview) {
        ctx.globalAlpha = 0.6 * wf * alpha; ctx.strokeStyle = '#fff6dc'; ctx.lineWidth = Math.max(1, R * 0.12); ctx.lineCap = 'round';
        for (let k = 0; k < 3; k++) { const a0 = v.ang * 0.9 + k * 2.094; ctx.beginPath(); ctx.arc(0, 0, R * 1.13, a0, a0 + 0.5 + 0.7 * wf); ctx.stroke(); }
      }
      ctx.restore();
      ctx.globalAlpha = 1;
      if (T.al && T.dt > 0 && !W.preview) { ctx.beginPath(); ctx.arc(px, py, R + 5, 0, 7); ctx.strokeStyle = hexA(col, 0.8); ctx.lineWidth = 3; ctx.stroke(); }
      void now;
    }
    function drawTag(T) { // spin gauge ring + name (second pass, so no top covers another's tag)
      const R = TYPES[T.t].r * lay.s, px = X(T.x), py = Y(T.y), col = colOf(T.s), wf = T.sp / 100;
      if (T.al) {
        if (!W.preview) {
          ctx.beginPath(); ctx.arc(px, py, R + 3.5, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * clamp(wf, 0, 1));
          ctx.strokeStyle = wf < 0.25 ? '#ee6a55' : hexA(col, 0.9); ctx.lineWidth = 2; ctx.lineCap = 'butt'; ctx.stroke();
        }
        txt(name(T.s), px, py - R - 12, isMine(T.s) ? '#f2e9d8' : col, '700 10.5px ' + FONT);
        if (isMine(T.s)) { ctx.beginPath(); ctx.moveTo(px - 4, py - R - 4.5); ctx.lineTo(px + 4, py - R - 4.5); ctx.lineTo(px, py - R - 0.5); ctx.closePath(); ctx.fillStyle = '#f2e9d8'; ctx.fill(); }
      }
    }
    function drawLaunchUI(now) {
      const w = cv.w, h = cv.h;
      // every top hovers on its launcher
      for (const T of W.tops) {
        const px = X(T.x), py = Y(T.y), R = TYPES[T.t].r * lay.s;
        ctx.beginPath(); ctx.arc(px, py, R + 7, 0, 7); ctx.setLineDash([4, 4]); ctx.strokeStyle = hexA(colOf(T.s), 0.65); ctx.lineWidth = 2; ctx.stroke(); ctx.setLineDash([]);
      }
      for (const s of mine()) {
        const a = aim[s], T = W.tops[s]; if (!a || !T) continue;
        const px = X(T.x), py = Y(T.y), R = TYPES[T.t].r * lay.s;
        if (!launched[s]) {
          // predicted path (lone top, first 0.9 s)
          const sim = { A: W.A, t: 0, tops: [], pc: {} }, v = launchSpeed(a.p);
          const q = { s, t: T.t, x: T.x, y: T.y, vx: Math.cos(a.a) * v, vy: Math.sin(a.a) * v, sp: 90, al: 1, f: 0, fr: '', cd: 9, dt: 0, ld: null, by: -1, byT: 99 };
          sim.tops.push(q);
          ctx.fillStyle = 'rgba(242,233,216,.75)';
          for (let i = 1; i <= 110 && q.al; i++) { stepTop(sim, q, null, H, null); if (i % 9 === 0) { ctx.globalAlpha = 0.85 - i / 140; ctx.beginPath(); ctx.arc(X(q.x), Y(q.y), 1.8, 0, 7); ctx.fill(); } }
          ctx.globalAlpha = 1;
          // aim arrow
          const L0 = R + 6, L1 = R + 14 + 46 * a.p, ca = Math.cos(a.a), sa = Math.sin(a.a);
          ctx.strokeStyle = colOf(s); ctx.lineWidth = 5; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(px + ca * L0, py + sa * L0); ctx.lineTo(px + ca * L1, py + sa * L1); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(px + ca * (L1 + 9), py + sa * (L1 + 9)); ctx.lineTo(px + ca * L1 - sa * 8, py + sa * L1 + ca * 8); ctx.lineTo(px + ca * L1 + sa * 8, py + sa * L1 - ca * 8); ctx.closePath(); ctx.fillStyle = colOf(s); ctx.fill();
          // timing ring closes in on 「발사!」
          const left = GO - phT;
          if (phT > PRE - 0.3 && left > -WIN) {
            const rr = R + 4 + Math.max(0, left) * 30, inPerf = Math.abs(left) <= PERF + 0.03, inWin = Math.abs(left) <= WIN;
            ctx.beginPath(); ctx.arc(px, py, rr, 0, 7); ctx.strokeStyle = inPerf ? '#7be08a' : inWin ? '#ffd36a' : 'rgba(242,233,216,.55)'; ctx.lineWidth = inPerf ? 4 : 2.5; ctx.stroke();
          }
        }
        if (pull) { // slingshot band
          ctx.globalAlpha = 0.5; ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.setLineDash([5, 5]);
          ctx.beginPath(); ctx.moveTo(pull.sx, pull.sy); ctx.lineTo(pull.x, pull.y); ctx.stroke(); ctx.setLineDash([]);
          ctx.beginPath(); ctx.arc(pull.sx, pull.sy, 6, 0, 7); ctx.fillStyle = '#f2e9d8'; ctx.fill(); ctx.globalAlpha = 1;
        }
        if (myLabel && myLabel.t < 1.6) txt(myLabel.text, px, py - R - 30 - myLabel.t * 10, myLabel.q >= 1 ? '#ffe08a' : '#f2e9d8', '22px ' + DISP);
        // bottom band: power + what to do
        const y0 = h - 118, bw = Math.min(w - 40, 320), bx = (w - bw) / 2;
        ctx.save();
        rrect(ctx, bx - 10, y0 - 12, bw + 20, 104, 16); ctx.fillStyle = 'rgba(23,19,31,.8)'; ctx.fill();
        ctx.font = '700 12px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ab9fb8'; ctx.fillText('힘', bx, y0 + 6);
        rrect(ctx, bx + 24, y0, bw - 70, 12, 6); ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.fill();
        rrect(ctx, bx + 24, y0, Math.max(12, (bw - 70) * a.p), 12, 6); ctx.fillStyle = colOf(s); ctx.fill();
        ctx.textAlign = 'right'; ctx.font = '700 12px ' + MONO; ctx.fillStyle = '#f2e9d8'; ctx.fillText(Math.round(a.p * 100) + '%', bx + bw, y0 + 6);
        ctx.textAlign = 'center'; ctx.font = '600 13px ' + FONT;
        let l1, l2, c2 = '#e3ae45';
        if (launched[s]) { l1 = '발사 완료! 다른 팽이를 기다려요'; l2 = '회전 ' + Math.round(launched[s][2] * 100) + '%로 출발해요'; }
        else if (earlyT > 0) { l1 = '조금 빨라요!'; l2 = '「발사!」가 뜨는 순간 손을 떼요'; c2 = '#ee6a55'; }
        else { l1 = '화면을 누른 채 뒤로 당겨 조준해요'; l2 = '「발사!」에 맞춰 손을 떼면 회전 최대!'; }
        ctx.fillStyle = '#f2e9d8'; ctx.fillText(l1, w / 2, y0 + 36);
        ctx.fillStyle = c2; ctx.fillText(l2, w / 2, y0 + 60);
        ctx.restore();
      }
      // countdown
      if (phT < PRE) { txt('라운드 ' + st.rd, w / 2, lay.cy - 20, '#f2e9d8', '30px ' + DISP); txt(ARENAS[st.ar].name, w / 2, lay.cy + 14, '#e3ae45', '18px ' + DISP); }
      else if (phT < GO) { const n = Math.ceil(GO - phT), k = (GO - phT) % 1; txt(String(n), w / 2, lay.cy, '#f2e9d8', Math.round(56 + 20 * k) + 'px ' + DISP); }
      else if (phT < GO + 0.8) txt('발사!', w / 2, lay.cy, '#ffd36a', '50px ' + DISP);
      void now;
    }
    function drawStrip() {
      const w = cv.w, n = st.n, gap = 6, x0 = 8, bw = (w - 16 - gap * (n - 1)) / n, y0 = 6, bh = 50, need = Math.floor(st.b / 2) + 1;
      ctx.save();
      for (let s = 0; s < n; s++) {
        const x = x0 + s * (bw + gap), col = colOf(s), T = W && W.tops[s];
        rrect(ctx, x, y0, bw, bh, 11); ctx.fillStyle = 'rgba(23,19,31,.8)'; ctx.fill();
        if (isMine(s)) { ctx.lineWidth = 1.5; ctx.strokeStyle = '#e3ae45'; ctx.stroke(); }
        ctx.beginPath(); ctx.arc(x + 11, y0 + 14, 5, 0, 7); ctx.fillStyle = col; ctx.fill();
        // wins pips (right)
        const pw = need * 8;
        for (let k = 0; k < need; k++) { ctx.beginPath(); ctx.arc(x + bw - 9 - (need - 1 - k) * 8, y0 + 14, 3, 0, 7); if (k < (st.wins[s] | 0)) { ctx.fillStyle = '#e3ae45'; ctx.fill(); } else { ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1; ctx.stroke(); } }
        ctx.font = '700 11px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8';
        let nm = name(s); const maxW = bw - 24 - pw - 4;
        while (nm.length > 1 && ctx.measureText(nm).width > maxW) nm = nm.slice(0, -1);
        ctx.fillText(nm, x + 20, y0 + 14.5);
        // row 2
        const y2 = y0 + 35;
        if (st.ph === 'pick' || st.ph === 'launch' || !T || W.preview) {
          ctx.font = '600 10.5px ' + FONT; ctx.fillStyle = '#ab9fb8';
          let t = TYPES[st.tp[s] | 0].nm;
          if (st.ph === 'pick') t += (P(s).ai || st.rdy[s]) ? ' ✓' : ' …';
          ctx.fillText(t, x + 8, y2);
        } else if (!T.al) {
          ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#ee6a55'; ctx.fillText(T.fr === 'o' ? '장외' : '멈춤', x + 8, y2);
        } else {
          const wf = clamp(T.sp / 100, 0, 1), bx = x + 8, bl = bw - 16 - 26;
          rrect(ctx, bx, y2 - 4, bl, 8, 4); ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.fill();
          rrect(ctx, bx, y2 - 4, Math.max(4, bl * wf), 8, 4); ctx.fillStyle = wf < 0.25 ? '#ee6a55' : col; ctx.fill();
          ctx.font = '700 10px ' + MONO; ctx.textAlign = 'right'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(String(Math.round(T.sp)), x + bw - 7, y2 + 0.5);
        }
      }
      ctx.restore();
      // round line (the picker shows it itself)
      if (pick) return;
      const A = ARENAS[st.ar] || ARENAS[0];
      let t = '라운드 ' + st.rd + ' · ' + A.name;
      if (W && !W.preview && st.ph === 'play' && W.t > SUDDEN) t += ' · 회전이 빨리 줄어요!';
      txt(t, cv.w / 2, 68, W && W.t > SUDDEN && st.ph === 'play' ? '#ee6a55' : '#ab9fb8', '600 11.5px ' + FONT);
    }
    function drawControls(now) {
      const s = mine()[0]; if (s == null || !W || W.preview) return;
      const w = cv.w, h = cv.h, T = W.tops[s], col = colOf(s);
      const dead = !T || !T.al;
      ctx.save();
      ctx.globalAlpha = dead ? 0.3 : 1;
      const b = dashBtn(), ready = T && T.cd <= 0 && T.sp >= 6;
      const pressed = [...ptrs.values()].some((p) => p.kind === 'dash');
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r * (pressed ? 0.93 : 1), 0, 7); ctx.fillStyle = ready ? hexA(col, 0.88) : 'rgba(46,38,64,.88)'; ctx.fill();
      ctx.lineWidth = 3; ctx.strokeStyle = ready ? '#fff3cf' : 'rgba(242,233,216,.25)'; ctx.stroke();
      if (T && T.cd > 0) { ctx.beginPath(); ctx.arc(b.x, b.y, b.r - 1.5, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - clamp(T.cd / DASH_CD, 0, 1))); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.stroke(); }
      ctx.font = '19px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = ready ? '#17131f' : '#ab9fb8'; ctx.fillText('돌진', b.x, b.y - 4);
      ctx.font = '700 10px ' + FONT; ctx.fillText('회전 −' + DASH_COST, b.x, b.y + 14);
      const q = [...ptrs.values()].find((p) => p.kind === 'stick');
      const ax = q ? q.ax : 24 + STICK_R + 8, ay = q ? q.ay : h - STICK_R - 34;
      ctx.globalAlpha = (dead ? 0.3 : 1) * (q ? 0.95 : 0.4);
      ctx.beginPath(); ctx.arc(ax, ay, STICK_R, 0, 7); ctx.fillStyle = 'rgba(23,19,31,.55)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.stroke();
      let kx = ax, ky = ay;
      if (q) { const dx = q.x - q.ax, dy = q.y - q.ay, d = Math.hypot(dx, dy), m = Math.min(d, STICK_R); if (d > 0) { kx = ax + dx / d * m; ky = ay + dy / d * m; } }
      ctx.beginPath(); ctx.arc(kx, ky, 20, 0, 7); ctx.fillStyle = hexA(col, 0.9); ctx.fill(); ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.stroke();
      if (!q) { ctx.font = '600 11px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.fillText('살짝 밀기', ax, ay - STICK_R - 10); }
      ctx.globalAlpha = 1;
      if (dead && st.ph === 'play') txt(T && T.fr === 'o' ? '장외 · 관전 중' : '회전 멈춤 · 관전 중', w / 2, h - 70, '#ee6a55', '18px ' + DISP);
      ctx.restore();
      void now;
    }
    function drawHint() {
      if (!(hintT > 0) || hintKind !== 'play' || !st || st.ph !== 'play') return;
      const me = W && W.tops[mine()[0]]; if (!me || !me.al) return;
      const w = cv.w, h = cv.h;
      ctx.save(); ctx.globalAlpha = Math.min(1, hintT);
      const t1 = '왼쪽: 엄지를 대고 밀면 살짝 움직여요', t2 = '오른쪽 톡: 돌진! (회전 조금 써요)';
      ctx.font = '600 13px ' + FONT;
      const bw = Math.min(w - 20, Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width) + 26), y0 = h - 196;
      rrect(ctx, (w - bw) / 2, y0, bw, 50, 14); ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t1, w / 2, y0 + 16); ctx.fillStyle = '#e3ae45'; ctx.fillText(t2, w / 2, y0 + 35);
      ctx.restore();
    }
    function draw(now) {
      cv.clear();
      const w = cv.w, h = cv.h;
      if (!st || !lay) return;
      const A = ARENAS[st.ar] || ARENAS[0];
      if (!bgGrad) { bgGrad = ctx.createRadialGradient(w / 2, lay.cy, 30, w / 2, lay.cy, Math.max(w, h) * 0.75); bgGrad.addColorStop(0, '#2a2236'); bgGrad.addColorStop(1, '#120e18'); }
      ctx.fillStyle = bgGrad; ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = hexA(A.pal.bg, 0.35); ctx.fillRect(0, 0, w, h);
      ensureBg();
      const sx = shake > 0 ? (Math.random() - 0.5) * shake * 7 : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 7 : 0;
      ctx.save(); ctx.translate(sx, sy);
      if (bg && bg.wu) { const bw = bg.wu * lay.s, bh = bg.hu * lay.s; ctx.drawImage(bg, lay.cx - bw / 2, lay.cy - bh / 2, bw, bh); }
      if (W) {
        // stopped / fallen tops first, then the live ones
        for (const T of W.tops) if (!T.al) drawTop(T, now);
        for (const T of W.tops) if (T.al) drawTop(T, now);
        for (const T of W.tops) if (T.al) drawTag(T);
        ctx.save(); ctx.translate(lay.cx, lay.cy); ctx.scale(lay.s, lay.s);
        for (const p of parts) { ctx.globalAlpha = Math.min(1, p.t * 3); ctx.strokeStyle = p.c; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03); ctx.stroke(); }
        for (const r of rings) { const k = 1 - r.t / r.T; ctx.globalAlpha = Math.min(1, r.t / r.T * 1.6); ctx.strokeStyle = r.col; ctx.lineWidth = 2.5 * (1 - k) + 0.5; ctx.beginPath(); ctx.arc(r.x, r.y, r.r0 + (r.r1 - r.r0) * k, 0, 7); ctx.stroke(); }
        ctx.restore(); ctx.globalAlpha = 1;
      }
      ctx.restore();
      for (const f of floats) { ctx.globalAlpha = Math.min(1, f.t * 2); txt(f.text, clamp(X(f.x), 90, w - 90), clamp(Y(f.y) - 28 - (1.8 - f.t) * 14, 96, h - 60), f.col, '700 14px ' + FONT); }
      ctx.globalAlpha = 1;
      drawStrip();
      if (W && st.ph === 'launch') drawLaunchUI(now);
      if (W && (st.ph === 'play' || st.ph === 'end')) drawControls(now);
      drawHint();
      if (st.ph === 'pick' && !pick) txt(host() ? '팽이 고르는 중…' : '호스트를 기다려요…', w / 2, h - 40, '#ab9fb8', '600 13px ' + FONT);
      if (st.ph === 'end') {
        const t = st.rw >= 0 ? name(st.rw) + ' 라운드 승리!' : '무승부 라운드';
        txt(t, w / 2, lay.cy - 10, st.rw >= 0 ? colOf(st.rw) : '#f2e9d8', '26px ' + DISP);
        if (st.rw >= 0) txt(TYPES[st.tp[st.rw] | 0].nm + ' · ' + (st.wins[st.rw] | 0) + '승', w / 2, lay.cy + 20, '#f2e9d8', '600 13px ' + FONT);
      }
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        const k = st.rid + '.' + st.rd;
        if (k !== key) { key = k; lastBm = -1; lastEvQ = -1; }
        const pk = k + '.' + st.ph;
        if (pk !== phKey) { phKey = pk; enterPhase(st.ph, prev && prev.ph); }
        if (W && W.preview) W.tops.forEach((T, i) => { T.t = clamp(st.tp[i] | 0, 0, 3); });
        if (guestPend && st.ph === 'pick') { const s = mine()[0]; if (s != null && st.tp[s] === guestPend.tp && st.cl[s] === guestPend.cl && (st.rdy[s] ? 1 : 0) === guestPend.r) guestPend = null; }
        if (st.ph === 'pick') { if (!pick && mine().length) buildPicker(); syncPicker(); } else dropPicker();
        if (!lay) layout();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        dropPicker(); styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, phT, launched, aim, lay, locIn, pressDash, launchNow, choose }),
    };
  }

  L.register({
    id: 'tops', name: '팽이 싸움', tag: '실시간 팽이 대결', cat: '아케이드',
    blurb: '당겨서 쏘는 팽이 대결! 「발사!」에 맞춰 날리고, 오목한 경기장에서 부딪혀 상대를 장외로 보내거나 끝까지 돌아남아요. 팽이 4종류, 경기장 4곳.',
    tint: '#2c3a6e',
    icon: '<ellipse cx="28" cy="46" rx="18" ry="4" fill="none" stroke="currentColor" stroke-width="2.5" opacity=".6"/><path d="M28 44 L14 28 Q28 18 42 28 Z" fill="currentColor"/><ellipse cx="28" cy="27" rx="14" ry="5" fill="none" stroke="currentColor" stroke-width="3"/><path d="M28 21 V12" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M6 22 q4 -6 10 -7 M50 22 q-4 -6 -10 -7" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'rounds', label: '라운드', choices: [{ v: 3, label: '3판 2선승' }, { v: 5, label: '5판 3선승' }], def: 3 },
      { id: 'arena', label: '경기장', choices: [{ v: -1, label: '무작위' }].concat(ARENAS.map((A, i) => ({ v: i, label: A.name }))), def: -1 },
    ],
    controls: [
      { id: 'up', label: '위 (발사 때: 힘 +)', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래 (발사 때: 힘 −)', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽 (발사 때: 조준 돌리기)', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽 (발사 때: 조준 돌리기)', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'act', label: '발사 · 돌진 · 준비', keys: ['Space', 'Enter'], pad: ['a', 'rb'] },
    ],
    quick: [
      '팽이를 날려 다른 팽이를 경기장 밖으로 쳐내거나, 끝까지 돌아남으면 이겨요.',
      '발사: 화면을 누른 채 뒤로 당겨 조준 → 「발사!」에 맞춰 손 떼기. 대결 중: 왼쪽 엄지로 살짝 밀기, 오른쪽 톡 = 돌진.',
      '마지막까지 돌고 있는 팽이가 라운드 승리. 3판 2선승(또는 5판 3선승).',
    ],
    rules: [
      { h: '목표', p: [
        '팽이를 경기장에 날려 보내 서로 부딪혀요.',
        '경기장 밖으로 튕겨 나가거나(장외) 회전이 다 떨어져 멈추면(회전 멈춤) 탈락이에요.',
        '마지막까지 돌고 있는 팽이가 라운드 승리예요.',
      ] },
      { h: '라운드 순서', p: [
        '① 팽이 고르기: 팽이 종류 4가지 중 하나와 색을 고르고 「시작!」(온라인은 「준비 완료」). 경기장은 미리 보여요.',
        '② 발사: 「3, 2, 1, 발사!」 카운트다운이 나와요. 화면 아무 데나 누른 채 뒤로 당기면 반대쪽으로 조준돼요. 많이 당길수록 세게 나가요(점선이 날아갈 길).',
        '「발사!」가 뜨는 순간 손을 떼면 퍼펙트 — 회전 100%로 출발해요. 빠르거나 늦을수록 회전이 줄어요(가장 약하면 55%).',
        '당기다가 처음 자리로 되돌리고 떼면 취소돼요. 너무 일찍 떼면 조준만 남고 발사는 안 돼요 — 「발사!」에 맞춰 화면을 다시 톡 하면 그 조준으로 날아가요.',
        '「발사!」 뒤 0.6초 안에 안 날리면 저절로 약하게 날아가요.',
        '③ 회전 대결: 경기장은 오목한 그릇이라 팽이가 가운데로 미끄러져 내려와요.',
      ] },
      { h: '예시', p: [
        '「발사!」가 뜨는 바로 그때 떼면 회전 100%(퍼펙트). 0.3초 늦게 떼면 약 82%예요.',
        '내 팽이 아래쪽 화면을 누르고 아래로 쭉 당기면, 팽이는 위쪽(경기장 가운데)으로 세게 날아가요.',
      ] },
      { h: '조작 (회전 대결)', p: [
        '화면 왼쪽에 엄지를 대고 밀면 그쪽으로 살짝 움직여요. 팽이는 저절로 돌아다니니 방향만 슬쩍 거들어 주는 느낌이에요.',
        '화면 오른쪽 아무 데나 톡 = 돌진! 조이스틱 방향(없으면 가장 가까운 팽이 쪽)으로 확 튀어 나가고, 돌진 중에 부딪히면 더 세게 때려요. 회전을 5 쓰고, 다시 쓰려면 3초.',
        'PC 키보드·게임패드: 방향키·WASD·왼스틱으로 이동, 스페이스·엔터·Ⓐ·RB로 돌진. 발사 때는 ←→로 조준 돌리기, ↑↓로 힘, 스페이스로 발사. 고를 때는 ←→ 팽이, ↑↓ 색, 스페이스 준비. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '팽이 4종류', p: [
        '공격형: 빠르게 돌아다니며 세게 들이받아요. 대신 회전이 빨리 줄어요.',
        '방어형: 무겁고 단단해서 맞아도 잘 안 밀리고 회전도 덜 깎여요. 느려요.',
        '지구력형: 가볍지만 회전이 아주 오래가요. 가운데에서 버티는 팽이예요.',
        '균형형: 모든 능력이 보통이라 상성 걱정이 없어요.',
        '상성: 공격형 → 지구력형에 강함, 지구력형 → 방어형에 강함, 방어형 → 공격형에 강함.',
        '고르는 화면의 막대(공격·방어·지구력·속도)로 능력을 비교할 수 있어요.',
      ] },
      { h: '충돌 · 회전', p: [
        '팽이가 부딪히면 회전끼리 맞물려 서로 튕겨 나가요. 회전이 많을수록, 빠르게 부딪힐수록 상대를 더 멀리 날려요.',
        '맞을 때마다 회전이 깎여요. 상단 막대와 팽이 둘레의 고리가 남은 회전이에요. 빨개지면 비틀거리기 시작해요.',
        '테두리에 아주 빠르게 부딪히면 넘어가서 장외예요. 천천히 닿으면 튕겨 나와요.',
        '출발 직후 2초 동안은 테두리가 꽉 받쳐 줘서 장외가 거의 안 나요(첫 충돌에 바로 떨어지지 않게).',
        '동시에 떨어지면 마지막까지 버틴 팽이가 이겨요. 45초가 지나면 회전이 점점 빨리 줄어요. 100초가 지나도 안 끝나면 회전이 가장 많이 남은 팽이가 이겨요.',
      ] },
      { h: '경기장', p: [
        '나무 접시: 기본 경기장이에요.',
        '깊은 사발: 가운데로 세게 끌려가서 자주 부딪혀요. 테두리가 높아 장외는 잘 안 나요.',
        '팔각 링: 평평한 편이고, 네 변 가운데가 뚫려 있어요(빨간 화살표). 거기로 밀려나면 바로 장외!',
        '쌍둥이 웅덩이: 웅덩이 두 개 사이에 낮은 언덕이 있어요. 숨어 있다가 건너가 공격해요.',
        '「무작위」를 고르면 라운드마다 다른 경기장이 나와요. 팽이를 고를 때 이번 경기장을 미리 볼 수 있어요.',
      ] },
      { h: '승리 · 라운드', p: [
        '3판 2선승 또는 5판 3선승이에요(시작 전 옵션).',
        '라운드 사이마다 팽이와 색을 다시 고를 수 있어요(12초 뒤 자동 시작). 출발 자리는 라운드마다 돌아가며 바뀌어요.',
        '정말 똑같은 순간에 모두 떨어지면 무승부 라운드예요. 최대 판 수(3판 2선승이면 7판)를 넘으면 승수가 가장 많은 사람이 우승(같으면 공동 우승).',
      ] },
      { h: '팁', p: [
        '상대를 가장 가까운 테두리 쪽으로 밀어요. 상대보다 가운데 쪽에서 들이받으면 장외를 노릴 수 있어요.',
        '테두리 근처에서 바깥쪽으로 돌진하면 내가 넘어가요!',
        '지구력형은 피하기만 해도 이길 수 있어요. 공격형을 만나면 옆으로 슬쩍 비켜요.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 해요. 혼자 하면 나머지 자리는 AI 팽이예요. 친구와는 온라인·LAN 방으로(각자 폰 한 대). 물리는 호스트 폰이 계산해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 발사 타이밍이 들쭉날쭉하고 테두리 쪽으로 마구 돌진해요. 어려움은 거의 퍼펙트로 쏘고, 상대 팽이를 보고 상성 좋은 팽이를 골라요. 상대보다 안쪽에서 들이받아 장외를 노리고, 위험할 땐 피해요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { rotOf, slotOf, roundWinner, TYPES, ARENAS, COLORS, beats, rimInfo, spawnOf, defaultAim, qualityOf, newWorld, stepWorld, stepTop, collide, aiThink, aiLaunch, aiPick, counterPick, startLaunch, startPlay, roundOver, nextRound, H, CAP_T, SUDDEN },
  });
})();
