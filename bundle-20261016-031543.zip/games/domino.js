/* 도미노 쓰러뜨리기 — 스테이지마다 같은 도미노 개수로 길을 만들어 과녁(핀·종)을 쓰러뜨리는 퍼즐 대결.
   위에서 내려다본 바닥(36×60 cm). 모두 동시에 배치하고(쓰러뜨리기), 결정적 연쇄 시뮬레이션으로 채점한다.
   결정적 모델(고정 스텝 1/240 s, + − × ÷ √ 와 다항식 sin만 사용):
   · 도미노 = 앞 아래 모서리를 경첩으로 넘어가는 역진자: θ'' = K(sin θ − sin θc), θc = 넘어가기 시작하는 각
     (밀어 준 힘이 약하면 다시 일어선다).
   · 넘어가는 도미노의 윗면이 닿는 거리 r(앞쪽 광선 5개로 이웃 발자국/벽/종/공/시소에 쏜 거리)에서 H·sin θ = r 이 되면 충돌.
     다음 도미노가 받는 각속도 = ω · 0.85 · cos θ(닿는 높이) · |d·n|(방향이 어긋난 정도) · (가장자리 맞으면 감소).
     → 너무 촘촘하면 덜 넘어간 상태로 닿아 힘이 약하고, 너무 멀면 바닥 근처를 쳐서 약하고, 급커브는 방향 손실.
   · 갈림길: 넘어가면 ±30° 두 갈래로 민다. 다리: 구멍 위에 놓을 자리를 만든다. 계단: 높은 단으로 올라가는 길.
   · 공: 맞은 방향으로 굴러가며 핀·도미노를 쓰러뜨리고 벽에 튕긴다(경사로에서는 가속). 시소: 한쪽 끝을 치면 반대쪽이 튀어 오른다.
   apply가 모든 사람의 배치를 끝까지 시뮬레이션해 점수를 매기고 last={id, L(배치), R(결과)}를 남기며, 뷰는 같은 시뮬레이션을 재생한다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- constants ---------- */
  const FW = 36, FH = 60;                                   // floor, cm
  const DH = 4.4, DHN = 0.375, DHT = 1.1;                   // domino height, half thickness, half width
  const PH = 3.6, PR = 0.35;                                // pin height, radius
  const BR = 1.1, BELR = 1.3, SAWL = 5, SAWR = 1.5;         // ball radius, bell radius, seesaw half length, end zone radius
  const FKN = 0.55, FKT = 1.25;                             // fork footprint
  const BRL = 5.2, BRW = 1.7;                               // bridge half length (along n) / half width
  const STL = 3.2, STW = 1.9;                               // stairs half length / half width
  const SDT = 1 / 240, TCAP = 45, GRAV = 981;
  const PI = 3.141592653589793, TAU = 2 * PI, HPI = PI / 2;
  const SP = 2.8;                                           // comfortable spacing (centre to centre)
  const POSTE = 0.85;                                       // post (bumper) restitution for the ball
  const PINW = 1.2;                                         // width of a falling pin (head + neck) for what it can hit
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  // deterministic sine (Taylor to x^13 after range reduction): identical on every JS engine
  function dsin(x) {
    x = x - TAU * Math.round(x / TAU);
    if (x > HPI) x = PI - x; else if (x < -HPI) x = -PI - x;
    const x2 = x * x;
    return x * (1 - x2 / 6 * (1 - x2 / 20 * (1 - x2 / 42 * (1 - x2 / 72 * (1 - x2 / 110 * (1 - x2 / 156))))));
  }
  const dcos = (x) => dsin(x + HPI);
  const CS = []; for (let i = 0; i < 64; i++) CS.push([dcos(i * TAU / 64), dsin(i * TAU / 64)]);
  const C30 = 0.8660254037844386, S30 = 0.5;
  function angIdx(dx, dy) { const a = Math.atan2(dy, dx); return ((Math.round(a / TAU * 64) % 64) + 64) % 64; }

  /* ---------- stages (field 36×60, y grows downward; angle index 48 = up, 0 = right, 16 = down, 32 = left) ---------- */
  // d: 난이도 단계(1~5, 무작위 코스는 단계마다 하나씩 뽑아 쉬운 것부터). sp: [다리, 계단, 갈림길] allowances.
  // st: start domino [x, y, angle]. balls: [[x, y, aim angle]]. saws: [[x, y, axis angle]]. posts: [[x, y, r]] 기둥.
  // fx: 미리 놓인 검은 장치 도미노 줄 {a: 방향, c: 1이면 끝에서 내 도미노로 이어 갈 수 있음, p: [[x, y, 크기(1 = 보통), 방향?]]}
  // ramps: [x0, y0, x1, y1, dx, dy] (공이 (dx,dy) 쪽으로 빨라짐)
  const STAGES = [
    { nm: '첫 연쇄', d: 1, bud: 20, sp: [0, 0, 0], st: [18, 55, 48], walls: [[4, 33, 22, 34.5]], pins: [[27, 29], [13, 16]], bells: [[18, 6]] },
    { nm: '구멍 건너기', d: 2, bud: 24, sp: [1, 0, 0], st: [8, 55, 48], gaps: [[5, 27, 36, 33]], walls: [[15, 42, 25, 43.5]], pins: [[30, 47], [27, 15], [11, 13]], bells: [[19, 5]] },
    { nm: '굴러라 공', d: 3, bud: 26, sp: [0, 0, 0], st: [5, 55, 0], saws: [[20, 46, 56]], balls: [[12, 12.5, 48]],
      walls: [[7, 9.5, 35, 10.5], [7, 14.5, 9, 15.5], [15, 14.5, 35, 15.5]], ramps: [[9, 10.5, 16, 14.5, 1, 0]],
      pins: [[26, 40], [21, 12.5], [25.5, 12.5], [30, 12.5]], bells: [[33.5, 12.5]] },
    { nm: '갈림길', d: 2, bud: 28, sp: [0, 0, 1], st: [18, 56, 48], walls: [[17, 3, 19, 30]], pins: [[10, 22], [8, 14], [26, 22], [28, 14]], bells: [[6, 5], [30, 5]] },
    { nm: '높은 단', d: 5, bud: 34, sp: [1, 1, 1], st: [6, 57, 48], plat: [[5, 2, 31, 16]], gaps: [[9, 30, 36, 35]], balls: [[27, 46, 32]],
      walls: [[2, 42, 3, 50]], pins: [[11, 10], [26, 10], [19, 46], [13.5, 46]], bells: [[18, 6]] },
    // ---- round 7 ----
    { nm: '지그재그', d: 1, bud: 30, sp: [0, 0, 0], st: [18, 56, 48], walls: [[0, 40, 23, 41.5], [13, 22, 36, 23.5]],
      pins: [[30, 34], [6, 17]], bells: [[26, 6]] },
    { nm: '기둥 숲', d: 1, bud: 28, sp: [0, 0, 0], st: [18, 57, 48],
      posts: [[11, 47, 1.4], [25, 47, 1.4], [18, 39, 1.6], [6, 34, 1.4], [30, 34, 1.4], [12, 25, 1.5], [24, 25, 1.5], [18, 15, 1.6], [7, 12, 1.3], [29, 12, 1.3]],
      pins: [[18, 47], [13.5, 37], [18, 27.5], [23, 16.5]], bells: [[18, 5]] },
    { nm: '볼링장', d: 2, bud: 22, sp: [0, 0, 1], st: [6, 56, 0], balls: [[18, 43, 48]],
      walls: [[12, 17, 13, 40], [23, 17, 24, 40]], ramps: [[13, 22, 23, 38, 0, -1]],
      pins: [[18, 16], [17.1, 13], [18.9, 13], [15.1, 10.5], [18, 10.2], [20.9, 10.5], [5, 30], [31, 30]], bells: [[18, 5]] },
    { nm: '연쇄 시소', d: 3, bud: 24, sp: [0, 0, 0], st: [5, 57, 0], saws: [[29.5, 35, 48], [24.5, 26.5, 32], [16, 21.5, 48]],
      walls: [[10, 4, 11.5, 15], [20.5, 4, 22, 15], [10, 4, 22, 5.5], [10, 13.5, 14.5, 15], [17.5, 13.5, 22, 15]],
      pins: [[14, 56.5], [25.5, 53.5], [31.5, 19], [29, 8]], bells: [[16, 11]] },
    { nm: '거인 도미노', d: 3, bud: 20, sp: [0, 0, 0], st: [33, 56.5, 32], gaps: [[0, 26, 36, 30.5]],
      fx: [{ a: 32, c: 1, p: [[20, 56.5, 1, 32], [16.84, 56.03, 1, 35], [13.96, 54.67, 1, 38], [11.6, 52.53, 1, 41], [9.96, 49.79, 1, 44], [9.18, 46.7, 1, 47], [9, 43.03, 1.3, 48], [9, 38.33, 1.65, 48], [9, 32.34, 2.1, 48]] }],
      pins: [[26.5, 56.5], [9.5, 16], [15.5, 8.5], [23.5, 6]], bells: [[31.5, 8]] },
    { nm: '당구대', d: 3, bud: 14, sp: [0, 0, 0], st: [4, 58, 56], balls: [[19, 43, 56], [23.7, 38.3, 56]],
      posts: [[13, 37, 1.5], [26, 47, 1.5], [8, 26, 1.4], [27, 18, 1.4]],
      pins: [[9.5, 52.5], [27.2, 34.8], [29.96, 33.32], [28.68, 32.04], [33.14, 32.96], [31.3, 30.7], [29.04, 28.86]], bells: [[33.6, 25.4]] },
    { nm: '성벽 속 종', d: 4, bud: 32, sp: [0, 0, 1], st: [18, 56, 48],
      walls: [[8, 13, 9.5, 31], [26.5, 20, 28, 31], [8, 29.5, 28, 31], [8, 13, 21, 14.5]],
      pins: [[4, 34], [32, 34], [18, 45], [12, 8], [24, 7]], bells: [[17, 22.5]] },
    { nm: '굽은 강', d: 4, bud: 30, sp: [1, 0, 1], st: [8, 56, 48], gaps: [[0, 28, 22, 34], [16, 0, 22, 34]], balls: [[29, 33, 48]],
      ramps: [[24, 15, 34, 27, 0, -1]], pins: [[29, 12], [28.1, 9], [29.9, 9], [6, 10], [10, 20]], bells: [[4, 4]] },
    { nm: '산 넘기', d: 4, bud: 30, sp: [0, 1, 0], st: [18, 56, 48], plat: [[0, 24, 36, 36]],
      pins: [[8, 46], [9, 30], [27, 30], [10, 14], [26, 12]], bells: [[18, 5]] },
    { nm: '골드버그 장치', d: 5, bud: 20, sp: [1, 0, 0], st: [4, 57, 0], balls: [[30, 45, 48]], saws: [[25, 22, 32]],
      ramps: [[26, 26, 34, 40, 0, -1]], walls: [[22, 26, 24, 44]], gaps: [[4.5, 14, 9.5, 30], [0, 14, 4.5, 17], [0, 27, 4.5, 30]],
      fx: [{ a: 32, c: 0, p: [[17.5, 22, 1], [14.6, 22, 1.3], [11, 22, 1.8]] }],
      pins: [[12, 57], [20, 56], [30, 10]], bells: [[2.5, 22]] },
  ];

  function stageOf(i, mr) {
    const S = STAGES[i], mx = (x) => (mr ? FW - x : x), ma = (a) => (mr ? (96 - a) % 64 : a);
    const mrect = (r) => (mr ? [FW - r[2], r[1], FW - r[0], r[3]] : r.slice(0, 4));
    const fx = [], chains = [];
    (S.fx || []).forEach((ch) => {
      chains.push({ i0: fx.length, n: ch.p.length, cont: ch.c ? 1 : 0 });
      for (const q of ch.p) fx.push({ x: mx(q[0]), y: q[1], s: q[2] || 1, a: ma(q[3] != null ? q[3] : ch.a) });
    });
    return {
      i, mr, nm: S.nm, d: S.d, bud: S.bud, sp: S.sp.slice(),
      st: { x: mx(S.st[0]), y: S.st[1], a: ma(S.st[2]) },
      walls: (S.walls || []).map(mrect), gaps: (S.gaps || []).map(mrect), plat: (S.plat || []).map(mrect),
      ramps: (S.ramps || []).map((r) => mrect(r).concat([mr ? -r[4] : r[4], r[5]])),
      pins: (S.pins || []).map((p) => ({ x: mx(p[0]), y: p[1] })), bells: (S.bells || []).map((p) => ({ x: mx(p[0]), y: p[1] })),
      balls: (S.balls || []).map((b) => ({ x: mx(b[0]), y: b[1], a: ma(b[2]) })),
      saws: (S.saws || []).map((b) => ({ x: mx(b[0]), y: b[1], a: ma(b[2]) })),
      posts: (S.posts || []).map((p) => ({ x: mx(p[0]), y: p[1], r: p[2] })),
      fx, chains,
    };
  }

  /* ---------- layout encoding: 4 chars per piece (type 2b, x·4 8b, y·4 8b, angle 6b) ---------- */
  // types: 0 도미노, 1 다리, 2 계단, 3 갈림길
  function encL(ps) {
    let s = '';
    for (const p of ps) {
      const v = (p.t << 22) | (Math.round(p.x * 4) << 14) | (Math.round(p.y * 4) << 6) | (p.a & 63);
      s += B64[(v >> 18) & 63] + B64[(v >> 12) & 63] + B64[(v >> 6) & 63] + B64[v & 63];
    }
    return s;
  }
  function decL(s) {
    const out = [];
    if (typeof s !== 'string' || s.length % 4) throw new Error('bad layout');
    for (let i = 0; i < s.length; i += 4) {
      let v = 0;
      for (let k = 0; k < 4; k++) { const c = B64.indexOf(s[i + k]); if (c < 0) throw new Error('bad layout'); v = v * 64 + c; }
      out.push({ t: (v >> 22) & 3, x: ((v >> 14) & 255) / 4, y: ((v >> 6) & 255) / 4, a: v & 63 });
    }
    return out;
  }
  const q4 = (v) => Math.round(v * 4) / 4;

  /* ---------- geometry ---------- */
  const inR = (x, y, r) => x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3];
  function oRect(x, y, a, hn, ht) { const c = CS[a]; return { cx: x, cy: y, nx: c[0], ny: c[1], hn, ht }; }
  function inO(x, y, r, m) { const px = x - r.cx, py = y - r.cy, u = px * r.nx + py * r.ny, v = -px * r.ny + py * r.nx; m = m || 0; return Math.abs(u) <= r.hn + m && Math.abs(v) <= r.ht + m; }
  function wallRect(w) { return { cx: (w[0] + w[2]) / 2, cy: (w[1] + w[3]) / 2, nx: 1, ny: 0, hn: (w[2] - w[0]) / 2, ht: (w[3] - w[1]) / 2 }; }
  function rayRect(ox, oy, dx, dy, r) {
    const px = ox - r.cx, py = oy - r.cy, tx = -r.ny, ty = r.nx;
    const lu = px * r.nx + py * r.ny, lv = px * tx + py * ty, du = dx * r.nx + dy * r.ny, dv = dx * tx + dy * ty;
    let t0 = -1e9, t1 = 1e9;
    const slab = (p, d, h) => {
      if (Math.abs(d) < 1e-9) return p >= -h && p <= h;
      let a = (-h - p) / d, b = (h - p) / d; if (a > b) { const t = a; a = b; b = t; }
      if (a > t0) t0 = a; if (b < t1) t1 = b; return true;
    };
    if (!slab(lu, du, r.hn) || !slab(lv, dv, r.ht) || t0 > t1 || t1 < 0) return 1e9;
    return t0 < 0 ? 0 : t0;
  }
  function rayCirc(ox, oy, dx, dy, cx, cy, R) {
    const px = ox - cx, py = oy - cy, b = px * dx + py * dy, c = px * px + py * py - R * R;
    if (c <= 0) return 0;
    const disc = b * b - c; if (disc < 0 || b > 0) return 1e9;
    return -b - Math.sqrt(disc);
  }
  function rectCorners(r) {
    const tx = -r.ny, ty = r.nx, out = [];
    for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) out.push([r.cx + r.nx * r.hn * a + tx * r.ht * b, r.cy + r.ny * r.hn * a + ty * r.ht * b]);
    return out;
  }
  function closestOnRect(x, y, r) {
    const px = x - r.cx, py = y - r.cy, tx = -r.ny, ty = r.nx;
    const u = clamp(px * r.nx + py * r.ny, -r.hn, r.hn), v = clamp(px * tx + py * ty, -r.ht, r.ht);
    return [r.cx + r.nx * u + tx * v, r.cy + r.ny * u + ty * v];
  }
  function sawEnds(saw) { const c = CS[saw.a]; return [[saw.x - c[0] * SAWL, saw.y - c[1] * SAWL], [saw.x + c[0] * SAWL, saw.y + c[1] * SAWL]]; }
  function segDist(px, py, a, b) {
    const dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy;
    const t = l2 > 0 ? clamp(((px - a[0]) * dx + (py - a[1]) * dy) / l2, 0, 1) : 0;
    return Math.hypot(px - a[0] - dx * t, py - a[1] - dy * t);
  }
  // a standing piece record (shared by the simulation and the build view)
  function pieceRec(k, x, y, a, s, lv) {
    const c = CS[a];
    const hn = k === 'f' ? FKN : k === 'p' ? PR : DHN * s, ht = k === 'f' ? FKT : k === 'p' ? PR : DHT * s;
    return { k, x, y, a, s, nx: c[0], ny: c[1], hn, ht, H: k === 'p' ? PH : DH * s, r: oRect(x, y, a, hn, ht), lv, st: 0, b: -1, own: k === 'd' || k === 'f', li: -1 };
  }
  // every standing piece of a stage + layout, in simulation order: start, pins, fixed (검은) dominoes, the player's pieces
  function piecesOf(stg, ps, T) {
    const out = [pieceRec('s', stg.st.x, stg.st.y, stg.st.a, 1, T.level(stg.st.x, stg.st.y))];
    for (const p of stg.pins) out.push(pieceRec('p', p.x, p.y, 0, 1, T.level(p.x, p.y)));
    for (const f of stg.fx) out.push(pieceRec('x', f.x, f.y, f.a, f.s, T.level(f.x, f.y)));
    ps.forEach((p, i) => { if (p.t === 0 || p.t === 3) { const q = pieceRec(p.t === 3 ? 'f' : 'd', p.x, p.y, p.a, 1, T.level(p.x, p.y)); q.li = i; out.push(q); } });
    return out;
  }

  /* terrain queries for a stage + the player's bridges/stairs */
  function Terrain(stg, brs, sts) { this.S = stg; this.br = brs || []; this.sz = sts || []; this.wr = stg.walls.map(wallRect); }
  Terrain.prototype.hole = function (x, y) {
    if (!this.S.gaps.some((g) => inR(x, y, g))) return false;
    return !this.br.some((b) => inO(x, y, b));
  };
  Terrain.prototype.level = function (x, y) {
    if (this.sz.some((s) => inO(x, y, s))) return 0.5;
    if (this.S.plat.some((p) => inR(x, y, p))) return 1;
    if (this.S.ramps.some((r) => inR(x, y, r))) return 0.5;
    return 0;
  };
  Terrain.prototype.wall = function (x, y, m) { return this.wr.some((w) => inO(x, y, w, m)); };
  Terrain.prototype.post = function (x, y, m) { return this.S.posts.some((q) => (x - q.x) * (x - q.x) + (y - q.y) * (y - q.y) < (q.r + m) * (q.r + m)); };
  Terrain.prototype.ramp = function (x, y) { return this.S.ramps.find((r) => inR(x, y, r)) || null; };

  // can a piece go here? (pieces = already validated list, for bridges/stairs)
  function pieceOk(stg, T, p) {
    if (!(p.x >= 0.5 && p.x <= FW - 0.5 && p.y >= 0.5 && p.y <= FH - 0.5) || p.a < 0 || p.a > 63) return false;
    if (p.t === 1 || p.t === 2) return !T.wall(p.x, p.y, 0.2) && !T.post(p.x, p.y, 0.2);
    const r = p.t === 3 ? oRect(p.x, p.y, p.a, FKN, FKT) : oRect(p.x, p.y, p.a, DHN, DHT);
    const pts = rectCorners(r); pts.push([p.x, p.y]);
    for (const q of pts) {
      if (q[0] < 0.2 || q[0] > FW - 0.2 || q[1] < 0.2 || q[1] > FH - 0.2) return false;
      if (T.wall(q[0], q[1], 0.1) || T.post(q[0], q[1], 0.1) || T.hole(q[0], q[1]) || (T.ramp(q[0], q[1]) && !T.sz.some((s) => inO(q[0], q[1], s)))) return false;
    }
    const d2 = (x, y) => Math.hypot(p.x - x, p.y - y);
    if (d2(stg.st.x, stg.st.y) < 1.4) return false;
    for (const q of stg.pins) if (d2(q.x, q.y) < 1.0) return false;
    for (const q of stg.bells) if (d2(q.x, q.y) < BELR + 0.7) return false;
    for (const q of stg.balls) if (d2(q.x, q.y) < BR + 0.7) return false;
    for (const q of stg.saws) { const e = sawEnds(q); if (segDist(p.x, p.y, e[0], e[1]) < 1.0) return false; }
    for (const f of stg.fx) if (inO(p.x, p.y, oRect(f.x, f.y, f.a, DHN * f.s, DHT * f.s), 0.85)) return false;
    return true;
  }
  // validate a whole layout; returns {ps, T} or throws
  function checkLayout(stg, ps) {
    const cnt = [0, 0, 0, 0];
    for (const p of ps) cnt[p.t]++;
    if (cnt[0] > stg.bud || cnt[1] > stg.sp[0] || cnt[2] > stg.sp[1] || cnt[3] > stg.sp[2]) throw new Error('too many pieces');
    const brs = ps.filter((p) => p.t === 1).map((p) => oRect(p.x, p.y, p.a, BRL, BRW));
    const sts = ps.filter((p) => p.t === 2).map((p) => oRect(p.x, p.y, p.a, STL, STW));
    const T = new Terrain(stg, brs, sts);
    for (const p of ps) if (!pieceOk(stg, T, p)) throw new Error('bad piece');
    return T;
  }

  /* ---------- chain-reaction world ---------- */
  function World(stg, ps) {
    const T = (this.T = checkLayout(stg, ps));
    this.S = stg; this.t = 0; this.done = false; this.quiet = 0; this.snd = [];
    this.bodies = []; this.fl = [];
    this.pc = piecesOf(stg, ps, T);
    this.fx0 = 1 + stg.pins.length;
    this.bells = stg.bells.map((b) => ({ x: b.x, y: b.y, hit: 0, tt: -1 }));
    this.balls = stg.balls.map((b) => ({ x: b.x, y: b.y, vx: 0, vy: 0, mv: 0, moved: 0, gone: 0, rot: 0, hx: 1, hy: 0 }));
    this.saws = stg.saws.map((sw) => { const c = CS[sw.a]; return { e: sawEnds(sw), ux: c[0], uy: c[1], used: 0, side: 0, tt: -1 }; });
    this.trigger(0, this.pc[0].nx, this.pc[0].ny, 5.2);
  }
  World.prototype.events = function (o, d, w, H, lvl, self) {
    const ev = [], ox = o[0], oy = o[1], dx = d[0], dy = d[1], tx = -dy, ty = dx;
    const offs = w > 1 ? [0, -0.2 * w, 0.2 * w, -0.45 * w, 0.45 * w] : [0];
    const reach = H + 0.02, hw = w / 2 || 1;
    const best = (fn) => { let b = 1e9, bl = 0; for (const l of offs) { const r = fn(ox + tx * l, oy + ty * l); if (r < b) { b = r; bl = l; } } return [b, Math.abs(bl) / hw]; };
    const push = (e, h) => { if (h[0] <= reach) { e.r = h[0]; e.lat = h[1]; e.o = ev.length; ev.push(e); } };
    for (let i = 0; i < this.pc.length; i++) {
      if (i === self) continue;
      const P = this.pc[i];
      if (Math.abs(P.x - ox) > reach + 1.2 + P.ht || Math.abs(P.y - oy) > reach + 1.2 + P.ht) continue;
      if (P.lv > lvl + 0.5) continue;
      const h = P.k === 'p' ? best((x, y) => rayCirc(x, y, dx, dy, P.x, P.y, PR)) : best((x, y) => rayRect(x, y, dx, dy, P.r));
      h[1] = Math.min(1, Math.abs((P.x - ox) * tx + (P.y - oy) * ty) / (hw + P.ht)); // how far off the centre line the target stands
      push({ k: 0, i }, h);
    }
    this.bells.forEach((B, i) => push({ k: 1, i }, best((x, y) => rayCirc(x, y, dx, dy, B.x, B.y, BELR))));
    this.balls.forEach((B, i) => { if (!B.moved) push({ k: 2, i }, best((x, y) => rayCirc(x, y, dx, dy, B.x, B.y, BR))); });
    this.saws.forEach((S, s) => { if (!S.used) for (let e = 0; e < 2; e++) { const p = S.e[e]; push({ k: 3, s, e }, best((x, y) => rayCirc(x, y, dx, dy, p[0], p[1], SAWR))); } });
    for (const wr of this.T.wr) push({ k: 4 }, best((x, y) => rayRect(x, y, dx, dy, wr)));
    for (const q of this.S.posts) push({ k: 4 }, best((x, y) => rayCirc(x, y, dx, dy, q.x, q.y, q.r)));
    if (lvl < 0.5) for (const pr of this.S.plat) {
      const r = wallRect(pr), h = best((x, y) => rayRect(x, y, dx, dy, r));
      if (h[0] <= reach) { const ex = ox + dx * (h[0] + 0.05), ey = oy + dy * (h[0] + 0.05); if (!this.T.sz.some((s) => inO(ex, ey, s))) push({ k: 4 }, h); }
    }
    ev.sort((a, b) => a.r - b.r || a.o - b.o);
    return ev;
  };
  World.prototype.addBody = function (kind, pi, o, d, w, H, hn, om, lvl) {
    const sc = (2 * hn) / Math.sqrt(4 * hn * hn + H * H);
    const b = { kind, pi, o, d, w, H, sc, K: 1.5 * GRAV / H, th: 0, om, st: 1, ev: kind === 'fv' ? [] : this.events(o, d, w, H, lvl, pi), ci: 0, lean: -1, thc: 0, arms: null };
    this.bodies.push(b);
    return this.bodies.length - 1;
  };
  // push piece pi in direction (px,py) with angular speed om; returns the body index or -1
  World.prototype.trigger = function (pi, px, py, om) {
    const P = this.pc[pi];
    if (P.st !== 0) return -1;
    let bi;
    if (P.k === 'p') {
      if (om < 0.2) return -1;
      bi = this.addBody('p', pi, [P.x + px * PR, P.y + py * PR], [px, py], PINW, PH, PR, om, P.lv);
    } else {
      const dot = px * P.nx + py * P.ny, s = dot >= 0 ? 1 : -1;
      om *= Math.abs(dot);
      if (om < 0.2) return -1;
      const d = [P.nx * s, P.ny * s], o = [P.x + d[0] * P.hn, P.y + d[1] * P.hn];
      if (P.k === 'f') {
        bi = this.addBody('fv', pi, o, d, 2 * P.ht, DH, P.hn, om, P.lv);
        const a1 = [d[0] * C30 - d[1] * S30, d[0] * S30 + d[1] * C30], a2 = [d[0] * C30 + d[1] * S30, -d[0] * S30 + d[1] * C30];
        const i1 = this.addBody('arm', pi, o, a1, 1.4, DH, P.hn, om, P.lv), i2 = this.addBody('arm', pi, o, a2, 1.4, DH, P.hn, om, P.lv);
        this.bodies[bi].arms = [i1, i2];
      } else bi = this.addBody('d', pi, o, d, 2 * P.ht, P.H, P.hn, om, P.lv);
    }
    P.st = 1; P.b = bi;
    return bi;
  };
  World.prototype.rest = function (b, bi) { b.st = 2; b.thc = b.th; if (b.pi >= 0 && this.pc[b.pi].b === bi) this.pc[b.pi].st = 2; };
  World.prototype.flick = function (si, side) {
    const s = this.saws[si]; s.used = 1; s.side = side; s.tt = this.t;
    const from = s.e[side], to = s.e[1 - side], ux = (to[0] - from[0]) / (2 * SAWL), uy = (to[1] - from[1]) / (2 * SAWL);
    this.fl.push({ t: this.t + 0.12, o: [to[0], to[1]], d: [ux, uy] });
    this.snd.push({ k: 'saw', x: from[0], y: from[1] });
  };
  World.prototype.contact = function (bi, b, e) {
    const x = b.o[0] + b.d[0] * e.r, y = b.o[1] + b.d[1] * e.r;
    if (e.k === 0) {
      const P = this.pc[e.i];
      if (P.st !== 0) return false;
      // a small domino gives a big one less spin (same push at the top, longer lever)
      const mass = P.H > b.H ? Math.sqrt(b.H / P.H) : 1;
      const T = (P.k === 'p' ? 1.05 : 0.9) * dcos(b.th) * (1 - 0.4 * e.lat * e.lat) * mass;
      const nb = this.trigger(e.i, b.d[0], b.d[1], b.om * T);
      this.snd.push({ k: P.k === 'p' ? 'pin' : P.H > DH + 0.5 ? 'big' : 'clack', x, y, v: b.om });
      this.rest(b, bi); b.lean = nb;
      return true;
    }
    if (e.k === 1) {
      const B = this.bells[e.i];
      if (!B.hit && b.om > 0.4) { B.hit = 1; B.tt = this.t; this.snd.push({ k: 'bell', x: B.x, y: B.y }); }
      this.rest(b, bi); return true;
    }
    if (e.k === 2) {
      const ba = this.balls[e.i];
      if (ba.moved) return false;
      const v = b.om * b.H * dcos(b.th) * 0.9;
      ba.vx = b.d[0] * v; ba.vy = b.d[1] * v; ba.mv = 1; ba.moved = 1;
      this.snd.push({ k: 'ball', x: ba.x, y: ba.y });
      this.rest(b, bi); return true;
    }
    if (e.k === 3) { if (!this.saws[e.s].used) this.flick(e.s, e.e); return false; }
    this.snd.push({ k: 'wall', x, y });
    this.rest(b, bi); return true;
  };
  World.prototype.ballStep = function (B, dt) {
    const T = this.T;
    let ax = 0, ay = 0;
    const rp = T.ramp(B.x, B.y); if (rp) { ax += 90 * rp[4]; ay += 90 * rp[5]; }
    let sp = Math.sqrt(B.vx * B.vx + B.vy * B.vy);
    if (sp > 1e-6) { ax -= 5 * B.vx / sp; ay -= 5 * B.vy / sp; }
    B.vx += ax * dt; B.vy += ay * dt;
    let nx = B.x + B.vx * dt, ny = B.y + B.vy * dt;
    const l0 = T.level(B.x, B.y);
    if (T.level(nx, ny) - l0 > 0.6) {
      if (T.level(nx, B.y) - l0 > 0.6) B.vx = -B.vx * 0.5; else B.vy = -B.vy * 0.5;
      nx = B.x; ny = B.y; this.snd.push({ k: 'bump', x: B.x, y: B.y });
    }
    const dmv = Math.sqrt((nx - B.x) * (nx - B.x) + (ny - B.y) * (ny - B.y));
    B.rot += dmv / BR; if (dmv > 1e-6) { B.hx = (nx - B.x) / dmv; B.hy = (ny - B.y) / dmv; }
    B.x = nx; B.y = ny;
    for (const w of T.wr) {
      const c = closestOnRect(B.x, B.y, w), dx = B.x - c[0], dy = B.y - c[1], d = Math.sqrt(dx * dx + dy * dy);
      if (d < BR && d > 1e-9) {
        const n0 = dx / d, n1 = dy / d, vn = B.vx * n0 + B.vy * n1;
        B.x += n0 * (BR - d); B.y += n1 * (BR - d);
        if (vn < 0) { B.vx -= 1.5 * vn * n0; B.vy -= 1.5 * vn * n1; if (vn < -3) this.snd.push({ k: 'bump', x: B.x, y: B.y }); }
      }
    }
    for (const q of this.S.posts) {
      const dx = B.x - q.x, dy = B.y - q.y, d = Math.sqrt(dx * dx + dy * dy), R = BR + q.r;
      if (d < R && d > 1e-9) {
        const n0 = dx / d, n1 = dy / d, vn = B.vx * n0 + B.vy * n1;
        B.x = q.x + n0 * R; B.y = q.y + n1 * R;
        if (vn < 0) { B.vx -= (1 + POSTE) * vn * n0; B.vy -= (1 + POSTE) * vn * n1; if (vn < -3) this.snd.push({ k: 'bump', x: B.x, y: B.y }); }
      }
    }
    if (B.x < BR) { B.x = BR; B.vx = Math.abs(B.vx) * 0.5; } if (B.x > FW - BR) { B.x = FW - BR; B.vx = -Math.abs(B.vx) * 0.5; }
    if (B.y < BR) { B.y = BR; B.vy = Math.abs(B.vy) * 0.5; } if (B.y > FH - BR) { B.y = FH - BR; B.vy = -Math.abs(B.vy) * 0.5; }
    if (T.hole(B.x, B.y)) { B.gone = 1; B.mv = 0; this.snd.push({ k: 'drop', x: B.x, y: B.y }); return; }
    sp = Math.sqrt(B.vx * B.vx + B.vy * B.vy);
    if (sp > 1e-6) {
      const lv = T.level(B.x, B.y);
      for (let i = 0; i < this.pc.length; i++) {
        const P = this.pc[i];
        if (P.st !== 0 || Math.abs(P.x - B.x) > 3 + P.ht || Math.abs(P.y - B.y) > 3 + P.ht || P.lv > lv + 0.5) continue;
        let hit;
        if (P.k === 'p') hit = (P.x - B.x) * (P.x - B.x) + (P.y - B.y) * (P.y - B.y) < (BR + PR) * (BR + PR);
        else { const c = closestOnRect(B.x, B.y, P.r); hit = (c[0] - B.x) * (c[0] - B.x) + (c[1] - B.y) * (c[1] - B.y) < BR * BR; }
        if (hit) {
          // a pin flies off along the line from the ball's centre through it, a domino along the roll
          let ux = B.vx / sp, uy = B.vy / sp;
          if (P.k === 'p') { const dx = P.x - B.x, dy = P.y - B.y, dl = Math.sqrt(dx * dx + dy * dy); if (dl > 1e-6) { ux = dx / dl; uy = dy / dl; } }
          const nb = this.trigger(i, ux, uy, sp / P.H * 1.4);
          if (nb >= 0) { B.vx *= 0.8; B.vy *= 0.8; this.snd.push({ k: P.k === 'p' ? 'pin' : 'clack', x: P.x, y: P.y, v: 8 }); }
        }
      }
      for (const Bl of this.bells) {
        const dx = B.x - Bl.x, dy = B.y - Bl.y, d = Math.sqrt(dx * dx + dy * dy);
        if (d < BR + BELR && d > 1e-9) {
          const n0 = dx / d, n1 = dy / d, vn = B.vx * n0 + B.vy * n1;
          B.x = Bl.x + n0 * (BR + BELR); B.y = Bl.y + n1 * (BR + BELR);
          if (vn < 0) { B.vx -= 1.6 * vn * n0; B.vy -= 1.6 * vn * n1; }
          if (!Bl.hit) { Bl.hit = 1; Bl.tt = this.t; this.snd.push({ k: 'bell', x: Bl.x, y: Bl.y }); }
        }
      }
      for (let s = 0; s < this.saws.length; s++) {
        const S = this.saws[s]; if (S.used) continue;
        for (let e = 0; e < 2; e++) {
          const p = S.e[e];
          if ((B.x - p[0]) * (B.x - p[0]) + (B.y - p[1]) * (B.y - p[1]) < (BR + SAWR) * (BR + SAWR)) { this.flick(s, e); break; }
        }
      }
    }
    if (sp < 0.6 && !rp) { B.mv = 0; B.vx = 0; B.vy = 0; }
  };
  // ball against ball (equal masses, a little loss)
  World.prototype.ballPairs = function () {
    const bs = this.balls;
    for (let i = 0; i < bs.length; i++) for (let j = i + 1; j < bs.length; j++) {
      const A = bs[i], B = bs[j];
      if (A.gone || B.gone || (!A.mv && !B.mv)) continue;
      const dx = B.x - A.x, dy = B.y - A.y, d2 = dx * dx + dy * dy;
      if (d2 >= 4 * BR * BR || d2 < 1e-12) continue;
      const d = Math.sqrt(d2), n0 = dx / d, n1 = dy / d, ov = (2 * BR - d) / 2;
      A.x -= n0 * ov; A.y -= n1 * ov; B.x += n0 * ov; B.y += n1 * ov;
      const vr = (A.vx - B.vx) * n0 + (A.vy - B.vy) * n1;
      if (vr <= 0) continue;
      const j2 = vr * 0.96;
      A.vx -= j2 * n0; A.vy -= j2 * n1; B.vx += j2 * n0; B.vy += j2 * n1;
      A.mv = B.mv = 1; A.moved = B.moved = 1;
      this.snd.push({ k: 'clack', x: (A.x + B.x) / 2, y: (A.y + B.y) / 2, v: 9 });
    }
  };
  World.prototype.step = function () {
    if (this.done) return;
    const dt = SDT;
    for (let k = 0; k < this.fl.length; k++) {
      const f = this.fl[k];
      if (this.t >= f.t) {
        const bi = this.addBody('k', -1, f.o, f.d, 2.0, 4.6, 0.3, 9, this.T.level(f.o[0], f.o[1]));
        this.fl.splice(k--, 1); this.bodies[bi].flick = 1;
      }
    }
    let active = this.fl.length > 0;
    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (b.st === 1) {
        if (b.kind === 'fv') continue;
        active = true;
        b.om += b.K * (dsin(b.th) - b.sc) * dt;
        b.th += b.om * dt;
        if (b.th <= 0 && b.om <= 0) {
          b.th = 0; b.om = 0; b.st = 3;
          if (b.pi >= 0 && this.pc[b.pi].b === i && b.kind !== 'arm') { this.pc[b.pi].st = 0; this.pc[b.pi].b = -1; }
          continue;
        }
        if (b.th >= HPI) { b.th = HPI; this.rest(b, i); if (b.kind === 'd' || b.kind === 'p') this.snd.push({ k: b.H > DH + 0.5 ? 'big' : 'flat', x: b.o[0], y: b.o[1] }); }
        const reach = b.H * dsin(b.th);
        while (b.ci < b.ev.length && b.ev[b.ci].r <= reach) { const e = b.ev[b.ci++]; if (this.contact(i, b, e)) break; }
      } else if (b.st === 2 && b.lean >= 0) {
        const nb = this.bodies[b.lean], tg = b.thc + 0.6 * nb.th;
        if (tg > b.th) b.th = tg > 1.4 ? 1.4 : tg;
      }
    }
    // fork visual body follows its arms
    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (b.kind !== 'fv' || b.st === 3) continue;
      const a1 = this.bodies[b.arms[0]], a2 = this.bodies[b.arms[1]];
      b.th = a1.th > a2.th ? a1.th : a2.th;
      if (a1.st === 3 && a2.st === 3) { b.st = 3; b.th = 0; const P = this.pc[b.pi]; if (P.b === i) { P.st = 0; P.b = -1; } }
      else if (a1.st !== 1 && a2.st !== 1) { b.st = 2; this.pc[b.pi].st = 2; }
    }
    let rolling = false;
    for (const B of this.balls) if (B.mv) { rolling = true; this.ballStep(B, dt); }
    if (rolling) { active = true; if (this.balls.length > 1) this.ballPairs(); }
    this.t += dt;
    this.quiet = active ? 0 : this.quiet + 1;
    if (this.quiet > 0.3 / SDT || this.t > TCAP) this.done = true;
  };
  World.prototype.run = function () { let g = 0; while (!this.done && g++ < TCAP / SDT + 10) this.step(); return this; };
  World.prototype.res = function () {
    let h = 0, c = 0;
    for (const P of this.pc) {
      if (P.b < 0) continue;
      const b = this.bodies[P.b];
      if (P.k === 'p' && b.th > 0.4) h++;
      if (P.own && b.th > 0.25) c++;
    }
    for (const B of this.bells) if (B.hit) h++;
    return { h, c };
  };
  function targetsOf(stg) { return stg.pins.length + stg.bells.length; }
  function scoreOf(stg, ps, r) { const used = ps.filter((p) => p.t === 0).length; return { h: r.h, c: r.c, l: stg.bud - used, sc: r.h * 10 + (stg.bud - used) + r.c }; }
  function simLayout(stg, ps) { const w = new World(stg, ps).run(); return scoreOf(stg, ps, w.res()); }

  /* ---------- state ---------- */
  function pickStages(ns) {
    const groups = ns === 3 ? [[1, 2], [3], [4, 5]] : [[1], [2], [3], [4], [5]];
    return groups.map((g) => {
      const c = []; STAGES.forEach((S, i) => { if (g.includes(S.d)) c.push(i); });
      return c[Math.floor(Math.random() * c.length)];
    });
  }
  function init(players, opts) {
    const n = players.length, ns = opts && +opts.stg === 3 ? 3 : 5, mp = opts && opts.map != null ? opts.map : 'r';
    let sl;
    if (mp === 'b') sl = ns === 3 ? [0, 2, 4] : [0, 1, 2, 3, 4];                       // 기본 코스(예전 그대로)
    else if (Number.isInteger(mp) && mp >= 0 && mp < STAGES.length) sl = [mp];          // 맵 하나만
    else sl = pickStages(ns);                                                           // 무작위: 단계마다 하나씩, 쉬운 것부터
    return {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)), sl, mr: sl.map(() => (Math.random() < 0.5 ? 1 : 0)),
      r: 0, sb: players.map(() => ''), dn: players.map(() => 0), tot: players.map(() => 0), hs: [], seq: 0, last: null, ph: 'b',
    };
  }
  const curStage = (s) => stageOf(s.sl[s.r], s.mr[s.r]);
  function actor(s) { if (s.ph !== 'b') return null; const a = []; for (let i = 0; i < s.n; i++) if (!s.dn[i]) a.push(i); return a; }
  function apply(s, seat, a) {
    if (s.ph !== 'b') throw new Error('game over');
    if (!Number.isInteger(seat) || seat < 0 || seat >= s.n || s.dn[seat]) throw new Error('not your turn');
    if (!a || a.k !== 's' || typeof a.d !== 'string' || a.d.length > 4 * 48) throw new Error('bad action');
    const stg = curStage(s), ps = decL(a.d);
    checkLayout(stg, ps);
    s.sb[seat] = a.d; s.dn[seat] = 1;
    if (s.dn.some((x) => !x)) return s;
    const R = [];
    for (let i = 0; i < s.n; i++) { const r = simLayout(stg, decL(s.sb[i])); R.push([r.h, r.c, r.l, r.sc]); s.tot[i] += r.sc; }
    s.hs.push(R.map((x) => x[3]));
    s.seq++;
    s.last = { id: s.seq, r: s.r, si: s.sl[s.r], mr: s.mr[s.r], L: s.sb.slice(), R };
    s.r++;
    s.sb = s.sb.map(() => ''); s.dn = s.dn.map(() => 0);
    if (s.r >= s.sl.length) s.ph = 'e';
    return s;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const nm = (i) => s.nm[i] || (i + 1) + '번';
    const best = Math.max(...s.tot), w = []; s.tot.forEach((v, i) => { if (v === best) w.push(i); });
    const order = s.tot.map((v, i) => [v, i]).sort((a, b) => b[0] - a[0] || a[1] - b[1]);
    const text = order.map(([v, i], r) => (r + 1) + '위 ' + nm(i) + ' · ' + v + '점').join('\n');
    if (s.n === 1) return { winners: [0], title: '총점 ' + s.tot[0] + '점', text: s.hs.map((h, r) => (r + 1) + '스테이지 ' + h[0] + '점').join('\n') };
    return { winners: w, text };
  }

  /* ---------- AI: route search over waypoints + full simulation of the best plans ---------- */
  const NX = FW, NY = FH, NC = NX * NY;
  const aiCache = {};
  function devSim(stg, kind, i, e) {
    const w = new World(stg, []);
    w.bodies = []; w.pc[0].st = 2; w.pc[0].b = -1; w.fl = []; w.snd = [];
    if (kind === 'ball') { const B = w.balls[i], c = CS[stg.balls[i].a]; B.vx = c[0] * 20; B.vy = c[1] * 20; B.mv = 1; B.moved = 1; }
    else if (kind === 'saw') w.flick(i, e);
    else { const pi = w.fx0 + stg.chains[i].i0, P = w.pc[pi]; w.trigger(pi, P.nx, P.ny, 6); }
    w.run();
    const set = [], dev = [];
    w.pc.forEach((P, k) => { if (P.k === 'p' && P.b >= 0 && w.bodies[P.b].th > 0.4) set.push('p' + (k - 1)); });
    w.bells.forEach((B, k) => { if (B.hit) set.push('b' + k); });
    w.balls.forEach((B, k) => { if (B.moved) dev.push('ball' + k); });
    w.saws.forEach((S, k) => { if (S.used) dev.push('saw' + k); });
    stg.chains.forEach((ch, k) => { if (w.pc[w.fx0 + ch.i0].st) dev.push('fx' + k); });
    return { set, dev };
  }
  function grid(stg) {
    const key = stg.i + '_' + stg.mr;
    if (aiCache[key]) return aiCache[key];
    const T = new Terrain(stg, [], []);
    const blk = new Uint8Array(NC), hole = new Uint8Array(NC), lev = new Float32Array(NC);
    const es = stg.saws.map(sawEnds);
    for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) {
      const x = i + 0.5, y = j + 0.5, c = j * NX + i;
      let b = x < 1.2 || x > FW - 1.2 || y < 1.2 || y > FH - 1.2 || T.wall(x, y, 1.3) || T.post(x, y, 1.3) || !!T.ramp(x, y);
      for (const q of stg.bells) if (Math.hypot(x - q.x, y - q.y) < BELR + 1.4) b = true;
      for (const q of stg.balls) if (Math.hypot(x - q.x, y - q.y) < BR + 1.4) b = true;
      for (const e of es) if (segDist(x, y, e[0], e[1]) < 1.6) b = true;
      for (const f of stg.fx) if (inO(x, y, oRect(f.x, f.y, f.a, DHN * f.s, DHT * f.s), 1.3)) b = true;
      blk[c] = b ? 1 : 0; hole[c] = stg.gaps.some((g) => inR(x, y, [g[0] - 0.6, g[1] - 0.6, g[2] + 0.6, g[3] + 0.6])) ? 1 : 0; lev[c] = T.level(x, y);
    }
    const G = { T, blk, hole, lev, dj: {} };
    // what does each gadget (ball, seesaw end, black domino line) knock over by itself?
    G.dev = {};
    stg.balls.forEach((_, i) => { G.dev['ball' + i] = devSim(stg, 'ball', i, 0); });
    stg.saws.forEach((_, i) => { for (let e = 0; e < 2; e++) G.dev['saw' + i + '_' + e] = devSim(stg, 'saw', i, e); });
    stg.chains.forEach((_, i) => { G.dev['fx' + i] = devSim(stg, 'fx', i, 0); });
    return (aiCache[key] = G);
  }
  const cellOf = (x, y) => clamp(Math.floor(y), 0, NY - 1) * NX + clamp(Math.floor(x), 0, NX - 1);
  // Dijkstra over 4 layers (bit0: bridge used, bit1: stairs used)
  function dijkstra(G, x, y, av) {
    const key = Math.round(x * 4) + ',' + Math.round(y * 4) + ',' + av;
    if (G.dj[key]) return G.dj[key];
    const N = 4 * NC, dist = new Float64Array(N).fill(1e9), prev = new Int32Array(N).fill(-1);
    const heap = [], push = (d, n) => { heap.push([d, n]); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
    const s0 = cellOf(x, y); dist[s0] = 0; push(0, s0);
    const DIRS = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];
    while (heap.length) {
      const [d, n] = pop();
      if (d > dist[n]) continue;
      const ly = n / NC | 0, c = n - ly * NC, ci = c % NX, cj = (c - ci) / NX;
      for (const [di, dj, w] of DIRS) {
        const ni = ci + di, nj = cj + dj;
        if (ni < 0 || nj < 0 || ni >= NX || nj >= NY) continue;
        const nc = nj * NX + ni;
        if (G.blk[nc]) continue;
        if (di && dj && (G.blk[cj * NX + ni] || G.blk[nj * NX + ci])) continue;
        let nl = ly, cost = w;
        if (G.hole[nc]) {
          if (!G.hole[c]) { if (!(av & 1) || (ly & 1)) continue; nl = ly | 1; cost += 6; }
          cost += w;
        }
        if (G.lev[nc] - G.lev[c] > 0.6) { if (!(av & 2) || (ly & 2)) continue; nl = nl | 2; cost += 6; }
        const nn = nl * NC + nc, nd = d + cost;
        if (nd < dist[nn]) { dist[nn] = nd; prev[nn] = n; push(nd, nn); }
      }
    }
    return (G.dj[key] = { dist, prev, x, y });
  }
  function pathTo(D, layer, c) {
    const out = []; let n = layer * NC + c, g = 0;
    while (n >= 0 && g++ < 5000) { const cc = n % NC; out.push([cc % NX + 0.5, (cc / NX | 0) + 0.5]); n = D.prev[n]; }
    return out.reverse();
  }
  // goals: entry cell + final points + continuation point
  function goalsOf(stg, G) {
    const gs = [];
    stg.pins.forEach((p, i) => gs.push({ id: 'p' + i, k: 'pin', x: p.x, y: p.y, val: ['p' + i], ends: false, gb: 2.4, ga: 2.6 }));
    stg.bells.forEach((p, i) => gs.push({ id: 'b' + i, k: 'bell', x: p.x, y: p.y, val: ['b' + i], ends: true, gb: BELR + 2.0 }));
    stg.balls.forEach((b, i) => {
      const c = CS[b.a], D = G.dev['ball' + i];
      gs.push({ id: 'ball' + i, k: 'ball', x: b.x, y: b.y, val: D.set, dev: D.dev, ends: true, gb: BR + 2.0, pre: [b.x - c[0] * 7, b.y - c[1] * 7] });
    });
    stg.saws.forEach((sw, i) => {
      const e = sawEnds(sw);
      for (let v = 0; v < 2; v++) {
        const A = e[v], B = e[1 - v], ux = (B[0] - A[0]) / (2 * SAWL), uy = (B[1] - A[1]) / (2 * SAWL), D = G.dev['saw' + i + '_' + v];
        gs.push({ id: 'saw' + i, k: 'saw', x: A[0], y: A[1], val: D.set, dev: D.dev, ends: false, gb: SAWR + 1.6, ga: 2.8, pre: [A[0] - ux * 8, A[1] - uy * 8], ex: [B[0], B[1]], ux, uy });
      }
    });
    stg.chains.forEach((ch, i) => {
      const f = stg.fx[ch.i0], c = CS[f.a], D = G.dev['fx' + i];
      const g = { id: 'fx' + i, k: 'fx', x: f.x, y: f.y, val: D.set, dev: D.dev, ends: !ch.cont, gb: SP * f.s, pre: [f.x - c[0] * 7, f.y - c[1] * 7] };
      if (ch.cont) {
        // keep building after the last (biggest) black domino: the line goes on where its top lands
        const L2 = stg.fx[ch.i0 + ch.n - 1], c2 = CS[L2.a], H = DH * L2.s, fr = DHN * L2.s, k = fr + 0.7 * H + DHN - 1.8;
        g.ex = [L2.x + c2[0] * k, L2.y + c2[1] * k]; g.ux = c2[0]; g.uy = c2[1]; g.ga = 0.3;
      }
      gs.push(g);
    });
    return gs;
  }
  // approach cell for a goal from a Dijkstra result: returns {layer, cell, d}
  function approach(G, D, g, used, av) {
    let cands;
    if (g.pre) cands = [cellOf(g.pre[0], g.pre[1])];
    else if (g.k === 'pin') cands = [cellOf(g.x, g.y)];
    else { cands = []; for (let j = Math.floor(g.y - 4); j <= g.y + 4; j++) for (let i = Math.floor(g.x - 4); i <= g.x + 4; i++) { if (i < 0 || j < 0 || i >= NX || j >= NY) continue; const d = Math.hypot(i + 0.5 - g.x, j + 0.5 - g.y); if (d >= 2.6 && d <= 3.8) cands.push(j * NX + i); } }
    let best = null;
    for (const c of cands) for (let ly = 0; ly < 4; ly++) {
      if (ly & used || ly & ~av) continue;
      const d = D.dist[ly * NC + c];
      if (d < 1e8 && (!best || d < best.d)) best = { layer: ly, cell: c, d };
    }
    return best;
  }
  // enumerate goal sequences from a source (depth-first); returns plan legs
  function enumerate(G, gs, src, av, used, taken, budgetLen, depth, acc, out) {
    const D = dijkstra(G, src.x, src.y, av);
    let any = false;
    // most promising first (near and worth a lot), so the search budget is spent on good orders
    const cs = [];
    for (const g of gs) {
      if (taken.has(g.id)) continue;
      const ap = approach(G, D, g, used, av);
      if (!ap) continue;
      const len = ap.d + (g.pre ? 8 : 0);
      if (len > budgetLen) continue;
      let nv = 0; for (const v of g.val) if (!taken.has(v)) nv++;
      cs.push({ g, ap, len, key: len - 8 * nv });
    }
    cs.sort((a, b) => a.key - b.key);
    for (const { g, ap, len } of cs) {
      any = true;
      const leg = { src, g, ap };
      const t2 = new Set(taken); t2.add(g.id); for (const v of g.val) t2.add(v); if (g.dev) for (const v of g.dev) t2.add(v);
      const nacc = acc.concat([leg]);
      if (g.ends || depth >= 5) out.push(nacc);
      else {
        const nx = g.ex ? { x: g.ex[0] + g.ux * 1.5, y: g.ex[1] + g.uy * 1.5, ux: g.ux, uy: g.uy } : { x: g.x, y: g.y };
        out.push(nacc);
        enumerate(G, gs, nx, av, used | ap.layer, t2, budgetLen - len, depth + 1, nacc, out);
      }
      if (out.length > 400) return;
    }
    if (!any && acc.length) out.push(acc);
  }
  function planValue(plan) { const s = new Set(); for (const leg of plan) for (const v of leg.g.val) s.add(v); return s.size; }
  function planLen(plan) { let l = 0; for (const leg of plan) l += leg.ap.d + (leg.g.pre ? 8 : 0); return l; }

  // polyline helpers
  function simplify(G, pts) {
    if (pts.length < 3) return pts;
    const clear = (a, b) => {
      const n = Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 0.4);
      const la = G.lev[cellOf(a[0], a[1])];
      for (let k = 0; k <= n; k++) {
        const x = a[0] + (b[0] - a[0]) * k / n, y = a[1] + (b[1] - a[1]) * k / n, c = cellOf(x, y);
        if (G.blk[c] || G.hole[c] || G.lev[c] - la > 0.6) return false;
      }
      return true;
    };
    const out = [pts[0]]; let i = 0;
    while (i < pts.length - 1) {
      let j = pts.length - 1;
      while (j > i + 1 && !clear(pts[i], pts[j])) j--;
      out.push(pts[j]); i = j;
    }
    return out;
  }
  // round every corner with a circular arc (radius up to R, limited by the neighbouring segment lengths)
  function chaikin(pts) {
    if (pts.length < 3) return pts;
    const R = 9, out = [pts[0]];
    for (let i = 1; i < pts.length - 1; i++) {
      const A = out[out.length - 1], B = pts[i], C = pts[i + 1];
      const ux = A[0] - B[0], uy = A[1] - B[1], vx = C[0] - B[0], vy = C[1] - B[1];
      const lu = Math.hypot(ux, uy), lv = Math.hypot(vx, vy);
      if (lu < 1e-6 || lv < 1e-6) continue;
      const cosA = (ux * vx + uy * vy) / (lu * lv), ang = Math.acos(clamp(cosA, -1, 1)); // interior angle
      const turn = PI - ang;
      if (turn < 0.05) { out.push(B); continue; }
      const maxT = Math.min(lu * (i === 1 ? 0.85 : 0.5), lv * (i === pts.length - 2 ? 0.55 : 0.5));
      let t = R / Math.tan(ang / 2);
      if (t > maxT) t = maxT;
      const r = t * Math.tan(ang / 2);
      const P1 = [B[0] + ux / lu * t, B[1] + uy / lu * t], P2 = [B[0] + vx / lv * t, B[1] + vy / lv * t];
      // arc centre: along the bisector
      const bx = ux / lu + vx / lv, by = uy / lu + vy / lv, bl = Math.hypot(bx, by) || 1, dc = r / Math.sin(ang / 2);
      const cx = B[0] + bx / bl * dc, cy = B[1] + by / bl * dc;
      let a1 = Math.atan2(P1[1] - cy, P1[0] - cx), a2 = Math.atan2(P2[1] - cy, P2[0] - cx);
      let da = a2 - a1; while (da > PI) da -= TAU; while (da < -PI) da += TAU;
      const n = Math.max(2, Math.ceil(Math.abs(da) * r / 0.6));
      for (let k = 0; k <= n; k++) { const a = a1 + da * k / n; out.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); }
    }
    out.push(pts[pts.length - 1]);
    return out;
  }
  function arc(pts) { const s = [0]; for (let i = 1; i < pts.length; i++) s.push(s[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); return s; }
  function at(pts, S, s) {
    s = clamp(s, 0, S[S.length - 1]);
    let i = 1; while (i < S.length - 1 && S[i] < s) i++;
    const a = pts[i - 1], b = pts[i], l = S[i] - S[i - 1] || 1e-9, t = (s - S[i - 1]) / l;
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
  }
  // build the layout for a plan (+ optional fork)
  function buildLayout(stg, G, plan, opt) {
    const ps = [], spc = opt.sp, nz = opt.noise || 0;
    const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) * 0.8;
    const T = () => checkTerrain(stg, ps);
    let terr = T();
    const have = [0, 0, 0];
    const tryAdd = (p) => {
      if (p.t === 0 && ps.filter((q) => q.t === 0).length >= stg.bud) return false;
      if (!pieceOk(stg, terr, p)) return false;
      for (const q of ps) if (q.t === 0 || q.t === 3) { if (Math.hypot(q.x - p.x, q.y - p.y) < 1.3 && (p.t === 0 || p.t === 3)) return false; }
      ps.push(p); return true;
    };
    // polyline: straight head along the source direction, smoothed middle, straight tail into an approach point
    const poly = (src, cells, pre, goal) => {
      const sx = src.px != null ? src.px : src.x, sy = src.px != null ? src.py : src.y;
      const head = [[sx, sy]];
      if (src.ux != null) head.push([sx + src.ux * 4.4, sy + src.uy * 4.4]);
      // skip path cells that lie around the source (they would make the line double back behind the straight head)
      let k0 = 1;
      if (src.ux != null) while (k0 < cells.length - 1 && Math.hypot(cells[k0][0] - sx, cells[k0][1] - sy) < 5.5) k0++;
      const body = [head[head.length - 1]].concat(cells.slice(k0));
      if (pre) body.push([pre[0], pre[1]]); else body.push(goal);
      const sm = simplify(G, body);
      const all = head.slice(0, -1).concat(sm);
      if (pre) all.push(goal);
      return chaikin(all);
    };
    const legPoints = (leg, nxt) => {
      const D = dijkstra(G, leg.src.x, leg.src.y, opt.av), g = leg.g;
      const cells = pathTo(D, leg.ap.layer, leg.ap.cell);
      if (g.pre) return poly(leg.src, cells, g.pre, [g.x, g.y]);
      if (g.k === 'pin') {
        // pass straight through the pin: come in along the bisector of (from → pin) and (pin → next)
        let ux = g.x - leg.src.x, uy = g.y - leg.src.y, l = Math.hypot(ux, uy) || 1; ux /= l; uy /= l;
        if (nxt) {
          const tx = (nxt.g.pre ? nxt.g.pre[0] : nxt.g.x) - g.x, ty = (nxt.g.pre ? nxt.g.pre[1] : nxt.g.y) - g.y, tl = Math.hypot(tx, ty) || 1;
          const wm = [[1, 1], [1, 0.3], [0.3, 1]][opt.pm || 0];
          let bx = ux * wm[0] + tx / tl * wm[1], by = uy * wm[0] + ty / tl * wm[1], bl = Math.hypot(bx, by);
          if (bl > 0.3) { ux = bx / bl; uy = by / bl; }
        }
        const pre = [g.x - ux * 4.5, g.y - uy * 4.5];
        const pc = cellOf(pre[0], pre[1]);
        if (!G.blk[pc] && !G.hole[pc] && Math.hypot(pre[0] - leg.src.x, pre[1] - leg.src.y) > 3) {
          const D2 = D, ly = [0, 1, 2, 3].filter((k) => !(k & ~opt.av)).sort((a, b) => D2.dist[a * NC + pc] - D2.dist[b * NC + pc])[0];
          if (D2.dist[ly * NC + pc] < 1e8) { const c2 = pathTo(D2, ly, pc); const pts = poly(leg.src, c2, pre, [g.x, g.y]); pts.dir = [ux, uy]; return pts; }
        }
        cells.pop(); return poly(leg.src, cells, null, [g.x, g.y]);
      }
      return poly(leg.src, cells, null, [g.x, g.y]);
    };
    const placeAlong = (pts, ga, gb) => {
      const S = arc(pts), Lt = S[S.length - 1];
      // specials first: bridge over holes, stairs at platform edges
      let inH = -1;
      for (let s = 0; s <= Lt; s += 0.25) {
        const p = at(pts, S, s), h = stg.gaps.some((g) => inR(p[0], p[1], g));
        if (h && inH < 0) inH = s;
        if (!h && inH >= 0) {
          if (stg.sp[0] > have[0]) { const a = at(pts, S, inH - 0.5), b = at(pts, S, s + 0.5), m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; if (tryAdd({ t: 1, x: q4(m[0]), y: q4(m[1]), a: angIdx(b[0] - a[0], b[1] - a[1]) })) { have[0]++; terr = T(); } }
          inH = -1;
        }
      }
      for (let s = 0.25; s <= Lt; s += 0.25) {
        const a = at(pts, S, s - 0.25), b = at(pts, S, s);
        if (G.T.level(b[0], b[1]) - G.T.level(a[0], a[1]) > 0.6 && stg.sp[1] > have[1]) {
          const c = at(pts, S, s - 0.6), d = at(pts, S, s + 0.6);
          if (tryAdd({ t: 2, x: q4(b[0]), y: q4(b[1]), a: angIdx(d[0] - c[0], d[1] - c[1]) })) { have[1]++; terr = T(); }
        }
      }
      const Uu = Lt - ga - gb;
      if (Uu < -0.5) return;
      const m = Math.max(1, Math.round(Uu / spc) + 1), step = m > 1 ? Uu / (m - 1) : 0;
      const ss = [], pp = [];
      for (let k = 0; k < m; k++) { const s = ga + (m > 1 ? k * step : Math.max(0, Uu) / 2) + gauss() * nz; ss.push(s); pp.push(at(pts, S, s)); }
      for (let k = 0; k < m; k++) {
        const s = ss[k], p = pp[k];
        // face the bisector of (previous → this) and (this → next) so every domino turns the line by the same amount
        const pv = k > 0 ? pp[k - 1] : at(pts, S, s - spc), nx = k < m - 1 ? pp[k + 1] : at(pts, S, s + spc);
        let ux = p[0] - pv[0], uy = p[1] - pv[1], vx = nx[0] - p[0], vy = nx[1] - p[1];
        const lu = Math.hypot(ux, uy), lv = Math.hypot(vx, vy);
        let dx, dy;
        if (lu > 0.3 && lv > 0.3) { dx = ux / lu + vx / lv; dy = uy / lu + vy / lv; }
        else { const a0 = at(pts, S, s - 0.9), a1 = at(pts, S, s + 0.9); dx = a1[0] - a0[0]; dy = a1[1] - a0[1]; }
        let ai = angIdx(dx, dy);
        if (nz) ai = (ai + Math.round(gauss() * nz * 3) + 64) % 64;
        const lat = gauss() * nz * 0.5, c = CS[ai];
        const px = p[0] - c[1] * lat, py = p[1] + c[0] * lat;
        if (!tryAdd({ t: 0, x: q4(px), y: q4(py), a: ai })) {
          for (const off of [0.4, -0.4, 0.8]) { const p2 = at(pts, S, s + off); if (tryAdd({ t: 0, x: q4(p2[0]), y: q4(p2[1]), a: ai })) break; }
        }
      }
    };
    const runLegs = (legs, firstGap, src0) => {
      let ga = firstGap, carry = src0 || null;
      for (let li = 0; li < legs.length; li++) {
        const leg = legs[li];
        const lg = carry && leg.src.ux == null ? { src: carry, g: leg.g, ap: leg.ap } : leg;
        const pts = legPoints(lg, legs[li + 1]);
        placeAlong(pts, ga, leg.g.gb);
        ga = leg.g.ga || 0;
        const S = arc(pts), Lt = S[S.length - 1], a = at(pts, S, Lt - 1.5), b = pts[pts.length - 1], l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
        carry = leg.g.k === 'pin' ? { x: leg.g.x, y: leg.g.y, ux: (b[0] - a[0]) / l, uy: (b[1] - a[1]) / l } : null;
      }
    };
    if (opt.fork) {
      const f = opt.fork;
      // trunk: start → fork point
      const D = dijkstra(G, stg.st.x, stg.st.y, opt.av);
      const fd = CS[f.a], pts = poly({ x: stg.st.x, y: stg.st.y, ux: CS[stg.st.a][0], uy: CS[stg.st.a][1] }, pathTo(D, f.layer, f.cell), [f.x - fd[0] * 4, f.y - fd[1] * 4], [f.x, f.y]);
      placeAlong(pts, spc, spc);
      tryAdd({ t: 3, x: q4(f.x), y: q4(f.y), a: f.a });
      runLegs(f.b1, 2.8); runLegs(f.b2, 2.8);
    } else runLegs(plan, spc);
    return ps;
  }
  function checkTerrain(stg, ps) {
    const brs = ps.filter((p) => p.t === 1).map((p) => oRect(p.x, p.y, p.a, BRL, BRW));
    const sts = ps.filter((p) => p.t === 2).map((p) => oRect(p.x, p.y, p.a, STL, STW));
    return new Terrain(stg, brs, sts);
  }
  function aiPlans(stg, G, av) {
    const gs = goalsOf(stg, G), out = [];
    const maxLen = stg.bud * SP * 1.15;
    enumerate(G, gs, { x: stg.st.x, y: stg.st.y, ux: CS[stg.st.a][0], uy: CS[stg.st.a][1] }, av, 0, new Set(), maxLen, 0, [], out);
    const scored = out.map((p) => ({ p, v: planValue(p), l: planLen(p) }));
    scored.sort((a, b) => b.v - a.v || a.l - b.l);
    return diverse(scored, (x) => valKey(x.p));
  }
  function forkPlans(stg, G, av) {
    if (!stg.sp[2]) return [];
    const gs = goalsOf(stg, G), out = [];
    const src = { x: stg.st.x, y: stg.st.y };
    const D = dijkstra(G, src.x, src.y, av);
    let cx = 0, cy = 0; for (const g of gs) { cx += g.x; cy += g.y; } cx /= gs.length; cy /= gs.length;
    // fork candidates: points along the way from the start towards the centre of the goals
    let tc = cellOf(cx, cy), tl = 0;
    let bestD = 1e9; for (let ly = 0; ly < 4; ly++) if (!(ly & ~av) && D.dist[ly * NC + tc] < bestD) { bestD = D.dist[ly * NC + tc]; tl = ly; }
    if (bestD > 1e8) { // nearest reachable cell
      let bd = 1e9; for (let c = 0; c < NC; c++) { const d = D.dist[c]; if (d < 1e8) { const e = Math.hypot(c % NX + 0.5 - cx, (c / NX | 0) + 0.5 - cy) + d * 0.1; if (e < bd) { bd = e; tc = c; tl = 0; } } }
    }
    const path = pathTo(D, tl, tc), sm = chaikin(simplify(G, [[src.x, src.y]].concat(path.slice(1)))), S = arc(sm);
    const maxLen = stg.bud * SP * 1.15;
    for (const fs of [6, 10, 15, 21]) {
      if (fs > S[S.length - 1] - 1) continue;
      const p = at(sm, S, fs), a0 = at(sm, S, fs - 1.5), a1 = at(sm, S, fs + 1.5);
      const ai = angIdx(a1[0] - a0[0], a1[1] - a0[1]), d = CS[ai];
      const fc = cellOf(p[0], p[1]); let fl = -1;
      for (let ly = 0; ly < 4; ly++) if (!(ly & ~av) && D.dist[ly * NC + fc] < 1e8) { fl = ly; break; }
      if (fl < 0 || G.blk[fc] || G.hole[fc]) continue;
      const arms = [[d[0] * C30 - d[1] * S30, d[0] * S30 + d[1] * C30], [d[0] * C30 + d[1] * S30, -d[0] * S30 + d[1] * C30]];
      const srcs = arms.map((u) => ({ x: p[0] + u[0] * 4.2, y: p[1] + u[1] * 4.2, ux: u[0], uy: u[1], px: p[0] + d[0] * FKN, py: p[1] + d[1] * FKN }));
      if (srcs.some((s) => G.blk[cellOf(s.x, s.y)])) continue;
      // each arm only goes for the goals on its own side of the fork
      const side = (g) => d[0] * (g.y - p[1]) - d[1] * (g.x - p[0]) > 0;
      const other1 = new Set(), other2 = new Set();
      for (const g of gs) (side(g) ? other2 : other1).add(g.id);
      const b1 = []; enumerate(G, gs, srcs[0], av, fl, other1, maxLen - fs, 0, [], b1);
      const used1 = (pl) => pl.reduce((m, l) => m | l.ap.layer, fl);
      const top1 = b1.map((pl) => ({ pl, v: planValue(pl), l: planLen(pl) })).sort((a, b) => b.v - a.v || a.l - b.l).slice(0, 6);
      for (const c1 of top1) {
        const taken = new Set(other2); for (const leg of c1.pl) { taken.add(leg.g.id); for (const v of leg.g.val) taken.add(v); if (leg.g.dev) for (const v of leg.g.dev) taken.add(v); }
        const b2 = []; enumerate(G, gs, srcs[1], av, used1(c1.pl), taken, maxLen - fs - c1.l, 0, [], b2);
        b2.push([]);
        for (const pl2 of b2) {
          const s = new Set(); for (const pl of [c1.pl, pl2]) for (const leg of pl) for (const v of leg.g.val) s.add(v);
          out.push({ fork: { x: p[0], y: p[1], a: ai, cell: fc, layer: fl, b1: c1.pl, b2: pl2 }, v: s.size, l: fs + c1.l + planLen(pl2) });
        }
      }
    }
    out.sort((a, b) => b.v - a.v || a.l - b.l);
    return diverse(out, (x) => valKey(x.fork.b1.concat(x.fork.b2)));
  }
  // what a plan aims at (its set of targets + gadgets), to keep the candidate list varied
  function valKey(plan) { const s = new Set(); for (const leg of plan) { s.add(leg.g.id); for (const v of leg.g.val) s.add(v); } return Array.from(s).sort().join(','); }
  // at most two plans (the shortest) per target set
  function diverse(list, key) { const seen = {}; return list.filter((x) => { const k = key(x); seen[k] = (seen[k] || 0) + 1; return seen[k] <= 2; }); }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const stg = curStage(s), G = grid(stg);
    const av = (stg.sp[0] ? 1 : 0) | (stg.sp[1] ? 2 : 0);
    const t0 = Date.now();
    const isGad = (leg) => leg.g.k === 'ball' || leg.g.k === 'saw' || leg.g.k === 'fx';
    const gk = (plan) => (plan.some(isGad) ? 1 : 0);
    const all = aiPlans(stg, G, av);
    const cands = all.slice(0, 12).map((x) => ({ plan: x.p, v: x.v, l: x.l, k: x.v + gk(x.p) }));
    // make sure every gadget (ball, seesaw, black line) gets tried with its best plan
    const gad = {};
    for (const x of all) for (const leg of x.p) if (isGad(leg)) {
      const o = gad[leg.g.id] || (gad[leg.g.id] = { top: x, short: x });
      if (x.l < o.short.l) o.short = x;
    }
    const inC = new Set(cands.map((c) => c.plan));
    for (const id in gad) for (const x of [gad[id].top, gad[id].short]) if (!inC.has(x.p)) { inC.add(x.p); cands.push({ plan: x.p, v: x.v, l: x.l, k: x.v + 1 }); }
    for (const f of forkPlans(stg, G, av).slice(0, 10)) cands.push({ plan: null, fork: f.fork, v: f.v, l: f.l, k: f.v + gk(f.fork.b1.concat(f.fork.b2)) });
    cands.sort((a, b) => b.k - a.k || a.l - b.l);
    const noise = lv === 1 ? 0.55 : lv === 2 ? 0.18 : 0;
    let pool;
    if (lv === 1) { const k = Math.min(cands.length, 6); pool = k ? [cands[Math.floor(Math.random() * k)]] : []; }
    else if (lv === 2) pool = cands.slice(0, 6);
    else pool = cands.slice(0, 30);
    const vars = lv === 3 ? [[2.8, 0], [2.8, 1], [2.8, 2], [3.1, 0], [2.6, 1], [3.1, 2]] : lv === 2 ? [[2.8, 0], [2.9, 1]] : [[SP + (Math.random() - 0.5) * 1.2, Math.floor(Math.random() * 3)]];
    let best = null, n = 0;
    outer: for (const vv of vars) for (const c of pool) {
      if (best && Date.now() - t0 > (lv === 3 ? 260 : 120)) break outer;
      let ps;
      try { ps = buildLayout(stg, G, c.plan, { sp: vv[0], pm: vv[1], noise, av, fork: c.fork }); checkLayout(stg, ps); } catch (e) { continue; }
      n++;
      const r = lv === 1 ? { sc: 0 } : simLayout(stg, ps);
      if (!best || r.sc > best.sc) best = { sc: r.sc, ps };
    }
    return { k: 's', d: encL(best ? best.ps : []) };
  }
  function aiDelayFor(s, seat, lv) { return [3400, 2600, 1800][clamp((lv || 2) - 1, 0, 2)]; }

  /* ================= view ================= */
  const KZ = 0.42;           // oblique projection: screen y = y − z·KZ

  L.register({
    id: 'domino', name: '도미노 쓰러뜨리기', tag: '연쇄 퍼즐', cat: '스포츠',
    blurb: '같은 개수의 도미노로 길을 만들어 핀과 종을 쓰러뜨려요. 모두 동시에 배치하고, 연쇄 반응으로 점수를 겨룹니다.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 2600,
    tint: '#2d4a5e',
    icon: '<rect x="8" y="20" width="6" height="24" rx="1.5" fill="currentColor"/><rect x="18" y="20" width="6" height="24" rx="1.5" fill="currentColor" transform="rotate(14 21 44)"/><rect x="28" y="20" width="6" height="24" rx="1.5" fill="currentColor" transform="rotate(34 31 44)"/><rect x="38" y="24" width="6" height="24" rx="1.5" fill="currentColor" transform="rotate(62 41 48)"/><circle cx="11" cy="27" r="1.4" fill="#000" opacity=".35"/><circle cx="11" cy="37" r="1.4" fill="#000" opacity=".35"/><path d="M46 14c0-3 2-5 4-5s4 2 4 5v3h-8z" fill="currentColor"/><circle cx="50" cy="19" r="1.4" fill="currentColor"/>',
    options: [
      { id: 'stg', label: '스테이지', choices: [{ v: 3, label: '3스테이지' }, { v: 5, label: '5스테이지' }], def: 5 },
      { id: 'map', label: '맵', choices: [{ v: 'r', label: '무작위' }, { v: 'b', label: '기본 코스' }].concat(STAGES.map((S, i) => ({ v: i, label: S.nm }))), def: 'r' },
    ],
    quick: [
      '금색 시작 도미노에서 과녁(핀·종)까지 도미노 길을 만들어 많이 쓰러뜨리면 이겨요.',
      '내 차례(모두 동시에): ✏ 그리기로 길을 긋고 → 「쓰러뜨리기」를 두 번 눌러 제출해요.',
      '점수 = 과녁 1개 10점 + 넘어진 내 도미노 1개 1점 + 남긴 도미노 1개 1점. 스테이지 총점 1등이 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '바닥을 위에서 내려다본 화면이에요. 금색 도미노가 출발점, 핀·종이 과녁이에요.',
        '정해진 개수의 도미노로 출발점부터 과녁까지 길을 만들어요. 과녁을 많이 쓰러뜨릴수록 좋아요.',
        '스테이지를 여러 개(기본 5개) 하고, 총점이 가장 높은 사람이 이겨요.'] },
      { h: '준비', p: [
        '스테이지마다 모두 같은 맵, 같은 개수의 도미노를 받아요. 위쪽에 「남은 도미노」가 보여요.',
        '어떤 맵은 다리 · 계단 · 갈림길 같은 특수 조각도 몇 개 받아요.'] },
      { h: '차례에 할 일', p: [
        '모두 동시에, 서로 안 보고 배치해요(한 폰에 여럿이면 가림막으로 한 명씩).',
        '① ✏ 그리기: 금색 시작 도미노 근처에서 과녁 쪽으로 손가락을 그어요. 알맞은 간격으로 도미노가 놓여요.',
        '② 이어 그리려면 마지막 도미노 근처에서 다시 그어요. 도미노 사이 선이 초록이면 좋은 간격이에요.',
        '③ 고치기: ✋ 고르기로 도미노를 눌러 끌어 옮기고, ⟲ ⟳로 돌리고, 「빼기」로 빼요. ↶는 되돌리기.',
        '④ 다 됐으면 「쓰러뜨리기」 → 「한 번 더!」를 눌러 제출해요.',
        '⑤ 모두 제출하면 한 사람씩 차례로 쓰러뜨려 보고 점수를 매겨요. 「빨리 ▶▶」 「건너뛰기」로 빨리 볼 수 있어요.'] },
      { h: '점수·승리', p: [
        '쓰러뜨린 과녁(핀·종) 1개 = 10점.',
        '넘어진 내 도미노(연쇄 길이) 1개 = 1점.',
        '쓰지 않고 남긴 도미노 1개 = 1점. 그러니 너무 많이 놓지 않는 것도 작전이에요.',
        '모든 스테이지 점수를 더해 가장 높은 사람이 이겨요(같으면 공동 승리). 혼자 하면 총점 도전이에요.'] },
      { h: '물리 (이렇게 쓰러져요)', p: [
        '도미노는 바로 앞 도미노를 쳐서 넘어뜨려요. 좋은 간격은 도미노 높이의 절반쯤이에요.',
        '너무 좁으면 힘이 약하고, 너무 넓으면 닿지 않아 멈춰요.',
        '방향을 너무 급하게 꺾으면 힘이 빠져서 멈춰요. 완만하게 휘어 주세요.',
        '벽에 막혀요. 낮은 바닥에서 높은 단으로는 그냥 못 올라가요(계단이 필요해요).',
        '핀은 넘어지면서 앞의 도미노를 다시 칠 수 있어요. 종은 울리면 과녁이지만 연쇄는 거기서 멈춰요.'] },
      { h: '특수 조각 · 장치', p: [
        '다리: 구멍 위에 놓으면 그 위에 도미노를 세울 수 있어요.',
        '계단: 높은 단 가장자리에 놓으면 연쇄가 단 위로 올라가요.',
        '갈림길: 넘어지면 양쪽 30° 두 갈래로 동시에 밀어요. 과녁이 두 군데일 때 좋아요.',
        '특수 조각 버튼을 누르고 바닥을 누르면 놓여요. 버튼 숫자가 남은 개수예요.',
        '공: 맞은 방향으로 굴러 핀을 쓰러뜨려요. 경사로에서는 빨라지고, 공끼리 부딪히면 힘이 옮겨 가요.',
        '시소: 한쪽 끝을 치면 반대쪽이 튀어 올라 앞을 쳐요. 나무 기둥: 도미노를 막고 공을 튕겨 내요.',
        '검은 도미노: 맵에 미리 놓인 장치예요. 금색 화살표 쪽으로 밀면 혼자 이어서 넘어가요. 큰 검은 도미노는 멀리까지 닿아요(내 도미노로 세지 않아요).'] },
      { h: '맵', p: [
        '맵은 ' + STAGES.length + '가지예요. 기본 「무작위」는 쉬운 맵부터 어려운 맵까지 단계마다 하나씩 골라요(3·5스테이지).',
        '「기본 코스」는 처음 5개 맵 그대로예요. 맵 이름을 고르면 그 맵 한 스테이지만 해요(연습용).'] },
      { h: '조작', p: [
        '✏ 그리기: 길 긋기. ✋ 고르기: 눌러 고르기 · 끌어 옮기기.',
        '⟲ ⟳ 고른 조각 돌리기 · 「빼기」 고른 조각 빼기(아무것도 안 골랐으면 「비우기」 = 전부 치우기) · ↶ 되돌리기.',
        '「쓰러뜨리기」를 두 번 누르면 제출. 버튼 위 안내 줄이 지금 할 일을 알려 줘요.'] },
      { h: '예시', p: [
        '도미노 30개, 핀 3개인 맵: 시작 도미노에서 핀 쪽으로 완만한 곡선을 그어 도미노 24개를 놓았어요.',
        '쓰러뜨려 보니 핀 3개 모두 넘어감(30점) + 넘어진 도미노 24개(24점) + 남긴 도미노 6개(6점) = 60점!',
        '중간에 급하게 꺾었다면 거기서 멈춰 과녁 0개 → 넘어진 도미노 수 + 남긴 도미노 수만 받아요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 과녁 순서와 길을 더 많이 찾아보고 간격이 정확해요.'] },
    ],
    tutorial: [
      { text: '위에서 내려다본 바닥이에요. 금색 도미노가 출발점, 핀·종이 과녁이에요. 도미노 길로 과녁을 쓰러뜨려요!' },
      { sel: '.dm-left', text: '이번 스테이지에 쓸 수 있는 도미노 개수예요. 안 쓰고 남긴 도미노도 1개에 1점이에요.' },
      { sel: '.dm-t-draw', text: '✏ 그리기: 금색 시작 도미노 근처에서 과녁 쪽으로 손가락을 그어요. 알맞은 간격으로 도미노가 놓여요. 사이 선이 초록이면 좋은 간격!' },
      { sel: '.dm-t-sel', text: '✋ 고르기: 도미노를 눌러 고른 뒤 끌어서 옮겨요. 급하게 꺾인 곳은 완만하게 고쳐 주세요(급커브에선 멈춰요).' },
      { sel: '.dm-edit', text: '↶ 되돌리기 · ⟲ ⟳ 돌리기 · 빼기. 다 됐으면 「쓰러뜨리기」를 두 번 눌러 제출해요.' },
      { text: '모두 제출하면 한 사람씩 쓰러뜨려 봐요. 과녁 1개 10점 + 넘어진 내 도미노 1개 1점 + 남긴 도미노 1개 1점. 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _sim: { World, stageOf, STAGES, pickStages, devSim, goalsOf, encL, decL, checkLayout, simLayout, scoreOf, buildLayout, aiPlans, forkPlans, grid, pieceOk, dsin, CS },
  });

  /* ---------- view ---------- */
  const PIPS = [[], [[0, 0]], [[-1, -1], [1, 1]], [[-1, -1], [0, 0], [1, 1]], [[-1, -1], [1, -1], [-1, 1], [1, 1]], [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]]];
  const LIGHT = (() => { const v = [-0.45, -0.55, 1], l = Math.hypot(v[0], v[1], v[2]); return v.map((x) => x / l); })();
  function shade(hex, k) {
    const n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    const f = (c) => Math.round(clamp(c * k, 0, 255));
    return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')';
  }
  function mix(a, b, t) {
    const A = parseInt(a.slice(1), 16), B = parseInt(b.slice(1), 16);
    const c = (sh) => Math.round(((A >> sh) & 255) * (1 - t) + ((B >> sh) & 255) * t);
    return '#' + ((1 << 24) | (c(16) << 16) | (c(8) << 8) | c(0)).toString(16).slice(1);
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const topEl = L.h('div', { class: 'hud top', style: { padding: '6px 8px 0', justifyContent: 'space-between', flexWrap: 'nowrap', gap: '6px' } });
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px 8px', flexDirection: 'column', alignItems: 'stretch', gap: '6px' } });
    root.append(topEl, bot);
    const color = (i) => (api.players[i] ? api.players[i].color : '#ccc');
    const nameOf = (i) => (api.players[i] ? api.players[i].name : '');
    let st = null, stg = null, alive = true, dirty = true, sentAt = 0;
    const drafts = {};          // seat -> {ps, undo, tool, sel}
    let cur = -1;               // local seat building on this screen
    let shown = -1;             // seat whose curtain was lifted (several humans on one phone)
    let curtainEl = null, sumEl = null;
    let rep = null;             // replay {last, order, k, w, stg, ps, t, hold, fast, done}
    let confirmUntil = 0, stroke = null, drag = null, ptr = null;
    const cam = { cx: FW / 2, cy: FH / 2, z: 1, tz: 1, tcx: FW / 2, tcy: FH / 2 };
    let V = null; // view transform {s, ox, oy}
    const sndT = {};

    /* ---- transforms ---- */
    function area() {
      const tb = topEl.getBoundingClientRect(), bb = bot.getBoundingClientRect(), rr = cv.cv.getBoundingClientRect();
      const top = Math.max(0, (tb.bottom || 0) - rr.top) + 8, b = Math.min(cv.h, (bb.top || cv.h) - rr.top) - 8;
      return { top, bot: Math.max(top + 140, b) };
    }
    function setView() {
      const ar = area(), h = ar.bot - ar.top, w = cv.w - 16;
      const s0 = Math.min(w / (FW + 1.6), h / (FH + 2.2));
      const s = s0 * cam.z;
      // keep the field in view when zoomed
      const hw = w / 2 / s, hh = h / 2 / s;
      const cx = cam.z <= 1.001 ? FW / 2 : clamp(cam.cx, Math.min(FW / 2, hw - 0.8), Math.max(FW / 2, FW + 0.8 - hw));
      const cy = cam.z <= 1.001 ? FH / 2 - 0.6 : clamp(cam.cy, Math.min(FH / 2, hh - 1.4), Math.max(FH / 2, FH + 0.8 - hh));
      V = { s, ox: cv.w / 2 - cx * s, oy: ar.top + h / 2 - cy * s, ar };
    }
    const SX = (x) => V.ox + x * V.s, SY = (y, z) => V.oy + (y - (z || 0) * KZ) * V.s;
    const toField = (p) => ({ x: (p.x - V.ox) / V.s, y: (p.y - V.oy) / V.s });

    /* ---- terrain heights for drawing ---- */
    function zAt(T, x, y) {
      for (const r of T.sz) {
        if (!inO(x, y, r)) continue;
        const u = (x - r.cx) * r.nx + (y - r.cy) * r.ny;
        const z1 = stg.plat.some((p) => inR(r.cx + r.nx * r.hn, r.cy + r.ny * r.hn, p)) ? 1.5 : 0;
        const z0 = stg.plat.some((p) => inR(r.cx - r.nx * r.hn, r.cy - r.ny * r.hn, p)) ? 1.5 : 0;
        return z0 + (z1 - z0) * (u + r.hn) / (2 * r.hn);
      }
      return stg.plat.some((p) => inR(x, y, p)) ? 1.5 : 0;
    }

    /* ---- drawing primitives ---- */
    function poly(pts, fill, stroke, lw) {
      ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath();
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
    }
    // a box hinged at its front-bottom edge o, falling along d by th
    function drawBox(o, d, hn2, ht, H, th, base, zb, o2) {
      const tx = -d[1], ty = d[0], c = dcos(th), sn = dsin(th);
      const P = (u, v, z) => { const u2 = u * c + z * sn, z2 = -u * sn + z * c; const x = o[0] + d[0] * u2 + tx * v, y = o[1] + d[1] * u2 + ty * v; return [SX(x), SY(y, z2 + zb)]; };
      const U0 = -hn2, U1 = 0, V0 = -ht, V1 = ht, Z0 = 0, Z1 = H;
      const faces = [
        { p: [[U0, V0, Z0], [U0, V1, Z0], [U0, V1, Z1], [U0, V0, Z1]], n: [-1, 0, 0], k: 'b' },
        { p: [[U1, V0, Z0], [U1, V0, Z1], [U1, V1, Z1], [U1, V1, Z0]], n: [1, 0, 0], k: 'b' },
        { p: [[U0, V0, Z0], [U0, V0, Z1], [U1, V0, Z1], [U1, V0, Z0]], n: [0, -1, 0], k: 's' },
        { p: [[U0, V1, Z0], [U1, V1, Z0], [U1, V1, Z1], [U0, V1, Z1]], n: [0, 1, 0], k: 's' },
        { p: [[U0, V0, Z1], [U0, V1, Z1], [U1, V1, Z1], [U1, V0, Z1]], n: [0, 0, 1], k: 't' },
      ];
      let pipFace = null, pa = 0;
      for (const f of faces) {
        const nu = f.n[0] * c + f.n[2] * sn, nz = -f.n[0] * sn + f.n[2] * c, nv = f.n[1];
        const wx = d[0] * nu + tx * nv, wy = d[1] * nu + ty * nv, wz = nz;
        if (wy * KZ + wz <= 1e-4) continue;
        const li = 0.62 + 0.38 * Math.max(0, wx * LIGHT[0] + wy * LIGHT[1] + wz * LIGHT[2]);
        const pts = f.p.map((q) => P(q[0], q[1], q[2]));
        poly(pts, shade(base, li * (f.k === 't' ? 0.97 : f.k === 's' ? 0.9 : 1)), 'rgba(40,24,10,.45)', 0.6);
        if (f.k === 'b') { const ar = Math.abs((pts[2][0] - pts[0][0]) * (pts[3][1] - pts[1][1]) - (pts[3][0] - pts[1][0]) * (pts[2][1] - pts[0][1])); if (ar > pa) { pa = ar; pipFace = pts; } }
      }
      if (o2 && pipFace && pa > 30) {
        // divider line + pips on the broad face
        const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
        const q = pipFace; // corners: (V0,Z0),(V1,Z0),(V1,Z1),(V0,Z1) in some order
        const at2 = (v, z) => lerp(lerp(q[0], q[1], v), lerp(q[3], q[2], v), z);
        ctx.strokeStyle = o2.line || 'rgba(60,40,20,.55)'; ctx.lineWidth = Math.max(0.8, V.s * 0.12);
        const m0 = at2(0.08, 0.5), m1 = at2(0.92, 0.5); ctx.beginPath(); ctx.moveTo(m0[0], m0[1]); ctx.lineTo(m1[0], m1[1]); ctx.stroke();
        if (pa > 140) {
          ctx.fillStyle = o2.pip || 'rgba(40,28,16,.75)';
          const r = Math.max(0.7, V.s * 0.13 * (o2.ps || 1));
          for (const [half, n] of [[0.25, o2.p1], [0.75, o2.p2]]) for (const pp of PIPS[n]) { const c2 = at2(0.5 + pp[0] * 0.25, half + pp[1] * 0.13); ctx.beginPath(); ctx.arc(c2[0], c2[1], r, 0, 7); ctx.fill(); }
        }
      }
    }
    function shadowRect(cx, cy, nx, ny, hn, ht, zb, a) {
      const tx = -ny, ty = nx, pts = [];
      for (const [u, v] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) pts.push([SX(cx + nx * hn * u + tx * ht * v + 0.25), SY(cy + ny * hn * u + ty * ht * v + 0.35, zb)]);
      poly(pts, 'rgba(0,0,0,' + (a || 0.28) + ')');
    }
    function drawDomPiece(P, i, w, own, zb) {
      const b = P.b >= 0 && w ? w.bodies[P.b] : null;
      let base = P.k === 's' ? '#e3ae45' : P.k === 'f' ? '#c98a4b' : P.k === 'x' ? '#3a3340' : '#efe5cf';
      if (own != null && P.k === 'd') base = mix('#efe5cf', color(own), 0.16);
      let o, d, th = 0;
      if (b && b.st !== 3) { o = b.o; d = b.d; th = b.th; } else { o = [P.x + P.nx * P.hn, P.y + P.ny * P.hn]; d = [P.nx, P.ny]; }
      if (th < 0.05) shadowRect(P.x, P.y, P.nx, P.ny, P.hn, P.ht, zb);
      const H = P.k === 'f' ? 3.0 : P.H;
      drawBox(o, d, 2 * P.hn, P.ht, H, th, base, zb, P.k === 'f' ? null : P.k === 'x' ? { p1: (i * 5 + 1) % 7, p2: (i * 3 + 2) % 7, line: 'rgba(227,174,69,.75)', pip: '#f2e9d8', ps: P.s } : { p1: (i * 5 + 1) % 7, p2: (i * 3 + 2) % 7, line: own != null && P.k === 'd' ? color(own) : null });
      if (P.k === 'f' && th < 0.6) {
        // Y mark on the top
        const c = [P.x, P.y], z = zb + H + 0.02, d0 = [P.nx, P.ny], a1 = [d0[0] * C30 - d0[1] * S30, d0[0] * S30 + d0[1] * C30], a2 = [d0[0] * C30 + d0[1] * S30, -d0[0] * S30 + d0[1] * C30];
        ctx.strokeStyle = '#3a2210'; ctx.lineWidth = Math.max(1, V.s * 0.16); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(SX(c[0] - d0[0] * 0.4), SY(c[1] - d0[1] * 0.4, z)); ctx.lineTo(SX(c[0]), SY(c[1], z));
        ctx.lineTo(SX(c[0] + a1[0] * 0.5 * 0 + (-a1[1]) * 0 + a1[0] * 0.6), SY(c[1] + a1[1] * 0.6, z)); ctx.moveTo(SX(c[0]), SY(c[1], z)); ctx.lineTo(SX(c[0] + a2[0] * 0.6), SY(c[1] + a2[1] * 0.6, z)); ctx.stroke();
      }
    }
    function drawPin(P, w, zb) {
      const b = P.b >= 0 && w ? w.bodies[P.b] : null;
      let d = [0, 1], th = 0, o = [P.x, P.y];
      if (b && b.st !== 3) { d = b.d; th = b.th; o = [P.x, P.y]; }
      const sn = dsin(th), c = dcos(th);
      const top = [o[0] + d[0] * PH * sn, o[1] + d[1] * PH * sn, zb + PH * c];
      const r = PR * V.s;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(SX(P.x + 0.2), SY(P.y + 0.3, zb), r * 1.3, r * 0.9, 0, 0, 7); ctx.fill();
      const x0 = SX(o[0]), y0 = SY(o[1], zb), x1 = SX(top[0]), y1 = SY(top[1], top[2]);
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#d9d2c6'; ctx.lineWidth = r * 2.3; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      ctx.strokeStyle = '#fbf7ee'; ctx.lineWidth = r * 1.5; ctx.beginPath(); ctx.moveTo(x0 - r * 0.25, y0); ctx.lineTo(x1 - r * 0.25, y1); ctx.stroke();
      const bx = x0 + (x1 - x0) * 0.72, by = y0 + (y1 - y0) * 0.72, bx2 = x0 + (x1 - x0) * 0.8, by2 = y0 + (y1 - y0) * 0.8;
      ctx.strokeStyle = '#d8453a'; ctx.lineWidth = r * 2.35; ctx.lineCap = 'butt'; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx2, by2); ctx.stroke();
      ctx.fillStyle = '#fffaf0'; ctx.beginPath(); ctx.arc(x1, y1, r * 1.05, 0, 7); ctx.fill();
      ctx.lineCap = 'butt';
    }
    function drawBell(B, w, now, zb) {
      const hit = w && B.hit, age = hit ? w.t - B.tt : 99;
      const wob = age < 1.6 ? Math.sin(age * 22) * 0.25 * (1 - age / 1.6) : 0;
      const x = SX(B.x), y = SY(B.y, zb), s = V.s;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(x + s * 0.3, y + s * 0.3, BELR * s * 1.05, BELR * s * 0.75, 0, 0, 7); ctx.fill();
      // stand
      ctx.fillStyle = '#5a3a1e'; ctx.beginPath(); ctx.ellipse(x, y, BELR * s * 0.95, BELR * s * 0.62, 0, 0, 7); ctx.fill();
      ctx.save(); ctx.translate(x, y - 0.4 * s); ctx.rotate(wob);
      const hgt = 3.2 * KZ * s + BELR * s * 0.5;
      const g = ctx.createLinearGradient(-BELR * s, 0, BELR * s, 0);
      g.addColorStop(0, '#8a5d12'); g.addColorStop(0.35, hit ? '#ffe28a' : '#f0c45a'); g.addColorStop(1, '#9a6a18');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(-BELR * s, 0); ctx.quadraticCurveTo(-BELR * s * 0.75, -hgt * 0.45, -BELR * s * 0.5, -hgt * 0.8);
      ctx.quadraticCurveTo(0, -hgt * 1.12, BELR * s * 0.5, -hgt * 0.8); ctx.quadraticCurveTo(BELR * s * 0.75, -hgt * 0.45, BELR * s, 0);
      ctx.ellipse(0, 0, BELR * s, BELR * s * 0.35, 0, 0, Math.PI); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#5c3c0a'; ctx.beginPath(); ctx.ellipse(0, 0, BELR * s * 0.92, BELR * s * 0.28, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#e8b847'; ctx.beginPath(); ctx.arc(0, -hgt * 1.0, s * 0.3, 0, 7); ctx.fill();
      ctx.restore();
      if (hit && age < 1.4) {
        for (let k = 0; k < 2; k++) { const a = age * 1.6 - k * 0.35; if (a < 0 || a > 1) continue; ctx.strokeStyle = 'rgba(255,226,138,' + (1 - a) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y - hgt * 0.5, (BELR + a * 3.5) * s, 0, 7); ctx.stroke(); }
      }
    }
    function drawBall(Bx, By, rot, hx, hy, zb, gone) {
      if (gone) return;
      const x = SX(Bx), y = SY(By, zb + BR), r = BR * V.s;
      ctx.fillStyle = 'rgba(0,0,0,.32)'; ctx.beginPath(); ctx.ellipse(SX(Bx + 0.3), SY(By + 0.4, zb), r * 1.05, r * 0.8, 0, 0, 7); ctx.fill();
      const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
      g.addColorStop(0, '#ff9a7e'); g.addColorStop(0.5, '#d2402e'); g.addColorStop(1, '#6e160e');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      // a stripe that rolls
      ctx.save(); ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.clip();
      const ph = Math.sin(rot), off = ph * r * 0.8;
      ctx.strokeStyle = 'rgba(255,235,210,.75)'; ctx.lineWidth = r * 0.28;
      ctx.beginPath(); ctx.moveTo(x - hy * r * 1.2 + hx * off, y + hx * r * 1.2 + hy * off); ctx.lineTo(x + hy * r * 1.2 + hx * off, y - hx * r * 1.2 + hy * off); ctx.stroke();
      ctx.restore();
    }
    function drawPost(q, zb) {
      const x = SX(q.x), y = SY(q.y, zb), r = q.r * V.s, hgt = 2.6 * KZ * V.s;
      ctx.fillStyle = 'rgba(0,0,0,.32)'; ctx.beginPath(); ctx.ellipse(SX(q.x + 0.35), SY(q.y + 0.45, zb), r * 1.08, r * 0.85, 0, 0, 7); ctx.fill();
      // brass-capped walnut pillar
      const g = ctx.createLinearGradient(x - r, 0, x + r, 0);
      g.addColorStop(0, '#4a2b14'); g.addColorStop(0.4, '#8a5a2e'); g.addColorStop(1, '#3a210f');
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.6, 0, 0, Math.PI); ctx.lineTo(x - r, y - hgt); ctx.ellipse(x, y - hgt, r, r * 0.6, 0, Math.PI, 0, true); ctx.closePath(); ctx.fill();
      const g2 = ctx.createRadialGradient(x - r * 0.3, y - hgt - r * 0.2, r * 0.1, x, y - hgt, r);
      g2.addColorStop(0, '#ffe7a3'); g2.addColorStop(0.55, '#e3ae45'); g2.addColorStop(1, '#8a6118');
      ctx.fillStyle = g2; ctx.beginPath(); ctx.ellipse(x, y - hgt, r, r * 0.6, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(40,20,8,.6)'; ctx.lineWidth = 1; ctx.stroke();
    }
    function drawSaw(sw, ws, w) {
      const e = sawEnds(sw);
      let side = -1, k = 0;
      if (ws && ws.used) { side = ws.side; k = clamp((w.t - ws.tt) / 0.12, 0, 1); }
      const zA = side < 0 ? 0.7 : side === 0 ? 0.7 - 0.6 * k : 0.7 + 0.9 * k, zB = side < 0 ? 0.7 : side === 1 ? 0.7 - 0.6 * k : 0.7 + 0.9 * k;
      const c = CS[sw.a], tx = -c[1] * 1.0, ty = c[0] * 1.0;
      // pivot
      poly([[SX(sw.x - c[0] * 0.9), SY(sw.y - c[1] * 0.9, 0)], [SX(sw.x + c[0] * 0.9), SY(sw.y + c[1] * 0.9, 0)], [SX(sw.x), SY(sw.y, 0.75)]], '#3c2614');
      ctx.fillStyle = 'rgba(0,0,0,.25)'; poly([[SX(e[0][0] + tx + 0.3), SY(e[0][1] + ty + 0.4)], [SX(e[1][0] + tx + 0.3), SY(e[1][1] + ty + 0.4)], [SX(e[1][0] - tx + 0.3), SY(e[1][1] - ty + 0.4)], [SX(e[0][0] - tx + 0.3), SY(e[0][1] - ty + 0.4)]], 'rgba(0,0,0,.25)');
      const pts = [[SX(e[0][0] + tx), SY(e[0][1] + ty, zA)], [SX(e[1][0] + tx), SY(e[1][1] + ty, zB)], [SX(e[1][0] - tx), SY(e[1][1] - ty, zB)], [SX(e[0][0] - tx), SY(e[0][1] - ty, zA)]];
      poly(pts, '#b98549', '#5a3a1e', 1);
      ctx.strokeStyle = 'rgba(90,58,30,.6)'; ctx.lineWidth = 1;
      for (const t of [0.25, 0.5, 0.75]) { const a = [e[0][0] + (e[1][0] - e[0][0]) * t, e[0][1] + (e[1][1] - e[0][1]) * t], z = zA + (zB - zA) * t; ctx.beginPath(); ctx.moveTo(SX(a[0] + tx), SY(a[1] + ty, z)); ctx.lineTo(SX(a[0] - tx), SY(a[1] - ty, z)); ctx.stroke(); }
      if (!ws || !ws.used) for (const p of e) { ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.arc(SX(p[0]), SY(p[1], 0.7), SAWR * V.s, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
    }
    function drawPlank(p, hn, ht, kind, T) {
      const c = CS[p.a], tx = -c[1], ty = c[0];
      const corner = (u, v) => { const x = p.x + c[0] * hn * u + tx * ht * v, y = p.y + c[1] * hn * u + ty * ht * v; return [x, y]; };
      if (kind === 1) {
        const pts = [corner(-1, -1), corner(1, -1), corner(1, 1), corner(-1, 1)].map((q) => [SX(q[0]), SY(q[1], 0.15)]);
        poly(pts.map((q) => [q[0] + 2, q[1] + 3]), 'rgba(0,0,0,.35)');
        poly(pts, '#a0703e', '#4d2f16', 1.2);
        ctx.strokeStyle = 'rgba(60,36,16,.55)'; ctx.lineWidth = 1;
        for (let u = -0.8; u <= 0.81; u += 0.2) { const a = corner(u, -1), b = corner(u, 1); ctx.beginPath(); ctx.moveTo(SX(a[0]), SY(a[1], 0.15)); ctx.lineTo(SX(b[0]), SY(b[1], 0.15)); ctx.stroke(); }
        ctx.strokeStyle = '#6e4622'; ctx.lineWidth = Math.max(1.5, V.s * 0.22);
        for (const v of [-1, 1]) { const a = corner(-1, v), b = corner(1, v); ctx.beginPath(); ctx.moveTo(SX(a[0]), SY(a[1], 0.6)); ctx.lineTo(SX(b[0]), SY(b[1], 0.6)); ctx.stroke(); }
      } else {
        const n = 5;
        for (let k = 0; k < n; k++) {
          const u0 = -1 + 2 * k / n, u1 = -1 + 2 * (k + 1) / n, z = (T ? zAt(T, corner((u0 + u1) / 2, 0)[0], corner((u0 + u1) / 2, 0)[1]) : 0.75);
          const pts = [corner(u0, -1), corner(u1, -1), corner(u1, 1), corner(u0, 1)].map((q) => [SX(q[0]), SY(q[1], z)]);
          poly(pts, shade('#c48a50', 0.8 + 0.06 * k), '#4d2f16', 0.8);
        }
      }
    }
    function drawFloor(T) {
      const g = ctx.createLinearGradient(0, 0, 0, cv.h); g.addColorStop(0, '#1b1524'); g.addColorStop(1, '#0f0b15');
      ctx.fillStyle = g; ctx.fillRect(0, 0, cv.w, cv.h);
      // rail
      const x0 = SX(0), y0 = SY(0), x1 = SX(FW), y1 = SY(FH), rw = Math.max(5, V.s * 0.8);
      ctx.fillStyle = '#3d2412'; ctx.fillRect(x0 - rw, y0 - rw, x1 - x0 + 2 * rw, y1 - y0 + 2 * rw);
      ctx.strokeStyle = 'rgba(227,174,69,.35)'; ctx.lineWidth = 1; ctx.strokeRect(x0 - rw + 0.5, y0 - rw + 0.5, x1 - x0 + 2 * rw - 1, y1 - y0 + 2 * rw - 1);
      const fg = ctx.createRadialGradient((x0 + x1) / 2, (y0 + y1) / 2, 10, (x0 + x1) / 2, (y0 + y1) / 2, (y1 - y0) * 0.7);
      fg.addColorStop(0, '#2a6f58'); fg.addColorStop(1, '#174a3a');
      ctx.fillStyle = fg; ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      ctx.fillStyle = 'rgba(242,233,216,.08)';
      for (let y = 4; y < FH; y += 4) for (let x = 4; x < FW; x += 4) ctx.fillRect(SX(x) - 0.75, SY(y) - 0.75, 1.5, 1.5);
      // ramps
      for (const r of stg.ramps) {
        ctx.fillStyle = 'rgba(196,150,90,.35)'; ctx.fillRect(SX(r[0]), SY(r[1]), (r[2] - r[0]) * V.s, (r[3] - r[1]) * V.s);
        ctx.strokeStyle = 'rgba(242,233,216,.45)'; ctx.lineWidth = 1.5;
        const cx = (r[0] + r[2]) / 2, cy = (r[1] + r[3]) / 2;
        for (let k = -1; k <= 1; k++) {
          const ax = cx + r[4] * k * 1.6, ay = cy + r[5] * k * 1.6, px = -r[5], py = r[4];
          ctx.beginPath(); ctx.moveTo(SX(ax - r[4] * 0.6 + px), SY(ay - r[5] * 0.6 + py)); ctx.lineTo(SX(ax + r[4] * 0.4), SY(ay + r[5] * 0.4)); ctx.lineTo(SX(ax - r[4] * 0.6 - px), SY(ay - r[5] * 0.6 - py)); ctx.stroke();
        }
      }
      // gaps
      for (const r of stg.gaps) {
        const gx = SX(r[0]), gy = SY(r[1]), gw = (r[2] - r[0]) * V.s, gh = (r[3] - r[1]) * V.s;
        ctx.fillStyle = '#07050a'; ctx.fillRect(gx, gy, gw, gh);
        const gg = ctx.createLinearGradient(0, gy, 0, gy + gh); gg.addColorStop(0, 'rgba(60,40,30,.9)'); gg.addColorStop(0.35, 'rgba(10,8,12,0)');
        ctx.fillStyle = gg; ctx.fillRect(gx, gy, gw, gh);
        ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 2; ctx.strokeRect(gx, gy, gw, gh);
      }
      // platform
      for (const r of stg.plat) {
        const z = 1.5;
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(SX(r[0]) + 3, SY(r[1]) + 3, (r[2] - r[0]) * V.s, (r[3] - r[1]) * V.s);
        poly([[SX(r[0]), SY(r[3], z)], [SX(r[2]), SY(r[3], z)], [SX(r[2]), SY(r[3], 0)], [SX(r[0]), SY(r[3], 0)]], '#0f3a2e');
        ctx.fillStyle = '#2f7c63'; ctx.fillRect(SX(r[0]), SY(r[1], z), (r[2] - r[0]) * V.s, (r[3] - r[1]) * V.s);
        ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.lineWidth = 1; ctx.strokeRect(SX(r[0]) + 0.5, SY(r[1], z) + 0.5, (r[2] - r[0]) * V.s - 1, (r[3] - r[1]) * V.s - 1);
      }
    }
    function drawWalls() {
      for (const r of stg.walls) {
        const z = 2.2;
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(SX(r[0]) + 3, SY(r[1]) + 4, (r[2] - r[0]) * V.s, (r[3] - r[1]) * V.s);
        poly([[SX(r[0]), SY(r[3], z)], [SX(r[2]), SY(r[3], z)], [SX(r[2]), SY(r[3], 0)], [SX(r[0]), SY(r[3], 0)]], '#4a2b14');
        const g = ctx.createLinearGradient(0, SY(r[1], z), 0, SY(r[3], z)); g.addColorStop(0, '#9a6434'); g.addColorStop(1, '#7a4a22');
        ctx.fillStyle = g; ctx.fillRect(SX(r[0]), SY(r[1], z), (r[2] - r[0]) * V.s, (r[3] - r[1]) * V.s);
        ctx.strokeStyle = 'rgba(40,20,8,.6)'; ctx.lineWidth = 1; ctx.strokeRect(SX(r[0]) + 0.5, SY(r[1], z) + 0.5, (r[2] - r[0]) * V.s - 1, (r[3] - r[1]) * V.s - 1);
      }
    }

    /* ---- scene ---- */
    function sceneOf() {
      // returns {pcs:[pieces], w (world or null), T, ps (layout), own}
      if (rep && rep.w) return { pcs: rep.w.pc, w: rep.w, T: rep.w.T, ps: rep.ps, own: rep.order[rep.k] };
      const dr = cur >= 0 ? drafts[cur] : null, ps = dr ? dr.ps : (lastLayoutOfMine() || []);
      let T; try { T = checkTerrain(stg, ps); } catch (e) { T = new Terrain(stg, [], []); }
      const pcs = piecesOf(stg, ps, T);
      return { pcs, w: null, T, ps, own: cur >= 0 ? cur : null };
    }
    function lastLayoutOfMine() {
      // waiting after submitting: show what I sent
      if (!st || st.ph !== 'b') return null;
      const me = api.mySeats().find((q) => st.dn[q] && st.sb[q]);
      if (me == null) return null;
      try { return decL(st.sb[me]); } catch (e) { return null; }
    }
    function draw(now) {
      if (!st || !stg) return;
      setView();
      cv.clear();
      const sc = sceneOf(), T = sc.T, w = sc.w;
      drawFloor(T);
      // specials lying flat
      sc.ps.forEach((p) => { if (p.t === 1) drawPlank(p, BRL, BRW, 1, T); });
      sc.ps.forEach((p) => { if (p.t === 2) drawPlank(p, STL, STW, 2, T); });
      drawWalls();
      stg.saws.forEach((sw, i) => drawSaw(sw, w ? w.saws[i] : null, w));
      // depth-sorted things
      const items = [];
      sc.pcs.forEach((P, i) => items.push({ y: P.y + (P.b >= 0 && w && w.bodies[P.b].d[1] > 0 ? w.bodies[P.b].d[1] * DH * dsin(w.bodies[P.b].th) * 0.5 : 0), f: () => (P.k === 'p' ? drawPin(P, w, zAt(T, P.x, P.y)) : drawDomPiece(P, i, w, P.k === 'd' || P.k === 'f' ? sc.own : null, zAt(T, P.x, P.y))) }));
      (w ? w.bells : stg.bells.map((b) => ({ x: b.x, y: b.y, hit: 0 }))).forEach((B) => items.push({ y: B.y, f: () => drawBell(B, w, now, zAt(T, B.x, B.y)) }));
      stg.balls.forEach((b0, i) => { const b = w ? w.balls[i] : { x: b0.x, y: b0.y, rot: 0, hx: 1, hy: 0, gone: 0 }; items.push({ y: b.y, f: () => drawBall(b.x, b.y, b.rot, b.hx, b.hy, zAt(T, b.x, b.y), b.gone) }); });
      stg.posts.forEach((q) => items.push({ y: q.y, f: () => drawPost(q, zAt(T, q.x, q.y)) }));
      items.sort((a, b) => a.y - b.y);
      for (const it of items) it.f();
      if (!w) drawBuildOverlay(sc);
      if (w) drawReplayOverlay(w, now);
    }
    function drawBuildOverlay(sc) {
      const dr = cur >= 0 ? drafts[cur] : null;
      // start marker
      const sp = stg.st, c = CS[sp.a];
      ctx.strokeStyle = 'rgba(227,174,69,.85)'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.arc(SX(sp.x), SY(sp.y), 3.4 * V.s, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      const ax = sp.x + c[0] * 3.9, ay = sp.y + c[1] * 3.9;
      ctx.fillStyle = 'rgba(227,174,69,.9)'; ctx.beginPath(); ctx.moveTo(SX(ax + c[0] * 1.1), SY(ay + c[1] * 1.1)); ctx.lineTo(SX(ax - c[1] * 0.7), SY(ay + c[0] * 0.7)); ctx.lineTo(SX(ax + c[1] * 0.7), SY(ay - c[0] * 0.7)); ctx.fill();
      // black domino lines: a small arrow behind the first one shows which way to push it
      for (const ch of stg.chains) {
        const f = stg.fx[ch.i0], n = CS[f.a], bx = f.x - n[0] * 2.6, by = f.y - n[1] * 2.6;
        ctx.fillStyle = 'rgba(227,174,69,.8)'; ctx.beginPath();
        ctx.moveTo(SX(bx + n[0] * 1.0), SY(by + n[1] * 1.0)); ctx.lineTo(SX(bx - n[1] * 0.7 - n[0] * 0.4), SY(by + n[0] * 0.7 - n[1] * 0.4)); ctx.lineTo(SX(bx + n[1] * 0.7 - n[0] * 0.4), SY(by - n[0] * 0.7 - n[1] * 0.4)); ctx.fill();
      }
      // target rings
      ctx.strokeStyle = 'rgba(238,106,85,.75)'; ctx.lineWidth = 1.5;
      for (const p of stg.pins) { ctx.beginPath(); ctx.arc(SX(p.x), SY(p.y), 1.3 * V.s, 0, 7); ctx.stroke(); }
      if (!dr) return;
      // spacing links between consecutive dominoes
      const doms = dr.ps.map((p, i) => ({ p, i })).filter((q) => q.p.t === 0 || q.p.t === 3);
      const link = (a, b, aa, ba) => {
        const d = Math.hypot(b.x - a.x, b.y - a.y);
        if (d > 6.5) return;
        let da = Math.abs(aa - ba) % 32; if (da > 16) da = 32 - da;
        const deg = da * 5.625;
        const col = d >= 2.3 && d <= 4.3 && deg <= 23 ? 'rgba(95,211,160,.9)' : d >= 1.9 && d <= 4.9 && deg <= 40 ? 'rgba(227,174,69,.9)' : 'rgba(238,106,85,.95)';
        ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(SX(a.x), SY(a.y) + 2); ctx.lineTo(SX(b.x), SY(b.y) + 2); ctx.stroke();
      };
      for (const q of doms) { if (q.p.pv == null) continue; const a = q.p.pv === 'S' ? sp : dr.ps.find((z) => z.id === q.p.pv); if (a) link(a, q.p, a.a, q.p.a); }
      // selection
      if (dr.sel >= 0 && dr.ps[dr.sel]) {
        const p = dr.ps[dr.sel];
        ctx.strokeStyle = drag && drag.bad ? '#ee6a55' : '#e3ae45'; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(SX(p.x), SY(p.y, 1), (p.t === 1 ? BRL : p.t === 2 ? STL : 1.9) * V.s, 0, 7); ctx.stroke();
      }
      if (stroke && stroke.pts.length > 1) {
        ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.beginPath();
        stroke.pts.forEach((q, i) => (i ? ctx.lineTo(SX(q.x), SY(q.y)) : ctx.moveTo(SX(q.x), SY(q.y)))); ctx.stroke(); ctx.lineCap = 'butt';
      }
    }
    function drawReplayOverlay(w, now) {
      const r = w.res();
      const x = 10, y = V.ar.top + 2;
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      if (rep.hold > 0 && rep.sc) {
        const k = clamp(1 - rep.hold / rep.hold0, 0, 1), s = rep.sc;
        ctx.globalAlpha = Math.min(1, k * 4);
        const t = '+' + s.sc + '점';
        ctx.font = '400 ' + Math.round(34 + 6 * (1 - k)) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center';
        ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(t, cv.w / 2, V.ar.top + (V.ar.bot - V.ar.top) * 0.42);
        ctx.fillStyle = '#e3ae45'; ctx.fillText(t, cv.w / 2, V.ar.top + (V.ar.bot - V.ar.top) * 0.42);
        ctx.font = '700 13px "IBM Plex Sans KR", sans-serif';
        const t2 = '과녁 ' + s.h + '×10 · 남김 ' + s.l + ' · 연쇄 ' + s.c;
        ctx.lineWidth = 4; ctx.strokeText(t2, cv.w / 2, V.ar.top + (V.ar.bot - V.ar.top) * 0.42 + 30); ctx.fillStyle = '#f2e9d8'; ctx.fillText(t2, cv.w / 2, V.ar.top + (V.ar.bot - V.ar.top) * 0.42 + 30);
        ctx.globalAlpha = 1;
      }
      void x; void y; void r; void now;
    }

    /* ---- build editing ---- */
    function draft() { return cur >= 0 ? drafts[cur] : null; }
    function snapshot(dr) { dr.undo.push(JSON.stringify(dr.ps)); if (dr.undo.length > 40) dr.undo.shift(); }
    function counts(ps) { const c = [0, 0, 0, 0]; for (const p of ps) c[p.t]++; return c; }
    function canPut(ps, p, ignore) {
      const others = ps.filter((_, i) => i !== ignore);
      const c = counts(others); c[p.t]++;
      if (c[0] > stg.bud || c[1] > stg.sp[0] || c[2] > stg.sp[1] || c[3] > stg.sp[2]) return 'count';
      let T; try { T = checkTerrain(stg, p.t === 1 || p.t === 2 ? others.concat([p]) : others); } catch (e) { return 'bad'; }
      if (!pieceOk(stg, T, p)) return 'bad';
      if (p.t === 0 || p.t === 3) for (const q of others) if ((q.t === 0 || q.t === 3) && Math.hypot(q.x - p.x, q.y - p.y) < 1.25) return 'bad';
      // bridges/stairs removed from under existing dominoes must not leave them hanging
      if (p.t === 1 || p.t === 2) { if (others.some((q) => !pieceOk(stg, T, q))) return 'bad'; }
      return null;
    }
    function layoutOk(ps) { try { checkLayout(stg, ps); return true; } catch (e) { return false; } }
    function nearestPiece(ps, f, maxD) {
      let best = -1, bd = maxD;
      ps.forEach((p, i) => { const d = Math.hypot(p.x - f.x, p.y - f.y) - (p.t === 1 ? 2.5 : p.t === 2 ? 1.5 : 0); if (d < bd) { bd = d; best = i; } });
      return best;
    }
    function posOf(dr, id) { if (id === 'S') return [stg.st.x, stg.st.y]; const q = dr.ps.find((p) => p.id === id); return q ? [q.x, q.y] : null; }
    function startStroke(f) {
      const dr = draft();
      snapshot(dr);
      // continue from the start domino or a domino of an existing line if we begin near it
      let prev = null, pid = null, bd = 3.6;
      const cands = [{ x: stg.st.x, y: stg.st.y, id: 'S' }].concat(dr.ps.filter((p) => p.t === 0 || p.t === 3));
      for (const q of cands) { const d = Math.hypot(q.x - f.x, q.y - f.y); if (d < bd) { bd = d; prev = [q.x, q.y]; pid = q.id; } }
      stroke = { prev, pid, pts: [f], o: f, n: 0 };
      dr.sel = -1;
    }
    function putDom(dr, x, y, a) {
      const p = { t: 0, x: q4(x), y: q4(y), a, id: ++dr.nid, pv: stroke.pid };
      const why = canPut(dr.ps, p);
      if (why) return why;
      // turn the previous domino of this stroke to the bisector for a smooth curve
      if (stroke.n > 0) {
        const qi = dr.ps.findIndex((q) => q.id === stroke.pid);
        const q = dr.ps[qi], pp = q ? posOf(dr, q.pv) : null;
        if (q && pp) { const t2 = Object.assign({}, q, { a: angIdx(p.x - pp[0], p.y - pp[1]) }); if (!canPut(dr.ps, t2, qi)) dr.ps[qi] = t2; }
      }
      dr.ps.push(p); stroke.pid = p.id; stroke.n++;
      clack();
      return null;
    }
    function moveStroke(f) {
      const dr = draft(); if (!stroke || !dr) return;
      stroke.pts.push(f);
      if (!stroke.prev) {
        if (Math.hypot(f.x - stroke.o.x, f.y - stroke.o.y) < 0.9) return;
        const why = putDom(dr, stroke.o.x, stroke.o.y, angIdx(f.x - stroke.o.x, f.y - stroke.o.y));
        if (why === 'count') full();
        stroke.prev = [stroke.o.x, stroke.o.y];
      }
      let g = 0;
      while (g++ < 30) {
        const dx = f.x - stroke.prev[0], dy = f.y - stroke.prev[1], d = Math.hypot(dx, dy);
        if (d < SP) break;
        const ux = dx / d, uy = dy / d, nx = stroke.prev[0] + ux * SP, ny = stroke.prev[1] + uy * SP;
        const why = putDom(dr, nx, ny, angIdx(ux, uy));
        if (why === 'count') { full(); stroke.prev = [nx, ny]; break; }
        stroke.prev = [nx, ny];
      }
      dirty = true; renderHud();
    }
    let fullT = 0;
    function full() { const t = performance.now(); if (t - fullT > 1500) { fullT = t; api.toast('도미노를 다 썼어요'); api.buzz(30); } }
    let clackT = 0;
    function clack() { const t = performance.now(); if (t - clackT > 40) { clackT = t; api.sfx('tick'); api.buzz(6); } }
    function endStroke() {
      const dr = draft(); if (!stroke || !dr) return;
      if (!stroke.n) dr.undo.pop();
      stroke = null; dirty = true; renderHud();
    }
    function placeSpecial(f, t) {
      const dr = draft();
      let a = 48;
      if (t === 1) { const g = stg.gaps.find((r) => inR(f.x, f.y, [r[0] - 3, r[1] - 3, r[2] + 3, r[3] + 3])); if (g) a = (g[2] - g[0]) >= (g[3] - g[1]) ? 48 : 0; }
      if (t === 2) { let pr = null, bd = 1e9; for (const r of stg.plat) { const dd = Math.hypot(clamp(f.x, r[0], r[2]) - f.x, clamp(f.y, r[1], r[3]) - f.y); if (dd < bd) { bd = dd; pr = r; } } if (pr) { const dx = Math.min(Math.abs(f.x - pr[0]), Math.abs(f.x - pr[2])), dy = Math.min(Math.abs(f.y - pr[1]), Math.abs(f.y - pr[3])); a = dy <= dx ? 48 : 0; } }
      if (t === 3) { const n = nearestPiece(dr.ps.filter((p) => p.t === 0), f, 6); if (n >= 0) a = dr.ps.filter((p) => p.t === 0)[n].a; }
      const p = { t, x: q4(f.x), y: q4(f.y), a };
      const why = canPut(dr.ps, p);
      if (why) { api.sfx('click'); api.toast(why === 'count' ? '이 조각은 더 없어요' : '여기에는 놓을 수 없어요'); return; }
      p.id = ++dr.nid; snapshot(dr); dr.ps.push(p); dr.sel = dr.ps.length - 1; dr.tool = 'sel';
      api.sfx('thud'); api.buzz(12); dirty = true; renderHud();
    }
    function rotateSel(dir) {
      const dr = draft(); if (!dr || dr.sel < 0) return;
      const p = dr.ps[dr.sel], q = Object.assign({}, p, { a: (p.a + dir + 64) % 64 });
      if (canPut(dr.ps, q, dr.sel)) { api.sfx('click'); api.toast('그 방향으로는 돌릴 수 없어요'); return; }
      snapshot(dr); dr.ps[dr.sel] = q; api.sfx('tick'); dirty = true;
    }
    function deleteSel() {
      const dr = draft(); if (!dr || dr.sel < 0) return;
      snapshot(dr);
      const rm = dr.ps.splice(dr.sel, 1)[0];
      // removing a bridge/stairs can leave pieces on a hole: drop those too
      if (rm.t === 1 || rm.t === 2) { const T = checkTerrain(stg, dr.ps); dr.ps = dr.ps.filter((q) => pieceOk(stg, T, q)); }
      dr.sel = -1; api.sfx('pop'); dirty = true; renderHud();
    }
    function undo() { const dr = draft(); if (!dr || !dr.undo.length) return; dr.ps = JSON.parse(dr.undo.pop()); dr.sel = -1; api.sfx('click'); dirty = true; renderHud(); }
    function clearAll() { const dr = draft(); if (!dr || !dr.ps.length) return; snapshot(dr); dr.ps = []; dr.sel = -1; api.sfx('whoosh'); api.toast('모두 치웠어요 · ↶로 되돌릴 수 있어요'); dirty = true; renderHud(); }
    function submit() {
      const dr = draft(); if (!dr) return;
      const now = performance.now();
      if (now > confirmUntil) { confirmUntil = now + 2600; api.sfx('tick'); api.buzz(10); renderHud(true); setTimeout(() => renderHud(true), 2700); return; }
      confirmUntil = 0;
      if (!layoutOk(dr.ps)) { api.toast('놓을 수 없는 조각이 있어요'); return; }
      const a = { k: 's', d: encL(dr.ps) };
      const seat = cur;
      api.sfx('whoosh'); api.buzz(20);
      if (!api.isHost) sentAt = performance.now();
      if (api.mySeats().length > 1) api.actAs(seat, a); else api.act(a);
    }

    /* ---- input ---- */
    function myBuildSeat() {
      if (!st || st.ph !== 'b' || rep) return -1;
      if (sentAt && performance.now() - sentAt < 6000) return -1;
      const acts = actor(st) || [];
      const mine = acts.filter((q) => api.canAct(q));
      if (!mine.length) return -1;
      return mine[0];
    }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (ptr || !st || rep || cur < 0 || curtainEl) return;
      const p = cv.local(ev), f = toField(p), dr = draft();
      ptr = { id: ev.pointerId, x0: p.x, y0: p.y, moved: false };
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      if (dr.tool === 'draw') { startStroke(f); moveStroke(f); }
      else if (dr.tool === 'sel') {
        const i = nearestPiece(dr.ps, f, 2.2);
        if (i >= 0) { dr.sel = i; drag = { i, dx: dr.ps[i].x - f.x, dy: dr.ps[i].y - f.y, orig: Object.assign({}, dr.ps[i]), bad: false, moved: false }; api.sfx('tick'); }
        else { dr.sel = -1; drag = null; }
        renderHud();
      } else ptr.special = dr.tool;
      dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!ptr || ptr.id !== ev.pointerId) return;
      const p = cv.local(ev), f = toField(p), dr = draft(); if (!dr) return;
      if (Math.hypot(p.x - ptr.x0, p.y - ptr.y0) > 6) ptr.moved = true;
      if (stroke) moveStroke(f);
      else if (drag && ptr.moved) {
        const q = Object.assign({}, dr.ps[drag.i], { x: q4(clamp(f.x + drag.dx, 0.5, FW - 0.5)), y: q4(clamp(f.y + drag.dy, 0.5, FH - 0.5)) });
        if (!drag.moved) { snapshot(dr); drag.moved = true; }
        drag.bad = !!canPut(dr.ps, q, drag.i);
        dr.ps[drag.i] = q;
      }
      dirty = true;
    });
    function endPtr(ev) {
      if (!ptr || ptr.id !== ev.pointerId) return;
      const pt = ptr; ptr = null;
      const dr = draft();
      if (stroke) endStroke();
      else if (drag && dr) {
        if (drag.bad) { dr.ps[drag.i] = drag.orig; if (drag.moved) dr.undo.pop(); api.toast('여기에는 놓을 수 없어요'); api.sfx('click'); }
        else if (drag.moved) { api.sfx('thud'); if (dr.ps[drag.i].t === 1 || dr.ps[drag.i].t === 2) { const T = checkTerrain(stg, dr.ps); if (dr.ps.some((q) => !pieceOk(stg, T, q))) { dr.ps = JSON.parse(dr.undo.pop()); api.toast('그 위에 있던 도미노가 떨어져요'); } } }
        drag = null; renderHud();
      } else if (pt.special && dr && !pt.moved) placeSpecial(toField(cv.local(ev)), pt.special === 'b' ? 1 : pt.special === 's' ? 2 : 3);
      dirty = true;
    }
    cv.cv.addEventListener('pointerup', endPtr);
    cv.cv.addEventListener('pointercancel', endPtr);

    /* ---- HUD ---- */
    let hudKey = '';
    function btn(label, opts) {
      return L.h('button', Object.assign({ class: 'btn' + (opts.cls ? ' ' + opts.cls : ''), type: 'button', text: label, style: Object.assign({ minHeight: '44px', padding: '0 10px', fontSize: '13px', flex: 'none' }, opts.style || {}) }, opts.attrs || {}, { onclick: opts.on }));
    }
    function renderHud(force) {
      if (!st || !stg) return;
      const dr = draft(), c = dr ? counts(dr.ps) : null;
      const waiting = st.ph === 'b' && cur < 0;
      const rr = rep && rep.w ? rep.w.res() : null;
      const key = [st.r, st.ph, cur, rep ? rep.k + ':' + (rep.hold > 0 ? 1 : 0) + (rep.fast ? 'f' : '') + (rr ? rr.c + '/' + rr.h : '') : '', dr ? dr.ps.length + ':' + dr.sel + ':' + dr.tool + ':' + dr.undo.length + ':' + c.join(',') : '', confirmUntil > performance.now() ? 1 : 0, st.dn.join(''), sentAt ? 1 : 0, sumEl ? 1 : 0].join('|');
      if (key === hudKey && !force) return;
      hudKey = key;
      topEl.innerHTML = '';
      const ri = rep ? rep.last.r : Math.min(st.r, st.sl.length - 1);
      const sNm = rep ? rep.stg.nm : stg.nm;
      topEl.append(L.h('div', { class: 'panel dm-stage', style: { padding: '5px 10px', fontSize: '12px', display: 'flex', gap: '6px', alignItems: 'baseline', minWidth: 0, overflow: 'hidden', whiteSpace: 'nowrap' } },
        L.h('b', { class: 'mono', style: { color: 'var(--brass)' }, text: (ri + 1) + '/' + st.sl.length }), L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 700 }, text: sNm })));
      if (rep && rep.w) {
        const r = rep.w.res(), tg = targetsOf(rep.stg), who = rep.order[rep.k];
        topEl.append(L.h('div', { class: 'panel mono', style: { padding: '5px 10px', fontSize: '12px', display: 'flex', gap: '8px', flex: 'none' } },
          L.h('span', null, '연쇄 ', L.h('b', { style: { color: 'var(--brass)' }, text: String(r.c) })),
          L.h('span', null, '과녁 ', L.h('b', { style: { color: '#ee6a55' }, text: r.h + '/' + tg }))));
        void who;
      } else if (dr) {
        const left = stg.bud - c[0];
        topEl.append(L.h('div', { class: 'panel mono dm-left', style: { padding: '5px 10px', fontSize: '12px', flex: 'none' } },
          '남은 도미노 ', L.h('b', { style: { color: left ? 'var(--brass)' : '#ee6a55' }, text: String(left) }), '/' + stg.bud));
      } else {
        topEl.append(L.h('div', { class: 'panel mono', style: { padding: '5px 10px', fontSize: '12px', flex: 'none' } }, '도미노 ' + stg.bud + '개'));
      }
      bot.innerHTML = '';
      if (rep) {
        const who = rep.order[rep.k];
        bot.append(L.h('div', { style: { display: 'flex', gap: '8px', alignItems: 'stretch' } },
          L.h('div', { class: 'panel', style: { flex: '1 1 auto', minWidth: 0, display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 10px' } },
            L.h('span', { class: 'dot', style: { '--c': color(who) } }),
            L.h('div', { style: { minWidth: 0 } },
              L.h('div', { style: { fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: nameOf(who) + '의 도미노' }),
              L.h('div', { class: 'muted', style: { fontSize: '11.5px' }, text: (rep.k + 1) + '/' + rep.order.length + ' · 차례로 쓰러뜨려 봐요' }))),
          btn(rep.fast ? '보통 속도' : '빨리 ▶▶', { on: () => { rep.fast = !rep.fast; api.sfx('click'); renderHud(true); } }),
          btn('건너뛰기', { on: () => { skipReplay(); } })));
        return;
      }
      if (st.ph === 'e') return;
      if (waiting) {
        const done = st.dn.filter((x) => x).length, mineDone = api.mySeats().some((q) => st.dn[q]);
        const anyAI = actor(st).some((q) => api.players[q] && api.players[q].ai);
        bot.append(L.h('div', { class: 'panel', style: { padding: '8px 12px', fontSize: '13px', textAlign: 'center' } },
          L.h('b', null, mineDone ? '제출했어요' : '구경 중'), L.h('span', { class: 'muted', text: ' · ' + (anyAI ? '다른 사람(AI 포함)' : '다른 사람') + '이 배치하는 중 (' + done + '/' + st.n + ')' })));
        return;
      }
      if (!dr) return;
      const tools = [['draw', '✏ 그리기'], ['sel', '✋ 고르기']];
      const sp = [['b', '다리', 1, 0], ['s', '계단', 2, 1], ['f', '갈림길', 3, 2]];
      const row1 = L.h('div', { class: 'dm-tools', style: { display: 'flex', gap: '6px', overflowX: 'auto', scrollbarWidth: 'none', minWidth: 0, maxWidth: '100%' } });
      for (const [id, lb] of tools) row1.append(btn(lb, { cls: 'dm-t-' + id + (dr.tool === id ? ' primary' : ''), style: { flex: '1 1 0', minWidth: '0', whiteSpace: 'nowrap' }, on: () => { dr.tool = id; api.sfx('tick'); renderHud(); dirty = true; } }));
      for (const [id, lb, t, k] of sp) {
        if (!stg.sp[k]) continue;
        const left = stg.sp[k] - c[t];
        row1.append(btn(lb + ' ' + left, { cls: dr.tool === id ? 'primary' : '', style: { flex: '1 1 0', minWidth: '0', whiteSpace: 'nowrap', opacity: left ? 1 : 0.5 }, on: () => { if (!left) { api.toast(lb + '은(는) 이미 놓았어요'); return; } dr.tool = id; api.sfx('tick'); api.toast('바닥을 눌러 ' + lb + '을(를) 놓아요'); renderHud(); } }));
      }
      const hasSel = dr.sel >= 0 && !!dr.ps[dr.sel];
      const conf = confirmUntil > performance.now();
      const row2 = L.h('div', { class: 'dm-edit', style: { display: 'flex', gap: '6px', minWidth: 0, maxWidth: '100%' } },
        btn('↶', { attrs: { 'aria-label': '되돌리기', disabled: dr.undo.length ? null : true }, style: { width: '44px', padding: 0, fontSize: '18px' }, on: undo }),
        btn('⟲', { attrs: { 'aria-label': '왼쪽으로 돌리기', disabled: hasSel ? null : true }, style: { width: '44px', padding: 0, fontSize: '18px' }, on: () => rotateSel(-1) }),
        btn('⟳', { attrs: { 'aria-label': '오른쪽으로 돌리기', disabled: hasSel ? null : true }, style: { width: '44px', padding: 0, fontSize: '18px' }, on: () => rotateSel(1) }),
        btn(hasSel ? '빼기' : '비우기', { attrs: { 'aria-label': hasSel ? '고른 조각 빼기' : '모두 치우기', disabled: dr.ps.length ? null : true }, style: { width: '56px', padding: 0 }, on: () => (hasSel ? deleteSel() : clearAll()) }),
        btn(conf ? '한 번 더!' : '쓰러뜨리기', { cls: 'primary dm-go', style: { flex: '1 1 auto', minWidth: 0, fontSize: '14px' }, on: submit }));
      let hint;
      if (conf) hint = '한 번 더 누르면 제출해요 (도미노 ' + c[0] + '개)';
      else if (dr.tool === 'draw') hint = dr.ps.length ? '선이 초록이면 좋은 간격 · 이어 그리려면 마지막 도미노 근처에서 시작' : '금색 시작 도미노 근처에서 과녁 쪽으로 길을 그어요';
      else if (dr.tool === 'sel') hint = hasSel ? '끌어서 옮기기 · ⟲ ⟳ 돌리기 · 빼기' : '도미노나 조각을 눌러 골라요';
      else hint = '바닥을 눌러 놓아요';
      const who = api.mySeats().length > 1 ? nameOf(cur) + ' · ' : '';
      bot.append(L.h('div', { class: 'muted dm-hint', style: { fontSize: '11.5px', textAlign: 'center', textShadow: '0 1px 2px #000', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minWidth: 0, maxWidth: '100%' }, text: who + hint }), row1, row2);
    }

    /* ---- curtain for several builders on one phone ---- */
    function needCurtain() { return cur >= 0 && api.mySeats().length > 1 && !api.online && shown !== cur; }
    function showCurtain() {
      if (curtainEl) return;
      const seat = cur;
      curtainEl = L.h('div', { class: 'overlay curtain', style: { zIndex: 15 } },
        L.h('span', { class: 'dot', style: { '--c': color(seat), width: '18px', height: '18px' } }),
        L.h('div', { class: 'big', text: nameOf(seat) }),
        L.h('div', { class: 'muted', text: '다른 사람이 보지 않게 폰을 넘겨주세요' }),
        L.h('button', { class: 'btn primary', text: '배치 시작' }));
      curtainEl.addEventListener('click', () => { shown = seat; curtainEl.remove(); curtainEl = null; api.sfx('click'); renderHud(true); dirty = true; });
      root.append(curtainEl);
    }
    function hideCurtain() { if (curtainEl) { curtainEl.remove(); curtainEl = null; } }

    /* ---- replay ---- */
    function startReplay(last) {
      const s2 = stageOf(last.si, last.mr);
      const order = []; for (let i = 0; i < last.L.length; i++) order.push(i);
      rep = { last, order, k: -1, w: null, stg: s2, ps: [], acc: 0, hold: 0, hold0: 1, fast: false, sc: null };
      stg = s2;
      hideCurtain();
      api.setBusy(true);
      nextReplay();
    }
    function nextReplay() {
      rep.k++;
      if (rep.k >= rep.order.length) { showSummary(); return; }
      const seat = rep.order[rep.k];
      let ps = []; try { ps = decL(rep.last.L[seat]); } catch (e) {}
      rep.ps = ps; rep.w = new World(rep.stg, ps); rep.acc = 0; rep.hold = 0; rep.sc = null;
      cam.z = 1; cam.tz = 1; cam.cx = FW / 2; cam.cy = FH / 2;
      api.sfx('click');
      renderHud(true);
    }
    function skipReplay() {
      if (!rep) return;
      if (rep.w && !rep.w.done) { rep.w.run(); }
      rep.hold = 0.01;
      api.sfx('click');
    }
    function showSummary() {
      rep.w = null;
      const L2 = rep.last, R = L2.R, n = R.length;
      const rows = [];
      const ordr = []; for (let i = 0; i < n; i++) ordr.push(i);
      ordr.sort((a, b) => R[b][3] - R[a][3] || a - b);
      for (const i of ordr) {
        rows.push(L.h('div', { style: { display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '8px', alignItems: 'center', padding: '6px 0', borderTop: '1px solid var(--line)' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0 } }, L.h('span', { class: 'dot', style: { '--c': color(i) } }), L.h('b', { style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: nameOf(i) })),
          L.h('span', { class: 'muted mono', style: { fontSize: '11.5px' }, text: '과녁' + R[i][0] + ' 남김' + R[i][2] + ' 연쇄' + R[i][1] }),
          L.h('b', { class: 'mono', style: { color: 'var(--brass)', minWidth: '5ch', textAlign: 'right' }, text: '+' + R[i][3] })));
      }
      const tot = st ? st.tot : null;
      const last = st && st.ph === 'e';
      const go = L.h('button', { class: 'btn primary', text: last ? '최종 결과' : '다음 스테이지', onclick: () => endReplay() });
      sumEl = L.h('div', { class: 'overlay', style: { zIndex: 14 } },
        L.h('div', { class: 'sheet' },
          L.h('span', { class: 'label', text: (L2.r + 1) + '스테이지 결과' }),
          L.h('h2', { text: rep.stg.nm }),
          L.h('div', null, rows),
          tot ? L.h('div', { class: 'muted', style: { fontSize: '12.5px' }, text: '총점 · ' + tot.map((v, i) => nameOf(i) + ' ' + v).join(' · ') }) : null,
          L.h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, go)));
      root.append(sumEl);
      api.sfx('chip');
      rep.sumT = 0; rep.sumMax = api.mySeats().length ? 9 : 3.2;
      renderHud(true);
    }
    function endReplay() {
      if (sumEl) { sumEl.remove(); sumEl = null; }
      rep = null;
      stg = st && st.ph === 'b' ? curStage(st) : stg;
      cam.z = 1; cam.tz = 1;
      syncBuilder();
      api.setBusy(false);
      renderHud(true); dirty = true;
    }
    function playSounds(w) {
      const now = performance.now();
      for (const e of w.snd) {
        const map = { clack: ['tick', 30], big: ['thud', 90], pin: ['pop', 60], bell: ['chip', 90], ball: ['roll', 60], saw: ['whoosh', 120], wall: ['thud', 80], bump: ['bounce', 70], drop: ['thud', 200], flat: ['click', 45] }[e.k];
        if (!map) continue;
        if (sndT[e.k] && now - sndT[e.k] < map[1]) continue;
        sndT[e.k] = now; api.sfx(map[0]);
        if (e.k === 'bell' || e.k === 'pin') api.buzz(e.k === 'bell' ? 30 : 12);
      }
      w.snd.length = 0;
    }
    function tickReplay(dt) {
      if (!rep || !rep.w) { if (rep && sumEl) { rep.sumT += dt * L.debug.speed; if (rep.sumT > rep.sumMax) endReplay(); } return; }
      const w = rep.w, sp = L.debug.speed * (rep.fast ? 3 : 1);
      if (!w.done) {
        rep.acc += dt * sp;
        let n = 0;
        while (rep.acc >= SDT && !w.done && n < 4000) { w.step(); rep.acc -= SDT; n++; }
        playSounds(w);
        // camera follows the moving front
        let sx = 0, sy = 0, k = 0;
        for (const b of w.bodies) if (b.st === 1) { sx += b.o[0] + b.d[0] * 2; sy += b.o[1] + b.d[1] * 2; k++; }
        for (const B of w.balls) if (B.mv) { sx += B.x * 2; sy += B.y * 2; k += 2; }
        if (k) { cam.tcx = sx / k; cam.tcy = sy / k; cam.tz = 1.45; } else cam.tz = 1;
        if (w.done) {
          rep.sc = scoreOf(rep.stg, rep.ps, w.res());
          rep.hold = rep.hold0 = 1.6;
          if (rep.sc.h) api.sfx('win');
          renderHud(true);
        }
        renderHud();
      } else if (rep.hold > 0) {
        rep.hold -= dt * L.debug.speed * (rep.fast ? 2 : 1);
        cam.tz = 1;
        if (rep.hold <= 0) nextReplay();
      }
      dirty = true;
    }

    /* ---- whose build is on this screen ---- */
    function syncBuilder() {
      if (!st || rep) return;
      const seat = myBuildSeat();
      if (seat !== cur) { cur = seat; confirmUntil = 0; stroke = null; drag = null; }
      if (cur >= 0) {
        const key = st.r;
        if (!drafts[cur] || drafts[cur].r !== key) drafts[cur] = { r: key, ps: [], undo: [], tool: 'draw', sel: -1, nid: 0 };
        if (needCurtain()) showCurtain(); else hideCurtain();
      } else hideCurtain();
    }

    /* ---- main loop ---- */
    const stop = U.loop((dt, now) => {
      if (!alive) return;
      tickReplay(dt);
      const zk = Math.min(1, dt * 3);
      cam.z += (cam.tz - cam.z) * zk; cam.cx += (cam.tcx - cam.cx) * zk; cam.cy += (cam.tcy - cam.cy) * zk;
      if (Math.abs(cam.tz - cam.z) > 1e-3) dirty = true;
      if (sentAt && performance.now() - sentAt > 6000) { sentAt = 0; syncBuilder(); renderHud(true); }
      if (confirmUntil && performance.now() > confirmUntil) { confirmUntil = 0; renderHud(true); }
      if (dirty || ptr) { dirty = false; draw(now); }
    });
    cv.onresize = () => { dirty = true; };
    // test hook: field → screen
    cv.cv._dbg = () => ({ cur, tool: draft() ? draft().tool : null, n: draft() ? draft().ps.length : -1, rep: !!rep, scr: (x, y) => [SX(x), SY(y)], stg: stg ? { st: stg.st, pins: stg.pins, bells: stg.bells } : null });

    return {
      update(next, prev) {
        st = next;
        if (prev !== next) sentAt = 0;
        const l = next.last;
        if (!prev) {
          stg = next.ph === 'b' ? curStage(next) : l ? stageOf(l.si, l.mr) : curStage(Object.assign({}, next, { r: 0 }));
        } else if (prev !== next && l && (!prev.last || prev.last.id !== l.id)) {
          startReplay(l);
          return;
        }
        if (!rep) { if (next.ph === 'b') stg = curStage(next); syncBuilder(); }
        renderHud(true); dirty = true;
      },
      destroy() { alive = false; stop(); cv.destroy(); topEl.remove(); bot.remove(); hideCurtain(); if (sumEl) sumEl.remove(); api.setBusy(false); },
    };
  }
})();
