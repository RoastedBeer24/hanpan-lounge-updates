/* 스모 범퍼카 — realtime bumper-car sumo (2–6). Push the others off the arena; last one standing wins the round.
   32 arenas with their own mechanics, 20 power-ups (vector icons, no emoji). Host-authoritative fixed-step physics (1/120 s); guests publish their
   stick/turn input + a dash counter, receive ~20 Hz snapshots, interpolate the other cars and lightly predict
   their own. One person per phone: locally you drive seat 0 against AI cars; friends play through online/LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const H = 1 / 120;            // physics step
  const CR = 8;                 // car radius
  const ACC = 220, VMAX = 200, DASH = 150, DASH_CD = 2.2, DASH_T = 0.3;
  const POP = 20, EC = 0.85;    // extra separation speed on a bump, restitution
  const FALL_T = 0.7, COUNT = 3, END_T = 2.6, ITEM_EVERY = 8, ITEM_T = 7;
  const RESPAWN_T = 2.4, INV_T = 2.0, KILL_WIN = 3, OT_MAX = 45; // respawn wait, spawn shield, kill-credit window, overtime cap (s)
  const TEAMC = [['#e8574a', '#f29a5a', '#d6457e'], ['#4a8fe8', '#52c9e0', '#8a72ec']], TEAMN = ['빨강 팀', '파랑 팀'];
  const ally = (W, a, b) => !!(W && W.tm && a >= 0 && b >= 0 && a !== b && W.tm[a] === W.tm[b]); // 팀전: same side
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const wrapA = (a) => { a = (a + Math.PI) % (Math.PI * 2); if (a < 0) a += Math.PI * 2; return a - Math.PI; };
  function hash32(a, b) {
    let h = (Math.imul(a | 0, 0x9E3779B1) ^ Math.imul((b | 0) + 0x632BE5AB, 0x85EBCA77)) >>> 0;
    h ^= h >>> 16; h = Math.imul(h, 0x7feb352d) >>> 0; h ^= h >>> 15; h = Math.imul(h, 0x846ca68b) >>> 0; h ^= h >>> 16;
    return h >>> 0;
  }

  /* arenas: shape 'c' (circle R) or 'r' (rect hw × hh); fr = floor friction (1/s), grip = how much thrust bites */
  const ARENAS = [
    { id: 'dojo', name: '원형 도장', sub: '기본 원형 링. 정직한 밀어내기 한판', shape: 'c', R: 100, fr: 2.2, grip: 1 },
    { id: 'ice', name: '얼음 링', sub: '잘 미끄러져요. 멈추기도 꺾기도 어려워요', shape: 'c', R: 100, fr: 0.3, grip: 0.38 },
    { id: 'island', name: '줄어드는 섬', sub: '모래섬이 점점 작아져요', shape: 'c', R: 116, fr: 2.4, grip: 1, shrink: 1 },
    { id: 'spin', name: '회전 원판', sub: '원판이 돌아요. 바깥쪽일수록 빨리 휩쓸려요', shape: 'c', R: 102, fr: 2.0, grip: 0.95, spin: 0.75 },
    { id: 'holes', name: '구멍 바닥', sub: '깜빡이는 칸은 곧 뚫려요', shape: 'c', R: 106, fr: 2.2, grip: 1, holes: 1 },
    { id: 'bumper', name: '범퍼 기둥', sub: '기둥에 닿으면 세게 튕겨 나가요', shape: 'c', R: 106, fr: 2.0, grip: 1, posts: [[0, -52, 12], [52, 0, 12], [0, 52, 12], [-52, 0, 12]] },
    { id: 'belt', name: '컨베이어 벨트', sub: '띠마다 반대로 흘러가는 바닥', shape: 'r', hw: 92, hh: 116, fr: 2.4, grip: 1, belts: 1 },
    { id: 'wind', name: '바람 부는 절벽', sub: '화살표가 뜨면 곧 옆바람이 불어요', shape: 'r', hw: 86, hh: 118, fr: 2.2, grip: 1, wind: 1 },
    { id: 'seesaw', name: '시소 판', sub: '무거운 쪽으로 판이 기울어요', shape: 'r', hw: 72, hh: 126, fr: 2.0, grip: 1, tilt: 1 },
    { id: 'hill', name: '가운데 언덕', sub: '가운데 언덕에서는 바깥으로 미끄러져요', shape: 'c', R: 106, fr: 2.2, grip: 1, hill: 46 },
    { id: 'lava', name: '용암 분출구', sub: '빨갛게 달아오른 구멍이 곧 터지며 차를 날려요', shape: 'c', R: 104, fr: 2.2, grip: 1, vents: 1 },
    { id: 'pinball', name: '핀볼 테이블', sub: '플리퍼가 주기적으로 쳐올리고 범퍼가 튕겨요', shape: 'r', hw: 84, hh: 120, fr: 1.7, grip: 1, flip: 1, posts: [[0, 0, 10], [-40, -34, 8], [40, 34, 8]] },
    { id: 'magnet', name: '자석 바닥', sub: '켜진 자석 판이 근처 차를 끌어당겨요', shape: 'c', R: 106, fr: 2.2, grip: 1, mag: 1 },
    { id: 'tramp', name: '트램펄린', sub: '노란 판을 밟으면 달리던 쪽으로 튀어 올라요', shape: 'c', R: 108, fr: 2.2, grip: 1, pads: 1 },
    { id: 'drift', name: '떠다니는 판', sub: '네 판이 벌어졌다 붙었다 해요. 틈에 빠지지 마세요', shape: 'p', fr: 2.6, grip: 1, plat: 1 },
    { id: 'bhole', name: '블랙홀', sub: '가운데 블랙홀이 차를 빨아들여요', shape: 'c', R: 108, fr: 2.0, grip: 1, bhole: 1 },
    { id: 'jelly', name: '해파리 바다', sub: '떠다니는 해파리에 닿으면 통 튕겨요', shape: 'c', R: 106, fr: 2.2, grip: 1, jelly: 1 },
    { id: 'top', name: '거대 팽이', sub: '가운데 팽이가 돌아다니며 차를 쳐내요', shape: 'c', R: 106, fr: 2.2, grip: 1, top: 1 },
    { id: 'laser', name: '레이저 벽', sub: '도는 레이저가 켜지면 쓸려 나가요', shape: 'c', R: 104, fr: 2.2, grip: 1, laser: 1 },
    { id: 'dark', name: '꺼지는 조명', sub: '조명이 깜빡이다 잠깐 꺼져요. 전조등만 보여요', shape: 'r', hw: 88, hh: 116, fr: 2.2, grip: 1, dark: 1 },
    // round 12: new arenas, each with its own mechanic
    { id: 'trap', name: '함정문 바닥', sub: '빨갛게 깜빡인 문이 열렸다가 다시 닫혀요', shape: 'c', R: 106, fr: 2.2, grip: 1, trap: 1 },
    { id: 'piston', name: '피스톤 벽', sub: '양옆 벽에서 피스톤이 튀어나와 밀쳐요', shape: 'r', hw: 90, hh: 112, fr: 2.2, grip: 1, piston: 1 },
    { id: 'tide', name: '용암 밀물', sub: '용암이 밀려왔다 빠져요. 빨간 점선까지 잠겨요', shape: 'c', R: 108, fr: 2.2, grip: 1, tide: 1 },
    { id: 'fan', name: '선풍기 구역', sub: '돌기 시작한 선풍기 앞 길로 센 바람이 불어요', shape: 'c', R: 104, fr: 2.2, grip: 1, fans: 1 },
    { id: 'bowl', name: '기우는 원반', sub: '차가 몰린 쪽으로 원반이 사방으로 기울어요', shape: 'c', R: 100, fr: 2.0, grip: 1, tilt2: 1 },
    { id: 'windmill', name: '풍차 날개', sub: '가운데 날개 셋이 이리저리 돌며 쓸어내요', shape: 'c', R: 108, fr: 2.2, grip: 1, arms: 1 },
    { id: 'donut', name: '도넛 회전판', sub: '안쪽·바깥 고리가 반대로 돌아요. 가운데는 구멍', shape: 'c', R: 110, fr: 2.2, grip: 1, donut: 1 },
    { id: 'popup', name: '솟는 기둥', sub: '빛나는 자리에서 기둥이 솟아 차를 튕겨요', shape: 'c', R: 106, fr: 2.2, grip: 1, pop: 1 },
    { id: 'blizzard', name: '눈보라 빙판', sub: '미끄러운 빙판에 사방에서 돌풍이 불어요', shape: 'r', hw: 90, hh: 114, fr: 0.8, grip: 0.55, gust: 1 },
    { id: 'cross', name: '흔들 다리', sub: '좁은 십자 다리가 가끔 크게 흔들려요', shape: 'x', fr: 2.4, grip: 1, quake: 1 },
    { id: 'bombs', name: '폭탄 비', sub: '과녁이 뜨면 곧 폭탄이 떨어져 터져요', shape: 'c', R: 106, fr: 2.2, grip: 1, bombs: 1 },
    { id: 'wreck', name: '철구 진자', sub: '거대한 쇠공이 그네처럼 오가며 들이받아요', shape: 'c', R: 106, fr: 2.2, grip: 1, wreck: 1 },
    // round 13: more arenas for the timed kill race
    { id: 'fence', name: '회전 울타리', sub: '고무 울타리의 뚫린 틈이 빙글빙글 돌아요', shape: 'c', R: 104, fr: 2.2, grip: 1, fence: 1 },
    { id: 'slope', name: '도는 비탈', sub: '바닥이 화살표 쪽으로 기울고, 그 방향이 돌아요', shape: 'c', R: 104, fr: 2.2, grip: 1, slope: 1 },
    { id: 'portal', name: '포탈 광장', sub: '같은 색 포탈로 들어가면 짝 포탈로 나와요', shape: 'c', R: 106, fr: 2.2, grip: 1, portal: 1 },
    { id: 'boost', name: '가속 발판', sub: '화살표 발판이 그쪽으로 쏘아 보내요. 방향이 바뀌어요', shape: 'c', R: 108, fr: 2.2, grip: 1, boost: 1 },
    { id: 'logs', name: '굴러오는 통나무', sub: '빨간 화살표 쪽에서 곧 통나무가 굴러와요', shape: 'r', hw: 88, hh: 116, fr: 2.2, grip: 1, logs: 1 },
    { id: 'rift', name: '갈라지는 땅', sub: '점선을 따라 땅이 갈라졌다 다시 붙어요', shape: 'c', R: 106, fr: 2.2, grip: 1, rift: 1 },
    { id: 'wave', name: '밀려오는 파도', sub: '거품이 일면 곧 파도가 바닥을 쓸고 지나가요', shape: 'r', hw: 90, hh: 112, fr: 2.2, grip: 1, wave: 1 },
    { id: 'rubber', name: '고무벽 복도', sub: '양옆은 튕기는 고무벽, 위아래 끝이 낭떠러지', shape: 'r', hw: 74, hh: 122, fr: 2.2, grip: 1, walls: 1 },
  ];
  /* power-ups: key → name, color, duration (s; 0 = instant), one-line effect (shown when it hits you). Icons are drawn in drawIcon(). */
  const ITEMS = {
    h: { nm: '무거워짐', col: '#e3ae45', T: ITEM_T, d: '7초 동안 묵직해서 잘 안 밀려요' },
    s: { nm: '방패', col: '#7fe3ff', T: ITEM_T * 0.75, d: '약 5초 동안 거의 안 밀려요' },
    w: { nm: '충격파', col: '#ff9a5c', T: 0, d: '주변 차를 바깥으로 튕겨냈어요' },
    g: { nm: '갈고리', col: '#c9a0ff', T: 0, d: '가장 가까운 차를 끌어당겼어요' },
    o: { nm: '기름', col: '#9fb2c4', T: 0, d: '가까운 차 밑에 미끄러운 기름!' },
    b: { nm: '거대화', col: '#ee6a55', T: 6, d: '6초 동안 크고 무거워져요' },
    t: { nm: '순간 이동', col: '#5fd3e8', T: 9, d: '다음 돌진이 순간 이동이 돼요' },
    r: { nm: '역방향', col: '#f07fb8', T: 0, d: '가까운 차의 조작이 반대로!' },
    k: { nm: '끈끈이', col: '#8fd35f', T: 0, d: '주변 차들이 끈적해져 느려져요' },
    m: { nm: '반사 갑옷', col: '#dfe6ee', T: 6, d: '부딪혀 오는 힘을 되돌려줘요' },
    n: { nm: '자석', col: '#e0507a', T: 4.5, d: '4.5초 동안 주변 차를 끌어당겨요' },
    p: { nm: '스프링', col: '#ffe066', T: 9, d: '다음 돌진이 높이 뛰기가 돼요' },
    z: { nm: '축소 광선', col: '#7f9cff', T: 5, d: '가까운 차가 작고 가벼워져요' },
    v: { nm: '회오리', col: '#7fe0c4', T: 5.5, d: '회오리가 상대를 쫓아가 휘감아요' },
    x: { nm: '폭탄', col: '#ff7a3d', T: 1.6, d: '뒤에 폭탄을 떨궜어요. 얼른 피해요!' },
    u: { nm: '꽁꽁', col: '#a6d8ff', T: 2.2, d: '가까운 차가 2초 동안 얼어붙어요' },
    f: { nm: '터보', col: '#ffb02e', T: 5, d: '5초 동안 빠르고 돌진도 자주!' },
    y: { nm: '유령', col: '#c8c0e8', T: 4, d: '4초 동안 차를 뚫고 지나가요' },
    c: { nm: '대포알', col: '#8e9aaa', T: 0, d: '앞쪽 차에게 대포알을 쐈어요' },
    i: { nm: '투명', col: '#f2e9d8', T: 5, d: '5초 동안 다른 사람 눈에 안 보여요' },
  };
  const ITEM_KEYS = Object.keys(ITEMS);
  /* what it does to you when someone else uses it on you */
  const VICTIM = { r: '4초 동안 조작이 반대로!', z: '5초 동안 작고 가벼워져요', u: '2초 동안 얼어서 못 움직여요', g: '갈고리에 끌려가요!', o: '발밑이 미끄러워요!', k: '끈적해서 느려져요' };
  const RV_T = 4, SK_T = 3.5, OIL_T = 7, OIL_R = 26, WAVE_R = 78, BLINK = 54, GIANT = 1.45, AIR_T = 0.42, SMALL = 0.7;
  const MAGN_R = 95, TW_R = 20, XB_R = 52, CB_V = 240, SPRING_V = 185;
  const rad = (c) => CR * (c.gi > 0 ? GIANT : 1) * (c.zs > 0 ? SMALL : 1);
  const frac = (v) => v - Math.floor(v);
  const smooth = (v) => { v = clamp(v, 0, 1); return v * v * (3 - 2 * v); };

  /* ---- time-driven arena mechanics (functions of W.t and W.sd only, so guests can redraw them) ---- */
  const VENTS = [[0, 0], [50, 0], [0, 50], [-50, 0], [0, -50]], VENT_R = 32, VENT_P = 6.5;
  function ventState(W, k) { // 0 idle, 1 glowing (warning), 2 erupting
    const ph = frac((W.t + (hash32(W.sd, k + 200) % 650) / 100) / VENT_P) * VENT_P;
    if (W.t < 3.5) return 0;
    if (ph > VENT_P - 0.45) return 2;
    if (ph > VENT_P - 1.55) return 1;
    return 0;
  }
  const MAGS = [[0, -60], [52, 30], [-52, 30]], MAG_R = 72, MAG_P = 4.5, MAG_WARN = 0.9;
  function magState(W) { // which pad, warming up?
    const sl = Math.floor(W.t / MAG_P), k = (sl + (W.sd % 3)) % 3;
    return { k, warn: W.t - sl * MAG_P < MAG_WARN, on: W.t >= 2 };
  }
  const PADS = [[0, 0, 13], [35, 35, 12], [-35, 35, 12], [35, -35, 12], [-35, -35, 12]];
  const PL_HS = 44, PL_D0 = 41, PL_D1 = 68, PL_P = 10;
  function platD(W) { return PL_D0 + (PL_D1 - PL_D0) * (0.5 - 0.5 * Math.cos(Math.PI * 2 * Math.max(0, W.t - 2) / PL_P)); }
  function platV(W) { return W.t < 2 ? 0 : (PL_D1 - PL_D0) * 0.5 * Math.sin(Math.PI * 2 * (W.t - 2) / PL_P) * Math.PI * 2 / PL_P; }
  const BH_R = 13;
  function jellies(W) { // [x, y, r, vx, vy]
    const out = [];
    for (let k = 0; k < 4; k++) {
      const p = (hash32(W.sd, k + 300) % 628) / 100, q = (hash32(W.sd, k + 310) % 628) / 100, a = 0.33 + k * 0.05, b = 0.27 + ((k * 7) % 4) * 0.04;
      out.push([64 * Math.sin(W.t * a + p), 64 * Math.sin(W.t * b + q), 11, 64 * a * Math.cos(W.t * a + p), 64 * b * Math.cos(W.t * b + q)]);
    }
    return out;
  }
  const TOP_R = 17;
  function topOf(W) { // [x, y, r, vx, vy, spin dir]
    const p = (hash32(W.sd, 401) % 628) / 100, a = 0.37, b = 0.29;
    return [34 * Math.sin(W.t * a + p), 34 * Math.sin(W.t * b), TOP_R, 34 * a * Math.cos(W.t * a + p), 34 * b * Math.cos(W.t * b), hash32(W.sd, 402) & 1 ? 1 : -1];
  }
  const LZ_ON = 4, LZ_OFF = 2.2, LZ_WARN = 0.9, LZ_W = 0.75;
  function laserOf(W) { // {on, warn, ang, w (rad/s)}
    const dir = hash32(W.sd, 501) & 1 ? 1 : -1, per = LZ_ON + LZ_OFF;
    const ph = W.t < 3 ? -1 : frac((W.t - 3) / per) * per;
    return { on: ph >= LZ_OFF, warn: ph >= LZ_OFF - LZ_WARN && ph < LZ_OFF, ang: dir * W.t * LZ_W + (hash32(W.sd, 502) % 314) / 100, w: dir * LZ_W };
  }
  const FL_LEN = 40, FL_TH = 4, FL_P = 3.2;
  function flipAng(ph) { // 0 rest → 1 up
    if (ph < 0.1) return ph / 0.1;
    if (ph < 0.35) return 1;
    if (ph < 0.7) return 1 - (ph - 0.35) / 0.35;
    return 0;
  }
  function flippers(W) { // [px, py, ang, omega, len]
    const out = [];
    for (const sy of [1, -1]) {
      const ph = W.t < 3 ? 9 : frac((W.t + (sy < 0 ? FL_P / 2 : 0)) / FL_P) * FL_P;
      const u = flipAng(ph), du = (flipAng(ph + 0.01) - u) / 0.01;
      for (const sx of [-1, 1]) {
        const rest = 0.5, up = -0.45; // angle measured from the inward horizontal, + = toward the near edge
        const a0 = rest + (up - rest) * u, w0 = (up - rest) * du;
        // inward direction is -sx; flip toward edge sign sy
        const base = sx < 0 ? 0 : Math.PI, s = (sx < 0 ? 1 : -1) * sy;
        out.push([sx * 66, sy * 84, base + s * a0, s * w0, FL_LEN]);
      }
    }
    return out;
  }
  const DK_P = 11;
  function darkOf(W) { // 0 lit, 1 flicker warning, 2 dark
    if (W.t < 4) return 0;
    const ph = frac((W.t - 4) / DK_P) * DK_P;
    if (ph > 6.2 && ph < 7.2) return 1;
    if (ph >= 7.2 && ph < 10.2) return 2;
    return 0;
  }
  const HOLE_CELL = 30, HOLE_N = 3; // cells -3..3

  function holeCells(sd) { // deterministic fall order of the floor tiles for this round
    const cells = [];
    for (let i = -HOLE_N; i <= HOLE_N; i++) for (let j = -HOLE_N; j <= HOLE_N; j++) {
      const cx = i * HOLE_CELL, cy = j * HOLE_CELL;
      if (Math.hypot(cx, cy) > 100 - HOLE_CELL * 0.4) continue;
      if (i === 0 && j === 0) continue; // the centre stays
      cells.push([i, j, hash32(sd, (i + 8) * 31 + j + 8)]);
    }
    cells.sort((a, b) => a[2] - b[2]);
    return cells.slice(0, Math.round(cells.length * 0.7)).map((c) => [c[0], c[1]]);
  }
  function trapCells(sd) { // 12 trapdoors that open and close in turn
    const cells = [];
    for (let i = -HOLE_N; i <= HOLE_N; i++) for (let j = -HOLE_N; j <= HOLE_N; j++) {
      if (Math.hypot(i * HOLE_CELL, j * HOLE_CELL) > 106 - HOLE_CELL * 0.4) continue;
      if (i === 0 && j === 0) continue;
      cells.push([i, j, hash32(sd, (i + 8) * 37 + j + 5)]);
    }
    cells.sort((a, b) => a[2] - b[2]);
    return cells.slice(0, TRAP_N).map((c) => [c[0], c[1]]);
  }
  const TRAP_N = 12, TRAP_P = 9, TRAP_WARN = 1.4, TRAP_OPEN = 2.6;
  const HOLE_T0 = 5, HOLE_DT = 2.2, HOLE_WARN = 1.6, HOLE_HOLD = 6;
  function holeState(W, i, j) { // 0 floor, 1 warning, 2 hole
    const k = W.hidx[(i + 8) * 32 + j + 8];
    if (k == null) return 0;
    if (W.A.trap) {
      const lt = W.t - 3 - k * TRAP_P / TRAP_N; // each door starts its cycle (with a warning) in turn
      if (lt < 0) return 0;
      const ph = frac(lt / TRAP_P) * TRAP_P;
      return ph < TRAP_WARN ? 1 : ph < TRAP_WARN + TRAP_OPEN ? 2 : 0;
    }
    const t0 = HOLE_T0 + k * HOLE_DT, cyc = HOLE_T0 + W.hn * HOLE_DT + HOLE_HOLD, t = frac(W.t / cyc) * cyc; // every tile comes back after a while
    if (t >= t0 + HOLE_WARN) return 2;
    if (t >= t0) return 1;
    return 0;
  }
  function windAt(W, t) { // returns {w: accel x (signed), warn: dir or 0}
    const per = 7, k = Math.floor(t / per), ph = t - k * per;
    const dir = (hash32(W.sd, k + 101) & 1) ? 1 : -1;
    if (t < 4) return { w: 0, warn: 0, dir };
    if (ph < 2.2) return { w: 0, warn: 0, dir };
    if (ph < 3.4) return { w: 0, warn: dir, dir };
    if (ph < 6.4) { const e = Math.min(1, (ph - 3.4) * 3, (6.4 - ph) * 3); return { w: 135 * dir * e, warn: 0, dir }; }
    return { w: 0, warn: 0, dir };
  }
  /* ---- round 12 arena mechanics (also pure functions of W.t and W.sd) ---- */
  function perm(sd, n, salt) { const a = []; for (let k = 0; k < n; k++) a.push([k, hash32(sd, k + salt)]); a.sort((p, q) => p[1] - q[1]); const o = []; a.forEach((p, i) => { o[p[0]] = i; }); return o; }
  const PS_YS = [-72, 0, 72], RAM_H = 15, RAM_D = 62, PS_P = 7.2;
  function pistons(W) { // [side, yc, ext, ext speed, state 0 idle / 1 warn / 2 moving or out]
    const ord = W.psp || (W.psp = perm(W.sd, 6, 640)), out = [];
    for (let k = 0; k < 6; k++) {
      const side = k < 3 ? -1 : 1, yc = PS_YS[k % 3], lt = W.t - 3 - ord[k] * (PS_P / 6);
      let e = 0, ve = 0, s = 0;
      if (lt >= 0) {
        const ph = frac(lt / PS_P) * PS_P;
        if (ph < 0.9) s = 1;
        else if (ph < 1.25) { s = 2; e = RAM_D * (ph - 0.9) / 0.35; ve = RAM_D / 0.35; }
        else if (ph < 1.7) { s = 2; e = RAM_D; }
        else if (ph < 2.5) { s = 2; e = RAM_D * (1 - (ph - 1.7) / 0.8); ve = -RAM_D / 0.8; }
      }
      out.push([side, yc, e, ve, s]);
    }
    return out;
  }
  const TIDE_P = 13, TIDE_A = 34;
  function tideU(W, t) { // u: 0 low … 1 high tide, warn: lava is about to rise / rising
    const lt = t - 5;
    if (lt < 0) return { u: 0, warn: 0 };
    const ph = frac(lt / TIDE_P) * TIDE_P;
    if (ph < 1.6) return { u: 0, warn: 1 };
    if (ph < 4.1) return { u: smooth((ph - 1.6) / 2.5), warn: 1 };
    if (ph < 7.1) return { u: 1, warn: 0 };
    if (ph < 9.1) return { u: 1 - smooth((ph - 7.1) / 2), warn: 0 };
    return { u: 0, warn: 0 };
  }
  const FAN_P = 6.5, FAN_W = 30, FAN_A = 185;
  function fanAng(W, k) { return (hash32(W.sd, 600) % 628) / 100 + k * Math.PI * 2 / 3; }
  function fanState(W) { // {k: fan index, warn, e: blow strength 0..1}
    if (W.t < 3) return { k: -1, warn: 0, e: 0 };
    const sl = Math.floor((W.t - 3) / FAN_P), ph = W.t - 3 - sl * FAN_P, k = (sl + hash32(W.sd, 601) % 3) % 3;
    if (ph < 1.3) return { k, warn: 1, e: 0 };
    if (ph < 4.8) return { k, warn: 0, e: Math.min(1, (ph - 1.3) * 3, (4.8 - ph) * 3) };
    return { k: -1, warn: 0, e: 0 };
  }
  const ARM_L = 72, ARM_TH = 4.5;
  function armsOf(W) { // windmill: three arms swinging back and forth while drifting round [px, py, ang, omega, len]
    const a0 = (hash32(W.sd, 610) % 628) / 100, t = W.t;
    const base = a0 + 0.25 * t + 2.4 * Math.sin(Math.PI * t / 9), om = 0.25 + 2.4 * (Math.PI / 9) * Math.cos(Math.PI * t / 9);
    return [0, 1, 2].map((k) => [0, 0, base + k * Math.PI * 2 / 3, om, ARM_L]);
  }
  const DN_PIT = 28, DN_MID = 64, DN_WI = 0.9, DN_WO = -0.6;
  const POPS = [[0, 0]].concat([0, 1, 2, 3, 4, 5].map((k) => [Math.round(Math.cos(k * Math.PI / 3 + Math.PI / 6) * 56), Math.round(Math.sin(k * Math.PI / 3 + Math.PI / 6) * 56)])), PO_R = 11, PO_P = 7;
  function popState(W, k) { // {s: 0 down / 1 warn / 2 up, age: time since it rose}
    const lt = W.t - 3 - (W.pop || (W.pop = perm(W.sd, POPS.length, 660)))[k] * 1.0;
    if (lt < 0) return { s: 0, age: 0 };
    const ph = frac(lt / PO_P) * PO_P;
    if (ph < 1) return { s: 1, age: 0 };
    if (ph < 4.2) return { s: 2, age: ph - 1 };
    return { s: 0, age: 0 };
  }
  const GUST_P = 5.5, GUST_A = 125;
  function gustAt(W, t) { // {x, y accel, warn, an (direction), e}
    if (t < 3) return { x: 0, y: 0, warn: 0, an: 0, e: 0 };
    const sl = Math.floor((t - 3) / GUST_P), ph = t - 3 - sl * GUST_P, an = hash32(W.sd, sl + 700) / 4294967296 * Math.PI * 2;
    if (ph < 1.1) return { x: 0, y: 0, warn: 1, an, e: 0 };
    if (ph < 3.4) { const e = Math.min(1, (ph - 1.1) * 3, (3.4 - ph) * 3); return { x: Math.cos(an) * GUST_A * e, y: Math.sin(an) * GUST_A * e, warn: 0, an, e }; }
    return { x: 0, y: 0, warn: 0, an, e: 0 };
  }
  const X_L = 118, X_W = 22, X_P = 42;
  const QK_T0 = 4, QK_P = 6.5, QK_WARN = 1.3, QK_V = 62;
  const quakeDir = (W, k) => (hash32(W.sd, k + 900) % 8) * Math.PI / 4;
  function quakeOf(W) { // {warn: a jolt is coming, an: its direction, shake: 0..1 right after a jolt}
    if (W.t < QK_T0) return { warn: 0, an: 0, shake: 0 };
    const s = (W.t - QK_T0) / QK_P, k = Math.floor(s), ph = (s - k) * QK_P;
    return { warn: ph > QK_P - QK_WARN ? 1 : 0, an: quakeDir(W, k + 1), shake: k >= 1 && ph < 0.6 ? 1 - ph / 0.6 : 0 };
  }
  const BB_T0 = 4, BB_P = 2.0, BB_FUSE = 2.4, BB_R = 40;
  function bombPos(W, b) { const u1 = hash32(W.sd, b * 2 + 1000) / 4294967296, u2 = hash32(W.sd, b * 2 + 1001) / 4294967296, r = 84 * Math.sqrt(u1); return [Math.cos(u2 * 6.2832) * r, Math.sin(u2 * 6.2832) * r]; }
  function bombsOf(W) { // falling bombs [x, y, fuse progress 0..1, index]
    const out = [];
    if (W.t < BB_T0) return out;
    const b1 = Math.floor((W.t - BB_T0) / BB_P);
    for (let b = Math.max(0, b1 - 2); b <= b1; b++) { const ta = BB_T0 + b * BB_P; if (W.t >= ta && W.t < ta + BB_FUSE) { const p = bombPos(W, b); out.push([p[0], p[1], (W.t - ta) / BB_FUSE, b]); } }
    return out;
  }
  const WR_R = 15, WR_A = 90, WR_W = Math.PI * 2 / 5.2;
  function wreckOf(W) { // [x, y, r, vx, vy]
    const t = W.t, an = (hash32(W.sd, 620) % 628) / 100 + 0.22 * t, amp = WR_A * smooth((t - 1.5) / 2.5);
    const s = amp * Math.sin(WR_W * t), ds = amp * WR_W * Math.cos(WR_W * t), ca = Math.cos(an), sa = Math.sin(an);
    return [ca * s, sa * s, WR_R, ca * ds - sa * s * 0.22, sa * ds + ca * s * 0.22];
  }
  /* ---- round 13 arena mechanics ---- */
  const FN_GAP = 1.15, FN_W = 0.32;
  function fenceGaps(W, t) { const a = (hash32(W.sd, 1100) % 628) / 100 + (hash32(W.sd, 1101) & 1 ? 1 : -1) * FN_W * t; return [a, a + Math.PI]; }
  function inGap(W, an, t, extra) { for (const g of fenceGaps(W, t)) if (Math.abs(wrapA(an - g)) < FN_GAP / 2 + extra) return true; return false; }
  const SL_A = 115;
  function slopeAng(W, t) { return (hash32(W.sd, 1110) % 628) / 100 + (hash32(W.sd, 1111) & 1 ? 1 : -1) * 0.3 * t; }
  const PT_R = 10;
  function portalsOf(W) { // [x, y, pair, end]
    const out = [], a0 = (hash32(W.sd, 1120) % 628) / 100;
    for (let p = 0; p < 2; p++) { const th = a0 + p * Math.PI / 2 + 0.18 * W.t; for (let e = 0; e < 2; e++) out.push([Math.cos(th + e * Math.PI) * 58, Math.sin(th + e * Math.PI) * 58, p, e]); }
    return out;
  }
  const BS_R = 12, BS_P = 7, BS_V = 200;
  function boostDir(W, k, t) { // pads at radius 58; every 7 s all arrows turn 90°. warn = about to turn
    const ph = Math.floor(t / BS_P), base = k * Math.PI / 3;
    return { an: base + Math.PI / 2 + ((ph + (hash32(W.sd, 1130) % 4)) % 4) * Math.PI / 2, warn: t - ph * BS_P > BS_P - 1.2 };
  }
  const BS_POS = [0, 1, 2, 3, 4, 5].map((k) => [Math.cos(k * Math.PI / 3) * 58, Math.sin(k * Math.PI / 3) * 58]);
  const LG_P = 3.6, LG_T0 = 3, LG_WARN = 1.2, LG_L = 30, LG_R = 8, LG_V = 95;
  function logsOf(W) { // [x, y, dir, state 1 warn / 2 rolling]
    const out = [], hh = W.A.hh, k1 = Math.floor((W.t - LG_T0) / LG_P);
    for (let k = Math.max(0, k1 - 3); k <= k1; k++) {
      const tk = LG_T0 + k * LG_P + LG_WARN, dir = k % 2 ? 1 : -1, x = (hash32(W.sd, k + 1140) % 120) - 60;
      if (W.t < tk - LG_WARN) continue;
      if (W.t < tk) { out.push([x, -dir * (hh + LG_R + 4), dir, 1]); continue; }
      const y = -dir * (hh + LG_R + 4) + dir * LG_V * (W.t - tk);
      if (Math.abs(y) <= hh + LG_R + 6) out.push([x, y, dir, 2]);
    }
    return out;
  }
  const RF_P = 9, RF_W = 14;
  function riftOf(W, t) { // {an, w (half width of the crack), warn}
    if (t < 3) return { an: 0, w: 0, warn: 0 };
    const k = Math.floor((t - 3) / RF_P), ph = t - 3 - k * RF_P, an = (hash32(W.sd, k + 1150) % 314) / 100;
    if (ph < 1.5) return { an, w: 0, warn: 1 };
    if (ph < 2.3) return { an, w: RF_W * (ph - 1.5) / 0.8, warn: 1 };
    if (ph < 4.8) return { an, w: RF_W, warn: 0 };
    if (ph < 5.6) return { an, w: RF_W * (1 - (ph - 4.8) / 0.8), warn: 0 };
    return { an, w: 0, warn: 0 };
  }
  const WV_P = 7.5, WV_T0 = 3, WV_WARN = 1.2, WV_V = 85, WV_H = 14, WV_PUSH = 55;
  function waveOf(W) { // {x (band centre) or null, dir, warn: dir of the coming wave or 0}
    if (W.t < WV_T0) return { x: null, dir: 1, warn: 0 };
    const k = Math.floor((W.t - WV_T0) / WV_P), ph = W.t - WV_T0 - k * WV_P, dir = k % 2 ? -1 : 1, hw = W.A.hw;
    if (ph < WV_WARN) return { x: null, dir, warn: dir };
    const x = -dir * (hw + WV_H + 2) + dir * WV_V * (ph - WV_WARN);
    return Math.abs(x) < hw + WV_H + 4 ? { x, dir, warn: 0 } : { x: null, dir, warn: 0 };
  }
  function sudden() { return 1; } // (the old round-mode squeeze; a match now runs on a clock and nothing shrinks for good)
  const ISL_P = 46;
  function islandU(t) { // sand island: shrinks for 26 s, stays small, then the tide goes out again
    const ph = frac(t / ISL_P) * ISL_P;
    return ph < 6 ? 0 : ph < 32 ? (ph - 6) / 26 : ph < 38 ? 1 : 1 - smooth((ph - 38) / 6);
  }
  function curR(W, t) {
    const A = W.A;
    let R = A.R;
    if (A.shrink) R = A.R - (A.R - 40) * islandU(W.t);
    if (A.tide) R = A.R - TIDE_A * tideU(W, t == null ? W.t : t).u;
    return R * (A.shrink ? 1 : sudden(W));
  }
  /* distance from (x, y) to the nearest edge or hole (negative = off the floor). warnHoles: treat warning tiles as holes */
  function edgeDist(W, x, y, warnHoles) {
    const A = W.A;
    let d;
    if (A.shape === 'c') {
      const r = Math.hypot(x, y);
      d = curR(W) - r;
      if (warnHoles && A.tide) d = Math.min(d, curR(W, W.t + 1.0) - r); // the lava is about to come in
      if (A.donut) d = Math.min(d, r - DN_PIT);
      if (A.fence) { const an = Math.atan2(y, x); if (!inGap(W, an, W.t, 0) && !(warnHoles && inGap(W, an, W.t + 0.8, 0.12))) d = Math.max(d, 30); }
      if (A.rift) { const z = riftOf(W, W.t), w = warnHoles && (z.warn || z.w > 0) ? RF_W + 2 : z.w; if (w > 0) d = Math.min(d, Math.abs(-Math.sin(z.an) * x + Math.cos(z.an) * y) - w); }
    } else if (A.shape === 'x') { // a plaza with four narrow bridges
      const s = sudden(W), ax = Math.abs(x), ay = Math.abs(y);
      d = Math.max(Math.min(X_L * s - ax, X_W - ay), Math.min(X_W - ax, X_L * s - ay), Math.min(X_P - ax, X_P - ay));
    } else if (A.shape === 'p') { // union of four drifting square platforms
      const hs = PL_HS * sudden(W);
      const one = (pd) => {
        if (pd <= hs) return pd + hs - Math.max(Math.abs(x), Math.abs(y)); // joined: one big square
        let e = -1e9;
        for (const sx of [-1, 1]) for (const sy of [-1, 1]) e = Math.max(e, Math.min(hs - Math.abs(x - sx * pd), hs - Math.abs(y - sy * pd)));
        return e;
      };
      d = one(platD(W));
      if (warnHoles) { const t0 = W.t; W.t = t0 + 0.9; d = Math.min(d, one(platD(W))); W.t = t0; } // AI & spawns: mind the gap that is about to open
    } else if (A.walls) d = A.hh - Math.abs(y); // the long sides are rubber walls
    else { const s = sudden(W); d = Math.min(A.hw * s - Math.abs(x), A.hh * s - Math.abs(y)); }
    if (A.bhole) d = Math.min(d, Math.hypot(x, y) - BH_R);
    if (A.holes || A.trap) {
      const ci = Math.round(x / HOLE_CELL), cj = Math.round(y / HOLE_CELL);
      for (let i = ci - 1; i <= ci + 1; i++) for (let j = cj - 1; j <= cj + 1; j++) {
        const hs = holeState(W, i, j);
        if (hs === 2 || (warnHoles && hs === 1)) {
          const h2 = HOLE_CELL / 2, dx = Math.abs(x - i * HOLE_CELL) - h2, dy = Math.abs(y - j * HOLE_CELL) - h2;
          const out = dx > 0 || dy > 0 ? Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) : Math.max(dx, dy);
          d = Math.min(d, out);
        }
      }
    }
    return d;
  }
  /* surface at (x, y): surface velocity (vx, vy) the floor drags cars toward, extra accel (ax, ay), friction, grip */
  function surface(W, x, y) {
    const A = W.A;
    const o = { vx: 0, vy: 0, ax: 0, ay: 0, fr: A.fr, grip: A.grip };
    if (A.spin) { const w = A.spin; o.vx = -w * y; o.vy = w * x; o.ax = w * w * x * 0.55; o.ay = w * w * y * 0.55; }
    if (A.belts) { const band = Math.floor((y + A.hh) / (A.hh / 2)); o.vx = (band % 2 ? -1 : 1) * 72; }
    if (A.wind) o.ax += W.wind;
    if (A.tilt) o.ay += 170 * Math.sin(W.th);
    if (A.hill) { const d = Math.hypot(x, y); if (d < A.hill && d > 0.5) { const a = 175 * Math.sin(Math.PI * d / A.hill); o.ax += x / d * a; o.ay += y / d * a; } }
    if (A.vents) for (let k = 0; k < VENTS.length; k++) {
      if (ventState(W, k) !== 2) continue;
      const dx = x - VENTS[k][0], dy = y - VENTS[k][1], d = Math.hypot(dx, dy);
      if (d < VENT_R) { const a = 1100 * (1 - d / VENT_R) + 160, ux = d > 0.5 ? dx / d : 1, uy = d > 0.5 ? dy / d : 0; o.ax += ux * a; o.ay += uy * a; }
    }
    if (A.mag) {
      const m = magState(W);
      if (m.on && !m.warn) { const p = MAGS[m.k], dx = p[0] - x, dy = p[1] - y, d = Math.hypot(dx, dy); if (d < MAG_R && d > 1) { const a = 430 * (1 - d / MAG_R) * Math.min(1, d / 6); o.ax += dx / d * a; o.ay += dy / d * a; } }
    }
    if (A.bhole) {
      const d = Math.hypot(x, y);
      if (d > 0.5) { const a = (8600 / (d + 24)) * (2 - sudden(W)); o.ax -= x / d * a; o.ay -= y / d * a; const sw = Math.min(40, 1400 / (d + 10)); o.vx += -y / d * sw; o.vy += x / d * sw; }
    }
    if (A.plat) { const v = platV(W); o.vx += Math.sign(x) * v; o.vy += Math.sign(y) * v; }
    if (A.fans) {
      const f = W.fan || fanState(W);
      if (f.e > 0) {
        const an = fanAng(W, f.k), dx = -Math.cos(an), dy = -Math.sin(an), pp = Math.abs(-dy * x + dx * y);
        if (pp < FAN_W) { const a = FAN_A * f.e * (1 - 0.4 * pp / FAN_W); o.ax += dx * a; o.ay += dy * a; }
      }
    }
    if (A.tilt2) { o.ax += 160 * Math.sin(W.th); o.ay += 160 * Math.sin(W.th2 || 0); }
    if (A.donut) { const r = Math.hypot(x, y), w = r < DN_MID ? DN_WI : DN_WO; o.vx = -w * y; o.vy = w * x; o.ax += w * w * x * 0.3; o.ay += w * w * y * 0.3; }
    if (A.gust) { o.ax += W.gx || 0; o.ay += W.gy || 0; }
    if (A.slope) { const an = slopeAng(W, W.t); o.ax += Math.cos(an) * SL_A; o.ay += Math.sin(an) * SL_A; }
    if (A.boost) for (let k = 0; k < 6; k++) { const p = BS_POS[k]; if (Math.hypot(x - p[0], y - p[1]) < BS_R) { const an = boostDir(W, k, W.t).an; o.vx = Math.cos(an) * BS_V; o.vy = Math.sin(an) * BS_V; o.fr = 4.5; break; } }
    if (A.wave) { const wv = W.wv || waveOf(W); if (wv.x != null && Math.abs(x - wv.x) < WV_H) { o.vx += wv.dir * WV_PUSH; o.fr = Math.max(o.fr, 3); } }
    if (W.oil && Math.hypot(x - W.oil.x, y - W.oil.y) < OIL_R) { o.fr = 0.25; o.grip = 0.3; }
    return o;
  }
  function spawnPos(A, n, s) {
    const an = -Math.PI / 2 + (s / n) * Math.PI * 2 + (n === 2 ? 0 : Math.PI / n);
    let x, y;
    if (A.plat) { // a platform each (5th/6th car shares)
      const k = n === 2 ? (s ? 0 : 2) : s % 4, cs = [[-1, -1], [1, -1], [1, 1], [-1, 1]][k], off = s >= 4 ? 14 : 0;
      x = cs[0] * (PL_D0 + off); y = cs[1] * (PL_D0 - off);
      return { x, y, a: Math.atan2(-y, -x) };
    }
    if (A.belts) { // a column down the middle: every car is the same distance from the edge its belt runs to
      y = n === 1 ? 0 : -A.hh * 0.7 + (s / (n - 1)) * A.hh * 1.4; x = (s % 2 ? 1 : -1) * 6;
      return { x, y, a: y > 0 ? -Math.PI / 2 : Math.PI / 2 };
    }
    if (A.shape === 'x') { // out on the bridges (5th/6th car further in)
      const k = n === 2 ? s * 2 : s % 4, d = s >= 4 ? 52 : 82, dirs = [[0, -1], [1, 0], [0, 1], [-1, 0]][k];
      x = dirs[0] * d; y = dirs[1] * d;
      return { x, y, a: Math.atan2(-y, -x) };
    }
    if (A.shape === 'c') { const r = A.R * (A.posts ? 0.78 : A.vents || A.pads || A.pop ? 0.8 : A.arms ? 0.85 : A.donut ? 0.72 : A.bhole ? 0.62 : 0.55); x = Math.cos(an) * r; y = Math.sin(an) * r; }
    else { x = Math.cos(an) * A.hw * 0.55; y = Math.sin(an) * A.hh * 0.55; }
    if (A.hill) { x *= 1.25; y *= 1.25; }
    return { x, y, a: Math.atan2(-y, -x) };
  }
  function newWorld(ar, sd, n) {
    const A = ARENAS[clamp(ar | 0, 0, ARENAS.length - 1)];
    const W = { A, ar: ar | 0, sd: sd >>> 0, n, t: 0, th: 0, thv: 0, th2: 0, thv2: 0, wind: 0, gx: 0, gy: 0, fan: null, item: null, itemT: ITEM_EVERY * 0.6, cars: [], hidx: {}, bumps: 0, acc: 0, oil: null, tw: null, xb: null, cb: null };
    if (A.holes) holeCells(W.sd).forEach((c, k, all) => { W.hidx[(c[0] + 8) * 32 + c[1] + 8] = k; W.hn = all.length; });
    if (A.trap) trapCells(W.sd).forEach((c, k) => { W.hidx[(c[0] + 8) * 32 + c[1] + 8] = k; });
    for (let s = 0; s < n; s++) {
      const p = spawnPos(A, n, s);
      W.cars.push(Object.assign({ seat: s, x: p.x, y: p.y, vx: 0, vy: 0, a: p.a, alive: true, f: 0, cd: 0.6, dt: 0, j: 0, jc: 0, dl: 0, lh: -1, lht: -9, rs: 0, inv: 0, pt: 0, by: -1 }, fx0()));
    }
    tickMech(W);
    return W;
  }
  /* timed effects on a car: field → item key (badge order) */
  const FX = [['hv', 'h'], ['sh', 's'], ['gi', 'b'], ['bk', 't'], ['sp', 'p'], ['rf', 'm'], ['mg', 'n'], ['tb', 'f'], ['gh', 'y'], ['iv', 'i'], ['rv', 'r'], ['sk', 'k'], ['zs', 'z'], ['fz', 'u']];
  function fx0() { const o = {}; for (const [f] of FX) o[f] = 0; return o; }
  /* per-step cached mechanics (wind, gusts, the active fan) — derived from W.t, so guests compute the same */
  function tickMech(W) {
    const A = W.A;
    if (A.wind) W.wind = windAt(W, W.t).w;
    if (A.gust) { const g = gustAt(W, W.t); W.gx = g.x; W.gy = g.y; }
    if (A.fans) W.fan = fanState(W);
    if (A.wave) W.wv = waveOf(W);
  }
  const flagsOf = (q) => { let f = (q.alive ? 1 : 0) | (q.inv > 0 ? 2 : 0) | (q.dt > 0 ? 8 : 0) | (q.j > 0 ? 512 : 0); FX.forEach(([k], i) => { if (q[k] > 0) f |= 1 << (i + 10); }); return f; };
  function massOf(c) { return (c.hv > 0 ? 2.3 : 1) * (c.dt > 0 ? 1.6 : 1) * (c.sh > 0 ? 4 : 1) * (c.gi > 0 ? 2 : 1) * (c.zs > 0 ? 0.55 : 1) * (c.fz > 0 ? 1.3 : 1); }
  /* inp: {x, y (stick, |v| ≤ 1), t (turn −1/0/1), m ('s' | 't'), d (dash counter)} */
  function stepCar(W, c, inp, h, hooks) {
    if (!c.alive) return;
    if (c.f > 0) { c.f += h; c.x += c.vx * h; c.y += c.vy * h; c.vx *= 0.985; c.vy *= 0.985; return; }
    const i = inp || {};
    const tick = () => {
      if (c.cd > 0) c.cd -= h * (c.tb > 0 ? 2.2 : 1);
      if (c.dt > 0) c.dt -= h;
      for (const [f] of FX) if (c[f] > 0) c[f] -= h;
      if (c.jc > 0) c.jc -= h;
      if (c.inv > 0) c.inv -= h;
      if (c.pt > 0) c.pt -= h;
    };
    if (c.j > 0) { // airborne off a trampoline: ballistic, no grip
      c.x += c.vx * h; c.y += c.vy * h; c.vx *= 0.997; c.vy *= 0.997;
      c.j -= h; if (c.j <= 0) { c.j = 0; c.jc = 0.35; if (hooks && hooks.land) hooks.land(c); }
      tick(); return;
    }
    const S = surface(W, c.x, c.y);
    const rvs = c.rv > 0 ? -1 : 1;
    let tx = 0, ty = 0;
    if (c.fz > 0) { // 꽁꽁: an ice block — no steering, no dash, slides
      c.dl = i.d | 0;
      const k = Math.exp(-0.45 * h);
      c.vx = S.vx * 0.3 + (c.vx - S.vx * 0.3) * k + S.ax * h; c.vy = S.vy * 0.3 + (c.vy - S.vy * 0.3) * k + S.ay * h;
      c.x += c.vx * h; c.y += c.vy * h;
      tick(); return;
    }
    if (i.m === 't') {
      c.a = wrapA(c.a + clamp(+i.t || 0, -1, 1) * rvs * 3.3 * h);
      tx = Math.cos(c.a) * 0.9; ty = Math.sin(c.a) * 0.9;
    } else {
      tx = clamp(+i.x || 0, -1, 1) * rvs; ty = clamp(+i.y || 0, -1, 1) * rvs;
      const m = Math.hypot(tx, ty);
      if (m > 1) { tx /= m; ty /= m; }
      if (m > 0.15) { const d = wrapA(Math.atan2(ty, tx) - c.a); c.a = wrapA(c.a + clamp(d, -11 * h, 11 * h)); }
    }
    // dash: a new press (counter changed) fires when the cooldown is ready
    const dl = i.d | 0;
    if (dl !== c.dl) {
      c.dl = dl;
      if (c.cd <= 0) {
        let dx = Math.cos(c.a), dy = Math.sin(c.a);
        if (i.m !== 't' && Math.hypot(tx, ty) > 0.25) { const m = Math.hypot(tx, ty); dx = tx / m; dy = ty / m; c.a = Math.atan2(dy, dx); }
        if (c.bk > 0) { // 순간 이동 charge: blink instead of a dash
          const ox = c.x, oy = c.y;
          c.x += dx * BLINK; c.y += dy * BLINK; c.vx = c.vx * 0.4 + dx * 60; c.vy = c.vy * 0.4 + dy * 60;
          c.bk = 0; c.cd = DASH_CD;
          if (hooks && hooks.blink) hooks.blink(c, ox, oy);
        } else if (c.sp > 0) { // 스프링 charge: hop over cars and gaps
          const v = SPRING_V;
          c.vx = dx * v + c.vx * 0.15; c.vy = dy * v + c.vy * 0.15; c.j = AIR_T; c.dt = 0; c.sp = 0; c.cd = DASH_CD;
          if (hooks && hooks.jump) hooks.jump(c);
          tick(); return;
        } else {
          const dk = c.sk > 0 ? 0.55 : 1;
          c.vx += dx * DASH * dk; c.vy += dy * DASH * dk; c.cd = DASH_CD; c.dt = DASH_T;
          if (hooks && hooks.dash) hooks.dash(c);
        }
      }
    }
    const acc = ACC * S.grip * (c.hv > 0 ? 0.82 : 1) * (c.sk > 0 ? 0.45 : 1) * (c.tb > 0 ? 1.35 : 1);
    c.vx += (tx * acc + S.ax) * h; c.vy += (ty * acc + S.ay) * h;
    const k = Math.exp(-S.fr * (c.sk > 0 ? 1.8 : 1) * h);
    c.vx = S.vx + (c.vx - S.vx) * k; c.vy = S.vy + (c.vy - S.vy) * k;
    const sp = Math.hypot(c.vx, c.vy), cap = (c.dt > 0 ? VMAX + DASH : VMAX) * (c.sk > 0 ? 0.6 : 1) * (c.tb > 0 ? 1.2 : 1);
    if (sp > cap) { c.vx *= cap / sp; c.vy *= cap / sp; }
    c.x += c.vx * h; c.y += c.vy * h;
    // trampoline pads launch the car the way it was going
    if (W.A.pads && !(c.jc > 0) && W.t > 0.2) for (const p of PADS) {
      if (Math.hypot(c.x - p[0], c.y - p[1]) > p[2]) continue;
      let s2 = Math.hypot(c.vx, c.vy), ux = c.vx / (s2 || 1), uy = c.vy / (s2 || 1);
      if (s2 < 20) { ux = Math.cos(c.a); uy = Math.sin(c.a); }
      const v = clamp(s2 * 1.15 + 60, 130, 210);
      c.vx = ux * v; c.vy = uy * v; c.j = AIR_T; c.dt = 0;
      if (hooks && hooks.jump) hooks.jump(c);
      break;
    }
    tick();
  }
  function collide(W, hooks) {
    const cs = W.cars;
    for (let i = 0; i < cs.length; i++) {
      const a = cs[i];
      if (!a.alive || a.f > 0 || a.j > 0) continue;
      for (let j = i + 1; j < cs.length; j++) {
        const b = cs[j];
        if (!b.alive || b.f > 0 || b.j > 0) continue;
        if (a.gh > 0 || b.gh > 0) continue; // 유령: passes through cars
        let dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
        const RR = rad(a) + rad(b);
        if (d >= RR) continue;
        if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
        const sa = a.inv > 0 && !(b.inv > 0), sb = b.inv > 0 && !(a.inv > 0); // 부활 보호막: can't be pushed, still pushes
        const nx = dx / d, ny = dy / d, ma = massOf(a), mb = massOf(b), ia = sa ? 0 : 1 / ma, ib = sb ? 0 : 1 / mb;
        const ov = RR - d;
        a.x -= nx * ov * ia / (ia + ib); a.y -= ny * ov * ia / (ia + ib);
        b.x += nx * ov * ib / (ia + ib); b.y += ny * ov * ib / (ia + ib);
        const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        if (vn < 0) {
          const fr = ally(W, a.seat, b.seat); // 팀전: bumping a teammate is soft and never counts as a hit
          const jm = (-(1 + EC) * vn + POP) / (ia + ib) * (fr ? 0.35 : 1);
          // 반사 갑옷: the armoured car barely feels it and the other one gets the push back, boosted
          const ra = a.rf > 0 && !(b.rf > 0), rb = b.rf > 0 && !(a.rf > 0);
          const ka = ra ? 0.25 : rb ? 1.9 : 1, kb = rb ? 0.25 : ra ? 1.9 : 1;
          a.vx -= jm * ia * nx * ka; a.vy -= jm * ia * ny * ka;
          b.vx += jm * ib * nx * kb; b.vy += jm * ib * ny * kb;
          if (!fr) { a.lh = b.seat; a.lht = W.t; b.lh = a.seat; b.lht = W.t; }
          W.bumps++;
          if (hooks && hooks.bump) hooks.bump(a, b, -vn, ra || rb);
        }
      }
    }
    const A = W.A, P = A.posts;
    // round obstacles: fixed posts, drifting jellies, the wandering top
    const obs = [];
    if (P) for (const p of P) obs.push([p[0], p[1], p[2], 0, 0, 'p']);
    if (A.jelly) for (const q of jellies(W)) obs.push([q[0], q[1], q[2], q[3], q[4], 'j']);
    if (A.top) { const q = topOf(W); obs.push([q[0], q[1], q[2], q[3], q[4], 't', q[5]]); }
    if (A.wreck) { const q = wreckOf(W); obs.push([q[0], q[1], q[2], q[3], q[4], 'b']); }
    if (A.pop) for (let k = 0; k < POPS.length; k++) { const ps = popState(W, k); if (ps.s === 2) obs.push([POPS[k][0], POPS[k][1], PO_R, 0, 0, 'u', ps.age < 0.18 ? 1 : 0]); }
    const fl = A.flip ? flippers(W) : A.arms ? armsOf(W) : null, lz = A.laser ? laserOf(W) : null;
    const pis = A.piston ? pistons(W) : null, phw = A.piston ? A.hw * sudden(W) : 0;
    const lgs = A.logs ? logsOf(W) : null;
    for (const c of cs) {
      if (!c.alive || c.f > 0 || c.j > 0) continue;
      const cr = rad(c);
      if (A.fence) { // rubber fence round the rim, except at the two moving gaps
        const r = Math.hypot(c.x, c.y), lim = A.R - cr - 1.5;
        if (r > lim && r < A.R + 2 && !inGap(W, Math.atan2(c.y, c.x), W.t, 0)) {
          const nx = c.x / r, ny = c.y / r, vr = c.vx * nx + c.vy * ny;
          c.x = nx * lim; c.y = ny * lim;
          if (vr > 0) { const k = vr * 1.8 + 25; c.vx -= nx * k; c.vy -= ny * k; if (vr > 40 && hooks && hooks.post) hooks.post(c, vr, 'w'); }
        }
      }
      if (A.walls) for (const sg of [-1, 1]) { // springy side walls
        if (c.x * sg > A.hw - cr) { c.x = sg * (A.hw - cr); if (c.vx * sg > 0) { const v = c.vx * sg; c.vx = -sg * (v * 1.05 + 35); if (v > 40 && hooks && hooks.post) hooks.post(c, v, 'w'); } }
      }
      if (lgs) for (const q of lgs) { // rolling logs: horizontal capsules sliding along y
        if (q[3] !== 2) continue;
        const px = clamp(c.x, q[0] - LG_L, q[0] + LG_L), py = q[1];
        let dx = c.x - px, dy = c.y - py, d = Math.hypot(dx, dy);
        const R = cr + LG_R;
        if (d >= R) continue;
        if (d < 1e-6) { dx = 0; dy = q[2]; d = 1; }
        const nx = dx / d, ny = dy / d, lv = q[2] * LG_V;
        c.x = px + nx * R; c.y = py + ny * R;
        const vn = c.vx * nx + (c.vy - lv) * ny;
        if (vn < 0) {
          const mk = c.sh > 0 ? 0.6 : c.hv > 0 || c.gi > 0 ? 0.8 : 1, kick = (-vn * 1.15 + 45) * mk;
          c.vx += nx * kick; c.vy += ny * kick;
          W.bumps++;
          if (hooks && hooks.post) hooks.post(c, -vn + 60, 'g');
        }
      }
      for (const p of obs) {
        let dx = c.x - p[0], dy = c.y - p[1], d = Math.hypot(dx, dy);
        const R = cr + p[2];
        if (d >= R) continue;
        if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
        const nx = dx / d, ny = dy / d;
        c.x = p[0] + nx * R; c.y = p[1] + ny * R;
        const vn = (c.vx - p[3]) * nx + (c.vy - p[4]) * ny;
        const rising = p[5] === 'u' && p[6];
        if (vn < 0 || p[5] === 't' || rising) {
          const mk = c.sh > 0 ? 0.5 : c.hv > 0 || c.gi > 0 ? 0.75 : 1;
          if (p[5] === 't') { // the top spins: a sideways swat plus a shove away
            const kick = (Math.max(0, -vn) * 1.2 + 95) * mk, sw = 150 * p[6] * mk;
            c.vx = p[3] + nx * kick - ny * sw; c.vy = p[4] + ny * kick + nx * sw;
          } else if (p[5] === 'b') { // wrecking ball: heavy, carries its own speed
            const kick = (Math.max(0, -vn) * 1.3 + 70) * mk;
            c.vx = p[3] * 0.9 + nx * kick; c.vy = p[4] * 0.9 + ny * kick;
          } else if (rising) { // a post shooting up under the car flings it away
            const kick = 170 * mk;
            c.vx = c.vx * 0.3 + nx * kick; c.vy = c.vy * 0.3 + ny * kick;
          } else {
            const kick = (-vn * (p[5] === 'j' ? 1.7 : 2.3) + (p[5] === 'j' ? 80 : 60)) * mk;
            c.vx += nx * kick; c.vy += ny * kick;
          }
          W.bumps++;
          if (hooks && hooks.post) hooks.post(c, Math.abs(vn) + (p[5] === 't' || p[5] === 'b' || rising ? 120 : 0), p[5]);
        }
      }
      if (pis) for (const q of pis) { // piston rams: boxes sliding out of the side walls
        if (q[2] < 0.5) continue;
        const x0 = q[0] < 0 ? -phw : phw - q[2], x1 = q[0] < 0 ? -phw + q[2] : phw;
        const px = clamp(c.x, x0, x1), py = clamp(c.y, q[1] - RAM_H, q[1] + RAM_H);
        let dx = c.x - px, dy = c.y - py, d = Math.hypot(dx, dy);
        if (d >= cr) continue;
        if (d < 1e-6) { dx = -q[0]; dy = 0; d = 1; }
        const nx = dx / d, ny = dy / d;
        c.x = px + nx * cr; c.y = py + ny * cr;
        const rv = -q[0] * q[3]; // ram velocity (x)
        const vn = (c.vx - rv * (Math.abs(nx) > 0.5 ? 1 : 0)) * nx + c.vy * ny;
        if (vn < 0) {
          const mk = c.sh > 0 ? 0.6 : c.hv > 0 || c.gi > 0 ? 0.8 : 1;
          const kick = (-vn * 1.05 + (q[3] > 0 ? 25 : 8)) * mk;
          c.vx += nx * kick; c.vy += ny * kick;
          if (hooks && hooks.post && (q[3] > 0 || -vn > 40)) hooks.post(c, -vn, 'r');
        }
      }
      if (fl) for (const f of fl) { // flipper / windmill arm = a swinging capsule
        const ex = Math.cos(f[2]), ey = Math.sin(f[2]);
        const rx = c.x - f[0], ry = c.y - f[1], u = clamp(rx * ex + ry * ey, 0, f[4]);
        const qx = f[0] + ex * u, qy = f[1] + ey * u;
        let dx = c.x - qx, dy = c.y - qy, d = Math.hypot(dx, dy);
        const R = cr + (A.arms ? ARM_TH : FL_TH);
        if (d >= R) continue;
        if (d < 1e-6) { dx = -ey; dy = ex; d = 1; }
        const nx = dx / d, ny = dy / d;
        c.x = qx + nx * R; c.y = qy + ny * R;
        const fvx = -f[3] * ey * u, fvy = f[3] * ex * u; // flipper surface velocity at the contact
        const vn = (c.vx - fvx) * nx + (c.vy - fvy) * ny;
        if (vn < 0) {
          const swing = Math.abs(f[3]) > 0.5;
          const kick = -vn * (swing ? 1.6 : 1.4) + (swing ? 50 : 10);
          c.vx += nx * kick; c.vy += ny * kick;
          if (hooks && hooks.post && (swing || -vn > 40)) hooks.post(c, -vn, A.arms ? 'a' : 'f');
        }
      }
      if (lz && lz.on) { // rotating laser bar through the centre
        const ex = Math.cos(lz.ang), ey = Math.sin(lz.ang);
        const al = c.x * ex + c.y * ey, pp = -c.x * ey + c.y * ex, R = cr + 2.5;
        if (Math.abs(pp) >= R || Math.abs(al) > 120) continue;
        const side = pp >= 0 ? 1 : -1, nx = -ey * side, ny = ex * side;
        c.x += nx * (R - Math.abs(pp)); c.y += ny * (R - Math.abs(pp));
        const bvx = -lz.w * ey * al, bvy = lz.w * ex * al; // beam velocity at this point
        const vn = (c.vx - bvx) * nx + (c.vy - bvy) * ny;
        if (vn < 0) {
          const kick = -vn * 1.5 + 55;
          c.vx += nx * kick; c.vy += ny * kick;
          if (hooks && hooks.post) hooks.post(c, -vn + 40, 'l');
        }
      }
    }
  }
  /* power-up effects (host / local). k = item key. Returns the affected other seat (or -1) */
  function applyItem(W, c, k, hooks) {
    const others = W.cars.filter((o) => o !== c && o.alive && o.f <= 0 && !(o.gh > 0) && !(o.inv > 0)); // 유령 / freshly respawned cars can't be targeted
    const near = (lim) => { let b = null, bd = lim; for (const o of others) { const d = Math.hypot(o.x - c.x, o.y - c.y); if (d < bd) { bd = d; b = o; } } return b; };
    const ca = Math.cos(c.a), sa = Math.sin(c.a);
    let tg = -1;
    if (k === 'h') c.hv = ITEMS.h.T;
    else if (k === 's') c.sh = ITEMS.s.T;
    else if (k === 'b') { c.gi = ITEMS.b.T; c.zs = 0; }
    else if (k === 't') { c.bk = ITEMS.t.T; c.sp = 0; }
    else if (k === 'p') { c.sp = ITEMS.p.T; c.bk = 0; }
    else if (k === 'm') c.rf = ITEMS.m.T;
    else if (k === 'n') c.mg = ITEMS.n.T;
    else if (k === 'f') c.tb = ITEMS.f.T;
    else if (k === 'y') c.gh = ITEMS.y.T;
    else if (k === 'i') c.iv = ITEMS.i.T;
    else if (k === 'z') { const o = near(1e9); if (o) { o.zs = ITEMS.z.T; o.gi = 0; tg = o.seat; } }
    else if (k === 'u') { const o = near(1e9); if (o) { o.fz = ITEMS.u.T; o.lh = c.seat; o.lht = W.t; tg = o.seat; } }
    else if (k === 'v') { // a whirlwind starts in front of me and hunts the others
      W.tw = { x: r1(c.x + ca * 18), y: r1(c.y + sa * 18), vx: ca * 40, vy: sa * 40, t: ITEMS.v.T, o: c.seat };
    } else if (k === 'x') { // a bomb dropped right behind me
      W.xb = { x: r1(c.x - ca * (rad(c) + 6)), y: r1(c.y - sa * (rad(c) + 6)), t: ITEMS.x.T, o: c.seat };
    } else if (k === 'c') { // cannonball: toward the nearest car in front (±70°), else straight ahead
      let ux = ca, uy = sa, bd = 1e9;
      for (const o of others) { const dx = o.x - c.x, dy = o.y - c.y, d = Math.hypot(dx, dy) || 1; if ((dx * ca + dy * sa) / d > 0.34 && d < bd) { bd = d; ux = dx / d; uy = dy / d; } }
      W.cb = { x: c.x + ux * (rad(c) + 4), y: c.y + uy * (rad(c) + 4), vx: ux * CB_V, vy: uy * CB_V, t: 1.3, o: c.seat };
    }
    else if (k === 'w') { // 충격파: radial shove
      for (const o of others) {
        if (o.j > 0) continue;
        const dx = o.x - c.x, dy = o.y - c.y, d = Math.hypot(dx, dy);
        if (d > WAVE_R) continue;
        const ux = d > 0.5 ? dx / d : 1, uy = d > 0.5 ? dy / d : 0, im = (230 * (1 - d / WAVE_R) + 70) / Math.sqrt(massOf(o));
        o.vx += ux * im; o.vy += uy * im; o.lh = c.seat; o.lht = W.t;
      }
    } else if (k === 'g') { // 갈고리: yank the nearest car toward me
      const o = near(160) || near(1e9);
      if (o) {
        const dx = c.x - o.x, dy = c.y - o.y, d = Math.hypot(dx, dy) || 1, im = 215 / Math.sqrt(massOf(o));
        o.vx = o.vx * 0.3 + dx / d * im; o.vy = o.vy * 0.3 + dy / d * im; o.lh = c.seat; o.lht = W.t; tg = o.seat;
      }
    } else if (k === 'o') { // 기름: a slick under the nearest car
      const o = near(1e9);
      const x = o ? o.x : c.x, y = o ? o.y : c.y;
      W.oil = { x: r1(x), y: r1(y), t: OIL_T }; tg = o ? o.seat : -1;
    } else if (k === 'r') { const o = near(1e9); if (o) { o.rv = RV_T; tg = o.seat; } }
    else if (k === 'k') { // 끈끈이: every car near me gets stuck
      const hit = others.filter((o) => Math.hypot(o.x - c.x, o.y - c.y) < 95);
      if (!hit.length) { const o = near(1e9); if (o) hit.push(o); }
      for (const o of hit) o.sk = SK_T;
      if (hit.length === 1) tg = hit[0].seat;
    }
    if (hooks && hooks.item) hooks.item(c, k, tg);
    return tg;
  }
  /* one fixed step of the whole arena. inputs[seat] = input object */
  /* radial shove (bombs). Airborne and ghost cars are spared. */
  function blast(W, x, y, R, pow, by, hooks) {
    for (const o of W.cars) {
      if (!o.alive || o.f > 0 || o.j > 0 || o.gh > 0 || o.inv > 0) continue;
      const dx = o.x - x, dy = o.y - y, d = Math.hypot(dx, dy);
      if (d > R + rad(o)) continue;
      const ux = d > 0.5 ? dx / d : 1, uy = d > 0.5 ? dy / d : 0, im = (pow * (1 - clamp(d / (R + rad(o)), 0, 1)) + 70) / Math.sqrt(massOf(o));
      o.vx += ux * im; o.vy += uy * im;
      if (by >= 0 && by !== o.seat) { o.lh = by; o.lht = W.t; }
    }
    if (hooks && hooks.blast) hooks.blast(x, y, R);
  }
  /* power-up objects that live on the floor: whirlwind, bomb, cannonball (host / local) */
  function stepObjects(W, hooks) {
    const cs = W.cars;
    for (const c of cs) { // 자석: pull the others in
      if (!(c.mg > 0) || !c.alive || c.f > 0) continue;
      for (const o of cs) {
        if (o === c || !o.alive || o.f > 0 || o.j > 0 || o.gh > 0 || o.inv > 0) continue;
        const dx = c.x - o.x, dy = c.y - o.y, d = Math.hypot(dx, dy);
        if (d > MAGN_R || d < 1) continue;
        const a = (300 * (1 - d / MAGN_R) + 60) / Math.sqrt(massOf(o));
        o.vx += dx / d * a * H; o.vy += dy / d * a * H;
      }
    }
    const tw = W.tw;
    if (tw) {
      tw.t -= H;
      let tg = null, bd = 1e9;
      for (const o of cs) { if (o.seat === tw.o || !o.alive || o.f > 0 || o.gh > 0 || o.iv > 0) continue; const d = Math.hypot(o.x - tw.x, o.y - tw.y); if (d < bd) { bd = d; tg = o; } }
      let gx = tg ? tg.x - tw.x : -tw.x, gy = tg ? tg.y - tw.y : -tw.y;
      if (edgeDist(W, tw.x, tw.y, false) < 14) { gx = -tw.x; gy = -tw.y; }
      const gl = Math.hypot(gx, gy) || 1, k = 1 - Math.exp(-2.2 * H);
      tw.vx += (gx / gl * 62 - tw.vx) * k; tw.vy += (gy / gl * 62 - tw.vy) * k;
      tw.x += tw.vx * H; tw.y += tw.vy * H;
      for (const o of cs) {
        if (o.seat === tw.o || !o.alive || o.f > 0 || o.j > 0 || o.gh > 0 || o.inv > 0) continue;
        const dx = o.x - tw.x, dy = o.y - tw.y, d = Math.hypot(dx, dy);
        if (d > TW_R + rad(o)) continue;
        const ux = d > 0.5 ? dx / d : 1, uy = d > 0.5 ? dy / d : 0, m = 1 / Math.sqrt(massOf(o));
        o.vx += (-uy * 720 + ux * 260) * m * H; o.vy += (ux * 720 + uy * 260) * m * H;
        o.lh = tw.o; o.lht = W.t;
      }
      if (tw.t <= 0) W.tw = null;
    }
    const xb = W.xb;
    if (xb) { xb.t -= H; if (xb.t <= 0) { W.xb = null; blast(W, xb.x, xb.y, XB_R, 300, xb.o, hooks); } }
    const cb = W.cb;
    if (cb) {
      cb.t -= H; cb.x += cb.vx * H; cb.y += cb.vy * H;
      for (const o of cs) {
        if (o.seat === cb.o || !o.alive || o.f > 0 || o.j > 0 || o.gh > 0 || o.inv > 0) continue;
        if (Math.hypot(o.x - cb.x, o.y - cb.y) > rad(o) + 4) continue;
        const v = Math.hypot(cb.vx, cb.vy) || 1, im = 250 / Math.sqrt(massOf(o));
        o.vx += cb.vx / v * im; o.vy += cb.vy / v * im; o.lh = cb.o; o.lht = W.t;
        if (hooks && hooks.post) hooks.post(o, 200, 'c');
        W.cb = null; break;
      }
      if (W.cb && (cb.t <= 0 || edgeDist(W, cb.x, cb.y, false) < -30)) W.cb = null;
    }
  }
  function stepWorld(W, inputs, hooks) {
    W.t += H;
    const A = W.A;
    tickMech(W);
    if (A.tilt2) { // a dish on a ball joint: tilts both ways toward the heavy side
      let tx = 0, ty = 0;
      for (const c of W.cars) if (c.alive && c.f <= 0 && !(c.j > 0)) { const m = massOf(c); tx += m * c.x; ty += m * c.y; }
      W.thv += (0.02 * tx - 5 * W.th - 2.6 * W.thv) * H; W.th += W.thv * H;
      W.thv2 += (0.02 * ty - 5 * W.th2 - 2.6 * W.thv2) * H; W.th2 += W.thv2 * H;
      const m = Math.hypot(W.th, W.th2);
      if (m > 0.36) { W.th *= 0.36 / m; W.th2 *= 0.36 / m; W.thv *= 0.5; W.thv2 *= 0.5; }
    }
    if (A.quake && W.t - H >= QK_T0) { // a jolt shoves every car on the ground the same way
      const k0 = Math.floor((W.t - H - QK_T0) / QK_P), k1 = Math.floor((W.t - QK_T0) / QK_P);
      if (k1 > k0) { const an = quakeDir(W, k1); for (const c of W.cars) if (c.alive && c.f <= 0 && !(c.j > 0)) { const m = 1 / Math.sqrt(massOf(c)); c.vx += Math.cos(an) * QK_V * m; c.vy += Math.sin(an) * QK_V * m; } if (hooks && hooks.quake) hooks.quake(an); }
    }
    if (A.bombs && W.t >= BB_T0 + BB_FUSE) {
      const k0 = Math.floor((W.t - H - BB_T0 - BB_FUSE) / BB_P), k1 = Math.floor((W.t - BB_T0 - BB_FUSE) / BB_P);
      if (k1 > k0) { const p = bombPos(W, k1); blast(W, p[0], p[1], BB_R, 260, -1, hooks); }
    }
    if (A.tilt) {
      let tq = 0;
      for (const c of W.cars) if (c.alive && c.f <= 0) tq += massOf(c) * c.y;
      const acc = 0.022 * tq - 5 * W.th - 2.6 * W.thv;
      W.thv += acc * H; W.th += W.thv * H;
      if (W.th > 0.42) { W.th = 0.42; if (W.thv > 0) W.thv = 0; }
      if (W.th < -0.42) { W.th = -0.42; if (W.thv < 0) W.thv = 0; }
    }
    for (const c of W.cars) stepCar(W, c, inputs && inputs[c.seat], H, hooks);
    if (A.portal) { // step into a portal → come out of its twin, same speed and heading
      const ps = portalsOf(W);
      for (const c of W.cars) {
        if (!c.alive || c.f > 0 || c.j > 0 || c.pt > 0) continue;
        for (const p of ps) {
          if (Math.hypot(c.x - p[0], c.y - p[1]) > PT_R) continue;
          const q = ps.find((o) => o[2] === p[2] && o[3] !== p[3]), sp = Math.hypot(c.vx, c.vy);
          const ux = sp > 20 ? c.vx / sp : Math.cos(c.a), uy = sp > 20 ? c.vy / sp : Math.sin(c.a), ox = c.x, oy = c.y;
          c.x = q[0] + ux * (PT_R + rad(c) + 3); c.y = q[1] + uy * (PT_R + rad(c) + 3); c.pt = 0.9;
          if (hooks && hooks.portal) hooks.portal(c, ox, oy, p[2]);
          break;
        }
      }
    }
    stepObjects(W, hooks);
    collide(W, hooks);
    // pick-ups
    if (W.oil) { W.oil.t -= H; if (W.oil.t <= 0) W.oil = null; }
    if (W.item && edgeDist(W, W.item.x, W.item.y, false) < -2) { W.item = null; W.itemT = 1.5; } // its floor went away
    if (W.item) {
      for (const c of W.cars) {
        if (!c.alive || c.f > 0 || c.j > 0) continue;
        if (Math.hypot(c.x - W.item.x, c.y - W.item.y) < rad(c) + 7) {
          const k = ITEMS[W.item.k] ? W.item.k : 'h';
          W.item = null; W.itemT = ITEM_EVERY;
          applyItem(W, c, k, hooks);
          break;
        }
      }
    }
    // falling / elimination
    for (const c of W.cars) {
      if (!c.alive) { if (c.rs > 0) { c.rs -= H; if (c.rs <= 0) respawn(W, c, hooks); } continue; }
      if (c.f <= 0 && !(c.j > 0) && edgeDist(W, c.x, c.y, false) < 0) { c.f = 1e-6; if (hooks && hooks.fall) hooks.fall(c); }
      if (c.f >= FALL_T) {
        c.alive = false; c.rs = RESPAWN_T;
        let by = W.t - c.lht < KILL_WIN && c.lh !== c.seat ? c.lh : -1;
        if (ally(W, by, c.seat)) by = -1; // a teammate's push (item etc.) is no kill // the last car (or item) that touched it gets the kill
        c.by = by;
        if (hooks && hooks.out) hooks.out(c, by);
      }
    }
  }
  /* back on the floor after a fall: the safest spot (floor all round, nobody close, no hazard), with a short shield (host only: Math.random) */
  function respawn(W, c, hooks) {
    const A = W.A, hz = hazards(W, c.seat), sp = spawnPos(A, W.n, c.seat);
    let bx = sp.x, by = sp.y, bs = -1e9;
    for (let k = 0; k < 28; k++) {
      const ext = A.shape === 'c' ? curR(W) : 120, x = k ? (Math.random() * 2 - 1) * ext : sp.x, y = k ? (Math.random() * 2 - 1) * ext : sp.y;
      const e = edgeDist(W, x, y, true);
      let dn = 90, dh = 40;
      for (const o of W.cars) if (o !== c && o.alive && o.f <= 0) dn = Math.min(dn, Math.hypot(o.x - x, o.y - y));
      for (const q of hz) dh = Math.min(dh, Math.hypot(q[0] - x, q[1] - y) - q[2]);
      const sc = Math.min(e, 36) * 2 + dn + dh * 1.5 - (A.shape === 'x' ? 0 : Math.hypot(x, y) * 0.1) - (e < 12 ? 400 + (12 - e) * 20 : 0); // floor first, always
      if (sc > bs) { bs = sc; bx = x; by = y; }
    }
    Object.assign(c, fx0(), { x: bx, y: by, vx: 0, vy: 0, a: Math.atan2(-by, -bx), alive: true, f: 0, j: 0, jc: 0, cd: 0.4, dt: 0, inv: INV_T, lh: -1, lht: -9, pt: 0, by: -1, rs: 0 });
    if (hooks && hooks.respawn) hooks.respawn(c);
  }
  /* host only (uses Math.random): spawn a power-up now and then */
  /* is (x, y) inside a solid obstacle or on a trampoline pad? (keeps power-ups reachable) */
  function blockedAt(W, x, y) {
    const A = W.A;
    if (A.posts) for (const p of A.posts) if (Math.hypot(x - p[0], y - p[1]) < p[2] + 14) return true;
    if (A.top && Math.hypot(x, y) < 34 + TOP_R + 10) return true;
    if (A.pads) for (const p of PADS) if (Math.hypot(x - p[0], y - p[1]) < p[2] + 8) return true;
    if (A.flip) for (const f of flippers(W)) if (Math.hypot(x - f[0], y - f[1]) < FL_LEN + 10) return true;
    if (A.pop) for (const p of POPS) if (Math.hypot(x - p[0], y - p[1]) < PO_R + 10) return true;
    if (A.donut && Math.hypot(x, y) < DN_PIT + 16) return true;
    return false;
  }
  function maybeItem(W, dt, on) {
    if (!on || W.item) return;
    W.itemT -= dt;
    if (W.itemT > 0) return;
    for (let k = 0; k < 24; k++) {
      const x = (Math.random() * 2 - 1) * 90, y = (Math.random() * 2 - 1) * 110;
      if (edgeDist(W, x, y, true) > (W.A.plat ? 15 : W.A.shape === 'x' ? 12 : 26) && !blockedAt(W, x, y) && W.cars.every((c) => !c.alive || Math.hypot(c.x - x, c.y - y) > 30)) { W.item = { k: ITEM_KEYS[Math.floor(Math.random() * ITEM_KEYS.length)], x: r1(x), y: r1(y) }; W.itemT = ITEM_EVERY; return; }
    }
    W.itemT = 1;
  }

  /* ----- AI ----- */
  const AIC = {
    1: { rate: 0.32, noise: 0.55, margin: 12, dashP: 0.25, dashR: 32, dodge: 0, aim: 0.5, sims: 8, hz: 0.3, itemR: 28, rvFix: 99, darkN: 0.6 },
    2: { rate: 0.15, noise: 0.24, margin: 24, dashP: 0.5, dashR: 46, dodge: 0.25, aim: 0.8, sims: 12, hz: 1, itemR: 75, rvFix: 1.3, darkN: 0.35 },
    3: { rate: 0.06, noise: 0.05, margin: 28, dashP: 1, dashR: 62, dodge: 0.9, aim: 1, sims: 16, hz: 1.6, itemR: 140, rvFix: 0.35, darkN: 0.12, simDash: 1, itemAny: 1, horMax: 1.6, centre: 1, eW: 2.4, opp: 1 },
  };
  /* moving / active hazards the look-ahead can't feel (collisions, upcoming eruptions, the sweeping laser) */
  function hazards(W, me) {
    const A = W.A, out = [];
    if (A.piston) { const hw = A.hw * sudden(W); for (const q of pistons(W)) if (q[4] && !(q[3] < 0)) for (const u of [0.15, 0.5, 0.85]) out.push([q[0] * (hw - RAM_D * u), q[1], RAM_H + 3]); }
    if (A.arms) for (const f of armsOf(W)) { const an = f[2] + f[3] * 0.3; for (const u of [0.35, 0.7, 1]) out.push([Math.cos(an) * f[4] * u, Math.sin(an) * f[4] * u, 8]); }
    if (A.pop) for (let k = 0; k < POPS.length; k++) if (popState(W, k).s) out.push([POPS[k][0], POPS[k][1], PO_R + 6]);
    if (A.wreck) { const q = wreckOf(W); out.push([q[0], q[1], q[2] + 6]); out.push([q[0] + q[3] * 0.3, q[1] + q[4] * 0.3, q[2] + 10]); }
    if (A.bombs) for (const b of bombsOf(W)) out.push([b[0], b[1], BB_R + 4]);
    if (A.fans) { const f = W.fan || fanState(W); if (f.k >= 0) { const an = fanAng(W, f.k), R = A.R; for (let r = -R + 10; r < R; r += 22) out.push([Math.cos(an) * r, Math.sin(an) * r, FAN_W - 6]); } }
    if (A.logs) for (const q of logsOf(W)) { const y = q[3] === 2 ? q[1] + q[2] * LG_V * 0.35 : q[1] + q[2] * 20; for (const u of [-1, -0.5, 0, 0.5, 1]) out.push([q[0] + u * LG_L, y, LG_R + 8]); }
    if (A.wave) { const wv = waveOf(W); const x = wv.x != null ? wv.x + wv.dir * WV_V * 0.3 : wv.warn ? -wv.warn * (A.hw - 6) : null; if (x != null) for (let y = -A.hh + 10; y < A.hh; y += 22) out.push([x, y, WV_H + 4]); }
    if (A.boost) for (let k = 0; k < 6; k++) out.push([BS_POS[k][0], BS_POS[k][1], BS_R + 2]);
    if (W.tw && W.tw.o !== me) out.push([W.tw.x + W.tw.vx * 0.3, W.tw.y + W.tw.vy * 0.3, TW_R + 10]);
    if (W.xb) out.push([W.xb.x, W.xb.y, XB_R + 6]);
    if (W.cb && W.cb.o !== me) for (const u of [0.08, 0.16, 0.24]) out.push([W.cb.x + W.cb.vx * u, W.cb.y + W.cb.vy * u, 9]);
    if (A.posts) for (const p of A.posts) out.push([p[0], p[1], p[2] + 4]);
    if (A.jelly) for (const q of jellies(W)) out.push([q[0] + q[3] * 0.3, q[1] + q[4] * 0.3, q[2] + 6]);
    if (A.top) { const q = topOf(W); out.push([q[0] + q[3] * 0.3, q[1] + q[4] * 0.3, q[2] + 12]); }
    if (A.flip) for (const f of flippers(W)) for (const u of [0.5, 1]) out.push([f[0] + Math.cos(f[2]) * f[4] * u, f[1] + Math.sin(f[2]) * f[4] * u, 9]);
    if (A.vents) for (let k = 0; k < VENTS.length; k++) if (ventState(W, k)) out.push([VENTS[k][0], VENTS[k][1], VENT_R + 2]);
    if (A.pads) for (const p of PADS) out.push([p[0], p[1], p[2] + 2]);
    if (A.laser) { const z = laserOf(W); if (z.on || z.warn) { const an = z.ang + z.w * 0.3; for (let r = -100; r <= 100; r += 20) out.push([Math.cos(an) * r, Math.sin(an) * r, 11]); } }
    return out;
  }
  function simAhead(W, c, ix, iy, T, kick, hz) { // where would this car be after T s holding (ix, iy) — no collisions
    const g = Object.assign(fx0(), { x: c.x, y: c.y, vx: c.vx + (kick ? kick[0] : 0), vy: c.vy + (kick ? kick[1] : 0), a: c.a, alive: true, f: 0, cd: 1, dt: 0, hv: c.hv, sk: c.sk, tb: c.tb, zs: c.zs, fz: c.fz, j: c.j, jc: c.jc, dl: 0 });
    const n = Math.round(T / (H * 4));
    let worst = 1e9, hc = 1e9;
    for (let k = 0; k < n; k++) {
      stepCar(W, g, { x: ix, y: iy, m: 's', d: 0 }, H * 4, null);
      if (!(g.j > 0)) worst = Math.min(worst, edgeDist(W, g.x, g.y, true));
      if (hz && k % 2 === 0) for (const q of hz) hc = Math.min(hc, Math.hypot(g.x - q[0], g.y - q[1]) - q[2] - CR);
    }
    if (g.j > 0) worst = Math.min(worst, edgeDist(W, g.x + g.vx * g.j, g.y + g.vy * g.j, true));
    return { x: g.x, y: g.y, worst, hc };
  }
  /* 팀전 협공: an enemy a teammate is already on is worth more */
  function pincer(W, c, o, lv) {
    let b = 0;
    for (const q of W.cars) {
      if (q === c || !q.alive || q.f > 0 || !ally(W, c.seat, q.seat)) continue;
      const d = Math.hypot(q.x - o.x, q.y - o.y);
      if (d < 70) b += (70 - d) * (lv >= 3 ? 0.6 : lv === 2 ? 0.4 : 0.15);
    }
    return Math.min(b, 40);
  }
  function aiThink(W, c, mem, lv, dt) {
    if (!c.alive || c.f > 0) return mem.inp || (mem.inp = { x: 0, y: 0, m: 's', d: 0 });
    const C = AIC[lv] || AIC[2];
    const inp = mem.inp || (mem.inp = { x: 0, y: 0, m: 's', d: 0 });
    mem.t = (mem.t || 0) - dt;
    if (mem.t > 0 || c.j > 0 || c.fz > 0) return inp;
    mem.t = C.rate * (0.7 + Math.random() * 0.6);
    // 역방향: notice after a while and steer the other way
    if (c.rv > 0) { if (mem.rvAt == null) mem.rvAt = W.t; } else mem.rvAt = null;
    const flipIn = mem.rvAt != null && W.t - mem.rvAt > C.rvFix ? -1 : 1;
    const press = (x, y) => { inp.x = r2(x * flipIn); inp.y = r2(y * flipIn); inp.m = 's'; inp.d = (inp.d + 1) % 1000; return inp; };
    const blinkOk = (x, y) => lv <= 1 || edgeDist(W, c.x + x * BLINK, c.y + y * BLINK, true) > (lv >= 3 ? 16 : 6);
    const hopOk = (x, y) => { const L2 = SPRING_V * AIR_T; return lv <= 1 || edgeDist(W, c.x + x * L2 + c.vx * 0.06, c.y + y * L2 + c.vy * 0.06, true) > (lv >= 3 ? 16 : 8); };
    const charge = c.bk > 0 || c.sp > 0, chargeOk = (x, y) => (c.bk > 0 ? blinkOk(x, y) : hopOk(x, y));
    // pick a victim: nearer and nearer to an edge = juicier
    let tgt = null, best = -1e9;
    if (!mem.pref) mem.pref = W.cars.map(() => Math.random() * 14); // personal grudges: breaks the symmetric ties that made some seats the usual victim
    for (const o of W.cars) {
      if (o === c || !o.alive || o.f > 0) continue;
      if (ally(W, c.seat, o.seat)) continue; // 팀전: never hunt a teammate
      if (o.iv > 0 && lv < 3) continue; // 투명: can't see it (어려움 still guesses where it went)
      if (o.gh > 0 && lv >= 2) continue; // 유령: no point pushing it
      if (o.inv > 0 && lv >= 2) continue; // just respawned: shielded, wait it out
      const d = Math.hypot(o.x - c.x, o.y - c.y), e = edgeDist(W, o.x, o.y, false);
      const sc = -d * 0.6 - e * (C.eW || 1.4) + (mem.tg === o.seat ? 25 : 0) - (o.rf > 0 && lv >= 2 ? 60 : 0) - (o.sh > 0 && lv >= 3 ? 40 : 0)
        + mem.pref[o.seat] + (W.tm ? pincer(W, c, o, lv) : 0) + (lv >= 2 && (o.zs > 0 || o.fz > 0) ? 25 : 0) + (lv >= 3 && W.lead === o.seat ? 18 : 0) + (C.opp && o.cd > 0.8 ? 18 : 0) - (o.iv > 0 ? 35 : 0) - (o.mg > 0 && lv >= 3 ? 20 : 0);
      if (sc > best) { best = sc; tgt = o; }
    }
    if (c.gh > 0 && lv >= 2) tgt = null; // I'm a ghost: can't push anyone, so just stay safe / grab items
    if (tgt) mem.tg = tgt.seat;
    // goal point: just behind the victim, on the side away from its nearest edge (so a hit pushes it out)
    let gx = 0, gy = 0, goItem = false;
    mem.al = 0; mem.toT = 1e9;
    if (tgt) {
      const e0 = edgeDist(W, tgt.x, tgt.y, true);
      let ox = 0, oy = 0; // direction toward the victim's nearest edge
      for (let k = 0; k < 8; k++) { const an = k * Math.PI / 4, e = edgeDist(W, tgt.x + Math.cos(an) * 12, tgt.y + Math.sin(an) * 12, true); if (e0 - e > 0) { ox += Math.cos(an) * (e0 - e); oy += Math.sin(an) * (e0 - e); } }
      const ol = Math.hypot(ox, oy) || 1; ox /= ol; oy /= ol;
      if (C.aim < 1 && Math.random() > C.aim) { ox = -ox; oy = -oy; }
      const lead = Math.min(0.35, Math.hypot(tgt.x - c.x, tgt.y - c.y) / 300);
      const px = tgt.x + tgt.vx * lead, py = tgt.y + tgt.vy * lead;
      const toT = Math.hypot(px - c.x, py - c.y);
      const behindX = px - ox * CR * 2.6, behindY = py - oy * CR * 2.6;
      // already lined up behind it → drive through it
      const al = ((px - c.x) * ox + (py - c.y) * oy) / (toT || 1);
      if (al > 0.6 || toT < CR * 3) { gx = px + ox * 20; gy = py + oy * 20; } else { gx = behindX; gy = behindY; }
      // 어려움: when the victim is safe in the middle and far off, hold the high ground (between it and the centre) instead of chasing round the rim
      if (C.centre && e0 > 40 && toT > 60) { gx = tgt.x * 0.35; gy = tgt.y * 0.35; }
      mem.al = al; mem.toT = toT;
    }
    // power-ups: 보통 grabs nearby ones, 어려움 goes out of its way for them, 쉬움 only stumbles on them
    if (W.item) {
      const dI = Math.hypot(W.item.x - c.x, W.item.y - c.y);
      if (dI < C.itemR && (C.itemAny || dI < mem.toT * 1.2 || mem.al < 0.6) && edgeDist(W, W.item.x, W.item.y, true) > 12) { gx = W.item.x; gy = W.item.y; goItem = true; }
    }
    // choose the stick direction whose short look-ahead lands nearest the goal while keeping a safety margin
    let bx = 0, by = 0, bs = -1e9;
    const hor = clamp(1.1 / W.A.fr, 0.45, C.horMax || 0.9);
    const hz = hazards(W, c.seat);
    // a jolt / gust is about to hit: 보통·어려움 keep further from the edge
    const shaky = (W.A.quake && quakeOf(W).warn) || (W.A.gust && gustAt(W, W.t).warn) || (W.A.tide && tideU(W, W.t).warn);
    let margin = C.margin + (shaky ? (lv >= 3 ? 14 : lv === 2 ? 6 : 0) : 0);
    if (W.A.shape === 'x') margin = Math.min(margin, lv >= 3 ? 16 : 12); // the bridges are narrower than the usual margin
    const shield = c.inv > 0 && lv >= 2; // 보통·어려움 know the spawn shield makes them unpushable: charge in
    for (let k = 0; k <= C.sims; k++) {
      const an = (k / C.sims) * Math.PI * 2, ix = k === C.sims ? 0 : Math.cos(an), iy = k === C.sims ? 0 : Math.sin(an);
      const p = simAhead(W, c, ix, iy, hor, null, hz.length ? hz : null);
      let s = -Math.hypot(p.x - gx, p.y - gy);
      if (p.worst < (shield ? 8 : margin)) s -= ((shield ? 8 : margin) - p.worst) * 6;
      if (p.worst < 0) s -= 400;
      if (p.hc < 0) s += p.hc * 5 * C.hz;
      if (s > bs) { bs = s; bx = ix; by = iy; }
    }
    // 어려움: sidestep a dash coming at me
    if (Math.random() < C.dodge) for (const o of W.cars) {
      if (o === c || !o.alive || o.f > 0 || o.dt <= 0) continue;
      const rx = c.x - o.x, ry = c.y - o.y, d = Math.hypot(rx, ry), sp = Math.hypot(o.vx, o.vy);
      if (d > 70 || sp < 60) continue;
      const toward = (o.vx * rx + o.vy * ry) / (d * sp);
      if (toward < 0.8) continue;
      const px = -o.vy / sp, py = o.vx / sp, side = px * rx + py * ry >= 0 ? 1 : -1;
      const cand = [[px * side, py * side], [-px * side, -py * side]];
      let safe = false;
      for (const [ix, iy] of cand) { const p = simAhead(W, c, ix, iy, hor); if (p.worst > 4) { bx = ix; by = iy; safe = true; break; } }
      if (safe && c.cd <= 0 && lv >= 3 && (charge ? chargeOk(bx, by) : simAhead(W, c, bx, by, hor + 0.4, [bx * DASH, by * DASH]).worst > 6)) return press(bx, by);
    }
    // 순간 이동 / 스프링 charge: escape from the brink (or a hazard), or blink next to a victim
    if (charge && c.cd <= 0 && lv >= 2) {
      let hzNear = false;
      if (lv >= 3) for (const q of hz) if (Math.hypot(c.x - q[0], c.y - q[1]) < q[2] + rad(c)) { hzNear = true; break; }
      if ((edgeDist(W, c.x, c.y, true) < 18 || hzNear) && (bx || by) && chargeOk(bx, by)) return press(bx, by);
      if (c.bk > 0 && tgt && !goItem && mem.toT > 45 && mem.toT < 105 && mem.al > 0.6) {
        const dx = (tgt.x - c.x) / mem.toT, dy = (tgt.y - c.y) / mem.toT;
        if (blinkOk(dx, dy)) return press(dx, dy);
      }
    }
    const nz = C.noise + (W.A.dark && darkOf(W) === 2 ? C.darkN : 0);
    let ax = bx + (Math.random() - 0.5) * nz, ay = by + (Math.random() - 0.5) * nz;
    const m = Math.hypot(ax, ay);
    if (m > 1) { ax /= m; ay /= m; }
    inp.x = r2(ax * flipIn); inp.y = r2(ay * flipIn); inp.m = 's';
    // dash when lined up and close enough (and it doesn't throw me off). 거대화 makes it bolder.
    const dashR = C.dashR * (c.gi > 0 ? 1.3 : 1);
    const mateInWay = W.tm && tgt && W.cars.some((q) => q !== c && q.alive && ally(W, c.seat, q.seat) && Math.hypot(q.x - c.x, q.y - c.y) < mem.toT && ((q.x - c.x) * (tgt.x - c.x) + (q.y - c.y) * (tgt.y - c.y)) / (Math.hypot(q.x - c.x, q.y - c.y) * mem.toT + 1e-6) > 0.85);
    if (tgt && !goItem && !mateInWay && c.cd <= 0 && mem.toT < dashR && mem.al > 0.75 && Math.random() < (shield ? 1 : C.dashP) && !(charge && lv >= 2)) {
      const dx = (tgt.x - c.x) / mem.toT, dy = (tgt.y - c.y) / mem.toT;
      // past the victim there should still be floor (어려움 simulates it, the others eyeball it)
      const after = charge ? (chargeOk(dx, dy) ? 1 : -99) : C.simDash ? simAhead(W, c, dx, dy, 0.5, [dx * DASH * 0.5, dy * DASH * 0.5]).worst : edgeDist(W, c.x + dx * 50, c.y + dy * 50, true);
      if (after > (C.simDash ? -6 : -10) || (shield && lv >= 3 && after > -30)) return press(dx, dy);
    }
    return inp;
  }

  /* ======================= pure game interface ======================= */
  /* A match = one clock. Falling off costs nothing but a short wait; pushing someone off = 1 kill.
     First to the kill goal wins, or the most kills when time runs out (tie → fewer falls → overtime). */
  function init(players, opts) {
    const o = opts || {}, np = players.length;
    const ts = o.mode === 2 || o.mode === 3 ? Math.min(3, Math.max(o.mode, Math.ceil(np / 2))) : 0; // 팀전 2:2 / 3:3 (grows to fit everyone)
    const n = ts ? ts * 2 : np, nm = players.map((p) => String((p && p.name) || '').slice(0, 10));
    for (let i = np; i < n; i++) nm.push('지원 AI ' + (i - np + 1)); // empty team seats → AI cars
    return {
      rid: 1 + U.rand(99999), n, np, nm, tm: ts ? Array.from({ length: n }, (_, i) => i % 2) : null,
      T: ([2, 3, 5].includes(o.time) ? o.time : 3) * 60, goal: [5, 10, 15].includes(o.goal) ? o.goal : 10,
      sw: [0, 60, 90].includes(o.sw) ? o.sw : 60, it: o.items === 0 ? 0 : 1,
      ph: 'pick', pk: -1, ar: -1, rd: 1, sd: 1 + U.rand(2147483646), k: Array(n).fill(0), dn: Array(n).fill(0), mt0: 0, ot: 0, rw: -1, res: null,
    };
  }
  function startMatch(s, rnd) { // host/local: leave the picker; a random arena is rolled only now
    const ar = s.pk >= 0 ? s.pk : Math.floor((rnd || Math.random)() * ARENAS.length);
    return Object.assign({}, s, { ph: 'count', ar });
  }
  /* random arena mode: a new arena every s.sw seconds (scores and the clock carry on). el = match seconds played so far */
  function nextStage(s, el, rnd) {
    const r = rnd || Math.random;
    let ar = Math.floor(r() * (ARENAS.length - 1)); if (ar >= s.ar) ar++;
    return Object.assign({}, s, { rd: s.rd + 1, sd: 1 + U.rand(2147483646), ph: 'count', ar, mt0: Math.round(el * 10) / 10 });
  }
  function teamRank(s) { // [[team, kills, falls]] best first
    const t = [[0, 0, 0], [1, 0, 0]];
    s.tm.forEach((m, i) => { t[m][1] += s.k[i] | 0; t[m][2] += s.dn[i] | 0; });
    return t.sort((a, b) => b[1] - a[1] || a[2] - b[2]);
  }
  function teamLead(s) { const r = teamRank(s); return r[0][1] === r[1][1] && r[0][2] === r[1][2] ? -1 : r[0][0]; }
  function rankOf(s) { return s.k.map((v, i) => [i, v, s.dn[i] | 0]).sort((a, b) => b[1] - a[1] || a[2] - b[2] || a[0] - b[0]); }
  function leadOf(s) { if (s.tm) { const t = teamLead(s); return t < 0 ? -1 : rankOf(s).find((r) => s.tm[r[0]] === t)[0]; } const r = rankOf(s); return r.length > 1 && r[0][1] === r[1][1] && r[0][2] === r[1][2] ? -1 : r[0][0]; } // −1 = tied at the top
  function finish(s) {
    if (s.tm) { const t = teamLead(s), res = rankOf(s); return Object.assign({}, s, { ph: 'end', res, rt: t, rw: t < 0 ? -1 : res.find((r) => s.tm[r[0]] === t)[0] }); }
    const res = rankOf(s), top = res.filter((r) => r[1] === res[0][1] && r[2] === res[0][2]); return Object.assign({}, s, { ph: 'end', res, rw: top.length === 1 ? top[0][0] : -1 }); }
  /* a car fell (host): count it, and maybe end the match */
  function addKill(s, victim, by) {
    const n = Object.assign({}, s, { k: s.k.slice(), dn: s.dn.slice() });
    n.dn[victim] = (n.dn[victim] | 0) + 1;
    if (by >= 0 && by !== victim) n.k[by] = (n.k[by] | 0) + 1;
    if (by >= 0 && n.tm && teamRank(n)[0][1] >= n.goal) return finish(n);
    if (by >= 0 && !n.tm && n.k[by] >= n.goal) return finish(n);
    if (n.ot && leadOf(n) >= 0) return finish(n); // overtime: the first change that breaks the tie wins
    return n;
  }
  function timeUp(s) { return leadOf(s) >= 0 ? finish(s) : Object.assign({}, s, { ot: 1 }); }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const np = s.np || s.n || s.res.length;
    if (s.tm) {
      const tr = teamRank(s), how = (s.pk >= 0 ? ARENAS[s.pk].name : '무작위 경기장') + ' · 팀전 ' + (s.n / 2) + ':' + (s.n / 2) + ' · 목표 팀 ' + s.goal + '처치';
      const win = s.rt >= 0 ? Array.from({ length: np }, (_, i) => i).filter((i) => s.tm[i] === s.rt) : Array.from({ length: np }, (_, i) => i);
      const tl = tr.map((t) => TEAMN[t[0]] + '  ' + t[1] + '처치 · 낙하 ' + t[2] + '  (' + s.tm.map((m, i) => (m === t[0] ? nm(i) + ' ' + (s.k[i] | 0) : null)).filter(Boolean).join(', ') + ')');
      const stats = [{ label: '팀', values: Array.from({ length: np }, (_, i) => TEAMN[s.tm[i]]) }, { label: '밀어낸 수', values: Array.from({ length: np }, (_, i) => (s.k[i] | 0) + '번') }, { label: '떨어진 수', values: Array.from({ length: np }, (_, i) => (s.dn[i] | 0) + '번') }];
      return { stats, winners: win, title: s.rt >= 0 ? TEAMN[s.rt] + ' 우승!' : '무승부', text: how + '\n' + tl.join('\n') };
    }
    const top = s.res.filter((r) => r[1] === s.res[0][1] && r[2] === s.res[0][2]).map((r) => r[0]).filter((i) => i < np);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '처치 · 낙하 ' + r[2]);
    const how = (s.pk >= 0 ? ARENAS[s.pk].name : '무작위 경기장') + ' · ' + Math.round(s.T / 60) + '분 · 목표 ' + s.goal + '처치';
    const by = []; s.res.forEach((r) => { by[r[0]] = r; });
    const col = (f) => Array.from({ length: np }, (_, i) => (by[i] ? f(by[i]) : '-'));
    const stats = [{ label: '밀어낸 수', values: col((r) => (r[1] | 0) + '번') }, { label: '떨어진 수', values: col((r) => (r[2] | 0) + '번') },
      { label: '득실', values: col((r) => { const d = (r[1] | 0) - (r[2] | 0); return (d > 0 ? '+' : '') + d; }) }];
    return { stats, winners: top, title: top.length === 1 ? nm(top[0]) + ' 우승!' : '공동 우승', text: how + '\n' + lines.join('\n') };
  }
  const fmtT = (v) => { v = Math.max(0, Math.ceil(v)); return Math.floor(v / 60) + ':' + String(v % 60).padStart(2, '0'); };

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `
.sm-pick{position:absolute;left:0;right:0;bottom:0;z-index:8;padding:12px 12px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.95) 14%);display:flex;flex-direction:column;gap:8px;user-select:none;-webkit-user-select:none}
.sm-pick h3{margin:0;font-family:var(--f-display,"Black Han Sans"),sans-serif;font-weight:400;font-size:22px;color:var(--ink,#f2e9d8)}
.sm-pick .sub{font-size:12px;color:var(--muted,#ab9fb8);min-height:16px;line-height:1.35}
.sm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(60px,1fr));gap:5px;max-height:46vh;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;padding:1px 2px 2px 1px;-webkit-overflow-scrolling:touch;scrollbar-width:thin}
.sm-tk{touch-action:pan-y;appearance:none;border:1.5px solid rgba(242,233,216,.14);background:rgba(46,38,64,.92);color:var(--ink,#f2e9d8);border-radius:12px;padding:4px 2px 5px;display:flex;flex-direction:column;align-items:center;gap:2px;font-weight:700;font-size:10.5px;line-height:1.15;min-height:62px;cursor:pointer;touch-action:manipulation;word-break:keep-all;text-align:center}
.sm-tk:active{transform:scale(.96)}
.sm-tk canvas{width:40px;height:36px;display:block}
.sm-tk.on{border-color:var(--brass,#e3ae45);background:rgba(227,174,69,.2)}
.sm-tk:disabled{opacity:.85;cursor:default}
.sm-tk .q{font-family:var(--f-display,"Black Han Sans"),sans-serif;font-size:24px;height:36px;display:grid;place-items:center;color:var(--brass,#e3ae45)}
.sm-ctl{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted,#ab9fb8)}
.sm-ctl .lb{font-weight:700}
.sm-ctl .seg button{min-height:36px;padding:6px 10px}
.sm-chip{position:absolute;left:10px;top:62px;z-index:6;appearance:none;border:1px solid rgba(242,233,216,.2);background:rgba(23,19,31,.78);color:var(--ink,#f2e9d8);border-radius:12px;min-height:40px;padding:4px 12px;font:700 12px/1.2 "IBM Plex Sans KR",system-ui,sans-serif;cursor:pointer;touch-action:manipulation;user-select:none;-webkit-user-select:none}
.sm-chip b{color:var(--brass,#e3ae45)}
`;

  const KC = () => { const v = L.ui && L.ui.ctlScale ? +L.ui.ctlScale() : 1; return v > 0 ? v : 1; };
  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let st = null, key = null, W = null, phase = 'wait', cd = 0, endT = 0, acc = 0, hostT = 0, frameNo = 0, pick = null;
    let cfg = { ctl: 's' };
    try { const c = JSON.parse(localStorage.getItem('lounge.sumo.cfg') || 'null'); if (c && (c.ctl === 's' || c.ctl === 't')) cfg.ctl = c.ctl; } catch (e) {}
    const pc = {};
    const P = (s) => {
      const b = api.players[s] || { name: (st && st.nm && st.nm[s]) || 'AI', color: '#888', ai: true, lv: 2 };
      if (!st || !st.tm || st.tm[s] == null) return b;
      const k = st.rid + ':' + s; if (pc[k]) return pc[k];
      let j = 0; for (let i = 0; i < s; i++) if (st.tm[i] === st.tm[s]) j++;
      return (pc[k] = Object.assign({}, b, { color: TEAMC[st.tm[s]][j % 3] }));
    };
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return !!(st && st.tm && s < st.n) && (!api.online || api.isHost); if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1); // the one person driving on this phone
    let aiMem = [], inputs = {}, parts = [], floats = [], shake = 0, hstop = 0, slowT = 0, flashA = 0, lastSfx = 0, hintT = 0, lay = null;
    const locIn = {}; // seat -> input for the person on this phone
    // network
    let pubT = 0, hsQ = 0, inQ = 0, lastSig = '', inT = 0, snaps = [], lastQ = -1, lastBm = 0, lastEvQ = -1, rtt = 0.15;
    const sendT = {}, iqOf = {}, remIn = {};
    let ghost = null;

    function curKey() { return st ? st.rid + '.' + st.rd + '.' + st.ar : null; }
    function startRound() {
      if (!(st.ar >= 0)) { W = null; return; }
      W = newWorld(st.ar, st.sd, st.n); W.tm = st.tm || null;
      aiMem = W.cars.map(() => ({}));
      inputs = {};
      parts = []; floats = []; rings = []; cue = {}; snaps = []; lastQ = -1; ghost = null; acc = 0; banner = null;
      for (const s of mine()) locIn[s] = { x: 0, y: 0, t: 0, m: cfg.ctl, d: (locIn[s] && locIn[s].d) || 0 };
      phase = st.ph === 'play' ? 'play' : 'count';
      cd = COUNT; endT = END_T;
      if (st.rd === 1 && mine().length) hintT = 5;
      feed = [];
      layout();
    }

    /* ----- layout: whole arena on screen, leaving a control band at the bottom ----- */
    function arenaBox(A) { return A.shape === 'x' ? { w: X_L * 2, h: X_L * 2 } : A.shape === 'c' ? { w: A.R * 2 + (A.fans ? 16 : 0), h: A.R * 2 + (A.fans ? 16 : 0) } : A.shape === 'p' ? { w: (PL_D1 + PL_HS) * 2, h: (PL_D1 + PL_HS) * 2 } : { w: A.hw * 2, h: A.hh * 2 }; }
    function layout() {
      const w = cv.w, h = cv.h;
      const A = W ? W.A : ARENAS[0], B = arenaBox(A);
      const k = KC(); STICK_R = Math.round(46 * k);
      const top = 106, bot = mine().length ? Math.round(120 * Math.max(1, k)) : 20;
      const s = Math.max(0.5, Math.min((w - 24) / (B.w + 20), (h - top - bot) / (B.h + 20)));
      lay = { s, cx: w / 2, cy: top + (h - top - bot) / 2 };
      syncChip();
    }
    cv.onresize = layout;
    const X = (x) => lay.cx + x * lay.s, Y = (y) => lay.cy + y * lay.s;

    /* ----- input ----- */
    const ptrs = new Map(); // id -> {seat, kind:'stick'|'L'|'R', ax, ay, x, y}
    let STICK_R = 46;
    const onCtl = () => layout(); window.addEventListener('lounge-ctl', onCtl);
    const seatAt = () => { const m = mine(); return m.length ? m[0] : -1; };
    function dashBtn() { const r = Math.round(36 * KC()); return { x: cv.w - r - 22, y: cv.h - r - 30, r }; }
    function turnBtns() { const r = Math.round(32 * Math.min(1.35, KC())), y = cv.h - r - 30; return [{ x: 24 + r, y, r, dir: -1 }, { x: 24 + r * 3 + 14, y, r, dir: 1 }]; }
    function refresh() {
      for (const s of mine()) {
        const I = locIn[s] || (locIn[s] = { x: 0, y: 0, t: 0, m: cfg.ctl, d: 0 });
        I.m = cfg.ctl; I.x = 0; I.y = 0; I.t = 0;
        for (const p of ptrs.values()) {
          if (p.seat !== s) continue;
          if (p.kind === 'stick') {
            const dx = p.x - p.ax, dy = p.y - p.ay;
            const d = Math.hypot(dx, dy);
            if (d > 6) { const m = Math.min(1, d / STICK_R); I.x = r2(dx / d * m); I.y = r2(dy / d * m); }
          } else if (p.kind === 'L') I.t -= 1; else if (p.kind === 'R') I.t += 1;
        }
        I.t = clamp(I.t, -1, 1);
        // keyboard / gamepad (api.input, rebindable): a stick is analog, keys are full deflection
        if (api.input) {
          const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down');
          if (kx || ky) {
            if (cfg.ctl === 's') { const m = Math.hypot(kx, ky), k = m > 1 ? 1 / m : 1; I.x = r2(kx * k); I.y = r2(ky * k); }
            else I.t = r2(clamp(kx, -1, 1));
          }
        }
      }
    }
    function pressDash(s) {
      const I = locIn[s]; if (!I) return;
      const c = myCar(s);
      I.d = (I.d + 1) % 1000;
      if (c && c.cd > 0.05) { api.buzz(5); } else { api.buzz(18); }
      pubT = 0; inT = 0;
    }
    function onDown(e) {
      const p = cv.local(e), seat = seatAt();
      if (seat < 0 || !W) return;
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      const rightSide = p.x > cv.w / 2;
      hintT = Math.min(hintT, 1); banner = null;
      if (rightSide) { pressDash(seat); ptrs.set(e.pointerId, { seat, kind: 'dash', x: p.x, y: p.y }); refresh(); return; }
      if (cfg.ctl === 't') {
        const kind = p.x < cv.w / 4 ? 'L' : 'R';
        ptrs.set(e.pointerId, { seat, kind, x: p.x, y: p.y });
      } else {
        for (const [id, q] of ptrs) if (q.seat === seat && q.kind === 'stick') ptrs.delete(id);
        ptrs.set(e.pointerId, { seat, kind: 'stick', ax: p.x, ay: p.y, x: p.x, y: p.y });
      }
      refresh();
    }
    function onMove(e) {
      const q = ptrs.get(e.pointerId);
      if (!q) return;
      const p = cv.local(e);
      q.x = p.x; q.y = p.y;
      if (q.kind === 'stick') {
        const d = Math.hypot(q.x - q.ax, q.y - q.ay);
        if (d > STICK_R * 1.3) { const k = STICK_R * 1.3 / d; q.ax = q.x - (q.x - q.ax) * k; q.ay = q.y - (q.y - q.ay) * k; } // the stick base follows the thumb
      } else if (q.kind === 'L' || q.kind === 'R') { if (p.x < cv.w / 2) q.kind = p.x < cv.w / 4 ? 'L' : 'R'; }
      refresh();
    }
    function onUp(e) { if (ptrs.delete(e.pointerId)) refresh(); }
    // keyboard / gamepad (declared in `controls`): movement is read in refresh() (also every frame, for analog sticks)
    const offIn = api.input ? api.input.on((type, id) => {
      if (id === 'dash') { if (type === 'down' && W && mine().length) { hintT = Math.min(hintT, 1); pressDash(mine()[0]); } }
      else refresh();
    }) : null;
    const releaseAll = () => { ptrs.clear(); refresh(); };
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    window.addEventListener('blur', releaseAll);

    function setCfg(v) { cfg.ctl = v; try { localStorage.setItem('lounge.sumo.cfg', JSON.stringify(cfg)); } catch (e) {} releaseAll(); syncChip(); }
    const chip = L.h('button', { class: 'sm-chip', type: 'button', 'aria-label': '조작 방식 바꾸기', onclick() { api.sfx('click'); setCfg(cfg.ctl === 's' ? 't' : 's'); hintT = 3; } });
    chip.addEventListener('pointerdown', (e) => e.stopPropagation());
    root.appendChild(chip);
    function syncChip() {
      chip.innerHTML = '';
      chip.append('조작 ', L.h('b', { text: cfg.ctl === 's' ? '조이스틱' : '좌우 회전' }), ' ⇄');
      chip.hidden = !mine().length || !st || st.ph === 'pick' || st.ph === 'done';
    }

    /* ----- arena picker (host / local chooses; default random) ----- */
    function thumb(id, w, h2) {
      const c = L.h('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
      c.width = w * dpr; c.height = h2 * dpr;
      const A = ARENAS[id], B = arenaBox(A);
      const g = c.getContext('2d'), s = Math.min(w / (B.w + 16), h2 / (B.h + 16)) * dpr;
      g.translate(c.width / 2, c.height / 2); g.scale(s, s);
      const Wd = newWorld(id, 7, 2); Wd.t = { holes: 14, island: 30, drift: 7, mag: 3, tide: 10, windmill: 2 }[A.id] || 0;
      drawArena(g, Wd, (x) => x, (y) => y, 1, 0, true);
      return c;
    }
    function buildPicker() {
      if (pick) return;
      const canPick = host() && (mine().length > 0 || !api.online);
      const sub = L.h('div', { class: 'sub' }), grid = L.h('div', { class: 'sm-grid' }), btns = [];
      const mk = (id) => {
        const b = L.h('button', { class: 'sm-tk', 'aria-label': id < 0 ? '무작위 경기장' : ARENAS[id].name, disabled: !canPick },
          id < 0 ? L.h('div', { class: 'q', text: '?' }) : thumb(id, 40, 36), L.h('span', { text: id < 0 ? '무작위' : ARENAS[id].name }));
        b.onclick = () => { if (!canPick || !st || st.ph !== 'pick') return; api.sfx('click'); api.setState(Object.assign({}, st, { pk: id, ar: id < 0 ? -1 : id })); };
        btns.push({ id, b }); grid.append(b);
      };
      mk(-1); ARENAS.forEach((_, i) => mk(i));
      const seg = L.h('div', { class: 'seg', role: 'group', 'aria-label': '조작 방식' });
      const drawSeg = () => { seg.innerHTML = ''; for (const [v, t] of [['s', '조이스틱'], ['t', '좌우 회전']]) seg.append(L.h('button', { class: cfg.ctl === v ? 'on' : '', text: t, onclick() { api.sfx('click'); setCfg(v); drawSeg(); } })); };
      drawSeg();
      const go = L.h('button', { class: 'btn primary block', text: '시작', onclick() { if (!st || st.ph !== 'pick') return; api.sfx('click'); api.buzz(15); api.setState(dbgMap(startMatch(st))); } });
      const el = L.h('div', { class: 'sm-pick' }, L.h('h3', { text: '경기장 고르기' }), sub, grid,
        mine().length ? L.h('div', { class: 'sm-ctl' }, L.h('span', { class: 'lb', text: '조작' }), seg) : null,
        canPick ? go : L.h('div', { class: 'sub', text: '호스트가 경기장을 고르는 중…' }));
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el, sub, btns };
      syncPicker();
    }
    function syncPicker() {
      if (!pick || !st) return;
      const sel = st.pk == null ? -1 : st.pk;
      pick.btns.forEach(({ id, b }) => b.classList.toggle('on', id === sel));
      pick.sub.textContent = (sel < 0 ? (st.sw > 0 ? '무작위 · ' + (st.sw === 60 ? '1분' : '1분 30초') + '마다 다른 경기장으로 바뀌어요' : '무작위 · 경기장 하나로 끝까지') : ARENAS[sel].name + ' — ' + ARENAS[sel].sub) + ' · ' + Math.round(st.T / 60) + '분 · 목표 ' + (st.tm ? '팀 ' : '') + st.goal + '처치' + (st.tm ? ' · 팀전 ' + st.n / 2 + ':' + st.n / 2 : '');
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } }

    /* ----- feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 50)) return; lastSfx = t; api.sfx(n); }
    function sparks(x, y, col, n, sp) { for (let i = 0; i < n; i++) { const a = Math.random() * 7, v = sp * (0.4 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0.35 + Math.random() * 0.3, c: col }); } if (parts.length > 300) parts.splice(0, parts.length - 300); }
    const isMine = (seat) => mine().includes(seat);
    const POSTC = { p: '#7fe3ff', j: '#f0a8ff', t: '#e3ae45', f: '#ffe08a', l: '#ff5470', b: '#c4c9d2', c: '#d8dde5', u: '#ffd27a', r: '#e3ae45', a: '#d9b27a' };
    const postSfx = (k) => (k === 't' || k === 'b' || k === 'c' || k === 'r' ? 'thud' : k === 'f' || k === 'a' ? 'click' : k === 'l' ? 'hit' : 'bounce');
    let rings = []; // expanding circles / lines for power-up effects (world units)
    const hooks = {
      bump(a, b, v, refl) {
        sparks((a.x + b.x) / 2, (a.y + b.y) / 2, refl ? '#dfe6ee' : '#fff3cf', v > 120 ? 10 : 5, 60 + v * 0.4);
        if (v > 40) sfx(v > 150 ? 'thud' : 'hit', 60);
        if (refl) { rings.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, r0: 4, r1: 20, t: 0.3, T: 0.3, col: '#dfe6ee' }); sfx('chip', 60); }
        const meIn = isMine(a.seat) || isMine(b.seat);
        if (meIn) api.buzz(v > 150 ? 30 : 12);
        if (v > 90) shake = Math.min(1, shake + clamp((v - 90) / 220, 0, 0.6) * (meIn ? 1 : 0.6));
        // hit-stop: a short freeze on big hits (offline only, so online sync is untouched)
        if (!api.online && v > 150 && (meIn || v > 220)) { hstop = Math.max(hstop, Math.min(0.09, 0.03 + (v - 150) / 2500)); if (v > 200) flashA = Math.max(flashA, 0.18); }
        if (v > 200) { sparks((a.x + b.x) / 2, (a.y + b.y) / 2, '#ffd27a', 8, 160); rings.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, r0: 6, r1: 26, t: 0.25, T: 0.25, col: '#fff3cf' }); }
      },
      post(c, v, kind) {
        sparks(c.x, c.y, POSTC[kind] || '#7fe3ff', 8, 90);
        sfx(postSfx(kind), 60);
        if (isMine(c.seat)) api.buzz(kind === 't' || kind === 'b' || kind === 'c' ? 35 : 20);
        if (v > 80) shake = Math.min(1, shake + 0.3);
      },
      dash(c) { if (isMine(c.seat)) sfx('whoosh', 40); },
      jump(c) { sfx('bounce', 30); if (isMine(c.seat)) api.buzz(15); rings.push({ x: c.x, y: c.y, r0: 6, r1: 22, t: 0.35, T: 0.35, col: '#ffd84a' }); },
      land(c) { sparks(c.x, c.y, '#fff3cf', 6, 50); if (isMine(c.seat)) api.buzz(10); },
      blink(c, ox, oy) { sfx('whoosh', 20); if (isMine(c.seat)) api.buzz(20); rings.push({ x: ox, y: oy, x2: c.x, y2: c.y, line: 1, t: 0.4, T: 0.4, col: ITEMS.t.col }); sparks(ox, oy, ITEMS.t.col, 8, 70); sparks(c.x, c.y, ITEMS.t.col, 8, 70); },
      item(c, k, tg) {
        const I = ITEMS[k] || ITEMS.h, o = tg >= 0 && W ? W.cars[tg] : null;
        sfx({ w: 'thud', g: 'roll', o: 'pop', b: 'thud', t: 'pop', r: 'tick', k: 'pop', m: 'chip', n: 'roll', p: 'bounce', z: 'pop', v: 'whoosh', x: 'tick', u: 'chip', f: 'whoosh', y: 'pop', c: 'thud', i: 'pop' }[k] || 'chip', 40);
        floats.push({ x: c.x, y: c.y, text: I.nm + '!', col: I.col, t: 1.3, ik: k });
        if (isMine(c.seat)) { api.buzz(25); showBanner(k, I.nm, I.d); }
        if (o && isMine(o.seat) && VICTIM[k]) { api.buzz([30, 40, 30]); showBanner(k, I.nm + '!', VICTIM[k]); }
        if (o && k === 'z') { rings.push({ x: o.x, y: o.y, r0: CR * 2, r1: CR * 0.6, t: 0.35, T: 0.35, col: I.col }); rings.push({ x: c.x, y: c.y, x2: o.x, y2: o.y, line: 1, t: 0.35, T: 0.35, col: I.col }); }
        if (o && k === 'u') { sparks(o.x, o.y, '#e8f7ff', 10, 60); rings.push({ x: o.x, y: o.y, r0: 4, r1: 18, t: 0.35, T: 0.35, col: I.col }); }
        if (k === 'n') rings.push({ x: c.x, y: c.y, r0: MAGN_R, r1: 8, t: 0.5, T: 0.5, col: I.col });
        if (k === 'f' || k === 'y' || k === 'i' || k === 'p') rings.push({ x: c.x, y: c.y, r0: 6, r1: 22, t: 0.35, T: 0.35, col: I.col });
        if (k === 'c') { shake = Math.min(1, shake + 0.2); sparks(c.x + Math.cos(c.a) * 10, c.y + Math.sin(c.a) * 10, '#d8dde5', 8, 70); }
        if (k === 'w') { rings.push({ x: c.x, y: c.y, r0: 8, r1: WAVE_R, t: 0.45, T: 0.45, col: I.col }); shake = Math.min(1, shake + 0.4); for (const q of W ? W.cars : []) if (q !== c && q.alive && isMine(q.seat) && Math.hypot(q.x - c.x, q.y - c.y) < WAVE_R) api.buzz(40); }
        if (k === 'k') { rings.push({ x: c.x, y: c.y, r0: 10, r1: 95, t: 0.5, T: 0.5, col: I.col }); for (const q of W ? W.cars : []) if (q !== c && q.sk > 0 && isMine(q.seat)) { api.buzz(30); floats.push({ x: q.x, y: q.y + 14, text: '끈적!', col: I.col, t: 1 }); } }
        if (o && k === 'g') { rings.push({ x: c.x, y: c.y, x2: o.x, y2: o.y, line: 1, t: 0.45, T: 0.45, col: I.col }); if (isMine(o.seat)) api.buzz(40); }
        if (o && k === 'r') floats.push({ x: o.x, y: o.y + 14, text: '조작 반대로!', col: I.col, t: 1.4 });
        if (k === 'o' && W && W.oil) { rings.push({ x: W.oil.x, y: W.oil.y, r0: 4, r1: OIL_R, t: 0.3, T: 0.3, col: '#a9b8c6' }); if (o && isMine(o.seat)) api.buzz(25); }
        if (k === 'b') rings.push({ x: c.x, y: c.y, r0: CR, r1: CR * 2.4, t: 0.35, T: 0.35, col: I.col });
      },
      fall(c) { if (isMine(c.seat)) { api.buzz(90); } sfx('whoosh', 30); },
      blast(x, y, R) { // bomb going off
        sfx('thud', 20); shake = Math.min(1, shake + 0.55);
        rings.push({ x, y, r0: 6, r1: R, t: 0.4, T: 0.4, col: '#ffb347' }); sparks(x, y, '#ffb347', 16, 140); sparks(x, y, '#fff0a0', 8, 90);
        if (W && W.cars.some((q) => q.alive && isMine(q.seat) && Math.hypot(q.x - x, q.y - y) < R + 10)) api.buzz(50);
      },
      quake() { shake = 1; sfx('thud', 20); if (mine().length) api.buzz([40, 30, 40]); },
      out(c, by) { onOut(c.seat, by); },
      respawn(c) { respawned(c); },
      portal(c, ox, oy, pair) { const col = pair ? '#ffb02e' : '#7fd8ff'; sfx('whoosh', 30); rings.push({ x: ox, y: oy, r0: 4, r1: 18, t: 0.35, T: 0.35, col }); rings.push({ x: c.x, y: c.y, r0: 18, r1: 4, t: 0.35, T: 0.35, col }); if (isMine(c.seat)) api.buzz(15); },
    };
    let feed = [], lastTick = 0; // kill feed: {by, v, t}
    function onOut(seat, by) {
      if (isMine(seat)) { api.sfx('lose'); shake = 1; api.buzz([60, 40, 60]); }
      else if (by >= 0 && isMine(by)) { api.sfx('win'); api.haptic('win', [30, 30, 50]); }
      else sfx('thud', 40);
      const c = W && W.cars[seat];
      if (c && by >= 0 && isMine(by)) floats.push({ x: clamp(c.x, -90, 90), y: clamp(c.y, -110, 110), text: '+1 처치!', col: P(by).color, t: 1.6 });
      feed.push({ by, v: seat, t: 4.5 }); if (feed.length > 3) feed.shift();
      if (c) { rings.push({ x: clamp(c.x, -110, 110), y: clamp(c.y, -130, 130), r0: 8, r1: 40, t: 0.5, T: 0.5, col: P(seat).color }); setTimeout(() => api.sfx('thud'), 90); }
      if (isMine(seat) || (by >= 0 && isMine(by))) { flashA = Math.max(flashA, 0.3); if (!api.online) slowT = Math.max(slowT, 0.55); }
      if (host() && st && st.ph === 'play') api.setState(addKill(st, seat, by));
    }
    function respawned(c) {
      rings.push({ x: c.x, y: c.y, r0: 26, r1: 6, t: 0.45, T: 0.45, col: '#f2e9d8' }); sparks(c.x, c.y, P(c.seat).color, 10, 70);
      if (isMine(c.seat)) { api.sfx('pop'); api.buzz(20); }
    }
    const myCar = (s) => (W ? W.cars[s] : null);
    let banner = null; // what the item I just got (or that hit me) does
    function showBanner(k, title, desc) { banner = { k, title, desc, t: 1.6 }; } // 알림은 짧게(1.6초)·누르면 걷힘
    function drawBanner() {
      if (!banner || banner.t <= 0) return;
      const w = cv.w, x0 = chip.hidden ? 10 : Math.min(w - 200, chip.offsetLeft + chip.offsetWidth + 8), bw = Math.min(260, w - x0 - 8), y0 = 62, bh = 42;
      ctx.save(); ctx.globalAlpha = Math.min(1, banner.t * 3);
      const I = ITEMS[banner.k] || ITEMS.h;
      rrect(ctx, x0, y0, bw, bh, 12); ctx.fillStyle = 'rgba(23,19,31,.6)'; ctx.fill(); ctx.strokeStyle = I.col; ctx.lineWidth = 1.5; ctx.stroke();
      itemDisc(ctx, banner.k, x0 + 22, y0 + bh / 2, 14, 0);
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.font = '700 13px ' + FONT; ctx.fillStyle = I.col; ctx.fillText(banner.title, x0 + 42, y0 + 14, bw - 50);
      ctx.font = '600 11px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText(banner.desc, x0 + 42, y0 + 30, bw - 50);
      ctx.restore();
    }

    /* test hook: Lounge.debug.sumoMap = '<arena id>' forces that arena for the next rounds (headless screenshots) */
    function dbgMap(s) { const id = L.debug && L.debug.sumoMap, k = id ? ARENAS.findIndex((a) => a.id === id) : -1; return k >= 0 && s.ph === 'count' ? Object.assign({}, s, { ar: k }) : s; }
    /* ----- host: round flow ----- */
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'pick') {
        if (!pick) buildPicker();
        if (!mine().length) { hostT += dt; if (hostT > 1.5) { hostT = -1e9; api.setState(dbgMap(startMatch(st))); } }
        return;
      }
      if (!W) return;
      if (st.ph === 'count' && phase === 'play') { api.setState(Object.assign({}, st, { ph: 'play' })); return; }
      if (st.ph === 'play') {
        const el = st.mt0 + W.t;
        if (!st.ot && el >= st.T) api.setState(timeUp(st));
        else if (st.ot && el >= st.T + OT_MAX) api.setState(finish(st));
        else if (!st.ot && st.pk < 0 && st.sw > 0 && W.t >= st.sw && st.T - el > 20) api.setState(dbgMap(nextStage(st, el)));
      } else if (st.ph === 'end') {
        endT -= dt;
        if (endT <= 0) { endT = 1e9; api.setState(Object.assign({}, st, { ph: 'done' })); }
      }
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.cars.length) || simHere(s) || !o || o.k !== key) continue;
        remIn[s] = { x: clamp(+o.x || 0, -1, 1), y: clamp(+o.y || 0, -1, 1), t: clamp(+o.t || 0, -1, 1), m: o.m === 't' ? 't' : 's', d: o.d | 0 };
        if (fin(o.q)) iqOf[s] = o.q;
      }
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.c)) return;
      lastQ = hs.q;
      snaps.push({ at: now, c: hs.c }); if (snaps.length > 4) snaps.shift();
      if (fin(hs.t)) W.t = hs.t;
      if (fin(hs.th)) W.th = hs.th;
      if (fin(hs.wd)) W.wind = hs.wd;
      if (fin(hs.th2)) W.th2 = hs.th2;
      W.tw = Array.isArray(hs.tw) ? { x: +hs.tw[0] || 0, y: +hs.tw[1] || 0, vx: +hs.tw[2] || 0, vy: +hs.tw[3] || 0, t: +hs.tw[4] || 0, o: hs.tw[5] | 0 } : null;
      W.xb = Array.isArray(hs.xb) ? { x: +hs.xb[0] || 0, y: +hs.xb[1] || 0, t: +hs.xb[2] || 0, o: hs.xb[3] | 0 } : null;
      W.cb = Array.isArray(hs.cb) ? { x: +hs.cb[0] || 0, y: +hs.cb[1] || 0, vx: +hs.cb[2] || 0, vy: +hs.cb[3] || 0, t: 1, o: hs.cb[4] | 0 } : null;
      W.item = Array.isArray(hs.it) && ITEMS[hs.it[0]] ? { k: hs.it[0], x: +hs.it[1] || 0, y: +hs.it[2] || 0 } : null;
      W.oil = Array.isArray(hs.oil) ? { x: +hs.oil[0] || 0, y: +hs.oil[1] || 0, t: +hs.oil[2] || 0 } : null;
      if (Array.isArray(hs.bm) && hs.bm[0] !== lastBm) {
        lastBm = hs.bm[0]; const v = +hs.bm[1] || 0, kd = String(hs.bm[4] || '');
        if (kd && kd !== 'm') { sparks(+hs.bm[2] || 0, +hs.bm[3] || 0, POSTC[kd] || '#7fe3ff', 8, 90); sfx(postSfx(kd), 60); }
        else { sparks(+hs.bm[2] || 0, +hs.bm[3] || 0, kd ? '#dfe6ee' : '#fff3cf', v > 120 ? 10 : 5, 60 + v * 0.4); if (v > 40) sfx(v > 150 ? 'thud' : 'hit', 60); }
      }
      let evNew = null;
      if (Array.isArray(hs.ev) && hs.ev[0] !== lastEvQ) { if (lastEvQ !== -1 || hs.ev[0] !== 0) evNew = hs.ev; lastEvQ = hs.ev[0]; }
      hs.c.forEach((a, s) => {
        const c = W.cars[s];
        if (!c || !Array.isArray(a)) return;
        const fl = a[5] | 0, alive = !!(fl & 1);
        if (c.alive && !alive) { c.alive = false; onOut(s, fin(a[8]) ? a[8] : -1); }
        else if (!c.alive && alive) { c.alive = true; c.x = a[0]; c.y = a[1]; c.vx = a[2]; c.vy = a[3]; c.f = 0; respawned(c); }
        c.rs = +a[10] || 0; c.inv = fl & 2 ? Math.max(c.inv, 0.25) : 0;
        c.dt = fl & 8 ? 0.1 : 0;
        FX.forEach(([f], i) => { c[f] = fl & (1 << (i + 10)) ? Math.max(c[f], 0.25) : 0; });
        c.j = +a[9] || 0;
        c.f = +a[6] || 0;
        if (!isMine(s)) return;
        c.cd = +a[7] || 0;
        // reconcile my predicted car toward the host's (extrapolated by the one-way delay)
        if (hs.iq && fin(hs.iq[s]) && sendT[hs.iq[s]]) { const sm = (now - sendT[hs.iq[s]]) / 1000; if (sm > 0 && sm < 2) rtt = rtt * 0.85 + sm * 0.15; }
        const lag = Math.min(0.25, rtt / 2);
        const tx = a[0] + a[2] * lag, ty = a[1] + a[3] * lag;
        if (c.f > 0 || Math.hypot(tx - c.x, ty - c.y) > 40) { c.x = tx; c.y = ty; c.vx = a[2]; c.vy = a[3]; }
        else { c.x += (tx - c.x) * 0.35; c.y += (ty - c.y) * 0.35; c.vx += (a[2] - c.vx) * 0.5; c.vy += (a[3] - c.vy) * 0.5; }
      });
      if (evNew) { // replay the host's latest power-up / blink / jump effect
        const c = W.cars[evNew[2] | 0], k = String(evNew[1]);
        if (c) {
          if (k === 'T') hooks.blink(c, +evNew[4] || 0, +evNew[5] || 0);
          else if (k === 'P') hooks.portal(c, +evNew[4] || 0, +evNew[5] || 0, evNew[3] | 0);
          else if (k === 'X') hooks.blast(+evNew[4] || 0, +evNew[5] || 0, XB_R);
          else if (k === 'J') hooks.jump(c);
          else if (ITEMS[k]) { if (k === 'r' && W.cars[evNew[3]]) W.cars[evNew[3]].rv = 1; hooks.item(c, k, fin(evNew[3]) ? evNew[3] : -1); }
        }
      }
    }
    function interpOthers(now) {
      if (host() || !snaps.length || !W) return;
      const rt = now - 100;
      let A = null, B = snaps[snaps.length - 1], k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.25);
      W.cars.forEach((c, s) => {
        if (isMine(s)) return;
        const b = B.c[s], a = A ? A.c[s] : null;
        if (!Array.isArray(b)) return;
        if (a && Array.isArray(a) && Math.hypot(b[0] - a[0], b[1] - a[1]) < 60) { c.x = a[0] + (b[0] - a[0]) * k; c.y = a[1] + (b[1] - a[1]) * k; c.a = a[4] + wrapA(b[4] - a[4]) * k; }
        else { c.x = b[0]; c.y = b[1]; c.a = b[4]; }
        c.vx = b[2]; c.vy = b[3];
      });
    }
    function publish(rdt, now) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          const c = W.cars.map((q) => [r1(q.x), r1(q.y), Math.round(q.vx), Math.round(q.vy), r2(q.a), flagsOf(q), r2(q.f), r1(Math.max(0, q.cd)), q.alive ? -1 : q.by == null ? -1 : q.by, r2(Math.max(0, q.j)), r1(Math.max(0, q.rs))]);
          api.net.hostSend({ k: key, q: hsQ, t: r2(W.t), th: r2(W.th), th2: r2(W.th2 || 0), wd: Math.round(W.wind), it: W.item ? [W.item.k, W.item.x, W.item.y] : 0, oil: W.oil ? [W.oil.x, W.oil.y, r1(W.oil.t)] : 0,
            tw: W.tw ? [r1(W.tw.x), r1(W.tw.y), Math.round(W.tw.vx), Math.round(W.tw.vy), r1(W.tw.t), W.tw.o] : 0, xb: W.xb ? [W.xb.x, W.xb.y, r2(W.xb.t), W.xb.o] : 0, cb: W.cb ? [r1(W.cb.x), r1(W.cb.y), Math.round(W.cb.vx), Math.round(W.cb.vy), W.cb.o] : 0,
            c, bm: lastBump, ev: lastEv, iq: Object.assign({}, iqOf) });
        } else {
          const s = mine()[0];
          if (s == null) return;
          const I = locIn[s]; if (!I) return;
          const sig = I.x + '|' + I.y + '|' + I.t + '|' + I.m + '|' + I.d;
          if (sig === lastSig && inT > 0) return;
          lastSig = sig; inT = 0.15;
          inQ = (inQ + 1) % 100000; sendT[inQ] = now; delete sendT[(inQ + 99900) % 100000];
          api.net.publish({ k: key, q: inQ, x: I.x, y: I.y, t: I.t, m: I.m, d: I.d });
        }
      } catch (e) {}
    }
    let lastBump = [0, 0, 0, 0, ''], lastEv = [0, '', -1, -1, 0, 0];
    const evOut = (k, seat, tg, x, y) => { lastEv = [(lastEv[0] + 1) % 1000, k, seat, tg, r1(x), r1(y)]; };
    const hostHooks = Object.assign({}, hooks, {
      bump(a, b, v, refl) { hooks.bump(a, b, v, refl); lastBump = [(lastBump[0] + 1) % 1000, Math.round(v), r1((a.x + b.x) / 2), r1((a.y + b.y) / 2), refl ? 'm' : '']; },
      post(c, v, kind) { hooks.post(c, v, kind); lastBump = [(lastBump[0] + 1) % 1000, Math.round(v), r1(c.x), r1(c.y), kind || 'p']; },
      item(c, k, tg) { hooks.item(c, k, tg); evOut(k, c.seat, tg, c.x, c.y); },
      blink(c, ox, oy) { hooks.blink(c, ox, oy); evOut('T', c.seat, -1, ox, oy); },
      jump(c) { hooks.jump(c); evOut('J', c.seat, -1, c.x, c.y); },
      blast(x, y, R) { hooks.blast(x, y, R); if (R === XB_R) evOut('X', 0, -1, x, y); }, // arena bombs are replayed from the clock
      quake(an) { hooks.quake(an); },
      out(c, by) { c.by = by; hooks.out(c, by); },
      portal(c, ox, oy, pair) { hooks.portal(c, ox, oy, pair); evOut('P', c.seat, pair, ox, oy); },
    });

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      frameNo++;
      let sl = 1;
      if (hstop > 0) { hstop -= rdt; sl = 0; } else if (slowT > 0) { slowT -= rdt; sl = 0.35; }
      if (flashA > 0) flashA = Math.max(0, flashA - rdt * 1.5);
      const dt = rdt * SPD() * sl;
      if (mine().length) refresh(); // picks up gamepad stick changes every frame
      if (st.ph === 'pick') { if (!pick) buildPicker(); }
      else if (pick) dropPicker();
      if (W && phase === 'count') {
        const prevN = Math.ceil(cd); cd -= dt; const nowN = Math.ceil(cd);
        if (nowN !== prevN && nowN > 0) api.sfx('tick');
        if (cd <= 0) { phase = 'play'; api.sfx('pop'); api.buzz(20); }
      }
      if (hintT > 0) hintT -= rdt;
      if (banner) { banner.t -= rdt; if (banner.t <= 0) banner = null; }
      if (host()) {
        pollHost();
        if (W && phase === 'play' && st.ph !== 'end' && st.ph !== 'done') {
          W.lead = st.tm ? -1 : leadOf(st);
          W.cars.forEach((c, i) => {
            const p = api.players[i] || (st.tm && i < st.n ? { ai: true, lv: 2 } : null);
            if (!p) return;
            if (simHere(i)) {
              if (p.ai || !isMine(i) || (L.debug && L.debug.autoplay)) inputs[i] = aiThink(W, c, aiMem[i], p.ai ? (p.lv || 2) : 2, dt);
              else inputs[i] = locIn[i];
            } else inputs[i] = remIn[i];
          });
          acc += Math.min(dt, 0.25);
          let n = 0;
          while (acc >= H && n < 80) { stepWorld(W, inputs, hostHooks); acc -= H; n++; }
          maybeItem(W, dt, st.it);
        } else if (W && st.ph === 'end') {
          // the winner keeps rolling a little while the banner shows
          acc += Math.min(dt, 0.25); let n = 0;
          while (acc >= H && n < 80) { stepWorld(W, {}, null); acc -= H; n++; }
        }
        hostFlow(dt);
      } else if (W) {
        pollGuest(now);
        if (phase === 'play' && st.ph === 'play') {
          W.t += dt;
          tickMech(W);
          if (W.cb) { W.cb.x += W.cb.vx * dt; W.cb.y += W.cb.vy * dt; }
          if (W.tw) { W.tw.x += W.tw.vx * dt; W.tw.y += W.tw.vy * dt; }
          if (W.xb) W.xb.t = Math.max(0, W.xb.t - dt);
          for (const s of mine()) { const c = W.cars[s]; if (c && c.alive && c.f <= 0) { let k = Math.min(dt, 0.1); while (k > 1e-6) { const hh = Math.min(H * 2, k); stepCar(W, c, locIn[s], hh, null); k -= hh; } } else if (c && c.f > 0) c.f += dt; }
        }
        interpOthers(now);
      }
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vx *= 0.9; p.vy *= 0.9; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = feed.length - 1; i >= 0; i--) { feed[i].t -= rdt; if (feed[i].t <= 0) feed.splice(i, 1); }
      if (W && st.ph === 'play' && phase === 'play' && !st.ot) { // last ten seconds tick
        const left = Math.ceil(st.T - st.mt0 - W.t);
        if (left !== lastTick && left <= 10 && left > 0) api.sfx('tick');
        lastTick = left;
      }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t -= rdt; if (rings[i].t <= 0) rings.splice(i, 1); }
      if (W && phase === 'play' && st.ph === 'play') arenaCues();
      shake = Math.max(0, shake - rdt * 3);
      publish(rdt, now);
    }
    /* sounds / haptics when a timed arena mechanic changes (same on host and guests: all derived from W.t) */
    let cue = {};
    function arenaCues() {
      const A = W.A, myNear = (x, y, r) => mine().some((s) => { const c = W.cars[s]; return c && c.alive && c.f <= 0 && Math.hypot(c.x - x, c.y - y) < r; });
      if (A.vents) for (let k = 0; k < VENTS.length; k++) {
        const v = ventState(W, k), was = cue['v' + k] | 0;
        if (v !== was) {
          if (v === 1) { sfx('roll', 30); if (myNear(VENTS[k][0], VENTS[k][1], VENT_R + 6)) api.buzz(15); }
          if (v === 2) { sfx('thud', 30); sparks(VENTS[k][0], VENTS[k][1], '#ffb347', 14, 120); shake = Math.min(1, shake + 0.25); if (myNear(VENTS[k][0], VENTS[k][1], VENT_R + 4)) api.buzz(45); }
        }
        cue['v' + k] = v;
      }
      if (A.mag) { const m = magState(W), key2 = m.k + (m.warn ? 'w' : ''); if (cue.m != null && cue.m !== key2) sfx(m.warn ? 'tick' : 'roll', 30); cue.m = key2; }
      if (A.laser) { const z = laserOf(W), key2 = z.on ? 2 : z.warn ? 1 : 0; if (cue.l != null && key2 > cue.l) sfx(key2 === 2 ? 'whoosh' : 'tick', 30); cue.l = key2; }
      if (A.flip) { const up = flippers(W).some((f) => Math.abs(f[3]) > 0.5); if (up && !cue.f) sfx('click', 30); cue.f = up; }
      const chg = (id, v) => { const was = cue[id]; cue[id] = v; return was != null && was !== v; };
      if (A.piston) pistons(W).forEach((q, k) => { if (chg('p' + k, q[4]) && q[4]) { sfx(q[4] === 1 ? 'tick' : 'thud', 40); if (q[4] === 2 && myNear(q[0] * A.hw * 0.75, q[1], 40)) api.buzz(25); } });
      if (A.tide) { const u = tideU(W, W.t); if (chg('td', u.warn) && u.warn) { sfx('roll', 30); api.buzz(15); } }
      if (A.fans) { const f = W.fan || fanState(W), v = f.k < 0 ? 0 : f.warn ? 1 : 2; if (chg('fn', v) && v) sfx(v === 1 ? 'roll' : 'whoosh', 30); }
      if (A.pop) for (let k = 0; k < POPS.length; k++) { const v = popState(W, k).s; if (chg('o' + k, v) && v === 2) { sfx('pop', 40); sparks(POPS[k][0], POPS[k][1], '#ffd27a', 6, 70); if (myNear(POPS[k][0], POPS[k][1], PO_R + 12)) api.buzz(30); } }
      if (A.gust) { const g = gustAt(W, W.t), v = g.warn ? 1 : g.e > 0 ? 2 : 0; if (chg('gu', v) && v) sfx(v === 1 ? 'tick' : 'whoosh', 30); }
      if (A.quake) {
        const q = quakeOf(W); if (chg('qw', q.warn) && q.warn) { sfx('roll', 30); if (mine().length) api.buzz(15); }
        const k = W.t >= QK_T0 ? Math.floor((W.t - QK_T0) / QK_P) : -1; if (chg('qk', k) && k >= 1 && !host()) hooks.quake(quakeDir(W, k));
      }
      if (A.bombs) {
        const bs = bombsOf(W), top = bs.length ? bs[bs.length - 1][3] : -1;
        if (chg('ba', top) && top >= 0) sfx('tick', 40);
        const ex = W.t >= BB_T0 + BB_FUSE ? Math.floor((W.t - BB_T0 - BB_FUSE) / BB_P) : -1;
        if (chg('bx', ex) && ex >= 0 && !host()) { const p = bombPos(W, ex); hooks.blast(p[0], p[1], BB_R); }
      }
      if (A.trap) { let open = 0; for (const k in W.hidx) { const i = Math.floor(+k / 32) - 8, j = (+k % 32) - 8; if (holeState(W, i, j) === 2) open++; } const pv = cue.tp; cue.tp = open; if (pv != null && open > pv) sfx('click', 120); }
      if (A.dark) { const d = darkOf(W); if (cue.d != null && d !== cue.d) { if (d === 1) sfx('tick', 30); if (d === 2) { sfx('click', 30); api.buzz(12); } if (d === 0) sfx('pop', 30); } cue.d = d; }
    }

    /* ----- drawing ----- */
    function draw(now) {
      cv.clear();
      const w = cv.w, h = cv.h;
      if (!lay) layout();
      const A = W ? W.A : null;
      // backdrop
      const BG = { island: '#0d3346', ice: '#0c1828', jelly: '#0a2a44', lava: '#1c0a08', bhole: '#07050d', dark: '#08060c', drift: '#0b1a24', tide: '#1c0a08', blizzard: '#0e1a28', cross: '#0a0810', donut: '#0c0812' };
      ctx.fillStyle = (A && BG[A.id]) || '#110c17'; ctx.fillRect(0, 0, w, h);
      if (A && (A.id === 'lava' || A.id === 'tide')) { // glowing magma below
        const gr = ctx.createRadialGradient(w / 2, lay.cy, 40, w / 2, lay.cy, Math.max(w, h) * 0.7); gr.addColorStop(0, 'rgba(255,90,30,.35)'); gr.addColorStop(1, 'rgba(120,20,10,.1)');
        ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
      }
      if (A && (A.id === 'bhole')) { // star field swirling in
        for (let i = 0; i < 90; i++) { const r0 = (hash32(i, 21) % 1000) / 1000 * Math.max(w, h) * 0.75 + 40, a0 = hash32(i, 22) / 4294967296 * 7 + now / (6000 + r0 * 30); ctx.fillStyle = 'rgba(220,210,255,' + (0.15 + (i % 5) * 0.08) + ')'; ctx.fillRect(w / 2 + Math.cos(a0) * r0, lay.cy + Math.sin(a0) * r0, 1.5, 1.5); }
      } else if (A && (A.id === 'island' || A.id === 'jelly' || A.id === 'drift')) { // waves
        ctx.strokeStyle = 'rgba(140,210,230,.12)'; ctx.lineWidth = 2;
        for (let y = 10; y < h; y += 26) { ctx.beginPath(); for (let x = 0; x <= w; x += 12) { const yy = y + Math.sin(x / 30 + now / 600 + y) * 4; x ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy); } ctx.stroke(); }
      } else { // abyss dots
        ctx.fillStyle = 'rgba(171,159,184,.07)';
        for (let i = 0; i < 70; i++) { const x = (hash32(i, 3) % 1000) / 1000 * w, y = (hash32(i, 9) % 1000) / 1000 * h; ctx.fillRect(x, y, 1.5, 1.5); }
      }
      if (!W) { drawMystery(); return; }
      const fxk = L.fx ? L.fx() : 1, sx = shake > 0 ? (Math.random() - 0.5) * shake * 7 * fxk : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 7 * fxk : 0;
      ctx.save(); ctx.translate(lay.cx + sx, lay.cy + sy); ctx.scale(lay.s, lay.s);
      drawArena(ctx, W, (x) => x, (y) => y, 1, now, false);
      // item
      if (W.item) {
        const it = W.item, I = ITEMS[it.k] || ITEMS.h, bob = Math.sin(now / 200) * 1.2;
        ctx.save(); ctx.translate(it.x, it.y + bob);
        ctx.beginPath(); ctx.arc(0, 0, 11 + Math.sin(now / 160) * 1.2, 0, 7); ctx.strokeStyle = hexA(I.col, 0.5); ctx.lineWidth = 1; ctx.stroke();
        ctx.restore();
        itemDisc(ctx, it.k, it.x, it.y + bob, 8.5, 10);
      }
      drawObjects(now);
      // cars: falling ones first (they are below the floor)
      const order = W.cars.filter((c) => c.alive).sort((a, b) => (b.f > 0) - (a.f > 0));
      for (const c of order) drawCar(c, now);
      for (const p of parts) { ctx.globalAlpha = Math.min(1, p.t * 3); ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, 1.4, 0, 7); ctx.fill(); }
      for (const r of rings) {
        const k = 1 - r.t / r.T;
        ctx.globalAlpha = Math.min(1, r.t / r.T * 1.6);
        ctx.strokeStyle = r.col; ctx.lineWidth = r.line ? 2.2 : 2.5 * (1 - k) + 0.5;
        ctx.beginPath();
        if (r.line) { ctx.setLineDash([3, 3]); ctx.moveTo(r.x, r.y); ctx.lineTo(r.x2, r.y2); ctx.stroke(); ctx.setLineDash([]); }
        else { ctx.arc(r.x, r.y, r.r0 + (r.r1 - r.r0) * k, 0, 7); ctx.stroke(); }
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      if (W.A.dark) drawDark(now);
      // floating texts (screen space)
      for (const f of floats) {
        ctx.globalAlpha = Math.min(1, f.t * 2);
        const fy = Y(f.y) - 24 - (1.8 - f.t) * 18;
        const fx2 = clamp(X(f.x), 90, w - 90), fy2 = clamp(fy, 80, h - 60);
        txt(f.text, fx2 + (f.ik ? 11 : 0), fy2, f.col, '700 14px ' + FONT, 0);
        if (f.ik) { ctx.font = '700 14px ' + FONT; itemDisc(ctx, f.ik, fx2 + 11 - ctx.measureText(f.text).width / 2 - 13, fy2, 9, 0); }
      }
      ctx.globalAlpha = 1;
      if (flashA > 0) { ctx.fillStyle = "rgba(255,246,220," + (flashA * fxk).toFixed(3) + ")"; ctx.fillRect(0, 0, w, h); }
      drawHud(now);
    }
    /* power-up objects on the floor (world units) */
    function drawObjects(now) {
      const xb = W.xb;
      if (xb) { // bomb: blast-radius ring that fills up as the fuse burns
        const p = clamp(1 - xb.t / ITEMS.x.T, 0, 1), blinkOn = Math.sin(now / (60 + 140 * (1 - p))) > 0;
        ctx.beginPath(); ctx.arc(xb.x, xb.y, XB_R, 0, 7); ctx.fillStyle = 'rgba(255,122,61,' + (0.06 + 0.12 * p) + ')'; ctx.fill();
        ctx.setLineDash([4, 4]); ctx.strokeStyle = 'rgba(255,122,61,.75)'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.setLineDash([]);
        ctx.beginPath(); ctx.arc(xb.x, xb.y, XB_R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p); ctx.strokeStyle = '#ff7a3d'; ctx.lineWidth = 2.2; ctx.stroke();
        ctx.beginPath(); ctx.arc(xb.x, xb.y, 7, 0, 7); ctx.fillStyle = '#26222c'; ctx.fill(); ctx.strokeStyle = blinkOn ? '#ffd27a' : '#5a4a3a'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.beginPath(); ctx.arc(xb.x + 4.5, xb.y - 5.5, 2, 0, 7); ctx.fillStyle = blinkOn ? '#fff0a0' : '#ff7a3d'; ctx.fill();
      }
      const tw = W.tw;
      if (tw) { // whirlwind: spinning arcs
        const fade = Math.min(1, tw.t * 2);
        ctx.save(); ctx.translate(tw.x, tw.y); ctx.globalAlpha = 0.9 * fade;
        ctx.beginPath(); ctx.arc(0, 0, TW_R, 0, 7); ctx.fillStyle = 'rgba(127,224,196,.16)'; ctx.fill();
        ctx.rotate(now / 90); ctx.strokeStyle = '#7fe0c4'; ctx.lineCap = 'round';
        for (let i = 0; i < 4; i++) { const r = TW_R * (0.35 + i * 0.2); ctx.lineWidth = 2.2 - i * 0.35; ctx.beginPath(); ctx.arc(0, 0, r, i * 1.7, i * 1.7 + 3.4); ctx.stroke(); }
        ctx.lineCap = 'butt'; ctx.restore();
      }
      const cb = W.cb;
      if (cb) { // cannonball with a smoke trail
        const v = Math.hypot(cb.vx, cb.vy) || 1, ux = cb.vx / v, uy = cb.vy / v;
        const gr = ctx.createLinearGradient(cb.x - ux * 26, cb.y - uy * 26, cb.x, cb.y); gr.addColorStop(0, 'rgba(200,200,210,0)'); gr.addColorStop(1, 'rgba(220,220,230,.55)');
        ctx.strokeStyle = gr; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(cb.x - ux * 26, cb.y - uy * 26); ctx.lineTo(cb.x, cb.y); ctx.stroke(); ctx.lineCap = 'butt';
        ctx.beginPath(); ctx.arc(cb.x, cb.y, 4.5, 0, 7); ctx.fillStyle = '#2a2d36'; ctx.fill(); ctx.strokeStyle = '#8e9aaa'; ctx.lineWidth = 1; ctx.stroke();
        ctx.beginPath(); ctx.arc(cb.x - 1.4, cb.y - 1.4, 1.3, 0, 7); ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.fill();
      }
    }
    let dk = null;
    function drawDark(now) { // lights out: only headlights and a faint neon rim stay visible
      const d = darkOf(W);
      if (!d) return;
      const a = d === 2 ? 0.95 : (Math.sin(now / 45) > 0.2 ? 0.75 : 0);
      if (!a) return;
      const w = cv.w, h = cv.h, dpr = cv.dpr;
      if (!dk) dk = document.createElement('canvas');
      if (dk.width !== Math.round(w * dpr) || dk.height !== Math.round(h * dpr)) { dk.width = Math.round(w * dpr); dk.height = Math.round(h * dpr); }
      const g = dk.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0); g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, w, h);
      g.fillStyle = 'rgba(4,3,8,' + a + ')'; g.fillRect(0, 0, w, h);
      g.globalCompositeOperation = 'destination-out';
      for (const c of W.cars) {
        if (!c.alive || (c.iv > 0 && !isMine(c.seat))) continue;
        const x = X(c.x), y = Y(c.y), r = rad(c) * lay.s;
        const rg = g.createRadialGradient(x, y, r, x, y, r * 2.6); rg.addColorStop(0, 'rgba(0,0,0,1)'); rg.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = rg; g.beginPath(); g.arc(x, y, r * 2.6, 0, 7); g.fill();
        const L2 = 62 * lay.s, cg = g.createRadialGradient(x, y, r, x, y, L2); cg.addColorStop(0, 'rgba(0,0,0,.9)'); cg.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = cg; g.beginPath(); g.moveTo(x, y); g.arc(x, y, L2, c.a - 0.42, c.a + 0.42); g.closePath(); g.fill();
      }
      if (W.item) { const x = X(W.item.x), y = Y(W.item.y), r = 12 * lay.s; const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, 'rgba(0,0,0,.8)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = rg; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); }
      g.globalCompositeOperation = 'source-over';
      ctx.drawImage(dk, 0, 0, w, h);
      // neon rim
      const sc = sudden(W), hw = W.A.hw * sc * lay.s, hh = W.A.hh * sc * lay.s;
      ctx.strokeStyle = 'rgba(180,140,240,' + (d === 2 ? 0.35 : 0.2) + ')'; ctx.lineWidth = 1.5; ctx.setLineDash([6, 6]);
      ctx.strokeRect(lay.cx - hw, lay.cy - hh, hw * 2, hh * 2); ctx.setLineDash([]);
    }
    function drawMystery() {
      if (!st || st.ph !== 'pick') return;
      const top = pick ? pick.el.offsetTop : cv.h, R = Math.min(70, top / 2 - 24);
      if (R < 24) return;
      ctx.save(); ctx.translate(cv.w / 2, top / 2); ctx.scale(R / 70, R / 70);
      ctx.beginPath(); ctx.arc(0, 0, 70, 0, 7); ctx.fillStyle = 'rgba(46,38,64,.8)'; ctx.fill();
      ctx.setLineDash([8, 8]); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 3; ctx.stroke(); ctx.setLineDash([]);
      ctx.font = '56px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#e3ae45'; ctx.fillText('?', 0, 4);
      ctx.restore();
    }
    function drawCar(c, now) {
      const col = P(c.seat).color || '#ccc';
      const fall = c.f > 0 ? clamp(c.f / FALL_T, 0, 1) : 0;
      const air = c.j > 0 ? Math.sin(Math.PI * clamp(1 - c.j / AIR_T, 0, 1)) : 0;
      const sc = (1 - fall * 0.65) * (rad(c) / CR) * (1 + air * 0.4);
      // 투명: almost invisible to the others, see-through for me; 유령: translucent
      const vis = c.iv > 0 ? (isMine(c.seat) ? 0.4 : 0.06 + (Math.hypot(c.vx, c.vy) > 120 ? 0.08 : 0)) : c.gh > 0 ? 0.5 + 0.12 * Math.sin(now / 120) : 1;
      if (vis < 1) ctx.save(), ctx.globalAlpha = vis;
      if (c.mg > 0 && !fall && vis > 0.3) { // magnet field
        ctx.save(); ctx.strokeStyle = 'rgba(224,80,122,.5)'; ctx.lineWidth = 1;
        for (let i = 0; i < 3; i++) { const r = MAGN_R * (1 - frac(now / 900 + i / 3)); ctx.globalAlpha = 0.5 * r / MAGN_R * vis; ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, 7); ctx.stroke(); }
        ctx.restore();
      }
      if (c.tb > 0 && !fall && Math.hypot(c.vx, c.vy) > 30) { // turbo flames
        const v = Math.hypot(c.vx, c.vy), ux = c.vx / v, uy = c.vy / v, L2 = rad(c) + 6 + Math.random() * 6;
        ctx.beginPath(); ctx.moveTo(c.x - uy * 4, c.y + ux * 4); ctx.lineTo(c.x - ux * (rad(c) + L2), c.y - uy * (rad(c) + L2)); ctx.lineTo(c.x + uy * 4, c.y - ux * 4); ctx.closePath();
        ctx.fillStyle = 'rgba(255,176,46,.75)'; ctx.fill();
      }
      if (air) { ctx.beginPath(); ctx.ellipse(c.x + 2 + air * 8, c.y + 3 + air * 10, CR * (1 - air * 0.3), CR * 0.9 * (1 - air * 0.3), 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,' + (0.4 - air * 0.2) + ')'; ctx.fill(); }
      ctx.save(); ctx.translate(c.x, c.y); ctx.scale(sc, sc);
      ctx.globalAlpha = (1 - fall * 0.6) * vis;
      if (!fall && !air) { ctx.beginPath(); ctx.ellipse(1.2, 2.2, CR + 1, CR * 0.95, 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.fill(); }
      if (c.dt > 0) { ctx.save(); ctx.rotate(Math.atan2(c.vy, c.vx)); ctx.strokeStyle = 'rgba(255,243,207,.55)'; ctx.lineWidth = 1.2; for (const o of [-4, 0, 4]) { ctx.beginPath(); ctx.moveTo(-CR - 2, o); ctx.lineTo(-CR - 12 - Math.random() * 6, o); ctx.stroke(); } ctx.restore(); }
      // rubber bumper ring
      ctx.beginPath(); ctx.arc(0, 0, CR, 0, 7); ctx.fillStyle = c.hv > 0 ? '#8a8f99' : '#2a2230'; ctx.fill();
      ctx.lineWidth = c.hv > 0 ? 1.6 : 0.8; ctx.strokeStyle = c.hv > 0 ? '#e3ae45' : 'rgba(0,0,0,.6)'; ctx.stroke();
      ctx.rotate(c.a);
      // body
      const g = ctx.createRadialGradient(-2, -2, 1, 0, 0, CR * 0.85);
      g.addColorStop(0, shade(col, 0.4)); g.addColorStop(1, shade(col, -0.15));
      ctx.beginPath(); ctx.arc(0, 0, CR * 0.78, 0, 7); ctx.fillStyle = g; ctx.fill();
      // nose + seat + driver
      ctx.beginPath(); ctx.moveTo(CR * 0.86, 0); ctx.lineTo(CR * 0.42, -CR * 0.36); ctx.lineTo(CR * 0.42, CR * 0.36); ctx.closePath(); ctx.fillStyle = '#f2e9d8'; ctx.fill();
      ctx.beginPath(); ctx.arc(-CR * 0.18, 0, CR * 0.36, 0, 7); ctx.fillStyle = shade(col, -0.45); ctx.fill();
      ctx.beginPath(); ctx.arc(-CR * 0.12, 0, CR * 0.22, 0, 7); ctx.fillStyle = '#f2e0c8'; ctx.fill();
      ctx.restore();
      if (c.fz > 0 && !fall) { // ice block
        ctx.save(); ctx.translate(c.x, c.y); const q = (CR + 2.5) * sc;
        rrect(ctx, -q, -q, q * 2, q * 2, 3); ctx.fillStyle = 'rgba(190,230,255,.55)'; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(-q * 0.6, -q * 0.2); ctx.lineTo(-q * 0.1, -q * 0.7); ctx.strokeStyle = 'rgba(255,255,255,.8)'; ctx.stroke(); ctx.restore();
      }
      if (c.sh > 0) { ctx.save(); ctx.translate(c.x, c.y); ctx.beginPath(); ctx.arc(0, 0, (CR + 3) * sc, 0, 7); ctx.strokeStyle = 'rgba(127,227,255,' + (0.55 + 0.3 * Math.sin(now / 90)) + ')'; ctx.lineWidth = 1.6; ctx.stroke(); ctx.fillStyle = 'rgba(127,227,255,.12)'; ctx.fill(); ctx.restore(); }
      if (!fall) { // other effect badges
        const R = (CR + 3) * sc;
        ctx.save(); ctx.translate(c.x, c.y);
        if (c.rf > 0) { // reflect armour: silver hexagon
          ctx.beginPath(); for (let i = 0; i < 6; i++) { const an = i * Math.PI / 3 + now / 900; i ? ctx.lineTo(Math.cos(an) * R, Math.sin(an) * R) : ctx.moveTo(Math.cos(an) * R, Math.sin(an) * R); } ctx.closePath();
          ctx.strokeStyle = 'rgba(223,230,238,.9)'; ctx.lineWidth = 1.4; ctx.stroke(); ctx.fillStyle = 'rgba(223,230,238,.1)'; ctx.fill();
        }
        if (c.sk > 0) { // sticky goo
          ctx.fillStyle = 'rgba(143,211,95,.55)'; for (let i = 0; i < 6; i++) { const an = i * 1.05 + 0.4; ctx.beginPath(); ctx.arc(Math.cos(an) * R * 0.95, Math.sin(an) * R * 0.95, 2.1, 0, 7); ctx.fill(); }
          ctx.beginPath(); ctx.arc(0, 0, R * 0.98, 0, 7); ctx.strokeStyle = 'rgba(143,211,95,.7)'; ctx.lineWidth = 1.2; ctx.stroke();
        }
        if (c.rv > 0) { // reversed controls: two chasing arrows
          ctx.rotate(-now / 260); ctx.strokeStyle = '#f07fb8'; ctx.lineWidth = 1.4;
          for (const o of [0, Math.PI]) { ctx.beginPath(); ctx.arc(0, 0, R + 1.5, o, o + 1.9); ctx.stroke(); const ex = Math.cos(o + 1.9) * (R + 1.5), ey = Math.sin(o + 1.9) * (R + 1.5); ctx.beginPath(); ctx.arc(ex, ey, 1.6, 0, 7); ctx.fillStyle = '#f07fb8'; ctx.fill(); }
        }
        if (c.bk > 0) { // blink charge: orbiting sparks
          ctx.fillStyle = ITEMS.t.col; for (let i = 0; i < 3; i++) { const an = now / 200 + i * 2.09; ctx.beginPath(); ctx.arc(Math.cos(an) * (R + 2), Math.sin(an) * (R + 2), 1.4, 0, 7); ctx.fill(); }
        }
        if (c.sp > 0) { // spring charge: a bouncing coil ring
          ctx.strokeStyle = ITEMS.p.col; ctx.lineWidth = 1.2; ctx.beginPath();
          for (let i = 0; i <= 24; i++) { const an = i / 24 * Math.PI * 2, rr = R + 2 + Math.sin(an * 8 + now / 80) * 1.4; i ? ctx.lineTo(Math.cos(an) * rr, Math.sin(an) * rr) : ctx.moveTo(Math.cos(an) * rr, Math.sin(an) * rr); }
          ctx.stroke();
        }
        ctx.restore();
      }
      if (c.inv > 0 && !fall) { // spawn shield: blinking white bubble
        ctx.beginPath(); ctx.arc(c.x, c.y, rad(c) + 4, 0, 7); ctx.strokeStyle = 'rgba(242,233,216,' + (0.45 + 0.4 * Math.sin(now / 70)) + ')'; ctx.lineWidth = 1.8; ctx.stroke();
        ctx.fillStyle = 'rgba(242,233,216,.12)'; ctx.fill();
      }
      if (vis < 1) ctx.restore();
      // ring for my car(s) + name above others
      if (!fall) {
        if (isMine(c.seat)) { ctx.beginPath(); ctx.arc(c.x, c.y, rad(c) + 2.5, 0, 7); ctx.strokeStyle = 'rgba(242,233,216,.8)'; ctx.lineWidth = 0.9; ctx.setLineDash([2.5, 2]); ctx.stroke(); ctx.setLineDash([]); }
      }
    }
    function txt(t, x, y, col, font, rot) {
      ctx.save(); ctx.translate(x, y); if (rot) ctx.rotate(rot);
      ctx.font = font; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,8,16,.8)'; ctx.strokeText(t, 0, 0); ctx.fillStyle = col; ctx.fillText(t, 0, 0);
      ctx.restore();
    }
    function drawHud(now) {
      const w = cv.w, h = cv.h, m = mine();
      if (!st) return;
      // name tags (screen space, readable)
      if (W) for (const c of W.cars) {
        if (!c.alive || c.f > 0) continue;
        if (W.A.dark && darkOf(W) === 2 && !isMine(c.seat)) continue; // lights out: no name tags for the others
        if (c.iv > 0 && !isMine(c.seat)) continue; // 투명
        txt(name(c.seat), X(c.x), Y(c.y) - (rad(c) * lay.s * (c.j > 0 ? 1.4 : 1) + 9), P(c.seat).color, '700 10.5px ' + FONT, 0);
      }
      // top-left: arena + kills per player · top-right: clock + goal
      const el = W && st.ph !== 'pick' ? st.mt0 + (phase === 'play' ? W.t : 0) : 0, left = st.T - el;
      const panel = () => {
        ctx.save();
        let title = st.ar >= 0 ? ARENAS[st.ar].name : st.pk < 0 ? '무작위 경기장' : '';
        if (st.tm) { const tk = [0, 0]; st.tm.forEach((m, i) => { tk[m] += st.k[i] | 0; }); title = '빨강 ' + tk[0] + ' : ' + tk[1] + ' 파랑'; }
        ctx.font = '700 13px ' + FONT;
        const bw = Math.min(w - 112, Math.max(ctx.measureText(title).width + 24, st.n * 32 + 20));
        rrect(ctx, 8, 8, bw, 48, 12); ctx.fillStyle = 'rgba(23,19,31,.78)'; ctx.fill();
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(title, 18, 21, bw - 20);
        let x = 18; ctx.font = '700 12px ' + MONO;
        const lead = leadOf(st);
        for (let s = 0; s < st.n; s++) {
          const c = W && W.cars[s], alive = !W || (c && c.alive);
          ctx.globalAlpha = alive ? 1 : 0.4;
          ctx.beginPath(); ctx.arc(x + 5, 42, 5, 0, 7); ctx.fillStyle = P(s).color; ctx.fill();
          if (isMine(s)) { ctx.lineWidth = 2; ctx.strokeStyle = '#f2e9d8'; ctx.stroke(); }
          ctx.fillStyle = s === lead && st.k[s] > 0 ? '#e3ae45' : '#f2e9d8'; ctx.fillText(String(st.k[s] | 0), x + 13, 42.5);
          x += 32;
        }
        ctx.globalAlpha = 1;
        // clock
        const cx0 = w - 100;
        rrect(ctx, cx0, 8, 92, 48, 12); ctx.fillStyle = 'rgba(23,19,31,.78)'; ctx.fill();
        if (st.ot) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 1.5; ctx.stroke(); }
        ctx.textAlign = 'center';
        const hot = !st.ot && left <= 10 && st.ph === 'play';
        ctx.font = '700 19px ' + MONO; ctx.fillStyle = st.ot ? '#ee6a55' : hot ? (Math.sin(now / 120) > 0 ? '#ee6a55' : '#f2e9d8') : '#f2e9d8';
        ctx.fillText(st.ot ? '연장' : fmtT(left), cx0 + 46, 25);
        ctx.font = '600 11px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.fillText('목표 ' + st.goal + '처치', cx0 + 46, 45);
        ctx.restore();
      };
      panel();
      // kill feed (right side, under the clock) — hidden while an item banner is up
      if (feed.length && !(banner && banner.t > 0)) {
        ctx.save(); ctx.font = '700 11px ' + FONT; ctx.textBaseline = 'middle';
        let y = 72;
        for (let i = feed.length - 1; i >= 0; i--) {
          const f = feed[i], parts2 = f.by >= 0 ? [[name(f.by), P(f.by).color], [' → ', '#ab9fb8'], [name(f.v), P(f.v).color]] : [[name(f.v), P(f.v).color], [' 낙하', '#ab9fb8']];
          const tw = parts2.reduce((a, q) => a + ctx.measureText(q[0]).width, 0) + 16;
          ctx.globalAlpha = Math.min(1, f.t * 2);
          rrect(ctx, w - 8 - tw, y - 9, tw, 18, 9); ctx.fillStyle = 'rgba(23,19,31,.8)'; ctx.fill();
          let x = w - 8 - tw + 8; ctx.textAlign = 'left';
          for (const q of parts2) { ctx.fillStyle = q[1]; ctx.fillText(q[0], x, y + 0.5); x += ctx.measureText(q[0]).width; }
          y += 21;
        }
        ctx.restore();
      }
      // wind warning
      if (W && W.A.wind && st.ph === 'play') {
        const wa = windAt(W, W.t);
        const dir = wa.warn || (Math.abs(wa.w) > 5 ? Math.sign(wa.w) : 0);
        if (dir) {
          ctx.globalAlpha = wa.warn ? 0.5 + 0.5 * Math.sin(now / 80) : 0.9;
          for (const yy of [lay.cy - 60, lay.cy, lay.cy + 60]) {
            const xx = dir > 0 ? X(-W.A.hw) - 16 : X(W.A.hw) + 16;
            ctx.beginPath(); ctx.moveTo(xx - 10 * dir, yy - 12); ctx.lineTo(xx + 6 * dir, yy); ctx.lineTo(xx - 10 * dir, yy + 12);
            ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = wa.warn ? '#ee6a55' : '#cfe8ff'; ctx.stroke();
          }
          ctx.globalAlpha = 1;
        }
      }
      // controls for the humans on this phone
      if (W && st.ph !== 'pick' && st.ph !== 'done') for (const s of m) drawControls(s, now);
      if (W && st.ph === 'play' && m.length) drawBanner();
      // countdown / banners
      const bigs = (t, col, size, yk) => txt(t, w / 2, h * (yk || 0.42), col, size + 'px ' + DISP, 0);
      if (W && phase === 'count' && st.ph === 'count') {
        const n = Math.max(1, Math.ceil(cd));
        bigs(String(n), '#f2e9d8', 64, st.rd === 1 ? 0.53 : 0.44);
        bigs(ARENAS[st.ar].name, '#e3ae45', 22, 0.3);
        txt(ARENAS[st.ar].sub, w / 2, h * 0.3 + 26, '#ab9fb8', '600 12px ' + FONT, 0);
        if (st.rd === 1 && st.tm) { const me = m[0]; txt(me != null && st.tm[me] != null ? '나는 ' + TEAMN[st.tm[me]] + ' · 아군끼리는 살짝만 밀려요' : '팀전 · 아군끼리는 살짝만 밀려요', w / 2, h * 0.3 + 48, me != null && st.tm[me] != null ? TEAMC[st.tm[me]][0] : '#f2e9d8', '700 12px ' + FONT, 0); txt('팀 처치 합 ' + st.goal + ' 먼저, 또는 ' + Math.round(st.T / 60) + '분 뒤 많은 팀 우승', w / 2, h * 0.3 + 66, '#e3ae45', '700 12px ' + FONT, 0); }
        else if (st.rd === 1) { txt('떨어뜨리면 +1 처치 · 떨어져도 부활해요', w / 2, h * 0.3 + 48, '#f2e9d8', '700 12px ' + FONT, 0); txt(st.goal + '처치 먼저, 또는 ' + Math.round(st.T / 60) + '분 뒤 처치 1등이 우승', w / 2, h * 0.3 + 66, '#e3ae45', '700 12px ' + FONT, 0); }
      }
      if (W && phase === 'count' && st.ph === 'count' && st.rd > 1) bigs('경기장이 바뀌었어요!', '#f2e9d8', 16, 0.24);
      if (st.ph === 'end' && st.tm) bigs(st.rt >= 0 ? TEAMN[st.rt] + ' 우승!' : '무승부!', st.rt >= 0 ? TEAMC[st.rt][0] : '#f2e9d8', 28, 0.4);
      else if (st.ph === 'end') { bigs(st.rw >= 0 ? name(st.rw) + ' 우승!' : '공동 우승!', st.rw >= 0 ? P(st.rw).color : '#f2e9d8', 28, 0.4); if (st.rw >= 0 && st.k[st.rw] >= st.goal) txt('목표 ' + st.goal + '처치 달성', w / 2, h * 0.4 + 30, '#e3ae45', '700 14px ' + FONT, 0); }
      if (W && st.ph === 'play') {
        if (st.ot) txt('연장전! 다음 처치로 결판', w / 2, h * 0.3, '#ee6a55', '700 15px ' + FONT, 0);
        else if (st.pk < 0 && st.sw > 0 && st.T - el > 20 && st.sw - W.t < 5 && st.sw - W.t > 0) txt('곧 경기장이 바뀌어요 ' + Math.ceil(st.sw - W.t), w / 2, h * 0.3, '#e3ae45', '700 14px ' + FONT, 0);
        for (const s of m) { const c = W.cars[s]; if (c && !c.alive && c.rs > 0) { bigs('부활 ' + Math.max(1, Math.ceil(c.rs)), '#f2e9d8', 34, 0.42); txt('잠깐 뒤 안전한 자리에서 다시 나와요', w / 2, h * 0.42 + 30, '#ab9fb8', '600 12px ' + FONT, 0); } }
      }
      if (hintT > 0 && st.ph !== 'pick') {
        ctx.globalAlpha = Math.min(1, hintT);
        for (const s of m) {
          const t1 = cfg.ctl === 's' ? '왼쪽: 엄지를 대고 밀면 그쪽으로' : '왼쪽 ◀ ▶: 회전 (자동 전진)';
          const t2 = '오른쪽 아무 데나 톡: 돌진!';
          ctx.save();
          ctx.font = '600 13px ' + FONT;
          const bw = Math.min(w - 20, Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width) + 26), y0 = h - 190;
          rrect(ctx, (w - bw) / 2, y0, bw, 48, 14); ctx.fillStyle = 'rgba(23,19,31,.85)'; ctx.fill();
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t1, w / 2, y0 + 15); ctx.fillStyle = '#e3ae45'; ctx.fillText(t2, w / 2, y0 + 34);
          ctx.restore();
        }
        ctx.globalAlpha = 1;
      }
    }
    function drawControls(s, now) {
      const w = cv.w, h = cv.h, c = W.cars[s], col = P(s).color;
      ctx.save();
      const dead = !c || !c.alive;
      ctx.globalAlpha = dead ? 0.3 : 1;
      // dash button with cooldown ring
      const b = dashBtn(s), ready = c && c.cd <= 0;
      const pressed = [...ptrs.values()].some((p) => p.seat === s && p.kind === 'dash');
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r * (pressed ? 0.93 : 1), 0, 7); ctx.fillStyle = ready ? hexA(col, 0.85) : 'rgba(46,38,64,.85)'; ctx.fill();
      ctx.lineWidth = 3; ctx.strokeStyle = ready ? '#fff3cf' : 'rgba(242,233,216,.25)'; ctx.stroke();
      if (c && !ready) { ctx.beginPath(); ctx.arc(b.x, b.y, b.r - 1.5, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - clamp(c.cd / DASH_CD, 0, 1))); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.stroke(); }
      const chg = c && c.bk > 0 ? 't' : c && c.sp > 0 ? 'p' : null, frozen = c && c.fz > 0;
      if (chg && ready) { ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 4 + Math.sin(now / 120) * 1.5, 0, 7); ctx.strokeStyle = ITEMS[chg].col; ctx.lineWidth = 2.5; ctx.stroke(); }
      ctx.font = '19px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = ready && !frozen ? '#17131f' : '#ab9fb8';
      if (chg) { itemDisc(ctx, chg, b.x, b.y - 9, 11, 0); ctx.font = '15px ' + DISP; ctx.fillText(chg === 't' ? '순간' : '점프', b.x, b.y + 13); }
      else ctx.fillText(frozen ? '꽁꽁' : '돌진', b.x, b.y + 1);
      L.ui.drawKeyBadge(ctx, b.x + b.r + 8, b.y + b.r + 4, L.ui.keyLabel('sumo', 'dash'));
      // my active power-ups (icon + name + seconds), stacked above the dash button
      if (c && c.alive) {
        const fx = FX.filter(([f]) => c[f] > 0).slice(0, 4);
        let y = b.y - b.r - 18;
        ctx.font = '700 11px ' + FONT; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
        for (const [f, k] of fx) {
          const I = ITEMS[k], label = I.nm + (host() ? ' ' + Math.ceil(c[f]) : '');
          const tw = ctx.measureText(label).width + 34, x1 = w - 10;
          rrect(ctx, x1 - tw, y - 12, tw, 24, 12); ctx.fillStyle = 'rgba(23,19,31,.85)'; ctx.fill(); ctx.strokeStyle = I.col; ctx.lineWidth = 1.5; ctx.stroke();
          itemDisc(ctx, k, x1 - tw + 12, y, 9, 0);
          ctx.fillStyle = '#f2e9d8'; ctx.fillText(label, x1 - 9, y + 0.5);
          y -= 28;
        }
        ctx.textAlign = 'center';
      }
      if (cfg.ctl === 's') {
        const q = [...ptrs.values()].find((p) => p.seat === s && p.kind === 'stick');
        const ax = q ? q.ax : 24 + STICK_R + 8, ay = q ? q.ay : h - STICK_R - 34;
        ctx.globalAlpha = (dead ? 0.3 : 1) * (q ? 0.95 : 0.4);
        ctx.beginPath(); ctx.arc(ax, ay, STICK_R, 0, 7); ctx.fillStyle = 'rgba(23,19,31,.55)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.stroke();
        let kx = ax, ky = ay;
        if (q) { const dx = q.x - q.ax, dy = q.y - q.ay, d = Math.hypot(dx, dy), m = Math.min(d, STICK_R); if (d > 0) { kx = ax + dx / d * m; ky = ay + dy / d * m; } }
        ctx.beginPath(); ctx.arc(kx, ky, Math.round(20 * KC()), 0, 7); ctx.fillStyle = hexA(col, 0.9); ctx.fill(); ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.stroke();
        if (!q) { ctx.font = '600 11px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.8)'; ctx.fillText('이동', ax, ay - STICK_R - 10); }
      } else {
        for (const tb of turnBtns()) {
          const on = [...ptrs.values()].some((p) => p.seat === s && p.kind === (tb.dir < 0 ? 'L' : 'R'));
          ctx.beginPath(); ctx.arc(tb.x, tb.y, tb.r, 0, 7); ctx.fillStyle = on ? hexA(col, 0.85) : 'rgba(23,19,31,.6)'; ctx.fill();
          ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(242,233,216,.4)'; ctx.stroke();
          ctx.beginPath(); ctx.arc(tb.x, tb.y, 12, tb.dir < 0 ? -0.2 : Math.PI + 0.2, tb.dir < 0 ? Math.PI * 1.25 : -Math.PI * 0.25, tb.dir < 0);
          ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 3; ctx.stroke();
          const ex = tb.x + (tb.dir < 0 ? -12 : 12) * Math.cos(tb.dir < 0 ? Math.PI * 1.25 : -Math.PI * 0.25), ey = tb.y + 12 * Math.sin(tb.dir < 0 ? Math.PI * 1.25 : -Math.PI * 0.25);
          ctx.beginPath(); ctx.arc(ex, ey, 3, 0, 7); ctx.fillStyle = '#f2e9d8'; ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      if (dead && st.ph === 'play') { ctx.font = '18px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ee6a55'; ctx.fillText('부활 대기', w / 2, h - 70); }
      if (c && c.alive && c.inv > 0 && st.ph === 'play') { ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f2e9d8'; ctx.fillText('보호막 중: 안 밀려요!', w / 2, h - 70); }
      ctx.restore();
      void now;
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; startRound(); }
        if (st.ph === 'play' && phase === 'count' && !host()) { phase = 'play'; cd = 0; }
        if (st.ph === 'end' && (!prev || prev.ph !== 'end')) {
          endT = END_T;
          if (st.rw >= 0 && isMine(st.rw)) { api.sfx('win'); api.buzz(60); } else api.sfx('chip');
        }
        if (st.ph === 'pick') { if (!pick) buildPicker(); syncPicker(); } else dropPicker();
        syncChip();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown); window.removeEventListener('lounge-ctl', onCtl);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        dropPicker(); chip.remove(); styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, phase, locIn, cfg, lay, ptrs, X, Y, pressDash }),
    };
  }

  /* ----- arena art (world units; g already transformed so 1 unit = 1 world unit) ----- */
  function drawArena(g, W, X, Y, s, now, thumbMode) {
    const A = W.A;
    g.save();
    const rimShadow = () => { g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = thumbMode ? 0 : 18; g.shadowOffsetY = thumbMode ? 0 : 6; };
    if (A.shape === 'c') {
      const R = curR(W), RR = A.tide ? A.R * sudden(W) : R;
      g.save(); rimShadow();
      g.beginPath(); g.arc(0, 0, RR + 4, 0, 7);
      g.fillStyle = { island: '#c9a66b', ice: '#7ea8c8', bumper: '#2b1f3c', hill: '#2f4f27', lava: '#2a1410', magnet: '#3b4552', tramp: '#1d3f6e', bhole: '#2a1d48', jelly: '#d8c690', top: '#4a2e18', laser: '#232a33',
        trap: '#2c2c38', tide: '#1e0e0a', fan: '#283544', bowl: '#3c2c22', windmill: '#5a3d1e', donut: '#3a2440', popup: '#241f36', bombs: '#3b3023', wreck: '#2e2b28', fence: '#1f2e28', slope: '#3a2c22', portal: '#1e1a30', boost: '#26262c', rift: '#3a2e26' }[A.id] || '#5a3a22';
      g.fill(); g.restore();
      // floor
      g.save(); g.beginPath(); g.arc(0, 0, R, 0, 7); g.clip();
      if (A.id === 'dojo') {
        const fg = g.createRadialGradient(0, 0, 0, 0, 0, R); fg.addColorStop(0, '#d9c49a'); fg.addColorStop(1, '#bfa577'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(90,60,30,.25)'; g.lineWidth = 0.6; for (let y = -R; y < R; y += 4) { g.beginPath(); g.moveTo(-R, y); g.lineTo(R, y); g.stroke(); }
        g.strokeStyle = '#f5ecd8'; g.lineWidth = 2; for (const sx2 of [-1, 1]) { g.beginPath(); g.moveTo(sx2 * 10, -12); g.lineTo(sx2 * 10, 12); g.stroke(); }
        g.beginPath(); g.arc(0, 0, R - 3, 0, 7); g.strokeStyle = 'rgba(120,80,40,.6)'; g.lineWidth = 3; g.stroke();
      } else if (A.id === 'ice') {
        const fg = g.createRadialGradient(-R * 0.3, -R * 0.3, 0, 0, 0, R); fg.addColorStop(0, '#eaf6ff'); fg.addColorStop(1, '#a9cde6'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 0.8;
        for (let i = 0; i < 9; i++) { const a = hash32(i, 4) / 4294967296 * 7, r0 = 20 + (hash32(i, 5) % 60); g.beginPath(); g.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); g.lineTo(Math.cos(a + 0.3) * (r0 + 22), Math.sin(a + 0.3) * (r0 + 22)); g.lineTo(Math.cos(a + 0.1) * (r0 + 34), Math.sin(a + 0.1) * (r0 + 34)); g.stroke(); }
        g.strokeStyle = 'rgba(91,179,230,.6)'; g.lineWidth = 2; g.beginPath(); g.arc(0, 0, 26, 0, 7); g.stroke();
      } else if (A.id === 'island') {
        const fg = g.createRadialGradient(0, 0, 0, 0, 0, R); fg.addColorStop(0, '#f0d9a2'); fg.addColorStop(0.85, '#e2c487'); fg.addColorStop(1, '#cfae6e'); g.fillStyle = fg; g.fillRect(-A.R, -A.R, A.R * 2, A.R * 2);
        g.fillStyle = 'rgba(150,110,60,.25)'; for (let i = 0; i < 60; i++) { const x = (hash32(i, 1) % 220) - 110, y = (hash32(i, 2) % 220) - 110; g.fillRect(x, y, 1.2, 1.2); }
        g.strokeStyle = 'rgba(255,255,255,.65)'; g.lineWidth = 2.5; g.beginPath(); g.arc(0, 0, R - 1, 0, 7); g.stroke();
      } else if (A.id === 'spin') {
        g.rotate((W.t || 0) * A.spin);
        for (let i = 0; i < 12; i++) { g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, R, i * Math.PI / 6, (i + 1) * Math.PI / 6); g.closePath(); g.fillStyle = i % 2 ? '#3d2f5c' : '#e3ae45'; g.fill(); }
        g.beginPath(); g.arc(0, 0, R * 0.62, 0, 7); g.fillStyle = 'rgba(23,19,31,.18)'; g.fill();
        g.beginPath(); g.arc(0, 0, 10, 0, 7); g.fillStyle = '#f2e9d8'; g.fill();
        g.beginPath(); g.arc(0, 0, 4, 0, 7); g.fillStyle = '#3d2f5c'; g.fill();
      } else if (A.id === 'holes') {
        g.fillStyle = '#4a4a58'; g.fillRect(-R, -R, R * 2, R * 2);
        for (let i = -HOLE_N - 1; i <= HOLE_N + 1; i++) for (let j = -HOLE_N - 1; j <= HOLE_N + 1; j++) {
          const x = i * HOLE_CELL - HOLE_CELL / 2, y = j * HOLE_CELL - HOLE_CELL / 2, hs = holeState(W, i, j);
          if (hs === 2) { g.fillStyle = '#0b0810'; g.fillRect(x, y, HOLE_CELL, HOLE_CELL); g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(x, y, HOLE_CELL, 4); continue; }
          g.fillStyle = (i + j) & 1 ? '#6c6a7a' : '#5e5c6c'; g.fillRect(x + 0.6, y + 0.6, HOLE_CELL - 1.2, HOLE_CELL - 1.2);
          if (hs === 1) { const k = 0.35 + 0.35 * Math.sin((W.t || 0) * 14); g.fillStyle = 'rgba(238,106,85,' + k + ')'; g.fillRect(x + 0.6, y + 0.6, HOLE_CELL - 1.2, HOLE_CELL - 1.2); g.strokeStyle = '#ee6a55'; g.lineWidth = 1; g.strokeRect(x + 2, y + 2, HOLE_CELL - 4, HOLE_CELL - 4); }
        }
      } else if (A.id === 'bumper') {
        const fg = g.createRadialGradient(0, 0, 0, 0, 0, R); fg.addColorStop(0, '#3a2c55'); fg.addColorStop(1, '#251b3a'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(240,127,184,.35)'; g.lineWidth = 1; for (let r = 20; r < R; r += 20) { g.beginPath(); g.arc(0, 0, r, 0, 7); g.stroke(); }
      } else if (A.id === 'hill') {
        g.fillStyle = '#4c7a3a'; g.fillRect(-R, -R, R * 2, R * 2);
        for (let k = 5; k >= 1; k--) { g.beginPath(); g.arc(0, 0, A.hill * k / 5, 0, 7); g.fillStyle = 'rgb(' + (76 + (6 - k) * 18) + ',' + (122 + (6 - k) * 14) + ',' + (58 + (6 - k) * 6) + ')'; g.fill(); }
        g.strokeStyle = 'rgba(30,50,20,.35)'; g.lineWidth = 0.8; for (let k = 1; k <= 5; k++) { g.beginPath(); g.arc(0, 0, A.hill * k / 5, 0, 7); g.stroke(); }
        g.fillStyle = 'rgba(255,255,255,.12)'; for (let i = 0; i < 40; i++) { const a = hash32(i, 7) / 4294967296 * 7, r = A.hill + 6 + (hash32(i, 8) % 50); g.fillRect(Math.cos(a) * r, Math.sin(a) * r, 1, 2.5); }
      } else if (A.id === 'lava') { // cooled basalt with glowing seams
        g.fillStyle = '#3a2a26'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(255,120,40,.35)'; g.lineWidth = 1.1;
        for (let i = 0; i < 14; i++) { const a = hash32(i, 31) / 4294967296 * 7, r0 = 14 + (hash32(i, 32) % 70); g.beginPath(); g.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); g.lineTo(Math.cos(a + 0.25) * (r0 + 16), Math.sin(a + 0.25) * (r0 + 16)); g.lineTo(Math.cos(a + 0.05) * (r0 + 28), Math.sin(a + 0.05) * (r0 + 28)); g.stroke(); }
        g.fillStyle = 'rgba(0,0,0,.18)'; for (let i = 0; i < 50; i++) { const x = (hash32(i, 33) % 200) - 100, y = (hash32(i, 34) % 200) - 100; g.fillRect(x, y, 2, 2); }
      } else if (A.id === 'magnet') { // steel plate
        const fg = g.createLinearGradient(-R, -R, R, R); fg.addColorStop(0, '#9aa6b4'); fg.addColorStop(0.5, '#c4ccd6'); fg.addColorStop(1, '#8a95a3'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(40,50,60,.25)'; g.lineWidth = 0.8; for (let x = -R; x < R; x += 26) { g.beginPath(); g.moveTo(x, -R); g.lineTo(x, R); g.stroke(); }
        g.fillStyle = 'rgba(40,50,60,.45)'; for (let x = -R + 13; x < R; x += 26) for (let y = -R + 13; y < R; y += 26) { g.beginPath(); g.arc(x, y, 1.2, 0, 7); g.fill(); }
      } else if (A.id === 'tramp') { // gym mat
        g.fillStyle = '#2f6fb3'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1; for (let y = -R; y < R; y += 18) { g.beginPath(); g.moveTo(-R, y); g.lineTo(R, y); g.stroke(); }
        g.beginPath(); g.arc(0, 0, R - 4, 0, 7); g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 2; g.stroke();
      } else if (A.id === 'bhole') { // event horizon disk with spiral arms
        const fg = g.createRadialGradient(0, 0, 0, 0, 0, R); fg.addColorStop(0, '#0a0612'); fg.addColorStop(0.25, '#3a2766'); fg.addColorStop(1, '#5b4691'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.save(); g.rotate((W.t || 0) * 0.6);
        g.strokeStyle = 'rgba(200,170,255,.28)'; g.lineWidth = 2;
        for (let k = 0; k < 4; k++) { g.beginPath(); for (let i = 0; i <= 30; i++) { const r = BH_R + i * 3.2, an = k * Math.PI / 2 + Math.log(r / BH_R) * 1.6; i ? g.lineTo(Math.cos(an) * r, Math.sin(an) * r) : g.moveTo(Math.cos(an) * r, Math.sin(an) * r); } g.stroke(); }
        g.restore();
      } else if (A.id === 'jelly') { // sandbar under shallow water
        const fg = g.createRadialGradient(0, 0, 0, 0, 0, R); fg.addColorStop(0, '#9fe0d5'); fg.addColorStop(1, '#58b4b4'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(255,255,255,.28)'; g.lineWidth = 0.9;
        for (let i = 0; i < 10; i++) { const x = (hash32(i, 41) % 170) - 85, y = (hash32(i, 42) % 170) - 85, r = 6 + ((W.t || 0) * 5 + i * 3) % 14; g.beginPath(); g.arc(x, y, r, 0, 7); g.stroke(); }
      } else if (A.id === 'top') { // wooden table
        g.fillStyle = '#a8743f'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(80,45,15,.3)'; g.lineWidth = 0.8; for (let r = 8; r < R; r += 7) { g.beginPath(); g.arc(5, -3, r, 0, 7); g.stroke(); }
      } else if (A.id === 'laser') { // metal grid
        g.fillStyle = '#39424e'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(120,200,255,.13)'; g.lineWidth = 0.8; for (let x = -R; x < R; x += 14) { g.beginPath(); g.moveTo(x, -R); g.lineTo(x, R); g.stroke(); g.beginPath(); g.moveTo(-R, x); g.lineTo(R, x); g.stroke(); }
        g.beginPath(); g.arc(0, 0, 9, 0, 7); g.fillStyle = '#1b2026'; g.fill(); g.strokeStyle = '#ff5470'; g.lineWidth = 1.5; g.stroke();
      } else if (A.id === 'trap') { // steel deck with hazard-striped trapdoors
        g.fillStyle = '#5d6170'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(30,30,40,.35)'; g.lineWidth = 0.8;
        for (let x = -R; x < R; x += HOLE_CELL) { g.beginPath(); g.moveTo(x + HOLE_CELL / 2, -R); g.lineTo(x + HOLE_CELL / 2, R); g.stroke(); g.beginPath(); g.moveTo(-R, x + HOLE_CELL / 2); g.lineTo(R, x + HOLE_CELL / 2); g.stroke(); }
        for (const k in W.hidx) {
          const i = Math.floor(+k / 32) - 8, j = (+k % 32) - 8, x = i * HOLE_CELL - HOLE_CELL / 2, y = j * HOLE_CELL - HOLE_CELL / 2;
          const hs = thumbMode ? (W.hidx[k] % 3 === 0 ? 2 : W.hidx[k] % 3 === 1 ? 1 : 0) : holeState(W, i, j);
          if (hs === 2) { g.fillStyle = '#07050b'; g.fillRect(x, y, HOLE_CELL, HOLE_CELL); g.fillStyle = '#3a3c48'; g.fillRect(x, y, 4, HOLE_CELL); g.fillRect(x + HOLE_CELL - 4, y, 4, HOLE_CELL); continue; }
          g.save(); g.beginPath(); g.rect(x + 1, y + 1, HOLE_CELL - 2, HOLE_CELL - 2); g.clip();
          g.fillStyle = '#2a2a30'; g.fillRect(x, y, HOLE_CELL, HOLE_CELL);
          g.strokeStyle = 'rgba(227,174,69,.8)'; g.lineWidth = 2.4;
          for (let q = -HOLE_CELL; q < HOLE_CELL; q += 7) { g.beginPath(); g.moveTo(x + q, y); g.lineTo(x + q + HOLE_CELL, y + HOLE_CELL); g.stroke(); }
          g.restore();
          g.fillStyle = '#50535f'; g.fillRect(x + 4, y + 4, HOLE_CELL - 8, HOLE_CELL - 8);
          g.strokeStyle = 'rgba(20,20,28,.6)'; g.lineWidth = 0.8; g.beginPath(); g.moveTo(x + HOLE_CELL / 2, y + 4); g.lineTo(x + HOLE_CELL / 2, y + HOLE_CELL - 4); g.stroke();
          if (hs === 1) { const kk = 0.35 + 0.35 * Math.sin((W.t || 0) * 14); g.fillStyle = 'rgba(238,106,85,' + kk + ')'; g.fillRect(x + 1, y + 1, HOLE_CELL - 2, HOLE_CELL - 2); g.strokeStyle = '#ee6a55'; g.lineWidth = 1.2; g.strokeRect(x + 2, y + 2, HOLE_CELL - 4, HOLE_CELL - 4); }
        }
      } else if (A.id === 'tide') { // dark crust that the lava keeps eating
        g.fillStyle = '#463530'; g.fillRect(-A.R, -A.R, A.R * 2, A.R * 2);
        g.fillStyle = 'rgba(0,0,0,.2)'; for (let i = 0; i < 60; i++) { const x = (hash32(i, 51) % 210) - 105, y = (hash32(i, 52) % 210) - 105; g.fillRect(x, y, 2, 2); }
        g.strokeStyle = 'rgba(255,140,60,.25)'; g.lineWidth = 1;
        for (let i = 0; i < 10; i++) { const a = hash32(i, 53) / 4294967296 * 7, r0 = 10 + (hash32(i, 54) % 60); g.beginPath(); g.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); g.lineTo(Math.cos(a + 0.3) * (r0 + 14), Math.sin(a + 0.3) * (r0 + 14)); g.stroke(); }
      } else if (A.id === 'fan') { // hangar concrete with lane marks
        g.fillStyle = '#8b8f96'; g.fillRect(-R, -R, R * 2, R * 2);
        g.fillStyle = 'rgba(0,0,0,.08)'; for (let i = 0; i < 40; i++) { const x = (hash32(i, 61) % 200) - 100, y = (hash32(i, 62) % 200) - 100; g.fillRect(x, y, 3, 1.5); }
        for (let k = 0; k < 3; k++) {
          const an = fanAng(W, k), ca = Math.cos(an), sa = Math.sin(an);
          g.strokeStyle = 'rgba(227,174,69,.4)'; g.lineWidth = 1.2; g.setLineDash([6, 6]);
          for (const sg of [-1, 1]) { g.beginPath(); g.moveTo(ca * R - sa * FAN_W * sg, sa * R + ca * FAN_W * sg); g.lineTo(-ca * R - sa * FAN_W * sg, -sa * R + ca * FAN_W * sg); g.stroke(); }
          g.setLineDash([]);
        }
      } else if (A.id === 'bowl') { // a polished dish, shaded toward its low side
        const tx = Math.sin(W.th || 0), ty = Math.sin(W.th2 || 0), fg = g.createRadialGradient(-tx * 160, -ty * 160, 4, tx * 60, ty * 60, R * 1.6);
        fg.addColorStop(0, '#e7c58f'); fg.addColorStop(1, '#8a6238'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(90,55,25,.35)'; g.lineWidth = 0.9; for (let r = 18; r < R; r += 18) { g.beginPath(); g.arc(0, 0, r, 0, 7); g.stroke(); }
        g.beginPath(); g.arc(0, 0, 5, 0, 7); g.fillStyle = '#5a3a1e'; g.fill();
        if (!thumbMode && Math.hypot(tx, ty) > 0.05) { // arrow: which way it's tipping
          const an = Math.atan2(ty, tx), L2 = 30 * Math.min(1, Math.hypot(tx, ty) / 0.25), ex = Math.cos(an) * L2, ey = Math.sin(an) * L2;
          g.strokeStyle = 'rgba(238,106,85,.75)'; g.lineWidth = 3; g.lineCap = 'round';
          g.beginPath(); g.moveTo(0, 0); g.lineTo(ex, ey); g.stroke();
          g.beginPath(); g.moveTo(ex + Math.cos(an + 2.5) * 6, ey + Math.sin(an + 2.5) * 6); g.lineTo(ex, ey); g.lineTo(ex + Math.cos(an - 2.5) * 6, ey + Math.sin(an - 2.5) * 6); g.stroke(); g.lineCap = 'butt';
        }
      } else if (A.id === 'windmill') { // a field with a mown circle
        g.fillStyle = '#6d9a45'; g.fillRect(-R, -R, R * 2, R * 2);
        g.beginPath(); g.arc(0, 0, ARM_L + 6, 0, 7); g.fillStyle = '#7fae52'; g.fill();
        g.strokeStyle = 'rgba(40,70,20,.3)'; g.lineWidth = 0.8; for (let r = 14; r < ARM_L; r += 12) { g.beginPath(); g.arc(0, 0, r, 0, 7); g.stroke(); }
        g.fillStyle = 'rgba(255,255,255,.14)'; for (let i = 0; i < 50; i++) { const a = hash32(i, 71) / 4294967296 * 7, r = ARM_L + 8 + (hash32(i, 72) % 26); g.fillRect(Math.cos(a) * r, Math.sin(a) * r, 1, 2.5); }
      } else if (A.id === 'donut') { // two counter-rotating rings around a pit
        const t = W.t || 0;
        g.fillStyle = '#c86f9a'; g.fillRect(-R, -R, R * 2, R * 2);
        g.save(); g.rotate(t * DN_WO); for (let i = 0; i < 16; i++) { g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, R, i * Math.PI / 8, (i + 0.5) * Math.PI / 8); g.closePath(); g.fillStyle = 'rgba(255,255,255,.12)'; g.fill(); } g.restore();
        g.beginPath(); g.arc(0, 0, DN_MID, 0, 7); g.fillStyle = '#f2c46d'; g.fill();
        g.save(); g.beginPath(); g.arc(0, 0, DN_MID, 0, 7); g.clip(); g.rotate(t * DN_WI); for (let i = 0; i < 10; i++) { g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, DN_MID, i * Math.PI / 5, (i + 0.45) * Math.PI / 5); g.closePath(); g.fillStyle = 'rgba(120,60,20,.14)'; g.fill(); } g.restore();
        g.beginPath(); g.arc(0, 0, DN_MID, 0, 7); g.strokeStyle = 'rgba(60,20,40,.55)'; g.lineWidth = 2; g.stroke();
        const pg = g.createRadialGradient(0, 0, 2, 0, 0, DN_PIT + 4); pg.addColorStop(0, '#000'); pg.addColorStop(DN_PIT / (DN_PIT + 4), '#0b0610'); pg.addColorStop(1, 'rgba(60,20,40,.8)');
        g.beginPath(); g.arc(0, 0, DN_PIT + 4, 0, 7); g.fillStyle = pg; g.fill();
        g.lineWidth = 2;
        g.save(); g.rotate(t * DN_WO); g.strokeStyle = 'rgba(255,255,255,.6)'; for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; g.beginPath(); g.arc(0, 0, R - 9, a, a + 0.25); g.stroke(); } g.restore();
        g.save(); g.rotate(t * DN_WI); g.strokeStyle = 'rgba(120,60,20,.6)'; for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; g.beginPath(); g.arc(0, 0, DN_MID - 9, a, a + 0.3); g.stroke(); } g.restore();
      } else if (A.id === 'popup') { // purple hex tiles
        g.fillStyle = '#3b3058'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(180,150,240,.16)'; g.lineWidth = 1;
        for (let y = -R, row = 0; y < R + 12; y += 15, row++) for (let x = -R + (row % 2 ? 9 : 0); x < R + 12; x += 18) {
          g.beginPath(); for (let q = 0; q < 6; q++) { const a = q * Math.PI / 3 + Math.PI / 6; q ? g.lineTo(x + Math.cos(a) * 9.5, y + Math.sin(a) * 9.5) : g.moveTo(x + Math.cos(a) * 9.5, y + Math.sin(a) * 9.5); } g.closePath(); g.stroke();
        }
      } else if (A.id === 'bombs') { // scorched dirt
        g.fillStyle = '#9a8460'; g.fillRect(-R, -R, R * 2, R * 2);
        g.fillStyle = 'rgba(60,40,20,.18)'; for (let i = 0; i < 8; i++) { const x = (hash32(i, 81) % 160) - 80, y = (hash32(i, 82) % 160) - 80; g.beginPath(); g.arc(x, y, 8 + (hash32(i, 83) % 8), 0, 7); g.fill(); }
        g.fillStyle = 'rgba(0,0,0,.12)'; for (let i = 0; i < 60; i++) { const x = (hash32(i, 84) % 210) - 105, y = (hash32(i, 85) % 210) - 105; g.fillRect(x, y, 1.6, 1.6); }
      } else if (A.id === 'wreck') { // demolition yard with a striped edge
        g.fillStyle = '#9b958a'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(40,35,30,.22)'; g.lineWidth = 0.9; for (let x = -R; x < R; x += 30) { g.beginPath(); g.moveTo(x, -R); g.lineTo(x + 8, R); g.stroke(); }
        g.save(); g.beginPath(); g.arc(0, 0, R, 0, Math.PI * 2); g.moveTo(R - 6, 0); g.arc(0, 0, R - 6, 0, Math.PI * 2, true); g.clip(); g.fillStyle = '#2a2622'; g.fillRect(-R, -R, R * 2, R * 2); g.strokeStyle = '#e3ae45'; g.lineWidth = 4;
        for (let a = 0; a < 40; a++) { const an = a * Math.PI / 20; g.beginPath(); g.moveTo(Math.cos(an) * (R - 7), Math.sin(an) * (R - 7)); g.lineTo(Math.cos(an + 0.08) * R, Math.sin(an + 0.08) * R); g.stroke(); }
        g.restore();
      } else if (A.id === 'fence') { // a green court
        g.fillStyle = '#4f8a6e'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1.2; g.beginPath(); g.arc(0, 0, R * 0.45, 0, 7); g.stroke(); g.beginPath(); g.moveTo(-R, 0); g.lineTo(R, 0); g.stroke();
      } else if (A.id === 'slope') { // lit on the high side, shadowed on the low side
        const an = slopeAng(W, W.t || 0), ca = Math.cos(an), sa = Math.sin(an), fg = g.createLinearGradient(-ca * R, -sa * R, ca * R, sa * R);
        fg.addColorStop(0, '#e2c08a'); fg.addColorStop(1, '#7a5634'); g.fillStyle = fg; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(70,40,15,.25)'; g.lineWidth = 1; for (let k = -R; k < R; k += 16) { g.beginPath(); g.moveTo(ca * k - sa * R, sa * k + ca * R); g.lineTo(ca * k + sa * R, sa * k - ca * R); g.stroke(); }
      } else if (A.id === 'portal') { // night plaza
        g.fillStyle = '#2e2a4a'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(160,140,255,.14)'; g.lineWidth = 1; for (let r = 16; r < R; r += 16) { g.beginPath(); g.arc(0, 0, r, 0, 7); g.stroke(); }
        g.fillStyle = 'rgba(255,255,255,.4)'; for (let i = 0; i < 30; i++) { const x = (hash32(i, 121) % 200) - 100, y = (hash32(i, 122) % 200) - 100; g.fillRect(x, y, 1, 1); }
      } else if (A.id === 'boost') { // asphalt
        g.fillStyle = '#4a4a52'; g.fillRect(-R, -R, R * 2, R * 2);
        g.fillStyle = 'rgba(255,255,255,.05)'; for (let i = 0; i < 60; i++) { const x = (hash32(i, 131) % 210) - 105, y = (hash32(i, 132) % 210) - 105; g.fillRect(x, y, 2, 1); }
        g.strokeStyle = 'rgba(255,255,255,.3)'; g.setLineDash([8, 8]); g.lineWidth = 1.5; g.beginPath(); g.arc(0, 0, 58, 0, 7); g.stroke(); g.setLineDash([]);
      } else if (A.id === 'rift') { // cracked stone
        g.fillStyle = '#8b7d6b'; g.fillRect(-R, -R, R * 2, R * 2);
        g.strokeStyle = 'rgba(50,40,30,.3)'; g.lineWidth = 0.9; for (let i = 0; i < 14; i++) { const a = hash32(i, 141) / 4294967296 * 7, r0 = 10 + (hash32(i, 142) % 70); g.beginPath(); g.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); g.lineTo(Math.cos(a + 0.2) * (r0 + 18), Math.sin(a + 0.2) * (r0 + 18)); g.stroke(); }
      } else {
        g.fillStyle = '#c9b48a'; g.fillRect(-R, -R, R * 2, R * 2);
      }
      g.restore();
      if (A.tide) { // the lava sea between the crust and the old shore
        if (RR - R > 0.5) {
          const lg = g.createRadialGradient(0, 0, R, 0, 0, RR + 4); lg.addColorStop(0, '#ffde7a'); lg.addColorStop(0.25, '#ff7a1f'); lg.addColorStop(1, '#b8260e');
          g.beginPath(); g.arc(0, 0, RR + 3, 0, Math.PI * 2); g.moveTo(R, 0); g.arc(0, 0, R, 0, Math.PI * 2, true); g.fillStyle = lg; g.fill();
          if (!thumbMode && RR - R > 4) { g.fillStyle = 'rgba(255,240,160,.7)'; for (let i = 0; i < 14; i++) { const a = hash32(i, 55) / 4294967296 * 7 + (now || 0) / 4000, rr = R + 2 + (RR - R - 2) * ((hash32(i, 56) % 100) / 100); g.beginPath(); g.arc(Math.cos(a) * rr, Math.sin(a) * rr, 1.2 + Math.sin((now || 0) / 200 + i) * 0.6, 0, 7); g.fill(); } }
        } else { g.beginPath(); g.arc(0, 0, RR + 3, 0, 7); g.strokeStyle = '#ff7a1f'; g.lineWidth = 2.5; g.stroke(); }
        const tw = tideU(W, W.t || 0);
        if (tw.warn || thumbMode) { const hr = (A.R - TIDE_A) * sudden(W); g.beginPath(); g.arc(0, 0, hr, 0, 7); g.setLineDash([5, 4]); g.strokeStyle = 'rgba(255,90,40,' + (thumbMode ? 0.75 : 0.5 + 0.4 * Math.sin((now || 0) / 90)) + ')'; g.lineWidth = 1.8; g.stroke(); g.setLineDash([]); }
      }
      // the original edge of a shrinking floor
      if (A.shrink || sudden(W) < 1) { g.beginPath(); g.arc(0, 0, A.R, 0, 7); g.strokeStyle = 'rgba(238,106,85,.3)'; g.lineWidth = 1; g.setLineDash([3, 4]); g.stroke(); g.setLineDash([]); }
      g.beginPath(); g.arc(0, 0, R, 0, 7); g.strokeStyle = sudden(W) < 1 ? 'rgba(238,106,85,.9)' : 'rgba(242,233,216,.55)'; g.lineWidth = 1.6; g.stroke();
    } else if (A.shape === 'x') { // rope bridges over a chasm + a stone plaza
      const L2 = X_L * sudden(W), q = quakeOf(W), jit = thumbMode ? 0 : q.shake * 1.6 * (L.fx ? L.fx() : 1);
      g.save(); if (jit) g.translate(Math.sin((now || 0) / 23) * jit, Math.cos((now || 0) / 29) * jit);
      g.save(); rimShadow(); g.fillStyle = '#3a2a1c';
      g.fillRect(-L2 - 3, -X_W - 3, L2 * 2 + 6, X_W * 2 + 6); g.fillRect(-X_W - 3, -L2 - 3, X_W * 2 + 6, L2 * 2 + 6); g.fillRect(-X_P - 3, -X_P - 3, X_P * 2 + 6, X_P * 2 + 6); g.restore();
      for (const v of [0, 1]) { // planks
        g.save(); if (v) g.rotate(Math.PI / 2);
        g.fillStyle = '#a77a48'; g.fillRect(-L2, -X_W, L2 * 2, X_W * 2);
        g.strokeStyle = 'rgba(70,40,15,.55)'; g.lineWidth = 1; for (let x = -L2; x < L2; x += 7) { g.beginPath(); g.moveTo(x, -X_W); g.lineTo(x, X_W); g.stroke(); }
        g.strokeStyle = '#d9c39a'; g.lineWidth = 1.4; for (const sy of [-1, 1]) { g.beginPath(); g.moveTo(-L2, sy * (X_W - 1)); g.lineTo(L2, sy * (X_W - 1)); g.stroke(); }
        g.restore();
      }
      const pg = g.createRadialGradient(0, 0, 4, 0, 0, X_P * 1.4); pg.addColorStop(0, '#b9b0a0'); pg.addColorStop(1, '#8c8474'); g.fillStyle = pg; g.fillRect(-X_P, -X_P, X_P * 2, X_P * 2);
      g.strokeStyle = 'rgba(50,45,40,.35)'; g.lineWidth = 0.8; for (let k = -X_P; k <= X_P; k += 14) { g.beginPath(); g.moveTo(k, -X_P); g.lineTo(k, X_P); g.stroke(); g.beginPath(); g.moveTo(-X_P, k); g.lineTo(X_P, k); g.stroke(); }
      g.strokeStyle = 'rgba(242,233,216,.5)'; g.lineWidth = 1.4; g.strokeRect(-X_P, -X_P, X_P * 2, X_P * 2);
      g.restore();
    } else if (A.shape === 'p') { // four drifting platforms
      const pd = platD(W), hs = PL_HS * sudden(W);
      for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
        const x0 = sx * pd - hs, y0 = sy * pd - hs;
        g.save(); rimShadow(); g.fillStyle = '#3d4a56'; g.fillRect(x0 - 3, y0 - 3, hs * 2 + 6, hs * 2 + 6); g.restore();
        const fg = g.createLinearGradient(x0, y0, x0 + hs * 2, y0 + hs * 2); fg.addColorStop(0, '#d8c08a'); fg.addColorStop(1, '#b89a62'); g.fillStyle = fg; g.fillRect(x0, y0, hs * 2, hs * 2);
        g.strokeStyle = 'rgba(90,60,30,.3)'; g.lineWidth = 0.8; for (let k = 1; k < 6; k++) { g.beginPath(); g.moveTo(x0, y0 + k * hs / 3); g.lineTo(x0 + hs * 2, y0 + k * hs / 3); g.stroke(); }
        g.strokeStyle = 'rgba(242,233,216,.55)'; g.lineWidth = 1.4; g.strokeRect(x0, y0, hs * 2, hs * 2);
        g.fillStyle = 'rgba(227,174,69,.85)'; g.beginPath(); g.arc(sx * pd, sy * pd, 3, 0, 7); g.fill();
      }
    } else {
      const sc = sudden(W), hw = A.hw * sc, hh = A.hh * sc;
      g.save();
      if (A.tilt) { // the plank: the low end is drawn darker + slightly larger
        rimShadow();
        g.fillStyle = '#4a3020'; g.fillRect(-hw - 4, -hh - 4, hw * 2 + 8, hh * 2 + 8);
      } else { rimShadow(); g.fillStyle = A.wind ? '#3b3530' : A.flip ? '#7a4a1c' : A.dark ? '#1a1424' : A.gust ? '#7fa2bf' : A.piston ? '#3a3d48' : A.logs ? '#3a5a2a' : A.wave ? '#b89a62' : A.walls ? '#3a2440' : '#2a2a33'; g.fillRect(-hw - 4, -hh - 4, hw * 2 + 8, hh * 2 + 8); }
      g.restore();
      g.save(); g.beginPath(); g.rect(-hw, -hh, hw * 2, hh * 2); g.clip();
      if (A.belts) {
        const bh = A.hh / 2;
        for (let b = 0; b < 4; b++) {
          const y0 = -A.hh + b * bh, dir = b % 2 ? -1 : 1;
          g.fillStyle = b % 2 ? '#3c3f4a' : '#454957'; g.fillRect(-A.hw, y0, A.hw * 2, bh);
          const off = ((W.t || 0) * 72 * dir) % 24;
          g.strokeStyle = 'rgba(227,174,69,.55)'; g.lineWidth = 2.2;
          for (let x = -A.hw - 24; x < A.hw + 24; x += 24) {
            const xx = x + off;
            g.beginPath(); g.moveTo(xx - 4 * dir, y0 + bh * 0.3); g.lineTo(xx + 4 * dir, y0 + bh * 0.5); g.lineTo(xx - 4 * dir, y0 + bh * 0.7); g.stroke();
          }
          g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(-A.hw, y0, A.hw * 2, 1.4);
        }
      } else if (A.wind) {
        const fg = g.createLinearGradient(-hw, 0, hw, 0); fg.addColorStop(0, '#6d6457'); fg.addColorStop(0.5, '#8a7f6e'); fg.addColorStop(1, '#6d6457'); g.fillStyle = fg; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.strokeStyle = 'rgba(40,30,20,.3)'; g.lineWidth = 0.8;
        for (let i = 0; i < 18; i++) { const x = (hash32(i, 11) % 160) - 80, y = (hash32(i, 12) % 220) - 110; g.beginPath(); g.moveTo(x, y); g.lineTo(x + 8, y + 5); g.lineTo(x + 12, y + 2); g.stroke(); }
        if (!thumbMode && W.wind) { g.strokeStyle = 'rgba(220,235,255,.35)'; g.lineWidth = 1; for (let i = 0; i < 14; i++) { const y = (hash32(i, 13) % 230) - 115, x = ((now / 3 * Math.sign(W.wind) + hash32(i, 14)) % 260) - 130; g.beginPath(); g.moveTo(x, y); g.lineTo(x - 20 * Math.sign(W.wind), y); g.stroke(); } }
      } else if (A.flip) { // pinball playfield
        const fg = g.createLinearGradient(0, -hh, 0, hh); fg.addColorStop(0, '#1b3f86'); fg.addColorStop(0.5, '#2a5bb5'); fg.addColorStop(1, '#1b3f86'); g.fillStyle = fg; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.strokeStyle = 'rgba(255,224,138,.35)'; g.lineWidth = 1.2; for (const sx2 of [-1, 1]) { g.beginPath(); g.moveTo(sx2 * 50, -hh); g.lineTo(sx2 * 50, -60); g.moveTo(sx2 * 50, hh); g.lineTo(sx2 * 50, 60); g.stroke(); }
        g.fillStyle = 'rgba(255,224,138,.5)'; for (const [x, y] of [[0, -60], [0, 60], [-20, -90], [20, 90], [-60, 0], [60, 0]]) { g.beginPath(); g.moveTo(x, y - 4); g.lineTo(x + 3.5, y + 2.5); g.lineTo(x - 3.5, y + 2.5); g.closePath(); g.fill(); }
      } else if (A.dark) { // dance floor
        const n2 = 22;
        for (let x = -hw; x < hw; x += n2) for (let y = -hh; y < hh; y += n2) { const k = hash32((x + 200) | 0, (y + 200) | 0) % 5; g.fillStyle = ['#3a2050', '#24365a', '#4a2340', '#2a2a40', '#203a3a'][k]; g.fillRect(x + 0.5, y + 0.5, n2 - 1, n2 - 1); }
        if (!thumbMode) { const k2 = Math.floor((now || 0) / 500); g.fillStyle = 'rgba(240,127,184,.18)'; for (let i = 0; i < 6; i++) { const q = hash32(k2, i); g.fillRect(-hw + (q % 8) * n2, -hh + ((q >> 8) % 11) * n2, n2, n2); } }
      } else if (A.piston) { // factory floor
        g.fillStyle = '#6f7480'; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.strokeStyle = 'rgba(30,32,40,.3)'; g.lineWidth = 0.8; for (let y = -hh; y < hh; y += 16) { g.beginPath(); g.moveTo(-hw, y); g.lineTo(hw, y); g.stroke(); }
        g.fillStyle = 'rgba(30,32,40,.35)'; for (let x = -hw + 8; x < hw; x += 16) for (let y = -hh + 8; y < hh; y += 16) { g.beginPath(); g.arc(x, y, 0.9, 0, 7); g.fill(); }
        for (const yc of PS_YS) for (const sd of [-1, 1]) { g.fillStyle = 'rgba(238,106,85,.06)'; g.fillRect(sd < 0 ? -hw : hw - RAM_D, yc - RAM_H, RAM_D, RAM_H * 2); } // the reach of each ram
      } else if (A.gust) { // packed snow on ice
        const fg = g.createLinearGradient(-hw, -hh, hw, hh); fg.addColorStop(0, '#f4fbff'); fg.addColorStop(1, '#bcd9ee'); g.fillStyle = fg; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.strokeStyle = 'rgba(120,170,210,.45)'; g.lineWidth = 0.8;
        for (let i = 0; i < 10; i++) { const x = (hash32(i, 91) % 160) - 80, y = (hash32(i, 92) % 210) - 105; g.beginPath(); g.moveTo(x, y); g.lineTo(x + 16, y + 6); g.lineTo(x + 26, y + 2); g.stroke(); }
        g.fillStyle = 'rgba(255,255,255,.8)'; for (let i = 0; i < 30; i++) { const x = (hash32(i, 93) % 176) - 88, y = (hash32(i, 94) % 224) - 112; g.fillRect(x, y, 2, 2); }
      } else if (A.logs) { // grassy hillside
        g.fillStyle = '#6f9e4a'; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.fillStyle = 'rgba(255,255,255,.12)'; for (let i = 0; i < 60; i++) { const x = (hash32(i, 151) % 176) - 88, y = (hash32(i, 152) % 232) - 116; g.fillRect(x, y, 1, 3); }
        g.strokeStyle = 'rgba(60,40,20,.25)'; g.lineWidth = 6; for (const x of [-60, 0, 60]) { g.beginPath(); g.moveTo(x, -hh); g.lineTo(x, hh); g.stroke(); }
      } else if (A.wave) { // wet sand
        const fg = g.createLinearGradient(-hw, 0, hw, 0); fg.addColorStop(0, '#d9c08c'); fg.addColorStop(0.5, '#e8d4a6'); fg.addColorStop(1, '#d9c08c'); g.fillStyle = fg; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.strokeStyle = 'rgba(140,110,70,.25)'; g.lineWidth = 1; for (let y = -hh + 6; y < hh; y += 12) { g.beginPath(); for (let x = -hw; x <= hw; x += 10) { const yy = y + Math.sin(x / 9 + y) * 1.5; x === -hw ? g.moveTo(x, yy) : g.lineTo(x, yy); } g.stroke(); }
      } else if (A.walls) { // rubber-padded corridor
        g.fillStyle = '#5a4a7a'; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.strokeStyle = 'rgba(255,255,255,.1)'; g.lineWidth = 1; for (let y = -hh; y < hh; y += 20) { g.beginPath(); g.moveTo(-hw, y); g.lineTo(hw, y); g.stroke(); }
        g.fillStyle = 'rgba(238,106,85,.25)'; g.fillRect(-hw, -hh, hw * 2, 8); g.fillRect(-hw, hh - 8, hw * 2, 8);
      } else if (A.tilt) {
        const fg = g.createLinearGradient(0, -hh, 0, hh); const k = clamp(W.th / 0.42, -1, 1);
        fg.addColorStop(0, shadeHex('#b07a45', 0.25 * -k)); fg.addColorStop(1, shadeHex('#b07a45', 0.25 * k));
        g.fillStyle = fg; g.fillRect(-hw, -hh, hw * 2, hh * 2);
        g.strokeStyle = 'rgba(70,40,15,.45)'; g.lineWidth = 1; for (let x = -hw + 18; x < hw; x += 18) { g.beginPath(); g.moveTo(x, -hh); g.lineTo(x, hh); g.stroke(); }
        g.fillStyle = '#3b2414'; g.fillRect(-hw, -2, hw * 2, 4); // pivot
        g.fillStyle = '#e3ae45'; g.beginPath(); g.moveTo(-hw - 1, -6); g.lineTo(-hw + 8, 0); g.lineTo(-hw - 1, 6); g.fill(); g.beginPath(); g.moveTo(hw + 1, -6); g.lineTo(hw - 8, 0); g.lineTo(hw + 1, 6); g.fill();
      }
      g.restore();
      g.strokeStyle = sc < 1 ? 'rgba(238,106,85,.9)' : 'rgba(242,233,216,.55)'; g.lineWidth = 1.6; g.strokeRect(-hw, -hh, hw * 2, hh * 2);
      if (A.wind) { g.fillStyle = 'rgba(0,0,0,.4)'; for (const sx2 of [-1, 1]) { for (let y = -hh; y < hh; y += 8) { g.beginPath(); g.moveTo(sx2 * hw, y); g.lineTo(sx2 * (hw + 5 + (hash32(y | 0, 3) % 4)), y + 4); g.lineTo(sx2 * hw, y + 8); g.fill(); } } }
      if (sc < 1) { g.strokeStyle = 'rgba(238,106,85,.3)'; g.setLineDash([3, 4]); g.lineWidth = 1; g.strokeRect(-A.hw, -A.hh, A.hw * 2, A.hh * 2); g.setLineDash([]); }
    }
    drawGear(g, W, now, thumbMode);
    g.restore();
    void X; void Y; void s;
  }

  /* moving parts and pads on top of the floor (shared by the game view and the picker thumbnails) */
  function drawGear(g, W, now, thumbMode) {
    const A = W.A, t = W.t || 0;
    const shadow = (on) => { g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = on && !thumbMode ? 8 : 0; g.shadowOffsetY = on && !thumbMode ? 3 : 0; };
    if (W.oil) { // slick
      const o = W.oil, fade = Math.min(1, o.t / 1.2);
      g.save(); g.globalAlpha = 0.85 * fade;
      const rg = g.createRadialGradient(o.x - 5, o.y - 5, 2, o.x, o.y, OIL_R); rg.addColorStop(0, '#5b6b7a'); rg.addColorStop(0.5, '#2a2f3a'); rg.addColorStop(1, 'rgba(20,22,30,.7)');
      g.beginPath(); for (let i = 0; i <= 12; i++) { const an = i / 12 * Math.PI * 2, r = OIL_R * (0.88 + 0.12 * Math.sin(i * 2.3)); i ? g.lineTo(o.x + Math.cos(an) * r, o.y + Math.sin(an) * r) : g.moveTo(o.x + Math.cos(an) * r, o.y + Math.sin(an) * r); }
      g.closePath(); g.fillStyle = rg; g.fill();
      g.strokeStyle = 'rgba(200,160,255,.35)'; g.lineWidth = 1.2; g.beginPath(); g.arc(o.x - 4, o.y - 3, OIL_R * 0.45, 0.4, 2.2); g.stroke();
      g.strokeStyle = 'rgba(120,230,200,.3)'; g.beginPath(); g.arc(o.x + 3, o.y + 2, OIL_R * 0.6, 3.6, 5.2); g.stroke();
      g.restore();
    }
    if (A.vents) VENTS.forEach((v, k) => {
      const st2 = thumbMode ? (k === 0 ? 1 : 0) : ventState(W, k);
      g.beginPath(); g.arc(v[0], v[1], 11, 0, 7); g.fillStyle = '#4a2a20'; g.fill(); // little cone
      const eg = g.createRadialGradient(v[0], v[1], 1, v[0], v[1], 7); eg.addColorStop(0, st2 ? '#fff0a0' : '#ff8a3a'); eg.addColorStop(1, st2 ? '#ff6a1a' : '#5a1a0a');
      g.beginPath(); g.arc(v[0], v[1], 7, 0, 7); g.fillStyle = eg; g.fill();
      g.lineWidth = 1.5; g.strokeStyle = st2 ? '#ffd27a' : '#2a140c'; g.stroke();
      if (st2 === 1) { g.beginPath(); g.arc(v[0], v[1], VENT_R, 0, 7); g.fillStyle = 'rgba(255,90,30,' + (0.12 + 0.12 * Math.sin(now / 70)) + ')'; g.fill(); g.setLineDash([3, 3]); g.strokeStyle = 'rgba(255,140,60,.8)'; g.lineWidth = 1; g.stroke(); g.setLineDash([]); }
      if (st2 === 2) { const rg = g.createRadialGradient(v[0], v[1], 2, v[0], v[1], VENT_R); rg.addColorStop(0, 'rgba(255,230,120,.95)'); rg.addColorStop(0.5, 'rgba(255,110,30,.6)'); rg.addColorStop(1, 'rgba(255,60,20,0)'); g.fillStyle = rg; g.beginPath(); g.arc(v[0], v[1], VENT_R, 0, 7); g.fill(); }
    });
    if (A.mag) {
      const m = thumbMode ? { k: 0, warn: false, on: true } : magState(W);
      MAGS.forEach((p, k) => {
        const act = m.on && m.k === k;
        if (act && !m.warn) { g.save(); g.beginPath(); g.arc(0, 0, curR(W), 0, 7); g.clip(); g.beginPath(); g.arc(p[0], p[1], MAG_R, 0, 7); g.fillStyle = 'rgba(238,106,85,.08)'; g.fill(); for (let i = 0; i < 3; i++) { const r = MAG_R * (1 - frac(t * 0.9 + i / 3)); g.beginPath(); g.arc(p[0], p[1], r, 0, 7); g.strokeStyle = 'rgba(238,106,85,' + (0.45 * r / MAG_R) + ')'; g.lineWidth = 1.2; g.stroke(); } g.restore(); }
        g.save(); shadow(true); g.beginPath(); g.arc(p[0], p[1], 13, 0, 7); g.fillStyle = act ? (m.warn ? (Math.sin(now / 80) > 0 ? '#ee6a55' : '#5a3a40') : '#ee6a55') : '#4a525e'; g.fill(); g.restore();
        g.lineWidth = 4; g.strokeStyle = act ? '#ffd0c8' : '#8a95a3'; g.beginPath(); g.arc(p[0], p[1], 7, Math.PI * 0.15, Math.PI * 0.85, true); g.stroke(); // horseshoe
        g.fillStyle = act ? '#ffffff' : '#c4ccd6'; g.fillRect(p[0] - 9, p[1] + 1, 4, 4); g.fillRect(p[0] + 5, p[1] + 1, 4, 4);
      });
    }
    if (A.pads) for (const p of PADS) {
      g.save(); shadow(true); g.beginPath(); g.arc(p[0], p[1], p[2] + 2, 0, 7); g.fillStyle = '#2a2a33'; g.fill(); g.restore();
      g.beginPath(); g.arc(p[0], p[1], p[2], 0, 7); g.fillStyle = '#ffd84a'; g.fill();
      g.beginPath(); g.arc(p[0], p[1], p[2] * 0.62, 0, 7); g.strokeStyle = '#d29a1c'; g.lineWidth = 1.2; g.stroke();
      g.fillStyle = '#7a4a10'; g.beginPath(); g.moveTo(p[0], p[1] - 4); g.lineTo(p[0] + 3.4, p[1] + 1); g.lineTo(p[0] - 3.4, p[1] + 1); g.closePath(); g.fill();
    }
    if (A.bhole) { // the hole itself
      const rg = g.createRadialGradient(0, 0, 0, 0, 0, BH_R + 8); rg.addColorStop(0, '#000'); rg.addColorStop(BH_R / (BH_R + 8), '#000'); rg.addColorStop(1, 'rgba(160,120,255,0)');
      g.fillStyle = rg; g.beginPath(); g.arc(0, 0, BH_R + 8, 0, 7); g.fill();
      g.beginPath(); g.arc(0, 0, BH_R + 1, 0, 7); g.strokeStyle = 'rgba(255,200,120,' + (0.5 + 0.3 * Math.sin(now / 120)) + ')'; g.lineWidth = 1.4; g.stroke();
    }
    if (A.posts) for (const p of A.posts) {
      g.save(); shadow(true); g.beginPath(); g.arc(p[0], p[1], p[2], 0, 7); g.fillStyle = '#f07fb8'; g.fill(); g.restore();
      g.beginPath(); g.arc(p[0], p[1], p[2] * 0.7, 0, 7); g.fillStyle = '#ffd1e8'; g.fill();
      g.beginPath(); g.arc(p[0], p[1], p[2] * 0.35, 0, 7); g.fillStyle = '#f07fb8'; g.fill();
      if (!thumbMode) { g.beginPath(); g.arc(p[0], p[1], p[2] + 2 + Math.sin(now / 150) * 1, 0, 7); g.strokeStyle = 'rgba(240,127,184,.5)'; g.lineWidth = 1; g.stroke(); }
    }
    if (A.flip) for (const f of flippers(W)) {
      const ex = Math.cos(f[2]), ey = Math.sin(f[2]), hot = Math.abs(f[3]) > 0.5;
      g.save(); shadow(true); g.lineCap = 'round';
      g.beginPath(); g.moveTo(f[0], f[1]); g.lineTo(f[0] + ex * f[4], f[1] + ey * f[4]); g.strokeStyle = hot ? '#fff3cf' : '#f2e9d8'; g.lineWidth = FL_TH * 2 + 1.5; g.stroke(); g.restore();
      g.lineCap = 'round'; g.beginPath(); g.moveTo(f[0], f[1]); g.lineTo(f[0] + ex * f[4], f[1] + ey * f[4]); g.strokeStyle = '#ee6a55'; g.lineWidth = FL_TH * 1.1; g.stroke(); g.lineCap = 'butt';
      g.beginPath(); g.arc(f[0], f[1], 3, 0, 7); g.fillStyle = '#ffe08a'; g.fill();
    }
    if (A.jelly) for (const q of jellies(W)) { // translucent bells with trailing tentacles
      const pul = 1 + 0.08 * Math.sin(t * 5 + q[0]);
      g.save(); g.translate(q[0], q[1]);
      g.strokeStyle = 'rgba(240,168,255,.55)'; g.lineWidth = 1;
      const bx = -q[3], by = -q[4], bl = Math.hypot(bx, by) || 1;
      for (let i = -2; i <= 2; i++) { g.beginPath(); g.moveTo(i * 3, 0); g.quadraticCurveTo(i * 3 + bx / bl * 9 + Math.sin(t * 6 + i) * 3, by / bl * 9, i * 3 + bx / bl * 18, by / bl * 18 + Math.cos(t * 5 + i) * 2); g.stroke(); }
      const rg = g.createRadialGradient(-3, -3, 1, 0, 0, q[2] * pul); rg.addColorStop(0, 'rgba(255,230,255,.95)'); rg.addColorStop(1, 'rgba(220,120,240,.55)');
      g.beginPath(); g.arc(0, 0, q[2] * pul, 0, 7); g.fillStyle = rg; g.fill(); g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 1; g.stroke();
      g.restore();
    }
    if (A.top) {
      const q = topOf(W);
      g.save(); g.translate(q[0], q[1]);
      shadow(true); g.beginPath(); g.arc(0, 0, q[2], 0, 7); g.fillStyle = '#e3ae45'; g.fill(); g.shadowBlur = 0; g.shadowOffsetY = 0;
      g.rotate(t * 9 * q[5]);
      for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, q[2], i * Math.PI / 3, i * Math.PI / 3 + Math.PI / 6); g.closePath(); g.fillStyle = i % 2 ? '#ee6a55' : '#5bb3e6'; g.fill(); }
      g.beginPath(); g.arc(0, 0, q[2] * 0.4, 0, 7); g.fillStyle = '#f2e9d8'; g.fill();
      g.beginPath(); g.arc(0, 0, 2.5, 0, 7); g.fillStyle = '#3d2f5c'; g.fill();
      g.restore();
      if (!thumbMode) { g.beginPath(); g.arc(q[0], q[1], q[2] + 3, t * 9 * q[5], t * 9 * q[5] + 2); g.strokeStyle = 'rgba(255,243,207,.5)'; g.lineWidth = 1.2; g.stroke(); }
    }
    if (A.laser) {
      const z = laserOf(W), ex = Math.cos(z.ang), ey = Math.sin(z.ang), Lr = curR(W);
      if (z.on || thumbMode) {
        g.save(); g.lineCap = 'round';
        g.shadowColor = 'rgba(255,60,90,.9)'; g.shadowBlur = thumbMode ? 0 : 10;
        g.beginPath(); g.moveTo(-ex * Lr, -ey * Lr); g.lineTo(ex * Lr, ey * Lr); g.strokeStyle = 'rgba(255,84,112,.9)'; g.lineWidth = 5; g.stroke();
        g.shadowBlur = 0; g.strokeStyle = '#ffe0e6'; g.lineWidth = 1.6; g.stroke(); g.restore();
      } else if (z.warn) {
        g.setLineDash([4, 4]); g.beginPath(); g.moveTo(-ex * Lr, -ey * Lr); g.lineTo(ex * Lr, ey * Lr); g.strokeStyle = 'rgba(255,84,112,' + (0.4 + 0.4 * Math.sin(now / 60)) + ')'; g.lineWidth = 1.5; g.stroke(); g.setLineDash([]);
      }
      for (const sg of [-1, 1]) { g.beginPath(); g.arc(sg * ex * (Lr + 3), sg * ey * (Lr + 3), 3.5, 0, 7); g.fillStyle = z.on ? '#ff5470' : '#5a2a35'; g.fill(); }
      g.beginPath(); g.arc(0, 0, 6, 0, 7); g.fillStyle = z.on ? '#ff5470' : '#5a2a35'; g.fill();
    }
    if (A.piston) { // rams: housing in the wall + the sliding block
      const hw = A.hw * sudden(W);
      for (const q of pistons(W)) {
        const sd = q[0], e = thumbMode ? (q[1] === 0 && sd < 0 ? RAM_D * 0.8 : 0) : q[2], warn = !thumbMode && q[4] === 1;
        const hx = sd < 0 ? -hw - 9 : hw + 1;
        g.fillStyle = warn ? (Math.sin(now / 70) > 0 ? '#ee6a55' : '#7a3a34') : '#2a2c34'; g.fillRect(hx, q[1] - RAM_H - 2, 8, RAM_H * 2 + 4);
        if (e > 0.5) {
          const x0 = sd < 0 ? -hw : hw - e;
          g.save(); shadow(true); g.fillStyle = '#c4c9d2'; g.fillRect(x0, q[1] - RAM_H, e, RAM_H * 2); g.restore();
          g.save(); g.beginPath(); g.rect(x0, q[1] - RAM_H, e, RAM_H * 2); g.clip(); g.strokeStyle = 'rgba(227,174,69,.9)'; g.lineWidth = 3;
          const face = sd < 0 ? x0 + e : x0; for (let y = q[1] - RAM_H - 8; y < q[1] + RAM_H + 8; y += 7) { g.beginPath(); g.moveTo(face - sd * 5, y); g.lineTo(face, y + 5); g.stroke(); }
          g.restore();
          g.fillStyle = '#5a5f6a'; g.fillRect(sd < 0 ? x0 + e - 3 : x0, q[1] - RAM_H, 3, RAM_H * 2);
        }
        if (warn) { g.fillStyle = 'rgba(238,106,85,' + (0.18 + 0.12 * Math.sin(now / 70)) + ')'; g.fillRect(sd < 0 ? -hw : hw - RAM_D, q[1] - RAM_H, RAM_D, RAM_H * 2); }
      }
    }
    if (A.fans) { // three fans on the rim; the live one blows along its lane
      const f = thumbMode ? { k: 0, warn: 0, e: 1 } : (W.fan || fanState(W)), R = A.R;
      for (let k = 0; k < 3; k++) {
        const an = fanAng(W, k), ca = Math.cos(an), sa = Math.sin(an), fx = ca * (R + 8), fy = sa * (R + 8), live = f.k === k;
        if (live && f.e > 0) { // gusts streaming across the lane
          g.save(); g.beginPath(); g.arc(0, 0, R, 0, 7); g.clip(); g.fillStyle = 'rgba(200,230,255,' + (0.12 * f.e) + ')';
          g.beginPath(); g.moveTo(ca * R - sa * FAN_W, sa * R + ca * FAN_W); g.lineTo(-ca * R - sa * FAN_W, -sa * R + ca * FAN_W); g.lineTo(-ca * R + sa * FAN_W, -sa * R - ca * FAN_W); g.lineTo(ca * R + sa * FAN_W, sa * R - ca * FAN_W); g.closePath(); g.fill();
          g.strokeStyle = 'rgba(235,248,255,' + (0.6 * f.e) + ')'; g.lineWidth = 1.3;
          for (let i = 0; i < 9; i++) { const off = ((i * 37) % 50) - 25, u = frac((now || 0) / 700 + i / 9) * 2 * R - R; g.beginPath(); g.moveTo(ca * -u - sa * off, sa * -u + ca * off); g.lineTo(ca * (-u - 16) - sa * off, sa * (-u - 16) + ca * off); g.stroke(); }
          g.restore();
        }
        if (live && f.warn) { g.save(); g.setLineDash([4, 4]); g.strokeStyle = 'rgba(238,106,85,' + (0.5 + 0.4 * Math.sin(now / 80)) + ')'; g.lineWidth = 1.4; for (const sg of [-1, 1]) { g.beginPath(); g.moveTo(ca * R - sa * FAN_W * sg, sa * R + ca * FAN_W * sg); g.lineTo(-ca * R - sa * FAN_W * sg, -sa * R + ca * FAN_W * sg); g.stroke(); } g.restore(); }
        g.save(); g.translate(fx, fy); g.rotate(an);
        g.save(); shadow(true); g.fillStyle = live ? (f.warn ? '#ee6a55' : '#e3ae45') : '#4a5462'; g.fillRect(-6, -FAN_W * 0.8, 12, FAN_W * 1.6); g.restore();
        g.translate(-3, 0); const spin = live ? (now || 0) / (f.warn ? 60 : 25) : 0;
        g.strokeStyle = '#f2e9d8'; g.lineWidth = 2.2; for (let b = 0; b < 3; b++) { const ba = spin + b * 2.094; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(ba) * 2.5, Math.sin(ba) * 13); g.stroke(); }
        g.restore();
      }
    }
    if (A.arms) { // windmill: hub + three beams
      for (const f of armsOf(W)) {
        const ex = Math.cos(f[2]), ey = Math.sin(f[2]);
        g.save(); shadow(true); g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 0); g.lineTo(ex * f[4], ey * f[4]); g.strokeStyle = '#5a3d1e'; g.lineWidth = ARM_TH * 2 + 1.5; g.stroke(); g.restore();
        g.lineCap = 'round'; g.beginPath(); g.moveTo(ex * 8, ey * 8); g.lineTo(ex * f[4], ey * f[4]); g.strokeStyle = '#d9b27a'; g.lineWidth = ARM_TH * 1.3; g.stroke(); g.lineCap = 'butt';
        g.fillStyle = '#ee6a55'; g.beginPath(); g.arc(ex * f[4], ey * f[4], 3, 0, 7); g.fill();
      }
      g.beginPath(); g.arc(0, 0, 9, 0, 7); g.fillStyle = '#3d2f5c'; g.fill(); g.beginPath(); g.arc(0, 0, 4, 0, 7); g.fillStyle = '#e3ae45'; g.fill();
    }
    if (A.pop) POPS.forEach((p, k) => { // posts: flush disc / glowing warning / raised column
      const ps = thumbMode ? { s: k % 3 === 0 ? 2 : k % 3 === 1 ? 1 : 0, age: 1 } : popState(W, k);
      if (ps.s === 2) {
        const up = Math.min(1, ps.age / 0.15);
        g.save(); shadow(true); g.beginPath(); g.arc(p[0], p[1] - 2 * up, PO_R, 0, 7); g.fillStyle = '#e3ae45'; g.fill(); g.restore();
        g.beginPath(); g.arc(p[0], p[1] - 2 * up, PO_R * 0.68, 0, 7); g.fillStyle = '#ffe2a0'; g.fill();
        g.beginPath(); g.arc(p[0], p[1] - 2 * up, PO_R * 0.3, 0, 7); g.fillStyle = '#b37a1c'; g.fill();
      } else {
        g.beginPath(); g.arc(p[0], p[1], PO_R, 0, 7); g.fillStyle = '#2a2440'; g.fill(); g.lineWidth = 1.2; g.strokeStyle = 'rgba(227,174,69,.5)'; g.stroke();
        if (ps.s === 1) { g.beginPath(); g.arc(p[0], p[1], PO_R + 2 + Math.sin(now / 60) * 1.5, 0, 7); g.strokeStyle = '#ffd27a'; g.lineWidth = 2; g.stroke(); g.fillStyle = 'rgba(255,210,122,' + (0.25 + 0.2 * Math.sin(now / 60)) + ')'; g.fill(); }
      }
    });
    if (A.bombs) for (const b of (thumbMode ? [[30, -20, 0.6, 0], [-40, 30, 0.2, 1]] : bombsOf(W))) { // target + shadow of the falling bomb
      const p = b[2];
      g.beginPath(); g.arc(b[0], b[1], BB_R, 0, 7); g.fillStyle = 'rgba(238,106,85,' + (0.06 + 0.14 * p) + ')'; g.fill();
      g.setLineDash([4, 4]); g.strokeStyle = 'rgba(238,106,85,.8)'; g.lineWidth = 1.2; g.stroke(); g.setLineDash([]);
      g.beginPath(); g.arc(b[0], b[1], BB_R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p); g.strokeStyle = '#ee6a55'; g.lineWidth = 2.4; g.stroke();
      g.strokeStyle = 'rgba(238,106,85,.7)'; g.lineWidth = 1; g.beginPath(); g.moveTo(b[0] - 6, b[1]); g.lineTo(b[0] + 6, b[1]); g.moveTo(b[0], b[1] - 6); g.lineTo(b[0], b[1] + 6); g.stroke();
      g.beginPath(); g.ellipse(b[0], b[1], 3 + 6 * p, 2.4 + 4.8 * p, 0, 0, 7); g.fillStyle = 'rgba(0,0,0,' + (0.15 + 0.35 * p) + ')'; g.fill();
      if (p > 0.8) { const h = (1 - p) * 120; g.beginPath(); g.arc(b[0], b[1] - h, 6.5, 0, 7); g.fillStyle = '#26222c'; g.fill(); g.beginPath(); g.arc(b[0] + 3, b[1] - h - 5, 1.8, 0, 7); g.fillStyle = '#ffd27a'; g.fill(); }
    }
    if (A.wreck) { // the cable hangs from the crane right above the middle
      const q = wreckOf(W);
      g.beginPath(); g.ellipse(q[0] + 4, q[1] + 6, q[2], q[2] * 0.85, 0, 0, 7); g.fillStyle = 'rgba(0,0,0,.35)'; g.fill();
      g.strokeStyle = '#3a3530'; g.lineWidth = 2.2; g.beginPath(); g.moveTo(0, 0); g.lineTo(q[0], q[1]); g.stroke();
      g.beginPath(); g.arc(0, 0, 5, 0, 7); g.fillStyle = '#e3ae45'; g.fill();
      const bg = g.createRadialGradient(q[0] - 5, q[1] - 5, 2, q[0], q[1], q[2]); bg.addColorStop(0, '#9aa0aa'); bg.addColorStop(1, '#2c2f36');
      g.beginPath(); g.arc(q[0], q[1], q[2], 0, 7); g.fillStyle = bg; g.fill(); g.strokeStyle = '#17131f'; g.lineWidth = 1; g.stroke();
      g.beginPath(); g.arc(q[0], q[1], 3, 0, 7); g.fillStyle = '#5a5f6a'; g.fill();
    }
    if (A.gust && !thumbMode) { // gust: a big arrow while it's coming, snow streaks while it blows
      const gu = gustAt(W, t);
      if (gu.warn || gu.e > 0) {
        const ca = Math.cos(gu.an), sa = Math.sin(gu.an);
        if (gu.warn) {
          g.save(); g.globalAlpha = 0.45 + 0.35 * Math.sin(now / 80); g.strokeStyle = '#ee6a55'; g.lineWidth = 6; g.lineCap = 'round'; g.lineJoin = 'round';
          g.beginPath(); g.moveTo(-ca * 26, -sa * 26); g.lineTo(ca * 26, sa * 26); g.stroke();
          g.beginPath(); g.moveTo(ca * 26 + Math.cos(gu.an + 2.5) * 12, sa * 26 + Math.sin(gu.an + 2.5) * 12); g.lineTo(ca * 26, sa * 26); g.lineTo(ca * 26 + Math.cos(gu.an - 2.5) * 12, sa * 26 + Math.sin(gu.an - 2.5) * 12); g.stroke();
          g.restore();
        } else {
          const sc = sudden(W); g.save(); g.beginPath(); g.rect(-A.hw * sc, -A.hh * sc, A.hw * sc * 2, A.hh * sc * 2); g.clip();
          g.strokeStyle = 'rgba(90,140,190,' + (0.6 * gu.e) + ')'; g.lineWidth = 1.2;
          for (let i = 0; i < 18; i++) { const off = (hash32(i, 95) % 220) - 110, u = frac((now || 0) / 600 + i / 18) * 240 - 120; g.beginPath(); g.moveTo(ca * u - sa * off, sa * u + ca * off); g.lineTo(ca * (u - 14) - sa * off, sa * (u - 14) + ca * off); g.stroke(); }
          g.restore();
        }
      }
    }
    if (A.fence) { // rubber fence with two travelling gaps
      const R = A.R, gs = fenceGaps(W, t);
      g.save(); g.lineCap = 'round';
      for (let k = 0; k < 2; k++) {
        const a0 = gs[k] + FN_GAP / 2, a1 = gs[(k + 1) % 2] - FN_GAP / 2 + (k ? Math.PI * 2 : 0);
        g.beginPath(); g.arc(0, 0, R + 1, a0, k ? a1 : a1); g.strokeStyle = '#2a1a22'; g.lineWidth = 6; g.stroke();
        g.beginPath(); g.arc(0, 0, R + 1, a0, a1); g.strokeStyle = '#f07fb8'; g.lineWidth = 3.6; g.stroke();
      }
      for (const a of gs) { g.beginPath(); g.arc(0, 0, R + 3, a - FN_GAP / 2, a + FN_GAP / 2); g.strokeStyle = 'rgba(238,106,85,.55)'; g.lineWidth = 2; g.setLineDash([3, 3]); g.stroke(); g.setLineDash([]); }
      for (const a of gs) for (const sg of [-1, 1]) { const e = a + sg * FN_GAP / 2; g.beginPath(); g.arc(Math.cos(e) * (R + 1), Math.sin(e) * (R + 1), 3.2, 0, 7); g.fillStyle = '#ffd1e8'; g.fill(); }
      g.restore();
    }
    if (A.slope) { // chevrons rolling downhill
      const an = slopeAng(W, t), ca = Math.cos(an), sa = Math.sin(an), off = thumbMode ? 0 : frac((now || 0) / 900) * 26;
      g.save(); g.beginPath(); g.arc(0, 0, A.R, 0, 7); g.clip(); g.strokeStyle = 'rgba(255,240,210,.45)'; g.lineWidth = 3; g.lineCap = 'round'; g.lineJoin = 'round';
      for (let u = -78; u <= 78; u += 26) for (const v of [-40, 0, 40]) { const px = ca * (u + off) - sa * v, py = sa * (u + off) + ca * v; g.beginPath(); g.moveTo(px - ca * 6 - sa * 8, py - sa * 6 + ca * 8); g.lineTo(px, py); g.lineTo(px - ca * 6 + sa * 8, py - sa * 6 - ca * 8); g.stroke(); }
      g.restore();
    }
    if (A.portal) for (const p of portalsOf(W)) { // swirling rings; same colour = linked
      const col = p[2] ? '#ffb02e' : '#7fd8ff';
      const rg = g.createRadialGradient(p[0], p[1], 1, p[0], p[1], PT_R + 3); rg.addColorStop(0, '#0b0814'); rg.addColorStop(0.7, hexA(col, 0.6)); rg.addColorStop(1, hexA(col, 0));
      g.beginPath(); g.arc(p[0], p[1], PT_R + 3, 0, 7); g.fillStyle = rg; g.fill();
      g.save(); g.translate(p[0], p[1]); g.rotate((thumbMode ? 0 : (now || 0) / 300) * (p[3] ? -1 : 1)); g.strokeStyle = col; g.lineWidth = 1.8;
      for (let i = 0; i < 3; i++) { g.beginPath(); g.arc(0, 0, PT_R - 1 - i * 2.6, i * 2, i * 2 + 3.6); g.stroke(); }
      g.restore();
      g.beginPath(); g.arc(p[0], p[1], PT_R, 0, 7); g.strokeStyle = col; g.lineWidth = 1.4; g.stroke();
    }
    if (A.boost) for (let k = 0; k < 6; k++) { // arrow pads
      const p = BS_POS[k], b = boostDir(W, k, t), blink = !thumbMode && b.warn && Math.sin((now || 0) / 70) > 0;
      g.save(); g.translate(p[0], p[1]);
      g.beginPath(); g.arc(0, 0, BS_R, 0, 7); g.fillStyle = blink ? '#ee6a55' : '#ffb02e'; g.fill(); g.strokeStyle = '#2a1a0a'; g.lineWidth = 1.2; g.stroke();
      g.rotate(b.an); g.fillStyle = '#2a1a0a';
      for (const o of [-4, 3]) { g.beginPath(); g.moveTo(o - 3, -6); g.lineTo(o + 3, 0); g.lineTo(o - 3, 6); g.lineTo(o - 0.5, 0); g.closePath(); g.fill(); }
      g.restore();
    }
    if (A.rift) { // the crack: red dashes while it's coming, a dark chasm while it's open
      const z = thumbMode ? { an: 0.6, w: RF_W, warn: 0 } : riftOf(W, t), ca = Math.cos(z.an), sa = Math.sin(z.an), R = A.R + 2;
      g.save(); g.beginPath(); g.arc(0, 0, A.R, 0, 7); g.clip();
      if (z.w > 0) {
        g.fillStyle = '#0b0810'; g.beginPath(); g.moveTo(-ca * R - sa * z.w, -sa * R + ca * z.w); g.lineTo(ca * R - sa * z.w, sa * R + ca * z.w); g.lineTo(ca * R + sa * z.w, sa * R - ca * z.w); g.lineTo(-ca * R + sa * z.w, -sa * R - ca * z.w); g.closePath(); g.fill();
        g.strokeStyle = 'rgba(255,120,60,.5)'; g.lineWidth = 1.2; g.stroke();
      }
      if (z.warn) { g.setLineDash([5, 4]); g.strokeStyle = 'rgba(238,106,85,' + (0.5 + 0.4 * Math.sin((now || 0) / 70)) + ')'; g.lineWidth = 1.6; for (const sg of [-1, 1]) { g.beginPath(); g.moveTo(-ca * R - sa * RF_W * sg, -sa * R + ca * RF_W * sg); g.lineTo(ca * R - sa * RF_W * sg, sa * R + ca * RF_W * sg); g.stroke(); } g.setLineDash([]); }
      g.restore();
    }
    if (A.logs) for (const q of (thumbMode ? [[20, 0, 1, 2]] : logsOf(W))) { // logs + warning arrows at the edge they come from
      if (q[3] === 1) {
        const ey = -q[2] * (A.hh - 10);
        g.save(); g.globalAlpha = 0.5 + 0.4 * Math.sin((now || 0) / 70); g.strokeStyle = '#ee6a55'; g.lineWidth = 4; g.lineCap = 'round'; g.lineJoin = 'round';
        g.beginPath(); g.moveTo(q[0] - 10, ey - q[2] * 4); g.lineTo(q[0], ey + q[2] * 6); g.lineTo(q[0] + 10, ey - q[2] * 4); g.stroke();
        g.restore(); continue;
      }
      g.save(); shadow(true); g.lineCap = 'round'; g.beginPath(); g.moveTo(q[0] - LG_L, q[1]); g.lineTo(q[0] + LG_L, q[1]); g.strokeStyle = '#7a4a22'; g.lineWidth = LG_R * 2; g.stroke(); g.restore();
      g.strokeStyle = 'rgba(40,20,5,.5)'; g.lineWidth = 1.2; const sp = thumbMode ? 0 : frac(q[1] / 9) * 9;
      for (let x = -LG_L + 4; x < LG_L; x += 9) { g.beginPath(); g.moveTo(q[0] + x, q[1] - LG_R + 1.5); g.lineTo(q[0] + x + 2, q[1] + LG_R - 1.5); g.stroke(); }
      void sp;
      for (const sg of [-1, 1]) { g.beginPath(); g.arc(q[0] + sg * LG_L, q[1], LG_R - 0.5, 0, 7); g.fillStyle = '#c99a62'; g.fill(); g.strokeStyle = '#7a4a22'; g.lineWidth = 1; g.stroke(); g.beginPath(); g.arc(q[0] + sg * LG_L, q[1], 3, 0, 7); g.stroke(); }
    }
    if (A.wave) { // a foaming wave band
      const wv = thumbMode ? { x: -20, dir: 1, warn: 0 } : waveOf(W), hw = A.hw, hh = A.hh;
      g.save(); g.beginPath(); g.rect(-hw, -hh, hw * 2, hh * 2); g.clip();
      if (wv.x != null) {
        const x0 = wv.x - WV_H, gr = g.createLinearGradient(x0, 0, x0 + WV_H * 2, 0);
        gr.addColorStop(wv.dir > 0 ? 0 : 1, 'rgba(70,150,210,.15)'); gr.addColorStop(0.5, 'rgba(90,170,230,.7)'); gr.addColorStop(wv.dir > 0 ? 1 : 0, 'rgba(240,250,255,.95)');
        g.fillStyle = gr; g.fillRect(x0, -hh, WV_H * 2, hh * 2);
        g.fillStyle = 'rgba(255,255,255,.9)'; for (let y = -hh; y < hh; y += 9) { g.beginPath(); g.arc(wv.x + wv.dir * WV_H, y + Math.sin(y + (now || 0) / 100) * 2, 2.6, 0, 7); g.fill(); }
      } else if (wv.warn) {
        const ex = -wv.warn * hw; g.fillStyle = 'rgba(255,255,255,' + (0.35 + 0.3 * Math.sin((now || 0) / 70)) + ')';
        for (let y = -hh; y < hh; y += 10) { g.beginPath(); g.arc(ex + wv.warn * 3, y, 3, 0, 7); g.fill(); }
        g.strokeStyle = '#ee6a55'; g.lineWidth = 4; g.lineCap = 'round'; g.lineJoin = 'round';
        for (const y of [-hh / 2, 0, hh / 2]) { g.beginPath(); g.moveTo(ex + wv.warn * 6, y - 10); g.lineTo(ex + wv.warn * 16, y); g.lineTo(ex + wv.warn * 6, y + 10); g.stroke(); }
      }
      g.restore();
    }
    if (A.walls) for (const sg of [-1, 1]) { // the rubber walls
      g.save(); shadow(true); g.fillStyle = '#f07fb8'; g.fillRect(sg < 0 ? -A.hw - 6 : A.hw, -A.hh, 6, A.hh * 2); g.restore();
      g.fillStyle = '#ffd1e8'; for (let y = -A.hh + 10; y < A.hh; y += 20) { g.beginPath(); g.arc(sg * (A.hw + 3) - sg * 3 + sg * 3, y, 1.6, 0, 7); g.fill(); }
    }
    if (A.quake && !thumbMode) { // which way the next jolt throws you
      const q = quakeOf(W);
      if (q.warn) {
        const ca = Math.cos(q.an), sa = Math.sin(q.an);
        g.save(); g.globalAlpha = 0.5 + 0.4 * Math.sin(now / 70); g.strokeStyle = '#ee6a55'; g.lineWidth = 6; g.lineCap = 'round'; g.lineJoin = 'round';
        g.beginPath(); g.moveTo(-ca * 22, -sa * 22); g.lineTo(ca * 22, sa * 22); g.stroke();
        g.beginPath(); g.moveTo(ca * 22 + Math.cos(q.an + 2.5) * 11, sa * 22 + Math.sin(q.an + 2.5) * 11); g.lineTo(ca * 22, sa * 22); g.lineTo(ca * 22 + Math.cos(q.an - 2.5) * 11, sa * 22 + Math.sin(q.an - 2.5) * 11); g.stroke();
        g.restore();
      }
    }
  }

  /* ---------- power-up icons: plain vector drawings (no emoji / font glyphs, so they show on every phone) ---------- */
  function inkOf(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return '#17131f';
    const n = parseInt(m[1], 16), l = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
    return l > 0.55 ? '#17131f' : '#fbf5ea';
  }
  /* the glyph for item k inside a disc of radius r centred on (0, 0); ink = glyph colour, bg = disc colour (for cut-outs) */
  function drawIcon(g, k, r, ink, bg) {
    g.save(); g.scale(r / 10, r / 10);
    g.fillStyle = ink; g.strokeStyle = ink; g.lineWidth = 1.9; g.lineCap = 'round'; g.lineJoin = 'round';
    const P = (pts, close) => { g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); if (close) g.closePath(); };
    const C = (x, y, rr) => { g.beginPath(); g.arc(x, y, rr, 0, Math.PI * 2); };
    const arrow = (x0, y0, x1, y1, hl) => { const a = Math.atan2(y1 - y0, x1 - x0); P([[x0, y0], [x1, y1]]); g.stroke(); P([[x1 - Math.cos(a - 0.6) * hl, y1 - Math.sin(a - 0.6) * hl], [x1, y1], [x1 - Math.cos(a + 0.6) * hl, y1 - Math.sin(a + 0.6) * hl]]); g.stroke(); };
    switch (k) {
      case 'h': // cartoon weight with a ring on top
        g.lineWidth = 2; C(0, -6, 2.6); g.stroke();
        P([[-4.6, -3.2], [4.6, -3.2], [8.2, 8], [-8.2, 8]], true); g.fill();
        g.fillStyle = bg; g.fillRect(-3.6, 2, 7.2, 2); break;
      case 's': // shield
        P([[0, -8.5], [7, -5.5], [6.2, 1.5]]); g.quadraticCurveTo(4.5, 6.8, 0, 9); g.quadraticCurveTo(-4.5, 6.8, -6.2, 1.5); g.lineTo(-7, -5.5); g.closePath(); g.fill();
        g.strokeStyle = bg; g.lineWidth = 1.4; P([[0, -5.5], [0, 5.5]]); g.stroke(); break;
      case 'w': // shock rings
        C(0, 0, 2.6); g.fill(); g.lineWidth = 1.6; C(0, 0, 5.4); g.stroke(); g.globalAlpha = 0.75; C(0, 0, 8.4); g.stroke(); break;
      case 'g': // grappling hook
        g.lineWidth = 2.2; P([[3, -6.5], [3, 2]]); g.stroke(); g.beginPath(); g.arc(-1.5, 2, 4.5, 0, Math.PI); g.stroke();
        P([[-8.4, 0.2], [-6, -3.6], [-3.6, 0.2]], true); g.fill(); C(3, -7.6, 1.8); g.stroke(); break;
      case 'o': // oil drop
        g.beginPath(); g.moveTo(0, -9); g.quadraticCurveTo(7, -0.5, 6, 3); g.arc(0, 3, 6, 0, Math.PI); g.quadraticCurveTo(-7, -0.5, 0, -9); g.fill();
        g.strokeStyle = bg; g.lineWidth = 1.3; g.beginPath(); g.arc(0, 3, 3.4, Math.PI * 0.55, Math.PI * 1.05); g.stroke(); break;
      case 'b': // grow: arrows to the corners
        g.lineWidth = 1.9; for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) arrow(sx * 2.2, sy * 2.2, sx * 8, sy * 8, 3.6);
        break;
      case 'z': // shrink: arrows to the middle
        g.lineWidth = 1.9; for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) arrow(sx * 8.4, sy * 8.4, sx * 2.6, sy * 2.6, 3.4);
        break;
      case 't': // teleport: hollow start, dashed hop, solid end
        g.lineWidth = 1.6; C(-5, 5, 3); g.setLineDash([1.6, 1.6]); g.stroke();
        g.beginPath(); g.moveTo(-3.4, 1.8); g.quadraticCurveTo(-3, -5, 2.2, -5.4); g.stroke(); g.setLineDash([]);
        C(5, -4.6, 3.4); g.fill(); break;
      case 'r': // reverse
        g.lineWidth = 2; arrow(-7, -3.6, 7, -3.6, 3.4); arrow(7, 3.6, -7, 3.6, 3.4); break;
      case 'k': // sticky goo
        C(0, -1.5, 6.2); g.fill(); g.beginPath(); g.ellipse(-4, 4.8, 1.8, 3.4, 0, 0, Math.PI * 2); g.fill();
        g.beginPath(); g.ellipse(1.2, 6, 1.9, 3.2, 0, 0, Math.PI * 2); g.fill(); C(5, 4.4, 1.6); g.fill();
        g.fillStyle = bg; C(-2, -3.4, 1.4); g.fill(); break;
      case 'm': // mirror armour: hexagon + bounce arrow
        g.lineWidth = 1.8; P([0, 1, 2, 3, 4, 5].map((i) => [Math.cos(i * Math.PI / 3 - Math.PI / 2) * 8.4, Math.sin(i * Math.PI / 3 - Math.PI / 2) * 8.4]), true); g.stroke();
        g.lineWidth = 1.8; P([[-4, 3.5], [0, -1.5], [4, 3.5]]); g.stroke(); P([[1.2, -2.6], [4.4, -3.4], [3.6, -0.2]]); g.stroke(); break;
      case 'n': // horseshoe magnet
        g.lineWidth = 3.6; g.lineCap = 'butt'; g.beginPath(); g.arc(0, -1, 5.4, Math.PI, 0); g.stroke(); P([[-5.4, -1], [-5.4, 6.5]]); g.stroke(); P([[5.4, -1], [5.4, 6.5]]); g.stroke();
        g.fillStyle = bg; g.fillRect(-7.4, 4.2, 4, 2.6); g.fillRect(3.4, 4.2, 4, 2.6); break;
      case 'p': // spring
        g.lineWidth = 1.8; P([[-6, 7], [6, 4.6], [-6, 2.2], [6, -0.2], [-6, -2.6], [6, -5]]); g.stroke();
        g.lineWidth = 2.4; P([[-7.5, -7.6], [7.5, -7.6]]); g.stroke(); P([[-7.5, 8.6], [7.5, 8.6]]); g.stroke(); break;
      case 'v': // whirlwind
        g.lineWidth = 2.1; [[-7.4, 8.2, -7], [-5, 6.2, -3.4], [-3, 3.6, 0.2], [-1.2, 2.2, 3.8], [0, 1, 7.2]].forEach(([x0, x1, y]) => { P([[x0, y], [x1, y]]); g.stroke(); }); break;
      case 'x': // bomb
        C(-1.4, 2.2, 6.2); g.fill(); g.lineWidth = 1.7; g.beginPath(); g.moveTo(2.6, -2.4); g.quadraticCurveTo(4, -6.6, 7, -6.8); g.stroke();
        g.lineWidth = 1.3; for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + 0.6; P([[7 + Math.cos(a) * 1.2, -7.6 + Math.sin(a) * 1.2], [7 + Math.cos(a) * 3, -7.6 + Math.sin(a) * 3]]); g.stroke(); }
        g.fillStyle = bg; C(-3.6, 0, 1.5); g.fill(); break;
      case 'u': // snowflake: six spokes with little forks near the tips
        g.lineWidth = 1.8;
        for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 - Math.PI / 2, ca = Math.cos(a), sa = Math.sin(a); P([[0, 0], [ca * 8.6, sa * 8.6]]); g.stroke();
          g.lineWidth = 1.4; P([[ca * 5.2 + Math.cos(a + 0.9) * 2.6, sa * 5.2 + Math.sin(a + 0.9) * 2.6], [ca * 6.4, sa * 6.4], [ca * 5.2 + Math.cos(a - 0.9) * 2.6, sa * 5.2 + Math.sin(a - 0.9) * 2.6]]); g.stroke(); g.lineWidth = 1.8; }
        break;
      case 'f': // turbo chevrons
        g.lineWidth = 2.6; P([[-7, -6], [-1.5, 0], [-7, 6]]); g.stroke(); P([[0.5, -6], [6, 0], [0.5, 6]]); g.stroke(); break;
      case 'y': // ghost
        g.beginPath(); g.moveTo(-6.2, 8.4); g.lineTo(-6.2, -1.6); g.arc(0, -1.6, 6.2, Math.PI, 0); g.lineTo(6.2, 8.4); g.lineTo(4.1, 6.4); g.lineTo(2.1, 8.4); g.lineTo(0, 6.4); g.lineTo(-2.1, 8.4); g.lineTo(-4.1, 6.4); g.closePath(); g.fill();
        g.fillStyle = bg; C(-2.4, -1.6, 1.5); g.fill(); C(2.4, -1.6, 1.5); g.fill(); break;
      case 'c': // cannonball in flight
        C(2.4, 0.6, 6); g.fill(); g.lineWidth = 1.8; for (const [x0, y] of [[-9, -3.4], [-9.6, 0.6], [-9, 4.6]]) { P([[x0, y], [x0 + 4.2, y]]); g.stroke(); }
        g.fillStyle = bg; C(0.4, -1.6, 1.5); g.fill(); break;
      case 'i': // invisible: eye with a slash
        g.lineWidth = 1.7; g.beginPath(); g.moveTo(-8.4, 0); g.quadraticCurveTo(0, -8, 8.4, 0); g.quadraticCurveTo(0, 8, -8.4, 0); g.closePath(); g.stroke();
        C(0, 0, 2.6); g.fill(); g.lineWidth = 2.2; g.strokeStyle = bg; P([[-7.2, 7.2], [7.2, -7.2]]); g.stroke(); g.strokeStyle = ink; g.lineWidth = 1.5; P([[-7.2, 7.2], [7.2, -7.2]]); g.stroke(); break;
      default: C(0, 0, 4); g.fill();
    }
    g.restore();
  }
  /* a coloured token with the item glyph (floor pick-up, badges, banners) */
  function itemDisc(g, k, x, y, r, shadow) {
    const I = ITEMS[k] || ITEMS.h, ink = inkOf(I.col);
    g.save(); g.translate(x, y);
    if (shadow) { g.shadowColor = hexA(I.col, 0.9); g.shadowBlur = shadow; }
    g.beginPath(); g.arc(0, 0, r, 0, Math.PI * 2); g.fillStyle = I.col; g.fill();
    g.shadowBlur = 0; g.lineWidth = Math.max(0.8, r * 0.1); g.strokeStyle = 'rgba(23,19,31,.85)'; g.stroke();
    drawIcon(g, k, r * 0.78, ink, I.col);
    g.restore();
  }

  /* ---------- helpers ---------- */
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }
  const shadeHex = shade;

  /* ---------- 도감(codex): built from ARENAS · ITEMS · VICTIM and the rules text ---------- */
  function codexIcon(draw) {
    const dpr = Math.min(2, window.devicePixelRatio || 1), c = L.h('canvas');
    c.width = c.height = Math.round(36 * dpr); c.style.width = c.style.height = '36px'; c.style.display = 'block';
    const g = c.getContext('2d'); g.scale(dpr, dpr); draw(g); return c;
  }
  const boxOf = (A) => (A.shape === 'x' ? X_L * 2 : A.shape === 'c' ? A.R * 2 + (A.fans ? 16 : 0) : A.shape === 'p' ? (PL_D1 + PL_HS) * 2 : Math.max(A.hw, A.hh) * 2);
  const arenaIcon = (id) => codexIcon((g) => {
    const A = ARENAS[id], s = 36 / (boxOf(A) + 16);
    g.translate(18, 18); g.scale(s, s);
    const Wd = newWorld(id, 7, 2); Wd.t = { holes: 14, island: 4, drift: 7, mag: 3, tide: 10, windmill: 2 }[A.id] || 0;
    drawArena(g, Wd, (x) => x, (y) => y, 1, 0, true);
  });
  const itemIcon = (k) => codexIcon((g) => itemDisc(g, k, 18, 18, 16));
  const SHAPE_NM = { c: '원형', r: '사각', p: '떠다니는 판', x: '십자 다리' };
  function rulesBy(sec, names, sep) {
    const txt = ((sec && sec.p) || []).join(' '), at = [];
    names.forEach((n, i) => { const k = txt.indexOf(n + sep); if (k >= 0) at.push([k, i, n]); });
    at.sort((a, b) => a[0] - b[0]);
    const out = {};
    at.forEach(([k, i, n], j) => { out[i] = txt.slice(k + n.length, j + 1 < at.length ? at[j + 1][0] : txt.length).replace(/^\([^)]*\)/, '').replace(/^:\s*/, '').trim(); });
    return out;
  }
  function codex(el) {
    const def = L.games.sumo || {}, rs = def.rules || [], rsec = (h) => rs.find((s) => s.h === h) || rs.find((s) => s.h.indexOf(h) === 0);
    const ar = rulesBy(rsec('경기장'), ARENAS.map((A) => A.name), ':');
    const it = rulesBy(rsec('아이템'), ITEM_KEYS.map((k) => ITEMS[k].nm), '(');
    const secs = [
      { h: '경기장', p: ['경기장 ' + ARENAS.length + '곳. 기본은 무작위예요(옵션에 따라 1분마다 바뀌어요).'], rows: () => ARENAS.map((A, i) => ({
        ic: () => arenaIcon(i), name: (i + 1) + '. ' + A.name, tag: SHAPE_NM[A.shape] + (A.fr < 1 ? ' · 미끄러움' : ''), desc: [A.sub] })) },
      { h: '아이템', p: ['약 ' + ITEM_EVERY + '초마다 경기장에 하나씩 나와요. 동그란 패 위로 지나가면 바로 효과가 나요.'], rows: () => ITEM_KEYS.map((k) => ({
        ic: () => itemIcon(k), name: ITEMS[k].nm, tag: ITEMS[k].T > 0 && !VICTIM[k] && !'tpx'.includes(k) ? Math.round(ITEMS[k].T) + '초' : '',
        desc: [it[ITEM_KEYS.indexOf(k)] || ITEMS[k].d].concat(VICTIM[k] ? ['맞으면: ' + VICTIM[k]] : []) })) },
      { h: '기믹', p: ['경기장마다 다른 기믹. 깜빡임·화살표가 곧 일어날 일을 미리 알려 줘요.'], rows: () => ARENAS.map((A, i) => ({
        ic: () => arenaIcon(i), name: A.name, tag: '', desc: [ar[i] || A.sub] })) },
    ];
    const tabs = L.h('div', { class: 'chips' }), pane = L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    const show = (k) => {
      pane.innerHTML = '';
      [...tabs.children].forEach((b, i) => b.classList.toggle('on', i === k));
      const sec = secs[k];
      (sec.p || []).forEach((t) => pane.append(L.h('p', { class: 'note', style: { margin: 0 }, text: t })));
      sec.rows().forEach((r) => {
        const ic = L.h('span', { class: 'cx-ic', style: { background: 'transparent' } }, r.ic());
        pane.append(L.h('div', { class: 'cx-row' }, ic, L.h('div', { class: 'cx-tx' },
          L.h('div', { class: 'cx-nm' }, L.h('b', { text: r.name }), r.tag ? L.h('span', { class: 'cx-tag', text: r.tag }) : null),
          ...r.desc.map((t) => L.h('div', { class: 'cx-d', text: t })))));
      });
    };
    const N = { 경기장: ARENAS.length, 아이템: ITEM_KEYS.length, 기믹: ARENAS.length };
    secs.forEach((sec, k) => tabs.append(L.h('button', { class: 'btn sm', text: sec.h + ' ' + N[sec.h], onclick: () => show(k) })));
    el.append(tabs, pane);
    show(0);
  }

  L.register({
    id: 'sumo', name: '스모 범퍼카', tag: '실시간 밀어내기', cat: '아케이드',
    blurb: '범퍼카로 부딪혀 상대를 경기장 밖으로! 떨어져도 부활하고, 정해진 시간 안에 처치를 가장 많이 하면 승리. 경기장 40곳, 아이템 20종. 친구와는 온라인·LAN 방으로.',
    tint: '#6a2a3a',
    icon: '<circle cx="28" cy="30" r="22" fill="none" stroke="currentColor" stroke-width="3" stroke-dasharray="5 4"/><circle cx="20" cy="30" r="8" fill="currentColor"/><circle cx="37" cy="27" r="8" fill="none" stroke="currentColor" stroke-width="3"/><path d="M8 18l6 4M6 30h7M8 42l6-4" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'mode', label: '모드', tip: '혼자 싸울지, 팀으로 싸울지.', choices: [{ v: 0, label: '개인전', tip: '모두가 적.' }, { v: 2, label: '팀전 2:2', tip: '2명씩 두 팀(4명).' }, { v: 3, label: '팀전 3:3', tip: '3명씩 두 팀(6명).' }], def: 0 },
      { id: 'time', label: '경기 시간', choices: [{ v: 2, label: '2분' }, { v: 3, label: '3분' }, { v: 5, label: '5분' }], def: 3 },
      { id: 'goal', label: '목표 처치', tip: '이만큼 밀어내면 바로 승리.', choices: [{ v: 5, label: '5' }, { v: 10, label: '10' }, { v: 15, label: '15' }], def: 10 },
      { id: 'sw', label: '무작위 경기장', tip: '정한 시간마다 경기장 모양이 바뀌어요.', choices: [{ v: 60, label: '1분마다 바뀜' }, { v: 90, label: '1분 30초마다' }, { v: 0, label: '안 바뀜' }], def: 60 },
      { id: 'items', label: '아이템', choices: [{ v: 1, label: '켜기' }, { v: 0, label: '끄기' }], def: 1 },
    ],
    controls: [
      { id: 'up', label: '위', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'dash', label: '돌진', keys: ['Space', 'ShiftLeft'], pad: ['a', 'rb'] },
    ],
    quick: [
      '범퍼카로 부딪혀 다른 차를 경기장 밖(또는 구멍)으로 밀어내요.',
      '화면 왼쪽에 엄지를 대고 밀면 그쪽으로 달려요. 오른쪽 아무 데나 톡 = 돌진!',
      '상대를 떨어뜨리면 +1 처치. 떨어져도 2초쯤 뒤 부활해요. 목표 처치(기본 10)에 먼저 닿거나, 시간(기본 3분)이 끝났을 때 처치가 가장 많으면 우승!',
    ],
    rules: [
      { h: '목표', p: [
        '범퍼카로 부딪혀 다른 차를 경기장 밖(또는 구멍)으로 밀어내요. 떨어뜨리면 +1 처치!',
        '떨어진 차는 약 2.4초 뒤 안전한 자리에서 부활해요. 그러니 끝까지 계속 싸워요.',
        '시작 전에 경기장을 골라요(혼자 할 때는 내가, 온라인은 호스트). 기본은 무작위예요.',
      ] },
      { h: '팀전', p: [
        '옵션 「모드」에서 팀전 2:2·3:3을 고르면 빨강 팀과 파랑 팀으로 나뉘어요. 사람이 모자란 자리는 AI 차(보통)가 채워요. 인원이 많으면 3:3으로 늘어나요.',
        '차 색이 팀 색이에요(빨강 계열·파랑 계열). 왼쪽 위에 두 팀의 처치 합이 보여요.',
        '아군끼리 부딪히면 살짝만 밀려요. 아군이 밀어 떨어져도 처치가 아니에요(그 전 3초 안에 적이 건드렸으면 그 적의 처치).',
        '승리: 팀 처치 합이 목표에 먼저 닿거나, 시간이 끝났을 때 합이 많은 팀이 우승. 같으면 낙하 합이 적은 팀, 그것도 같으면 연장전.',
        'AI는 아군을 노리지 않고, 아군이 붙어 있는 적을 함께 몰아붙여요.',
      ] },
      { h: '조작 (터치)', p: [
        '조이스틱(기본): 화면 왼쪽 아무 데나 엄지를 대면 그 자리에 조이스틱이 생겨요. 미는 방향으로 차가 달려요. 많이 밀수록 세게.',
        '좌우 회전: 차가 저절로 앞으로 가고, 왼쪽 아래 ◀ ▶ 버튼으로 돌아요.',
        '돌진: 화면 오른쪽 아무 데나 톡. 조이스틱 방향(없으면 차가 보는 방향)으로 튀어 나가고, 돌진 중에는 더 묵직하게 부딪혀요. 다시 쓰려면 약 2.2초.',
        '조작 방식은 경기장 고르기 화면이나 왼쪽 위 「조작」 칩에서 바꿔요. 이 폰에 기억돼요.',
        'PC 키보드·게임패드: 방향키·WASD·왼스틱으로 이동(좌우 회전 방식에서는 ←→로 회전), 스페이스·Shift·Ⓐ·RB 돌진. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '처치 · 승리', p: [
        '처치: 내가 마지막으로 부딪힌(또는 아이템을 맞힌) 차가 3초 안에 떨어지면 내 처치 +1이에요. 기믹에 밀려 떨어져도, 그 전에 내가 건드렸으면 내 처치!',
        '혼자 떨어지면(3초 안에 아무도 안 건드림) 처치는 아무에게도 안 가요. 벌점은 없지만 「낙하」 수에 세요.',
        '승리: 목표 처치(5·10·15, 기본 10)에 먼저 닿으면 바로 우승. 시간(2·3·5분, 기본 3분)이 끝나면 처치가 가장 많은 사람이 우승이에요.',
        '처치 수가 같으면 낙하가 적은 사람이 이겨요. 그것까지 같으면 「연장전」: 다음 처치로 결판, 45초 안에 안 나면 공동 우승.',
        '부활 보호막: 부활 직후 2초 동안 하얀 막이 깜빡여요. 그동안은 밀리지 않고(상대는 밀 수 있어요) 아이템도 안 맞아요.',
        '왼쪽 위에 경기장과 각자의 처치 수, 오른쪽 위에 남은 시간과 목표가 보여요. 처치 소식은 오른쪽 위에 짧게 떠요.',
        '예시: 목표 10처치·3분 경기에서 2분 만에 내가 10처치 → 바로 우승! 3분이 다 됐는데 나 7, 친구 7, 낙하는 내가 2번·친구 4번 → 내가 우승.',
      ] },
      { h: '경기장 바뀜', p: [
        '무작위 경기장이면 1분마다(옵션: 1분 30초, 안 바뀜) 다른 경기장으로 바뀌어요. 바뀔 때 3초 카운트다운 동안 시계가 멈추고, 처치 수는 그대로예요.',
        '경기장을 하나 고르면 그 경기장에서 끝까지 해요.',
        '줄어드는 섬·구멍 바닥처럼 땅이 줄어드는 기믹은 잠시 뒤 다시 원래대로 돌아와요.',
      ] },
      { h: '물리', p: [
        '부딪히면 서로 튕겨요. 빠를수록, 무거울수록 상대가 더 멀리 날아가요.',
        '바닥마다 미끄러운 정도가 달라요(얼음은 아주 미끄러워요).',
        '아이템(켜기): 약 8초마다 경기장에 하나씩 나타나요. 그림이 그려진 동그란 패 위로 지나가면 바로 효과가 나요(버튼 없음). 먹으면 화면 위에 무슨 효과인지 한 줄로 알려 주고, 내 차에 걸린 효과는 돌진 버튼 위에 아이콘·남은 초로 보여요.',
      ] },
      { h: '아이템 20종 (그림 → 효과)', p: [
        '부활 보호막 중인 차와 유령 상태의 차는 상대 아이템에 안 걸려요.',
        '무거워짐(케틀벨): 7초 동안 2배 넘게 무거워지지만 조금 느려요. 방패(방패): 약 5초 동안 거의 밀리지 않아요.',
        '충격파(동심원): 먹는 순간 내 주변(가까울수록 세게) 차들을 바깥으로 튕겨내요.',
        '갈고리(갈고리): 가장 가까운 차를 내 쪽으로 확 끌어당겨요.',
        '기름(물방울): 가장 가까운 차 발밑에 7초 동안 기름 웅덩이가 생겨요. 웅덩이 위에서는 누구든 얼음처럼 미끄러워요.',
        '거대화(바깥 화살표 넷): 6초 동안 차가 커지고 2배 무거워져요.',
        '순간 이동(점선 점프): 9초 안에 누르는 다음 돌진이 순간 이동으로 바뀌어요. 그 방향으로 차 몇 대만큼 휙 옮겨가요(돌진 버튼에 「순간」). 밖으로 이동하면 떨어져요!',
        '역방향(반대 화살표): 가장 가까운 차의 조작이 4초 동안 반대로 돼요.',
        '끈끈이(흘러내리는 방울): 내 주변(없으면 가장 가까운) 차들이 3.5초 동안 끈적해져 느려지고 돌진도 약해져요.',
        '반사 갑옷(육각형): 6초 동안 부딪혀 오는 힘을 거의 안 받고, 오히려 상대를 더 세게 튕겨 보내요.',
        '자석(말굽자석): 4.5초 동안 내 주변 차들을 내 쪽으로 끌어당겨요. 가장자리 근처에서는 나도 조심!',
        '스프링(용수철): 9초 안에 누르는 다음 돌진이 높이 뛰기로 바뀌어요(돌진 버튼에 「점프」). 차 다섯 대쯤 거리를 날아 차·구멍·틈을 넘어가요. 내려앉은 곳이 밖이면 떨어져요.',
        '축소 광선(안쪽 화살표 넷): 가장 가까운 차가 5초 동안 작고 가벼워져 잘 밀려요(거대화도 풀려요).',
        '회오리(소용돌이): 내 앞에 회오리가 생겨 5초 동안 가장 가까운 다른 차를 쫓아가 휘감아 날려요. 나는 안 맞아요.',
        '폭탄(폭탄): 내 바로 뒤에 폭탄을 떨궈요. 약 1.6초 뒤 터져 주황 점선 안의 차를 모두(나도!) 날려요.',
        '꽁꽁(눈송이): 가장 가까운 차가 2초 동안 얼음 덩어리가 돼요. 움직이지도 돌진하지도 못하고 미끄러져요.',
        '터보(겹화살표): 5초 동안 더 빨리 달리고 돌진이 2배 넘게 빨리 다시 차요.',
        '유령(유령): 4초 동안 다른 차와 부딪히지 않고 뚫고 지나가요. 상대 아이템에도 안 걸려요. 대신 나도 못 밀어요.',
        '대포알(날아가는 공): 내 앞쪽(좌우 70도 안)의 가장 가까운 차에게 대포알을 쏴서 세게 밀어내요. 앞에 아무도 없으면 똑바로 날아가요.',
        '투명(줄 그은 눈): 5초 동안 다른 사람 화면에서 거의 안 보이고 이름표도 사라져요. 쉬움·보통 AI는 나를 못 찾아요.',
      ] },
      { h: '경기장', p: [
        '시작 전에 경기장을 골라요(혼자 할 때는 내가, 온라인은 호스트). 하나를 고르면 모든 라운드를 거기서, 무작위면 라운드마다 다른 경기장이 나오고 카운트다운에서 공개돼요.',
        '원형 도장: 기본 원형 링. 얼음 링: 아주 미끄러워 멈추기 어려워요.',
        '줄어드는 섬: 모래섬이 26초 동안 점점 작아졌다가 잠시 뒤 다시 넓어져요. 회전 원판: 바닥이 돌아서 차가 휩쓸려 가요.',
        '구멍 바닥: 칸이 빨갛게 깜빡이다가 약 1.6초 뒤 뚫려요. 가운데 칸은 남아요. 다 뚫리고 몇 초 뒤 모든 칸이 다시 돌아와요.',
        '범퍼 기둥: 분홍 기둥에 닿으면 세게 튕겨 나가요. 컨베이어 벨트: 띠마다 좌우 반대 방향으로 흘러가요.',
        '바람 부는 절벽: 빨간 화살표가 깜빡이면 곧 그 방향으로 3초쯤 옆바람이 불어요. 위아래 끝도 절벽이에요.',
        '시소 판: 차들이 몰린 쪽으로 판이 기울고, 기운 쪽으로 미끄러져요. 가운데 언덕: 언덕 비탈에서는 바깥쪽으로 밀려나요.',
        '용암 분출구: 구멍 다섯 개가 번갈아 빨갛게 달아오르고(약 1초) 터지면서 주변 차를 날려 보내요.',
        '핀볼 테이블: 위아래 플리퍼가 번갈아 쳐올려 차를 날리고, 분홍 범퍼는 세게 튕겨요.',
        '자석 바닥: 자석 판 셋 중 하나씩 차례로 켜져(깜빡임이 예고) 근처 차를 끌어당겨요.',
        '트램펄린: 노란 판을 밟으면 달리던 방향으로 튀어 올라 잠깐 날아가요. 공중에서는 부딪히지 않고, 내려앉은 곳이 밖이면 떨어져요.',
        '떠다니는 판: 네 장의 판이 붙었다가 천천히 벌어져요. 벌어진 틈은 낭떠러지예요. 판 위의 차는 판을 따라 움직여요.',
        '블랙홀: 가운데 구멍이 소용돌이치며 차를 빨아들여요. 구멍에 빠지면 탈락.',
        '해파리 바다: 해파리 넷이 떠다니고, 닿으면 통 튕겨 나가요.',
        '거대 팽이: 가운데 팽이가 천천히 돌아다니며 닿은 차를 옆으로 세게 쳐내요.',
        '레이저 벽: 가운데를 지나는 레이저가 돌면서 켜졌다 꺼졌다 해요(점선이 켜지기 직전 예고). 켜진 레이저는 벽처럼 차를 쓸어내요.',
        '꺼지는 조명: 조명이 깜빡이다가 3초쯤 꺼져요. 그동안 차의 전조등 주변만 보이고, 다른 차 이름도 안 보여요.',
        '회전 울타리: 가장자리가 분홍 고무 울타리라 튕겨 나와요. 울타리의 뚫린 틈 두 곳이 빙글빙글 돌아요. 틈으로만 떨어져요.',
        '도는 비탈: 바닥이 화살표 쪽으로 기울어 그쪽으로 미끄러져요. 기우는 방향이 천천히 돌아요.',
        '포탈 광장: 같은 색 포탈 두 개가 짝이에요. 들어가면 짝 포탈에서 달리던 방향 그대로 튀어나와요. 포탈도 천천히 돌아요.',
        '가속 발판: 노란 발판을 밟으면 화살표 쪽으로 휙 쏘아져요. 7초마다 화살표가 90도씩 돌아요(빨갛게 깜빡이면 곧 바뀜).',
        '굴러오는 통나무: 위나 아래 끝에 빨간 화살표가 깜빡이면 곧 그 자리로 통나무가 굴러와 차를 밀고 가요.',
        '갈라지는 땅: 빨간 점선 사이가 곧 갈라져 구멍이 돼요. 몇 초 뒤 다시 붙고, 다음엔 다른 방향으로 갈라져요.',
        '밀려오는 파도: 한쪽 끝에 거품과 화살표가 보이면 곧 파도가 바닥을 쓸고 지나가며 차를 그쪽으로 밀어요.',
        '고무벽 복도: 양옆은 세게 튕기는 고무벽이라 안 떨어져요. 위아래 끝이 낭떠러지예요.',
        '함정문 바닥: 노랑·검정 줄무늬 문 12개가 차례로 빨갛게 깜빡이고(약 1.4초) 열렸다가, 2.6초 뒤 다시 닫혀요.',
        '피스톤 벽: 양옆 벽에 피스톤이 셋씩 있어요. 벽 칸이 빨갛게 깜빡이면 곧 피스톤이 쭉 튀어나와 앞의 차를 반대편으로 밀쳐요.',
        '용암 밀물: 약 13초마다 용암이 밀려와 땅이 좁아져요. 빨간 점선이 깜빡이면 곧 그 선까지 잠겨요. 잠깐 뒤 다시 빠져요.',
        '선풍기 구역: 가장자리 선풍기 셋 중 하나씩 돌아요. 빨간 점선 길이 깜빡이면 곧 그 길로 3초쯤 센 바람이 불어 반대편으로 밀려요.',
        '기우는 원반: 차들이 몰린 쪽(무거운 쪽)으로 원반이 사방 어디로든 기울어요. 빨간 화살표가 기우는 쪽이에요.',
        '풍차 날개: 가운데 날개 셋이 왔다 갔다 하며 돌아요. 날개에 맞으면 쓸려 가요. 바깥 테두리는 날개가 안 닿아요.',
        '도넛 회전판: 안쪽 노란 고리는 한쪽으로, 바깥 분홍 고리는 반대로 돌아요. 가운데 구멍에 빠져도 탈락이에요.',
        '솟는 기둥: 빛나는 자리(약 1초 예고)에서 기둥이 솟아 위에 있던 차를 튕겨내고, 3초쯤 벽처럼 서 있다가 내려가요.',
        '눈보라 빙판: 미끄러운 빙판이에요. 빨간 화살표가 뜨면 곧 그 방향으로 2초쯤 돌풍이 불어요.',
        '흔들 다리: 가운데 광장과 좁은 다리 넷. 빨간 화살표가 깜빡이면 곧 다리가 그 방향으로 크게 흔들려 모든 차가 휙 밀려요.',
        '폭탄 비: 빨간 과녁이 생기고 약 2.4초 뒤 폭탄이 떨어져 과녁 안의 차를 날려요. 과녁 테두리가 다 차면 펑!',
        '철구 진자: 가운데 크레인에 매달린 쇠공이 그네처럼 오가요. 흔들리는 방향도 천천히 돌아요. 맞으면 세게 날아가요.',
      ] },
      { h: '팁', p: [
        '가장자리에서는 함부로 돌진하지 마세요. 상대가 피하면 내가 밖으로 날아가요.',
        '상대를 가장 가까운 가장자리 쪽으로 밀어요. 가운데로 밀면 다시 버텨요.',
        '상대가 돌진을 쓴 직후(약 2.2초 동안 다시 못 써요)가 반격할 기회예요.',
        '방패·반사 갑옷이 켜진 차와는 정면으로 부딪히지 마세요.',
        '부활 직후 보호막(2초) 동안은 안 밀려요. 바로 옆 차에게 돌진하면 공짜 처치 기회!',
        '혼자 떨어져도 벌점은 없지만, 동점이면 낙하가 적은 쪽이 이겨요.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 운전해요. 혼자 하면 나머지 자리는 AI 차예요.',
        '친구와는 온라인·LAN 방으로: 각자 폰으로 한 대씩. 차와 충돌은 호스트 폰이 계산해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 자주 실수하고 경기장 기믹도 잘 못 피하며, 부활 보호막 중인 차에게도 헛심을 써요. 보통·어려움은 보호막 중엔 과감히 밀고 들어와요. 어려움은 가장자리 근처의 차와 1등을 노리고, 멀리 있는 상대 대신 가운데를 지켜요. 보통은 예고를 보고 피하고, 어려움은 돌진·폭탄·피스톤을 미리 피하고, 흔들림·돌풍 예고 때는 가장자리에서 물러나요. 아이템은 보통이 가까운 것만, 어려움은 멀리서도 챙기고 순간 이동·스프링으로 위기를 넘겨요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount, codex,
    _t: { AIC, ally, teamRank, init, addKill, timeUp, finish, nextStage, leadOf, rankOf, portalsOf, logsOf, riftOf, waveOf, fenceGaps, inGap, respawn, ARENAS, ITEMS, FX, drawIcon, itemDisc, pistons, tideU, fanState, armsOf, popState, gustAt, quakeOf, bombsOf, wreckOf, applyItem, ventState, magState, platD, jellies, topOf, laserOf, flippers, darkOf, hazards, PADS, VENTS, MAGS, rad, massOf, flagsOf, BLINK, newWorld, stepWorld, stepCar, collide, edgeDist, surface, aiThink, maybeItem, startMatch, holeState, windAt, curR, sudden, H, CR, FALL_T, RESPAWN_T, INV_T },
  });
})();
