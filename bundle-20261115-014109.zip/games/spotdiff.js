/* 다른 그림 찾기 대결 — everyone searches the same pair of pictures at the same time (a race).
   Pictures are procedural scenes drawn on canvas from a seed (34 places, ~180 drawable things). Each round has 5–7
   differences: removed / extra thing, colour, size, changed detail; from round 2 also mirrored, moved, tilted, pattern,
   count, text/number. Later rounds: more things, smaller changes, trickier kinds (difficulty dv = k − 5). Tap a difference on either picture →
   circled on both in your colour. Wrong taps lock you for a moment (anti-spam). Limited hints. 3 or 5 rounds.
   Realtime (one person per phone): the host's view runs the round clock and the AI searchers and publishes the state;
   a phone judges its own taps locally (same seed → same scene) and sends {t:'hit', i}; the host's apply decides who
   was first. Solo = endless stages (more differences, subtler kinds; best stage via api.best) or star time attack. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= constants ======================= */
  const W = 1000, H = 660, TAU = Math.PI * 2;
  const OL = '#2b2233';
  const COUNT_MS = 3200, END_MS = 5600, HINTS = 3, HINT_AFTER = 8000, HINT_SOLO_PEN = 10;
  const PAL = ['#e5484d', '#f28a2e', '#f6cd3b', '#4caf50', '#22b3a6', '#3d7ee6', '#8f5bd8', '#f483b6', '#9b6332', '#f6f2ea', '#8f909c', '#3b3542'];
  const NEAR = { 0: [1, 7, 8], 1: [0, 2, 8], 2: [1, 9], 3: [4], 4: [3, 5], 5: [4, 6], 6: [5, 7, 11], 7: [6, 0], 8: [1, 0, 11], 9: [2, 10], 10: [9, 11], 11: [10, 8, 6] };
  const KH = { col: 0.85, rm: 0.9, ex: 0.95, sz: 1.15, pat: 1.05, cnt: 1.25, var: 1.25, rot: 1.15, mv: 1.3, mir: 1.3, txt: 1.35 };
  const MINRR = 30;

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const ri = (R, n) => Math.floor(R() * n);
  const pick = (R, a) => a[ri(R, a.length)];
  function shuf(R, a) { for (let i = a.length - 1; i > 0; i--) { const j = ri(R, i + 1); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ======================= drawing helpers (X = current ctx) ======================= */
  let X = null, LWv = 3.2;
  const LWB = 3.2;
  function ink() { X.lineWidth = LWv; X.strokeStyle = OL; X.lineJoin = 'round'; X.lineCap = 'round'; X.stroke(); }
  function F(col) { X.fillStyle = col; X.fill(); ink(); }
  function Fn(col) { X.fillStyle = col; X.fill(); }
  function C(x, y, r, col, no) { X.beginPath(); X.arc(x, y, r, 0, TAU); if (no) Fn(col); else F(col); }
  function E(x, y, rx, ry, col, rot, no) { X.beginPath(); X.ellipse(x, y, rx, ry, rot || 0, 0, TAU); if (no) Fn(col); else F(col); }
  function rrp(x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); X.moveTo(x + r, y); X.arcTo(x + w, y, x + w, y + h, r); X.arcTo(x + w, y + h, x, y + h, r); X.arcTo(x, y + h, x, y, r); X.arcTo(x, y, x + w, y, r); X.closePath(); }
  function RR(x, y, w, h, r, col, no) { X.beginPath(); rrp(x, y, w, h, r); if (no) Fn(col); else F(col); }
  function P(a, col, no) { X.beginPath(); X.moveTo(a[0], a[1]); for (let i = 2; i < a.length; i += 2) X.lineTo(a[i], a[i + 1]); X.closePath(); if (no) Fn(col); else F(col); }
  function S(a, w, col) { X.beginPath(); X.moveTo(a[0], a[1]); for (let i = 2; i < a.length; i += 2) X.lineTo(a[i], a[i + 1]); X.lineWidth = w; X.strokeStyle = col; X.lineCap = 'round'; X.lineJoin = 'round'; X.stroke(); }
  function SO(a, w, col) { S(a, w + LWv * 2, OL); S(a, w, col); }
  function Qd(x0, y0, cx, cy, x1, y1, w, col, out) {
    X.lineCap = 'round';
    if (out) { X.beginPath(); X.moveTo(x0, y0); X.quadraticCurveTo(cx, cy, x1, y1); X.lineWidth = w + LWv * 2; X.strokeStyle = OL; X.stroke(); }
    X.beginPath(); X.moveTo(x0, y0); X.quadraticCurveTo(cx, cy, x1, y1); X.lineWidth = w; X.strokeStyle = col; X.stroke();
  }
  function blob(list, col) { // union of circles [x,y,r,...] with one outline
    X.lineWidth = LWv * 2; X.strokeStyle = OL;
    for (let i = 0; i < list.length; i += 3) { X.beginPath(); X.arc(list[i], list[i + 1], list[i + 2], 0, TAU); X.stroke(); }
    X.fillStyle = col;
    for (let i = 0; i < list.length; i += 3) { X.beginPath(); X.arc(list[i], list[i + 1], list[i + 2], 0, TAU); X.fill(); }
  }
  function starP(x, y, n, ro, rin, col, rot) {
    const a = [];
    for (let i = 0; i < n * 2; i++) { const ang = (rot == null ? -Math.PI / 2 : rot) + i * Math.PI / n, r = i % 2 ? rin : ro; a.push(x + Math.cos(ang) * r, y + Math.sin(ang) * r); }
    P(a, col);
  }
  const shC = {};
  function sh(hex, f) {
    const key = hex + f; if (shC[key]) return shC[key];
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return (shC[key] = 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')');
  }
  function eye(x, y, r, light) { C(x, y, r, light ? '#ffe27a' : OL, true); C(x + r * 0.35, y - r * 0.35, r * 0.35, '#fff', true); }
  function glow(x, y, r, col) { const g = X.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(255,230,140,0)'); X.fillStyle = g; X.beginPath(); X.arc(x, y, r, 0, TAU); X.fill(); }
  function clipDo(pathFn, fn) { X.save(); X.beginPath(); pathFn(); X.clip(); fn(); X.restore(); }
  const KFONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  function TX(s, x, y, sz, col, mono) { X.fillStyle = col; X.font = '700 ' + sz + 'px ' + (mono ? '"IBM Plex Mono",ui-monospace,Menlo,monospace' : KFONT); X.textAlign = 'center'; X.textBaseline = 'middle'; X.fillText(s, x, y); }
  function RG(x, y, r, w, col, a0, a1) { X.beginPath(); X.arc(x, y, r, a0 || 0, a1 == null ? TAU : a1); X.lineCap = 'round'; X.lineWidth = w + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = w; X.strokeStyle = col; X.stroke(); }
  function lum(hex) { if (!hex || hex[0] !== '#') return 0.5; const n = parseInt(hex.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; }
  // pattern inside a path: 0 none, 1 diagonal stripes, 2 dots, 3 flat stripes
  function patt(path, p, k) {
    if (!p) return;
    const c = lum(k) > 0.62 ? 'rgba(43,34,51,.42)' : 'rgba(255,255,255,.82)';
    clipDo(path, () => {
      X.fillStyle = c;
      if (p === 1) { X.save(); X.rotate(-0.6); for (let x = -130; x < 130; x += 20) X.fillRect(x, -130, 9, 260); X.restore(); }
      else if (p === 2) { for (let j = 0, y = -108; y < 110; y += 18, j++) for (let x = -108 + (j % 2) * 9; x < 110; x += 18) { X.beginPath(); X.arc(x, y, 4.4, 0, TAU); X.fill(); } }
      else { for (let y = -112; y < 112; y += 22) X.fillRect(-130, y, 260, 9); }
    });
  }
  function pfill(path, k, p) { X.beginPath(); path(); Fn(k); patt(path, p, k); X.beginPath(); path(); ink(); }

  /* ======================= drawable things ======================= */
  // r = bounding radius (local units, origin = centre), ft = how far the base sits below the centre,
  // col = palette indices it may take (null = fixed colours), vn = number of detail variants, asym = mirror diff allowed.
  const TY = {};
  function def(name, r, o, draw) { TY[name] = Object.assign({ r, ft: r * 0.85, col: null, vn: 1, asym: false, draw }, o); }
  const GREEN = '#4caf50', DGREEN = '#3b8a3a', WOOD = '#9b6332', WOOD2 = '#c58a4a', WHITE = '#f6f2ea', GOLD = '#f6cd3b';

  def('flower', 36, { ft: 32, col: [0, 1, 2, 5, 6, 7, 9], vn: 2 }, (k, v) => {
    S([0, -6, 0, 32], 4.5, DGREEN); E(9, 20, 9, 4.5, GREEN, -0.6);
    const n = v ? 8 : 5, pr = v ? 6.5 : 8.5, d = v ? 12.5 : 11;
    for (let i = 0; i < n; i++) { const a = i / n * TAU - Math.PI / 2; C(Math.cos(a) * d, -12 + Math.sin(a) * d, pr, k); }
    C(0, -12, 6.5, k === PAL[2] ? '#8a5a2b' : GOLD);
  });
  def('tree', 95, { ft: 90, col: [3, 1, 2], vn: 2 }, (k, v) => {
    RR(-11, 10, 22, 80, 4, '#8a5a32');
    blob([0, -32, 48, -32, -4, 32, 32, -4, 32, 0, -58, 30], k);
    E(-14, -46, 14, 9, sh(k, 0.25), -0.5, true);
    if (v) { const pts = [-24, -18, 10, -40, 26, -10, -6, -2, 4, -66, -36, -40]; for (let i = 0; i < pts.length; i += 2) C(pts[i], pts[i + 1], 6, PAL[0]); }
  });
  def('pine', 95, { ft: 88, col: [3, 4], vn: 2 }, (k, v) => {
    RR(-9, 60, 18, 28, 3, '#7a4f2c');
    P([0, -25, 68, 64, -68, 64], sh(k, -0.12)); P([0, -60, 56, 14, -56, 14], k); P([0, -90, 42, -26, -42, -26], sh(k, 0.1));
    if (v) { const pts = [-30, 50, 24, 40, -14, 4, 20, -4, 0, -42, 40, 58]; const cs = [PAL[0], GOLD, PAL[5], PAL[0], GOLD, PAL[7]]; for (let i = 0; i < pts.length; i += 2) C(pts[i], pts[i + 1], 6, cs[i / 2]); }
  });
  def('cloud', 62, { vn: 2 }, (k, v) => {
    const l = [-30, 10, 24, 0, -4, 32, 32, 10, 24, -46, 18, 16, 46, 18, 16];
    if (v) l.push(20, -22, 20);
    blob(l, '#fbfcff'); E(-8, -14, 14, 7, '#fff', -0.3, true);
  });
  def('sun', 58, { vn: 2 }, (k, v) => {
    for (let i = 0; i < 10; i++) { const a = i / 10 * TAU; const c = Math.cos(a), s = Math.sin(a); P([c * 54, s * 54, c * 38 - s * 9, s * 38 + c * 9, c * 38 + s * 9, s * 38 - c * 9], '#f5a524'); }
    C(0, 0, 33, GOLD);
    if (v) { eye(-11, -6, 4); eye(11, -6, 4); X.beginPath(); X.arc(0, 4, 13, 0.3, Math.PI - 0.3); ink(); }
  });
  def('bird', 32, { col: [0, 2, 5, 6, 7, 1], asym: true, ft: 22 }, (k) => {
    P([-18, 2, -32, -8, -30, 12], sh(k, -0.15)); E(-2, 4, 20, 13, k); E(-6, 3, 11, 7, sh(k, -0.2), -0.3);
    C(14, -8, 10, k); eye(17, -10, 2.6); P([23, -10, 33, -6, 23, -2], '#f5a524');
  });
  def('star', 36, { col: [2, 9, 7, 1, 4], vn: 2, rt: 1 }, (k, v) => { starP(0, 0, v ? 6 : 5, 33, v ? 17 : 14, k); C(-6, -6, 4, '#fff', true); });
  def('balloon', 48, { ft: 46, col: [0, 1, 2, 3, 5, 6, 7], vn: 2, rt: 1 }, (k, v) => {
    Qd(0, 22, -8, 34, 2, 46, 2, '#6d6474');
    E(0, -12, 26, 32, k);
    if (v) clipDo(() => X.ellipse(0, -12, 26, 32, 0, 0, TAU), () => { X.fillStyle = 'rgba(255,255,255,.8)'; X.fillRect(-30, -10, 60, 11); });
    P([-5, 22, 5, 22, 0, 16], sh(k, -0.2)); E(-9, -26, 6, 10, 'rgba(255,255,255,.55)', 0.4, true);
  });
  def('gift', 40, { ft: 31, col: [0, 3, 5, 6, 7, 1], vn: 2 }, (k, v) => {
    const rb = k === PAL[2] ? WHITE : GOLD;
    RR(-28, -12, 56, 43, 4, k); RR(-31, -22, 62, 13, 3, sh(k, 0.15)); RR(-6, -22, 12, 53, 0, rb);
    if (!v) { E(-11, -29, 11, 7, rb, -0.4); E(11, -29, 11, 7, rb, 0.4); C(0, -27, 4.5, rb); }
    else { RR(9, -2, 15, 11, 2, WHITE); }
  });
  def('mug', 34, { ft: 22, col: [0, 5, 3, 9, 2, 7], vn: 2, asym: true }, (k, v) => {
    X.beginPath(); X.arc(21, 2, 10, -1.4, 1.4); X.lineWidth = 7 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 7; X.strokeStyle = k; X.stroke();
    RR(-20, -17, 40, 39, 6, k); E(0, -17, 20, 5, sh(k, -0.3)); C(-4, 4, 6, 'rgba(255,255,255,.5)', true);
    if (v) { Qd(-8, -24, -14, -34, -6, -42, 3, '#d8d3e0'); Qd(6, -24, 0, -34, 8, -42, 3, '#d8d3e0'); }
  });
  def('books', 42, { ft: 26, col: [0, 5, 3, 6, 1], vn: 2 }, (k, v) => {
    const cs = [k, PAL[(PAL.indexOf(k) + 4) % 8], PAL[(PAL.indexOf(k) + 2) % 8]];
    const ys = v ? [12, -2, -16] : [12, -2];
    ys.forEach((y, i) => { const off = i % 2 ? 4 : -2; RR(-34 + off, y, 68, 14, 3, cs[i]); RR(26 + off, y + 3, 6, 8, 1, WHITE, true); });
  });
  def('clock', 42, { col: [8, 0, 5, 11, 3], vn: 5, tx: 1 }, (k, v) => {
    C(0, 0, 35, k); C(0, 0, 27, '#fbf7ee');
    for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; S([Math.cos(a) * 20, Math.sin(a) * 20, Math.cos(a) * 25, Math.sin(a) * 25], 3, OL); }
    const hd = [[13, 0, 0, -21], [-13, 0, 0, -21], [8, 10, 0, 21], [0, 13, 21, 0], [-10, -8, 0, 21]][v];
    S([0, 0, hd[0], hd[1]], 4.5, OL); S([0, 0, hd[2], hd[3]], 3, OL); C(0, 0, 3.5, PAL[0], true);
  });
  def('lamp', 64, { ft: 60, col: [2, 0, 5, 3, 7, 4], vn: 2 }, (k, v) => {
    if (v) glow(0, -30, 64, 'rgba(255,230,140,.55)');
    E(0, 57, 18, 5, '#3b3542'); S([0, -20, 0, 56], 4, '#3b3542');
    P([-20, -58, 20, -58, 32, -18, -32, -18], k);
    if (v) E(0, -17, 12, 4, '#fff6c8', 0, true);
  });
  def('plant', 48, { ft: 44, col: [8, 0, 5, 1, 9], vn: 2 }, (k, v) => {
    if (v) { E(-24, -2, 7, 18, GREEN, -1.1); E(24, -2, 7, 18, GREEN, 1.1); }
    E(-14, -14, 8, 22, GREEN, -0.5); E(14, -14, 8, 22, GREEN, 0.5); E(0, -22, 8, 26, '#3f9a45');
    P([-22, 10, 22, 10, 17, 44, -17, 44], k); RR(-25, 4, 50, 10, 3, sh(k, 0.15));
  });
  def('cat', 46, { ft: 40, col: [1, 10, 11, 9], vn: 2, asym: true }, (k, v) => {
    if (v) Qd(-20, 34, -36, 40, -46, 34, 7, k, true); else Qd(-20, 30, -44, 20, -34, -6, 7, k, true);
    E(-4, 16, 24, 26, k); E(-2, 22, 12, 16, sh(k, 0.3), 0, true);
    P([-2, -28, 0, -44, 10, -32], k); P([14, -32, 24, -44, 26, -26], k);
    C(10, -16, 18, k);
    const lt = k === PAL[11] || k === PAL[10];
    eye(4, -18, 2.8, lt); eye(17, -18, 2.8, lt); C(11, -10, 2.4, PAL[7], true);
    S([20, -10, 32, -12], 1.5, OL); S([20, -7, 32, -5], 1.5, OL);
  });
  def('ball', 30, { ft: 28, col: [0, 5, 2, 3, 1, 6], vn: 2 }, (k, v) => {
    C(0, 0, 28, k);
    clipDo(() => X.arc(0, 0, 28, 0, TAU), () => {
      if (!v) { X.fillStyle = WHITE; X.save(); X.rotate(-0.5); X.fillRect(-30, -6, 60, 12); X.restore(); }
      else { C(-10, -8, 6, WHITE, true); C(10, 6, 6, WHITE, true); C(-6, 14, 5, WHITE, true); C(12, -14, 4, WHITE, true); }
    });
    X.beginPath(); X.arc(0, 0, 28, 0, TAU); ink(); C(-10, -12, 5, 'rgba(255,255,255,.6)', true);
  });
  def('apple', 28, { ft: 22, col: [0, 3, 2], vn: 2 }, (k, v) => {
    S([0, -12, 3, -24], 3.5, '#6b4423'); blob([-8, 4, 18, 8, 4, 18], k); C(-9, -3, 5, 'rgba(255,255,255,.5)', true);
    if (!v) E(10, -20, 8, 4, GREEN, -0.5);
  });
  def('fish', 46, { col: [1, 2, 5, 0, 6, 4, 7], vn: 2, asym: true, ft: 22 }, (k, v) => {
    P([-26, 0, -44, -16, -44, 16], sh(k, -0.12)); P([-6, -16, 6, -29, 12, -16], sh(k, -0.18));
    E(0, 0, 30, 19, k);
    if (v) { E(-8, 0, 4, 16, 'rgba(255,255,255,.75)', 0, true); E(4, 0, 4, 17, 'rgba(255,255,255,.75)', 0, true); }
    C(17, -4, 5, '#fff'); C(18, -4, 2.4, OL, true); S([27, 5, 22, 7], 2, OL);
  });
  def('frame', 58, { col: [8, 2, 0, 11], vn: 3, rt: 1 }, (k, v) => {
    RR(-46, -36, 92, 72, 4, k);
    clipDo(() => rrp(-38, -28, 76, 56, 2), () => {
      X.fillStyle = v === 1 ? '#fde3ea' : '#cfe8f5'; X.fillRect(-40, -30, 80, 60);
      if (v === 0) { P([-40, 30, -12, -6, 6, 14, 18, 0, 40, 30], '#5aa36a'); C(22, -14, 7, GOLD); }
      else if (v === 1) { X.beginPath(); X.moveTo(0, 18); X.bezierCurveTo(-30, -2, -14, -24, 0, -10); X.bezierCurveTo(14, -24, 30, -2, 0, 18); F(PAL[0]); }
      else { RR(-4, 0, 8, 30, 2, '#8a5a32'); C(0, -6, 15, GREEN); X.fillStyle = '#9fd36a'; X.fillRect(-40, 22, 80, 10); }
    });
    X.beginPath(); rrp(-38, -28, 76, 56, 2); ink();
  });
  def('window', 92, { col: [0, 5, 3, 7, 2], vn: 2 }, (k, v) => {
    RR(-70, -60, 140, 120, 6, WHITE);
    clipDo(() => rrp(-60, -50, 120, 100, 2), () => {
      const g = X.createLinearGradient(0, -50, 0, 50); g.addColorStop(0, '#8fd0f5'); g.addColorStop(1, '#d6f0ff'); X.fillStyle = g; X.fillRect(-60, -50, 120, 100);
      if (v) blob([-16, 0, 14, 4, -8, 17, 22, 2, 12], '#fff'); else C(26, -22, 12, GOLD);
    });
    X.beginPath(); rrp(-60, -50, 120, 100, 2); ink();
    S([0, -50, 0, 50], 6, WHITE); S([-60, 0, 60, 0], 6, WHITE);
    P([-66, -58, -36, -58, -50, 20, -66, 56], k); P([66, -58, 36, -58, 50, 20, 66, 56], k);
    RR(-76, -66, 152, 10, 4, sh(k, -0.25));
  });
  def('cushion', 34, { ft: 26, col: [0, 1, 2, 3, 5, 6, 7], vn: 2 }, (k, v) => {
    RR(-27, -23, 54, 46, 15, k); RR(-20, -16, 40, 32, 10, sh(k, 0.18), true);
    if (v) { C(-10, -8, 4, WHITE, true); C(10, -8, 4, WHITE, true); C(-10, 8, 4, WHITE, true); C(10, 8, 4, WHITE, true); }
  });
  def('sofa', 185, { ft: 80, col: [0, 5, 3, 6, 8, 4] }, (k) => {
    RR(-150, 66, 12, 16, 3, '#3b3542'); RR(138, 66, 12, 16, 3, '#3b3542');
    RR(-160, -60, 320, 86, 26, k); RR(-140, -46, 130, 56, 18, sh(k, 0.12), true); RR(10, -46, 130, 56, 18, sh(k, 0.12), true);
    RR(-150, 4, 300, 64, 14, sh(k, 0.06));
    RR(-178, -20, 44, 90, 20, k); RR(134, -20, 44, 90, 20, k);
  });
  def('rug', 200, { ft: 0, col: [0, 5, 6, 4, 1] }, (k) => {
    E(0, 0, 192, 48, k); E(0, 0, 160, 36, sh(k, 0.22), 0, true); E(0, 0, 120, 24, k, 0, true);
  });
  def('tv', 72, { ft: 66, vn: 3 }, (k, v) => {
    S([-30, 34, -40, 66], 5, '#3b3542'); S([30, 34, 40, 66], 5, '#3b3542');
    RR(-62, -52, 124, 86, 8, '#3b3542');
    clipDo(() => rrp(-54, -44, 108, 70, 4), () => {
      if (v === 0) { X.fillStyle = '#5bc0eb'; X.fillRect(-56, -46, 112, 74); X.beginPath(); X.moveTo(-56, 6); for (let x = -56; x <= 56; x += 8) X.lineTo(x, 6 + Math.sin(x / 9) * 6); X.lineTo(56, 30); X.lineTo(-56, 30); X.fillStyle = '#2f7fd6'; X.fill(); }
      else if (v === 1) { X.fillStyle = '#7cc35f'; X.fillRect(-56, -46, 112, 74); C(4, 2, 12, WHITE); C(4, 2, 4, OL, true); }
      else { const cs = ['#f6f2ea', GOLD, '#22b3a6', '#4caf50', '#8f5bd8', '#e5484d']; cs.forEach((c, i) => { X.fillStyle = c; X.fillRect(-54 + i * 18, -44, 18, 70); }); }
    });
    X.beginPath(); rrp(-54, -44, 108, 70, 4); ink();
  });
  def('vase', 50, { ft: 46, col: [5, 0, 4, 9, 2], vn: 2 }, (k, v) => {
    const st = v ? [[-16, -28], [0, -38], [16, -28]] : [[-11, -32], [11, -32]];
    const fc = [PAL[0], GOLD, PAL[7]];
    st.forEach((p, i) => { S([0, 0, p[0], p[1]], 3, DGREEN); C(p[0], p[1], 8, fc[i]); C(p[0], p[1], 3, '#fff6c8', true); });
    E(0, 24, 20, 22, k); RR(-9, -2, 18, 10, 3, k); E(-6, 18, 4, 9, 'rgba(255,255,255,.4)', 0, true);
  });

  def('shelf', 120, { ft: 6 }, () => {
    P([-90, 6, -90, 30, -70, 6], '#8a5a32'); P([90, 6, 90, 30, 70, 6], '#8a5a32');
    RR(-112, -6, 224, 13, 3, WOOD2);
  });

  /* misc */
  def('crab', 42, { ft: 24, col: [0, 1, 6], vn: 2 }, (k, v) => {
    for (let i = 0; i < 3; i++) { SO([-14, 10 + i * 4, -30, 16 + i * 6], 3, k); SO([14, 10 + i * 4, 30, 16 + i * 6], 3, k); }
    if (!v) { SO([-18, 0, -28, -14], 5, k); SO([18, 0, 28, -14], 5, k); C(-30, -20, 10, k); C(30, -20, 10, k); S([-30, -30, -30, -20], 2.5, OL); S([30, -30, 30, -20], 2.5, OL); }
    else { SO([-20, 6, -32, 8], 5, k); SO([20, 6, 32, 8], 5, k); C(-36, 6, 10, k); C(36, 6, 10, k); S([-46, 6, -36, 6], 2.5, OL); S([46, 6, 36, 6], 2.5, OL); }
    E(0, 6, 26, 16, k); S([-6, -8, -8, -18], 3, OL); S([6, -8, 8, -18], 3, OL); C(-8, -19, 4, '#fff'); C(8, -19, 4, '#fff'); C(-8, -19, 1.8, OL, true); C(8, -19, 1.8, OL, true);
  });
  def('starfish', 36, { ft: 20, col: [1, 0, 2, 7, 6], vn: 2 }, (k, v) => {
    starP(0, 0, 5, 33, 14, k);
    if (v) for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * TAU / 5; C(Math.cos(a) * 18, Math.sin(a) * 18, 3.2, WHITE, true); }
    C(0, 0, 4, sh(k, 0.3), true);
  });
  def('shell', 30, { ft: 18, col: [7, 9, 1, 2], asym: true }, (k) => {
    P([-26, 14, 20, 14, 26, -2, 8, -20, -12, -12], k);
    X.beginPath(); X.arc(6, -2, 10, 0, 5); ink(); X.beginPath(); X.arc(6, -2, 4.5, 0, 5); ink();
    S([-20, 10, -6, -8], 2, OL); S([-10, 13, 0, -6], 2, OL);
  });
  def('rock', 52, { ft: 30, vn: 2 }, (k, v) => {
    P([-44, 28, -38, -4, -14, -26, 16, -24, 40, -2, 46, 28], '#8f909c'); P([-30, 26, -22, 4, 4, -6, 22, 10, 28, 26], '#a9aab5', true);
    if (v) P([20, 30, 26, 10, 42, 6, 50, 30], '#7c7d89');
  });

  /* camping */
  def('tent', 120, { ft: 70, col: [1, 0, 3, 5, 2], vn: 2 }, (k, v) => {
    P([-100, 70, 0, -92, 100, 70], k); P([0, -92, 100, 70, 60, 70], sh(k, -0.15));
    if (!v) { P([-30, 70, 0, -12, 30, 70], sh(k, -0.3)); S([0, -12, 0, 70], 2.5, OL); }
    else { P([-34, 70, 0, -16, 34, 70], '#2b2233'); P([-34, 70, 0, -16, -48, 70], sh(k, 0.15)); }
    S([0, -92, 0, -110], 4, OL);
  });
  def('fire', 42, { ft: 24, vn: 2 }, (k, v) => {
    RR(-30, 14, 60, 12, 6, '#8a5a32'); X.save(); X.rotate(0.35); RR(-30, 8, 60, 12, 6, '#7a4f2c'); X.restore();
    const fl = v ? [[-14, 16, 13, 32], [14, 16, 13, 32], [0, 16, 15, 44]] : [[-8, 16, 14, 34], [10, 16, 13, 28]];
    fl.forEach((f) => { P([f[0] - f[2], f[1], f[0], f[1] - f[3], f[0] + f[2], f[1]], '#f28a2e'); P([f[0] - f[2] * 0.5, f[1], f[0], f[1] - f[3] * 0.55, f[0] + f[2] * 0.5, f[1]], GOLD, true); });
  });
  def('mushroom', 32, { ft: 28, col: [0, 8, 1], vn: 2 }, (k, v) => {
    RR(-8, -2, 16, 30, 6, '#f3e6cf');
    X.beginPath(); X.arc(0, 2, 27, Math.PI, 0); X.closePath(); F(k);
    if (!v) { C(-12, -8, 4.5, WHITE, true); C(6, -16, 4, WHITE, true); C(13, -4, 3.5, WHITE, true); }
  });
  def('log', 52, { ft: 22, asym: true }, () => {
    RR(-48, -18, 90, 36, 18, WOOD); S([-30, -8, -6, -8], 2.5, '#6b4423'); S([-20, 6, 10, 6], 2.5, '#6b4423');
    E(42, 0, 10, 18, '#d7a86e'); X.beginPath(); X.ellipse(42, 0, 5, 10, 0, 0, TAU); X.lineWidth = 2; X.strokeStyle = '#8a5a32'; X.stroke();
  });
  def('backpack', 40, { ft: 36, col: [0, 5, 3, 1, 6], vn: 2 }, (k, v) => {
    X.beginPath(); X.arc(0, -32, 9, Math.PI, 0); X.lineWidth = 4 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 4; X.strokeStyle = sh(k, -0.25); X.stroke();
    RR(-24, -30, 48, 64, 14, k); RR(-24, -30, 48, 24, 12, sh(k, -0.15));
    if (v) RR(-14, 6, 28, 20, 6, sh(k, 0.18));
    RR(-4, -12, 8, 8, 2, GOLD);
  });
  def('lantern', 38, { ft: 34, col: [0, 3, 5, 11], vn: 2 }, (k, v) => {
    if (!v) glow(0, 2, 38, 'rgba(255,226,122,.6)');
    X.beginPath(); X.arc(0, -26, 8, Math.PI, 0); X.lineWidth = 3; X.strokeStyle = OL; X.stroke();
    P([-14, -18, 14, -18, 10, -26, -10, -26], k);
    RR(-13, -18, 26, 36, 6, v ? '#5a5466' : '#ffe27a');
    RR(-16, 18, 32, 8, 2, k);
  });
  def('rabbit', 38, { ft: 32, col: [9, 10, 8], vn: 2, asym: true }, (k, v) => {
    C(-24, 14, 6, '#fff');
    E(8, -30, 4.5, 14, k);
    if (v) E(24, -22, 4.5, 14, k, 1.2); else E(17, -31, 4.5, 14, k, 0.25);
    E(-4, 14, 20, 18, k); C(12, -6, 13, k); eye(17, -8, 2.4); C(24, -3, 2.2, PAL[7], true);
  });
  def('butterfly', 32, { ft: 60, col: [5, 1, 7, 2, 6], vn: 2 }, (k, v) => {
    E(-12, -8, 13, 10, k, -0.5); E(12, -8, 13, 10, k, 0.5); E(-10, 9, 9, 7, sh(k, -0.15), 0.4); E(10, 9, 9, 7, sh(k, -0.15), -0.4);
    if (v) { C(-14, -9, 3.5, WHITE, true); C(14, -9, 3.5, WHITE, true); }
    E(0, 0, 3.5, 14, OL, 0, true); S([0, -12, -6, -22], 2, OL); S([0, -12, 6, -22], 2, OL);
  });
  def('sign', 46, { ft: 44, asym: true }, () => {
    RR(-5, -14, 10, 58, 2, '#8a5a32');
    P([-30, -36, 22, -36, 36, -24, 22, -12, -30, -12], WOOD2); S([-20, -24, 14, -24], 2.5, '#8a5a32');
  });

  /* misc */
  def('moon', 42, { col: [2, 9], asym: true }, (k) => {
    X.beginPath(); X.arc(0, 0, 34, -Math.PI / 2, Math.PI / 2, false); X.arc(-42.2, 0, 54.2, 0.678, -0.678, true); X.closePath(); F(k);
    C(20, -10, 4, sh(k, -0.15), true); C(22, 12, 3, sh(k, -0.15), true);
  });

  /* market */
  def('stall', 195, { ft: 92, col: [0, 5, 3, 1, 6] }, (k) => {
    RR(-140, -150, 10, 240, 2, '#8a5a32'); RR(130, -150, 10, 240, 2, '#8a5a32');
    for (let i = 0; i < 6; i++) { const x = -160 + i * 320 / 6; P([x, -175, x + 320 / 6, -175, x + 320 / 6, -128, x, -128], i % 2 ? WHITE : k); X.beginPath(); X.arc(x + 160 / 6, -128, 160 / 6, 0, Math.PI); F(i % 2 ? WHITE : k); }
    RR(-150, 12, 300, 80, 4, '#b5793f'); RR(-158, 6, 316, 14, 3, '#d4a064');
    S([-120, 50, 120, 50], 2.5, '#8a5a32');
  });
  def('crate', 52, { ft: 38, col: [0, 1, 2, 3], vn: 2 }, (k, v) => {
    const fr = v ? [-14, 14] : [-30, -10, 10, 30];
    fr.forEach((x) => { C(x, -14, 11, k); C(x - 3, -18, 3, 'rgba(255,255,255,.5)', true); });
    RR(-44, -10, 88, 48, 4, WOOD2); S([-44, 6, 44, 6], 2.5, '#8a5a32'); S([-44, 22, 44, 22], 2.5, '#8a5a32');
  });
  def('banana', 36, { ft: 18, col: [2, 3], asym: true }, (k) => {
    for (let i = 0; i < 3; i++) { X.beginPath(); X.moveTo(-28, -10 + i * 7); X.quadraticCurveTo(-2, 30 + i * 4, 28, -4 + i * 6); X.quadraticCurveTo(-2, 14 + i * 4, -28, -10 + i * 7); X.closePath(); F(i === 1 ? sh(k, -0.08) : k); }
    RR(-34, -16, 10, 12, 3, '#6b4423');
  });
  def('melon', 46, { ft: 32, vn: 2 }, (k, v) => {
    if (!v) { E(0, 0, 40, 32, '#3c9a45'); for (let i = -2; i <= 2; i++) { X.beginPath(); X.ellipse(0, 0, Math.abs(i) * 12 + 3, 31, 0, -1.3, 1.3); X.lineWidth = 4; X.strokeStyle = '#1f6b2a'; X.stroke(); } }
    else { X.beginPath(); X.arc(0, -6, 40, 0, Math.PI); X.closePath(); F('#3c9a45'); X.beginPath(); X.arc(0, -6, 34, 0, Math.PI); X.closePath(); F('#f05a5a'); for (let i = 0; i < 5; i++) E(-20 + i * 10, 6 + (i % 2) * 8, 2, 3.5, OL, 0, true); }
  });
  def('carrot', 36, { ft: 14, col: [1, 6], asym: true }, (k) => {
    E(24, -10, 10, 4, GREEN, -0.9); E(28, -2, 10, 4, GREEN, 0.2); E(22, -16, 9, 4, DGREEN, -1.5);
    P([-32, 12, 20, -12, 24, 0], k); S([-10, 0, -4, 6], 2, sh(k, -0.3)); S([4, -4, 8, 2], 2, sh(k, -0.3));
  });
  def('basket', 42, { ft: 30, col: [8, 2], vn: 2 }, (k, v) => {
    X.beginPath(); X.arc(0, -4, 26, Math.PI, 0); X.lineWidth = 5 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 5; X.strokeStyle = sh(k, -0.2); X.stroke();
    if (v) { E(-10, -6, 16, 9, '#d9a25b', -0.3); E(12, -8, 15, 9, '#e0b06b', 0.3); }
    P([-38, -4, 38, -4, 30, 30, -30, 30], k);
    for (let i = 0; i < 3; i++) S([-34 + i * 2, 6 + i * 8, 34 - i * 2, 6 + i * 8], 2, sh(k, -0.3));
  });
  def('pricetag', 34, { ft: 32, vn: 3, tx: 1 }, (k, v) => {
    RR(-3, -2, 6, 34, 2, '#8a5a32'); RR(-30, -30, 60, 30, 5, WHITE);
    X.fillStyle = PAL[0]; X.font = '700 19px "IBM Plex Mono",monospace'; X.textAlign = 'center'; X.textBaseline = 'middle'; X.fillText(['500', '800', '300'][v], 0, -14);
  });
  def('umbrella', 90, { ft: 86, col: [0, 5, 3, 2, 7], vn: 2 }, (k, v) => {
    RR(-3, -40, 6, 126, 2, '#e3e1e8');
    X.beginPath(); X.moveTo(-86, -30); X.quadraticCurveTo(0, -112, 86, -30); X.closePath(); F(k);
    if (!v) clipDo(() => { X.moveTo(-86, -30); X.quadraticCurveTo(0, -112, 86, -30); X.closePath(); }, () => { X.fillStyle = WHITE; for (let i = 0; i < 3; i++) { X.beginPath(); X.moveTo(0, -80); X.lineTo(-62 + i * 52, -24); X.lineTo(-40 + i * 52, -24); X.closePath(); X.fill(); } });
    X.beginPath(); X.moveTo(-86, -30); X.quadraticCurveTo(0, -112, 86, -30); X.closePath(); ink();
    C(0, -80, 4, k);
  });

  /* misc */
  def('flag', 44, { ft: 42, col: [0, 5, 2, 3, 6], asym: true }, (k) => {
    S([-14, 42, -14, -40], 3.5 + LWv * 2, OL); S([-14, 42, -14, -40], 3.5, '#d8d3e0');
    P([-12, -40, 32, -27, -12, -12], k); C(-14, -42, 3.5, GOLD);
  });
  def('bench', 62, { ft: 26, col: [8, 3, 0, 5] }, (k) => {
    RR(-50, 6, 8, 22, 2, '#3b3542'); RR(42, 6, 8, 22, 2, '#3b3542');
    RR(-58, -26, 116, 12, 3, k); RR(-58, -10, 116, 12, 3, k); RR(-60, 4, 120, 10, 3, sh(k, -0.12));
  });

  /* kitchen */
  def('pot', 52, { ft: 34, col: [0, 5, 10, 3], vn: 2 }, (k, v) => {
    RR(-46, -10, 14, 8, 3, sh(k, -0.2)); RR(32, -10, 14, 8, 3, sh(k, -0.2));
    RR(-36, -16, 72, 50, 9, k); E(-20, 8, 6, 14, 'rgba(255,255,255,.3)', 0, true);
    if (!v) { E(0, -17, 39, 8, sh(k, 0.12)); RR(-7, -30, 14, 9, 4, OL); }
    else { E(0, -16, 35, 7, '#7a3b22'); Qd(-10, -26, -18, -38, -8, -50, 3, '#d8d3e0'); Qd(10, -26, 2, -38, 12, -50, 3, '#d8d3e0'); }
  });
  def('pan', 54, { ft: 14, col: [11, 0, 5], vn: 2, asym: true }, (k, v) => {
    RR(22, -4, 34, 9, 4, '#3b3542'); RR(-46, -8, 70, 20, 9, k);
    if (v) { E(-12, -12, 18, 6, '#fff'); C(-10, -14, 5, GOLD); }
  });
  def('kettle', 46, { ft: 40, col: [0, 5, 9, 2, 3], asym: true }, (k) => {
    X.beginPath(); X.arc(0, -16, 18, Math.PI * 1.05, -0.05 * Math.PI); X.lineWidth = 5 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 5; X.strokeStyle = '#3b3542'; X.stroke();
    P([22, 6, 44, -16, 48, -12, 28, 22], k);
    X.beginPath(); X.moveTo(-30, 40); X.lineTo(30, 40); X.quadraticCurveTo(34, -10, 0, -12); X.quadraticCurveTo(-34, -10, -30, 40); X.closePath(); F(k);
    RR(-8, -18, 16, 7, 3, sh(k, -0.25)); E(-14, 14, 5, 12, 'rgba(255,255,255,.35)', 0, true);
  });
  def('plates', 42, { ft: 20, col: [5, 4, 0], vn: 2 }, (k, v) => {
    const n = v ? 3 : 2;
    for (let i = 0; i < n; i++) { const y = 12 - i * 10; E(0, y, 38, 8, WHITE); X.beginPath(); X.ellipse(0, y, 30, 5.5, 0, 0, TAU); X.lineWidth = 2.5; X.strokeStyle = k; X.stroke(); }
  });
  def('jar', 38, { ft: 34, col: [0, 3, 1, 5], vn: 2 }, (k, v) => {
    RR(-22, -18, 44, 52, 10, 'rgba(225,242,255,.7)');
    if (!v) { C(-8, 20, 7, '#b5793f'); C(8, 18, 7, '#c58a4a'); C(0, 4, 7, '#b5793f'); }
    else RR(-19, 6, 38, 25, 8, '#c92f4a', true);
    RR(-24, -28, 48, 12, 3, k); E(-12, 0, 3, 10, 'rgba(255,255,255,.6)', 0, true);
  });
  def('bread', 44, { ft: 22, vn: 2 }, (k, v) => {
    E(0, 0, 40, 22, '#d9a25b'); E(0, -6, 34, 12, '#e8b876', 0, true);
    const n = v ? 3 : 2; for (let i = 0; i < n; i++) { const x = -((n - 1) * 14) / 2 + i * 14; S([x - 5, 6, x + 5, -10], 3, '#a8743a'); }
  });

  /* winter */
  def('house', 130, { ft: 92, col: [0, 5, 3, 2, 8], vn: 2 }, (k, v) => {
    RR(40, -86, 20, 40, 2, '#9b5b44');
    RR(-80, -20, 160, 112, 2, k);
    P([-102, -14, 0, -96, 102, -14], '#7a3b2e'); P([-102, -14, -84, -2, 0, -70, 84, -2, 102, -14, 0, -96], '#f8fbff');
    RR(-18, 34, 36, 58, 4, '#6b4423'); C(10, 64, 3, GOLD, true);
    const wc = v ? '#4b5a8a' : '#ffd96a';
    RR(-66, 4, 34, 30, 3, wc); RR(32, 4, 34, 30, 3, wc); S([-49, 4, -49, 34], 2.5, WHITE); S([49, 4, 49, 34], 2.5, WHITE);
  });
  def('snowman', 72, { ft: 58, col: [0, 5, 3, 6, 2], vn: 2, asym: true }, (k, v) => {
    SO([-18, -8, -40, -22], 3, '#7a4f2c'); SO([18, -8, 40, -24], 3, '#7a4f2c');
    C(0, 30, 28, '#fbfbff'); C(0, -8, 21, '#fbfbff'); C(0, -38, 15, '#fbfbff');
    RR(-15, -26, 30, 8, 4, k); RR(4, -26, 8, 22, 3, k);
    C(-5, -42, 2.4, OL, true); C(6, -42, 2.4, OL, true); P([2, -37, 22, -34, 2, -32], '#f28a2e');
    C(0, -6, 2.6, OL, true); C(0, 4, 2.6, OL, true);
    if (!v) { RR(-17, -54, 34, 6, 2, '#2b2a33'); RR(-11, -72, 22, 20, 2, '#2b2a33'); RR(-11, -60, 22, 4, 0, PAL[0], true); }
  });
  def('sled', 50, { ft: 22, col: [0, 5, 8, 3], asym: true }, (k) => {
    X.beginPath(); X.moveTo(-44, 18); X.lineTo(34, 18); X.quadraticCurveTo(50, 18, 46, 2); X.lineWidth = 4 + LWv * 2; X.strokeStyle = OL; X.stroke(); X.lineWidth = 4; X.strokeStyle = '#c9ccd6'; X.stroke();
    S([-30, 6, -30, 18], 3, OL); S([20, 6, 20, 18], 3, OL);
    RR(-44, -8, 82, 14, 4, k); RR(-40, -20, 74, 12, 4, sh(k, 0.12));
  });
  def('flake', 28, {}, () => {
    for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, c = Math.cos(a), s = Math.sin(a); SO([0, 0, c * 24, s * 24], 3, '#f4f9ff'); }
    for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, c = Math.cos(a), s = Math.sin(a); S([c * 14 - s * 6, s * 14 + c * 6, c * 18, s * 18, c * 14 + s * 6, s * 14 - c * 6], 2.5, '#f4f9ff'); }
    C(0, 0, 4, '#f4f9ff');
  });
  def('lamppost', 92, { ft: 90, vn: 2 }, (k, v) => {
    if (!v) glow(0, -62, 70, 'rgba(255,226,122,.55)');
    RR(-5, -50, 10, 138, 2, '#3b3542'); RR(-14, 80, 28, 10, 3, '#3b3542');
    P([-16, -50, 16, -50, 12, -76, -12, -76], v ? '#5a5466' : '#ffe27a'); P([-20, -76, 20, -76, 0, -90], '#3b3542');
  });
  def('mitten', 32, { ft: 30, col: [0, 5, 3, 6, 7], asym: true }, (k) => {
    E(14, -4, 7, 12, k, 0.5); RR(-16, -26, 28, 44, 13, k); RR(-18, 14, 32, 14, 4, WHITE);
    S([-10, -6, 6, -6], 2.5, sh(k, 0.35));
  });
  def('penguin', 42, { ft: 38, col: [0, 5, 3, 2], asym: true }, (k) => {
    E(-10, 38, 9, 4, '#f5a524'); E(10, 38, 9, 4, '#f5a524');
    E(0, 4, 24, 34, '#2b2a33'); E(2, 10, 16, 26, WHITE, 0, true);
    E(22, 0, 6, 16, '#2b2a33', -0.6); eye(4, -18, 3); eye(14, -18, 3); P([10, -12, 26, -10, 10, -6], '#f5a524');
    RR(-20, -6, 40, 8, 4, k);
  });

  /* beach */
  def('palm', 150, { ft: 145, asym: true }, () => {
    for (let i = 0; i < 8; i++) { const t = i / 8; RR(-12 + t * 34 - 1, 140 - i * 34 - 20, 26 - t * 6, 30, 6, i % 2 ? '#b5793f' : '#a26a36'); }
    const lv = [[34, -120, -60, -104], [34, -120, 120, -94], [34, -120, -10, -150], [34, -120, 96, -150], [34, -120, -44, -70], [34, -120, 110, -60]];
    lv.forEach((l) => { const mx = (l[0] + l[2]) / 2, my = (l[1] + l[3]) / 2 - 18; X.beginPath(); X.moveTo(l[0], l[1]); X.quadraticCurveTo(mx, my - 14, l[2], l[3]); X.quadraticCurveTo(mx, my + 12, l[0], l[1]); X.closePath(); F('#3f9a45'); });
    C(28, -112, 8, '#7a4f2c'); C(42, -110, 8, '#7a4f2c');
  });
  def('towel', 120, { ft: 0, col: [0, 5, 6, 3, 7] }, (k) => {
    RR(-110, -26, 220, 52, 6, k); for (let i = 0; i < 3; i++) RR(-80 + i * 60, -26, 22, 52, 0, WHITE, true);
    X.beginPath(); rrp(-110, -26, 220, 52, 6); ink();
  });
  def('bucket', 38, { ft: 30, col: [0, 5, 2, 3, 7], vn: 2 }, (k, v) => {
    if (v) { RR(6, -46, 6, 30, 2, '#8a5a32'); P([2, -46, 16, -46, 18, -60, 0, -60], GOLD); }
    X.beginPath(); X.arc(0, -12, 24, Math.PI, 0); X.lineWidth = 3; X.strokeStyle = OL; X.stroke();
    P([-24, -12, 24, -12, 18, 30, -18, 30], k); RR(-26, -16, 52, 8, 3, sh(k, 0.2));
  });
  def('castle', 62, { ft: 40, vn: 2 }, (k, v) => {
    const sand = '#e6c27a', tw = v ? [-38, 0, 38] : [-30, 30];
    RR(-50, 0, 100, 40, 3, sand);
    tw.forEach((x) => { RR(x - 13, -30, 26, 40, 2, sand); for (let i = 0; i < 3; i++) RR(x - 13 + i * 10, -38, 6, 9, 1, sand); });
    RR(-9, 18, 18, 22, 8, '#b08a4a'); S([0, -34, 0, -58], 2.5, OL); P([0, -58, 18, -52, 0, -46], PAL[0]);
  });
  def('boat', 70, { ft: 30, col: [0, 5, 2, 9], asym: true }, (k) => {
    S([-4, 14, -4, -62], 4, '#7a4f2c');
    P([0, -60, 0, 6, 46, 6], WHITE); P([-8, -54, -8, 6, -44, 6], k);
    P([-56, 14, 58, 14, 40, 34, -44, 34], '#a86d38'); S([-50, 22, 52, 22], 2.5, '#7a4f2c');
  });

  /* farm */
  def('barn', 160, { ft: 112, col: [0, 8], vn: 2 }, (k, v) => {
    RR(-110, -30, 220, 142, 2, k); P([-124, -24, -70, -100, 70, -100, 124, -24], sh(k, -0.25)); P([-70, -100, 70, -100, 50, -86, -50, -86], WHITE, true);
    RR(-26, -76, 52, 36, 3, WHITE); RR(-20, -70, 40, 24, 2, '#3b2a24', true);
    if (!v) { RR(-46, 22, 92, 90, 2, WHITE); S([-46, 22, 46, 112], 5, WHITE); RR(-40, 28, 80, 78, 1, k, true); S([-40, 28, 40, 106], 6, WHITE); S([40, 28, -40, 106], 6, WHITE); X.beginPath(); rrp(-46, 22, 92, 90, 2); ink(); }
    else { RR(-46, 22, 92, 90, 2, '#2b2233'); RR(-80, 22, 34, 90, 2, k); RR(46, 22, 34, 90, 2, k); }
  });
  def('chicken', 34, { ft: 32, col: [9, 8, 1], asym: true }, (k) => {
    S([-4, 18, -6, 32], 3, '#f5a524'); S([6, 18, 8, 32], 3, '#f5a524');
    P([-30, -6, -18, -16, -14, 6], sh(k, -0.1)); E(-2, 6, 22, 16, k); C(14, -10, 11, k);
    P([10, -21, 14, -27, 18, -21], PAL[0]); P([24, -12, 32, -9, 24, -6], '#f5a524'); E(22, -2, 3, 5, PAL[0], 0, true); eye(16, -12, 2.2);
    E(-4, 6, 11, 7, sh(k, -0.12), -0.3);
  });
  def('pig', 42, { ft: 30, vn: 2, asym: true }, (k, v) => {
    const pk = '#f4a7b9';
    RR(-20, 14, 8, 16, 3, pk); RR(10, 14, 8, 16, 3, pk); Qd(-34, -2, -44, -10, -40, 4, 3, OL);
    E(-4, 2, 32, 22, pk);
    if (v) { E(-14, 10, 8, 5, '#9b6332', 0.3, true); E(4, -8, 6, 4, '#9b6332', 0, true); }
    C(24, -6, 15, pk); P([16, -18, 22, -30, 28, -18], pk); E(36, -2, 6, 7, '#f283a0'); C(35, -4, 1.5, OL, true); C(37, 0, 1.5, OL, true); eye(26, -10, 2.4);
  });
  def('sheep', 46, { ft: 36, asym: true }, () => {
    RR(-22, 16, 7, 20, 3, '#3b3542'); RR(12, 16, 7, 20, 3, '#3b3542');
    blob([-24, 0, 16, -6, -10, 18, 14, -2, 17, -8, 12, 18, 8, 10, 15], '#fbfbff');
    E(30, -8, 12, 15, '#3b3542'); E(22, -18, 8, 4, '#3b3542', -0.4); eye(34, -12, 2.3, true);
  });
  def('cow', 58, { ft: 44, col: [11, 8], vn: 2, asym: true }, (k, v) => {
    RR(-36, 18, 9, 26, 3, '#f6f2ea'); RR(22, 18, 9, 26, 3, '#f6f2ea'); Qd(-44, -10, -54, 4, -50, 20, 3, OL);
    RR(-46, -24, 84, 50, 18, '#fbfbff');
    E(-22, -8, 12, 9, k, 0.3, true); E(8, 6, 10, 8, k, -0.2, true);
    X.beginPath(); rrp(-46, -24, 84, 50, 18); ink();
    if (v) { S([40, -2, 40, 12], 2, OL); C(40, 16, 6, GOLD); }
    RR(30, -34, 30, 34, 12, '#fbfbff'); E(48, -8, 12, 8, '#f4a7b9'); P([32, -34, 28, -46, 38, -36], '#e6dccb'); eye(42, -22, 2.6);
  });
  def('hay', 40, { ft: 30, vn: 2 }, (k, v) => {
    if (!v) { RR(-36, -24, 72, 52, 5, '#e8c45a'); S([-36, -6, 36, -6], 2, '#b8932f'); S([-36, 10, 36, 10], 2, '#b8932f'); S([-12, -24, -12, 28], 3, '#a8743a'); S([12, -24, 12, 28], 3, '#a8743a'); }
    else { C(0, 0, 30, '#e8c45a'); X.beginPath(); X.arc(0, 0, 20, 0, 5.5); X.lineWidth = 2; X.strokeStyle = '#b8932f'; X.stroke(); X.beginPath(); X.arc(0, 0, 10, 0, 5.5); X.stroke(); }
  });

  /* ---------- round 12: more things (pn = patterns, cn = [min,max] count, tx = text detail, rt = may tilt, hot = prop diff spot) ---------- */
  const SKIN = '#f3c9a0', METAL = '#8f909c', DARK = '#3b3542';
  function signType(name, words, cols) {
    def(name, 70, { ft: 26, col: cols || [0, 5, 3, 6, 8], vn: words.length, tx: 1, rt: 1 }, (k, v) => {
      RR(-66, -27, 132, 54, 10, k); RR(-59, -20, 118, 40, 7, sh(k, -0.18), true);
      TX(words[v], 0, 1, 30, '#fffaf0');
    });
  }
  signType('libsign', ['쉿!', '조용히', '책 읽기', '도서관']);
  signType('flowsign', ['꽃', '새싹', '화분', '선물']);
  signType('bakesign', ['빵', '갓 구움', '쿠키', '케이크']);
  signType('shopsign', ['카페', '빵집', '꽃집', '책방']);


  /* street · harbour · café · workshop */
  signType('cafesign', ['커피', '라떼', '디저트', '오늘의 빵'], [8, 11, 3, 0, 5]);
  def('lighthouse', 122, { ft: 118, col: [0, 5, 3, 11], vn: 2, hot: [0, -20, 70] }, (k, v) => {
    const body = () => { X.moveTo(-34, 118); X.lineTo(34, 118); X.lineTo(22, -60); X.lineTo(-22, -60); X.closePath(); };
    X.beginPath(); body(); Fn(WHITE);
    clipDo(body, () => { X.fillStyle = k; X.fillRect(-40, -30, 80, 30); X.fillRect(-40, 30, 80, 30); X.fillRect(-40, 92, 80, 26); });
    X.beginPath(); body(); ink();
    if (v) glow(0, -84, 54, 'rgba(255,240,170,.6)');
    RR(-30, -70, 60, 10, 2, DARK); RR(-17, -100, 34, 30, 4, v ? '#ffe27a' : '#9fd3f0');
    P([-24, -100, 24, -100, 0, -120], k); RR(-7, 92, 14, 26, 3, WOOD);
  });
  def('bike', 54, { ft: 28, col: [0, 5, 3, 2, 6, 11], asym: true }, (k) => {
    RG(-30, 10, 18, 3, DARK); RG(30, 10, 18, 3, DARK);
    SO([-30, 10, -8, -16, 18, -16, 30, 10], 4, k); SO([-8, -16, 0, 10, -30, 10], 4, k); SO([0, 10, 18, -16], 4, k);
    SO([18, -16, 14, -32, 25, -34], 3.5, DARK); RR(-17, -26, 18, 6, 3, DARK);
  });
  def('hydrant', 36, { ft: 34, col: [0, 2, 5, 3] }, (k) => {
    RR(-15, -14, 30, 44, 5, k); RR(-20, 26, 40, 8, 3, sh(k, -0.2)); E(0, -14, 16, 10, sh(k, 0.15));
    RR(-6, -30, 12, 10, 3, k); RR(-26, -4, 11, 12, 3, sh(k, -0.15)); RR(15, -4, 11, 12, 3, sh(k, -0.15)); C(0, 6, 5, sh(k, -0.3));
  });
  def('buoy', 38, { ft: 22, col: [0, 1, 2, 3], vn: 2 }, (k, v) => {
    E(0, 20, 34, 7, 'rgba(255,255,255,.4)', 0, true);
    P([-26, 20, 26, 20, 14, -18, -14, -18], k); if (v) RR(-21, -2, 42, 10, 2, WHITE);
    SO([0, -18, 0, -32], 3.5, DARK); C(0, -32, 6, v ? GOLD : k);
  });
  def('espresso', 50, { ft: 42, col: [10, 0, 11, 5, 4], vn: 2, asym: true }, (k, v) => {
    RR(-42, -40, 84, 22, 6, k); RR(-42, -18, 18, 58, 3, sh(k, -0.2)); RR(-46, 36, 92, 8, 3, DARK);
    RR(-12, -18, 36, 13, 3, METAL); SO([6, -5, 6, 6], 5, DARK);
    if (v) { RR(-4, 18, 22, 18, 3, WHITE); SO([18, 22, 24, 28, 18, 32], 3, WHITE); }
    C(24, -29, 4.5, PAL[0], true); C(34, -29, 4.5, PAL[3], true);
  });
  def('hammer', 42, { col: [8, 0, 11, 5], rt: 1, asym: true }, (k) => {
    RR(-6, -16, 12, 56, 4, k); P([-30, -34, 20, -34, 30, -26, 20, -14, -30, -14], METAL);
  });
  def('saw', 52, { col: [0, 5, 8, 2], rt: 1, asym: true }, (k) => {
    P([-46, -16, 30, -16, 30, 8, -46, 20], '#c9ccd6');
    X.beginPath(); for (let x = -46; x < 28; x += 8) { const y = 20 - (x + 46) * 12 / 76; X.moveTo(x, y); X.lineTo(x + 4, y + 6); X.lineTo(x + 8, y - 1); } ink();
    RR(26, -24, 26, 36, 8, k); RR(32, -16, 12, 18, 4, sh(k, -0.4), true);
  });
  def('toolbox', 46, { ft: 28, col: [0, 5, 3, 2, 1], vn: 2 }, (k, v) => {
    SO([-14, -14, -14, -26, 14, -26, 14, -14], 4, DARK);
    RR(-42, -14, 84, 42, 4, k); RR(-42, -14, 84, 13, 3, sh(k, -0.2));
    if (v) RR(-42, 12, 84, 8, 0, WHITE, true);
    RR(-6, -6, 12, 8, 2, METAL);
  });


  def('suitcase', 46, { ft: 40, col: [0, 5, 3, 11, 6, 2], vn: 2 }, (k, v) => {
    SO([-12, -30, -12, -42, 12, -42, 12, -30], 4, DARK);
    RR(-30, -30, 60, 68, 7, k); RR(-30, -30, 60, 68, 7, k);
    S([-14, -24, -14, 32], 3, sh(k, -0.25)); S([14, -24, 14, 32], 3, sh(k, -0.25));
    if (v) { RR(-8, -14, 20, 14, 3, GOLD); }
    C(-20, 42, 4, DARK, true); C(20, 42, 4, DARK, true);
  });
  def('laptop', 44, { ft: 22, col: [10, 11, 9, 5], vn: 2, asym: true }, (k, v) => {
    P([-30, -40, 30, -40, 34, 14, -34, 14], k); P([-24, -34, 24, -34, 27, 8, -27, 8], v ? '#2a4a6a' : '#9fd3f0');
    if (v) { S([-14, -20, 10, -20], 3, '#7fe3c1'); S([-14, -10, 16, -10], 3, '#7fe3c1'); }
    P([-42, 14, 42, 14, 34, 22, -34, 22], sh(k, 0.15));
  });
  signType('gatesign', ['A12', 'B07', 'C21', 'D03'], [5, 11, 4, 0]);

  /* misc */
  def('wrench', 46, { col: [10, 0, 5, 2], rt: 1, asym: true }, (k) => {
    X.save(); X.rotate(0.75);
    P([-6, 30, 6, 30, 6, -24, 15, -32, 11, -44, 5, -38, -5, -38, -11, -44, -15, -32, -6, -24], k);
    C(0, 32, 11, k); C(0, 32, 4.5, '#2b2233', true);
    X.restore();
  });
  def('screen', 50, { ft: 30, vn: 4, tx: 1, rt: 1 }, (k, v) => {
    RR(-44, -31, 88, 62, 7, DARK); RR(-36, -24, 72, 46, 4, '#163447');
    TX(['12', '47', '08', '93'][v], 0, -1, 32, '#7fe3c1', 1);
  });

  /* classroom */
  def('chalkboard', 205, { ft: 96, vn: 4, tx: 1, hot: [0, -16, 120] }, (k, v) => {
    RR(-196, -96, 392, 184, 6, '#8a5a32'); RR(-184, -84, 368, 160, 3, '#2f5d4a');
    X.fillStyle = 'rgba(255,255,255,.06)'; X.fillRect(-170, -70, 120, 40); X.fillRect(40, 30, 110, 30);
    TX(['1 + 2 = 3', '가 나 다 라', '5 × 2 = 10', '안녕하세요'][v], 0, -16, 44, '#f4f1e6');
    S([-150, 42, -60, 42], 4, '#f4f1e6');
    RR(-190, 84, 380, 10, 3, '#a86d38'); RR(100, 74, 26, 8, 2, WHITE, true); RR(134, 74, 20, 8, 2, GOLD, true);
  });
  def('desk', 112, { ft: 70, col: [8, 5, 3, 10] }, (k) => {
    RR(-92, -6, 8, 76, 2, '#5a5466'); RR(84, -6, 8, 76, 2, '#5a5466');
    RR(-80, 4, 160, 34, 3, sh(k, -0.1));
    RR(-104, -16, 208, 16, 4, '#d4a064');
  });
  def('globe', 44, { ft: 40, col: [5, 4] }, (k) => {
    RR(-16, 32, 32, 8, 3, '#8a5a32'); S([0, 22, 0, 32], 5, '#8a5a32');
    C(0, -6, 28, k);
    clipDo(() => X.arc(0, -6, 28, 0, TAU), () => { blob([-12, -16, 10, -2, -10, 8, 14, 4, 9, 6, 10, 6], '#5cb85c'); });
    X.beginPath(); X.arc(0, -6, 28, 0, TAU); ink();
    RG(0, -6, 35, 4, '#c9a447', -2.4, 0.75);
  });
  def('pencils', 40, { ft: 30, col: [5, 0, 3, 6], cn: [2, 5] }, (k, v, o) => {
    const n = o.n || 3, cs = [PAL[0], GOLD, PAL[5], PAL[3], PAL[6]];
    for (let i = 0; i < n; i++) { const x = n === 1 ? 0 : -13 + i * 26 / (n - 1); X.save(); X.translate(x, -2); X.rotate(x / 45); RR(-4, -32, 8, 32, 1, cs[i]); P([-4, -32, 4, -32, 0, -40], '#f3e6cf'); X.restore(); }
    RR(-18, -6, 36, 36, 5, k);
  });
  def('calendar', 46, { vn: 5, tx: 1, rt: 1 }, (k, v) => {
    RR(-32, -30, 64, 62, 5, WHITE); RR(-32, -30, 64, 17, 5, PAL[0]);
    TX(['3', '7', '12', '25', '9'][v], 0, 10, 32, OL, 1);
    C(-16, -30, 4, METAL); C(16, -30, 4, METAL);
  });
  def('trophy', 42, { ft: 36, col: [2, 10, 8], vn: 2 }, (k, v) => {
    RR(-20, 26, 40, 10, 2, '#6b4423'); RR(-5, 6, 10, 22, 2, k);
    if (!v) { RG(-24, -14, 10, 5, k); RG(24, -14, 10, 5, k); }
    X.beginPath(); X.moveTo(-24, -32); X.lineTo(24, -32); X.quadraticCurveTo(24, 10, 0, 10); X.quadraticCurveTo(-24, 10, -24, -32); X.closePath(); F(k);
    starP(0, -14, 5, 9, 4, WHITE);
  });
  def('plane2', 40, { asym: true, rt: 1 }, () => {
    P([-36, 8, 36, -8, -22, -18], WHITE); P([-36, 8, 36, -8, -14, 6], '#dfe3ec'); P([-14, 6, 36, -8, -10, 16], '#c9ccd6');
  });
  def('chair', 58, { ft: 52, col: [0, 5, 3, 1, 8], asym: true }, (k) => {
    RR(-30, -54, 9, 106, 3, '#5a5466'); RR(22, 0, 8, 52, 3, '#5a5466');
    RR(-34, -54, 18, 46, 5, k); RR(-34, -8, 68, 12, 4, k);
  });

  /* misc */
  def('frog', 34, { ft: 18, col: [3, 4, 2, 7], vn: 2 }, (k, v) => {
    E(-18, 14, 12, 6, sh(k, -0.15)); E(18, 14, 12, 6, sh(k, -0.15));
    E(0, 4, 26, 16, k); C(-11, -12, 8, k); C(11, -12, 8, k);
    C(-11, -12, 4, '#fff', true); C(11, -12, 4, '#fff', true); C(-11, -12, 2, OL, true); C(11, -12, 2, OL, true);
    X.beginPath(); X.arc(0, 2, 12, 0.3, Math.PI - 0.3); ink();
    if (v) { C(-12, 8, 3.5, sh(k, -0.3), true); C(10, 12, 3.5, sh(k, -0.3), true); C(16, 2, 3, sh(k, -0.3), true); }
  });


  /* misc */
  def('goblet', 34, { ft: 30, col: [2, 10, 0] }, (k) => {
    RR(-14, 24, 28, 6, 3, k); RR(-3, 4, 6, 22, 2, k);
    X.beginPath(); X.moveTo(-18, -28); X.lineTo(18, -28); X.quadraticCurveTo(18, 6, 0, 6); X.quadraticCurveTo(-18, 6, -18, -28); X.closePath(); F(k);
    C(0, -12, 4.5, PAL[0]);
  });
  def('candles', 46, { ft: 40, cn: [2, 5] }, (k, v, o) => {
    const n = o.n || 3;
    RR(-18, 34, 36, 7, 3, GOLD); SO([0, 34, 0, 8], 5, GOLD); SO([-32, 6, 32, 6], 4, GOLD);
    for (let i = 0; i < n; i++) { const x = -32 + i * 64 / (n - 1); RR(x - 5, -18, 10, 24, 2, WHITE); P([x - 5, -18, x, -34, x + 5, -18], '#f28a2e'); }
  });
  def('barrel', 42, { ft: 38, vn: 2 }, (k, v) => {
    X.beginPath(); X.moveTo(-26, -36); X.quadraticCurveTo(-36, 0, -26, 36); X.lineTo(26, 36); X.quadraticCurveTo(36, 0, 26, -36); X.closePath(); F('#a86d38');
    S([-31, -18, 31, -18], 4, '#5a5466'); S([-31, 18, 31, 18], 4, '#5a5466'); E(0, -36, 26, 6, '#c58a4a');
    if (v) { RR(-7, -2, 14, 9, 2, '#5a5466'); RR(-3, 6, 6, 8, 1, '#5a5466'); }
  });

  /* library */
  def('bookcase', 175, { ft: 160, col: [8, 11, 6] }, (k) => {
    RR(-110, -160, 220, 320, 6, k === PAL[8] ? '#7a4f2c' : sh(k, -0.1)); RR(-98, -148, 196, 296, 3, '#4a2f1e', true);
    for (let s = 0; s < 4; s++) {
      const y = -148 + s * 74; let x = -94, i = s * 7;
      while (x < 86) { const w = Math.min(10 + ((i * 7) % 4) * 3, 94 - x), hh = 44 + ((i * 5) % 4) * 6; RR(x, y + 70 - hh, w, hh, 2, PAL[(i * 3) % 8]); x += w + 2; i++; }
      RR(-98, y + 70, 196, 6, 1, '#a86d38', true);
    }
  });
  def('table', 160, { ft: 70, col: [8, 11] }, (k) => {
    RR(-130, -10, 14, 80, 3, '#7a4f2c'); RR(116, -10, 14, 80, 3, '#7a4f2c'); RR(-150, -22, 300, 18, 4, '#a86d38');
  });
  def('openbook', 42, { ft: 10, vn: 2, col: [0, 5, 3, 6] }, (k, v) => {
    P([-42, 8, -40, -16, 0, -12, 40, -16, 42, 8, 0, 12], k);
    P([-38, 4, -36, -20, -2, -16, -2, 8], WHITE); P([38, 4, 36, -20, 2, -16, 2, 8], WHITE);
    if (!v) { for (let i = 0; i < 4; i++) { S([-32, -13 + i * 5, -8, -11 + i * 5], 1.8, METAL); S([8, -11 + i * 5, 32, -13 + i * 5], 1.8, METAL); } }
    else { C(-20, -6, 8, PAL[0]); P([8, 3, 20, -15, 32, 3], PAL[3]); }
  });
  def('hourglass', 38, { ft: 36, vn: 2 }, (k, v) => {
    const path = () => { X.moveTo(-17, -28); X.lineTo(17, -28); X.lineTo(3, 0); X.lineTo(17, 28); X.lineTo(-17, 28); X.lineTo(-3, 0); X.closePath(); };
    X.beginPath(); path(); Fn('rgba(220,240,255,.8)');
    if (!v) { P([-14, -25, 14, -25, 2, -3, -2, -3], GOLD, true); P([-7, 28, 7, 28, 0, 20], GOLD, true); }
    else { P([-15, 28, 15, 28, 3, 4, -3, 4], GOLD, true); P([-5, -5, 5, -5, 0, -1], GOLD, true); }
    X.beginPath(); path(); ink();
    RR(-23, -36, 46, 9, 3, WOOD); RR(-23, 27, 46, 9, 3, WOOD);
  });
  def('magnifier', 42, { asym: true, rt: 1, col: [0, 5, 11] }, (k) => {
    SO([10, 10, 32, 32], 9, k);
    C(-6, -6, 22, '#cfe8f5'); E(-12, -12, 8, 5, 'rgba(255,255,255,.75)', -0.7, true);
    RG(-6, -6, 22, 6, '#c9ccd6');
  });
  def('scroll', 40, { ft: 16, rt: 1 }, () => {
    RR(-30, -16, 60, 32, 2, '#f3e6cf'); E(-30, 0, 7, 18, '#e3d0b0'); E(30, 0, 7, 18, '#e3d0b0');
    S([-20, -6, 20, -6], 2, '#9b8b70'); S([-20, 4, 14, 4], 2, '#9b8b70');
  });

  /* subway */
  def('seats', 232, { ft: 40, col: [5, 0, 3, 6] }, (k) => {
    RR(-212, 0, 424, 40, 4, '#9aa3b5');
    RR(-220, -72, 440, 48, 10, sh(k, -0.12));
    for (let i = 1; i < 6; i++) S([-220 + i * 440 / 6, -66, -220 + i * 440 / 6, -30], 2.5, sh(k, -0.3));
    RR(-226, -28, 452, 28, 9, k);
  });
  def('person', 58, { ft: 54, col: [0, 5, 3, 6, 1, 7, 4], pn: 4, vn: 3 }, (k, v, o) => {
    RR(-13, 20, 11, 34, 4, '#3b3f5a'); RR(2, 20, 11, 34, 4, '#3b3f5a');
    SO([-20, -10, -26, 18], 8, k); SO([20, -10, 26, 18], 8, k);
    pfill(() => rrp(-20, -18, 40, 44, 11), k, o.p);
    if (v === 1) { RR(-17, -46, 34, 34, 12, '#3b2a24'); }
    C(0, -32, 14, SKIN);
    if (v === 0) { X.beginPath(); X.arc(0, -34, 15, Math.PI * 1.05, -0.05); X.closePath(); F('#3b2a24'); }
    else if (v === 1) { X.beginPath(); X.arc(0, -35, 15, Math.PI, 0); X.closePath(); F('#3b2a24'); }
    else { RR(-19, -44, 38, 7, 3, GOLD); RR(-12, -56, 24, 14, 5, GOLD); }
    C(-5, -31, 1.8, OL, true); C(5, -31, 1.8, OL, true);
  });
  def('strap', 36, { ft: -32 }, () => {
    S([0, -32, 0, 2], 4, '#8f909c'); RG(0, 14, 12, 5, GOLD);
  });
  def('routemap', 72, { ft: 0, col: [3, 0, 5, 1], cn: [4, 7] }, (k, v, o) => {
    RR(-66, -26, 132, 52, 5, WHITE); SO([-52, 6, 52, 6], 6, k);
    const n = o.n || 5; for (let i = 0; i < n; i++) C(-52 + i * 104 / (n - 1), 6, 6.5, WHITE);
    RR(-56, -18, 44, 9, 3, k, true);
  });
  def('stsign', 72, { vn: 4, tx: 1 }, (k, v) => {
    RR(-68, -26, 136, 52, 8, '#1f6b3a'); RR(-63, -21, 126, 42, 6, '#2a8a4c', true);
    TX(['꽃마을', '별빛역', '솔숲역', '달빛역'][v], 0, 1, 30, WHITE);
  });
  def('bag', 38, { ft: 30, col: [0, 1, 2, 5, 7, 3], pn: 4 }, (k, v, o) => {
    RG(0, -16, 11, 3.5, sh(k, -0.3), Math.PI, TAU);
    pfill(() => rrp(-24, -16, 48, 46, 4), k, o.p);
  });

  /* desert oasis */
  def('camel', 92, { ft: 64, vn: 2, asym: true }, (k, v) => {
    const c = '#d9a25b', d = '#b98250';
    RR(-40, 10, 10, 54, 4, d); RR(14, 10, 10, 54, 4, d);
    Qd(-44, -4, -56, 10, -52, 26, 4, c, true);
    if (v) { E(-20, -22, 16, 17, c); E(12, -22, 16, 17, c); } else E(-4, -24, 22, 21, c);
    Qd(34, -6, 54, -20, 58, -46, 13, c, true);
    E(-4, -2, 48, 22, c);
    RR(-22, 10, 10, 54, 4, c); RR(30, 10, 10, 54, 4, c);
    E(66, -50, 16, 10, c, 0.2); eye(68, -54, 2.4);
  });
  def('cactus', 54, { ft: 48, col: [3, 4], cn: [1, 3] }, (k, v, o) => {
    const n = o.n || 2, arm = (sx, y, l) => SO([0, y, sx * 24, y, sx * 24, y - l], 13, k);
    if (n >= 1) arm(-1, 8, 28);
    if (n >= 2) arm(1, -8, 26);
    if (n >= 3) arm(1, 26, 16);
    RR(-13, -46, 26, 94, 13, k); S([-4, -36, -4, 40], 2, sh(k, -0.25)); S([5, -36, 5, 40], 2, sh(k, -0.25));
  });
  def('amphora', 42, { ft: 38, col: [8, 1, 0, 4, 5], pn: 4 }, (k, v, o) => {
    RG(-16, -16, 9, 4, sh(k, -0.2), 1.4, 4.4); RG(16, -16, 9, 4, sh(k, -0.2), -1.3, 1.7);
    pfill(() => { X.moveTo(-10, -30); X.lineTo(10, -30); X.lineTo(8, -20); X.quadraticCurveTo(36, -8, 18, 34); X.lineTo(-18, 34); X.quadraticCurveTo(-36, -8, -8, -20); X.closePath(); }, k, o.p);
    RR(-13, -38, 26, 9, 3, sh(k, -0.15));
  });
  def('lizard', 46, { ft: 10, col: [3, 2, 1, 4], asym: true }, (k) => {
    Qd(-14, 0, -32, 8, -46, -4, 7, k, true);
    SO([-12, 2, -18, 12], 4, k); SO([14, 2, 20, 12], 4, k); SO([-12, -2, -18, -10], 4, k); SO([14, -2, 20, -10], 4, k);
    E(2, 0, 20, 8, k); E(26, -2, 11, 7, k); eye(30, -4, 1.9);
  });
  def('reeds', 44, { ft: 40, vn: 2 }, (k, v) => {
    const st = v ? [-16, -5, 6, 17] : [-11, 2, 14];
    st.forEach((x, i) => { const tx = x + (i % 2 ? 5 : -5), ty = -18 - (i % 2) * 10; S([x, 40, tx, ty], 3.5, '#5e8a3a'); E(tx, ty - 6, 4.5, 11, '#7a4f2c'); });
  });

  /* misc */
  def('anchor', 48, { ft: 42, col: [10, 11, 2] }, (k) => {
    RG(0, -34, 9, 5, k); SO([0, -24, 0, 36], 7, k); SO([-18, -14, 18, -14], 6, k);
    RG(0, 4, 32, 7, k, 0.35, Math.PI - 0.35);
    P([28, 14, 40, 2, 36, 24], k); P([-28, 14, -40, 2, -36, 24], k);
  });
  def('rope', 34, { ft: 14 }, () => {
    E(0, 4, 32, 12, '#d8b47a'); E(0, 0, 24, 9, '#c9a06a'); E(0, -3, 14, 5, '#b88f5a'); SO([14, -3, 28, -18], 4, '#d8b47a');
  });
  def('bottle', 36, { ft: 30, col: [3, 4, 8, 5], vn: 2 }, (k, v) => {
    RR(-6, -36, 12, 10, 2, '#a86d38'); RR(-15, -26, 30, 56, 10, sh(k, 0.15));
    if (v) { RR(-8, -10, 16, 28, 3, '#f3e6cf'); S([-8, -2, 8, -2], 2, '#a8743a'); }
    E(-7, -6, 3, 12, 'rgba(255,255,255,.55)', 0, true);
  });

  /* misc */
  def('gear', 42, { col: [10, 2, 1, 5, 0], cn: [6, 10], rt: 1 }, (k, v, o) => {
    const n = o.n || 8, w = Math.PI / n * 0.55, a = [];
    for (let i = 0; i < n; i++) { const t = i / n * TAU; a.push(Math.cos(t - w * 1.3) * 28, Math.sin(t - w * 1.3) * 28, Math.cos(t - w) * 40, Math.sin(t - w) * 40, Math.cos(t + w) * 40, Math.sin(t + w) * 40, Math.cos(t + w * 1.3) * 28, Math.sin(t + w * 1.3) * 28); }
    P(a, k); C(0, 0, 11, '#2b2233'); C(0, 0, 20, 'rgba(255,255,255,.18)', true);
  });

  /* flower shop */
  def('counter', 232, { ft: 70, col: [7, 4, 5, 3, 8] }, (k) => {
    RR(-220, -20, 440, 90, 6, k); RR(-220, 12, 440, 10, 0, sh(k, 0.22), true);
    RR(-228, -32, 456, 16, 4, '#d4a064');
  });
  def('bouquet', 48, { ft: 42, col: [0, 7, 1, 2, 6, 9], vn: 2 }, (k, v) => {
    S([-4, 0, -12, -16], 2.5, DGREEN); S([4, 0, 12, -16], 2.5, DGREEN);
    const fl = [-14, -18, 0, -30, 14, -18, -5, -8, 8, -6];
    for (let i = 0; i < fl.length; i += 2) { C(fl[i], fl[i + 1], 10, k); C(fl[i], fl[i + 1], 3.5, GOLD, true); }
    P([-22, -4, 22, -4, 6, 42, -6, 42], '#cfe8c0');
    if (v) { E(-9, 22, 8, 5, PAL[0], 0.3); E(9, 22, 8, 5, PAL[0], -0.3); C(0, 22, 4, PAL[0]); }
  });
  def('tulips', 48, { ft: 42, col: [0, 7, 2, 6, 1], cn: [2, 5] }, (k, v, o) => {
    const n = o.n || 3;
    for (let i = 0; i < n; i++) {
      const x = -18 + i * 36 / (n - 1), tx = x * 1.25;
      S([x, 10, tx, -22], 3, DGREEN);
      P([tx - 9, -34, tx - 9, -24, tx, -18, tx + 9, -24, tx + 9, -34, tx + 4, -28, tx, -36, tx - 4, -28], k);
    }
    P([-24, 6, 24, 6, 18, 42, -18, 42], '#9aa3b5'); RR(-26, 2, 52, 8, 3, '#b8bfcc');
  });
  def('wcan', 46, { ft: 30, col: [5, 3, 0, 2, 4], asym: true }, (k) => {
    SO([14, 12, 42, -18], 6, k); E(44, -20, 7, 4, sh(k, -0.2), 0.6);
    RG(-6, -12, 18, 5, sh(k, -0.2), Math.PI, TAU);
    RR(-30, -12, 48, 42, 8, k); E(-14, 6, 5, 12, 'rgba(255,255,255,.35)', 0, true);
  });
  def('succ', 34, { ft: 28, vn: 2 }, (k, v) => {
    const n = v ? 7 : 5;
    for (let i = 0; i < n; i++) { const a = -Math.PI + (i + 0.5) / n * Math.PI; E(Math.cos(a) * 12, -4 + Math.sin(a) * 12, 6, 13, i % 2 ? '#8fcf9b' : '#6fb27f', a + Math.PI / 2); }
    P([-19, 4, 19, 4, 14, 28, -14, 28], '#d9875a'); RR(-21, 0, 42, 8, 3, '#e29a6d');
  });

  /* night city */
  def('bldg', 176, { ft: 160, col: [6, 5, 11, 4], vn: 4, hot: [0, -10, 120] }, (k, v) => {
    RR(-70, -160, 140, 320, 3, sh(k, -0.5)); RR(-76, -166, 152, 12, 2, sh(k, -0.35));
    for (let r = 0; r < 8; r++) for (let c = 0; c < 3; c++) { const lit = ((r * 3 + c) * 7 + v * 5 + r * c * (v + 1)) % 3 !== 0; RR(-52 + c * 38, -140 + r * 36, 28, 22, 2, lit ? '#ffd96a' : '#2b2a40', true); }
  });
  def('car', 64, { ft: 30, col: [0, 5, 2, 3, 9, 6], vn: 2, asym: true }, (k, v) => {
    if (v) RR(-12, -42, 24, 10, 3, GOLD);
    P([-34, -6, -22, -32, 22, -32, 38, -6], k);
    P([-28, -8, -18, -27, -2, -27, -2, -8], '#9fd3f0'); P([4, -8, 4, -27, 18, -27, 30, -8], '#9fd3f0');
    RR(-60, -8, 120, 28, 10, k); E(55, 2, 4, 6, GOLD, 0, true); RR(-58, 0, 6, 8, 2, PAL[0], true);
    C(-32, 20, 12, '#2b2a33'); C(-32, 20, 4.5, '#c9ccd6', true); C(32, 20, 12, '#2b2a33'); C(32, 20, 4.5, '#c9ccd6', true);
  });
  def('tlight', 66, { ft: 62, vn: 3 }, (k, v) => {
    RR(-4, -8, 8, 70, 2, DARK); RR(-17, -62, 34, 58, 8, DARK);
    const cs = ['#e5484d', '#f6cd3b', '#4caf50'];
    for (let i = 0; i < 3; i++) { if (i === v) glow(0, -48 + i * 18, 16, 'rgba(255,240,180,.5)'); C(0, -48 + i * 18, 7, i === v ? cs[i] : '#4b4458', true); }
  });
  def('billboard', 86, { ft: 80, vn: 4, tx: 1, col: [0, 5, 6, 3] }, (k, v) => {
    RR(-6, -8, 12, 88, 2, '#5a5466');
    RR(-78, -66, 156, 62, 6, k); RR(-70, -58, 140, 46, 4, '#fbf7ee');
    TX(['24시', '세일', '맛집', '영업중'][v], 0, -34, 30, k === PAL[2] ? OL : k);
  });
  def('jet', 52, { col: [9, 0, 5], asym: true }, (k) => {
    P([-6, 0, -26, 26, -14, 26, 10, 2], '#c9ccd6'); P([-6, -4, -24, -24, -14, -24, 8, -4], '#dfe3ec');
    E(0, 0, 46, 10, k === PAL[9] ? WHITE : k); P([-40, -2, -50, -22, -34, -6], sh(k === PAL[9] ? PAL[5] : k, -0.15));
    for (let i = 0; i < 4; i++) C(-12 + i * 12, -2, 2.6, '#3d7ee6', true);
  });
  def('firework', 48, { col: [0, 2, 7, 4, 6], vn: 2 }, (k, v) => {
    const n = v ? 12 : 8;
    for (let i = 0; i < n; i++) { const a = i / n * TAU, c = Math.cos(a), s = Math.sin(a); S([c * 12, s * 12, c * 38, s * 38], 4.5, k); C(c * 43, s * 43, 4, sh(k, 0.45), true); }
    C(0, 0, 6, '#fff', true);
  });

  /* misc */
  def('cake', 60, { ft: 40, col: [7, 9, 6, 0, 4], cn: [1, 5] }, (k, v, o) => {
    const n = o.n || 3;
    E(0, 40, 58, 8, '#e3e1e8');
    for (let i = 0; i < n; i++) { const x = n === 1 ? 0 : -30 + i * 60 / (n - 1); RR(x - 4, -46, 8, 24, 2, PAL[(i * 2 + 1) % 8]); P([x - 4, -46, x, -58, x + 4, -46], '#f28a2e'); }
    RR(-50, -24, 100, 64, 10, '#f3e6cf'); RR(-50, 8, 100, 8, 0, k, true);
    RR(-52, -28, 104, 18, 8, k); for (let i = 0; i < 5; i++) C(-40 + i * 20, -10, 5, k, true);
  });
  def('cupcake', 34, { ft: 28, col: [7, 9, 8, 5], vn: 2 }, (k, v) => {
    P([-18, 0, 18, 0, 13, 28, -13, 28], '#e9b6c9'); S([-8, 2, -6, 26], 2, '#c98aa3'); S([8, 2, 6, 26], 2, '#c98aa3');
    blob([-10, -6, 12, 10, -6, 12, 0, -16, 13], k);
    if (!v) { C(0, -31, 6.5, PAL[0]); S([0, -37, 4, -44], 2, DGREEN); }
    else { const cs = [PAL[0], PAL[5], GOLD, PAL[3]]; for (let i = 0; i < 6; i++) { X.fillStyle = cs[i % 4]; X.fillRect(-14 + i * 5.5, -14 + (i % 3) * 5 - 6, 4, 2.5); } }
  });
  def('juice', 32, { ft: 28, col: [1, 0, 6, 3, 2], vn: 2 }, (k, v) => {
    if (v) SO([4, -8, 14, -38], 3, WHITE);
    P([-15, -12, 15, -12, 12, 26, -12, 26], k, true);
    P([-17, -26, 17, -26, 12, 28, -12, 28], 'rgba(225,242,255,.35)');
  });

  /* misc */
  def('scooter', 46, { ft: 40, col: [0, 5, 3, 7], asym: true }, (k) => {
    SO([30, 30, 22, -36], 5, k); SO([12, -36, 32, -36], 5, '#3b3542');
    RR(-34, 20, 62, 9, 4, k);
    C(-28, 34, 7, DARK); C(30, 34, 7, DARK);
  });

  /* bakery */
  def('showcase', 240, { ft: 90, col: [8, 7, 4, 5] }, (k) => {
    RR(-230, 20, 460, 70, 6, k); RR(-230, 46, 460, 8, 0, sh(k, 0.25), true);
    RR(-224, -70, 448, 92, 4, 'rgba(210,235,250,.42)'); S([-224, -24, 224, -24], 4, '#e3e1e8');
    X.fillStyle = 'rgba(255,255,255,.35)'; X.beginPath(); X.moveTo(-200, -66); X.lineTo(-170, -66); X.lineTo(-210, 16); X.lineTo(-222, 16); X.closePath(); X.fill();
  });
  def('croissant', 40, { ft: 16 }, () => {
    E(-26, 2, 11, 9, '#d9a25b', 0.6); E(26, 2, 11, 9, '#d9a25b', -0.6); E(-13, -6, 14, 13, '#e0a85e', 0.3); E(13, -6, 14, 13, '#e0a85e', -0.3); E(0, -10, 15, 15, '#e8b876');
  });
  def('donut', 34, { ft: 18, col: [7, 11, 2, 9, 1], vn: 2 }, (k, v) => {
    E(0, 0, 32, 18, '#d9a25b'); E(0, -3, 27, 13, k); E(0, -2, 9, 4.5, '#8a5a32');
    if (v) { const cs = [PAL[0], PAL[5], GOLD, PAL[3], '#fff']; for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; X.fillStyle = cs[i % 5]; X.fillRect(Math.cos(a) * 18 - 2, -3 + Math.sin(a) * 8 - 1, 5, 2.5); } }
  });
  def('baguettes', 50, { ft: 34, cn: [2, 4] }, (k, v, o) => {
    const n = o.n || 3;
    for (let i = 0; i < n; i++) { const x = -18 + i * 36 / (n - 1); X.save(); X.translate(x, -12); X.rotate((i - (n - 1) / 2) * 0.2); RR(-7, -34, 14, 52, 7, '#d9a25b'); S([-3, -24, 3, -18], 2, '#a8743a'); S([-3, -12, 3, -6], 2, '#a8743a'); X.restore(); }
    P([-34, 0, 34, 0, 26, 32, -26, 32], '#b5793f'); S([-30, 10, 30, 10], 2, '#8a5a32'); S([-28, 20, 28, 20], 2, '#8a5a32');
  });
  def('pie', 46, { ft: 16, vn: 2, col: [0, 6, 1] }, (k, v) => {
    E(0, 6, 44, 14, '#c9ccd6'); E(0, 0, 38, 12, '#d9a25b');
    if (v) { clipDo(() => X.ellipse(0, 0, 32, 9, 0, 0, TAU), () => { X.fillStyle = k; X.fillRect(-34, -10, 68, 20); X.fillStyle = '#e8b876'; for (let i = -3; i <= 3; i++) { X.fillRect(i * 10 - 2, -10, 5, 20); } X.fillRect(-34, -3, 68, 4); }); }
    else { E(0, -1, 32, 9, '#e8b876', 0, true); S([-12, -2, -4, 2], 2.5, '#a8743a'); S([4, -2, 12, 2], 2.5, '#a8743a'); }
  });
  def('slice', 38, { ft: 22, col: [7, 9, 8, 6], asym: true }, (k) => {
    P([-32, 0, 30, -14, 30, 22, -32, 22], '#f3e6cf'); P([-32, 8, 30, 2, 30, 8, -32, 14], k, true);
    P([-32, 0, 30, -14, 30, -20, -32, -6], k); C(20, -24, 7, PAL[0]);
  });


  /* gallery */
  def('painting', 90, { col: [2, 8, 11, 9], vn: 4, rt: 1 }, (k, v) => {
    RR(-72, -54, 144, 108, 4, k);
    clipDo(() => rrp(-60, -42, 120, 84, 2), () => {
      if (v === 0) { X.fillStyle = '#f6a96b'; X.fillRect(-62, -44, 124, 88); C(0, 4, 18, GOLD, true); X.fillStyle = '#3d7ee6'; X.fillRect(-62, 6, 124, 40); }
      else if (v === 1) { X.fillStyle = '#f6f2ea'; X.fillRect(-62, -44, 124, 88); C(-26, -6, 22, PAL[0]); RR(4, -32, 40, 40, 0, PAL[5]); P([-10, 42, 18, 2, 46, 42], GOLD); }
      else if (v === 2) { X.fillStyle = '#cfe8f5'; X.fillRect(-62, -44, 124, 88); P([-62, 44, -20, -22, 6, 14, 28, -8, 62, 44], '#5aa36a'); P([-28, -12, -20, -22, -12, -12], WHITE, true); }
      else { X.fillStyle = '#5b4a6e'; X.fillRect(-62, -44, 124, 88); E(0, 40, 32, 22, PAL[6]); C(0, -4, 18, SKIN); X.beginPath(); X.arc(0, -8, 19, Math.PI, 0); X.closePath(); F('#3b2a24'); }
    });
    X.beginPath(); rrp(-60, -42, 120, 84, 2); ink();
  });
  def('statue', 82, { ft: 78, col: [9, 2, 10, 4, 7], vn: 3 }, (k, v) => {
    RR(-30, 10, 60, 64, 3, '#e3e1e8'); RR(-36, 4, 72, 10, 3, '#f6f2ea'); RR(-36, 70, 72, 8, 2, '#c9ccd6');
    if (v === 0) { C(0, -26, 28, k); E(-9, -36, 8, 6, 'rgba(255,255,255,.45)', -0.5, true); }
    else if (v === 1) P([-26, 4, 0, -62, 26, 4], k);
    else RG(0, -28, 22, 12, k);
  });
  def('rope2', 80, { ft: 34, col: [0, 6, 5] }, (k) => {
    E(-67, 32, 12, 4, GOLD); E(67, 32, 12, 4, GOLD);
    RR(-72, -30, 10, 62, 3, GOLD); RR(62, -30, 10, 62, 3, GOLD);
    Qd(-67, -24, 0, 12, 67, -24, 7, k, true);
    C(-67, -32, 7, GOLD); C(67, -32, 7, GOLD);
  });


  /* rainy street */
  def('umbr', 52, { ft: 46, col: [0, 5, 2, 3, 6, 7], pn: 3 }, (k, v, o) => {
    S([0, -24, 0, 34], 3.5, '#5a5466'); RG(-7, 34, 7, 3.5, '#5a5466', 0, Math.PI);
    pfill(() => { X.moveTo(-48, -14); X.quadraticCurveTo(0, -76, 48, -14); X.quadraticCurveTo(40, -22, 32, -14); X.quadraticCurveTo(24, -22, 16, -14); X.quadraticCurveTo(8, -22, 0, -14); X.quadraticCurveTo(-8, -22, -16, -14); X.quadraticCurveTo(-24, -22, -32, -14); X.quadraticCurveTo(-40, -22, -48, -14); X.closePath(); }, k, o.p);
    C(0, -46, 3.5, k);
  });
  def('boots', 38, { ft: 30, col: [2, 0, 5, 3, 7], vn: 2 }, (k, v) => {
    for (const ox of [-18, 14]) { P([ox - 12, -26, ox + 4, -26, ox + 4, 16, ox + 18, 18, ox + 18, 30, ox - 12, 30], k); if (v) RR(ox - 12, -26, 16, 8, 2, WHITE, true); RR(ox - 12, 24, 30, 6, 2, sh(k, -0.3), true); }
  });
  def('mailbox', 54, { ft: 50, col: [0, 5, 3], vn: 2 }, (k, v) => {
    RR(-6, 0, 12, 50, 2, '#5a5466');
    RR(-26, -38, 52, 42, 12, k); RR(-15, -26, 30, 6, 2, OL, true);
    if (v) { X.save(); X.translate(0, -26); X.rotate(-0.15); RR(-10, -16, 22, 16, 1, WHITE); S([-10, -16, 1, -8, 12, -16], 1.5, METAL); X.restore(); }
    SO([26, -32, 34, -32, 34, -46], 3, PAL[0]);
  });
  def('busstop', 86, { ft: 82, vn: 4, tx: 1 }, (k, v) => {
    RR(-4, -40, 8, 122, 2, METAL); C(0, -52, 30, '#3d7ee6'); C(0, -52, 23, WHITE);
    TX(['12', '37', '5', '61'][v], 0, -51, 26, OL, 1);
  });
  def('snail', 36, { ft: 16, col: [8, 1, 2, 7], asym: true }, (k) => {
    S([24, 2, 30, -16], 2.5, OL); S([28, 2, 38, -12], 2.5, OL); C(30, -16, 2.5, OL, true); C(38, -12, 2.5, OL, true);
    E(2, 10, 32, 7, '#c9b48a');
    C(-4, -6, 19, k); X.beginPath(); X.arc(-4, -6, 11, 0, 5); ink(); X.beginPath(); X.arc(-4, -6, 5, 0, 5); ink();
  });

  /* garden */
  def('gnome', 50, { ft: 44, col: [0, 5, 3, 6], vn: 2, asym: true }, (k, v) => {
    SO([28, 40, 32, -6], 3, WOOD); P([24, 40, 36, 40, 38, 28, 22, 28], METAL);
    RR(-16, 32, 14, 12, 4, '#6b4423'); RR(2, 32, 14, 12, 4, '#6b4423');
    RR(-18, 0, 36, 38, 10, k === PAL[3] ? PAL[5] : PAL[3]);
    if (v) P([-12, -2, 12, -2, 0, 30], WHITE); else P([-12, -2, 12, -2, 0, 12], WHITE);
    C(0, -8, 10, SKIN); C(0, -4, 3.5, '#f283a0', true);
    P([-16, -12, 16, -12, 6, -46], k);
  });
  def('bhouse', 58, { ft: 54, col: [0, 5, 3, 8, 2], vn: 2 }, (k, v) => {
    RR(-5, 0, 10, 54, 2, WOOD);
    RR(-22, -32, 44, 38, 3, k); P([-30, -30, 0, -54, 30, -30], '#7a3b2e');
    C(0, -15, 9, '#2b2233');
    if (v) { C(0, -16, 7.5, GOLD); C(2, -18, 1.8, OL, true); P([6, -16, 12, -14, 6, -12], '#f28a2e', true); }
    RR(-3, -4, 6, 4, 1, WOOD, true);
  });
  def('bee', 32, { asym: true }, () => {
    E(-6, -14, 10, 8, 'rgba(230,245,255,.9)', -0.4); E(6, -15, 10, 8, 'rgba(230,245,255,.9)', 0.4);
    P([-20, 0, -30, 0, -20, 4], OL);
    E(0, 0, 20, 13, GOLD);
    clipDo(() => X.ellipse(0, 0, 20, 13, 0, 0, TAU), () => { X.fillStyle = '#2b2233'; X.fillRect(-10, -14, 6, 28); X.fillRect(2, -14, 6, 28); });
    X.beginPath(); X.ellipse(0, 0, 20, 13, 0, 0, TAU); ink(); eye(14, -3, 2.4);
  });
  def('wbarrow', 64, { ft: 30, col: [0, 5, 3, 2], asym: true }, (k) => {
    SO([-62, -16, -12, 4], 4, '#7a4f2c'); SO([-20, 6, -24, 28], 4, '#5a5466');
    P([-32, -22, 46, -22, 32, 14, -22, 14], k); S([-26, -14, 40, -14], 2, sh(k, 0.3));
    C(30, 20, 12, DARK); C(30, 20, 4, '#c9ccd6', true);
  });
  def('ladybug', 38, { ft: 18, cn: [2, 6] }, (k, v, o) => {
    C(28, 0, 10, '#2b2233'); C(30, -4, 2, '#fff', true);
    E(0, 0, 30, 20, PAL[0]); S([0, -20, 0, 20], 2.5, OL);
    const sp = [[-12, -8], [12, -8], [-14, 8], [14, 8], [-22, 0], [22, 0]], n = o.n || 3;
    for (let i = 0; i < n; i++) C(sp[i][0], sp[i][1], 5, '#2b2233', true);
  });

  /* parking lot · construction site */
  def('cone', 34, { ft: 30, col: [1, 0, 2], vn: 2 }, (k, v) => {
    P([-8, -30, 8, -30, 22, 24, -22, 24], k);
    if (v) { P([-12, -12, 12, -12, 15, -2, -15, -2], WHITE, true); P([-17, 6, 17, 6, 19, 14, -19, 14], WHITE, true); }
    else P([-14, -4, 14, -4, 17, 6, -17, 6], WHITE, true);
    RR(-30, 22, 60, 9, 3, DARK);
  });
  def('pmeter', 62, { ft: 58, vn: 4, tx: 1 }, (k, v) => {
    RR(-6, 0, 12, 58, 2, '#5a5466');
    RR(-30, -60, 60, 62, 8, '#3d7ee6'); RR(-22, -52, 44, 24, 4, '#163447');
    TX(['P1', 'P2', 'B1', 'B2'][v], 0, -40, 20, '#7fe3c1', 1);
    RR(-16, -20, 32, 7, 3, DARK, true); C(14, -6, 4, GOLD, true);
  });
  signType('psign', ['주차장', '출구', '만차', '입구'], [5, 3, 0, 6]);
  def('barrier', 66, { ft: 34, col: [1, 0, 2], vn: 2, asym: true }, (k, v) => {
    RR(-54, -10, 8, 44, 2, DARK); RR(46, -10, 8, 44, 2, DARK);
    RR(-64, 28, 28, 7, 2, DARK); RR(36, 28, 28, 7, 2, DARK);
    clipDo(() => rrp(-62, -30, 124, 26, 4), () => { X.fillStyle = WHITE; X.fillRect(-64, -32, 128, 30); X.fillStyle = k; for (let x = -80; x < 80; x += 30) { X.beginPath(); X.moveTo(x, -4); X.lineTo(x + 15, -4); X.lineTo(x + 31, -30); X.lineTo(x + 16, -30); X.closePath(); X.fill(); } });
    X.beginPath(); rrp(-62, -30, 124, 26, 4); ink();
    if (v) { C(-54, -38, 6, GOLD); glow(-54, -38, 16, 'rgba(255,230,140,.6)'); }
  });
  def('bricks', 46, { ft: 30, cn: [2, 6] }, (k, v, o) => {
    const n = o.n || 3; let i = 0;
    for (let row = 0; row < 3 && i < n; row++) for (let c = 0; c < 3 - row && i < n; c++, i++) RR(-42 + row * 14 + c * 28, 14 - row * 18, 26, 16, 2, '#c0573e');
  });
  def('crane', 230, { ft: 222, col: [2, 1], vn: 2, hot: [120, -60, 70] }, (k, v) => {
    RR(-50, 206, 100, 16, 3, DARK);
    RR(-16, -170, 32, 378, 2, k);
    X.lineWidth = 3; X.strokeStyle = sh(k, -0.35); for (let y = -160; y < 200; y += 32) { X.beginPath(); X.moveTo(-14, y); X.lineTo(14, y + 32); X.moveTo(14, y); X.lineTo(-14, y + 32); X.stroke(); }
    RR(-90, -190, 270, 22, 2, k); RR(-120, -196, 40, 34, 3, '#5a5466');
    RR(-14, -168, 40, 30, 3, '#5a6c80');
    S([120, -168, 120, v ? -60 : -100], 2.5, OL);
    if (v) { RR(92, -60, 56, 36, 3, '#9b6332'); S([92, -46, 148, -46], 2, sh('#9b6332', -0.3)); }
    else { RG(120, -92, 8, 3, METAL, 0, Math.PI); }
  });
  def('hardhat', 34, { ft: 18, col: [2, 1, 9, 5], vn: 2 }, (k, v) => {
    X.beginPath(); X.arc(0, 4, 26, Math.PI, 0); X.closePath(); F(k);
    RR(-34, 2, 68, 9, 4, sh(k, -0.15));
    if (v) RR(-4, -22, 8, 24, 2, sh(k, -0.3), true); else C(0, -8, 6, '#3d7ee6', true);
  });

  /* hospital · bank */
  def('wheelchair', 52, { ft: 46, col: [5, 0, 11], asym: true }, (k) => {
    RG(-6, 22, 22, 4, '#5a5466');
    SO([-24, -40, -22, 0, 26, 0, 30, 32], 4, METAL);
    RR(-22, -12, 44, 12, 4, k); RR(-24, -44, 10, 34, 4, k);
    C(32, 38, 6, DARK); SO([26, 0, 40, 10], 3, METAL);
  });
  def('cooler', 58, { ft: 54, col: [5, 4], vn: 2 }, (k, v) => {
    RR(-24, -6, 48, 60, 5, WHITE); RR(-10, 14, 20, 8, 2, DARK, true);
    C(-8, 6, 3, PAL[0], true); C(8, 6, 3, PAL[5], true);
    RR(-20, -56, 40, 50, 12, 'rgba(160,210,240,.55)');
    clipDo(() => rrp(-20, -56, 40, 50, 12), () => { X.fillStyle = sh(k, 0.35); X.fillRect(-22, v ? -26 : -50, 44, 60); });
    X.beginPath(); rrp(-20, -56, 40, 50, 12); ink();
  });
  signType('hsign', ['접수', '수납', '약국', '진료실'], [5, 4, 3, 0]);
  signType('banksign', ['상담', '입금', '대출', '환전'], [5, 3, 11, 8]);
  def('atm', 72, { ft: 68, vn: 4, tx: 1 }, (k, v) => {
    RR(-40, -68, 80, 136, 8, '#c9ccd6'); RR(-30, -56, 60, 40, 4, '#163447');
    TX(['ATM', '출금', '입금', '조회'][v], 0, -36, 18, '#7fe3c1');
    RR(-30, -6, 60, 26, 3, '#9aa3b5');
    for (let r = 0; r < 2; r++) for (let c = 0; c < 4; c++) RR(-26 + c * 14, -2 + r * 11, 10, 7, 1, DARK, true);
    RR(-20, 34, 40, 6, 2, DARK, true);
  });
  def('coins', 36, { ft: 22, cn: [2, 6] }, (k, v, o) => {
    const n = o.n || 3, h = Math.ceil(n / 2);
    for (let i = 0; i < h; i++) E(-12, 16 - i * 8, 13, 5, GOLD);
    for (let i = 0; i < n - h; i++) E(14, 16 - i * 8, 13, 5, '#c9ccd6');
  });

  /* wine bar */
  def('wine', 46, { ft: 42, col: [0, 6, 3, 11], vn: 2 }, (k, v) => {
    const g = sh(k, -0.45);
    P([-5, -44, 5, -44, 5, -22, 13, -10, 13, 42, -13, 42, -13, -10, -5, -22], g);
    RR(-6, -46, 12, 8, 2, v ? GOLD : PAL[0]);
    if (v) RR(-11, 4, 22, 20, 2, '#f3e6cf'); else E(0, 14, 10, 12, '#f3e6cf');
    E(-7, -2, 2.5, 12, 'rgba(255,255,255,.4)', 0, true);
  });
  def('wglass', 34, { ft: 32, col: [0, 2, 7], vn: 2 }, (k, v) => {
    S([0, 2, 0, 28], 3, '#d8dde6'); E(0, 30, 12, 3.5, '#d8dde6');
    X.beginPath(); X.moveTo(-15, -30); X.quadraticCurveTo(-17, 4, 0, 4); X.quadraticCurveTo(17, 4, 15, -30); X.closePath();
    X.fillStyle = 'rgba(220,235,245,.5)'; X.fill();
    clipDo(() => { X.moveTo(-15, -30); X.quadraticCurveTo(-17, 4, 0, 4); X.quadraticCurveTo(17, 4, 15, -30); X.closePath(); }, () => { X.fillStyle = k === PAL[0] ? '#8a1f2e' : k; X.fillRect(-20, v ? -8 : -22, 40, 40); });
    X.beginPath(); X.moveTo(-15, -30); X.quadraticCurveTo(-17, 4, 0, 4); X.quadraticCurveTo(17, 4, 15, -30); ink();
  });
  def('cheese', 38, { ft: 18, col: [2, 1], cn: [1, 4] }, (k, v, o) => {
    RR(-36, 4, 72, 14, 4, '#9b6332');
    P([-26, 4, 26, 4, 26, -18, -26, -2], k);
    const n = o.n || 2, hs = [[-14, -2], [6, -6], [16, -2], [-4, -1]];
    for (let i = 0; i < n; i++) C(hs[i][0], hs[i][1], 3.5, sh(k, -0.3), true);
  });
  def('stool', 58, { ft: 54, col: [0, 5, 11, 8] }, (k) => {
    SO([-14, -6, -22, 52], 4, DARK); SO([14, -6, 22, 52], 4, DARK); S([-18, 26, 18, 26], 3, DARK);
    E(0, -14, 26, 8, k); RR(-24, -14, 48, 8, 3, sh(k, -0.25));
  });

  /* laundromat */
  def('washer', 68, { ft: 62, col: [9, 10, 5], vn: 3 }, (k, v) => {
    RR(-50, -62, 100, 124, 8, k); RR(-50, -62, 100, 26, 6, sh(k, -0.12));
    C(-30, -49, 5, PAL[3], true); RR(-14, -54, 40, 10, 3, '#163447', true);
    C(0, 12, 34, '#9aa3b5'); C(0, 12, 26, '#2f3d52');
    clipDo(() => X.arc(0, 12, 26, 0, TAU), () => {
      if (v === 1) { blob([-8, 18, 12, 10, 8, 11, -2, 24, 9], PAL[0]); E(6, 22, 9, 6, PAL[5]); }
      else if (v === 2) { X.fillStyle = 'rgba(255,255,255,.8)'; for (let i = 0; i < 8; i++) { X.beginPath(); X.arc(-16 + (i * 13) % 32, 4 + (i * 7) % 24, 4 + i % 3, 0, TAU); X.fill(); } }
    });
    E(-10, 2, 7, 4, 'rgba(255,255,255,.3)', -0.6, true);
  });
  def('detergent', 34, { ft: 30, col: [1, 5, 3, 6, 0], vn: 2, asym: true }, (k, v) => {
    RR(-20, -22, 40, 52, 6, k); RR(-10, -32, 14, 12, 3, sh(k, -0.3));
    SO([14, -16, 22, -8, 22, 10, 14, 16], 4, sh(k, -0.2));
    if (v) RR(-14, -6, 28, 20, 3, WHITE); else C(0, 4, 10, WHITE);
  });
  def('shirt', 46, { col: [0, 5, 3, 6, 9, 2], pn: 4, rt: 1 }, (k, v, o) => {
    S([0, -40, 0, -32], 2.5, METAL); RG(0, -44, 5, 2, METAL, Math.PI, TAU * 0.95);
    S([-30, -22, 0, -32, 30, -22], 3, METAL);
    const path = () => { X.moveTo(-14, -30); X.lineTo(-38, -16); X.lineTo(-30, 0); X.lineTo(-20, -6); X.lineTo(-20, 38); X.lineTo(20, 38); X.lineTo(20, -6); X.lineTo(30, 0); X.lineTo(38, -16); X.lineTo(14, -30); X.quadraticCurveTo(0, -20, -14, -30); X.closePath(); };
    pfill(path, k, o.p);
  });
  def('folded', 36, { ft: 22, col: [0, 5, 3, 6, 9, 7], cn: [2, 4] }, (k, v, o) => {
    const n = o.n || 3; for (let i = 0; i < n; i++) RR(-30, 10 - i * 12, 60, 12, 3, i % 2 ? sh(k, 0.3) : k);
  });
  signType('lsign', ['세탁', '건조', '코인', '24시'], [5, 4, 6, 1]);

  /* hair salon */
  def('mirror', 66, { col: [2, 8, 11], vn: 2 }, (k, v) => {
    if (v) { RR(-46, -62, 92, 124, 10, k); RR(-36, -52, 72, 104, 6, '#cfe6f2'); }
    else { E(0, 0, 46, 62, k); E(0, 0, 36, 52, '#cfe6f2'); }
    S([-18, -30, -2, -44], 4, 'rgba(255,255,255,.7)'); S([-16, -14, 8, -38], 3, 'rgba(255,255,255,.5)');
  });
  def('salonchair', 64, { ft: 60, col: [0, 11, 5, 8], asym: true }, (k) => {
    RR(-30, 52, 60, 8, 3, METAL); RR(-5, 18, 10, 36, 2, METAL);
    RR(-30, -4, 60, 22, 8, k); RR(-28, -58, 50, 56, 12, k); RR(-30, -10, 14, 8, 3, sh(k, -0.3)); RR(16, -10, 18, 8, 3, sh(k, -0.3));
    SO([26, 14, 36, 34], 4, METAL);
  });
  def('scissors', 38, { col: [0, 5, 6, 11], asym: true }, (k) => {
    SO([-4, 4, 34, -18], 4, METAL); SO([-4, -4, 34, 18], 4, METAL);
    RG(-18, -10, 9, 4, k); RG(-18, 10, 9, 4, k); C(0, 0, 3, DARK, true);
  });
  def('spray', 36, { ft: 32, col: [5, 7, 3, 0], asym: true }, (k) => {
    RR(-14, -12, 28, 44, 6, k); RR(-6, -22, 12, 10, 2, DARK);
    P([-6, -34, 10, -34, 16, -28, 16, -22, -6, -22], DARK); RR(-10, 2, 20, 14, 3, 'rgba(255,255,255,.75)', true);
  });
  def('dryer', 38, { col: [0, 7, 11, 9], asym: true, rt: 1 }, (k) => {
    RR(-6, 2, 14, 34, 5, sh(k, -0.2));
    RR(-26, -20, 46, 26, 12, k); RR(18, -18, 12, 22, 3, DARK); C(-12, -7, 5, sh(k, 0.4), true);
  });

  /* night market */
  def('bowl', 38, { ft: 18, col: [0, 5, 11], vn: 2 }, (k, v) => {
    X.beginPath(); X.moveTo(-32, -6); X.quadraticCurveTo(-30, 20, 0, 20); X.quadraticCurveTo(30, 20, 32, -6); X.closePath(); F(k);
    E(0, -6, 32, 7, '#f0d89a'); S([-20, -8, -8, -6, 4, -9, 16, -6], 3, '#e3b85a');
    if (v) { E(10, -9, 9, 5, WHITE); C(10, -9, 3.5, GOLD, true); }
    S([18, -10, 34, -36], 3, '#9b6332'); S([22, -9, 40, -32], 3, '#9b6332');
  });
  def('skewer', 42, { cn: [2, 4], rt: 1, asym: true }, (k, v, o) => {
    S([-38, 0, 36, 0], 3, '#c58a4a');
    const n = o.n || 3; for (let i = 0; i < n; i++) RR(-30 + i * 17, -9, 14, 18, 4, i % 2 ? '#d9782c' : '#a8442a');
  });
  def('pills', 34, { ft: 16, col: [0, 5, 3, 6], cn: [2, 6] }, (k, v, o) => {
    RR(-30, -14, 60, 30, 5, '#dfe3ea');
    const n = o.n || 4; for (let i = 0; i < n; i++) { const x = -21 + (i % 3) * 21, y = i < 3 ? -4 : 7; RR(x - 7, y - 4, 14, 8, 4, k); }
  });

  /* ======================= places (themes) ======================= */
  function grad(c0, c1, y0, y1) { const g = X.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, c0); g.addColorStop(1, c1); X.fillStyle = g; X.fillRect(0, y0, W, y1 - y0); }
  function hills(R, y, amp, col, n) { X.beginPath(); X.moveTo(0, H); X.lineTo(0, y); const seg = W / n; for (let i = 0; i < n; i++) { const x0 = i * seg; X.quadraticCurveTo(x0 + seg / 2, y - amp * (0.5 + R()), x0 + seg, y + (R() - 0.5) * amp * 0.4); } X.lineTo(W, H); X.closePath(); X.fillStyle = col; X.fill(); }
  function dots(R, n, x0, y0, x1, y1, col, r0, r1) { X.fillStyle = col; for (let i = 0; i < n; i++) { X.beginPath(); X.arc(x0 + R() * (x1 - x0), y0 + R() * (y1 - y0), r0 + R() * (r1 - r0), 0, TAU); X.fill(); } }
  const SKY = [['#8fd0f5', '#dff3ff'], ['#f6a96b', '#fde2b0'], ['#9cc7ef', '#f3e6ff']];
  const pc = (R, t) => pick(R, TY[t].col || [0]);

  const THEMES = [
    { id: 'living', name: '거실', g: 'in',
      bg(v, R) {
        const wall = ['#efe2c8', '#cfe3d6', '#d7dceb', '#f0d5d5'][v % 4];
        X.fillStyle = wall; X.fillRect(0, 0, W, 440);
        X.fillStyle = 'rgba(0,0,0,.035)'; for (let x = 0; x < W; x += 56) X.fillRect(x, 0, 26, 430);
        X.fillStyle = '#b98250'; X.fillRect(0, 430, W, 230);
        X.strokeStyle = 'rgba(70,40,20,.35)'; X.lineWidth = 2;
        for (let y = 470; y < H; y += 48) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); const off = R() * 200; for (let x = off; x < W; x += 230) { X.beginPath(); X.moveTo(x, y - 48); X.lineTo(x, y); X.stroke(); } }
        X.fillStyle = WHITE; X.fillRect(0, 424, W, 14); X.fillStyle = 'rgba(0,0,0,.15)'; X.fillRect(0, 438, W, 4);
      },
      lay(R) {
        const wx = 150 + R() * 700, sx = 230 + R() * 540;
        const hx = wx < 500 ? wx + 230 + R() * (880 - wx - 230) : 120 + R() * (wx - 350);
        return { bv: ri(R, 4), props: [
          { t: 'window', x: wx, y: 190, sol: 1, pd: 1 },
          { t: 'shelf', x: hx, y: 262 },
          { t: 'rug', x: 500 + (R() - 0.5) * 200, y: 596, pd: 1 },
          { t: 'sofa', x: sx, y: 432, pd: 1 },
        ], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 256, y1: 256, ty: ['books', 'plant', 'vase', 'mug', 'apple', 'books'], n: [2, 3], s: [0.6, 0.72] },
          { x0: 20, x1: 980, y0: 18, y1: 360, fl: 1, ty: ['frame', 'clock', 'frame', 'star'], n: [3, 4], s: [0.62, 0.82], no: [[hx - 120, 140, hx + 120, 275]] },
          { x0: sx - 150, x1: sx + 150, y0: 440, y1: 444, ty: ['cushion', 'cushion', 'cat', 'books'], n: [2, 3], s: [0.66, 0.8] },
          { x0: 10, x1: 990, y0: 540, y1: 652, ty: ['plant', 'cat', 'ball', 'books', 'gift', 'lamp', 'vase', 'tv', 'ball', 'plant'], n: [7, 9], s: [0.66, 0.9] },
        ] };
      } },
    { id: 'camp', name: '숲속 캠핑', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 420);
        hills(R, 330, 120, '#8aa6c8', 4); hills(R, 380, 70, '#6f9a7a', 5);
        X.fillStyle = '#7cc35f'; X.fillRect(0, 400, W, 260); X.fillStyle = '#6cb352'; X.fillRect(0, 400, W, 14);
        X.strokeStyle = '#4f9a3e'; X.lineWidth = 3; for (let i = 0; i < 40; i++) { const x = R() * W, y = 430 + R() * 220; X.beginPath(); X.moveTo(x - 5, y); X.lineTo(x, y - 9); X.lineTo(x + 5, y); X.stroke(); }
      },
      lay(R) {
        const tx = 200 + R() * 600;
        return { bv: ri(R, 3), props: [{ t: 'tent', x: tx, y: 412, sol: 1, pd: 1 }], zones: [
          { x0: 30, x1: 970, y0: 16, y1: 170, fl: 1, nx: 1, ty: ['sun'], n: [1, 1], s: [0.66, 0.78] },
          { x0: 10, x1: 990, y0: 14, y1: 260, fl: 1, ty: ['cloud', 'cloud', 'bird', 'bird'], n: [3, 5], s: [0.58, 0.8] },
          { x0: 10, x1: 990, y0: 430, y1: 470, ty: ['pine', 'tree', 'pine'], n: [2, 3], s: [0.58, 0.72] },
          { x0: 10, x1: 990, y0: 520, y1: 652, ty: ['fire', 'mushroom', 'log', 'backpack', 'lantern', 'rabbit', 'flower', 'sign', 'butterfly', 'mushroom', 'flower'], n: [8, 10], s: [0.7, 0.92] },
        ] };
      } },
    { id: 'market', name: '시장', g: 'out',
      bg(v, R) {
        grad('#9ed8f0', '#dff3ff', 0, 160);
        const cs = ['#e9c9a0', '#d9b3a0', '#c9d3b8', '#e3d0b0'];
        for (let x = 0; x < W; x += 200) { X.fillStyle = cs[(x / 200 + v) % 4]; X.fillRect(x, 60 + R() * 30, 200, 420); X.fillStyle = 'rgba(80,60,40,.25)'; X.fillRect(x + 50, 140, 40, 50); X.fillRect(x + 120, 140, 40, 50); }
        X.fillStyle = '#d6c7aa'; X.fillRect(0, 470, W, 190);
        X.strokeStyle = 'rgba(90,70,40,.25)'; X.lineWidth = 2; for (let y = 500; y < H; y += 40) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
        X.beginPath(); X.moveTo(0, 30); X.quadraticCurveTo(500, 90, W, 30); X.lineWidth = 2; X.strokeStyle = '#5a4a3a'; X.stroke();
        for (let i = 0; i < 14; i++) { const t = (i + 0.5) / 14, x = t * W, y = 30 + 60 * 2 * t * (1 - t) * 1; X.beginPath(); X.moveTo(x - 16, y); X.lineTo(x + 16, y); X.lineTo(x, y + 26); X.closePath(); X.fillStyle = PAL[(i * 3 + v) % 8]; X.fill(); }
      },
      lay(R) {
        const a = 245 + (R() - 0.5) * 60, b = 755 + (R() - 0.5) * 60;
        return { bv: ri(R, 4), props: [{ t: 'stall', x: a, y: 392, pd: 1 }, { t: 'stall', x: b, y: 392, pd: 1 }], zones: [
          { x0: a - 146, x1: a + 146, y0: 402, y1: 404, ty: ['crate', 'melon', 'banana', 'basket', 'apple', 'carrot', 'pricetag', 'fish', 'apple'], n: [3, 4], s: [0.6, 0.74] },
          { x0: b - 146, x1: b + 146, y0: 402, y1: 404, ty: ['crate', 'melon', 'banana', 'basket', 'apple', 'carrot', 'pricetag', 'fish', 'apple'], n: [3, 4], s: [0.6, 0.74] },
          { x0: 10, x1: 990, y0: 540, y1: 652, ty: ['crate', 'basket', 'cat', 'ball', 'melon', 'basket', 'flower', 'apple'], n: [5, 7], s: [0.66, 0.88] },
          { x0: 10, x1: 990, y0: 70, y1: 200, fl: 1, ty: ['bird', 'balloon'], n: [1, 3], s: [0.58, 0.72] },
        ] };
      } },
    { id: 'kitchen', name: '부엌', g: 'in',
      bg(v, R) {
        const t = ['#e7f0ee', '#f4ead8', '#e8e6f4', '#f6e3e0'][v % 4];
        X.fillStyle = t; X.fillRect(0, 0, W, 500);
        X.strokeStyle = 'rgba(80,80,100,.16)'; X.lineWidth = 2; for (let y = 120; y < 490; y += 40) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); } for (let x = 0; x < W; x += 40) { X.beginPath(); X.moveTo(x, 120); X.lineTo(x, 490); X.stroke(); }
        X.fillStyle = '#c58a4a'; X.fillRect(0, 0, W, 112); X.strokeStyle = 'rgba(60,30,10,.4)'; X.lineWidth = 3;
        for (let x = 0; x < W; x += 125) { X.strokeRect(x + 8, 8, 109, 96); X.fillStyle = '#e3ae45'; X.fillRect(x + 100, 70, 8, 22); }
        X.fillStyle = '#e8e2d6'; X.fillRect(0, 488, W, 24); X.fillStyle = 'rgba(0,0,0,.12)'; X.fillRect(0, 512, W, 6);
        X.fillStyle = '#b07a45'; X.fillRect(0, 518, W, 142); X.strokeStyle = 'rgba(60,30,10,.4)';
        for (let x = 0; x < W; x += 166) { X.strokeRect(x + 10, 530, 146, 124); X.fillStyle = '#e3ae45'; X.fillRect(x + 70, 542, 26, 7); }
      },
      lay(R) {
        const wx = 150 + R() * 700;
        const hx = wx < 500 ? wx + 230 + R() * (880 - wx - 230) : 120 + R() * (wx - 350);
        return { bv: ri(R, 4), props: [{ t: 'window', x: wx, y: 232, sol: 1, pd: 1, s: 0.95 }, { t: 'shelf', x: hx, y: 268 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 262, y1: 262, ty: ['jar', 'mug', 'plates', 'plant', 'jar', 'books'], n: [2, 3], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 124, y1: 380, fl: 1, ty: ['clock', 'frame'], n: [1, 2], s: [0.58, 0.74], no: [[hx - 120, 150, hx + 120, 282]] },
          { x0: 10, x1: 990, y0: 492, y1: 494, ty: ['pot', 'pan', 'kettle', 'plates', 'jar', 'bread', 'mug', 'apple', 'carrot', 'melon', 'banana', 'plant', 'jar', 'mug'], n: [8, 10], s: [0.72, 0.95] },
        ] };
      } },
    { id: 'winter', name: '겨울 마을', g: 'out',
      bg(v, R) {
        const g = [['#1d2a55', '#4a5d99'], ['#bfe0f5', '#eef8ff'], ['#f3b38a', '#c9d6f0']][v % 3]; grad(g[0], g[1], 0, 440);
        if (v % 3 === 0) dots(R, 80, 0, 0, W, 380, 'rgba(255,255,255,.8)', 0.8, 2);
        hills(R, 380, 80, '#dfe9f6', 4);
        X.fillStyle = '#f3f6fb'; X.fillRect(0, 440, W, 220); hills(R, 450, 30, '#f8fbff', 6);
        X.fillStyle = 'rgba(120,150,200,.18)'; for (let i = 0; i < 8; i++) { X.beginPath(); X.ellipse(R() * W, 500 + R() * 150, 60 + R() * 60, 8, 0, 0, TAU); X.fill(); }
      },
      lay(R) {
        const a = 180 + R() * 150, b = 600 + R() * 220;
        return { bv: ri(R, 3), props: [{ t: 'house', x: a, y: 386, sol: 1, pd: 1, s: 0.95 }, { t: 'house', x: b, y: 386, sol: 1, pd: 1, s: 0.95 }], zones: [
          { x0: 10, x1: 990, y0: 14, y1: 260, fl: 1, ty: ['flake', 'flake', 'flake', 'bird', 'star', 'flake'], n: [5, 7], s: [0.66, 0.95] },
          { x0: 10, x1: 990, y0: 520, y1: 652, ty: ['snowman', 'sled', 'pine', 'gift', 'mitten', 'penguin', 'lamppost', 'pine', 'snowman', 'mitten', 'penguin'], n: [7, 10], s: [0.6, 0.84] },
        ] };
      } },
    { id: 'beach', name: '바닷가', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 260);
        grad('#3fb6d6', '#1f86b0', 250, 420);
        X.strokeStyle = 'rgba(255,255,255,.5)'; X.lineWidth = 3; for (let i = 0; i < 12; i++) { const x = R() * W, y = 270 + R() * 120; X.beginPath(); X.moveTo(x, y); X.quadraticCurveTo(x + 15, y - 6, x + 30, y); X.stroke(); }
        X.beginPath(); X.moveTo(0, H); X.lineTo(0, 418); for (let x = 0; x <= W; x += 40) X.lineTo(x, 414 + Math.sin(x / 60) * 8); X.lineTo(W, H); X.closePath(); X.fillStyle = '#f0d9a0'; X.fill(); X.lineWidth = 4; X.strokeStyle = '#ffffff'; X.stroke();
        dots(R, 50, 0, 430, W, H, 'rgba(170,130,60,.3)', 1.5, 3);
      },
      lay(R) {
        const left = R() < 0.5;
        return { bv: ri(R, 3), props: [{ t: 'palm', x: left ? 110 : 890, y: 380, f: left ? 0 : 1 }, { t: 'towel', x: 300 + R() * 400, y: 610, pd: 1 }], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 170, fl: 1, nx: 1, ty: ['sun'], n: [1, 1], s: [0.62, 0.76] },
          { x0: 10, x1: 990, y0: 14, y1: 230, fl: 1, ty: ['cloud', 'cloud', 'bird', 'bird'], n: [3, 5], s: [0.56, 0.8] },
          { x0: 10, x1: 990, y0: 392, y1: 400, ty: ['boat'], n: [1, 2], s: [0.6, 0.7] },
          { x0: 10, x1: 990, y0: 470, y1: 652, ty: ['bucket', 'castle', 'crab', 'shell', 'starfish', 'ball', 'umbrella', 'shell', 'crab', 'bucket'], n: [8, 10], s: [0.64, 0.86] },
        ] };
      } },
    { id: 'farm', name: '농장', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 420);
        hills(R, 360, 80, '#9fd17d', 4);
        X.fillStyle = '#8ccf6a'; X.fillRect(0, 410, W, 250);
        X.fillStyle = '#e8d3a8'; X.beginPath(); X.moveTo(440, 660); X.quadraticCurveTo(520, 520, 470, 430); X.lineTo(500, 430); X.quadraticCurveTo(580, 540, 560, 660); X.closePath(); X.fill();
        for (let x = 10; x < W; x += 70) { X.fillStyle = '#c99a62'; X.fillRect(x, 432, 10, 46); }
        X.fillStyle = '#d8ad74'; X.fillRect(0, 442, W, 8); X.fillRect(0, 462, W, 8);
      },
      lay(R) {
        const left = R() < 0.5, bx = left ? 170 + R() * 70 : 830 - R() * 70;
        return { bv: ri(R, 3), props: [{ t: 'barn', x: bx, y: 372, sol: 1, pd: 1, s: 0.9 }], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 160, fl: 1, nx: 1, ty: ['sun'], n: [0, 1], s: [0.62, 0.76] },
          { x0: 10, x1: 990, y0: 14, y1: 240, fl: 1, ty: ['cloud', 'cloud', 'bird', 'bird'], n: [3, 5], s: [0.56, 0.8] },
          { x0: 10, x1: 990, y0: 500, y1: 652, ty: ['chicken', 'pig', 'sheep', 'cow', 'hay', 'flower', 'chicken', 'tree', 'pig', 'sheep', 'flower'], n: [8, 11], s: [0.62, 0.84] },
        ] };
      } },
    /* ----- round 12: 20 more places ----- */
    { id: 'classroom', name: '교실', g: 'in',
      bg(v, R) {
        const wall = ['#f1e6cc', '#d6ead9', '#dfe2f0', '#f3dcd0'][v % 4];
        X.fillStyle = wall; X.fillRect(0, 0, W, 470);
        X.fillStyle = 'rgba(0,0,0,.05)'; X.fillRect(0, 330, W, 140);
        X.fillStyle = WHITE; X.fillRect(0, 326, W, 8);
        X.fillStyle = '#c99a62'; X.fillRect(0, 470, W, 190);
        X.strokeStyle = 'rgba(80,50,20,.3)'; X.lineWidth = 2;
        for (let y = 500; y < H; y += 40) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
        for (let x = R() * 80; x < W; x += 120) { X.beginPath(); X.moveTo(x, 470); X.lineTo(x - 60, H); X.stroke(); }
        X.fillStyle = 'rgba(0,0,0,.15)'; X.fillRect(0, 470, W, 6);
      },
      lay(R) {
        const bx = 500 + (R() - 0.5) * 160, d1 = 190 + R() * 50, d2 = 810 - R() * 50, dy = 470;
        return { bv: ri(R, 4), props: [
          { t: 'chalkboard', x: bx, y: 172, s: 0.95, sol: 1, pd: 1 },
          { t: 'desk', x: d1, y: dy, pd: 1 }, { t: 'desk', x: d2, y: dy, pd: 1 },
        ], zones: [
          { x0: d1 - 98, x1: d1 + 98, y0: dy - 16, y1: dy - 16, ty: ['books', 'apple', 'globe', 'pencils', 'trophy', 'mug', 'plant', 'calendar'], n: [2, 3], s: [0.58, 0.7] },
          { x0: d2 - 98, x1: d2 + 98, y0: dy - 16, y1: dy - 16, ty: ['books', 'apple', 'globe', 'pencils', 'trophy', 'mug', 'plant', 'calendar'], n: [2, 3], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 12, y1: 320, fl: 1, ty: ['clock', 'frame', 'calendar', 'plane2', 'star', 'clock', 'frame'], n: [3, 5], s: [0.6, 0.8] },
          { x0: 10, x1: 990, y0: 572, y1: 652, ty: ['backpack', 'chair', 'ball', 'books', 'plant', 'backpack', 'globe', 'chair', 'trophy'], n: [5, 7], s: [0.62, 0.84] },
        ] };
      } },
    { id: 'library', name: '도서관', g: 'in',
      bg(v, R) {
        const wall = ['#eadcc0', '#d9e0cf', '#e6d4cc'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 500);
        X.fillStyle = 'rgba(0,0,0,.04)'; for (let x = 0; x < W; x += 40) X.fillRect(x, 0, 20, 500);
        X.fillStyle = '#9b6332'; X.fillRect(0, 500, W, 160);
        X.strokeStyle = 'rgba(50,25,10,.35)'; X.lineWidth = 2;
        for (let y = 530; y < H; y += 34) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); const off = R() * 160; for (let x = off; x < W; x += 200) { X.beginPath(); X.moveTo(x, y - 34); X.lineTo(x, y); X.stroke(); } }
        X.fillStyle = '#6b4423'; X.fillRect(0, 492, W, 12);
      },
      lay(R) {
        const a = 140 + R() * 40, b = 860 - R() * 40, tx = 500 + (R() - 0.5) * 80;
        return { bv: ri(R, 3), props: [
          { t: 'bookcase', x: a, y: 334, s: 0.95, sol: 1 }, { t: 'bookcase', x: b, y: 334, s: 0.95, sol: 1 },
          { t: 'table', x: tx, y: 560, s: 0.95, pd: 1 },
        ], zones: [
          { x0: 260, x1: 740, y0: 16, y1: 340, fl: 1, ty: ['clock', 'frame', 'painting', 'calendar', 'libsign', 'frame', 'clock'], n: [3, 5], s: [0.58, 0.74] },
          { x0: tx - 140, x1: tx + 140, y0: 560 - 22 * 0.95, y1: 560 - 22 * 0.95, ty: ['openbook', 'hourglass', 'books', 'magnifier', 'mug', 'globe', 'scroll', 'candles', 'plant'], n: [3, 4], s: [0.62, 0.74] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['books', 'cat', 'plant', 'backpack', 'libsign', 'books', 'globe', 'chair', 'lamp'], n: [4, 6], s: [0.6, 0.8], no: [[tx - 150, 540, tx + 150, 660]] },
        ] };
      } },
    { id: 'subway', name: '지하철', g: 'in',
      bg(v, R) {
        const wall = ['#e3e6ec', '#ece6dc', '#dde8e6'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 530);
        X.fillStyle = '#c9ced8'; X.fillRect(0, 0, W, 34); X.fillStyle = '#fffbe6'; for (let x = 60; x < W; x += 220) X.fillRect(x, 10, 120, 12);
        const tun = ['#1c2236', '#2a2238', '#1d2a2c'][v % 3];
        for (let i = 0; i < 4; i++) { const x = 20 + i * 245; RR(x, 80, 215, 150, 16, '#9aa3b5'); X.fillStyle = tun; X.beginPath(); rrp(x + 10, 90, 195, 130, 10); X.fill();
          X.fillStyle = 'rgba(255,230,150,.55)'; for (let j = 0; j < 3; j++) X.fillRect(x + 20 + R() * 160, 110 + R() * 90, 30 + R() * 30, 3); }
        X.fillStyle = '#8f96a3'; X.fillRect(0, 530, W, 130);
        X.fillStyle = 'rgba(255,255,255,.12)'; for (let i = 0; i < 50; i++) { X.beginPath(); X.arc(R() * W, 540 + R() * 120, 3, 0, TAU); X.fill(); }
        X.fillStyle = '#f2c94c'; for (const x of [12, 494, 980]) X.fillRect(x, 34, 9, 496);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [{ t: 'seats', x: 255, y: 466, s: 0.9 }, { t: 'seats', x: 745, y: 466, s: 0.9 }], zones: [
          { x0: 10, x1: 990, y0: 40, y1: 40, ty: ['strap'], n: [5, 8], s: [0.75, 0.92] },
          { x0: 30, x1: 970, y0: 236, y1: 396, fl: 1, ty: ['routemap', 'stsign', 'frame', 'clock', 'screen', 'routemap'], n: [3, 4], s: [0.58, 0.72] },
          { x0: 50, x1: 950, y0: 466 - 26 * 0.9, y1: 466 - 26 * 0.9, ty: ['bag', 'books', 'backpack', 'mug', 'cat', 'bag'], n: [2, 4], s: [0.55, 0.68], no: [[462, 300, 538, 470]] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['person', 'person', 'bag', 'person', 'umbr', 'backpack', 'person', 'bag'], n: [5, 7], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'oasis', name: '사막 오아시스', g: 'out',
      bg(v, R) {
        const g = [['#f9d79a', '#fdf0cf'], ['#9fd2ef', '#f8ecd0'], ['#f2a774', '#fbe0b2']][v % 3];
        grad(g[0], g[1], 0, 420);
        for (let i = 0; i < 2; i++) { const x = 150 + R() * 700, s = 70 + R() * 50; X.fillStyle = 'rgba(200,150,90,.55)'; X.beginPath(); X.moveTo(x - s, 400); X.lineTo(x, 400 - s * 0.9); X.lineTo(x + s, 400); X.closePath(); X.fill(); }
        hills(R, 400, 50, '#e8c27a', 4);
        X.fillStyle = '#efd39a'; X.fillRect(0, 430, W, 230); hills(R, 460, 26, '#f3dca8', 5);
        const px = 360 + R() * 280;
        X.fillStyle = '#7fcf8f'; X.beginPath(); X.ellipse(px, 528, 250, 62, 0, 0, TAU); X.fill();
        X.fillStyle = '#3fb6d6'; X.beginPath(); X.ellipse(px, 528, 220, 46, 0, 0, TAU); X.fill();
        X.strokeStyle = 'rgba(255,255,255,.6)'; X.lineWidth = 3; for (let i = 0; i < 5; i++) { const x = px - 150 + R() * 300, y = 515 + R() * 26; X.beginPath(); X.moveTo(x, y); X.quadraticCurveTo(x + 12, y - 5, x + 24, y); X.stroke(); }
        dots(R, 50, 0, 590, W, H, 'rgba(170,120,60,.3)', 1.5, 3);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 170, fl: 1, nx: 1, ty: ['sun'], n: [1, 1], s: [0.6, 0.74] },
          { x0: 10, x1: 990, y0: 14, y1: 250, fl: 1, ty: ['bird', 'cloud', 'bird'], n: [2, 4], s: [0.56, 0.76] },
          { x0: 10, x1: 990, y0: 440, y1: 480, ty: ['camel', 'tent', 'palm', 'camel', 'cactus'], n: [2, 3], s: [0.55, 0.66] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['cactus', 'amphora', 'lizard', 'rock', 'basket', 'reeds', 'melon', 'amphora', 'lizard'], n: [6, 8], s: [0.62, 0.84] },
        ] };
      } },
    { id: 'florist', name: '꽃집', g: 'in',
      bg(v, R) {
        const wall = ['#f6dfe4', '#dcefe3', '#f3ecd6'][v % 4 % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 480);
        X.fillStyle = 'rgba(255,255,255,.35)'; for (let x = 0; x < W; x += 60) for (let y = 20; y < 470; y += 60) { X.beginPath(); X.arc(x + ((y / 60) % 2) * 30, y, 5, 0, TAU); X.fill(); }
        for (let y = 480; y < H; y += 45) for (let x = 0; x < W; x += 45) { X.fillStyle = ((x + y) / 45) % 2 ? '#e9e2d6' : '#d6cdbf'; X.fillRect(x, y, 45, 45); }
        X.fillStyle = 'rgba(0,0,0,.12)'; X.fillRect(0, 480, W, 6);
      },
      lay(R) {
        const cx = 500 + (R() - 0.5) * 160, hx = cx < 500 ? 760 + R() * 100 : 140 + R() * 100;
        return { bv: ri(R, 3), props: [{ t: 'shelf', x: hx, y: 220 }, { t: 'counter', x: cx, y: 470, s: 0.86, pd: 1 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 214, y1: 214, ty: ['succ', 'plant', 'vase', 'flower', 'succ', 'jar'], n: [2, 3], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 14, y1: 320, fl: 1, ty: ['frame', 'clock', 'flowsign', 'painting', 'flowsign'], n: [2, 3], s: [0.58, 0.74], no: [[hx - 120, 110, hx + 120, 236]] },
          { x0: cx - 190, x1: cx + 190, y0: 470 - 32 * 0.86, y1: 470 - 32 * 0.86, ty: ['bouquet', 'vase', 'pricetag', 'basket', 'succ', 'tulips', 'wcan'], n: [3, 4], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['tulips', 'plant', 'wcan', 'bucket', 'cactus', 'tulips', 'flower', 'cat', 'basket', 'bouquet'], n: [6, 8], s: [0.6, 0.82] },
        ] };
      } },
    { id: 'night', name: '야경 도시', g: 'out',
      bg(v, R) {
        const g = [['#0e1330', '#2f3566'], ['#1d1238', '#5a3a6e'], ['#0b1c2c', '#2a4a5e']][v % 3];
        grad(g[0], g[1], 0, 520);
        dots(R, 90, 0, 0, W, 380, 'rgba(255,255,255,.7)', 0.8, 2);
        X.fillStyle = 'rgba(20,20,45,.7)'; for (let x = 0; x < W;) { const w = 50 + R() * 60, h = 80 + R() * 140; X.fillRect(x, 520 - h - 40, w, h + 40); x += w + 4; }
        X.fillStyle = '#5a5e70'; X.fillRect(0, 500, W, 34); X.fillStyle = '#353a4a'; X.fillRect(0, 534, W, 126);
        X.fillStyle = '#e3ae45'; for (let x = 20; x < W; x += 90) X.fillRect(x, 594, 46, 6);
        X.fillStyle = 'rgba(255,217,106,.08)'; for (let i = 0; i < 6; i++) X.fillRect(R() * W, 540, 30, 120);
      },
      lay(R) {
        const n = 3 + (R() < 0.5 ? 1 : 0), props = [], no = [];
        for (let i = 0; i < n; i++) { const s = 0.72 + R() * 0.3, x = (i + 0.5) * W / n + (R() - 0.5) * 40; props.push({ t: 'bldg', x, y: 500 - 160 * s, s, pd: 1 }); no.push([x - 76 * s, 500 - 330 * s, x + 76 * s, 520]); }
        return { bv: ri(R, 3), props, zones: [
          { x0: 30, x1: 970, y0: 14, y1: 150, fl: 1, nx: 1, ty: ['moon'], n: [0, 1], s: [0.62, 0.76], no },
          { x0: 10, x1: 990, y0: 14, y1: 340, fl: 1, ty: ['star', 'jet', 'firework', 'star', 'firework', 'balloon'], n: [3, 5], s: [0.58, 0.78], no },
          { x0: 10, x1: 990, y0: 586, y1: 652, ty: ['car', 'car', 'tlight', 'lamppost', 'billboard', 'cat', 'car', 'person', 'tlight'], n: [4, 6], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'bakery', name: '빵집', g: 'in',
      bg(v, R) {
        const wall = ['#f4e2c6', '#f1d6cf', '#e5e8d2'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 420);
        X.fillStyle = 'rgba(160,100,60,.08)'; for (let y = 0; y < 420; y += 30) for (let x = (y / 30 % 2) * 30; x < W; x += 60) X.fillRect(x, y, 30, 30);
        X.fillStyle = '#b07a45'; X.fillRect(0, 420, W, 240); X.fillStyle = WHITE; X.fillRect(0, 414, W, 10);
        X.strokeStyle = 'rgba(60,30,10,.3)'; X.lineWidth = 2; for (let x = 0; x < W; x += 50) { X.beginPath(); X.moveTo(x, 424); X.lineTo(x, H); X.stroke(); }
        X.fillStyle = '#d9875a'; X.beginPath(); X.moveTo(0, 0); for (let x = 0; x <= W; x += 50) { X.lineTo(x, 34); X.lineTo(x + 25, 46); } X.lineTo(W, 0); X.closePath(); X.fill();
      },
      lay(R) {
        const hx = R() < 0.5 ? 180 + R() * 80 : 820 - R() * 80;
        return { bv: ri(R, 3), props: [{ t: 'shelf', x: hx, y: 236 }, { t: 'showcase', x: 500, y: 520, s: 0.95, pd: 1 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 230, y1: 230, ty: ['bread', 'croissant', 'jar', 'baguettes', 'pie'], n: [2, 3], s: [0.56, 0.68] },
          { x0: 10, x1: 990, y0: 60, y1: 330, fl: 1, ty: ['clock', 'frame', 'bakesign', 'calendar', 'bakesign'], n: [2, 3], s: [0.58, 0.74], no: [[hx - 120, 120, hx + 120, 252]] },
          { x0: 290, x1: 710, y0: 520 - 70 * 0.95, y1: 520 - 70 * 0.95, ty: ['cake', 'pie', 'slice', 'donut', 'croissant', 'cupcake', 'pricetag', 'donut'], n: [3, 4], s: [0.58, 0.7] },
          { x0: 300, x1: 700, y0: 520 - 24 * 0.95, y1: 520 - 24 * 0.95, ty: ['donut', 'croissant', 'slice', 'cupcake', 'bread'], n: [3, 4], s: [0.52, 0.6] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['baguettes', 'basket', 'cat', 'plant', 'bread'], n: [2, 3], s: [0.6, 0.76], no: [[268, 400, 732, 660]] },
        ] };
      } },
    { id: 'gallery', name: '미술관', g: 'in',
      bg(v, R) {
        const wall = ['#f2efe8', '#e3e6ea', '#efe4dc'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 470);
        X.fillStyle = 'rgba(255,240,200,.35)'; for (let x = 100; x < W; x += 200) { X.beginPath(); X.moveTo(x - 20, 0); X.lineTo(x + 20, 0); X.lineTo(x + 110, 360); X.lineTo(x - 110, 360); X.closePath(); X.fill(); }
        X.fillStyle = '#3b3542'; for (let x = 100; x < W; x += 200) X.fillRect(x - 14, 0, 28, 10);
        X.fillStyle = '#d8d2c6'; X.fillRect(0, 456, W, 14);
        X.fillStyle = '#a9794a'; X.fillRect(0, 470, W, 190);
        X.strokeStyle = 'rgba(60,30,10,.3)'; X.lineWidth = 2; for (let y = 500; y < H; y += 30) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 30, y1: 380, fl: 1, ty: ['painting', 'painting', 'frame', 'painting', 'frame'], n: [4, 5], s: [0.6, 0.78] },
          { x0: 10, x1: 990, y0: 570, y1: 652, ty: ['statue', 'rope2', 'bench', 'person', 'plant', 'statue', 'person', 'rope2'], n: [4, 6], s: [0.6, 0.82] },
        ] };
      } },
    { id: 'rain', name: '비 오는 거리', g: 'out',
      bg(v, R) {
        const g = [['#8a93a6', '#c6ccd6'], ['#6f7a90', '#aab3c4'], ['#9a9aae', '#d0cdd8']][v % 3];
        grad(g[0], g[1], 0, 200);
        const fc = ['#c9a0a0', '#a0b8c9', '#c9c0a0', '#a8c9a0', '#bfa8c9'];
        for (let i = 0; i < 5; i++) { const x = i * 200; X.fillStyle = fc[(i + v) % 5]; X.fillRect(x, 70 + (i % 2) * 30, 200, 410);
          X.fillStyle = 'rgba(40,50,70,.35)'; X.fillRect(x + 30, 330, 140, 110); X.fillStyle = 'rgba(255,240,200,.3)'; X.fillRect(x + 36, 336, 128, 98);
          X.fillStyle = PAL[(i * 3 + v) % 8]; X.beginPath(); X.moveTo(x + 20, 300); X.lineTo(x + 180, 300); X.lineTo(x + 192, 326); X.lineTo(x + 8, 326); X.closePath(); X.fill(); }
        X.fillStyle = '#9ba1ad'; X.fillRect(0, 480, W, 70); X.fillStyle = '#4a4f5c'; X.fillRect(0, 550, W, 110);
        X.fillStyle = 'rgba(160,180,210,.35)'; for (let i = 0; i < 6; i++) { X.beginPath(); X.ellipse(R() * W, 580 + R() * 70, 50 + R() * 50, 9, 0, 0, TAU); X.fill(); }
        X.strokeStyle = 'rgba(220,235,255,.45)'; X.lineWidth = 2; for (let i = 0; i < 110; i++) { const x = R() * W, y = R() * H; X.beginPath(); X.moveTo(x, y); X.lineTo(x - 5, y + 18); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 110, y1: 290, fl: 1, ty: ['shopsign', 'clock', 'shopsign', 'flag'], n: [2, 4], s: [0.58, 0.74] },
          { x0: 10, x1: 990, y0: 520, y1: 540, ty: ['person', 'mailbox', 'busstop', 'lamppost', 'tlight', 'person', 'umbr'], n: [3, 5], s: [0.58, 0.74] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['car', 'umbr', 'boots', 'snail', 'frog', 'car', 'umbr'], n: [4, 6], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'garden', name: '정원', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 420);
        hills(R, 380, 50, '#a6d48a', 5);
        X.fillStyle = '#86c26e'; X.fillRect(0, 420, W, 240);
        X.fillStyle = '#fbfbff'; for (let x = 6; x < W; x += 36) { X.fillRect(x, 384, 20, 64); X.beginPath(); X.moveTo(x, 384); X.lineTo(x + 10, 372); X.lineTo(x + 20, 384); X.fill(); } X.fillRect(0, 400, W, 8); X.fillRect(0, 428, W, 8);
        X.fillStyle = '#8a5a32'; X.fillRect(0, 470, W, 26);
        const cs = [PAL[0], PAL[7], GOLD, PAL[6], WHITE]; for (let i = 0; i < 60; i++) { X.fillStyle = cs[i % 5]; X.beginPath(); X.arc(R() * W, 466 + R() * 26, 4, 0, TAU); X.fill(); }
        X.strokeStyle = '#6cb352'; X.lineWidth = 3; for (let i = 0; i < 40; i++) { const x = R() * W, y = 520 + R() * 130; X.beginPath(); X.moveTo(x - 5, y); X.lineTo(x, y - 9); X.lineTo(x + 5, y); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 30, x1: 970, y0: 14, y1: 150, fl: 1, nx: 1, ty: ['sun'], n: [0, 1], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 14, y1: 300, fl: 1, ty: ['cloud', 'bird', 'bee', 'butterfly', 'cloud', 'bee'], n: [3, 5], s: [0.58, 0.8] },
          { x0: 10, x1: 990, y0: 470, y1: 500, ty: ['tree', 'bhouse', 'gnome', 'wbarrow', 'bhouse'], n: [2, 3], s: [0.56, 0.68] },
          { x0: 10, x1: 990, y0: 586, y1: 652, ty: ['flower', 'gnome', 'wcan', 'ladybug', 'snail', 'mushroom', 'bucket', 'flower', 'rabbit', 'wbarrow', 'ladybug'], n: [7, 9], s: [0.6, 0.84] },
        ] };
      } },

    { id: 'street', name: '도심 거리', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 200);
        const fc = ['#d9c3a5', '#b9c6d2', '#cdb8c9', '#c8cdb0', '#e0b9a0'];
        for (let i = 0; i < 4; i++) { const x = i * 250, top = 110 + (i % 2) * 26; X.fillStyle = fc[(i + v) % 5]; X.fillRect(x, top, 250, 400);
          X.fillStyle = 'rgba(0,0,0,.08)'; X.fillRect(x, top, 250, 10);
          for (let r = 0; r < 2; r++) for (let c = 0; c < 4; c++) { X.fillStyle = 'rgba(60,80,110,.45)'; X.fillRect(x + 22 + c * 56, top + 26 + r * 54, 36, 36); X.fillStyle = 'rgba(255,255,255,.35)'; X.fillRect(x + 24 + c * 56, top + 28 + r * 54, 14, 32); }
          X.fillStyle = 'rgba(40,50,70,.4)'; X.fillRect(x + 26, 360, 198, 140); X.fillStyle = 'rgba(255,240,205,.32)'; X.fillRect(x + 32, 366, 186, 128); }
        X.fillStyle = '#b4b0aa'; X.fillRect(0, 500, W, 52); X.strokeStyle = 'rgba(0,0,0,.12)'; X.lineWidth = 2; for (let x = 0; x < W; x += 60) { X.beginPath(); X.moveTo(x, 500); X.lineTo(x, 552); X.stroke(); }
        X.fillStyle = '#d8d4cc'; X.fillRect(0, 548, W, 8);
        X.fillStyle = '#4b4f5a'; X.fillRect(0, 556, W, 104);
        const cw = 120 + R() * 700; X.fillStyle = 'rgba(245,245,245,.75)'; for (let y = 566; y < H; y += 20) X.fillRect(cw, y, 120, 10);
        X.fillStyle = '#e3ae45'; for (let x = 10; x < W; x += 110) if (x + 50 < cw || x > cw + 120) X.fillRect(x, 640, 50, 5);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 10, y1: 104, fl: 1, ty: ['bird', 'cloud', 'jet', 'bird'], n: [2, 3], s: [0.5, 0.62] },
          { x0: 10, x1: 990, y0: 286, y1: 340, fl: 1, ty: ['shopsign', 'clock', 'cafesign', 'flag', 'shopsign'], n: [3, 4], s: [0.56, 0.7] },
          { x0: 10, x1: 990, y0: 530, y1: 542, ty: ['person', 'mailbox', 'busstop', 'lamppost', 'tlight', 'hydrant', 'bike', 'bench', 'plant', 'person', 'hydrant'], n: [5, 7], s: [0.58, 0.74] },
          { x0: 10, x1: 990, y0: 618, y1: 652, ty: ['car', 'car', 'scooter', 'bike', 'car'], n: [3, 4], s: [0.62, 0.78] },
        ] };
      } },
    { id: 'harbor', name: '항구', g: 'out',
      bg(v, R) {
        const g = [['#8fc6e8', '#e8f2f6'], ['#e99a6a', '#fbe0b8'], ['#7f95b8', '#d9dde8']][v % 3]; grad(g[0], g[1], 0, 330);
        hills(R, 320, 50, 'rgba(90,110,130,.45)', 4);
        grad('#3f8fb4', '#1f5d80', 320, 480);
        X.strokeStyle = 'rgba(255,255,255,.45)'; X.lineWidth = 2.5; for (let i = 0; i < 18; i++) { const x = R() * W, y = 340 + R() * 130; X.beginPath(); X.moveTo(x, y); X.quadraticCurveTo(x + 14, y - 5, x + 28, y); X.stroke(); }
        X.fillStyle = '#7a5434'; X.fillRect(0, 480, W, 18); for (let x = 30; x < W; x += 120) X.fillRect(x, 470, 16, 44);
        X.fillStyle = '#a7774a'; X.fillRect(0, 498, W, 162);
        X.strokeStyle = 'rgba(60,35,15,.38)'; X.lineWidth = 2; for (let y = 520; y < H; y += 28) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); const off = R() * 160; for (let x = off; x < W; x += 210) { X.beginPath(); X.moveTo(x, y - 28); X.lineTo(x, y); X.stroke(); } }
      },
      lay(R) {
        const lx = R() < 0.5 ? 90 + R() * 80 : 830 + R() * 80, s = 0.86 + R() * 0.12;
        const no = [[lx - 50 * s, 440 - 240 * s, lx + 50 * s, 470]];
        return { bv: ri(R, 3), props: [{ t: 'lighthouse', x: lx, y: 452 - 118 * s, s, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 12, y1: 250, fl: 1, ty: ['bird', 'cloud', 'bird', 'cloud', 'jet'], n: [3, 4], s: [0.52, 0.7], no },
          { x0: 10, x1: 990, y0: 410, y1: 462, ty: ['boat', 'buoy', 'boat', 'buoy', 'boat'], n: [3, 4], s: [0.62, 0.8], no },
          { x0: 10, x1: 990, y0: 520, y1: 534, ty: ['crate', 'barrel', 'lamppost', 'bench', 'person', 'crate', 'bike'], n: [3, 5], s: [0.58, 0.72] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['crate', 'barrel', 'anchor', 'rope', 'fish', 'bucket', 'lantern', 'buoy', 'cat', 'crate'], n: [6, 8], s: [0.62, 0.82] },
        ] };
      } },
    { id: 'cafe', name: '카페', g: 'in',
      bg(v, R) {
        const wall = ['#e9dcc6', '#d6dccf', '#e3d2cc', '#d3d6e0'][v % 4];
        X.fillStyle = wall; X.fillRect(0, 0, W, 470);
        X.fillStyle = 'rgba(140,70,50,.10)'; for (let y = 0, j = 0; y < 300; y += 22, j++) for (let x = (j % 2) * 30; x < W; x += 60) X.fillRect(x + 2, y + 2, 56, 18);
        X.fillStyle = '#6b4a33'; X.fillRect(0, 300, W, 170); X.fillStyle = 'rgba(0,0,0,.12)'; for (let x = 0; x < W; x += 50) X.fillRect(x, 300, 3, 170);
        X.fillStyle = '#d9c7a8'; X.fillRect(0, 468, W, 26); X.fillStyle = 'rgba(0,0,0,.18)'; X.fillRect(0, 494, W, 6);
        X.fillStyle = '#8d6a4c'; X.fillRect(0, 500, W, 160);
        X.fillStyle = 'rgba(255,255,255,.07)'; for (let y = 500, j = 0; y < H; y += 40, j++) for (let x = (j % 2) * 40; x < W; x += 80) X.fillRect(x, y, 40, 40);
      },
      lay(R) {
        const hx = 170 + R() * 660;
        return { bv: ri(R, 4), props: [{ t: 'shelf', x: hx, y: 236 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 230, y1: 230, ty: ['mug', 'jar', 'plant', 'plates', 'books', 'jar'], n: [2, 3], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 14, y1: 280, fl: 1, ty: ['frame', 'clock', 'cafesign', 'frame', 'lamp'], n: [3, 4], s: [0.56, 0.74], no: [[hx - 122, 120, hx + 122, 250]] },
          { x0: 10, x1: 990, y0: 470, y1: 472, ty: ['espresso', 'mug', 'croissant', 'cake', 'jar', 'plant', 'bread', 'mug', 'espresso', 'plates'], n: [6, 8], s: [0.66, 0.84] },
          { x0: 10, x1: 990, y0: 596, y1: 652, ty: ['chair', 'plant', 'bag', 'cat', 'umbr', 'chair', 'books'], n: [4, 6], s: [0.62, 0.8] },
        ] };
      } },
    { id: 'workshop', name: '목공방', g: 'in',
      bg(v, R) {
        const wall = ['#c9a77d', '#b7a58f', '#c6b28c'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 470);
        X.fillStyle = 'rgba(70,40,20,.10)'; for (let x = 0; x < W; x += 84) X.fillRect(x, 0, 4, 470);
        X.fillStyle = '#e1cfa6'; X.fillRect(40, 30, W - 80, 260); X.fillStyle = 'rgba(70,50,30,.35)'; for (let y = 46; y < 284; y += 26) for (let x = 56; x < W - 50; x += 26) { X.beginPath(); X.arc(x, y, 2.5, 0, TAU); X.fill(); }
        X.strokeStyle = 'rgba(70,40,20,.5)'; X.lineWidth = 4; X.strokeRect(40, 30, W - 80, 260);
        X.fillStyle = '#8a5a32'; X.fillRect(0, 470, W, 30); X.fillStyle = '#6b4423'; X.fillRect(0, 500, W, 12);
        X.fillStyle = '#9a8670'; X.fillRect(0, 512, W, 148);
        X.fillStyle = 'rgba(230,200,140,.35)'; for (let i = 0; i < 40; i++) { X.beginPath(); X.ellipse(R() * W, 540 + R() * 110, 6 + R() * 6, 2.5, R() * 3, 0, TAU); X.fill(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 46, x1: 954, y0: 36, y1: 284, fl: 1, ty: ['hammer', 'saw', 'wrench', 'clock', 'saw', 'hammer', 'gear', 'wrench'], n: [5, 7], s: [0.58, 0.76] },
          { x0: 10, x1: 990, y0: 470, y1: 472, ty: ['toolbox', 'crate', 'jar', 'mug', 'lamp', 'plant', 'toolbox', 'bucket', 'log'], n: [5, 7], s: [0.64, 0.82] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['crate', 'barrel', 'toolbox', 'bucket', 'chair', 'log', 'cat', 'crate'], n: [4, 6], s: [0.62, 0.8] },
        ] };
      } },

    { id: 'office', name: '사무실', g: 'in',
      bg(v, R) {
        const wall = ['#e4e6ea', '#e9e2d6', '#dfe6e1'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 520);
        const sk = [['#9cc7ef', '#e6f2fb'], ['#f0b07a', '#fbe3c4'], ['#3a4a78', '#7b88b8']][v % 3];
        for (let i = 0; i < 2; i++) { const x = 60 + i * 520; X.fillStyle = '#5a5e70'; X.fillRect(x - 8, 40, 376, 236);
          const g = X.createLinearGradient(0, 48, 0, 268); g.addColorStop(0, sk[0]); g.addColorStop(1, sk[1]); X.fillStyle = g; X.fillRect(x, 48, 360, 220);
          X.fillStyle = 'rgba(70,80,110,.55)'; for (let b = 0; b < 7; b++) { const bw = 30 + R() * 30, bh = 40 + R() * 120; X.fillRect(x + b * 52, 268 - bh, bw, bh); }
          X.fillStyle = '#5a5e70'; X.fillRect(x + 176, 48, 8, 220); }
        X.fillStyle = '#b9bcc4'; X.fillRect(0, 516, W, 10);
        X.fillStyle = '#6e7584'; X.fillRect(0, 526, W, 134);
        X.strokeStyle = 'rgba(255,255,255,.08)'; X.lineWidth = 2; for (let x = 0; x < W; x += 80) { X.beginPath(); X.moveTo(x, 526); X.lineTo(x, H); X.stroke(); }
      },
      lay(R) {
        const a = 230 + R() * 60, b = 770 - R() * 60;
        return { bv: ri(R, 3), props: [{ t: 'desk', x: a, y: 470, pd: 1 }, { t: 'desk', x: b, y: 470, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 290, y1: 380, fl: 1, ty: ['clock', 'frame', 'calendar', 'screen', 'painting', 'calendar'], n: [3, 4], s: [0.5, 0.64] },
          { x0: a - 96, x1: a + 96, y0: 454, y1: 454, ty: ['laptop', 'mug', 'plant', 'books', 'lamp', 'jar', 'laptop'], n: [2, 3], s: [0.6, 0.74] },
          { x0: b - 96, x1: b + 96, y0: 454, y1: 454, ty: ['laptop', 'mug', 'plant', 'books', 'lamp', 'jar', 'laptop'], n: [2, 3], s: [0.6, 0.74] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['chair', 'plant', 'bag', 'backpack', 'person', 'umbr', 'chair', 'person'], n: [5, 7], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'platform', name: '기차역 플랫폼', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 400);
        hills(R, 330, 60, 'rgba(110,140,120,.5)', 5);
        X.fillStyle = '#6a5a52'; X.fillRect(0, 380, W, 40); X.fillStyle = '#9a9aa2'; X.fillRect(0, 392, W, 5); X.fillRect(0, 410, W, 5);
        X.fillStyle = '#5a4436'; for (let x = 0; x < W; x += 30) X.fillRect(x, 397, 14, 13);
        X.fillStyle = '#c9c4ba'; X.fillRect(0, 420, W, 240); X.fillStyle = '#f2c94c'; X.fillRect(0, 428, W, 10);
        X.fillStyle = 'rgba(0,0,0,.06)'; for (let x = 0; x < W; x += 70) X.fillRect(x, 438, 2, 222);
        X.fillStyle = '#4a5466'; X.fillRect(0, 0, W, 38); for (let x = 60; x < W; x += 300) X.fillRect(x, 38, 14, 400);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 50, y1: 250, fl: 1, ty: ['stsign', 'clock', 'screen', 'routemap', 'bird', 'stsign'], n: [3, 5], s: [0.54, 0.7], no: [[50, 0, 84, 440], [350, 0, 384, 440], [650, 0, 684, 440], [950, 0, 984, 440]] },
          { x0: 10, x1: 990, y0: 520, y1: 540, ty: ['person', 'bench', 'lamppost', 'mailbox', 'person', 'plant', 'person'], n: [4, 6], s: [0.58, 0.74] },
          { x0: 10, x1: 990, y0: 606, y1: 652, ty: ['suitcase', 'bag', 'person', 'umbr', 'backpack', 'suitcase', 'cat', 'bike'], n: [5, 7], s: [0.62, 0.8] },
        ] };
      } },
    { id: 'lobby', name: '호텔 로비', g: 'in',
      bg(v, R) {
        const wall = ['#efe6d6', '#e3dfe8', '#e6ece4'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 500);
        X.fillStyle = 'rgba(160,120,60,.18)'; for (let x = 40; x < W; x += 180) X.fillRect(x, 0, 18, 500);
        X.fillStyle = '#c9a25a'; X.fillRect(0, 0, W, 16); X.fillRect(0, 486, W, 14);
        X.fillStyle = '#e8e2d8'; X.fillRect(0, 500, W, 160);
        X.strokeStyle = 'rgba(120,100,80,.25)'; X.lineWidth = 2; for (let y = 500; y < H; y += 54) for (let x = (y / 54 % 2) * 60; x < W; x += 120) X.strokeRect(x, y, 120, 54);
        X.fillStyle = 'rgba(150,40,50,.55)'; X.fillRect(380, 560, 240, 100);
      },
      lay(R) {
        const cx = 500 + (R() - 0.5) * 300;
        return { bv: ri(R, 3), props: [{ t: 'counter', x: cx, y: 474, s: 0.62, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 30, y1: 300, fl: 1, ty: ['painting', 'clock', 'frame', 'clock', 'painting'], n: [3, 5], s: [0.5, 0.66] },
          { x0: cx - 130, x1: cx + 130, y0: 454, y1: 454, ty: ['bouquet', 'lamp', 'books', 'mug', 'laptop', 'vase'], n: [2, 3], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['suitcase', 'plant', 'person', 'chair', 'vase', 'suitcase', 'umbr', 'statue', 'bag'], n: [5, 7], s: [0.6, 0.8], no: [[cx - 150, 400, cx + 150, 560]] },
        ] };
      } },
    { id: 'study', name: '서재', g: 'in',
      bg(v, R) {
        const wall = ['#5b4a3e', '#3f4a44', '#4a3f52'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 500);
        X.fillStyle = 'rgba(255,255,255,.04)'; for (let x = 0; x < W; x += 36) X.fillRect(x, 0, 18, 500);
        X.fillStyle = '#8a5a32'; X.fillRect(0, 420, W, 80); X.fillStyle = 'rgba(0,0,0,.15)'; for (let x = 0; x < W; x += 100) X.fillRect(x, 420, 3, 80);
        X.fillStyle = '#6b4423'; X.fillRect(0, 500, W, 160);
        X.fillStyle = 'rgba(140,40,40,.55)'; X.fillRect(120, 560, 760, 100);
      },
      lay(R) {
        const left = R() < 0.5, bx = left ? 150 : 850, dx = left ? 600 : 400;
        return { bv: ri(R, 3), props: [{ t: 'bookcase', x: bx, y: 334, s: 0.95, sol: 1 }, { t: 'desk', x: dx, y: 470, s: 1.1, pd: 1 }], zones: [
          { x0: left ? 300 : 10, x1: left ? 990 : 700, y0: 30, y1: 330, fl: 1, ty: ['painting', 'clock', 'frame', 'frame', 'calendar'], n: [3, 4], s: [0.52, 0.68] },
          { x0: dx - 105, x1: dx + 105, y0: 452, y1: 452, ty: ['openbook', 'hourglass', 'magnifier', 'globe', 'lamp', 'mug', 'scroll', 'candles', 'books'], n: [3, 4], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 604, y1: 652, ty: ['books', 'cat', 'chair', 'lamp', 'plant', 'globe', 'books'], n: [4, 6], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'gate', name: '공항 게이트', g: 'in',
      bg(v, R) {
        const sk = [['#8fc6ee', '#e8f3fb'], ['#e99a6a', '#fbe0b8'], ['#26305a', '#5a6a9a']][v % 3];
        grad(sk[0], sk[1], 0, 300);
        X.fillStyle = '#8a8f98'; X.fillRect(0, 240, W, 60); X.fillStyle = '#f6f2ea'; for (let x = 0; x < W; x += 80) X.fillRect(x, 268, 40, 4);
        X.fillStyle = '#4a5060'; for (let x = 0; x < W; x += 200) X.fillRect(x, 0, 10, 300); X.fillRect(0, 0, W, 12); X.fillRect(0, 296, W, 12);
        X.fillStyle = '#d9dbe0'; X.fillRect(0, 308, W, 210);
        X.fillStyle = '#7d8290'; X.fillRect(0, 518, W, 142);
        X.fillStyle = 'rgba(255,255,255,.07)'; for (let x = 0; x < W; x += 50) X.fillRect(x, 518, 25, 142);
      },
      lay(R) {
        return { bv: ri(R, 3), props: [{ t: 'seats', x: 255, y: 500, s: 0.9 }, { t: 'seats', x: 745, y: 500, s: 0.9 }], zones: [
          { x0: 20, x1: 980, y0: 20, y1: 230, fl: 1, ty: ['jet', 'cloud', 'bird', 'jet', 'cloud'], n: [3, 4], s: [0.52, 0.72] },
          { x0: 20, x1: 980, y0: 316, y1: 410, fl: 1, ty: ['gatesign', 'clock', 'screen', 'gatesign', 'painting'], n: [2, 4], s: [0.5, 0.62] },
          { x0: 50, x1: 950, y0: 500 - 26 * 0.9, y1: 500 - 26 * 0.9, ty: ['bag', 'laptop', 'backpack', 'mug', 'books', 'bag'], n: [2, 4], s: [0.55, 0.68], no: [[462, 330, 538, 510]] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['suitcase', 'person', 'bag', 'suitcase', 'backpack', 'plant', 'person', 'suitcase'], n: [5, 7], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'parking', name: '주차장', g: 'out',
      bg(v, R) {
        const wall = ['#b9bcc4', '#c4bfb4', '#aeb8bc'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 300);
        X.fillStyle = '#e8e6e0'; X.fillRect(0, 0, W, 40); X.fillStyle = '#fffbe6'; for (let x = 80; x < W; x += 260) X.fillRect(x, 14, 140, 12);
        X.fillStyle = 'rgba(0,0,0,.08)'; for (let x = 0; x < W; x += 250) X.fillRect(x + 110, 40, 30, 260);
        X.fillStyle = '#f2c94c'; X.fillRect(0, 260, W, 18); X.fillStyle = OL; for (let x = 0; x < W; x += 40) X.fillRect(x, 260, 20, 18);
        X.fillStyle = '#5c6068'; X.fillRect(0, 300, W, 360);
        X.fillStyle = 'rgba(255,255,255,.75)'; for (let x = 20; x < W; x += 160) { X.fillRect(x, 310, 6, 110); X.fillRect(x, 540, 6, 120); }
        X.fillStyle = 'rgba(255,255,255,.5)'; for (let x = 0; x < W; x += 90) X.fillRect(x + 20, 476, 50, 6);
        X.fillStyle = 'rgba(0,0,0,.12)'; for (let i = 0; i < 6; i++) { X.beginPath(); X.ellipse(R() * W, 330 + R() * 320, 30 + R() * 30, 8, 0, 0, TAU); X.fill(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [], zones: [
          { x0: 10, x1: 990, y0: 50, y1: 240, fl: 1, ty: ['psign', 'clock', 'psign', 'screen', 'calendar', 'psign'], n: [3, 4], s: [0.5, 0.64] },
          { x0: 10, x1: 990, y0: 410, y1: 420, ty: ['car', 'car', 'pmeter', 'car', 'cone', 'car', 'hydrant'], n: [4, 6], s: [0.62, 0.8] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['car', 'cone', 'person', 'bike', 'car', 'barrier', 'bag', 'cone', 'car', 'umbr'], n: [5, 7], s: [0.62, 0.82] },
        ] };
      } },
    { id: 'nmarket', name: '야시장', g: 'out',
      bg(v, R) {
        const g = [['#151a33', '#3a2f5c'], ['#1b1428', '#4a2a3a'], ['#0f1f2a', '#2f3f5a']][v % 3]; grad(g[0], g[1], 0, 460);
        dots(R, 40, 0, 0, W, 200, 'rgba(255,255,255,.55)', 0.8, 1.8);
        X.fillStyle = 'rgba(20,20,40,.7)'; for (let x = 0; x < W; x += 120) { const h = 120 + R() * 140; X.fillRect(x, 380 - h, 100, h + 80); }
        X.beginPath(); X.moveTo(0, 50); X.quadraticCurveTo(500, 130, W, 50); X.lineWidth = 2; X.strokeStyle = '#5a4a3a'; X.stroke();
        for (let i = 0; i < 16; i++) { const t = (i + 0.5) / 16, x = t * W, y = 50 + 80 * 2 * t * (1 - t); glow(x, y + 6, 16, 'rgba(255,220,140,.7)'); X.fillStyle = ['#ffd96a', '#ff9a6a', '#ffe9b0'][(i + v) % 3]; X.beginPath(); X.arc(x, y + 6, 5, 0, TAU); X.fill(); }
        X.fillStyle = '#3e3a44'; X.fillRect(0, 460, W, 200);
        X.fillStyle = 'rgba(255,200,120,.08)'; X.fillRect(0, 460, W, 40);
        X.fillStyle = 'rgba(255,255,255,.05)'; for (let y = 500; y < H; y += 44) X.fillRect(0, y, W, 3);
      },
      lay(R) {
        const a = 245 + (R() - 0.5) * 60, b = 755 + (R() - 0.5) * 60;
        const top = ['bowl', 'skewer', 'pricetag', 'juice', 'bottle', 'crate', 'fish', 'bowl', 'skewer', 'lantern'];
        return { bv: ri(R, 3), props: [{ t: 'stall', x: a, y: 392, pd: 1 }, { t: 'stall', x: b, y: 392, pd: 1 }], zones: [
          { x0: a - 146, x1: a + 146, y0: 402, y1: 404, ty: top, n: [3, 4], s: [0.6, 0.74] },
          { x0: b - 146, x1: b + 146, y0: 402, y1: 404, ty: top, n: [3, 4], s: [0.6, 0.74] },
          { x0: 10, x1: 990, y0: 150, y1: 230, fl: 1, ty: ['lantern', 'lantern', 'billboard'], n: [1, 3], s: [0.5, 0.62] },
          { x0: 10, x1: 990, y0: 590, y1: 652, ty: ['person', 'stool', 'crate', 'person', 'bag', 'basket', 'stool', 'umbr', 'person', 'cat'], n: [5, 7], s: [0.62, 0.82] },
        ] };
      } },
    { id: 'site', name: '공사 현장', g: 'out',
      bg(v, R) {
        const g = SKY[v % 3]; grad(g[0], g[1], 0, 440);
        X.fillStyle = 'rgba(120,130,150,.45)'; for (let x = 0; x < W; x += 140) { const h = 80 + R() * 160; X.fillRect(x, 420 - h, 110, h); }
        X.strokeStyle = 'rgba(90,84,102,.6)'; X.lineWidth = 4; const sx = 560 + R() * 160;
        for (let y = 160; y <= 420; y += 65) { X.beginPath(); X.moveTo(sx, y); X.lineTo(sx + 260, y); X.stroke(); }
        for (let x = sx; x <= sx + 260; x += 65) { X.beginPath(); X.moveTo(x, 160); X.lineTo(x, 420); X.stroke(); }
        X.fillStyle = '#b08a5e'; X.fillRect(0, 420, W, 240);
        X.fillStyle = 'rgba(80,50,20,.25)'; dots(R, 70, 0, 430, W, H, 'rgba(80,50,20,.25)', 2, 5);
        X.fillStyle = '#9a9aa2'; X.fillRect(0, 412, W, 10);
      },
      lay(R) {
        const left = R() < 0.5, cx = left ? 170 + R() * 60 : 830 - R() * 60;
        return { bv: ri(R, 3), props: [{ t: 'crane', x: cx, y: 210, f: left ? 0 : 1, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 20, y1: 150, fl: 1, ty: ['cloud', 'bird', 'cloud', 'sun'], n: [2, 3], s: [0.56, 0.74], no: [[cx - 160, 0, cx + 180, 440]] },
          { x0: 10, x1: 990, y0: 470, y1: 500, ty: ['barrier', 'bricks', 'cone', 'wbarrow', 'toolbox', 'barrel', 'sign', 'bricks'], n: [3, 5], s: [0.6, 0.76], no: [[cx - 60, 380, cx + 60, 440]] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['hardhat', 'hammer', 'wrench', 'saw', 'barrier', 'cone', 'person', 'toolbox', 'bricks', 'hardhat'], n: [6, 8], s: [0.62, 0.84] },
        ] };
      } },
    { id: 'clinic', name: '병원 대기실', g: 'fan',
      bg(v, R) {
        const wall = ['#e6eef0', '#eef0e6', '#ece8f0'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 520);
        X.fillStyle = ['#7fc4c0', '#9cc7ef', '#b9d6a8'][v % 3]; X.fillRect(0, 300, W, 14);
        X.fillStyle = 'rgba(0,0,0,.04)'; X.fillRect(0, 314, W, 206);
        X.fillStyle = '#fffbe6'; X.fillRect(0, 0, W, 16);
        X.fillStyle = '#d9dcd6'; X.fillRect(0, 520, W, 140);
        X.strokeStyle = 'rgba(0,0,0,.08)'; X.lineWidth = 2; for (let x = 0; x < W; x += 70) { X.beginPath(); X.moveTo(x, 520); X.lineTo(x, H); X.stroke(); } for (let y = 560; y < H; y += 50) { X.beginPath(); X.moveTo(0, y); X.lineTo(W, y); X.stroke(); }
      },
      lay(R) {
        return { bv: ri(R, 3), props: [{ t: 'seats', x: 255, y: 480, s: 0.9 }, { t: 'seats', x: 745, y: 480, s: 0.9 }], zones: [
          { x0: 20, x1: 980, y0: 30, y1: 290, fl: 1, ty: ['hsign', 'clock', 'screen', 'calendar', 'painting', 'hsign', 'frame'], n: [4, 5], s: [0.5, 0.64] },
          { x0: 50, x1: 950, y0: 480 - 26 * 0.9, y1: 480 - 26 * 0.9, ty: ['bag', 'books', 'mug', 'person', 'bag', 'pills'], n: [2, 4], s: [0.55, 0.68], no: [[462, 330, 538, 490]] },
          { x0: 10, x1: 990, y0: 600, y1: 652, ty: ['person', 'wheelchair', 'plant', 'cooler', 'bag', 'umbr', 'person', 'chair'], n: [5, 7], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'winebar', name: '와인 바', g: 'fan',
      bg(v, R) {
        const wall = ['#3a2a2e', '#2e2a36', '#33302a'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 520);
        X.fillStyle = 'rgba(255,255,255,.035)'; for (let y = 0; y < 520; y += 30) for (let x = (y / 30 % 2) * 30; x < W; x += 60) X.fillRect(x, y, 56, 26);
        for (let x = 120; x < W; x += 250) { S([x, 0, x, 60], 2, '#1a1418'); glow(x, 76, 70, 'rgba(255,200,120,.35)'); C(x, 70, 13, '#ffd27a'); }
        X.fillStyle = '#5a3a28'; X.fillRect(0, 520, W, 140);
        X.fillStyle = 'rgba(0,0,0,.15)'; for (let x = 0; x < W; x += 90) X.fillRect(x, 520, 3, 140);
      },
      lay(R) {
        const left = R() < 0.5, hx = left ? 230 + R() * 60 : 770 - R() * 60, cx = 500 + (R() - 0.5) * 120;
        return { bv: ri(R, 3), props: [{ t: 'shelf', x: hx, y: 236 }, { t: 'counter', x: cx, y: 470, s: 0.9, c: 8, pd: 1 }], zones: [
          { x0: hx - 108, x1: hx + 108, y0: 230, y1: 230, ty: ['wine', 'wine', 'bottle', 'wine', 'goblet'], n: [3, 4], s: [0.6, 0.72] },
          { x0: left ? 420 : 20, x1: left ? 980 : 580, y0: 110, y1: 330, fl: 1, ty: ['painting', 'clock', 'frame', 'mirror'], n: [2, 3], s: [0.5, 0.64] },
          { x0: cx - 190, x1: cx + 190, y0: 440, y1: 440, ty: ['wglass', 'wine', 'cheese', 'candles', 'wglass', 'bowl', 'wglass'], n: [3, 5], s: [0.58, 0.72] },
          { x0: 10, x1: 990, y0: 604, y1: 652, ty: ['stool', 'person', 'stool', 'plant', 'barrel', 'bag', 'stool'], n: [5, 7], s: [0.62, 0.8] },
        ] };
      } },
    { id: 'laundry', name: '세탁소', g: 'fan',
      bg(v, R) {
        const wall = ['#dfe9ef', '#efe6dc', '#e2efe2'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 520);
        X.fillStyle = ['#3d7ee6', '#22b3a6', '#8f5bd8'][v % 3]; X.fillRect(0, 0, W, 22);
        S([0, 74, W, 74], 3, '#8f909c');
        X.fillStyle = '#c9ccd6'; X.fillRect(0, 512, W, 8);
        X.fillStyle = '#e6e2da'; X.fillRect(0, 520, W, 140);
        X.fillStyle = 'rgba(0,0,0,.06)'; for (let y = 520; y < H; y += 40) for (let x = (y / 40 % 2) * 40; x < W; x += 80) X.fillRect(x, y, 40, 40);
      },
      lay(R) {
        const wx = [100, 300, 500, 700, 900].map((x) => x + Math.round((R() - 0.5) * 30)), ws = 0.9, wy = 512 - 62 * ws, top = wy - 62 * ws;
        const tops = wx.map((x) => ({ x0: x - 44, x1: x + 44, y0: top, y1: top, ty: ['detergent', 'basket', 'folded', 'mug', 'plant', 'folded'], n: [0, 1], s: [0.56, 0.64] }));
        return { bv: ri(R, 3), props: wx.map((x) => ({ t: 'washer', x, y: wy, s: ws, pd: 1 })), zones: tops.concat([
          { x0: 20, x1: 980, y0: 80, y1: 250, fl: 1, ty: ['shirt', 'shirt', 'shirt', 'lsign', 'clock', 'calendar'], n: [4, 6], s: [0.56, 0.7] },
          { x0: 10, x1: 990, y0: 604, y1: 652, ty: ['basket', 'detergent', 'person', 'folded', 'chair', 'bag', 'basket', 'detergent'], n: [5, 7], s: [0.62, 0.82] },
        ]) };
      } },
    { id: 'bank', name: '은행 창구', g: 'fan',
      bg(v, R) {
        const wall = ['#e8e4da', '#dfe4ea', '#e4e8e0'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 500);
        X.fillStyle = ['#2d5a8a', '#2f6b4a', '#7a3b2e'][v % 3]; X.fillRect(0, 0, W, 30);
        X.fillStyle = 'rgba(0,0,0,.05)'; for (let x = 0; x < W; x += 200) X.fillRect(x, 30, 8, 470);
        X.fillStyle = 'rgba(160,210,240,.25)'; X.fillRect(0, 330, W, 70); S([0, 330, W, 330], 3, '#9aa3b5');
        X.fillStyle = '#cfcac0'; X.fillRect(0, 500, W, 160);
        X.strokeStyle = 'rgba(0,0,0,.08)'; X.lineWidth = 2; for (let y = 500; y < H; y += 54) for (let x = (y / 54 % 2) * 60; x < W; x += 120) X.strokeRect(x, y, 120, 54);
      },
      lay(R) {
        const cx = 500 + (R() - 0.5) * 200;
        return { bv: ri(R, 3), props: [{ t: 'counter', x: cx, y: 474, s: 1.0, pd: 1 }], zones: [
          { x0: 10, x1: 990, y0: 40, y1: 320, fl: 1, ty: ['banksign', 'clock', 'screen', 'banksign', 'painting', 'calendar', 'screen'], n: [4, 5], s: [0.5, 0.64] },
          { x0: cx - 210, x1: cx + 210, y0: 444, y1: 444, ty: ['laptop', 'coins', 'pencils', 'mug', 'bouquet', 'books', 'coins', 'laptop'], n: [3, 5], s: [0.58, 0.7] },
          { x0: 10, x1: 990, y0: 604, y1: 652, ty: ['atm', 'person', 'plant', 'chair', 'bag', 'person', 'umbr', 'cooler'], n: [5, 7], s: [0.6, 0.8] },
        ] };
      } },
    { id: 'salon', name: '미용실', g: 'fan',
      bg(v, R) {
        const wall = ['#f0e6e0', '#e4e6ee', '#e8efe8'][v % 3];
        X.fillStyle = wall; X.fillRect(0, 0, W, 520);
        X.fillStyle = 'rgba(0,0,0,.035)'; for (let x = 0; x < W; x += 50) X.fillRect(x, 0, 2, 520);
        X.fillStyle = '#2b2a33'; X.fillRect(0, 0, W, 18);
        X.fillStyle = '#f2f0ea'; X.fillRect(0, 520, W, 140);
        X.fillStyle = '#2b2a33'; for (let y = 520; y < H; y += 46) for (let x = (y / 46 % 2) * 46; x < W; x += 92) X.fillRect(x, y, 46, 46);
      },
      lay(R) {
        const hx = 500 + (R() - 0.5) * 300;
        return { bv: ri(R, 3), props: [{ t: 'shelf', x: hx, y: 300 }], zones: [
          { x0: 10, x1: 990, y0: 40, y1: 250, fl: 1, ty: ['mirror', 'mirror', 'clock', 'mirror', 'frame', 'painting'], n: [3, 4], s: [0.58, 0.72] },
          { x0: hx - 108, x1: hx + 108, y0: 294, y1: 294, ty: ['spray', 'detergent', 'bottle', 'jar', 'scissors', 'dryer', 'plant'], n: [3, 4], s: [0.6, 0.72] },
          { x0: 10, x1: 990, y0: 540, y1: 552, ty: ['salonchair', 'salonchair', 'plant', 'salonchair'], n: [2, 3], s: [0.66, 0.76], no: [[hx - 130, 220, hx + 130, 320]] },
          { x0: 10, x1: 990, y0: 626, y1: 652, ty: ['person', 'bag', 'spray', 'books', 'plant', 'umbr', 'person'], n: [3, 5], s: [0.6, 0.76] },
        ] };
      } },
  ];

  /* ======================= scene generator (pure, deterministic) ======================= */
  const MARGIN = 6, ISC = 1.3;
  function mk(t, x, y, s, c, v, f, Lr, extra) {
    const ty = TY[t];
    return Object.assign({ t, x, y, s, c: c | 0, v: v | 0, f: f | 0, L: Lr, r: ty.r * s, b: y + ty.ft * s }, extra || {});
  }
  let GH = H;
  function freeAt(x, y, r, objs, avoid, skip) {
    if (x - r < MARGIN || x + r > W - MARGIN || y - r < MARGIN || y + r > GH - MARGIN) return false;
    for (let j = 0; j < objs.length; j++) {
      if (j === skip) continue;
      const o = objs[j]; if (o.L !== 1 && !o.sol) continue;
      const dx = x - o.x, dy = y - o.y, rr = r + o.r + 4; if (dx * dx + dy * dy < rr * rr) return false;
    }
    if (avoid) for (const d of avoid) { const dx = x - d.x, dy = y - d.y, rr = r + d.rr + 14; if (dx * dx + dy * dy < rr * rr) return false; }
    return true;
  }
  function hitsNo(z, x, y, r) {
    if (z.no) for (const q of z.no) { const nx = Math.max(q[0], Math.min(q[2], x)), ny = Math.max(q[1], Math.min(q[3], y)); if ((nx - x) * (nx - x) + (ny - y) * (ny - y) < r * r) return true; }
    return false;
  }
  function place(R, z, t, objs, avoid, zi) {
    const ty = TY[t];
    const s = Math.round((z.s[0] + R() * (z.s[1] - z.s[0])) * ISC * 100) / 100, r = ty.r * s;
    const x = z.x1 - z.x0 > 2 * r ? z.x0 + r + R() * (z.x1 - z.x0 - 2 * r) : (z.x0 + z.x1) / 2;
    let y;
    if (z.fl) y = z.y1 - z.y0 > 2 * r ? z.y0 + r + R() * (z.y1 - z.y0 - 2 * r) : (z.y0 + z.y1) / 2;
    else y = z.y0 + R() * (z.y1 - z.y0) - ty.ft * s;
    const c = ty.col ? pick(R, ty.col) : 0, v = ri(R, ty.vn), f = ty.asym && R() < 0.5 ? 1 : 0;
    const p = ty.pn ? ri(R, ty.pn) : 0, n = ty.cn ? ty.cn[0] + ri(R, ty.cn[1] - ty.cn[0] + 1) : 0;
    if (hitsNo(z, x, y, r)) return null;
    if (!freeAt(x, y, r, objs, avoid, -1)) return null;
    return mk(t, x, y, s, c, v, f, 1, { p, n, z: zi, fl: z.fl ? 1 : 0 });
  }
  function farColor(R, o) {
    const ty = TY[o.t]; if (!ty.col) return -1;
    const ok = ty.col.filter((c) => c !== o.c && !NEAR[o.c].includes(c));
    return ok.length ? pick(R, ok) : -1;
  }
  // difficulty dv 0..2 (from the round): which kinds may appear, how small the changed thing may be
  const KIND_EASY = ['rm', 'ex', 'col', 'sz', 'var'], TRICKY = ['mir', 'mv', 'rot', 'txt'];
  const MIN_R = [36, 31, 28, 28], MIN_DET = [40, 35, 32, 31];
  const dvOf = (K) => Math.max(0, Math.min(2, K - 5));
  function tryScene(seed, th, K, dvIn, exIn) {
    const R = rng(seed);
    const ex = Math.max(0, Math.min(300, exIn | 0)); GH = H + ex;
    const dv = dvIn == null ? dvOf(K) : Math.max(0, Math.min(3, dvIn | 0));
    const T = THEMES[th];
    const lay = T.lay(R);
    if (ex) { // taller picture: everything moves down, floating zones near the top also grow upward into the new band
      for (const p of lay.props) p.y += ex;
      for (const z of lay.zones) {
        const h0 = z.y1 - z.y0, grow = z.fl && z.y0 < 260;
        z.y1 += ex; if (!grow) z.y0 += ex;
        if (z.no) z.no = z.no.map((q) => [q[0], q[1] + ex, q[2], q[3] + ex]);
        if (grow) { const add = Math.min(3, Math.round(ex / 110)); z.n = [z.n[0] + add, z.n[1] + add]; void h0; }
      }
    }
    const objs = [];
    for (const p of lay.props) {
      const ty = TY[p.t];
      objs.push(mk(p.t, p.x, p.y, p.s || 1, p.c != null ? p.c : pc(R, p.t), ri(R, ty.vn), p.f || 0, 0, { sol: p.sol ? 1 : 0, pd: p.pd ? 1 : 0, p: 0, n: ty.cn ? ty.cn[0] : 0 }));
    }
    lay.zones.forEach((z, zi) => {
      const n = z.n[0] + ri(R, z.n[1] - z.n[0] + 1) + (dv >= 2 && z.n[1] >= 4 ? 1 : 0);
      let placed = 0;
      for (let tries = 0; placed < n && tries < n * 40; tries++) { const o = place(R, z, pick(R, z.ty), objs, null, zi); if (o) { objs.push(o); placed++; } }
    });
    const items = objs.filter((o) => o.L === 1).length;
    if (items < K + 3) return null;
    // differences
    const cands = shuf(R, objs.map((o, i) => i).filter((i) => objs[i].L === 1 || objs[i].pd));
    const diffs = [], cnt = {}, cap = 2, trickyCap = dv >= 3 ? 3 : dv >= 2 ? 2 : 1;
    const nEx = K >= 6 ? 1 : (R() < 0.5 ? 1 : 0);
    const minR = MIN_R[dv], minDet = MIN_DET[dv];
    let propD = 0;
    for (const i of cands) {
      if (diffs.length >= K - nEx) break;
      const o = objs[i], ty = TY[o.t], prop = o.L === 0;
      if (prop && propD >= 1) continue;
      const ops = [];
      if (!prop && o.r >= minR) ops.push('rm', 'sz');
      if (ty.col && o.r >= minR && farColor(R, o) >= 0) ops.push('col');
      if (ty.vn > 1 && o.r >= (ty.tx && !prop ? Math.max(40, minDet) : minDet)) ops.push(ty.tx ? 'txt' : 'var');
      if (!prop && ty.pn && o.r >= minDet) ops.push('pat');
      if (!prop && ty.cn && o.r >= minDet) ops.push('cnt');
      if (dv > 0) {
        if (!prop && ty.asym && o.r >= minR) ops.push('mir');
        if (!prop && ty.rt && o.fl && o.r >= minR) ops.push('rot');
        if (!prop && o.r >= minR && o.t !== 'strap') ops.push('mv');
      }
      const allowed = ops.filter((k) => dv > 0 || KIND_EASY.includes(k));
      if (!allowed.length) continue;
      shuf(R, allowed); allowed.sort((a, b) => (cnt[a] || 0) - (cnt[b] || 0));
      for (const op of allowed) {
        if ((cnt[op] || 0) >= (TRICKY.includes(op) ? trickyCap : cap)) continue;
        const d = { o: i, k: op, sd: R() < 0.5 ? 0 : 1, x: o.x, y: o.y, rr: o.r, a: 0 };
        if (op === 'col') d.a = farColor(R, o);
        else if (op === 'var' || op === 'txt') d.a = (o.v + 1 + ri(R, ty.vn - 1)) % ty.vn;
        else if (op === 'mir') d.a = 1;
        else if (op === 'sz') {
          const up = [1.45, 1.4, 1.34, 1.3][dv], dn = [0.6, 0.64, 0.68, 0.71][dv];
          const cy = (q) => (o.fl ? o.y : o.b - ty.ft * o.s * q); // grounded things keep their feet on the ground
          const grow = R() < 0.5 && freeAt(o.x, cy(up), o.r * up, objs, null, i) && !hitsNo(lay.zones[o.z] || {}, o.x, cy(up), o.r * up);
          if (grow) d.a = up; else if (o.r * dn >= 20) d.a = dn; else continue;
          const ny = cy(d.a);
          d.y = (o.y + ny) / 2; d.rr = Math.max(o.r, o.r * d.a) + Math.abs(ny - o.y) / 2;
        } else if (op === 'pat') {
          const ch = []; for (let p = 0; p < ty.pn; p++) if (p !== o.p && !((o.p === 1 && p === 3) || (o.p === 3 && p === 1))) ch.push(p);
          if (!ch.length) continue;
          d.a = pick(R, ch);
        } else if (op === 'cnt') {
          const lo = ty.cn[0], hi = ty.cn[1], md = hi - lo >= 3 || dv === 0 ? 2 : 1, ch = [];
          for (let q = lo; q <= hi; q++) if (Math.abs(q - o.n) >= md) ch.push(q);
          if (!ch.length) for (let q = lo; q <= hi; q++) if (q !== o.n) ch.push(q);
          if (!ch.length) continue;
          d.a = pick(R, ch);
        } else if (op === 'rot') {
          d.a = Math.round((R() < 0.5 ? -1 : 1) * (0.42 + R() * 0.2) * 100) / 100;
        } else if (op === 'mv') {
          const z = lay.zones[o.z]; if (!z) continue;
          let ok = false;
          for (let tr = 0; tr < 8 && !ok; tr++) {
            const dist = Math.max(44, o.r * (0.9 + R() * 0.4));
            const ang = z.fl ? R() * TAU : (R() < 0.5 ? 0 : Math.PI);
            const nx = Math.round(o.x + Math.cos(ang) * dist), ny = Math.round(o.y + Math.sin(ang) * dist);
            if (nx - o.r < z.x0 - 1 || nx + o.r > z.x1 + 1) continue;
            if (z.fl && (ny - o.r < z.y0 - 1 || ny + o.r > z.y1 + 1)) continue;
            if (hitsNo(z, nx, ny, o.r) || !freeAt(nx, ny, o.r, objs, null, i)) continue;
            d.a = [nx, ny]; d.x = (o.x + nx) / 2; d.y = (o.y + ny) / 2; d.rr = o.r + dist / 2; ok = true;
          }
          if (!ok) continue;
        }
        if (prop) {
          if (ty.hot) { d.x = o.x + ty.hot[0] * o.s * (o.f ? -1 : 1); d.y = o.y + ty.hot[1] * o.s; d.rr = ty.hot[2] * o.s; }
          else d.rr = Math.min(o.r * 0.72, 150);
        }
        d.rr = Math.max(MINRR, d.rr);
        if (d.x < 20 || d.x > W - 20 || d.y < 20 || d.y > GH - 20) continue;
        let clash = false;
        for (const e of diffs) { const dx = d.x - e.x, dy = d.y - e.y, rr = d.rr + e.rr + 14; if (dx * dx + dy * dy < rr * rr) { clash = true; break; } }
        if (clash) continue;
        d.x = Math.round(d.x); d.y = Math.round(d.y); d.rr = Math.round(d.rr);
        diffs.push(d); cnt[op] = (cnt[op] || 0) + 1; if (prop) propD++;
        break;
      }
    }
    // extra things (exist on one side only)
    for (let g = 0; diffs.length < K && g < 300; g++) {
      const zi = ri(R, lay.zones.length), z = lay.zones[zi]; if (z.nx) continue;
      const t = pick(R, z.ty);
      if (TY[t].r * z.s[1] * ISC < minR) continue;
      const o = place(R, z, t, objs, diffs, zi);
      if (!o || o.r < minR) continue;
      diffs.push({ o: -1, k: 'ex', sd: R() < 0.5 ? 0 : 1, x: Math.round(o.x), y: Math.round(o.y), rr: Math.round(Math.max(MINRR, o.r)), a: o });
    }
    if (diffs.length < K) return null;
    shuf(R, diffs);
    for (const d of diffs) { const q = Math.sqrt(48 / d.rr); d.h = Math.round(KH[d.k] * Math.min(1.4, Math.max(0.75, q)) * 100) / 100; }
    return { th, seed, dv, ex, hh: H + ex, bs: Math.floor(R() * 2147483647), bv: lay.bv, objs, diffs };
  }
  function genScene(seed, th, K, dv, ex) {
    for (let a = 0; a < 30; a++) { const s = tryScene((seed + a * 7919) >>> 0, th, K, dv, ex); if (s) return s; }
    throw new Error('scene failed ' + seed + '/' + th);
  }
  const sceneCache = [];
  function sceneOf(s) {
    const key = s.sd + '.' + s.th + '.' + s.k + '.' + s.dv + '.' + (s.ex | 0);
    for (const c of sceneCache) if (c.key === key) return c.sc;
    const sc = genScene(s.sd, s.th, s.k, s.dv, s.ex | 0);
    sceneCache.unshift({ key, sc }); if (sceneCache.length > 4) sceneCache.pop();
    return sc;
  }
  function sideObjs(sc, side) {
    sc._side = sc._side || [];
    if (sc._side[side]) return sc._side[side];
    const list = sc.objs.map((o) => Object.assign({}, o));
    const rm = {};
    for (const d of sc.diffs) {
      if (d.sd !== side) continue;
      if (d.k === 'ex') { list.push(Object.assign({}, d.a)); continue; }
      const o = list[d.o];
      if (d.k === 'rm') rm[d.o] = 1;
      else if (d.k === 'col') o.c = d.a;
      else if (d.k === 'var' || d.k === 'txt') o.v = d.a;
      else if (d.k === 'mir') o.f = o.f ? 0 : 1;
      else if (d.k === 'sz') { o.s *= d.a; if (!o.fl) o.y = o.b - TY[o.t].ft * o.s; }
      else if (d.k === 'pat') o.p = d.a;
      else if (d.k === 'cnt') o.n = d.a;
      else if (d.k === 'rot') o.ro = d.a;
      else if (d.k === 'mv') { o.b += d.a[1] - o.y; o.x = d.a[0]; o.y = d.a[1]; }
    }
    const out = list.filter((o, i) => !rm[i]).sort((a, b) => (a.L - b.L) || (a.b - b.b));
    sc._side[side] = out;
    return out;
  }
  function drawObj(o) {
    const ty = TY[o.t];
    X.save(); X.translate(o.x, o.y); if (o.ro) X.rotate(o.ro); X.scale(o.f ? -o.s : o.s, o.s);
    LWv = LWB / o.s;
    ty.draw(PAL[o.c] || PAL[0], o.v | 0, o);
    X.restore();
  }
  function paintScene(c, sc, side) {
    X = c;
    X.save();
    X.beginPath(); X.rect(0, 0, W, sc.hh || H); X.clip();
    X.lineJoin = 'round'; X.lineCap = 'round';
    if (sc.ex) { // top band: the background's upper part stretched, then the real background below it
      X.save(); X.scale(1, (H + sc.ex) / H); THEMES[sc.th].bg(sc.bv, rng(sc.bs)); X.restore();
      X.save(); X.translate(0, sc.ex); X.beginPath(); X.rect(0, 0, W, H); X.clip(); THEMES[sc.th].bg(sc.bv, rng(sc.bs)); X.restore();
    } else THEMES[sc.th].bg(sc.bv, rng(sc.bs));
    for (const o of sideObjs(sc, side)) drawObj(o);
    X.restore();
    X = null;
  }

  /* ======================= game logic (pure) ======================= */
  const kFor = (rd, R) => (R <= 1 ? 6 : 5 + Math.round((rd - 1) * 2 / (R - 1)));
  const newSeed = () => Math.floor(Math.random() * 2147483647);
  function themeOrder(opt, R) {
    const ix = THEMES.findIndex((t) => t.id === opt);
    if (ix >= 0) return Array(R).fill(ix);
    let pool = THEMES.map((t, i) => i);
    if (opt === 'in' || opt === 'out' || opt === 'fan') pool = pool.filter((i) => THEMES[i].g === opt);
    const a = shuf(Math.random, pool);
    const out = []; for (let i = 0; i < R; i++) out.push(a[i % a.length]);
    return out;
  }
  // endless solo stages: more differences and subtler changes as you go
  const kEnd = (rd) => Math.min(8, 5 + Math.floor((rd - 1) / 3));
  const dvEnd = (rd) => Math.min(3, Math.floor((rd - 1) / 2));
  function pickTheme(opt, prev) {
    const ix = THEMES.findIndex((t) => t.id === opt);
    if (ix >= 0) return ix;
    let pool = THEMES.map((t, i) => i);
    if (opt === 'in' || opt === 'out' || opt === 'fan') pool = pool.filter((i) => THEMES[i].g === opt);
    if (pool.length > 1) pool = pool.filter((i) => i !== prev);
    return pool[Math.floor(Math.random() * pool.length)];
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const lim = [60, 90, 120].includes(+opts.time) ? +opts.time : 90;
    const base = { rid: Math.floor(Math.random() * 1e9), n, nm: players.map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 10)),
      lim, rd: 1, ph: 'count', sd: newSeed(), sc: Array(n).fill(0), hn: Array(n).fill(HINTS), hu: 0, ms: Array(n).fill(0), hx: Array(n).fill(0), ft: Array(n).fill(0), lh: Array(n).fill(0), el: 0, rh: [], ss: [], tm: [], last: null };
    if (n === 1 && opts.solo !== 'stars') { // endless stages
      const th = pickTheme(opts.theme || 'mix', -1), k = kEnd(1);
      return Object.assign(base, { md: 'e', to: String(opts.theme || 'mix').slice(0, 12), R: 0, tl: [], th, k, dv: dvEnd(1), f: '-'.repeat(k), cl: 0, tt: 0, fs: 0 });
    }
    const R = +opts.rounds === 5 ? 5 : 3;
    const tl = themeOrder(opts.theme || 'mix', R);
    const k = kFor(1, R);
    return Object.assign(base, { R, tl, th: tl[0], k, dv: dvOf(k), f: '-'.repeat(k) });
  }
  function actor(s) {
    if (!s || s.ph !== 'play') return null;
    const a = []; for (let i = 0; i < s.n; i++) a.push(i);
    return a;
  }
  function apply(s, seat, a) {
    if (!a || s.ph !== 'play' || seat < 0 || seat >= s.n) throw new Error('bad action');
    const id = (s.last ? s.last.id : 0) + 1;
    if (a.t === 'hit') {
      const i = a.i | 0;
      if (i < 0 || i >= s.k || s.f[i] !== '-') throw new Error('taken');
      s.f = s.f.slice(0, i) + seat + s.f.slice(i + 1);
      s.sc[seat]++;
      if (s.ft) { const el = Math.round((s.el || 0) / 100); s.ft[seat] += Math.max(0, el - (s.lh[seat] || 0)); s.lh[seat] = el; }
      s.last = { id, k: 'hit', s: seat, i };
      return s;
    }
    if (a.t === 'hint') {
      if (s.hn[seat] <= 0) throw new Error('no hints');
      if ((s.el || 0) < HINT_AFTER - 1200) throw new Error('too early');
      const un = []; for (let i = 0; i < s.k; i++) if (s.f[i] === '-') un.push(i);
      if (!un.length) throw new Error('none left');
      s.hn[seat]--; if (s.hx) s.hx[seat]++;
      if (s.n === 1) s.hu++;
      s.last = { id, k: 'hint', s: seat, i: un[Math.floor(Math.random() * un.length)] };
      return s;
    }
    if (a.t === 'miss') { if (s.ms) s.ms[seat] = Math.min(999, s.ms[seat] + 1); return s; } // wrong tap: only counted for the result table
    throw new Error('bad action');
  }
  const allFound = (s) => s.f.indexOf('-') < 0;
  function starsFor(s, ms) {
    if (!allFound(s)) return 0;
    const t = ms / 1000 + s.hu * HINT_SOLO_PEN;
    return t <= s.k * 5.5 ? 3 : t <= s.k * 10 ? 2 : 1;
  }
  function endRound(s, clock) {
    const n = JSON.parse(JSON.stringify(s));
    n.ph = 'end'; n.el = Math.round(Math.min(clock, n.lim * 1000));
    if (n.md === 'e') {
      if (allFound(n)) { const ds = Math.round(n.el / 100) + n.hu * HINT_SOLO_PEN * 10; n.cl++; n.tt += ds; n.fs = n.fs ? Math.min(n.fs, ds) : ds; }
      return n;
    }
    n.rh.push(n.f);
    n.tm.push(Math.round(n.el / 100));
    if (n.n === 1) n.ss.push(starsFor(n, n.el));
    return n;
  }
  function nextRound(s) {
    const n = JSON.parse(JSON.stringify(s));
    if (n.md === 'e') {
      if (!allFound(n)) { n.ph = 'done'; return n; }
      n.rd++; n.th = pickTheme(n.to, n.th); n.sd = newSeed(); n.k = kEnd(n.rd); n.dv = dvEnd(n.rd); n.f = '-'.repeat(n.k);
      if (n.cl % 3 === 0) n.hn[0] = Math.min(5, n.hn[0] + 1); // +1 hint every 3 cleared stages
      n.ph = 'count'; n.el = 0; n.hu = 0; if (n.lh) n.lh = n.lh.map(() => 0);
      return n;
    }
    if (n.rd >= n.R) { n.ph = 'done'; return n; }
    n.rd++; n.th = n.tl[n.rd - 1]; n.sd = newSeed(); n.k = kFor(n.rd, n.R); n.dv = dvOf(n.k); n.f = '-'.repeat(n.k);
    n.ph = 'count'; n.el = 0; n.hu = 0; if (n.lh) n.lh = n.lh.map(() => 0);
    return n;
  }
  // AI searchers: each AI looks for one difference at a time; the time depends on level and how hard the difference is
  const AIB = [0, 13000, 8400, 5300];
  function aiPlan(s, sc, lv, R, first, slow) {
    const un = []; for (let i = 0; i < s.k; i++) if (s.f[i] === '-') un.push(i);
    if (!un.length) return { tgt: -1, t: 1e9 };
    let tot = 0; const w = un.map((i) => { const x = 1 / sc.diffs[i].h; tot += x; return x; });
    let r = R() * tot, tgt = un[un.length - 1];
    for (let j = 0; j < un.length; j++) { r -= w[j]; if (r <= 0) { tgt = un[j]; break; } }
    let t = AIB[lv] * sc.diffs[tgt].h * (0.55 + R() * 0.9) * (slow || 1) * (1 + 0.08 * (sc.dv || 0));
    if (first) t += 1400 + R() * 1200;
    if (lv === 1 && R() < 0.3) t += 2500;      // 헛짚어서 잠깐 멈춤
    if (lv === 2 && R() < 0.12) t += 2000;
    return { tgt, t };
  }
  // host-only: advances the round clock, the AI searchers and the phases. Returns a new state or null (no change).
  function hostStep(s, mem, dt, aiLv, R) {
    R = R || Math.random;
    const key = s.rid + '.' + s.rd + '.' + s.ph;
    if (mem.key !== key) { mem.key = key; mem.clock = s.ph === 'play' ? (s.el || 0) : 0; mem.pub = Math.floor(mem.clock / 1000); mem.ai = {}; }
    mem.clock += dt;
    if (s.ph === 'count') return mem.clock >= COUNT_MS ? Object.assign(JSON.parse(JSON.stringify(s)), { ph: 'play', el: 0 }) : null;
    if (s.ph === 'end') return mem.clock >= END_MS ? nextRound(s) : null;
    if (s.ph !== 'play') return null;
    const sc = sceneOf(s);
    let cur = s, changed = false;
    for (let seat = 0; seat < s.n; seat++) {
      const lv = aiLv[seat]; if (!lv) { delete mem.ai[seat]; continue; }
      let m = mem.ai[seat];
      if (!m) m = mem.ai[seat] = aiPlan(cur, sc, lv, R, true);
      if (m.tgt >= 0 && cur.f[m.tgt] !== '-') m = mem.ai[seat] = aiPlan(cur, sc, lv, R, false, 0.6);
      m.t -= dt;
      if (m.t <= 0 && m.tgt >= 0) {
        if (cur.f[m.tgt] === '-') { cur = apply(changed ? cur : JSON.parse(JSON.stringify(cur)), seat, { t: 'hit', i: m.tgt }); changed = true; }
        mem.ai[seat] = aiPlan(cur, sc, lv, R, false);
      }
    }
    if (allFound(cur) || mem.clock >= s.lim * 1000) return endRound(cur, mem.clock);
    const sec = Math.floor(mem.clock / 1000);
    if (changed || sec !== mem.pub) {
      mem.pub = sec;
      if (!changed) cur = JSON.parse(JSON.stringify(cur));
      cur.el = Math.round(mem.clock);
      return cur;
    }
    return null;
  }
  function statsOf(s) {
    if (!s.ms) return undefined;
    const avg = (i) => (s.sc[i] ? (s.ft[i] / 10 / s.sc[i]).toFixed(1) + '초' : '-');
    const one = s.n === 1;
    const row = (label, fn) => (one ? { label, value: String(fn(0)) } : { label, values: s.sc.map((v, i) => String(fn(i))) });
    return [row('찾은 수', (i) => s.sc[i] + '개'), row('틀린 터치', (i) => s.ms[i] + '번'), row('힌트 사용', (i) => s.hx[i] + '번'), row('평균 찾기 시간', avg)];
  }
  function result(s) {
    const r = resultBase(s); if (r) r.stats = statsOf(s);
    return r;
  }
  function resultBase(s) {
    if (!s || s.ph !== 'done') return null;
    if (s.md === 'e') {
      const fs = s.fs ? (s.fs / 10).toFixed(1) + '초' : '-';
      return { winners: s.cl > 0 ? [0] : [], title: '스테이지 ' + s.cl + '개 클리어',
        text: s.rd + '번째 스테이지(' + THEMES[s.th].name + ')에서 시간 초과\n깬 스테이지 ' + s.cl + '개 · 합계 ' + (s.tt / 10).toFixed(1) + '초\n가장 빠른 스테이지 ' + fs };
    }
    if (s.n === 1) {
      const tot = s.ss.reduce((a, b) => a + b, 0), max = s.R * 3;
      const lines = s.ss.map((v, i) => (i + 1) + '라운드 ' + THEMES[s.tl[i]].name + ' — ' + '★'.repeat(v) + '☆'.repeat(3 - v) + (v ? ' (' + (s.tm[i] / 10).toFixed(1) + '초)' : ' (시간 초과)'));
      const clear = s.ss.every((v) => v > 0);
      return { winners: clear ? [0] : [], title: (clear ? '클리어! ' : '아쉬워요 · ') + '별 ' + tot + ' / ' + max, text: lines.join('\n') };
    }
    const best = Math.max.apply(null, s.sc);
    const winners = []; for (let i = 0; i < s.n; i++) if (s.sc[i] === best) winners.push(i);
    const order = s.sc.map((v, i) => i).sort((a, b) => s.sc[b] - s.sc[a]);
    const per = (i) => s.rh.map((f) => f.split('').filter((c) => c === String(i)).length).join('·');
    const text = order.map((i, r) => (r + 1) + '위 ' + s.nm[i] + ' — ' + s.sc[i] + '개 (' + per(i) + ')').join('\n');
    return { winners, title: best === 0 ? '아무도 못 찾았어요' : undefined, text };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const CSS = `
.sd-top{position:absolute;left:0;right:0;top:0;height:46px;display:flex;align-items:center;gap:8px;padding:0 12px;z-index:3;pointer-events:none}
.sd-rd{font:700 12px ${MONO};color:#e3ae45;background:rgba(227,174,69,.12);border:1px solid rgba(227,174,69,.45);border-radius:999px;padding:3px 8px;flex:none}
.sd-th{font:700 14px ${FONT};color:#f2e9d8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;flex:0 1 auto}
.sd-dots{display:flex;gap:4px;margin-left:auto;flex:none}
.sd-dots i{width:13px;height:13px;border-radius:50%;border:2px solid rgba(242,233,216,.4);box-sizing:border-box;display:block}
.sd-dots i.on{border-color:#fff;background:var(--c)}
.sd-time{font:700 19px ${MONO};color:#f2e9d8;min-width:54px;text-align:right;flex:none}
.sd-time.low{color:#ee6a55}
.sd-bar{position:absolute;left:0;right:0;bottom:0;height:62px;display:flex;align-items:center;gap:8px;padding:0 10px;z-index:3}
.sd-chips{display:flex;flex-wrap:wrap;gap:4px 5px;flex:1 1 auto;min-width:0;align-content:center;max-height:58px;overflow:hidden}
.sd-chip{display:inline-flex;align-items:center;gap:4px;height:24px;padding:0 7px 0 5px;border-radius:999px;background:#221c2e;border:1.5px solid rgba(242,233,216,.14);font:700 14px ${MONO};color:#f2e9d8;flex:none;box-sizing:border-box}
.sd-chip i{width:11px;height:11px;border-radius:50%;background:var(--c);display:block;box-shadow:0 0 0 1.5px rgba(0,0,0,.3)}
.sd-chip.me{border-color:#e3ae45}
.sd-chip.pop{animation:sdpop .7s}
.sd-chip.miss{animation:sdmiss .5s}
@keyframes sdpop{0%{transform:scale(1.3);background:var(--c)}100%{transform:scale(1)}}
@keyframes sdmiss{0%,100%{transform:none}30%{transform:translateX(-3px)}60%{transform:translateX(3px)}}
.sd-goal{font:600 12px/1.35 ${FONT};color:#ab9fb8;flex:1 1 auto;min-width:0}
.sd-goal b{color:#e3ae45;font-weight:700}
.sd-hint{min-width:84px;padding:0 10px !important;font-size:14px}
.sd-hint[disabled]{opacity:.45}
.sd-zoom{width:48px;padding:0 !important;font:700 14px ${MONO}}
.sd-card{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:4;width:min(300px,86%);box-sizing:border-box;padding:16px 16px 14px;border-radius:18px;background:rgba(23,19,31,.94);border:1px solid rgba(227,174,69,.5);box-shadow:0 10px 30px rgba(0,0,0,.45);color:#f2e9d8;text-align:center;pointer-events:none;font-family:${FONT}}
.sd-card .k{font:700 12px ${MONO};color:#e3ae45;letter-spacing:.06em}
.sd-card h3{margin:4px 0 2px;font:400 30px "Black Han Sans",${FONT}}
.sd-card .s{font-size:13px;color:#ab9fb8;margin-top:2px}
.sd-card .big{font:700 46px ${MONO};color:#e3ae45;line-height:1.1;margin-top:6px}
.sd-card .rows{display:flex;flex-direction:column;gap:5px;margin-top:10px;text-align:left}
.sd-card .row{display:flex;align-items:center;gap:8px;font-size:14px}
.sd-card .row i{width:12px;height:12px;border-radius:50%;background:var(--c);flex:none}
.sd-card .row .n{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sd-card .row .p{font:700 14px ${MONO};color:#8fe3a8}
.sd-card .row .t{font:700 14px ${MONO};color:#f2e9d8;min-width:30px;text-align:right}
.sd-card .stars{font-size:34px;color:#e3ae45;letter-spacing:4px;margin-top:6px}
.sd-tip{position:absolute;left:50%;transform:translate(-50%,6px);top:58px;z-index:5;width:max-content;max-width:calc(100% - 28px);box-sizing:border-box;padding:10px 14px;border-radius:14px;background:rgba(23,19,31,.97);border:1px solid rgba(227,174,69,.55);box-shadow:0 6px 20px rgba(0,0,0,.35);color:#f2e9d8;font:600 13px/1.45 ${FONT};text-align:center;word-break:keep-all;pointer-events:none;opacity:0;transition:opacity .4s,transform .4s}
.sd-tip.on{opacity:1;transform:translate(-50%,0)}
.sd-tip b{display:block;color:#e3ae45;font-weight:800;margin-bottom:2px}
`;
  const ZOOMS = [1, 2, 3];

  function mount(root, api) {
    const h = L.h;
    let H = 660; // picture height of the current scene (taller on tall portrait screens)
    const styleEl = h('style', { text: CSS }); root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    cv.cv.style.touchAction = 'none';
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const host = () => !api.online || api.isHost;
    const me = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const nameOf = (i) => (api.players[i] && api.players[i].name) || (st && st.nm[i]) || (i + 1) + '번';
    const colOf = (i) => (api.players[i] && api.players[i].color) || '#e3ae45';

    // DOM HUD
    const rdEl = h('span', { class: 'sd-rd' }), thEl = h('span', { class: 'sd-th' }), dotsEl = h('div', { class: 'sd-dots' }), timeEl = h('span', { class: 'sd-time' });
    const top = h('div', { class: 'sd-top' }, rdEl, thEl, dotsEl, timeEl);
    const chips = h('div', { class: 'sd-chips' });
    const hintBtn = h('button', { 'data-action': 'hint', class: 'btn sd-hint', 'aria-label': '힌트', onclick: () => doHint() });
    const zoomBtn = h('button', { 'data-action': 'zin', class: 'btn sd-zoom', 'aria-label': '확대 바꾸기', onclick: () => cycleZoom() });
    const bar = h('div', { class: 'sd-bar' }, chips, hintBtn, zoomBtn);
    root.append(top, bar);
    let card = null, cardSig = '';

    let st = null, scene = null, sceneKey = '', rects = [], scl = 1;
    const mem = { key: null, clock: 0, pub: 0, ai: {} };
    let elBase = 0, elAt = performance.now(), phaseAt = performance.now(), phaseKey = '';
    let z = 1, vx = W / 2, vy = H / 2;
    let base = [null, null], sharp = [null, null], sharpSig = '', viewMovedAt = 0;
    let lockUntil = 0, lockDur = 0, missStreak = 0, lastMissAt = 0;
    const misses = [], pops = [], pending = {};
    let hintFx = null, lastId = -1, prevF = '', tip = null, tipShown = false, lastTick = -1;
    const cursor = { x: W / 2, y: H / 2, on: false };

    function phaseClock() { // ms in the current phase (host = authoritative)
      if (!st) return 0;
      if (host()) return mem.key === st.rid + '.' + st.rd + '.' + st.ph ? mem.clock : (st.ph === 'play' ? st.el : 0);
      if (st.ph === 'play') return elBase + (performance.now() - elAt) * SPD();
      return (performance.now() - phaseAt) * SPD();
    }

    /* ----- layout & caches ----- */
    function layout() {
      const Wc = cv.w, Hc = cv.h, topH = 46, barH = 62, gap = 10;
      const a0 = topH + 2, a1 = Hc - barH - 2;
      let iw, ih;
      if (Wc > Hc * 1.15) { // wide window: side by side
        iw = Math.min((Wc - 24 - gap) / 2, (a1 - a0) * W / H); ih = iw * H / W;
        const x = (Wc - iw * 2 - gap) / 2, y = a0 + (a1 - a0 - ih) / 2;
        rects = [{ x, y, w: iw, h: ih }, { x: x + iw + gap, y, w: iw, h: ih }];
      } else {
        ih = Math.min((a1 - a0 - gap) / 2, (Wc - 14) * H / W); iw = ih * W / H;
        const x = (Wc - iw) / 2, y = a0 + Math.max(0, (a1 - a0 - ih * 2 - gap) / 2);
        rects = [{ x, y, w: iw, h: ih }, { x, y: y + ih + gap, w: iw, h: ih }];
      }
      scl = iw / W;
      base = [null, null]; sharp = [null, null]; sharpSig = '';
    }
    cv.onresize = layout;
    function bestEx() { // extra picture height that fills a tall portrait screen (0 on wide/short screens)
      const Wc = cv.w, Hc = cv.h;
      if (!(Wc > 0 && Hc > 0) || Wc > Hc * 1.15) return 0;
      const ah = (Hc - 46 - 62 - 4 - 10) / 2, aw = Wc - 14;
      return Math.max(0, Math.min(300, Math.floor((1000 * ah / aw - 660) / 20) * 20));
    }
    function ensureScene() {
      if (!st) return;
      const key = st.sd + '.' + st.th + '.' + st.k + '.' + st.dv + '.' + (st.ex | 0);
      if (key === sceneKey) return;
      sceneKey = key; scene = sceneOf(st);
      if (scene.hh !== H) { H = scene.hh; layout(); }
      base = [null, null]; sharp = [null, null]; sharpSig = '';
      z = 1; vx = W / 2; vy = H / 2; cursor.x = W / 2; cursor.y = H / 2;
    }
    function mkCanvas(w, hh) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(hh)); return c; }
    function buildBase(side) {
      const r = rects[side]; if (!r || !scene) return null;
      const f = Math.min(1.6, 2400 / (r.w * cv.dpr));
      const c = mkCanvas(r.w * cv.dpr * f, r.h * cv.dpr * f);
      const g = c.getContext('2d'); g.setTransform(c.width / W, 0, 0, c.height / H, 0, 0);
      paintScene(g, scene, side);
      return c;
    }
    function buildSharp(side) {
      const r = rects[side];
      const c = mkCanvas(r.w * cv.dpr, r.h * cv.dpr), g = c.getContext('2d');
      const k = c.width / W * z;
      g.setTransform(k, 0, 0, k, -(vx - W / (2 * z)) * k, -(vy - H / (2 * z)) * k);
      paintScene(g, scene, side);
      return c;
    }
    function clampView() {
      z = Math.max(1, Math.min(3, z));
      const hw = W / (2 * z), hh = H / (2 * z);
      vx = Math.max(hw, Math.min(W - hw, vx)); vy = Math.max(hh, Math.min(H - hh, vy));
      viewMovedAt = performance.now();
    }
    // logical (picture) → screen, and back
    const toS = (side, lx, ly) => { const r = rects[side]; return { x: r.x + (lx - (vx - W / (2 * z))) * scl * z, y: r.y + (ly - (vy - H / (2 * z))) * scl * z }; };
    const toL = (side, sx, sy) => { const r = rects[side]; return { x: vx - W / (2 * z) + (sx - r.x) / (scl * z), y: vy - H / (2 * z) + (sy - r.y) / (scl * z) }; };
    const sideAt = (x, y) => { for (let i = 0; i < 2; i++) { const r = rects[i]; if (r && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return i; } return -1; };

    /* ----- input ----- */
    const ptrs = new Map();
    let gest = null;
    function onDown(e) {
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      const p = cv.local(e);
      cursor.on = false;
      ptrs.set(e.pointerId, { x: p.x, y: p.y, sx: p.x, sy: p.y, t: performance.now() });
      if (ptrs.size === 1) gest = { moved: false, pinch: false, side: sideAt(p.x, p.y) };
      else if (ptrs.size === 2) startPinch();
    }
    function startPinch() {
      const a = [...ptrs.values()];
      const mx = (a[0].x + a[1].x) / 2, my = (a[0].y + a[1].y) / 2;
      let side = sideAt(mx, my); if (side < 0) side = gest && gest.side >= 0 ? gest.side : 0;
      gest = { moved: true, pinch: true, side, d0: Math.max(10, Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y)), z0: z, m: toL(side, mx, my) };
    }
    function onMove(e) {
      const q = ptrs.get(e.pointerId); if (!q) return;
      const p = cv.local(e);
      const dx = p.x - q.x, dy = p.y - q.y; q.x = p.x; q.y = p.y;
      if (!gest) return;
      if (gest.pinch && ptrs.size >= 2) {
        const a = [...ptrs.values()];
        const mx = (a[0].x + a[1].x) / 2, my = (a[0].y + a[1].y) / 2;
        z = gest.z0 * Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) / gest.d0;
        z = Math.max(1, Math.min(3, z));
        const r = rects[gest.side];
        vx = gest.m.x - (mx - r.x) / (scl * z) + W / (2 * z); vy = gest.m.y - (my - r.y) / (scl * z) + H / (2 * z);
        clampView();
        return;
      }
      if (!gest.moved && Math.hypot(p.x - q.sx, p.y - q.sy) > 9) gest.moved = true;
      if (gest.moved && !gest.pinch && z > 1.001) { vx -= dx / (scl * z); vy -= dy / (scl * z); clampView(); }
    }
    function onUp(e) {
      const q = ptrs.get(e.pointerId); if (!q) return;
      ptrs.delete(e.pointerId);
      if (gest && !gest.moved && !gest.pinch && ptrs.size === 0 && performance.now() - q.t < 700) {
        const side = sideAt(q.x, q.y);
        if (side >= 0) { const l = toL(side, q.x, q.y); tapAt(side, l.x, l.y); }
      }
      if (ptrs.size === 0) gest = null;
      else if (gest && gest.pinch) gest = { moved: true, pinch: false, side: gest.side }; // one finger left: no tap
    }
    function onWheel(e) {
      e.preventDefault();
      const p = cv.local(e), side = sideAt(p.x, p.y); if (side < 0) return;
      zoomAt(side, p.x, p.y, e.deltaY < 0 ? 1.25 : 0.8);
    }
    function zoomAt(side, sx, sy, f) {
      const m = toL(side, sx, sy), r = rects[side];
      z = Math.max(1, Math.min(3, z * f));
      vx = m.x - (sx - r.x) / (scl * z) + W / (2 * z); vy = m.y - (sy - r.y) / (scl * z) + H / (2 * z);
      clampView(); syncZoomBtn();
    }
    function cycleZoom() {
      const i = ZOOMS.findIndex((v) => v > z + 0.05);
      const nz = i < 0 ? 1 : ZOOMS[i];
      const cx = cursor.on ? cursor.x : vx, cy = cursor.on ? cursor.y : vy;
      z = nz; vx = cx; vy = cy; clampView(); syncZoomBtn(); api.sfx('click');
    }
    function syncZoomBtn() { const t = (Math.round(z * 10) / 10) + '×'; if (zoomBtn.textContent !== t) zoomBtn.textContent = t; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('wheel', onWheel, { passive: false });
    cv.cv.addEventListener('contextmenu', noCtx);
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'tap') { if (!cursor.on) { cursor.on = true; cursor.x = vx; cursor.y = vy; return; } tapAt(0, cursor.x, cursor.y); }
      else if (id === 'hint') doHint();
      else if (id === 'zin' || id === 'zout') { if (!cursor.on) { cursor.x = vx; cursor.y = vy; } const s0 = toS(0, cursor.x, cursor.y); zoomAt(0, s0.x, s0.y, id === 'zin' ? 1.5 : 1 / 1.5); }
    }) : () => {};

    const canPlay = () => st && st.ph === 'play' && me() >= 0;
    function tapAt(side, lx, ly) {
      if (!canPlay() || !scene) return;
      const now = performance.now();
      if (now < lockUntil) { api.buzz(20); return; }
      const slop = 12 / (scl * z);
      let best = -1, bd = 1e18;
      scene.diffs.forEach((d, i) => { const dx = lx - d.x, dy = ly - d.y, d2 = dx * dx + dy * dy, lim = d.rr + slop; if (d2 <= lim * lim && d2 < bd) { bd = d2; best = i; } });
      if (best >= 0) {
        if (st.f[best] !== '-' || pending[best]) return; // already circled: no penalty
        pending[best] = { t: now, n: 1 };
        missStreak = 0;
        api.sfx('pop'); api.buzz(18);
        api.act({ t: 'hit', i: best });
        return;
      }
      if (now - lastMissAt > 6000) missStreak = 0;
      missStreak++; lastMissAt = now;
      lockDur = Math.min(4000, 1500 + (missStreak - 1) * 1000);
      lockUntil = now + lockDur;
      misses.push({ side, x: lx, y: ly, t: now });
      api.act({ t: 'miss' });
      api.sfx('thud'); api.buzz(60);
      const c = chips.querySelector('.sd-chip.me'); if (c) { c.classList.remove('miss'); void c.offsetWidth; c.classList.add('miss'); }
    }
    function hintReady() { return canPlay() && st.hn[me()] > 0 && phaseClock() >= HINT_AFTER && st.f.indexOf('-') >= 0; }
    function doHint() {
      if (!canPlay()) return;
      if (st.hn[me()] <= 0) { api.toast('힌트를 다 썼어요'); return; }
      if (phaseClock() < HINT_AFTER) { api.toast('힌트는 시작 ' + (HINT_AFTER / 1000) + '초 뒤부터 쓸 수 있어요'); return; }
      api.sfx('whoosh'); api.act({ t: 'hint' });
    }

    /* ----- host loop: clock, AI, phases ----- */
    function aiLv() { return api.players.map((p) => (p && p.ai ? (p.lv || 2) : 0)); }
    function hostFrame(dtMs) {
      if (!st || !host()) return;
      let ns = null;
      try { ns = hostStep(st, mem, dtMs, aiLv()); } catch (e) { console.error(e); }
      if (ns) api.setState(ns);
    }

    /* ----- HUD ----- */
    function fmt(ms) { const s = Math.max(0, Math.ceil(ms / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
    let chipSig = '';
    function renderHud() {
      if (!st) return;
      rdEl.textContent = st.md === 'e' ? 'S' + st.rd : st.rd + '/' + st.R;
      thEl.textContent = THEMES[st.th].name;
      const ds = st.f.split('').map((c) => (c === '-' ? '' : colOf(+c))).join(',');
      if (dotsEl.dataset.sig !== ds) {
        dotsEl.dataset.sig = ds; dotsEl.innerHTML = '';
        st.f.split('').forEach((c) => dotsEl.append(h('i', { class: c === '-' ? '' : 'on', style: c === '-' ? {} : { '--c': colOf(+c) } })));
      }
      const m = me();
      const sig = st.n + '|' + st.sc.join(',') + '|' + m + '|' + api.players.map((p) => p && p.color).join(',') + '|' + (st.n === 1 ? st.ss.join('') + st.k + '.' + st.rd + '.' + (st.cl || 0) : '');
      if (sig !== chipSig) {
        chipSig = sig; chips.innerHTML = '';
        if (st.md === 'e') {
          chips.append(h('div', { class: 'sd-goal' }, h('b', { text: '스테이지 ' + st.rd }), ' · 깬 곳 ' + st.cl, h('br'), '시간 안에 ' + st.k + '개 모두 찾기'));
        } else if (st.n === 1) {
          const k = st.k;
          chips.append(h('div', { class: 'sd-goal' }, h('b', { text: '★★★ ' + Math.floor(k * 5.5) + '초' }), ' · ★★ ' + (k * 10) + '초 안에 모두', h('br'), '모은 별 ' + st.ss.reduce((a, b) => a + b, 0) + '개'));
        } else {
          for (let i = 0; i < st.n; i++) chips.append(h('span', { class: 'sd-chip' + (i === m ? ' me' : ''), title: nameOf(i), 'data-s': i, style: { '--c': colOf(i) } }, h('i'), String(st.sc[i])));
        }
      }
      const showHint = m >= 0;
      hintBtn.hidden = !showHint;
      if (showHint) {
        const left = st.hn[m];
        const t = '힌트 ' + left;
        if (hintBtn.textContent !== t) hintBtn.textContent = t;
        const dis = !hintReady();
        if (hintBtn.disabled !== dis) hintBtn.disabled = dis;
      }
      syncZoomBtn();
    }
    function renderTime() {
      if (!st) return;
      let t = '', low = false;
      if (st.ph === 'play') { const left = st.lim * 1000 - phaseClock(); t = fmt(left); low = left < 10500; }
      else if (st.ph === 'count') t = fmt(st.lim * 1000);
      else if (st.ph === 'end' || st.ph === 'done') t = fmt(st.lim * 1000 - st.el);
      if (timeEl.textContent !== t) timeEl.textContent = t;
      timeEl.classList.toggle('low', low);
      if (st.ph === 'play' && hintBtn.disabled === hintReady() && me() >= 0) hintBtn.disabled = !hintReady();
    }
    function setCard(sig, build) {
      if (sig === cardSig) return;
      cardSig = sig;
      if (card) { card.remove(); card = null; }
      if (build) { card = build(); root.appendChild(card); }
    }
    function renderCard() {
      if (!st) return;
      const pc = phaseClock();
      if (st.ph === 'count') {
        const n = Math.max(1, Math.ceil((COUNT_MS - pc) / 1000));
        setCard('c' + st.rid + st.rd + n, () => h('div', { class: 'sd-card' },
          h('div', { class: 'k', text: st.md === 'e' ? '스테이지 ' + st.rd + ' · 난이도 ' + '●'.repeat(st.dv + 1) + '○'.repeat(3 - st.dv) : '라운드 ' + st.rd + ' / ' + st.R }),
          h('h3', { text: THEMES[st.th].name }),
          h('div', { class: 's', text: '다른 곳 ' + st.k + '개를 찾아요' + (st.n === 1 ? '' : ' · 먼저 찾으면 내 것!') }),
          h('div', { class: 'big', text: String(n) })));
        if (n !== lastTick) { lastTick = n; api.sfx('tick'); }
      } else if (st.ph === 'end') {
        const left = Math.max(1, Math.ceil((END_MS - pc) / 1000));
        const lastR = st.md === 'e' ? !allFound(st) : st.rd >= st.R;
        setCard('e' + st.rid + st.rd + left, () => {
          const f = st.f;
          if (st.md === 'e') {
            const ok = allFound(st);
            return h('div', { class: 'sd-card' },
              h('div', { class: 'k', text: '스테이지 ' + st.rd + (ok ? ' 클리어!' : ' 실패') }),
              h('div', { class: 'stars', text: ok ? '✓' : '✕' }),
              h('div', { class: 's', text: ok ? (st.el / 1000).toFixed(1) + '초' + (st.hu ? ' (힌트 +' + st.hu * HINT_SOLO_PEN + '초)' : '') + ' · 깬 스테이지 ' + st.cl : '시간 초과 · ' + st.f.split('').filter((c) => c !== '-').length + ' / ' + st.k + '개' }),
              h('div', { class: 's', text: lastR ? '결과를 보여 줄게요… ' + left : '다음 스테이지 ' + left + (st.cl % 3 === 0 && st.hn[0] < 5 ? ' · 힌트 +1' : '') }));
          }
          if (st.n === 1) {
            const v = st.ss[st.ss.length - 1] || 0;
            return h('div', { class: 'sd-card' },
              h('div', { class: 'k', text: '라운드 ' + st.rd + ' 끝' }),
              h('div', { class: 'stars', text: '★'.repeat(v) + '☆'.repeat(3 - v) }),
              h('div', { class: 's', text: (allFound(st) ? '모두 찾았어요 · ' + (st.el / 1000).toFixed(1) + '초' : '시간 초과 · ' + f.split('').filter((c) => c !== '-').length + ' / ' + st.k + '개') + (st.hu ? ' (힌트 +' + st.hu * HINT_SOLO_PEN + '초)' : '') }),
              h('div', { class: 's', text: lastR ? '결과를 보여 줄게요… ' + left : '다음 라운드 ' + left }));
          }
          const order = st.sc.map((v, i) => i).sort((a, b) => st.sc[b] - st.sc[a]);
          return h('div', { class: 'sd-card' },
            h('div', { class: 'k', text: '라운드 ' + st.rd + ' 끝' + (allFound(st) ? '' : ' · 시간 초과') }),
            h('div', { class: 'rows' }, order.map((i) => {
              const got = f.split('').filter((c) => c === String(i)).length;
              return h('div', { class: 'row' }, h('i', { style: { '--c': colOf(i) } }), h('span', { class: 'n', text: nameOf(i) + (i === me() ? ' (나)' : '') }), h('span', { class: 'p', text: got ? '+' + got : '' }), h('span', { class: 't', text: String(st.sc[i]) }));
            })),
            h('div', { class: 's', style: { marginTop: '8px' }, text: lastR ? '결과를 보여 줄게요… ' + left : '다음 라운드 ' + left }));
        });
      } else setCard('', null);
    }

    /* ----- drawing ----- */
    function ring(x, y, r, col, w, dash) {
      ctx.setLineDash(dash || []);
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.lineWidth = w + 3; ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.stroke();
      ctx.lineWidth = w; ctx.strokeStyle = col; ctx.stroke();
      ctx.setLineDash([]);
    }
    function draw(now) {
      const Wc = cv.w, Hc = cv.h;
      ctx.clearRect(0, 0, Wc, Hc);
      const bg = ctx.createLinearGradient(0, 0, 0, Hc); bg.addColorStop(0, '#1d1727'); bg.addColorStop(1, '#17131f');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, Wc, Hc);
      if (!st || !scene || !rects.length) return;
      const hideImgs = st.ph === 'count';
      // sharp redraw once the view settles
      const sig = sceneKey + '|' + z.toFixed(3) + '|' + vx.toFixed(1) + '|' + vy.toFixed(1) + '|' + rects[0].w;
      if (z > 1.01 && sig !== sharpSig && now - viewMovedAt > 140 && !hideImgs) { sharp = [buildSharp(0), buildSharp(1)]; sharpSig = sig; }
      for (let side = 0; side < 2; side++) {
        const r = rects[side];
        ctx.save();
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(r.x, r.y, r.w, r.h, 8) : ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
        if (hideImgs) {
          ctx.fillStyle = '#2e2640'; ctx.fillRect(r.x, r.y, r.w, r.h);
          ctx.fillStyle = 'rgba(227,174,69,.12)'; ctx.font = '700 ' + Math.round(r.h * 0.35) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('?', r.x + r.w / 2, r.y + r.h / 2);
        } else {
          if (!base[side]) base[side] = buildBase(side);
          if (z > 1.01 && sharp[side] && sig === sharpSig) ctx.drawImage(sharp[side], r.x, r.y, r.w, r.h);
          else { const b = base[side], k = b.width / W; ctx.drawImage(b, (vx - W / (2 * z)) * k, (vy - H / (2 * z)) * k, W / z * k, H / z * k, r.x, r.y, r.w, r.h); }
          drawMarks(side, now);
        }
        ctx.restore();
        ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(227,174,69,.7)';
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(r.x - 1, r.y - 1, r.w + 2, r.h + 2, 9) : ctx.rect(r.x - 1, r.y - 1, r.w + 2, r.h + 2); ctx.stroke();
        if (z > 1.01) { // mini map: where the zoomed view is
          const mw = 54, mh = mw * H / W, mx = r.x + r.w - mw - 6, my = r.y + 6;
          ctx.fillStyle = 'rgba(23,19,31,.6)'; ctx.fillRect(mx, my, mw, mh);
          ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.strokeRect(mx + (vx - W / (2 * z)) / W * mw, my + (vy - H / (2 * z)) / H * mh, mw / z, mh / z);
        }
      }
      // penalty veil
      if (now < lockUntil && st.ph === 'play') {
        const left = (lockUntil - now) / 1000;
        for (const r of rects) { ctx.fillStyle = 'rgba(30,20,40,.35)'; ctx.fillRect(r.x, r.y, r.w, r.h); }
        const r0 = rects[0], r1 = rects[1];
        const cx = (r0.x + r1.x + r1.w) / 2, cy = r0.y === r1.y ? r0.y + r0.h / 2 : (r0.y + r0.h + r1.y) / 2;
        const t = '틀렸어요! ' + left.toFixed(1) + '초';
        ctx.font = '700 15px ' + FONT; const tw = ctx.measureText(t).width + 28;
        ctx.fillStyle = 'rgba(238,106,85,.95)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(cx - tw / 2, cy - 17, tw, 34, 17) : ctx.rect(cx - tw / 2, cy - 17, tw, 34); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, cx, cy + 1);
        const w = tw - 24; ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.fillRect(cx - w / 2, cy + 12, w * Math.max(0, (lockUntil - now) / lockDur), 2);
      }
    }
    function drawMarks(side, now) {
      const k = scl * z;
      // found circles
      scene.diffs.forEach((d, i) => {
        const c = st.f[i];
        const p = toS(side, d.x, d.y), rr = d.rr * k + 4;
        if (c !== '-') {
          const pp = pops.find((q) => q.i === i);
          let sc = 1; if (pp) { const a = Math.min(1, (now - pp.t) / 320); sc = 1 + (1 - a) * (1 - a) * 0.7; }
          ring(p.x, p.y, rr * sc, colOf(+c), 3.5);
        } else if (pending[i]) ring(p.x, p.y, rr, colOf(me()), 3, [6, 5]);
        else if (st.ph === 'end' || st.ph === 'done') { const a = 0.55 + 0.45 * Math.sin(now / 160); ctx.globalAlpha = a; ring(p.x, p.y, rr, '#ee6a55', 3, [7, 5]); ctx.globalAlpha = 1; }
      });
      // name tags of fresh finds
      for (const q of pops) {
        const age = now - q.t; if (age > 1500) continue;
        const d = scene.diffs[q.i], p = toS(side, d.x, d.y), rr = d.rr * k + 4;
        const t = q.s === me() ? '찾았다!' : nameOf(q.s);
        ctx.globalAlpha = Math.min(1, (1500 - age) / 300);
        ctx.font = '700 12px ' + FONT; const tw = ctx.measureText(t).width + 12;
        const y = p.y - rr - 12 - Math.min(1, age / 400) * 6;
        ctx.fillStyle = colOf(q.s); ctx.beginPath(); ctx.roundRect ? ctx.roundRect(p.x - tw / 2, y - 10, tw, 20, 10) : ctx.rect(p.x - tw / 2, y - 10, tw, 20); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, p.x, y + 1);
        ctx.globalAlpha = 1;
      }
      // misses
      for (const m of misses) {
        const age = now - m.t; if (age > 900 || m.side !== side) continue;
        const p = toS(side, m.x, m.y), s = 11;
        ctx.globalAlpha = 1 - age / 900; ctx.lineCap = 'round';
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(p.x - s, p.y - s); ctx.lineTo(p.x + s, p.y + s); ctx.moveTo(p.x + s, p.y - s); ctx.lineTo(p.x - s, p.y + s); ctx.stroke();
        ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 4; ctx.stroke();
        ctx.globalAlpha = 1;
      }
      // hint ring
      if (hintFx && now - hintFx.t < 4500 && st.ph === 'play' && st.f[hintFx.i] === '-') {
        const p = toS(side, hintFx.x, hintFx.y), base = hintFx.r * k;
        const a = (now - hintFx.t) / 650;
        ctx.globalAlpha = 0.6 + 0.4 * Math.sin(a * Math.PI);
        ring(p.x, p.y, base * (1 + 0.08 * Math.sin(a * TAU)), '#e3ae45', 4, [10, 7]);
        ctx.globalAlpha = 1;
      }
      // keyboard / pad cursor
      if (cursor.on && st.ph === 'play') {
        const p = toS(side, cursor.x, cursor.y);
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(p.x, p.y, 12, 0, TAU); ctx.moveTo(p.x - 20, p.y); ctx.lineTo(p.x - 6, p.y); ctx.moveTo(p.x + 6, p.y); ctx.lineTo(p.x + 20, p.y); ctx.moveTo(p.x, p.y - 20); ctx.lineTo(p.x, p.y - 6); ctx.moveTo(p.x, p.y + 6); ctx.lineTo(p.x, p.y + 20); ctx.stroke();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.stroke();
      }
    }

    /* ----- frame ----- */
    function frame(rdt, now) {
      if (!st) return;
      hostFrame(rdt * 1000 * SPD());
      // keyboard / pad cursor movement
      if (api.input && canPlay()) {
        const ax = api.input.axis('left', 'right'), ay = api.input.axis('up', 'down');
        if (ax || ay) {
          if (!cursor.on) { cursor.on = true; cursor.x = vx; cursor.y = vy; }
          const sp = 460 / z;
          cursor.x = Math.max(0, Math.min(W, cursor.x + ax * sp * rdt)); cursor.y = Math.max(0, Math.min(H, cursor.y + ay * sp * rdt));
          if (z > 1.01) { const hw = W / (2 * z) * 0.8, hh = H / (2 * z) * 0.8; if (cursor.x < vx - hw) vx = cursor.x + hw; if (cursor.x > vx + hw) vx = cursor.x - hw; if (cursor.y < vy - hh) vy = cursor.y + hh; if (cursor.y > vy + hh) vy = cursor.y - hh; clampView(); }
        }
      }
      // pending claims: resend if lost, clear when decided
      for (const k in pending) {
        const i = +k, p = pending[k];
        if (!st || st.ph !== 'play') { delete pending[k]; continue; }
        if (st.f[i] !== '-') { delete pending[k]; continue; }
        if (now - p.t > 900) { if (p.n >= 4) { delete pending[k]; continue; } p.t = now; p.n++; api.act({ t: 'hit', i }); }
      }
      while (misses.length && now - misses[0].t > 1000) misses.shift();
      while (pops.length && now - pops[0].t > 1600) pops.shift();
      // first-play tip (once per device), during the first countdown
      if (!tipShown && st.ph === 'count' && st.rd === 1 && me() >= 0) { tipShown = true; tip = firstTip(); }
      if (tip && st.ph === 'play' && phaseClock() > 1000) tip.hide(); // 첫 안내는 시작 1초 안에 걷힘(판을 가리지 않게)
      renderTime(); renderCard();
    }
    function firstTip() {
      try { if (localStorage.getItem('lounge.tip.spotdiff')) return null; localStorage.setItem('lounge.tip.spotdiff', '1'); } catch (e) { /* storage blocked */ }
      const el = h('div', { class: 'sd-tip', role: 'status' }, h('b', { text: '처음이라면 이렇게!' }),
        h('div', { text: '위·아래 그림에서 다른 곳을 톡! (어느 그림이든 OK)' }),
        h('div', { text: '두 손가락으로 크게 · 틀리면 잠깐 못 눌러요' }));
      root.appendChild(el);
      requestAnimationFrame(() => el.classList.add('on'));
      let gone = false;
      const hide = () => { if (gone) return; gone = true; el.classList.remove('on'); setTimeout(() => el.remove(), 450); };
      const tm = setTimeout(hide, 7000);
      return { hide, remove() { clearTimeout(tm); gone = true; el.remove(); } };
    }

    function saveBest() {
      try {
        if (st.md === 'e') {
          let nw = api.best('stage', st.cl, { label: '끝없는 스테이지 최고', unit: '스테이지' });
          if (st.fs) nw = api.best('fast', st.fs / 10, { label: '가장 빠른 스테이지', lower: true, fmt: 'time' }) || nw;
          if (nw) api.toast('🏆 새 최고 기록!');
        } else {
          const tot = st.ss.reduce((a, b) => a + b, 0);
          if (tot > 0 && api.best('stars' + st.R, tot, { label: '별 타임어택(' + st.R + '라운드) 최고', unit: '별' })) api.toast('🏆 새 최고 기록!');
        }
      } catch (e) { console.error(e); }
    }
    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });
    layout();

    return {
      update(next) {
        if (!next) return;
        const was = st; st = next;
        const pk = st.rid + '.' + st.rd + '.' + st.ph;
        if (pk !== phaseKey) {
          phaseKey = pk; phaseAt = performance.now(); lastTick = -1;
          if (st.ph === 'play') { api.sfx('whoosh'); lockUntil = 0; missStreak = 0; }
          if (st.ph === 'end' && was && was.ph === 'play') api.sfx(allFound(st) ? 'chip' : 'lose');
          if (st.ph === 'done' && was && was.ph !== 'done' && st.n === 1 && me() === 0 && api.best) saveBest();
          if (st.ph === 'count') { hintFx = null; for (const k in pending) delete pending[k]; misses.length = 0; pops.length = 0; }
        }
        if (st.ph === 'play' && (!was || was.el !== st.el || was.ph !== 'play')) { elBase = st.el || 0; elAt = performance.now(); }
        if (host() && st.ex == null && st.ph === 'count' && st.rd === 1) {
          const ex = bestEx();
          api.setState(Object.assign(JSON.parse(JSON.stringify(st)), { ex }));
          return;
        }
        ensureScene();
        // fresh finds → pop animation + who found it
        if (was && was.rid === st.rid && was.rd === st.rd && was.f.length === st.f.length) {
          for (let i = 0; i < st.f.length; i++) {
            if (was.f[i] === '-' && st.f[i] !== '-') {
              const s = +st.f[i];
              pops.push({ i, s, t: performance.now() });
              const mine = s === me();
              if (mine) { api.sfx('chip'); }
              else {
                api.sfx('click');
                if (pending[i]) api.toast('아깝다! ' + nameOf(s) + ' 님이 먼저 찾았어요');
              }
              const c = chips.querySelector('.sd-chip[data-s="' + s + '"]'); if (c) { c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop'); }
            }
          }
        }
        const lid = st.last ? st.last.id : 0;
        if (lastId < 0) lastId = lid; // first render: don't replay old events
        else if (lid !== lastId) {
          lastId = lid;
          if (st.last.k === 'hint' && st.last.s === me() && scene && st.ph === 'play') {
            const d = scene.diffs[st.last.i];
            // a loose ring around the area (not the exact spot)
            const R = rng(st.sd + st.last.id * 31);
            const ang = R() * TAU, off = d.rr * (0.4 + R() * 0.5);
            hintFx = { i: st.last.i, x: d.x + Math.cos(ang) * off, y: d.y + Math.sin(ang) * off, r: d.rr * 2.3 + 24, t: performance.now() };
            api.toast(st.n === 1 ? '이 근처에 있어요! (+' + HINT_SOLO_PEN + '초)' : '이 근처에 있어요!');
          }
        }
        prevF = st.f;
        renderHud(); renderTime(); renderCard();
        void prevF;
      },
      destroy() {
        stopLoop(); offIn();
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('wheel', onWheel); cv.cv.removeEventListener('contextmenu', noCtx);
        if (tip) tip.remove(); if (card) card.remove();
        top.remove(); bar.remove(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ st, scene, rects, z, vx, vy, mem, tapAt, toS, lock: lockUntil }),
    };
  }

  /* ======================= registration ======================= */
  L.register({
    id: 'spotdiff', name: '다른 그림 찾기 대결', tag: '눈썰미 레이스', cat: '파티',
    blurb: '똑같아 보이는 두 그림에서 다른 곳을 먼저 찾는 사람이 임자! 장소 34곳, 매번 새 그림을 모두 동시에 봐요. 혼자 하면 끝없는 스테이지(최고 기록 저장)나 별 타임어택. 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#1f5a6e',
    icon: '<rect x="8" y="5" width="40" height="20" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><rect x="8" y="31" width="40" height="20" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="19" cy="15" r="4" fill="currentColor"/><circle cx="19" cy="41" r="4" fill="currentColor"/><path d="M36 10l-5 9h10z" fill="currentColor"/><circle cx="36" cy="41" r="7" fill="none" stroke="currentColor" stroke-width="2.5"/>',
    minPlayers: 1, maxPlayers: 8, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'left', label: '커서 왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '커서 오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'up', label: '커서 위', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '커서 아래', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'tap', label: '여기 콕! (찍기)', keys: ['Space', 'Enter'], pad: ['a'] },
      { id: 'hint', label: '힌트', keys: ['KeyH'], pad: ['y'] },
      { id: 'zin', label: '확대', keys: ['KeyE', 'Equal', 'NumpadAdd'], pad: ['rb'] },
      { id: 'zout', label: '축소', keys: ['KeyQ', 'Minus', 'NumpadSubtract'], pad: ['lb'] },
    ],
    options: [
      { id: 'solo', label: '혼자 할 때', tip: '혼자 할 때 방식.', choices: [{ v: 'endless', label: '끝없는 스테이지', tip: '스테이지를 끝없이 이어 가요(최고 기록).' }, { v: 'stars', label: '별 타임어택', tip: '빨리 찾을수록 별을 더 받아요.' }], def: 'endless' },
      { id: 'rounds', label: '라운드', choices: [{ v: 3, label: '3라운드' }, { v: 5, label: '5라운드' }], def: 3 },
      { id: 'time', label: '라운드 시간', choices: [{ v: 60, label: '60초' }, { v: 90, label: '90초' }, { v: 120, label: '120초' }], def: 90 },
      { id: 'theme', label: '장소', tip: '그림 장소.', choices: [{ v: 'mix', label: '무작위(섞어서)' }, { v: 'in', label: '실내만' }, { v: 'out', label: '바깥만' }, { v: 'fan', label: '가게·일터' }].concat(THEMES.map((t) => ({ v: t.id, label: t.name }))), def: 'mix' },
    ],
    quick: [
      '위·아래 두 그림은 거의 같지만 다른 곳이 5~7군데 있어요. 장소 34곳, 매번 새 그림! 모두 같은 그림을 동시에 봐요.',
      '다른 곳을 찾으면 어느 그림이든 그 자리를 톡! 맞으면 두 그림에 내 색 동그라미가 생겨요.',
      '먼저 찾은 사람이 1점. 라운드 3번(또는 5번) 합계가 가장 많은 사람이 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '위·아래 두 그림에서 서로 다른 곳을 남보다 먼저 찾아요. 한 곳 = 1점.',
        '라운드마다 새 그림(장소)이 나오고, 다른 곳은 5개에서 시작해 마지막 라운드엔 7개까지 늘어요.',
        '라운드가 갈수록 어려워져요: 물건이 많아지고, 바뀐 곳이 작아지고, 찾기 까다로운 종류(위치·기울기·무늬·개수·글자)가 섞여요.',
        '모든 라운드가 끝났을 때 점수가 가장 높은 사람이 승리(같으면 공동 승리).',
      ] },
      { h: '찾기', p: [
        '다른 곳이 보이면 위 그림이든 아래 그림이든 그 자리를 톡! 맞으면 두 그림 모두에 내 색 동그라미가 그려져요.',
        '이미 누가 찾은 곳(동그라미)은 다시 눌러도 점수가 없지만, 벌칙도 없어요.',
        '틀린 곳을 누르면 1.5초 동안 못 눌러요. 연달아 틀리면 2.5초, 3.5초… 길어져요(최대 4초). 마구 누르기 금지!',
        '모두 찾거나 시간(기본 90초)이 끝나면 라운드 끝. 못 찾은 곳은 빨간 점선으로 알려 줘요.',
      ] },
      { h: '어떤 게 달라요?', p: [
        '1라운드: 없어진 물건 / 생긴 물건, 색이 바뀐 것, 크기가 바뀐 것, 모양이 살짝 바뀐 것(꽃잎 수, 창문 불빛, 표정 등).',
        '2라운드부터 더: 좌우가 뒤집힌 것, 자리를 옮긴 것, 기울어진 것(액자·간판), 무늬(줄무늬·물방울), 개수(촛불·양초·전등 수), 시계 바늘·글자·숫자.',
        '옮겨진 물건은 원래 자리나 새 자리 어디를 눌러도 정답이에요.',
        '배경(벽·하늘·바닥 무늬)은 두 그림이 늘 똑같아요. 물건만 보면 돼요.',
      ] },
      { h: '확대 · 힌트', p: [
        '두 손가락으로 벌리면 확대, 한 손가락으로 끌면 이동. 두 그림이 같이 움직여요. 오른쪽 아래 「1×」 버튼으로 1× → 2× → 3× 바꿀 수도 있어요.',
        '힌트: 한 게임에 3번. 라운드 시작 8초 뒤부터 쓸 수 있고, 아직 아무도 못 찾은 곳 근처를 금색 점선으로 보여 줘요(나만 보여요).',
        'PC: 마우스 클릭으로 찍고 휠로 확대해요. 키보드·패드는 방향키(스틱)로 커서를 옮기고 스페이스(Ⓐ)로 찍어요. H=힌트, E/Q=확대/축소. 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '혼자 하기 ① 끝없는 스테이지 (기본)', p: [
        '스테이지마다 새 그림. 시간(기본 90초) 안에 다른 곳을 모두 찾으면 다음 스테이지로, 못 찾으면 끝!',
        '갈수록 어려워져요: 다른 곳 5개 → 3스테이지마다 1개씩 늘어 최대 8개, 2스테이지마다 바뀐 곳이 더 작고 은근해져요(난이도 ●○○○ → ●●●●).',
        '힌트는 3번으로 시작, 3스테이지를 깰 때마다 +1(최대 5). 힌트를 쓰면 그 스테이지 기록에 +10초.',
        '깬 스테이지 수와 가장 빠른 스테이지 시간이 「🏆 내 최고 기록」에 남아요.',
      ] },
      { h: '혼자 하기 ② 별 타임어택', p: [
        '설정 「혼자 할 때」를 「별 타임어택」으로 바꾸면 3·5라운드 동안 라운드마다 모두 찾은 시간으로 별을 받아요.',
        '★★★ = 개수 × 5.5초 안 (6개면 33초), ★★ = 개수 × 10초 안, ★ = 시간 안에 모두. 힌트를 쓰면 한 번에 +10초로 계산해요.',
        '모든 라운드에서 별을 1개 이상 받으면 클리어!',
      ] },
      { h: '예시', p: [
        '거실 그림: 위 그림의 쿠션은 빨강인데 아래는 파랑 → 아무 쿠션이나 톡 → 「찾았다!」 +1점.',
        '→ 그런데 AI 2가 0.5초 먼저 찾았다면 「아깝다!」 — 그 점수는 AI 2의 것이에요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '모두 같은 그림을 동시에 보는 경주라서 한 폰에는 한 명만: 혼자 하면 나머지 자리는 AI예요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로(2~8명). 자리를 AI로 채우면 AI와 대결해요.',
        '장소 34곳: 거실·부엌·카페·목공방·사무실·서재·호텔 로비·공항 게이트·교실·도서관·지하철·꽃집·빵집·미술관 / 도심 거리·항구·기차역 플랫폼·시장·야시장·주차장·공사 현장·겨울 마을·바닷가·농장·숲속 캠핑·사막 오아시스·야경 도시·비 오는 거리·정원 / 가게·일터: 병원 대기실·와인 바·세탁소·은행 창구·미용실.',
        '기본은 「무작위(섞어서)」: 라운드마다 다른 장소가 나와요. 「실내만·바깥만·가게·일터」이나 한 장소만 고를 수도 있어요. 같은 장소라도 물건 배치·색·종류가 매번 새로 만들어져요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 혼자 찾을 때 한 곳에 쉬움은 15초쯤(가끔 헤맴), 보통은 10초쯤, 어려움은 6~7초쯤 걸려요. 뒤 라운드일수록 AI도 조금 느려져요.',
      ] },
    ],
    init, actor, apply,
    // never scheduled by core (realtime: the host view runs the AI searchers); kept pure for test tools
    ai(s) { if (!s || s.ph !== 'play') return null; const un = []; for (let i = 0; i < s.k; i++) if (s.f[i] === '-') un.push(i); return un.length ? { t: 'hit', i: un[Math.floor(Math.random() * un.length)] } : null; },
    result, mount,
    _t: { W, H, TY, THEMES, PAL, NEAR, rng, genScene, tryScene, sceneOf, sideObjs, paintScene, kFor, init, actor, apply, hostStep, endRound, nextRound, result, aiPlan, COUNT_MS, END_MS, HINT_AFTER },
  });
})();
