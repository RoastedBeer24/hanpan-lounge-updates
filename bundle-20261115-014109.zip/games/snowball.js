/* 눈싸움 대작전 — realtime top-down snowball fight for 2–8 (each for themselves, or two teams 2:2 / 3:3 / 4:4).
   One person per phone (realtime): alone you play against AI; friends play through online / LAN rooms.
   Hearts: 3 per round, a hit takes one, 0 = out. Last one (team) standing wins the round; first to N round wins.
   Snowballs fly in a real arc (x, y + height z): they pass over low snow walls toward a standing kid's chest, but a kid
   who ducks behind a wall is safe until the wall is knocked down. Scoop snow to make balls (max 3 carried).
   The world engine (movement, balls, walls, power-ups, AI) is pure and lives outside the view so node can run
   headless AI matches. The host (or the local phone) runs it; guests send their stick/buttons and draw the host's
   snapshots (their own kid is predicted locally). Round flow travels in the small coarse state. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- world (units ≈ half a metre). x across (−HW…HW), y down the screen (−HH…HH). ---------- */
  let HW = 12, HH = 16; const PR = 0.72, BR = 0.26, BBR = 0.5;
  const HS = 2.0, HD = 0.95, HC = 1.0;                 // hit height: standing / ducking / scooping
  const WALL_H = 1.15, MAN_H = 2.3, TREE_H = 4.5;
  const G = 22, VB = 23, VBB = 18, Z0 = 1.5, RMIN = 2.5, RMAX = 18;
  const VWALK = 6.4, VDUCK = 2.5, VSLED = 12, ACC = 44, ACC_ICE = 6, ACC_SLED = 18;
  const SCOOP_T = 0.6, PILE_T = 0.3, AMAX = 3, AM0 = 2, HP = 3;
  const THROW_CD = 0.42, RAPID_CD = 0.17, RAPID_T = 6, SLED_T = 3.2, BIG_N = 2;
  const STUN_T = 0.42, SLOW_T = 0.55, INV_T = 0.85, TA_T = 0.26;
  const ROUND_T = 60, OT_T = 25, COUNT_T = 2.6, FIRST_T = 5.2, END_T = 2.8, LAST_T = 0.8;
  const PU_EVERY = 7.5, PU_MAX = 2, PU_FIRST = 5;
  const SUB = 1 / 120;
  const PU_KEYS = ['B', 'R', 'S', 'C'];
  const TEAM_NM = ['빨강 팀', '파랑 팀'], TEAM_C = ['#ee6a55', '#5bb3e6'];
  const PU_NAME = { B: '큰 눈덩이', R: '연속 던지기', S: '썰매 대시', C: '핫초코' };

  /* maps: one quadrant (x ≥ 0, y ≥ 0), mirrored into all four → fair for 2 (top/bottom) and 4 (corners).
     w = snow wall [x, y, w, h] (3 hits), m = snowman [x, y] (3 hits, tall), t = pine tree [x, y], i = ice [x, y, rx, ry] */
  const MAPS = [
    { id: 'yard', nm: '앞마당', items: [['w', 8.8, 10.6, 4.4, 1.1], ['w', 0, 10.2, 4.6, 1.1], ['m', 4.7, 5.6], ['w', 4.4, 0, 1.1, 3.2], ['m', 0, 0], ['w', 9.4, 3.4, 3.0, 1.1], ['t', 11.1, 7.2]] },
    { id: 'pond', nm: '얼음 연못', items: [['i', 0, 0, 6.6, 4.2], ['w', 8.8, 10.6, 4.4, 1.1], ['w', 0, 10.2, 4.6, 1.1], ['t', 7.9, 3.6], ['t', 3.3, 6.7], ['m', 10.4, 0], ['w', 8.6, 7.0, 1.1, 2.6]] },
    { id: 'fort', nm: '눈 요새', items: [['w', 4.2, 8.8, 3.8, 1.1], ['w', 9.7, 10.6, 1.1, 3.6], ['m', 0, 4.4], ['w', 7.2, 0, 3.4, 1.1], ['t', 11.1, 4.6], ['m', 3.4, 12.4]] },
    { id: 'forest', nm: '소나무 숲', items: [['t', 2.6, 3.4], ['t', 7.4, 4.8], ['t', 4.9, 8.2], ['t', 0, 6.6], ['t', 9.9, 0], ['w', 0, 10.2, 4.6, 1.1], ['w', 8.8, 10.6, 4.4, 1.1], ['m', 4.7, 0]] },
    // d = deep snow drift [x, y, rx, ry]: slow to wade through, but snow there packs twice as fast
    { id: 'drift', nm: '눈더미 언덕', sub: '가운데 깊은 눈: 느리지만 빨리 뭉쳐요', items: [['d', 0, 0, 6.8, 3.4], ['d', 10.2, 7.6, 2.2, 2.6], ['w', 5.6, 10.8, 3.6, 1.1], ['w', 0, 6.4, 3.2, 1.1], ['m', 3.4, 4.2], ['t', 10.8, 1.6], ['w', 10.4, 12.6, 1.1, 2.4]] },
    { id: 'lanes', nm: '미끄럼 골목', sub: '양옆 얼음길과 가운데 눈벽 줄', items: [['i', 7.6, 0, 1.6, 9.2], ['w', 0, 3.6, 5.6, 1.1], ['w', 3.6, 9.4, 1.1, 3.2], ['m', 0, 8.6], ['w', 10.2, 11.2, 3.2, 1.1], ['t', 11.1, 4.2], ['d', 4.6, 0, 1.6, 2.2]] },
    { id: 'park', nm: '눈사람 공원', sub: '튼튼한 눈사람 사이로 숨바꼭질', items: [['m', 2.6, 3.8], ['m', 7.2, 2.2], ['m', 5.2, 8.0], ['m', 10.1, 6.6], ['w', 0, 11.0, 5.4, 1.1], ['t', 10.6, 12.6], ['i', 0, 0, 3.2, 2.0], ['d', 9.8, 0, 1.8, 1.6]] },
  ];
  const AI_DIFF = {
    1: { react: 0.5, think: 0.45, lead: 0, err: 1.9, gap: [1.1, 2.0], range: 12, dodge: 0.12, cover: 0.15, pu: 0.35, spd: 0.84, low: 0.2, ret: 0.1, duck: 0.2 },
    2: { react: 0.28, think: 0.28, lead: 0.65, err: 0.95, gap: [0.65, 1.2], range: 14.5, dodge: 0.5, cover: 0.55, pu: 0.75, spd: 0.93, low: 0.6, ret: 0.45, duck: 0.6 },
    3: { react: 0.14, think: 0.16, lead: 1, err: 0.4, gap: [0.42, 0.75], range: 16.5, dodge: 0.85, cover: 0.9, pu: 1, spd: 1, low: 1, ret: 0.85, duck: 0.9 },
  };

  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * Math.random()); }
  function wrapA(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  const NOIN = { ax: 0, ay: 0, du: 0, sc: 0, thr: null, spd: 1 };
  const NOH = {};

  function mirror(list) {
    const out = [], seen = {};
    for (const it of list) for (const sx of [1, -1]) for (const sy of [1, -1]) {
      const o = it.slice(); o[1] = it[1] * sx + 0; o[2] = it[2] * sy + 0;
      const k = o.join(','); if (seen[k]) continue; seen[k] = 1; out.push(o);
    }
    return out;
  }
  /* yard size grows with the number of kids (the map items are spread out to match) */
  function yardOf(np) { return np <= 4 ? [12, 16] : np <= 6 ? [13, 18.5] : [14, 21]; }
  function setSize(np) { const y = yardOf(np); HW = y[0]; HH = y[1]; }
  function spawns(np, tm) {
    const Y = HH - 2.2;
    if (np <= 2) return [[0, Y], [0, -Y]];
    if (np === 3) return [[0, Y], [-8.5, -Y], [8.5, -Y]];
    if (np === 4) return [[-8.5, Y], [8.5, -Y], [8.5, Y], [-8.5, -Y]];
    const out = [];
    if (tm) {   // two teams: evens along the bottom fence, odds along the top
      const k = Math.ceil(np / 2), sp = Math.min(7.5, (2 * HW - 5) / Math.max(1, k - 1));
      for (let i = 0; i < np; i++) { const j = i >> 1, x = (j - (k - 1) / 2) * sp; out.push(i % 2 ? [-x, -Y] : [x, Y]); }
      return out;
    }
    for (let i = 0; i < np; i++) {   // each for themselves: evenly around the edge of the yard
      const a = (i / np) * 6.2832;
      out.push([r1(clamp(Math.sin(a) * HW * 1.25, -HW + 2.2, HW - 2.2)), r1(clamp(Math.cos(a) * HH * 1.1, -Y, Y))]);
    }
    return out;
  }
  // extra cover for the bigger yards (fractions of the quadrant), skipped where the map already has something
  const EXTRA = [['w', 0.52, 0.44, 3.4, 1.1], ['m', 0.84, 0.22], ['w', 0.18, 0.66, 1.1, 2.6]];
  const sideOf = (W, i) => (W.tm ? i % 2 : i);

  function newWorld(st) {
    const mp = MAPS[st.mk] || MAPS[0], np = st.np, ob = [], ice = [], dr = [];
    setSize(np);
    const fx = HW / 12, fy = HH / 16, base = mp.items.map((it) => { const o = it.slice(); o[1] = r1(o[1] * fx); o[2] = r1(o[2] * fy); return o; });
    if (np > 4) for (const e of EXTRA) {
      const o = e.slice(); o[1] = r1(o[1] * HW); o[2] = r1(o[2] * HH);
      if (!base.some((b) => b[0] !== 'd' && hyp(b[1] - o[1], b[2] - o[2]) < 3.2 + (b[0] === 'i' ? Math.max(b[3], b[4]) : 0))) base.push(o);
    }
    for (const it of mirror(base)) {
      if (it[0] === 'w') ob.push({ k: 'w', x: it[1], y: it[2], w: it[3], h: it[4], r: 0, hp: 3 });
      else if (it[0] === 'm') ob.push({ k: 'm', x: it[1], y: it[2], w: 0, h: 0, r: 0.85, hp: 3 });
      else if (it[0] === 't') ob.push({ k: 't', x: it[1], y: it[2], w: 0, h: 0, r: 0.75, hp: 9 });
      else if (it[0] === 'i') ice.push({ x: it[1], y: it[2], rx: it[3], ry: it[4] });
      else if (it[0] === 'd') dr.push({ x: it[1], y: it[2], rx: it[3], ry: it[4] });
    }
    const sp = spawns(np, st.tm), pl = [];
    for (let i = 0; i < np; i++) {
      pl.push({ i, x: sp[i][0], y: sp[i][1], vx: 0, vy: 0, a: sp[i][1] > 0 ? -Math.PI / 2 : Math.PI / 2, hp: HP, am: AM0,
        du: 0, sc: 0, scn: 0, st: 0, sl: 0, iv: 0, cd: 0, ta: 0, big: 0, rap: 0, sled: 0, sh: 0, out: 0 });
    }
    for (const p of pl) { for (const o of ob) pushOut(o, p, PR); fence(p, PR); p.vx = 0; p.vy = 0; }
    return { ob, ice, dr, pl, aiTg: [], tm: st.tm ? 1 : 0, it: st.it === 0 ? 0 : 1, balls: [], pu: [], t: 0, puT: PU_FIRST, bid: 0, fxn: 0, fx: [],
      hits: Array(np).fill(0), ot: 0, endT: 0, res: null };
  }

  /* ---------- geometry ---------- */
  const CP = { x: 0, y: 0 };
  function closest(o, x, y) {
    if (o.k === 'w') { CP.x = clamp(x, o.x - o.w / 2, o.x + o.w / 2); CP.y = clamp(y, o.y - o.h / 2, o.y + o.h / 2); }
    else { const dx = x - o.x, dy = y - o.y, d = hyp(dx, dy); if (d <= o.r) { CP.x = x; CP.y = y; } else { CP.x = o.x + dx / d * o.r; CP.y = o.y + dy / d * o.r; } }
    return CP;
  }
  const solid = (o) => o.hp > 0;
  function overlap(o, x, y, r) { closest(o, x, y); const dx = x - CP.x, dy = y - CP.y; return dx * dx + dy * dy < r * r; }
  function obHeight(o) { return o.k === 'w' ? WALL_H : o.k === 'm' ? MAN_H : TREE_H; }
  function pushOut(o, p, r) {
    if (o.k !== 'w') {
      let dx = p.x - o.x, dy = p.y - o.y, d = hyp(dx, dy); const R = o.r + r;
      if (d >= R) return;
      if (d < 1e-6) { dx = 0; dy = 1; d = 1; }
      const nx = dx / d, ny = dy / d; p.x = o.x + nx * R; p.y = o.y + ny * R;
      const vn = p.vx * nx + p.vy * ny; if (vn < 0) { p.vx -= vn * nx; p.vy -= vn * ny; }
      return;
    }
    const hx = o.w / 2, hy = o.h / 2, rx = p.x - o.x, ry = p.y - o.y;
    if (Math.abs(rx) < hx && Math.abs(ry) < hy) {      // centre inside: out along the shallow side
      const px = hx - Math.abs(rx) + r, py = hy - Math.abs(ry) + r;
      if (px < py) { const s = rx < 0 ? -1 : 1; p.x = o.x + s * (hx + r); if (p.vx * s < 0) p.vx = 0; }
      else { const s = ry < 0 ? -1 : 1; p.y = o.y + s * (hy + r); if (p.vy * s < 0) p.vy = 0; }
      return;
    }
    closest(o, p.x, p.y);
    const dx = p.x - CP.x, dy = p.y - CP.y, d = hyp(dx, dy);
    if (d >= r || d < 1e-9) return;
    const nx = dx / d, ny = dy / d; p.x = CP.x + nx * r; p.y = CP.y + ny * r;
    const vn = p.vx * nx + p.vy * ny; if (vn < 0) { p.vx -= vn * nx; p.vy -= vn * ny; }
  }
  function onIce(W, x, y) { for (const c of W.ice) { const u = (x - c.x) / c.rx, v = (y - c.y) / c.ry; if (u * u + v * v < 1) return true; } return false; }
  function onDrift(W, x, y) { for (const c of W.dr || []) { const u = (x - c.x) / c.rx, v = (y - c.y) / c.ry; if (u * u + v * v < 1) return true; } return false; }
  const DRIFT_V = 0.6;   // walking speed in deep snow
  function onPile(W, x, y) { for (const o of W.ob) if (o.hp === 0 && hyp(x - o.x, y - o.y) < (o.k === 'w' ? Math.max(o.w, o.h) / 2 + 0.4 : 1.3)) return true; return false; }
  function hgt(p) { return p.out ? 0 : p.ta > 0 ? HS : p.du ? HD : p.scn ? HC : HS; }
  function fence(p, r) {
    const lx = HW - r, ly = HH - r;
    if (p.x < -lx) { p.x = -lx; if (p.vx < 0) p.vx = 0; } else if (p.x > lx) { p.x = lx; if (p.vx > 0) p.vx = 0; }
    if (p.y < -ly) { p.y = -ly; if (p.vy < 0) p.vy = 0; } else if (p.y > ly) { p.y = ly; if (p.vy > 0) p.vy = 0; }
  }

  function emit(W, hooks, code, a, b, c, d) {
    W.fxn++;
    W.fx.push([W.fxn, code, a, b, c, d]); if (W.fx.length > 12) W.fx.shift();
    if (hooks && hooks.fx) hooks.fx(code, a, b, c, d);
  }

  /* is a standing enemy of `p` near (x, y)?  → aim at chest height, else low (walls, ducking or scooping kids) */
  function chestAim(W, p, x, y) {
    for (const q of W.pl) if (!q.out && sideOf(W, q.i) !== sideOf(W, p.i) && hyp(q.x - x, q.y - y) < 1.7 && hgt(q) >= HS) return true;
    return false;
  }
  /* the ball that `p` would throw toward (tx, ty) */
  function launch(W, p, tx, ty, out) {
    let dx = tx - p.x, dy = ty - p.y, d = hyp(dx, dy);
    if (d < 1e-3) { dx = Math.cos(p.a); dy = Math.sin(p.a); d = 1; }
    const ux = dx / d, uy = dy / d;
    d = clamp(d, RMIN, RMAX);
    const big = p.big > 0, ha = chestAim(W, p, p.x + ux * d, p.y + uy * d) ? 1.3 : 0.55;
    const vh = big ? VBB : VB, T = Math.max(0.05, (d - 0.6) / vh), vz = (ha - Z0 + 0.5 * G * T * T) / T;
    const b = out || {};
    b.x = p.x + ux * 0.6; b.y = p.y + uy * 0.6; b.z = Z0; b.vx = ux * vh; b.vy = uy * vh; b.vz = vz; b.o = p.i; b.bg = big ? 1 : 0; b.age = 0;
    b.tx = p.x + ux * d; b.ty = p.y + uy * d;
    return b;
  }
  function canThrow(p) { return !p.out && p.cd <= 0 && p.st <= 0 && p.sled <= 0 && (p.am > 0 || p.rap > 0 || p.big > 0); }
  function tryThrow(W, p, tx, ty, hooks) {
    if (!canThrow(p) || !fin(tx) || !fin(ty)) return false;
    const b = launch(W, p, tx, ty);
    b.id = ++W.bid;
    if (p.big > 0) p.big--; else if (p.rap <= 0) p.am--;
    p.cd = p.rap > 0 ? RAPID_CD : THROW_CD; p.ta = TA_T; p.du = 0; p.sc = 0;
    p.a = Math.atan2(b.vy, b.vx);
    if (b.o >= 0) { if (!W.thr) W.thr = []; W.thr[b.o] = (W.thr[b.o] | 0) + 1; } // result stats
    W.balls.push(b);
    if (W.balls.length > 24) W.balls.shift();
    emit(W, hooks, 0, r1(b.x), r1(b.y), p.i, b.bg);
    return true;
  }
  function hitPlayer(W, p, b, hooks) {
    if (p.iv > 0) { emit(W, hooks, 6, r1(p.x), r1(p.y), 0, 0); return; }
    if (p.sh) { p.sh = 0; p.iv = 0.5; emit(W, hooks, 9, r1(p.x), r1(p.y), p.i, 0); return; }
    p.hp--; p.st = b.bg ? 0.8 : STUN_T; p.sl = SLOW_T; p.iv = INV_T; p.sc = 0; p.scn = 0;
    const l = hyp(b.vx, b.vy) || 1, kb = b.bg ? 9 : 5;
    p.vx += b.vx / l * kb; p.vy += b.vy / l * kb;
    if (b.o >= 0 && b.o < W.hits.length) W.hits[b.o]++;
    if (p.hp <= 0) { p.hp = 0; p.out = 1; p.du = 0; emit(W, hooks, 2, r1(p.x), r1(p.y), p.i, b.o); }
    else emit(W, hooks, 1, r1(p.x), r1(p.y), p.i, b.o + (b.bg ? 8 : 0));
  }
  function splash(W, b, skip, hooks) {
    for (const q of W.pl) {
      if (q.out || q === skip || sideOf(W, q.i) === sideOf(W, b.o)) continue;
      if (hyp(q.x - b.x, q.y - b.y) < 2.0) hitPlayer(W, q, b, hooks);
    }
  }
  function stepBall(W, b, h, hooks, host) {
    b.age += h; b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h; b.vz -= G * h;
    const r = b.bg ? BBR : BR;
    if (Math.abs(b.x) > HW - r || Math.abs(b.y) > HH - r) { if (host && b.z < 1.3) emit(W, hooks, 13, r1(clamp(b.x, -HW, HW)), r1(clamp(b.y, -HH, HH)), 0, 0); return false; }
    for (let j = 0; j < W.ob.length; j++) {
      const o = W.ob[j];
      if (!solid(o) || b.z > obHeight(o) || !overlap(o, b.x, b.y, r)) continue;
      if (!host) return false;
      if (o.k === 't') emit(W, hooks, 5, r1(b.x), r1(b.y), j, 0);
      else { o.hp = Math.max(0, o.hp - (b.bg ? 3 : 1)); emit(W, hooks, o.hp ? 3 : 4, r1(b.x), r1(b.y), j, o.hp); }
      if (b.bg) splash(W, b, null, hooks);
      return false;
    }
    const so = sideOf(W, b.o);
    for (const p of W.pl) {
      if (p.out || p.i === b.o || sideOf(W, p.i) === so || b.z <= 0 || b.z > hgt(p)) continue;
      if (hyp(p.x - b.x, p.y - b.y) < PR + r) {
        if (!host) return false;
        hitPlayer(W, p, b, hooks); if (b.bg) splash(W, b, p, hooks);
        return false;
      }
    }
    if (b.z <= 0) {
      if (host) { emit(W, hooks, 7, r1(b.x), r1(b.y), b.bg, 0); if (b.bg) splash(W, b, null, hooks); }
      return false;
    }
    return true;
  }

  /* one kid's movement (shared with the guest's own-kid prediction) */
  function movePlayer(W, p, I, h) {
    if (p.st > 0) p.st -= h; if (p.sl > 0) p.sl -= h; if (p.iv > 0) p.iv -= h; if (p.cd > 0) p.cd -= h; if (p.ta > 0) p.ta -= h;
    if (p.rap > 0) p.rap -= h; if (p.sled > 0) p.sled -= h;
    if (p.out) { p.vx *= 0.9; p.vy *= 0.9; p.du = 0; p.scn = 0; return; }
    let mx = clamp(+I.ax || 0, -1, 1), my = clamp(+I.ay || 0, -1, 1); const m = hyp(mx, my); if (m > 1) { mx /= m; my /= m; }
    const ice = onIce(W, p.x, p.y);
    p.du = I.du && p.sled <= 0 && p.ta <= 0 ? 1 : 0;
    p.scn = I.sc && p.st <= 0 && p.sled <= 0 && !ice && p.am < AMAX && p.ta <= 0 ? 1 : 0;
    if (p.scn) { mx = 0; my = 0; p.du = 0; }
    let vm = p.sled > 0 ? VSLED : p.du ? VDUCK : VWALK, acc = p.sled > 0 ? ACC_SLED : ice ? ACC_ICE : ACC;
    vm *= I.spd || 1;
    if (p.sled <= 0 && onDrift(W, p.x, p.y)) vm *= DRIFT_V;
    if (p.sled > 0 && hyp(mx, my) < 0.2) { mx = Math.cos(p.a); my = Math.sin(p.a); }
    if (p.sl > 0) vm *= 0.55;
    if (p.st > 0) { vm = 0; acc = ice ? ACC_ICE : 14; }
    let ax = mx * vm - p.vx, ay = my * vm - p.vy; const al = hyp(ax, ay), am = acc * h;
    if (al > am) { ax *= am / al; ay *= am / al; }
    p.vx += ax; p.vy += ay;
    if (hyp(mx, my) > 0.15 && p.st <= 0 && p.ta <= 0) { const d = wrapA(Math.atan2(my, mx) - p.a); p.a = wrapA(p.a + clamp(d, -14 * h, 14 * h)); }
    p.x += p.vx * h; p.y += p.vy * h;
    for (const o of W.ob) if (solid(o)) pushOut(o, p, PR);
    fence(p, PR);
  }

  function stepWorld(W, h, inputs, hooks) {
    for (const p of W.pl) {
      const I = inputs[p.i] || NOIN;
      const sc0 = p.sc;
      // a throw that arrives a moment early (still winding down from the last one, or stunned) waits up to 0.3 s
      if (I.thr && !p.out) { I.tb = (I.tb || 0) + h; if (canThrow(p) || I.tb > 0.3) { tryThrow(W, p, I.thr[0], I.thr[1], hooks); I.thr = null; I.tb = 0; } }
      movePlayer(W, p, I, h);
      if (p.scn) {
        p.sc = sc0 + h;
        if (p.sc >= (onPile(W, p.x, p.y) || onDrift(W, p.x, p.y) ? PILE_T : SCOOP_T)) { p.sc = 0; p.am = Math.min(AMAX, p.am + 1); emit(W, hooks, 11, r1(p.x), r1(p.y), p.i, p.am); }
      } else p.sc = 0;
    }
    const pl = W.pl;
    for (let i = 0; i < pl.length; i++) for (let j = i + 1; j < pl.length; j++) {
      const a = pl[i], c = pl[j];
      if (a.out || c.out) continue;
      let dx = c.x - a.x, dy = c.y - a.y; const d2 = dx * dx + dy * dy, R = 2 * PR;
      if (d2 >= R * R) continue;
      let d = Math.sqrt(d2); if (d < 1e-6) { dx = 0.01; dy = 0; d = 0.01; }
      const nx = dx / d, ny = dy / d, o = (R - d) / 2;
      a.x -= nx * o; a.y -= ny * o; c.x += nx * o; c.y += ny * o;
      const enemy = sideOf(W, a.i) !== sideOf(W, c.i);
      for (const [s, t, sg] of [[a, c, 1], [c, a, -1]]) {   // sled bump: knocks an enemy over (no heart lost)
        if (s.sled > 0 && enemy && t.st <= 0 && t.iv <= 0) {
          t.st = 0.6; t.iv = 0.6; t.vx += nx * sg * 9; t.vy += ny * sg * 9; t.sc = 0;
          emit(W, hooks, 10, r1(t.x), r1(t.y), t.i, s.i);
        }
      }
      fence(a, PR); fence(c, PR);
    }
    for (let k = W.balls.length - 1; k >= 0; k--) if (!stepBall(W, W.balls[k], h, hooks, true)) W.balls.splice(k, 1);
    for (let k = W.pu.length - 1; k >= 0; k--) {
      const u = W.pu[k];
      for (const p of pl) {
        if (p.out || hyp(p.x - u.x, p.y - u.y) > PR + 0.7) continue;
        if (u.k === 'B') p.big = BIG_N;
        else if (u.k === 'R') p.rap = RAPID_T;
        else if (u.k === 'S') { p.sled = SLED_T; p.du = 0; p.sc = 0; }
        else if (p.hp < HP) p.hp++; else p.sh = 1;
        emit(W, hooks, 8, r1(u.x), r1(u.y), p.i, PU_KEYS.indexOf(u.k));
        W.pu.splice(k, 1);
        break;
      }
    }
  }
  function spawnPU(W, hooks) {
    for (let n = 0; n < 30; n++) {
      const x = (Math.random() * 2 - 1) * (HW - 1.6), y = (Math.random() * 2 - 1) * (HH - 3.5);
      if (onIce(W, x, y)) continue;
      let bad = false;
      for (const o of W.ob) if (solid(o) && overlap(o, x, y, 1.3)) { bad = true; break; }
      if (bad) continue;
      for (const p of W.pl) if (!p.out && hyp(p.x - x, p.y - y) < 4.5) { bad = true; break; }
      for (const u of W.pu) if (hyp(u.x - x, u.y - y) < 4) bad = true;
      if (bad) continue;
      // fair: roughly as far from the nearest kid of every side
      const k = PU_KEYS[Math.floor(Math.random() * PU_KEYS.length)];
      W.pu.push({ x: r1(x), y: r1(y), k });
      emit(W, hooks, 12, r1(x), r1(y), PU_KEYS.indexOf(k), 0);
      return;
    }
  }
  function aliveSides(W) {
    const s = new Set();
    for (const p of W.pl) if (!p.out) s.add(sideOf(W, p.i));
    return s;
  }
  function sideHearts(W) {
    const m = {};
    for (const p of W.pl) if (!p.out) { const s = sideOf(W, p.i); m[s] = (m[s] || 0) + p.hp; }
    return m;
  }
  /* one game tick while playing; returns {w: side | −1} once the round is decided */
  function tickWorld(W, dt, inputs, hooks) {
    if (W.res) return null;
    W.t += dt;
    if (W.it) { W.puT -= dt; if (W.puT <= 0) { W.puT = PU_EVERY * (0.8 + Math.random() * 0.4); if (W.pu.length < PU_MAX) spawnPU(W, hooks); } }
    const n = Math.min(40, Math.max(1, Math.ceil(dt / SUB))), h = dt / n;
    for (let k = 0; k < n; k++) stepWorld(W, h, inputs, hooks);
    const al = aliveSides(W);
    if (al.size <= 1) {
      W.endT += dt;
      if (W.endT >= LAST_T) { W.res = { w: al.size === 1 ? [...al][0] : -1, why: 'ko' }; return W.res; }
    } else if (!W.ot && W.t >= ROUND_T) {
      const sh = sideHearts(W), mx = Math.max(...Object.values(sh)), top = Object.keys(sh).filter((k) => sh[k] === mx).map(Number);
      if (top.length === 1) { W.res = { w: top[0], why: 'time' }; return W.res; }
      W.ot = 1;
      for (const p of W.pl) {
        if (p.out) continue;
        if (!top.includes(sideOf(W, p.i))) { p.out = 1; p.hp = 0; emit(W, hooks, 2, r1(p.x), r1(p.y), p.i, -1); }
        else { p.hp = 1; p.sh = 0; }
      }
      emit(W, hooks, 14, 0, 0, 0, 0);
    } else if (W.ot && W.t >= ROUND_T + OT_T) { W.res = { w: -1, why: 'time' }; return W.res; }
    return null;
  }

  /* ---------- AI ---------- */
  function ballThreat(W, b, p) {   // when / how high a flying ball would pass through p (if it stood still)
    let x = b.x, y = b.y, z = b.z, vz = b.vz; const r = (b.bg ? BBR : BR) + PR + 0.3, dt = 0.025;
    for (let t = 0; t < 1.4; t += dt) {
      x += b.vx * dt; y += b.vy * dt; z += vz * dt; vz -= G * dt;
      if (z <= 0) return null;
      if (z < HS && hyp(x - p.x, y - p.y) < r) return { t, z };
    }
    return null;
  }
  function pathBlock(W, p, b0) {   // first thing a test throw would hit: {k:'ob', j, d} / {k:'pl'} / {k:'ground'}
    const b = { x: b0.x, y: b0.y, z: b0.z, vx: b0.vx, vy: b0.vy, vz: b0.vz, bg: b0.bg };
    const r = b.bg ? BBR : BR, dt = 0.02, so = sideOf(W, p.i);
    for (let t = 0; t < 2; t += dt) {
      b.x += b.vx * dt; b.y += b.vy * dt; b.z += b.vz * dt; b.vz -= G * dt;
      if (Math.abs(b.x) > HW || Math.abs(b.y) > HH) return { k: 'out' };
      for (let j = 0; j < W.ob.length; j++) { const o = W.ob[j]; if (solid(o) && b.z <= obHeight(o) && overlap(o, b.x, b.y, r)) return { k: 'ob', j, d: hyp(b.x - p.x, b.y - p.y) }; }
      for (const q of W.pl) if (!q.out && sideOf(W, q.i) !== so && b.z > 0 && b.z <= hgt(q) && hyp(q.x - b.x, q.y - b.y) < PR + r) return { k: 'pl', q: q.i };
      for (const q of W.pl) if (!q.out && q !== p && sideOf(W, q.i) === so && b.z > 0 && b.z <= HS && hyp(q.x - b.x, q.y - b.y) < PR + r) return { k: 'mate' };
      if (b.z <= 0) return { k: 'ground' };
    }
    return { k: 'ground' };
  }
  function support(o, ux, uy) { return o.k === 'w' ? Math.abs(ux) * o.w / 2 + Math.abs(uy) * o.h / 2 : o.r; }
  function freeSpot(W, x, y) {
    if (Math.abs(x) > HW - PR - 0.1 || Math.abs(y) > HH - PR - 0.1) return false;
    for (const o of W.ob) if (solid(o) && overlap(o, x, y, PR + 0.05)) return false;
    return true;
  }
  /* a spot behind cover as seen from the target (null = none near) */
  function coverSpot(W, p, tg) {
    let best = null, bs = 1e9;
    for (const o of W.ob) {
      if (!solid(o)) continue;
      let ux = o.x - tg.x, uy = o.y - tg.y; const l = hyp(ux, uy) || 1; ux /= l; uy /= l;
      const d = support(o, ux, uy) + PR + 0.25, cx = o.x + ux * d, cy = o.y + uy * d;
      if (!freeSpot(W, cx, cy)) continue;
      let s = hyp(cx - p.x, cy - p.y);
      if (hyp(cx - tg.x, cy - tg.y) < 5) s += 8;
      for (const q of W.pl) if (!q.out && q !== tg && sideOf(W, q.i) !== sideOf(W, p.i) && hyp(q.x - cx, q.y - cy) < 4) s += 6;
      if (o.k === 't') s += 1.5;      // a trunk is narrower than a wall
      if (s < bs) { bs = s; best = { x: cx, y: cy, j: W.ob.indexOf(o) }; }
    }
    return best && bs < 14 ? best : null;
  }
  function wallBetween(W, ax, ay, bx, by, near) {   // a solid wall/snowman on the segment, within `near` of b
    for (const o of W.ob) {
      if (!solid(o) || o.k === 't') continue;
      for (let k = 0.2; k <= 0.95; k += 0.05) {
        const x = ax + (bx - ax) * k, y = ay + (by - ay) * k;
        if (hyp(bx - x, by - y) > near) continue;
        if (overlap(o, x, y, 0.15)) return true;
      }
    }
    return false;
  }
  function steer(W, p, gx, gy, M, I) {
    let dx = gx - p.x, dy = gy - p.y; const d = hyp(dx, dy);
    if (d < 0.35) { I.ax = 0; I.ay = 0; return d; }
    dx /= d; dy /= d;
    const la = Math.min(2.2, d);
    for (const o of W.ob) {
      if (!solid(o)) continue;
      const px = p.x + dx * la, py = p.y + dy * la;
      if (!overlap(o, px, py, PR + 0.3)) continue;
      closest(o, p.x, p.y);
      let ox = p.x - CP.x, oy = p.y - CP.y; const ol = hyp(ox, oy) || 1; ox /= ol; oy /= ol;
      let tx = -oy, ty = ox;
      const dt = tx * dx + ty * dy;
      if (Math.abs(dt) < 0.15) { if (!M.side) M.side = Math.random() < 0.5 ? 1 : -1; tx *= M.side; ty *= M.side; }
      else if (dt < 0) { tx = -tx; ty = -ty; }
      dx = dx * 0.25 + tx; dy = dy * 0.25 + ty;
      const l = hyp(dx, dy) || 1; dx /= l; dy /= l;
      break;
    }
    const m = 1.6;
    if (p.x < -HW + m) dx += 0.6; if (p.x > HW - m) dx -= 0.6; if (p.y < -HH + m) dy += 0.6; if (p.y > HH - m) dy -= 0.6;
    const l = hyp(dx, dy) || 1;
    const sl = d < 1.2 ? Math.max(0.35, d / 1.2) : 1;
    I.ax = dx / l * sl; I.ay = dy / l * sl;
    return d;
  }
  function pickTarget(W, p, lv, M) {
    if (M.tg >= 0 && M.tgT > 0 && W.pl[M.tg] && !W.pl[M.tg].out) return W.pl[M.tg];
    let best = null, bs = 1e9;
    for (const q of W.pl) {
      if (q.out || sideOf(W, q.i) === sideOf(W, p.i)) continue;
      let s = hyp(q.x - p.x, q.y - p.y);
      if (lv >= 3) s -= (HP - q.hp) * 2.5 + (q.st > 0 || q.scn ? 3 : 0);
      if (lv <= 1) s += Math.random() * 6;
      if (W.tm && lv >= 2 && W.aiTg) { let n = 0; for (let k = 0; k < W.aiTg.length; k++) if (k !== p.i && W.aiTg[k] === q.i && sideOf(W, k) === sideOf(W, p.i)) n++; s -= Math.min(2, n) * (lv >= 3 ? 3 : 1.8); }  // focus fire
      if (s < bs) { bs = s; best = q; }
    }
    M.tg = best ? best.i : -1; M.tgT = 1.5;
    if (W.aiTg) W.aiTg[p.i] = M.tg;
    return best;
  }
  function aiThink(W, p, M, lv, dt) {
    const D = AI_DIFF[lv] || AI_DIFF[2];
    const I = M.inp || (M.inp = { ax: 0, ay: 0, du: 0, sc: 0, thr: null, spd: 1 });
    if (M.t == null) Object.assign(M, { t: 0, tt: 0.6 + Math.random() * 0.8, dg: 0, dk: 0, hide: 0, tg: -1, tgT: 0, seen: {}, sn: 0, str: Math.random() < 0.5 ? 1 : -1, strT: 2, mode: 'fight', goal: null, stuck: 0, unst: 0, ux: 0, uy: 0, puOk: {}, rc: 0 });
    I.spd = D.spd; I.thr = null;
    if (p.out) { I.ax = 0; I.ay = 0; I.du = 0; I.sc = 0; return I; }
    M.t -= dt; M.tt -= dt; M.dg -= dt; M.dk -= dt; M.hide -= dt; M.tgT -= dt; M.strT -= dt; M.unst -= dt;
    // incoming balls → dodge or duck (decided once per ball)
    for (const b of W.balls) {
      if (b.o === p.i || sideOf(W, b.o) === sideOf(W, p.i) || b.age < D.react || M.seen[b.id]) continue;
      M.seen[b.id] = 1;
      const th = ballThreat(W, b, p);
      if (!th || Math.random() > D.dodge) continue;
      if (th.z > HD + 0.08 && Math.random() < D.duck && p.sled <= 0) { M.dk = th.t + 0.2; continue; }
      let nx = -b.vy, ny = b.vx; const l = hyp(nx, ny) || 1; nx /= l; ny /= l;
      const rx = p.x - b.x, ry = p.y - b.y;
      let s = rx * nx + ry * ny >= 0 ? 1 : -1;
      if (!freeSpot(W, p.x + nx * s * 1.6, p.y + ny * s * 1.6)) s = -s;
      M.ux = nx * s; M.uy = ny * s; M.dg = Math.min(0.7, th.t + 0.25);
    }
    if (++M.sn > 200) { M.sn = 0; const keep = {}; for (const b of W.balls) if (M.seen[b.id]) keep[b.id] = 1; M.seen = keep; }
    const tg = pickTarget(W, p, lv, M);
    if (M.t <= 0) {
      M.t = D.think * (0.7 + Math.random() * 0.6);
      const empty = p.am === 0 && p.big <= 0 && p.rap <= 0;
      let pu = null, pd = 1e9;
      if (W.pu.length) for (const u of W.pu) {
        const key = u.x + ',' + u.y;
        if (M.puOk[key] == null) M.puOk[key] = Math.random() < D.pu;
        const d = hyp(u.x - p.x, u.y - p.y);
        if (M.puOk[key] && d < 9 && d < pd && !(u.k === 'C' && p.hp >= HP && p.sh)) { pu = u; pd = d; }
      }
      const prev = M.mode;
      if (empty) M.mode = 'reload';
      else if (pu && !(tg && hyp(tg.x - p.x, tg.y - p.y) < 4)) M.mode = 'pu';
      else if (M.hide > 0) M.mode = 'hide';
      else if (lv >= 2 && p.am < AMAX && p.big <= 0 && (!tg || hyp(tg.x - p.x, tg.y - p.y) > D.range + 5)) M.mode = 'reload';
      else M.mode = 'fight';
      if (M.mode === 'reload' && prev !== 'reload') M.rc = Math.random() < D.cover ? 1 : 0;
      if (M.mode === 'reload') {
        const cs = M.rc && tg ? coverSpot(W, p, tg) : null;
        M.goal = cs || (lv <= 1 ? { x: p.x, y: p.y } : M.goal && M.goal.r ? M.goal : { x: p.x, y: p.y, r: 1 });
      } else if (M.mode === 'pu') M.goal = { x: pu.x, y: pu.y };
      else if (M.mode === 'hide') { const cs = tg ? coverSpot(W, p, tg) : null; if (cs) M.goal = cs; else { M.mode = 'fight'; M.hide = 0; } }
      M.cov = 0;
      // teams: one half of the side holds a wall near the target (cover), the other half swings wide (flank)
      const role = W.tm && lv >= 2 ? (p.i >> 1) % 2 : -1;
      if (M.mode === 'fight' && tg && role === 0) {
        const cs = coverSpot(W, p, tg);
        if (cs && hyp(cs.x - tg.x, cs.y - tg.y) < D.range * 0.95 && hyp(cs.x - tg.x, cs.y - tg.y) > 4.5) { M.goal = cs; M.cov = 1; }
      }
      if (M.mode === 'fight' && tg && !M.cov) {
        if (M.strT <= 0) { M.str = -M.str; M.strT = 1.2 + Math.random() * 2.2; }
        const want = D.range * (lv >= 3 ? 0.72 : 0.68);
        let ux = p.x - tg.x, uy = p.y - tg.y; const l = hyp(ux, uy) || 1; ux /= l; uy /= l;
        if (role === 1 && !M.fl) M.fl = Math.random() < 0.5 ? 1 : -1;
        const ang = role === 1 ? M.fl * (1.05 + 0.2 * M.str) : M.str * (lv <= 1 ? 0.25 : 0.55);
        const cx = Math.cos(ang), sx = Math.sin(ang), rx = ux * cx - uy * sx, ry = ux * sx + uy * cx;
        M.goal = { x: clamp(tg.x + rx * want, -HW + 1.5, HW - 1.5), y: clamp(tg.y + ry * want, -HH + 1.5, HH - 1.5) };
      } else if (M.mode === 'fight') M.goal = { x: 0, y: 0 };
    }
    // movement
    const g = M.goal || { x: p.x, y: p.y };
    let gd = 0;
    if (M.dg > 0) { I.ax = M.ux; I.ay = M.uy; gd = 9; }
    else if (M.unst > 0) { I.ax = M.ux; I.ay = M.uy; gd = 9; }
    else gd = steer(W, p, g.x, g.y, M, I);
    // unstick
    if (hyp(I.ax, I.ay) > 0.5 && hyp(p.vx, p.vy) < 0.6 && p.st <= 0 && !p.scn) { M.stuck += dt; if (M.stuck > 0.9) { M.stuck = 0; const a = Math.random() * 6.283; M.ux = Math.cos(a); M.uy = Math.sin(a); M.unst = 0.6; M.side = -(M.side || 1); } }
    else M.stuck = 0;
    const atGoal = gd < 0.7;
    I.sc = M.mode === 'reload' && atGoal && M.dg <= 0 && p.am < AMAX ? 1 : 0;
    if (I.sc && lv >= 2 && p.am >= 2 && tg && hyp(tg.x - p.x, tg.y - p.y) < D.range * 0.8) I.sc = 0;
    if (M.mode === 'reload' && p.am >= (lv >= 2 ? AMAX : 2)) M.t = 0;
    I.du = M.dk > 0 || (M.mode === 'hide' && atGoal) || (M.cov && atGoal && M.tt > 0.2) ? 1 : 0;
    if (I.sc) { I.ax = 0; I.ay = 0; }
    // throwing
    if (tg && M.tt <= 0 && canThrow(p) && M.mode !== 'reload' && M.dk <= 0) {
      const d0 = hyp(tg.x - p.x, tg.y - p.y);
      if (d0 <= D.range + (p.big > 0 ? 2 : 0)) {
        let ex = tg.x, ey = tg.y;
        for (let k = 0; k < 2; k++) { const T = hyp(ex - p.x, ey - p.y) / (p.big > 0 ? VBB : VB); ex = tg.x + tg.vx * T * D.lead; ey = tg.y + tg.vy * T * D.lead; }
        const e = D.err * (0.4 + d0 / 14);
        ex += gauss() * e; ey += gauss() * e;
        const tb = launch(W, p, ex, ey, {});
        const hit = pathBlock(W, p, tb);
        let go = true;
        if (hit.k === 'ob' && hit.d < 3.2 && lv >= 2) go = false;                   // my own cover is in the way
        else if (hit.k === 'mate') go = false;
        else if (hit.k === 'ob' && W.ob[hit.j].k !== 't' && Math.random() > D.low) go = false;  // hiding target: crumble its wall?
        else if (hit.k === 'ob' && W.ob[hit.j].k === 't' && lv >= 2) go = false;
        if (go) {
          I.thr = [r1(ex), r1(ey)];
          M.tt = D.gap[0] + Math.random() * (D.gap[1] - D.gap[0]);
          if (p.rap > 0) M.tt *= 0.35;
          if (Math.random() < D.ret && p.rap <= 0 && p.am <= 1) { M.hide = 0.7 + Math.random() * 0.6; M.t = 0; }
        } else { M.tt = 0.25; M.str = -M.str; M.strT = 1.5; M.t = Math.min(M.t, 0.1); }
      } else M.tt = 0.15;
    }
    return I;
  }

  /* ---------- coarse state ---------- */
  function pickMap(mp, prev) {
    if (mp >= 0 && mp < MAPS.length) return mp;
    let k = Math.floor(Math.random() * MAPS.length);
    if (k === prev) k = (k + 1 + Math.floor(Math.random() * (MAPS.length - 1))) % MAPS.length;
    return k;
  }
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 2, 8);
    const mp = typeof o.map === 'number' && o.map >= -1 && o.map < MAPS.length ? o.map : -1;
    const need = [2, 3, 5].includes(+o.need) ? +o.need : 3;
    return {
      rid: 1 + U.rand(99999), nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), np,
      tm: o.mode === 'team' && np >= 4 && np % 2 === 0 ? 1 : 0, need, mp, it: o.items === 0 ? 0 : 1,
      ph: 'count', rd: 1, mk: pickMap(mp, -1), wins: Array(np).fill(0), hits: Array(np).fill(0), rw: -1, why: '', res: null,
    };
  }
  function seatsOfSide(st, side) { const out = []; for (let i = 0; i < st.np; i++) if ((st.tm ? i % 2 : i) === side) out.push(i); return out; }
  function roundOver(st, rw, why, hits, thr) {
    const n = Object.assign({}, st, { wins: st.wins.slice(), hits: st.hits.slice(), ph: 'end', rw, why: why || '' });
    if (rw >= 0) for (const s of seatsOfSide(st, rw)) n.wins[s]++;
    if (Array.isArray(hits)) hits.forEach((v, i) => { if (i < n.hits.length) n.hits[i] = Math.min(999, (n.hits[i] | 0) + (v | 0)); });
    n.thr = Array.from({ length: n.hits.length }, (_, i) => Math.min(9999, ((st.thr && st.thr[i]) | 0) + ((Array.isArray(thr) && thr[i]) | 0)));
    return n;
  }
  function nextRound(st) {
    const mx = Math.max(...st.wins);
    if (mx >= st.need || st.rd >= st.need * st.np + 4) {
      const order = st.wins.map((v, i) => [i, v, st.hits[i] | 0]).sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[0] - b[0]);
      return Object.assign({}, st, { ph: 'done', res: order });
    }
    return Object.assign({}, st, { rd: st.rd + 1, mk: pickMap(st.mp, st.mk), ph: 'count', rw: -1, why: '' });
  }
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res) || !st.res.length) return null;
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번';
    const top = st.res[0][1], winners = st.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = st.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '승 · 맞힘 ' + r[2]);
    let title, lines2 = lines;
    const col = (a, fm) => Array.from({ length: st.np || st.res.length }, (_, i) => fm((Array.isArray(a) ? a[i] : 0) | 0, i));
    const pre = [];
    if (st.tm) {
      winners.sort((a, b) => a - b);
      const ws = winners.length ? winners[0] % 2 : -1;
      title = (ws >= 0 ? TEAM_NM[ws] + ' 승리!' : '무승부');
      const sum = (a, side) => seatsOfSide(st, side).reduce((t, i) => t + ((Array.isArray(a) ? a[i] : 0) | 0), 0);
      lines2 = [0, 1].map((sd) => { const th = sum(st.thr, sd), h = sum(st.hits, sd);
        return TEAM_NM[sd] + ' (' + seatsOfSide(st, sd).map(nm).join('·') + ')  ' + (st.wins[sd] | 0) + '승 · 맞힘 ' + h + ' · 던짐 ' + th + ' · 명중률 ' + (th ? Math.round(100 * Math.min(1, h / th)) : 0) + '%'; });
      pre.push({ label: '팀', values: col(null, (v, i) => TEAM_NM[i % 2]) });
    } else title = winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승';
    const stats = pre.concat([{ label: '라운드 승', values: col(st.wins, (v) => v + '승') }, { label: '맞힌 눈덩이', values: col(st.hits, (v) => v + '번') },
      { label: '던진 눈덩이', values: col(st.thr, (v) => v + '개') }, { label: '명중률', values: col(st.thr, (v, i) => (v ? Math.round(100 * Math.min(1, ((st.hits && st.hits[i]) | 0) / v)) + '%' : '-')) }]);
    return { stats, winners, title, text: (st.tm ? (st.np >> 1) + ':' + (st.np >> 1) + ' 팀전' : '각자 대결') + ' · ' + st.need + '승 먼저\n' + lines2.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  let STICK_R = 46, TOPH = 66; const ZK = 0.62;
  const KC = () => { const v = L.ui && L.ui.ctlScale ? +L.ui.ctlScale() : 1; return v > 0 ? v : 1; };
  const CSS = `
.sb-btn{position:absolute;border-radius:50%;border:2px solid rgba(242,233,216,.35);background:rgba(26,32,50,.82);color:#f2e9d8;
  font:700 15px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;
  touch-action:none;user-select:none;-webkit-user-select:none;z-index:3;padding:0;box-shadow:0 4px 12px rgba(0,0,0,.4);
  -webkit-tap-highlight-color:transparent;cursor:pointer}
.sb-btn::before{content:'';position:absolute;inset:-9px;border-radius:50%}
.sb-btn small{font-size:10px;font-weight:600;opacity:.75;line-height:1}
.sb-btn.on{transform:scale(.94)}
.sb-btn.fired{animation:sbf .28s ease-out}
@keyframes sbf{0%{transform:scale(.86);box-shadow:0 0 0 0 rgba(255,255,255,.75),0 4px 12px rgba(0,0,0,.4)}100%{transform:scale(1);box-shadow:0 0 0 16px rgba(255,255,255,0),0 4px 12px rgba(0,0,0,.4)}}
.sb-btn.buf{border-color:#ffd27a;border-style:dashed}
.sb-btn.on{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}
.sb-btn.cd{opacity:.5}
.sb-btn.pulse{animation:sbp .9s ease-in-out infinite}
@keyframes sbp{50%{box-shadow:0 0 0 7px rgba(227,174,69,.5),0 4px 12px rgba(0,0,0,.4)}}
.sb-throw{width:88px;height:88px;right:10px;bottom:12px;font-size:17px}
.sb-scoop{width:68px;height:68px;right:110px;bottom:8px;font-size:14px}
.sb-duck{width:64px;height:64px;right:22px;bottom:112px;font-size:14px}
.sb-pips{display:flex;gap:3px;height:10px;align-items:center}
.sb-pips i{width:8px;height:8px;border-radius:50%;background:rgba(242,233,216,.22)}
.sb-pips i.f{background:#fff;box-shadow:0 0 5px #bfe3ff}
.sb-pips i.b{width:10px;height:10px;background:#bfe3ff;box-shadow:0 0 6px #8fd0ff}
.sb-pips i.r{background:#ffd27a;box-shadow:0 0 5px #ffd27a}
.sb-btn.on .sb-pips i{background:rgba(42,29,5,.3)}
.sb-btn.on .sb-pips i.f{background:#2a1d05;box-shadow:none}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    let st = null, key = null, W = null, phase = 'wait', cd = 0, endT = 0, lay = null, flip = false, shake = 0, tipT = 0, startT = 0, tipFull = false;
    let bgCv = null, bgKey = '', gCv = null, gCtx = null, gKey = '', fadeT = 0;
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const ctrlOn = () => me() >= 0 && !auto();
    const COL = (s) => P(s).color || ['#ee6a55', '#5bb3e6', '#7cc66a', '#e3ae45'][s % 4];
    const sideCol = (side) => (st && st.tm ? TEAM_C[side] || '#f2e9d8' : COL(side));
    const curKey = () => (st ? st.rid + '.' + st.rd : null);

    /* ----- round start ----- */
    let aiMem = [], vis = [], parts = [], rings = [], floats = [], conf = [], flakes = [];
    function startRound() {
      key = curKey();
      W = newWorld(st);
      aiMem = W.pl.map(() => ({}));
      vis = W.pl.map((p) => ({ fx: p.x, fy: p.y, foot: 0, spl: [], hitT: 0, bob: Math.random() * 6, tgx: p.x, tgy: p.y }));
      parts = []; rings = []; floats = []; snaps = []; lastFx = 0; lastQ = -1; for (const k in remIn) delete remIn[k];
      locIn.thr = null; netA.n = 0;
      if (aim) aim = null;
      phase = st.ph === 'play' ? 'play' : st.ph === 'count' ? 'count' : 'end';
      const first = st.rd === 1 && ctrlOn();
      cd = first ? FIRST_T : COUNT_T; endT = END_T;
      // the full control card only the first time on this phone (until the first throw); later just one short line
      let seen = false; try { seen = localStorage.getItem('lounge.snowball.tip') === '1'; } catch (e) {}
      tipFull = first && !seen;
      tipT = first ? (tipFull ? 30 : 3.2) : 0;
      gKey = '';
      camY = 0;
      layout();
      const m = me(); if (m >= 0 && lay) camY = clamp(VY(W.pl[m].y) - 3, lay.minC, lay.maxC);
    }

    /* ----- layout ----- */
    function layout() {
      const k = KC(); STICK_R = Math.round(46 * k); TOPH = st && st.np > 4 ? 96 : 66;
      const w = cv.w, h = cv.h, bot = ctrlOn() ? (k > 1.2 ? Math.round(12 + 88 * k + 12 + 64 * k + 6) : Math.round(182 * Math.max(1, k))) : 12, M = 0.9;
      const ww = 2 * (HW + M), wh = 2 * (HH + M) + 1.2, visH = Math.max(120, h - TOPH - bot);
      // fit the width; if the yard is taller than the free band, a camera follows my kid up and down
      const s = Math.max(4, Math.min((w - 8) / ww, visH * 1.3 / wh));
      const ext = HH + M, half = visH / 2 / s, c0 = -0.6;
      let minC = -ext - 1.2 + half, maxC = ext - half;
      if (minC > maxC) { minC = maxC = c0; }
      lay = { s, ox: w / 2, cy0: TOPH + visH / 2, visH, bot, M, minC, maxC, scroll: maxC > minC };
      camY = clamp(camY, minC, maxC);
      const m = me();
      flip = !!(W && m >= 0 && spawns(st.np, st.tm)[m][1] < 0);
      buildBg(); buildGround();
      showBtns(); placeBtns();
    }
    function placeBtns() {
      if (!btn.duck) return;
      const k = KC(), f = Math.min(1.4, Math.max(0.8, k)), tb = Math.round(88 * k), sb = Math.round(68 * k), db = Math.round(64 * k);
      const set = (b, sz, r, bo, fs) => { const q = b.style; q.width = q.height = sz + 'px'; q.right = r + 'px'; q.bottom = bo + 'px'; q.fontSize = Math.round(fs * f) + 'px'; };
      set(btn.throw, tb, 10, 12, 17);
      set(btn.duck, db, 10 + (tb - db) / 2 + (k > 1.2 ? 0 : 12 * (1 - k)), 12 + tb + 12, 14);
      if (k > 1.2) set(btn.scoop, sb, 10 + tb + 8, 12 + tb + 12, 14);
      else set(btn.scoop, sb, 10 + tb + 12, 8, 14);
    }
    cv.onresize = layout;
    const onCtl = () => layout(); window.addEventListener('lounge-ctl', onCtl);
    const VX = (x) => (flip ? -x : x), VY = (y) => (flip ? -y : y);
    const SX = (x) => lay.ox + VX(x) * lay.s;
    const SY = (y) => lay.cy0 + (VY(y) - camY) * lay.s;
    let camY = 0;
    function camStep(rdt) {
      if (!lay || !W) return;
      let tgt = 0;
      const p = ctrlOn() ? myKid() : null;
      if (p && !p.out) tgt = VY(p.y) - 3;
      else { let n = 0; for (const q of W.pl) if (!q.out) { tgt += VY(q.y); n++; } tgt = n ? tgt / n : 0; }
      tgt = clamp(tgt, lay.minC, lay.maxC);
      camY += (tgt - camY) * Math.min(1, rdt * 4);
      camY = clamp(camY, lay.minC, lay.maxC);
    }
    const ZH = (z) => z * lay.s * ZK;
    function toWorld(px, py) { const x = (px - lay.ox) / lay.s, y = (py - lay.cy0) / lay.s + camY; return { x: flip ? -x : x, y: flip ? -y : y }; }

    /* ----- static layer: night sky, fence, snow, ice (world space, unflipped) ----- */
    function buildBg() {
      if (!lay || !W) return;
      const k = st.mk + '|' + HW + '|' + lay.s + '|' + cv.dpr;
      if (k === bgKey && bgCv) return;
      bgKey = k;
      const s = lay.s, dpr = cv.dpr, M = lay.M, ww = 2 * (HW + M), wh = 2 * (HH + M);
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(ww * s * dpr)); c.height = Math.max(1, Math.round(wh * s * dpr));
      const g = c.getContext('2d');
      g.setTransform(s * dpr, 0, 0, s * dpr, (HW + M) * s * dpr, (HH + M) * s * dpr);
      let seed = 7 + st.mk * 13; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      // snow field
      const gr = g.createLinearGradient(0, -HH, 0, HH);
      gr.addColorStop(0, '#dfe8f3'); gr.addColorStop(0.5, '#eef3f9'); gr.addColorStop(1, '#e3ebf5');
      g.fillStyle = gr; g.fillRect(-HW - M, -HH - M, ww, wh);
      // soft drifts
      for (let i = 0; i < 26; i++) {
        const x = (rnd() * 2 - 1) * HW, y = (rnd() * 2 - 1) * HH, r = 1.5 + rnd() * 3.5;
        const rg = g.createRadialGradient(x, y, 0, x, y, r);
        rg.addColorStop(0, rnd() < 0.5 ? 'rgba(255,255,255,.55)' : 'rgba(190,206,228,.35)'); rg.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = rg; g.beginPath(); g.ellipse(x, y, r * 1.4, r, 0, 0, 7); g.fill();
      }
      for (let i = 0; i < 900; i++) { g.fillStyle = rnd() < 0.6 ? 'rgba(150,170,205,.13)' : 'rgba(255,255,255,.8)'; const z = 0.06 + rnd() * 0.08; g.fillRect((rnd() * 2 - 1) * HW, (rnd() * 2 - 1) * HH, z, z); }
      // deep snow drifts: soft bright mounds
      for (const d of W.dr || []) {
        g.save();
        const dg = g.createRadialGradient(d.x, d.y - d.ry * 0.3, 0.2, d.x, d.y, Math.max(d.rx, d.ry) * 1.1);
        dg.addColorStop(0, '#ffffff'); dg.addColorStop(0.7, '#f4f8fd'); dg.addColorStop(1, 'rgba(214,226,242,.0)');
        g.beginPath(); g.ellipse(d.x, d.y, d.rx + 0.5, d.ry + 0.5, 0, 0, 7); g.fillStyle = dg; g.fill();
        g.beginPath(); g.ellipse(d.x, d.y + 0.15, d.rx, d.ry, 0, 0, 7); g.strokeStyle = 'rgba(150,172,205,.35)'; g.lineWidth = 0.1; g.setLineDash([0.4, 0.35]); g.stroke(); g.setLineDash([]);
        g.fillStyle = 'rgba(170,190,220,.28)';
        for (let i = 0; i < 14; i++) { const a = rnd() * 6.28, rr0 = Math.sqrt(rnd()) * 0.85; g.beginPath(); g.ellipse(d.x + Math.cos(a) * d.rx * rr0, d.y + Math.sin(a) * d.ry * rr0, 0.5, 0.16, 0, 0, Math.PI); g.fill(); }
        g.restore();
      }
      // ice
      for (const ic of W.ice) {
        g.save(); g.beginPath(); g.ellipse(ic.x, ic.y, ic.rx + 0.35, ic.ry + 0.35, 0, 0, 7); g.fillStyle = 'rgba(255,255,255,.9)'; g.fill();
        g.beginPath(); g.ellipse(ic.x, ic.y, ic.rx, ic.ry, 0, 0, 7);
        const ig = g.createLinearGradient(ic.x - ic.rx, ic.y - ic.ry, ic.x + ic.rx, ic.y + ic.ry);
        ig.addColorStop(0, '#a9d6ee'); ig.addColorStop(0.5, '#cbe9f7'); ig.addColorStop(1, '#94c7e4');
        g.fillStyle = ig; g.fill(); g.clip();
        g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 0.08;
        for (let i = 0; i < 9; i++) { let x = ic.x + (rnd() * 2 - 1) * ic.rx * 0.8, y = ic.y + (rnd() * 2 - 1) * ic.ry * 0.8; g.beginPath(); g.moveTo(x, y); for (let j = 0; j < 4; j++) { x += (rnd() - 0.5) * 2.4; y += (rnd() - 0.5) * 1.6; g.lineTo(x, y); } g.stroke(); }
        g.fillStyle = 'rgba(255,255,255,.35)';
        for (let i = 0; i < 5; i++) { g.save(); g.translate(ic.x + (rnd() - 0.5) * ic.rx, ic.y + (rnd() - 0.5) * ic.ry); g.rotate(-0.5); g.fillRect(-1.2, -0.08, 2.4, 0.16); g.restore(); }
        g.restore();
        g.lineWidth = 0.12; g.strokeStyle = 'rgba(120,160,200,.5)'; g.beginPath(); g.ellipse(ic.x, ic.y, ic.rx, ic.ry, 0, 0, 7); g.stroke();
      }
      // wooden fence with snow caps
      g.lineCap = 'round';
      g.strokeStyle = '#6b4a33'; g.lineWidth = 0.32;
      g.strokeRect(-HW - 0.25, -HH - 0.25, 2 * HW + 0.5, 2 * HH + 0.5);
      g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 0.12;
      g.strokeRect(-HW - 0.33, -HH - 0.33, 2 * HW + 0.66, 2 * HH + 0.66);
      const post = (x, y) => { g.fillStyle = '#5a3c28'; g.fillRect(x - 0.28, y - 0.28, 0.56, 0.56); g.fillStyle = '#fbfdff'; g.beginPath(); g.arc(x, y - 0.06, 0.26, 0, 7); g.fill(); };
      for (let x = -HW; x <= HW + 0.01; x += 3) { post(x - 0.25 * Math.sign(x || 1) * 0, -HH - 0.25); post(x, HH + 0.25); }
      for (let y = -HH + 3; y < HH; y += 3) { post(-HW - 0.25, y); post(HW + 0.25, y); }
      bgCv = c;
    }
    /* dynamic ground layer (footprints, splats, scoop holes) — world space, unflipped */
    function buildGround() {
      if (!lay || !W) return;
      const k = key + '|' + lay.s + '|' + cv.dpr;
      if (k === gKey && gCv) return;
      gKey = k;
      const s = lay.s, dpr = cv.dpr;
      gCv = document.createElement('canvas');
      gCv.width = Math.max(1, Math.round(2 * HW * s * dpr)); gCv.height = Math.max(1, Math.round(2 * HH * s * dpr));
      gCtx = gCv.getContext('2d');
      gCtx.setTransform(s * dpr, 0, 0, s * dpr, HW * s * dpr, HH * s * dpr);
    }
    function stampFoot(x, y, a, side) {
      if (!gCtx) return;
      const nx = -Math.sin(a), ny = Math.cos(a), o = 0.22 * side;
      gCtx.save(); gCtx.translate(x + nx * o, y + ny * o); gCtx.rotate(a);
      gCtx.fillStyle = 'rgba(128,150,190,.32)'; gCtx.beginPath(); gCtx.ellipse(0, 0, 0.2, 0.12, 0, 0, 7); gCtx.fill();
      gCtx.restore();
    }
    function stampSplat(x, y, big) {
      if (!gCtx) return;
      const r = big ? 1.0 : 0.45;
      gCtx.save(); gCtx.translate(x, y);
      gCtx.fillStyle = 'rgba(120,145,185,.28)'; gCtx.beginPath(); gCtx.ellipse(0.05, 0.08, r * 1.15, r * 0.95, 0, 0, 7); gCtx.fill();
      gCtx.fillStyle = '#ffffff';
      for (let i = 0; i < 6; i++) { const a = Math.random() * 6.28, d = r * (0.5 + Math.random() * 0.6); gCtx.beginPath(); gCtx.arc(Math.cos(a) * d, Math.sin(a) * d, r * (0.18 + Math.random() * 0.18), 0, 7); gCtx.fill(); }
      gCtx.beginPath(); gCtx.arc(0, 0, r * 0.7, 0, 7); gCtx.fill();
      gCtx.restore();
    }
    function stampHole(x, y) {
      if (!gCtx) return;
      gCtx.fillStyle = 'rgba(115,140,185,.30)'; gCtx.beginPath(); gCtx.ellipse(x + (Math.random() - 0.5) * 0.4, y + 0.3, 0.42, 0.26, 0, 0, 7); gCtx.fill();
    }

    /* ----- input: floating stick (left), buttons (right), tap/drag on the yard to throw there; keys via api.input ----- */
    const locIn = { ax: 0, ay: 0, du: 0, sc: 0, thr: null, spd: 1 };
    let stick = null, aim = null, btnDu = false, btnSc = false;
    const netA = { n: 0, t: [0, 0] };
    function readMove() {
      let sx = 0, sy = 0;
      if (stick) {
        // small dead zone, then a quick ramp: full speed already at ~80 % of the ring
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), DZ = 6;
        if (d > DZ) { const m = Math.min(1, (d - DZ) / (STICK_R * 0.8 - DZ)); const mm = 0.25 + 0.75 * m; sx = dx / d * mm; sy = dy / d * mm; }
      }
      if (api.input && !sx && !sy) {
        const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down');
        if (kx || ky) { const m = hyp(kx, ky); sx = m > 1 ? kx / m : kx; sy = m > 1 ? ky / m : ky; }
      }
      locIn.ax = flip ? -sx : sx; locIn.ay = flip ? -sy : sy;
      locIn.du = btnDu || !!(api.input && api.input.held('duck')) ? 1 : 0;
      locIn.sc = btnSc || !!(api.input && api.input.held('scoop')) ? 1 : 0;
    }
    function myKid() { const m = me(); return W && m >= 0 ? W.pl[m] : null; }
    function enemies(p) { return W ? W.pl.filter((q) => !q.out && sideOf(W, q.i) !== sideOf(W, p.i)) : []; }
    function autoTarget(p, skip) {
      let best = -1, bd = 1e9;
      for (const q of enemies(p)) { if (q.i === skip) continue; const d = hyp(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; best = q.i; } }
      return best;
    }
    function predicted(p, q) {
      let ex = q.x, ey = q.y;
      for (let k = 0; k < 2; k++) { const T = hyp(ex - p.x, ey - p.y) / (p.big > 0 ? VBB : VB); ex = q.x + (q.vx || 0) * T; ey = q.y + (q.vy || 0) * T; }
      return { x: ex, y: ey };
    }
    function reticle() {
      const p = myKid(); if (!p || !aim) return null;
      if (aim.src === 'pt') return { x: aim.wx, y: aim.wy };
      let bx, by;
      const q = aim.tg >= 0 ? W.pl[aim.tg] : null;
      if (q && !q.out) { const e = predicted(p, q); bx = e.x; by = e.y; }
      else { aim.tg = autoTarget(p, -1); bx = aim.bx != null ? aim.bx : p.x + Math.cos(p.a) * 8; by = aim.by != null ? aim.by : p.y + Math.sin(p.a) * 8; aim.bx = bx; aim.by = by; }
      return { x: clamp(bx + aim.ox, -HW, HW), y: clamp(by + aim.oy, -HH, HH) };
    }
    function startAim(src, extra) {
      const p = myKid(); if (!p || p.out || phase !== 'play' || !ctrlOn()) return false;
      aim = Object.assign({ src, tg: autoTarget(p, -1), ox: 0, oy: 0, moved: 0 }, extra || {});
      tipT = Math.min(tipT, 0.4);
      return true;
    }
    function releaseAim(cancel) {
      if (!aim) return;
      const p = myKid(), r = reticle();
      aim = null;
      if (cancel || !p || !r || phase !== 'play') return;
      if (!canThrow(p)) {
        if (p.am <= 0 && p.big <= 0 && p.rap <= 0) { floats.push({ x: p.x, y: p.y, t: 0, life: 1.1, txt: '눈덩이 없음! 「뭉치기」 꾹', c: '#ffd27a', z: 2.8 }); api.buzz(20); pulseT = 2.2; }
        else if (!p.out) { bufThr = { x: r.x, y: r.y, t: 0.35 }; btn.throw.classList.add('buf'); } // still winding down: throw as soon as I can
        return;
      }
      sendThrow(p, r.x, r.y);
    }
    let bufThr = null;
    function sendThrow(p, x, y) {
      const tx = r1(x), ty = r1(y);
      bufThr = null; btn.throw.classList.remove('buf');
      btn.throw.classList.remove('fired'); void btn.throw.offsetWidth; btn.throw.classList.add('fired');
      rings.push({ x: tx, y: ty, t: 0, life: 0.3, r0: 1.4, r1: 0.4, c: '#e3ae45' });
      if (tipFull) { tipFull = false; tipT = Math.min(tipT, 0.5); try { localStorage.setItem('lounge.snowball.tip', '1'); } catch (e) {} }
      if (host()) locIn.thr = [tx, ty];
      else { netA.n = (netA.n + 1) % 1000; netA.t = [tx, ty]; pubT = 0; p.ta = TA_T; p.a = Math.atan2(ty - p.y, tx - p.x); if (p.big > 0) p.big--; else if (p.rap <= 0) p.am = Math.max(0, p.am - 1); p.cd = THROW_CD; }
      api.buzz(10);
    }
    let pulseT = 0;
    function onDown(e) {
      banner = null; // 알림은 누르면 바로 걷힘
      if (!ctrlOn() || !lay) return;
      const pt = cv.local(e);
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      if (e.pointerType === 'mouse' || pt.x > cv.w * 0.55) {   // aim at that spot on the yard
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        const w = toWorld(pt.x, pt.y);
        if (startAim('pt', { id: e.pointerId, wx: w.x, wy: w.y })) return;
        return;
      }
      stick = { id: e.pointerId, bx: pt.x, by: pt.y, x: pt.x, y: pt.y };
      if (!tipFull) tipT = Math.min(tipT, 0.6);
    }
    function onMove(e) {
      if (aim && aim.src === 'pt' && aim.id === e.pointerId) { const pt = cv.local(e), w = toWorld(pt.x, pt.y); aim.wx = w.x; aim.wy = w.y; return; }
      if (!stick || e.pointerId !== stick.id) return;
      const pt = cv.local(e); stick.x = pt.x; stick.y = pt.y;
      const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), mx = STICK_R * 1.25;
      if (d > mx) { stick.bx = stick.x - dx / d * mx; stick.by = stick.y - dy / d * mx; }
    }
    function onUp(e) {
      if (aim && aim.src === 'pt' && aim.id === e.pointerId) { releaseAim(e.type === 'pointercancel'); return; }
      if (stick && e.pointerId === stick.id) stick = null;
    }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    const btn = {};
    function mkBtn(cls, label, sub, down, up, move) {
      const b = L.h('button', { class: 'sb-btn ' + cls, type: 'button', 'aria-label': label }, L.h('span', { class: 'lb', text: label }), L.h('small', { text: sub }));
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); try { b.setPointerCapture(e.pointerId); } catch (er) {} b.classList.add('on'); down(e); });
      if (move) b.addEventListener('pointermove', move);
      const off = (e) => { if (!b.classList.contains('on')) return; b.classList.remove('on'); if (up) up(e); };
      b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('lostpointercapture', off);
      b.addEventListener('contextmenu', noCtx);
      root.appendChild(b);
      return b;
    }
    btn.throw = mkBtn('sb-throw', '던지기', '', (e) => { if (!startAim('btn', { id: e.pointerId, lx: e.clientX, ly: e.clientY })) btn.throw.classList.remove('on'); },
      (e) => { if (aim && aim.src === 'btn') releaseAim(e && e.type === 'pointercancel'); },
      (e) => {
        if (!aim || aim.src !== 'btn' || aim.id !== e.pointerId || !lay) return;
        const dx = e.clientX - aim.lx, dy = e.clientY - aim.ly; aim.lx = e.clientX; aim.ly = e.clientY;
        const g = 1.25 / lay.s;   // ~1.25 screen px of drag per px of aim move
        aim.ox += (flip ? -dx : dx) * g; aim.oy += (flip ? -dy : dy) * g; aim.moved += hyp(dx, dy);
      });
    const pips = L.h('span', { class: 'sb-pips' });
    btn.throw.querySelector('small').replaceWith(pips);
    btn.scoop = mkBtn('sb-scoop', '뭉치기', '꾹 누르기', () => { btnSc = true; pulseT = 0; }, () => { btnSc = false; });
    btn.duck = mkBtn('sb-duck', '숙이기', '꾹 누르기', () => { btnDu = true; }, () => { btnDu = false; });
    btn.throw.dataset.action = 'throw'; btn.scoop.dataset.action = 'scoop'; btn.duck.dataset.action = 'duck';
    function showBtns() { const v = ctrlOn(); for (const k in btn) btn[k].style.display = v ? '' : 'none'; }
    let pipSig = '', btnVis = null;
    function syncBtns() {
      if (btnVis !== ctrlOn()) { btnVis = ctrlOn(); showBtns(); if (lay && (lay.bot > 20) !== btnVis) layout(); }
      const p = myKid(); if (!p || !ctrlOn()) return;
      const sig = p.am + '|' + p.big + '|' + (p.rap > 0 ? 1 : 0);
      if (sig !== pipSig) {
        pipSig = sig;
        pips.textContent = '';
        if (p.big > 0) for (let i = 0; i < p.big; i++) pips.appendChild(L.h('i', { class: 'b' }));
        else if (p.rap > 0) for (let i = 0; i < 3; i++) pips.appendChild(L.h('i', { class: 'r' }));
        else for (let i = 0; i < AMAX; i++) pips.appendChild(L.h('i', { class: i < p.am ? 'f' : '' }));
      }
      btn.throw.classList.toggle('cd', !canThrow(p) && !(btn.throw.classList.contains('on')));
      btn.scoop.classList.toggle('cd', p.am >= AMAX || p.out);
      btn.duck.classList.toggle('cd', p.out);
      const needAmmo = !p.out && p.am === 0 && p.big <= 0 && p.rap <= 0 && phase === 'play';
      btn.scoop.classList.toggle('pulse', needAmmo || pulseT > 0);
    }
    let kbAim = false;
    const offIn = api.input ? api.input.on((type, id) => {
      if (!ctrlOn()) return;
      if (id === 'throw') {
        if (type === 'down') { if (!aim) kbAim = startAim('key'); }
        else if (kbAim) { kbAim = false; if (aim && aim.src === 'key') releaseAim(false); }
        return;
      }
      if (id === 'target' && type === 'down') {
        const p = myKid(); if (!p) return;
        const cur = aim ? aim.tg : lockT;
        const es = enemies(p).map((q) => q.i).sort((a, b) => a - b);
        if (!es.length) return;
        const nx = es[(es.indexOf(cur) + 1) % es.length];
        if (aim) { aim.tg = nx; aim.ox = 0; aim.oy = 0; }
        lockT = nx; sfx('tick', 40);
      }
    }) : null;
    let lockT = -1;
    function keyAimStep(rdt) {
      if (!aim || aim.src !== 'key' || !api.input) return;
      const ax = api.input.axis('aimL', 'aimR'), ay = api.input.axis('aimU', 'aimD');
      if (ax || ay) { aim.ox += (flip ? -ax : ax) * 12 * rdt; aim.oy += (flip ? -ay : ay) * 12 * rdt; }
      if (lockT >= 0 && aim.tg !== lockT && W.pl[lockT] && !W.pl[lockT].out) aim.tg = lockT;
    }
    const releaseAll = () => { stick = null; btnDu = false; btnSc = false; aim = null; kbAim = false; for (const k in btn) btn[k].classList.remove('on'); };
    window.addEventListener('blur', releaseAll);

    /* ----- effects ----- */
    let lastSfx = {};
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function puff(x, y, z, n, sp, col, life) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.283, v = sp * (0.3 + Math.random());
        parts.push({ x, y, z: z || 0.5, vx: Math.cos(a) * v, vy: Math.sin(a) * v, vz: 2 + Math.random() * 4, t: 0, life: (life || 0.6) * (0.6 + Math.random() * 0.6), c: col || '#ffffff', r: 0.1 + Math.random() * 0.14 });
      }
      if (parts.length > 260) parts.splice(0, parts.length - 260);
    }
    function addFloat(x, y, txt, c, z) { floats.push({ x, y, t: 0, life: 1, txt, c, z: z == null ? 3.4 : z + 0.8 }); if (floats.length > 12) floats.shift(); }
    function onFx(code, a, b, c, d) {
      const m = me();
      switch (code) {
        case 0: sfx('whoosh', 70); break;
        case 1: case 2: {
          const by = code === 1 ? d & 7 : d, big = code === 1 && d >= 8;
          puff(a, b, 1.3, big ? 22 : 13, big ? 6 : 4.2);
          rings.push({ x: a, y: b, t: 0, life: 0.35, r0: 0.4, r1: big ? 2.6 : 1.6, c: '#ffffff' });
          if (vis[c]) { vis[c].hitT = 1; for (let k = 0; k < (big ? 4 : 2); k++) vis[c].spl.push({ ox: (Math.random() - 0.5) * 0.9, oy: Math.random() * 1.1, r: 0.16 + Math.random() * 0.14, t: 0 }); if (vis[c].spl.length > 8) vis[c].spl.splice(0, vis[c].spl.length - 8); }
          if (code === 2) {
            sfx('thud'); shake = Math.max(shake, c === m ? 0.9 : 0.4);
            addFloat(a, b, by === -1 ? '시간 아웃' : '아웃!', '#ee6a55', 3);
            if (c === m) api.buzz(90);
          } else {
            sfx('hit', 40); addFloat(a, b, big ? '쾅!' : '퍽!', '#ffffff');
            if (c === m) { api.buzz(35); shake = Math.max(shake, 0.5); } else if (by === m) api.buzz(12);
          }
          if (by === m && c !== m) addFloat(a, b - 0.4, '명중!', '#e3ae45', 3.6);
          break;
        }
        case 3: sfx('pop', 50); puff(a, b, 0.8, 9, 3.5, '#f4f8fd'); break;
        case 4: sfx('thud', 80); puff(a, b, 0.8, 22, 5.5, '#f4f8fd', 0.9); shake = Math.max(shake, 0.3); addFloat(a, b, '와르르!', '#bfe3ff', 2.4); break;
        case 5: sfx('bounce', 80); puff(a, b, 2.2, 10, 3, '#ffffff', 0.9); break;
        case 6: sfx('click', 80); puff(a, b, 1.2, 5, 2.5); break;
        case 7: sfx('click', 110); stampSplat(a, b, !!c); puff(a, b, 0.1, c ? 12 : 4, c ? 4.5 : 2.2); if (c) { shake = Math.max(shake, 0.25); rings.push({ x: a, y: b, t: 0, life: 0.4, r0: 0.5, r1: 2.2, c: '#bfe3ff' }); } break;
        case 8: {
          const k = PU_KEYS[d] || 'B';
          sfx('chip'); rings.push({ x: a, y: b, t: 0, life: 0.5, r0: 0.4, r1: 2.4, c: PU_COL[k] });
          addFloat(a, b, PU_NAME[k] + (k === 'C' && W && W.pl[c] && W.pl[c].sh ? ' (보호막)' : '') + '!', PU_COL[k], 2.8);
          if (c === m) api.buzz(18);
          break;
        }
        case 9: sfx('bounce'); rings.push({ x: a, y: b, t: 0, life: 0.45, r0: 0.6, r1: 2.0, c: '#ffd27a' }); addFloat(a, b, '막았다!', '#ffd27a'); break;
        case 10: sfx('thud', 80); puff(a, b, 0.3, 12, 4); addFloat(a, b, '쿵!', '#ffffff'); if (c === m) api.buzz(30); break;
        case 11: sfx('tick', 50); stampHole(a, b); if (c === m) { api.buzz(8); if (d >= AMAX) addFloat(a, b, '가득!', '#bfe3ff', 2.6); } break;
        case 12: sfx('pop', 100); rings.push({ x: a, y: b, t: 0, life: 0.6, r0: 0.2, r1: 1.8, c: PU_COL[PU_KEYS[c]] || '#fff' }); break;
        case 13: sfx('click', 120); puff(a, b, 0.6, 6, 2.5); break;
        case 14: sfx('whoosh'); banner = { t: '한 방 승부!', sub: '하트 1개씩 · 먼저 맞히면 승리', c: '#ee6a55', life: 1.4, max: 1.4 }; api.buzz(40); break;
      }
    }
    const hooks = { fx: onFx };
    let banner = null;

    /* ----- host flow ----- */
    const remIn = {};
    function inputsFor() {
      const out = [];
      for (let s = 0; s < W.pl.length; s++) {
        if (isAIseat(s)) out[s] = aiThink(W, W.pl[s], aiMem[s], P(s).ai ? lvOf(s) : 2, curDt);
        else if (localHuman(s)) out[s] = locIn;
        else out[s] = remIn[s] || (remIn[s] = { ax: 0, ay: 0, du: 0, sc: 0, thr: null, spd: 1, seen: -1 });
      }
      return out;
    }
    let curDt = 0;
    function hostFlow(dt) {
      if (!host() || !st || !W) return;
      if (st.ph === 'count' && phase === 'play') { api.setState(Object.assign({}, st, { ph: 'play' })); return; }
      if (st.ph === 'play' && phase === 'play' && W.res && !W.res.sent) { W.res.sent = 1; api.setState(roundOver(st, W.res.w, W.res.why, W.hits, W.thr)); return; }
      if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextRound(st)); } }
    }

    /* ----- online ----- */
    let pubT = 0, hsQ = 0, inQ = 0, lastQ = -1, lastFx = 0, snaps = [], lastSig = '', inT = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.pl.length) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remIn[s] || (remIn[s] = { ax: 0, ay: 0, du: 0, sc: 0, thr: null, spd: 1, seen: -1 });
        R.ax = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0; R.ay = fin(+o.ay) ? clamp(+o.ay, -1, 1) : 0;
        R.du = o.du ? 1 : 0; R.sc = o.sc ? 1 : 0;
        const n = o.n | 0;
        if (R.seen >= 0 && n !== R.seen && Array.isArray(o.t) && fin(+o.t[0]) && fin(+o.t[1])) R.thr = [clamp(+o.t[0], -HW, HW), clamp(+o.t[1], -HH, HH)];
        R.seen = n;
      }
    }
    function encode() {
      const Pp = [];
      for (const p of W.pl) {
        const fl = (p.du ? 1 : 0) | (p.scn ? 2 : 0) | (p.st > 0 ? 4 : 0) | (p.iv > 0 ? 8 : 0) | (p.out ? 16 : 0) | (p.sh ? 32 : 0) | (p.sled > 0 ? 64 : 0) | (p.rap > 0 ? 128 : 0) | (p.ta > 0 ? 256 : 0) | (p.sl > 0 ? 512 : 0);
        Pp.push(r1(p.x), r1(p.y), r1(p.vx), r1(p.vy), r1(p.a), fl, p.hp, p.am, p.big, r1(p.sc));
      }
      const B = [];
      const bl = W.balls.length > 18 ? W.balls.slice(-18) : W.balls;
      for (const b of bl) B.push(r1(b.x), r1(b.y), r1(b.z), r1(b.vx), r1(b.vy), r1(b.vz), b.o + (b.bg ? 8 : 0));
      const Pu = []; for (const u of W.pu) Pu.push(u.x, u.y, PU_KEYS.indexOf(u.k));
      return { k: key, q: hsQ, t: r1(W.t), ot: W.ot, P: Pp, B, U: Pu, O: W.ob.map((o) => Math.min(9, o.hp)).join(''), fx: W.fx.slice(-10) };
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.P)) return;
      lastQ = hs.q;
      if (fin(hs.t)) W.t = hs.t;
      W.ot = hs.ot ? 1 : 0;
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; try { onFx(e[1], +e[2] || 0, +e[3] || 0, e[4] | 0, e[5] | 0); } catch (er) {} }
      const m = me();
      W.pl.forEach((p, i) => {
        const o = i * 10, A = hs.P;
        if (!fin(+A[o]) || !fin(+A[o + 1])) return;
        const fl = A[o + 5] | 0;
        p.out = fl & 16 ? 1 : 0; p.sh = fl & 32 ? 1 : 0; p.sled = fl & 64 ? 0.2 : 0; p.rap = fl & 128 ? 0.2 : 0; p.sl = fl & 512 ? 0.2 : 0;
        p.st = fl & 4 ? 0.1 : 0; p.iv = fl & 8 ? 0.1 : 0;
        p.hp = A[o + 6] | 0; p.am = A[o + 7] | 0; p.big = A[o + 8] | 0; p.sc = +A[o + 9] || 0;
        p.nx = +A[o]; p.ny = +A[o + 1]; p.nvx = +A[o + 2] || 0; p.nvy = +A[o + 3] || 0; p.nat = now;
        if (i !== m || auto()) { p.du = fl & 1 ? 1 : 0; p.scn = fl & 2 ? 1 : 0; p.na = +A[o + 4] || 0; if (fl & 256) p.ta = 0.1; }
        else if (fl & 2) p.scn = 1;
      });
      snaps.push({ at: now, P: hs.P }); if (snaps.length > 5) snaps.shift();
      // balls: replace and advance by about half the round trip
      W.balls = [];
      const B = Array.isArray(hs.B) ? hs.B : [];
      for (let i = 0; i + 6 < B.length; i += 7) W.balls.push({ x: +B[i], y: +B[i + 1], z: +B[i + 2], vx: +B[i + 3], vy: +B[i + 4], vz: +B[i + 5], o: (B[i + 6] | 0) & 7, bg: (B[i + 6] | 0) >= 8 ? 1 : 0, age: 0.3 });
      let lag = 0.05 * SPD(); while (lag > 1e-4) { const h = Math.min(1 / 60, lag); for (let k = W.balls.length - 1; k >= 0; k--) if (!stepBall(W, W.balls[k], h, null, false)) W.balls.splice(k, 1); lag -= h; }
      W.pu = [];
      const Uu = Array.isArray(hs.U) ? hs.U : [];
      for (let i = 0; i + 2 < Uu.length; i += 3) W.pu.push({ x: +Uu[i], y: +Uu[i + 1], k: PU_KEYS[Uu[i + 2]] || 'B' });
      if (typeof hs.O === 'string' && hs.O.length === W.ob.length) for (let j = 0; j < W.ob.length; j++) W.ob[j].hp = +hs.O[j];
    }
    function guestStep(dt, rdt, now) {
      const m = auto() ? -1 : me();
      // others: interpolate ~100 ms behind
      const rt = now - 100;
      let A = null, Bs = snaps.length ? snaps[snaps.length - 1] : null, k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; Bs = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, Bs.at - A.at), 0, 1.3);
      W.pl.forEach((p, i) => {
        if (!Bs) return;
        const o = i * 10;
        if (i === m && phase === 'play' && !p.out) {
          readMove();
          const n = Math.max(1, Math.ceil(dt / SUB)), h = dt / n;
          const I = { ax: locIn.ax, ay: locIn.ay, du: locIn.du, sc: locIn.sc, spd: 1 };
          const st0 = p.st, sl0 = p.sl, iv0 = p.iv, sled0 = p.sled, rap0 = p.rap;
          for (let j = 0; j < n; j++) movePlayer(W, p, I, h);
          p.st = st0; p.sl = sl0; p.iv = iv0; p.sled = sled0; p.rap = rap0;
          if (fin(p.nx)) {
            const age = Math.min(0.15, (now - p.nat) / 1000);
            const tx = p.nx + p.nvx * age, ty = p.ny + p.nvy * age, d = hyp(tx - p.x, ty - p.y);
            if (d > 3) { p.x = tx; p.y = ty; } else { const kk = 1 - Math.exp(-rdt * 5); p.x += (tx - p.x) * kk; p.y += (ty - p.y) * kk; }
          }
          return;
        }
        const b = Bs.P, a = A ? A.P : null;
        const bx = +b[o], by = +b[o + 1], ba = +b[o + 4] || 0;
        const ox = p.x, oy = p.y;
        if (a && hyp(bx - a[o], by - a[o + 1]) < 8) { p.x = a[o] + (bx - a[o]) * k; p.y = a[o + 1] + (by - a[o + 1]) * k; p.a = a[o + 4] + wrapA(ba - a[o + 4]) * k; }
        else { p.x = bx; p.y = by; p.a = ba; }
        p.vx = p.nvx || 0; p.vy = p.nvy || 0;
        void ox; void oy;
        if (p.ta > 0) p.ta -= dt; if (p.cd > 0) p.cd -= dt;
      });
      const me0 = m >= 0 ? W.pl[m] : null;
      if (me0) { if (me0.ta > 0) me0.ta -= dt; if (me0.cd > 0) me0.cd -= dt; }
      const n = Math.min(20, Math.max(1, Math.ceil(dt / (1 / 60)))), h = dt / n;
      for (let j = 0; j < n; j++) for (let i = W.balls.length - 1; i >= 0; i--) if (!stepBall(W, W.balls[i], h, null, false)) W.balls.splice(i, 1);
    }
    function publish(rdt, now) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(encode());
        } else {
          const m = me(); if (m < 0) return;
          readMove();
          const sig = [r2(locIn.ax), r2(locIn.ay), locIn.du, locIn.sc, netA.n].join('|');
          if (sig === lastSig && inT > 0) return;
          if (pubT > 0 && sig !== lastSig && inT > 0.1) return;
          lastSig = sig; inT = 0.2; pubT = 1 / 30;
          inQ = (inQ + 1) % 100000;
          api.net.publish({ k: key, q: inQ, ax: r2(locIn.ax), ay: r2(locIn.ay), du: locIn.du, sc: locIn.sc, n: netA.n, t: netA.t });
        }
      } catch (e) {}
      void now;
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      if (curKey() !== key) startRound();
      if (!W) return;
      const dt = rdt * SPD();
      curDt = dt;
      if (phase === 'count') {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (b !== a && b > 0 && b <= 3) sfx('tick', 40);
        if (cd <= 0 && (host() || st.ph === 'play')) { phase = 'play'; sfx('pop'); api.buzz(16); startT = 0.9; }
      }
      if (phase === 'play' && (st.ph === 'end' || st.ph === 'done')) phase = 'end';
      if (tipT > 0) tipT -= rdt;
      if (startT > 0) startT -= rdt;
      if (pulseT > 0) pulseT -= rdt;
      readMove(); keyAimStep(rdt);
      if (bufThr) { const p = myKid(); bufThr.t -= rdt; if (!p || p.out || bufThr.t <= 0 || phase !== 'play') { bufThr = null; btn.throw.classList.remove('buf'); } else if (canThrow(p)) sendThrow(p, bufThr.x, bufThr.y); }
      if (host()) {
        pollHost();
        if (phase === 'play' && !W.res) tickWorld(W, Math.min(dt, 0.1), inputsFor(), hooks);
        else if (phase !== 'play') {
          for (const p of W.pl) { p.vx *= 0.85; p.vy *= 0.85; }
          const h = Math.min(dt, 0.1);
          for (let i = W.balls.length - 1; i >= 0; i--) if (!stepBall(W, W.balls[i], h, null, false)) W.balls.splice(i, 1);
        }
        hostFlow(dt);
      } else {
        pollGuest(now);
        guestStep(Math.min(dt, 0.1), rdt, now);
        if (st.ph === 'end') phase = 'end';
      }
      // footprints + effects
      W.pl.forEach((p, i) => {
        const v = vis[i]; if (!v) return;
        const d = hyp(p.x - v.fx, p.y - v.fy);
        if (d > 0.75 && !p.out) {
          if (p.sled > 0) { if (gCtx) { gCtx.strokeStyle = 'rgba(128,150,190,.28)'; gCtx.lineWidth = 0.12; const nx = -Math.sin(p.a) * 0.38, ny = Math.cos(p.a) * 0.38; gCtx.beginPath(); gCtx.moveTo(v.fx + nx, v.fy + ny); gCtx.lineTo(p.x + nx, p.y + ny); gCtx.moveTo(v.fx - nx, v.fy - ny); gCtx.lineTo(p.x - nx, p.y - ny); gCtx.stroke(); } }
          else if (d < 3) { v.foot = -v.foot || 1; stampFoot(p.x, p.y, Math.atan2(p.y - v.fy, p.x - v.fx), v.foot); }
          v.fx = p.x; v.fy = p.y;
        }
        if (v.hitT > 0) v.hitT -= rdt * 3;
        for (let k = v.spl.length - 1; k >= 0; k--) { v.spl[k].t += rdt; if (v.spl[k].t > 3) v.spl.splice(k, 1); }
        if (p.scn && Math.random() < rdt * 10) puff(p.x + Math.cos(p.a) * 0.5, p.y + Math.sin(p.a) * 0.5, 0.2, 1, 1.5);
        if (p.sled > 0 && Math.random() < rdt * 25) puff(p.x, p.y, 0.1, 1, 2);
      });
      camStep(rdt);
      fadeT += rdt;
      if (fadeT > 1.2 && gCtx) { fadeT = 0; gCtx.save(); gCtx.globalCompositeOperation = 'destination-out'; gCtx.fillStyle = 'rgba(0,0,0,.05)'; gCtx.fillRect(-HW, -HH, 2 * HW, 2 * HH); gCtx.restore(); }
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t += rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.z = Math.max(0, q.z + q.vz * rdt); q.vz -= 14 * rdt; q.vx *= 0.94; q.vy *= 0.94; if (q.t > q.life) parts.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t += rdt; if (rings[i].t > rings[i].life) rings.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t += rdt; if (floats[i].t > floats[i].life) floats.splice(i, 1); }
      for (let i = conf.length - 1; i >= 0; i--) { const c = conf[i]; c.t += rdt; c.x += c.vx * rdt; c.y += c.vy * rdt; c.vy += 420 * rdt; c.rot += c.vr * rdt; if (c.t > c.life) conf.splice(i, 1); }
      if (banner) { banner.life -= rdt; if (banner.life <= 0) banner = null; }
      shake = Math.max(0, shake - rdt * 2.6);
      publish(rdt, now);
    }

    /* ----- drawing ----- */
    const PU_COL = { B: '#8fd0ff', R: '#ffd27a', S: '#ee6a55', C: '#c98a5a' };
    function txt(t, x, y, col, font, al, stroke) {
      ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle';
      if (stroke) { ctx.lineWidth = stroke; ctx.strokeStyle = 'rgba(16,20,34,.85)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y); }
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function heartPath(c, x, y, r) {
      c.beginPath();
      c.moveTo(x, y + r * 0.9);
      c.bezierCurveTo(x - r * 1.6, y - r * 0.1, x - r * 0.8, y - r * 1.3, x, y - r * 0.45);
      c.bezierCurveTo(x + r * 0.8, y - r * 1.3, x + r * 1.6, y - r * 0.1, x, y + r * 0.9);
      c.closePath();
    }
    function drawWall(o, j) {
      const s = lay.s, x0 = SX(o.x) - o.w * s / 2, w = o.w * s, hh = o.h * s, yc = SY(o.y), y0 = yc - hh / 2;
      if (o.hp === 0) { // pile
        ctx.fillStyle = 'rgba(120,145,185,.25)'; ctx.beginPath(); ctx.ellipse(SX(o.x), yc + 2, w / 2 + 3, hh / 2 + 3, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#f7fafe'; ctx.beginPath(); ctx.ellipse(SX(o.x), yc - 1, w / 2 + 1, hh / 2 + 1, 0, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,1)'; ctx.beginPath(); ctx.ellipse(SX(o.x) - w * 0.1, yc - 3, w / 3, hh / 3, 0, 0, 7); ctx.fill();
        return;
      }
      const H = ZH(WALL_H) * (o.hp === 3 ? 1 : o.hp === 2 ? 0.9 : 0.72);
      // shadow
      ctx.fillStyle = 'rgba(90,115,160,.28)'; ctx.fillRect(x0 + 3, y0 + 4, w, hh);
      // front face
      const fy0 = y0 + hh - H, fh = H;
      const fg = ctx.createLinearGradient(0, fy0, 0, y0 + hh);
      fg.addColorStop(0, '#dfe8f4'); fg.addColorStop(1, '#b9c9df');
      ctx.fillStyle = fg; ctx.fillRect(x0, fy0, w, fh + 0.5);
      // top face
      ctx.fillStyle = '#fbfdff'; ctx.fillRect(x0, y0 - H, w, hh);
      // bricks on the front
      ctx.strokeStyle = 'rgba(120,145,185,.45)'; ctx.lineWidth = 1;
      const bw = Math.max(10, s * 1.1), rows = 2, rh = fh / rows;
      ctx.beginPath();
      for (let r = 0; r < rows; r++) {
        const yy = fy0 + r * rh; ctx.moveTo(x0, yy); ctx.lineTo(x0 + w, yy);
        for (let xx = x0 + (r % 2 ? bw / 2 : bw); xx < x0 + w - 2; xx += bw) { ctx.moveTo(xx, yy); ctx.lineTo(xx, yy + rh); }
      }
      ctx.stroke();
      // damage: bites out of the top edge
      if (o.hp < 3) {
        let sd = j * 977 + 13; const rnd = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
        const nb = o.hp === 2 ? 2 : 4;
        for (let k = 0; k < nb; k++) {
          const bx = x0 + w * (0.1 + 0.8 * rnd()), br = s * (0.3 + rnd() * 0.25), by = y0 - H + 1;
          ctx.save(); ctx.beginPath(); ctx.rect(x0 - 2, y0 - H - br, w + 4, br + hh + H); ctx.clip();
          ctx.fillStyle = '#c9d7ea'; ctx.beginPath(); ctx.arc(bx, by, br, 0, 7); ctx.fill();
          ctx.fillStyle = '#eaf1f8'; ctx.beginPath(); ctx.arc(bx, by - br * 0.35, br * 0.92, 0, 7); ctx.fill();
          ctx.restore();
          ctx.fillStyle = '#f7fafe'; ctx.beginPath(); ctx.arc(x0 + w * rnd(), y0 + hh + s * 0.15, s * (0.18 + rnd() * 0.15), 0, 7); ctx.fill();
          ctx.strokeStyle = 'rgba(110,135,180,.5)'; ctx.lineWidth = 1; ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(100,125,170,.6)'; ctx.lineWidth = 1.2;
        ctx.beginPath(); const cx = x0 + w * (0.3 + rnd() * 0.4); ctx.moveTo(cx, fy0); ctx.lineTo(cx + 4, fy0 + fh * 0.5); ctx.lineTo(cx - 2, fy0 + fh); ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(110,135,180,.55)'; ctx.lineWidth = 1; ctx.strokeRect(x0 + 0.5, y0 - H + 0.5, w - 1, hh + H - 1);
    }
    function drawSnowman(o) {
      const s = lay.s, x = SX(o.x), y = SY(o.y);
      if (o.hp === 0) {
        ctx.fillStyle = 'rgba(120,145,185,.25)'; ctx.beginPath(); ctx.ellipse(x + 2, y + 2, s * 1.2, s * 0.8, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#f7fafe'; ctx.beginPath(); ctx.ellipse(x, y, s * 1.1, s * 0.7, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#e46a2c'; ctx.save(); ctx.translate(x + s * 0.3, y - s * 0.1); ctx.rotate(0.6); ctx.beginPath(); ctx.moveTo(0, -2); ctx.lineTo(s * 0.5, 0); ctx.lineTo(0, 2); ctx.fill(); ctx.restore();
        return;
      }
      ctx.fillStyle = 'rgba(90,115,160,.3)'; ctx.beginPath(); ctx.ellipse(x + 3, y + 3, s * 0.95, s * 0.55, 0, 0, 7); ctx.fill();
      const ball = (cy, r) => {
        const g = ctx.createRadialGradient(x - r * 0.35, cy - r * 0.4, r * 0.1, x, cy, r);
        g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#c8d6e8');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, cy, r, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(110,135,180,.45)'; ctx.lineWidth = 1; ctx.stroke();
      };
      const r0 = s * 0.85, r1_ = s * 0.6, r2_ = s * 0.43;
      ball(y - r0 * 0.6, r0);
      const y1 = y - r0 * 0.6 - r0 * 0.75 - r1_ * 0.5;
      ball(y1, r1_);
      ctx.fillStyle = '#3a2c2a'; for (let k = 0; k < 2; k++) { ctx.beginPath(); ctx.arc(x, y1 - r1_ * 0.2 + k * r1_ * 0.45, 1.6, 0, 7); ctx.fill(); }
      // stick arms
      ctx.strokeStyle = '#6b4a33'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x - r1_ * 0.8, y1); ctx.lineTo(x - r1_ * 1.8, y1 - r1_ * 0.6); ctx.moveTo(x + r1_ * 0.8, y1); ctx.lineTo(x + r1_ * 1.8, y1 - r1_ * 0.5); ctx.stroke();
      if (o.hp >= 2) {
        const y2 = y1 - r1_ * 0.75 - r2_ * 0.55;
        ball(y2, r2_);
        ctx.fillStyle = '#2a2230'; ctx.beginPath(); ctx.arc(x - r2_ * 0.32, y2 - r2_ * 0.1, 1.5, 0, 7); ctx.arc(x + r2_ * 0.32, y2 - r2_ * 0.1, 1.5, 0, 7); ctx.fill();
        ctx.fillStyle = '#e46a2c'; ctx.beginPath(); ctx.moveTo(x, y2 + 1); ctx.lineTo(x + r2_ * 0.9, y2 + r2_ * 0.25); ctx.lineTo(x, y2 + r2_ * 0.35); ctx.fill();
        if (o.hp === 3) { // bucket hat
          ctx.fillStyle = '#7d3b46'; ctx.fillRect(x - r2_ * 0.75, y2 - r2_ * 1.05, r2_ * 1.5, r2_ * 0.25); ctx.fillRect(x - r2_ * 0.5, y2 - r2_ * 1.6, r2_, r2_ * 0.6);
        }
        ctx.fillStyle = '#b8323a'; ctx.fillRect(x - r1_ * 0.7, y1 - r1_ * 0.85, r1_ * 1.4, r1_ * 0.22);
      }
    }
    function drawTree(o) {
      const s = lay.s, x = SX(o.x), y = SY(o.y);
      ctx.fillStyle = 'rgba(70,95,140,.28)'; ctx.beginPath(); ctx.ellipse(x + s * 0.6, y + s * 0.4, s * 1.25, s * 0.6, 0.2, 0, 7); ctx.fill();
      ctx.fillStyle = '#5a3c28'; ctx.fillRect(x - s * 0.18, y - s * 0.7, s * 0.36, s * 0.75);
      const layers = [[0.75, 1.25, 0.95], [1.65, 1.0, 0.85], [2.5, 0.75, 0.7]];
      for (const [h0, r, hh] of layers) {
        const yb = y - h0 * s * 0.85, yt = yb - hh * s * 1.25;
        ctx.fillStyle = '#2f6b58'; ctx.beginPath(); ctx.moveTo(x - r * s, yb); ctx.lineTo(x + r * s, yb); ctx.lineTo(x, yt); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#24574a'; ctx.beginPath(); ctx.moveTo(x, yt); ctx.lineTo(x + r * s, yb); ctx.lineTo(x + r * s * 0.2, yb); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#f7fbff'; ctx.beginPath(); ctx.moveTo(x - r * s * 0.85, yb - 1); ctx.quadraticCurveTo(x - r * s * 0.3, yb - s * 0.35, x, yb - s * 0.12); ctx.quadraticCurveTo(x + r * s * 0.4, yb - s * 0.4, x + r * s * 0.85, yb - 1); ctx.lineTo(x + r * s * 0.5, yb - s * 0.2); ctx.lineTo(x, yt + s * 0.25); ctx.lineTo(x - r * s * 0.5, yb - s * 0.2); ctx.closePath(); ctx.globalAlpha = 0.9; ctx.fill(); ctx.globalAlpha = 1;
      }
    }
    function drawKid(p, now) {
      const s = lay.s, x = SX(p.x), y = SY(p.y), col = COL(p.i), v = vis[p.i];
      const u = s * 1.08;
      if (p.out) { // snow angel
        ctx.save(); ctx.globalAlpha = 0.85;
        ctx.fillStyle = 'rgba(120,145,185,.35)'; ctx.beginPath(); ctx.ellipse(x, y, u * 1.25, u * 0.75, 0, 0, 7); ctx.fill();
        ctx.fillStyle = shade(col, 0.25); ctx.beginPath(); ctx.ellipse(x, y + u * 0.15, u * 0.55, u * 0.42, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#f3d2b5'; ctx.beginPath(); ctx.arc(x, y - u * 0.45, u * 0.36, 0, 7); ctx.fill();
        ctx.strokeStyle = '#3a2c2a'; ctx.lineWidth = 1.3; const e = u * 0.12;
        for (const sx of [-1, 1]) { const ex = x + sx * u * 0.14, ey = y - u * 0.48; ctx.beginPath(); ctx.moveTo(ex - e, ey - e); ctx.lineTo(ex + e, ey + e); ctx.moveTo(ex + e, ey - e); ctx.lineTo(ex - e, ey + e); ctx.stroke(); }
        ctx.fillStyle = shade(col, -0.25); ctx.beginPath(); ctx.arc(x, y - u * 0.55, u * 0.36, Math.PI, 0); ctx.fill();
        ctx.restore();
        return;
      }
      const inv = p.iv > 0 && Math.floor(now / 70) % 2 === 0;
      ctx.save();
      if (inv) ctx.globalAlpha = 0.55;
      const crouch = p.ta > 0 ? 1 : p.du ? 0.58 : p.scn ? 0.66 : 1;
      const bob = Math.sin(now / 90 + v.bob) * (hyp(p.vx, p.vy) > 1 ? 1.2 : 0);
      // shadow (+ team ring)
      ctx.fillStyle = 'rgba(70,95,140,.3)'; ctx.beginPath(); ctx.ellipse(x, y + u * 0.15, u * 0.8, u * 0.36, 0, 0, 7); ctx.fill();
      if (st.tm) { ctx.strokeStyle = TEAM_C[p.i % 2]; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(x, y + u * 0.15, u * 0.95, u * 0.45, 0, 0, 7); ctx.stroke(); }
      if (p.sled > 0) { // red sled under the kid
        ctx.save(); ctx.translate(x, y); ctx.rotate(VA(p.a) + Math.PI / 2);
        ctx.fillStyle = '#b8323a'; rr(ctx, -u * 0.55, -u * 1.0, u * 1.1, u * 2.0, u * 0.3); ctx.fill();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-u * 0.6, -u); ctx.lineTo(-u * 0.6, u); ctx.moveTo(u * 0.6, -u); ctx.lineTo(u * 0.6, u); ctx.stroke();
        ctx.restore();
      }
      if (p.sh) { ctx.strokeStyle = 'rgba(255,210,122,.7)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(x, y - u * 0.7 * crouch, u * 1.0, u * 1.25 * crouch + u * 0.3, 0, 0, 7); ctx.stroke(); }
      const fa = VA(p.a), fx = Math.cos(fa), fy = Math.sin(fa);
      // boots
      ctx.fillStyle = '#3a2c34';
      const step = Math.sin(now / 80 + v.bob) * (hyp(p.vx, p.vy) > 1 ? u * 0.12 : 0);
      ctx.beginPath(); ctx.ellipse(x - u * 0.28, y + u * 0.12 + step, u * 0.2, u * 0.14, 0, 0, 7); ctx.ellipse(x + u * 0.28, y + u * 0.12 - step, u * 0.2, u * 0.14, 0, 0, 7); ctx.fill();
      // body (puffy coat)
      const by = y - u * 0.45 * crouch + bob * 0.3, bh = u * 0.62 * crouch + u * 0.1;
      const cg = ctx.createLinearGradient(x - u * 0.6, by - bh, x + u * 0.6, by + bh);
      cg.addColorStop(0, shade(col, 0.25)); cg.addColorStop(1, shade(col, -0.25));
      ctx.fillStyle = cg; ctx.beginPath(); ctx.ellipse(x, by, u * 0.62, bh, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(20,24,40,.35)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.beginPath(); ctx.moveTo(x - u * 0.5, by); ctx.quadraticCurveTo(x, by + bh * 0.4, x + u * 0.5, by); ctx.stroke();
      // arms / mittens
      const hy = by - bh * 0.1;
      const throwing = p.ta > 0;
      ctx.fillStyle = shade(col, -0.35);
      if (p.scn) { ctx.beginPath(); ctx.arc(x + fx * u * 0.55 - u * 0.2, y + fy * u * 0.3, u * 0.17, 0, 7); ctx.arc(x + fx * u * 0.55 + u * 0.2, y + fy * u * 0.3, u * 0.17, 0, 7); ctx.fill(); const pr = clamp(p.sc / SCOOP_T, 0, 1); ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x + fx * u * 0.55, y + fy * u * 0.3 - u * 0.1, u * (0.08 + 0.22 * pr), 0, 7); ctx.fill(); }
      else if (throwing) { const k = 1 - p.ta / TA_T; ctx.beginPath(); ctx.arc(x + fx * u * (0.3 + 0.6 * k), hy - u * (0.7 - 0.6 * k) + fy * u * 0.3, u * 0.18, 0, 7); ctx.arc(x - u * 0.62, hy + u * 0.1, u * 0.17, 0, 7); ctx.fill(); }
      else {
        ctx.beginPath(); ctx.arc(x - u * 0.64, hy + u * 0.12, u * 0.17, 0, 7); ctx.arc(x + u * 0.64, hy + u * 0.12, u * 0.17, 0, 7); ctx.fill();
        if (p.big > 0) { ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x + u * 0.66, hy - u * 0.25, u * 0.38, 0, 7); ctx.fill(); ctx.strokeStyle = '#8fd0ff'; ctx.lineWidth = 1.5; ctx.stroke(); }
        else if (p.am > 0) { ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x + u * 0.66, hy + u * 0.02, u * 0.15, 0, 7); ctx.fill(); }
      }
      // scarf
      const hy2 = by - bh + u * 0.05;
      ctx.fillStyle = p.i % 2 ? '#f2e9d8' : '#e3ae45'; ctx.beginPath(); ctx.ellipse(x, hy2, u * 0.42, u * 0.14, 0, 0, 7); ctx.fill();
      ctx.fillRect(x + u * 0.12, hy2, u * 0.16, u * 0.38);
      // head
      const hr = u * 0.44, hcy = hy2 - hr * 0.85;
      ctx.fillStyle = '#f3d2b5'; ctx.beginPath(); ctx.arc(x, hcy, hr, 0, 7); ctx.fill();
      const back = fy < -0.55;   // facing away from the camera
      if (!back) {
        const ex = fx * hr * 0.3, ey = Math.max(0, fy) * hr * 0.15;
        ctx.fillStyle = '#2a2230';
        if (p.st > 0) { ctx.strokeStyle = '#2a2230'; ctx.lineWidth = 1.2; for (const sx of [-1, 1]) { const cx = x + ex + sx * hr * 0.36, cy = hcy + ey; ctx.beginPath(); ctx.moveTo(cx - 2, cy - 2); ctx.lineTo(cx + 2, cy + 2); ctx.moveTo(cx + 2, cy - 2); ctx.lineTo(cx - 2, cy + 2); ctx.stroke(); } }
        else { ctx.beginPath(); ctx.arc(x + ex - hr * 0.34, hcy + ey, Math.max(1.2, hr * 0.12), 0, 7); ctx.arc(x + ex + hr * 0.34, hcy + ey, Math.max(1.2, hr * 0.12), 0, 7); ctx.fill(); }
        ctx.fillStyle = 'rgba(238,106,85,.35)'; ctx.beginPath(); ctx.arc(x + ex - hr * 0.55, hcy + ey + hr * 0.3, hr * 0.17, 0, 7); ctx.arc(x + ex + hr * 0.55, hcy + ey + hr * 0.3, hr * 0.17, 0, 7); ctx.fill();
      }
      // knit hat + pompom
      const hc = shade(col, -0.3);
      ctx.fillStyle = hc; ctx.beginPath(); ctx.arc(x, hcy - hr * 0.1, hr * 1.02, Math.PI * 1.02, Math.PI * 1.98); ctx.closePath(); ctx.fill();
      if (back) { ctx.beginPath(); ctx.arc(x, hcy, hr * 1.0, 0, 7); ctx.fill(); }
      ctx.fillStyle = shade(col, 0.45); ctx.fillRect(x - hr, hcy - hr * 0.25, hr * 2, hr * 0.26);
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x, hcy - hr * 1.15, hr * 0.32, 0, 7); ctx.fill();
      // snow splats stuck on the coat
      for (const sp of v.spl) { const a = Math.max(0, 1 - sp.t / 3); ctx.globalAlpha = (inv ? 0.55 : 1) * a; ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x + sp.ox * u, by - bh * 0.6 + sp.oy * u * crouch, sp.r * u * 1.5, 0, 7); ctx.fill(); }
      ctx.globalAlpha = inv ? 0.55 : 1;
      if (v.hitT > 0) { ctx.globalAlpha = v.hitT * 0.6; ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.ellipse(x, by - u * 0.2, u * 0.75, bh + hr, 0, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
      ctx.restore();
      // stun stars
      const topY = hcy - hr * 1.6;
      if (p.st > 0) { for (let k = 0; k < 3; k++) { const a = now / 160 + k * 2.1; txt('✦', x + Math.cos(a) * u * 0.6, topY + Math.sin(a) * u * 0.2, '#ffd27a', '700 ' + Math.round(u * 0.5) + 'px ' + FONT); } }
      // hearts above head
      const hs = Math.max(3.2, u * 0.2);
      for (let k = 0; k < HP; k++) {
        const hx = x + (k - 1) * hs * 2.6, hyy = topY - hs * 1.2;
        heartPath(ctx, hx, hyy, hs);
        ctx.fillStyle = k < p.hp ? '#ee4a5a' : 'rgba(30,36,56,.35)'; ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 1; ctx.stroke();
      }
      if (p.i === me() && !auto()) txt('나', x, topY - hs * 4, '#e3ae45', '800 ' + Math.max(10, Math.round(u * 0.55)) + 'px ' + FONT, 'center', 3);
    }
    const VA = (a) => (flip ? a + Math.PI : a);
    function drawBall(b) {
      const s = lay.s, r = (b.bg ? BBR : BR) * s * 1.35 + 1.2, x = SX(b.x), y = SY(b.y), z = Math.max(0, b.z);
      const yz = y - ZH(z);
      const g = ctx.createRadialGradient(x - r * 0.35, yz - r * 0.35, r * 0.1, x, yz, r);
      g.addColorStop(0, '#ffffff'); g.addColorStop(1, b.bg ? '#a9d8f5' : '#cfdced');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, yz, r, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(90,115,160,.6)'; ctx.lineWidth = 1; ctx.stroke();
    }
    function drawBallShadow(b) {
      const s = lay.s, r = (b.bg ? BBR : BR) * s * 1.35 + 1.2, x = SX(b.x), y = SY(b.y), k = clamp(1 - b.z / 6, 0.4, 1);
      ctx.fillStyle = 'rgba(60,85,130,' + (0.32 * k) + ')'; ctx.beginPath(); ctx.ellipse(x, y, r * k, r * 0.5 * k, 0, 0, 7); ctx.fill();
    }
    function drawPU(u, now) {
      const s = lay.s, x = SX(u.x), y = SY(u.y), bob = Math.sin(now / 260 + u.x) * s * 0.15, r = s * 0.62, c = PU_COL[u.k];
      ctx.fillStyle = 'rgba(70,95,140,.3)'; ctx.beginPath(); ctx.ellipse(x, y + s * 0.2, r, r * 0.4, 0, 0, 7); ctx.fill();
      const yy = y - s * 0.7 + bob;
      ctx.save();
      ctx.shadowColor = c; ctx.shadowBlur = 10;
      ctx.fillStyle = 'rgba(26,32,50,.85)'; ctx.beginPath(); ctx.arc(x, yy, r, 0, 7); ctx.fill();
      ctx.restore();
      ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, yy, r, 0, 7); ctx.stroke();
      const q = r * 0.62;
      if (u.k === 'B') { ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x, yy, q * 0.85, 0, 7); ctx.fill(); ctx.strokeStyle = '#8fd0ff'; ctx.lineWidth = 1.5; ctx.stroke(); }
      else if (u.k === 'R') { ctx.fillStyle = '#ffffff'; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(x - q * 0.55 + k * q * 0.55, yy + (k === 1 ? -q * 0.3 : q * 0.15), q * 0.28, 0, 7); ctx.fill(); } ctx.strokeStyle = c; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x - q, yy + q * 0.6); ctx.lineTo(x + q, yy + q * 0.6); ctx.stroke(); }
      else if (u.k === 'S') { ctx.fillStyle = '#ee6a55'; rr(ctx, x - q * 0.9, yy - q * 0.35, q * 1.8, q * 0.6, q * 0.25); ctx.fill(); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x - q, yy + q * 0.45); ctx.lineTo(x + q * 0.8, yy + q * 0.45); ctx.quadraticCurveTo(x + q * 1.1, yy + q * 0.45, x + q * 1.05, yy + q * 0.1); ctx.stroke(); }
      else { ctx.fillStyle = '#e8dccb'; rr(ctx, x - q * 0.55, yy - q * 0.3, q * 1.0, q * 0.95, q * 0.15); ctx.fill(); ctx.fillStyle = '#7a4a2e'; ctx.fillRect(x - q * 0.45, yy - q * 0.25, q * 0.8, q * 0.22); ctx.strokeStyle = '#e8dccb'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x + q * 0.5, yy + q * 0.15, q * 0.25, -1.4, 1.4); ctx.stroke(); ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x - q * 0.2, yy - q * 0.45); ctx.quadraticCurveTo(x, yy - q * 0.75, x - q * 0.1, yy - q * 1.0); ctx.stroke(); }
    }
    function drawAim(now) {
      const p = myKid(); if (!p || p.out || !ctrlOn()) return;
      if (!aim) { // who 「던지기」 would lock onto right now: a soft ring under them
        if (phase !== 'play') return;
        const tg = lockT >= 0 && W.pl[lockT] && !W.pl[lockT].out ? lockT : autoTarget(p, -1), q = tg >= 0 ? W.pl[tg] : null;
        if (!q || hyp(q.x - p.x, q.y - p.y) > RMAX + 2) return;
        ctx.save(); ctx.setLineDash([4, 4]); ctx.lineDashOffset = -now / 60;
        ctx.strokeStyle = canThrow(p) ? 'rgba(227,174,69,.6)' : 'rgba(171,159,184,.45)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(SX(q.x), SY(q.y), lay.s * 1.25, lay.s * 0.75, 0, 0, 7); ctx.stroke();
        ctx.restore();
        return;
      }
      const r = reticle(); if (!r) return;
      // the locked kid (auto aim) gets a bright ring and a label; a dragged aim says 「직접 조준」
      const lk = aim.src !== 'pt' && aim.tg >= 0 && W.pl[aim.tg] && !W.pl[aim.tg].out ? W.pl[aim.tg] : null, manual = aim.src === 'pt' || hyp(aim.ox, aim.oy) > 0.8;
      if (lk) {
        ctx.save(); ctx.strokeStyle = manual ? 'rgba(227,174,69,.45)' : '#e3ae45'; ctx.lineWidth = 2.6;
        ctx.beginPath(); ctx.ellipse(SX(lk.x), SY(lk.y), lay.s * 1.3, lay.s * 0.8, 0, 0, 7); ctx.stroke(); ctx.restore();
      }
      txt(manual ? '직접 조준' : '자동 조준 · 끌면 옮겨요', SX(p.x), SY(p.y) + lay.s * 1.5 + 10, manual ? '#f2e9d8' : '#e3ae45', '700 11px ' + FONT, 'center', 3);
      const b = launch(W, p, r.x, r.y, {});
      ctx.save();
      ctx.setLineDash([5, 5]); ctx.lineDashOffset = -now / 40;
      ctx.strokeStyle = canThrow(p) ? 'rgba(227,174,69,.9)' : 'rgba(171,159,184,.7)'; ctx.lineWidth = 2.2;
      ctx.beginPath();
      let x = b.x, y = b.y, z = b.z, vz = b.vz;
      const T = hyp(b.tx - b.x, b.ty - b.y) / hyp(b.vx, b.vy), n = 16;
      ctx.moveTo(SX(x), SY(y) - ZH(z));
      for (let k = 1; k <= n; k++) { const dt = T / n; x += b.vx * dt; y += b.vy * dt; z += vz * dt; vz -= G * dt; ctx.lineTo(SX(x), SY(y) - ZH(Math.max(0, z))); }
      ctx.stroke(); ctx.setLineDash([]);
      // range ring
      ctx.strokeStyle = 'rgba(227,174,69,.18)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(SX(p.x), SY(p.y), RMAX * lay.s, 0, 7); ctx.stroke();
      const tx = SX(b.tx), ty = SY(b.ty), rr_ = lay.s * 0.9;
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(tx, ty, rr_, 0, 7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(tx - rr_ * 1.5, ty); ctx.lineTo(tx - rr_ * 0.5, ty); ctx.moveTo(tx + rr_ * 0.5, ty); ctx.lineTo(tx + rr_ * 1.5, ty); ctx.moveTo(tx, ty - rr_ * 1.5); ctx.lineTo(tx, ty - rr_ * 0.5); ctx.moveTo(tx, ty + rr_ * 0.5); ctx.lineTo(tx, ty + rr_ * 1.5); ctx.stroke();
      ctx.restore();
    }
    function drawWorld(now) {
      const s = lay.s;
      // static layers
      ctx.save(); ctx.translate(SX(0), SY(0)); if (flip) ctx.rotate(Math.PI);
      const M = lay.M;
      ctx.drawImage(bgCv, -(HW + M) * s, -(HH + M) * s, 2 * (HW + M) * s, 2 * (HH + M) * s);
      if (gCv) ctx.drawImage(gCv, -HW * s, -HH * s, 2 * HW * s, 2 * HH * s);
      ctx.restore();
      for (const r of rings) {
        const k = r.t / r.life;
        ctx.beginPath(); ctx.ellipse(SX(r.x), SY(r.y), (r.r0 + (r.r1 - r.r0) * k) * s, (r.r0 + (r.r1 - r.r0) * k) * s * 0.6, 0, 0, 7);
        ctx.strokeStyle = hexA(r.c, 0.8 * (1 - k)); ctx.lineWidth = 2.5; ctx.stroke();
      }
      for (const b of W.balls) drawBallShadow(b);
      // depth-sorted things
      const list = dl; list.length = 0;
      W.ob.forEach((o, j) => list.push({ y: VY(o.y) + (o.k === 'w' ? o.h / 2 : 0.2) * (o.hp === 0 ? 0 : 1) - (o.hp === 0 ? 3 : 0), t: 0, o, j }));
      for (const p of W.pl) list.push({ y: VY(p.y) + (p.out ? -3 : 0), t: 1, p });
      for (const u of W.pu) list.push({ y: VY(u.y), t: 2, u });
      for (const b of W.balls) list.push({ y: VY(b.y) + 0.3, t: 3, b });
      list.sort((a, b) => a.y - b.y);
      for (const it of list) {
        if (it.t === 0) { if (it.o.k === 'w') drawWall(it.o, it.j); else if (it.o.k === 'm') drawSnowman(it.o); else drawTree(it.o); }
        else if (it.t === 1) drawKid(it.p, now);
        else if (it.t === 2) drawPU(it.u, now);
        else drawBall(it.b);
      }
      for (const q of parts) { const k = q.t / q.life; ctx.globalAlpha = Math.max(0, 1 - k); ctx.fillStyle = q.c; ctx.beginPath(); ctx.arc(SX(q.x), SY(q.y) - ZH(q.z), Math.max(1, q.r * s), 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
      drawAim(now);
      // kids out of view: little arrows at the band edge
      for (const p of W.pl) {
        if (p.out) continue;
        const y = SY(p.y), top = TOPH + 4, bot = cv.h - lay.bot - 4;
        if (y > top - 6 && y - s * 2.4 < bot) continue;
        const x = clamp(SX(p.x), 14, cv.w - 14), up = y <= top - 6, ay = up ? top + 30 : bot - 8;
        ctx.fillStyle = COL(p.i); ctx.strokeStyle = 'rgba(16,20,34,.8)'; ctx.lineWidth = 2;
        ctx.beginPath(); if (up) { ctx.moveTo(x, ay - 9); ctx.lineTo(x - 8, ay + 3); ctx.lineTo(x + 8, ay + 3); } else { ctx.moveTo(x, ay + 9); ctx.lineTo(x - 8, ay - 3); ctx.lineTo(x + 8, ay - 3); }
        ctx.closePath(); ctx.stroke(); ctx.fill();
      }
      for (const f of floats) {
        const k = f.t / f.life, x = SX(f.x), y = SY(f.y) - ZH(f.z) - 10 - k * 22;
        ctx.save(); ctx.globalAlpha = Math.min(1, (1 - k) * 2.2);
        txt(f.txt, x, y, f.c, '800 14px ' + FONT, 'center', 3.5);
        ctx.restore();
      }
    }
    const dl = [];
    function drawStick() {
      if (!ctrlOn()) return;
      const bx = stick ? stick.bx : 24 + STICK_R, by = stick ? stick.by : cv.h - 30 - STICK_R;
      ctx.save();
      ctx.globalAlpha = stick ? 0.9 : 0.5;
      ctx.beginPath(); ctx.arc(bx, by, STICK_R, 0, 7); ctx.fillStyle = 'rgba(16,22,38,.45)'; ctx.fill();
      ctx.strokeStyle = 'rgba(242,233,216,.45)'; ctx.lineWidth = 2; ctx.stroke();
      let kx = bx, ky = by;
      if (stick) { const dx = stick.x - bx, dy = stick.y - by, d = hyp(dx, dy), m = Math.min(d, STICK_R); if (d > 0) { kx = bx + dx / d * m; ky = by + dy / d * m; } }
      if (stick && (kx !== bx || ky !== by)) { // direction wedge on the ring
        const an = Math.atan2(ky - by, kx - bx);
        ctx.beginPath(); ctx.arc(bx, by, STICK_R - 2, an - 0.45, an + 0.45); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 4; ctx.stroke();
      }
      ctx.beginPath(); ctx.arc(kx, ky, Math.round(22 * KC()), 0, 7); ctx.fillStyle = stick ? '#e3ae45' : 'rgba(242,233,216,.6)'; ctx.fill();
      if (!stick) txt('이동', kx, ky + 0.5, '#2a1d05', '700 12px ' + FONT);
      ctx.restore();
    }
    function fmt(t) { t = Math.max(0, Math.ceil(t)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); }
    function drawHud(now) {
      const w = cv.w, n = st.np, m = me();
      let ch = 40;
      if (n > 4) ch = drawHudBig(m);
      else {
      const gap = 5, cw = Math.min(124, (w - 12 - gap * (n - 1)) / n), x0 = (w - (cw * n + gap * (n - 1))) / 2, y0 = 5;
      for (let i = 0; i < n; i++) {
        const x = x0 + i * (cw + gap), p = W.pl[i];
        ctx.save();
        rr(ctx, x, y0, cw, ch, 10); ctx.fillStyle = p && p.out ? 'rgba(23,19,31,.6)' : 'rgba(23,19,31,.86)'; ctx.fill();
        ctx.strokeStyle = i === m ? '#e3ae45' : 'rgba(242,233,216,.18)'; ctx.lineWidth = i === m ? 1.6 : 1; ctx.stroke();
        ctx.beginPath(); ctx.arc(x + 11, y0 + 12, 5, 0, 7); ctx.fillStyle = COL(i); ctx.fill();
        if (st.tm) { txt(i % 2 ? 'B' : 'A', x + 11, y0 + 12.5, '#17131f', '800 7px ' + FONT); }
        let nm = name(i); ctx.font = '700 11px ' + FONT; while (nm.length > 1 && ctx.measureText(nm).width > cw - 44) nm = nm.slice(0, -1);
        txt(nm, x + 20, y0 + 12.5, p && p.out ? '#ab9fb8' : '#f2e9d8', '700 11px ' + FONT, 'left');
        txt('★' + (st.wins[i] | 0), x + cw - 6, y0 + 12.5, '#e3ae45', '700 11px ' + MONO, 'right');
        if (p) for (let k = 0; k < HP; k++) { heartPath(ctx, x + 12 + k * 12, y0 + 28, 4.3); ctx.fillStyle = k < p.hp ? '#ee4a5a' : 'rgba(242,233,216,.18)'; ctx.fill(); }
        if (p && !p.out) for (let k = 0; k < AMAX; k++) { ctx.beginPath(); ctx.arc(x + cw - 9 - k * 9, y0 + 28, 3.2, 0, 7); ctx.fillStyle = k < p.am ? '#ffffff' : 'rgba(242,233,216,.15)'; ctx.fill(); }
        if (p && p.out) txt('아웃', x + cw - 8, y0 + 27, '#ee6a55', '700 10px ' + FONT, 'right');
        ctx.restore();
      }
      }
      const y0 = 5;
      // round + clock
      const ot = W.ot, left = ot ? ROUND_T + OT_T - W.t : ROUND_T - W.t;
      const lab = st.rd + '라운드 · ' + (phase === 'count' ? MAPS[st.mk].nm : (ot ? '한 방 ' : '') + fmt(phase === 'play' || phase === 'end' ? left : ROUND_T));
      ctx.font = '700 12px ' + FONT;
      const tw = ctx.measureText(lab).width + 22, low = phase === 'play' && left < 10;
      rr(ctx, (w - tw) / 2, y0 + ch + 4, tw, 19, 9.5); ctx.fillStyle = ot ? '#ee6a55' : 'rgba(23,19,31,.84)'; ctx.fill();
      txt(lab, w / 2, y0 + ch + 14, ot ? '#fff' : low && Math.floor(now / 300) % 2 ? '#ee6a55' : '#e3ae45', '700 12px ' + FONT);
      if (st.tm) {   // team heart totals either side of the clock
        const sh = sideHearts(W);
        for (const sd of [0, 1]) {
          const t2 = '♥' + (sh[sd] | 0) + ' ★' + (st.wins[seatsOfSide(st, sd)[0]] | 0);
          ctx.font = '700 11px ' + MONO; const bw = ctx.measureText(t2).width + 14;
          const bx = sd === 0 ? (w - tw) / 2 - 6 - bw : (w + tw) / 2 + 6;
          if (bx < 2 || bx + bw > w - 2) continue;
          rr(ctx, bx, y0 + ch + 4, bw, 19, 9.5); ctx.fillStyle = hexA(TEAM_C[sd], 0.9); ctx.fill();
          txt(t2, bx + bw / 2, y0 + ch + 14, '#17131f', '700 11px ' + MONO);
        }
      }
    }
    /* 5–8 kids: two rows of compact cards (teams: red row on top, blue row below) */
    function drawHudBig(m) {
      const w = cv.w, n = st.np, rows = [[], []];
      if (st.tm) for (let i = 0; i < n; i++) rows[i % 2].push(i);
      else for (let i = 0; i < n; i++) rows[i < Math.ceil(n / 2) ? 0 : 1].push(i);
      const gap = 4, ch = 31, y00 = 5, lw = st.tm ? 16 : 0;
      rows.forEach((row, r) => {
        const k = row.length, y0 = y00 + r * (ch + 3);
        const cw = Math.min(110, (w - 10 - lw - gap * (k - 1)) / k), x00 = (w - lw - (cw * k + gap * (k - 1))) / 2 + lw;
        if (st.tm) { rr(ctx, x00 - lw - 1, y0, lw - 2, ch, 5); ctx.fillStyle = TEAM_C[r]; ctx.fill(); txt(r ? 'B' : 'A', x00 - lw / 2 - 2, y0 + ch / 2 + 0.5, '#17131f', '800 10px ' + FONT); }
        row.forEach((i, c) => {
          const x = x00 + c * (cw + gap), p = W.pl[i];
          ctx.save();
          rr(ctx, x, y0, cw, ch, 8); ctx.fillStyle = p && p.out ? 'rgba(23,19,31,.6)' : 'rgba(23,19,31,.86)'; ctx.fill();
          ctx.strokeStyle = i === m ? '#e3ae45' : st.tm ? hexA(TEAM_C[i % 2], 0.55) : 'rgba(242,233,216,.18)'; ctx.lineWidth = i === m ? 1.6 : 1; ctx.stroke();
          ctx.beginPath(); ctx.arc(x + 8, y0 + 9.5, 4, 0, 7); ctx.fillStyle = COL(i); ctx.fill();
          let nm = name(i); ctx.font = '700 10px ' + FONT;
          const rw = st.tm ? 2 : 20; while (nm.length > 1 && ctx.measureText(nm).width > cw - 16 - rw) nm = nm.slice(0, -1);
          txt(nm, x + 15, y0 + 10, p && p.out ? '#ab9fb8' : '#f2e9d8', '700 10px ' + FONT, 'left');
          if (!st.tm) txt('★' + (st.wins[i] | 0), x + cw - 4, y0 + 10, '#e3ae45', '700 10px ' + MONO, 'right');
          if (p) for (let q = 0; q < HP; q++) { heartPath(ctx, x + 8 + q * 9, y0 + 22, 3.3); ctx.fillStyle = q < p.hp ? '#ee4a5a' : 'rgba(242,233,216,.18)'; ctx.fill(); }
          if (p && !p.out) for (let q = 0; q < AMAX; q++) { ctx.beginPath(); ctx.arc(x + cw - 6 - q * 6.5, y0 + 22, 2.4, 0, 7); ctx.fillStyle = q < p.am ? '#ffffff' : 'rgba(242,233,216,.15)'; ctx.fill(); }
          if (p && p.out) txt('아웃', x + cw - 5, y0 + 22, '#ee6a55', '700 9px ' + FONT, 'right');
          ctx.restore();
        });
      });
      return ch * 2 + 3 + 2;
    }
    function centerText(t1, sub, col, scale, cy) {
      ctx.save(); ctx.translate(cv.w / 2, cy); ctx.scale(scale, scale);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '50px ' + DISP; ctx.lineWidth = 7; ctx.strokeStyle = 'rgba(16,20,34,.85)'; ctx.lineJoin = 'round'; ctx.strokeText(t1, 0, 0);
      ctx.fillStyle = col; ctx.fillText(t1, 0, 0);
      if (sub) { ctx.font = '700 16px ' + FONT; ctx.lineWidth = 4.5; ctx.strokeText(sub, 0, 40); ctx.fillStyle = '#f2e9d8'; ctx.fillText(sub, 0, 40); }
      ctx.restore();
    }
    function sideName(side) {
      if (side < 0) return '';
      if (st.tm) return TEAM_NM[side] || '';
      return name(side).slice(0, 10);
    }
    function smallBanner(b) {
      ctx.save(); ctx.globalAlpha = Math.min(1, b.life * 3, (b.max - b.life) * 6);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '20px ' + DISP; const w1 = ctx.measureText(b.t).width;
      ctx.font = '700 11px ' + FONT; const w2 = b.sub ? ctx.measureText(b.sub).width : 0;
      const bw = Math.min(cv.w - 16, Math.max(w1, w2) + 28), bh = b.sub ? 46 : 30, y = TOPH + 6;
      ctx.fillStyle = 'rgba(16,20,34,.55)'; ctx.fillRect((cv.w - bw) / 2, y, bw, bh);
      ctx.font = '20px ' + DISP; ctx.fillStyle = b.c; ctx.fillText(b.t, cv.w / 2, y + 15, bw - 12);
      if (b.sub) { ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText(b.sub, cv.w / 2, y + 34, bw - 12); }
      ctx.restore();
    }
    function drawBanners(now) {
      const cy = TOPH + (cv.h - TOPH - lay.bot) * 0.36;
      if (phase === 'count') {
        const n = Math.ceil(cd);
        if (n <= 3) centerText(String(n), st.rd > 1 || !tipT ? st.rd + '라운드 · ' + MAPS[st.mk].nm : null, '#f2e9d8', 1 + (cd % 1) * 0.3, cy);
        else centerText(st.rd + '라운드', MAPS[st.mk].nm, '#bfe3ff', 0.9, cy);
      } else if (phase === 'play' && startT > 0) {
        ctx.save(); ctx.globalAlpha = Math.min(1, startT * 2); centerText('던져!', null, '#e3ae45', 1.1, cy); ctx.restore();
      } else if (phase === 'end' && (st.ph === 'end' || st.ph === 'done')) {
        const rw = st.rw;
        const mine = rw >= 0 && me() >= 0 && seatsOfSide(st, rw).includes(me());
        if (st.ph === 'done') centerText('경기 끝!', null, '#e3ae45', 0.9, cy);
        else centerText(rw >= 0 ? (mine ? '라운드 승리!' : sideName(rw) + ' 승리') : '무승부', st.why === 'time' ? '시간 끝 · 하트가 많은 쪽 승리' : rw >= 0 ? (st.tm ? '' : '마지막까지 버텼어요') : '모두 아웃', rw >= 0 ? sideCol(rw) : '#f2e9d8', mine || rw < 0 ? 0.85 : 0.72, cy);
      }
      if (banner && phase === 'play') smallBanner(banner); // 판을 가리지 않게: 점수판 바로 아래 작게·반투명·1.4초
      if (tipT > 0 && ctrlOn()) {
        const pc = !!window.LOUNGE_DESKTOP || (window.matchMedia && matchMedia('(pointer:fine)').matches);
        const lines = tipFull ? ['처음이라면 이것만!', '왼쪽 엄지: 끌어서 걷기', '「던지기」 누르면 노란 원의 상대 자동 조준', '떼면 휙! · 버튼째 끌면 조준점 옮기기', '「뭉치기」 꾹: 눈덩이 만들기(최대 3개)', '「숙이기」 꾹: 눈벽 뒤에 숨으면 안전'] : ['「던지기」 누르면 조준 · 떼면 휙!'];
        if (pc && tipFull) lines.push('PC: WASD 이동 · 스페이스 던지기 · E 뭉치기 · Q 숙이기');
        ctx.save(); ctx.globalAlpha = Math.min(1, tipT * 2);
        ctx.font = '600 13px ' + FONT;
        let mw = 0; for (const l of lines) mw = Math.max(mw, ctx.measureText(l).width);
        const bw = Math.min(cv.w - 20, mw + 28), bh = lines.length * 21 + 16, bx = (cv.w - bw) / 2, by = Math.min(cv.h - lay.bot - bh - 6, cy + 60);
        rr(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(20,24,40,.9)'; ctx.fill(); ctx.strokeStyle = 'rgba(191,227,255,.55)'; ctx.lineWidth = 1.2; ctx.stroke();
        lines.forEach((l, k) => { ctx.font = '600 13px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = k === 0 ? '#bfe3ff' : '#f2e9d8'; ctx.fillText(l, cv.w / 2, by + 18 + k * 21, bw - 14); });
        ctx.restore();
      }
    }
    function drawFlakes(rdt) {
      if (!flakes.length) for (let i = 0; i < 46; i++) flakes.push({ x: Math.random(), y: Math.random(), r: 0.8 + Math.random() * 1.8, v: 0.03 + Math.random() * 0.05, ph: Math.random() * 6 });
      ctx.fillStyle = 'rgba(255,255,255,.75)';
      for (const f of flakes) {
        f.y += f.v * rdt; f.ph += rdt; if (f.y > 1.02) { f.y = -0.02; f.x = Math.random(); }
        const x = (f.x + Math.sin(f.ph) * 0.01) * cv.w, y = f.y * cv.h;
        ctx.beginPath(); ctx.arc(x, y, f.r, 0, 7); ctx.fill();
      }
    }
    let lastDraw = 0;
    function draw(now) {
      if (!lay || !W || !bgCv) return;
      const rdt = lastDraw ? Math.min(0.05, (now - lastDraw) / 1000) : 0; lastDraw = now;
      cv.clear();
      const bg = ctx.createLinearGradient(0, 0, 0, cv.h); bg.addColorStop(0, '#141a2c'); bg.addColorStop(1, '#1d2238');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, cv.w, cv.h);
      const fxk = L.fx ? L.fx() : 1, sx = shake > 0 ? (Math.random() - 0.5) * shake * 8 * fxk : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 8 * fxk : 0;
      ctx.save(); ctx.translate(sx, sy);
      drawWorld(now);
      ctx.restore();
      drawFlakes(rdt);
      drawHud(now);
      drawStick();
      drawBanners(now);
      for (const c of conf) { ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(c.rot); ctx.globalAlpha = Math.min(1, (c.life - c.t) * 2); ctx.fillStyle = c.c; ctx.fillRect(-4, -2.2, 8, 4.4); ctx.restore(); }
    }

    const stopLoop = U.loop((rdt, now) => {
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); syncBtns(); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    function celebrate(next) {
      const rw = next.rw, m = me();
      if (rw >= 0) {
        const mine = m >= 0 && seatsOfSide(next, rw).includes(m);
        api.sfx(m < 0 || mine ? 'win' : 'lose');
        if (mine) api.buzz(50);
        const col = next.tm ? TEAM_C[rw] : COL(seatsOfSide(next, rw)[0]);
        for (let i = 0; i < 60; i++) conf.push({ x: cv.w * (0.2 + Math.random() * 0.6), y: TOPH + 60, vx: (Math.random() - 0.5) * 380, vy: -100 - Math.random() * 300, rot: Math.random() * 7, vr: (Math.random() - 0.5) * 14, c: [col, '#ffffff', '#bfe3ff'][i % 3], t: 0, life: 1.5 + Math.random() * 0.8 });
      } else api.sfx('tick');
    }

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (curKey() !== key) { startRound(); return; }
        if (prev && prev.ph !== next.ph) {
          if (next.ph === 'play' && phase === 'count') { phase = 'play'; sfx('pop'); startT = 0.9; }
          if (next.ph === 'end') { phase = 'end'; endT = END_T; aim = null; celebrate(next); }
        }
        if (W && next.ph === 'done') phase = 'end';
      },
      destroy() {
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll); window.removeEventListener('lounge-ctl', onCtl);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        for (const k in btn) btn[k].remove();
        styleEl.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, st, lay, flip, aim, locIn, remIn, phase }),
    };
  }

  /* ---------- small drawing helpers ---------- */
  function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(255,255,255,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'snowball', name: '눈싸움 대작전', tag: '실시간 눈싸움', cat: '아케이드',
    blurb: '눈을 뭉쳐 던지고, 눈벽 뒤에 숙여 숨고! 하트 3개를 먼저 다 잃으면 아웃, 마지막까지 남으면 라운드 승리. 2~8명 각자 또는 2:2 · 3:3 · 4:4 팀전(한 폰에 한 명).',
    tint: '#2a5a86',
    icon: '<circle cx="18" cy="20" r="8" fill="currentColor"/><path d="M27 17q9-6 17 2" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="3 3"/><rect x="8" y="38" width="40" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M8 43.5h40M18 38v5.5M28 43.5v5.5M38 38v5.5" stroke="currentColor" stroke-width="2"/><circle cx="44" cy="23" r="3.5" fill="currentColor"/><circle cx="44" cy="31" r="4.5" fill="none" stroke="currentColor" stroke-width="2.5"/>',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'mode', label: '방식', tip: '대결 방식.', choices: [{ v: 'ffa', label: '각자 대결', tip: '모두가 적.' }, { v: 'team', label: '팀전 (2:2 · 3:3 · 4:4)', tip: '두 팀으로 나눠요.' }], def: 'ffa' },
      { id: 'need', label: '이기려면', choices: [{ v: 2, label: '2라운드' }, { v: 3, label: '3라운드' }, { v: 5, label: '5라운드' }], def: 3 },
      { id: 'map', label: '마당', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.nm }))), def: -1 },
      { id: 'items', label: '아이템', tip: '마당에 아이템이 떨어져요.', choices: [{ v: 1, label: '켬' }, { v: 0, label: '끔' }], def: 1 },
    ],
    controls: [
      { id: 'up', label: '위로 걷기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 걷기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 걷기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 걷기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'throw', label: '던지기 (누르면 조준, 떼면 던짐)', keys: ['Space', 'KeyJ'], pad: ['rt', 'a'] },
      { id: 'scoop', label: '뭉치기 (꾹 누르기)', keys: ['KeyE', 'KeyK'], pad: ['x', 'lt'] },
      { id: 'duck', label: '숙이기 (꾹 누르기)', keys: ['KeyQ', 'KeyL'], pad: ['b', 'lb'] },
      { id: 'target', label: '조준할 상대 바꾸기', keys: ['KeyR', 'KeyU'], pad: ['y', 'rb'] },
      { id: 'aimL', label: '조준점 왼쪽', keys: ['Numpad4'], pad: ['rx-'] },
      { id: 'aimR', label: '조준점 오른쪽', keys: ['Numpad6'], pad: ['rx+'] },
      { id: 'aimU', label: '조준점 위', keys: ['Numpad8'], pad: ['ry-'] },
      { id: 'aimD', label: '조준점 아래', keys: ['Numpad5', 'Numpad2'], pad: ['ry+'] },
    ],
    quick: [
      '눈덩이를 던져 상대를 맞히세요! 한 번 맞으면 하트 1개, 3개 다 잃으면 아웃.',
      '「던지기」를 누르면 가까운 상대를 조준, 떼면 던져요. 눈이 없으면 「뭉치기」를 꾹.',
      '마지막까지 남으면 라운드 승리! 먼저 3라운드(설정)를 이기면 우승.',
    ],
    rules: [
      { h: '목표', p: [
        '눈 쌓인 마당에서 하는 눈싸움이에요. 눈덩이로 상대를 맞혀 하트를 빼앗아요.',
        '모두 하트 3개로 시작해요. 맞을 때마다 1개씩 줄고, 0개가 되면 그 라운드는 아웃(눈밭에 누워 구경).',
        '마지막까지 남은 사람(팀)이 라운드 승리. 정해진 라운드 수를 먼저 이기면 우승!',
      ] },
      { h: '조작 (터치)', p: [
        '왼쪽 엄지: 화면 왼쪽을 누르고 끌면 그 방향으로 걸어요(누른 곳이 조이스틱 중심). 조금만 밀어도 바로 움직이고, 링의 80%쯤 밀면 최고 속도예요.',
        '「던지기」: 누르는 순간 가장 가까운 상대(발밑에 노란 점선 원이 보이는 사람)에게 조준점이 잡히고(움직이는 방향도 미리 계산), 손을 떼면 던져요. 누른 채로 버튼을 끌면 조준점을 옮길 수 있어요(「직접 조준」).',
        '방금 던져서 아직 못 던질 때 손을 떼도 괜찮아요. 0.35초 안에 던질 수 있게 되면 그때 자동으로 던져요(버튼 테두리가 점선).',
        '화면 오른쪽(버튼 말고 마당)을 누르면 그 자리를 조준하고, 떼면 그곳으로 던져요.',
        '「뭉치기」: 꾹 누르고 있으면 멈춰 서서 눈을 뭉쳐요. 0.6초에 1개, 최대 3개까지 들고 다녀요. 무너진 눈벽 더미에서는 두 배로 빨라요. 얼음 위에서는 못 뭉쳐요.',
        '「숙이기」: 꾹 누르는 동안 몸을 낮춰요. 천천히만 걸을 수 있고, 던지는 순간에는 잠깐 일어서요.',
        'PC: WASD·방향키 이동, 스페이스·J 던지기(누르고 있으면 조준, 떼면 던짐), E·K 뭉치기, Q·L 숙이기, R·U 조준할 상대 바꾸기. 마우스로 마당을 누르면 그곳을 조준해요. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '눈덩이와 엄폐', p: [
        '눈덩이는 포물선으로 날아가요. 그림자가 땅에 떨어질 곳을 보여 줘요.',
        '서 있는 사람을 노리면 가슴 높이로 날아가서 낮은 눈벽은 넘어가요. 그래서 눈벽 뒤에 서 있으면 맞아요!',
        '눈벽 뒤에서 「숙이기」를 하면 눈덩이가 벽에 막혀요. 대신 벽은 3번 맞으면 와르르 무너져요.',
        '눈사람은 키가 커서 서 있어도 숨을 수 있지만, 역시 3번 맞으면 무너져요. 소나무는 절대 안 무너져요.',
        '맞으면 잠깐 휘청이고 느려지며, 0.85초 동안은 다시 맞지 않아요(깜빡임).',
        '팀전에서는 우리 팀 눈덩이는 우리 편을 그냥 지나가요.',
      ] },
      { h: '아이템 (마당에 떨어지면 먼저 밟는 사람이 가져가요)', p: [
        '큰 눈덩이(파란 공): 큰 눈덩이 2개를 바로 받아요. 벽·눈사람을 한 방에 무너뜨리고, 떨어진 곳 주변 사람도 맞혀요.',
        '연속 던지기(노란 공 3개): 6초 동안 눈덩이가 줄지 않고 아주 빨리 던질 수 있어요.',
        '썰매 대시(빨간 썰매): 3초 동안 썰매를 타고 쌩! 부딪힌 상대는 넘어져요(하트는 그대로).',
        '핫초코(머그잔): 하트 1개 회복. 하트가 가득하면 다음 한 번을 막아 주는 보호막이 생겨요.',
      ] },
      { h: '시간 · 승리', p: [
        '한 라운드는 60초. 시간이 다 되면 남은 하트가 가장 많은 쪽이 이겨요(팀전은 팀 하트 합).',
        '하트가 같으면 「한 방 승부」: 그 사람들만 하트 1개로 25초 더! 그래도 안 끝나면 무승부 라운드.',
        '라운드마다 시작 자리로 돌아가고 벽도 새로 쌓여요. 마당을 「무작위」로 하면 라운드마다 바뀌어요.',
      ] },
      { h: '예시', p: [
        '상대가 눈벽 뒤에 숙여 숨었다면 → 계속 던져서 벽을 무너뜨리거나(3번), 옆으로 돌아가서 던져요.',
        '눈덩이가 0개면 「던지기」를 눌러도 안 나가요 → 벽 뒤로 가서 「뭉치기」를 꾹(숙인 자세라 벽 뒤에선 안전해요).',
        '날아오는 눈덩이가 보이면 옆으로 비켜요. 멀리서 날아오는 공일수록 피하기 쉬워요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지는 AI예요. 친구와는 온라인·LAN 방에서 각자 폰으로(2~8명, 빈자리는 AI).',
        '「팀전」: 4·6·8명이면 2:2 · 3:3 · 4:4로 빨강 팀(1·3·5·7번) 대 파랑 팀(2·4·6·8번). 팀은 마당 양 끝에서 시작해요. 인원이 홀수면 각자 대결이에요.',
        '5명 이상이면 마당이 더 넓어지고 눈벽·눈사람이 더 생겨요.',
        '팀전 AI는 같은 상대를 함께 노리고, 한 명은 벽 뒤에서 버티는 동안 다른 한 명은 옆으로 돌아 들어가요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움 AI는 움직이는 방향을 미리 계산해 던지고, 벽 뒤에 숨고, 공을 잘 피해요.',
        '마당: 앞마당, 얼음 연못(가운데 미끄러운 얼음), 눈 요새, 소나무 숲, 눈더미 언덕(깊은 눈), 미끄럼 골목(양옆 얼음길), 눈사람 공원(눈사람 숲), 무작위(기본).',
        '깊은 눈(점선 테두리의 볼록한 눈더미): 걸음이 느려지지만 그 위에서 뭉치면 두 배로 빨리 만들어져요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { init, newWorld, tickWorld, stepWorld, aiThink, launch, tryThrow, roundOver, nextRound, result, MAPS, AI_DIFF, sideOf, spawns, HW, HH },
  });
})();
