/* 음반 레이블 경영 (v2, 단순화) — 1~4개 레이블이 같은 TOP 10 차트를 두고 겨뤄요.
   한 차례 = 한 분기, 행동 2번(✍️ 계약 · 🎙️ 곡 내기 · 📣 홍보 · 🎤 공연) → 모두 끝나면 이번 분기 TOP 10 →
   4분기 끝엔 시상식. 정해진 해(기본 2년)가 끝나면 점수(차트 점수 + 트로피) 1등. 혼자면 목표 점수. */
(function () {
  const L = window.Lounge;

  /* ---------- 데이터 ---------- */
  const GEN = [
    { n: '발라드', c: '#6f9be6', d: '#1d2c55', i: '🎹' },
    { n: '댄스팝', c: '#ef6aac', d: '#4d1838', i: '💃' },
    { n: '힙합', c: '#e9a23b', d: '#4a300c', i: '🎤' },
    { n: '록', c: '#e2563e', d: '#4a160e', i: '🎸' },
    { n: 'R&B', c: '#a874e0', d: '#33184f', i: '🎷' },
    { n: '일렉트로닉', c: '#34c3cc', d: '#0d3a40', i: '🎛️' },
  ];
  const NG = GEN.length;
  const TR = [
    { k: 'comp', n: '작곡 천재', i: '🎼', d: '곡을 내면 ★+1' },
    { k: 'stage', n: '무대 체질', i: '🎪', d: '공연 수입 2배, 공연해도 안 지침' },
    { k: 'buzz', n: '화제 몰이', i: '📸', d: '홍보하면 곡 힘 ×2 (보통 ×1.5)' },
    { k: 'iron', n: '강철 체력', i: '💪', d: '곡을 내도 안 지침' },
    { k: 'star', n: '스타성', i: '✨', d: 'TOP 10에만 들어도 인기 +1 (보통은 TOP 3)' },
    { k: 'mood', n: '기분파', i: '🎭', d: '신나면 ★+2, 지치면 ★−2 (보통 ±1)' },
  ];
  const TRI = {}; TR.forEach((t, i) => { TRI[t.k] = i; });
  const MOOD = [{ n: '지침', i: '😩', c: '#ef7a62' }, { n: '보통', i: '🙂', c: '#e8c35a' }, { n: '신남', i: '😄', c: '#7ed98a' }];
  const NA = ['새벽', '네온', '유리', '검은', '푸른', '은빛', '하얀', '붉은', '늦은', '먼', '작은', '낡은', '젖은', '깊은', '빈', '조용한', '느린', '밤의', '여름', '겨울', '종이', '모래빛', '두 번째', '잠든'];
  const NN = ['고양이', '파도', '우산', '정류장', '등대', '여우', '라디오', '모래', '숲', '안개', '불꽃', '도시', '거울', '달', '기차', '열쇠', '바람', '심장', '창문', '나비', '고래', '항구', '사막', '전화기'];
  const NS = ['', '', '', ' 밴드', ' 클럽', ' 크루'];
  const TA = ['마지막', '첫', '어젯밤의', '끝없는', '투명한', '뜨거운', '차가운', '낯선', '오래된', '작은', '멀어진', '흔들리는', '눈부신', '조용한', '푸른'];
  const TN = ['여름', '편지', '신호', '계절', '춤', '약속', '고백', '기억', '거리', '불빛', '노래', '파티', '비행', '정원', '파도', '오후', '밤', '꿈'];
  const PTS = [10, 7, 5, 4, 3, 2, 2, 1, 1, 1];   // 순위별 점수
  const PAY = [4, 3, 3, 2, 2, 1, 1, 1, 1, 1];    // 순위별 수입(₩)
  const FRESH = [1, 0.65, 0.4];                  // 곡 나이(분기)별 힘
  const HOT = 1.5, COLD = 0.7;
  const AP = 2, ROSTER = 3, MARKET = 4, AWP = 8, REL_C = 2, PRO_C = 2, START_M = 8;
  const AWN = ['올해의 노래', '올해의 가수', '올해의 레이블'];

  const ICON = '<circle cx="28" cy="28" r="18" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="5" fill="currentColor"/><path d="M28 14a14 14 0 0 1 14 14" fill="none" stroke="currentColor" stroke-width="2" opacity=".6"/><path d="M40 8v14l6-3" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>';

  /* ---------- 도움 ---------- */
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rnd = (n) => (Math.random() * n) | 0;
  const pick = (a) => a[rnd(a.length)];
  function hash(n) { n = (n ^ 61) ^ (n >>> 16); n = (n + (n << 3)) | 0; n ^= n >>> 4; n = Math.imul(n, 0x27d4eb2d); n ^= n >>> 15; return (n >>> 0) / 4294967296; }
  const has = (m, k) => !!m && m.tr === TRI[k];
  const muOf = (s, id) => s.mu.find((m) => m.id === id) || null;
  const rosterOf = (s, i) => s.mu.filter((m) => m.lb === i);
  const marketOf = (s) => s.mk.map((id) => muOf(s, id)).filter(Boolean);
  const score = (s, i) => s.L[i].cp + s.L[i].aw * AWP;
  const TOTQ = (s) => s.Y * 4;
  function wpick(ws) { let t = 0; ws.forEach((w) => { t += w; }); let r = Math.random() * t; for (let k = 0; k < ws.length; k++) { r -= ws[k]; if (r < 0) return k; } return ws.length - 1; }
  function stageName(s) {
    for (let k = 0; k < 30; k++) {
      const nm = pick(NA) + ' ' + pick(NN) + pick(NS);
      if (!s.used.includes(nm)) { s.used.push(nm); if (s.used.length > 60) s.used.shift(); return nm; }
    }
    return pick(NA) + ' ' + pick(NN) + ' ' + (s.nid % 90 + 10);
  }
  function songTitle(s) { let t = ''; for (let k = 0; k < 20; k++) { t = pick(TA) + ' ' + pick(TN); if (!s.so.some((x) => x.tt === t)) break; } return t; }
  function newMusician(s) {
    const tal = 1 + wpick([14, 30, 30, 18, 8]);
    const fame = wpick([40, 32, 20, 8]);
    return { id: s.nid++, nm: stageName(s), g: rnd(NG), tal, fame, mood: 1 + (Math.random() < 0.35 ? 1 : 0), tr: rnd(TR.length), lb: -1, act: -1, yp: 0 };
  }
  function signCost(m) { return 1 + m.tal * 2 + m.fame + (has(m, 'comp') ? 1 : 0); }
  function trendM(s, g) { return s.hot.includes(g) ? HOT : s.cold === g ? COLD : 1; }
  function relStars(m) {
    const b = has(m, 'mood') ? 2 : 1;
    return clamp(m.tal + (has(m, 'comp') ? 1 : 0) + (m.mood === 2 ? b : m.mood === 0 ? -b : 0), 1, 8);
  }
  function gigPay(m) { let v = (2 + m.fame) * (has(m, 'stage') ? 2 : 1); if (m.mood === 0) v = Math.ceil(v / 2); return v; }
  const promoM = (s, so) => (has(muOf(s, so.m), 'buzz') ? 2 : HOT);
  // 곡의 힘(잡음 없음). tq = 차트를 매기는 분기
  function power(s, so, tq, trendless) {
    const age = tq - so.t;
    if (age < 0 || age > 2) return 0;
    const m = so.lb >= 0 ? muOf(s, so.m) : null;
    const fame = m ? m.fame : so.fa;
    return so.st * (1 + 0.25 * fame) * (trendless ? 1 : trendM(s, so.g)) * (so.pr === tq ? promoM(s, so) : 1) * FRESH[age];
  }
  const elig = (s) => s.so.filter((x) => s.t - x.t >= 0 && s.t - x.t <= 2);
  function rankAmong(list, p) { let r = 1; for (const v of list) if (v > p) r++; return r; }
  // 화면·봇 공용 미리보기: 지금 곡을 내면(또는 홍보하면) 이번 분기 몇 위쯤인지
  function previewRel(s, i, m) {
    const so = { st: relStars(m), g: m.g, t: s.t, lb: i, m: m.id, pr: -1, fa: 0 };
    const p = power(s, so, s.t);
    return { st: so.st, rank: rankAmong(elig(s).map((x) => power(s, x, s.t)), p) };
  }
  function previewPromo(s, so) {
    const others = elig(s).filter((x) => x.id !== so.id).map((x) => power(s, x, s.t));
    const p0 = power(s, so, s.t), p1 = power(s, Object.assign({}, so, { pr: s.t }), s.t);
    return { from: rankAmong(others, p0), to: rankAmong(others, p1) };
  }

  /* ---------- 시작 ---------- */
  function bgSongs(s, k) {
    for (let j = 0; j < k; j++) {
      s.so.push({ id: s.nid++, tt: songTitle(s), mn: stageName(s), m: -1, lb: -1, g: rnd(NG), st: 2 + wpick([30, 36, 24, 10]), fa: wpick([20, 30, 28, 15, 7]), t: s.t, pr: Math.random() < 0.3 ? s.t : -1, yp: 0, bs: 99 });
    }
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const Y = clamp(+opts.years || 2, 1, 4);
    const s = {
      n, Y, t: 0, yr: 1, q: 1, ord: players.map((_, i) => i), oi: 0, cur: 0, ph: 'turn',
      L: players.map(() => ({ cp: 0, aw: 0, m: START_M, ap: AP, yp: 0 })),
      mu: [], mk: [], so: [], chart: [], hot: [], cold: 0, nid: 1, used: [], lid: 0, last: null, sum: null,
      seed: (Math.random() * 1e9) | 0, goal: n === 1 ? [0, 32, 100, 170][Y] : 0,
    };
    const gs = [0, 1, 2, 3, 4, 5].sort(() => Math.random() - 0.5);
    s.hot = [gs[0], gs[1]]; s.cold = gs[2];
    for (let i = 0; i < n; i++) {
      const m = newMusician(s); m.tal = 2; m.fame = 1; m.mood = 1; m.lb = i; s.mu.push(m);
    }
    for (let k = 0; k < MARKET; k++) { const m = newMusician(s); s.mu.push(m); s.mk.push(m.id); }
    bgSongs(s, 4);
    s.cur = s.ord[0];
    return s;
  }
  function actor(s) { return s.ph === 'over' ? null : s.cur; }

  /* ---------- 행동 ---------- */
  function legal(s, i, a) {
    const l = s.L[i];
    if (!a || typeof a !== 'object') return '잘못된 행동';
    if (a.t === 'end') return null;
    if (l.ap <= 0) return '행동을 다 썼어요';
    if (a.t === 'sign') {
      const m = muOf(s, a.m);
      if (!m || m.lb !== -1 || !s.mk.includes(m.id)) return '없는 음악가';
      if (rosterOf(s, i).length >= ROSTER) return '소속이 꽉 찼어요(최대 ' + ROSTER + '명)';
      return l.m >= signCost(m) ? null : '돈이 모자라요';
    }
    if (a.t === 'rel' || a.t === 'gig') {
      const m = muOf(s, a.m);
      if (!m || m.lb !== i) return '없는 음악가';
      if (m.act === s.t) return '이번 분기에 이미 활동했어요';
      if (a.t === 'rel' && l.m < REL_C) return '돈이 모자라요';
      return null;
    }
    if (a.t === 'promo') {
      const so = s.so.find((x) => x.id === a.r);
      if (!so || so.lb !== i) return '없는 곡';
      const age = s.t - so.t;
      if (age < 0 || age > 2) return '차트에서 내려간 곡';
      if (so.pr === s.t) return '이번 분기에 이미 홍보했어요';
      return l.m >= PRO_C ? null : '돈이 모자라요';
    }
    return '모르는 행동';
  }
  function doAct(s, i, a) {
    const l = s.L[i];
    if (a.t === 'end') return null;
    l.ap--;
    if (a.t === 'sign') {
      const m = muOf(s, a.m), c = signCost(m);
      l.m -= c; m.lb = i; m.act = -1;
      s.mk = s.mk.filter((x) => x !== m.id);
      const nm = newMusician(s); s.mu.push(nm); s.mk.push(nm.id);
      return { k: 'sign', m: m.id, x: m.nm + ' 계약 (₩' + c + ')' };
    }
    if (a.t === 'rel') {
      const m = muOf(s, a.m);
      l.m -= REL_C; m.act = s.t;
      const so = { id: s.nid++, tt: songTitle(s), mn: m.nm, m: m.id, lb: i, g: m.g, st: relStars(m), fa: 0, t: s.t, pr: -1, yp: 0, bs: 99 };
      s.so.push(so);
      if (!has(m, 'iron')) m.mood = Math.max(0, m.mood - 1);
      return { k: 'rel', m: m.id, r: so.id, x: '「' + so.tt + '」 발매 ' + '★'.repeat(so.st) };
    }
    if (a.t === 'gig') {
      const m = muOf(s, a.m), v = gigPay(m);
      l.m += v; m.act = s.t;
      if (!has(m, 'stage')) m.mood = Math.max(0, m.mood - 1);
      return { k: 'gig', m: m.id, x: m.nm + ' 공연 +₩' + v };
    }
    if (a.t === 'promo') {
      const so = s.so.find((x) => x.id === a.r);
      l.m -= PRO_C; so.pr = s.t;
      return { k: 'promo', r: so.id, x: '「' + so.tt + '」 홍보 📣' };
    }
    return null;
  }
  function apply(s, seat, a) {
    if (s.ph === 'over') throw new Error('over');
    if (seat !== s.cur) throw new Error('not your turn');
    const err = legal(s, seat, a);
    if (err) throw new Error(err);
    const ev = doAct(s, seat, a);
    if (ev) s.last = Object.assign({ id: ++s.lid, i: seat }, ev);
    if (a.t === 'end' || s.L[seat].ap <= 0) { nextLabel(s); if (ev && s.last.k === 'q') s.last.pa = Object.assign({ i: seat }, ev); }
    return s;
  }
  function nextLabel(s) {
    s.oi++;
    if (s.oi >= s.ord.length) { quarterEnd(s); return; }
    s.cur = s.ord[s.oi];
  }

  /* ---------- 분기 마감 ---------- */
  function quarterEnd(s) {
    const prevRank = {}; s.chart.forEach((c, k) => { prevRank[c.id] = k + 1; });
    const sc = elig(s).map((so) => ({ so, v: power(s, so, s.t) * (0.85 + Math.random() * 0.3) })).sort((a, b) => b.v - a.v);
    const gain = s.L.map(() => ({ p: 0, m: 0 }));
    s.chart = sc.slice(0, 10).map((x, k) => {
      const so = x.so;
      so.yp += PTS[k]; so.bs = Math.min(so.bs, k + 1);
      if (so.lb >= 0) {
        const l = s.L[so.lb]; l.cp += PTS[k]; l.yp += PTS[k]; l.m += PAY[k];
        gain[so.lb].p += PTS[k]; gain[so.lb].m += PAY[k];
        const m = muOf(s, so.m);
        if (m) { m.yp += PTS[k]; if (k < 3 || has(m, 'star')) m.fame = Math.min(5, m.fame + 1); }
      }
      return { id: so.id, tt: so.tt, mn: so.mn, lb: so.lb, g: so.g, st: so.st, pr: prevRank[so.id] || 0, d: PTS[k], ag: s.t - so.t };
    });
    // 쉬었으면 기분 회복
    for (const m of s.mu) if (m.lb >= 0 && m.act !== s.t) m.mood = Math.min(2, m.mood + 1);
    const sum = { yr: s.yr, q: s.q, g: gain, ev: null, aw: null, hot: null, cold: 0 };
    if (s.q === 4) sum.aw = awards(s);
    // 소식(가끔): 바이럴 또는 스캔들
    const pool = s.mu.filter((m) => m.lb >= 0);
    if (pool.length && Math.random() < 0.5) {
      const m = pick(pool);
      if (Math.random() < 0.6 || m.fame === 0) { m.fame = Math.min(5, m.fame + 1); sum.ev = { k: 'viral', i: m.lb, m: m.id, x: m.nm + ' 영상이 퍼졌어요! 인기 ♥+1' }; }
      else { m.fame = Math.max(0, m.fame - 1); m.mood = 0; sum.ev = { k: 'scandal', i: m.lb, m: m.id, x: m.nm + ' 구설수… 인기 ♥−1, 지침' }; }
    }
    // 유행: 뜨는 장르 하나가 바뀌고, 식은 장르도 새로
    const out = rnd(2), cand = [];
    for (let g = 0; g < NG; g++) if (!s.hot.includes(g)) cand.push(g);
    const ng = pick(cand); s.hot = s.hot.slice(); s.hot[out] = ng;
    const cc = []; for (let g = 0; g < NG; g++) if (!s.hot.includes(g)) cc.push(g);
    s.cold = pick(cc);
    sum.hot = s.hot.slice(); sum.cold = s.cold; sum.newHot = ng;
    s.sum = sum;
    s.last = { id: ++s.lid, k: 'q', yr: s.yr, q: s.q, aw: !!sum.aw };
    // 다음 분기
    s.t++;
    if (s.t >= TOTQ(s)) { s.ph = 'over'; return; }
    s.q = (s.t % 4) + 1; s.yr = Math.floor(s.t / 4) + 1;
    if (s.q === 1) { s.L.forEach((l) => { l.yp = 0; }); s.mu.forEach((m) => { m.yp = 0; }); s.so = s.so.filter((x) => s.t - x.t <= 2); s.so.forEach((x) => { x.yp = 0; }); }
    // 시장: 가장 오래된 한 명이 떠나고 새 얼굴
    const old = s.mk.shift(); s.mu = s.mu.filter((m) => m.id !== old);
    const nm = newMusician(s); s.mu.push(nm); s.mk.push(nm.id);
    bgSongs(s, 4);
    s.L.forEach((l) => { l.ap = AP; });
    const st0 = s.t % s.n;
    s.ord = s.ord.map((_, k) => (k + st0) % s.n);
    s.oi = 0; s.cur = s.ord[0];
  }
  function awards(s) {
    const songs = s.so.filter((x) => x.yp > 0).sort((a, b) => b.yp - a.yp || a.bs - b.bs);
    const by = {};
    s.so.forEach((x) => { if (x.yp > 0) { const k = x.lb >= 0 ? 'm' + x.m : 'b' + x.mn; by[k] = by[k] || { mn: x.mn, lb: x.lb, v: 0 }; by[k].v += x.yp; } });
    const singer = Object.values(by).sort((a, b) => b.v - a.v)[0] || null;
    const ly = s.L.map((l) => l.yp), best = Math.max(...ly);
    const A = [
      songs[0] ? { tt: songs[0].tt, mn: songs[0].mn, lb: songs[0].lb, v: songs[0].yp } : null,
      singer ? { tt: '', mn: singer.mn, lb: singer.lb, v: singer.v } : null,
      best > 0 ? { tt: '', mn: '', lb: ly.indexOf(best), v: best } : null,
    ];
    A.forEach((w) => { if (w && w.lb >= 0) s.L[w.lb].aw++; });
    return A;
  }

  function result(s) {
    if (s.ph !== 'over') return null;
    const sc = s.L.map((_, i) => score(s, i));
    const stats = [
      { label: '점수', values: sc },
      { label: '차트 점수', values: s.L.map((l) => l.cp) },
      { label: '트로피', values: s.L.map((l) => '🏆' + l.aw) },
      { label: '남은 돈', values: s.L.map((l) => '₩' + l.m) },
    ];
    const hl = [];
    if (s.chart[0]) hl.push('마지막 1위: 「' + s.chart[0].tt + '」 ' + s.chart[0].mn);
    if (s.n === 1) {
      const ok = sc[0] >= s.goal;
      hl.unshift('목표 ' + s.goal + '점 — ' + (ok ? '달성!' : '아쉽게 못 미쳤어요'));
      return { winners: ok ? [0] : [], title: ok ? '명가 레이블 달성' : '목표 미달', text: '점수 ' + sc[0] + ' / 목표 ' + s.goal, stats, highlights: hl };
    }
    const best = Math.max(...sc);
    return { winners: sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0), text: '레이블 점수 ' + best + '점', stats, highlights: hl };
  }

  /* ---------- AI ---------- */
  // 버릇: 판마다 시드로 정해지는 성향(고정 규칙 아님 — 점수에 섞여 들어감)
  function habit(s, i) {
    const r = (k) => hash(s.seed * 13 + i * 97 + k * 11);
    return { fav: (r(1) * NG) | 0, promo: 0.75 + r(2) * 0.6, gig: 0.7 + r(3) * 0.7, size: r(4) < 0.45 ? 2 : 3, thrift: 0.75 + r(5) * 0.5, star: 0.8 + r(6) * 0.5, wait: r(7) };
  }
  function styleOf(seat) { return (L.aiStyle && L.aiStyle(seat)) || 'bal'; }
  // ₩1의 값(점수 단위): 남은 분기가 적을수록 돈은 쓸모가 줄어요
  function moneyVal(s, lv, hb) {
    const left = TOTQ(s) - s.t;
    if (lv === 1) return 0.6;
    if (lv === 2) return 0.7 * hb.thrift * (TOTQ(s) - s.t > 1 ? 1 : 0.4);
    const v = left >= 4 ? 0.9 : left === 3 ? 0.75 : left === 2 ? 0.5 : 0.08;
    return v * hb.thrift;
  }
  const ptsAt = (r) => (r <= 10 ? PTS[r - 1] : 0);
  const payAt = (r) => (r <= 10 ? PAY[r - 1] : 0);
  // 곡 하나가 앞으로 벌어 줄 점수 어림(이번 분기 + lv≥2는 다음 분기들까지)
  function songWorth(s, comp, p0, lv, mv) {
    let v = 0;
    const qs = Math.min(lv, TOTQ(s) - s.t);
    for (let a = 0; a < qs; a++) {
      const r = rankAmong(comp, p0 * FRESH[a] * (a ? 0.92 : 1));
      v += (ptsAt(r) + payAt(r) * mv) * (a ? 0.85 : 1);
    }
    return v;
  }
  function cands(s, i) {
    const out = [{ t: 'end' }];
    const ok = (a) => !legal(s, i, a);
    for (const m of marketOf(s)) { const a = { t: 'sign', m: m.id }; if (ok(a)) out.push(a); }
    for (const m of rosterOf(s, i)) for (const t of ['rel', 'gig']) { const a = { t, m: m.id }; if (ok(a)) out.push(a); }
    for (const so of elig(s)) if (so.lb === i) { const a = { t: 'promo', r: so.id }; if (ok(a)) out.push(a); }
    return out;
  }
  function aiValue(s, i, a, lv, hb, comp, sty) {
    const l = s.L[i], mv = moneyVal(s, lv, hb), left = TOTQ(s) - s.t;
    const tl = lv === 1; // 쉬움은 유행을 잘 못 읽어요
    if (a.t === 'end') return 0;
    if (a.t === 'rel') {
      const m = muOf(s, a.m);
      const so = { st: relStars(m), g: m.g, t: s.t, lb: i, m: m.id, pr: -1, fa: 0 };
      let v = songWorth(s, comp, power(s, so, s.t, tl), lv, mv) - REL_C * mv;
      if (lv >= 2) {
        // 지금 지치게 하면 다음 곡이 약해짐 / 보통 기분이면 쉬었다가 신나서 내는 것도 생각
        if (m.mood === 1 && !has(m, 'iron') && left > 2) v -= 1.2 * hb.wait;
        if (m.mood === 0 && left > 1) v -= 2;
      }
      if (lv >= 3) { const rk = rankAmong(comp, power(s, so, s.t)); if (rk <= 3 && m.fame < 5 && left > 1) v += 1.5; if (s.q === 4 && rk === 1) v += 3; } // 인기 오름·올해의 노래 노리기
      if (m.g === hb.fav) v += 0.6;
      if (sty === 'gamble' && so.st >= 4) v += 1;
      return v;
    }
    if (a.t === 'promo') {
      const so = s.so.find((x) => x.id === a.r);
      const others = elig(s).filter((x) => x.id !== so.id).map((x) => power(s, x, s.t, tl));
      const r0 = rankAmong(others, power(s, so, s.t, tl)), r1 = rankAmong(others, power(s, Object.assign({}, so, { pr: s.t }), s.t, tl));
      let v = (ptsAt(r1) - ptsAt(r0)) + (payAt(r1) - payAt(r0)) * mv;
      if (r1 <= 3 && lv >= 3) { const m = muOf(s, so.m); if (m && m.fame < 5 && r0 > 3) v += 1.5 * (left > 1 ? 1 : 0.2); } // 인기 오름
      if (lv >= 3 && s.q === 4 && r1 === 1) v += 2;
      return v * hb.promo - PRO_C * mv + (sty === 'agg' ? 0.5 : 0);
    }
    if (a.t === 'gig') {
      const m = muOf(s, a.m);
      let v = gigPay(m) * mv * hb.gig;
      if (lv >= 2 && !has(m, 'stage')) v -= (m.mood <= 1 ? 1.5 : 0.6) * (left > 1 ? 1 : 0);
      if (l.m < REL_C + PRO_C) v += 1.5;
      return v + (sty === 'def' ? 0.4 : 0);
    }
    if (a.t === 'sign') {
      const m = muOf(s, a.m), ro = rosterOf(s, i).length, cost = signCost(m);
      if (left <= 1) return -5;
      const so = { st: m.tal + (has(m, 'comp') ? 1 : 0), g: m.g, t: s.t, lb: i, m: m.id, pr: -1, fa: 0 };
      // 한 명이 남은 분기 동안 대략 2분기에 곡 하나쯤 → 그 값의 일부
      const per = songWorth(s, comp, power(s, so, s.t, tl), Math.max(lv, 2), mv) - REL_C * mv;
      let v = per * (left - 1) * 0.42 * hb.star - cost * mv * (lv === 1 ? 0.6 : 1);
      if (ro >= hb.size) v -= 4;
      if (ro === 0) v += 6;
      if (l.m - cost < REL_C) v -= 3;
      if (m.g === hb.fav) v += 0.8;
      return v;
    }
    return 0;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const hb = habit(s, seat), sty = styleOf(seat);
    const cs = cands(s, seat);
    if (lv === 1 && Math.random() < 0.2) return cs[1 + rnd(cs.length - 1)] || cs[0];
    const comp = elig(s).map((x) => power(s, x, s.t, lv === 1));
    const noise = lv === 1 ? 4 : lv === 2 ? 1.2 : 0.25;
    // 어려움: 남은 행동 2번을 한 묶음으로 봐요(곡 내기 → 그 곡 홍보 같은 조합)
    const two = lv >= 3 && s.L[seat].ap >= 2;
    let best = cs[0], bv = -1e9;
    for (const a of cs) {
      let v = aiValue(s, seat, a, lv, hb, comp, sty);
      if (two && a.t !== 'end') {
        const s2 = JSON.parse(JSON.stringify(s));
        doAct(s2, seat, a);
        const comp2 = elig(s2).map((x) => power(s2, x, s2.t));
        let b2 = 0;
        for (const b of cands(s2, seat)) b2 = Math.max(b2, aiValue(s2, seat, b, lv, hb, comp2, sty));
        v += b2;
      }
      v += (Math.random() - 0.5) * 2 * noise;
      if (v > bv) { bv = v; best = a; }
    }
    return best;
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 900 : 700; }

  function hint(s, seat) {
    if (s.ph === 'over' || seat < 0) return null;
    return [s.cur === seat ? '내 차례: 행동 ' + s.L[seat].ap + '번 남음' : '다른 레이블 차례예요',
      '점수 ' + score(s, seat) + ' (차트 ' + s.L[seat].cp + ' + 트로피 ' + s.L[seat].aw + '개)',
      '유행 🔥 ' + s.hot.map((g) => GEN[g].n).join(' · ') + ' / ❄️ ' + GEN[s.cold].n];
  }

  /* ---------- 화면 ---------- */
  const CSS = `
.lb,.lb-ov{--gold:#f2c14e;--dim:#b5a6c8}
.lb{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 70% at 50% -10%,#3a2450 0%,#1b1326 55%,#110c19 100%);color:#f6eefc;font-family:var(--f-body);overflow:hidden}
.lb *{box-sizing:border-box}
.lb-hd{flex:none;padding:8px 56px 4px 10px;display:flex;flex-direction:column;gap:6px}
.lb-qt{display:flex;align-items:center;gap:8px;min-height:30px}
.lb-qt b{font-family:var(--f-display);font-weight:400;font-size:21px;color:var(--gold);white-space:nowrap}
.lb-pips{display:flex;gap:3px;flex:1;min-width:0}
.lb-pips i{flex:1;max-width:18px;height:7px;border-radius:4px;background:#ffffff1c}
.lb-pips i.d{background:#f2c14e88}.lb-pips i.c{background:var(--gold);box-shadow:0 0 6px #f2c14e}.lb-pips i.y{margin-right:4px}
.lb-sb{display:flex;gap:5px}
.lb-lab{flex:1;min-width:0;border-radius:11px;background:#00000040;border:1px solid #ffffff18;padding:4px 7px 4px 9px;position:relative;overflow:hidden;min-height:44px;display:flex;flex-direction:column;justify-content:center}
.lb-lab:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--c)}
.lb-lab.cur{border-color:var(--c);box-shadow:0 0 0 1px var(--c) inset,0 0 12px color-mix(in srgb,var(--c) 45%,transparent)}
.lb-lab .n{font-size:12.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#e9def5}
.lb-lab .v{font-size:14px;font-weight:800;white-space:nowrap;display:flex;gap:6px}
.lb-lab .v span{color:var(--dim);font-weight:600}
.lb-todo{flex:none;margin:2px 8px 0;border-radius:12px;padding:8px 12px;font-size:15px;font-weight:700;display:flex;align-items:center;gap:8px;min-height:44px;background:#ffffff0d;color:#e6dcf2}
.lb-todo.me{background:linear-gradient(90deg,#f2c14e2e,#f2c14e10);color:#ffe7a8;box-shadow:0 0 0 1px #f2c14e66 inset}
.lb-todo .tw{min-width:0;display:flex;flex-direction:column;line-height:1.25}.lb-todo .tw small{font-size:13px;font-weight:600;color:#d8cce8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lb-todo .ap{display:flex;gap:4px;margin-left:auto;flex:none}
.lb-todo .ap i{width:14px;height:14px;border-radius:50%;background:var(--gold);box-shadow:0 0 6px #f2c14e}
.lb-todo .ap i.u{background:#ffffff22;box-shadow:none}
.lb-dots{display:inline-flex;gap:3px}.lb-dots i{width:6px;height:6px;border-radius:50%;background:#e6dcf2;animation:lbd 1s infinite}.lb-dots i:nth-child(2){animation-delay:.2s}.lb-dots i:nth-child(3){animation-delay:.4s}
@keyframes lbd{0%,100%{opacity:.25}50%{opacity:1}}
.lb-trend{flex:none;display:flex;gap:6px;padding:6px 8px 2px;align-items:center;overflow:hidden}
.lb-trend .lbl{font-size:12.5px;color:var(--dim);font-weight:700;flex:none}
.lb-gt{display:inline-flex;align-items:center;gap:3px;border-radius:999px;padding:3px 9px 3px 6px;font-size:13.5px;font-weight:800;white-space:nowrap;color:#fff;background:var(--gc);flex:none}
.lb-gt.cold{background:#3a4a62;color:#cfe3ff}
.lb-main{flex:1;min-height:0;overflow-y:auto;padding:6px 8px 10px;display:flex;flex-direction:column;gap:8px;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
.lb-main>*{flex:none}
.lb-sec{display:flex;align-items:baseline;justify-content:space-between;gap:8px;margin:6px 4px 0;font-size:15px;font-weight:800;color:#efe4fb}
.lb-sec small{font-size:12.5px;color:var(--dim);font-weight:600;text-align:right}
.lb-mc{position:relative;border-radius:16px;padding:10px;background:linear-gradient(150deg,color-mix(in srgb,var(--gc) 26%,#241a33) 0%,#1f1730 70%);border:1px solid color-mix(in srgb,var(--gc) 45%,#ffffff10);display:flex;flex-direction:column;gap:8px}
.lb-mc .top{display:flex;gap:10px;align-items:center;min-width:0}
.lb-av{flex:none;position:relative;line-height:0}
.lb-av .gi{position:absolute;right:-3px;bottom:-3px;width:24px;height:24px;border-radius:50%;background:#1b1326;border:2px solid var(--gc);display:flex;align-items:center;justify-content:center;font-size:13px;line-height:1}
.lb-mc .inf{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.lb-mc .nm{font-size:17.5px;font-weight:800;line-height:1.2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lb-mc .ln{display:flex;gap:6px;align-items:center;flex-wrap:wrap;font-size:13px}
.lb-st{color:var(--gold);font-size:17px;letter-spacing:1px;line-height:1}
.lb-st .e{color:#ffffff26}
.lb-ht{color:#ff6fa5;font-size:14px;letter-spacing:1px;line-height:1}
.lb-ht .e{color:#ffffff26}
.lb-chip{display:inline-flex;align-items:center;gap:3px;border-radius:8px;padding:2px 7px;font-size:12.5px;font-weight:700;white-space:nowrap;background:#00000040;border:1px solid #ffffff22;color:#efe4fb}
.lb-chip.g{background:var(--gc);border-color:transparent;color:#fff}
.lb-chip.hot{box-shadow:0 0 0 2px #ffb03a inset}
.lb-mood{font-size:13px;font-weight:800}
.lb-acts{display:grid;grid-template-columns:1.35fr 1fr;gap:6px}
.lb-b{min-height:54px;border-radius:12px;border:1px solid #ffffff26;background:#ffffff12;color:#f6eefc;font:inherit;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;padding:4px 6px;text-align:center;touch-action:manipulation;transition:transform .08s}
.lb-b:active:not(:disabled){transform:scale(.97)}
.lb-b b{font-size:15.5px;font-weight:800;white-space:nowrap}
.lb-b span{font-size:12.5px;color:#e6dcf2;white-space:nowrap}
.lb-b.pri{background:linear-gradient(180deg,#f6cd61,#e0a93a);color:#2a1a05;border-color:#ffd97a}
.lb-b.pri span{color:#4a3208;font-weight:700}
.lb-b:disabled{opacity:.38;cursor:default}
.lb-done{display:flex;align-items:center;justify-content:center;gap:6px;min-height:46px;border-radius:12px;background:#00000033;color:var(--dim);font-size:14px;font-weight:700;grid-column:1/-1}
.lb-empty{border-radius:14px;border:1.5px dashed #ffffff2a;padding:14px;text-align:center;color:var(--dim);font-size:14px}
.lb-song{display:grid;grid-template-columns:8px 1fr auto;gap:8px;align-items:center;border-radius:13px;background:#ffffff0c;border:1px solid #ffffff16;padding:7px 8px 7px 0;overflow:hidden}
.lb-song .gb{align-self:stretch;background:var(--gc);border-radius:0 4px 4px 0}
.lb-song .tx{min-width:0;display:flex;flex-direction:column;gap:2px}
.lb-song .tt{font-size:15px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lb-song .sub{font-size:12.5px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lb-song .lb-b{min-width:112px;min-height:50px}
.lb-age{display:inline-flex;gap:2px;vertical-align:middle}.lb-age i{width:10px;height:5px;border-radius:2px;background:#7ed98a}.lb-age i.u{background:#ffffff22}
.lb-mk{display:grid;grid-template-columns:1fr 1fr;gap:7px}
.lb-mk .lb-mc{padding:8px;gap:6px}
.lb-mk .top{flex-direction:column;align-items:flex-start;gap:6px}
.lb-mk .avr{display:flex;gap:8px;align-items:center;width:100%;min-width:0}
.lb-mk .nm{font-size:15px;white-space:normal;line-height:1.2;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.lb-mk .lb-b{min-height:48px}
.lb-ch{border-radius:14px;background:#00000033;border:1px solid #ffffff14;padding:4px}
.lb-cr{display:grid;grid-template-columns:30px 34px 1fr auto;gap:6px;align-items:center;min-height:40px;padding:2px 6px;border-radius:9px}
.lb-cr+.lb-cr{border-top:1px solid #ffffff0d}
.lb-cr.mine{background:color-mix(in srgb,var(--c) 26%,transparent);border-top-color:transparent}
.lb-cr .rk{font-family:var(--f-display);font-size:20px;text-align:center;color:#efe4fb}
.lb-cr .rk.t1{color:var(--gold)}
.lb-cr .mv{font-size:12px;font-weight:800;text-align:center}
.lb-cr .mv.up{color:#7ed98a}.lb-cr .mv.dn{color:#ef7a62}.lb-cr .mv.nw{color:#ff8fc0}.lb-cr .mv.eq{color:#ffffff55}
.lb-cr .tx{min-width:0;display:flex;flex-direction:column}
.lb-cr .tt{font-size:14px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lb-cr .sub{font-size:12px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lb-cr .who{font-size:12.5px;font-weight:800;white-space:nowrap;text-align:right;max-width:90px;overflow:hidden;text-overflow:ellipsis}
.lb-cr .pt{font-size:12px;color:var(--gold);display:block;text-align:right}
.lb-bot{flex:none;display:flex;gap:8px;padding:6px 8px calc(8px + env(safe-area-inset-bottom,0px));align-items:center;border-top:1px solid #ffffff10;background:#0000002e}
.lb-bot .msg{flex:1;min-width:0;font-size:13.5px;color:var(--dim);line-height:1.3}
.lb-bot .btn{min-height:52px;min-width:136px;font-size:16px}
.lb-flash{animation:lbf .9s ease-out}
@keyframes lbf{0%{box-shadow:0 0 0 3px #f2c14e,0 0 24px #f2c14e}100%{box-shadow:0 0 0 0 transparent}}
.lb-ov{position:absolute;inset:0;z-index:9;background:#07040bcc;display:flex;align-items:center;justify-content:center;padding:62px 10px 10px;animation:lbo .25s ease-out;color:#f6eefc;font-family:var(--f-body)}
@keyframes lbo{from{opacity:0}to{opacity:1}}
.lb-card{width:100%;max-width:430px;max-height:100%;border-radius:20px;background:linear-gradient(170deg,#2c1f40,#1b1328);border:1px solid #ffffff22;box-shadow:0 10px 40px #000a;display:flex;flex-direction:column;overflow:hidden}
.lb-card h3{margin:0;padding:12px 14px 2px;font-family:var(--f-display);font-weight:400;font-size:23px;color:var(--gold);text-align:center}
.lb-card .csub{text-align:center;font-size:13.5px;color:var(--dim);padding:0 12px 6px}
.lb-cb{flex:1;min-height:0;overflow-y:auto;padding:4px 10px 6px;display:flex;flex-direction:column;gap:8px}
.lb-cf{flex:none;padding:8px 10px 12px;display:flex;gap:8px;align-items:center}
.lb-cf .btn{flex:1;min-height:52px;font-size:17px}
.lb-steps{display:flex;gap:5px;justify-content:center;padding:0 0 2px}.lb-steps i{width:8px;height:8px;border-radius:50%;background:#ffffff2a}.lb-steps i.on{background:var(--gold)}
.lb-gain{display:flex;gap:6px}
.lb-gain>div{flex:1;min-width:0;border-radius:12px;background:#00000040;padding:6px 4px;text-align:center;border-top:3px solid var(--c)}
.lb-gain .n{font-size:12px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lb-gain .p{font-size:18px;font-weight:900;color:var(--gold)}
.lb-gain .m{font-size:12.5px;color:#9fe3a8;font-weight:700}
.lb-anim{position:relative}
.lb-anim .lb-cr{position:absolute;left:0;right:0;transition:transform .8s cubic-bezier(.2,.8,.2,1),opacity .6s}
.lb-news{border-radius:14px;padding:12px;background:#00000038;border:1px solid #ffffff1a;display:flex;gap:12px;align-items:center;font-size:15px;font-weight:700;line-height:1.35}
.lb-news .ic{font-size:34px;flex:none;line-height:1}
.lb-aw{border-radius:16px;padding:10px 12px;background:linear-gradient(135deg,#4a3614,#2a1e33);border:1px solid #f2c14e66;display:flex;gap:12px;align-items:center;opacity:0;transform:translateY(12px) scale(.96);animation:lba .5s ease-out forwards}
@keyframes lba{to{opacity:1;transform:none}}
.lb-aw .k{font-size:13px;color:var(--gold);font-weight:800}
.lb-aw .w{font-size:16px;font-weight:800}
.lb-aw .lbn{font-size:13px;font-weight:800}
`;

  let uid = 0;
  function avatar(m, size) {
    const G = GEN[m.g], id = 'lbav' + (++uid);
    const sk = ['#f3d0aa', '#dcaa7c', '#b07a52'][hash(m.id * 7 + 3) * 3 | 0];
    const hc = ['#2a1d2e', '#5a3a22', '#d8c06a', '#8a3a6a', '#1e2a4a'][hash(m.id * 11 + 5) * 5 | 0];
    const hv = hash(m.id * 13 + 1) * 4 | 0;
    const hair = [
      '<path d="M19 30C18 15 46 15 45 30C43 23 37 20 32 20C27 20 21 23 19 30Z" fill="' + hc + '"/>',
      '<path d="M18 31C16 13 48 13 46 31L47 46L41 44L42 29C38 22 26 22 22 29L23 44L17 46Z" fill="' + hc + '"/>',
      '<path d="M19 28L21 16L25 21L28 12L32 20L36 12L39 21L43 16L45 28C40 21 24 21 19 28Z" fill="' + hc + '"/>',
      '<path d="M18 28C18 12 46 12 46 28Z" fill="' + G.c + '"/><rect x="17" y="25" width="30" height="5" rx="2.5" fill="' + G.d + '"/>',
    ][hv];
    const ink = '#2a1a22';
    const eyes = m.mood === 2 ? '<path d="M24.5 31q3-3.6 6 0M33.5 31q3-3.6 6 0" stroke="' + ink + '" stroke-width="2.2" fill="none" stroke-linecap="round"/>'
      : m.mood === 1 ? '<circle cx="27.5" cy="31" r="2" fill="' + ink + '"/><circle cx="36.5" cy="31" r="2" fill="' + ink + '"/>'
        : '<path d="M24.5 31.5h6M33.5 31.5h6" stroke="' + ink + '" stroke-width="2.2" stroke-linecap="round"/>';
    const mouth = m.mood === 2 ? '<path d="M26 36.5Q32 43.5 38 36.5Z" fill="#fff" stroke="' + ink + '" stroke-width="1.6" stroke-linejoin="round"/>'
      : m.mood === 1 ? '<path d="M28 37.5Q32 40 36 37.5" stroke="' + ink + '" stroke-width="2" fill="none" stroke-linecap="round"/>'
        : '<path d="M28 39.5Q32 36.5 36 39.5" stroke="' + ink + '" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M42 24q2 3.4 0 4.6q-2-1.2 0-4.6Z" fill="#8fd0ff"/>';
    const cheek = m.mood === 2 ? '<circle cx="24" cy="35.5" r="2.2" fill="#ff8fa0" opacity=".55"/><circle cx="40" cy="35.5" r="2.2" fill="#ff8fa0" opacity=".55"/>' : '';
    const svg = '<svg viewBox="0 0 64 64" width="' + size + '" height="' + size + '" aria-hidden="true"><defs><radialGradient id="' + id + '" cx=".5" cy=".3" r=".8"><stop offset="0" stop-color="' + G.c + '"/><stop offset="1" stop-color="' + G.d + '"/></radialGradient><clipPath id="' + id + 'c"><circle cx="32" cy="32" r="31"/></clipPath></defs>' +
      '<circle cx="32" cy="32" r="31" fill="url(#' + id + ')"/><g clip-path="url(#' + id + 'c)"><path d="M8 66C9 50 20 45 32 45C44 45 55 50 56 66Z" fill="' + G.d + '" stroke="#ffffff30" stroke-width="1"/>' +
      '<rect x="28" y="40" width="8" height="7" fill="' + sk + '"/><circle cx="32" cy="31" r="13" fill="' + sk + '"/>' + hair + eyes + cheek + mouth + '</g>' +
      '<circle cx="32" cy="32" r="30.5" fill="none" stroke="#ffffff40" stroke-width="1.2"/></svg>';
    const el = document.createElement('div');
    el.className = 'lb-av'; el.style.setProperty('--gc', G.c);
    el.innerHTML = svg + '<span class="gi">' + G.i + '</span>';
    return el;
  }
  const starsHtml = (n, max) => '<span class="lb-st">' + '★'.repeat(Math.min(n, max)) + '<span class="e">' + '★'.repeat(Math.max(0, max - n)) + '</span></span>';
  const heartsHtml = (n) => '<span class="lb-ht">' + '♥'.repeat(n) + '<span class="e">' + '♥'.repeat(5 - n) + '</span></span>';
  const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const rankTxt = (r) => (r <= 10 ? r + '위쯤' : '순위 밖');

  function mount(root, api) {
    const h = L.h;
    const styleEl = h('style', { text: CSS });
    const wrap = h('div', { class: 'lb' });
    root.append(styleEl, wrap);
    let st = null, lastMsg = null, lastSeen = -1, sentAt = 0, ov = null, sumOpen = false, step = 0, steps = [], timer = 0, flash = null, scrollTop = 0;
    const pname = (i) => (i >= 0 && api.players[i] ? api.players[i].name : '다른 레이블');
    const pcol = (i) => (i >= 0 && api.players[i] ? api.players[i].color : '#8a8098');
    const noHuman = () => !api.mySeats().length;
    function myView() {
      const v = api.viewer(); if (v >= 0) return v;
      const m = api.mySeats(); if (st && m.includes(st.cur)) return st.cur;
      return m.length ? m[0] : (st ? st.cur : 0);
    }
    const myTurn = () => st && st.ph !== 'over' && api.canAct(st.cur) && myView() === st.cur && !sumOpen;
    function send(a) {
      if (Date.now() - sentAt < 280 || !myTurn()) return;
      const e = legal(st, st.cur, a);
      if (e) { api.toast(e); api.sfx('thud'); return; }
      sentAt = Date.now(); api.sfx('click'); api.buzz(10);
      api.actAs(st.cur, a);
    }

    function render() {
      const s = st; if (!s) return;
      const m0 = wrap.querySelector('.lb-main'); if (m0) scrollTop = m0.scrollTop;
      wrap.innerHTML = '';
      const me = myView(), l = s.L[me], mine = myTurn();
      // 머리: 분기 + 진행 점 + 레이블 점수판
      const hd = h('div', { class: 'lb-hd' });
      const pips = h('div', { class: 'lb-pips', title: '전체 ' + TOTQ(s) + '분기' });
      for (let k = 0; k < TOTQ(s); k++) pips.append(h('i', { class: (k < s.t ? 'd' : k === s.t && s.ph !== 'over' ? 'c' : '') + (k % 4 === 3 ? ' y' : '') }));
      hd.append(h('div', { class: 'lb-qt' }, h('b', { text: s.ph === 'over' ? '시즌 끝' : s.yr + '년 ' + s.q + '분기' + (s.q === 4 ? ' 🏆' : '') }), pips));
      const sb = h('div', { class: 'lb-sb' });
      s.L.forEach((x, i) => sb.append(h('div', { class: 'lb-lab' + (i === s.cur && s.ph !== 'over' ? ' cur' : ''), style: { '--c': pcol(i) } },
        h('span', { class: 'n', text: (i === me && s.n > 1 ? '★ ' : '') + pname(i) }),
        h('span', { class: 'v', html: '⭐' + score(s, i) + (s.n === 1 ? '<span>/' + s.goal + '</span>' : '') + ' <span>₩' + x.m + '</span>' }))));
      hd.append(sb);
      wrap.append(hd);
      // 지금 할 일
      const todo = h('div', { class: 'lb-todo' + (mine ? ' me' : '') });
      if (s.ph === 'over') todo.append('🎉 모든 분기가 끝났어요');
      else if (mine) {
        const ro = rosterOf(s, me);
        const txt = !ro.length ? '✍️ 아래 시장에서 음악가와 계약하세요' : l.ap === AP ? '🎯 내 차례 — 음악가 버튼을 눌러요' : '🎯 한 번 더! 홍보·곡·공연·계약';
        todo.append(h('span', { text: txt }));
        const ap = h('span', { class: 'ap', title: '남은 행동' }); for (let k = 0; k < AP; k++) ap.append(h('i', { class: k < l.ap ? '' : 'u' }));
        todo.append(ap);
      } else {
        const lm = lastMsg && lastMsg.q === s.t && lastMsg.i !== me ? lastMsg : null;
        todo.append(h('span', { class: 'lb-dots', html: '<i></i><i></i><i></i>' }), h('div', { class: 'tw' }, h('span', { text: pname(s.cur) + ' 차례' }),
          lm ? h('small', { html: '<b style="color:' + pcol(lm.i) + '">' + esc(pname(lm.i)) + '</b> ' + esc(lm.x) }) : null));
        todo.style.setProperty('box-shadow', '0 0 0 1px ' + pcol(s.cur) + '88 inset');
      }
      wrap.append(todo);
      // 유행
      const tr = h('div', { class: 'lb-trend' }, h('span', { class: 'lbl', text: '이번 분기 유행' }));
      s.hot.forEach((g) => tr.append(h('span', { class: 'lb-gt', style: { '--gc': GEN[g].c }, text: '🔥 ' + GEN[g].n })));
      tr.append(h('span', { class: 'lb-gt cold', text: '❄️ ' + GEN[s.cold].n }));
      wrap.append(tr);
      // 본문
      const main = h('div', { class: 'lb-main' });
      const ro = rosterOf(s, me);
      main.append(h('div', { class: 'lb-sec' }, h('span', { text: '🎙️ 내 음악가 ' + ro.length + '/' + ROSTER }), h('small', { text: '한 명당 분기에 한 번 활동' })));
      if (!ro.length) main.append(h('div', { class: 'lb-empty', text: '아직 음악가가 없어요 — 아래 「시장」에서 계약하세요' }));
      ro.forEach((m) => main.append(muCard(s, m, me, mine)));
      // 내 곡
      const songs = elig(s).filter((x) => x.lb === me).sort((a, b) => b.t - a.t || b.st - a.st);
      main.append(h('div', { class: 'lb-sec' }, h('span', { text: '📀 내 곡' }), h('small', { text: '📣 홍보: 이번 분기 곡 힘 ×1.5 · ₩' + PRO_C })));
      if (!songs.length) main.append(h('div', { class: 'lb-empty', text: '차트에 올릴 곡이 없어요 — 🎙️ 곡 내기로 발매해요' }));
      songs.forEach((so) => main.append(songRow(s, so, me, mine)));
      // 시장
      main.append(h('div', { class: 'lb-sec' }, h('span', { text: '✍️ 시장' }), h('small', { text: '계약하면 끝까지 함께해요' })));
      const mk = h('div', { class: 'lb-mk' });
      marketOf(s).forEach((m) => mk.append(mkCard(s, m, me, mine)));
      main.append(mk);
      // 지난 차트
      main.append(h('div', { class: 'lb-sec' }, h('span', { text: '📊 지난 분기 TOP 10' }), h('small', { text: '1위 10점 · 2위 7 · 3위 5 …' })));
      if (!s.chart.length) main.append(h('div', { class: 'lb-empty', text: '첫 분기가 끝나면 차트가 나와요' }));
      else { const c = h('div', { class: 'lb-ch' }); s.chart.forEach((x, k) => c.append(chartRow(x, k, me))); main.append(c); }
      wrap.append(main);
      main.scrollTop = scrollTop;
      // 아래
      const bot = h('div', { class: 'lb-bot' });
      bot.append(h('div', { class: 'msg', text: s.ph === 'over' ? '' : mine ? '다 쓰면 자동으로 넘어가요' : (s.q === 4 ? '이번 분기 끝에 시상식!' : '모두 끝나면 TOP 10 발표') }));
      bot.append(h('button', { class: 'btn primary', type: 'button', text: '차례 끝 ▶', 'data-key': 'Enter', disabled: !mine, onclick: () => send({ t: 'end' }) }));
      wrap.append(bot);
      if (flash) { const el = wrap.querySelector('[data-f="' + flash + '"]'); if (el) { el.classList.add('lb-flash'); try { el.scrollIntoView({ block: 'nearest' }); } catch (e) { /* */ } } flash = null; }
    }
    function genreChip(s, g) {
      const hot = s.hot.includes(g), cold = s.cold === g;
      return h('span', { class: 'lb-chip g' + (hot ? ' hot' : ''), style: { '--gc': GEN[g].c }, text: GEN[g].i + ' ' + GEN[g].n + (hot ? ' 🔥' : cold ? ' ❄️' : '') });
    }
    function traitChip(m) { const T = TR[m.tr]; return h('span', { class: 'lb-chip', title: T.d, text: T.i + ' ' + T.n, onclick: () => api.toast(T.i + ' ' + T.n + ' — ' + T.d) }); }
    function muCard(s, m, me, mine) {
      const c = h('div', { class: 'lb-mc', style: { '--gc': GEN[m.g].c }, 'data-f': 'm' + m.id });
      const inf = h('div', { class: 'inf' },
        h('div', { class: 'nm', text: m.nm }),
        h('div', { class: 'ln' }, genreChip(s, m.g), traitChip(m)),
        h('div', { class: 'ln', html: '재능 ' + starsHtml(m.tal, 5) + ' &nbsp;인기 ' + heartsHtml(m.fame) }),
        h('div', { class: 'ln' }, h('span', { class: 'lb-mood', style: { color: MOOD[m.mood].c }, text: '기분 ' + MOOD[m.mood].i + ' ' + MOOD[m.mood].n })));
      c.append(h('div', { class: 'top' }, avatar(m, 70), inf));
      const acts = h('div', { class: 'lb-acts' });
      if (m.act === s.t) acts.append(h('div', { class: 'lb-done', text: '✅ 이번 분기 활동 끝' }));
      else if (mine) {
        const pv = previewRel(s, me, m);
        const e1 = legal(s, me, { t: 'rel', m: m.id }), e2 = legal(s, me, { t: 'gig', m: m.id });
        acts.append(h('button', { class: 'lb-b pri', type: 'button', disabled: !!e1, onclick: () => send({ t: 'rel', m: m.id }) },
          h('b', { text: '🎙️ 곡 내기 ₩' + REL_C }), h('span', { text: e1 || '★' + pv.st + ' · 예상 ' + rankTxt(pv.rank) })));
        acts.append(h('button', { class: 'lb-b', type: 'button', disabled: !!e2, onclick: () => send({ t: 'gig', m: m.id }) },
          h('b', { text: '🎤 공연' }), h('span', { text: '+₩' + gigPay(m) + (has(m, 'stage') ? ' · 안 지침' : ' · 지침↓') })));
      } else acts.append(h('div', { class: 'lb-done', text: '쉬는 중 — 분기가 끝나면 기분 한 칸 회복' }));
      c.append(acts);
      return c;
    }
    function songRow(s, so, me, mine) {
      const age = s.t - so.t;
      const last = s.chart.findIndex((x) => x.id === so.id);
      const row = h('div', { class: 'lb-song', style: { '--gc': GEN[so.g].c }, 'data-f': 's' + so.id });
      row.append(h('span', { class: 'gb' }));
      const ag = '<span class="lb-age" title="차트에 머무는 기간">' + [0, 1, 2].map((k) => '<i' + (k < 3 - age ? '' : ' class="u"') + '></i>').join('') + '</span>';
      row.append(h('div', { class: 'tx' },
        h('div', { class: 'tt', text: so.tt }),
        h('div', { class: 'sub', html: starsHtml(so.st, so.st).replace('lb-st', 'lb-st" style="font-size:13px') + ' ' + esc(so.mn) }),
        h('div', { class: 'sub', html: ag + ' ' + (age === 0 ? '신곡' : age === 2 ? '마지막 분기' : (age + 1) + '분기째') + (last >= 0 ? ' · 지난 ' + (last + 1) + '위' : '') + (so.pr === s.t ? ' · 📣 홍보함' : '') })));
      if (mine && so.pr !== s.t) {
        const pv = previewPromo(s, so), e = legal(s, me, { t: 'promo', r: so.id });
        row.append(h('button', { class: 'lb-b', type: 'button', disabled: !!e, onclick: () => send({ t: 'promo', r: so.id }) },
          h('b', { text: '📣 홍보 ₩' + PRO_C }), h('span', { text: e || (pv.to > 10 ? '그래도 순위 밖' : (pv.from > 10 ? '밖' : pv.from + '위') + ' → ' + pv.to + '위') })));
      } else {
        const r = previewPromo(s, so).from;
        row.append(h('div', { style: { textAlign: 'right', padding: '0 6px', fontSize: '13px', color: '#e6dcf2', fontWeight: '800', minWidth: '64px' }, html: '예상<br>' + (r > 10 ? '순위 밖' : r + '위') }));
      }
      return row;
    }
    function mkCard(s, m, me, mine) {
      const c = h('div', { class: 'lb-mc', style: { '--gc': GEN[m.g].c } });
      const cost = signCost(m), e = legal(s, me, { t: 'sign', m: m.id });
      c.append(h('div', { class: 'top' },
        h('div', { class: 'avr' }, avatar(m, 50), h('div', { class: 'nm', text: m.nm })),
        h('div', { class: 'ln' }, genreChip(s, m.g)),
        h('div', { class: 'ln' }, traitChip(m)),
        h('div', { class: 'ln', html: starsHtml(m.tal, 5) }),
        h('div', { class: 'ln', html: heartsHtml(m.fame) + ' <span class="lb-mood" style="color:' + MOOD[m.mood].c + '">' + MOOD[m.mood].i + '</span>' })));
      c.append(h('button', { class: 'lb-b' + (mine && !e ? ' pri' : ''), type: 'button', disabled: !mine || !!e, onclick: () => send({ t: 'sign', m: m.id }) },
        h('b', { text: '✍️ 계약 ₩' + cost }), mine && e ? h('span', { text: e.replace('소속이 꽉 찼어요', '꽉 참') }) : null));
      return c;
    }
    function chartRow(x, k, me) {
      const mvC = !x.pr ? 'nw' : x.pr > k + 1 ? 'up' : x.pr < k + 1 ? 'dn' : 'eq';
      const mvT = !x.pr ? 'NEW' : x.pr > k + 1 ? '▲' + (x.pr - k - 1) : x.pr < k + 1 ? '▼' + (k + 1 - x.pr) : '–';
      return h('div', { class: 'lb-cr' + (x.lb === me && x.lb >= 0 ? ' mine' : ''), style: { '--c': pcol(x.lb) } },
        h('span', { class: 'rk' + (k === 0 ? ' t1' : ''), text: String(k + 1) }),
        h('span', { class: 'mv ' + mvC, text: mvT }),
        h('div', { class: 'tx' }, h('span', { class: 'tt', text: GEN[x.g].i + ' ' + x.tt }), h('span', { class: 'sub', text: x.mn + ' · ★' + x.st })),
        h('div', null, h('span', { class: 'who', style: { color: x.lb >= 0 ? pcol(x.lb) : '#9c90ad', display: 'block' }, text: x.lb >= 0 ? pname(x.lb) : '다른 레이블' }), x.lb >= 0 ? h('span', { class: 'pt', text: '+' + x.d + '점' }) : null));
    }

    /* ----- 분기 결산(눌러서 넘기기, 사람이 없으면 저절로) ----- */
    function openSum(s) {
      const S = s.sum; if (!S) return;
      steps = ['chart'];
      if (S.ev || (S.hot && s.ph !== 'over')) steps.push('news');
      if (S.aw) steps.push('award');
      step = 0; sumOpen = true; api.setBusy(true);
      drawSum();
    }
    function closeSum() {
      clearTimeout(timer); timer = 0;
      if (ov) { ov.remove(); ov = null; }
      if (sumOpen) { sumOpen = false; api.setBusy(false); }
      render();
    }
    function nextStep() {
      clearTimeout(timer); timer = 0;
      if (step + 1 >= steps.length) { closeSum(); return; }
      step++; api.sfx(steps[step] === 'award' ? 'win' : 'pop'); drawSum();
    }
    function drawSum() {
      const s = st, S = s.sum, me = myView();
      if (ov) ov.remove();
      const card = h('div', { class: 'lb-card' });
      const body = h('div', { class: 'lb-cb' });
      const kind = steps[step];
      if (kind === 'chart') {
        card.append(h('h3', { text: S.yr + '년 ' + S.q + '분기 TOP 10' }), h('div', { class: 'csub', text: '순위대로 점수와 돈을 받아요' }));
        const gn = h('div', { class: 'lb-gain' });
        S.g.forEach((g, i) => gn.append(h('div', { style: { '--c': pcol(i) } }, h('div', { class: 'n', text: pname(i) }), h('div', { class: 'p', text: '+' + g.p + '점' }), h('div', { class: 'm', text: '+₩' + g.m }))));
        body.append(gn);
        const box = h('div', { class: 'lb-ch lb-anim' });
        const RH = 44;
        box.style.height = (s.chart.length * RH + 8) + 'px';
        const rows = s.chart.map((x, k) => { const r = chartRow(x, k, me); r.style.top = (4 + k * RH) + 'px'; r.style.height = (RH - 2) + 'px'; return r; });
        rows.forEach((r, k) => {
          const x = s.chart[k];
          const from = x.pr ? x.pr - 1 : 11 + k * 0.3;
          r.style.transform = 'translateY(' + ((from - k) * RH) + 'px)';
          r.style.opacity = x.pr ? '1' : '0';
          r.style.transitionDelay = (k * 0.05) + 's';
          box.append(r);
        });
        body.append(box);
        requestAnimationFrame(() => requestAnimationFrame(() => rows.forEach((r) => { r.style.transform = 'none'; r.style.opacity = '1'; })));
      } else if (kind === 'news') {
        card.append(h('h3', { text: '이번 분기 소식' }), h('div', { class: 'csub', text: '다음 분기 계획에 참고하세요' }));
        if (S.ev) body.append(h('div', { class: 'lb-news', style: { borderColor: pcol(S.ev.i) } }, h('span', { class: 'ic', text: S.ev.k === 'viral' ? '🌟' : '📰' }),
          h('div', null, h('div', { style: { color: pcol(S.ev.i), fontSize: '13px' }, text: pname(S.ev.i) }), h('div', { text: S.ev.x }))));
        if (S.hot && s.ph !== 'over') {
          const t = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '4px' } });
          S.hot.forEach((g) => t.append(h('span', { class: 'lb-gt', style: { '--gc': GEN[g].c }, text: '🔥 ' + GEN[g].i + ' ' + GEN[g].n + (g === S.newHot ? ' NEW' : '') })));
          t.append(h('span', { class: 'lb-gt cold', text: '❄️ ' + GEN[S.cold].i + ' ' + GEN[S.cold].n }));
          body.append(h('div', { class: 'lb-news' }, h('span', { class: 'ic', text: '📈' }), h('div', null, h('div', { text: '다음 분기 유행: 🔥 곡 힘 ×1.5 · ❄️ ×0.7' }), t)));
        }
      } else {
        card.append(h('h3', { text: '🏆 ' + S.yr + '년 시상식' }), h('div', { class: 'csub', text: '트로피 1개 = ' + AWP + '점' }));
        S.aw.forEach((w, k) => {
          const who = !w ? '수상 없음' : k === 2 ? pname(w.lb) : (w.tt ? '「' + w.tt + '」 ' : '') + w.mn;
          body.append(h('div', { class: 'lb-aw', style: { animationDelay: (k * 0.35) + 's' } }, h('span', { style: { fontSize: '36px', lineHeight: '1' }, text: ['🎵', '🎤', '🏢'][k] }),
            h('div', { style: { minWidth: '0' } }, h('div', { class: 'k', text: AWN[k] }), h('div', { class: 'w', text: who }),
              w ? h('div', { class: 'lbn', style: { color: w.lb >= 0 ? pcol(w.lb) : '#9c90ad' }, text: (w.lb >= 0 ? pname(w.lb) + ' +' + AWP + '점' : '다른 레이블') + ' · 올해 ' + w.v + '점' } ) : null)));
        });
      }
      card.append(body);
      const dots = h('div', { class: 'lb-steps' }); steps.forEach((_, k) => dots.append(h('i', { class: k === step ? 'on' : '' })));
      const last = step + 1 >= steps.length, over = s.ph === 'over';
      const foot = h('div', { class: 'lb-cf' }, h('button', { class: 'btn primary', type: 'button', 'data-key': 'Enter', text: last ? (over ? '최종 결과 ▶' : '다음 분기 ▶') : '다음 ▶', onclick: (e) => { e.stopPropagation(); api.sfx('click'); nextStep(); } }));
      card.append(dots, foot);
      ov = h('div', { class: 'lb-ov', onclick: (e) => { if (e.target === ov) nextStep(); } }, card);
      root.append(ov);
      // 사람이 없으면(봇만) 저절로 넘김. 사람이 있으면 「다음」을 기다려요.
      if (noHuman()) timer = setTimeout(nextStep, (kind === 'chart' ? 2600 : 2000) / Math.max(1, L.debug.speed || 1));
    }
    function announce(s, prev) {
      const l = s.last;
      if (!l || l.id === lastSeen) return;
      const first = lastSeen < 0 && prev == null;
      lastSeen = l.id;
      if (first) return;
      if (l.k === 'q') { api.sfx(l.aw ? 'win' : 'roll'); api.buzz(16); openSum(s); return; }
      api.sfx(l.k === 'sign' ? 'chip' : l.k === 'rel' ? 'pop' : l.k === 'promo' ? 'whoosh' : 'chip');
      lastMsg = { i: l.i, x: l.x, q: s.t };
      flash = l.k === 'promo' ? 's' + l.r : l.k === 'rel' ? 's' + l.r : 'm' + l.m;
    }
    const view = {
      update(s, prev) {
        st = s;
        announce(s, prev);
        render();
      },
      destroy() { clearTimeout(timer); if (ov) ov.remove(); if (sumOpen) api.setBusy(false); styleEl.remove(); wrap.remove(); },
    };
    return view;
  }

  /* ---------- 도감(데이터에서 자동) ---------- */
  const codex = [
    { h: '장르', p: ['분기마다 🔥 뜨는 장르 2개(곡 힘 ×' + HOT + ')와 ❄️ 식은 장르 1개(×' + COLD + ')가 있어요. 분기가 끝날 때마다 하나씩 바뀌어요.'],
      rows: GEN.map((G) => ({ icon: G.i, name: G.n, tag: '장르', desc: '유행에 따라 곡 힘 ×' + COLD + ' / ×1 / ×' + HOT })) },
    { h: '성격', p: ['음악가마다 성격이 하나 있어요. 칩을 누르면 설명이 떠요.'], rows: TR.map((t) => ({ icon: t.i, name: t.n, tag: '성격', desc: t.d })) },
    { h: '기분', p: ['활동(곡 내기·공연)하면 한 칸 지치고, 그 분기에 쉬면 한 칸 회복해요.'],
      rows: MOOD.map((M, k) => ({ icon: M.i, name: M.n, tag: '기분', desc: (k === 2 ? '곡 ★+1' : k === 0 ? '곡 ★−1 · 공연 수입 절반' : '보통') })) },
    { h: '차트', p: ['곡은 3분기 동안 차트에 머물러요(힘 ' + FRESH.map((f) => '×' + f).join(' → ') + ').', '곡 힘 = 별 ★ × 인기(♥ 하나당 +25%) × 유행 × 홍보(×1.5)'],
      rows: PTS.map((p, k) => ({ icon: k === 0 ? '🥇' : k === 1 ? '🥈' : k === 2 ? '🥉' : '🎵', name: (k + 1) + '위', tag: p + '점', desc: '수입 ₩' + PAY[k] + (k < 3 ? ' · 인기 ♥+1' : '') })) },
    { h: '행동', p: ['한 분기에 행동 ' + AP + '번. 음악가 한 명은 분기에 한 번만 활동해요.'],
      rows: [
        { icon: '✍️', name: '계약', tag: '₩1 + 재능×2 + 인기', desc: '시장의 음악가를 데려와요(최대 ' + ROSTER + '명, 끝까지 함께).' },
        { icon: '🎙️', name: '곡 내기', tag: '₩' + REL_C, desc: '이번 분기 차트에 들어가는 곡. 별 = 재능 ± 기분.' },
        { icon: '📣', name: '홍보', tag: '₩' + PRO_C, desc: '내 곡 하나의 이번 분기 힘 ×1.5.' },
        { icon: '🎤', name: '공연', tag: '+₩(2 + 인기)', desc: '돈을 벌어요. 지침 한 칸.' },
        { icon: '🏆', name: '시상식', tag: AWP + '점씩', desc: '4분기 끝: ' + AWN.join(' · ') + '.' },
      ] },
  ];

  L.register({
    id: 'label', name: '음반 레이블 경영', tag: '음악 경영', cat: '전략',
    icon: ICON, tint: '#4a2350', time: '10–20분',
    blurb: '음악가와 계약하고 곡을 내서 TOP 10 차트를 노려요. 유행을 타고, 해마다 시상식!',
    quick: [
      '음악가와 ✍️ 계약하고 🎙️ 곡을 내서 분기마다 TOP 10 차트에 올려요.',
      '한 분기에 행동 2번: 계약 · 곡 내기 · 📣 홍보 · 🎤 공연(돈).',
      '순위대로 점수! 4분기 끝엔 시상식. 마지막에 점수 1등이 이겨요.',
    ],
    options: [
      { id: 'years', label: '기간', choices: [{ v: 1, label: '1년' }, { v: 2, label: '2년' }, { v: 3, label: '3년' }], def: 2 },
    ],
    rules: [
      { h: '한눈에', p: [
        '1. 음악가와 ✍️ 계약하고 🎙️ 곡을 내요. 모두 끝나면 그 분기 TOP 10 차트 발표!',
        '2. 한 분기에 행동 2번: ✍️ 계약 · 🎙️ 곡 내기(₩' + REL_C + ') · 📣 홍보(₩' + PRO_C + ', 곡 힘 ×1.5) · 🎤 공연(돈 벌기). 음악가 한 명은 분기에 한 번만 활동.',
        '3. 곡 힘 = 재능 ★ × 인기 ♥ × 유행(🔥 ×1.5, ❄️ ×0.7). 버튼에 「예상 몇 위」가 나와요.',
        '4. 순위대로 점수(1위 10 · 2위 7 · 3위 5 …)와 돈. 곡은 3분기 동안 차트에 머물며 식어요.',
        '5. 4분기 끝 시상식: 올해의 노래·가수·레이블(트로피 1개 = ' + AWP + '점). 마지막에 점수 1등 승리!'] },
      { h: '기분', p: ['곡 내기·공연을 하면 한 칸 지치고(😄→🙂→😩), 그 분기에 쉬면 한 칸 회복해요. 😄 신나면 ★+1, 😩 지치면 ★−1.'] },
      { h: '혼자 하기', p: ['혼자면 목표 점수(1년 32 · 2년 100 · 3년 170점)를 넘기면 성공!'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움. 판마다 음악가·유행이 새로 나와요(판 밖 성장 없음).'] },
    ],
    tutorial: [
      { sel: '.lb-todo', text: '여기에 지금 할 일이 나와요. 노란 점 = 남은 행동 2번.' },
      { sel: '.lb-mc', text: '음악가 카드: 🎙️ 곡 내기 버튼에 별 ★과 예상 순위가 보여요.' },
      { sel: '.lb-trend', text: '🔥 뜨는 장르는 곡 힘 ×1.5! 장르를 맞춰 보세요.' },
      { text: '행동 2번을 쓰면 다음 레이블 차례. 모두 끝나면 TOP 10 발표!' },
    ],
    codex,
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 3, aiDelay: 700,
    init, actor, apply, ai, aiDelayFor, result, mount, hint,
    _t: { score, cands, aiValue, legal, GEN, TR, previewRel },
  });
})();
